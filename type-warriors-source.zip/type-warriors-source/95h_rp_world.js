/* ===== RUNESTONE RAMPARTS 8.8b art: grand castles and the world map (95h_rp_world.js) =====
   rpCastleArt(id) -> {c,w,h,gx,gy,c2} baked once per castle: 'moss' Mossgate Keep (grey stone, blue cones, green-and-gold banners,
     portcullis gatehouse, drawbridge, ivy), 'frost' Frostfang Citadel (pale ice stone, crystal spires, snow, icicles, a frozen icefall),
     'ember' Ember Crown (obsidian, horned towers, a crown keep with fire inside, red banners, lava falls and a lava moat).
     c is 300x520 (painted at 2x and scaled down; c2 is the 2x copy for small redraws). The road arrives from the LEFT: put the gate
     point (gx,gy) on the road's end; the area left of the gate stays empty so the road shows.
   rpCastleLive(g,id,x,y,t) cheap live layer at the castle's top-left: pennants, window and torch flicker, lava pulse, frost sparkles.
   rpCastleHit(g,id,x,y,k) red flash, shake and rubble while the keep takes a hit (k 0..1).
   rpWorldArt() -> 1600x900 world map (forest valley, snowy peaks, volcano) with the three castles; RPWORLD.nodes = castle bases;
   rpWorldLive(g,t) river shimmer, lava glow, falling snow, drifting mist, castle lights. rpMapIcon(id,w,h) -> castle on a tile.
   No ctx.filter, no shadowBlur; everything static is baked once and the live layers only blit small sprites and short paths. */
const RPWO='#12081f',RPW_PI=Math.PI;
const rpwR=i=>{const x=Math.sin(i*91.373+17.31)*43758.5453;return x-Math.floor(x)};
const RPWC={},RPWS={};
const RPW_PAL={
 moss:{st:'#908aa2',sl:'#c2bcd2',sd:'#615a76',sk:'#3e3852',roof:'#3159c4',rl:'#79a2f4',rd:'#1d2c7c',ban:'#2f8a3e',ban2:'#ffd45a',win:'#ffd27a',winG:'255,196,100',
  rock:'#6e687e',rockL:'#a29cb2',rockD:'#443e56',wood:'#7a5030',iron:'#3c3648'},
 frost:{st:'#9ec6ee',sl:'#e8f7ff',sd:'#6890c8',sk:'#43629a',roof:'#86dcff',rl:'#effcff',rd:'#3a86c6',ban:'#2c5cc0',ban2:'#eaf6ff',win:'#a8f6ff',winG:'120,232,255',
  rock:'#6c86ae',rockL:'#c0d6ee',rockD:'#3e5078',wood:'#5e5060',iron:'#3a4660'},
 wonder:{st:'#d8cff4',sl:'#fdfaff',sd:'#a196d0',sk:'#6a5c9e',roof:'#c8a8ff',rl:'#ffeefe',rd:'#7a5ad8',ban:'#7a3ad0',ban2:'#ffd45a',win:'#ffd0fa',winG:'255,160,250',
  rock:'#7a6cb8',rockL:'#cfc4f4',rockD:'#40367a',wood:'#c89a4a',iron:'#5a4a8a'},
 ember:{st:'#3e3448',sl:'#6a5a76',sd:'#271f30',sk:'#17111e',roof:'#541c26',rl:'#9a3a42',rd:'#2a0c14',ban:'#c8222e',ban2:'#ffb22a',win:'#ffa23e',winG:'255,128,36',
  rock:'#3a2a32',rockL:'#64485a',rockD:'#1e1418',wood:'#3a2018',iron:'#2a2230'}};
function rpwCv(w,h){const c=document.createElement('canvas');c.width=Math.max(1,Math.ceil(w));c.height=Math.max(1,Math.ceil(h));return c}
/* a cached soft radial glow sprite (drawn with 'lighter') */
function rpwGlow(rgb,r){const k=rgb+'|'+r;if(RPWS[k])return RPWS[k];const c=rpwCv(r*2,r*2),g=c.getContext('2d'),q=g.createRadialGradient(r,r,0,r,r,r);
 q.addColorStop(0,`rgba(${rgb},.9)`);q.addColorStop(.38,`rgba(${rgb},.36)`);q.addColorStop(1,`rgba(${rgb},0)`);g.fillStyle=q;g.fillRect(0,0,r*2,r*2);return RPWS[k]=c}
function rpwOut(g,w){g.strokeStyle=RPWO;g.lineWidth=w||2.6;g.stroke()}
/* flat wall with bevelled stones, light from the left */
function rpwWall(g,P,x,y,w,h,seed,sh){sh=sh||9;g.save();g.beginPath();g.rect(x,y,w,h);g.clip();
 let q=g.createLinearGradient(x,0,x+w,0);q.addColorStop(0,P.sl);q.addColorStop(.16,P.st);q.addColorStop(.78,P.st);q.addColorStop(1,P.sd);g.fillStyle=q;g.fillRect(x,y,w,h);
 let n=seed||1;g.lineWidth=1;
 for(let yy=y,r=0;yy<y+h;yy+=sh,r++){let xx=x-(r%2?sh*.8:sh*1.7);
  while(xx<x+w){const bw=sh*(1.5+rpwR(n)*1.3),v=rpwR(n*3+1);n++;
   if(v>.6){g.fillStyle=v>.86?'rgba(255,255,255,.13)':'rgba(18,8,31,.13)';g.fillRect(xx+1,yy+1,bw-2,sh-2)}
   g.strokeStyle='rgba(255,255,255,.22)';g.beginPath();g.moveTo(xx+1.5,yy+sh-1.5);g.lineTo(xx+1.5,yy+1.5);g.lineTo(xx+bw-1.5,yy+1.5);g.stroke();
   g.strokeStyle='rgba(18,8,31,.42)';g.beginPath();g.moveTo(xx+bw-.5,yy+.5);g.lineTo(xx+bw-.5,yy+sh-.5);g.lineTo(xx+.5,yy+sh-.5);g.stroke();xx+=bw}}
 q=g.createLinearGradient(0,y,0,y+h);q.addColorStop(0,'rgba(18,8,31,0)');q.addColorStop(1,'rgba(18,8,31,.3)');g.fillStyle=q;g.fillRect(x,y,w,h);
 g.restore();g.strokeStyle=RPWO;g.lineWidth=2.6;g.strokeRect(x,y,w,h)}
/* battlements along a wall top; ember gets obsidian teeth, frost gets snow caps */
function rpwCren(g,P,id,x,y,w,mw){mw=mw||9;const gap=mw*.7,n=Math.max(1,Math.floor((w+gap)/(mw+gap))),sp=n>1?(w-n*mw)/(n-1):0;
 for(let i=0;i<n;i++){const xx=x+i*(mw+sp);
  if(id==='ember'){const tooth=()=>{g.beginPath();g.moveTo(xx,y+1);g.lineTo(xx,y-mw*.5);g.lineTo(xx+mw/2,y-mw*1.7);g.lineTo(xx+mw,y-mw*.5);g.lineTo(xx+mw,y+1);g.closePath()};
   tooth();g.fillStyle=P.st;g.fill();g.fillStyle=P.sl;g.beginPath();g.moveTo(xx,y-mw*.5);g.lineTo(xx+mw/2,y-mw*1.7);g.lineTo(xx+mw*.42,y+1);g.lineTo(xx,y+1);g.closePath();g.fill();
   g.fillStyle='rgba(255,140,60,.55)';g.beginPath();g.moveTo(xx+mw/2,y-mw*1.7);g.lineTo(xx+mw*.6,y-mw*.9);g.lineTo(xx+mw*.5,y-mw*.9);g.closePath();g.fill();tooth();rpwOut(g,2.2);continue}
  if(id==='wonder'){g.beginPath();g.moveTo(xx,y+1);g.lineTo(xx,y-mw*.55);g.arc(xx+mw/2,y-mw*.55,mw/2,RPW_PI,0);g.lineTo(xx+mw,y+1);g.closePath();g.fillStyle=P.st;g.fill();rpwOut(g,2);
   g.fillStyle='rgba(255,255,255,.7)';g.fillRect(xx+1.5,y-mw*.5,mw*.25,mw*.5);g.fillStyle='#ffd45a';g.beginPath();g.arc(xx+mw/2,y-mw*1.05-2,2.4,0,RPW_PI*2);g.fill();rpwOut(g,1.2);continue}
  g.fillStyle=P.st;g.fillRect(xx,y-mw,mw,mw+1);g.fillStyle=P.sl;g.fillRect(xx,y-mw,mw*.32,mw+1);g.fillStyle='rgba(18,8,31,.25)';g.fillRect(xx+mw*.72,y-mw,mw*.28,mw+1);
  g.beginPath();g.rect(xx,y-mw,mw,mw+1);rpwOut(g,2.2);
  if(id==='frost'){g.fillStyle='#f6fbff';g.beginPath();g.ellipse(xx+mw/2,y-mw,mw*.66,mw*.32,0,RPW_PI,0);g.quadraticCurveTo(xx+mw+1,y-mw+3,xx+mw*.7,y-mw+3);g.lineTo(xx+mw*.3,y-mw+2);g.closePath();g.fill();rpwOut(g,1.6)}}}
/* round tower body; by = front base, returns the top y */
function rpwDrum(g,P,cx,by,w,h,seed){const r=w/2,e=r*.3,ty=by-h;
 const body=()=>{g.beginPath();g.moveTo(cx-r,ty);g.lineTo(cx-r,by);g.ellipse(cx,by,r,e,0,RPW_PI,0,true);g.lineTo(cx+r,ty);g.closePath()};
 g.save();body();const q=g.createLinearGradient(cx-r,0,cx+r,0);q.addColorStop(0,P.st);q.addColorStop(.22,P.sl);q.addColorStop(.5,P.st);q.addColorStop(.84,P.sd);q.addColorStop(1,P.sk);
 g.fillStyle=q;g.fill();g.clip();const s=Math.max(7,Math.min(10,w*.11));let n=seed||3;g.lineWidth=1;
 for(let yy=ty+s,k=0;yy<by+e+s;yy+=s,k++){g.strokeStyle='rgba(18,8,31,.36)';g.beginPath();g.ellipse(cx,yy,r,e,0,RPW_PI,0,true);g.stroke();
  g.strokeStyle='rgba(255,255,255,.16)';g.beginPath();g.ellipse(cx,yy+1.3,r,e,0,RPW_PI*.97,RPW_PI*.42,true);g.stroke();
  const m=Math.max(4,Math.round(w/13));g.strokeStyle='rgba(18,8,31,.3)';g.beginPath();
  for(let j=0;j<m;j++){const a=RPW_PI*(j+(k%2?.5:0)+.02)/m;if(a<=.05||a>=RPW_PI-.05)continue;const x=cx+r*Math.cos(a),y1=yy+e*Math.sin(a);g.moveTo(x,y1-s);g.lineTo(x,y1)}g.stroke();
  if(rpwR(n++)>.7){const a=RPW_PI*(.2+rpwR(n)*.6),x=cx+r*Math.cos(a);g.fillStyle=rpwR(n+1)>.5?'rgba(255,255,255,.1)':'rgba(18,8,31,.12)';g.fillRect(x-s*.7,yy-s+e*Math.sin(a)+1,s*1.3,s-2)}}
 const q2=g.createLinearGradient(0,ty,0,by);q2.addColorStop(0,'rgba(18,8,31,0)');q2.addColorStop(1,'rgba(18,8,31,.28)');g.fillStyle=q2;g.fillRect(cx-r,ty,w,h+e);
 g.restore();body();rpwOut(g);return ty}
/* parapet ring with corbels and merlons on top of a drum (for roofless towers) */
function rpwRing(g,P,id,cx,ty,w){const R=w/2+4,E=R*.3,bh=11;
 g.fillStyle=P.sd;for(let j=1;j<8;j++){const a=RPW_PI*j/8,x=cx+R*.92*Math.cos(a),y=ty+E*Math.sin(a);g.beginPath();g.moveTo(x-2.6,y);g.lineTo(x+2.6,y);g.lineTo(x+1.4,y+7);g.lineTo(x-1.4,y+7);g.closePath();g.fill();rpwOut(g,1.5)}
 rpwDrum(g,P,cx,ty,R*2,bh,9);g.fillStyle=P.sk;g.beginPath();g.ellipse(cx,ty-bh,R,E,0,0,RPW_PI*2);g.fill();rpwOut(g,2.2);
 for(let j=0;j<7;j++){const a=RPW_PI*(j+.5)/7,x=cx+R*Math.cos(a),y=ty-bh+E*Math.sin(a),mw=3+6*Math.sin(a);
  if(id==='ember'){g.fillStyle=Math.cos(a)>.2?P.st:P.sl;g.beginPath();g.moveTo(x-mw/2,y+1);g.lineTo(x,y-11);g.lineTo(x+mw/2,y+1);g.closePath();g.fill();rpwOut(g,1.8);continue}
  g.fillStyle=Math.cos(a)>.3?P.sd:Math.cos(a)<-.3?P.sl:P.st;g.beginPath();g.rect(x-mw/2,y-8,mw,9);g.fill();rpwOut(g,1.8);
  if(id==='frost'){g.fillStyle='#f6fbff';g.beginPath();g.ellipse(x,y-8,mw*.62+1,2.6,0,RPW_PI,0);g.fill();rpwOut(g,1.2)}}}
/* tiled conical roof (moss) */
function rpwCone(g,P,cx,by,R,h,A,flag){const E=R*.3,ax=cx,ay=by-h;
 const path=()=>{g.beginPath();g.moveTo(cx-R,by);g.quadraticCurveTo(cx-R*.28,by-h*.38,ax,ay);g.quadraticCurveTo(cx+R*.28,by-h*.38,cx+R,by);g.ellipse(cx,by,R,E,0,0,RPW_PI);g.closePath()};
 g.save();path();let q=g.createLinearGradient(cx-R,0,cx+R,0);q.addColorStop(0,P.roof);q.addColorStop(.25,P.rl);q.addColorStop(.55,P.roof);q.addColorStop(1,P.rd);g.fillStyle=q;g.fill();g.clip();
 const rows=Math.max(5,Math.round(h/8));g.lineWidth=1.1;
 for(let i=1;i<=rows;i++){const v=i/rows,y=ay+h*v,hw=R*Math.pow(v,.75),sw=Math.max(4,R*.28),n=Math.max(1,Math.round(hw*2/sw));
  g.strokeStyle='rgba(18,8,31,.34)';g.beginPath();for(let k=0;k<n;k++){const x=cx-hw+(k+(i%2?.5:0))*(hw*2/n),dy=E*v*Math.sqrt(Math.max(0,1-((x-cx)/(hw+.01))**2));g.moveTo(x+sw*.5,y+dy-2);g.arc(x,y+dy-2,sw*.5,0,RPW_PI)}g.stroke()}
 g.fillStyle='rgba(255,255,255,.22)';g.beginPath();g.moveTo(cx-R*.62,by+E*.6);g.quadraticCurveTo(cx-R*.2,by-h*.4,ax,ay+2);g.quadraticCurveTo(cx-R*.32,by-h*.3,cx-R*.36,by+E*.8);g.closePath();g.fill();
 g.restore();path();rpwOut(g);
 g.strokeStyle=P.rd;g.lineWidth=3;g.beginPath();g.ellipse(cx,by,R-1,E-1,0,.15,RPW_PI-.15);g.stroke();
 g.strokeStyle=RPWO;g.lineWidth=2;g.beginPath();g.moveTo(ax,ay+2);g.lineTo(ax,ay-14);g.stroke();g.fillStyle='#ffd45a';g.beginPath();g.arc(ax,ay-1,3.2,0,RPW_PI*2);g.fill();rpwOut(g,1.6);
 if(flag)A.flags.push({x:ax,y:ay-14,len:flag,col:A.P.ban,c2:A.P.ban2})}
/* faceted ice spire with a snow collar (frost) */
function rpwSpire(g,P,cx,by,R,h,A,flag){const E=R*.3,ax=cx,ay=by-h;
 const path=()=>{g.beginPath();g.moveTo(cx-R,by);g.lineTo(cx-R*.55,by-h*.42);g.lineTo(ax,ay);g.lineTo(cx+R*.55,by-h*.42);g.lineTo(cx+R,by);g.ellipse(cx,by,R,E,0,0,RPW_PI);g.closePath()};
 g.save();path();let q=g.createLinearGradient(cx-R,0,cx+R,0);q.addColorStop(0,P.roof);q.addColorStop(.3,P.rl);q.addColorStop(.6,P.roof);q.addColorStop(1,P.rd);g.fillStyle=q;g.fill();g.clip();
 g.fillStyle='rgba(255,255,255,.42)';g.beginPath();g.moveTo(cx-R,by);g.lineTo(cx-R*.55,by-h*.42);g.lineTo(ax,ay);g.lineTo(cx-R*.18,by+E);g.closePath();g.fill();
 g.fillStyle='rgba(20,60,130,.28)';g.beginPath();g.moveTo(cx+R*.32,by+E);g.lineTo(ax,ay);g.lineTo(cx+R*.55,by-h*.42);g.lineTo(cx+R,by);g.closePath();g.fill();
 g.strokeStyle='rgba(255,255,255,.75)';g.lineWidth=1.2;g.beginPath();g.moveTo(ax,ay+3);g.lineTo(cx-R*.18,by+E);g.moveTo(cx-R*.62,by-h*.2);g.lineTo(cx-R*.35,by-h*.36);g.moveTo(cx-R*.5,by-h*.05);g.lineTo(cx-R*.3,by-h*.15);g.stroke();
 g.strokeStyle='rgba(30,70,140,.4)';g.beginPath();g.moveTo(ax,ay+3);g.lineTo(cx+R*.32,by+E);g.stroke();g.restore();path();rpwOut(g);
 /* snow collar with drips */
 for(let j=0;j<=6;j++){const a=RPW_PI*j/6,x=cx+R*1.02*Math.cos(a),y=by+E*Math.sin(a);g.fillStyle='#f6fbff';g.beginPath();g.ellipse(x,y-1,R*.26,R*.17+1,0,0,RPW_PI*2);g.fill()}
 g.strokeStyle=RPWO;g.lineWidth=1.8;g.beginPath();for(let j=0;j<=6;j++){const a=RPW_PI*j/6,x=cx+R*1.02*Math.cos(a),y=by+E*Math.sin(a);g.moveTo(x+R*.26,y-1);g.ellipse(x,y-1,R*.26,R*.17+1,0,0,RPW_PI)}g.stroke();
 g.fillStyle='#ffffff';g.beginPath();g.moveTo(ax,ay-9);g.lineTo(ax+3.5,ay-1);g.lineTo(ax,ay+5);g.lineTo(ax-3.5,ay-1);g.closePath();g.fill();rpwOut(g,1.5);
 A.spark.push([ax,ay-2],[cx-R*.4,by-h*.3]);if(flag){g.strokeStyle=RPWO;g.lineWidth=2;g.beginPath();g.moveTo(ax,ay-8);g.lineTo(ax,ay-20);g.stroke();A.flags.push({x:ax,y:ay-20,len:flag,col:P.ban,c2:P.ban2})}}
/* horned obsidian roof with spikes (ember) */
function rpwHorn(g,P,cx,by,R,h,A,flag){const E=R*.3,ax=cx,ay=by-h;
 for(const s of[-1,1]){const hp=()=>{g.beginPath();g.moveTo(cx+s*R*.5,by-h*.18);g.quadraticCurveTo(cx+s*R*1.75,by-h*.22,cx+s*R*1.5,by-h*.95);g.quadraticCurveTo(cx+s*R*1.32,by-h*.42,cx+s*R*.55,by-h*.02);g.closePath()};
  hp();const q=g.createLinearGradient(cx+s*R*.5,by,cx+s*R*1.5,by-h);q.addColorStop(0,'#8a7464');q.addColorStop(1,'#efe2c8');g.fillStyle=q;g.fill();
  g.save();hp();g.clip();g.strokeStyle='rgba(18,8,31,.4)';g.lineWidth=1.2;for(let i=1;i<5;i++){const u=i/5;g.beginPath();g.arc(cx+s*R*(.55+u*1.05),by-h*(.1+u*.65),R*.25,0,RPW_PI*2);g.stroke()}g.restore();hp();rpwOut(g,2.2)}
 const path=()=>{g.beginPath();g.moveTo(cx-R,by);g.lineTo(cx-R*.42,by-h*.5);g.lineTo(ax,ay);g.lineTo(cx+R*.42,by-h*.5);g.lineTo(cx+R,by);g.ellipse(cx,by,R,E,0,0,RPW_PI);g.closePath()};
 g.save();path();let q=g.createLinearGradient(cx-R,0,cx+R,0);q.addColorStop(0,P.roof);q.addColorStop(.28,P.rl);q.addColorStop(.6,P.roof);q.addColorStop(1,P.rd);g.fillStyle=q;g.fill();g.clip();
 g.strokeStyle='rgba(18,8,31,.45)';g.lineWidth=1.2;for(let k=-3;k<=3;k++){g.beginPath();g.moveTo(ax,ay);g.lineTo(cx+k*R*.3,by+E);g.stroke()}
 g.strokeStyle='rgba(255,120,60,.5)';g.beginPath();g.moveTo(ax,ay+2);g.lineTo(cx-R*.3,by+E);g.stroke();g.restore();path();rpwOut(g);
 g.fillStyle=P.sd;for(let j=0;j<=6;j++){const a=RPW_PI*j/6,x=cx+R*Math.cos(a),y=by+E*Math.sin(a);g.beginPath();g.moveTo(x-3,y-2);g.lineTo(x+Math.cos(a)*7,y+6+Math.sin(a)*3);g.lineTo(x+3,y-2);g.closePath();g.fill();rpwOut(g,1.5)}
 g.fillStyle=P.iron;g.beginPath();g.moveTo(ax-2.5,ay+3);g.lineTo(ax,ay-16);g.lineTo(ax+2.5,ay+3);g.closePath();g.fill();rpwOut(g,1.6);
 A.ember.push([ax,ay-14]);if(flag)A.flags.push({x:ax,y:ay-14,len:flag,col:P.ban,c2:P.ban2})}
/* iridescent crystal spire with a gold collar and a star finial (wonder) */
function rpwPrism(g,P,cx,by,R,h,A,flag){const E=R*.3,ax=cx,ay=by-h;
 const path=()=>{g.beginPath();g.moveTo(cx-R,by);g.lineTo(cx-R*.5,by-h*.42);g.lineTo(ax,ay);g.lineTo(cx+R*.5,by-h*.42);g.lineTo(cx+R,by);g.ellipse(cx,by,R,E,0,0,RPW_PI);g.closePath()};
 g.save();path();let q=g.createLinearGradient(0,ay,0,by+E);q.addColorStop(0,'#fff4ff');q.addColorStop(.3,'#ffb4ee');q.addColorStop(.62,'#b496ff');q.addColorStop(1,'#78d8ff');g.fillStyle=q;g.fill();g.clip();
 g.fillStyle='rgba(255,255,255,.42)';g.beginPath();g.moveTo(cx-R,by);g.lineTo(cx-R*.5,by-h*.42);g.lineTo(ax,ay);g.lineTo(cx-R*.15,by+E);g.closePath();g.fill();
 g.fillStyle='rgba(70,30,150,.3)';g.beginPath();g.moveTo(cx+R*.35,by+E);g.lineTo(ax,ay);g.lineTo(cx+R*.5,by-h*.42);g.lineTo(cx+R,by);g.closePath();g.fill();
 g.strokeStyle='rgba(255,255,255,.85)';g.lineWidth=1.2;g.beginPath();g.moveTo(ax,ay+3);g.lineTo(cx-R*.15,by+E);g.moveTo(cx-R*.5,by-h*.42);g.lineTo(cx-R*.62,by+E*.6);g.moveTo(cx-R*.55,by-h*.2);g.lineTo(cx-R*.3,by-h*.32);g.stroke();
 g.strokeStyle='rgba(90,40,170,.45)';g.beginPath();g.moveTo(ax,ay+3);g.lineTo(cx+R*.35,by+E);g.stroke();g.restore();path();rpwOut(g);
 rpwBand(g,cx,by,R*1.04);
 g.fillStyle='#ffd45a';g.beginPath();g.arc(ax,ay-1,2.6,0,RPW_PI*2);g.fill();rpwOut(g,1.4);rpwStar(g,ax,ay-9,6,4);g.fillStyle='#ffffff';g.fill();rpwOut(g,1.4);
 A.spark.push([ax,ay-9]);A.ember.push([ax,ay-9]);if(flag){g.strokeStyle=RPWO;g.lineWidth=2;g.beginPath();g.moveTo(ax,ay-15);g.lineTo(ax,ay-26);g.stroke();A.flags.push({x:ax,y:ay-26,len:flag,col:P.ban,c2:P.ban2})}}
/* a gold band around a drum, with small gems */
function rpwBand(g,cx,y,R){const E=R*.3;g.beginPath();g.ellipse(cx,y,R,E,0,0,RPW_PI);g.lineTo(cx-R,y-4);g.ellipse(cx,y-4,R,E,0,RPW_PI,0,true);g.closePath();g.fillStyle='#ffc94a';g.fill();rpwOut(g,1.8);
 g.strokeStyle='#fff2b0';g.lineWidth=1.2;g.beginPath();g.ellipse(cx,y-3,R*.98,E,0,RPW_PI*.62,RPW_PI*.92);g.stroke();
 for(let j=1;j<5;j++){const a=RPW_PI*j/5,x=cx+R*Math.cos(a),yy=y-2+E*Math.sin(a);g.fillStyle=j%2?'#ff7ae0':'#6ae0ff';g.beginPath();g.arc(x,yy,1.6,0,RPW_PI*2);g.fill()}}
function rpwRoof(g,P,id,cx,by,R,h,A,flag){(id==='frost'?rpwSpire:id==='ember'?rpwHorn:id==='wonder'?rpwPrism:rpwCone)(g,P,cx,by,R,h,A,flag)}
/* windows: round-topped (moss), lancet (frost), slit with a pointed head (ember) */
function rpwWin(g,P,id,A,x,y,w,h){const shp=(o)=>{g.beginPath();if(id==='moss'||id==='wonder')g.roundRect(x-o,y-o,w+o*2,h+o*2,[w/2+o,w/2+o,1,1]);else{const pk=id==='frost'?w*.9:w*1.1;g.moveTo(x-o,y+h+o);g.lineTo(x-o,y+pk*.45);g.lineTo(x+w/2,y-pk*.45-o);g.lineTo(x+w+o,y+pk*.45);g.lineTo(x+w+o,y+h+o);g.closePath()}};
 shp(2);g.fillStyle=id==='wonder'?'#ffd45a':P.sk;g.fill();rpwOut(g,1.6);shp(0);g.fillStyle=P.win;g.fill();if(id==='wonder'){g.save();shp(0);g.clip();const q=g.createLinearGradient(0,y,0,y+h);q.addColorStop(0,'#ffd0fa');q.addColorStop(1,'#9ae8ff');g.fillStyle=q;g.fillRect(x,y-w,w,h+w);g.restore()}
 g.save();shp(0);g.clip();g.fillStyle='rgba(255,255,255,.4)';g.fillRect(x,y+h*.55,w*.45,h*.45);g.fillStyle='rgba(18,8,31,.22)';g.fillRect(x+w*.62,y-w,w,h+w);g.restore();
 g.strokeStyle=RPWO;g.lineWidth=1.3;g.beginPath();g.moveTo(x+w/2,y-w*.2);g.lineTo(x+w/2,y+h);g.moveTo(x,y+h*.52);g.lineTo(x+w,y+h*.52);g.stroke();
 g.fillStyle=P.sl;g.fillRect(x-2.5,y+h+1.5,w+5,3);g.strokeStyle=RPWO;g.lineWidth=1.2;g.strokeRect(x-2.5,y+h+1.5,w+5,3);
 A.wins.push([x+w/2,y+h/2,Math.max(w,h)*1.1])}
function rpwStar(g,x,y,r,n){n=n||5;g.beginPath();for(let i=0;i<n*2;i++){const a=-RPW_PI/2+i*RPW_PI/n,rr=i%2?r*.45:r;i?g.lineTo(x+Math.cos(a)*rr,y+Math.sin(a)*rr):g.moveTo(x+Math.cos(a)*rr,y+Math.sin(a)*rr)}g.closePath()}
/* hanging banners with a gold rod and an emblem */
function rpwBanner(g,P,id,x,y,w,h){const cl=()=>{g.beginPath();g.moveTo(x,y);g.lineTo(x+w,y);g.lineTo(x+w,y+h);g.lineTo(x+w/2,y+h-w*.42);g.lineTo(x,y+h);g.closePath()};
 cl();g.fillStyle=P.ban;g.fill();g.save();cl();g.clip();g.fillStyle='rgba(18,8,31,.25)';g.fillRect(x+w*.66,y,w,h);g.fillStyle='rgba(255,255,255,.16)';g.fillRect(x,y,w*.18,h);
 g.strokeStyle=P.ban2;g.lineWidth=1.6;g.beginPath();g.moveTo(x+2.5,y+2);g.lineTo(x+2.5,y+h-3);g.lineTo(x+w/2,y+h-w*.42-3);g.lineTo(x+w-2.5,y+h-3);g.lineTo(x+w-2.5,y+2);g.stroke();g.restore();cl();rpwOut(g,2.2);
 const ex=x+w/2,ey=y+h*.4,s=w*.3;g.fillStyle=P.ban2;g.strokeStyle=P.ban2;
 if(id==='moss'){g.beginPath();g.moveTo(ex,ey-s*1.3);g.quadraticCurveTo(ex+s*1.2,ey-s*.4,ex,ey+s*1.2);g.quadraticCurveTo(ex-s*1.2,ey-s*.4,ex,ey-s*1.3);g.fill();g.strokeStyle=P.ban;g.lineWidth=1;g.beginPath();g.moveTo(ex,ey-s);g.lineTo(ex,ey+s*1.4);g.stroke()}
 else if(id==='wonder'){rpwStar(g,ex,ey,s*1.3);g.fill()}
 else if(id==='frost'){g.lineWidth=1.5;g.beginPath();for(let k=0;k<3;k++){const a=k*RPW_PI/3;g.moveTo(ex-Math.cos(a)*s*1.2,ey-Math.sin(a)*s*1.2);g.lineTo(ex+Math.cos(a)*s*1.2,ey+Math.sin(a)*s*1.2)}g.stroke()}
 else{g.beginPath();g.moveTo(ex,ey-s*1.5);g.quadraticCurveTo(ex+s*1.3,ey,ex+s*.5,ey+s);g.quadraticCurveTo(ex,ey+s*1.3,ex-s*.6,ey+s);g.quadraticCurveTo(ex-s*1.2,ey,ex,ey-s*1.5);g.fill()}
 g.fillStyle='#ffd45a';g.fillRect(x-3,y-2.5,w+6,4);g.strokeStyle=RPWO;g.lineWidth=1.5;g.strokeRect(x-3,y-2.5,w+6,4)}
/* a jagged boulder; x,y = bottom centre */
function rpwBoulder(g,P,x,y,w,h,s){const j=k=>.85+rpwR(s*7+k)*.3;
 const pts=[[x-w/2,y],[x-w*.5,y-h*.5*j(1)],[x-w*.28,y-h*.92*j(2)],[x+w*.08,y-h],[x+w*.36,y-h*.82*j(3)],[x+w*.5,y-h*.38*j(4)],[x+w*.46,y]];
 const poly=a=>{g.beginPath();g.moveTo(a[0][0],a[0][1]);for(let i=1;i<a.length;i++)g.lineTo(a[i][0],a[i][1]);g.closePath()};
 poly(pts);g.fillStyle=P.rock;g.fill();
 g.fillStyle=P.rockL;poly([pts[1],pts[2],pts[3],[x-w*.02,y-h*.5],[x-w*.3,y-h*.32]]);g.fill();
 g.fillStyle=P.rockD;poly([[x+w*.04,y-h*.46],pts[4],pts[5],pts[6],[x+w*.08,y]]);g.fill();
 g.strokeStyle='rgba(18,8,31,.45)';g.lineWidth=1.2;g.beginPath();g.moveTo(pts[3][0],pts[3][1]);g.lineTo(x-w*.02,y-h*.5);g.lineTo(x+w*.08,y);g.moveTo(x-w*.02,y-h*.5);g.lineTo(x-w*.3,y-h*.32);g.stroke();
 poly(pts);rpwOut(g,2.4)}
function rpwRocks(g,P,id,list,seed){list.slice().sort((a,b)=>a[1]-b[1]).forEach((b,i)=>{rpwBoulder(g,P,b[0],b[1],b[2],b[3],seed+i);
 if(id==='frost'){g.fillStyle='#f6fbff';g.beginPath();g.ellipse(b[0]-b[2]*.1,b[1]-b[3]*.9,b[2]*.32,b[3]*.16+1,-.15,0,RPW_PI*2);g.fill();rpwOut(g,1.6)}})}
/* ivy clinging to a wall */
function rpwIvy(g,x,y,len,s){const L=['#2c6a30','#3f8a3c','#5aa848'];let px=x;g.strokeStyle='#2a4a22';g.lineWidth=1.2;g.beginPath();g.moveTo(x,y);
 for(let v=0;v<len;v+=4)g.lineTo(x+Math.sin(v*.25+s)*4,y+v);g.stroke();
 for(let v=0;v<len;v+=3.2){const k=(v*7+s*13)|0;px=x+Math.sin(v*.25+s)*4+(rpwR(k)-.5)*9;const py=y+v+(rpwR(k+1)-.5)*3,sz=2.2+rpwR(k+2)*1.6*(1-v/len*.6);
  g.fillStyle=L[k%3];g.beginPath();g.ellipse(px,py,sz,sz*.7,rpwR(k+3)*3,0,RPW_PI*2);g.fill();g.strokeStyle='rgba(18,8,31,.7)';g.lineWidth=.8;g.stroke()}}
function rpwIcicles(g,x0,x1,y,s,len){len=len||9;for(let x=x0;x<x1;x+=4+rpwR(s+x)*3){const l=len*(.4+rpwR(s*3+x)*.8);g.fillStyle='#dff6ff';g.beginPath();g.moveTo(x-2,y);g.lineTo(x,y+l);g.lineTo(x+2,y);g.closePath();g.fill();g.strokeStyle='rgba(18,8,31,.6)';g.lineWidth=1;g.stroke()}}
/* clusters of ice crystals (frost) */
function rpwCrystal(g,x,y,h,a,w,C){w=w||h*.32;C=C||['#e8fbff','#9ae6ff','#5ab8ec','#2e78c0'];g.save();g.translate(x,y);g.rotate(a);const sh=()=>{g.beginPath();g.moveTo(-w/2,0);g.lineTo(-w/2,-h*.72);g.lineTo(0,-h);g.lineTo(w/2,-h*.72);g.lineTo(w/2,0);g.closePath()};
 sh();const q=g.createLinearGradient(-w/2,0,w/2,0);q.addColorStop(0,C[0]);q.addColorStop(.45,C[1]);q.addColorStop(.5,C[2]);q.addColorStop(1,C[3]);g.fillStyle=q;g.fill();
 g.strokeStyle='rgba(255,255,255,.8)';g.lineWidth=1;g.beginPath();g.moveTo(0,-h);g.lineTo(0,0);g.moveTo(-w*.3,-h*.6);g.lineTo(-w*.3,-h*.2);g.stroke();sh();rpwOut(g,2);g.restore()}
/* the gate: voussoir arch, dark passage with warm light, raised portcullis, keystone */
function rpwGate(g,P,id,A,cx,by,w,h){const r=w/2,sy=by-h+r,R2=r+9;
 g.beginPath();g.moveTo(cx-R2,by);g.lineTo(cx-R2,sy);g.arc(cx,sy,R2,RPW_PI,0);g.lineTo(cx+R2,by);g.closePath();g.fillStyle=P.sl;g.fill();rpwOut(g,2.4);
 g.strokeStyle='rgba(18,8,31,.55)';g.lineWidth=1.4;g.beginPath();for(let i=1;i<9;i++){const a=RPW_PI+i/9*RPW_PI;g.moveTo(cx+Math.cos(a)*r,sy+Math.sin(a)*r);g.lineTo(cx+Math.cos(a)*R2,sy+Math.sin(a)*R2)}
 for(let y=sy+9;y<by;y+=9){g.moveTo(cx-R2,y);g.lineTo(cx-r,y);g.moveTo(cx+r,y);g.lineTo(cx+R2,y)}g.stroke();
 const op=()=>{g.beginPath();g.moveTo(cx-r,by);g.lineTo(cx-r,sy);g.arc(cx,sy,r,RPW_PI,0);g.lineTo(cx+r,by);g.closePath()};
 op();g.fillStyle='#160c1e';g.fill();g.save();op();g.clip();
 let q=g.createLinearGradient(0,sy-r,0,by);q.addColorStop(0,'rgba(18,8,31,1)');q.addColorStop(1,`rgba(${P.winG},.55)`);g.fillStyle=q;g.fillRect(cx-r,sy-r,w,h);
 g.fillStyle=P.win;g.globalAlpha=.85;g.beginPath();g.moveTo(cx-r*.42,by);g.lineTo(cx-r*.42,by-h*.38);g.arc(cx,by-h*.38,r*.42,RPW_PI,0);g.lineTo(cx+r*.42,by);g.closePath();g.fill();g.globalAlpha=1;
 g.fillStyle='rgba(18,8,31,.5)';g.fillRect(cx-r,by-h*.16,w,h*.16);
 /* portcullis, raised two thirds */
 const pb=sy+r*.15;g.strokeStyle=P.iron;g.lineWidth=2.6;g.beginPath();for(let x=cx-r+5;x<cx+r;x+=7.5){g.moveTo(x,sy-r);g.lineTo(x,pb)}for(let y=sy-r+5;y<pb;y+=8){g.moveTo(cx-r,y);g.lineTo(cx+r,y)}g.stroke();
 g.strokeStyle='rgba(255,255,255,.22)';g.lineWidth=1;g.beginPath();for(let x=cx-r+4;x<cx+r;x+=7.5){g.moveTo(x,sy-r);g.lineTo(x,pb)}g.stroke();
 g.fillStyle=P.iron;for(let x=cx-r+5;x<cx+r;x+=7.5){g.beginPath();g.moveTo(x-2.2,pb);g.lineTo(x,pb+6);g.lineTo(x+2.2,pb);g.closePath();g.fill();rpwOut(g,1)}
 g.restore();op();rpwOut(g,2.6);
 /* keystone */
 const kc=id==='moss'?'#ffd45a':id==='frost'?'#bff4ff':id==='wonder'?'#ff9af0':'#ff5a2a';g.fillStyle=kc;g.beginPath();g.moveTo(cx-6,sy-R2-3);g.lineTo(cx+6,sy-R2-3);g.lineTo(cx+4,sy-r+2);g.lineTo(cx-4,sy-r+2);g.closePath();g.fill();rpwOut(g,1.8);
 g.fillStyle='rgba(255,255,255,.45)';g.fillRect(cx-4,sy-R2-1,2.5,6);if(id!=='moss')A.spark.push([cx,sy-R2+2])}
/* lowered drawbridge with chains */
function rpwBridge(g,P,cx,by,w,len,wy){const x0=cx-w/2-3,x1=cx+w/2+3,b0=cx-w/2-9,b1=cx+w/2+9;
 g.beginPath();g.moveTo(x0,by);g.lineTo(x1,by);g.lineTo(b1,by+len);g.lineTo(b0,by+len);g.closePath();g.fillStyle=P.wood;g.fill();
 g.save();g.clip();g.strokeStyle='rgba(18,8,31,.45)';g.lineWidth=1.2;g.beginPath();for(let k=1;k<7;k++){const u=k/7;g.moveTo(x0+(x1-x0)*u,by);g.lineTo(b0+(b1-b0)*u,by+len)}g.stroke();
 g.fillStyle='rgba(255,255,255,.14)';g.fillRect(b0,by,(b1-b0)*.3,len);g.fillStyle=P.iron;g.fillRect(b0,by+len*.3,b1-b0,2.5);g.fillRect(b0,by+len*.72,b1-b0,2.5);g.restore();
 g.beginPath();g.moveTo(x0,by);g.lineTo(x1,by);g.lineTo(b1,by+len);g.lineTo(b0,by+len);g.closePath();rpwOut(g,2.4);
 for(const s of[-1,1]){const ax=cx+s*(w/2+12),ay=wy,bx=cx+s*(w/2+6),bY=by+len-3;g.fillStyle='#8a8498';
  for(let i=0;i<=8;i++){const u=i/8;g.beginPath();g.ellipse(ax+(bx-ax)*u,ay+(bY-ay)*u,1.6,2.4,0,0,RPW_PI*2);g.fill();g.strokeStyle=RPWO;g.lineWidth=.8;g.stroke()}}}
function rpwTorch(g,A,x,y){g.fillStyle='#3a2a20';g.beginPath();g.moveTo(x-3,y-3);g.lineTo(x+3,y-3);g.lineTo(x+1.5,y+6);g.lineTo(x-1.5,y+6);g.closePath();g.fill();rpwOut(g,1.5);
 g.fillStyle='#ffd45a';g.fillRect(x-4,y-5,8,2.5);A.torch.push([x,y-5])}
/* a crest shield over the gate */
function rpwCrest(g,P,id,x,y,s){const sh=()=>{g.beginPath();g.moveTo(x-s,y-s);g.lineTo(x+s,y-s);g.lineTo(x+s,y);g.quadraticCurveTo(x+s,y+s*.9,x,y+s*1.35);g.quadraticCurveTo(x-s,y+s*.9,x-s,y);g.closePath()};
 sh();g.fillStyle='#ffd45a';g.fill();rpwOut(g,2.2);g.save();g.translate(x,y+s*.08);g.scale(.78,.78);g.translate(-x,-y);sh();g.fillStyle=P.ban;g.fill();g.restore();
 g.fillStyle='#ffd45a';if(id==='wonder'){rpwStar(g,x,y+s*.12,s*.62);g.fill()}else if(id==='frost'){g.strokeStyle='#ffffff';g.lineWidth=1.6;g.beginPath();for(let k=0;k<3;k++){const a=k*RPW_PI/3+RPW_PI/2;g.moveTo(x-Math.cos(a)*s*.55,y+s*.15-Math.sin(a)*s*.55);g.lineTo(x+Math.cos(a)*s*.55,y+s*.15+Math.sin(a)*s*.55)}g.stroke()}
 else if(id==='ember'){g.beginPath();g.moveTo(x-s*.55,y+s*.45);g.lineTo(x-s*.55,y-s*.25);g.lineTo(x-s*.28,y+s*.05);g.lineTo(x,y-s*.45);g.lineTo(x+s*.28,y+s*.05);g.lineTo(x+s*.55,y-s*.25);g.lineTo(x+s*.55,y+s*.45);g.closePath();g.fill()}
 else{g.beginPath();g.moveTo(x,y-s*.6);g.lineTo(x+s*.45,y+s*.25);g.lineTo(x+s*.15,y+s*.25);g.lineTo(x+s*.15,y+s*.6);g.lineTo(x-s*.15,y+s*.6);g.lineTo(x-s*.15,y+s*.25);g.lineTo(x-s*.45,y+s*.25);g.closePath();g.fill()}}
/* ---------- the three castles ---------- */
const RPW_CW=300,RPW_CH=520,RPW_GX=140,RPW_GY=440;
function rpwPaintCastle(g,id,A){const P=RPW_PAL[id];A.P=P;const fr=id==='frost',em=id==='ember',mo=id==='moss';
 /* ground shadow (kept below the road band so the road stays clear) */
 g.fillStyle='rgba(0,0,0,.28)';g.beginPath();g.ellipse(196,506,112,15,0,0,RPW_PI*2);g.fill();
 if(em){g.save();g.globalCompositeOperation='lighter';g.drawImage(rpwGlow('255,90,20',90),196-120,500-50,240,100);g.restore()}
 /* frost: a cliff behind the right side with a frozen icefall */
 if(fr){rpwRocks(g,P,id,[[278,300,40,60],[284,360,36,70],[280,430,44,80],[286,510,40,90]],40);}
 if(em){rpwRocks(g,P,id,[[280,330,36,56],[284,400,40,80],[282,470,44,80]],40)}
 /* back: the great tower (moss, frost) or the crown keep (ember) */
 if(em){const cx=160,w=118,ty=rpwDrum(g,P,cx,336,w,190,21),R=w/2,E=R*.3;
  /* fire inside the crown */
  g.fillStyle='#1a0c10';g.beginPath();g.ellipse(cx,ty,R-2,E-1,0,0,RPW_PI*2);g.fill();
  g.save();g.globalCompositeOperation='lighter';g.drawImage(rpwGlow('255,110,30',70),cx-70,ty-60,140,100);g.restore();
  g.fillStyle='#ff8a2a';g.beginPath();g.moveTo(cx-34,ty+4);g.quadraticCurveTo(cx-30,ty-26,cx-14,ty-34);g.quadraticCurveTo(cx-10,ty-14,cx,ty-46);g.quadraticCurveTo(cx+12,ty-18,cx+18,ty-30);g.quadraticCurveTo(cx+30,ty-12,cx+34,ty+4);g.closePath();g.fill();
  g.fillStyle='#ffd45a';g.beginPath();g.moveTo(cx-18,ty+4);g.quadraticCurveTo(cx-14,ty-12,cx-4,ty-22);g.quadraticCurveTo(cx+2,ty-8,cx+10,ty-14);g.quadraticCurveTo(cx+18,ty-4,cx+18,ty+4);g.closePath();g.fill();
  A.fire=[cx,ty-14];
  /* back spikes, then the gold band, then front spikes: a crown */
  const spike=(a,hh,ww,back)=>{const x=cx+R*Math.cos(a),y=ty+E*Math.sin(a)*(back?-1:1);const sp=()=>{g.beginPath();g.moveTo(x-ww/2,y+2);g.quadraticCurveTo(x-ww*.4,y-hh*.5,x,y-hh);g.quadraticCurveTo(x+ww*.4,y-hh*.5,x+ww/2,y+2);g.closePath()};
   sp();const q=g.createLinearGradient(x-ww/2,0,x+ww/2,0);q.addColorStop(0,back?P.st:P.sl);q.addColorStop(.45,back?P.sd:P.st);q.addColorStop(1,P.sk);g.fillStyle=q;g.fill();
   g.strokeStyle='#ffb22a';g.lineWidth=1.4;g.beginPath();g.moveTo(x-ww*.32,y);g.quadraticCurveTo(x-ww*.28,y-hh*.5,x,y-hh+3);g.stroke();sp();rpwOut(g,2.2);
   g.fillStyle='#ff5a2a';g.beginPath();g.arc(x,y-hh+1,2.6,0,RPW_PI*2);g.fill();A.ember.push([x,y-hh+1])};
  spike(RPW_PI*.25,46,18,true);spike(RPW_PI*.75,46,18,true);
  g.fillStyle='#d89a2a';g.beginPath();g.moveTo(cx-R,ty);g.ellipse(cx,ty,R,E,0,RPW_PI,0,true);g.lineTo(cx+R,ty+12);g.ellipse(cx,ty+12,R,E,0,0,RPW_PI);g.closePath();g.fill();
  g.save();g.clip();const qb=g.createLinearGradient(cx-R,0,cx+R,0);qb.addColorStop(0,'#ffe08a');qb.addColorStop(.3,'#ffc94a');qb.addColorStop(1,'#8a5a1a');g.fillStyle=qb;g.fillRect(cx-R,ty-E,w,30);g.restore();
  g.beginPath();g.moveTo(cx-R,ty);g.ellipse(cx,ty,R,E,0,RPW_PI,0,true);g.lineTo(cx+R,ty+12);g.ellipse(cx,ty+12,R,E,0,0,RPW_PI);g.closePath();rpwOut(g,2.2);
  for(const a of[.12,.3,.5,.7,.88]){spike(RPW_PI*a,a===.5?92:a===.3||a===.7?70:52,a===.5?26:20,false)}
  for(const a of[.2,.4,.6,.8]){const x=cx+R*Math.cos(RPW_PI*a),y=ty+6+E*Math.sin(RPW_PI*a);g.fillStyle='#c8222e';g.beginPath();g.arc(x,y,3.2,0,RPW_PI*2);g.fill();rpwOut(g,1.2)}
  /* a huge red gem on the crown band */
  g.fillStyle='#ff2a3a';g.beginPath();g.moveTo(cx,ty+E-8);g.lineTo(cx+9,ty+E+6);g.lineTo(cx,ty+E+20);g.lineTo(cx-9,ty+E+6);g.closePath();g.fill();rpwOut(g,2);g.fillStyle='rgba(255,220,200,.7)';g.beginPath();g.moveTo(cx,ty+E-5);g.lineTo(cx-5,ty+E+5);g.lineTo(cx,ty+E+4);g.closePath();g.fill();A.gem=[cx,ty+E+6];
  for(const [x,y] of[[118,236],[150,214],[186,214],[204,260],[136,280]])rpwWin(g,P,id,A,x,y,10,18)}
 else{const gt=rpwDrum(g,P,168,196,fr?40:48,fr?92:100,11);rpwRoof(g,P,id,168,gt,fr?25:31,fr?74:74,A,30);rpwWin(g,P,id,A,162,gt+26,12,20);
  /* the keep block with corner turrets */
  rpwWall(g,P,118,170,104,170,31,10);rpwCren(g,P,id,118,170,104,10);if(fr)rpwIcicles(g,120,220,171,5,8);
  for(const [x,y] of[[130,198],[164,198],[198,198],[146,250],[184,250]])rpwWin(g,P,id,A,x,y,12,20);
  for(const cx of[116,224]){const t=rpwDrum(g,P,cx,300,28,152,cx);rpwRoof(g,P,id,cx,t,fr?16:18,fr?62:46,A,cx===224?20:0)}
  if(fr){rpwCrystal(g,152,170,30,-.25);rpwCrystal(g,190,170,24,.3);rpwCrystal(g,170,170,38,.05);A.spark.push([170,138],[152,146])}}
 /* curtain walls */
 rpwWall(g,P,56,262,64,96,51,9);rpwCren(g,P,id,56,262,64,9);if(mo)rpwIvy(g,64,300,50,2);if(fr)rpwIcicles(g,58,118,263,9,10);
 rpwWall(g,P,184,300,40,176,61,9);rpwCren(g,P,id,184,300,40,9);
 /* left tower on its ledge */
 {const t=rpwDrum(g,P,46,362,em?40:46,em?196:170,71);if(em||fr)rpwRoof(g,P,id,46,t,em?24:27,em?66:100,A,26);else rpwRoof(g,P,id,46,t,29,80,A,26);
  rpwWin(g,P,id,A,40,t+34,11,19);rpwWin(g,P,id,A,40,t+94,11,19);if(mo)rpwIvy(g,32,t+70,90,5)}
 rpwRocks(g,P,id,[[18,384,40,30],[52,390,58,34],[88,384,40,24],[30,372,30,20]],7);
 if(fr){rpwCrystal(g,14,386,26,-.4);rpwCrystal(g,24,388,36,-.1);rpwCrystal(g,36,388,20,.35);A.spark.push([22,356])}
 if(em){g.fillStyle=P.iron;for(const [x,y,a] of[[10,382,-.5],[78,380,.2]]){g.save();g.translate(x,y);g.rotate(a);g.beginPath();g.moveTo(-4,4);g.lineTo(0,-22);g.lineTo(4,4);g.closePath();g.fill();rpwOut(g,1.6);g.restore()}}
 /* right great drum tower */
 {const cx=em?250:248,w=em?62:68,t=rpwDrum(g,P,cx,490,w,em?218:226,81);
  if(fr){rpwRoof(g,P,id,cx,t,38,128,A,34)}else if(em){rpwRing(g,P,id,cx,t,w);rpwRoof(g,P,id,cx,t-11,30,76,A,34)}else rpwRoof(g,P,id,cx,t,41,102,A,34);
  rpwWin(g,P,id,A,cx-6,t+40,12,21);rpwWin(g,P,id,A,cx-16,t+106,11,19);rpwWin(g,P,id,A,cx+6,t+150,10,18);
  rpwBanner(g,P,id,cx-10,t+62,20,44);if(mo)rpwIvy(g,cx-24,t+150,70,8);if(fr)rpwIcicles(g,cx-w/2,cx+w/2,t+2,13,12)}
 /* frost: frozen icefall pouring off the right cliff */
 if(fr){const fall=()=>{g.beginPath();g.moveTo(272,286);g.quadraticCurveTo(290,300,292,330);g.lineTo(296,486);g.quadraticCurveTo(300,504,292,514);g.lineTo(262,514);g.quadraticCurveTo(254,500,270,486);g.lineTo(276,330);g.quadraticCurveTo(276,300,272,286);g.closePath()};
  fall();const q=g.createLinearGradient(262,0,298,0);q.addColorStop(0,'#f2fcff');q.addColorStop(.5,'#a8e8ff');q.addColorStop(1,'#5aa8e0');g.fillStyle=q;g.fill();
  g.save();fall();g.clip();g.strokeStyle='rgba(255,255,255,.85)';g.lineWidth=1.4;g.beginPath();for(const x of[279,284,289]){g.moveTo(x,300);g.lineTo(x+1,500)}g.stroke();g.strokeStyle='rgba(40,110,180,.5)';g.beginPath();g.moveTo(287,320);g.lineTo(288,500);g.stroke();g.restore();fall();rpwOut(g,2.4);
  rpwIcicles(g,262,296,512,21,10);A.spark.push([282,340],[286,440],[272,500])}
 /* ember: lava falls off the right rocks into the moat */
 if(em){const fall=()=>{g.beginPath();g.moveTo(276,350);g.quadraticCurveTo(292,360,292,384);g.lineTo(296,500);g.lineTo(270,504);g.lineTo(276,384);g.quadraticCurveTo(276,364,276,350);g.closePath()};
  fall();const q=g.createLinearGradient(0,350,0,505);q.addColorStop(0,'#ffe27a');q.addColorStop(.4,'#ff9a2a');q.addColorStop(1,'#e8401a');g.fillStyle=q;g.fill();
  g.save();fall();g.clip();g.strokeStyle='rgba(120,20,10,.55)';g.lineWidth=2;g.beginPath();for(const x of[280,288]){g.moveTo(x,370);g.lineTo(x+1,500)}g.stroke();g.restore();fall();rpwOut(g,2.4);A.lava=[270,352,26,150]}
 /* the gatehouse */
 rpwWall(g,P,96,326,88,148,91,9);rpwCren(g,P,id,96,326,88,9);if(fr)rpwIcicles(g,98,182,327,17,11);
 g.fillStyle=P.sl;g.fillRect(90,470,100,7);g.strokeStyle=RPWO;g.lineWidth=2.2;g.strokeRect(90,470,100,7);
 rpwGate(g,P,id,A,RPW_GX,470,48,82);
 rpwCrest(g,P,id,RPW_GX,350,11);
 rpwBanner(g,P,id,101,342,15,40);rpwBanner(g,P,id,164,342,15,40);
 rpwTorch(g,A,108,404);rpwTorch(g,A,172,404);
 if(mo){rpwIvy(g,100,412,56,11);rpwIvy(g,182,420,48,3)}
 /* bartizans on the gatehouse corners: corbelled cone below, tower, roof */
 for(const cx of[96,184]){g.fillStyle=P.sd;g.beginPath();g.moveTo(cx-12,360);g.lineTo(cx,382);g.lineTo(cx+12,360);g.closePath();g.fill();rpwOut(g,2.2);
  const t=rpwDrum(g,P,cx,362,24,48,cx+3);rpwRoof(g,P,id,cx,t,em?13:15,em?30:fr?50:40,A,0);
  g.fillStyle=RPWO;g.fillRect(cx-1.5,t+16,3,12)}
 rpwBridge(g,P,RPW_GX,476,48,22,412);
 /* front rocks */
 rpwRocks(g,P,id,[[206,508,56,30],[246,516,70,34],[286,516,40,26],[194,494,26,16]],27);
 if(fr){rpwCrystal(g,214,500,22,-.3);rpwCrystal(g,226,504,30,.15);rpwCrystal(g,292,500,22,.4)}
 if(em){g.save();g.globalCompositeOperation='lighter';for(const [x,y,r] of[[230,512,44],[284,506,30],[196,506,26]])g.drawImage(rpwGlow('255,110,30',r),x-r,y-r);g.restore();
  g.strokeStyle='#ff8a2a';g.lineWidth=2;g.beginPath();g.moveTo(198,503);g.lineTo(212,498);g.lineTo(224,506);g.moveTo(240,510);g.lineTo(256,502);g.lineTo(270,509);g.stroke();
  g.fillStyle=P.iron;for(const [x,y,a] of[[262,500,.3],[214,494,-.2]]){g.save();g.translate(x,y);g.rotate(a);g.beginPath();g.moveTo(-4,4);g.lineTo(0,-24);g.lineTo(4,4);g.closePath();g.fill();rpwOut(g,1.6);g.restore()}}
 if(mo){for(const [x,y] of[[198,500],[290,508],[222,516]]){for(const [dx,dy,r] of[[-6,0,6],[5,-1,7],[0,-6,6]]){g.fillStyle='#2f7a3a';g.beginPath();g.arc(x+dx,y+dy,r,0,RPW_PI*2);g.fill();rpwOut(g,1.6)}
  g.fillStyle='#ff9ad8';g.beginPath();g.arc(x-2,y-5,1.6,0,RPW_PI*2);g.arc(x+4,y-2,1.6,0,RPW_PI*2);g.fill()}}}
/* the crystal palace (Wonderland): pearl stone, gold bands, iridescent crystal spires, a rose window, a rainbow waterfall, crystal gardens */
const RPW_CRY=[['#fff0fc','#ffb4ee','#ff7ad8','#b83aa8'],['#effcff','#9ae8ff','#5ac0f0','#3a70c8'],['#f6f0ff','#c8b0ff','#9a7aff','#5a3ac0']];
function rpwPaintPalace(g,A){const id='wonder',P=RPW_PAL.wonder;A.P=P;A.float=[];A.rain=null;
 g.fillStyle='rgba(30,10,60,.3)';g.beginPath();g.ellipse(196,506,116,15,0,0,RPW_PI*2);g.fill();
 g.save();g.globalCompositeOperation='lighter';g.globalAlpha=.7;g.drawImage(rpwGlow('200,140,255',110),40,250,300,280);g.restore();
 /* crystal cliff behind the right side, with a rainbow waterfall */
 rpwRocks(g,P,id,[[280,290,40,56],[286,360,36,74],[282,440,44,84],[288,512,40,90]],40);
 for(const [x,y,h,a,k] of[[270,250,34,-.2,0],[288,256,26,.3,1],[296,330,22,.4,2]])rpwCrystal(g,x,y,h,a,0,RPW_CRY[k]);
 /* back: the great tower in two tiers */
 {const cx=168,t1=rpwDrum(g,P,cx,212,50,96,11);rpwBand(g,cx,t1+2,27);const t2=rpwDrum(g,P,cx,t1,34,30,12);rpwBand(g,cx,t2+2,19);rpwRoof(g,P,id,cx,t2,22,54,A,30);
  rpwWin(g,P,id,A,cx-6,t1+22,12,22);rpwWin(g,P,id,A,cx-4,t2+8,8,14)}
 /* the keep with a rose window */
 rpwWall(g,P,112,172,114,170,31,10);rpwCren(g,P,id,112,172,114,10);
 {const x=169,y=232,r=21;g.fillStyle='#ffd45a';g.beginPath();g.arc(x,y,r+4,0,RPW_PI*2);g.fill();rpwOut(g,2.2);const C=['#ff7ae0','#ffb84a','#ffe46a','#7ae89a','#6ae0ff','#7a8aff','#b07aff','#ff8aa8'];
  for(let k=0;k<8;k++){g.fillStyle=C[k];g.beginPath();g.moveTo(x,y);g.arc(x,y,r,k/8*RPW_PI*2,(k+1)/8*RPW_PI*2);g.closePath();g.fill()}
  g.strokeStyle=RPWO;g.lineWidth=1.4;g.beginPath();for(let k=0;k<8;k++){g.moveTo(x,y);g.lineTo(x+Math.cos(k/8*RPW_PI*2)*r,y+Math.sin(k/8*RPW_PI*2)*r)}g.stroke();g.beginPath();g.arc(x,y,r,0,RPW_PI*2);g.stroke();
  g.fillStyle='#ffffff';g.beginPath();g.arc(x,y,6,0,RPW_PI*2);g.fill();rpwOut(g,1.4);g.fillStyle='rgba(255,255,255,.35)';g.beginPath();g.ellipse(x-7,y-8,7,4,-.6,0,RPW_PI*2);g.fill();A.wins.push([x,y,34]);A.rose=[x,y]}
 for(const [x,y] of[[124,200],[204,200],[126,272],[202,272],[164,286]])rpwWin(g,P,id,A,x,y,11,20);
 for(const x of[134,204]){rpwPrism(g,P,x,164,7,30,A,0)}
 for(const cx of[112,226]){const t=rpwDrum(g,P,cx,300,30,154,cx);rpwBand(g,cx,t+2,16);rpwRoof(g,P,id,cx,t,19,72,A,cx===226?22:0);rpwWin(g,P,id,A,cx-4,t+30,8,15)}
 /* curtain walls */
 rpwWall(g,P,56,262,64,96,51,9);rpwCren(g,P,id,56,262,64,9);rpwWall(g,P,184,300,40,176,61,9);rpwCren(g,P,id,184,300,40,9);
 /* left tower */
 {const t=rpwDrum(g,P,46,362,46,176,71);rpwBand(g,46,t+2,24);rpwRoof(g,P,id,46,t,28,104,A,26);rpwWin(g,P,id,A,40,t+34,11,20);rpwWin(g,P,id,A,40,t+96,11,20);rpwBand(g,46,t+70,24)}
 rpwRocks(g,P,id,[[18,384,40,30],[52,390,58,34],[88,384,40,24],[30,372,30,20]],7);
 for(const [x,y,h,a,k] of[[12,388,30,-.35,0],[24,390,40,-.08,2],[38,390,22,.35,1],[82,382,20,.3,0]])rpwCrystal(g,x,y,h,a,0,RPW_CRY[k]);
 /* right great tower in two tiers */
 {const cx=246,t=rpwDrum(g,P,cx,490,70,232,81);rpwBand(g,cx,t+2,37);const t2=rpwDrum(g,P,cx,t,50,30,82);rpwBand(g,cx,t2+2,27);rpwRoof(g,P,id,cx,t2,32,116,A,34);
  rpwWin(g,P,id,A,cx-6,t+40,12,22);rpwWin(g,P,id,A,cx-16,t+108,11,20);rpwWin(g,P,id,A,cx+8,t+156,10,18);rpwBanner(g,P,id,cx-10,t+62,20,44);rpwBand(g,cx,t+132,37)}
 /* rainbow waterfall off the cliff into a glowing pool */
 {const fall=()=>{g.beginPath();g.moveTo(272,286);g.quadraticCurveTo(290,296,292,330);g.lineTo(296,486);g.quadraticCurveTo(300,504,292,512);g.lineTo(262,512);g.quadraticCurveTo(254,500,270,486);g.lineTo(276,330);g.quadraticCurveTo(276,300,272,286);g.closePath()};
  fall();g.save();g.clip();const C=['#ff8ac8','#ffc86a','#fff08a','#8af0a8','#7ad8ff','#a88aff'];for(let k=0;k<6;k++){g.fillStyle=C[k];g.fillRect(262+k*6,280,6.4,240)}
  g.strokeStyle='rgba(255,255,255,.75)';g.lineWidth=1.4;g.beginPath();for(const x of[275,283,291]){g.moveTo(x,300);g.lineTo(x+1,505)}g.stroke();g.restore();fall();rpwOut(g,2.4);A.rain=[262,290,34,220]}
 g.save();g.globalCompositeOperation='lighter';g.drawImage(rpwGlow('255,150,250',40),246,476,80,60);g.restore();
 g.fillStyle='#7a5ad8';g.beginPath();g.ellipse(276,512,30,8,0,0,RPW_PI*2);g.fill();rpwOut(g,2);g.fillStyle='#ffd0fa';g.beginPath();g.ellipse(276,512,22,4.5,0,0,RPW_PI*2);g.fill();
 /* the gatehouse */
 rpwWall(g,P,96,326,88,148,91,9);rpwCren(g,P,id,96,326,88,9);g.fillStyle='#ffd45a';g.fillRect(90,470,100,7);g.strokeStyle=RPWO;g.lineWidth=2.2;g.strokeRect(90,470,100,7);
 rpwGate(g,P,id,A,RPW_GX,470,48,82);rpwCrest(g,P,id,RPW_GX,350,11);rpwBanner(g,P,id,101,342,15,40);rpwBanner(g,P,id,164,342,15,40);rpwTorch(g,A,108,404);rpwTorch(g,A,172,404);
 for(const cx of[96,184]){g.fillStyle=P.sd;g.beginPath();g.moveTo(cx-12,360);g.lineTo(cx,382);g.lineTo(cx+12,360);g.closePath();g.fill();rpwOut(g,2.2);g.fillStyle='#ffd45a';g.beginPath();g.arc(cx,382,2.6,0,RPW_PI*2);g.fill();
  const t=rpwDrum(g,P,cx,362,24,48,cx+3);rpwBand(g,cx,t+2,13);rpwRoof(g,P,id,cx,t,14,46,A,0);g.fillStyle=RPWO;g.fillRect(cx-1.5,t+16,3,12)}
 rpwBridge(g,P,RPW_GX,476,48,22,412);
 rpwRocks(g,P,id,[[206,508,56,30],[246,516,70,34],[194,494,26,16]],27);
 for(const [x,y,h,a,k] of[[200,502,26,-.3,1],[214,506,36,-.05,0],[230,508,24,.3,2],[258,514,20,.4,1]])rpwCrystal(g,x,y,h,a,0,RPW_CRY[k]);
 /* glowing mushrooms by the gate */
 for(const [x,y,r,c] of[[188,500,9,'#6ae0ff'],[180,506,6,'#ff7ae0']]){g.fillStyle='#f4ecff';g.fillRect(x-1.6,y-r*.9,3.2,r*.9);g.strokeStyle=RPWO;g.lineWidth=1.2;g.strokeRect(x-1.6,y-r*.9,3.2,r*.9);g.fillStyle=c;g.beginPath();g.ellipse(x,y-r*.9,r,r*.55,0,RPW_PI,0);g.closePath();g.fill();rpwOut(g,1.6);A.wins.push([x,y-r,r*1.6])}
 A.float=[[22,150,7,0],[292,190,6,1],[96,232,5,2],[214,120,6,0],[60,60,5,1],[276,80,5,2]];
 A.spark.push([169,232],[22,356],[214,470],[276,300])}
function rpCastleArt(id){if(!RPW_PAL[id])id='moss';if(RPWC[id])return RPWC[id];
 const A={id,w:RPW_CW,h:RPW_CH,gx:RPW_GX,gy:RPW_GY,flags:[],wins:[],torch:[],spark:[],ember:[],lava:null,fire:null,gem:null};
 const c2=rpwCv(RPW_CW*2,RPW_CH*2),g=c2.getContext('2d');g.lineJoin='round';g.lineCap='round';g.scale(2,2);if(id==='wonder')rpwPaintPalace(g,A);else rpwPaintCastle(g,id,A);
 const c=rpwCv(RPW_CW,RPW_CH),h=c.getContext('2d');h.imageSmoothingQuality='high';h.drawImage(c2,0,0,RPW_CW,RPW_CH);
 A.c=c;A.c2=c2;return RPWC[id]=A}
/* live layer: pennants, window and torch flicker, lava, sparkles. x,y = where the castle canvas is drawn (top-left) */
function rpCastleLive(g,id,x,y,t,lite){const A=rpCastleArt(id),P=A.P;g.save();g.translate(x,y);
 for(let i=0;i<A.flags.length;i++){const f=A.flags[i],L=f.len,n=6;g.beginPath();g.moveTo(f.x,f.y);
  for(let k=1;k<=n;k++){const u=k/n;g.lineTo(f.x+L*u,f.y+Math.sin(t*5+i*1.7-u*3)*3*u+u*2)}for(let k=n;k>=0;k--){const u=k/n;g.lineTo(f.x+L*u,f.y+9*(1-u*.85)+Math.sin(t*5+i*1.7-u*3)*3*u+u*2)}
  g.closePath();g.fillStyle=f.col;g.fill();g.strokeStyle=RPWO;g.lineWidth=1.6;g.stroke();g.fillStyle=f.c2;g.fillRect(f.x,f.y+3,L*.35,1.8)}
 g.globalCompositeOperation='lighter';const gw=rpwGlow(P.winG,24);
 for(let i=lite?1:0;i<A.wins.length;i+=lite?6:2){const w=A.wins[i],a=.22+.12*Math.sin(t*3.1+i*2.3)+.06*Math.sin(t*11+i);g.globalAlpha=a;g.drawImage(gw,w[0]-w[2],w[1]-w[2],w[2]*2,w[2]*2)}
 const wo=A.id==='wonder',tg=rpwGlow(wo?'255,140,250':'255,170,70',24);for(let i=0;i<A.torch.length;i++){const p=A.torch[i],f=.85+.15*Math.sin(t*13+i*3)+.08*Math.sin(t*29+i);g.globalAlpha=.55;g.drawImage(tg,p[0]-22*f,p[1]-26*f,44*f,44*f);
  g.globalAlpha=1;g.fillStyle=wo?'#c87aff':'#ff8a2a';g.beginPath();g.ellipse(p[0],p[1]-5*f,3.6,7*f,0,0,RPW_PI*2);g.fill();g.fillStyle=wo?'#ffe0ff':'#ffe27a';g.beginPath();g.ellipse(p[0],p[1]-3.5*f,1.8,3.8*f,0,0,RPW_PI*2);g.fill()}
 if(A.lava){const L=A.lava,eg=rpwGlow('255,100,30',40);g.globalAlpha=.35+.2*Math.sin(t*2.2);g.drawImage(eg,L[0]-30,L[1]+L[3]-50,90,80);
  g.globalAlpha=.7;g.fillStyle='#ffe27a';g.beginPath();for(let i=0;i<5;i++){const u=(t*.45+i/5)%1;g.rect(L[0]+6+i*4,L[1]+u*(L[3]-14),2,9)}g.fill()}
 if(A.fire){const f=A.fire,k=.5+.25*Math.sin(t*7)+.12*Math.sin(t*17);g.globalAlpha=k;g.drawImage(rpwGlow('255,140,40',40),f[0]-44,f[1]-40,88,70);
  g.globalAlpha=.75;g.fillStyle='#ffd45a';g.beginPath();for(let i=0;i<3;i++){const u=(t*.8+i/3)%1,x=f[0]-14+i*14+Math.sin(t*3+i)*4,y=f[1]-10-u*40,r=2.2*(1-u)+.6;g.moveTo(x+r,y);g.arc(x,y,r,0,RPW_PI*2)}g.fill()}
 if(A.rain){const L=A.rain;g.globalAlpha=.55;g.fillStyle='#ffffff';g.beginPath();for(let i=0;i<6;i++){const u=(t*.6+i/6)%1;g.rect(L[0]+10+(i%3)*7,L[1]+u*(L[3]-12),2,10)}g.fill();g.globalAlpha=.3+.15*Math.sin(t*2);g.drawImage(rpwGlow('255,150,250',30),L[0]-16,L[1]+L[3]-36,66,60)}
 if(A.rose&&!lite){g.globalAlpha=.3+.2*Math.sin(t*1.6);g.drawImage(rpwGlow('255,200,120',30),A.rose[0]-30,A.rose[1]-30)}
 if(A.gem){g.globalAlpha=.35+.25*Math.sin(t*2.6);g.drawImage(rpwGlow('255,40,60',20),A.gem[0]-20,A.gem[1]-20)}
 if(!lite)for(let i=0;i<A.ember.length;i++){const p=A.ember[i];g.globalAlpha=.3+.25*Math.sin(t*3+i*1.3);g.drawImage(rpwGlow(A.id==='wonder'?'255,210,255':'255,110,40',12),p[0]-12,p[1]-12)}
 if(A.spark.length&&!lite){g.fillStyle='#ffffff';g.globalAlpha=.9;g.beginPath();for(let i=0;i<A.spark.length;i++){const p=A.spark[i],u=(t*.6+i*.37)%1,a=Math.max(0,Math.sin(u*RPW_PI));if(a<.15)continue;const s=a*4.5;
   g.moveTo(p[0],p[1]-s*1.6);g.lineTo(p[0]+s*.35,p[1]-s*.35);g.lineTo(p[0]+s*1.6,p[1]);g.lineTo(p[0]+s*.35,p[1]+s*.35);g.lineTo(p[0],p[1]+s*1.6);g.lineTo(p[0]-s*.35,p[1]+s*.35);g.lineTo(p[0]-s*1.6,p[1]);g.lineTo(p[0]-s*.35,p[1]-s*.35);g.closePath()}g.fill();
  g.globalCompositeOperation='source-over';if(!lite){g.globalAlpha=.7;g.beginPath();for(let i=0;i<12;i++){const u=(t*.08+rpwR(i)*7)%1,xx=110+rpwR(i+20)*190+Math.sin(t+i)*6,yy=60+u*400;g.rect(xx,yy,2.2,2.2)}g.fill()}}
 if(A.float&&A.float.length){g.globalCompositeOperation='source-over';g.globalAlpha=1;for(let i=0;i<A.float.length;i++){const f=A.float[i],y=f[1]+Math.sin(t*1.6+i*1.9)*4,s=f[2],C=RPW_CRY[f[3]];
  g.beginPath();g.moveTo(f[0],y-s*1.6);g.lineTo(f[0]+s*.8,y);g.lineTo(f[0],y+s*1.6);g.lineTo(f[0]-s*.8,y);g.closePath();g.fillStyle=C[1];g.fill();g.strokeStyle=RPWO;g.lineWidth=1.4;g.stroke();g.fillStyle=C[0];g.beginPath();g.moveTo(f[0],y-s*1.6);g.lineTo(f[0]-s*.8,y);g.lineTo(f[0],y);g.closePath();g.fill()}}
 g.restore()}
/* hit flash: red silhouette over the castle with a small shake and flying rubble (k runs 0..1) */
function rpCastleHit(g,id,x,y,k){const A=rpCastleArt(id);if(k<0||k>=1)return;
 if(!A.red){const c=rpwCv(A.w,A.h),h=c.getContext('2d');h.drawImage(A.c,0,0);h.globalCompositeOperation='source-in';h.fillStyle='#ff2a3a';h.fillRect(0,0,A.w,A.h);A.red=c}
 const e=1-k,dx=Math.sin(k*46)*5*e,dy=Math.cos(k*39)*2*e;g.save();g.globalAlpha=.55*e;g.drawImage(A.red,x+dx,y+dy);g.globalAlpha=Math.min(1,e*1.4);
 for(let i=0;i<7;i++){const a=-RPW_PI*(.15+rpwR(i+3)*.7),v=40+rpwR(i+9)*70,px=x+A.gx+30+rpwR(i)*80+Math.cos(a)*v*k,py=y+A.gy-60-rpwR(i+5)*120+Math.sin(a)*v*k+160*k*k;
  g.fillStyle=i%2?A.P.st:A.P.sd;g.beginPath();g.rect(px-3,py-3,6,5);g.fill();g.strokeStyle=RPWO;g.lineWidth=1.4;g.stroke()}g.restore()}
/* ---------- the world map ---------- */
const RPWORLD={nodes:{moss:{x:255,y:548},frost:{x:676,y:304},ember:{x:1092,y:292},wonder:{x:1060,y:652}},scale:{moss:.48,frost:.48,ember:.48,wonder:.48}};
function rpwSpl(pts,step){const o=[];for(let i=0;i<pts.length-1;i++){const p0=pts[Math.max(0,i-1)],p1=pts[i],p2=pts[i+1],p3=pts[Math.min(pts.length-1,i+2)],n=Math.max(2,Math.ceil(Math.hypot(p2[0]-p1[0],p2[1]-p1[1])/step));
 for(let k=0;k<n;k++){const t=k/n,t2=t*t,t3=t2*t,f=j=>.5*(2*p1[j]+(-p0[j]+p2[j])*t+(2*p0[j]-5*p1[j]+4*p2[j]-p3[j])*t2+(-p0[j]+3*p1[j]-3*p2[j]+p3[j])*t3);o.push([f(0),f(1)])}}o.push(pts[pts.length-1].slice());return o}
function rpwIn(poly,x,y){let c=false;for(let i=0,j=poly.length-1;i<poly.length;j=i++){const a=poly[i],b=poly[j];if((a[1]>y)!==(b[1]>y)&&x<(b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0])c=!c}return c}
function rpwNear(L,x,y,d){const d2=d*d;for(let i=0;i<L.length;i++){const p=L[i];if((p[0]-x)**2+(p[1]-y)**2<d2)return true}return false}
function rpwPoly(g,a){g.beginPath();g.moveTo(a[0][0],a[0][1]);for(let i=1;i<a.length;i++)g.lineTo(a[i][0],a[i][1]);g.closePath()}
/* a ribbon of varying width along a dense polyline, as a closed polygon */
function rpwRibbon(L,w0,w1,off){const l=[],r=[];off=off||0;for(let i=0;i<L.length;i++){const a=L[Math.max(0,i-1)],b=L[Math.min(L.length-1,i+1)],dx=b[0]-a[0],dy=b[1]-a[1],m=Math.hypot(dx,dy)||1,nx=-dy/m,ny=dx/m,w=(w0+(w1-w0)*i/(L.length-1))/2,o=off*w*2;
 l.push([L[i][0]+nx*(w+o),L[i][1]+ny*(w+o)]);r.push([L[i][0]-nx*(w-o),L[i][1]-ny*(w-o)])}return l.concat(r.reverse())}
function rpwPine(g,x,y,h,c,hi,snow){g.fillStyle='rgba(0,0,0,.25)';g.beginPath();g.ellipse(x+h*.12,y+1,h*.36,h*.1,0,0,RPW_PI*2);g.fill();
 g.fillStyle='#4a3020';g.fillRect(x-h*.05,y-h*.16,h*.1,h*.17);g.strokeStyle=RPWO;g.lineWidth=1.6;g.strokeRect(x-h*.05,y-h*.16,h*.1,h*.17);
 for(let k=0;k<3;k++){const ty=y-h*(1-k*.22),by=y-h*(.2+(2-k)*.17),w=h*(.2+k*.085);
  g.beginPath();g.moveTo(x,ty);g.lineTo(x+w,by);g.quadraticCurveTo(x,by+h*.07,x-w,by);g.closePath();g.fillStyle=c;g.fill();g.lineWidth=1.8;g.strokeStyle=RPWO;g.stroke();
  g.fillStyle=snow?'#f4faff':hi;g.globalAlpha=snow?.95:.5;g.beginPath();g.moveTo(x,ty+1);g.lineTo(x-w*.78,by-1);g.quadraticCurveTo(x-w*.3,by-(by-ty)*.12,x-w*.05,by-(by-ty)*.3);g.closePath();g.fill();
  if(snow){g.beginPath();g.moveTo(x,ty+1);g.lineTo(x+w*.6,by-(by-ty)*.25);g.lineTo(x+w*.1,by-(by-ty)*.4);g.closePath();g.fill()}
  g.globalAlpha=1;g.fillStyle='rgba(10,20,20,.2)';g.beginPath();g.moveTo(x+1,ty+2);g.lineTo(x+w-1,by-1);g.lineTo(x+w*.2,by+h*.03);g.closePath();g.fill()}}
function rpwDead(g,x,y,h){g.fillStyle='rgba(0,0,0,.3)';g.beginPath();g.ellipse(x+h*.1,y+1,h*.3,h*.08,0,0,RPW_PI*2);g.fill();
 g.lineCap='round';const br=()=>{g.beginPath();g.moveTo(x,y);g.lineTo(x,y-h*.8);g.moveTo(x,y-h*.45);g.lineTo(x-h*.28,y-h*.72);g.moveTo(x,y-h*.6);g.lineTo(x+h*.25,y-h*.88);g.moveTo(x,y-h*.28);g.lineTo(x+h*.2,y-h*.42)};
 br();g.strokeStyle=RPWO;g.lineWidth=h*.1+2.4;g.stroke();br();g.strokeStyle='#3a2420';g.lineWidth=h*.1;g.stroke();g.strokeStyle='#ff7a2a';g.globalAlpha=.75;g.lineWidth=1.1;g.beginPath();g.moveTo(x-.5,y-h*.12);g.lineTo(x+.5,y-h*.32);g.lineTo(x-.5,y-h*.5);g.stroke();g.globalAlpha=1}
/* outlined cartoon cloud: union of circles with a shaded underside */
function rpwCloud(g,x,y,s,col,sh,alpha){const C=[[0,0,1],[-1.05,.25,.72],[1.05,.22,.78],[-.5,-.45,.72],[.5,-.5,.8],[-1.75,.45,.5],[1.8,.45,.52]];g.save();g.globalAlpha=alpha||1;
 const u=()=>{g.beginPath();for(const [dx,dy,r] of C){g.moveTo(x+dx*s+r*s,y+dy*s);g.arc(x+dx*s,y+dy*s,r*s,0,RPW_PI*2)}};
 u();g.strokeStyle=RPWO;g.lineWidth=5;g.stroke();u();g.fillStyle=col;g.fill();g.save();u();g.clip();g.fillStyle=sh;g.beginPath();g.ellipse(x+s*.2,y+s*1.05,s*3,s*.75,0,0,RPW_PI*2);g.fill();
 g.fillStyle='rgba(255,255,255,.35)';g.beginPath();g.ellipse(x-s*.6,y-s*.75,s*.9,s*.3,-.2,0,RPW_PI*2);g.fill();g.restore();g.restore()}
/* a mountain: jagged silhouette, lit left facets, shaded right facets, snow cap with gullies (or ember rim light) */
function rpwPeak(g,ax,ay,bl,br,by,k,seed){const J=i=>rpwR(seed*11+i);
 const L1=[ax+(bl-ax)*.3,ay+(by-ay)*(.26+J(1)*.08)],L2=[ax+(bl-ax)*.62,ay+(by-ay)*(.58+J(2)*.1)],R1=[ax+(br-ax)*.28,ay+(by-ay)*(.22+J(3)*.08)],R2=[ax+(br-ax)*.6,ay+(by-ay)*(.55+J(4)*.1)];
 const sil=[[bl,by],[L2[0]-6,L2[1]],[L1[0]-4,L1[1]],[ax,ay],[R1[0]+5,R1[1]],[R2[0]+7,R2[1]],[br,by]];
 const C=k==='snow'?['#d4e0f2','#a2b0d4','#7482b0','#5a6494','#f8fbff','#c2d2ec']:k==='far'?['#a8b4da','#8a96c4','#6e7aaa','#5a6494','#e4ecf8','#b8c6e2']:['#6a4450','#4a2c36','#321c24','#1e1016',null,null];
 const mx=ax+(J(5)-.5)*(br-bl)*.12;g.save();rpwPoly(g,sil);g.fillStyle=C[1];g.fill();g.clip();
 g.fillStyle=C[0];rpwPoly(g,[[bl-5,by+5],[L2[0]-6,L2[1]],[L1[0]-4,L1[1]],[ax,ay],[mx,by+5]]);g.fill();
 g.fillStyle=C[1];rpwPoly(g,[[L2[0]-6,L2[1]],[L2[0]+(mx-L2[0])*.5,by+5],[bl-5,by+5]]);g.fill();
 g.fillStyle=C[2];rpwPoly(g,[[mx,by+5],[ax,ay],[R1[0]+5,R1[1]],[R2[0]+7,R2[1]],[br+5,by+5]]);g.fill();
 g.fillStyle=C[3];g.globalAlpha=.7;rpwPoly(g,[[R1[0]+5,R1[1]],[R2[0]+7,R2[1]],[br+5,by+5],[R1[0]+(br-R1[0])*.35,by+5]]);g.fill();g.globalAlpha=1;
 if(C[4]){const cy=ay+(by-ay)*(.38+J(6)*.1),cap=[[bl-60,ay-60],[br+60,ay-60],[br+60,cy]];for(let i=10;i>=0;i--){const x=bl+(br-bl)*i/10;cap.push([x,cy+(i%2?-4:10+J(i+20)*22)*(1-Math.abs(i-5)/8)])}cap.push([bl-60,cy]);
  rpwPoly(g,cap);g.fillStyle=C[4];g.fill();g.save();rpwPoly(g,cap);g.clip();g.fillStyle=C[5];rpwPoly(g,[[mx,by+5],[ax,ay],[R1[0]+5,R1[1]],[R2[0]+7,R2[1]],[br+5,by+5]]);g.fill();g.restore();
  g.strokeStyle='rgba(18,8,31,.55)';g.lineWidth=1.6;rpwPoly(g,cap);g.stroke();
  g.fillStyle=C[4];for(let i=0;i<4;i++){const x=bl+(br-bl)*(.2+i*.2+J(i+30)*.06),y=cy+12;g.beginPath();g.moveTo(x-5,y-6);g.lineTo(x+5,y-6);g.lineTo(x+1,y+16+J(i+40)*22);g.closePath();g.fill()}}
 else{const q=g.createLinearGradient(0,ay,0,by);q.addColorStop(0,'rgba(255,90,40,0)');q.addColorStop(1,'rgba(255,90,40,.35)');g.fillStyle=q;g.fillRect(bl,ay,br-bl,by-ay)}
 g.strokeStyle='rgba(18,8,31,.3)';g.lineWidth=1.3;g.beginPath();for(let i=0;i<9;i++){const u=J(i+50),x=bl+(br-bl)*u,y=ay+(by-ay)*(.45+J(i+60)*.5);g.moveTo(x,y);g.lineTo(x+(J(i+70)-.5)*16,y+10+J(i+80)*14)}g.stroke();g.restore();
 g.strokeStyle='rgba(18,8,31,.5)';g.lineWidth=1.6;g.beginPath();g.moveTo(ax,ay);g.lineTo(mx,by);g.moveTo(L1[0]-4,L1[1]);g.lineTo(L2[0]+(mx-L2[0])*.5,by);g.moveTo(R1[0]+5,R1[1]);g.lineTo(R1[0]+(br-R1[0])*.35,by);g.stroke();
 if(!C[4]){g.strokeStyle='rgba(255,110,50,.6)';g.lineWidth=2.2;g.beginPath();g.moveTo(L2[0]-6,L2[1]);g.lineTo(L1[0]-4,L1[1]);g.lineTo(ax,ay);g.stroke()}
 rpwPoly(g,sil);rpwOut(g,k==='far'?2:2.6)}
/* cliff face hanging below an edge polyline: irregular rock columns, strata, a ragged foot */
function rpwCliff(g,E,dep,col,seed,snow){const L=rpwSpl(E,5);const B=L.map((p,i)=>[p[0],p[1]+dep*(.84+.14*Math.sin(i*.31+seed)+.1*Math.sin(i*.9+seed*2)+.08*rpwR(seed+i))]);
 rpwPoly(g,L.concat(B.slice().reverse()));g.fillStyle=col[1];g.fill();
 let i=0,n=seed;while(i<L.length-1){const w=3+((rpwR(n++)*4)|0),j=Math.min(L.length-1,i+w),a=L[i],b=L[j],sl=(b[1]-a[1])/(b[0]-a[0]+.01),v=rpwR(n++);
  g.fillStyle=sl>.2?(v>.5?col[0]:col[1]):sl<-.2?(v>.5?col[2]:col[3]||col[2]):(v>.6?col[0]:v>.25?col[1]:col[2]);
  g.beginPath();g.moveTo(a[0],a[1]);for(let k=i+1;k<=j;k++)g.lineTo(L[k][0],L[k][1]);for(let k=j;k>=i;k--)g.lineTo(B[k][0],B[k][1]);g.closePath();g.fill();
  g.strokeStyle='rgba(255,255,255,.16)';g.lineWidth=1.4;g.beginPath();g.moveTo(a[0]+1.5,a[1]+3);g.lineTo(B[i][0]+1.5,B[i][1]-2);g.stroke();
  g.strokeStyle='rgba(18,8,31,.42)';g.lineWidth=1.3;g.beginPath();g.moveTo(b[0],b[1]+2);g.lineTo(b[0]+(B[j][0]-b[0]),b[1]+(B[j][1]-b[1])*(v>.5?1:.55));g.stroke();
  for(let s2=0;s2<2;s2++)if(rpwR(n+s2*7)>.35){const y=a[1]+(B[i][1]-a[1])*(.22+rpwR(n+s2*5)*.6);g.beginPath();g.moveTo(a[0]+2,y);g.lineTo(b[0]-2,y+(b[1]-a[1])+(rpwR(n+s2)-.5)*4);g.stroke()}i=j}
 const q=g.createLinearGradient(0,0,0,1);void q;g.save();rpwPoly(g,L.concat(B.slice().reverse()));g.clip();
 for(let k=0;k<L.length;k+=2){const gg=g.createLinearGradient(0,L[k][1],0,B[k][1]);gg.addColorStop(0,'rgba(18,8,31,0)');gg.addColorStop(1,'rgba(18,8,31,.35)');g.fillStyle=gg;g.fillRect(L[k][0]-1,L[k][1],6,B[k][1]-L[k][1]+2)}g.restore();
 g.beginPath();g.moveTo(B[0][0],B[0][1]);for(let k=1;k<B.length;k++)g.lineTo(B[k][0],B[k][1]);rpwOut(g,2.6);
 g.beginPath();g.moveTo(L[0][0],L[0][1]);for(let k=1;k<L.length;k++)g.lineTo(L[k][0],L[k][1]);rpwOut(g,2.6);
 if(snow){g.fillStyle='#f6fbff';for(let k=0;k<L.length;k+=2){const p=L[k];g.beginPath();g.ellipse(p[0],p[1]+2,7,4+rpwR(seed+k)*4,0,0,RPW_PI*2);g.fill()}
  g.strokeStyle=RPWO;g.lineWidth=1.6;g.beginPath();for(let k=0;k<L.length;k+=2){const p=L[k],ry=4+rpwR(seed+k)*4;g.moveTo(p[0]+7,p[1]+2);g.ellipse(p[0],p[1]+2,7,ry,0,0,RPW_PI)}g.stroke();
  for(let k=3;k<L.length;k+=7){const p=L[k];rpwIcicles(g,p[0]-5,p[0]+6,p[1]+5,k,8)}}
 return B}
function rpwOak(g,x,y,h,c,hi){g.fillStyle='rgba(0,0,0,.25)';g.beginPath();g.ellipse(x+h*.12,y+1,h*.4,h*.11,0,0,RPW_PI*2);g.fill();g.fillStyle='#4a3020';g.fillRect(x-h*.06,y-h*.35,h*.12,h*.36);g.strokeStyle=RPWO;g.lineWidth=1.6;g.strokeRect(x-h*.06,y-h*.35,h*.12,h*.36);
 const C=[[0,-h*.62,h*.34],[-h*.26,-h*.45,h*.25],[h*.26,-h*.45,h*.27]];g.beginPath();for(const [dx,dy,r] of C){g.moveTo(x+dx+r,y+dy);g.arc(x+dx,y+dy,r,0,RPW_PI*2)}g.strokeStyle=RPWO;g.lineWidth=3.6;g.stroke();g.fillStyle=c;g.fill();
 g.fillStyle=hi;g.globalAlpha=.55;g.beginPath();g.arc(x-h*.1,y-h*.72,h*.15,0,RPW_PI*2);g.arc(x-h*.32,y-h*.5,h*.1,0,RPW_PI*2);g.fill();g.globalAlpha=1;
 g.fillStyle='rgba(0,0,0,.18)';g.beginPath();g.arc(x+h*.3,y-h*.38,h*.17,0,RPW_PI*2);g.fill()}
function rpwPlankBridge(g,x0,y0,x1,y1,wd){const a=Math.atan2(y1-y0,x1-x0),len=Math.hypot(x1-x0,y1-y0);g.save();g.translate(x0,y0);g.rotate(a);
 g.fillStyle='rgba(0,0,0,.3)';g.fillRect(4,-wd/2+6,len,wd);
 g.fillStyle='#7a5030';g.fillRect(0,-wd/2,len,wd);g.strokeStyle='rgba(18,8,31,.55)';g.lineWidth=1.2;g.beginPath();for(let x=6;x<len;x+=7){g.moveTo(x,-wd/2);g.lineTo(x,wd/2)}g.stroke();
 g.fillStyle='rgba(255,220,160,.18)';g.fillRect(0,-wd/2,len,wd*.3);g.strokeStyle=RPWO;g.lineWidth=2.2;g.strokeRect(0,-wd/2,len,wd);
 for(const s of[-1,1]){g.strokeStyle='#5a3a20';g.lineWidth=2.6;g.beginPath();g.moveTo(0,s*wd/2-3);g.quadraticCurveTo(len/2,s*wd/2+3,len,s*wd/2-3);g.stroke();
  for(let x=0;x<=len;x+=len/4){g.fillStyle='#5a3a20';g.fillRect(x-2,s*wd/2-7,4,8);g.strokeStyle=RPWO;g.lineWidth=1.4;g.strokeRect(x-2,s*wd/2-7,4,8)}}
 g.restore()}
function rpwWOpen(){try{const m=RP_MAPS.find(x=>x.id==='wonder');return !!(m&&RP_MAPOPEN(m))}catch(e){return false}}
/* the world: forest valley (Mossgate), snow plateau (Frostfang), ember plateau and volcano (Ember Crown), and the Wonderland lowland below the
   cliffs, shrouded in swirling mist while locked. One trail joins all four gates (each reached from the left). open = Wonderland unlocked;
   both versions are cached. Omitting open asks the save (RP_MAPOPEN), so the old one-argument calls keep working. */
let RPWW_C={};
function rpWorldArt(open){if(open===undefined)open=rpwWOpen();open=!!open;const key=open?'o':'l';if(RPWW_C[key])return RPWW_C[key].c;
 const c=rpwCv(1600,900),g=c.getContext('2d');g.lineJoin='round';g.lineCap='round';const W={c,open,riv:[],lava:[],falls:[],isl:[],cast:[]};
 const S=[[452,-10],[905,-10],[915,140],[895,260],[930,360],[905,410],[820,430],[720,428],[640,408],[560,360],[505,300],[470,220],[445,110]];
 const E=[[965,-10],[1610,-10],[1610,500],[1420,488],[1290,466],[1170,452],[1080,440],[995,410],[985,330],[960,240],[985,120]];
 const GORGE=[[895,-10],[985,-10],[985,120],[960,240],[985,330],[995,410],[955,450],[905,410],[930,360],[895,260],[915,140]];
 const EDGE_S=[[470,220],[505,300],[560,360],[640,408],[720,428],[820,430],[905,410]],EDGE_E=[[995,410],[1080,440],[1170,452],[1290,466],[1420,488],[1610,500]];
 const WP=[[648,470],[720,486],[820,492],[905,470],[955,496],[995,468],[1080,498],[1170,510],[1290,524],[1420,546],[1610,558],[1610,910],[700,910],[688,800],[674,680],[660,570]];
 const inW=(x,y)=>rpwIn(WP,x,y);
 /* forest valley base */
 let q=g.createLinearGradient(0,0,0,900);q.addColorStop(0,'#1f4a2c');q.addColorStop(.5,'#2c6a38');q.addColorStop(1,'#245a30');g.fillStyle=q;g.fillRect(0,0,1600,900);
 for(let i=0;i<260;i++){const x=rpwR(i*3+1)*1600,y=rpwR(i*3+2)*900,r=30+rpwR(i*3+3)*80;g.globalAlpha=.4;g.fillStyle=['#357841','#245a30','#1a4527','#3d8a46'][i%4];g.beginPath();g.ellipse(x,y,r,r*.5,0,0,RPW_PI*2);g.fill()}g.globalAlpha=1;
 for(const [x,y,rx,ry] of[[330,610,110,40],[150,470,70,26],[520,650,100,36],[420,530,80,30],[250,700,120,36],[80,380,60,22]]){g.fillStyle='#4f9e4e';g.globalAlpha=.5;g.beginPath();g.ellipse(x,y,rx,ry,0,0,RPW_PI*2);g.fill();g.globalAlpha=1}
 for(let i=0;i<260;i++){const x=rpwR(i+3000)*1600,y=300+rpwR(i+3300)*600;if(inW(x,y))continue;g.fillStyle=['#ffe46a','#ffffff','#ff9ad8','#b4a0ff'][i%4];g.globalAlpha=.75;g.fillRect(x,y,2,2)}g.globalAlpha=1;
 /* the Wonderland lowland: twilight ground feathered into the forest, aurora light, crystal veins, ponds, star dust */
 {rpwPoly(g,WP);q=g.createLinearGradient(640,0,780,0);q.addColorStop(0,'rgba(34,30,92,0)');q.addColorStop(1,'rgba(34,30,92,1)');g.fillStyle=q;g.fill();
  g.save();rpwPoly(g,WP);g.clip();q=g.createLinearGradient(0,480,0,900);q.addColorStop(0,open?'rgba(70,60,160,.55)':'rgba(40,24,80,.6)');q.addColorStop(1,'rgba(20,16,60,.2)');g.fillStyle=q;g.fillRect(640,460,980,460);
  for(let i=0;i<70;i++){const x=700+rpwR(i+4000)*900,y=480+rpwR(i+4040)*420,r=24+rpwR(i+4080)*56;g.globalAlpha=.45;g.fillStyle=['#3a3a8a','#2a2a6e','#4a3a9a','#26407a'][i%4];g.beginPath();g.ellipse(x,y,r,r*.45,0,0,RPW_PI*2);g.fill()}
  g.globalCompositeOperation='lighter';for(let i=0;i<9;i++){const x=700+rpwR(i+4100)*520,y=520+rpwR(i+4120)*220,r=90+rpwR(i+4140)*90;g.globalAlpha=open?.2:.08;g.drawImage(rpwGlow(['90,200,255','255,110,220','150,120,255'][i%3],80),x-r,y-r*.6,r*2,r*1.2)}
  g.globalAlpha=1;for(let i=0;i<16;i++){let x=720+rpwR(i+4200)*500,y=520+rpwR(i+4230)*220;const col=['120,230,255','255,140,240','180,150,255'][i%3];g.beginPath();g.moveTo(x,y);for(let k=0;k<5;k++){x+=(rpwR(i*13+k+9)-.5)*30;y+=(rpwR(i*11+k+5)-.5)*14;g.lineTo(x,y)}
   g.strokeStyle=`rgba(${col},.2)`;g.lineWidth=6;g.stroke();g.strokeStyle=`rgba(${col},.5)`;g.lineWidth=2;g.stroke()}
  g.globalCompositeOperation='source-over';for(let i=0;i<220;i++){const x=680+rpwR(i+4300)*940,y=480+rpwR(i+4360)*420;if(!inW(x,y))continue;g.fillStyle=['#ffffff','#ffd0fa','#a8f0ff','#fff2a8'][i%4];g.globalAlpha=.6;g.fillRect(x,y,1.8,1.8)}g.globalAlpha=1;g.restore()}
 /* rivers: Mossgate river (blue) and the starlight stream from the gorge (violet) */
 const R1=rpwSpl([[468,292],[500,380],[545,440],[592,505],[622,585],[640,670],[650,760],[658,910]],8);
 const R2=rpwSpl([[952,505],[915,535],[866,566],[822,610],[798,680],[786,760],[780,910]],8);
 const RV=[[R1,18,56,0],[R2,14,30,1]];
 for(const [L,w0,w1,s] of RV){rpwPoly(g,rpwRibbon(L,w0+14,w1+16));g.fillStyle=s?'#3a2e6a':'#6a5a44';g.fill();rpwOut(g,2.4)}
 for(const [L,w0,w1,s] of RV){rpwPoly(g,rpwRibbon(L,w0+5,w1+6));g.fillStyle=s?'#5a4e9a':'#8a7a60';g.fill()}
 for(const [L,w0,w1,s] of RV){rpwPoly(g,rpwRibbon(L,w0,w1));q=g.createLinearGradient(400,300,1000,900);if(s){q.addColorStop(0,'#8a5af0');q.addColorStop(1,'#4a2ab8')}else{q.addColorStop(0,'#3a8ad0');q.addColorStop(1,'#2160a8')}g.fillStyle=q;g.fill()}
 for(const [L,w0,w1,s] of RV){rpwPoly(g,rpwRibbon(L,w0*.45,w1*.45,-.25));g.fillStyle=s?'#d0a8ff':'#62b4f0';g.globalAlpha=.5;g.fill();g.globalAlpha=1;
  g.strokeStyle='rgba(255,255,255,.55)';g.lineWidth=1.6;g.beginPath();for(let i=4;i<L.length-2;i+=5){const p=L[i],w=w0+(w1-w0)*i/L.length,o=(rpwR(i+L.length)-.5)*w*.6;g.moveTo(p[0]+o-5,p[1]);g.quadraticCurveTo(p[0]+o,p[1]-3,p[0]+o+5,p[1])}g.stroke();
  if(s)for(let i=2;i<L.length;i+=3){const p=L[i],o=(rpwR(i+9)-.5)*w1*.5;g.fillStyle=i%2?'#ffffff':'#ffd8ff';rpwStar(g,p[0]+o,p[1],i%9?1.6:3,4);g.fill()}
  W.riv.push({L,w0,w1,s})}
 for(const [L,w0,w1] of RV){g.save();rpwPoly(g,rpwRibbon(L,w0+5,w1+6));g.clip();rpwPoly(g,rpwRibbon(L,w0,w1));g.strokeStyle=RPWO;g.lineWidth=2.2;g.stroke();g.restore()}
 /* sky inside the highlands, far ranges */
 g.save();g.beginPath();for(const P of[S,GORGE,E]){g.moveTo(P[0][0],P[0][1]);for(const p of P)g.lineTo(p[0],p[1]);g.closePath()}g.clip();
 q=g.createLinearGradient(440,0,1600,0);q.addColorStop(0,'#232a5c');q.addColorStop(.42,'#2c2e66');q.addColorStop(.58,'#3a1a3a');q.addColorStop(1,'#4a1424');g.fillStyle=q;g.fillRect(440,-10,1170,230);
 for(let i=0;i<40;i++){g.fillStyle='rgba(255,255,255,.6)';g.fillRect(470+rpwR(i+300)*480,rpwR(i+330)*70,1.6,1.6)}
 for(const [ax,ay,bl,br,by,s] of[[470,30,420,560,190,1],[566,-10,480,660,190,2],[680,10,600,770,186,3],[790,-30,700,880,190,12],[890,20,820,960,196,13]])rpwPeak(g,ax,ay,bl,br,by,'far',s);
 for(const [ax,ay,bl,br,by,s] of[[1010,20,930,1100,210,4],[1100,40,1040,1160,200,14],[1320,0,1220,1440,230,5],[1500,30,1400,1620,240,6]])rpwPeak(g,ax,ay,bl,br,by,'ember',s);
 g.restore();
 g.save();g.beginPath();g.rect(880,150,140,320);g.clip();rpwPoly(g,GORGE);q=g.createLinearGradient(0,150,0,460);q.addColorStop(0,'rgba(20,16,48,0)');q.addColorStop(.18,'#141030');q.addColorStop(1,'#2a2a54');g.fillStyle=q;g.fill();g.restore();
 g.save();rpwPoly(g,GORGE);g.clip();for(let i=0;i<9;i++){g.globalAlpha=.22;g.drawImage(rpwGlow('200,210,255',60),905+rpwR(i)*60-60,140+i*34-40,120,80)}g.globalAlpha=1;g.restore();
 /* plateau surfaces */
 g.save();g.beginPath();g.rect(0,186,1600,800);g.clip();rpwPoly(g,S);q=g.createLinearGradient(0,186,0,440);q.addColorStop(0,'#c4d4ea');q.addColorStop(1,'#eef5fc');g.fillStyle=q;g.fill();g.clip();
 for(let i=0;i<140;i++){const x=440+rpwR(i+500)*500,y=170+rpwR(i+540)*280,r=20+rpwR(i+580)*50;g.fillStyle=i%3?'#c2d4ea':'#ffffff';g.globalAlpha=.55;g.beginPath();g.ellipse(x,y,r,r*.4,0,0,RPW_PI*2);g.fill()}g.globalAlpha=1;
 g.strokeStyle='rgba(120,150,200,.45)';g.lineWidth=2;g.beginPath();for(let i=0;i<34;i++){const x=450+rpwR(i+620)*470,y=230+rpwR(i+640)*200;g.moveTo(x-22,y);g.quadraticCurveTo(x,y-7,x+22,y)}g.stroke();g.restore();
 g.save();g.beginPath();g.rect(0,196,1600,800);g.clip();rpwPoly(g,E);q=g.createLinearGradient(0,196,0,500);q.addColorStop(0,'#22141c');q.addColorStop(1,'#3e2428');g.fillStyle=q;g.fill();g.clip();
 for(let i=0;i<140;i++){const x=960+rpwR(i+700)*650,y=150+rpwR(i+740)*360,r=24+rpwR(i+780)*60;g.fillStyle=['#4a2a2e','#2a161c','#3a2026'][i%3];g.globalAlpha=.6;g.beginPath();g.ellipse(x,y,r,r*.45,0,0,RPW_PI*2);g.fill()}g.globalAlpha=1;
 g.globalCompositeOperation='lighter';for(let i=0;i<40;i++){const x=980+rpwR(i+900)*620,y=230+rpwR(i+930)*240;g.strokeStyle='rgba(255,110,30,.55)';g.lineWidth=2;g.beginPath();g.moveTo(x,y);let px=x,py=y;for(let k=0;k<4;k++){px+=(rpwR(i*9+k)-.5)*40;py+=(rpwR(i*7+k+3)-.5)*20;g.lineTo(px,py)}g.stroke()}
 g.globalCompositeOperation='source-over';g.restore();
 for(const [ax,ay,bl,br,by,s] of[[512,96,462,610,240,7],[612,-34,505,745,226,8],[812,6,712,925,232,9],[730,120,680,800,240,10]])rpwPeak(g,ax,ay,bl,br,by,'snow',s);
 /* the volcano and its lava */
 {const V=()=>{g.beginPath();g.moveTo(1030,268);g.quadraticCurveTo(1120,210,1158,60);g.lineTo(1222,60);g.quadraticCurveTo(1262,210,1384,268);g.quadraticCurveTo(1207,290,1030,268);g.closePath()};
  V();q=g.createLinearGradient(1030,0,1384,0);q.addColorStop(0,'#74505c');q.addColorStop(.4,'#563440');q.addColorStop(.55,'#3a2028');q.addColorStop(1,'#22121a');g.fillStyle=q;g.fill();g.save();V();g.clip();
  for(let i=0;i<16;i++){const u=i/15,x0=1162+u*56,x1=1030+u*354;g.strokeStyle=i%2?'rgba(18,8,31,.35)':'rgba(255,255,255,.07)';g.lineWidth=i%2?1.6:3;g.beginPath();g.moveTo(x0,64);g.quadraticCurveTo(x0+(x1-x0)*.25,180,x1,290);g.stroke()}
  q=g.createLinearGradient(0,60,0,280);q.addColorStop(0,'rgba(255,120,50,.25)');q.addColorStop(.4,'rgba(255,120,50,0)');g.fillStyle=q;g.fillRect(1030,60,360,230);g.restore();V();rpwOut(g,2.8);
  g.fillStyle='#2a0c10';g.beginPath();g.ellipse(1190,62,34,9,0,0,RPW_PI*2);g.fill();rpwOut(g,2.4);g.fillStyle='#ff7a1a';g.beginPath();g.ellipse(1190,63,26,5.5,0,0,RPW_PI*2);g.fill();g.fillStyle='#ffd27a';g.beginPath();g.ellipse(1186,63,14,2.6,0,0,RPW_PI*2);g.fill();W.crater=[1190,60]}
 const LV=[rpwSpl([[1198,66],[1222,120],[1206,170],[1240,215],[1228,262],[1262,320],[1240,380],[1226,420]],7),rpwSpl([[1174,66],[1150,110],[1160,150],[1110,166],[1060,178],[1010,194],[980,214]],7),
  rpwSpl([[1214,64],[1286,120],[1310,180],[1388,240],[1418,320],[1470,400],[1500,480]],7)];
 g.fillStyle='#1a0a0e';g.beginPath();g.ellipse(1352,420,66,22,0,0,RPW_PI*2);g.fill();rpwOut(g,2.4);g.fillStyle='#ff8a2a';g.beginPath();g.ellipse(1352,421,56,16,0,0,RPW_PI*2);g.fill();g.fillStyle='#ffd27a';g.beginPath();g.ellipse(1340,418,30,5,0,0,RPW_PI*2);g.fill();
 g.fillStyle='#1a0a0e';g.beginPath();g.ellipse(1226,426,22,8,0,0,RPW_PI*2);g.fill();rpwOut(g,2);g.fillStyle='#ff8a2a';g.beginPath();g.ellipse(1226,426,16,5,0,0,RPW_PI*2);g.fill();
 for(const L of LV){rpwPoly(g,rpwRibbon(L,11,22));g.fillStyle='#1a0a0e';g.fill();rpwOut(g,2);rpwPoly(g,rpwRibbon(L,7,15));q=g.createLinearGradient(0,60,0,520);q.addColorStop(0,'#ffd27a');q.addColorStop(.5,'#ff8a2a');q.addColorStop(1,'#e8461a');g.fillStyle=q;g.fill();
  rpwPoly(g,rpwRibbon(L,2,5,-.2));g.fillStyle='#fff0b0';g.globalAlpha=.7;g.fill();g.globalAlpha=1;W.lava.push(L);
  g.save();g.globalCompositeOperation='lighter';for(let i=0;i<L.length;i+=9){g.globalAlpha=.32;g.drawImage(rpwGlow('255,100,30',30),L[i][0]-30,L[i][1]-30)}g.restore()}
 g.save();g.globalCompositeOperation='lighter';g.globalAlpha=.8;g.drawImage(rpwGlow('255,120,40',110),1080,-50,220,220);g.restore();
 /* frozen lake */
 g.fillStyle='#8aa8cc';g.beginPath();g.ellipse(790,372,58,19,0,0,RPW_PI*2);g.fill();rpwOut(g,2.4);g.fillStyle='#bfe8ff';g.beginPath();g.ellipse(790,374,52,15,0,0,RPW_PI*2);g.fill();
 g.strokeStyle='#ffffff';g.lineWidth=1.6;g.beginPath();g.moveTo(758,370);g.lineTo(776,376);g.lineTo(788,368);g.moveTo(798,378);g.lineTo(816,372);g.lineTo(828,376);g.stroke();
 /* cliffs */
 rpwCliff(g,EDGE_S,64,['#b0bed6','#8492b0','#64709a','#4e5a84'],11,true);
 rpwCliff(g,EDGE_E,60,['#5e444e','#42303a','#2a1c22','#1e1218'],21,false);
 rpwCliff(g,[[905,410],[955,450],[995,410]],48,['#4a4a6a','#34344e','#24243a'],31,false);
 g.save();g.globalCompositeOperation='lighter';g.strokeStyle='rgba(255,110,30,.6)';g.lineWidth=2;g.beginPath();for(let i=0;i<6;i++){const x=1030+i*36+rpwR(i+70)*20,y=432+(x-1000)*.12+14;g.moveTo(x,y);g.lineTo(x+4,y+14);g.lineTo(x-2,y+30)}g.stroke();g.restore();
 const fall=(x,y0,y1,w,c0,c1,k)=>{q=g.createLinearGradient(0,y0,0,y1);q.addColorStop(0,c0);q.addColorStop(1,c1);g.fillStyle=q;g.beginPath();g.moveTo(x-w/2,y0);g.lineTo(x+w/2,y0);g.lineTo(x+w/2+3,y1);g.lineTo(x-w/2-3,y1);g.closePath();g.fill();
  if(k===2){g.save();g.clip();const C=['#ff8ac8','#ffc86a','#fff08a','#8af0a8','#7ad8ff','#a88aff'];for(let j=0;j<6;j++){g.fillStyle=C[j];g.fillRect(x-w/2-3+j*(w+6)/6,y0,(w+6)/6+.5,y1-y0)}g.restore();g.beginPath();g.moveTo(x-w/2,y0);g.lineTo(x+w/2,y0);g.lineTo(x+w/2+3,y1);g.lineTo(x-w/2-3,y1);g.closePath()}
  rpwOut(g,2.2);g.strokeStyle='rgba(255,255,255,.75)';g.lineWidth=1.4;g.beginPath();for(let j=-1;j<=1;j++){g.moveTo(x+j*w*.28,y0+3);g.lineTo(x+j*w*.3,y1-3)}g.stroke();
  for(let j=0;j<5;j++){g.fillStyle='#ffffff';g.beginPath();g.arc(x+(j-2)*w*.3,y1+(j%2)*3,4+rpwR(j+x)*3,0,RPW_PI*2);g.fill()}W.falls.push([x,y0,y1,w,k===2?2:0])};
 fall(474,236,296,16,'#a8dcff','#3a8ad0');fall(954,454,506,18,'#d8c8ff','#7a5ae0',open?2:0);
 /* the trail: forest edge -> Mossgate -> Frostfang -> Ember Crown -> down the ember cliff -> the Wonderland palace */
 const nd=RPWORLD.nodes,sc=RPWORLD.scale,gate=k=>[nd[k].x+(RPW_GX-155)*sc[k],nd[k].y+(RPW_GY-512)*sc[k]];const gm=gate('moss'),gf=gate('frost'),ge=gate('ember'),gw=gate('wonder');
 const TA=rpwSpl([[-20,598],[60,592],[130,572],[188,540],[222,520],gm],6),TB=rpwSpl([[318,506],[372,486],[424,470],[478,446],[520,428],[560,418],[584,400],[590,372],[606,346],[626,318],[646,292],gf],6),
  TC=rpwSpl([[736,272],[786,284],[836,276],[880,262],[930,254],[972,256],[1010,266],[1046,264],ge],6),TD=rpwSpl([[1066,300],[1040,330],[1016,372],[1006,408],[1004,440],[1000,472],[986,506],[966,546],[960,584],[984,610],[1016,618],gw],6);
 W.trail=[TA,TB,TC,TD];
 for(const T of W.trail){g.beginPath();g.moveTo(T[0][0],T[0][1]);for(const p of T)g.lineTo(p[0],p[1]);g.strokeStyle='rgba(18,8,31,.3)';g.lineWidth=22;g.stroke();g.strokeStyle='#8a7656';g.lineWidth=17;g.stroke();g.strokeStyle='#a48e6a';g.lineWidth=9;g.stroke()}
 const stairs=(x0,x1,y0,y1,col)=>{g.fillStyle=col;g.beginPath();g.moveTo(x0-4,y1);g.lineTo(x1+4,y1);g.lineTo(x1,y0);g.lineTo(x0,y0);g.closePath();g.fill();rpwOut(g,2);g.strokeStyle='rgba(18,8,31,.55)';g.lineWidth=1.4;g.beginPath();for(let y=y0+7;y<y1-1;y+=7){g.moveTo(x0-(y-y0)/(y1-y0)*4,y);g.lineTo(x1+(y-y0)/(y1-y0)*4,y)}g.stroke()};
 stairs(584,604,360,436,'#b8c4d8');stairs(994,1014,410,474,'#6a5058');
 /* scatter by depth: forest, snow, ember, wonder flora, and the four castles */
 const items=[],keep=(x,y)=>{for(const k in nd){const n=nd[k],s=sc[k];if(x>n.x-150*s-14&&x<n.x+150*s+14&&y>n.y-470*s&&y<n.y+60)return false}return true};
 const onTrail=(x,y,d)=>W.trail.some(T=>rpwNear(T,x,y,d)),onRiver=(x,y)=>W.riv.some(r=>rpwNear(r.L,x,y,r.w1*.5+16)),cliffS=rpwSpl(EDGE_S.concat([[955,450]],EDGE_E),12);
 for(let i=0;i<3600&&items.length<1020;i++){const x=rpwR(i*5+11)*1640-20,y=rpwR(i*5+12)*940-10;if(!keep(x,y)||onTrail(x,y,18)||onRiver(x,y))continue;
  if(rpwIn(GORGE,x,y))continue;const inS=rpwIn(S,x,y),inE=rpwIn(E,x,y);
  if(inS){if(y<238||rpwR(i+7)<.25||(x>724&&x<856&&y>346&&y<398))continue;items.push({k:rpwR(i+9)<.9?'snow':'srock',x,y,h:20+rpwR(i+8)*20})}
  else if(inE){if(y<236||y<282&&x>1000&&x<1420||W.lava.some(L=>rpwNear(L,x,y,24))||(x>1270&&x<1430&&y>394&&y<446)||rpwR(i+7)<.45)continue;const r=rpwR(i+9);items.push({k:r<.62?'dead':r<.85?'erock':'shard',x,y,h:18+rpwR(i+8)*16})}
  else{if(rpwNear(cliffS,x,y-30,34))continue;let near=false;for(const P of[S,E])if(rpwIn(P,x,y-66))near=true;if(near)continue;
   if(inW(x,y)&&x>690){if(rpwR(i+7)<.35)continue;const big=rpwR(i+21)<.1?1.7:1;items.push({k:'won',x,y,h:(30+rpwR(i+8)*18)*big*(y>620?1.15:1),i});continue}
   const big=y>600?1.3:y>480?1.12:1,r=rpwR(i+9),edge=x>600&&inW(x,y);items.push({k:edge&&r<.4?'won':r<.8?'pine':r<.95?'oak':'rock',x,y,h:(24+rpwR(i+8)*18)*big,i})}}
 for(const k in nd)items.push({k:'castle',id:k,x:nd[k].x,y:nd[k].y});
 /* floating-island shadows on the ground (open) */
 const ISL=[[800,498,58,0],[724,600,44,1],[1176,474,28,2]];
 if(open)for(const [x,y,r] of ISL){g.fillStyle='rgba(10,6,40,.3)';g.beginPath();g.ellipse(x+10,y+118,r*.9,r*.22,0,0,RPW_PI*2);g.fill()}
 items.sort((a,b)=>a.y-b.y);const tc=['#1b4d2e','#256b3a','#123821','#2e7a3e'],oc=['#3a8a3a','#2f7a34','#4a9a40'];
 for(const it of items){const i=(it.x*7+it.y*13)|0;
  if(it.k==='pine')rpwPine(g,it.x,it.y,it.h,tc[i%4],'#5aa85e',false);
  else if(it.k==='oak')rpwOak(g,it.x,it.y,it.h*.9,oc[i%3],'#8ad06a');
  else if(it.k==='won'){if(!open)rpwPine(g,it.x,it.y,it.h*.8,['#2a2058','#33246a','#221a48'][i%3],'#8a6ad0',false);else if(typeof rpwWProp==='function')rpwWProp(g,it.x,it.y,it.h,it.i,false)}
  else if(it.k==='snow')rpwPine(g,it.x,it.y,it.h,['#1f4a4a','#2a5e5a','#163a3c'][i%3],'#eaf6ff',true);
  else if(it.k==='dead')rpwDead(g,it.x,it.y,it.h);
  else if(it.k==='shard'){g.fillStyle='#1a1020';for(const [dx,h,a] of[[-5,it.h*.9,-.3],[0,it.h*1.3,0],[6,it.h*.8,.35]]){g.save();g.translate(it.x+dx,it.y);g.rotate(a);g.beginPath();g.moveTo(-4,0);g.lineTo(0,-h);g.lineTo(4,0);g.closePath();g.fill();rpwOut(g,1.6);g.restore()}}
  else if(it.k==='srock'){rpwBoulder(g,RPW_PAL.frost,it.x,it.y,it.h*.9,it.h*.6,i);g.fillStyle='#f6fbff';g.beginPath();g.ellipse(it.x-2,it.y-it.h*.52,it.h*.3,it.h*.1+1,0,0,RPW_PI*2);g.fill();rpwOut(g,1.4)}
  else if(it.k==='rock'||it.k==='erock')rpwBoulder(g,it.k==='rock'?RPW_PAL.moss:RPW_PAL.ember,it.x,it.y,it.h*.9,it.h*.6,i);
  else{if(it.id==='wonder'&&!open)continue;const A=rpCastleArt(it.id),s=sc[it.id],x0=it.x-155*s,y0=it.y-512*s;g.fillStyle='rgba(0,0,0,.32)';g.beginPath();g.ellipse(it.x+10,it.y-4,150*s,24*s,0,0,RPW_PI*2);g.fill();
   if(it.id==='wonder'){g.save();g.globalCompositeOperation='lighter';g.globalAlpha=.5;g.drawImage(rpwGlow('200,140,255',90),it.x-110,it.y-200,220,240);g.restore()}
   g.imageSmoothingQuality='high';g.drawImage(A.c2,x0,y0,A.w*s,A.h*s);it.x0=x0;it.y0=y0;W.cast.push(it)}}
 /* bridges and trail dots */
 rpwPlankBridge(g,516,442,566,410,16);rpwPlankBridge(g,888,260,982,258,14);
 for(const T of W.trail){let acc=0;for(let i=1;i<T.length;i++){acc+=Math.hypot(T[i][0]-T[i-1][0],T[i][1]-T[i-1][1]);if(acc>=20){acc=0;const p=T[i];g.fillStyle='#f4e2b8';g.beginPath();g.ellipse(p[0],p[1],5,4,0,0,RPW_PI*2);g.fill();rpwOut(g,1.8)}}}
 /* floating islands with crystal flora and rainbow falls (open) */
 if(open)for(const [x,y,r,k] of ISL){const top=()=>{g.beginPath();g.ellipse(x,y,r,r*.3,0,0,RPW_PI*2)};
  g.beginPath();g.moveTo(x-r,y);g.quadraticCurveTo(x-r*.7,y+r*.5,x-r*.2,y+r*.95);g.lineTo(x,y+r*1.2);g.lineTo(x+r*.25,y+r*.9);g.quadraticCurveTo(x+r*.8,y+r*.45,x+r,y);g.closePath();
  q=g.createLinearGradient(x-r,0,x+r,0);q.addColorStop(0,'#8a7ac8');q.addColorStop(.5,'#5a4a9a');q.addColorStop(1,'#2e2468');g.fillStyle=q;g.fill();rpwOut(g,2.4);
  g.strokeStyle='rgba(18,8,31,.4)';g.lineWidth=1.3;g.beginPath();g.moveTo(x-r*.5,y+r*.2);g.lineTo(x-r*.2,y+r*.8);g.moveTo(x+r*.3,y+r*.2);g.lineTo(x+r*.1,y+r*.7);g.stroke();
  for(const [dx,h,a,c] of[[-.3,.4,-.2,0],[.1,.32,.25,1]])rpwCrystal(g,x+dx*r,y+r*(.75+dx*.2),-h*r,a+RPW_PI,h*r*.3,RPW_CRY[c]);
  top();g.fillStyle='#3a8a6a';g.fill();rpwOut(g,2.2);top();g.save();g.clip();g.fillStyle='#4ab07a';g.beginPath();g.ellipse(x-r*.2,y-r*.06,r*.8,r*.2,0,0,RPW_PI*2);g.fill();g.restore();
  if(k===0){fall(x+r*.82,y+4,y+112,12,'#ffffff','#ffffff',2);g.fillStyle='#7a5ad8';g.beginPath();g.ellipse(x+r*.82,y+120,26,7,0,0,RPW_PI*2);g.fill();rpwOut(g,2);g.fillStyle='#ffd0fa';g.beginPath();g.ellipse(x+r*.82,y+120,18,4,0,0,RPW_PI*2);g.fill()}
  if(k===1){fall(x-r*.78,y+4,y+120,10,'#ffffff','#ffffff',2)}
  if(typeof rpwWProp==='function'){if(k===0){rpwWProp(g,x-r*.3,y+2,46,0,false);rpwWProp(g,x+r*.3,y+4,34,1,false)}else if(k===1){rpwWProp(g,x+r*.1,y+2,40,3,false)}else rpwWProp(g,x,y+2,26,4,false)}
  W.isl.push([x,y,r])}
 /* aurora veils over the Wonderland (open) */
 if(open){g.save();g.globalCompositeOperation='lighter';for(let k=0;k<3;k++){g.globalAlpha=.12;g.strokeStyle=['#5affbe','#ff7ae0','#7ab8ff'][k];g.lineWidth=14-k*3;g.beginPath();for(let x=680;x<=1240;x+=12){const y=446+k*10+Math.sin(x*.012+k*1.3)*16;x===680?g.moveTo(x,y):g.lineTo(x,y)}g.stroke()}g.restore()}
 /* clouds and mist */
 rpwCloud(g,446,322,18,'#e6e8f6','#b4b6d6');rpwCloud(g,926,402,16,'#cfcce4','#9a96bc');rpwCloud(g,1166,8,20,'#4a3a48','#2e2230');rpwCloud(g,1250,-6,16,'#3e3040','#281c2a');rpwCloud(g,940,70,14,'#c8c6e0','#8e8cb4');
 for(const [x,y,r,a] of[[930,220,90,.35],[955,470,70,.35],[480,330,70,.3],[640,190,110,.14]]){g.globalAlpha=a;g.drawImage(rpwGlow('230,236,255',r),x-r,y-r*.6,r*2,r*1.2)}g.globalAlpha=1;
 /* locked: the shroud - purple mist, clouds and a glowing question mark */
 if(!open){g.save();rpwPoly(g,WP);g.clip();for(let i=0;i<34;i++){const x=700+rpwR(i+5000)*560,y=490+rpwR(i+5040)*260,r=70+rpwR(i+5080)*80;g.globalAlpha=.42;g.drawImage(rpwGlow(i%3?'90,60,150':'140,90,200',r),x-r,y-r*.7,r*2,r*1.4)}
  g.globalAlpha=.55;g.fillStyle='#2a1a4a';g.fillRect(640,460,980,460);g.restore();g.globalAlpha=1;
  for(const [x,y,s] of[[700,520,20],[780,500,24],[870,486,22],[960,502,26],[1060,512,24],[1150,524,26],[1220,540,22],[730,620,18],[1190,640,20],[760,720,22],[1120,730,24]])rpwCloud(g,x,y,s,'#6a5296','#4a3676',.96);
  g.save();g.globalCompositeOperation='lighter';g.globalAlpha=.9;g.drawImage(rpwGlow('190,120,255',120),nd.wonder.x-130,nd.wonder.y-290,260,240);g.restore();
  const qy=nd.wonder.y-118;g.font='bold 120px Georgia, "Times New Roman", serif';g.textAlign='center';g.textBaseline='alphabetic';
  g.lineWidth=12;g.strokeStyle=RPWO;g.strokeText('?',nd.wonder.x,qy);q=g.createLinearGradient(0,qy-92,0,qy);q.addColorStop(0,'#fff0ff');q.addColorStop(.5,'#e0a8ff');q.addColorStop(1,'#9a5ae8');g.fillStyle=q;g.fillText('?',nd.wonder.x,qy);
  g.fillStyle='rgba(255,255,255,.55)';g.beginPath();g.ellipse(nd.wonder.x-14,qy-70,8,4,-.6,0,RPW_PI*2);g.fill();W.q=[nd.wonder.x,qy-44]}
 /* vignette: calm, darker title corner and edges */
 q=g.createRadialGradient(170,130,40,170,130,560);q.addColorStop(0,'rgba(10,6,24,.66)');q.addColorStop(1,'rgba(10,6,24,0)');g.fillStyle=q;g.fillRect(0,0,800,700);
 q=g.createLinearGradient(0,640,0,900);q.addColorStop(0,'rgba(10,6,24,0)');q.addColorStop(1,'rgba(10,6,24,.55)');g.fillStyle=q;g.fillRect(0,640,1600,260);
 q=g.createLinearGradient(1100,0,1600,0);q.addColorStop(0,'rgba(10,6,24,0)');q.addColorStop(1,'rgba(10,6,24,.4)');g.fillStyle=q;g.fillRect(1100,0,500,900);
 W.mist=rpwGlow('230,236,255',80);W.pmist=rpwGlow('150,100,220',80);W.lg=rpwGlow('255,110,30',30);RPWW_C[key]=W;return c}
function rpWorldLive(g,t,open){if(open===undefined)open=rpwWOpen();open=!!open;const W=RPWW_C[open?'o':'l'];if(!W){rpWorldArt(open);return}g.save();
 /* river shimmer (Mossgate river) and starlight twinkles (the stream) */
 g.strokeStyle='rgba(255,255,255,.5)';g.lineWidth=1.6;g.beginPath();
 for(const r of W.riv){if(r.s)continue;const L=r.L,n=L.length;for(let i=0;i<16;i++){const u=(t*.035+i/16+rpwR(i+n)*.05)%1,j=Math.min(n-2,(u*n)|0),p=L[j],q=L[j+1],w=r.w0+(r.w1-r.w0)*j/n,o=(rpwR(i*3+n)-.5)*w*.7,dx=q[0]-p[0],dy=q[1]-p[1],m=Math.hypot(dx,dy)||1;
  g.moveTo(p[0]-dy/m*o,p[1]+dx/m*o);g.lineTo(p[0]-dy/m*o+dx/m*8,p[1]+dx/m*o+dy/m*8)}}g.stroke();
 if(open){const r=W.riv.find(x=>x.s);if(r){g.fillStyle='#ffffff';g.globalAlpha=.9;g.beginPath();for(let i=0;i<12;i++){const u=(t*.4+i*.29)%1;if(u>.45)continue;const a=Math.sin(u/.45*RPW_PI),s=a*3.4,p=r.L[(i*7+3)%r.L.length],x=p[0]+(rpwR(i+3)-.5)*14,y=p[1];
   g.moveTo(x,y-s*1.5);g.lineTo(x+s*.3,y-s*.3);g.lineTo(x+s*1.5,y);g.lineTo(x+s*.3,y+s*.3);g.lineTo(x,y+s*1.5);g.lineTo(x-s*.3,y+s*.3);g.lineTo(x-s*1.5,y);g.lineTo(x-s*.3,y-s*.3);g.closePath()}g.fill()}}
 g.globalAlpha=.75;g.fillStyle='#ffffff';g.beginPath();for(const f of W.falls){for(let k=0;k<4;k++){const u=(t*.9+k/4)%1;g.rect(f[0]-f[3]*.3+k*f[3]*.18,f[1]+u*(f[2]-f[1]-4),2,6)}}g.fill();g.globalAlpha=1;
 /* lava */
 g.globalCompositeOperation='lighter';const lg=W.lg;
 for(let li=0;li<W.lava.length;li++){const L=W.lava[li];for(let i=10;i<L.length;i+=40){g.globalAlpha=.22+.16*Math.sin(t*2.4+i*.3+li);g.drawImage(lg,L[i][0]-30,L[i][1]-30)}}
 g.fillStyle='#fff0b0';g.globalAlpha=.6;g.beginPath();for(const L of W.lava)for(let i=0;i<6;i++){const u=(t*.06+i/6)%1,p=L[Math.min(L.length-1,(u*L.length)|0)];g.rect(p[0]-1.5,p[1]-1.5,3,3)}g.fill();
 g.globalAlpha=.35+.2*Math.sin(t*1.7);g.drawImage(rpwGlow('255,120,40',110),W.crater[0]-90,W.crater[1]-80,180,150);
 g.fillStyle='#ffb84a';g.globalAlpha=.6;g.beginPath();for(let i=0;i<12;i++){const u=(t*.07+rpwR(i+40))%1,x=990+rpwR(i+41)*560+Math.sin(t+i)*10,y=470-u*420;g.rect(x,y,2.2,2.2)}g.fill();
 /* Wonderland: aurora shimmer and glowing islands (open), or the swirling shroud and the pulsing '?' (locked) */
 if(open){const av=typeof rpwAurora==='function'?rpwAurora():null;if(av)for(let k=0;k<2;k++){g.globalAlpha=.16+.1*Math.sin(t*.7+k*2.1);g.drawImage(av,640+k*150+Math.sin(t*.13+k)*40,420+k*22,520,60)}
  for(let i=0;i<W.isl.length;i++){const s=W.isl[i];g.globalAlpha=.2+.12*Math.sin(t*1.8+i*2);g.drawImage(rpwGlow('200,140,255',40),s[0]-s[2],s[1]-s[2]*.6,s[2]*2,s[2]*1.4)}}
 else{g.globalCompositeOperation='source-over';for(let k=0;k<3;k++){const a=t*.12*(k%2?-1:1)+k*2.1,x=960+Math.cos(a)*120*(1+k*.4),y=600+Math.sin(a)*40;g.globalAlpha=.32;g.drawImage(W.pmist,x-110,y-60,220,120)}
  g.globalCompositeOperation='lighter';g.globalAlpha=.3+.25*Math.sin(t*2);g.drawImage(rpwGlow('200,140,255',60),W.q[0]-70,W.q[1]-80,140,150)}
 g.globalCompositeOperation='source-over';
 for(let i=0;i<3;i++){const u=(t*.05+i/3)%1,r=8+u*26;g.globalAlpha=.32*(1-u);g.fillStyle='#3a2a36';g.beginPath();g.arc(W.crater[0]+Math.sin(u*4+i)*12+u*30,W.crater[1]-10-u*80,r,0,RPW_PI*2);g.fill()}
 g.fillStyle='#ffffff';for(let b=0;b<2;b++){g.globalAlpha=b?.45:.8;g.beginPath();for(let i=b;i<40;i+=2){const u=(t*(.03+rpwR(i+90)*.03)+rpwR(i+91))%1,x=452+rpwR(i+92)*470+Math.sin(t*.8+i)*14,y=-10+u*420;g.rect(x,y,b?1.6:2.4,b?1.6:2.4)}g.fill()}
 for(const [x,y,a,s] of[[930,250,.3,1],[955,470,.22,.9]]){g.globalAlpha=a*(.75+.25*Math.sin(t*.5+x));g.drawImage(W.mist,x-80*s+Math.sin(t*.25+y)*24,y-48*s,160*s,96*s)}
 g.globalAlpha=1;
 for(const it of W.cast){const s=RPWORLD.scale[it.id];g.save();g.translate(it.x0,it.y0);g.scale(s,s);rpCastleLive(g,it.id,0,0,t,1);g.restore()}
 g.restore()}
/* a small tile with the castle, for the 'next region' card */
function rpMapIcon(id,w,h){if(!RPW_PAL[id])id='moss';w=Math.round(w||88);h=Math.round(h||88);const k=id+w+'x'+h;if(RPWS[k])return RPWS[k];const c=rpwCv(w,h),g=c.getContext('2d'),A=rpCastleArt(id),r=Math.min(w,h)*.16;
 g.beginPath();g.roundRect(0,0,w,h,r);g.save();g.clip();const B={moss:['#4a8ac8','#2c6a38','#1d4a2c'],frost:['#5a7ab8','#dce8f4','#a9bfd6'],ember:['#3a1424','#3e2428','#1e1016'],wonder:['#3a2a8a','#2c2c70','#1a1646']}[id];
 let q=g.createLinearGradient(0,0,0,h);q.addColorStop(0,B[0]);q.addColorStop(.5,B[0]);q.addColorStop(.62,B[1]);q.addColorStop(1,B[2]);g.fillStyle=q;g.fillRect(0,0,w,h);
 if(id==='ember'){g.globalCompositeOperation='lighter';g.globalAlpha=.6;g.drawImage(rpwGlow('255,100,30',60),w*.2,h*.45,w*.9,h*.6);g.globalCompositeOperation='source-over';g.globalAlpha=1}
 if(id==='frost'||id==='wonder'){g.fillStyle='#ffffff';for(let i=0;i<14;i++)g.fillRect(rpwR(i)*w,rpwR(i+5)*h*.55,1.5,1.5)}
 if(id==='wonder'){g.globalCompositeOperation='lighter';g.globalAlpha=.55;g.drawImage(rpwGlow('200,120,255',60),-w*.1,h*.2,w*1.2,h*.9);g.globalAlpha=.3;g.strokeStyle='#5affbe';g.lineWidth=Math.max(2,h*.04);g.beginPath();for(let x=0;x<=w;x+=4){const y=h*.2+Math.sin(x/w*7)*h*.05;x?g.lineTo(x,y):g.moveTo(x,y)}g.stroke();g.globalCompositeOperation='source-over';g.globalAlpha=1}
 const s=Math.min(h*.98/500,w*1.2/300),x0=w/2-160*s,y0=h-512*s-h*.02;g.imageSmoothingQuality='high';g.drawImage(s<.35?A.c:A.c2,x0,y0,A.w*s,A.h*s);
 const tr=id==='ember'||id==='wonder'?null:id==='frost'?['#1f4a4a','#eaf6ff',true]:['#1b4d2e','#5aa85e',false];
 if(tr){const th=h*.24;rpwPine(g,w*.1,h*1.02,th,tr[0],tr[1],tr[2]);rpwPine(g,w*.9,h*1.04,th*1.1,tr[0],tr[1],tr[2])}else if(id==='wonder'&&typeof rpwWProp==='function'){rpwWProp(g,w*.1,h*1.02,h*.34,1,false);rpwWProp(g,w*.9,h*1.03,h*.3,4,false)}else{rpwDead(g,w*.1,h,h*.2);rpwDead(g,w*.92,h*1.02,h*.24)}
 q=g.createLinearGradient(0,0,0,h);q.addColorStop(0,'rgba(255,255,255,.12)');q.addColorStop(.4,'rgba(255,255,255,0)');g.fillStyle=q;g.fillRect(0,0,w,h);g.restore();
 g.beginPath();g.roundRect(1,1,w-2,h-2,r);g.strokeStyle='rgba(18,8,31,.85)';g.lineWidth=2;g.stroke();return RPWS[k]=c}
