import asyncio,os
from playwright.async_api import async_playwright
SET="""()=>{RS_ASK=false;P.xp=999999;P.gold=50000;syncPaths();P.petSt=2;P.pets={ember:{b:300},bramble:{b:120},antler:{b:10}};P.pet='ember';petNorm();
 for(const k in WP)P.own[k]=1;for(const k in AR)P.ownA[k]=1;P.weapon='rusty';P.path='knight';P.armor='rags';
 const wk=Object.keys(WP),ak=Object.keys(AR);window._W=wk.find(k=>WP[k].r==='Mythic'&&WP[k].p==='knight');window._M=wk.find(k=>WP[k].p==='mage'&&WP[k].r==='Epic');window._A=ak.find(k=>AR[k].r==='Legendary');
 P.lo={s:[{n:'Campaign',w:'rusty',a:'rags',p:'ember'},{},{}],sel:0,ask:0};P.upg=P.upg||{};window._U=JSON.stringify(P.upg);save();loadouts()}"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append('PE '+str(e)[:300]))
        await pg.goto('file://'+os.path.abspath('out.html'));await pg.wait_for_timeout(900);E=pg.evaluate
        # Armory shortcut
        await E("()=>{RS_ASK=false;armory()}");await pg.wait_for_timeout(300)
        await pg.click('#arlo');await pg.wait_for_timeout(500)
        print('armory shortcut',await E("()=>!!document.getElementById('lol')"))
        await E(SET);await pg.wait_for_timeout(900)
        print('tiles clip art',await E("()=>{P.lo.s[1]={n:'Endless',w:_W,a:_A,p:'ember'};save();loadouts();return [...document.querySelectorAll('.lotile')].every(t=>{const c=t.querySelector('canvas:not(.mybg)');if(!c)return true;const a=t.getBoundingClientRect(),b=c.getBoundingClientRect();return getComputedStyle(t).overflow==='hidden'&&b.top>=a.top-1&&b.bottom<=a.bottom+1&&b.left>=a.left-1&&b.right<=a.right+1})}"))
        await E(SET);await pg.wait_for_timeout(600)
        # open weapon picker by clicking the slot
        await pg.click('[data-pick="w"]');await pg.wait_for_timeout(600)
        print('picker',await E("()=>[LOX.pk,document.querySelectorAll('.loit').length,document.activeElement.className,document.querySelector('.loslw[data-slot=\"w\"]').classList.contains('ed'),!!document.querySelector('.lobest')]"))
        await pg.screenshot(path='shots/lp_picker.png')
        # hover compare (preview, not selected)
        await pg.hover(f'.loit[data-it="'+await E("()=>_W")+'"]');await pg.wait_for_timeout(500)
        print('compare',await E("()=>[LOX.pv&&LOX.pv.id===_W,document.querySelector('.locmo b').textContent,document.querySelectorAll('.locmr.up').length,document.getElementById('lostn').textContent,P.lo.s[0].w,document.getElementById('loput').disabled]"))
        await pg.screenshot(path='shots/lp_compare.png')
        # click selects, button puts
        await pg.click(f'.loit[data-it="'+await E("()=>_W")+'"]');await pg.wait_for_timeout(200)
        print('selected',await E("()=>[LOX.psel===_W,document.getElementById('loput').disabled,document.querySelector('#loput span').textContent]"))
        await pg.click('#loput');await pg.wait_for_timeout(150)
        await E("()=>document.querySelectorAll('.loslw.losnap .lotile, .lospk i').forEach(e=>e.getAnimations().forEach(a=>{a.pause();a.currentTime=180}))")
        await pg.screenshot(path='shots/lp_snap_mid.png')
        await E("()=>document.getAnimations().forEach(a=>{try{a.play()}catch(e){}})");await pg.wait_for_timeout(700)
        print('put',await E("()=>[P.lo.s[0].w===_W,LOX.pk,P.weapon,document.activeElement.dataset.pick]"))
        await pg.screenshot(path='shots/lp_put.png')
        # swap armor with double-click
        await pg.click('[data-pick="a"]');await pg.wait_for_timeout(500)
        await pg.dblclick(f'.loit[data-it="'+await E("()=>_A")+'"]');await pg.wait_for_timeout(700)
        print('dblclick swap',await E("()=>[P.lo.s[0].a===_A,LOX.pk]"))
        # keyboard: open companion picker with Enter, arrows, Enter puts
        await pg.focus('[data-pick="p"]');await pg.keyboard.press('Enter');await pg.wait_for_timeout(500)
        f0=await E("()=>document.activeElement.dataset.it")
        await pg.keyboard.press('ArrowRight');await pg.wait_for_timeout(150)
        f1=await E("()=>document.activeElement.dataset.it")
        await pg.keyboard.press('Enter');await pg.wait_for_timeout(600)
        print('keyboard pick',f0,f1,await E("()=>[P.lo.s[0].p,LOX.pk]"))
        # Esc layering: picker closes, page stays
        await pg.click('[data-pick="w"]');await pg.wait_for_timeout(400)
        await pg.click('#losob');await pg.wait_for_timeout(250)
        await pg.screenshot(path='shots/lp_sort.png')
        await pg.keyboard.press('ArrowDown');await pg.keyboard.press('Enter');await pg.wait_for_timeout(400)
        print('sorted',await E("()=>[P.lo.so&&P.lo.so.w,document.querySelector('#losob b').textContent]"))
        await pg.click('[data-pf="mage"]');await pg.wait_for_timeout(400)
        print('filter mage',await E("()=>[...document.querySelectorAll('.loit')].every(x=>WP[x.dataset.it].p==='mage')"))
        await pg.keyboard.press('Escape');await pg.wait_for_timeout(300)
        print('esc closes picker',await E("()=>[LOX.pk,!!document.getElementById('lol'),!!document.querySelector('.lolist')]"))
        # drag and drop: open picker, drag a mage weapon onto the weapon slot
        await pg.click('[data-pick="w"]');await pg.wait_for_timeout(400)
        await pg.click('[data-pf="mage"]');await pg.wait_for_timeout(300)
        await pg.drag_and_drop(f'.loit[data-it="'+await E("()=>_M")+'"]','.loslw[data-slot="w"]');await pg.wait_for_timeout(600)
        print('drag drop',await E("()=>[P.lo.s[0].w===_M,P.lo.s[0].c,LOX.pk]"))
        # unequip with the x and with Delete
        await pg.click('[data-rm="p"]');await pg.wait_for_timeout(400)
        print('remove x',await E("()=>[P.lo.s[0].p,!!document.querySelector('.loslw.lomt[data-slot=\"p\"]')]"))
        await pg.focus('[data-pick="a"]');await pg.keyboard.press('Delete');await pg.wait_for_timeout(300)
        print('remove del',await E("()=>[P.lo.s[0].a]"))
        await pg.screenshot(path='shots/lp_removed.png')
        # auto-fill best
        await pg.click('#loauto');await pg.wait_for_timeout(700)
        print('autofill',await E("()=>[P.lo.s[0].w,P.lo.s[0].a,P.lo.s[0].p,WP[P.lo.s[0].w].p]"))
        # equip with Enter on the selected card; skill tree untouched
        await pg.focus('.locard.on');await pg.keyboard.press('Enter');await pg.wait_for_timeout(600)
        print('enter equips',await E("()=>[P.weapon===P.lo.s[0].w,P.armor===P.lo.s[0].a,JSON.stringify(P.upg)===_U,!!document.querySelector('.locard.on .loact')]"))
        await pg.screenshot(path='shots/lp_equipped.png')
        # locked items can't be put in
        await E("()=>{P.xp=0;save();loadouts()}");await pg.wait_for_timeout(300);await pg.click('[data-pick="w"]');await pg.wait_for_timeout(300)
        await pg.click('[data-pf="all"]');await pg.wait_for_timeout(300)
        lk=await E("()=>{const x=document.querySelector('.loit.lk');return x&&x.dataset.it}")
        if lk:
            await pg.click(f'.loit[data-it="{lk}"]');await pg.wait_for_timeout(200)
            print('locked',await E("()=>[document.getElementById('loput').disabled,document.querySelector('#loput span').textContent]"))
            await pg.dblclick(f'.loit[data-it="{lk}"]');await pg.wait_for_timeout(200)
            print('locked dbl',await E(f"()=>P.lo.s[0].w==='{lk}'"))
        await pg.screenshot(path='shots/lp_locked.png')
        await pg.keyboard.press('Escape');await pg.wait_for_timeout(200);await pg.keyboard.press('Escape');await pg.wait_for_timeout(300)
        print('esc twice home',await E("()=>[ov.className,!!document.getElementById('lol')]"))
        # 1280 picker
        await E("()=>{P.xp=999999;save()}")
        await pg.set_viewport_size({'width':1280,'height':720});await E("()=>{loadouts()}");await pg.wait_for_timeout(500)
        await pg.click('[data-pick="a"]');await pg.wait_for_timeout(500);await pg.hover('.loit:nth-child(2)');await pg.wait_for_timeout(400)
        await pg.screenshot(path='shots/lp_picker_1280.png')
        print('overflow',await E("()=>[...document.querySelectorAll('.lopn,.lopk,.lolist')].map(e=>e.scrollHeight-e.clientHeight)"))
        print(er);await b.close()
asyncio.run(main())
