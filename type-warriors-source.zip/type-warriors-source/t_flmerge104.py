# python3 t_flmerge104.py [game.html] : 10.4 Harvest Festival, the five parts together (99s_fl_merge.js and the merge edits).
# Every festival screen at 1600x900, 1280x720 and 1024x640 with tools/td/rpu_ovl.js (home card and falling leaves, Choose a mode › Events,
# festival hub, calendar and its reveal, market and its "now or later" card, crates menu with both tabs, shop row and Harvest Collection,
# a Harvest Chest result, gear in the armory, companions Hall / eggs / hatch reveal, Rush page / run / results); the economy hooks pay
# exactly once across the parts (chest acorn filler, calendar presents, market purchases, the Rush payout, Gratitude tasks, the
# Collection's Mythic purchase through flgBuy); toasts do not stack on top of each other; no page errors. Screenshots in shots/w104_merge/.
import asyncio,os,sys,json
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
OVL=open(os.path.join(HERE,'..','tools','td','rpu_ovl.js')).read()
SHOTS=os.path.join(HERE,'shots','w104_merge');os.makedirs(SHOTS,exist_ok=True)
FAIL=[];N=[0];ERR=[]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+json.dumps(info)[:1400]),flush=True)
    if not ok:FAIL.append(name)
SETUP="()=>{try{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;PFW.asked=true;TPOLL_ON=0;ST.cine=false}catch(e){}window.FL_FORCE=1;load({});P.name='Hero';P.xp=lvx(30);syncPaths();FLP();save();title();return 1}"
HELP=r"""()=>{window.__m={sl:ms=>new Promise(r=>setTimeout(r,ms)),
 adv(to){const q=S.cr2;if(!q)return;while(q.t<to){q.last=performance.now()-1000/30;flcUpdate();if(!S.cr2||S.cr2!==q)break}},
 /* the leaves: inside the stage area, first child of .dkh, under every text box they meet */
 leaves(){const L=document.querySelector('.flleaves');if(!L)return{none:1};const h=L.parentElement,R=L.getBoundingClientRect(),st=h.querySelector('.dkstage').getBoundingClientRect();
  const bad=[];const own=e=>[...e.childNodes].some(n=>n.nodeType===3&&n.textContent.trim());
  for(const e of h.querySelectorAll('*')){if(L.contains(e)||!(own(e)||e.tagName==='BUTTON'))continue;const b=e.getBoundingClientRect();if(b.width<2||b.height<2)continue;
   if(b.right<=R.left||b.left>=R.right||b.bottom<=R.top||b.top>=R.bottom)continue;let top=e;while(top.parentElement!==h)top=top.parentElement;const cs=getComputedStyle(top);
   if(cs.position==='static'||(+cs.zIndex<0))bad.push((e.className||e.tagName)+':'+(e.textContent||'').trim().slice(0,20))}
  return{first:h.firstElementChild===L,z:getComputedStyle(L).zIndex,inStage:Math.abs(R.left-st.left)<2&&Math.abs(R.top-st.top)<2&&Math.abs(R.right-st.right)<2&&Math.abs(R.bottom-st.bottom)<2,n:L.querySelectorAll('.fllf').length,bad}},
 toasts(){return['flctoast','fletoast'].map(id=>{const e=document.getElementById(id);if(!e)return 0;const on=e.classList.contains('on')||e.classList.contains('show');const b=e.getBoundingClientRect();return on?[Math.round(b.top),Math.round(b.bottom),Math.round(b.left),Math.round(b.right)]:0}).map(x=>x||0)}};return 1}"""
async def mk(b,vw,vh,date='2026-11-07T12:00:00'):
    ctx=await b.new_context(viewport={'width':vw,'height':vh});await ctx.add_init_script("window.TWA_RELAYS=[]")
    pg=await ctx.new_page();pg.on('pageerror',lambda e:ERR.append(f'{vw}: '+str(e)[:300]))
    await pg.clock.install(time=date);await pg.goto(H);await pg.wait_for_function("()=>typeof title==='function'&&typeof P==='object'");await pg.wait_for_timeout(900)
    await pg.evaluate(SETUP);await pg.evaluate(OVL);await pg.evaluate(HELP);await pg.wait_for_timeout(300);return ctx,pg
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch()
        for vw,vh in [(1600,900),(1280,720),(1024,640)]:
            ctx,pg=await mk(b,vw,vh);E=pg.evaluate
            async def shot(n,w=250):
                await pg.wait_for_timeout(w);await pg.screenshot(path=os.path.join(SHOTS,f'{n}_{vw}.png'))
            o={}
            # ---- home: the events card and the falling leaves ----
            await E("async()=>{P.fl.fe.lv=1;title();await __m.sl(900)}");await shot('home',600)
            # the festival card (its own text and the Halloween button) and its place among the home cards; the rest of the home page is not festival work
            o['home']=await E("""()=>{const c=document.getElementById('dkflc');if(!c)return['no festival card'];const R=c.getBoundingClientRect(),o=__rpuOvl(c);
              for(const s of c.parentElement.children){if(s===c)continue;const b=s.getBoundingClientRect();if(b.width>2&&b.right>R.left+2&&b.left<R.right-2&&b.bottom>R.top+2&&b.top<R.bottom-2)o.push('card overlaps '+s.className)}return o}""")
            lv=await E("()=>__m.leaves()")
            chk(f'{vw}x{vh} home: the Harvest Festival card and the page do not overlap; the falling leaves fill only the stage area, under every panel, card and text',not o['home'] and lv.get('first') and lv.get('z')=='0' and lv.get('inStage') and lv.get('n',0)>=8 and not lv.get('bad'),[o['home'],lv])
            # ---- Choose a mode › Events ----
            r=await E("""async()=>{modeSheet();await __m.sl(500);const sh=document.getElementById('dkms');sh.querySelector('[data-v="m"] #dmv').click();await __m.sl(500);const g=sh.querySelector('.dkpv[data-v="e"] .dkmg');
              return{ids:[...g.children].slice(0,2).map(e=>e.id),rich:g.querySelector('#dmflr').classList.contains('flrcard'),o:__rpuOvl(sh)}}""")
            await shot('events');await E("()=>{try{dkClose(true)}catch(e){}title()}")
            chk(f'{vw}x{vh} Choose a mode › Events: the Harvest Festival card first, the Rush card (its own art, LIMITED TIME) second, no overlaps',r['ids']==['dmfl','dmflr'] and r['rich'] and not r['o'],r)
            # ---- festival hub, calendar and its reveal ----
            await E("async()=>{fleHub();await __m.sl(700)}");await shot('hub');o['hub']=await E("()=>__rpuOvl(ov)")
            await E("async()=>{fleCal();await __m.sl(700)}");await shot('calendar');o['cal']=await E("()=>__rpuOvl(ov)")
            r=await E("""async()=>{const a0=P.fl.ac,c0=P.fcr|0,g0=P.gold,lg0=P.fl.fe.lg.length;const d=fleCalNow();document.querySelector(`[data-fle-day="${d}"]`).click();await __m.sl(1400);const rv=document.getElementById('flerev');
              const out={rev:!!rv,ovl:rv?__rpuOvl(rv):['no reveal'],toasts:__m.toasts(),gifts:FLE_CAL[d].g,ac:P.fl.ac-a0,ch:(P.fcr|0)-c0,gold:P.gold-g0,lg:P.fl.fe.lg.slice(lg0).map(e=>[e.d,e.src]),again:fleCalClaim(d)};return out}""")
            await shot('calendar_reveal',100)
            exp={'ac':0,'ch':0,'co':0}
            for k,v in r['gifts']:exp[k]=exp.get(k,0)+v
            chk(f'{vw}x{vh} calendar: today\'s present pays once (acorns {exp["ac"]}, chests {exp["ch"]}, coins {exp["co"]}), its reveal has no overlaps, no extra toast on top of it, a second claim gets nothing',
                r['rev'] and not r['ovl'] and r['ac']==exp['ac'] and r['ch']==exp['ch'] and r['gold']==exp['co'] and len([x for x in r['lg'] if x[0]>0])==(1 if exp['ac'] else 0) and r['again'] is None and r['toasts']==[0,0],r)
            await E("()=>{const k=document.getElementById('flerok');if(k)k.click()}")
            # ---- market ----
            await E("async()=>{P.fl.ac=12000;fleMarket();await __m.sl(800)}");await shot('market');o['market']=await E("()=>__rpuOvl(ov)")
            r=await E("""async()=>{const a0=P.fl.ac,c0=P.fcr|0,lg0=P.fl.fe.lg.length;document.querySelector('[data-fle-buy="chest"]').click();await __m.sl(500);const ask=document.getElementById('fleask');
              const out={spent:a0-P.fl.ac,ch:(P.fcr|0)-c0,lg:P.fl.fe.lg.slice(lg0).map(e=>[e.d,e.src]),ask:!!ask,ovl:__rpuOvl(ov),toasts:__m.toasts(),note:(document.getElementById('flemknote')||{}).textContent};
              const n=document.getElementById('fleaskn');if(n)n.click();await __m.sl(200);return out}""")
            await shot('market_bought',50)
            chk(f'{vw}x{vh} market: a Harvest Chest costs 150 acorns once and adds one chest; the note and the "Open it now" card show, no chest toast on top, no overlaps',
                r['spent']==150 and r['ch']==1 and r['lg']==[[-150,'market']] and r['ask'] and not r['ovl'] and r['toasts']==[0,0],r)
            if vw==1600:
                r=await E("""async()=>{delete P.pets[FL.pets.r];fleMarket();await __m.sl(500);const a0=P.fl.ac;const b=document.querySelector('[data-fle-buy="squir"]');b.click();await __m.sl(80);b.click();await __m.sl(600);
                  const ov1=!!document.getElementById('pthx');const out={spent:a0-P.fl.ac,own:petOwned(FL.pets.r),rev:ov1};for(let i=0;i<40&&document.getElementById('pthx');i++){const s=document.getElementById('ptsk');if(s)s.click();const c=document.querySelector('#pthx .ptrv button');if(c)c.click();await __m.sl(250)}
                  out.closed=!document.getElementById('pthx');out.market=!!document.querySelector('.flemk');return out}""")
                chk('market: a companion bought there joins once (1,000 acorns), its harvest reveal plays, and closing it returns to the market',r['spent']==1000 and r['own'] and r['rev'] and r['closed'] and r['market'],r)
            # ---- crates menu (both tabs), shop row, Harvest Collection, a chest result ----
            r=await E("""async()=>{P.fcr=4;P.hcr=2;P.crates=3;P.acr=2;crateHub();await __m.sl(1200);const a=__rpuOvl(ov).filter(x=>!/^CLIPPED \\.sm\\[Open\\]/.test(x));const fit1=ov.scrollHeight<=ov.clientHeight+2;
              flcTabSet('h');await __m.sl(600);const b2=__rpuOvl(ov).filter(x=>!/^CLIPPED \\.sm\\[Open\\]/.test(x));const fit2=ov.scrollHeight<=ov.clientHeight+2;flcTabSet('f');return{a,b2,fit1,fit2}}""")
            await shot('crates')
            chk(f'{vw}x{vh} crates menu: with the Harvest Chest banner and the tabs the page fits above the Store / Owned toggle and the dock on both tabs, nothing hidden or overlapping',not r['a'] and not r['b2'] and r['fit1'] and r['fit2'],r)
            await E("async()=>{flcTabSet('h');await __m.sl(500)}");await shot('crates_graveyard');await E("()=>flcTabSet('f')")
            r=await E("""async()=>{P.gold=130000;delete P.ownA[FL.gear.a[5]];delete P.own[FL.gear.w[5]];const key=x=>x.replace(/\\[[^\\]]*\\]/g,'').replace(/ \\d+x\\d+$/,'');
              window.FL_FORCE=-1;shop();await __m.sl(600);const base=new Set(__rpuOvl(document.getElementById('shp')).map(key));window.FL_FORCE=1;
              SHX.sel='f';shop();await __m.sl(900);const a=__rpuOvl(document.getElementById('shp')).filter(x=>!base.has(key(x)));const own=!!document.getElementById('flgsp');
              flcCollection();await __m.sl(900);const w=document.getElementById('flcwin');return{a,own,b:__rpuOvl(w),dis:[...w.querySelectorAll('[data-fb]')].map(x=>x.disabled)}}""")
            await shot('collection')
            chk(f'{vw}x{vh} shop: the Harvest Chest row and the Harvest Collection banner, one way in for the Mythics (no second Harvest Relics button); the Collection has no overlaps',not r['a'] and not r['own'] and not r['b'] and r['dis']==[False,False,True],r)
            if vw==1600:
                r=await E("""async()=>{const g0=P.gold,L0=(P.ldg||[]).length;const fb=document.querySelector('#flcwin [data-fb="w"]');fb.click();await __m.sl(1300);const L=ledgerRecent(4);
                  const again=flgBuy('w');return{paid:g0-P.gold,own:!!P.own[FL.gear.w[5]],ldg:L.filter(e=>/harvest relic/.test(e.src)).map(e=>e.d),again,why:flgWhyNot('w')}}""")
                chk('Harvest Collection: the Horn of Plenty is bought once through flgBuy (100,000 coins, gold ledger "harvest relic"), then owned',r['paid']==100000 and r['own'] and r['ldg'][:1]==[-100000] and r['again'] is False and r['why']=='owned',r)
            await E("()=>shClose()")
            r=await E("""async()=>{FLC.force=5;FLC.forceK='relic';P.fcr=Math.max(1,P.fcr|0);flcStart();const q=S.cr2;__m.adv(q.E+.2);await __m.sl(400);return __rpuOvl(ov.querySelector('.flcres'))}""")
            await shot('chest_result');await E("()=>{crateEnd();title()}")
            chk(f'{vw}x{vh} a Mythic Harvest Chest result: no overlaps',not r,r)
            # ---- gear in the armory ----
            r=await E("""async()=>{P.ownA.flfeast=1;P.own.fl_horn=1;P.armor='flfeast';setWeapon('fl_horn');save();armory('Armor');await __m.sl(500);const c=ov.querySelector('[data-k="flfeast"]');if(c)c.click();await __m.sl(500);
              const pv=ov.querySelector('.gab');return{card:!!c,o:pv?__rpuOvl(pv.parentElement):['no panel'],page:__rpuOvl(ov).length}}""")
            await shot('armory')
            chk(f'{vw}x{vh} armory: Feastlord\'s Aegis inspect panel with Bountiful Harvest, no overlaps',r['card'] and not r['o'],r)
            # ---- companions ----
            r=await E("""async()=>{petNorm();const key=x=>{const m=x.match(/^OVERLAP (\\S+?)\\[.*?\\] x (\\S+?)\\[/);return m?m[1]+(/^#dk_|^\\.B$|^\\.bdg$/.test(m[2])?'|dock':'|'+m[2]):x};
              const reg=PIDS.find(i=>PDEF[i]&&!PDEF[i].fl&&PDEF[i].r==='l')||'mosskip';P.pets[reg]=P.pets[reg]||{b:0,nk:'',pal:0,acc:0,trim:0};PTX.sel=reg;PTX.back=title;petHall('Pets');await __m.sl(800);const base=new Set(__rpuOvl(ov).map(key));
              for(const id of[FL.pets.r,FL.pets.l])P.pets[id]=P.pets[id]||{b:0,nk:'',pal:0,acc:0,trim:0};PTX.sel=FL.pets.l;petHall('Pets');await __m.sl(800);const a=__rpuOvl(ov).filter(x=>!base.has(key(x)));
              P.eggs.h=1;PTX.egg='h';petHall('Eggs');await __m.sl(900);return{a,b:__rpuOvl(ov)}}""")
            await shot('eggs')
            chk(f'{vw}x{vh} Companion Hall with a harvest companion, and the Eggs tab with the Golden Harvest Egg: no overlaps',not r['a'] and not r['b'],r)
            r=await E("""async()=>{delete P.pets.flturkey;const x=flpEgg();for(let i=0;i<60;i++){await __m.sl(250);const rv=document.querySelector('#pthx .ptrv');if(rv&&rv.textContent.trim().length>10)break}await __m.sl(600);
              const el=document.getElementById('pthx');return{x,o:el?__rpuOvl(el):['no reveal']}}""")
            await shot('hatch_reveal',50)
            chk(f'{vw}x{vh} the Golden Harvest Egg hatches Thunderplume: the reveal has no overlaps',r['x'] and r['x'].get('id')=='flturkey' and not r['o'],r)
            await E("()=>{const x=document.getElementById('pthx');if(x){try{x._stop&&x._stop()}catch(e){}x.remove()}title()}")
            # ---- Harvest Moon Rush: page, run, results ----
            await E("async()=>{flrMenu(title);await __m.sl(900)}");await shot('rush_page');o['rush']=await E("()=>__rpuOvl(document.querySelector('.flrm'))")
            await E("async()=>{start(0,'flr');S.hp=S.max=40;for(let i=0;i<180;i++)update(1/60);draw()}");await shot('rush_run',100)
            r=await E("""async()=>{const lg0=P.fl.fe.lg.length,c0=P.fcr|0,G=fleGT(),i=G.k.findIndex(k=>FLE_TK[k].ev==='rush'),p0=i>=0?G.p[i]:null;S.flrA=10;S.flrC=1;S.score=900;over(1);await __m.sl(800);
              const L=P.fl.fe.lg.slice(lg0).filter(e=>/rush/i.test(e.src)).map(e=>e.d);return{o:__rpuOvl(document.querySelector('.flrov')),L,ch:(P.fcr|0)-c0,toasts:__m.toasts(),task:i>=0?G.p[i]-p0:null}}""")
            await shot('rush_results',50)
            chk(f'{vw}x{vh} Harvest Moon Rush: page and results without overlaps; the run\'s 10 acorns and 1 chest are paid once, quietly (the results list them)',not o['rush'] and not r['o'] and r['L']==[10] and r['ch']==1 and r['toasts']==[0,0] and r['task'] in (None,1),[o['rush'],r])
            for k in ('hub','cal','market'):
                chk(f'{vw}x{vh} festival {k}: no overlaps',not o[k],o[k])
            await ctx.close()
        # ================= economy and toasts across the parts (1600x900) =================
        ctx,pg=await mk(b,1600,900);E=pg.evaluate
        r=await E("""async()=>{const a0=fleAcorns(),lg0=P.fl.fe.lg.length;FLC.force=0;FLC.forceK='ac';P.fcr=2;flcStart();const q=S.cr2,n=q.res&&q.res.n||q.fl&&q.fl.n;__m.adv(q.E+.2);await __m.sl(500);
          const got=fleAcorns()-a0,lg=P.fl.fe.lg.slice(lg0).map(e=>[e.d,e.src]),pend=(P.flcPend||[]).length,again=flcPendRun();crateEnd();title();
          P.fcr=10;P.fcpity=0;const a1=fleAcorns();crateHub();await __m.sl(400);flcBatch(10);await __m.sl(1500);const bat=fleAcorns()-a1,pend2=(P.flcPend||[]).length;crateEnd();title();return{n,got,lg,pend,again,bat,pend2}}""")
        chk('chest acorn filler: the acorns of a pull reach the festival exactly once (one ledger line, "Harvest Chest"), nothing stays waiting; Open 10 hands every waiting acorn over',
            r['got']==r['n'] and len(r['lg'])==1 and r['lg'][0][1]=='Harvest Chest' and r['pend']==0 and r['again']==0 and r['pend2']==0,r)
        r=await E("""async()=>{const G=fleGT(),k=G.k[0],T=FLE_TK[k];G.p[0]=T.n;G.c[0]=0;save();const a0=fleAcorns();const n1=fleClaimTask(0),n2=fleClaimTask(0);return{n1,n2,got:fleAcorns()-a0}}""")
        chk('Gratitude task: claiming pays its acorns once, a second claim pays nothing',r['n1']>0 and r['n2']==0 and r['got']==r['n1'],r)
        r=await E("""async()=>{title();await __m.sl(300);flcAdd(1,'Harvest Calendar');await __m.sl(120);fleGive(7,'calendar');await __m.sl(500);const t=__m.toasts();const ct=document.querySelector('#flctoast small').textContent;
          await __m.sl(3600);flcAdd(1,'market');await __m.sl(300);const ct2=document.querySelector('#flctoast small').textContent;return{t,ct,ct2}}""")
        chk('toasts: a chest toast and an acorn toast at the same time stack (the newer one sits under the one already showing), and a chest toast names its source in words',
            r['t'][0] and r['t'][1] and (r['t'][1][0]>=r['t'][0][1] or r['t'][0][0]>=r['t'][1][1]) and r['ct']=='Harvest Calendar' and r['ct2']=='Harvest Market',r)
        r=await E("""()=>{const L=[];const t0=fleTask;fleTask=function(ev,v){L.push(ev);return t0.apply(this,arguments)};start(0,'flr');S.flrA=0;S.flrC=0;S.mode='play';over();fleTask=t0;const n=L.filter(x=>x==='rush').length;title();return{n}}""")
        chk('a Harvest Moon Rush run that ends without acorns still counts once for its Gratitude task',r['n']==1,r)
        await ctx.close()
        chk('no page errors',not ERR,ERR)
        await b.close()
    print(f'\n{N[0]-len(FAIL)}/{N[0]} passed'+('' if not FAIL else '  FAILED: '+'; '.join(FAIL)))
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
