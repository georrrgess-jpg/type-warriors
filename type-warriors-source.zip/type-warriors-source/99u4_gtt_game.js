/* ===== UPDATE 10.5, THE GREAT TURKEY TROT: the game (99u4, prefix gttu / GTTU) =====
   A casino racing game: read the race card, back a turkey (up to three bets), watch the race, cash out early if you like.
   The data and the race model are in 99u_gtt_data / 99u2_gtt_sim, the art in 99u3_gtt_art, sound in 99u5_gtt_audio, CSS in 99u6_gtt_style.
   Screens: the paddock (race card + bet slip), the race (full stage canvas + HUD), the photo finish, the results (podium + bet lines).
   Money (strict): the stakes are taken through cTake together with the pending record P.gtt.pend in ONE save at Start; every payout goes
   through cPay exactly once (a cash out for its bet, the rest when the race is settled) and the pending record is removed in the same
   save as the last payout. The race that is shown is the sim replayed from the seeds stored in the pending record, so a reload (or
   leaving the casino) finishes the same race instantly, pays once and shows the result screen.
   Festival: while flOn() a race with a winning bet pays +5 acorns through fleGive (10 races = 50 acorns a day, P.gtt.acorn).
   Keys: 1-6 pick a turkey, W / T / P / E bet type (Win / Top 2 / Top 3 "podium" / Exact 1-2; the digit 3 stays a turkey), + / - stake,
   arrows move the pick and the tab, Enter add a bet (or race again), Space start, C cash out, N new card, Esc back. */
const GTTU={
 K:[['win','Win','W','Your turkey finishes first'],['top2','Top 2','T','Your turkey finishes first or second'],['top3','Top 3','P','Your turkey finishes in the first three'],['exact','Exact 1-2','E','Pick the winner and the runner-up, in order']],
 kn:{win:'Win',top2:'Top 2',top3:'Top 3',exact:'Exact 1-2'},
 steps:[10,25,50,100,250,500,1000,2500,5000],
 style:{front:'Front-runner',close:'Closer',stalk:'Stalker'},going:{firm:'Firm going',good:'Good going',muddy:'Muddy going'},wx:{clear:'Clear sky',wind:'Windy',drizzle:'Drizzle'},
 fixCard:[],fixRace:[],fast:1,hidden:0,seedCtr:1000,cur:null,
 say:{lead:['{n} takes the lead!','{n} goes to the front!','{n} moves into the lead!'],stumble:['{n} stumbles on a hay bale!','Oh no, {n} trips!','{n} hits the hay!'],
  burst:['{n} finds a corn kernel and bursts away!','Corn power for {n}!','{n} is flying!'],pie:['{n} stops to stare at a pie!','{n} is distracted by a pie!','A pie! {n} loses focus!'],
  kick:['Here comes {n} on the outside!','{n} starts the big kick!','{n} is closing fast!'],gust:['A gust sweeps across the track!','The wind whips up the leaves!'],
  half:['Halfway: {n} leads.'],last:['Into the final stretch! {n} in front.'],win:['{n} wins!','{n} takes it!','{n} is first past the post!']}};
const gttuOrd=n=>['','1st','2nd','3rd','4th','5th','6th'][n]||n+'th';
const gttuM=m=>m==null?'—':'×'+(+(+m).toFixed(2));
const gttuR=id=>(typeof GTT_RUN!=='undefined'&&GTT_RUN.find(r=>r.id===id))||{id,n:id,style:'stalk',col:['#c87a2a','#ffd45a'],silk:['#ffd45a','#c87a2a'],jockey:{n:'Pip',kind:'goblin'},tip:''};
const gttuInk=c=>{const h=String(c).replace('#',''),n=parseInt(h.length===3?h.replace(/./g,'$&$&'):h,16),r=n>>16&255,g=n>>8&255,b=n&255;return .299*r+.587*g+.114*b>150?'#12081f':'#fff8e8'};
const gttuFmtT=t=>{const m=Math.floor(t/60),s=t-m*60;return m+':'+(s<10?'0':'')+s.toFixed(1)};
function gttuSeed(kind){const q=kind==='card'?GTTU.fixCard:GTTU.fixRace;if(q.length)return q.shift()>>>0;try{const a=new Uint32Array(1);crypto.getRandomValues(a);return a[0]}catch(e){return (Math.random()*4294967296)>>>0}}
/* P.gtt: repaired once per screen (gttuG(true)); gttNorm builds a new object, so it is not run on every access (the pending record must stay the same object) */
function gttuG(fix){if(fix||!P.gtt||typeof P.gtt!=='object'||P.gtt.v!==1||!P.gtt.rec||!P.gtt.acorn){try{gttNorm()}catch(e){console.error(e)}}
 if(!P.gtt||typeof P.gtt!=='object')P.gtt={v:1,races:0,bets:0,wins:0,best:0,long:0,fav:{},rec:{},seen:0,pend:null,acorn:{day:'',n:0}};return P.gtt}
const gttuTotal=bets=>bets.reduce((a,b)=>a+b.stake,0);
const gttuRet=b=>Math.min(GTT.cap,Math.floor(b.stake*b.mult));
function gttuLbl(card,b,nl){const n=l=>'#'+(l+1)+' '+gttuR(card.field[l]).n;return b.k==='exact'?n(b.a)+(nl?'\nthen ':', then ')+n(b.b):n(b.a)}
ICON.gtt='<svg viewBox="0 0 64 64"><path d="M32 36 14 14c6-4 12-3 18 2 6-5 12-6 18-2z" fill="#e8851a" stroke="#12081f" stroke-width="3" stroke-linejoin="round"/><ellipse cx="32" cy="40" rx="15" ry="12" fill="#a8602a" stroke="#12081f" stroke-width="3"/><circle cx="40" cy="26" r="6" fill="#d8a060" stroke="#12081f" stroke-width="2.5"/><circle cx="42" cy="25" r="1.8" fill="#12081f"/><path d="M46 27l7 2-6 2z" fill="#ffd45a" stroke="#12081f" stroke-width="2"/><path d="M26 50v8M38 50v8" stroke="#12081f" stroke-width="3" stroke-linecap="round"/></svg>';
try{gttTile()}catch(e){console.error(e)}
try{if(typeof FLE_SRC==='object'&&FLE_SRC&&!FLE_SRC.turkeytrot)FLE_SRC.turkeytrot='Great Turkey Trot'}catch(e){}
{const i=GAMES.findIndex(g=>g.id==='gtt');if(i>=0)GAMES.splice(i,1);
 GAMES.unshift({id:'gtt',n:'The Great Turkey Trot',d:'NEW · Six turkeys with tiny monster jockeys race round the harvest fair. Read the card, back a turkey, watch the race and cash out early if yours is fading. Max payout 20,000 per race.',m:(e,t)=>gttHome(e,t)})}
/* ---------- trophies (Casino) ---------- */
A('gtt1','Casino',0,'Off to the Races','Run your first race in The Great Turkey Trot.',1,()=>AS('gttr'),100);
A('gtt2','Casino',1,'Backed a Winner','Win a Win bet in The Great Turkey Trot.',1,()=>AS('gttw'),150);
A('gtt3','Casino',2,'Longshot','Win a Win bet at x15 or more in The Great Turkey Trot.',15,()=>AS('gttl'),300,1);
A('gtt4','Casino',2,'Called It','Win an Exact 1-2 bet in The Great Turkey Trot.',1,()=>AS('gttx'),300,1);
A('gtt5','Casino',2,'By a Beak','Back the winner of a photo finish in The Great Turkey Trot.',1,()=>AS('gttb'),250,1);
A('gtt6','Casino',1,'Smart Money','Cash out a Turkey Trot bet for more than its stake.',1,()=>AS('gttc'),200);

/* ---------- settling (pure lines + the one place that pays) ---------- */
/* what a pending record is worth against a finished race: cashed-out bets keep what they were paid, the rest is settled; the whole race never pays more than GTT.cap */
function gttuLines(rec,fin){
 const cash=new Map((rec.cash||[]).map(c=>[c.i,c.pay])),rem=[],idx=[];
 rec.bets.forEach((b,i)=>{if(!cash.has(i)){rem.push(b);idx.push(i)}});
 const S=rem.length?gttSettle(rem,fin):{lines:[],total:0},cashPaid=[...cash.values()].reduce((a,v)=>a+v,0),allow=Math.max(0,GTT.cap-cashPaid),payRem=Math.min(S.total,allow);
 const lines=rec.bets.map((b,i)=>{if(cash.has(i))return{i,bet:b,won:false,cashed:true,pay:cash.get(i)};const l=S.lines[idx.indexOf(i)]||{won:false,pay:0};return{i,bet:b,won:!!l.won,cashed:false,pay:l.pay|0}});
 return{lines,cashPaid,payRem,paid:cashPaid+payRem,staked:gttuTotal(rec.bets),remStake:gttuTotal(rem),capped:cashPaid+lines.reduce((a,l)=>a+(l.won&&!l.cashed?Math.floor(l.bet.stake*l.bet.mult+1e-9):0),0)>GTT.cap,winner:fin.order[0],photo:fin.photo||false}}
/* pays the pending race exactly once: P.gtt.pend is cleared before the single cPay, whose save writes both */
function gttuSettle(fin){
 const g=gttuG(),rec=g.pend;if(!rec||!Array.isArray(rec.bets))return null;
 const card=gttCard(rec.cardSeed),R=gttuLines(rec,fin);R.card=card;R.fin=fin;R.rec=rec;
 g.pend=null;g.races++;g.bets+=rec.bets.length;
 let nw=0,maxWin=0,nex=0,beak=false;
 for(const l of R.lines){if(l.cashed)continue;if(l.won){nw++;if(l.bet.k==='win')maxWin=Math.max(maxWin,l.bet.mult);if(l.bet.k==='exact')nex++}
  if(fin.photo&&l.bet.a===fin.order[0])beak=true}
 g.wins+=nw;if(R.paid>g.best)g.best=R.paid;if(maxWin>g.long)g.long=maxWin;
 for(const b of rec.bets)for(const l of(b.k==='exact'?[b.a,b.b]:[b.a])){const id=card.field[l];if(id)g.fav[id]=(g.fav[id]||0)+1}
 card.field.forEach((id,lane)=>{const r=g.rec[id]=g.rec[id]||{s:0,w:0,p:0,last:[]},pos=fin.order.indexOf(lane)+1;r.s++;if(pos===1)r.w++;if(pos>=1&&pos<=3)r.p++;r.last=(r.last||[]).concat(pos).slice(-5)});
 R.wins=nw;R.acorns=0;
 try{if(typeof flOn==='function'&&flOn()&&nw>0&&typeof fleGive==='function'){const day=typeof fleDay==='function'?fleDay():new Date().toISOString().slice(0,10),a=g.acorn;if(a.day!==day){a.day=day;a.n=0}
   if(a.n<GTT.acorn.perDay){a.n++;R.acorns=fleGive(GTT.acorn.win,'turkeytrot')||0}}}catch(e){console.error(e)}
 stat('gttr',1,'add');if(nw&&maxWin)stat('gttw',1,'add');if(maxWin)stat('gttl',Math.floor(maxWin),'max');if(nex)stat('gttx',nex,'add');if(beak)stat('gttb',1,'add');
 if(R.remStake>0)cPay(R.remStake,R.payRem);else save();
 try{achCheck()}catch(e){}
 return R}
/* one bet cashed out: recorded in the pending record and paid in the same save (once; a second call for the same bet does nothing) */
function gttuCash(i,pay){
 const g=gttuG(),rec=g.pend;if(!rec||!rec.bets[i]||(rec.cash||[]).some(c=>c.i===i))return 0;
 const paid=(rec.cash||[]).reduce((a,c)=>a+c.pay,0);pay=Math.floor(Math.min(pay,GTT.cap-paid));if(!(pay>=1))return 0;
 rec.cash=(rec.cash||[]).concat({i,pay});if(pay>rec.bets[i].stake)stat('gttc',1,'add');cPay(rec.bets[i].stake,pay);try{achCheck()}catch(e){}return pay}
/* run a pending race to the end without showing it (reload, leaving the casino) */
function gttuFinishNow(){const g=gttuG(),rec=g.pend;if(!rec)return null;let fin;try{fin=gttRun(gttCard(rec.cardSeed),rec.raceSeed)}catch(e){console.error(e);g.pend=null;save();return null}return gttuSettle(fin)}

/* ---------- the casino mount ---------- */
function gttHome(el,tok){
 const alive=()=>CAS.tok===tok,rm=matchMedia('(prefers-reduced-motion: reduce)').matches,LOW=()=>rm||(typeof PFSET==='function'&&PFSET()!=='high'),STEP=1/GTT.hz;
 try{gttBake()}catch(e){console.error(e)}
 gttuG(true);ensureAudio();
 let priceCancel=null,errN=0,ph='paddock',card=null,px=null,sel=null,ex1=null,kind='win',slip=[],rec=null,fin=null,st=null,R=null,cam=null,cv=null,cg=null,pcv=null,pcg=null,ccv=null,ccg=null,
  tt=0,last=0,acc=0,gateT=0,photoT=0,resT=0,winT=-1,evI=0,lastSay=-9,lastLead=-1,said={},offers=[],offAt=[],lastCo=0,loopOn=false,overlay=null,conf=[],note='',priceId=0,cseed=0,half=0,gobT=0,stepT=0,clock=0,gateOpen=false;
 const $q=s=>el.querySelector(s),g0=()=>gttuG();
 const nm=l=>gttuR(card.field[l]).n,runner=l=>gttuR(card.field[l]);
 /* ===== the card and its price ===== */
 const newCard=(seed,keep)=>{cseed=seed==null?gttuSeed('card'):seed>>>0;card=gttCard(cseed);px=null;sel=null;ex1=null;const prev=keep?keep.map(b=>({k:b.k,a:b.a,b:b.b,stake:b.stake})):[];slip=[];priceId++;const id=priceId,c0=card;
  if(prev.length){let tot=0;for(const b of prev){if(slip.length>=GTT.maxBets||tot+b.stake>Math.min(GTT.maxTotal,P.gold))break;tot+=b.stake;slip.push({k:b.k,a:b.a,b:b.b,stake:b.stake,mult:null})}}
  if(ph==='paddock'&&$q('#gttcard')){paddockCards();slipRender();headRender()}
  try{if(typeof priceStop==='function')priceStop();const cn=gttPrice(c0,4000,r=>{if(!alive()||id!==priceId||c0!==card)return;px=r;reprice();if(ph==='paddock'&&$q('#gttcard')){oddsRender();slipRender()}});priceCancel=typeof cn==='function'?cn:null}catch(e){console.error(e)}};
 const priceStop=()=>{if(priceCancel){try{priceCancel()}catch(e){}priceCancel=null}};
 const mOf=(k,a,b)=>{if(!px||!px.mult)return null;const M=px.mult;if(k==='exact')return M.exact&&M.exact[a]?M.exact[a][b]:null;return M[k]?M[k][a]:null};
 const reprice=()=>{const keep=[];let dropped=0;for(const b of slip){const m=mOf(b.k,b.a,b.b);if(m){b.mult=m;keep.push(b)}else dropped++}slip=keep;if(dropped)msg('Some bets are not offered on this card and were removed.','l')};
 /* ===== bets ===== */
 const total=()=>gttuTotal(slip);
 const curBet=()=>{if(sel==null)return null;if(kind==='exact'){if(ex1==null||ex1===sel)return null;return{k:'exact',a:ex1,b:sel}}return{k:kind,a:sel}};
 const stakeNow=()=>Math.floor(CAS.bet||0);
 const addErr=()=>{const b=curBet();
  if(!px)return'Setting the odds... one moment.';
  if(kind==='exact'&&(ex1==null||sel==null))return ex1==null?'Exact 1-2: tap the winner first (1st?).':'Exact 1-2: now tap the runner-up (2nd?).';
  if(kind==='exact'&&ex1===sel)return'Exact 1-2 needs two different turkeys.';
  if(!b)return'Tap a turkey to back it.';
  const s=stakeNow();if(s<GTT.minBet)return`Stakes start at ${GTT.minBet}.`;if(s>GTT.maxBet)return`Table limit: ${cmn(GTT.maxBet)} per bet.`;
  if(slip.length>=GTT.maxBets)return`Three bets per race is the limit. Remove one first.`;
  if(total()+s>GTT.maxTotal)return`Table limit: ${cmn(GTT.maxTotal)} staked per race.`;
  if(total()+s>P.gold)return broke()||'Not enough gold for that bet.';
  if(!mOf(b.k,b.a,b.b))return'That bet is not offered (too long a shot).';return''};
 const addBet=quiet=>{if(ph!=='paddock'||CAS.lock)return false;const e=addErr();if(e){msg(e,'l');return false}const b=curBet(),s=stakeNow();slip.push({k:b.k,a:b.a,b:b.b,stake:s,mult:mOf(b.k,b.a,b.b)});
  if(!quiet)beep(880,.05,'triangle',.5);ex1=null;sel=null;oddsRender();pickRender();slipRender();markRows();msg(`Added: ${GTTU.kn[b.k]} on ${gttuLbl(card,b)}. ${slip.length<GTT.maxBets?'Add another or start the race.':'Start the race!'}`,'w');return true};
 const rmBet=i=>{if(ph!=='paddock'||CAS.lock||!slip[i])return;slip.splice(i,1);slipRender();markRows();beep(420,.05,'triangle',.4)};
 const setKind=k=>{if(ph!=='paddock'||CAS.lock||kind===k)return;kind=k;ex1=null;sel=null;tabsRender();oddsRender();markRows();pickRender()};
 const pick=l=>{if(ph!=='paddock'||CAS.lock||l<0||l>5)return;try{gttSnd.gobble(l)}catch(e){}
  if(kind==='exact'){if(ex1==null||sel!=null){ex1=l;sel=null}else if(l===ex1){ex1=null}else sel=l}else sel=l;
  oddsRender();markRows();pickRender();strut(l)};
 const strut=l=>{const r=$q(`.gttrow[data-l="${l}"]`);if(r&&!rm){r.classList.remove('hop');void r.offsetWidth;r.classList.add('hop')}};
 const setStake=d=>{if(ph!=='paddock'||CAS.lock)return;const S=GTTU.steps,b=CAS.bet;const v=d>0?(S.find(x=>x>b)||S[S.length-1]):([...S].reverse().find(x=>x<b)||S[0]);CAS.bet=Math.min(P.gold,v);betRefresh();oddsRender();pickRender();slipRender()};
 /* ===== paddock ===== */
 const SVG={sun:'<svg viewBox="0 0 24 24" width="16" height="16"><circle cx="12" cy="12" r="5" fill="#ffd45a" stroke="#12081f" stroke-width="2"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2" stroke="#ffd45a" stroke-width="2" stroke-linecap="round"/></svg>',
  wind:'<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="#9fe8ff" stroke-width="2.4" stroke-linecap="round"><path d="M3 8h10a3 3 0 1 0-3-3M3 13h15a3 3 0 1 1-3 3M3 18h7"/></svg>',
  rain:'<svg viewBox="0 0 24 24" width="16" height="16"><path d="M7 14a4 4 0 0 1 1-7.8A5 5 0 0 1 17.500 8 3.500 3.500 0 0 1 17 14z" fill="#b8c4e8" stroke="#12081f" stroke-width="2"/><path d="M8 17l-1 3M12 17l-1 3M16 17l-1 3" stroke="#6ab8ff" stroke-width="2" stroke-linecap="round"/></svg>',
  firm:'<svg viewBox="0 0 24 24" width="16" height="16"><rect x="3" y="12" width="18" height="7" rx="2" fill="#d8b070" stroke="#12081f" stroke-width="2"/><path d="M7 9l2-4 2 4 2-4 2 4" stroke="#ffd45a" stroke-width="2" fill="none"/></svg>',
  good:'<svg viewBox="0 0 24 24" width="16" height="16"><rect x="3" y="12" width="18" height="7" rx="2" fill="#a8742e" stroke="#12081f" stroke-width="2"/><path d="M7 11c0-3 2-5 2-7M13 11c0-3 2-5 2-7" stroke="#7dff9a" stroke-width="2" fill="none" stroke-linecap="round"/></svg>',
  muddy:'<svg viewBox="0 0 24 24" width="16" height="16"><rect x="3" y="12" width="18" height="7" rx="2" fill="#5a3a1c" stroke="#12081f" stroke-width="2"/><circle cx="8" cy="9" r="2" fill="#7a4a22"/><circle cx="14" cy="8" r="2.500" fill="#7a4a22"/><circle cx="18" cy="10" r="1.500" fill="#7a4a22"/></svg>'};
 const wxIcon=w=>w==='wind'?SVG.wind:w==='drizzle'?SVG.rain:SVG.sun;
 const lastRec=id=>{const r=g0().rec[id];return r&&Array.isArray(r.last)?r.last.slice(-5):[]};
 const formHtml=id=>{const L=lastRec(id);let h='';for(let i=0;i<5;i++){const p=L[i-(5-L.length)];h+=p?`<i class="gtm m${Math.min(p,4)}" title="${gttuOrd(p)}">${p}</i>`:'<i class="gtm m0">·</i>'}return h};
 const rowHtml=l=>{const r=runner(l),s=r.silk||[r.col[1],r.col[0]];return `<div class="gttrow" data-l="${l}" role="radio" aria-checked="false" tabindex="0" aria-label="${r.n}, number ${l+1}">
  <i class="gttcl" style="background:${s[0]};color:${gttuInk(s[0])};--c2:${s[1]}"><b>${l+1}</b></i><canvas width="120" height="96" data-id="${r.id}"></canvas>
  <span class="gttnm"><b>${r.n}</b><em class="gtts-${r.style}">${GTTU.style[r.style]||''}</em><small>${r.tip||''}</small></span>
  <span class="gttform" title="Last five finishes">${formHtml(r.id)}</span><button class="gttodds" tabindex="-1" data-l="${l}">…</button><s class="gttmine">BET</s></div>`};
 const paddockCards=()=>{const box=$q('#gttcard');if(!box)return;box.innerHTML=card.field.map((_,l)=>rowHtml(l)).join('');
  box.querySelectorAll('.gttrow').forEach(row=>{const l=+row.dataset.l,cv=row.querySelector('canvas'),id=card.field[l];row.onclick=()=>pick(l);row.onmousedown=e=>e.preventDefault();row.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();e.stopPropagation();pick(l)}};
   LIVE.push({cv,fn:()=>{try{gttPortrait(cv,id,performance.now()/1000+l*.37,l)}catch(e){}},slow:2,ph:l})});
  oddsRender();markRows()};
 const headRender=()=>{const a=$q('#gttno');if(!a)return;a.textContent='Race '+card.no;$q('#gttgo').innerHTML=(SVG[card.going]||'')+' '+(GTTU.going[card.going]||card.going);$q('#gttwx').innerHTML=wxIcon(card.weather)+' '+(GTTU.wx[card.weather]||card.weather)};
 const oddsRender=()=>{if(ph!=='paddock')return;el.querySelectorAll('.gttrow').forEach(row=>{const l=+row.dataset.l,b=row.querySelector('.gttodds');let t,cls='';
   if(!px){t='…';cls='wait'}else if(kind==='exact'){if(ex1==null)t='1st?';else if(l===ex1){t='1st';cls='first'}else{const m=mOf('exact',ex1,l);t=m?gttuM(m):'—'}}else{const m=mOf(kind,l);t=m?gttuM(m):'—';if(!m)cls='off'}
   b.textContent=t;b.className='gttodds '+cls});
  const pr=$q('#gttpricing');if(pr)pr.hidden=!!px};
 const markRows=()=>{const mine=new Set();slip.forEach(b=>{mine.add(b.a);if(b.k==='exact')mine.add(b.b)});el.querySelectorAll('.gttrow').forEach(row=>{const l=+row.dataset.l,on=kind==='exact'?(l===ex1||l===sel):l===sel;row.classList.toggle('sel',on);row.setAttribute('aria-checked',on?'true':'false');row.classList.toggle('mine',mine.has(l));
   row.classList.toggle('first',kind==='exact'&&l===ex1)})};
 const tabsRender=()=>{el.querySelectorAll('.gtttab').forEach(b=>{const on=b.dataset.k===kind;b.classList.toggle('on',on);b.setAttribute('aria-selected',on?'true':'false')});const K=GTTU.K.find(x=>x[0]===kind);const d=$q('#gttdesc');if(d)d.textContent=K[3]};
 const pickRender=()=>{const e=$q('#gttpick'),a=$q('#gttadd');if(!e)return;const b=curBet(),s=stakeNow();let h='';
  if(kind==='exact'){if(ex1==null)h='<b class="q">1st?</b><span>Tap the turkey you think will WIN</span>';else if(sel==null)h=`<b class="q">2nd?</b><span>1st: #${ex1+1} ${nm(ex1)}. Now tap the runner-up</span>`;else h=`<span>#${ex1+1} ${nm(ex1)} then #${sel+1} ${nm(sel)}</span><b>${gttuM(mOf('exact',ex1,sel))}</b>`}
  else if(sel==null)h='<b class="q">Tap a turkey</b><span>to back it on the race card</span>';else h=`<span>#${sel+1} ${nm(sel)}</span><b>${gttuM(mOf(kind,sel))}</b>`;
  e.innerHTML=h;const m=b&&mOf(b.k,b.a,b.b);a.querySelector('small').textContent=m&&s>=GTT.minBet?`returns ${cmn(Math.min(GTT.cap,Math.floor(s*m)))}`:'';a.disabled=false};
 const slipRender=()=>{const box=$q('#gttslip');if(!box)return;
  box.innerHTML=slip.length?slip.map((b,i)=>`<div class="gttsl"><i>${GTTU.kn[b.k]}</i><span><b>${gttuLbl(card,b,1)}</b><small>${cmn(b.stake)} at ${b.mult?gttuM(b.mult):'…'}</small></span><u>${b.mult?cmn(gttuRet(b)):'…'}</u><button data-rm="${i}" aria-label="Remove this bet">✕</button></div>`).join(''):'<div class="gttempty">No bets yet. Tap a turkey, then press Start, or build up to three bets with Add to slip.</div>';
  box.querySelectorAll('[data-rm]').forEach(b=>b.onclick=()=>rmBet(+b.dataset.rm));
  const st0=total(),pos=slip.reduce((a,b)=>a+(b.mult?Math.floor(b.stake*b.mult):0),0),cap=pos>GTT.cap;
  $q('#gtttot').innerHTML=`<div><small>Total stake</small><b><i class="gttcn"></i>${cmn(st0)}</b></div><div><small>Possible return</small><b><i class="gttcn"></i>${cmn(Math.min(GTT.cap,pos))}</b></div>
   <p class="${cap?'cap':''}">${cap?'Capped at '+cmn(GTT.cap)+' for the race':'Max payout '+cmn(GTT.cap)+' per race'}</p>`;
  const go=$q('#gttgo2');if(go)go.disabled=!px};
 const paddock=()=>{ph='paddock';overlay=null;stopLoop();
  el.innerHTML=`<div class="gttw" id="gttw"><div class="gttl">
   <div class="gtth"><h3>Today's race card</h3><span class="gttchip" id="gttno"></span><span class="gttchip" id="gttgo"></span><span class="gttchip" id="gttwx"></span><button class="gtthelp" id="gtthelp" aria-label="How to play" title="How to play">?</button></div>
   <div class="gttcard" id="gttcard" role="radiogroup" aria-label="The race card"></div>
   <div class="gttfoot"><button class="gttbtn" id="gttnew">New card <kbd>N</kbd></button><button class="gttbtn" id="gttstat">My stats</button><span id="gttpricing" class="gttpr">Setting the odds...</span><span class="gttleg">Form: last five finishes</span></div></div>
   <div class="gtts"><h4>Bet slip</h4><div class="gtttabs" role="tablist">${GTTU.K.map(k=>`<button class="gtttab" role="tab" data-k="${k[0]}"><b>${k[1]}</b><kbd>${k[2]}</kbd></button>`).join('')}</div>
    <p class="gttdesc" id="gttdesc"></p><div class="gttpick" id="gttpick"></div>
    <div class="ctl gttst">${betBar('Stake')}</div>
    <button class="gttadd" id="gttadd"><b>Add to slip</b><small></small><kbd>Enter</kbd></button>
    <div class="gttslip" id="gttslip"></div><div class="gtttot" id="gtttot"></div>
    <button class="bbig gttgo" id="gttgo2">Start race <kbd>Space</kbd></button><p class="cmsg" id="cm"> </p></div></div>`;
  $q('#gtthelp').onclick=()=>howTo();$q('#gttnew').onclick=()=>userNew();$q('#gttstat').onclick=()=>statsWin();
  el.querySelectorAll('.gtttab').forEach(b=>b.onclick=()=>setKind(b.dataset.k));$q('#gttadd').onclick=()=>addBet();$q('#gttgo2').onclick=()=>start();
  wireBet(()=>{oddsRender();pickRender();slipRender()});headRender();paddockCards();tabsRender();pickRender();slipRender();
  if(!px)msg('Setting the odds...')};
 const userNew=()=>{if(ph!=='paddock'||CAS.lock)return;const had=slip.length;newCard();beep(620,.05,'triangle',.5);msg(had?'New card. Your slip was cleared.':'New card drawn. Pick your turkey.')};
 /* ===== tutorial / stats windows ===== */
 const closeOverlay=()=>{if(overlay){overlay.remove();overlay=null;return true}return false};
 const howTo=done=>{closeOverlay();const w=$q('.gttw');if(!w)return;const d=document.createElement('div');d.className='gttmod gtthow';overlay=d;
  d.innerHTML=`<h3>How to play The Great Turkey Trot</h3><div class="gtthg">
   <div><i class="gttil il1"><span>#3</span><em>×4.2</em></i><b>1. Pick a turkey</b><p>Tap a runner on the race card. The big number is what a winning bet pays: ×4 turns 100 into 400.</p></div>
   <div><i class="gttil il2"><u>Win</u><u>Top 2</u><u>Top 3</u><u>Exact</u></i><b>2. Choose a bet</b><p>Win is first place. Top 2 and Top 3 are safer and pay less. Exact 1-2 picks the winner and the runner-up in order. Up to three bets, then Start.</p></div>
   <div><i class="gttil il3"><span class="gttdots"><s></s><s></s><s></s></span><em>Cash out 340</em></i><b>3. Watch and cash out</b><p>Your turkeys wear a gold ring. If one is fading, Cash out (C) takes a fair offer right now. The result is fixed when the race starts.</p></div></div>
   <button class="bbig" id="gtthok">Got it</button>`;w.appendChild(d);g0().seen=1;save();const ok=$q('#gtthok');ok.onclick=()=>{closeOverlay();if(done)done()};try{ok.focus()}catch(e){}};
 const statsWin=()=>{closeOverlay();const w=$q('.gttw');if(!w)return;const g=g0(),d=document.createElement('div');d.className='gttmod gttstw';overlay=d;
  const fav=Object.entries(g.fav||{}).sort((a,b)=>b[1]-a[1])[0],favN=fav?gttuR(fav[0]).n+' ('+fav[1]+' bets)':'none yet';
  const rows=GTT_RUN.map(r=>{const q=(g.rec||{})[r.id]||{s:0,w:0,p:0};return `<tr><td>${r.n}</td><td>${q.s}</td><td>${q.w}</td><td>${q.p}</td>${GTTU.hidden?`<td class="hid">spd ${r.spd} sta ${r.sta} kick ${r.kick} gate ${r.gate} wild ${r.wild}</td>`:''}</tr>`}).join('');
  d.innerHTML=`<h3>Your Turkey Trot stats</h3><div class="gttstg"><div><small>Races</small><b>${cmn(g.races)}</b></div><div><small>Winning bets</small><b>${cmn(g.wins)}</b></div><div><small>Best race payout</small><b>${cmn(g.best)}</b></div><div><small>Longest winning shot</small><b>${g.long?gttuM(g.long):'none yet'}</b></div><div><small>Favourite turkey</small><b>${favN}</b></div><div><small>Bets placed</small><b>${cmn(g.bets)}</b></div></div>
   <div class="gttstt"><table><thead><tr><th>Turkey</th><th>Starts</th><th>Wins</th><th>Top 3</th>${GTTU.hidden?'<th>Hidden stats</th>':''}</tr></thead><tbody>${rows}</tbody></table></div><button class="bbig" id="gttsok">Close</button>`;w.appendChild(d);$q('#gttsok').onclick=()=>closeOverlay();try{$q('#gttsok').focus()}catch(e){}};
 /* ===== starting, racing ===== */
 const cashed=i=>(rec.cash||[]).some(c=>c.i===i);
 const mineLanes=()=>{const s=new Set();(rec?rec.bets:slip).forEach(b=>{s.add(b.a);if(b.k==='exact')s.add(b.b)});return[...s]};
 const start=()=>{if(ph!=='paddock'||CAS.lock||overlay)return;
  if(!px){msg('Setting the odds... one moment.');return}
  if(!slip.length&&!addBet(true))return;
  const tot=total();if(tot>P.gold){msg(broke()||'Not enough gold for these bets.','l');return}
  if(tot>GTT.maxTotal||slip.length>GTT.maxBets||slip.some(b=>b.stake<GTT.minBet||b.stake>GTT.maxBet||!b.mult)){msg('Please check your slip.','l');return}
  const r={cardSeed:cseed,raceSeed:gttuSeed('race'),bets:slip.map(b=>b.k==='exact'?{k:b.k,a:b.a,b:b.b,stake:b.stake,mult:b.mult}:{k:b.k,a:b.a,stake:b.stake,mult:b.mult}),cash:[],t0:Date.now()};
  g0().pend=r;if(!cTake(tot)){g0().pend=null;msg(broke()||'Not enough gold for these bets.','l');return}
  rec=r;betLock(true);ensureAudio();beginRace()};
 const say=(txt,o)=>{if(!txt)return;o=o||{};if(!o.force&&tt-lastSay<.9)return;lastSay=tt;const b=$q('#gttsay');if(!b)return;const p=document.createElement('p');p.textContent=txt;if(o.mine)p.className='mine';b.appendChild(p);while(b.children.length>2)b.firstChild.remove();
  try{gttSnd.ding()}catch(e){}};
 const sayT=(k,l,m)=>{let A=GTTU.say[k];try{if(typeof GTT_SAY==='object'&&GTT_SAY&&Array.isArray(GTT_SAY[k])&&GTT_SAY[k].length&&GTT_SAY[k].every(x=>typeof x==='string'))A=GTT_SAY[k]}catch(e){}
  if(!A)return'';const v={n:l!=null&&l>=0?nm(l):'',m:m!=null&&m>=0?nm(m):'',j:l!=null&&l>=0?((runner(l).jockey||{}).n||''):''};
  const ok=A.filter(t=>(!/\{n\}/.test(t)||v.n)&&(!/\{m\}/.test(t)||v.m)&&(!/\{j\}/.test(t)||v.j)),L=ok.length?ok:A,t=L[(Math.random()*L.length)|0];
  return typeof gttSayFmt==='function'?gttSayFmt(t,v):t.replace(/\{(\w)\}/g,(_,c)=>v[c]||'')};
 const banner=t=>{const b=$q('#gttban');if(!b)return;b.textContent=t;b.classList.remove('on');void b.offsetWidth;b.classList.add('on')};
 const beginRace=()=>{warmN=0;wcv=null;ph='gate';gateT=0;acc=0;evI=0;winT=-1;said={};lastSay=-9;lastLead=-1;offers=[];offAt=[];lastCo=0;job=null;cam=null;clock=0;gateOpen=false;photoT=0;
  fin=gttRun(card,rec.raceSeed);st=gttSimNew(card,rec.raceSeed);raceDom();
  try{gttSnd.call()}catch(e){}banner('Call to the post!');say('The turkeys step up to the gate...',{force:1});startLoop()};
 let dots=[];
 const raceDom=()=>{const mine=new Set(mineLanes());
  el.innerHTML=`<div class="gttw gttrace" id="gttrace"><canvas id="gttrc" width="1600" height="900"></canvas>
   <div class="gttclk"><b id="gttclkt">0:00.0</b><small>Race ${card.no} · ${GTTU.going[card.going]||''}</small></div>
   <div class="gttps" id="gttps" aria-hidden="true"><div class="gttpsl"></div><s class="gttpsf" title="Finish"></s>${card.field.map((_,l)=>{const s=runner(l).silk||['#ffd45a','#c87a2a'];return `<i class="gttpd${mine.has(l)?' mine':''}" data-l="${l}" style="top:${l%2?27:3}px;background:${s[0]};color:${gttuInk(s[0])}"><b>${l+1}</b></i>`}).join('')}</div>
   <div class="gttbets" id="gttbets"><h5>Your bets</h5>${rec.bets.map((b,i)=>`<div class="gttb" data-i="${i}"><span class="gttbk">${GTTU.kn[b.k]}</span><b>${gttuLbl(card,b,1)}</b><small><span>${cmn(b.stake)} at ${gttuM(b.mult)}</span><em class="now">–</em></small>
     <button class="gttco" data-i="${i}" disabled><span>Cash out</span><u>–</u></button></div>`).join('')}<p class="gttcoh">Press <kbd>C</kbd> to cash out</p></div>
   <div class="gttsay" id="gttsay"></div><button class="gttskip" id="gttskip">Skip to result <kbd>▸▸</kbd></button><div class="gttban" id="gttban"></div></div>`;
  cv=$q('#gttrc');cg=cv.getContext('2d');dots=[...el.querySelectorAll('.gttpd')];
  el.querySelectorAll('.gttco').forEach(b=>b.onclick=()=>doCash(+b.dataset.i));$q('#gttskip').onclick=()=>skipRace()};
 const coLabel=i=>{const b=$q(`.gttb[data-i="${i}"]`);if(!b)return;const bt=b.querySelector('.gttco'),u=bt.querySelector('u'),done=cashed(i);
  if(done){const c=rec.cash.find(c=>c.i===i);b.classList.add('done');bt.hidden=true;let e=b.querySelector('.gttdone');if(!e){e=document.createElement('em');e.className='gttdone';b.appendChild(e)}e.textContent='Cashed out '+cmn(c.pay);return}
  const o=offers[i],closed=st&&Math.max(...st.run.map(q=>q.x))>=GTT.len*.9;
  if(closed){bt.disabled=true;u.textContent='closed';bt.classList.add('off')}else if(o>=1){bt.disabled=false;bt.classList.remove('off');u.textContent=cmn(o)}else{bt.disabled=true;u.textContent=o===0&&offAt[i]?'–':'…'}};
 const capLeft=()=>Math.max(0,GTT.cap-rec.cash.reduce((a,c)=>a+c.pay,0));
 /* all live bets are priced from ONE set of continuations about once a second (gttOffers; one gttOffer per bet when it is missing) */
 const priceBets=(idx,n,salt)=>{const bs=idx.map(i=>rec.bets[i]);let os;try{os=typeof gttOffers==='function'?gttOffers(st,bs,n,salt):bs.map(b=>gttOffer(st,b,n,salt))}catch(e){console.error(e);os=bs.map(()=>0)}return os.map(o=>Math.floor(o)||0)};
 /* the labels are refreshed about once a second from 10 slices of 30 continuations, one slice per frame (about 2 ms each), averaged: the same estimate as one 300-run pricing without one long frame */
 let job=null;const OJN=10,OJR=30;
 const offerTick=now=>{if(ph!=='race'||st.t<1)return;const live=[];rec.bets.forEach((b,i)=>{if(!cashed(i))live.push(i)});if(!live.length){job=null;return}
  if(!job){if(lastCo&&now-lastCo<800){if(!offerTick.c||now-offerTick.c>400){offerTick.c=now;live.forEach(i=>coLabel(i))}return}job={k:0,sum:new Map()}}
  const os=priceBets(live,OJR,st.n*31+job.k);live.forEach((i,j)=>job.sum.set(i,(job.sum.get(i)||0)+os[j]));job.k++;
  if(job.k>=OJN){const cl=capLeft();live.forEach(i=>{offers[i]=Math.min(Math.floor(job.sum.get(i)/OJN),cl);offAt[i]=now;coLabel(i)});job=null;lastCo=now}};
 const doCash=i=>{if(ph!=='race'||!rec||!rec.bets[i]||cashed(i))return;const o=Math.min(priceBets([i])[0],capLeft());/* priced afresh at the click, never from a stale label */
  if(!(o>=1)){msg('No cash-out offer right now.');return}
  const b=rec.bets[i],pay=gttuCash(i,o);if(!pay)return;offers[i]=0;coLabel(i);try{gttSnd.ding()}catch(e){}
  msg(`Cashed out ${gttuLbl(card,b)} for ${cmn(pay)} (stake ${cmn(b.stake)}).`,pay>b.stake?'w':'')};
 const cashAny=()=>{if(ph!=='race'||!rec)return;for(let i=0;i<rec.bets.length;i++)if(!cashed(i)){doCash(i);if(cashed(i))return}msg('Nothing to cash out.')};
 const collect=()=>{const L=st.ev;while(evI<L.length){const e=L[evI++],k=e.k,l=e.lane,mine=l!=null&&l>=0&&mineLanes().includes(l);
   if(GTTU.say[k]){say(sayT(k,k==='gust'?null:l),{mine});if(k!=='gust'&&l>=0)try{gttSnd.gobble(l)}catch(x){}}}
  const R2=st.run;let lead=-1,sec=-1,mx=0;for(const q of R2){if(q.x>mx){mx=q.x;lead=q.lane}}for(const q of R2)if(q.lane!==lead&&(sec<0||q.x>R2[sec].x))sec=q.lane;
  if(lead!==lastLead&&st.t>2.5){if(lastLead>=0&&!(mx<20))say(sayT('lead',lead,lastLead),{mine:mineLanes().includes(lead)});lastLead=lead}else if(lastLead<0&&st.t>2.5)lastLead=lead;
  if(mx>=GTT.len*.5&&!said.half){said.half=1;say(sayT('mid',lead,sec),{force:1})}
  if(mx>=GTT.len*.82&&!said.last){said.last=1;say(sayT('final',lead,sec),{force:1})}
  if(winT<0&&R2.some(q=>q.fin!==null)){winT=tt;const w=R2.reduce((a,q)=>q.fin!==null&&(a===null||q.fin<a.fin)?q:a,null);if(w&&!fin.photo){say(sayT('win',w.lane),{force:1,mine:mineLanes().includes(w.lane)});try{gttSnd.gobble(w.lane)}catch(x){}}}};
 const hud=()=>{for(let l=0;l<6;l++){const q=st.run[l];dots[l].style.transform=`translateX(${(Math.min(1,q.x/GTT.len)*GTTU.dw).toFixed(1)}px)`}
  const c=gttuFmtT(st.t);if(c!==clock){clock=c;$q('#gttclkt').textContent=c;
   el.querySelectorAll('.gttb').forEach(b=>{const bet=rec.bets[+b.dataset.i],n=b.querySelector('.now');const p=l=>gttuOrd(st.run[l].pos);n.textContent=bet.k==='exact'?`now ${p(bet.a)} / ${p(bet.b)}`:`now ${p(bet.a)}`})}};
 let drawMs=0,drawN=0;
 /* a slow machine (software canvas) draws every second frame while the race itself keeps full time: drawMs is the running cost of one draw */
 const drawRace=()=>{try{const c2=gttCam(st,cam);if(c2)cam=c2}catch(e){}if(!cam)cam={x:0,zoom:1};if(drawMs>12&&(drawN++&1))return;const a=performance.now();gttDrawRace(cg,st,cam,{t:tt,mine:mineLanes(),low:LOW(),going:card.going,weather:card.weather});{const d=Math.min(30,performance.now()-a);drawMs=drawMs?drawMs*.92+d*.08:d}};
 const startPhoto=()=>{ph='photo';photoT=0;el.classList.add('gttph');try{gttSnd.shutter()}catch(e){}say(sayT('photo'),{force:1})};
 const skipRace=()=>{if(ph==='over'||!st)return;if(ph==='gate'||ph==='race'||ph==='photo'){let g=0;while(!st.done&&g++<20000)gttStep(st);finishRace()}};
 const finishRace=()=>{if(ph==='over')return;ph='over';el.classList.remove('gttph');try{gttSnd.stop()}catch(e){}
  R=gttuSettle(fin);if(!R){R=gttuLines(rec,fin);R.card=card;R.fin=fin;R.rec=rec;R.wins=R.lines.filter(l=>l.won).length;R.acorns=0}
  betLock(false);resultsDom();
  setTimeout(()=>{if(!alive())return;const net=R.paid-R.staked;try{if(R.paid>0&&net>=0)gttSnd.win(net>=2000);else if(R.paid===0)gttSnd.lose()}catch(e){}},300)};
 /* the first draw of the race scene at a new zoom, of the podium and of the photo bakes images: do those once, off screen, while the turkeys stand at the gate */
 let wcv=null,warmN=0;
 const warm=()=>{try{if(!wcv){wcv=document.createElement('canvas');wcv.width=1600;wcv.height=900}const g=wcv.getContext('2d'),n=++warmN;
   if(n===1){const c2=gttCam(fin,null);gttDrawRace(g,fin,c2||{x:0,zoom:1},{t:0,mine:[],low:LOW(),going:card.going,weather:card.weather})}else if(n===2)gttDrawPodium(g,fin,0);else if(n===3&&fin.photo)gttPhoto(g,1,fin);
   else if(n>=4||(n===3&&!fin.photo)){wcv=null;warmN=9}}catch(e){wcv=null;warmN=9}};
 const stepFrame=dt=>{
  if(ph==='gate'){gateT+=dt;const T=rm?1.3:2.5;drawRace();if(warmN<9)warm();
   if(!said.u&&gateT>T-1.0){said.u=1;banner("Under starter's orders...")}
   if(gateT>=T){ph='race';acc=0;try{gttSnd.gate()}catch(e){}banner("And they're off!");say(sayT('gate'),{force:1});if(!LOW()){const r=$q('#gttrace');if(r){r.classList.remove('shk');void r.offsetWidth;r.classList.add('shk')}}}}
  else if(ph==='race'){acc+=dt*GTTU.fast;let n=0;while(acc>=STEP&&!st.done&&n<24){gttStep(st);acc-=STEP;n++}
   if(n){collect();if((st.n&3)===0){let lead=0;for(const q of st.run)if(q.x>st.run[lead].x)lead=q.lane;if(st.t-stepT>.14){stepT=st.t;try{gttSnd.step(lead)}catch(e){}}}}
   hud();drawRace();offerTick(performance.now());
   {const mx=Math.max(...st.run.map(q=>q.x))/GTT.len,lv=Math.max(0,Math.min(1,(mx-.5)/.5));if((st.n&7)===0)try{gttSnd.crowd(.14+.86*lv*lv)}catch(e){}}
   if(fin.photo&&st.run[fin.photo.a]&&(st.run[fin.photo.a].fin!==null||st.run[fin.photo.b].fin!==null))startPhoto();
   else if(st.done||(winT>=0&&tt-winT>4.5))finishRace()}
  else if(ph==='photo'){photoT+=dt;try{gttPhoto(cg,Math.min(2.5,photoT),fin)}catch(e){console.error(e)}if(photoT>=3.4)finishRace()}
  else if(ph==='over'){resT+=dt;if(pcg){try{pcg.setTransform(1,0,0,1,0,0);pcg.clearRect(0,0,pcv.width,pcv.height);pcg.setTransform(pcv.width/1600,0,0,pcv.height/900,0,0);gttDrawPodium(pcg,fin,resT)}catch(e){console.error(e)}}/* 10.5: clear every frame (the light shafts are translucent and piled up) */confDraw(dt)}};
 const frame=now=>{if(!alive()||!el.isConnected){loopOn=false;try{gttSnd.stop()}catch(e){}return}if(!loopOn)return;const dt=Math.min(.1,(now-last)/1000);last=now;tt+=dt;
  try{if(!GTTU.hold)stepFrame(dt);errN=0}catch(e){console.error(e);/* a race that keeps failing is finished from its seeds instead of hanging with the stakes taken */if(++errN>30&&rec&&fin&&(ph==='race'||ph==='gate'||ph==='photo')){errN=0;try{ph='race';finishRace()}catch(x){console.error(x)}}}
  if(loopOn)requestAnimationFrame(frame)};
 function startLoop(){if(loopOn)return;loopOn=true;last=performance.now();requestAnimationFrame(frame)}
 function stopLoop(){loopOn=false}
 /* ===== results ===== */
 const confBurst=n=>{const cols=['#ffd45a','#ff8a2a','#9fe8ff','#7dff9a','#ff6a9a','#ffffff'];n=LOW()?Math.ceil(n/3):n;for(let i=0;i<n;i++)conf.push({x:100+Math.random()*680,y:-10-Math.random()*120,vx:(Math.random()-.5)*90,vy:90+Math.random()*160,a:Math.random()*6,va:(Math.random()-.5)*9,s:4+Math.random()*4,c:cols[i%cols.length],l:3.5+Math.random()*1.5})};
 const confDraw=dt=>{if(!ccg)return;ccg.clearRect(0,0,880,495);if(!conf.length)return;for(let i=conf.length-1;i>=0;i--){const p=conf[i];p.l-=dt;if(p.l<=0||p.y>520){conf.splice(i,1);continue}p.x+=p.vx*dt;p.y+=p.vy*dt;p.a+=p.va*dt;p.vx*=.995;
   ccg.save();ccg.translate(p.x,p.y);ccg.rotate(p.a);ccg.fillStyle=p.c;ccg.fillRect(-p.s/2,-p.s/3,p.s,p.s*.66);ccg.restore()}};
 const resultsDom=()=>{stopLoop();const lines=R.lines,net=R.paid-R.staked,pho=!!R.photo,order=fin.order,times=fin.times||[];
  const tl=l=>times[l];const orderHtml=order.map((l,i)=>{const r=runner(l),s=r.silk||['#ffd45a','#c87a2a'];return `<div class="gttor${i===0?' w':''}"><i style="background:${s[0]};color:${gttuInk(s[0])}">${l+1}</i><span><b>${gttuOrd(i+1)}</b> ${r.n}</span><u>${tl(l)!=null?(i===0?tl(l).toFixed(2)+'s':'+'+(tl(l)-tl(order[0])).toFixed(2)):''}</u></div>`}).join('');
  const lh=lines.map(l=>{const b=l.bet,cls=l.cashed?'cash':l.won?'won':'lost',mark=l.cashed?'$':l.won?'✓':'✕',amt=l.cashed?'cashed out '+cmn(l.pay):l.won?'paid '+cmn(l.pay):'lost '+cmn(b.stake);
   return `<div class="gttrl ${cls}"><i>${mark}</i><span><b>${GTTU.kn[b.k]} · ${gttuLbl(card,b,1)}</b><small>${cmn(b.stake)} at ${gttuM(b.mult)}</small></span><u>${amt}</u></div>`}).join('');
  el.innerHTML=`<div class="gttw gttres"><div class="gttrcl"><div class="gttrh"><h3>Race ${card.no} · the result</h3>${pho?'<span class="gttchip ph">Photo finish</span>':''}<span class="gttchip">${GTTU.going[card.going]||''}</span></div>
   <div class="gttpod"><canvas id="gttpc" width="1600" height="900"></canvas><canvas id="gttcf" width="880" height="495"></canvas></div><div class="gttorder">${orderHtml}</div></div>
   <div class="gttrcr"><h4>Your bets</h4>${note?`<p class="gttnote">${note}</p>`:''}<div class="gttrb">${lh}</div>
    <div class="gttrt"><div><small>Staked</small><b>${cmn(R.staked)}</b></div><div><small>Paid</small><b>${cmn(R.paid)}</b></div><div class="${net>0?'up':net<0?'dn':''}"><small>Net</small><b>${net>0?'+':net<0?'−':''}${cmn(Math.abs(net))}</b></div></div>
    ${R.capped?`<p class="gttcapn">Capped at ${cmn(GTT.cap)} for the race</p>`:''}${R.acorns?`<p class="gttac"><i></i>+${R.acorns} acorns from the Harvest Festival</p>`:''}
    <div class="gttrec"><h5>Your Turkey Trot record</h5><div><span><b>${cmn(g0().races)}</b>races</span><span><b>${cmn(g0().wins)}</b>winning bets</span><span><b>${cmn(g0().best)}</b>best payout</span></div></div>
    <p class="cmsg" id="cm"> </p>
    <div class="gttrbtn"><button class="bbig gttagain" id="gttagain">Race again <kbd>Enter</kbd></button><div><button class="gttbtn" id="gttnew2">New card <kbd>N</kbd></button><button class="gttbtn" id="gttback">Back <kbd>Esc</kbd></button></div></div></div></div>`;
  pcv=$q('#gttpc');pcg=pcv.getContext('2d');ccv=$q('#gttcf');ccg=ccv.getContext('2d');conf=[];resT=0;if(R.paid>0)confBurst(R.paid>=R.staked?90:30);
  $q('#gttagain').onclick=()=>again();$q('#gttnew2').onclick=()=>newOnly();$q('#gttback').onclick=()=>{if(!CAS.lock)lobby()};
  msg(R.paid>R.staked?`A winner! ${cmn(R.paid)} paid, ${cmn(R.paid-R.staked)} up.`:R.paid>0?`${cmn(R.paid)} paid back on ${cmn(R.staked)} staked.`:`No luck this time. ${broke()||'Race again?'}`,R.paid>R.staked?'w':R.paid>0?'':'l');
  startLoop()};
 const again=()=>{if(ph!=='over'||CAS.lock)return;const prev=rec?rec.bets:[];note='';newCard(undefined,prev);ph='paddock';kind='win';paddock();msg(slip.length?'Same bets on a new card. Check the odds, then press Start (Space).':'New card. Pick your turkey.')};
 const newOnly=()=>{if(ph!=='over'||CAS.lock)return;note='';newCard();ph='paddock';kind='win';paddock();msg('New card. Pick your turkey.')};
 /* ===== input ===== */
 const free=()=>!overlay;
 CAS.key={'1':()=>free()&&pick(0),'2':()=>free()&&pick(1),'3':()=>free()&&pick(2),'4':()=>free()&&pick(3),'5':()=>free()&&pick(4),'6':()=>free()&&pick(5),
  w:()=>free()&&setKind('win'),t:()=>free()&&setKind('top2'),p:()=>free()&&setKind('top3'),e:()=>free()&&setKind('exact'),
  '+':()=>free()&&setStake(1),'=':()=>free()&&setStake(1),'-':()=>free()&&setStake(-1),'_':()=>free()&&setStake(-1),
  enter:()=>{if(closeOverlay())return;if(ph==='paddock')addBet();else if(ph==='over')again()},' ':()=>{if(closeOverlay())return;if(ph==='paddock')start()},
  c:()=>cashAny(),n:()=>{if(overlay)return;if(ph==='paddock')userNew();else if(ph==='over')newOnly()},
  arrowup:()=>{if(ph==='paddock'&&free())pick(Math.max(0,(sel==null?(ex1==null?1:ex1):sel)-1))},arrowdown:()=>{if(ph==='paddock'&&free())pick(Math.min(5,(sel==null?(ex1==null?-1:ex1):sel)+1))},
  arrowleft:()=>{if(ph==='paddock'&&free()){const i=GTTU.K.findIndex(k=>k[0]===kind);setKind(GTTU.K[(i+3)%4][0])}},arrowright:()=>{if(ph==='paddock'&&free()){const i=GTTU.K.findIndex(k=>k[0]===kind);setKind(GTTU.K[(i+1)%4][0])}}};
 {const b0=S.back;S.back=()=>{if(CAS.lock)return;if(closeOverlay())return;b0()};const cb=$('cb');if(cb)cb.onclick=S.back}
 /* leaving with a race pending (the Lobby is locked during a race, so this is a safety net): finish it now, pay once */
 CAS.flush=()=>{stopLoop();priceStop();try{gttSnd.stop()}catch(e){}if(g0().pend)GTTU.lastFlush=gttuFinishNow()};
 GTTU.cur={ph:()=>ph,card:()=>card,px:()=>px,slip:()=>slip,fin:()=>fin,st:()=>st,R:()=>R,rec:()=>rec,sel:()=>sel,ex1:()=>ex1,kind:()=>kind,offers:()=>offers,cam:()=>cam,overlay:()=>!!overlay,
  newCard:(s)=>{newCard(s);if(ph==='paddock'||ph==='over'){ph='paddock';kind='win';paddock()}},pick,setKind,add:addBet,start,cash:doCash,skip:skipRace,again,newOnly,rm:rmBet,stats:statsWin,help:howTo,close:closeOverlay,
  frame:(n,dt)=>{dt=dt||1/60;for(let i=0;i<n;i++){tt+=dt;stepFrame(dt)}},tt:()=>tt};
 /* ===== open ===== */
 const pe=g0().pend;
 if(pe){/* a race was pending (reload during a race): finish it now and show how it went */
  card=gttCard(pe.cardSeed);cseed=pe.cardSeed;R=gttuFinishNow();
  if(R){fin=R.fin;rec=R.rec;note='Your race finished while you were away. This is how it went.';ph='over';betLock(false);resultsDom();return}}
 newCard();paddock();
 if(!g0().seen&&!(navigator.webdriver&&!window.GTT_NEWS))setTimeout(()=>{if(alive()&&ph==='paddock'&&!overlay)howTo()},350)}
GTTU.dw=800;
window.GTTDBG={get cur(){return GTTU.cur},ph:()=>GTTU.cur&&GTTU.cur.ph(),card:()=>GTTU.cur&&GTTU.cur.card(),st:()=>GTTU.cur&&GTTU.cur.st(),fin:()=>GTTU.cur&&GTTU.cur.fin(),R:()=>GTTU.cur&&GTTU.cur.R(),pend:()=>P.gtt&&P.gtt.pend,
 setCard:s=>{GTTU.fixCard.push(s>>>0)},setRace:s=>{GTTU.fixRace.push(s>>>0)},speed:n=>{GTTU.fast=n},hold:v=>{GTTU.hold=!!v},skip:()=>GTTU.cur&&GTTU.cur.skip(),hidden:v=>{GTTU.hidden=v?1:0},seeds:()=>({card:GTTU.fixCard.slice(),race:GTTU.fixRace.slice()})};
/* ---------- DEV > Cheats ---------- */
try{const h0=dvxHTML;dvxHTML=function(){let h=h0.apply(this,arguments);try{h+=`<div class="dvx"><h5>Turkey Trot (casino)</h5><div class="dvrow"><span>${GTTU.hidden?'hidden stats shown':'hidden stats off'} · race speed x${GTTU.fast}</span>${dvBtn('x:gtt_hid','Show hidden stats')}${dvBtn('x:gtt_fast','Fast race (x4)')}${dvBtn('x:gtt_seed','Next race seed')}</div></div>`}catch(e){}return h};
 const a0=dvxAct;dvxAct=function(a){if(!/^gtt_/.test(a))return a0.apply(this,arguments);
  if(a==='gtt_hid'){GTTU.hidden=GTTU.hidden?0:1;dvxMsg('Turkey Trot: hidden stats '+(GTTU.hidden?'shown in My stats.':'hidden.'))}
  else if(a==='gtt_fast'){GTTU.fast=GTTU.fast>1?1:4;dvxMsg('Turkey Trot: races run at x'+GTTU.fast+'.')}
  else if(a==='gtt_seed'){GTTU.fixRace.push(++GTTU.seedCtr);dvxMsg('Turkey Trot: the next race uses seed '+GTTU.seedCtr+' (the card stays random).')}}}catch(e){}
