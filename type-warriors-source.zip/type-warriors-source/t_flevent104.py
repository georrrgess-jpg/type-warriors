# python3 t_flevent104.py [game.html] : 10.4 Harvest Festival, the festival itself (99q_fl_event.js, 99q2_fl_event_art.js, 99q3_fl_event_ui.js).
# Acorns (save repair, the daily bag, the ledger, the toast), earning through the game's own finish functions (campaign, Endless,
# Daily Challenge, Tower Defense, Runestone Riddle, Lantern Caravan, Trick-or-Treat, Harvest Moon Rush), Gratitude tasks (seeding,
# progress, claiming, the bonus, next-day payout), the Harvest Calendar (states, doors, catch-up, coins under the cheat guard, the
# Thanksgiving feast and the Golden Harvest Egg), the Harvest Market (every item, confirm step, equip toggles, missing parts),
# trophies, the home card with and without Halloween, the falling leaves (reduced motion, Performance mode, the switch, the
# keepsake), the Events sheet, the grace week, the closed festival, UI fit at 1600x900 / 1280x720 / 1024x640, frame cost and page
# errors. The other parts (chest, companions, Harvest Moon Rush) are stood in by tools/fl/stub_fle.js (test-only, never shipped).
# Screenshots in shots/w104_event/.
import asyncio,json,os,sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 and not sys.argv[1].startswith('-') else os.path.join(HERE,'out.html'))
SHOTS=os.path.join(HERE,'shots','w104_event');os.makedirs(SHOTS,exist_ok=True)
STUB=open(os.path.join(HERE,'..','tools','fl','stub_fle.js')).read()
OVL=open(os.path.join(HERE,'..','tools','td','rpu_ovl.js')).read()
FAIL=[];N=[0];ERR=[]
def chk(name,info,ok):
    ok=bool(ok);N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+json.dumps(info,default=str)[:1500]),flush=True)
    if not ok:FAIL.append(name)
async def mk(b,date,vw=1600,vh=900,stub=True,ac=False,rm=False):
    ctx=await b.new_context(viewport={'width':vw,'height':vh},reduced_motion='reduce' if rm else 'no-preference')
    await ctx.add_init_script("window.TWA_RELAYS=[]")
    if ac:await ctx.add_init_script("window.TW_AC_TEST=1")
    pg=await ctx.new_page();pg.on('pageerror',lambda e:ERR.append(date+': '+str(e)[:300]))
    await pg.clock.install(time=date);await pg.goto(H);await pg.wait_for_timeout(1400)
    await pg.evaluate("()=>{try{RS_ASK=false;ST.perfAsked=1;PFW.asked=true;TPOLL_ON=0}catch(e){}}")
    if stub:
        real=await pg.evaluate("()=>['flcAdd','flcOpenUI','flpGive','flpEggAdd','flpEgg'].filter(k=>typeof window[k]==='function')")
        await pg.add_script_tag(content=STUB)
        if real:await pg.evaluate(SPY,real)
    await pg.add_script_tag(content=OVL);return ctx,pg
# merged build: the real parts are loaded, so the stub defines nothing; these spies call straight through to the real functions and keep
# the stub's counters (companions arrive silently and an egg's hatch scene is closed at once, so the market stays in front for the test)
SPY="""(L)=>{const W=window,F=W.__flStub,has=k=>L.includes(k);
 if(has('flcAdd')){const f=flcAdd;flcAdd=function(n){F.chest+=n;return f.apply(this,arguments)}}
 if(has('flcOpenUI')){const f=flcOpenUI;flcOpenUI=function(){F.open++;return f.apply(this,arguments)}}
 if(has('flpGive')){const f=flpGive;flpGive=function(id,o){F.give.push(id);return f.call(this,id,Object.assign({},o,{silent:1}))}}
 if(has('flpEggAdd')){const f=flpEggAdd;flpEggAdd=function(n){F.egg+=n;return f.apply(this,arguments)}}
 if(has('flpEgg')){const f=flpEgg;flpEgg=function(){const r=f.apply(this,arguments);if(r)F.hatch++;const x=document.getElementById('pthx');if(x){try{x._stop&&x._stop()}catch(e){}x.remove()}return r}}}"""
async def shot(pg,name,wait=700):
    await pg.wait_for_timeout(wait);await pg.screenshot(path=os.path.join(SHOTS,name+'.png'))
FRESH="()=>{load({});P.name='Hero';FLP();save();title()}"
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch()
        # ================= A: Saturday 7 November, Halloween still on =================
        ctx,pg=await mk(b,'2026-11-07T12:00:00');E=pg.evaluate
        await E(FRESH)
        r=await E("()=>[typeof fleAcorns,typeof fleGive,typeof fleSpend,typeof fleHub,typeof fleTask,flOn(),flShopOn(),hwOn(),fleCalNow()]")
        chk('API and dates: festival on, Halloween on, calendar day 7',r,r==['function']*5+[True,True,True,7])
        r=await E("""()=>{load({fl:{ac:'12abc',other:'keep',fe:{cal:{3:1,7:1,x:1,30:1},gt:'bad',buy:{egg:2,zzz:1},lg:[1,{src:'x',d:5,bal:5}],dy:{d:5},tot:-4,lv:'0',gtN:'7'}}});const f=P.fl,e=f.fe;
          const a=[f.ac,f.other,Object.keys(e.cal),e.buy,e.lg.length,e.dy.d,e.tot,e.lv,e.gtN,e.gt.k.length];load({fl:'junk'});const b2=[typeof P.fl,P.fl.ac,typeof P.fl.fe];
          const c=sgShape({fl:{ac:-5,fe:{cal:{9:1}}}});load({});return [a,b2,c.fl.ac,Object.keys(c.fl.fe.cal)]}""")
        chk('save repair on load and import: bad values cleaned, unknown keys of other parts kept',r,r==[[0,'keep',['7'],{'egg':2},1,'',0,1,7,0],['object',0,'object'],0,['9']])
        await E(FRESH)
        r=await E("""()=>{const n=fleGive(30,'calendar');const t=document.getElementById('fletoast'),L=P.fl.fe.lg.slice(-1)[0];return [n,P.fl.ac,!!t&&t.classList.contains('show'),t&&t.textContent.includes('+30'),L.src,L.d,L.bal,P.fl.fe.tot]}""")
        chk('fleGive: acorns, toast, ledger entry, total gathered',r,r==[30,30,True,True,'calendar',30,30,30])
        await shot(pg,'toast_acorns',250)
        r=await E("""()=>{const D=fleToday();D.play=0;D.fr=0;const a=[fleGive(140,'campaign'),fleGive(30,'campaign'),fleGive(4,'towers'),fleGive(2,'fishing'),fleGive(2,'fishing'),fleGive(45,'task')];return [a,fleToday().play]}""")
        chk('daily bag: 150 play acorns at full rate, then a quarter (fractions carry), tasks uncapped',r,r==[[140,15,1,0,1,45],150])
        r=await E("()=>{P.fl.ac=100;const s0=P.fl.fe.sp;return [fleSpend(150),fleSpend(60),P.fl.ac,P.fl.fe.sp-s0,fleSpend(0),fleSpend(-5)]}")
        chk('fleSpend: refuses too much / nonsense, spends and counts',r,r==[False,True,40,60,False,False])
        r=await E("()=>{window.FL_FORCE=-1;const a=[fleGive(10,'calendar'),fleSpend(1),flOn()];title();const c=!!document.getElementById('dkflc');window.FL_FORCE=undefined;title();return [a,c,!!document.getElementById('dkflc')]}")
        chk('FL_FORCE=-1 switches it all off (no acorns, no card)',r,r==[[0,False,False],False,True])
        # ---- earning through the game's own finish functions ----
        await E(FRESH)
        r=await E("""async()=>{const sl=ms=>new Promise(r=>setTimeout(r,ms));const out={};const d=()=>P.fl.ac;let a;
          a=d();start(1);S.dmgTaken=0;victory();out.camp3=d()-a;out.run=S.fleRun;out.res=resBlock().includes('flres');await sl(50);
          a=d();start(2);S.dmgTaken=5;victory();out.camp1=d()-a;
          a=d();start(2);S.ok=80;over(false);out.loss=d()-a;
          a=d();start(2);S.ok=80;over(true);out.quit=d()-a;
          a=d();start(0);S.wave=5;startWave();out.end5=d()-a;S.wave=6;startWave();out.end6=d()-a;a=d();if(typeof flrMenu==='function')start(0,'flr');else{start(0);S.flr=1;S.gy=1}S.wave=10;startWave();out.rushRounds=d()-a;S.flr=0;S.gy=0;
          a=d();dcRecord(dcKey(),{key:dcKey(),n:1,win:1,score:1,wpm:30,acc:90});out.dc=d()-a;
          a=d();S.prac={};out.pracLive=fleLive();S.prac=null;title();return out}""")
        chk('campaign win by stars (14 / 10), loss 3, quit 0, Endless 8 per 5 rounds (not in Harvest Moon Rush), Daily Challenge 15, results line, practice pays nothing',r,
            r=={'camp3':14,'run':14,'res':True,'camp1':10,'loss':3,'quit':0,'end5':8,'end6':8,'rushRounds':0,'dc':15,'pracLive':False})
        r=await E("""()=>{const out={};const d=()=>P.fl.ac;let a=d();rpStart('moss');const R=RPX;R.tut=null;rpFinish(true);out.win=d()-a;out.st=R.result.stars;title();
          a=d();rpStart('moss');RPX.tut=null;RPX.wave=5;rpFinish(false);out.loss=d()-a;title();a=d();rpStart('moss');RPX.tut=null;RPX.wave=2;rpFinish(false);out.early=d()-a;title();return out}""")
        chk('Tower Defense: a 3-star win 22, a loss after 3 waves 5, an early loss 0',r,r=={'win':22,'st':3,'loss':5,'early':0})
        r=await E("""async()=>{const sl=ms=>new Promise(r=>setTimeout(r,ms));const d=()=>P.fl.ac;let a=d();const R=RRP();delete R.d[rrKey()];rrMenu(title,'d');await sl(300);for(const c of rrWord(rrKey()))rrType(c);rrEnter();await sl(1800);const rr=d()-a;try{rrResClose()}catch(e){}title();
          a=d();wrStart('mill');WRX.int=4;WRX.ok=95;WRX.chars=100;WRX.x=WRX.rt.len;for(let i=0;i<260;i++)wrUpdate(1/60);const wr=d()-a;try{wrLeave()}catch(e){}title();
          a=d();ttNewRun(0);ttFinish(true);const tt=d()-a;TRT.run=null;title();
          a=d();start(0);const n1=fleGive(25,'Harvest Moon Rush'),n2=fleGive(10,'Harvest Moon Rush');const lg=P.fl.fe.lg.slice(-1)[0].src;title();return [rr,wr,tt,n1+n2,d()-a,lg]}""")
        chk("Runestone Riddle 12, Lantern Caravan 14, Trick-or-Treat street 8, Harvest Moon Rush pays uncapped",r,r==[12,14,8,35,35,'Harvest Moon Rush'])
        r=await E("()=>[fsLand,pzMatchEnd,waFinish,riftOver,wcRecord].map(f=>/fleGive/.test(String(f)))")
        chk('Fishing, The Crooked Cue, Arena, Rift and Wildcard finish functions are wrapped',r,r==[True]*5)
        r=await E("()=>{const s=new Set(P.fl.fe.lg.map(x=>x.src));return ['campaign','endless','daily','towers','riddle','caravan','treat','Harvest Moon Rush'].filter(k=>!s.has(k))}")
        chk('the ledger names every source',r,r==[])
        # ---- Gratitude tasks ----
        r=await E("""()=>{const bad=[];for(let i=0;i<40;i++){const d=fleDay(new Date(2026,10,6+i).getTime()),a=fleTasksFor(d),b2=fleTasksFor(d);if(a.join()!==b2.join())bad.push('seed '+d);
          const T=a.map(k=>FLE_TK[k]);if(T.map(t=>t.t).join()!=='0,1,2')bad.push('tiers '+d);if(new Set(T.map(t=>t.ev)).size<3)bad.push('ev '+d);const m=T.filter(t=>t.m!=='any').map(t=>t.m);if(new Set(m).size<m.length)bad.push('mode '+d)}return bad}""")
        chk('Gratitude tasks: same three for everyone each day, easy / medium / hard, three different modes',r,r==[])
        await E(FRESH)
        r=await E("""async()=>{const sl=ms=>new Promise(r=>setTimeout(r,ms));const G=fleGT();const ks=G.k.slice();for(const k of ks){const T=FLE_TK[k];fleTask(T.ev,T.n,1)}await sl(100);const t=document.getElementById('fletoast');
          return [G.p.map((v,i)=>v>=FLE_TK[ks[i]].n),fleTaskReady(),!!t&&t.classList.contains('task')]}""")
        chk('task progress from the game, a task toast, three ready to claim',r,r==[[True]*3,3,True])
        await E("()=>fleHub()");await shot(pg,'hub_tasks_ready',900)
        r=await E("""async()=>{const sl=ms=>new Promise(r=>setTimeout(r,ms));const a=P.fl.ac;for(let i=0;i<3;i++){const b=document.querySelector('[data-fle-cl]');if(!b)return 'no claim button '+i;b.click();await sl(600)}
          const G=fleGT();return [P.fl.ac-a,G.c,G.b,P.fl.fe.gtN,document.querySelectorAll('.flegt.got').length,!!document.querySelector('.flegtb.got')]}""")
        chk('claiming on the hub: +20 +30 +45 and the +25 bonus for all three',r,r==[120,[1,1,1],1,3,3,True])
        await shot(pg,'hub_tasks_done',600)
        r=await E("""()=>{const e=P.fl.fe,G=fleGT();G.c=[0,0,0];G.b=0;G.k.forEach((k,i)=>G.p[i]=i<2?FLE_TK[k].n:0);G.d='2026-11-06';const a=P.fl.ac,n0=e.gtN;const G2=fleGT();
          return [P.fl.ac-a,e.gtN-n0,G2.d,G2.p.join(),!!e.note]}""")
        chk("a new day pays yesterday's finished tasks and posts a note",r,r[0]==50 and r[1]==2 and r[2]=='2026-11-07' and r[3]=='0,0,0' and r[4])
        await E("()=>fleHub()");await pg.wait_for_timeout(500)
        r=await E("()=>[!!document.querySelector('.flehub .flenote'),P.fl.fe.note]");chk('the note shows once on the hub',r,r==[True,''])
        # ---- the calendar ----
        await E(FRESH)
        r=await E("()=>[6,7,8,26].map(fleCalSt)");chk('calendar states on 7 Nov: 6 missed, 7 today, 8 and 26 locked',r,r==['miss','today','lock','lock'])
        await E("()=>{P.fl.ac=100;fleCal()}");await shot(pg,'calendar_7nov',900)
        r=await E("""async()=>{const sl=ms=>new Promise(r=>setTimeout(r,ms));const b8=document.querySelector('[data-fle-day="8"]');b8.click();await sl(50);const lockOk=!P.fl.fe.cal[8]&&b8.classList.contains('nope');
          const c0=P[FL.chest.cnt]|0;document.querySelector('[data-fle-day="7"]').click();await sl(900);const rev=document.getElementById('flerev');const got=[lockOk,!!rev,rev&&rev.textContent.includes('Harvest Chest'),(P[FL.chest.cnt]|0)-c0,!!P.fl.fe.cal[7],!!(rev&&rev.querySelector('#flerchest'))];return got}""")
        chk("a locked door shakes; today's door opens: reveal, a Harvest Chest, open-the-chest button",r,r==[True,True,True,1,True,True])
        await shot(pg,'calendar_reveal',500)
        r=await E("""async()=>{const sl=ms=>new Promise(r=>setTimeout(r,ms));document.getElementById('flerok').click();await sl(400);const d7=document.querySelector('[data-fle-day="7"]');const a=[!document.getElementById('flerev'),d7.classList.contains('got')];
          d7.click();await sl(100);return a.concat([!document.getElementById('flerev'),fleCalClaim(7)])}""")
        chk('Collect closes it; an opened door cannot pay twice',r,r==[True,True,True,None])
        r=await E("""async()=>{const sl=ms=>new Promise(r=>setTimeout(r,ms));P.fl.ac=100;fleCal();await sl(200);let b=document.querySelector('[data-fle-day="6"]');b.click();await sl(80);const c1=[b.classList.contains('confirm'),P.fl.ac,!!P.fl.fe.cal[6]];
          b.click();await sl(900);const c2=[P.fl.ac,!!P.fl.fe.cal[6],P.fl.fe.cu,!!document.getElementById('flerev')];document.getElementById('flerok').click();await sl(300);
          P.fl.ac=10;P.fl.fe.cal={};fleCal();await sl(200);b=document.querySelector('[data-fle-day="6"]');b.click();await sl(80);const c3=[!!document.getElementById('flemsg'),!!P.fl.fe.cal[6],P.fl.ac];return [c1,c2,c3]}""")
        chk('catch-up: asks first, then 40 acorns for the missed present; not enough acorns says so',r,r==[[True,100,False],[100,True,1,True],[True,False,10]])
        # ---- the market ----
        await E(FRESH)
        await E("()=>{P.fl.ac=12000;fleMarket()}");await shot(pg,'market',1000)
        r=await E("()=>FLE_MK.map(i=>fleMkSt(i.k))");chk('market: every item for sale with the other parts present',r,r==['ok']*8)
        r=await E("""async()=>{const sl=ms=>new Promise(r=>setTimeout(r,ms));const S0=JSON.parse(JSON.stringify(window.__flStub)),a=P.fl.ac,c0=P[FL.chest.cnt]|0;
          document.querySelector('[data-fle-buy="chest"]').click();await sl(300);const ask=document.getElementById('fleask');const r1=[a-P.fl.ac,(P[FL.chest.cnt]|0)-c0,!!ask&&ask.textContent.includes('Open it now')];
          document.getElementById('fleasky').click();await sl(250);r1.push(window.__flStub.open-S0.open);
          if(!document.querySelector('[data-fle-buy="chest5"]')){fleMarket();await sl(300)}/* the real flcOpenUI left the market for the crates menu */
          document.querySelector('[data-fle-buy="chest5"]').click();await sl(300);r1.push((P[FL.chest.cnt]|0)-c0);const k=document.getElementById('fleaskn');if(k)k.click();await sl(200);return r1}""")
        chk('Harvest Chest x1 (150) and x5 (650): chests added, "Open it now" opens the chest screen',r,r==[150,1,True,1,6])
        r=await E("""async()=>{const sl=ms=>new Promise(r=>setTimeout(r,ms));const a=P.fl.ac;const b=document.querySelector('[data-fle-buy="fox"]');b.click();await sl(80);const c1=[b.classList.contains('confirm'),P.fl.ac===a];b.click();await sl(300);
          const card=document.querySelector('.flemi[data-fle-k="fox"]');return c1.concat([a-P.fl.ac,window.__flStub.give.includes(FL.pets.l),card.classList.contains('own'),fleMkSt('fox'),fleBuy('fox')])}""")
        chk('Emberleaf (2,500): a confirm step, then flpGive, then Owned and no second sale',r,r==[True,True,2500,True,True,'own',False])
        r=await E("""async()=>{const sl=ms=>new Promise(r=>setTimeout(r,ms));const B=fleBty();const q=k=>document.querySelector(`[data-fle-buy="${k}"]`);
          q('squir').click();await sl(60);q('squir').click();await sl(400);q('title').click();await sl(400);const t1=[!!B.own['t:harvesthero'],B.title];q('title').click();await sl(100);t1.push(B.title);q('title').click();await sl(100);t1.push(B.title);
          q('trail').click();await sl(250);t1.push(B.trail);const c=document.createElement('canvas');c.width=60;c.height=60;let ok=true;try{btyTrailArt(c.getContext('2d'),'flleaf',30,30,.5,'A',1,1)}catch(e){ok=false}t1.push(ok);
          q('keep').click();await sl(250);t1.push(P.fl.fe.buy.keep|0);t1.push(btyTitle());return t1}""")
        chk('Acorn Scamp; Harvest Hero title (equip / remove); Falling Leaves trail draws; Autumn Keepsake',r,r==[True,'harvesthero','','harvesthero','flleaf',True,1,'Harvest Hero'])
        r=await E("""async()=>{const sl=ms=>new Promise(r=>setTimeout(r,ms));const b=document.querySelector('[data-fle-buy="egg"]');b.click();await sl(60);b.click();await sl(300);const ask=document.getElementById('fleask');const r1=[window.__flStub.egg,!!ask&&ask.textContent.includes('Hatch')];
          document.getElementById('fleasky').click();await sl(200);fleMkRefresh();return r1.concat([window.__flStub.hatch,fleMkSt('egg'),!!P.ach.flt_m1,!!P.ach.flt_m3])}""")
        chk('Golden Harvest Egg (5,000): egg added, "Hatch it now" hatches, then Owned; market trophies earned',r,r==[1,True,1,'own',True,True])
        await shot(pg,'market_bought',700)
        r=await E("()=>{P.fl.ac=50;fleMkRefresh();const b=document.querySelector('[data-fle-buy=\"chest5\"]');return [fleMkSt('chest'),b.disabled,/more/.test(b.title)]}")
        chk('not enough acorns: buttons off with how many more are needed',r,r==['poor',True,True])
        # ---- trophies ----
        r=await E("()=>{const A=ACH.filter(a=>a.cat==='Harvest');P.fl.fe.tot=5000;achCheck();return [A.length,ACAT.includes('Harvest'),!!P.ach.flt_a3,A.every(a=>typeof a.v()==='number')]}")
        chk('nine Harvest trophies in their own category; gathering 5,000 earns Acorn Baron',r,r==[9,True,True,True])
        # ---- home ----
        await E(FRESH)
        r=await E("""()=>{title();const c=document.getElementById('dkflc'),sc=document.querySelector('.dksc');return [!!c,sc.querySelectorAll(':scope>.dkcard').length,!!(c&&c.querySelector('#dkev')),document.querySelectorAll('#dkev').length,!!c.querySelector('#dkfl'),sc.classList.contains('dks4'),document.querySelectorAll('.flleaves .fllf').length]}""")
        chk('home (Halloween on): the festival card takes the events slot with a Halloween button; 4 cards; 14 falling leaves',r,r==[True,4,True,1,True,True,14])
        await shot(pg,'home_1600',1200)
        r=await E("""()=>{const c=document.getElementById('dkflc'),cr=c.getBoundingClientRect(),cl=c.querySelector('.dkcl').getBoundingClientRect(),hw=c.querySelector('#dkev').getBoundingClientRect();if(cl.bottom>cr.bottom-2)return 'text below the card bottom';
          const txt=[...c.querySelectorAll('.dkcl b,.dkcl .dkevl>span,.flecm')].map(e=>{const g=document.createRange();g.selectNodeContents(e);return g.getBoundingClientRect()});
          const hit=txt.some(t=>t.right>hw.left+1&&t.left<hw.right-1&&t.bottom>hw.top+1&&t.top<hw.bottom-1);return [cl.top>=cr.top+2,hw.right<=cr.right&&hw.bottom<=cr.bottom,hit,__rpuOvl(c)]}""")
        chk('the card fits: text inside, Halloween button touches no text, overlap audit clean',r,r==[True,True,False,[]])
        r=await E("""async()=>{const sl=ms=>new Promise(r=>setTimeout(r,ms));document.querySelector('#dkflc #dkev').click();await sl(500);const all=document.querySelectorAll('.dks'),sh=all[all.length-1];const ids=[...sh.querySelectorAll('.dkpv[data-v="e"] .dkm')].map(b=>b.id);
          const vis=!sh.querySelector('.dkpv[data-v="e"]').hidden;return [vis,ids,sh.querySelector('#dkmsh').textContent]}""")
        chk('the Halloween button opens Events: Harvest Festival, Harvest Moon Rush, Trick-or-Treat, Monster Mash',r,r[0] and r[1]==['dmfl','dmflr','dmt','dmg'])
        await shot(pg,'events_sheet',500)
        r=await E("""async()=>{const sl=ms=>new Promise(r=>setTimeout(r,ms));const all=document.querySelectorAll('.dks'),sh=all[all.length-1];sh.querySelector('#dmfl').click();await sl(500);const a=!!document.querySelector('section.flehub');
          title();await sl(300);dkClose(true);modeSheet();await sl(400);const all2=document.querySelectorAll('.dks'),s2=all2[all2.length-1];const v=s2.querySelector('#dmv');const t=v&&v.querySelector('small').textContent;dkClose(true);await sl(250);
          title();await sl(200);document.getElementById('dkfl').click();await sl(400);const b2=!!document.querySelector('section.flehub');title();await sl(200);document.body.focus();
          document.dispatchEvent(new KeyboardEvent('keydown',{key:'v',bubbles:true}));await sl(400);return [a,t,b2,!!document.querySelector('section.flehub')]}""")
        chk('Events card goes to the festival; Choose a mode lists it; the home card and V open the hub',r,r[0] and 'Harvest Festival' in (r[1] or '') and r[2] and r[3])
        r=await E("""async()=>{const sl=ms=>new Promise(r=>setTimeout(r,ms));fleHub();await sl(300);document.getElementById('flelv').click();await sl(100);const off=P.fl.fe.lv;title();await sl(200);const n=document.querySelectorAll('.fllf').length;
          fleHub();await sl(200);document.getElementById('flelv').click();title();await sl(200);return [off,n,document.querySelectorAll('.fllf').length]}""")
        chk('the Leaves switch on the hub turns the home leaves off and on',r,r==[0,0,14])
        r=await E("()=>{ST.perf='low';pfApply();title();const n=document.querySelectorAll('.fllf').length;ST.perf='high';pfApply();title();return [n,document.querySelectorAll('.fllf').length]}")
        chk('Performance mode: no leaves',r,r==[0,14])
        # ---- help, frame cost ----
        await E("()=>{fleHub();fleHow()}");await shot(pg,'help',500)
        r=await E("()=>{const m=document.getElementById('flehow');const o=__rpuOvl(m);document.getElementById('flehx').click();return [o,!document.getElementById('flehow')]}")
        chk('How it works: fits, closes',r,r==[[],True])
        r=await E("""async()=>{const out={};for(const [k,f] of [['tt',()=>ttMenu()],['hub',()=>fleHub()],['market',()=>fleMarket()],['cal',()=>fleCal()]]){f();await new Promise(r=>setTimeout(r,500));
          const t0=performance.now();for(let i=0;i<30;i++)for(const l of LIVE)if(l.cv.isConnected)l.fn(i*.03);const cpu=(performance.now()-t0)/30;
          const T=[];let last=performance.now();await new Promise(res=>{let n=0;const q=t=>{T.push(t-last);last=t;if(++n<90)requestAnimationFrame(q);else res()};requestAnimationFrame(q)});T.shift();T.sort((a,b)=>a-b);out[k]=[+cpu.toFixed(2),+T[T.length>>1].toFixed(1)]}return out}""")
        print('   canvas work per refresh (ms) and median frame (ms):',r)
        chk('frame cost: hub, market and calendar canvases cost well under the Trick-or-Treat menu (the Halloween bar) and frames hold',r,
            r['hub'][0]<max(6,r['tt'][0]*.5) and r['market'][0]<max(8,r['tt'][0]*.5) and r['cal'][0]<1 and all(r[k][1]<=20 for k in r))
        r=await E("""async()=>{title();await new Promise(r=>setTimeout(r,600));const T=[];let last=performance.now();await new Promise(res=>{let n=0;const f=t=>{T.push(t-last);last=t;if(++n<90)requestAnimationFrame(f);else res()};requestAnimationFrame(f)});T.sort((a,b)=>a-b);return Math.round(T[45]*10)/10}""")
        print('   home frame time with leaves (median ms):',r);chk('home with leaves keeps a normal frame time',r,r<40)
        await ctx.close()
        # ================= UI fit at three sizes =================
        for vw,vh in [(1600,900),(1280,720),(1024,640)]:
            ctx,pg=await mk(b,'2026-11-07T12:00:00',vw,vh);E=pg.evaluate;tag=f'{vw}x{vh}'
            await E(FRESH);await E("()=>{P.fl.ac=2600;P.fl.fe.tot=3100;P.fl.fe.cal={6:1};const G=fleGT();G.p[0]=FLE_TK[G.k[0]].n}")
            bad={}
            for nm,js,root in [('home',"title()","document.getElementById('dkflc')"),('hub',"fleHub()","document.querySelector('section.fle')"),('calendar',"fleCal()","document.querySelector('section.fle')"),
                               ('market',"fleMarket()","document.querySelector('section.fle')"),('reveal',"fleCal();fleReveal({day:26,st:'today',gifts:[{k:'ac',v:200,txt:'200 acorns'},{k:'ch',v:2,txt:'2 Harvest Chests'},{k:'gold',v:1,txt:'The Golden Harvest Egg'}]})","document.getElementById('flerev')"),
                               ('events',"title();modeSheet('ev')","(()=>{const a=document.querySelectorAll('.dks');return a[a.length-1]})()")]:
                await E("()=>{const r=document.getElementById('flerev');if(r)r.remove();try{dkClose(true)}catch(e){}}");await pg.wait_for_timeout(250)
                await E("()=>{"+js+"}");await pg.wait_for_timeout(900)
                o=await E("()=>{const R="+root+";if(!R)return['no root'];const W=document.getElementById('wrap').getBoundingClientRect();const out=__rpuOvl(R);for(const e of R.querySelectorAll('button')){const r=e.getBoundingClientRect();if(r.width&&(r.right>W.right+1||r.bottom>W.bottom+1||r.left<W.left-1))out.push('off stage '+(e.id||e.className))}return out}")
                if o:bad[nm]=o
                await pg.screenshot(path=os.path.join(SHOTS,f'{nm}_{tag}.png'))
            chk(f'{tag}: home card, hub, calendar, market, feast reveal and Events sheet have no overlaps or off-stage buttons',bad,bad=={})
            r=await E("()=>{fleMarket();const d=document.querySelector('.dkrow'),g=document.querySelector('.flemkg');if(!d||!g)return 'missing';const a=g.getBoundingClientRect(),b2=d.querySelector('.dk').getBoundingClientRect();return a.bottom<=b2.top+1||document.getElementById('ov').scrollHeight>document.getElementById('ov').clientHeight}")
            chk(f'{tag}: the market cards end above the dock (or the page scrolls)',r,r==True)
            await ctx.close()
        # ================= B: 10 November, Halloween over =================
        ctx,pg=await mk(b,'2026-11-10T12:00:00');E=pg.evaluate;await E(FRESH)
        r=await E("""async()=>{title();await new Promise(r=>setTimeout(r,300));const sc=document.querySelector('.dksc');const ids=[...sc.querySelectorAll(':scope>.dkcard')].map(c=>c.id);
          modeSheet('ev');await new Promise(r=>setTimeout(r,400));const all=document.querySelectorAll('.dks'),sh=all[all.length-1];const ev=[...sh.querySelectorAll('.dkpv[data-v="e"] .dkm')].map(b=>b.id);
          return [hwOn(),ids.includes('dkflc'),ids.length,sc.classList.contains('dks4'),sc.classList.contains('dks3'),!!document.querySelector('#dkflc #dkev'),ev]}""")
        chk('after Halloween: the festival is the fourth card (2x2), no Halloween button; Events lists the festival, the Rush and Trick-or-Treat',r,r==[False,True,4,True,False,False,['dmfl','dmflr','dmt']])
        await E("()=>{dkClose(true);title()}");await shot(pg,'home_10nov',1200)
        await ctx.close()
        # ================= C: Monday 9 November with the cheat guard enforcing =================
        ctx,pg=await mk(b,'2026-11-09T12:00:00',ac=True);E=pg.evaluate
        await pg.evaluate("()=>{fleCal()}");await pg.wait_for_timeout(500)
        g0=await E("()=>P.gold");await E("()=>{try{P.gold=999999}catch(e){}}");g1=await E("()=>P.gold")
        await pg.click('[data-fle-day="9"]');await pg.wait_for_function("()=>!!document.getElementById('flerev')",timeout=5000)
        r=await E("()=>[P.gold,!!P.fl.fe.cal[9],!!document.getElementById('flerev')]")
        chk('cheat guard on: a console write to coins is refused, the 1,500-coin present still pays through the game',[g0,g1,r],g1==g0 and r==[g0+1500,True,True])
        await shot(pg,'calendar_coins_guard',300)
        await ctx.close()
        # ================= D: Thanksgiving =================
        ctx,pg=await mk(b,'2026-11-26T18:00:00');E=pg.evaluate;await E(FRESH)
        r=await E("""async()=>{const sl=ms=>new Promise(r=>setTimeout(r,ms));const e=P.fl.fe;for(let d=6;d<26;d++)e.cal[d]=1;save();fleCal();await sl(500);const a=P.fl.ac,c0=P[FL.chest.cnt]|0,eg=window.__flStub.egg;
          document.querySelector('[data-fle-day="26"]').click();await sl(1000);const rv=document.getElementById('flerev');return [P.fl.ac-a,(P[FL.chest.cnt]|0)-c0,window.__flStub.egg-eg,!!fleBty().own['t:thankful'],e.feast,!!(rv&&rv.querySelector('#flerhatch')),fleCalN(),!!P.ach.flt_cA]}""")
        chk('the Thanksgiving feast after every present: 200 acorns, 2 chests, the Golden Harvest Egg, Thankful Heart; all 21 trophy',r,r==[200,2,1,True,1,True,21,True])
        await shot(pg,'feast_reveal',600)
        r=await E("""async()=>{const sl=ms=>new Promise(r=>setTimeout(r,ms));document.getElementById('flerhatch').click();await sl(300);return [window.__flStub.hatch]}""")
        chk('"Hatch the egg" hatches it',r,r==[1])
        await E(FRESH)
        r=await E("""async()=>{const sl=ms=>new Promise(r=>setTimeout(r,ms));const e=P.fl.fe;for(let d=6;d<26;d++)if(d!==12)e.cal[d]=1;save();fleCal();await sl(400);const eg=window.__flStub.egg;const b=document.querySelector('[data-fle-day="26"]');b.click();await sl(200);
          const asked=[!!document.getElementById('flemsg'),!e.cal[26]];b.click();await sl(1000);return asked.concat([!!e.cal[26],window.__flStub.egg-eg,e.feast])}""")
        chk('a missed day: the feast warns first, then opens without the egg',r,r==[True,True,True,0,0])
        await E("()=>{document.getElementById('flerev')&&document.getElementById('flerok').click()}");await pg.wait_for_timeout(400)
        await E("()=>{const e=P.fl.fe;e.cal={};for(let d=6;d<26;d++)if(d%3)e.cal[d]=1;fleCal()}");await shot(pg,'calendar_26nov',900)
        await ctx.close()
        # ================= E: the grace week (4 December) =================
        ctx,pg=await mk(b,'2026-12-04T12:00:00');E=pg.evaluate;await E(FRESH)
        r=await E("""()=>{P.fl.ac=600;const a=[flOn(),flShopOn(),fleGive(10,'campaign'),fleGive(10,'chest'),fleCalClaim(fleCalNow())];title();a.push(!!document.getElementById('dkflc'));fleHub();a.push(!!document.getElementById('flegomk'),!!document.querySelector('.flegt'));
          a.push(fleBuy('chest'),P.fl.ac);P.fl.ac=0;title();a.push(!!document.getElementById('dkflc'));return a}""")
        chk('grace week: no play acorns or presents, other acorns and the market still work; the card shows only with acorns left',r,r==[False,True,0,10,None,True,True,False,True,460,False])
        await E("()=>{P.fl.ac=600;fleHub()}");await shot(pg,'hub_grace',900)
        r=await E("()=>{title();const a=document.querySelectorAll('.fllf').length;P.fl.fe.buy.keep=1;title();return [a,document.querySelectorAll('.fllf').length]}")
        chk('after the festival the leaves stay only with the Autumn Keepsake',r,r==[0,14])
        await E("()=>{P.ach.flt_a1=Date.now();P.fl.fe.tot=200;save()}");await ctx.close()
        # ================= F: closed (10 December) =================
        ctx,pg=await mk(b,'2026-12-10T12:00:00');E=pg.evaluate
        r=await E("()=>{load({ach:{flt_a1:1},fl:{ac:500}});title();const a=[flShopOn(),!!document.getElementById('dkflc'),fleGive(10,'chest'),fleBuy('chest')];fleHub();a.push(!!document.querySelector('.flegone'));const ids=ACH.filter(x=>x.cat==='Harvest').map(x=>x.id);a.push(ids,ACAT.includes('Harvest'));return a}")
        chk('closed: no card, no acorns, no sales, a thank-you screen; only earned Harvest trophies stay in the case',r,r==[False,False,0,False,True,['flt_a1'],True])
        await shot(pg,'closed',500)
        r=await E("()=>{load({});title();return [ACH.filter(x=>x.cat==='Harvest').length,ACAT.includes('Harvest')]}")
        chk('a save without festival trophies shows no Harvest category once it is over',r,r==[0,False])
        await ctx.close()
        # ================= G: the other parts missing =================
        ctx,pg=await mk(b,'2026-11-07T12:00:00',stub=False);E=pg.evaluate;await E(FRESH)
        r=await E("""()=>{const has=['flcAdd','flpGive','flpEggAdd','flrMenu'].filter(k=>typeof window[k]==='function');P.fl.ac=5000;const st=FLE_MK.map(i=>fleMkSt(i.k));P.fl.ac=0;const g=fleCalClaim(7);fleMarket();const b2=document.querySelector('[data-fle-buy="egg"]');
          fleHub();return [has,st,g&&g.gifts[0].k,P.fl.ac,b2.disabled,b2.textContent,document.getElementById('flerushb').disabled]}""")
        chk('without the other parts: their items say Coming soon, a chest present becomes acorns, the Rush tile is off',r,
            r[1]==['soon','soon','soon','soon','soon','ok','ok','ok'] if r[0]==[] else r[0]!=[])
        print('   (other parts present in this build:',r[0],')')
        await ctx.close()
        # ================= H: reduced motion =================
        ctx,pg=await mk(b,'2026-11-07T12:00:00',rm=True);E=pg.evaluate;await E(FRESH)
        r=await E("()=>{title();const a=document.querySelectorAll('.fllf').length;const n0=LIVE.length;fleHub();return [a,LIVE.filter(l=>l.cv&&l.cv.id==='flescene').length]}")
        chk('reduced motion: no leaves, the hub scene is painted once',r,r==[0,0])
        await ctx.close()
        # ================= I: 10.4c polish (real clicks and keys) =================
        ctx,pg=await mk(b,'2026-11-07T12:00:00');E=pg.evaluate;await E(FRESH)
        await E("()=>{P.fl.ac=6000;P.gold=500000;P.fl.fe.cal={6:1};const G=fleGT();G.p[0]=FLE_TK[G.k[0]].n;fleHub()}");await pg.wait_for_timeout(700)
        r=await E("()=>{const w=document.getElementById('flewal');return [w.getAttribute('role'),w.title.length>40&&/Harvest Market/.test(w.title),document.activeElement&&document.activeElement.className.includes('flecl')]}")
        chk('10.4c: the acorn wallet explains acorns in a tooltip and is a button; the hub starts on the Claim button',r,r==['button',True,True])
        await pg.click('#flewal');await pg.wait_for_timeout(300)
        r=await E("()=>[!!document.getElementById('flehow'),document.activeElement&&document.activeElement.id]")
        chk('10.4c: tapping the wallet opens How it works, focus on Got it; Esc closes only the dialog',r==[True,'flehx'],r)
        await pg.keyboard.press('Escape');await pg.wait_for_timeout(200)
        r=await E("()=>[!document.getElementById('flehow'),!!document.querySelector('section.flehub')]")
        chk('10.4c: Esc from How it works stays on the hub',r==[True,True],r)
        await E("()=>fleMarket()");await pg.wait_for_timeout(500)
        c0=await E("()=>[P.fcr|0,P.fl.ac]");await pg.dblclick('[data-fle-buy="chest"]');await pg.wait_for_timeout(500)
        c1=await E("()=>[P.fcr|0,P.fl.ac,!!document.getElementById('fleask')]")
        chk('10.4c: a double click on Buy buys one Harvest Chest (150 acorns), then the Open it now card shows',c1[0]-c0[0]==1 and c0[1]-c1[1]==150 and c1[2],[c0,c1])
        await pg.keyboard.press('Escape');await pg.wait_for_timeout(300)
        r=await E("()=>[!!document.getElementById('fleask'),!!document.querySelector('section.flemk')]")
        chk('10.4c: Esc closes the Open it now card first and stays in the market',r==[False,True],r)
        await pg.click('[data-fle-buy="chest"]');await pg.wait_for_timeout(500)
        await E("()=>fleHub()");await pg.wait_for_timeout(400)
        r=await E("()=>[!!document.getElementById('fleask'),!!document.getElementById('flemsg')]")
        chk('10.4c: the Open it now card does not follow you to other screens',r==[False,False],r)
        await E("()=>fleCal()");await pg.wait_for_timeout(500)
        await E("()=>document.querySelector('[data-fle-day=\"12\"]').click()");await pg.wait_for_timeout(300)
        r=await E("()=>{const m=document.getElementById('flemsg');return m&&m.textContent}")
        chk('10.4c: tapping a locked present says when it opens',r and '12 November' in r,r)
        r=await E("()=>document.activeElement&&document.activeElement.dataset&&document.activeElement.dataset.fleDay")
        chk('10.4c: the calendar starts on today\'s present for the keyboard',r=='7',r)
        await E("()=>fleHub()");await pg.wait_for_timeout(300)
        await ctx.close()
        ctx,pg=await mk(b,'2026-11-07T12:00:00');E=pg.evaluate;await E(FRESH);r1=await E("async()=>{window.FLE_NEWS=1;fleHub();await new Promise(r=>setTimeout(r,1300));return !!document.getElementById('flehow')}")  # (page timers run on the test clock: wait inside the page)
        await pg.keyboard.press('Enter');await pg.wait_for_timeout(300)
        r2=await E("async()=>{fleHub();await new Promise(r=>setTimeout(r,1300));return [!!document.getElementById('flehow'),P.fl.fe.seen]}")
        chk('10.4c: the first visit to the festival opens How it works once (window.FLE_NEWS lets it show under automation); the second visit does not',r1 and r2==[False,1],[r1,r2])
        await ctx.close()
        for vw,vh in [(1600,900),(1024,640)]:
            ctx,pg=await mk(b,'2026-12-03T12:00:00',vw,vh);E=pg.evaluate;await E(FRESH);await E("()=>{window.FL_FORCE=undefined;P.fl.ac=800;P.fl.fe.cal={6:1};P.fl.fe.tot=900;fleHub()}");await pg.wait_for_timeout(700)
            r=await E("()=>{const h=document.querySelector('.flehero');return [/festival is over/.test(h.querySelector('p').textContent),/December/.test(h.querySelector('p').textContent),h.querySelectorAll('.flestats span').length,!!document.getElementById('flegomk'),document.activeElement&&document.activeElement.id,__rpuOvl(document.querySelector('section.fle'))]}")
            chk(f'10.4c {vw}x{vh}: grace week hub: the hero says the festival is over and until when, no duplicate counters, the market button has focus, no overlaps',r[:5]==[True,True,0,True,'flegomk'] and r[5]==[],r)
            await ctx.close()
        await b.close()
    chk('no page errors',ERR,ERR==[])
    print(f'\n{N[0]-len(FAIL)} / {N[0]} passed'+(' · FAILED: '+'; '.join(FAIL) if FAIL else ''))
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
