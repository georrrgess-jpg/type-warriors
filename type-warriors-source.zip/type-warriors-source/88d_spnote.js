/* ===== SKILL TREE BADGE: only nag when a skill point can actually be spent =====
   The sidebar, the Gear dock tab and the Skill Tree sub-tab used to show a badge whenever any skill points were unspent,
   even when the tree was complete or every remaining rank cost more points than the player had.
   spNote() returns the unspent points only if at least one rank can be bought with them right now, otherwise 0. */
function spNote(){try{const sp=spLeft();if(sp<=0)return 0;for(const n of ND){const r=U(n.id);if(r<n.max&&reqOk(n)&&sCost(n,r)<=sp)return sp}return 0}catch(e){return 0}}
