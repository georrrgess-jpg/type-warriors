/* ===== 9.6 THE CROOKED CUE: the emblem (96zd) =====
   One badge for the mode: a gold-ringed medallion, the 8-ball, a cue with a kink in it crossing behind, and a
   ribbon. Inline SVG (static, no filters), used on the casino tile, the Special feature card, the switcher button
   and beside the hub title. */
function pzEmblem(px,opt){opt=opt||{};const rib=opt.ribbon!==false;
 return `<svg class="pzemb" viewBox="0 0 200 ${rib?214:200}" width="${px}" height="${Math.round(px*(rib?214:200)/200)}" aria-hidden="true"><defs>
 <linearGradient id="pzeG" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff0a8"/><stop offset=".45" stop-color="#f2b938"/><stop offset=".75" stop-color="#c47c18"/><stop offset="1" stop-color="#ffd86a"/></linearGradient>
 <radialGradient id="pzeF" cx=".5" cy=".38" r=".7"><stop offset="0" stop-color="#3fae78"/><stop offset=".6" stop-color="#17643f"/><stop offset="1" stop-color="#0a3424"/></radialGradient>
 <radialGradient id="pzeB" cx=".36" cy=".3" r=".75"><stop offset="0" stop-color="#5a5468"/><stop offset=".35" stop-color="#1c1824"/><stop offset="1" stop-color="#050308"/></radialGradient>
 <linearGradient id="pzeW" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe2a6"/><stop offset="1" stop-color="#c8904a"/></linearGradient>
 <linearGradient id="pzeR" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#c8283c"/><stop offset="1" stop-color="#7a1022"/></linearGradient></defs>
 <circle cx="100" cy="100" r="97" fill="#12081f"/>
 <circle cx="100" cy="100" r="91" fill="url(#pzeG)"/>
 <circle cx="100" cy="100" r="80" fill="#12081f"/>
 <circle cx="100" cy="100" r="76" fill="url(#pzeF)"/>
 ${[0,1,2,3,4,5,6,7,8,9,10,11].map(i=>{const a=i/12*Math.PI*2-Math.PI/2,x=100+Math.cos(a)*85.5,y=100+Math.sin(a)*85.5;return `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${i%3?1.8:2.8}" fill="#12081f" opacity=".7"/>`}).join('')}
 <ellipse cx="100" cy="66" rx="58" ry="26" fill="#fff6c0" opacity=".1"/>
 <g stroke-linecap="round" stroke-linejoin="round">
  <path d="M22 142 L78 120 L176 50" fill="none" stroke="#12081f" stroke-width="15"/>
  <path d="M22 142 L78 120" fill="none" stroke="#3a1a2a" stroke-width="10"/>
  <path d="M22 142 L48 131.8" fill="none" stroke="#8a2a2a" stroke-width="10"/><path d="M33 137.7 L37 136.1" fill="none" stroke="#f2b938" stroke-width="10"/>
  <path d="M78 120 L176 50" fill="none" stroke="url(#pzeW)" stroke-width="7.5"/>
  <path d="M80 117.4 L174 49.2" fill="none" stroke="#fff8e0" stroke-width="1.6" opacity=".7"/>
  <path d="M75 122 L81 117.8" fill="none" stroke="#f2b938" stroke-width="11"/>
  <path d="M166 57.1 L176 50" fill="none" stroke="#f6f0e0" stroke-width="7.5"/>
  <path d="M174.8 50.9 L178.4 48.3" fill="none" stroke="#3a86e8" stroke-width="7.5"/></g>
 <circle cx="100" cy="98" r="41" fill="#12081f"/>
 <circle cx="100" cy="98" r="37.5" fill="url(#pzeB)"/>
 <circle cx="100" cy="98" r="17" fill="#fbf7ee" stroke="#12081f" stroke-width="2"/>
 <text x="100" y="108.5" text-anchor="middle" font-family="Poppins,sans-serif" font-weight="800" font-size="28" fill="#12081f">8</text>
 <ellipse cx="86" cy="80" rx="11" ry="6.5" transform="rotate(-30 86 80)" fill="#fff" opacity=".55"/>
 <circle cx="80.5" cy="77.5" r="3" fill="#fff" opacity=".9"/>
 <g fill="#ffe27a"><path d="M100 27l2.6 6 6 2.6-6 2.6-2.6 6-2.6-6-6-2.6 6-2.6z"/><path d="M52 60l1.6 3.6 3.6 1.6-3.6 1.6-1.6 3.6-1.6-3.6-3.6-1.6 3.6-1.6z"/><path d="M150 128l1.6 3.6 3.6 1.6-3.6 1.6-1.6 3.6-1.6-3.6-3.6-1.6 3.6-1.6z"/></g>
 ${rib?`<g stroke="#12081f" stroke-width="3.5" stroke-linejoin="round">
  <path d="M14 166 L36 160 L36 196 L14 202 L24 184 Z" fill="#7a1022"/><path d="M186 166 L164 160 L164 196 L186 202 L176 184 Z" fill="#7a1022"/>
  <path d="M28 156 Q100 140 172 156 L172 192 Q100 176 28 192 Z" fill="url(#pzeR)"/></g>
  <path d="M34 162 Q100 147 166 162" fill="none" stroke="#ffd86a" stroke-width="1.6" opacity=".8"/>
  <path id="pzeT" d="M38 182 Q100 166 162 182" fill="none"/>
  <text font-family="'Pirata One',serif" font-size="25" fill="#ffe08a" stroke="#12081f" stroke-width="1" paint-order="stroke" letter-spacing="1"><textPath href="#pzeT" startOffset="50%" text-anchor="middle">Crooked Cue</textPath></text>`:''}
 </svg>`}
/* the casino tile and the Special feature art: a lit felt with the emblem in the middle */
TA.pz=`<svg viewBox="0 0 320 176" preserveAspectRatio="xMidYMid slice"><defs><radialGradient id="pzta2" cx=".5" cy=".45" r=".75"><stop offset="0" stop-color="#36a070"/><stop offset=".5" stop-color="#17643f"/><stop offset="1" stop-color="#062018"/></radialGradient><linearGradient id="pztw2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#a85e2a"/><stop offset="1" stop-color="#4a220c"/></linearGradient></defs>
 <rect width="320" height="176" fill="url(#pzta2)"/>
 <rect x="-6" y="-6" width="332" height="188" rx="16" fill="none" stroke="url(#pztw2)" stroke-width="18"/><rect x="-6" y="-6" width="332" height="188" rx="16" fill="none" stroke="#12081f" stroke-width="2.5"/>
 ${[[10,10],[160,6],[310,10],[10,166],[160,170],[310,166]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="10" fill="#0a0610" stroke="#c48a2a" stroke-width="3"/>`).join('')}
 <ellipse cx="160" cy="80" rx="140" ry="70" fill="#fff4c0" opacity=".07"/>
 ${[[52,128,'#f2c21b',0],[78,46,'#e0262e',0],[262,120,'#1e4fd8',1],[248,52,'#178a3e',0],[284,82,'#6a2aa8',1]].map(([x,y,c,s])=>`<g><circle cx="${x}" cy="${y}" r="10" fill="${s?'#f6f1e6':c}" stroke="#12081f" stroke-width="2"/>${s?`<path d="M${x-9.4} ${y-4}h18.8v8h-18.8z" fill="${c}"/><circle cx="${x}" cy="${y}" r="10" fill="none" stroke="#12081f" stroke-width="2"/>`:''}<circle cx="${x}" cy="${y}" r="4.4" fill="#fbf7ee"/><circle cx="${x-3.4}" cy="${y-3.8}" r="2.4" fill="#fff" opacity=".8"/></g>`).join('')}
 <g transform="translate(98 2) scale(.62)">${pzEmblem(200).replace(/^<svg[^>]*>/,'').replace(/<\/svg>$/,'')}</g></svg>`;
/* hub title, switcher button, feature card badge */
function pzEmbDeco(){try{
 const t=document.querySelector('.pzh9 .pztitle.pzsign, .pztitle.pzsign');if(t&&!t.querySelector('.pzemb'))t.insertAdjacentHTML('afterbegin',`<i class="pzembw">${pzEmblem(88)}</i>`);
 const b=document.querySelector('[data-sp=pz]');if(b&&!b.querySelector('.pzemb')){const d=b.querySelector('.nsdot');if(d)d.outerHTML=`<i class="pzembs">${pzEmblem(22,{ribbon:false})}</i>`}
}catch(e){}}
{const f0=pzHub;pzHub=function(){const r=f0.apply(this,arguments);pzEmbDeco();setTimeout(pzEmbDeco,60);return r}}
{const f0=twLobby;twLobby=function(){const r=f0.apply(this,arguments);pzEmbDeco();const rb=document.querySelector('.pzrib');if(rb)rb.textContent='UPDATE 9.6';return r}}
if(typeof casinoOpen==='function'){const f0=casinoOpen;casinoOpen=function(){const r=f0.apply(this,arguments);setTimeout(pzEmbDeco,0);setTimeout(pzEmbDeco,300);return r}}
{const st=document.createElement('style');st.textContent=`
.pzembw{display:inline-block;vertical-align:middle;margin:-22px 12px 0 0;transform-origin:50% 60%;animation:pzembIn .7s cubic-bezier(.3,1.6,.5,1) both}
.pzembw .pzemb{display:block}
.pzembs{display:inline-block;width:22px;height:22px;margin-right:7px;vertical-align:-6px}
.pzembs .pzemb{display:block}
@keyframes pzembIn{0%{transform:scale(.3) rotate(-40deg);opacity:0}100%{transform:none;opacity:1}}
`;document.head.appendChild(st)}
