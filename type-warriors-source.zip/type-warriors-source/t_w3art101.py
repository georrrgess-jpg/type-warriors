# python3 t_w3art101.py [game.html] : World 3 life and interaction (10.1, 98g3): the bake extras (waterfalls, balloons, flocks,
# butterflies, the trip hammer and the piston engine, live banners, crows), the hotspots, the click hook (pads still build, towers still
# select, monsters and open menus never poke, a poke never changes gameplay), the reactions on every map, the battle reactions (steam
# when monsters cross the vents, gears wound up by firing towers, flocks taking off, the light of a strike), real mouse clicks and the
# hover cursor, the frame cost of the layers against World 1 (and lite / reduced motion), the hub painting's live layer.
import asyncio,os,sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:600]),flush=True)
    if not ok:FAIL.append(name)
HELP=r"""()=>{
 window.w3New=(map)=>{try{rpLeave()}catch(e){}rpStart(map);const R=RPX,m=R.map;R.tut=null;R.supply=1e9;R.banner=null;if(m.gustT&&!R.gust)R.gust={t:9,k:0,on:0};if(m.sw&&R.sw==null){R.sw=0;R.swK=1}
  if(m.rods&&!R.rodK)R.rodK=m.rods.map(()=>0);if(!R.bolts)R.bolts=[];R.flash=R.flash||0;R.pause=false;R.lite=0;const el=document.getElementById('rptut');if(el)el.style.display='none';return R};
 window.w3Full=(R)=>{const T=Object.keys(RP_TW).filter(t=>RP_TW[t]&&!['hive','grav'].includes(t));R.pads.forEach((p,i)=>{rpBuild(p,T[i%T.length]);if(p.tw){p.tw.build=1;p.tw.upK=1}});
  R.wave=5;R.wst='run';const M=Object.keys(RPMOB).filter(k=>!RPMOB[k].boss&&RP_FOE[k]);for(let i=0;i<26;i++){const e=rpSpawn(M[i%M.length],i%R.G.paths.length);if(e)e.s=60+i*70}for(let i=0;i<20;i++)rpStep(R,1/30);return R};
 window.w3Snap=()=>{const d=ctx.getImageData(0,0,1600,900).data;let h=0;for(let i=0;i<d.length;i+=4*61)h=(h*31+d[i]+d[i+1]*7+d[i+2]*13)%1000000007;return h};
 window.w3State=(R)=>JSON.stringify([R.supply,R.hp,R.sw,R.wave,R.wst,R.pads.map(p=>p.tw?p.tw.type+p.tw.tier:0),R.foes.length,R.sel?1:0,R.selPad?1:0,R.place,R.aim]);
 return 1}"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        pg.on('console',lambda m:er.append('console: '+m.text[:300]) if m.type=='error' and not any(w in m.text for w in('WebSocket','wss:','net::','Failed to load resource')) else None)
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E("()=>{window.TWA_RELAYS=[];RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const r=RPP();r.new99j=1;r.dragon=1;for(const k in r.tut)r.tut[k]=1}")
        await E(HELP)
        # ---- module and hook
        r=await E("()=>[typeof rpw3aPoke,typeof RPW3A.react.meadow,typeof RPW3A.react.foundry,typeof RPW3A.react.storm,(String(rpClick).includes('rpw3aFree')||/* 10.3: the potion aim wrapper (99j) sits outside it and passes every other click through */String(rpClick).includes('R.pt.aim')),RPW.amb.meadow===rpw3aAmbMeadow,RPW.amb.foundry===rpw3aAmbFoundry,RPW.amb.storm===rpw3aAmbStorm,RPW.ambTop.storm===rpw3aTopStorm]")
        chk('98g3 is loaded: the poke, a reaction per map, the click hook and the live layers registered',r[0]=='function' and r[1]==r[2]==r[3]=='function' and all(r[4:]),r)
        # ---- bake extras
        r=await E("""()=>{const M=rpBake(RP_MAP('meadow')),F=rpBake(RP_MAP('foundry')),S=rpBake(RP_MAP('storm'));
          return {falls:M.falls.length,bal:M.balloons.length,flocks:M.flocks.length,bf:M.bflies.length,ham:!!F.ham,eng:!!F.eng,vst:F.vst.length,flags:S.flags.length,crows:S.crows.length,spl:S.spl.length,
           hot:[M.hot.length,F.hot.length,S.hot.length],kinds:[new Set(M.hot.map(h=>h.k)).size,new Set(F.hot.map(h=>h.k)).size,new Set(S.hot.map(h=>h.k)).size]}}""")
        print('   extras:',r)
        chk('bake extras: waterfalls, balloons, perched flocks and butterflies (meadow); the trip hammer, the piston engine and vent states (foundry); live banners, crows and splash spots (storm)',
            r['falls']>=2 and r['bal']==2 and r['flocks']>=2 and r['bf']>=4 and r['ham'] and r['eng'] and r['vst']==3 and r['flags']>=4 and r['crows']>=1 and r['spl']>=40,r)
        chk('every map has many hotspots of many kinds',all(x>=20 for x in r['hot']) and all(x>=7 for x in r['kinds']),r)
        r=await E("""()=>['meadow','foundry','storm'].map(id=>{const B=rpBake(RP_MAP(id)),bad=[];for(const p of B.G.pads)for(const q of B.occ||[]){if(Math.abs(q.x-p.x)<54+q.w&&q.y>p.y-44&&q.y-q.h<p.y+36)bad.push([p.x,p.y,q.x|0,q.y|0])}
          const F=B.ham?[B.ham,B.eng]:[];for(const m of F)for(const p of B.G.pads)if(Math.abs(m.x-p.x)<110&&m.y>p.y-50&&m.y-110<p.y+40)bad.push(['machine',p.x,p.y]);
          for(const f of B.falls||[])for(const p of B.G.pads)if(Math.abs(f.x-p.x)<40&&Math.abs(f.y-p.y)<30)bad.push(['fall',p.x,p.y]);return [id,bad]})""")
        chk('the new props (machines, springs) keep clear of every pad and of the tower on it',all(len(x[1])==0 for x in r),r)
        r=await E("""()=>{const B=rpBake(RP_MAP('foundry')),dR=rpw3aDR(B.G);return [B.ham,B.eng].map(m=>Math.round(dR(m.x,m.y)))}""")
        chk('the machines stand off the rails',all(x>=50 for x in r),r)
        # ---- the distance field matches the exact road distance
        r=await E("""()=>{const G=rpGeo(RP_MAP('storm')),f=rpw3aDR(G);let worst=0;for(let i=0;i<400;i++){const x=rpw3aR(i)*1600,y=rpw3aR(i+500)*900;let m=4e4;for(const q of G.U){const d=(q.x-x)**2+(q.y-y)**2;if(d<m)m=d}const ex=Math.min(200,Math.sqrt(m));worst=Math.max(worst,Math.abs(ex-Math.min(200,f(x,y))))}return +worst.toFixed(2)}""")
        chk('rpw3aDR (the 8 px distance field) stays within 3 px of the exact road distance',r<=3,r)
        # ---- the click hook: pads build, towers select, monsters and menus are left alone; no gameplay change from a poke
        r=await E("""()=>{const out={};for(const id of['meadow','foundry','storm']){const R=w3New(id);R.wst='build';const T=RP_TWORDER[0];let built=0,poked=0;
          for(const p of R.pads.slice(0,6)){R.place=T;rpClick(p.x,p.y,0,false);if(p.tw)built++;if(R._w3&&R._w3.poke)poked++}
          R.place=null;R.sel=null;R.selPad=null;const tw=R.pads[0].tw;rpClick(tw.x,tw.y-40,0,false);const sel=R.sel===tw;rpClick(tw.x,tw.y-40,0,false);
          const free=R.pads.find(p=>!p.tw);rpClick(free.x,free.y,0,false);const selPad=R.selPad===free;const pk1=!!(R._w3&&R._w3.poke);R.selPad=null;
          out[id]=[built,poked,sel,selPad,pk1]}return out}""")
        chk('with a tower in hand, clicking pads builds on them (and never pokes); clicking a tower selects it; clicking an empty pad opens it; none of these poke',
            all(v[0]==6 and v[1]==0 and v[2] and v[3] and not v[4] for v in r.values()),r)
        r=await E("""()=>{const out={};for(const id of['meadow','foundry','storm']){const R=w3New(id);R.wst='build';const B=R.bake;
          const h=B.hot.find(q=>!q.dyn&&q.k!=='castle'&&q.k!=='bridge'&&!rpPick(R,q.x,q.y)&&!rpSnap(R,q.x,q.y)&&rpw3aFree(R,q.x,q.y,0,false));
          const s0=w3State(R);rpClick(h.x,h.y,0,false);const a=R._w3&&R._w3.poke&&R._w3.poke[3];const s1=w3State(R);
          /* an open pad menu or a selected tower: the click only closes it */
          R.selPad=R.pads[0];if(R._w3)R._w3.poke=null;rpClick(h.x,h.y,0,false);const b=!!(R._w3&&R._w3.poke);
          /* a tower in hand: no poke either */R.place=RP_TWORDER[0];rpClick(h.x,h.y,0,false);const c=!!(R._w3&&R._w3.poke);R.place=null;
          /* right click, a paused battle */R.pause=true;rpClick(h.x,h.y,0,false);const d=!!(R._w3&&R._w3.poke);R.pause=false;rpClick(h.x,h.y,2,false);const e=!!(R._w3&&R._w3.poke);
          out[id]=[h.k,a,s0===s1,b,c,d,e]}return out}""")
        chk('a click on a free prop pokes it and changes nothing in the battle (supply, health, switch, towers, monsters, selection)',all(v[1]==v[0] and v[2] for v in r.values()),r)
        chk('no poke while a pad menu is open, a tower is in hand, the battle is paused, or on a right click',all(not any(v[3:]) for v in r.values()),r)
        r=await E("""()=>{const out={};for(const id of['meadow','foundry','storm']){const R=w3Full(w3New(id));let n=0,poked=0;for(const e of R.foes.slice(0,8)){if(e.dead)continue;const q=rpPos(R,e);if(rpPick(R,q.x,q.y-20))continue;n++;if(R._w3)R._w3.poke=null;R.sel=null;R.selPad=null;rpClick(q.x,q.y-20,0,false);if(R._w3&&R._w3.poke)poked++}out[id]=[n,poked]}return out}""")
        chk('clicking a monster never pokes the prop behind it',all(v[0]>=3 and v[1]==0 for v in r.values()),r)
        r=await E("""()=>{const out={};for(const id of['meadow','foundry','storm']){const R=w3New(id);R.wst='build';const tp=R.pads.find(p=>!p.tw);let ok=0;for(const dx of[-60,0,60])for(const dy of[-30,0,30]){R.selPad=null;R.sel=null;rpClick(tp.x+dx*.6,tp.y+dy*.5,0,true);if(R.selPad)ok++}out[id]=ok}return out}""")
        chk('a tap near an empty pad still snaps to that pad (touch), never to a prop',all(v==9 for v in r.values()),r)
        # ---- every hotspot reacts without errors, and the reactions show
        r=await E("""()=>{const out={};for(const id of['meadow','foundry','storm']){const R=w3New(id);R.wst='build';const B=R.bake;const kinds={};let err=0;
          for(const h of B.hot){if(kinds[h.k])continue;kinds[h.k]=1;try{R.t=5;h.R=null;rpw3aPoke(R,h.dyn?h.x:h.x,h.y);R.t=5.3;rpDraw();R.t=6;rpDraw()}catch(e){err++;out.e=String(e)}}
          const fx=R.fx.length;out[id]=[Object.keys(kinds).length,err,fx]}return out}""")
        chk('poking every kind of prop on every map runs and draws without errors and throws particles',all(v[1]==0 and v[0]>=7 and v[2]>0 for k,v in r.items() if k!='e'),r)
        r=await E("""()=>{const res={};const look=(id,k)=>{const run=(pk)=>{const R=w3New(id);R.wst='build';const B=R.bake,h=B.hot.find(q=>q.k===k);R.t=8;rpDraw();if(pk){h.R=R;h.at=8}R.t=8.4;R.fx.length=0;rpDraw();return w3Snap()};return run(0)!==run(1)};
          res.mill=look('meadow','mill');res.ship=look('meadow','ship');res.house=look('meadow','house');res.flock=look('meadow','flock');res.hammer=look('foundry','hammer');res.engine=look('foundry','engine');res.lever=look('foundry','lever');res.boiler=look('foundry','boiler');
          res.rod=(()=>{const R=w3New('storm');R.t=8;rpDraw();const a=w3Snap();R._w3rodK={0:7.9};rpDraw();return a!==w3Snap()})();res.banner=look('storm','banner');res.crows=look('storm','crows');res.crys=look('storm','crys');return res}""")
        chk('the reactions show: windmill, airship, cottage smoke, flock, hammer, engine, lever, boiler steam, rod, banner, crows, crystal',all(r.values()),r)
        r=await E("""()=>{const R=w3New('meadow');const B=R.bake,m=B.mills[0],h=B.hot.find(q=>q.o===m);R.t=10;rpDraw();const a0=m.a;R.t=10.5;rpDraw();const calm=m.a-a0;h.R=R;h.at=10.5;R.t=11;rpDraw();const fast=m.a-a0-calm;return [+calm.toFixed(3),+fast.toFixed(3)]}""")
        chk('a poked windmill spins up (its blades turn several times faster for a while)',r[1]>3*r[0]>0,r)
        r=await E("""()=>{const R=w3New('foundry');const sw0=R.sw;const h=R.bake.hot.find(q=>q.k==='lever');rpClick(h.x,h.y,0,false);for(let i=0;i<10;i++){R.t+=.05;rpDraw()}return [R.sw===sw0,R._w3.poke&&R._w3.poke[3]]}""")
        chk('the switch lever wiggles when poked but the switch never flips',r==[True,'lever'],r)
        # ---- battle reactions
        r=await E("""()=>{const R=w3New('foundry');R.wst='run';const B=R.bake,v=B.vst[0];const e=rpSpawn('cog',0);let best=0,bd=1e9;const P=R.G.paths[0];for(let s=0;s<P.len;s+=4){e.s=s;e._s=null;const q=rpPos(R,e);const d=Math.hypot(q.x-v.x,q.y-v.y);if(d<bd){bd=d;best=s}}e.s=best;e._s=null;
          let at0=v.at;for(let i=0;i<6;i++){R.t=20+i/30;rpDraw()}const steam=v.at>at0;
          const st=B.gst[0];const g=B.A.gears[0];let near=R.pads.filter(p=>Math.abs(p.x-g[0])<260&&Math.abs(p.y-g[1])<220);if(!near.length)return [steam,'no pad near gear'];const pd=near[0];rpBuild(pd,RP_TWORDER[0]);pd.tw.build=1;
          for(let i=0;i<20;i++){R.t=21+i/30;pd.tw.fire=1;rpDraw()}const wound=st.b;return [steam,+wound.toFixed(2),+bd.toFixed(1)]}""")
        chk('foundry: a monster crossing a vent sets off a steam burst; a tower firing near a wall gear winds it up',r[0] is True and r[1]>1.5,r)
        r=await E("""()=>{const R=w3New('meadow');R.wst='run';const f=R.bake.flocks[0];f.R=null;R.t=30;rpDraw();const st0=f.st;const e=rpSpawn('cog',0);const P=R.G.paths[0];let best=0,bd=1e9;for(let s=0;s<P.len;s+=4){e.s=s;e._s=null;const q=rpPos(R,e);const d=Math.hypot(q.x-f.x,q.y-f.y);if(d<bd){bd=d;best=s}}e.s=best;e._s=null;
          for(let i=0;i<4;i++){R.t=30.1+i*.25;rpDraw()}const up=f.st;R.foes.length=0;for(let i=0;i<60;i++){R.t=31+i*.25;rpDraw()}return [st0,up,f.st,Math.round(bd)]}""")
        chk('meadow: a perched flock takes off when a monster walks by, and lands again later',r[0]==0 and r[1]==1 and r[2]==0,r)
        r=await E("""()=>{const R=w3New('storm');R.t=40;rpDraw();const a=w3Snap();R.bolts=[{x:820,y:550,t:.05,d:.55,tw:0}];R.t=40.05;rpDraw();R.bolts=[];R.t=40.2;rpDraw();const s=R._w3.strike;const b=w3Snap();R.t=41.5;rpDraw();return [!!s,a!==b,s&&s[0]]}""")
        chk('storm: a strike lights the stone and the puddles round it for a moment',r[0] and r[1] and r[2]==820,r)
        # ---- real mouse clicks through the canvas listener, and the hover cursor
        r=await E("""()=>{const R=w3New('meadow');R.wst='build';const m=R.bake.mills.find(m=>{const h=R.bake.hot.find(q=>q.o===m);return rpw3aFree(R,h.x,h.y,0,false)});const h=R.bake.hot.find(q=>q.o===m);const r=cv.getBoundingClientRect();
          const p=R.pads.find(p=>!p.tw);return {mill:[r.left+h.x/1600*r.width,r.top+h.y/900*r.height],pad:[r.left+p.x/1600*r.width,r.top+p.y/900*r.height],pi:p.i}}""")
        await pg.mouse.move(r['mill'][0],r['mill'][1]);await pg.wait_for_timeout(100)
        cur=await E("()=>cv.style.cursor")
        await pg.mouse.click(r['mill'][0],r['mill'][1]);await pg.wait_for_timeout(100)
        k=await E("()=>RPX._w3&&RPX._w3.poke&&RPX._w3.poke[3]")
        await E(f"()=>{{RPX.place=RP_TWORDER[0];RPX._w3.poke=null}}")
        await pg.mouse.click(r['pad'][0],r['pad'][1]);await pg.wait_for_timeout(100)
        b2=await E(f"()=>[!!RPX.pads[{r['pi']}].tw,!!(RPX._w3.poke)]")
        chk('real mouse: hovering a windmill shows the pointer, clicking it spins it up; with a tower in hand a click on a pad builds',cur=='pointer' and k=='mill' and b2==[True,False],[cur,k,b2])
        # ---- frame cost
        r=await E("""()=>{const out={};const meas=(f)=>{const L=[];for(let k=0;k<120;k++){ctx.getImageData(0,0,1,1);const t0=performance.now();ctx.save();try{f(k)}finally{ctx.restore()}ctx.getImageData(0,0,1,1);L.push(performance.now()-t0)}L.sort((a,b)=>a-b);return +((L[0]+L[6]+L[12])/3).toFixed(2)};
          for(const id of['ember','meadow','foundry','storm']){const R=w3Full(w3New(id));if(id==='meadow')R.gust.k=1;if(id==='foundry'){R.sw=1;R.swK=.5}
           const all=k=>{R.t=10+k/60;rpAmbient(ctx,R);if(RPW.ambTop[id])RPW.ambTop[id](ctx,R)},own=k=>{R.t=10+k/60;RPW.amb[id](ctx,R);RPW.twist[id](ctx,R);if(RPW.ambTop[id])RPW.ambTop[id](ctx,R)};
           R.lite=0;const a=meas(all),o=RPW.amb[id]?meas(own):0;R.lite=1;const l=meas(all);R.lite=0;R.rm=true;const m=meas(all);R.rm=false;out[id]=[a,o,l,m]}
          const R=w3Full(w3New('storm'));R.bolts=[{x:520,y:450,t:.1,d:.55,tw:0}];R.flash=.6;out.storm_bolt=meas(k=>{R.t=10+k/60;rpAmbient(ctx,R);RPW.ambTop.storm(ctx,R)});return out}""")
        print('   ms per frame [ambience chain + top, World 3 layers alone, lite, reduced motion] (Ember Crown = World 1 reference):',r)
        em=r['ember'][0]
        chk('frame cost on a full battle: each map within 1.5x World 1\'s Ember Crown (10.0 was 1.6-1.9x), its own layers about 1 ms, and a lightning frame within 2.5x',
            all(r[k][0]<=max(1.3,1.5*em) and r[k][1]<=max(1.5,1.05*em) for k in['meadow','foundry','storm']) and r['storm_bolt']<=max(1.8,2.5*em),r)
        chk('lite mode and reduced motion draw less',all(r[k][2]<=r[k][0]+.05 and r[k][3]<=r[k][0]+.05 for k in['meadow','foundry','storm']),r)
        # ---- the hub painting
        r=await E("""()=>{const W=RPW.world[3]();const g=document.createElement('canvas').getContext('2d');g.canvas.width=1600;g.canvas.height=900;g.drawImage(W.c,0,0);W.anim(g,1);const d0=g.getImageData(0,0,1600,900).data;let h0=0;for(let i=0;i<d0.length;i+=4*61)h0=(h0*31+d0[i]+d0[i+1]*7)%1000000007;
          g.drawImage(W.c,0,0);W.anim(g,4.2);const d1=g.getImageData(0,0,1600,900).data;let h1=0;for(let i=0;i<d1.length;i+=4*61)h1=(h1*31+d1[i]+d1[i+1]*7)%1000000007;
          const L=[];for(let k=0;k<40;k++){g.getImageData(0,0,1,1);const t0=performance.now();W.anim(g,k/30);g.getImageData(0,0,1,1);L.push(performance.now()-t0)}L.sort((a,b)=>a-b);
          return [RPW3A_W.x3.falls.length,RPW3A_W.x3.bal.length,h0!==h1,+L[5].toFixed(2)]}""")
        chk('hub painting: waterfalls, balloons, birds, rain and lightning move, and its live layer stays cheap (< 1.2 ms)',r[0]==4 and r[1]==2 and r[2] and r[3]<1.2,r)
        # ---- screenshots of reactions
        os.makedirs(os.path.join(HERE,'shots'),exist_ok=True)
        await E("()=>{const R=w3Full(w3New('foundry'));R.lite=0;const h=R.bake.hot.find(q=>q.k==='hammer');rpw3aPoke(R,h.x,h.y);R.t+=.42;rpDraw()}")
        await pg.screenshot(path=os.path.join(HERE,'shots','w3art101_test.png'))
        chk('no page errors',not er,er)
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
