/* ===== 10.1 THE CROOKED CUE: Orbit 8, a second venue (97b1): data, save, unlocks, AI styles =====
   Orbit 8 is a zero-g pool lounge on a ring station above a gas giant, reached from the Crooked Cue hub once you have beaten Grizzle.
   Five new players climb a ladder that starts a little above Grizzle and ends above Mortimer: Bleep (a rookie bar robot),
   Octavia Inkwell (an octopus lounge singer), Facet (a calculating crystal), Rex Nova (a jet-packed gecko hotshot) and the boss,
   Empress Vantara (the Event Horizon). They live in PZ_REG like the regulars, so the match flow, money, "wise to you", the daily
   cap, the 15,000 ceiling, resume and the results all work unchanged. Ladder: PZN_ORDER (PZ_ORDER stays the tavern's seven).
   Save: P.pz.venue ('tavern' | 'o8', the hub you were last in) and P.pz.o8 {seen}, normalised by the wrapped PZS().
   AI styles on top of 96d: glitch (Bleep: now and then a wild shot), streak (Rex: sharper the longer his run), clutch (Vantara:
   sharper on the 8). House rule proGuide (Vantara): the aim line only. Prefix pzn / PZN_. */
const PZN_ORDER=['bleep','octavia','facet','rex','vantara'];
const PZN={bk:null,hubBk:null,tbl:null,port:{},stage:{},ms:0,run:0,last:-1,open0:null,vopen0:false};
Object.assign(PZ_REG,{
 bleep:{id:'bleep',n:'Bleep',k:'The Rookie Bot',c:'#ffc23a',lvl:4,race:2,stakes:[300,500,1000,2000],mult:1.75,floor:1.35,venue:'o8',
  ai:{sig:1.8,psig:.09,pos:.15,safe:.1,sTry:10,look:4,brk:1.6,glitch:.14},
  house:{},houseTxt:'No house rule: plain 8-ball. Bleep is still learning (and still buffering).',cue:'pzn_bleep',skin:'#d8e0ea',
  voice:{f:880,t:'square',w:.6,robot:1},quirk:'His screen face glitches, his antenna blinks and he polishes the same glass forever.',
  lines:{hi:['HELLO. I AM BLEEP. I HAVE READ ONE (1) BOOK ON POOL.','Loading charm... 100%!'],pot:['BALL.EXE IN POCKET!','Beep boop. Nice.'],miss:['ERROR 404: POCKET NOT FOUND.','Recalibrating...'],
   you:['Saving that shot to memory!'],foul:['Rule violation detected! Hee.'],win:['VICTORY.WAV *plays loudly*'],lose:['Good game! Rebooting my feelings.'],taunted:['D-D-DOES NOT COMPUTE!']},
  taunts:['have you tried a reboot','blue screen','low battery','beep beep miss']},
 octavia:{id:'octavia',n:'Octavia Inkwell',k:'Eight Arms, One Cue',c:'#ff6ad5',lvl:5,race:2,stakes:[500,1000,2000,3000],mult:2.3,floor:1.6,venue:'o8',
  ai:{sig:1.45,psig:.07,pos:.45,safe:.25,sTry:18,look:5,spin:1,brk:1.1},
  house:{winnerBreaks:1},houseTxt:'Encore: whoever won the last rack breaks the next.',cue:'pzn_octavia',skin:'#d85ac0',
  voice:{f:620,t:'sine',w:.3,echo:1},quirk:'Her skin ripples with colour, bubbles rise in her helmet and every arm is busy.',
  lines:{hi:['Oh, a new face in the lounge! Sit, darling. I take requests.','Eight arms, sweetie. I only need one.'],pot:['And the crowd goes wild.','Mm, smooth as jazz.'],miss:['Slipped a sucker.','The mic was in my eye.'],
   you:['Bravo, bravo!'],foul:['Off-key, darling.'],win:['Encore! Encore!'],lose:['Brava... you stole my show.'],taunted:['*splurt* INK!']},
  taunts:['ink about it','squid pro quo','all arms no aim','calamari time']},
 facet:{id:'facet',n:'Facet',k:'The Calculating Crystal',c:'#8ef0ff',lvl:6,race:3,stakes:[1000,2000,3000,4000],mult:3,floor:1.8,venue:'o8',
  ai:{sig:1.0,psig:.05,pos:.7,safe:.32,sTry:24,look:6,brk:.8},
  house:{shortGuide:1},houseTxt:'Refraction: the aim guide is short (no long object-ball line).',cue:'pzn_facet',skin:'#bfefff',
  voice:{f:1040,t:'triangle',w:.08,echo:1},quirk:'Shards orbit it; a glint sweeps its facets while it runs the numbers.',
  lines:{hi:['Probability you win: eleven percent. Let us test it.'],pot:['As computed.','Angle confirmed.'],miss:['An outlier.','Variance. Noted.'],
   you:['Unexpected. Impressive.'],foul:['Your error margin is showing.'],win:['The math was never in doubt.'],lose:['Recalculating... everything.'],taunted:['C-cracks in my logic!']},
  taunts:['cut the facts','crack under pressure','shatter time','do the math']},
 rex:{id:'rex',n:'Rex Nova',k:'The Comet Kid',c:'#ff6a3a',lvl:7,race:3,stakes:[2000,3000,4000,5000],mult:3.4,floor:2.1,venue:'o8',
  ai:{sig:.72,psig:.05,pos:.4,safe:0,sTry:0,look:5,over:1.12,brk:.6,streak:1},
  house:{clock:30},houseTxt:'Quick draw: a 30-second shot clock.',cue:'pzn_rex',skin:'#3ad8a8',
  voice:{f:200,t:'sawtooth',w:.25},quirk:'Chews gum, blows bubbles, and his jetpack never quite switches off.',
  lines:{hi:['Name\'s Rex. Rex Nova. Fastest cue this side of the belt.','Blink and you\'ll miss the rack, partner.'],pot:['YEE-HAW!','Hot streak, baby!'],miss:['Booster hiccup.','That pocket moved. I saw it.'],
   you:['Okay, okay, you got moves.'],foul:['Outta fuel, rookie?'],win:['Another rack for the stars!'],lose:['Rematch. Same time next orbit.'],taunted:['Hey! Not cool, pal!']},
  taunts:['comet crash','burnt out','lizard brain','out of gas']},
 vantara:{id:'vantara',n:'Empress Vantara',k:'The Event Horizon',c:'#b48cff',lvl:7,race:3,stakes:[2000,3000,4000,5000],mult:3.8,floor:2.4,venue:'o8',
  ai:{sig:.5,psig:.025,pos:.85,safe:.35,sTry:30,look:8,spin:1,brk:.4,clutch:.7},
  house:{proGuide:1},houseTxt:'Event horizon: you see the aim line and nothing beyond it.',cue:'pzn_vantara',skin:'#2a1a4a',
  voice:{f:150,t:'sine',w:.04,echo:1},quirk:'Light bends around her head; a void 8-ball circles her palm.',
  lines:{hi:['Every ball falls to me in the end, little star.','Nothing escapes the Event Horizon. Not even a bank shot.'],pot:['Pulled in.','Gravity is patient.'],miss:['...a ripple. Nothing more.'],
   you:['You shine brighter than I expected.'],foul:['You drift too close to the edge.'],win:['Swallowed whole.'],lose:['Impossible... the light escaped me.'],taunted:['You DARE disturb the void?']},
  taunts:['black hole in one','space case','lights out empress','collapse and fall']}});
/* how each one thinks before a shot (seconds of routine, practice strokes, chalk) */
Object.assign(PZ_THINK,{bleep:{dur:.95,pr:1,chalk:0},octavia:{dur:1.15,pr:2,chalk:1},facet:{dur:1.45,pr:1,chalk:1},rex:{dur:.8,pr:1,chalk:0},vantara:{dur:1.3,pr:1,chalk:1}});
Object.assign(PZ_MONH,{bleep:270,octavia:330,facet:370,rex:350,vantara:400});
Object.assign(PZ_TIPS,{bleep:'Mostly solid, but every so often his circuits glitch and he blasts one. Stay ready.',
 octavia:'Uses spin and plays position. Winner breaks here, so a rack win is worth double.',
 facet:'Plans three shots ahead and plays safe when it has nothing. Leave it long, awkward shots.',
 rex:'Never plays safe and gets sharper on a run. Break his streaks early: one miss and he cools off.',
 vantara:'Near perfect, and even sharper on the 8. You only get the aim line. Play safe when you must.'});
Object.assign(PZ97_HOUSE,{bleep:'None. Plain 8-ball.',octavia:'Winner breaks.',facet:'Short aim guide only.',rex:'30-second shot clock.',vantara:'Aim line only.'});
Object.assign(PZ97_PLATE,{bleep:'Bleep',octavia:'Octavia',facet:'Facet',rex:'Rex Nova',vantara:'Vantara'});
Object.assign(PZ_SHORT,{bleep:'Bleep',octavia:'Octavia',facet:'Facet',rex:'Rex',vantara:'Vantara'});
/* the cues they play with (match only: they are not in PZ_CUES, so the Cue Rack is unchanged) */
const PZN_CUES={
 pzn_bleep:{id:'pzn_bleep',n:'Service Probe',a:'#f4f8ff',b:'#c8d2e0',c:'#3a4458',d:'#ffc23a',wrap:'#1a2030',glow:'#7af8ff'},
 pzn_octavia:{id:'pzn_octavia',n:'Coral Mic Stand',a:'#ffe0f4',b:'#f0a0d8',c:'#4a1240',d:'#ff6ad5',wrap:'#24081e',glow:'#ff6ad5'},
 pzn_facet:{id:'pzn_facet',n:'Prism Rod',a:'#ffffff',b:'#bfefff',c:'#2a3a6a',d:'#8ef0ff',wrap:'#101830',glow:'#8ef0ff'},
 pzn_rex:{id:'pzn_rex',n:'Booster Cue',a:'#fff0d0',b:'#e8b070',c:'#4a1408',d:'#ff6a3a',wrap:'#200804',glow:'#ffb03a'},
 pzn_vantara:{id:'pzn_vantara',n:'Horizon Scepter',a:'#f0e8ff',b:'#8a6ad0',c:'#0a0418',d:'#b48cff',wrap:'#05020c',glow:'#d8b8ff'}};
{const f0=pzCueSprite;pzCueSprite=function(id){const d=PZN_CUES[id];if(!d||PZ_CUES.some(c=>c.id===id))return f0.apply(this,arguments);PZ_CUES.push(d);try{return f0.apply(this,arguments)}finally{const i=PZ_CUES.indexOf(d);if(i>=0)PZ_CUES.splice(i,1)}}}
/* ---------- save and unlocks ---------- */
const pznIs=id=>PZN_ORDER.includes(id);
function pznVenueOpen(Z){Z=Z||PZS();return (Z.beat.grizzle||0)>0}
function pznOpen(id){const Z=PZS(),i=PZN_ORDER.indexOf(id);if(i<0||!pznVenueOpen(Z))return false;return i===0||(Z.beat[PZN_ORDER[i-1]]||0)>0}
function pznNorm(Z){if(!Z.o8||typeof Z.o8!=='object'||Array.isArray(Z.o8))Z.o8={seen:0};if(typeof Z.o8.seen!=='number'||!isFinite(Z.o8.seen))Z.o8.seen=0;
 if(Z.venue!=='tavern'&&Z.venue!=='o8')Z.venue='tavern';if(Z.venue==='o8'&&!((Z.beat.grizzle||0)>0))Z.venue='tavern';
 for(const k of PZN_ORDER){for(const o of[Z.beat,Z.rep])if(k in o){const v=o[k];if(typeof v!=='number'||!isFinite(v)||v<0)delete o[k];else o[k]=Math.floor(v)}}return Z}
{const f0=PZS;PZS=function(){const Z=f0.apply(this,arguments);try{pznNorm(Z)}catch(e){}return Z}}
{const f0=pzOpen;pzOpen=function(id){if(pznIs(id))return pznOpen(id);return f0.apply(this,arguments)}}
/* ---------- AI styles ---------- */
/* glitch: now and then the shot goes haywire (a wild power and a wobble), and his screen shows it */
{const f0=pzaNoise;pzaNoise=function(s,me,rng){const r=f0.apply(this,arguments);if(me&&me.glitch&&!s.brk&&!s.safety){const u=(rng||Math.random)();if(u<me.glitch){const k=(rng||Math.random)();r.pow=Math.max(.08,Math.min(1,r.pow*(k<.5?.55:1.55)));r.ang+=((rng||Math.random)()-.5)*.07;r.glitch=1}}return r}}
/* who has had the table: Rex's run counts his visits in a row; the break resets it */
{const f0=pzBeginTurn;pzBeginTurn=function(brk){try{const w=PZ.st?PZ.st.turn:-1;PZ.pznRun=(!brk&&w===1&&PZN.last===1)?(PZ.pznRun||0)+1:0;PZN.last=brk?-1:w}catch(e){}return f0.apply(this,arguments)}}
{const f0=pzAiBegin;pzAiBegin=function(){const r=f0.apply(this,arguments);try{const ai=PZ.ai,st=PZ.st,me=ai&&ai.me;if(me){
  if(me.streak&&PZ.pznRun>0)me.sig*=Math.max(.6,1-.12*PZ.pznRun);
  if(me.clutch&&st&&!st.brk&&pzrOn8(st))me.sig*=me.clutch}}catch(e){}return r}}
{const f0=pzAiFire;pzAiFire=function(){const ai=PZ.ai;try{if(ai&&ai.shot&&ai.shot.glitch&&PZ.reg&&PZ.reg.id==='bleep'){PZ.pznGlitch=performance.now();pzFloat(1430,520,'GLITCH!','#7af8ff');pzFx('no')}}catch(e){}return f0.apply(this,arguments)}}
/* house rule: the aim line only */
{const f0=pzGuideMode;pzGuideMode=function(){const R=PZ.reg;if(R&&R.house&&R.house.proGuide)return 'pro';return f0.apply(this,arguments)}}
{const f0=pzHudAll;pzHudAll=function(){const r=f0.apply(this,arguments);try{const R=PZ.reg;if(R&&R.house&&R.house.proGuide&&$('pzgdv'))$('pzgdv').textContent='Line'}catch(e){}return r}}
