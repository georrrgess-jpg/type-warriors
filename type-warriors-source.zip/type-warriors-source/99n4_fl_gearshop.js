/* ===== UPDATE 10.4, THE HARVEST FESTIVAL: the harvest relics in the shop (99n4, prefix flgs) =====
   The two Mythic harvest relics are sold for coins like the Halloween Mythics (FL.price, 99m; flgBuy / flgBuyBoth in 99n).
   The pieces here can be used by any screen:
     flgShopHTML(o)        three relic cards (armor, weapon, bundle), the Bountiful Harvest strip and the twelve-relic strip
     flgShopBind(root,cb)  paints their canvases and wires the buy buttons (cb(kind) after a purchase)
     flgShopWin(note)      a "Harvest Relics" window over the shop (#shmod), with a painted autumn header
   The Harvest Collection window of the chest part (99o) embeds these or calls flgBuy itself. When that part is not present
   (no flcOpenUI), the shop header gets a small "Harvest Relics" button so the relics can still be bought. */
const flgsSave=()=>FL.price.a+FL.price.w-FL.price.b;
function flgsThumbs(root){(root||ov).querySelectorAll('canvas[data-flg]').forEach(c=>{const [k,id]=c.dataset.flg.split(':');try{art(c,k,id,0)}catch(e){}})}
/* the twelve-relic strip: dark until owned */
function flgsStrip(){return `<div class="flgst">${flgItems().map(it=>{const d=(it.kind==='a'?AR:WP)[it.id],o=flgOwn(it.kind,it.id);return `<span class="flgi${o?' own':''}" style="--c:${d.col}" title="${esc(d.n)} (${d.r})${o?'':', not found yet'}"><canvas width="68" height="84" data-flg="${it.kind}:${it.id}"></canvas><i>${d.r[0]==='U'?'UN':d.r.slice(0,3).toUpperCase()}</i></span>`}).join('')}</div>`}
function flgShopHTML(o){o=o||{};const on=flShopOn(),g=+P.gold||0,oa=flgOwn('a','flfeast'),ow=flgOwn('w','fl_horn'),ar=AR.flfeast,wp=WP.fl_horn,ab=GAB.bounty;
 const btn=k=>{const why=flgWhyNot(k),pr=flgPriceOf(k),own=why==='owned';return `<button class="flgsb${own?' own':''}" data-flgb="${k}" ${why?'disabled':''}>${own?'✓ Owned':why==='part'?'Part owned':why==='ended'?'Festival over':why==='gold'?`<span><i class="coin"></i>${pr.toLocaleString()}</span><small>need ${(pr-g).toLocaleString()} more</small>`:`<span><i class="coin"></i>${pr.toLocaleString()}</span>`}</button>`};
 const card=(k,nm,sub,desc,prev,own)=>`<div class="flgsc${own?' own':''}${k==='b'?' bun':''}" data-k="${k}" style="--i:${'awb'.indexOf(k)}"><div class="flgscp">${prev}<i class="flgsgl"></i>${k==='b'?`<span class="flgssv">SAVE ${flgsSave().toLocaleString()}</span>`:''}</div><b>${nm}</b><em>${sub}</em><small>${desc}</small>${btn(k)}</div>`;
 return `<div class="flgs"><div class="flgsg">${card('a',esc(ar.n),'Mythic armor set',esc(ar.d.replace('. Ability: Bountiful Harvest','')),`<canvas width="200" height="250" data-flgl="a:flfeast"></canvas>`,oa)}
  ${card('w',esc(wp.n),'Mythic weapon',esc(wp.d.replace('. Ability: Bountiful Harvest','')),`<canvas width="200" height="250" data-flgl="w:fl_horn"></canvas>`,ow)}
  ${card('b','Feast Bundle','Armor and weapon together',`Both relics for ${FL.price.b.toLocaleString()} gold.`,`<span class="flgspair"><canvas width="150" height="190" data-flgl="a:flfeast"></canvas><canvas width="150" height="190" data-flgl="w:fl_horn"></canvas></span>`,oa&&ow)}</div>
  <div class="flgsab"><span class="flgsic"><canvas width="92" height="66" data-flgic="1"></canvas></span><div><b>Ability: ${esc(ab.n)}</b><span>${esc(ab.d)}</span></div><div class="flgsset"><b>Set bonus</b><span>${esc(ab.set.replace('Set bonus: ',''))}</span></div></div>
  ${o.noStrip?'':`<div class="flgscol"><div class="flgscolh"><b>Harvest relics</b><span>${flgCount()} / 12 found${typeof flcOpenUI==='function'?' · open Harvest Chests to find the rest':''}</span></div>${flgsStrip()}</div>`}
  ${on?'':`<p class="flgsend">The harvest is in. These relics are no longer sold.</p>`}</div>`}
function flgShopBind(root,cb){root=root||ov;flgsThumbs(root);
 root.querySelectorAll('canvas[data-flgl]').forEach((c,i)=>{const [k,id]=c.dataset.flgl.split(':'),cd=c.closest('.flgsc');let fr=0;LIVE.push({cv:c,fn:t=>{if(cd&&!cd.matches(':hover')&&(fr++%2))return;try{art(c,k,id,t+i)}catch(e){}}})});
 root.querySelectorAll('canvas[data-flgic]').forEach(c=>{const g=c.getContext('2d');try{g.drawImage(flbIconSpr(),0,0,92,66)}catch(e){}});
 root.querySelectorAll('[data-flgb]').forEach(b=>b.onclick=()=>{const k=b.dataset.flgb;if(!flgBuy(k))return;flgsCelebrate(root,k);if(typeof cb==='function')setTimeout(()=>cb(k),900)})}
function flgsCelebrate(root,k){try{beep(784,.12,'triangle',.7);setTimeout(()=>beep(1047,.16,'triangle',.7),110);setTimeout(()=>beep(1568,.3,'sine',.5),230);if(typeof axOn==='function'&&axOn()){const t0=ac.currentTime+.05;[72,76,79,84,88].forEach((m,i)=>cTone(sg,t0+i*.07,nf(m),.6,'triangle',.05,{a:.003,lp:3000,lp2:800}))}}catch(e){}
 const gv=document.getElementById('shgv');if(gv)gv.textContent=(+P.gold||0).toLocaleString();
 const card=root.querySelector(`.flgsc[data-k="${k}"]`);if(!card)return;card.classList.add('bought');
 for(let i=0;i<24;i++){const s=document.createElement('i');s.className='flgssp';s.style.cssText=`--dx:${((Math.random()-.5)*260).toFixed(0)}px;--dy:${(-60-Math.random()*200).toFixed(0)}px;--c:${['#ffcf4a','#ff7a3a','#c8e04a','#b06aff','#fff2b8'][i%5]};animation-delay:${(Math.random()*.15).toFixed(2)}s`;card.appendChild(s);setTimeout(()=>s.remove(),1300)}}

/* ---------- the window ---------- */
/* an autumn field at dusk behind the window title: a rising harvest moon, geese, hills, wheat, a scarecrow and drifting leaves */
function flgsScene(g,w,h,t,on){g.setTransform(1,0,0,1,0,0);
 let q=g.createLinearGradient(0,0,0,h);q.addColorStop(0,'#1a0c2a');q.addColorStop(.5,'#5a2a3a');q.addColorStop(1,'#a8542a');g.fillStyle=q;g.fillRect(0,0,w,h);
 for(let i=0;i<26;i++){const x=(i*131)%w,y=(i*37)%(h*.4);g.globalAlpha=.25+.4*Math.abs(Math.sin(t*1.1+i));g.fillStyle='#fff6e0';g.fillRect(x,y,1.5,1.5)}g.globalAlpha=1;
 const mx=w*.84,my=h*.46+Math.sin(t*.2)*2;ncGlow(g,mx,my,170,'#ffb43a44');g.fillStyle=rgr(g,mx-16,my-18,4,58,'#fff2c0','#f08a2a');g.beginPath();g.arc(mx,my,56,0,TAU);g.fill();g.fillStyle='#c8642a44';for(const [dx,dy,r] of[[-18,-10,10],[14,12,8],[20,-18,5],[-6,22,7]]){g.beginPath();g.arc(mx+dx,my+dy,r,0,TAU);g.fill()}
 {const u=(t*.05)%1,gx=-80+u*(w+160),gy=h*.22+Math.sin(u*6)*6;g.strokeStyle='#1a0c1c';g.lineWidth=2;for(const [dx,dy] of[[0,0],[-14,8],[-28,16],[-14,-8],[-28,-16],[-42,24]]){const f=Math.sin(t*7+dx)*3;g.beginPath();g.moveTo(gx+dx-6,gy+dy-f);g.lineTo(gx+dx,gy+dy);g.lineTo(gx+dx+6,gy+dy-f);g.stroke()}}
 g.fillStyle='#3a1a24';g.beginPath();g.moveTo(0,h*.74);g.quadraticCurveTo(w*.3,h*.52,w*.55,h*.7);g.quadraticCurveTo(w*.8,h*.86,w,h*.62);g.lineTo(w,h);g.lineTo(0,h);g.closePath();g.fill();
 g.fillStyle='#24101a';g.beginPath();g.moveTo(0,h*.86);g.quadraticCurveTo(w*.4,h*.72,w,h*.84);g.lineTo(w,h);g.lineTo(0,h);g.closePath();g.fill();
 /* wheat along the bottom */
 g.strokeStyle='#c8963a';g.lineWidth=2;for(let i=0;i<70;i++){const x=(i*29.7)%w,hh=26+(i*13)%22,sw=Math.sin(t*1.4+i*.6)*4;g.beginPath();g.moveTo(x,h);g.quadraticCurveTo(x+sw*.3,h-hh*.5,x+sw,h-hh);g.stroke();g.fillStyle='#e8b850';g.beginPath();g.ellipse(x+sw,h-hh-4,2.6,6,sw*.05,0,TAU);g.fill()}
 /* a scarecrow on the hill */
 {const sx=w*.2,sy=h*.66;g.strokeStyle='#1a0c12';g.lineWidth=5;g.beginPath();g.moveTo(sx,sy+60);g.lineTo(sx,sy-30);g.moveTo(sx-34,sy-6);g.lineTo(sx+34,sy-10);g.stroke();g.fillStyle='#1a0c12';g.beginPath();g.arc(sx,sy-38,11,0,TAU);g.fill();g.beginPath();g.moveTo(sx-20,sy-44);g.lineTo(sx+20,sy-46);g.lineTo(sx+8,sy-62);g.lineTo(sx-8,sy-62);g.closePath();g.fill();
  g.beginPath();g.moveTo(sx-16,sy-14);g.lineTo(sx+16,sy-16);g.lineTo(sx+20,sy+24);g.lineTo(sx-20,sy+26);g.closePath();g.fill()}
 /* pumpkins */
 for(const [x,r] of[[.36,16],[.42,11],[.9,14]])hwPumpkin(g,w*x,h-r*.9,r,t,{lit:false});
 /* drifting leaves */
 for(let i=0;i<9;i++){const u=((t*.08+i/9)%1),x=((i*197)%w)+Math.sin(t+i)*30-u*60,y=u*(h+30)-15;flgMaple(g,x,y,5+(i%3),t*1.4+i,['#e86a1e','#ffc040','#c8341a'][i%3],{ow:1,flat:1})}
 if(!on){g.fillStyle='#0008';g.fillRect(0,0,w,h)}}
function flgShopWin(note){if(typeof note!=='string')note='';let m=document.getElementById('shmod');if(!m){try{shop()}catch(e){return}m=document.getElementById('shmod');if(!m)return}
 const on=flShopOn();
 m.innerHTML=`<div class="shmc wide flgsw" id="flgsw"><button class="shx" aria-label="Close">×</button>
  <div class="flgshd"><canvas id="flgssc" width="1100" height="240"></canvas><div class="flgsht"><div><span class="flgslt">HARVEST FESTIVAL</span><span class="flgsdays">${on?esc(flLeft()):'The harvest is in'}</span></div><h3>Harvest Relics</h3><p>${on?'The Feastlord’s Mythic relics, sold only while the festival lasts.':'The festival is over. These relics are no longer sold.'}</p></div></div>
  ${note?`<div class="flgsnote">${esc(note)}</div>`:''}${flgShopHTML()}</div>`;
 m.classList.add('on');m.querySelector('.shx').onclick=shClose;m.onclick=e=>{if(e.target===m)shClose()};
 const sc=document.getElementById('flgssc'),sg2=sc.getContext('2d');LIVE.push({cv:sc,fn:t=>flgsScene(sg2,sc.width,sc.height,t,on)});
 flgShopBind(m,k=>{if(!document.getElementById('flgsw'))return;flgShopWin(k==='a'?`${AR.flfeast.n} is yours. Equip it in the Armory.`:k==='w'?`${WP.fl_horn.n} is yours. Equip it in the Armory.`:`The Feast Bundle is yours: ${AR.flfeast.n} and ${WP.fl_horn.n}.`)});
 try{beep(330,.3,'triangle',.35);setTimeout(()=>beep(440,.4,'triangle',.3),140)}catch(e){}}
/* a button in the shop header, only when the chest part (with its own Harvest Collection window) is not there */
{const sh0=shop;shop=function(){const r=sh0.apply(this,arguments);try{if(typeof flcOpenUI!=='function'&&(flShopOn()||flgCount()>0)){const h=ov.querySelector('.shh h2');if(h&&!ov.querySelector('.flgsp')){const b=document.createElement('button');b.className='flgsp';b.id='flgsp';b.innerHTML='<canvas width="58" height="42"></canvas><span>Harvest Relics</span>';h.after(b);
   const c=b.querySelector('canvas');try{c.getContext('2d').drawImage(flbIconSpr(),0,0,58,42)}catch(e){}b.onclick=()=>flgShopWin()}}}catch(e){}return r}}

{const st=document.createElement('style');st.textContent=`
.flgsp{all:unset;box-sizing:border-box;cursor:pointer;display:flex;align-items:center;gap:6px;padding:4px 16px 4px 8px;border-radius:24px;font:700 17px var(--ui);color:#2a1406;background:linear-gradient(180deg,#fff0a0,#f4b020 55%,#d88a10);border:2px solid #fff4b8;box-shadow:0 4px 0 #7a4a08,0 8px 16px #000a;transition:transform .15s}
.flgsp:hover{transform:translateY(-2px)}.flgsp:active{transform:translateY(2px)}.flgsp canvas{width:46px;height:33px}
.shmod:has(.flgsw){inset:58px -8px 50px}
.shmc.flgsw{padding:0;width:min(1120px,96%);background:linear-gradient(180deg,#24120e,#120a14);border:2px solid transparent;background-clip:padding-box;box-shadow:0 0 0 2px #ffcf4a77,0 0 50px #ff9a2a33,0 24px 60px #000e}
.flgsw .shx{color:#fff2b8;text-shadow:0 2px 6px #000}
.flgshd{position:relative;aspect-ratio:1100/240;overflow:hidden;border-radius:16px 16px 0 0}
.flgshd canvas{position:absolute;inset:0;width:100%;height:100%}
.flgshd::after{content:"";position:absolute;left:0;right:0;bottom:0;height:28px;background:linear-gradient(transparent,#24120e)}
.flgsht{position:absolute;left:0;right:0;top:20px;display:flex;flex-direction:column;align-items:center;gap:4px;z-index:1;text-align:center}
.flgsht>div{display:flex;gap:8px;align-items:center}
.flgslt{padding:3px 10px;border-radius:10px;font:800 11px var(--ui);letter-spacing:1.2px;color:#2a1406;background:linear-gradient(180deg,#ffe27a,#f6a830)}
.flgsdays{padding:3px 10px;border-radius:12px;background:#12081fcc;font:700 13px var(--ui);color:#ffcf4a}
.flgsht h3{margin:0 0 6px;font:400 64px/1.05 'Pirata One',Georgia,serif;color:#ffd45a;text-shadow:0 3px 0 #3a1a00,0 0 26px #ff9a2a88}
.flgsht p{margin:0;font:500 16px var(--ui);color:#fff0dc;text-shadow:0 2px 6px #000}
.flgsnote{margin:8px 24px 0;padding:10px 16px;border-radius:12px;background:#2a1a08e6;border:1.5px solid #ffcf4aaa;font:600 15px var(--ui);color:#fff2c8;text-align:center;animation:flgsin .4s ease both}
.flgs{padding:0 0 18px}
.flgsg{display:grid;grid-template-columns:1fr 1fr 1.25fr;gap:16px;padding:16px 24px 6px}
.flgsc{position:relative;display:flex;flex-direction:column;align-items:center;gap:4px;padding:12px 14px 14px;border-radius:18px;text-align:center;background:radial-gradient(ellipse at 50% 30%,#4a2614,#1a0c10 72%);border:2px solid #ffcf4a55;box-shadow:0 10px 24px #000a;transition:transform .25s,border-color .25s;animation:flgsin .55s cubic-bezier(.2,1.2,.4,1) calc(.1s + var(--i)*.09s) both}
@keyframes flgsin{from{opacity:0;transform:translateY(24px) scale(.96)}}
.flgsc:hover{transform:translateY(-6px);border-color:#ffcf4a}
.flgsc.bun{border-color:#ff9a2a88;background:radial-gradient(ellipse at 50% 30%,#5a2a14,#1e0c10 72%)}
.flgsc.own{border-color:#b8e05a}.flgsc.own::before{content:'OWNED';position:absolute;top:10px;right:10px;padding:3px 9px;border-radius:10px;font:800 11px var(--ui);letter-spacing:1px;color:#1a2a06;background:#c8f06a;z-index:2}
.flgscp{position:relative;display:flex;justify-content:center;align-items:flex-end;height:200px;width:100%}
.flgscp canvas{height:200px;width:160px;position:relative;z-index:1;-webkit-mask-image:radial-gradient(ellipse 60% 62% at 50% 48%,#000 62%,#0000 100%);mask-image:radial-gradient(ellipse 60% 62% at 50% 48%,#000 62%,#0000 100%);transition:transform .35s cubic-bezier(.3,1.6,.5,1)}
.flgsc:hover .flgscp canvas{transform:scale(1.07)}
.flgspair{display:flex;gap:4px;position:relative;z-index:1}.flgspair canvas{height:170px;width:134px}
.flgsgl{position:absolute;left:50%;bottom:8px;width:70%;height:40px;transform:translateX(-50%);border-radius:50%;background:radial-gradient(#ffcf4a66,transparent 70%);animation:flgsgl 2.6s ease-in-out infinite}
@keyframes flgsgl{50%{opacity:.5;transform:translateX(-50%) scale(1.15)}}
.flgssv{position:absolute;top:2px;left:50%;transform:translateX(-50%) rotate(-4deg);z-index:2;padding:4px 12px;border-radius:10px;font:800 13px var(--ui);letter-spacing:1px;color:#2a1406;background:linear-gradient(180deg,#fff0a0,#f0a820);box-shadow:0 4px 10px #000a}
.flgsc b{font:400 30px/1.05 'Pirata One',Georgia,serif;color:#ffd45a}.flgsc em{font:800 12px var(--ui);font-style:normal;letter-spacing:1.4px;text-transform:uppercase;color:#ff9a4a}
.flgsc small{font:500 13.5px/1.4 var(--ui);color:#f0e0d0;min-height:38px}
.flgsb{all:unset;box-sizing:border-box;cursor:pointer;margin-top:auto;display:flex;flex-direction:column;align-items:center;justify-content:center;min-width:72%;padding:9px 18px;border-radius:14px;font:800 22px var(--ui);color:#2a1406;background:linear-gradient(180deg,#fff0a0,#f4b020 55%,#d88a10);border:2px solid #fff4b8;box-shadow:0 5px 0 #7a4a08,0 8px 18px #000a;transition:transform .12s}
.flgsb .coin{width:22px;height:22px;margin-right:6px;vertical-align:-3px}.flgsb small{font:700 11px var(--ui);color:#ffdede;min-height:0}
.flgsb:hover:not(:disabled){transform:translateY(-2px)}.flgsb:active:not(:disabled){transform:translateY(3px)}
.flgsb:disabled{cursor:default;font-size:18px;color:#f0e8e0;background:linear-gradient(180deg,#5a3e3a,#2e1e22);border-color:#8a6a5a;box-shadow:0 4px 0 #1a0c10}
.flgsb.own,.flgsb.own:disabled{font-size:20px;color:#1a2a06;background:linear-gradient(180deg,#e0ffb0,#8ad83a);border-color:#f0ffd8;box-shadow:0 4px 0 #3a5a0a}
.flgsc.bought{animation:flgsbt .9s cubic-bezier(.3,1.6,.5,1)}@keyframes flgsbt{30%{transform:scale(1.06)}}
.flgssp{position:absolute;left:50%;top:40%;width:8px;height:8px;border-radius:50%;background:var(--c);z-index:3;pointer-events:none;animation:flgssp 1.1s ease-out forwards}
@keyframes flgssp{to{transform:translate(var(--dx),var(--dy)) scale(.2);opacity:0}}
.flgsab{display:flex;align-items:center;gap:16px;margin:10px 24px 0;padding:12px 18px;border-radius:14px;background:linear-gradient(90deg,#3a220a,#1a0c14);border:1.5px solid #ffcf4a66;animation:flgsin .5s ease .35s both}
.flgsic canvas{width:70px;height:50px;display:block}.flgsab>div{display:flex;flex-direction:column;gap:2px;flex:1}.flgsab b{font:400 24px 'Pirata One',Georgia,serif;color:#ffd45a}.flgsab span{font:500 13px/1.4 var(--ui);color:#f4e4cc}
.flgsab .flgsset{flex:.8;padding-left:16px;border-left:1px solid #ffcf4a44}.flgsset b{color:#c8f06a!important}
.flgscol{margin:12px 24px 0;padding:12px 16px;border-radius:14px;background:#12081faa;border:1px solid #ffffff1a;animation:flgsin .5s ease .45s both}
.flgscolh{display:flex;justify-content:space-between;align-items:baseline;gap:12px;margin-bottom:8px}.flgscolh b{font:400 24px 'Pirata One',Georgia,serif;color:#ffe8c0}.flgscolh span{font:600 13px var(--ui);color:#d8c0a8}
.flgst{display:flex;gap:8px;justify-content:center;flex-wrap:wrap}
.flgi{position:relative;display:flex;flex-direction:column;align-items:center;padding:4px 4px 2px;border-radius:12px;background:#ffffff0d;border:1.5px solid #ffffff1a}
.flgi canvas{width:54px;height:67px;filter:brightness(0) opacity(.45)}.flgi.own{border-color:var(--c);background:radial-gradient(ellipse at 50% 40%,color-mix(in srgb,var(--c) 22%,transparent),transparent 70%)}.flgi.own canvas{filter:none}
.flgi i{font:800 10px var(--ui);font-style:normal;letter-spacing:.6px;color:#d8c8b8}.flgi.own i{color:var(--c)}
.flgsend{margin:10px 24px 0;text-align:center;font:600 15px var(--ui);color:#e8c8a8}
`;document.head.appendChild(st)}
/* the Hall's "Almost complete" card: for the Bountiful Harvest set, "Find it in the Shop" opens the Harvest Relics window too */
{const ch0=catHall;catHall=function(){const r=ch0.apply(this,arguments);try{const gl=hlGoal();if(gl&&gl.key==='s:bounty')ov.querySelectorAll('[data-gs]').forEach(b=>b.addEventListener('click',()=>setTimeout(()=>{if(document.getElementById('shmod')&&typeof flcOpenUI!=='function')flgShopWin()},0)))}catch(e){}return r}}
