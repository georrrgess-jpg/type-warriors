/* ===== RUNESTONE TOWER DEFENSE 10.0: World 3 art - Skyforge Heights, part 1 (98g) =====
   The maps of World 3 (ids meadow, foundry, storm; data in 98a), filled into the 98a registries RPW.bake / amb / twist / ambTop /
   castleHit / icon / world. Part 1: shared helpers, the three castles, Cloudspire Meadows and the ambience hook. Part 2 (98g2):
   Gearworks Foundry, Storm Citadel, the map icons and the world painting.
   - Everything static is baked once per map into B.c (sky, islands or floor, roads that follow rpGeo(map).paths sample by sample,
     props and the castle). Pads are never baked: the engine draws them at rpGeo(map).pads, and props keep clear of them, of the roads
     and of the castle (rpw3aOcc).
   - Cloudspire Meadows: islands are a field on a 4 px grid (road and pad discs, extra blobs, noisy edges) carved by a sky channel under
     each rope bridge (map.bridge); the mask is extruded into cliffs with hanging rocks. B.isl is the same map without the sky, so the
     drifting clouds below the islands are drawn and then covered again by small B.isl patches (no full-screen redraw).
   - Gearworks Foundry: riveted plates, rail-track roads, the rail switch and its lever (map.sw, R.sw / R.swK), conveyor belts
     (map.conv), furnace vent grates (map.vents, the engine draws eruptions), molten channels, gears, chimneys.
   - Live layers draw only cached sprites and short paths, and draw less when R.lite or R.rm. Globals use the prefix rpw3a.
   - 10.1: the live layers (RPW.amb / twist / ambTop), rpw3aCastleLive, rpw3aSpinPut and rpw3aDR (a distance field) moved to 98g3,
     which also adds the bake extras and the click / battle reactions. */
const RPW3A={ids:{meadow:1,foundry:1,storm:1},cast:{},spr:{},pend:null};
const rpw3aR=i=>{const x=Math.sin(i*127.13+71.7)*43758.5453;return x-Math.floor(x)};
const rpw3aCv=(w,h)=>{const c=document.createElement('canvas');c.width=Math.max(1,Math.ceil(w));c.height=Math.max(1,Math.ceil(h));return c};
const rpw3aN=(x,y,s)=>{s=s||0;return Math.sin(x*.013+1.7+s)*Math.sin(y*.017+.3+s*2)*.5+Math.sin((x+y)*.0071+2+s)*.3+Math.sin(x*.031-y*.027+s*3)*.2};
function rpw3aO(g,w){g.strokeStyle=RPO;g.lineWidth=w||2.6;g.stroke()}
function rpw3aTint(src,col){const c=rpw3aCv(src.width,src.height),g=c.getContext('2d');g.drawImage(src,0,0);g.globalCompositeOperation='source-in';g.fillStyle=col;g.fillRect(0,0,c.width,c.height);return c}
function rpw3aPoly(g,a){g.beginPath();g.moveTo(a[0][0],a[0][1]);for(let i=1;i<a.length;i++)g.lineTo(a[i][0],a[i][1]);g.closePath()}
/* a sprite cached by key: draw(g) paints it at 2x into a w x h box with its anchor at (ax, ay) */
function rpw3aSpr(k,w,h,ax,ay,draw){if(RPW3A.spr[k])return RPW3A.spr[k];const c=rpw3aCv(w*2,h*2),g=c.getContext('2d');g.lineJoin='round';g.lineCap='round';g.scale(2,2);g.translate(ax,ay);draw(g);
 const o=rpw3aCv(w,h),h2=o.getContext('2d');h2.imageSmoothingQuality='high';h2.drawImage(c,0,0,w,h);return RPW3A.spr[k]={c:o,ax,ay,w,h}}
const rpw3aPut=(g,S,x,y,s)=>{s=s||1;g.drawImage(S.c,x-S.ax*s,y-S.ay*s,S.w*s,S.h*s)};
/* a turning sprite (gear, blades) as n pre-rendered frames over its symmetry period, so the live layers blit instead of rotating;
   sq squashes it flat (a gear lying on the floor) */
function rpw3aSpin(k,S,period,n,sq){const key='spin'+k;if(RPW3A.spr[key])return RPW3A.spr[key];const w=S.w,h=Math.ceil(S.h*(sq||1)),F=[];
 for(let i=0;i<n;i++){const c=rpw3aCv(w,h),g=c.getContext('2d');g.translate(w/2,h/2);if(sq)g.scale(1,sq);g.rotate(i/n*period);g.drawImage(S.c,-S.ax,-S.ay);F.push(c)}
 return RPW3A.spr[key]={F,period,n,w,h}}
/* stroke a road (or a part i0..i1 of it) along its samples */
function rpw3aLine(g,S,i0,i1,w,col){g.beginPath();g.moveTo(S[i0].x,S[i0].y);for(let i=i0+1;i<=i1;i++)g.lineTo(S[i].x,S[i].y);g.lineWidth=w;g.strokeStyle=col;g.stroke()}
/* runs of consecutive samples where keep(i) holds: [[i0,i1],...] */
function rpw3aRuns(n,keep){const o=[];let a=-1;for(let i=0;i<n;i++){if(keep(i)){if(a<0)a=i}else if(a>=0){o.push([a,i-1]);a=-1}}if(a>=0)o.push([a,n-1]);return o}
/* ---------- the land field -> crisp alpha mask (1600 x 900) ---------- */
function rpw3aMask(fn,s){s=s||4;const nx=Math.ceil(1600/s)+2,ny=Math.ceil(900/s)+2,F=new Float32Array(nx*ny);
 for(let j=0;j<ny;j++)for(let i=0;i<nx;i++)F[j*nx+i]=fn(i*s,j*s);
 const sm=rpw3aCv(nx,ny),sg=sm.getContext('2d'),im=sg.createImageData(nx,ny);for(let k=0;k<F.length;k++)im.data[k*4+3]=Math.max(0,Math.min(255,128+F[k]*28));sg.putImageData(im,0,0);
 const m=rpw3aCv(1600,900),g=m.getContext('2d');g.imageSmoothingEnabled=true;g.drawImage(sm,0,0,nx,ny,-s/2,-s/2,nx*s,ny*s);
 const id=g.getImageData(0,0,1600,900),d=id.data;for(let k=3;k<d.length;k+=4){const a=(d[k]-128)*3+128;d[k]=a<0?0:a>255?255:a}g.putImageData(id,0,0);
 const at=(x,y)=>{const i=Math.max(0,Math.min(nx-2,x/s)),j=Math.max(0,Math.min(ny-2,y/s)),i0=i|0,j0=j|0,u=i-i0,v=j-j0,a=F[j0*nx+i0],b=F[j0*nx+i0+1],c=F[(j0+1)*nx+i0],e=F[(j0+1)*nx+i0+1];return a+(b-a)*u+(c-a)*v+(a-b-c+e)*u*v};
 return{m,F,s,nx,ny,at}}
/* ---------- occupancy: props keep clear of roads, pads (and the towers on them), the castle, the entrances and each other ---------- */
function rpw3aOcc(G,cast,o){o=o||{};const L=[],P=G.pads,rw=o.rw||40,dR=rpw3aDR(G);G={dRoad:dR,pads:G.pads,ent:G.ent};
 const ok=(x,y,w,h,m)=>{m=m==null?10:m;if(x<-30||x>1630)return false;if(G.dRoad(x,y)<rw+m)return false;
  for(let k=10;k<h*.72;k+=12)for(const dx of[-w*.6,0,w*.6])if(G.dRoad(x+dx,y-k)<rw+4)return false;
  for(const p of P){const dx=Math.abs(x-p.x);if(dx<56+w&&y>p.y-46&&y-h<p.y+38)return false}
  if(cast&&x+w>cast.x+(o.cx||20)&&y-h<cast.y+cast.h&&y>cast.y+(o.cy||150))return false;
  if(G.ent.some(e=>Math.abs(x-e.x)<(o.ew||110)+w&&y>e.y-100&&y-h<e.y+70))return false;
  for(const q of L)if(Math.abs(x-q.x)<w+q.w+(o.gap||4)&&y-h<q.y+4&&y>q.y-q.h-4&&Math.abs(y-q.y)<(h+q.h)*.5+8)return false;
  if(o.ok&&!o.ok(x,y,w,h))return false;return true};
 return{ok,L,add:(x,y,w,h)=>L.push({x,y,w,h}),take:(x,y,w,h,m)=>{if(!ok(x,y,w,h,m))return false;L.push({x,y,w,h});return true}}}
/* ---------- shared painting helpers ---------- */
function rpw3aCloud(g,x,y,s,col,sh,ol){const C=[[0,0,1],[-1.05,.25,.72],[1.05,.22,.78],[-.5,-.45,.72],[.5,-.5,.8],[-1.75,.45,.5],[1.8,.45,.52]];
 const u=()=>{g.beginPath();for(const [dx,dy,r] of C){g.moveTo(x+dx*s+r*s,y+dy*s);g.arc(x+dx*s,y+dy*s,r*s,0,TAU)}};
 if(ol){u();g.strokeStyle=ol;g.lineWidth=Math.max(2,s*.12);g.stroke()}u();g.fillStyle=col;g.fill();g.save();u();g.clip();g.fillStyle=sh;g.beginPath();g.ellipse(x+s*.2,y+s*1.05,s*3,s*.75,0,0,TAU);g.fill();
 g.fillStyle='rgba(255,255,255,.45)';g.beginPath();g.ellipse(x-s*.6,y-s*.75,s*.9,s*.3,-.2,0,TAU);g.fill();g.restore()}
/* a soft cloud puff sprite (no outline) for drifting layers */
function rpw3aPuff(k,w,h,cols){return rpw3aSpr('puff'+k,w,h,w/2,h/2,g=>{for(let i=0;i<9;i++){const a=i/9*TAU,rx=w*.33*(.6+rpw3aR(i+k*9)*.5),x=Math.cos(a)*w*.18+(rpw3aR(i*3+k)-.5)*w*.2,y=Math.sin(a)*h*.12+(rpw3aR(i*5+k)-.5)*h*.12;
  const q=g.createRadialGradient(x,y,0,x,y,rx);q.addColorStop(0,cols[0]);q.addColorStop(.55,cols[1]);q.addColorStop(1,cols[2]);g.fillStyle=q;g.beginPath();g.ellipse(x,y,rx,rx*h/w*1.2,0,0,TAU);g.fill()}})}
/* a copper (or brass) dome; onion: bulging; by = base centre; C = [base, light, dark, patina] */
function rpw3aDome(g,cx,by,R,h,C,onion,fin){const E=R*.3,top=by-h;
 const path=()=>{g.beginPath();g.moveTo(cx-R,by);if(onion){g.bezierCurveTo(cx-R*1.32,by-h*.42,cx-R*.18,by-h*.66,cx,top);g.bezierCurveTo(cx+R*.18,by-h*.66,cx+R*1.32,by-h*.42,cx+R,by)}
  else{g.bezierCurveTo(cx-R,by-h*.62,cx-R*.56,top,cx,top);g.bezierCurveTo(cx+R*.56,top,cx+R,by-h*.62,cx+R,by)}g.ellipse(cx,by,R,E,0,0,Math.PI);g.closePath()};
 g.save();path();let q=g.createLinearGradient(cx-R*1.2,0,cx+R*1.2,0);q.addColorStop(0,C[0]);q.addColorStop(.28,C[1]);q.addColorStop(.6,C[0]);q.addColorStop(1,C[2]);g.fillStyle=q;g.fill();g.clip();
 g.strokeStyle='rgba(18,8,31,.35)';g.lineWidth=1.2;for(let k=-3;k<=3;k++){if(!k)continue;g.beginPath();g.moveTo(cx,top);g.quadraticCurveTo(cx+k*R*.42,by-h*.5,cx+k*R*.3,by+E)}g.stroke();
 if(C[3]){g.strokeStyle=C[3];g.globalAlpha=.75;g.lineWidth=2.2;for(let k=-2;k<=2;k++){const x=cx+k*R*.36;g.beginPath();g.moveTo(x,by-h*.32-rpw3aR(k+cx)*h*.2);g.lineTo(x+1,by+E*.8);g.stroke()}g.globalAlpha=1}
 g.fillStyle='rgba(255,255,255,.35)';g.beginPath();g.ellipse(cx-R*.42,by-h*.48,R*.16,h*.24,.25,0,TAU);g.fill();g.restore();path();rpw3aO(g,2.4);
 g.fillStyle=C[2];g.beginPath();g.ellipse(cx,by,R+2,E+2,0,0,Math.PI);g.lineTo(cx-R-2,by-3);g.ellipse(cx,by-3,R+2,E+2,0,Math.PI,0,true);g.closePath();g.fill();rpw3aO(g,1.8);
 if(fin!==0){g.strokeStyle=RPO;g.lineWidth=2;g.beginPath();g.moveTo(cx,top+2);g.lineTo(cx,top-(fin||14));g.stroke();g.fillStyle='#ffd45a';g.beginPath();g.arc(cx,top-2,3.2,0,TAU);g.fill();rpw3aO(g,1.5);
  g.beginPath();g.arc(cx,top-(fin||14)*.6,2.2,0,TAU);g.fill();rpw3aO(g,1.2)}return top-(fin||14)}
/* rivets in a row */
function rpw3aRiv(g,x0,y0,x1,y1,n,r,col){for(let i=0;i<n;i++){const u=n>1?i/(n-1):.5,x=x0+(x1-x0)*u,y=y0+(y1-y0)*u;g.fillStyle='rgba(18,8,31,.5)';g.beginPath();g.arc(x+.6,y+.8,r,0,TAU);g.fill();g.fillStyle=col||'#c8b89a';g.beginPath();g.arc(x,y,r,0,TAU);g.fill();g.fillStyle='rgba(255,255,255,.6)';g.beginPath();g.arc(x-r*.3,y-r*.3,r*.4,0,TAU);g.fill()}}
/* a gear: n teeth, outer radius R; sprite cached (used flat on walls, turned by the live layers) */
function rpw3aGear(k,R,n,C){return rpw3aSpr('gear'+k,R*2+8,R*2+8,R+4,R+4,g=>{const ri=R*.8,path=()=>{g.beginPath();for(let i=0;i<n;i++){const a=i/n*TAU,w=TAU/n;g.lineTo(Math.cos(a-w*.3)*ri,Math.sin(a-w*.3)*ri);g.lineTo(Math.cos(a-w*.17)*R,Math.sin(a-w*.17)*R);g.lineTo(Math.cos(a+w*.17)*R,Math.sin(a+w*.17)*R);g.lineTo(Math.cos(a+w*.3)*ri,Math.sin(a+w*.3)*ri)}g.closePath()};
 path();const q=g.createRadialGradient(-R*.3,-R*.3,R*.1,0,0,R);q.addColorStop(0,C[1]);q.addColorStop(.6,C[0]);q.addColorStop(1,C[2]);g.fillStyle=q;g.fill();rpw3aO(g,2.6);
 g.strokeStyle='rgba(18,8,31,.4)';g.lineWidth=1.4;g.beginPath();g.arc(0,0,ri*.86,0,TAU);g.stroke();
 const sp=n>14?6:5;g.fillStyle='rgba(18,8,31,.62)';for(let i=0;i<sp;i++){const a=i/sp*TAU+.3;g.beginPath();g.arc(Math.cos(a)*ri*.55,Math.sin(a)*ri*.55,ri*.2,0,TAU);g.fill()}
 g.fillStyle=C[1];g.beginPath();g.arc(0,0,ri*.3,0,TAU);g.fill();rpw3aO(g,2);g.fillStyle=C[2];g.beginPath();g.arc(0,0,ri*.12,0,TAU);g.fill();
 g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=2;g.beginPath();g.arc(0,0,R*.9,Math.PI*1.05,Math.PI*1.45);g.stroke()})}
/* an airship: striped envelope, wooden gondola, propeller (the live layer spins a separate prop sprite) */
function rpw3aShip(k,s,C){return rpw3aSpr('ship'+k,190*s,120*s,95*s,60*s,g=>{g.scale(s,s);
 g.fillStyle='rgba(20,40,80,.0)';const env=()=>{g.beginPath();g.ellipse(0,-14,70,30,0,0,TAU)};
 /* fins */for(const sy of[-1,1]){g.fillStyle=C[2];g.beginPath();g.moveTo(-56,-14);g.lineTo(-86,-14+sy*24);g.lineTo(-74,-14+sy*3);g.closePath();g.fill();rpw3aO(g,2)}
 env();g.fillStyle=C[0];g.fill();g.save();env();g.clip();g.fillStyle=C[1];for(let i=-3;i<=3;i+=2){g.beginPath();g.ellipse(i*14,-14,8,34,0,0,TAU);g.fill()}
 g.fillStyle='rgba(18,8,31,.25)';g.beginPath();g.ellipse(6,-2,72,22,0,0,TAU);g.fill();g.fillStyle='rgba(255,255,255,.4)';g.beginPath();g.ellipse(-16,-30,40,7,-.08,0,TAU);g.fill();g.restore();env();rpw3aO(g,2.6);
 g.strokeStyle=RPO;g.lineWidth=1.4;g.beginPath();for(const x of[-30,-10,10,30]){g.moveTo(x,12);g.lineTo(x*.7,24)}g.stroke();
 /* gondola */g.beginPath();g.moveTo(-34,22);g.lineTo(34,22);g.quadraticCurveTo(30,40,16,42);g.lineTo(-20,42);g.quadraticCurveTo(-34,38,-34,22);g.closePath();g.fillStyle='#8a5a32';g.fill();
 g.save();g.clip();g.fillStyle='#6a4024';g.fillRect(-40,33,80,3);g.fillStyle='rgba(255,220,160,.25)';g.fillRect(-40,22,80,4);g.restore();g.beginPath();g.moveTo(-34,22);g.lineTo(34,22);g.quadraticCurveTo(30,40,16,42);g.lineTo(-20,42);g.quadraticCurveTo(-34,38,-34,22);g.closePath();rpw3aO(g,2.2);
 for(const x of[-18,-4,10]){g.fillStyle='#ffe08a';g.beginPath();g.arc(x,30,2.6,0,TAU);g.fill();rpw3aO(g,1.2)}
 g.fillStyle=C[3]||'#ffd45a';g.beginPath();g.moveTo(-34,24);g.lineTo(-44,28);g.lineTo(-34,32);g.closePath();g.fill();rpw3aO(g,1.4)})}
function rpw3aPropSpr(){return rpw3aSpr('prop',24,24,12,12,g=>{g.fillStyle='#e8d8b0';for(let i=0;i<3;i++){g.save();g.rotate(i/3*TAU);g.beginPath();g.ellipse(0,-6,2.6,6.5,0,0,TAU);g.fill();rpw3aO(g,1.2);g.restore()}g.fillStyle='#5a4030';g.beginPath();g.arc(0,0,2.4,0,TAU);g.fill();rpw3aO(g,1)})}

/* ======================================================================================================================
   The castles. Each is painted at 2x into 300 x 520 (like 95h) with the gate point (140, 440) on the road's end; A records the live bits.
   ====================================================================================================================== */
const RPW3A_CP={
 meadow:{st:'#ece6f4',sl:'#ffffff',sd:'#b4aed0',sk:'#7e78a6',roof:'#d8743a',rl:'#ffb27a',rd:'#8a3a1a',ban:'#3a8ae0',ban2:'#ffd45a',win:'#ffe08a',winG:'255,200,110',
  rock:'#9a8a7a',rockL:'#d0c2b0',rockD:'#5e5048',wood:'#8a5a32',iron:'#4a4a62'},
 foundry:{st:'#6a5a52',sl:'#9a887a',sd:'#463a36',sk:'#2a2220',roof:'#c89a3a',rl:'#ffe08a',rd:'#6a4a14',ban:'#c8402a',ban2:'#ffc94a',win:'#ffb24a',winG:'255,150,50',
  rock:'#4a4040',rockL:'#7a6c66',rockD:'#2a2222',wood:'#5a3a24',iron:'#3a3440'},
 storm:{st:'#5a6482',sl:'#8a96b8',sd:'#3a4260',sk:'#232840',roof:'#2e3a6a',rl:'#5a74b8',rd:'#141c3a',ban:'#3a4ac8',ban2:'#9ae8ff',win:'#ffd27a',winG:'255,190,100',
  rock:'#3a4058',rockL:'#6a7494',rockD:'#1e2236',wood:'#3a3240',iron:'#2a2e40'}};
const RPW3A_CU=['#d8743a','#ffb27a','#8a3a1a','#5ad0b0'],RPW3A_BR=['#c89a3a','#ffe08a','#6a4a14',null];
function rpw3aCastle(id){if(RPW3A.cast[id])return RPW3A.cast[id];const A={id,w:300,h:520,gx:140,gy:440,flags:[],wins:[],torch:[],spark:[],glow:[],smoke:[],orb:null,gear:null,ship:null};
 const c2=rpw3aCv(600,1040),g=c2.getContext('2d');g.lineJoin='round';g.lineCap='round';g.scale(2,2);A.P=RPW3A_CP[id];
 try{(id==='meadow'?rpw3aPaintCloud:id==='foundry'?rpw3aPaintForge:rpw3aPaintStorm)(g,A)}catch(e){console.error(e)}
 const c=rpw3aCv(300,520),h=c.getContext('2d');h.imageSmoothingQuality='high';h.drawImage(c2,0,0,300,520);A.c=c;A.c2=c2;return RPW3A.cast[id]=A}
/* the cloud castle (Cloudspire Meadows): white stone, copper domes with verdigris, sky-blue banners, a cloud bank round its feet */
function rpw3aPaintCloud(g,A){const P=A.P,id='moss',cu=RPW3A_CU;
 const cl=(x,y,s,a)=>{g.globalAlpha=a||1;rpw3aCloud(g,x,y,s,'#ffffff','#d6dcf4',RPO);g.globalAlpha=1};
 /* clouds behind */cl(250,330,26);cl(52,250,18);cl(270,200,16);
 /* back: the tall spire tower with an onion dome */
 {const cx=196,t=rpwDrum(g,P,cx,236,40,150,11);rpwWin(g,P,id,A,cx-6,t+24,12,20);rpwWin(g,P,id,A,cx-6,t+80,12,20);const ft=rpw3aDome(g,cx,t,25,62,cu,1,22);A.flags.push({x:cx,y:ft,len:30,col:P.ban,c2:P.ban2})}
 /* the keep: wall block with a great copper dome */
 rpwWall(g,P,104,190,128,150,31,10);rpwCren(g,P,'moss',104,190,128,10);
 {const t=rpwDrum(g,P,168,190,84,30,7);A.glow.push([168,t+8,60]);rpw3aDome(g,168,t,44,74,cu,0,26);
  for(const x of[146,182])rpwWin(g,P,id,A,x,t+6,10,16)}
 for(const [x,y] of[[118,220],[150,220],[186,220],[212,220],[132,272],[200,272]])rpwWin(g,P,id,A,x,y,12,22);
 /* round window with a gold frame */
 {const x=168,y=286,r=16;g.fillStyle='#ffd45a';g.beginPath();g.arc(x,y,r+4,0,TAU);g.fill();rpw3aO(g,2.2);g.fillStyle=P.win;g.beginPath();g.arc(x,y,r,0,TAU);g.fill();
  g.strokeStyle=RPO;g.lineWidth=1.5;g.beginPath();for(let k=0;k<6;k++){g.moveTo(x,y);g.lineTo(x+Math.cos(k/6*TAU)*r,y+Math.sin(k/6*TAU)*r)}g.stroke();g.beginPath();g.arc(x,y,r,0,TAU);g.stroke();A.wins.push([x,y,30])}
 /* corner turrets of the keep */
 for(const cx of[106,230]){const t=rpwDrum(g,P,cx,300,28,150,cx);rpw3aDome(g,cx,t,17,34,cu,1,cx>200?18:12);rpwWin(g,P,id,A,cx-4,t+30,9,16);if(cx>200)A.flags.push({x:cx,y:t-52,len:22,col:P.ban,c2:P.ban2})}
 /* curtain walls */
 rpwWall(g,P,56,262,64,96,51,9);rpwCren(g,P,'moss',56,262,64,9);rpwWall(g,P,184,300,40,176,61,9);rpwCren(g,P,'moss',184,300,40,9);
 /* left tower with a small dome */
 {const t=rpwDrum(g,P,46,362,46,170,71);rpw3aDome(g,46,t,27,52,cu,0,20);rpwWin(g,P,id,A,40,t+34,11,19);rpwWin(g,P,id,A,40,t+94,11,19);A.flags.push({x:46,y:t-74,len:24,col:P.ban,c2:P.ban2})}
 /* right great tower with a copper onion dome and an airship moored to it */
 {const cx=248,w=68,t=rpwDrum(g,P,cx,490,w,226,81);rpw3aDome(g,cx,t,40,90,cu,1,26);
  rpwWin(g,P,id,A,cx-6,t+40,12,21);rpwWin(g,P,id,A,cx-16,t+106,11,19);rpwWin(g,P,id,A,cx+6,t+150,10,18);rpwBanner(g,P,'frost',cx-10,t+62,20,44);
  /* a little sky-dock on the tower */g.fillStyle=P.wood;g.beginPath();g.rect(cx+22,t+92,38,7);g.fill();rpw3aO(g,2);g.strokeStyle=RPO;g.lineWidth=2;g.beginPath();g.moveTo(cx+26,t+99);g.lineTo(cx+34,t+114);g.moveTo(cx+56,t+99);g.lineTo(cx+44,t+114);g.stroke();A.ship=[cx+36,t+52]}
 /* the gatehouse */
 rpwWall(g,P,96,326,88,148,91,9);rpwCren(g,P,'moss',96,326,88,9);
 g.fillStyle=P.sl;g.fillRect(90,470,100,7);g.strokeStyle=RPO;g.lineWidth=2.2;g.strokeRect(90,470,100,7);
 rpwGate(g,P,'moss',A,140,470,48,82);
 /* crest: a winged cloud */{const x=140,y=352;g.fillStyle='#ffd45a';g.beginPath();g.moveTo(x-12,y-11);g.lineTo(x+12,y-11);g.lineTo(x+12,y);g.quadraticCurveTo(x+12,y+10,x,y+15);g.quadraticCurveTo(x-12,y+10,x-12,y);g.closePath();g.fill();rpw3aO(g,2.2);
  g.fillStyle=P.ban;g.beginPath();g.moveTo(x-9,y-8);g.lineTo(x+9,y-8);g.lineTo(x+9,y);g.quadraticCurveTo(x+9,y+7,x,y+11);g.quadraticCurveTo(x-9,y+7,x-9,y);g.closePath();g.fill();
  g.fillStyle='#ffffff';g.beginPath();g.arc(x-4,y+1,3.4,0,TAU);g.arc(x+1,y-2,4,0,TAU);g.arc(x+5,y+1,3,0,TAU);g.fill();
  for(const s of[-1,1]){g.fillStyle='#ffffff';g.beginPath();g.moveTo(x+s*12,y-6);g.quadraticCurveTo(x+s*26,y-14,x+s*28,y-4);g.quadraticCurveTo(x+s*22,y-2,x+s*24,y+3);g.quadraticCurveTo(x+s*18,y+2,x+s*12,y+2);g.closePath();g.fill();rpw3aO(g,1.6)}}
 rpwBanner(g,P,'frost',101,342,15,40);rpwBanner(g,P,'frost',164,342,15,40);rpwTorch(g,A,108,404);rpwTorch(g,A,172,404);
 for(const cx of[96,184]){g.fillStyle=P.sd;g.beginPath();g.moveTo(cx-12,360);g.lineTo(cx,382);g.lineTo(cx+12,360);g.closePath();g.fill();rpw3aO(g,2.2);const t=rpwDrum(g,P,cx,362,24,48,cx+3);rpw3aDome(g,cx,t,14,26,cu,1,10)}
 rpwBridge(g,P,140,476,48,22,412);
 /* the cloud bank round the base (kept off the road on the left) */
 cl(222,500,22);cl(270,492,20);cl(196,512,14);cl(290,512,16);cl(28,392,14);cl(66,398,12);
 A.spark.push([168,112],[248,170],[196,92],[46,150])}
/* the foundry fortress (Gearworks Foundry): iron and brick, brass domes, smokestacks, a great gear over a blast-door gate */
function rpw3aPaintForge(g,A){const P=A.P,id='frost',br=RPW3A_BR;
 const stack=(x,by,w,h)=>{g.beginPath();g.moveTo(x-w/2,by);g.lineTo(x-w*.42,by-h);g.lineTo(x+w*.42,by-h);g.lineTo(x+w/2,by);g.closePath();const q=g.createLinearGradient(x-w/2,0,x+w/2,0);q.addColorStop(0,'#8a4a3a');q.addColorStop(.3,'#b8644a');q.addColorStop(1,'#4a2420');g.fillStyle=q;g.fill();
  g.save();g.clip();g.strokeStyle='rgba(18,8,31,.35)';g.lineWidth=1;for(let y=by-6;y>by-h;y-=6){g.beginPath();g.moveTo(x-w,y);g.lineTo(x+w,y);g.stroke();for(let xx=x-w/2+((y/6)%2?4:0);xx<x+w/2;xx+=9){g.beginPath();g.moveTo(xx,y);g.lineTo(xx,y+6);g.stroke()}}
  g.fillStyle='rgba(18,8,31,.45)';g.fillRect(x-w/2,by-h,w,12);g.restore();g.beginPath();g.moveTo(x-w/2,by);g.lineTo(x-w*.42,by-h);g.lineTo(x+w*.42,by-h);g.lineTo(x+w/2,by);g.closePath();rpw3aO(g,2.4);
  g.fillStyle='#3a3440';g.fillRect(x-w*.5,by-h-6,w,8);g.strokeRect(x-w*.5,by-h-6,w,8);g.fillStyle='#1a1214';g.beginPath();g.ellipse(x,by-h-6,w*.4,3,0,0,TAU);g.fill();A.smoke.push([x,by-h-8,w])};
 /* smokestacks at the back */stack(70,240,24,150);stack(222,200,30,170);stack(262,260,22,130);
 /* the keep: dark iron block with brass dome */
 rpwWall(g,P,104,190,128,150,31,10);rpwCren(g,P,'frost',104,190,128,10);
 {const t=rpwDrum(g,P,168,190,80,26,7);rpw3aDome(g,168,t,42,60,br,0,22);A.glow.push([168,t-20,40])}
 for(const [x,y] of[[118,222],[150,222],[186,222],[212,222]])rpwWin(g,P,id,A,x,y,12,22);
 /* the great gear on the keep face (turned by the live layer) */
 {const G=rpw3aGear('fk',28,14,['#c89a3a','#ffe08a','#6a4a14']);g.fillStyle='#1a1214';g.beginPath();g.arc(168,288,31,0,TAU);g.fill();rpw3aO(g,2);A.gear=[168,288,28]}
 for(const cx of[106,230]){const t=rpwDrum(g,P,cx,300,28,150,cx);rpw3aDome(g,cx,t,16,26,br,0,12);rpwWin(g,P,id,A,cx-4,t+30,9,16)}
 rpwWall(g,P,56,262,64,96,51,9);rpwCren(g,P,'frost',56,262,64,9);rpwWall(g,P,184,300,40,176,61,9);rpwCren(g,P,'frost',184,300,40,9);
 /* pipes along the curtain wall */
 for(const [x0,y0,x1,y1] of[[60,300,120,300],[188,340,222,340]]){g.strokeStyle=RPO;g.lineWidth=8;g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.stroke();g.strokeStyle='#c89a3a';g.lineWidth=5;g.stroke();g.strokeStyle='rgba(255,240,180,.6)';g.lineWidth=1.4;g.beginPath();g.moveTo(x0,y0-1.5);g.lineTo(x1,y1-1.5);g.stroke()}
 {const t=rpwDrum(g,P,46,362,46,170,71);rpw3aDome(g,46,t,26,40,br,0,18);rpwWin(g,P,id,A,40,t+34,11,19);rpwWin(g,P,id,A,40,t+94,11,19);A.flags.push({x:46,y:t-60,len:24,col:P.ban,c2:P.ban2})}
 {const cx=248,w=68,t=rpwDrum(g,P,cx,490,w,226,81);rpwRing(g,P,'frost',cx,t,w);const t2=rpwDrum(g,P,cx,t-11,48,30,82);rpw3aDome(g,cx,t2,28,46,br,0,24);A.flags.push({x:cx,y:t2-70,len:30,col:P.ban,c2:P.ban2});
  rpwWin(g,P,id,A,cx-6,t+40,12,21);rpwWin(g,P,id,A,cx-16,t+106,11,19);rpwWin(g,P,id,A,cx+6,t+150,10,18);rpwBanner(g,P,'ember',cx-10,t+62,20,44);
  /* hazard stripes round the base */g.save();g.beginPath();g.rect(cx-w/2,452,w,14);g.clip();for(let x=cx-w/2-14;x<cx+w/2;x+=12){g.fillStyle='#ffc94a';g.beginPath();g.moveTo(x,466);g.lineTo(x+6,466);g.lineTo(x+20,452);g.lineTo(x+14,452);g.closePath();g.fill()}g.restore();g.strokeStyle=RPO;g.lineWidth=2;g.strokeRect(cx-w/2,452,w,14)}
 /* the gatehouse with a blast door */
 rpwWall(g,P,96,326,88,148,91,9);rpwCren(g,P,'frost',96,326,88,9);g.fillStyle=P.sl;g.fillRect(90,470,100,7);g.strokeStyle=RPO;g.lineWidth=2.2;g.strokeRect(90,470,100,7);
 rpwGate(g,P,'ember',A,140,470,48,82);
 /* gear crest */{const x=140,y=352;g.save();g.translate(x,y);const G=rpw3aGear('crest',13,10,['#ffc94a','#fff0b0','#8a5a14']);g.drawImage(G.c,-G.ax,-G.ay);g.restore();g.fillStyle='#c8402a';g.beginPath();g.arc(x,y,4,0,TAU);g.fill();rpw3aO(g,1.4)}
 rpwBanner(g,P,'ember',101,342,15,40);rpwBanner(g,P,'ember',164,342,15,40);rpwTorch(g,A,108,404);rpwTorch(g,A,172,404);
 for(const cx of[96,184]){g.fillStyle=P.sd;g.beginPath();g.moveTo(cx-12,360);g.lineTo(cx,382);g.lineTo(cx+12,360);g.closePath();g.fill();rpw3aO(g,2.2);const t=rpwDrum(g,P,cx,362,24,48,cx+3);rpw3aDome(g,cx,t,14,20,br,0,8)}
 rpwBridge(g,P,140,476,48,22,412);
 rpwRocks(g,P,'frost',[[206,508,56,30],[246,516,70,34],[286,516,40,26]],27);
 /* coal heaps and an ingot stack in front */for(const [x,y] of[[214,506],[286,508]]){g.fillStyle='#1e1a1e';g.beginPath();g.ellipse(x,y,16,8,0,Math.PI,0);g.closePath();g.fill();rpw3aO(g,1.8);g.fillStyle='rgba(255,255,255,.2)';for(let i=0;i<5;i++){g.beginPath();g.arc(x-8+i*4,y-3-(i%2)*3,1.4,0,TAU);g.fill()}}
 A.spark.push([168,128],[248,190])}
/* the storm citadel (Storm Citadel): dark slate, tall spires tipped with rods and storm crystals, a crackling orb on the great spire */
function rpw3aPaintStorm(g,A){const P=A.P,id='frost';
 const spire=(cx,by,R,h,orb)=>{const E=R*.3,ax=cx,ay=by-h;const path=()=>{g.beginPath();g.moveTo(cx-R,by);g.lineTo(cx-R*.5,by-h*.42);g.lineTo(ax,ay);g.lineTo(cx+R*.5,by-h*.42);g.lineTo(cx+R,by);g.ellipse(cx,by,R,E,0,0,Math.PI);g.closePath()};
  g.save();path();const q=g.createLinearGradient(cx-R,0,cx+R,0);q.addColorStop(0,P.roof);q.addColorStop(.3,P.rl);q.addColorStop(.6,P.roof);q.addColorStop(1,P.rd);g.fillStyle=q;g.fill();g.clip();
  g.strokeStyle='rgba(18,8,31,.4)';g.lineWidth=1.1;for(let i=1;i<9;i++){const y=ay+h*i/9;g.beginPath();g.moveTo(cx-R,y);g.lineTo(cx+R,y);g.stroke()}
  g.strokeStyle='rgba(160,220,255,.5)';g.lineWidth=1.4;g.beginPath();g.moveTo(ax,ay+4);g.lineTo(cx-R*.3,by+E);g.stroke();g.restore();path();rpw3aO(g,2.4);
  g.strokeStyle=RPO;g.lineWidth=2.4;g.beginPath();g.moveTo(ax,ay+2);g.lineTo(ax,ay-(orb?26:16));g.stroke();g.strokeStyle='#c8d0e8';g.lineWidth=1.2;g.stroke();
  if(orb){g.fillStyle='#bff0ff';g.beginPath();g.arc(ax,ay-30,orb,0,TAU);g.fill();rpw3aO(g,2);g.fillStyle='#ffffff';g.beginPath();g.arc(ax-orb*.3,ay-30-orb*.3,orb*.35,0,TAU);g.fill();A.glow.push([ax,ay-30,orb*5])}
  else{g.fillStyle='#9ae8ff';g.beginPath();g.moveTo(ax,ay-22);g.lineTo(ax+3,ay-16);g.lineTo(ax,ay-10);g.lineTo(ax-3,ay-16);g.closePath();g.fill();rpw3aO(g,1.2);A.spark.push([ax,ay-16])}
  return ay};
 rpwRocks(g,P,id,[[278,300,40,60],[284,370,36,70],[280,440,44,80],[286,512,40,90]],40);
 /* the great spire with the storm orb */
 {const cx=170,t=rpwDrum(g,P,cx,200,46,120,11);rpwWin(g,P,id,A,cx-6,t+20,12,22);rpwWin(g,P,id,A,cx-6,t+66,12,22);const ay=spire(cx,t,28,100,9);A.orb=[cx,ay-30]}
 rpwWall(g,P,104,190,128,150,31,10);rpwCren(g,P,'ember',104,190,128,10);
 for(const [x,y] of[[118,222],[150,226],[186,226],[212,222],[132,276],[200,276]])rpwWin(g,P,id,A,x,y,12,22);
 for(const cx of[106,230]){const t=rpwDrum(g,P,cx,300,28,152,cx);spire(cx,t,17,64,0);rpwWin(g,P,id,A,cx-4,t+30,9,16)}
 rpwWall(g,P,56,262,64,96,51,9);rpwCren(g,P,'ember',56,262,64,9);rpwWall(g,P,184,300,40,176,61,9);rpwCren(g,P,'ember',184,300,40,9);
 {const t=rpwDrum(g,P,46,362,44,180,71);spire(46,t,25,96,0);rpwWin(g,P,id,A,40,t+34,11,19);rpwWin(g,P,id,A,40,t+94,11,19);A.flags.push({x:46,y:t-112,len:26,col:P.ban,c2:P.ban2})}
 {const cx=248,w=66,t=rpwDrum(g,P,cx,490,w,232,81);rpwRing(g,P,'ember',cx,t,w);spire(cx,t-11,30,120,6);rpwWin(g,P,id,A,cx-6,t+40,12,21);rpwWin(g,P,id,A,cx-16,t+106,11,19);rpwWin(g,P,id,A,cx+6,t+150,10,18);
  /* lightning banner */{const x=cx-10,y=t+62,w2=20,h=44;g.beginPath();g.moveTo(x,y);g.lineTo(x+w2,y);g.lineTo(x+w2,y+h);g.lineTo(x+w2/2,y+h-8);g.lineTo(x,y+h);g.closePath();g.fillStyle=P.ban;g.fill();rpw3aO(g,2.2);
   g.fillStyle='#ffe46a';g.beginPath();g.moveTo(x+12,y+6);g.lineTo(x+5,y+20);g.lineTo(x+10,y+20);g.lineTo(x+7,y+34);g.lineTo(x+16,y+16);g.lineTo(x+11,y+16);g.closePath();g.fill();rpw3aO(g,1.2);g.fillStyle='#ffd45a';g.fillRect(x-3,y-2.5,w2+6,4)}}
 rpwWall(g,P,96,326,88,148,91,9);rpwCren(g,P,'ember',96,326,88,9);g.fillStyle=P.sl;g.fillRect(90,470,100,7);g.strokeStyle=RPO;g.lineWidth=2.2;g.strokeRect(90,470,100,7);
 rpwGate(g,P,'frost',A,140,470,48,82);
 /* crest: a bolt on a shield */{const x=140,y=352;g.fillStyle='#9ae8ff';g.beginPath();g.moveTo(x-12,y-11);g.lineTo(x+12,y-11);g.lineTo(x+12,y);g.quadraticCurveTo(x+12,y+10,x,y+15);g.quadraticCurveTo(x-12,y+10,x-12,y);g.closePath();g.fill();rpw3aO(g,2.2);
  g.fillStyle=P.ban;g.beginPath();g.moveTo(x-9,y-8);g.lineTo(x+9,y-8);g.lineTo(x+9,y);g.quadraticCurveTo(x+9,y+7,x,y+11);g.quadraticCurveTo(x-9,y+7,x-9,y);g.closePath();g.fill();
  g.fillStyle='#ffe46a';g.beginPath();g.moveTo(x+3,y-7);g.lineTo(x-4,y+2);g.lineTo(x,y+2);g.lineTo(x-2,y+9);g.lineTo(x+5,y-1);g.lineTo(x+1,y-1);g.closePath();g.fill()}
 for(const x of[101,164]){const y=342,w2=15,h=40;g.beginPath();g.moveTo(x,y);g.lineTo(x+w2,y);g.lineTo(x+w2,y+h);g.lineTo(x+w2/2,y+h-6);g.lineTo(x,y+h);g.closePath();g.fillStyle=P.ban;g.fill();rpw3aO(g,2);g.fillStyle='#ffe46a';g.beginPath();g.moveTo(x+9,y+6);g.lineTo(x+4,y+17);g.lineTo(x+8,y+17);g.lineTo(x+5,y+29);g.lineTo(x+12,y+14);g.lineTo(x+8,y+14);g.closePath();g.fill();g.fillStyle='#9ae8ff';g.fillRect(x-3,y-2.5,w2+6,4)}
 rpwTorch(g,A,108,404);rpwTorch(g,A,172,404);
 for(const cx of[96,184]){g.fillStyle=P.sd;g.beginPath();g.moveTo(cx-12,360);g.lineTo(cx,382);g.lineTo(cx+12,360);g.closePath();g.fill();rpw3aO(g,2.2);const t=rpwDrum(g,P,cx,362,24,48,cx+3);spire(cx,t,14,40,0)}
 rpwBridge(g,P,140,476,48,22,412);
 rpwRocks(g,P,id,[[206,508,56,30],[246,516,70,34],[286,516,40,26],[194,494,26,16]],27);
 for(const [x,y,h,a] of[[214,500,22,-.3],[226,504,30,.15],[292,500,22,.4]])rpwCrystal(g,x,y,h,a,0,['#e8fbff','#9ae8ff','#5a9ae8','#2a3a98'])}
/* hit flinch: red silhouette, a small shake and flying rubble (k 0..1) */
function rpw3aCastleHit(id,c,x,y,k){const A=rpw3aCastle(id);if(k<0||k>=1)return;if(!A.red)A.red=rpw3aTint(A.c,'#ff2a3a');
 const e=1-k,dx=Math.sin(k*46)*5*e,dy=Math.cos(k*39)*2*e;c.save();c.globalAlpha=.55*e;c.drawImage(A.red,x+dx,y+dy);c.globalAlpha=Math.min(1,e*1.4);
 for(let i=0;i<7;i++){const a=-Math.PI*(.15+rpw3aR(i+3)*.7),v=40+rpw3aR(i+9)*70,px=x+A.gx+30+rpw3aR(i)*80+Math.cos(a)*v*k,py=y+A.gy-60-rpw3aR(i+5)*120+Math.sin(a)*v*k+160*k*k;
  c.fillStyle=i%2?A.P.st:A.P.sd;c.beginPath();c.rect(px-3,py-3,6,5);c.fill();c.strokeStyle=RPO;c.lineWidth=1.4;c.stroke()}c.restore()}

/* ======================================================================================================================
   Cloudspire Meadows
   ====================================================================================================================== */
/* land with cliffs: hanging rocks under the south rims, the mask extruded D px down with strata parallel to the rim, cliff texture, the
   top (a canvas already masked to the land) with an outline, a lit lip and tufts over the rim. o.pre runs before the slab (islets). */
function rpw3aTerrain(g,M,o){const H=900,D=o.D,mk=rpw3aTint(M.m,RPO),edgeB=[],edgeT=[];
 for(let j=1;j<M.ny-1;j++)for(let i=0;i<M.nx;i++){const v=M.F[j*M.nx+i];if(v<=0)continue;if(M.F[(j+1)*M.nx+i]<=0)edgeB.push([i*M.s,j*M.s]);if(M.F[(j-1)*M.nx+i]<=0)edgeT.push([i*M.s,j*M.s])}
 for(let k=0;k<edgeB.length;k+=5){const [x,y]=edgeB[k];if(rpw3aR(k)<.25)continue;const l=26+rpw3aR(k+3)*(o.coneL||70),w=14+rpw3aR(k+5)*22,yy=y+D-6;
  g.beginPath();g.moveTo(x-w,yy);g.quadraticCurveTo(x-w*.4,yy+l*.6,x+(rpw3aR(k+7)-.5)*10,yy+l);g.quadraticCurveTo(x+w*.5,yy+l*.5,x+w,yy);g.closePath();
  const qq=g.createLinearGradient(0,yy,0,yy+l);qq.addColorStop(0,o.cone[0]);qq.addColorStop(1,o.cone[1]);g.fillStyle=qq;g.fill();rpw3aO(g,2.4);
  g.strokeStyle='rgba(255,255,255,.18)';g.lineWidth=2;g.beginPath();g.moveTo(x-w*.6,yy+4);g.quadraticCurveTo(x-w*.3,yy+l*.5,x,yy+l-6);g.stroke();
  if(o.vine&&rpw3aR(k+9)<.5){g.strokeStyle=o.vine;g.lineWidth=1.6;g.beginPath();g.moveTo(x+w*.3,yy);g.bezierCurveTo(x+w*.5,yy+l*.4,x+w*.1,yy+l*.6,x+w*.35,yy+l*.9);g.stroke()}
  if(o.glint&&rpw3aR(k+11)<.35){g.fillStyle=o.glint;g.beginPath();g.moveTo(x-3,yy+l*.3);g.lineTo(x,yy+l*.18);g.lineTo(x+3,yy+l*.3);g.lineTo(x,yy+l*.55);g.closePath();g.fill()}}
 if(o.pre)o.pre();
 /* the mask stacked at offsets a..b (every 2 px), by doubling: a few draws instead of one per offset (10.1) */
 let SC=null;const span=(a,b,col)=>{const c=col?(SC||(SC=rpw3aCv(1600,H))):rpw3aCv(1600,H),x=c.getContext('2d');if(col){x.globalCompositeOperation='source-over';x.clearRect(0,0,1600,H)}x.drawImage(M.m,0,a);let w=0;while(w<b-a){const s=Math.min(w+2,b-a-w);x.drawImage(c,0,s);w+=s}
  if(col){x.globalCompositeOperation='source-in';x.fillStyle=col;x.fillRect(0,0,1600,H)}return c};
 const E=span(D%2,D),eg=E.getContext('2d');
 const Eo=rpw3aTint(E,RPO);for(const [ox,oy] of[[-3,0],[3,0],[0,3],[-2,2],[2,2],[0,-2]])g.drawImage(Eo,ox,oy);
 {const grp=[];for(let dy=D;dy>=0;dy-=2){let col=o.bands[0][1];for(const b of o.bands)if(dy>=b[0])col=b[1];const q=grp[grp.length-1];if(q&&q.col===col)q.a=dy;else grp.push({col,a:dy,b:dy})}
  for(const q of grp)g.drawImage(span(q.a,q.b,q.col),0,0)}
 {const T=rpw3aCv(1600,H),t=T.getContext('2d');t.lineCap='round';
  for(let k=0;k<edgeB.length;k+=2){const [x,y]=edgeB[k];const sh=rpw3aN(x,0,5);if(sh>.25){t.fillStyle='rgba(18,8,31,.16)';t.fillRect(x,y+6,M.s+1,D)}else if(sh<-.25){t.fillStyle='rgba(255,240,220,.12)';t.fillRect(x,y+6,M.s+1,D)}}
  t.strokeStyle='rgba(18,8,31,.4)';t.lineWidth=1.4;for(let k=0;k<edgeB.length;k+=6){const [x,y]=edgeB[k];const l=10+rpw3aR(k+1)*30;t.beginPath();t.moveTo(x,y+12);t.lineTo(x+(rpw3aR(k+2)-.5)*6,y+12+l*.5);t.lineTo(x+(rpw3aR(k+3)-.5)*8,y+12+l);t.stroke()}
  for(let k=0;k<edgeB.length;k+=4){const [x,y]=edgeB[k];t.fillStyle=rpw3aR(k)<.5?'rgba(255,240,220,.3)':'rgba(18,8,31,.3)';t.beginPath();t.ellipse(x,y+18+rpw3aR(k+4)*28,2.5+rpw3aR(k+5)*3,1.8,0,0,TAU);t.fill()}
  if(o.root){t.strokeStyle=o.root;t.lineWidth=1.3;for(let k=0;k<edgeB.length;k+=9){const [x,y]=edgeB[k];if(rpw3aR(k+6)<.5)continue;t.beginPath();t.moveTo(x,y+8);t.bezierCurveTo(x+4,y+18,x-3,y+26,x+2,y+30+rpw3aR(k)*16);t.stroke()}}
  if(o.vein){t.globalCompositeOperation='lighter';for(let k=0;k<edgeB.length;k+=13){const [x,y]=edgeB[k];if(rpw3aR(k+8)<.4)continue;let px=x,py=y+10;t.beginPath();t.moveTo(px,py);for(let j=0;j<4;j++){px+=(rpw3aR(k+j)-.5)*14;py+=6+rpw3aR(k*3+j)*8;t.lineTo(px,py)}
   t.strokeStyle=o.vein[0];t.lineWidth=5;t.stroke();t.strokeStyle=o.vein[1];t.lineWidth=1.6;t.stroke()}t.globalCompositeOperation='source-over'}
  t.globalCompositeOperation='destination-in';t.drawImage(E,0,0);t.globalCompositeOperation='destination-out';t.drawImage(M.m,0,0);g.drawImage(T,0,0)}
 o.top.getContext('2d').globalCompositeOperation='destination-in';o.top.getContext('2d').drawImage(M.m,0,0);o.top.getContext('2d').globalCompositeOperation='source-over';
 for(const [ox,oy] of[[-2.5,0],[2.5,0],[0,-2.5],[0,3]])g.drawImage(mk,ox,oy);g.drawImage(o.top,0,0);
 g.strokeStyle=o.lip;g.lineWidth=2;g.beginPath();for(let k=0;k<edgeT.length;k+=2){const [x,y]=edgeT[k];g.moveTo(x-2,y+3);g.lineTo(x+3,y+3)}g.stroke();
 if(o.tuft)for(let k=0;k<edgeB.length;k+=3){const [x,y]=edgeB[k];const n=2+((rpw3aR(k)*3)|0);for(let j=0;j<n;j++){const xx=x+(rpw3aR(k+j)-.5)*6,l=4+rpw3aR(k*3+j)*8;g.strokeStyle=o.tuft[j%2];g.lineWidth=2;g.beginPath();g.moveTo(xx,y-1);g.quadraticCurveTo(xx+1,y+l*.6,xx+(rpw3aR(k+j*7)-.5)*5,y+l);g.stroke()}}
 return{edgeB,edgeT}}
const RPW3A_MP={grass:['#4eae3e','#86dc62','#3e9a36','#9ae672'],sky0:'#8fd4ff',sky1:'#4a9ce8',edge:'#2e5a2a',curb:'#efe4c8',dirt:'#e2c690',dirt2:'#d4b67e',cob:['#f2deb2','#e6cc9e','#dabe8c'],
 cliff:['#a87a52','#8a6040','#76563e','#6a5446','#5a4a48'],tree:['#3aa048','#4ab854','#2e8a3e'],treeHi:'#c8ff8a',trunk:'#7a5232',rock:'#9a94a8',rockHi:'#e0dcee'};
/* the island field. Each stretch of road between two bridges is its own island: its land is a disc round its road samples, its pads and a
   few blobs; where two islands' fields meet, a band of sky runs along the line between them (wider at the bridges, so every rope bridge
   spans a real gap). The road off the bridges and every pad stone stay land whatever the shape. */
function rpw3aIsles(map,G,cast){const br=map.bridge||[],S=G.paths[0].S,NB=br.length,isl=new Int8Array(S.length);let k=0,inB=-1;
 for(let i=0;i<S.length;i++){const q=S[i],b=br.findIndex(b=>Math.hypot(q.x-b[0],q.y-b[1])<b[2]+2);if(b>=0){isl[i]=-1;if(inB!==b){inB=b;k++}}else{isl[i]=k;inB=-1}}
 const NI=k+1,U=[];for(let i=0;i<S.length;i+=2)if(isl[i]>=0)U.push({x:S[i].x,y:S[i].y,k:isl[i]});
 const grid=new Map();for(const q of U){const key=(q.x>>6)*512+(q.y>>6);let L=grid.get(key);if(!L)grid.set(key,L=[]);L.push(q)}
 /* squared distance to each island's road samples: one field per island on an 8 px grid (10.1, was a search per point), read bilinearly */
 const gs=8,gx=Math.ceil(1640/gs)+2,gy=Math.ceil(940/gs)+2,cap=160,DK=[...Array(NI)].map(()=>new Float32Array(gx*gy).fill(cap*cap)),rr=Math.ceil(cap/gs);
 for(const q of U){const D=DK[q.k],ci=Math.round(q.x/gs),cj=Math.round(q.y/gs);for(let j=Math.max(0,cj-rr);j<=Math.min(gy-1,cj+rr);j++){const dy=(j*gs-q.y)**2,row=j*gx;for(let i=Math.max(0,ci-rr);i<=Math.min(gx-1,ci+rr);i++){const d=(i*gs-q.x)**2+dy;if(d<D[row+i])D[row+i]=d}}}
 for(const D of DK)for(let k=0;k<D.length;k++)D[k]=Math.sqrt(D[k]);
 const dk=new Float32Array(NI),near=(x,y)=>{const u=Math.max(0,Math.min(gx-1.001,x/gs)),v=Math.max(0,Math.min(gy-1.001,y/gs)),i=u|0,j=v|0,fu=u-i,fv=v-j,k=j*gx+i;
  for(let n=0;n<NI;n++){const D=DK[n],d=(D[k]*(1-fu)+D[k+1]*fu)*(1-fv)+(D[k+gx]*(1-fu)+D[k+gx+1]*fu)*fv;dk[n]=d>=cap-1?1e9:d*d}};
 const own=(x,y)=>{let bk=0,bd=1e9;for(const q of U){const d=(q.x-x)**2+(q.y-y)**2;if(d<bd){bd=d;bk=q.k}}return bk};
 const ell=(x,y,b)=>{const dx=(x-b[0])/b[2],dy=(y-b[1])/b[3];return(1-Math.sqrt(dx*dx+dy*dy))*Math.min(b[2],b[3])};
 const pads=G.pads.map(p=>[p.x,p.y+8,90,54,own(p.x,p.y)]),padS=G.pads.map(p=>[p.x,p.y+8,64,34]);
 const blobs=[[40,250,96,110,0],[110,180,80,60,0],[150,470,70,70,0],[330,610,80,60,1],[470,650,80,50,1],[740,250,90,70,2],[770,390,80,60,2],[1010,300,70,70,2],[1060,630,80,50,3],[900,650,70,50,3],
  [1330,480,130,80,NI-1],[1420,528,130,46,NI-1],[1530,524,120,50,NI-1],[1560,430,90,110,NI-1]];
 const R0=90,v=new Float32Array(NI);
 const fn=(x,y)=>{near(x,y);const n=rpw3aN(x,y,1)*16+rpw3aN(x*2.3,y*2.3,4)*7;
  for(let i=0;i<NI;i++)v[i]=R0+n-Math.sqrt(dk[i]);for(const p of pads)v[p[4]]=Math.max(v[p[4]],ell(x,y,p)+n*.6);for(const b of blobs)v[b[4]]=Math.max(v[b[4]],ell(x,y,b)+n);
    let v1=-1e9,v2=-1e9;for(let i=0;i<NI;i++){if(v[i]>v1){v2=v1;v1=v[i]}else if(v[i]>v2)v2=v[i]}
  let gw=24+rpw3aN(x*1.7,y*1.7,9)*6;for(const b of br){const dx=x-b[0],dy=y-b[1];if(dx>180||dx<-180||dy>180||dy<-180)continue;const d=Math.sqrt(dx*dx+dy*dy);gw+=d<90?60:d<180?60*(180-d)/90:0}
  let f=Math.min(v1,(v1-v2-gw)*.5);
  /* must stay land: the road off the bridges and the pad stones */
  let dm=1e9;for(let i=0;i<NI;i++)dm=Math.min(dm,dk[i]);f=Math.max(f,52-Math.sqrt(dm));for(const p of padS){const e=ell(x,y,p);if(e>f)f=e}
  return f};
 return{fn,NI}}
/* bake Cloudspire Meadows */
function rpw3aBakeMeadow(map){const G=rpGeo(map),H=900,MP=RPW3A_MP,pal=Object.assign({},RP_PAL.meadow);
 const CA=rpw3aCastle('meadow'),cast={x:Math.round(G.gate.x-CA.gx),y:Math.round(G.gate.y-CA.gy),w:CA.w,h:CA.h};
 const I=rpw3aIsles(map,G,cast),M=rpw3aMask(I.fn,4),land=(x,y,m)=>M.at(x,y)>(m||0);
 /* ---- the sky with its sea of clouds ---- */
 const sky=rpw3aCv(1600,H),s=sky.getContext('2d');let q=s.createLinearGradient(0,0,0,H);q.addColorStop(0,MP.sky0);q.addColorStop(.55,'#6cb8f4');q.addColorStop(1,MP.sky1);s.fillStyle=q;s.fillRect(0,0,1600,H);
 s.globalCompositeOperation='lighter';s.globalAlpha=.35;s.drawImage(rpwGlow('255,250,220',120),900,-140,600,360);s.globalCompositeOperation='source-over';s.globalAlpha=1;
 for(let i=0;i<70;i++){const x=rpw3aR(i+11)*1700-50,y=rpw3aR(i+31)*H*1.05,r=50+rpw3aR(i+51)*90;s.globalAlpha=.16+rpw3aR(i+71)*.18;s.fillStyle=i%3?'#ffffff':'#d8ecff';s.beginPath();s.ellipse(x,y,r*1.8,r*.55,0,0,TAU);s.fill()}s.globalAlpha=1;
 /* little islands far below */for(let i=0;i<16;i++){const x=rpw3aR(i+90)*1600,y=110+rpw3aR(i+95)*740,r=9+rpw3aR(i+99)*20;s.globalAlpha=.6;s.fillStyle='#6a8ac0';s.beginPath();s.moveTo(x-r,y);s.quadraticCurveTo(x-r*.3,y+r*1.2,x,y+r*2);s.quadraticCurveTo(x+r*.4,y+r,x+r,y);s.closePath();s.fill();s.fillStyle='#7ab89a';s.beginPath();s.ellipse(x,y,r,r*.34,0,0,TAU);s.fill();
  s.fillStyle='#5a9a80';for(let k=0;k<2;k++){s.beginPath();s.arc(x-r*.4+k*r*.6,y-r*.3,r*.22,0,TAU);s.fill()}s.globalAlpha=1}
 for(let i=0;i<34;i++){const x=rpw3aR(i+130)*1700-50,y=200+rpw3aR(i+170)*760,sc=14+rpw3aR(i+210)*20;s.globalAlpha=.85;rpw3aCloud(s,x,y,sc,'#ffffff','#cfe0f6',null)}s.globalAlpha=1;
 /* ---- the islands (B.isl: everything but the sky) ---- */
 /* ---- the islands (B.isl: everything but the sky) ---- */
 const isl=rpw3aCv(1600,H),g=isl.getContext('2d');g.lineJoin='round';g.lineCap='round';
 /* the grass top */
 const top=rpw3aCv(1600,H),tg=top.getContext('2d');tg.lineCap='round';
 q=tg.createLinearGradient(0,0,0,H);q.addColorStop(0,'#72d054');q.addColorStop(1,'#52b444');tg.fillStyle=q;tg.fillRect(0,0,1600,H);
 for(let i=0;i<260;i++){const x=rpw3aR(i*3+5)*1600,y=rpw3aR(i*3+6)*H,r=26+rpw3aR(i*3+7)*80;tg.globalAlpha=.4;tg.fillStyle=MP.grass[i%4];tg.beginPath();tg.ellipse(x,y,r,r*.55,0,0,TAU);tg.fill()}tg.globalAlpha=1;
 /* mown stripes */tg.globalAlpha=.07;tg.fillStyle='#ffffff';for(let x=-900;x<1600;x+=56){tg.beginPath();tg.moveTo(x,0);tg.lineTo(x+28,0);tg.lineTo(x+28+900*.6,H);tg.lineTo(x+900*.6,H);tg.closePath();tg.fill()}tg.globalAlpha=1;
 for(let i=0;i<900;i++){const x=rpw3aR(i*2+300)*1600,y=rpw3aR(i*2+301)*H;tg.strokeStyle=i%3?'#3e9a34':'#9ae870';tg.lineWidth=1.6;tg.globalAlpha=.8;tg.beginPath();tg.moveTo(x,y);tg.lineTo(x-2,y-6-rpw3aR(i)*5);tg.moveTo(x+3,y);tg.lineTo(x+4,y-5-rpw3aR(i+3)*5);tg.stroke()}tg.globalAlpha=1;
 rpw3aTerrain(g,M,{D:50,top,cone:[MP.cliff[3],MP.cliff[4]],vine:'#4a7a34',root:'#5a3a24',lip:'rgba(220,255,180,.55)',tuft:['#3e9a34','#5cc24a'],
  bands:[[0,'#5a8a34'],[5,'#7a5a3a'],[10,MP.cliff[0]],[20,MP.cliff[1]],[30,MP.cliff[2]],[40,MP.cliff[3]]],
  pre:()=>{/* small floating islets in the open sky */
   const islets=[];for(let i=0;i<400&&islets.length<6;i++){const x=60+rpw3aR(i+3100)*1220,y=150+rpw3aR(i+3200)*600,r=18+rpw3aR(i+3300)*16;let ok=true;
    for(let a=0;a<8&&ok;a++){const px=x+Math.cos(a/8*TAU)*(r+40),py=y+Math.sin(a/8*TAU)*(r*.5+40);if(M.at(px,py)>-30||M.at(px,py-60)>-30)ok=false}if(!ok||M.at(x,y)>-40||islets.some(q=>Math.hypot(q[0]-x,q[1]-y)<220))continue;islets.push([x,y,r])}
   for(const [x,y,r] of islets){g.beginPath();g.moveTo(x-r,y);g.quadraticCurveTo(x-r*.6,y+r*1.1,x-r*.1,y+r*2.2);g.lineTo(x+r*.15,y+r*1.6);g.quadraticCurveTo(x+r*.7,y+r*.9,x+r,y);g.closePath();
    q=g.createLinearGradient(x-r,0,x+r,0);q.addColorStop(0,MP.cliff[0]);q.addColorStop(1,MP.cliff[3]);g.fillStyle=q;g.fill();rpw3aO(g,2.4);
    g.beginPath();g.ellipse(x,y,r,r*.36,0,0,TAU);g.fillStyle='#5cc24a';g.fill();rpw3aO(g,2.2);g.fillStyle='#86dc62';g.beginPath();g.ellipse(x-r*.2,y-r*.06,r*.7,r*.2,0,0,TAU);g.fill();
    if(r>24){g.save();g.translate(x+r*.2,y);rpOak(g,0,0,30,{tree:MP.tree,treeHi:MP.treeHi,trunk:MP.trunk},x|0);g.restore()}else{g.fillStyle=MP.tree[0];g.beginPath();g.arc(x-r*.2,y-4,6,0,TAU);g.arc(x+r*.2,y-5,7,0,TAU);g.fill();rpw3aO(g,1.8)}}}});
 /* ---- grass detail: clover, meadow patches ---- */
 const dR=rpw3aDR(G),P=G.pads,padNear=(x,y,r)=>P.some(p=>Math.hypot(p.x-x,(p.y-y)*1.3)<r),inCast=(x,y)=>x>cast.x-10&&y>cast.y+150,
  free=(x,y,r)=>land(x,y,8)&&dR(x,y)>44+r&&!padNear(x,y,66+r)&&!inCast(x,y)&&!G.ent.some(e=>Math.abs(x-e.x)<100&&Math.abs(y-e.y)<90);
 const FL=['#ffe46a','#ffffff','#ff9ad8','#c8a0ff','#ff6a5a','#7ad8ff'];
 for(let i=0;i<140;i++){const cx=rpw3aR(i+500)*1600,cy=rpw3aR(i+540)*H;if(!free(cx,cy,6))continue;const c1=FL[i%6],c2=FL[(i+2)%6],R=18+rpw3aR(i+580)*28;
  g.globalAlpha=.3;g.fillStyle='#9ae870';g.beginPath();g.ellipse(cx,cy,R*1.2,R*.6,0,0,TAU);g.fill();g.globalAlpha=1;
  for(let k=0;k<26;k++){const a=rpw3aR(i*31+k)*TAU,r=Math.sqrt(rpw3aR(i*17+k))*R,x=cx+Math.cos(a)*r,y=cy+Math.sin(a)*r*.55;if(!free(x,y,0))continue;const c=k%3?c1:c2,sz=1.6+rpw3aR(k+i)*1.2;
   g.strokeStyle='#3e8a30';g.lineWidth=1.2;g.beginPath();g.moveTo(x,y+4);g.lineTo(x,y);g.stroke();g.fillStyle=c;for(let p=0;p<5;p++){const pa=p/5*TAU;g.beginPath();g.arc(x+Math.cos(pa)*sz,y+Math.sin(pa)*sz*.8,sz*.7,0,TAU);g.fill()}g.fillStyle='#ffb02a';g.beginPath();g.arc(x,y,sz*.5,0,TAU);g.fill()}}
 for(let i=0;i<260;i++){const x=rpw3aR(i+700)*1600,y=rpw3aR(i+760)*H;if(!free(x,y,0))continue;g.fillStyle=FL[i%6];g.globalAlpha=.9;g.beginPath();g.arc(x,y,2,0,TAU);g.fill()}g.globalAlpha=1;
 for(let i=0;i<420;i++){const x=rpw3aR(i*7+1300)*1600,y=rpw3aR(i*7+1301)*H;if(!free(x,y,-6))continue;const n=3+(i%3);for(let j=0;j<n;j++){const a=(j/(n-1)-.5)*1.1,l=7+rpw3aR(i+j)*7;g.strokeStyle=j%2?'#2e8a2e':'#5cc24a';g.lineWidth=2.2;g.beginPath();g.moveTo(x+j*2-n,y);g.quadraticCurveTo(x+j*2-n+a*4,y-l*.6,x+j*2-n+a*9,y-l);g.stroke()}}
 for(let i=0;i<30;i++){const x=rpw3aR(i*3+1700)*1600,y=rpw3aR(i*3+1701)*H;if(!free(x,y,0))continue;for(let k=0;k<2;k++){const mx=x+k*9,my=y-k*3;g.fillStyle='#fff4e0';g.fillRect(mx-1.5,my-6,3,6);g.fillStyle=i%2?'#ff6a5a':'#c88aff';g.beginPath();g.ellipse(mx,my-7,5-k,3.4-k*.6,0,Math.PI,0);g.closePath();g.fill();g.strokeStyle=RPO;g.lineWidth=1.2;g.stroke();g.fillStyle='#fff';g.beginPath();g.arc(mx-1.5,my-8,1,0,TAU);g.fill()}}
 for(let i=0;i<90;i++){const x=rpw3aR(i*5+900)*1600,y=rpw3aR(i*5+901)*H;if(!free(x,y,4))continue;g.fillStyle='#4ab83a';g.strokeStyle='#1e4a1e';g.lineWidth=1.3;for(const [dx,dy] of[[-4,0],[4,0],[0,-4]]){g.beginPath();g.arc(x+dx,y+dy,4,0,TAU);g.fill();g.stroke()}}
 /* ---- the road ---- */
 const DX=104,own=[];for(const Pp of G.paths){const S=Pp.S,ob=i=>(map.bridge||[]).some(b=>Math.hypot(S[i].x-b[0],S[i].y-b[1])<b[2]);own.push({S,P:Pp,runs:rpw3aRuns(S.length,i=>Pp.own[i]&&!ob(i)&&S[i].x>DX-8),br:rpw3aRuns(S.length,i=>Pp.own[i]&&ob(i)),dock:rpw3aRuns(S.length,i=>Pp.own[i]&&S[i].x<=DX)})}
 /* the sky-dock: a planked quay along the first stretch of road, with posts and rails */
 for(const o of own){const S=o.S;for(const r of o.dock){rpw3aLine(g,S,r[0],Math.min(S.length-1,r[1]+2),96,'rgba(18,8,31,.3)');
  for(let i=r[0];i<=r[1]+2&&i<S.length;i+=3){const p=S[i],nx=-Math.sin(p.a),ny=Math.cos(p.a),tx=Math.cos(p.a),ty=Math.sin(p.a),w=44;g.fillStyle=['#b07a46','#9a6a3c','#c08a52'][i%3];g.strokeStyle=RPO;g.lineWidth=1.4;
   g.beginPath();g.moveTo(p.x+nx*w-tx*6,p.y+ny*w-ty*6);g.lineTo(p.x+nx*w+tx*6,p.y+ny*w+ty*6);g.lineTo(p.x-nx*w+tx*6,p.y-ny*w+ty*6);g.lineTo(p.x-nx*w-tx*6,p.y-ny*w-ty*6);g.closePath();g.fill();g.stroke()}
  for(const sd of[-1,1]){g.strokeStyle='#6a4426';g.lineWidth=3.4;g.beginPath();for(let i=r[0];i<=r[1];i++){const p=S[i],x=p.x-Math.sin(p.a)*42*sd,y=p.y+Math.cos(p.a)*42*sd;i===r[0]?g.moveTo(x,y):g.lineTo(x,y)}g.stroke();
   for(let i=r[0];i<=r[1];i+=7){const p=S[i],x=p.x-Math.sin(p.a)*46*sd,y=p.y+Math.cos(p.a)*46*sd;g.fillStyle='#7a5030';g.beginPath();g.rect(x-4,y-18,8,20);g.fill();rpw3aO(g,1.8);g.fillStyle='#d8c08a';g.fillRect(x-4,y-12,8,2.5)}}}}
 const ext=(r,n)=>[Math.max(0,r[0]-2),Math.min(n-1,r[1]+2)];
 for(const [w,col] of[[88,'rgba(0,0,0,.18)'],[78,MP.edge],[72,MP.curb],[60,MP.dirt]])for(const o of own)for(const r of o.runs){const e=ext(r,o.S.length);rpw3aLine(g,o.S,e[0],e[1],w,col)}
 for(const o of own){const S=o.S;for(const r of o.runs)for(let i=r[0];i<=r[1];i+=3){const p=S[i];for(let k=0;k<3;k++){const off=(rpw3aR(i*3+k)-.5)*44,x=p.x-Math.sin(p.a)*off+(rpw3aR(i+k*7)-.5)*4,y=p.y+Math.cos(p.a)*off;
   g.fillStyle=MP.cob[(i+k)%3];g.strokeStyle='rgba(90,60,30,.25)';g.lineWidth=1.2;g.beginPath();g.ellipse(x,y,4+rpw3aR(i*5+k)*3,3+rpw3aR(i*7+k)*2,p.a,0,TAU);g.fill();g.stroke()}}}
 for(const o of own){const S=o.S;for(const r of o.runs)for(let i=r[0];i<=r[1];i+=5)for(const sd of[-1,1]){const p=S[i],x=p.x-Math.sin(p.a)*35*sd,y=p.y+Math.cos(p.a)*35*sd;if(dR(x,y)<30)continue;
   g.fillStyle=MP.curb;g.strokeStyle=RPO;g.lineWidth=1.6;g.beginPath();g.ellipse(x,y,7,4.5,p.a,0,TAU);g.fill();g.stroke();g.fillStyle='rgba(255,255,255,.4)';g.beginPath();g.ellipse(x-1,y-1.5,4,1.6,p.a,0,TAU);g.fill()}}
 g.strokeStyle='rgba(120,80,40,.3)';g.lineWidth=4;for(const o of own){const S=o.S;for(const r of o.runs)for(let i=r[0]+20;i<r[1]-10;i+=34){const p=S[i];g.save();g.translate(p.x,p.y);g.rotate(p.a);g.beginPath();g.moveTo(-6,-9);g.lineTo(4,0);g.lineTo(-6,9);g.stroke();g.restore()}}
 /* ---- rope bridges: plank decks (the hand ropes sway in the live layer) ---- */
 const bridges=[];for(const o of own){const S=o.S;for(const r of o.br){const i0=Math.max(0,r[0]-3),i1=Math.min(S.length-1,r[1]+3);
  g.save();g.globalCompositeOperation='destination-over';g.translate(0,26);rpw3aLine(g,S,i0,i1,66,'rgba(30,60,120,.22)');g.restore();
  for(let i=i0;i<=i1;i+=3){const p=S[i],nx=-Math.sin(p.a),ny=Math.cos(p.a),tx=Math.cos(p.a),ty=Math.sin(p.a),sag=Math.sin((i-i0)/(i1-i0)*Math.PI)*5,w=34+(rpw3aR(i)-.5)*4;
   g.fillStyle=['#b07a46','#9a6a3c','#c08a52'][i%3];g.strokeStyle=RPO;g.lineWidth=1.6;g.beginPath();g.moveTo(p.x+nx*w-tx*5,p.y+ny*w-ty*5+sag);g.lineTo(p.x+nx*w+tx*5,p.y+ny*w+ty*5+sag);g.lineTo(p.x-nx*w+tx*5,p.y-ny*w+ty*5+sag);g.lineTo(p.x-nx*w-tx*5,p.y-ny*w-ty*5+sag);g.closePath();g.fill();g.stroke();
   g.strokeStyle='rgba(255,230,180,.35)';g.lineWidth=1.2;g.beginPath();g.moveTo(p.x+nx*(w-3)-tx*3,p.y+ny*(w-3)-ty*3+sag);g.lineTo(p.x-nx*(w-3)-tx*3,p.y-ny*(w-3)-ty*3+sag);g.stroke()}
  for(const sd of[-1,1]){g.strokeStyle='#6a4426';g.lineWidth=3;g.beginPath();for(let i=i0;i<=i1;i++){const p=S[i],sag=Math.sin((i-i0)/(i1-i0)*Math.PI)*5,x=p.x-Math.sin(p.a)*30*sd,y=p.y+Math.cos(p.a)*30*sd+sag;i===i0?g.moveTo(x,y):g.lineTo(x,y)}g.stroke()}
  const post=i=>{const p=S[i];for(const sd of[-1,1]){const x=p.x-Math.sin(p.a)*41*sd,y=p.y+Math.cos(p.a)*41*sd;g.fillStyle='#7a5030';g.beginPath();g.rect(x-4,y-24,8,26);g.fill();rpw3aO(g,2);g.fillStyle='#9a6a3c';g.beginPath();g.ellipse(x,y-24,4,2,0,0,TAU);g.fill();rpw3aO(g,1.4);
   g.strokeStyle='#d8c08a';g.lineWidth=2;g.beginPath();g.moveTo(x-4,y-14);g.lineTo(x+4,y-10);g.moveTo(x-4,y-8);g.lineTo(x+4,y-4);g.stroke()}};
  post(i0);post(i1);bridges.push({S,i0,i1})}}
 /* ---- props ---- */
 const O=rpw3aOcc(G,cast,{ok:(x,y,w,h)=>land(x-w*.8,y,3)&&land(x+w*.8,y,3)&&land(x,y+6,6)&&land(x,y-Math.min(h,30),0)});
 const mills=[],items=[];
 /* the sky-dock entrance: a quay, crates, lanterns; the airship moored at the top left (live) and the dock gate (front post in ambTop) */
 const e0=G.ent[0];{const x=Math.max(30,e0.x-14),y=e0.y;
  for(const [px,py] of[[112,y-56],[112,y+52]]){g.fillStyle='#6a4426';g.beginPath();g.rect(px-5,py-26,10,28);g.fill();rpw3aO(g,2);g.fillStyle='#d8c08a';g.fillRect(px-5,py-16,10,3);g.fillStyle='#ffd45a';g.beginPath();g.arc(px,py-30,4,0,TAU);g.fill();rpw3aO(g,1.4)}
  for(const [cx,cy,s] of[[34,y+76,13],[58,y+82,10],[40,y+94,10]]){g.fillStyle='#b88a52';g.beginPath();g.rect(cx-s,cy-s*1.6,s*2,s*1.6);g.fill();rpw3aO(g,1.8);g.strokeStyle='#6a4426';g.lineWidth=1.4;g.beginPath();g.moveTo(cx-s,cy-s*1.6);g.lineTo(cx+s,cy);g.moveTo(cx+s,cy-s*1.6);g.lineTo(cx-s,cy);g.stroke()}
  /* a gangplank from the moored airship */g.save();g.translate(86,y-74);g.rotate(1.1);g.fillStyle='#b07a46';g.beginPath();g.rect(-4,-6,46,12);g.fill();rpw3aO(g,1.8);g.strokeStyle='rgba(18,8,31,.4)';g.lineWidth=1;g.beginPath();for(let k=6;k<46;k+=7){g.moveTo(k,-6);g.lineTo(k,6)}g.stroke();g.restore()
  O.add(46,y+94,32,44)}
 /* windmills: big ones first (their blades turn in the live layer) */
 {const C=[];for(let y=230;y<=760;y+=16)for(let x=60;x<=1290;x+=16)if(O.ok(x,y,30,128,14))C.push([x,y]);
  while(mills.length<4&&C.length){let best=null,bs=-1;for(const c of C){const d=mills.length?Math.min(...mills.map(m=>Math.hypot(m.x-c[0],m.y-c[1]))):400,sc=Math.min(d,420)+(c[1]>200&&c[1]<720?40:0);if(sc>bs){bs=sc;best=c}}
   if(!best||bs<240)break;O.add(best[0],best[1],30,128);mills.push({x:best[0],y:best[1],r:44,s:.9+rpw3aR(best[0])*.2,v:.6+rpw3aR(best[1])*.5});const b=best;for(let i=C.length-1;i>=0;i--)if(Math.hypot(C[i][0]-b[0],C[i][1]-b[1])<200)C.splice(i,1)}}
 for(const m of mills)rpw3aMill(g,m.x,m.y);
 /* cottages, trees, hay, beehives, fences */
 const KIND=[['tree',.28,24,66,14],['blossom',.08,24,64,14],['bush',.16,14,18,2],['house',.07,30,58,14],['hay',.05,16,26,4],['hive',.04,9,20,2],['sheep',.06,13,20,2],['rock',.07,12,14,0],['sunfl',.08,12,34,2],['fence',.05,22,18,4],['well',.02,16,40,8],['lamp',.04,6,44,0]];
 for(let i=0;i<6000&&items.length<260;i++){const x=rpw3aR(i*4+21)*1640-20,y=rpw3aR(i*4+22)*(H+40)-20;let r=rpw3aR(i*4+23),K=KIND[0];for(const k of KIND){if(r<k[1]){K=k;break}r-=k[1]}
  const h=K[0]==='tree'?K[3]+rpw3aR(i)*24:K[3];if(!O.take(x,y,K[2],h,K[4]))continue;items.push({x,y,k:K[0],h,i})}
 items.sort((a,b)=>a.y-b.y);const tp={tree:MP.tree,treeHi:MP.treeHi,trunk:MP.trunk,rock:MP.rock,rockHi:MP.rockHi};
 for(const it of items){const{x,y,k,h,i}=it;if(k==='tree')rpOak(g,x,y,h,tp,i);else if(k==='blossom')rpw3aBlossom(g,x,y,h,i);else if(k==='house')rpw3aHouse(g,x,y,i);
  else if(k==='bush'){for(const [dx,dy,r] of[[-8,0,8],[7,-2,9],[0,-8,8]]){g.fillStyle=MP.tree[i%3];g.beginPath();g.arc(x+dx,y+dy,r,0,TAU);g.fill();rpw3aO(g,2)}g.fillStyle='rgba(255,255,255,.3)';g.beginPath();g.arc(x-3,y-11,4,0,TAU);g.fill();g.fillStyle=FL[i%6];for(let j=0;j<3;j++){g.beginPath();g.arc(x-6+j*6,y-8+(j%2)*5,1.8,0,TAU);g.fill()}}
  else if(k==='hay')rpw3aHay(g,x,y);else if(k==='hive')rpw3aHive(g,x,y);else if(k==='sheep')rpw3aSheep(g,x,y,i);else if(k==='sunfl')rpw3aSunfl(g,x,y,i);else if(k==='fence')rpw3aFence(g,x,y,i);else if(k==='well')rpw3aWell(g,x,y);else if(k==='lamp')rpw3aLamp(g,x,y);else rpRock(g,x,y,h,tp)}
 /* ---- the castle ---- */
 g.drawImage(CA.c,cast.x,cast.y,CA.w,CA.h);
 /* ---- compose ---- */
 const c=rpw3aCv(1600,H),cg=c.getContext('2d');cg.drawImage(sky,0,0);cg.drawImage(isl,0,0);
 M.m=null;/* the full-size mask is no longer needed; M.at (the 4 px grid) stays for tests */
 return{c,isl,pal,G,trees:items,cast,id:map.id,M,mills,bridges,occ:O.L,dock:{x:58,y:e0.y},
  clouds:[...Array(9)].map((_,i)=>({y:120+i*86+rpw3aR(i+3)*40,v:8+rpw3aR(i+7)*14,x0:rpw3aR(i+9)*1900,k:i%3})),
  birds:[...Array(7)].map((_,i)=>({x0:rpw3aR(i+40)*1600,y:140+rpw3aR(i+41)*600,v:30+rpw3aR(i+42)*30,a:rpw3aR(i+43)*TAU}))}}
function rpw3aMill(g,x,y){g.save();g.translate(x,y);rpBlob(g,6,2,34,10,'#000',.22);
 /* stone base, tapered white body, cap */
 g.beginPath();g.moveTo(-24,0);g.lineTo(-17,-78);g.lineTo(17,-78);g.lineTo(24,0);g.closePath();let q=g.createLinearGradient(-24,0,24,0);q.addColorStop(0,'#fffaf0');q.addColorStop(.35,'#f4ecdc');q.addColorStop(1,'#b8aa98');g.fillStyle=q;g.fill();
 g.save();g.clip();g.fillStyle='#a89a90';g.fillRect(-26,-18,52,18);g.strokeStyle='rgba(18,8,31,.3)';g.lineWidth=1;for(let yy=-16;yy<0;yy+=6){g.beginPath();g.moveTo(-26,yy);g.lineTo(26,yy);g.stroke()}
 g.strokeStyle='rgba(18,8,31,.12)';for(let yy=-70;yy<-18;yy+=10){g.beginPath();g.moveTo(-26,yy);g.lineTo(26,yy);g.stroke()}g.restore();
 g.beginPath();g.moveTo(-24,0);g.lineTo(-17,-78);g.lineTo(17,-78);g.lineTo(24,0);g.closePath();rpw3aO(g,2.4);
 g.fillStyle='#6a4426';g.beginPath();g.moveTo(-7,0);g.lineTo(-7,-14);g.arc(0,-14,7,Math.PI,0);g.lineTo(7,0);g.closePath();g.fill();rpw3aO(g,1.8);
 for(const yy of[-40,-60]){g.fillStyle='#ffe08a';g.beginPath();g.rect(-4,yy,8,10);g.fill();rpw3aO(g,1.5)}
 g.beginPath();g.moveTo(-22,-76);g.quadraticCurveTo(-20,-100,0,-104);g.quadraticCurveTo(20,-100,22,-76);g.closePath();q=g.createLinearGradient(-22,0,22,0);q.addColorStop(0,'#e8603a');q.addColorStop(.3,'#ff8a5a');q.addColorStop(1,'#9a2a1a');g.fillStyle=q;g.fill();rpw3aO(g,2.4);
 g.strokeStyle='rgba(18,8,31,.3)';g.lineWidth=1.2;for(const k of[-12,0,12]){g.beginPath();g.moveTo(k*.4,-102);g.lineTo(k,-77);g.stroke()}
 g.fillStyle='#5a3a24';g.beginPath();g.arc(0,-86,5,0,TAU);g.fill();rpw3aO(g,1.6);g.restore()}
function rpw3aBlades(){return rpw3aSpr('blades',116,116,58,58,g=>{for(let i=0;i<4;i++){g.save();g.rotate(i/4*TAU);g.fillStyle='#6a4426';g.fillRect(-2,-54,4,54);g.strokeStyle=RPO;g.lineWidth=1.4;g.strokeRect(-2,-54,4,54);
  g.beginPath();g.rect(2,-52,14,38);g.fillStyle='#fff8ea';g.fill();rpw3aO(g,1.8);g.strokeStyle='rgba(106,68,38,.75)';g.lineWidth=1;g.beginPath();for(let y=-46;y<-14;y+=7){g.moveTo(2,y);g.lineTo(16,y)}g.moveTo(9,-52);g.lineTo(9,-14);g.stroke();g.restore()}
 g.fillStyle='#8a5a32';g.beginPath();g.arc(0,0,6,0,TAU);g.fill();rpw3aO(g,1.8);g.fillStyle='#ffd45a';g.beginPath();g.arc(0,0,2.4,0,TAU);g.fill()})}
function rpw3aHouse(g,x,y,i){g.save();g.translate(x,y);rpBlob(g,6,2,32,9,'#000',.22);const roof=['#e8503a','#3a7ae0','#e89a2a','#a85ad8'][i%4],w=24;
 g.beginPath();g.rect(-w,-30,w*2,30);g.fillStyle='#fff4dc';g.fill();g.save();g.clip();g.fillStyle='rgba(18,8,31,.14)';g.fillRect(w*.3,-30,w,30);g.strokeStyle='#8a5a32';g.lineWidth=2.4;g.beginPath();g.moveTo(-w,-16);g.lineTo(w,-16);g.moveTo(-w*.45,-30);g.lineTo(-w*.45,0);g.moveTo(w*.45,-30);g.lineTo(w*.45,0);g.stroke();g.restore();g.beginPath();g.rect(-w,-30,w*2,30);rpw3aO(g,2.2);
 g.fillStyle='#6a4426';g.beginPath();g.rect(-5,-14,10,14);g.fill();rpw3aO(g,1.6);for(const sx of[-1,1]){g.fillStyle='#ffe08a';g.beginPath();g.rect(sx*15-4,-26,8,8);g.fill();rpw3aO(g,1.4);g.fillStyle='#ff6a8a';g.fillRect(sx*15-5,-17,10,3)}
 g.beginPath();g.moveTo(-w-6,-28);g.lineTo(0,-56);g.lineTo(w+6,-28);g.closePath();const q=g.createLinearGradient(-w,0,w,0);q.addColorStop(0,roof);q.addColorStop(1,'#12081f');g.fillStyle=roof;g.fill();g.save();g.clip();g.globalAlpha=.3;g.fillStyle=q;g.fillRect(0,-60,w+8,40);g.globalAlpha=1;
 g.strokeStyle='rgba(18,8,31,.3)';g.lineWidth=1;for(let yy=-50;yy<-28;yy+=6){g.beginPath();g.moveTo(-w-6,yy);g.lineTo(w+6,yy);g.stroke()}g.restore();g.beginPath();g.moveTo(-w-6,-28);g.lineTo(0,-56);g.lineTo(w+6,-28);g.closePath();rpw3aO(g,2.4);
 g.fillStyle='#b05a3a';g.beginPath();g.rect(10,-52,7,14);g.fill();rpw3aO(g,1.6);g.restore()}
function rpw3aBlossom(g,x,y,h,i){g.save();g.translate(x,y);rpBlob(g,h*.1,3,h*.4,h*.12,'#000',.25);g.fillStyle='#7a5232';g.beginPath();g.moveTo(-h*.06,0);g.lineTo(-h*.04,-h*.42);g.lineTo(h*.04,-h*.42);g.lineTo(h*.07,0);g.closePath();g.fill();rpw3aO(g,2.2);
 const cl=[[0,-h*.66,h*.3],[-h*.24,-h*.5,h*.22],[h*.24,-h*.52,h*.23],[0,-h*.44,h*.24]];g.beginPath();for(const [cx,cy,r] of cl){g.moveTo(cx+r,cy);g.arc(cx,cy,r,0,TAU)}g.fillStyle='#ffa8d0';g.fill();rpw3aO(g,2.6);
 g.fillStyle='rgba(180,60,120,.22)';for(const [cx,cy,r] of cl){g.beginPath();g.arc(cx+r*.25,cy+r*.2,r*.78,0,TAU);g.fill()}g.fillStyle='#ffe8f4';g.globalAlpha=.7;for(const [cx,cy,r] of cl){g.beginPath();g.arc(cx-r*.3,cy-r*.35,r*.42,0,TAU);g.fill()}g.globalAlpha=1;
 g.fillStyle='#ffffff';for(let k=0;k<6;k++){g.beginPath();g.arc(-h*.22+rpw3aR(i+k)*h*.44,-h*.7+rpw3aR(i*3+k)*h*.36,1.8,0,TAU);g.fill()}g.restore()}
function rpw3aHay(g,x,y){g.save();g.translate(x,y);rpBlob(g,4,2,18,6,'#000',.22);g.beginPath();g.moveTo(-15,0);g.quadraticCurveTo(-16,-24,0,-27);g.quadraticCurveTo(16,-24,15,0);g.closePath();g.fillStyle='#f0c84a';g.fill();g.save();g.clip();g.strokeStyle='#c89a2a';g.lineWidth=1.2;for(let k=-12;k<14;k+=4){g.beginPath();g.moveTo(k,0);g.quadraticCurveTo(k*.6,-14,k*.2,-26);g.stroke()}g.fillStyle='rgba(18,8,31,.15)';g.fillRect(4,-30,14,30);g.restore();g.beginPath();g.moveTo(-15,0);g.quadraticCurveTo(-16,-24,0,-27);g.quadraticCurveTo(16,-24,15,0);g.closePath();rpw3aO(g,2);g.restore()}
function rpw3aHive(g,x,y){g.save();g.translate(x,y);rpBlob(g,3,2,11,4,'#000',.22);g.fillStyle='#e8b04a';for(let k=0;k<4;k++){const w=10-k*1.8,yy=-k*5;g.beginPath();g.ellipse(0,yy-3,w,4,0,0,TAU);g.fill();rpw3aO(g,1.5)}g.fillStyle='#3a2414';g.beginPath();g.arc(0,-3,2.2,0,TAU);g.fill();g.restore()}
function rpw3aSunfl(g,x,y,i){for(let k=0;k<3;k++){const dx=(k-1)*8,h=22+((i+k)%3)*6,yy=y-(k%2)*3;g.strokeStyle='#3e8a30';g.lineWidth=2.4;g.beginPath();g.moveTo(x+dx,yy);g.lineTo(x+dx,yy-h);g.stroke();g.fillStyle='#4ab83a';g.beginPath();g.ellipse(x+dx+4,yy-h*.45,4,2,.5,0,TAU);g.fill();
 g.fillStyle=k===1?'#ff8a3a':'#ffd23a';for(let p=0;p<8;p++){const a=p/8*TAU;g.beginPath();g.ellipse(x+dx+Math.cos(a)*4.5,yy-h+Math.sin(a)*4.5,2.8,1.6,a,0,TAU);g.fill()}g.fillStyle='#6a3a1a';g.beginPath();g.arc(x+dx,yy-h,2.8,0,TAU);g.fill();g.strokeStyle=RPO;g.lineWidth=1;g.stroke()}}
function rpw3aFence(g,x,y,i){const a=(rpw3aR(i)-.5)*.5;g.save();g.translate(x,y);g.rotate(a);g.strokeStyle=RPO;g.lineWidth=5;g.beginPath();g.moveTo(-22,-10);g.lineTo(22,-10);g.moveTo(-22,-4);g.lineTo(22,-4);g.stroke();g.strokeStyle='#c89a62';g.lineWidth=3;g.stroke();
 for(const px of[-20,0,20]){g.fillStyle='#a87a46';g.beginPath();g.rect(px-2.5,-16,5,17);g.fill();rpw3aO(g,1.6)}g.restore()}
function rpw3aWell(g,x,y){g.save();g.translate(x,y);rpBlob(g,3,2,18,6,'#000',.22);g.fillStyle='#a8a2b8';g.beginPath();g.ellipse(0,-6,14,6,0,0,TAU);g.lineTo(14,-14);g.ellipse(0,-14,14,6,0,0,Math.PI,true);g.closePath();g.fill();rpw3aO(g,2);
 g.fillStyle='#2a4a8a';g.beginPath();g.ellipse(0,-14,10,4,0,0,TAU);g.fill();g.strokeStyle='#6a4426';g.lineWidth=3;g.beginPath();g.moveTo(-12,-14);g.lineTo(-12,-34);g.moveTo(12,-14);g.lineTo(12,-34);g.stroke();
 g.beginPath();g.moveTo(-17,-32);g.lineTo(0,-42);g.lineTo(17,-32);g.closePath();g.fillStyle='#e8503a';g.fill();rpw3aO(g,2);g.restore()}
function rpw3aLamp(g,x,y){g.save();g.translate(x,y);rpBlob(g,2,1,6,2.5,'#000',.25);g.strokeStyle=RPO;g.lineWidth=4.4;g.beginPath();g.moveTo(0,0);g.lineTo(0,-36);g.lineTo(7,-36);g.stroke();g.strokeStyle='#4a4a62';g.lineWidth=2.4;g.stroke();
 g.fillStyle='#ffe08a';g.beginPath();g.rect(4,-36,7,9);g.fill();rpw3aO(g,1.4);g.restore()}
function rpw3aSheep(g,x,y,i){g.save();g.translate(x,y);if(i%2)g.scale(-1,1);rpBlob(g,2,2,13,4,'#000',.22);g.fillStyle='#3a3040';for(const dx of[-6,5])g.fillRect(dx,-6,3,7);
 g.beginPath();for(const [dx,dy,r] of[[-6,-11,6],[0,-13,7],[6,-11,6],[-2,-8,6],[4,-8,6]]){g.moveTo(dx+r,dy);g.arc(dx,dy,r,0,TAU)}g.fillStyle='#ffffff';g.fill();rpw3aO(g,1.8);g.fillStyle='#3a3040';g.beginPath();g.ellipse(11,-13,4,5,.3,0,TAU);g.fill();rpw3aO(g,1.4);g.fillStyle='#fff';g.beginPath();g.arc(12,-14,1,0,TAU);g.fill();g.restore()}
/* above everything: high wind streaks while the gale blows (the flyers are swept along) */
function rpw3aTopMeadow(c,R){const k=R.gust?R.gust.k:0;if(k<=0)return;const t=R.t;c.lineCap='round';c.strokeStyle='#ffffff';
 for(let i=0;i<(R.lite?5:11);i++){const y=90+((i*173)%700),x=((t*(1300+(i%4)*200)+i*397)%2100)-250,L=160+(i%3)*70;c.globalAlpha=k*(.35+.15*(i%2));c.lineWidth=1.6+(i%2);
  c.beginPath();c.moveTo(x,y);c.quadraticCurveTo(x+L*.5,y-6+Math.sin(t*5+i)*5,x+L,y);c.stroke()}c.globalAlpha=1}
/* ---------- hooks ---------- */
RPW.bake.meadow=rpw3aBakeMeadow;/* the live layers are defined in 98g3 */RPW.amb.meadow=rpw3aAmbMeadow;RPW.twist.meadow=rpw3aTwMeadow;RPW.ambTop.meadow=rpw3aTopMeadow;RPW.castleHit.meadow=(c,x,y,k)=>rpw3aCastleHit('meadow',c,x,y,k);
/* (98a draws RPW.amb inside the rpAmbient chain, at rpCastleLive, so the tower layers stay on top) */
