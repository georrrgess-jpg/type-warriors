/* ===== RUNESTONE RIDDLE: the look =====
   Indigo night backdrop, a graphite runestone with a chunky #12081f outline, serif runes on carved tiles, an indigo glass side panel,
   Pirata One title with a gold gradient, Poppins UI. Every animation moves only transform or opacity; glows are pseudo-elements faded in. */
{const st=document.createElement('style');st.textContent=`
#ov.rrx.rrlock{overflow:hidden}#ov.rrx{display:block;padding:0;text-align:left;background:radial-gradient(120% 90% at 30% 0%,#241650 0%,#120b30 45%,#07041a 100%);overflow:auto}
.rr{--t:68px;--gap:calc(var(--t)*.17);position:relative;min-height:100%;display:flex;flex-direction:column;padding:26px 44px 30px;box-sizing:border-box;font-family:Poppins,system-ui,sans-serif;color:#efeaff;isolation:isolate;-webkit-text-size-adjust:100%;text-size-adjust:100%}
.rr *{box-sizing:border-box;max-height:1000000px}
.rrsky{position:absolute;inset:0;overflow:hidden;pointer-events:none;z-index:-1}
.rrsky i{position:absolute;border-radius:50%;opacity:.5}
.rrsky i:nth-child(1){width:520px;height:520px;left:-160px;top:-180px;background:radial-gradient(circle,#4a2aa855,#0000 70%)}
.rrsky i:nth-child(2){width:640px;height:640px;right:-220px;top:20%;background:radial-gradient(circle,#2a1a7a55,#0000 70%)}
.rrsky i:nth-child(3){width:700px;height:420px;left:20%;bottom:-200px;background:radial-gradient(ellipse,#1a3a5a44,#0000 70%)}
/* header */
.rrhd{width:100%;display:grid;grid-template-columns:auto minmax(0,1fr) auto auto;align-items:center;gap:14px 22px;max-width:1320px;margin:0 auto 16px}
.rrbk{font:600 15px Poppins,sans-serif;color:#e8e2ff;background:linear-gradient(180deg,#2a2468,#1c1850);border:1.5px solid #4a42a0;border-radius:14px;padding:10px 16px;cursor:pointer;box-shadow:0 4px 0 #12081f;transition:transform .15s}
.rrbk:hover{transform:translateY(-2px)}.rrbk:active{transform:translateY(2px)}
.rrbk span{font-size:20px;line-height:0;vertical-align:-1px;margin-right:2px}
.rrti{min-width:0}
.rrti h1{margin:0;line-height:1.12!important;padding-bottom:2px;-webkit-text-fill-color:transparent;font:400 52px/1 "Pirata One",Georgia,serif;letter-spacing:1px;background:linear-gradient(180deg,#fff2b8 0%,#ffcf4a 42%,#d07a10 78%,#8a3e08 100%);-webkit-background-clip:text;background-clip:text;color:transparent;-webkit-text-stroke:1px #3a1a06;filter:none;text-shadow:none}
.rrti p{margin:6px 0 0;font:500 13.5px/1.45 Poppins,system-ui,sans-serif;color:#c8bff0;max-width:640px}
.rrtabs{display:flex;gap:4px;padding:4px;border-radius:999px;background:#140f38;border:1.5px solid #3e3790}
.rrtabs button{font:700 12.5px Poppins,sans-serif;letter-spacing:.6px;text-transform:uppercase;color:#a9a0e0;background:none;border:0;border-radius:999px;padding:9px 16px;cursor:pointer;white-space:nowrap;position:relative}
.rrtabs button{box-shadow:none}.rrtabs button[aria-selected="true"]{color:#2a1604;background:linear-gradient(180deg,#ffe48a,#f5b928);box-shadow:0 2px 0 #8a5a08}
.rrtabs button:not([aria-selected="true"]):hover{color:#fff}
.rrgold{display:flex;align-items:center;gap:8px;padding:9px 16px 9px 12px;border-radius:999px;background:#140f38;border:1.5px solid #3e3790;font:700 17px Poppins,sans-serif;color:#ffe08a;white-space:nowrap}
.rrgold.bump{animation:rrBump .45s cubic-bezier(.3,1.6,.5,1)}
.rrcn{display:inline-block;width:20px;height:20px;border-radius:50%;background:radial-gradient(circle at 35% 30%,#fff6c0 0 18%,#ffd24a 40%,#c98a10 100%);border:2px solid #7a4a06;flex:none;vertical-align:middle}
/* layout */
.rrmain{display:grid;grid-template-columns:auto minmax(0,600px);gap:52px;justify-content:center;align-items:start;width:100%;max-width:1320px;margin:auto}
.rrboard{display:flex;flex-direction:column;align-items:center;gap:14px}
.rrside{display:flex;flex-direction:column;gap:14px;min-width:0}
/* the runestone */
.rrslab{position:relative;padding:calc(var(--t)*.5) calc(var(--t)*.55);border-radius:30px;background:linear-gradient(160deg,#3d3748 0%,#2a2433 40%,#1c1823 100%);border:4px solid #12081f;box-shadow:0 26px 50px #000a,inset 0 2px 0 #ffffff14,inset 0 -6px 0 #0006}
.rrslab::before{content:"";position:absolute;inset:12px;border-radius:20px;border:2px solid #ffffff12;pointer-events:none}
.rrcarve{position:absolute;inset:0;border-radius:26px;pointer-events:none;opacity:.5;background:radial-gradient(circle at 18% 12%,#ffffff10,#0000 35%),radial-gradient(circle at 85% 88%,#00000040,#0000 40%)}
.rrglyph svg{position:absolute;width:calc(var(--t)*.26);height:calc(var(--t)*.26);fill:none;stroke:#8a80b0;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;opacity:.28;pointer-events:none}
.rrglyph{--o:calc(var(--t)*.14)}.rrglyph .g0{left:var(--o);top:var(--o)}.rrglyph .g1{right:var(--o);top:var(--o)}.rrglyph .g2{left:var(--o);bottom:var(--o)}.rrglyph .g3{right:var(--o);bottom:var(--o)}
.rrslab::after{content:"";position:absolute;inset:-4px;border-radius:30px;pointer-events:none;opacity:0;transition:opacity .9s ease}
.rrslab.awake::after{opacity:1;box-shadow:0 0 0 3px #4ae89a,0 0 40px #4ae89a66,inset 0 0 50px #4ae89a22}
.rrslab.dim::after{opacity:1;box-shadow:0 0 0 3px #b0485a,0 0 32px #ff6a7a33}
.rrslab.awake .rrglyph svg{stroke:#7af0b0;opacity:.75;transition:opacity .9s,stroke .9s}
.rrslab.rrswap{animation:rrSwap .45s cubic-bezier(.3,1.4,.5,1)}
.rrslab.rrq{animation:rrQuake .6s ease}
.rrgrid{position:relative;display:grid;gap:var(--gap)}
.rrrw{display:grid;grid-template-columns:repeat(5,var(--t));gap:var(--gap)}
.rrrw.shk{animation:rrShake .5s ease}
.rrgrid.rrin .rrrw{animation:rrRowIn .5s cubic-bezier(.3,1.3,.5,1) both;animation-delay:calc(var(--r)*.06s)}
/* tiles */
.rrt{position:relative;width:var(--t);height:var(--t);border-radius:calc(var(--t)*.2);background:linear-gradient(180deg,#221d2b,#16121d);border:2px solid #3a3346;display:grid;place-items:center;transform-style:preserve-3d}
.rrt b{font:400 calc(var(--t)*.58)/1 Georgia,"Times New Roman",serif;color:#fff;text-transform:uppercase;position:relative;z-index:2}
.rrt::after{content:"";position:absolute;inset:-2px;border-radius:inherit;pointer-events:none;opacity:0;transition:opacity .25s}
.rrt.f{border-color:#6c6384;background:linear-gradient(180deg,#2a2434,#1b1722)}
.rrrw.now .rrt.cur::before{content:"";position:absolute;left:24%;right:24%;bottom:14%;height:3px;border-radius:2px;background:#ffd45a;animation:rrCaret 1.1s ease-in-out infinite}
.rrt.gh::before{content:attr(data-gh);position:absolute;inset:0;display:grid;place-items:center;font:400 calc(var(--t)*.58)/1 Georgia,serif;text-transform:uppercase;color:#7af0b0;opacity:.32}
.rrt.gh{border-color:#2f7a58;border-style:dashed}
.rrt.ghin::before{animation:rrGhost .7s ease both}
.rrt.pop{animation:rrPop .16s ease}
.rrt.flip{animation:rrFlip .52s ease-in-out both;animation-delay:calc(var(--i)*.27s)}
.rr-rm .rrt.flip{animation:none}
.rrt.c{background:linear-gradient(180deg,#2a8a5a 0%,#145236 55%,#0b2a1d 100%);border-color:#7af0b0}.rrt.c b{color:#9dfccc}
.rrt.c::after{box-shadow:0 0 18px #4ae89a88,inset 0 0 10px #7af0b055;opacity:1}
.rrt.p{background:linear-gradient(180deg,#d9a826 0%,#8a6410 55%,#3e2c06 100%);border-color:#ffd45a}.rrt.p b{color:#ffe9a0}
.rrt.p::after{box-shadow:0 0 16px #ffc94a77;opacity:1}
.rrt.a{background:linear-gradient(180deg,#26212f,#18151e);border-color:#2e2938}.rrt.a b{color:#7d7590}
.rrt.won{animation:rrWin .7s cubic-bezier(.3,1.6,.5,1) both;animation-delay:calc(var(--i)*.09s)}
.rr-rm .rrt.won,.rr-rm .rrt.pop,.rr-rm .rrgrid.rrin .rrrw,.rr-rm .rrslab{animation:none!important}
.rrleg{display:flex;flex-wrap:wrap;justify-content:center;gap:4px 16px;margin:0;width:0;min-width:100%;font:600 12.5px/1.5 Poppins,sans-serif;color:#9a92c8;text-align:center}
.rrleg span{display:inline-flex;align-items:center;gap:6px;white-space:nowrap}
.rrleg b{color:#ffe08a;white-space:nowrap}
.rrsw{display:inline-block;width:12px;height:12px;border-radius:4px;border:1.5px solid}.rrsw.c{background:#1f6b45;border-color:#7af0b0}.rrsw.p{background:#b08418;border-color:#ffd45a}
.rrlink{font:700 12.5px Poppins,sans-serif;color:#ffe08a;background:none;border:0;border-radius:0;box-shadow:none;min-width:0;border-bottom:1.5px dashed #ffe08a88;padding:0 0 1px;margin:0;cursor:pointer}.rrlink:hover{color:#fff}
/* side panel */
.rrpanel{padding:16px 18px 15px;border-radius:24px;background:linear-gradient(180deg,#1d1752f2,#130e3af2);border:1.5px solid #4a42a0;box-shadow:0 18px 40px #0008,inset 0 1px 0 #ffffff12}
.rrey{margin:0 0 10px;font:700 11.5px Poppins,sans-serif;letter-spacing:1.6px;text-transform:uppercase;color:#ffcf5a}
.rrey u{text-decoration:none;color:#7a70b8;margin:0 4px}
.rrcutn{color:#ff9a8a;letter-spacing:.6px}
.rrpanel .rrey:not(:first-child){margin-top:13px}
.rrstats{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}
.rrstats>div{padding:10px 8px 9px;border-radius:14px;background:#0b0820;border:1.5px solid #2c2668;text-align:center;min-width:0}
.rrstats b{display:block;font:800 24px/1.15 Poppins,sans-serif;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.rrstats b.m{color:#ffd45a}.rrstats b.g{color:#7af0b0}
.rrstats small{display:block;margin-top:5px;font:700 10px Poppins,sans-serif;letter-spacing:1.3px;text-transform:uppercase;color:#8a82c0}
.rrlad{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:6px}
.rrlp{display:flex;flex-direction:column;align-items:center;gap:1px;padding:7px 2px 6px;border-radius:11px;background:#0e0b28;border:1.5px solid #2c2668;min-width:0}
.rrlp small{font:700 10px Poppins,sans-serif;color:#8a82c0;letter-spacing:.5px}
.rrlp b{font:800 13.5px Poppins,sans-serif;color:#ffe08a;white-space:nowrap}
.rrlp.gone{opacity:.38}
.rrlp.nx{border-color:#ffd45a;background:linear-gradient(180deg,#3a2c0a,#1e1606);position:relative}
.rrlp.nx::after{content:"";position:absolute;inset:-4px;border-radius:14px;border:2px solid #ffd45a66;animation:rrBreath 1.6s ease-in-out infinite}
.rrlp.hit{border-color:#7af0b0;background:linear-gradient(180deg,#1f6b45,#0c2a1c)}.rrlp.hit b{color:#9dfccc}
.rrcal{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));gap:5px}
.rrcd{display:grid;place-items:center;height:30px;border-radius:9px;font:700 12.5px Poppins,sans-serif;color:#6a64a0;background:#15123a;border:1.5px solid #27225a;position:relative}
.rrcal.rrcin .rrcd{animation:rrCell .4s cubic-bezier(.3,1.5,.5,1) both;animation-delay:calc(var(--i)*12ms)}
.rrcd.w{background:linear-gradient(180deg,#22744a,#164a32);border-color:#2f8a5a;color:#e8fff2}
.rrcd.l{background:linear-gradient(180deg,#7a2430,#4e141c);border-color:#98303e;color:#ffe2e6}
.rrcd.ms{color:#5a5490;background:#100d2c}
.rrcd.pre{color:#4a4580;background:#0e0b26;border-style:dashed}
.rrcd.fu{color:#4e4888;background:#141036}
.rrcd.td{color:#2a1604;background:linear-gradient(180deg,#ffe48a,#f5b928);border-color:#fff0b0}
.rrcd.td.w{color:#e8fff2;background:linear-gradient(180deg,#22744a,#164a32);border-color:#ffd45a;outline:2px solid #ffd45a;outline-offset:1px}.rrcd.td.l{color:#ffe2e6;background:linear-gradient(180deg,#7a2430,#4e141c);border-color:#ffd45a;outline:2px solid #ffd45a;outline-offset:1px}
.rrcd.td:not(.w):not(.l)::after{content:"";position:absolute;inset:-4px;border-radius:12px;border:2px solid #ffd45a88;animation:rrBreath 1.6s ease-in-out infinite}
.rrbon{margin:11px 0 0;font:500 12.5px/1.5 Poppins,sans-serif;color:#c8bff0}.rrbon b{color:#fff}.rrbon em{font-style:normal;font-weight:700;color:#ffd45a}
.rrnote{margin:14px 0 12px;font:500 12.5px/1.5 Poppins,sans-serif;color:#c8bff0}
.rrdist{display:flex;flex-direction:column;gap:5px}
.rrdr{display:grid;grid-template-columns:16px 1fr;align-items:center;gap:8px;font:700 12px Poppins,sans-serif;color:#a9a0e0}
.rrdr i{display:block;height:20px;position:relative}
.rrdr i::before{content:"";position:absolute;inset:0;border-radius:6px;background:linear-gradient(90deg,#3a3290,#5a4ac8);transform-origin:left;transform:scaleX(max(.06,var(--w)));animation:rrBar .7s cubic-bezier(.3,1.1,.5,1) both}
.rrdr.me i::before{background:linear-gradient(90deg,#1f8a55,#4ae89a)}
.rrdr em{position:absolute;left:8px;top:50%;transform:translateY(-50%);font:800 11.5px Poppins,sans-serif;font-style:normal;color:#fff;z-index:1}
/* buttons */
.rrbtn{font:700 14.5px Poppins,sans-serif;color:#2a1604;background:linear-gradient(180deg,#ffe48a,#f5b928);border:2px solid #12081f;border-radius:14px;padding:11px 18px;cursor:pointer;box-shadow:0 4px 0 #8a5a08;transition:transform .15s;white-space:nowrap}
.rrbtn:hover{transform:translateY(-2px)}.rrbtn:active{transform:translateY(2px)}
.rrbtn i{font-style:normal;margin-left:4px}
.rrbtn.ghost{color:#efeaff;background:linear-gradient(180deg,#2a2468,#1c1850);border-color:#4a42a0;box-shadow:0 4px 0 #12081f}
.rrnew{width:100%}
/* rune powers */
.rrpow{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px 10px;width:0;min-width:100%}
.rrpb{display:grid;grid-template-columns:auto minmax(0,1fr);align-items:center;gap:10px;padding:10px 12px;border-radius:16px;cursor:pointer;text-align:left;color:#efeaff;background:linear-gradient(180deg,#241e5e,#17134a);border:1.5px solid #4a42a0;box-shadow:0 4px 0 #12081f;transition:transform .15s;position:relative;overflow:hidden}
.rrpb:hover:not(:disabled){transform:translateY(-2px)}.rrpb:active:not(:disabled){transform:translateY(2px)}
.rrpb:disabled{cursor:default;opacity:.55}
.rrpb.used{opacity:.6;border-style:dashed}
.rrpi{width:36px;height:36px;border-radius:11px;display:grid;place-items:center;border:2px solid #12081f}
.rrpi svg{width:22px;height:22px}
.rrp-r .rrpi{background:linear-gradient(180deg,#4ae89a,#1f8a55);color:#06201a}
.rrp-s .rrpi{background:linear-gradient(180deg,#b08aff,#6a3ad8);color:#ffe9a0}
.rrpt{min-width:0}.rrpt b{display:flex;align-items:center;justify-content:space-between;gap:8px;font:700 14px Poppins,sans-serif}
.rrpt small{display:block;margin-top:1px;font:500 11.5px/1.3 Poppins,sans-serif;color:#a9a0e0}
.rrpc{display:flex;align-items:center;gap:5px;font:800 13px Poppins,sans-serif;color:#ffe08a;white-space:nowrap}
.rrpc .rrcn{width:16px;height:16px;border-width:1.5px}
.rrpb.fire::after{content:"";position:absolute;inset:0;background:radial-gradient(circle at 20% 50%,#ffffffaa,#fff0 60%);animation:rrFire .5s ease both;pointer-events:none}
.rrpn{grid-column:1/-1;margin:-2px 0 0;font:500 11.5px Poppins,sans-serif;color:#8a82c0;text-align:center}
/* keyboard */
.rrkb{display:flex;flex-direction:column;align-items:center;gap:8px}.rr{--k:50px}
.rrkb.off{opacity:.55;pointer-events:none}
.rrkr{display:flex;gap:6px;justify-content:center}
.rrk{width:var(--k);height:50px;border-radius:11px;font:600 17px Poppins,sans-serif;color:#fff;background:linear-gradient(180deg,#25205e,#1a1650);border:1.5px solid #3e3790;box-shadow:0 3px 0 #0c0828;cursor:pointer;padding:0;display:grid;place-items:center;transition:transform .1s}
.rrk:hover{transform:translateY(-1px)}
.rrk.tap{animation:rrTap .18s ease}
.rrk.wide{width:calc(var(--k)*1.55);font-size:12.5px;font-weight:700;letter-spacing:.4px;text-transform:uppercase}
.rrk.wide svg{width:24px;height:24px}
.rrk.c{background:linear-gradient(180deg,#22744a,#164a32);border-color:#2f8a5a}
.rrk.p{background:linear-gradient(180deg,#d4a224,#a07812);border-color:#ffd45a;color:#2a1604}
.rrk.a{background:#100d28;border-color:#2a2458;color:#8a84bc;box-shadow:0 3px 0 #08061a;opacity:.7}
.rrk.chg{animation:rrKeyIn .4s cubic-bezier(.3,1.6,.5,1)}
.rrk.shat{animation:rrShat .6s ease}
/* toast, result, fx */
.rrtoast{position:absolute;left:50%;top:-22px;z-index:30;white-space:normal;width:max-content;padding:11px 20px;border-radius:14px;background:#fff8e0;color:#2a1604;font:700 14px Poppins,sans-serif;border:2px solid #12081f;box-shadow:0 10px 24px #000a;opacity:0;transform:translate(-50%,-10px);pointer-events:none;transition:opacity .2s,transform .25s cubic-bezier(.3,1.5,.5,1);max-width:520px;text-align:center}
.rrtoast.on{opacity:1;transform:translate(-50%,0)}
.rrres{position:absolute;left:0;right:0;top:0;height:100%;z-index:40;display:grid;place-items:center;padding:20px;background:#05031299;overflow:auto}
.rrres[hidden]{display:none}
.rrres.on{animation:rrFade .25s ease both}
.rrrc{position:relative;width:min(470px,100%);padding:26px 26px 22px;border-radius:26px;background:linear-gradient(180deg,#221a5e,#130e3a);border:2px solid #5a50c0;box-shadow:0 30px 60px #000c,inset 0 1px 0 #ffffff1a;text-align:center;animation:rrCard .45s cubic-bezier(.3,1.5,.5,1) both}
.rrrc.win{border-color:#4ae89a}
.rrrc .rrey{margin-bottom:6px}
.rrrc h2{margin:0;font:400 42px/1.05 "Pirata One",Georgia,serif;letter-spacing:.5px;text-shadow:none;-webkit-text-fill-color:transparent;background:linear-gradient(180deg,#fff2b8,#ffcf4a 50%,#d07a10);-webkit-background-clip:text;background-clip:text;color:transparent}
.rrrc.lose h2{background:linear-gradient(180deg,#f2eaff,#b8a8f0);-webkit-background-clip:text;background-clip:text}
.rrsub{margin:6px 0 20px;font:500 14px Poppins,sans-serif;color:#c8bff0}
.rrword{display:flex;justify-content:center;gap:8px;margin:0 0 16px;--t:52px}
.rrword .rrt{animation:rrWin .7s cubic-bezier(.3,1.6,.5,1) both;animation-delay:calc(.25s + var(--i)*.08s)}
.rrpay{margin:0 0 14px;padding:10px 14px;border-radius:16px;background:#0b0820;border:1.5px solid #2c2668;text-align:left}
.rrpay p{display:flex;justify-content:space-between;align-items:center;gap:12px;margin:4px 0;font:600 13.5px Poppins,sans-serif;color:#c8bff0}
.rrpay p b{color:#ffe08a;white-space:nowrap}
.rrpay p.neg b{color:#ff9a8a}.rrpay p.bon b{color:#7af0b0}
.rrpay p.tot{margin-top:8px;padding-top:8px;border-top:1.5px dashed #3a3480;font-size:16px;color:#fff}
.rrpay p.tot b{font-size:22px;margin-left:auto}
.rrpay p.ttl{justify-content:center;color:#ffd45a;font-weight:700}.rrpay p.ttl em{font-style:normal;color:#fff}
.rrdist.big{margin:0 0 12px}
.rrstk{margin:0 0 16px;font:600 13px Poppins,sans-serif;color:#a9a0e0}.rrstk b{color:#fff;white-space:nowrap}.rrstk u{text-decoration:none;color:#5a5490;margin:0 3px}
.rrbts{display:flex;gap:10px;justify-content:center;flex-wrap:wrap}
.rrxb{position:absolute;top:12px;right:12px;width:36px;height:36px;min-width:0;padding:0;display:grid;place-items:center;border-radius:12px;font:600 22px/1 Poppins,sans-serif;color:#c8bff0;background:#ffffff0d;border:1.5px solid #3e3790;box-shadow:none;cursor:pointer}
.rrxb:hover{color:#fff}
.rrfx{position:absolute;left:0;top:0;width:100%;height:100%;max-height:2400px;pointer-events:none;z-index:35}
.rrfly{position:absolute;z-index:45;width:22px;height:22px;border-radius:50%;pointer-events:none;background:radial-gradient(circle at 35% 30%,#fff6c0 0 18%,#ffd24a 40%,#c98a10 100%);border:2px solid #7a4a06}
/* keyframes: transform and opacity only */
@keyframes rrPop{0%{transform:scale(.86)}55%{transform:scale(1.12)}100%{transform:scale(1)}}
@keyframes rrFlip{0%{transform:perspective(500px) rotateX(0)}48%{transform:perspective(500px) rotateX(90deg)}52%{transform:perspective(500px) rotateX(90deg)}100%{transform:perspective(500px) rotateX(0)}}
@keyframes rrShake{0%,100%{transform:translateX(0)}15%{transform:translateX(-10px)}30%{transform:translateX(9px)}45%{transform:translateX(-7px)}60%{transform:translateX(5px)}75%{transform:translateX(-3px)}}
@keyframes rrWin{0%{transform:translateY(0) scale(1)}35%{transform:translateY(-26%) scale(1.08)}65%{transform:translateY(4%) scale(.97)}100%{transform:translateY(0) scale(1)}}
@keyframes rrQuake{0%,100%{transform:translate(0,0)}20%{transform:translate(-6px,2px) rotate(-.4deg)}40%{transform:translate(6px,-2px) rotate(.4deg)}60%{transform:translate(-4px,1px)}80%{transform:translate(3px,0)}}
@keyframes rrRowIn{0%{opacity:0;transform:translateY(14px) scale(.96)}100%{opacity:1;transform:none}}
@keyframes rrSwap{0%{transform:scale(.97);opacity:.6}100%{transform:none;opacity:1}}
@keyframes rrCaret{0%,100%{opacity:.25}50%{opacity:1}}
@keyframes rrGhost{0%{opacity:0;transform:scale(1.6)}60%{opacity:.6;transform:scale(.95)}100%{opacity:.32;transform:none}}
@keyframes rrBreath{0%,100%{opacity:.25;transform:scale(1)}50%{opacity:1;transform:scale(1.04)}}
@keyframes rrCell{0%{opacity:0;transform:scale(.6)}100%{opacity:1;transform:none}}
@keyframes rrBar{0%{transform:scaleX(0)}}
@keyframes rrTap{0%{transform:scale(1)}50%{transform:scale(.88)}100%{transform:scale(1)}}
@keyframes rrKeyIn{0%{transform:scale(.7)}60%{transform:scale(1.14)}100%{transform:scale(1)}}
@keyframes rrShat{0%{transform:scale(1) rotate(0)}25%{transform:scale(1.2) rotate(-8deg)}50%{transform:scale(.9) rotate(6deg)}100%{transform:scale(1) rotate(0)}}
@keyframes rrFire{0%{opacity:0;transform:scale(.6)}40%{opacity:1}100%{opacity:0;transform:scale(1.6)}}
@keyframes rrFade{0%{opacity:0}100%{opacity:1}}
@keyframes rrCard{0%{opacity:0;transform:translateY(24px) scale(.9)}100%{opacity:1;transform:none}}
@keyframes rrBump{0%{transform:scale(1)}40%{transform:scale(1.15)}100%{transform:scale(1)}}
/* touch mode sets body.tm p{font-size:20px}; keep the riddle's own sizes */
#rr p.rrleg,#rr p.rrbon,#rr p.rrnote{font-size:12.5px}#rr p.rrey,#rr p.rrpn{font-size:11.5px}#rr .rrti p{font-size:13.5px}#rr p.rrsub{font-size:14px}#rr p.rrstk{font-size:13px}#rr .rrpay p{font-size:13.5px}#rr .rrpay p.tot{font-size:16px}
/* phones (overlay under 700 wide, shown at about 0.6 scale): larger text and keys */
#rr.rr-tiny p.rrleg,#rr.rr-tiny p.rrbon,#rr.rr-tiny p.rrnote{font-size:17px}#rr.rr-tiny p.rrey,#rr.rr-tiny p.rrpn{font-size:15.5px}#rr.rr-tiny .rrsw{width:16px;height:16px}
#rr.rr-tiny .rrstats b{font-size:30px;line-height:1.3}#rr.rr-tiny .rrstats small{font-size:13px}#rr.rr-tiny .rrlp small{font-size:13px}#rr.rr-tiny .rrlp b{font-size:17px}#rr.rr-tiny .rrcd{height:40px;font-size:16px}
#rr.rr-tiny .rrpt b{font-size:19px}#rr.rr-tiny .rrpt small{font-size:15px}#rr.rr-tiny .rrpc{font-size:17px}#rr.rr-tiny .rrpi{width:46px;height:46px}#rr.rr-tiny .rrpi svg{width:28px;height:28px}
#rr.rr-tiny .rrk{height:66px;font-size:24px}#rr.rr-tiny .rrk.wide{font-size:15px}#rr.rr-tiny .rrtabs button{font-size:16px;padding:12px 20px}#rr.rr-tiny .rrbk,#rr.rr-tiny .rrgold{font-size:19px}
#rr.rr-tiny .rrrc{width:100%;padding:30px 26px 26px}#rr.rr-tiny .rrrc h2{font-size:52px}#rr.rr-tiny p.rrsub{font-size:18px}#rr.rr-tiny .rrword{--t:64px}#rr.rr-tiny .rrpay p{font-size:17px}#rr.rr-tiny .rrpay p.tot{font-size:20px}#rr.rr-tiny .rrpay p.tot b{font-size:28px}
#rr.rr-tiny .rrdr{font-size:15px;grid-template-columns:20px 1fr}#rr.rr-tiny .rrdr i{height:26px}#rr.rr-tiny .rrdr em{font-size:14px}#rr.rr-tiny p.rrstk{font-size:16px}#rr.rr-tiny .rrbtn{font-size:18px;padding:14px 20px}#rr.rr-tiny .rrtoast{font-size:18px}#rr.rr-tiny .rrlink{font-size:16px}
@media (prefers-reduced-motion:reduce){.rr *{animation-duration:.01ms!important;animation-iteration-count:1!important}}
/* shorter screens */
.rr.rr-short{padding-top:18px}.rr.rr-short .rrhd{margin-bottom:10px}.rr.rr-short .rrti h1{font-size:40px}.rr.rr-short .rrti p{font-size:12.5px}.rr.rr-short .rrcd{height:26px}.rr.rr-short .rrk{height:44px}.rr.rr-short .rrpanel{padding:13px 15px 12px}.rr.rr-short .rrpanel .rrey{margin-bottom:8px}.rr.rr-short .rrpanel .rrey:not(:first-child){margin-top:10px}.rr.rr-short .rrstats>div{padding:8px 6px 7px}.rr.rr-short .rrstats b{font-size:20px}.rr.rr-short .rrside,.rr.rr-short .rrboard{gap:10px}.rr.rr-short .rrlp{padding:5px 2px 4px}.rr.rr-short .rrpb{padding:8px 10px}.rr.rr-short .rrpi{width:32px;height:32px}
/* narrow screens: stack */
.rr.rr-narrow .rrhd{grid-template-columns:auto minmax(0,1fr) auto}.rr.rr-narrow .rrtabs{grid-column:1/-1;grid-row:2;justify-self:center}.rr.rr-narrow .rrmain{grid-template-columns:minmax(0,1fr)}.rr.rr-narrow .rrside{max-width:600px;width:100%;justify-self:center}
.rr.rr-narrow{padding:20px 16px 24px}.rr.rr-narrow .rrboard,.rr.rr-narrow .rrside{display:contents}.rr.rr-narrow .rrmain{justify-items:center}.rr.rr-narrow .rrslab{order:1}.rr.rr-narrow .rrkb{order:2}.rr.rr-narrow .rrpow{order:3;width:100%;min-width:0;max-width:600px}.rr.rr-narrow .rrleg{order:4;width:100%;min-width:0;max-width:600px}.rr.rr-narrow .rrpanel{order:5;width:100%;max-width:600px}.rr.rr-narrow .rrmain{gap:22px}.rr.rr-tiny .rrti h1{font-size:34px}.rr.rr-tiny .rrhd{grid-template-columns:auto minmax(0,1fr)}.rr.rr-tiny .rrgold{grid-column:2;justify-self:end;grid-row:1}.rr.rr-tiny .rrti{grid-column:1/-1;grid-row:3}.rr.rr-tiny .rrti p{display:none}.rr.rr-tiny .rrtabs{grid-row:2}.rr.rr-tiny .rrpow{grid-template-columns:1fr}
`;document.head.appendChild(st)}
