/* ---------- polish: interface sounds and casino celebration ---------- */
function bigWin(profit,mega){const w=$('wrap');if(!w)return;const d=document.createElement('div');d.className='cwin';
 let h=`<div class="bn${mega?' mega':''}">${mega?'MEGA WIN':'BIG WIN'}<small>+${cmn(profit)}</small></div>`;
 const n=mega?70:38;for(let i=0;i<n;i++)h+=`<i class="cn" style="left:${Math.random()*100}%;animation-duration:${1.6+Math.random()*1.6}s;animation-delay:${Math.random()*(mega?1.6:1)}s;width:${22+Math.random()*22|0}px;height:${22+Math.random()*22|0}px"></i>`;
 d.innerHTML=h;w.appendChild(d);setTimeout(()=>d.remove(),mega?5200:4200);
 if(typeof ac!=='undefined'&&ac&&sg){const o=ac.createGain();o.gain.value=1;o.connect(sg);const T=ac.currentTime+.02;
  cKick(o,T,.4,100,35,.7);const pent=[0,2,4,7,9];for(let i=0;i<(mega?24:12);i++)cBell(o,T+.05+i*(mega?.06:.07),nf(69+pent[i%5]+12*((i/5)|0)),.08,1.2);
  if(mega){cPad(o,T,[nf(50),nf(57),nf(62),nf(66)],2.6,.035,2400);for(const n of[74,78,81,86])cBrass(o,T+.5,nf(n),1.4,.05);cNoise(o,T+.4,1.8,.1,{type:'highpass',f1:5000,f2:5100})}
  else{cBrass(o,T+.3,nf(81),.8,.05);cBrass(o,T+.3,nf(76),.8,.03)}}}
{const okBtn=e=>{const b=e.target&&e.target.closest?e.target.closest('button'):null;return b&&!b.disabled&&!b.closest('.cas')&&b.id!=='sk'&&b.id!=='cz'?b:null};
 document.addEventListener('pointerdown',e=>{const b=okBtn(e);if(!b)return;ensureAudio();if(b.classList.contains('sm')||b.classList.contains('tab')||b.classList.contains('sw')||b.classList.contains('path'))beep(640,.035,'triangle',.45);else{beep(520,.05,'triangle',.7);setTimeout(()=>beep(780,.07,'triangle',.6),45)}},true);
 document.addEventListener('mouseover',e=>{const b=okBtn(e);if(!b||b===e.relatedTarget||(e.relatedTarget&&b.contains(e.relatedTarget)))return;beep(1180,.018,'sine',.16)},true)}
