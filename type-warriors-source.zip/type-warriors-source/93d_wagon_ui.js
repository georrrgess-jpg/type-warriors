/* ===== LANTERN CARAVAN: the hub, route cards, Convoy Workshop, Route Log, the intro strip, the result card and the hooks =====
   The hub follows the Moonlit Fishing landing page: a 1600x900 root (.wrx) over #ov.fshx, a live backdrop canvas on the right
   (the wagon idling at a lantern post), a left column with the title, the route cards and the gold Hitch up button, and small
   tiles for the Workshop, the Route Log and How to play. Modals use the fishing .fsmod pattern. */
let wrSel='mill',WRM={rt:null,look:null,t0:0};
/* ---------- a menu-only state the painters can draw from ---------- */
function wrMenuState(rt,look){const w=WRP();return {rt,bake:wrBake(rt),x:0,v:0,t:0,st:'menu',haz:null,kick:0,swing:0,swv:0,wheel:0,flareOn:0,dash:null,heroPose:null,poseT:0,lunge:0,petHop:-9,petFl:-9,
 drv:{mode:'idle',t0:-9,dur:0},look:look||{lan:w.lan,ban:w.ban,paint:w.paint},fx:[],embers:[],ox:0,rm:wrRM()}}
function wrHubDraw(g,M,t){const R=M;R.t=t;R.x=t*5;R.swing=Math.sin(t*1.7)*.06;g.setTransform(1,0,0,1,0,0);g.fillStyle='#000';g.fillRect(0,0,W,H);
 try{wrSceneDraw(g,R)}catch(e){}R.ox=430;try{wrPetDraw(g,R);wrWagonDraw(g,R);wrHeroDraw(g,R)}catch(e){}R.ox=0;ptFxStep(g,R.fx,1/30);try{wrForeDraw(g,R)}catch(e){}}
/* ---------- the hub ---------- */
function wagonMenu(back){S.mode='title';S.view='wagon';const w=WRP();if(!w.seen85){w.seen85=1;save()}if(!wrRouteOpen(WR_RT(wrSel)))wrSel='mill';
 const rt=WR_RT(wrSel),nw=['lan','ban','paint'].some(f=>WR_COSK[f].some(k=>w.seen[f+':'+k]===0));
 show(`<div class="wrx wrhub" id="wrhub"><canvas id="wrhb" width="1600" height="900" aria-hidden="true"></canvas><i class="fshvig"></i>
 <div class="fstr"><span class="fsgold fsg">${fsCoin}<b id="wrgold">${P.gold.toLocaleString()}</b></span><button class="wrmu fsg" id="wrmu" aria-pressed="${ST.mute?'false':'true'}">${wrMuIc()}<span>Music: ${ST.mute?'off':'on'}</span></button><button class="fsback fsg" id="wrback"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 5l-7 7 7 7" stroke="currentColor" stroke-width="2.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>Back <kbd>Esc</kbd></button></div>
 <section class="fshl wrhl">
  <p class="fshk"><span class="fshkm"><canvas id="wrhdrv" width="44" height="44"></canvas></span>THE CARAVAN GUILD</p>
  <h1 class="fsht">Lantern <em>Caravan</em></h1>
  <p class="fshs">Escort the lantern wagon to the gate. Type the word on a monster to cut it down, and the word on the wrench bubble when the wheel jams.</p>
  <div class="wrroutes" id="wrroutes" role="listbox" aria-label="Routes">${WR_ROUTES.map(r=>wrRouteCard(r,w)).join('')}</div>
  <button class="fshgo wrgo" id="wrgo"><span class="fshgoi" aria-hidden="true">${wrGoIc()}</span><span id="wrgot">Hitch up<small>${esc(rt.n)}</small></span><i>›</i><kbd>Space</kbd></button>
  <div class="fshtl wrtl">
   <button class="fsht2 fsg" id="wrws" style="--c:#ffd45a"><span class="fshic"><canvas id="wrwsc" width="120" height="96"></canvas></span><b>Convoy Workshop</b><small>${wrOwnedN(w)} / ${wrCosN()} looks</small>${nw?'<i class="fshdot">!</i>':''}</button>
   <button class="fsht2 fsg" id="wrlog" style="--c:#cfe0f0"><span class="fshic"><canvas id="wrlogc" width="120" height="96"></canvas></span><b>Route Log</b><small>${w.clears} clear${w.clears===1?'':'s'} · ${wrMedN(w)} / 9 medals</small></button>
   <button class="fsht2 fsg" id="wrhelp" style="--c:#9fd0ff"><span class="fshic"><canvas id="wrhelpc" width="120" height="96"></canvas></span><b>How to play</b><small>Repair or defend</small></button>
  </div></section>
 <div class="fsmod" id="wrmod" hidden></div></div>`,'fshx wrhx nosb');
 S.back=()=>{if(wrModal(null,true))return;title()};{const cn=$('cn');if(cn)cn.classList.add('dkhid')}
 WRM.rt=rt;const M=WRM.M=wrMenuState(rt);const bd=$('wrhb'),g=bd.getContext('2d');wrHubDraw(g,M,2);if(!dkRM())LIVE.push({cv:bd,fn:t=>wrHubDraw(g,M,t),slow:2});
 live('wrhdrv',c=>{const x=c.getContext('2d');return t=>{try{rrkPortrait(c,RRK[0],t)}catch(e){}}});
 live('wrwsc',c=>{const x=c.getContext('2d');return t=>{x.setTransform(1,0,0,1,0,0);x.clearRect(0,0,120,96);x.save();x.translate(60,14);wrLantern(x,0,-8,.52,WR_COS.lan[w.lan]||WR_COS.lan.brass,t,Math.sin(t*1.5)*.08,0);x.restore()}});
 live('wrlogc',c=>{const x=c.getContext('2d');return t=>{x.setTransform(1,0,0,1,0,0);x.clearRect(0,0,120,96);wrMedalDraw(x,60,50,30,Math.max(1,...WR_ROUTES.map(r=>w.med[r.id]||0)),t)}});
 {const x=$('wrhelpc').getContext('2d');x.save();x.translate(60,54);wrWheel(x,0,0,28,.4,'#d9a441',false);x.restore();x.save();x.translate(60,54);x.rotate(-.5);wrIcoWrench(x,26,-26,13,'#9fd0ff');x.restore()}
 $('wrback').onclick=()=>S.back();$('wrgo').onclick=()=>wrHitch();$('wrws').onclick=()=>wrWorkshop();$('wrlog').onclick=()=>wrRouteLog();$('wrhelp').onclick=()=>wrHowTo();
 $('wrmu').onclick=()=>{try{$('mt').click()}catch(e){}wrMuSync()};
 $('wrroutes').querySelectorAll('.wrrt').forEach(b=>{b.onclick=()=>wrSelect(b.dataset.id);b.ondblclick=()=>{wrSelect(b.dataset.id);wrHitch()}});
 wrHubFit();}
function wrMuIc(){return '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M9 18V6l10-2v12" stroke="currentColor" stroke-width="2.4" fill="none" stroke-linecap="round" stroke-linejoin="round"/><circle cx="6.5" cy="18" r="2.6" fill="currentColor"/><circle cx="16.5" cy="16" r="2.6" fill="currentColor"/></svg>'}
function wrMuSync(){const b=$('wrmu');if(!b)return;b.setAttribute('aria-pressed',ST.mute?'false':'true');const s=b.querySelector('span');if(s)s.textContent='Music: '+(ST.mute?'off':'on')}
function wrGoIc(){return '<svg viewBox="0 0 52 32" aria-hidden="true"><path d="M4 8h30l4 10H2z"/><circle cx="12" cy="24" r="5"/><circle cx="32" cy="24" r="5"/><rect x="38" y="2" width="8" height="12" rx="2"/></svg>'}
function wrHubFit(){const r=$('wrhub');if(!r)return;const W=ov.clientWidth||1600,H2=ov.clientHeight||900,nar=W<1100;r.classList.toggle('wr-narrow',nar);const z=nar?1:Math.min(1,W/1600,H2/900);r.style.zoom=z<.999?z.toFixed(3):''}
addEventListener('resize',()=>{if($('wrhub'))wrHubFit()});
const wrCosN=()=>WR_COSK.lan.length+WR_COSK.ban.length+WR_COSK.paint.length;
const wrOwnedN=w=>['lan','ban','paint'].reduce((n,f)=>n+WR_COSK[f].filter(k=>wrOwn(f,k,w)).length,0);
const wrMedN=w=>WR_ROUTES.reduce((n,r)=>n+(w.med[r.id]||0),0);
function wrRouteCard(r,w){const open=wrRouteOpen(r),m=w.med[r.id]||0,b=w.best[r.id],sel=r.id===wrSel;
 return `<button class="wrrt fsg${sel?' on':''}${open?'':' lock'}" data-id="${r.id}" role="option" aria-selected="${sel}" ${open?'':'aria-disabled="true"'} style="--c:${WR_MED[m].c}"><span class="wrrm">${wrMedalSVG(m,54)}</span><span class="wrrtt"><b>${esc(r.n)}</b><small>${esc(r.sub)} · ${r.legs} legs · up to ${Math.round(r.pay*1.15*1.5).toLocaleString()} coins</small>${open?`<em>${m?WR_MED[m].n+' medal':'No medal yet'}${b?` · best ${wrFmtT(b.t)}`:''}</em>`:`<em class="wrlk">${wrLockIc()} ${esc(wrNeedTxt(r.unlock))}</em>`}</span><i class="dkchv">›</i></button>`}
function wrLockIc(){return '<svg viewBox="0 0 24 24" width="13" height="13" aria-hidden="true"><rect x="5" y="10" width="14" height="11" rx="2.5" fill="currentColor"/><path d="M8 10V7a4 4 0 0 1 8 0v3" stroke="currentColor" stroke-width="2.4" fill="none"/></svg>'}
const wrFmtT=t=>{t=Math.round(t);return Math.floor(t/60)+':'+String(t%60).padStart(2,'0')};
function wrSelect(id){const r=WR_RT(id);if(!wrRouteOpen(r)){wrToastUi(`Locked · ${wrNeedTxt(r.unlock)}`);return}wrSel=id;const w=WRP();
 $('wrroutes').querySelectorAll('.wrrt').forEach(b=>{const on=b.dataset.id===id;b.classList.toggle('on',on);b.setAttribute('aria-selected',on)});
 const t=$('wrgot');if(t)t.innerHTML='Hitch up<small>'+esc(r.n)+'</small>';
 if(WRM.rt!==r){WRM.rt=r;const M=WRM.M;if(M){M.rt=r;M.bake=wrBake(r);M.embers=[]}}}
function wrToastUi(m){try{ccToast(m)}catch(e){}}
function wrHitch(){const r=WR_RT(wrSel);if(!wrRouteOpen(r)){wrToastUi(`Locked · ${wrNeedTxt(r.unlock)}`);return}const w=WRP();if(!w.intro){wrHowTo(true);return}wrStart(r.id);wrTouchKb()}
/* keys in the hub: Space hitches up, arrows pick a route, Enter on a card hitches */
addEventListener('keydown',e=>{if(!$('wrhub')||S.mode!=='title'||e.ctrlKey||e.metaKey||e.altKey)return;const mo=$('wrmod');if(mo&&!mo.hidden){if(e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();wrModal(null)}return}
 const ae=document.activeElement;if(ae&&/INPUT|TEXTAREA|SELECT/.test(ae.tagName)&&ae!==inp)return;
 if(e.key===' '){e.preventDefault();e.stopImmediatePropagation();if(!e.repeat)wrHitch()}
 else if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();const ids=WR_ROUTES.filter(wrRouteOpen).map(r=>r.id),i=ids.indexOf(wrSel);wrSelect(ids[(i+(e.key==='ArrowDown'?1:-1)+ids.length)%ids.length])}
 else if(e.key==='Enter'&&ae&&ae.classList&&ae.classList.contains('wrrt')){e.preventDefault();wrSelect(ae.dataset.id);wrHitch()}},true);
/* ---------- modals ---------- */
function wrModal(h,quiet){const m=$('wrmod');if(!m)return false;if(!h){if(m.hidden)return false;m.hidden=true;m.innerHTML='';LIVE=LIVE.filter(l=>l.cv&&l.cv.isConnected);WRM.pv=null;if(!quiet)wagonMenuRefresh();return true}m.innerHTML=h;m.hidden=false;m.onclick=e=>{if(e.target===m)wrModal(null)};const f=m.querySelector('[data-first]')||m.querySelector('button');try{f&&f.focus({preventScroll:true})}catch(e){}return true}
function wagonMenuRefresh(){const w=WRP();const rc=$('wrroutes');if(rc)rc.innerHTML=WR_ROUTES.map(r=>wrRouteCard(r,w)).join('');if(rc)rc.querySelectorAll('.wrrt').forEach(b=>{b.onclick=()=>wrSelect(b.dataset.id);b.ondblclick=()=>{wrSelect(b.dataset.id);wrHitch()}});
 const ws=$('wrws');if(ws){const s=ws.querySelector('small');if(s)s.textContent=`${wrOwnedN(w)} / ${wrCosN()} looks`;const d=ws.querySelector('.fshdot');const nw=['lan','ban','paint'].some(f=>WR_COSK[f].some(k=>w.seen[f+':'+k]===0));if(d&&!nw)d.remove()}
 if(WRM.M){WRM.M.look={lan:w.lan,ban:w.ban,paint:w.paint}}}
/* the Convoy Workshop: lanterns, banners and paint, previewed live on the wagon */
function wrWorkshop(){const w=WRP(),F={lan:'Lanterns',ban:'Banners',paint:'Paint'};
 const row=f=>`<div class="wrwrow"><h4>${F[f]}</h4><div class="wrchips">${WR_COSK[f].map(k=>{const c=WR_COS[f][k],own=wrOwn(f,k,w),on=w[f]===k,nw=w.seen[f+':'+k]===0;
  return `<button class="wrchip${on?' on':''}${own?'':' lock'}" data-f="${f}" data-k="${k}" title="${esc(c.d)}" ${own?'':'aria-disabled="true"'}><span class="wrchpv"><canvas width="84" height="84"></canvas></span><b>${esc(c.n)}</b>${own?(on?'<small class="wreq">Equipped</small>':'<small>Equip</small>'):`<small class="wrlk">${wrLockIc()} ${esc(wrNeedTxt(c.need))}</small>`}${nw?'<i class="wrnew">NEW</i>':''}</button>`}).join('')}</div></div>`;
 wrModal(`<div class="wrws fsg"><button class="fsx2" id="wrwsx" aria-label="Close">✕</button><div class="wrwsl"><h3>Convoy Workshop</h3><p>Looks for the lantern, the banner and the wagon. Medals on the routes unlock them.</p><canvas id="wrwspv" width="640" height="360"></canvas><p class="wrwsd" id="wrwsd">${esc((WR_COS.lan[w.lan]||{}).d||'')}</p></div><div class="wrwsr">${row('lan')}${row('ban')}${row('paint')}</div></div>`);
 for(const f of['lan','ban','paint'])for(const k of WR_COSK[f])if(w.seen[f+':'+k]===0)w.seen[f+':'+k]=1;save();
 $('wrwsx').onclick=()=>wrModal(null);
 const pv=$('wrwspv'),g=pv.getContext('2d');const M=WRM.pv=wrMenuState(WR_RT(wrSel));M.ox=-268;
 const draw=t=>{M.t=t;M.swing=Math.sin(t*1.7)*.06;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,640,360);g.fillStyle='#0c0824';g.fillRect(0,0,640,360);g.save();g.scale(.78,.78);g.translate(-60,-385);try{wrWagonDraw(g,M)}catch(e){}g.restore();
  g.fillStyle='#1c1838';g.fillRect(0,300,640,60);g.fillStyle='#ffffff14';g.fillRect(0,300,640,2)};
 draw(2);LIVE.push({cv:pv,fn:draw,slow:2});
 const chips=[...document.querySelectorAll('.wrchip')];for(const b of chips){const f=b.dataset.f,k=b.dataset.k,cv=b.querySelector('canvas'),x=cv.getContext('2d');wrChipArt(x,f,k);
  const prev=()=>{M.look=Object.assign({},M.look,{[f]:k});const d=$('wrwsd');if(d)d.textContent=WR_COS[f][k].d};const back=()=>{M.look={lan:w.lan,ban:w.ban,paint:w.paint};const d=$('wrwsd');if(d)d.textContent=''};
  b.onmouseenter=prev;b.onfocus=prev;b.onmouseleave=back;b.onblur=back;
  b.onclick=()=>{if(!wrOwn(f,k,w)){wrToastUi(`Locked · ${wrNeedTxt(WR_COS[f][k].need)}`);return}w[f]=k;save();chips.forEach(q=>{if(q.dataset.f!==f)return;const on=q.dataset.k===k;q.classList.toggle('on',on);const s=q.querySelector('small');if(s&&!q.classList.contains('lock')){s.textContent=on?'Equipped':'Equip';s.className=on?'wreq':''}});M.look={lan:w.lan,ban:w.ban,paint:w.paint};try{beep(660,.06,'triangle',.3)}catch(e){}}}}
function wrChipArt(x,f,k){const c=WR_COS[f][k];x.setTransform(1,0,0,1,0,0);x.clearRect(0,0,84,84);
 if(f==='lan'){x.save();x.translate(42,6);wrLantern(x,0,-4,.46,c,2,0,0);x.restore()}
 else if(f==='ban'){x.save();x.translate(26,80);if(c.c0){x.scale(.5,.5);wrBanner(x,0,0,c,1,0)}else{x.strokeStyle='#8a5a2c';x.lineWidth=4;x.beginPath();x.moveTo(8,0);x.lineTo(8,-70);x.stroke()}x.restore()}
 else{x.save();x.translate(42,52);x.beginPath();x.roundRect(-30,-22,60,34,6);const q=x.createLinearGradient(0,-22,0,12);q.addColorStop(0,c.body);q.addColorStop(1,c.dark);wrFill(x,q,3);wrWheel(x,-16,16,12,.3,c.rim,false);wrWheel(x,16,16,12,.3,c.rim,false);x.restore()}}
/* the Route Log */
function wrRouteLog(){const w=WRP(),rows=WR_ROUTES.map(r=>{const m=w.med[r.id]||0,b=w.best[r.id];return `<div class="wrlr" style="--c:${WR_MED[m].c}">${wrMedalSVG(m,46)}<div><b>${esc(r.n)}</b><small>${esc(r.sub)}</small></div><span><small>Medal</small><b>${WR_MED[m].n}</b></span><span><small>Best time</small><b>${b?wrFmtT(b.t):'—'}</b></span><span><small>Accuracy</small><b>${b?b.acc+'%':'—'}</b></span></div>`}).join('');
 const master=WR_ROUTES.every(r=>(w.med[r.id]||0)>=3);
 wrModal(`<div class="wrlog fsg"><button class="fsx2" id="wrlogx" aria-label="Close">✕</button><h3>Route Log</h3><div class="wrlrs">${rows}</div>
  <div class="wrlst"><span><small>Routes run</small><b>${w.runs}</b></span><span><small>Routes cleared</small><b>${w.clears}</b></span><span><small>Monsters cut down</small><b>${w.kills.toLocaleString()}</b></span><span><small>Repairs</small><b>${w.repairs}</b></span><span><small>Lantern Flares</small><b>${w.flares}</b></span><span><small>Coins earned</small><b>${w.gold.toLocaleString()}</b></span></div>
  <p class="wrlm ${master?'on':''}">${master?'Caravan Master: gold on every route. The title is yours in the bounty exchange.':'Gold on every route earns the <b>Caravan Master</b> title.'}</p></div>`);
 $('wrlogx').onclick=()=>wrModal(null)}
/* how to play: the three-step strip from the concept, also the first-run intro */
function wrHowTo(intro){wrModal(`<div class="wrhow fsg"><button class="fsx2" id="wrhowx" aria-label="Close">✕</button><h3>${intro?'Before you hitch up':'How to play'}</h3>
  <div class="wrsteps"><div class="wrstep"><canvas width="300" height="150" data-k="jam"></canvas><b>1 · Wheel gets jammed</b><small>Rocks, branches, mud and loose cargo stop the wagon. A blue wrench bubble appears.</small></div><i>›</i>
   <div class="wrstep"><canvas width="300" height="150" data-k="type"></canvas><b>2 · Type the word</b><small>Type the repair word before the fuse runs out, or the axle cracks and you lose a shield.</small></div><i>›</i>
   <div class="wrstep"><canvas width="300" height="150" data-k="roll"></canvas><b>3 · Wagon keeps moving</b><small>Monsters carry a red sword tag. Type their word and the hero cuts them down.</small></div></div>
  <div class="wrhrow"><span>${wrShieldSVG(22)}<em>Four <b>Wagon Integrity</b> shields. A monster that reaches the wagon takes one.</em></span><span>${wrLanternSVG(22)}<em>Letters fill the lantern. <kbd>Enter</kbd> fires a <b>Lantern Flare</b>: every monster is flung off the road and a shield comes back.</em></span><span><em><kbd>Tab</kbd> switches target. Reach the gate for coins, XP and a route medal.</em></span></div>
  <div class="row"><button id="wrhowgo" data-first>${intro?'Hitch up':'Got it'}</button></div></div>`);
 $('wrhowx').onclick=()=>wrModal(null);$('wrhowgo').onclick=()=>{if(intro){const w=WRP();w.intro=1;save();wrModal(null,true);wrStart(wrSel);wrTouchKb()}else wrModal(null)};
 document.querySelectorAll('.wrstep canvas').forEach((cv,i)=>{const g=cv.getContext('2d'),k=cv.dataset.k;const d=t=>wrStepArt(g,k,t);d(1);LIVE.push({cv,fn:d,slow:2,ph:i})})}
function wrStepArt(g,k,t){g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,300,150);g.fillStyle='#120e30';g.fillRect(0,0,300,150);g.fillStyle='#262046';g.fillRect(0,118,300,32);g.fillStyle='#ffffff14';g.fillRect(0,118,300,2);
 g.save();g.translate(150,118);
 if(k==='jam'){g.fillStyle='#3a2a1c';g.fillRect(-120,-60,200,22);g.beginPath();g.moveTo(32,0);g.lineTo(40,-22);g.lineTo(58,-30);g.lineTo(78,-18);g.lineTo(84,0);g.closePath();wrFill(g,'#6a6478',3);wrWheel(g,0,-40,40,.6,'#d9a441',false);
  for(let i=0;i<5;i++){const u=((t*2.2+i*.37)%1);g.globalAlpha=1-u;pStar4(g,30+Math.sin(i*4)*18*u,-10-u*40,4,i%2?'#ffd45a':'#ff9a5a')}g.globalAlpha=1}
 else if(k==='type'){g.fillStyle='#3a2a1c';g.fillRect(-120,-60,200,22);wrWheel(g,0,-40,40,.6,'#d9a441',false);const e={hz:1,w:'mend',i:2+(Math.floor(t*1.4)%3),x:150,y:92,t:5,fuse:8,badT:0,ph:0};g.restore();g.save();wrTag(g,e,true)}
 else{wrWheel(g,0,-40,40,t*7,'#d9a441',false);g.strokeStyle='#9fd0ff';g.lineWidth=3;g.lineCap='round';for(let i=0;i<4;i++){const y=-70+i*18,l=30+((t*300+i*47)%60);g.globalAlpha=.6;g.beginPath();g.moveTo(-70-l,y);g.lineTo(-70,y);g.stroke()}g.globalAlpha=1}
 g.restore()}
function wrShieldSVG(s){return `<svg viewBox="-14 -14 28 28" width="${s}" height="${s}" aria-hidden="true"><path d="M0 -12L11 -8L10.5 1Q8 10 0 13Q-8 10 -10.5 1L-11 -8Z" fill="#ffd45a" stroke="#12081f" stroke-width="2"/></svg>`}
function wrLanternSVG(s){return `<svg viewBox="-12 -14 24 30" width="${s}" height="${s*1.2}" aria-hidden="true"><rect x="-8" y="-8" width="16" height="22" rx="3" fill="#ffb84a" stroke="#12081f" stroke-width="2"/><path d="M-4 -8a4 4 0 0 1 8 0" stroke="#12081f" stroke-width="2" fill="none"/></svg>`}
/* ---------- medals ---------- */
function wrMedalSVG(m,sz){const c=WR_MED[m]||WR_MED[0],col=c.c,dk=m?'#12081f':'#3a3450';
 return `<svg viewBox="0 0 60 60" width="${sz}" height="${sz}" aria-hidden="true"><path d="M20 4h20l-6 20H26z" fill="${m?'#3a2a7a':'#2a2438'}" stroke="${dk}" stroke-width="2"/><path d="M14 4h12l-6 20" fill="${m?'#5a3ab0':'#3a3450'}" stroke="${dk}" stroke-width="2"/><path d="M34 4h12l-6 20" fill="${m?'#5a3ab0':'#3a3450'}" stroke="${dk}" stroke-width="2"/><circle cx="30" cy="38" r="17" fill="${m?col:'#2a2438'}" stroke="${dk}" stroke-width="2.4"/><circle cx="30" cy="38" r="11" fill="none" stroke="${m?'#12081f55':'#4a4260'}" stroke-width="2"/>${m?'<path d="M30 30v16M22 38h16M24.3 32.3l11.4 11.4M35.7 32.3L24.3 43.7" stroke="#12081f88" stroke-width="2"/><path d="M22 30q4-5 10-5" stroke="#ffffffaa" stroke-width="2" fill="none" stroke-linecap="round"/>':'<path d="M24 32l12 12M36 32L24 44" stroke="#4a4260" stroke-width="2.4"/>'}</svg>`}
function wrMedalDraw(g,x,y,r,m,t){const c=WR_MED[m]||WR_MED[0];g.save();g.translate(x,y);g.fillStyle=m?'#3a2a7a':'#2a2438';g.beginPath();g.moveTo(-r*.5,-r*1.5);g.lineTo(r*.5,-r*1.5);g.lineTo(r*.3,-r*.5);g.lineTo(-r*.3,-r*.5);g.closePath();wrFill(g,m?'#5a3ab0':'#3a3450',2.4);
 g.beginPath();g.arc(0,r*.1,r*.75,0,TAU);wrFill(g,m?c.c:'#2a2438',2.6);g.beginPath();g.arc(0,r*.1,r*.45,0,TAU);g.strokeStyle=m?'#12081f55':'#4a4260';g.lineWidth=2;g.stroke();
 if(m){wrWheel(g,0,r*.1,r*.42,t*.6,'#12081f88',true);wrHi(g,-r*.4,-r*.3,-r*.1,-r*.52,2.4,.6)}g.restore()}
/* ---------- the result card ---------- */
function wrResult(){const R=WRX,r=R&&R.result;if(!r)return;S.mode='over';const rt=R.rt,M=WR_MED[r.med],w=WRP();
 const unl=r.unl.map(([f,k])=>`<span class="wrunl" style="--c:${WR_MED[(WR_COS[f][k].need||{}).med||3].c}"><canvas width="64" height="64" data-f="${f}" data-k="${k}"></canvas><b>${esc(WR_COS[f][k].n)}</b><small>New ${f==='lan'?'lantern':f==='ban'?'banner':'paint'}</small></span>`).join('');
 show(`<div class="wrres ${r.won?'win':'lose'}" style="--c:${M.c}"><div class="wrmed${r.won?' slam':''}">${wrMedalSVG(r.med,150)}</div>
  <h2>${r.won?'Route complete!':'Broke down'}</h2><p class="wrsub">${esc(rt.n)} · ${r.won?`<b style="color:${M.c}">${M.n} medal</b>${r.newMed?' · <b class="wrnb">new!</b>':''}`:`${Math.round(r.prog*100)}% of the way`}${r.won&&r.med<3?` · gold needs 4 shields and 92% accuracy`:''}</p>
  <div class="res"><div><b>${wrFmtT(r.time)}</b>Time</div><div><b>${Math.round(r.acc*100)}%</b>Accuracy</div><div><b>${r.wpm}</b>Words per minute</div><div><b>${r.kills}</b>Monsters cut down</div><div><b>${r.repairs}</b>Repairs</div><div><b>${r.maxCombo}</b>Best streak</div><div><b>${r.int} / ${WRT.MAXINT}</b>Shields left</div></div>
  <div class="wrpay"><span class="wrpayc"><i class="wrcoinb" id="wrcoinb"></i><b id="wrtot">+0</b> coins</span><small>route pay ${r.pay.toLocaleString()}${r.first?' (first run today ×1.5)':''} · road coins ${r.coins}${r.lg?` · level-up bonus ${r.lg}`:''}</small></div>
  <p class="wrxp">Earned <b>${r.xp.toLocaleString()} XP</b>${r.l1>r.l0?`<br><b>Level up! You are now level ${r.l1}, ${rankOf(r.l1)}.</b>`:''}${r.xn||''}${r.ttl?'<br><b style="color:#ffd45a">Caravan Master! The title is yours in the bounty exchange.</b>':''}</p>
  ${unl?`<div class="wrunls">${unl}</div>`:''}
  <div class="row"><button id="wr1">Ride again</button><button class="sm" id="wr2">Routes</button><button class="sm" id="hm">Home</button></div></div>`,'wrpx');
 $('wr1').onclick=()=>wrRestart();$('wr2').onclick=()=>wrQuit();$('hm').onclick=()=>{wrLeave();title()};S.back=()=>{wrLeave();title()};
 document.querySelectorAll('.wrunl canvas').forEach(cv=>wrChipArt(cv.getContext('2d'),cv.dataset.f,cv.dataset.k));
 const tt=$('wrtot');if(wrRM()||!r.total){if(tt)tt.textContent='+'+r.total.toLocaleString()}else setTimeout(()=>{wrCount(tt,r.total);wrCoinsFly(tt)},r.won?700:300)}
function wrCount(el,v){if(!el)return;const t0=performance.now(),D=900;const f=t=>{const u=Math.min(1,(t-t0)/D);el.textContent='+'+Math.round(v*(1-Math.pow(1-u,3))).toLocaleString();if(u<1)requestAnimationFrame(f)};requestAnimationFrame(f)}
function wrLoc(el){const B=ov.getBoundingClientRect(),k=B.width/(ov.offsetWidth||1)||1,r=el.getBoundingClientRect();return{left:(r.left-B.left)/k,top:(r.top-B.top)/k,width:r.width/k,height:r.height/k}}
function wrCoinsFly(from){const to=$('wrcoinb');if(!from||!to||!from.isConnected)return;const a=wrLoc(from),b=wrLoc(to),n=12;
 for(let i=0;i<n;i++){const c=document.createElement('i');c.className='wrfly';const x0=a.left+a.width/2+(Math.random()-.5)*120,y0=a.top+a.height/2+40+Math.random()*60,x1=b.left+b.width/2,y1=b.top+b.height/2;
  c.style.left=(x0-11)+'px';c.style.top=(y0-11)+'px';ov.appendChild(c);const dx=x1-x0,dy=y1-y0;
  const an=c.animate([{transform:'translate(0,0) scale(.4)',opacity:0},{transform:`translate(${dx*.3}px,${dy*.3-60}px) scale(1.1)`,opacity:1,offset:.35},{transform:`translate(${dx}px,${dy}px) scale(.7)`,opacity:1}],{duration:620+i*45,delay:i*40,easing:'cubic-bezier(.3,.7,.3,1)',fill:'forwards'});
  an.onfinish=()=>{c.remove();try{beep(1318+Math.random()*300,.05,'triangle',.1)}catch(e){}to.classList.remove('bump');void to.offsetWidth;to.classList.add('bump')}}}
/* ---------- the touch keyboard for the run ---------- */
function wrTouchKb(){try{if(!TM())return}catch(e){return}const R=WRX;if(!R||R.pause||R.over)return;
 show(`<div id="wrkb" aria-label="Keyboard">${['qwertyuiop','asdfghjkl','zxcvbnm'].map((r,i)=>`<div class="wrkr">${[...r].map(c=>`<button data-c="${c}" tabindex="-1">${c}</button>`).join('')}</div>`).join('')}<div class="wrkr wrka"><button data-a="pause" tabindex="-1">Pause</button><button data-a="tab" tabindex="-1">Target</button><button class="wrkf" data-a="flare" tabindex="-1">Flare</button></div></div>`,'wrkbx');
 const kb=$('wrkb');kb.addEventListener('pointerdown',e=>{const b=e.target.closest('button');if(!b)return;e.preventDefault();try{ensureAudio()}catch(x){}if(b.dataset.c)wrKey(b.dataset.c);else if(b.dataset.a==='pause')wrPause();else if(b.dataset.a==='tab')wrTab();else if(b.dataset.a==='flare')wrFlare();b.classList.remove('hit');void b.offsetWidth;b.classList.add('hit')})}
{const p0=wrPause;wrPause=function(on){const R=WRX;const was=R&&R.pause;p0.apply(this,arguments);if(R&&was&&!R.pause)wrTouchKb()}}
{const s0=wrStart;wrStart=function(){const r=s0.apply(this,arguments);return r}}
{const r0=wrRestart;wrRestart=function(){const r=r0.apply(this,arguments);wrTouchKb();return r}}
/* ---------- hooks into the game ---------- */
MG.wagon=bP('M14 40h54l6 22H10z','#8a5a2c')+bF('M14 40h54l6 22H10z','#000',.22)+bH('M18 44h44','#fff',3)+bC(28,70,10,'#4a3020')+bC(28,70,4,'#d9a441')+bC(62,70,10,'#4a3020')+bC(62,70,4,'#d9a441')+bP('M60 20h18v20H60z','#ffb84a')+bP('M64 14h10v6H64z','#d9a441')+bS(69,30,4,'#fff8d8');
MA.wagon='#ffb04a';
/* Choose mode: a featured card above the grid */
{const m0=modeSheet;modeSheet=function(){const r=m0.apply(this,arguments);try{const sh=document.querySelector('.dks .dkpv[data-v="m"]')||document.querySelector('.dkpv[data-v="m"]'),g=sh&&sh.querySelector('.dkmg');if(g&&!sh.querySelector('#dmwr')){const w=WRP(),b=document.createElement('button');b.className='dkm dkmwr';b.id='dmwr';b.style.setProperty('--c','#ffb04a');try{const u=wrCardShot();if(u)b.style.setProperty('--img',`url(${u})`)}catch(e){}
  b.innerHTML=`<span class="dkmi">${mico('wagon',58)}</span><span class="dkmt"><b>Lantern Caravan${w.seen85?'':' <em class="dkmnew">NEW</em>'}</b><small>Escort the wagon to the gate. Type to fight and to mend the wheel. ${wrMedN(w)} / 9 medals.</small></span><i class="dkchv">›</i>`;
  g.insertBefore(b,g.firstChild);b.onclick=()=>{dkClose(true);setTimeout(()=>wagonMenu(title),0)}}}catch(e){console.error(e)}return r}}
/* the home card: it takes the Endless slot, or joins as a fourth card while the Halloween events card is up */
{const t0=title;title=function(){const r=t0.apply(this,arguments);try{wrHomeCard()}catch(e){console.error(e)}return r}}
function wrHomeCard(){const sc=ov.querySelector('.dksc');if(!sc||sc.querySelector('#dkwagon'))return;const w=WRP(),go=sc.querySelector('#go'),d=document.createElement('div');
 d.innerHTML=`<button class="dkcard dkwagon dklive dkg dktilt" id="dkwagon" title="Lantern Caravan (W)" aria-label="Lantern Caravan, new mode. ${wrMedN(w)} of 9 route medals"><canvas class="dkcv" width="560" height="320" aria-hidden="true"></canvas><i class="dkgl"></i>${w.seen85?'':'<em class="dknew">NEW</em>'}<span class="dkcl"><small>${w.seen85?'LANTERN CARAVAN':'NEW MODE'}</small><b>${w.seen85?(w.clears?'Escort the wagon':'Hitch up the wagon'):'Lantern Caravan'}</b><small class="dkevv">${wrMedN(w)?`${wrMedN(w)} / 9 medals`:'Reach the Village Gate'} <i>›</i></small></span></button>`;
 const card=d.firstChild;if(go)go.replaceWith(card);else{sc.appendChild(card);sc.classList.add('dks4');try{dkFit()}catch(e){}}card.onclick=()=>wagonMenu(title);
 const cv=card.querySelector('canvas'),g=cv.getContext('2d');const draw=t=>{try{wrCardScene(g,560,320,t)}catch(e){}};draw(2);if(!dkRM())LIVE.push({cv,fn:draw,slow:2,ph:2})}
let WRCARD=null,WRSHOT='';
function wrCardShot(){if(WRSHOT)return WRSHOT;const c=document.createElement('canvas');c.width=640;c.height=360;const g=c.getContext('2d');wrCardScene(g,640,360,2.5);g.fillStyle='rgba(12,8,34,.35)';g.fillRect(0,0,640,360);return WRSHOT=c.toDataURL('image/webp',.72)}
function wrCardScene(g,w,h,t){const rt=WR_RT('mill'),B=wrBake(rt);if(!WRCARD||WRCARD.width!==w){WRCARD=document.createElement('canvas');WRCARD.width=w;WRCARD.height=h;const c=WRCARD.getContext('2d');c.drawImage(B.sky,300,160,1000,571,0,0,w,h);c.globalAlpha=.9;c.drawImage(B.far,200,0,1000,470,0,h*.28,w,h*.72);c.globalAlpha=1}
 g.setTransform(1,0,0,1,0,0);g.drawImage(WRCARD,0,0);const k=w/1000;
 g.save();g.translate(0,h*.72);g.scale(k,k);let sx=-((t*60)%480);g.save();g.globalAlpha=.9;for(;sx<1000;sx+=480)g.drawImage(B.wall,sx,-150+22);g.restore();g.restore();
 const M=WRCARD.M||(WRCARD.M=wrMenuState(rt));M.t=t;M.swing=Math.sin(t*1.7)*.06;M.wheel=t*2.2;M.v=60;
 g.save();g.translate(w*.5-640*k*.95,h*.72+22*k+GY*0);g.scale(k*.95,k*.95);g.translate(0,-GY);try{wrWagonDraw(g,M)}catch(e){}g.restore();
 g.save();g.translate(w*.5-640*k*.95,h*.72+22*k);g.scale(k*.95,k*.95);g.translate(0,-GY);try{wrHeroDraw(g,M)}catch(e){}g.restore();
 const q=g.createLinearGradient(0,0,w,0);q.addColorStop(0,'#0c0822c0');q.addColorStop(.45,'#0c082230');q.addColorStop(1,'#0c082200');g.fillStyle=q;g.fillRect(0,0,w,h)}
/* the W key on the home hub */
{const hk0=homeKey;homeKey=function(e){if(HOME&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&(e.key==='w'||e.key==='W')&&!document.querySelector('.dks.on')){const ae=document.activeElement;if(!(ae&&ae!==inp&&/INPUT|TEXTAREA|SELECT/.test(ae.tagName))){e.preventDefault();wagonMenu(title);return true}}return hk0.apply(this,arguments)}}
/* the Play tab lights up on the caravan screens */
{const d0=dkDetect;dkDetect=function(html){if(typeof html==='string'&&/class="wrx wrhub/.test(html))return'pl';return d0.apply(this,arguments)}}
/* help */
try{HELP.Modes.unshift(['Lantern Caravan','New! Escort a goblin-driven lantern wagon along a night road. Monsters walk in from the right with a word on a red sword tag: type it and your hero cuts them down. When the wheel jams, type the repair word in the blue wrench bubble before the fuse runs out. Monsters that reach the wagon take one of four shields. Letters fill the lantern; Enter fires a Lantern Flare that clears the road and restores a shield. Reach the gate for coins, XP and a bronze, silver or gold route medal. Medals unlock lanterns, banners and paint in the Convoy Workshop.']);HELP.Shortcuts.push(['W','Lantern Caravan from the main menu.'])}catch(e){}
/* the bounty and the title */
try{const t={k:'wagon',tier:1,ok:()=>true,mk:r=>({n:1}),txt:c=>'Finish a Lantern Caravan route'};BTPL.push(t);BTK.wagon=t}catch(e){}
try{BT_TITLES.push(['caravanmaster','Caravan Master',1e9]);const b0=bountyBoard;bountyBoard=function(){const r=b0.apply(this,arguments);try{const x=ov.querySelector('[data-buy="t:caravanmaster"]');if(x){const s=document.createElement('span');s.className='rrlock';s.textContent='Earn: gold on every caravan route';x.replaceWith(s)}}catch(e){}return r}}catch(e){}
/* developer cheats */
try{const h0=dvxHTML;dvxHTML=function(){let h=h0.apply(this,arguments);const w=WRP();h+=`<div class="dvx"><h5>Lantern Caravan</h5><div class="dvrow"><span>${wrMedN(w)} / 9 medals · ${w.clears} clears · ${wrOwnedN(w)} / ${wrCosN()} looks</span></div><div class="dvrow">${dvBtn('x:wrgo','Open the hub')}${dvBtn('x:wrmill','Start Millbrook')}${dvBtn('x:wrpines','Start Hollow Pines')}${dvBtn('x:wrgallows','Start Gallows Pass')}${dvBtn('x:wrmed','All gold medals')}${dvBtn('x:wrcos','All looks')}${dvBtn('x:wrreset','Reset caravan save')}</div></div>`;return h};
 const a0=dvxAct;dvxAct=function(a){if(!/^wr/.test(a))return a0.apply(this,arguments);const w=WRP();
  if(a==='wrgo'){DEV.open=false;devRender();wagonMenu(title)}else if(a==='wrmill'||a==='wrpines'||a==='wrgallows'){DEV.open=false;devRender();wrStart(a.slice(2))}
  else if(a==='wrmed'){for(const r of WR_ROUTES)w.med[r.id]=3;wrUnlockSweep();dvxMsg('Gold on every route.')}else if(a==='wrcos'){for(const f of['lan','ban','paint'])for(const k of WR_COSK[f])w.own[f+':'+k]=1;dvxMsg('Every convoy look owned.')}
  else if(a==='wrreset'){delete P.wr;WRP();dvxMsg('Caravan save reset.')}}}catch(e){}
/* touch: the stage moves up to leave room for the caravan keyboard (kbWant only knows the main fight) */
{const a0=applyLayout;applyLayout=function(){const r=a0.apply(this,arguments);try{const kb=$('wrkb');if(kb&&S.wr&&TM()&&ov.className.indexOf('hide')<0){const vw=innerWidth,vh=innerHeight,kh=kb.getBoundingClientRect().height||0,ah=Math.max(120,vh-kh);let k=Math.min(vw/W,ah/H);wrap.style.top=(ah/2)+'px';wrap.style.transform=`translate(-50%,-50%) scale(${k})`}}catch(e){}return r}}
{const t0=wrTouchKb;wrTouchKb=function(){const r=t0.apply(this,arguments);try{if($('wrkb'))applyLayout()}catch(e){}return r}}
