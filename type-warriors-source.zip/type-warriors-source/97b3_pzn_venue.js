/* ===== 10.1 THE CROOKED CUE: Orbit 8, the room, the table and the match (97b3) =====
   The Orbit 8 lounge, baked once into one 1600 x 900 canvas like 96f (pznBake): a ceiling skylight full of stars, dark navy hull
   panels with cyan light strips, a round porthole on the left with a ringed gas giant, a tall viewport on the right with a nebula,
   a ring station and a moon, a polished floor with a perspective grid, neon edges and the table's glow. The table keeps the exact
   96f geometry (the cushions trace PZ_TBL, the pockets sit on PZ_POCK) but is its own design: gunmetal rails with a chrome bevel and
   a cyan neon inlay, LED sights, a steel-blue felt with a faint hex weave and the Orbit 8 ring in the kitchen, chrome pockets with a
   magenta ring round a swirling gravity well, a glass ball-return tube, and no legs: two hover pods throw light on the floor.
   Per frame (pzDrawLamp / pzDrawLights / pzDrawDust wrapped, only while PZ.pzn): the floating halo light with running lights, a few
   twinkling stars, a shuttle that crosses the viewport now and then, the neon sign flicker, the hover pods and slow zero-g motes;
   lite mode and reduced motion keep only the halo. Shot flair per player (pzContact wrapped), a venue VS intro (pzIntro wrapped)
   and a synth lounge groove (note wrapped) while you are in Orbit 8. */
const PZN_FELT={id:'orbit',n:'Orbit Blue',a:'#2878a8',b:'#195282',c:'#0d3460'};
const pznVenueNow=()=>!!((PZ.on&&PZ.pzn)||(!PZ.on&&ov&&ov.querySelector(':scope>.pzn8')));
/* ---------- space: stars, nebulae, the gas giant ---------- */
function pznStars(g,x,y,w,h,n,seed){for(let i=0;i<n;i++){const sx=x+pzNoise(i*3.7+seed)*w,sy=y+pzNoise(i*5.3+seed+1)*h,r=pzNoise(i*1.9+seed+2)*1.3+.35,a=.35+pzNoise(i+seed)*.6;g.fillStyle=i%9?`rgba(235,230,255,${a})`:`rgba(255,210,240,${a})`;g.fillRect(sx-r/2,sy-r/2,r,r)}
 for(let i=0;i<Math.max(1,n/40);i++){const sx=x+pzNoise(i*7.1+seed+4)*w,sy=y+pzNoise(i*2.3+seed+5)*h;g.fillStyle='rgba(255,255,255,.9)';pznStar4(g,sx,sy,3.5);pzGlow(g,sx,sy,9,'rgba(200,220,255,1)',.5)}}
function pznNebula(g,x,y,r,col,a){const q=g.createRadialGradient(x,y,2,x,y,r);q.addColorStop(0,col.replace('A',a));q.addColorStop(.5,col.replace('A',a*.4));q.addColorStop(1,col.replace('A',0));g.fillStyle=q;g.fillRect(x-r,y-r,r*2,r*2)}
function pznSpaceFill(g,x,y,w,h,seed){g.fillStyle=pzLin(g,0,y,0,y+h,[[0,'#04031a'],[.6,'#0b0930'],[1,'#170e3c']]);g.fillRect(x,y,w,h);
 pznNebula(g,x+w*.3,y+h*.4,w*.5,'rgba(190,60,200,A)',.22);pznNebula(g,x+w*.75,y+h*.7,w*.45,'rgba(40,170,230,A)',.2);pznStars(g,x,y,w,h,Math.round(w*h/900),seed)}
function pznPlanet(g,cx,cy,r,tilt){/* rings behind, the banded body with a terminator, rings in front */
 const ring=(front)=>{g.save();g.translate(cx,cy);g.rotate(tilt);for(const [rr,lw,c] of[[r*1.95,10,'rgba(230,200,150,.55)'],[r*1.72,7,'rgba(255,230,190,.75)'],[r*1.5,9,'rgba(200,150,110,.6)'],[r*1.3,3,'rgba(255,240,210,.5)']]){g.strokeStyle=c;g.lineWidth=lw;g.beginPath();g.ellipse(0,0,rr,rr*.24,0,front?0:Math.PI,front?Math.PI:TAU);g.stroke()}g.restore()};
 ring(false);g.save();g.beginPath();g.arc(cx,cy,r,0,TAU);g.clip();g.fillStyle='#e8a060';g.fillRect(cx-r,cy-r,r*2,r*2);
 const bands=['#f4d0a0','#d8804a','#f0c088','#b8603a','#e8b07a','#c87048','#f8dcb0','#a8502e'];for(let i=0;i<14;i++){const y0=cy-r+i*(r*2/14);g.fillStyle=bands[i%8];g.beginPath();g.moveTo(cx-r,y0);for(let x=0;x<=r*2;x+=r/6)g.lineTo(cx-r+x,y0+Math.sin(x*.05+i)*4);g.lineTo(cx+r,y0+r*2/14+3);g.lineTo(cx-r,y0+r*2/14+3);g.closePath();g.fill()}
 g.fillStyle='rgba(200,80,50,.8)';g.beginPath();g.ellipse(cx+r*.25,cy+r*.18,r*.18,r*.09,0,0,TAU);g.fill();g.strokeStyle='rgba(255,220,180,.6)';g.lineWidth=2;g.stroke();
 const sh=g.createRadialGradient(cx-r*.45,cy-r*.4,r*.2,cx-r*.1,cy-r*.05,r*1.35);sh.addColorStop(0,'rgba(255,240,210,.25)');sh.addColorStop(.55,'rgba(0,0,0,0)');sh.addColorStop(1,'rgba(10,4,30,.9)');g.fillStyle=sh;g.fillRect(cx-r,cy-r,r*2,r*2);g.restore();
 g.strokeStyle=PZ_O;g.lineWidth=3;g.beginPath();g.arc(cx,cy,r,0,TAU);g.stroke();g.strokeStyle='rgba(255,220,170,.45)';g.lineWidth=2;g.beginPath();g.arc(cx,cy,r-2,Math.PI*1.05,Math.PI*1.6);g.stroke();ring(true)}
function pznStation(g,cx,cy,r){/* a distant ring station: a torus with spokes and lit windows */
 g.save();g.translate(cx,cy);g.rotate(-.25);g.strokeStyle='#3a4468';g.lineWidth=r*.28;g.beginPath();g.ellipse(0,0,r,r*.38,0,0,TAU);g.stroke();g.strokeStyle='#8a96c8';g.lineWidth=r*.12;g.beginPath();g.ellipse(0,-2,r,r*.38,0,Math.PI,TAU);g.stroke();
 g.strokeStyle='#5a6490';g.lineWidth=3;for(let i=0;i<4;i++){const a=i*Math.PI/2+.4;g.beginPath();g.moveTo(0,0);g.lineTo(Math.cos(a)*r,Math.sin(a)*r*.38);g.stroke()}pzEll(g,'#c8d0f0',0,0,r*.16,r*.16,0,2);
 for(let i=0;i<16;i++){const a=i/16*TAU;g.fillStyle=i%3?'rgba(255,230,150,.9)':'rgba(120,240,255,.9)';g.fillRect(Math.cos(a)*r-1,Math.sin(a)*r*.38-1,2.4,2.4)}g.restore()}
/* ---------- the room ---------- */
function pznBakeRoom(g){const fy=596;
 g.fillStyle='#0a0a22';g.fillRect(0,0,1600,900);
 /* ceiling and its long skylight */
 g.fillStyle=pzLin(g,0,0,0,150,[[0,'#151838'],[1,'#0c0e26']]);g.fillRect(0,0,1600,150);
 g.save();g.beginPath();g.rect(0,8,1600,112);g.clip();pznSpaceFill(g,0,8,1600,112,11);g.restore();
 for(let x=-20;x<1640;x+=160){g.fillStyle=pzLin(g,x-10,0,x+10,0,[[0,'#1a1e3a'],[.5,'#4a5278'],[1,'#1a1e3a']]);g.fillRect(x-9,0,18,128);g.strokeStyle=PZ_O;g.lineWidth=3;g.strokeRect(x-9,0,18,128);g.fillStyle='#8a96c8';g.beginPath();g.arc(x,20,2.5,0,TAU);g.arc(x,104,2.5,0,TAU);g.fill()}
 g.fillStyle=pzLin(g,0,118,0,150,[[0,'#2a3058'],[1,'#141830']]);g.fillRect(0,118,1600,32);g.strokeStyle=PZ_O;g.lineWidth=3;g.beginPath();g.moveTo(0,119);g.lineTo(1600,119);g.moveTo(0,150);g.lineTo(1600,150);g.stroke();
 g.fillStyle='#7af8ff';g.fillRect(0,136,1600,3);for(let x=0;x<1600;x+=64)pzGlow(g,x+32,137,40,'rgba(120,240,255,1)',.22);
 /* neon signs in the gaps between the HUD cards: a ringed 8, and a cocktail */
 const neon=(fn,col)=>{g.save();g.lineCap='round';g.lineJoin='round';g.strokeStyle=col.replace('1)','.25)');g.lineWidth=12;fn();g.stroke();g.strokeStyle=col;g.lineWidth=5;fn();g.stroke();g.strokeStyle='rgba(255,255,255,.85)';g.lineWidth=1.6;fn();g.stroke();g.restore()};
 g.fillStyle='rgba(8,6,24,.85)';pzRR(g,476,26,148,84,16);g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();g.fillStyle='rgba(8,6,24,.85)';pzRR(g,976,26,148,84,16);g.fill();g.stroke();
 neon(()=>{g.beginPath();g.arc(550,68,24,0,TAU)},'rgba(255,106,213,1)');neon(()=>{g.beginPath();g.ellipse(550,68,48,12,-.25,Math.PI*1.06,Math.PI*1.94)},'rgba(120,240,255,1)');
 g.save();g.fillStyle='#ffe8ff';g.font='800 30px Poppins,sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillText('8',550,70);g.restore();neon(()=>{g.beginPath();g.ellipse(550,68,48,12,-.25,-Math.PI*.06,Math.PI*1.06)},'rgba(120,240,255,1)');
 neon(()=>{g.beginPath();g.moveTo(1026,46);g.lineTo(1074,46);g.lineTo(1050,74);g.closePath();g.moveTo(1050,74);g.lineTo(1050,94);g.moveTo(1038,96);g.lineTo(1062,96)},'rgba(120,240,255,1)');neon(()=>{g.beginPath();g.arc(1066,44,6,0,TAU)},'rgba(255,194,58,1)');
 neon(()=>{g.beginPath();g.moveTo(1040,52);g.lineTo(1060,52)},'rgba(255,106,213,1)');
 for(const [x,c] of[[550,'rgba(255,106,213,1)'],[1050,'rgba(120,240,255,1)']])pzGlow(g,x,68,110,c,.18);
 /* hull wall: panels with seams, rivets and light strips */
 g.fillStyle=pzLin(g,0,150,0,fy,[[0,'#1a1f48'],[1,'#10132e']]);g.fillRect(0,150,1600,fy-150);
 for(let x=0;x<1600;x+=100){g.fillStyle=pzMix('#1c2250','#232a5c',pzNoise(x*.13));g.fillRect(x+2,152,96,fy-154);g.fillStyle='rgba(0,0,0,.4)';g.fillRect(x+98,150,3,fy-150);g.fillStyle='rgba(160,180,255,.06)';g.fillRect(x+2,150,2,fy-150)}
 for(const y of[300,450]){g.fillStyle='rgba(0,0,0,.35)';g.fillRect(0,y,1600,3);g.fillStyle='rgba(160,180,255,.07)';g.fillRect(0,y+3,1600,2)}
 for(let x=0;x<1600;x+=100)for(const y of[162,288,312,438,462,584]){g.fillStyle='#4a5488';g.beginPath();g.arc(x+12,y,2.2,0,TAU);g.arc(x+88,y,2.2,0,TAU);g.fill()}
 for(const x of[330,1270]){g.fillStyle='#7af8ff';g.fillRect(x-2,170,4,400);pzGlow(g,x,370,220,'rgba(120,240,255,1)',.14)}
 /* the left porthole: a ringed gas giant */
 {const cx=166,cy=338,r=142;g.save();g.beginPath();g.arc(cx,cy,r,0,TAU);g.clip();pznSpaceFill(g,cx-r,cy-r,r*2,r*2,23);pznPlanet(g,cx-34,cy+46,92,-.32);
  g.fillStyle='rgba(180,220,255,.07)';g.beginPath();g.moveTo(cx-r,cy-r*.3);g.lineTo(cx-r*.2,cy-r);g.lineTo(cx+r*.1,cy-r);g.lineTo(cx-r,cy+r*.05);g.closePath();g.fill();g.restore();
  g.lineWidth=26;g.strokeStyle=pzLin(g,cx-r,cy-r,cx+r,cy+r,[[0,'#8a96c8'],[.5,'#3a4470'],[1,'#20264a']]);g.beginPath();g.arc(cx,cy,r+13,0,TAU);g.stroke();
  g.strokeStyle=PZ_O;g.lineWidth=4;g.beginPath();g.arc(cx,cy,r,0,TAU);g.stroke();g.beginPath();g.arc(cx,cy,r+26,0,TAU);g.stroke();
  g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=2;g.beginPath();g.arc(cx,cy,r+20,Math.PI*1.1,Math.PI*1.45);g.stroke();
  for(let i=0;i<12;i++){const a=i/12*TAU;pzEll(g,'#c8d0f0',cx+Math.cos(a)*(r+13),cy+Math.sin(a)*(r+13),3.4,3.4,0,1.4)}
  g.strokeStyle='#ff6ad5';g.lineWidth=2.5;g.beginPath();g.arc(cx,cy,r+31,Math.PI*.15,Math.PI*.85);g.stroke();pzGlow(g,cx,cy+r+30,120,'rgba(255,106,213,1)',.16)}
 /* the right viewport: nebula, a ring station, a moon */
 {const x=1318,y=154,w=266,h=356;g.save();pzRR(g,x,y,w,h,44);g.clip();pznSpaceFill(g,x,y,w,h,41);pznNebula(g,x+w*.6,y+h*.35,170,'rgba(255,90,170,A)',.3);pznNebula(g,x+w*.3,y+h*.75,150,'rgba(90,230,255,A)',.22);
  pznStation(g,x+w*.58,y+h*.36,62);g.fillStyle='#d8d4e8';g.beginPath();g.arc(x+w*.26,y+h*.7,26,0,TAU);g.fill();g.fillStyle='rgba(20,10,40,.55)';g.beginPath();g.arc(x+w*.26+9,y+h*.7+5,24,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2.5;g.beginPath();g.arc(x+w*.26,y+h*.7,26,0,TAU);g.stroke();
  for(const [a,b,c] of[[-8,-6,5],[6,8,3.5],[-12,10,3]]){g.fillStyle='rgba(120,110,150,.6)';g.beginPath();g.arc(x+w*.26+a,y+h*.7+b,c,0,TAU);g.fill()}g.restore();
  g.lineWidth=18;g.strokeStyle=pzLin(g,x,0,x+w,0,[[0,'#3a4470'],[.5,'#8a96c8'],[1,'#3a4470']]);pzRR(g,x-9,y-9,w+18,h+18,52);g.stroke();g.strokeStyle=PZ_O;g.lineWidth=4;pzRR(g,x,y,w,h,44);g.stroke();pzRR(g,x-18,y-18,w+36,h+36,60);g.stroke();
  g.fillStyle='#2a3058';g.fillRect(x+w/2-6,y,12,h);g.strokeStyle=PZ_O;g.lineWidth=2.5;g.strokeRect(x+w/2-6,y,12,h);g.fillStyle='rgba(255,255,255,.05)';g.beginPath();g.moveTo(x+10,y+20);g.lineTo(x+60,y+20);g.lineTo(x+10,y+180);g.closePath();g.fill()}
 /* floor: polished deck plates in perspective, neon seams, reflections */
 g.fillStyle=pzLin(g,0,fy,0,900,[[0,'#181c40'],[1,'#0a0c22']]);g.fillRect(0,fy,1600,900-fy);
 {const vx=800,vy=300;g.strokeStyle='rgba(120,140,220,.16)';g.lineWidth=2;for(let i=-16;i<=16;i++){const bx=vx+i*120;g.beginPath();g.moveTo(vx+(bx-vx)*((fy-vy)/(900-vy)),fy);g.lineTo(bx,900);g.stroke()}
  for(let k=1;k<8;k++){const y=fy+(900-fy)*Math.pow(k/8,1.6);g.strokeStyle=`rgba(120,140,220,${.08+k*.012})`;g.beginPath();g.moveTo(0,y);g.lineTo(1600,y);g.stroke()}}
 g.fillStyle='rgba(0,0,0,.5)';g.fillRect(0,fy-4,1600,6);g.fillStyle='#ff6ad5';g.fillRect(0,fy+2,1600,2.5);for(let x=0;x<1600;x+=80)pzGlow(g,x+40,fy+3,50,'rgba(255,106,213,1)',.12);
 g.fillStyle='rgba(122,248,255,.6)';g.fillRect(0,832,1600,2);
 /* the porthole and viewport glow on the floor */
 pzGlow(g,166,640,160,'rgba(255,170,110,1)',.12);pzGlow(g,1450,640,170,'rgba(255,90,170,1)',.12);
 const v=g.createRadialGradient(800,440,320,800,440,1000);v.addColorStop(0,'rgba(0,0,0,0)');v.addColorStop(1,'rgba(4,2,16,.72)');g.fillStyle=v;g.fillRect(0,0,1600,900)}
/* ---------- the table (exact 96f geometry, its own look) ---------- */
function pznBakeTable(g){const G=PZ_G,{W:w,H:h}=PZ_PHY,rail=G.rail,felt=PZN_FELT;g.save();g.translate(G.x,G.y);
 /* no legs: two hover pods and their light on the floor */
 g.fillStyle='rgba(0,0,0,.45)';g.beginPath();g.ellipse(w/2,h+rail+92,w*.6,46,0,0,TAU);g.fill();
 for(const px of[w*.2,w*.8]){pzGlow(g,px,h+rail+96,150,'rgba(110,236,255,1)',.35);g.fillStyle=pzLin(g,px-50,0,px+50,0,[[0,'#20264a'],[.5,'#5a6490'],[1,'#20264a']]);pzRR(g,px-50,h+rail+30,100,40,18);g.fill();g.strokeStyle=PZ_O;g.lineWidth=3.5;g.stroke();
  g.fillStyle='#7af8ff';pzRR(g,px-36,h+rail+62,72,6,3);g.fill();g.fillStyle='rgba(255,255,255,.3)';g.fillRect(px-40,h+rail+36,80,3)}
 /* apron and the glass ball-return tube */
 g.fillStyle=pzLin(g,0,h+rail-8,0,h+rail+52,[[0,'#3a4268'],[.5,'#232848'],[1,'#141830']]);pzRR(g,-rail-8,h+rail-8,w+rail*2+16,58,14);g.fill();g.strokeStyle=PZ_O;g.lineWidth=4;g.stroke();
 g.fillStyle='#7af8ff';g.fillRect(-rail+6,h+rail+42,w+rail*2-12,2.5);g.fillStyle='rgba(200,220,255,.18)';g.fillRect(-rail,h+rail-6,w+rail*2,2);
 {const ty=G.trayY-G.y,x0=G.trayX0-G.x,x1=G.trayX1-G.x;g.fillStyle='#070818';pzRR(g,x0-14,ty-15,x1-x0+28,30,15);g.fill();g.fillStyle=pzLin(g,0,ty-13,0,ty+13,[[0,'#0c1030'],[1,'#1c2a50']]);pzRR(g,x0-10,ty-12,x1-x0+20,24,12);g.fill();
  g.strokeStyle='#7af8ff';g.lineWidth=2.5;pzRR(g,x0-14,ty-15,x1-x0+28,30,15);g.stroke();g.strokeStyle='rgba(255,255,255,.45)';g.lineWidth=1.6;g.beginPath();g.moveTo(x0,ty-10);g.lineTo(x1,ty-10);g.stroke();
  g.fillStyle='#04040e';g.beginPath();g.ellipse(x1+20,ty,11,16,0,0,TAU);g.fill();g.strokeStyle='#ff6ad5';g.lineWidth=3;g.stroke()}
 /* gunmetal rails with a chrome bevel */
 const metal=pzLin(g,0,-rail,0,h+rail,[[0,'#5a6488'],[.18,'#3a4268'],[.5,'#262c4c'],[.82,'#3a4268'],[1,'#20243e']]);
 g.fillStyle=metal;pzRR(g,-rail,-rail,w+rail*2,h+rail*2,30);g.fill();g.strokeStyle=PZ_O;g.lineWidth=5;g.stroke();
 g.strokeStyle='rgba(220,230,255,.42)';g.lineWidth=2.4;pzRR(g,-rail+4,-rail+4,w+rail*2-8,h+rail*2-8,26);g.stroke();
 g.strokeStyle='rgba(0,0,0,.35)';g.lineWidth=2;pzRR(g,-rail+9,-rail+9,w+rail*2-18,h+rail*2-18,22);g.stroke();
 g.fillStyle=pzLin(g,0,-rail,0,-rail+16,[[0,'rgba(220,235,255,.36)'],[1,'rgba(220,235,255,0)']]);g.fillRect(-rail+24,-rail+5,w+rail*2-48,16);
 for(let i=0;i<9;i++){const x=-rail+40+i*((w+rail*2-80)/8);g.fillStyle='rgba(255,255,255,.08)';g.beginPath();g.moveTo(x,-rail+6);g.lineTo(x+26,-rail+6);g.lineTo(x+10,-rail+30);g.lineTo(x-16,-rail+30);g.closePath();g.fill()}
 /* the cyan inlay round the playing surface */
 g.strokeStyle='rgba(120,240,255,.25)';g.lineWidth=9;pzRR(g,-31,-31,w+62,h+62,14);g.stroke();g.strokeStyle='#7af8ff';g.lineWidth=2.6;pzRR(g,-31,-31,w+62,h+62,14);g.stroke();
 /* LED sights */
 const led=(x,y)=>{pzGlow(g,x,y,13,'rgba(140,250,255,1)',.75);g.fillStyle='#e8ffff';g.beginPath();g.arc(x,y,2.6,0,TAU);g.fill();g.strokeStyle='rgba(18,8,31,.8)';g.lineWidth=1.2;g.stroke()};
 for(let i=1;i<8;i++){if(i===4)continue;led(w*i/8,-rail/2-5);led(w*i/8,h+rail/2+5)}for(let i=1;i<4;i++){led(-rail/2-5,h*i/4);led(w+rail/2+5,h*i/4)}
 /* cushions and cloth, traced from the physics edges */
 const L=pzLoop();g.fillStyle=pzMix(felt.c,'#000000',.2);pzRR(g,-24,-24,w+48,h+48,10);g.fill();
 const loop=()=>{g.beginPath();L.forEach(([x,y],i)=>i?g.lineTo(x,y):g.moveTo(x,y));g.closePath()};
 g.save();g.beginPath();g.rect(-24,-24,w+48,h+48);L.forEach(([x,y],i)=>i?g.lineTo(x,y):g.moveTo(x,y));g.closePath();g.clip('evenodd');g.lineJoin='round';
 for(const [lw,k] of[[56,0],[40,.1],[28,.18],[18,.26],[9,.34]]){g.strokeStyle=pzMix(pzMix(felt.c,'#000000',.2),felt.a,k);g.lineWidth=lw;loop();g.stroke()}g.restore();
 g.save();loop();g.clip();
 g.fillStyle=pzLin(g,0,0,0,h,[[0,felt.a],[1,felt.b]]);g.fillRect(-30,-30,w+60,h+60);
 /* a faint hex weave */
 g.strokeStyle='rgba(255,255,255,.035)';g.lineWidth=1;for(let row=0;row<16;row++)for(let col=0;col<34;col++){const hx=col*28+(row%2)*14,hy=row*29;g.beginPath();for(let k=0;k<6;k++){const a=k/6*TAU+Math.PI/6;g.lineTo(hx+Math.cos(a)*15,hy+Math.sin(a)*15)}g.closePath();g.stroke()}
 {const tl=pzCv(96,96),tx=tl.getContext('2d'),im=tx.createImageData(96,96);for(let i=0;i<96*96;i++){const n=pzNoise(i*1.7+9),v=n>.5?255:0,a=Math.abs(n-.5)*.14;im.data[i*4]=v;im.data[i*4+1]=v;im.data[i*4+2]=v;im.data[i*4+3]=a*255}tx.putImageData(im,0,0);g.fillStyle=g.createPattern(tl,'repeat');g.fillRect(-30,-30,w+60,h+60)}
 /* the Orbit 8 ring in the kitchen */
 g.save();g.translate(w*.115,h/2);g.rotate(-Math.PI/2);g.globalAlpha=.13;g.strokeStyle='#e8f8ff';g.lineWidth=3;g.beginPath();g.ellipse(0,0,64,16,-.2,0,TAU);g.stroke();g.fillStyle='#e8f8ff';g.font='800 36px Poppins,sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillText('8',0,2);
 g.font='400 22px "Pirata One",Georgia,serif';g.fillText('ORBIT EIGHT',0,40);g.restore();
 g.strokeStyle='rgba(255,255,255,.14)';g.lineWidth=2;g.setLineDash([7,9]);g.beginPath();g.moveTo(w/4,8);g.lineTo(w/4,h-8);g.stroke();g.setLineDash([]);
 for(const sx of[w/4,w*3/4]){g.fillStyle='rgba(255,255,255,.34)';g.beginPath();g.arc(sx,h/2,3.2,0,TAU);g.fill()}
 /* the halo's cool light pool */
 const lp=g.createRadialGradient(w/2,h*.46,30,w/2,h*.46,w*.66);lp.addColorStop(0,'rgba(220,245,255,.2)');lp.addColorStop(.55,'rgba(180,220,255,.05)');lp.addColorStop(1,'rgba(0,0,20,.32)');g.fillStyle=lp;g.fillRect(-30,-30,w+60,h+60);
 g.lineJoin='round';for(const [lw,al] of[[30,.06],[20,.09],[11,.13],[5,.18]]){g.strokeStyle=`rgba(0,0,10,${al})`;g.lineWidth=lw;loop();g.stroke()}
 g.restore();
 g.save();g.lineCap='round';const rails=PZ_TBL.S.filter(s=>s[0]===s[2]||s[1]===s[3]);for(const [a,b,c,d] of rails){g.strokeStyle='rgba(0,0,0,.5)';g.lineWidth=3;g.beginPath();g.moveTo(a,b);g.lineTo(c,d);g.stroke();g.strokeStyle='#bff8ff';g.globalAlpha=.5;g.lineWidth=1.3;g.beginPath();g.moveTo(a+(a===c?(a<w/2?1.5:-1.5):0),b+(b===d?(b<h/2?1.5:-1.5):0));g.lineTo(c+(a===c?(a<w/2?1.5:-1.5):0),d+(b===d?(b<h/2?1.5:-1.5):0));g.stroke();g.globalAlpha=1}g.restore();
 /* pockets: a chrome ring, a magenta neon ring and a swirling gravity well */
 for(const [px,py,hr,rr] of PZ_POCK){g.fillStyle='#0a0a1e';g.beginPath();g.arc(px,py+3,rr+4,0,TAU);g.fill();
  g.fillStyle=pzLin(g,px-rr,py-rr,px+rr,py+rr,[[0,'#f0f4ff'],[.45,'#8a96c0'],[1,'#3a4268']]);g.beginPath();g.arc(px,py,rr,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();
  pzGlow(g,px,py,rr+16,'rgba(255,106,213,1)',.35);g.strokeStyle='#ff6ad5';g.lineWidth=3;g.beginPath();g.arc(px,py,hr+5,0,TAU);g.stroke();
  const q=g.createRadialGradient(px,py,2,px,py,hr+2);q.addColorStop(0,'#000');q.addColorStop(.7,'#06041a');q.addColorStop(1,'#2a1458');g.fillStyle=q;g.beginPath();g.arc(px,py,hr+2,0,TAU);g.fill();
  g.strokeStyle='rgba(190,140,255,.35)';g.lineWidth=1.4;for(let k=0;k<3;k++){g.beginPath();for(let s=0;s<=20;s++){const a=k*TAU/3+s*.32,r=hr*(1-s/22);g.lineTo(px+Math.cos(a)*r,py+Math.sin(a)*r)}g.stroke()}
  g.strokeStyle='rgba(255,255,255,.55)';g.lineWidth=1.6;g.beginPath();g.arc(px,py,rr-4,Math.PI*1.05,Math.PI*1.55);g.stroke()}
 for(const [sx,sy] of[[-30,34],[34,-30],[w+30,34],[w-34,-30],[-30,h-34],[34,h+30],[w+30,h-34],[w-34,h+30]]){g.fillStyle='#c8d0f0';g.beginPath();g.arc(sx,sy,3.4,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=1.4;g.stroke()}
 g.restore()}
function pznBake(){if(PZN.bk)return PZN.bk;const c=pzCv(1600,900),g=c.getContext('2d');g.lineJoin='round';g.lineCap='round';pznBakeRoom(g);pznBakeTable(g);pzGlow(g,PZ_G.lampX,PZ_G.y+PZ_PHY.H*.5,470,'rgba(190,230,255,1)',.08);return PZN.bk=c}
/* ---------- per frame ---------- */
let PZN_HALO=null;
function pznHaloBake(){if(PZN_HALO)return PZN_HALO;const c=pzCv(340,120),g=c.getContext('2d');g.translate(170,52);g.lineJoin='round';
 g.fillStyle=pzLin(g,-150,0,150,0,[[0,'#2a3058'],[.3,'#8a96c8'],[.5,'#e8eeff'],[.7,'#8a96c8'],[1,'#2a3058']]);g.beginPath();g.ellipse(0,0,150,30,0,0,TAU);g.ellipse(0,2,118,18,0,0,TAU);g.fill('evenodd');g.strokeStyle=PZ_O;g.lineWidth=4;g.beginPath();g.ellipse(0,0,150,30,0,0,TAU);g.stroke();g.beginPath();g.ellipse(0,2,118,18,0,0,TAU);g.stroke();
 g.strokeStyle='#bff8ff';g.lineWidth=4;g.beginPath();g.ellipse(0,6,132,22,0,.1,Math.PI-.1);g.stroke();pzGlow(g,0,26,120,'rgba(190,245,255,1)',.55);
 g.fillStyle='#3a4470';for(const s of[-1,1]){pzRR(g,s*150-8,-10,16,20,5);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2.5;g.stroke()}return PZN_HALO=c}
function pznDrawHalo(g,t){const rm=pzRM(),by=rm?0:Math.sin(t*1.1)*3,x=PZ_G.lampX,y=PZ_G.lampY-16+by;g.drawImage(pznHaloBake(),x-170,y-52);
 if(!rm&&!PZ.lite)for(let i=0;i<10;i++){const a=t*.9+i*TAU/10,sx=x+Math.cos(a)*134,sy=y+6+Math.sin(a)*24;if(Math.sin(a)<-.1)continue;g.globalAlpha=.55+.45*Math.sin(t*4+i);g.fillStyle=i%2?'#ff9ae8':'#e8ffff';g.fillRect(sx-2,sy-2,4,4)}g.globalAlpha=1}
const PZN_TW=[[60,40],[240,90],[700,30],[1180,60],[1420,24],[1530,96],[96,260],[230,410],[1360,200],[1540,300],[1460,450],[890,96]];
function pznDrawAmb(g,t){if(pzRM())return;
 for(let i=0;i<PZN_TW.length;i++){const [x,y]=PZN_TW[i],a=Math.max(0,Math.sin(t*1.3+i*2.1));if(a<.2)continue;g.globalAlpha=a*.85;g.drawImage(pzGlowS('rgba(220,235,255,1)'),x-9,y-9,18,18);g.fillStyle='#fff';g.fillRect(x-1,y-1,2,2)}g.globalAlpha=1;
 /* a shuttle crosses the viewport every 26 s */
 {const ph=(t%26)/7;if(ph<1){const x=1300+ph*300,y=300-ph*60;g.save();g.beginPath();pzRR(g,1318,154,266,356,44);g.clip();g.translate(x,y);g.rotate(-.2);g.fillStyle='#c8d0f0';g.beginPath();g.moveTo(14,0);g.lineTo(-10,-6);g.lineTo(-14,0);g.lineTo(-10,6);g.closePath();g.fill();pzGlow(g,-16,0,14,'rgba(255,180,90,1)',.9);g.restore()}}
 /* neon sign flicker */
 {const ph=t%11;if(ph<.18&&ph%.06<.03){g.fillStyle='rgba(8,6,24,.7)';g.fillRect(500,38,100,64)}}
 /* hover pods */
 {const f=.6+.4*Math.sin(t*17)*Math.sin(t*5.1),y=PZ_G.y+PZ_PHY.H+PZ_G.rail+66;for(const px of[.2,.8])pzGlow(g,PZ_G.x+PZ_PHY.W*px,y,46,'rgba(140,250,255,1)',.35*f)}}
function pznDrawMotes(g,t){if(pzRM())return;g.save();g.globalCompositeOperation='lighter';for(let i=0;i<16;i++){const ph=(t*.02+i*.0625)%1,x=PZ_G.lampX-300+((i*157)%600)+Math.sin(t*.5+i)*20,y=700-ph*560,a=Math.sin(ph*Math.PI)*.22;g.fillStyle=i%3?`rgba(160,240,255,${a})`:`rgba(255,160,230,${a})`;g.beginPath();g.arc(x,y,1.4+(i%3)*.6,0,TAU);g.fill()}g.restore()}
{const f0=pzDrawLamp;pzDrawLamp=function(g,t){if(PZ.pzn)return pznDrawHalo(g,t);return f0.apply(this,arguments)}}
{const f0=pzDrawLights;pzDrawLights=function(g,t){if(PZ.pzn)return pznDrawAmb(g,t);return f0.apply(this,arguments)}}
{const f0=pzDrawDust;pzDrawDust=function(g,t){if(PZ.pzn)return pznDrawMotes(g,t);return f0.apply(this,arguments)}}
/* mount: the Orbit 8 room and table for its players (practice included) */
{const f0=pzMount;pzMount=function(R){PZ.pzn=!!(R&&pznIs(R.id));PZ.pznFx=[];const r=f0.apply(this,arguments);try{if(PZ.pzn){PZ.bk=pznBake();const m=$('pzm');if(m)m.classList.add('pzn8m')}}catch(e){console.error(e)}return r}}
/* head-and-shoulders framing (HUD cards, the hub medallions, the regulars' cards): [top, bottom, x shift] in monster units */
Object.assign(PZ97_BUST,{bleep:[-312,-110,0],octavia:[-362,-150,0],facet:[-390,-170,0],rex:[-372,-150,6],vantara:[-420,-200,0]});
{const f0=pzCastPortrait;pzCastPortrait=function(g,who,id,size,t,ex){if(who!=='hero'&&pznIs(id)){g.save();g.clearRect(0,0,size,size);try{pz97Bust(g,id,size,ex||pzCastEx(),t||1)}catch(e){}g.restore();return}return f0.apply(this,arguments)}}
/* ---------- shot flair: each Orbit 8 player strikes in their own way ---------- */
function pznShotFx(){const R=PZ.reg,c=PZ.B[0],s=PZ.shot;if(!R||!c||pzRM())return;const x=PZ_G.x+c.x-Math.cos(s.ang)*12,y=PZ_G.y+c.y-Math.sin(s.ang)*12,bx=PZ_G.x+c.x-Math.cos(s.ang)*240,by=PZ_G.y+c.y-Math.sin(s.ang)*240;
 if(R.id==='bleep'){pzSpecks(x,y,8,'#7af8ff');pzFx('key')}
 else if(R.id==='octavia'){pzPuff(x,y,6,'rgba(90,20,110,.75)',60);for(let i=0;i<3;i++)PZ.pznFx.push({k:'note',x:bx+(Math.random()-.5)*40,y:by-20,t:0,d:1.1,c:['#ffd45a','#ff9ad8','#8ef0ff'][i]})}
 else if(R.id==='facet'){pzSpecks(x,y,10,'#e8ffff');PZ.pznFx.push({k:'prism',x,y,a:s.ang,t:0,d:.5})}
 else if(R.id==='rex'){pzPuff(bx,by,8,'rgba(255,150,60,.8)',120);PZ.pznFx.push({k:'flame',x:bx,y:by,a:s.ang,t:0,d:.45})}
 else if(R.id==='vantara'){PZ.pznFx.push({k:'ring',x:PZ_G.x+c.x,y:PZ_G.y+c.y,t:0,d:.7})}}
{const f0=pzContact;pzContact=function(){const r=f0.apply(this,arguments);try{if(PZ.pzn&&PZ.shotAi)pznShotFx()}catch(e){}return r}}
{const f0=pzFxDraw;pzFxDraw=function(g){const r=f0.apply(this,arguments);try{const L=PZ.pzn&&PZ.pznFx;if(L&&L.length){const dt=Math.min(.05,Math.max(0,(PZ.t||0)-(PZ.pznFxT||0)));PZ.pznFxT=PZ.t;
  for(let i=L.length-1;i>=0;i--){const f=L[i];f.t+=dt;if(f.t>=f.d){L.splice(i,1);continue}const u=f.t/f.d;g.save();
   if(f.k==='note'){g.globalAlpha=Math.sin(u*Math.PI);g.fillStyle=f.c;g.font='400 30px "Pirata One",serif';g.textAlign='center';g.fillText('♪',f.x+Math.sin(u*9)*10,f.y-u*70)}
   else if(f.k==='prism'){g.globalCompositeOperation='lighter';g.translate(f.x,f.y);g.rotate(f.a+Math.PI);const cols=['rgba(255,80,80,','rgba(255,200,60,','rgba(80,255,140,','rgba(80,170,255,','rgba(200,90,255,'];cols.forEach((c,k)=>{g.strokeStyle=c+((1-u)*.55)+')';g.lineWidth=3;g.beginPath();g.moveTo(0,0);g.lineTo(60+u*80,(k-2)*(6+u*14));g.stroke()})}
   else if(f.k==='flame'){g.globalAlpha=1-u;pzGlow(g,f.x,f.y,40+u*30,'rgba(255,150,50,1)',.8)}
   else if(f.k==='ring'){g.strokeStyle=`rgba(190,140,255,${(1-u)*.8})`;g.lineWidth=4*(1-u)+1;g.beginPath();g.arc(f.x,f.y,14+u*90,0,TAU);g.stroke();g.strokeStyle=`rgba(255,220,180,${(1-u)*.5})`;g.lineWidth=2;g.beginPath();g.arc(f.x,f.y,8+u*50,0,TAU);g.stroke()}
   g.restore()}}}catch(e){}return r}}
/* reactions the tavern does not use: they think while they line up, and a double pot or a bank from you gets a "wow" */
{const f0=pzAiBegin;pzAiBegin=function(){const r=f0.apply(this,arguments);try{if(PZ.pzn&&PZ.ai&&!PZ.st.brk)pzCastReact('mon','think',Math.round(PZ.ai.dur*520))}catch(e){}return r}}
{const f0=pzJudgeShot;pzJudgeShot=function(silent){let who=-1,n=0,bank=false;try{if(PZ.pzn&&!silent&&PZ.st){who=PZ.st.turn;const ev=PZ.ev||[];const pk=ev.filter(e=>e.t==='pk'&&e.a>0).map(e=>e.a);n=pk.length;bank=ev.some(e=>e.t==='cu'&&!e.j&&pk.includes(e.a))}}catch(e){}
 const r=f0.apply(this,arguments);try{if(who===0&&(n>=2||bank)&&PZ.st&&!PZ.st.over&&PZ.st.turn===0)pzCastReact('mon','wow',1500)}catch(e){}return r}}
/* ---------- the VS intro: each one makes an entrance ---------- */
let PZN_STREAK=null;
function pznStreakBake(){if(PZN_STREAK)return PZN_STREAK;const c=pzCv(1600,900),g=c.getContext('2d');for(let i=0;i<140;i++){const x=pzNoise(i*2.3)*1600,y=pzNoise(i*4.1+3)*900,l=30+pzNoise(i*7.7)*160,a=.15+pzNoise(i*1.1)*.5;const q=g.createLinearGradient(x,0,x+l,0);q.addColorStop(0,'rgba(200,230,255,0)');q.addColorStop(1,`rgba(200,230,255,${a})`);g.fillStyle=q;g.fillRect(x,y,l,1.6+(i%3)*.6)}return PZN_STREAK=c}
function pznEntrance(g,id,t,u,fit){/* u: 0..1 entrance progress; draws the figure on a 320 x 400 canvas */
 const e=1-Math.pow(1-u,3),ex=Object.assign(pzCastEx(),PZ_EXP[u<1?'wow':'smug']);let x=fit.x,y=fit.y,s=fit.s,rot=0,al=1;
 if(id==='bleep'){x+=(1-e)*260;rot=(1-e)*-.5;y-=Math.abs(Math.sin(u*Math.PI*3))*(1-u)*40}
 else if(id==='octavia'){y-=(1-e)*360;if(u<.85){g.save();g.globalAlpha=.6;g.strokeStyle='rgba(200,250,255,.9)';g.lineWidth=4;g.beginPath();g.arc(fit.x,y-150*s,170*s,0,TAU);g.stroke();g.restore()}else if(u<1){for(let i=0;i<10;i++){const a=i/10*TAU,r=(u-.85)/.15*90;g.fillStyle='rgba(200,250,255,.8)';g.beginPath();g.arc(fit.x+Math.cos(a)*(80+r),fit.y-150*s+Math.sin(a)*(80+r),4,0,TAU);g.fill()}}}
 else if(id==='facet'){al=pznCl(u*1.6-.3);if(u<1)for(let i=0;i<12;i++){const a=i*2.4,r=(1-e)*220;g.fillStyle=i%2?'#c8f6ff':'#e8d8ff';g.save();g.translate(fit.x+Math.cos(a)*r,fit.y-170*s+Math.sin(a)*r*.7);g.rotate(a+u*6);g.beginPath();g.moveTo(0,-12);g.lineTo(6,0);g.lineTo(0,12);g.lineTo(-6,0);g.closePath();g.fill();g.strokeStyle=PZ_O;g.lineWidth=2;g.stroke();g.restore()}}
 else if(id==='rex'){x+=(1-e)*200;y-=(1-e)*300;rot=(1-e)*.4;ex.mo=1;ex.ma=.9;if(u<1){g.save();g.globalCompositeOperation='lighter';for(let i=0;i<8;i++){const k=i/8,px=x+k*90*(1-e)+30,py=y-60*s+k*140*(1-e);g.globalAlpha=(1-k)*.5;g.drawImage(pzGlowS('rgba(255,150,50,1)'),px-30,py-30,60,60)}g.restore()}}
 else if(id==='vantara'){s*=Math.max(.05,e);rot=(1-e)*-3;g.save();g.strokeStyle=`rgba(190,140,255,${(1-u)*.9})`;g.lineWidth=5;for(let k=0;k<3;k++){g.beginPath();g.ellipse(fit.x,fit.y-200*fit.s,(60+k*40)*(1-e*.6),(16+k*10)*(1-e*.6),-.2+u*4+k,0,TAU);g.stroke()}g.restore()}
 g.save();g.globalAlpha=al;g.translate(x,y);g.rotate(rot);g.scale(s,s);pzMon[id](g,t,ex,{breath:Math.sin(t*2.2)*.012,tilt:0,bob:0,hop:0});g.restore()}
{const f0=pzIntro;pzIntro=function(R,cb){const r=f0.apply(this,arguments);try{if(R&&pznIs(R.id)){const el=$('pzintro'),old=$('pzvo');if(el&&old){el.classList.add('pznvs');
  const sk=pzCv(1600,900);sk.className='pznstk';sk.getContext('2d').drawImage(pznStreakBake(),0,0);el.prepend(sk);
  const cv=pzCv(320,400);cv.id='pzvo';cv.className=old.className;old.replaceWith(cv);const g=cv.getContext('2d');g.lineJoin='round';g.lineCap='round';const fit=pzMonFit(R.id,320,400,10),t0=performance.now()/1000;
  {const b=document.createElement('div');b.className='pznvsq';b.style.setProperty('--c',R.c);b.textContent=`“${R.lines.hi[0]}”`;el.appendChild(b)}
  const f=()=>{if(!cv.isConnected)return;const t=performance.now()/1000,u=pzRM()?1:Math.min(1,(t-t0-.15)/.9);g.clearRect(0,0,320,400);pznEntrance(g,R.id,t,Math.max(0,u),fit)};f();LIVE.push({cv,fn:f,ph:0})}}}catch(e){console.error(e)}return r}}
/* ---------- a synth lounge groove for Orbit 8 (D dorian, slow four on the floor) ---------- */
const PZN_CH=[[50,'m7'],[50,'m7'],[55,'7'],[55,'7'],[48,'M7'],[48,'M7'],[57,'m7'],[57,'m7'],[50,'m7'],[52,'m7'],[53,'M7'],[55,'7'],[58,'M7'],[57,'m7'],[55,'7'],[57,'7']];
const PZN_ARP=[0,2,1,3,2,1,3,2];
function pznScore(t,n0){if(!PZN.ms){PZN.ms=1;PZN.n0=n0}KS.on=0;const n=n0-PZN.n0,bar=(n>>3)&15,k=n&7,sd=stepD();if(k===0)PZM.lv=pzLevel();const lv=PZM.lv,B=pzBus(lv),[root,q]=PZN_CH[bar],ch=PZ_Q[q];
 if(k%2===0)wcv(t,mf(root-24+(k===4?7:0)),sd*1.6,{w:'sawtooth',lp:lv===2?420:560,v:lv?.07:.055,a:.01,r:.12,bus:B.pc});
 if(lv>0){if(k===0||k===4)wcKick(t,.2,B.pc);if(k===2||k===6)kns(t,.05,.05,8000,'highpass',B.pc)}else if(k===0)wcKick(t,.1,B.pc);
 if(k%2===1)kns(t,.025,lv?.03:.02,9500,'highpass',B.pc);
 /* the glassy arpeggio */
 {const i=PZN_ARP[k],nt=root+12+ch[i]+(k>=4&&bar%4===3?12:0);wcv(t,mf(nt),sd*.9,{w:'triangle',lp:lv?3200:2400,v:lv?.02:.016,a:.004,r:.25,bus:B.st,det:6});if(k%4===0)wcv(t,mf(nt+12),sd*.6,{w:'sine',lp:4000,v:.008,a:.003,r:.3,bus:B.br})}
 /* a warm pad on each bar */
 if(k===0)for(const i of ch.slice(1))wcv(t,mf(root+i),sd*7.6,{w:'sawtooth',lp:900,v:.008,a:.4,r:.6,bus:B.st,det:(i%3-1)*9})}
{const n0=note;note=function(t,n){if(pzMusic()&&pznVenueNow())return pznScore(t,n);if(PZN.ms)PZN.ms=0;return n0(t,n)}}
/* robots and crystals talk in their own blips */
{const f0=pzVoice;pzVoice=function(o){const R=PZ_REG[o&&o.id];if(R&&R.voice&&R.voice.robot){try{const t0=pzT(),n=Math.min(14,Math.ceil((o.n||8)/2));for(let i=0;i<n;i++){const t=t0+i*.06;wcv(t,R.voice.f*(i%3===0?1.5:1)*(.9+Math.random()*.25),.035,{w:'square',v:.022,a:.002,r:.03,bus:sg,lp:4200})}}catch(e){}return}return f0.apply(this,arguments)}}
{const st=document.createElement('style');st.textContent=`
.pzintro.pznvs{background:radial-gradient(ellipse at 50% 45%,#2a1a6aee,#07051cf6 70%)}
.pzintro.pznvs .pznstk{position:absolute;left:0;top:0;width:1600px;height:900px;opacity:.7;animation:pznstk 1.4s linear infinite;pointer-events:none}
@keyframes pznstk{from{transform:translateX(0)}to{transform:translateX(-260px)}}
.pzintro.pznvs .pzvr b{text-shadow:0 0 0 #000,0 3px 0 #12081f}
.pznvsq{position:absolute;left:1060px;top:722px;margin-left:-170px;width:340px;box-sizing:border-box;padding:8px 12px;border-radius:14px;background:#fff8ee;border:3px solid #12081f;color:#2a1a3a;font:700 italic 13px/1.35 Poppins,sans-serif;text-align:center;box-shadow:0 6px 0 #0007;animation:pzpopIn .45s .9s cubic-bezier(.25,1.6,.45,1) both}
.pzintro.pznvs.out .pznstk{animation:none}
`;document.head.appendChild(st)}
