/* ===== 10.7 THE CROOKED CUE: The Gilded Hoard, the cast (97bc) =====
   Five drawers in the 96g / 97b2 convention: pzMon[id](g,t,ex,p), origin at the bottom centre (up is negative), `ex` the live
   expression springs (eo eyes open, lx/ly look, br brow, bh brow height, mo mouth curve, ma mouth open, bl blush, sw sweat) and `p`
   the pose (breath, tilt, bob, hop). Every reaction is read from the springs through pzdcMood(ex) (cheer, sad, angry, rattled, wow),
   so each blends in and out and also works on the hub, the results and the VS intro, where there is no match state.
     Clasp     a mimic treasure chest, the vault's doorman: the lid is his mouth (teeth, a long tongue), eyes glow in the dark inside,
               a bellhop cap, stubby claw feet; coins spill when he laughs, the lid snaps when angry, the cap flies off on a wow.
               Idle: his tongue licks the rim every few seconds and a foot taps.
     Zephyra   a smoke genie dealer rising from a brass lamp: a teal-to-violet smoke tail that curls and drifts, a jewelled headband,
               gold bangles; she shuffles glowing cards from hand to hand (fanned up on a cheer, spilled when rattled); smoke puffs
               in the mood's colour on every reaction.
     Brass     Sir Brassknuckle, a clockwork brass golem bouncer: riveted plates, a furnace grate chest with flickering coals,
               a wind-up key turning in his back, steam from the shoulder pipes (a whistle burst every 8 s, constant when angry),
               a tiny bow tie, gauge eyes whose needles read the mood (spinning on a wow).
     Hornsby   Baron Hornsby, a minotaur high roller: gold-capped horns, a crimson velvet smoking jacket, a monocle on a chain
               (it drops on a wow), a gold nose ring, a gold-topped cane; he riffles a stack of chips; snorts steam when angry.
     Aurelion  the Hoardwing, an ancient gold dragon banker (boss): a tail curled round a hoard of coins and gems (baked once),
               folded wings, a long neck, a small crown, half-moon spectacles, smoke from the nostrils, an open ledger whose page
               turns every few seconds; fire breath on a cheer, glowing eyes when angry.
   Gradients are cached per context (pzGr/pzGrR keys pzdc*); the coin hoard is baked once. No shadowBlur, no ctx.filter. */
const pzdcCl=x=>x<0?0:x>1?1:x;
function pzdcMood(ex){return{ch:pzdcCl((ex.mo-.4)*1.6)*pzdcCl(ex.ma*1.5),sad:pzdcCl((-ex.mo-.3)*1.6),ang:pzdcCl((ex.br-.4)*1.8),rat:pzdcCl(ex.sw),wow:pzdcCl((ex.eo-1.02)*5)}}
/* a gold coin seen at an angle (k = 0..1 how much of its face shows) */
function pzdcCoin(g,x,y,r,k,lw){k=Math.max(.12,k);g.fillStyle='#b8780e';g.beginPath();g.ellipse(x,y+r*.18,r,r*k,0,0,TAU);g.fill();g.fillStyle='#ffd24a';g.strokeStyle=PZ_O;g.lineWidth=lw||2.4;g.beginPath();g.ellipse(x,y,r,r*k,0,0,TAU);g.fill();g.stroke();
 if(k>.3){g.strokeStyle='#c8860e';g.lineWidth=1.4;g.beginPath();g.ellipse(x,y,r*.62,r*k*.62,0,0,TAU);g.stroke();g.fillStyle='rgba(255,255,230,.8)';g.beginPath();g.ellipse(x-r*.35,y-r*k*.35,r*.22,r*k*.16,-.5,0,TAU);g.fill()}}
/* a cut gem: a coloured lozenge with a light facet */
function pzdcGem(g,x,y,r,col,lw){g.fillStyle=col;g.strokeStyle=PZ_O;g.lineWidth=lw||2.2;g.beginPath();g.moveTo(x,y-r);g.lineTo(x+r*.85,y-r*.15);g.lineTo(x,y+r);g.lineTo(x-r*.85,y-r*.15);g.closePath();g.fill();g.stroke();
 g.fillStyle='rgba(255,255,255,.7)';g.beginPath();g.moveTo(x,y-r*.8);g.lineTo(x+r*.45,y-r*.15);g.lineTo(x,y-r*.05);g.lineTo(x-r*.45,y-r*.15);g.closePath();g.fill()}
/* a soft smoke / steam puff of three discs */
function pzdcPuff(g,x,y,r,col,a){if(a<=.01)return;g.globalAlpha=a;g.fillStyle=col;g.beginPath();g.arc(x,y,r,0,TAU);g.arc(x-r*.7,y+r*.25,r*.7,0,TAU);g.arc(x+r*.72,y+r*.2,r*.66,0,TAU);g.fill();g.globalAlpha=1}
/* a four-point sparkle */
const pzdcStar=(g,x,y,r)=>{g.beginPath();g.moveTo(x,y-r);g.quadraticCurveTo(x,y,x+r,y);g.quadraticCurveTo(x,y,x,y+r);g.quadraticCurveTo(x,y,x-r,y);g.quadraticCurveTo(x,y,x,y-r);g.fill()};
/* rivets along a line */
function pzdcRiv(g,x0,y0,x1,y1,n,r){for(let i=0;i<n;i++){const u=n>1?i/(n-1):.5,x=x0+(x1-x0)*u,y=y0+(y1-y0)*u;g.fillStyle='#7a4a12';g.beginPath();g.arc(x,y+.8,r,0,TAU);g.fill();g.fillStyle='#ffe7a0';g.beginPath();g.arc(x-.4,y-.4,r*.75,0,TAU);g.fill()}}

/* static parts are baked once at 2x into small canvases (shared by every context) and drawn with drawImage */
const PZDC_BK={};
function pzdcBk(g,key,x,y,w,h,fn){let c=PZDC_BK[key];if(!c){const S=2;c=pzCv(Math.ceil(w*S),Math.ceil(h*S));const b=c.getContext('2d');b.scale(S,S);b.translate(-x,-y);b.lineJoin='round';b.lineCap='round';fn(b);PZDC_BK[key]=c}g.drawImage(c,x,y,w,h)}
/* ================= Clasp: the mimic chest doorman ================= */
pzMon.clasp=function(g,t,ex,p){const M=pzdcMood(ex),W=114,by=-38,ty=-148;g.save();g.scale(1.12,1.12);
 const shk=M.rat>.04?Math.sin(t*47)*3.2*M.rat:0,bnc=Math.abs(Math.sin(t*2.3))*3.5*(1-M.sad)*(1-M.ang*.6)+M.ch*Math.abs(Math.sin(t*9))*6;
 pzEll(g,'rgba(0,0,0,.3)',0,2,132,12,0,0);
 /* coins on the floor */
 pzdcBk(g,'cfloor',-150,-24,300,36,g=>{pzdcCoin(g,-128,-6,11,.42,2);pzdcCoin(g,-112,-3,10,.38,2);pzdcCoin(g,124,-5,11,.4,2)});
 /* stubby claw feet: the back pair darker; the front right one taps */
 const tap=M.ch<.3&&M.ang<.3?Math.max(0,Math.sin(t*5))*((t%4)<1.6?1:0)*7:0;
 const foot=(x,lift,back)=>{g.save();g.translate(x,-lift);pzdcBk(g,back?'cfootb':'cfootf',-24,-50,48,56,g=>{pzBlob(g,back?'#4a2a14':'#7a4420',()=>{g.roundRect(-14,-44,28,36,10)},3.2);
  pzBlob(g,back?'#a8781c':'#f0b830',()=>{g.moveTo(-20,-6);g.quadraticCurveTo(-20,-16,0,-16);g.quadraticCurveTo(20,-16,20,-6);g.quadraticCurveTo(14,2,0,1);g.quadraticCurveTo(-14,2,-20,-6)},3);
  g.strokeStyle=PZ_O;g.lineWidth=2;g.beginPath();g.moveTo(-7,-10);g.lineTo(-7,-2);g.moveTo(7,-10);g.lineTo(7,-2);g.stroke()});g.restore()};
 foot(-54,0,1);foot(54,0,1);foot(-88,0,0);foot(88,tap,0);
 g.save();g.translate(shk,-bnc);g.scale(1,1+p.breath);
 /* how wide the lid gapes: talks with ma, laughs wide on a cheer, flies open on a wow, droops when sad and snaps when angry */
 const snap=12+Math.abs(Math.sin(t*6.5))*26,base=34+Math.sin(t*1.6)*3+ex.ma*30+M.ch*26*(.7+.3*Math.sin(t*14))+M.wow*46-M.sad*12+(M.rat>.05?Math.sin(t*38)*5*M.rat:0);
 const gap=Math.max(9,Math.min(84,base*(1-M.ang)+snap*M.ang)),lb=ty-gap;
 /* the dark inside, the eyes and the teeth */
 g.fillStyle=pzGr(g,'pzdc_cin',0,-260,0,-140,[[0,'#2a0a26'],[1,'#0c0410']]);g.beginPath();g.rect(-W+6,lb-4,W*2-12,gap+10);g.fill();
 {const er=Math.min(19,gap*.34+4),ey=ty-gap*.52;pzGlow(g,0,ey,er*4.2,M.ang>.3?'rgba(255,70,40,1)':'rgba(255,200,60,1)',.45+.25*M.ang);
  for(const s of[-1,1])pznEye(g,s*32,ey,er,ex,{white:M.ang>.3?'#ffd0a0':'#fff6c8',iris:M.ang>.3?'#ff4a1a':'#ffaa1a',pupil:PZ_O,skin:'#1a0814',side:s,lw:2.6,pr:.5,slit:1})}
 pzdcBk(g,'cbox',-W-6,ty-22,W*2+12,by-ty+30,g=>{
 g.fillStyle='#fff8ea';g.strokeStyle=PZ_O;g.lineWidth=2.2;
 for(let i=0;i<7;i++){const x=-W+20+i*((W*2-40)/6),h=11+(i%2)*4;g.beginPath();g.moveTo(x-8,ty+2);g.lineTo(x,ty-h);g.lineTo(x+8,ty+2);g.closePath();g.fill();g.stroke()}
 /* the box: plank wood, gold bands, studs, corner plates, a lock plate */
 const box=()=>{g.roundRect(-W,ty,W*2,by-ty,[4,4,12,12])};
 pzBlob(g,pzGr(g,'pzdc_cbox',0,ty,0,by,[[0,'#a85a28'],[.5,'#8a4418'],[1,'#5a2a10']]),box,4.5);
 g.save();g.beginPath();box();g.clip();g.strokeStyle='rgba(40,14,4,.55)';g.lineWidth=2;for(let i=1;i<4;i++){const y=ty+i*(by-ty)/4;g.beginPath();g.moveTo(-W,y);g.lineTo(W,y);g.stroke()}
 g.strokeStyle='rgba(255,200,140,.22)';g.lineWidth=2;for(let i=0;i<4;i++){const y=ty+6+i*(by-ty)/4;g.beginPath();g.moveTo(-W+30,y);g.quadraticCurveTo(-20,y+3,10,y);g.stroke()}
 g.fillStyle=pzGr(g,'pzdc_cband',0,ty,0,by,[[0,'#ffe27a'],[.5,'#e0a028'],[1,'#a8680e']]);g.fillRect(-W,ty,W*2,14);g.fillRect(-W,by-14,W*2,14);g.fillRect(-76,ty,18,by-ty);g.fillRect(58,ty,18,by-ty);g.restore();
 g.strokeStyle=PZ_O;g.lineWidth=2.4;g.beginPath();g.moveTo(-W,ty+14);g.lineTo(W,ty+14);g.moveTo(-W,by-14);g.lineTo(W,by-14);g.moveTo(-76,ty+14);g.lineTo(-76,by-14);g.moveTo(-58,ty+14);g.lineTo(-58,by-14);g.moveTo(58,ty+14);g.lineTo(58,by-14);g.moveTo(76,ty+14);g.lineTo(76,by-14);g.stroke();
 pzdcRiv(g,-67,ty+28,-67,by-26,4,3.2);pzdcRiv(g,67,ty+28,67,by-26,4,3.2);pzdcRiv(g,-W+16,ty+7,W-16,ty+7,9,2.4);pzdcRiv(g,-W+16,by-7,W-16,by-7,9,2.4);
 });
 /* lock plate (a gold shield with a keyhole), wobbling when rattled */
 {g.save();g.translate(0,ty+50);g.rotate(M.rat*Math.sin(t*30)*.12);pzBlob(g,'#ffd24a',()=>{g.moveTo(-20,-24);g.lineTo(20,-24);g.lineTo(20,6);g.quadraticCurveTo(20,22,0,30);g.quadraticCurveTo(-20,22,-20,6);g.closePath()},3);
  g.fillStyle='rgba(255,255,255,.55)';g.fillRect(-15,-20,5,22);pzEll(g,PZ_O,0,-5,5.5,5.5,0,0);g.fillStyle=PZ_O;g.beginPath();g.moveTo(-3,-3);g.lineTo(3,-3);g.lineTo(5,12);g.lineTo(-5,12);g.closePath();g.fill();g.restore()}
 pzBlush(g,-92,ty+34,14,ex);pzBlush(g,92,ty+34,14,ex);
 /* the tongue: lolls out over the front; licks the rim every few seconds; flops limp when sad, waggles on a cheer */
 {const lk=M.ch<.3&&M.ang<.3?Math.sin(Math.PI*pzdcCl(((t%6.5)-5.4)/1.1)):0,sw=Math.sin(t*2.2)*6+M.ch*Math.sin(t*11)*12;
  const tx=48+sw+lk*30,tyy=ty+60+M.ch*22+M.sad*30-lk*(110+gap*.6)-M.ang*24,cx=50+sw*.5+lk*60,cy=ty+10-lk*40;
  const tg=pzGr(g,'pzdc_ctg',0,ty-30,0,ty+80,[[0,'#ff6a8a'],[1,'#e83a64']]),L=pznLimb(g,24,ty-3,cx,cy,tx,tyy,34,24,tg,3.4,0);{const P=L.pts,e=P[P.length-1],q=P[P.length-2],a=Math.atan2(e[1]-q[1],e[0]-q[0]);g.save();g.translate(e[0],e[1]);g.rotate(a);pzBlob(g,tg,()=>{g.arc(0,0,12,-Math.PI/2,Math.PI/2)},3.4);g.fillStyle=tg;g.fillRect(-3,-10,4,20);g.restore()}
  g.strokeStyle='rgba(150,20,60,.6)';g.lineWidth=2.6;g.beginPath();const P=L.pts;g.moveTo(P[3][0],P[3][1]);for(let i=4;i<P.length-1;i++)g.lineTo(P[i][0],P[i][1]);g.stroke();g.fillStyle='rgba(255,255,255,.45)';g.beginPath();g.ellipse(P[5][0]-6,P[5][1],3,7,0,0,TAU);g.fill()}
 /* the lid: a domed top that rocks with laughter */
 {g.save();g.translate(-W,lb);g.rotate(-M.ch*.05*(.6+.4*Math.sin(t*14))-M.wow*.07+M.sad*.03+p.tilt*.3);g.translate(W,0);
  pzdcBk(g,'clid',-W-6,-96,W*2+12,120,g=>{const lid=()=>{g.moveTo(-W,0);g.lineTo(-W,-46);g.ellipse(0,-46,W,42,0,Math.PI,TAU);g.lineTo(W,0);g.closePath()};g.fillStyle='#fff8ea';g.strokeStyle=PZ_O;g.lineWidth=2.2;for(let i=0;i<6;i++){const x=-W+34+i*((W*2-68)/5),h=12+((i+1)%2)*5;g.beginPath();g.moveTo(x-8,-2);g.lineTo(x,h);g.lineTo(x+8,-2);g.closePath();g.fill();g.stroke()}
  pzBlob(g,pzGr(g,'pzdc_clid',0,-90,0,0,[[0,'#c87038'],[.55,'#9a4c1c'],[1,'#6a3012']]),lid,4.5);
  g.save();g.beginPath();lid();g.clip();g.strokeStyle='rgba(40,14,4,.5)';g.lineWidth=2;g.beginPath();g.moveTo(-W,-46);g.lineTo(W,-46);g.moveTo(-W,-66);g.quadraticCurveTo(0,-104,W,-66);g.stroke();
  g.fillStyle=pzGr(g,'pzdc_clb',0,-90,0,0,[[0,'#fff0a0'],[.5,'#e8a830'],[1,'#a8680e']]);g.fillRect(-W,-14,W*2,14);g.fillRect(-76,-100,18,100);g.fillRect(58,-100,18,100);
  g.fillStyle='rgba(255,240,200,.25)';g.beginPath();g.ellipse(-40,-72,46,10,-.15,0,TAU);g.fill();g.restore();
  g.strokeStyle=PZ_O;g.lineWidth=2.4;g.beginPath();g.moveTo(-W,-14);g.lineTo(W,-14);for(const x of[-76,-58,58,76]){g.moveTo(x,-14);g.lineTo(x,-46-Math.sqrt(Math.max(0,1-x*x/(W*W)))*42)}g.stroke();
  pzdcRiv(g,-67,-28,-67,-70,3,3);pzdcRiv(g,67,-28,67,-70,3,3);pzBlob(g,'#ffd24a',()=>{g.ellipse(0,-34,15,13,0,0,TAU)},3);pzdcGem(g,0,-34,9,'#ff2a4a',2);pzdcRiv(g,-W+14,-7,W-14,-7,9,2.4)});if(((t*.5)%1)<.1){g.fillStyle='#fff';pzdcStar(g,6,-42,7)}
  /* sweat */
  pzSweat(g,W-24,-60,t,ex);
  /* the bellhop cap: hops when the lid snaps, flies off on a wow */
  {const fly=M.wow*30,hop=M.ang*Math.abs(Math.sin(t*6.5))*10+M.ch*Math.abs(Math.sin(t*9))*6;g.save();g.translate(18+M.wow*10,-90-fly-hop);g.rotate(.16+M.wow*.5+Math.sin(t*1.7)*.03);
   pzBlob(g,'#c81e3a',()=>{g.moveTo(-26,0);g.lineTo(-22,-26);g.quadraticCurveTo(0,-32,22,-26);g.lineTo(26,0);g.quadraticCurveTo(0,6,-26,0)},3.4);
   g.fillStyle='#ffd24a';g.fillRect(-25,-9,50,6);g.strokeStyle=PZ_O;g.lineWidth=2;g.strokeRect(-25,-9,50,6);g.fillStyle='rgba(255,255,255,.3)';g.fillRect(-18,-24,6,12);
   pzEll(g,'#ffd24a',0,-30,5,4,0,2.2);pzBlob(g,'#1a0a20',()=>{g.moveTo(-26,0);g.quadraticCurveTo(-10,8,8,4);g.lineTo(-24,2);g.closePath()},2);g.restore()}
  g.restore()}
 /* a laugh spills coins out of the mouth */
 if(M.ch>.08)for(let i=0;i<7;i++){const ph=(t*1.15+i/7)%1,s=i%2?1:-1,x=s*(18+ph*(70+(i%3)*28)),y=ty-gap*.4-ph*120+ph*ph*190;g.globalAlpha=M.ch*(1-Math.pow(ph,5));pzdcCoin(g,x,y,9,Math.abs(Math.cos(t*7+i)),2);g.globalAlpha=1}
 /* angry: little puffs of dust from the snapping lid */
 if(M.ang>.2)for(const s of[-1,1]){const ph=(t*2.2)%1;pzdcPuff(g,s*(W+8+ph*20),ty-gap*.5-ph*14,6+ph*8,'#e8d8c8',M.ang*(1-ph)*.7)}
 /* sad: the lid seeps a drop */
 if(M.sad>.3){const ph=(t*.8)%1;g.globalAlpha=M.sad*(1-ph);g.fillStyle='#9ad8ff';g.strokeStyle=PZ_O;g.lineWidth=2;g.beginPath();g.ellipse(-60,ty-gap*.4+ph*36,4,6,0,0,TAU);g.fill();g.stroke();g.globalAlpha=1}
 g.restore();g.restore()};

/* ================= Zephyra: the smoke genie dealer ================= */
pzMon.zephyra=function(g,t,ex,p){const M=pzdcMood(ex),fl=Math.sin(t*1.3)*6;
 pzEll(g,'rgba(0,0,0,.28)',0,2,96,10,0,0);
 /* mood smoke puffs behind her */
 const pa=Math.max(M.ch,M.ang,M.sad,M.rat,M.wow);
 if(pa>.05){const col=M.ang>.3?'#ff5a6a':M.sad>.3?'#8a9ac8':M.ch>.3?'#fff0b0':M.wow>.3?'#ffb0f0':'#d8c8ff';
  for(let i=0;i<9;i++){const ph=(t*.55+i/9)%1,a=i/9*TAU+t*.2,r=110+ph*50+(M.rat>.3?Math.sin(t*20+i)*14:0);const px=Math.cos(a)*r,py=-250+Math.sin(a)*r*.75-(M.sad>.3?-ph*30:ph*20);pzdcPuff(g,px,py,12+ph*14,col,pa*(1-ph)*.7);if(M.ch>.3&&i%3===0){g.fillStyle=`rgba(255,240,180,${M.ch*(1-ph)})`;pzdcStar(g,px+14,py-14,8)}}}
 /* the lamp */
 {g.save();g.translate(0,-4);
 pzdcBk(g,'zlamp',-136,-104,272,116,g=>{
  pzBlob(g,'#c88a1c',()=>{g.ellipse(0,-6,44,10,0,0,TAU)},3.2);pzBlob(g,'#e8a830',()=>{g.moveTo(-18,-12);g.lineTo(-12,-26);g.lineTo(12,-26);g.lineTo(18,-12);g.closePath()},3);
  /* handle */
  g.strokeStyle=PZ_O;g.lineWidth=12;g.beginPath();g.ellipse(-84,-46,20,16,0,-1.2,2.2);g.stroke();g.strokeStyle='#d89a28';g.lineWidth=6;g.stroke();
  /* spout */
  pzBlob(g,pzGr(g,'pzdc_zsp',0,-80,0,-20,[[0,'#fff0a0'],[1,'#b8780e']]),()=>{g.moveTo(50,-52);g.quadraticCurveTo(90,-50,112,-78);g.lineTo(120,-74);g.quadraticCurveTo(104,-34,52,-30);g.closePath()},3.2);
  pzBlob(g,pzGr(g,'pzdc_zlamp',0,-74,0,-24,[[0,'#fff3b0'],[.4,'#f0b838'],[1,'#9a600e']]),()=>{g.ellipse(0,-46,72,24,0,0,TAU)},4);
  g.strokeStyle='rgba(120,60,0,.6)';g.lineWidth=2;g.beginPath();g.ellipse(0,-42,58,13,0,.2,Math.PI-.2);g.stroke();
  pzdcLampGems(g,t);
  pzBlob(g,'#e8a830',()=>{g.ellipse(0,-68,26,8,0,0,TAU)},3);g.fillStyle='#2a0a3a';g.beginPath();g.ellipse(0,-69,16,4.5,0,0,TAU);g.fill();
  g.fillStyle='rgba(255,255,255,.65)';g.beginPath();g.ellipse(-30,-58,16,5,-.2,0,TAU);g.fill();});
g.restore()}
 g.save();g.translate(0,-fl);g.scale(1,1+p.breath*.8);
 /* the smoke tail: a curling S from the lamp mouth to her waist, with wisps peeling off */
 {const sw=Math.sin(t*1.25)*36,sw2=Math.sin(t*.9+1)*20;const col=pzGr(g,'pzdc_ztail',0,-200,0,-60,[[0,'#3ec8d8'],[.55,'#6a6ae0'],[1,'#9a4ae8']]);
  pznLimb(g,sw2*.4,-68+fl,60+sw,-110,4,-188,10,62,col,3.5,0);
  g.save();g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=3;g.beginPath();g.moveTo(sw2*.3+3,-80+fl);g.quadraticCurveTo(50+sw,-118,10,-178);g.stroke();g.restore();
  for(let i=0;i<7;i++){const ph=(t*.35+i/7)%1,u=1-ph,x=(1-u)*(1-u)*sw2*.4+2*(1-u)*u*(60+sw)+u*u*4+Math.sin(t*2+i)*20*ph+(i%2?-1:1)*(18+ph*30),y=(1-u)*(1-u)*(-68+fl)+2*(1-u)*u*(-110)+u*u*(-188)-ph*30;
   pzdcPuff(g,x,y,7+ph*10,i%2?'#7ae0ec':'#b68af0',.6*(1-ph))}
  /* a curl of smoke drifting off the tail */
  g.strokeStyle='rgba(170,140,255,.55)';g.lineWidth=4;g.beginPath();const cxp=-56+Math.sin(t*.8)*10,cyp=-130;g.arc(cxp,cyp,14,t*1.5,t*1.5+4.2);g.stroke();g.beginPath();g.arc(cxp+20,cyp-26,9,-t*1.8,-t*1.8+4);g.stroke()}
 /* the torso */
 const skin='#86dcec',skinD='#4aa8c4',sk=pzGr(g,'pzdc_zsk',0,-290,0,-170,[[0,'#a8ecf6'],[1,'#5ab8d0']]);
 /* back arm, the hair ponytail behind */
 {const hs=Math.sin(t*1.1)*14;g.save();g.translate(0,-372+p.bob);
  pzBlob(g,pzGr(g,'pzdc_zhair',0,-40,0,140,[[0,'#3a1a78'],[1,'#7a4ad8']]),()=>{g.moveTo(-6,-30);g.bezierCurveTo(60+hs,-60,110+hs,0,90+hs*1.4,60);g.bezierCurveTo(80+hs*1.6,90,110+hs*1.8,120,96+hs*2,150);g.bezierCurveTo(70+hs,110,56+hs,70,60+hs*.6,40);g.bezierCurveTo(56,10,20,-4,6,-6);g.closePath()},3.4);
  g.strokeStyle='rgba(200,170,255,.45)';g.lineWidth=2.5;g.beginPath();g.moveTo(10,-24);g.bezierCurveTo(60+hs,-44,96+hs,6,80+hs*1.4,60);g.stroke();g.restore()}
 pzdcBk(g,'ztorso',-66,-312,132,146,g=>{const skin='#86dcec',sk=pzGr(g,'pzdc_zsk',0,-290,0,-170,[[0,'#a8ecf6'],[1,'#5ab8d0']]);
 pzBlob(g,sk,()=>{g.moveTo(-44,-298);g.quadraticCurveTo(-58,-290,-52,-264);g.quadraticCurveTo(-34,-230,-38,-200);g.quadraticCurveTo(-40,-182,-26,-178);g.lineTo(26,-178);g.quadraticCurveTo(40,-182,38,-200);g.quadraticCurveTo(34,-230,52,-264);g.quadraticCurveTo(58,-290,44,-298);g.quadraticCurveTo(0,-308,-44,-298)},4);
 /* bolero and top: deep violet with gold trim, a jewel at the sternum */
 pzBlob(g,'#3a1468',()=>{g.moveTo(-44,-298);g.quadraticCurveTo(-58,-288,-52,-262);g.quadraticCurveTo(-40,-244,-36,-232);g.quadraticCurveTo(-20,-250,-14,-282);g.quadraticCurveTo(-26,-296,-44,-298)},3);
 pzBlob(g,'#3a1468',()=>{g.moveTo(44,-298);g.quadraticCurveTo(58,-288,52,-262);g.quadraticCurveTo(40,-244,36,-232);g.quadraticCurveTo(20,-250,14,-282);g.quadraticCurveTo(26,-296,44,-298)},3);
 g.strokeStyle='#ffcf48';g.lineWidth=3;g.beginPath();g.moveTo(-14,-282);g.quadraticCurveTo(-20,-250,-36,-232);g.moveTo(14,-282);g.quadraticCurveTo(20,-250,36,-232);g.stroke();
 pzBlob(g,'#ffcf48',()=>{g.moveTo(-30,-244);g.quadraticCurveTo(0,-232,30,-244);g.lineTo(28,-236);g.quadraticCurveTo(0,-224,-28,-236);g.closePath()},2.4);pzdcGem(g,0,-236,7,'#ff3a6a',2);
 /* sash at the waist */
 pzBlob(g,pzGr(g,'pzdc_zsash',0,-200,0,-176,[[0,'#ffe27a'],[1,'#c88a1c']]),()=>{g.moveTo(-40,-202);g.quadraticCurveTo(0,-192,40,-202);g.lineTo(38,-180);g.quadraticCurveTo(0,-170,-38,-180);g.closePath()},3);
 pzdcGem(g,0,-188,6,'#3ae0c8',2);
});
 /* arms and the card shuffle: cards arc from the left hand to the right; fanned overhead on a cheer, dropped when sad, sprayed when rattled */
 const lift=M.ch*70,drop=M.sad*28,lh={x:-64,y:-214-lift+drop+Math.sin(t*2.4)*3},rh={x:64,y:-214-lift+drop-Math.sin(t*2.4)*3};
 const arm=(s,h)=>{pznLimb(g,s*44,-286,s*80,-262+(h.y+214)*.3,h.x,h.y,20,13,sk,3.4,0);
  for(let i=0;i<3;i++){const u=.72+i*.08,x=s*44*(1-u)*(1-u)+2*(1-u)*u*s*80+u*u*h.x,y=-286*(1-u)*(1-u)+2*(1-u)*u*(-262+(h.y+214)*.3)+u*u*h.y;g.strokeStyle=PZ_O;g.lineWidth=7;g.beginPath();g.ellipse(x,y,9,4,s*.6,0,TAU);g.stroke();g.strokeStyle=i%2?'#ffe27a':'#e8a830';g.lineWidth=4;g.stroke()}
  pzEll(g,skin,h.x,h.y,11,10,0,3)};
 arm(-1,lh);arm(1,rh);
 {const N=6;for(let i=0;i<N;i++){let x,y,a,al=1;
   if(M.ch>.4){const fa=(i-(N-1)/2)*.34+Math.sin(t*3)*.05;x=Math.sin(fa)*90;y=-372-Math.cos(fa)*44;a=fa}
   else{const ph=(t*.9+i/N)%1,u=ph;x=lh.x+(rh.x-lh.x)*u;y=lh.y-14-Math.sin(u*Math.PI)*(44+M.wow*40)+(M.rat>.2?Math.sin(t*13+i*2)*24*M.rat:0);a=(u-.5)*1.4+(M.rat>.2?Math.sin(t*9+i)*M.rat:0);if(M.sad>.3){y+=M.sad*u*30}}
   g.save();g.translate(x,y);g.rotate(a);pzdcBk(g,'zcard'+i,-26,-26,52,52,g=>{pzGlow(g,0,0,26,'rgba(120,240,255,1)',.35);g.fillStyle='#fff8ee';g.strokeStyle=PZ_O;g.lineWidth=2.4;g.beginPath();g.roundRect(-11,-15,22,30,4);g.fill();g.stroke();
   g.fillStyle=i%2?'#e8263a':'#3a1468';g.font='800 12px Poppins,sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillText(['A','K','Q','J','8','★'][i],0,1);g.textBaseline='alphabetic';
   g.strokeStyle='rgba(58,200,220,.8)';g.lineWidth=1.5;g.beginPath();g.roundRect(-8,-12,16,24,3);g.stroke()});g.restore()}}
 /* the head */
 g.save();g.translate(0,-336+p.bob);g.rotate(p.tilt*.6+M.sad*.06-M.ch*.05*Math.sin(t*8));g.translate(0,M.sad*4);
 /* pointed ears with gold hoops */
 for(const s of[-1,1]){pzBlob(g,skin,()=>{g.moveTo(s*36,-6);g.quadraticCurveTo(s*62,-24-M.ch*6+M.sad*14,s*66,-30-M.ch*8+M.sad*20);g.quadraticCurveTo(s*56,4,s*36,12);g.closePath()},3.2);
  g.strokeStyle=PZ_O;g.lineWidth=6;g.beginPath();g.arc(s*42,20,8,0,TAU);g.stroke();g.strokeStyle='#ffcf48';g.lineWidth=3;g.stroke()}
 pzdcBk(g,'zhead',-52,-84,104,142,g=>{const skin='#86dcec',sk=pzGr(g,'pzdc_zsk',0,-290,0,-170,[[0,'#a8ecf6'],[1,'#5ab8d0']]);pzBlob(g,sk,()=>{g.roundRect(-12,30,24,24,6)},3);
 pzBlob(g,pzGr(g,'pzdc_zface',0,-46,0,40,[[0,'#b4f2fa'],[1,'#6ac4dc']]),()=>{g.moveTo(0,-44);g.bezierCurveTo(30,-44,42,-20,40,2);g.bezierCurveTo(38,26,20,40,0,42);g.bezierCurveTo(-20,40,-38,26,-40,2);g.bezierCurveTo(-42,-20,-30,-44,0,-44)},4);
 /* hair: a smooth dark-violet cap with a topknot ring */
 pzBlob(g,'#3a1a78',()=>{g.moveTo(-42,4);g.bezierCurveTo(-48,-40,-20,-56,0,-54);g.bezierCurveTo(20,-56,48,-40,42,4);g.quadraticCurveTo(38,-18,22,-26);g.quadraticCurveTo(0,-20,-22,-26);g.quadraticCurveTo(-38,-18,-42,4)},3.4);
 g.strokeStyle='rgba(190,160,255,.5)';g.lineWidth=3;g.beginPath();g.moveTo(-30,-36);g.quadraticCurveTo(-10,-50,10,-48);g.stroke();
 pzBlob(g,'#3a1a78',()=>{g.ellipse(0,-64,14,12,0,0,TAU)},3);pzBlob(g,'#ffcf48',()=>{g.roundRect(-10,-56,20,7,3)},2.4);
 /* the jewelled headband */
 g.strokeStyle=PZ_O;g.lineWidth=8;g.beginPath();g.moveTo(-41,-16);g.quadraticCurveTo(0,-36,41,-16);g.stroke();g.strokeStyle='#ffcf48';g.lineWidth=4.5;g.stroke();
});
 {const tw=.6+.4*Math.sin(t*3);pzdcBk(g,'zplate',-28,-44,56,38,g=>{pzBlob(g,'#ffcf48',()=>{g.moveTo(0,-38);g.lineTo(9,-26);g.lineTo(0,-12);g.lineTo(-9,-26);g.closePath()},2.4);for(const s of[-1,1])pzEll(g,'#ff3a6a',s*22,-24,3,3,0,1.4)});pzdcGem(g,0,-25,7,M.ang>.3?'#ff2a3a':'#3ae0c8',2);
  if(tw>.9){g.fillStyle='#fff';pzdcStar(g,6,-34,6)}}
 /* face */
 for(const s of[-1,1]){pznEye(g,s*15,-2,10.5,ex,{iris:'#a24ae8',iris2:'#6a1ab8',skin:'#8ad8ea',side:s,lw:2.8,pr:.55});
  g.strokeStyle=PZ_O;g.lineWidth=2.6;g.lineCap='round';const ey=-2-10.5*Math.min(1,ex.eo)*.8;g.beginPath();g.moveTo(s*24,ey+2);g.lineTo(s*31,ey-3);g.moveTo(s*21,ey-1);g.lineTo(s*26,ey-7);g.stroke()}
 pzBrowD(g,-16,-18,15,ex,-1,'#2a0a58',3.2);pzBrowD(g,16,-18,15,ex,1,'#2a0a58',3.2);
 g.strokeStyle='rgba(30,60,90,.6)';g.lineWidth=2;g.beginPath();g.moveTo(-1,6);g.quadraticCurveTo(3,12,-2,14);g.stroke();
 pzBlush(g,-24,14,8,ex,'#ff7ac8');pzBlush(g,24,14,8,ex,'#ff7ac8');
 pzMouthD(g,0,24,20,ex,{in:'#3a0a30',tongue:'#ff7a9a',line:'#5a1a5a',lw:3});
 g.fillStyle='rgba(255,90,170,.5)';g.beginPath();g.ellipse(0,24+ex.mo*2,7,2.4,0,0,TAU);g.fill();
 pzSweat(g,38,-26,t,ex);
 g.restore();
 g.restore()};
function pzdcLampGems(g,t){pzdcGem(g,0,-44,8,'#ff3a6a',2.2);pzdcGem(g,-34,-42,5,'#3ae0c8',1.8);pzdcGem(g,34,-42,5,'#3ae0c8',1.8)}

/* ================= Sir Brassknuckle: the clockwork bouncer ================= */
pzMon.brass=function(g,t,ex,p){const M=pzdcMood(ex),shk=M.rat>.04?Math.sin(t*41)*2.5*M.rat:0;
 const brass=pzGr(g,'pzdc_bbr',-120,-300,120,-80,[[0,'#fff0b0'],[.35,'#f0c050'],[.75,'#c88a28'],[1,'#7a4a12']]),dark='#5a3a14';
 pzEll(g,'rgba(0,0,0,.3)',0,2,128,12,0,0);
 g.save();g.translate(shk,0);
 /* feet and piston legs */
 pzdcBk(g,'blegs',-96,-104,192,110,g=>{const brass=pzGr(g,'pzdc_bbr',-120,-300,120,-80,[[0,'#fff0b0'],[.35,'#f0c050'],[.75,'#c88a28'],[1,'#7a4a12']]);
 for(const s of[-1,1]){pzBlob(g,'#3a2a2a',()=>{g.roundRect(s*48-14,-96,28,64,6)},3.2);g.strokeStyle='#8a8a9a';g.lineWidth=3;for(let i=0;i<3;i++){g.beginPath();g.moveTo(s*48-12,-84+i*18);g.lineTo(s*48+12,-84+i*18);g.stroke()}
  pzBlob(g,brass,()=>{g.moveTo(s*48-38,-2);g.quadraticCurveTo(s*48-38,-40,s*48,-40);g.quadraticCurveTo(s*48+38,-40,s*48+40,-2);g.closePath()},4);pzdcRiv(g,s*48-24,-12,s*48+24,-12,4,2.6)}
});
 g.save();g.scale(1,1+p.breath*.8);
 /* steam pipes on the shoulders: whistle bursts every 8 s, constant when angry */
 const whis=pzdcCl(1-Math.abs(((t%8)-.8)/.8)),stm=Math.max(whis,M.ang,M.ch*.6);
 for(const s of[-1,1]){pzBlob(g,'#b8782a',()=>{g.roundRect(s*132-9,-356,18,60,4)},3.2);pzBlob(g,'#e8b048',()=>{g.roundRect(s*132-13,-364,26,10,3)},3);
  for(let i=0;i<4;i++){const ph=(t*(1.2+stm*1.6)+i/4)%1,a=(.14+.6*stm)*(1-ph);pzdcPuff(g,s*(132+ph*26),-370-ph*60,7+ph*14,'#f4f0f4',a)}}
 /* the wind-up key behind his right shoulder, turning */
 {const ka=t*(1.6+M.ch*3-M.sad*1.2),kx=74,ky=-330;g.save();g.translate(kx,ky);g.rotate(.55);pzBlob(g,'#c88a28',()=>{g.roundRect(-5,-6,10,40,3)},3);
  g.translate(0,-10);g.scale(Math.cos(ka)*.9+(Math.cos(ka)>=0?.1:-.1),1);pzBlob(g,pzGr(g,'pzdc_bkey',-30,-30,30,0,[[0,'#fff0b0'],[1,'#b8780e']]),()=>{g.ellipse(-16,-16,18,14,0,0,TAU);g.moveTo(34,-16);g.ellipse(16,-16,18,14,0,0,TAU)},3.4);
  g.fillStyle=PZ_O;g.beginPath();g.ellipse(-16,-16,6,5,0,0,TAU);g.ellipse(16,-16,6,5,0,0,TAU);g.fill();g.restore()}
 /* upper arms behind the body */
 const ar=(s)=>{const up=s>0?M.ch:0,bang=M.ang;const sx=s*118,sy=-268,ex2=s*(146-up*20-bang*30),ey2=-196-up*90+M.sad*16,hx=s*(138-bang*70-up*10),hy=-124-up*190+M.sad*24+bang*-40+(bang>.3?Math.abs(Math.sin(t*7+(s>0?0:1.6)))*-16:0)+(s<0?Math.sin(t*1.4)*3:0);
  g.lineCap='round';g.strokeStyle=PZ_O;g.lineWidth=44;g.beginPath();g.moveTo(sx,sy);g.lineTo(ex2,ey2);g.lineTo(hx,hy);g.stroke();g.strokeStyle='#c88a28';g.lineWidth=36;g.stroke();g.strokeStyle='rgba(255,240,180,.55)';g.lineWidth=8;g.beginPath();g.moveTo(sx-s*8,sy);g.lineTo(ex2-s*8,ey2);g.lineTo(hx-s*8,hy);g.stroke();
  pzEll(g,'#5a5a6a',ex2,ey2,16,16,0,3.2);pzEll(g,'#9a9aaa',ex2,ey2,7,7,0,2);
  /* the fist */
  g.save();g.translate(hx,hy);pzdcBk(g,'bfist'+(up>.3?1:0),-32,-28,64,58,g=>{const brass=pzGr(g,'pzdc_bbr',-120,-300,120,-80,[[0,'#fff0b0'],[.35,'#f0c050'],[.75,'#c88a28'],[1,'#7a4a12']]);pzBlob(g,brass,()=>{g.roundRect(-28,-24,56,50,16)},4);g.strokeStyle=PZ_O;g.lineWidth=2.4;for(let i=1;i<4;i++){g.beginPath();g.moveTo(-28+i*14,up>.3?18:-20);g.lineTo(-28+i*14,up>.3?24:-6);g.stroke()}
  pzdcRiv(g,-18,10,18,10,3,2.4)});g.restore()};
 /* the torso: a riveted barrel */
 pzdcBk(g,'btorso',-176,-326,352,256,g=>{const brass=pzGr(g,'pzdc_bbr',-120,-300,120,-80,[[0,'#fff0b0'],[.35,'#f0c050'],[.75,'#c88a28'],[1,'#7a4a12']]);const torso=()=>{g.moveTo(-88,-96);g.bezierCurveTo(-120,-140,-132,-230,-110,-290);g.quadraticCurveTo(0,-318,110,-290);g.bezierCurveTo(132,-230,120,-140,88,-96);g.quadraticCurveTo(0,-82,-88,-96)};
 pzBlob(g,brass,torso,5);
 g.save();g.beginPath();torso();g.clip();g.strokeStyle='rgba(90,50,10,.55)';g.lineWidth=3;g.beginPath();g.moveTo(-130,-150);g.quadraticCurveTo(0,-134,130,-150);g.moveTo(0,-300);g.lineTo(0,-232);g.moveTo(0,-142);g.lineTo(0,-90);g.stroke();
 g.fillStyle='rgba(255,255,255,.28)';g.beginPath();g.ellipse(-70,-250,18,40,.25,0,TAU);g.fill();g.fillStyle='rgba(60,30,0,.22)';g.beginPath();g.ellipse(80,-180,34,90,-.1,0,TAU);g.fill();g.restore();
 pzdcRiv(g,-100,-140,-112,-280,6,3);pzdcRiv(g,100,-140,112,-280,6,3);pzdcRiv(g,-80,-148,80,-148,7,3);
 /* belt band */
 pzBlob(g,'#3a2a2a',()=>{g.moveTo(-96,-112);g.quadraticCurveTo(0,-98,96,-112);g.lineTo(90,-92);g.quadraticCurveTo(0,-78,-90,-92);g.closePath()},3.4);pzBlob(g,'#ffd24a',()=>{g.roundRect(-16,-108,32,20,4)},3);
pzBlob(g,'#2a1a1a',()=>{g.roundRect(-52,-232,104,78,[30,30,10,10])},4);for(const s of[-1,1]){pzBlob(g,brass,()=>{g.moveTo(s*80,-250);g.quadraticCurveTo(s*80,-312,s*126,-312);g.quadraticCurveTo(s*168,-304,s*164,-252);g.quadraticCurveTo(s*124,-262,s*80,-250)},4.5);pzdcRiv(g,s*96,-290,s*150,-286,4,2.8)}
});
 /* the furnace grate with glowing coals */
 {const heat=.55+.25*Math.sin(t*5.3)*Math.sin(t*3.1)+M.ang*.35+M.ch*.3-M.sad*.3;
  g.save();g.beginPath();g.roundRect(-48,-228,96,70,[27,27,8,8]);g.clip();g.fillStyle=pzGrR(g,'pzdc_bfire',0,-160,4,80,[[0,'#ffe27a'],[.4,'#ff7a1a'],[1,'#5a0a0a']]);g.globalAlpha=pzdcCl(.4+heat*.7);g.fillRect(-50,-232,100,80);g.globalAlpha=1;
  for(let i=0;i<9;i++){const x=-38+(i%5)*19+(i>4?9:0),y=-168-(i>4?14:0),f=.5+.5*Math.sin(t*(4+i)+i*2);g.fillStyle=f>.6?'#ffd24a':'#ff6a1a';g.strokeStyle='#3a0a0a';g.lineWidth=1.6;g.beginPath();g.ellipse(x,y,10,7,0,0,TAU);g.fill();g.stroke()}
  if(M.ch>.2||M.ang>.2)for(let i=0;i<4;i++){const ph=(t*1.8+i/4)%1;g.fillStyle='#ffe27a';g.globalAlpha=(1-ph)*Math.max(M.ch,M.ang);g.beginPath();g.moveTo(-30+i*20,-178-ph*44);g.quadraticCurveTo(-24+i*20,-190-ph*44,-30+i*20,-204-ph*44);g.quadraticCurveTo(-36+i*20,-190-ph*44,-30+i*20,-178-ph*44);g.fill();g.globalAlpha=1}
  g.restore();pzGlow(g,0,-190,70+heat*16,'rgba(255,140,40,1)',.35*pzdcCl(heat));
  pzdcBk(g,'bgrate',-56,-236,112,84,g=>{g.strokeStyle=PZ_O;g.lineWidth=7;for(let i=-2;i<=2;i++){g.beginPath();g.moveTo(i*18,-228);g.lineTo(i*18,-158);g.stroke()}g.strokeStyle='#5a5a6a';g.lineWidth=3.5;for(let i=-2;i<=2;i++){g.beginPath();g.moveTo(i*18,-226);g.lineTo(i*18,-160);g.stroke()}
  g.strokeStyle=PZ_O;g.lineWidth=7;g.beginPath();g.moveTo(-50,-196);g.lineTo(50,-196);g.stroke();g.strokeStyle='#5a5a6a';g.lineWidth=3.5;g.stroke()})}
 ar(-1);ar(1);
 /* the head: a small dome, a grille mouth, gauge eyes, a tiny bow tie */
 g.save();g.translate(0,-304+p.bob*.6);g.rotate(p.tilt*.5+M.sad*.05);g.translate(0,M.sad*6);
 pzdcBk(g,'bhead',-60,-104,120,112,g=>{const brass=pzGr(g,'pzdc_bbr',-120,-300,120,-80,[[0,'#fff0b0'],[.35,'#f0c050'],[.75,'#c88a28'],[1,'#7a4a12']]);const head=()=>{g.moveTo(-50,-10);g.lineTo(-54,-56);g.quadraticCurveTo(-52,-96,0,-98);g.quadraticCurveTo(52,-96,54,-56);g.lineTo(50,-10);g.quadraticCurveTo(0,0,-50,-10)};
 pzBlob(g,'#3a2a2a',()=>{g.roundRect(-20,-14,40,18,4)},3);
 pzBlob(g,brass,head,4.5);g.fillStyle='rgba(255,255,255,.35)';g.beginPath();g.ellipse(-26,-80,14,7,-.4,0,TAU);g.fill();pzdcRiv(g,-40,-18,40,-18,5,2.4);
});
 /* top lamp that flashes when angry */
 pzEll(g,M.ang>.3&&((t*4)%1)<.5?'#ff3a3a':'#ffd24a',0,-102,9,7,0,3);if(M.ang>.3)pzGlow(g,0,-104,28,'rgba(255,60,60,1)',.6*M.ang);
 /* gauge eyes: the needles read the mood */
 for(const s of[-1,1]){const x=s*24,y=-58,r=17;pzEll(g,'#c88a28',x,y,r+5,r+5,0,3.4);
  g.save();g.beginPath();g.arc(x,y,r,0,TAU);g.clip();pzdcBk(g,'bgauge'+s,x-r,y-r,r*2,r*2,g=>{g.fillStyle='#fff8e8';g.fillRect(x-r,y-r,r*2,r*2);g.fillStyle='#ff5a4a';g.beginPath();g.moveTo(x,y);g.arc(x,y,r,-.6,.2);g.closePath();g.fill();
  g.strokeStyle='#5a3a14';g.lineWidth=1.6;for(let i=0;i<7;i++){const a=-Math.PI*1.1+i*.45;g.beginPath();g.moveTo(x+Math.cos(a)*r*.72,y+Math.sin(a)*r*.72);g.lineTo(x+Math.cos(a)*r*.92,y+Math.sin(a)*r*.92);g.stroke()}});
  let na=-Math.PI*.62+ex.lx*.5-M.sad*.9+M.ang*1.15+M.ch*.4+(M.rat>.05?Math.sin(t*31+s)*.5*M.rat:0);if(M.wow>.05)na+=M.wow*t*9*s;
  g.strokeStyle=PZ_O;g.lineWidth=3;g.beginPath();g.moveTo(x,y);g.lineTo(x+Math.cos(na)*r*.82,y+Math.sin(na)*r*.82);g.stroke();pzEll(g,PZ_O,x,y,3,3,0,0);
  /* the shutter lids blink with eo */
  const op=pzdcCl(Math.min(1,ex.eo)),lid=(1-op)*r*2;if(lid>.5){g.fillStyle='#b8782a';g.fillRect(x-r,y-r,r*2,lid);g.strokeStyle=PZ_O;g.lineWidth=2.4;g.beginPath();g.moveTo(x-r,y-r+lid);g.lineTo(x+r,y-r+lid);g.stroke()}
  g.fillStyle='rgba(255,255,255,.55)';g.beginPath();g.ellipse(x-6,y-8,5,3,-.5,0,TAU);g.fill();g.restore();
  g.strokeStyle=PZ_O;g.lineWidth=3;g.beginPath();g.arc(x,y,r,0,TAU);g.stroke();
  /* brass brow plates */
  {g.save();g.translate(x,y-r-8-ex.bh*5);g.rotate(s*(-ex.br)*.4);pzBlob(g,'#a86a1c',()=>{g.roundRect(-16,-4,32,8,3)},2.6);g.restore()}}
 /* grille mouth */
 {const w=44,h=7+ex.ma*16,c=ex.mo*10,my=-28;g.save();g.translate(0,my);pzBlob(g,'#2a1a1a',()=>{g.moveTo(-w/2,-h/2+c*.3);g.quadraticCurveTo(0,-h/2-c*.4,w/2,-h/2+c*.3);g.lineTo(w/2,h/2-c*.2);g.quadraticCurveTo(0,h/2+c,-w/2,h/2-c*.2);g.closePath()},3);
  if(ex.ma>.3){g.fillStyle='#ff8a2a';g.globalAlpha=.6;g.beginPath();g.ellipse(0,h*.2,w*.3,h*.25,0,0,TAU);g.fill();g.globalAlpha=1}
  g.strokeStyle='#8a8a9a';g.lineWidth=2;for(let i=-2;i<=2;i++){g.beginPath();g.moveTo(i*8,-h/2-c*.2+1);g.lineTo(i*8,h/2+c*.4-1);g.stroke()}g.restore()}
 pzBlush(g,-38,-34,8,ex,'#ff8a4a');pzBlush(g,38,-34,8,ex,'#ff8a4a');
 /* oil-drop sweat */
 if(ex.sw>.05){const ph=(t*1.3)%1;g.globalAlpha=pzdcCl(ex.sw)*(1-ph*.5);g.fillStyle='#3a2a3a';g.strokeStyle='#fff';g.lineWidth=1.5;g.beginPath();g.moveTo(48,-70+ph*16);g.quadraticCurveTo(55,-60+ph*16,48,-54+ph*16);g.quadraticCurveTo(41,-60+ph*16,48,-70+ph*16);g.fill();g.stroke();g.globalAlpha=1}
 g.restore();
 /* the tiny bow tie */
 {const by=-300+p.bob*.6;pzBlob(g,'#c81e3a',()=>{g.moveTo(-15,by-7);g.lineTo(0,by);g.lineTo(-15,by+7);g.closePath();g.moveTo(15,by-7);g.lineTo(0,by);g.lineTo(15,by+7);g.closePath()},2.6);pzEll(g,'#ffd24a',0,by,3.6,3.6,0,2)}
 /* sad: a little puff of black smoke from the grate */
 if(M.sad>.2)for(let i=0;i<3;i++){const ph=(t*.6+i/3)%1;pzdcPuff(g,-6+Math.sin(t+i)*10,-236-ph*60,8+ph*10,'#4a4050',M.sad*(1-ph)*.6)}
 g.restore();g.restore()};

/* ================= Baron Hornsby: the minotaur high roller ================= */
pzMon.hornsby=function(g,t,ex,p){const M=pzdcMood(ex),shk=M.rat>.04?Math.sin(t*43)*2.6*M.rat:0;
 const fur='#7a4422',furD='#4a2410',velv=pzGr(g,'pzdc_hvel',-100,-300,100,-90,[[0,'#e83a50'],[.5,'#a8142e'],[1,'#5a0618']]);
 pzEll(g,'rgba(0,0,0,.3)',0,2,124,12,0,0);
 g.save();g.translate(shk,0);
 /* the cane (behind the left hand) */
 {const cx=-118+Math.sin(t*1.1)*2;g.strokeStyle=PZ_O;g.lineWidth=11;g.lineCap='round';g.beginPath();g.moveTo(cx,-4);g.lineTo(cx+6,-168);g.stroke();g.strokeStyle='#2a1420';g.lineWidth=6;g.stroke();pzEll(g,'#ffd24a',cx,-6,6,4,0,2.4)}
 /* trousers and hooves */
 pzdcBk(g,'hlegs',-80,-126,160,132,g=>{
 for(const s of[-1,1]){pzBlob(g,'#2a1a2a',()=>{g.moveTo(s*14,-120);g.lineTo(s*62,-120);g.lineTo(s*56,-26);g.lineTo(s*20,-26);g.closePath()},3.6);
  pzBlob(g,'#2a1a14',()=>{g.moveTo(s*14,-28);g.lineTo(s*64,-28);g.quadraticCurveTo(s*70,0,s*58,0);g.lineTo(s*20,0);g.quadraticCurveTo(s*10,-4,s*14,-28)},3.6);g.strokeStyle=PZ_O;g.lineWidth=2.4;g.beginPath();g.moveTo(s*39,-24);g.lineTo(s*39,0);g.stroke()}
});
 g.save();g.scale(1,1+p.breath*.8);
 /* back arm (left): rests on the cane */
 const sleeve=(x0,y0,cx,cy,x1,y1)=>{pznLimb(g,x0,y0,cx,cy,x1,y1,38,30,velv,4,0)};
 sleeve(-86,-268,-140,-220,-116,-176);pzBlob(g,'#1a0a14',()=>{g.ellipse(-116,-174,18,10,.3,0,TAU)},3);
 pzBlob(g,fur,()=>{g.ellipse(-112,-166,18,14,0,0,TAU)},3.4);pzEll(g,'#ffd24a',-112,-160,8,6,0,2.6);
 /* the jacket */
 pzdcBk(g,'hjacket',-126,-306,252,220,g=>{const velv=pzGr(g,'pzdc_hvel',-100,-300,100,-90,[[0,'#e83a50'],[.5,'#a8142e'],[1,'#5a0618']]);const jk=()=>{g.moveTo(-88,-286);g.quadraticCurveTo(-118,-276,-112,-230);g.lineTo(-104,-110);g.quadraticCurveTo(0,-94,104,-110);g.lineTo(112,-230);g.quadraticCurveTo(118,-276,88,-286);g.quadraticCurveTo(0,-300,-88,-286)};
 pzBlob(g,velv,jk,4.5);
 g.save();g.beginPath();jk();g.clip();g.fillStyle='rgba(255,190,200,.16)';g.beginPath();g.ellipse(-60,-230,22,60,.1,0,TAU);g.fill();g.fillStyle='rgba(40,0,10,.25)';g.beginPath();g.ellipse(80,-170,30,90,0,0,TAU);g.fill();g.restore();
 /* shirt and ascot */
 pzBlob(g,'#fff8ee',()=>{g.moveTo(-34,-290);g.lineTo(0,-196);g.lineTo(34,-290);g.closePath()},3);
 pzBlob(g,'#ffcf48',()=>{g.moveTo(-16,-290);g.quadraticCurveTo(0,-280,16,-290);g.lineTo(10,-250);g.quadraticCurveTo(0,-240,-10,-250);g.closePath()},3);pzEll(g,'#e8263a',0,-266,5,5,0,2);
 /* black satin shawl lapels with a gold edge */
 for(const s of[-1,1]){pzBlob(g,'#1a0a1a',()=>{g.moveTo(s*34,-292);g.quadraticCurveTo(s*58,-270,s*50,-220);g.quadraticCurveTo(s*30,-194,s*4,-180);g.lineTo(0,-196);g.quadraticCurveTo(s*26,-230,s*22,-290);g.closePath()},3.4);
  g.strokeStyle='rgba(255,255,255,.18)';g.lineWidth=3;g.beginPath();g.moveTo(s*40,-276);g.quadraticCurveTo(s*48,-250,s*40,-226);g.stroke()}
 g.strokeStyle='#ffcf48';g.lineWidth=2.6;g.beginPath();g.moveTo(34,-292);g.quadraticCurveTo(58,-270,50,-220);g.quadraticCurveTo(30,-194,4,-180);g.moveTo(-34,-292);g.quadraticCurveTo(-58,-270,-50,-220);g.quadraticCurveTo(-30,-194,-4,-180);g.stroke();
 /* gold frog closures */
 for(let i=0;i<3;i++){const y=-176+i*22;g.strokeStyle=PZ_O;g.lineWidth=6;g.beginPath();g.moveTo(-22,y);g.lineTo(22,y);g.stroke();g.strokeStyle='#ffcf48';g.lineWidth=3;g.stroke();pzEll(g,'#ffcf48',-24,y,4.5,4.5,0,2);pzEll(g,'#ffcf48',24,y,4.5,4.5,0,2)}
 /* a pocket square */
 pzBlob(g,'#ffcf48',()=>{g.moveTo(58,-226);g.lineTo(64,-238);g.lineTo(70,-228);g.lineTo(76,-238);g.lineTo(82,-226);g.closePath()},2.4);g.strokeStyle='#1a0a1a';g.lineWidth=3;g.beginPath();g.moveTo(54,-224);g.lineTo(86,-224);g.stroke();
});
 /* the right arm with the riffling chip stack (tossed up on a cheer, scattered when rattled) */
 {const hx=96,hy=-176-M.ch*40+M.sad*18;sleeve(86,-268,140,-232,hx+8,hy+6);pzBlob(g,'#1a0a14',()=>{g.ellipse(hx+8,hy+8,18,10,-.3,0,TAU)},3);
  const cols=['#e8263a','#1a1a2a','#3ac85a','#ffcf48','#2a6ae8','#e8263a','#1a1a2a','#ffcf48'];
  for(let i=0;i<8;i++){let lift=Math.max(0,Math.sin(t*5.5-i*.7))*5,x=hx,y=hy-8-i*7-lift;if(M.ch>.1){const ph=(t*1.4+i/8)%1;y-=M.ch*(Math.sin(ph*Math.PI)*90+i*4);x+=M.ch*Math.sin(i*2.1)*26*ph}if(M.rat>.1){x+=Math.sin(t*17+i*1.9)*14*M.rat;y+=Math.cos(t*13+i)*6*M.rat}
   const cc=cols[i];g.save();g.translate(x,y);pzdcBk(g,'hchip'+cc,-19,-9,38,18,g=>{g.fillStyle=cc;g.strokeStyle=PZ_O;g.lineWidth=2.2;g.beginPath();g.ellipse(0,0,16,5.5,0,0,TAU);g.fill();g.stroke();g.strokeStyle='rgba(255,255,255,.75)';g.lineWidth=2;g.setLineDash([3,4]);g.beginPath();g.ellipse(0,0,12,3.6,0,0,TAU);g.stroke();g.setLineDash([])});g.restore()}
  pzBlob(g,fur,()=>{g.ellipse(hx,hy+2,20,14,0,0,TAU)},3.4);g.strokeStyle=PZ_O;g.lineWidth=2;g.beginPath();g.moveTo(hx-6,hy-8);g.lineTo(hx-6,hy+6);g.moveTo(hx+6,hy-8);g.lineTo(hx+6,hy+6);g.stroke();pzEll(g,'#ffd24a',hx+12,hy-2,4,5,0,2)}
 /* the head */
 g.save();g.translate(0,-326+p.bob);g.rotate(p.tilt*.55+M.sad*.07-M.ch*.06*Math.sin(t*9));g.translate(0,M.sad*8-M.ch*4);g.scale(1.14,1.14);
 /* neck */
 pzBlob(g,furD,()=>{g.roundRect(-40,8,80,26,8)},3.6);
 /* horns: big curved, gold caps; they jolt on a wow */
 for(const s of[-1,1]){const hl=-M.sad*.12+M.wow*.08;g.save();g.translate(s*42,-48);g.rotate(s*hl);
  pzdcBk(g,'hhorn'+s,s>0?-12:-106,-100,118,118,g=>{pzBlob(g,pzGr(g,'pzdc_hhorn',0,-90,0,0,[[0,'#fff6e0'],[1,'#c8b088']]),()=>{g.moveTo(0,10);g.bezierCurveTo(s*40,6,s*88,-6,s*96,-62);g.lineTo(s*82,-62);g.bezierCurveTo(s*74,-24,s*36,-14,-s*6,-14);g.closePath()},4);
  g.strokeStyle='rgba(120,90,50,.5)';g.lineWidth=2;for(let i=1;i<4;i++){const x=s*(20+i*16),y=-6-i*10;g.beginPath();g.moveTo(x,y+12);g.lineTo(x+s*10,y-2);g.stroke()}
  pzBlob(g,'#ffcf48',()=>{g.moveTo(s*80,-56);g.lineTo(s*98,-58);g.quadraticCurveTo(s*100,-82,s*92,-92);g.quadraticCurveTo(s*80,-80,s*80,-56)},3);g.fillStyle='rgba(255,255,255,.6)';g.fillRect(s*86-2,-74,3,12);});g.restore()}
 /* ears: droop when sad, perk on a wow */
 for(const s of[-1,1]){const ea=s*(.25+M.sad*.6-M.wow*.35+Math.sin(t*1.7+s)*.05);g.save();g.translate(s*56,-30);g.rotate(ea);pzBlob(g,fur,()=>{g.ellipse(s*22,0,26,12,0,0,TAU)},3.4);pzEll(g,'#e88a8a',s*24,1,15,6,0,0);g.restore()}
 /* skull and muzzle */
 pzdcBk(g,'hskull',-74,-96,148,134,g=>{const furD='#4a2410';
 pzBlob(g,pzGr(g,'pzdc_hhead',0,-70,0,40,[[0,'#8a5028'],[1,'#4a2410']]),()=>{g.moveTo(-66,-46);g.bezierCurveTo(-66,-80,-34,-84,0,-84);g.bezierCurveTo(34,-84,66,-80,66,-46);g.bezierCurveTo(64,-14,44,4,40,30);g.lineTo(-40,30);g.bezierCurveTo(-44,4,-64,-14,-66,-46)},4.5);g.fillStyle='rgba(30,10,0,.3)';g.beginPath();g.moveTo(-50,-44);g.quadraticCurveTo(0,-30,50,-44);g.quadraticCurveTo(0,-38,-50,-44);g.fill();
 /* curly forelock */
 g.fillStyle=furD;g.strokeStyle=PZ_O;g.lineWidth=3;for(let i=0;i<4;i++){g.beginPath();g.arc(-21+i*14,-74+Math.abs(i-1.5)*4,10,0,TAU);g.fill();g.stroke()}
});
 /* eyes, brows */
 for(const s of[-1,1])pznEye(g,s*25,-32,11.5,ex,{iris:'#8a4a10',skin:'#6a3a1c',side:s,lw:2.8,pr:.58});
 pzBrowD(g,-24,-46,22,ex,-1,'#3a1a08',6);pzBrowD(g,24,-46,22,ex,1,'#3a1a08',6);
 /* the monocle on his right eye, on a gold chain; it drops on a wow */
 {const dropK=M.wow,mx=25+dropK*10,my=-32+dropK*58+Math.sin(t*3)*dropK*4;
  g.strokeStyle='#ffcf48';g.lineWidth=1.8;g.setLineDash([3,2]);g.beginPath();g.moveTo(mx+15,my+4);g.quadraticCurveTo(52,30+dropK*10,46,72);g.stroke();g.setLineDash([]);
  g.fillStyle='rgba(200,240,255,.28)';g.beginPath();g.arc(mx,my,15,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=6;g.stroke();g.strokeStyle='#ffcf48';g.lineWidth=3.4;g.stroke();
  const gl=((t*.4)%1);if(gl<.25){g.save();g.beginPath();g.arc(mx,my,13,0,TAU);g.clip();g.fillStyle='rgba(255,255,255,.75)';g.save();g.translate(mx-20+gl*160,my);g.rotate(.6);g.fillRect(-3,-20,6,40);g.restore();g.restore()}
  else{g.fillStyle='rgba(255,255,255,.7)';g.beginPath();g.ellipse(mx-6,my-6,4,2.4,-.6,0,TAU);g.fill()}}
 /* muzzle */
 pzdcBk(g,'hmuzzle',-64,-30,128,76,g=>{
 pzBlob(g,pzGr(g,'pzdc_hmz',0,-20,0,40,[[0,'#d8a476'],[1,'#a8744a']]),()=>{g.moveTo(-40,-14);g.quadraticCurveTo(0,-22,40,-14);g.quadraticCurveTo(58,8,46,28);g.quadraticCurveTo(0,42,-46,28);g.quadraticCurveTo(-58,8,-40,-14)},4);
});
 for(const s of[-1,1]){const fl=M.ang*3+(M.ang>.2?Math.abs(Math.sin(t*5))*3:0);pzEll(g,'#2a1008',s*18,2,8+fl*.6,10-M.ang*2,s*.55,0);g.strokeStyle='rgba(30,10,0,.5)';g.lineWidth=2;g.beginPath();g.arc(s*18,2,13,s>0?-2.4:-.7,s>0?-1.6:.1+-.7+.1);g.stroke()}
 /* nose ring */
 {const rs=Math.sin(t*2.1)*.12+(M.rat>.1?Math.sin(t*20)*.3*M.rat:0);g.save();g.translate(0,8);g.rotate(rs);g.strokeStyle=PZ_O;g.lineWidth=7;g.beginPath();g.arc(0,8,10,.1,Math.PI*2-.1+.1);g.stroke();g.strokeStyle='#ffcf48';g.lineWidth=4;g.stroke();g.fillStyle='rgba(255,255,255,.8)';g.fillRect(-7,10,3,3);g.restore()}
 pzMouthD(g,0,26,34,ex,{in:'#3a0a18',tongue:'#e86a7a',line:'#3a1a10',lw:3.2});
 pzBlush(g,-38,6,9,ex);pzBlush(g,38,6,9,ex);
 pzSweat(g,-52,-50,t,ex);
 /* snorts: steam jets from the nostrils when angry, a small idle snort every 7 s */
 {const idle=pzdcCl(1-Math.abs(((t%7)-.5)/.5))*.5,k=Math.max(M.ang,idle);if(k>.05)for(const s of[-1,1])for(let i=0;i<3;i++){const ph=(t*2.4+i/3)%1;pzdcPuff(g,s*(18+ph*46),4+ph*24,6+ph*10,'#f4f0f4',k*(1-ph)*.85)}}
 g.restore();
 g.restore();g.restore()};

/* ================= Aurelion the Hoardwing: the gold dragon banker (boss) ================= */
let PZDC_HOARD=null;
/* the coin hoard, baked once at 2x: local x -200..200, y -120..12 */
function pzdcHoard(){if(PZDC_HOARD)return PZDC_HOARD;const S=2,W=400,H=132,c=pzCv(W*S,H*S),g=c.getContext('2d');g.scale(S,S);g.translate(200,120);g.lineJoin='round';g.lineCap='round';
 let sd=7;const rnd=()=>{sd=(sd*16807)%2147483647;return(sd-1)/2147483646};
 pzBlob(g,(()=>{const q=g.createLinearGradient(0,-110,0,10);q.addColorStop(0,'#ffe27a');q.addColorStop(.6,'#e0a028');q.addColorStop(1,'#9a600e');return q})(),()=>{g.moveTo(-196,6);g.bezierCurveTo(-170,-60,-90,-104,0,-106);g.bezierCurveTo(90,-104,170,-60,196,6);g.closePath()},4);
 for(let i=0;i<110;i++){const u=rnd()*2-1,x=u*184,top=-Math.sqrt(Math.max(0,1-u*u))*100,y=top+rnd()*(-top+4)*.9+4;pzdcCoin(g,x,y,7+rnd()*5,.35+rnd()*.3,1.8)}
 const gc=['#ff2a4a','#2ad8a0','#3a8aff','#c84aff','#ff2a4a','#2ad8a0'];for(let i=0;i<14;i++){const u=rnd()*1.8-.9,x=u*170,top=-Math.sqrt(Math.max(0,1-u*u))*96,y=top+rnd()*(-top)*.8+6;pzdcGem(g,x,y,6+rnd()*5,gc[i%6],2)}
 /* a goblet and a crown peeking out */
 g.save();g.translate(-120,-40);pzBlob(g,'#ffd24a',()=>{g.moveTo(-14,-24);g.lineTo(14,-24);g.quadraticCurveTo(12,-4,3,0);g.lineTo(3,10);g.lineTo(10,14);g.lineTo(-10,14);g.lineTo(-3,10);g.lineTo(-3,0);g.quadraticCurveTo(-12,-4,-14,-24)},2.6);pzdcGem(g,0,-12,4,'#ff2a4a',1.6);g.restore();
 g.save();g.translate(132,-34);g.rotate(.25);pzBlob(g,'#ffd24a',()=>{g.moveTo(-16,6);g.lineTo(-18,-12);g.lineTo(-8,-4);g.lineTo(0,-16);g.lineTo(8,-4);g.lineTo(18,-12);g.lineTo(16,6);g.closePath()},2.6);pzdcGem(g,0,0,3.6,'#3a8aff',1.4);g.restore();
 return PZDC_HOARD=c}
pzMon.aurelion=function(g,t,ex,p){const M=pzdcMood(ex),shk=M.rat>.04?Math.sin(t*39)*2.4*M.rat:0;
 const gold=pzGr(g,'pzdc_agold',-120,-360,120,-60,[[0,'#fff2a8'],[.4,'#f2c040'],[1,'#a8680e']]),goldD='#b8780e',belly='#fff0b8';
 pzEll(g,'rgba(0,0,0,.3)',0,4,200,14,0,0);pzGlow(g,0,-50,120,'rgba(255,200,80,1)',.24);
 g.save();g.translate(shk,0);
 /* folded wings behind: they lift on a cheer and an angry flare, droop when sad */
 const wl=M.ch*.18+M.ang*.22-M.sad*.16+Math.sin(t*.9)*.03;
 for(const s of[-1,1]){g.save();g.translate(s*60,-250);g.rotate(-s*wl);g.scale(.86,.86);pzdcBk(g,'awing'+s,s>0?-12:-146,-120,158,240,g=>{
  pzBlob(g,pzGr(g,'pzdc_awing',0,-120,0,140,[[0,'#e8782a'],[1,'#8a2a14']]),()=>{g.moveTo(0,0);g.lineTo(s*96,-86);g.quadraticCurveTo(s*120,-20,s*134,60);g.quadraticCurveTo(s*112,56,s*108,90);g.quadraticCurveTo(s*86,76,s*70,110);g.quadraticCurveTo(s*48,90,s*20,90);g.closePath()},4);
  g.strokeStyle='rgba(60,10,0,.55)';g.lineWidth=2.6;g.beginPath();g.moveTo(s*96,-86);g.lineTo(s*110,60);g.moveTo(s*96,-86);g.lineTo(s*72,104);g.moveTo(s*96,-86);g.lineTo(s*24,88);g.stroke();
  g.lineCap='round';g.strokeStyle=PZ_O;g.lineWidth=14;g.beginPath();g.moveTo(0,0);g.lineTo(s*96,-86);g.stroke();g.strokeStyle='#f2c040';g.lineWidth=8;g.stroke();
  pzBlob(g,'#fff6e0',()=>{g.moveTo(s*92,-82);g.lineTo(s*110,-110);g.lineTo(s*102,-78);g.closePath()},2.6)});g.restore()}
 g.save();g.scale(1,1+p.breath*.7);
 /* body: seated, belly plates */
 pzdcBk(g,'abody',-132,-276,264,226,g=>{const gold=pzGr(g,'pzdc_agold',-120,-360,120,-60,[[0,'#fff2a8'],[.4,'#f2c040'],[1,'#a8680e']]);const body=()=>{g.moveTo(-70,-250);g.bezierCurveTo(-120,-210,-128,-110,-100,-70);g.quadraticCurveTo(0,-50,100,-70);g.bezierCurveTo(128,-110,120,-210,70,-250);g.quadraticCurveTo(0,-268,-70,-250)};
 pzBlob(g,gold,body,5);
 g.save();g.beginPath();body();g.clip();g.fillStyle='rgba(120,60,0,.18)';for(let i=0;i<5;i++)for(let j=0;j<6;j++){const x=-110+j*44+(i%2)*22,y=-240+i*36;g.beginPath();g.arc(x,y,14,0,Math.PI);g.fill()}
 g.fillStyle='rgba(255,255,255,.25)';g.beginPath();g.ellipse(-74,-180,14,46,.2,0,TAU);g.fill();g.restore();
 pzBlob(g,pzGr(g,'pzdc_abel',0,-250,0,-70,[[0,'#fff8d8'],[1,'#f0c878']]),()=>{g.moveTo(-40,-246);g.quadraticCurveTo(-64,-160,-54,-74);g.quadraticCurveTo(0,-62,54,-74);g.quadraticCurveTo(64,-160,40,-246);g.quadraticCurveTo(0,-256,-40,-246)},3.6);
 g.strokeStyle='rgba(160,100,20,.7)';g.lineWidth=2.4;for(let i=1;i<7;i++){const y=-246+i*25,w=40+Math.sin(i/7*Math.PI)*16;g.beginPath();g.moveTo(-w,y);g.quadraticCurveTo(0,y+6,w,y);g.stroke()}
});
 /* the hoard in front */
 g.restore();
 g.drawImage(pzdcHoard(),-200,-120,400,132);
 /* hind feet resting on the coins */
 pzdcBk(g,'afeet',-148,-152,296,108,g=>{const gold=pzGr(g,'pzdc_agold',-120,-360,120,-60,[[0,'#fff2a8'],[.4,'#f2c040'],[1,'#a8680e']]);
 for(const s of[-1,1]){pzBlob(g,gold,()=>{g.ellipse(s*92,-104,40,44,s*.4,0,TAU)},4.5);g.fillStyle='rgba(120,60,0,.2)';g.beginPath();g.ellipse(s*100,-96,24,30,s*.4,0,TAU);g.fill();
  pzBlob(g,gold,()=>{g.moveTo(s*84,-60);g.quadraticCurveTo(s*86,-86,s*112,-84);g.quadraticCurveTo(s*140,-80,s*140,-58);g.closePath()},4);
  for(let i=0;i<3;i++)pzBlob(g,'#fff6e0',()=>{const x=s*(94+i*16);g.moveTo(x-5,-60);g.lineTo(x+s*2,-50);g.lineTo(x+5,-60);g.closePath()},2.2)}
});
 /* the tail curls round the front of the pile; the tip flicks */
 {const fk=Math.sin(t*1.6)*16+M.ch*Math.sin(t*10)*14;
  const gg=g,spines=(L,w0,w1,c)=>{const g=c||gg;const P=L.pts,n=P.length-1;g.fillStyle='#e8782a';g.strokeStyle=PZ_O;g.lineWidth=2.2;for(let i=1;i<n;i+=2){const w=(w0+(w1-w0)*i/n)/2,x=P[i][0],y=P[i][1]-w;g.beginPath();g.moveTo(x-6,y+3);g.lineTo(x+1,y-10);g.lineTo(x+6,y+3);g.closePath();g.fill();g.stroke()}};
  pzdcBk(g,'atail',20,-104,190,96,g=>{const gold=pzGr(g,'pzdc_agold',-120,-360,120,-60,[[0,'#fff2a8'],[.4,'#f2c040'],[1,'#a8680e']]);const L=pznLimb(g,118,-74,176,-20,40,-30,34,22,gold,4,0);spines(L,34,22,g)});
  const L2=pznLimb(g,44,-30,-70,-34,-136+fk*.4,-58+fk*.3,22,9,gold,4,-.7);spines(L2,22,9);
  const e=L2.pts[L2.pts.length-1];pzBlob(g,'#e8782a',()=>{g.moveTo(e[0]+2,e[1]-16);g.lineTo(e[0]-16,e[1]);g.lineTo(e[0]+2,e[1]+14);g.lineTo(e[0]+8,e[1]);g.closePath()},3)}
 g.save();g.scale(1,1+p.breath*.7);
 /* the ledger (left claw) and a quill (right claw); a page turns every 7 s */
 {const bx=-30,by=-142+M.sad*10-M.ch*6,turn=pzdcCl(((t%7)-6)/1);g.save();g.translate(bx,by);g.rotate(-.1);
 pzdcBk(g,'abook',-68,-14,136,62,g=>{
  pzBlob(g,'#5a1420',()=>{g.roundRect(-62,-8,124,52,6)},4);
  pzBlob(g,'#fff6e0',()=>{g.moveTo(0,0);g.quadraticCurveTo(-30,-10,-56,-2);g.lineTo(-56,40);g.quadraticCurveTo(-30,32,0,42);g.closePath()},3);
  pzBlob(g,'#fff6e0',()=>{g.moveTo(0,0);g.quadraticCurveTo(30,-10,56,-2);g.lineTo(56,40);g.quadraticCurveTo(30,32,0,42);g.closePath()},3);
  g.strokeStyle='rgba(90,60,40,.6)';g.lineWidth=1.6;for(let i=0;i<5;i++){g.beginPath();g.moveTo(-48,6+i*7);g.lineTo(-10,8+i*7);g.moveTo(10,8+i*7);g.lineTo(48-(i===4?20:0),6+i*7);g.stroke()}
  g.fillStyle='#2aa86a';g.font='800 9px Poppins,sans-serif';g.textAlign='right';g.fillText('+50k',46,34);
});
  if(turn>0&&turn<1){const k=Math.cos(turn*Math.PI);g.save();g.scale(k,1);pzBlob(g,k>0?'#fff6e0':'#f0e0c0',()=>{g.moveTo(0,0);g.quadraticCurveTo(30,-14,56,-6);g.lineTo(56,38);g.quadraticCurveTo(30,30,0,42);g.closePath()},2.6);g.restore()}
  g.strokeStyle='#e8263a';g.lineWidth=3;g.beginPath();g.moveTo(4,42);g.lineTo(8,62);g.stroke();g.restore();
  /* claws holding it */
  for(const s of[-1,1]){const cx=bx+s*58,cy=by+26;pzBlob(g,gold,()=>{g.ellipse(cx,cy,14,12,0,0,TAU)},3.4)}
  /* the quill in the right claw writes */
  const qx=bx+38+Math.sin(t*4)*6,qy=by+8+Math.abs(Math.sin(t*8))*2;g.save();g.translate(qx,qy);g.rotate(-.7);pzBlob(g,'#fff6e0',()=>{g.moveTo(0,0);g.quadraticCurveTo(8,-30,4,-56);g.quadraticCurveTo(-8,-30,0,0)},2.4);g.strokeStyle='rgba(120,100,80,.6)';g.lineWidth=1.4;g.beginPath();g.moveTo(1,-4);g.lineTo(3,-50);g.stroke();g.restore()}
 g.restore();
 /* the neck and head */
 const nx=Math.sin(t*.8)*8+p.tilt*40,hy=-372+p.bob+M.sad*20-M.ch*8;
 pznLimb(g,0,-226,-30+nx*.5,-300,nx,hy+30,64,44,gold,4.5,0);
 g.strokeStyle='rgba(160,100,20,.6)';g.lineWidth=2.4;for(let i=0;i<4;i++){const u=.2+i*.2,x=(1-u)*(1-u)*0+2*(1-u)*u*(-30+nx*.5)+u*u*nx,y=(1-u)*(1-u)*(-226)+2*(1-u)*u*(-300)+u*u*(hy+30);g.beginPath();g.moveTo(x-14,y);g.quadraticCurveTo(x,y+5,x+14,y);g.stroke()}
 g.save();g.translate(nx,hy);g.rotate(p.tilt*.5+M.sad*.08+(M.ch>.3?-.12*M.ch:0));g.scale(1.3,1.3);
 /* back spines / frills */
  pzdcBk(g,'ahead',-86,-88,172,116,g=>{const gold=pzGr(g,'pzdc_agold',-120,-360,120,-60,[[0,'#fff2a8'],[.4,'#f2c040'],[1,'#a8680e']]);
for(const s of[-1,1]){pzBlob(g,'#e8782a',()=>{g.moveTo(s*40,-6);g.lineTo(s*76,-22);g.lineTo(s*62,-2);g.lineTo(s*80,8);g.lineTo(s*44,14);g.closePath()},3)}
 /* horns */
 for(const s of[-1,1])pzBlob(g,pzGr(g,'pzdc_ahorn',0,-80,0,-20,[[0,'#fffaf0'],[1,'#d8c098']]),()=>{g.moveTo(s*20,-34);g.bezierCurveTo(s*30,-60,s*60,-74,s*78,-80);g.bezierCurveTo(s*58,-60,s*44,-40,s*36,-24);g.closePath()},3.4);
 /* skull */
 pzBlob(g,gold,()=>{g.moveTo(-46,0);g.bezierCurveTo(-50,-36,-26,-50,0,-50);g.bezierCurveTo(26,-50,50,-36,46,0);g.bezierCurveTo(44,14,30,20,0,22);g.bezierCurveTo(-30,20,-44,14,-46,0)},4.5);
});
 /* the crown */
 {const cy=-46-M.wow*10;pzBlob(g,'#ffd24a',()=>{g.moveTo(-20,cy+4);g.lineTo(-22,cy-14);g.lineTo(-11,cy-6);g.lineTo(0,cy-20);g.lineTo(11,cy-6);g.lineTo(22,cy-14);g.lineTo(20,cy+4);g.closePath()},3);pzdcGem(g,0,cy-4,4.5,'#ff2a4a',1.6);pzEll(g,'#3a8aff',-16,cy-1,2.6,2.6,0,1.2);pzEll(g,'#3a8aff',16,cy-1,2.6,2.6,0,1.2)}
 /* eyes (glow when angry), brow ridges */
 if(M.ang>.1)for(const s of[-1,1])pzGlow(g,s*20,-20,30,'rgba(255,80,30,1)',.8*M.ang);
 for(const s of[-1,1])pznEye(g,s*20,-20,10.5,ex,{white:M.ang>.3?'#ffe08a':'#fffbe8',iris:M.ang>.3?'#ff4a1a':'#e8a020',pupil:PZ_O,skin:'#e8b040',side:s,lw:2.8,slit:1,pr:.6});
 pzBrowD(g,-20,-36,22,ex,-1,goldD,6);pzBrowD(g,20,-36,22,ex,1,goldD,6);
 /* snout */
 pzdcBk(g,'asnout',-40,-10,80,66,g=>{
 pzBlob(g,pzGr(g,'pzdc_asn',0,-10,0,50,[[0,'#ffe68a'],[1,'#d89a28']]),()=>{g.moveTo(-34,0);g.bezierCurveTo(-36,30,-24,50,0,52);g.bezierCurveTo(24,50,36,30,34,0);g.quadraticCurveTo(0,-8,-34,0)},4);
 for(const s of[-1,1])pzEll(g,'#5a2a08',s*11,20,4.5,3.4,s*.4,0);
});
 /* the mouth line / open jaw; fire breath on a cheer */
 {const w=40,op=ex.ma*16+M.ch*10;g.save();g.translate(0,38);if(op>3){pzBlob(g,'#4a0a10',()=>{g.moveTo(-w/2,0);g.quadraticCurveTo(0,ex.mo*8,w/2,0);g.quadraticCurveTo(0,op*1.4+ex.mo*6,-w/2,0)},3);g.fillStyle='#fff';for(const s of[-1,1]){g.beginPath();g.moveTo(s*12,1);g.lineTo(s*9,7);g.lineTo(s*6,1);g.closePath();g.fill()}}
  else{g.strokeStyle=PZ_O;g.lineWidth=3.2;g.beginPath();g.moveTo(-w/2,0);g.quadraticCurveTo(0,ex.mo*10,w/2,0);g.stroke()}g.restore()}
 if(M.ch>.15){const f=M.ch;g.save();g.translate(14,44);g.rotate(.8);pzGlow(g,0,-40,90,'rgba(255,160,40,1)',.55*f);
  for(let i=0;i<3;i++){const ph=(t*3+i/3)%1,sc=f*(.6+ph*.8),a=(1-ph)*f;g.globalAlpha=a;g.fillStyle=['#ff5a1a','#ffa82a','#fff0a0'][i];g.save();g.translate(Math.sin(t*9+i)*6,-ph*30);g.scale(sc,sc);g.beginPath();g.moveTo(-22,0);g.bezierCurveTo(-30,-40,-6,-70,0,-120+i*24);g.bezierCurveTo(6,-70,30,-40,22,0);g.quadraticCurveTo(0,10,-22,0);g.fill();g.restore()}g.globalAlpha=1;g.restore()}
 /* the half-moon spectacles low on the snout (the eyes peer over); they jump up on a wow, go askew when rattled */
 {const sy=-6-M.wow*30,ra=M.rat*Math.sin(t*12)*.12+M.rat*.12;g.save();g.translate(0,sy);g.rotate(ra);g.strokeStyle=PZ_O;g.lineWidth=5.5;
  for(const s of[-1,1]){g.beginPath();g.arc(s*20,0,13,0,Math.PI);g.closePath();g.fillStyle='rgba(210,240,255,.3)';g.fill();g.stroke()}
  g.strokeStyle='#ffd24a';g.lineWidth=2.8;for(const s of[-1,1]){g.beginPath();g.arc(s*20,0,13,0,Math.PI);g.closePath();g.stroke()}g.beginPath();g.moveTo(-7,1);g.quadraticCurveTo(0,-5,7,1);g.stroke();
  g.fillStyle='rgba(255,255,255,.7)';g.fillRect(-28,3,5,2.4);g.fillRect(12,3,5,2.4);g.restore()}
 pzBlush(g,-34,12,9,ex,'#ff8a5a');pzBlush(g,34,12,9,ex,'#ff8a5a');
 pzSweat(g,44,-30,t,ex);
 /* smoke from the nostrils: lazy wisps; thick and dark when angry, thin when sad */
 {const k=.45+M.ang*.5-M.sad*.25,col=M.ang>.3?'#6a5a5a':'#e8e0e8';for(const s of[-1,1])for(let i=0;i<3;i++){const ph=(t*.7+i/3+(s>0?.5:0))%1,x=s*(12+ph*14)+Math.sin(t*2+i+s)*8*ph,y=14-ph*70;pzdcPuff(g,x,y,4+ph*8,col,k*(1-ph)*.7)}}
 g.restore();
 g.restore()};
/* heights for PZ_MONH (the venue data 97bb owns them; these only fill in what is missing) */
{const h={clasp:330,zephyra:410,brass:400,hornsby:440,aurelion:460};for(const k in h)if(!PZ_MONH[k])PZ_MONH[k]=h[k]}
/* medallion busts [top, bottom, x] for pz97Bust (the venue module may set its own; these only fill in what is missing) */
try{const b={clasp:[-352,-96,0],zephyra:[-430,-236,0],brass:[-414,-236,0],hornsby:[-456,-250,0],aurelion:[-492,-284,0]};for(const k in b)if(!PZ97_BUST[k])PZ97_BUST[k]=b[k]}catch(e){}
