import asyncio,os
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append('PE '+str(e)[:300]))
        await pg.goto('file://'+os.path.abspath('out.html'));await pg.wait_for_timeout(900);E=pg.evaluate;bad=0
        await E("()=>{RS_ASK=false;P.gold=100;P.petSt=2;P.pets={ember:{b:10}};P.pet='ember';P.eggs={r:0,l:0,m:0};P.ccUsed={};petNorm();save();title()}");await pg.wait_for_timeout(300)
        # redeem through the real box, typed in lowercase as it appears in the notes
        await E("()=>ccAsk()");await pg.wait_for_timeout(200);await pg.fill('#ccin','newupdatecoins81');await pg.keyboard.press('Enter');await pg.wait_for_timeout(1600)
        r=await E("()=>[P.gold,P.eggs.r,!!document.querySelector('#ccfx .ccegg'),(document.querySelector('#ccfx .ccegg b')||{}).textContent,!!P.ccUsed.NEWUPDATECOINS81]")
        ok=r[0]==1600 and r[1]==1 and r[2];bad+=not ok;print('redeem',r,'OK' if ok else 'BAD')
        await pg.screenshot(path='shots/code81_reward.png')
        await E("()=>{const b=document.querySelector('#ccfx .ccok');if(b)b.click();ccStop()}");await pg.wait_for_timeout(400)
        # second try on the same save
        r=await E("async()=>{const x=await ccRedeem('NEWUPDATECOINS81');return [x.ok,x.m,P.gold,P.eggs.r]}")
        ok=r[0]==0 and r[2]==1600 and r[3]==1;bad+=not ok;print('again same save',r,'OK' if ok else 'BAD')
        # survives a reload of the save
        await E("()=>{load(JSON.parse(JSON.stringify(P)))}")
        r=await E("async()=>{const x=await ccRedeem('newupdatecoins81');return [x.ok,P.eggs.r]}");ok=r[0]==0;bad+=not ok;print('after reload',r,'OK' if ok else 'BAD')
        # a different save (another account) can still redeem it once
        await E("()=>{P.ccUsed={};P.gold=0;P.eggs={r:0,l:0,m:0};save()}")
        r=await E("async()=>{const x=await ccRedeem('NewUpdateCoins81');return [x.ok,P.gold,P.eggs.r,x.m]}");ok=r[0]==1 and r[1]==1500 and r[2]==1;bad+=not ok;print('other save',r,'OK' if ok else 'BAD')
        await E("()=>ccStop()")
        # hidden in the Updates tab only
        await E("()=>{title()}");await pg.wait_for_timeout(300);await pg.click('#bell');await pg.wait_for_timeout(250);await pg.click('[data-bt=\"u\"]');await pg.wait_for_timeout(400)
        r=await E("()=>{const s=document.querySelector('#bellp .blsec');if(s)s.scrollIntoView({block:'center'});return [!!s,s&&s.textContent]}")
        ok=r[0];bad+=not ok;print('in updates',r,'OK' if ok else 'BAD');await pg.wait_for_timeout(200);await pg.screenshot(path='shots/code81_updates.png')
        await pg.click('[data-bt=\"n\"]');await pg.wait_for_timeout(300)
        r=await E("()=>document.getElementById('bellp').textContent.toLowerCase().includes('newupdatecoins81')");ok=not r;bad+=not ok;print('not in news',not r,'OK' if ok else 'BAD')
        print('bad',bad);print(er);await b.close()
asyncio.run(main())
