# Embedded in a website with a box taller than the screen, the game fits the visible screen height.
import asyncio,os,sys,threading,http.server,functools,socketserver
from playwright.async_api import async_playwright
ROOT=os.path.abspath('.');PORT=18475
def page(h,pad=0):return f'<!doctype html><body style="margin:0;background:#fff"><div style="height:{pad}px;background:#000"></div><iframe id="g" src="/out.html" style="width:100%;height:{h}px;border:0;display:block"></iframe></body>'
class H(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path.startswith('/p'):q=dict(x.split('=') for x in self.path.split('?')[1].split('&'));b=page(int(q['h']),int(q.get('pad',0))).encode();self.send_response(200);self.send_header('Content-Type','text/html');self.end_headers();self.wfile.write(b);return
        return super().do_GET()
    def log_message(self,*a):pass
async def main():
    socketserver.ThreadingTCPServer.allow_reuse_address=True;srv=socketserver.ThreadingTCPServer(('127.0.0.1',PORT),functools.partial(H,directory=ROOT));threading.Thread(target=srv.serve_forever,daemon=True).start()
    bad=0;er=[]
    def chk(n,v,ok):
        nonlocal bad;bad+=0 if ok else 1;print(n,v,'OK' if ok else 'BAD',flush=True)
    async with async_playwright() as p:
        b=await p.chromium.launch()
        async def run(h,top=False,pad=0):
            c=await b.new_context(viewport={'width':1366,'height':650},screen={'width':1366,'height':768});pg=await c.new_page();pg.on('pageerror',lambda e:er.append(str(e)[:200]))
            await pg.goto(f'http://127.0.0.1:{PORT}/'+('out.html' if top else f'p?h={h}&pad={pad}'));await pg.wait_for_timeout(2500)
            f=pg.main_frame if top else [x for x in pg.frames if x.url.endswith('/out.html')][0]
            r=await f.evaluate("()=>{const b=wrap.getBoundingClientRect();return {cap:FIT.cap,on:FIT.on,top:Math.round(b.top),bottom:Math.round(b.bottom),w:Math.round(b.width),ih:innerHeight,sh:screen.height,ah:screen.availHeight,oh:outerHeight}}")
            return pg,f,r
        pg,f,r=await run(1000);print('   ',r)
        chk('box 1000 px tall on a 768 px screen: the whole game is visible',r,r['on']==1 and r['top']<=1 and r['bottom']<=650 and r['w']>900)
        await pg.screenshot(path='shots/fit_tall_box.png')
        await f.evaluate("()=>{ST.fitscr='off';applyLayout()}");r2=await f.evaluate("()=>[FIT.on,Math.round(wrap.getBoundingClientRect().bottom)]");chk('setting Off restores the old fit',r2,r2[0]==0 and r2[1]>800)
        await f.evaluate("()=>{ST.fitscr='auto';applyLayout();settings()}");await pg.wait_for_timeout(400)
        await f.evaluate("()=>{const t=[...document.querySelectorAll('button')].find(b=>/Display/.test(b.textContent));if(t)t.click()}");await pg.wait_for_timeout(400)
        r3=await f.evaluate("()=>{const o=document.getElementById('fitopt');return o?[o.querySelector('label').textContent,o.querySelector('.on').textContent]:null}");chk('setting shown in Display',r3,r3==['Fit to screen on websites','On'])
        await pg.context.close()
        pg,f,r=await run(1000,pad=150);await pg.wait_for_timeout(800);r=await f.evaluate("()=>{const b=wrap.getBoundingClientRect();return {trim:FIT.trim,bottom:Math.round(b.bottom)}}");chk('banner or space above the game: still fully visible',r,150+r['bottom']<=651)
        await pg.screenshot(path='shots/fit_band_above.png');await pg.context.close()
        pg,f,r=await run(560);chk('box that already fits: unchanged',r,r['on']==0);await pg.context.close()
        pg,f,r=await run(0,True);chk('not embedded: unchanged',r,r['on']==0 and r['cap']==0);await pg.context.close()
        print('bad',bad);print(er[:5]);await b.close()
    srv.shutdown()
asyncio.run(main())
