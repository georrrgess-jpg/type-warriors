/* ---------- second armoury: mage staves and wands (frames as in drawW0: staff head at x=L*1.18, wand tip at x=L*.76) ---------- */
function wStaff(g,L,t,o){const top=L*1.04,ox=top+L*.14,N=22,P=[];for(let i=0;i<=N;i++){const u=i/N;P.push([-L*.34+u*(top+L*.34+L*.04),o.wob?o.wob(u)*3:0])}
 if(o.back)o.back(g,ox,top,L);
 rib(g,P,u=>(o.sw||3.4)*(o.sf?o.sf(u):1),o.c);grain(g,-L*.3,-2.4,top+L*.2,4.8,'#0005',36,3);
 wrapG(g,-L*.06,L*.16,0,3.5,o.grip||'#2a1a30');if(o.shaft)o.shaft(g,ox,top,L);
 o.head(g,ox,top,L)}
function wWand(g,L,t,o){const len=L*.68,ox=len+L*.08,N=18,P=[];for(let i=0;i<=N;i++){const u=i/N;P.push([-L*.14+u*(len+L*.16),o.wob?o.wob(u):0])}
 if(o.back)o.back(g,ox,len,L);
 rib(g,P,u=>(o.sw||2.8)*(o.sf?o.sf(u):1),o.c);wrapG(g,-L*.12,L*.1,0,3.1,o.grip||'#2a1a30');if(o.shaft)o.shaft(g,ox,len,L);
 o.tip(g,ox,len,L)}
const wflame=(g,x,y,h,w,t,i,a,rot)=>{const s=Math.sin(t*9+i*2.1)*.22;g.save();g.translate(x,y);g.rotate(rot==null?Math.PI/2:rot);g.globalAlpha=a==null?1:a;poly(g,[-w,0,-w*.5+h*s*.2,-h*.55,h*s,-h,w*.5+h*s*.2,-h*.5,w,0],'#ff9a2a');poly(g,[-w*.6,0,h*s*.5,-h*.7,w*.6,0],'#ffe070');poly(g,[-w*.3,0,h*s*.3,-h*.4,w*.3,0],'#fff8d0');g.restore()};

/* --- Sporecap Staff (common): a gnarled stick with moss, little mushrooms and a glowing cap on top --- */
WNEW.shroom=(g,L,t,X)=>wStaff(g,L,t,{c:X.c,sw:3.6,wob:u=>Math.sin(u*9)*.8+Math.sin(u*21)*.4,grip:'#3a4a2a',
 shaft:(g,ox,top)=>{for(let i=0;i<6;i++){const x=-L*.22+i*L*.2;g.fillStyle='#5a9a3a';g.beginPath();g.ellipse(x,(i%2?3:-3)*.8,L*.05,2.2,0,0,TAU);g.fill()}
  for(const [x,s] of[[L*.3,-1],[L*.56,1],[L*.8,-1]]){g.fillStyle='#f0e6d0';g.fillRect(x-1,s>0?3:-9,2.4,6);g.fillStyle='#d8503a';g.beginPath();g.ellipse(x,s>0?9:-9,4,2.6,0,0,TAU);g.fill();g.fillStyle='#fff';g.fillRect(x-1.6,(s>0?9:-9)-1,1.1,1.1)}},
 head:(g,ox,top)=>{const cx=ox-L*.02;g.fillStyle=vgr(g,-5,5,'#fff6e0','#c8b890');g.beginPath();g.moveTo(top-6,-3.4);g.quadraticCurveTo(top+L*.08,-1.8,cx+2,-L*.045);g.lineTo(cx+2,L*.045);g.quadraticCurveTo(top+L*.08,1.8,top-6,3.4);g.closePath();g.fill();g.strokeStyle='#0006';g.lineWidth=.8;g.stroke();
  g.save();g.globalCompositeOperation='lighter';glow(g,cx+L*.08,0,L*.34,'#7affd066');g.restore();
  g.beginPath();g.moveTo(cx,-L*.2);g.bezierCurveTo(cx+L*.2,-L*.2,cx+L*.3,-L*.06,cx+L*.3,0);g.bezierCurveTo(cx+L*.3,L*.06,cx+L*.2,L*.2,cx,L*.2);g.quadraticCurveTo(cx-L*.04,0,cx,-L*.2);g.closePath();g.fillStyle=rgr(g,cx+L*.1,-L*.05,2,L*.34,'#ff7a5a','#9a2a2a');g.fill();g.strokeStyle='#000a';g.lineWidth=1;g.stroke();
  g.strokeStyle='#f0d8b8aa';g.lineWidth=.8;for(let i=-4;i<=4;i++){g.beginPath();g.moveTo(cx+1,i*L*.04);g.lineTo(cx-L*.05,i*L*.046);g.stroke()}
  for(const [a,b,r] of[[.12,-.09,.035],[.2,.05,.045],[.1,.1,.028],[.27,-.02,.022],[.18,-.15,.025]]){ell(g,cx+L*a,L*b,L*r,L*r,'#fff0d0');ell(g,cx+L*a,L*b,L*r*.5,L*r*.5,'#8affd8aa')}
  g.save();g.globalCompositeOperation='lighter';for(let i=0;i<9;i++){const u=(t*.3+i/9)%1,a=i*2.3,x=cx+L*.2+u*L*.5,y=Math.sin(a+u*5)*L*.2*(.3+u);g.globalAlpha=Math.sin(u*Math.PI)*.9;glow(g,x,y,3+rnd(i)*3,i%2?'#a0ffd0':'#ffe880')}g.restore()}});
/* --- Wisp Lantern (uncommon): a shepherd's crook with a lantern and a living flame inside --- */
WNEW.lantern=(g,L,t,X)=>wStaff(g,L,t,{c:X.c,sw:3.3,grip:'#3a2a1a',
 head:(g,ox,top)=>{g.strokeStyle='#1a1410';g.lineWidth=7;g.beginPath();g.moveTo(top-4,0);g.bezierCurveTo(top+L*.18,0,top+L*.22,-L*.25,top+L*.04,-L*.25);g.stroke();g.strokeStyle=X.c;g.lineWidth=4.4;g.stroke();g.strokeStyle=wsh(X.c,.4);g.lineWidth=1;g.stroke();
  const lx=top-L*.07,ly=-L*.25,hw=L*.11,len=L*.2,sw=wsin(t,1.6,0)*.05;g.save();g.translate(top+L*.04,ly);g.rotate(sw);g.translate(-(top+L*.04),-ly);
  g.strokeStyle='#8a8a98';g.lineWidth=1.2;g.beginPath();g.moveTo(top+L*.04,ly);g.lineTo(top+L*.0,ly-hw*.6);g.moveTo(top+L*.04,ly);g.lineTo(top+L*.0,ly+hw*.6);g.stroke();
  const x0=top-L*.3,x1=top+L*.0;g.fillStyle='#10102088';g.beginPath();g.moveTo(x1,ly-hw*.6);g.lineTo(x1-L*.02,ly-hw);g.lineTo(x0+L*.02,ly-hw);g.lineTo(x0,ly-hw*.6);g.lineTo(x0,ly+hw*.6);g.lineTo(x0+L*.02,ly+hw);g.lineTo(x1-L*.02,ly+hw);g.lineTo(x1,ly+hw*.6);g.closePath();g.fill();
  g.save();g.globalCompositeOperation='lighter';glow(g,(x0+x1)/2,ly,L*.28,'#7ad8ff88');g.restore();
  g.save();g.translate((x0+x1)/2,ly);g.rotate(Math.PI/2);const fh=L*.16*(1+.12*wsin(t,8,0));poly(g,[-L*.05,L*.03,-L*.025,-fh*.5,wsin(t,7,0)*2,-fh,L*.025,-fh*.5,L*.05,L*.03],'#8ae8ff');poly(g,[-L*.03,L*.03,0,-fh*.7,L*.03,L*.03],'#f0ffff');g.restore();
  g.strokeStyle='#4a4a5a';g.lineWidth=1.6;g.beginPath();for(const k of[-.6,0,.6]){g.moveTo(x1-L*.02,ly+hw*k);g.lineTo(x0+L*.02,ly+hw*k)}g.stroke();g.strokeStyle='#4a4a5a';g.lineWidth=2.6;g.strokeRect(x0,ly-hw*.62,x1-x0,hw*1.24);
  g.fillStyle='#5a5a6a';g.fillRect(x1-1,ly-hw*.7,4,hw*1.4);g.fillRect(x0-3,ly-hw*.7,4,hw*1.4);g.restore();
  g.save();g.globalCompositeOperation='lighter';for(let i=0;i<5;i++){const u=(t*.35+i/5)%1;g.globalAlpha=Math.sin(u*Math.PI)*.8;glow(g,top-L*.2-u*L*.34+Math.sin(u*7+i)*3,ly+Math.sin(i*3+t)*L*.06,3,'#9af0ff')}g.restore()}});
/* --- Tidecaller Staff (rare): a trident crowned with a captive drop of sea --- */
WNEW.tidal=(g,L,t,X)=>wStaff(g,L,t,{c:X.c,sw:3.4,grip:'#1a4a58',wob:u=>Math.sin(u*14)*.35,
 shaft:(g,ox,top)=>{g.strokeStyle='#e8fff8';g.lineWidth=1.2;for(let i=0;i<5;i++){const x=L*.1+i*L*.17;g.beginPath();g.arc(x,-3.4,2.6,.2,Math.PI-.2);g.stroke()}},
 head:(g,ox,top)=>{const m=metal(g,-L*.2,L*.2,'#6ae8f0');g.lineCap='round';
  g.strokeStyle='#04282f';g.lineWidth=6.4;for(const s of[-1,0,1]){g.beginPath();g.moveTo(ox-L*.1,0);if(s)g.bezierCurveTo(ox-L*.05,s*L*.14,ox+L*.02,s*L*.2,ox+L*.12,s*L*.2);else g.lineTo(ox+L*.16,0);g.stroke()}
  g.strokeStyle=m;g.lineWidth=4.2;for(const s of[-1,0,1]){g.beginPath();g.moveTo(ox-L*.1,0);if(s)g.bezierCurveTo(ox-L*.05,s*L*.14,ox+L*.02,s*L*.2,ox+L*.12,s*L*.2);else g.lineTo(ox+L*.16,0);g.stroke()}
  for(const [x,y] of[[ox+L*.12,-L*.2],[ox+L*.12,L*.2],[ox+L*.16,0]]){const hy=y?Math.sign(y):0;poly(g,[x-2,y-4,x+L*.15,y,x-2,y+4,x+3,y],m,'#04282f',1);poly(g,[x,y-4,x-L*.04,y-L*.05,x+2,y-1],m,'#04282f',.8);poly(g,[x,y+4,x-L*.04,y+L*.05,x+2,y+1],m,'#04282f',.8)}
  const bx=ox+L*.04,r=L*.1,py=wsin(t,2,0)*1.5;g.save();g.beginPath();g.arc(bx,py,r,0,TAU);g.clip();g.fillStyle=rgr(g,bx-r*.3,py-r*.3,1,r*1.3,'#bff8ff','#1a8ac8');g.fillRect(bx-r,py-r,r*2,r*2);g.strokeStyle='#ffffffcc';g.lineWidth=1.3;g.beginPath();for(let i=0;i<=16;i++){const x=bx-r+i/16*r*2;const y=py+Math.sin(i*.9+t*3)*r*.18;i?g.lineTo(x,y):g.moveTo(x,y)}g.stroke();g.restore();g.strokeStyle='#e8ffff';g.lineWidth=1.2;g.beginPath();g.arc(bx,py,r,0,TAU);g.stroke();ell(g,bx-r*.4,py-r*.45,r*.22,r*.14,'#fffc');
  g.save();g.globalCompositeOperation='lighter';glow(g,bx,py,r*2.4,'#4ae0ff55');for(let i=0;i<5;i++){const u=(t*.7+i/5)%1,a=i*1.9;g.globalAlpha=1-u;ell(g,bx-L*.04-u*L*.3,Math.sin(a)*L*.14*(1-u*.4),1.6,2.2,'#bff8ff')}g.restore()}});
/* --- Hourglass Staff (epic): a brass frame, a clock behind it, and sand that never quite runs out --- */
WNEW.hourglass=(g,L,t,X)=>wStaff(g,L,t,{c:X.c,sw:3.5,grip:'#4a2a1a',
 shaft:(g,ox,top)=>{for(let i=0;i<4;i++){const x=L*.02+i*L*.24;poly(g,[x-3,-3.8,x,-6,x+3,-3.8,x,-1.6],'#e6b93e','#5a3a08',.7);poly(g,[x-3,3.8,x,6,x+3,3.8,x,1.6],'#e6b93e','#5a3a08',.7)}},
 back:(g,ox,top)=>{g.save();g.globalCompositeOperation='lighter';glow(g,ox,0,L*.5,'#ffb84a44');g.globalAlpha=.55;g.strokeStyle='#ffc86a';g.lineWidth=1.2;g.beginPath();g.arc(ox,0,L*.27,0,TAU);g.stroke();for(let i=0;i<12;i++){const a=i*TAU/12;g.beginPath();g.moveTo(ox+Math.cos(a)*L*.24,Math.sin(a)*L*.24);g.lineTo(ox+Math.cos(a)*L*(i%3?.265:.245),Math.sin(a)*L*(i%3?.265:.245));g.stroke()}g.lineWidth=1.6;g.beginPath();g.moveTo(ox,0);g.lineTo(ox+Math.cos(t*.9)*L*.17,Math.sin(t*.9)*L*.17);g.stroke();g.beginPath();g.moveTo(ox,0);g.lineTo(ox+Math.cos(t*.075)*L*.11,Math.sin(t*.075)*L*.11);g.stroke();g.restore()},
 head:(g,ox,top)=>{const xA=ox-L*.15,xB=ox+L*.15,hw=L*.1,nk=L*.012;const bulb=(a,b)=>{g.beginPath();g.moveTo(a,-hw);g.bezierCurveTo(a+(b-a)*.45,-hw,b-(b-a)*.1,-nk*2,b,-nk);g.lineTo(b,nk);g.bezierCurveTo(b-(b-a)*.1,nk*2,a+(b-a)*.45,hw,a,hw);g.closePath()};
  g.fillStyle='#bfe8ff33';bulb(xA+3,ox);g.fill();bulb(xB-3,ox);g.fill();
  const p=.5+.5*wsin(t,.5,0),sand=(a,b,f,col)=>{g.save();bulb(a,b);g.clip();g.fillStyle=col;const x0=a<b?a:b;if(a<b){g.fillRect(a,-hw,(b-a)*f,hw*2)}else{g.fillRect(a-(a-b)*f,-hw,(a-b)*f,hw*2)}g.restore()};
  sand(xA+3,ox,p,'#ffc85a');sand(xB-3,ox,1-p,'#ffc85a');g.strokeStyle='#ffe0a0';g.lineWidth=1;g.beginPath();g.moveTo(ox,0);g.lineTo(xA+4+(ox-xA-4)*p,0);g.stroke();
  g.strokeStyle='#e8f8ff';g.lineWidth=1.2;bulb(xA+3,ox);g.stroke();bulb(xB-3,ox);g.stroke();g.strokeStyle='#ffffff88';g.lineWidth=1;g.beginPath();g.moveTo(xA+6,-hw*.6);g.lineTo(ox-6,-hw*.2);g.moveTo(xB-6,-hw*.6);g.lineTo(ox+6,-hw*.2);g.stroke();
  for(const x of[xA,xB]){g.fillStyle=metal(g,-hw,hw,'#e6b93e');g.beginPath();g.roundRect(x-3.4,-hw-3,6.8,hw*2+6,2);g.fill();g.strokeStyle='#4a2a08';g.lineWidth=1;g.stroke()}
  for(const s of[-1,1]){g.fillStyle=metal(g,-3,3,'#c8921e');g.fillRect(xA,s*(hw+1.2)-1.2,xB-xA,2.4)}}});
/* --- Soulcage (legendary): an iron cage on a black staff; a skull burns inside it and souls circle it --- */
WNEW.soulcage=(g,L,t,X)=>wStaff(g,L,t,{c:'#2a2a34',sw:3.6,grip:'#10101a',
 shaft:(g,ox,top)=>{for(let i=0;i<5;i++){const x=L*.0+i*L*.2;g.fillStyle='#e8e0cc';g.beginPath();g.ellipse(x,0,3,4.8,0,0,TAU);g.fill();g.strokeStyle='#000a';g.lineWidth=.8;g.stroke()}},
 back:(g,ox)=>{g.save();g.globalCompositeOperation='lighter';glow(g,ox,0,L*.62,'#3aff9055');g.restore()},
 head:(g,ox,top)=>{const x0=ox-L*.16,x1=ox+L*.3,R=L*.21,cxm=(x0+x1)/2;
  g.save();g.globalCompositeOperation='lighter';for(let i=0;i<7;i++){const u=(t*.5+i/7)%1;g.globalAlpha=(1-u)*.9;wflame(g,cxm+L*.02+u*L*.12,Math.sin(i*5)*L*.04,L*.07*(1-u*.5),L*.03,t,i,(1-u)*.9)}g.restore();
  g.fillStyle=vgr(g,-9,9,'#f4fff4','#a8c8b0');g.beginPath();g.ellipse(cxm,0,L*.085,L*.075,0,0,TAU);g.fill();g.strokeStyle='#000a';g.lineWidth=1;g.stroke();g.fillRect(cxm-L*.12,-L*.035,L*.07,L*.07);g.strokeRect(cxm-L*.12,-L*.035,L*.07,L*.07);g.fillStyle='#10201a';for(let k=-1;k<=1;k++)g.fillRect(cxm-L*.115,k*L*.02-.6,L*.045,1.2);
  g.save();g.globalCompositeOperation='lighter';for(const s of[-1,1]){glow(g,cxm+L*.035,s*L*.035,L*.09,'#3aff90ee')}g.restore();for(const s of[-1,1])ell(g,cxm+L*.035,s*L*.035,2.6,2.6,'#eaffef');
  g.save();g.globalCompositeOperation='lighter';g.fillStyle='#7affb0';for(let i=0;i<6;i++){const u=(t*.4+i/6)%1,a=i*1.7+t*1.4;g.globalAlpha=Math.sin(u*Math.PI)*.85;const x=cxm+Math.cos(a)*L*.15,y=Math.sin(a)*R*.7;glow(g,x,y,4,'#8affc0');ell(g,x,y,1.4,1.4,'#fff')}g.restore();
  g.strokeStyle='#050508';g.lineWidth=5.2;const bars=()=>{for(const k of[-1,-.64,.64,1]){g.beginPath();for(let i=0;i<=14;i++){const u=i/14,x=x0+u*(x1-x0),y=k*R*Math.pow(Math.sin(Math.PI*(.06+u*.88)),.7);i?g.lineTo(x,y):g.moveTo(x,y)}g.stroke()}};bars();g.strokeStyle=metal(g,-R,R,'#7a7a8a');g.lineWidth=3;bars();g.strokeStyle='#ffffff55';g.lineWidth=.9;bars();
  for(const x of[x0,x1]){g.fillStyle=metal(g,-R*.5,R*.5,'#8a8a9a');g.beginPath();g.roundRect(x-3,-R*.45,6,R*.9,2);g.fill();g.strokeStyle='#000a';g.lineWidth=1;g.stroke()}
  poly(g,[x1+2,-3,x1+L*.1,0,x1+2,3],'#8a8a9a','#000a',1);
  g.strokeStyle='#8a8a9a';g.lineWidth=1.6;for(const s of[-1,1]){g.beginPath();g.moveTo(x0,s*R*.4);for(let i=1;i<4;i++)g.lineTo(x0-i*L*.035+wsin(t,2,i)*.8,s*(R*.4+i*L*.03)+Math.sin(t*2+i)*.8);g.stroke()}}});

/* --- Candlewick Wand (common): a wax candle for a wand, with a flame that never goes out --- */
WNEW.candle=(g,L,t,X)=>wWand(g,L,t,{c:X.c,sw:3.6,grip:'#6a4a2a',
 shaft:(g,ox,len)=>{for(let i=0;i<5;i++){const x=L*.16+i*len*.15,d=L*(.04+rnd(i)*.05),sg=i%2?-1:1;g.fillStyle='#fff4d0';g.strokeStyle='#b8a070';g.lineWidth=.8;g.beginPath();g.roundRect(x-1.5,sg>0?2:-2-d,3,d+1.2,1.5);g.fill();g.stroke();ell(g,x,sg>0?2+d+.4:-2-d-.4,2,2,'#fff4d0')}},
 tip:(g,ox,len)=>{g.fillStyle='#fff';g.fillRect(len+L*.02,-2.4,L*.05,4.8);g.strokeStyle='#2a1a10';g.lineWidth=1.4;g.beginPath();g.moveTo(len+L*.06,0);g.lineTo(ox+L*.02,0);g.stroke();
  g.save();g.globalCompositeOperation='lighter';glow(g,ox+L*.1,0,L*.34*(1+.1*wsin(t,9,0)),'#ffa83a88');g.restore();wflame(g,ox+L*.02,0,L*.2,L*.05,t,0);
  g.save();g.globalCompositeOperation='lighter';for(let i=0;i<5;i++){const u=(t*.8+i/5)%1;g.globalAlpha=1-u;g.fillStyle='#ffd070';g.fillRect(ox+L*.1+u*L*.26,Math.sin(i*4+t*3)*L*.07*u,2,2)}g.restore()}});
/* --- Scribe's Quill (uncommon): a plume as long as a wand; the nib is wet with light --- */
WNEW.quill=(g,L,t,X)=>{const len=L*.68,ox=len+L*.08;
 wWand(g,L,t,{c:'#e8e0f0',sw:1.7,grip:'#2a1a50',wob:u=>Math.sin(u*3)*.5,
 back:(g,ox,len)=>{g.save();g.translate(0,0);const pts=[];g.beginPath();g.moveTo(L*.1,0);g.bezierCurveTo(L*.2,-L*.2,L*.46,-L*.22,L*.62,-L*.02);g.bezierCurveTo(L*.5,L*.04,L*.3,L*.06,L*.1,0);g.closePath();g.fillStyle=hgr(g,L*.1,L*.62,'#f4eeff','#9a7ae0');g.fill();g.strokeStyle='#2a1a50aa';g.lineWidth=1;g.stroke();g.beginPath();g.moveTo(L*.1,0);g.bezierCurveTo(L*.2,L*.2,L*.46,L*.2,L*.62,L*.04);g.bezierCurveTo(L*.5,L*.0,L*.3,-L*.02,L*.1,0);g.closePath();g.fillStyle=hgr(g,L*.1,L*.62,'#e8e0ff','#6a4ac0');g.fill();g.stroke();
   g.strokeStyle='#5a3aa088';g.lineWidth=.7;for(let i=0;i<13;i++){const u=.12+i*.045,x=L*u*4.6*.2+L*.05;g.beginPath();g.moveTo(L*(.12+i*.04),0);g.lineTo(L*(.2+i*.04),-L*.17*Math.sin((i+1)/14*Math.PI)*.9);g.moveTo(L*(.12+i*.04),0);g.lineTo(L*(.2+i*.04),L*.17*Math.sin((i+1)/14*Math.PI)*.9);g.stroke()}g.restore()},
 tip:(g,ox,len)=>{poly(g,[len-L*.02,-2.4,ox+L*.02,0,len-L*.02,2.4],metal(g,-3,3,'#e6b93e'),'#4a3008',.9);g.strokeStyle='#4a3008';g.lineWidth=.8;g.beginPath();g.moveTo(len+L*.02,0);g.lineTo(ox,0);g.stroke();
  g.save();g.globalCompositeOperation='lighter';glow(g,ox+L*.04,0,L*.16*(1+.2*wsin(t,4,0)),'#b88aff99');for(let i=0;i<4;i++){const u=(t*.6+i/4)%1;g.globalAlpha=1-u;g.strokeStyle='#e0d0ff';g.lineWidth=1.2;g.beginPath();g.moveTo(ox+u*L*.2,u*L*.1*(i%2?1:-1));g.lineTo(ox+u*L*.2+L*.04,u*L*.1*(i%2?1:-1)+3);g.stroke()}g.restore();ell(g,ox+L*.03,L*.04+((t*30)%12)*.6,1.6,2.4,'#c8a8ff')}})};
/* --- Watcher's Wand (rare): bone-pale wood and an eye that follows whatever is near --- */
WNEW.watcher=(g,L,t,X)=>wWand(g,L,t,{c:'#4a2a5a',sw:2.9,grip:'#1a0a24',wob:u=>Math.sin(u*10)*.7,
 shaft:(g,ox,len)=>{g.strokeStyle='#c83a6a';g.lineWidth=1;for(let i=0;i<4;i++){g.beginPath();g.moveTo(L*.12+i*L*.1,-2.4);g.bezierCurveTo(L*.16+i*L*.1,-8,L*.2+i*L*.1,-4,L*.22+i*L*.1,-10);g.stroke()}},
 tip:(g,ox,len)=>{const r=L*.12,ex=ox+L*.02;g.save();g.globalCompositeOperation='lighter';glow(g,ex,0,r*3,'#b04aff55');g.restore();
  g.strokeStyle='#c83a6a';g.lineWidth=1.6;for(let i=0;i<6;i++){const a=-1.2+i*.48;g.beginPath();g.moveTo(len,0);g.quadraticCurveTo(ex+Math.cos(a)*r*.6,Math.sin(a)*r*.9,ex+Math.cos(a)*r*1.05,Math.sin(a)*r*1.05);g.stroke()}
  g.beginPath();g.ellipse(ex,0,r*1.15,r,0,0,TAU);g.fillStyle=rgr(g,ex-r*.3,-r*.3,1,r*1.3,'#fff8f0','#e0b8c0');g.fill();g.strokeStyle='#000a';g.lineWidth=1.2;g.stroke();
  g.strokeStyle='#d8305a99';g.lineWidth=.7;for(let i=0;i<7;i++){const a=i*.9;g.beginPath();g.moveTo(ex+Math.cos(a)*r,Math.sin(a)*r*.9);g.lineTo(ex+Math.cos(a)*r*.55,Math.sin(a)*r*.5);g.stroke()}
  const lx=Math.sin(t*.9)*r*.32,ly=Math.cos(t*1.3)*r*.24;g.fillStyle=rgr(g,ex+lx,ly,1,r*.62,'#e8a0ff','#4a1a8a');g.beginPath();g.arc(ex+lx,ly,r*.58,0,TAU);g.fill();g.strokeStyle='#1a0a30';g.lineWidth=1;g.stroke();g.fillStyle='#07000f';g.beginPath();g.ellipse(ex+lx,ly,r*.13,r*.46,0,0,TAU);g.fill();ell(g,ex+lx-r*.2,ly-r*.22,r*.12,r*.1,'#fff');
  const bl=Math.max(0,Math.sin(t*1.1+1)*2-1.55);if(bl>0){g.fillStyle='#4a2a5a';g.beginPath();g.ellipse(ex,-r*(1-bl*2.2)*.5,r*1.2,r*(.5+bl),0,0,TAU);g.fill()}}});
/* --- Prismatic Rod (epic): a silver rod with a glass prism that splits a white beam into every colour --- */
WNEW.prism=(g,L,t,X)=>wWand(g,L,t,{c:'#c8d0e0',sw:2.8,grip:'#3a3a4a',
 shaft:(g,ox,len)=>{for(let i=0;i<3;i++){const x=L*.2+i*L*.14;g.fillStyle=metal(g,-4,4,'#e8eef8');g.beginPath();g.roundRect(x,-4,L*.04,8,1.5);g.fill();g.strokeStyle='#000a';g.lineWidth=.8;g.stroke()}},
 tip:(g,ox,len)=>{const cx=ox+L*.02,r=L*.15;const T=[[cx-r*.3,-r*.9],[cx-r*.3,r*.9],[cx+r*.9,0]];
  g.save();g.globalCompositeOperation='lighter';g.strokeStyle='#fff';g.lineWidth=1.8;g.shadowColor='#fff';g.shadowBlur=6;g.beginPath();g.moveTo(len-L*.2,-L*.1);g.lineTo(cx-r*.1,-r*.1);g.stroke();g.shadowBlur=0;
  const cols=['#ff3a3a','#ff9a2a','#ffe83a','#3aff6a','#3ab8ff','#8a5aff'];for(let i=0;i<6;i++){const a=(-.5+i*.2)+Math.sin(t*1.3)*.06;g.globalAlpha=.6;g.strokeStyle=cols[i];g.lineWidth=2.6;g.beginPath();g.moveTo(cx+r*.4,r*.2*(i-2.5)*.4);g.lineTo(cx+r*.4+Math.cos(a)*L*.62,Math.sin(a)*L*.62+r*.2*(i-2.5)*.4);g.stroke()}g.restore();
  g.beginPath();g.moveTo(T[0][0],T[0][1]);g.lineTo(T[1][0],T[1][1]);g.lineTo(T[2][0],T[2][1]);g.closePath();g.fillStyle=rgr(g,cx,-r*.3,1,r*1.5,'#ffffffdd','#9ad0ff99');g.fill();g.strokeStyle='#fff';g.lineWidth=1.4;g.stroke();g.strokeStyle='#ffffff88';g.lineWidth=.8;g.beginPath();g.moveTo(T[0][0]+3,-r*.4);g.lineTo(cx+r*.3,0);g.lineTo(T[1][0]+3,r*.4);g.stroke();
  g.save();g.globalCompositeOperation='lighter';for(let i=0;i<4;i++)mS(g,cx+Math.cos(i*1.9+t)*r*1.5,Math.sin(i*2.3+t*.8)*r*1.2,1.6+i%2,'#fff');g.restore()}});
/* --- Midas Scepter (legendary): solid gold, a coin for a jewel, and coins that orbit it --- */
WNEW.midas=(g,L,t,X)=>wWand(g,L,t,{c:'#e6b93e',sw:3.4,grip:'#7a1a2a',
 back:(g,ox,len)=>{g.save();g.globalCompositeOperation='lighter';glow(g,ox,0,L*.5,'#ffd24a66');g.restore()},
 shaft:(g,ox,len)=>{for(let i=0;i<3;i++){const x=L*.22+i*L*.15;g.strokeStyle='#8a5a08';g.lineWidth=1.2;g.beginPath();g.moveTo(x,-3.6);g.lineTo(x+3,3.6);g.stroke();gem(g,x+L*.075,0,2,'#ff3a5a')}g.fillStyle='#fff9';for(let i=0;i<5;i++)g.fillRect(L*.1+i*L*.12+Math.sin(t*3+i)*2,-2.2,1.6,1.2)},
 tip:(g,ox,len)=>{const r=L*.14,sq=Math.cos(t*1.4);for(const s of[-1,1]){g.beginPath();g.moveTo(len,0);g.quadraticCurveTo(len+L*.04,s*L*.15,ox+r*.2,s*r*1.05);g.strokeStyle='#4a2a04';g.lineWidth=6.4;g.stroke();g.strokeStyle='#f0c850';g.lineWidth=4;g.stroke();g.strokeStyle='#fff6b0';g.lineWidth=1;g.stroke()}
  g.save();g.translate(ox+r*.2,0);g.scale(Math.max(.14,Math.abs(sq)),1);ell(g,0,r*.12,r,r,'#8a5a0a');ell(g,0,0,r,r,rgr(g,-r*.3,-r*.3,r*.1,r*1.1,'#fff6b0','#d8961c'));g.strokeStyle='#8a5a10';g.lineWidth=1.4;g.beginPath();g.arc(0,0,r*.72,0,TAU);g.stroke();if(sq>0){g.fillStyle='#b8780e';g.beginPath();g.moveTo(-r*.4,r*.3);g.lineTo(-r*.4,-r*.1);g.lineTo(-r*.2,r*.1);g.lineTo(0,-r*.3);g.lineTo(r*.2,r*.1);g.lineTo(r*.4,-r*.1);g.lineTo(r*.4,r*.3);g.closePath();g.fill()}g.restore();
  for(let i=0;i<4;i++){const a=t*2.2+i*TAU/4,cx=ox+r*.2+Math.cos(a)*L*.24,cy=Math.sin(a)*L*.16,s=Math.max(.2,Math.abs(Math.cos(a*2+i)));g.save();g.translate(cx,cy);g.scale(s,1);ell(g,0,0,L*.04,L*.04,'#ffd24a');g.strokeStyle='#8a5a10';g.lineWidth=.8;g.stroke();g.restore()}
  g.save();g.globalCompositeOperation='lighter';for(let i=0;i<5;i++){const u=(t*.5+i/5)%1;g.globalAlpha=1-u;mS(g,ox+u*L*.3,Math.sin(i*4)*L*.12*u,2.2,'#fff3a0')}g.restore();ell(g,ox+r*.2,r*1.05+((t*22)%14),1.6,2.6,'#ffd24a')}});
