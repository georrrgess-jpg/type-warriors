/* ---- signature auras: a back layer (behind the hero) and a front layer (things orbiting in front).
   Every aura follows the same rules: soft glow, one dark "weight" element, orbiters that pass behind and in front. ---- */
function arBat(g,x,y,s,fl,col,eye,ol){ol=ol||'#ff5a7099';g.save();g.translate(x,y);g.scale(s,s);const u=fl*6;
 for(const sd of[-1,1]){g.save();g.scale(sd,1);poly(g,[1.5,-.5,6,-4+u*.3,15,-9+u,14,-2+u*.7,11,-.5+u*.5,9.5,2.5+u*.3,6,1,3,4,1.5,3],col,ol,.9);g.strokeStyle='#ffffff22';g.lineWidth=.7;g.beginPath();g.moveTo(2,-.5);g.lineTo(14,-8+u);g.moveTo(2,0);g.lineTo(11,-1+u*.5);g.stroke();g.restore()}
 ell(g,0,1.2,3,4.3,col);g.strokeStyle=ol;g.lineWidth=.9;g.beginPath();g.ellipse(0,1.2,3,4.3,0,0,TAU);g.stroke();
 poly(g,[-2.6,-2,-2,-6,-.6,-3],col,ol,.8);poly(g,[2.6,-2,2,-6,.6,-3],col,ol,.8);
 glow(g,-1.2,-.4,3,eye+'aa');glow(g,1.2,-.4,3,eye+'aa');ell(g,-1.2,-.4,.8,.8,eye);ell(g,1.2,-.4,.8,.8,eye);g.restore()}
function arSmoke(g,t,col,a){const A=n=>Math.round(n*255).toString(16).padStart(2,'0');g.fillStyle=rgr(g,-4,-78,8,98,col+A(a),col+'00');g.fillRect(-110,-190,210,200);
 for(let i=0;i<6;i++){const u=(t*.16+i/6)%1,x=-6+Math.sin(t*.6+i*1.9)*34,y=-12-u*128,r=13+(i%3)*6;g.globalAlpha=Math.sin(u*Math.PI)*a*.9;ell(g,x,y,r,r*.8,col+'ff')}g.globalAlpha=1}
function arAura(g,K,c,post,hx,hy){const f=K.aura,og=c.orbit;if(!f&&!og)return;const {M,D,T,acc,t,tier}=c,ol=OL;OL=0;g.save();
 const orb=(n,cx,cy,rx,ry,spd,fn)=>{for(let i=0;i<n;i++){const a=t*spd+i*TAU/n,z=Math.sin(a);if((z>0)!==!!post)continue;fn(cx+Math.cos(a)*rx,cy+z*ry,i,a,z)}};
 const trail=(cx,cy,rx,ry,spd,i,n,col,r,dir)=>{for(let j=1;j<=5;j++){const a=t*spd+i*TAU/n-j*.11*dir;g.globalAlpha=.34*(1-j/6);ell(g,cx+Math.cos(a)*rx,cy+Math.sin(a)*ry,r*(1-j*.13),r*(1-j*.13),col)}g.globalAlpha=1};
 if(HWA[f])HWA[f](g,K,c,post,hx,hy,orb,trail);else if(f==='bloodmoon'){
  if(!post){arSmoke(g,t,'#240008',.62);glow(g,-6,-100,98,'#ff204044');
   ell(g,-6,-102,37,37,rgr(g,-15,-112,2,46,'#ff8a9a','#6a0818'));g.globalAlpha=.32;for(const [x,y,r] of[[-17,-112,6.5],[1,-92,8.5],[-12,-86,4.5],[6,-110,3.4]])ell(g,x,y,r,r,'#4a0412');g.globalAlpha=1;g.strokeStyle='#ff9aa855';g.lineWidth=1.6;g.beginPath();g.arc(-6,-102,37,0,TAU);g.stroke()}
  orb(2,-2,-96,62,18,.95,(x,y,i,a,z)=>{arBat(g,x,y,1.05+z*.2,Math.sin(t*15+i*2.2),'#2e0a14','#ff4a60')})}
 else if(f==='crescent'){
  if(!post){glow(g,-6,-102,86,'#8aa8ff40');g.save();g.translate(-5,-100);g.rotate(-.3);g.fillStyle=rgr(g,-10,-10,4,48,'#ffffff','#b8c8ff');g.beginPath();g.arc(0,0,42,Math.PI*.3,Math.PI*1.7);g.arc(12,0,34,Math.PI*1.62,Math.PI*.38,true);g.closePath();g.fill();g.restore()}}
 else if(f==='inferno'){
  if(!post){glow(g,0,-72,98,'#ff6a1a50');for(let i=0;i<3;i++){const u=(t*.45+i/3)%1;g.globalAlpha=(1-u)*.5;g.strokeStyle='#ffb050';g.lineWidth=1.6;g.beginPath();g.ellipse(-2,-70,26+u*38,40+u*34,0,0,TAU);g.stroke()}g.globalAlpha=1}
  else for(const [x,s,ph] of[[-15,.9,0],[19,.9,2]]){const w=Math.sin(t*9+ph)*2.4,by=-98;glow(g,x,by-8,13,'#ff8a2a88');poly(g,[x-5*s,by,x-3*s+w,by-12*s,x+w*1.5,by-22*s,x+3*s+w,by-12*s,x+5*s,by],'#ff7a1a');poly(g,[x-2.4*s,by,x+w,by-12*s,x+2.4*s,by],'#ffd060')}}
 else if(f==='tide'){
  if(!post){glow(g,0,-72,90,'#3ae0d03a');for(let i=0;i<3;i++){const u=(t*.4+i/3)%1;g.globalAlpha=(1-u)*.6;g.strokeStyle='#bffff4';g.lineWidth=1.6;g.beginPath();g.ellipse(-2,-30,24+u*52,6+u*14,0,0,TAU);g.stroke()}g.globalAlpha=1}
  orb(4,-2,-80,44,14,.8,(x,y,i)=>{trail(-2,-80,44,14,.8,i,4,'#bffff4',3.2,1);poly(g,[x,y-5,x+3,y+1,x,y+4,x-3,y+1],'#dffffa','#0a5a68',.9)})}
 else if(f==='storm'){
  if(!post){glow(g,0,-92,92,'#ffe36a30');const fl=Math.sin(t*23)>.82;for(const [x,y,r] of[[-20,-128,18],[2,-136,22],[24,-126,17]])ell(g,x,y,r,r*.62,fl?'#4a5a8a':'#242a4a');if(fl)glow(g,2,-128,40,'#ffffaa66')}
  orb(3,-2,-86,46,15,1.3,(x,y,i)=>{const j=Math.sin(t*30+i*4)*1.5;glow(g,x,y+j,8,'#ffe36aaa');ell(g,x,y+j,2,2,'#ffffff')})}
 else if(f==='rift'){
  if(!post){glow(g,-4,-92,70,'#7a3aff55');g.save();g.translate(-4,-92);for(let i=0;i<3;i++){g.save();g.rotate(t*.6*(i%2?-1:1)+i);g.strokeStyle=['#ff6ad8','#7a3aff','#c8a0ff'][i]+'cc';g.lineWidth=2.6;g.beginPath();g.ellipse(0,0,50-i*10,19+i*8,0,0,TAU);g.stroke();g.restore()}ell(g,0,0,13,13,'#020006');g.restore()}}
 else if(f==='blades'){
  if(!post){glow(g,-4,-90,76,'#7affc030');for(const [sd,ph] of[[-1,0],[1,2]]){g.save();g.translate(-4+sd*34,-96+Math.sin(t*1.6+ph)*4);g.rotate(sd*(.5+Math.sin(t*1.4+ph)*.08));g.globalAlpha=.8;arBev(g,[0,-26,5.5,-8,4,12,0,19,-4,12,-5.5,-8],mixc(M,'#ffffff',.2),{sm:1,ow:1.1,edge:T,ew:1.6});g.restore()}}}
 else if(f==='wisps'){
  orb(3,-2,-84,44,15,.7,(x,y,i)=>{trail(-2,-84,44,15,.7,i,3,acc,3.6,1);glow(g,x,y,8,acc+'88');ell(g,x,y,3.2,3.2,'#ffffff');ell(g,x,y,2,2,acc)})}
 else if(f==='smoke'){if(!post)arSmoke(g,t,'#12062a',.6)}
 else if(f==='wyrm'){
  if(!post){glow(g,0,-72,92,acc+'38');const fl=Math.sin(t*1.5)*.07;for(const k of[1,0]){g.save();g.translate(-12,-94);g.rotate(fl*(k?1.3:1)-(k?.12:0));g.scale(k?.82:1,k?.82:1);g.globalAlpha=k?.62:.86;
   const W=[-34,-64],tips=[[-86,-48],[-78,-16],[-46,10]];
   poly(g,[0,0,W[0],W[1],-86,-48,-62,-38,-78,-16,-54,-12,-46,10,-30,3,-8,16],shade(D,-.45),'#000000a0',1.2);
   g.strokeStyle=acc+'aa';g.lineWidth=1.3;g.beginPath();g.moveTo(0,0);g.lineTo(W[0],W[1]);for(const q of tips){g.moveTo(W[0],W[1]);g.lineTo(q[0],q[1])}g.stroke();
   g.restore()}}}
 else if(f==='halo'){
  if(!post){glow(g,hx-1,hy-4,62,acc+'55');g.save();g.translate(hx-1,hy-4);g.rotate(t*.22);g.globalAlpha=.24;for(let i=0;i<12;i++){g.rotate(TAU/12);poly(g,[-3,-22,3,-22,0,-(i%2?52:66)],'#fff6c0')}g.restore();g.strokeStyle=acc+'aa';g.lineWidth=1.6;g.beginPath();g.arc(hx-1,hy-4,26,0,TAU);g.stroke()}}
 else if(f==='frost'){
  if(!post){glow(g,0,-70,92,'#bff4ff30');glow(g,0,-6,64,'#d8f4ff44')}
  orb(3,-2,-82,42,13,.6,(x,y,i,a)=>{g.save();g.translate(x,y);g.rotate(a);poly(g,[0,-6,3,0,0,6,-3,0],'#e8faff','#4a86b8',.9);g.restore()})}
 else if(f==='pyre'){
  if(!post){glow(g,0,-76,98,'#ff7a1a46');glow(g,0,-48,60,'#ffc85030')}
  orb(3,-2,-82,42,14,.9,(x,y,i)=>{const w=Math.sin(t*10+i)*1.6;trail(-2,-82,42,14,.9,i,3,'#ffb040',3.4,1);glow(g,x,y,9,'#ff8a2a99');poly(g,[x-3,y+3,x-1.8+w,y-4,x+w,y-9,x+1.8+w,y-4,x+3,y+3],'#ff7a1a');poly(g,[x-1.4,y+3,x+w*.6,y-4,x+1.4,y+3],'#ffe080')})}
 else if(f==='souls'){
  if(!post){arSmoke(g,t,'#04120c',.6);glow(g,0,-76,70,acc+'28')}
  orb(3,-2,-86,46,15,.75,(x,y,i)=>{trail(-2,-86,46,15,.75,i,3,acc,4.4,1);glow(g,x,y,10,acc+'88');ell(g,x,y,4.2,4.8,acc+'cc');ell(g,x-1.3,y-.6,.9,1.3,'#02100a');ell(g,x+1.3,y-.6,.9,1.3,'#02100a')})}
 else if(f==='forge'){
  if(!post){glow(g,0,-72,86,acc+'30');for(let i=0;i<2;i++){const u=(t*.5+i/2)%1;g.globalAlpha=(1-u)*.7;g.strokeStyle=acc;g.lineWidth=2;g.beginPath();g.ellipse(2,-2,22+u*44,5+u*10,0,0,TAU);g.stroke()}g.globalAlpha=1}
  else for(let i=0;i<6;i++){const u=(t*.6+i/6)%1,x=Math.sin(i*5.3+t)*20+i*2-6,y=-8-u*70;g.globalAlpha=Math.sin(u*Math.PI);g.fillStyle=i%2?'#ffe9a0':'#ffb040';g.fillRect(x-1,y-1,2,2)}}
 else if(f==='eclipse'){
  if(!post){arSmoke(g,t,'#0a0626',.62);glow(g,0,-80,76,acc+'26')}
  orb(3,-2,-84,54,17,.55,(x,y,i,a,z)=>{const r=4.6+z*1.1;ell(g,x,y,r,r,i===0?'#06030f':'#2a2060');g.strokeStyle=acc;g.lineWidth=1.3;g.beginPath();g.arc(x,y,r,0,TAU);g.stroke();if(i===1){glow(g,x,y,8,acc+'66')}})}
 else if(f==='holy'){
  if(!post){glow(g,0,-76,86,acc+'28');const gv=g.createLinearGradient(-10,0,12,0);gv.addColorStop(0,acc+'00');gv.addColorStop(.5,acc+'2e');gv.addColorStop(1,acc+'00');for(let i=0;i<8;i++){g.globalAlpha=1-i/8;g.fillStyle=gv;g.fillRect(-10,-172+i*22,22,23)}g.globalAlpha=1;const gh=g.createLinearGradient(-60,0,60,0);gh.addColorStop(0,acc+'00');gh.addColorStop(.5,acc+'30');gh.addColorStop(1,acc+'00');g.fillStyle=gh;g.fillRect(-60,-112,120,16)}}
 else if(f==='leaves'||f==='blossom'){const col=f==='leaves'?acc:'#ff6a8a';
  orb(6,-2,-80,40,16,.55,(x,y,i,a,z)=>{g.save();g.translate(x,y);g.rotate(a*2+i);g.globalAlpha=.92;arBev(g,f==='leaves'?[0,-4.2,3,0,0,4.2,-3,0]:[0,-3.4,2.8,-1,2,3.2,0,4,-2,3.2,-2.8,-1],i%2?col:mixc(col,'#ffffff',.35),{sm:1,ow:.9});g.restore()})}
 else if(f==='prism'){
  if(!post)glow(g,0,-76,96,hsx(t*40,80,70)+'34');
  orb(6,-2,-80,50,18,.6,(x,y,i,a)=>{const h=hsx(t*80+i*60,100,72);glow(g,x,y,10,h+'99');g.save();g.translate(x,y);g.rotate(a);poly(g,[0,-5.4,3.8,0,0,5.4,-3.8,0],h,'#ffffff',1);g.restore()})}
 if(og){const n=Math.min(og,8);orb(n,-2,-76,38,12,.9,(x,y,i)=>{trail(-2,-76,38,12,.9,i,n,acc,2.6,1);glow(g,x,y,6,acc+'99');ell(g,x,y,1.9,1.9,acc);ell(g,x-.5,y-.5,.8,.8,'#ffffff')})}
 g.restore();OL=ol}
