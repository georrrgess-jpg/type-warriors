/* ---------- Monster Mash: nine monsters and three bosses ----------
   All face left (toward the hero); y=0 is the ground. Every one has its own silhouette and a small idle story. */
const GYD={};
const gyFl=(t,k)=>.78+.22*Math.sin(t*(k||9))+.06*Math.sin(t*23);
/* ragged hem: a cloth edge as a flat polygon for poly() */
function gyHem(x0,x1,y,n,j,t,w){const p=[];for(let i=0;i<=n;i++){const u=i/n;p.push(x0+(x1-x0)*u,y+((i%2)?j:-j*.3)+Math.sin(t*3+i*1.7)*(w||0))}return p}

/* 1. Grave Shambler: a half-risen corpse in a burial shroud, one arm reaching, a coffin nail in its brow */
GYD.gyshamble=(g,t,o)=>{const lg=(o&&o.lg)||0,s=Math.sin(t*4.6),b=Math.abs(Math.cos(t*4.6))*2.2,sk='#8a9e84',dk='#47564a';g.save();g.lineJoin='round';g.lineCap='round';
 /* dragging back leg, striding front leg */
 limb(g,5,-38,10+s*4,-20,9.5,shade(sk,-.4));limb(g,10+s*4,-20,16+s*9,-4,8,shade(sk,-.45));ell(g,14+s*9,-3,9,3.6,'#2a2a22');
 limb(g,-4,-38,-9-s*4,-20,10,sk);limb(g,-9-s*4,-20,-14-s*9,-4,8.5,shade(sk,-.1));poly(g,[-14-s*9-8,-1,-14-s*9+7,-1,-14-s*9+5,-8,-14-s*9-6,-8],'#2a2a22','#000a',1);
 g.translate(2,-b);
 /* shroud and torn rags */
 poly(g,[-17,-38,17,-40,19,-16].concat(gyHem(19,-18,-9,6,6,t,1.4)),'#cfc6ae','#00000099',1.4);
 g.fillStyle='#0003';g.beginPath();g.moveTo(-17,-38);g.lineTo(-17,-12);g.lineTo(-8,-12);g.lineTo(-6,-38);g.fill();
 g.strokeStyle='#8a7e66';g.lineWidth=1;for(let i=0;i<4;i++){g.beginPath();g.moveTo(-10+i*7,-36);g.lineTo(-11+i*7,-14);g.stroke()}
 /* torso: bare chest with ribs showing through */
 g.beginPath();g.moveTo(-17,-40);g.quadraticCurveTo(-20,-66,-9,-80);g.quadraticCurveTo(4,-86,15,-76);g.quadraticCurveTo(21,-60,16,-40);g.closePath();g.fillStyle=hgr(g,-18,18,shade(sk,.1),dk);g.fill();g.strokeStyle='#000000a0';g.lineWidth=1.6;g.stroke();
 g.save();g.beginPath();g.moveTo(-17,-40);g.quadraticCurveTo(-20,-66,-9,-80);g.quadraticCurveTo(4,-86,15,-76);g.quadraticCurveTo(21,-60,16,-40);g.clip();
 g.fillStyle='#3a1a1a';g.beginPath();g.ellipse(-6,-62,9,12,-.2,0,TAU);g.fill();g.strokeStyle='#e8dfc4';g.lineWidth=2.2;for(let i=0;i<4;i++){g.beginPath();g.moveTo(-14,-72+i*6);g.quadraticCurveTo(-6,-69+i*6,2,-71+i*6);g.stroke()}g.strokeStyle='#e8dfc4';g.lineWidth=2.6;g.beginPath();g.moveTo(-13,-76);g.lineTo(-13,-50);g.stroke();
 g.fillStyle='#5a7a3a99';for(const [x,y,r] of[[8,-52,5],[12,-68,4],[-14,-46,4]]){g.beginPath();g.arc(x,y,r,0,TAU);g.fill()}g.restore();
 /* arms: one reaching, one hanging with a broken bone */
 limb(g,-14,-76,-26,-66,8,shade(sk,-.1));limb(g,-26,-66,-44-lg*18,-60+Math.sin(t*4.6)*2-lg*8,7,sk);for(let i=0;i<4;i++)limb(g,-45-lg*18,-60-lg*8+i*2.4-3,-53-lg*18,-60-lg*8+i*3.4-5+Math.sin(t*5+i)*1.2,1.8,'#b8c4a8');
 limb(g,12,-76,20,-56,8,shade(sk,-.4));limb(g,20,-56,22,-38,7,shade(sk,-.45));poly(g,[22,-38,20,-26,25,-28],'#e8dfc4','#000a',.8);
 /* head */
 const hx=-6,hy=-96;g.save();g.translate(hx,hy);g.rotate(-.12+Math.sin(t*2.3)*.04);
 ell(g,0,0,12.6,13.6,rgr(g,-4,-5,1,18,shade(sk,.2),dk));
 g.fillStyle='#2a3a2a66';g.beginPath();g.ellipse(6,-2,5,8,0,0,TAU);g.fill();
 /* sparse hair and the nail */
 g.strokeStyle='#3a3a30';g.lineWidth=1.3;for(let i=0;i<7;i++){g.beginPath();g.moveTo(-9+i*3,-11+Math.abs(i-3)*.8);g.lineTo(-11+i*3.4,-19-(i%2)*3+Math.sin(t*2+i)*.8);g.stroke()}
 poly(g,[-5,-9,-3,-9,-4,-2],'#9a8a78','#000a',.6);ell(g,-4,-10,2.2,1.4,'#6a5a48');
 /* eyes glow, jaw hangs open */
 ell(g,-6,-1,3.8,4.2,'#12180f');ell(g,3.6,-1.4,3,3.4,'#12180f');const fe=gyFl(t,7);g.globalAlpha=fe;eye(g,-6,-1,1.8,'#d8ff5a');eye(g,3.6,-1.4,1.4,'#d8ff5a');g.globalAlpha=1;
 g.strokeStyle='#000a';g.lineWidth=1.5;g.beginPath();g.moveTo(-1,2);g.lineTo(-3,6);g.stroke();
 const jw=3+Math.sin(t*4.6)*1.4;poly(g,[-10,7,5,6,3,9+jw,-8,9+jw],'#5a2a2a','#000a',1);g.fillStyle='#e8dfc4';for(let i=0;i<4;i++)g.fillRect(-8+i*3.6,7,2,2.6);for(let i=0;i<3;i++)g.fillRect(-6+i*3.6,8+jw-1,2,2.4);
 g.restore();g.restore()};

/* 2. Gravedigger Bones: a skeleton in a battered hat with a rusty spade and a green-lit lantern */
GYD.gydigger=(g,t,o)=>{const lg=(o&&o.lg)||0,s=Math.sin(t*5.5),b=Math.abs(Math.cos(t*5.5))*2,bone='#e6dec4',bd='#9a9078';g.save();g.lineJoin='round';g.lineCap='round';
 const leg=(hx,fx,c)=>{const kx=(hx+fx)/2-5;limb(g,hx,-38,kx,-20,5,c);limb(g,kx,-20,fx,-4,4.4,c);ell(g,kx,-20,4,4,c);poly(g,[fx-9,-2,fx+6,-2,fx+4,-7,fx-6,-7],c,'#000a',.8)};
 leg(5,9-s*9,shade(bone,-.25));leg(-4,-8+s*9,bone);
 g.translate(0,-b);
 /* pelvis, spine, ribs */
 poly(g,[-9,-40,9,-40,7,-32,-7,-32],shade(bone,-.1),'#000a',1);limb(g,0,-40,-1,-80,3.6,bd);
 for(let i=0;i<5;i++){const y=-48-i*6.4,w=13-i*1.1;g.strokeStyle=bone;g.lineWidth=3;g.beginPath();g.ellipse(-1,y,w,3.8,0,Math.PI*.08,Math.PI*.92);g.stroke();g.strokeStyle='#0008';g.lineWidth=.8;g.stroke()}
 g.fillStyle='#4a3a2a99';g.beginPath();g.moveTo(-12,-80);g.lineTo(12,-78);g.lineTo(9,-66);g.lineTo(4,-70);g.lineTo(-3,-62);g.lineTo(-12,-72);g.fill();
 /* collar bones and shoulders */
 limb(g,-12,-80,12,-80,3,bone);ell(g,-13,-80,5,4.2,bone);ell(g,13,-80,5,4.2,bone);
 /* back arm hangs with the lantern */
 limb(g,12,-80,17,-62,3.6,shade(bone,-.2));limb(g,17,-62,20,-46,3.2,shade(bone,-.25));
 g.strokeStyle='#4a4a50';g.lineWidth=1.4;g.beginPath();g.moveTo(20,-46);g.lineTo(20,-42);g.stroke();
 {const lx=20,ly=-40,fl=gyFl(t,8);g.save();g.translate(lx,ly+Math.sin(t*3)*1);g.rotate(Math.sin(t*3)*.08);glow(g,0,2,26,'#7aff8a'+hwA(.55*fl));g.fillStyle='#2a2a30';g.fillRect(-5,-2,10,3);g.fillRect(-5,12,10,3);g.fillStyle='#7aff8acc';g.beginPath();g.roundRect(-4,1,8,12,2);g.fill();ell(g,0,7,2.2*fl+1,3.6*fl+1,'#eaffd0');g.strokeStyle='#2a2a30';g.lineWidth=1.2;g.strokeRect(-4,1,8,12);g.beginPath();g.moveTo(-4,-2);g.quadraticCurveTo(0,-9,4,-2);g.stroke();g.restore()}
 /* front arm and spade */
 const ax=-30-lg*20,ay=-70-lg*22+s*1.5;limb(g,-12,-80,-22,-70,3.6,bone);limb(g,-22,-70,ax,ay,3.4,bone);
 g.save();g.translate(ax,ay);g.rotate(-.55-lg*.9+Math.sin(t*2)*.04);g.strokeStyle='#6a4a2a';g.lineWidth=3.4;g.beginPath();g.moveTo(8,18);g.lineTo(-2,-40);g.stroke();g.strokeStyle='#8a6a42';g.lineWidth=1.4;g.beginPath();g.moveTo(8.8,18);g.lineTo(-1.2,-40);g.stroke();
 poly(g,[-9,-38,5,-39,7,-52,0,-62,-12,-51],'#7a7e86','#000a',1.3);g.fillStyle='#8a4a1e66';g.beginPath();g.ellipse(-3,-50,4,6,.3,0,TAU);g.fill();g.fillStyle='#ffffff55';g.fillRect(-7,-48,1.4,8);
 g.fillStyle='#3a2410';for(const [x,y] of[[-6,-44],[2,-54]]){g.beginPath();g.arc(x,y,1.6,0,TAU);g.fill()}g.restore();
 for(const [fx,fy] of[[ax-2,ay+2],[ax+1,ay+5]])ell(g,fx,fy,3,2.6,bone);
 /* skull in a crumpled hat */
 const hx=-3,hy=-95;g.save();g.translate(hx,hy);g.rotate(-.1+Math.sin(t*2.8)*.05);
 ell(g,0,0,11.6,12,rgr(g,-3,-4,1,16,'#fffaf0',bone));poly(g,[-7,7,6,6,5,13,-6,13],shade(bone,-.12),'#000a',1);g.fillStyle='#1a1408';for(let i=0;i<4;i++)g.fillRect(-5+i*3,8,1.2,5);
 ell(g,-5,-1,3.8,4.4,'#0a0806');ell(g,3.8,-1,3,3.6,'#0a0806');const fe=gyFl(t,6);g.globalAlpha=fe;eye(g,-5,-1,1.7,'#7aff8a');eye(g,3.8,-1,1.3,'#7aff8a');g.globalAlpha=1;poly(g,[-1,3,-2.6,6,.6,6],'#0a0806');
 g.strokeStyle='#00000055';g.lineWidth=.9;g.beginPath();g.moveTo(5,-10);g.lineTo(3,-4);g.lineTo(5,-1);g.stroke();
 ell(g,0,-9,18,4.2,'#2a2230');poly(g,[-10,-9,-8,-26,-2,-29,8,-27,10,-9],'#342a3e','#000a',1.3);poly(g,[-8,-24,6,-26,8,-21,-9,-19],'#6a2a3a');poly(g,[-1,-30,4,-26,0,-26],'#342a3e');
 g.restore();g.restore()};

/* 3. Pumpkin Stalker: a scarecrow with a jack-o'-lantern head that goes off like a bomb */
GYD.gyjack=(g,t,o)=>{const lg=(o&&o.lg)||0,s=Math.sin(t*5),b=Math.abs(Math.cos(t*5))*2,fl=gyFl(t,8.4);g.save();g.lineJoin='round';g.lineCap='round';
 /* post-and-straw legs */
 for(const [hx,fx,c] of[[5,9-s*8,'#5a4426'],[-4,-8+s*8,'#7a5a32']]){const kx=(hx+fx)/2-3;limb(g,hx,-34,kx,-18,7,c);limb(g,kx,-18,fx,-3,6,shade(c,-.1));for(let i=0;i<4;i++)limb(g,fx-3+i*2.4,-3,fx-5+i*2.6,2,1.6,'#e8c850');ell(g,kx,-18,3.4,3.4,'#3a2a14')}
 g.translate(0,-b);
 /* burlap shirt with patches, straw at the hem and cuffs */
 g.beginPath();g.moveTo(-16,-80);g.quadraticCurveTo(-19,-56,-17,-34);g.lineTo(17,-34);g.quadraticCurveTo(19,-56,15,-80);g.closePath();g.fillStyle=hgr(g,-18,18,'#a8844e','#5a4426');g.fill();g.strokeStyle='#000a';g.lineWidth=1.6;g.stroke();
 g.strokeStyle='#4a3418aa';g.lineWidth=.8;for(let i=-14;i<16;i+=3.2){g.beginPath();g.moveTo(i,-78);g.lineTo(i+.6,-35);g.stroke()}
 poly(g,[-10,-66,2,-67,1,-55,-10,-54],'#7a3a2a','#000a',1);g.setLineDash([1.6,1.6]);g.strokeStyle='#e8d8a8';g.lineWidth=.8;g.strokeRect(-8.6,-64.6,9.6,8.6);g.setLineDash([]);
 for(let i=0;i<9;i++)limb(g,-15+i*3.7,-34,-16+i*3.7+Math.sin(t*2+i)*1.4,-27-(i%3)*2,1.8,i%2?'#ecc858':'#c8a030');
 /* rope belt */
 g.fillStyle='#7a5a30';g.fillRect(-17,-47,34,4);g.strokeStyle='#3a2a10';g.lineWidth=.8;for(let i=-16;i<17;i+=3){g.beginPath();g.moveTo(i,-47);g.lineTo(i+1.6,-43);g.stroke()}
 /* arms: crossbar sleeves with straw hands */
 limb(g,-14,-76,-26,-70,8,'#8a6a3a');limb(g,-26,-70,-40-lg*16,-64-lg*8,7,'#7a5a32');for(let i=0;i<5;i++)limb(g,-41-lg*16,-64-lg*8,-50-lg*16,-70-lg*8+i*3.4+Math.sin(t*5+i)*1.4,1.6,i%2?'#ecc858':'#c8a030');
 limb(g,13,-76,22,-62,8,'#6a4a2a');limb(g,22,-62,24,-44,7,'#5a3e22');for(let i=0;i<4;i++)limb(g,24,-44,22+i*2.2,-35,1.6,'#c8a030');
 /* pumpkin head: the glow sloshes inside and leaks upward as sparks */
 const hx=-4,hy=-99;g.save();g.translate(hx,hy);g.rotate(Math.sin(t*2.6)*.05);limb(g,2,12,2,2,9,'#5a4426');
 glow(g,0,0,52,'#ff8a1a'+hwA(.5*fl));
 ell(g,-11,0,6.6,14.6,shade('#e8741c',-.38));ell(g,11,0,6.6,14.6,shade('#e8741c',-.3));ell(g,-5,0,9.6,16,shade('#e8741c',-.16));ell(g,6,0,9.4,15.8,shade('#e8741c',-.1));{const old=OL;OL=1.4;ell(g,0,0,10.4,16.4,rgr(g,-3,-6,1,20,shade('#e8741c',.3),'#e8741c'));OL=old}
 g.strokeStyle='#5a2406aa';g.lineWidth=1;for(const d of[-7,0,7]){g.beginPath();g.moveTo(d*.4,-15);g.quadraticCurveTo(d*1.5,0,d*.5,15.4);g.stroke()}
 poly(g,[-3,-14,-3.6,-22,1.4,-25,5,-23,3,-14],'#4a6a22','#14240a',1.2);g.strokeStyle='#7aaa3a';g.lineWidth=1.4;g.beginPath();g.moveTo(3,-22);g.bezierCurveTo(10,-24,11,-17,7,-16);g.stroke();
 const gc=fl>.9?'#fff0a0':'#ffd040';g.fillStyle=gc;g.strokeStyle='#4a1404';g.lineWidth=1;
 g.beginPath();g.moveTo(-9,-1);g.lineTo(-2,-1.4);g.lineTo(-6,-9);g.closePath();g.fill();g.stroke();g.beginPath();g.moveTo(2,-1.4);g.lineTo(9,-1);g.lineTo(5,-9);g.closePath();g.fill();g.stroke();
 g.beginPath();g.moveTo(0,1);g.lineTo(-2.6,5.4);g.lineTo(2.6,5.4);g.closePath();g.fill();g.stroke();
 g.fillStyle='#ffb020';g.beginPath();g.moveTo(-10,8);g.lineTo(-7,11.4);g.lineTo(-4.4,8.4);g.lineTo(-1.4,12);g.lineTo(1.6,8.6);g.lineTo(4.6,12);g.lineTo(7.4,8.4);g.lineTo(10,11);g.lineTo(11,6.6);g.lineTo(8,16);g.quadraticCurveTo(0,20,-8,16);g.closePath();g.fill();g.stroke();
 g.fillStyle='#e8741c';for(const tx of[-4,2.4,8]){g.fillRect(tx-1,8.6,2,3.6)}
 g.restore();
 for(let i=0;i<5;i++){const u=(t*.8+i/5)%1;g.globalAlpha=Math.sin(u*Math.PI)*.9;ell(g,hx+Math.sin(u*7+i*2)*9,hy-24-u*34,1.8*(1-u)+.6,1.8*(1-u)+.6,i%2?'#ffd060':'#ff8a2a')}g.globalAlpha=1;
 g.restore()};

/* 4. Lantern Wisp: a rusted cage lantern with a living flame inside, drifting low over the graves */
GYD.gywisp=(g,t,o)=>{const bob=Math.sin(t*2.6)*6,fl=gyFl(t,10),lg=(o&&o.lg)||0;g.save();g.lineJoin='round';g.lineCap='round';g.translate(0,-48+bob);
 /* trailing spirit-flame tail */
 for(let i=0;i<7;i++){const u=i/7,x=14+u*46,y=Math.sin(t*5-i*.7)*5*u+u*10;g.globalAlpha=.55*(1-u);ell(g,x,y,12*(1-u)+2,8*(1-u)+1.4,i%2?'#7affc8':'#4ad8b0')}g.globalAlpha=1;
 glow(g,0,0,64,'#5affb0'+hwA(.55*fl));
 /* chain and hook */
 g.strokeStyle='#5a5a62';g.lineWidth=2.4;g.setLineDash([4,3]);g.beginPath();g.moveTo(-1,-26);g.lineTo(-1,-44);g.stroke();g.setLineDash([]);g.strokeStyle='#3a3a42';g.lineWidth=2.4;g.beginPath();g.arc(-1,-46,4,0,Math.PI*1.2);g.stroke();
 /* the cage */
 poly(g,[-12,-24,10,-24,6,-30,-8,-30],'#3a3a44','#000a',1.2);poly(g,[-14,22,12,22,15,28,-17,28],'#2a2a32','#000a',1.2);
 g.save();g.beginPath();g.moveTo(-12,-24);g.lineTo(10,-24);g.lineTo(14,22);g.lineTo(-14,22);g.closePath();g.fillStyle=rgr(g,-1,0,2,24,'#f4fffacc','#3ad8a0aa');g.fill();g.restore();
 /* the flame creature */
 g.save();g.translate(-1,3);g.scale(1.3,1.25);g.beginPath();g.moveTo(-9,18);g.quadraticCurveTo(-13,2,-4,-10+Math.sin(t*9)*2);g.quadraticCurveTo(0,-20-fl*5,6,-8);g.quadraticCurveTo(13,4,9,18);g.closePath();g.fillStyle='#9affd0';g.fill();g.beginPath();g.moveTo(-5,16);g.quadraticCurveTo(-7,4,-1,-4);g.quadraticCurveTo(4,4,5,16);g.closePath();g.fillStyle='#f4fff8';g.fill();
 ell(g,-3.6,3,2.4,3.4,'#06301e');ell(g,3.6,3,2.4,3.4,'#06301e');ell(g,0,10,2,2.8,'#06301e');ell(g,-3.2,2.2,.8,1,'#eaffd8');ell(g,3.8,2.2,.8,1,'#eaffd8');g.restore();
 g.strokeStyle='#2a2a32';g.lineWidth=2.2;for(const x of[-12,-6,0,6,12]){g.beginPath();g.moveTo(x*.78-1,-24);g.lineTo(x*1.1-1,22);g.stroke()}
 g.strokeStyle='#8a4a1e88';g.lineWidth=1;for(const y of[-12,2,14]){g.beginPath();g.moveTo(-14,y);g.lineTo(13,y);g.stroke()}
 /* spark motes shake loose */
 for(let i=0;i<4;i++){const u=(t*.9+i/4)%1;g.globalAlpha=Math.sin(u*Math.PI);ell(g,Math.sin(u*6+i*2)*12,-30-u*22,1.4,1.4,'#eaffd8')}g.globalAlpha=1;g.restore()};

/* 5. Wailing Spectre: a chained ghost with a hollow mouth and a long tattered sheet */
GYD.gyghost=(g,t,o)=>{const bob=Math.sin(t*2.2)*7,lg=(o&&o.lg)||0,w=Math.sin(t*3.4);g.save();g.lineJoin='round';g.lineCap='round';g.translate(0,-50+bob);g.globalAlpha=.88;
 glow(g,0,0,76,'#bfe8ff44');
 /* body: a drifting shroud that thins into wisps */
 g.beginPath();g.moveTo(-18,-18);g.bezierCurveTo(-30,-48,22,-60,22,-22);g.bezierCurveTo(24,0,30+w*3,20,24,40);g.quadraticCurveTo(18,36,14,48+w*4);g.quadraticCurveTo(8,38,2,52-w*4);g.quadraticCurveTo(-4,40,-10,50+w*3);g.quadraticCurveTo(-16,40,-22,42);g.quadraticCurveTo(-30,16,-18,-18);g.closePath();
 g.fillStyle=vgr(g,-52,52,'#f4fbff','#7aa0c0aa');g.fill();g.strokeStyle='#e8f6ff';g.lineWidth=1.4;g.stroke();
 g.strokeStyle='#8ab0cc66';g.lineWidth=1;for(let i=0;i<4;i++){g.beginPath();g.moveTo(-12+i*8,-10);g.quadraticCurveTo(-14+i*8+w*2,16,-10+i*8,44);g.stroke()}
 /* reaching arms with shackles */
 for(const [sx,sy,k] of[[-14,-8,0],[10,-2,1]]){const ax=-40-lg*18+k*14,ay=4+k*8+Math.sin(t*3+k)*4;g.beginPath();g.moveTo(sx,sy);g.quadraticCurveTo(sx-16,sy-6,ax,ay);g.quadraticCurveTo(sx-14,sy+10,sx+2,sy+10);g.closePath();g.fillStyle=k?'#b8d4e8':'#e8f6ff';g.fill();g.strokeStyle='#ffffffaa';g.lineWidth=1;g.stroke();
  for(let i=0;i<3;i++)limb(g,ax,ay,ax-8-i*1.6,ay+3.4*(i-1)+Math.sin(t*5+i)*1.2,1.6,'#e8f6ff');
  g.strokeStyle='#6a6a74';g.lineWidth=2.6;g.beginPath();g.arc(sx-12,sy+1.6,3.4,0,TAU);g.stroke();g.strokeStyle='#5a5a62';g.lineWidth=1.8;g.setLineDash([3,2.4]);g.beginPath();g.moveTo(sx-12,sy+5);g.quadraticCurveTo(sx-12,sy+26,sx-4,sy+44+Math.sin(t*2+k)*3);g.stroke();g.setLineDash([])}
 /* face: huge hollow eyes, a wailing mouth */
 ell(g,-9,-34,5,7,'#0a1a2a');ell(g,3,-35,4,6,'#0a1a2a');g.globalAlpha=.7+.3*Math.sin(t*5);eye(g,-9,-34,1.9,'#aef0ff');eye(g,3,-35,1.5,'#aef0ff');g.globalAlpha=.88;
 const mo=5+Math.sin(t*3.4)*2.6;ell(g,-5,-22,4.6,mo*1.3,'#0a1a2a');ell(g,-5,-21,3,mo*.8,'#02070e');
 g.strokeStyle='#0a1a2a88';g.lineWidth=1.4;g.beginPath();g.moveTo(-14,-42);g.lineTo(-5,-39);g.moveTo(5,-42);g.lineTo(-1,-40);g.stroke();
 /* a tear of ectoplasm */
 {const u=(t*.7)%1;g.globalAlpha=(1-u)*.8;ell(g,-9,-27+u*22,1.4,2.4,'#aef0ff')}g.globalAlpha=1;g.restore()};

/* 6. Hex Cat: a black cat in a tiny witch's hat, back arched, green eyes burning */
GYD.gycat=(g,t,o)=>{const lg=(o&&o.lg)||0,s=Math.sin(t*9),b=Math.abs(Math.cos(t*9))*3,tw=Math.sin(t*3);g.save();g.lineJoin='round';g.lineCap='round';
 /* tail: a tall question-mark curl */
 g.strokeStyle='#14101c';g.lineWidth=8;g.beginPath();g.moveTo(24,-30-b);g.bezierCurveTo(44,-34,50+tw*3,-62,36+tw*4,-76);g.bezierCurveTo(30,-82,24+tw*3,-76,28,-70);g.stroke();g.strokeStyle='#2a2438';g.lineWidth=3;g.stroke();
 /* legs: stretched stride */
 const lgp=(x,ph,c)=>{const a=Math.sin(t*9+ph)*10;limb(g,x,-28-b,x+a*.5,-14,7,c);limb(g,x+a*.5,-14,x+a,-2,5.4,c);ell(g,x+a-3,-2,6,3.4,c)};
 lgp(18,Math.PI,'#0c0a12');lgp(-16,0,'#0c0a12');
 g.translate(0,-b);
 /* body: arched back, bristled fur along the spine */
 g.beginPath();g.moveTo(-26,-26);g.quadraticCurveTo(-24,-52,0,-58);g.quadraticCurveTo(26,-62,30,-38);g.quadraticCurveTo(28,-24,10,-22);g.quadraticCurveTo(-8,-18,-26,-26);g.closePath();g.fillStyle=vgr(g,-62,-18,'#2a2438','#0e0b14');g.fill();g.strokeStyle='#000000c0';g.lineWidth=1.6;g.stroke();
 for(let i=0;i<8;i++){const x=-18+i*6,y=-54-Math.sin(i/7*Math.PI)*5;poly(g,[x-2.4,y+2,x+.6,y-6-(i%2)*2,x+3,y+3],'#2a2438')}
 g.strokeStyle='#4a4260';g.lineWidth=1;g.beginPath();g.moveTo(-14,-40);g.quadraticCurveTo(0,-48,16,-42);g.stroke();
 limb(g,-18,-30,-30-lg*12,-26,6,'#0c0a12');ell(g,-34-lg*12,-24,5.4,3.6,'#0c0a12');
 /* head with the little hat */
 const hx=-30,hy=-52;g.save();g.translate(hx,hy);g.rotate(-.1);
 poly(g,[-12,-8,-14,-22,-6,-12],'#14101c','#000a',1.2);poly(g,[6,-10,10,-24,12,-9],'#14101c','#000a',1.2);poly(g,[-11,-9,-12,-18,-7,-11],'#8a3a6a');
 ell(g,0,0,14,12,rgr(g,-3,-4,1,18,'#2e2840','#0e0b14'));
 const fe=gyFl(t,5.4);glow(g,-6,-1,18,'#7aff5a'+hwA(.5*fe));ell(g,-6,-1,4.2,3.4,'#aaff5a');ell(g,5,-2,3.4,2.8,'#aaff5a');ell(g,-6,-1,.9,3.2,'#0a1004');ell(g,5,-2,.8,2.6,'#0a1004');
 poly(g,[-13,3,-10,4,-14,5],'#e8e0d0');poly(g,[-1,3.6,-3.4,3.6,-2.2,6.6],'#e8e0d0');poly(g,[-9,6,-6,8,-3,6],'#e8e0d0');
 poly(g,[-14,2,-10,3,-12,5],'#ff7a9a');g.strokeStyle='#e8e0d0';g.lineWidth=.8;for(const k of[-1,0,1]){g.beginPath();g.moveTo(-10,3+k*1.4);g.lineTo(-24,2+k*4+Math.sin(t*4)*.5);g.stroke()}
 /* witch hat and bell collar */
 ell(g,2,-10,16,3.8,'#2a1646');poly(g,[-6,-10,-3,-24,3,-34,12,-37+Math.sin(t*3)*1.4,8,-28,9,-11],'#38206a','#000a',1.2);poly(g,[-6,-10,9,-11,9,-15,-5,-14],'#ffb84a','#000a',.8);
 g.fillStyle='#6a3a9a';g.fillRect(-1,-5,0,0);g.restore();
 g.fillStyle='#8a2a2a';g.beginPath();g.roundRect(-34,-44,8,3,1.4);g.fill();ell(g,-30,-39,2.6,2.6,'#ffd070');
 g.restore();g.restore()};

/* 7. Mire Hag: a hooked-nose witch dragging a bubbling pot and a skeleton-key staff */
GYD.gywitch=(g,t,o)=>{const lg=(o&&o.lg)||0,s=Math.sin(t*4),b=Math.abs(Math.cos(t*4))*2;g.save();g.lineJoin='round';g.lineCap='round';
 /* the cauldron she drags on a chain */
 {const cx=40,sw=Math.sin(t*4+1)*2;g.save();g.translate(cx,0);glow(g,0,-22,40,'#7aff5a44');
  for(const x of[-14,14])poly(g,[x-4,-8,x+4,-8,x+2,0,x-2,0],'#1a1a20');
  g.beginPath();g.ellipse(0,-22,22,19,0,0,TAU);g.fillStyle=rgr(g,-6,-30,2,30,'#4a4a56','#14141a');g.fill();g.strokeStyle='#000';g.lineWidth=1.8;g.stroke();
  ell(g,0,-36,19,6,'#0a2a10');ell(g,0,-36,17,4.6,hsx(105,70,34+Math.sin(t*3)*4));
  for(let i=0;i<4;i++){const u=(t*.7+i/4)%1;g.globalAlpha=Math.sin(u*Math.PI);ell(g,-8+i*5.4,-38-u*20,2.4+u*2,2.4+u*2,'#9aff6a');g.strokeStyle='#d8ffb0';g.lineWidth=.8;g.stroke()}g.globalAlpha=1;
  g.strokeStyle='#5a5a66';g.lineWidth=1.4;g.beginPath();g.moveTo(-18,-22);g.lineTo(18,-22);g.stroke();g.restore();
  g.strokeStyle='#4a4a54';g.lineWidth=2.4;g.setLineDash([4,3]);g.beginPath();g.moveTo(cx-20,-24);g.quadraticCurveTo(14,-14+sw,4,-48);g.stroke();g.setLineDash([])}
 g.translate(0,-b);
 /* legs under the robe */
 for(const [x,ph] of[[-4,0],[6,Math.PI]]){const a=Math.sin(t*4+ph)*6;ell(g,x+a,-2,8,3.4,'#2a1a10')}
 /* hunched robe */
 g.beginPath();g.moveTo(-14,-92);g.quadraticCurveTo(-26,-60,-24,-6);g.lineTo(22,-6);g.quadraticCurveTo(22,-50,12,-86);g.quadraticCurveTo(-2,-98,-14,-92);g.closePath();g.fillStyle=hgr(g,-26,24,'#4a2a6a','#1a0e2a');g.fill();g.strokeStyle='#000b';g.lineWidth=1.8;g.stroke();
 poly(g,gyHem(-24,22,-6,9,5,t,1.2).concat([22,-6,-24,-6]),'#2a1646');
 g.strokeStyle='#8a5ab888';g.lineWidth=1.2;for(let i=0;i<3;i++){g.beginPath();g.moveTo(-14+i*10,-82);g.quadraticCurveTo(-16+i*10,-44,-18+i*10,-8);g.stroke()}
 g.fillStyle='#ffb84a';for(const [x,y] of[[-6,-60],[8,-36],[-14,-30]]){g.beginPath();for(let i=0;i<8;i++){const a=-Math.PI/2+i*Math.PI/4,r=i%2?1.4:3.6;g.lineTo(x+Math.cos(a)*r,y+Math.sin(a)*r)}g.closePath();g.fill()}
 poly(g,[-10,-50,8,-52,10,-46,-10,-44],'#2a1646','#ffb84a',1);
 /* arms: one stirs the air, one grips a key-topped staff */
 limb(g,-12,-80,-24,-68,7,'#3a2058');limb(g,-24,-68,-36-lg*14,-62-lg*8,6,'#6a8a52');for(let i=0;i<4;i++)limb(g,-37-lg*14,-62-lg*8,-46-lg*14,-62-lg*8+(i-1.5)*3.4,1.5,'#7a9a5a');
 limb(g,10,-84,18,-66,7,'#3a2058');limb(g,18,-66,20,-52,6,'#6a8a52');
 g.save();g.translate(21,-50);g.strokeStyle='#5a3a1e';g.lineWidth=3.4;g.beginPath();g.moveTo(0,52);g.lineTo(2,-52);g.stroke();g.strokeStyle='#8a5a30';g.lineWidth=1.2;g.beginPath();g.moveTo(.8,52);g.lineTo(2.8,-52);g.stroke();
 g.strokeStyle='#cfc8b0';g.lineWidth=2.4;g.beginPath();g.arc(3,-58,5,0,TAU);g.stroke();g.beginPath();g.moveTo(3,-53);g.lineTo(3,-40);g.moveTo(3,-44);g.lineTo(8,-44);g.moveTo(3,-40);g.lineTo(8,-40);g.stroke();glow(g,3,-58,14,'#7aff5a'+hwA(.4*gyFl(t,6)));g.restore();
 /* head: green face, huge hooked nose, wild hair, crooked hat */
 const hx=-6,hy=-103;g.save();g.translate(hx,hy);g.rotate(-.14);
 g.strokeStyle='#cfcfd8';g.lineWidth=2;for(let i=0;i<8;i++){g.beginPath();g.moveTo(8,-4+i*2.4);g.quadraticCurveTo(22+i*1.6,2+i*5+Math.sin(t*2+i)*3,16+i*2.4,18+i*5);g.stroke()}
 ell(g,0,0,12.4,13.6,rgr(g,-3,-5,1,18,'#9ac870','#4a7a3a'));
 poly(g,[-10,-1,-24,6,-18,10,-14,8,-9,5],'#8abc62','#000a',1.2);ell(g,-21,8,2.4,2,'#3a5a28');
 ell(g,-5,-3,3.4,3,'#0a1408');eye(g,-5,-3,1.5,'#ffe04a');ell(g,4,-4,2.6,2.4,'#0a1408');eye(g,4,-4,1.1,'#ffe04a');
 g.strokeStyle='#14240a';g.lineWidth=1.8;g.beginPath();g.moveTo(-10,-8);g.lineTo(-1,-6);g.moveTo(1,-9);g.lineTo(8,-7);g.stroke();
 g.strokeStyle='#14240a';g.lineWidth=1.5;g.beginPath();g.moveTo(-8,8);g.quadraticCurveTo(-2,12,6,7);g.stroke();poly(g,[-6,9,-4.4,13,-3,9.6],'#e8e0b0');ell(g,6,3,2.6,2,'#3a5a28');
 ell(g,1,-11,19,4.4,'#241044');poly(g,[-8,-11,-2,-34,6,-44,14,-48+Math.sin(t*2)*1.6,6,-36,9,-11],'#38206a','#000a',1.3);poly(g,[-8,-11,9,-12,8,-17,-7,-16],'#ffb84a','#000a',.8);ell(g,5,-15,2.4,3,'#241044');
 g.restore();g.restore()};

/* 8. Mausoleum Brute: a walking slab of tomb-stone with a coffin-lid shield and chained fists */
GYD.gybrute=(g,t,o)=>{const lg=(o&&o.lg)||0,s=Math.sin(t*3),b=Math.abs(Math.cos(t*3))*2,fl=gyFl(t,4);g.save();g.lineJoin='round';g.lineCap='round';
 const stone='#7a8088',sd='#3a3e46';
 const blk=(x,y,w,h,c,sk)=>{g.beginPath();g.moveTo(x+(sk||0),y);g.lineTo(x+w,y+(sk||0)*.4);g.lineTo(x+w-(sk||0),y+h);g.lineTo(x,y+h-(sk||0)*.3);g.closePath();g.fillStyle=hgr(g,x,x+w,shade(c,.2),shade(c,-.28));g.fill();g.strokeStyle='#000000c0';g.lineWidth=1.8;g.stroke();g.strokeStyle='#ffffff2a';g.lineWidth=1;g.beginPath();g.moveTo(x+2,y+2);g.lineTo(x+w-3,y+2);g.stroke()};
 /* legs: two stone pillars */
 blk(4+s*3,-52,24,50,shade(stone,-.15),3);blk(-28-s*3,-52,24,50,stone,3);
 g.translate(0,-b);
 /* torso: a stacked sarcophagus with a glowing crack */
 blk(-36,-120,72,72,stone,5);
 g.save();g.beginPath();g.rect(-36,-120,72,72);g.clip();g.strokeStyle='#3a3e4688';g.lineWidth=1.4;for(const y of[-102,-84,-66]){g.beginPath();g.moveTo(-36,y);g.lineTo(36,y+Math.sin(y)*2);g.stroke()}
 g.fillStyle='#4a6a3a77';for(const [x,y,w] of[[-30,-118,18],[10,-70,22]])g.fillRect(x,y,w,6);
 g.strokeStyle='#7aff8a';g.lineWidth=2.2;g.shadowColor='#7aff8a';g.shadowBlur=10*fl;g.beginPath();g.moveTo(-6,-120);g.lineTo(-2,-104);g.lineTo(-10,-92);g.lineTo(-4,-78);g.lineTo(-8,-62);g.stroke();g.shadowBlur=0;g.restore();
 /* engraved cross and R.I.P. plate */
 g.fillStyle='#2a2e36';g.fillRect(-16,-112,22,14);g.fillStyle='#8a929c';g.font='bold 9px serif';g.textAlign='center';g.fillText('R.I.P',-5,-102);g.textAlign='left';
 g.strokeStyle='#2a2e36';g.lineWidth=2.4;g.beginPath();g.moveTo(14,-110);g.lineTo(14,-70);g.moveTo(5,-100);g.lineTo(23,-100);g.stroke();
 /* shield arm: a coffin lid */
 g.save();g.translate(-50-lg*8,-96);g.rotate(-.18);poly(g,[-12,-34,12,-34,18,-6,6,30,-6,30,-18,-6],'#5a3a24','#000b',1.8);g.strokeStyle='#8a6a42';g.lineWidth=1.4;g.beginPath();g.moveTo(-6,-30);g.lineTo(-12,-6);g.lineTo(-3,26);g.moveTo(6,-30);g.lineTo(12,-6);g.lineTo(3,26);g.stroke();g.fillStyle='#cfc8b0';g.beginPath();g.arc(0,-10,5,0,TAU);g.fill();g.strokeStyle='#000';g.lineWidth=1;g.stroke();g.fillStyle='#14100a';g.fillRect(-2.6,-12,1.8,3);g.fillRect(.8,-12,1.8,3);g.restore();
 /* fist arm with a dangling chain */
 blk(24,-116,30,16,shade(stone,-.1),2);blk(34,-104,22,44,stone,2);g.save();g.translate(46,-56);blk(-12,-2,30,24,shade(stone,.05),3);g.restore();
 g.strokeStyle='#5a5a64';g.lineWidth=3;g.setLineDash([5,3.4]);g.beginPath();g.moveTo(44,-60);g.quadraticCurveTo(54,-40+Math.sin(t*3)*3,48,-22);g.stroke();g.setLineDash([]);ell(g,48,-20,6,6,'#3a3a42');
 /* head: a cracked statue's skull-face, one eye alight */
 const hx=-4,hy=-138;blk(-22,-146,36,34,shade(stone,.08),4);ell(g,-4,-130,13,13,rgr(g,-8,-134,1,18,shade(stone,.3),sd));
 ell(g,-10,-132,5,6,'#0a0c10');ell(g,3,-133,4,5,'#0a0c10');g.globalAlpha=fl;eye(g,-10,-132,2.6,'#7aff8a');eye(g,3,-133,2,'#7aff8a');g.globalAlpha=1;
 g.strokeStyle='#0a0c10';g.lineWidth=2;g.beginPath();g.moveTo(-14,-120);g.lineTo(2,-119);g.stroke();for(let i=0;i<5;i++){g.beginPath();g.moveTo(-12+i*3.4,-120);g.lineTo(-12+i*3.4,-115);g.stroke()}
 g.strokeStyle='#0a0c1099';g.lineWidth=1.4;g.beginPath();g.moveTo(-6,-146);g.lineTo(-3,-138);g.lineTo(-8,-133);g.stroke();
 g.restore()};

/* 9. Crypt Count: a high-collared vampire whose cape spreads into bat wings */
GYD.gyvamp=(g,t,o)=>{const lg=(o&&o.lg)||0,s=Math.sin(t*4),b=Math.abs(Math.cos(t*4))*1.4,fl=gyFl(t,5);g.save();g.lineJoin='round';g.lineCap='round';
 /* cape spread behind like wings */
 {const f=Math.sin(t*2.6)*.1;for(const [k,c] of[[1,'#220810'],[0,'#4a0f1e']]){g.save();g.translate(8,-100);g.rotate(-.1-f*(1+k)+k*.1);g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(40,-34,84,-26);g.quadraticCurveTo(70,-6,80,16);g.quadraticCurveTo(58,6,60,30);g.quadraticCurveTo(38,14,34,46);g.quadraticCurveTo(14,26,6,60);g.lineTo(0,50);g.closePath();g.fillStyle=c;g.fill();g.strokeStyle='#000b';g.lineWidth=1.6;g.stroke();g.strokeStyle='#00000066';g.lineWidth=1.2;g.beginPath();g.moveTo(0,0);g.lineTo(84,-26);g.moveTo(0,0);g.lineTo(80,16);g.moveTo(0,0);g.lineTo(60,30);g.stroke();g.restore()}}
 /* legs */
 for(const [x,ph,c] of[[5,Math.PI,'#12060c'],[-4,0,'#1a0a12']]){const a=Math.sin(t*4+ph)*8,kx=x+a*.5-2;limb(g,x,-44,kx,-24,8,c);limb(g,kx,-24,x+a,-4,7,c);poly(g,[x+a-10,-1,x+a+7,-1,x+a+5,-8,x+a-8,-8],'#0a0408','#000',1)}
 g.translate(0,-b);
 /* long coat and waistcoat */
 g.beginPath();g.moveTo(-15,-100);g.quadraticCurveTo(-20,-70,-18,-40);g.lineTo(-10,-30);g.lineTo(0,-40);g.lineTo(10,-30);g.lineTo(18,-40);g.quadraticCurveTo(20,-70,14,-100);g.closePath();g.fillStyle=hgr(g,-20,20,'#3a0c18','#14040a');g.fill();g.strokeStyle='#000';g.lineWidth=1.6;g.stroke();
 poly(g,[-5,-98,4,-98,6,-60,0,-48,-6,-60],'#e8dce4','#000a',1);g.fillStyle='#b01a38';for(const y of[-88,-76,-64])ell(g,0,y,1.6,1.6,'#b01a38');
 poly(g,[-6,-92,6,-92,4,-84,0,-80,-4,-84],'#8a1228');ell(g,0,-88,2.4,2.4,'#ff3a5a');
 /* arms: one hand open and clawed, one holding the cape */
 limb(g,-13,-96,-24,-80,7,'#2a0a14');limb(g,-24,-80,-38-lg*16,-72-lg*8,6,'#2a0a14');poly(g,[-36-lg*16,-76-lg*8,-40-lg*16,-72-lg*8,-36-lg*16,-68-lg*8],'#f0e6ee','#000a',.8);for(let i=0;i<4;i++)limb(g,-40-lg*16,-72-lg*8,-50-lg*16,-72-lg*8+(i-1.5)*3.2,1.4,'#e8dce4'),poly(g,[-50-lg*16,-72-lg*8+(i-1.5)*3.2-1,-55-lg*16,-72-lg*8+(i-1.5)*3.4,-50-lg*16,-72-lg*8+(i-1.5)*3.2+1],'#7a1228');
 limb(g,12,-96,22,-80,7,'#1a060e');limb(g,22,-80,16,-62,6,'#1a060e');ell(g,15,-60,3.4,3.4,'#e8dce4');
 /* collar and head */
 poly(g,[-14,-98,-22,-122,-8,-110,-4,-100],'#4a0f1e','#000',1.4);poly(g,[10,-98,22,-124,8,-112,3,-100],'#5a1426','#000',1.4);poly(g,[-12,-100,-18,-118,-8,-108],'#b01a38');
 const hx=-3,hy=-116;g.save();g.translate(hx,hy);g.rotate(-.05+Math.sin(t*2)*.03);
 ell(g,0,0,11.4,13.6,rgr(g,-3,-5,1,18,'#f2e8f0','#8a7a98'));
 g.fillStyle='#4a2a6a2a';g.beginPath();g.ellipse(5,3,4.6,7,0,0,TAU);g.fill();
 g.beginPath();g.moveTo(-12,0);g.bezierCurveTo(-14,-18,8,-20,12,-7);g.lineTo(10,-4);g.lineTo(5,-9);g.lineTo(2,-2);g.lineTo(-2,-10);g.bezierCurveTo(-7,-9,-9,-4,-9,2);g.closePath();g.fillStyle=hgr(g,-12,12,'#2a2034','#07040c');g.fill();g.strokeStyle='#000b';g.lineWidth=1.2;g.stroke();
 g.globalAlpha=fl;glow(g,-5,-1,14,'#ff2a4a88');g.globalAlpha=1;ell(g,-5,-1,3.4,2.4,'#2a0610');ell(g,-5,-1,2.4,1.8,'#ff3a5a');ell(g,-5,-1,.7,1.4,'#100');ell(g,4,-2,2.6,1.9,'#2a0610');ell(g,4,-2,1.8,1.4,'#ff3a5a');
 g.strokeStyle='#14040a';g.lineWidth=1.6;g.beginPath();g.moveTo(-10,-5.4);g.lineTo(-1,-3);g.moveTo(1,-5);g.lineTo(8,-3.4);g.stroke();
 poly(g,[-12,1,-16,6,-11,6],'#d8ccd8','#000a',.8);g.strokeStyle='#5a2434';g.lineWidth=1.3;g.beginPath();g.moveTo(-9,8);g.lineTo(0,8);g.stroke();poly(g,[-8,8,-6.4,8,-7.2,13],'#fff','#000a',.6);poly(g,[-2,8,-.6,8,-1.4,12.4],'#fff','#000a',.6);
 g.restore();
 /* mist curling at the hem */
 for(let i=0;i<4;i++){g.globalAlpha=.22+.08*Math.sin(t+i);ell(g,-18+i*12+Math.sin(t*.8+i)*4,-3,16,5,'#c8a0b8')}g.globalAlpha=1;
 g.restore()};

/* ---------- bosses ---------- */
/* Headless Horseman: a black charger, a rider with a flaming jack-o'-lantern held high */
GYD.bhorse=(g,t,o)=>{const lg=(o&&o.lg)||0,gl=Math.sin(t*5),b=Math.abs(Math.sin(t*5))*7,fl=gyFl(t,8);g.save();g.lineJoin='round';g.lineCap='round';
 /* horse: legs in a gallop, ghostly fire at the hooves */
 const leg=(x,ph,c)=>{const a=Math.sin(t*5+ph),kx=x+a*22,ky=-48+Math.abs(a)*-14;limb(g,x,-82-b,kx,ky,13,c);limb(g,kx,ky,x+a*34-6*Math.max(0,a),-8-Math.max(0,-a)*16,10,shade(c,-.1));poly(g,[x+a*34-14,-6-Math.max(0,-a)*16,x+a*34+6,-6-Math.max(0,-a)*16,x+a*34+4,-16-Math.max(0,-a)*16,x+a*34-12,-16-Math.max(0,-a)*16],'#14101a','#000',1.4);g.globalAlpha=.7;ell(g,x+a*34-4,-6-Math.max(0,-a)*16,10,6,'#7aff8a55');g.globalAlpha=1};
 leg(-62,0,'#1a1620');leg(46,Math.PI*.6,'#14101a');leg(-48,Math.PI*1.1,'#221c2a');leg(60,Math.PI*1.7,'#1a1620');
 g.translate(0,-b);
 /* body, tail, mane */
 g.beginPath();g.moveTo(-96,-100);g.quadraticCurveTo(-92,-140,-40,-146);g.quadraticCurveTo(30,-150,72,-130);g.quadraticCurveTo(100,-112,92,-86);g.quadraticCurveTo(60,-66,-8,-72);g.quadraticCurveTo(-72,-70,-96,-100);g.closePath();g.fillStyle=vgr(g,-150,-66,'#2a2432','#0e0a14');g.fill();g.strokeStyle='#000';g.lineWidth=2.4;g.stroke();
 g.strokeStyle='#4a4260';g.lineWidth=2;g.beginPath();g.moveTo(-60,-130);g.quadraticCurveTo(-8,-142,56,-122);g.stroke();
 for(let i=0;i<8;i++){const u=i/7,x=88-u*10,y=-118+u*20,w=Math.sin(t*5-i*.7)*10*(u+.3);g.strokeStyle=i%2?'#7aff8a':'#3ad88a';g.lineWidth=7-u*3;g.globalAlpha=.9-u*.3;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+24+w,y+8,x+48+w*1.4,y+26+u*10);g.stroke()}g.globalAlpha=1;
 /* neck and head (facing left) */
 g.beginPath();g.moveTo(-86,-122);g.quadraticCurveTo(-120,-150,-134,-176);g.quadraticCurveTo(-110,-190,-96,-176);g.quadraticCurveTo(-72,-150,-60,-116);g.closePath();g.fillStyle=hgr(g,-130,-60,'#2e2838','#14101a');g.fill();g.strokeStyle='#000';g.lineWidth=2.2;g.stroke();
 g.save();g.translate(-132,-184);g.rotate(-.2);poly(g,[8,-14,2,-34,16,-16],'#14101a','#000',1.4);g.beginPath();g.moveTo(12,-6);g.quadraticCurveTo(-8,-26,-34,-12);g.quadraticCurveTo(-52,-4,-50,12);g.quadraticCurveTo(-46,22,-32,18);g.quadraticCurveTo(-8,12,14,18);g.closePath();g.fillStyle=hgr(g,-50,14,'#3a3444','#18121e');g.fill();g.strokeStyle='#000';g.lineWidth=2.2;g.stroke();
 ell(g,-44,12,4,3,'#0a060e');glow(g,-18,-6,34,'#ff4a2a'+hwA(.6*fl));ell(g,-18,-6,6,4.2,'#ff6a3a');ell(g,-18,-6,2.6,3.2,'#fff0a0');g.strokeStyle='#8a8a98';g.lineWidth=1.4;for(let i=0;i<4;i++){g.beginPath();g.moveTo(-38+i*5,15);g.lineTo(-38+i*5,19);g.stroke()}
 for(let i=0;i<5;i++){const u=(t*1.4+i/5)%1;g.globalAlpha=1-u;ell(g,-50-u*20,10-u*10,6*(1-u)+2,4*(1-u)+1.4,'#cfd8e8')}g.globalAlpha=1;g.restore();
 /* saddle blanket */
 poly(g,[-36,-142,24,-146,28,-104,-30,-100],'#4a0f1e','#000a',1.6);g.strokeStyle='#ffb84a';g.lineWidth=2;g.beginPath();g.moveTo(-30,-106);g.lineTo(26,-110);g.stroke();
 /* the rider: cloak streaming back, no head */
 g.save();g.translate(-2,-142);g.scale(1.3,1.3);g.translate(2,142);
 g.beginPath();g.moveTo(-20,-148);g.quadraticCurveTo(-34,-196,-14,-230);g.lineTo(4,-232);g.quadraticCurveTo(70,-224,128,-170);g.quadraticCurveTo(80,-176,40,-142);g.closePath();g.fillStyle=hgr(g,-30,120,'#1a1228','#3a1a4a');g.fill();g.strokeStyle='#000';g.lineWidth=2;g.stroke();
 for(let i=0;i<5;i++){const x=40+i*18,w=Math.sin(t*4+i)*5;poly(g,[x,-186+i*7,x+14,-170+i*9+w,x+4,-164+i*9+w],'#0e0818')}
 g.beginPath();g.moveTo(-26,-150);g.quadraticCurveTo(-34,-188,-22,-216);g.lineTo(2,-218);g.quadraticCurveTo(14,-188,12,-150);g.closePath();g.fillStyle=hgr(g,-30,14,'#4a2a5a','#1a0e24');g.fill();g.strokeStyle='#000';g.lineWidth=1.8;g.stroke();
 poly(g,[-16,-216,-2,-218,0,-206,-14,-204],'#ffb84a','#000a',1);g.strokeStyle='#0a0612';g.lineWidth=3;g.beginPath();g.moveTo(-24,-216);g.quadraticCurveTo(-8,-226,8,-216);g.stroke();
 /* sword arm */
 limb(g,-10,-208,-26-lg*30,-190-lg*10,12,'#3a2250');limb(g,-26-lg*30,-190-lg*10,-50-lg*50,-176-lg*18,10,'#2a1840');ell(g,-52-lg*50,-176-lg*18,8,8,'#d8c0a0');
 g.save();g.translate(-52-lg*50,-176-lg*18);g.rotate(-.8-lg*.8);g.fillStyle='#3a2410';g.fillRect(-3,-4,6,16);poly(g,[-14,-6,14,-6,14,-12,-14,-12],'#8a8a98','#000',1.6);poly(g,[-9,-12,9,-12,6,-120,0,-136,-6,-120],'#d8dee8','#000',1.8);g.fillStyle='#ffffff66';g.fillRect(-1,-14,2,100);g.globalCompositeOperation='lighter';glow(g,0,-80,50,'#7aff8a'+hwA(.35*fl));g.restore();
 /* the jack-o'-lantern head, held high in the other hand */
 limb(g,12,-206,34,-238,12,'#3a2250');limb(g,34,-238,16,-264+Math.sin(t*3)*3,10,'#2a1840');
 {const px=2,py=-286+Math.sin(t*3)*3;glow(g,px,py,110,'#ff8a1a'+hwA(.55*fl));ell(g,px-14,py,10,22,shade('#e8741c',-.35));ell(g,px+14,py,10,22,shade('#e8741c',-.3));ell(g,px-6,py,14,24,shade('#e8741c',-.15));ell(g,px+7,py,14,23,shade('#e8741c',-.1));{const old=OL;OL=2;ell(g,px,py,16,25,rgr(g,px-5,py-9,2,32,shade('#e8741c',.3),'#e8741c'));OL=old}
  poly(g,[px-4,py-24,px-5,py-36,px+3,py-40,px+8,py-36,px+5,py-24],'#4a6a22','#14240a',1.6);
  const gc=fl>.9?'#fff0a0':'#ffd040';g.fillStyle=gc;g.strokeStyle='#4a1404';g.lineWidth=1.4;g.beginPath();g.moveTo(px-14,py-2);g.lineTo(px-3,py-2);g.lineTo(px-9,py-14);g.closePath();g.fill();g.stroke();g.beginPath();g.moveTo(px+3,py-2);g.lineTo(px+14,py-2);g.lineTo(px+8,py-14);g.closePath();g.fill();g.stroke();
  g.beginPath();g.moveTo(px,py+2);g.lineTo(px-4,py+9);g.lineTo(px+4,py+9);g.closePath();g.fill();g.stroke();g.fillStyle='#ffb020';g.beginPath();g.moveTo(px-14,py+12);g.lineTo(px-9,py+17);g.lineTo(px-5,py+13);g.lineTo(px,py+19);g.lineTo(px+5,py+13);g.lineTo(px+9,py+17);g.lineTo(px+14,py+12);g.lineTo(px+12,py+22);g.quadraticCurveTo(px,py+30,px-12,py+22);g.closePath();g.fill();g.stroke();
  for(let i=0;i<8;i++){const u=(t*1.1+i/8)%1;g.globalAlpha=Math.sin(u*Math.PI);ell(g,px+Math.sin(u*6+i*2)*14,py-42-u*46,2.2*(1-u)+.6,2.2*(1-u)+.6,i%2?'#ffd060':'#ff8a2a')}g.globalAlpha=1}
 g.restore();g.restore()};

/* The Pumpkin King: a vine-crowned gourd lord in a cloak of leaves, with a candle-skull scepter */
GYD.bpumpking=(g,t,o)=>{const lg=(o&&o.lg)||0,fl=gyFl(t,6.4),sw=Math.sin(t*1.8),b=Math.abs(Math.sin(t*2))*3;g.save();g.lineJoin='round';g.lineCap='round';
 /* writhing root-vine legs */
 for(const [x,ph] of[[-30,0],[34,2]]){for(let k=0;k<3;k++){const w=Math.sin(t*2+ph+k)*5;g.strokeStyle=k?'#3a5a1a':'#4a6a22';g.lineWidth=16-k*4;g.beginPath();g.moveTo(x-6+k*6,-90);g.bezierCurveTo(x+w-10,-60,x-14+k*10-w,-30,x-24+k*18+w,-2);g.stroke()}}
 g.translate(0,-b);
 /* cloak of leaves and straw */
 g.beginPath();g.moveTo(-70,-150);g.quadraticCurveTo(-96,-80,-84,-20);g.lineTo(84,-20);g.quadraticCurveTo(92,-80,64,-150);g.closePath();g.fillStyle=vgr(g,-170,-20,'#6a3a14','#2a1606');g.fill();g.strokeStyle='#000';g.lineWidth=2.4;g.stroke();
 for(let r=0;r<4;r++)for(let i=0;i<9;i++){const x=-76+i*18+(r%2)*9,y=-134+r*32,w=Math.sin(t*2+i+r)*2;g.save();g.translate(x,y);g.rotate(Math.sin(i*2.1+r)*.4+w*.03);leafG(g,0,0,0,26,9,['#b8501a','#d8781c','#8a3a10','#e0a030'][(i+r)%4]);g.restore()}
 g.fillStyle='#00000040';g.beginPath();g.moveTo(-70,-150);g.quadraticCurveTo(-96,-80,-84,-20);g.lineTo(-50,-20);g.quadraticCurveTo(-60,-80,-40,-150);g.fill();
 /* belt of skulls */
 g.fillStyle='#3a2410';g.fillRect(-72,-96,144,12);for(const x of[-48,-16,16,48]){ell(g,x,-90,8,8,'#e8e0c8');ell(g,x-3,-91,2,2.4,'#14100a');ell(g,x+3,-91,2,2.4,'#14100a')}
 /* arms of thick vine, one wielding the scepter */
 for(const [sx,sy,ex,ey,c] of[[-60,-150,-100-lg*30,-110-lg*6,'#4a6a22'],[56,-150,92,-100,'#3a5a1a']]){g.strokeStyle=c;g.lineWidth=18;g.beginPath();g.moveTo(sx,sy);g.quadraticCurveTo((sx+ex)/2-8,sy+30,ex,ey);g.stroke();g.strokeStyle=shade(c,.2);g.lineWidth=5;g.stroke();for(let i=0;i<4;i++)limb(g,ex,ey,ex-14+i*3-(sx<0?10:-4),ey+8+Math.sin(t*3+i)*3,3.4,shade(c,.1))}
 g.save();g.translate(-108-lg*30,-114-lg*6);g.rotate(-.1+sw*.03);g.strokeStyle='#5a3a1e';g.lineWidth=7;g.beginPath();g.moveTo(0,110);g.lineTo(0,-80);g.stroke();g.strokeStyle='#8a5a30';g.lineWidth=2;g.beginPath();g.moveTo(2,110);g.lineTo(2,-80);g.stroke();
 ell(g,0,-96,17,18,rgr(g,-5,-102,2,24,'#fffaf0','#c8c0a4'));ell(g,-6,-98,4.4,5,'#0a0806');ell(g,6,-98,4.4,5,'#0a0806');g.globalAlpha=fl;eye(g,-6,-98,2,'#ffb040');eye(g,6,-98,2,'#ffb040');g.globalAlpha=1;poly(g,[-2,-91,2,-91,0,-86],'#0a0806');
 g.fillStyle='#efe8d0';g.fillRect(-4,-118,8,14);ell(g,0,-122,4,6*fl+1,'#ffd040');glow(g,0,-124,40,'#ffb02088');g.restore();
 /* the great pumpkin head */
 const hx=-6,hy=-196;g.save();g.translate(hx,hy);g.rotate(sw*.025);glow(g,0,0,170,'#ff8a1a'+hwA(.5*fl));
 ell(g,-44,0,22,52,shade('#e8741c',-.4));ell(g,44,0,22,52,shade('#e8741c',-.32));ell(g,-22,0,32,58,shade('#e8741c',-.18));ell(g,24,0,32,57,shade('#e8741c',-.12));{const old=OL;OL=2.2;ell(g,0,0,38,60,rgr(g,-12,-22,4,76,shade('#e8741c',.32),'#e8741c'));OL=old}
 g.strokeStyle='#5a2406aa';g.lineWidth=2;for(const d of[-26,-9,9,26]){g.beginPath();g.moveTo(d*.4,-56);g.quadraticCurveTo(d*1.8,0,d*.5,58);g.stroke()}
 /* crown of thorned vine */
 g.strokeStyle='#3a5a1a';g.lineWidth=9;g.beginPath();g.moveTo(-40,-34);g.bezierCurveTo(-30,-72,-10,-52,0,-76);g.bezierCurveTo(10,-52,30,-72,40,-34);g.stroke();g.strokeStyle='#5a8a2a';g.lineWidth=3;g.stroke();for(let i=0;i<7;i++){const u=i/6,x=-38+u*76,y=-40-Math.sin(u*Math.PI)*30;poly(g,[x-3,y,x,y-14-Math.sin(u*Math.PI)*6,x+3,y],'#d8d0a0','#000a',1)}
 poly(g,[-6,-58,-8,-84,6,-92,14,-82,8,-58],'#4a6a22','#14240a',1.6);g.strokeStyle='#7aaa3a';g.lineWidth=3;g.beginPath();g.moveTo(10,-86);g.bezierCurveTo(26,-96,28,-76,18,-74);g.stroke();
 const gc=fl>.9?'#fff0a0':'#ffd040';g.fillStyle=gc;g.strokeStyle='#4a1404';g.lineWidth=2;
 g.beginPath();g.moveTo(-32,-4);g.lineTo(-6,-6);g.lineTo(-20,-34);g.closePath();g.fill();g.stroke();g.beginPath();g.moveTo(8,-6);g.lineTo(32,-4);g.lineTo(20,-34);g.closePath();g.fill();g.stroke();
 g.beginPath();g.moveTo(0,4);g.lineTo(-8,18);g.lineTo(8,18);g.closePath();g.fill();g.stroke();
 g.fillStyle='#ffb020';g.beginPath();g.moveTo(-34,24);g.lineTo(-24,34);g.lineTo(-16,26);g.lineTo(-8,36);g.lineTo(0,27);g.lineTo(8,36);g.lineTo(16,26);g.lineTo(24,34);g.lineTo(34,24);g.lineTo(30,42);g.quadraticCurveTo(0,60,-30,42);g.closePath();g.fill();g.stroke();
 g.fillStyle='#e8741c';for(const tx of[-14,0,14])g.fillRect(tx-2,27,4,12);
 ell(g,-17,-17,4,6,'#fff6c0');ell(g,19,-17,4,6,'#fff6c0');
 g.restore();
 for(let i=0;i<10;i++){const u=(t*.9+i/10)%1;g.globalAlpha=Math.sin(u*Math.PI)*.9;ell(g,hx+Math.sin(u*6+i*2)*34,hy-90-u*70,3*(1-u)+.8,3*(1-u)+.8,i%2?'#ffd060':'#ff8a2a')}g.globalAlpha=1;
 g.restore()};

/* Mother Hexmire: the coven's queen, a towering hag over a boiling cauldron, circled by candles and spirits */
GYD.bhexmire=(g,t,o)=>{const lg=(o&&o.lg)||0,fl=gyFl(t,5),hv=Math.sin(t*1.7)*6;g.save();g.lineJoin='round';g.lineCap='round';
 /* the cauldron: a cast-iron belly on three crooked legs, green fire beneath */
 g.save();g.translate(0,0);for(let i=0;i<5;i++){const u=(t*1.6+i/5)%1;g.globalAlpha=1-u;poly(g,[-30+i*14-6,-4,-30+i*14,-34-u*30,-30+i*14+6,-4],i%2?'#7aff8a':'#3ad88a')}g.globalAlpha=1;
 for(const x of[-50,0,50])poly(g,[x-8,-30,x+8,-30,x+5,0,x-5,0],'#14141a','#000',1.6);
 g.beginPath();g.ellipse(0,-76,84,56,0,0,TAU);g.fillStyle=rgr(g,-26,-100,4,100,'#5a5a66','#14141a');g.fill();g.strokeStyle='#000';g.lineWidth=2.8;g.stroke();
 g.strokeStyle='#8a8a98';g.lineWidth=7;g.beginPath();g.ellipse(0,-110,84,16,0,Math.PI,TAU);g.stroke();
 g.fillStyle='#d8d0b0';g.font='bold 22px serif';g.textAlign='center';g.fillText('☠',0,-68);g.textAlign='left';
 g.restore();
 /* the brew: bubbling green, spilling over */
 ell(g,0,-110,76,12,'#0a2a10');ell(g,0,-111,70,9,hsx(110,70,36+Math.sin(t*3)*5));
 for(let i=0;i<6;i++){const u=(t*.8+i/6)%1,x=-52+i*21;g.globalAlpha=Math.sin(u*Math.PI);ell(g,x,-112-u*40,5+u*4,5+u*4,'#9aff6a');g.strokeStyle='#e8ffd0';g.lineWidth=1.2;g.stroke()}g.globalAlpha=1;
 /* the witch rises from the steam */
 g.translate(0,hv);glow(g,0,-190,140,'#7aff5a'+hwA(.28*fl));
 g.beginPath();g.moveTo(-44,-110);g.quadraticCurveTo(-76,-170,-52,-250);g.lineTo(34,-252);g.quadraticCurveTo(70,-170,54,-110);g.closePath();g.fillStyle=hgr(g,-70,60,'#4a2a6a','#14081e');g.fill();g.strokeStyle='#000';g.lineWidth=2.4;g.stroke();
 g.strokeStyle='#8a5ab888';g.lineWidth=2;for(let i=0;i<5;i++){g.beginPath();g.moveTo(-34+i*18,-240);g.quadraticCurveTo(-40+i*18+Math.sin(t*2+i)*4,-170,-30+i*16,-114);g.stroke()}
 g.fillStyle='#ffb84a';for(const [x,y] of[[-20,-200],[16,-170],[-32,-150],[30,-216]]){g.beginPath();for(let i=0;i<8;i++){const a=-Math.PI/2+i*Math.PI/4,r=i%2?3.4:9;g.lineTo(x+Math.cos(a)*r,y+Math.sin(a)*r)}g.closePath();g.fill()}
 /* arms: reaching with long green hands, one conducting the circling candles */
 limb(g,-40,-232,-84-lg*30,-200-lg*8,13,'#3a2058');limb(g,-84-lg*30,-200-lg*8,-124-lg*50,-186-lg*12,10,'#6a8a52');for(let i=0;i<5;i++)limb(g,-126-lg*50,-186-lg*12,-148-lg*50,-186-lg*12+(i-2)*8+Math.sin(t*4+i)*3,3,'#7a9a5a'),poly(g,[-148-lg*50,-186-lg*12+(i-2)*8-2,-160-lg*50,-186-lg*12+(i-2)*9,-148-lg*50,-186-lg*12+(i-2)*8+2],'#2a1a10');
 limb(g,40,-234,70,-206,13,'#3a2058');limb(g,70,-206,86,-250,10,'#6a8a52');
 /* head with a towering hat */
 const hx=-6,hy=-274;g.save();g.translate(hx,hy);g.rotate(-.1+Math.sin(t*1.4)*.03);
 g.strokeStyle='#cfcfd8';g.lineWidth=3;for(let i=0;i<11;i++){g.beginPath();g.moveTo(14,-8+i*3.4);g.quadraticCurveTo(38+i*2,6+i*8+Math.sin(t*2+i)*5,28+i*3.4,36+i*8);g.stroke()}
 ell(g,0,0,28,30,rgr(g,-7,-10,2,40,'#9ac870','#3a6a2a'));
 poly(g,[-22,-2,-52,14,-40,22,-30,17,-20,10],'#8abc62','#000',1.8);ell(g,-46,17,5,3.6,'#2a4a1a');
 ell(g,-11,-6,7,6,'#0a1408');eye(g,-11,-6,3,'#ffe04a');ell(g,8,-8,5.4,5,'#0a1408');eye(g,8,-8,2.2,'#ffe04a');
 g.strokeStyle='#14240a';g.lineWidth=3;g.beginPath();g.moveTo(-22,-17);g.lineTo(-3,-12);g.moveTo(2,-18);g.lineTo(18,-14);g.stroke();
 g.strokeStyle='#14240a';g.lineWidth=2.4;g.beginPath();g.moveTo(-16,16);g.quadraticCurveTo(-3,26,14,14);g.stroke();for(const x of[-10,-2,6])poly(g,[x-2,19,x+2,19,x,26],'#e8e0b0','#000a',.8);
 ell(g,12,8,5,4,'#2a4a1a');
 ell(g,2,-24,42,9,'#241044');poly(g,[-14,-24,-6,-80,10,-112,34,-122+Math.sin(t*2)*3,16,-90,22,-24],'#38206a','#000',2);poly(g,[-14,-24,22,-26,20,-38,-12,-36],'#ffb84a','#000a',1.4);ell(g,4,-32,6,7,'#241044');
 glow(g,34,-122,22,'#7aff5a'+hwA(.6*fl));g.restore();
 /* circling candle flames and a pair of spirits */
 for(let i=0;i<5;i++){const a=t*.8+i*TAU/5,x=Math.cos(a)*118,y=-186+Math.sin(a)*22,zf=Math.sin(a)>0?1:.7;g.globalAlpha=zf;g.fillStyle='#efe8d0';g.fillRect(x-3,y,6,18);glow(g,x,y-6,22,'#ffb02088');ell(g,x,y-6,3,5*gyFl(t+i,9),'#ffd040');ell(g,x,y-5,1.4,2.6,'#fff')}g.globalAlpha=1;
 for(let i=0;i<2;i++){const a=t*.6+i*Math.PI+1;hwGhost(g,Math.cos(a)*100,-300+Math.sin(a)*30,1.3,t+i,'#dfffee',.55,'#04140c')}
 g.restore()};

const GYM={
 gyshamble:{n:'Grave Shambler',h:120,sp:46,th:100,ds:'A corpse that has not been told it is dead. It walks toward the nearest voice with one arm out.'},
 gydigger:{n:'Gravedigger Bones',h:124,sp:52,th:100,pj:'bone',rgp:.5,ds:'Still working the night shift. Throws bones when he cannot reach you with the spade.'},
 gyjack:{n:'Pumpkin Stalker',h:130,sp:50,th:112,tr:'bomb',ds:'A scarecrow with a lantern for a head. When the candle gutters it goes off like a bomb.'},
 gywisp:{n:'Lantern Wisp',h:96,sp:116,th:100,fly:1,ds:'A lost soul in a rusty lantern. It drifts low and lights the way to wherever you are.'},
 gyghost:{n:'Wailing Spectre',h:150,sp:70,th:116,fly:1,tr:'blink',ds:'Chained to a grave it cannot remember. Its wail carries it across the field in a blink.'},
 gycat:{n:'Hex Cat',h:84,sp:132,th:82,cx:-8,tr:'charge',ds:'A witch\'s familiar that skipped the witch. Sprints the moment you are in reach.'},
 gywitch:{n:'Mire Hag',h:176,sp:36,th:150,tr:'summon',ds:'Drags her cauldron from grave to grave and calls the dead to dinner.'},
 gybrute:{n:'Mausoleum Brute',h:236,sp:28,th:150,tr:'shield',ds:'A tomb that decided to leave. Its lid is a shield and its fists are headstones.'},
 gyvamp:{n:'Crypt Count',h:186,sp:42,th:130,tr:'blink',ds:'Old money, older hunger. He steps through the mist and is suddenly closer than he should be.'},
 bhorse:{n:'Headless Horseman',h:360,sp:60,th:290,tw:360,boss:1,cx:24,ds:'Rides every Halloween looking for a head. He has not found one he likes, so he carries a pumpkin.'},
 bpumpking:{n:'The Pumpkin King',h:380,sp:48,th:300,tw:330,boss:1,ds:'Ruler of the patch and everything that rots in it. His crown is thorns. His smile is carved.'},
 bhexmire:{n:'Mother Hexmire',h:390,sp:50,th:330,tw:360,boss:1,ds:'Queen of the coven. The brew is never finished, and you are on the list of ingredients.'}};
Object.assign(DR,GYD);Object.assign(MON,GYM);for(const k in GYD)MON[k].d=GYD[k];
Object.assign(ROARK,{bhorse:'howl',bpumpking:'hollow',bhexmire:'screech'});
const GY_MOBS=[['gyshamble','gydigger','gyjack'],['gywisp','gyghost','gycat'],['gywitch','gybrute','gyvamp']],GY_BOSS=['bhorse','bpumpking','bhexmire'];
