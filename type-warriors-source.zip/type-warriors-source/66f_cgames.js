/* ---------- casino games: shared painted backdrops for the canvas games ---------- */
function cdBulbs(g,x,y,w,h,now,fast,r){const step=26,pts=[];for(let i=x;i<=x+w;i+=step)pts.push([i,y]);for(let j=y+step;j<=y+h;j+=step)pts.push([x+w,j]);for(let i=x+w-step;i>=x;i-=step)pts.push([i,y+h]);for(let j=y+h-step;j>y;j-=step)pts.push([x,j]);
 const ph=Math.floor(now/(fast?110:360));pts.forEach((p,i)=>{const on=(i+ph)%3===0;if(on)cdGlow(g,p[0],p[1],r*3.2,'rgba(255,214,90,.5)');g.beginPath();g.arc(p[0],p[1],r,0,TAU);g.fillStyle=on?'#fff2a8':'#7a5a22';g.fill();g.lineWidth=1;g.strokeStyle='#2a1002';g.stroke()})}
function slBack(g,cv,now,win){const W=cv.width,H=cv.height;
 g.fillStyle=rgr(g,W/2,H/2,20,W*.62,'#5e1030','#12030a');g.fillRect(0,0,W,H);
 g.save();g.globalAlpha=.06;g.fillStyle='#ffd76a';for(let i=0;i<16;i++){const a=i/16*TAU;g.beginPath();g.moveTo(W/2,H/2);g.lineTo(W/2+Math.cos(a)*900,H/2+Math.sin(a)*900);g.lineTo(W/2+Math.cos(a+.1)*900,H/2+Math.sin(a+.1)*900);g.fill()}g.restore();
 g.beginPath();g.roundRect(3,3,W-6,H-6,18);g.lineWidth=6;g.strokeStyle=vgr(g,0,H,'#ffe48a','#a8681a');g.stroke();
 cdBulbs(g,7,7,W-14,H-14,now,win,4)}
function rkDeco(g,Wd,Ht,st){g.save();const mx=Wd*.86,my=Ht*.24;cdGlow(g,mx,my,190,'rgba(255,180,60,.26)');
 g.beginPath();g.arc(mx,my,50,0,TAU);g.fillStyle=rgr(g,mx-14,my-14,6,62,'#fff4b0','#d8921a');g.fill();g.fillStyle='rgba(176,110,16,.3)';
 for(const c of[[-16,-8,12],[14,12,9],[8,-22,7]]){g.beginPath();g.arc(mx+c[0],my+c[1],c[2],0,TAU);g.fill()}
 g.beginPath();g.moveTo(0,Ht);g.lineTo(0,Ht-30);for(let x=0;x<=Wd;x+=20)g.lineTo(x,Ht-26-Math.abs(Math.sin(x*.011+1)*30)-Math.sin(x*.07)*5);g.lineTo(Wd,Ht);g.closePath();g.fillStyle='#1c0a20';g.fill();
 g.strokeStyle='#f0c05055';g.lineWidth=2;g.stroke();
 for(let i=0;i<26;i++){const x=rnd(i*3)*Wd,y=Ht-6-rnd(i*7)*28;g.fillStyle='rgba(255,224,120,'+(.25+.3*Math.sin(performance.now()/500+i))+')';g.fillRect(x,y,2.4,2.4)}
 g.restore()}
function plBack(g,G){const bg=g.createLinearGradient(0,0,0,G.Ht);bg.addColorStop(0,'#150a34');bg.addColorStop(1,'#2a0a22');g.fillStyle=bg;g.fillRect(0,0,G.Wd,G.Ht);
 cdGlow(g,G.cx,G.top+90,420,'rgba(255,170,70,.12)');
 }
