/* ===== RUNESTONE TOWER DEFENSE 10.1f: coherent world maps (98u, registered last; prefix rpco) =====
   Owner report: the boat on the World 2 painting sailed through the castle and over land, the dolphins jumped backward, the river
   streaks on Mossgate Hollow ran over the bridge. Audit of everything that moves on the three hub paintings and the ten battle maps;
   the fixes live in the art modules themselves (95d, 95h, 98f, 98f2, 98f3, 98g3; backups .v10bak), this module holds the shared
   motion helpers they call:
   - rpcoPath / rpcoAt: a Catmull-Rom path with arc-length lookup (position and unit tangent at a distance along it).
   - rpcoLeap: a leap out of the water and back (dolphins): position plus the rotation that keeps the nose on the direction of travel
     (with the sprite mirrored by dir, the rotation is atan2(vy, |vx|); the old ang*dir turned a left-going dolphin upside down and
     backward). Drawn clipped at the water line, so it rises out of and dives into the sea instead of popping.
   - rpcoW2Ship: the little ship on the World 2 painting sails a water-only course (checked against the island and trench fields):
     up from the south through the lagoon between the reef, the cove and the trench, south of the channel rock, west past the reef
     castle's spires (behind them, never over them) and out past the lighthouse; bow first, a squash where it heads north, faded in
     and out off the painted sea.
   - rpcoShuttle: a ping-pong flight between two ends (airships): eased travel, a slow turn at each end (the sprite narrows through
     zero instead of flipping), so the bow always leads.
   - rpcoW3Air / rpcoW3Flock / rpcoW3Bal / rpcoW3Bolt: the World 3 painting's airships (an upper sky lane clear of the castles,
     chimneys and labels, and the dock beside Cloudspire), the flock (rises over the islands and leaves at the top, no castle in its
     way), the balloons (out of the chimney smoke) and the bolt (strikes the lightning rods beside the citadel, not through it).
   - rpcoFlipY: keeps side-on fish upright when they swim left (mirror instead of rotating through 180 degrees). */
const RPCO={};
function rpcoPath(pts,step){const L=rpwSpl(pts,step||6),c=[0];for(let i=1;i<L.length;i++)c.push(c[i-1]+Math.hypot(L[i][0]-L[i-1][0],L[i][1]-L[i-1][1]));return{L,c,len:c[c.length-1]}}
/* position and unit tangent at distance d along P (clamped) */
function rpcoAt(P,d){const L=P.L,c=P.c,n=L.length;d=Math.max(0,Math.min(P.len,d));let lo=0,hi=n-1;while(hi-lo>1){const m=(lo+hi)>>1;if(c[m]<=d)lo=m;else hi=m}
 const a=L[lo],b=L[hi],s=c[hi]-c[lo]||1,u=(d-c[lo])/s,dx=b[0]-a[0],dy=b[1]-a[1],m=Math.hypot(dx,dy)||1;return{x:a[0]+dx*u,y:a[1]+dy*u,tx:dx/m,ty:dy/m}}
const rpcoEio=u=>u<=0?0:u>=1?1:u<.5?2*u*u:1-2*(1-u)*(1-u);
/* a leap: u in [-k, 1+k] (outside 0..1 the body is under water and clipped); returns [x, y, rot] for scale(dir,1) then rotate(rot) */
function rpcoLeap(x0,y0,dir,u,span,amp){const x=x0+(u-.5)*span*dir,y=y0-Math.sin(u*Math.PI)*amp,vx=span*dir,vy=-Math.cos(u*Math.PI)*amp*Math.PI;return[x,y,Math.atan2(vy,Math.abs(vx))]}
/* draw a right-facing sprite S (centre cx, cy in it) leaping; clipped below the water line wy */
function rpcoLeapDraw(g,S,cx,cy,x,y,dir,rot,sc,wy){g.save();g.beginPath();g.rect(x-200,y-200,400,Math.max(0,wy-(y-200)));g.clip();g.translate(x,y);g.scale(dir*sc,sc);g.rotate(rot);g.drawImage(S,-cx,-cy);g.restore()}
/* side-on sprites swimming at heading h: rotate by h, and mirror vertically when heading left so the back stays up */
function rpcoFlipY(c,h){c.rotate(h);if(Math.cos(h)<0)c.scale(1,-1)}
/* ---------- World 2 painting: the ship's course ---------- */
const RPCO_W2SHIP=[[700,880],[688,770],[652,650],[618,548],[592,494],[556,468],[508,463],[466,450],[430,427],[380,400],[330,372],[230,364],[120,366],[-70,372]];
function rpcoW2Ship(t){const P=RPCO.w2s||(RPCO.w2s=rpcoPath(RPCO_W2SHIP,6)),sp=15,per=P.len/sp+14,d=((t%per)+per)%per*sp;
 if(d>P.len)return null;const q=rpcoAt(P,d),dir=q.tx<0?-1:1,k=Math.min(1,d/90,(P.len-d)/90);
 return{x:q.x,y:q.y,dir,sx:dir*Math.max(.55,Math.min(1,Math.abs(q.tx)*2.6)),a:Math.max(0,k),tx:q.tx,ty:q.ty}}
/* the dolphins on the World 2 painting: open sea east of the cove island (clear of the compass, the rock and the trench) */
const RPCO_W2DOL=[[1000,262,1],[1150,400,-1]];
function rpcoW2Dol(i,t){const [x0,y0,dir]=RPCO_W2DOL[i],ts=(t+i*3.1)%6.2;if(ts>1.9)return null;const u=ts/1.9*1.3-.15,[x,y,rot]=rpcoLeap(x0,y0,dir,u,60,30);return{x,y,rot,dir,u,x0,y0,ts}}
/* ---------- a ping-pong flight between the ends of a path ----------
   go = seconds per crossing, wait = seconds turning at each end; returns {x, y, f (sprite x scale: +1 facing right, -1 left), d} */
function rpcoShuttle(P,t,go,wait){const per=2*(go+wait),ph=((t%per)+per)%per;let d,back=false,turn=0;
 if(ph<go)d=P.len*rpcoEio(ph/go);else if(ph<go+wait){d=P.len;turn=(ph-go)/wait}else if(ph<2*go+wait){back=true;d=P.len*(1-rpcoEio((ph-go-wait)/go))}else{d=0;back=true;turn=(ph-2*go-wait)/wait}
 const q=rpcoAt(P,d),fw=Math.sign(q.tx)||1,f0=back?-fw:fw;let f=f0;if(turn)f=f0*Math.cos(turn*Math.PI);if(Math.abs(f)<.08)f=f<0?-.08:.08;return{x:q.x,y:q.y,f,d,back,turn}}
/* ---------- World 3 painting ---------- */
const RPCO_W3AIR=[{p:[[66,628],[30,642],[-40,660],[-120,670]],go:9,wait:5},{p:[[452,198],[640,188],[828,198]],go:26,wait:3.5}];
function rpcoW3Air(i,t){const A=RPCO_W3AIR[i],P=A.P||(A.P=rpcoPath(A.p,6));return rpcoShuttle(P,t+i*7,A.go,A.wait)}
const RPCO_W3FLOCK=[[-70,352],[200,302],[450,238],[700,132],[900,-70]];
function rpcoW3Flock(t){const u=(t/26)%1;if(u>=.6)return null;const P=RPCO.w3f||(RPCO.w3f=rpcoPath(RPCO_W3FLOCK,8)),q=rpcoAt(P,u/.6*P.len);return q}
const RPCO_W3BAL=[[576,628,18,10],[905,168,14,10]];/* centre x, y, drift x, drift y */
function rpcoW3Bal(i,t){const [x,y,ax,ay]=RPCO_W3BAL[i];return[x+Math.sin(t*.07+i*2)*ax,y+Math.sin(t*.19+i)*ay]}
const RPCO_W3ROD=[-130,130];/* the outer lightning rods beside the citadel (rpw3aWorld paints rods at dx -130, -90, 90, 130) */
function rpcoW3Bolt(W,t){const ph=t%3.1,k=Math.floor(t/3.1);if(ph>=.3)return null;const [x,y]=W.storm,ex=x+RPCO_W3ROD[k%2],ey=y-26;return{ph,k,ex,ey,sx:ex+(rpw3aR(k+3)-.5)*24,sy:y-210}}
