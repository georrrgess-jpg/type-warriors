/* ===== MOONLIT FISHING: data, odds, economy and save state =====
   A calm typing minigame at the tavern pond. Cast, wait for a bite, then type the word before the fish slips away.
   Rarer fish bring longer words and more reeling stages. Catches fill the Fish Bestiary (counts, sizes, records),
   can be sold for gold or kept in the creel and turned in for fishing-rod cosmetics. Gold buys rod upgrades.
   Save: P.fish (created on first use by fsP()). Art: 90b/90c (FISHART), scene 90d, game 90e, menus 90f. */
const FSR={/* rarity: colour, base odds (%), reeling stages, line hearts, word pool, label */
 c:{n:'Common',c:'#cfd6e6',o:74.75,st:1,hp:1,k:0,pl:.46},
 u:{n:'Uncommon',c:'#6ee08a',o:20,st:1,hp:1,k:1,pl:.40},
 r:{n:'Rare',c:'#5ab8ff',o:5,st:2,hp:1,k:2,pl:.40},
 l:{n:'Legendary',c:'#ffc23a',o:.25,st:3,hp:2,k:3,pl:.36}};
const FSRK=['c','u','r','l'];
/* the 30 fish (24 at the Tavern Pond, 6 more at the new spots). len = [min,max] in cm; v = base sale value in gold at average size; w = relative weight inside its rarity;
   home = where it is drawn swimming in the bestiary blurb; d = one short line of lore */
const FISH={
 reed:{n:'Reed Darter',r:'c',len:[6,14],v:4,w:12,d:'A quick little dart of gold that hides between the reeds.'},
 ember:{n:'Ember Carp',r:'c',len:[20,48],v:6,w:11,d:'Its scales stay warm long after the sun goes down.'},
 moss:{n:'Mossback Perch',r:'c',len:[14,32],v:4,w:11,d:'Wears the pond on its back: stripes of moss and shadow.'},
 lant:{n:'Lantern Guppy',r:'c',len:[3,7],v:4,w:9,d:'Its tail glows like a tiny lantern. Travellers follow it home.'},
 pebble:{n:'Pebble Loach',r:'c',len:[8,18],v:4,w:10,d:'Lies so still on the bottom that it is often mistaken for a stone.'},
 copper:{n:'Copper Trout',r:'c',len:[22,46],v:6,w:9,d:'A shining stream trout with a rosy stripe. A tavern favourite.'},
 whisker:{n:'Whisker Catfish',r:'c',len:[25,60],v:6,w:8,d:'Grumpy, whiskery and older than the dock it lives under.'},
 lily:{n:'Lily Sunfish',r:'c',len:[10,22],v:4,w:10,d:'Round as a lily pad, with a belly the colour of sunset.'},
 bramble:{n:'Bramble Pike',r:'c',len:[40,90],v:7,w:7,d:'Long, toothy and patient. It strikes like a snapping branch.'},
 willow:{n:'Willow Shiner',r:'c',len:[9,18],v:4,w:10,d:'A slender silver flash that swims in shoals under the willows.'},
 frost:{n:'Frostscale Trout',r:'u',len:[25,52],v:15,w:10,d:'Swims up from the cold springs. Frost forms where it surfaces.'},
 thorn:{n:'Thornback Gar',r:'u',len:[50,110],v:17,w:8,d:'Armoured in bronze plates, with a snout full of needle teeth.'},
 bog:{n:'Bog Puffer',r:'u',len:[10,24],v:14,w:10,d:'Puffs into a spiky ball when startled. Mostly harmless. Mostly.'},
 twilight:{n:'Twilight Eel',r:'u',len:[60,140],v:16,w:9,d:'Its glowing spots come out one by one, like stars at dusk.'},
 rose:{n:'Rosefin Angelfish',r:'u',len:[12,26],v:16,w:9,d:'Tall, graceful and striped like a rose garden at night.'},
 cinder:{n:'Cinder Betta',r:'u',len:[6,12],v:19,w:8,d:'Its long fins flicker like the last embers of a campfire.'},
 glass:{n:'Glassfin',r:'u',len:[8,16],v:19,w:7,d:'Clear as water. You can see its tiny glowing heart beating.'},
 moonfin:{n:'Silver Moonfin',r:'r',len:[28,52],v:48,w:11,d:'Only rises when the moon is high. Its fins are curved like crescents.'},
 angler:{n:'Dusk Angler',r:'r',len:[30,64],v:55,w:9,d:'Dangles a little moon of its own to lure the curious.'},
 ray:{n:'Ghostwing Ray',r:'r',len:[60,130],v:61,w:8,d:'Glides through the deep like a pale ghost. Fishers swear it watches them.'},
 sun:{n:'Sunscale Sturgeon',r:'r',len:[90,180],v:68,w:7,d:'An ancient armoured giant that carries the noon sun on its back.'},
 aurora:{n:'Aurora Koi',r:'l',len:[60,96],v:340,w:10,d:'Said to be born from a falling star. Its ribbons hold every colour of the northern lights.'},
 moonmaw:{n:'Moonmaw',r:'l',len:[180,320],v:390,w:8,d:'The pond\'s oldest secret. A pale moon glows deep inside its jaws.'},
 tidecrown:{n:'Tidecrown',r:'l',len:[120,220],v:440,w:6,d:'The sunken king of the pond, crowned in coral and gold.'},
 smelt:{n:'Snowdrift Smelt',r:'c',len:[8,16],v:5,w:12,loc:'frost',d:'Swims in glittering schools under the ice. Smells faintly of fresh snow.'},
 tetra:{n:'Glowcap Tetra',r:'c',len:[3,6],v:5,w:12,loc:'grotto',d:'A living spark. Whole shoals light the grotto like falling stars.'},
 char:{n:'Glacier Char',r:'u',len:[30,64],v:16,w:10,loc:'frost',d:'Crimson-bellied and frost-spotted. It only bites in water cold enough to sting.'},
 cavefish:{n:'Crystal Cavefish',r:'u',len:[12,26],v:17,w:10,loc:'grotto',d:'Blind and gentle. Amethyst crystals grow from its back as it ages.'},
 flyfish:{n:'Icewing Flyfish',r:'r',len:[25,45],v:58,w:10,loc:'frost',d:'Leaps from the lake on wings of living ice and glides beneath the aurora.'},
 wyrm:{n:'Lumenwyrm',r:'l',len:[250,420],v:420,w:8,loc:'grotto',d:'An ancient dragon of the deep caves. Light ripples down its body like a slow song.'}};
const FIDS=Object.keys(FISH);
/* fishing spots: each has its own fish pool and scene; new spots open as you discover more species */
const FSLOCS={
 pond:{n:'Tavern Pond',d:'Lantern light, lily pads and the castle on the hill.',need:0,c:'#ffd45a'},
 frost:{n:'Frostfall Lake',d:'A frozen mountain lake under the northern lights.',need:10,c:'#9ff0ff'},
 grotto:{n:'Glowcap Grotto',d:'A hidden cave lagoon lit by glowing mushrooms and crystals.',need:18,c:'#c47aff'},
 storm:{n:'Stormreach Coast',d:'Wild cliffs, crashing waves and lightning over the sea.',need:99,soon:1,c:'#7ab8ff'}};
const FSLOCK=Object.keys(FSLOCS);
/* which fish live where: the pond keeps its 24; each new spot has 3 of its own plus pond fish that suit it */
const FSPOOL={pond:FIDS.filter(i=>!FISH[i].loc),
 frost:['smelt','reed','willow','char','frost','glass','flyfish','moonfin','aurora'],
 grotto:['tetra','lant','pebble','cavefish','twilight','cinder','angler','ray','wyrm','moonmaw'],storm:[]};
FIDS.forEach(i=>{FISH[i].at=FSLOCK.filter(k=>FSPOOL[k].includes(i))});
const fsLoc=()=>{const F=fsP(),k=F.loc;return FSLOCS[k]&&!FSLOCS[k].soon&&fsLocOpen(k)?k:'pond'};
function fsLocOpen(k){const L=FSLOCS[k];return !!L&&!L.soon&&fsFound()>=L.need}
/* catch words: longer and rarer words for rarer fish; Legendary fights pull one word per stage from the epic pool */
const FSW=[
 'moon reed tide pond wave mist lily dusk foam glow cast hook reel bait line fern moss rain cove dock bank lake star wind calm drift brook creek gleam shoal float river marsh perch skiff oar lure net cool dew shell sand frog newt',
 'ripple lantern current harbor minnow shimmer glimmer moonlit silver mirror crystal tadpole seaweed starlit bubbles glisten whisper eclipse crescent willow pebble splash firefly lagoon rowboat mooring cattail waters nightly',
 'moonbeam starlight waterfall nightshade reflection undertow riverbank silverfin lighthouse luminous shimmering moonshine starglow fireflies driftwood stillwater kingfisher whirlpool dragonfly nightfall',
 'leviathan moonstruck tidecaller everglow starfall moonshadow abyssal constellation thunderous everlasting nightwater moonlight kingdom ancient behemoth stormborn'
].map(s=>s.split(' '));
/* rod upgrades, bought with gold. Line: more time per letter. Lure: shorter waits and better odds. Hook: bigger fish (worth more). */
const FSUP={
 line:{n:'Line',d:'More time to type before the fish slips away.',fx:l=>l?`+${l*10}% time`:'base time',c:[200,500,1100,2400,5000]},
 lure:{n:'Lure',d:'Fish bite sooner, and rare fish bite more often.',fx:l=>`${l?'-'+l*6+'% wait, ':''}rare luck ${['×1','×1.08','×1.16','×1.26','×1.38','×1.5'][l]}`,c:[250,600,1300,2800,5600]},
 hook:{n:'Hook',d:'Bigger fish (worth more) and more giants.',fx:l=>l?`+${l*4}% size`:'base size',c:[200,500,1100,2400,5000]}};
const FSUPK=['line','lure','hook'];
/* the rod's name follows its total upgrade level (0-15) */
const FSRODN=[[0,'Willow Rod'],[3,'Ashwood Rod'],[6,'Moonreed Rod'],[10,'Starwoven Rod'],[15,'Tidecaller Rod']];
/* rod looks, earned by turning in kept fish (cosmetic only). k: fish id -> count */
const FSKIN={
 willow:{n:'Willow',d:'A trusty rod cut from the tavern willow.',k:{},c:['#8a5a2e','#c88a4a'],ln:'#f4ecd8',tip:'#ffd45a',bob:['#e8364e','#fff8e8']},
 ember:{n:'Emberwood',d:'Warm to the touch and glowing at the tip.',k:{ember:5,cinder:1},c:['#7a2a12','#ff7a2a'],ln:'#ffd0a0',tip:'#ff9a3a',bob:['#ff5a1a','#ffe07a'],gl:'#ff8a3a'},
 frost:{n:'Frostline',d:'Pale ice-wood with a line that never tangles.',k:{frost:3,glass:2},c:['#3a6a9a','#bfe8ff'],ln:'#e8f8ff',tip:'#9ff0ff',bob:['#5ad8ff','#ffffff'],gl:'#9ff0ff'},
 moonreed:{n:'Moonreed',d:'Woven from reeds that grow in moonlight.',k:{moonfin:2,twilight:2,willow:3},c:['#2a2a6a','#a8a0ff'],ln:'#d8d0ff',tip:'#c8b8ff',bob:['#8a6aff','#fff8e8'],gl:'#a88aff'},
 abyss:{n:'Abyssal',d:'Carved from black driftwood found at the bottom of the pond.',k:{angler:2,ray:1,whisker:4},c:['#1a1036','#6a3aff'],ln:'#b89aff',tip:'#ff6ae8',bob:['#2a1a5a','#ff6ae8'],gl:'#c86aff'},
 sun:{n:'Sunforged',d:'Gilded brass and a sunstone at the tip.',k:{sun:1,copper:6,thorn:2},c:['#8a5a10','#ffd45a'],ln:'#fff2b0',tip:'#ffe27a',bob:['#ffc23a','#fff8e8'],gl:'#ffd45a'},
 aurora:{n:'Aurora',d:'Every colour of the northern lights, all at once. Proof of a true master angler.',k:{aurora:1,moonmaw:1,tidecrown:1},c:['#2a1a6a','#7affd8'],ln:'#ffffff',tip:'#ffffff',bob:['#ff7ae0','#7affd8'],gl:'#7affd8',rb:1}};
const FSKINK=Object.keys(FSKIN);
/* tonight's moon (changes daily): one featured fish bites twice as often and sells for +50%; the full moon raises legendary odds */
const FSMOON=[['New Moon','A dark night. Rare fish stir in the deep.',{r:1.25}],['Waxing Crescent','A gentle night for fishing.',{}],['First Quarter','Uncommon fish are restless.',{u:1.2}],['Waxing Gibbous','The pond glitters. Rare fish rise.',{r:1.15}],
 ['Full Moon','The moon is full. Legends wake.',{l:1.6}],['Waning Gibbous','Calm water and steady bites.',{wait:.85}],['Last Quarter','Big fish prowl the shallows.',{size:1.06}],['Waning Crescent','Quiet water. Every fish is hungry.',{wait:.8}]];
function fsDayN(){const k=dcKey().split('-').map(Number);return Math.floor(Date.UTC(k[0],k[1]-1,k[2])/864e5)}
function fsMoon(){const n=fsDayN(),ph=((n%8)+8)%8,M=FSMOON[ph];const pool=FSPOOL[typeof fsLoc==='function'&&P.fish?fsLoc():'pond'].filter(id=>FISH[id].r!=='l');return{ph,n:M[0],d:M[1],m:M[2],feat:pool[(n*7+3)%pool.length]}}
/* save state */
function fsP(){if(!P.fish||typeof P.fish!=='object')P.fish={};const F=P.fish;
 F.b=F.b||{};/* bestiary: id -> {n caught, big cm, bigT time, g giants, t first catch} */
 F.cr=Array.isArray(F.cr)?F.cr:[];/* creel: kept fish [{id,cm,g}] */
 F.up=F.up||{line:0,lure:0,hook:0};F.sk=F.sk||{willow:1};F.skin=F.skin&&F.sk[F.skin]?F.skin:'willow';
 F.s=F.s||{};/* stats: cast caught esc gold leg giant best streak fast (letters/s) big */
 F.seen=F.seen||0;return F}
const fsLv=()=>{const u=fsP().up;return (u.line||0)+(u.lure||0)+(u.hook||0)};
const fsRodName=()=>{const l=fsLv();let n=FSRODN[0][1];for(const [k,v] of FSRODN)if(l>=k)n=v;return n};
const fsFound=()=>FIDS.filter(id=>fsP().b[id]&&fsP().b[id].n).length;
const FSCREEL=30;/* creel capacity */
/* odds for a cast, as {c,u,r,l} percentages (sums to 100) */
function fsOdds(lure,moon){lure=lure==null?fsP().up.lure||0:lure;moon=moon||fsMoon().m;const luck=[1,1.08,1.16,1.26,1.38,1.5][lure];
 const r=FSR.r.o*luck*(moon.r||1),l=FSR.l.o*luck*(moon.l||1),u=FSR.u.o*(1+(luck-1)*.5)*(moon.u||1),c=Math.max(5,100-r-l-u);const s=c+u+r+l;return{c:c/s*100,u:u/s*100,r:r/s*100,l:l/s*100}}
/* roll a fish for a cast */
function fsRoll(rnd){rnd=rnd||Math.random;const F=fsP(),M=fsMoon(),o=fsOdds(F.up.lure||0,M.m);let x=rnd()*100,rk='c';for(const k of FSRK){if(x<o[k]){rk=k;break}x-=o[k]}
 const pl=FSPOOL[fsLoc()]||FSPOOL.pond,ids=pl.filter(id=>FISH[id].r===rk),ws=ids.map(id=>FISH[id].w*(id===M.feat?2:1)),tot=ws.reduce((a,b)=>a+b,0);let y=rnd()*tot,id=ids[0];for(let i=0;i<ids.length;i++){if(y<ws[i]){id=ids[i];break}y-=ws[i]}
 /* size: a soft bell inside the range, nudged up by the Hook; the top 4% are Giants */
 const f=FISH[id],hk=(F.up.hook||0)*.04*(M.m.size?1:1)+(M.m.size?M.m.size-1:0),b=(rnd()+rnd()+rnd())/3,u=Math.min(1,b*(1+hk)),giant=rnd()<.04+(F.up.hook||0)*.006;
 const uu=giant?Math.min(1,.92+rnd()*.08+hk*.2):Math.min(.92,u);const cm=Math.round((f.len[0]+(f.len[1]-f.len[0])*uu)*10)/10;
 return{id,rk,cm,g:giant}}
/* sale value: base x size factor (bigger is worth more), giants x2 (x2.5 with a max Hook), featured fish +50% */
function fsValue(c){const f=FISH[c.id],mid=(f.len[0]+f.len[1])/2,sz=Math.pow(Math.max(.4,c.cm/mid),1.25),hk=fsP().up.hook||0;let v=f.v*sz*(c.g?2:1);if(c.ft!=null?c.ft:c.id===fsMoon().feat)v*=1.5;return Math.max(1,Math.round(v))}
/* words for a catch: one per stage, never repeating inside a fight */
let FSRECENT=[];
function fsWords(rk){const k=FSR[rk].k,st=FSR[rk].st,out=[];for(let i=0;i<st;i++){const pool=FSW[Math.min(3,k===3?(i===st-1?3:2):k)].filter(w=>!out.includes(w)&&!FSRECENT.includes(w));const w=pool[Math.random()*pool.length|0]||FSW[k][0];out.push(w)}
 FSRECENT=FSRECENT.concat(out).slice(-12);return out}
/* time for one word (seconds): a little reaction time plus time per letter (less per letter for rarer fish); Line upgrades add 10% each */
function fsTime(w,line,rk){line=line==null?fsP().up.line||0:line;return (1.4+w.length*(FSR[rk||'c'].pl))*(1+line*.1)}
/* wait before a bite (seconds); the Lure and some moons shorten it */
function fsWait(rnd){rnd=rnd||Math.random;const l=fsP().up.lure||0,m=fsMoon().m;return (2.2+rnd()*3.6)*(1-l*.06)*(m.wait||1)}
const fsUpCost=k=>{const l=fsP().up[k]||0;return l>=5?null:FSUP[k].c[l]};
function fsBuyUp(k){const c=fsUpCost(k);if(c==null||P.gold<c)return false;P.gold-=c;fsP().up[k]=(fsP().up[k]||0)+1;fsSt('spent',c,'add');save();return true}
function fsSt(k,v,m){const s=fsP().s;if(m==='add')s[k]=(s[k]||0)+v;else if(m==='set')s[k]=v;else if(v>(s[k]||0))s[k]=v}
/* record a successful catch in the bestiary; returns {first, record} */
function fsRecord(c,secs,letters){const F=fsP(),b=F.b[c.id]||(F.b[c.id]={n:0,big:0,g:0});const first=!b.n,rec=c.cm>(b.big||0);b.n++;if(first)b.t=Date.now();if(rec){b.big=c.cm;b.bigT=Date.now()}if(c.g)b.g=(b.g||0)+1;
 fsSt('caught',1,'add');if(c.rk==='l')fsSt('leg',1,'add');if(c.g)fsSt('giant',1,'add');F.streak=(F.streak||0)+1;fsSt('best',F.streak);if(secs>0&&letters>=5)fsSt('fast',Math.round(letters/secs*10)/10);
 if(c.cm>(F.s.bigCm||0)&&c.rk!=='c'||!F.s.bigId){/* biggest catch overall, by size relative to its species range */}
 const f=FISH[c.id],rel=(c.cm-f.len[0])/(f.len[1]-f.len[0]);if(!F.s.bigId||c.cm>(F.s.bigCm||0)){F.s.bigId=c.id;F.s.bigCm=c.cm}
 save();return{first,record:rec&&!first,rel}}
/* sell or keep */
function fsSell(c){const v=fsValue(c);P.gold+=v;fsSt('gold',v,'add');try{stat('gold',v,'add')}catch(e){}save();return v}
function fsKeep(c){const F=fsP();if(F.cr.length>=FSCREEL)return false;F.cr.push({id:c.id,cm:c.cm,g:c.g?1:0,ft:c.ft!=null?c.ft:(c.id===fsMoon().feat?1:0)});save();return true}
function fsSellCreel(i){const F=fsP(),c=F.cr[i];if(!c)return 0;F.cr.splice(i,1);return fsSell(c)}
/* rod looks: can it be crafted from the creel? turning in uses the smallest kept fish of each kind first */
function fsCanSkin(k){const S0=FSKIN[k],F=fsP();if(F.sk[k])return false;return Object.entries(S0.k).every(([id,n])=>F.cr.filter(c=>c.id===id).length>=n)}
function fsCraft(k){if(!fsCanSkin(k))return false;const F=fsP();for(const [id,n] of Object.entries(FSKIN[k].k)){for(let j=0;j<n;j++){let bi=-1;F.cr.forEach((c,i)=>{if(c.id===id&&(bi<0||c.cm<F.cr[bi].cm))bi=i});F.cr.splice(bi,1)}}
 F.sk[k]=1;F.skin=k;fsSt('skins',Object.keys(F.sk).length,'set');save();return true}
