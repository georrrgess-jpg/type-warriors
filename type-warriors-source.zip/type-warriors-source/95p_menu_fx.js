/* ===== 9.2: smooth menu transitions (95p, after 95o) =====
   Menu screens used to swap in one frame. Now, when show() opens a different menu screen (S.mode 'title'), the new page rises 12 px
   and fades in (0.34 s, a soft overshoot curve) while a thin indigo veil over the stage fades out, so every screen change reads as one
   smooth move. Pages that keep their shell (the sidebar) only move their content. A screen that re-renders itself (the same screen
   key: the class list and the root class of the new HTML) does not replay it, so picking a map on the hub or a skin does not flicker.
   Web Animations on transform and opacity only (no layout, no filters); nothing in the DOM is duplicated or delayed, so code that
   reads the new page right after show() is unaffected. Off with reduced motion, in battles, and on the very first screen. */
const MFX={last:'',veil:null,n:0};
const mfxNoMo=()=>{try{if(typeof ccReduce==='function'&&ccReduce())return true}catch(e){}try{return matchMedia('(prefers-reduced-motion: reduce)').matches}catch(e){return false}};
function mfxSKey(html,cls){const m=/class="([^"]+)"/.exec(html||'');return (cls||'')+'|'+(m?m[1].split(' ').slice(0,2).join(' '):'')}
function mfxSVeil(){let v=MFX.veil;if(!v||!v.isConnected){v=MFX.veil=document.createElement('div');v.className='mfxveil';v.setAttribute('aria-hidden','true');wrap.appendChild(v)}
 try{v.animate([{opacity:.5},{opacity:0}],{duration:360,easing:'cubic-bezier(.3,.7,.3,1)'})}catch(e){}}
function mfxSEnter(){const main=ov.querySelector(':scope > main.mn'),els=main?[main]:[...ov.children];
 for(const el of els){try{el.animate([{opacity:0,transform:'translateY(12px) scale(.992)'},{opacity:1,transform:'none'}],{duration:340,easing:'cubic-bezier(.2,.9,.25,1.04)'})}catch(e){}}mfxSVeil()}
{const s0=show;show=function(html,cls){const key=mfxSKey(html,cls),first=!MFX.n++;const r=s0.apply(this,arguments);
  try{if(!first&&S.mode==='title'&&key!==MFX.last&&!mfxNoMo())mfxSEnter()}catch(e){}MFX.last=key;return r}}
{const st=document.createElement('style');st.textContent=`.mfxveil{position:absolute;inset:0;z-index:40;pointer-events:none;background:radial-gradient(120% 90% at 50% 40%,#1e1650,#08051a);opacity:0}`;document.head.appendChild(st)}
