# python3 t_poll99.py [game.html] : the Tower Vote (96zz): first-open window, the VOTE button by the bell, one vote per player (kept
# across reloads), percentages only, the 24-hour close, the signed vote event, and the count (one vote per key, late and forged
# votes ignored). The relays are stubbed: this checks the game's side, not the public relays.
import asyncio,os,sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:500]),flush=True)
    if not ok:FAIL.append(name)
STUB="()=>{window.__sent=[];rkRelaySend=async(u,ev)=>{__sent.push(ev);return true};rkRelayQueryAll=async()=>({ok:true,evs:window.__evs||[]});RS_ASK=false;try{ST.perfAsked=1}catch(e){}try{PFW.asked=true}catch(e){}}"
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();ctx=await b.new_context(viewport={'width':1600,'height':900});await ctx.add_init_script('window.TPOLL_FORCE=1');pg=await ctx.new_page();er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await pg.wait_for_timeout(1200);await E(STUB)
        r=await E("()=>[!!document.getElementById('tpoll'),tpSt().seen,document.querySelectorAll('#tpoll .tpv').length,[...document.querySelectorAll('#tpoll .tpc h3')].map(e=>e.textContent)]")
        chk('the first time the game opens, the Tower Vote appears (Bone Crypt vs Starfall Observatory)',r[0] and r[1]==1 and r[2]==2 and r[3]==['Bone Crypt','Starfall Observatory'],r)
        r=await E("()=>{const b=document.getElementById('tpbtn'),bell=document.getElementById('bell');if(!b)return null;const q=b.getBoundingClientRect(),w=bell.getBoundingClientRect();return [b.nextElementSibling===bell,Math.round(w.left-q.right),Math.round(q.width),b.classList.contains('new'),Math.abs((q.top+q.height/2)-(w.top+w.height/2))<6]}")
        chk('a small VOTE button sits right next to the bell (with a dot until you vote)',r and r[0] and 0<=r[1]<12 and r[2]<=48 and r[3] and r[4],r)
        await E("()=>{document.getElementById('tpx').click()}");await pg.reload();await pg.wait_for_timeout(1500);await E(STUB);await E("()=>title()");await pg.wait_for_timeout(1600)
        r=await E("()=>[!!document.getElementById('tpoll'),!!document.getElementById('tpbtn')]")
        chk('after that it does not pop up again by itself; the VOTE button stays',r==[False,True],r)
        await E("()=>{window.__evs=[];tpFetch=async()=>({ok:1,n:50,cnt:{crypt:31,star:19},pct:{crypt:62,star:38}});document.getElementById('tpbtn').click()}");await pg.wait_for_timeout(400)
        g0=await E("()=>P.gold")
        await E("()=>document.querySelector('#tpoll .tpv[data-v=star]').click()");await pg.wait_for_timeout(1200)
        r=await E("()=>{const d=document.getElementById('tpoll'),t=document.getElementById('tpthx');return [tpSt().vote,d.classList.contains('done'),getComputedStyle(t).display,t.textContent,getComputedStyle(d.querySelector('.tpv')).display,d.querySelector('.tpc.mine').dataset.o,__sent.length,document.getElementById('tpbtn').classList.contains('new'),P.gold,/\\d+%/.test([...d.querySelectorAll('.tpfoot,#tpsub,#tpthx,#tpnote')].map(e=>e.textContent).join(' '))]}")
        chk('voting saves the choice, shows "Thanks for voting!" and pays 1,000 coins, with no percentages shown',r[0]=='star' and r[1] and r[2]=='flex' and 'Thanks for voting!' in r[3] and '+1,000 coins' in r[3] and r[4]=='none' and r[5]=='star' and r[6]>=1 and not r[7] and r[8]-g0==1000 and not r[9],[r,g0])
        await pg.screenshot(path=os.path.join(HERE,'shots','poll_voted.png'))
        r=await E(f"()=>[tpVote('crypt'),tpSt().vote,P.gold-{g0}]")
        chk('a player can only vote once (a second vote is refused and pays nothing more)',r==[False,'star',1000],r)
        await pg.reload();await pg.wait_for_timeout(1500);await E(STUB)
        r=await E("()=>[tpSt().vote,tpVote('crypt'),tpSt().sent>0,tpSt().paid]")
        chk('the vote (and the coins) are kept after a reload, and it still cannot be changed',r[0]=='star' and r[1]==False and r[2] and r[3]==1,r)
        r=await E("""async()=>{const ev=__sent[0]||null;window.__sent=[];const s=tpSt();s.sent=0;save();await tpSend();const e=__sent[0];return e?[e.kind,e.tags.some(t=>t[0]==='d'&&t[1]===TPOLL.tag),JSON.parse(e.content).c,await rkEvOk(e)]:null}""")
        chk('the vote goes out as a signed event (kind 30078, the poll tag, the choice), and the signature checks out',r==[30078,True,'star',True],r)
        await pg.reload();await pg.wait_for_timeout(1500);await E(STUB)
        r=await E("""async()=>{const mk=async(c,at,K)=>rkEvSign(K,30078,[['d',TPOLL.tag],['t',TPOLL.tag]],JSON.stringify({v:1,p:TPOLL.id,c}),at);
          const key=()=>{let d=0n;while(d===0n||d>=WCEC.n)d=wcB2n(crypto.getRandomValues(new Uint8Array(32)));return{d,pk:wcHx(wcN2b(wcMul(d)[0]))}};const now=Math.floor(Date.now()/1000),endS=Math.floor(TPOLL.end/1000);const evs=[];
          for(let i=0;i<3;i++)evs.push(await mk('crypt',now-100,key()));const k2=key();evs.push(await mk('crypt',now-200,k2));evs.push(await mk('star',now-50,k2));
          evs.push(await mk('star',endS+3600,key()));const f=await mk('star',now-10,key());f.content=JSON.stringify({v:1,p:TPOLL.id,c:'crypt'});evs.push(f);evs.push(evs[0]);
          window.__evs=evs;const s=tpSt();s.vote='';save();const R=await tpFetch();return [R.ok,R.cnt.crypt,R.cnt.star,R.pct.crypt,R.pct.star]}""")
        chk('counting: one vote per player (their latest), late votes and tampered votes ignored; 3 Crypt + 1 Starfall = 75% / 25%',r==[1,3,1,75,25],r)
        r=await E("()=>[tpPct({crypt:1,star:2}),tpPct({crypt:0,star:0})]")
        chk('percentages always add up to 100',r[0]['crypt']+r[0]['star']==100 and r[1]=={'crypt':0,'star':0},r)
        r=await E("()=>[Math.round((TPOLL.end-Date.UTC(2026,9,28,20,30))/3600000)]")
        chk('the poll closes 24 hours after it went live (Thursday 29 October 2026, 20:30 UTC)',r==[24],r)
        r=await E("""async()=>{const D0=Date.now;Date.now=()=>TPOLL.end+60000;delete P.poll;save();title();await new Promise(r=>setTimeout(r,1500));const a=!!document.getElementById('tpoll');const v=tpVote('crypt');
          tpFetch=async()=>({ok:1,n:9,cnt:{crypt:6,star:3},pct:{crypt:67,star:33}});tpShow();await new Promise(r=>setTimeout(r,500));const d=document.getElementById('tpoll');const out=[a,v,d.classList.contains('done'),document.getElementById('tpsub').textContent,/\\d+%/.test([...d.querySelectorAll('.tpfoot,#tpsub,#tpthx,#tpnote')].map(e=>e.textContent).join(' '))];tpClose();Date.now=D0;return out}""")
        chk('after 24 hours: no pop-up, no voting, the window says voting has closed (players never see percentages)',r[0]==False and r[1]==False and r[2] and 'Voting has closed' in r[3] and not r[4],r)
        chk('no page errors',not er,er)
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
