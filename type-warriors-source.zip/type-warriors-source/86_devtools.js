/* ---------- Developer tools: password-protected diagnostics for finding bugs ----------
   A small "Developer tools" switch in Settings (Data tab) asks for a password. Once unlocked (until the page is reloaded)
   a DEV tab appears on the left edge that opens a panel with an error log, performance and state readouts, automated
   diagnostics, test cheats and save checks. Errors are recorded from page load, even before the tool is unlocked. */
const DEV={on:false,open:false,tab:'Errors',errs:[],seen:new Map(),fails:0,lockUntil:0,god:0,ts:1,fpsHist:[],long:0,nan:[],lastTest:null,tick:0,frames:0,t0:performance.now(),lastFrame:performance.now()};
const DEV_SALT='tw-devtools-7.3',DEV_HASH='dded950ddcb1b97774bc65ec01148e70257a16d62179db9b8f5255b353763e1e';
const devHash=p=>{let h=SHA(DEV_SALT+':'+p);for(let i=0;i<3000;i++)h=SHA(h+DEV_SALT);return h};
/* ---- error capture (always on) ---- */
function devLog(kind,msg,src){try{msg=String(msg).slice(0,600);const key=kind+'|'+msg;const o=DEV.seen.get(key);if(o){o.n++;o.t=Date.now();return}const e={kind,msg,src:src||'',n:1,t:Date.now(),mode:S&&S.mode,view:S&&S.view};DEV.seen.set(key,e);DEV.errs.push(e);if(DEV.errs.length>200){const d=DEV.errs.shift();DEV.seen.delete(d.kind+'|'+d.msg)}}catch(x){}}
addEventListener('error',e=>devLog('error',(e.message||'error')+(e.lineno?' (line '+e.lineno+')':''),e.filename));
addEventListener('unhandledrejection',e=>devLog('promise',e.reason&&e.reason.stack||e.reason));
for(const k of['error','warn']){const o=console[k];console[k]=function(){try{devLog(k,[...arguments].map(a=>a&&a.stack||(typeof a==='object'?JSON.stringify(a):a)).join(' '))}catch(x){}return o.apply(this,arguments)}}
/* ---- settings switch ---- */
SETG.Data.push('Developer tools');
{const st0=settingsTabs;settingsTabs=function(){const box=ov.querySelector('.opts');if(box&&!box.querySelector('#devsw')){const d=document.createElement('div');d.className='opt';d.innerHTML=`<div><label>Developer tools</label><small>Password-protected diagnostics for finding bugs. Locks again when the page reloads.</small></div><div class="seg"><button class="sm${DEV.on?'':' on'}" id="devoff">Off</button><button class="sm${DEV.on?' on':''}" id="devsw">On</button></div>`;box.appendChild(d);
   $('devsw').onclick=()=>{if(DEV.on)return;devAsk()};$('devoff').onclick=()=>{if(!DEV.on)return;DEV.on=false;DEV.open=false;devRender();devPanelEl();settings(S.back)}}
  st0()}}
function devAsk(){const old=document.getElementById('devask');if(old)old.remove();const w=document.createElement('div');w.id='devask';
 w.innerHTML=`<div class="dvbox"><b>Developer tools</b><small>Enter the password to unlock.</small><input id="devpw" type="password" autocomplete="off" spellcheck="false"><div class="dvmsg" id="devmsg"></div><div class="dvrow"><button id="devgo">Unlock</button><button id="devcx">Cancel</button></div></div>`;document.body.appendChild(w);
 for(const ev of['keydown','keyup','keypress'])w.addEventListener(ev,e=>e.stopPropagation());
 const pw=$('devpw'),msg=$('devmsg');pw.focus();
 const go=()=>{const now=Date.now();if(now<DEV.lockUntil){msg.textContent='Too many attempts. Wait '+Math.ceil((DEV.lockUntil-now)/1000)+'s.';return}
  if(devHash(pw.value)===DEV_HASH){DEV.on=true;DEV.fails=0;w.remove();devRender();if(S.mode==='title'&&ov.querySelector('.opts'))settings(S.back)}
  else{DEV.fails++;pw.value='';msg.textContent='Incorrect password.';if(DEV.fails>=5){DEV.lockUntil=now+30000;DEV.fails=0;msg.textContent='Too many attempts. Locked for 30s.'}}};
 $('devgo').onclick=go;pw.onkeydown=e=>{e.stopPropagation();if(e.key==='Enter')go();if(e.key==='Escape')w.remove()};$('devcx').onclick=()=>w.remove()}
/* ---- panel ---- */
let devEl=null,devBody=null;
function devPanelEl(){if(!DEV.on){if(devEl){devEl.remove();devEl=null}return null}
 if(devEl)return devEl;devEl=document.createElement('div');devEl.id='devroot';
 devEl.innerHTML=`<button id="devtab" title="Developer tools">DEV</button><div id="devpanel" hidden><div class="dvhd"><b>Developer tools</b><span id="devbadge" title="Drag this bar to move. F2 opens and closes.">F2 · drag to move</span><button id="devx" aria-label="Close">×</button></div><div class="dvtabs"></div><div class="dvbody"></div></div>`;
 document.body.appendChild(devEl);for(const ev of['keydown','keyup','keypress'])devEl.addEventListener(ev,e=>e.stopPropagation());
 devDrag(devEl.querySelector('#devtab'),devEl.querySelector('#devtab'),'tab',()=>{DEV.open=!DEV.open;devRender()});devDrag(devEl.querySelector('.dvhd'),devEl.querySelector('#devpanel'),'panel');devPlace(devEl.querySelector('#devtab'),'tab');devPlace(devEl.querySelector('#devpanel'),'panel');devEl.querySelector('#devx').onclick=()=>{DEV.open=false;devRender()};
 const tabs=['Errors','Perf','State','Tests','Cheats','Save'];devEl.querySelector('.dvtabs').innerHTML=tabs.map(t=>`<button data-t="${t}">${t}</button>`).join('');
 devEl.querySelectorAll('.dvtabs button').forEach(b=>b.onclick=()=>{DEV.tab=b.dataset.t;devRender()});devBody=devEl.querySelector('.dvbody');return devEl}
const dvEsc=s=>String(s).replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
const dvBtn=(id,l,cls)=>`<button class="dvb ${cls||''}" data-a="${id}">${l}</button>`;
/* ---- moving and shortcut: drag the header (or the DEV tab) anywhere; F2 opens and closes the panel ---- */
const DEVPOS_KEY='tw-dev-pos';let devPos={};try{devPos=JSON.parse(localStorage.getItem(DEVPOS_KEY)||'{}')||{}}catch(e){}
function devSavePos(){try{localStorage.setItem(DEVPOS_KEY,JSON.stringify(devPos))}catch(e){}}
function devPlace(el,key){const p=devPos[key];if(!p)return;const r=el.getBoundingClientRect();const x=Math.max(0,Math.min(innerWidth-Math.min(r.width,60),p.x)),y=Math.max(0,Math.min(innerHeight-30,p.y));el.style.left=x+'px';el.style.top=y+'px';el.style.right='auto'}
function devDrag(handle,el,key,onClick){let sx,sy,ox,oy,moved=0,id=null;
 handle.style.touchAction='none';handle.style.cursor='grab';
 handle.addEventListener('pointerdown',e=>{if(e.button!==0||e.target.closest('button:not(#devtab)'))return;const r=el.getBoundingClientRect();sx=e.clientX;sy=e.clientY;ox=r.left;oy=r.top;moved=0;id=e.pointerId;try{handle.setPointerCapture(id)}catch(x){}});
 handle.addEventListener('pointermove',e=>{if(id!==e.pointerId)return;const dx=e.clientX-sx,dy=e.clientY-sy;if(!moved&&Math.hypot(dx,dy)<4)return;moved=1;handle.style.cursor='grabbing';
  const r=el.getBoundingClientRect(),x=Math.max(0,Math.min(innerWidth-Math.min(r.width,60),ox+dx)),y=Math.max(0,Math.min(innerHeight-30,oy+dy));el.style.left=x+'px';el.style.top=y+'px';el.style.right='auto';devPos[key]={x,y}});
 const end=e=>{if(id!==e.pointerId)return;id=null;handle.style.cursor='grab';try{handle.releasePointerCapture(e.pointerId)}catch(x){}if(moved)devSavePos();else if(onClick)onClick();moved=0};
 handle.addEventListener('pointerup',end);handle.addEventListener('pointercancel',end)}
addEventListener('keydown',e=>{if(e.key==='F2'&&DEV.on){e.preventDefault();e.stopImmediatePropagation();if(!e.repeat){DEV.open=!DEV.open;devRender()}}},true);
addEventListener('resize',()=>{if(devEl){devPlace(devEl.querySelector('#devtab'),'tab');devPlace(devEl.querySelector('#devpanel'),'panel')}});
function devRender(){const el=devPanelEl();if(!el)return;const p=el.querySelector('#devpanel');p.hidden=!DEV.open;el.querySelector('#devtab').classList.toggle('hot',DEV.errs.length>0);
 el.querySelector('#devtab').textContent=DEV.errs.length?'DEV '+DEV.errs.length:'DEV';if(!DEV.open)return;
 el.querySelectorAll('.dvtabs button').forEach(b=>b.classList.toggle('on',b.dataset.t===DEV.tab));
 const T=DEV.tab,B=devBody;
 if(T==='Errors'){B.innerHTML=`<div class="dvrow">${dvBtn('clr','Clear')}${dvBtn('copyrep','Copy full report')}${dvBtn('throw','Test error')}</div>`+(DEV.errs.length?DEV.errs.slice().reverse().map(e=>`<div class="dvit ${e.kind}"><b>${e.kind}${e.n>1?' ×'+e.n:''}</b> <small>${new Date(e.t).toLocaleTimeString()} · ${e.mode||''}${e.view?'/'+e.view:''}</small><pre>${dvEsc(e.msg)}</pre></div>`).join(''):'<p class="dvok">No errors recorded this session.</p>')}
 else if(T==='Perf'){B.innerHTML='<div id="dvperf"></div>'}
 else if(T==='State'){B.innerHTML='<div id="dvstate"></div>'}
 else if(T==='Tests'){B.innerHTML=`<p class="dvnote">Automated checks run on a copy of your state. Nothing is saved while they run.</p><div class="dvrow">${dvBtn('t-art','Art and data')}${dvBtn('t-menu','Open every menu')}${dvBtn('t-lvl','Play-test levels')}${dvBtn('t-save','Save check')}${dvBtn('t-audio','Audio check')}${dvBtn('t-all','Run all','gd')}</div><div id="dvres">${DEV.lastTest?devResHTML(DEV.lastTest):''}</div>`}
 else if(T==='Cheats'){B.innerHTML=`<p class="dvnote">For testing. These change your real save, so use a backup.</p><div class="dvrow">${dvBtn('gold','+100k gold')}${dvBtn('corn','+1,000 candy corn')}${dvBtn('crates','+5 crates')}${typeof cxChest==='function'?dvBtn('cxc','+5 Celestial Chests'):''}${dvBtn('unlock','Own all gear')}${dvBtn('simwin','Win level (3 stars)')}</div><div class="dvrow"><span>Gold: <b id="dvgb">${nf0(P.gold)}</b></span><input id="dvgold" type="number" min="0" step="1000" value="${DEV.gamt||10000}" style="width:110px">${dvBtn('gadd','Add')}${dvBtn('grem','Remove')}${dvBtn('gset','Set to')}${dvBtn('g0','Zero')}</div><div class="dvrow"><span>Quick</span>${dvBtn('gq1000','+1k')}${dvBtn('gq10000','+10k')}${dvBtn('gq-1000','-1k')}${dvBtn('gq-10000','-10k')}</div><div class="dvrow">${dvBtn('god',DEV.god?'God mode: ON':'God mode: off',DEV.god?'on':'')}${dvBtn('killall','Kill all enemies')}${dvBtn('combo','Combo 50')}${dvBtn('hp','Full health')}</div><div class="dvrow"><span>Game speed</span>${[.25,.5,1,2,4].map(v=>dvBtn('ts'+v,v+'×',DEV.ts===v?'on':'')).join('')}</div><div class="dvrow"><span>Start level</span><input id="dvlv" type="number" min="1" max="40" value="1" style="width:60px">${dvBtn('lvgo','Go')}</div>`}
 else if(T==='Save'){B.innerHTML=`<div class="dvrow">${dvBtn('export','Copy save JSON')}${dvBtn('validate','Validate save')}${dvBtn('ttreset','Reset Hollow Street run')}</div><div id="dvres">${DEV.lastSave?devResHTML(DEV.lastSave):''}</div><p class="dvnote">Save size: ${(JSON.stringify(P).length/1024).toFixed(1)} KB</p>`}
 B.querySelectorAll('[data-a]').forEach(b=>b.onclick=()=>devAct(b.dataset.a))}
function devResHTML(r){return `<div class="dvsum ${r.fail?'bad':'good'}">${r.pass} passed · ${r.fail} problem${r.fail===1?'':'s'}</div>`+r.items.map(i=>`<div class="dvit ${i.ok?'ok':'err'}"><b>${i.ok?'✓':'✗'} ${dvEsc(i.name)}</b>${i.note?'<pre>'+dvEsc(i.note)+'</pre>':''}</div>`).join('')}
function devCopy(txt){try{navigator.clipboard.writeText(txt).catch(()=>devCopyFb(txt))}catch(e){devCopyFb(txt)}}
function devCopyFb(txt){const t=document.createElement('textarea');t.value=txt;t.style.cssText='position:fixed;left:-999px';document.body.appendChild(t);t.select();try{document.execCommand('copy')}catch(e){}t.remove()}
function devReport(){const L=[];L.push('Type Warriors diagnostics '+new Date().toISOString());L.push('UA: '+navigator.userAgent);L.push('Viewport: '+innerWidth+'x'+innerHeight+' dpr '+devicePixelRatio);L.push('Mode: '+S.mode+'/'+(S.view||'')+' wave '+S.wave+' camp '+S.camp);L.push('Audio: '+(ac?ac.state:'none')+' mute '+ST.mute+' gain '+(mg?mg.gain.value.toFixed(3):'-'));
 L.push('FPS avg '+devFps().toFixed(1)+' long frames '+DEV.long);L.push('--- errors ('+DEV.errs.length+') ---');for(const e of DEV.errs)L.push('['+e.kind+' x'+e.n+'] '+e.msg);if(DEV.lastTest){L.push('--- tests ---');for(const i of DEV.lastTest.items)if(!i.ok)L.push('FAIL '+i.name+(i.note?': '+i.note:''))}return L.join('\n')}
function devFps(){const h=DEV.fpsHist;return h.length?h.reduce((a,b)=>a+b,0)/h.length:0}
/* ---- gold cheat: keep every visible balance in step ---- */
const nf0=n=>Math.floor(n).toLocaleString('en-US');
function devGoldSync(){try{const g=nf0(P.gold),e=document.getElementById('dvgb');if(e)e.textContent=g;const c=document.getElementById('cbal');if(c)c.textContent=g;
 document.querySelectorAll('.gdpill b,#gdbal,.gbar b').forEach(x=>{x.textContent=g});if(typeof betRefresh==='function')betRefresh();if(S.mode==='title'&&typeof refreshGold==='function')refreshGold()}catch(x){}}
/* ---- actions ---- */
function devAct(a){
 if(a==='clr'){DEV.errs=[];DEV.seen.clear()}
 else if(a==='copyrep')devCopy(devReport());
 else if(a==='throw')setTimeout(()=>{throw new Error('Dev tools test error')},0);
 else if(a==='gold'){P.gold+=100000;save();devGoldSync()}
 else if(a==='gadd'||a==='grem'||a==='gset'||a==='g0'||a.startsWith('gq')){const el=$('dvgold'),v=Math.max(0,Math.floor(Math.abs(+(el&&el.value)||0)));if(el)DEV.gamt=v||DEV.gamt;
  if(a==='gadd')P.gold+=v;else if(a==='grem')P.gold=Math.max(0,P.gold-v);else if(a==='gset')P.gold=v;else if(a==='g0')P.gold=0;else P.gold=Math.max(0,P.gold+(+a.slice(2)));
  P.gold=Math.min(P.gold,1e12);save();devGoldSync()}
 else if(a==='corn'){ttNormalize();P.candyCorn+=1000;save()}
 else if(a==='crates'){P.hcr=(P.hcr|0)+5;save()}
 else if(a==='cxc'){P.ccr=(P.ccr|0)+5;save()}
 else if(a==='simwin'){const ok=window.devSimLevel&&window.devSimLevel();if(ok){DEV.open=false;devRender()}else ccToast('Start a campaign level first, then press Win level.')}
 else if(a==='unlock'){for(const k in AR)P.ownA[k]=1;for(const k in WP)P.own[k]=1;save()}
 else if(a==='god'){DEV.god=DEV.god?0:1}
 else if(a==='killall'){if(S.mode==='play')for(const e of[...S.en])try{kill(e,true)}catch(x){devLog('error','killall: '+x)}}
 else if(a==='combo'){if(S.mode==='play'){S.combo=50;S.maxCombo=Math.max(S.maxCombo||0,50)}}
 else if(a==='hp'){if(S.mode==='play')S.hp=S.max}
 else if(a.startsWith('ts')){DEV.ts=+a.slice(2)}
 else if(a==='lvgo'){const n=Math.max(1,Math.min(40,+($('dvlv')||{}).value||1));DEV.open=false;try{hide&&hide()}catch(e){}start(n)}
 else if(a==='export')devCopy(JSON.stringify(P));
 else if(a==='validate'){DEV.lastSave=devTestSave()}
 else if(a==='ttreset'){ttNormalize();P.treatData.active=null;TRT.run=null;save()}
 else if(a.startsWith('t-'))devRunTests(a.slice(2));
 devRender()}
/* ---- automated diagnostics ---- */
const dvItem=(r,name,ok,note)=>{r.items.push({name,ok,note});ok?r.pass++:r.fail++};
function devTestArt(r){const c=document.createElement('canvas');c.width=236;c.height=150;const g=c.getContext('2d');
 const blank=()=>{const d=g.getImageData(0,0,c.width,c.height).data;for(let i=3;i<d.length;i+=4)if(d[i]>8)return false;return true};
 const bad={w:[],a:[],m:[]};
 for(const id in WP){const w=WP[id];if(!w.n||!w.r||!RC[w.r]){bad.w.push(id+': missing name, rarity or colour');continue}for(const t of[0,1.7]){try{art(c,'w',id,t);if(blank()){bad.w.push(id+': drew nothing');break}}catch(e){bad.w.push(id+': '+e.message);break}}}
 for(const id in AR){const a=AR[id];if(!a.n||!a.r||!RC[a.r]){bad.a.push(id+': missing name, rarity or colour');continue}for(const t of[0,1.7]){try{art(c,'a',id,t);if(blank()){bad.a.push(id+': drew nothing');break}}catch(e){bad.a.push(id+': '+e.message);break}}}
 c.width=420;c.height=420;for(const id in MON){try{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,420,420);g.save();g.translate(210,360);MON[id].d(g,1.3,{});g.restore()}catch(e){bad.m.push(id+': '+e.message)}}
 dvItem(r,'Weapon art ('+Object.keys(WP).length+')',!bad.w.length,bad.w.join('\n'));dvItem(r,'Armor art ('+Object.keys(AR).length+')',!bad.a.length,bad.a.join('\n'));dvItem(r,'Monster art ('+Object.keys(MON).length+')',!bad.m.length,bad.m.join('\n'));
 /* hero with every armor and a few weapons */
 const bh=[];c.width=400;c.height=400;for(const id in AR){try{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,400,400);g.save();g.translate(200,350);drawHero(g,{arm:id,wp:'sword'in WP?'sword':Object.keys(WP)[0],col:P.col,t:1.1});g.restore()}catch(e){bh.push(id+': '+e.message)}}
 dvItem(r,'Hero drawn in every armor',!bh.length,bh.join('\n'));
 const dd=[];for(let n=1;n<=(typeof ASTRAL!=='undefined'?33:30);n++){try{const d=lvDef((n-1)*5);if(!d||typeof d!=='object')dd.push('level '+n+': no definition');zoneIdx((n-1)*5)}catch(e){dd.push('level '+n+': '+e.message)}}
 dvItem(r,'Level definitions',!dd.length,dd.join('\n'))}
function devTestMenus(r){const fns=[['title',()=>title()],['settings',()=>settings(title)],['armory',()=>armory()],['shop',()=>shop()],['profile',()=>profile()],['campaign',()=>campaign()],['bounty board',()=>bountyBoard()],['daily',()=>dailyMenu(title)],['save center',()=>saveCenter(title)],['crates',()=>crateHub()],['Monster Mash',()=>gyMenu(title)],['Trick-or-Treat',()=>ttMenu()],['Candy Stall',()=>ttShop()],['practice',()=>pracMenu(title)]];
 if(typeof astralMenu==='function')fns.push(['Astral',()=>astralMenu()]);
 for(const [n,f] of fns){const before=DEV.errs.length;let note='',ok=true;try{f();if(!ov||ov.innerHTML.length<80){ok=false;note='screen is empty'}if(document.documentElement.scrollWidth>innerWidth+4){ok=false;note+=(note?'; ':'')+'horizontal overflow ('+document.documentElement.scrollWidth+'px)'}}catch(e){ok=false;note=e.message}if(DEV.errs.length>before){ok=false;note+=(note?'; ':'')+DEV.errs[DEV.errs.length-1].msg}dvItem(r,'Menu: '+n,ok,note)}
 try{title()}catch(e){}}
function devTestLevels(r){const sv=save;save=function(){};const snap=JSON.stringify(P),bad=[];
 try{const MAXL=typeof ASTRAL!=='undefined'?33:30;for(const n of[1,5,10,15,20,25,28,30,31,32,33]){if(n>MAXL)continue;try{start(n);S.hp=S.max=999;for(let i=0;i<60;i++){update(.05);if(i%10===0){S.spawnLeft=Math.max(S.spawnLeft,1)}}drawWorld();
   const nan=[];for(const k of['hp','score','combo','wave','round'])if(typeof S[k]==='number'&&!isFinite(S[k]))nan.push(k);for(const e of S.en)if(!isFinite(e.x)||!isFinite(e.y)){nan.push('enemy '+e.id);break}if(nan.length)bad.push('level '+n+': NaN in '+nan.join(', '))}catch(e){bad.push('level '+n+': '+e.message)}}}
 finally{try{const o=JSON.parse(snap);for(const k of Object.keys(P))if(!(k in o))delete P[k];Object.assign(P,o)}catch(e){}save=sv;try{S.mode='title';S.view='';S.en=[];S.pj=[];title()}catch(e){}}
 dvItem(r,'Play-test levels (60 steps each, then draw)',!bad.length,bad.join('\n'))}
function devTestSave(){const r={pass:0,fail:0,items:[]},bad=[],isNum=v=>typeof v==='number'&&isFinite(v);
 for(const k of['gold','xp','candyCorn','hcr'])if(P[k]!==undefined&&!(isNum(P[k])&&P[k]>=0))bad.push(k+' = '+P[k]);
 dvItem(r,'Currency values are finite and not negative',!bad.length,bad.join('\n'));
 const ub=[];for(const k in P.own||{})if(!WP[k])ub.push('weapon '+k);for(const k in P.ownA||{})if(!AR[k])ub.push('armor '+k);dvItem(r,'Owned gear all exists',!ub.length,ub.join('\n'));
 dvItem(r,'Equipped gear is owned',!!(AR[P.armor]&&WP[P.weapon])&&(P.ownA[P.armor]||P.armor==='rags')&&!!P.own[P.weapon],'armor '+P.armor+' / weapon '+P.weapon);
 let ok=true,n='';try{const q=JSON.parse(JSON.stringify(P));ttNormalize(q);if(q.treatData.active)ttValidate(q.treatData.active)}catch(e){ok=false;n=e.message}dvItem(r,'Hollow Street data validates',ok,n);
 const nn=[];(function w(o,p,d){if(d>4||!o||typeof o!=='object')return;for(const k in o){const v=o[k];if(typeof v==='number'&&!isFinite(v))nn.push(p+k);else if(v&&typeof v==='object')w(v,p+k+'.',d+1)}})(P,'',0);dvItem(r,'No NaN or Infinity anywhere in the save',!nn.length,nn.slice(0,20).join('\n'));
 let size=0;try{size=JSON.stringify(P).length}catch(e){}dvItem(r,'Save size reasonable ('+(size/1024).toFixed(1)+' KB)',size<2e6,'');
 return r}
function devTestAudio(r){const n=[];if(!ac)n.push('Audio not started yet (press any key or click first)');else{if(ac.state!=='running')n.push('AudioContext is '+ac.state);const want=ST.mute?0:ST.mvol*.6;if(Math.abs(mg.gain.value-want)>.02&&!(S.cine||S.cr2))n.push('music gain '+mg.gain.value.toFixed(3)+' but expected '+want.toFixed(3));if(ST.mute&&mg.gain.value>.001)n.push('muted but music is audible')}dvItem(r,'Audio context and mute state',!n.length,n.join('\n'))}
function devRunTests(which){const r={pass:0,fail:0,items:[]};const run=(n,f)=>{try{f()}catch(e){dvItem(r,n+' crashed',false,e.stack||e.message)}};
 if(which==='art'||which==='all')run('Art',()=>devTestArt(r));
 if(which==='menu'||which==='all')run('Menus',()=>devTestMenus(r));
 if(which==='lvl'||which==='all')run('Levels',()=>devTestLevels(r));
 if(which==='save'||which==='all')run('Save',()=>{const s=devTestSave();r.items.push(...s.items);r.pass+=s.pass;r.fail+=s.fail});
 if(which==='audio'||which==='all')run('Audio',()=>devTestAudio(r));
 DEV.lastTest=r;DEV.tab='Tests';DEV.open=true;devRender()}
/* ---- live readouts + god mode + speed ---- */
{const u0=update;update=function(dt){if(DEV.on){if(DEV.ts!==1)dt*=DEV.ts;if(DEV.god&&S.mode==='play'&&S.hp<S.max)S.hp=S.max}return u0.call(this,dt)}}
function devTick(){DEV.tick++;const now=performance.now();DEV.frames++;const dt=now-DEV.lastFrame;DEV.lastFrame=now;if(dt>60)DEV.long++;
 if(now-DEV.t0>=1000){DEV.fpsHist.push(DEV.frames*1000/(now-DEV.t0));if(DEV.fpsHist.length>10)DEV.fpsHist.shift();DEV.frames=0;DEV.t0=now;
  if(DEV.on){if(S.mode==='play'){const bad=[];for(const k of['hp','score','combo'])if(typeof S[k]==='number'&&!isFinite(S[k]))bad.push(k);for(const e of S.en||[])if(!isFinite(e.x)||!isFinite(e.y)){bad.push('enemy '+(e.id||'?'));break}if(bad.length)devLog('nan','Non-finite value in game state: '+bad.join(', '))}
   if(document.documentElement.scrollWidth>innerWidth+4&&S.mode==='title')devLog('layout','Page is wider than the window ('+document.documentElement.scrollWidth+'px)');
   if(DEV.open){if(DEV.tab==='Perf'&&$('dvperf')){const m=performance.memory;$('dvperf').innerHTML=`<div class="dvgrid"><span>FPS now</span><b>${DEV.fpsHist.slice(-1)[0]?.toFixed(0)||'-'}</b><span>FPS average</span><b>${devFps().toFixed(1)}</b><span>FPS lowest</span><b>${Math.min(...DEV.fpsHist).toFixed(0)}</b><span>Frames over 60ms</span><b>${DEV.long}</b><span>JS memory</span><b>${m?(m.usedJSHeapSize/1048576).toFixed(0)+' MB':'n/a'}</b><span>Live canvases</span><b>${LIVE.length}</b><span>DOM nodes</span><b>${document.getElementsByTagName('*').length}</b><span>Resolution</span><b>${innerWidth}×${innerHeight} @${devicePixelRatio}</b></div>`}
    if(DEV.tab==='State'&&$('dvstate')){const rows=[['mode',S.mode+'/'+(S.view||'')],['level',S.camp],['wave / round',S.wave+' / '+S.round],['hp',S.hp+' / '+S.max],['shield',S.shield],['combo',S.combo],['score',Math.round(S.score||0)],['enemies',(S.en||[]).length],['projectiles',(S.pj||[]).length],['spawn left',S.spawnLeft],['audio',ac?ac.state:'off'],['music gain',mg?mg.gain.value.toFixed(3):'-'],['mute',ST.mute],['gold',P.gold],['candy corn',P.candyCorn],['armor',P.armor],['weapon',P.weapon],['Halloween',hwOn()?String(hwLeft()):'ended']];$('dvstate').innerHTML='<div class="dvgrid">'+rows.map(r=>`<span>${r[0]}</span><b>${dvEsc(r[1])}</b>`).join('')+'</div>'}
    if(DEV.tab==='Errors'&&DEV.errs.length!==DEV.shown){DEV.shown=DEV.errs.length;devRender()}}
   const tb=document.getElementById('devtab');if(tb){tb.classList.toggle('hot',DEV.errs.length>0);tb.textContent=DEV.errs.length?'DEV '+DEV.errs.length:'DEV'}}}}
{const l0=loop;loop=function(ts){try{devTick()}catch(e){}return l0(ts)}}
