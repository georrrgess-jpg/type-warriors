/* ===== 9.4 THE CROOKED CUE: screens (96j) =====
   The tavern hub, the VS intro, the pause menu, results, Slick Shade's offer, the Cue Rack and the house rules. */
/* touch mode: the stage is zoomed by the game; fit the pool screens back into 1600 x 900 (the wcFitTM pattern) */
function pzFitTM(){try{const b=document.body,on=typeof ovTM!=='undefined'&&ovTM&&ov.classList.contains('pzx');
 if(on){if(b.classList.contains('tm')){b.classList.remove('tm');b.classList.add('pztm')}}else if(b.classList.contains('pztm')){b.classList.remove('pztm');if(TM())b.classList.add('tm')}
 const x=ov.querySelector(':scope>.pzh,:scope>.pzm,:scope>.pzr,:scope>.pzk');
 if(on&&x){const w=ov.clientWidth,h=ov.clientHeight,s=Math.min(w/1600,h/900);x.style.transformOrigin='0 0';x.style.transform=`translate(${Math.round((w-1600*s)/2)}px,${Math.round((h-900*s)/2)}px) scale(${s})`}
 else if(x&&x.style.transform&&x.style.transformOrigin==='0px 0px'){x.style.transform='';x.style.transformOrigin=''}}catch(e){}}
{const s0=show;show=function(){const r=s0.apply(this,arguments);pzFitTM();return r}}
{const a0=applyLayout;applyLayout=function(){const r=a0.apply(this,arguments);pzFitTM();return r}}
/* ---------- the hub ---------- */
function pzStars(n){return '★'.repeat(n)+'<u>'+'★'.repeat(7-n)+'</u>'}
function pzHubBake(){if(PZ.hubBk)return PZ.hubBk;const c=pzCv(1600,900),g=c.getContext('2d');g.lineJoin='round';g.lineCap='round';pzBakeRoom(g);
 /* a bar counter with stools along the bottom right, and a little round table bottom left */
 g.fillStyle=pzLin(g,0,742,0,900,[[0,'#7a3e18'],[1,'#3a1a0a']]);pzRR(g,980,760,640,200,14);g.fill();g.strokeStyle=PZ_O;g.lineWidth=4;g.stroke();g.fillStyle='#a85a24';pzRR(g,970,742,660,26,8);g.fill();g.stroke();g.fillStyle='rgba(255,220,170,.22)';g.fillRect(978,746,644,3);
 for(let i=0;i<5;i++){g.strokeStyle='rgba(0,0,0,.3)';g.lineWidth=3;g.beginPath();g.moveTo(1020+i*120,780);g.lineTo(1020+i*120,900);g.stroke()}
 g.fillStyle='#6a3414';g.beginPath();g.ellipse(250,812,70,18,0,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();g.fillStyle='#4a2410';g.fillRect(244,812,12,84);g.fillStyle='#ff9ab0';g.beginPath();g.arc(250,798,9,0,TAU);g.fill();g.stroke();
 g.fillStyle='rgba(8,4,16,.42)';g.fillRect(0,0,1600,900);return PZ.hubBk=c}
function pzHub(){const Z=PZS(),tokH=++PZ.tok;PZ.on=false;PZ.hub=true;CAS.on=true;CAS.key=null;CAS.tok++;pzCastInit(PZ_ORDER[0]);try{pzMusicOn()}catch(e){}
 if(PZ.sel==null||(PZ.sel!=='shade'&&!pzOpen(PZ.sel))||(PZ.sel==='shade'&&!PZ.shadeHere))PZ.sel=PZ_ORDER.slice().reverse().find(k=>pzOpen(k)&&!(Z.beat[k]>0))||PZ_ORDER.filter(pzOpen).pop()||'gloop';
 /* Slick Shade sometimes slides into the booth once a day, after you have beaten Grizzle and carry some gold */
 if(PZ.shadeHere==null||PZ.hubOpens==null){PZ.hubOpens=1}
 if(!PZ.shadeChecked||PZ.shadeChecked!==pzDay()){PZ.shadeChecked=pzDay();PZ.shadeHere=false;if((Z.beat.grizzle||0)>0&&P.gold>=2000&&Z.shade.day!==pzDay()&&Math.random()<.12){PZ.shadeHere=true;Z.shade.day=pzDay();Z.shade.seen=(Z.shade.seen||0)+1;save()}}
 if(PZ.sel==='shade'&&!PZ.shadeHere)PZ.sel=PZ_ORDER.slice().reverse().find(k=>pzOpen(k)&&!(Z.beat[k]>0))||PZ_ORDER.filter(pzOpen).pop()||'gloop';
 const rows=PZ_ORDER.map(k=>{const R=PZ_REG[k],open=pzOpen(k),n=Z.beat[k]||0,next=open&&!n&&(k==='gloop'||(Z.beat[PZ_ORDER[PZ_ORDER.indexOf(k)-1]]||0)>0);
  return `<button class="pzrow ${PZ.sel===k?'sel':''} ${open?'':'lock'} ${next?'next':''}" data-k="${k}" ${open?'':'disabled'}><canvas width="88" height="88" data-p="${k}"></canvas><b>${open?R.n:'? ? ?'}</b><span>${open?(n?`✓ beaten ×${n}`:(next?'NEXT UP':'open')):'locked'}</span></button>`}).join('');
 const shade=PZ.shadeHere?`<button class="pzrow shade ${PZ.sel==='shade'?'sel':''}" data-k="shade"><canvas width="88" height="88" data-p="shade"></canvas><b>Slick Shade</b><span>HUSTLER · TONIGHT ONLY</span></button>`:'';
 const live=Z.live?`<div class="pzresume" id="pzresume"><b>Resume your match vs ${PZ_REG[Z.live.opp].n}?</b><span>Score ${Z.live.score[0]} - ${Z.live.score[1]}</span><button id="pzrs1">Resume</button><button id="pzrs2" class="ghost">Forfeit</button></div>`:'';
 show(`<div class="pzh" id="pzh"><canvas id="pzhbg" width="1600" height="900"></canvas><canvas id="pzhfg" width="1600" height="900"></canvas>
  <button class="pzback" id="pzbk">‹&nbsp; Casino</button><div class="pzgold"><i></i><b id="pzgold">${cmn(P.gold)}</b></div>
  <div class="pztitle">The Crooked Cue<small>a pool hall in the casino's back room</small></div>
  <div class="pzside"><button data-a="practice"><b>Practice Table</b><span>free play, any regular</span></button>${typeof pzTrick==='function'?`<button data-a="trick"><b>Trick Shots</b><span>10 puzzle shots</span></button>`:''}<button data-a="cues"><b>Cue Rack</b><span>cues, felts, ball sets</span></button><button data-a="rules"><b>House Rules</b><span>how it all works</span></button></div>
  <div class="pzboard"><div class="pzh2">Tonight's Tables</div><div class="pzrows${PZ.shadeHere?' s8':''}" id="pzrows">${shade}${rows}</div><small>Beat a regular to open the next table · ${Z.dayN}/${PZ_DAILY} paid matches today</small></div>
  <div class="pzopp" id="pzopp"></div><button class="pzrackem" id="pzrackem">Rack 'em up!</button>${live}</div>`,'casbg pzx');
 const bg=$('pzhbg').getContext('2d');bg.drawImage(pzHubBake(),0,0);
 /* animated bar regulars and the small portraits */
 const fg=$('pzhfg').getContext('2d');fg.lineJoin='round';fg.lineCap='round';const exs={gloop:Object.assign(pzCastEx(),PZ_EXP.happy),grizzle:pzCastEx(),barnacle:Object.assign(pzCastEx(),PZ_EXP.smug),moldwick:Object.assign(pzCastEx(),PZ_EXP.happy)};
 const drawFg=()=>{if(PZ.tok!==tokH)return;const t=performance.now()/1000;fg.clearRect(0,0,1600,900);
  fg.save();fg.translate(1090,830);fg.scale(.56,.56);pzMon.grizzle(fg,t,exs.grizzle,{breath:Math.sin(t*2.2)*.012,tilt:0,bob:0,hop:0});fg.restore();
  fg.save();fg.translate(1268,812);fg.scale(.56,.56);pzMon.gloop(fg,t+2,exs.gloop,{breath:0,tilt:0,bob:0,hop:0});fg.restore();
  fg.save();fg.translate(1456,832);fg.scale(.54,.54);pzMon.barnacle(fg,t+4,exs.barnacle,{breath:Math.sin(t*2.2)*.012,tilt:0,bob:0,hop:0});fg.restore();
  fg.save();fg.translate(150,836);fg.scale(.42,.42);pzMon.moldwick(fg,t+1,exs.moldwick,{breath:Math.sin(t*2)*.012,tilt:0,bob:0,hop:0});fg.restore();
  /* bar glasses and a candle on the little table (just in front of the characters) */
  for(const [mx,my] of[[1150,770],[1320,770],[1500,770]]){fg.fillStyle='#f4e0a0';fg.beginPath();fg.roundRect(mx,my-34,26,34,5);fg.fill();fg.strokeStyle=PZ_O;fg.lineWidth=2;fg.stroke();fg.fillStyle='#fff';fg.beginPath();fg.ellipse(mx+13,my-34,15,6,0,0,TAU);fg.fill();fg.stroke()}
  pzGlow(fg,250,790,40,'rgba(255,200,120,1)',.35+.1*Math.sin(t*5))};
 LIVE.push({cv:$('pzhfg'),fn:drawFg,slow:2,ph:0});drawFg();
 ov.querySelectorAll('canvas[data-p]').forEach(cv=>{const k=cv.dataset.p,g=cv.getContext('2d'),lock=cv.parentNode.classList.contains('lock');const f=()=>pzCastPortrait(g,'mon',k,88,performance.now()/1000,Object.assign(pzCastEx(),PZ_EXP.neutral));f();
  if(lock){g.globalCompositeOperation='source-in';g.fillStyle='#0c0818';g.fillRect(0,0,88,88);g.globalCompositeOperation='source-over'}else LIVE.push({cv,fn:f,slow:6,ph:0})});
 const draw=()=>pzHubOpp();pzHubOpp();
 ov.querySelectorAll('.pzrow').forEach(b=>b.onclick=()=>{if(b.disabled)return;PZ.sel=b.dataset.k;pzFx('tick');ov.querySelectorAll('.pzrow').forEach(x=>x.classList.toggle('sel',x===b));pzHubOpp()});
 ov.querySelectorAll('.pzside button').forEach(b=>b.onclick=()=>{pzFx('tick');const a=b.dataset.a;if(a==='practice')pzStart({opp:PZ.sel==='shade'?'gloop':PZ.sel,practice:true});else if(a==='cues')pzCueRack();else if(a==='rules')pzRules();else if(a==='trick'&&typeof pzTrick==='function')pzTrick()});
 $('pzbk').onclick=()=>{pzMusicOff();try{lobby()}catch(e){title()}};S.back=()=>$('pzbk').click();
 $('pzrackem').onclick=()=>{if(Z.live){$('pzrs1').click();return}const sel=PZ.sel,R=PZ_REG[sel],lo=sel==='shade'?500:Math.min(...R.stakes.filter(s=>s<=casCap('pz')));if(P.gold<lo){pzMusicOff();pzNote('Not enough gold for stakes, so this one is a free practice game.');pzStart({opp:sel==='shade'?'gloop':sel,practice:true});return}const stake=sel==='shade'?PZ.shadeStake:pzStakeOf(sel);pzMusicOff();pzStart({opp:sel,stake})};
 if(Z.live){$('pzrs1').onclick=()=>{pzStart({opp:Z.live.opp,resume:Z.live,race:Z.live.race})};$('pzrs2').onclick=function(){if(!this.dataset.sure){this.dataset.sure=1;const t=this.textContent;this.textContent=Z.live&&Z.live.stake&&!Z.live.practice?'Sure? You lose the stake':'Sure? Drop this match';setTimeout(()=>{if(this.isConnected){delete this.dataset.sure;this.textContent=t}},3200);return}const L=Z.live;Z.live=null;if(L.stake&&!L.practice){Z.losses++;Z.streak=0;ecSrc('pool',()=>cPay(L.stake,0));Z.net-=L.stake}save();$('pzresume').remove()}}
 pzFitTM()}
const PZ_TIPS={gloop:'Hits everything far too hard. Pot your balls and leave it nothing.',moldwick:'Slow and careful. Do not hand her ball in hand.',grizzle:'Breaks hard and runs out if the table opens. Keep the cue ball under control.',vesper:'Hides the cue ball behind your balls. Learn to kick off a cushion.',barnacle:'Loves banks and kicks. He will try to bank the 8 for the win.',hootsworth:'Precise and plans ahead. Never leave an easy opening.',mortimer:'Rarely misses. Win with safeties and a clean break.',shade:'Bets small, wins big. Never let him run the deciding rack.'};
function pzSkillBars(R){const a=R.ai,v=[['Aim',1+(3-a.sig)/2.1*4],['Position',1+a.pos*5],['Safety',1+a.safe*9],['Planning',a.look*.62]];
 return `<div class="pzsk">${v.map(([n,x])=>{const k=Math.max(1,Math.min(5,Math.round(x)));return `<div><span>${n}</span>${'<i class="on"></i>'.repeat(k)+'<i></i>'.repeat(5-k)}</div>`}).join('')}</div>`}
function pzStakeOf(id){PZ.stk=PZ.stk||{};const R=PZ_REG[id],cap=casCap('pz'),list=R.stakes.filter(s=>s<=cap);if(!list.length)return 0;let s=PZ.stk[id];if(!list.includes(s)||s>P.gold)s=list.find(x=>x<=P.gold)||list[0];PZ.stk[id]=s;return s}
/* a small message on whatever pool screen is up (the casino's msg() needs elements these screens do not have) */
function pzNote(text,ms){try{const host=$('pzh')||$('pzm')||$('pzr')||$('pzk')||ov;const old=$('pznote');if(old)old.remove();const el=document.createElement('div');el.id='pznote';el.className='pznote';el.textContent=text;host.appendChild(el);setTimeout(()=>{el.classList.add('out');setTimeout(()=>el.remove(),400)},ms||3200)}catch(e){}}
function pzHubOpp(){const id=PZ.sel,R=PZ_REG[id],Z=PZS(),el=$('pzopp');if(!el)return;const hustler=id==='shade',cap=casCap('pz');
 if(hustler&&!PZ.shadeStake)PZ.shadeStake=Math.min(cap,Math.max(500,Math.min(P.gold,1000)));
 const stake=hustler?PZ.shadeStake:pzStakeOf(id),mult=pzMultS(id,stake),wise=Z.rep[id]||0,paid=Z.dayN<PZ_DAILY;
 const chips=hustler?[500,1000,2000,3000,5000].filter(s=>s<=cap).map(s=>`<button class="pzchip ${s===stake?'on':''}" data-s="${s}" ${s>P.gold?'disabled':''}>${cmn(s)}</button>`).join(''):R.stakes.filter(s=>s<=cap).map(s=>`<button class="pzchip ${s===stake?'on':''}" data-s="${s}" ${s>P.gold?'disabled':''}>${cmn(s)}</button>`).join('');
 const quote=R.lines.hi[0];
 const rec=hustler?(Z.shade.beat?`Beaten ×${Z.shade.beat}`:'Never beaten'):(Z.beat[id]?`Beaten ×${Z.beat[id]}`:'Not beaten yet'),cue=hustler?PZ_CUES.find(c=>c.beatShade):PZ_CUES.find(c=>c.beat===id),cn=hustler?(Z.shade.beat||0):(Z.beat[id]||0),cueTxt=cue?(Z.cues[cue.id]?`${cue.n}: owned`:`${cue.n}: ${Math.min(cn,3)} / 3 wins`):'';
 el.innerHTML=`<div class="pzoppp"><canvas id="pzoppc" width="220" height="300"></canvas>${hustler?'':pzSkillBars(R)}</div><div class="pzoppi"><div class="pzh3" style="color:${R.c}">${R.n}</div><div class="pzstars">${R.lvl?pzStars(R.lvl):'<em>RANDOM VISITOR</em>'}</div><p class="pzq">"${quote}"</p><p>${R.k}</p><p class="pzhr"><b>House rule</b> ${R.houseTxt}</p><p class="pztip"><b>Tip</b> ${PZ_TIPS[id]||''}</p>
  <small>STAKE</small><div class="pzchips">${chips}</div>
  <div class="pzrec"><span>${rec}</span>${cueTxt?`<span>${cueTxt}</span>`:''}</div>
  <div class="pzpay">${P.gold<(hustler?500:Math.min(...R.stakes.filter(s=>s<=cap)))?`You need ${cmn(hustler?500:Math.min(...R.stakes.filter(s=>s<=cap)))} gold to play for stakes. Practice is free.`:paid?`Win pays <b>${cmn(Math.round(stake*mult))}</b> back <em>(+${cmn(Math.round(stake*mult)-stake)} profit)</em> · race to ${R.race}`:'Daily paid matches used: this one is a friendly (no stake, no unlock progress)'}</div>${wise&&paid?`<div class="pzwise">${R.n} is wise to you: ×${mult.toFixed(2).replace(/0$/,'')} today</div>`:''}</div>`;
 el.style.setProperty('--c',R.c);const cv=$('pzoppc'),g=cv.getContext('2d');g.lineJoin='round';g.lineCap='round';const ex=Object.assign(pzCastEx(),PZ_EXP.neutral),tk=PZ.tok,fit=pzMonFit(id,220,300,8,1.2);
 const f=()=>{if(!cv.isConnected)return;const t=performance.now()/1000;g.clearRect(0,0,220,300);g.save();g.translate(fit.x,fit.y);g.scale(fit.s,fit.s);pzMon[id](g,t,ex,{breath:Math.sin(t*2.2)*.012,tilt:Math.sin(t*.8)*.025,bob:Math.sin(t*1.7)*1.4,hop:0});g.restore()};f();LIVE.push({cv,fn:f,slow:2,ph:1});
 el.querySelectorAll('.pzchip').forEach(b=>b.onclick=()=>{if(b.disabled)return;const s=+b.dataset.s;if(hustler)PZ.shadeStake=s;else PZ.stk[id]=s;pzFx('tick');pzHubOpp()});
 const rb=$('pzrackem');if(rb){const lo=hustler?500:Math.min(...R.stakes.filter(s=>s<=cap)),poor=P.gold<lo;rb.textContent=Z.live?'Resume your match':poor?'Free practice game':(!paid?"Rack 'em up! (friendly)":"Rack 'em up!");rb.style.setProperty('--c',R.c)}}
/* ---------- the VS intro ---------- */
function pzIntro(R,cb){const el=$('pzintro');if(!el){cb();return}const M=PZ.M,tok=PZ.tok;let done=false;const end=()=>{if(done)return;done=true;el.classList.add('out');setTimeout(()=>{el.hidden=true;el.innerHTML=''},380);cb()};
 el.hidden=false;el.className='pzintro';el.innerHTML=`<div class="pzvs"><div class="pzvl"><canvas id="pzvh" width="320" height="400"></canvas><b>You</b><i>Challenger</i></div><div class="pzvm"><span>VS</span><em>${M.practice?'PRACTICE':'STAKE '+cmn(M.stake)+'  →  '+cmn(Math.round(M.stake*M.mult))}</em><small>Race to ${M.race}</small></div><div class="pzvr" style="--c:${R.c}"><canvas id="pzvo" width="320" height="400"></canvas><b style="color:${R.c}">${R.n}</b><i>${R.k}</i></div></div><p class="pzvh">${R.houseTxt}</p><u>click to skip</u>`;
 const vf=pzMonFit(R.id,320,400,10);const mk=(id,who)=>{const cv=$(id),g=cv.getContext('2d');g.lineJoin='round';g.lineCap='round';const f=()=>{if(!cv.isConnected)return;const t=performance.now()/1000;g.clearRect(0,0,320,400);
  if(who==='hero'){const sp=PZ_CAST.sprites.idle;if(sp)g.drawImage(sp,0,10,344,420,0,14,320,390)}else{g.save();g.translate(vf.x,vf.y);g.scale(vf.s,vf.s);pzMon[R.id](g,t,Object.assign(pzCastEx(),PZ_EXP.smug),{breath:Math.sin(t*2.2)*.012,tilt:0,bob:0,hop:0});g.restore()}};f();LIVE.push({cv,fn:f,slow:2,ph:0})};
 mk('pzvh','hero');mk('pzvo','mon');pzFx('vs');el.onclick=end;setTimeout(end,pzRM()?900:2600)}
/* ---------- modal helpers ---------- */
function pzModal(html,cls){const m=$('pzmod');if(!m)return null;m.hidden=false;m.className='pzmod '+(cls||'');m.innerHTML=`<div class="pzmp">${html}</div>`;PZ.modal=true;return m}
function pzModalClose(){const m=$('pzmod');if(m){m.hidden=true;m.innerHTML=''}PZ.modal=false;PZ.paused=false;PZ.last=performance.now()}
function pzPauseMenu(again){if(!PZ.on||(PZ.modal&&!again)||PZ.ph==='over'||PZ.ph==='intro')return;PZ.paused=true;const Z=PZS(),M=PZ.M;
 const m=pzModal(`<div class="pzh2">Paused</div><p class="pzmm">${PZ.reg.n} · race to ${M.race} · score ${M.score[0]}-${M.score[1]}</p>
  <button class="pzmb gold" data-a="resume">Resume</button><button class="pzmb" data-a="rules">House rules</button><button class="pzmb" data-a="set">Settings</button><button class="pzmb red" data-a="forfeit">Forfeit match</button>`,'pause');
 S.back=()=>{const b=document.querySelector('#pzmod [data-a=resume]');if(b)b.click();else if(PZ.modal)pzPauseMenu(true)};
 m.querySelector('[data-a=resume]').onclick=()=>{pzModalClose();S.back=()=>pzPauseMenu()};
 m.querySelector('[data-a=rules]').onclick=()=>{pzRulesModal()};
 m.querySelector('[data-a=set]').onclick=()=>{pzSettingsModal()};
 m.querySelector('[data-a=forfeit]').onclick=()=>{pzModal(`<div class="pzh2">Forfeit?</div><p class="pzmm">${M.practice?'It is only practice, so nothing is lost.':`You will lose your stake of <b>${cmn(M.stake)}</b>.`}</p><button class="pzmb red" data-a="yes">Forfeit</button><button class="pzmb gold" data-a="no">Keep playing</button>`,'pause');
  const mm=$('pzmod');mm.querySelector('[data-a=yes]').onclick=()=>{pzModalClose();pzForfeit()};mm.querySelector('[data-a=no]').onclick=()=>pzPauseMenu(true)}}
function pzSettingsModal(){const Z=PZS(),m=pzModal(`<div class="pzh2">Settings</div>
 <div class="pzset"><span>Aim guide</span><div class="pzseg" data-k="guide">${['full','short','pro'].map(v=>`<button class="${Z.guide===v?'on':''}" data-v="${v}">${v[0].toUpperCase()+v.slice(1)}</button>`).join('')}</div></div>
 <div class="pzset"><span>Typing taunts</span><div class="pzseg" data-k="tauntsOn">${[[true,'On'],[false,'Off']].map(([v,l])=>`<button class="${Z.tauntsOn===v?'on':''}" data-v="${v}">${l}</button>`).join('')}</div></div>
 <p class="pzmm small">Full shows the whole guide. Short shows the ghost ball and a little of the line. Pro shows only the aim line to the first ball.</p><button class="pzmb gold" data-a="back">Back</button>`,'pause');
 m.querySelectorAll('.pzseg').forEach(sg=>sg.querySelectorAll('button').forEach(b=>b.onclick=()=>{const k=sg.dataset.k,v=b.dataset.v==='true'?true:b.dataset.v==='false'?false:b.dataset.v;Z[k]=v;save();pzGuideNote();sg.querySelectorAll('button').forEach(x=>x.classList.toggle('on',x===b));pzFx('tick');pzHudAll()}));
 m.querySelector('[data-a=back]').onclick=()=>pzPauseMenu(true)}
function pzRulesBody(){return `<div class="pzrules"><div><b>Aim</b><p>Move the mouse to aim. Pull back from the table (or use the Power bar) and release to shoot. Arrow keys fine-tune the angle.</p></div><div><b>Spin</b><p>Click the cue ball diagram: top = follow, bottom = draw (backspin), left/right = english. Double-click to reset.</p></div>
 <div><b>Groups</b><p>The first ball you pot after the break picks your group: solids (1-7) or stripes (9-15). Keep shooting while you pot your balls.</p></div><div><b>Fouls</b><p>Scratch, no ball hit, wrong ball first, or no cushion after contact. The other player gets ball in hand anywhere.</p></div>
 <div><b>The 8</b><p>Clear your group, then call a pocket for the 8 (click a pocket or press 1-6). Pot it there to win the rack. Pot it early, elsewhere or with a foul and you lose it.</p></div><div><b>Taunts</b><p>After a monster misses you may get a taunt: type it in time and its next shot wobbles. Esc skips it.</p></div>
 <div><b>The guide</b><p>Full simulates your shot: the gold line is where the object ball really goes, blue is the cue ball, a green ring is a pocket that will take a ball and a red cross is a scratch. Short shows less; Pro shows only the aim line (and pays off against Mortimer).</p></div>
 <div><b>Controls</b><p>Mouse aims. Hold Shift or the right button for fine aim; the wheel and the arrow keys nudge (Shift for tiny steps). W A S D set the spin, R resets it, G changes the guide, 1-6 call a pocket, Space or SHOOT fires.</p></div>
 <div><b>Pace and clock</b><p>Hold Space or click while the balls roll or the monster thinks to fast-forward; click skips the rack pauses. Paid matches run a shot clock.</p></div></div>`}
function pzRulesModal(){const m=pzModal(`<div class="pzh2">House Rules</div>${pzRulesBody()}<button class="pzmb gold" data-a="back">Back</button>`,'pause wide');m.querySelector('[data-a=back]').onclick=()=>pzPauseMenu(true)}
function pzRules(){const tk=PZ.tok;show(`<div class="pzr" id="pzr"><canvas id="pzrbg" width="1600" height="900"></canvas><button class="pzback" id="pzbk">‹&nbsp; The bar</button><div class="pzrp"><div class="pzh2">House Rules</div>${pzRulesBody()}</div></div>`,'casbg pzx');
 $('pzrbg').getContext('2d').drawImage(pzHubBake(),0,0);$('pzbk').onclick=()=>pzHub();S.back=()=>pzHub();pzFitTM()}
/* ---------- Slick Shade's offer ---------- */
function pzShadeOffer(){PZ.paused=true;const R=PZ.reg,m=pzModal(`<div class="pzh2" style="color:#ffe066">Slick Shade</div><p class="pzmm">"${R.lines.offer[0]}"</p><p class="pzmm small">Race to 3 instead of 2. Same stake, but the pay goes up to ×2.8, and I stop pretending.</p><button class="pzmb gold" data-a="yes">Let it ride</button><button class="pzmb" data-a="no">No thanks</button>`,'pause shade');
 pzCastReact('mon','smug',2000);m.querySelector('[data-a=yes]').onclick=()=>{pzModalClose();pzExtend(true)};m.querySelector('[data-a=no]').onclick=()=>{pzModalClose();pzExtend(false)}}
/* ---------- results ---------- */
function pzResults(res){PZ.on=false;PZ.resAt=performance.now();const R=PZ_REG[res.opp],win=res.win,Z=PZS();
 const unl=res.unlocks.map(u=>`<div class="pzun"><small>NEW ${u.t==='cue'?'CUE':u.t==='felt'?'FELT':'BALL SET'}</small><b>${u.n}</b></div>`).join('');
 const prog=!res.practice&&win&&res.opp!=='shade'?(()=>{const c=PZ_CUES.find(x=>x.beat===res.opp);const n=res.beatN;return c&&n<3?`<div class="pzun prog"><small>${c.n}</small><b>${n} / 3 wins</b></div>`:''})():'';
 show(`<div class="pzr" id="pzr"><canvas id="pzrbg" width="1600" height="900"></canvas><div class="pzresc ${win?'win':'lose'}"><canvas id="pzrpm" width="400" height="500"></canvas>
  <div class="pzrpn"><div class="pzh1">${[...(res.forfeit?'You forfeited':win?'You win!':'You lose')].map((c,i)=>`<i style="--i:${i}">${c===' '?'&nbsp;':c}</i>`).join('')}</div><p>${res.practice?'Practice table':`Race to ${res.race}`} · ${res.score[0]} - ${res.score[1]} · ${R.n}</p>
  ${res.practice?`<p class="pzpay0">No stake on the table.</p>`:win?`<div class="pzpay1"><span>Stake ${cmn(res.stake)} × ${res.mult.toFixed(2).replace(/0$/,'')} · you get back</span><b id="pzpayn">0</b><em>Profit +${cmn(res.pay-res.stake)}${res.bonus?` · includes bonus +${cmn(res.bonus)} ${res.bnr?'(break & run)':''}${res.golden?' (golden break)':''}`:''}</em></div>`:`<div class="pzpay1 neg"><span>Stake lost</span><b>−${cmn(res.stake)}</b></div>`}
  <div class="pzstat"><div><b>${Math.floor(res.time/60)}:${String(res.time%60).padStart(2,'0')}</b><small>TIME</small></div><div><b>${res.pots}</b><small>BALLS POTTED</small></div><div><b>${res.banks}</b><small>BANK SHOTS</small></div><div><b>${res.bnr}</b><small>BREAK &amp; RUNS</small></div></div>
  <div class="pzuns">${res.opened?`<div class="pzun open"><small>NEW TABLE</small><b>${PZ_REG[res.opened].n} is open</b></div>`:''}${unl}${prog}</div><div class="pzrbt">${res.opened?`<button class="pzmb gold" id="pzch">Challenge ${PZ_REG[res.opened].n.split(' ')[0]}</button><button class="pzmb" id="pzre">Rematch</button>`:`<button class="pzmb gold" id="pzre">Rematch</button>`}<button class="pzmb" id="pzbb">Back to the bar</button></div></div></div></div>`,'casbg pzx');
 $('pzrbg').getContext('2d').drawImage(pzHubBake(),0,0);S.back=()=>pzHub();
 const cv=$('pzrpm'),g=cv.getContext('2d');g.lineJoin='round';g.lineCap='round';const ex=Object.assign(pzCastEx(),PZ_EXP[win?'sad':'cheer']),rf=pzMonFit(R.id,400,500,30,1.2);
 const f=()=>{if(!cv.isConnected)return;const t=performance.now()/1000;g.clearRect(0,0,400,500);g.save();g.translate(rf.x,rf.y+(win?10:0));g.scale(rf.s,rf.s);g.translate(0,win?0:-Math.abs(Math.sin(t*5))*16/rf.s);pzMon[R.id](g,t,ex,{breath:Math.sin(t*2.2)*.012,tilt:win?.06:Math.sin(t*3)*.03,bob:0,hop:0});g.restore()};f();LIVE.push({cv,fn:f,slow:1,ph:0});
 $('pzbb').onclick=()=>{if(res.opened)PZ.sel=res.opened;pzHub()};{const ch=$('pzch');if(ch)ch.onclick=()=>{PZ.sel=res.opened;pzMusicOff();pzHub();$('pzrackem').click()}}
 $('pzre').onclick=()=>{const k=res.opp;let stake=res.stake,prac=res.practice;if(!prac){const aff=PZ_REG[k].stakes.filter(s=>s<=casCap('pz')&&s<=P.gold);if(stake>P.gold||!stake){stake=aff.length?aff[aff.length-1]:0}if(!stake){prac=true;pzNote('Not enough gold for stakes: a free practice game.')}}pzMusicOff();pzStart({opp:k,stake,practice:prac})};
 if(!res.practice&&win&&res.pay){let n=0;const tgt=res.pay,t0=performance.now(),el=$('pzpayn'),stp=()=>{if(!el.isConnected)return;const u=Math.min(1,(performance.now()-t0)/1400),e=1-Math.pow(1-u,3);el.textContent=cmn(Math.round(tgt*e));if(u<1)requestAnimationFrame(stp)};requestAnimationFrame(stp);pzResCoins()}
 pzFx(win?'win':'lose');pzFitTM()}
function pzResCoins(){const host=ov.querySelector('.pzresc');if(!host||pzRM())return;for(let i=0;i<54;i++){const c=document.createElement('i');c.className='pzcoinfx';c.style.setProperty('--x',(Math.random()*760-380)+'px');c.style.setProperty('--y',(-(240+Math.random()*250))+'px');c.style.setProperty('--d',(Math.random()*.7)+'s');host.appendChild(c);setTimeout(()=>c.remove(),2200)}}
/* ---------- the cue rack ---------- */
function pzCueRack(){const Z=PZS(),tab=PZ.rackTab||'cues';PZ.rackTab=tab;const tokR=PZ.tok;
 const items=tab==='cues'?PZ_CUES:tab==='felts'?PZ_FELT:PZ_BALLS,own=tab==='cues'?Z.cues:tab==='felts'?Z.felts:Z.ballsets,eq=tab==='cues'?Z.cue:tab==='felts'?Z.felt:Z.balls;
 PZ.rackSel=PZ.rackSel&&items.find(x=>x.id===PZ.rackSel)?PZ.rackSel:eq;const sel=items.find(x=>x.id===PZ.rackSel)||items[0],have=!!own[sel.id];
 show(`<div class="pzk" id="pzk"><canvas id="pzkbg" width="1600" height="900"></canvas><button class="pzback" id="pzbk">‹&nbsp; The bar</button><div class="pzgold"><i></i><b>${cmn(P.gold)}</b></div>
  <div class="pztitle sm">The Cue Rack</div><div class="pzktabs">${[['cues','Cues'],['felts','Felts'],['balls','Ball sets']].map(([k,l])=>`<button class="${tab===k?'on':''}" data-t="${k}">${l}</button>`).join('')}</div>
  <div class="pzkgrid">${items.map(x=>`<button class="pzki ${x.id===sel.id?'sel':''} ${own[x.id]?'':'lock'} ${eq===x.id?'eq':''}" data-i="${x.id}"><b>${x.n}${eq===x.id?'<i>EQUIPPED</i>':''}</b><canvas width="290" height="40" data-k="${x.id}"></canvas><span>${own[x.id]?(eq===x.id?'In your hand':'Owned'):x.how}</span></button>`).join('')}</div>
  <div class="pzkprev"><canvas id="pzkpv" width="820" height="420"></canvas><div class="pzh3k">${sel.n}</div><p>${have?'You own this.':sel.how}</p>${have?`<button class="pzmb gold" id="pzkeq" ${eq===sel.id?'disabled':''}>${eq===sel.id?'Equipped':'Equip'}</button>`:(sel.price?`<button class="pzmb gold" id="pzkbuy" ${P.gold<sel.price?'disabled':''}>Buy for ${cmn(sel.price)}</button>`:`<button class="pzmb" disabled>Locked</button>`)}</div></div>`,'casbg pzx');
 $('pzkbg').getContext('2d').drawImage(pzHubBake(),0,0);$('pzbk').onclick=()=>pzHub();S.back=()=>pzHub();
 ov.querySelectorAll('.pzktabs button').forEach(b=>b.onclick=()=>{PZ.rackTab=b.dataset.t;PZ.rackSel=null;pzFx('tick');pzCueRack()});
 ov.querySelectorAll('.pzki').forEach(b=>{b.onclick=()=>{PZ.rackSel=b.dataset.i;pzFx('tick');pzCueRack()};const cv=b.querySelector('canvas'),g=cv.getContext('2d'),it=items.find(x=>x.id===b.dataset.i);pzRackThumb(g,tab,it,290,40)});
 {const cv=$('pzkpv'),g=cv.getContext('2d');const f=()=>{if(!cv.isConnected)return;pzRackPreview(g,tab,sel,performance.now()/1000)};f();LIVE.push({cv,fn:f,slow:1,ph:0})}
 const eqb=$('pzkeq');if(eqb)eqb.onclick=()=>{if(tab==='cues')Z.cue=sel.id;else if(tab==='felts')Z.felt=sel.id;else Z.balls=sel.id;save();pzFx('place');pzCueRack()};
 const bb=$('pzkbuy');if(bb)bb.onclick=()=>{if(sel.price&&cTake(sel.price)){own[sel.id]=1;if(tab==='cues')Z.cue=sel.id;else if(tab==='felts')Z.felt=sel.id;else Z.balls=sel.id;save();pzFx('win');pzCueRack()}};pzFitTM()}
function pzRackThumb(g,tab,it,w,h){g.clearRect(0,0,w,h);if(tab==='cues'){const s=pzCueSprite(it.id);const k=(w-10)/(PZ_CUE.L+16);if(it.glow)pzGlow(g,w*.55,h/2,w*.5,pzRgba(it.glow),.28);g.save();g.translate(w-6,h/2);g.scale(k,k*1.7);g.drawImage(s.c,-(s.L+10),-15,s.W/2,s.H/2);g.restore()}
 else if(tab==='felts'){const q=pzLin(g,0,0,0,h,[[0,it.a],[1,it.b]]);g.fillStyle=q;pzRR(g,6,4,w-12,h-8,9);g.fill();g.strokeStyle='#7a4018';g.lineWidth=6;g.stroke();g.strokeStyle=PZ_O;g.lineWidth=2;pzRR(g,3,1,w-6,h-2,11);g.stroke();g.fillStyle='rgba(255,255,255,.85)';g.beginPath();g.arc(w*.3,h/2,6,0,TAU);g.fill();g.stroke()}
 else{pzbSetup(PZ_BS.D||52,it.id);g.save();for(let i=0;i<5;i++){const n=[1,3,8,9,15][i];const M=pzbRot(pzbRot(pzbI(),0,1,0,.3+i*.2),1,0,0,-.2);pzbPaint(15,n,M);g.drawImage(PZ_BS.atlas,15*PZ_BS.D,0,PZ_BS.D,PZ_BS.D,20+i*52,h/2-19,38,38)}g.restore();pzbSetup(PZ_BS.D,PZS().balls)}}
function pzRackPreview(g,tab,it,t){g.clearRect(0,0,820,420);g.save();g.lineJoin='round';g.lineCap='round';if(tab!=='cues')g.translate(90,0);
 if(tab==='cues'){g.fillStyle='rgba(8,4,24,.5)';pzRR(g,0,0,820,420,24);g.fill();const q=g.createRadialGradient(410,230,10,410,230,380);q.addColorStop(0,'rgba(120,100,220,.28)');q.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=q;g.fillRect(0,0,820,420);const s=pzCueSprite(it.id);g.translate(410,214);g.rotate(-.2+Math.sin(t*.7)*.035);const sc=1.62;g.scale(sc,sc*1.45);if(it.glow)pzGlow(g,-10,2,230,pzRgba(it.glow),.3+.08*Math.sin(t*2));g.drawImage(s.c,-(s.L+10)/2-6,-15,s.W/2,s.H/2)}
 else if(tab==='felts'){g.fillStyle=pzLin(g,0,40,0,380,[[0,it.a],[1,it.b]]);pzRR(g,60,60,520,300,16);g.fill();g.strokeStyle='#6e3616';g.lineWidth=26;g.stroke();g.strokeStyle=PZ_O;g.lineWidth=3;pzRR(g,47,47,546,326,24);g.stroke();for(const [x,y] of[[60,60],[580,60],[60,360],[580,360],[320,60],[320,360]]){g.fillStyle='#07040a';g.beginPath();g.arc(x,y,16,0,TAU);g.fill();g.strokeStyle='#d8a03a';g.lineWidth=3;g.stroke()}
  g.fillStyle='rgba(255,255,255,.9)';g.beginPath();g.arc(200,210,12,0,TAU);g.fill();const q=g.createRadialGradient(320,200,20,320,200,300);q.addColorStop(0,'rgba(255,240,190,.18)');q.addColorStop(1,'rgba(0,0,0,.4)');g.fillStyle=q;pzRR(g,60,60,520,300,16);g.fill()}
 else{const D=PZ_BS.D;pzbSetup(D,it.id);g.fillStyle='rgba(8,4,24,.5)';pzRR(g,-90,0,820,420,24);g.fill();for(let i=0;i<8;i++){const n=i===0?0:[1,2,3,8,9,12,15][i-1];const M=pzbRot(pzbRot(pzbI(),0,1,0,t*1.1+i*.7),1,0,0,-.3+Math.sin(t+i)*.1);pzbPaint(i,n,M);g.drawImage(PZ_BS.atlas,i*D,0,D,D,40+(i%4)*150,80+Math.floor(i/4)*160,120,120)}pzbSetup(D,PZS().balls)}
 g.restore()}

/* Enter and the arrow keys on the hub and the results screen */
if(!window.__pzKeys2){window.__pzKeys2=1;addEventListener('keydown',e=>{try{if(e.repeat||(PZ.on&&$('pzm')))return;if(document.activeElement&&/INPUT|TEXTAREA/.test(document.activeElement.tagName))return;
 if($('pzre')&&(e.key==='Enter')){e.preventDefault();if(performance.now()-(PZ.resAt||0)>700)($('pzch')||$('pzre')).click();return}
 if($('pzh')&&$('pzrackem')){if(e.key==='Enter'&&!PZ.modal){e.preventDefault();$('pzrackem').click()}
  else if(e.key==='ArrowDown'||e.key==='ArrowUp'){const rows=[...document.querySelectorAll('.pzrow:not(:disabled)')],i=rows.findIndex(r=>r.classList.contains('sel')),n=rows[Math.max(0,Math.min(rows.length-1,i+(e.key==='ArrowDown'?1:-1)))];if(n){e.preventDefault();n.click()}}}}catch(err){}})}
