# python3 t_pzb106b.py [out.html] : 10.6 ball agent B: Cathedral Glass and Aurora Opal (97b8_pz_balls_glass_opal.js, prefix pzb8).
# Registration, the owner's readability rule measured pixel by pixel for both sets (same measuring code as t_pzb102.py), paint cost against
# Starfall and Ember Core, the sets differ from each other and from the older sets, a match draws with each set, no page errors.
import asyncio,os,sys,re
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
SRC=open(os.path.join(HERE,'t_pzb102.py')).read()
MEASURE=re.search(r'MEASURE=r"""(.*?)"""',SRC,re.S).group(1).replace("PZ_BALLS.map(b=>b.id)","['cathedral','opal']")
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:700]),flush=True)
    if not ok:FAIL.append(name)
PRE="()=>{RS_ASK=false;PZ_TUT_OFF=true;WCRELAYS=[];ST.perfAsked=1;PFW.asked=true;P.gold=100000;P.pz=null;save()}"
COST="""(sets)=>{const R={};for(const s of sets){pzbSetup(64,s);const P=PZ_BS;for(let w=0;w<3;w++)for(let n=1;n<16;n++)pzbPaint(15,n,pzbRot(pzbI(),1,0,0,w));let best=1e9;
 for(let tr=0;tr<5;tr++){const t0=performance.now();for(let k=0;k<200;k++)pzbPaint(15,1+k%15,pzbRot(pzbI(),0,1,0,k*.1+tr));best=Math.min(best,(performance.now()-t0)/200)}R[s]=+best.toFixed(3)}pzbSetup(52,'classic');return R}"""
DIFF="""()=>{const out={};const sets=['cathedral','opal','gem','moon','marble','neon','lava','galaxy','royal'];const img={};
 for(const s of sets){pzbSetup(52,s);const a=[];for(const n of [1,9,8]){pzbPaint(15,n,pzbRot(pzbRot(pzbI(),0,1,0,.28),1,0,0,-.22));a.push(Array.from(PZ_BS.ax.getImageData(15*PZ_BS.D,0,PZ_BS.D,PZ_BS.D).data))}img[s]=a}
 const dist=(A,B)=>{let t=0,k=0;for(let q=0;q<3;q++)for(let i=0;i<A[q].length;i+=4){if(A[q][i+3]<250)continue;t+=Math.abs(A[q][i]-B[q][i])+Math.abs(A[q][i+1]-B[q][i+1])+Math.abs(A[q][i+2]-B[q][i+2]);k++}return t/k/3};
 const res={};for(const a of ['cathedral','opal'])for(const b of sets)if(a!==b)res[a+'/'+b]=+dist(img[a],img[b]).toFixed(1);pzbSetup(52,'classic');return res}"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();er=[]
        pg=await b.new_page(viewport={'width':1600,'height':900});pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(H);await pg.wait_for_timeout(1500);await pg.evaluate(PRE);E=pg.evaluate
        r=await E("""()=>['cathedral','opal'].map(id=>{const b=PZ_BALLS.find(x=>x.id===id),p=PZ_BPAL[id];return [!!b,b&&b.n,b&&b.price,b&&b.prem,PZ_TAG97[id],p&&p.kind,p&&p.col&&Object.keys(p.col).length]})""")
        chk('Cathedral Glass: PZ_BALLS entry, name, price 20,000, tag, palette kind',r[0]==[True,'Cathedral Glass',20000,1,'Light through a cathedral window.','cathedral',8],r[0])
        chk('Aurora Opal: PZ_BALLS entry, name, price 50,000, tag, palette kind',r[1]==[True,'Aurora Opal',50000,1,'Every turn flashes a new colour.','opal',8],r[1])
        R=await E(MEASURE)
        keys=['stripeLight','capMin','solidLight','pairGap','solidCol','stripeCol','y8','yMin','ratio8','disc8','num8','numMin','cueY','cueS']
        for s,v in R.items():print('  %-10s'%s+''.join('%10s'%v[k] for k in keys))
        bad=lambda f:{s:v for s,v in R.items() if not f(v)}
        chk('stripes: light caps above and below a coloured band',not bad(lambda v:v['stripeLight']>=.22 and v['capMin']>=.2 and v['stripeCol']>=.2),bad(lambda v:v['stripeLight']>=.22 and v['capMin']>=.2 and v['stripeCol']>=.2))
        chk('solids: coloured all over',not bad(lambda v:v['solidLight']<=.08 and v['solidCol']>=.5),bad(lambda v:v['solidLight']<=.08 and v['solidCol']>=.5))
        chk('solids and stripes told apart by the light area',not bad(lambda v:v['pairGap']>=.18 and v['stripeLight']-v['solidLight']>=.18),bad(lambda v:v['pairGap']>=.18 and v['stripeLight']-v['solidLight']>=.18))
        chk('the 8 is the darkest ball',not bad(lambda v:v['ratio8']<=.62 and v['y8']<=60),bad(lambda v:v['ratio8']<=.62 and v['y8']<=60))
        chk('the 8 disc and number contrast >= 4.5',not bad(lambda v:v['disc8']>=4.5 and v['num8']>=4.5),bad(lambda v:v['disc8']>=4.5 and v['num8']>=4.5))
        chk('every number readable (>= 4:1)',not bad(lambda v:v['numMin']>=4),bad(lambda v:v['numMin']>=4))
        chk('the cue ball is white',not bad(lambda v:v['cueY']>=150 and v['cueS']<=.12),bad(lambda v:v['cueY']>=150 and v['cueS']<=.12))
        c=await E(COST,['galaxy','lava','cathedral','opal']);print('  paint ms (64 px, mean of 200):',c)
        lim=1.5*max(c['galaxy'],c['lava'])
        chk('paint cost within 1.5x of the dearer of Starfall and Ember Core (%.3f ms)'%lim,c['cathedral']<=lim and c['opal']<=lim,c)
        d=await E(DIFF);print('  mean RGB distance of balls 1/9/8 from other sets:',d)
        chk('both sets clearly differ from each other and from the older sets (mean colour distance >= 18; a crude metric, the pearl and marble sets share the pale palette)',min(d.values())>=18,{k:v for k,v in d.items() if v<18})
        # stable under rolling: the same orientation paints identically twice and a rotation changes the pattern
        r=await E("""()=>{const o={};for(const s of ['cathedral','opal']){pzbSetup(52,s);const P=PZ_BS,D=P.D,px=M=>{pzbPaint(15,1,M);return Array.from(P.ax.getImageData(15*D,0,D,D).data)};const M1=pzbRot(pzbI(),0,1,0,.3),a=px(M1),b=px(M1),c=px(pzbRot(pzbI(),0,1,0,.9));let s1=0,s2=0;for(let i=0;i<a.length;i++){s1+=Math.abs(a[i]-b[i]);s2+=Math.abs(a[i]-c[i])}o[s]=[s1,s2>20000]}return o}""")
        chk('painting is deterministic and the pattern rolls with the ball',all(v[0]==0 and v[1] for v in r.values()),r)
        # a real match with each set
        for s in ['cathedral','opal']:
            await E("(s)=>{const Z=PZS();Z.ballsets[s]=1;Z.balls=s;Z.beat.grizzle=1;save();casinoOpen();gameOpen('pz');pzStart({opp:'grizzle',practice:true,seed:7});setTimeout(()=>{const i=document.getElementById('pzintro');if(i)i.click()},500);0}",s)
            await pg.wait_for_timeout(3000)
            r=await E("()=>({set:PZ_BS.set,ph:PZ.ph,balls:PZ.B.length})")
            chk('a match draws with '+s,r['set']==s and r['balls']==16,r)
            await E("()=>{PZ.speed=1;pzForfeit&&pzForfeit()}");await pg.wait_for_timeout(400)
        chk('no page errors',not er,er)
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
