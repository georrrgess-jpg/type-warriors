/* ===== CASINO 9.7d: Plinko nerfed at the owner's request (96zn, after 96zm; one edit in 67_casino3.js) =====
   - New boards: much flatter edges. Top multipliers were 5.6-1,000x (16 rows / high paid 969.92x); now 2.9-126x.
   - Long-run return 96% -> 93% on every rows/risk setting (plkTab normalises each board to PLRTP).
   - No ball ever pays more than PLMAX (20,000): settle() in 67_casino3.js caps every payout, including the balls that are
     settled quietly when the player leaves with balls still falling. At big bets the cap also lowers the return on the
     high-multiplier slots (e.g. 5,000 x 126x pays 20,000, not 630,000). */
const PLMAX=20000,PLRTP=.93;
{const S=h=>h.concat(h.slice(0,-1).reverse());
 PLK[8]={l:S([3,1.6,1.1,1,.6]),m:S([6,2.4,1.3,.8,.5]),h:S([12,3.5,1.4,.4,.2])};
 PLK[12]={l:S([5,2.2,1.5,1.2,1.05,.9,.6]),m:S([14,6,3,1.6,1.05,.6,.4]),h:S([40,12,5,1.8,.7,.3,.2])};
 PLK[16]={l:S([8,4,2,1.4,1.3,1.15,1.05,.95,.6]),m:S([30,15,6,3.5,2.2,1.4,1,.6,.35]),h:S([100,40,14,6,3,1.6,.3,.2,.2])}}
function plkTab(n,k){const b=PLK[n][k];let rtp=0;for(let i=0;i<=n;i++){let c=1;for(let j=0;j<i;j++)c=c*(n-j)/(j+1);rtp+=c/Math.pow(2,n)*b[i]}const f=PLRTP/rtp;return b.map(x=>Math.floor(x*f*100)/100)}
try{const g=GAMES.find(x=>x.id==='pl');if(g)g.d='Drop balls through a field of pegs. Pick the rows and the risk. The edges pay the most. Max payout 20,000 per ball.'}catch(e){}
