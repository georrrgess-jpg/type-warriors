/* ===== RUNESTONE RAMPARTS: the Celestial Prism, a fifth tower (95c3, art only; loads after 95c) =====
   A large hexagonal crystal floats and turns above an arcane pedestal; a sun-gold halo turns slowly behind it, rainbow glints and
   caustics play over the crystal and the dish below. Tiers 1-3 grow the pedestal (tier 3 adds orbiting mini-prisms); tier 4 "Mythic"
   (violet stone, glowing inlays, two orbiting rune rings, a turning sigil on the ground); tier 5 "Celestial" (marble and gold, a crown
   cradle, crystal wings, a ring of light carrying three mini-prisms, star sparkles, an ornate white-gold halo).
   Baked once (RPSPR, lazily or in rpTowerWarm): pad + pedestal + pips, the pedestal alone (build), the static glow layer, 24 crystal
   frames over one 60-degree turn per tier (the crystal has six faces, so that loops), 12 mini-prism frames, the halo, sigil, rune and
   light rings, wing fins, a star, a rainbow streak, the beam bands and a sparkle pattern. Live per frame: drawImage of those (glows with
   'lighter'), a few rect clips for the rings. No shadowBlur, no ctx.filter.
   API (wrapping 95c; every other tower type passes straight through)
     RPTW.prism, RPSKIN.prism            'Celestial Prism'; the only skin is 'base' (any other skin draws as base)
     rpTowerDraw(g,'prism',tier,skin,t,o)  tiers 1-5; o = {aim, fire 0..1, charge 0..1, over, sel, ghost, ph}
     rpTowerBuild(g,'prism',tier,skin,k,t,o)  build (the prism condenses from light), upgrade (o.from), ascension for 3->4 and 4->5;
                                         at k>=1 it is exactly rpTowerDraw
     rpTowerTop('prism',tier)            the crystal tip (beam origin) above the pad centre: 96 117 133 142 148
     rpTowerIcon, rpTowerWarm            as for the other towers
     rpPrismBeam(g,x0,y0,x1,y1,t,k,tier)  the radiant beam (k = charge: thin pale gold at 0, thick white-gold core, rainbow fringe,
                                         flowing sparkles and a pulsing width at 1)
     rpPrismHit(g,x,y,t,k,tier)          the flare where the beam lands
     rpPrismNova(g,x,y,k,r,tier)         the tier-5 supernova pulse (k 0..1, r = radius in px; ground squash RPFX.sq) */
RPTW.prism={n:'Celestial Prism',role:'Radiant beam',col:'#ffe27a'};
RPSKIN.prism=['base'];
const RPZN=24,RPZNM=12,rpzT=t=>Math.max(1,Math.min(5,t|0||1));
/* cr = crystal [belt radius, belt height, top point, bottom point]; cy = belt centre; ped = dish top; dr = dish radius; hr = halo ring and ray radii */
const RPZL=[0,
 {cy:-64,cr:[13,16,24,14],ped:-24,dr:15,hr:[20,29]},
 {cy:-80,cr:[15,18,28,16],ped:-33,dr:19,hr:[23,33]},
 {cy:-92,cr:[16.5,20,31,17],ped:-42,dr:21,hr:[26,37],minis:1},
 {cy:-98,cr:[17.5,21,33,18],ped:-45,dr:22,hr:[29,41],minis:1,rings:1,sig:1},
 {cy:-102,cr:[18.5,22,35,19],ped:-44,dr:22,hr:[34,40],light:1,wings:1,sig:1}];
for(let i=1;i<6;i++){const L=RPZL[i],c=L.cr;L.tip=L.cy-c[1]/2-c[2];L.top=Math.round(-L.tip)}
const RPZPK={
 base:{st:RPSTONE.base,met:'#34358c',metL:'#7276dc',metD:'#181650',tr:'#ffd45a',trL:'#fff0a8',trD:'#b07a1a',rune:'#ffe27a',halo:'#ffc94a',glow:'#ffe9a0',cr:'base',gem:'#ffe27a'},
 myth:{st:RPSTONE.violet,met:'#56289a',metL:'#9c6ae4',metD:'#260c54',tr:'#ffd45a',trL:'#fff0a8',trD:'#b07a1a',rune:'#e0b4ff',halo:'#b278ff',glow:'#c890ff',cr:'myth',gem:'#c890ff',sig:['#8a4ae0','#e6c8ff','#ffd45a']},
 cel:{st:RPSTONE.marble,met:'#efe4c8',metL:'#ffffff',metD:'#b49e72',tr:'#ffd45a',trL:'#fff6c8',trD:'#c08a24',rune:'#ffe9a0',halo:'#ffe7a0',glow:'#fff3c8',cr:'cel',gem:'#ffffff',sig:['#ffc94a','#fffbe8','#ffffff']}};
const rpzP=t=>t>=5?RPZPK.cel:t===4?RPZPK.myth:RPZPK.base;
const RPZCC={
 base:{h:['#ffe98a','#ffb0dc','#94dcff','#b4a4ff','#fff0b8'],dk:'#4a3cae',dk2:'#241a66'},
 myth:{h:['#ffd890','#f09cff','#b98cff','#98aaff','#ecd2ff'],dk:'#4c1a94',dk2:'#240854'},
 cel:{h:['#fffbe8','#ffdcee','#d8f6ff','#fff2c0','#ffffff'],dk:'#f0b23c',dk2:'#b06e16'}};
const RPZRB=['#ff4a6a','#ff9a3a','#ffe24a','#5aff8a','#4ad8ff','#5a7aff','#b45aff'];
function rpzHue(H,f){f=Math.max(0,Math.min(1,f))*(H.length-1);const i=Math.min(H.length-2,f|0);return rpMix(H[i],H[i+1],f-i)}
/* a raw canvas (no 2x), cached */
function rpzCv(key,w,h,fn){let s=RPSPR.get(key);if(s)return s;const c=document.createElement('canvas');c.width=w;c.height=h;const g=c.getContext('2d');try{fn(g,w,h)}catch(e){console.error(e)}s={c,x0:-w/2,y0:-h/2,w,h};RPSPR.set(key,s);return s}

/* ---------- the crystal: a hexagonal bipyramid, faces culled by winding, tinted by angle (so the colours sweep as it turns) ---------- */
function rpzCrArt(g,c,C,f,N,lw,mini){const R=c[0],hm=c[1],zt=hm/2,zb=-hm/2,zA=zt+c[2],zB=zb-c[3],th=f/N*Math.PI/3,Q=RPSQ;
 const P=(a,z)=>[Math.cos(a)*R,Math.sin(a)*R*Q-z],F=[];
 for(let i=0;i<6;i++){const a0=th+i*Math.PI/3,a1=a0+Math.PI/3,am=a0+Math.PI/6;
  F.push({k:0,am,p:[P(a0,zb),P(a1,zb),P(a1,zt),P(a0,zt)]},{k:1,am,p:[P(a0,zt),P(a1,zt),[0,-zA]]},{k:2,am,p:[P(a1,zb),P(a0,zb),[0,-zB]]})}
 const ar=p=>{let s=0;for(let i=0;i<p.length;i++){const a=p[i],b=p[(i+1)%p.length];s+=a[0]*b[1]-b[0]*a[1]}return s};
 const V=F.filter(q=>ar(q.p)>.05),pth=p=>{g.beginPath();g.moveTo(p[0][0],p[0][1]);for(let i=1;i<p.length;i++)g.lineTo(p[i][0],p[i][1]);g.closePath()};
 const sil=()=>{g.beginPath();for(const q of V){g.moveTo(q.p[0][0],q.p[0][1]);for(let i=1;i<q.p.length;i++)g.lineTo(q.p[i][0],q.p[i][1]);g.closePath()}};
 g.lineJoin='round';g.lineCap='round';sil();g.lineWidth=lw*2;g.strokeStyle=RPTO;g.stroke();
 for(const q of V){const s=((q.am%TAU)+TAU)%TAU,u=s>Math.PI?TAU-s:s,hue=rpzHue(C.h,u/Math.PI),d=.5+.5*Math.cos(q.am-2.25);
  let ys=q.p.map(p=>p[1]),y0=Math.min(...ys),y1=Math.max(...ys),c0,c1;
  if(q.k===0){c0=rpMix(C.dk,hue,.3+.7*d);c1=rpMix(C.dk,hue,.08+.62*d)}
  else if(q.k===1){c0=rpMix(hue,'#ffffff',.35+.6*d);c1=rpMix(C.dk,hue,.38+.62*d)}
  else{c0=rpMix(C.dk,hue,.22+.5*d);c1=C.dk2}
  pth(q.p);const gr=g.createLinearGradient(0,y0,0,y1);gr.addColorStop(0,c0);gr.addColorStop(1,c1);g.fillStyle=gr;g.fill();
  /* a rainbow sheen on the face that catches the light */
  const sp=q.k===2?0:Math.pow(Math.max(0,Math.cos(q.am-1.8)),5);
  if(sp>.04&&!mini){g.save();pth(q.p);g.clip();const xs=q.p.map(p=>p[0]),xa=Math.min(...xs),xb=Math.max(...xs),rg=g.createLinearGradient(xa,y0,xb,y1);
   RPZRB.forEach((cc,i)=>rg.addColorStop(.12+i/6*.76,cc));rg.addColorStop(0,'rgba(255,255,255,0)');rg.addColorStop(1,'rgba(255,255,255,0)');g.globalAlpha=.5*sp;g.fillStyle=rg;g.fillRect(xa,y0,xb-xa,y1-y0);g.globalAlpha=1;g.restore()}
  pth(q.p);g.lineWidth=Math.max(.8,lw*.42);g.strokeStyle=d>.5?'rgba(255,255,255,.6)':rpA(C.dk2,.6);g.stroke()}
 /* inner light, a bright vertical streak and the highlight on the upper left */
 g.save();sil();g.clip();let q=g.createRadialGradient(-R*.25,-zt*.4,0,-R*.25,-zt*.4,R*1.9);q.addColorStop(0,'rgba(255,255,255,.4)');q.addColorStop(.5,'rgba(255,255,255,.08)');q.addColorStop(1,'rgba(255,255,255,0)');
 g.fillStyle=q;g.fillRect(-R-4,-zA-4,2*R+8,zA-zB+R+8);
 if(!mini){g.strokeStyle='rgba(255,255,255,.85)';g.lineWidth=lw*.8;g.beginPath();g.moveTo(-R*.55,-zt+2);g.lineTo(-R*.55,zb+R*Q*.2);g.stroke();g.lineWidth=lw*.45;g.beginPath();g.moveTo(-R*.62,-zt-3);g.lineTo(-R*.2,-zA*.82);g.stroke()}
 g.restore();
 const sx=-R*.42,sy=-zt-c[2]*.32,ss=mini?2.2:lw*1.8;g.fillStyle='#ffffff';g.beginPath();g.moveTo(sx,sy-ss*1.6);g.quadraticCurveTo(sx,sy,sx+ss,sy);g.quadraticCurveTo(sx,sy,sx,sy+ss*1.6);g.quadraticCurveTo(sx,sy,sx-ss,sy);g.quadraticCurveTo(sx,sy,sx,sy-ss*1.6);g.fill()}
function rpzCrBox(c,lw){const R=c[0],zA=c[1]/2+c[2],yb=Math.max(c[1]/2+c[3],c[1]/2+R*RPSQ),m=lw+3;return [-(R+m),-(zA+m),2*(R+m),zA+yb+2*m]}
function rpzCrS(tier,f){const P=rpzP(tier),c=RPZL[tier].cr,lw=tier>=4?2.5:2.3,b=rpzCrBox(c,lw);return rpSpr('pz|c|'+tier+'|'+f,b[0],b[1],b[2],b[3],g=>rpzCrArt(g,c,RPZCC[P.cr],f,RPZN,lw,0))}
function rpzMiniS(tier,f){const P=rpzP(tier),c=[5.6,7,10,6],b=rpzCrBox(c,1.6);return rpSpr('pz|m|'+P.cr+'|'+f,b[0],b[1],b[2],b[3],g=>rpzCrArt(g,c,RPZCC[P.cr],f,RPZNM,1.6,1))}

/* ---------- baked ornaments ---------- */
function rpzGem(g,x,y,w,col){g.beginPath();g.moveTo(x,y-w*1.25);g.lineTo(x+w,y);g.lineTo(x,y+w*1.25);g.lineTo(x-w,y);g.closePath();g.fillStyle=rpHG(g,x-w,x+w,'#ffffff',col,rpMix(col,'#12081f',.45));g.fill();rpOut(g,1.6);
 g.fillStyle='rgba(255,255,255,.95)';g.beginPath();g.moveTo(x-w*.15,y-w*.85);g.lineTo(x-w*.55,y-w*.05);g.lineTo(x-w*.15,y-w*.15);g.closePath();g.fill()}
function rpzSunPlate(g,x,y,w,P){g.beginPath();g.moveTo(x,y-w*1.15);g.lineTo(x+w,y);g.lineTo(x,y+w*1.15);g.lineTo(x-w,y);g.closePath();g.fillStyle=rpHG(g,x-w,x+w,P.trL,P.tr,P.trD);g.fill();rpOut(g,2);
 g.beginPath();g.moveTo(x,y-w*.75);g.lineTo(x+w*.62,y);g.lineTo(x,y+w*.75);g.lineTo(x-w*.62,y);g.closePath();g.fillStyle='#1c0e30';g.fill();g.lineWidth=1;g.strokeStyle=RPTO;g.stroke();
 g.fillStyle=P.rune;g.beginPath();g.arc(x,y,w*.19,0,TAU);g.fill();g.strokeStyle=P.rune;g.lineWidth=1.1;g.beginPath();for(let i=0;i<8;i++){const a=i*Math.PI/4;g.moveTo(x+Math.cos(a)*w*.3,y+Math.sin(a)*w*.36);g.lineTo(x+Math.cos(a)*w*.46,y+Math.sin(a)*w*.56)}g.stroke()}
/* the dish the crystal floats over: gold rim, dark well, a baked pool of light */
function rpzDish(g,y,rx,P){rpCap(g,0,y,rx,P.trL,P.trD,2.4);g.beginPath();g.ellipse(0,y+.4,rx*.76,rx*.76*RPSQ,0,0,TAU);g.fillStyle=P.metD;g.fill();g.lineWidth=1.4;g.strokeStyle=RPTO;g.stroke();
 g.save();g.translate(0,y+.4);g.scale(1,RPSQ);const q=g.createRadialGradient(0,0,0,0,0,rx*.76);q.addColorStop(0,'#ffffff');q.addColorStop(.35,'#fff3b0');q.addColorStop(.75,rpA(P.halo,.5));q.addColorStop(1,rpA(P.halo,0));g.fillStyle=q;g.beginPath();g.arc(0,0,rx*.76,0,TAU);g.fill();g.restore();
 g.strokeStyle='rgba(255,255,255,.7)';g.lineWidth=1.2;g.beginPath();g.ellipse(0,y-.6,rx-1.2,(rx-1.2)*RPSQ,0,Math.PI*1.08,Math.PI*1.6);g.stroke()}
function rpzProng(g,x0,y0,x1,y1,cx,cy,lw,P,gem){rpBeam(g,x0,y0,x1,y1,lw,P.tr,P.trL,[cx,cy]);if(gem)rpzGem(g,x1,y1-2,lw*.95,gem);else rpRiv(g,x1,y1,lw*.75,P.trL)}
function rpzBodyArt(g,tier){const P=rpzP(tier),S=P.st,L=RPZL[tier],T=tier;rpPadArt(g);
 if(T===1){rpMason(g,0,0,25,22,13,S,1,5,71);rpTopStone(g,0,-13,22,S,4,rpA(P.rune,.5));rpzSunPlate(g,0,3.5,5,P);
  rpTube(g,0,-13,12,9,6,P.metL,P.met,P.metD);rpTube(g,0,-19,9,15,5,P.trL,P.tr,P.trD,2);rpzDish(g,-24,15,P);
  for(const k of [-1,1])rpzProng(g,k*13,-25,k*10,-40,k*19,-33,3,P)}
 else if(T===2){rpMason(g,0,0,30,27,16,S,2,6,73);rpBand(g,0,0,30.4,2.5,3.2,P.trL,P.tr,P.trD,6,P.trL);rpTopStone(g,0,-16,27,S,6,rpA(P.rune,.5));rpzSunPlate(g,0,3,5.6,P);
  rpTube(g,0,-16,14,11,11,P.metL,P.met,P.metD);rpBand(g,0,-16,13.4,5,3,P.trL,P.tr,P.trD,4,P.trL);rpTube(g,0,-27,11,19,6,P.trL,P.tr,P.trD,2);rpzDish(g,-33,19,P);
  for(const k of [-1,1]){rpCrystal(g,k*19,-31,17,7,k*.55,{l:'#ffffff',m:'#d8ccff',d:'#8a7ad8',k:'#4a3a9a'});rpzProng(g,k*15,-34,k*12,-54,k*23,-44,3.2,P)}}
 else if(T===3){rpMason(g,0,0,35,32,13,S,1,6,75);rpBand(g,0,0,35.4,2,3,P.trL,P.tr,P.trD,8,P.trL);rpTopStone(g,0,-13,32,S,7);
  rpMason(g,0,-13,27,25,14,S,2,5,77);rpBand(g,0,-13,25.6,10.5,3.4,P.trL,P.tr,P.trD,6,P.trL);
  for(const a of [1.12,2.02])rpzSunPlate(g,Math.cos(a)*25,-13-5+Math.sin(a)*25*RPSQ,4.4,P);rpzSunPlate(g,0,3.5,5.2,P);
  rpTopStone(g,0,-27,25,S,9,rpA(P.rune,.55));rpTube(g,0,-27,14,11,9,P.metL,P.met,P.metD);rpBand(g,0,-27,13.4,4,2.8,P.trL,P.tr,P.trD,4,P.trL);
  rpTube(g,0,-36,11,21,6,P.trL,P.tr,P.trD,2);rpzDish(g,-42,21,P);
  for(const k of [-1,1])rpzProng(g,k*19,-43,k*27,-76,k*38,-54,3.2,P,'#fff3b0')}
 else if(T===4){rpMason(g,0,0,36,33,13,S,1,6,79);rpBand(g,0,0,36.4,2,3,P.trL,P.tr,P.trD,8,P.trL);rpTopStone(g,0,-13,33,S,8,rpA(P.gem,.5));
  for(const a of [3.6,4.3,5.1,5.8])rpCrystal(g,Math.cos(a)*30,-13+Math.sin(a)*30*RPSQ,15,6.5,Math.cos(a)*.5,{l:'#fbefff',m:'#c99cff',d:'#7a3ad0',k:'#3a1270'});
  rpMason(g,0,-13,28,26,16,S,2,5,81);rpBand(g,0,-13,26.6,12.5,3.6,P.trL,P.tr,P.trD,6,P.trL);
  for(const a of [.95,1.57,2.19])rpzGem(g,Math.cos(a)*27.4,-13-6+Math.sin(a)*27*RPSQ,3.8,P.gem);rpzSunPlate(g,0,3.5,5.4,P);
  for(const a of [.45,2.7])rpCrystal(g,Math.cos(a)*30,-13+Math.sin(a)*30*RPSQ+2,13,6,Math.cos(a)*.6,{l:'#fbefff',m:'#c99cff',d:'#7a3ad0',k:'#3a1270'});
  rpTopStone(g,0,-29,26,S,10,rpA(P.gem,.6));rpTube(g,0,-29,15,12,10,P.metL,P.met,P.metD);rpBand(g,0,-29,14.4,4,2.8,P.trL,P.tr,P.trD,4,P.trL);
  rpTube(g,0,-39,12,22,6,P.trL,P.tr,P.trD,2);rpzDish(g,-45,22,P);
  for(const k of [-1,1]){rpzProng(g,k*20,-46,k*29,-78,k*40,-58,3.2,P,P.gem);rpCrystal(g,k*17,-44,12,5.5,k*.5,{l:'#fbefff',m:'#c99cff',d:'#7a3ad0',k:'#3a1270'})}}
 else{rpMason(g,0,0,37,34,13,S,1,6,83);rpBand(g,0,0,37.4,2,3,P.trL,P.tr,P.trD,8,P.trL);rpBand(g,0,0,35.2,9,2.4,P.trL,P.tr,P.trD);rpTopStone(g,0,-13,34,S,9,rpA(P.tr,.6));
  rpMason(g,0,-13,29,27,16,S,2,5,85);rpBand(g,0,-13,27.6,12.5,3.6,P.trL,P.tr,P.trD,6,'#ffffff');
  const gc=['#ff9ac4','#8ae8ff','#ffe27a'];[.95,1.57,2.19].forEach((a,i)=>rpzGem(g,Math.cos(a)*28.4,-13-6+Math.sin(a)*28*RPSQ,3.8,gc[i]));rpzSunPlate(g,0,3.5,5.4,P);
  rpTopStone(g,0,-29,27,S,11,rpA(P.tr,.7));rpTube(g,0,-29,15,12,9,P.metL,P.met,P.metD);rpBand(g,0,-29,14.4,4,2.8,P.trL,P.tr,P.trD,4,'#ffffff');
  rpTube(g,0,-38,12,22,6,P.trL,P.tr,P.trD,2);
  /* the crown cradle: points behind the dish, the dish, points in front */
  const pts=[];for(let i=0;i<8;i++){const a=(i+.5)/8*TAU;pts.push([Math.cos(a)*21,-44+Math.sin(a)*21*RPSQ,Math.sin(a)])}
  const spike=([x,y,s])=>{const hh=s<0?8:13+(Math.abs(x)<8?3:0);g.beginPath();g.moveTo(x-4,y+1);g.quadraticCurveTo(x-1.5,y-hh*.5,x,y-hh);g.quadraticCurveTo(x+1.5,y-hh*.5,x+4,y+1);g.closePath();g.fillStyle=rpHG(g,x-4,x+4,P.trL,P.tr,P.trD);g.fill();rpOut(g,1.8);
   g.beginPath();g.arc(x,y-hh-1.5,s<0?1.8:2.4,0,TAU);g.fillStyle=s<0?'#fff6d8':'#ffffff';g.fill();rpOut(g,1.3)};
  for(const p of pts)if(p[2]<0)spike(p);rpzDish(g,-44,22,P);for(const p of pts)if(p[2]>=0)spike(p);
}}
/* tier plaque: tiers 1-3 the gold gems of 95c, tier 4 four violet gems, tier 5 five rainbow gems under a tiny crown */
function rpzPipArt(g,n){if(n<4){rpPipArt(g,n);return}const w=8+n*10,h=12,v=n===4;
 if(!v){g.beginPath();g.moveTo(-7,-h/2+1);g.lineTo(-7,-h/2-4.5);g.lineTo(-3.5,-h/2-2);g.lineTo(0,-h/2-7);g.lineTo(3.5,-h/2-2);g.lineTo(7,-h/2-4.5);g.lineTo(7,-h/2+1);g.closePath();g.fillStyle=rpVG(g,-h/2-7,-h/2,'#fff6c8','#d89a2a');g.fill();rpOut(g,1.8);
  for(const x of [-7,0,7]){g.beginPath();g.arc(x,x?-h/2-5.2:-h/2-7.6,1.5,0,TAU);g.fillStyle='#ffffff';g.fill();g.lineWidth=1;g.strokeStyle=RPTO;g.stroke()}}
 g.beginPath();g.roundRect(-w/2,-h/2,w,h,4);g.fillStyle=v?rpVG(g,-h/2,h/2,'#4a2484','#1a0838'):rpVG(g,-h/2,h/2,'#3a2e7e','#140c34');g.fill();rpOut(g,2.4);
 g.beginPath();g.roundRect(-w/2+1.7,-h/2+1.7,w-3.4,h-3.4,3);g.lineWidth=1;g.strokeStyle=v?'rgba(214,170,255,.75)':'rgba(255,246,200,.85)';g.stroke();
 const RB=['#ff8ab4','#ffd45a','#7affc4','#7ad8ff','#c890ff'];
 for(let i=0;i<n;i++){const x=(i-(n-1)/2)*10,c=v?['#f6e4ff','#b47aff','#5a1ea0']:['#ffffff',RB[i],rpMix(RB[i],'#3a2060',.45)];g.beginPath();g.moveTo(x,-5.4);g.lineTo(x+3.9,0);g.lineTo(x,5.4);g.lineTo(x-3.9,0);g.closePath();g.fillStyle=rpHG(g,x-3.9,x+3.9,c[0],c[1],c[2]);g.fill();g.lineWidth=1.3;g.strokeStyle=RPTO;g.stroke();
  g.fillStyle='rgba(255,255,255,.95)';g.beginPath();g.moveTo(x-.4,-3.6);g.lineTo(x-2.2,-.2);g.lineTo(x-.4,-.6);g.closePath();g.fill()}}
const rpzBack=tier=>rpSpr('pz|bk|'+tier,-66,-100,132,146,g=>{rpzBodyArt(g,tier);g.save();g.translate(0,RPPIPY);rpzPipArt(g,tier);g.restore()});
const rpzBody=tier=>rpSpr('pz|bd|'+tier,-66,-100,132,146,g=>{RPNOPAD=1;try{rpzBodyArt(g,tier)}finally{RPNOPAD=0}});
const rpzPipS=n=>rpSpr('pz|pip|'+n,-32,-17,64,26,g=>rpzPipArt(g,n));
function rpzGlowS(tier){const k='pz|gl|'+tier,s0=RPSPR.get(k);if(s0)return s0;const L=RPZL[tier],P=rpzP(tier),G=[],A=(x,y,rx,ry,c,a)=>G.push([x,y,rx,ry,c,a]),bot=L.cy+L.cr[1]/2+L.cr[3];
 A(0,L.ped,L.dr*1.25,L.dr*.7,'#fff3b0',.9);A(0,(L.ped+bot)/2,9,(L.ped-bot)/2+12,P.glow,.5);A(0,3.5,11,11,'#ffd45a',.7);
 if(tier===3)for(const a of [1.12,2.02])A(Math.cos(a)*25,-18+Math.sin(a)*25*RPSQ,9,9,'#ffd45a',.6);
 if(tier>=4){for(const a of [.95,1.57,2.19])A(Math.cos(a)*27.6,-19+Math.sin(a)*27*RPSQ,10,10,P.glow,.75);A(0,-13,42,16,P.glow,.25)}
 if(tier===4)for(const k of [-1,1])A(k*29,-80,10,10,P.glow,.7);
 if(tier===5)for(let i=0;i<8;i++){const a=(i+.5)/8*TAU;A(Math.cos(a)*21,-44+Math.sin(a)*21*RPSQ-(Math.sin(a)<0?10:15),6,6,'#fff6d8',.55)}
 let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;for(const [x,y,rx,ry] of G){x0=Math.min(x0,x-rx);y0=Math.min(y0,y-ry);x1=Math.max(x1,x+rx);y1=Math.max(y1,y+ry)}
 return rpSpr(k,Math.floor(x0),Math.floor(y0),Math.ceil(x1-x0)+1,Math.ceil(y1-y0)+1,g=>{const ga=RPGA;RPGA=1;g.globalCompositeOperation='lighter';for(const [x,y,rx,ry,c,a] of G)rpGlow(g,x,y,rx,ry,c,a);RPGA=ga})}
/* the halo: a gold sunburst ring that turns slowly behind the crystal */
function rpzHaloArt(g,tier){const L=RPZL[tier],P=rpzP(tier),r=L.hr[0],rr=L.hr[1],n=tier>=5?0:tier===4?16:tier>=2?12:8;
 for(let i=0;i<n;i++){const a=i/n*TAU,lg=n===8||i%2===0,ro=lg?rr:rr*.8,w=lg?.12:.085;g.beginPath();g.moveTo(Math.cos(a-w)*r,Math.sin(a-w)*r);g.lineTo(Math.cos(a)*ro,Math.sin(a)*ro);g.lineTo(Math.cos(a+w)*r,Math.sin(a+w)*r);g.closePath();
  g.fillStyle=rpHG(g,Math.cos(a)*r-6,Math.cos(a)*r+6,P.trL,lg?P.tr:P.trD,P.trD);g.fill();g.lineWidth=1.6;g.strokeStyle=RPTO;g.stroke()}
 if(tier===5){for(let i=0;i<7;i++){g.beginPath();g.arc(0,0,r-4.2-i*.9,0,TAU);g.lineWidth=1.1;g.strokeStyle=rpA(RPZRB[i],.8);g.stroke()}}
 g.beginPath();g.arc(0,0,r,0,TAU);g.lineWidth=5.6;g.strokeStyle=RPTO;g.stroke();g.lineWidth=3.2;g.strokeStyle=P.tr;g.stroke();g.lineWidth=1.3;g.strokeStyle=P.trL;g.beginPath();g.arc(0,0,r-.5,Math.PI*1.02,Math.PI*1.8);g.stroke();
 if(tier>=4){g.beginPath();g.arc(0,0,r+6,0,TAU);g.lineWidth=3.6;g.strokeStyle=RPTO;g.stroke();g.lineWidth=1.6;g.strokeStyle=tier===4?'#c890ff':'#ffffff';g.stroke()}
 if(tier>=3){const m=tier>=5?12:tier===4?8:4;for(let i=0;i<m;i++){const a=i/m*TAU+TAU/m/2;if(tier>=4)rpzGem(g,Math.cos(a)*r,Math.sin(a)*r,2.6,tier===4?'#c890ff':i%3===0?'#ff9ac4':i%3===1?'#8ae8ff':'#ffe27a');else rpRiv(g,Math.cos(a)*r,Math.sin(a)*r,2,P.trL)}}}
const rpzHaloS=tier=>{const rr=RPZL[tier].hr[1]+4;return rpSpr('pz|h|'+tier,-rr,-rr,rr*2,rr*2,g=>rpzHaloArt(g,tier))};
function rpzGlyphs(g,r,n,s){for(let i=0;i<n;i++){const a=i/n*TAU+TAU/n/2;g.save();g.translate(Math.cos(a)*r,Math.sin(a)*r);g.rotate(a+Math.PI/2);g.beginPath();const v=i%4;
  if(v===0){g.moveTo(0,-s);g.lineTo(0,s);g.moveTo(-s*.6,-s*.3);g.lineTo(s*.6,s*.3)}else if(v===1){g.moveTo(-s*.6,-s*.8);g.lineTo(0,s*.8);g.lineTo(s*.6,-s*.8)}else if(v===2){g.moveTo(-s*.6,s*.8);g.lineTo(-s*.6,-s*.8);g.lineTo(s*.6,0);g.closePath()}else{g.moveTo(0,-s);g.lineTo(0,s);g.moveTo(-s*.7,0);g.lineTo(s*.7,0)}g.stroke();g.restore()}}
/* the ground sigil (circle space, radius 100) */
function rpzSigArt(g,C){g.lineCap='round';g.lineJoin='round';g.globalAlpha=.4;g.fillStyle=C[0];g.beginPath();g.arc(0,0,99,0,TAU);g.arc(0,0,78,0,TAU,true);g.fill();g.globalAlpha=1;
 for(const [lw,c] of [[9,'rgba(18,8,31,.85)'],[4.6,C[0]],[1.6,C[1]]])for(const r of [96,79]){g.beginPath();g.arc(0,0,r,0,TAU);g.lineWidth=r>90?lw:lw*.8;g.strokeStyle=c;g.stroke()}
 g.strokeStyle=RPTO;g.lineWidth=5.4;rpzGlyphs(g,87.5,16,6);g.strokeStyle=C[2];g.lineWidth=2.4;rpzGlyphs(g,87.5,16,6);
 for(let i=0;i<8;i++){const a=i/8*TAU;g.beginPath();g.arc(Math.cos(a)*96,Math.sin(a)*96,5.4,0,TAU);g.fillStyle=C[2];g.fill();g.lineWidth=2.2;g.strokeStyle=RPTO;g.stroke()}}
const rpzSigS=tier=>rpSpr('pz|sg|'+tier,-104,-104,208,208,g=>rpzSigArt(g,rpzP(tier).sig||RPZPK.myth.sig),1.2);
/* the orbiting rune ring (tier 4) and the ring of light (tier 5) */
function rpzRuneRingArt(g){for(const [lw,c] of [[15,'rgba(18,8,31,.8)'],[9,'#9a5ae8'],[3,'#f0dcff']]){g.beginPath();g.arc(0,0,92,0,TAU);g.lineWidth=lw;g.strokeStyle=c;g.stroke()}
 for(let i=0;i<8;i++){const a=i/8*TAU;g.save();g.translate(Math.cos(a)*92,Math.sin(a)*92);g.rotate(a+Math.PI/2);g.beginPath();g.moveTo(0,-15);g.lineTo(11,0);g.lineTo(0,15);g.lineTo(-11,0);g.closePath();
  g.fillStyle=rpHG(g,-11,11,'#fff0a8','#ffd45a','#b07a1a');g.fill();g.lineWidth=4;g.strokeStyle=RPTO;g.stroke();g.strokeStyle='#4a1a8a';g.lineWidth=3;g.beginPath();if(i%2){g.moveTo(0,-7);g.lineTo(0,7);g.moveTo(-4,-2);g.lineTo(4,2)}else{g.moveTo(-4,-5);g.lineTo(0,5);g.lineTo(4,-5)}g.stroke();g.restore()}}
const rpzRuneRingS=()=>rpSpr('pz|rr',-110,-110,220,220,rpzRuneRingArt,1);
function rpzLightRingArt(g){const q=g.createRadialGradient(0,0,76,0,0,108);q.addColorStop(0,'rgba(255,236,170,0)');q.addColorStop(.55,'rgba(255,236,170,.6)');q.addColorStop(1,'rgba(255,236,170,0)');g.fillStyle=q;g.beginPath();g.arc(0,0,108,0,TAU);g.arc(0,0,76,0,TAU,true);g.fill();
 g.beginPath();g.arc(0,0,93,0,TAU);g.lineWidth=7;g.strokeStyle='#ffe9a0';g.stroke();g.lineWidth=3;g.strokeStyle='#ffffff';g.stroke();
 for(let i=0;i<16;i++){const a=i/16*TAU;g.fillStyle='#ffffff';g.beginPath();g.arc(Math.cos(a)*93,Math.sin(a)*93,i%2?4:6.5,0,TAU);g.fill()}}
const rpzLightRingS=()=>rpSpr('pz|lr',-110,-110,220,220,rpzLightRingArt,1);
/* tier-5 wing fins (a blade pointing up from its root at 0,0) */
function rpzFinArt(g,L,w){const A=[0,5],B=[-w*.5,-L*.3],C=[-w*.16,-L*.8],D=[0,-L],E=[w*.5,-L*.38];
 g.beginPath();g.moveTo(A[0],A[1]);g.lineTo(B[0],B[1]);g.lineTo(C[0],C[1]);g.lineTo(D[0],D[1]);g.lineTo(0,A[1]);g.closePath();g.fillStyle=rpVG(g,-L,5,'#ffffff','#ffe6a8');g.fill();
 g.beginPath();g.moveTo(A[0],A[1]);g.lineTo(D[0],D[1]);g.lineTo(E[0],E[1]);g.closePath();g.fillStyle=rpVG(g,-L,5,'#ffe08a','#c99a3e');g.fill();
 g.strokeStyle='rgba(255,255,255,.9)';g.lineWidth=1.4;g.beginPath();g.moveTo(-w*.3,-L*.28);g.lineTo(-w*.1,-L*.72);g.stroke();
 g.strokeStyle=rpA('#ff9ac4',.7);g.lineWidth=1;g.beginPath();g.moveTo(w*.12,-L*.2);g.lineTo(w*.12,-L*.6);g.stroke();g.strokeStyle=rpA('#8ae8ff',.7);g.beginPath();g.moveTo(w*.24,-L*.22);g.lineTo(w*.24,-L*.48);g.stroke();
 g.beginPath();g.moveTo(A[0],A[1]);g.lineTo(B[0],B[1]);g.lineTo(C[0],C[1]);g.lineTo(D[0],D[1]);g.lineTo(E[0],E[1]);g.closePath();rpOut(g,2.2);
 g.beginPath();g.ellipse(0,3,3.4,2.4,0,0,TAU);g.fillStyle='#ffd45a';g.fill();rpOut(g,1.4)}
const RPZFIN=[[52,14],[46,13],[38,11]];
const rpzFinS=j=>{const [L,w]=RPZFIN[j];return rpSpr('pz|fn|'+j,-w/2-4,-L-4,w+8,L+12,g=>rpzFinArt(g,L,w))};
/* a four-point star, a rainbow streak, a rainbow ring and a ray burst (light, stamped with 'lighter') */
const rpzStarS=()=>rpzCv('pz|st',64,64,g=>{g.translate(32,32);const q=g.createRadialGradient(0,0,0,0,0,30);q.addColorStop(0,'rgba(255,255,255,1)');q.addColorStop(.16,'rgba(255,250,220,.75)');q.addColorStop(.45,'rgba(255,226,150,.16)');q.addColorStop(1,'rgba(255,220,140,0)');g.fillStyle=q;g.fillRect(-32,-32,64,64);
 g.fillStyle='#ffffff';for(const [a,l,w] of [[0,31,3.4],[Math.PI/2,31,3.4],[Math.PI/4,15,1.8],[-Math.PI/4,15,1.8]]){g.save();g.rotate(a);g.beginPath();g.moveTo(-l,0);g.quadraticCurveTo(0,-w,l,0);g.quadraticCurveTo(0,w,-l,0);g.fill();g.restore()}});
const rpzRbS=()=>rpzCv('pz|rb',48,16,g=>{const q=g.createLinearGradient(4,0,44,0);RPZRB.forEach((c,i)=>q.addColorStop(i/6,c));g.fillStyle=q;g.fillRect(0,0,48,16);g.globalCompositeOperation='destination-in';g.setTransform(1,0,0,1/3,24,8);
 const m=g.createRadialGradient(0,0,0,0,0,24);m.addColorStop(0,'rgba(0,0,0,.95)');m.addColorStop(.6,'rgba(0,0,0,.45)');m.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=m;g.fillRect(-24,-24,48,48)});
const rpzRainS=()=>rpzCv('pz|rn',256,256,g=>{const q=g.createRadialGradient(128,128,0,128,128,128);q.addColorStop(0,'rgba(255,255,255,0)');q.addColorStop(.7,'rgba(255,255,255,0)');
 [['#b45aff',.76],['#5a7aff',.8],['#4ad8ff',.84],['#5aff8a',.88],['#ffe24a',.92],['#ff9a3a',.95],['#ff4a6a',.98]].forEach(([c,s])=>q.addColorStop(s,rpA(c,.85)));q.addColorStop(1,'rgba(255,74,106,0)');g.fillStyle=q;g.fillRect(0,0,256,256)});
const rpzRaysS=()=>rpzCv('pz|ry',256,256,g=>{g.translate(128,128);for(let i=0;i<16;i++){const a=i/16*TAU,l=i%2?92:126,w=i%2?.06:.09,q=g.createRadialGradient(0,0,0,0,0,l);q.addColorStop(0,'rgba(255,255,255,.95)');q.addColorStop(.4,'rgba(255,240,190,.5)');q.addColorStop(1,'rgba(255,220,140,0)');
 g.fillStyle=q;g.beginPath();g.moveTo(0,0);g.lineTo(Math.cos(a-w)*l,Math.sin(a-w)*l);g.lineTo(Math.cos(a+w)*l,Math.sin(a+w)*l);g.closePath();g.fill()}});
/* beam bands: stretched along x (vertical profiles) */
const rpzBGS=()=>rpzCv('pz|bg',8,64,g=>{const q=g.createLinearGradient(0,0,0,64);q.addColorStop(0,'rgba(255,190,70,0)');q.addColorStop(.3,'rgba(255,196,80,.35)');q.addColorStop(.5,'rgba(255,224,140,.9)');q.addColorStop(.7,'rgba(255,196,80,.35)');q.addColorStop(1,'rgba(255,190,70,0)');g.fillStyle=q;g.fillRect(0,0,8,64)});
const rpzBCS=()=>rpzCv('pz|bc',8,32,g=>{const q=g.createLinearGradient(0,0,0,32);q.addColorStop(0,'rgba(232,150,40,0)');q.addColorStop(.1,'rgba(240,164,50,.9)');q.addColorStop(.26,'#ffd45a');q.addColorStop(.4,'#fff6c8');q.addColorStop(.5,'#ffffff');q.addColorStop(.6,'#fff6c8');q.addColorStop(.74,'#ffd45a');q.addColorStop(.9,'rgba(240,164,50,.9)');q.addColorStop(1,'rgba(232,150,40,0)');g.fillStyle=q;g.fillRect(0,0,8,32)});
const rpzBFS=()=>rpzCv('pz|bf',8,64,g=>{const q=g.createLinearGradient(0,0,0,64);q.addColorStop(0,'rgba(255,74,106,0)');[['#ff4a6a',.08],['#ff9a3a',.18],['#ffe24a',.28],['#ffe24a',.33]].forEach(([c,s])=>q.addColorStop(s,rpA(c,.85)));q.addColorStop(.4,'rgba(255,255,255,0)');q.addColorStop(.6,'rgba(255,255,255,0)');
 [['#5aff8a',.67],['#4ad8ff',.76],['#5a7aff',.85],['#b45aff',.93]].forEach(([c,s])=>q.addColorStop(s,rpA(c,.85)));q.addColorStop(1,'rgba(180,90,255,0)');g.fillStyle=q;g.fillRect(0,0,8,64)});
const rpzBPS=()=>rpzCv('pz|bp',64,32,g=>{const st=(x,y,s,a)=>{g.globalAlpha=a;g.fillStyle='#ffffff';g.beginPath();g.moveTo(x,y-s);g.quadraticCurveTo(x,y,x+s*.8,y);g.quadraticCurveTo(x,y,x,y+s);g.quadraticCurveTo(x,y,x-s*.8,y);g.quadraticCurveTo(x,y,x,y-s);g.fill()};
 const q=g.createRadialGradient(0,0,0,0,0,6);q.addColorStop(0,'rgba(255,250,220,1)');q.addColorStop(1,'rgba(255,230,150,0)');
 for(const [x,y,r] of [[8,14,5],[30,20,4],[47,11,5.5],[58,22,3.5],[20,9,3]]){g.save();g.translate(x,y);g.scale(r/6,r/6);g.fillStyle=q;g.fillRect(-6,-6,12,12);g.restore()}
 st(8,14,5,1);st(47,11,6,1);st(30,20,3.6,.9);g.globalAlpha=1});
/* core + rainbow fringe in one band, 4 charge levels */
const rpzBCF=i=>rpzCv('pz|bcf|'+i,8,80,g=>{const k=i/3;g.globalAlpha=Math.min(.85,Math.max(0,(k-.12)*1.5));g.drawImage(rpzBFS().c,0,0,8,80);g.globalAlpha=.75+.25*k;g.drawImage(rpzBCS().c,0,24,8,32)});
const RPZPAT=new WeakMap();
function rpzPat(g){let p=RPZPAT.get(g);if(!p){p=g.createPattern(rpzBPS().c,'repeat');RPZPAT.set(g,p)}return p}

/* ---------- the live tower ---------- */
const RPZB1={nopad:0,cut:null,pz:1,pa:1,pw:0,spin:0,halo:1,orb:1,sig:1,glow:1,py:0};
function rpzRing(g,s,x,y,r,tilt,spin,pass,a){g.save();g.translate(x,y);g.rotate(tilt);g.beginPath();if(pass)g.rect(-r-16,0,2*r+32,r);else g.rect(-r-16,-r,2*r+32,r);g.clip();g.scale(r/100,r/100*RPSQ);g.rotate(spin);g.globalAlpha=a;rpPut(g,s);g.restore()}
function rpzMini(g,tier,x,y,sc,f,a,P){g.globalCompositeOperation='lighter';rpGlow(g,x,y,11*sc,11*sc,P.glow,.55*a/RPGA);g.globalCompositeOperation='source-over';const s=rpzMiniS(tier,f);g.globalAlpha=a;g.drawImage(s.c,x+s.x0*sc,y+s.y0*sc,s.w*sc,s.h*sc)}
function rpzOrbit(g,tier,T,cy,pass,a,f,P){const fm=(f>>1)%RPZNM;
 if(tier===4){rpzRing(g,rpzRuneRingS(),0,cy+3,38,.3,T*.9,pass,a);rpzRing(g,rpzRuneRingS(),0,cy-15,27,-.38,-T*1.25,pass,a*.95)}
 if(tier===3||tier===4){const R=tier===4?44:39;for(let i=0;i<3;i++){const an=T*.8+i*TAU/3,sn=Math.sin(an);if((sn<0)!==(pass===0))continue;
  rpzMini(g,tier,Math.cos(an)*R,cy+6+sn*R*RPSQ+Math.sin(T*2.1+i*2)*2.6,.86+.14*sn,(fm+i*4)%RPZNM,a*(pass?1:.88),P)}}
 if(tier===5){const R=46,tl=.2,yc=cy+5,ct=Math.cos(tl),st=Math.sin(tl);g.globalCompositeOperation='lighter';rpzRing(g,rpzLightRingS(),0,yc,R,tl,T*.6,pass,a*.9);
  for(let j=0;j<2;j++){const an=T*2.3+j*Math.PI,sn=Math.sin(an);if((sn<0)!==(pass===0))continue;const lx=Math.cos(an)*R,ly=sn*R*RPSQ;rpGlow(g,ct*lx-st*ly,yc+st*lx+ct*ly,8,8,'#ffffff',.95)}
  g.globalCompositeOperation='source-over';
  for(let i=0;i<3;i++){const an=T*.7+i*TAU/3,sn=Math.sin(an);if((sn<0)!==(pass===0))continue;const lx=Math.cos(an)*R,ly=sn*R*RPSQ;rpzMini(g,5,ct*lx-st*ly,yc+st*lx+ct*ly-4,.84+.16*sn,(fm+i*4)%RPZNM,a*(pass?1:.88),P)}}
 g.globalAlpha=RPGA}
const rpzWingS=s=>rpSpr('pz|wg|'+s,s>0?-8:-60,-56,68,70,g=>{for(let j=2;j>=0;j--){g.save();g.rotate(s*(.62+j*.4));rpzFinArt(g,RPZFIN[j][0],RPZFIN[j][1]);g.restore()}});
function rpzWings(g,T,cy,a,fc){for(const s of [-1,1]){g.save();g.translate(s*15,cy+10);g.rotate(s*(Math.sin(T*1.9)*.06-fc*.06));g.globalAlpha=a;rpPut(g,rpzWingS(s));g.restore()}
 g.globalCompositeOperation='lighter';for(const s of [-1,1]){const j=(T*.8+(s>0?.5:0))%3|0,an=s*(.62+j*.4),L=RPZFIN[j][0]*.85;rpGlow(g,s*15+Math.sin(an)*L,cy+10-Math.cos(an)*L,7,7,'#ffffff',.5+.4*Math.sin(T*3+s))}
 g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}
/* the ground sigil (tiers 4-5), under the pad */
function rpzSig(g,tier,T,a){if(!RPZL[tier].sig||a<=0)return;g.save();g.globalAlpha=a;g.translate(0,13);g.scale(.64,.64*RPSQ);g.rotate(T*.16);rpPut(g,rpzSigS(tier));g.restore();g.globalAlpha=RPGA}
function rpzParts(g,tier,t,o,B){if(!(RPGA>.002))return;const L=RPZL[tier],P=rpzP(tier),c=L.cr,ph=o.ph||0,T=t+ph*3.7,ga=RPGA,b=B||RPZB1;
 const fire=Math.max(0,Math.min(1,o.fire||0)),ch=fire>0?Math.max(0,Math.min(1,o.charge||0)):0,fc=fire*(.35+.65*ch);
 const cy=L.cy+Math.sin(T*1.7)*2.4+(b.py||0),hy=cy-4,tipY=cy-c[1]/2-c[2],botY=cy+c[1]/2+c[3];
 const ang=T*.9+(b.spin||0);let f=Math.floor(ang/(Math.PI/3)*RPZN)%RPZN;if(f<0)f+=RPZN;
 const L1=()=>{g.globalCompositeOperation='lighter'},N0=()=>{g.globalCompositeOperation='source-over';g.globalAlpha=ga};
 if(!b.nopad)rpzSig(g,tier,T,ga);
 const hs=b.halo;if(hs>0){L1();rpGlow(g,0,hy,L.hr[1]*1.65*hs,L.hr[1]*1.65*hs,P.halo,(.4+.1*Math.sin(T*2.1)+.4*fc)*Math.min(1,hs));
  if(fc>.02){g.save();g.translate(0,hy);g.rotate(-T*.5);const s=L.hr[1]*(1.2+.3*ch)*hs;g.globalAlpha=ga*fc*.55;g.drawImage(rpzRaysS().c,-s,-s,s*2,s*2);g.restore()}N0();
  g.save();g.translate(0,hy);g.rotate(T*.22);if(hs!==1)g.scale(hs,hs);g.globalAlpha=ga*Math.min(1,hs);rpPut(g,rpzHaloS(tier));g.restore();g.globalAlpha=ga}
 if(b.cut==null)rpPut(g,b.nopad?rpzBody(tier):rpzBack(tier));else rpPutBelow(g,rpzBody(tier),b.cut,0,b.dy||0);
  if(b.glow>0){L1();g.globalAlpha=ga*b.glow*(.78+.22*Math.sin(T*2.4));rpPut(g,rpzGlowS(tier));N0()}
 if(!b.nopad){const u=((t+ph*2.3)*.28)%1;if(u<.12){const v=u/.12*tier,i=Math.min(tier-1,v|0);L1();rpGlow(g,(i-(tier-1)/2)*10,RPPIPY-1,8,8,'#fff6c8',Math.sin(Math.PI*(v-i))*.95);N0()}}
 if(L.wings&&b.orb>0)rpzWings(g,T,cy,ga*b.orb,fc);
 if(b.orb>0)rpzOrbit(g,tier,T,cy,0,ga*b.orb,f,P);
 /* the levitation light under the crystal */
 L1();rpGlow(g,0,(L.ped+botY)/2,9+4*fc,(L.ped-botY)/2+6,P.glow,.35+.1*Math.sin(T*3)+.4*fc);N0();
 if(b.pz>0){const s=rpzCrS(tier,f);g.globalAlpha=ga*b.pa;if(b.pz===1)rpPut(g,s,0,cy);else{g.save();g.translate(0,cy);g.scale(b.pz,b.pz);rpPut(g,s);g.restore()}g.globalAlpha=ga}
 if(b.orb>0)rpzOrbit(g,tier,T,cy,1,ga*b.orb,f,P);
 L1();
 if(b.pz>0){rpGlow(g,0,cy-4,c[0]*1.6*b.pz,(c[1]+c[2])*.72*b.pz,'#fff6d8',(.16+.07*Math.sin(T*3)+.5*fc)*b.pa);
  /* a rainbow glint sweeping across the crystal */
  {const u=((T*.31)%1);if(u<.42){const v=u/.42,rb=rpzRbS().c;g.save();g.translate(-c[0]*.9+v*c[0]*1.8,cy-c[2]*.15-v*8);g.rotate(-.55);g.globalAlpha=ga*Math.sin(Math.PI*v)*.85*b.pa;g.drawImage(rb,-11,-3.5,22,7);g.restore()}}}
 if(b.pw>0)rpGlow(g,0,cy-4,c[0]*2.4,(c[1]+c[2]+c[3])*.85,'#ffffff',b.pw);
 /* rainbow caustics on the dish and the pad */
 {const rb=rpzRbS().c;for(let i=0;i<(tier>3?3:2);i++){const a2=ang*(i<2?1:.5)+i*Math.PI,r=i<2?L.dr*.5:38,y0=i<2?L.ped:2,sn=Math.sin(a2);if(i===2&&sn<.15)continue;
  g.globalAlpha=ga*(i<2?.55:.4)*(.6+.4*Math.abs(sn))*b.glow;g.drawImage(rb,Math.cos(a2)*r-8,y0+sn*r*RPSQ-2.5,16,5)}}
 /* motes rising from the dish into the crystal */
 {const n=tier>2?4:3;for(let i=0;i<n;i++){const u=(T*.5+i/n)%1;rpGlow(g,Math.sin(u*5+i*2.3)*(9-6*u),L.ped-3-u*(L.ped-3-botY),2.8,2.8,i%2?'#ffffff':P.glow,Math.sin(Math.PI*u)*.9*b.glow)}}
 /* the tip star; firing: a flare at the tip, a streak toward the target and light drawn into the crystal */
 if(b.pz>0){const s=(7+3*Math.sin(T*3.3)+fire*(9+16*ch))*b.pz;g.save();g.translate(0,tipY);g.rotate(T*.7);g.globalAlpha=ga*(.65+.35*fire)*b.pa;g.drawImage(rpzStarS().c,-s,-s,s*2,s*2);g.restore()}
 if(fire>.01){rpGlow(g,0,tipY,13+15*ch,13+15*ch,P.halo,fire*(.5+.3*ch));rpGlow(g,0,tipY,6+7*ch,6+7*ch,'#ffffff',fire);
  const am=o.aim==null?.5:o.aim;g.save();g.translate(0,tipY);g.rotate(am);g.globalAlpha=ga*fire*(.4+.4*ch);g.drawImage(rpGlowC('#fff3b0'),-6,-(4+4*ch),30+26*ch,8+8*ch);g.restore();
  if(ch>.05)for(let i=0;i<4;i++){const u=(T*1.7+i/4)%1,r=(1-u)*(40+14*tier*.3),a=i*1.57+u*2.6;rpGlow(g,Math.cos(a)*r,cy-4+Math.sin(a)*r*.62,3.2,3.2,i%2?'#ffffff':P.halo,ch*fire*u*1.2)}}
 if(tier===5){const SP=[[-50,-30],[47,-44],[-44,24],[54,10]];for(let i=0;i<SP.length;i++){const w=Math.sin(T*2.3+i*1.9);if(w<.2)continue;const s=(4+7*w);g.globalAlpha=ga*w;g.drawImage(rpzStarS().c,SP[i][0]-s,hy+SP[i][1]-s,s*2,s*2)}}
 else if(tier===4){for(let i=0;i<2;i++){const w=Math.sin(T*2+i*2.6);if(w<.3)continue;const s=3+6*w;g.globalAlpha=ga*w;g.drawImage(rpzStarS().c,(i?29:-29)-s,-80-s,s*2,s*2)}}
 N0()}
function rpzDraw(g,tier,t,o){const L=RPZL[tier],over=o.over||0;g.save();RPGA=o.ghost?.5:1;g.globalAlpha=RPGA;g.lineJoin='round';g.lineCap='round';
 if(o.sel){const p=.5+.5*Math.sin(t*4);g.globalCompositeOperation='lighter';rpGlow(g,0,14,82,36,'#ffc94a',.3+.15*p);
  g.globalAlpha=RPGA;g.lineWidth=7;g.strokeStyle='rgba(255,201,74,.25)';g.beginPath();g.ellipse(0,15,64,26,0,0,TAU);g.stroke();g.globalCompositeOperation='source-over';
  g.lineWidth=5;g.strokeStyle=RPTO;g.stroke();g.lineWidth=2.6;g.strokeStyle='rgba(255,212,90,'+(.75+.25*p).toFixed(3)+')';g.stroke()}
 rpzParts(g,tier,t,o,null);
 if(over>.01&&!o.ghost)rpOvercharge(g,0,0,t,over,L.top);
 g.restore();RPGA=1}

/* ---------- build, upgrade and ascension ---------- */
function rpzPips(g,n,sc,flash){g.save();g.translate(0,RPPIPY);g.scale(sc,sc);rpPut(g,rpzPipS(n));g.restore();if(flash>0){g.globalCompositeOperation='lighter';rpGlow(g,(n-1)/2*10,RPPIPY,16,16,'#fff6c8',flash);g.globalCompositeOperation='source-over';g.globalAlpha=1}}
function rpzRuneCircle(g,t,a,sc){if(a<=0)return;g.save();g.scale(sc*.44,sc*.44*RPSQ);g.rotate(t*1.3);g.globalAlpha=Math.min(1,a);rpPut(g,rpSpr('brc',-106,-106,212,212,rpBRingArt));g.restore();
 g.globalCompositeOperation='lighter';rpGlow(g,0,1,50*sc,22*sc,'#ffd45a',(.3+.15*Math.sin(t*9))*a);g.globalCompositeOperation='source-over';g.globalAlpha=1}
function rpzPillar(g,y0,y1,w,a,col){if(a<=.01||w<=.5)return;g.save();g.globalCompositeOperation='lighter';g.translate(0,y0);g.rotate(-Math.PI/2);const len=y0-y1;
 g.globalAlpha=Math.min(1,a);g.drawImage(rpzBGS().c,0,-w*1.6,len,w*3.2);g.globalAlpha=Math.min(1,a)*.9;g.drawImage(rpzBCS().c,0,-w*.36,len,w*.72);g.restore();
 g.globalCompositeOperation='lighter';rpGlow(g,0,y0,w*2.6,w*1.1,col||'#ffd45a',a*.8);g.globalCompositeOperation='source-over';g.globalAlpha=1}
function rpzShock(g,u,R0,R1,col,lw){if(u<=0||u>=1)return;const R=R0+(R1-R0)*rpEO(u);g.globalAlpha=1-u;g.beginPath();g.ellipse(0,8,R,R*RPSQ,0,0,TAU);g.lineWidth=(lw||7)*(1-u)+2;g.strokeStyle=RPTO;g.stroke();g.lineWidth=(lw||7)*.72*(1-u)+1.4;g.strokeStyle=col;g.stroke();g.lineWidth=1.2;g.strokeStyle='#fff6c8';g.stroke();g.globalAlpha=1}
function rpzSpray(g,sp,y,n,R,tc,seed){if(sp<=0||sp>=1)return;g.globalCompositeOperation='lighter';for(let i=0;i<n;i++){const a=i/n*TAU+.26,d=(14+R*rpEO(sp))*(.65+rpR(i+seed)*.55);rpGlow(g,Math.cos(a)*d,y+Math.sin(a)*d*.75+sp*sp*30,4.4,4.4,i%3?'#fff0a8':tc,(1-sp)*1.3)}g.globalCompositeOperation='source-over';g.globalAlpha=1}
function rpzFlash(g,y,top,fl,col){if(fl<=0)return;g.globalCompositeOperation='lighter';rpGlow(g,0,y,74+30*fl,top*.6+20*fl,col,.8*fl*fl);rpGlow(g,0,y,34,top*.36,'#ffffff',fl*fl*fl);g.globalCompositeOperation='source-over';g.globalAlpha=1}
function rpzRays(g,y,s,a,rot){if(a<=.01)return;g.save();g.globalCompositeOperation='lighter';g.translate(0,y);g.rotate(rot);g.globalAlpha=Math.min(1,a);g.drawImage(rpzRaysS().c,-s,-s,s*2,s*2);g.restore();g.globalAlpha=1}
/* light motes spiralling in from all around into the crystal */
function rpzConverge(g,k,k0,k1,n,cy,col){g.globalCompositeOperation='lighter';for(let i=0;i<n;i++){const t0=k0+i*(k1-k0-.22)/n,u=rpSeg(k,t0,t0+.22);if(u<=0||u>=1)continue;const e=u*u,a=i*2.39996+u*2.8,r=(1-e)*(66+rpR(i)*44);
  const x=Math.cos(a)*r,y=cy+Math.sin(a)*r*.55-(1-e)*(rpR(i+3)*50-18),al=Math.sin(Math.PI*u)*1.2;rpGlow(g,x,y,5,5,i%3?'#ffd45a':'#ffffff',al);rpGlow(g,(x+Math.cos(a-.35)*r*.12)*.96,y*.98,3,3,'#fff6c8',al*.5)}g.globalCompositeOperation='source-over';g.globalAlpha=1}
function rpzBuild(g,tier,k,t,o){const from=o.from>=1&&o.from<tier?o.from|0:0,L=RPZL[tier],top=L.top,G='#ffd45a',oo={aim:o.aim,ph:o.ph,fire:0,charge:0};
 g.save();RPGA=1;g.globalAlpha=1;g.lineJoin='round';g.lineCap='round';g.globalCompositeOperation='source-over';
 const S=(a,b)=>rpSeg(k,a,b),B=x=>Object.assign({},RPZB1,{nopad:1},x),T=t+(o.ph||0)*3.7;
 if(!from)rpzSig(g,tier,T,S(.6,.9));else if(tier>=4&&from>=3){rpzSig(g,from,T,1-S(.4,.52)*S(.4,.52));rpzSig(g,tier,T,S(.56,.9))}
 rpPut(g,rpPadS());
 if(!from){
  /* new: rune circle, motes condense into a star that becomes the crystal while the pedestal rises; then flash, halo bloom, shockwave */
  const rf=1-S(.8,.97);rpzRuneCircle(g,t,S(0,.16)*1.5*rf,.4+.6*rpEB(S(0,.16)));
  {const pk=S(.82,.97);if(k>=.82)rpzPips(g,tier,pk<1?rpEB(pk):1,pk>0&&pk<1?1-pk:0)}
  rpzPillar(g,4,-top-40,10+10*S(.04,.3),S(.04,.24)*(1-S(.62,.85))*.55);
  rpzConverge(g,k,.02,.62,16,L.cy-4,G);
  const e0=S(.1,.5),e=e0*e0*(3-2*e0),ry=36-e*136,cs=S(.5,.72),pu=S(.5,.72);
  {const s1=S(.28,.56)*(1-S(.5,.62));if(s1>0){g.globalCompositeOperation='lighter';rpGlow(g,0,L.cy-4,10+34*s1,10+34*s1,G,.9*s1);rpGlow(g,0,L.cy-4,6+12*s1,6+12*s1,'#ffffff',s1);
   const ss=6+30*s1;g.save();g.translate(0,L.cy-4);g.rotate(t*4);g.globalAlpha=s1;g.drawImage(rpzStarS().c,-ss,-ss,ss*2,ss*2);g.restore();g.globalCompositeOperation='source-over';g.globalAlpha=1}}
  if(e>0){const b=B({cut:e<1?ry:null,dy:(1-e)*12,pz:cs>0?.15+.85*rpEB(cs):0,pa:Math.min(1,cs*3),pw:cs>0?(1-S(.55,.9))*.95:0,spin:7*(1-rpEO(S(.5,.95))),halo:rpEB(S(.6,.85)),orb:S(.7,.9),sig:S(.6,.9),glow:S(.45,.8)});rpzParts(g,tier,t,oo,b);RPGA=1;g.globalAlpha=1}
  if(e>0&&e<1){g.globalCompositeOperation='lighter';const ew=40+6*Math.sin(t*24);rpGlow(g,0,ry,ew+24,14,G,.95);rpGlow(g,0,ry,ew,6,'#ffffff',1);g.globalAlpha=1;g.fillStyle='#fff6c8';g.fillRect(-ew*.85,ry-1.2,ew*1.7,2.4);g.globalCompositeOperation='source-over'}
  rpzRays(g,L.cy-4,70+50*S(.58,.8),(1-S(.62,.85))*S(.56,.62),t*.8);
  rpzFlash(g,L.cy-10,top,k<.6?S(.5,.6):1-S(.6,.8),G);
  rpzShock(g,S(.6,.95),30,104,G,7);rpzShock(g,S(.68,.97),24,80,'#fff0a8',5);
  rpzSpray(g,S(.6,.97),L.cy,14,64,RPTW.prism.col,tier);rpDust(g,0,10,S(.55,.75),1.6)}
 else if(!(tier>=4&&from>=3)){
  /* upgrade 1->2, 2->3: the old crystal spins up and whitens, dissolves into light; the new pedestal rises and the new crystal forms */
  rpzRuneCircle(g,t*1.4,S(0,.14)*1.4*(1-S(.7,.97)),.5+.5*rpEB(S(0,.14)));
  {const n=k<.62?from:tier,pk=S(.62,.82);rpzPips(g,n,k>=.62&&pk<1?.75+.25*rpEB(pk):1,pk>0&&pk<1?1-pk:0)}
  rpzPillar(g,6,-top-60,12+12*S(.06,.4),S(.06,.3)*(1-S(.62,.9))*.6);
  const of=S(.32,.52);if(of<1){g.save();const e1=rpEIO(of);g.scale(1-.1*e1,1-.22*e1);RPGA=1-of*of;rpzParts(g,from,t,oo,B({spin:5*S(0,.45)*S(0,.45),pw:.85*S(.08,.42),py:-6*S(.1,.45),halo:1+.25*S(0,.4)}));g.restore();RPGA=1;g.globalAlpha=1;
   g.globalCompositeOperation='lighter';g.globalAlpha=Math.min(1,.7*S(0,.34)*(1-of));rpPut(g,rpzBody(from));g.globalCompositeOperation='source-over';g.globalAlpha=1}
  rpzConverge(g,k,.3,.7,10,L.cy-4,G);
  const e0=S(.36,.66),e=e0*e0*(3-2*e0),ry=36-e*136,cs=S(.46,.7);
  if(e>0){const b=B({cut:e<1?ry:null,dy:(1-e)*8,pz:cs>0?.45+.55*rpEB(cs):0,pa:Math.min(1,cs*3),pw:cs>0?(1-S(.5,.88))*.9:0,spin:6*(1-rpEO(S(.46,.94))),halo:rpEB(S(.5,.8)),orb:S(.64,.88),sig:S(.6,.9),glow:S(.5,.8)});rpzParts(g,tier,t,oo,b);RPGA=1;g.globalAlpha=1}
  if(e>0&&e<1){g.globalCompositeOperation='lighter';const ew=44+6*Math.sin(t*24);rpGlow(g,0,ry,ew+24,14,G,.95);rpGlow(g,0,ry,ew,6,'#ffffff',1);g.globalAlpha=1;g.fillStyle='#fff6c8';g.fillRect(-ew*.85,ry-1.2,ew*1.7,2.4);g.globalCompositeOperation='source-over'}
  rpzRays(g,L.cy-4,80+50*S(.46,.75),(1-S(.5,.8))*S(.4,.48),-t*.9);
  rpzFlash(g,L.cy-10,top,k<.46?S(.3,.46):1-S(.46,.72),'#fff0b0');
  rpzShock(g,S(.62,.95),34,110,G,7);rpzShock(g,S(.7,.97),28,86,'#fff0a8',5);rpzSpray(g,S(.6,.97),L.cy,14,66,RPTW.prism.col,tier+7);
  rpDust(g,-30,10,S(.62,.86),1.3);rpDust(g,30,12,S(.62,.88),1.3)}
 else{
  /* ascension 3->4, 4->5: a pillar of light from the sky, three rune rings converge, a flash and a shockwave, the new tier settles */
  const P=rpzP(tier),HC=P.halo,pk=S(0,.14),yb=-420+424*rpEO(pk),pw=(18+30*S(.1,.45))*(1-S(.62,.96));
  rpzPillar(g,yb,-470,pw,Math.min(1,pk*3)*(1-S(.8,.97)),HC);
  {const n=k<.55?from:tier,qk=S(.55,.75);rpzPips(g,n,k>=.55&&qk<1?.6+.4*rpEB(qk):1,qk>0&&qk<1?1.2*(1-qk):0)}
  rpzRuneCircle(g,t*1.6,S(.02,.16)*1.5*(1-S(.75,.97)),.6+.6*rpEB(S(.02,.16)));
  const of=S(.4,.52);if(of<1){g.save();RPGA=1-of*of;rpzParts(g,from,t,oo,B({spin:8*S(0,.5)*S(0,.5),pw:.95*S(.06,.46),py:-10*rpEIO(S(.04,.46)),halo:1+.3*S(0,.45)}));g.restore();RPGA=1;g.globalAlpha=1;
   g.globalCompositeOperation='lighter';g.globalAlpha=Math.min(1,.8*S(0,.4)*(1-of));rpPut(g,rpzBody(from));g.globalCompositeOperation='source-over';g.globalAlpha=1}
  /* the converging rings (the new tier's sigil) */
  for(let j=0;j<3;j++){const u=S(.05+j*.05,.5+j*.03);if(u<=0||u>=1)continue;const e=rpEIO(u),r=(150-j*22)+((22+j*8)-(150-j*22))*e,y=(-300+j*95)+((L.cy+30-j*30)-(-300+j*95))*e,al=Math.min(1,u*4)*(1-rpSeg(u,.82,1));
   g.save();g.translate(0,y);g.scale(r/100,r/100*RPSQ);g.rotate(t*(j%2?-2.4:2.4)+u*6);g.globalAlpha=al;rpPut(g,rpzSigS(tier));g.restore();g.globalCompositeOperation='lighter';rpGlow(g,0,y,r*1.15,r*RPSQ*1.4,HC,al*.6);g.globalCompositeOperation='source-over';g.globalAlpha=1}
  rpzConverge(g,k,.12,.56,14,L.cy-4,HC);
  const pu=S(.5,.82),a=Math.pow(1-pu,1.5),w=Math.sin(pu*Math.PI*2.5),sy=pu>0?1-.2*w*a:1,sx=pu>0?1+.13*w*a:1;
  if(k>=.48){g.save();g.scale(sx,sy);RPGA=S(.48,.56);rpzParts(g,tier,t,oo,B({pw:(1-S(.5,.82))*.95,spin:8*(1-rpEO(S(.5,.95))),halo:rpEB(S(.55,.82)),orb:S(.62,.9),sig:S(.56,.9),glow:S(.5,.8)}));g.restore();RPGA=1;g.globalAlpha=1}
  rpzRays(g,L.cy-8,90+90*S(.48,.85),(1-S(.55,.9))*S(.44,.5)*1.2,t*.7);
  rpzFlash(g,L.cy-12,top,k<.5?S(.38,.5):1-S(.5,.78),HC);
  {const u=S(.5,.92);if(u>0&&u<1){const R=40+130*rpEO(u);g.save();g.globalCompositeOperation='lighter';g.globalAlpha=(1-u);g.drawImage(rpzRainS().c,-R*1.05,8-R*1.05*RPSQ,R*2.1,R*2.1*RPSQ);g.restore();g.globalAlpha=1}}
  rpzShock(g,S(.5,.9),36,160,HC==='#ffe7a0'?G:HC,9);rpzShock(g,S(.56,.95),30,120,G,6);rpzShock(g,S(.64,.97),26,84,'#fff6c8',4);
  /* sparkles falling from the pillar */
  if(k>.5&&k<.97){g.globalCompositeOperation='lighter';for(let i=0;i<16;i++){const u=S(.5+rpR(i)*.25,.75+rpR(i)*.22);if(u<=0||u>=1)continue;const x=(rpR(i+5)-.5)*120+Math.sin(u*6+i)*8,y=-top-80+u*(top+90);
    const s=4+4*(1-u);g.globalAlpha=(1-u)*Math.min(1,u*5);g.drawImage(rpzStarS().c,x-s,y-s,s*2,s*2)}g.globalCompositeOperation='source-over';g.globalAlpha=1}
  rpzSpray(g,S(.52,.97),L.cy,18,84,HC,tier+3);rpDust(g,-34,10,S(.5,.75),1.5);rpDust(g,34,12,S(.5,.78),1.5)}
 g.restore();RPGA=1}

/* ---------- beam, hit flare, supernova ---------- */
function rpzTs(tier){return tier>=5?1.45:tier===4?1.28:tier===3?1.12:tier===2?1.05:1}
function rpPrismBeam(g,x0,y0,x1,y1,t,k,tier){k=Math.max(0,Math.min(1,k||0));tier=rpzT(tier);t=t||0;const dx=x1-x0,dy=y1-y0,d=Math.hypot(dx,dy);if(!(d>2))return;
 const ts=rpzTs(tier),pul=1+(.05+.15*k)*Math.sin(t*16-d*.004),wc=(1.5+4.3*k)*ts*pul,wg=(4+8.5*k)*ts*pul;
 g.save();g.translate(x0,y0);g.rotate(Math.atan2(dy,dx));g.globalCompositeOperation='lighter';
 g.globalAlpha=.4+.35*k;g.drawImage(rpzBGS().c,0,-wg,d,wg*2);g.globalCompositeOperation='source-over';
 g.globalAlpha=1;g.drawImage(rpzBCF(Math.round(k*3)).c,0,-wc*2.5,d,wc*5);
 g.globalCompositeOperation='lighter';
 if(k>.06){const s=Math.max(.45,wc*1.5/16);g.save();g.globalAlpha=Math.min(1,k*1.5);g.scale(s,s);const off=(t*380/s)%64;g.translate(off,0);g.fillStyle=rpzPat(g);g.fillRect(-off,-16,d/s,32);g.restore()}
 const gc=rpGlowC('#ffffff');for(let i=0;i<2;i++){const u=(t*1.5+i*.5)%1;g.globalAlpha=(.3+.5*k)*Math.sin(Math.PI*u);g.drawImage(gc,u*d-14,-wc*1.6,28,wc*3.2)}
 g.restore()}
function rpPrismHit(g,x,y,t,k,tier){k=Math.max(0,Math.min(1,k||0));tier=rpzT(tier);t=t||0;const ts=rpzTs(tier),p=.5+.5*Math.sin(t*19),R=(8+11*k)*ts;
 g.save();g.globalCompositeOperation='lighter';
 g.globalAlpha=.45+.3*k;g.drawImage(rpGlowC('#ffb83a'),x-R*1.5,y-R*1.5,R*3,R*3);g.globalAlpha=.8;g.drawImage(rpGlowC('#fff3b0'),x-R*.9,y-R*.9,R*1.8,R*1.8);
 g.globalAlpha=1;const rw=R*(.4+.12*p);g.drawImage(rpGlowC('#ffffff'),x-rw,y-rw,rw*2,rw*2);
 const st=rpzStarS().c;g.translate(x,y);g.save();g.rotate(t*1.6);const ss=R*(1.15+.25*p);g.globalAlpha=.6+.4*k;g.drawImage(st,-ss,-ss,ss*2,ss*2);g.restore();
 if(k>.25){const u=(t*2.6)%1,rr=R*(.6+1.1*u);g.globalAlpha=(1-u)*(k-.25)*.8;g.drawImage(rpzRainS().c,-rr,-rr*.8,rr*2,rr*1.6)}
 for(let i=0;i<3;i++){const q=t*2.2+i/3,u=q%1,n=Math.floor(q),a=i*2.4+n*1.7,d=R*(.4+1.7*u);g.globalAlpha=(1-u)*(.6+.5*k);const s=2.6+1.8*(1-u);g.drawImage(rpGlowC(i%2?'#ffffff':'#ffd45a'),Math.cos(a)*d-s,Math.sin(a)*d*.7-s-u*8,s*2,s*2)}
 g.restore()}
function rpPrismNova(g,x,y,k,r,tier){if(!(k>=0&&k<=1))return;tier=rpzT(tier);const sq=RPFX.sq,e=1-Math.pow(1-k,3),f=1-k,R=r*(.06+.94*e),P=rpzP(tier);g.save();g.lineCap='round';
 g.globalAlpha=.24*f;g.fillStyle='#fff3c0';g.beginPath();g.ellipse(x,y,R,R*sq,0,0,TAU);g.fill();
 g.globalCompositeOperation='lighter';
 if(k<.4){const q=1-k/.4,s=60+r*.5*k;g.globalAlpha=q;g.drawImage(rpGlowC('#ffffff'),x-s,y-40-s,s*2,s*2);g.drawImage(rpGlowC('#ffd45a'),x-s*1.6,y-30-s*1.2,s*3.2,s*2.4)}
 g.globalAlpha=f*.6;g.drawImage(rpGlowC(P.halo),x-R*1.2,y-R*sq*1.4,R*2.4,R*sq*2.8);
 g.globalAlpha=Math.min(1,f*1.7);g.drawImage(rpzRainS().c,x-R*1.08,y-R*1.08*sq,R*2.16,R*2.16*sq);
 {const R2=R*.7;g.globalAlpha=Math.min(1,f*1.2)*.8;g.drawImage(rpzRainS().c,x-R2*1.08,y-R2*1.08*sq,R2*2.16,R2*2.16*sq)}
 if(k<.7){const u=k/.7;g.save();g.translate(x,y-20);g.rotate(k*1.2);g.scale(1,.8);const s=r*.35+r*.6*u;g.globalAlpha=(1-u)*.9;g.drawImage(rpzRaysS().c,-s,-s,s*2,s*2);g.restore()}
 g.globalCompositeOperation='source-over';
 g.globalAlpha=Math.min(1,f*1.5);g.beginPath();g.ellipse(x,y,R,R*sq,0,0,TAU);g.lineWidth=6*f+3.4;g.strokeStyle='rgba(18,8,31,.55)';g.stroke();g.lineWidth=4.4*f+1.6;g.strokeStyle='#ffd45a';g.stroke();g.lineWidth=1.6;g.strokeStyle='#ffffff';g.stroke();
 if(k>.12){const k2=(k-.12)/.88,R2=r*(.06+.94*(1-Math.pow(1-k2,3)))*.82;g.globalAlpha=Math.min(1,(1-k2)*1.3)*.85;g.beginPath();g.ellipse(x,y,R2,R2*sq,0,0,TAU);g.lineWidth=3*(1-k2)+1.4;g.strokeStyle='#fff6c8';g.stroke()}
 g.globalCompositeOperation='lighter';const st=rpzStarS().c,gc=rpGlowC('#fff3b0');
 for(let i=0;i<14;i++){const a=i/14*TAU+.2,px=x+Math.cos(a)*R,py=y+Math.sin(a)*R*sq,h=(26+18*rpR(i+tier))*f;g.globalAlpha=f*.7;g.drawImage(gc,px-5,py-h,10,h*1.2);
  if(i%2===0){const s=(5+5*rpR(i))*(.4+f);g.globalAlpha=Math.min(1,f*1.6);g.drawImage(st,px-s,py-s-h*.6*k,s*2,s*2)}}
 g.restore()}

/* ---------- warm, icon and the wrappers ---------- */
function rpzWarm(tier){rpPadS();rpzBack(tier);rpzBody(tier);rpzGlowS(tier);rpzHaloS(tier);rpzPipS(tier);for(let f=0;f<RPZN;f++)rpzCrS(tier,f);if(tier>=3)for(let f=0;f<RPZNM;f++)rpzMiniS(tier,f);
 if(RPZL[tier].sig)rpzSigS(tier);if(tier===4)rpzRuneRingS();if(tier===5){rpzLightRingS();rpzWingS(1);rpzWingS(-1)}
 rpzStarS();rpzRbS();rpzRainS();rpzRaysS();rpzBGS();rpzBCS();rpzBFS();rpzBPS();for(let i=0;i<4;i++)rpzBCF(i);rpSpr('brc',-106,-106,212,212,rpBRingArt)}
{const f0=rpTowerDraw;rpTowerDraw=function(g,type,tier,skin,t,o){if(type!=='prism')return f0.apply(this,arguments);rpzDraw(g,rpzT(tier),t||0,o||{})}}
{const f0=rpTowerBuild;rpTowerBuild=function(g,type,tier,skin,k,t,o){if(type!=='prism')return f0.apply(this,arguments);o=o||{};t=t||0;tier=rpzT(tier);if(!(k<1)){rpzDraw(g,tier,t,o);return}rpzBuild(g,tier,Math.max(0,k||0),t,o)}}
{const f0=rpTowerTop;rpTowerTop=function(type,tier){return type==='prism'?RPZL[rpzT(tier)].top:f0.apply(this,arguments)}}
{const f0=rpTowerWarm;rpTowerWarm=function(type,tier,skin){if(type!=='prism')return f0.apply(this,arguments);rpzWarm(rpzT(tier))}}
{const f0=rpTowerIcon;rpTowerIcon=function(type,tier,skin,size){if(type!=='prism')return f0.apply(this,arguments);tier=rpzT(tier);size=Math.max(16,size|0||96);const key='pz|ic|'+tier+'|'+size;let s=RPSPR.get(key);if(s)return s.c;
 const c=document.createElement('canvas');c.width=c.height=size;const top=RPZL[tier].top+8,h=top+46,k=Math.min(size*.95/h,size*.95/134),g=c.getContext('2d');g.translate(size/2,size/2+(top-46)/2*k);g.scale(k,k);
 try{rpzDraw(g,tier,.42,{aim:.55,ph:.3})}catch(e){console.error(e)}RPSPR.set(key,{c});return c}}
