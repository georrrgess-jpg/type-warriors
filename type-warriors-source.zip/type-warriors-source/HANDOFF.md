# Type Warriors — Handoff Brief

Read this whole file before changing anything. It records how the game is built, the art and UI style the owner has approved, and the standing rules. Screenshots of the approved look are in `refs/`.

---

## 1. What the game is

Type Warriors is a browser typing game: a chunky cartoon knight (or archer, mage or rogue) fights monsters by typing words. It ships as **one self-contained HTML file** (`type-warriors.html`), with no external assets apart from Google Fonts. The owner plans to publish it on their Wix site.

Major systems:
- Campaign (regions such as Goblin Woods and Sunken Ruins, with stages, stars and region bosses), Endless, Daily Challenge (a new realm and modifier each day), Warden's Arena, Graveyard event, Halloween events.
- Armory: classes, weapons and armor with mastery, Skill Tree, Auto-Equip.
- Casino and minigames, Shop, chests (Celestial / Astral chest, Graveyard crate), Bounty board, Bestiary, Hall, Save Center, Updates/News (the bell), Calendar.
- Companion Hall (pets): roster, eggs (Runeshell = Rare, Crownheart = Legendary), hatching, Adventure Trail stamps, bond levels and cosmetics.
- Main menu: the "Console Dock" hub. A bright diorama of the current region on the right, a campaign panel on the left, a six-tab dock at the bottom (Play, Gear, Pets, Progress, Shop, More), and the bell and calendar in the bottom-right corner.

---

## 2. How the code is organised (important)

- Source is about 145 numbered modules (`00_head.html`, `10_data.js`, … `88c_dockicons.js`, `70_main.js`). `build.sh` concatenates them **in a fixed order** into `out.html`, then syntax-checks the extracted script with `node --check` (it prints `SYNTAX_OK`).
- The deliverable is `out.html`, copied to **`type-warriors.html`**. A second copy, **`type-warriors-act6-TEST.html`**, has always been delivered alongside it. It is byte-identical, built by `build_ast3.sh` into `out_ast.html`. Always build both, confirm `cmp out.html out_ast.html` passes, and deliver both.
- **Everything is one script, so later code overrides earlier code:**
  - A later `function foo(){}` replaces an earlier one everywhere.
  - Wrap an existing function with `{const f0=foo;foo=function(){const r=f0.apply(this,arguments);/*extra*/;return r}}`.
  - Some globals are `const` (for example `dcKey`, `hwOn`, `DKI`, `PTICO`) and cannot be reassigned. Mutate them (`Object.assign(DKI,{...})`) or wrap their callers.
- **Preferred way to make changes:** add a new module after the module you are changing (for example `87h_pet_fx.js` after `87g_pet_polish.js`), add it to the file lists in **both** `build.sh` and `build_ast3.sh`, and do the overrides there. When you edit an existing module, save a backup first (`file.js.v7bak`).
- **UI framework:**
  - `show(html, cls)` renders a menu into `#ov` and clears `LIVE`.
  - Animate canvases with `LIVE.push({cv, fn: t => draw(t), slow: N})`, where `slow` means "render every Nth frame".
  - `S.back` is the Back/Esc handler. `$('id')` is `getElementById`. `title()` opens the main menu.
- **CSS** is added by each module through `document.createElement('style')`. Later styles win.
- **Save data** is the global `P` (for example `P.gold`, `P.pets`, `P.eggs`, `P.petSort`). Call `save()` after changing it.
- **Pets:**
  - Data and logic: `87a_pet_data.js` (`PDEF`, `PIDS`, `petOwned`, `petHatch`, `petBuy`, `petEquip`, `petNextEgg`, `PEGG_PRICE = {r:2000, l:10000}`).
  - Art: `87b_pet_art.js` (`petDraw`, `petFit`, `eggDraw`, `eggFit`, `PSIG` signature colours).
  - Menus: `87c`, `87e`, `87g`, `87h`. Hatch cinematic: `87f` (`ptHatchScene`). State object: `PTX`.
- **Dock and hub:**
  - `88_dock.js` holds the dock, sheets and Daily card.
  - `88b_hub.js` holds the diorama `homeScene`/`drawBG`, the `DKI` icon set, glare and tilt (`.dkg`, `.dktilt`), the hero hotspot and the Daily medallion `dkDailyLive`.
  - `88c_dockicons.js` holds the current dock icons and their animations.

---

## 3. Art and UI style (the owner's approved look; match it)

Look at `refs/` first. In short: **a polished, warm, storybook-cartoon fantasy, lit at night.**

- **Illustration:** hand-built vector art drawn in canvas or inline SVG, never bitmaps.
  - Chunky shapes with **dark outlines** (`#12081f`, about 2.4–3px at a 100-unit scale).
  - Soft gradient fills, a darker "shade" half on the right, and a **white highlight stroke** on the upper left.
  - Small sparkles (4-point stars) and soft additive glows (`pGlow` / `globalCompositeOperation='lighter'`).
  - Characters are cute and round, with big friendly eyes.
- **SVG icon helpers** (in `31b_boonicons.js`; reuse them):
  - `bP(path, fill)`: outlined shape. `bF(path, fill, opacity)`: shade. `bH(path, colour, width)`: highlight.
  - `bC(x, y, r, fill)`: circle. `bEl(...)`: ellipse. `bL(...)`: outlined line. `bS(x, y, r, fill)`: sparkle.
  - Icons use a 100×100 viewBox, with the art roughly between 14 and 86.
- **Palette:**
  - Panels are deep indigo and purple: `#1c1446` to `#0c0822`, borders `#3a3070` / `#5a4ca0`, glassy, with a 1px inner top highlight.
  - Gold accent: `--gold: #ffc94a` / `#ffd45a`. Body text is warm white (`#fff8e8`, `#f4ecd8`). Muted text is lavender (`#c4badf`).
  - Rarity colours: Rare is blue `#5ab8ff`, Legendary is gold `#ffc23a`, and purple `#b47aff` marks magic.
  - Errors and badges use red `#e8364e`.
- **Type:**
  - **Pirata One** for big decorative titles ("Companion Hall", "Armory", pet names), in gold.
  - **Poppins** (`var(--ui)`) for all UI text, bold 700/800 on buttons. Cinzel is used occasionally.
- **Buttons:**
  - Primary is a gold gradient with dark-brown text and a 4px "pressed" bottom shadow.
  - Secondary is indigo with a lavender border. Soft and ghost buttons are text with a chevron.
  - Pills, tags and badges are rounded.
- **Motion:**
  - Springy and lively but tasteful: `cubic-bezier(.3,1.5,.5,1)` overshoot, short (0.2–0.7s) one-shot animations, staggered entrances.
  - Hover lifts things by 2–4px; presses squish them to about 0.9.
  - Idle life comes from bobbing, breathing, blinking and drifting motes.
  - Every animation must finish cleanly. Don't let a hover animation snap back halfway; play it once with a class and remove the class afterwards.
  - Respect `prefers-reduced-motion`.
- **Layout:** 1600×900 design space, scaled to fit. The dock is centred at the bottom. Panels have 18–22px radii. Don't clutter: give one clear next action per screen.

---

## 4. Performance rules (learned the hard way)

Rendering is fill-bound on weaker machines. **Avoid:**
- `backdrop-filter`
- `mix-blend-mode` soft-light or screen
- animated `box-shadow` or `filter`
- infinite `background-position` animations
- large full-screen additive glows every frame

**Prefer:**
- `transform` and `opacity` animations
- cached offscreen canvases for static layers
- `slow` on `LIVE` canvases
- one-shot timed shines instead of constant ones

Measure the frame rate before and after visual changes; headless Chromium gives roughly 18–27 fps as a baseline. For a weaker machine, add CDP `Emulation.setCPUThrottlingRate` (2 or 4) and test at device scale factor 1.5.

---

## 5. Testing

Python Playwright scripts (`t_*.py`) load `out.html` headless, drive the game with `page.evaluate`, print results and write screenshots to `shots/`. An empty `[]` at the end means no page errors. `ERR_TUNNEL_CONNECTION_FAILED` is only the offline font load and is harmless.

Useful patterns:
- Set up state with `await pg.evaluate("()=>{RS_ASK=false;P.gold=5000;P.petSt=2;petNorm();petHall('Pets')}")`.
- Change the date with `pg.clock.install(...)`, because `dcKey` is const.
- Freeze CSS animations mid-way: `el.getAnimations({subtree:true}).forEach(a=>{a.pause();a.currentTime=200})`.

Regression set to run after changes (`tools/regress.sh` runs all 36, `t_riddle` and `t_wagon` first): `t_time_alert t_leaderboard t_ranked t_ranked_net t_wc_school t_perf_casino t_wildcard t_wc_pp t_wc_scan t_access t_code81 t_petclick t_loadout_polish t_loadouts t_flow t_pe t_pdet t_entry t_misc t_trail t_modes t_start6 t_stuck2 t_dkacc t_audit t_sort t_fx t_dock t_dkanim t_fishing t_finishers`. Some depend on game state and may need small updates when a layout changes. Wildcard room codes have their own test, `t_wc_code.py`, which needs a local MQTT broker (see the Wildcard notes below). Keep element IDs stable where you can.

Always **look at screenshots** of what you changed (at 1600×900, and also at 1280×720 or smaller) before delivering.

---

## 6. Standing rules from the owner

1. **Updates tab (bell):** only add or push an in-game update notification when the owner explicitly asks. Even then, **ask for their okay first**.
2. **Do not alter the Celestial chest or Graveyard chest opening animations** unless asked.
3. Deliver **both** `type-warriors.html` and `type-warriors-act6-TEST.html` (identical), plus a few screenshots, with a short, honest summary of what changed and anything not done.
4. The owner gives you creative authority to polish and improve. Keep the existing art style, keep every menu reachable quickly, and keep things functional and intuitive.

---

## 7. Recent work (latest first)

- **Update 8.7 (scaled build of `UPDATE_8.7_PLAN.md`): fixes, fair economy and a menu pass (`94a`–`94f`, after `93l`):**
  - Built in isolated workspaces (`tools/ws.sh new|diff|apply NAME`, lean copies under `/tmp/tw_ws`) and merged by hand; modules are registered with
    `tools/addmod.sh NEW.js AFTER.js`. `tools/bld.sh` now uses its own temp file so several builds can run at once.
  - **`94a_fix_fishing.js`** (plan A1, A2, A4, A6, A9, B1, B16): leaving during a catch show keeps or sells the fish once; a full creel sells instead
    of overfilling; Back mid-fight asks like Esc and counts as an escape; the reel timer pauses on blur/hidden tab ("Paused - press any key");
    on-screen keyboards for Fishing and Trick-or-Treat (`kbWant` in `63_touch.js` asks `tkWant()`, backup `.v7bak`); Big Screen counts the caravan
    and fishing as play. `t_fishing.py` changed one assertion (a full-creel leave now sells: `[30,False]`; backup `.v10bak`). Test: `t_fix87_fish.py`.
  - **`94b_fix_modes.js`** (A3, A5, A7, A8, A10, B2, B6): the riddle settles stats, streak and gold in the same save as the result (a load-time
    recovery settles saves hit by the old bug once); today's answer is no longer stored before it is solved; the four dead Daily Challenge
    trophies (ids `dc1`, `dc7`, `dcw5`, `dcS` kept) now track the Runestone Riddle (Riddle Apprentice, Rune Regular, Stone Scholar, Rune
    Whisperer: first solve, 7-day streak, 5 solves, solve in 1-2 guesses). `rrEnter`/`rrFinish` are full copies in 94b. Wildcard pauses solo and
    same-screen tables while the Game menu is open (`wcLater` replaced; ranked never pauses), `wcAnim` survives leaving mid-animation, and the
    +150 first-win bonus needs a staked game inside the daily cap (`89d_wc_menus.js` line edit, backup `.v7bak`). Arena: Enter works on the result
    and the menu track plays while paused or over (`70_main.js` `mk()` line edit, backup `.v7bak`). Test: `t_fix87_modes.py`.
  - **`94c_fix_menus.js`** (B7-B14, D6): `dkRefreshBadges()` refreshes dock, sub-tab, bell and calendar badges in place after `save()`; Settings keeps
    its scroll position; the bell closes on Esc, moves focus in, counts honestly, and a brand-new save starts with the old update notices read
    (no notice was added); the legacy corner buttons (`#cn`) are hidden outside gameplay; pet timers no longer reopen a screen after Back;
    "none" stats read "No record yet" (`60_ui.js`, `84i`, `84e` edits, backups `.v7bak`); Performance mode rests paused animations at their start;
    used codes survive "Reset save"; Reset save moved from the Profile header to Settings > Data (owner's choice). Test: `t_fix87_menus.py`.
  - **`94d_econ.js`** (E1, E1b, E4, E7, E8, E9, E11, E14): Lantern Caravan daily contracts (first 3 wins per route per local day pay in full, then the
    route pay is 35%; road coins unchanged; `WRP().ctr`; shown on the hub and result card); honest "Up to N coins + road coins"; game speed scales gold
    by `1+.25(r-1)`; prestige clears `P.ug`; eggs can't be bought past the companions left (migration `P.m87` refunds surplus bought eggs once,
    with a toast); calendar and crate-duplicate XP level-ups pay the 100-gold level bonus; reward text says "gold from monsters and rounds"
    (`68b_prestige.js` string, backup `.v7bak`); a backwards clock can't reopen daily rewards (`P.dmax`; `Date` with no argument is held forward
    only while the clock is behind). Casino, Graveyard and Astral pay are unchanged (owner). Test: `t_econ87.py`.
  - **`94e_ledger.js`**: every change of `P.gold` is recorded (`P.ldg`, last 100; `P.ldgDay`, today's totals per source) through an accessor that
    survives `load()`; `ledgerToday()`, `ledgerRecent(n)`, `ukSrc(label,fn)`. No visible UI yet.
  - **`94f_ui87.js`** (menu pass): Back from Settings, Help, Save Center, Menu background and the calendar returns to the screen they were opened
    over (`NAV87` wraps the top-level openers); a bottom row holding a primary action sticks above the dock when the page overflows (Practice);
    modal exits (`.hlmod/.ptmod/.pthx/.pat-wrap/.rkup .out`) use a real fade keyframe instead of the entrance in reverse; no backdrop-filter on the
    old scrims; the global `h1` glow loop is off; stale NEW labels gone (Fishing card kicker reads "Tavern pond"); Wildcard has a card in Choose a
    mode; campaign act tabs show "Act II" with the full name and unlock level as a tooltip (locked tabs give a small shake); Help lists every
    current mode, six acts and the real shortcuts. Test: `t_ui87.py`.
  - Tools from the plan's M0: `tools/perf87/frames.py`, `tools/ui/sweep.py` + `lib.py`, `tools/ui/anim_guard.js` + `anim_scan.py`, `tools/econ/sim.py`.
  - Not done in this scaled round (still in the plan): Quick Switcher, Continue card, the full restyle of older screens, a ledger screen,
    most of the motion and performance milestones (M6, M7), the riddle card's tiles poking above its border.

- **Lantern Caravan 8.6: the conductor, a hero who stays behind the wagon, and the camp hub (`93i`–`93l`, after `93h`; small edits in `30_hero.js`, `93c`, `93d`, `93f`, `93h`; backups `.v1bak`/`.v2bak`):**
  - **Behind the wagon (`93i_wagon_cast.js`):** the hero no longer strikes anything. He rides on a damped spring behind the rear axle (`WRT.HX`), stride phase follows ground speed, with lean, bob, a salute pose after a repair and a stumble on a hit. `drawHero` takes optional `wb`/`wph` stride parameters. The pet follows on its own spring with walk/idle hysteresis and a gait clock. `wrHeroStrike` is redeclared: it now starts the conductor's lash instead of a sword swing.
  - **Conductor Bogsworth:** a toad in a tall hat and a too-small coat, sitting on a cargo crate. He lashes monsters with a tongue (the hit lands at 0.12 s, in step with the monster's white hit frame), tooting a whistle on jams and croaking in speech bubbles (`wrSay`). Registered as `MON.wrcond` with `nx:1` so the Bestiary and mastery lists skip him. Sounds: `WRAFX.toot/lash/croak` (end of `93f`).
  - **Camp hub (`93j_wagon_hub.js`, `93k_wagon_hubstyle.js`):** rebuilt to match the owner's concept art: painted camp backdrop (static bake plus live fire, fireflies, wagon, hero, pet), the "Ready for departure" panel with Start Journey, three painted route cards with lock/compass badges and medal slots, and a bottom bar (Convoy Workshop, Route Log, How to Play). The narrow layout moves the badge to the top right.
  - **Parity (`93l_wagon_screens.js`):** the pause menu is now a panel with Bogsworth's portrait, route/leg, progress bar, stat tiles and key chips; the result card shows a conductor quote.
  - **8.6b fixes:** Bogsworth's head redrawn so it reads cleanly (round cap tucked between two bulging eyes, smaller handlebar moustache above the mouth, nostrils; `93i`, backup `.v1bak`); the camp's string lights moved from the foreground layer to the awning layer so they hang behind the cast instead of across his face (`93j`, backup `.v1bak`). Route pay rebalanced in `93a` (backup `.v1bak`): Millbrook Bridge 420 → 175 (about 200 a run at three or four shields; the first-run-of-day bonus still applies), Hollow Pines 700 → 420, Gallows Pass 1050 → 840 (−20%). Gold medal made reachable (`wrMedalOf` in `93a`, backup `.v2bak`): 3 of 4 shields and 85% accuracy (was 4 of 4 and 92%); silver still needs 2 shields. Result-card hint text and `t_wagon.py` updated. XP values unchanged. Routes shortened 30% (8.6c, `93a` backup `.v3bak`): mill 1800→1260, pines 2600→1820, gallows 3400→2380 units, so a run is roughly 21 s, 30 s and 40 s of road before stops; spawns and hazards are time-based, so shorter routes mean fewer of both.
  - Checks: `t_wagon.py` bad 0; `tools/wr/ovl.py` leaves only the game's own XP bar (`LEVEL` label, 2 px, shared `88h`); `touch.py` clean on all four touch viewports; `tools/wr/cond.py`, `cast.py`, `menus.py` write screenshots to `screenshots/wagon-cast`. Frame times (headless, 1600×900) fight 21.6 / caravan idle 25.8 / busy 27.8 ms mean.
- **Lantern Caravan 8.5c: a more detailed wagon (`93h_wagon_detail.js`, after `93g`):**
  - Redeclares `wrWagonDraw`, `wrWheel` and `wrWheelOff`, and wraps `wrChipArt` (the workshop's paint chips now show the real side panel). Same footprint and anchor points as before (rear axle at the origin, wheels 52/44 at x 0/150, lantern hung at 136,−302), so nothing else moved.
  - Static parts are painted once into 2× sprites (`wrSpr(key,x0,y0,w,h,fn)` → `WRSP`, stamped with `wrPut`): `wb|<paint>` the chassis (beam, leaf springs, axle caps) and the side (four planks with grain and knots via `wrGrain`, stained uprights with iron straps and rivets via `wrRiv`, iron corner plates, top rail and sill, the guild's lantern emblem in the rim colour, a rope coil on a peg, a footstep); `wc` the cargo (burlap sack with weave, patch and tied neck, a red bedroll with leather straps, an iron-cornered crate with an "LC" stencil, a hooped barrel, a tie-down rope); `wf|<lantern>` the wrought-iron post (foot plate, brace, scroll, finial, hook) in the lantern's cage colour; `wn|<paint>` the bench (seat, tufted cushion, back rail); `wd|<paint>` the curved dashboard (trim band in the rim colour, a "No. 7" brass plate). Wheels (`wh|r|rim|far`): iron tyre with twelve rivets, a jointed felloe, twelve tapered spokes (six below r 20), an iron-banded hub with bolts; the sprite rotates while `wrWheelLight` lays a fixed highlight and shade over it so the light does not spin.
  - Live each frame: a tin pail under the rear and a brass bell at the front swing with the lantern (`wrPail`, `wrBell`), the reins are two leather straps that sag when standing and tighten when rolling, plus everything from 93b/93g (pitch, tilt, bob, cargo lag, light pool, alarm, broken wheel).
  - Cost: unchanged. With/without the wagon, rAF frame times: old wagon 3.7–4.1 ms, new 3.5–4.4 ms (`tools/wr/ab.py` against a build without `93h`). Most of the wagon's cost is the lantern glow, the light pool and the driver, as before.
  - Screenshots: `screenshots/wagon-detail/` (`before_*` and `after_*` for each paint, the jam, the breakdown, the hub and the workshop) from `tools/wr/wagon.py`.

- **Lantern Caravan 8.5b: polish pass on motion and impact (`93g_wagon_polish.js`, after `93f`; small edits in `93b`/`93c`/`93d`/`93e`, backups `.v1bak`):**
  - The wagon feels heavy: `WRX.pitch` is a damped spring toward −accel × 0.00034 (clamped ±0.032 rad), applied about the rear axle in `wrWagonDraw`, so it rocks back about 1.8° pulling away and dips about 1.7° stopping, settling within a second. Wheels now roll without slipping (`R.wheel += v/52`; it was v/27). Dust puffs trail both wheels (`WRX.dust`, painted from a `wrGateDraw` wrapper so they sit behind the wagon). The lantern throws a warm pool on the deck (`wrLightPool`, one additive sprite per lantern colour, brighter in a Flare).
  - A jam reads at a glance: sparks from the locked wheel are spawned by the update (they were spawned inside the painter), a red ! springs up over the driver (`wrAlarm`) and pulses faster under 3 s of fuse with a sweat drop, and the wrench bubble turns red, swells and its wrench shakes as the fuse runs out; the fuse bar is gold under 60% and red under 3 s.
  - Hits read before the death: each letter flashes the monster with a white silhouette (`wrSil`: the monster drawn into an offscreen canvas, then `source-atop` white; no `ctx.filter`) and nudges it 7 px; a killed monster holds a white frame for 0.12 s while the blow lands, then squashes over 0.45 s; the finished tag bursts into sparks (red for monsters, blue for repairs). `wrMobDraw`, `wrTag`, `wrToastDraw` and `wrText` are redeclared in `93g`.
  - Tags spring in (`wrOver` over 0.28 s, about the pointer), the typed letter pops 1.4× for 0.16 s, the caret pulses. Toasts spring in. Floating texts step up 44 px instead of stacking; the Horseman's knock-back line moved beside him, clear of his tag.
  - Breakdown: the near front wheel rolls on about 210 px, wobbles and falls flat (`wrWheelOff`), the nose drops about the rear axle, dust and a small shake when the wheel lands.
  - Gate: a shower of sparks and a ring as the doors open (once, `WRX.gConf`).
  - HUD: the coin count rolls up (`coinShow`), the lantern meter fills smoothly (`flareShow`) and sparkles when full (`WRX.hfx`, drawn after the HUD), a shield restored by a Flare pops back with a green ring (`WRX.gainT`).
  - Scene: village windows occasionally go dark or flare (`B.wins` recorded in the bake, about 34 fillRects at most), embers move by real frame time (`R._dt`).
  - Menus: the hub wagon is parked (the world used to slide under still wheels); switching route fades the backdrop through dark over 0.42 s; route cards slide in staggered; cards and chips squish on press; the workshop preview is centred; the home card's wheels match the scroll. Result card: the stats and the pay box stagger in after the medal slam, four sparkles burst around a won medal.
  - Reduced motion (`WRX.rm`): no pitch, no tumble, no springs on tags, toasts, the alarm or the gate doors (an eased swing instead), a short wheel roll-off, fewer sparks, no CSS entrances. Low performance mode (`wrLow()`, `ST.perf==='low'`): no dust, embers, window flicker, waterfall mist or silhouettes (a soft glow instead).
  - Cost: none measurable. `draw()` 15.8–20.8 ms across repeats against 21.7 before; rAF frame times idle 23.7–25.4 / busy 25.4–27.8 ms against the fight's 22.0–22.6 on the same runs (headless software rendering varies ±2 ms between runs).
  - Checks: `t_wagon.py` 37/37, `tools/wr/ovl.py` and `touch.py` clean apart from the shared XP bar's own 2 px LEVEL label, the full regression (see the delivery note), screenshots in `screenshots/wagon-polish/` from `tools/wr/polish.py`.
  - Still open: Big Screen's `fsBusy` (a const in `88m`) does not count the caravan as play; the driver faces the camera; the result card's best time can show 0:00 only when a test forces `WRX.time`.

- **Update 8.5: Lantern Caravan, the wagon escort mode (`93a_wagon_data.js`, `93b_wagon_art.js`, `93c_wagon_game.js`, `93d_wagon_ui.js`, `93e_wagon_style.js`, `93f_wagon_audio.js`, after `92k_riddle_menu2.js`; plan in `WAGON_ROUTE_PLAN.md` at the repo root):**
  - A side-scrolling night road. A goblin-driven wagon with a big lantern rolls along a stone bridge toward a gate; the hero and pet walk beside it. Monsters come in from the right with a word on a red sword tag (type it, the hero cuts them down); the wheel jams now and then (a blue wrench bubble with a repair verb; type it before the fuse runs out or the axle cracks). Monsters that reach the wagon take one of four Wagon Integrity shields. Reach the gate for coins, XP and a bronze/silver/gold route medal; medals unlock lanterns, banners and paint.
  - Architecture: a canvas mode like the Warden's Arena, not an engine `kind`. `wrStart(id)` does `reset()`, `S.mode='wagon'`, `S.wr=1`, builds the state `WRX` and `hide()`s the overlay; `update`/`draw` are wrapped (`if(S.wr&&WRX)return wrUpdate/wrDraw`), `title` is wrapped to `wrLeave()`. Everything on screen lives in screen space and the world scrolls under the wagon by `WRX.x`: pet 235, hero 330, wagon rear axle 640 (body 440..850), monsters stand at `WRT.AX` 930 and lunge 64 px. **The state is `WRX`, not `WR`: `WR` is a const radius in `66k_wheel.js`.**
  - Input: a capture-phase keydown (letters, Tab, Enter = Lantern Flare, Escape = pause, Space swallowed) plus `key(c)` wrapped to `wrKey` for the touch keyboard. Targeting copies `key()`: an open hazard wins when its first letter matches, else the nearest monster; one slip per word is forgiven; Tab cycles (hazard first) and resets the old word.
  - Data (`93a`): `WR_ROUTES` (mill 3 legs/1260 units, pines 4/1820, gallows 5/2380 (shortened 30% in 8.6c) with `bhorse` on the last leg; `wp` waypoint names, `far` backdrop variant, `mobs`, `haz`, `pay`, `xp`, `unlock`), `WR_HAZ` (rock/branch/mud/cargo, verbs, fuse 6–9 s), `WR_WORDS` (~290 road words; `pickWord(role,WR_WORDS,6d+2leg,onScreen)`), `WRT` tuning (speeds 60/132 surge/92 gate, flare meter 60, hit cooldown 2.5 s), medal rules (`wrMedalOf`: bronze reach, silver 2+ shields, gold 4 shields and 92% accuracy), pay (`wrPayOf`: pay × (0.55+0.15×shields) × 0.8–1.1 by accuracy; breakdown 25% × progress; first clear of a route per day ×1.5), cosmetics `WR_COS` (5 lanterns, 5 banners, 4 paints with `need` {route,med} or {allmed}), the save `P.wr` through `WRP()` (lazy normaliser: med, best, runs, clears, lan/ban/paint, own, seen, day/dayDone, seen85, intro, totals), `wrOwn`, `wrUnlockSweep`.
  - Scene (`93b`): per-route strips baked once with `abSprite` (`wr_<route>_sky/ridge/far/river/fall/wall/deck/fore`, shared `wr_postglow`/`wr_vig`) and scrolled by `wrDrift(c,spr,y,factor,x)`: sky (static) → ridge .06 → far set .18 (village with lit windows and a church / pine wall with fog and a watchtower / the keep with dead trees and tombs) → river .35 with a waterfall (a vertically scrolling streak sheet in a clip) → the far parapet with a lantern post every 480 (additive baked glow) → embers → the deck (cobbles, arches cut with destination-out) → characters → bushes 1.35 → vignette. `wrRidge` is periodic so strips tile. The gate (`wrGateDraw`) is drawn only in the last 620 units, fading in over 140, and its doors swing open (an overshoot squash toward the hinge) with a light spill as it reaches x 1280→960.
  - The wagon (`wrWagonDraw`, origin at the rear axle): far wheels, undercarriage, the banner post (`wrBanner`: pennant flutter by speed, emblem by look), the plank body (paint look), cargo that bobs with a lag, the lantern frame and `wrLantern` (cage/glass/flame/glow by look, pendulum `WRX.swing` driven by acceleration, boosted in a Flare), Professor Nickels as the driver (`rrkDraw(RRK[0])` at .62, clipped behind the front board; modes idle/think/cheer/sad/point via `wrDriver`), near wheels (`wrWheel`, rotation from distance plus a kick-spin after a repair), hazard props under the front wheel (`wrHazProp`), sparks while jammed, smoke when broken. Tilt −2.6° when jammed, +6° and sunk when broken. `R.ox` offsets the characters for the menus.
  - Run (`93c`): speed eases toward 60 (0 with a hazard open or a monster within 140 of the front; 132 for 3 s in a Flare; 92 rolling into the gate). Spawns: waves of 1–3 (+1 on the last leg, ambush toast) every 4.5–7 s ÷ (1+.25(d−1)), cap 3+(d−1); stagger 190 px, speed ±8%; flyers hover and dive. Attack: lunge .5 s, hit at .25 s (`wrHit`: −1 shield, shake, red flash, driver sad, shield-crack animation in the HUD), then `wait` 2.5 s sliding back 52 px with a new word. Hazards (`wrHazOpen`) wait for a clear road (no monster within 300 of the front, not in the last 10%, not during the boss) and reopen 10–16 s after clearing; a burnt fuse calls `wrHit(null,'axle')`. Kills: squash-and-tumble death, bursts, a ring, coins that fly to the HUD counter (2 per 4 letters; boss ×12), the hero dashes out and back (`WRX.dash`, drawn after the wagon; archers and mages shoot via `shotArt`, rogues throw and dash), the pet hops. The Horseman has 3 words (`phs`); each one knocks him back 170 (`kb`); the third banishes him. Lantern Flare (`wrFlare`): +1 per letter, +6 per kill, +4 per repair; at 60, Enter flings every monster off the right edge, knocks the boss back, restores a shield, a radial wash and streaks. Legs light the progress dots with a ping and a toast; `wrGate` flings the monsters, victory pose, 2.8 s roll-in; `wrBreak` stops everything for 2.2 s. `wrFinish` computes medal/pay/XP (`xpMode(rt.xp × prog × xpMulRun())`, `levelGold`, `xpNoteH`), writes `P.wr`, sweeps unlocks, grants the **Caravan Master** title at all gold (`BTY().own['t:caravanmaster']`, pushed to `BT_TITLES` at 1e9, exchange shows "Earn: gold on every caravan route"), credits `btyAdd('wagon',1)`, then `wrResult` after .7–1 s.
  - HUD (canvas, in `wrHUD`): integrity panel (shield glyphs, cracked halves fall for .7 s, red pulse on the last), the progress bar with waypoint dots, a wagon marker and the gate glyph, a coin chip (bumps on landing) and the lantern meter ("ENTER · FLARE" pulse when full). Toasts under the bar (`wrToast`). The corner `#pb` button is reused the arena way (`wrPBHook`/`wrPB`) and moved top-right by `#pb.wrpb`; `#cn` is hidden with `dkhid` while running and `dkCorner()` restores it on leaving. Pause (`wrPause`) on Escape, `#pb`, blur and a hidden tab; the menu offers Resume / Restart (double-click) / Quit route.
  - Touch: `kbWant` is a const tied to `S.mode==='play'`, so the run builds its own keyboard (`wrTouchKb`: `#wrkb` in `#ov.wrkbx`, pointer-events only on the keys, Pause/Target/Flare row) and `applyLayout` is wrapped to scale the stage into the space above it. The hub gets `wr-narrow` below 1100 px of `ov.clientWidth` (touch): the column stacks over the scene, modals go full width.
  - Menus (`93d`/`93e`, fishing-hub style on `#ov.fshx`): `wagonMenu(back)` with a live backdrop (`wrHubDraw` draws the scene and the wagon idling via `wrMenuState`), route cards with medal badges (`wrMedalSVG`), locks and best times, Hitch up (Space; the first time shows the intro strip `wrHowTo(true)`), tiles for the **Convoy Workshop** (`wrWorkshop`: live wagon preview that follows hover/focus, chips with NEW pips, Equip writes `P.wr.lan/ban/paint`), the **Route Log** (medals, best time, accuracy, totals, the title line) and **How to play** (the concept's three-step strip as small live canvases). Result card `wrResult`: medal slam (`.wrmed.slam`), stats, pay line with a count-up and a DOM coin flight (`wrCoinsFly`, `.wrfly`), the XP line ("Earned …" so `88h` injects the animated bar), unlock cards, Ride again / Routes / Home (Esc = Home via `overKey` and `#hm`).
  - Hooks: a featured full-width card at the top of Choose mode (`#dmwr`, scene image from `wrCardShot()`), the home card `#dkwagon` (replaces the Endless card; while the Halloween events card is up it joins as a fourth card, `.dks4` 2×2, and `dkFit()` is re-run), W on the hub (`homeKey`), `HELP.Modes`/`Shortcuts`, the `wagon` bounty template (tier 1; note this reshuffles the tier-1 seeded pool once), `dkDetect` lights the Play tab, DEV › Cheats section (open the hub, start each route, all gold, all looks, reset). No Updates-tab entry, News card or code was added (owner rule).
  - Audio (`93f`, built on the `rra*` helpers from `92i` with its own resources, players and output chain): "Lantern Road", D major, crotchet 104, 34 bars (intro 2 | A 8 glockenspiel | A' 8 recorder | B 8 G-major lift with harp fills | A'' 8 both leads, bassoon doubles the bass), pizzicato bass on 1 and 3, woodblock clip-clop on the off-beats that goes quiet while the wagon stands, a low brass drone and drum while a monster is within 1250 px (`wraState`), tambourine and bells during a Flare; the hub plays the calm version at 88 with harp arpeggios. Hand-over mirrors the riddle: `wraWant()` ('road' while `WRX` is up in modes wagon/over, 'camp' on the hub), `wraPump` from the `note` tick, `mg` ducked over 1.2 s, `WRAM.vol` follows `ST.mute`/`ST.mvol`, stops when hidden or muted; `show`/`hide`/`visibilitychange`/`applyVol` are wrapped. Effects (`WRAFX` through `sg`) replace the beeps by wrapping `wrSfx` (key tick rising with the streak, wrench clink, miss, slip, slash, jam, free, shield crack, flare whoosh and bell run, coin, milestone, leg, boss); the gate plays the fanfare and a breakdown the wah through `wraJing`. `WRAX.on=0` restores the beeps. Levels: road peaks about −5 dBFS before `WRAM.lvl`, near the riddle's track.
  - Tests and tools: `t_wagon.py` (37 checks, steps the simulation with `wrUpdate(1/60)`), second in `tools/regress.sh` (now 36 tests). `tools/wr/`: `snap.py`, `run.py`, `run2.py`, `menus.py`, `ovl.py` (7 viewports × 7 screens: only the big Pirata title's line box and the game's own XP bar report), `touch.py`, `fps.py`, `prof.py`, `mus.py`. Numbers (headless, 1600×900): rAF frame times fight 24.1 ms mean / caravan idle 24.3 / busy with 4 monsters and a hazard 26.2; `draw()` 21.8 ms vs the campaign fight's 18.7 (software rendering is fill-bound; per-part timings are unreliable because `petDraw`'s `getTransform` flushes the batch).
  - Regression notes: `t_dkacc.py` now parks the pointer at (2,2) in `home()`: the featured caravan card pushed the Choose-mode cards down, so after picking Fishing the pointer rested on the hub's Choose mode button and its hover tilt kept the box moving (Playwright's "element is not stable"). `t_leaderboard.py` writes relay logs to `../lbt/`, which must exist at the repo root (git-ignored). `tools/pylib` must hold `amqtt`, `pyyaml` and `websockets` (`pip install --target tools/pylib amqtt pyyaml`).
  - Known limits at 8.5 (most were handled in 8.5b above): `fsBusy` in `88m` is a const, so Big Screen does not count the caravan as play; the driver faces the camera (no seated keeper pose exists).

- **Runestone Riddle 8.4b: Sanctum redesign, keepers and Silas Veil (`92f_silas_art.js`, `92g_riddle_keepers.js`, `92h_riddle_scene.js`, plus rewrites in `92b`/`92c`/`92d`):**
  - Layout follows the owner's Sanctum concept, in three columns: the keeper (320 px), the rune arch with the keyboard slab under it, and the panel (470 px).
    - The panel holds Today's Riddle (day streak, coins today, best streak, payout ladder, 7-day streak tracker with a gift on day 7, View calendar) and a separate Rune Powers panel.
    - The calendar is now a modal (`rrCal`/`rrCalClose`): weekday columns, month paging with ‹ › or the arrow keys, played/solved/avg/best stats and the guess spread.
  - Scene (`92h`):
    - `rrBgPaint` paints the sanctum once per fit. It has the wall, arches, banners, pillars, torch brackets, floor and rug, book piles and candles, and a vignette.
    - Only the torch flames (`rrFlame`, small canvases on `LIVE` slow 2) and the CSS motes move.
    - `rrArchBake` bakes the stone arch for the current tile size. `rrArchLive` draws its 10 side runes and the keystone sigil every frame.
  - Warmth: `rrHeatOf(e)` = (2 × green positions + gold-only letters) / 10, and 1 when solved.
    - Runes wake bottom-up (`o` order) and shift from violet to gold, pulse faster, and embers rise with heat.
    - The recess glows, and a green tile flashes it (`rrHeatPulse`).
    - CSS `--heat` drives the outer glow, with `.hot` at 0.6, `.blaze` at 0.85 and `.awake`/`.dim` on win/lose.
    - `rrResonate` plays a chord after each guess, with 1 + 5·heat notes, a harmony at 0.6+ and a shimmer at 0.8+. Key ticks rise in pitch with heat.
    - The arch tilts toward the pointer (`#rrtilt`), with a lamp following it. This is off for touch and reduced motion.
  - Keyboard (`rrKeys` builds it once and syncs it in place, `rrKeyFill` colours a key the moment its tile flips). `RR.ks` tracks the shown states.
    - Physical keys flash their on-screen key (`rrKeyFlash`).
    - Absent letters are gray, per the concept legend.
    - Enter submits whenever letters are typed, even if a panel button has focus.
  - Placeholder: the active row has purple sockets (pulsing pseudo opacity), typed letters get gold borders, and the next slot has a spinning conic ring (`.rrring`), a bobbing gold chisel and a twinkle.
  - Tiles use Poppins 800 letters.
  - Keepers:
    - The day's host comes from `RRH_ROT` (Silas on 3 days in 7; otherwise Professor Nickels the goblin, Goldhoard the golden dragon archivist, Lorekeeper Rattles the skeleton, or Scribe Inkwell the octopus). Practice cycles through all five.
    - `rrHostStart(open|done)`, `rrHostReact` (cheer when warmth rises 0.15+, think otherwise, win cheer and loss sad held), `rrHostPower` (Silas's card vortex, the keepers point), and `rrHostSay` speech bubbles from `RRH_LINES`.
    - Silas's poses peak at k = 0.5 and return to idle at k = 1; `rrHostDraw` holds sad at 0.5 and loops the win cheer twice. The keepers hold their poses at k = 1. The dragon is drawn at 0.9 scale so his wings fit.
  - Silas (`92f`) is by the art agent: `silasDraw(g,t,{mode,k,heat,look})`, about 1 ms per frame.
  - Keepers (`92g`) wrap `wcCrewDraw`/`wcCrewTop` for keeper objects only, adding `WCSP.rrkdrg`; the casino characters render pixel-identically. The dragon takes about 2.2 ms per frame.
  - The home card's mini runestone uses the new tile colours, Poppins letters and glowing side runes.
  - Narrow and touch layouts: the keeper becomes a small row with the bubble beside it, then come the stone, keyboard, powers and panel. On phones (`rr-tiny`) the title is 40 px.
  - `.rr` uses `overflow:clip` so the torch glows can't cause sideways scrolling. Corner ornaments use the classes `o1`–`o4` because a global `.tr` class exists.
- **Runestone Riddle 8.4c: music, rune sounds, richer arch and sanctum, menu detail, epic Silas (`92i_riddle_audio.js`, `92j_riddle_arch2.js`, `92k_riddle_menu2.js`, new `92f`):**
  - Build order after `92h`: `92i` (audio), `92j` (arch and backdrop), `92k` (menu detail).
  - Music (`92i`, by the audio agent): "The Riddler's Study", F major, 120 bpm, 36 bars (about 72 s a loop), with instruments swapped every other loop. Practice gets a calmer 100 bpm harp version.
    - Warmth layers: sparkle arpeggio at 0.4+, whistled descant at 0.7+, tambourine on every beat at 0.85+. Win fanfare and loss wah-wah duck the track.
    - It hands over with `mg` like the fishing music: `rraPump` runs from the game's `note` tick, so it starts once the game's audio is running (any click). Volume follows `ST.mute`/`ST.mvol`.
    - Sounds: the old riddle beeps are gated while `rrType/rrDel/rrEnter/rrFinish/rrUse` run. Tile chimes hang off `rrHeatPulse`, arch-rune tings off `rrHeatSet` (`rraTings`), and `rrResonate` is replaced. Effects go through `sg`. `RRAX.on=0` restores the old sounds. `rraStats()` reports live voices.
  - Arch (`92j`) redeclares `rrArchBake`/`rrArchLive`: bevelled blocks, gold-moulded recess, rune plates, carved channels that fill with light and carry pulses, a faceted keystone gem, crystal finials, ember trails and a gold sheen on a win.
    - A rune crossing lit 0.9 throws a ring and sparks (`rrRuneWake`, silent when `RRAX.on`, since `92i` plays the tings).
    - `rrBgPaint` adds a rose window with light shafts, bookshelf arches, banners, pillars, candelabra (bottom left, clear of the keeper name), potion shelf, rug and book piles.
    - Live extras: 6 DOM floating candles (`.rrfloat`) and a floor rune ring canvas (`.rrring2`, opacity from `--rheat`). Both are hidden in narrow layouts.
  - Menu (`92k`): `#rrmu` music button beside the coin chip (both in `.rrhr`; it clicks `#mt`, so the setting is shared). Also a crest gem and gold filigree on the panels, a twinkling star and underline on the title, and a light sweep on View calendar (`overflow:clip`).
  - Silas (`92f`, by the art agent): masquerade mask on a stick, gilded coat, rune circle under him. In his ability he puts the mask on, and his eyes and the circle blaze. About 1.0 to 1.4 ms per frame.
  - Cost: the arch draws in about 0.6 ms a frame when hot (was 0.2). Music adds about 2 to 3 ms of audio work per second, with no measurable frame change.
  - Tests: `t_riddle.py` has 43 checks (the new one covers the music button, candles, ring and coin chip). The overlap checker skips `.rrfloat,.rrring2,.rrcrest,.rrfili,.rrtstar`. `rr/mus.py` checks music start, mute and stop.
- **Update 8.4: Runestone Riddle replaces the Daily Challenge (`92a_riddle_words.js`, `92b_riddle.js`, `92c_riddle_style.js`, `92d_riddle_hooks.js`, `92e_update84.js`, after `91c_rainbow_fx.js`):**
  - Words (`92a`): `RR_ANS` holds 1,293 curated answers (common and school-friendly, plus fantasy words). `RR_OK` holds about 16,000 accepted guesses (the public-domain dwyl list plus the answers). `rrValid(w)` checks a guess.
  - The daily word is `rrWord(rrKey())`: a seeded order (mulberry32, seed 8403) over the answers, indexed by days since 22 Oct 2026, which is riddle #1. The same local date gives the same word for everyone. Earlier dates show "Preview".
  - Rules and payouts (`92b`):
    - Six tries. `rrScore` handles repeated letters the way Wordle does.
    - Payout ladder `RR_PAY` = 1500/900/500/300/180/120. A failed riddle pays `RR_FAIL` = 25.
    - Each rune power used trims the payout by `RR_CUT` = 15%. Reveal costs 100 coins (a ghost letter in its slot); Shatter costs 60 (three wrong letters greyed out). Each power works once per riddle.
    - Streak: `RR_BONUS7` = +500 on every 7th day in a row. The Riddlemaster title comes at 30 days: it is pushed onto `BT_TITLES` at price 1e9 and granted via `BTY().own['t:riddlemaster']`; the exchange shows "Earn: 30-day riddle streak" instead of a buy button.
    - Practice riddles (`P.rr.pr`) use a random word, pay no coins, make powers free, and never touch the daily streak.
  - Save data is `P.rr`; the field layout is in the 92b header. The board persists between visits, so leaving never rerolls a riddle.
  - Hooks (`92d`):
    - `dcMenu` now opens the riddle. The old one-attempt Daily Challenge is unreachable, but `P.dc` is untouched.
    - The home card is re-rendered after `title()`: `dkDailyLive` is replaced with a runestone canvas, the label/chip text changes, and there is a NEW badge until the first visit (`P.rr.seen84`).
    - The Choose mode card is patched after `modeSheet`.
    - The bell alert is replaced in `alertList`.
    - The "daily" bounty now reads "Solve today's Runestone Riddle" and is credited on a daily solve.
    - The corner Casino/Music/Fullscreen buttons are hidden on the riddle screen (`#cn.dkhid`); `dkCorner()` runs on leaving.
  - Layout:
    - The game draws on a scaled 1600x900 stage, and touch mode can resize the overlay. So `rrFit()` sizes from `ov.clientWidth/Height`: it sets `--t` (tile) and `--k` (key) and the classes `rr-narrow` (<1100), `rr-tiny` (<700) and `rr-short` (<860).
    - Do not use vw/vh or viewport media queries here.
    - Coin flight and the spark canvas use `rrLoc()` to get stage-local coordinates.
    - Narrow screens order the parts as stone, keyboard, powers, legend, panel.
  - Watch for class-name clashes: the overlay class is `rrx` (the close button is `rrxb`), and the board-swap animation is `rrswap`. `.rrsw` is the legend swatch.
  - 8.4 notice (`92e`), pushed at the owner's request: the `u-8.4` Updates entry is dated 22 Oct 2026 and has a 900x1298 WebP collage. Code `RUNESTONE84` (once per save) gives 2,500 coins and 3 Rune Charms (`P.rr.free`; each makes one daily power free, and the payout trim still applies). No News card.
  - Tests: `t_riddle.py` (with `t_riddle_ovl.js`, the overlap/clip sweep) is the first entry in `lbt/regress.sh`.
  - Fixes from the independent QA pass:
    - Each visit pins its date in `RR.key`, so a guess that finishes after midnight still counts for its own day. `rrTick` only rolls over to the new day when nothing is in progress.
    - `RR.busy` stays set until the result card shows, so a tab switch can't show the wrong riddle.
    - Letters typed during a flip go into the next row.
    - Tabs blur after a click, so physical Enter keeps working.
    - Toasts move into the result card while it is open.
    - The coin flight is skipped if the card is already closed.
    - The header coins count up (`data-v`).
    - Tiles and keys have aria-labels with their state, and the result dialog traps focus.
    - On a phone the overlay is shown at about 0.6 scale and `body.tm p{font-size:20px}` applies, so the `#rr p.*` rules pin the riddle's sizes and `#rr.rr-tiny` enlarges text and keys.
    - The result card is placed at `ov.scrollTop` with the overlay height, and `#ov.rrlock` stops scrolling while it is open.
    - Practice words skip today's word and the next 366 daily words, and avoid the last 60 practice words (`P.rr.pr.rec`).
- **Endless payout cut, rainbow shiny FX, creel refresh fix:**
  - Endless gold: `EGK` in `50_game.js` went from 1.5 to 0.9 (40% less kill and round gold in Endless). The Graveyard keeps its old base through `EGK_GY=1.5` (times `GYK`), and Beginner still uses `BG_GOLD`. The round-gold float now shows the same multiplier the payout uses.
  - Rainbow shinies (`91c_rainbow_fx.js`, after `91b_sig_weapons.js`). It wraps `drawEnemy`, `shinyFx`, `rainbowMake` and `drawFxList`, and replaces `rainbowCaught` with the same payout.
    - Behind the monster: spectrum sunburst rays, a conic prism ring at the feet and the far half of an orbit of comet motes.
    - In front: the near half of the orbit, rising prism stars and a faceted rainbow gem above the word bubble.
    - Arrival: prism rings and a flare (`S.rbx`, kind `arr`).
    - Kill: a prism light beam, three conic shockwaves, spinning shards and a springy per-letter "RAINBOW!" title with "+1,000 coins" (kind `boom`).
    - Canvas only: no `ctx.filter` or `shadowBlur`, and `createConicGradient` falls back to plain colours. Reduced motion: no shake, fewer shards, slower orbit.
  - Creel tab (`90u_fish_polish.js`): `fsHudRefresh` re-renders the Creel tab when its contents changed (`fsCrSig`), keeping the scroll position. Kept fish now show without a refresh. Tested in `t_fishing.py`.

- **Moonlit Fishing update 5: Mythic rarity, 15 new fish, rod looks, quick sell, menu performance (new `90c6_fish_art6.js`, `90c7_fish_art7.js`, `90c8_fish_mythic.js`, `90c9_fish_art9.js`, `90h3_rod_skins.js`, `90p_mythic_fx.js`; edits in `90a`/`90e`/`90f`/`90h`/`90i`/`90k1`/`90m`/`90n`; backups `*.u5bak`):**
  - **Mythic rarity (`FSR.m`, colour `#ff5ad8`):** 4 words, 2 line hearts, a 7.6 s catch show, base odds 0.125% (about 1 in 800) at a spot that has a Mythic, and 0% elsewhere. `fsOdds(lure,moon,loc)` takes the spot; `fsRoll` falls back to Common if a spot has no fish of the rolled rarity. The full moon and the Lure help a little (`luck` at 30%). Stats count `s.myth`.
    - Two Mythics: `seraph` (Seraph of Everwinter, Frostfall Lake, 900 base) and `eclipse` (Eclipse Leviathan, Glowcap Grotto, 1050 base). They are never the featured fish, never jump on the hub, and the pond never rolls them.
    - Journal and pond bestiary: an undiscovered Mythic shows its shadow with a glowing "?" and "Only at <spot>" instead of "Undiscovered". The Mythic tab and collection row were added, and the collection box was tightened to fit five rows.
    - Spectacle (`90p_mythic_fx.js`): wraps `fsShowFx` for Mythic catches and provides `fsMythicView(V,el,d)` (called from the show state in `90e`) and the `m1` sound. Reduced motion gives a calm version. The hint texts in the journal and the hub preview know about Mythics.
  - **15 new fish:** Pond: Honeycomb Goby, Mossy Mudskipper (C), Knightfin Perch, Emberwing Lionfish (R), Starfall Arowana (L). Frostfall: Icicle Herring, Snowball Sculpin (C), Frost Narwhalfin (R), Frostjaw Colossus (L), Seraph (M). Grotto: Puffshroom Loach (C), Geode Grouper, Phantom Lanternshark (R), Runefin Coelacanth (L), Eclipse Leviathan (M). Totals: 45 fish; pond 29, frost 14, grotto 15.
  - **Rod looks (`90h3_rod_skins.js`):** the tier still sets the rod's form; a non-default look now sets the material colours (`fsRodLook(sk)`) and draws its own signature details and a small animation (ember lava cracks and a flame tip, frost rime and icicles, moonreed moon-phase inlays and a charm, abyss tentacle and runes with a blinking eye, sun engraved emblems and a sunstone, aurora ribbons and curtains). Willow and the locked placeholder draw pixel-identically to before.
  - **Quick sell:** on the catch preview, Enter shows a confirm bar (`fsQsOn`/`fsQsOff`, `#fsqs`) with the price and a warning when the fish is worth keeping; a second Enter (or the Sell button) sells; Esc or Cancel closes it. Space, S and K behave as before. The preview shows a key hint line.
  - **Main menu performance (`90m`):** the hub scene is no longer copied through a full-screen mirror canvas every frame. It draws directly and the canvas element is flipped with CSS; everything drawn after the scene uses a counter-flip transform. The scene loop runs at 30 fps (`slow:2`) and drops to 20 fps if frames average over 7 ms; the small icon canvases are staggered at lower rates. Frostfall's aurora blit is cropped to its painted area and its snowfall uses 100 flakes (was 170). Measured in headless Chromium: pond hub 14–20 fps before, 26–33 after; Frostfall hub 16–17 before, 21–31 after.
  - **Pet on the dock:** `fsHeroSit` now stands the pet on the planks (x+128) with a contact shadow; hovering pets float above their shadow. The jumping fish on the hub now leap away from the hero instead of across the rod.
  - **Side panel:** the six rarity chips wrap onto two rows.
  - Balance (`fish/sim/sim.js`, now counts Mythics): at 45 WPM, Frostfall pays about 102 / 117 / 151 gold/min with rods 000 / 222 / 555 and the Grotto 109 / 125 / 159; Mythics come about 0.5–0.85 per hour at their spot.
  - Tests: `t_fishing.py` (backup `.v5bak`) covers 45 fish drawn, Mythic odds per spot (and none at the pond), the journal "?" card, and the quick-sell confirm flow.
- **Moonlit Fishing update 6: creel tiers, realistic daily bounties, baits, Trophy Hall, Mythic badges, Frostfall/Grotto performance (new `90q_fish_u6art.js`, `90r_fish_u6.js`; `FSCREEL` uses replaced by `fsCreelCap()` in `90a`/`90e`/`90f`/`90i`/`90m`; backups `*.u6bak`):**
  - **Creel tiers (`FSCRT`, save `P.fish.crl`):** Wicker 30 → Sturdy 40 (350 gold) → Frostkeeper 55 (1,000) → Enchanted 75 (2,500) → Moonlit Treasure 100 (6,000).
    - Perks: sort tools (Sturdy); rarity filters and +5% value (Frostkeeper); +10% and "Sell extras" (Enchanted: keeps the most valuable fish of each species, rod-look fish and anything Rare or better); +15% and bait crafting needs one fewer fish (Moonlit Treasure).
    - The value bonus applies only to fish sold from the basket. Stored entries carry `kp:1`; old entries are marked the first time they're valued. `fsKeep` is redeclared in `90r` (it adds `kp` and `t`).
    - The Creel tab (`fsCreelHTML`, redeclared) shows the tier's basket art, a capacity bar, an Upgrade button, sort/filter chips and Sell extras. The hub tile adds the tier name.
  - **Daily bounties (`P.fish.bty`):** three requests a day (Easy / Medium / Hard, target about 3.5 / 6.5 / 11 minutes), generated once per day from a seeded RNG and stored.
    - Sizing uses a pace model (`fsPace`):
      - catches per minute, measured from `s.ft`/`s.lc` after 5 minutes of fishing (default 4.2);
      - landed/escaped counts per rarity (`s.rs`; defaults c .96, u .92, r .6, l .35, m .25);
      - the odds at each open spot (`fsShareAt`).
    - Each candidate's expected minutes must fall within 0.55–1.5× the target. Rewards are `16 × minutes + 20` (rounded to 5). Finishing all three pays a board bonus of 100 plus 25 per streak day, up to 200. One free swap a day.
    - Kinds: a Common/Uncommon species (counts anywhere; the hint names its best spot), N fish of a rarity or rarer, N fish at a spot, N big fish (top quarter of their size range), a catch streak, and total value of fish landed (sold or kept).
    - Realism rules found with the simulator `fish/u6/btysim.py`:
      - every count is at least 2, and species above Easy at least 3;
      - never a Giant or any single rare event;
      - Rare requests only after the player has shown they can land Rares;
      - streak requests only once the player's own escape rate is measured (20+ Common bites), aimed at 0.7× the target, at most 12.
    - Simulated real time vs the shown estimate (40 days × 6 typist profiles): median 0.7–1.0×, 90th percentile within about 1.4×.
    - UI: a strip on the menu under Tonight, the Tavern Bounty Board modal (`fsBountyModal`, key O on the menu), and a collapsible tracker in the pond. Completion news shows as a banner once the catch is dealt with (`fsSet('idle')` hook).
  - **Baits (`FSBAIT`, save `P.fish.bait`):** one bait is used up per cast while equipped (`fsRoll` wrapper; `fsOdds` multiplies by `FSBAITM` during the roll).
    - Glow Worms (Uncommon ×1.6, 30 gold for 10 casts, craft from 4 Commons).
    - Moonmoth Lure (Rare ×2, 90 for 10, 3 Uncommons).
    - Starlight Roe (Legendary ×2.5 and Mythic ×2, 300 for 8, 3 Rares).
    - Frost Shrimp and Glowcap Spores: that spot's own fish ×2.5 against visitors, 45 for 10, from 3 native fish. They work only at their spot.
    - Crafting never uses fish saved for rod looks.
    - Bait Pouch modal: the B key in the pond and on the menu. A bait chip sits above the rod chip in the pond.
  - **Trophy Hall (`fsTrophy`, view `fishtrophy`; replaces the menu's Stats tile, key T):**
    - Trophy Wall: 8 mounts (`P.fish.tro`) showing each species' record, a picker, and "Fill empty mounts with my best".
    - Achievements: 19 (`FSACH`, claimed in `P.fish.ach`, about 6,000 gold in total).
    - Records: all stats plus bounties, bait and creel, and the biggest catch of each rarity relative to its species' range. The pond side panel still has its Stats tab.
  - **Fishing Spots:** Frostfall and the Grotto cards show a "1 Mythic here" medallion (the Mythic's silhouette with a pulsing "?" until caught). The bottom panel names it, or "Unknown Mythic", with "Roughly 1 in 800 casts here" or "Caught ×N · it can bite again" (wrappers on `fsdgCard`/`fsdgPanel`).
  - **Frostfall / Grotto performance (`90k1`, `90k2`; backups `.u6bak`, agent backups `.p6bak` in `perf/src`):**
    - Frostfall's aurora is a pre-baked 20 s loop of 12 keyframes, built lazily (two on the first frame, then one per frame; the source canvases are freed afterwards, about +15 MB in total). Each frame crossfades two of them; the keyframes already include the still sky and are cut to the skyline. Wave speeds are whole multiples of the loop.
    - The reflection strips no longer use a clip; a one-time cut-out of the pier and lantern pixels is drawn on top.
    - Lantern, window, moon and mushroom glows are pre-rendered at the sizes they are drawn (5 sizes for the flicker) and copied 1:1 instead of stretched.
    - `fsThumb` (in `90f`) caches still thumbnails per fish, size and silhouette colour. The 45-card bestiary redraw on every catch reveal took about 140 ms; it is now a copy.
    - Measured (headless software Chromium):
      - Frostfall back layer, forced to finish: 7.0 / 14.6 / 25.3 ms (avg / p95 / max) → 3.3 / 4.3 / 7.5. The periodic aurora re-render spikes are gone.
      - Grotto back layer: 2.9 → 1.9 ms avg.
      - Pond loop cost in gameplay: Frostfall 5.3 / 12.7 → about 1.3 / 2.0 ms.
      - Worst frame during a whole cast-to-reveal: 300–400 ms → about 83 ms at all three spots (`fish/playperf.py`).
  - Tests: `t_fishing.py` (backup `.v6bak`) adds 17 update-6 checks: creel tiers and the value bonus, sell extras, bait odds and use, spot bait, crafting, bounty sizing/completion/bonus/swap, a 60-day bounty sweep, the menu strip and tiles, the bounty board, the Trophy Hall (fill, claim, Esc), the spot badges and the pond HUD.
- **Developer tools: more cheats (`86c_devcheats.js`, after `86b_codes.js`).** DEV › Cheats gains these sections:
  - **Player:** set level 1–30 (`P.xp=lvx(l)`), prestige 0–10 (grants the prestige armours), class (raises the level if the class is still locked).
  - **Skill tree:** +5 / +25 points (`P.spb`), max the whole tree for free, reset with all points refunded, set any node's rank.
  - **Weapons & armor:** give, or give and equip, any of the 94 weapons (grouped by class; equipping switches class) and 51 armours; set weapon mastery tier 0–5, or tier 5 on every weapon; reset to starter gear.
  - **Campaign:** set the unlocked level, 3 stars on all 30 levels, reset stars.
  - **Pets:** give one or all, set bond level 1–10, +1 egg of each rarity.
  - **Moonlit Fishing:** all fish, max rod, max creel, all rod looks, unlock the cove, +10 of each bait, new bounties.
  - **Wildcard:** all card backs.
  - Each action saves, re-syncs the class and weapon, and refreshes the home screen.
- **Moonlit Fishing update 7: odd catches, the bottle story and the secret Lighthouse Cove, 5 new fish (50 in total), a soundtrack, an art review, new cast/catch animations, an easier bait system, a calmer menu (new `90c10_fish_art10.js`, `90k3_loc_cove.js`, `90s2_odd_art.js`, `90s_fish_odd.js`, `90t_fish_music.js`, `90u_fish_polish.js`; edits in `90a`, `90c`–`90c9`, `90d`, `90e`, `90h`, `90l3`, `90p`, `90r`; backups `*.u7bak`):**
  - **Data (`90a`):**
    - 5 cove fish: `sprat` Lamplight Sprat (C), `blenny` Barnacle Blenny (C), `wreckfin` Wreckfin Scorpionfish (U), `seahorse` Lighthouse Seahorse (R) and `wraith` Lanternwraith (M).
    - `FSLOCS.cove` (`secret:1`).
    - `FSPOOL.cove`, 12 fish: the 5 new ones plus lant, twilight, glass, angler, ray, tidecrown and moonmaw.
    - Totals: 50 fish; pond 29, frost 14, grotto 15, cove 12.
  - **Odd catches (`90s`):**
    - Rates: boot 1 in 80 casts, bottle 1 in 120, chest 1 in 250, ring 1 in 600 (`FSODD`, `FSODDSCALE` scales them all). Never in the first 8 casts or during the tutorial.
    - Each item has a `FISH['odd'+k]` entry, not in `FIDS`, and art in `FISHART` from `90s2`, so the normal catch pipeline draws it.
    - `fsRecord` skips them: no bestiary, stats or bounty counts.
    - They reel in with words from a treasure list (`FSODDW`), and a "Something's on the line… not a fish!" bubble appears by the bobber.
    - After the show, `fsReveal` switches to state `odd`. `fsOddGive` applies the reward and `fsOddCard` shows the card; Space, Enter or Collect closes it.
    - Rewards:
      - boot: 1 gold; 10 boots earn the title "Bootlegger";
      - bottle: the next of 4 story pages (`FSPAGES`, the lighthouse keeper's log; `FSPGN`); once all 4 are found, a keeper's note (`FSNOTES`) and 40 gold. While pages are missing, bottles bite 1 in 50 casts (`FSBOTP`), and one is guaranteed after 80 casts without one (`FSBOTPITY`, `P.fish.odd.dry`). That is about 160 casts (30–35 minutes) to find the cove;
      - chest: 80–200 gold, a crate of 10 bait plus 30 gold, or 6 Starlight Roe plus 50 gold;
      - ring: belongs to one of 6 owners (`FSRINGS`) and is returned at the Tavern Bounty Board's Lost & Found for 250–400 gold plus a bait gift; after all 6, a ring sells for 250.
    - Save: `P.fish.odd`.
    - 4 achievements were added: Bootlegger, Message Received, Good Samaritan, Treasure Hunter.
    - The Trophy Hall has a new Curios tab: read the pages, and see odd-catch counts and the title.
  - **Lighthouse Cove:**
    - It opens with the 4th page (it was 8 pages at 1 in 120 casts, about 3 hours; that was made easier). `fsLocOpen` is redeclared in `90s`: secret spots open on pages, other spots on species.
    - Fishing Spots now shows 5 cards. The secret card is a dark, foggy "?" with page progress until the cove is found.
    - The Angler's Journal spot chips use short names (All spots / Pond / Frostfall / Grotto / Cove, full name on hover) and never wrap (`90n`).
    - Scene (`90k3`, `FSLOCART.cove`): the old Stormreach lighthouse on a headland with the keeper's ghostly lamp and sweeping beams, a golden lamp path on the water, a shipwreck bow, a weathered pier, fog, a crescent moon and a bobbing bottle. It follows the Frost/Grotto performance patterns: about 3.5 ms flushed, no spikes. The gallery crop is `FSDGCROP.cove`.
  - **Music (`90t`):**
    - The fishing views get their own live-synthesised score. The menu views alternate "Fisherman's Shanty" (G major 6/8) and "Moonlit Night" (D minor).
    - One track per spot:
      - Pond: D major 3/4 folk with harp, lute and flute;
      - Frostfall: E Lydian celesta, music box and glass pads;
      - Grotto: F# minor marimba and echoing kalimba;
      - Cove: C minor 6/8 cello drone, whistle, foghorn and ship's bell.
    - How it fits in:
      - it wraps `note()` (the normal score stays silent while fishing), `show()` and `applyVol()`;
      - views and spots crossfade over 1.2 s, and the hidden tab pauses;
      - the Music volume and mute apply;
      - all tracks sit near −18.5 LUFS, with no clipping.
    - `fm7Want()` returns the wanted track.
  - **Art review (`90c`–`90c9`):**
    - All 45 older fish were checked (critique in `fish/u7review/REVIEW.md`). Moonmaw, Tidecrown, Snowdrift Smelt and Puffshroom Loach were redesigned or recoloured to be distinct.
    - Silhouettes skip glows, so journal shadows are crisp.
    - The Mythics keep their glow when discovered, blinks draw a closed-eye crease, and 6 fish were pulled inside the frame.
  - **Animations (`90e`, `90d`, `90h`, `90p`):**
    - Rod, bend and lean follow springs, with a flexing tip.
    - The cast has a wind-up, a whip and a real parabola; landings get a droplet crown with staggered ripples.
    - Nibbles and the bite tug the rod and hook-set it.
    - The bobber is reeled closer as you type, and the fish breaches on the line between words.
    - The catch show is one shared fish pose with a leap, hold, unhook and a glide into the panel.
    - The legendary show is painted above the dim.
    - The escape snaps the line with recoiling ropes and the fish leaps away.
    - `fsArt(c)` and `fsNm(c)` handle odd catches.
    - Timings, odds and word limits are unchanged; reduced motion gets calm versions.
  - **Bait (`90u`):**
    - The pond's bait chip, or the B key, opens a quick picker: 1–5 to pick, 0 for none.
    - The Bait Pouch is now 5 clear cards. Each shows the effect chip, "Best for", and the odds change at this spot ("Rare 5% → 10%"). One bait is suggested from the current spot, open bounties and missing species. Buy or craft also puts that bait in use.
    - The bait button left the menu.
  - **Update 8.3 notice (`90v_update83.js`):** pushed at the owner's request. It's an Updates (bell) entry "8.3 Moonlit Fishing is OUT!" with a 900x1022 WebP collage (menu, a Mythic show, the cove, the spots map, a bottle page, the journal, the Trophy Hall and the Bait Pouch). The code `MOONLURE83` (2,500 coins and 10 casts of Starlight Roe, once per save) is hidden at the end of the notes and highlighted in the bell. There is no News card.
  - **Update 8 balance:** sale values are x1.15 (`FSPAY` in `fsValue`, `90a`), and Mythic base odds are 0.3125% (about 1 in 320 casts at its spot, was 1 in 800; `FSR.m.o`). Sim at 45 WPM: pond 102 / 124 / 156 gold/min (rods 000 / 222 / 555), Frostfall 132 / 148 / 199, Grotto 138 / 161 / 208; Mythics 1.3–2.2 per hour at their spot. A Mythic is now more likely per cast than the whole Legendary tier (0.25%).
  - **Catch preview keep reason (`90u`, redeclared `fsKeepWhy`):** a rod look it helps craft comes first, as "for the Abyssal rod (1/2)" (the rod closest to finished, plus "+N more"). This applies while "Save fish I need for rod looks" is on, or always for Rare+ fish. Otherwise the reason is the rarity ("Rare catch"), then "New species!", then "Giant!".
  - **Menu (`90u`):**
    - The bounty strip is now one slim notice with progress pips.
    - The moon's line is a welcoming tagline.
    - The Fishing Spots sign counts the secret spot only once it is found.
- **Wildcard fixes (`89m`, `89c`, `89y6`, `89y0`, `77`; backups `.u7bak`):**
  - The top seat's hand of card backs sat on the draw and discard piles. The fan now sits beside its avatar, clear of the piles at any hand size, and deals and draws fly to it. Draws that cross the discard pile lob over it.
  - Touch mode now fits Wildcard screens.
  - Card-back pre-rendering:
    - it now encodes in a worker, with a main-thread fallback;
    - on slow machines it draws in bands;
    - it waits for the menu's entrance animation.
    This removed the long freezes (12 tasks over 50 ms at 4x throttle → 0).
  - The casino reverb is built about twice as fast.
  - **Join panel:** the squashed "Join ›" button is fixed (`89m`).
- **Dragon Casino lobby smoothness (`66d_cscene.js`, `88l_perf_casino.js`, `77_casinomusic.js`; backups `.u7bak`):**
  - The dragon scene's layers are pre-drawn one per idle slice, from 1.2 s after load, while on the title screen.
  - The eye's inner shadow is cached instead of using a per-frame `shadowBlur`.
  - The hidden title canvas isn't redrawn under Casino screens.
  - The Casino button shine animates a transform.
  - The casino reverb is pre-built in idle slices.
  - Results: click handler 92 → 14 ms (1x) and 350 → 50 ms (4x throttle); longest task in the first 2 s 299 → 25 ms (4x); idling on the lobby 30 → 60 fps headless.
  - Known leftovers:
    - clicking Casino within about 3 s of page load still builds the layers on the click;
    - `czglow`/`twtabg` in `00_head.html` still animate box-shadow on small elements.
- **Fishing Spots destination gallery (`90l3_fish_spots.js`, Stormreach art `90l2_storm_art.js`; comment update in `90l`; backups `build*.sh.u4bak`, `t_fishing.py.v4bak`):**
  - `fsMap(back)` is redeclared (the later declaration wins) and keeps the same entry points: the hub signpost/kicker, the M key and the pond HUD title. The old map's `fsMapPaint` is no longer called.
  - **Layout:**
    - Header: title, "Choose your next fishing spot", and global species logged from `fsFound()` (unique species, not a sum of spots).
    - A "Currently fishing" pill, plus the coins and Back.
    - Four cards and one bottom panel.
  - **Card art (`fsdgArt`):**
    - Crops of each spot's real scene (`FSDGCROP`, drawn once with `fsScene(...,{noHero,loc})` and cached).
    - Stormreach uses `fsStormArt`.
    - Each card adds light per-frame touches (`fsdgFx`): lantern flicker, aurora and snow, spores and waterfall, `fsStormFx`. These freeze under reduced motion.
  - **States:**
    - Current spot (`fsLoc()`): cyan "Current location" ribbon.
    - Previewed card (`FSDG.sel`, temporary UI state, never saved): gold outline, plus a "Selected" ribbon when it isn't also the current spot.
    - Locked (progression, real `L.need`): Locked banner and "Discover N species to unlock" with progress.
    - Coming soon (`L.soon`): hourglass banner, no counts.
  - **Bottom panel (`fsdgPanel`):**
    - Thumbnail, name, description and "x of y species discovered" with an exact bar.
    - One action: Fish here / Continue fishing / Coming soon (disabled) / Locked (disabled).
    - `fsdgGo` re-validates `fsLocOpen`, travels with `fsTravel` (unless already there), enters `fsPond()`, and ignores repeat clicks (`FSDG.busy`).
  - **Input:**
    - Cards are buttons: a click, tap, Enter or Space previews.
    - Arrow keys preview the next or previous card.
    - Esc uses `S.back`.
    - Focus moves to the selected card only for keyboard players (`FSDG.kb`).
  - **Fit (`fsdgFit`, from the on-screen size of `#fsx`):** four across normally; 2×2 with larger type in a scroll area under k<0.62; one column with art beside the text under k<0.4. The panel always stays below the scroll area.
  - **Touch mode fix (all fishing screens):**
    - `touchLayout` moves `#ov` out of the scaled stage and zooms it to a ~1000px box, so the 1600×900 fishing screens spilled off-screen.
    - `fsFitTM()` now scales `.fsx` to fit in touch mode. It wraps `show` and `applyLayout`.
    - Known limitation: the on-screen keyboard (`kbWant`) still only appears in `S.mode==='play'`, so touch players can't type to reel fish in.
  - Tests: `t_fishing.py` covers opening on the current spot, preview vs travel, exact bars, coming soon and locked, arrows and Enter, Esc, single travel on repeated clicks, no loop pile-up, and Continue fishing. Touch and reduced motion are checked by `fish/touchrm.py` and `fish/tm.py`.
- **Moonlit Fishing v3 (new `90k1_loc_frost.js`, `90k2_loc_grotto.js`, `90c4_fish_art4.js`, `90c5_fish_art5.js`, `90h2_rod_fx.js`, `90l_fish_locs_ui.js`, `90m_fish_menu.js`, `90n_fish_journal2.js`, `90o_fish_workshop2.js`; edits in `90a`/`90d`/`90e`/`90f`/`90g`/`90h`; backups `*.u3bak`/`*.v1bak`):**
  - **Fishing spots (`90a` data, `90d` scene hook, `90l` UI):**
    - `FSLOCS` lists Tavern Pond (open), Frostfall Lake (10 species), Glowcap Grotto (18 species) and Stormreach Coast (coming soon). `FSPOOL[k]` holds each spot's fish; `FISH[i].at` lists the spots for a fish.
    - `fsLoc()` returns the current spot (`P.fish.loc`, falls back to the pond if locked). `fsLocOpen(k)` and `fsTravel(k)`. `fsRoll` and the featured fish use the current pool.
    - Scenes: `FSLOCART[k]={bg,back,front}`. `fsScene` hands off to `fsSceneLoc` when `V.loc` (or the current spot) isn't the pond.
    - `fsMap(back)` is the world map (medallion thumbnails, "Fish here", locked progress). The pond HUD title shows the spot and opens the map when idle. A "New fishing spot!" banner appears when a spot unlocks (wraps `fsRecord`).
    - Map nodes use the class `fsmnode`: `fsmn` is already the pond HUD's moon line.
  - **Six new fish:** smelt, char, flyfish (Frostfall Lake) and tetra, cavefish, wyrm (Lumenwyrm, Legendary) at Glowcap Grotto. Same art contract as the originals.
  - **Main menu `fsHub()` (`90m`), styled after the concept:**
    - Spot kicker (opens the map), gold title with a shine sweep, and a Tonight card with the featured fish, chips and Go Fishing.
    - The scene is mirrored, with the hero seated on the dock (`fsHeroSit`), a crescent moon, and fish that jump now and then.
    - Four tiles with animated canvas icons (`fsIcon`) and a Fishing Spots signpost. Keys: M map, J journal, W workshop.
  - **Angler's Journal, field-guide edition (`90n`):**
    - Rarity tabs with counts and a spot filter. The 4-column grid shows 12 per page and adapts to 2–3 rows, with leaf placeholders.
    - Each fish has a painted underwater scene (`fsJScene`: pond / frost / grotto, cached, feathered edges), a "Found at" tag, a record banner with date, a size ruler with a marker, four stat cards, and Previous / n of m / Next.
    - It reassigns `fsJournal/fsJList/fsJGrid/fsJStep/fsJPage` (assignments, so it replaces the 90l wrappers).
  - **Rod Workshop (`90o`):**
    - A showcase bench (`fsRodShowcase` from `90h2`, preview any tier) and a rod-level track.
    - Upgrade cards with animated canvas icons (`fsUpArt`: spool, lure, hook; the ring turns bronze, silver, gold), Now ➜ Next chips, a worked example and a "Best value" tag.
    - Buying flies coins to the purse and pops the new pip. Keys 1/2/3 buy.
    - Rod looks are a swatch row plus one detail card. The pond side panel's Rod tab is a compact copy with an "Open the Rod Workshop" button.
  - **Rods:** the 5 tier models were redrawn (`90h`). `90h2_rod_fx.js` gives each tier its own idle aura, cast trail, reeling effect and catch flourish, and wraps `fsMotionFx`.
  - **Fixes:**
    - Common catch previews were broken by the global `.rc` roulette class; previews now use `fsr-*` and banners `fsb-*`.
    - Auto-sell now sells every Common/Uncommon except a first catch of a species and giants (`fsKeepWhy`). Optional "Save fish I need for rod looks" (`P.fish.look`).
    - `fsPond` is a `var` so 90l can wrap it.
    - Review pass (all fixed, with checks in `t_fishing.py`):
      - Kept fish store `ft` (featured when caught), so their price no longer changes with the spot.
      - With a full creel, Space and leaving never sell a fish worth keeping.
      - `fsMix` accepts 3-digit hex, and the Aurora tip is `#ffffff`.
      - Hub tiles refresh when the Basket/Stats modal is closed by its backdrop.
      - Hub and map canvases freeze under reduced motion.
      - The workshop returns to the pond when opened from it (`FSH.wback`).
      - The Rod tab buy buttons follow your gold.
      - Journal Previous from outside the filter picks the last fish.
      - The unlock notice waits until it can be shown (`fsUnlockShow`).
      - `fsStop` clears the how-to guide's input lock `FS.tut`.
  - **Balance (`fish/sim/sim.js`, now per spot):** at 45 WPM the pond pays about 91 / 105 / 139 gold/min with rods 000 / 222 / 555, Frostfall 88 / 103 / 131 and the Grotto 93 / 110 / 142. Legendaries come about 1.1–1.8 per hour everywhere.
  - Tests: `t_fishing.py` (backup `.v3bak`) covers the new hub tiles, the 12-per-page journal and tab counts, the workshop (tier preview), the side-panel Rod tab, the Common preview class, spot unlocks, travel, the map and the HUD spot name.
- **Moonlit Fishing v2 (`90h_fish_rods.js`, `90i_fish_hub.js`, `90j_fish_hub_style.js`, plus edits in `90a`/`90d`/`90e`/`90f`/`91`; backups `*.v1bak`):**
  - **Flow:** `fishing()` now opens the landing menu `fsHub()`.
    - The landing menu is the living pond backdrop drawn by `fsScene` with `V.noHero`, a title, tonight's moon card, Go Fishing (Space) and four tiles: Journal, Rod Workshop, Creel, Stats.
    - Go Fishing calls `fsPond()`, the original fishing screen. Back from the pond (`fsLeave`) returns to the landing menu; Esc there goes home.
  - **Angler's Journal `fsJournal(id)`:** a leather book. The left page is a 6×4 index with rarity bookmarks; the right page is the entry (portrait, lore, size ruler with the record and the giant zone, field notes). Arrow keys and the corner buttons turn the page (`.fsjflip`, a rotateY animation).
  - **Rod Workshop `fsWorkshop()`:** the rod drawn large on a bench, the 5 tier models, upgrade cards and rod looks.
  - **Rod models:** `fsRod(g,hx,hy,a,bend,len,t,skin,tier)` now draws 5 models (`fsTier()` from total level: 0/3/6/10/15). Rod looks tint the model. `FSTIERN` holds the names.
  - **Animations (`90e`):**
    - Cast: wind-up, whip and tip trail (`FS.trail`), the bobber flight (`FS.fly`) and a damped landing bob.
    - Bite: a yank and rod snap (`FS.biteT`).
    - Reeling: the line vibrates (`fsLine` `vib`), droplets run along the line, and the fish breaches between words (`FS.breach`).
    - Catch: water trail, a size stamp and the hero pulling back.
    - Escape: the line snaps (`FS.snap`).
  - **Ease of play:**
    - A how-to guide on the first visit (`P.fish.tut`), rotating tips under Cast, a next-letter caret and the prompt "Watch the bobber".
    - Esc twice to leave mid-fight.
    - A smarter default Keep: rare+, new, record, giant, or needed for a rod look.
    - Auto-sell (`P.fish.auto`), set from the catch preview or the Creel tab.
  - **Economy (owner chose "lower"):**
    - Simulated gold/min: about 80–96 with a basic rod, 97–112 mid-game and 123–144 maxed. Combat is about 150–200.
    - Upgrade total is about 29k; the max luck multiplier is ×1.5.
  - **Finishers v2 (`91`):**
    - A one-colour hero silhouette `pfxSil` for golden knight afterimages and violet rogue shadow clones.
    - Knight: ground cracks and a light pillar. Archer: a leaf vortex, a sky-high volley and target runes. Mage: a ground rune circle, lightning and a rune blast. Rogue: smoke puffs.
- **Moonlit Fishing (new mode; modules `90a`–`90g`, after `89y6`):**
  - **Where it lives:** a NEW card on the home screen (`fsHomeCard`, wraps `title`), the **F** key on the home screen, and Starfall Rift's spot in Choose a mode (`#dma`). Warden's Arena moved to a row under the cards (`#dmwa`). `fishing()` opens the pond; Esc / Back calls `fsLeave` (an undecided catch is kept or sold, never lost). `S.mode='fish'` while fishing.
  - **Data and economy (`90a_fish_data.js`):**
    - `FISH` has 24 species: 10 Common, 7 Uncommon, 4 Rare, 3 Legendary. `FSR` holds per-rarity odds, stages (Rare 2, Legendary 3), line hearts (Legendary 2, so one retry) and time per letter.
    - `fsRoll`, `fsValue` (size factor; giants ×2), `fsTime` (rarer means less time per letter; Line +8%/level), `fsWait`.
    - Rod upgrades `FSUP` (Line / Lure / Hook, 5 levels each, about 42k gold total). Rod looks `FSKIN` are crafted from kept fish. `fsMoon()` sets a daily moon phase and featured fish.
    - Save: `P.fish` = `{b: bestiary, cr: creel (cap 30), up, sk, skin, s: stats}`.
  - **Balance:** `../fish/sim/sim.js` loads the real data module and models typists by WPM.
    - Base rod: about 125–155 gold/min, below combat (about 200).
    - Max rod: about 240–310 gold/min.
    - About 1–2.7 Legendaries per hour; the full bestiary takes 2–4 h.
    - 20 WPM players need Line upgrades for Rare and Legendary fish.
  - **Art:** `90b_fish_art.js` is the kit (`fishDraw(g,id,o)`, `fishFit`, `fk*` helpers, silhouettes via `o.sil`). Fish are drawn in `90c_fish_art1.js` (Commons), `90c2_fish_art2.js` (mixed) and `90c3_fish_art3.js` (Rare/Legendary). Brief: `../fish/BRIEF.md`. Contact sheet: `cd ../fish && python3 render.py OUT.png ART.js[,ART2.js] [ids]`.
  - **Scene (`90d`):** one cached still layer (`FSBG`) plus live water shimmer, ripples, lotus, lanterns, reeds, fish shadows, willows and fireflies. The hero comes from `drawHero` with `wp:null` and a rod drawn from the hand (`fsRod`, `fsBobber`, `fsLine`).
  - **Game (`90e`):**
    - State machine `FS.st`: idle, cast, wait, reel/stage, show, reveal (or escape).
    - Catch spectacles scale by rarity in `fsShowFx`. Legendary adds a darkened sky, a pillar of light, aurora ribbons, god rays and gold rain, and can be skipped.
    - Keys go through a capture-phase `fsKeyDown`; touch keyboards use `beforeinput` on `inp`.
  - **UI (`90f`) and styles (`90g`):** side panel tabs Bestiary / Creel / Rod / Stats, the Catch preview with Sell/Keep (Space takes the default), and a fish detail modal.
  - **Tests:** `t_fishing.py`. Probes: `../fish/play.py HTML OUT [c u r l]` screenshots every phase.
- **Hero path finishers and signature weapons (`91_path_fx.js`, `91b_sig_weapons.js`):**
  - **Finishers:** Knight Final Verdict (leap and golden crescent slam), Archer Verdant Volley, Mage Arcane Beam, Rogue Shadow Flurry.
    - They play on Fury (smaller version) and on a boss finished with Space (big version, in the existing slow motion, with its name).
    - Finishing within 2 s of the boss being beaten gives a "Swift finish" bonus of 40 + tier×20 gold.
    - Hooks: wraps of `kill`, `fury`, `update` (remembers when the boss became beatable), `drawHeroGame` (moves the hero for the leap/blink) and `drawFxList` (draws the effects layer). Reduced motion turns off shake and movement.
  - **Signature weapons** (`SIGW`, `hw:1` keeps them out of crates and the shop): Dawnbreaker, Verdant Tempest, Astral Conduit, Nightwhisper.
    - Art is in `WNEW.sig_*`.
    - A Forge card sits at the top of the path's Armory list (`sigCard`, 15,000 gold). The weapon is also forged free after 3 boss finishers with that path (`P.sigf`).
  - **Tests:** `t_finishers.py`. Probe: `../fish/hero.py`.
- **Hand: no stacking glitch on fast sweeps; motion survives re-renders (`89y4_wc_hand.js`, backup `.bak3`):**
  - **Stacking:** the sink-on-top class `.wchz` is gone. A card you move off drops straight back to its own place in the stack (z-index = hand index), so only the hovered card (z 50) is ever out of order. Before, on a fast sweep to the left, each passed card stayed on top of its right-hand neighbour for 200 ms and then popped under it, so card edges seemed to glitch through the cards covering them.
  - **Re-render mid-motion:** `wcRenderHand` replaces every card element. The wrapper now records each card's current transform while it is still moving, and the progress of its draw-in and sheen animations (`WCH_CARRY`). The new card carries on from there instead of snapping.
  - **Reflow class:** `.wchfl` (springy FLIP glide) is now set per card, only on cards whose slot changed, and is removed when that card's hover changes. Hovering right after a sort or play keeps the normal quick timing.
  - **Probes (`../wv/`):**
    - `zprobe.py HTML` counts frames where two neighbouring resting cards are stacked out of hand order (old build: 531, now 0).
    - `jprobe.py HTML` finds frame-to-frame snaps when re-rendering during a sweep, a draw-in or a sort.
    - `lstrip.py HTML TAG` saves screenshots during a leftward sweep.
- **Hand: smooth fast sweeps, unplayable cards stay still (`89y4_wc_hand.js`, backups `.bak1`, `.bak2`):**
  - **Hover easing:** hover now uses a quick ease with no overshoot (the springy ease is kept for reflows).
  - **Sweeps:** while the pointer sweeps, only the card under it moves. Neighbours part and the sheen/tick play only after the pointer rests `WCHL_SETTLE` (110 ms) on one card.
  - **Unplayable cards (`.no`, your turn only):** they never lift, raise or lose their dark veil when hovered (CSS `.no.hv`, `wchS`, `wchUp`).
  - **Z-order:** (superseded: `.wchz` was removed in the entry above.)
  - **Hit-test:** `wchPick`'s hysteresis margin applies only to a raised card, so a flat card can't claim a strip its neighbour covers.
  - **Probe:** `../wv/sweep.py HTML`. Before: up to 2 cards moving at once and 19–42 bounces per sweep. After: 1 card and about 1–6.
- **Wildcard visual overhaul (five new modules after `89x`, in this order):**
  - **`89y0_wc_bkcore.js` (card-back pipeline, designer kit, vault showcase):**
    - Each back is a full standalone SVG document (`WCBKX[key]`). It is drawn once into a WebP bitmap in idle time (never while a table is on screen).
    - `wcBack(k)` returns a small `<svg class="wcbx">` wrapper holding that image, so heavy detail costs nothing per card.
    - The kit `WB` holds the frames, filigree, vector Pirata One lettering (`WB.word`; an image cannot use web fonts), guilloche, gems, rivets, damask and so on. Read the header before drawing a back, and run `WB.check(key)` on it.
    - The vault preview tilts under the pointer and has a light sweep; tiles have rarity rims.
    - It also holds the redrawn Lounge Velvet.
  - **`89y1_wc_backs.js`:** the other 14 backs, redrawn with far more detail and each keeping its theme.
    - The six Ranked sleeves share `BX.sleeve` (rank metal frame, element gems in the corners, WILDCARD plaques, rank emblem).
    - Each document is 19–52 kB.
  - **`89y4_wc_hand.js` (hand hover flicker fix and polish):**
    - Hand cards no longer take pointer events. The hovered card is picked from the cards' resting slots, with hysteresis, and marked `.hv`.
    - Because the hovered card no longer moves out from under the pointer, the hover can't flip back and forth.
    - The hand fans on an arc, neighbours part, and playable cards glow. Hands of more than 12 cards compress.
    - Use `.hv`, `wcHandLay` or `el.click()`; `elementFromPoint` never returns a hand card.
  - **`89y5_wc_table.js` (premium table):**
    - Felt texture, a leather rail with stitching and brass, the printed crest and lettering, a spotlight and vignette.
    - Variants: per-table leather colours for solo tables, blue for rooms, midnight and gold for Ranked (`rktbl`).
    - Brass-studded nameplates, rail medallions, a direction ring that rests clear of the piles, and a crest in the Menu.
  - **`89y6_wc_anim.js` (animations):** reassigns `wcFly`, `wcBurst`, `wcPop`, `wcShake`, `wcDeal2`, `wcWild2`, `wcRev2`, `wcSkip2` and wraps `wcAnim`.
    - Riffle shuffle and dealt arcs, flights with light trails, landing squash with element particles, a Stun lightning bolt, the wild colour wheel, a +2/+4 slam, stamp banners, and a win spotlight with confetti and coins.
    - Transform/opacity only; respects `wcRM()`.
  - **Tools:**
    - `../wv/bldx.sh OUT.html extra.js...` builds a separate copy without touching `out.html`.
    - `../wv/wcshots.py HTML OUTDIR [backs table hover anim menus perf]` takes screenshots and runs the hover-flicker probe (0 switches now; the bug measured 35) and a frame-time probe at 4x CPU throttle (within noise of the old build).
  - Built by a multi-agent workflow with critic reviews (table, framework, hand and animations); the 14 backs were drawn and checked directly.
- **Ranked: 1,000 points to Legend (was 500), back-loaded:** each rank has its own bar size, `WCRN[].need` = 110 (Bronze), 150, 200, 250, 290 (Diamond); helper `rkNeed(r)` (`89s`). `rkApply` ranks up at the need, `rkSt` clamps the bar below it, and every screen shows "/ need" (`rkPct` for bar widths in `89u`: hub, results animation, road, home pill, leaderboard). Each history entry stores its bar size `q`.
  - Leaderboard (`89w`): entries are now `v:2` with 5-number matches `[t,place,points,rank,q]`; the check accepts `q` = that rank's need, or the old 100 for season-1 matches before `RKLBQCUT` (1 Nov 2026), so players who climbed under the old bars stay on the board. The whole-season replay uses each match's own `q`.
- **Reset save fixed (`60_ui.js`, backup `.v12bak`):** the Profile "Reset save" button set `P=fresh()` directly, which skipped the pet and Trick-or-Treat setup that `load()` wrappers add, so the title screen threw (`petEggsN`). It now calls `load({})`. Also: the code-reward glow (`86b_codes.js`) could build an invalid colour on its first frame (clamped), and the countdown hides at once on a move (`wcApply` wrapper in `89x`).
- **Reset profile leaves the board (`89w`):** a `save` wrapper (`rkLbDevCheck`) remembers the key of the save this device last wrote (`localStorage.twlbDev`). When the save changes to another key or none (reset, import, restore), the old key signs `{hide:1,gone:1}` (not counted as hidden). Pending ones wait in `localStorage.twlbRetire` (retried at start, on `rkLbLoad`, when back online) and stay listed as done for 60 days; a retired save that is restored gets `lbPend` and posts again.
  - Resets made before this fix: `rkLbScanErased` (at start) reads the "Before erase" backups (`sgList`/`sgGet(BKP+id)`) and retires any erased save that had posted, unless it is the save in use.
- **Last 5 seconds countdown (`89x_time_alert.js`, after `89w`):** one driver (`taStep`, every 100 ms) asks `taSource()` which timed game is running and draws `#tacd` on the stage: a gold 5-4-3-2-1 badge that turns red at 3, pops each second and ticks (`beep`).
  - Sources: Wildcard turn timers, only on your own turn (the host takes the start time from a `wcStep` wrapper, `TCD.wc`; a guest counts from when its turn or phase began); it replaces Wildcard's old 3-2-1 `tick` unless the setting is Off. Casino Quiz clue (read from `#qtn`; no extra tick because the Quiz already beeps). Trick-or-Treat doorsteps (`TRT.run.remaining`, hidden during walk, greet and Moonfreeze). Timed Practice (`S.prac.gn - S.pel`) and Starfall Rift (`S.time`), at the top centre. Paused games hide it.
  - Settings › Effects › "Last 5 seconds countdown": On / Silent / Off (`ST.tacd`).
  - Also fixed: "Fit to screen on websites" (`88n`) showed on every Settings tab; it is now added before the tabs are built, next to Fullscreen (backup `.bak4`).
  - Test: `t_time_alert.py`.
- **Doubled text in ranked matches fixed:** the ranked table was tagged with the class `rkt`, which is also the results title (`<h1 class="rkt">`, brown 4px text shadow, absolute position). Every text on the table inherited that shadow and the table was shifted. The table class is now `rktbl` (`89s_wc_ranked.js`, `89u_wc_rkui.js`; backups `.bak2`). `t_ranked.py` checks for it. Keep class names unique: `rkt` is the title only.
- **Ranked season leaderboard (`89w_wc_board.js`, after `89v`), on public Nostr relays (no Firebase, no server of our own):**
  - **Storage:** after each ranked match the game signs one replaceable event per player per season (kind 30078, tags `d`/`t` = `twwc-lb-s<season>`) and sends it to the `nostr:` relays in `WCRELAYS`. Relays keep only the newest one per key. Time stamps always increase (`P.rk.lbAt`), so the newest entry always wins.
  - **Identity:** a key made once per save (`P.rk.nsk`/`npk`). Shown as the player name plus `#` and the first 4 characters of the key.
  - **Save fields:** `sm`/`sw` (season matches and wins), `r0` (the season's starting rank), `lbHide`, `lbLast` (the last content sent), `lbPend` (waiting to send), `lbSent`, `lbAt`, `lbc` (the last board, shown when offline). A new season resets `sm`, `sw` and `lbLast`, and sets `r0`.
  - **Reading:** `rkLbLoad(force)` (2-minute cache) queries all relays (`rkRelayQueryAll` pages back with `until` when a relay caps a reply), keeps the newest event per key, checks it with `rkLbCheck`, verifies BIP-340 signatures (`rkEvOk`/`rkSchnorrOk`) for the top 100 and for any newer event that would hide or remove an entry (a forged newer event falls back to the player's previous one), then ranks with `rkLbSort` (score, wins, fewer matches, earlier). The player's own row and place always come from their own save.
  - **Anti-cheat (`rkLbCheck`):** the right season, tag and time window; sane values; enough matches for the rank and bar (each rank needs its full 100 at that rank's 1st-place points); enough time for the wins; the last 10 matches listed with points from `WCRN`, wins at least `RKLBGAP` (20) seconds apart, and ranks that only go up after a gain; when the whole season fits in 10 matches it is replayed and must match exactly. Names: control and invisible characters stripped, 14 characters, a word filter (`RKBAD`), and always escaped. This blocks impossible scores and forgeries, not a careful cheater who edits their own game to post a plausible score.
  - **Screens:** `rkBoard()` (your place, insignia, "Show me on the leaderboard" On/Off, top 100 with your row highlighted and, if you are further down, a gap and your row; loading, offline-with-saved-copy and no-connection states; Refresh with a 4-second cooldown). The Ranked hub has a top-3 preview with "View all" in the middle panel; at Legend the right panel shows the players around you (`rkStandings` replaced).
  - **Tests:** `t_leaderboard.py` (needs `PYTHONPATH=../../pylib`). It starts three local relays from `t_nostr_relay.py` (now stores events like public relays; `--noverify` acts as a dishonest relay, `--slow MS`), uses `t_nostr_tools.py` (an independent Python BIP-340 signer and a ranked-season simulator) and `t_nostr_relay_math.py`. It covers BIP-340 vectors, JS↔Python signatures, every cheat rule, forged, tampered and impossible entries, XSS names, two players, replacement, hide/show, offline queue and retry, a new season, 650 players with paging, the hub preview, the Legend panel, the push throttle and one real match played to the end.
  - Not tested against the live public relays: the sandbox blocks them. Some public relays may refuse kind 30078 or rate-limit; the board works with any that answer.
- **Ranked polish:** the Wildcard home's Ranked button sits above the top bar (`.wchbar` had covered most of it), is larger, says "Play Ranked" and carries a gold trophy symbol (`.rktro`). With Settings › Text visibility › Clear on, the dark edges it adds no longer apply on the Ranked screens (they looked like doubled text). The rewards road shows "You · x / 100" above the current insignia instead of on the line.
- **Fit to the screen when embedded (`88n_fit_screen.js`, wraps `applyLayout`):** in an iframe (the owner's Wix page on a Chromebook) an invisible full-height marker (`#fitmark`) is measured with an IntersectionObserver against the browser window (works across origins), re-measured every 0.7 s. When part of the box is off screen, the stage fits the band of the box that is visible (`FIT.bt`/`FIT.bh`), wherever the page is scrolled (unless most of it is scrolled away); re-measured on resize and every 0.6 s, so switching the Chromebook between fullscreen and normal is followed both ways. Without IntersectionObserver it falls back to a screen-size estimate. Inside an iframe the mouse wheel no longer scrolls the website behind the game (wheel `preventDefault` unless a game list can scroll; `#ov` has `overscroll-behavior:contain`). Settings › Display › "Fit to screen on websites" (`ST.fitscr`) turns both off. The owner's site uses Wix's newest editor (with Aria), which has no Dev Mode, so the Big Screen lightbox plan cannot be set up there. Test: `t_fit_screen.py` (resizes the window to mimic fullscreen, checks wheel scrolling).
- **Fullscreen on Wix: Big Screen instead of a new tab (`88m_fs_bigscreen.js`, overrides `fsFallback` from `50_game.js`):** inside an iframe the game flushes the save, posts `{type:'type-warriors-fullscreen'}` to the parent and waits 400 ms for `{type:'type-warriors-fullscreen-ack'}` from `window.parent` only. Ack: no message (a 2-second note mid-run; with `action:'close'` the note says it is going back), and this copy goes quiet (`fsSleep`: sound suspended, typing run paused; the stale-save question is skipped while hidden and the first tap after returning reloads the newest save). No ack: the device-fullscreen tip, no new-tab button. Top-level pages keep the old message with "Open in new tab". The owner's Wix setup (lightbox `GameBig`, embeds `#htmlGame`/`#htmlBig`, Velo `onMessage` code) is in the "Type Warriors Fullscreen Workaround" plan. Test: `t_fs_bigscreen.py` (serves a mock parent page on a local port).
- **Wildcard Ranked (`89s`–`89v`), built from the owner's "Ranked ONE" plan, placed inside Wildcard (the owner's choice), unlocked from the start, online through the relays (no Firebase):**
  - **`89s_wc_ranked.js` (rules and data):** `WCRN` (six ranks: points per place, coins, sleeve, emote, AI description), `WCREMO`/`WCREMK` (five moment emotes), seasons (`WCRSEA`: 6 weeks from 12 Oct 2026, `rkSeason()`), save data `P.rk` via `rkSt()` (`r`, `bar`, `lp` Legend points, `season`, `peak`, `n`, `w`, `paid` {season: [ranks paid]}, `em` owned emotes, `hist`, `title`, `met`, `note`, `live`). `rkApply(place, why)` moves the bar (floor 0, rank up at 100 then 0, never drops in a season; Legend counts `lp`), `rkReward(r)` pays sleeve/emote once ever and coins once per season. A new season (checked in `rkSt`) drops 2 ranks and resets the bar. `R.live` marks a match in progress; a match left behind (page closed) counts as 4th (`rkDodge`).
    - Placing: `wcRank` now also breaks ties by whoever played last (`p.lp`, set in a `wcPlay` wrapper).
    - AI ladder: bots with `diff:'r0'..'r4'` use `wcBotRk` (Bronze random; Silver numbers first, saves wilds, most-held colour; Gold aims actions at the leader and always calls; Platinum remembers colours a player could not match, forgotten once they play it; Diamond/Legend also counts played cards, holds +4, dumps high-point cards near the end). `WCB.r0..r4` set forget/catch/reaction. Measured in 1,500-game simulations: Bronze→Silver is a big step (1.70 average place score vs three Bronze AI, 1.5 = even), later steps are small (about 1.5–1.57): the game has a lot of luck. Ranked AI think 0.8–2 s.
    - Matches: `rkStart()` (offline, 3 AI at your rank, 15-second turns, no stake, mode `solo` with `WX.tbl='rk'`, `WX.rk` set). Timeouts: a move not sent by the player (`wcSend` sets `WX.rkUser`) counts; three in a row → `rkAfk` (4th). Leaving through the menu → 4th. `wcReset` clears all ranked state so casual games stay casual.
  - **`89t_wc_rkart.js` (art):** `rkInsig(r,size,{label,anim})` builds each insignia from a card fan (2–6 cards, a wheel at Legend), wings (Platinum frost, Diamond crystal, Legend gold), medallion and emblem. Sleeves are card backs `rkcopper`, `rkmoon`, `rksun`, `rkglacier`, `rkprism`, `rkcelest` in `WCBK` with a new rarity "Ranked" (`RKRAR`), drawn by `rkSleeve(i)` through a `wcBackArt` wrapper; Celestial's rays and orbiting cards only move in big views (`.rkbig`, vault preview, ceremony). `rkEmo(key,av,cls)` + `rkEmoPaint(root)`: comic-burst emote badges with the player's own hero (crew portrait for AI).
  - **`89u_wc_rkui.js` (screens and emotes):** `rkHub()`, `rkResults(res,rank,o)` (the concept-6 result screen with the bar filling), `rkUp(up,done)` (rank-up ceremony), `rkRoad()` (rank-up rewards road). The Wildcard home has a Ranked pill next to Casino (`#rkhome`). The vault has two shelves (Lounge / Ranked sleeves). Emotes on every Wildcard table: the Emote button opens `rkPick()` (8 free emotes + 5 ranked, locked ones show their rank); `rkSend` (3-second cooldown) → `wcEmote`; ranked emotes travel as text `@key` and `wcBubble` turns them into bursts (`rkShow`); moments are detected from table events in a `wcAnim` wrapper (`rkMoment`): the matching emote glows on the button for 4 s; AI at that rank sometimes sends theirs. Tap a seat's name to mute it (`WX.mute`, also mutes taunts).
  - **`89v_wc_rkmm.js` (online):** `rkFind()` searches on the relay channel "RANKED" (`{t:'seek'}` every 1.5 s; own rank for 8 s, then ±1). The smallest compatible id hosts: picks a room code, announces `{t:'room'}`, opens a private room (`WCL.rk`) under a matchmaking overlay; guests join by code and auto-ready. The host deals when everyone invited is ready (or after 16 s) with AI in empty seats (`rkNetStart`, mode `net`, `{t:'rk'}` sent right after `start`). At the end the host sends `{t:'rkfin', rank, hands}`; each player applies their own points. Host-counted timeouts send `{t:'rkafk'}`. The host leaving voids the match for guests. Alone for 15 s → AI match. No server, so points are not protected against cheating.
  - **Tests:** `t_ranked.py` (the plan's checklist: old saves, points table, bar floor, rank up once, rewards once, coins per season, season drop, Legend, tie-breaks, AI strength, a full match, three timeouts, leaving, closing the page, emote picker/cooldown/moment/mute, other screen sizes) and `t_ranked_net.py` (two browsers matched through the local MQTT broker, a full online ranked match with identical standings on both, a lone seeker getting AI at 15 s).
  - Not done: no Updates-tab notice (the owner is asked first). The Legend standings were local at first; the season leaderboard (`89w`) replaced them.
- **Playing together on school networks (`89q_wc_nostr.js`, `89r_wc_school.js`, edits in `89k`, small addition in `88l`):**
  - **Why it failed at school:** the room-code relays used ports 8084/8884/8081, which school firewalls block (only 443 gets out). Both ways in then needed a direct WebRTC link, which school networks stop (Wi-Fi client isolation, blocked UDP/STUN, blocked mDNS), so the offline QR method could not work there either.
  - **Relays:** `WCRELAYS` now lists MQTT brokers on 443 (`mqtt.eclipseprojects.io`, `public.cloud.shiftr.io` with `public:public`, credentials parsed from the URL into the MQTT CONNECT), four Nostr relays (`nostr:wss://…`, all on 443), then the old three. Relays that worked and then dropped are reconnected with a growing pause. `wcRelaySend` captures the key and connections at call time and `wcRelayClose` waits 700 ms before closing sockets, so a last message still goes out. `wcRelayOk()` no longer requires WebRTC.
  - **Nostr (`89q`):** `wcNostr(url, topics, onMsg, onState)` has the same shape as `wcMq`. Messages are ephemeral events (kind 25051, tag `t` = topic, content = base64 AES-GCM ciphertext), signed with BIP-340 Schnorr (`wcSchnorr`, BigInt secp256k1, about 5 ms per signature) using a throwaway key per page. One signed event per message is shared by all Nostr relays (`WCNEV`).
  - **Relay fallback (`89r`):** the guest tries a direct link first; if its data channel has not opened `WCFB_MS` (5 s) after answering, or the connection fails, or the browser has no WebRTC, both sides switch to `wcVC`, a data-channel look-alike over the relay (`{t:'d', gid, n, x}`, numbered for in-order, once-only delivery; pings throttled to every 8 s; 45 s idle timeout; `{"t":"bye"}` on leaving). New relay messages: `viarelay`, `relayok`, knock flag `relay:1`. A device that needed the relay remembers it for 7 days (`localStorage.twwcRelay`) and goes straight to it next time (joins in about 2 s instead of about 11).
  - **QR invites** carry `WCR~CODE` while the room is online (scan = join by code, nothing to scan back). The old offline invite is still offered when there is no internet.
  - **Connection check** (`wcNetCheck`, linked from the home join card, the join screens and the room): tests every relay (connect plus a message round trip), direct links (two connections inside the page), the camera and how the page was opened, then gives a summary and a copyable report.
  - The "Running slowly?" offer now waits until you are outside the Casino (`88l`), since Performance mode no longer changes the Casino.
  - **Tests:** `t_wc_school.py` (needs the local MQTT broker and `t_nostr_relay.py`, a local Nostr relay that verifies every signature with its own Python BIP-340 code): a full staked game over Nostr with direct links blocked, a guest without WebRTC, relay reconnection, a normal network staying direct, the QR content, the 7-day memory and the connection check. The public relays themselves could not be reached from the build sandbox, so they have not been tested live.
- **Performance mode leaves the Casino alone (`88l_perf_casino.js`, small edit in `88k`):**
  - `PFSET()` is the saved choice (`ST.perf`); `PFM()` is the mode in effect and returns `'high'` whenever `pfCas()` is true, meaning `#ov` has the `casbg` class (the casino lobby, every casino game and all Wildcard screens).
  - So inside the Casino, Balanced and Performance change nothing: full canvas resolution, full-rate `LIVE` canvases, canvas `shadowBlur`, looping CSS animations, `backdrop-filter`, and Wildcard's full-length deal and effects (`wcRM()` only follows `prefers-reduced-motion` there).
  - `pfCasSync()` re-runs `applyLayout()` (which calls `pfApply`) the moment you enter or leave; it is hooked into `show`, `hide` and `loop`.
  - Settings shows the saved choice and notes that the Casino keeps its full animations; the "running slowly" offer also reads `PFSET()`.
  - Test: `t_perf_casino.py`.
- **Wildcard polish round (modules `89n`–`89p`, plus rewrites of `89b` and parts of `89d`/`89m`):**
  - **Cards (`89b_wc_cards.js`, rewritten):** brighter three-stop element palettes (`WCK`), white outer border, sunburst rays and element motif, a large faint element glyph, gloss sweep, gold diamond with cream centre, value or action icon, a ribbon pill for actions, and corner indexes with element coins. The four-element wild and +4 Hex keep their concepts.
  - **Card backs:** nine backs with rarities (`WCRAR`: Common, Rare, Epic, Legendary, Secret; colours `WCRARC`). `WCBK[k]` has `n` (name), `r` (rarity), `how` (unlock hint), `fl` (flavour text) and `need(W)` returning `[have, goal]` for progress bars. Unlocks live in `wcRecord`: Neon Arcade (10 games), Hallow's Eve, Emerald Jackpot (10 wins), Royal Gold, Astral, Dragonfire (5-win streak), Pastel Wyrm (win a game the rare guest sat at, `W.pbeat`), Elder Rune (secret, code WILDRUNE82). `W.seen` drives the NEW badges and the red dot on the home screen's Card backs button.
  - **Your Record and the Card Back Vault (`89o_wc_record.js`):** `wcStats()` is a full record screen (profile and rank via `WCRK`/`wcRank2`, win-rate ring, rank progress, highlight tiles, gold-per-game sparkline, recent games labelled 1st–4th via `WCPL`, wins by table). "Biggest pot" was removed at the owner's request. `wcVault(sel)` is a separate menu (home header › Card backs, and from the results unlock button): a tilting preview, rarity, flavour text, progress and Equip.
  - **Rare guest (`89n_wc_rare.js`):** a dragon in a pink (Baron Bubblegum) or baby-blue (Duke Azurine) suit, species `pdragon`, with an aura, wings, a tail, sparkles, gold horns and heart shades. `wcCrewGen(n, rnd, {rare: p})` swaps one regular for the guest with probability `p`: 10% per solo game or room, 25% on the home screen. Seats show "★ RARE GUEST".
  - **Effects (`89p_wc_fx2.js`):** `wcDeal2` (deck drop, riffle and bridge, round-robin deal straight into your hand slots face down, a flip wave, the first card to the pile), `wcWild2` (element orbs orbit and the chosen one slams into the pile), `wcRev2` (Turnabout arrow sweep and seat hops), `wcSkip2` (Stun bolt and a frozen seat). They wrap `wcAnim` for `deal`, `rev` and `skip`. All use WAAPI transforms and opacity only.
  - **Home:** header no longer overlaps the sign at 1280 wide; new add-player seat button (`.wcadd2`, a soft ping and a rotating dashed ring); a streak chip after 2+ wins in a row; card fan hover plays the `shimmer` chime.
  - **Tests:** `t_wildcard.py` now also checks the record screen, the vault, equipping a back, unlocks and the rare-guest rate (about 10%).
- **Update 8.2: Wildcard, the Dragon Lounge card game (modules `89a`–`89m`, after `88k_access_perf.js`):**
  - **Where it lives:** Casino → Cards tab (first tile, red NEW corner ribbon; the ribbon moved off Nebula Scratch) and the Special tab feature card (the Wildcard / Nebula / Tower switch defaults to Wildcard). `gameOpen('wc')` opens `wcHome()`.
  - **Casino grid:** with 13+ games the grid switches to 7 columns (`:has(>.gdt:nth-child(13))`), and from 15 games it scrolls, so no tile (Quiz Showdown last time) is ever cut off again.
  - **Modules:**
    - `89a_wc_core.js`: the pure rules engine. `wcNew` builds the game `G`; actions `wcPlay`, `wcDrawAct`, `wcPass`, `wcCall` (WILD!), `wcCatch`, all via `wcDo(G, seat, action)`. Every change is logged to `G.ev`; the table replays events as animations. Bots: `wcBot` (all lounge regulars play at the `m` level of `WCB`). Economy: `WCT` (four tables keyed `c50`, `c250`, `c1k`, `c2k5`), `WCTK`, `WCFEE`, `WCE`, `wcPayout`.
    - `89b_wc_cards.js`: SVG card art (`wcSVG`, cached): element gradients with element motifs (flames, waves, leaves, bolts), a gold inner frame with corner gems, a gold-rimmed shield, action ribbons (STUN, TURN, CURSE, WILD, HEX), four-element wilds. Card backs `WCBK` and `wcBack`.
    - `89c_wc_table.js`: the table. `WX` is the state. `wcPump` plays events through `wcAnim`; `wcStep` schedules the regulars, catch windows, the same-screen curtain and turn timers. Effects: `wcFly`, `wcBurst` (element-glyph particles), `wcWave` (wild colour sweep), `wcShake`, `wcFlash`, riffle shuffle. The status pill above the hand says whose turn it is and what to play. `wcMenu` is the in-game menu (Esc opens it). It also holds back the "Running slowly?" offer while a card game is on screen.
    - `89d_wc_menus.js`: home (`wcHome`: neon marquee, live regulars, chip table picker, room-code boxes), rules, save data in `P.wc` via `wcSt()` (the stats screen now lives in `89o`), solo start, `wcRecord`, results podium, the private room (`WCL`, `wcLobbyRender`, seat menu `wcSeatMenu`, chip buy-ins, segmented timer and hand size, house-rule tiles) and the join screens (`wcJoinView(state)`).
    - `89e_wc_net.js`: playing with friends on other devices (see below). Host is authoritative: guests get `wcView` (other hands masked) and send actions by card id.
    - `89f_wc_casino.js`: casino listing, `wcFeat`, the Special switch.
    - `89g_wc_qr.js`: QR encoder (`wcQR`). `89g9_wc82img.js`: the 8.2 collage. `89h_update82.js`: the 8.2 Updates entry (no News card, by the owner's choice) and the code **WILDRUNE82** (2,500 coins plus the Elder Rune card back, once per save), hidden at the end of the notes.
    - `89i_wc_crew.js`: the lounge regulars — monsters in suits drawn on canvas (dragon, goblin, orc, skeleton, lizard, wolf, frog, octopus) with random suits, ties, hats, eyewear and held items. `wcCrewGen(n)` makes a lineup with random names; `wcCrewDraw(g, A, t)` animates breathing, blinking and a flipping chip. `wcPortrait`/`wcFigure` are wrapped for `av.t==='crew'`.
    - `89j_wc_audio.js`: "Neon Wildcard", a synthesised arcade lounge theme (16 bars, A minor, the casino's 116 bpm) with menu, game and tense variations, routed through the casino music busses (so the Music setting applies), plus `wcFx(name)` sound effects through the sound-effects volume.
    - `89k_wc_relay.js`: room codes over public MQTT brokers on secure WebSockets (`WCRELAYS`), messages AES-GCM encrypted with a key from the room code. `89l_wc_scan.js`: camera scanning (`wcScan`) with a built-in QR decoder (`wcQRDecode`, Reed-Solomon corrected) for offline joining.
    - `89m_wc_style.js`: every Wildcard style.
  - **Playing with friends:**
    - *Room code (needs internet):* the host's room shows a 4-letter code. The guest types it on the home screen; the devices swap WebRTC details through the relay (several brokers at once, whichever answer), then play directly. STUN servers help devices on different networks; some strict networks still block direct play, and the join screen says so.
    - *Scan to join (no internet, same Wi-Fi):* the host taps Invite by QR, the guest scans it (Join a room › No internet? Scan to join), then the host scans the guest's reply QR. Paste and copy fallbacks exist for devices without a camera.
  - **Economy (3,000-game simulations, `sim2.js` style):** buy-ins 50 / 250 / 1,000 / 2,500 with a 12% house cut; the winner takes the pot less the cut, 2nd gets 40% of their buy-in back. Gold returned per gold staked: careless player 0.52, typical 0.98, sharp 1.12 (and a sharp player still wins only about 29% of games). 15 paid games a day (then practice), first win of the day +150, private rooms cut 10%, same-screen games are free.
  - **Tests:** `t_wildcard.py` (listing, payouts, the code, a staked solo game played by `t_wc_agent.js`, the in-game menu, forfeit, daily cap, stats, Esc), `t_wc_pp.py` (same screen), `t_wc_scan.py` (two browsers joined by scanning each other's QR through the real decoder), `t_wc_code.py` (two browsers joined by room code through a real MQTT broker; start one locally first, for example `pip install amqtt` and run its broker with a `ws` listener on `127.0.0.1:18083`).
- **Text visibility and Performance mode (`88k_access_perf.js`, Settings → Display):**
  - **Text visibility** (`ST.tvis`, Standard or Clear): `tvBuild()` reads every style rule once and writes stronger copies of the faint ones into `#tvcss`. Faded colours are brightened while vivid gold and rarity colours are kept, small text gets bolder, and light menu text gets a dark edge.
    - The copies are wrapped in `:where(body.tv)` so they never beat a more specific state rule such as a selected tab.
    - Note: weight and size are parsed from `font:` shorthands, because rules using `var(--ui)` report blank longhands.
  - **Performance mode** (`ST.perf`: `high`, `bal` or `low`). Profiling showed the canvas is fill-bound: the zone background is about 45% of a frame and the vignette about 15%.
    - Balanced: resolution at most 1×, the background is redrawn every 2nd frame (`PFBG` copies the freshly drawn background and replays it), and the vignette is pre-rendered.
    - Performance: resolution 0.75×, background every 4th frame, no decorative vignette, `runLive` at half rate, looping CSS animations paused (`pfAnims`), and a `shadowBlur` hook that exists only while Performance is on.
    - The background cache is bypassed while the screen shakes or a cutscene zooms.
    - In Quality mode the game offers Performance once after two 5-second windows under 20 fps outside gameplay (`ST.perfAsked`).
  - Tests: `t_access.py`.
- **Code NEWUPDATECOINS81 (`88j_code81.js`):**
  - A built-in code (in `CC_BUILTIN`, `max:0`) worth 1,500 coins plus a Runeshell egg.
  - Each save can redeem it once (`P.ccUsed`), and it's case-insensitive.
  - `ccGrant` and `ccPlay` are wrapped to add the egg and show it on the reward card.
  - The code is hidden at the end of the 8.1 notes in the Updates tab only (`.blsec`). The News card is unchanged.
  - Test: `t_code81.py`.
- **Update 8.1 notification (`88i_update81.js`), pushed with the owner's okay:**
  - Adds `u-8.1` to `UPDATES` and `n-8.1` (out) to `NEWS`, both titled "Companions & Loadouts".
  - Both carry a collage (`UPD81_IMG`, a 900px WebP data URL of about 102 KB, made from in-game screenshots).
  - `bellInner` is wrapped so Updates entries with `img` show it, as News does. Any `.blimg` opens full size on click (`updZoom`, Esc closes).
- **XP pacing (from another session, ported in):**
  - New `88h_xp_pacing.js`, plus small edits in `60_ui.js`, `70a_modes.js`, `73c_dc_game.js`, `84c_gy_mode.js`, `84i_beginner.js` and `85_astral.js` (backups `*.v11bak`).
  - The build matched the owner's `type-warriors_58.html` byte for byte before 8.1 was added.
- **Roster card flicker fix (`87j_pet_cardfix.js`, after `87i`):**
  - The bug: selecting a companion added an idle `LIVE` loop to its card but never removed the old one, re-clicking stacked more, and the hover greeting loop kept running after a click. Several loops drew different poses into one canvas, so the card glitched.
  - Also, the original `live()` takes the card's first canvas, which on a Mythic card is the backdrop.
  - The fix: `ptCardTidy()` runs after every click in the hall. It keeps exactly one idle loop on the selected card's `canvas[data-pc]`, returns other cards to a still frame, and keeps backdrop canvases on their own painter. `ptCardWake` stops as soon as its card is selected.
  - Test: `t_petclick.py`.
- **Mythic backdrop (`88g_mythic_bg.js`) and a tile fix:**
  - Every owned Mythic pet shown in a frame gets an animated cosmic backdrop on a canvas behind the art. Frames covered: Companion Hall roster cards and portrait, Loadout Locker cards, slots, picker and compare, the Armory pet slot, and egg pool lists.
  - The backdrop: a turning spiral nebula with stars, twinkles, a breathing glow, an upright halo, a gold magic circle under the feet, rising motes and a shooting star.
  - Palettes are per pet (`MYPAL`: yeti frost, sol sunfire, `_` default for any future Mythic). Sprites are cached in `MYIMG`.
  - A MutationObserver finds hosts (`MYHOST`) and adds the canvas to `LIVE` with `slow:3` (`slow:4` for small frames). Reduced motion shows a still frame.
  - Fix in `88f`: `.lotile` clips again, and canvases are absolutely positioned to the tile. Snap sparkles now live on the slot row, not inside the tile.
- **Loadout Locker polish (`88f_loadout_polish.js`, after `88e`):**
  - The right panel is now a slot editor. Click a slot, drop gear onto it, or press Enter on it to open the gear picker in the left panel. The picker has class or rarity filter chips, a "Sort:" dropdown in the Pets-tab style (saved in `P.lo.so`), and a "Best" badge.
  - Hovering or focusing an item previews it on the hero. A compare box shows overall strength (the Auto-Equip test run) and per-stat changes with green ▲ / red ▼.
  - Put an item in with the button, a double-click, Enter, or drag and drop. Clear a slot with × or Delete. Auto-fill best uses `autoPick` for the preset's class.
  - Slot snap animation with sparkles and a beep. Enter on the selected preset equips it. Esc closes the innermost layer (sort menu, then picker, then the page).
  - The Armory bar has a "Loadouts" button (`#arlo`).
  - Gotchas found:
    - The game's global `.em` class (Endless menu) leaked padding into empty slots, so they now use `lomt`.
    - HTML5 drag needs a `div` (Chromium won't drag a `<button>`) and `-webkit-user-drag:element` once `all:unset` is applied.
  - Test: `t_loadout_polish.py`.
- **Loadout Locker (`88e_loadouts.js`, Gear → Loadouts):**
  - Three named presets (default names Campaign, Endless, Gold Hunt) in `P.lo = {s:[{n,w,a,p,c}×3], sel, ask}`. Each stores weapon, armor, companion and the weapon's class.
  - The Gear sub-tab strip is now Armory · Loadouts · Skill Tree (`DKSUB.gr`, `DKG.lo`, and `DKGO.gr` remembers it). The page is detected by `class="lol"`.
  - Equip applies only owned, usable pieces: it checks `P.own`/`P.ownA`, `pathOpen` for the class and `petOwned`. Anything else is skipped, marked on the tile, and reported in a toast. Skill Tree ranks are never touched.
  - Save current loadout: overwriting a filled preset needs a second click. Rename is inline (pencil, Enter/Esc, 16 characters max). "Ask before replacing gear" (`P.lo.ask`) shows a confirm dialog listing each change.
  - Illustrated locker-room stage (cached background, torches, motes). It previews the hovered or selected preset; a swap sparkles and an equip plays a gold celebration. Keys 1–3 pick a preset.
  - Test: `t_loadouts.py`.
- **Source synced with the shipped HTML:** the changes that existed only in the delivered `type-warriors.html` now live in the source, and the build is byte-identical to it.
  - New `87i_pet_mythic.js` (after `87h`): Mythic companions Glacierhorn and Solmane, the Starforge egg (50,000 gold, `P.eggs.m`), the Starforge hatch cinematic, Mythic battle effects and the companion power hotkey.
  - New `88d_spnote.js` (after `88c`): `spNote()`, so the Skill Tree badge only appears when a point can actually be spent.
  - Small in-place edits (backups `*.v7bak`): `74_shell.js` and `88_dock.js` use `spNote()`; `86b_codes.js` adds the `BRAYDENSGIFT` code; `87a_pet_data.js` counts Mythic eggs; `87d_pet_game.js` draws the companion in front of the knight (`petDrawGame`).
- Tests need Python Playwright pinned to the installed browser (here `pip install playwright==1.56.0`).
- **Dock icons v2 (`88c_dockicons.js`):**
  - All six icons redrawn: crossed swords, knight's helm with plume, paw with a heart pad, rounded bar chart, coin pouch, three dots.
  - Each icon has a hover, focus and press animation that plays to the end.
  - Badges moved off the icon art, and the label no longer shifts on hover.
- **Pet and egg effects (`87h_pet_fx.js`):**
  - Descriptions for both eggs (`PEGGD`), on the stage and in an "About" card. Redrawn `PTICO` icons.
  - Pet stage: pop-in on select, signature-colour motes, petting with hearts and combos (every fifth pet plays the power animation), a "Tap to pet" hint, and a gold celebration on equip.
  - Roster: cards wake and greet on hover, and owned legendary cards get a gold shine.
  - Eggs: ready eggs rock, sparkle and pulse; tapping the egg gives a reaction; the hatch button gets a shine.
  - The hatch reveal shows collection progress and the next free egg.
- **Pets sort and Eggs declutter (`87g_pet_polish.js`):**
  - "Sort:" dropdown with Collection, Recommended, Rarity, Bond high/low, Name A–Z and Recently acquired, saved in `P.petSort`.
  - Rarity-bordered cards.
  - Eggs tab is now three columns: Your Eggs, the egg stage, and Hatchery (with Buy and "Earn one free").
- **Earlier:** Console Dock main-menu overhaul; bright region diorama; Manage pet / Manage gear buttons; Daily Challenge medallion that changes every day; smooth menu transitions; pet starter-screen fixes.
