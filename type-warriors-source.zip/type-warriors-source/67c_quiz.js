/* ---------- casino: Quiz Showdown, a category board of trivia clues ---------- */
/*QZ-LOGIC*/
const QZ={VALS:[200,400,600,800,1000],PICKS:10,REF:1000,CAP:2.5,WRONG:.5,QUICK:6,QCAP:1000,T:[20,20,20,22,24],
 gain(v,secs,streak){let g=v;if(secs<=QZ.QUICK)g+=Math.round(v*.1);if(streak>=2)g+=100;return g},
 loss(v){return Math.round(v*QZ.WRONG)},
 mult(s){const x=s/QZ.REF;return x<=0?0:x<=1.5?x:Math.min(QZ.CAP,1.5+(x-1.5)*.5)},
 ddMax(s){return Math.max(1000,Math.min(s,2000))},finMax(s){return Math.max(0,Math.min(s,2000))}};
/*END-QZ-LOGIC*/
ICON.qz='<svg viewBox="0 0 64 64"><rect x="6" y="10" width="52" height="38" rx="5" fill="#1a3aa8" stroke="#ffd76a" stroke-width="3"/><rect x="11" y="15" width="42" height="28" rx="2" fill="#0a1e6a"/><text x="32" y="38" font-size="26" text-anchor="middle" fill="#ffd76a" font-family="Georgia" font-weight="700">?</text><rect x="22" y="50" width="20" height="5" rx="2" fill="#ffd76a"/></svg>';
GAMES.push({id:'qz',n:'Quiz Showdown',d:'Pick clues from a category board and answer for points. Daily Double, Final Clue. Your score sets the payout.',m:(e,t)=>mQZ(e,t)});
const qzShuf=a=>{a=a.slice();for(let i=a.length-1;i>0;i--){const j=Math.random()*(i+1)|0;[a[i],a[j]]=[a[j],a[i]]}return a};
function qzBuild(){P.qs=Array.isArray(P.qs)?P.qs:[];const seen=new Set(P.qs),cats=qzShuf(Object.keys(QB)),board=cats.slice(0,5),used=new Set();
 const pick=(c,t)=>{const rows=QB[c].map((r,i)=>({r,id:c+'|'+i})).filter(x=>x.r[0]===t),fresh=rows.filter(x=>!seen.has(x.id)),p=qzShuf(fresh.length?fresh:rows)[0];return p};
 const mk=x=>({id:x.id,q:x.r[1],o:qzShuf([{t:x.r[2],ok:1},{t:x.r[3]},{t:x.r[4]},{t:x.r[5]}])});
 const grid=board.map(c=>QZ.VALS.map((v,ti)=>{const x=pick(c,ti+1);return{c,v,done:0,dd:0,...mk(x)}}));
 const dc=Math.random()*5|0,dr=2+(Math.random()*3|0);grid[dc][dr].dd=1;
 const others=cats.slice(5),fp=pick(others[Math.random()*others.length|0],5);
 return{cats:board,grid,fin:{c:fp.id.split('|')[0],v:0,...mk(fp)}}}
function mQZ(el,tok){
 const alive=()=>CAS.tok===tok,L='ABCD';
 let ph='setup',G=null,bet=0,score=0,picks=0,streak=0,bestS=0,nOk=0,nBad=0,nPass=0,cur=null,locked=false,settled=false,tmr=null,t0=0,tmax=20,lastSec=0,nt=null,stake=0,active=false;
 const QC=()=>Math.min(QZ.QCAP,P.gold);
 el.innerHTML=`<div class="qz"><div class="qbar"><div class="qst"><span>Score</span><b id="qs">0</b></div><div class="qst"><span>Picks left</span><b id="qp">${QZ.PICKS}</b></div><div class="qst"><span>Streak</span><b id="qk">0</b></div><div class="qst pay"><span>Payout now</span><b id="qm">0.00×</b><small id="qmv"> </small></div></div><div id="qmain" class="qmain"></div><p class="cmsg" id="cm"> </p><div class="ctl" id="qctl"></div></div>`;
 const HUD=()=>{const m=QZ.mult(score);$('qs').textContent=cmn(score);$('qs').className=score<0?'neg':'';$('qp').textContent=Math.max(0,QZ.PICKS-picks);$('qk').textContent=streak;$('qm').textContent=(ph==='setup'?0:m).toFixed(2)+'×';$('qmv').textContent=ph==='setup'?'':cmn(Math.floor(bet*m))+' gold'};
 const clr=()=>{clearInterval(tmr);clearTimeout(nt);nt=null};
 const timer=(max,onEnd)=>{clearInterval(tmr);t0=performance.now();tmax=max;lastSec=0;tmr=setInterval(()=>{if(!alive()){clearInterval(tmr);return}const left=Math.max(0,tmax-(performance.now()-t0)/1000),b=$('qtb');if(b){b.style.width=(left/tmax*100)+'%';b.className=left<6?'low':''}const n=$('qtn');if(n)n.textContent=Math.ceil(left);
   if(left<=5&&left>0&&Math.ceil(left)!==lastSec){lastSec=Math.ceil(left);beep(480+(5-lastSec)*40,.05,'square',.18)}if(left<=0){clearInterval(tmr);onEnd()}},100)};
 const settle=()=>{if(settled)return;settled=true;active=false;clr();const m=QZ.mult(score),pay=Math.floor(bet*m);stat('qzc',nOk,'add');stat('qzs',bestS,'max');stat('qzx',m>=QZ.CAP-1e-9?1:0,'max');P.qs=(P.qs||[]).slice(-420);save();cPay(bet,pay);return pay};
 CAS.flush=()=>{if(active&&!settled){if(ph==='clue'&&!locked&&cur){score-=cur.dd?cur.wg:QZ.loss(cur.v)}settle()}};
 /* ---- setup ---- */
 const setup=()=>{ph='setup';clr();active=false;settled=false;score=picks=streak=bestS=nOk=nBad=nPass=0;HUD();
  const lad=[0,.5,1,1.5,2,2.5,QZ.CAP].filter((x,i,a)=>a.indexOf(x)===i&&x<=QZ.CAP),need=m=>Math.round(QZ.REF*(m<=1.5?m:1.5+(m-1.5)*2));
  $('qmain').innerHTML=`<div class="qrules"><div class="qr1"><h3>How it works</h3><ul><li>Choose <b>${QZ.PICKS} clues</b> from a board of 5 categories. Higher values are harder.</li><li>A right answer wins the clue's value. <b>Answer within ${QZ.QUICK} seconds</b> for a 10% bonus, and from your 3rd right answer in a row earn <b>+100</b>.</li><li>A wrong answer or a timeout costs <b>half</b> the value. <b>Pass</b> costs nothing but uses a pick.</li><li>One clue hides a <b>Daily Double</b>: wager your own points on it.</li><li>Then comes the <b>Final Clue</b>. Wager what you like and risk it all, or cash out before it.</li></ul></div>
  <div class="qr2"><h3>Payout</h3><table class="qlad"><tr><th>Final score</th><th>You get</th></tr>${lad.map(x=>`<tr><td>${x?cmn(need(x)):'0 or less'}</td><td><b>${x?x.toFixed(2).replace(/\.?0+$/,'')+'× your stake':'nothing'}</b></td></tr>`).join('')}</table><p class="qnote">Stakes are limited to ${cmn(QZ.QCAP)} gold. Questions you have seen come up last, so you meet fresh ones first.</p></div></div>`;
  $('qctl').innerHTML=`${betBar('Stake')}<div class="btns"><button class="bbig" id="qgo">Start quiz</button></div>`;
  wireBet(()=>{if(CAS.bet>QC())CAS.bet=QC();betRefresh()});$('qgo').onclick=start;msg(broke()||'Set your stake and press Start. Keys: 1 to 4 or A to D answer, P passes.');
  CAS.key={enter:()=>start(),' ':()=>start()}};
 const start=()=>{if(ph!=='setup'||CAS.lock)return;if(CAS.bet<1){msg(broke()||'Place a stake first.');return}if(CAS.bet>P.gold){msg('Not enough gold.');return}if(CAS.bet>QZ.QCAP){CAS.bet=QZ.QCAP;betRefresh()}bet=CAS.bet;if(!cTake(bet))return;betLock(true);const cb=$('cb');if(cb){cb.disabled=false;S.back=()=>lobby();cb.onclick=S.back}G=qzBuild();active=true;settled=false;beep(520,.06,'triangle',.5);board('Choose a clue. Higher values pay more and are harder.')};
 /* ---- board ---- */
 const board=m=>{ph='board';clr();cur=null;locked=false;HUD();
  let cells='';for(let r=0;r<5;r++)for(let c=0;c<5;c++){const t=G.grid[c][r];cells+=`<button class="qt${t.done?' used':''}" data-c="${c}" data-r="${r}" ${t.done?'disabled':''}>${t.done?'':t.v}</button>`}
  $('qmain').innerHTML=`<div class="qb"><div class="qh">${G.cats.map(c=>`<div>${esc(c)}</div>`).join('')}</div><div class="qg">${cells}</div></div>`;
  ov.querySelectorAll('.qt:not(.used)').forEach(b=>b.onclick=()=>open(+b.dataset.c,+b.dataset.r));
  const m2=QZ.mult(score),can=picks>=(QZ.MINP||1)&&m2>0;
  $('qctl').innerHTML=`<div class="btns"><button class="bbig" id="qco" ${can?'':'disabled'}>Cash out ${can?cmn(Math.floor(bet*m2)):''}</button></div>`;$('qco').onclick=cashout;
  CAS.key={c:()=>{if(can)cashout()}};msg(m||' ')};
 const cashout=()=>{if(ph!=='board'||picks<(QZ.MINP||1)||QZ.mult(score)<=0)return;const pay=settle();ph='end';results(true,pay)};
 const open=(ci,ri)=>{if(ph!=='board')return;const c=G.grid[ci][ri];c.done=1;picks++;cur=c;P.qs.push(c.id);
  if(c.dd){ph='dd';dd()}else clue(QZ.T[ri])};
 /* ---- daily double ---- */
 const dd=()=>{const mx=QZ.ddMax(score);let w=Math.min(mx,Math.max(100,Math.round(score/4/100)*100));cur.wg=w;HUD();
  $('qmain').innerHTML=`<div class="qsplash"><div class="qdd">DAILY DOUBLE!</div><p>${esc(cur.c?G.cats[G.grid.findIndex(col=>col.includes(cur))]:'')}. Wager any amount of your points, from 100 up to ${cmn(mx)}. Right wins it, wrong loses it.</p><div class="qw"><button class="sm" data-d="-100">−100</button><b id="qwv">${cmn(w)}</b><button class="sm" data-d="100">+100</button></div><div class="qwq"><button class="sm" data-q="0">Min</button><button class="sm" data-q="25">25%</button><button class="sm" data-q="50">50%</button><button class="sm" data-q="100">Max</button></div></div>`;
  const setW=x=>{w=Math.max(100,Math.min(mx,Math.round(x/100)*100));cur.wg=w;$('qwv').textContent=cmn(w)};
  ov.querySelectorAll('[data-d]').forEach(b=>b.onclick=()=>setW(w+ +b.dataset.d));ov.querySelectorAll('[data-q]').forEach(b=>b.onclick=()=>setW(+b.dataset.q===0?100:mx*+b.dataset.q/100));
  $('qctl').innerHTML=`<div class="btns"><button class="bbig" id="qlk">Lock in wager</button></div>`;$('qlk').onclick=()=>clue(26);CAS.key={enter:()=>clue(26),' ':()=>clue(26)};jingle('boon');msg(' ')};
 /* ---- a clue ---- */
 const clue=secs=>{ph='clue';locked=false;clr();const isF=cur===G.fin,cat=isF?G.fin.c:G.cats[G.grid.findIndex(col=>col.includes(cur))];
  $('qmain').innerHTML=`<div class="qcard"><div class="qct"><span>${esc(cat)}</span><b>${isF?'FINAL CLUE':cur.dd?'DAILY DOUBLE · wager '+cmn(cur.wg):cmn(cur.v)+' points'}</b></div><div class="qtm"><i id="qtb"></i><em id="qtn">${secs}</em></div><p class="qq">${esc(cur.q)}</p><div class="qa">${cur.o.map((o,i)=>`<button data-i="${i}"><u>${L[i]}</u><span>${esc(o.t)}</span></button>`).join('')}</div></div>`;
  ov.querySelectorAll('.qa button').forEach(b=>b.onclick=()=>answer(+b.dataset.i));
  const pass=!isF&&!cur.dd;$('qctl').innerHTML=pass?`<div class="btns"><button class="bbig sm2" id="qps">Pass (P)</button></div>`:' ';if(pass)$('qps').onclick=passIt;
  const K={p:()=>pass&&passIt()};for(let i=0;i<4;i++){K[String(i+1)]=()=>answer(i);K[L[i].toLowerCase()]=()=>answer(i)}CAS.key=K;
  HUD();msg(' ');timer(isF?30:secs,()=>answer(-1))};
 const reveal=(i,ok)=>{ov.querySelectorAll('.qa button').forEach((b,k)=>{b.disabled=true;if(cur.o[k].ok)b.classList.add('good');else if(k===i)b.classList.add('bad')})};
 const passIt=()=>{if(ph!=='clue'||locked)return;locked=true;clr();nPass++;streak=0;ov.querySelectorAll('.qa button').forEach((b,k)=>{b.disabled=true;if(cur.o[k].ok)b.classList.add('good')});HUD();msg('Passed. No points lost.');after()};
 const answer=i=>{if(ph!=='clue'||locked)return;locked=true;clr();const secs=(performance.now()-t0)/1000,isF=cur===G.fin,ok=i>=0&&!!cur.o[i].ok;reveal(i,ok);let d;
  if(isF){d=ok?fw:-fw}else if(cur.dd){d=ok?cur.wg:-cur.wg}else d=ok?QZ.gain(cur.v,secs,streak):-QZ.loss(cur.v);
  if(ok){nOk++;streak++;bestS=Math.max(bestS,streak);jingle(isF||cur.dd||d>=800?'win':'boon')}else{nBad++;streak=0;beep(170,.25,'sawtooth',.5)}
  score+=d;HUD();const f=document.createElement('div');f.className='qfl '+(d>=0?'up':'dn');f.textContent=(d>=0?'+':'−')+cmn(Math.abs(d));$('qmain').appendChild(f);
  const bon=ok&&!isF&&!cur.dd?(secs<=QZ.QUICK?' Quick bonus!':'')+(streak>=3?' Streak bonus +100!':''):'';
  msg(ok?`Correct!${bon}`:i<0?`Time is up. The answer was ${cur.o.find(o=>o.ok).t}.`:`Not quite. The answer was ${cur.o.find(o=>o.ok).t}.`,ok?'w':'l');after()};
 const after=()=>{const last=picks>=QZ.PICKS||cur===G.fin,go=()=>{clearTimeout(nt);nt=null;if(!alive())return;if(cur===G.fin){fin2();return}if(picks>=QZ.PICKS)toFinal();else board()};
  $('qctl').innerHTML=`<div class="btns"><button class="bbig sm2" id="qnx">${last?(cur===G.fin?'See results':'Continue'):'Next clue'} ▸</button></div>`;$('qnx').onclick=go;CAS.key={enter:go,' ':go};nt=setTimeout(go,cur===G.fin?2600:2200)};
 /* ---- final clue ---- */
 let fw=0;
 const toFinal=()=>{ph='fin';clr();const mx=QZ.finMax(score);if(mx<=0){msg('No points to wager, so the Final Clue is skipped.');const pay=settle();ph='end';results(false,pay);return}
  fw=Math.min(mx,Math.round(score/4/100)*100);HUD();cur=G.fin;P.qs.push(G.fin.id);
  $('qmain').innerHTML=`<div class="qsplash"><div class="qdd" style="color:#ffd76a">FINAL CLUE</div><p>Category: <b>${esc(G.fin.c)}</b>. Wager up to ${cmn(mx)} points. A right answer adds it, a wrong answer or a timeout takes it away. Or cash out now and keep your ${cmn(Math.floor(bet*QZ.mult(score)))} gold.</p><div class="qw"><button class="sm" data-d="-100">−100</button><b id="qwv">${cmn(fw)}</b><button class="sm" data-d="100">+100</button></div><div class="qwq"><button class="sm" data-q="0">Zero</button><button class="sm" data-q="25">25%</button><button class="sm" data-q="50">50%</button><button class="sm" data-q="100">Max</button></div></div>`;
  const setW=x=>{fw=Math.max(0,Math.min(mx,Math.round(x/100)*100));$('qwv').textContent=cmn(fw)};
  ov.querySelectorAll('[data-d]').forEach(b=>b.onclick=()=>setW(fw+ +b.dataset.d));ov.querySelectorAll('[data-q]').forEach(b=>b.onclick=()=>setW(mx*+b.dataset.q/100));
  const go=()=>{if(fw<=0){/* a zero wager still plays for fun but cannot change the score */}clue(30)};
  $('qctl').innerHTML=`<div class="btns"><button class="bbig" id="qfg">Lock in and answer</button><button class="bbig sm2" id="qfc">Cash out</button></div>`;$('qfg').onclick=go;$('qfc').onclick=()=>{const pay=settle();ph='end';results(false,pay)};CAS.key={enter:go};jingle('boon');msg(' ')};
 const fin2=()=>{const pay=settle();ph='end';results(false,pay)};
 /* ---- results ---- */
 const results=(cash,pay)=>{clr();CAS.key={enter:()=>setup(),' ':()=>setup()};betLock(false);HUD();const m=QZ.mult(score),net=pay-bet,tot=nOk+nBad,acc=tot?Math.round(nOk/tot*100):0;
  $('qmain').innerHTML=`<div class="qres"><h3>${cash?'You cashed out':'Quiz complete'}</h3><div class="qbig ${net>0?'w':net<0?'l':''}">${cmn(pay)} <small>gold</small></div><p>${net>0?`You won <b>${cmn(net)}</b> gold.`:net===0&&pay>0?'You got your stake back.':`You lost ${cmn(bet-pay)} gold.`}</p><div class="qstats"><span><b>${cmn(score)}</b>final score</span><span><b>${m.toFixed(2)}×</b>multiplier</span><span><b>${nOk}</b>right</span><span><b>${nBad}</b>wrong</span><span><b>${nPass}</b>passed</span><span><b>${bestS}</b>best streak</span><span><b>${acc}%</b>accuracy</span></div></div>`;
  $('qctl').innerHTML=`<div class="btns"><button class="bbig" id="qag">Play again</button></div>`;$('qag').onclick=setup;
  msg(pay>bet?'Nice work!':pay<bet?`${broke()||'Better luck next round.'}`:' ',pay>bet?'w':pay<bet?'l':'')};
 setup()}
