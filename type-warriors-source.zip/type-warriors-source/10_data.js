'use strict';
const W=1600,H=900,GY=770,KX=210,K=W/900,TAU=Math.PI*2;
const $=id=>document.getElementById(id);
const cv=$('c'),ctx=cv.getContext('2d'),ov=$('ov'),inp=$('inp'),wrap=$('wrap');
const RC={Common:'#b8b8b8',Uncommon:'#5fd97a',Rare:'#5fb4ff',Epic:'#c86bff',Legendary:'#ffb02e',Mythic:'#ff4d94'};
const RKM={Common:0,Uncommon:1,Rare:2,Epic:3,Legendary:4,Mythic:5};
const HC=[['Crimson','#b3243d'],['Azure','#2f6fd8'],['Emerald','#2fa85a'],['Violet','#8a3fd8'],['Amber','#e0a020'],['Ivory','#e8e4d8'],['Rose','#e0507a'],['Teal','#22b5b0'],['Orange','#e8702a'],['Midnight','#2a3a8a'],['Onyx','#26262e'],['Silver','#b8c0cc']];
const hcOf=c=>c===99?((typeof P!=='undefined'&&P&&P.cc)||'#ffffff'):(HC[c]||HC[0])[1];
const mixc=(a,b,f)=>{if(!/^#[0-9a-f]{6}/i.test(a)||!/^#[0-9a-f]{6}/i.test(b))return a;const p=parseInt(a.slice(1,7),16),q=parseInt(b.slice(1,7),16),m=(s)=>Math.round(((p>>s)&255)*(1-f)+((q>>s)&255)*f);return '#'+((1<<24)+(m(16)<<16)+(m(8)<<8)+m(0)).toString(16).slice(1)};
const RK=['Novice','Initiate','Adept','Veteran','Elite','Champion','Warlord','Legend'];

/* ---------- gear ---------- */
const WP={
rusty:{n:'Rusty Sword',r:'Common',d:'No bonus',w:40,t:'sword',c:'#8a6a4a'},
dagger:{n:'Iron Dagger',r:'Common',d:'+5% score',sc:1.05,w:30,t:'dagger',c:'#c8ccd8'},
steel:{n:'Steel Blade',r:'Uncommon',d:'+10% score',sc:1.1,w:14,t:'sword',c:'#dfe6f5'},
mace:{n:'Spiked Mace',r:'Uncommon',d:'Fury charges 15% faster',fu:1.15,w:14,t:'mace',c:'#9aa0b0'},
axe:{n:'Battle Axe',r:'Uncommon',d:'Enemies 5% slower',sl:.95,w:14,t:'axe',c:'#b8c0d0'},
frost:{n:'Frostfang',r:'Rare',d:'Enemies 10% slower',sl:.9,w:8,t:'sword',c:'#7fd8ff'},
venom:{n:'Viper Fang',r:'Rare',d:'Combos build faster',cq:1,w:8,t:'dagger',c:'#7dff5f'},
lance:{n:'Knight Lance',r:'Rare',d:'+15% score',sc:1.15,w:8,t:'spear',c:'#e8eefc'},
ember:{n:'Ember Axe',r:'Epic',d:'Fury charges 30% faster',fu:1.3,w:4,t:'axe',c:'#ff8a3a'},
moon:{n:'Moonblade',r:'Epic',d:'Enemies 10% slower, +10% score',sl:.9,sc:1.1,w:4,t:'sword',c:'#c8d0ff'},
storm:{n:'Stormspear',r:'Legendary',d:'Faster combos, +20% score',cq:1,sc:1.2,w:2,t:'spear',c:'#ffe36a'},
void:{n:'Void Scythe',r:'Legendary',d:'Faster combos, fury +40%',cq:1,fu:1.4,w:2,t:'scythe',c:'#b06bff'},
sun:{n:'Sunbrand',r:'Legendary',d:'+35% score',sc:1.35,w:1,t:'sword',c:'#ffd24a'},
king:{n:'Kingsbane',r:'Legendary',d:'Slower foes, +15% score, fury +20%',sl:.85,sc:1.15,fu:1.2,w:1,t:'sword',c:'#ffffff'}};
const AR={
rags:{n:'Ragged Tunic',r:'Common',d:'No bonus',w:50,m:'#8a7a5a',dk:'#5e5236',tr:'#c2b088'},
leather:{n:'Ranger Leathers',r:'Uncommon',d:'+1 max HP',hp:1,w:28,m:'#a06a3a',dk:'#5e3818',tr:'#dca868'},
chain:{n:'Chainmail Hauberk',r:'Rare',d:'+1 max HP and a starting shield',hp:1,sh:1,w:14,m:'#a4b2c4',dk:'#586678',tr:'#e6eef8'},
shadow:{n:'Shadowweave',r:'Rare',d:'+1 max HP, enemies 5% slower',hp:1,sl:.95,w:12,m:'#3b2f60',dk:'#160e2a',tr:'#b06bff'},
plate:{n:'Knight Plate',r:'Epic',d:'+2 max HP',hp:2,w:6,m:'#cdd8f2',dk:'#7382a8',tr:'#ffd76a'},
glacier:{n:'Glacier Regalia',r:'Epic',d:'+2 max HP, enemies 8% slower',hp:2,sl:.92,w:5,m:'#a8e4ff',dk:'#4a86b8',tr:'#ffffff'},
dragon:{n:'Dragonscale',r:'Legendary',d:'+2 max HP, 2 starting shields',hp:2,sh:2,w:2,m:'#c83a3a',dk:'#5a1016',tr:'#ffb84a'},
sun:{n:'Sunforged Aegis',r:'Legendary',d:'+3 max HP, a shield, +10% score',hp:3,sh:1,sc:1.1,w:1.5,m:'#ffd24a',dk:'#a8701a',tr:'#fff6c0'},
pelt:{n:"Hunter's Pelt",r:'Uncommon',d:'+1 max HP, foes 3% slower',hp:1,sl:.97,w:24,m:'#9a6a3c',dk:'#4a3018',tr:'#f4f0e4',base:'leather'},
bone:{n:'Bonewrought Mail',r:'Rare',d:'+1 max HP and +5% score',hp:1,sc:1.05,w:11,m:'#e8e2cc',dk:'#8a8470',tr:'#7fffd0',base:'chain',acc:'#7fffd0',tier:2},
jade:{n:'Jade Warden',r:'Rare',d:'+1 max HP and a starting shield',hp:1,sh:1,w:10,m:'#5ad08a',dk:'#1f6a44',tr:'#e8ffd0',base:'plate',acc:'#9affc0',tier:2},
ember:{n:'Emberforged Plate',r:'Epic',d:'+2 max HP and +6% score',hp:2,sc:1.06,w:6,m:'#4a3a44',dk:'#14101a',tr:'#ff8a2a',base:'plate',acc:'#ff8a2a',tier:3},
tide:{n:'Tidecaller Scale',r:'Epic',d:'+2 max HP, foes 7% slower',hp:2,sl:.93,w:5,m:'#3ac8c0',dk:'#146a78',tr:'#d8fff8',base:'dragon',acc:'#8ff8e8',tier:3},
nightsong:{n:'Nightsong Raiment',r:'Epic',d:'+1 max HP, foes 10% slower',hp:1,sl:.9,w:5,m:'#3a4a98',dk:'#0c1236',tr:'#cfe0ff',base:'shadow',acc:'#9ac0ff',tier:3},
thunder:{n:'Stormcaller Plate',r:'Legendary',d:'+2 max HP, 2 starting shields',hp:2,sh:2,w:1.2,m:'#e8d84a',dk:'#5a4a10',tr:'#8ad4ff',base:'plate',acc:'#fff36a',tier:4},
blood:{n:'Bloodmoon Regalia',r:'Legendary',d:'+3 max HP and +12% score',hp:3,sc:1.12,w:1.2,m:'#a01028',dk:'#2a0208',tr:'#ff5a70',base:'dragon',acc:'#ff5a70',tier:4},
void:{n:'Voidwalker Shroud',r:'Legendary',d:'+2 max HP, a shield, foes 10% slower',hp:2,sl:.9,sh:1,w:1,m:'#22103c',dk:'#05020e',tr:'#ff6ad8',base:'shadow',acc:'#ff6ad8',tier:4},
ascend:{n:'Ascendant Panoply',r:'Mythic',d:'+4 max HP, 2 shields, foes 12% slower, +18% score',hp:4,sh:2,sl:.88,sc:1.18,w:.1,m:'#fff4d0',dk:'#8a70c8',tr:'#ffffff',base:'sun',mythic:1,acc:'#ffffff',tier:4},
/* additional sets (same renderer kit, see AK in 30a_kit.js) */
smock:{n:"Weaver's Smock",r:'Common',d:'No bonus',w:40,m:'#a08a62',dk:'#6a583a',tr:'#d8c898'},
traveler:{n:"Wayfarer's Cloak",r:'Common',d:'No bonus',w:40,m:'#6a7a4a',dk:'#3a4a2a',tr:'#b8c48a'},
gambeson:{n:'Militia Gambeson',r:'Common',d:'No bonus',w:40,m:'#c8b890',dk:'#7a6a48',tr:'#8a6a3a'},
scout:{n:"Scout's Jerkin",r:'Uncommon',d:'+1 max HP',hp:1,w:26,m:'#5e7a3a',dk:'#2e4020',tr:'#d8c890'},
druid:{n:"Druid's Vestments",r:'Uncommon',d:'+1 max HP, foes 3% slower',hp:1,sl:.97,w:22,m:'#6a9a4a',dk:'#2e5a2a',tr:'#e8dca0',acc:'#b8f08a',tier:2},
studded:{n:'Studded Jack',r:'Uncommon',d:'+1 max HP and +3% score',hp:1,sc:1.03,w:22,m:'#7a5a3a',dk:'#3a2818',tr:'#c8c0b0'},
brigandine:{n:'Ironclad Brigandine',r:'Rare',d:'+1 max HP and a starting shield',hp:1,sh:1,w:11,m:'#6a3040',dk:'#2a1218',tr:'#d8b860',acc:'#ffd890',tier:2},
monk:{n:'Crimson Monk Robes',r:'Rare',d:'+1 max HP and +6% score',hp:1,sc:1.06,w:10,m:'#d04a30',dk:'#6a1c14',tr:'#ffd76a',acc:'#ffd76a',tier:2},
dwarf:{n:'Dwarfforged Mail',r:'Rare',d:'+1 max HP, a shield, foes 3% slower',hp:1,sh:1,sl:.97,w:9,m:'#8a7a68',dk:'#3a3028',tr:'#d8a848',acc:'#ffcf6a',tier:2},
samurai:{n:'Ronin Lacquer',r:'Epic',d:'+2 max HP and +8% score',hp:2,sc:1.08,w:5,m:'#b02830',dk:'#1a1014',tr:'#e8c860',acc:'#ffd070',tier:3},
crusader:{n:"Crusader's Aegis",r:'Epic',d:'+2 max HP and a starting shield',hp:2,sh:1,w:5,m:'#d8dce8',dk:'#6a7488',tr:'#d8b048',acc:'#ffe08a',tier:3},
verdant:{n:'Verdant Warden',r:'Epic',d:'+2 max HP, foes 6% slower',hp:2,sl:.94,w:5,m:'#4a8a3a',dk:'#1e3a1a',tr:'#d8e8a0',acc:'#b8f070',tier:3},
phoenix:{n:'Phoenix Regalia',r:'Legendary',d:'+3 max HP and +10% score',hp:3,sc:1.1,w:1.1,m:'#d8402a',dk:'#6a1408',tr:'#ffc850',acc:'#ffb040',tier:4},
revenant:{n:'Revenant Plate',r:'Legendary',d:'+2 max HP, a shield, foes 8% slower',hp:2,sh:1,sl:.92,w:1,m:'#2a3a34',dk:'#0a1410',tr:'#7affc0',acc:'#7affc0',tier:4},
titan:{n:'Titanforge Bulwark',r:'Legendary',d:'+3 max HP and 2 starting shields',hp:3,sh:2,w:.9,m:'#a8743a',dk:'#4a2e14',tr:'#e8c870',acc:'#ffc060',tier:4},
eclipse:{n:'Eclipse Sovereign',r:'Mythic',d:'+4 max HP, 3 shields, foes 10% slower, +12% score',hp:4,sh:3,sl:.9,sc:1.12,w:.1,m:'#1c1840',dk:'#08051c',tr:'#ffd76a',acc:'#ffd05a',tier:4,mythic:2}};
/* weapon paths: each path has its own weapons, unlocked by player level */
const PATHS={
knight:{n:'Knight',lv:1,c:'#ffc94a',st:'rusty',d:'Start every run with a shield.',sh:1},
archer:{n:'Archer',lv:4,c:'#7dffb0',st:'hunter',d:'Fury charges 25% faster. Finishing a word looses a single arrow.',fu:1.25},
mage:{n:'Mage',lv:7,c:'#c86bff',st:'twig',d:'Every 4th kill unleashes an arcane bolt that also strikes a second monster.',ev:4},
rogue:{n:'Rogue',lv:10,c:'#ff5c8a',st:'shiv',d:'Each word forgives two slips. 20% of kills are critical hits worth double.',fg:1,cr:.2}};
const PK=Object.keys(PATHS);
Object.assign(WP,{
hunter:{n:'Hunting Bow',r:'Common',d:'No bonus',w:40,t:'bow',c:'#a0703a',p:'archer'},
yew:{n:'Yew Longbow',r:'Uncommon',d:'+10% score',sc:1.1,w:14,t:'bow',c:'#d8b070',p:'archer'},
recurve:{n:'Ranger Recurve',r:'Uncommon',d:'Fury charges 15% faster',fu:1.15,w:14,t:'bow',c:'#6a8a4a',p:'archer'},
frostbow:{n:'Frostwind Bow',r:'Rare',d:'Enemies 8% slower',sl:.92,w:8,t:'bow',c:'#9fe0ff',p:'archer'},
serpent:{n:'Serpent Bow',r:'Rare',d:'Combos build faster',cq:1,w:8,t:'bow',c:'#7dff5f',p:'archer'},
phoenix:{n:'Phoenix Bow',r:'Epic',d:'Fury charges 30% faster, +10% score',fu:1.3,sc:1.1,w:4,t:'bow',c:'#ff8a3a',p:'archer'},
skyfall:{n:'Skyfall',r:'Legendary',d:'Faster combos, +25% score, fury +25%',cq:1,sc:1.25,fu:1.25,w:1.5,t:'bow',c:'#ffe36a',p:'archer'},
twig:{n:'Gnarled Staff',r:'Common',d:'No bonus',w:40,t:'staff',c:'#7a5a3a',p:'mage'},
sparkwand:{n:'Spark Wand',r:'Uncommon',d:'+10% score',sc:1.1,w:14,t:'wand',c:'#ffe36a',p:'mage'},
crystal:{n:'Crystal Staff',r:'Uncommon',d:'Fury charges 15% faster',fu:1.15,w:14,t:'staff',c:'#7fd8ff',p:'mage'},
arcane:{n:'Arcane Rod',r:'Rare',d:'Enemies 10% slower',sl:.9,w:8,t:'wand',c:'#c86bff',p:'mage'},
emberstaff:{n:'Emberstaff',r:'Rare',d:'Combos build faster',cq:1,w:8,t:'staff',c:'#ff8a3a',p:'mage'},
tempest:{n:'Tempest Staff',r:'Epic',d:'Fury charges 30% faster, enemies 5% slower',fu:1.3,sl:.95,w:4,t:'staff',c:'#5fb4ff',p:'mage'},
astral:{n:'Astral Scepter',r:'Legendary',d:'Enemies 8% slower, +30% score, fury +30%',sl:.92,sc:1.3,fu:1.3,w:1.5,t:'wand',c:'#f0b8ff',p:'mage'},
shiv:{n:'Rusted Shiv',r:'Common',d:'No bonus',w:40,t:'dagger',c:'#9a9aa6',p:'rogue'},
stiletto:{n:'Stiletto',r:'Uncommon',d:'+10% score',sc:1.1,w:14,t:'dagger',c:'#dfe6f5',p:'rogue'},
scimitar:{n:'Desert Scimitar',r:'Uncommon',d:'Combos build faster',cq:1,w:14,t:'katana',c:'#e8d8b0',p:'rogue'},
nightfang:{n:'Nightfang',r:'Rare',d:'Enemies 8% slower',sl:.92,w:8,t:'dagger',c:'#9a6bff',p:'rogue'},
ronin:{n:'Ronin Katana',r:'Rare',d:'+15% score',sc:1.15,w:8,t:'katana',c:'#eef4ff',p:'rogue'},
bloodthorn:{n:'Bloodthorn',r:'Epic',d:'Faster combos, +10% score',cq:1,sc:1.1,w:4,t:'katana',c:'#ff3b5c',p:'rogue'},
umbra:{n:'Umbral Edge',r:'Legendary',d:'Faster combos, fury +30%, +25% score',cq:1,fu:1.3,sc:1.25,w:1.5,t:'katana',c:'#b06bff',p:'rogue'}});
/* mythic weapons: one per weapon category, far rarer than legendary */
Object.assign(WP,{
m_sword:{n:'Worldsplitter',r:'Mythic',d:'Slower foes, +50% score, fury +40%, faster combos',sl:.85,sc:1.5,fu:1.4,cq:1,w:.07,t:'sword',c:'#ff4d94',h:340},
m_dagger:{n:'Fatebreaker',r:'Mythic',d:'Slower foes, +45% score, fury +35%, faster combos',sl:.88,sc:1.45,fu:1.35,cq:1,w:.07,t:'dagger',c:'#4dffd2',h:165},
m_katana:{n:'Kagutsuchi',r:'Mythic',d:'Slower foes, +50% score, fury +40%, faster combos',sl:.87,sc:1.5,fu:1.4,cq:1,w:.07,t:'katana',c:'#ff7a3d',h:20,p:'rogue'},
m_mace:{n:'Cataclysm',r:'Mythic',d:'Slower foes, +40% score, fury +60%',sl:.85,sc:1.4,fu:1.6,w:.07,t:'mace',c:'#ffd93d',h:50},
m_axe:{n:'Ragnarok',r:'Mythic',d:'Slower foes, +45% score, fury +50%, faster combos',sl:.86,sc:1.45,fu:1.5,cq:1,w:.07,t:'axe',c:'#ff3d3d',h:0},
m_spear:{n:'Aetherlance',r:'Mythic',d:'Slower foes, +55% score, fury +35%, faster combos',sl:.88,sc:1.55,fu:1.35,cq:1,w:.07,t:'spear',c:'#3dc8ff',h:195},
m_scythe:{n:'Soulharvest',r:'Mythic',d:'Slower foes, +45% score, fury +60%, faster combos',sl:.88,sc:1.45,fu:1.6,cq:1,w:.07,t:'scythe',c:'#9d4dff',h:270},
m_bow:{n:'Starfall Longbow',r:'Mythic',d:'Slower foes, +50% score, fury +45%, faster combos',sl:.88,sc:1.5,fu:1.45,cq:1,w:.07,t:'bow',c:'#8dff4d',h:100,p:'archer'},
m_staff:{n:'Worldroot Staff',r:'Mythic',d:'Slower foes, +45% score, fury +55%, faster combos',sl:.85,sc:1.45,fu:1.55,cq:1,w:.07,t:'staff',c:'#4dff7a',h:135,p:'mage'},
m_wand:{n:'Infinity Wand',r:'Mythic',d:'Slower foes, +60% score, fury +45%, faster combos',sl:.86,sc:1.6,fu:1.45,cq:1,w:.07,t:'wand',c:'#d94dff',h:295,p:'mage'}});
/* seven more mythic weapons, each with its own signature art (29b_mythart.js) */
Object.assign(WP,{
m_sword2:{n:'Dawnbreaker',r:'Mythic',d:'Slower foes, +45% score, fury +50%, faster combos',sl:.86,sc:1.45,fu:1.5,cq:1,w:.07,t:'sword',c:'#ffe27a',h:48},
m_dagger2:{n:'Voidfang',r:'Mythic',d:'Slower foes, +50% score, fury +40%, faster combos',sl:.87,sc:1.5,fu:1.4,cq:1,w:.07,t:'dagger',c:'#a040ff',h:278,p:'rogue'},
m_katana2:{n:'Tsukuyomi',r:'Mythic',d:'Slower foes, +55% score, fury +35%, faster combos',sl:.88,sc:1.55,fu:1.35,cq:1,w:.07,t:'katana',c:'#bcd0ff',h:222,p:'rogue'},
m_bow2:{n:'Sunpiercer',r:'Mythic',d:'Slower foes, +50% score, fury +50%, faster combos',sl:.87,sc:1.5,fu:1.5,cq:1,w:.07,t:'bow',c:'#ffb02e',h:36,p:'archer'},
m_staff2:{n:'Astral Orrery',r:'Mythic',d:'Slower foes, +50% score, fury +45%, faster combos',sl:.86,sc:1.5,fu:1.45,cq:1,w:.07,t:'staff',c:'#6ac8ff',h:200,p:'mage'},
m_mace2:{n:'Stormhammer',r:'Mythic',d:'Slower foes, +45% score, fury +55%',sl:.85,sc:1.45,fu:1.55,w:.07,t:'mace',c:'#8ae8ff',h:188}});
/* the second armoury: eleven more archer weapons, ten each for the mage and the rogue (art in 29c/29d/29e). They bring three new stats: cr crit chance, gm gold, ch chance a kill chains to another foe */
Object.assign(WP,{
willow:{n:'Willow Shortbow',r:'Common',d:'+5% score',sc:1.05,w:40,t:'bow',c:'#c8b878',p:'archer',nw:1},
driftbow:{n:'Driftwood Bow',r:'Common',d:'+10% gold',gm:.1,w:40,t:'bow',c:'#9a8a78',p:'archer',nw:1},
thornwood:{n:'Thornwood Bow',r:'Uncommon',d:'+5% crit chance',cr:.05,w:14,t:'bow',c:'#8a4a3a',p:'archer',nw:1},
gilded:{n:'Gilded Longbow',r:'Uncommon',d:'+15% gold',gm:.15,w:14,t:'bow',c:'#f0e6c8',p:'archer',nw:1},
stormcall:{n:'Stormcaller Bow',r:'Rare',d:'6% chance a kill chains to another foe',ch:.06,w:8,t:'bow',c:'#7a8aff',p:'archer',nw:1},
wyrmbone:{n:'Wyrmbone Bow',r:'Rare',d:'+8% crit chance',cr:.08,w:8,t:'bow',c:'#e8e0c8',p:'archer',nw:1},
duskwing:{n:'Duskwing Bow',r:'Epic',d:'Enemies 8% slower, +8% crit chance',sl:.92,cr:.08,w:4,t:'bow',c:'#8a5ad8',p:'archer',nw:1},
coral:{n:'Reefsong Bow',r:'Epic',d:'+25% gold, +10% score',gm:.25,sc:1.1,w:4,t:'bow',c:'#ff8a7a',p:'archer',nw:1},
thunderbird:{n:'Thunderbird',r:'Legendary',d:'Faster combos, chain 8%, +20% score',cq:1,ch:.08,sc:1.2,w:1.2,t:'bow',c:'#8aeaff',p:'archer',nw:1},
wraith:{n:'Wraithstring',r:'Legendary',d:'Slower foes, +12% crit, fury +25%',sl:.92,cr:.12,fu:1.25,w:1.2,t:'bow',c:'#9affc8',p:'archer',nw:1},
m_bow3:{n:"Orion's Oath",r:'Mythic',d:'Slower foes, +45% score, fury +40%, faster combos, +10% crit',sl:.87,sc:1.45,fu:1.4,cq:1,cr:.1,w:.07,t:'bow',c:'#8ab4ff',h:225,p:'archer',nw:1},
candle:{n:'Candlewick Wand',r:'Common',d:'+5% score',sc:1.05,w:40,t:'wand',c:'#f0e4c0',p:'mage',nw:1},
shroom:{n:'Sporecap Staff',r:'Common',d:'+10% gold',gm:.1,w:40,t:'staff',c:'#8a6a4a',p:'mage',nw:1},
lantern:{n:'Wisp Lantern',r:'Uncommon',d:'Enemies 5% slower',sl:.95,w:14,t:'staff',c:'#6a5a4a',p:'mage',nw:1},
quill:{n:"Scribe's Quill",r:'Uncommon',d:'+5% crit chance',cr:.05,w:14,t:'wand',c:'#e8e0f0',p:'mage',nw:1},
tidal:{n:'Tidecaller Staff',r:'Rare',d:'6% chance a kill chains to another foe',ch:.06,w:8,t:'staff',c:'#3ac8d8',p:'mage',nw:1},
watcher:{n:"Watcher's Wand",r:'Rare',d:'+8% crit chance',cr:.08,w:8,t:'wand',c:'#6a3a8a',p:'mage',nw:1},
hourglass:{n:'Hourglass Staff',r:'Epic',d:'Enemies 12% slower, fury +20%',sl:.88,fu:1.2,w:4,t:'staff',c:'#c8a05a',p:'mage',nw:1},
prism:{n:'Prismatic Rod',r:'Epic',d:'+12% score, +8% crit chance',sc:1.12,cr:.08,w:4,t:'wand',c:'#e8f0ff',p:'mage',nw:1},
soulcage:{n:'Soulcage',r:'Legendary',d:'Slower foes, chain 10%, +25% score',sl:.9,ch:.1,sc:1.25,w:1.2,t:'staff',c:'#7affb0',p:'mage',nw:1},
midas:{n:'Midas Scepter',r:'Legendary',d:'+40% gold, +25% score, fury +20%',gm:.4,sc:1.25,fu:1.2,w:1.2,t:'wand',c:'#ffd24a',p:'mage',nw:1},
kunai:{n:'Iron Kunai',r:'Common',d:'+5% score',sc:1.05,w:40,t:'dagger',c:'#a8acb8',p:'rogue',nw:1},
bokken:{n:'Wooden Bokken',r:'Common',d:'+10% gold',gm:.1,w:40,t:'katana',c:'#b88a52',p:'rogue',nw:1},
cutlass:{n:'Corsair Cutlass',r:'Uncommon',d:'+15% gold',gm:.15,w:14,t:'katana',c:'#d8dce8',p:'rogue',nw:1},
kris:{n:'Flamewave Kris',r:'Uncommon',d:'+5% crit chance',cr:.05,w:14,t:'dagger',c:'#e8a060',p:'rogue',nw:1},
obsidian:{n:'Obsidian Dirk',r:'Rare',d:'+8% crit chance',cr:.08,w:8,t:'dagger',c:'#3a3048',p:'rogue',nw:1},
windcutter:{n:'Windcutter',r:'Rare',d:'Enemies 10% slower',sl:.9,w:8,t:'katana',c:'#c8f0e0',p:'rogue',nw:1},
jester:{n:"Jester's Jape",r:'Epic',d:'+10% crit chance, +15% gold',cr:.1,gm:.15,w:4,t:'dagger',c:'#ff5ad0',p:'rogue',nw:1},
oni:{n:"Oni's Fang",r:'Epic',d:'Fury charges 25% faster, +8% crit chance',fu:1.25,cr:.08,w:4,t:'katana',c:'#d8302a',p:'rogue',nw:1},
ryujin:{n:"Ryujin's Scale",r:'Legendary',d:'Faster combos, chain 8%, +20% score',cq:1,ch:.08,sc:1.2,w:1.2,t:'katana',c:'#3ae0b0',p:'rogue',nw:1},
heartseeker:{n:'Heartseeker',r:'Legendary',d:'+18% crit, +20% score, +20% gold',cr:.18,sc:1.2,gm:.2,w:1.2,t:'dagger',c:'#ff3a6a',p:'rogue',nw:1}});
/* keep the mythic weapon total the same however many there are */
{const ks=Object.keys(WP).filter(k=>WP[k].r==='Mythic');for(const k of ks)WP[k].w=.77/ks.length}
for(const k in WP)WP[k].p=WP[k].p||'knight';
/* normal weapon crates: knight swords and daggers only. Special crates: everything else */
const isSpecial=id=>WP[id].p!=='knight'||!['sword','dagger'].includes(WP[id].t);
const PRICE={w:450,a:500,s:700,p:15000},GOLDDUP={Common:15,Uncommon:30,Rare:60,Epic:120,Legendary:300,Mythic:900};
/* drop odds: epic and legendary are much harder to find, rare a little harder */
const RW={Common:1,Uncommon:1,Rare:1.3,Epic:.65,Legendary:.5,Mythic:1.5};
const PRN=['I','II','III','IV','V','VI','VII','VIII','IX','X'];
[['Vanguard Plate','Epic','plate','#c88a4a','#5a3416','#ffb070',2,1,1.08,1],['Silverguard Harness','Epic','plate','#dfe6f0','#6a7488','#ffffff',3,1,1.12,.97],['Goldensworn Panoply','Legendary','plate','#ffd24a','#a8701a','#fff6c0',3,2,1.16,.95],['Sapphire Regent','Legendary','glacier','#4a8aff','#14307a','#bfe0ff',4,2,1.2,.94],['Crimson Paragon','Legendary','dragon','#e0304a','#5a0a18','#ffb0b8',4,2,1.25,.92],['Emerald Sovereign','Legendary','plate','#3ad07a','#0c4a2a','#c8ffd8',5,3,1.3,.9],['Amethyst Archon','Legendary','shadow','#a860ff','#301060','#f0d0ff',5,3,1.36,.88],['Obsidian Overlord','Legendary','dragon','#2a2a38','#08080e','#ff8a3a',6,3,1.42,.86],['Solar Exemplar','Legendary','sun','#fff0a0','#c88a10','#ffffff',6,4,1.5,.84],['Eternal Champion','Mythic','plate','#ffffff','#8a70c8','#ffffff',7,4,1.6,.8]].forEach((q,i)=>{AR['pr'+(i+1)]={n:q[0],r:q[1],d:`Prestige ${PRN[i]} exclusive: +${q[6]} max HP, ${q[7]} shield${q[7]>1?'s':''}, ${q[9]<1?'foes '+Math.round((1-q[9])*100)+'% slower, ':''}+${Math.round((q[8]-1)*100)}% score`,hp:q[6],sh:q[7],sc:q[8],sl:q[9],w:0,m:q[3],dk:q[4],tr:q[5],base:q[2],acc:q[5],tier:i<3?3:4,pr:i+1,mythic:i===9?1:0}});
for(const o of[WP,AR])for(const k in o){o[k].col=RC[o[k].r];o[k].w*=RW[o[k].r]}
/* the new weapons add variety, not luck: each rarity keeps the same total share of the special crates it always had */
{const sp=Object.keys(WP).filter(isSpecial),T={};for(const r of Object.keys(RC)){if(r==='Mythic')continue;const all=sp.filter(k=>WP[k].r===r),old=all.filter(k=>!WP[k].nw),a=all.reduce((n,k)=>n+WP[k].w,0),b=old.reduce((n,k)=>n+WP[k].w,0);if(a&&b)for(const k of all)WP[k].w*=b/a}}
/* keep each rarity's total drop share the same however many sets it holds (Common 50, Uncommon 52, Rare 61, Epic 17.5, Legendary 3.45, Mythic .15) */
{const T0={Common:50,Uncommon:52,Rare:61.1,Epic:17.55,Legendary:3.45,Mythic:.15},S0={};for(const k in AR)if(!AR[k].pr)S0[AR[k].r]=(S0[AR[k].r]||0)+AR[k].w;for(const k in AR)if(!AR[k].pr&&S0[AR[k].r])AR[k].w*=T0[AR[k].r]/S0[AR[k].r]}

/* boons: 4 rarities. u = unique group (can only be taken once per run) */
function slowBy(s,f){s.slow=Math.max(.6,s.slow*f)}
const heal=(s,n)=>{s.hp=Math.min(s.max,s.hp+n)};
const BOONS=[
{n:'Aegis',i:'🛡️',d:'Block the next hit',r:0,f:s=>s.shield++},
{n:'Feast',i:'🍖',d:'Restore 2 HP',r:0,f:s=>heal(s,2)},
{n:'Frost Rune',i:'❄️',d:'Enemies 6% slower',r:0,f:s=>slowBy(s,.94)},
{n:'Fortune',i:'🪙',d:'+8% score',r:0,f:s=>{s.sc*=1.08}},
{n:'Whetstone',i:'🗡️',d:'Fury charges 15% faster',r:0,f:s=>{s.furyMul*=1.15}},
{n:'Poultice',i:'🌿',d:'Restore 1 HP and gain a shield',r:0,f:s=>{heal(s,1);s.shield++}},
{n:'Lucky Charm',i:'🍀',d:'Slightly better crate chance',r:0,f:s=>{s.cl+=.01}},
{n:'Iron Heart',i:'❤️',d:'+1 max HP and heal 1',r:1,f:s=>{s.max++;heal(s,1)}},
{n:'Rage Tonic',i:'🔥',d:'Fury charges 30% faster',r:1,f:s=>{s.furyMul*=1.3}},
{n:'Quickblade',i:'⚡',d:'Combos build faster',r:1,f:s=>{s.cq++}},
{n:'Crate Lure',i:'📦',d:'Better crate chance',r:1,f:s=>{s.cl+=.02}},
{n:'Storm Charge',i:'🌩️',d:'Fill your fury bar now',r:1,f:s=>{s.fury=100}},
{n:'Ward Stone',i:'🔮',d:'Gain 2 shields',r:1,f:s=>{s.shield+=2}},
{n:'Bloodthirst',i:'🩸',d:'Heal 1 HP every 10 kills',r:1,u:'vamp',f:s=>{s.vamp=1}},
{n:'Steady Grip',i:'🧤',d:'Each word forgives one more slip',r:1,u:'fg',f:s=>{s.fg++}},
{n:'Second Wind',i:'🕊️',d:'Survive one deadly hit',r:2,f:s=>{s.rev++}},
{n:'Time Warp',i:'⏳',d:'Enemies 15% slower. Only one time boon per run.',r:2,u:'tw',f:s=>slowBy(s,.85)},
{n:'Titan Heart',i:'💖',d:'+2 max HP, heal fully',r:2,f:s=>{s.max+=2;s.hp=s.max}},
{n:'Chain Lightning',i:'⛓️',d:'Kills have a 25% chance to strike another monster',r:2,u:'chain',f:s=>{s.chain=Math.max(s.chain,.25)}},
{n:'Golden Touch',i:'✨',d:'+25% score',r:2,f:s=>{s.sc*=1.25}},
{n:'Bulwark',i:'🏰',d:'Gain a shield at the start of every round',r:2,u:'regen',f:s=>{s.regen=1;s.shield++}},
{n:'Phoenix Heart',i:'🐦‍🔥',d:'+1 max HP. Once, rise from death at full health',r:3,f:s=>{s.max++;s.rev++;s.revFull=1}},
{n:'Chrono Sovereign',i:'⌛',d:'Enemies 22% slower and fury +25%. Counts as your time boon',r:3,u:'tw',f:s=>{slowBy(s,.78);s.furyMul*=1.25}},
{n:'Thunder God',i:'⚡',d:'Fury starts every round full, and charges 20% faster',r:3,u:'thund',f:s=>{s.thund=1;s.furyMul*=1.2;s.fury=100}},
{n:'Midas Touch',i:'👑',d:'+50% score and much better crate chance',r:3,f:s=>{s.sc*=1.5;s.cl+=.04}},
{n:'Blood Moon',i:'🌕',d:'+30% score. Heal 1 HP whenever you break a boss phase',r:3,u:'moon',f:s=>{s.sc*=1.3;s.moon=1}},
{n:'Eternal Bulwark',i:'⚜️',d:'Gain 3 shields, then a shield every round',r:3,u:'regen',f:s=>{s.shield+=3;s.regen=1}},
{n:'Lucky Penny',d:'+5% score and a touch better crate chance',r:0,f:s=>{s.sc*=1.05;s.cl+=.005}},
{n:'Hearth Bread',d:'Restore 1 HP and gain a quarter of your fury',r:0,f:s=>{heal(s,1);s.fury=Math.min(100,s.fury+25)}},
{n:'Pebble Ward',d:'Gain a shield. Enemies 2% slower',r:0,f:s=>{s.shield++;slowBy(s,.98)}},
{n:'Ember Charm',d:'Fury charges 10% faster and +3% score',r:0,f:s=>{s.furyMul*=1.1;s.sc*=1.03}},
{n:"Scholar's Quill",d:'+12% score and fury charges 10% faster',r:1,f:s=>{s.sc*=1.12;s.furyMul*=1.1}},
{n:'Moonstone',d:'Enemies 8% slower and gain a shield',r:1,f:s=>{slowBy(s,.92);s.shield++}},
{n:'Brave Banner',d:'+1 max HP and +6% score',r:1,f:s=>{s.max++;s.sc*=1.06}},
{n:'Spark Vial',d:'Fury jumps to at least 60% and charges 10% faster',r:1,f:s=>{s.fury=Math.max(s.fury,60);s.furyMul*=1.1}},
{n:'Sentinel Crest',d:'+1 max HP, heal 1 and gain 2 shields',r:2,f:s=>{s.max++;heal(s,1);s.shield+=2}},
{n:'Gilded Compass',d:'+15% score and better crate chance',r:2,f:s=>{s.sc*=1.15;s.cl+=.02}},
{n:'Tempest Feather',d:'Fury charges 25% faster and combos build faster',r:2,f:s=>{s.furyMul*=1.25;s.cq++}},
{n:"Dragon's Hoard",d:'+35% score and gain 2 shields',r:3,u:'hoard',f:s=>{s.sc*=1.35;s.shield+=2}},
{n:"Valkyrie's Blessing",d:'+2 max HP, heal fully, enemies 8% slower',r:3,u:'valk',f:s=>{s.max+=2;s.hp=s.max;slowBy(s,.92)}}];
const BOONCAP=12;
const BG={Aegis:['shield'],'Ward Stone':['shield'],Poultice:['shield','heal'],Bulwark:['shield'],'Eternal Bulwark':['shield'],Feast:['heal'],'Iron Heart':['hp'],'Titan Heart':['hp'],'Phoenix Heart':['hp'],'Frost Rune':['slow'],'Time Warp':['slow'],'Chrono Sovereign':['slow','fury'],Fortune:['score'],'Golden Touch':['score'],'Midas Touch':['score','crate'],'Blood Moon':['score'],Whetstone:['fury'],'Rage Tonic':['fury'],'Thunder God':['fury'],'Storm Charge':['fury'],'Lucky Charm':['crate'],'Crate Lure':['crate']};
Object.assign(BG,{'Lucky Penny':['score','crate'],'Hearth Bread':['heal','fury'],'Pebble Ward':['shield'],'Ember Charm':['fury','score'],"Scholar's Quill":['score','fury'],Moonstone:['slow','shield'],'Brave Banner':['hp','score'],'Spark Vial':['fury'],'Sentinel Crest':['hp','shield'],'Gilded Compass':['score','crate'],'Tempest Feather':['fury'],"Dragon's Hoard":['score','shield'],"Valkyrie's Blessing":['hp','slow']});
const boonW=(b,s)=>{let w=1;for(const g of BG[b.n]||[b.n])w*=Math.pow(.28,s.gc[g]||0);return w*Math.pow(.6,s.gc['n:'+b.n]||0)};
const BR=['Common','Rare','Epic','Legendary'],BC=['#b8b8b8','#5fb4ff','#c86bff','#ffb02e'];

/* ---------- zones ---------- */
const ZN=[
{n:'Goblin Woods',a:'#5fd97a',h:135,sky:['#050f0b','#1d4a33'],m:['gob','bat','troll'],b:'bGob',bn:'Goblin King',pl:'the goblin woods'},
{n:'Crypt of Bones',a:'#9fe8ff',h:215,sky:['#070a16','#2b3a63'],m:['skel','ghost','zomb'],b:'bLich',bn:'Crypt Lord',pl:'the forgotten crypt'},
{n:'Spider Caverns',a:'#c86bff',h:285,sky:['#0a0514','#33194f'],m:['snake','spid','scor'],b:'bQueen',bn:'Web Queen',pl:'the spider caverns'},
{n:'Ember Keep',a:'#ff6a3a',h:14,sky:['#150404','#6a200c'],m:['imp','flame','brute'],b:'bDemon',bn:'Ember Tyrant',pl:'the burning keep'},
{n:'Frozen Peaks',a:'#7fd8ff',h:195,sky:['#081426','#4f86b8'],m:['fsk','wolf','yeti'],b:'bWyrm',bn:'Frost Wyrm',pl:'the frozen peaks'},
{n:'Sunken Ruins',a:'#4fe0c0',h:170,sky:['#021018','#0b6070'],m:['crab','fish','octo'],b:'bKraken',bn:'Tide Ravager',pl:'the drowned ruins'}];
const ACTS=['The Awakening','Rising Darkness','The Long Gauntlet','Legends of War','The Final Reckoning'];
/* level rules: each campaign level can change how the fight plays */
const MODS={fog:{n:'Creeping Fog',d:'Words stay hidden until monsters get close.'},dark:{n:'Endless Night',d:'Darkness hides the field, but words stay visible.'},swarm:{n:'Swarm',d:'More monsters, arriving faster.'},giants:{n:'Giants',d:'Fewer, tougher monsters with long words.'},gusts:{n:'Howling Gusts',d:'Monsters surge forward in sudden bursts.'},frenzy:{n:'Frenzy',d:'Monsters speed up as each round goes on.'},ranged:{n:'Marksmen',d:'Many monsters attack from range. Parry with SPACE.'},elite:{n:'Elite Guard',d:'Many elite monsters, worth double points.'},finale:{n:'Final Stand',d:'Frenzied monsters, and many of them shoot.'}};
/* [name, base scene, tint, sky, weather, props, monsters (walker, diver, tank), boss art, boss name, place, rule, boss hue, blurb] */
const LVD=[
['Goblin Woods',0,0,0,0,0,['gob','bat','troll'],'bGob','Goblin King','the goblin woods',0,0,'A moonlit forest crawling with goblins.'],
['Crypt of Bones',1,0,0,0,0,['skel','ghost','zomb'],'bLich','Crypt Lord','the forgotten crypt',0,0,'Old graves stir beneath a pale moon.'],
['Spider Caverns',2,0,0,0,0,['snake','spid','scor'],'bQueen','Web Queen','the spider caverns',0,0,'Glowing crystals light a nest of silk.'],
['Ember Keep',3,0,0,0,0,['imp','flame','brute'],'bDemon','Ember Tyrant','the burning keep',0,0,'A fortress burning above a river of lava.'],
['Frozen Peaks',4,0,0,'snow',0,['fsk','wolf','yeti'],'bWyrm','Frost Wyrm','the frozen peaks','gusts',0,'Blizzard winds push the horde ever faster.'],
['Sunken Ruins',5,0,0,0,0,['crab','fish','octo'],'bKraken','Tide Ravager','the drowned ruins','fog',0,'Murky water hides every word until they close in.'],
['Haunted Farmlands',0,'#7a3aa8',['#0e0618','#4a2a6a'],'motes','scarecrow',['skel','bat','zomb'],'scarecrow','Scarecrow King','the haunted farmlands','dark',0,'Scarecrows watch a moonless field.'],
['Ashen Battlefield',3,'#7a7a88',['#0e0e12','#5a5a66'],'ash','banners',['skel','wolf','brute'],'warlord','Warlord Gorath','the ashen battlefield','swarm',0,'Torn banners mark a war that never ended.'],
['Cursed Marsh',0,'#4a9a3a',['#061208','#2a5a2a'],'spores','gallows',['snake','fish','troll'],'hydra','Bog Hydra','the cursed marsh','fog',0,'Gallows loom in the swamp mist.'],
['Moonlit Catacombs',1,'#3a5ac8',['#050a1c','#2a4a9a'],'motes','statues',['ghost','skel','zomb'],'golemS','Grave Warden','the moonlit catacombs','elite',0,'Statues of dead kings guard the deep tombs.'],
['Venom Hive',2,'#b0b02a',['#100e02','#5a5a12'],'spores','crystals',['snake','spid','scor'],'wasp','Hive Empress','the venom hive','ranged',0,'Toxic spores drift through the hive.'],
['Blazing Forge',3,'#ff9a2a',['#1a0800','#8a3a0a'],'embers','columns',['imp','flame','brute'],'ogre','Forge Overseer','the blazing forge','frenzy',0,'The anvils never cool, and neither do the foes.'],
['Crimson Forest',0,'#c82a3a',['#180508','#7a1a2a'],'spores','banners',['gob','wolf','troll'],'were','Blood Chieftain','the crimson forest','swarm',0,'The trees bleed red under a warband banner.'],
['Sunscorched Dunes',3,'#e8c060',['#2a1a08','#c8883a'],'sand','obelisk',['scor','snake','brute'],'scorpK','Sand Tyrant','the sunscorched dunes','gusts',0,'Sandstorms rage around ancient obelisks.'],
['Frostbitten Tundra',4,0,0,'snow','bones',['wolf','fsk','yeti'],'golemI','Winter Warden','the frozen tundra','fog',0,'Giant bones lie half buried in the snow.'],
['Drowned Cathedral',5,'#5a3ac8',['#040614','#2a2a7a'],'motes','arch',['ghost','crab','octo'],'angler','Abyssal Angler','the drowned cathedral','dark',0,'Sunken arches and silent, glowing water.'],
['Sky Bastion',4,'#9ac8ff',['#1a2a4a','#9ac8ff'],'wind','columns',['fsk','ghost','yeti'],'thunder','Storm Roc','the sky bastion','frenzy',0,'A fortress above the clouds, buffeted by wind.'],
['Molten Depths',3,'#ff4a1a',['#200400','#a82a0a'],'embers','bones',['flame','imp','brute'],'golemL','Lava Colossus','the molten depths','giants',0,'Titans wade through rivers of fire.'],
['Iron Fortress',1,'#8a8aa0',['#08080e','#4a4a5a'],'ash','banners',['skel','ghost','brute'],'marshal','Iron Marshal','the iron fortress','ranged',0,'Archers line the walls of a grey stronghold.'],
['Witchwood',0,'#5a1a8a',['#0a0416','#4a1a6a'],'spores','gallows',['snake','bat','troll'],'witch','Coven Mother','the witchwood','dark',0,'A cursed wood where no light survives.'],
['Bleeding Coast',5,'#c82a2a',['#180404','#7a1a1a'],'rain','masts',['crab','fish','octo'],'crabK','Crimson Crab King','the bleeding coast','swarm',0,'Wrecked ships and a red, rain-lashed sea.'],
['Shattered Citadel',3,'#6a6a9a',['#0a0a18','#4a4a7a'],'ash','columns',['imp','skel','brute'],'tyrantK','Citadel Tyrant','the shattered citadel','elite',0,'Broken pillars and the elite of a fallen army.'],
['Abyssal Grotto',2,'#1a6aa8',['#020a14','#0a4a7a'],'motes','crystals',['snake','fish','octo'],'serpent','Grotto Leviathan','the abyssal grotto','fog',0,'Blue crystals glow in a flooded cave.'],
['Storm Peaks',4,'#6a5aa8',['#0a0a1c','#3a3a7a'],'rain','obelisk',['fsk','wolf','yeti'],'dragonB','Thunder Drake','the storm peaks','gusts',0,'Lightning splits the sky above the summits.'],
['Twilight Wood',0,'#c88a2a',['#180c04','#8a5a1a'],'motes','lanterns',['gob','bat','troll'],'treant','Twilight King','the twilight wood','frenzy',0,'Lantern light glows in a golden, endless dusk.'],
['Necropolis',1,'#2ac88a',['#02100a','#1a6a4a'],'spores','statues',['ghost','zomb','skel'],'reaper','Necropolis Sovereign','the necropolis','swarm',0,'A green ghostfire city of the dead.'],
['Mantis Throne',2,'#c82a8a',['#14020c','#6a1a4a'],'spores','obelisk',['spid','scor','snake'],'mantis','Mantis Empress','the mantis throne','giants',0,'A mantis empress holds court in pink silk.'],
['Dragon Forge',3,'#ff2a2a',['#1a0202','#8a1010'],'embers','columns',['imp','flame','brute'],'dragonR','Dragon Tyrant','the dragon forge','ranged',0,'Where dragonfire was taught to shoot.'],
['Frozen Throne',4,'#4aa8ff',['#040a1c','#2a5aa8'],'snow','arch',['fsk','wolf','yeti'],'djinn','Frozen Sovereign','the frozen throne','dark',0,'A palace of ice under a starless sky.'],
['Sunken Throne',5,'#ffd76a',['#021010','#0a6a6a'],'motes','arch',['crab','fish','octo'],'seaKing','Abyssal King','the sunken throne','finale',0,'The last king waits in gold and darkness.']];
const LEVELS=LVD.map((x,i)=>({i,n:x[0],z:x[1],tint:x[2],sky:x[3],wx:x[4],prop:x[5],m:x[6],b:x[7],bn:x[8],bl:(x[8]==='Warlord Gorath'?'':'the ')+x[8].toLowerCase(),pl:x[9],mod:x[10],hue:x[11],blurb:x[12],a:x[2]?shade(x[2],.4):ZN[x[1]].a}));
const zoneIdx=w=>(S.rift||S.prac||S.gy||S.camp>30/*ASTRAL*/)?0:S.dc?S.dc.L.z:LEVELS[(((w-1)/5|0)%30+30)%30].z,lvOf=w=>(((w-1)/5)|0)+1,lvDef=w=>S.camp>30?ASTRAL[S.camp-31]/*ASTRAL*/:S.dc?S.dc.L:S.gy?GYLV[(lvOf(w)-1)%3]:S.rift?RIFTL:S.prac?PRACL:LEVELS[((lvOf(w)-1)%30+30)%30],lvN=n=>n>30?ASTRAL[n-31]/*ASTRAL*/:LEVELS[((n-1)%30+30)%30];

/* ---------- words ---------- */
const uniq=s=>[...new Set(s.split(/\s+/).filter(x=>/^[a-z]{3,}$/.test(x)))];
const GEN=uniq(`axe bow orb rune helm mace bolt fang claw gold flag horn keep moat oath pike rook tomb wolf zeal ash bane bark bone cape crow dawn dusk fire fate gale gem hawk hilt iron jade king lord mist moon mire oak omen pyre raid rust sage scar seer soul spur stag star tide tusk vale veil vow ward wisp yew doom dark gore grim hex hunt kin lair lore lute myth nest pact peak rage rift rot sear silk slay stab tale tarn toll trap urn vine void wand weir wilt wren zest cairn lark mead ogre pelt quill reed rime sable shard slate snare spike stave thane torch vigil yarn
armor arrow amber blade blood brave brand candle castle chain chant charm chest chill cloak coven crown crypt curse dagger dragon drake dread elder ember exile fable feast fiend flame flint forge frost ghoul giant glory goblin grave grove guard guild haunt haven helmet herald hollow honor hound hydra idol jester jewel knave knight lance ledger legend lich locket lunar mantle marsh mason mercy mirage mystic noble oracle outlaw pagan palace pillar plague portal potion priest prince quiver quest raven realm relic rider ritual robe royal ruin saber sacred scroll scythe shadow shield shrine siege silver sinful skull sorcery spell spire spirit squire stone storm sword talon tavern temple throne timber torch tower trident troll trumpet umbral vassal vault venom viper visor warden wizard wraith wyvern yeoman bishop bandit banner beast bounty chalice cinder cleric dwarf falcon feral fable gallant gloom hermit hunter iron jousting lantern marshal monk nomad pledge rebel reign sentry sigil smith stallion tribute usurper vanquish warhorn wander yonder
alchemy ambush armory arcane banshee barbican bastion battle beacon betrayal blizzard bulwark cathedral catapult cauldron cavalry chalice champion citadel conquest crusader cursed dungeon dynasty eclipse enchant fortress gargoyle gauntlet gladiator griffin guardian harbinger heretic hexblade highborn inferno keeper kingdom labyrinth legion lionheart longbow mammoth marauder minstrel monarch necromancer nightfall oathsworn oblivion paladin phantom pilgrim portcullis rampart reaper relentless sanctum sentinel serpent shadowed shattered skirmish sorcerer spectral stronghold sunfall talisman tempest thunder tournament trebuchet triumph undying valiant vanguard vengeance vigilant warband warlock warlord watchtower whisper wildfire windswept witchcraft wolfpack banished bloodline castellan cloister conjure dreadful emberlight fearless gauntlets grimoire hallowed ironclad jubilant kindred lanterns moonrise nemesis outcast paragon quicksilver reckoning sovereign stormcloud tyrant unbroken vagrant wayfarer wrathful
battlefield bloodstained candlelight dragonslayer drawbridge executioner fearsome graveyard gravestone hellfire highlander kingslayer lightbringer moonlight nightmare overlord shieldwall shieldbearer stormbringer swordsmith thunderous unbreakable undefeated vagabond warhammer wintertide witchhunter blacksmith bloodthirsty chainbreaker dreadnought earthshaker fireproof gatekeeper heartstrings ironhearted knighthood lionhearted mountaintop nightwatcher oathbreaker questbound runestone shadowfang swordbearer torchlight warmonger wildernesses`);
const ZW0=[
`moss fern bark root acorn mud loam clay soil peat twig thorn bramble briar bracken burrow thicket toadstool mushroom lichen spore sapling seedling fungus hollow log stump sap resin pine cedar elm birch willow hazel alder nettle clover thistle dew fen bog marsh pond puddle snail slug beetle worm moth toad newt fox badger boar stag owl hare mole vole stoat rook glade grove copse woods trail path snare hut camp smoke cobble hide pelt antler mossy muddy earthy leafy gnarled knotted damp musty rustic forager gather harvest hunter tracker druid herbs berry hazelnut chestnut timber lumber pixie firefly foxglove hawthorn lantern`,
`tomb crypt vault grave coffin casket shroud wraith spectre ghoul ghost phantom bones skull marrow ossuary catacomb epitaph requiem dirge elegy lament mourn funeral burial vigil relic censer incense candle wax gargoyle spire nave altar chapel abbey cloister monk friar cowl cassock gloom murky pallid ashen morbid macabre eerie haunt banshee revenant undead lich vampire fang crimson raven cobweb dust decay ruin cenotaph pall hearse toll knell bell dusk midnight nocturne vespers sarcophagus reliquary eulogy sepulcher mourning skeleton bonemeal urn`,
`web silk thread strand cocoon spinner spinneret weaver venom mandible chitin carapace hiss skitter scuttle lurk stalk ambush pounce burrow tunnel cavern grotto stalactite stalagmite geode crystal quartz mineral ore vein seam drip echo lair nest egg brood swarm hatchling widow recluse tarantula mite tick scorpion pincer stinger barb molt husk glow luminous sticky snare trapped bundle prey feast drain drained shiver creeping abyss dripping molting`,
`cinder ember ash soot smoke flame blaze inferno magma lava molten slag iron steel anvil hammer forge furnace bellows tongs crucible smelter smith kiln brand scorch sear singe char coal charcoal brimstone sulfur obsidian basalt pumice ignite kindle torch pyre cauldron flare spark fuse fervent fiery sizzle roast melt scald boil steam vent eruption volcano crater caldera rampart bastion battlement smolder ashen charred hellfire`,
`frost ice snow sleet hail blizzard gale drift flurry glacier icicle crevasse avalanche summit ridge crag cliff peak tundra permafrost fjord aurora rime hoar chill shiver frigid frozen brittle numb bitter howl whiteout powder shard flake yeti mammoth wolf ram goat eagle parka fur cairn pass trek climb rope pick lodge sled snowdrift frostbite frostbound wintry`,
`tide wave surf brine salt kelp coral reef pearl shell conch barnacle anchor hull mast keel galleon wreck treasure trident siren mermaid triton leviathan kraken squid eel shark crab lobster urchin anemone lagoon trench abyss depths current undertow maelstrom whirlpool drown drifting sunken ruin column mosaic temple idol relic silt murk bubble algae shipwreck krill`];
const ZW=ZW0.map((t,i)=>uniq(t).filter(w=>w.length<=10&&!ZW0.slice(0,i).some(x=>(' '+x+' ').includes(' '+w+' '))));
const ZN2=['Goblin Woods','Crypts','Spider Caverns','Ember Keep','Frozen Peaks','Sunken Ruins'],ZTAG=['earthy','gothic','arachnid','forged','frozen','tidal'];
const WZ=new Map();ZW.forEach((l,i)=>l.forEach(w=>WZ.set(w,i)));
const BADJ=uniq('dark cursed ancient hungry silent burning hollow frozen restless wicked fearless broken endless crimson gilded savage forgotten shattered lonely bitter merciless hateful rotting howling faded jagged barren bloodied mournful twisted ruthless timeless nameless tireless gruesome ashen sunless venomous thundering brittle moldering withered spiteful pitiless unholy'),
BNOUN=uniq('king night storm blade crown dragon shadow throne legion flame oath kingdom tide curse ruin sword hero fortress hunger winter grave banner empire tomb blood nightmare fury silence vengeance dawn fate thunder chain oblivion harvest omen'),
BPL=uniq('knights heroes fools kings soldiers dreamers champions warriors travelers pilgrims rebels bards squires heralds'),
BVERB=uniq('escape defeat outrun silence bind outlast forget slay withstand deceive banish resist tame'),
BVP=['crush your hopes','devour the light','swallow your name','end your journey','break your blade','bury your kingdom','silence your song','drown your courage','burn your banners','shatter your shield','take your crown','erase your legend','scatter your bones','feast on your fear','freeze your heart','undo your oath','hollow your spirit','steal your last breath','cage your soul','wither your resolve','tear down your walls','snuff out your torch','chain your fate','bleed your armies dry'],
BFIX=['you shall not pass this hall','your blade is dull and your words are slow','no hero has ever typed past me','bow down and beg for mercy','the old gods are watching you fail','every word you type is your last','run while you still have the breath','only the swift and the sharp survive','this realm belongs to darkness now','your legend ends in this very place','tremble before the power of the deep','none may escape my endless hunger','i have waited a thousand years for this','the bells toll for the fallen knight','come closer little hero and die','light fades and shadows always win',
'your courage is a candle in a gale','i have buried better warriors than you','turn back before the night takes you','the crows already know your name','a thousand swords could not save you','you are late to your own funeral','my patience ended long before you came','no song will ever remember this fight','the dead are lining up to greet you','your fingers are quick but your fate is slow','many have tried and all have failed','the silence after this will be mine','fall to your knees and count your sins','you carry nothing worth the trouble','your torch will not last the hour','even the stars look away from you','i was old when your kingdom was young','this is where brave stories come to die','fight on little knight and lose slowly','every step brought you closer to your grave','i am the last thing you will ever read','the ground remembers every fool who fought','your armor cannot hold back the dark','hope is a rumor i put an end to'];
let RECENT=[];
function pickWord(role,zi,d,onScreen){
 const sh=Math.min(4,d/13|0),[lo,hi]=[[4,6+sh],[3,4+sh],[7+(sh>>1),10+sh]][role];
 const firsts=new Set(onScreen.map(w=>w[0])),ban=new Set([...RECENT,...onScreen]);
 const zone=Array.isArray(zi)?zi:ZW[zi];
 const ok=(w,f,r)=>w.length>=lo&&w.length<=hi&&(!f||!firsts.has(w[0]))&&(!r||!ban.has(w));
 for(const [f,r] of [[1,1],[0,1],[0,0]]){
  const prefer=Math.random()<.7?[zone,GEN]:[GEN,zone];
  for(const pool of prefer){const c=pool.filter(w=>ok(w,f,r));if(c.length){const w=c[Math.random()*c.length|0];RECENT.push(w);if(RECENT.length>70)RECENT.shift();return w}}
 }
 return GEN[Math.random()*GEN.length|0]}
let RECENTB=[];
function bossLine(L,tier,used){
 const P=a=>a[Math.random()*a.length|0];let s,n=0;
 do{const r=Math.random(),e=tier>1&&Math.random()<.35?P([' once more',' again',' tonight']):'';
  const T=[
  ()=>P(BFIX),
  ()=>`the ${P(BADJ)} ${P(BNOUN)} shall ${P(BVP)}`,
  ()=>`${L.bl} will ${P(BVP)}`,
  ()=>`no ${P(BNOUN)} can stop the ${P(BADJ)} ${P(BNOUN)}`,
  ()=>`fear the ${P(BADJ)} ${P(BNOUN)} of ${L.pl}`,
  ()=>`${L.pl} shall ${P(BVP)}`,
  ()=>`only ${P(BADJ)} ${P(BPL)} leave ${L.pl}`,
  ()=>`i am the ${P(BADJ)} ${P(BNOUN)} you cannot ${P(BVERB)}`,
  ()=>`${L.bl} has buried a thousand ${P(BPL)}`,
  ()=>`kneel before ${L.bl} and ${P(['beg for mercy','count your sins','pray for dawn','accept your fate','forget your name'])}`,
  ()=>`your ${P(BNOUN)} is ${P(BADJ)} and your ${P(BNOUN)} is weak`,
  ()=>`welcome to ${L.pl} where ${P(BPL)} come to die`,
  ()=>`the ${P(BADJ)} ${P(BNOUN)} of ${L.pl} will ${P(BVP)}`,
  ()=>`${L.bl} says ${P(['leave now','turn back','tremble','beg','run','kneel'])} or ${P(['perish','burn','fall','be forgotten','bleed'])}`];
  s=P(T)()+e}while((used.includes(s)||RECENTB.includes(s)||s.length>50||s.length<20)&&++n<80);
 RECENTB.push(s);if(RECENTB.length>120)RECENTB.shift();return s}
