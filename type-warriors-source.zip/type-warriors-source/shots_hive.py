# python3 shots_hive.py [outdir] : screenshots of the Clockwork Hive (98h/98i): the tier sheet, the info panel and battle moments
# (the swarm, the Queen's burst, the pollen buff), full stage and 2x crops.
import asyncio,os,sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
OUT=sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'shots','w10_hive')
GAME='file://'+os.path.join(HERE,'out.html')
SETUP="()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const r=RPP();r.new99j=1;r.dragon=1;r.stars=Object.assign(r.stars||{},{moss:3,frost:3,ember:3});for(const k in r.tut)r.tut[k]=1;for(const k of['build','wave','coins','upgrade','abil','rune','twist','twist_frost','twist_ember','twist_wonder'])r.tut[k]=1;save()}"
HELP=open(os.path.join(HERE,'t_hive.py')).read().split('HELP=r"""',1)[1].split('"""',1)[0]
SCENE=r"""(a)=>{const [map,wave,plan,mobs,secs,near]=a;const R=tdNew(map,wave);R.spd=1;
 for(const [pi,t,k] of plan)tdBuild(R,R.pads[pi],t,k);for(const p of R.pads)if(p.tw)p.tw.ph=Math.random();R.fx.length=0;R.rings.length=0;
 /* monsters around the road point nearest pad `near` (offsets along the road), walking slowly */
 const s0=near!=null?tdNear(R,R.pads[near],0):0;for(const [id,ds,path,hp,sp] of mobs){const e=rpSpawn(id,path||0);e.s=s0+ds;e.hp=e.mx=hp||1e5;if(sp!=null)e.sp=sp}
 for(let k=0;k<Math.round(secs*30);k++){rpStep(R,1/30);R.t+=1/30;if(k%2===0)try{ptFxStep(ctx,R.fx,1/15)}catch(x){}}
 R.hold=true;R.banner=null;R.toast=null;R.tx.length=0;return R.pads.filter(p=>p.tw).map(p=>[p.i,p.tw.type,p.tw.tier,Math.round(p.x),Math.round(p.y)])}"""
async def shot(pg,name,clip=None):
    await pg.wait_for_timeout(250)
    p=os.path.join(OUT,name);await pg.screenshot(path=p,clip=clip) if clip else await pg.screenshot(path=p);print('saved',p)
async def main():
    os.makedirs(OUT,exist_ok=True)
    async with async_playwright() as p:
        b=await p.chromium.launch();er=[]
        pg=await b.new_page(viewport={'width':1600,'height':900},device_scale_factor=2);pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(GAME);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E(SETUP);await E(HELP)
        # ---- the tier sheet: tiers 1-5, large, on a meadow
        await E("""()=>{const c=document.createElement('canvas');c.width=3200;c.height=1800;c.id='hvsheet';c.style.cssText='position:fixed;left:0;top:0;width:1600px;height:900px;z-index:99999';document.body.appendChild(c);
          const g=c.getContext('2d');g.scale(2,2);const B=rpBake(RP_MAP('moss'));g.drawImage(B.c,0,0);g.fillStyle='rgba(14,26,8,.5)';g.fillRect(0,0,1600,900);const vg=g.createRadialGradient(800,470,200,800,470,900);vg.addColorStop(0,'rgba(10,6,24,0)');vg.addColorStop(1,'rgba(10,6,24,.55)');g.fillStyle=vg;g.fillRect(0,0,1600,900);
          const q=g.createLinearGradient(0,620,0,900);q.addColorStop(0,'rgba(10,6,24,0)');q.addColorStop(1,'rgba(10,6,24,.7)');g.fillStyle=q;g.fillRect(0,620,1600,280);
          g.textAlign='center';g.font="400 58px 'Pirata One',Georgia,serif";g.lineWidth=8;g.strokeStyle='#12081f';g.strokeText('The Clockwork Hive',800,92);g.fillStyle='#ffd45a';g.fillText('The Clockwork Hive',800,92);
          const names=['Tier 1','Tier 2','Tier 3 · Honeycomb','Tier 4 · Royal Jelly',"Tier 5 · Queen's Court"];
          for(let t=1;t<=5;t++){const x=160+(t-1)*320,y=560;g.save();g.translate(x,y);g.scale(2.35,2.35);rpTowerDraw(g,'hive',t,'base',1.4+t*.61,{ph:.13*t});g.restore();
           g.font='800 24px Poppins,system-ui,sans-serif';g.lineWidth=6;g.strokeText(names[t-1],x,720);g.fillStyle='#fff6e0';g.fillText(names[t-1],x,720);
           g.font='600 17px Poppins,system-ui,sans-serif';const sub=[`${RP_TW.hive.bees[t-1]} bees`,`${RP_TW.hive.bees[t-1]} bees`,'honey puddles','pollen +10%','the Queen Bee'][t-1];g.lineWidth=5;g.strokeText(sub,x,748);g.fillStyle='#ffc83a';g.fillText(sub,x,748)}}""")
        await shot(pg,'hive_tiers.png')
        # bees and the Queen up close
        await E("""()=>{const c=document.getElementById('hvsheet'),g=c.getContext('2d');g.setTransform(2,0,0,2,0,0);const B=rpBake(RP_MAP('moss'));g.drawImage(B.c,0,0);g.fillStyle='rgba(14,26,8,.55)';g.fillRect(0,0,1600,900);
          for(let t=1;t<=5;t++){const x=180+(t-1)*300;g.save();g.translate(x,330);rphvBee(g,0,0,1,t,.37+t*.1,5,1);g.restore();g.save();g.translate(x,560);rphvBee(g,0,0,-1,t,.5+t*.2,3.2,1);g.restore();
           g.font='800 22px Poppins';g.textAlign='center';g.lineWidth=6;g.strokeStyle='#12081f';g.strokeText('Tier '+t+' bee',x,690);g.fillStyle='#fff6e0';g.fillText('Tier '+t+' bee',x,690)}
          g.save();g.translate(800,130);rphvQueen(g,0,0,1,5,.3,3.4,1,.6,0);g.restore();
          g.save();g.translate(1080,800);rphvPuddle(g,0,0,60,1,.4,3,.2);g.restore();g.save();g.translate(1300,800);rphvPuddle(g,0,0,60,1,.4,4,.6);g.restore();g.save();g.translate(1500,800);rphvPuddle(g,0,0,60,1,.4,5,.9);g.restore()}""")
        await shot(pg,'hive_bees.png')
        await E("()=>{document.getElementById('hvsheet').remove()}")
        # ---- battle: the swarm on Mossgate Hollow (hives of tiers 1-3, a frost spire and a ballista against a mixed wave)
        r=await E("()=>{const R=tdNew('moss',6);return R.pads.map(p=>[p.i,Math.round(p.x),Math.round(p.y),Math.round(Math.hypot(rpAt(R.G,tdNear(R,p,0),0).x-p.x,rpAt(R.G,tdNear(R,p,0),0).y-p.y))])}");print(r)
        plan=[[2,'hive',3],[3,'hive',2],[1,'ballista',2],[5,'frost',2],[0,'hive',1]]
        mobs=[['scamp',-160,0,1e5,14],['scamp',-120,0,1e5,14],['bulwark',-60,0,1e5,10],['gloom',-30,0,1e5,12],['scamp',10,0,1e5,14],['golem',60,0,1e5,8],['gloom',100,0,1e5,12],['scamp',140,0,1e5,14],['bulwark',190,0,1e5,10],['scamp',230,0,1e5,14]]
        r=await E(SCENE,['moss',6,plan,mobs,4.5,2]);print(r)
        await E("()=>{RPX.sel=null;rpDraw()}");await shot(pg,'battle_swarm.png')
        hv=[x for x in r if x[1]=='hive' and x[2]==3][0]
        await shot(pg,'battle_swarm_zoom.png',{'x':max(0,min(1600-700,hv[3]-300)),'y':max(0,min(900-440,hv[4]-300)),'width':700,'height':440})
        # ---- the info panel
        await E("()=>{const R=RPX;R.sel=R.pads.find(p=>p.tw&&p.tw.type==='hive'&&p.tw.tier===3).tw}");await pg.wait_for_timeout(700)
        await shot(pg,'info_panel.png')
        await E("()=>{RPX.sel=null}")
        # ---- the Queen's burst (Wonderland, tier 5)
        hp=await E("()=>{const R=tdNew('wonder',30);const front=p=>{const q=rpAt(R.G,tdNear(R,p,0),0);return q.y-p.y};const p=[...R.pads].filter(p=>p.x>350&&p.x<1250&&p.y>200&&p.y<560&&front(p)>40).sort((a,b)=>front(b)-front(a))[0],o=[...R.pads].filter(q=>q!==p&&q.y<p.y).sort((a,b)=>Math.hypot(a.x-p.x,a.y-p.y)-Math.hypot(b.x-p.x,b.y-p.y));return [p.i,o[0].i,o[1].i]}")
        plan=[[hp[0],'hive',5],[hp[1],'frost',4],[hp[2],'ballista',4]]
        r=await E(SCENE,['wonder',30,plan,[],.2]);q=[x for x in r if x[1]=='hive'][0]
        r2=await E("""(pi)=>{const R=RPX,pad=R.pads[pi],s=tdNear(R,pad,0),L=[];for(const [id,k] of [['golem',-30],['scamp',-50],['bulwark',0],['scamp',20],['gloom',-10],['shaman',40],['scamp',60]]){const e=rpSpawn(id,0);e.s=s+k;e.hp=e.mx=3e5;e.sp=6;L.push(e)}
          R.fx.length=0;R.rings.length=0;R.hold=false;const tw=pad.tw;tw.qn.cd=3.5;let t=0;while(t<12){rpStep(R,1/30);R.t+=1/30;t+=1/30;if(t%(2/30)<1/30)try{ptFxStep(ctx,R.fx,1/15)}catch(x){}if(R.hvBursts.length&&R.hvBursts[0].t>=.27)break}
          R.hold=true;R.banner=null;R.toast=null;R.tx.length=0;rpDraw();return [t,R.hvBurstN,tw.qn.m,Math.round(tw.qn.x),Math.round(tw.qn.y)]}""",hp[0]);print('queen',r2)
        await shot(pg,'battle_queen_burst.png')
        await shot(pg,'battle_queen_burst_zoom.png',{'x':max(0,min(1600-640,r2[3]-320)),'y':max(0,min(900-400,r2[4]-250)),'width':640,'height':400})
        # the Queen's take-off from her crown
        r3=await E("""()=>{const R=tdNew('wonder',30),pad=[...R.pads].filter(p=>p.y>420&&p.y<640&&p.x>400&&p.x<1200)[0],tw=tdBuild(R,pad,'hive',5);R.fx.length=0;R.rings.length=0;for(let k=0;k<10;k++){rpStep(R,1/30);R.t+=1/30}const s=tdNear(R,pad,0),e=rpSpawn('golem',0);e.s=s;e.hp=e.mx=1e6;e.sp=0;
          let t=0;while(t<3&&tw.qn.m==='perch'){rpStep(R,1/30);R.t+=1/30;t+=1/30}for(let k=0;k<5;k++){rpStep(R,1/30);R.t+=1/30;try{ptFxStep(ctx,R.fx,1/30)}catch(x){}}R.hold=true;R.banner=null;R.toast=null;R.tx.length=0;rpDraw();return [Math.round(pad.x),Math.round(pad.y),tw.qn.m]}""");print('takeoff',r3)
        await shot(pg,'battle_queen_takeoff_zoom.png',{'x':max(0,min(1600-500,r3[0]-250)),'y':max(0,min(900-330,r3[1]-250)),'width':500,'height':330})
        # ---- pollen: a Royal Jelly hive next to a prism and a ballista
        r4=await E("""()=>{const R=tdNew('wonder',30);let A=null,B=null;for(const p of R.pads)for(const q of R.pads){if(p!==q&&!A&&Math.hypot(p.x-q.x,p.y-q.y)<150&&p.x>300&&p.x<1300&&p.y>200&&p.y<700){A=p;B=q}}
          const hv=tdBuild(R,A,'hive',4);tdBuild(R,B,'ballista',3);R.fx.length=0;R.rings.length=0;const s=tdNear(R,A,0);for(const [id,k] of [['golem',-200],['scamp',-160],['gloom',-230],['bulwark',-120]]){const e=rpSpawn(id,0);e.s=Math.max(0,s+k);e.hp=e.mx=1e6;e.sp=10}
          let t=0;while(t<6){rpStep(R,1/30);R.t+=1/30;t+=1/30;if(t>5&&hv.cr&&hv.cr.to&&hv.cr.t/hv.cr.d>.42&&hv.cr.t/hv.cr.d<.55)break}R.hold=true;R.sel=hv;R.banner=null;R.toast=null;R.tx.length=0;rpDraw();return [Math.round((A.x+B.x)/2),Math.round((A.y+B.y)/2),B.tw.pol>0]}""");print('pollen',r4)
        await pg.wait_for_timeout(500);await E("()=>rpDraw()")
        await shot(pg,'battle_pollen.png')
        await E("()=>{RPX.sel=null;rpDraw()}")
        await shot(pg,'battle_pollen_zoom.png',{'x':max(0,min(1600-640,r4[0]-320)),'y':max(0,min(900-420,r4[1]-260)),'width':640,'height':420})
        print('errors',er)
        await b.close()
asyncio.run(main())
