/* ===== RUNESTONE TOWER DEFENSE 10.0: Tower Mastery (98m, last of the 10.0 modules) =====
   Spec: TD_WORLDS_PLAN.md section 4.
   - XP per tower type in P.rp.mast[type]: every wave cleared gives each tower on the field 6 x tier, every kill 1 to its tower, a won
     map 50 to every tower type used. Levels I-V at RPY_LV. A level-up unlocks that tower's skin 'm<level>' (P.rp.own[type+':m'+n]),
     shows a toast, and the results card lists the XP gained.
   - Skins: every tower has five (RPY_SET), 60 in all. A skin = a palette theme (RPY_TH) applied by a recolouring wrapper around the
     drawing context (rpyCtx: every fill / stroke colour and gradient stop goes through rpyCol, every image drawn through rpyImg, both
     cached per theme) + effects that grow with the level: II a ground glow and rising motes of the theme's element, III a floating gem
     crest, IV an orbiting ring of its element and a turning rune sigil, V wings or a halo of light and a light pillar.
     Performance mode, the battle's lite flag and reduced motion keep the recolour and the static adornments and drop the motion.
   - The Tower Skins screen (rpSkins, replacing 97l's) shows each tower's mastery level, its XP track and all its skins. */
const RPY_LV=[0,300,1200,3200,7000,14000],RPY_ROM=['','I','II','III','IV','V'];
const rpyXP=t=>{const r=RPP();if(!r.mast||typeof r.mast!=='object'||Array.isArray(r.mast))r.mast={};return Math.max(0,Math.floor(+r.mast[t]||0))};
const rpyLevel=t=>{const x=rpyXP(t);let n=0;for(let i=1;i<RPY_LV.length;i++)if(x>=RPY_LV[i])n=i;return n};
/* ---------- themes: role -> [hue, saturation, lightness shift]; iri = iridescent [hue0, hue span] ---------- */
const RPY_TH={
 jade:{stone:[150,.16,0],wood:[30,.35,-.04],trim:[46,.75,0],warm:[140,.55,0],cool:[158,.62,0],magic:[165,.55,0],leaf:[140,.6,0],glow:'#7dffc0',el:'leaf'},
 rosegold:{stone:[340,.12,.06],wood:[350,.3,0],trim:[18,.62,.06],warm:[350,.65,.05],cool:[330,.5,.08],magic:[320,.55,.05],leaf:[340,.42,.05],glow:'#ffb0c8',el:'petal'},
 obsidian:{stone:[265,.15,-.2],wood:[270,.2,-.18],trim:[302,.85,.05],warm:[300,.9,.05],cool:[188,.9,.05],magic:[290,.9,.05],leaf:[190,.7,-.04],glow:'#ff5ae8',el:'shard'},
 glacier:{stone:[205,.25,.12],wood:[210,.25,.05],trim:[195,.35,.15],warm:[195,.8,.1],cool:[190,.8,.12],magic:[220,.7,.1],leaf:[185,.5,.12],glow:'#bff4ff',el:'snow'},
 inferno:{stone:[10,.15,-.14],wood:[5,.3,-.14],trim:[38,.95,.03],warm:[20,1,.05],cool:[30,1,.05],magic:[5,.9,0],leaf:[25,.9,-.04],glow:'#ff7a2a',el:'ember'},
 sakura:{stone:[330,.08,.18],wood:[340,.3,.05],trim:[45,.6,.1],warm:[335,.7,.12],cool:[320,.55,.15],magic:[300,.5,.12],leaf:[335,.55,.15],glow:'#ffc8e8',el:'petal'},
 abyssal:{stone:[220,.3,-.17],wood:[225,.3,-.14],trim:[180,.8,.05],warm:[175,.9,.05],cool:[185,.95,.05],magic:[280,.8,.05],leaf:[165,.8,0],glow:'#5af0ff',el:'bubble'},
 solar:{stone:[40,.25,.12],wood:[35,.45,.05],trim:[48,.95,.08],warm:[40,1,.08],cool:[45,.95,.12],magic:[30,.9,.08],leaf:[55,.8,.05],glow:'#ffe27a',el:'sun'},
 lunar:{stone:[230,.1,.15],wood:[235,.15,.08],trim:[220,.2,.25],warm:[230,.4,.2],cool:[220,.5,.18],magic:[250,.45,.15],leaf:[210,.3,.15],glow:'#e8f0ff',el:'star'},
 verdant:{stone:[95,.18,0],wood:[28,.5,-.02],trim:[45,.7,0],warm:[100,.7,0],cool:[120,.6,0],magic:[90,.7,0],leaf:[110,.75,.02],glow:'#b8ff7a',el:'leaf'},
 amethyst:{stone:[270,.18,.02],wood:[280,.3,-.05],trim:[200,.15,.2],warm:[285,.75,.05],cool:[270,.7,.05],magic:[290,.8,.05],leaf:[275,.6,0],glow:'#d8a0ff',el:'gem'},
 royal:{stone:[225,.22,0],wood:[220,.3,-.05],trim:[46,.9,.05],warm:[230,.8,0],cool:[225,.85,0],magic:[235,.8,0],leaf:[220,.6,0],glow:'#ffd45a',el:'gem'},
 toxic:{stone:[100,.12,-.12],wood:[280,.2,-.1],trim:[80,.9,.05],warm:[85,.95,.02],cool:[290,.8,.02],magic:[100,.9,.02],leaf:[90,.95,.02],glow:'#c8ff3a',el:'bubble'},
 coral:{stone:[25,.18,.1],wood:[15,.35,.02],trim:[45,.6,.1],warm:[8,.85,.08],cool:[175,.7,.05],magic:[345,.7,.08],leaf:[170,.6,.05],glow:'#ff9a8a',el:'bubble'},
 storm:{stone:[220,.15,-.05],wood:[225,.2,-.1],trim:[200,.3,.2],warm:[200,.95,.1],cool:[205,1,.1],magic:[260,.9,.1],leaf:[195,.9,.05],glow:'#9fe8ff',el:'bolt'},
 phoenix:{stone:[20,.2,-.05],wood:[15,.4,-.1],trim:[45,1,.08],warm:[15,1,.05],cool:[40,1,.08],magic:[355,.95,.05],leaf:[30,1,.05],glow:'#ffb040',el:'feather',wing:'#ff8a2a'},
 aurora:{iri:[150,260],stone:[200,.16,.08],glow:'#a0ffe8',el:'star',wing:'#8affd8'},
 voidstar:{stone:[255,.35,-.24],wood:[260,.3,-.2],trim:[46,.9,.1],warm:[275,.9,.1],cool:[230,.95,.12],magic:[285,.95,.12],leaf:[240,.8,.05],glow:'#b48aff',el:'star',wing:'#8a5aff'},
 celestial:{stone:[45,.12,.25],wood:[40,.25,.15],trim:[46,1,.12],warm:[48,.9,.15],cool:[195,.6,.2],magic:[50,.8,.18],leaf:[55,.7,.15],glow:'#fff2b0',el:'star',wing:'#fff2c8'},
 prismatic:{iri:[0,720],stone:[260,.14,.1],glow:'#ffffff',el:'gem',wing:'#ffd8ff'}};
for(const k in RPY_TH)RPY_TH[k].id=k;
/* every tower's five mastery skins: [theme, name] for levels I-V */
const RPY_SET={
 ballista:[['jade','Jadewood Ballista'],['rosegold','Rose Gold Arbalest'],['amethyst','Amethyst Arbalest'],['obsidian','Obsidian Sentinel'],['celestial','Celestial Arbalest']],
 brazier:[['lunar','Moonfire Blazer'],['sakura','Blossom Blazer'],['glacier','Frostfire Blazer'],['toxic','Venomfire Blazer'],['voidstar','Voidflame Pyre']],
 frost:[['sakura','Sakura Spire'],['inferno','Emberglass Spire'],['solar','Sunstone Spire'],['amethyst','Amethyst Spire'],['aurora','Borealis Spire']],
 bell:[['verdant','Verdant Bell'],['coral','Coral Chime'],['solar','Sunburst Bell'],['abyssal','Abyssal Gong'],['phoenix','Phoenix Bell']],
 prism:[['jade','Jade Prism'],['rosegold','Rose Prism'],['glacier','Glacier Prism'],['obsidian','Obsidian Prism'],['prismatic','Spectrum Prism']],
 dragon:[['verdant','Forest Wyrm Roost'],['glacier','Frost Wyrm Roost'],['royal','Royal Wyrm Roost'],['obsidian','Shadow Wyrm Roost'],['aurora','Aurora Wyrm Roost']],
 tide:[['verdant','Kelp Shrine'],['sakura','Pearl Shrine'],['solar','Sunken Gold Shrine'],['amethyst','Amethyst Shrine'],['celestial','Celestial Tide Shrine']],
 mortar:[['jade','Jade Mortar'],['inferno','Magma Mortar'],['royal','Royal Mortar'],['storm','Tempest Mortar'],['voidstar','Void Mortar']],
 still:[['verdant','Herbalist\'s Still'],['glacier','Frostbrew Still'],['amethyst','Amethyst Still'],['toxic','Venom Still'],['prismatic','Philosopher\'s Still']],
 star:[['lunar','Moonwatch Observatory'],['rosegold','Rose Observatory'],['jade','Jade Observatory'],['abyssal','Deep Sky Observatory'],['voidstar','Void Observatory']],
 hive:[['verdant','Meadow Hive'],['sakura','Blossom Hive'],['glacier','Frost Hive'],['obsidian','Obsidian Hive'],['aurora','Aurora Hive']],
 grav:[['lunar','Lunar Engine'],['rosegold','Rose Engine'],['phoenix','Phoenix Engine'],['storm','Tempest Engine'],['celestial','Celestial Singularity']]};
const RPY_DEF=[['jade','Jade'],['coral','Coral'],['royal','Royal'],['obsidian','Obsidian'],['celestial','Celestial']];
const rpySet=t=>RPY_SET[t]||RPY_DEF.map(([th,n])=>[th,n+' '+((RPTW[t]&&RPTW[t].n)||t)]);
const rpySkinTheme=(t,k)=>{const n=+String(k).slice(1);return /^m[1-5]$/.test(k)?RPY_TH[rpySet(t)[n-1][0]]:null};
/* ---------- colour mapping ---------- */
function rpyHSL(r,g,b){r/=255;g/=255;b/=255;const mx=Math.max(r,g,b),mn=Math.min(r,g,b),l=(mx+mn)/2;let h=0,s=0;if(mx!==mn){const d=mx-mn;s=l>.5?d/(2-mx-mn):d/(mx+mn);h=(mx===r?(g-b)/d+(g<b?6:0):mx===g?(b-r)/d+2:(r-g)/d+4)*60}return[h,s,l]}
function rpyRGB(h,s,l){h=((h%360)+360)%360/360;const q=l<.5?l*(1+s):l+s-l*s,p=2*l-q,f=t=>{t=t<0?t+1:t>1?t-1:t;return t<1/6?p+(q-p)*6*t:t<.5?q:t<2/3?p+(q-p)*(2/3-t)*6:p};return[Math.round(f(h+1/3)*255),Math.round(f(h)*255),Math.round(f(h-1/3)*255)]}
const rpyCl=v=>v<0?0:v>1?1:v;
function rpyXf(T,r,g,b){const [h,s,l]=rpyHSL(r,g,b);if(l<.13||l>.94)return[r,g,b];
 let role;if(s<.16)role='stone';else if(h>=25&&h<62&&l>.38&&s>.35)role='trim';else if(h>=10&&h<45&&l<=.42)role='wood';else if(h<25||h>=335)role='warm';else if(h<70)role='trim';else if(h<165)role='leaf';else if(h<255)role='cool';else role='magic';
 if(T.iri&&role!=='stone')return rpyRGB(T.iri[0]+l*T.iri[1]+h*.15,Math.max(.62,s),rpyCl(l+.04));
 const X=T[role];if(!X)return[r,g,b];
 return rpyRGB(X[0]+(role==='stone'?0:(h%30)-15)*.25,role==='stone'?Math.min(.6,X[1]+s*.4):rpyCl(X[1]*(.62+.55*s)),rpyCl(l+X[2]*(role==='stone'?1:.8)))}
const RPY_PC=document.createElement('canvas').getContext('2d'),RPY_CC={};
function rpyCol(T,c){if(!T||typeof c!=='string')return c;let M=RPY_CC[T.id];if(!M)M=RPY_CC[T.id]=new Map();let v=M.get(c);if(v!==undefined)return v;
 RPY_PC.fillStyle='#000';RPY_PC.fillStyle=c;const n=RPY_PC.fillStyle;let r,g,b,a=1;
 if(n[0]==='#'){r=parseInt(n.slice(1,3),16);g=parseInt(n.slice(3,5),16);b=parseInt(n.slice(5,7),16)}else{const m=n.match(/[\d.]+/g);if(!m){M.set(c,c);return c}r=+m[0];g=+m[1];b=+m[2];a=m[3]!==undefined?+m[3]:1}
 const o=rpyXf(T,r,g,b);v=`rgba(${o[0]},${o[1]},${o[2]},${a})`;if(M.size>4000)M.clear();M.set(c,v);return v}
/* images (baked sprites) are recoloured once per theme */
const RPY_IC=new WeakMap();
function rpyImg(T,img){if(!T||!img||!(img.width>0)||img.width*img.height>1100000)return img;let M=RPY_IC.get(img);if(!M){M=new Map();RPY_IC.set(img,M)}let c=M.get(T.id);if(c)return c;
 c=document.createElement('canvas');c.width=img.width;c.height=img.height;const x=c.getContext('2d');x.drawImage(img,0,0);let D;try{D=x.getImageData(0,0,c.width,c.height)}catch(e){M.set(T.id,img);return img}
 const d=D.data,memo=new Map();for(let i=0;i<d.length;i+=4){if(d[i+3]===0)continue;const k=(d[i]<<16)|(d[i+1]<<8)|d[i+2];let o=memo.get(k);if(!o){o=rpyXf(T,d[i],d[i+1],d[i+2]);memo.set(k,o)}d[i]=o[0];d[i+1]=o[1];d[i+2]=o[2]}
 x.putImageData(D,0,0);M.set(T.id,c);return c}
/* the recolouring context: plain forwarding functions and accessors (no Proxy), one wrapper per real context */
const RPY_CW=new WeakMap();
function rpyCtx(g,T){let w=RPY_CW.get(g);if(!w){w=Object.create(null);const P=CanvasRenderingContext2D.prototype;
  for(const k of Object.getOwnPropertyNames(P)){if(k==='constructor')continue;const d=Object.getOwnPropertyDescriptor(P,k);
   if(typeof d.value==='function')w[k]=function(){return g[k].apply(g,arguments)};else if(d.get)Object.defineProperty(w,k,{get(){return g[k]},set(v){g[k]=v},configurable:true})}
  const grad=G=>({_g:G,addColorStop(o,c){G.addColorStop(o,rpyCol(w._T,c))}});
  for(const k of['fillStyle','strokeStyle','shadowColor'])Object.defineProperty(w,k,{get(){return g[k]},set(v){g[k]=v&&v._g?v._g:rpyCol(w._T,v)}});
  w.createLinearGradient=function(){return grad(g.createLinearGradient.apply(g,arguments))};w.createRadialGradient=function(){return grad(g.createRadialGradient.apply(g,arguments))};
  if(g.createConicGradient)w.createConicGradient=function(){return grad(g.createConicGradient.apply(g,arguments))};
  w.createPattern=function(img,rep){return g.createPattern(rpyImg(w._T,img),rep)};w.drawImage=function(img){const a=[...arguments];a[0]=rpyImg(w._T,img);return g.drawImage.apply(g,a)};
  RPY_CW.set(g,w)}w._T=T;return w}
/* ---------- effect sprites ---------- */
const RPY_SP=new Map();
function rpySpr(key,w,h,f){let c=RPY_SP.get(key);if(c)return c;c=document.createElement('canvas');c.width=w;c.height=h;const g=c.getContext('2d');g.lineJoin='round';g.lineCap='round';f(g,w,h);RPY_SP.set(key,c);return c}
function rpyGlowS(col){return rpySpr('g'+col,64,64,(g)=>{const q=g.createRadialGradient(32,32,0,32,32,32);q.addColorStop(0,col+'cc');q.addColorStop(.45,col+'55');q.addColorStop(1,col+'00');g.fillStyle=q;g.fillRect(0,0,64,64)})}
function rpyEl(el,col){return rpySpr('e'+el+col,28,28,(g)=>{g.translate(14,14);const q=g.createRadialGradient(0,0,0,0,0,14);q.addColorStop(0,col+'88');q.addColorStop(1,col+'00');g.fillStyle=q;g.fillRect(-14,-14,28,28);
 g.fillStyle=col;g.strokeStyle='#12081f';g.lineWidth=1.4;g.beginPath();
 if(el==='leaf'){g.ellipse(0,0,7,3.6,-.6,0,TAU);g.fill();g.stroke();g.beginPath();g.moveTo(-5,3);g.lineTo(5,-3);g.stroke()}
 else if(el==='petal'){for(let i=0;i<5;i++){const a=i*TAU/5;g.ellipse(Math.cos(a)*3.4,Math.sin(a)*3.4,3.2,2,a,0,TAU)}g.fill();g.stroke();g.fillStyle='#fff2b0';g.beginPath();g.arc(0,0,1.8,0,TAU);g.fill()}
 else if(el==='snow'){g.strokeStyle=col;g.lineWidth=2;for(let i=0;i<3;i++){const a=i*Math.PI/3;g.moveTo(Math.cos(a)*7,Math.sin(a)*7);g.lineTo(-Math.cos(a)*7,-Math.sin(a)*7)}g.stroke();g.fillStyle='#fff';g.beginPath();g.arc(0,0,2,0,TAU);g.fill()}
 else if(el==='ember'||el==='sun'){g.arc(0,0,el==='sun'?4.5:3.6,0,TAU);g.fill();g.fillStyle='#fffbe0';g.beginPath();g.arc(-1,-1,1.6,0,TAU);g.fill()}
 else if(el==='bubble'){g.strokeStyle=col;g.lineWidth=1.8;g.arc(0,0,5.5,0,TAU);g.stroke();g.fillStyle='#ffffffbb';g.beginPath();g.arc(-2,-2,1.6,0,TAU);g.fill()}
 else if(el==='bolt'){g.moveTo(-2,-8);g.lineTo(3,-1);g.lineTo(0,0);g.lineTo(3,8);g.lineTo(-3,1);g.lineTo(0,0);g.closePath();g.fill();g.stroke()}
 else if(el==='feather'){g.ellipse(0,0,8,3,-.8,0,TAU);g.fill();g.stroke();g.strokeStyle='#fff2b0';g.beginPath();g.moveTo(-6,5);g.lineTo(6,-5);g.stroke()}
 else if(el==='shard'||el==='gem'){g.moveTo(0,-8);g.lineTo(5,0);g.lineTo(0,8);g.lineTo(-5,0);g.closePath();g.fill();g.stroke();g.fillStyle='#ffffffaa';g.beginPath();g.moveTo(0,-6);g.lineTo(2,-1);g.lineTo(-1,0);g.closePath();g.fill()}
 else{for(let i=0;i<10;i++){const a=i*Math.PI/5-Math.PI/2,r=i%2?2.6:7;g.lineTo(Math.cos(a)*r,Math.sin(a)*r)}g.closePath();g.fill();g.stroke()}})}
function rpyCrest(col){return rpySpr('c'+col,44,52,(g)=>{g.translate(22,26);const q=g.createRadialGradient(0,0,0,0,0,22);q.addColorStop(0,col+'99');q.addColorStop(1,col+'00');g.fillStyle=q;g.fillRect(-22,-26,44,52);
 g.strokeStyle='#12081f';g.lineWidth=2.4;const L=g.createLinearGradient(-9,-14,9,14);L.addColorStop(0,'#ffffff');L.addColorStop(.35,col);L.addColorStop(1,'#12081f');g.fillStyle=L;g.beginPath();g.moveTo(0,-16);g.lineTo(10,-4);g.lineTo(0,16);g.lineTo(-10,-4);g.closePath();g.fill();g.stroke();
 g.fillStyle='#ffffffcc';g.beginPath();g.moveTo(0,-13);g.lineTo(5,-4);g.lineTo(0,-2);g.lineTo(-4,-4);g.closePath();g.fill();g.strokeStyle='#ffd45a';g.lineWidth=2;g.beginPath();g.moveTo(-12,-4);g.lineTo(12,-4);g.stroke()})}
function rpySigil(col){return rpySpr('s'+col,200,200,(g)=>{g.translate(100,100);g.strokeStyle=col;g.globalAlpha=.85;g.lineWidth=3;g.beginPath();g.arc(0,0,92,0,TAU);g.stroke();g.lineWidth=1.6;g.beginPath();g.arc(0,0,78,0,TAU);g.stroke();
 for(let i=0;i<12;i++){g.save();g.rotate(i*TAU/12);g.translate(0,-85);g.beginPath();g.moveTo(-4,-4);g.lineTo(0,4);g.lineTo(4,-4);g.moveTo(0,-5);g.lineTo(0,5);g.stroke();g.restore()}
 g.globalAlpha=.5;g.beginPath();for(let i=0;i<6;i++){const a=i*TAU/6;i?g.lineTo(Math.cos(a)*70,Math.sin(a)*70):g.moveTo(Math.cos(a)*70,Math.sin(a)*70)}g.closePath();g.stroke();
 g.beginPath();for(let i=0;i<6;i++){const a=i*TAU/6+TAU/12;i?g.lineTo(Math.cos(a)*70,Math.sin(a)*70):g.moveTo(Math.cos(a)*70,Math.sin(a)*70)}g.closePath();g.stroke()})}
function rpyWing(col){return rpySpr('w'+col,120,110,(g)=>{g.translate(4,100);for(let i=0;i<5;i++){const a=-1.25+i*.22,L=96-i*11;g.save();g.rotate(a);const q=g.createLinearGradient(0,0,L,0);q.addColorStop(0,'#ffffff');q.addColorStop(.4,col);q.addColorStop(1,col+'22');
  g.fillStyle=q;g.strokeStyle='#12081f';g.lineWidth=1.8;g.globalAlpha=.92;g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(L*.5,-15,L,-3);g.quadraticCurveTo(L*.55,9,0,6);g.closePath();g.fill();g.globalAlpha=.6;g.stroke();g.restore()}})}
function rpyPillar(col){return rpySpr('p'+col,80,260,(g)=>{const q=g.createLinearGradient(0,0,0,260);q.addColorStop(0,col+'00');q.addColorStop(.55,col+'44');q.addColorStop(1,col+'88');g.fillStyle=q;g.beginPath();g.moveTo(22,0);g.lineTo(58,0);g.lineTo(76,260);g.lineTo(4,260);g.closePath();g.fill();
 const q2=g.createLinearGradient(0,0,80,0);q2.addColorStop(0,'#ffffff00');q2.addColorStop(.5,'#ffffff55');q2.addColorStop(1,'#ffffff00');g.globalCompositeOperation='source-atop';g.fillStyle=q2;g.fillRect(0,0,80,260)})}
/* ---------- the skinned tower ---------- */
let RPY_D=0;
{const f0=rpTowerDraw;rpTowerDraw=function(g,type,tier,skin,t,o){const T=!RPY_D&&skin&&rpySkinTheme(type,skin);if(!T)return f0.apply(this,arguments);o=o||{};t=t||0;
  const lv=+skin[1],col=T.glow,top=(rpTowerTop(type,tier)||100),icon=typeof RPG_ICON!=='undefined'&&RPG_ICON>0,q=icon||o.ghost?0:(typeof rpgQc==='function'?rpgQc():1),tt=q?t:1.3,ph=(o.ph||0)*TAU,el=T.el;
  RPY_D++;g.save();try{
   /* behind the tower */
   if(lv>=2){const r=58+6*Math.sin(tt*2+ph);g.globalAlpha=.55;g.drawImage(rpyGlowS(col),-r,-r*.42+4,r*2,r*.84);g.globalAlpha=1}
   const lite=!q&&!icon;
   if(lv>=4&&!lite){g.save();g.translate(0,4);g.scale(1,.36);g.rotate(tt*.35);g.globalAlpha=.7;g.drawImage(rpySigil(col),-78,-78,156,156);g.restore();g.globalAlpha=1}
   if(lv>=5){if(!lite){g.globalAlpha=.5+.15*Math.sin(tt*1.5);g.drawImage(rpyPillar(col),-40,-top-150,80,top+156);g.globalAlpha=1}
    const W=rpyWing(T.wing||col),fl=Math.sin(tt*2.2+ph)*.08,wy=-top*.62;for(const sd of[-1,1]){g.save();g.translate(sd*22,wy);g.scale(sd*1.05,1.05);g.rotate(-fl-.12);g.drawImage(W,-4,-100,120,110);g.restore()}}
   const orb=(front)=>{const n=lv>=5?8:6,R=40+tier*3,y0=-top*.42;for(let i=0;i<n;i++){const a=tt*.9+i*TAU/n+ph,z=Math.sin(a);if(front!==(z>0))continue;const x=Math.cos(a)*R,y=y0+z*R*.28,s=(.75+.25*z)*(lv>=5?1.1:1);g.drawImage(rpyEl(el,col),x-11*s,y-11*s,22*s,22*s)}};
   if(lv>=4)orb(false);
   /* the tower itself, recoloured */
   f0.call(this,rpyCtx(g,T),type,tier,'base',t,o);
   if(lv>=4)orb(true);
   if(lv>=3){const by=-top-26+Math.sin(tt*2.4+ph)*4;g.drawImage(rpyCrest(col),-15,by-18,30,36)}
   if(lv>=5){g.save();g.translate(0,-top-8);g.scale(1,.32);g.rotate(tt*.6);g.strokeStyle=col;g.lineWidth=5;g.globalAlpha=.85;g.beginPath();g.arc(0,0,30,0,TAU);g.stroke();g.lineWidth=2;g.strokeStyle='#ffffff';g.beginPath();g.arc(0,0,30,0,TAU);g.stroke();g.restore();g.globalAlpha=1}
   if(lv>=2&&q){const n=lv>=5?6:lv>=4?4:3;for(let i=0;i<n;i++){const u=(tt*.4+i/n+ph/TAU)%1,x=(Math.sin(i*12.9+ph)*.5)*60,y=-u*(top+30);g.globalAlpha=Math.sin(Math.PI*u)*.9;const s=12*(1-u*.4);g.drawImage(rpyEl(el,col),x-s/2,y-s/2,s,s)}g.globalAlpha=1}
  }finally{g.restore();RPY_D--}}}
/* build animation and Tower Skins previews draw through rpTowerDraw; the build ring / bar icons through rpTowerIcon (cached by skin) */
/* ---------- XP ---------- */
function rpyAdd(R,type,n){if(!(n>0)||!RPTW[type])return;const r=RPP();rpyXP(type);const l0=rpyLevel(type);r.mast[type]=Math.round((r.mast[type]||0)+n);if(R){R.mastG=R.mastG||{};R.mastG[type]=(R.mastG[type]||0)+n}
 const l1=rpyLevel(type);if(l1>l0){for(let i=l0+1;i<=l1;i++)r.own[type+':m'+i]=1;const nm=rpySet(type)[l1-1][1];if(R){R.mastUp=R.mastUp||[];R.mastUp.push([type,l1]);try{rpToast(`${RPTW[type].n} mastery ${RPY_ROM[l1]}! New skin: ${nm}`,3.2,'#ffd45a');rpSfx('up')}catch(e){}}}}
{const w0=rpWaveDone;rpWaveDone=function(){const R=RPX;try{if(R){const gain={};for(const p of R.pads){const tw=p.tw;if(!tw||tw.build<1)continue;const k=Math.max(0,(tw.kills||0)-(tw._mk||0));tw._mk=tw.kills||0;gain[tw.type]=(gain[tw.type]||0)+6*tw.tier+k}
  for(const t in gain)rpyAdd(R,t,gain[t]);try{save()}catch(e){}}}catch(e){console.error(e)}return w0.apply(this,arguments)}}
{const f0=rpFinish;rpFinish=function(won){const R=RPX;RPY_LAST=R?{mastG:R.mastG,mastUp:R.mastUp}:null;try{if(R&&won&&R.won&&!R.free&&!R._mWin){R._mWin=1;const used=new Set(R.pads.filter(p=>p.tw).map(p=>p.tw.type));for(const t of used)rpyAdd(R,t,50);save()}}catch(e){}return f0.apply(this,arguments)}}
/* the results card lists the mastery gained */
let RPY_LAST=null;
function rpyRes(){const R=RPX&&RPX.mastG?RPX:RPY_LAST,box=ov.querySelector('.rpres');if(!R||!box||!R.mastG||box.querySelector('.rpyres'))return;const ups=new Map((R.mastUp||[]).map(([t,l])=>[t,l]));
 const rows=Object.keys(R.mastG).sort((a,b)=>R.mastG[b]-R.mastG[a]).slice(0,6).map(t=>{const l=rpyLevel(t),x=rpyXP(t),nx=RPY_LV[l+1],pr=nx?(x-RPY_LV[l])/(nx-RPY_LV[l]):1;
  return `<span class="rpyr${ups.has(t)?' up':''}"><img alt="" src="${rpIconCanvas(t,3,rpSkinOf(t),56)}"><b>${esc(RPTW[t].n)}</b><i>${l?RPY_ROM[l]:'-'}</i><em><s style="transform:scaleX(${pr.toFixed(3)})"></s></em><small>+${cmn(R.mastG[t])} XP${ups.has(t)?' · new skin!':''}</small></span>`}).join('');
 const d=document.createElement('div');d.className='rpyres';d.innerHTML=`<small class="rpyrh">TOWER MASTERY</small><div>${rows}</div>`;const row=box.querySelector('.row');if(row)row.before(d);else box.appendChild(d)}
{const r0=rpResult;rpResult=function(){const out=r0.apply(this,arguments);try{rpyRes()}catch(e){console.error(e)}return out}}
{const r0=rpResultEndless;rpResultEndless=function(){const out=r0.apply(this,arguments);try{rpyRes()}catch(e){console.error(e)}return out}}
/* skins owned from the saved XP (old saves, cheats) */
function rpySync(){try{const r=RPP();for(const t of RP_TWORDER){const l=rpyLevel(t);for(let i=1;i<=l;i++)r.own[t+':m'+i]=1}}catch(e){}}
{const m0=rampartsMenu;rampartsMenu=function(){rpySync();return m0.apply(this,arguments)}}
/* ---------- the Tower Skins screen, with mastery ---------- */
const rpySkinList=t=>{const L=RP_SKINLIST().filter(s=>s.tw===t);rpySet(t).forEach(([th,n],i)=>L.push({tw:t,k:'m'+(i+1),n,how:`Mastery ${RPY_ROM[i+1]}`,mast:i+1}));return L};
rpSkins=function(back){back=back||(()=>rampartsMenu(title));rpySync();const r=RPP(),sn=rpStarN();
 const all=RP_TWORDER.flatMap(rpySkinList);if(!RPSKSEL||!all.some(s=>s.tw===RPSKSEL.tw&&s.k===RPSKSEL.k))RPSKSEL=all.find(s=>s.tw==='dragon'&&s.k==='azure')||all[0];
 const sel=all.find(s=>s.tw===RPSKSEL.tw&&s.k===RPSKSEL.k);RPSKSEL=sel;const own=rpSkinOwn(sel),on=rpSkinOf(sel.tw)===sel.k,twLock=(sel.tw==='dragon'&&!rpDragonOpen())||(typeof rpwTwLocked==='function'&&rpwTwLocked(sel.tw));
 const mine=rpySkinList(sel.tw),ml=rpyLevel(sel.tw),mx=rpyXP(sel.tw),nxt=RPY_LV[ml+1],pr=nxt?(mx-RPY_LV[ml])/(nxt-RPY_LV[ml]):1;
 const nav=RP_TWORDER.map(t=>{const l=rpyLevel(t);return `<button class="rpcsn${t===sel.tw?' on':''}" data-tw="${t}"><img alt="" src="${rpIconCanvas(t,3,rpSkinOf(t),88)}"><b>${esc(RPTW[t].n)}</b><i class="rpylv${l?'':' z'}">${l?RPY_ROM[l]:'·'}</i></button>`}).join('');
 const card=s=>{const o=rpSkinOwn(s),eq=rpSkinOf(s.tw)===s.k;return `<button class="rpskt rpcsk rpycard${o?'':' lock'}${eq?' eq':''}${s===sel?' sel':''}${s.champ?' champ':''}${s.mast?' m'+s.mast:''}" data-tw="${s.tw}" data-k="${s.k}"><span class="rpcskv"><img alt="" src="${rpIconCanvas(s.tw,3,s.k,176)}">${o?'':`<i class="rpsklk">${RPI.lock}</i>`}${s.mast?`<i class="rpytag">${RPY_ROM[s.mast]}</i>`:''}</span><b>${esc(s.n)}</b>
  <small class="rpcpill${eq?' eq':o?' own':''}">${eq?'✓ Equipped':o?'Equip':`${RPI.lock}<span>${s.champ?'Champion only':esc(s.how)}</span>`}</small></button>`};
 const track=`<div class="rpytrk"><div class="rpytl"><b>${esc(RPTW[sel.tw].n)} mastery</b><span>${ml?`Level ${RPY_ROM[ml]}`:'Not yet ranked'} · ${cmn(mx)} XP${nxt?` · next at ${cmn(nxt)}`:' · max'}</span></div>
  <div class="rpybar"><s style="transform:scaleX(${pr.toFixed(3)})"></s></div><div class="rpylvs">${[1,2,3,4,5].map(i=>`<span class="${ml>=i?'got':''}"><i>${RPY_ROM[i]}</i><em>${cmn(RPY_LV[i])}</em></span>`).join('')}</div>
  <p>Earn XP with this tower: every wave it survives (more at higher tiers), every monster it defeats, and every map you win with it. Each level unlocks a new skin.</p></div>`;
 const status=own?(on?'Equipped':'Owned'):'Locked',th=sel.mast?RPY_TH[rpySet(sel.tw)[sel.mast-1][0]]:null;
 const desc=sel.champ?`Blue steel, gold trim and blue fire. Only the season's champion wins it: hold the most waves in the Wonderland this season.`:sel.mast?`A mastery ${RPY_ROM[sel.mast]} skin: ${['','a fresh full recolour','a bold recolour with a glowing aura','with a floating gem crest','with an orbiting ring of its element and a turning rune sigil','the most epic: wings of light, a halo and a light pillar'][sel.mast]}.`:sel.k==='base'?`The classic ${esc(RPTW[sel.tw].n)}, as it was first built.`:own?'Yours to equip on every map.':`A new look for the ${esc(RPTW[sel.tw].n)}. ${esc(sel.how)} across the maps to unlock it.`;
 const req=sel.champ?`<div class="rpcreq">${RPTRO}<span><b>Finish #1 in Wonderland this season</b><em>Champion also earns ${cmn(RPLB_PRIZE)} coins.</em></span><span class="rpcend"><small>CHAMPIONSHIP ENDS IN</small><b>${esc(rpSeaLeft())}</b></span></div>`
  :sel.mast?`<div class="rpcreq"><i class="rpytag big">${RPY_ROM[sel.mast]}</i><span><b>Reach mastery ${RPY_ROM[sel.mast]} with the ${esc(RPTW[sel.tw].n)}</b><em>${cmn(Math.min(mx,RPY_LV[sel.mast]))} / ${cmn(RPY_LV[sel.mast])} XP</em></span><span class="rpcbar"><i style="transform:scaleX(${Math.min(1,mx/RPY_LV[sel.mast]).toFixed(3)})"></i></span></div>`
  :sel.star?`<div class="rpcreq">${RPI.star(1,30)}<span><b>Earn ${sel.star} stars across the maps</b><em>You have ${sn} stars.</em></span><span class="rpcbar"><i style="transform:scaleX(${Math.min(1,sn/sel.star)})"></i></span></div>`
  :`<div class="rpcreq">${RPI.keep}<span><b>Always yours</b><em>Every tower starts with its classic look.</em></span></div>`;
 const btn=own?(on&&sel.k!=='base'?`<button class="rpcact" id="rpskeq">Unequip</button>`:on?`<button class="rpcact" disabled>Equipped</button>`:`<button class="rpcact gold" id="rpskeq">Equip ${esc(sel.n)}</button>`)
  :sel.champ?`<button class="rpcact blue rpskch" id="rpskeq">View championship ›</button>`:`<button class="rpcact" disabled>${RPI.lock} ${esc(sel.how)}</button>`;
 show(`<div class="rpx rpskx rpc2sk rpysk" id="rpsk"><canvas class="rplbbg" id="rpskbg" width="1600" height="900"></canvas>
  <div class="rphtop"><button class="rpbk" id="rpskback" aria-label="Back (Esc)">‹ Back</button></div>
  <div class="rpcskh"><h1>Tower Skins</h1><p>Mastery & cosmetic collection</p></div>
  <nav class="rpcsl">${nav}</nav>
  <section class="rpcsm"><h3>${esc(RPTW[sel.tw].n)} Skins${twLock?' <em>locked tower</em>':''}</h3><div class="rpygrid">${mine.map(card).join('')}</div>${track}</section>
  <section class="rpcsr"><div class="rpskpv${sel.champ?' champ':''}"${th?` style="--g:${th.glow}"`:''}><canvas id="rpskcv" width="520" height="430"></canvas></div>
   <div class="rpcst"><span><h3>${esc(sel.n)}</h3><p class="rpsksub">${esc(RPTW[sel.tw].n)} ${sel.mast?'mastery skin':'cosmetic'}</p></span><span class="rpcstat ${status.toLowerCase()}">${status==='Locked'?RPI.lock:''}${status}</span></div>
   <p class="rpskd">${desc}${twLock?' This tower is not unlocked yet.':''}</p>${req}<div class="rpskbt">${btn}</div></section></div>`,'rpx rpskxx');
 S.view='ramparts';S.back=back;$('rpskback').onclick=()=>back();
 {const bg=$('rpskbg'),g=bg.getContext('2d');try{g.drawImage(rpWorldArt(rpWonderOpen()),0,0,1600,900)}catch(e){try{g.drawImage(rpBake(RP_MAP('moss')).c,0,0,1600,900)}catch(x){}}g.fillStyle='rgba(8,5,28,.78)';g.fillRect(0,0,1600,900)}
 {const cv=$('rpskcv');if(sel.tw==='dragon'&&sel.k==='azure')rpPrizeLive(cv,{tier:3,sc:2,x:.4,y:.92,clear:1});else{const g=cv.getContext('2d'),big=sel.mast>=5;const fn=t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,520,430);g.translate(260,big?395:380);g.scale(big?1.75:2.2,big?1.75:2.2);rpTowerDraw(g,sel.tw,3,sel.k,t,{aim:Math.sin(t*.7)*.8-.4,ph:.4,fire:(t%2.4)<.3?1-(t%2.4)/.3:0,charge:.6+.4*Math.sin(t*2)})};fn(1);if(!rpRM())LIVE.push({cv,fn,slow:2,vis:true})}}
 ov.querySelectorAll('.rpcsn').forEach(b=>b.onclick=()=>{const t=b.dataset.tw,L=rpySkinList(t);RPSKSEL=L.find(s=>rpSkinOf(t)===s.k)||L[0];try{rpSfx('key',2)}catch(e){}rpSkins(back)});
 ov.querySelectorAll('.rpskt').forEach(b=>b.onclick=()=>{const s=all.find(x=>x.tw===b.dataset.tw&&x.k===b.dataset.k);if(!s)return;RPSKSEL=s;try{rpSfx('key',2)}catch(e){}
  if(rpSkinOwn(s)&&rpSkinOf(s.tw)!==s.k){RPP().skin[s.tw]=s.k;save();try{rpSfx('up')}catch(e){}}rpSkins(back)});
 const eq=$('rpskeq');if(eq)eq.onclick=()=>{if(sel.champ&&!own){rpBoard(()=>rpSkins(back));return}const r2=RPP();r2.skin[sel.tw]=on?'base':sel.k;save();try{rpSfx('up')}catch(e){}rpSkins(back)};
 const cur=ov.querySelector('.rpcsn.on');if(cur)try{cur.scrollIntoView({block:'nearest'})}catch(e){}};
{const st=document.createElement('style');st.textContent=`
.rpysk .rpcsl{gap:2px}.rpysk .rpcsn{min-height:56px}.rpysk .rpcsn img{width:48px;height:48px}
.rpylv{min-width:26px;height:24px;display:grid;place-items:center;padding:0 4px;border-radius:8px;background:#ffd45a;color:#3a1a04!important;font:800 12px var(--ui)!important;font-style:normal}.rpylv.z{background:#2a1f6a;color:#8a7ec0!important}
.rpysk .rpcsm{padding:14px 18px}.rpysk .rpcsm h3{margin-bottom:10px;font-size:24px}
.rpygrid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;flex:1;min-height:0;align-content:start}
#ov .rpysk .rpcsk{flex:none;height:212px;padding:8px 6px 10px;gap:4px;border-radius:16px;border-width:2px}
.rpysk .rpcskv img{width:132px;height:132px}.rpysk .rpcsk>b{font-size:13.5px;text-align:center;line-height:1.15;min-height:31px;display:flex;align-items:center}
.rpysk .rpcpill{min-width:0;width:100%;padding:5px 6px;font-size:12px!important;border-radius:11px;box-sizing:border-box}
.rpytag{position:absolute;right:4px;top:4px;display:grid;place-items:center;min-width:24px;height:24px;padding:0 4px;border-radius:8px;background:linear-gradient(180deg,#ffe27a,#d89a2a);border:2px solid #12081f;color:#3a1a04;font:800 12px var(--ui);font-style:normal}
.rpytag.big{position:static;min-width:34px;height:34px;font-size:15px;flex:none}
#ov .rpysk .rpcsk.m4{background:linear-gradient(180deg,#2a1450,#0c0824)}#ov .rpysk .rpcsk.m5{background:linear-gradient(180deg,#3a2468,#140c34);border-color:#c89aff}
.rpytrk{margin-top:10px;padding:10px 14px 12px;border-radius:16px;background:#12081f90;border:2px solid #3a3070}.rpytl{display:flex;justify-content:space-between;align-items:baseline;gap:10px}
.rpytl b{font:800 15px var(--ui);color:#fff8e8}.rpytl span{font:700 12.5px var(--ui);color:#ffd45a}.rpybar{height:10px;margin-top:8px;border-radius:6px;background:#2a1f6a;border:2px solid #12081f;overflow:hidden}.rpybar s{display:block;height:100%;background:linear-gradient(90deg,#ffd45a,#ff9a3a);transform-origin:left center}
.rpylvs{display:flex;justify-content:space-between;margin-top:6px}.rpylvs span{display:flex;flex-direction:column;align-items:center;gap:1px;opacity:.55}.rpylvs span.got{opacity:1}
.rpylvs i{display:grid;place-items:center;width:30px;height:24px;border-radius:8px;background:#2a1f6a;border:2px solid #4a3a90;color:#cfc6f0;font:800 12px var(--ui);font-style:normal}.rpylvs span.got i{background:#ffd45a;border-color:#12081f;color:#3a1a04}.rpylvs em{font:700 10.5px var(--ui);font-style:normal;color:#a99be0}
.rpytrk p{margin:6px 0 0;font:500 12px/1.35 var(--ui);color:#c4badf}
.rpyres{margin:10px 0 4px;padding:10px 12px;border-radius:14px;background:#12081f90;border:2px solid #3a3070;text-align:left}.rpyrh{font:800 11px var(--ui);letter-spacing:.2em;color:#7ad8ff}
.rpyres>div{display:grid;grid-template-columns:1fr 1fr;gap:6px 14px;margin-top:6px}.rpyr{display:grid;grid-template-columns:36px 1fr auto;grid-template-rows:auto auto;column-gap:8px;align-items:center}
.rpyr img{grid-row:1/3;width:36px;height:36px}.rpyr b{font:700 13px var(--ui);color:#fff8e8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.rpyr i{font:800 12px var(--ui);font-style:normal;color:#ffd45a}
.rpyr em{grid-column:2;height:6px;border-radius:4px;background:#2a1f6a;overflow:hidden}.rpyr em s{display:block;height:100%;background:#ffd45a;transform-origin:left center}.rpyr small{grid-column:3;font:700 11px var(--ui);color:#a99be0}.rpyr.up small{color:#7dffb0}`;document.head.appendChild(st)}
/* ---------- help, How to play and DEV cheats for 10.0 ---------- */
try{const h=HELP.Modes.find(x=>x[0]==='Runestone Tower Defense');if(h)h[1]+=" Three worlds: the Runestone Realm, the Tidebreak Isles (a star on Ember Crown; towers reach tier IV) and Skyforge Heights (a star on Kraken's Maw; tier V), each with its own monsters, abilities and map twists; some monsters jam towers. Tower Mastery: every tower earns XP in battle (waves survived, monsters defeated, maps won); each of its five levels unlocks a new skin in Tower Skins. New towers: the Clockwork Hive (World 2) and the Singularity Engine (World 3)."}catch(e){}
{const h0=rpHowTo;rpHowTo=function(){const r=h0.apply(this,arguments);try{const w=ov.querySelector('#rpmod .rphw');if(w)w.insertAdjacentHTML('beforeend',`<p><b>Worlds.</b> Use the tabs to switch worlds. The Tidebreak Isles open with a star on Ember Crown (towers reach tier IV there), Skyforge Heights with a star on Kraken's Maw (tier V). Each world has its own monsters and twists: the tide, fog, whirlpools, gales, a switch track, a thunderstorm.</p>
 <p><b>Jammed towers.</b> Inklings ink a tower, Sparkjammers and the Titan's stomp short it out, and the storm's lightning strikes towers far from a lightning rod: a jammed tower stops firing for a moment.</p>
 <p><b>Mastery.</b> Every tower earns mastery XP in battle. Each of its five levels unlocks a skin; equip them in Tower Skins.</p>`)}catch(e){}return r}}
{const h0=dvxHTML;dvxHTML=function(){let h=h0.apply(this,arguments);try{if(typeof RPP==='function'){const sec=(t,b)=>`<div class="dvx"><h5>${t}</h5>${b}</div>`;
  h+=sec('Tower Defense: worlds & mastery',`<div class="dvrow">${dvBtn('x:tdw2','Open World 2')}${dvBtn('x:tdw3','Open World 3')}${dvBtn('x:tdw3all','3 stars on every new map')}</div>
   <div class="dvrow">${dvBtn('x:tdm1','Mastery I on every tower')}${dvBtn('x:tdm5','Max mastery on every tower')}${dvBtn('x:tdm0','Clear mastery')}</div>`)}}catch(e){}return h}}
{const a0=dvxAct;dvxAct=function(a){const r=typeof RPP==='function'?RPP():null;if(!r)return a0.apply(this,arguments);
 if(a==='tdw2'){if(!(r.stars.ember>0))r.stars.ember=1;dvxMsg('World 2 is open.')}
 else if(a==='tdw3'){for(const id of['ember','coral','wreck','abyss'])if(!(r.stars[id]>0))r.stars[id]=1;dvxMsg('World 3 is open.')}
 else if(a==='tdw3all'){for(const m of RP_MAPS)if(m.world>1)r.stars[m.id]=3;if(!(r.stars.ember>0))r.stars.ember=1;dvxMsg('3 stars on every World 2 and 3 map.')}
 else if(a==='tdm1'||a==='tdm5'){rpyXP('ballista');for(const t of RP_TWORDER)r.mast[t]=Math.max(r.mast[t]||0,RPY_LV[a==='tdm1'?1:5]);rpySync();dvxMsg(a==='tdm1'?'Mastery I on every tower.':'Max mastery (V) on every tower: every mastery skin is yours.')}
 else if(a==='tdm0'){r.mast={};for(const k of Object.keys(r.own))if(/:m[1-5]$/.test(k))delete r.own[k];for(const t in r.skin)if(/^m[1-5]$/.test(r.skin[t]))r.skin[t]='base';dvxMsg('Mastery cleared.')}
 else return a0.apply(this,arguments);try{save()}catch(e){}try{devRender()}catch(e){}}}
