/* ===== UPDATE 10.4, THE HARVEST FESTIVAL: harvest weapons (99n2, prefix flg) =====
   WNEW builders (29c_wbuild.js): grip at the origin, tip toward +x, L=70 on the hero. One per rarity, each grander than the last:
   a farmhand's Hayfork, the Baker's Rolling Pin, the Maple Longbow, the Acorn Flail (its chain always hangs toward the ground),
   the Cranberry Glaive and the Mythic Horn of Plenty, a golden cornucopia warhammer that spills fruit-light.
   No shadow blur (the game's performance rules): glows are radial gradients, sparks are small shapes. */

/* the direction of "down on the screen" in the weapon's own frame, so hanging things hang */
function flgDown(g){try{const m=g.getTransform();if(m.a*m.d-m.b*m.c<=0)return Math.PI/2;return Math.PI/2-Math.atan2(m.b,m.a)}catch(e){return Math.PI/2}}

/* Common: Hayfork, a farmhand's pitchfork bound with twine, a straw bundle and a corn-husk doll */
WNEW.fl_fork=(g,L,t,X)=>{g.shadowBlur=0;const wood='#7a5a32',P=[];for(let i=0;i<=16;i++){const u=i/16;P.push([-L*.22+u*L*.92,Math.sin(u*5+.6)*1.1])}
 rib(g,P,u=>2.5-u*.3,wood);
 for(const u of[.32,.6]){const x=-L*.22+u*L*.92;ell(g,x,Math.sin(u*5+.6)*1.1,1.6,2.2,shade(wood,-.3))}
 wrapG(g,-L*.06,L*.1,0,3.1,'#4a3418');
 const hx=L*.7;
 /* straw bundle tied under the head */
 for(let i=0;i<14;i++){const a=(i-6.5)*.07,len=L*.15+(i%3)*2;g.strokeStyle=i%3?'#e8c860':'#c8a038';g.lineWidth=1.2;g.beginPath();g.moveTo(hx-L*.12,(i-6.5)*.5);g.lineTo(hx-L*.12-Math.cos(a)*len,(i-6.5)*.5+Math.sin(a)*len*1.6+Math.sin(t*2+i)*.6);g.stroke()}
 g.fillStyle='#a8322a';g.fillRect(hx-L*.13,-3.6,3,7.2);g.strokeStyle='#5a120e';g.lineWidth=.8;g.strokeRect(hx-L*.13,-3.6,3,7.2);
 /* the iron head: crosspiece and three tines */
 const T=[[-7.2,-1],[0,0],[7.2,1]];g.lineCap='round';
 for(const [y0,s] of T){g.strokeStyle='#12081f';g.lineWidth=3.6;g.beginPath();g.moveTo(hx,y0);g.bezierCurveTo(hx+L*.08,y0+s*2.6,hx+L*.2,y0+s*1.4,hx+L*.34,y0+s*.4);g.stroke();
  g.strokeStyle='#8a8e98';g.lineWidth=2.2;g.stroke();g.strokeStyle='#d8dce4aa';g.lineWidth=.8;g.beginPath();g.moveTo(hx+2,y0-.6);g.bezierCurveTo(hx+L*.08,y0+s*2.6-.6,hx+L*.2,y0+s*1.4-.6,hx+L*.31,y0+s*.4-.5);g.stroke()}
 arBev(g,[hx-2.6,-8.6,hx+3,-8.6,hx+3,8.6,hx-2.6,8.6],'#5a5e68',{ow:1.1});
 g.strokeStyle='#c8a068';g.lineWidth=1;for(let i=0;i<4;i++){g.beginPath();g.moveTo(hx-4+i*1.2,-4);g.lineTo(hx-3+i*1.2,4);g.stroke()}
 /* a corn-husk doll swinging on twine */
 {const a=flgDown(g)+Math.sin(t*2.2)*.3,ax=L*.48,ay=2,dx=Math.cos(a),dy=Math.sin(a);g.strokeStyle='#c8a068';g.lineWidth=.8;g.beginPath();g.moveTo(ax,ay);g.lineTo(ax+dx*7,ay+dy*7);g.stroke();
  g.save();g.translate(ax+dx*7,ay+dy*7);g.rotate(a-Math.PI/2);ell(g,0,1.8,1.9,1.9,'#e8d8a0');poly(g,[-1.4,3,1.4,3,3.4,10,-3.4,10],'#d8c488','#12081f99',.7);g.strokeStyle='#a8322a';g.lineWidth=.9;g.beginPath();g.moveTo(-1.8,5.2);g.lineTo(1.8,5.2);g.stroke();
  limb(g,-1.2,4.4,-3.4,7,.9,'#d8c488');limb(g,1.2,4.4,3.4,7,.9,'#d8c488');g.restore()}
 for(let i=0;i<3;i++){const u=(t*.5+i/3)%1;g.save();g.translate(hx-L*.2-u*L*.3,8+u*16);g.rotate(t*2+i);g.globalAlpha=Math.sin(u*Math.PI)*.8;g.strokeStyle='#e8c860';g.lineWidth=1;g.beginPath();g.moveTo(-2.4,0);g.lineTo(2.4,0);g.stroke();g.restore()}g.globalAlpha=1};

/* Uncommon: Baker's Rolling Pin, a heavy maple pin, flour-dusted, a gingham ribbon and a cookie-cutter charm */
WNEW.fl_pin=(g,L,t,X)=>{g.shadowBlur=0;const wd='#d8a868',x0=L*.16,x1=L*.8,R=6.6;
 /* handle */
 g.fillStyle=vgr(g,-3,3,'#e8c088','#8a5a2a');g.beginPath();g.roundRect(-L*.16,-2.8,L*.31,5.6,2.6);g.fill();g.strokeStyle='#12081fcc';g.lineWidth=1.1;g.stroke();
 ell(g,-L*.17,0,3.4,3.4,vgr(g,-3.4,3.4,'#f0cc90','#9a6a32'));ell(g,L*.13,0,2.4,3.4,'#b88448');
 /* the barrel */
 const bar=()=>{g.beginPath();g.roundRect(x0,-R,x1-x0,R*2,R*.9)};bar();
 {const q=g.createLinearGradient(0,-R,0,R);q.addColorStop(0,'#fff0c8');q.addColorStop(.25,wd);q.addColorStop(.7,'#b07838');q.addColorStop(1,'#6a4018');g.fillStyle=q;g.fill()}
 g.save();bar();g.clip();g.strokeStyle='#8a5a2a55';g.lineWidth=.8;for(let i=0;i<5;i++){g.beginPath();g.moveTo(x0,-R+2+i*2.4);g.bezierCurveTo(x0+L*.2,-R+1+i*2.6,x0+L*.4,-R+3+i*2.2,x1,-R+2.2+i*2.4);g.stroke()}
 g.fillStyle='#ffffffcc';for(let i=0;i<26;i++){const u=rnd(i*3.1),v=rnd(i*7.7);g.fillRect(x0+u*(x1-x0),-R+v*R*1.1,1.2,1)}g.fillStyle='#ffffff40';g.fillRect(x0,-R,x1-x0,R*.6);g.restore();
 bar();g.strokeStyle='#12081fdd';g.lineWidth=1.2;g.stroke();
 /* far handle */
 g.fillStyle=vgr(g,-2.6,2.6,'#e8c088','#8a5a2a');g.beginPath();g.roundRect(x1-1,-2.4,L*.18,4.8,2.2);g.fill();g.strokeStyle='#12081fcc';g.lineWidth=1;g.stroke();ell(g,x1+L*.19,0,3.2,3.2,vgr(g,-3.2,3.2,'#f0cc90','#9a6a32'));
 /* gingham ribbon tied by the grip */
 {const rx=x0+3,sw=Math.sin(t*3)*1.6;g.fillStyle='#d8322a';g.fillRect(rx-1.6,-R-.4,3.4,R*2+.8);g.fillStyle='#ffffffaa';for(let y=-R;y<R;y+=2.2)g.fillRect(rx-1.2,y,1.2,1.1);
  for(const s of[-1,1])poly(g,[rx,R-1,rx-3+s*2,R+8+sw*s,rx+1+s*3,R+9-sw*s,rx+1.6,R],s<0?'#d8322a':'#c02824','#12081fbb',.8);ell(g,rx+.2,R,1.8,1.6,'#e84a3a')}
 /* a little maple-leaf cookie cutter on a string */
 {const a=flgDown(g)+Math.sin(t*2.6+1)*.25,ax=L*.62,ay=R-1,dx=Math.cos(a),dy=Math.sin(a);g.strokeStyle='#e8e0d0';g.lineWidth=.6;g.beginPath();g.moveTo(ax,ay);g.lineTo(ax+dx*6,ay+dy*6);g.stroke();
  g.save();g.translate(ax+dx*10,ay+dy*10);g.rotate(a-Math.PI/2);flgMaple(g,0,0,3.6,Math.PI,'#c8d0dc',{ow:1,vein:'#6a7080aa'});g.restore()}
 /* flour puffs */
 for(let i=0;i<4;i++){const u=(t*.4+i/4)%1;g.globalAlpha=Math.sin(u*Math.PI)*.75;g.fillStyle='#fff8ec';g.fillRect(x0+L*(.1+i*.15)+Math.sin(u*5+i)*2,R+1+u*18,1.1,1.1)}g.globalAlpha=1};

/* Rare: Maple Longbow, maple-red limbs carved with veins, leaves tied at the tips, a leaf that drifts away */
WNEW.fl_maple=(g,L,t,X)=>{g.shadowBlur=0;wBow(g,L,t,{c:'#c4542a',lw:3.3,grip:'#3a5a22',str:'#f4e6c0',sw:1.1,nock:'#e8b04a',head:'#e8eefc',
 back:(g,G,h,bw)=>{g.save();g.globalCompositeOperation='lighter';glow(g,0,bw*.1,L*.44,'#ff8a2a26');g.restore()},
 limb:(g,G,h,bw,gy)=>{for(const s of[-1,1]){for(const u of[.2,.38,.56]){const p=G.at(u,s);g.strokeStyle='#ffd8a066';g.lineWidth=.7;g.beginPath();g.moveTo(p.x-p.nx*1.6,p.y-p.ny*1.6);g.lineTo(p.x+p.nx*1.6+p.tx*2*s,p.y+p.ny*1.6+p.ty*2*s);g.stroke()}
   const e=G.at(.04,s);for(let k=0;k<2;k++)flgMaple(g,e.x+s*(1.6+k*2.4),e.y+3.4+k*2.6,3.4-k*.6,s*.7+Math.sin(t*2.6+k+s)*.25+k*.6,k?'#f0a030':'#d8441a',{ow:.8})}
  g.save();g.translate(0,gy);arBev(g,[-3.4,-6,3.4,-6,3,6,-3,6],'#5a3a1a',{ow:.9});flgMaple(g,0,0,3.4,0,'#e8b04a',{ow:.8,vein:'#8a5a1a99'});g.restore();
  {const u=(t*.3)%1;g.globalAlpha=Math.sin(u*Math.PI)*.9;flgMaple(g,h*.2+u*L*.2,bw*.3+u*L*.34,2.8,t*2,'#e86a1e',{ow:.7});g.globalAlpha=1}}})};

/* Epic: Acorn Flail, an oak haft, an iron chain that hangs to the ground and a great iron-capped acorn with an amber glow */
WNEW.fl_acorn=(g,L,t,X)=>{g.shadowBlur=0;const oak='#6a4424';
 const P=[];for(let i=0;i<=10;i++){const u=i/10;P.push([-L*.2+u*L*.66,Math.sin(u*4)*.6])}rib(g,P,u=>2.9-u*.2,oak);
 wrapG(g,-L*.16,L*.08,0,3.4,'#3a1e0e');for(const x of[L*.12,L*.3,L*.44]){g.fillStyle=metal(g,-4,4,'#7a7e88');g.beginPath();g.roundRect(x-1.6,-3.8,3.2,7.6,1.2);g.fill();g.strokeStyle='#12081fcc';g.lineWidth=.9;g.stroke()}
 /* oak leaves at the grip */
 for(const [a,s] of[[2.5,1],[1.9,-1]]){g.save();g.translate(L*.11,0);g.rotate(a+Math.sin(t*1.8+s)*.08);g.beginPath();g.moveTo(0,0);for(let k=1;k<=4;k++){const x=k*3.1,w=3.4-Math.abs(k-2.4)*.5;g.quadraticCurveTo(x-1.6,-w-1.4,x,-w*.55)}g.quadraticCurveTo(14.6,0,12.4,.6);for(let k=4;k>=1;k--){const x=k*3.1,w=3.4-Math.abs(k-2.4)*.5;g.quadraticCurveTo(x+1.6,w+1.4,x-1.6,w*.55)}g.closePath();
  g.fillStyle=s>0?'#6a8a2a':'#9aa83a';g.fill();g.strokeStyle='#12081fcc';g.lineWidth=.9;g.stroke();g.strokeStyle='#ffffff55';g.lineWidth=.6;g.beginPath();g.moveTo(1,0);g.lineTo(12,0);g.stroke();g.restore()}
 flgAcorn(g,L*.1,4.4,2.6,.5,{ow:.8});
 const ex=L*.47;ell(g,ex+2,0,3,3.6,'#5a5e68');g.strokeStyle='#12081fcc';g.lineWidth=1;g.beginPath();g.ellipse(ex+2,0,3,3.6,0,0,TAU);g.stroke();
 /* the chain: it swings around "down" */
 const a=flgDown(g)+Math.sin(t*2.1)*.32-.25,n=6,cl=L*.06;let px=ex+3,py=0;
 for(let i=0;i<n;i++){const aa=a+Math.sin(t*2.1-i*.3)*.06*i,nx=px+Math.cos(aa)*cl,ny=py+Math.sin(aa)*cl;g.save();g.translate((px+nx)/2,(py+ny)/2);g.rotate(aa);g.strokeStyle='#12081f';g.lineWidth=2.6;g.beginPath();g.ellipse(0,0,cl*.62,i%2?1.2:2.2,0,0,TAU);g.stroke();g.strokeStyle=i%2?'#8a8e98':'#aeb2bc';g.lineWidth=1.3;g.stroke();g.restore();px=nx;py=ny}
 /* the acorn head: its cap hangs from the chain */
 {const r=9.6;g.save();g.translate(px+Math.cos(a)*r*1.3,py+Math.sin(a)*r*1.3);g.rotate(a-Math.PI/2);
  g.save();g.globalCompositeOperation='lighter';glow(g,0,r*.4,r*3,'#ffa83a'+flgA(.32+.12*Math.sin(t*3)));g.restore();
  flgAcorn(g,0,0,r,0,{nut:'#7a3e14',nut2:'#e8a050',cap:'#5a5a62',ow:1.2});
  for(let i=0;i<5;i++){const aa=Math.PI*(1.12+i*.19),sx=Math.cos(aa)*r*1.02,sy=Math.sin(aa)*r*.62-r*.2;poly(g,[sx-1.7,sy+.6,sx+Math.cos(aa)*4.6,sy+Math.sin(aa)*4.2,sx+1.7,sy+.6],'#d8dce4','#12081fcc',.8)}
  g.strokeStyle='#ffe08a';g.lineWidth=.9;g.beginPath();g.moveTo(-r*.5,r*1.1);g.quadraticCurveTo(0,r*1.4,r*.5,r*1.1);g.stroke();
  g.save();g.globalCompositeOperation='lighter';g.globalAlpha=.5+.3*Math.sin(t*3);g.strokeStyle='#ffc060';g.lineWidth=1.2;g.beginPath();g.moveTo(-r*.92,-r*.1);g.quadraticCurveTo(0,r*.2,r*.92,-r*.1);g.stroke();g.restore();g.restore()}
 /* oak leaves drift down */
 for(let i=0;i<2;i++){const u=(t*.32+i*.5)%1,lx=L*(.1+i*.22)+Math.sin(u*7+i)*4,ly=6+u*26;g.save();g.translate(lx,ly);g.rotate(t*1.6+i*2);g.globalAlpha=Math.sin(u*Math.PI)*.85;leafG(g,-3,0,0,6.4,2.4,i?'#d8a030':'#8a9a3a');g.restore()}g.globalAlpha=1};

/* Legendary: Cranberry Glaive, a crimson crescent blade on a corded haft, a cluster of glowing cranberries, frost on the steel */
WNEW.fl_glaive=(g,L,t,X)=>{g.shadowBlur=0;const pu=.75+.25*Math.sin(t*3);
 g.save();g.globalCompositeOperation='lighter';glow(g,L*.76,-L*.06,L*.5,'#ff2a4a26');g.restore();
 /* haft: dark wood wrapped in crimson cord, gold ferrules */
 g.fillStyle=vgr(g,-3,3,'#5a3420','#1e0e08');g.beginPath();g.roundRect(-L*.22,-2.8,L*.72,5.6,2.6);g.fill();g.strokeStyle='#12081fcc';g.lineWidth=1.1;g.stroke();
 g.strokeStyle='#c8203a';g.lineWidth=1.1;for(let x=-L*.2;x<L*.12;x+=3.6){g.beginPath();g.moveTo(x,-2.8);g.lineTo(x+2.2,2.8);g.moveTo(x+2.2,-2.8);g.lineTo(x,2.8);g.stroke()}
 for(const x of[-L*.22,L*.14,L*.46]){g.fillStyle=metal(g,-4,4,'#e6b93e');g.beginPath();g.roundRect(x-1.6,-3.6,3.6,7.2,1.4);g.fill();g.strokeStyle='#12081fcc';g.lineWidth=.9;g.stroke()}
 /* the blade */
 const b0=L*.5,bl=()=>{g.beginPath();g.moveTo(b0,-3.2);g.bezierCurveTo(b0+L*.18,-5.4,b0+L*.36,-9,b0+L*.56,-L*.2);g.bezierCurveTo(b0+L*.5,-L*.05,b0+L*.36,4,b0+L*.16,6.6);g.quadraticCurveTo(b0+L*.08,7.6,b0+L*.06,10.6);g.lineTo(b0,4);g.closePath()};
 bl();{const q=g.createLinearGradient(0,-L*.2,0,10);q.addColorStop(0,'#ffb0bc');q.addColorStop(.35,'#e0304a');q.addColorStop(.75,'#8a0a20');q.addColorStop(1,'#4a0410');g.fillStyle=q;g.fill()}
 g.save();bl();g.clip();g.strokeStyle='#ffffffcc';g.lineWidth=1.3;g.beginPath();g.moveTo(b0+2,-3.6);g.bezierCurveTo(b0+L*.18,-5.8,b0+L*.36,-9.4,b0+L*.55,-L*.195);g.stroke();
 g.fillStyle='#5a061888';g.beginPath();g.moveTo(b0+4,0);g.bezierCurveTo(b0+L*.18,-1.4,b0+L*.32,-3.6,b0+L*.44,-L*.12);g.lineTo(b0+L*.4,-L*.08);g.bezierCurveTo(b0+L*.28,-.6,b0+L*.16,2.4,b0+4,2.6);g.closePath();g.fill();
 g.fillStyle='#ffffffcc';for(let i=0;i<12;i++){const u=rnd(i*5.3),v=rnd(i*2.9);g.fillRect(b0+4+u*L*.42,-L*.12*u+v*6-2,1,1)}
 {const sp=((t*.6)%1)*L*.7;g.strokeStyle='#ffffff55';g.lineWidth=2;g.beginPath();g.moveTo(b0+sp,-12);g.lineTo(b0+sp-6,10);g.stroke()}g.restore();
 bl();g.strokeStyle='#12081fdd';g.lineWidth=1.2;g.stroke();
 /* cranberry cluster and two leaves at the collar */
 for(const [a,s] of[[-2.2,1],[-1.2,-1]]){g.save();g.translate(b0-1,-2);g.rotate(a);arBev(g,[0,-1.8,5,-3,10,0,5,3,0,1.8],s>0?'#3a6a2a':'#4a7a2a',{sm:1,ow:.9});g.restore()}
 g.save();g.globalCompositeOperation='lighter';glow(g,b0-2,1,12,'#ff3050'+flgA(.4*pu));g.restore();
 for(const [bx,by,r] of[[-4,-1,2.6],[-1,2.4,2.4],[1.6,-1.6,2.2],[-5.4,3.4,2],[2.6,2,2]]){ell(g,b0+bx,by,r,r,rgr(g,b0+bx-r*.4,by-r*.4,.2,r*1.2,'#ff8a9a','#a8081e'));ell(g,b0+bx-r*.35,by-r*.35,r*.3,r*.3,'#ffffffcc')}
 /* juice drop and rising sparks */
 {const u=(t*.5)%1;g.globalAlpha=1-u*.8;const dx=b0+L*.22,dy=6+u*16;g.fillStyle='#c8102a';g.beginPath();g.moveTo(dx,dy-2.4);g.quadraticCurveTo(dx+1.8,dy+.4,dx,dy+1.8);g.quadraticCurveTo(dx-1.8,dy+.4,dx,dy-2.4);g.fill();g.globalAlpha=1}
 g.save();g.globalCompositeOperation='lighter';for(let i=0;i<6;i++){const u=(t*.45+i/6)%1;g.globalAlpha=Math.sin(u*Math.PI)*.8;ell(g,b0+L*(.06+i*.08)+Math.sin(u*6+i)*2,-6-u*18,1.2,1.2,i%2?'#ff6a80':'#ffd0d8')}g.restore()};

/* Mythic: Horn of Plenty, a golden cornucopia warhammer; the horn's mouth spills glowing fruit, the back is a sheaf-struck hammer face */
/* (the fruit helpers flgFruit / flgFruitImg live in 99n) */
const FLG_HH={};
function flgHornHead(L){if(FLG_HH[L])return FLG_HH[L];const hx=L*.82,k=4,x0=hx-L*.24,y0=-L*.38,w=L*.66,h=L*.82,c=document.createElement('canvas');c.width=Math.ceil(w*k);c.height=Math.ceil(h*k);const g=c.getContext('2d');g.scale(k,k);g.translate(-x0,-y0);g.lineJoin='round';g.lineCap='round';
 const OL0=OL;OL=0;
 const B=[[hx-2,-L*.2],[hx-5,-L*.04],[hx+L*.02,L*.1],[hx+L*.17,L*.2]],bz=(u,k)=>{const m=1-u;return m*m*m*B[0][k]+3*m*m*u*B[1][k]+3*m*u*u*B[2][k]+u*u*u*B[3][k]};
 const C=[];{let x=B[0][0],y=B[0][1],h=Math.atan2(B[0][1]-B[1][1],B[0][0]-B[1][0]);const cu=[];for(let k=0;k<11;k++){const ds=1.25;h+=.3+k*.045;x+=Math.cos(h)*ds;y+=Math.sin(h)*ds;cu.push([x,y])}for(let k=cu.length-1;k>=0;k--)C.push(cu[k])}
 const NB=16;for(let i=0;i<=NB;i++){const u=i/NB;C.push([bz(u,0),bz(u,1)])}
 const n=C.length,wf=u=>.5+Math.pow(u,1.25)*L*.125,poly2=hwTube(C,wf);
 arBev(g,poly2,'#e8b53a',{ow:1.2,edge:'#fff2b8',ew:1.2,tex:(g2,b)=>{g2.strokeStyle='#9a6418aa';g2.lineWidth=.8;g2.beginPath();for(let k=-30;k<30;k+=2.8){g2.moveTo(b[0]+k,b[1]);g2.lineTo(b[0]+k+30,b[1]+30);g2.moveTo(b[0]+k+30,b[1]);g2.lineTo(b[0]+k,b[1]+30)}g2.stroke();g2.fillStyle='#ffffff30';g2.fillRect(b[0],b[1],b[2]-b[0],(b[3]-b[1])*.3)}});
 for(const u of[.5,.66,.82]){const i=Math.round(u*(n-1)),p=C[i],q=C[Math.min(n-1,i+1)],a=Math.atan2(q[1]-p[1],q[0]-p[0]),w=wf(u)*1.05;g.strokeStyle='#12081f';g.lineWidth=2.8;g.beginPath();g.moveTo(p[0]-Math.sin(a)*w,p[1]+Math.cos(a)*w);g.lineTo(p[0]+Math.sin(a)*w,p[1]-Math.cos(a)*w);g.stroke();g.strokeStyle='#ffe07a';g.lineWidth=1.6;g.stroke()}
 /* the mouth, glowing from within */
 const m=C[n-1],mp=C[n-3],ma=Math.atan2(m[1]-mp[1],m[0]-mp[0]),mw=wf(1)*1.04;
 g.save();g.translate(m[0],m[1]);g.rotate(ma);ell(g,0,0,3,mw,'#3a1a06');g.strokeStyle='#12081f';g.lineWidth=3;g.beginPath();g.ellipse(0,0,3,mw,0,0,TAU);g.stroke();g.strokeStyle='#fff2b8';g.lineWidth=1.6;g.stroke();g.restore();
 /* fruit resting in the mouth */
 const ox=Math.cos(ma),oy=Math.sin(ma),nx=-oy,ny=ox;
 flgFruitImg(g,'wheat',m[0]+ox*1-nx*5,m[1]+oy*1-ny*5,1.1,ma+1.5);flgFruitImg(g,'grapes',m[0]+ox*3+nx*3.4,m[1]+oy*3+ny*3.4,1.1,ma-.9);flgFruitImg(g,'apple',m[0]+ox*4.4-nx*1.4,m[1]+oy*4.4-ny*1.4,1.2,-.2);flgFruitImg(g,'pear',m[0]+ox*2.4+nx*.4,m[1]+oy*2.4+ny*.4,1,.5);
 OL=OL0;return FLG_HH[L]={c,x0,y0,w,h,m,ma,mw}}
WNEW.fl_horn=(g,L,t,X)=>{g.shadowBlur=0;const pu=.8+.2*Math.sin(t*3.2),hx=L*.82;
 g.save();g.globalCompositeOperation='lighter';glow(g,L*.66,L*.06,L*.8,'#ffc84a26');glow(g,hx+L*.08,L*.14,L*.4,'#ffb43a'+flgA(.26+.08*pu));g.restore();
 /* haft: polished dark wood, gold bands and a spiral of gold wire, a ruby pommel */
 const P=[];for(let i=0;i<=14;i++){const u=i/14;P.push([-L*.22+u*L*1.06,0])}rib(g,P,u=>2.9,'#4a2a14');
 g.strokeStyle='#ffd86acc';g.lineWidth=.9;g.beginPath();for(let x=L*.12;x<L*.68;x+=1){const y=Math.sin(x*.55)*2.6;x===L*.12?g.moveTo(x,y):g.lineTo(x,y)}g.stroke();
 wrapG(g,-L*.14,L*.1,0,3.4,'#6a1424');for(const x of[-L*.21,L*.12,L*.42,L*.68]){g.fillStyle=metal(g,-4.2,4.2,'#f0c040');g.beginPath();g.roundRect(x-1.8,-4,3.8,8,1.4);g.fill();g.strokeStyle='#12081fcc';g.lineWidth=.9;g.stroke()}
 {const gp=.7+.3*Math.sin(t*2.6);g.save();g.globalCompositeOperation='lighter';glow(g,-L*.26,0,10,'#ff3a5a'+flgA(.5*gp));g.restore();poly(g,[-L*.21,0,-L*.25,-4.4,-L*.31,0,-L*.25,4.4],'#e81e3a','#4a0410',1);poly(g,[-L*.21,0,-L*.25,-4.4,-L*.27,-1],'#ffaab4aa')}
 /* the cornucopia head (a woven golden horn across the haft's end; the curled tip is the back spike, the mouth spills fruit):
    painted once per weapon length by flgHornHead, which also gives the mouth's position and angle */
 const HD=flgHornHead(L),m=HD.m,ma=HD.ma,ox=Math.cos(ma),oy=Math.sin(ma);g.drawImage(HD.c,HD.x0,HD.y0,HD.w,HD.h);
 g.save();g.translate(m[0],m[1]);g.rotate(ma);g.globalCompositeOperation='lighter';glow(g,2,0,HD.mw*2.2,'#ffd86a'+flgA(.5*pu));g.restore();
 /* fruit-light spills from the mouth and falls toward the ground */
 const dn=flgDown(g);for(let i=0;i<5;i++){const u=(t*.42+i/5)%1,k=FLG_FRUIT[i%FLG_FRUIT.length],sx=m[0]+ox*6,sy=m[1]+oy*6,fx=sx+ox*u*10+Math.cos(dn)*u*u*L*.46+Math.sin(i*2.1)*u*6,fy=sy+oy*u*10+Math.sin(dn)*u*u*L*.46;
  g.globalAlpha=Math.min(1,Math.sin(u*Math.PI)*1.6);g.save();g.globalCompositeOperation='lighter';glow(g,fx,fy,10,['#ff5a3a','#c8e04a','#b06aff','#ff9a2a','#ffe08a','#ffc040'][i%6]+'88');g.restore();flgFruit(g,k,fx,fy,.85,t,t*2+i)}g.globalAlpha=1;
 /* a cranberry gem where horn meets haft, and sparkles */
 gem(g,hx-3.4,0,2.8,'#e81e3a');
 for(let i=0;i<4;i++){const u=(t*.6+i/4)%1,x=hx-L*.1+i*L*.08,y=-L*.26-u*10,s=(1-u)*2.2+.6;g.globalAlpha=Math.sin(u*Math.PI);g.fillStyle='#fff6c8';g.fillRect(x-.5,y-s*1.6,1,s*3.2);g.fillRect(x-s*1.6,y-.5,s*3.2,1)}g.globalAlpha=1};

/* item thumbnails: art() frames each weapon type the same way; the pin, the flail's hanging chain, the glaive and the horn need their own
   framing so nothing is cut off. [x, y, scale, angle] as in art()'s table. */
const FLG_ARTQ={fl_pin:[.2,.74,.74,-.72],fl_acorn:[.22,.56,.64,-.62],fl_glaive:[.17,.86,.76,-.8],fl_horn:[.17,.79,.62,-.72]};
{const a0=art;art=function(cvs,k,id,t){if(k!=='w'||!FLG_ARTQ[id]||!WP[id])return a0.apply(this,arguments);
  const g=cvs.getContext('2d'),w=cvs.width,h=cvs.height,it=WP[id],Q=FLG_ARTQ[id];g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,w,h);
  const gl=g.createRadialGradient(w/2,h*.55,2,w/2,h*.55,w*.5);gl.addColorStop(0,it.col+'66');gl.addColorStop(1,it.col+'00');g.fillStyle=gl;g.fillRect(0,0,w,h);
  g.save();g.translate(w*Q[0],h*Q[1]);g.rotate(Q[3]);const s=Math.min(w,h)/78*Q[2];g.scale(s,s);drawW(g,id,84,t||0);g.restore()}}
