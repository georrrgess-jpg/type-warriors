/* ===== LANTERN CARAVAN: the scene, the wagon, the lantern, the banner and the gate =====
   Static layers are baked once per route into strips (abSprite cache) and scrolled by WRX.x with a parallax factor.
   The wagon is drawn each frame from a few dozen shapes: chunky #12081f outlines, darker right halves, upper-left
   highlights, like the keepers and the fishing art. No ctx.filter or shadowBlur anywhere. */
const WRO='#12081f';
const WRB={};
function wrStroke(g,lw){g.lineWidth=lw||3;g.strokeStyle=WRO;g.lineJoin='round';g.lineCap='round';g.stroke()}
function wrFill(g,fill,lw){g.fillStyle=fill;g.fill();if(lw!==0)wrStroke(g,lw)}
function wrHi(g,x1,y1,x2,y2,w,a){g.strokeStyle=`rgba(255,255,255,${a==null?.55:a})`;g.lineWidth=w||2.4;g.lineCap='round';g.beginPath();g.moveTo(x1,y1);g.lineTo(x2,y2);g.stroke()}
/* a periodic ridge so a strip tiles seamlessly */
function wrRidge(g,Wd,Hd,base,amp,seed,fill,hs){g.beginPath();g.moveTo(0,Hd);for(let x=0;x<=Wd;x+=8){const u=x/Wd*TAU;let y=base-amp*(Math.sin(u+seed)*.5+Math.sin(u*3+seed*1.7)*.28+Math.sin(u*7+seed*.6)*.14+Math.sin(u*13+seed*2.3)*.08);if(hs)y+=(rnd(x/8+seed*9)-.5)*hs;g.lineTo(x,y)}g.lineTo(Wd,Hd);g.closePath();g.fillStyle=fill;g.fill()}
function wrBlock(g,x,y,w,h,base){g.fillStyle=base;g.fillRect(x,y,w,h);g.fillStyle='#ffffff22';g.fillRect(x,y,w,2);g.fillRect(x,y,2,h);g.fillStyle='#12081f66';g.fillRect(x,y+h-2,w,2);g.fillRect(x+w-2,y,2,h)}
function wrHouse(g,x,y,w,h,col,roof,win){g.fillStyle=col;g.fillRect(x-w/2,y-h,w,h);g.fillStyle=roof;g.beginPath();g.moveTo(x-w/2-4,y-h);g.lineTo(x,y-h-w*.55);g.lineTo(x+w/2+4,y-h);g.closePath();g.fill();if(win){glow(g,x,y-h*.5,w*.5,win+'55');g.fillStyle=win;g.fillRect(x-w*.16,y-h*.65,w*.32,h*.3)}}
/* ---------- baking ---------- */
function wrBake(rt){if(WRB[rt.id])return WRB[rt.id];const B={};const id=rt.id,K=k=>'wr_'+id+'_'+k;
 /* sky: gradient, stars, a moon, three still clouds */
 B.sky=abSprite(K('sky'),W,H,(g,w,h)=>{g.fillStyle=abLin(g,0,h,[[0,rt.sky[0]],[.55,rt.sky[1]],[1,rt.far==='keep'?'#4a1a4a':'#3a2a6a']]);g.fillRect(0,0,w,h);abStars(g,150,rt.d*7+3,540,'#eee8ff',1.5);abStars(g,30,rt.d*7+9,300,'#fff',2.4);
  const mx=1240,my=150,mr=rt.far==='keep'?70:56;abMoon(g,mx,my,mr,'#fffbe8',rt.far==='keep'?'#f0c0a0':'#e8e0c8',rt.far==='keep'?'#ffb08077':'#fff0c055');
  const cl=abCloud(K('cl'),700,120,rt.far==='keep'?'#4a2a5a99':'#3a2c6a99','#3a2c6a00',rt.d*3);for(const [cx,cy,sc,al] of[[120,120,1,.6],[760,70,.8,.45],[1300,250,.9,.5]]){g.globalAlpha=al;g.drawImage(cl,cx,cy,700*sc,120*sc)}g.globalAlpha=1});
 /* far ridge */
 B.ridge=abSprite(K('ridge'),1600,340,(g,w,h)=>{wrRidge(g,w,h,160,90,rt.d*1.3,rt.far==='keep'?'#2a1440':'#241a4e');wrRidge(g,w,h,220,70,rt.d*2.1+4,rt.far==='keep'?'#1e0f32':'#1a1340',6)});
 /* the far set */
 B.far=abSprite(K('far'),2400,470,(g,w,h)=>{
  if(rt.far==='village'){wrRidge(g,w,h,250,60,2.2,'#1a1a44');for(let i=0;i<34;i++){const x=rnd(i+5)*w,hh=22+rnd(i+30)*30;wrHouse(g,x,300-rnd(i+2)*24,18+rnd(i+9)*16,hh,'#1c1a40','#120e30',rnd(i+40)<.75?'#ffd27a':null)}
   g.fillStyle='#1a1640';g.fillRect(1480,150,30,150);g.beginPath();g.moveTo(1476,150);g.lineTo(1495,100);g.lineTo(1514,150);g.fill();g.fillStyle='#ffd27a';g.fillRect(1490,210,10,16);glow(g,1495,218,22,'#ffd27a77');
   g.fillStyle='#1a1640';g.fillRect(560,190,34,120);g.beginPath();g.moveTo(554,190);g.lineTo(577,140);g.lineTo(600,190);g.fill();
   wrRidge(g,w,h,330,40,5.1,'#161236');for(let i=0;i<36;i++)abPine(g,rnd(i+100)*w,350+rnd(i+130)*40,40+rnd(i+160)*50,'#120f2e');wrRidge(g,w,h,410,30,7.3,'#0e0b26',8)}
  else if(rt.far==='forest'){wrRidge(g,w,h,230,70,3.2,'#111a34');for(let i=0;i<70;i++)abPine(g,rnd(i+200)*w,300+rnd(i+230)*50,70+rnd(i+260)*70,'#0d1830');
   g.fillStyle='#0b1226';g.fillRect(1700,160,44,170);g.fillRect(1690,150,64,16);g.fillStyle='#ffb04a';g.fillRect(1716,196,12,14);glow(g,1722,203,26,'#ffb04a66');
   for(let i=0;i<40;i++)abPine(g,rnd(i+300)*w,380+rnd(i+330)*40,100+rnd(i+360)*90,'#070e20');const fg=abFog(K('fog'),'#8aa0d070');g.globalAlpha=.6;g.drawImage(fg,0,250);g.drawImage(fg,1600,250);g.globalAlpha=1}
  else{wrRidge(g,w,h,240,80,1.1,'#1c0f30');abCastle(g,1300,330,.8,'#140a24','#ff9a5a','#ffb08a');for(let i=0;i<30;i++)abDead(g,rnd(i+400)*w,350+rnd(i+430)*50,70+rnd(i+460)*80,'#120826',i);
   for(let i=0;i<16;i++)abTomb(g,rnd(i+500)*w,400+rnd(i+530)*40,.8+rnd(i)*.5,'#0e0620',i);wrRidge(g,w,h,420,30,8.1,'#0a0418',10)}});
 /* the river band and the waterfall: the river is still water with a scrolling sheet of streaks for the fall */
 B.river=abSprite(K('river'),2400,250,(g,w,h)=>{g.fillStyle=abLin(g,0,h,[[0,'#0e0c32'],[1,'#07061a']]);g.fillRect(0,0,w,h);for(let i=0;i<90;i++){const x=rnd(i+600)*w,y=20+rnd(i+630)*(h-40),l=20+rnd(i+660)*60;g.strokeStyle=`rgba(140,160,255,${.08+rnd(i+690)*.14})`;g.lineWidth=1.5;g.beginPath();g.moveTo(x,y);g.lineTo(x+l,y);g.stroke()}
  /* the fall's rock lip and foam pool */
  g.fillStyle='#120e2e';g.fillRect(1690,0,180,20);glow(g,1780,180,120,'#b8c8ff22');for(let i=0;i<26;i++){const x=1700+rnd(i+700)*160,y=150+rnd(i+730)*60;g.fillStyle=`rgba(220,230,255,${.25+rnd(i+760)*.4})`;g.beginPath();g.arc(x,y,3+rnd(i+790)*7,0,TAU);g.fill()}});
 B.fall=abSprite(K('fall'),160,320,(g,w,h)=>{g.fillStyle=abLin(g,0,h,[[0,'#9fb4ff66'],[1,'#dfe8ffaa']]);g.fillRect(10,0,w-20,h);for(let i=0;i<40;i++){const x=12+rnd(i+800)*(w-24),y=rnd(i+830)*h,l=30+rnd(i+860)*80;g.strokeStyle=`rgba(255,255,255,${.25+rnd(i+890)*.5})`;g.lineWidth=1.5+rnd(i+920)*2;g.beginPath();g.moveTo(x,y);g.lineTo(x,y+l);g.moveTo(x,y-h);g.lineTo(x,y-h+l);g.stroke()}});
 /* the far parapet and its lantern posts (behind the characters) */
 B.wall=abSprite(K('wall'),480,150,(g,w,h)=>{const top=h-118;g.fillStyle='#262046';g.fillRect(0,top,w,118);for(let r=0;r<4;r++)for(let i=-1;i<7;i++){const bw=80,x=i*bw+(r%2?40:0);wrBlock(g,x+2,top+8+r*26,bw-4,22,r%2?'#2b2550':'#2e2856')}
  g.fillStyle='#3a3464';g.fillRect(0,top-4,w,12);g.fillStyle='#ffffff26';g.fillRect(0,top-4,w,2);
  /* ivy */for(let i=0;i<14;i++){const x=rnd(i+40)*w,y=top+rnd(i+70)*60;g.fillStyle=i%2?'#1e4a3a':'#24563e';g.beginPath();g.ellipse(x,y,6+rnd(i)*6,4+rnd(i+1)*4,0,0,TAU);g.fill()}
  /* the post */const px=240;g.fillStyle='#1a1430';g.fillRect(px-7,top-100,14,104);g.fillRect(px-14,top-104,28,8);g.fillStyle='#12081f';g.fillRect(px-4,top-112,8,10);
  g.beginPath();g.roundRect(px-12,top-144,24,34,4);g.fillStyle='#d9a441';g.fill();wrStroke(g,2.4);g.beginPath();g.roundRect(px-8,top-138,16,22,2);g.fillStyle='#ffe9a0';g.fill();g.fillStyle='#ffd45a';g.beginPath();g.ellipse(px,top-127,4,7,0,0,TAU);g.fill()});
 B.postGlow=abSprite('wr_postglow',260,260,(g,w,h)=>{glow(g,130,130,128,'#ffc86a44')});
 /* the deck and the bridge face with its arches */
 B.deck=abSprite(K('deck'),480,130,(g,w,h)=>{g.fillStyle='#2f2a52';g.fillRect(0,0,w,34);for(let i=0;i<12;i++){const x=i*40+(i%2?0:0);wrBlock(g,x+2,2,36,14,'#36305c');wrBlock(g,x+22,18,36,14,'#332d58')}
  g.fillStyle='#1c1838';g.fillRect(0,34,w,8);g.fillStyle='#221c42';g.fillRect(0,42,w,h-42);for(let r=0;r<3;r++)for(let i=-1;i<7;i++){const bw=80,x=i*bw+(r%2?40:0);wrBlock(g,x+2,46+r*28,bw-4,24,r%2?'#251f48':'#28224c')}
  /* the arch cut through */g.globalCompositeOperation='destination-out';g.beginPath();g.moveTo(140,h);g.lineTo(140,110);g.arc(240,110,100,Math.PI,0);g.lineTo(340,h);g.closePath();g.fill();g.globalCompositeOperation='source-over';
  g.strokeStyle='#3c3464';g.lineWidth=6;g.beginPath();g.moveTo(140,h);g.lineTo(140,110);g.arc(240,110,100,Math.PI,0);g.lineTo(340,h);g.stroke();g.fillStyle='#ffffff18';g.fillRect(0,42,w,2)});
 /* the near-side bushes */
 B.fore=abSprite(K('fore'),1600,110,(g,w,h)=>{for(let i=0;i<70;i++){const x=rnd(i+900)*w,y=40+rnd(i+930)*50,r=18+rnd(i+960)*26;g.fillStyle=i%3?'#0e2a22':'#123426';g.beginPath();g.ellipse(x,y,r,r*.75,0,0,TAU);g.fill()}for(let i=0;i<40;i++){const x=rnd(i+1000)*w;g.strokeStyle='#1a4a34';g.lineWidth=2;g.beginPath();g.moveTo(x,h);g.quadraticCurveTo(x+6,h-30,x+(rnd(i)-.5)*20,h-46-rnd(i+2)*24);g.stroke()}});
 B.vig=abSprite('wr_vig',W,H,(g,w,h)=>{const q=g.createRadialGradient(w/2,h*.45,h*.35,w/2,h*.45,h*.95);q.addColorStop(0,'rgba(4,2,12,0)');q.addColorStop(1,'rgba(4,2,12,.8)');g.fillStyle=q;g.fillRect(0,0,w,h)});
 return WRB[rt.id]=B}
function wrDrift(c,spr,y,f,x,al,sc){const w=spr.width*(sc||1);let sx=-(((x*f)%w+w)%w);if(al!=null)c.globalAlpha=al;for(;sx<W;sx+=w)c.drawImage(spr,sx,y,w,spr.height*(sc||1));c.globalAlpha=1}
/* ---------- the scene behind the characters ---------- */
function wrSceneDraw(c,R){const B=R.bake;if(!B)return;const x=R.x,t=S.t;
 c.drawImage(B.sky,0,0);
 wrDrift(c,B.ridge,330,.06,x);
 wrDrift(c,B.far,250,.18,x);
 /* river and the falls */
 wrDrift(c,B.river,GY-110,.35,x);
 {const w=B.river.width;let sx=-(((x*.35)%w+w)%w);for(;sx<W;sx+=w){const fx=sx+1700;if(fx>-200&&fx<W){c.save();c.beginPath();c.rect(fx,GY-110,160,170);c.clip();const off=(t*260)%320;c.drawImage(B.fall,fx,GY-110-off);c.drawImage(B.fall,fx,GY-110-off+320);c.restore();
   c.save();c.globalAlpha=.5+.2*Math.sin(t*3);glow(c,fx+80,GY+50,70,'#dfe8ff33');c.restore()}}}
 /* the far parapet, with its posts' glow */
 wrDrift(c,B.wall,GY-150,1,x);
 {const w=480;let sx=-(((x)%w+w)%w);c.save();c.globalCompositeOperation='lighter';for(;sx<W;sx+=w){const px=sx+240;c.globalAlpha=.85+.15*Math.sin(t*9+px);c.drawImage(B.postGlow,px-130,GY-268-130)}c.restore();c.globalAlpha=1}
 /* fireflies and embers */
 if(!R.embers.length)for(let i=0;i<22;i++)R.embers.push({x:Math.random()*W,y:200+Math.random()*560,s:1+Math.random()*1.8,p:Math.random()*6,v:8+Math.random()*14});
 c.save();for(const e of R.embers){e.x-=(R.v*.5+e.v)*(1/60);e.y+=Math.sin(t*1.3+e.p)*.25;if(e.x<-10){e.x=W+10;e.y=200+Math.random()*560}const a=.35+.35*Math.sin(t*2.2+e.p);c.globalAlpha=a;c.fillStyle=e.p>3?'#ffe9a0':'#9dfccc';c.beginPath();c.arc(e.x,e.y,e.s,0,TAU);c.fill()}c.restore();
 /* the deck under the feet */
 wrDrift(c,B.deck,GY,1,x)}
function wrForeDraw(c,R){const B=R.bake;if(!B)return;wrDrift(c,B.fore,H-100,1.35,R.x,.92);c.globalAlpha=.9;c.drawImage(B.vig,0,0);c.globalAlpha=1}
/* ---------- the gate at the end of the road ---------- */
function wrGateDraw(c,R){const gx=R.gx-R.x,left=R.rt.len-R.x;if(left>620)return;const t=S.t,open=wrClamp((1280-gx)/320,0,1),k=wrOver(open),al=wrClamp((620-left)/140,0,1);
 c.save();c.globalAlpha=al;c.translate(gx,GY);
 /* light spill when open */
 if(open>0){c.save();c.globalAlpha=open*.8;const q=c.createRadialGradient(0,-150,20,0,-150,520);q.addColorStop(0,'rgba(255,214,120,.55)');q.addColorStop(1,'rgba(255,180,60,0)');c.fillStyle=q;c.fillRect(-520,-680,1040,700);c.restore()}
 /* wall and towers */
 const st=(x,y,w,h,col)=>{c.fillStyle=col;c.fillRect(x,y,w,h);for(let r=0;r<Math.floor(h/26);r++)for(let i=0;i<Math.ceil(w/80)+1;i++){const bx=x+i*80-(r%2?40:0);if(bx+76>x&&bx<x+w){const l=Math.max(bx,x),rr=Math.min(bx+76,x+w);wrBlock(c,l+2,y+4+r*26,rr-l-4,22,col)}}};
 st(-230,-320,460,330,'#2a2450');st(-300,-470,130,480,'#2e2856');st(170,-470,130,480,'#2e2856');
 for(const tx of[-300,170])for(let i=0;i<4;i++){c.fillStyle='#2e2856';c.fillRect(tx+i*34,-492,22,24)}for(let i=0;i<6;i++){c.fillStyle='#2a2450';c.fillRect(-220+i*78,-342,40,24)}
 /* the archway: dark inside, warm when open */
 c.save();c.beginPath();c.moveTo(-120,0);c.lineTo(-120,-200);c.arc(0,-200,120,Math.PI,0);c.lineTo(120,0);c.closePath();c.clip();c.fillStyle=open>0?abLin(c,-330,0,[[0,'#ffd98a'],[1,'#ffb860']]):'#0a0618';c.fillRect(-130,-330,260,340);
 if(open>0){c.globalAlpha=open;for(let i=0;i<5;i++){c.fillStyle=`rgba(255,255,255,${.08+.06*Math.sin(t*3+i)})`;c.beginPath();c.moveTo(-10,-320);c.lineTo(-100+i*45,20);c.lineTo(-70+i*45,20);c.closePath();c.fill()}c.globalAlpha=1}
 /* the doors swing in: each one squashes toward its hinge */
 for(const d of[-1,1]){c.save();c.translate(d*120,0);c.scale(Math.max(.06,1-k*.94),1);c.translate(-d*120,0);c.fillStyle='#4a2c18';c.beginPath();c.rect(d<0?-120:0,-320,120,320);c.fill();wrStroke(c,4);c.strokeStyle='#8a5a2c';c.lineWidth=2;for(let i=1;i<4;i++){c.beginPath();c.moveTo(d<0?-120+i*30:i*30,-320);c.lineTo(d<0?-120+i*30:i*30,0);c.stroke()}c.fillStyle='#d9a441';for(const yy of[-250,-150,-50]){c.beginPath();c.arc(d<0?-100:100,yy,6,0,TAU);c.fill()}c.restore()}
 c.restore();
 c.beginPath();c.moveTo(-132,0);c.lineTo(-132,-200);c.arc(0,-200,132,Math.PI,0);c.lineTo(132,0);c.strokeStyle='#3c3464';c.lineWidth=14;c.stroke();wrStroke(c,3);
 /* torches, banners, the lantern over the arch */
 for(const tx of[-200,200]){c.fillStyle='#1a1430';c.fillRect(tx-5,-300,10,50);const f=.8+.2*Math.sin(t*12+tx);glow(c,tx,-312,36*f,'#ffb04a77');c.fillStyle='#ffc23a';c.beginPath();c.ellipse(tx,-312,7*f,13*f,0,0,TAU);c.fill();c.fillStyle='#fff6c8';c.beginPath();c.ellipse(tx,-308,3,6,0,0,TAU);c.fill()}
 for(const bx of[-235,235]){c.fillStyle='#3a2a7a';c.beginPath();c.moveTo(bx-24,-440);c.lineTo(bx+24,-440);c.lineTo(bx+24,-330);c.lineTo(bx,-310);c.lineTo(bx-24,-330);c.closePath();c.fill();wrStroke(c,2.5);c.fillStyle='#ffd45a';c.beginPath();c.arc(bx,-385,9,0,TAU);c.fill()}
 c.restore()}
/* ---------- the lantern (the bobber cosmetic) ---------- */
function wrLantern(g,x,y,s,look,t,sw,boost){const L=look||WR_COS.lan.brass,f=.9+Math.sin(t*13.1)*.06+Math.sin(t*7.7+1)*.05,bo=boost||0;
 g.save();g.translate(x,y);g.rotate(sw||0);g.scale(s,s);
 /* the glow, additive */
 g.save();g.globalCompositeOperation='lighter';const r=(150+bo*120)*f;const q=g.createRadialGradient(0,62,4,0,62,r);q.addColorStop(0,`rgba(${L.glow},${.6+bo*.3})`);q.addColorStop(.35,`rgba(${L.glow},${.24+bo*.14})`);q.addColorStop(1,`rgba(${L.glow},0)`);g.fillStyle=q;g.fillRect(-r,62-r,r*2,r*2);g.restore();
 /* hook and ring */
 g.beginPath();g.arc(0,-4,9,Math.PI,0);g.lineWidth=7;g.strokeStyle=WRO;g.stroke();g.lineWidth=3.4;g.strokeStyle=L.cage;g.stroke();
 /* cap */
 g.beginPath();g.moveTo(-26,16);g.quadraticCurveTo(0,-8,26,16);g.lineTo(30,24);g.lineTo(-30,24);g.closePath();wrFill(g,L.cage,3);g.beginPath();g.moveTo(-32,24);g.lineTo(32,24);g.lineTo(28,32);g.lineTo(-28,32);g.closePath();wrFill(g,L.dark,2.6);
 /* glass body */
 g.beginPath();g.roundRect(-30,32,60,70,10);const gg=g.createLinearGradient(0,32,0,102);gg.addColorStop(0,L.glass);gg.addColorStop(1,L.flame);g.fillStyle=gg;g.fill();
 /* flame */
 g.save();g.translate(0,92);g.scale(f,f*1.1);g.beginPath();g.moveTo(0,-38);g.quadraticCurveTo(15,-12,11,0);g.quadraticCurveTo(0,8,-11,0);g.quadraticCurveTo(-15,-12,0,-38);g.closePath();const fg=g.createLinearGradient(0,-38,0,6);fg.addColorStop(0,'#fff8d8');fg.addColorStop(.5,L.flame);fg.addColorStop(1,L.glow.startsWith('255,120')?'#ff4a2a':'#ff9a3a');g.fillStyle=fg;g.fill();g.fillStyle='#fffdf0';g.beginPath();g.ellipse(0,-8,4,9,0,0,TAU);g.fill();g.restore();
 /* cage bars and the glass outline */
 g.beginPath();g.roundRect(-30,32,60,70,10);wrStroke(g,3.2);g.strokeStyle=L.cage;g.lineWidth=3;for(const bx of[-12,12]){g.beginPath();g.moveTo(bx,32);g.lineTo(bx,102);g.stroke()}g.beginPath();g.moveTo(-30,67);g.lineTo(30,67);g.stroke();
 wrHi(g,-24,40,-24,92,2.2,.45);
 /* base */
 g.beginPath();g.moveTo(-34,102);g.lineTo(34,102);g.lineTo(28,116);g.lineTo(-28,116);g.closePath();wrFill(g,L.cage,3);g.beginPath();g.ellipse(0,118,10,4,0,0,TAU);wrFill(g,L.dark,2);
 g.restore()}
/* ---------- the pennant (the banner cosmetic) ---------- */
function wrBanner(g,x,y,look,t,v){const B=look;g.save();g.translate(x,y);
 g.beginPath();g.moveTo(0,0);g.lineTo(0,-150);g.lineWidth=8;g.strokeStyle=WRO;g.stroke();g.lineWidth=4;g.strokeStyle='#8a5a2c';g.stroke();g.beginPath();g.arc(0,-154,6,0,TAU);wrFill(g,'#d9a441',2.4);
 if(!B||!B.c0){g.restore();return}
 const amp=3+Math.min(10,v*.12),L=78,n=6;g.beginPath();g.moveTo(2,-150);for(let i=0;i<=n;i++){const u=i/n,wx=2+u*L,wy=-150+Math.sin(t*9-u*5)*amp*u+u*8;g.lineTo(wx,wy)}
 g.lineTo(2+L*.72,-104+Math.sin(t*9-3.6)*amp*.72);for(let i=n;i>=0;i--){const u=i/n,wx=2+u*L,wy=-150+Math.sin(t*9-u*5)*amp*u+u*8+44*(1-u*.35);g.lineTo(wx,wy)}g.closePath();
 const q=g.createLinearGradient(0,-150,0,-100);q.addColorStop(0,B.c1);q.addColorStop(1,B.c0);wrFill(g,q,2.6);
 /* the emblem */
 const ex=2+L*.4,ey=-128+Math.sin(t*9-2)*amp*.4;g.fillStyle=B.ec;g.strokeStyle=WRO;g.lineWidth=1.4;
 if(B.emb==='lantern'){g.beginPath();g.roundRect(ex-6,ey-9,12,18,3);g.fill();g.stroke();g.beginPath();g.arc(ex,ey-11,4,Math.PI,0);g.stroke()}
 else if(B.emb==='wolf'){g.beginPath();g.moveTo(ex-10,ey-8);g.lineTo(ex-5,ey+2);g.lineTo(ex,ey+9);g.lineTo(ex+9,ey+2);g.lineTo(ex+10,ey-8);g.lineTo(ex+4,ey-3);g.lineTo(ex-4,ey-3);g.closePath();g.fill();g.stroke()}
 else if(B.emb==='skull'){g.beginPath();g.arc(ex,ey-2,8,0,TAU);g.fill();g.stroke();g.fillStyle=WRO;g.beginPath();g.arc(ex-3,ey-3,2,0,TAU);g.arc(ex+3,ey-3,2,0,TAU);g.fill();g.fillRect(ex-4,ey+4,8,4)}
 else{g.beginPath();g.moveTo(ex-10,ey+6);g.lineTo(ex-10,ey-4);g.lineTo(ex-5,ey);g.lineTo(ex,ey-9);g.lineTo(ex+5,ey);g.lineTo(ex+10,ey-4);g.lineTo(ex+10,ey+6);g.closePath();g.fill();g.stroke()}
 g.restore()}
/* ---------- a wheel ---------- */
function wrWheel(g,x,y,r,rot,rim,far){g.save();g.translate(x,y);g.rotate(rot);const hub='#3a2a1c';
 g.beginPath();g.arc(0,0,r,0,TAU);g.fillStyle=far?'#1c1428':'#5a3a22';g.fill();wrStroke(g,far?2.4:3.4);
 g.beginPath();g.arc(0,0,r-9,0,TAU);g.fillStyle=far?'#15101e':'#2a1c12';g.fill();
 g.strokeStyle=far?'#2a2038':'#8a5a2c';g.lineWidth=far?4:5.5;g.lineCap='round';for(let i=0;i<8;i++){const a=i*Math.PI/4;g.beginPath();g.moveTo(0,0);g.lineTo(Math.cos(a)*(r-9),Math.sin(a)*(r-9));g.stroke()}
 g.beginPath();g.arc(0,0,r,0,TAU);g.strokeStyle=far?'#2a2038':rim;g.lineWidth=far?3:5;g.stroke();
 g.beginPath();g.arc(0,0,r*.26,0,TAU);wrFill(g,far?'#2a2038':hub,far?2:2.6);if(!far){g.fillStyle='#d9a441';g.beginPath();g.arc(0,0,r*.09,0,TAU);g.fill();wrHi(g,-r*.6,-r*.62,-r*.3,-r*.82,2.6,.35)}
 g.restore()}
/* ---------- the wagon ---------- */
function wrWagonDraw(c,R){const t=S.t,look=R.look,PA=WR_COS.paint[look.paint]||WR_COS.paint.oak,LA=WR_COS.lan[look.lan]||WR_COS.lan.brass,BA=WR_COS.ban[look.ban],rolling=R.v>5,jam=!!R.haz,brk=R.st==='break';
 const bob=rolling?Math.sin(R.wheel*2.1)*2.2:0,cb=rolling?Math.sin(R.wheel*2.1-.5)*3:0;
 c.save();c.translate(WRT.WX+(R.ox||0),GY);
 /* shadow */
 c.fillStyle='rgba(0,0,0,.35)';c.beginPath();c.ellipse(100,6,230+R.v*.4,12,0,0,TAU);c.fill();
 /* hazard props under the front wheel */
 if(jam)wrHazProp(c,R.haz,t);
 /* tilt about the front axle when jammed or broken */
 const tilt=brk?.1:jam?-.045*wrEase(Math.min(1,(R.haz.fuse-R.haz.t)*4)):0;c.translate(150,-44);c.rotate(tilt);c.translate(-150,44);if(brk)c.translate(0,8);
 /* far-side wheels */
 wrWheel(c,-6,-60,52,R.wheel,PA.rim,true);wrWheel(c,146,-52,44,R.wheel*52/44,PA.rim,true);
 c.save();c.translate(0,bob);
 /* undercarriage */
 c.fillStyle='#2a1c12';c.fillRect(-170,-78,350,16);wrStroke(c,0);c.beginPath();c.rect(-170,-78,350,16);wrStroke(c,2.4);
 /* the banner post, behind the body */
 wrBanner(c,-186,-150,BA,t,R.v);
 /* body */
 c.beginPath();c.moveTo(-200,-150);c.lineTo(190,-150);c.lineTo(200,-66);c.lineTo(-210,-66);c.closePath();const bg=c.createLinearGradient(0,-150,0,-66);bg.addColorStop(0,PA.body);bg.addColorStop(1,PA.dark);wrFill(c,bg,3.4);
 c.strokeStyle='#12081f55';c.lineWidth=2;for(const yy of[-128,-106,-86]){c.beginPath();c.moveTo(-204,yy);c.lineTo(194,yy);c.stroke()}
 c.strokeStyle=PA.rim;c.lineWidth=4;for(const xx of[-150,-60,40,130]){c.beginPath();c.moveTo(xx,-150);c.lineTo(xx+3,-66);c.stroke()}
 wrHi(c,-192,-144,180,-144,2.4,.35);
 /* cargo */
 c.save();c.translate(0,cb);
 c.beginPath();c.moveTo(-160,-150);c.quadraticCurveTo(-150,-205,-100,-200);c.quadraticCurveTo(-60,-212,-30,-192);c.lineTo(-20,-150);c.closePath();wrFill(c,'#b8a080',3);c.strokeStyle='#12081f44';c.lineWidth=2;c.beginPath();c.moveTo(-120,-198);c.lineTo(-110,-156);c.stroke();
 c.beginPath();c.rect(-20,-200,56,52);wrFill(c,'#8a5a2c',3);c.strokeStyle='#5a3614';c.lineWidth=2;c.beginPath();c.moveTo(-20,-174);c.lineTo(36,-174);c.moveTo(8,-200);c.lineTo(8,-148);c.stroke();wrHi(c,-14,-194,28,-194,2,.35);
 c.beginPath();c.ellipse(60,-162,24,16,0,0,TAU);wrFill(c,'#9a7a4a',2.6);c.beginPath();c.ellipse(60,-176,10,6,0,0,TAU);wrFill(c,'#6a4a2a',2);
 c.restore();
 /* the lantern frame and the lantern itself */
 c.beginPath();c.moveTo(80,-150);c.lineTo(80,-312);c.lineTo(132,-312);c.lineTo(132,-300);c.lineTo(92,-300);c.lineTo(92,-150);c.closePath();wrFill(c,LA.cage,3);wrHi(c,84,-306,84,-160,1.8,.35);
 wrLantern(c,126,-300,.95,LA,t,R.swing*.6,R.flareOn>0?1:0);
 /* the driver's bench and the driver */
 c.beginPath();c.rect(140,-156,70,10);wrFill(c,PA.dark,2.6);
 {const d=R.drv,a=t-d.t0;let mode=d.mode,k=1;if(a<.3)k=a/.3;else if(a>d.dur){k=Math.max(0,1-(a-d.dur)/.3);if(k<=0)mode='idle'}
  c.save();c.beginPath();c.rect(120,-330,120,186);c.clip();c.translate(176,-96+(rolling?Math.sin(R.wheel*2.1+1)*2:0));c.scale(.62,.62);try{rrkDraw(c,RRK[0],t,{mode,k})}catch(e){}c.restore()}
 /* the front board hides his legs; the reins run forward */
 c.beginPath();c.moveTo(130,-150);c.lineTo(214,-150);c.lineTo(222,-100);c.lineTo(130,-100);c.closePath();wrFill(c,PA.body,3);c.strokeStyle='#12081f55';c.lineWidth=2;c.beginPath();c.moveTo(130,-126);c.lineTo(218,-126);c.stroke();
 c.strokeStyle='#5a3a22';c.lineWidth=3;c.beginPath();c.moveTo(210,-140);c.quadraticCurveTo(250,-120,268,-96);c.stroke();
 c.restore();
 /* near-side wheels */
 wrWheel(c,0,-52,52,R.wheel,PA.rim,false);wrWheel(c,150,-44,44,R.wheel*52/44,PA.rim,false);
 /* sparks while jammed */
 if(jam&&R.st==='roll'&&Math.random()<.35)ptBurst(R.fx,150+(Math.random()-.5)*20,-10,1,['#ffd45a','#ff9a5a'],{v:200,s:3,up:1,sp:1.8,g:360,l:.5});
 if(brk){c.fillStyle='#8a8a9a';for(let i=0;i<4;i++){const u=(t*.4+i*.25)%1;c.globalAlpha=(1-u)*.5;c.beginPath();c.arc(150+Math.sin(u*6+i)*10,-40-u*90,8+u*14,0,TAU);c.fill()}c.globalAlpha=1}
 c.restore()}
function wrHazProp(c,h,t){const x=212;c.save();
 if(h.k==='rock'){c.beginPath();c.moveTo(x-30,0);c.lineTo(x-22,-22);c.lineTo(x-4,-30);c.lineTo(x+18,-20);c.lineTo(x+26,0);c.closePath();wrFill(c,'#6a6478',3);wrHi(c,x-18,-18,x-6,-24,2,.3)}
 else if(h.k==='branch'){c.strokeStyle=WRO;c.lineWidth=12;c.lineCap='round';c.beginPath();c.moveTo(x-70,-6);c.quadraticCurveTo(x-10,-26,x+60,-4);c.stroke();c.strokeStyle='#5a3a22';c.lineWidth=7;c.stroke();c.strokeStyle='#5a3a22';c.lineWidth=4;c.beginPath();c.moveTo(x-20,-20);c.lineTo(x-34,-44);c.moveTo(x+20,-14);c.lineTo(x+30,-40);c.stroke();c.fillStyle='#1e4a3a';for(const [bx,by] of[[x-38,-48],[x+32,-44],[x-4,-26]]){c.beginPath();c.ellipse(bx,by,10,6,.4,0,TAU);c.fill()}}
 else if(h.k==='mud'){c.beginPath();c.ellipse(x+4,2,78,14,0,0,TAU);wrFill(c,'#3a2a1c',2.4);c.fillStyle='#4a3a28';for(let i=0;i<5;i++){c.beginPath();c.ellipse(x-40+i*20,-2+Math.sin(t*3+i)*2,8,4,0,0,TAU);c.fill()}}
 else{c.save();c.translate(-10,-200);c.rotate(.35+Math.sin(t*6)*.05);c.beginPath();c.rect(-20,-24,40,48);wrFill(c,'#8a5a2c',3);c.strokeStyle='#5a3614';c.lineWidth=2;c.beginPath();c.moveTo(-20,0);c.lineTo(20,0);c.stroke();c.restore()}
 c.restore()}
