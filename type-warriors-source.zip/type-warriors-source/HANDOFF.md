# Type Warriors — Handoff Brief

Read this whole file before changing anything. It records how the game is built, the art and UI style the owner has approved, and the standing rules. Screenshots of the approved look are in `refs/`.

---

## 1. What the game is

Type Warriors is a browser typing game: a chunky cartoon knight (or archer, mage or rogue) fights monsters by typing words. It ships as **one self-contained HTML file** (`type-warriors.html`), with no external assets apart from Google Fonts. The owner plans to publish it on their Wix site.

Major systems:
- Campaign (regions such as Goblin Woods and Sunken Ruins, with stages, stars and region bosses), Endless, Daily Challenge (a new realm and modifier each day), Warden's Arena, Graveyard event, Halloween events.
- Armory: classes, weapons and armor with mastery, Skill Tree, Auto-Equip.
- Casino and minigames, Shop, chests (Celestial / Astral chest, Graveyard crate), Bounty board, Bestiary, Hall, Save Center, Updates/News (the bell), Calendar.
- Companion Hall (pets): roster, eggs (Runeshell = Rare, Crownheart = Legendary), hatching, Adventure Trail stamps, bond levels and cosmetics.
- Main menu: the "Console Dock" hub. A bright diorama of the current region on the right, a campaign panel on the left, a six-tab dock at the bottom (Play, Gear, Pets, Progress, Shop, More), and the bell and calendar in the bottom-right corner.

---

## 2. How the code is organised (important)

- Source is about 135 numbered modules (`00_head.html`, `10_data.js`, … `88c_dockicons.js`, `70_main.js`). `build.sh` concatenates them **in a fixed order** into `out.html`, then syntax-checks the extracted script with `node --check` (it prints `SYNTAX_OK`).
- The deliverable is `out.html`, copied to **`type-warriors.html`**. A second copy, **`type-warriors-act6-TEST.html`**, has always been delivered alongside it. It is byte-identical, built by `build_ast3.sh` into `out_ast.html`. Always build both, confirm `cmp out.html out_ast.html` passes, and deliver both.
- **Everything is one script, so later code overrides earlier code:**
  - A later `function foo(){}` replaces an earlier one everywhere.
  - Wrap an existing function with `{const f0=foo;foo=function(){const r=f0.apply(this,arguments);/*extra*/;return r}}`.
  - Some globals are `const` (for example `dcKey`, `hwOn`, `DKI`, `PTICO`) and cannot be reassigned. Mutate them (`Object.assign(DKI,{...})`) or wrap their callers.
- **Preferred way to make changes:** add a new module after the module you are changing (for example `87h_pet_fx.js` after `87g_pet_polish.js`), add it to the file lists in **both** `build.sh` and `build_ast3.sh`, and do the overrides there. When you edit an existing module, save a backup first (`file.js.v7bak`).
- **UI framework:**
  - `show(html, cls)` renders a menu into `#ov` and clears `LIVE`.
  - Animate canvases with `LIVE.push({cv, fn: t => draw(t), slow: N})`, where `slow` means "render every Nth frame".
  - `S.back` is the Back/Esc handler. `$('id')` is `getElementById`. `title()` opens the main menu.
- **CSS** is added by each module through `document.createElement('style')`. Later styles win.
- **Save data** is the global `P` (for example `P.gold`, `P.pets`, `P.eggs`, `P.petSort`). Call `save()` after changing it.
- **Pets:**
  - Data and logic: `87a_pet_data.js` (`PDEF`, `PIDS`, `petOwned`, `petHatch`, `petBuy`, `petEquip`, `petNextEgg`, `PEGG_PRICE = {r:2000, l:10000}`).
  - Art: `87b_pet_art.js` (`petDraw`, `petFit`, `eggDraw`, `eggFit`, `PSIG` signature colours).
  - Menus: `87c`, `87e`, `87g`, `87h`. Hatch cinematic: `87f` (`ptHatchScene`). State object: `PTX`.
- **Dock and hub:**
  - `88_dock.js` holds the dock, sheets and Daily card.
  - `88b_hub.js` holds the diorama `homeScene`/`drawBG`, the `DKI` icon set, glare and tilt (`.dkg`, `.dktilt`), the hero hotspot and the Daily medallion `dkDailyLive`.
  - `88c_dockicons.js` holds the current dock icons and their animations.

---

## 3. Art and UI style (the owner's approved look; match it)

Look at `refs/` first. In short: **a polished, warm, storybook-cartoon fantasy, lit at night.**

- **Illustration:** hand-built vector art drawn in canvas or inline SVG, never bitmaps.
  - Chunky shapes with **dark outlines** (`#12081f`, about 2.4–3px at a 100-unit scale).
  - Soft gradient fills, a darker "shade" half on the right, and a **white highlight stroke** on the upper left.
  - Small sparkles (4-point stars) and soft additive glows (`pGlow` / `globalCompositeOperation='lighter'`).
  - Characters are cute and round, with big friendly eyes.
- **SVG icon helpers** (in `31b_boonicons.js`; reuse them):
  - `bP(path, fill)`: outlined shape. `bF(path, fill, opacity)`: shade. `bH(path, colour, width)`: highlight.
  - `bC(x, y, r, fill)`: circle. `bEl(...)`: ellipse. `bL(...)`: outlined line. `bS(x, y, r, fill)`: sparkle.
  - Icons use a 100×100 viewBox, with the art roughly between 14 and 86.
- **Palette:**
  - Panels are deep indigo and purple: `#1c1446` to `#0c0822`, borders `#3a3070` / `#5a4ca0`, glassy, with a 1px inner top highlight.
  - Gold accent: `--gold: #ffc94a` / `#ffd45a`. Body text is warm white (`#fff8e8`, `#f4ecd8`). Muted text is lavender (`#c4badf`).
  - Rarity colours: Rare is blue `#5ab8ff`, Legendary is gold `#ffc23a`, and purple `#b47aff` marks magic.
  - Errors and badges use red `#e8364e`.
- **Type:**
  - **Pirata One** for big decorative titles ("Companion Hall", "Armory", pet names), in gold.
  - **Poppins** (`var(--ui)`) for all UI text, bold 700/800 on buttons. Cinzel is used occasionally.
- **Buttons:**
  - Primary is a gold gradient with dark-brown text and a 4px "pressed" bottom shadow.
  - Secondary is indigo with a lavender border. Soft and ghost buttons are text with a chevron.
  - Pills, tags and badges are rounded.
- **Motion:**
  - Springy and lively but tasteful: `cubic-bezier(.3,1.5,.5,1)` overshoot, short (0.2–0.7s) one-shot animations, staggered entrances.
  - Hover lifts things by 2–4px; presses squish them to about 0.9.
  - Idle life comes from bobbing, breathing, blinking and drifting motes.
  - Every animation must finish cleanly. Don't let a hover animation snap back halfway; play it once with a class and remove the class afterwards.
  - Respect `prefers-reduced-motion`.
- **Layout:** 1600×900 design space, scaled to fit. The dock is centred at the bottom. Panels have 18–22px radii. Don't clutter: give one clear next action per screen.

---

## 4. Performance rules (learned the hard way)

Rendering is fill-bound on weaker machines. **Avoid:**
- `backdrop-filter`
- `mix-blend-mode` soft-light or screen
- animated `box-shadow` or `filter`
- infinite `background-position` animations
- large full-screen additive glows every frame

**Prefer:**
- `transform` and `opacity` animations
- cached offscreen canvases for static layers
- `slow` on `LIVE` canvases
- one-shot timed shines instead of constant ones

Measure the frame rate before and after visual changes; headless Chromium gives roughly 18–27 fps as a baseline.

---

## 5. Testing

Python Playwright scripts (`t_*.py`) load `out.html` headless, drive the game with `page.evaluate`, print results and write screenshots to `shots/`. An empty `[]` at the end means no page errors. `ERR_TUNNEL_CONNECTION_FAILED` is only the offline font load and is harmless.

Useful patterns:
- Set up state with `await pg.evaluate("()=>{RS_ASK=false;P.gold=5000;P.petSt=2;petNorm();petHall('Pets')}")`.
- Change the date with `pg.clock.install(...)`, because `dcKey` is const.
- Freeze CSS animations mid-way: `el.getAnimations({subtree:true}).forEach(a=>{a.pause();a.currentTime=200})`.

Regression set to run after changes: `t_loadout_polish t_loadouts t_flow t_pe t_pdet t_entry t_misc t_trail t_modes t_start6 t_stuck2 t_dkacc t_audit t_sort t_fx t_dock t_dkanim`. Some depend on game state and may need small updates when a layout changes. Keep element IDs stable where you can.

Always **look at screenshots** of what you changed (at 1600×900, and also at 1280×720 or smaller) before delivering.

---

## 6. Standing rules from the owner

1. **Updates tab (bell):** only add or push an in-game update notification when the owner explicitly asks. Even then, **ask for their okay first**.
2. **Do not alter the Celestial chest or Graveyard chest opening animations** unless asked.
3. Deliver **both** `type-warriors.html` and `type-warriors-act6-TEST.html` (identical), plus a few screenshots, with a short, honest summary of what changed and anything not done.
4. The owner gives you creative authority to polish and improve. Keep the existing art style, keep every menu reachable quickly, and keep things functional and intuitive.

---

## 7. Recent work (latest first)

- **Mythic backdrop (`88g_mythic_bg.js`) and a tile fix:**
  - Every owned Mythic pet shown in a frame gets an animated cosmic backdrop on a canvas behind the art. Frames covered: Companion Hall roster cards and portrait, Loadout Locker cards, slots, picker and compare, the Armory pet slot, and egg pool lists.
  - The backdrop: a turning spiral nebula with stars, twinkles, a breathing glow, an upright halo, a gold magic circle under the feet, rising motes and a shooting star.
  - Palettes are per pet (`MYPAL`: yeti frost, sol sunfire, `_` default for any future Mythic). Sprites are cached in `MYIMG`.
  - A MutationObserver finds hosts (`MYHOST`) and adds the canvas to `LIVE` with `slow:3` (`slow:4` for small frames). Reduced motion shows a still frame.
  - Fix in `88f`: `.lotile` clips again, and canvases are absolutely positioned to the tile. Snap sparkles now live on the slot row, not inside the tile.
- **Loadout Locker polish (`88f_loadout_polish.js`, after `88e`):**
  - The right panel is now a slot editor. Click a slot, drop gear onto it, or press Enter on it to open the gear picker in the left panel. The picker has class or rarity filter chips, a "Sort:" dropdown in the Pets-tab style (saved in `P.lo.so`), and a "Best" badge.
  - Hovering or focusing an item previews it on the hero. A compare box shows overall strength (the Auto-Equip test run) and per-stat changes with green ▲ / red ▼.
  - Put an item in with the button, a double-click, Enter, or drag and drop. Clear a slot with × or Delete. Auto-fill best uses `autoPick` for the preset's class.
  - Slot snap animation with sparkles and a beep. Enter on the selected preset equips it. Esc closes the innermost layer (sort menu, then picker, then the page).
  - The Armory bar has a "Loadouts" button (`#arlo`).
  - Gotchas found:
    - The game's global `.em` class (Endless menu) leaked padding into empty slots, so they now use `lomt`.
    - HTML5 drag needs a `div` (Chromium won't drag a `<button>`) and `-webkit-user-drag:element` once `all:unset` is applied.
  - Test: `t_loadout_polish.py`.
- **Loadout Locker (`88e_loadouts.js`, Gear → Loadouts):**
  - Three named presets (default names Campaign, Endless, Gold Hunt) in `P.lo = {s:[{n,w,a,p,c}×3], sel, ask}`. Each stores weapon, armor, companion and the weapon's class.
  - The Gear sub-tab strip is now Armory · Loadouts · Skill Tree (`DKSUB.gr`, `DKG.lo`, and `DKGO.gr` remembers it). The page is detected by `class="lol"`.
  - Equip applies only owned, usable pieces: it checks `P.own`/`P.ownA`, `pathOpen` for the class and `petOwned`. Anything else is skipped, marked on the tile, and reported in a toast. Skill Tree ranks are never touched.
  - Save current loadout: overwriting a filled preset needs a second click. Rename is inline (pencil, Enter/Esc, 16 characters max). "Ask before replacing gear" (`P.lo.ask`) shows a confirm dialog listing each change.
  - Illustrated locker-room stage (cached background, torches, motes). It previews the hovered or selected preset; a swap sparkles and an equip plays a gold celebration. Keys 1–3 pick a preset.
  - Test: `t_loadouts.py`.
- **Source synced with the shipped HTML:** the changes that existed only in the delivered `type-warriors.html` now live in the source, and the build is byte-identical to it.
  - New `87i_pet_mythic.js` (after `87h`): Mythic companions Glacierhorn and Solmane, the Starforge egg (50,000 gold, `P.eggs.m`), the Starforge hatch cinematic, Mythic battle effects and the companion power hotkey.
  - New `88d_spnote.js` (after `88c`): `spNote()`, so the Skill Tree badge only appears when a point can actually be spent.
  - Small in-place edits (backups `*.v7bak`): `74_shell.js` and `88_dock.js` use `spNote()`; `86b_codes.js` adds the `BRAYDENSGIFT` code; `87a_pet_data.js` counts Mythic eggs; `87d_pet_game.js` draws the companion in front of the knight (`petDrawGame`).
- Tests need Python Playwright pinned to the installed browser (here `pip install playwright==1.56.0`).
- **Dock icons v2 (`88c_dockicons.js`):**
  - All six icons redrawn: crossed swords, knight's helm with plume, paw with a heart pad, rounded bar chart, coin pouch, three dots.
  - Each icon has a hover, focus and press animation that plays to the end.
  - Badges moved off the icon art, and the label no longer shifts on hover.
- **Pet and egg effects (`87h_pet_fx.js`):**
  - Descriptions for both eggs (`PEGGD`), on the stage and in an "About" card. Redrawn `PTICO` icons.
  - Pet stage: pop-in on select, signature-colour motes, petting with hearts and combos (every fifth pet plays the power animation), a "Tap to pet" hint, and a gold celebration on equip.
  - Roster: cards wake and greet on hover, and owned legendary cards get a gold shine.
  - Eggs: ready eggs rock, sparkle and pulse; tapping the egg gives a reaction; the hatch button gets a shine.
  - The hatch reveal shows collection progress and the next free egg.
- **Pets sort and Eggs declutter (`87g_pet_polish.js`):**
  - "Sort:" dropdown with Collection, Recommended, Rarity, Bond high/low, Name A–Z and Recently acquired, saved in `P.petSort`.
  - Rarity-bordered cards.
  - Eggs tab is now three columns: Your Eggs, the egg stage, and Hatchery (with Buy and "Earn one free").
- **Earlier:** Console Dock main-menu overhaul; bright region diorama; Manage pet / Manage gear buttons; Daily Challenge medallion that changes every day; smooth menu transitions; pet starter-screen fixes.
