# python3 t_ui92.py : Runestone Tower Defense 9.2 - pads clear of map features, the Tidecaller Shrine, the tower bar and build ring,
# smoother turret turning, the gentler endless Wonderland, and the menu transitions.
import asyncio,os,sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:500]),flush=True)
    if not ok:FAIL.append(name)
AUDIT=r"""(id)=>{const map=RP_MAP(id),G=rpGeo(map),B=rpBake(map),lake=map.lake,vents=map.vents||[],C=B.cast,bad=[];
 const caves=G.ent.map(e=>({x:Math.max(30,e.x-14),y:e.y}));
 for(const p of G.pads){const pts=[];for(let k=0;k<16;k++){const a=k/16*TAU,sn=Math.sin(a)*21;pts.push([p.x+Math.cos(a)*50,p.y+(sn<0?sn:15+sn),1])}for(let yy=-110;yy<=0;yy+=10)for(const dx of[-38,0,38])pts.push([p.x+dx,p.y+yy,0]);
  for(const [x,y,base] of pts){if(base&&G.dRoad(x,y)<39)bad.push([p.x,p.y,'road']);if(base&&G.RV&&G.dRiver(x,y)<54)bad.push([p.x,p.y,'river']);
   if(base&&lake&&((x-lake[0])/(lake[2]+6))**2+((y-lake[1])/(lake[3]+6))**2<1)bad.push([p.x,p.y,'lake']);
   if(vents.some(v=>Math.hypot(x-v[0],(y-v[1])/.8)<44))bad.push([p.x,p.y,'vent']);if(caves.some(c=>x>c.x-74&&x<c.x+74&&y>c.y-96&&y<c.y+60))bad.push([p.x,p.y,'cave']);
   if(C&&x>C.x+20&&x<C.x+C.w-20&&y>C.y+40&&y<C.y+C.h)bad.push([p.x,p.y,'castle'])}}
 return [G.pads.length,[...new Set(bad.map(b=>b.join(',')))]]}"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E("()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;PFW.asked=true;const T=RPP().tut;for(const k of['build','wave','coins','upgrade','abil','twist_frost','twist_ember','twist_wonder'])T[k]=1}")
        # ---------------------------------------------------------------- pads
        for m in ['moss','frost','ember','wonder']:
            r=await E(AUDIT,m);chk(f'{m}: {r[0]} pads, every tower footprint clear of the road edge, river, lava, vents, caves/portals and castle',r[0]>=12 and not r[1],r)
        r=await E("()=>['moss','frost','ember','wonder'].map(m=>{let b=1e9;for(let k=0;k<3;k++){delete RPGEO[m];const t=performance.now();rpGeo(RP_MAP(m));b=Math.min(b,performance.now()-t)}return Math.round(b)})")
        chk('pad placement is computed quickly (under 250 ms per map, once)',max(r)<250,r)
        # ---------------------------------------------------------------- the Tidecaller Shrine
        r=await E("()=>{RPP().stars={};RPP().dragon=0;rpStart('moss');const R=RPX;R.tut=null;R.supply=1000;window.dispatchEvent(new KeyboardEvent('keydown',{key:'i'}));const a=R.place;R.place=null;const ok=rpBuild(R.pads[0],'tide');return [a,RP_TW.tide.cost[0],ok,!!R.pads[0].tw,RP_TWORDER.length,document.querySelectorAll('.rpbar .rpcard').length]}")
        chk('the Tidecaller Shrine costs 600, key I picks it, it is open from the start; nine tower cards (9.8 Thunder Mortar, 9.9 the Still)',r==['tide',600,True,True,9,9],r)
        r=await E("""()=>{rpLeave();rpStart('moss');const R=RPX;R.tut=null;R.supply=1e6;const pads=[...R.pads].sort((a,b)=>a.x-b.x),p=pads[4];rpBuild(p,'tide');p.tw.build=1;
          R.wst='run';R.wave=4;R.q=[];let best=0,bd=1e9,bp=0;R.G.paths.forEach((P2,pi)=>{for(let s=0;s<P2.len;s+=8){const q=rpAt(R.G,s,pi);const d=Math.hypot(q.x-p.x,(q.y-p.y)/.75);if(d<bd){bd=d;best=s;bp=pi}}});
          const g=rpSpawn('scamp',bp);g.s=best;g.sp=30;g.hp=g.mx=1e6;const f=rpSpawn('gloom',bp);f.s=best+10;f.sp=0;f.hp=f.mx=1e6;p.tw.cd=0;
          let minS=1e9,maxBack=0,soak=0,seen=new Set();const s0=g.s;for(let i=0;i<90;i++){rpStep(R,1/60);R.t+=1/60;if(R.tdJets.length)seen.add('jet');if(R.tdWaves.length)seen.add('wave');soak=Math.max(soak,g.soak||0);maxBack=Math.max(maxBack,s0+30*i/60-g.s)}
          return [[...seen].sort().join(','),maxBack>60,soak>1,f.hp===f.mx,g.hp<g.mx]}""")
        chk('it charges, fires a jet, raises a wave that sweeps a monster back and soaks it; flyers are not hit',r==['jet,wave',True,True,True,True],r)
        r=await E("""()=>{const R=RPX;const e=rpSpawn('scamp',0);e.s=50;e.hp=e.mx=1e6;const t={type:'bell'};const h0=e.hp;rpHurt(e,100,99,t);const d1=h0-e.hp;e.soak=2;const h1=e.hp;rpHurt(e,100,99,t);const d2=h1-e.hp;e.dead=1;return [Math.round(d1),Math.round(d2)]}""")
        chk('soaked monsters take 25% more from the Storm Bell',r==[100,125],r)
        r=await E("""()=>{rpLeave();const st=RPP().stars;st.ember=1;rpStart('wonder');const R=RPX;R.tut=null;R.hold=false;R.supply=1e7;const pads=[...R.pads].sort((a,b)=>a.x-b.x),p=pads[5];rpBuild(p,'tide');const tw=p.tw;tw.build=1;
          R.wst='run';R.wave=20;R.q=[];
          let best=0,bd=1e9,bp=0;R.G.paths.forEach((P2,pi)=>{for(let s=0;s<P2.len;s+=8){const q=rpAt(R.G,s,pi);const d=Math.hypot(q.x-p.x,(q.y-p.y)/.75);if(d<bd){bd=d;best=s;bp=pi}}});
          const res=[];for(const tier of[3,4,5]){while(tw.tier<tier)rpUpgrade(tw);tw.upK=1;tw.nb=3;tw.cd=0;for(const e of R.foes)e.dead=1;R.foes=[];for(let k=0;k<12;k++){const e=rpSpawn('bulwark',bp);e.s=best-60+k*18;e.hp=e.mx=1e7;e.sp=40}let whirl=0,jets=0,lev=0;for(let i=0;i<60*6;i++){rpStep(R,1/60);R.t+=1/60;whirl=Math.max(whirl,R.tdWhirls.length);jets=Math.max(jets,R.tdJets.length);lev=Math.max(lev,R.tdLevs.length)}res.push([tier,whirl>0,jets,lev>0])}
          const g=cv.getContext('2d');let px=[];for(const t of[1,2,3,4,5]){g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,400,400);g.save();g.translate(200,300);rpTowerDraw(g,'tide',t,'base',1,{});g.restore();const d=g.getImageData(100,100,200,240).data;let n=0;for(let q=3;q<d.length;q+=16)if(d[q]>20)n++;px.push(n>400)}
          rpDraw();return [res,px]}""")
        chk('tier 3 leaves whirlpools, tier 4 fires twin jets, tier 5 calls the Leviathan; all five tiers draw',r[0]==[[3,True,1,False],[4,True,2,False],[5,True,2,True]] and all(r[1]),r)
        # ---------------------------------------------------------------- the bar and the ring
        await E("()=>{rpLeave();rpStart('frost');RPX.tut=null;RPX.supply=330}");await pg.wait_for_timeout(900)
        await pg.hover('.rpcard[data-tw="bell"]');await pg.wait_for_timeout(450)
        r=await E("()=>{const c=document.querySelector('.rpcard[data-tw=\"bell\"]'),n=document.querySelector('.rpcard[data-tw=\"frost\"]'),cs=getComputedStyle(c),m=new DOMMatrix(cs.transform);const tip=c.querySelector('.rptip');return [Math.round(m.m42),+cs.zIndex>+getComputedStyle(n).zIndex,m.a>1.1,+getComputedStyle(tip).opacity]}")
        chk('hovering a tower tile pops it up over its neighbours with its info flyout',r[0]<=-20 and r[1] and r[2] and r[3]>.9,r)
        await pg.mouse.move(800,60);await pg.wait_for_timeout(300)
        r=await E("""async()=>{const R=RPX,out=[];for(const p of[[...R.pads].sort((a,b)=>a.y-b.y)[0],[...R.pads].sort((a,b)=>b.y-a.y)[0]]){R.selPad=p;R.sel=null;await new Promise(r=>setTimeout(r,900));
          const bs=[...document.querySelectorAll('#rpring .rprb')].map(b=>{const r=b.getBoundingClientRect();return [r.x+r.width/2,r.y+r.height/2]});let mn=1e9;for(let i=0;i<bs.length;i++)for(let j=i+1;j<bs.length;j++)mn=Math.min(mn,Math.hypot(bs[i][0]-bs[j][0],bs[i][1]-bs[j][1]));
          const inStage=bs.every(([x,y])=>y>30&&y<870);out.push([bs.length,Math.round(mn),inStage])}R.selPad=null;return out}""")
        chk('the build ring spreads all nine buttons without overlap, near the top and the bottom of the map',all(x[0]==9 and x[1]>=68 and x[2] for x in r),r)
        # ---------------------------------------------------------------- smooth turning
        r=await E("""()=>{rpLeave();rpStart('moss');const R=RPX;R.tut=null;R.supply=1e6;const p=R.pads[3];rpBuild(p,'ballista');p.tw.build=1;R.wst='run';R.wave=3;R.q=[];
          const F=[];for(let k=0;k<10;k++){const e=rpSpawn(k%2?'scamp':'gloom',0);e.s=80+k*55;e.hp=e.mx=60;F.push(e)}let mx=0,last=null,shots=0;for(let i=0;i<60*14;i++){const f0=p.tw.fire;rpStep(R,1/60);R.t+=1/60;if(p.tw.fire===1&&f0<1)shots++;if(last!=null)mx=Math.max(mx,Math.abs(rpaD(p.tw.aimD,last)));last=p.tw.aimD}
          const dealt=F.reduce((a,e)=>a+60-Math.max(0,e.hp),0);return [+mx.toFixed(3),shots>5,dealt>=shots*RP_TW.ballista.dmg[0]*.85,shots,p.tw.kills]}""")
        chk('the ballista turret turns smoothly (never more than about 9 degrees a frame), still fires as often and every bolt hits',r[0]<=.16 and r[3]>=10 and r[2] and r[4]>=1,r)
        # ---------------------------------------------------------------- the Wonderland
        r=await E("()=>{const m=RP_MAP('wonder'),e=RP_MAP('ember');return [Math.abs(rpHpK(m,10,false)-rpHpK(e,10,false))<1e-9,+(rpHpK(m,60,false)/rpHpK(m,15,false)).toFixed(1),+(rpHpK(m,40,false)/rpHpK(m,15,false)).toFixed(1)]}")
        chk('the endless Wonderland plays like Ember Crown to wave 15 and climbs more gently after (wave 60 hit points far below the old 5%-a-wave curve)',r[0] and r[2]<12 and r[1]<40,r)
        # ---------------------------------------------------------------- menu transitions
        r=await E("""async()=>{rpLeave();title();await new Promise(r=>setTimeout(r,600));const W=()=>document.getAnimations().filter(a=>!(window.CSSAnimation&&a instanceof CSSAnimation)&&!(window.CSSTransition&&a instanceof CSSTransition)&&a.playState==='running');
          rampartsMenu(title);const n=document.querySelectorAll('.rphub').length,a1=W().length;
          await Promise.all(W().map(x=>x.finished.catch(()=>0)));RPSEL='frost';rampartsMenu(title);const a2=W().length;return [n,a1>=2,a2]}""")
        chk('opening another menu screen plays the transition (page rise and veil); re-rendering the same screen does not; nothing is duplicated',r==[1,True,0],r)
        chk('no page errors',not er,er)
        await b.close()
    print(f'{N[0]-len(FAIL)} / {N[0]} passed');sys.exit(1 if FAIL else 0)
asyncio.run(main())
