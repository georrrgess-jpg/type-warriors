/* ===== CELESTIAL GEAR (Act VI): Astral Cleaver (Mythic axe) and Orbitbreaker (Legendary blade) =====
   Both are found only in the Celestial Chest. They use the WNEW builder frame: grip at the origin, tip toward +x, L=70 on the hero. */

/* small drawing helpers shared by the celestial art */
const cxS4=(g,x,y,r,col,k)=>{k=k||.2;g.beginPath();for(let i=0;i<8;i++){const a=-Math.PI/2+i*Math.PI/4,rr=i%2?r*k:r;g.lineTo(x+Math.cos(a)*rr,y+Math.sin(a)*rr)}g.closePath();g.fillStyle=col;g.fill()};
/* fills the current clip with a slow nebula: a gradient, drifting colour clouds and twinkling stars */
function cxNeb(g,x,y,w,h,t,seed,c0,c1,cloud,n){n=n||16;const q=g.createLinearGradient(x,y,x+w*.6,y+h);q.addColorStop(0,c0);q.addColorStop(1,c1);g.fillStyle=q;g.fillRect(x,y,w,h);
 g.save();g.globalCompositeOperation='lighter';for(let i=0;i<4;i++){const px=x+w*(.15+.7*rnd(seed+i*3)+.05*Math.sin(t*.35+i*2)),py=y+h*(.15+.7*rnd(seed+i*3+1)+.05*Math.cos(t*.3+i)),r=Math.max(w,h)*(.28+.2*rnd(seed+i*3+2));glow(g,px,py,r,cloud[i%cloud.length])}g.restore();
 for(let i=0;i<n;i++){const px=x+w*rnd(seed*7+i),py=y+h*rnd(seed*11+i+40),tw=.45+.55*Math.abs(Math.sin(t*(1.1+rnd(i+seed)*1.6)+i*1.7));g.globalAlpha=tw;cxS4(g,px,py,.9+rnd(i*5+seed)*1.5,'#fff',.25)}g.globalAlpha=1}
/* a blade outline: the spine is a curve, wf(u) is the half width at u. Returns the two edges. */
function cxEdges(sp,wf){const n=sp.length,A=[],B=[];for(let i=0;i<n;i++){const a=sp[Math.max(0,i-1)],b=sp[Math.min(n-1,i+1)],dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy)||1,w=wf(i/(n-1)),nx=-dy/d,ny=dx/d;A.push([sp[i][0]+nx*w,sp[i][1]+ny*w]);B.push([sp[i][0]-nx*w,sp[i][1]-ny*w])}return{A,B}}
const cxPath=(g,A,B)=>{g.beginPath();A.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));for(let i=B.length-1;i>=0;i--)g.lineTo(B[i][0],B[i][1]);g.closePath()};
const cxLine=(g,P,from,to)=>{g.beginPath();for(let i=from;i<=to;i++)i>from?g.lineTo(P[i][0],P[i][1]):g.moveTo(P[i][0],P[i][1])};
/* a cut gem with a bright facet; r is the radius */
function cxGem(g,x,y,r,c,c2,pu){pu=pu==null?1:pu;g.save();g.globalCompositeOperation='lighter';glow(g,x,y,r*3.2,c+hxA(.45*pu));g.restore();
 poly(g,[x,y-r*1.25,x+r*.85,y,x,y+r*1.25,x-r*.85,y],c,'#0009',.8);poly(g,[x,y-r*1.25,x+r*.85,y,x,y],'#ffffff77');poly(g,[x,y+r*1.25,x-r*.85,y,x,y],c2||shade(c,-.4)+'aa');ell(g,x-r*.2,y-r*.35,r*.18,r*.22,'#fffd')}
/* a bright four point star with a halo */
function cxStar(g,x,y,r,col,t,ph){const p=.7+.3*Math.sin((t||0)*3+(ph||0));g.save();g.globalCompositeOperation='lighter';glow(g,x,y,r*2.4,col+hxA(.5*p));g.restore();cxS4(g,x,y,r*p,'#fff',.16);g.save();g.globalAlpha=.7;cxS4(g,x,y,r*.6,col,.3);g.restore()}

/* ---------- Mythic: Astral Cleaver ---------- */
/* A double bitted crescent axe: two broad blades whose faces are windows of starry space, a ringed hub with a living violet core,
   a braided dark haft with three silver diamond collars, and a pointed silver pommel. Grip at the origin, head at hx=.82L. */
WNEW.ast_cleaver=(g,L,t,X)=>{const hx=L*.82,pu=.78+.22*Math.sin(t*3.1),SIL='#c3b6e2',small=(()=>{try{const m=g.getTransform();return Math.hypot(m.a,m.b)<1.25}catch(e){return false}})();
 g.save();g.globalCompositeOperation='lighter';glow(g,hx,0,L*.8,'#8a3dff1c');glow(g,hx,0,L*.34,'#c77dff28');g.restore();
 /* haft: dark violet leather in a diagonal braid */
 const H0=-L*.24,H1=hx,HW=3.5,HF=[];for(let i=0;i<=16;i++)HF.push([H0+(H1-H0)*i/16,0]);rib(g,HF,u=>HW,'#2a1834');
 g.save();g.beginPath();g.rect(H0,-HW,H1-H0,HW*2);g.clip();for(let x=H0-4;x<H1;x+=3.4){g.strokeStyle='#0c0512';g.lineWidth=1;g.beginPath();g.moveTo(x,HW);g.lineTo(x+3.4,-HW);g.stroke();g.strokeStyle='#4a3458aa';g.lineWidth=.6;g.beginPath();g.moveTo(x+1.2,HW);g.lineTo(x+4.6,-HW);g.stroke();g.strokeStyle='#0c051266';g.lineWidth=.7;g.beginPath();g.moveTo(x,-HW);g.lineTo(x+3.4,HW);g.stroke()}g.restore();
 g.beginPath();g.moveTo(H0,-HW);g.lineTo(H1,-HW);g.moveTo(H0,HW);g.lineTo(H1,HW);g.strokeStyle='#000b';g.lineWidth=.9;g.stroke();
 /* three silver diamond collars, each set with a violet gem */
 for(const x of[.2,.38,.58]){const cx=L*x,hl=L*.085,hw=HW+1.5;g.beginPath();g.moveTo(cx-hl,0);g.lineTo(cx,-hw);g.lineTo(cx+hl,0);g.lineTo(cx,hw);g.closePath();g.fillStyle=metal(g,-hw,hw,SIL);g.fill();g.strokeStyle='#000';g.lineWidth=1;g.lineJoin='round';g.stroke();
  g.strokeStyle='#f0e8ff99';g.lineWidth=.5;g.beginPath();g.moveTo(cx-hl*.7,-.3);g.lineTo(cx-.2,-hw*.7);g.stroke();poly(g,[cx,-1.9,cx+1.5,0,cx,1.9,cx-1.5,0],'#b04aff','#1a0838',.5);ell(g,cx-.4,-.7,.5,.5,'#fffd')}
 /* the foot: a pointed silver pommel with a violet gem */
 g.beginPath();g.moveTo(H0+L*.05,-HW-1.4);g.lineTo(H0-L*.02,-HW-2.8);g.lineTo(H0-L*.15,0);g.lineTo(H0-L*.02,HW+2.8);g.lineTo(H0+L*.05,HW+1.4);g.closePath();g.fillStyle=metal(g,-HW-1.4,HW+1.4,SIL);g.fill();g.strokeStyle='#000';g.lineWidth=1.1;g.lineJoin='round';g.stroke();
 g.beginPath();g.moveTo(H0,-HW-1.6);g.lineTo(H0-L*.1,-.6);g.strokeStyle='#f0e8ffaa';g.lineWidth=.6;g.stroke();poly(g,[H0-L*.035,-2.6,H0-L*.035+2.4,0,H0-L*.035,2.6,H0-L*.035-2.4,0],'#b04aff','#1a0838',.6);poly(g,[H0-L*.035,-2.6,H0-L*.035+2.4,0,H0-L*.035,0],'#e8d0ffcc');
 /* the head: two broad crescent blades, tips forward and back, each a window of starry space inside a silver rim */
 const cres=(s,k)=>{k=k||1;const cx0=hx-L*.0,cy0=s*L*.27,X=x=>cx0+(x-cx0)*k,Y=y=>cy0+(y-cy0)*k,P=(a,b)=>[X(hx+L*a),Y(s*L*b)];
  g.beginPath();g.moveTo(...P(.31,.2));g.bezierCurveTo(...P(.3,.56),...P(-.27,.6),...P(-.29,.2));
  g.bezierCurveTo(...P(-.22,.27),...P(-.15,.15),...P(-.03,.13));g.bezierCurveTo(...P(.1,.13),...P(.16,.27),...P(.31,.2));g.closePath()};
 for(const s of[-1,1]){
  cres(s);g.strokeStyle='#000';g.lineWidth=3.6;g.lineJoin='round';g.stroke();cres(s);g.fillStyle=metal(g,-L*.5,L*.5,SIL);g.fill();
  g.save();cres(s,.74);g.clip();cxNeb(g,hx-L*.35,s>0?0:-L*.55,L*.7,L*.55,t,s>0?21:34,'#06021a','#1e0e4c',['#8040e028','#ff6ad814','#5a7aff1c','#b080ff22'],small?10:26);
  /* a few bright stars joined by a thin line */
  {const cc=[[-.2,.3],[-.06,.42],[.08,.34],[.2,.27]].map(([a,b])=>[hx+L*a,s*L*b]);g.strokeStyle='#d8b0ff';g.globalAlpha=.4;g.lineWidth=.6;g.beginPath();cc.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.stroke();g.globalAlpha=1;cc.forEach((p,i)=>cxS4(g,p[0],p[1],1.4+(i===1?1.1:0)+.3*Math.sin(t*2+i+s),'#fff',.25))}
  g.restore();
  cres(s,.74);g.strokeStyle='#000c';g.lineWidth=1.1;g.stroke();cres(s,.74);g.strokeStyle='#e8dcffaa';g.lineWidth=.5;g.stroke();cres(s);g.strokeStyle='#000';g.lineWidth=1;g.stroke();
  /* the outer cutting edge glows violet with a thin bright line */
  g.save();g.globalCompositeOperation='lighter';g.beginPath();g.moveTo(hx+L*.31,s*L*.2);g.bezierCurveTo(hx+L*.3,s*L*.56,hx-L*.27,s*L*.6,hx-L*.29,s*L*.2);g.strokeStyle='#c98aff88';g.lineWidth=1.3;g.shadowColor='#b04aff';g.shadowBlur=small?0:7;g.stroke();g.restore();
  g.strokeStyle='#ffffffcc';g.lineWidth=.55;g.beginPath();g.moveTo(hx+L*.27,s*L*.26);g.bezierCurveTo(hx+L*.26,s*L*.5,hx-L*.1,s*L*.53,hx-L*.2,s*L*.4);g.stroke()}
 /* the hub: a silver ring around a living violet core with a star flare */
 ell(g,hx,0,L*.1,L*.1,rgr(g,hx,0,L*.03,L*.1,'#2a1850','#0a0418'));g.beginPath();g.arc(hx,0,L*.1,0,TAU);g.strokeStyle=metal(g,-L*.1,L*.1,SIL);g.lineWidth=2.4;g.stroke();g.beginPath();g.arc(hx,0,L*.1+1.2,0,TAU);g.strokeStyle='#000b';g.lineWidth=.8;g.stroke();g.beginPath();g.arc(hx,0,L*.1-1.2,0,TAU);g.stroke();
 for(let i=0;i<8;i++){const a=i*Math.PI/4+t*.2;g.save();g.translate(hx+Math.cos(a)*L*.1,Math.sin(a)*L*.1);g.rotate(a);g.fillStyle='#d8ccf0';g.fillRect(-.6,-1.9,1.6,3.8);g.restore()}
 g.save();g.globalCompositeOperation='lighter';glow(g,hx,0,L*.16,'#b04aff'+hxA(.7*pu));g.restore();ell(g,hx,0,L*.05,L*.05,rgr(g,hx,0,0,L*.05,'#fff','#b46aff'));
 g.save();g.globalCompositeOperation='lighter';g.globalAlpha=.6*pu;g.fillStyle='#f0d8ff';g.fillRect(hx-L*.16,-.45,L*.32,.9);g.fillRect(hx-.45,-L*.16,.9,L*.32);g.restore();
 /* thin orbit lines and stardust */
 g.save();g.translate(hx,0);g.rotate(-.5);g.strokeStyle='#e0c8ff55';g.lineWidth=.55;g.beginPath();g.ellipse(0,0,L*.22,L*.075,0,0,TAU);g.stroke();if(!small)for(let i=0;i<2;i++){const a=t*1.3+i*Math.PI;cxS4(g,Math.cos(a)*L*.22,Math.sin(a)*L*.075,1.5,'#fff',.25)}g.restore();
 if(!small){g.save();g.globalCompositeOperation='lighter';for(let i=0;i<8;i++){const u=(t*.35+i/8)%1,s=i%2?1:-1,px=hx+L*(-.25+.5*rnd(i+3))-u*L*.1,py=s*L*(.5+.1*rnd(i+9)+u*.12);g.globalAlpha=Math.sin(u*Math.PI)*.8;cxS4(g,px,py,1+rnd(i+20)*1.3,i%3?'#d8a0ff':'#fff',.25)}g.restore()}};

/* ---------- Legendary: Orbitbreaker ---------- */
/* An astral saber. The grip and guard sit exactly where they always have (x0=L*.2); only the blade was lengthened,
   so the guard to tip distance is 1.30x the old .7243*L. All parts are drawn in the weapon's own frame, so the knight carries them as one piece. */
const CXO_OLD_CHORD=.7243,CXO_CHORD=CXO_OLD_CHORD*1.3;
const cxOrb={rec:0,base:null,cur:null,pts:[],fl:[],lastLg:0,lastS:0,boost:0,rm:0,rmT:-9};
const cxoMix=(a,b,k)=>{const p=h=>[parseInt(h.slice(1,3),16),parseInt(h.slice(3,5),16),parseInt(h.slice(5,7),16)];const A=p(a),B=p(b);k=Math.max(0,Math.min(1,k));return '#'+A.map((v,i)=>Math.round(v+(B[i]-v)*k).toString(16).padStart(2,'0')).join('')};
const cxoRM=()=>{const n=performance.now();if(n-cxOrb.rmT>1500){cxOrb.rmT=n;try{cxOrb.rm=ccReduce()?1:0}catch(e){cxOrb.rm=0}}return cxOrb.rm};
let cxoGeoC=null;
/* the blade's spine, its half width and the two edges; cached per weapon length */
function cxOrbGeo(L){if(cxoGeoC&&cxoGeoC.L===L)return cxoGeoC;
 const x0=L*.2,N=40,raw=[];let x=0,y=0;raw.push([0,0]);
 for(let i=1;i<=N;i++){const u=(i-.5)/N,th=-.04+.72*Math.pow(u,1.6)+.36*sstep(.8,1,u);x+=Math.cos(th)/N;y+=Math.sin(th)/N;raw.push([x,y])}
 const k=CXO_CHORD*L/Math.hypot(x,y),SP=raw.map(p=>[x0+p[0]*k,p[1]*k]);
 const wf=u=>L*.13*Math.max(.008,u<.46?(.6+.4*Math.sin(u/.46*Math.PI/2)):Math.pow(1-(u-.46)/.54,.9)),E=cxEdges(SP,wf);
 const tip=SP[N],c=SP[Math.round(.5*N)];
 return cxoGeoC={L,x0,N,SP,wf,E,tip,chord:Math.hypot(tip[0]-x0,tip[1]),ec:c,ang:Math.atan2(SP[Math.round(.5*N)+1][1]-SP[Math.round(.5*N)-1][1],SP[Math.round(.5*N)+1][0]-SP[Math.round(.5*N)-1][0])}}
/* a faceted gem whose shading turns slowly: six facets lit from the upper left */
function cxoCore(g,x,y,r,rot,boost,pc){const oct=()=>{g.beginPath();for(let i=0;i<8;i++){const a=-Math.PI/2+i*Math.PI/4+Math.PI/8;g.lineTo(x+Math.cos(a)*r,y+Math.sin(a)*r)}g.closePath()};
 g.save();oct();g.clip();
 for(let i=0;i<6;i++){const a0=rot+i*Math.PI/3,a1=a0+Math.PI/3,am=(a0+a1)/2,b=Math.min(1,.5+.5*Math.cos(am+2.3)+.3*boost);
  g.beginPath();g.moveTo(x,y);g.lineTo(x+Math.cos(a0)*r*1.3,y+Math.sin(a0)*r*1.3);g.lineTo(x+Math.cos(a1)*r*1.3,y+Math.sin(a1)*r*1.3);g.closePath();g.fillStyle=cxoMix('#2e1182','#d6b6ff',b*.85*pc+.08);g.fill()}
 g.restore();
 oct();g.strokeStyle='#12063a';g.lineWidth=.7;g.lineJoin='round';g.stroke();
 g.beginPath();for(let i=0;i<=2;i++){const a=-Math.PI/2+(i+6)*Math.PI/4+Math.PI/8;i?g.lineTo(x+Math.cos(a)*r,y+Math.sin(a)*r):g.moveTo(x+Math.cos(a)*r,y+Math.sin(a)*r)}g.strokeStyle='#8aeaff';g.lineWidth=.8;g.lineCap='round';g.stroke();
 ell(g,x-r*.28,y-r*.34,r*.16,r*.2,'#ffffffcc')}
WNEW.ast_orbit=(g,L,t,X)=>{g.save();g.scale(1,-1);try{cxOrbDraw(g,L,t,X)}finally{g.restore()}};
/* drawn mirrored so the convex cutting edge leads toward the foes and the hooked tip curls back toward the knight */
const cxOrbDraw=(g,L,t,X)=>{const G=cxOrbGeo(L),x0=G.x0,N=G.N,SP=G.SP,wf=G.wf,E=G.E;
 const rm=cxoRM(),T=rm?1.3:t,mt=g.getTransform?g.getTransform():null,small=mt?Math.hypot(mt.a,mt.b)<1.25:false,bst=cxOrb.rec?cxOrb.boost:0,
  pc=.88+.12*Math.sin(T*1.6+.8),NAVY='#16226a',PG='#ecd48a';
 const GOLD=(a,b)=>metal(g,a,b,PG);
 /* grip: short navy wrap with a few diagonal bands, a gold collar at each end */
 {const g0=-L*.17,g1=x0-3,GR=[];for(let i=0;i<=8;i++)GR.push([g0+(g1-g0)*i/8,0]);rib(g,GR,u=>3.1,'#1a2770');
  g.save();g.beginPath();g.rect(g0,-3.1,g1-g0,6.2);g.clip();g.lineCap='butt';for(let x=g0-3;x<g1;x+=6.4){g.strokeStyle='#0a1033';g.lineWidth=1.5;g.beginPath();g.moveTo(x,3.1);g.lineTo(x+4.2,-3.1);g.stroke();g.strokeStyle='#5068c4';g.lineWidth=.7;g.beginPath();g.moveTo(x+1.2,3.1);g.lineTo(x+5.4,-3.1);g.stroke()}g.restore();
  g.beginPath();g.moveTo(g0,-3.1);g.lineTo(g1,-3.1);g.moveTo(g0,3.1);g.lineTo(g1,3.1);g.strokeStyle='#000b';g.lineWidth=.8;g.stroke();
  for(const x of[g0+.4,g1-1.4]){g.beginPath();g.roundRect(x-1,-3.9,2.6,7.8,1);g.fillStyle=GOLD(-4,4);g.fill();g.strokeStyle='#000b';g.lineWidth=.8;g.stroke()}
  /* pommel: a small violet gem in a pale gold frame */
  const px=g0-4.4;g.beginPath();g.moveTo(px-3.6,0);g.lineTo(px,-5.6);g.lineTo(px+3.6,0);g.lineTo(px,5.6);g.closePath();g.fillStyle=GOLD(-5.6,5.6);g.fill();g.strokeStyle='#000';g.lineWidth=1;g.lineJoin='round';g.stroke();
  poly(g,[px,-3.4,px+2.1,0,px,3.4,px-2.1,0],'#7a4ae0','#1a0a48',.6);poly(g,[px,-3.4,px+2.1,0,px,0],'#d6b6ffcc');poly(g,[px,3.4,px-2.1,0,px,0],'#3a1a98cc');ell(g,px-.5,-1.2,.5,.65,'#fffd')}
 /* the blade silhouette: dark outline, midnight blue surface, a darker inner face */
 cxPath(g,E.A,E.B);g.lineJoin='round';g.strokeStyle='#000';g.lineWidth=3.6;g.stroke();
 {let y0=1e9,y1=-1e9;for(const p of E.B)y0=Math.min(y0,p[1]);for(const p of E.A)y1=Math.max(y1,p[1]);const q=g.createLinearGradient(0,y0,0,y1);q.addColorStop(0,'#2a44a0');q.addColorStop(.6,'#1a2a74');q.addColorStop(1,'#111b58');g.fillStyle=q;cxPath(g,E.A,E.B);g.fill()}
 g.save();cxPath(g,E.A,E.B);g.clip();
 {const M=[];for(let i=0;i<=N;i++)M.push([(E.A[i][0]+E.B[i][0])/2*.55+E.A[i][0]*.45,(E.A[i][1]+E.B[i][1])/2*.55+E.A[i][1]*.45]);
  g.beginPath();for(let i=0;i<=N;i++)g.lineTo(M[i][0],M[i][1]);for(let i=N;i>=0;i--)g.lineTo(E.A[i][0],E.A[i][1]);g.closePath();g.fillStyle='#0b1242dd';g.fill()}
 /* constellation: three small stars on the solid blade, joined by a dim line; the middle one is the anchor */
 {const K=[[.12,.6,1.2,0],[.225,.4,1.9,2.2],[.325,.62,1.35,4.1]].map(([u,f,r,ph])=>{const i=Math.round(u*N),a=E.A[i],b=E.B[i];return{x:b[0]+(a[0]-b[0])*f,y:b[1]+(a[1]-b[1])*f,r,p:rm?.8:.62+.38*Math.sin(T*1.1+ph)}});
  g.strokeStyle='#6fd8ff';g.globalAlpha=.34;g.lineWidth=.6;g.beginPath();K.forEach((p,i)=>i?g.lineTo(p.x,p.y):g.moveTo(p.x,p.y));g.stroke();g.globalAlpha=1;
  K.forEach((p,i)=>{if(!small){g.save();g.globalCompositeOperation='lighter';glow(g,p.x,p.y,p.r*3+1.4,'#5ad0ff'+hxA((i===1?.5:.34)*p.p));g.restore()}
   cxS4(g,p.x,p.y,p.r*(small?1.1:1.5)*(.85+.15*p.p),i===1?'#ffffff':'#bff3ff',.3)})}
 g.restore();
 /* the opening: a clear gap around the suspended core, ringed in pale gold */
 {const ec=G.ec,rx=L*.108,ry=L*.077,cr=L*.049;
  g.save();g.translate(ec[0],ec[1]);g.rotate(G.ang);
  g.beginPath();g.ellipse(0,0,rx+1.1,ry+1.1,0,0,TAU);g.fillStyle='#000';g.fill();
  g.beginPath();g.ellipse(0,0,rx,ry,0,0,TAU);g.fillStyle=rgr(g,0,0,1,rx,'#1a0c46','#04061c');g.fill();g.strokeStyle=GOLD(-ry,ry);g.lineWidth=1.1;g.stroke();
  /* the orbit is tilted; its far half goes behind the core and its near half in front */
  g.save();g.rotate(.32);const orx=rx*.76,ory=ry*.34;
  g.beginPath();g.ellipse(0,0,orx,ory,0,Math.PI,TAU);g.strokeStyle='#5ad0ff';g.globalAlpha=.3;g.lineWidth=.5;g.stroke();g.globalAlpha=1;
  const sa=T*1.05+.3,sx=Math.cos(sa)*orx,sy=Math.sin(sa)*ory,front=Math.sin(sa)>0;
  const sat=()=>{if(small)return;g.save();g.globalCompositeOperation='lighter';glow(g,sx,sy,2.2,'#8aeaff88');g.restore();cxS4(g,sx,sy,front?1.5:1.1,'#e8fbff',.3)};
  if(!front)sat();
  g.save();g.rotate(-.32);{g.save();g.globalCompositeOperation='lighter';glow(g,0,0,cr*(2.1+bst*.9),'#9a6aff'+hxA(Math.min(1,.4*pc+.4*bst)));g.restore();
   cxoCore(g,0,0,cr,rm?.3:T*.42,bst,pc)}g.restore();
  g.beginPath();g.ellipse(0,0,orx,ory,0,0,Math.PI);g.strokeStyle='#7ae6ff';g.globalAlpha=.8;g.lineWidth=.6;g.stroke();g.globalAlpha=1;
  if(front)sat();
  g.restore();g.restore()}
 /* the cutting edge: pale gold, continuous around the tip, with one bevel highlight */
 g.lineJoin='round';g.lineCap='round';
 cxLine(g,E.B,0,N);g.strokeStyle='#000';g.lineWidth=3.4;g.stroke();cxLine(g,E.A,Math.round(.86*N),N);g.stroke();
 cxLine(g,E.A,0,N);g.strokeStyle='#000a';g.lineWidth=2.4;g.stroke();cxLine(g,E.A,0,N);g.strokeStyle='#5a72c8';g.lineWidth=.8;g.stroke();
 cxLine(g,E.B,0,N);g.strokeStyle=GOLD(-L*.2,L*.4);g.lineWidth=1.9;g.stroke();cxLine(g,E.A,Math.round(.86*N),N);g.lineWidth=1.5;g.stroke();
 {const E2=cxEdges(SP,u=>Math.max(0,wf(u)-1.9));cxLine(g,E2.B,4,N-3);g.strokeStyle='#fff6cc';g.globalAlpha=.85;g.lineWidth=.6;g.stroke();g.globalAlpha=1}
 /* the guard: a compact gold crescent cradling an inset four pointed cyan star */
 {const gx=x0-L*.015,hw=L*.155;g.beginPath();g.moveTo(gx+L*.075,-hw);g.bezierCurveTo(gx-L*.06,-hw,gx-L*.095,-hw*.5,gx-L*.09,0);g.bezierCurveTo(gx-L*.095,hw*.5,gx-L*.06,hw,gx+L*.075,hw);
  g.bezierCurveTo(gx+L*.0,hw*.72,gx+L*.04,hw*.4,gx+L*.04,0);g.bezierCurveTo(gx+L*.04,-hw*.4,gx+L*.0,-hw*.72,gx+L*.075,-hw);g.closePath();
  g.fillStyle=GOLD(-hw,hw);g.fill();g.strokeStyle='#000';g.lineWidth=1.3;g.lineJoin='round';g.stroke();
  g.beginPath();g.moveTo(gx+L*.055,-hw*.86);g.bezierCurveTo(gx-L*.045,-hw*.85,gx-L*.075,-hw*.45,gx-L*.07,-hw*.04);g.strokeStyle='#fff6cc99';g.lineWidth=.6;g.stroke();
  const sx=gx-L*.025;g.beginPath();g.arc(sx,0,4.6,0,TAU);g.fillStyle='#0a1236';g.fill();g.strokeStyle='#000';g.lineWidth=.9;g.stroke();g.strokeStyle='#c9ac5a';g.lineWidth=.6;g.beginPath();g.arc(sx,0,3.9,0,TAU);g.stroke();
  const sp=.85+.15*Math.sin(T*1.9+2);g.save();g.globalCompositeOperation='lighter';glow(g,sx,0,7,'#4fc8ff'+hxA(.4*sp));g.restore();cxS4(g,sx,0,3.7*sp,'#6fe0ff',.26);cxS4(g,sx,0,1.7,'#f4fdff',.3)}
 /* remember where the tip is on screen, for the attack trail */
 if(cxOrb.rec&&mt&&g===ctx){const M=cxOrb.base.inverse().multiply(mt),tp=M.transformPoint({x:G.tip[0],y:G.tip[1]}),gp=M.transformPoint({x:x0,y:0});cxOrb.cur={M,tip:[tp.x,tp.y],g:[gp.x,gp.y],tl:G.tip,gl:[x0,0]}}};

/* ---------- Orbitbreaker: attack trail and finishing flourish (cosmetic only) ----------
   The builder above records the tip and guard positions while the hero is drawn in play. Here those turn into a thin cyan crescent that follows
   the real tip path during the existing strike, and a short constellation on a real finishing blow. Neither touches timing, reach or damage. */
const CXO_LIFE=.22,CXO_FL=.62;
function cxoSweep(cu,l,d){const Rw=new DOMMatrix().rotateSelf(0,0,(-1.15+l*2.1)*180/Math.PI),m=new DOMMatrix().translateSelf(d*90,0).multiplySelf(cu.M).multiplySelf(Rw.inverse()).translateSelf(d*20,-d*30).multiplySelf(Rw).rotateSelf(0,0,d*2.1*180/Math.PI);
 const a=m.transformPoint({x:cu.tl[0],y:cu.tl[1]}),b=m.transformPoint({x:cu.gl[0],y:cu.gl[1]});return[a.x,a.y,b.x,b.y]}
function cxoTrail(c,now){const P=cxOrb.pts;if(P.length<2)return;
 c.save();c.globalCompositeOperation='lighter';c.lineCap='round';c.lineJoin='round';
 const fr=p=>Math.max(0,1-(now-p.t)/CXO_LIFE),Q=(p,k)=>{const f=fr(p),kk=k*(.4+.6*f);return[p.tx+(p.gx-p.tx)*kk,p.ty+(p.gy-p.ty)*kk]};
 for(let i=1;i<P.length;i++){const a=P[i-1],b=P[i],fa=fr(a),fb=fr(b),al=Math.pow((fa+fb)/2,1.5);if(al<.01)continue;
  const qa=Q(a,.15),qb=Q(b,.15),va=Q(a,.2),vb=Q(b,.2);
  c.beginPath();c.moveTo(a.tx,a.ty);c.lineTo(b.tx,b.ty);c.lineTo(vb[0],vb[1]);c.lineTo(va[0],va[1]);c.closePath();c.fillStyle='#8a5cff';c.globalAlpha=.2*al;c.fill();
  c.beginPath();c.moveTo(a.tx,a.ty);c.lineTo(b.tx,b.ty);c.lineTo(qb[0],qb[1]);c.lineTo(qa[0],qa[1]);c.closePath();c.fillStyle='#5fd8ff';c.globalAlpha=.42*al;c.fill();
  c.globalAlpha=.9*al;c.strokeStyle='#c8f6ff';c.lineWidth=2.4*(.45+.55*fb);c.beginPath();c.moveTo(a.tx,a.ty);c.lineTo(b.tx,b.ty);c.stroke()}
 c.restore()}
function cxoFlourish(x,y){const o=cxOrb,now=cxoNow(),a0=Math.random()*TAU,pts=[];for(let i=0;i<5;i++){const a=a0+i*1.15+(Math.random()-.5)*.5,r=30+Math.random()*30;pts.push([x+Math.cos(a)*r,y+Math.sin(a)*r*.8-10,2.4+Math.random()*1.8])}
 o.fl.push({t0:now,pts});while(o.fl.length>3)o.fl.shift()}
function cxoFl(c,now){const F=cxOrb.fl;for(let k=F.length-1;k>=0;k--)if(now-F[k].t0>CXO_FL)F.splice(k,1);if(!F.length)return;
 c.save();c.globalCompositeOperation='lighter';c.lineCap='round';
 for(const f of F){const u=now-f.t0,fade=Math.min(1,(CXO_FL-u)/.24),P=f.pts;
  c.strokeStyle='#7fe6ff';c.lineWidth=1.3;c.globalAlpha=.62*fade;
  for(let i=1;i<P.length;i++){const s=Math.max(0,Math.min(1,(u-.04*i)/.07));if(s<=0)break;c.beginPath();c.moveTo(P[i-1][0],P[i-1][1]);c.lineTo(P[i-1][0]+(P[i][0]-P[i-1][0])*s,P[i-1][1]+(P[i][1]-P[i-1][1])*s);c.stroke()}
  P.forEach((p,i)=>{const s=Math.max(0,Math.min(1,(u-.04*i)/.06));if(s<=0)return;const pop=s<1?1.4-.4*s:1,tw=.8+.2*Math.sin(u*30+i*2);c.globalAlpha=fade;glow(c,p[0],p[1],10,'#5ad0ff55');cxS4(c,p[0],p[1],p[2]*pop*tw,i===2?'#ffffff':'#bff3ff',.28)})}
 c.restore()}
{const f0=drawHeroGame;drawHeroGame=function(){const o=cxOrb;
  if(P.weapon!=='ast_orbit'){o.pts.length=0;o.fl.length=0;o.lastLg=0;return f0()}
  const now=cxoNow(),l=S.lunge;if(S.t<o.lastS-.5){o.pts.length=0;o.fl.length=0;o.lastLg=0}o.lastS=S.t;
  o.rec=1;o.base=ctx.getTransform();o.cur=null;o.boost=Math.max(0,Math.min(1,l))*(3-2*Math.max(0,Math.min(1,l)))*(cxoRM()?0:1);
  try{f0()}finally{o.rec=0}
  const cu=o.cur,pl=o.lastLg;
  if(!cxoRM()&&cu&&S.mode==='play'&&l>.05&&l!==pl){const n=l-pl>.08?6:1;
   for(let k=1;k<=n;k++){const lg=pl+(l-pl)*k/n;const q=k===n?[cu.tip[0],cu.tip[1],cu.g[0],cu.g[1]]:cxoSweep(cu,l,lg-l);o.pts.push({tx:q[0],ty:q[1],gx:q[2],gy:q[3],t:now-.04*(1-k/n)})}}
  o.lastLg=l;
  while(o.pts.length&&now-o.pts[0].t>CXO_LIFE)o.pts.shift();if(o.pts.length>30)o.pts.splice(0,o.pts.length-30);
  if(cxoRM()){o.pts.length=0;o.fl.length=0}else{ctx.save();cxoTrail(ctx,now);cxoFl(ctx,now);ctx.restore()}}}
{const k0=kill;kill=function(e,force){const had=!!(S.en&&S.en.includes(e)),r=k0.apply(this,arguments);
  try{if(had&&P.weapon==='ast_orbit'&&S.mode==='play'&&!S.en.includes(e)&&!cxoRM())cxoFlourish(e.x,e.y-(e.h||80)*.5)}catch(x){}return r}}
const cxoNow=()=>performance.now()/1000;

Object.assign(WP,{
 ast_cleaver:{n:'Astral Cleaver',r:'Mythic',d:'Foes 12% slower, +50% score, fury +55%, faster combos, +10% crit',sl:.88,sc:1.5,fu:1.55,cq:1,cr:.1,t:'axe',c:'#c8c0dc',p:'knight',nw:1,hw:1,cel:1,w:1,col:'#ff5fa8'},
 ast_orbit:{n:'Orbitbreaker',r:'Legendary',d:'Foes 8% slower, +30% score, fury +30%, faster combos',sl:.92,sc:1.3,fu:1.3,cq:1,t:'sword',c:'#e6b93e',p:'knight',nw:1,hw:1,cel:1,w:1,col:'#ffc94a'}});
