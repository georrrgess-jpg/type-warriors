/* ---------- casino: core, blackjack, rocket, higher or lower ---------- */
const CAS={bet:50,lock:false,tok:0,on:false,key:null,ret:'title',rh:[]};
const cst=()=>(P.cas=P.cas&&typeof P.cas==='object'?P.cas:{net:0,best:0,plays:0});
const cmn=n=>Math.floor(n).toLocaleString();
const csleep=ms=>new Promise(r=>setTimeout(r,ms));
const cab=n=>n>=1e6?+(n/1e6).toFixed(1)+'M':n>=1e4?Math.round(n/1e3)+'K':n>=1e3?+(n/1e3).toFixed(1)+'K':String(n);
const RKL=['','A','2','3','4','5','6','7','8','9','10','J','Q','K','A'],SUL=['♠','♥','♣','♦'];
const ICON={
 bj:'<svg viewBox="0 0 64 64"><rect x="7" y="12" width="30" height="42" rx="4" fill="#f4ecd8" stroke="#0005" transform="rotate(-12 22 33)"/><rect x="27" y="10" width="30" height="42" rx="4" fill="#fffdf4" stroke="#0005" transform="rotate(9 42 31)"/><text x="41" y="42" font-size="26" text-anchor="middle" fill="#c8202e" font-family="Georgia">♥</text><text x="21" y="42" font-size="24" text-anchor="middle" fill="#222" font-family="Georgia" transform="rotate(-12 22 33)">♠</text></svg>',
 rk:'<svg viewBox="0 0 64 64"><path d="M34 8c10 6 16 20 12 34l-8 6H24l-8-6C12 28 22 14 34 8z" fill="#e8eefc" stroke="#0005" transform="rotate(35 32 32)"/><circle cx="36" cy="26" r="6" fill="#4ab8ff" stroke="#345" stroke-width="2"/><path d="M14 50l-6 8 10-3zM26 58l-4-8 8 2z" fill="#ffb02e"/><path d="M20 36l-10 4 6 8zM44 36l8 10-8 2z" fill="#e8455a"/></svg>',
 hl:'<svg viewBox="0 0 64 64"><rect x="18" y="8" width="28" height="48" rx="4" fill="#fffdf4" stroke="#0005"/><path d="M32 14l9 11H23z" fill="#2aa060"/><path d="M32 50l-9-11h18z" fill="#c83a3a"/></svg>',
 sl:'<svg viewBox="0 0 64 64"><rect x="6" y="14" width="52" height="36" rx="6" fill="#7a0e1c" stroke="#ffd76a" stroke-width="3"/><rect x="11" y="19" width="12" height="26" rx="2" fill="#fffdf4"/><rect x="26" y="19" width="12" height="26" rx="2" fill="#fffdf4"/><rect x="41" y="19" width="12" height="26" rx="2" fill="#fffdf4"/><g font-family="Georgia" font-weight="700" font-size="20" text-anchor="middle" fill="#c8202e"><text x="17" y="39">7</text><text x="32" y="39">7</text><text x="47" y="39">7</text></g><rect x="58" y="20" width="4" height="18" rx="2" fill="#ffd76a"/></svg>',
 ro:'<svg viewBox="0 0 64 64"><circle cx="32" cy="32" r="28" fill="#5a3a18" stroke="#ffd76a" stroke-width="2"/><circle cx="32" cy="32" r="21" fill="#16161f"/><circle cx="32" cy="32" r="16" fill="none" stroke="#c8202e" stroke-width="10" stroke-dasharray="4.2 4.2"/><circle cx="32" cy="32" r="8" fill="#ffd76a"/><circle cx="32" cy="14" r="3" fill="#fff"/></svg>',
 di:'<svg viewBox="0 0 64 64"><rect x="10" y="10" width="44" height="44" rx="9" fill="#fffdf4" stroke="#0005" stroke-width="2" transform="rotate(-10 32 32)"/><g fill="#c8202e" transform="rotate(-10 32 32)"><circle cx="22" cy="22" r="4.5"/><circle cx="42" cy="22" r="4.5"/><circle cx="32" cy="32" r="4.5"/><circle cx="22" cy="42" r="4.5"/><circle cx="42" cy="42" r="4.5"/></g></svg>',
 mi:'<svg viewBox="0 0 64 64"><polygon points="24,10 42,10 54,24 32,56 10,24" fill="#4ad8ff" stroke="#0a4a6a" stroke-width="2"/><polygon points="24,10 32,24 10,24" fill="#a8f0ff"/><polygon points="42,10 54,24 32,24" fill="#2aa0d0"/><polygon points="10,24 54,24 32,56" fill="#1a80b0" opacity=".7"/></svg>'};
const GEM='<svg viewBox="0 0 64 64"><polygon points="20,8 44,8 58,24 32,58 6,24" fill="#4ad8ff" stroke="#0a4a6a" stroke-width="3"/><polygon points="20,8 32,24 6,24" fill="#b8f4ff"/><polygon points="44,8 58,24 32,24" fill="#2aa0d0"/></svg>';
const BOMB='<svg viewBox="0 0 64 64"><circle cx="30" cy="38" r="20" fill="#1a1a26" stroke="#000" stroke-width="2"/><ellipse cx="23" cy="30" rx="6" ry="4" fill="#fff5" transform="rotate(-30 23 30)"/><path d="M42 22l8-8" stroke="#a88a5a" stroke-width="4" stroke-linecap="round"/><circle cx="53" cy="10" r="6" fill="#ffb02e"/><circle cx="53" cy="10" r="3" fill="#fff3a0"/></svg>';

const GAMES=[
 {id:'bj',n:'Blackjack',d:'Beat the dealer to 21. Blackjack pays 3 to 2. Double down when the odds look right.',m:(e,t)=>mBJ(e,t)},
 {id:'rk',n:'Rocket',d:'The rocket climbs and the multiplier grows. Cash out before it explodes. Set an auto cash out if you like.',m:(e,t)=>mRK(e,t)},
 {id:'hl',n:'Higher or Lower',d:'Guess whether the next card is higher or lower. Chain guesses for a bigger multiplier and cash out any time. Payouts are capped at 20,000.',m:(e,t)=>mHL(e,t)},
 {id:'sl',n:'Slot Machine',d:'Spin three reels. Match symbols on the middle line. Two cherries already pay.',m:(e,t)=>mSL(e,t)},
 {id:'ro',n:'Roulette',d:'European wheel with one zero. Bet on numbers, colours, odds, evens, halves and dozens together.',m:(e,t)=>mRO(e,t)},
 {id:'di',n:'Dice',d:'Roll from 0 to 100. Pick over or under and slide your win chance. Lower chance pays more.',m:(e,t)=>mDI(e,t)},
 {id:'mi',n:'Mines',d:'Uncover gems on a 5 by 5 board and avoid the hidden bombs. Every gem raises your payout.',m:(e,t)=>mMI(e,t)}];

/* balance, stats and bets */
function balUp(d){const e=$('cbal');if(!e)return;e.textContent=cmn(P.gold);if(d){const f=document.createElement('span');f.className='fl '+(d>0?'up':'dn');f.textContent=(d>0?'+':'−')+cmn(Math.abs(d));e.parentNode.appendChild(f);setTimeout(()=>f.remove(),1400)}}
function cTake(b){b=Math.floor(b);if(!(b>=1)||b>P.gold)return false;P.gold-=b;save();balUp();return true}
function cPay(bet,pay){pay=Math.max(0,Math.floor(pay));P.gold+=pay;casTrack(bet,pay);const c=cst();c.plays++;c.net+=pay-bet;if(pay-bet>c.best)c.best=pay-bet;save();balUp(pay-bet);
 if(pay>=bet*6&&pay-bet>=200)try{bigWin(pay-bet,pay>=bet*25||pay-bet>=5000)}catch(e){}
 if(pay>bet){jingle(pay>=bet*5?'win':'boon')}else if(pay<bet)beep(170,.22,'sawtooth',.5)}
function msg(t,c){const e=$('cm');if(!e)return;e.textContent=t||' ';e.style.color=c==='w'?'#7dff9a':c==='l'?'#ff8a98':'#ffe9a8'}
function betBar(lab){return `<div class="bet"><div class="bv">${lab||'Bet'} <b id="bv">0</b> <small style="opacity:.6">max ${cmn(CAS_MAX)}</small></div><div class="chips">${[10,50,100,500,1000,5000].map(v=>`<button class="chip c${v}" data-a="${v}" aria-label="Add ${v}">${cab(v)}</button>`).join('')}</div><div class="bx"><button class="sm" data-m="c">Clear</button><button class="sm" data-m="h">½</button><button class="sm" data-m="d">2×</button><button class="sm" data-m="m">Max</button></div></div>`}
const CAS_MAX=7500;
function betRefresh(){CAS.bet=Math.max(0,Math.min(Math.floor(CAS.bet),P.gold,CAS.cap||Infinity));const e=$('bv');if(e)e.textContent=cmn(CAS.bet)}
function wireBet(onch){const f=()=>{betRefresh();if(onch)onch()};
 ov.querySelectorAll('.bet [data-a]').forEach(b=>b.onclick=()=>{if(CAS.lock)return;CAS.bet=Math.min(P.gold,CAS.bet+ +b.dataset.a);f();beep(700,.04,'triangle',.5)});
 ov.querySelectorAll('.bet [data-m]').forEach(b=>b.onclick=()=>{if(CAS.lock)return;const k=b.dataset.m;CAS.bet=k==='c'?0:k==='h'?Math.floor(CAS.bet/2):k==='d'?CAS.bet*2:P.gold;f();beep(520,.04,'triangle',.5)});
 if(CAS.bet<1&&P.gold>=1)CAS.bet=Math.min(50,P.gold);f()}
function betLock(v){CAS.lock=v;ov.querySelectorAll('.bet button').forEach(b=>b.disabled=v);const c=$('cb');if(c)c.disabled=v;if(!v)betRefresh()}
const broke=()=>P.gold<1?'You are out of gold. Slay some monsters to earn more.':'';

/* frame and lobby */
function casinoOpen(){if(S.mode!=='title')return;CAS.ret=S.mode==='pause'?'pause':'title';ensureAudio();lobby()}
function cFlush(){if(CAS.flush){const f=CAS.flush;CAS.flush=null;try{f()}catch(e){console.error(e)}}}
function casinoBack(){cFlush();CAS.on=false;CAS.key=null;CAS.tok++;if(CAS.ret==='pause'&&S.mode==='pause')pauseMenu();else title()}
function lobby(){CAS.cap=0;cFlush();CAS.tok++;CAS.lock=false;CAS.on=true;CAS.key=null;const c=cst();CAS.tab=CAS.tab||'all';
 const rm=matchMedia('(prefers-reduced-motion: reduce)').matches,coarse=matchMedia('(pointer: coarse)').matches;
 show(`<div class="gd" id="gd"><canvas class="gdbg" id="gdbg" width="1600" height="900"></canvas><div class="gdvg"></div>
<button class="gdleave" id="cb"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg><span>Leave</span></button>
<div class="gdpill"><span class="coin big"></span><b id="cbal">${cmn(P.gold)}</b></div>
<div class="gdstat">Lifetime <b class="${c.net>=0?'up':'dn'}">${c.net>=0?'+':'−'}${cmn(Math.abs(c.net))}</b> over ${c.plays} rounds · best win ${cmn(c.best)}</div>
${gdLogo()}
<div class="gdtabs" id="gdtabs">${TTAB.map(t=>`<button class="gdtab${t[0]===CAS.tab?' on':''}" data-t="${t[0]}"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">${t[2]}</svg><span>${t[1]}</span></button>`).join('')}</div>
<div class="gdgrid" id="gdgrid"></div>
<div class="gdfoot"><span id="gdft">${GDFOOT}${coarse?' Tap a card to preview it, tap again to play.':''}</span></div></div>`,'casbg gdo');
 S.back=casinoBack;$('cb').onclick=casinoBack;
 const bg=$('gdbg'),sf=cdScene(bg,rm);let once=0;LIVE.push({cv:bg,fn:rm?(t=>{if(!once){once=1;sf(t)}}):sf,slow:2,ph:0,vis:true});
 const grid=()=>{const gg=$('gdgrid');if(CAS.tab==='special'&&typeof twLobby==='function'){twLobby();return}gg.className='gdgrid';const L=GAMES.filter(g=>CAS.tab==='all'||(CAS.tab==='cards'?TCAT[g.id]==='cards':CAS.tab==='quiz'?TCAT[g.id]==='quiz':(!TCAT[g.id]||g.id==='ns')));
  $('gdgrid').innerHTML=L.map((g,i)=>`<button class="gdt" data-g="${g.id}" style="--i:${i}" aria-label="${g.n}" aria-describedby="gdd_${g.id}"><span class="gdta">${TA[g.id]||ICON[g.id]}</span><i class="co c1"></i><i class="co c2"></i><i class="co c3"></i><i class="co c4"></i><span class="gdd" id="gdd_${g.id}"><b>${g.d}</b>${coarse?'<em>Tap again to play</em>':''}</span><span class="gdtn${g.n.length>=12?' lg':''}">${g.n}</span></button>`).join('');
  ov.querySelectorAll('.gdt').forEach(b=>{const g=GAMES.find(x=>x.id===b.dataset.g);
   b.onclick=e=>{const touch=e.pointerType==='touch'||(coarse&&!e.pointerType&&e.detail>0);
    if(touch&&!b.classList.contains('sel')){ov.querySelectorAll('.gdt.sel').forEach(x=>x.classList.remove('sel'));b.classList.add('sel');return}
    gameOpen(g.id)}})};
 ov.querySelectorAll('.gdtab').forEach(b=>b.onclick=()=>{if(b.dataset.t===CAS.tab)return;CAS.tab=b.dataset.t;ov.querySelectorAll('.gdtab').forEach(x=>x.classList.toggle('on',x===b));grid();beep(620,.05,'triangle',.5)});
 grid()}
const GDFOOT='In-game gold only.';
function gameOpen(id){const g=GAMES.find(x=>x.id===id);if(!g)return;CAS.cap=CAS_MAX;cFlush();CAS.tok++;CAS.lock=false;CAS.key=null;const tok=CAS.tok;
 cdCave();show(`<div class="cas"><div class="ctop"><button class="sm" id="cb"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg><span>Lobby</span></button><h2>${g.n}</h2><div class="gbar"><span class="coin big"></span><b id="cbal">${cmn(P.gold)}</b></div></div><div id="cg" style="width:100%;display:flex;flex-direction:column;align-items:center;gap:12px"></div></div>`,'casbg');
 S.back=()=>{if(!CAS.lock)lobby()};$('cb').onclick=S.back;
 try{g.m($('cg'),tok)}catch(err){console.error(err);lobby()}}
addEventListener('keydown',e=>{if(!CAS.on||!CAS.key||ov.className.indexOf('casbg')<0||e.ctrlKey||e.metaKey||e.altKey)return;if(document.activeElement&&/INPUT/.test(document.activeElement.tagName)&&document.activeElement.type!=='range')return;const f=CAS.key[e.key==='Enter'?'enter':e.key.toLowerCase()];if(f){e.preventDefault();f()}});
ov.addEventListener('mousedown',e=>{if(e.target.closest&&e.target.closest('.cas button'))e.preventDefault()});
{const cz=$('cz');cz.onclick=casinoOpen;cz.addEventListener('mousedown',e=>e.preventDefault());
 let vis=false;setInterval(()=>{const v=S.mode==='title'&&ov.className.indexOf('hide')<0;if(v!==vis){vis=v;cz.style.display=v?'flex':'none'}},200)}

/* ---------- blackjack ---------- */
function mBJ(el,tok){
 const alive=()=>CAS.tok===tok;let sh=[],p=[],d=[],bet=0,ph='idle',hid=true;
 const shoe=()=>{sh=[];for(let k=0;k<6;k++)for(let r=1;r<=13;r++)for(let s=0;s<4;s++)sh.push([r,s]);for(let i=sh.length-1;i>0;i--){const j=Math.random()*(i+1)|0;[sh[i],sh[j]]=[sh[j],sh[i]]}};shoe();
 const val=h=>{let t=0,a=0;for(const c of h){const r=c[0];t+=r>10?10:r===1?(a++,11):r}while(t>21&&a>0){t-=10;a--}return t};
 const isBJ=h=>h.length===2&&val(h)===21;
 const card=(c,cl)=>`<div class="pc${c[1]%2?' r':''} ${cl||''}"><i>${RKL[c[0]]}</i><b>${SUL[c[1]]}</b><u>${SUL[c[1]]}</u></div>`;
 el.innerHTML=`<div class="felt" style="height:420px"><div class="hl">Dealer <b id="bjdv">-</b></div><div class="hand" id="bjd"></div><div class="hand" id="bjp"></div><div class="hl">You <b id="bjpv">-</b></div></div>
<p class="cmsg" id="cm"> </p><div class="ctl">${betBar()}<div class="btns"><button class="bbig" id="b0">Deal</button><button class="bbig" id="bh" style="display:none">Hit</button><button class="bbig" id="bs" style="display:none">Stand</button><button class="bbig" id="bd" style="display:none">Double</button></div></div>`;
 const R=ns=>{$('bjd').innerHTML=d.map((c,i)=>i===1&&hid?'<div class="pc bk"><i></i></div>':card(c,(ns==='d'&&i===d.length-1)||(ns==='rv'&&i===1)?'nw':'')).join('');
  $('bjp').innerHTML=p.map((c,i)=>card(c,ns==='p'&&i===p.length-1?'nw':'')).join('');
  $('bjdv').textContent=d.length?(hid?val([d[0]]):val(d)):'-';$('bjpv').textContent=p.length?val(p):'-'};
 const B=()=>{$('b0').style.display=ph==='idle'?'':'none';const pl=ph==='play';$('bh').style.display=$('bs').style.display=pl?'':'none';$('bd').style.display=pl&&p.length===2&&P.gold>=bet?'':'none'};
 const fin=async res=>{ph='idle';hid=false;R();bjTrack(res);const pay=res==='bj'?bet*2.5:res==='win'?bet*2:res==='push'?bet:0;cPay(bet,pay);
  const tx={bj:'Blackjack! Pays 3 to 2.',win:'You win.',push:'Push. Your bet is returned.',lose:'Dealer wins.',bust:'Bust. You went over 21.',dbust:'Dealer busts. You win.'}[res==='win'&&val(d)>21?'dbust':res];
  const w=pay>bet;msg(tx+(pay>bet?` +${cmn(pay-bet)}`:pay<bet?` −${cmn(bet)}`:'')+(broke()?' '+broke():''),w?'w':pay<bet?'l':'');betLock(false);B();$('b0').textContent='Deal again'};
 const dealerPlay=async()=>{ph='dealer';B();hid=false;R('rv');beep(600,.06,'triangle',.5);await csleep(600);if(!alive())return;
  while(val(d)<17){d.push(sh.pop());R('d');beep(520,.05,'triangle',.5);await csleep(650);if(!alive())return}
  const pv=val(p),dv=val(d);fin(dv>21||pv>dv?'win':pv===dv?'push':'lose')};
 const deal=async()=>{if(ph!=='idle'||CAS.lock)return;if(CAS.bet<1){msg(broke()||'Place a bet first.');return}if(CAS.bet>P.gold){msg('Not enough gold.');return}
  if(sh.length<90)shoe();bet=CAS.bet;if(!cTake(bet))return;betLock(true);p=[];d=[];hid=true;ph='deal';msg('');B();R();
  for(const s of['p','d','p','d']){await csleep(280);if(!alive())return;(s==='p'?p:d).push(sh.pop());beep(520,.05,'triangle',.5);R(s)}
  await csleep(320);if(!alive())return;
  if(isBJ(p)||isBJ(d)){hid=false;R('rv');await csleep(500);if(!alive())return;fin(isBJ(p)&&isBJ(d)?'push':isBJ(p)?'bj':'lose');return}
  ph='play';B()};
 const hit=async()=>{if(ph!=='play')return;p.push(sh.pop());beep(520,.05,'triangle',.5);R('p');const v=val(p);if(v>21){ph='x';B();await csleep(450);if(alive())fin('bust')}else if(v===21){ph='x';B();await csleep(400);if(alive())dealerPlay()}};
 const stand=()=>{if(ph!=='play')return;ph='x';B();dealerPlay()};
 const dbl=async()=>{if(ph!=='play'||p.length!==2||P.gold<bet)return;if(bet*2>CAS_MAX){msg('Table limit: '+cmn(CAS_MAX)+' per hand, so you cannot double this bet.');return}if(!cTake(bet))return;bet*=2;ph='x';B();p.push(sh.pop());beep(520,.05,'triangle',.5);R('p');await csleep(700);if(!alive())return;if(val(p)>21)fin('bust');else dealerPlay()};
 $('b0').onclick=deal;$('bh').onclick=hit;$('bs').onclick=stand;$('bd').onclick=dbl;wireBet();CAS.key={' ':()=>{if(ph==='idle')deal();else if(ph==='play')stand()},enter:()=>{if(ph==='idle')deal()},h:hit,s:stand,d:dbl};
 msg('Place your bet and press Deal. Keys: H hit, S stand, D double, Space deal or stand.');B()}

/* ---------- higher or lower ---------- */
const HLMAX=20000,HLE=1.075,HLBET=5000,HLGUESS=3,HLFACE=.75,HLTIE=(1/13)*.65;/* max payout, edge, max bet, guesses per round, and the cut applied to multipliers when the shown card is a J, Q, K or A *//* Higher or Lower: hard cap on total payout, and the per-guess multiplier edge (was 1.1) */
/* the payout cap applies to each round: reaching it cashes the player out automatically */
const hlLeft=()=>HLMAX,hlAddPaid=()=>{};
function mHL(el,tok){
 const alive=()=>CAS.tok===tok;let cur=null,cmul=1,bet=0,ph='idle',trail=[],busy=false,gn=0;CAS.cap=HLBET;
 const rnd=()=>[2+(Math.random()*13|0),Math.random()*4|0];
 const rnx=r=>{if(Math.random()<HLTIE)return[r,Math.random()*4|0];let k=2+(Math.random()*12|0);if(k>=r)k++;return[k,Math.random()*4|0]};/* a tie is 35% rarer than a plain draw (5% instead of 7.7%); the other 12 ranks share the rest equally */
 const pH=r=>(1-HLTIE)*(14-r)/12,pL=r=>(1-HLTIE)*(r-2)/12,fcut=(r,m)=>r>=11?Math.max(1.02,m*HLFACE):m,mH=r=>fcut(r,HLE/pH(r)),mL=r=>fcut(r,HLE/pL(r)),pay=(b,m)=>Math.min(hlLeft(),Math.floor(b*m));
 const card=(c,cl)=>`<div class="pc big2${c[1]%2?' r':''} ${cl||''}"><i>${RKL[c[0]]}</i><b>${SUL[c[1]]}</b><u>${SUL[c[1]]}</u></div>`;
 el.innerHTML=`<div class="felt" style="height:380px;flex-direction:row;gap:60px"><div class="msi" style="align-items:center;min-width:300px"><span>Multiplier</span><b id="hlm" style="font-size:64px">1.00×</b><span id="hlp">Payout <b style="font-size:34px" id="hlpv">0</b></span><span id="hlg" style="font-size:20px;opacity:.85"></span></div><div class="hand" id="hlc" style="min-height:200px;min-width:300px"></div><div class="hand" id="hlt" style="min-width:300px;gap:6px"></div></div>
<p class="cmsg" id="cm"> </p><div class="ctl">${betBar()}<div class="btns"><button class="bbig" id="h0">Start</button><button class="bbig" id="hh" style="display:none">Higher</button><button class="bbig" id="hlw" style="display:none">Lower</button><button class="bbig" id="hco" style="display:none">Cash out</button></div></div>`;
 const R=(cl)=>{$('hlc').innerHTML=cur?card(cur,cl):'<div class="pc big2 bk"><i></i></div>';$('hlt').innerHTML=trail.slice(-5).map(c=>`<div class="pc${c[1]%2?' r':''}" style="width:52px;height:74px;padding:3px 5px;opacity:.75"><i style="font-size:20px">${RKL[c[0]]}</i><b style="font-size:16px">${SUL[c[1]]}</b></div>`).join('');
  $('hlg').textContent=ph==='play'?`Guess ${Math.min(gn+1,HLGUESS)} of ${HLGUESS}`:`${HLGUESS} guesses per round`;$('hlg').textContent+='  ·  max payout '+cmn(HLMAX)+' per round';$('hlm').textContent=cmul.toFixed(2)+'×';$('hlpv').textContent=cmn(pay(bet,cmul))};
 const B=()=>{const pl=ph==='play';$('h0').style.display=ph==='idle'?'':'none';$('hh').style.display=$('hlw').style.display=pl?'':'none';$('hco').style.display=pl&&cmul>1?'':'none';
  if(pl){const h=$('hh'),l=$('hlw');h.disabled=busy||pH(cur[0])<=0;l.disabled=busy||pL(cur[0])<=0;h.innerHTML='Higher <small style="font-size:18px">'+(pH(cur[0])>0?'×'+mH(cur[0]).toFixed(2):'–')+'</small>';l.innerHTML='Lower <small style="font-size:18px">'+(pL(cur[0])>0?'×'+mL(cur[0]).toFixed(2):'–')+'</small>';$('hco').disabled=busy;$('hco').textContent='Cash out '+cmn(pay(bet,cmul))}};
 const start=()=>{if(ph!=='idle'||CAS.lock)return;if(CAS.bet<1){msg(broke()||'Place a bet first.');return}if(CAS.bet>P.gold){msg('Not enough gold.');return}CAS.bet=Math.min(CAS.bet,HLBET);bet=CAS.bet;gn=0;if(!cTake(bet))return;betLock(true);cur=rnd();cmul=1;trail=[];ph='play';busy=false;R('nw');B();msg('Will the next card be higher or lower? A tie loses.');beep(520,.05,'triangle',.5)};
 const guess=async up=>{if(ph!=='play'||busy)return;const r=cur[0];if((up?pH(r):pL(r))<=0)return;busy=true;B();const mult=up?mH(r):mL(r);let nx=rnx(r);
  const win=up?nx[0]>r:nx[0]<r;await csleep(180);if(!alive())return;trail.push(cur);cur=nx;R('nw');beep(win?660:200,.1,'triangle',.6);await csleep(450);if(!alive())return;busy=false;
  if(win){gn++;cmul=Math.floor(cmul*mult*100)/100;if(bet*cmul>=hlLeft()||gn>=HLGUESS){const capped=bet*cmul>=hlLeft();const pv=pay(bet,cmul);if(capped)cmul=pv/bet;ph='idle';hlAddPaid(pv);cPay(bet,pv);R();msg(capped?`Maximum payout reached! Cashed out ${cmn(pv)} (+${cmn(pv-bet)}).`:`All ${HLGUESS} guesses correct! Cashed out ${cmul.toFixed(2)}×  +${cmn(pv-bet)}`,'w');betLock(false);B();$('h0').textContent='Play again';return}R();B();msg(`Correct! Multiplier ${cmul.toFixed(2)}×. ${HLGUESS-gn} guess${HLGUESS-gn===1?'':'es'} left. Keep going or cash out.`,'w')}
  else{ph='idle';cPay(bet,0);msg((nx[0]===r?'A tie. ':'Wrong. ')+`You lose ${cmn(bet)}.${broke()?' '+broke():''}`,'l');cmul=1;R();betLock(false);B();$('h0').textContent='Play again'}};
 const cashout=()=>{if(ph!=='play'||busy||cmul<=1)return;const pv=pay(bet,cmul);ph='idle';hlAddPaid(pv);cPay(bet,pv);msg(`Cashed out ${cmul.toFixed(2)}×  +${cmn(pv-bet)}`,'w');betLock(false);B();$('h0').textContent='Play again'};
 $('h0').onclick=start;$('hh').onclick=()=>guess(true);$('hlw').onclick=()=>guess(false);$('hco').onclick=cashout;wireBet();
 CAS.key={' ':()=>{ph==='idle'?start():cashout()},enter:()=>{if(ph==='idle')start()},arrowup:()=>guess(true),arrowdown:()=>guess(false),h:()=>guess(true),l:()=>guess(false),c:cashout};
 const sm=el.querySelector('.bv small');if(sm)sm.textContent='max '+cmn(HLBET);betRefresh();R();msg('Place your bet (max 5,000, 3 guesses, max payout 20,000) and press Start. Keys: H higher, L lower, C or Space cash out.')}
