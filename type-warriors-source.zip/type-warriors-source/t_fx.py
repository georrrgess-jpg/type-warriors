import asyncio,os
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append('PE '+str(e)[:300]));pg.on('console',lambda m:m.type=='error' and er.append('CE '+m.text[:200]))
        await pg.goto('file://'+os.path.abspath('out.html'));await pg.wait_for_timeout(1500);E=pg.evaluate
        await E("()=>{RS_ASK=false;P.gold=51413;P.pets={};['antler','bramble','cinder','ember','beetle','gloom','noct'].forEach((k,i)=>P.pets[k]={b:i*40,t:Date.now()-i*1e6});P.pet='bramble';P.petSt=2;P.eggs={r:2,l:0};petNorm();PTX.sel='ember';PTX.petted=0;petHall('Pets')}")
        await pg.wait_for_timeout(2400);await pg.screenshot(path='shots/fx_hint.png')
        bb=await pg.locator('#ptcv').bounding_box()
        for i in range(5):
            await pg.mouse.click(bb['x']+bb['width']*.31,bb['y']+bb['height']*.7);await pg.wait_for_timeout(180)
        await pg.wait_for_timeout(250);await pg.screenshot(path='shots/fx_combo.png')
        await pg.hover('.ptc[data-p="noct"]');await pg.wait_for_timeout(600);await pg.screenshot(path='shots/fx_hover.png',clip={'x':140,'y':170,'width':420,'height':420})
        await pg.click('.ptc[data-p="antler"]');await pg.wait_for_timeout(1500)
        await pg.click('#pteq');await pg.wait_for_timeout(700);await pg.screenshot(path='shots/fx_equip.png')
        print('equipped',await E("()=>P.pet"))
        await E("()=>petHall('Eggs')");await pg.wait_for_timeout(1500);await pg.screenshot(path='shots/fx_eggs.png')
        eb=await pg.locator('#phxcv').bounding_box()
        await pg.mouse.click(eb['x']+eb['width']*.5,eb['y']+eb['height']*.5);await pg.wait_for_timeout(350);await pg.screenshot(path='shots/fx_tap.png')
        await pg.click('[data-egg="l"]');await pg.wait_for_timeout(900);await pg.screenshot(path='shots/fx_eggs_l.png')
        await pg.click('[data-egg="r"]');await pg.wait_for_timeout(600);await pg.click('#phxht');await pg.wait_for_timeout(500);await pg.click('#ptsk');await pg.wait_for_timeout(1800);await pg.screenshot(path='shots/fx_reveal.png')
        print(er[:6]);await b.close()
asyncio.run(main())
