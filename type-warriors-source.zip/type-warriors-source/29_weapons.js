/* ---------- texture helpers ---------- */
function sheen(g,x,y,w,h,a){const q=g.createLinearGradient(x,y,x+w,y+h);q.addColorStop(0,'rgba(255,255,255,'+a+')');q.addColorStop(.42,'rgba(255,255,255,0)');q.addColorStop(1,'rgba(0,0,0,'+a*.9+')');g.fillStyle=q;g.fillRect(x,y,w,h)}
function rivet(g,x,y,r,c){ell(g,x,y+r*.3,r,r,'#0005');ell(g,x,y,r,r,shade(c,-.3));ell(g,x-r*.25,y-r*.3,r*.55,r*.5,shade(c,.6))}
function grain(g,x,y,w,h,c,n,seed){g.fillStyle=c;let s=(seed||1)*7919;for(let i=0;i<n;i++){s=(s*9301+49297)%233280;const a=s/233280;s=(s*9301+49297)%233280;const b=s/233280;g.fillRect(x+a*w,y+b*h,1.7,1.1)}}
function gem(g,x,y,r,c){glow(g,x,y,r*3,c+'88');poly(g,[x,y-r,x+r*.8,y,x,y+r,x-r*.8,y],c,shade(c,-.5),.8);poly(g,[x,y-r,x+r*.8,y,x,y],'#ffffff55');ell(g,x-r*.25,y-r*.3,r*.22,r*.22,'#fffc')}
function metal(g,y0,y1,c){const q=g.createLinearGradient(0,y0,0,y1);q.addColorStop(0,shade(c,.62));q.addColorStop(.28,shade(c,.18));q.addColorStop(.52,c);q.addColorStop(.78,shade(c,-.3));q.addColorStop(1,shade(c,-.55));return q}

/* ---------- hero weapons (grip at origin, blade toward +x) ---------- */
function hsx(h,sat,l){h=((h%360)+360)%360/360;const f=n=>{const k=(n+h*12)%12,a=sat/100*Math.min(l/100,1-l/100);const v=l/100-a*Math.max(-1,Math.min(k-3,9-k,1));return Math.round(v*255).toString(16).padStart(2,'0')};return '#'+f(0)+f(8)+f(4)}
function drawW(g,id,L,t){drawW1(g,id,L,t);wGlow(g,id,L,t)}
function drawW1(g,id,L,t){const w=WP[id];if(RKM[w.r]<5||w.hw)return drawW0(g,id,L,t);t=t||0;const h0=(w.h||0)+(MYA[id]?Math.sin(t*1.7)*34:t*55),sv=[w.c,w.col];w.c=hsx(h0,88,58);w.col=hsx(h0+60,95,68);const c2=w.col;
 g.save();glow(g,L*.5,0,L*.95,c2+'55');g.restore();
 try{drawW0(g,id,L,t)}finally{w.c=sv[0];w.col=sv[1]};mythArt(g,id,L,t,h0);
 g.save();for(let i=0;i<9;i++){const a=t*2.2+i*.7,u=(i/9+t*.25)%1,x=L*(.1+u*.95),y=Math.sin(a)*L*.14*(.4+u);g.globalAlpha=.9;g.fillStyle=i%2?'#fff':hsx(h0+i*(MYA[id]?4:40),95,72);const r=1.6+Math.abs(Math.sin(a*1.3))*1.8;g.beginPath();g.moveTo(x,y-r*2);g.lineTo(x+r*.6,y-r*.6);g.lineTo(x+r*2,y);g.lineTo(x+r*.6,y+r*.6);g.lineTo(x,y+r*2);g.lineTo(x-r*.6,y+r*.6);g.lineTo(x-r*2,y);g.lineTo(x-r*.6,y-r*.6);g.closePath();g.fill()}g.restore()}
function drawW0(g,id,L,t){const w=WP[id],c=w.c,rc=w.col,ty=w.t,ra=RKM[w.r],gold='#e6b93e';t=t||0;g.save();g.lineCap='round';g.lineJoin='round';
 if(ra>=3){g.shadowColor=rc;g.shadowBlur=8+ra*4}
 if(WNEW[id]){g.shadowBlur=ra>=3?4:0;WNEW[id](g,L,t,{c:c,rc:rc,ra:ra});g.restore();return}
 const wrap=(x0,x1,col)=>{g.fillStyle=vgr(g,-3.6,3.6,shade(col,.3),shade(col,-.4));g.beginPath();g.roundRect(x0,-3.6,x1-x0,7.2,3);g.fill();g.strokeStyle=shade(col,-.55);g.lineWidth=1.1;for(let x=x0+2;x<x1-1;x+=3.4){g.beginPath();g.moveTo(x,-3.6);g.lineTo(x+2.2,3.6);g.stroke()}g.strokeStyle='#ffffff38';g.lineWidth=.8;g.beginPath();g.moveTo(x0+1,-2);g.lineTo(x1-1,-2);g.stroke()};
 const guard=(x,h,col,fancy)=>{g.fillStyle=metal(g,-h,h,col);g.beginPath();if(fancy){g.moveTo(x-3,-4);g.quadraticCurveTo(x-9,-h*.6,x-4,-h);g.lineTo(x+2,-h*.55);g.lineTo(x+4,-4);g.lineTo(x+4,4);g.lineTo(x+2,h*.55);g.lineTo(x-4,h);g.quadraticCurveTo(x-9,h*.6,x-3,4)}else{g.roundRect(x-3.5,-h,8,h*2,3)}g.closePath();g.fill();g.strokeStyle='#0007';g.lineWidth=1;g.stroke();g.fillStyle='#fff6';g.fillRect(x-1.5,-h*.7,1.4,h*1.4)};
 const pommel=(x,col,gc)=>{ell(g,x,0,4.6,4.6,metal(g,-5,5,col));g.strokeStyle='#0006';g.lineWidth=1;g.stroke();if(ra>=2)gem(g,x,0,2.4,gc||rc)};
 const blade=(x0,len,wd,tip,o)=>{o=o||{};const q=metal(g,-wd,wd,c);g.fillStyle=q;g.beginPath();g.moveTo(x0,-wd);g.lineTo(x0+len,-wd*.82);g.lineTo(x0+len+tip,0);g.lineTo(x0+len,wd*.82);g.lineTo(x0,wd);g.closePath();g.fill();g.save();g.clip();
  g.fillStyle='#0000002a';g.beginPath();g.moveTo(x0,0);g.lineTo(x0+len+tip,0);g.lineTo(x0+len,wd);g.lineTo(x0,wd);g.fill();
  g.fillStyle=shade(c,-.5)+'aa';g.fillRect(x0+4,-wd*.22,len*.86,wd*.44);g.fillStyle='#ffffff77';g.fillRect(x0+4,-wd*.22,len*.86,.9);
  g.strokeStyle='#ffffffaa';g.lineWidth=1.1;g.beginPath();g.moveTo(x0,-wd+1);g.lineTo(x0+len,-wd*.82+1);g.lineTo(x0+len+tip,0);g.stroke();
  g.strokeStyle='#ffffff30';g.lineWidth=1;const sp=(t*40)%(len+30)-15;g.beginPath();g.moveTo(x0+sp,-wd);g.lineTo(x0+sp-8,wd);g.stroke();if(o.fx)o.fx(x0,len,wd);g.restore();g.strokeStyle='#000a';g.lineWidth=1.1;g.beginPath();g.moveTo(x0,-wd);g.lineTo(x0+len,-wd*.82);g.lineTo(x0+len+tip,0);g.lineTo(x0+len,wd*.82);g.lineTo(x0,wd);g.closePath();g.stroke()};
 if(ty==='sword'||ty==='dagger'){const dg=ty==='dagger',len=L*(dg?.44:.76),x0=L*.13,wd=dg?4.8:5.8,fancy=ra>=2||id==='steel'||id==='frost';
  const fx=(a,l,d)=>{
   if(id==='rusty'){for(let i=0;i<9;i++){g.fillStyle=`rgba(${110+rnd(i)*40|0},${50+rnd(i+9)*30|0},20,.7)`;g.fillRect(a+4+rnd(i+2)*l*.8,-d+rnd(i+5)*d*1.6,3+rnd(i+7)*5,2+rnd(i+3)*3)}g.fillStyle='#0009';for(let i=0;i<4;i++)poly(g,[a+8+i*l*.2,d*.82,a+10+i*l*.2,d*.2,a+12+i*l*.2,d*.82],'#0000')}
   if(id==='frost'||id==='moon'){g.fillStyle='#ffffffdd';for(let i=0;i<5;i++)poly(g,[a+8+i*l*.18,-1.6,a+11+i*l*.18,0,a+8+i*l*.18,1.6,a+5+i*l*.18,0],'#fff');glow(g,a+l*.6,0,l*.5,id==='frost'?'#7fd8ff55':'#c8d0ff55')}
   if(id==='moon'){g.strokeStyle='#fff';g.lineWidth=1.4;g.beginPath();g.arc(a+l*.3,0,4.4,-1.2,1.2);g.stroke()}
   if(id==='sun'){glow(g,a+l*.5,0,l*.6,'#fff2a066');g.strokeStyle='#fff';g.lineWidth=1.4;for(let i=0;i<5;i++){const ang=-1+i*.5;g.beginPath();g.moveTo(a+8,0);g.lineTo(a+8+Math.cos(ang)*8,Math.sin(ang)*8);g.stroke()}}
   if(id==='king'){g.fillStyle=gold;g.fillRect(a+6,-1.4,l*.62,2.8);for(let i=0;i<6;i++)poly(g,[a+8+i*l*.1,-d,a+12+i*l*.1,-d*.3,a+4+i*l*.1,-d*.3],'#ffd76a')}
   if(id==='venom'){g.strokeStyle='#2a6a10';g.lineWidth=1.4;g.beginPath();g.moveTo(a+3,0);for(let i=1;i<=8;i++)g.lineTo(a+3+i*l*.11,(i%2?-1:1)*d*.5);g.stroke();g.fillStyle='#9aff5fcc';ell(g,a+l*.9,d*.9+1+Math.sin(t*5)*.8,1.6,2.6,'#9aff5f')}
   if(id==='nightfang'){glow(g,a+l*.5,0,l*.5,'#9a6bff55');g.strokeStyle='#e8d0ff';g.lineWidth=1.1;g.beginPath();g.moveTo(a+4,0);g.lineTo(a+l,0);g.stroke()}
   if(id==='stiletto'||id==='dagger'){g.strokeStyle='#0004';g.lineWidth=1;g.beginPath();g.moveTo(a+3,0);g.lineTo(a+l,0);g.stroke()}
   if(id==='shiv'){for(let i=0;i<5;i++){g.fillStyle='#4a3a2a88';g.fillRect(a+3+rnd(i)*l*.8,-d+rnd(i+4)*d*1.4,3,2)}}};
  wrap(-L*.15,x0,id==='king'?'#6a4a10':'#4a2c18');blade(x0,len,wd,L*.14,{fx});guard(x0,dg?9:13,id==='rusty'?'#7a6a40':id==='shiv'?'#6a6a70':gold,fancy);pommel(-L*.17,id==='rusty'?'#7a6a40':gold);
  if(id==='king'){poly(g,[x0-8,-12,x0-4,-19,x0,-13,x0+4,-19,x0+8,-12],'#ffd76a','#8a5a10',1)}}
 else if(ty==='katana'){const len=L*.78,x0=L*.12,wd=4.4,cv=L*.09;wrap(-L*.16,x0,'#2a2038');for(let i=0;i<5;i++){g.fillStyle=id==='umbra'?'#b06bff':'#e8d8b0';g.beginPath();g.moveTo(-L*.15+i*L*.05,-3.6);g.lineTo(-L*.12+i*L*.05,0);g.lineTo(-L*.15+i*L*.05,3.6);g.lineTo(-L*.17+i*L*.05,0);g.fill()}
  g.fillStyle=metal(g,-wd,wd,c);g.beginPath();g.moveTo(x0,-wd*.9);g.quadraticCurveTo(x0+len*.55,-wd*1.1-cv*.6,x0+len+L*.07,-cv*1.4);g.quadraticCurveTo(x0+len*.6,wd*.5-cv*.5,x0,wd*.9);g.closePath();g.fill();g.strokeStyle='#000a';g.lineWidth=1.1;g.stroke();
  g.save();g.clip();g.strokeStyle='#ffffffc0';g.lineWidth=1.1;g.beginPath();g.moveTo(x0,wd*.55);g.quadraticCurveTo(x0+len*.55,-wd*.1-cv*.4,x0+len+L*.05,-cv*1.3);g.stroke();g.strokeStyle='#0000004a';g.lineWidth=1.6;g.beginPath();g.moveTo(x0+4,-wd*.3);g.quadraticCurveTo(x0+len*.55,-wd*.6-cv*.5,x0+len*.95,-cv*1.2);g.stroke();
  if(id==='bloodthorn'){g.fillStyle='#ff3b5c88';for(let i=0;i<6;i++)poly(g,[x0+10+i*len*.13,-wd*.5-cv*.1*i,x0+14+i*len*.13,-wd*1.4-cv*.1*i,x0+18+i*len*.13,-wd*.5-cv*.1*i],'#ff3b5c88');glow(g,x0+len*.6,-cv,len*.5,'#ff3b5c44')}
  if(id==='umbra'){glow(g,x0+len*.6,-cv*.6,len*.55,'#b06bff66');g.fillStyle='#fff';for(let i=0;i<4;i++)g.fillRect(x0+8+i*len*.2,-1+(-cv*.3*i),2.2,2)}
  g.restore();g.fillStyle=metal(g,-9,9,gold);g.beginPath();g.ellipse(x0,0,3.4,9.5,0,0,TAU);g.fill();g.strokeStyle='#0007';g.lineWidth=1;g.stroke();if(ra>=2)gem(g,-L*.19,0,2.2,rc)}
 else if(ty==='mace'){wrap(-L*.15,L*.64,'#4a2c18');rivet(g,L*.2,0,1.8,c);rivet(g,L*.4,0,1.8,c);const cx=L*.78,r=L*.19;g.fillStyle=rgr(g,cx-r*.35,-r*.35,r*.1,r*1.1,shade(c,.55),shade(c,-.55));g.beginPath();g.arc(cx,0,r,0,TAU);g.fill();g.strokeStyle='#000a';g.lineWidth=1.3;g.stroke();
  for(let i=0;i<10;i++){const a=i*TAU/10+.2,b=r*.9;poly(g,[cx+Math.cos(a-.2)*b,Math.sin(a-.2)*b,cx+Math.cos(a)*(r+L*.13),Math.sin(a)*(r+L*.13),cx+Math.cos(a+.2)*b,Math.sin(a+.2)*b],metal(g,-r,r,c),'#000a',1)}
  g.strokeStyle='#ffffff55';g.lineWidth=1.2;g.beginPath();g.arc(cx,0,r*.7,3.6,4.8);g.stroke();g.strokeStyle=rc;g.lineWidth=2;g.beginPath();g.arc(cx,0,r*.35,0,TAU);g.stroke()}
 else if(ty==='axe'){wrap(-L*.15,L*.92,'#5a3a20');g.fillStyle='#ffffff20';g.fillRect(-L*.1,-3,L*.9,1.2);const bx=L*.6;
  g.fillStyle=metal(g,-L*.3,L*.3,c);g.beginPath();g.moveTo(bx,-5);g.quadraticCurveTo(bx+L*.06,-L*.36,bx+L*.34,-L*.32);g.quadraticCurveTo(bx+L*.2,-L*.06,bx+L*.36,0);g.quadraticCurveTo(bx+L*.2,L*.06,bx+L*.34,L*.32);g.quadraticCurveTo(bx+L*.06,L*.36,bx,5);g.closePath();g.fill();g.strokeStyle='#000b';g.lineWidth=1.4;g.stroke();
  g.save();g.clip();g.strokeStyle='#ffffffbb';g.lineWidth=1.6;g.beginPath();g.moveTo(bx+L*.34,-L*.32);g.quadraticCurveTo(bx+L*.2,-L*.06,bx+L*.36,0);g.quadraticCurveTo(bx+L*.2,L*.06,bx+L*.34,L*.32);g.stroke();g.strokeStyle='#0004';g.lineWidth=1.2;g.beginPath();g.moveTo(bx+8,-L*.2);g.quadraticCurveTo(bx+L*.16,0,bx+8,L*.2);g.stroke();
  if(id==='ember'){glow(g,bx+L*.2,0,L*.36,'#ff7a1a88');g.strokeStyle='#ffd05a';g.lineWidth=1.6;g.beginPath();g.moveTo(bx+8,-L*.12);g.lineTo(bx+L*.16,-L*.02);g.lineTo(bx+9,L*.02);g.lineTo(bx+L*.2,L*.14);g.stroke()}g.restore();
  g.fillStyle=metal(g,-10,10,'#7a7e88');g.beginPath();g.roundRect(bx-6,-8,8,16,2);g.fill();rivet(g,bx-2,-4,1.4,'#9aa');rivet(g,bx-2,4,1.4,'#9aa');poly(g,[L*.98,-3,L*1.06,0,L*.98,3],metal(g,-3,3,c))}
 else if(ty==='spear'){wrap(-L*.22,L*.74,'#5a3a20');g.fillStyle=vgr(g,-2.6,2.6,'#8a6a3a','#4a3018');g.fillRect(L*.5,-2.6,L*.3,5.2);
  const sx=L*.76;g.fillStyle=metal(g,-11,11,c);g.beginPath();g.moveTo(sx,0);g.quadraticCurveTo(sx+L*.08,-11,sx+L*.4,0);g.quadraticCurveTo(sx+L*.08,11,sx,0);g.fill();g.strokeStyle='#000a';g.lineWidth=1.2;g.stroke();g.strokeStyle='#ffffffaa';g.lineWidth=1.2;g.beginPath();g.moveTo(sx+3,0);g.lineTo(sx+L*.36,0);g.stroke();
  g.fillStyle=metal(g,-7,7,gold);g.beginPath();g.moveTo(sx-4,-4);g.lineTo(sx+3,-8);g.lineTo(sx+3,8);g.lineTo(sx-4,4);g.closePath();g.fill();g.strokeStyle='#0006';g.stroke();
  if(id==='lance'){poly(g,[sx-8,-4,sx-30,-14+Math.sin(t*4)*2,sx-26,0,sx-30,12+Math.sin(t*4+1)*2,sx-8,4],'#b3243d','#5a0a1a',1)}
  if(id==='storm'){glow(g,sx+L*.2,0,L*.5,'#ffe36a77');g.strokeStyle='#fff';g.lineWidth=1.8;g.beginPath();g.moveTo(sx+4,-5);g.lineTo(sx+12,-1);g.lineTo(sx+8,2);g.lineTo(sx+L*.3,5);g.stroke();for(let i=0;i<3;i++){const a=t*6+i*2;g.strokeStyle='#ffe36acc';g.lineWidth=1.2;g.beginPath();g.moveTo(sx+L*.2,0);g.lineTo(sx+L*.2+Math.cos(a)*14,Math.sin(a)*14);g.stroke()}}}
 else if(ty==='scythe'){wrap(-L*.15,L*.95,'#3a2a48');g.fillStyle='#ffffff20';g.fillRect(-L*.1,-3,L,1);const cx=L*.7,cy=-L*.08;g.save();g.scale(1,-1);
  g.fillStyle=metal(g,-L*.4,0,c);g.beginPath();g.moveTo(L*.86,-2);g.bezierCurveTo(L*.86,-L*.5,L*.5,-L*.66,L*.16,-L*.36);g.bezierCurveTo(L*.5,-L*.48,L*.74,-L*.34,L*.9,-L*.06);g.closePath();g.fill();g.strokeStyle='#000a';g.lineWidth=1.3;g.stroke();g.strokeStyle='#ffffffbb';g.lineWidth=1.4;g.beginPath();g.moveTo(L*.16,-L*.36);g.bezierCurveTo(L*.5,-L*.66,L*.86,-L*.5,L*.86,-2);g.stroke();
  glow(g,L*.5,-L*.44,L*.36,c+'66');g.fillStyle='#fff';for(let i=0;i<4;i++){const u=(t*.6+i/4)%1;g.globalAlpha=1-u;g.fillRect(L*.2+i*L*.16,-L*.4-u*10,2,2)}g.globalAlpha=1;gem(g,L*.9,0,3,rc);g.restore()}
 else if(ty==='bow'){const h=L*.56,bw=L*.22;g.strokeStyle='#0008';g.lineWidth=6.6;g.beginPath();g.moveTo(-h,-bw);g.quadraticCurveTo(-h*.35,bw*.9,0,bw*.5);g.quadraticCurveTo(h*.35,bw*.9,h,-bw);g.stroke();
  g.strokeStyle=shade(c,-.25);g.lineWidth=5.4;g.stroke();g.strokeStyle=c;g.lineWidth=3.4;g.stroke();g.strokeStyle=shade(c,.5);g.lineWidth=1;g.beginPath();g.moveTo(-h,-bw+1);g.quadraticCurveTo(-h*.35,bw*.9-1.5,0,bw*.5-1.5);g.quadraticCurveTo(h*.35,bw*.9-1.5,h,-bw+1);g.stroke();
  wrap(-6,6,'#3a2010');for(const s of[-1,1]){poly(g,[s*h,-bw,s*h+s*3,-bw-4,s*h+s*4,-bw+2],gold)}
  if(id==='frostbow'){g.fillStyle='#fff';for(const s of[-1,1])for(let i=1;i<4;i++)poly(g,[s*h*i*.28,-bw*.3*i,s*h*i*.28+2,-bw*.3*i-5,s*h*i*.28+4,-bw*.3*i],'#dff6ff')}
  if(id==='phoenix'){glow(g,0,0,L*.5,'#ff8a3a66');for(const s of[-1,1])poly(g,[s*h*.4,-bw*.2,s*h*.8,-bw*1.6,s*h*.7,-bw*.8],'#ffb84a','#c8481a',1)}
  if(id==='skyfall'){glow(g,0,0,L*.6,'#ffe36a55');for(const s of[-1,1])poly(g,[s*h*.4,-bw*.2,s*h*.9,-bw*1.9,s*h*.6,-bw*.7],'#fff8c0','#e8b02e',1)}
  if(id==='serpent'){g.strokeStyle='#2a6a10';g.lineWidth=1.4;g.beginPath();for(let i=0;i<=10;i++){const u=i/10-.5;g.lineTo(u*h*1.8,-bw*.55+(i%2?1:-1)*1.6+Math.abs(u)*bw*1.2)}g.stroke()}
  g.strokeStyle='#f4ecd8';g.lineWidth=1.1;g.beginPath();g.moveTo(-h,-bw);g.lineTo(-L*.02,-bw*.35-L*.08);g.lineTo(h,-bw);g.stroke();
  g.strokeStyle='#d8c8a0';g.lineWidth=2;g.beginPath();g.moveTo(-L*.02,-bw*.35-L*.08);g.lineTo(L*.02+bw*.4,bw*.35);g.stroke();poly(g,[L*.02+bw*.4,bw*.35-3,L*.02+bw*.4+8,bw*.35,L*.02+bw*.4,bw*.35+3],'#e8eefc')}
 else if(ty==='staff'){const top=L*1.04;g.fillStyle=vgr(g,-3.4,3.4,shade(c,.25),shade(c,-.4));g.beginPath();g.roundRect(-L*.34,-3.4,top+L*.3,6.8,3);g.fill();g.strokeStyle=shade(c,-.5);g.lineWidth=1;for(let i=0;i<7;i++){g.beginPath();g.moveTo(-L*.3+i*top*.16,-3.4);g.lineTo(-L*.3+i*top*.16+3,3.4);g.stroke()}grain(g,-L*.3,-2.6,top+L*.2,5,'#0006',40,3);wrap(-L*.06,L*.16,'#2a1a30');
  g.strokeStyle=metal(g,-10,10,gold);g.lineWidth=4;g.beginPath();g.moveTo(top-6,0);g.quadraticCurveTo(top+L*.05,-L*.16,top+L*.26,-L*.11);g.moveTo(top-6,0);g.quadraticCurveTo(top+L*.05,L*.16,top+L*.26,L*.11);g.stroke();
  const pu=1+.12*Math.sin(t*4),ox=top+L*.14;glow(g,ox,0,L*.5*pu,c+'aa');g.fillStyle=rgr(g,ox-3,-3,1,L*.13,'#ffffff',c);g.beginPath();g.arc(ox,0,L*.115,0,TAU);g.fill();g.strokeStyle='#ffffffaa';g.lineWidth=1;g.stroke();ell(g,ox-3,-3,L*.04,L*.03,'#fffd');
  if(id==='emberstaff'||id==='tempest'||id==='crystal'){for(let i=0;i<5;i++){const a=t*2+i*1.26;g.fillStyle='#fff';g.globalAlpha=.8;g.fillRect(ox+Math.cos(a)*L*.2,Math.sin(a)*L*.2,2.4,2.4)}g.globalAlpha=1}
  if(id==='crystal')poly(g,[ox+L*.02,-L*.18,ox+L*.1,-L*.02,ox+L*.02,L*.1,ox-L*.06,-L*.02],'#0000','#fff8',1)}
 else{ /* wand */ const len=L*.68;g.fillStyle=vgr(g,-3,3,shade(c,.35),shade(c,-.45));g.beginPath();g.roundRect(-L*.14,-2.8,len+L*.14,5.6,2.6);g.fill();g.strokeStyle='#0007';g.lineWidth=1;g.stroke();wrap(-L*.12,L*.1,'#2a1a30');
  for(let i=0;i<4;i++){g.strokeStyle=rc;g.lineWidth=1.2;g.beginPath();g.arc(L*.22+i*len*.16,0,3.6,-1.2,1.2);g.stroke()}
  const ox=len+L*.08,pu=1+.15*Math.sin(t*5);glow(g,ox,0,L*.42*pu,c+'aa');poly(g,[ox-L*.06,0,ox,-L*.1,ox+L*.13,0,ox,L*.1],rgr(g,ox,0,1,L*.13,'#fff',c),'#fff9',1);
  for(let i=0;i<5;i++){const u=(t*.9+i/5)%1;g.globalAlpha=1-u;g.fillStyle=i%2?'#fff':rc;g.fillRect(ox+u*L*.3+Math.sin(i*3)*3,Math.sin(i*5+t*3)*L*.12*u,2.2,2.2)}g.globalAlpha=1}
 g.restore()}

function coin(g,x,y,r){g.save();g.translate(x,y);ell(g,0,r*.15,r,r,'#7a4a0a');ell(g,0,0,r,r,rgr(g,-r*.3,-r*.3,r*.1,r*1.1,'#fff3a0','#d8961c'));g.strokeStyle='#8a5a10';g.lineWidth=Math.max(1,r*.16);g.beginPath();g.arc(0,0,r*.66,0,TAU);g.stroke();g.fillStyle='#b8780e';g.fillRect(-r*.1,-r*.4,r*.2,r*.8);g.restore()}
