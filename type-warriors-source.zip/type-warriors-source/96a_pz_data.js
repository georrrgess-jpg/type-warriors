/* ===== 9.4 THE CROOKED CUE (pool mode): data, save normaliser (96a) =====
   Code prefix `pz`, save P.pz, casino id 'pz'. See POOL_PLAN.md. Everything here is data; art is 96e-96h, rules 96b-96d. */
const PZ_O='#12081f';
/* the regulars. ai: aim sigma (degrees), power noise, position weight, safety threshold, safety tries, look-ahead width,
   style knobs: over/soft = power multipliers, bank = bank-shot score bias, spin = tries side spin, brk = break sigma */
const PZ_REG={
 gloop:{id:'gloop',n:'Gloop',k:'The Spilled Drink',c:'#8affb4',lvl:1,race:1,stakes:[50,100,200],mult:1.35,floor:1.15,
  ai:{sig:2.6,psig:.14,pos:0,safe:0,sTry:0,look:3,over:1.3,brk:2.6},
  house:{},houseTxt:'No house rule: plain 8-ball, nice and simple.',cue:'slime',skin:'#9affa0',
  voice:{f:330,t:'sine',w:.18},quirk:'Wobbles when excited and sips a glowing soda.',
  lines:{hi:["Ooh, a new friend! I hit 'em HARD.","Rack 'em! Blub!"],pot:['SPLAT! In it goes!','Did you see that?!'],miss:['Whoops, too much juice.','Aw, blub.'],
   you:["Wow, you're sticky-good!"],foul:["Hee! Your turn's mine now!"],win:['Best. Night. Ever!'],lose:["You beat me fair and square... wanna play again?"],taunted:['M-my wobble!']},
  taunts:['stay solid, jelly','all wobble no aim','you leak','drip drip']},
 moldwick:{id:'moldwick',n:'Granny Moldwick',k:'Slow and Steady',c:'#ff9ab0',lvl:2,race:1,stakes:[100,250,500],mult:1.45,floor:1.25,
  ai:{sig:2.9,psig:.10,pos:.1,safe:.15,sTry:12,look:4,soft:.8,brk:1.9},
  house:{spores:1},houseTxt:'Spore cloud: tiny spores drift over the table (just for looks).',cue:'mycelium',skin:'#f2dcc0',
  voice:{f:520,t:'triangle',w:.35},quirk:'Puffs spores from her cap and pushes up her spectacles.',
  lines:{hi:["Patience, dearie. The pockets aren't going anywhere."],pot:['Slow and steady.','Mm-hm.'],miss:["My eyes aren't what they were."],
   you:['Oh, lovely stroke, dear.'],foul:['Tsk. Rushing again.'],win:['Spore and done.'],lose:['You remind me of my late husband. He was also good.'],taunted:['Well I NEVER.']},
  taunts:['mold is old','time to retire','hurry up granny','spore loser']},
 grizzle:{id:'grizzle',n:'Grizzle',k:'The Breaker',c:'#c8d870',lvl:3,race:2,stakes:[200,500,1000],mult:1.5,floor:1.3,
  ai:{sig:1.96,psig:.12,pos:.1,safe:0,sTry:0,look:4,brk:.8},
  house:{winnerBreaks:1},houseTxt:'Winner breaks: whoever won the last rack breaks the next.',cue:'smasher',skin:'#8a9a46',
  voice:{f:110,t:'sawtooth',w:0},quirk:'Cracks his knuckles; his one eye darts about.',
  lines:{hi:['ONE EYE. ONE SHOT. ONE BIG BREAK.'],pot:['SMASH!','HA! Eye see you.'],miss:['...the table moved.'],
   you:['Hrrm. Lucky.'],foul:['HA HA! Bad shot, tiny.'],win:['GRIZZLE WINS!'],lose:['Grr... rematch. NOW.'],taunted:['WHO SAID THAT.']},
  taunts:['eye spy a miss','blink and miss','all brawn','keep an eye out']},
 vesper:{id:'vesper',n:'Vesper Nightwing',k:'Queen of Safeties',c:'#c8a0ff',lvl:4,race:2,stakes:[300,500,1000,2000],mult:1.75,floor:1.4,
  ai:{sig:1.73,psig:.08,pos:.25,safe:.40,sTry:24,look:5,brk:1.25},
  house:{dim:1},houseTxt:'Lights low: the table edges are darker.',cue:'nightwing',skin:'#5a3a7a',
  voice:{f:700,t:'sine',w:.1},quirk:'Ruffles her wings and sips something red.',
  lines:{hi:['Oh, a guest. How delicious.',"Careful, darling... that corner bites."],pot:['Darling, please.','Effortless.'],miss:['The light was in my eyes.'],
   you:['Mm. Not bad... for a mortal.'],foul:['How dreadful for you.'],win:["Do come back. I'll be hungry."],lose:["...beginner's luck."],taunted:['Hmph!']},
  taunts:['nice try, fang face','batty shot','sucks to be you','go hang upside down']},
 barnacle:{id:'barnacle',n:"Cap'n Barnacle",k:'Banks and Kicks',c:'#ff8a6a',lvl:5,race:2,stakes:[500,1000,2000,3000],mult:2.2,floor:1.6,
  ai:{sig:1.52,psig:.07,pos:.3,safe:.3,sTry:20,look:5,bank:1.4,brk:1.0},
  house:{bank8:1},houseTxt:'Bank the 8: the 8 must kiss a cushion before it drops, or it is spotted and that is a foul.',cue:'harpoon',skin:'#e85a3a',
  voice:{f:260,t:'square',w:.05},quirk:'Clacks his claws; his eye stalks bob.',
  lines:{hi:['Off the rail, into the hold! Har!'],pot:['Bank it, me hearties!','Har har!'],miss:['Blasted tide.'],
   you:['Shiver me shells, fine shot!'],foul:['Walk the plank, landlubber!'],win:['The treasure be mine!'],lose:["Ye've sunk me ship."],taunted:["Me claws be shakin'!"]},
  taunts:['crabby aim','shell shocked','sideways again','abandon ship']},
 hootsworth:{id:'hootsworth',n:'Professor Hootsworth',k:'Position Master',c:'#ffd45a',lvl:6,race:3,stakes:[1000,2000,3000,4000],mult:3,floor:1.8,
  ai:{sig:1.15,psig:.05,pos:.6,safe:.3,sTry:24,look:6,brk:.75},
  house:{shortGuide:1},houseTxt:'Short guide only: no line to the object ball.',cue:'quill',skin:'#a8784a',
  voice:{f:440,t:'triangle',w:.2},quirk:'Swivels his head and scribbles notes.',
  lines:{hi:['Elementary geometry, my young friend.'],pot:['Precisely as calculated.'],miss:['A rounding error.'],
   you:['Hoo! Most commendable.'],foul:['A fundamental misunderstanding.'],win:['Class dismissed.'],lose:['I shall revise my notes.'],taunted:['That is... most irregular.']},
  taunts:['who gives a hoot','check your math','owl be winning','pop quiz, prof']},
 mortimer:{id:'mortimer',n:'Mortimer Bonechalk',k:'Champion of the Crooked Cue',c:'#7ad8ff',lvl:7,race:3,stakes:[2000,3000,4000,5000],mult:3.5,floor:2.2,
  ai:{sig:.95,psig:.03,pos:.8,safe:.3,sTry:28,look:8,spin:1,brk:.4},
  house:{clock:25},houseTxt:'25-second shot clock.',cue:'scepter',skin:'#e8e4d8',
  voice:{f:180,t:'sine',w:.05,echo:1},quirk:'Ghost flames rise from his crown; he floats.',
  lines:{hi:['I have played this game for four hundred years.'],pot:['Inevitable.','As it was foretold.'],miss:['...interesting. You will not see that twice.'],
   you:['Ah. A spark of talent.'],foul:['Death and fouls are certain.'],win:['Another soul for the ledger.'],lose:['Impossible... I demand a rematch in a century.'],taunted:['You DARE?']},
  taunts:['bone dry aim','rattle your bones','skull and bones','dead on arrival']},
 shade:{id:'shade',n:'Slick Shade',k:'The Hustler',c:'#ffe066',lvl:0,race:2,stakes:[],mult:2.2,floor:1.8,hustler:1,
  ai:{sig:1.52,psig:.07,pos:.3,safe:.3,sTry:20,look:5,brk:1.0},
  house:{hustle:1},houseTxt:'The hustle: he plays rack one badly on purpose.',cue:'shadow',skin:'#100818',
  voice:{f:240,t:'triangle',w:.5,whisper:1},quirk:'Smoke ripples at his edges and his grin keeps growing.',
  lines:{hi:['Friendly game? Small stakes... for now.'],pot:['Funny how that works.'],miss:['Oh, would you look at that.'],
   you:["Well, well. You've got hands."],foul:["That's gonna cost ya."],offer:['Let it ride? Race to three. Pays better.'],win:['Pleasure doing business.'],lose:["...you're good. I'll be back."],taunted:['Easy, pal.']},
  taunts:['shady business','lights on, shade','not so slick','fade away']}
};
const PZ_ORDER=['gloop','moldwick','grizzle','vesper','barnacle','hootsworth','mortimer'];
/* cues: a (tip end), b (shaft), c (butt dark), d (butt light), wrap. need: how it is earned. price: shop cost in gold */
const PZ_CUES=[
 {id:'house',n:'House Cue',a:'#e8c890',b:'#c89a5a',c:'#5a1a1a',d:'#8a2a2a',wrap:'#2a1a3a',how:'Free',price:0},
 {id:'maple',n:'Maple Classic',a:'#f4e2b8',b:'#e0c07a',c:'#6a4a22',d:'#a87a3a',wrap:'#3a2a14',how:'Cue Rack: 1,500',price:1500},
 {id:'ember',n:'Ember Cue',a:'#ffd9a0',b:'#e88a3a',c:'#5a1208',d:'#ff6a2a',wrap:'#2a0a04',how:'Cue Rack: 4,000',price:4000,glow:'#ff8a3a'},
 {id:'frost',n:'Frost Cue',a:'#e8f8ff',b:'#9fd8f0',c:'#1a3a5a',d:'#6ac8ff',wrap:'#0a1a2a',how:'Cue Rack: 4,000',price:4000,glow:'#9fe8ff'},
 {id:'dragonbone',n:'Dragonbone',a:'#fff4d8',b:'#e8d8a8',c:'#6a1a10',d:'#d8a03a',wrap:'#2a0a04',how:'Cue Rack: 12,000',price:12000,glow:'#ffd45a'},
 {id:'slime',n:'Slime Stick',a:'#c8ffc8',b:'#7ae07a',c:'#1a5a2a',d:'#8affb4',wrap:'#0a2a14',how:'Beat Gloop 3 times',beat:'gloop',glow:'#8affb4'},
 {id:'mycelium',n:'Mycelium Cue',a:'#f8e8f0',b:'#e8b8c8',c:'#7a2a3a',d:'#ff9ab0',wrap:'#3a1a24',how:'Beat Granny Moldwick 3 times',beat:'moldwick'},
 {id:'smasher',n:'Smasher',a:'#c8c8d0',b:'#8a8a96',c:'#2a2a34',d:'#c8d870',wrap:'#14141a',how:'Beat Grizzle 3 times',beat:'grizzle'},
 {id:'nightwing',n:'Nightwing Cue',a:'#d8c0f0',b:'#6a4a8a',c:'#1a0a2a',d:'#c8a0ff',wrap:'#0a0414',how:'Beat Vesper 3 times',beat:'vesper',glow:'#c8a0ff'},
 {id:'harpoon',n:'Driftwood Harpoon',a:'#e8dcc0',b:'#b8a078',c:'#3a2a14',d:'#ff8a6a',wrap:'#1a1208',how:"Beat Cap'n Barnacle 3 times",beat:'barnacle'},
 {id:'quill',n:"Scholar's Quill",a:'#fff8e8',b:'#e8d8b0',c:'#4a2a0a',d:'#ffd45a',wrap:'#1a0e04',how:'Beat Professor Hootsworth 3 times',beat:'hootsworth'},
 {id:'scepter',n:'Bonechalk Scepter',a:'#f4f0e6',b:'#c8d8e8',c:'#0a1a3a',d:'#7ad8ff',wrap:'#06101e',how:'Beat Mortimer 3 times',beat:'mortimer',glow:'#7ad8ff'},
 {id:'shadow',n:'Shadow Cue',a:'#4a3a5a',b:'#2a2038',c:'#0a0614',d:'#ffe066',wrap:'#06030c',how:'Beat Slick Shade 3 times',beatShade:3,glow:'#ffe066'}
];
const PZ_FELT=[
 {id:'tavern',n:'Tavern Green',a:'#2e8f5e',b:'#1b6a45',c:'#0f4a30',how:'Free'},
 {id:'crimson',n:'Crimson',a:'#8a2030',b:'#5a1220',c:'#3a0a14',how:'Beat Grizzle',beat:'grizzle'},
 {id:'royal',n:'Royal Blue',a:'#2a5aa8',b:'#183a78',c:'#0e2650',how:'Beat Vesper',beat:'vesper'},
 {id:'violet',n:'Midnight Violet',a:'#5a3a9a',b:'#3a2478',c:'#241650',how:'Beat Professor Hootsworth',beat:'hootsworth'},
 {id:'gold',n:'Champion Gold',a:'#b08a2a',b:'#80601a',c:'#583e0e',how:'Beat Mortimer',beat:'mortimer'}
];
const PZ_BALLS=[
 {id:'classic',n:'Classic',how:'Free',price:0},
 {id:'gem',n:'Gemstone',how:'Cue Rack: 6,000',price:6000},
 {id:'moon',n:'Moonstone',how:'Beat Slick Shade 3 times',beatShade:3}
];
/* trick-shot, daily and money constants */
const PZ_DAILY=20,PZ_LIVE_V=1;
const pzDay=()=>typeof wcDay==='function'?wcDay():new Date().toISOString().slice(0,10);
/* is a stored live match safe to resume? every number finite, every list the right shape */
function pzLiveOk(L){const f=x=>typeof x==='number'&&isFinite(x);try{if(!L||typeof L!=='object'||L.v!==PZ_LIVE_V||!PZ_REG[L.opp])return false;
 if(!f(L.stake)||L.stake<0||L.stake>100000||!f(L.mult)||L.mult<0||L.mult>10||!(L.race>=1&&L.race<=5)||!Array.isArray(L.score)||L.score.length!==2||!L.score.every(f)||!f(L.rack)||!f(L.seed))return false;
 if(!Array.isArray(L.B)||L.B.length!==16||!L.B.every(b=>Array.isArray(b)&&b.length===4&&b.every(f)))return false;if(L.pre)return true;
 const s=L.st;return !!s&&typeof s==='object'&&Array.isArray(s.grp)&&Array.isArray(s.visits)&&Array.isArray(s.fouls)&&f(s.turn)&&f(s.breaker)}catch(e){return false}}
/* the save, normalised by type on every access (the wcSt pattern) */
function PZS(){let Z=P.pz;if(!Z||typeof Z!=='object'||Array.isArray(Z))Z=P.pz={};
 const d={v:1,beat:{},wins:0,losses:0,racks:0,rackWins:0,pots:0,bnr:0,golden:0,banks:0,taunts:0,streak:0,best:0,day:'',dayN:0,rep:{},
  cue:'house',cues:{house:1},felt:'tavern',felts:{tavern:1},balls:'classic',ballsets:{classic:1},guide:'full',tauntsOn:true,clockOn:true,
  trick:{},shade:{day:'',beat:0,seen:0},live:null,tut:{},seen:{},proGuideBeat:0,net:0};
 for(const k in d){if(Z[k]==null||typeof Z[k]!==typeof d[k]||(Array.isArray(d[k])!==Array.isArray(Z[k])))Z[k]=JSON.parse(JSON.stringify(d[k]))}
 for(const k of['beat','rep','cues','felts','ballsets','trick','tut','seen','shade'])if(!Z[k]||typeof Z[k]!=='object'||Array.isArray(Z[k]))Z[k]=JSON.parse(JSON.stringify(d[k]));
 if(Z.day!==pzDay()){Z.day=pzDay();Z.dayN=0;Z.rep={}}
 const ok=(set,key,def)=>{if(!Z[set][Z[key]])Z[key]=def};ok('cues','cue','house');ok('felts','felt','tavern');ok('ballsets','balls','classic');
 if(!['full','short','pro'].includes(Z.guide))Z.guide='full';
 if(Z.live&&!pzLiveOk(Z.live))Z.live=null;
 return Z}
/* unlock sweep: cues, felts and ball sets earned by beating regulars (returns the new unlocks, for the results screen) */
function pzUnlockSweep(){const Z=PZS(),got=[];
 for(const c of PZ_CUES)if(!Z.cues[c.id]&&((c.beat&&(Z.beat[c.beat]||0)>=3)||(c.beatShade&&(Z.shade.beat||0)>=c.beatShade))){Z.cues[c.id]=1;got.push({t:'cue',id:c.id,n:c.n})}
 for(const f of PZ_FELT)if(!Z.felts[f.id]&&f.beat&&(Z.beat[f.beat]||0)>=1){Z.felts[f.id]=1;got.push({t:'felt',id:f.id,n:f.n})}
 for(const b of PZ_BALLS)if(!Z.ballsets[b.id]&&b.beatShade&&(Z.shade.beat||0)>=b.beatShade){Z.ballsets[b.id]=1;got.push({t:'balls',id:b.id,n:b.n})}
 return got}
/* which regular is open? gloop always; then each one after you beat the one before */
function pzOpen(id){if(id==='gloop')return true;const i=PZ_ORDER.indexOf(id);if(i<1)return false;return (PZS().beat[PZ_ORDER[i-1]]||0)>0}
/* today's pay multiplier after "they're wise to you" (-0.1 per win over the day, floor per regular) */
function pzMult(id){const R=PZ_REG[id],Z=PZS(),w=Z.rep[id]||0;return Math.max(R.floor,Math.round((R.mult-.1*w)*100)/100)}
/* a win never pays more than the casino ceiling: the multiplier shrinks to fit the stake (5,000 x 3.0 = 15,000) */
const PZ_CAP=15000;
function pzMultS(id,stake){const m=pzMult(id);return stake>0?Math.min(m,Math.floor(PZ_CAP/stake*100)/100):m}
