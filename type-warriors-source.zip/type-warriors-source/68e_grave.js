/* ===== GRAVEYARD COLLECTION (shop window) and CRATE MENU polish =====
   The Graveyard window: a haunted, animated header scene, three relic cards with living previews, a set-bonus strip and the
   twelve-relic collection. Purchases use the same prices and rules as before.
   The crate menu: chests stand on glowing pedestals, cards arrive in turn, hovering lifts a chest and cracks its lid,
   owned crates breathe, and the Graveyard banner gets drifting fog and wisps. */
/* ---------- the haunted scene painted behind the window header ---------- */
function gvScene(g,w,h,t,on){g.setTransform(1,0,0,1,0,0);
 let q=g.createLinearGradient(0,0,0,h);q.addColorStop(0,'#0c0620');q.addColorStop(.55,'#24104a');q.addColorStop(1,'#3a1440');g.fillStyle=q;g.fillRect(0,0,w,h);
 for(let i=0;i<40;i++){const x=(i*97)%w,y=(i*53)%(h*.6);g.globalAlpha=.3+.5*Math.abs(Math.sin(t*1.3+i));g.fillStyle='#fff';g.fillRect(x,y,1.6,1.6)}g.globalAlpha=1;
 /* the moon, with drifting cloud bands */
 const mx=w*.78,my=h*.32;ncGlow(g,mx,my,130,'#c8d8ff40');g.fillStyle='#e8eeff';g.beginPath();g.arc(mx,my,46,0,Math.PI*2);g.fill();g.fillStyle='#c4cce8';for(const [dx,dy,r] of[[-14,-8,9],[12,10,7],[16,-16,5],[-6,18,6]]){g.beginPath();g.arc(mx+dx,my+dy,r,0,Math.PI*2);g.fill()}
 g.fillStyle='#1a0c34cc';for(let i=0;i<3;i++){const cx=((t*14+i*260)%(w+300))-150,cy=h*(.22+i*.09);g.beginPath();g.ellipse(cx,cy,120,12,0,0,Math.PI*2);g.ellipse(cx+60,cy-8,70,10,0,0,Math.PI*2);g.fill()}
 /* distant church and hills */
 g.fillStyle='#160a2c';g.beginPath();g.moveTo(0,h*.72);g.quadraticCurveTo(w*.25,h*.5,w*.5,h*.66);g.quadraticCurveTo(w*.75,h*.8,w,h*.6);g.lineTo(w,h);g.lineTo(0,h);g.closePath();g.fill();
 const cx0=w*.6,cy0=h*.62;g.fillStyle='#0e0620';g.fillRect(cx0-30,cy0-40,60,50);g.beginPath();g.moveTo(cx0-36,cy0-40);g.lineTo(cx0,cy0-70);g.lineTo(cx0+36,cy0-40);g.fill();g.fillRect(cx0-8,cy0-110,16,50);g.beginPath();g.moveTo(cx0-12,cy0-110);g.lineTo(cx0,cy0-132);g.lineTo(cx0+12,cy0-110);g.fill();
 g.fillStyle='#ffb04a'+ncA(.55+.35*Math.sin(t*3));g.fillRect(cx0-5,cy0-26,10,14);g.fillRect(cx0-4,cy0-96,8,10);
 /* dead tree */
 g.strokeStyle='#0a0418';g.lineCap='round';const tr=(x,y,a,l,wd,d)=>{if(d>5||l<5)return;const x2=x+Math.cos(a)*l,y2=y+Math.sin(a)*l;g.lineWidth=wd;g.beginPath();g.moveTo(x,y);g.lineTo(x2,y2);g.stroke();tr(x2,y2,a-.45+Math.sin(d*3)*.1,l*.72,wd*.65,d+1);tr(x2,y2,a+.38,l*.66,wd*.6,d+1)};tr(w*.1,h,-Math.PI/2+.08,h*.32,10,0);
 /* gravestones */
 g.fillStyle='#2a1e40';g.strokeStyle='#4a3a66';g.lineWidth=2;for(const [x,s,k] of[[.26,1,0],[.36,.8,1],[.46,.95,0],[.88,.85,1],[.95,.7,0]]){g.save();g.translate(w*x,h*.94);g.scale(s,s);g.beginPath();if(k){g.rect(-5,-58,10,58);g.rect(-20,-44,40,10)}else{g.moveTo(-18,0);g.lineTo(-18,-34);g.arc(0,-34,18,Math.PI,0);g.lineTo(18,0);g.closePath()}g.fill();g.stroke();g.restore()}
 /* the jack-o-lantern and candles */
 const px=w*.18,py=h*.86,fl=.8+.2*Math.sin(t*9)+.1*Math.sin(t*23);ncGlow(g,px,py,90*fl,'#ff8a2a55');
 for(const [dx,rw] of[[-16,20],[16,20],[0,24]]){g.fillStyle=dx?'#d8641a':'#f07a22';g.beginPath();g.ellipse(px+dx,py,rw,26,0,0,Math.PI*2);g.fill();g.strokeStyle='#5a1e08';g.lineWidth=2;g.stroke()}
 g.fillStyle='#4a6a1a';g.fillRect(px-3,py-33,6,10);g.fillStyle=`rgb(255,${200+fl*40|0},80)`;for(const s of[-1,1]){g.beginPath();g.moveTo(px+s*6,py-12);g.lineTo(px+s*17,py-10);g.lineTo(px+s*11,py-1);g.closePath();g.fill()}
 g.beginPath();g.moveTo(px-18,py+5);g.lineTo(px-9,py+10);g.lineTo(px-4,py+5);g.lineTo(px+1,py+12);g.lineTo(px+6,py+5);g.lineTo(px+11,py+10);g.lineTo(px+18,py+5);g.quadraticCurveTo(px,py+24,px-18,py+5);g.fill();
 for(const [x,ht] of[[.31,26],[.33,18],[.92,22]]){const cxx=w*x,cyy=h*.95;g.fillStyle='#e8dcc0';g.fillRect(cxx-4,cyy-ht,8,ht);const f=Math.sin(t*12+x*40)*1.5;ncGlow(g,cxx,cyy-ht-6,24,'#ffb04a66');g.fillStyle='#ffd45a';g.beginPath();g.ellipse(cxx+f*.4,cyy-ht-6,3,6,0,0,Math.PI*2);g.fill()}
 /* bats */
 for(let i=0;i<4;i++){const bx=((t*40*(1+i*.2)+i*220)%(w+80))-40,by=h*(.18+i*.07)+Math.sin(t*3+i)*6,wv=Math.sin(t*14+i)*7;g.fillStyle='#07030f';g.beginPath();g.moveTo(bx,by);g.quadraticCurveTo(bx-9,by-7-wv,bx-18,by+wv*.4);g.quadraticCurveTo(bx-9,by+1,bx,by+3);g.quadraticCurveTo(bx+9,by+1,bx+18,by+wv*.4);g.quadraticCurveTo(bx+9,by-7-wv,bx,by);g.fill()}
 /* wisps that bob between the graves */
 g.save();g.globalCompositeOperation='lighter';for(let i=0;i<6;i++){const x=w*(.24+i*.12)+Math.sin(t*.7+i*2)*30,y=h*(.72+.06*Math.sin(t*1.1+i));ncGlow(g,x,y,22,'#7affc8'+ncA(.35+.25*Math.sin(t*2+i)));g.fillStyle='#d8fff0';g.beginPath();g.arc(x,y,2.6,0,Math.PI*2);g.fill()}g.restore();
 /* rolling fog */
 g.save();for(let i=0;i<5;i++){const fx=((t*18*(i%2?1:-1)+i*300)%(w+400)+w+400)%(w+400)-200,fy=h*(.86+i*.03);const fq=g.createRadialGradient(fx,fy,0,fx,fy,220);fq.addColorStop(0,'#c8b8ff22');fq.addColorStop(1,'#c8b8ff00');g.fillStyle=fq;g.fillRect(fx-220,fy-220,440,440)}g.restore();
 if(!on){g.fillStyle='#0008';g.fillRect(0,0,w,h)}}

/* ---------- the window ---------- */
function gvBuy(w){if(!hwOn())return;const pr=HW_PRICE[w];if(P.gold<pr)return;if(w==='a'&&P.ownA.hwreap||w==='w'&&P.own.hw_scythe||w==='b'&&(P.ownA.hwreap||P.own.hw_scythe))return;
 P.gold-=pr;if(w!=='w')P.ownA.hwreap=1;if(w!=='a')P.own.hw_scythe=1;save();try{beep(880,.12,'triangle',.8);setTimeout(()=>beep(1320,.2,'triangle',.7),100);setTimeout(()=>beep(1760,.3,'sine',.5),220)}catch(e){}
 const gv=$('shgv');if(gv)gv.textContent=P.gold.toLocaleString();
 const card=ov.querySelector(`.gvc[data-w="${w}"]`);if(card){card.classList.add('bought');for(let i=0;i<26;i++){const s=document.createElement('i');s.className='gvsp';s.style.cssText=`--dx:${(Math.random()-.5)*260}px;--dy:${-60-Math.random()*200}px;--c:${['#7affc8','#c86bff','#ff9a30','#fff'][i%4]};animation-delay:${Math.random()*.15}s`;card.appendChild(s);setTimeout(()=>s.remove(),1300)}}
 setTimeout(()=>{if(!$('gvwin'))return;shGrave(w==='a'?`${AR.hwreap.n} is yours. Equip it in the Armory.`:w==='w'?`${WP.hw_scythe.n} is yours. Equip it in the Armory.`:`The Reaper Bundle is yours: ${AR.hwreap.n} and ${WP.hw_scythe.n}.`);try{shPanel(false)}catch(e){}},900)}
shGrave=function(note){if(typeof note!=='string')note='';if(typeof hwShopHTML!=='function')return;const m=$('shmod');if(!m)return;const on=hwOn(),g=P.gold,ar=AR.hwreap,wp=WP.hw_scythe,oa=!!P.ownA.hwreap,ow=!!P.own.hw_scythe,save2=HW_PRICE.a+HW_PRICE.w-HW_PRICE.b;
 const btn=(w,pr,owned,part)=>{const can=on&&!owned&&!part&&g>=pr;return `<button class="gvbuy${owned?' own':''}" data-gb="${w}" ${can?'':'disabled'}>${owned?'✓ Owned':part?'Part owned':!on?'Event ended':g<pr?`<span><i class="coin"></i>${pr.toLocaleString()}</span><small>need ${(pr-g).toLocaleString()} more</small>`:`<span><i class="coin"></i>${pr.toLocaleString()}</span>`}</button>`};
 const card=(w,nm,sub,desc,prev,pr,owned,part,extra)=>`<div class="gvc${owned?' own':''}${w==='b'?' bun':''}" data-w="${w}" style="--i:${'awb'.indexOf(w)}"><div class="gvcp">${prev}<i class="gvglow"></i>${w==='b'?`<span class="gvsave">SAVE ${save2.toLocaleString()}</span>`:''}</div><b>${nm}</b><em>${sub}</em><small>${desc}</small>${extra||''}${btn(w,pr,owned,part)}</div>`;
 m.innerHTML=`<div class="shmc wide gvwin" id="gvwin"><button class="shx" aria-label="Close">×</button>
  <div class="gvhd"><canvas id="gvsc" width="1100" height="240"></canvas><div class="gvht"><div><span class="hwlt">LIMITED TIME</span><span class="gvdays">${on?hwLeft():'The graveyard sleeps'}</span></div><h3 class="hwtxt">Graveyard Collection</h3><p>${on?'Mythic Halloween relics. When the graveyard sleeps, they are gone.':'The graveyard has gone quiet. These relics are no longer sold.'}</p></div></div>
  ${note?`<div class="gvnote">${esc(note)}</div>`:''}
  <div class="gvg">${card('a',ar.n,'Mythic armor set',ar.d,`<canvas width="200" height="250" data-gv="a:hwreap"></canvas>`,HW_PRICE.a,oa,0)}
   ${card('w',wp.n,'Mythic weapon',wp.d,`<canvas width="200" height="250" data-gv="w:hw_scythe"></canvas>`,HW_PRICE.w,ow,0)}
   ${card('b','Reaper Bundle','Armor and weapon together',`Both relics for ${HW_PRICE.b.toLocaleString()} gold.`,`<span class="gvpair"><canvas width="150" height="190" data-gv="a:hwreap"></canvas><canvas width="150" height="190" data-gv="w:hw_scythe"></canvas></span>`,HW_PRICE.b,oa&&ow,oa!==ow?1:0)}</div>
  <div class="gvab"><span class="gvic">✦</span><div><b>Ability: Soul Harvest</b><span>${esc((typeof GAB!=='undefined'&&GAB.harvest&&GAB.harvest.d)||'Flawless kills reap souls. At 13 souls the Reaper\'s Toll sweeps the field.')}</span></div><div class="gvset"><b>Set bonus</b><span>${esc((typeof GAB!=='undefined'&&GAB.harvest&&GAB.harvest.set||'').replace('Set bonus: ',''))}</span></div></div>
  <div class="gvcol"><div class="gvcolh"><b>Graveyard Crate relics</b><span>${hwCount()} / 12 found · win crates in Monster Mash or buy them in Hollow Street · you own ${P.hcr||0}</span></div>${hwStrip()}</div></div>`;
 m.classList.add('on');m.querySelector('.shx').onclick=shClose;m.onclick=e=>{if(e.target===m)shClose()};hwThumbs(m);
 m.querySelectorAll('[data-gb]').forEach(b=>b.onclick=()=>gvBuy(b.dataset.gb));
 const sc=$('gvsc'),sg=sc.getContext('2d');LIVE.push({cv:sc,fn:t=>gvScene(sg,sc.width,sc.height,t,on)});
 m.querySelectorAll('canvas[data-gv]').forEach((c,i)=>{const [k,id]=c.dataset.gv.split(':'),cd=c.closest('.gvc');let fr=0;LIVE.push({cv:c,fn:t=>{if(!cd.matches(':hover')&&(fr++%2))return;try{art(c,k,id,t+i)}catch(e){}}})});
 beep(196,.4,'sine',.4);setTimeout(()=>beep(233,.5,'sine',.3),160)};

/* ---------- crate menu polish ---------- */
{const ch0=crateHub;crateHub=function(){ch0.apply(this,arguments);const tk=SHOWT;setTimeout(()=>{if(SHOWT===tk)cxPolish()},0)}}
function cxPolish(){{try{const hub=ov.querySelector('.chub');if(!hub||hub.classList.contains('cx2'))return;hub.classList.add('cx2');
  ov.querySelectorAll('.chub .cc').forEach((cc,i)=>{cc.style.setProperty('--i',i);const n=+((cc.querySelector('.ccn')||{}).textContent||'').replace(/\D/g,'')||0;if(n)cc.classList.add('has');
   cc.addEventListener('pointerenter',()=>cc._h=1);cc.addEventListener('pointerleave',()=>cc._h=0);const b=cc.querySelector('[data-o],#cxop');if(b)b.addEventListener('click',()=>{cc.classList.add('opening')},{capture:true})});
  /* pedestals: draw a lit stone disc under every everyday chest, each frame, beneath the chest itself */
  for(const L of LIVE){const cv=L.cv;if(!cv||!cv.closest)continue;const cc=cv.closest('.chub .cc');if(!cc)continue;const g=cv.getContext('2d'),f0=L.fn,col=getComputedStyle(cc).getPropertyValue('--c').trim()||'#ffd45a';
   const clr=g.clearRect.bind(g);L.fn=t=>{g.clearRect=(...a)=>{clr(...a);gvPed(g,cv.width,cv.height,t,col,cc)};try{f0(t)}finally{g.clearRect=clr}}}
  /* the Graveyard banner: drifting fog and wisps over its art */
  const hb=ov.querySelector('.hwb .hwbl');if(hb&&!hb.querySelector('.gvfog')){const c=document.createElement('canvas');c.className='gvfog';c.width=440;c.height=300;hb.appendChild(c);const g=c.getContext('2d');
   LIVE.push({cv:c,fn:t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,440,300);g.save();g.globalCompositeOperation='lighter';for(let i=0;i<5;i++){const x=220+Math.sin(t*.6+i*1.7)*150,y=200+Math.sin(t*1.2+i)*30;ncGlow(g,x,y,18,'#7affc8'+ncA(.3+.2*Math.sin(t*2+i)));g.fillStyle='#e0fff4';g.beginPath();g.arc(x,y,2.2,0,Math.PI*2);g.fill()}g.restore();
    for(let i=0;i<4;i++){const fx=((t*16*(i%2?1:-1)+i*160)%640+640)%640-100,q=g.createRadialGradient(fx,262,0,fx,262,160);q.addColorStop(0,'#c8b8ff26');q.addColorStop(1,'#c8b8ff00');g.fillStyle=q;g.fillRect(fx-160,102,320,198)}},slow:1})}
 }catch(e){}}}
function gvPed(g,w,h,t,col,cc){const cx=w/2,by=h-5,hv=cc._h?1:0;g.save();
 const q=g.createRadialGradient(cx,by,0,cx,by,w*.42);q.addColorStop(0,col+(cc.classList.contains('has')?'40':'1c'));q.addColorStop(1,col+'00');g.fillStyle=q;g.fillRect(0,by-60,w,70);
 g.fillStyle='#120c24';g.beginPath();g.ellipse(cx,by+1,w*.46,9,0,0,Math.PI*2);g.fill();const sq=g.createLinearGradient(0,by-10,0,by+6);sq.addColorStop(0,'#4a3e66');sq.addColorStop(1,'#1e1634');g.fillStyle=sq;g.beginPath();g.ellipse(cx,by-3,w*.43,9,0,0,Math.PI*2);g.fill();
 g.strokeStyle=col+'88';g.lineWidth=1.5;g.setLineDash([4,6]);g.lineDashOffset=-t*12;g.beginPath();g.ellipse(cx,by-3,w*.4,6.5,0,0,Math.PI*2);g.stroke();g.setLineDash([]);
 if(cc.classList.contains('has')){g.globalCompositeOperation='lighter';for(let i=0;i<4;i++){const v=(t*.5+i/4)%1;g.globalAlpha=(1-v)*.7;g.fillStyle=col;g.fillRect(cx-40+i*26+Math.sin(t+i)*4,by-10-v*70,2.4,2.4)}}
 g.restore()}

/* ---------- styles ---------- */
{const st=document.createElement('style');st.textContent=`
.shmod:has(.gvwin){inset:58px -8px 50px}
.shmc.gvwin{padding:0;width:min(1120px,96%);background:linear-gradient(180deg,#140a2a,#0a0618);border:2px solid transparent;background-clip:padding-box;box-shadow:0 0 0 2px #7affc855,0 0 50px #c86bff44,0 24px 60px #000e}
.gvwin .shx{color:#d8fff0;text-shadow:0 2px 6px #000}
.gvhd{position:relative;height:auto;aspect-ratio:1100/240;overflow:hidden;border-radius:16px 16px 0 0}
.gvhd canvas{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
.gvhd::after{content:"";position:absolute;left:0;right:0;bottom:0;height:28px;background:linear-gradient(transparent,#140a2a)}
.gvht{position:absolute;left:0;right:0;top:22px;display:flex;flex-direction:column;align-items:center;gap:4px;z-index:1;text-align:center}
.gvht>div{display:flex;gap:8px;align-items:center}.gvdays{padding:3px 10px;border-radius:12px;background:#0a0618cc;font:700 13px var(--ui);color:#7affc8}
.gvht h3{margin:0;font:400 64px/1.05 'Pirata One',Georgia,serif;filter:drop-shadow(0 3px 0 #000a) drop-shadow(0 0 22px #7affc855);animation:gvt 4s ease-in-out infinite}
@keyframes gvt{50%{filter:drop-shadow(0 3px 0 #000a) drop-shadow(0 0 34px #c86bff88)}}
.gvht p{margin:0;font:500 16px var(--ui);color:#e4dcff;text-shadow:0 2px 6px #000}
.gvnote{margin:8px 24px 0;padding:10px 16px;border-radius:12px;background:#0f2a1ae6;border:1.5px solid #5affa0aa;font:600 15px var(--ui);color:#c8ffd8;text-align:center;animation:gvin .4s ease both}
.gvg{display:grid;grid-template-columns:1fr 1fr 1.25fr;gap:16px;padding:16px 24px 6px}
.gvc{position:relative;display:flex;flex-direction:column;align-items:center;gap:4px;padding:12px 14px 14px;border-radius:18px;text-align:center;background:radial-gradient(ellipse at 50% 30%,#2a1450,#120a24 70%);border:2px solid #ff4d9466;box-shadow:0 10px 24px #000a;transition:transform .25s,box-shadow .25s,border-color .25s;animation:gvin .55s cubic-bezier(.2,1.2,.4,1) calc(.1s + var(--i)*.09s) both}
@keyframes gvin{from{opacity:0;transform:translateY(24px) scale(.96)}}
.gvc:hover{transform:translateY(-6px);border-color:#7affc8;box-shadow:0 0 34px #7affc855,0 16px 30px #000c}
.gvc.bun{border-color:#ffd45a88;background:radial-gradient(ellipse at 50% 30%,#3a2050,#140a24 70%)}.gvc.bun:hover{border-color:#ffd45a;box-shadow:0 0 34px #ffd45a55,0 16px 30px #000c}
.gvc.own{border-color:#5affa0}.gvc.own::before{content:'OWNED';position:absolute;top:10px;right:10px;padding:3px 9px;border-radius:10px;font:800 11px var(--ui);letter-spacing:1px;color:#0a2a14;background:#7affc8}
.gvcp{position:relative;display:flex;justify-content:center;align-items:flex-end;height:200px;width:100%}
.gvcp canvas{height:200px;width:160px;position:relative;z-index:1;border-radius:14px;-webkit-mask-image:radial-gradient(ellipse 60% 62% at 50% 48%,#000 62%,#0000 100%);mask-image:radial-gradient(ellipse 60% 62% at 50% 48%,#000 62%,#0000 100%);filter:drop-shadow(0 10px 16px #000c);transition:transform .35s cubic-bezier(.3,1.6,.5,1)}
.gvc:hover .gvcp canvas{transform:scale(1.07)}
.gvpair{display:flex;gap:4px;position:relative;z-index:1}.gvpair canvas{height:170px;width:134px;-webkit-mask-image:radial-gradient(ellipse 60% 62% at 50% 48%,#000 62%,#0000 100%);mask-image:radial-gradient(ellipse 60% 62% at 50% 48%,#000 62%,#0000 100%)}
.gvglow{position:absolute;left:50%;bottom:8px;width:70%;height:40px;transform:translateX(-50%);border-radius:50%;background:radial-gradient(#7affc866,transparent 70%);animation:gvgl 2.6s ease-in-out infinite}
.gvc.bun .gvglow{background:radial-gradient(#ffd45a66,transparent 70%)}
@keyframes gvgl{50%{opacity:.5;transform:translateX(-50%) scale(1.15)}}
.gvsave{position:absolute;top:2px;left:50%;transform:translateX(-50%) rotate(-4deg);z-index:2;padding:4px 12px;border-radius:10px;font:800 13px var(--ui);letter-spacing:1px;color:#2a1406;background:linear-gradient(180deg,#fff0a0,#f0a820);box-shadow:0 4px 10px #000a;animation:gvsv 2s ease-in-out infinite}
@keyframes gvsv{50%{transform:translateX(-50%) rotate(3deg) scale(1.06)}}
.gvc b{font:400 30px/1.05 'Pirata One',Georgia,serif;color:#ff9ac6}.gvc.bun b{color:#ffe27a}.gvc em{font:800 12px var(--ui);font-style:normal;letter-spacing:1.4px;text-transform:uppercase;color:#7affc8}
.gvc small{font:500 13.5px/1.4 var(--ui);color:#d4cef0;min-height:38px}
.gvbuy{all:unset;box-sizing:border-box;cursor:pointer;margin-top:auto;display:flex;flex-direction:column;align-items:center;justify-content:center;min-width:72%;padding:9px 18px;border-radius:14px;font:800 22px var(--ui);color:#2a1406;background:linear-gradient(180deg,#fff0a0,#f4b020 55%,#d88a10);border:2px solid #fff4b8;box-shadow:0 5px 0 #7a4a08,0 8px 18px #000a;transition:transform .12s,filter .15s}
.gvbuy .coin{width:22px;height:22px;margin-right:6px;vertical-align:-3px}.gvbuy small{font:700 11px var(--ui);color:#ffdede;min-height:0}
.gvbuy:hover:not(:disabled){transform:translateY(-2px);filter:brightness(1.08)}.gvbuy:active:not(:disabled){transform:translateY(3px);box-shadow:0 2px 0 #7a4a08}
.gvbuy:disabled{cursor:default;font-size:18px;color:#e8e8f4;background:linear-gradient(180deg,#4a4060,#2a2440);border-color:#7a6a9a;box-shadow:0 4px 0 #140c24}
.gvbuy.own,.gvbuy.own:disabled{opacity:1;font-size:20px;color:#0a2a14;background:linear-gradient(180deg,#b8ffd8,#3ad88a);border-color:#e0fff0;box-shadow:0 4px 0 #0a5a2a}
.gvc.bought{animation:gvbt .9s cubic-bezier(.3,1.6,.5,1)}@keyframes gvbt{30%{transform:scale(1.06);box-shadow:0 0 60px #7affc8}}
.gvsp{position:absolute;left:50%;top:40%;width:8px;height:8px;border-radius:50%;background:var(--c);box-shadow:0 0 10px var(--c);z-index:3;pointer-events:none;animation:gvsp 1.1s ease-out forwards}
@keyframes gvsp{to{transform:translate(var(--dx),var(--dy)) scale(.2);opacity:0}}
.gvab{display:flex;align-items:center;gap:16px;margin:10px 24px 0;padding:12px 18px;border-radius:14px;background:linear-gradient(90deg,#0a2a1e,#140a2a);border:1.5px solid #5affb066;animation:gvin .5s ease .35s both}
.gvic{font:24px Georgia,serif;color:#7affc8;text-shadow:0 0 12px #7affc8}.gvab>div{display:flex;flex-direction:column;gap:2px;flex:1}.gvab b{font:400 24px 'Pirata One',Georgia,serif;color:#b8ffe0}.gvab span{font:500 13px/1.4 var(--ui);color:#d4f0e4}
.gvab .gvset{flex:.8;padding-left:16px;border-left:1px solid #5affb044}.gvset b{color:#ffe27a!important}
.gvcol{margin:12px 24px 20px;padding:12px 16px;border-radius:14px;background:#0a0618aa;border:1px solid #ffffff1a;animation:gvin .5s ease .45s both}
.gvcolh{display:flex;justify-content:space-between;align-items:baseline;gap:12px;margin-bottom:8px}.gvcolh b{font:400 24px 'Pirata One',Georgia,serif;color:#e8dcff}.gvcolh span{font:600 13px var(--ui);color:#a8a2d8}
.gvcol .hwst{justify-content:center}
@media (max-width:900px){.gvg{grid-template-columns:1fr}.gvab{flex-direction:column;align-items:flex-start}.gvab .gvset{border:0;padding:0}}
/* crate menu */
.chub.cx2 .cc{animation:cxin .6s cubic-bezier(.2,1.25,.4,1) calc(.08s + var(--i)*.07s) both;background:radial-gradient(ellipse at 50% 32%,color-mix(in srgb,var(--c) 22%,#1e1640),#0e0a24 72%)!important;border:2px solid #3a3070!important;box-shadow:0 10px 24px #000a!important}
@keyframes cxin{from{opacity:0;transform:translateY(40px) scale(.94)}}
.chub.cx2 .cc::after{display:none}
.chub.cx2 .cc::before{height:3px;background:linear-gradient(90deg,#0000,var(--c),#0000);opacity:.8}
.chub.cx2 .cc.has{border-color:color-mix(in srgb,var(--c) 60%,#3a3070)!important;animation:cxin .6s cubic-bezier(.2,1.25,.4,1) calc(.08s + var(--i)*.07s) both,cxhas 3s ease-in-out 1s infinite}
@keyframes cxhas{50%{box-shadow:0 10px 24px #000a,0 0 30px color-mix(in srgb,var(--c) 35%,transparent)}}
.chub.cx2 .cc:not(.e):hover{transform:translateY(-8px)!important;border-color:var(--c)!important;box-shadow:0 0 36px color-mix(in srgb,var(--c) 50%,transparent),0 18px 30px #000c!important}
.chub.cx2 .cc canvas{-webkit-mask-image:none;mask-image:none}
.chub.cx2 .cc .ccb .sm{position:relative;overflow:hidden}
.chub.cx2 .cc.has .ccb .sm:not(:disabled){background:linear-gradient(180deg,#fff0a0,#f4b020 55%,#d88a10)!important;color:#2a1406!important;border-color:#fff4b8!important;box-shadow:0 4px 0 #7a4a08,0 6px 14px #000a!important}
.chub.cx2 .cc.has .ccb .sm:not(:disabled):hover{filter:brightness(1.1);transform:translateY(-2px)}
.chub.cx2 .cc.has .ccb .sm:not(:disabled)::after{content:'';position:absolute;top:0;bottom:0;width:40%;left:-60%;background:linear-gradient(100deg,transparent,#ffffffaa,transparent);transform:skewX(-20deg);animation:cxsh 2.8s ease-in-out infinite}
@keyframes cxsh{0%,55%{left:-60%}100%{left:130%}}
.chub.cx2 .cc.opening{animation:cxopen .5s ease forwards}@keyframes cxopen{40%{transform:scale(1.05)}100%{transform:scale(1.08);opacity:.4}}
.hwb .hwbl{position:relative}.gvfog{position:absolute;left:50%;top:50%;width:440px;height:300px;transform:translate(-50%,-50%);pointer-events:none}
.hwb{animation:cxin .6s cubic-bezier(.2,1.2,.4,1) both}
`;document.head.appendChild(st)}
