/* ===== MOONLIT FISHING: fish art 3 (rare + legendary) =====
   moonfin, angler, ray, sun (Rare) and aurora, moonmaw, tidecrown (Legendary). Uses the fk kit from 90b.
   Private helpers are prefixed fa3_. Each fish: centred on the origin, facing right, ~200 units long. */
/* run fn in a frame rotated by a around the joint (x,y) */
function fa3_at(g,x,y,a,fn){g.save();g.translate(x,y);g.rotate(a);fn();g.restore()}
/* slight whole-body bend while thrashing on the line */
function fa3_bend(g,t,o){const f=o.flex||0;if(f)g.rotate(Math.sin(t*7.3)*.06*f)}
/* twinkle 0..1 */
const fa3_tw=(t,i,sp)=>.5+.5*Math.sin(t*(sp||3)+i*1.91);
/* ribbon outline points from a centre line fn(s)->[x,y,halfWidth] */
function fa3_rib(n,fn){const c=[];for(let i=0;i<=n;i++)c.push(fn(i/n));const L=[],R=[];
 for(let i=0;i<=n;i++){const a=c[Math.max(0,i-1)],b=c[Math.min(n,i+1)],dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy)||1,nx=-dy/d,ny=dx/d,w=c[i][2];
  L.push(c[i][0]+nx*w,c[i][1]+ny*w);R.unshift(c[i][0]-nx*w,c[i][1]-ny*w)}return L.concat(R)}
/* centre line samples only */
function fa3_line(n,fn){const c=[];for(let i=0;i<=n;i++)c.push(fn(i/n));return c}
/* rib lines radiating from (x0,y0) to targets, clipped to path */
function fa3_ribs(g,pathFn,x0,y0,tg,c,a,lw){g.save();pathFn();g.clip();g.strokeStyle=c||FKO;g.globalAlpha=a==null?.28:a;g.lineWidth=lw||1.3;
 for(let i=0;i<tg.length;i+=2){g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo((x0+tg[i])/2,(y0+tg[i+1])/2+(tg[i+1]-y0)*.08,tg[i],tg[i+1]);g.stroke()}g.restore()}
/* gill arc */
function fa3_gill(g,x,y0,y1,bow,a){g.beginPath();g.moveTo(x,y0);g.quadraticCurveTo(x-bow,(y0+y1)/2,x,y1);g.strokeStyle=FKO;g.globalAlpha=a==null?.55:a;g.lineWidth=2.3;g.stroke();g.globalAlpha=1}
/* a small smiling mouth */
function fa3_smile(g,x,y,w,c){g.beginPath();g.moveTo(x-w,y-w*.25);g.quadraticCurveTo(x-w*.1,y+w*.55,x+w*.6,y-w*.3);g.strokeStyle=c||FKO;g.lineWidth=2.2;g.stroke()}
/* closed spline without starting a new path (to combine several shapes) */
function fa3_blob(g,p,cont){const n=p.length/2,mx=i=>(p[(i%n)*2]+p[((i+1)%n)*2])/2,my=i=>(p[(i%n)*2+1]+p[((i+1)%n)*2+1])/2;if(!cont)g.beginPath();g.moveTo(mx(n-1),my(n-1));for(let i=0;i<n;i++)g.quadraticCurveTo(p[i*2],p[i*2+1],mx(i),my(i));g.closePath()}
/* gem */
function fa3_gem(g,x,y,r,c){g.beginPath();g.moveTo(x,y-r);g.lineTo(x+r*.8,y);g.lineTo(x,y+r);g.lineTo(x-r*.8,y);g.closePath();fkFill(g,fkLin(g,x-r,y-r,x+r,y+r,[shade(c,.55),c,shade(c,-.35)]),1.6);
 g.beginPath();g.moveTo(x-r*.35,y-r*.2);g.lineTo(x,y-r*.62);g.strokeStyle='rgba(255,255,255,.85)';g.lineWidth=1.2;g.stroke()}
function fa3_pearl(g,x,y,r){g.beginPath();g.arc(x,y,r,0,TAU);fkFill(g,fkRad(g,x,y,r,['#ffffff','#f4ecff','#c9b8e0']),1.3);g.beginPath();g.arc(x-r*.3,y-r*.32,r*.3,0,TAU);g.fillStyle='#fff';g.fill()}
/* inner rim stroke of a path (clipped), then re-outline */
function fa3_rim(g,pf,c,lw,olw){g.save();pf();g.clip();pf();g.strokeStyle=c;g.lineWidth=lw||4;g.stroke();g.restore();if(olw!==0){pf();g.lineWidth=olw||2.4;g.strokeStyle=FKO;g.stroke()}}
/* crescent path (bulging toward -x before rotation) */
function fa3_cres(g,x,y,R,k,rot){g.save();g.translate(x,y);g.rotate(rot);g.beginPath();g.arc(0,0,R,-Math.PI/2,Math.PI/2,true);g.ellipse(0,0,R*k,R,0,Math.PI/2,Math.PI*1.5,false);g.closePath();g.restore()}
/* cubic / quadratic bezier point + tangent */
function fa3_cub(a,b,c,d,s){const u=1-s;return [u*u*u*a[0]+3*u*u*s*b[0]+3*u*s*s*c[0]+s*s*s*d[0],u*u*u*a[1]+3*u*u*s*b[1]+3*u*s*s*c[1]+s*s*s*d[1],
 3*u*u*(b[0]-a[0])+6*u*s*(c[0]-b[0])+3*s*s*(d[0]-c[0]),3*u*u*(b[1]-a[1])+6*u*s*(c[1]-b[1])+3*s*s*(d[1]-c[1])]}
function fa3_quad(a,b,c,s){const u=1-s;return [u*u*a[0]+2*u*s*b[0]+s*s*c[0],u*u*a[1]+2*u*s*b[1]+s*s*c[1],2*u*(b[0]-a[0])+2*s*(c[0]-b[0]),2*u*(b[1]-a[1])+2*s*(c[1]-b[1])]}
/* sample the fkPath spline of points p into a polyline */
function fa3_spl(p){const n=p.length/2,out=[],mx=i=>(p[(i%n)*2]+p[((i+1)%n)*2])/2,my=i=>(p[(i%n)*2+1]+p[((i+1)%n)*2+1])/2;let x0=mx(n-1),y0=my(n-1);
 for(let i=0;i<n;i++){const cx=p[i*2],cy=p[i*2+1],x1=mx(i),y1=my(i);for(let k=1;k<=8;k++){const s=k/8,u=1-s;out.push([u*u*x0+2*u*s*cx+s*s*x1,u*u*y0+2*u*s*cy+s*s*y1])}x0=x1;y0=y1}return out}
/* top (top=true) or bottom edge y of a sampled outline at x */
function fa3_edge(pts,x,top){let b=null;for(let i=0;i<pts.length;i++){const a=pts[i],c=pts[(i+1)%pts.length];if((a[0]-x)*(c[0]-x)<=0&&a[0]!==c[0]){const y=a[1]+(c[1]-a[1])*(x-a[0])/(c[0]-a[0]);if(b===null||(top?y<b:y>b))b=y}}return b==null?0:b}
/* tapered whisker along a cubic: root half-width w0 to tip w1 */
function fa3_whisk(g,a,b,c,d,w0,w1,fill,lw){const p=fa3_rib(14,s=>{const q=fa3_cub(a,b,c,d,s);return [q[0],q[1],w0+(w1-w0)*s]});fkPath(g,p);fkFill(g,fill,lw||1.5)}

/* ---------- 18 Silver Moonfin (Rare) ---------- */
FISHART.moonfin=(g,t,o)=>{const gl=o.glow||0,sw=fkSway(o,3.2,.13),fl=Math.sin(t*4.2)*.12,pu=.5+.5*Math.sin(t*2.2),sh=k=>`rgba(255,255,255,${.5+.35*Math.sin(t*3+k)+gl*.15})`;
 fa3_bend(g,t,o);
 /* moon-glow aura */
 fkGlow(g,8,-4,118+gl*16,'#a8f2ff',.2+.08*pu+gl*.45);
 const silver=(y0,y1)=>fkLin(g,0,y0,0,y1,['#ffffff','#bdeef9','#f2fdff','#a6dff0','#ffffff']);
 /* lunate crescent tail: both lobes curl inward to sharp points */
 fa3_at(g,-52,0,sw,()=>{const tp=()=>{g.beginPath();g.moveTo(14,-10);g.bezierCurveTo(-8,-24,-32,-62,-60,-57);g.bezierCurveTo(-42,-44,-31,-22,-30,0);g.bezierCurveTo(-31,22,-42,44,-60,57);g.bezierCurveTo(-32,62,-8,24,14,10);g.closePath()};
  tp();fkFill(g,silver(-60,60),2.6);fa3_ribs(g,tp,8,0,[-56,-52,-46,-36,-36,-18,-33,0,-36,18,-46,36,-56,52],'#3a7a9a',.33);
  g.save();tp();g.clip();g.beginPath();g.moveTo(-54,-50);g.bezierCurveTo(-38,-38,-29,-18,-28,0);g.bezierCurveTo(-29,18,-38,38,-54,50);g.strokeStyle='rgba(140,236,255,.9)';g.lineWidth=3.2;g.stroke();g.restore();
  fa3_rim(g,tp,sh(0),3.6,2.6)});
 /* small crescent anal fin (back) */
 fa3_at(g,-14,40,-fl*.7,()=>{const p=()=>{g.beginPath();g.moveTo(10,-4);g.quadraticCurveTo(0,22,-36,28);g.quadraticCurveTo(-14,14,-14,-2);g.closePath()};p();fkFill(g,silver(-4,30),2.4);fa3_ribs(g,p,2,-2,[-32,26,-20,22,-10,14],'#3a7a9a',.3);fa3_rim(g,p,sh(1),3,2.4)});
 /* crescent-hook dorsal sweeping back, with silver spiky tips */
 fa3_at(g,14,-52,fl*.5,()=>{const A=[26,2],B=[16,-28],C=[-22,-34],D=[-58,-26];
  [.32,.52,.72].forEach((s,i)=>{const q=fa3_cub(A,B,C,D,s),L=Math.hypot(q[2],q[3])||1,tx=q[2]/L,ty=q[3]/L,nx=-ty,ny=tx,h=9-i;
   g.beginPath();g.moveTo(q[0]-tx*5,q[1]-ty*5);g.lineTo(q[0]+nx*h+tx*5,q[1]+ny*h+ty*5);g.lineTo(q[0]+tx*4,q[1]+ty*4);g.closePath();fkFill(g,fkLin(g,q[0],q[1],q[0]+nx*h,q[1]+ny*h,['#a8dcef','#ffffff']),2)});
  const p=()=>{g.beginPath();g.moveTo(A[0],A[1]);g.bezierCurveTo(B[0],B[1],C[0],C[1],D[0],D[1]);g.bezierCurveTo(-34,-22,-22,-14,-26,6);g.closePath()};
  p();fkFill(g,silver(-34,6),2.5);fa3_ribs(g,p,-6,8,[-54,-25,-42,-29,-28,-31,-14,-30,0,-26,14,-16],'#3a7a9a',.3);
  g.save();p();g.clip();g.beginPath();g.moveTo(-52,-24);g.bezierCurveTo(-34,-20,-24,-12,-24,2);g.strokeStyle='rgba(140,236,255,.9)';g.lineWidth=2.8;g.stroke();g.restore();
  fa3_rim(g,p,sh(2),3.4,2.5)});
 /* deep opah-like body with a tall chest */
 const BP=[100,8,96,-22,72,-50,30,-62,-12,-54,-42,-30,-56,-8,-54,8,-40,26,-10,46,30,58,70,48,94,26],body=()=>fkPath(g,BP);
 body();fkFill(g,fkLin(g,0,-60,0,56,['#0b6e90','#1fb4cc','#4ee6e0','#b6fff2']),3);
 fkShade(g,body,-14,-60,'#0a3a6a',.45);
 g.save();body();g.clip();
 /* gold spots */
 const sp=[[-36,-16,4.4],[-24,4,3.6],[-12,-28,5.2],[-4,-6,3.8],[6,22,4.6],[12,-40,3.4],[-40,10,3],[32,28,3.4],[-18,28,3],[44,-38,3.2],[-48,-2,2.4],[46,-20,2.8],[22,12,2.6],[-28,-36,3],[2,40,2.8],[-6,-46,2.6],[-34,26,2.4],[48,8,2.4],[18,46,2.6]];
 for(const [x,y,r] of sp){g.beginPath();g.arc(x,y,r,0,TAU);g.fillStyle=fkRad(g,x,y,r,['#fff6b8','#ffd34a','#d08a10']);g.fill();g.lineWidth=1.1;g.strokeStyle='rgba(27,16,36,.45)';g.stroke()}
 /* clean silver crescent-moon emblem */
 fa3_cres(g,22,-14,12.5,.42,-.55);g.fillStyle=fkLin(g,10,-26,30,0,['#ffffff','#e8fbff','#bfeef8']);g.fill();g.lineWidth=1.5;g.strokeStyle='rgba(20,90,130,.6)';g.stroke();
 g.restore();
 fkGlow(g,18,-14,26,'#d8fcff',.2+.12*pu+gl*.35);
 fkShade(g,body,12,58,'#0b5a7a',.32);
 fkHi(g,body,.6,3.4);
 fa3_gill(g,58,-36,12,12);
 /* thin crescent-sickle pectoral */
 fa3_at(g,50,18,fl,()=>{const p=()=>{g.beginPath();g.moveTo(4,-7);g.bezierCurveTo(-2,12,-22,28,-52,25);g.bezierCurveTo(-34,13,-18,2,-4,7);g.closePath()};p();fkFill(g,fkLin(g,4,-7,-40,26,['#ffffff','#c6f0fb','#7cc6e2']),2.4);fa3_ribs(g,p,2,0,[-50,25,-42,24,-34,22,-26,19,-18,14],'#3a7a9a',.35);fa3_rim(g,p,sh(3),3,2.4)});
 fkEye(g,74,-14,11.5,'#14708e',.3);
 fa3_smile(g,94,12,5);
 /* moon sparkles */
 const ss=[[-74,-52,7,'#ffffff'],[66,-62,6,'#fff3b0'],[-88,44,5,'#c8fbff'],[100,-28,4.5,'#ffffff'],[-8,64,5,'#fff3b0'],[34,-76,4,'#c8fbff']];
 ss.forEach(([x,y,r,c],i)=>{const k=fa3_tw(t,i,2.6);fkSpark(g,x,y+Math.sin(t+i)*2,r*(.6+.5*k)*(1+gl*.5),c,.35+.6*k)});
};

/* ---------- 19 Dusk Angler (Rare) ---------- */
FISHART.angler=(g,t,o)=>{const gl=o.glow||0,sw=fkSway(o,3.6,.16),fl=Math.sin(t*5)*.15,fx=o.flex||0,lp=.5+.5*Math.sin(t*3);
 fa3_bend(g,t,o);
 const ox=96+Math.sin(t*1.7)*3+Math.sin(t*9)*fx*3,oy=-54+Math.sin(t*2.3)*4;
 fkGlow(g,ox,oy,42,'#ffd98a',.2+.08*lp+gl*.45);
 /* tail */
 fa3_at(g,-54,2,sw,()=>{const p=[14,-10,-12,-22,-46,-44,-36,-14,-32,0,-36,14,-46,44,-12,22,14,10];
  fkFin(g,p,'#d08cff','#5a2a9a',[[4,0,-44,-40],[4,0,-40,-20],[4,0,-36,0],[4,0,-40,20],[4,0,-44,40]],2.4)});
 /* spiky violet dorsal crest */
 const crest=()=>{g.beginPath();g.moveTo(4,-62);g.quadraticCurveTo(0,-74,-8,-87);g.quadraticCurveTo(-11,-76,-16,-68);g.quadraticCurveTo(-20,-78,-28,-85);g.quadraticCurveTo(-29,-72,-34,-62);g.quadraticCurveTo(-39,-70,-48,-77);g.quadraticCurveTo(-48,-62,-56,-44);g.closePath()};
 crest();fkFill(g,fkLin(g,0,-87,0,-50,['#f6c8ff','#c070f4','#7a34c8','#4a1a8a']),2.3);
 fa3_ribs(g,crest,-18,-50,[-8,-86,-28,-84,-48,-76],FKO,.3,1.3);
 fa3_rim(g,crest,'rgba(255,220,255,.5)',2.4,2.3);
 fa3_at(g,-30,46,-fl*.6,()=>fkFin(g,[8,-6,-6,16,-26,22,-22,6,-18,-6],'#c080f8','#5a2a9a',[[2,-2,-22,18],[2,-2,-12,18]],2.3));
 /* mouth interior (shows through the body's open grin) */
 const cav=()=>{g.beginPath();g.moveTo(102,-12);g.quadraticCurveTo(70,-6,38,8);g.quadraticCurveTo(76,40,112,8);g.closePath()};
 cav();g.fillStyle=fkLin(g,0,-10,0,30,['#4a0c32','#22051a']);g.fill();
 g.save();cav();g.clip();g.beginPath();g.ellipse(66,24,17,6.5,-.12,0,TAU);g.fillStyle='#d04a7a';g.fill();g.beginPath();g.ellipse(62,22,7,2,-.12,0,TAU);g.fillStyle='rgba(255,170,200,.5)';g.fill();g.restore();
 /* body with an underbite: the lower jaw juts past the upper */
 const body=()=>{g.beginPath();g.moveTo(102,-12);g.quadraticCurveTo(100,-50,54,-66);g.quadraticCurveTo(4,-78,-40,-54);g.quadraticCurveTo(-66,-34,-64,0);g.quadraticCurveTo(-62,34,-40,50);
  g.quadraticCurveTo(4,72,54,62);g.quadraticCurveTo(104,52,112,8);g.quadraticCurveTo(76,40,38,8);g.quadraticCurveTo(70,-6,102,-12);g.closePath()};
 body();fkFill(g,fkRad(g,24,-16,104,['#a865dc','#6a33a4','#3a1664','#25103f']),3);
 fkShade(g,body,10,66,'#1a0830',.4);
 /* glowing freckles (kept clear of the fin) */
 g.save();body();g.clip();
 [[-30,-30],[-14,-44],[4,-50],[-40,-8],[-22,-14],[-46,16],[-48,32],[22,48],[12,-34],[-6,-22]].forEach(([x,y],i)=>{const k=fa3_tw(t,i,2.2),c=i%3?'#7af0ff':'#ff8ae0';
  g.globalAlpha=.18+.22*k;g.fillStyle=c;g.beginPath();g.arc(x,y,6.5,0,TAU);g.fill();g.globalAlpha=.35+.4*k;g.beginPath();g.arc(x,y,4,0,TAU);g.fill();g.globalAlpha=1;g.beginPath();g.arc(x,y,2,0,TAU);g.fillStyle='#ffffff';g.fill()});
 /* the lure's warm light on the forehead and eye */
 fkGlow(g,(ox+58)/2,(oy-34)/2+4,58,'#ffc878',.24+.1*lp+gl*.3);
 /* lower lip band */
 g.beginPath();g.moveTo(40,13);g.quadraticCurveTo(76,45,112,13);g.strokeStyle='rgba(206,150,255,.6)';g.lineWidth=3.2;g.stroke();
 g.restore();
 fkHi(g,body,.45,3.4);
 /* teeth: upper row hangs from the upper lip, lower row stands on the lower lip */
 g.fillStyle='#fffaf0';g.strokeStyle=FKO;g.lineWidth=1.2;
 const qp=(a,b,c,s)=>[(1-s)*(1-s)*a[0]+2*(1-s)*s*b[0]+s*s*c[0],(1-s)*(1-s)*a[1]+2*(1-s)*s*b[1]+s*s*c[1]];
 for(let i=1;i<9;i++){const s=i/9.4,p=qp([102,-12],[70,-6],[38,8],s),q=qp([102,-12],[70,-6],[38,8],s+.06),L=7-s*3;g.beginPath();g.moveTo(p[0],p[1]-1);g.lineTo(q[0],q[1]-1);g.lineTo((p[0]+q[0])/2+1,(p[1]+q[1])/2+L);g.closePath();g.fill();g.stroke()}
 for(let i=1;i<9;i++){const s=i/9,p=qp([38,8],[76,40],[112,8],s-.035),q=qp([38,8],[76,40],[112,8],s+.035),L=4.5+s*5.5;g.beginPath();g.moveTo(p[0],p[1]+1.5);g.lineTo(q[0],q[1]+1.5);g.lineTo((p[0]+q[0])/2+.5,(p[1]+q[1])/2-L);g.closePath();g.fill();g.stroke()}
 /* front pectoral */
 fa3_at(g,6,22,fl,()=>{const p=[6,-6,-14,-4,-34,10,-30,22,-12,22,4,8];fkFin(g,p,'#e0a0ff','#7a3ab8',[[2,0,-30,12],[2,0,-24,22],[2,0,-12,20]],2.3)});
 /* eye with a cheeky brow */
 fkEye(g,58,-30,13.5,'#ffaa22',.4);
 g.beginPath();g.moveTo(44,-48);g.quadraticCurveTo(58,-54,72,-46);g.strokeStyle=FKO;g.lineWidth=3;g.stroke();
 /* lure stalk */
 g.beginPath();g.moveTo(36,-66);g.quadraticCurveTo(58,-96,ox-2,oy-7);g.strokeStyle=FKO;g.lineWidth=6.5;g.stroke();g.strokeStyle='#9a5ad6';g.lineWidth=3.2;g.stroke();
 /* the little moon */
 g.beginPath();g.arc(ox,oy,10,0,TAU);fkFill(g,fkRad(g,ox,oy,10,['#ffffff','#fff2a8','#f2b448']),2.4);
 g.fillStyle='rgba(214,150,60,.55)';[[2,3,2.4],[-3,-2,1.6],[4,-4,1.2]].forEach(([a,b,r])=>{g.beginPath();g.arc(ox+a,oy+b,r,0,TAU);g.fill()});
 fkGlow(g,ox,oy,24,'#fff4c0',.5+.2*lp+gl*.3);
 [[ox+16,oy-10,4],[ox-15,oy+8,3],[ox+10,oy+16,2.6]].forEach(([x,y,r],i)=>fkSpark(g,x,y,r*(.6+.6*fa3_tw(t,i,3.4)),'#fff6c8',.3+.6*fa3_tw(t,i,3.4)));
};

/* ---------- 20 Ghostwing Ray (Rare) ---------- */
FISHART.ray=(g,t,o)=>{const gl=o.glow||0,fx=o.flex||0,A=6.5*(1+fx*1.9),ph=t*2.4,w1=Math.sin(ph)*A,w2=Math.sin(ph-.35)*A*.9,sw=fkSway(o,3,.1);
 fa3_bend(g,t,o);
 fkGlow(g,8,0,126+gl*14,'#b8c6ff',.2+.06*Math.sin(t*2)+gl*.45);
 /* one side of the wing outline, snout -> tail root; sg -1 upper, 1 lower */
 const side=(sg,wv)=>{const P=[],tx=-32+wv*.3,ty=68+wv;
  for(let i=0;i<=6;i++){const s=i/6,q=fa3_cub([90,12],[86,42],[28,80+wv*.6],[tx,ty],s);P.push(q[0],sg*(q[1]+Math.sin(s*5-ph*1.2)*2.2*s))}
  P.push(tx,sg*ty);
  for(let i=1;i<=9;i++){const s=i/9,q=fa3_quad([tx,ty],[10,40+wv*.3],[-44,8],s),off=(i%2?3.8:0)+Math.sin(s*8-ph*2)*1.4;P.push(q[0]-off*.9,sg*(q[1]+off*.4))}
  return P};
 const up=side(-1,w1),lo=side(1,w2),lr=[];for(let i=lo.length-2;i>=0;i-=2)lr.push(lo[i],lo[i+1]);
 const BP=up.concat(lr,[102,0]),body=()=>fkPath(g,BP),tip1=[-32+w1*.3,-(68+w1)],tip2=[-32+w2*.3,68+w2],outside=fn=>{g.save();g.beginPath();g.rect(-200,-200,400,400);fa3_blob(g,BP,1);g.clip('evenodd');fn();g.restore()};
 /* spectral wisps drifting off the wing tips */
 [[tip1,-1],[tip2,1]].forEach(([tp,sg],j)=>{for(let k=0;k<2;k++){const L=58+k*16,ph2=t*1.8+j*1.3+k*2;
  const fn=s=>[tp[0]-2-s*L,tp[1]+sg*(4+k*8)*s*s-sg*k*3+Math.sin(ph2-s*5)*7*s,(3.2-k*.8)*Math.sin(Math.PI*Math.min(1,s*1.6+.08))*(1-s*.6)+.15];const p=fa3_rib(12,fn);
  fkPath(g,p);g.fillStyle=fkLin(g,tp[0],0,tp[0]-L,0,[`rgba(220,228,255,${.42+.12*Math.sin(ph2)})`,'rgba(200,212,255,.18)','rgba(200,212,255,0)']);g.fill()}});
 /* long whip tail with a gentle S-sway */
 outside(()=>fa3_at(g,-34,0,sw,()=>{const fn=s=>[-s*76,Math.sin(t*3.1-s*5)*8*s*(1+fx*1.4)+Math.sin(s*Math.PI*1.6)*3*s,5.2*(1-s)+.7];const p=fa3_rib(18,fn);fkPath(g,p);fkFill(g,fkLin(g,0,0,-76,0,['rgba(232,238,255,.9)','rgba(190,192,246,.8)']),2)}));
 /* curled cephalic horn lobes pointing forward */
 outside(()=>[-1,1].forEach(s=>{const c=Math.sin(t*2+s)*1.8;const hp=[82,s*6,92,s*20,106,s*25,116+c*.4,s*(19+c),115,s*(10+c),108,s*(12+c*.5),98,s*12,89,s*4];
  fkPath(g,hp);fkFill(g,fkLin(g,86,0,116,0,['rgba(226,232,255,.9)','rgba(176,178,244,.9)']),2.3);
  g.beginPath();g.moveTo(92,s*12);g.quadraticCurveTo(106,s*20,111,s*(14+c*.6));g.strokeStyle='rgba(120,110,210,.45)';g.lineWidth=1.6;g.stroke()}));
 /* translucent body + wings */
 body();fkFill(g,fkLin(g,0,-80,0,80,['rgba(168,176,250,.6)','rgba(222,230,255,.66)','rgba(246,250,255,.74)','rgba(222,230,255,.66)','rgba(184,190,252,.6)']),2.8);
 g.save();body();g.clip();
 g.fillStyle='rgba(90,90,190,.12)';g.fillRect(-80,-96,200,84);
 /* ripple bands across the wings */
 for(let i=0;i<4;i++){const xx=-10+i*22+Math.sin(ph+i)*3;g.beginPath();g.moveTo(xx+12,-90);g.quadraticCurveTo(xx-6+Math.sin(ph-i)*4,0,xx+12,90);g.strokeStyle='rgba(255,255,255,.16)';g.lineWidth=5;g.stroke()}
 /* raised body ridge */
 g.beginPath();g.ellipse(28,0,60,18,0,0,TAU);g.fillStyle=fkLin(g,0,-18,0,18,['rgba(255,255,255,.7)','rgba(214,220,255,.45)']);g.fill();
 g.beginPath();g.moveTo(-34,0);g.quadraticCurveTo(20,-3,72,-1);g.strokeStyle='rgba(120,120,210,.3)';g.lineWidth=2;g.stroke();
 /* glowing lavender spots with soft halos */
 g.globalCompositeOperation='lighter';
 const SP=[[-4,-50,5],[14,-40,3.8],[4,-62,3],[30,-34,3.2],[-20,-30,3.2],[0,50,5.2],[18,42,3.8],[-14,34,3.4],[6,62,3],[32,36,3.2],[-28,-52,2.8],[-22,54,2.8]];
 SP.forEach(([x,y,r],i)=>{const k=fa3_tw(t,i,2.1);g.fillStyle=i%4?`rgba(170,120,255,${.16+.14*k+gl*.15})`:`rgba(255,130,220,${.16+.14*k+gl*.15})`;g.beginPath();g.arc(x,y,r*2.6,0,TAU);g.fill()});
 g.globalCompositeOperation='source-over';
 SP.forEach(([x,y,r],i)=>{g.beginPath();g.arc(x,y,r,0,TAU);g.fillStyle=i%4?'rgba(160,112,246,.85)':'rgba(255,136,220,.85)';g.fill();g.beginPath();g.arc(x-r*.3,y-r*.3,r*.38,0,TAU);g.fillStyle='rgba(255,255,255,.75)';g.fill()});
 g.restore();
 fkShade(g,body,20,80,'#6a6ad0',.2);
 /* bright spectral inner rim */
 fa3_rim(g,body,`rgba(226,238,255,${.55+.2*Math.sin(t*2.2)+gl*.3})`,8,0);
 fa3_rim(g,body,'rgba(255,255,255,.8)',2.4,2.8);
 /* face */
 fkEye(g,72,-14,9.5,'#5a5ad8',.5);fkEye(g,74,14,9.5,'#5a5ad8',.5);
 g.beginPath();g.moveTo(96,-5);g.quadraticCurveTo(101,0,96,5);g.strokeStyle=FKO;g.lineWidth=2.2;g.stroke();
 [-1,1].forEach(s=>{g.beginPath();g.ellipse(84,s*24,4.5,2.6,0,0,TAU);g.fillStyle='rgba(255,140,200,.55)';g.fill()});
 /* twinkles on the wings + ghost motes */
 [[-8,-44],[22,-50],[-2,40],[24,56]].forEach(([x,y],i)=>{const k=fa3_tw(t,i+2,3.2);fkSpark(g,x,y,(2.5+3*k)*(1+gl*.5),'#ffffff',.3+.65*k)});
 [[-62,-70,5],[64,-64,4],[-76,62,4.5],[56,68,3.6],[-96,-14,3.4]].forEach(([x,y,r],i)=>{const k=fa3_tw(t,i,2);fkSpark(g,x+Math.sin(t*.8+i)*4,y-k*4,r*(.6+.5*k)*(1+gl*.4),'#e6eeff',.3+.5*k)});
};

/* ---------- 21 Sunscale Sturgeon (Rare) ---------- */
function fa3_sun(g,x,y,r,t,i){const k=.5+.5*Math.sin(t*2+i*1.3);g.beginPath();g.arc(x,y,r*2.4,0,TAU);g.fillStyle=`rgba(255,236,160,${.1+.12*k})`;g.fill();
 g.save();g.translate(x,y);g.rotate(i*.4);g.fillStyle='#fff0a8';g.strokeStyle='#7a3a06';g.lineWidth=1;
 for(let k2=0;k2<8;k2++){const a=k2*TAU/8,L=k2%2?r*1.55:r*2;g.beginPath();g.moveTo(Math.cos(a-.28)*r*.9,Math.sin(a-.28)*r*.9);g.lineTo(Math.cos(a)*L,Math.sin(a)*L);g.lineTo(Math.cos(a+.28)*r*.9,Math.sin(a+.28)*r*.9);g.closePath();g.fill();g.stroke()}g.restore();
 g.beginPath();g.arc(x,y,r,0,TAU);fkFill(g,fkRad(g,x,y,r,['#fffbe0','#ffd040','#d4840c']),1.5);g.beginPath();g.arc(x-r*.25,y-r*.25,r*.32,0,TAU);g.fillStyle='rgba(255,255,240,.9)';g.fill()}
/* a pointed bony scute; dir -1 points up, 1 points down */
function fa3_scute(g,x,y,h,w,dir,c1,c2,c3){g.beginPath();g.moveTo(x-w,y-dir*3);g.quadraticCurveTo(x-w*.4,y+dir*h*.6,x+1,y+dir*h);g.quadraticCurveTo(x+w*.55,y+dir*h*.4,x+w,y-dir*3);g.quadraticCurveTo(x,y-dir*6,x-w,y-dir*3);g.closePath();
 fkFill(g,fkLin(g,x,y+dir*h,x,y-dir*4,[c1,c2,c3]),1.7);g.beginPath();g.arc(x,y,1.4,0,TAU);g.fillStyle='#7a3c06';g.fill()}
FISHART.sun=(g,t,o)=>{const gl=o.glow||0,sw=fkSway(o,2.8,.12),fl=Math.sin(t*4)*.12,pu=.5+.5*Math.sin(t*2);
 fa3_bend(g,t,o);
 fkGlow(g,10,-2,122+gl*14,'#ffb43a',.12+.05*pu+gl*.45);
 const finF=(x0,y0,x1,y1)=>fkLin(g,x0,y0,x1,y1,['#ffe08a','#f2a232','#e8501a']);
 const edge=(pf)=>fa3_rim(g,pf,'rgba(255,74,20,.85)',4.5,2.4);
 /* clean heterocercal shark tail */
 fa3_at(g,-64,-3,sw,()=>{const p=()=>{g.beginPath();g.moveTo(12,-7);g.quadraticCurveTo(-16,-18,-50,-50);g.quadraticCurveTo(-42,-22,-34,-2);g.quadraticCurveTo(-40,14,-36,28);g.quadraticCurveTo(-14,14,12,7);g.closePath()};
  p();g.fillStyle=finF(8,0,-46,-44);g.fill();fa3_ribs(g,p,8,0,[-48,-46,-42,-32,-37,-18,-34,-4,-36,12,-35,24],'#6a2a04',.3);edge(p)});
 /* back fins: dorsal behind the last scute, anal and pelvic */
 fa3_at(g,-46,-16,fl*.4,()=>{const p=()=>{g.beginPath();g.moveTo(10,2);g.quadraticCurveTo(2,-20,-18,-24);g.quadraticCurveTo(-12,-12,-16,2);g.closePath()};p();g.fillStyle=finF(0,0,-16,-24);g.fill();fa3_ribs(g,p,0,2,[-16,-22,-8,-20,0,-14],'#6a2a04',.3);edge(p)});
 fa3_at(g,-44,13,-fl*.5,()=>{const p=()=>{g.beginPath();g.moveTo(10,-2);g.quadraticCurveTo(0,14,-18,18);g.quadraticCurveTo(-12,6,-14,-2);g.closePath()};p();g.fillStyle=finF(0,0,-16,18);g.fill();fa3_ribs(g,p,0,-2,[-16,16,-6,14],'#6a2a04',.3);edge(p)});
 fa3_at(g,-6,26,-fl*.6,()=>{const p=()=>{g.beginPath();g.moveTo(8,-2);g.quadraticCurveTo(-2,14,-20,15);g.quadraticCurveTo(-12,4,-12,-2);g.closePath()};p();g.fillStyle=finF(0,0,-16,15);g.fill();fa3_ribs(g,p,0,-2,[-18,14,-8,12],'#6a2a04',.3);edge(p)});
 /* body: powerful front third tapering to the tail, long flat shovel snout */
 const BP=[118,-15,112,-8,96,-3,78,8,56,26,20,33,-20,27,-50,14,-70,4,-70,-6,-52,-16,-24,-28,10,-39,42,-41,64,-35,88,-25,108,-20,116,-18],body=()=>fkPath(g,BP),PT=fa3_spl(BP),top=x=>fa3_edge(PT,x,true),bot=x=>fa3_edge(PT,x,false);
 body();fkFill(g,fkLin(g,0,-41,0,33,['#5a2a06','#a85e10','#f0a828','#ffd870','#fff0c8','#fff8ea']),3);
 fkShade(g,body,-8,-41,'#4a2006',.5);
 fkScales(g,body,-70,90,-24,28,9,'#7a3a06',.16);
 fkGlow(g,24,-6,72,'#ffd060',.05+.06*pu+gl*.4);
 g.save();body();g.clip();
 /* lateral row of sun emblems */
 [[-42,-1,4],[-20,-3,4.8],[4,-4,5.2],[28,-5,5.2],[50,-6,4.8]].forEach(([x,y,r],i)=>fa3_sun(g,x,y,r,t,i));
 /* lower row of small bronze scutes */
 for(let i=0;i<7;i++){const x=-38+i*14,y=bot(x)-7.5,w=4.6-Math.abs(i-3)*.3,h=3.4;g.beginPath();g.moveTo(x-w,y);g.quadraticCurveTo(x-w*.3,y-h*.9,x+w*.2,y-h);g.quadraticCurveTo(x+w*.7,y-h*.5,x+w,y);g.quadraticCurveTo(x+w*.3,y+h*.9,x-w*.2,y+h);g.quadraticCurveTo(x-w*.7,y+h*.5,x-w,y);g.closePath();
  fkFill(g,fkLin(g,x,y-h,x,y+h,['#f6c470','#d48a30','#9a5212']),1.4);g.beginPath();g.moveTo(x-w*.7,y+.4);g.lineTo(x+w*.7,y-.4);g.strokeStyle='rgba(255,240,200,.75)';g.lineWidth=1;g.stroke()}
 g.restore();
 fkShade(g,body,14,34,'#e0b070',.2);
 fkHi(g,body,.6,3.2);
 /* evenly spaced dorsal ridge of bony scutes */
 for(let i=0;i<6;i++){const x=52-i*18;fa3_scute(g,x,top(x)+2,i===0||i===5?8:10,7,-1,'#fff3b0','#ffc23a','#a8600c')}
 fa3_gill(g,58,-30,16,10);
 /* pectoral */
 fa3_at(g,52,20,fl,()=>{const p=()=>{g.beginPath();g.moveTo(6,-4);g.quadraticCurveTo(-10,2,-30,18);g.quadraticCurveTo(-18,24,-4,12);g.closePath()};p();g.fillStyle=finF(4,-4,-28,20);g.fill();fa3_ribs(g,p,2,0,[-28,18,-18,20,-8,14],'#6a2a04',.3);edge(p)});
 /* four short barbels hanging under the snout, ahead of the mouth */
 [[103,9,0],[98,11,1],[93,8.5,2],[88,10.5,3]].forEach(([x,L,i])=>{const y=bot(x)-1,c=Math.sin(t*2.6+i*1.4)*1.8;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+1,y+L*.6,x-1+c,y+L);g.strokeStyle=FKO;g.lineWidth=3.6;g.stroke();g.strokeStyle='#ffe6b0';g.lineWidth=1.7;g.stroke()});
 /* underslung mouth */
 const my=bot(76);g.beginPath();g.ellipse(76,my-1.5,5.2,2.6,-.35,0,TAU);fkFill(g,'#5a1a0a',1.8);
 /* teal-ringed eye */
 g.beginPath();g.arc(70,-15,13,0,TAU);g.fillStyle='#1ab8b0';g.fill();g.lineWidth=2;g.strokeStyle=FKO;g.stroke();
 fkEye(g,70,-15,10,'#0e8a86',.2);
 g.beginPath();g.moveTo(58,-30);g.quadraticCurveTo(70,-34,82,-28);g.strokeStyle=FKO;g.lineWidth=2.6;g.stroke();
 [[-84,-56,6],[30,-60,5],[104,-34,4],[-40,46,4.5],[-100,30,4]].forEach(([x,y,r],i)=>{const k=fa3_tw(t,i,2.4);fkSpark(g,x,y,r*(.6+.5*k)*(1+gl*.5),'#fff0a0',.35+.6*k)});
};

/* ---------- 22 Aurora Koi (Legendary) ---------- */
const FA3_AUR=['#7ff6ff','#8a7cff','#ff8ad8','#ffe27a'];
FISHART.aurora=(g,t,o)=>{const gl=o.glow||0,fx=o.flex||0,sw=fkSway(o,2.4,.1),W=1+fx*1.5,sh=Math.sin(t*.9);
 fa3_bend(g,t,o);
 fkGlow(g,0,0,130+gl*22,'#b48cff',.16+.06*Math.sin(t*1.7)+gl*.6);
 fkGlow(g,-70,0,70,'#7ff6ff',.1+.04*Math.sin(t*2.3)+gl*.3);
 const silk=(x0,y0,x1,y1)=>fkLin(g,x0,y0,x1,y1,['rgba(240,250,255,.95)','rgba(127,246,255,.88)','rgba(150,124,255,.85)','rgba(255,138,216,.85)','rgba(255,226,122,.9)']);
 const streak=(c,n,a)=>{g.save();g.strokeStyle=`rgba(255,255,255,${a||.45})`;g.lineWidth=1.2;for(let k=1;k<n;k++){const f=k/n;g.beginPath();g.moveTo(c[0][0],c[0][1]+(f-.5)*6);for(let i=1;i<c.length;i++)g.lineTo(c[i][0],c[i][1]+(f-.5)*c[i][2]*1.5);g.stroke()}g.restore()};
 const orbit=front=>{for(let i=0;i<7;i++){const a=t*.7+i*TAU/7;if((Math.sin(a)>0)!==front)continue;const x=Math.cos(a)*106,y=Math.sin(a)*60,k=fa3_tw(t,i,3.3);
  g.beginPath();g.ellipse(0,0,106,60,0,a-.42,a);g.strokeStyle=FA3_AUR[i%4]+'66';g.lineWidth=2.2;g.stroke();fkSpark(g,x,y,(4+3*k)*(1+gl*.6),FA3_AUR[i%4],.5+.5*k)}};
 orbit(false);
 /* layered double-veil silk tail: four translucent bands waving in sequence */
 const veil=(yEnd,len,wid,ph,c1,c2)=>{const fn=s=>[12-s*len,yEnd*Math.pow(s,1.15)+Math.sin(t*2.5-s*4.4-ph)*9*s*W,(3+Math.sin(Math.PI*Math.min(1,s*1.12))*wid)*(1-s*.45)+.6];
  const p=fa3_rib(16,fn);fkPath(g,p);fkFill(g,fkLin(g,10,0,12-len,yEnd,['rgba(250,248,255,.8)',c1,c2]),2);g.save();fkPath(g,p);g.clip();streak(fa3_line(16,fn),4,.32);g.restore()};
 fa3_at(g,-44,0,sw,()=>{veil(-50,70,15,0,'rgba(110,240,255,.66)','rgba(127,246,255,.42)');veil(50,70,15,2.4,'rgba(255,220,110,.7)','rgba(255,200,90,.42)');
  veil(-18,82,13,.8,'rgba(150,120,255,.66)','rgba(170,140,255,.44)');veil(18,82,13,1.6,'rgba(255,130,214,.66)','rgba(255,150,220,.44)')});
 /* dorsal ribbon */
 fa3_at(g,16,-32,Math.sin(t*2)*.05,()=>{const fn=s=>[6-s*84,-s*30-Math.sin(Math.PI*s)*10+Math.sin(t*2.4-s*4)*6*s*W,(3+Math.sin(Math.PI*s)*9)*(1-s*.5)];const p=fa3_rib(12,fn);fkPath(g,p);fkFill(g,silk(0,0,-80,-30),2.2);g.save();fkPath(g,p);g.clip();streak(fa3_line(12,fn),3,.35);g.restore()});
 /* bold gold crown crest */
 g.save();g.translate(40,-37);g.rotate(-.12);g.scale(2.1,2.1);
 g.beginPath();g.moveTo(-14,8);g.lineTo(-13,-5);g.lineTo(-7,1);g.lineTo(-2,-13);g.lineTo(3,0);g.lineTo(9,-9);g.lineTo(11,3);g.lineTo(16,-3);g.lineTo(16,9);g.closePath();
 fkFill(g,fkLin(g,0,-13,0,8,['#fff8d0','#ffd23a','#c47e0c']),1.3);
 g.beginPath();g.moveTo(-12,3);g.lineTo(15,4);g.strokeStyle='rgba(150,80,10,.6)';g.lineWidth=.8;g.stroke();
 g.beginPath();g.moveTo(-11,-2);g.lineTo(-7,2.5);g.moveTo(-2,-10);g.lineTo(1,-1);g.strokeStyle='rgba(255,255,255,.75)';g.lineWidth=.8;g.stroke();
 [[-13,-5,'#7ff6ff'],[-2,-13,'#ff6ac8'],[9,-9,'#b48cff'],[16,-3,'#7ff6ff']].forEach(([x,y,c])=>{g.beginPath();g.arc(x,y,1.9,0,TAU);fkFill(g,fkRad(g,x,y,1.9,['#ffffff',c,shade(c,-.3)]),.8)});
 g.restore();
 /* long trailing pelvic + anal ribbons (behind) */
 fa3_at(g,12,30,Math.sin(t*2.4)*.06,()=>{const fn=s=>[2-s*52,s*38+Math.sin(t*2.7-s*4+.6)*5*s*W,(2.6+Math.sin(Math.PI*s)*6)*(1-s*.45)];const p=fa3_rib(10,fn);fkPath(g,p);fkFill(g,silk(0,0,-50,38),2.1);g.save();fkPath(g,p);g.clip();streak(fa3_line(10,fn),3,.35);g.restore()});
 fa3_at(g,-16,28,Math.sin(t*2.2)*.06,()=>{const fn=s=>[4-s*62,s*20+Math.sin(t*2.6-s*4+1)*5*s*W,(3+Math.sin(Math.PI*s)*6.5)*(1-s*.5)];const p=fa3_rib(10,fn);fkPath(g,p);fkFill(g,silk(0,0,-60,20),2.1);g.save();fkPath(g,p);g.clip();streak(fa3_line(10,fn),3,.35);g.restore()});
 /* body */
 const body=()=>fkPath(g,[98,2,88,-22,54,-38,6,-38,-32,-26,-50,-9,-50,9,-32,26,6,36,54,34,88,18]);
 body();fkFill(g,fkLin(g,0,-38,0,36,['#ece4ff','#ffffff','#fbf6ff','#ddd4f6']),3);
 g.save();body();g.clip();
 /* soft iridescent wash over the whole body */
 const iw=g.createLinearGradient(-50+sh*20,-30,100+sh*20,30);iw.addColorStop(0,'rgba(127,246,255,.22)');iw.addColorStop(.35,'rgba(170,140,255,.16)');iw.addColorStop(.7,'rgba(255,150,220,.2)');iw.addColorStop(1,'rgba(255,226,122,.16)');g.fillStyle=iw;g.fillRect(-60,-50,170,100);
 /* aurora patches */
 const pat=()=>{fa3_blob(g,[-56,-12,-34,-38,6,-44,40,-42,52,-30,38,-14,22,-4,6,-14,-12,2,-30,10,-46,4]);fa3_blob(g,[-24,18,-4,6,20,10,34,24,12,42,-20,38],1);fa3_blob(g,[-56,8,-44,14,-38,30,-56,26],1)};
 const pq=g.createLinearGradient(-60+sh*14,-30,80+sh*14,20);pq.addColorStop(0,'#3ee6ff');pq.addColorStop(.35,'#7a5cff');pq.addColorStop(.65,'#ff6ac8');pq.addColorStop(1,'#ffcf4a');
 pat();g.fillStyle=pq;g.fill();
 /* starfield inside the patches */
 g.save();pat();g.clip();
 const st=[[-38,-12],[-22,-26],[-6,-30],[12,-34],[30,-30],[44,-26],[-28,-4],[0,-20],[22,-16],[-8,22],[8,30],[18,20],[-14,14],[-46,18],[36,-36],[-50,-4]];
 st.forEach(([x,y],i)=>{const k=fa3_tw(t,i,2.8);g.globalAlpha=.4+.6*k;g.beginPath();g.arc(x,y,i%3?1.1:1.7,0,TAU);g.fillStyle='#fff';g.fill()});g.globalAlpha=1;
 g.beginPath();g.moveTo(-38,-12);g.lineTo(-22,-26);g.lineTo(-6,-30);g.lineTo(12,-34);g.lineTo(22,-16);g.moveTo(-8,22);g.lineTo(8,30);g.lineTo(18,20);g.strokeStyle='rgba(255,255,255,.5)';g.lineWidth=.9;g.stroke();
 [[-22,-26],[12,-34],[8,30],[-46,18]].forEach(([x,y],i)=>fkSpark(g,x,y,3.4*(.6+.5*fa3_tw(t,i+4,3)),'#ffffff',.9));
 g.restore();
 pat();g.strokeStyle='rgba(255,255,255,.55)';g.lineWidth=1.6;g.stroke();
 /* scales shimmer + sweeping sheen */
 fkScales(g,body,-50,60,-36,36,10,'#8a70c8',.12);
 const bx=((t*40)%260)-130;const bq=g.createLinearGradient(bx-20,0,bx+20,0);bq.addColorStop(0,'rgba(255,255,255,0)');bq.addColorStop(.5,'rgba(255,255,255,.45)');bq.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=bq;g.fillRect(bx-20,-50,40,100);
 g.restore();
 fkShade(g,body,6,38,'#6a50b8',.28);
 fkHi(g,body,.75,3.4);
 fa3_gill(g,58,-24,22,11,.45);
 /* long trailing pectoral ribbon */
 fa3_at(g,46,16,Math.sin(t*2.6)*.1,()=>{const fn=s=>[2-s*62,4+s*40+Math.sin(t*2.8-s*4)*6*s*W,(3+Math.sin(Math.PI*s)*7.5)*(1-s*.45)];const p=fa3_rib(12,fn);fkPath(g,p);fkFill(g,silk(0,0,-60,44),2.2);g.save();fkPath(g,p);g.clip();streak(fa3_line(12,fn),3,.4);g.restore()});
 /* two short gold barbels curling outward */
 const bc=Math.sin(t*2.4)*1.6;
 fa3_whisk(g,[95,7],[102,13],[108,21],[105+bc,28],2.3,.7,fkLin(g,95,7,105,28,['#fff4fa','#ffb0dc','#ff7ac4']),1.5);
 fa3_whisk(g,[89,9],[91,17],[88,25],[82-bc,29],2.3,.7,fkLin(g,89,9,82,29,['#fff4fa','#ffb0dc','#ff7ac4']),1.5);
 fkEye(g,72,-10,11.5,'#7a3ad0',.3);
 fa3_smile(g,93,6,4.5);
 /* sparkles drifting off the silk tail */
 for(let i=0;i<6;i++){const u=((t*.35+i/6)%1),x=-56-u*58,y=Math.sin(i*2.1)*36*u+Math.sin(t*2+i)*4,a=Math.sin(Math.PI*u);fkSpark(g,x,y,(2.5+2.5*a)*(1+gl*.5),FA3_AUR[(i+1)%4],.85*a)}
 orbit(true);
 if(gl>0)fkGlow(g,40,-10,66,'#ffffff',gl*.35);
};

/* ---------- 23 Moonmaw (Legendary) ---------- */
function fa3_barn(g,x,y,r,a){g.save();g.translate(x,y);g.rotate(a);g.beginPath();g.moveTo(-r,r*.2);g.quadraticCurveTo(-r*.9,-r*.7,-r*.42,-r*1.25);g.lineTo(r*.42,-r*1.25);g.quadraticCurveTo(r*.9,-r*.7,r,r*.2);g.quadraticCurveTo(0,r*.5,-r,r*.2);g.closePath();
 fkFill(g,fkLin(g,-r,0,r,0,['#f4f8ff','#b8c6e0','#6a7898']),1.3);g.beginPath();g.moveTo(-r*.3,0);g.lineTo(-r*.22,-r*1.1);g.moveTo(r*.3,0);g.lineTo(r*.22,-r*1.1);g.strokeStyle='rgba(60,70,110,.5)';g.lineWidth=.9;g.stroke();
 g.beginPath();g.ellipse(0,-r*1.25,r*.42,r*.18,0,0,TAU);g.fillStyle='#1c2448';g.fill();g.restore()}
FISHART.moonmaw=(g,t,o)=>{const gl=o.glow||0,fx=o.flex||0,sw=fkSway(o,2,.1),fl=Math.sin(t*3)*.08,mp=.5+.5*Math.sin(t*1.6);
 fa3_bend(g,t,o);
 fkGlow(g,0,0,130+gl*16,'#5a7aff',.13+gl*.35);
 /* tattered tail */
 fa3_at(g,-66,0,sw,()=>{const p=()=>{g.beginPath();g.moveTo(14,-10);g.quadraticCurveTo(-12,-28,-46,-58);g.lineTo(-37,-43);g.lineTo(-49,-33);g.lineTo(-39,-22);g.lineTo(-49,-8);g.lineTo(-39,2);g.lineTo(-49,14);g.lineTo(-37,24);g.lineTo(-47,38);g.lineTo(-37,46);g.lineTo(-44,58);g.quadraticCurveTo(-12,28,14,10);g.closePath()};
  p();fkFill(g,fkLin(g,10,0,-50,0,['#16226a','#2e48a0','#7a9ae0']),2.6);fa3_ribs(g,p,8,0,[-44,-54,-46,-30,-46,-6,-46,18,-42,42],'#0a1030',.35);
  fa3_rim(g,p,'rgba(190,214,255,.45)',3,2.6)});
 /* long dorsal + anal fins set back */
 fa3_at(g,-20,-42,fl*.5,()=>{const p=()=>{g.beginPath();g.moveTo(30,6);g.quadraticCurveTo(10,-26,-20,-30);g.lineTo(-24,-20);g.lineTo(-34,-24);g.lineTo(-36,-12);g.lineTo(-46,-12);g.quadraticCurveTo(-40,4,-34,16);g.closePath()};p();fkFill(g,fkLin(g,0,-30,0,10,['#7a9ae0','#1e2e78']),2.5);fa3_ribs(g,p,0,10,[-20,-30,-32,-22,-44,-12,6,-22],'#0a1030',.35);fa3_rim(g,p,'rgba(190,214,255,.4)',3,2.5)});
 fa3_at(g,-26,38,-fl*.6,()=>{const p=()=>{g.beginPath();g.moveTo(26,-6);g.quadraticCurveTo(6,22,-22,26);g.lineTo(-26,18);g.lineTo(-36,22);g.lineTo(-40,10);g.quadraticCurveTo(-36,-4,-30,-10);g.closePath()};p();fkFill(g,fkLin(g,0,-6,0,26,['#1e2e78','#7a9ae0']),2.5);fa3_ribs(g,p,0,-8,[-20,26,-34,20,-40,8,8,18],'#0a1030',.35)});
 /* huge jaw with the moon deep inside */
 const U0=[114,-28],U1=[86,-12],C0=[66,3],L1=[86,18],L0=[114,34];
 const cav=()=>{g.beginPath();g.moveTo(U0[0],U0[1]);g.quadraticCurveTo(U1[0],U1[1],C0[0],C0[1]);g.quadraticCurveTo(L1[0],L1[1],L0[0],L0[1]);g.quadraticCurveTo(119,3,U0[0],U0[1]);g.closePath()};
 cav();g.fillStyle=fkRad(g,94,3,32,['#2a2058','#120a2c','#07041a']);g.fill();
 g.save();cav();g.clip();fkGlow(g,94,3,32,'#bcd4ff',.35+.3*mp+gl*.3);
 g.beginPath();g.arc(94,3,12,0,TAU);g.fillStyle=fkRad(g,94,3,12,['#ffffff','#eef2ff','#b8c4e8']);g.fill();
 g.fillStyle='rgba(140,150,200,.55)';[[90,0,2.8],[97,7,2.1],[98,-2,1.5]].forEach(([x,y,r])=>{g.beginPath();g.arc(x,y,r,0,TAU);g.fill()});g.restore();
 /* body: a big heavy head tapering to a slim tail */
 const body=()=>{g.beginPath();g.moveTo(U0[0],U0[1]);g.quadraticCurveTo(108,-54,70,-63);g.quadraticCurveTo(16,-72,-30,-46);g.quadraticCurveTo(-62,-28,-74,-8);g.lineTo(-74,8);g.quadraticCurveTo(-60,28,-24,42);g.quadraticCurveTo(36,64,84,55);g.quadraticCurveTo(110,47,L0[0],L0[1]);
  g.quadraticCurveTo(L1[0],L1[1],C0[0],C0[1]);g.quadraticCurveTo(U1[0],U1[1],U0[0],U0[1]);g.closePath()};
 body();fkFill(g,fkLin(g,0,-68,0,58,['#080c34','#141e62','#2a4092','#6a88c4','#bccbe6']),3);
 fkShade(g,body,-24,-68,'#04061e',.5);
 fkScales(g,body,-74,74,-52,52,15,'#c8d8ff',.18);
 g.save();body();g.clip();
 /* silver-blue rim light along the back and belly */
 g.save();g.translate(0,4.5);body();g.strokeStyle='rgba(170,204,255,.55)';g.lineWidth=3.2;g.stroke();g.restore();
 g.save();g.translate(0,-4);body();g.strokeStyle='rgba(226,236,255,.6)';g.lineWidth=3;g.stroke();g.restore();
 /* glowing ancient glyphs along the flank */
 const GL=[[-52,-4,0],[-32,2,1],[-11,-3,2],[9,1,3],[28,-4,4]];
 const glyph=(x,y,k)=>{g.beginPath();if(k===0){g.arc(x,y-1,6.5,0,Math.PI);g.quadraticCurveTo(x,y+3,x+6.5,y-1)}
  else if(k===1){for(let i=0;i<=26;i++){const a=i*.36,r=.8+a*.66,px=x+Math.cos(a)*r,py=y+Math.sin(a)*r;i?g.lineTo(px,py):g.moveTo(px,py)}}
  else if(k===2){g.arc(x,y,7,0,TAU);for(let i=0;i<=5;i++){const a=-Math.PI/2+i*TAU*2/5,px=x+Math.cos(a)*5,py=y+Math.sin(a)*5;i?g.lineTo(px,py):g.moveTo(px,py)}}
  else if(k===3){g.moveTo(x,y+7);g.lineTo(x,y-7);g.moveTo(x-5,y-6);g.lineTo(x,y-1);g.lineTo(x+5,y-6)}
  else{g.moveTo(x,y-7);g.lineTo(x+5,y-1);g.lineTo(x,y+4);g.lineTo(x-5,y-1);g.closePath();g.moveTo(x-1.5,y+3);g.lineTo(x-5,y+7.5);g.moveTo(x+1.5,y+3);g.lineTo(x+5,y+7.5)}};
 g.lineCap='round';g.lineJoin='round';
 GL.forEach(([x,y,k],i)=>{const ra=Math.min(1,.45+.3*Math.sin(t*1.3+i*.9)+gl*.5);g.beginPath();g.arc(x,y,12,0,TAU);g.fillStyle=`rgba(90,200,255,${ra*.16})`;g.fill();
  glyph(x,y,k);g.strokeStyle=`rgba(100,220,255,${ra*.35})`;g.lineWidth=5;g.stroke();glyph(x,y,k);g.strokeStyle=`rgba(190,246,255,${ra})`;g.lineWidth=1.8;g.stroke()});
 g.restore();
 fkShade(g,body,16,60,'#1a2a6a',.22);
 fkHi(g,body,.5,3.6);
 /* clustered silver cone barnacles near the head and back */
 [[[114,-28],[108,-54],[70,-63],[[.42,4.2,0],[.53,2.6,1],[.6,3.4,-1],[.48,2,3]]],[[70,-63],[16,-72],[-30,-46],[[.48,3,0],[.56,5,1],[.63,3.4,-1],[.7,2.4,0],[.52,2,4],[.6,2.2,4]]]].forEach(([a,b,c,list])=>list.forEach(([s,r,dy])=>{
  const q=fa3_quad(a,b,c,s),L=Math.hypot(q[2],q[3])||1,nx=q[3]/L,ny=-q[2]/L;fa3_barn(g,q[0]-nx*(r*.5+dy*.8),q[1]-ny*(r*.5+dy*.8),r*1.3,Math.atan2(ny,nx)+Math.PI/2)}));
 fa3_gill(g,48,-40,36,16,.6);g.globalAlpha=1;fa3_gill(g,40,-32,30,12,.35);
 /* fangs along both jaws */
 g.fillStyle='#f4f6ff';g.strokeStyle=FKO;g.lineWidth=1.3;
 [[.18,1],[.42,1],[.66,1]].forEach(([s,d])=>{const q=fa3_quad(U0,U1,C0,s);g.beginPath();g.moveTo(q[0]-3.2,q[1]-1);g.lineTo(q[0]+3.2,q[1]-1.5);g.lineTo(q[0]+.4,q[1]+8-s*2);g.closePath();g.fill();g.stroke()});
 [[.36],[.6],[.84]].forEach(([s])=>{const q=fa3_quad(C0,L1,L0,s);g.beginPath();g.moveTo(q[0]-3.2,q[1]+1.5);g.lineTo(q[0]+3.2,q[1]+1);g.lineTo(q[0]+.4,q[1]-6-s*2);g.closePath();g.fill();g.stroke()});
 /* tattered ribbed fan pectoral */
 fa3_at(g,32,22,Math.sin(t*3)*.12,()=>{const p=()=>{g.beginPath();g.moveTo(8,-6);g.quadraticCurveTo(-14,-7,-36,5);g.lineTo(-30,10);g.lineTo(-43,17);g.lineTo(-34,21);g.lineTo(-41,31);g.lineTo(-29,30);g.lineTo(-30,41);g.lineTo(-19,34);g.quadraticCurveTo(-2,22,8,8);g.closePath()};
  p();fkFill(g,fkLin(g,4,0,-40,30,['#8aa8e8','#2a3c8c']),2.4);fa3_ribs(g,p,5,1,[-36,5,-43,17,-41,31,-30,41],'#0a1030',.4);fa3_rim(g,p,'rgba(200,220,255,.4)',2.6,2.4)});
 /* long whiskers rooted at the jaws, tapering and swaying */
 const c1=Math.sin(t*1.8)*6*(1+fx),c2=Math.sin(t*1.8+1)*6*(1+fx);
 fa3_whisk(g,[104,-26],[118,-52],[80,-70+c1*.4],[30+c1,-80+c1*.2],2.2,.4,fkLin(g,104,-26,30,-80,['#dfe8ff','#8ea4dc']),1.5);
 fa3_whisk(g,[103,33],[118,56],[80,72+c2*.4],[28+c2,80-c2*.2],2.2,.4,fkLin(g,103,33,28,80,['#dfe8ff','#8ea4dc']),1.5);
 [[104,-26],[103,33]].forEach(([x,y])=>{g.beginPath();g.arc(x,y,3,0,TAU);fkFill(g,'#8aa0d8',1.4)});
 /* wise ancient eye: gold iris, heavy lid */
 fkEye(g,64,-32,12.5,'#ffc23a',.2);
 g.beginPath();g.arc(64,-32,13.6,Math.PI*1.04,Math.PI*1.96);g.quadraticCurveTo(64,-35,51,-33.5);g.closePath();fkFill(g,'#1c2c78',2.6);
 g.beginPath();g.moveTo(48,-48);g.quadraticCurveTo(64,-54,80,-46);g.strokeStyle='rgba(200,220,255,.6)';g.lineWidth=2;g.stroke();
 /* moon-glow spilling out of the mouth onto the jaws */
 fkGlow(g,100,3,46,'#dce8ff',.16+.18*mp+gl*.45);
 /* drifting moonlight motes */
 for(let i=0;i<6;i++){const u=((t*.12+i/6)%1),x=-90+i*36+Math.sin(t*.7+i)*6,y=70-u*150,a=Math.sin(Math.PI*u);fkSpark(g,x,y,(2.5+2*a)*(1+gl*.5),i%2?'#bcd4ff':'#ffffff',.75*a)}
 [[-84,-60,5],[100,-58,4],[-98,46,4.4]].forEach(([x,y,r],i)=>{const k=fa3_tw(t,i,1.8);fkSpark(g,x,y-k*3,r*(.6+.5*k)*(1+gl*.5),'#ffffff',.3+.6*k)});
};

/* ---------- 24 Tidecrown (Legendary) ---------- */
/* flowing cape fin path: base front (x0,y0) -> top edge -> tip (tx,ty) -> wavy hem -> rear base (xr,yr); sg -1 dorsal, 1 anal */
function fa3_cape(g,t,W,sg,x0,y0,xr,yr,tx,ty,pk,ph,lo){lo=lo||0;return ()=>{const bl=Math.sin(t*2.2-ph)*5*W,b2=Math.sin(t*2.2-ph+.9)*4*W;
 g.beginPath();g.moveTo(x0,y0);g.bezierCurveTo(x0-16,sg*pk,tx+52,sg*(pk-2)+b2,tx,ty+bl);
 let px=tx,py=ty+bl;const N=5;for(let i=1;i<=N;i++){const s=i/N,nx=tx+(xr-tx)*s,ny=ty+bl+(yr-ty-bl)*s-sg*Math.sin(Math.PI*s)*(4+lo),mx=(px+nx)/2,my=(py+ny)/2+Math.sin(t*3-s*6-ph)*1.5*W;g.quadraticCurveTo(mx+2,my-sg*3.5,nx,ny);px=nx;py=ny}
 g.quadraticCurveTo((xr+x0)/2,sg*20,x0,y0);g.closePath()}}
FISHART.tidecrown=(g,t,o)=>{const gl=o.glow||0,fx=o.flex||0,sw=fkSway(o,2.4,.1),W=1+fx*1.5;
 fa3_bend(g,t,o);
 fkGlow(g,10,-4,128+gl*22,'#ffcf4a',.14+.05*Math.sin(t*2)+gl*.55);
 const sea=(x0,y0,x1,y1)=>fkLin(g,x0,y0,x1,y1,['#1cb894','#3ad8b0','#7af0c8','#c8f4a0']);
 const gold=(x0,y0,x1,y1)=>fkLin(g,x0,y0,x1,y1,['#ffe9a0','#ffc93a','#d08a10']);
 const trim=(pf,lw)=>fa3_rim(g,pf,'rgba(255,226,122,.92)',lw||4,2.5);
 /* broad veil tail with a scalloped gold hem */
 fa3_at(g,-48,0,sw,()=>{const pf=()=>{const a=Math.sin(t*2.4)*6*W,b=Math.sin(t*2.4+1.2)*6*W;g.beginPath();g.moveTo(12,-12);g.bezierCurveTo(-12,-22,-38,-46+a,-60,-52+a);
   let px=-60,py=-52+a;const N=7;for(let i=1;i<=N;i++){const s=i/N,nx=-60-Math.sin(Math.PI*s)*4+Math.sin(t*3-s*6)*2.5*W,ny=-52+a+(104+b-a)*s,mx=(px+nx)/2,my=(py+ny)/2;g.quadraticCurveTo(mx-7,my,nx,ny);px=nx;py=ny}
   g.bezierCurveTo(-38,46+b,-12,22,12,12);g.closePath()};
  pf();g.fillStyle=fkLin(g,10,0,-64,0,['#1a3cb0','#1c6cd0','#3ab0e0','#a8e8f4']);g.fill();g.save();pf();g.clip();g.globalCompositeOperation='lighter';g.fillStyle=fkLin(g,0,-50,0,50,['rgba(120,200,255,0)','rgba(120,220,255,.22)','rgba(120,200,255,0)']);g.fillRect(-70,-60,90,120);g.restore();fa3_ribs(g,pf,8,0,[-62,-50,-62,-30,-62,-10,-62,10,-62,30,-62,50],'#0a1a5a',.35);trim(pf,4.5)});
 /* layered cape fins: gold under-layer, sea-green over-layer */
 const dG=fa3_cape(g,t,W,-1,36,-48,-38,-26,-104,-44,72,.15,8),dS=fa3_cape(g,t,W,-1,36,-48,-38,-28,-96,-50,72,0);
 const aG=fa3_cape(g,t,W,1,22,46,-36,24,-96,40,66,.95,8),aS=fa3_cape(g,t,W,1,22,46,-36,26,-88,46,66,.8);
 [[dG,dS,-1],[aG,aS,1]].forEach(([G,S,sg])=>{G();g.fillStyle=gold(0,sg*40,-100,sg*60);g.fill();fa3_ribs(g,G,0,sg*36,[-100,sg*46,-80,sg*64,-60,sg*72,-40,sg*72,-20,sg*68],'#7a4a06',.28);trim(G,3);
  S();g.fillStyle=sea(0,sg*40,-90,sg*56);g.fill();fa3_ribs(g,S,0,sg*36,[-88,sg*48,-70,sg*62,-50,sg*66,-30,sg*66,-10,sg*62],'#0a4a3a',.32);trim(S,4)});
 /* deep discus body with a proud chest */
 const BP=[98,4,90,-28,58,-54,10,-60,-30,-43,-50,-17,-54,0,-50,17,-30,42,10,58,58,52,90,27],body=()=>fkPath(g,BP),PT=fa3_spl(BP);
 body();fkFill(g,fkLin(g,0,-62,0,60,['#14248a','#1c4cc0','#1aa0c8','#62e0d0']),3);
 fkShade(g,body,-16,-62,'#0a1050',.4);
 fkScales(g,body,-56,60,-54,56,12,'#ffd34a',.6);
 g.save();body();g.clip();g.globalCompositeOperation='lighter';const sx=Math.sin(t*1.1)*50;const sq=g.createLinearGradient(sx-30,-40,sx+30,40);sq.addColorStop(0,'rgba(255,220,120,0)');sq.addColorStop(.5,'rgba(255,220,120,.22)');sq.addColorStop(1,'rgba(255,220,120,0)');g.fillStyle=sq;g.fillRect(-70,-70,180,140);g.globalCompositeOperation='source-over';
 /* royal gold band along the back */
 const band=PT.filter(p=>p[1]<-14&&p[0]>-46&&p[0]<84).sort((a,b)=>a[0]-b[0]);
 const bandP=()=>{g.beginPath();band.forEach((p,i)=>{const yy=p[1]+6.5;i?g.lineTo(p[0],yy):g.moveTo(p[0],yy)})};
 bandP();g.strokeStyle=FKO;g.lineWidth=5.4;g.stroke();bandP();g.strokeStyle='#ffd34a';g.lineWidth=3;g.stroke();bandP();g.strokeStyle='rgba(255,250,210,.7)';g.lineWidth=1.2;g.stroke();
 g.restore();
 band.filter((p,i)=>i%9===4).forEach((p,i)=>{if(p[0]<-30||p[0]>50)return;g.beginPath();g.arc(p[0],p[1]+6.5,2.2,0,TAU);fkFill(g,i%2?'#ff4a6a':'#3ad8ff',1.1)});
 fkShade(g,body,16,62,'#0a3a6a',.3);
 fkHi(g,body,.6,3.6);
 /* pearl necklace along the gill line */
 fa3_gill(g,56,-42,40,16,.5);
 for(let i=0;i<9;i++){const s=i/8,y=-32+s*60,x=52-Math.sin(Math.PI*s)*12+2;fa3_pearl(g,x,y,i===4?4.6:3.2)}
 fa3_gem(g,36,-2,5.5,'#ff4a6a');
 /* clean pectoral, below and behind the necklace */
 fa3_at(g,28,32,Math.sin(t*3)*.12,()=>{const pf=()=>{g.beginPath();g.moveTo(6,-5);g.bezierCurveTo(-10,-10,-32,-2,-42,12);g.bezierCurveTo(-30,20,-8,16,6,6);g.closePath()};pf();g.fillStyle=sea(0,-6,-40,14);g.fill();fa3_ribs(g,pf,4,0,[-40,10,-30,16,-18,14],'#0a4a3a',.35);trim(pf,3.4)});
 /* glowing gold eye */
 fkGlow(g,70,-14,24,'#ffd34a',.3+.18*Math.sin(t*2.5)+gl*.35);
 fkEye(g,70,-14,11.5,'#ffbf1a',.3);
 g.beginPath();g.arc(72.5,-13,3.4,0,TAU);g.fillStyle='rgba(255,220,90,.45)';g.fill();
 fa3_smile(g,91,12,4.5);
 /* coral-and-gold crown seated flush on the head */
 const cx=64,cy=fa3_edge(PT,cx,true),ca=Math.atan2(fa3_edge(PT,cx+4,true)-fa3_edge(PT,cx-4,true),8);
 g.save();g.translate(cx,cy+2.5);g.rotate(ca);g.scale(1.22,1.22);
 /* coral sprigs */
 [[-10,-2,-19,-24,-1],[12,-2,21,-24,1]].forEach(([x0,y0,x1,y1,s])=>{const mx=(x0+x1)/2,my=y0-9;
  g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo(mx,y0-6,x1,y1);g.moveTo(mx,my);g.lineTo(mx+s*7,my-7);g.moveTo(x1-s*2,y1+6);g.lineTo(x1-s*8,y1-1);
  g.strokeStyle=FKO;g.lineWidth=6.2;g.stroke();g.strokeStyle='#ff6a80';g.lineWidth=3.4;g.stroke();
  [[x1,y1,2.8],[mx+s*7,my-7,2.3],[x1-s*8,y1-1,2]].forEach(([x,y,r])=>{g.beginPath();g.arc(x,y,r,0,TAU);fkFill(g,'#ff9aa8',1.3)})});
 g.beginPath();g.moveTo(-15,4);g.lineTo(-15,-14);g.lineTo(-8,-6);g.lineTo(-4,-20);g.lineTo(1,-8);g.lineTo(6,-20);g.lineTo(10,-6);g.lineTo(17,-14);g.lineTo(17,4);g.quadraticCurveTo(1,0,-15,4);g.closePath();
 fkFill(g,fkLin(g,0,-20,0,4,['#fff6c0','#ffd34a','#d08a10']),2.3);
 g.beginPath();g.moveTo(-15,-1);g.quadraticCurveTo(1,-4,17,-1);g.strokeStyle='#b06a08';g.lineWidth=1.4;g.stroke();
 fa3_gem(g,1,-6,4,'#ff3a5a');fa3_gem(g,-9,-3,2.6,'#3ac8ff');fa3_gem(g,11,-3,2.6,'#3aeea0');
 fa3_pearl(g,-4,-21,2.3);fa3_pearl(g,6,-21,2.3);fa3_pearl(g,-15,-15,2);fa3_pearl(g,17,-15,2);
 g.restore();
 /* floating pearls and rising bubbles */
 [[-76,-70],[92,-58],[-60,72]].forEach(([x,y],i)=>{const b=Math.sin(t*1.4+i*2)*3;fa3_pearl(g,x,y+b,3+i%2)});
 for(let i=0;i<4;i++){const u=((t*.18+i/4)%1),x=-20+i*30+Math.sin(t*1.5+i)*4,y=72-u*150,r=2+i%2*1.4;g.globalAlpha=Math.sin(Math.PI*u)*.8;g.beginPath();g.arc(x,y,r,0,TAU);g.strokeStyle='#d8fff6';g.lineWidth=1.2;g.stroke();g.beginPath();g.arc(x-r*.35,y-r*.35,r*.3,0,TAU);g.fillStyle='#fff';g.fill();g.globalAlpha=1}
 /* golden sparkles */
 [[-84,-50,6],[100,-42,5],[-100,40,5],[22,-80,4.5],[64,70,4.5],[-30,76,4],[106,30,4],[-40,-78,4]].forEach(([x,y,r],i)=>{const k=fa3_tw(t,i,2.7);fkSpark(g,x,y,r*(.6+.6*k)*(1+gl*.6),i%2?'#fff3b0':'#9ffff0',.35+.6*k)});
 if(gl>0)fkGlow(g,60,-50,44,'#fff2b0',gl*.5);
};
