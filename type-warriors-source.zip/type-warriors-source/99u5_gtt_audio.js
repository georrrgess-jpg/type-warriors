/* ===== UPDATE 10.5, THE GREAT TURKEY TROT: sound (99u5, prefix gttsnd; the object is gttSnd) =====
   Synthesized with Web Audio like the other casino games (the shared context `ac` and the sound-effects bus `sg`), behind the
   existing sound switches: nothing plays when the effects volume is 0 / muted (axOn()). Methods, all safe to call any time:
   call() bugle for the call to the post, gate() starting-gate clang, step(lane) soft pitter-patter (rate-limited), gobble(lane),
   crowd(level 0..1) a murmur bed that swells (call each frame), ding() commentator ding, shutter() photo finish, win(big),
   lose(), stop() (kills the crowd bed; call on leaving). */
const gttsndS={t:{step:0,ding:0,gob:0},bed:null,lvl:0};
function gttsndOn(){try{return typeof axOn==='function'?axOn():!!(ac&&sg&&ST.svol>0)}catch(e){return false}}
function gttsndTone(f,t0,d,ty,v,f2,lp){try{const o=ac.createOscillator(),g=ac.createGain();o.type=ty||'sine';o.frequency.setValueAtTime(f,t0);if(f2)o.frequency.exponentialRampToValueAtTime(f2,t0+d);
 g.gain.setValueAtTime(.0001,t0);g.gain.linearRampToValueAtTime(v,t0+Math.min(.02,d/3));g.gain.exponentialRampToValueAtTime(.0001,t0+d);let n=o;if(lp){const b=ac.createBiquadFilter();b.type='lowpass';b.frequency.value=lp;o.connect(b);n=b}n.connect(g);g.connect(sg);o.start(t0);o.stop(t0+d+.03)}catch(e){}}
function gttsndNoise(t0,d,f1,f2,q,v,a){try{const s=ac.createBufferSource();s.buffer=noiseBuf();const b=ac.createBiquadFilter();b.type='bandpass';b.Q.value=q||1;b.frequency.setValueAtTime(f1,t0);b.frequency.linearRampToValueAtTime(f2||f1,t0+d);
 const g=ac.createGain();g.gain.setValueAtTime(.0001,t0);g.gain.linearRampToValueAtTime(v,t0+(a||.01));g.gain.exponentialRampToValueAtTime(.0001,t0+d);s.connect(b);b.connect(g);g.connect(sg);s.start(t0,Math.random()*1.5);s.stop(t0+d+.03)}catch(e){}}
const gttSnd={
 call(){if(!gttsndOn())return;const t=ac.currentTime+.02;/* a short bugle: da da da DAAA */
  [[392,0,.13],[392,.17,.13],[523,.34,.13],[659,.52,.2],[784,.8,.62]].forEach(([f,o,d])=>{gttsndTone(f,t+o,d,'square',.07,0,1900);gttsndTone(f*2,t+o,d,'sawtooth',.02,0,2600)})},
 gate(){if(!gttsndOn())return;const t=ac.currentTime+.01;gttsndTone(1450,t,.22,'triangle',.12);gttsndTone(2180,t+.015,.26,'triangle',.07);gttsndTone(95,t,.2,'sine',.16,48);gttsndNoise(t,.08,2400,900,.8,.08)},
 step(lane){if(!gttsndOn())return;const n=performance.now();if(n-gttsndS.t.step<70)return;gttsndS.t.step=n;const t=ac.currentTime+.005,l=(lane|0)%6;
  gttsndNoise(t,.045,1500+l*150,900,1.2,.03,.004);gttsndTone(150-l*6,t,.07,'sine',.035,90)},
 gobble(lane){if(!gttsndOn())return;const n=performance.now();if(n-gttsndS.t.gob<220)return;gttsndS.t.gob=n;const t=ac.currentTime+.01,k=.85+((lane|0)%6)*.07;
  try{const o=ac.createOscillator(),lf=ac.createOscillator(),lg=ac.createGain(),g=ac.createGain(),b=ac.createBiquadFilter(),b2=ac.createBiquadFilter(),m=ac.createGain();
   o.type='sawtooth';o.frequency.setValueAtTime(380*k,t);o.frequency.exponentialRampToValueAtTime(230*k,t+.42);lf.frequency.value=19;lg.gain.value=55;lf.connect(lg);lg.connect(o.frequency);
   b.type='bandpass';b.frequency.value=900;b.Q.value=2.4;b2.type='bandpass';b2.frequency.value=2100;b2.Q.value=4;
   g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(.09,t+.04);g.gain.setValueAtTime(.09,t+.28);g.gain.exponentialRampToValueAtTime(.0001,t+.46);
   o.connect(b);o.connect(b2);b.connect(m);b2.connect(m);m.connect(g);g.connect(sg);[o,lf].forEach(x=>{x.start(t);x.stop(t+.5)})}catch(e){}},
 crowd(level){try{level=Math.max(0,Math.min(1,+level||0));gttsndS.lvl=level;if(!gttsndOn()){gttSnd.stop();return}
  if(!gttsndS.bed){if(level<=.01)return;const s=ac.createBufferSource();s.buffer=noiseBuf();s.loop=true;const b=ac.createBiquadFilter();b.type='bandpass';b.frequency.value=620;b.Q.value=.7;
   const hp=ac.createBiquadFilter();hp.type='highpass';hp.frequency.value=260;const g=ac.createGain();g.gain.value=0;s.connect(b);b.connect(hp);hp.connect(g);g.connect(sg);s.start(0,Math.random()*1.5);gttsndS.bed={s,g,b}}
  const B=gttsndS.bed,t=ac.currentTime;B.g.gain.setTargetAtTime(level*level*.34+level*.03,t,.25);B.b.frequency.setTargetAtTime(520+level*700,t,.4)}catch(e){}},
 ding(){if(!gttsndOn())return;const n=performance.now();if(n-gttsndS.t.ding<700)return;gttsndS.t.ding=n;const t=ac.currentTime+.01;gttsndTone(1318,t,.16,'triangle',.07);gttsndTone(1760,t+.07,.2,'triangle',.06)},
 shutter(){if(!gttsndOn())return;const t=ac.currentTime+.01;gttsndNoise(t,.03,3200,1800,1.5,.12,.002);gttsndNoise(t+.07,.04,2600,1400,1.5,.1,.002);gttsndTone(180,t+.07,.09,'square',.05,90)},
 win(big){if(!gttsndOn())return;const t=ac.currentTime+.02;[523,659,784,1047].forEach((f,i)=>{gttsndTone(f,t+i*.1,.3,'triangle',.09);gttsndTone(f*2,t+i*.1,.2,'sine',.03)});
  if(big){[1047,1319,1568,2093].forEach((f,i)=>gttsndTone(f,t+.5+i*.08,.35,'triangle',.07));try{if(typeof flcGobble==='function')flcGobble(sg,t+.45,.05)}catch(e){}}},
 lose(){if(!gttsndOn())return;const t=ac.currentTime+.01;gttsndTone(130,t,.3,'sine',.15,55);gttsndNoise(t,.12,420,160,.8,.06)},
 stop(){try{const B=gttsndS.bed;gttsndS.bed=null;gttsndS.lvl=0;if(B){const t=ac.currentTime;B.g.gain.cancelScheduledValues(t);B.g.gain.setTargetAtTime(0,t,.05);setTimeout(()=>{try{B.s.stop();B.s.disconnect();B.g.disconnect()}catch(e){}},400)}}catch(e){}}};
