/* ---------- campaign: boss artwork (a small medallion for the map, a large painted portrait for the panel) ---------- */
const BMC={},BIM={};
function bossBox(id){try{fitThumb(document.createElement('canvas'),id)}catch(e){}return FT.get(id)}
/* every boss gets its own light and its own weather, chosen from the world it rules */
const BAURA=[
 {fx:'leaf',rim:'#b8ff8a'},{fx:'wisp',rim:'#9affc8'},{fx:'spore',rim:'#ffe86a'},{fx:'ember',rim:'#ffb060'},{fx:'snow',rim:'#bfe8ff'},{fx:'bubble',rim:'#8ff0ff'}];
const cmAura=L=>BAURA[L.z]||BAURA[0];
function bossMedal(L){if(BMC[L.i])return BMC[L.i];const S0=240,c=document.createElement('canvas');c.width=c.height=S0;const g=c.getContext('2d'),a=L.a||'#8a6ad8';
 g.fillStyle=rgr(g,S0*.5,S0*.42,6,S0*.8,shade(a,-.38),shade(a,-.9));g.fillRect(0,0,S0,S0);
 g.save();g.globalCompositeOperation='lighter';glow(g,S0*.5,S0*.4,S0*.5,a+'88');g.restore();
 for(let i=0;i<5;i++){const x=rnd(L.i*7+i)*S0,y=rnd(L.i*7+i+9)*S0*.7;g.fillStyle='#ffffff55';g.fillRect(x,y,2,2)}
 const im=bossBox(L.b);if(im){const sw=im.w,sh=Math.min(im.h,im.w*1.12),k=Math.max(S0*.98/sw,S0*.98/sh);const dw=sw*k,dh=sh*k;g.drawImage(im.O,im.x0,im.y0,sw,sh,(S0-dw)/2,S0*.06,dw,dh)}
 g.fillStyle=rgr(g,S0*.5,S0*.5,S0*.3,S0*.74,'#0000','#000000b0');g.fillRect(0,0,S0,S0);
 return BMC[L.i]=c.toDataURL('image/jpeg',.9)}
function bossImg(url){let im=BIM[url];if(!im){im=BIM[url]=new Image();im.src=url}return im}

/* the large portrait: the world behind, a halo, the boss alive in the middle, and weather in front */
function bossHero(cv,L){const g=cv.getContext('2d'),w=cv.width,h=cv.height,M=MON[L.b],a=L.a||'#8a6ad8',au=cmAura(L);
 const bg=bossImg(sceneShot(L,w,h,'bh',''));
 const s=Math.min(h*.8/M.th,w*.8/(M.tw||M.th*.9)),sd=L.i*13.7;
 return t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,w,h);
  const dx=Math.sin(t*.35)*6,dy=Math.cos(t*.3)*3;
  g.save();g.translate(dx*.6,dy*.6);if(bg.complete&&bg.naturalWidth){g.globalAlpha=1;g.drawImage(bg,-14,-10,w+28,h+20)}g.restore();
  g.fillStyle=rgr(g,w*.5,h*.45,10,w*.75,'#0000','#00000088');g.fillRect(0,0,w,h);g.fillStyle=a+'38';g.fillRect(0,0,w,h);
  /* light shafts behind the boss */
  g.save();g.globalCompositeOperation='lighter';for(let i=0;i<6;i++){const an=-Math.PI/2+(i-2.5)*.17+Math.sin(t*.5+i)*.03;g.globalAlpha=.07+.04*Math.sin(t*1.1+i*1.9);g.fillStyle=au.rim;g.beginPath();g.moveTo(w*.5,h*.34);g.lineTo(w*.5+Math.cos(an)*w*1.3-46,h*.34+Math.sin(an)*w*1.3);g.lineTo(w*.5+Math.cos(an)*w*1.3+46,h*.34+Math.sin(an)*w*1.3);g.fill()}g.restore();
  const pul=1+Math.sin(t*1.7)*.07;g.save();g.globalCompositeOperation='lighter';glow(g,w*.5,h*.5,w*.52*pul,a+'77');glow(g,w*.5,h*.46,w*.26*pul,au.rim+'44');g.restore();
  /* the ground */
  g.save();g.translate(w*.5,h*.9);g.fillStyle='#000a';g.beginPath();g.ellipse(0,0,w*.3,h*.04,0,0,TAU);g.fill();g.restore();
  g.save();g.translate(w*.5-(M.cx||0)*s,h*.9);g.scale(s,s);try{M.d(g,t,{lg:0})}catch(e){}g.restore();
  /* rim light: a cool sheen on whatever the boss is */
  g.save();g.globalCompositeOperation='source-atop';g.restore();
  g.save();g.globalCompositeOperation='lighter';g.globalAlpha=.55;const fg=g.createLinearGradient(0,h*.88,0,h);fg.addColorStop(0,a+'00');fg.addColorStop(1,a+'66');g.fillStyle=fg;g.fillRect(0,h*.88,w,h*.12);g.restore();
  /* mist crawling along the floor */
  for(let k=0;k<2;k++){g.globalAlpha=.28-k*.08;const q=g.createLinearGradient(0,h*(.78+k*.07),0,h*(.98));q.addColorStop(0,'#0000');q.addColorStop(1,shade(a,.35)+'cc');g.fillStyle=q;g.beginPath();g.moveTo(0,h);for(let x=0;x<=w;x+=16)g.lineTo(x,h*(.86+k*.05)+Math.sin(x*.013+t*(.8+k*.4)+k*2)*8);g.lineTo(w,h);g.fill()}g.globalAlpha=1;
  /* weather of the boss's world */
  const f=au.fx;for(let i=0;i<34;i++){const r1=rnd(i+sd),r2=rnd(i+sd+50),r3=rnd(i+sd+99);
   if(f==='ember'){const u=(t*(.1+r1*.12)+r2)%1,x=r3*w+Math.sin(t+i)*14,y=h-u*h*1.05;g.globalAlpha=Math.sin(u*Math.PI)*.95;g.save();g.globalCompositeOperation='lighter';glow(g,x,y,6+r1*8,'#ff8a2a');g.restore();g.fillStyle='#ffe0a0';g.fillRect(x-1,y-1,2.4,2.4)}
   else if(f==='snow'){const x=(r1*w+t*(10+r3*18)+Math.sin(t*.9+i)*16)%w,y=(r2*h+t*(30+r3*40))%h;g.globalAlpha=.4+r3*.5;g.fillStyle='#fff';g.beginPath();g.arc(x,y,1.2+r1*2.2,0,TAU);g.fill()}
   else if(f==='bubble'){const u=(t*(.06+r1*.08)+r2)%1,x=r3*w+Math.sin(t*1.4+i)*10,y=h-u*h*1.1;g.globalAlpha=.65*(1-u);g.strokeStyle='#cffcff';g.lineWidth=1.2;g.beginPath();g.arc(x,y,2+r1*5,0,TAU);g.stroke()}
   else if(f==='wisp'){const u=(t*(.05+r1*.06)+r2)%1,x=r3*w+Math.sin(t*.8+i*2)*24,y=h*.95-u*h*.9;g.globalAlpha=Math.sin(u*Math.PI)*.8;g.save();g.globalCompositeOperation='lighter';glow(g,x,y,9+r1*10,i%2?'#9affc8':'#c8a0ff');g.restore()}
   else if(f==='spore'){const x=(r1*w+Math.sin(t*.6+i*1.7)*30+t*5)%w,y=(r2*h+t*(6+r3*10))%h;g.globalAlpha=.25+.6*Math.abs(Math.sin(t+i));g.save();g.globalCompositeOperation='lighter';glow(g,x,y,6+r3*5,'#ffe86a');g.restore()}
   else{const u=(t*(.04+r1*.05)+r2)%1,x=(r3*w+u*70)%w,y=u*h,sw=Math.sin(t*2+i)*.7;g.globalAlpha=Math.sin(u*Math.PI)*.8;g.save();g.translate(x,y);g.rotate(t+i);g.fillStyle=i%2?'#a8e860':'#d8c058';g.beginPath();g.ellipse(0,0,4+r1*3,2*(1+sw*.3),0,0,TAU);g.fill();g.restore()}}
  g.globalAlpha=1;
  const vg=g.createRadialGradient(w/2,h*.5,h*.35,w/2,h*.5,w*.78);vg.addColorStop(0,'#0000');vg.addColorStop(1,'#000000c0');g.fillStyle=vg;g.fillRect(0,0,w,h)}}
