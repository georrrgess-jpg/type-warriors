
/* ===== PETS & EGGS FX: egg descriptions, richer icons, a livelier stage, petting combos, eggs that stir when ready ===== */

/* ---------- egg descriptions ---------- */
const PEGGD={
 r:{tag:'Sapphire runes hum softly around a sleeping Rare companion.',
  lore:'Runeshell eggs are wrapped in glowing sapphire runes that keep a Rare companion safe while it sleeps. The runes brighten and hum when the little one inside is ready to meet you.'},
 l:{tag:'A royal egg, crowned in gold, with a heart that glows from within.',
  lore:'Crownheart eggs are the rarest finds in the hall. Beneath the golden crown beats a glowing heart, and inside waits one of the Legendary companions. Each one is a real event to hatch.'}};

/* ---------- icons: two-tone, with highlights; they still follow the text colour ---------- */
Object.assign(PTICO,{
 paw:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 11.2c3.2 0 6 3 6 5.9 0 2.2-1.7 3.4-3.4 3.1-1.1-.2-1.7-.7-2.6-.7s-1.5.5-2.6.7C7.7 20.5 6 19.3 6 17.1c0-2.9 2.8-5.9 6-5.9z" fill="currentColor"/><ellipse cx="5.2" cy="9.6" rx="2.1" ry="2.7" transform="rotate(-18 5.2 9.6)" fill="currentColor"/><ellipse cx="9.3" cy="5.6" rx="2.2" ry="2.9" transform="rotate(-6 9.3 5.6)" fill="currentColor"/><ellipse cx="14.7" cy="5.6" rx="2.2" ry="2.9" transform="rotate(6 14.7 5.6)" fill="currentColor"/><ellipse cx="18.8" cy="9.6" rx="2.1" ry="2.7" transform="rotate(18 18.8 9.6)" fill="currentColor"/><g fill="#fff" opacity=".45"><ellipse cx="10" cy="14.2" rx="1.6" ry="1"/><ellipse cx="8.7" cy="4.4" rx=".7" ry="1"/><ellipse cx="14.1" cy="4.4" rx=".7" ry="1"/></g></svg>',
 egg:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 1.8c4.6 0 7.4 8 7 13.3-.4 4.5-3.3 7.1-7 7.1s-6.6-2.6-7-7.1C4.6 9.8 7.4 1.8 12 1.8z" fill="currentColor"/><path d="M5.3 12.6l2.3 1.6 2.2-1.6 2.2 1.6 2.2-1.6 2.2 1.6 2.3-1.6" stroke="#000" stroke-opacity=".38" stroke-width="1.7" fill="none" stroke-linejoin="round" stroke-linecap="round"/><path d="M9 5.2c-1.3 1.4-2.1 3.6-2.3 5.6" stroke="#fff" stroke-opacity=".6" stroke-width="1.7" fill="none" stroke-linecap="round"/><circle cx="15.6" cy="17.2" r="1" fill="#fff" opacity=".4"/></svg>',
 trail:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4.5 21c3-1 3.5-3.5 6.5-4.5s5.5.5 7.5-2.5-1-5.5 1-8" stroke="currentColor" stroke-opacity=".45" stroke-width="2" stroke-dasharray="2.2 2.6" fill="none" stroke-linecap="round"/><path d="M18 2.2v8.6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M18.6 2.6h3.6l-1.1 1.9 1.1 1.9h-3.6z" fill="currentColor"/><circle cx="4.6" cy="20.6" r="2.2" fill="currentColor"/><circle cx="4" cy="20" r=".7" fill="#fff" opacity=".55"/></svg>',
 swd:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20.5 3.5l-1 4.4-9.3 9.3-2.4-2.4 9.3-9.3z" fill="currentColor"/><path d="M19.7 4.3l-9.9 9.9" stroke="#fff" stroke-opacity=".5" stroke-width="1"/><path d="M5.6 13.2l5.2 5.2" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/><path d="M7.6 16.4l-3.8 3.8" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/><circle cx="3.4" cy="20.6" r="1.6" fill="currentColor"/></svg>',
 pen:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 20l1.1-4.9L15.7 4.5a2 2 0 0 1 2.8 0l1 1a2 2 0 0 1 0 2.8L8.9 18.9z" fill="currentColor"/><path d="M14 6.2l3.8 3.8" stroke="#000" stroke-opacity=".4" stroke-width="1.6"/><path d="M5.6 16.6l1.8 1.8" stroke="#fff" stroke-opacity=".55" stroke-width="1.4"/></svg>',
 lock:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7.5 10.5V8a4.5 4.5 0 0 1 9 0v2.5" stroke="currentColor" stroke-width="2.4" fill="none"/><rect x="4.5" y="10.5" width="15" height="11" rx="3" fill="currentColor"/><circle cx="12" cy="15.3" r="1.7" fill="#000" fill-opacity=".45"/><path d="M12 16.2v2.2" stroke="#000" stroke-opacity=".45" stroke-width="1.6" stroke-linecap="round"/><path d="M6.6 12.6h5" stroke="#fff" stroke-opacity=".4" stroke-width="1.3" stroke-linecap="round"/></svg>',
 chk:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.6 4.6L19 7.4" stroke="currentColor" stroke-width="3.4" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>',
 play:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7.5 4.4c0-.9 1-1.4 1.7-.9l10.1 7.1c.6.5.6 1.4 0 1.8L9.2 19.5c-.7.5-1.7 0-1.7-.9z" fill="currentColor"/><path d="M9.6 7.2v4" stroke="#fff" stroke-opacity=".5" stroke-width="1.4" stroke-linecap="round"/></svg>',
 coin:'<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12.6" r="9.2" fill="#b07a1e"/><circle cx="12" cy="11.6" r="9.2" fill="#ffd45a"/><circle cx="12" cy="11.6" r="6.6" fill="none" stroke="#c8901a" stroke-width="1.4"/><path d="M12 7.6v8" stroke="#9a661a" stroke-width="2.2" stroke-linecap="round"/><path d="M6.4 8.2a6.4 6.4 0 0 1 4.2-3" stroke="#fff" stroke-opacity=".75" stroke-width="1.6" fill="none" stroke-linecap="round"/></svg>',
 heart:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20.6s-8-4.8-8-10.7A4.4 4.4 0 0 1 12 7.3a4.4 4.4 0 0 1 8 2.6c0 5.9-8 10.7-8 10.7z" fill="currentColor"/><path d="M7.4 8.4a2.4 2.4 0 0 0-1.6 2" stroke="#fff" stroke-opacity=".6" stroke-width="1.5" fill="none" stroke-linecap="round"/></svg>',
 star:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.6l2.8 5.9 6.4.8-4.7 4.4 1.2 6.4L12 17l-5.7 3.1 1.2-6.4-4.7-4.4 6.4-.8z" fill="currentColor"/><path d="M12 5.8l-1.5 3.3" stroke="#fff" stroke-opacity=".55" stroke-width="1.4" stroke-linecap="round"/></svg>'});

/* ---------- small shared helpers ---------- */
const ptNow=()=>performance.now()/1000;
const ptBack=k=>{const c1=1.70158,c3=c1+1,x=k-1;return 1+c3*x*x*x+c1*x*x};
function ptFxStep(g,FX,dt){for(let i=FX.length-1;i>=0;i--){const p=FX[i];p.l-=dt;if(p.l<=0){FX.splice(i,1);continue}
  p.vy+=(p.g||0)*dt;p.vx*=Math.pow(p.dr||.5,dt);p.x+=p.vx*dt;p.y+=p.vy*dt;p.r=(p.r||0)+dt*3;const a=Math.min(1,p.l/(p.l0*.5));g.globalAlpha=a;
  if(p.k==='heart')pHeart(g,p.x+Math.sin(p.l*7+i)*4,p.y,p.s,p.c,2);
  else if(p.k==='dust'){g.fillStyle=p.c;g.beginPath();g.arc(p.x,p.y,p.s*(1.6-a*.6),0,TAU);g.fill()}
  else if(p.k==='glow'){pGlow(g,p.x,p.y,p.s*2.6,p.c,.55*a);g.fillStyle='#fff';g.fillRect(p.x-1,p.y-1,2,2)}
  else{g.save();g.translate(p.x,p.y);g.rotate(p.r*.3);pStar4(g,0,0,p.s,p.c);g.restore()}
  g.globalAlpha=1}}
function ptBurst(FX,x,y,n,c,o){o=o||{};for(let i=0;i<n;i++){const a=o.up?-Math.PI/2+(Math.random()-.5)*(o.sp||2.2):Math.random()*TAU,v=(o.v||160)*(.4+Math.random()*.8),l=(o.l||1)*(.7+Math.random()*.5);
  FX.push({x:x+(Math.random()-.5)*(o.jx||0),y,vx:Math.cos(a)*v,vy:Math.sin(a)*v*(o.fl||1)-(o.lift||0),l,l0:l,c:Array.isArray(c)?c[i%c.length]:c,s:(o.s||5)*(.6+Math.random()*.7),k:o.k||'star',g:o.g==null?140:o.g,dr:o.dr})}}
function ptRings(g,R,dt){g.save();g.globalCompositeOperation='lighter';for(let i=R.length-1;i>=0;i--){const r=R[i];r.t+=dt;const v=r.t/(r.d||.8);if(v>=1){R.splice(i,1);continue}if(v<0)continue;
  g.beginPath();g.ellipse(r.x,r.y,(r.r0||20)+pS(v)*r.max,((r.r0||20)+pS(v)*r.max)*(r.fl||.28),0,0,TAU);g.strokeStyle=ptHexA(r.c,(1-v)*.85);g.lineWidth=(r.w||6)*(1-v)+1.5;g.stroke()}g.restore()}
function ptTexts(g,TX,dt){for(let i=TX.length-1;i>=0;i--){const q=TX[i];q.a+=dt;const k=q.a/(q.d||1.3);if(k>=1){TX.splice(i,1);continue}
  const s=k<.18?ptBack(k/.18):1,al=k>.7?1-(k-.7)/.3:1;g.save();g.globalAlpha=al;g.translate(q.x,q.y-k*46);g.scale(s,s);g.font=`800 ${q.sz||24}px Poppins,system-ui,sans-serif`;g.textAlign='center';g.textBaseline='middle';
  g.lineJoin='round';g.lineWidth=6;g.strokeStyle='#120a24';g.strokeText(q.s,0,0);g.fillStyle=q.c||'#fff';g.fillText(q.s,0,0);g.restore()}}

/* ---------- the pet stage: pop-in on select, signature motes, petting with combos, equip celebration ---------- */
function ptStage(cv){const g=cv.getContext('2d'),w=cv.width,h=cv.height,bg=ptStageBG(w,h),fy=h*.82,px=w*.31,py=fy+8;
 let last=-1,an=null,pop=null,hop=null,lt=ptNow(),combo=0,lastPet=0,born=ptNow();const FX=[],R=[],TX=[];
 PTX.play=(pose,dur)=>{an={pose,dur,t:ptNow()}};
 const sig=id=>(typeof PSIG!=='undefined'&&PSIG[id]?PSIG[id][0]:'#ffd45a');
 const geo=id=>{const D=PDEF[id],bx=D.box||[-60,-110,120,115],ps=D.hover?1.25:1.3;return{bx,ps,top:py+bx[1]*ps,mid:py+(bx[1]+bx[3]*.5)*ps,wd:bx[2]*ps}};
 const tone=(f,d,v,ty)=>{try{beep(f,d,ty||'sine',v)}catch(e){}};
 cv.style.cursor='pointer';cv.title='Tap your companion to pet it';
 cv.onclick=e=>{const id=PTX.sel;if(!id||!petOwned(id)||ptRM())return;const r=cv.getBoundingClientRect(),ex=(e.clientX-r.left)*w/r.width;if(ex>w*.5)return;
  const t=ptNow(),G=geo(id),c=sig(id);combo=t-lastPet<1.5?combo+1:1;lastPet=t;PTX.petted=1;hop={t};TX.length=0;
  ptBurst(FX,px,G.top+18,3+Math.min(combo,6),['#ff8ab4','#ff6a9a','#ffb0cc'],{k:'heart',up:1,sp:1.4,v:120,g:-30,l:1.1,s:8,jx:40,dr:.4});
  ptBurst(FX,px,G.mid,6,[c,'#ffffff'],{v:170,g:60,l:.7,s:6});
  if(combo%5===0){an={pose:'ability',dur:1.9,t};R.push({x:px,y:py,t:0,c,max:G.wd*1.3+90,w:9,d:.9},{x:px,y:py,t:-.12,c:'#ffffff',max:G.wd*1.1+60,w:5,d:.9});
   ptBurst(FX,px,G.mid,28,[c,'#ffffff','#ffd45a','#ff8ab4'],{v:320,g:200,l:1.4,s:7});TX.push({s:['So happy!','Best friends!','Pure joy!'][(combo/5-1)%3|0],x:px,y:G.top-26,a:0,c:'#ffd45a',sz:28,d:1.6});
   [0,90,180,270].forEach((d,i)=>setTimeout(()=>tone([784,988,1175,1568][i],.09,.16),d))}
  else{an={pose:'greet',dur:1.3,t};TX.push({s:combo>1?`♥ ×${combo}`:'♥',x:px+(Math.random()-.5)*30,y:G.top-14,a:0,c:'#ff8ab4',sz:combo>1?24:28,d:1.1});tone(620+Math.min(combo,8)*45,.05,.18);setTimeout(()=>tone(880+Math.min(combo,8)*45,.07,.14),80)}};
 return t=>{const now=ptNow(),dt=Math.min(.05,Math.max(0,now-lt));lt=now;g.setTransform(1,0,0,1,0,0);g.drawImage(bg,0,0);const rm=ptRM(),tt=rm?1.2:t;
  ptLantern(g,w*.2,h*.5,tt);ptLantern(g,w*.8,h*.5,tt+1.3);
  for(let i=0;i<6;i++){const a=tt*.4+i*1.7,x=w*(.2+.6*((i*.618)%1))+Math.sin(a)*20,y=h*(.35+.3*((i*.38)%1))+Math.cos(a*1.3)*12,al=Math.max(0,Math.sin(tt*1.2+i));pGlow(g,x,y,8,'#d8ff7a',.5*al)}
  const id=PTX.sel;
  if(id!==last){last=id;if(id&&!rm){pop={t:now};const G=geo(id),own=petOwned(id);
    ptBurst(FX,px,py,10,'rgba(200,190,240,.35)',{k:'dust',fl:.25,v:130,g:-10,l:.7,s:6,dr:.2});
    if(own){an={pose:'greet',dur:1.6,t:now};ptBurst(FX,px,G.mid,12,[sig(id),'#ffffff'],{v:200,g:80,l:.9,s:6});R.push({x:px,y:py,t:0,c:sig(id),max:G.wd*.9+40,w:6,d:.7})}}}
  /* an equip from the details panel (or a hatch reveal) lands here as a celebration */
  if(id&&PTX.cele&&PTX.cele.id===id&&now-PTX.cele.t<2.5&&!rm&&petOwned(id)){PTX.cele=null;const G=geo(id);an={pose:'ability',dur:1.9,t:now};
   R.push({x:px,y:py,t:0,c:'#ffd45a',max:G.wd*1.4+110,w:10,d:1},{x:px,y:py,t:-.15,c:'#ffffff',max:G.wd*1.2+80,w:5,d:1});
   ptBurst(FX,px,G.mid,34,['#ffd45a','#fff2c0',sig(id),'#ffffff'],{v:340,g:240,l:1.5,s:7});TX.push({s:'Ready for adventure!',x:Math.max(150,px),y:G.top-30,a:0,c:'#ffd45a',sz:26,d:1.8})}
  /* knight */const ks=2.05;g.save();g.translate(w*.64,fy);g.fillStyle='#00000066';g.beginPath();g.ellipse(0,4,70,12,0,0,TAU);g.fill();g.scale(ks,ks);try{drawHero(g,{arm:P.armor,wp:P.weapon,col:P.col,t:tt})}catch(e){}g.restore();
  if(!id){ptFxStep(g,FX,dt);return}
  const D=PDEF[id],own=petOwned(id),G=geo(id);let ps=G.ps,dy=0,sx=1,sy=1;
  if(pop){const k=(now-pop.t)/.55;if(k>=1)pop=null;else{const s=.45+.55*ptBack(Math.max(0,k));sx*=s;sy*=s}}
  if(hop){const k=(now-hop.t)/.42;if(k>=1)hop=null;else{dy=-Math.sin(k*Math.PI)*16;const q=k<.15?(1-k/.15)*.1:k>.85?((k-.85)/.15)*.08:0;sy*=1-q;sx*=1+q*.8}}
  let pose='idle',u=0;if(an){const k=(now-an.t)/an.dur;if(k>=1)an=null;else{pose=an.pose;u=k}}
  /* the floor ring under the companion breathes in its signature colour */
  if(own&&!rm){g.save();g.globalCompositeOperation='lighter';const pu=.5+.5*Math.sin(tt*2);g.beginPath();g.ellipse(px,py+2,G.wd*.55+8*pu,(G.wd*.55+8*pu)*.22,0,0,TAU);g.strokeStyle=ptHexA(sig(id),.16+.12*pu);g.lineWidth=3;g.stroke();g.restore()}
  const lk=own?petLook(id):{};
  if(own){g.save();g.translate(px,py+dy);g.scale(ps*sx,ps*sy);petDraw(g,id,Object.assign({t:tt,pose,u},lk));if(pose==='greet'&&lk.cel)petCelFx(g,id,u,tt,-50,70);g.restore()}
  else{const pu=rm?0:Math.sin(tt*2.2);pGlow(g,px,G.mid,90+pu*8,'#8a7aff',.22);g.save();g.fillStyle='#00000066';g.beginPath();g.ellipse(px,py+2,40*ps,8,0,0,TAU);g.fill();g.restore();
   g.save();g.translate(px,py);g.scale(sx,sy);g.translate(-px,-py);ptSil(g,id,px,py,ps,{t:1.2});g.restore();
   const qs=1+pu*.06;g.save();g.translate(px,py-50*ps-14);g.scale(qs,qs);g.fillStyle='#ffffffdd';g.font='800 46px Poppins,system-ui';g.textAlign='center';g.textBaseline='middle';g.shadowColor='#8a7aff';g.shadowBlur=18;g.fillText('?',0,0);g.restore()}
  /* signature motes drifting around the companion */
  if(own&&!rm){const c=sig(id);for(let i=0;i<6;i++){const a=tt*.55+i*TAU/6,rx=G.wd*.62+14,x=px+Math.cos(a)*rx,y=G.mid+Math.sin(a)*rx*.28-Math.sin(tt*1.3+i)*10,front=Math.sin(a)>0,al=(front?.55:.3)*(.6+.4*Math.sin(tt*2+i*1.3));pGlow(g,x,y,9,c,al);g.fillStyle=ptHexA('#ffffff',al);g.fillRect(x-1,y-1,2,2)}}
  /* first visit hint */
  if(own&&!rm&&!PTX.petted&&!an&&now-born>1.4){const al=Math.min(1,(now-born-1.4)*2)*(.75+.25*Math.sin(tt*3)),y=G.top-34+Math.sin(tt*2.4)*4;g.save();g.globalAlpha=al;g.font='700 16px Poppins,system-ui';g.textAlign='center';g.textBaseline='middle';const tw=g.measureText('Tap to pet').width+40;
   g.beginPath();g.roundRect(px-tw/2,y-15,tw,30,15);g.fillStyle='#120a2ce6';g.fill();g.strokeStyle='#ff8ab4';g.lineWidth=2;g.stroke();pHeart(g,px-tw/2+16,y+1,6,'#ff8ab4',0);g.fillStyle='#fff';g.fillText('Tap to pet',px+8,y+1);g.restore()}
  ptRings(g,R,dt);ptFxStep(g,FX,dt);ptTexts(g,TX,dt)}}
{const e0=petEquip;petEquip=function(id){const r=e0.apply(this,arguments);if(petOwned(id))PTX.cele={id,t:ptNow()};return r}}

/* ---------- the egg stage: eggs you own stir, wobble and sparkle; tap the egg to feel it move ---------- */
function ptHatchStage(cv){const w=520,h=560,k=PTK(),g=cv.getContext('2d'),bg=ptHatchBG(w,h);cv.width=w*k;cv.height=h*k;const fr=PTX.eggFrom;PTX.eggFrom=null;
 const S0={k:PTX.egg,from:fr&&fr!==PTX.egg?fr:null,t0:ptNow(),ac:(fr||PTX.egg)==='l'?[255,194,58]:[85,181,255]};
 const FX=[],R=[],TX=[];let tap=null,lt=ptNow(),spawn=0,pulse=0;
 PTX.eggSwap=kk=>{if(kk===S0.k)return;S0.from=S0.k;S0.k=kk;S0.t0=ptNow()};
 const ex0=w/2,ey0=h*.6-12,ES=1.3;
 const lantern=(x,y,t)=>{const f=.82+.18*Math.sin(t*7+x)+.08*Math.sin(t*13);pGlow(g,x,y,90*f,'#ffb04a',.28);g.save();g.translate(x,y);g.beginPath();g.moveTo(-14,-18);g.lineTo(0,-30);g.lineTo(14,-18);g.closePath();g.fillStyle='#3a2410';g.fill();g.beginPath();g.roundRect(-13,-18,26,34,4);g.fillStyle=ptHex('#ffcf6a',.85+.15*f);g.fill();g.strokeStyle='#3a2410';g.lineWidth=3;g.stroke();g.beginPath();g.moveTo(0,-18);g.lineTo(0,16);g.moveTo(-13,0);g.lineTo(13,0);g.lineWidth=2;g.stroke();g.beginPath();g.roundRect(-15,16,30,5,2);g.fillStyle='#3a2410';g.fill();g.restore()};
 const ready=()=>(P.eggs[S0.k]|0)>0;
 cv.style.cursor='pointer';
 cv.onclick=e=>{const r=cv.getBoundingClientRect(),x=(e.clientX-r.left)*w/r.width,y=(e.clientY-r.top)*h/r.height;if(Math.abs(x-ex0)>90||y<ey0-ES*150||y>ey0+20)return;
  const rd=ready(),ac=S0.k==='l'?'#ffc23a':'#5ff0ff';tap={t:ptNow(),s:rd?1:.55};
  ptBurst(FX,ex0,ey0-90,rd?16:7,[ac,'#ffffff'],{v:rd?220:130,g:120,l:.9,s:6});R.push({x:ex0,y:ey0+4,t:0,c:ac,max:120,w:6,d:.7,fl:.24});
  const msg=rd?['Something stirs inside…','It wiggled back!','Someone wants to meet you!','Tap Hatch to say hello!'][Math.random()*4|0]:`Get a ${PRAR[S0.k].egg} egg to hatch one`;
  TX.length=0;TX.push({s:msg,x:ex0,y:ey0-ES*150+22,a:0,c:rd?'#fff2c0':'#c4badf',sz:rd?22:18,d:1.6});
  try{if(rd){beep(700,.05,'sine',.16);setTimeout(()=>beep(1040,.06,'sine',.14),70);setTimeout(()=>beep(1320,.05,'sine',.1),150)}else beep(300,.08,'triangle',.14)}catch(x){}};
 return t0=>{const rm=ptRM(),t=rm?1:t0,now=ptNow(),dt=Math.min(.05,Math.max(0,now-lt));lt=now;g.setTransform(k,0,0,k,0,0);g.drawImage(bg,0,0,w,h);
  const tgt=S0.k==='l'?[255,194,58]:[85,181,255];for(let i=0;i<3;i++)S0.ac[i]+=(tgt[i]-S0.ac[i])*(rm?1:.12);const ac='#'+S0.ac.map(v=>Math.round(v).toString(16).padStart(2,'0')).join('');const rd=ready();
  lantern(w*.2,h*.2+6,t);lantern(w*.8,h*.2+6,t+1.4);for(const x of[w*.18,w*.82]){const f=rm?0:Math.sin(t*9+x)*1.2;pGlow(g,x,h*.56-8,22,'#ffb04a',.4);g.fillStyle='#ffcf6a';g.beginPath();g.ellipse(x+f*.4,h*.56-7,3.4,7,0,0,TAU);g.fill()}
  g.save();g.globalCompositeOperation='lighter';let q=g.createLinearGradient(0,0,0,h*.8);q.addColorStop(0,ptHex(ac,0));q.addColorStop(1,ptHex(ac,rd?.2:.12));g.fillStyle=q;g.beginPath();g.moveTo(w/2-40,0);g.lineTo(w/2+40,0);g.lineTo(w/2+120,h*.62);g.lineTo(w/2-120,h*.62);g.closePath();g.fill();g.restore();
  pGlow(g,w/2,h*.44,170,ac,(rd?.36:.24)+.07*Math.sin(t*1.4));
  if(!rm)for(let i=0;i<6;i++){const u=((t*.08+i/6)%1),x=w/2+Math.sin(i*2.3+t*.4)*120*(.6+u*.4),y=h*.58-u*h*.5,a=Math.sin(u*Math.PI)*.6;g.save();g.translate(x,y);g.globalAlpha=a;g.fillStyle=ac;g.beginPath();g.ellipse(0,2,4,3.4,0,0,TAU);g.fill();for(const [dx,dy] of[[-4,-3],[0,-5],[4,-3]]){g.beginPath();g.ellipse(dx,dy,1.5,1.9,0,0,TAU);g.fill()}g.restore()}
  /* a ready egg sends pulses across the cushion and sheds sparkles */
  if(rd&&!rm){pulse+=dt;if(pulse>1.6){pulse=0;R.push({x:ex0,y:ey0+6,t:0,c:ac,max:110,r0:30,w:4,d:1.3,fl:.22})}
   spawn+=dt*5;while(spawn>1){spawn--;const a=Math.random()*TAU,rr=40+Math.random()*30;FX.push({x:ex0+Math.cos(a)*rr,y:ey0-80+Math.sin(a)*rr*1.3,vx:(Math.random()-.5)*20,vy:-30-Math.random()*40,l:1.2,l0:1.2,c:Math.random()<.4?'#ffffff':ac,s:3+Math.random()*3,k:Math.random()<.5?'star':'glow',g:-10,dr:.6})}}
  ptRings(g,R,dt);
  /* the egg: breathes when asleep; when it's yours it rocks every few seconds, and a tap makes it wiggle */
  const lean=kk=>{let L=0,hy=0;if(rm)return[0,0];if(kk===S0.k&&rd){const ph=t%3.4;if(ph<.9){const v=ph/.9;L+=Math.sin(v*Math.PI*4)*(1-v)*.1;hy=-Math.sin(Math.min(1,v*2.2)*Math.PI)*5}}
   if(tap&&kk===S0.k){const v=(now-tap.t)/.9;if(v>=1)tap=null;else{L+=Math.sin(v*Math.PI*6)*(1-v)*.17*tap.s;hy-=Math.sin(Math.min(1,v*3)*Math.PI)*9*tap.s}}return[L,hy]};
  const eggAt=(kk,a,dy)=>{if(a<=0)return;const bob=rm?0:Math.sin(t*1.2)*3,[L,hy]=lean(kk),gl=kk===S0.k&&rd?.45+.3*Math.sin(t*2.4):.18+.1*Math.sin(t*1.6);g.save();g.globalAlpha=a;g.translate(ex0,ey0+bob+dy+hy);g.scale(ES,ES);
   if(L){g.save();g.scale(1/ES,1/ES);g.fillStyle='#00000055';g.beginPath();g.ellipse(0,-hy,46,8,0,0,TAU);g.fill();g.restore()}
   eggDraw(g,kk,{t,glow:gl,lean:L,noSh:L?1:0});g.restore()};
  const v=S0.from&&!rm?Math.min(1,(now-S0.t0)/.32):1;if(v<1){eggAt(S0.from,1-v,0);eggAt(S0.k,v,(1-pS(v))*-24)}else{S0.from=null;eggAt(S0.k,1,0)}
  ptFxStep(g,FX,dt);ptTexts(g,TX,dt)}}

/* ---------- roster cards: the companion wakes up and greets you on hover ---------- */
function ptCardWake(card){const c=card.querySelector('canvas[data-pc]');if(!c||card._wk||ptRM())return;const id=c.dataset.pc;if(!petOwned(id))return;card._wk=1;const t0=ptNow();
 const step=()=>{if(!card.isConnected||!card._wk){if(card.isConnected&&!card.classList.contains('on'))try{petFit(c,id,Object.assign({t:1.2},petLook(id)))}catch(e){}return}
  const k=(ptNow()-t0)/1.5;try{petFit(c,id,Object.assign(k<1?{t:ptNow(),pose:'greet',u:k}:{t:ptNow()},petLook(id)))}catch(e){}requestAnimationFrame(step)};requestAnimationFrame(step)}
{const b0=ptPetsBind;ptPetsBind=function(){const r=b0.apply(this,arguments);try{
 ov.querySelectorAll('.ptc').forEach(card=>{card.addEventListener('pointerenter',()=>{if(!card.classList.contains('on'))ptCardWake(card)});card.addEventListener('pointerleave',()=>{card._wk=0});card.addEventListener('focus',()=>{if(!card.classList.contains('on'))ptCardWake(card)});card.addEventListener('blur',()=>{card._wk=0})});
 }catch(e){}return r}}

/* ---------- eggs tab: description, a lively egg on each card, and a hatch button that calls to you ---------- */
{const b0=ptEggsBind;ptEggsBind=function(){const r=b0.apply(this,arguments);try{const k=PTX.egg,E=PRAR[k],D=PEGGD[k],L=petList(k),left=petPool(k).length;
 const tt=ov.querySelector('.phx-tt');if(tt&&!tt.querySelector('.phx-tag'))tt.insertAdjacentHTML('beforeend',`<p class="phx-tag">${D.tag}</p>`);
 const act=ov.querySelector('.phx-act'),sh=ov.querySelector('.phx-sh2');
 if(act){if(sh)sh.remove();act.insertAdjacentHTML('beforeend',`<div class="phx-about phx-ab-${k}"><div class="phx-abh"><i>${PTICO.egg}</i><b>About ${E.egg} eggs</b></div><p>${D.lore}</p>
   <div class="phx-facts"><span>${PTICO.star}${L.length} ${E.n} companions</span><span>${left?`${PTICO.paw}${left} left to find`:`${PTICO.chk}All found`}</span><span title="Eggs only hatch companions you don't have yet">${PTICO.chk}No repeats</span></div></div>`)}
 /* egg cards come alive: the ones you own rock gently, the chosen one glows */
 ov.querySelectorAll('canvas[data-et]').forEach(c=>{const kk=c.dataset.et,has=(P.eggs[kk]|0)>0,sd=kk==='l'?1.3:0;if(!has&&kk!==PTX.egg)return;
  LIVE.push({cv:c,slow:3,fn:t=>{if(ptRM())return;const on=kk===PTX.egg,ph=(t+sd)%3.4,v=ph/.9,L=has&&ph<.9?Math.sin(v*Math.PI*4)*(1-v)*.09:0;try{eggFit(c,kk,{t,noSh:1,lean:L,glow:(on?.3:.1)+(has?.2+.15*Math.sin(t*2.4):0)})}catch(e){}}})});
 const ht=$('phxht');if(ht)ht.classList.add('phx-call');
 }catch(e){}return r}}

/* ---------- hatch reveal: show collection progress and when the next egg arrives ---------- */
{const h0=ptHatchScene;ptHatchScene=function(id,k,opt){const r=h0.apply(this,arguments);try{const rv=$('ptrv');if(rv){const mo=new MutationObserver(()=>{const ms=rv.querySelector('.phc-ms');if(!ms||rv.querySelector('.phc-prog'))return;mo.disconnect();
   const own=PIDS.filter(petOwned).length,nx=petNextEgg(),pc=own/PIDS.length*100;
   (rv.querySelector('.phc-b')||ms).insertAdjacentHTML('afterend',`<div class="phc-prog"><div><span>${PTICO.paw} Collection</span><b>${own} / ${PIDS.length}</b></div><span class="phc-pb"><i style="--w:${pc}%"></i></span>${own<PIDS.length&&nx?`<small>${PTICO.trail} Next ${PRAR[nx.k].egg} egg in <b>${nx.left}</b> adventure${nx.left===1?'':'s'}</small>`:own>=PIDS.length?`<small>${PTICO.star} Every companion discovered!</small>`:''}</div>`)});
  mo.observe(rv,{childList:true,subtree:true})}}catch(e){}return r}}

{const st=document.createElement('style');st.textContent=`
/* icons */
.ptti svg,.ptgo svg,.ptsoft svg{filter:drop-shadow(0 1px 0 #0006)}
/* roster cards */
.ptc{transition:transform .22s cubic-bezier(.3,1.5,.5,1),border-color .18s,box-shadow .2s!important}
.ptc:not(.unk):hover{transform:translateY(-4px) scale(1.03)!important;z-index:2}
.ptc-r:not(.unk):hover{box-shadow:0 8px 18px #000a,0 0 16px #3a8aff55!important}
.ptc-l:not(.unk):hover{box-shadow:0 8px 18px #000a,0 0 18px #ffb02a66!important}
.ptc:active{transform:translateY(-1px) scale(.97)!important}
.ptc canvas{transition:transform .25s cubic-bezier(.3,1.6,.5,1)}.ptc:not(.unk):hover canvas{transform:translateY(-2px)}
.ptc-l:not(.unk){overflow:hidden}
.ptc-l:not(.unk)::after{content:"";position:absolute;top:-20%;bottom:-20%;left:0;width:40%;background:linear-gradient(100deg,#fff0 0%,#ffe9a833 50%,#fff0 100%);transform:translateX(-160%) skewX(-12deg);animation:ptsheen 5s ease-in-out infinite;pointer-events:none}
.ptc-l:not(.unk):nth-child(2n)::after{animation-delay:1.6s}.ptc-l:not(.unk):nth-child(3n)::after{animation-delay:3.1s}
@keyframes ptsheen{0%,62%{transform:translateX(-160%) skewX(-12deg)}86%,100%{transform:translateX(330%) skewX(-12deg)}}
.ptc .pteq{animation:pteqin .4s cubic-bezier(.3,1.8,.5,1) both}@keyframes pteqin{from{transform:scale(0) rotate(-40deg)}}
.ptc.unk .ptq{animation:ptqb 2.4s ease-in-out infinite}@keyframes ptqb{0%,100%{opacity:.6}50%{opacity:1}}
/* egg description */
.phx-tag{margin:2px 0 0;max-width:78%;text-align:center;font:italic 500 14px/1.35 var(--ui);color:#e6defa;text-shadow:0 1px 3px #000,0 0 10px #000a;animation:phxtag .5s ease .15s both}
@keyframes phxtag{from{opacity:0;transform:translateY(-4px)}}
.phx-about{margin-top:auto;padding:12px 14px;border-radius:14px;background:linear-gradient(180deg,#160f34,#0c0820);border:1px solid #3a3070;display:flex;flex-direction:column;gap:8px}
.phx-ab-l{border-color:#6a5222}.phx-ab-r{border-color:#2a4a8a}
.phx-abh{display:flex;align-items:center;gap:8px}.phx-abh i{display:grid;width:20px;height:20px}.phx-abh i svg{width:20px;height:20px}.phx-ab-r .phx-abh i{color:#5ab8ff}.phx-ab-l .phx-abh i{color:#ffc23a}
.phx-abh b{font:700 15px var(--ui);color:#fff8e8}
.phx-about p{margin:0;font:500 13px/1.45 var(--ui);color:#c4badf}
.phx-facts{display:flex;flex-wrap:wrap;gap:6px}.phx-facts span{display:inline-flex;align-items:center;gap:5px;padding:4px 9px;border-radius:999px;background:#ffffff0d;border:1px solid #ffffff14;font:700 12px var(--ui);color:#e8e0ff}.phx-facts svg{width:13px;height:13px;color:#ffd166}
/* lively hatch button */
.phx-call{position:relative;overflow:hidden;}
.phx-call::after{content:"";position:absolute;top:0;bottom:0;left:0;width:34%;background:linear-gradient(100deg,#fff0,#fff8 50%,#fff0);transform:translateX(-140%) skewX(-16deg);animation:phxsw 2.8s ease-in-out infinite;pointer-events:none}
.phx-call svg{animation:phxwig 2.8s ease-in-out infinite;transform-origin:50% 90%}
@keyframes phxsw{0%,55%{transform:translateX(-140%) skewX(-16deg)}85%,100%{transform:translateX(420%) skewX(-16deg)}}
@keyframes phxwig{0%,70%,100%{transform:rotate(0)}76%{transform:rotate(-14deg)}82%{transform:rotate(12deg)}88%{transform:rotate(-6deg)}94%{transform:rotate(3deg)}}
.phx2 .phx-cnt:not(.z){color:#fff;text-shadow:0 0 10px #ffd45a99;animation:phxcnt 2s ease-in-out infinite}@keyframes phxcnt{0%,100%{transform:scale(1)}50%{transform:scale(1.12)}}
.phx2 .phx-c{transition:transform .2s cubic-bezier(.3,1.5,.5,1),border-color .18s,box-shadow .2s}.phx2 .phx-c:hover{transform:translateY(-3px)}.phx2 .phx-c:active{transform:scale(.98)}
.phx2 .phx-c.phx-l.on{box-shadow:0 0 0 1px #ffc23a55,0 0 24px #ffb02a33}.phx2 .phx-c.phx-r.on{box-shadow:0 0 0 1px #5ab8ff55,0 0 24px #3a8aff33}
/* reveal: collection progress */
.phc-prog{grid-column:1/-1;justify-self:center;width:min(680px,100%);box-sizing:border-box;display:flex;flex-direction:row;align-items:center;gap:14px;padding:8px 14px;border-radius:12px;background:#0a0618aa;border:1px solid #3a3070;animation:phup .45s ease .5s both}
.phc-prog>div{display:flex;gap:10px;flex:none;align-items:center;font:700 13px var(--ui);color:#e8e0ff}.phc-prog>div span{display:inline-flex;gap:6px;align-items:center}.phc-prog svg{width:14px;height:14px;color:#ffd166}
.phc-prog b{color:#fff}.phc-pb{display:block;flex:1;min-width:80px;height:8px;border-radius:5px;background:#1e1640;overflow:hidden}.phc-pb i{display:block;height:100%;width:var(--w);border-radius:5px;background:linear-gradient(90deg,#7a5aff,#ffd45a);transform-origin:0 50%;animation:phcpb 1s cubic-bezier(.2,1,.3,1) .7s both}
@keyframes phcpb{from{transform:scaleX(0)}}
.phc-prog small{flex:none;display:inline-flex;gap:6px;align-items:center;font:600 12.5px var(--ui);color:#c4badf}
@media (prefers-reduced-motion:reduce){.ptc-l::after,.phx-call::after,.phx-call,.phx-call svg,.phx-cnt,.ptnw,.ptq{animation:none!important}}
`;document.head.appendChild(st)}
