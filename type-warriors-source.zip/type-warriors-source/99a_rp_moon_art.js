/* ===== RUNESTONE TOWER DEFENSE 10.2: the Moonblade Sentinel, art (99a, after 98v) =====
   The thirteenth tower (UPDATE_10_2_PLAN.md section 1): a carved moonstone guardian statue on a plinth, an indigo cloak on its
   shoulders and a crescent-crested helm, holding a crescent glaive aloft. It hurls the glaive (99b flies it out and back).
   Live: the arms are separate sprites turned about the shoulders (hold aloft, wind back over the helm, throw, the empty open hand
   held out while the glaive flies, the catch with a small recoil), the held glaive bobs and turns, the eyes and the chest moonstone
   breathe and flare on a wind-up; icons and the tier sheet show the idle pose.
   Tiers: 1 a small statue on a masonry drum, one glaive (the other hand rests); 2 Keen Edge: taller, a two-step plinth with a gold band
   and a crescent plaque, gold trim on the armour, a longer glaive with a cyan edge; 3 Twin Moons: a glaive in each hand, a great
   moonstone crescent behind the statue, moon-phase stones on the plinth; 4 Mythic (violet moonstone, gold, the shared Mythic layer);
   5 Celestial (white-gold, marble, a third glaive hovering over the helm, wings and halo).
   Plugs into the shared 95c pipeline (RPPAL/RPLAY/RPPULSE/RPWING/RPHALO + wrapped rpBodyArt, rpGlowList, rpTowerParts, rpTowerWarm), so the
   build/upgrade/ascension animations, icons, mastery recolouring and the 97k glow layer work as for every tower. No shadowBlur, no
   ctx.filter: glows are the shared radial sprites drawn with 'lighter'.
   API (model units: pad centre at 0,0; 99b multiplies by RPG.k)
     rpmbShoulder(tier,side)            the shoulder pivot {x,y} of the arm on that side (+1 right, -1 left)
     rpmbHand(tier,side,a)               the hand at arm angle a (0 = hanging down, PI = straight up, outward positive) {x,y}
     RPMB_A                              the arm angles: hold (aloft), wind (back over the helm), rel (release), out (open hand), rest
     rpmbBlade(g,x,y,tier,rot,sy,sc,a)   a glaive (rot = spin, sy = squash for a flat spin seen from above)
     rpmbGhost(g,x,y,tier,rot,sy,sc,a)   the glaive's motion-trail ghost (one baked glow sprite)
     rpmbEclipse(g,x,y,tier,rot,sc,k)    the eclipse crescent (tier 5), k = 0..1 fade
     rpmbWake(g,x,y,k,tier,seed)         a stretch of the silver wake on the road (ground layer), k = 0..1
     rpmbSpark(g,x,y,u,tier)             a cut spark (top layer), u = 0..1 */
RPTW.moon={n:'Moonblade Sentinel',role:'Boomerang',col:'#a8c4ff'};
RPSKIN.moon=['base'];
RPPAL.moon={base:{stone:RPSTONE.base,trim:'#ffd45a',trimL:'#fff0a8',trimD:'#b07a1a',glow:'#bfe0ff',glow2:'#e8f0ff',rune:'#9fd0ff'}};
/* per tier: statue scale s, plinth top py, plinth radius pr, top, tier 4-5 gems */
RPLAY.moon=[0,
 {s:.95,py:-14,pr:27,top:100,runes:[]},
 {s:1.02,py:-21,pr:29,top:112,runes:[]},
 {s:1.08,py:-25,pr:31,top:126,runes:[]},
 {s:1.1,py:-26,pr:32,top:134,runes:[],inl:[[0,6,4.2],[-26,1,3.4],[26,1,3.4]]},
 {s:1.14,py:-27,pr:33,top:154,runes:[],inl:[[0,6,4.4],[-27,1,3.6],[27,1,3.6]]}];
RPPULSE.moon=[1.8,.24];RPWING.moon=[30,-80];RPHALO.moon=[-147,22];
const rpmbT=t=>Math.max(1,Math.min(5,t|0||1));
/* palettes by tier: moonstone ms [light, mid, dark, deep], armour ar, cloak cl [light, mid, dark], gold g [light, mid, dark],
   blade bl [light, mid, dark], edge (the keen edge line), gem, eye */
const rpmbMet=tier=>tier>=5?{ms:['#fffdf6','#f4ead0','#d6bc84','#8a6a2a'],ar:['#ffffff','#f6e6b4','#d8b060','#7a5a1a'],cl:['#8ad0ff','#3a7ad0','#1a3478'],g:['#ffffff','#ffe27a','#c99a2a'],cr:['#fffbe6','#ffd45a','#c99a2a'],
  bl:['#ffffff','#fff2c8','#e0b860'],edge:'#9ae8ff',gem:['#ffffff','#9ae8ff','#2a8ac0'],eye:'#fff6c8',glow:'#fff0c0'}
 :tier===4?{ms:['#f2e6ff','#b996f0','#7a52c0','#3a1a7a'],ar:['#e8dcff','#9a82d8','#5a40a0','#24104a'],cl:['#8a4ad8','#5a1ea8','#2c0a62'],g:['#fff0a8','#ffd45a','#b07a1a'],
  bl:['#fbf2ff','#d0b0ff','#8a5ad8'],edge:'#ffd45a',gem:['#fbe8ff','#e08aff','#7a2ab8'],eye:'#f0c8ff',glow:'#c890ff'}
 :{ms:['#f2f5ff','#c3cbef','#8790c4','#454c86'],ar:['#f6f8ff','#c4cae6','#8088b0','#3c4170'],cl:tier>=3?['#7a6ae0','#4c3cb4','#261a6c']:['#6a5ad0','#4436a0','#221860'],g:['#fff0a8','#ffd45a','#b07a1a'],
  bl:tier>=3?['#ffffff','#d8e8ff','#8aa6e0']:['#ffffff','#d6dcf2','#8a92b8'],edge:tier>=2?'#7ad8ff':'#c8d4ff',gem:['#f4fbff','#9fd0ff','#3a62c0'],eye:'#d8f0ff',glow:'#bfe0ff'};
/* a crescent: the part of circle A (centre cx,cy, radius R) outside circle B (radius r, centre d higher), horns up; rot turns it */
function rpmbCresPath(g,cx,cy,R,d,r,rot){const y=(r*r-R*R-d*d)/(2*d),x=Math.sqrt(Math.max(0,R*R-y*y));g.save();g.translate(cx,cy);if(rot)g.rotate(rot);g.beginPath();
 let a0=Math.atan2(y,x),a1=Math.atan2(y,-x);if(a1<a0)a1+=TAU;g.arc(0,0,R,a0,a1,false);g.arc(0,-d,r,Math.atan2(y+d,-x),Math.atan2(y+d,x),true);g.closePath();g.restore()}
/* the arm angles (from hanging straight down, outward positive) */
const RPMB_A={hold:2.2,wind:3.0,rel:1.5,out:1.35,rest:.32,catchK:.55};
function rpmbShoulder(tier,side){const L=RPLAY.moon[rpmbT(tier)],s=L.s;return{x:side*14*s,y:L.py-49*s}}
const rpmbArmLen=tier=>22*RPLAY.moon[rpmbT(tier)].s;
function rpmbHand(tier,side,a){const S=rpmbShoulder(tier,side),l=rpmbArmLen(tier);return{x:S.x+side*Math.sin(a)*l,y:S.y+Math.cos(a)*l}}
/* ---------- the plinth ---------- */
function rpmbPlinth(g,tier,P,L,M){const S=P.stone,pr=L.pr,py=L.py;
 if(tier===1){rpMason(g,0,0,pr+2,pr,-py,S,1,5,7);rpTopStone(g,0,py,pr,S,3,rpA(M.edge,.5));return}
 /* a wide lower step (masonry) and a smooth moonstone drum */
 const h1=tier>=3?9:8;rpMason(g,0,0,pr+5,pr+4,h1,S,1,6,11);rpTopStone(g,0,-h1,pr+4,S,5,null);
 const h2=-py-h1;rpTube(g,0,-h1,pr,pr-1.5,h2,M.ms[0],M.ms[1],M.ms[2],2.4);
 /* the gold band and its rivets */
 rpBand(g,0,-h1,pr+.3,h2*.48,3,M.g[0],M.g[1],M.g[2],7,M.g[0]);
 rpCap(g,0,py,pr-1.5,M.ms[0],M.ms[2],2.2);g.strokeStyle=rpA(M.edge,.55);g.lineWidth=1.3;g.beginPath();g.ellipse(0,py,(pr-1.5)*.68,(pr-1.5)*.68*RPSQ,0,0,TAU);g.stroke();
 /* the crescent plaque on the front of the drum */
 const cy=-h1-h2*.48-1.5;g.beginPath();g.ellipse(0,cy,8.5,6.4,0,0,TAU);g.fillStyle=rpVG(g,cy-6,cy+6,M.ms[3],'#14102c');g.fill();rpOut(g,1.8);
 rpmbCresPath(g,0,cy+1.4,5,2.6,4.4,Math.PI);g.fillStyle=rpVG(g,cy-5,cy+3,M.g[0],M.g[1]);g.fill();g.lineWidth=1;g.strokeStyle=RPTO;g.stroke();
 /* tier 3+: moon-phase stones round the lower step (new, crescent, half, gibbous, full) */
 if(tier>=3)[-2.55,-2.95,.19,.59].forEach((a,i)=>{const x=Math.cos(a)*(pr+4.4),y=-h1*.5+Math.sin(a)*(pr+4.4)*RPSQ+4;if(Math.sin(a)<0)return;
  g.beginPath();g.arc(x,y,3.4,0,TAU);g.fillStyle='#1c1840';g.fill();rpOut(g,1.3);g.save();g.beginPath();g.arc(x,y,2.6,0,TAU);g.clip();g.fillStyle=M.gem[0];g.beginPath();g.arc(x+(i-1.5)*1.8,y,2.6,0,TAU);g.fill();g.restore()});
 if(tier>=3)for(const k of [-1,1]){const x=k*(pr+2.6),y=-h1*.5+5.6;g.beginPath();g.arc(x,y,3.4,0,TAU);g.fillStyle='#1c1840';g.fill();rpOut(g,1.3);g.beginPath();g.arc(x,y,2.5,0,TAU);g.fillStyle=M.gem[1];g.fill();
  g.fillStyle='rgba(255,255,255,.8)';g.beginPath();g.arc(x-.8,y-.9,.8,0,TAU);g.fill()}}
/* ---------- the great crescent behind the statue (tier 3+) ---------- */
function rpmbBackCres(g,tier,L,M){const s=L.s,cy=L.py-57*s,R=40*s;
 rpmbCresPath(g,0,cy,R+2,R*.42,R*.9+2,0);g.fillStyle=RPTO;g.fill();
 rpmbCresPath(g,0,cy,R,R*.42,R*.9,0);g.fillStyle=rpVG(g,cy-R*.4,cy+R,(M.cr||M.ms)[0],(M.cr||M.ms)[2]);g.fill();
 g.save();rpmbCresPath(g,0,cy,R,R*.42,R*.9,0);g.clip();g.lineWidth=2.6;g.strokeStyle=rpA(M.g[1],.95);g.beginPath();g.arc(0,cy,R-2.4,-.2,Math.PI+.2);g.stroke();
 g.lineWidth=1.2;g.strokeStyle='rgba(255,255,255,.75)';g.beginPath();g.arc(0,cy,R-5.2,Math.PI*.55,Math.PI*.95);g.stroke();g.restore();
 /* star studs along it */
 for(const a of [.15,.6,2.54,2.99,-.25,3.39]){const x=Math.cos(a)*(R-7*s),y=cy+Math.sin(a)*(R-7*s);g.fillStyle=M.gem[1];g.beginPath();g.arc(x,y,1.7,0,TAU);g.fill();g.lineWidth=.9;g.strokeStyle=RPTO;g.stroke()}
 /* gold tips on the horns */
 const y=(Math.pow(R*.9,2)-R*R-Math.pow(R*.42,2))/(2*R*.42),x=Math.sqrt(Math.max(0,R*R-y*y));for(const k of [-1,1]){g.beginPath();g.arc(k*x,cy+y,2.6,0,TAU);g.fillStyle=M.g[1];g.fill();rpOut(g,1.3)}}
/* ---------- the statue (no arms: those are live) ---------- */
function rpmbStatue(g,tier,L,M){const s=L.s,y0=L.py,yw=y0-30*s,ys=y0-49*s,yh=y0-59*s;
 /* the cloak behind: from the shoulders, flaring to the plinth, a wavy hem */
 g.beginPath();g.moveTo(-13*s,ys-1);g.quadraticCurveTo(-23*s,yw,-25*s,y0-1);for(let i=0;i<=6;i++){const x=-25*s+i*50*s/6;g.quadraticCurveTo(x-4*s,y0+(i%2?2.4:-1.2),x,y0+(i%2?-.5:1.5))}
 g.quadraticCurveTo(23*s,yw,13*s,ys-1);g.closePath();g.fillStyle=rpHG(g,-25*s,25*s,M.cl[0],M.cl[1],M.cl[2]);g.fill();rpOut(g,2.2);
 g.strokeStyle=rpA(RPTO,.35);g.lineWidth=1.2;for(const k of [-1,1]){g.beginPath();g.moveTo(k*17*s,ys+6*s);g.quadraticCurveTo(k*22*s,yw+4*s,k*21*s,y0-2);g.stroke()}
 if(tier>=2){g.strokeStyle=M.g[1];g.lineWidth=1.6;g.beginPath();g.moveTo(-24*s,y0-2);g.quadraticCurveTo(-22*s,yw,-14*s,ys+3*s);g.moveTo(24*s,y0-2);g.quadraticCurveTo(22*s,yw,14*s,ys+3*s);g.stroke()}
 /* the robe: moonstone folds flaring to the plinth */
 g.beginPath();g.moveTo(-9.5*s,yw);g.quadraticCurveTo(-13*s,y0-12*s,-17*s,y0);g.quadraticCurveTo(0,y0+3.2,17*s,y0);g.quadraticCurveTo(13*s,y0-12*s,9.5*s,yw);g.closePath();
 g.fillStyle=rpHG(g,-17*s,17*s,M.ms[0],M.ms[1],M.ms[2]);g.fill();rpOut(g,2.3);
 g.strokeStyle=rpA(M.ms[3],.55);g.lineWidth=1.3;for(const x of [-8,-3,3,8]){g.beginPath();g.moveTo(x*.55*s,yw+3);g.quadraticCurveTo(x*.85*s,y0-12*s,x*1.15*s,y0-1);g.stroke()}
 g.strokeStyle='rgba(255,255,255,.6)';g.lineWidth=1.1;g.beginPath();g.moveTo(-6*s,yw+3);g.quadraticCurveTo(-9*s,y0-12*s,-12*s,y0-2);g.stroke();
 /* hem band */
 g.beginPath();g.moveTo(-17*s,y0);g.quadraticCurveTo(0,y0+3.2,17*s,y0);g.lineWidth=4.6;g.strokeStyle=RPTO;g.stroke();g.lineWidth=2.4;g.strokeStyle=tier>=2?M.g[1]:M.ar[1];g.stroke();
 /* the breastplate */
 g.beginPath();g.moveTo(-9.5*s,yw+1);g.quadraticCurveTo(-12.5*s,ys+8*s,-13*s,ys+1);g.quadraticCurveTo(0,ys-4*s,13*s,ys+1);g.quadraticCurveTo(12.5*s,ys+8*s,9.5*s,yw+1);g.closePath();
 g.fillStyle=rpHG(g,-13*s,13*s,M.ar[0],M.ar[1],M.ar[2]);g.fill();rpOut(g,2.3);
 g.strokeStyle=rpA(M.ar[3],.6);g.lineWidth=1.2;g.beginPath();g.moveTo(0,ys+1);g.lineTo(0,yw);g.stroke();
 g.strokeStyle='rgba(255,255,255,.7)';g.lineWidth=1.2;g.beginPath();g.moveTo(-9*s,ys+3*s);g.quadraticCurveTo(-10*s,ys+9*s,-7.5*s,yw-1);g.stroke();
 if(tier>=2){g.strokeStyle=M.g[1];g.lineWidth=1.5;g.beginPath();g.moveTo(-12.6*s,ys+1.5);g.quadraticCurveTo(0,ys-3.3*s,12.6*s,ys+1.5);g.stroke()}
 /* the chest moonstone in a gold setting */
 const gy=ys+8.5*s;g.beginPath();g.arc(0,gy,4.6*s,0,TAU);g.fillStyle=M.g[1];g.fill();rpOut(g,1.6);g.beginPath();g.arc(0,gy,3.1*s,0,TAU);
 const q=g.createRadialGradient(-1,gy-1.2,.4,0,gy,3.2*s);q.addColorStop(0,M.gem[0]);q.addColorStop(.55,M.gem[1]);q.addColorStop(1,M.gem[2]);g.fillStyle=q;g.fill();g.lineWidth=1;g.strokeStyle=RPTO;g.stroke();
 g.fillStyle='rgba(255,255,255,.9)';g.beginPath();g.arc(-1.1*s,gy-1.2*s,.9*s,0,TAU);g.fill();
 /* belt with a crescent buckle */
 g.beginPath();g.moveTo(-10.4*s,yw-1);g.quadraticCurveTo(0,yw+2.4,10.4*s,yw-1);g.lineWidth=5;g.strokeStyle=RPTO;g.stroke();g.lineWidth=3;g.strokeStyle=tier>=2?M.g[2]:M.cl[1];g.stroke();
 rpmbCresPath(g,0,yw+1.4,3.4,1.8,2.9,Math.PI);g.fillStyle=M.g[1];g.fill();g.lineWidth=1;g.strokeStyle=RPTO;g.stroke();
 /* gorget and the helm */
 g.beginPath();g.ellipse(0,ys-1,6.5*s,3.2*s,0,0,TAU);g.fillStyle=M.ar[2];g.fill();rpOut(g,1.8);
 g.beginPath();g.arc(0,yh,8*s,Math.PI*.92,Math.PI*.08,false);g.quadraticCurveTo(8.4*s,yh+8*s,0,yh+9*s);g.quadraticCurveTo(-8.4*s,yh+8*s,-8*s*Math.cos(Math.PI*.08),yh+8*s*Math.sin(Math.PI*.08));g.closePath();
 g.fillStyle=rpHG(g,-8*s,8*s,M.ar[0],M.ar[1],M.ar[2]);g.fill();rpOut(g,2.2);
 /* the visor: a dark T slit (the eyes glow there, live) */
 g.beginPath();g.moveTo(-5.4*s,yh+.6*s);g.lineTo(5.4*s,yh+.6*s);g.lineTo(5*s,yh+2.6*s);g.lineTo(1.2*s,yh+2.6*s);g.lineTo(1*s,yh+6.8*s);g.lineTo(-1*s,yh+6.8*s);g.lineTo(-1.2*s,yh+2.6*s);g.lineTo(-5*s,yh+2.6*s);g.closePath();g.fillStyle='#120a28';g.fill();
 g.strokeStyle='rgba(255,255,255,.75)';g.lineWidth=1.2;g.beginPath();g.arc(0,yh,6*s,Math.PI*1.12,Math.PI*1.45);g.stroke();
 if(tier>=2){g.strokeStyle=M.g[1];g.lineWidth=1.4;g.beginPath();g.moveTo(0,yh-8*s);g.lineTo(0,yh-.5);g.stroke()}
 /* the crescent crest (horns up), bigger and gold from tier 2 */
 const cr=(tier>=2?8.6:7)*s,cy=yh-8.4*s-cr*.3;rpmbCresPath(g,0,cy,cr+1.6,cr*.5,cr*.86+1.6,0);g.fillStyle=RPTO;g.fill();
 rpmbCresPath(g,0,cy,cr,cr*.5,cr*.86,0);g.fillStyle=tier>=2?rpVG(g,cy-cr*.3,cy+cr,M.g[0],M.g[2]):rpVG(g,cy-cr*.3,cy+cr,M.ar[0],M.ar[2]);g.fill();
 g.fillStyle=M.gem[1];g.beginPath();g.arc(0,cy+cr*.78,1.6*s,0,TAU);g.fill();g.lineWidth=.9;g.strokeStyle=RPTO;g.stroke();
 /* tier 5: a little star finial on the crest */
 if(tier>=5){const y=cy-cr*.15;g.beginPath();for(let i=0;i<8;i++){const a=i/8*TAU-Math.PI/2,r=i%2?1.8:4.6;g.lineTo(Math.cos(a)*r,y+Math.sin(a)*r)}g.closePath();g.fillStyle=M.g[1];g.fill();rpOut(g,1.2)}}
/* ---------- the static body ---------- */
function rpmbBodyArt(g,tier,P){const L=RPLAY.moon[tier],M=rpmbMet(tier);
 rpPadArt(g);rpmbPlinth(g,tier,P,L,M);
 if(tier>=3)rpmbBackCres(g,tier,L,M);
 rpmbStatue(g,tier,L,M);
 if(tier>=4)rpAscArt(g,'moon',tier,P,L)}
{const b0=rpBodyArt;rpBodyArt=function(g,type,tier,P){if(type==='moon')return rpmbBodyArt(g,tier,P);return b0.apply(this,arguments)}}
{const l0=rpGlowList;rpGlowList=function(type,tier,P,L){if(type!=='moon')return l0.apply(this,arguments);const G=[],A=(x,y,rx,ry,c,a)=>G.push([x,y,rx,ry,c,a]),M=rpmbMet(tier),s=L.s;
 A(0,L.py-49*s+8.5*s,12,12,M.glow,.8);A(0,L.py-59*s+2,12,7,M.eye,.55);
 if(tier>=3)A(0,L.py-56*s+20*s,40*s,18*s,M.glow,.3);
 if(tier>=4){const A4=RPASC[tier];for(const [x,y,z] of L.inl)A(x,y,z*3.4,z*3.4,A4.glow,.85);A(0,-L.top*.5,46,L.top*.5,A4.glow,.16)}return G}}
/* ---------- live parts ---------- */
/* an arm, hanging from its shoulder pivot (0,0) to the hand at (0,len): pauldron, upper arm, elbow cop, vambrace, gauntlet; open = an open hand */
function rpmbArmArt(g,tier,open){const L=RPLAY.moon[tier],M=rpmbMet(tier),s=L.s,l=rpmbArmLen(tier);
 rpBeam(g,0,2*s,0,l*.5,6.4*s,M.ar[1],M.ar[0]);
 g.beginPath();g.moveTo(-4*s,l*.52);g.lineTo(-5.2*s,l*.86);g.lineTo(5.2*s,l*.86);g.lineTo(4*s,l*.52);g.closePath();g.fillStyle=rpHG(g,-4.6*s,4.6*s,M.ar[0],M.ar[1],M.ar[2]);g.fill();rpOut(g,1.8);
 if(tier>=2){g.beginPath();g.moveTo(-4.6*s,l*.84);g.lineTo(4.6*s,l*.84);g.lineWidth=2.4;g.strokeStyle=M.g[1];g.stroke()}
 g.beginPath();g.arc(0,l*.5,3.3*s,0,TAU);g.fillStyle=tier>=2?M.g[1]:M.ar[1];g.fill();rpOut(g,1.5);
 if(open){/* an open gauntlet: palm and spread fingers */
  g.beginPath();g.ellipse(0,l*.96,3.4*s,3*s,0,0,TAU);g.fillStyle=M.ar[1];g.fill();rpOut(g,1.4);
  for(const a of [-.7,-.25,.2,.65]){const x=Math.sin(a)*6*s,y=l*.96+Math.cos(a)*6*s;rpBeam(g,Math.sin(a)*2*s,l*.96+Math.cos(a)*2*s,x,y,1.4*s,M.ar[0],null)}
  rpBeam(g,-2.6*s,l*.92,-5.4*s,l*.86,1.4*s,M.ar[0],null)}
 else{g.beginPath();g.arc(0,l*.97,3.8*s,0,TAU);g.fillStyle=rpHG(g,-3.8*s,3.8*s,M.ar[0],M.ar[1],M.ar[2]);g.fill();rpOut(g,1.6);
  g.strokeStyle=rpA(RPTO,.5);g.lineWidth=.9;for(const y of [-1,1]){g.beginPath();g.moveTo(-2.8*s,l*.97+y*1.3*s);g.lineTo(2.8*s,l*.97+y*1.3*s);g.stroke()}}
 /* the pauldron over the shoulder */
 g.beginPath();g.ellipse(0,1*s,6.8*s,6*s,0,0,TAU);g.fillStyle=rpHG(g,-6.8*s,6.8*s,M.ar[0],M.ar[1],M.ar[2]);g.fill();rpOut(g,2);
 g.strokeStyle=tier>=2?M.g[1]:'rgba(255,255,255,.7)';g.lineWidth=1.4;g.beginPath();g.ellipse(0,1*s,4.8*s,4.2*s,0,Math.PI*1.05,Math.PI*1.9);g.stroke();
 if(tier>=3){g.fillStyle=M.gem[1];g.beginPath();g.arc(0,1.2*s,1.5*s,0,TAU);g.fill();g.lineWidth=.9;g.strokeStyle=RPTO;g.stroke()}}
const rpmbArmS=(tier,open)=>{tier=rpmbT(tier);const l=rpmbArmLen(tier),s=RPLAY.moon[tier].s;return rpSpr('mb|arm|'+tier+'|'+(open?1:0),-10*s,-8*s,20*s,l+18*s,g=>rpmbArmArt(g,tier,open))};
/* the glaive: a crescent blade, horns down, a wrapped grip on its inner curve and a moonstone at its heart; origin at its middle */
function rpmbBladeArt(g,tier){const M=rpmbMet(tier),k=tier>=2,R=k?18.5:17,d=k?8.4:7,r=k?16:14.6;g.save();g.translate(0,10);
 rpmbCresPath(g,0,0,R+1.8,d,r+1.8,Math.PI);g.fillStyle=RPTO;g.fill();
 rpmbCresPath(g,0,0,R,d,r,Math.PI);const q=g.createLinearGradient(0,-R,0,-R+10);q.addColorStop(0,M.bl[0]);q.addColorStop(.5,M.bl[1]);q.addColorStop(1,M.bl[2]);g.fillStyle=q;g.fill();
 g.save();rpmbCresPath(g,0,0,R,d,r,Math.PI);g.clip();g.lineWidth=k?2.4:1.6;g.strokeStyle=M.edge;g.beginPath();g.arc(0,0,R-1,Math.PI*1.08,Math.PI*1.92);g.stroke();
 g.lineWidth=1;g.strokeStyle='rgba(255,255,255,.9)';g.beginPath();g.arc(0,0,R-2.8,Math.PI*1.25,Math.PI*1.55);g.stroke();g.restore();
 /* grip: a short bar across the inner curve, wrapped */
 const gy=-r+d+2.6;g.beginPath();g.rect(-4.2,gy-1.8,8.4,3.6);g.fillStyle=tier===4?'#3a1a6a':tier>=5?'#c99a2a':'#2a2468';g.fill();rpOut(g,1.2);
 g.strokeStyle=rpA(M.g[1],.9);g.lineWidth=.8;for(const x of [-2.2,0,2.2]){g.beginPath();g.moveTo(x-.8,gy-1.6);g.lineTo(x+.8,gy+1.6);g.stroke()}
 /* the heart gem */
 const hy=-R+3.6;g.beginPath();g.arc(0,hy,2.6,0,TAU);g.fillStyle=M.gem[1];g.fill();g.lineWidth=1.1;g.strokeStyle=RPTO;g.stroke();g.fillStyle='#ffffff';g.beginPath();g.arc(-.7,hy-.8,.8,0,TAU);g.fill();
 g.restore()}
const rpmbBladeS=tier=>rpSpr('mb|bl|'+rpmbT(tier),-23,-13,46,20,g=>rpmbBladeArt(g,rpmbT(tier)));
function rpmbBlade(g,x,y,tier,rot,sy,sc,a){const s=sc||1,a0=g.globalAlpha;g.save();g.translate(x,y);g.scale(s,s*(sy==null?1:sy));g.rotate(rot||0);if(a!=null)g.globalAlpha=a0*a;rpPut(g,rpmbBladeS(tier));g.restore();g.globalAlpha=a0}
/* the trail ghost: a soft crescent of light */
const rpmbGhostS=tier=>rpSpr('mb|gh|'+rpmbT(tier),-24,-14,48,24,g=>{const M=rpmbMet(rpmbT(tier));g.translate(0,10);rpmbCresPath(g,0,0,18,8,16,Math.PI);g.fillStyle=rpA(M.glow,.55);g.fill();
 rpmbCresPath(g,0,0,16,7.4,14.6,Math.PI);g.fillStyle=rpA('#ffffff',.6);g.fill()},1);
function rpmbGhost(g,x,y,tier,rot,sy,sc,a){if(a<=.02)return;const s=sc||1;g.save();g.translate(x,y);g.scale(s,s*sy);g.rotate(rot||0);g.globalAlpha=a;rpPut(g,rpmbGhostS(tier));g.restore();g.globalAlpha=1}
/* the eclipse: a dark moon with a burning gold rim, a white-gold crescent blade riding it */
function rpmbEclArt(g){g.drawImage(rpGlowC('#fff0c0'),-46,-46,92,92);
 g.beginPath();g.arc(0,0,21,0,TAU);g.fillStyle=RPTO;g.fill();g.beginPath();g.arc(0,0,19,0,TAU);const q=g.createRadialGradient(-4,-4,2,0,0,19);q.addColorStop(0,'#2a2058');q.addColorStop(1,'#0a0618');g.fillStyle=q;g.fill();
 g.lineWidth=2.4;g.strokeStyle='#ffe27a';g.beginPath();g.arc(0,0,19,0,TAU);g.stroke();
 rpmbCresPath(g,0,-2,26,10,22,Math.PI*.15);g.fillStyle=RPTO;g.fill();rpmbCresPath(g,0,-2,24.4,9.4,20.6,Math.PI*.15);
 const r=g.createLinearGradient(-24,-24,24,24);r.addColorStop(0,'#ffffff');r.addColorStop(.5,'#fff2c8');r.addColorStop(1,'#e0b860');g.fillStyle=r;g.fill();
 g.save();rpmbCresPath(g,0,-2,24.4,9.4,20.6,Math.PI*.15);g.clip();g.lineWidth=2;g.strokeStyle='#9ae8ff';g.beginPath();g.arc(0,-2,23.4,0,TAU);g.stroke();g.restore();
 for(let i=0;i<6;i++){const a=i/6*TAU;g.fillStyle='#fff6d0';g.beginPath();g.arc(Math.cos(a)*14,Math.sin(a)*14,1.1,0,TAU);g.fill()}}
const rpmbEclS=()=>rpSpr('mb|ecl',-46,-46,92,92,rpmbEclArt);
function rpmbEclipse(g,x,y,tier,rot,sc,k){if(k<=.01)return;const s=(sc||1)*(.6+.4*k);g.save();g.translate(x,y);g.globalCompositeOperation='lighter';g.globalAlpha=.55*k;g.drawImage(rpGlowC('#fff0c0'),-70*s,-46*s,140*s,92*s);g.globalAlpha=.35*k;g.drawImage(rpGlowC('#9ae8ff'),-44*s,-30*s,88*s,60*s);
 g.globalCompositeOperation='source-over';g.globalAlpha=k;g.scale(s,s*.82);g.rotate(rot);rpPut(g,rpmbEclS());g.restore();g.globalAlpha=1}
/* the wake: a silver smear on the road */
const rpmbWakeS=tier=>rpSpr('mb|wk|'+(tier>=5?5:4),-22,-10,44,20,g=>{const c=tier>=5?'#fff0c0':'#bcd4ff',q=g.createRadialGradient(0,0,0,0,0,20);q.addColorStop(0,rpA('#ffffff',1));q.addColorStop(.3,rpA(c,.8));q.addColorStop(1,rpA(c,0));
 g.save();g.scale(1,.45);g.fillStyle=q;g.beginPath();g.arc(0,0,20,0,TAU);g.fill();g.restore();g.strokeStyle=rpA('#ffffff',.9);g.lineWidth=1.6;g.beginPath();g.moveTo(-14,0);g.lineTo(14,0);g.stroke()},1);
function rpmbWake(g,x,y,k,tier,rot){if(k<=.02)return;g.save();g.translate(x,y);g.rotate(rot||0);g.globalAlpha=Math.min(1,k);rpPut(g,rpmbWakeS(tier));g.restore();g.globalAlpha=1}
/* a cut: a sharp white-blue spark */
const rpmbSparkS=tier=>rpSpr('mb|sp|'+rpmbT(tier),-14,-14,28,28,g=>{const M=rpmbMet(rpmbT(tier));g.drawImage(rpGlowC(M.glow),-14,-14,28,28);g.fillStyle='#ffffff';g.beginPath();
 for(let i=0;i<8;i++){const a=i/8*TAU,r=i%2?2:9;g.lineTo(Math.cos(a)*r*(i%4===0?1:.7),Math.sin(a)*r*(i%4===2?1.1:.7))}g.closePath();g.fill()},1);
function rpmbSpark(g,x,y,u,tier){if(u<=0||u>=1)return;const z=(.7+.8*Math.sin(Math.PI*Math.min(1,u*1.8)))*(1-u*.3);g.save();g.translate(x,y);g.rotate(u*1.2);g.scale(z,z*.8);g.globalAlpha=1-u*u;rpPut(g,rpmbSparkS(tier));g.restore();g.globalAlpha=1}
/* the tower being drawn (99b sets it around rpTowerAt), so the arms and the held glaives follow the battle */
const RPMB_ART={cur:null};
/* arm angle for one side, from the tower's state: wind 0..1, thr 0..1 (just released), catch 0..1 (recoil), holding or not */
function rpmbArmA(tw,side,t,ph,active,holding){const A=RPMB_A,idle=Math.sin(t*1.3+ph*3+side)*.05;if(!active)return A.rest+Math.sin(t*1.1+ph*2+side)*.04;
 if(!tw)return A.hold+idle;
 const w=Math.max(0,Math.min(1,tw.mbW||0)),th=Math.max(0,Math.min(1,tw.mbT||0)),cc=Math.max(0,Math.min(1,tw.mbC||0));
 if(holding){const e=w*w*(3-2*w);let a=A.hold+(A.wind-A.hold)*e+idle*(1-e);if(cc>0)a-=A.catchK*Math.sin(Math.PI*Math.min(1,cc))*cc;return a}
 /* empty: the follow-through of the throw, then the open hand held out towards the glaive */
 if(th>0)return A.out+(A.wind-A.out)*th*th*th+(A.rel-A.out)*(1-th)*th;return A.out+Math.sin(t*2.2+ph+side)*.06}
function rpmbLive(g,tier,P,t,o,L,ph){const M=rpmbMet(tier),lt=RPFX.lite,tw=RPMB_ART.cur&&RPMB_ART.cur.type==='moon'?RPMB_ART.cur:null,s=L.s,ga=RPGA;
 const yh=L.py-59*s,gy=L.py-49*s+8.5*s,w=tw?Math.max(0,Math.min(1,tw.mbW||0)):0,cc=tw?Math.max(0,tw.mbC||0):0;
 /* eyes and chest stone breathe; they flare on a wind-up and a catch */
 g.globalCompositeOperation='lighter';const br=.55+.2*Math.sin(t*1.8+ph*5)+.45*w+.4*cc;rpGlow(g,0,gy,9+4*w,9+4*w,M.glow,br);
 for(const k of [-1,1])rpGlow(g,k*2.6*s,yh+1.6*s,4.2,3,M.eye,.7+.3*Math.sin(t*2.6+ph)+.4*w);g.globalCompositeOperation='source-over';g.globalAlpha=ga;
 for(const k of [-1,1]){g.fillStyle=M.eye;g.beginPath();g.ellipse(k*2.6*s,yh+1.6*s,1.5*s,.8*s,0,0,TAU);g.fill()}
 /* which hands hold a glaive, and which arm throws */
 const two=tier>=3,side=tw&&tw.mbSide?tw.mbSide:1,hold=tw&&tw.mbHold?tw.mbHold:[1,1,1];
 for(const k of [-1,1]){const active=two||k===side,holding=active&&(two?hold[k<0?0:1]:hold[0]),a=rpmbArmA(tw,k,t,ph,active,holding),S=rpmbShoulder(tier,k);
  g.save();g.translate(S.x,S.y);g.scale(k,1);g.rotate(-a);g.globalAlpha=ga;rpPut(g,rpmbArmS(tier,active&&!holding));g.restore();
  if(holding){const H=rpmbHand(tier,k,a),l=6.5*s,dx=k*Math.sin(a),dy=Math.cos(a),bob=Math.sin(t*1.6+ph*4+k)*.7;
   const rot=k*(Math.PI-a)*(.55+.45*w)+Math.sin(t*1.2+ph+k)*.06*(1-w);g.globalAlpha=ga;
   if(tier>=4&&!lt){g.globalCompositeOperation='lighter';rpGlow(g,H.x+dx*l,H.y+dy*l+bob,16,12,M.glow,.45+.3*w);g.globalCompositeOperation='source-over';g.globalAlpha=ga}
   rpmbBlade(g,H.x+dx*l,H.y+dy*l+bob,tier,rot,1,s*.92,1)}}
 /* tier 5: the third glaive hovers over the helm, turning slowly */
 if(tier>=5&&(!tw||hold[2])){const y=yh-26*s+Math.sin(t*1.5+ph)*2.2,r=t*.9+ph,sy=.5+.12*Math.sin(t*.7);g.globalCompositeOperation='lighter';rpGlow(g,0,y,22,14,M.glow,.55+.2*Math.sin(t*2));g.globalCompositeOperation='source-over';g.globalAlpha=ga;
  rpmbBlade(g,0,y,tier,r,sy,.95,1)}
 g.globalAlpha=ga}
{const p0=rpTowerParts;rpTowerParts=function(g,type,tier,skin,t,o,nopad){if(type!=='moon')return p0.apply(this,arguments);
 const P=rpPalT(type,skin,tier),L=RPLAY[type][tier],ph=o.ph||0;
 if(tier>=4){if(!nopad)rpAscGround(g,tier,t,ph,1);rpAscLive(g,type,tier,t,ph,L,0)}
 g.globalAlpha=RPGA;rpPut(g,nopad?rpBody(type,tier,skin):rpBack(type,tier,skin));
 {const q=RPPULSE[type];g.globalCompositeOperation='lighter';g.globalAlpha=RPGA*(1-q[1]+q[1]*Math.sin(t*q[0]+ph*7));rpPut(g,rpGlowLayer(type,tier,skin));g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}
 if(!nopad){const u=((t+ph*2.3)*.28)%1;if(u<.12){const v=u/.12*tier,i=Math.min(tier-1,v|0);g.globalCompositeOperation='lighter';rpGlow(g,(i-(tier-1)/2)*10,RPPIPY-1,8,8,'#fff6c8',Math.sin(Math.PI*(v-i))*.95);g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}}
 rpmbLive(g,tier,P,t,o,L,ph);
 if(tier>=4)rpAscLive(g,type,tier,t,ph,L,1);
 g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}}
{const w0=rpTowerWarm;rpTowerWarm=function(type,tier,skin){const r=w0.apply(this,arguments);if(type==='moon'){tier=rpmbT(tier);try{rpmbArmS(tier,0);rpmbArmS(tier,1);rpmbBladeS(tier);rpmbGhostS(tier);rpmbSparkS(tier);if(tier>=4)rpmbWakeS(tier);if(tier>=5)rpmbEclS()}catch(e){}}return r}}
/* the 9.9p glow and particle layer (97k): moonlight at the chest stone and the eyes (and the crescent at tier 3+); silver motes */
try{if(typeof RPG_SRC!=='undefined'){RPG_SRC.moon=[0,1,2,3,4,5].map(t=>{if(!t)return null;const L=RPLAY.moon[t],s=L.s,M=rpmbMet(t),a=[[0,L.py-40.5*s,[0,20,22,24,26,28][t],t===4?'#c890ff':t===5?'#fff0c0':'#bfe0ff'],[0,L.py-58*s,12,M.eye]];
  if(t>=3)a.push([0,L.py-56*s+22*s,30,M.glow]);return a});
 RPG_PAR.moon={k:'orbit',n:[0,2,3,4,5,6],c:['#e8f0ff','#bfe0ff','#fff6d8'],s:'star',y:[0,-62,-72,-80,-84,-88],r:[0,30,32,36,38,40],z:2.6}}}catch(e){}
