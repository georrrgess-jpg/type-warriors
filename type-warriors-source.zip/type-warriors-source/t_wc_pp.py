import asyncio,os,sys,time
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append('PE '+str(e)[:400]))
        await pg.goto('file://'+os.path.abspath((sys.argv[1] if len(sys.argv)>1 else 'out.html')));await pg.wait_for_timeout(1200);E=pg.evaluate
        await E("()=>{RS_ASK=false;P.gold=5000;P.name='Seth';save();wcHome();wcLobby();WCL.seats[1]={k:'local',name:'Mia'};WCL.seats[2]={k:'bot'};WCL.seats[3]={k:'local',name:'Jordan'};wcLobbyRender()}")
        await pg.click('#wcgo');await pg.add_script_tag(path=os.path.abspath('t_wc_agent.js'))
        t0=time.time();curt=0;shot=0;hidden_ok=True
        while time.time()-t0<300:
            await pg.wait_for_timeout(400)
            if await E("()=>!!document.getElementById('wcimr')"):
                h=await E("()=>{const t=document.createElement('div');t.innerHTML=wcBack(wcBackSel());const ref=t.querySelector('svg').innerHTML,hc=[...document.querySelectorAll('.wchc')];return hc.length>0&&hc.every(e=>e.querySelector('svg').innerHTML===ref)}")
                hidden_ok=hidden_ok and h
                if not shot:await pg.screenshot(path='shots/wc_pp_curtain.png');shot=1
                curt+=1;await pg.click('#wcimr')
            if await E("()=>!!document.getElementById('wcr')"):break
        print('pp done',round(time.time()-t0),'s curtains',curt,'hands hidden behind curtain',hidden_ok)
        print(await E("()=>[document.querySelector('.wcrh').textContent,wcSt().byd.pp,P.gold]"))
        await pg.screenshot(path='shots/wc_pp_res.png');print(er[:5]);await b.close()
asyncio.run(main())
