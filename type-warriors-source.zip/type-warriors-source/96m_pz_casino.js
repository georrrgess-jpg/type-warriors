/* ===== 9.4 THE CROOKED CUE: casino entry, Special-tab card, trophies (96m) =====
   Wired the way Wildcard is (89f): a GAMES entry, a gameOpen branch, a feature card on the Special tab and a switcher button.
   No Updates-tab (bell) notice: the owner has to ask for one and okay it first. */
TA.pz=`<svg viewBox="0 0 320 176" preserveAspectRatio="xMidYMid slice"><defs><radialGradient id="pzta" cx=".5" cy=".6" r=".8"><stop offset="0" stop-color="#2f9a68"/><stop offset=".55" stop-color="#14573a"/><stop offset="1" stop-color="#06201a"/></radialGradient><linearGradient id="pztw" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#9a5424"/><stop offset="1" stop-color="#5a2c10"/></linearGradient><radialGradient id="pzth" cx=".35" cy=".3" r=".8"><stop offset="0" stop-color="#fff" stop-opacity=".9"/><stop offset=".4" stop-color="#fff" stop-opacity="0"/></radialGradient></defs>
 <rect width="320" height="176" fill="url(#pzta)"/><rect x="-10" y="-10" width="340" height="196" rx="18" fill="none" stroke="url(#pztw)" stroke-width="22"/><rect x="-10" y="-10" width="340" height="196" rx="18" fill="none" stroke="#12081f" stroke-width="3"/>
 <ellipse cx="160" cy="84" rx="150" ry="80" fill="#ffeeb0" opacity=".08"/>
 ${[[1,'#f2c21b',0],[2,'#1e4fd8',1],[3,'#e0262e',1],[4,'#6a2aa8',2],[8,'#14121a',2],[5,'#f27a1b',2],[9,'#f2c21b',3],[6,'#178a3e',3],[7,'#8a1a1a',3],[10,'#1e4fd8',3]].map(([n,c,r],i,a)=>{const rowIdx=a.slice(0,i).filter(x=>x[2]===r).length,cnt=a.filter(x=>x[2]===r).length,x=206+r*17,y=88+(rowIdx-(cnt-1)/2)*18,st=n>8;return `<g><circle cx="${x}" cy="${y}" r="9" fill="${st?'#f6f1e6':c}" stroke="#12081f" stroke-width="1.6"/>${st?`<rect x="${x-9}" y="${y-4}" width="18" height="8" fill="${c}" clip-path="circle(9px at 9px 4px)"/>`:''}<circle cx="${x}" cy="${y}" r="4.2" fill="#fbf7ee"/><circle cx="${x-3}" cy="${y-3.5}" r="2.3" fill="url(#pzth)"/></g>`}).join('')}
 <circle cx="86" cy="88" r="9" fill="#f6f1e6" stroke="#12081f" stroke-width="1.6"/><circle cx="83" cy="84.5" r="2.5" fill="#fff"/><circle cx="90" cy="92" r="1.7" fill="#e0262e"/>
 <g transform="rotate(-8 100 90)"><rect x="-70" y="87" width="150" height="6" rx="3" fill="#e8c890" stroke="#12081f" stroke-width="1.6"/><rect x="-70" y="87" width="60" height="6" rx="3" fill="#5a1a1a" stroke="#12081f" stroke-width="1.6"/><rect x="78" y="87.5" width="3" height="5" fill="#3a86e8"/></g>
 <g fill="#ffd45a"><path d="M40 30l3 7 7 3-7 3-3 7-3-7-7-3 7-3z"/><path d="M282 40l2 5 5 2-5 2-2 5-2-5-5-2 5-2z"/></g></svg>`;
GAMES.unshift({id:'pz',n:'Crooked Cue Pool',d:'NEW · 8-ball in a tavern full of monsters. Real physics, spin, banks and bar-room taunts.',m:()=>pzHub()});
{const g0=gameOpen;gameOpen=function(id){if(id==='pz'){CAS.tok++;cFlush();pzHub();return}return g0.apply(this,arguments)}}
function pzFeat(){const Z=PZS();const n=PZ_ORDER.filter(k=>(Z.beat[k]||0)>0).length;return `<div class="twfeat pzfeat"><button class="twfart" data-g="pz" aria-label="Play Crooked Cue Pool"><span class="twfa">${TA.pz}</span><i class="co c1"></i><i class="co c2"></i><i class="co c3"></i><i class="co c4"></i><span class="twrib pzrib">UPDATE 9.4</span></button>
 <div class="twfinfo"><div class="twfk"><span class="twbadge pzbadge">POOL</span><span class="twnew">NEW</span></div><h3>The Crooked Cue</h3>
 <p>Real-physics 8-ball against the bar-room regulars. Spin the cue ball, bank your shots, and type taunts at the monsters when they miss.</p>
 <ul class="twfl"><li><b>Regulars</b> seven monsters, from Gloop to Mortimer Bonechalk</li><li><b>Stakes</b> from 50 up to 5,000, win up to ×3</li><li><b>Prizes</b> signature cues, felts and ball sets</li></ul></div>
 <div class="twfside"><div class="twfs"><span>Wins</span><b>${cmn(Z.wins)}</b></div><div class="twfs"><span>Regulars beaten</span><b>${n} / 7</b></div><div class="twfs"><span>Best streak</span><b>${Z.best||'–'}</b></div><button class="twplay" data-g="pz">Play now</button></div></div>`}
{const t0=twLobby;twLobby=function(){const sp=CAS.sp||'wc';if(sp!=='pz'){t0.apply(this,arguments)}else{const g=$('gdgrid');g.className='gdgrid twspecial';g.innerHTML=pzFeat()+`<div class="nssw"><button data-sp="ns">Nebula Scratch</button><button data-sp="tw">Tower Climb</button></div>`;g.querySelectorAll('[data-g]').forEach(x=>x.onclick=()=>gameOpen('pz'))}
 const sw=$('gdgrid')&&$('gdgrid').querySelector('.nssw');if(sw&&!sw.querySelector('[data-sp=pz]')){const b=document.createElement('button');b.dataset.sp='pz';b.innerHTML='<i class="nsdot"></i>Crooked Cue<em>NEW</em>';sw.appendChild(b);
  sw.querySelectorAll('button').forEach(x=>{x.classList.toggle('on',x.dataset.sp===(CAS.sp||'wc'));x.onclick=e=>{e.stopPropagation();if(x.dataset.sp===(CAS.sp||'wc'))return;CAS.sp=x.dataset.sp;beep(620,.05,'triangle',.5);twLobby()}})}}}
{const st=document.createElement('style');st.textContent=`.pzbadge{background:#1e3a5a!important;border-color:#5ab0d8!important;color:#c8ecff!important}.pzrib{background:linear-gradient(90deg,#2a8a5a,#d8a03a)!important}`;document.head.appendChild(st)}
/* the dock's "Choose a mode" card keeps working through gameOpen('pz'); the corner Casino button is hidden on the pool screens like Wildcard's */
{const c0=dkCorner;dkCorner=function(){const r=c0.apply(this,arguments);try{const c=$('cn');if(c&&ov.classList.contains('pzx')&&!ov.classList.contains('hide'))c.classList.add('dkhid')}catch(e){}return r}}
/* the main canvas is not redrawn behind pool screens (they are opaque) */
{const d0=draw;draw=function(){if(S.mode==='title'&&ov.classList.contains('pzx')&&!ov.classList.contains('hide'))return;return d0.apply(this,arguments)}}
/* ---------- trophies (Casino category) ---------- */
{const AP=(id,t,n,d,tg,v,g,sp)=>{if(!ACH.some(a=>a.id===id))A(id,'Casino',t,n,d,tg,v,g,sp)};
 AP('pz1',0,'First Rack','Win a rack of pool in The Crooked Cue.',1,()=>AS('pzr'),100);
 AP('pz100',1,'Pocket Full','Pocket 100 balls in The Crooked Cue.',100,()=>AS('pzp'),300);
 AP('pzbnr',2,'Run the Table','Win a rack without your opponent ever getting a shot.',1,()=>AS('pzbnr'),600,1);
 AP('pzgold',2,'Golden Break','Pocket the 8 on the break.',1,()=>AS('pzgold'),600,1);
 AP('pzbank',1,'Bank Artist','Pocket 10 balls off a cushion.',10,()=>AS('pzbk'),300);
 AP('pzall',2,'Regular','Beat all seven regulars of The Crooked Cue.',7,()=>AS('pzall'),1000,1);
 AP('pzchamp',3,'Champion of the Crooked Cue','Beat Mortimer Bonechalk.',1,()=>AS('pzchamp'),2000,2);
 AP('pzpro',3,'No Training Wheels','Beat Mortimer with the Pro guide.',1,()=>AS('pzpro'),2500,2);
 AP('pzshade',2,'Hustled the Hustler','Beat Slick Shade.',1,()=>AS('pzshade'),800,1);
 AP('pztaunt',0,'Silver Tongue','Rattle monsters with 10 typed taunts.',10,()=>AS('pztaunt'),150);
 AP('pztrick',2,'Trick Shot Master','Earn 3 stars on all 10 trick shots.',1,()=>AS('pztrick'),1000);
 AP('pzw25',1,'Pool Shark','Win 25 matches of pool.',25,()=>AS('pzw'),400)}
