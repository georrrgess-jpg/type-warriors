/* ---------- casino lair: painted scene, hoards, vault ---------- */
const cdMk=(w,h)=>{const c=document.createElement('canvas');c.width=w;c.height=h;return c};
/* Catmull-Rom spline through x,y pairs, appended to the current path */
function cdCR(g,p,closed,mv){const n=p.length/2,P=i=>{i=closed?((i%n)+n)%n:Math.max(0,Math.min(n-1,i));return[p[i*2],p[i*2+1]]};
 if(mv!==false)g.moveTo(p[0],p[1]);const e=closed?n:n-1;
 for(let i=0;i<e;i++){const a=P(i-1),b=P(i),c=P(i+1),d=P(i+2);g.bezierCurveTo(b[0]+(c[0]-a[0])/6,b[1]+(c[1]-a[1])/6,c[0]-(d[0]-b[0])/6,c[1]-(d[1]-b[1])/6,c[0],c[1])}
 if(closed)g.closePath()}
/* points along an open spline */
function cdSamp(p,per){const n=p.length/2,P=i=>{i=Math.max(0,Math.min(n-1,i));return[p[i*2],p[i*2+1]]},o=[];
 for(let i=0;i<n-1;i++){const a=P(i-1),b=P(i),c=P(i+1),d=P(i+2);for(let k=0;k<per;k++){const t=k/per,t2=t*t,t3=t2*t;
  const f=(u0,u1,u2,u3)=>.5*((2*u1)+(-u0+u2)*t+(2*u0-5*u1+4*u2-u3)*t2+(-u0+3*u1-3*u2+u3)*t3);o.push([f(a[0],b[0],c[0],d[0]),f(a[1],b[1],c[1],d[1])])}}
 o.push(P(n-1));return o}
/* layer: draws fn in absolute coordinates onto a canvas that covers x,y,w,h */
function cdLayer(x,y,w,h,fn){const c=cdMk(w,h),g=c.getContext('2d');g.translate(-x,-y);fn(g);return{c,x,y,w,h}}
/* inner shadow / inner glow trick: the outside of the shape casts a shadow into it */
function cdIn(g,pf,col,ox,oy,bl){g.save();g.beginPath();pf(g);g.clip();g.shadowColor=col;g.shadowBlur=bl;g.shadowOffsetX=ox;g.shadowOffsetY=oy;
 g.beginPath();g.rect(-3000,-3000,8000,8000);pf(g);g.fillStyle='#000';g.fill('evenodd');g.restore()}
/* scale texture */
function cdScales(g,pf,x0,y0,x1,y1,s,dark,lite,seed){g.save();g.beginPath();pf(g);g.clip();const sy=s*.64;let row=0;
 for(let y=y0;y<y1+s;y+=sy,row++)for(let x=x0-s;x<x1+s;x+=s){const cx=x+(row&1?s/2:0),cy=y,r=rnd(cx*.13+cy*.71+(seed||0));
  g.beginPath();g.moveTo(cx-s/2,cy-sy*.15);g.quadraticCurveTo(cx-s/2,cy+sy*1.05,cx,cy+sy*1.1);g.quadraticCurveTo(cx+s/2,cy+sy*1.05,cx+s/2,cy-sy*.15);
  g.fillStyle=r>.5?'rgba(255,225,120,'+((r-.5)*.22)+')':'rgba(70,24,0,'+((.5-r)*.28)+')';g.fill();
  g.strokeStyle=dark;g.lineWidth=Math.max(1,s*.09);g.stroke();
  g.beginPath();g.moveTo(cx-s*.34,cy+sy*.05);g.quadraticCurveTo(cx-s*.26,cy+sy*.72,cx-s*.02,cy+sy*.8);g.strokeStyle=lite;g.lineWidth=Math.max(1,s*.075);g.stroke()}
 g.restore()}
/* coin and gem sprites for the hoard */
function cdCoin(g,x,y,r,k){const ry=r*(.42+.18*rnd(k+3)),rot=(rnd(k+9)-.5)*.9;g.save();g.translate(x,y);g.rotate(rot);
 g.beginPath();g.ellipse(0,r*.12,r,ry,0,0,TAU);g.fillStyle='#6a3c06';g.fill();
 g.beginPath();g.ellipse(0,0,r,ry,0,0,TAU);g.fillStyle=vgr(g,-ry,ry,'#fff0a0','#d89418');g.fill();g.strokeStyle='#5a2c00';g.lineWidth=1.3;g.stroke();
 g.beginPath();g.ellipse(0,0,r*.66,ry*.62,0,0,TAU);g.strokeStyle='#a8680c';g.lineWidth=1;g.stroke();
 g.beginPath();g.ellipse(-r*.2,-ry*.25,r*.34,ry*.2,0,0,TAU);g.fillStyle='#fffbe0aa';g.fill();g.restore()}
function cdGem(g,x,y,r,c,k){g.save();g.translate(x,y);g.rotate((rnd(k)-.5)*.8);
 poly(g,[0,-r,r*.8,-r*.25,r*.55,r*.8,-r*.55,r*.8,-r*.8,-r*.25],c,'#1a0408',1.6);
 poly(g,[0,-r,r*.8,-r*.25,0,r*.05,-r*.8,-r*.25],shade(c,.45));poly(g,[0,r*.05,r*.8,-r*.25,r*.55,r*.8],shade(c,-.28));
 poly(g,[-r*.45,-r*.5,-r*.1,-r*.72,-r*.05,-r*.35],'#ffffffcc');g.restore()}
/* a mound of treasure: back = mound silhouette, then many coins and gems, sorted so lower ones sit in front */
function cdPile(g,cx,by,w,h,seed,n,gems){
 const top=u=>by-h*Math.pow(Math.max(0,1-Math.abs(u)*Math.abs(u)),.8);
 g.beginPath();g.moveTo(cx-w/2,by+40);for(let i=0;i<=24;i++){const u=-1+i/12;g.lineTo(cx+u*w/2,top(u)+4)}g.lineTo(cx+w/2,by+40);g.closePath();g.fillStyle=vgr(g,by-h,by,'#c88a1c','#4a2406');g.fill();
 const L=[];for(let i=0;i<n;i++){const u=(rnd(seed+i*1.7)-.5)*2.06,tp=top(u),y=tp+Math.pow(rnd(seed+i*2.9+4),.7)*(by+30-tp);L.push({u,y,r:10+rnd(seed+i*.37)*9,k:seed+i})}
 L.sort((a,b)=>a.y-b.y);for(const c of L){cdCoin(g,cx+c.u*w/2,c.y,c.r,c.k);const d=(c.y-by+h)/h;if(d<.5)continue}
 const gl=['#e8203c','#2ad07a','#3a8ae8','#e8203c','#b04ae8','#ffd040'];
 for(let i=0;i<(gems||0);i++){const u=(rnd(seed+i*5.3+80)-.5)*1.7,tp=top(u),y=tp+8+rnd(seed+i*3.1+90)*h*.5;cdGem(g,cx+u*w/2,y,10+rnd(seed+i)*8,gl[i%gl.length],seed+i)}}
/* the dragon-head emblem on the banners */
function cdSigil(g,x,y,s){g.save();g.translate(x,y);g.scale(s,s);
 const gold=vgr(g,-50,50,'#fff0a0','#d8921a');
 g.fillStyle=gold;g.strokeStyle='#4a2400';g.lineWidth=2;
 g.beginPath();g.moveTo(0,-62);g.lineTo(10,-40);g.lineTo(26,-62);g.lineTo(24,-30);g.lineTo(32,-8);g.lineTo(18,10);g.lineTo(12,42);g.lineTo(0,58);g.lineTo(-12,42);g.lineTo(-18,10);g.lineTo(-32,-8);g.lineTo(-24,-30);g.lineTo(-26,-62);g.lineTo(-10,-40);g.closePath();g.fill();g.stroke();
 g.fillStyle='#8a0a1c';g.beginPath();g.moveTo(-20,-6);g.lineTo(-6,-2);g.lineTo(-12,6);g.closePath();g.fill();g.beginPath();g.moveTo(20,-6);g.lineTo(6,-2);g.lineTo(12,6);g.closePath();g.fill();
 g.strokeStyle='#4a2400';g.lineWidth=2.4;g.beginPath();g.moveTo(-6,26);g.lineTo(-3,34);g.moveTo(6,26);g.lineTo(3,34);g.stroke();g.restore()}
function cdGlow(g,x,y,r,c){const q=g.createRadialGradient(x,y,0,x,y,r);q.addColorStop(0,c);q.addColorStop(1,c.replace(/,[\d.]+\)$/,',0)'));g.fillStyle=q;g.fillRect(x-r,y-r,r*2,r*2)}
