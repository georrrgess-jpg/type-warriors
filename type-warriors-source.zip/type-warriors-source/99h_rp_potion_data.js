/* ===== RUNESTONE TOWER DEFENSE 10.3: Potions, data and save (99h, after 99g; prefix rppt) =====
   UPDATE_10_3_PLAN.md. Eight potions are brewed between battles with coins (a coin sink) and carried into battle in a three-slot satchel.
   In battle each slot is used once: drinks work on the whole map for a few seconds, throws are aimed like the Slow Field.
   Rules (RPPTX): three slots, one use each; a shared cooldown after any potion; none in the first seconds of wave 1; at most RPPTX.cap
   of each potion in stock; a first-time gift (one Fury Draught, one Frostbite Flask) when the Witch’s Cauldron is first opened; drinks of the
   same kind never stack (a second one refreshes the time); a potion is spent the moment it is used, won or lost.
   Save P.rp.pot (rpptSave repairs it every time it is read):
     st  {id: 0..cap}        stock
     sat [id|'', x3]         the satchel (a slot holds a potion kind; a kind can fill more than one slot)
     gift 0|1                the first-time gift taken
     seen 0|1                the Witch’s Cauldron opened at least once (the hub button's "New" badge)
     n   {id: count}         potions used (all time),  b {id: count} potions brewed,  c coins spent on brewing
     tip {key: 1}            first-time tips shown (belt, throw, drink)
   Unlocks: Fury, Quicksilver and Frostbite from the start; Dragonfire 6 stars, Mending 12, Hourglass 18 (stars over all nine campaign
   maps, rpStarN); Gilded with World 2 open, Seer's with World 3 open (rpWorldOpen). A locked potion keeps its stock but cannot sit in
   the satchel. */
const RPPT_ORDER=['fury','quick','frost','fire','mend','hour','gild','seer'];
/* numbers: the plan's start values, tuned by the balance test (t_potbal103.py; HANDOFF 10.3): Frostbite 110 px / 2.5 s -> 120 px / 3 s,
   Hourglass 35% / 6 s -> 40% / 8 s, Gilded +50% / 20 s / 350 -> +25% / 12 s / 400, Seer's 15 s / +15% -> 18 s / +20% */
const RPPD={
 fury:{n:'Fury Draught',sh:'Fury',col:'#ff4a5a',c2:'#ffb0a0',kind:'drink',dur:12,k:.25,cost:300,
  desc:'Every tower deals +25% damage for 12 s.',cd:'Every tower deals +25% damage for 12 s.',tag:'+25% damage'},
 quick:{n:'Quicksilver Tonic',sh:'Quicksilver',col:'#cfe2f4',c2:'#ffffff',kind:'drink',dur:10,k:.3,cost:300,
  desc:'Every tower fires 30% faster for 10 s.',cd:'Every tower fires 30% faster for 10 s.',tag:'+30% fire rate'},
 frost:{n:'Frostbite Flask',sh:'Frostbite',col:'#5ab8ff',c2:'#d8f4ff',kind:'throw',r:120,dur:3,bossK:.5,cost:350,
  desc:'Throw it: monsters within 120 px freeze for 3 s. Bosses are slowed by half instead.',cd:'Monsters within 120 px freeze for 3 s. Bosses slow down instead.',tag:'Freeze 3 s'},
 fire:{n:'Dragonfire Bomb',sh:'Dragonfire',col:'#ff8a2a',c2:'#ffd27a',kind:'throw',r:90,dmg:260,burn:40,burnT:5,cost:400,stars:6,
  desc:'Throw it: 260 damage within 90 px, then the ground burns for 5 s (40 per second).',cd:'260 damage within 90 px, then 5 s of burning ground.',tag:'260 blast + fire'},
 mend:{n:'Elixir of Mending',sh:'Mending',col:'#5aeb8a',c2:'#d8ffe0',kind:'drink',heal:5,dur:5,cost:450,stars:12,
  desc:'The castle regains 5 health over 5 s (never above its maximum).',cd:'The castle regains 5 health over 5 s.',tag:'+5 health'},
 hour:{n:'Hourglass Brew',sh:'Hourglass',col:'#b47aff',c2:'#ecdcff',kind:'drink',k:.4,dur:8,bossK:.5,cost:500,stars:18,
  desc:'Every monster on the map moves 40% slower for 8 s (bosses half as much).',cd:'Every monster moves 40% slower for 8 s.',tag:'-40% speed'},
 gild:{n:'Gilded Tonic',sh:'Gilded',col:'#ffd45a',c2:'#fff4c0',kind:'drink',k:.25,dur:12,cost:400,world:2,
  desc:'Kills give +25% supply for 12 s (coins unchanged).',cd:'Kills give +25% supply for 12 s.',tag:'+25% supply'},
 seer:{n:"Seer's Tincture",sh:'Seer',col:'#3ae0c8',c2:'#c8fff4',kind:'drink',dur:18,rng:.2,cost:400,world:3,
  desc:'For 18 s towers see through fog and hiding (dive, glimmer, leap) and gain +20% range.',cd:'For 18 s towers see through fog and hiding, +20% range.',tag:'True sight'}};
const RPPTX={slots:3,cap:5,cd:20,lock:10,hold:900,fly:.55,keys:['4','5','6']};
const rpptOk=k=>typeof k==='string'&&Object.prototype.hasOwnProperty.call(RPPD,k);
/* the save, repaired on every read: bad types, unknown potions, out-of-range stock and a satchel that is not three known kinds */
function rpptSave(){const r=RPP();let p=r.pot;if(!p||typeof p!=='object'||Array.isArray(p))p=r.pot={};
 const num=(o,max)=>{const out={};if(o&&typeof o==='object'&&!Array.isArray(o))for(const k of RPPT_ORDER){const v=Math.floor(+o[k]);if(v>0&&isFinite(v))out[k]=Math.min(max,v)}return out};
 p.st=num(p.st,RPPTX.cap);p.n=num(p.n,1e7);p.b=num(p.b,1e7);
 const c=Math.floor(+p.c);p.c=c>0&&isFinite(c)?Math.min(c,1e10):0;
 let s=Array.isArray(p.sat)?p.sat.slice(0,RPPTX.slots):[];while(s.length<RPPTX.slots)s.push('');
 p.sat=s.map(k=>rpptOk(k)&&rpptOpen(k)?k:'');
 p.gift=p.gift===1?1:0;p.seen=p.seen===1?1:0;
 if(!p.tip||typeof p.tip!=='object'||Array.isArray(p.tip))p.tip={};for(const k in p.tip)if(p.tip[k]!==1)delete p.tip[k];
 for(const k in p)if(!/^(st|sat|gift|seen|n|b|c|tip)$/.test(k))delete p[k];
 return p}
/* unlocks */
function rpptOpen(k){const D=RPPD[k];if(!D)return false;try{if(D.stars&&rpStarN()<D.stars)return false;if(D.world&&!rpWorldOpen(D.world))return false}catch(e){return false}return true}
function rpptLockWhy(k){const D=RPPD[k];if(!D||rpptOpen(k))return'';
 if(D.stars){const n=(()=>{try{return rpStarN()}catch(e){return 0}})();return `Earn ${D.stars} stars to unlock (you have ${n})`}
 if(D.world===2)return'Opens with World 2 (a star on Ember Crown)';if(D.world===3)return"Opens with World 3 (a star on Kraken's Maw)";return'Locked'}
const rpptStock=k=>rpptSave().st[k]||0;
/* how many slots of the satchel hold kind k */
const rpptInSat=k=>rpptSave().sat.filter(x=>x===k).length;
/* brewing: one potion for its price, paid by the game's own code (the 98t / 98v guard allows it: a game function is on the stack) */
function rpptCanBrew(k){const D=RPPD[k];if(!D)return{ok:false,why:'Unknown potion'};if(!rpptOpen(k))return{ok:false,why:rpptLockWhy(k)};
 if(rpptStock(k)>=RPPTX.cap)return{ok:false,why:`Stock full (${RPPTX.cap})`};if((+P.gold||0)<D.cost)return{ok:false,why:`Need ${cmn(D.cost)} coins`};return{ok:true,why:''}}
function rpptBrew(k){const c=rpptCanBrew(k);if(!c.ok)return false;const D=RPPD[k],p=rpptSave(),g0=+P.gold||0;
 P.gold-=D.cost;if(!((+P.gold||0)<g0)){return false}/* the guard refused the payment: nothing is brewed */
 p.st[k]=Math.min(RPPTX.cap,(p.st[k]||0)+1);p.b[k]=(p.b[k]||0)+1;p.c+=D.cost;try{save()}catch(e){}return true}
/* the satchel */
function rpptSatSet(i,k){const p=rpptSave();if(!(i>=0&&i<RPPTX.slots))return false;if(k===''||k==null){p.sat[i]='';try{save()}catch(e){}return true}
 if(!rpptOk(k)||!rpptOpen(k))return false;p.sat[i]=k;try{save()}catch(e){}return true}
/* add to the first empty slot (or replace the last one when full); returns the slot used */
function rpptSatAdd(k){const p=rpptSave();if(!rpptOk(k)||!rpptOpen(k))return-1;let i=p.sat.indexOf('');if(i<0)i=RPPTX.slots-1;rpptSatSet(i,k);return i}
/* the first-time gift: one Fury Draught and one Frostbite Flask, put in the satchel */
function rpptGift(){const p=rpptSave();if(p.gift)return false;p.gift=1;for(const k of['fury','frost']){p.st[k]=Math.min(RPPTX.cap,(p.st[k]||0)+1);if(!p.sat.includes(k)){const i=p.sat.indexOf('');if(i>=0)p.sat[i]=k}}try{save()}catch(e){}return true}
/* what a battle takes: the satchel's kinds, as far as the stock covers them (two slots of one kind need two in stock) */
function rpptLoad(){const p=rpptSave(),use={},out=[];for(let i=0;i<RPPTX.slots;i++){const k=p.sat[i];if(k&&rpptOpen(k)&&(use[k]||0)<(p.st[k]||0)){use[k]=(use[k]||0)+1;out.push({k,i,used:0})}else out.push({k:k||'',i,used:0,empty:1,short:!!k})}return out}
/* spend one (on use, so a potion is gone whether the battle is won or lost) */
function rpptSpend(k){const p=rpptSave();if(!(p.st[k]>0))return false;p.st[k]--;if(!p.st[k])delete p.st[k];p.n[k]=(p.n[k]||0)+1;try{save()}catch(e){}return true}
