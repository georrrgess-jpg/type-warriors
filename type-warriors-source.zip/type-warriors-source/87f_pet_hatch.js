/* ===== HATCHING, REDONE: a staged, camera-driven reveal with its own sound design =====
   The result is committed (owned and saved) before this plays; the scene only presents it. Skip is available at once.
   Runeshell (Rare, about 5 s): drop, rune circle, three cracking wobbles, a charge, the cap blows off, the companion rises.
   Crownheart (Legendary, about 7 s): a sigil draws itself, the egg levitates inside spinning rune rings, gold seams split,
   light implodes into the heart gem, the petals burst open, the crown shatters into stars and the companion emerges in gold. */

/* ---------- sound: everything synthesised, routed through the game's sfx bus so the volume setting applies ---------- */
let PHNB=null;
function phAudio(){try{ensureAudio()}catch(e){}if(typeof ac==='undefined'||!ac||typeof sg==='undefined'||!sg||!ST||ST.svol<=0)return null;
 const m=ac.createGain();m.gain.value=.85;m.connect(sg);const d=ac.createDelay(1);d.delayTime.value=.24;const fb=ac.createGain();fb.gain.value=.36;const lp=ac.createBiquadFilter();lp.type='lowpass';lp.frequency.value=3000;const wet=ac.createGain();wet.gain.value=.32;d.connect(lp);lp.connect(fb);fb.connect(d);lp.connect(wet);wet.connect(m);
 if(!PHNB){PHNB=ac.createBuffer(1,ac.sampleRate*2,ac.sampleRate);const a=PHNB.getChannelData(0);let b=0;for(let i=0;i<a.length;i++){const w=Math.random()*2-1;b=(b+.02*w)/1.02;a[i]=w*.6+b*3}}
 return{m,fx:d,live:true}}
function phStop(A){if(!A||!A.live)return;A.live=false;try{const t=ac.currentTime;A.m.gain.cancelScheduledValues(t);A.m.gain.setValueAtTime(A.m.gain.value,t);A.m.gain.linearRampToValueAtTime(0,t+.18);setTimeout(()=>{try{A.m.disconnect()}catch(e){}},400)}catch(e){}}
function phTone(A,at,f,d,v,o){if(!A||!A.live)return;o=o||{};try{const t=ac.currentTime+at,os=ac.createOscillator(),g=ac.createGain();os.type=o.ty||'sine';os.frequency.setValueAtTime(f,t);if(o.f2)os.frequency.exponentialRampToValueAtTime(Math.max(20,o.f2),t+(o.fd||d));if(o.det)os.detune.value=o.det;
 const at2=o.att||.012;g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(v,t+at2);g.gain.exponentialRampToValueAtTime(.0005,t+d);os.connect(g);g.connect(A.m);if(o.echo)g.connect(A.fx);os.start(t);os.stop(t+d+.05)}catch(e){}}
function phNoise(A,at,d,v,o){if(!A||!A.live||!PHNB)return;o=o||{};try{const t=ac.currentTime+at,s=ac.createBufferSource(),f=ac.createBiquadFilter(),g=ac.createGain();s.buffer=PHNB;s.loop=true;f.type=o.ty||'bandpass';f.frequency.setValueAtTime(o.f||1200,t);if(o.f2)f.frequency.exponentialRampToValueAtTime(o.f2,t+d);f.Q.value=o.q||1;
 g.gain.setValueAtTime(0,t);if(o.swell){g.gain.linearRampToValueAtTime(v,t+d*.92);g.gain.linearRampToValueAtTime(0,t+d)}else{g.gain.linearRampToValueAtTime(v,t+(o.att||.005));g.gain.exponentialRampToValueAtTime(.0005,t+d)}s.connect(f);f.connect(g);g.connect(A.m);s.start(t,Math.random()*1.5);s.stop(t+d+.05)}catch(e){}}
const PHPEN=[523.25,587.33,659.25,783.99,880,1046.5,1174.66,1318.5,1568,1760];
const PHS={
 thud:(A,at)=>{phTone(A,at,120,.42,.5,{f2:44,fd:.3});phNoise(A,at,.22,.22,{ty:'lowpass',f:500,f2:150})},
 rune:(A,at,i)=>{const f=PHPEN[i%PHPEN.length];phTone(A,at,f,.7,.06,{echo:1,att:.02});phTone(A,at,f*2,.35,.015,{ty:'triangle'})},
 crack:(A,at,k)=>{phNoise(A,at,.08,.24*k,{f:2600,q:1.4});phNoise(A,at+.012,.05,.12*k,{ty:'highpass',f:5200});phNoise(A,at+.05,.06,.1*k,{f:1800,q:2});phTone(A,at,96,.24,.07*k,{ty:'triangle',f2:62})},
 rumble:(A,at,d,v)=>{phNoise(A,at,d,v||.16,{ty:'lowpass',f:140,f2:340,swell:1});phTone(A,at,52,d,.08,{f2:68,fd:d,att:d*.8})},
 rise:(A,at,d)=>{phTone(A,at,220,d+.1,.07,{f2:960,fd:d,att:d*.85});phNoise(A,at,d,.1,{f:380,f2:3400,q:.8,swell:1})},
 whoosh:(A,at)=>{phNoise(A,at,.55,.13,{f:3200,f2:500,q:.7})},
 boom:(A,at,big)=>{phTone(A,at,150,1.1,.55,{f2:34,fd:.9});phTone(A,at,75,.7,.18,{ty:'triangle',f2:40});phNoise(A,at,.8,.28,{ty:'lowpass',f:1100,f2:160});if(big)phNoise(A,at,1.4,.12,{f:600,f2:120,q:.6})},
 sparkle:(A,at,n)=>{for(let i=0;i<(n||9);i++){const f=PHPEN[3+((i*3)%7)]*(i%3?1:2);phTone(A,at+i*.055,f,.4,.035,{echo:1})}},
 bell:(A,at,f,v)=>{phTone(A,at,f,1.6,v||.06,{echo:1});phTone(A,at,f*2.76,.6,(v||.06)*.25);phTone(A,at,f*5.4,.25,(v||.06)*.08)},
 chord:(A,at,ns,d,v)=>{ns.forEach((f,i)=>{phTone(A,at+i*.03,f,d,v,{att:.09,echo:1});phTone(A,at+i*.03,f,d*.8,v*.5,{ty:'triangle',det:7,att:.1})})},
 choir:(A,at,d,ns,v)=>{if(!A||!A.live)return;try{const t=ac.currentTime+at,lp=ac.createBiquadFilter();lp.type='lowpass';lp.frequency.value=1500;lp.Q.value=.7;const g=ac.createGain();g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(v||.05,t+d*.45);g.gain.linearRampToValueAtTime(0,t+d);lp.connect(g);g.connect(A.m);g.connect(A.fx);
  const lfo=ac.createOscillator(),lg=ac.createGain();lfo.frequency.value=5.2;lg.gain.value=3.5;lfo.connect(lg);lfo.start(t);lfo.stop(t+d+.1);
  for(const f of ns)for(const dt of[-7,6]){const o=ac.createOscillator();o.type='sawtooth';o.frequency.value=f;o.detune.value=dt;lg.connect(o.frequency);o.connect(lp);o.start(t);o.stop(t+d+.1)}}catch(e){}},
 heart:(A,at)=>{phTone(A,at,72,.22,.42,{f2:40});phTone(A,at+.21,64,.26,.32,{f2:36})},
 shatter:(A,at)=>{for(let i=0;i<6;i++){phTone(A,at+i*.045,PHPEN[9-i]*1.5,.5,.03,{echo:1})}phNoise(A,at,.3,.08,{ty:'highpass',f:6000})}
};

/* ---------- the scene ---------- */
const PHX={};
function phBG(){if(PHX.bg)return PHX.bg;const W0=1600,H0=900,c=document.createElement('canvas');c.width=W0;c.height=H0;const b=c.getContext('2d'),cx=W0/2,fy=560;
 let q=b.createRadialGradient(cx,fy-160,40,cx,fy-160,1000);q.addColorStop(0,'#2a1e56');q.addColorStop(.55,'#130c2a');q.addColorStop(1,'#05030c');b.fillStyle=q;b.fillRect(0,0,W0,H0);
 /* vaulted arches and pillars receding into the dark */for(const [x,w,al] of[[cx-600,90,.5],[cx-380,70,.8],[cx+380,70,.8],[cx+600,90,.5]]){b.globalAlpha=al;q=b.createLinearGradient(x-w/2,0,x+w/2,0);q.addColorStop(0,'#1e1638');q.addColorStop(.5,'#2c2250');q.addColorStop(1,'#140e28');b.fillStyle=q;b.fillRect(x-w/2,0,w,fy+40);b.fillStyle='#ffffff0a';b.fillRect(x-w/2+6,0,8,fy+40);b.globalAlpha=1}
 b.strokeStyle='#2c2250';b.lineWidth=26;for(const [a,r] of[[cx-490,110],[cx+490,110]]){b.beginPath();b.arc(a,170,r,Math.PI,0);b.stroke()}
 for(const x of[cx-490,cx+490]){q=b.createLinearGradient(0,60,0,360);q.addColorStop(0,'#5a1e4a');q.addColorStop(1,'#3a1238');b.fillStyle=q;b.beginPath();b.moveTo(x-40,60);b.lineTo(x+40,60);b.lineTo(x+40,340);b.lineTo(x,305);b.lineTo(x-40,340);b.closePath();b.fill();b.strokeStyle='#c8963a';b.lineWidth=2.4;b.stroke();
  b.fillStyle='#e8b04a';b.beginPath();b.moveTo(x-18,190);b.lineTo(x-18,168);b.lineTo(x-8,180);b.lineTo(x,158);b.lineTo(x+8,180);b.lineTo(x+18,168);b.lineTo(x+18,190);b.closePath();b.fill()}
 /* floor and pedestal */q=b.createLinearGradient(0,fy-20,0,H0);q.addColorStop(0,'#1a1232');q.addColorStop(1,'#07040f');b.fillStyle=q;b.fillRect(0,fy-10,W0,H0);
 for(const [rx,ry,dy,c0,c1] of[[330,74,34,'#251d42','#0e0a1e'],[290,60,10,'#3e3462','#1c1634'],[250,50,-6,'#4e4476','#2a2248']]){q=b.createLinearGradient(0,fy+dy-ry,0,fy+dy+ry+24);q.addColorStop(0,c0);q.addColorStop(1,c1);b.fillStyle=q;b.beginPath();b.ellipse(cx,fy+dy+20,rx,ry,0,0,Math.PI);b.lineTo(cx-rx,fy+dy);b.ellipse(cx,fy+dy,rx,ry,0,Math.PI,0);b.closePath();b.fill();b.beginPath();b.ellipse(cx,fy+dy,rx,ry,0,0,TAU);b.fillStyle=c0;b.fill();b.strokeStyle='#7a6aa8';b.lineWidth=2;b.stroke()}
 q=b.createRadialGradient(cx,H0*.5,H0*.35,cx,H0*.5,W0*.7);q.addColorStop(0,'#00000000');q.addColorStop(1,'#000000c0');b.fillStyle=q;b.fillRect(0,0,W0,H0);
 return PHX.bg=c}
function ptHatchScene(id,k,opt){opt=opt||{};const wrapEl=$('wrap')||document.body;let el=$('pthx');if(el){if(el._stop)el._stop();el.remove()}el=document.createElement('div');el.id='pthx';el.className='pthx';
 const D=PDEF[id],leg=k==='l',rm=ptRM()||opt.reveal,TB=leg?3.9:3.1,TC=leg?5.7:4.5,AC=leg?'#ffc23a':'#5ff0ff',AC2=leg?'#b070ff':'#9fb8ff';
 el.innerHTML=`<canvas width="1600" height="900" id="pthc"></canvas><button class="ptskip" id="ptsk">Skip <span>⏭</span></button><div class="ptrv" id="ptrv"></div>`;wrapEl.appendChild(el);
 const cv=$('pthc'),g=cv.getContext('2d'),W0=1600,H0=900,cx=W0/2,fy=560,ey=fy-6,bg=phBG(),t0=performance.now()/1000;let done=false,raf=0,last=t0,skipped=false;
 const A=rm?null:phAudio();el._stop=()=>{phStop(A);cancelAnimationFrame(raf)};
 const ES=2.15,bx=D.box||[-60,-110,120,115],PS=Math.min(2.5,250/bx[3],320/bx[2]);
 const P_=[],shards=[],conf=[],rings=[],stars=[];let flash=0,shake=0,implode=0;
 const rnd=(a,b)=>a+Math.random()*(b-a);
 /* scripted beats (each fires once) */
 const beats=[];const at=(t,f)=>beats.push({t,f,done:false});
 const crack=leg?[]:[1.7,2.1,2.5];
 if(!leg){at(.02,()=>PHS.whoosh(A,0));at(.34,()=>{PHS.thud(A,0);shake=6;for(let i=0;i<18;i++){const a=Math.PI+Math.random()*Math.PI;P_.push({x:cx+Math.cos(a)*60,y:fy+4,vx:Math.cos(a)*rnd(60,180),vy:-rnd(10,60),l:.8,c:'#8a7ab8',s:rnd(2,4),g:60})}});
  for(let i=0;i<8;i++)at(.6+i*.12,()=>PHS.rune(A,0,i));
  crack.forEach((c,i)=>at(c,()=>{PHS.crack(A,0,.7+i*.25);shake=3+i*2.4;for(let j=0;j<4+i*3;j++)P_.push({x:cx+rnd(-60,60),y:ey-170+rnd(-30,30),vx:rnd(-90,90),vy:rnd(-140,-40),l:rnd(.5,.9),c:j%2?'#cfe0ff':'#5a8ae8',s:rnd(2,4),g:420})}));
  at(1.55,()=>PHS.rumble(A,0,1.6,.14));at(2.75,()=>PHS.rise(A,0,.35));}
 else{at(.05,()=>{PHS.rumble(A,0,1.2,.1);PHS.choir(A,.2,3.6,[196,247,294],.035)});for(let i=0;i<8;i++)at(.1+i*.09,()=>PHS.rune(A,0,i+1));
  at(.85,()=>PHS.bell(A,0,392,.05));[2.1,2.6,3.05].forEach((c,i)=>at(c,()=>{PHS.heart(A,0);PHS.crack(A,.05,.6+i*.2);shake=3+i*2}));
  at(2.0,()=>PHS.rumble(A,0,1.9,.16));at(3.4,()=>PHS.rise(A,0,.45));}
 at(TB,()=>{PHS.boom(A,0,leg);PHS.sparkle(A,.05,leg?14:9);if(leg){PHS.chord(A,.08,[261.6,329.6,392,523.3],2.6,.05);PHS.choir(A,.05,3.2,[262,330,392,523],.045)}else PHS.chord(A,.08,[293.7,370,440,587.3],2.2,.045);burst()});
 if(leg)at(TB+.62,()=>{PHS.shatter(A,0);for(let i=0;i<26;i++){const a=Math.random()*TAU,v=rnd(80,320);stars.push({x:cx,y:ey-300,vx:Math.cos(a)*v,vy:Math.sin(a)*v-60,l:rnd(1,1.6),s:rnd(4,9),r:Math.random()*6,c:i%3?'#ffd45a':'#fff6d0'})}});
 at(TB+.86,()=>{PHS.thud(A,0);shake=Math.max(shake,5);for(let i=0;i<22;i++){const a=Math.random()*TAU;P_.push({x:cx+Math.cos(a)*40,y:fy+4+Math.sin(a)*8,vx:Math.cos(a)*rnd(120,260),vy:Math.sin(a)*rnd(20,60)-20,l:.7,c:leg?'#ffe8a8':'#bfe8ff',s:rnd(2.5,4.5),g:30})}rings.push({t:0,c:'#ffffff',w:4,max:260})});
 at(TB+1,()=>{PHS.bell(A,0,leg?1046.5:880,.05);PHS.bell(A,.18,leg?1318.5:1174.7,.04)});
 at(TC,()=>{if(leg)PHS.chord(A,0,[392,493.9,587.3,784],1.8,.035);else PHS.chord(A,0,[440,554.4,659.3],1.6,.03);fin()});
 function burst(){flash=1;shake=leg?18:13;rings.push({t:0,c:AC,w:leg?16:12,max:leg?820:640},{t:-.12,c:'#ffffff',w:6,max:leg?1000:780});if(leg)rings.push({t:-.24,c:AC2,w:10,max:1100});
  const sc=leg?['#fffaf0','#f2e8d2','#ffd45a','#4a3aa8','#b070ff']:['#86b2ff','#3a6ad8','#f2f6fd','#cfd8ee','#5ff0ff'];
  for(let i=0;i<(leg?36:28);i++){const a=-Math.PI/2+rnd(-1.5,1.5),v=rnd(260,640);shards.push({x:cx+rnd(-40,40),y:ey-(leg?140:170),vx:Math.cos(a)*v,vy:Math.sin(a)*v,r:Math.random()*6,vr:rnd(-14,14),s:rnd(6,14),c:sc[i%sc.length],l:rnd(1.2,1.9),px:0,py:0})}
  const cc=leg?['#ffd45a','#fff2c0','#b070ff','#ff8ad8','#5ab0ff']:['#5ff0ff','#9fb8ff','#ffffff','#7affc8','#c8a8ff'];
  for(let i=0;i<(leg?90:60);i++){const a=rnd(0,TAU),v=rnd(120,520);conf.push({x:cx,y:ey-150,vx:Math.cos(a)*v,vy:Math.sin(a)*v-200,r:Math.random()*6,vr:rnd(-10,10),w:rnd(5,9),h:rnd(3,5),c:cc[i%cc.length],l:rnd(2,3.2),ph:Math.random()*6})}
  for(let i=0;i<30;i++){const a=rnd(0,TAU),v=rnd(60,380);P_.push({x:cx,y:ey-150,vx:Math.cos(a)*v,vy:Math.sin(a)*v,l:rnd(.8,1.4),c:i%2?'#ffffff':AC,s:rnd(3,6),g:-20,st:1})}}
 /* pet layer: drawn once per frame into its own canvas so it can rise as a glowing silhouette */
 const pl=document.createElement('canvas');pl.width=900;pl.height=800;const pg=pl.getContext('2d');
 const drawPet=(x,y,s,pose,u,sil,silC,t)=>{pg.setTransform(1,0,0,1,0,0);pg.clearRect(0,0,900,800);pg.setTransform(s,0,0,s,450,620);petDraw(pg,id,{t,pose,u,noSh:1});
  if(sil>0){pg.setTransform(1,0,0,1,0,0);pg.globalCompositeOperation='source-atop';pg.globalAlpha=sil;pg.fillStyle=silC;pg.fillRect(0,0,900,800);pg.globalAlpha=1;pg.globalCompositeOperation='source-over'}
  g.drawImage(pl,x-450,y-620)};
 const fin=()=>{if(done)return;done=true;P.petPend=null;save();const rv=$('ptrv'),st=opt.starter,more=!st&&(P.eggs[k]|0)>0&&petPool(k).length>0;
  const MS=[['acc',3,D.cos.acc],['pal',5,D.cos.pal],['cel',7,D.cos.cel],['trim',10,D.cos.sig]];
  rv.className='ptrv '+(leg?'leg':'rare');
  rv.innerHTML=`<div class="phc"><div class="phc-rib">${leg?'✦ LEGENDARY COMPANION ✦':'NEW COMPANION'}</div><div class="phc-l"><h2 class="phc-n">${esc(D.n)}</h2><div class="phc-tags">${ptBadge(D.r)}<span class="phc-fam" style="--f:${PFAM[D.fam]}">${D.fam}</span></div></div>
   <div class="phc-ab"><canvas width="72" height="72" id="ptrvi"></canvas><div><b>${D.ab.n}</b><p>${D.ab.d}</p></div></div>
   <div class="phc-ms"><small>Bond rewards to unlock</small><div>${MS.map(([kk,L,n])=>`<span title="${esc(n)} at Bond ${L}"><canvas width="64" height="52" data-hm="${kk}"></canvas><i>Bond ${L}</i></span>`).join('')}</div></div>
   <div class="ptmb phc-b">${st?`<button class="ptgo" id="ptrvq">${PTICO.paw} Meet ${esc(D.n)}</button>`:P.pet===id?`<button class="ptgo" id="ptrvq">${PTICO.chk} Equipped</button>`:`<button class="ptgo" id="ptrve">Equip ${esc(D.n)}</button><button class="ptgo b" id="ptrvq">Keep current</button>`}${more?`<button class="ptsoft" id="ptrvm">${PTICO.egg} Hatch another <em>${P.eggs[k]}</em></button>`:''}</div></div>`;
  requestAnimationFrame(()=>rv.classList.add('on'));petIconCv($('ptrvi'),D.ab.k);
  rv.querySelectorAll('canvas[data-hm]').forEach(c=>{const kk=c.dataset.hm;if(kk==='cel'){petFit(c,id,{t:1.2,pose:'greet',u:.55,still:1});const gg=c.getContext('2d'),s=c.height/110;gg.save();gg.translate(c.width/2,c.height*.9);gg.scale(s,s);petCelFx(gg,id,.4,1,-50,50);gg.restore()}else petFit(c,id,{t:1.2,still:1,[kk]:1})});
  $('ptsk').style.display='none';
  const close=(then)=>{phStop(A);cancelAnimationFrame(raf);el.classList.add('out');setTimeout(()=>el.remove(),260);PTX.sel=id;PTX.tab=then==='more'?'Eggs':'Pets';if(then==='more'){const r=petHatch(k);if(r&&r.id){petHall('Eggs');return ptHatchScene(r.id,k,{})}}petHall(PTX.tab)};
  const e=$('ptrve');if(e)e.onclick=()=>{petEquip(id);ptBeep(820,.06,.35);close()};$('ptrvq').onclick=()=>close();const mb=$('ptrvm');if(mb)mb.onclick=()=>close('more');
  setTimeout(()=>{const f=$('ptrve')||$('ptrvq');try{f&&f.focus()}catch(x){}},420)};
 const skip=()=>{if(done)return;skipped=true;phStop(A);const B=phAudio();if(B){PHS.chord(B,0,leg?[261.6,329.6,392,523.3]:[293.7,370,440,587.3],1.4,.04);PHS.bell(B,.05,leg?1046.5:880,.04);setTimeout(()=>phStop(B),1800)}flash=Math.max(flash,.5);fin()};
 $('ptsk').onclick=skip;el.tabIndex=-1;el.onkeydown=e=>{e.stopPropagation();if(e.key==='Escape'||(e.key===' '&&!done)){e.preventDefault();if(!done)skip()}};setTimeout(()=>{try{el.focus()}catch(x){}},30);
 const S_=(tt,a,b)=>pSeg(tt,a,b);
 const frame=()=>{if(!el.isConnected){phStop(A);return}const now=performance.now()/1000,dt=Math.min(.05,now-last);last=now;let tt=rm||skipped?Math.max(TC+.4,now-t0):now-t0;if(window.__phT!=null)tt=window.__phT;const t=now;
  for(const b of beats)if(!b.done&&tt>=b.t&&!skipped&&!rm){b.done=true;try{b.f()}catch(e){}}
  if(rm&&!done)fin();
  /* camera: a slow push in, a kick on the burst, then it settles */
  const post=tt-TB;let z=post<0?(leg?.92:.94)+((leg?1.14:1.1)-(leg?.92:.94))*pS(Math.max(0,tt)/TB):1+(leg?.16:.12)*Math.exp(-post*4)*Math.cos(post*7);if(rm)z=1;
  shake*=Math.pow(.02,dt);flash*=Math.pow(.004,dt);const sx=(Math.random()-.5)*shake,sy=(Math.random()-.5)*shake;
  g.setTransform(1,0,0,1,0,0);g.globalAlpha=1;g.globalCompositeOperation='source-over';
  const bz=1+(z-1)*.4;g.setTransform(bz,0,0,bz,cx*(1-bz)+sx*.4,(fy-150)*(1-bz)+sy*.4);g.drawImage(bg,0,0);
  g.setTransform(z,0,0,z,cx*(1-z)+sx,(fy-150)*(1-z)+sy);
  /* godrays behind the egg */const ri=post<0?S_(tt,leg?.8:1.2,TB)*.55:Math.max(.35,1-post*.4);
  if(ri>0){g.save();g.globalCompositeOperation='lighter';g.translate(cx,ey-150);g.rotate(t*.08);for(let i=0;i<14;i++){g.rotate(TAU/14);const len=700+Math.sin(t*1.3+i)*60,wd=i%2?26:44,q=g.createLinearGradient(0,0,0,-len);q.addColorStop(0,ptHexA(i%3?AC:'#ffffff',.22*ri));q.addColorStop(1,ptHexA(AC,0));g.fillStyle=q;g.beginPath();g.moveTo(-6,0);g.lineTo(6,0);g.lineTo(wd,-len);g.lineTo(-wd,-len);g.closePath();g.fill()}g.restore()}
  /* legendary: aurora ribbons */if(leg&&!rm){const ai=S_(tt,.8,2)*(post>0?Math.max(.4,1-post*.3):1);g.save();g.globalCompositeOperation='lighter';for(let r=0;r<3;r++){g.beginPath();for(let i=0;i<=40;i++){const x=i/40*W0,y=150+r*60+Math.sin(i*.35+t*.6+r)*40;i?g.lineTo(x,y):g.moveTo(x,y)}g.strokeStyle=ptHexA(['#b070ff','#ffc23a','#5ad8ff'][r],.12*ai);g.lineWidth=40;g.stroke()}g.restore()}
  /* floor magic: a rune circle (Rare) or a self-drawing gold sigil (Legendary) */
  g.save();g.translate(cx,fy-6);g.scale(1,.24);g.globalCompositeOperation='lighter';
  if(!leg){const on=S_(tt,.55,1.6);g.rotate(t*.25);g.strokeStyle=ptHexA('#5ff0ff',.25+.4*on);g.lineWidth=5;g.beginPath();g.arc(0,0,250,0,TAU);g.stroke();g.lineWidth=2;g.beginPath();g.arc(0,0,220,0,TAU);g.stroke();
   for(let i=0;i<8;i++){const lit=tt>.6+i*.12?1:0,a=i*TAU/8,x=Math.cos(a)*235,y=Math.sin(a)*235;g.save();g.translate(x,y);g.rotate(a+Math.PI/2);g.strokeStyle=ptHexA(lit?'#dffcff':'#5ff0ff',lit?.9:.25);g.lineWidth=lit?6:3;g.beginPath();if(i%3===0){g.moveTo(-10,-14);g.lineTo(0,14);g.lineTo(10,-14)}else if(i%3===1){g.moveTo(0,-16);g.lineTo(0,16);g.moveTo(-10,-4);g.lineTo(10,4)}else{g.arc(0,0,11,0,TAU);g.moveTo(-6,0);g.lineTo(6,0)}g.stroke();if(lit)pGlow(g,0,0,40,'#5ff0ff',.35);g.restore()}}
  else{const dr=S_(tt,.05,.85);g.rotate(-t*.12);g.strokeStyle=ptHexA('#ffd45a',.35+.4*S_(tt,.8,1.2));g.lineWidth=6;g.beginPath();g.arc(0,0,270,-Math.PI/2,-Math.PI/2+TAU*dr);g.stroke();g.lineWidth=3;g.beginPath();g.arc(0,0,236,Math.PI/2,Math.PI/2+TAU*dr);g.stroke();
   if(dr>.5){const st2=S_(tt,.45,1);g.beginPath();for(let i=0;i<=16;i++){const a=-Math.PI/2+i*TAU*3/8,r=232;i?g.lineTo(Math.cos(a)*r,Math.sin(a)*r):g.moveTo(Math.cos(a)*r,Math.sin(a)*r)}g.strokeStyle=ptHexA('#fff2b0',.45*st2);g.lineWidth=3;g.stroke()}
   for(let i=0;i<12;i++){const a=i*TAU/12;if(i/12<dr){pStar4(g,Math.cos(a)*270,Math.sin(a)*270,14,'#fff2c0');pGlow(g,Math.cos(a)*270,Math.sin(a)*270,40,'#ffd45a',.3)}}}
  g.restore();
  /* the egg */let eY=ey,lean=0,sq=1,crackP=0,cg=1,glow=.2+.15*Math.sin(t*2),lift=0,eA=1,capT=null,crownT=null,op=0,petalR=.78,petalA=1;
  if(!leg){const d=1-S_(tt,0,.34);eY=ey-d*d*620;if(tt>.34&&tt<.6){const k2=(tt-.34)/.26;sq=1-Math.sin(k2*Math.PI)*.12}
   crack.forEach((c,i)=>{const k2=(tt-c)/.32;if(k2>=0&&k2<1)lean+=Math.sin(k2*Math.PI*3)*(1-k2)*(.06+i*.035);if(tt>=c)crackP=Math.max(crackP,(i+1)/3*S_(tt,c,c+.12))});
   glow=.2+S_(tt,.6,1.6)*.4+S_(tt,2.6,TB)*.8;if(tt>2.75&&tt<TB){lean+=Math.sin(t*60)*.025;sq=1+Math.sin(t*40)*.02}cg=.6+S_(tt,2.6,TB)*.8;
   if(post>=0){const v=post;capT={x:Math.min(v,1.5)*420,y:-v*900+v*v*900*.55-60*Math.min(1,v*6),r:v*9,s:Math.max(.4,1-v*.4),a:Math.max(0,1-v*.9),glow:Math.max(0,1-v*1.2)};eA=1-S_(post,.4,.75);eY+=S_(post,.4,.75)*26}}
  else{lift=S_(tt,2,3.4);const lv=S_(tt,.8,2);eY=ey-lv*26-Math.sin(t*1.6)*4*lv;glow=.25+S_(tt,.8,2)*.4+S_(tt,3.4,TB)*.9;if(tt>2&&tt<TB)lean=Math.sin(t*38)*.012*(1+lift*1.5);implode=S_(tt,3.4,TB)*(post<0?1:0);
   if(post>=0){op=Math.min(1,post/.22);petalR=.78+post*1.4;petalA=Math.max(0,1-post*1.4);crownT=post<.62?{x:Math.sin(post*7)*20,y:-46-post*260,r:post*6,s:1+post*.4,a:1}:null;eA=1-S_(post,.42,.8);eY=ey-26+S_(post,0,.6)*26+S_(post,.42,.8)*26}}
  /* converging light before the burst */if(!rm&&post<0&&tt>(leg?3.3:2.65)){for(let i=0;i<3;i++){const a=Math.random()*TAU;P_.push({x:cx+Math.cos(a)*360,y:eY-140+Math.sin(a)*240,tx:cx,ty:eY-140,l:.5,c:i%2?'#ffffff':AC,s:rnd(2,4),seek:1})}}
  /* light leaking through the cracks (Rare) */if(!leg&&crackP>0&&post<0){g.save();g.globalCompositeOperation='lighter';g.translate(cx,eY);for(const [px,py] of[[-40,-176],[-8,-168],[24,-176],[46,-168]]){const ang=Math.atan2(py+40,px)-Math.PI/2*0;const len=120+crackP*220;g.save();g.translate(px*ES/2.15,py*ES/2.15);g.rotate(Math.atan2(py+120,px)+Math.PI/2);const q=g.createLinearGradient(0,0,0,-len);q.addColorStop(0,ptHexA('#bfffff',.4*crackP));q.addColorStop(1,'#5ff0ff00');g.fillStyle=q;g.beginPath();g.moveTo(-3,0);g.lineTo(3,0);g.lineTo(18,-len);g.lineTo(-18,-len);g.closePath();g.fill();g.restore()}g.restore()}
  if(implode>0){pGlow(g,cx,eY-158,40+implode*90,'#fff2c0',.5*implode);g.save();g.fillStyle=`rgba(5,3,12,${.35*implode})`;g.fillRect(0,0,W0,H0);g.restore()}
  const eggPos=()=>{g.save();g.globalAlpha=eA;g.translate(cx,eY);g.rotate(lean);g.scale(ES*(2-sq),ES*sq);eggDraw(g,k,{t,glow,crack:crackP,cg,cap:capT||undefined,lift,open:op,crownT:crownT||undefined,hideCrown:leg&&post>=.62,petalR,petalA,noSh:0});g.restore()};
  /* the companion */const em=post>=0?post:-1;let petY=fy+50,petA=0,silA=1,ps=PS,pose='idle',pu=0;
  if(em>=0){petA=S_(em,0,.12);const up=S_(em,.04,.45),dn=S_(em,.45,.86),hi=leg?190:170;petY=em<.45?fy+40-(hi+40)*(1-(1-up)*(1-up)):fy-hi+hi*dn*dn;silA=1-S_(em,.3,.85);ps=PS*(.7+S_(em,.04,.4)*.3);
   /* a little squash on landing */if(em>.86&&em<1.06){const k2=(em-.86)/.2;ps*=1-Math.sin(k2*Math.PI)*.06}
   if(em>.95){const gk=(em-.95)/1.7;if(gk<1){pose='greet';pu=gk}else{const c2=((em-2.65)%5.5);if(c2>4&&c2<5.6){pose='greet';pu=(c2-4)/1.6}}}else if(em>.1&&em<.86)pose='walk'}
  if(rm){petA=1;petY=fy;silA=0;ps=PS}
  /* light column behind the newcomer */if(em>=0&&!rm){const lc=Math.max(0,1-em*.35);g.save();g.globalCompositeOperation='lighter';g.translate(cx,fy-260);g.scale(.42,1.7);pGlow(g,0,0,300,AC,.34*lc);g.restore()}
  if(em>=0&&em<.12){if(petA>0){g.save();g.globalAlpha=petA;drawPet(cx,petY,ps,pose,pu,silA,leg?'#fff2c0':'#e8ffff',t);g.restore()}eggPos()}
  else if(em>=.12&&em<1.2){eggPos();g.save();g.globalAlpha=petA;drawPet(cx,petY,ps,pose,pu,silA,leg?'#fff2c0':'#e8ffff',t);g.restore()}
  else if(em>=1.2||rm){if(eA>0)eggPos();g.save();g.globalAlpha=petA;drawPet(cx,petY,ps,pose,pu,silA,'#fff',t);g.restore()}
  else eggPos();
  /* celebration around the newcomer */if(em>.95&&em<2.75&&!rm){g.save();g.translate(cx,fy);g.scale(ps,ps);petCelFx(g,id,(em-.95)/1.8,t,-bx[3]*.5,Math.max(bx[2],bx[3])*.7);g.restore()}
  /* shockwaves, flash and particles */g.save();g.globalCompositeOperation='lighter';
  for(let i=rings.length-1;i>=0;i--){const r=rings[i];r.t+=dt;if(r.t<0)continue;const v=r.t/1.1;if(v>=1){rings.splice(i,1);continue}g.save();g.translate(cx,ey-150);g.scale(1,.62);g.beginPath();g.arc(0,0,40+pS(v)*r.max,0,TAU);g.strokeStyle=ptHexA(r.c,(1-v)*.9);g.lineWidth=r.w*(1-v)+2;g.stroke();g.restore()}
  if(flash>.01){pGlow(g,cx,ey-150,460*(1.4-flash*.4),AC,.5*flash);pGlow(g,cx,ey-150,200,'#ffffff',.55*flash);g.fillStyle=ptHexA('#ffffff',.35*flash);g.fillRect(cx-700*flash,ey-152,1400*flash,4)}
  g.restore();
  for(let i=shards.length-1;i>=0;i--){const s=shards[i];s.l-=dt;if(s.l<=0||s.y>H0+40){shards.splice(i,1);continue}s.px=s.x;s.py=s.y;s.vy+=900*dt;s.vx*=Math.pow(.6,dt);s.x+=s.vx*dt;s.y+=s.vy*dt;s.r+=s.vr*dt;
   g.globalAlpha=Math.min(1,s.l*1.5);g.strokeStyle=ptHexA(s.c,.35);g.lineWidth=s.s*.5;g.beginPath();g.moveTo(s.px-s.vx*.03,s.py-s.vy*.03);g.lineTo(s.x,s.y);g.stroke();g.save();g.translate(s.x,s.y);g.rotate(s.r);pP(g,[-s.s,-s.s*.5,s.s*.9,-s.s*.3,s.s*.2,s.s*.8]);pF(g,s.c,2);pP(g,[-s.s,-s.s*.5,s.s*.9,-s.s*.3,0,0]);g.fillStyle='#ffffff44';g.fill();g.restore();g.globalAlpha=1}
  for(let i=conf.length-1;i>=0;i--){const c=conf[i];c.l-=dt;if(c.l<=0){conf.splice(i,1);continue}c.vy+=260*dt;c.vx*=Math.pow(.35,dt);c.vy*=Math.pow(.5,dt);c.x+=(c.vx+Math.sin(t*3+c.ph)*40)*dt;c.y+=c.vy*dt;c.r+=c.vr*dt;g.save();g.globalAlpha=Math.min(1,c.l);g.translate(c.x,c.y);g.rotate(c.r);g.scale(1,Math.cos(t*8+c.ph));g.fillStyle=c.c;g.fillRect(-c.w/2,-c.h/2,c.w,c.h);g.restore()}
  for(let i=stars.length-1;i>=0;i--){const s=stars[i];s.l-=dt;if(s.l<=0){stars.splice(i,1);continue}s.vy+=120*dt;s.x+=s.vx*dt;s.y+=s.vy*dt;s.r+=dt*4;g.globalAlpha=Math.min(1,s.l);pGlow(g,s.x,s.y,s.s*3,'#ffd45a',.5);g.save();g.translate(s.x,s.y);g.rotate(s.r);pStar5(g,0,0,s.s,s.c,1.4);g.restore();g.globalAlpha=1}
  for(let i=P_.length-1;i>=0;i--){const p=P_[i];p.l-=dt;if(p.l<=0){P_.splice(i,1);continue}if(p.seek){p.x+=(p.tx-p.x)*Math.min(1,dt*7);p.y+=(p.ty-p.y)*Math.min(1,dt*7)}else{p.vy+=(p.g||0)*dt;p.x+=p.vx*dt;p.y+=p.vy*dt}g.globalAlpha=Math.min(1,p.l*2);if(p.st)pStar4(g,p.x,p.y,p.s,p.c);else{pGlow(g,p.x,p.y,p.s*2.4,p.c,.5);g.fillStyle=p.c;g.fillRect(p.x-p.s/2,p.y-p.s/2,p.s,p.s)}g.globalAlpha=1}
  /* ambient motes once revealed */if(em>1.2||rm){for(let i=0;i<8;i++){const u=((t*.07+i/8)%1),x=cx+Math.sin(i*2.2+t*.3)*260*(.5+u*.5),y=fy-u*480,a=Math.sin(u*Math.PI)*.6;pGlow(g,x,y,8,AC,a)}}
  raf=requestAnimationFrame(frame)};
 raf=requestAnimationFrame(frame)}
{const st=document.createElement('style');st.textContent=`
.pthx{background:#05030c}.ptskip{display:flex;align-items:center;gap:6px}
.ptrv{position:absolute;left:50%;bottom:22px;transform:translateX(-50%) translateY(40px);opacity:0;pointer-events:none;transition:opacity .45s ease,transform .6s cubic-bezier(.2,1.2,.4,1)}.ptrv.on{opacity:1;pointer-events:auto;transform:translateX(-50%)}
.phc{position:relative;display:grid;grid-template-columns:auto 1fr;grid-template-areas:'l ab' 'ms ms' 'b b';align-items:center;column-gap:22px;row-gap:8px;padding:26px 26px 14px;width:min(980px,92vw);box-sizing:border-box;border-radius:22px;background:linear-gradient(180deg,#1c1446f2,#0c0822f5);border:2px solid #e8c36a;box-shadow:0 20px 60px #000c,0 0 40px #ffd16633}
.ptrv.rare .phc{border-color:#7ac8ff;box-shadow:0 20px 60px #000c,0 0 40px #5ff0ff33}
.phc-rib{position:absolute;top:-17px;left:50%;transform:translateX(-50%);padding:6px 26px;border-radius:10px;font:800 15px var(--ui);letter-spacing:2.5px;white-space:nowrap;color:#2a1406;background:linear-gradient(180deg,#fff0a0,#f0a820);border:2px solid #fff4b8;box-shadow:0 6px 18px #000a}.ptrv.rare .phc-rib{color:#06203a;background:linear-gradient(180deg,#bff6ff,#4ab8ff);border-color:#e0fbff}
.ptrv.on .phc-rib{animation:phrib .6s cubic-bezier(.2,1.4,.4,1) .15s both}@keyframes phrib{from{transform:translateX(-50%) scale(.4);opacity:0}}
.phc-l{grid-area:l;display:flex;flex-direction:column;align-items:center;gap:8px}.phc-n{margin:0;font:700 46px/1.05 'Cinzel',Georgia,serif;letter-spacing:.03em;text-shadow:none!important;-webkit-text-fill-color:transparent;color:transparent;background-image:linear-gradient(100deg,transparent 0%,transparent 42%,rgba(255,255,255,.95) 50%,transparent 58%,transparent 100%),linear-gradient(180deg,#fffbe8 0%,#ffe08a 45%,#f0a830 100%);background-size:260% 100%,100% 100%;background-repeat:no-repeat;background-position:120% 0,0 0;-webkit-background-clip:text;background-clip:text;filter:drop-shadow(0 2px 0 #3a1800) drop-shadow(0 0 1px #3a1800) drop-shadow(0 0 16px rgba(255,190,80,.45));white-space:nowrap}
.ptrv.on .phc-n{animation:phshine 2.6s ease .5s infinite,phup .5s cubic-bezier(.2,1.2,.4,1) .2s both}@keyframes phshine{0%{background-position:120% 0,0 0}60%,100%{background-position:-60% 0,0 0}}@keyframes phup{from{opacity:0;transform:translateY(14px)}}
.ptrv.rare .phc-n{background-image:linear-gradient(100deg,transparent 0%,transparent 42%,rgba(255,255,255,.95) 50%,transparent 58%,transparent 100%),linear-gradient(180deg,#ffffff 0%,#c8f0ff 45%,#5ab8ff 100%);filter:drop-shadow(0 2px 0 #0a1e4a) drop-shadow(0 0 1px #0a1e4a) drop-shadow(0 0 16px rgba(90,184,255,.45))}
.phc-tags{display:flex;gap:10px;align-items:center}.phc-tags .ptbg{align-self:center}.phc-fam{padding:3px 12px;border-radius:12px;font:700 13px var(--ui);color:var(--f);border:1.5px solid var(--f);background:#0b0717}
.phc-ab{grid-area:ab;display:flex;gap:12px;align-items:center;padding:8px 14px;border-radius:14px;background:#0b0717;border:1px solid #3a3070;max-width:560px}.phc-ab canvas{width:52px;height:52px;flex:none}.phc-ab b{font:400 24px 'Pirata One',Georgia,serif;color:#9fffb0}.phc-ab p{margin:0;font:500 14px var(--ui);color:#e8e0ff}
.phc-ms{grid-area:ms;display:flex;flex-direction:row;align-items:center;justify-content:center;gap:12px}.phc-ms small{font:700 12px var(--ui);color:#bbaed3;letter-spacing:.5px}.phc-ms>div{display:flex;gap:8px}.phc-ms span{display:flex;flex-direction:column;align-items:center;padding:4px 6px;border-radius:10px;background:#140e2a;border:1px solid #3a3070}.phc-ms canvas{width:50px;height:40px}.phc-ms i{font:700 10.5px var(--ui);font-style:normal;color:#ffd166}
.ptrv.on .phc-ab,.ptrv.on .phc-ms,.ptrv.on .phc-b{animation:phup .45s ease both}.ptrv.on .phc-ab{animation-delay:.3s}.ptrv.on .phc-ms{animation-delay:.42s}.ptrv.on .phc-b{animation-delay:.54s}
.phc-b{grid-area:b;margin-top:2px;flex-wrap:wrap;justify-content:center}.phc-b .ptsoft em{font-style:normal;padding:0 7px;border-radius:8px;background:#3a2a6a;margin-left:2px}
@media (prefers-reduced-motion:reduce){.ptrv,.ptrv *{animation:none!important;transition:none!important}}
`;document.head.appendChild(st)}
/* ---------- STARTER CHOICE (rebuilt): drawn on the very first frame, animated by its own loop, and impossible to get stuck in ---------- */
function ptStarter(){S.mode='title';S.view='menu';petNorm();if(P.petSt!==1)return petHall('Pets');
 {const hx=$('pthx');if(hx){if(hx._stop)hx._stop();hx.remove()}}
 const free=PSTART.filter(id=>!petOwned(id));if(!free.length){P.petSt=2;save();return petHall('Pets')}
 let sel=free.includes(PTX.ssel)?PTX.ssel:free[0],busy=false,raf=0,greetT=performance.now()/1000;
 show(`<div class="pth ptstart" id="pth"><header class="ptsh"><h2>Your First Companion</h2><p>${free.length<PSTART.length?'Pick a free companion you don\'t have yet.':'Choose one now. You\'ll discover the others through eggs.'}</p></header>
  <div class="ptsc" role="radiogroup" aria-label="Starter companions">${PSTART.map(id=>{const D=PDEF[id],own=!free.includes(id);return `<button class="ptsk${id===sel?' on':''}${own?' own':''}" data-s="${id}" role="radio" aria-checked="${id===sel}" ${own?'aria-disabled="true"':''}><h3>${D.n}</h3>${ptBadge(D.r)}<canvas width="300" height="230" data-sv="${id}"></canvas><span class="ptski"><canvas width="64" height="64" data-si="${D.ab.k}"></canvas><b>${D.ab.n}</b></span><p>${D.ab.d}</p><i class="ptskc">${PTICO.chk}</i>${own?'<em class="ptsko">Already yours</em>':''}</button>`}).join('')}</div>
  <button class="ptgo ptchoose" id="ptch">Choose ${PDEF[sel].n} ${PTICO.play}</button><p class="ptsm">One starter choice. Your adventure also earned its normal trail stamp.</p>
  <div class="ptmod" id="ptmod"></div><div class="row"><button class="sm" id="b">Back</button></div></div>`,'m');
 const stop=()=>{cancelAnimationFrame(raf);raf=0};
 /* Back always leaves: to where the player came from, or the home screen */
 S.back=()=>{stop();const bk=PTX.back;PTX.back=null;try{(bk||title)()}catch(e){title()}};$('b').onclick=S.back;
 ov.querySelectorAll('canvas[data-si]').forEach(c=>{try{petIconCv(c,c.dataset.si)}catch(e){}});
 const CV=[...ov.querySelectorAll('canvas[data-sv]')].map(c=>({c,id:c.dataset.sv,g:c.getContext('2d')}));
 const paint=now=>{const rm=ptRM();for(const {c,id,g} of CV){const on=sel===id,gk=(now-greetT)%5;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,300,230);g.save();g.translate(150,200);g.scale(1.6,1.6);
   const gr=on&&!rm&&gk<1.4;try{petDraw(g,id,{t:now+id.length,pose:gr?'greet':'idle',u:gr?gk/1.4:0})}catch(e){}g.restore()}};
 paint(performance.now()/1000);
 const loop=()=>{if(!CV[0]||!CV[0].c.isConnected){raf=0;return}paint(performance.now()/1000);raf=requestAnimationFrame(loop)};raf=requestAnimationFrame(loop);
 const pick=id=>{if(busy||!free.includes(id)){if(PSTART.includes(id)&&!free.includes(id)){ccToast(`${PDEF[id].n} is already yours. Pick another.`);ptBeep(300,.06,.25)}return}sel=id;PTX.ssel=id;greetT=performance.now()/1000;ov.querySelectorAll('[data-s]').forEach(x=>{const on=x.dataset.s===id;x.classList.toggle('on',on);x.setAttribute('aria-checked',on)});$('ptch').innerHTML=`Choose ${PDEF[sel].n} ${PTICO.play}`;ptBeep(620,.05,.3)};
 ov.querySelectorAll('[data-s]').forEach(b=>{b.onclick=()=>pick(b.dataset.s);b.ondblclick=()=>{if(free.includes(b.dataset.s)){pick(b.dataset.s);choose()}}});
 const choose=()=>{if(busy)return;busy=true;const ch=$('ptch');if(ch)ch.disabled=true;let r=null;try{r=petStarterPick(sel)}catch(e){r=null}
  if(!r){/* never loop back onto this screen: settle the choice and open the hall */stop();if(Object.keys(P.pets).length){P.petSt=2;save()}ccToast('Your companions are waiting in the hall.');PTX.tab='Pets';return petHall('Pets')}
  stop();PTX.sel=r.id;PTX.tab='Pets';try{ptHatchScene(r.id,'r',{starter:1})}catch(e){P.petPend=null;save();petHall('Pets')}};
 $('ptch').onclick=choose;
 const sc=ov.querySelector('.ptsc');if(sc)sc.onkeydown=e=>{if(e.key!=='ArrowRight'&&e.key!=='ArrowLeft')return;e.preventDefault();const i=free.indexOf(sel),n=free[(i+(e.key==='ArrowRight'?1:-1)+free.length)%free.length];pick(n);const b=ov.querySelector(`[data-s="${n}"]`);if(b)b.focus()};
 setTimeout(()=>{const b=ov.querySelector('.ptsk.on');try{b&&b.focus({preventScroll:true})}catch(e){}},60)}
{const st=document.createElement('style');st.textContent=`.ptsk{animation:ptsin .32s cubic-bezier(.2,1,.4,1) both}.ptsk:nth-child(2){animation-delay:.04s}.ptsk:nth-child(3){animation-delay:.08s}@keyframes ptsin{from{opacity:.25;transform:translateY(10px) scale(.98)}}
.ptsk:focus-visible{outline:3px solid var(--gold);outline-offset:3px}.ptchoose:disabled{filter:grayscale(.4);cursor:default}
.ptsk.own{cursor:not-allowed;filter:grayscale(.55) brightness(.75)}.ptsk.own:hover{transform:none}.ptsko{position:absolute;top:12px;right:12px;padding:3px 10px;border-radius:10px;font:800 12px var(--ui);font-style:normal;color:#e8e0ff;background:#3a3070}
@media (prefers-reduced-motion:reduce){.ptsk{animation:none}}`;document.head.appendChild(st)}
