/* ===== LANTERN CARAVAN 8.6: styles for the camp hub (93j) ===== (transform and opacity animation only) */
{const st=document.createElement('style');st.textContent=`
.wrcamp{position:absolute;left:0;top:0;width:1600px;height:900px}
.wrcamp>canvas{display:block;position:absolute;left:0;top:0;width:1600px;height:900px}
.wrvig{position:absolute;inset:0;pointer-events:none;background:linear-gradient(180deg,rgba(7,4,26,.5) 0%,rgba(7,4,26,0) 20%,rgba(7,4,26,0) 52%,rgba(7,4,26,.82) 100%)}
.wrhead{position:absolute;left:62px;top:30px;width:640px;text-align:left}
.wrbrand{display:flex;align-items:center;gap:12px;margin:0;font:800 14px var(--ui);letter-spacing:.34em;color:#e8e0ff;animation:fsIn .5s var(--sp) both}.wrcomp{display:inline-flex}.wrcomp svg{display:block}
.wrtitle{display:inline-block;margin:20px 0 8px;padding:0 8px 6px 0;font:400 106px/1.04 'Pirata One',Georgia,serif;background:linear-gradient(180deg,#fff6c0 8%,#ffd45a 46%,#f0861e 92%);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;filter:drop-shadow(0 5px 0 #3a1a04) drop-shadow(0 0 26px #ff9a2a55);animation:fsIn .6s .05s var(--sp) both;white-space:nowrap}
.wrflour{display:flex;align-items:center;gap:12px;width:572px;margin:6px 0 0;font:800 13px var(--ui);letter-spacing:.34em;color:#ffe9a0;animation:fsIn .6s .1s var(--sp) both}.wrflour u{flex:1;height:2px;background:linear-gradient(90deg,#ffd45a00,#ffd45a99);text-decoration:none}.wrflour u:last-of-type{background:linear-gradient(270deg,#ffd45a00,#ffd45a99)}.wrflour svg{flex:none}
.wrtag{margin:10px 0 0;font:italic 400 19px Georgia,serif;color:#f4ecd8;text-shadow:0 2px 6px #000;animation:fsIn .6s .15s var(--sp) both}
.wrready{position:absolute;left:62px;top:256px;width:472px;height:246px;box-sizing:border-box;padding:18px 24px 20px;text-align:left;border-radius:22px;background:linear-gradient(180deg,#1e1654f4,#0e0a30f7);border:2px solid #4a3e90;box-shadow:inset 0 1px 0 #ffffff26,0 16px 36px #000b;animation:fsWb .55s .2s var(--sp) both}
.wrready.pop{animation:wrPop .35s var(--sp) both}@keyframes wrPop{from{transform:scale(.965)}}
.wrorn{position:absolute;left:50%;width:12px;height:12px;margin-left:-6px;background:#ffd45a;border:2px solid #12081f;border-radius:2px;transform:rotate(45deg)}.wrorn.t{top:-8px}.wrorn.b{bottom:-8px}
.wrrdy{display:flex;align-items:center;gap:12px}.wrrdy .wrcomp svg{width:34px;height:34px}.wrrl{font:italic 400 18px Georgia,serif;color:#c8beff}
.wrrn{margin:8px 0 6px;font:400 50px/1.02 'Pirata One',Georgia,serif;color:#fff8e8;text-shadow:0 3px 0 #12081f;letter-spacing:.01em}
.wrri{margin:0;font:500 16px var(--ui);color:#c4badf}
.wrstart{all:unset;box-sizing:border-box;position:absolute;left:24px;right:24px;bottom:20px;height:62px;display:flex;align-items:center;gap:14px;padding:0 24px;border-radius:16px;background:linear-gradient(180deg,#ffe27a,#f2b631);color:#3a2006;font:800 28px var(--ui);box-shadow:0 5px 0 #9a6a10,0 14px 28px #000a;cursor:pointer;transition:transform .15s var(--sp)}
.wrstart:hover{transform:translateY(-3px)}.wrstart:active{transform:scale(.97)}.wrstart:focus-visible{outline:3px solid #fff;outline-offset:3px}.wrsi svg{display:block;width:50px;height:31px}.wrsi svg *{fill:#3a2006}.wrstart i{margin-left:auto;font-style:normal;font-size:40px;line-height:1}
.wrcards{position:absolute;left:60px;top:521px;width:1480px;height:265px;display:grid;grid-template-columns:repeat(3,478px);gap:23px}
.wrcd{all:unset;box-sizing:border-box;position:relative;display:block;width:478px;height:265px;overflow:hidden;border-radius:22px;border:2.5px solid #4a3e90;background:#120c34;cursor:pointer;text-align:left;box-shadow:0 14px 30px #000a;transition:transform .2s var(--sp),border-color .2s;animation:wrCardIn .55s var(--sp) both}
.wrcd:nth-child(1){animation-delay:.25s}.wrcd:nth-child(2){animation-delay:.32s}.wrcd:nth-child(3){animation-delay:.39s}
.wrcd>canvas{position:absolute;inset:0;width:100%;height:100%;display:block}
.wrcd::after{content:'';position:absolute;inset:0;border-radius:20px;border:3px solid #ffc94a;box-shadow:0 0 26px #ffb02a88;opacity:0;pointer-events:none;transition:opacity .2s}
.wrcd.on::after{opacity:1}.wrcd.on{border-color:#ffc94a}.wrcd:hover{transform:translateY(-5px)}.wrcd:active{transform:scale(.98)}.wrcd:focus-visible{outline:3px solid #fff;outline-offset:3px}
.wrcd.lock{border-color:#5a4ca0}.wrcd.lock:hover{transform:translateY(-2px)}.wrcd.nope{animation:wrNope .4s ease}
@keyframes wrCardIn{from{opacity:0;transform:translateY(26px)}}@keyframes wrNope{20%{transform:translateX(-8px)}45%{transform:translateX(7px)}70%{transform:translateX(-4px)}}
.wrdim{position:absolute;inset:0;background:rgba(10,6,34,.4)}
.wrbadge{position:absolute;left:16px;top:14px;display:flex;filter:drop-shadow(0 3px 6px #000a)}.wrbadge svg{display:block}.wrcd.on .wrbadge{animation:wrBadge 3.2s ease-in-out infinite}@keyframes wrBadge{50%{transform:rotate(14deg) scale(1.06)}}
.wrcdt{position:absolute;left:22px;right:22px;bottom:16px;display:flex;flex-direction:column}
.wrcdt b{margin-bottom:5px;font:400 42px/1.06 'Pirata One',Georgia,serif;color:#fff8e8;text-shadow:0 3px 0 #12081f,0 0 14px #000}
.wrcdt small{font:italic 400 18px Georgia,serif;color:#e0d8f8;text-shadow:0 2px 4px #000}
.wrcdm{display:flex;align-items:center;gap:14px;margin-top:9px}.wrsls{display:flex;gap:9px;flex:none}
.wrsl{display:block;width:32px;height:32px;box-sizing:border-box;border-radius:50%;background:rgba(10,6,32,.78);border:2px solid #5a4ca0;position:relative}
.wrsl.on{background:radial-gradient(circle at 35% 28%,#ffffffb0 0,var(--c) 38%,color-mix(in srgb,var(--c) 62%,#000) 100%);border-color:#12081f;box-shadow:0 0 12px color-mix(in srgb,var(--c) 60%,transparent)}.wrsl svg{position:absolute;inset:5px;width:auto;height:auto}
.wrcdm em{flex:1;text-align:right;font:800 15px/1.3 var(--ui);font-style:normal;color:#ffd45a;text-shadow:0 2px 4px #000}.wrcdm em.wrlk{font-weight:600;color:#e8e0ff}
.wrbar{position:absolute;left:0;right:0;top:808px;height:58px;display:flex;align-items:center;justify-content:center;gap:16px}
.wrbo{display:flex;align-items:center;gap:8px;width:98px}.wrbo u{flex:1;height:2px;text-decoration:none;background:linear-gradient(90deg,#ffd45a00,#ffd45a99)}.wrbo.r u{background:linear-gradient(270deg,#ffd45a00,#ffd45a99)}.wrbo.r{flex-direction:row}.wrbo.r svg{order:-1}.wrbo svg{flex:none;width:18px;height:18px}
.wrbb{all:unset;box-sizing:border-box;position:relative;display:flex;align-items:center;gap:14px;width:424px;height:58px;padding:0 20px 0 10px;border-radius:15px;background:linear-gradient(180deg,#1c1450ee,#0e0a30f4);border:2px solid #4a3e90;box-shadow:inset 0 1px 0 #ffffff1f,0 8px 20px #000a;cursor:pointer;text-align:left;transition:transform .18s var(--sp),border-color .18s;animation:wrCardIn .55s .5s var(--sp) both}
.wrbb:nth-of-type(2){animation-delay:.56s}.wrbb:nth-of-type(3){animation-delay:.62s}
.wrbb:hover{transform:translateY(-3px);border-color:#8a7ad0}.wrbb:active{transform:scale(.97)}.wrbb:focus-visible{outline:3px solid #fff;outline-offset:3px}
.wrbi{display:flex;flex:none;width:64px;height:50px}.wrbi canvas{display:block;width:64px;height:51px;margin-top:-1px}
.wrbt{display:flex;flex-direction:column;gap:1px;min-width:0}.wrbt b{font:800 18px var(--ui);color:#fff8e8}.wrbt small{font:500 13px var(--ui);color:#c4badf}
.wrch{margin-left:auto;font-style:normal;font:800 30px var(--ui);color:#fff8e8;line-height:1}
/* narrow (touch) layout: everything stacks over the scene */
.wrcamp.wr-narrow{position:relative;left:auto;top:auto;width:100%;height:auto;min-height:100%;overflow:visible;padding:74px 14px 26px;box-sizing:border-box;display:flex;flex-direction:column;gap:14px;align-items:stretch}
.wrcamp.wr-narrow>canvas{position:fixed;inset:0;width:100%;height:100%;object-fit:cover}.wrcamp.wr-narrow .wrvig{position:fixed;background:linear-gradient(180deg,rgba(7,4,26,.78),rgba(7,4,26,.62) 60%,rgba(7,4,26,.88))}
.wrcamp.wr-narrow .fstr{position:fixed;right:12px;top:12px;z-index:3}
.wrcamp.wr-narrow .wrhead,.wrcamp.wr-narrow .wrready,.wrcamp.wr-narrow .wrcards,.wrcamp.wr-narrow .wrbar{position:relative;left:0;top:0;width:100%;box-sizing:border-box}
.wrcamp.wr-narrow .wrtitle{font-size:64px}.wrcamp.wr-narrow .wrflour{width:100%}
.wrcamp.wr-narrow .wrready{height:auto;padding:16px 18px 18px}.wrcamp.wr-narrow .wrstart{position:relative;left:0;right:0;bottom:0;width:100%;margin-top:14px}
.wrcamp.wr-narrow .wrcards{display:flex;flex-direction:column;height:auto;gap:12px}.wrcamp.wr-narrow .wrcd{width:100%;height:150px}.wrcamp.wr-narrow .wrcd>canvas{object-fit:cover}
.wrcamp.wr-narrow .wrbadge{left:auto;right:12px;top:10px;transform-origin:center}
.wrcamp.wr-narrow .wrcdt b{font-size:30px}.wrcamp.wr-narrow .wrcdt small{font-size:15px}.wrcamp.wr-narrow .wrcdm{margin-top:6px}.wrcamp.wr-narrow .wrsl{width:24px;height:24px}.wrcamp.wr-narrow .wrcdm em{font-size:12.5px}
.wrcamp.wr-narrow .wrbar{height:auto;flex-direction:column;align-items:stretch;gap:10px}.wrcamp.wr-narrow .wrbo{display:none}.wrcamp.wr-narrow .wrbb{width:100%}
.wrcamp.wr-narrow .fsmod{position:fixed!important;inset:0;width:auto!important;height:auto!important;overflow:auto;padding:10px;box-sizing:border-box}
@media (prefers-reduced-motion:reduce){.wrcd,.wrbb,.wrready,.wrtitle,.wrbrand,.wrflour,.wrtag,.wrcd.on .wrbadge,.wrcd.nope{animation:none!important}}`;document.head.appendChild(st)}
