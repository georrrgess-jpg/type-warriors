/* ===== WILDCARD HAND: steady hover and a premium fan =====
   The hover glitch: hand cards used :hover on their own transformed boxes, so lifting and scaling the hovered card moved
   it out from under the cursor (or onto its neighbour), the neighbour took :hover, and the two swapped many times a
   second. Now the cards ignore the pointer (pointer-events:none) and one transparent hit layer (.wchit) on #wchand
   works out the hovered card itself from the cards' RESTING slots, never from where they are drawn, with a little
   hysteresis so a shaky hand on the boundary between two cards can't flip them. The result goes on the card as .hv.
   NOTE for other modules: .wchc:hover never matches any more and elementFromPoint never returns a hand card; style the
   hovered card with .hv and hit-test with wcHandLay (or call el.click(), which still runs every onclick wrapper).
   Clicks on the layer click the card's own button, so wcTapCard and every onclick wrapper still run; keyboard focus
   (Tab, arrow keys) also sets .hv; touch gets press feedback and a tap plays, with no sticky hover after the finger lifts.
   The polish: one shared layout (wcHandLay) puts the cards on a shallow arc that keeps every corner index inside the
   stage and also feeds wcHandSlots, so the deal lands exactly where the cards rest; the hovered card springs up and
   straightens while its neighbours part; the status pill slides up a little to make room for a raised card, and the
   Play it / Keep it buttons float above it while a drawn card is pending; playable cards wear a static coloured rim
   glow (only the single pending card breathes, so idle turns cost nothing); unplayable cards recede under a flat
   dark veil; Hint makes its card bob (on the `translate` property, so it never fights the slot transform); fresh cards
   rise in with a sheen; and every re-render slides the cards from where they were to where they now go (FLIP), so
   sorting, playing and drawing all reflow smoothly. Big hands tighten the step, flatten the arc and lower the
   playable lift so the fan stays one clean curve. Reduced motion (wcRM) keeps hover feedback but drops the motion.
   Performance (measured at 4x CPU throttle): a hover change moves at most the hovered card and its two direct
   neighbours, glow and veil switch instantly instead of fading, nothing breathes while idle, and no card keeps a
   permanent layer (will-change made idle frames slower); only transform and opacity ever animate. */
const WCHL_SETTLE=110,WCHL={hv:null,src:null,pt:null,L:[],bs:[],tap:null,down:null,ft:0,gt:0};
/* lift (px), scale and tilt factor per card state; the CSS below is generated from this table so JS and CSS agree */
const WCHV={ok:[-26,1,1],okb:[-12,1,1],okhv:[-50,1.06,.2],hv:[-20,1,.55],pend:[-38,1.06,.3],pendhv:[-46,1.07,0],rest:[0,1,1]};
/* resting slots: x,y0 = card top-left offset from the hand line (top 718), r = tilt in degrees. The arc is scaled down
   until the lowest corner of every tilted card stays inside the 900 px stage, so the corner indices are never cut. */
function wcHandLay(n){const w=112,maxW=n<=7?800:n<=12?900:960,step=n>1?Math.min(84,(maxW-w)/(n-1)):0,tot=w+(n-1)*step,m=(n-1)/2,da=n>1?Math.min(2.6,18/n):0,R=da?step/(da*Math.PI/180):0,rad=Math.PI/180;
 const S=Array.from({length:n},(_,i)=>{const r=(i-m)*da;return{x:800-tot/2+i*step,a:R*(1-Math.cos(r*rad)),r}});
 let k=1;S.forEach(s=>{const lim=100-(82*Math.cos(s.r*rad)+56*Math.abs(Math.sin(s.r*rad)));if(s.a>.5)k=Math.min(k,Math.max(0,lim)/s.a)});
 return S.map(s=>({x:s.x,y0:s.a*k,r:s.r}))}
wcHandSlots=function(G){const cards=wcDisp(),L=wcHandLay(cards.length);return cards.map((c,i)=>({c,x:L[i].x,y:718+L[i].y0,r:L[i].r}))};
const wchBig=b=>!!(b.parentNode&&b.parentNode.classList&&b.parentNode.classList.contains('wchbig'));
function wchS(b,nohv){const c=b.classList,h=!nohv&&c.contains('hv')&&!c.contains('no');/* unplayable cards never lift */return c.contains('pend')?(h?WCHV.pendhv:WCHV.pend):h?(c.contains('ok')?WCHV.okhv:WCHV.hv):c.contains('ok')?(wchBig(b)?WCHV.okb:WCHV.ok):WCHV.rest}
/* how far a card stands up at rest and when hovered */
const wchBase=b=>-wchS(b,1)[0],wchUp=b=>{const c=b.classList;if(c.contains('no'))return 0;return -(c.contains('pend')?WCHV.pendhv:c.contains('ok')?WCHV.okhv:WCHV.hv)[0]};
/* which card owns stage point (sx,sy)? Card i owns the strip from its left edge to the next card's left edge (the part
   you can see at rest); the current card keeps a margin on each side so jitter on a boundary can't flip it. Above card
   i's top, a raised left neighbour still shows, so that corner belongs to the neighbour. */
function wchPick(sx,sy,cur){const L=WCHL.L,bs=WCHL.bs,n=L.length;if(!n)return -1;const w=112,st=n>1?L[1].x-L[0].x:w,H=Math.min(14,st*.3);
 const right=i=>i<n-1?L[i+1].x:L[i].x+w,top=i=>718+L[i].y0-wchBase(bs[i]),bot=i=>718+L[i].y0+194;
 const Hc=cur>=0&&cur<n&&wchUp(bs[cur])>0?H:0;
 if(cur>=0&&cur<n&&sx>=L[cur].x-Hc&&sx<right(cur)+Hc&&sy>=718+L[cur].y0-wchUp(bs[cur])-14&&sy<=bot(cur))return cur;
 if(sx<L[0].x-6||sx>=L[n-1].x+w+6)return -1;let i=0;while(i<n-1&&sx>=L[i+1].x)i++;
 if(sy>=top(i)-4&&sy<=bot(i))return i;
 return i>0&&sx<L[i-1].x+w&&sy>=top(i-1)-4&&sy<top(i)-4?i-1:-1}
/* the stage rect is cached (refreshed on render and resize) so pointer moves never force a layout */
function wchStage(cx,cy){let R=WCHL.R;if(!R){const st=$('wct');if(!st)return null;R=WCHL.R=st.getBoundingClientRect()}const k=R.width/1600;return k?{x:(cx-R.left)/k,y:(cy-R.top)/k}:null}
addEventListener('resize',()=>{WCHL.R=null});
/* the transform a card is heading for, built from its inline vars and state classes (mirrors the CSS below) */
function wchT(b){const v=k=>parseFloat(b.style.getPropertyValue(k))||0,S=wchS(b);
 return `translate(${(v('--x')+v('--hcp')).toFixed(1)}px,${(v('--y')+S[0]).toFixed(1)}px) rotate(${(v('--r')*S[2]).toFixed(2)}deg) scale(${S[1]})`}
/* sheen + hover tick, at most one per 170 ms so a quick sweep across the hand doesn't chatter */
function wchGlint(b,src){clearTimeout(WCHL.gtm);const go=()=>{if(!b.isConnected||!b.classList.contains('hv'))return;WCHL.gt=performance.now();
  /* two identical keyframes, alternated, restart the sheen without a forced layout */const a=WCHL.sh=!WCHL.sh;b.classList.remove('wchs','wchs2');b.classList.add(a?'wchs':'wchs2');if(b.classList.contains('ok')&&src==='ptr')wcFx('hover')};
 const dt=performance.now()-WCHL.gt;if(dt>=170)go();else WCHL.gtm=setTimeout(go,170-dt)}
/* put .hv on card i (-1 = none) and part its neighbours; quiet=true when only restoring after a re-render */
function wchSet(i,src,quiet){const bs=WCHL.bs,b=bs[i]||null,id=b?b.dataset.id:null;
 if(!quiet&&id===WCHL.hv&&(!b||b.classList.contains('hv')))return;WCHL.hv=id;WCHL.src=b?src:null;
 const ok=b&&(b.classList.contains('ok')||b.classList.contains('pend')),st=bs.length>1?WCHL.L[1].x-WCHL.L[0].x:84,P=Math.max(18,44-st*.3);
 /* the status pill rises when a raised card would reach it, and stays up until the pointer leaves the hand (no bobbing
    during a sweep); measured before any class changes so the read never forces an extra layout */
 const T=$('wct');if(T){const was=T.classList.contains('wchup');let up=was;if(!b)up=false;else if(!was&&ok){const s=$('wcstat'),w=s?s.offsetWidth:0,x=WCHL.L[i].x;up=w>0&&x<800+w/2+10&&x+112>800-w/2-10}if(up!==was)T.classList.toggle('wchup',up)}
 /* a pointer sweep only lifts the card under the cursor; the neighbours part (and the sheen and tick play) once the
    pointer rests on one card for SETTLE ms, so a fast sweep never sets three cards moving per step */
 const lifts=!!b&&!b.classList.contains('no'),part=k=>(ok&&Math.abs(k-i)===1?Math.sign(k-i)*P:0).toFixed(1)+'px',settle=!quiet&&src==='ptr';clearTimeout(WCHL.stm);
 bs.forEach((e,k)=>{const on=k===i;if(e.classList.contains('hv')!==on){e.classList.toggle('hv',on);clearTimeout(e._zt);
  /* a card being let go stays on top while it sinks (a timed class: a delayed z-index transition would restyle every frame) */
  if(!on){e.classList.remove('wchs','wchs2');if(lifts&&!e.classList.contains('no')){e.classList.add('wchz');e._zt=setTimeout(()=>e.classList.remove('wchz'),200)}else e.classList.remove('wchz')}else e.classList.remove('wchz')}const px=settle?'0.0px':part(k);if(e._px!==px){e._px=px;e.style.setProperty('--hcp',px)}});
 if(settle&&b)WCHL.stm=setTimeout(()=>{if(WCHL.hv!==id||!b.isConnected)return;bs.forEach((e,k)=>{const px=part(k);if(e._px!==px){e._px=px;e.style.setProperty('--hcp',px)}});wchGlint(b,src)},WCHL_SETTLE);
 const hit=document.querySelector('#wchand .wchit');if(hit)hit.classList.toggle('ok',!!(b&&b.classList.contains('ok')));
 if(b&&!quiet&&!settle)wchGlint(b,src)}
function wchMove(cx,cy,src){const p=wchStage(cx,cy);if(!p)return;const cur=WCHL.bs.findIndex(b=>b.dataset.id===WCHL.hv);wchSet(wchPick(p.x,p.y,cur),src)}
/* pointer, touch and keyboard wiring, attached once per #wchand element */
function wchWire(h){if(h._wch)return;h._wch=1;const isHit=e=>e.target.classList&&e.target.classList.contains('wchit');
 h.addEventListener('pointermove',e=>{if(!isHit(e))return;
  if(e.pointerType==='touch'){if(!WCHL.down)return;const d=WCHL.down;if(Math.hypot(e.clientX-d.x,e.clientY-d.y)>14)d.moved=true}
  WCHL.pt={x:e.clientX,y:e.clientY,t:e.pointerType};wchMove(e.clientX,e.clientY,'ptr')});
 h.addEventListener('pointerdown',e=>{if(!isHit(e))return;const ae=document.activeElement;if(ae&&ae.classList&&ae.classList.contains('wchc'))ae.blur();
  /* a touch remembers what it pressed; any other pointer forgets a stale touch (hybrid devices) */
  WCHL.tap=null;if(e.pointerType==='touch')WCHL.down={x:e.clientX,y:e.clientY,moved:false};WCHL.pt={x:e.clientX,y:e.clientY,t:e.pointerType};wchMove(e.clientX,e.clientY,'ptr')});
 const up=e=>{if(e.pointerType!=='touch'||!WCHL.down)return;WCHL.tap={id:WCHL.down.moved?'':WCHL.hv,t:performance.now()};WCHL.down=null;WCHL.pt=null;wchSet(-1,'ptr')};
 h.addEventListener('pointerup',up);h.addEventListener('pointercancel',up);
 h.addEventListener('pointerleave',e=>{if(e.pointerType==='touch')return;WCHL.pt=null;if(WCHL.src==='ptr')wchSet(-1,'ptr')},true);
 h.addEventListener('click',e=>{if(!isHit(e))return;let id;const tp=WCHL.tap;WCHL.tap=null;
  if(tp&&performance.now()-tp.t<700)id=tp.id;else{const p=wchStage(e.clientX,e.clientY),cur=WCHL.bs.findIndex(b=>b.dataset.id===WCHL.hv);const i=p?wchPick(p.x,p.y,cur):-1;id=i>=0?WCHL.bs[i].dataset.id:null}
  const b=id&&h.querySelector(`.wchc[data-id="${id}"]`);if(b)b.click()});
 h.addEventListener('focusin',e=>{const b=e.target;if(!b.classList||!b.classList.contains('wchc'))return;let fv=true;try{fv=b.matches(':focus-visible')}catch(x){}if(fv)wchSet(WCHL.bs.indexOf(b),'key')});
 h.addEventListener('focusout',()=>{if(WCHL.src==='key')wchSet(-1,'key')})}
{const r0=wcRenderHand;wcRenderHand=function(resort){const h=$('wchand'),rm=wcRM(),old=new Map();
 if(h&&!rm)h.querySelectorAll('.wchc').forEach(b=>{if(b.style.visibility!=='hidden')old.set(b.dataset.id,wchT(b))});
 const out=r0.apply(this,arguments);if(!h||!h.isConnected)return out;
 const bs=[...h.querySelectorAll('.wchc')],n=bs.length,L=wcHandLay(n);WCHL.L=L;WCHL.R=null;WCHL.bs=bs;wchWire(h);h.classList.toggle('wchrm',rm);h.classList.toggle('wchbig',n>12);
 h.style.setProperty('--bt',(-(performance.now()%1600)).toFixed(0)+'ms');/* keeps the pending glow breathing in phase across re-renders */
 bs.forEach((b,i)=>{const s=L[i];b.style.setProperty('--x',s.x.toFixed(1)+'px');b.style.setProperty('--y',s.y0.toFixed(1)+'px');b.style.setProperty('--r',s.r.toFixed(2)+'deg');const sh=document.createElement('i');sh.className='wcsh';b.appendChild(sh)});
 const T=$('wct');if(T){T.classList.toggle('wchpd',bs.some(b=>b.classList.contains('pend')));T.classList.toggle('wchrm',rm)}
 if(n){const hit=document.createElement('div');hit.className='wchit';hit.setAttribute('aria-hidden','true');
  const x0=L[0].x-16,x1=L[n-1].x+112+16,y0=718+Math.min(...L.map(s=>s.y0))-80;hit.style.cssText=`left:${x0}px;top:${y0}px;width:${x1-x0}px;height:${Math.max(120,920-y0)}px`;h.appendChild(hit)}
 /* restore the hover across the re-render, from the pointer if it is still over the hand, else from keyboard focus */
 const cur=bs.findIndex(b=>b.dataset.id===WCHL.hv);let i=-1;
 if(WCHL.pt&&WCHL.src!=='key'){const p=wchStage(WCHL.pt.x,WCHL.pt.y);if(p)i=wchPick(p.x,p.y,cur)}else if(WCHL.src==='key'){const ae=document.activeElement;i=bs.indexOf(ae);if(i<0)i=cur}
 wchSet(i,WCHL.src||'ptr',true);
 /* FLIP: a card whose slot changed starts where it was heading before, then glides into its new slot; most
    re-renders (another player's move) change nothing, so they cost no extra layout */
 if(old.size&&!rm){const mv=[];bs.forEach(b=>{const t=old.get(b.dataset.id);if(t&&t!==wchT(b)){b.style.transition='none';b.style.transform=t;mv.push(b)}});
  if(mv.length){void h.offsetWidth;h.classList.add('wchfl');mv.forEach(b=>{b.style.transition='';b.style.transform=''});clearTimeout(WCHL.ft);WCHL.ft=setTimeout(()=>h.classList.remove('wchfl'),650)}}
 return out}}
{const V=k=>`--hcl:${WCHV[k][0]}px;--hcs:${WCHV[k][1]};--hck:${WCHV[k][2]}`,st=document.createElement('style');st.textContent=`
/* the hover vars are registered as non-inherited: changing them on a card must not restyle its whole SVG face */
@property --hcp{syntax:'<length>';inherits:false;initial-value:0px}@property --hcl{syntax:'<length>';inherits:false;initial-value:0px}
@property --hcs{syntax:'<number>';inherits:false;initial-value:1}@property --hck{syntax:'<number>';inherits:false;initial-value:1}
.wcx #wchand .wchit{position:absolute;z-index:70;touch-action:none;-webkit-tap-highlight-color:transparent;cursor:default;background:transparent}
.wcx #wchand .wchit.ok{cursor:pointer}
.wcx #wchand .wchc{pointer-events:none;cursor:default;transform:translate(calc(var(--x) + var(--hcp)),calc(var(--y) + var(--hcl))) rotate(calc(var(--r) * var(--hck))) scale(var(--hcs));
 transition:transform .26s cubic-bezier(.3,.7,.35,1);box-shadow:0 12px 20px -6px #000c,0 3px 6px #0007;filter:none}
.wcx #wchand .wchc.hv{transition:transform .19s cubic-bezier(.2,.9,.3,1)}
.wcx #wchand.wchfl .wchc{transition:transform .52s cubic-bezier(.22,1.22,.36,1)}
.wcx #wchand .wchc.wchz{z-index:49}
.wcx #wchand .wchc.ok{${V('ok')};box-shadow:0 0 0 2.5px color-mix(in srgb,var(--ec) 45%,#fff),0 14px 22px -6px #000d,0 3px 6px #0007}
.wcx #wchand.wchbig .wchc.ok:not(.pend):not(.hv){${V('okb')}}
.wcx #wchand .wchc.hv{${V('hv')};z-index:50}
.wcx #wchand .wchc.ok.hv{${V('okhv')}}
.wcx #wchand .wchc.pend{${V('pend')};z-index:45;box-shadow:0 0 0 3px #ffd45a,0 0 0 5.5px #12081f,0 14px 22px -6px #000d}
.wcx #wchand .wchc.pend.hv{${V('pendhv')};z-index:50}
.wcx #wchand .wchc:focus-visible{outline:3px solid #fff;outline-offset:5px}
/* glow: a tight coloured halo just outside the card, static (it never stains the neighbours' faces) */
.wcx #wchand .wchc::before{content:'';position:absolute;inset:-3px;border-radius:15px;z-index:-1;pointer-events:none;opacity:0;
 background:color-mix(in srgb,var(--ec) 60%,transparent);box-shadow:0 0 12px 1px color-mix(in srgb,var(--ec) 65%,transparent)}
.wcx #wchand .wchc.ok::before{opacity:.7}
.wcx #wchand .wchc.ok.hv::before{opacity:1}
/* only the single pending card breathes (opacity only, on its own layer) */
.wcx #wchand .wchc.pend::before{--ec:#ffc23a;will-change:opacity;animation:wchyBr 1.6s ease-in-out infinite;animation-delay:var(--bt,0ms)}
@keyframes wchyBr{0%,100%{opacity:.5}50%{opacity:1}}
.wcx #wchand .wchc.fresh:not(.ok):not(.pend)::before{--ec:#ffe6a0;animation:wchyFl 1.2s ease-out both;animation-delay:var(--d)}
@keyframes wchyFl{0%{opacity:0}22%{opacity:.85}100%{opacity:0}}
/* Hint: gold halo and three bobs; 'translate' composes with the slot transform instead of replacing it */
.wcx #wchand .wchc.wchint{animation:wchyHt .9s ease-in-out 3;z-index:48}
.wcx #wchand .wchc.wchint::before{--ec:#ffd45a;opacity:1}
@keyframes wchyHt{0%,100%{translate:0 0}45%{translate:0 -26px}}
/* unplayable: a flat dark veil (no desaturation, so a yellow card stays gold and doesn't turn to mud) */
.wcx #wchand .wchc::after{content:'';position:absolute;inset:0;border-radius:12px;pointer-events:none;background:#0d0826;opacity:0}
.wcx #wchand .wchc.no::after{opacity:.52}
.wcx #wchand .wchc.no.hv{--hcl:0px;--hcs:1;--hck:1;z-index:var(--z)}
.wcx #wchand .wcsh{position:absolute;inset:0;border-radius:12px;overflow:hidden;pointer-events:none}
.wcx #wchand .wcsh::before{content:'';position:absolute;top:-25%;bottom:-25%;left:0;width:42%;opacity:0;transform:translateX(-130%) skewX(-16deg);
 background:linear-gradient(90deg,#fff0,#fff5 45%,#fffc 50%,#fff5 55%,#fff0)}
.wcx #wchand .wchc.ok.wchs .wcsh::before,.wcx #wchand .wchc.pend.wchs .wcsh::before{animation:wchySh .75s cubic-bezier(.3,.6,.4,1) both}
.wcx #wchand .wchc.ok.wchs2 .wcsh::before,.wcx #wchand .wchc.pend.wchs2 .wcsh::before{animation:wchySh2 .75s cubic-bezier(.3,.6,.4,1) both}
.wcx #wchand .wchc.fresh .wcsh::before{animation:wchySh .8s cubic-bezier(.3,.6,.4,1) both;animation-delay:calc(var(--d) + .3s)}
@keyframes wchySh{0%{opacity:.9;transform:translateX(-130%) skewX(-16deg)}100%{opacity:.9;transform:translateX(330%) skewX(-16deg)}}
@keyframes wchySh2{0%{opacity:.9;transform:translateX(-130%) skewX(-16deg)}100%{opacity:.9;transform:translateX(330%) skewX(-16deg)}}
.wcx #wchand .wchc.fresh>svg{animation:wchyIn .6s var(--sp) both;animation-delay:var(--d)}
@keyframes wchyIn{0%{transform:translateY(54px) rotate(-6deg) scale(.8);opacity:0}35%{opacity:1}}
/* make room: the status pill slides up while a raised card is near it or a drawn card is pending, and the Play it /
   Keep it buttons float above the pill instead of sitting on the pending card */
.wcx #wct .wcstat{transition:translate .4s var(--sp)}
.wcx #wct.wchup .wcstat,.wcx #wct.wchpd .wcstat{translate:0 -14px}
.wcx #wct.wchpd .wcdrawn{top:546px}.wcx #wct.wchrm .wcstat{transition-duration:.06s}
.wcx #wchand.wchrm .wchc,.wcx #wchand.wchrm .wchc::before,.wcx #wchand.wchrm .wchc::after{transition-duration:.06s;transition-delay:0s}
.wcx #wchand.wchrm .wchc,.wcx #wchand.wchrm .wchc::before{animation:none!important}.wcx #wchand.wchrm .wchc.pend::before{opacity:.85}
.wcx #wchand.wchrm .wcsh{display:none}.wcx #wchand.wchrm .wchc.fresh>svg{animation:none}`;document.head.appendChild(st)}
