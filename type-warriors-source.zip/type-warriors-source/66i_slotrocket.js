/* ---------- casino polish: the slot machine and the rocket ----------
   Slot symbols, cabinet, paytable and win effects live here, and so does the rocket scene and its crash curve. */
const cmix=(a,b,t)=>{const p=h=>[1,3,5].map(i=>parseInt(h.slice(i,i+2),16)),x=p(a),y=p(b);return '#'+x.map((v,i)=>Math.round(v+(y[i]-v)*t).toString(16).padStart(2,'0')).join('')};
const g01=()=>{try{const a=new Uint32Array(2);crypto.getRandomValues(a);return(a[0]*2097152+(a[1]>>>11))/9007199254740992}catch(e){return Math.random()}};
const gL=(g,x0,y0,x1,y1,st)=>{const q=g.createLinearGradient(x0,y0,x1,y1);st.forEach((c,i)=>q.addColorStop(i/(st.length-1),c));return q};
const gR=(g,x,y,r0,r1,st,x2,y2)=>{const q=g.createRadialGradient(x,y,r0,x2===undefined?x:x2,y2===undefined?y:y2,r1);st.forEach((c,i)=>q.addColorStop(i/(st.length-1),c));return q};

/* ===== slot symbols ===== */
function drawSym(g,id,x,y,s){g.save();g.translate(x,y);g.scale(s/100,s/100);g.lineJoin='round';g.lineCap='round';
 const SH=()=>{g.shadowColor='rgba(0,0,0,.5)';g.shadowBlur=10;g.shadowOffsetY=5},NS=()=>{g.shadowColor='transparent';g.shadowBlur=0;g.shadowOffsetY=0};SH();
 if(id==='cherry'){g.strokeStyle='#4a7a1c';g.lineWidth=5.5;g.beginPath();g.moveTo(-18,10);g.quadraticCurveTo(-10,-26,12,-38);g.moveTo(20,14);g.quadraticCurveTo(18,-22,12,-38);g.stroke();
  g.fillStyle=gL(g,0,-48,30,-26,['#8ae04a','#2a8a2a']);g.strokeStyle='#1a4a14';g.lineWidth=2.4;g.beginPath();g.moveTo(12,-38);g.quadraticCurveTo(26,-56,48,-40);g.quadraticCurveTo(34,-26,12,-38);g.fill();g.stroke();
  for(const [cx,cy,r] of[[-22,20,22],[22,24,21]]){g.fillStyle=gR(g,cx-7,cy-8,2,r+4,['#ffb0b4','#f0283c','#8a0618']);g.beginPath();g.arc(cx,cy,r,0,TAU);g.fill();g.strokeStyle='#4a0010';g.lineWidth=2.5;g.stroke()}
  NS();g.fillStyle='rgba(255,255,255,.85)';g.beginPath();g.ellipse(-30,10,6,9,-.5,0,TAU);g.fill();g.beginPath();g.ellipse(14,15,5,8,-.5,0,TAU);g.fill()}
 else if(id==='lemon'){g.rotate(-.3);g.fillStyle=gL(g,0,-30,0,30,['#fffbb0','#ffe94a','#e0a800']);g.strokeStyle='#8a6008';g.lineWidth=3;g.beginPath();g.moveTo(-46,2);g.quadraticCurveTo(-42,-6,-34,-12);g.quadraticCurveTo(0,-36,34,-12);g.quadraticCurveTo(42,-6,46,2);g.quadraticCurveTo(42,10,34,14);g.quadraticCurveTo(0,36,-34,14);g.quadraticCurveTo(-42,10,-46,2);g.closePath();g.fill();g.stroke();
  NS();g.fillStyle='rgba(255,255,255,.55)';g.beginPath();g.ellipse(-10,-14,20,6,-.12,0,TAU);g.fill();g.fillStyle='rgba(176,120,0,.28)';for(const [dx,dy] of[[10,6],[24,-2],[-4,12],[-22,4],[2,-2]]){g.beginPath();g.arc(dx,dy,1.8,0,TAU);g.fill()}
  SH();g.fillStyle=gL(g,30,-44,54,-14,['#8ae04a','#2a8a2a']);g.strokeStyle='#1a4a14';g.lineWidth=2.2;g.beginPath();g.moveTo(38,-8);g.quadraticCurveTo(44,-34,66,-36);g.quadraticCurveTo(62,-12,38,-8);g.fill();g.stroke();NS()}
 else if(id==='bell'){g.fillStyle=gL(g,-34,0,34,0,['#a8700e','#ffe48a','#f0b830','#a8700e']);g.strokeStyle='#5a3a06';g.lineWidth=3;g.beginPath();g.moveTo(-36,24);g.quadraticCurveTo(-32,-2,-24,-16);g.quadraticCurveTo(0,-50,24,-16);g.quadraticCurveTo(32,-2,36,24);g.closePath();g.fill();g.stroke();
  g.fillStyle=gL(g,0,18,0,32,['#ffe48a','#b8780e']);g.beginPath();g.roundRect(-40,18,80,10,5);g.fill();g.stroke();g.fillStyle=gR(g,-3,36,1,10,['#fff6b0','#c8880c']);g.beginPath();g.arc(0,36,9,0,TAU);g.fill();g.stroke();
  g.fillStyle='#ffe48a';g.beginPath();g.arc(0,-40,6,0,TAU);g.fill();g.stroke();NS();g.strokeStyle='rgba(255,255,255,.75)';g.lineWidth=5;g.beginPath();g.moveTo(-20,10);g.quadraticCurveTo(-18,-12,-8,-26);g.stroke()}
 else if(id==='gem'){const A=[-42,-8],B=[-24,-34],C=[24,-34],D=[42,-8],E=[0,42],a=[-14,-8],b=[14,-8];
  g.fillStyle=gL(g,-30,-34,30,40,['#d8fbff','#5ac8f0','#1668b8']);g.strokeStyle='#0a3a6a';g.lineWidth=3;g.beginPath();g.moveTo(...A);g.lineTo(...B);g.lineTo(...C);g.lineTo(...D);g.lineTo(...E);g.closePath();g.fill();g.stroke();NS();
  const poly=(pts,f)=>{g.fillStyle=f;g.beginPath();g.moveTo(...pts[0]);for(const q of pts.slice(1))g.lineTo(...q);g.closePath();g.fill()};
  poly([B,C,b,a],'rgba(255,255,255,.55)');poly([A,B,a],'rgba(180,240,255,.4)');poly([D,C,b],'rgba(40,120,200,.35)');poly([a,b,E],'rgba(10,80,170,.28)');poly([A,a,E],'rgba(255,255,255,.18)');
  g.strokeStyle='rgba(255,255,255,.8)';g.lineWidth=1.8;g.beginPath();g.moveTo(...A);g.lineTo(...D);g.moveTo(...B);g.lineTo(...a);g.lineTo(...E);g.moveTo(...C);g.lineTo(...b);g.lineTo(...E);g.stroke();
  g.fillStyle='#fff';g.beginPath();g.moveTo(-26,-24);g.lineTo(-22,-18);g.lineTo(-16,-16);g.lineTo(-22,-14);g.lineTo(-26,-8);g.lineTo(-30,-14);g.lineTo(-36,-16);g.lineTo(-30,-18);g.closePath();g.fill()}
 else if(id==='seven'){g.font="900 104px Georgia,serif";g.textAlign='center';g.textBaseline='middle';g.lineWidth=12;g.strokeStyle='#5a3a06';g.strokeText('7',0,6);g.lineWidth=7;g.strokeStyle=gL(g,0,-40,0,50,['#fff6b0','#f0b830','#a8700e']);g.strokeText('7',0,6);
  g.fillStyle=gL(g,0,-46,0,56,['#ff9090','#e01a2a','#8a0412']);g.fillText('7',0,6);NS();g.save();g.beginPath();g.rect(-60,-60,120,52);g.clip();g.fillStyle='rgba(255,255,255,.38)';g.fillText('7',-1,2);g.restore()}
 else{g.fillStyle=gL(g,0,-34,0,30,['#fff6b0','#f4c030','#b8760e']);g.strokeStyle='#5a3a06';g.lineWidth=3;g.beginPath();g.moveTo(-38,28);g.lineTo(-44,-18);g.lineTo(-22,2);g.lineTo(0,-36);g.lineTo(22,2);g.lineTo(44,-18);g.lineTo(38,28);g.closePath();g.fill();g.stroke();
  g.fillStyle=gL(g,0,16,0,30,['#e8a82a','#8a540a']);g.beginPath();g.roundRect(-39,16,78,13,4);g.fill();g.stroke();
  for(const [cx,cy,c1,c2] of[[-44,-20,'#ff9aa8','#b8102a'],[0,-38,'#b8f0ff','#1a78c8'],[44,-20,'#ff9aa8','#b8102a']]){g.fillStyle=gR(g,cx-2,cy-2,1,8,[c1,c2]);g.beginPath();g.arc(cx,cy,7,0,TAU);g.fill();g.stroke()}
  g.fillStyle=gR(g,-2,8,1,9,['#ff9aa8','#c0102a']);g.beginPath();g.arc(0,8,7,0,TAU);g.fill();g.stroke();for(const dx of[-24,24]){g.fillStyle=gR(g,dx-1,22,1,5,['#b8f0ff','#1a78c8']);g.beginPath();g.arc(dx,22.5,4.2,0,TAU);g.fill()}
  NS();g.strokeStyle='rgba(255,255,255,.6)';g.lineWidth=3;g.beginPath();g.moveTo(-28,8);g.lineTo(-36,-8)}
 g.restore()}

/* ===== slot machine ===== */
function mSL(el,tok){
 const alive=()=>CAS.tok===tok,IDS=Object.keys(SLW);let strip=[];for(const k of IDS)for(let i=0;i<SLW[k];i++)strip.push(k);
 for(let i=strip.length-1;i>0;i--){const j=Math.random()*(i+1)|0;[strip[i],strip[j]]=[strip[j],strip[i]]}
 for(let i=0;i<strip.length;i++)if(strip[i]===strip[(i+1)%strip.length]&&strip[i]===strip[(i+2)%strip.length]){const j=(i+5)%strip.length;[strip[i],strip[j]]=[strip[j],strip[i]]}
 const L=strip.length,W=760,H=412;
 el.innerHTML=`<div class="felt slfelt"><canvas id="slc" width="${W}" height="${H}"></canvas><canvas id="slp" width="${W}" height="78"></canvas></div>
<p class="cmsg" id="cm"> </p><div class="ctl">${betBar()}<div class="btns"><button class="bbig slspin" id="sp"><span>SPIN</span><small>Space</small></button></div></div>`;
 const pos=[Math.random()*L|0,Math.random()*L|0,Math.random()*L|0],p0=pos.slice(),tgt=[0,0,0],D=[0,0,0],T=[1.5,2.1,2.7];let t0=0,st='idle',bet=0,res=null,flash=0,winT=0,winTxt='',winIdx=[],lastWin=0,tease=0,big=0;
 const fx=[];let lastNow=performance.now();
 const spark=(x,y,n,cols,pw)=>{for(let i=0;i<n;i++){const a=Math.random()*TAU,v=(pw||200)*(.3+Math.random());fx.push({x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v-80,l:1,d:.7+Math.random()*.8,r:2+Math.random()*3,c:cols[i%cols.length],g:260})}};
 const coins=n=>{for(let i=0;i<n;i++)fx.push({x:40+Math.random()*(W-80),y:-20-Math.random()*200,vx:(Math.random()-.5)*60,vy:40+Math.random()*120,l:1,d:2.4+Math.random(),r:8+Math.random()*7,c:'coin',g:420,ph:Math.random()*6})};
 const spin=()=>{if(st!=='idle'||CAS.lock)return;if(CAS.bet<1){msg(broke()||'Place a bet first.');return}if(CAS.bet>P.gold){msg('Not enough gold.');return}bet=CAS.bet;if(!cTake(bet))return;betLock(true);
  for(let i=0;i<3;i++){p0[i]=pos[i]%L;tgt[i]=Math.random()*L|0}
  res=tgt.map(i=>strip[i]);tease=res[0]===res[1]?1:0;T[2]=tease?3.6:2.7;
  for(let i=0;i<3;i++)D[i]=(3+i*2+(i===2&&tease?3:0))*L+(((tgt[i]-p0[i])%L)+L)%L;
  t0=performance.now();st='spin';flash=0;winT=0;winIdx=[];big=0;msg('');$('sp').disabled=true;beep(300,.15,'square',.3);beep(180,.4,'sawtooth',.18)};
 let stopped=[0,0,0];
 const RW=198,RH=112,gap=18,x0=(W-3*RW-2*gap)/2,wy=100,wh=270;
 live('slc',cv=>{const g=cv.getContext('2d');
  return()=>{if(!alive())return;const now=performance.now(),dt=Math.min(.05,(now-lastNow)/1000);lastNow=now;const el2=(now-t0)/1000;
   if(st==='spin'){for(let i=0;i<3;i++){const u=Math.min(1,el2/T[i]);pos[i]=p0[i]+D[i]*(1-Math.pow(1-u,i===2&&tease?3.2:2.4));if(u>=1&&!stopped[i]){stopped[i]=1;pos[i]=tgt[i];beep(420+i*90,.09,'triangle',.7);spark(x0+i*(RW+gap)+RW/2,wy+wh/2,6,['#ffe58a','#fff'],120)}}
    if(el2>=T[2]+.15){st='done';stopped=[0,0,0];const mult=slotPay(res[0],res[1],res[2]),pay=bet*mult;stat('slotx',pay/bet,'max');cPay(bet,pay);flash=now;
     const three=res[0]===res[1]&&res[1]===res[2];winIdx=pay>0?(three?[0,1,2]:[0,1,2].filter(i=>res[i]==='cherry')):[];
     if(pay>0){lastWin=pay-bet;winT=now;big=three?(mult>=100?3:mult>=20?2:1):0;winTxt=big===3?'JACKPOT!':big===2?'BIG WIN!':'WIN';for(const i of winIdx)spark(x0+i*(RW+gap)+RW/2,wy+wh/2,three?26:14,['#ffe58a','#fff6c0','#ffb030','#fff'],three?340:220);if(three)coins(big>=2?70:32);
      [0,4,7,12].forEach((s,k)=>setTimeout(()=>beep(nf(72+s+(big?5:0)),.16,'triangle',.6),k*90))}
     msg(pay>0?(three?`Three ${SLN[res[0]]}! `:'Two cherries! ')+`+${cmn(pay-bet)}`:`No match. −${cmn(bet)}.${broke()?' '+broke():''}`,pay>0?'w':'l');
     betLock(false);$('sp').disabled=false;st='idle'}}
   const win=winIdx.length&&now-winT<2600,pul=.5+.5*Math.sin(now/110);
   /* cabinet */
   g.fillStyle=gR(g,W/2,H/2,20,W*.7,['#6a1236','#2a0818','#10030a']);g.fillRect(0,0,W,H);
   g.save();g.globalAlpha=.07;g.fillStyle='#ffd76a';for(let i=0;i<18;i++){const a=i/18*TAU+now/9000;g.beginPath();g.moveTo(W/2,H/2);g.lineTo(W/2+Math.cos(a)*900,H/2+Math.sin(a)*900);g.lineTo(W/2+Math.cos(a+.09)*900,H/2+Math.sin(a+.09)*900);g.fill()}g.restore();
   g.beginPath();g.roundRect(4,4,W-8,H-8,26);g.lineWidth=9;g.strokeStyle=gL(g,0,0,0,H,['#fff0a0','#c8861a','#ffe48a','#8a5410']);g.stroke();cdBulbs(g,13,13,W-26,H-26,now,win||st==='spin',4.4);
   /* marquee */
   g.save();g.beginPath();g.roundRect(150,20,W-300,62,18);g.fillStyle=gL(g,0,20,0,82,['#5a0a22','#2a0610']);g.fill();g.lineWidth=4;g.strokeStyle=gL(g,0,20,0,82,['#ffe48a','#b8761a']);g.stroke();
   g.textAlign='center';g.textBaseline='middle';g.font="400 44px 'Pirata One',Georgia,serif";g.shadowColor='#ffb030';g.shadowBlur=win?26:12;g.fillStyle=gL(g,0,28,0,76,['#fff8c0','#f4b82a']);g.fillText('GOLDEN SLOTS',W/2,53);g.shadowBlur=0;
   for(const sx of[190,W-190]){g.fillStyle='#ffd76a';g.beginPath();g.moveTo(sx,53-11);g.lineTo(sx+4,53-3);g.lineTo(sx+12,53);g.lineTo(sx+4,53+3);g.lineTo(sx,53+11);g.lineTo(sx-4,53+3);g.lineTo(sx-12,53);g.lineTo(sx-4,53-3);g.fill()}g.restore();
   /* reel bed */
   g.beginPath();g.roundRect(x0-14,wy-12,3*RW+2*gap+28,wh+24,20);g.fillStyle='#14040a';g.fill();g.lineWidth=4;g.strokeStyle='#8a5a14';g.stroke();
   for(let i=0;i<3;i++){const x=x0+i*(RW+gap),isW=win&&winIdx.includes(i);g.save();g.beginPath();g.roundRect(x,wy,RW,wh,14);g.clip();
    g.fillStyle=gL(g,0,wy,0,wy+wh,['#bdb4a0','#fffdf4','#fffdf4','#bdb4a0']);g.fillRect(x,wy,RW,wh);
    if(isW){g.fillStyle=gR(g,x+RW/2,wy+wh/2,10,RW*.8,['rgba(255,230,120,'+(.55+.3*pul)+')','rgba(255,200,60,0)']);g.fillRect(x,wy,RW,wh)}
    const p=pos[i],b=Math.floor(p),spd=st==='spin'&&!stopped[i],cy=wy+wh/2;
    for(let j=b-3;j<=b+3;j++){const y=cy+(p-j)*RH,sym=strip[((j%L)+L)%L];
     if(spd){g.globalAlpha=.32;drawSym(g,sym,x+RW/2,y-26,RH*.84);drawSym(g,sym,x+RW/2,y+26,RH*.84);g.globalAlpha=.8}
     const centre=Math.abs(p-j)<.5,sc=isW&&centre?1+.09*Math.sin(now/90)+.06:1;drawSym(g,sym,x+RW/2,y,RH*.84*sc);g.globalAlpha=1}
    g.fillStyle=gL(g,0,wy,0,wy+wh,['rgba(10,2,8,.8)','rgba(10,2,8,0)','rgba(10,2,8,0)','rgba(10,2,8,.8)']);g.fillRect(x,wy,RW,wh);
    g.fillStyle=gL(g,x,wy,x+RW,wy+wh,['rgba(255,255,255,0)','rgba(255,255,255,.2)','rgba(255,255,255,0)']);g.beginPath();g.moveTo(x,wy+wh*.18);g.lineTo(x+RW,wy);g.lineTo(x+RW,wy+wh*.22);g.lineTo(x,wy+wh*.5);g.fill();
    g.restore();
    g.lineWidth=6;g.strokeStyle=isW?`rgba(255,${200+pul*55|0},${90+pul*100|0},1)`:gL(g,0,wy,0,wy+wh,['#ffe48a','#a8681a','#ffe48a']);g.shadowColor=isW?'#ffd24a':'transparent';g.shadowBlur=isW?24:0;g.beginPath();g.roundRect(x,wy,RW,wh,14);g.stroke();g.shadowBlur=0;
    if(tease&&st==='spin'&&i<2&&el2>T[1]){g.strokeStyle='rgba(255,230,120,'+(.5+.5*pul)+')';g.lineWidth=3;g.beginPath();g.roundRect(x-3,wy-3,RW+6,wh+6,16);g.stroke()}}
   /* payline with arrows */
   const cy=wy+wh/2,lc=win?(pul>.5?'#fff2a0':'#ff8a4a'):'#ff405acc';g.strokeStyle=lc;g.lineWidth=win?5:3;g.shadowColor=lc;g.shadowBlur=win?20:8;g.setLineDash([12,8]);g.beginPath();g.moveTo(x0-4,cy);g.lineTo(W-x0+4,cy);g.stroke();g.setLineDash([]);
   g.fillStyle=lc;for(const [ax,dir] of[[x0-18,1],[W-x0+18,-1]]){g.beginPath();g.moveTo(ax,cy-12);g.lineTo(ax+14*dir,cy);g.lineTo(ax,cy+12);g.closePath();g.fill()}g.shadowBlur=0;
   /* bottom bar: bet and last win */
   g.font="400 20px 'Pirata One',Georgia,serif";g.textBaseline='middle';g.textAlign='left';g.fillStyle='#ffe9b0';g.fillText('BET '+cmn(st==='idle'?CAS.bet:bet),58,H-22);g.textAlign='right';g.fillStyle=lastWin>0?'#7dffb0':'#ffe9b0';g.fillText('LAST WIN '+(lastWin>0?'+'+cmn(lastWin):'-'),W-58,H-22);
   /* particles */
   for(let i=fx.length-1;i>=0;i--){const q=fx[i];q.x+=q.vx*dt;q.y+=q.vy*dt;q.vy+=q.g*dt;q.l-=dt/q.d;if(q.l<=0||q.y>H+40){fx.splice(i,1);continue}g.globalAlpha=Math.min(1,q.l*2);
    if(q.c==='coin'){g.save();g.translate(q.x,q.y);g.scale(Math.abs(Math.cos(now/140+q.ph)),1);g.fillStyle=gR(g,-q.r*.3,-q.r*.3,1,q.r,['#fff3a0','#d8961c']);g.strokeStyle='#8a5a10';g.lineWidth=1.6;g.beginPath();g.arc(0,0,q.r,0,TAU);g.fill();g.stroke();g.restore()}
    else{g.fillStyle=q.c;g.beginPath();g.arc(q.x,q.y,q.r*q.l+.6,0,TAU);g.fill()}}g.globalAlpha=1;
   /* win banner */
   if(winIdx.length&&now-winT<2300){const k=Math.min(1,(now-winT)/260),a=Math.min(1,(2300-(now-winT))/400),sc=(.5+.5*k)*(1+.04*Math.sin(now/90));g.save();g.translate(W/2,wy+wh/2);g.scale(sc,sc);g.globalAlpha=a;g.textAlign='center';g.textBaseline='middle';
    g.font="400 "+(big?96:70)+"px 'Pirata One',Georgia,serif";g.lineWidth=10;g.strokeStyle='#3a0c00';g.strokeText(winTxt,0,-10);g.shadowColor='#ffb030';g.shadowBlur=30;g.fillStyle=gL(g,0,-60,0,40,['#fffbd0','#ffd24a','#f08a1a']);g.fillText(winTxt,0,-10);g.shadowBlur=0;
    g.font="400 44px 'Pirata One',Georgia,serif";g.lineWidth=7;g.strokeText('+'+cmn(lastWin),0,48);g.fillStyle='#7dffb0';g.fillText('+'+cmn(lastWin),0,48);g.restore()}
  }});
 /* paytable strip */
 live('slp',cv=>{const g=cv.getContext('2d'),n=IDS.length+1,cw=(W-24)/n;
  return()=>{if(!alive())return;const now=performance.now();g.clearRect(0,0,W,78);g.fillStyle='rgba(8,2,6,.55)';g.beginPath();g.roundRect(2,2,W-4,74,14);g.fill();g.strokeStyle='#8a5a14aa';g.lineWidth=2;g.stroke();
   const lit=res&&winIdx.length&&performance.now()-winT<2600?res[winIdx[0]]:null;
   [...IDS,'cherry2'].forEach((k,i)=>{const cx=12+i*cw+cw/2,two=k==='cherry2',sym=two?'cherry':k,on=lit&&((two&&winIdx.length===2)||(!two&&k===lit&&winIdx.length===3));
    if(on){g.fillStyle='rgba(255,214,90,'+(.2+.16*Math.sin(now/120))+')';g.beginPath();g.roundRect(cx-cw/2+4,6,cw-8,66,10);g.fill()}
    drawSym(g,sym,cx-cw/2+(two?18:24),38,two?30:36);if(two)drawSym(g,'cherry',cx-cw/2+30,42,24);
    g.textAlign='left';g.textBaseline='middle';g.font="400 19px 'Pirata One',Georgia,serif";g.fillStyle=on?'#fff8c0':'#ffe9b0';g.fillText(two?'2×2':'3×'+SLP[k],cx-cw/2+44,28);g.font='600 11px sans-serif';g.fillStyle='#e8c878';g.fillText(two?'any 2 🍒':SLN[k],cx-cw/2+44,52)})}});
 $('sp').onclick=spin;wireBet();CAS.key={' ':spin,enter:spin};msg('Place your bet and press Spin. Space also spins.')}

/* ===== rocket ===== */
const rkR=x=>x<=1.5?.99+.02*(x-1):x<=3?1-(x-1.5)/1.5*.05:x<=15?.95:x<=60?.95+(x-15)/45*.05:1;/* long-run return when cashing out at x */
const rkS=x=>rkR(x)/x;
function rkCrash(){if(typeof window.__rkcp==='number')return window.__rkcp;const u=g01();if(u>rkS(1))return 1;if(u<=rkS(1000))return 1000;
 let lo=1,hi=1000;for(let i=0;i<60;i++){const mid=Math.sqrt(lo*hi);if(rkS(mid)>u)lo=mid;else hi=mid}return Math.max(1,Math.floor(lo*100)/100)}
function mRK(el,tok){
 const alive=()=>CAS.tok===tok;
 el.innerHTML=`<div class="felt rkw" style="padding:6px;background:#050818"><canvas id="rk" width="1456" height="430"></canvas></div><p class="cmsg" id="cm"> </p>
<div class="ctl">${betBar()}<div class="ac"><label>Auto cash out at <input id="rka" type="number" min="1.05" step="0.1" placeholder="off"> ×</label></div><div class="btns"><button class="bbig" id="rkg">Launch</button></div></div><div class="hist" id="rkh"></div>`;
 let st='idle',cp=1,tf=0,cdT=0,m=1,bet=0,auto=0,cashM=0,cashT=0,lastT=performance.now(),lab='',shake=0,fl=0,msT=0,crashT=0,cdLast=0;const done=new Set(),rings=[],pts=[],stars=[],streak=[];
 for(let i=0;i<110;i++)stars.push([Math.random(),Math.random(),.25+Math.random()*.75,Math.random()*6]);
 for(let i=0;i<16;i++)streak.push([Math.random(),Math.random(),.4+Math.random()]);
 const MF=t=>Math.exp(.15*t);
 const hist=()=>{$('rkh').innerHTML=CAS.rh.map(v=>`<span class="${v>=20?'moon':v>=10?'hi':v>=2?'mid':'lo'}">${v.toFixed(2)}×</span>`).join('')};hist();
 const setLab=s=>{if(s!==lab){lab=s;$('rkg').textContent=s}};
 const tier=v=>v<2?['#7dffb0','#2aff90']:v<5?['#5af0e0','#20d8e8']:v<10?['#7ac8ff','#3a8aff']:v<20?['#ffd76a','#ffb020']:v<50?['#ff9a4a','#ff5a10']:['#ff6ae0','#c030ff'];
 const cash=(mult)=>{if(st!=='fly')return;mult=Math.floor(mult*100)/100;cashM=mult;cashT=tf;fl=.6;stat('rk',mult,'max');st='cashed';const pay=Math.floor(bet*mult);cPay(bet,pay);msg(`Cashed out at ${mult.toFixed(2)}×  +${cmn(pay-bet)}`,'w');betLock(false);for(let i=0;i<7;i++)setTimeout(()=>beep(1100+Math.random()*900,.07,'triangle',.5),i*60);fx.cash=1};
 const fx={cash:0};
 const launch=()=>{if(st==='fly'){cash(m);return}if(st==='cd'||CAS.lock)return;if(CAS.bet<1){msg(broke()||'Place a bet first.');return}if(CAS.bet>P.gold){msg('Not enough gold.');return}
  bet=CAS.bet;if(!cTake(bet))return;betLock(true);cp=rkCrash();
  const a=parseFloat($('rka').value);auto=a>=1.05?a:0;st='cd';cdT=1.1;cdLast=0;tf=0;m=1;pts.length=0;rings.length=0;done.clear();shake=0;msg('Ignition…');beep(200,.5,'sawtooth',.4)};
 /* particles: {x,y,vx,vy,l,d,r,c,add,g,k} */
 const add=(o)=>{if(pts.length<520)pts.push(o)};
 const boom=(x,y)=>{fl=1;shake=26;crashT=performance.now();rings.push({x,y,l:1,c:'#ffd070',w:1.4,big:1});rings.push({x,y,l:1,c:'#ff5a2a',w:.9,big:1});
  for(let i=0;i<90;i++){const a=Math.random()*TAU,s=60+Math.random()*420;add({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,l:1,d:.8+Math.random()*.9,r:3+Math.random()*7,c:['#fff6c0','#ffb02e','#ff5a2a','#e8455a'][i%4],add:1,g:140})}
  for(let i=0;i<26;i++){const a=Math.random()*TAU,s=40+Math.random()*180;add({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s-40,l:1,d:1.6+Math.random(),r:14+Math.random()*18,c:'#2a1018',g:-30,k:'smoke'})}
  for(let i=0;i<16;i++){const a=Math.random()*TAU,s=120+Math.random()*320;add({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s-100,l:1,d:1.3+Math.random()*.6,r:2.5,c:'#c8d0e8',g:520,k:'deb',rot:Math.random()*6})}};
 const flame=(g,L,t)=>{const fl2=g.createLinearGradient(-16,0,-16-L,0);fl2.addColorStop(0,'#fff6c0');fl2.addColorStop(.35,'#ffb030');fl2.addColorStop(1,'rgba(255,60,10,0)');g.fillStyle=fl2;g.beginPath();g.moveTo(-16,-8);g.quadraticCurveTo(-16-L*.6,-11-Math.sin(t*.05)*2,-16-L,0);g.quadraticCurveTo(-16-L*.6,11+Math.cos(t*.06)*2,-16,8);g.fill();
  g.fillStyle='#ffffffcc';g.beginPath();g.moveTo(-16,-4);g.quadraticCurveTo(-16-L*.35,-5,-16-L*.5,0);g.quadraticCurveTo(-16-L*.35,5,-16,4);g.fill()};
 const rkt=(g,x,y,a,s,fire,L,t)=>{g.save();g.translate(x,y);g.rotate(a);g.scale(s,s);
  if(fire){g.globalCompositeOperation='lighter';cdGlow(g,-28-L*.3,0,48+L*.6,'rgba(255,150,40,.55)');g.globalCompositeOperation='source-over';flame(g,L,t)}
  g.shadowColor='rgba(0,0,0,.4)';g.shadowBlur=8;
  g.fillStyle=gL(g,0,-22,0,-4,['#ff6a6a','#b81030']);for(const q of[-1,1]){g.beginPath();g.moveTo(-4,q*8);g.quadraticCurveTo(-14,q*18,-24,q*26);g.lineTo(-20,q*8);g.closePath();g.fill()}g.shadowBlur=0;
  g.fillStyle=gL(g,0,-14,0,14,['#ffffff','#dfe8fa','#8a9cc4']);g.beginPath();g.moveTo(34,0);g.quadraticCurveTo(14,-15,-18,-10);g.lineTo(-18,10);g.quadraticCurveTo(14,15,34,0);g.fill();g.strokeStyle='#1a2040aa';g.lineWidth=1.4;g.stroke();
  g.fillStyle=gL(g,0,-11,0,11,['#ff7a7a','#c01838']);g.beginPath();g.moveTo(34,0);g.quadraticCurveTo(24,-10,14,-12);g.lineTo(14,12);g.quadraticCurveTo(24,10,34,0);g.fill();
  g.fillStyle='#e8c040';g.fillRect(-18,-10,5,20);g.fillRect(5,-12,3,24);
  g.fillStyle=gR(g,-5,-2,1,7,['#d8f4ff','#2a8ae0','#0a3a7a']);g.beginPath();g.arc(-2,0,5.6,0,TAU);g.fill();g.strokeStyle='#cdd6ee';g.lineWidth=1.8;g.stroke();g.fillStyle='rgba(255,255,255,.8)';g.beginPath();g.arc(-4,-2,1.8,0,TAU);g.fill();g.restore()};
 const ground=(g,Wd,Ht,off,now)=>{if(off>=Ht)return;g.save();g.translate(0,off);g.beginPath();g.moveTo(0,Ht);g.lineTo(0,Ht-34);for(let x=0;x<=Wd;x+=16)g.lineTo(x,Ht-30-Math.abs(Math.sin(x*.011+1)*26)-Math.sin(x*.07)*4);g.lineTo(Wd,Ht);g.closePath();g.fillStyle=gL(g,0,Ht-70,0,Ht,['#2a0e30','#10040e']);g.fill();g.strokeStyle='#f0c05066';g.lineWidth=2;g.stroke();
  g.fillStyle='#3a2a50';g.fillRect(40,Ht-44,100,16);g.fillStyle='#5a4a78';g.fillRect(40,Ht-44,100,4);g.fillStyle='#2a1c40';g.fillRect(104,Ht-84,8,40);
  for(const [lx,c] of[[60,'#ffe9a0'],[120,'#ffe9a0']]){g.fillStyle=c;g.beginPath();g.arc(lx,Ht-46,3,0,TAU);g.fill()}
  for(let i=0;i<22;i++){const x=(i*53.7)%Wd,y=Ht-8-(i*17%24);g.fillStyle='rgba(255,224,120,'+(.2+.3*Math.sin(now/500+i))+')';g.fillRect(x,y,2.4,2.4)}g.restore()};
 live('rk',cv=>{const g=cv.getContext('2d'),Wd=cv.width,Ht=cv.height;
  return()=>{if(!alive())return;const now=performance.now(),dt=Math.min(.05,(now-lastT)/1000);lastT=now;
   if(st==='cd'){cdT-=dt;const n=Math.max(1,Math.ceil(cdT*2.7));if(n!==cdLast){cdLast=n;beep(400+(4-n)*140,.1,'square',.35);rings.push({x:Wd/2,y:Ht/2,l:1,c:'#ffd76a',w:.5})}if(cdT<=0){st='fly';tf=0;msg('Cash out before it explodes!');beep(520,.25,'sawtooth',.4)}}
   else if(st==='fly'||st==='cashed'){tf+=dt;m=MF(tf);
    if(st==='fly'&&auto&&m>=auto&&auto<=cp)cash(auto);
    if(m>=cp){m=cp;const wasFly=st==='fly';st='crash';CAS.rh.unshift(cp);CAS.rh.length=Math.min(CAS.rh.length,14);hist();
     const Xc=Math.max(6,tf*1.15),mMc=Math.max(2,m*1.25);boom(70+tf/Xc*(Wd-140),Ht-60-Math.log(m)/Math.log(mMc)*(Ht-120));
     if(wasFly){cPay(bet,0);msg(`Crashed at ${cp.toFixed(2)}×  −${cmn(bet)}${broke()?' '+broke():''}`,'l');betLock(false)}else msg(`Cashed out at ${cashM.toFixed(2)}×. The rocket crashed at ${cp.toFixed(2)}×.`,'w');
     beep(90,.5,'sawtooth',.8);setTimeout(()=>beep(55,.7,'square',.5),80)}}
   fl=Math.max(0,fl-dt*1.8);shake=Math.max(0,shake-dt*34);
   const alt=Math.min(1,Math.log(Math.max(1,m))/Math.log(120)),tr=tier(m);
   g.save();const sk=st==='fly'||st==='cashed'?Math.min(5,Math.max(0,(m-6)*.12)):0,sa=shake+sk;if(sa>.2)g.translate((Math.random()-.5)*sa,(Math.random()-.5)*sa);
   /* sky */
   const top=cmix(cmix('#050818','#1a0a42',Math.min(1,alt*1.6)),'#3a0c5e',Math.max(0,alt*1.6-1)),bot=cmix(cmix('#12123a','#3a1c6e',Math.min(1,alt*1.5)),'#ff8a4a',Math.max(0,alt*1.5-1)*.9);
   g.fillStyle=gL(g,0,0,0,Ht,[st==='crash'?cmix(top,'#2a0610',.6):top,st==='crash'?cmix(bot,'#5a1018',.6):bot]);g.fillRect(-20,-20,Wd+40,Ht+40);
   const sp=(st==='fly'||st==='cashed')?tf*26*(1+alt*2):0,tnow=now/1000;
   for(const [cx,cy,r,c,al] of[[.2,.3,360,'rgba(60,200,220,',.13],[.78,.55,420,'rgba(200,60,200,',.12],[.5,.9,380,'rgba(255,140,60,',.1]]){const ax=Wd*(cx+Math.sin(tnow*.08+cx*7)*.05),ay=Ht*(cy+Math.cos(tnow*.06+cy*5)*.06);cdGlow(g,ax,ay,r,c+(al*(.5+alt*1.1))+')')}
   for(const s of stars){const tw=.5+.5*Math.sin(tnow*2+s[3]);g.fillStyle='rgba(255,255,255,'+(.25+s[2]*.4*tw)+')';const x=((s[0]*Wd-sp*s[2]*.4)%Wd+Wd)%Wd,y=(s[1]*Ht+sp*s[2]*1.6)%Ht;if(s[2]>.85){g.fillRect(x-1,y-1,3,3)}else g.fillRect(x,y,s[2]*2,s[2]*2)}
   /* planets slide down as you climb */
   const pl=(px,py0,r,c0,c1,ring)=>{const py=py0+(st==='fly'||st==='cashed'||st==='crash'?tf*9:0);if(py>Ht+r*2)return;g.save();g.translate(px,py);
    if(ring){g.rotate(-.35);g.strokeStyle='rgba(255,224,160,.45)';g.lineWidth=r*.16;g.beginPath();g.ellipse(0,0,r*1.7,r*.45,0,Math.PI,TAU);g.stroke()}
    g.fillStyle=gR(g,-r*.35,-r*.35,r*.1,r*1.1,[c0,c1,'#0a0414']);g.beginPath();g.arc(0,0,r,0,TAU);g.fill();
    if(ring){g.strokeStyle='rgba(255,224,160,.6)';g.lineWidth=r*.16;g.beginPath();g.ellipse(0,0,r*1.7,r*.45,0,0,Math.PI);g.stroke()}g.restore()};
   pl(Wd*.84,70,46,'#ffe4a0','#c8721a',1);pl(Wd*.1,-120,26,'#a8d8ff','#2a4a9a',0);pl(Wd*.58,-420,60,'#ffa0e0','#7a2a8a',1);
   /* speed streaks */
   if((st==='fly'||st==='cashed')&&m>1.5){g.strokeStyle='rgba(255,255,255,'+Math.min(.22,.04+alt*.2)+')';g.lineWidth=1.4;for(const s of streak){const x=s[0]*Wd,L=40+s[2]*(40+alt*140),y=((s[1]*Ht+tf*500*s[2]*(1+alt))%(Ht+L))-L;g.beginPath();g.moveTo(x,y);g.lineTo(x,y+L);g.stroke()}}
   ground(g,Wd,Ht,Math.min(Ht+10,Math.max(0,(tf-.2)*(st==='fly'||st==='cashed'||st==='crash'?150:0))),now);
   /* grid with multiplier labels */
   const X=Math.max(6,tf*1.15),mM=Math.max(2,m*1.25),px=t=>70+t/X*(Wd-140),py=mm=>Ht-60-Math.log(mm)/Math.log(mM)*(Ht-120);
   g.font='600 13px sans-serif';g.textAlign='left';g.textBaseline='middle';
   for(const lv of[1.5,2,3,5,10,20,50,100,200,500,1000]){if(lv>=mM)continue;const y=py(lv);if(y<20)continue;g.strokeStyle='rgba(255,255,255,.07)';g.lineWidth=1;g.setLineDash([4,7]);g.beginPath();g.moveTo(54,y);g.lineTo(Wd-30,y);g.stroke();g.setLineDash([]);g.fillStyle='rgba(255,255,255,.42)';g.fillText(lv+'×',12,y)}
   let rx=96,ry=Ht-74,ra=-.55;const flying=st==='fly'||st==='cashed',N=80;
   if(flying||st==='crash'){const cl=[];for(let i=0;i<=N;i++){const tt=tf*i/N;cl.push([px(tt),py(Math.min(MF(tt),cp))])}
    g.beginPath();g.moveTo(cl[0][0],Ht-60);for(const q of cl)g.lineTo(q[0],q[1]);g.lineTo(cl[N][0],Ht-60);g.closePath();g.fillStyle=gL(g,0,0,0,Ht,[st==='crash'?'rgba(255,64,90,.28)':tr[1]+'44','rgba(0,0,0,0)']);g.fill();
    const line=(w,col,bl)=>{g.beginPath();cl.forEach((q,i)=>i?g.lineTo(q[0],q[1]):g.moveTo(q[0],q[1]));g.strokeStyle=col;g.lineWidth=w;g.lineJoin='round';g.lineCap='round';g.shadowColor=col;g.shadowBlur=bl;g.stroke();g.shadowBlur=0};
    const lc=st==='crash'?'#ff6a7a':st==='cashed'?'#ffd76a':tr[0];line(12,lc+'33',0);line(4.5,lc,18);line(1.8,'#ffffffcc',0);
    rx=cl[N][0];ry=cl[N][1];const q0=cl[Math.max(0,N-4)];ra=Math.atan2(ry-q0[1],rx-q0[0]);
    if(st==='cashed'||cashM>0&&st==='crash'&&cashT>0){const cx=px(cashT),cy=py(cashM);g.strokeStyle='rgba(255,215,106,.7)';g.setLineDash([6,6]);g.lineWidth=2;g.beginPath();g.moveTo(cx,cy);g.lineTo(cx,Ht-52);g.stroke();g.setLineDash([]);g.fillStyle='#ffd76a';g.beginPath();g.arc(cx,cy,8,0,TAU);g.fill();g.strokeStyle='#fff';g.lineWidth=2;g.stroke();
     g.font="400 22px 'Pirata One',Georgia,serif";g.textAlign='center';const lab2='CASHED '+cashM.toFixed(2)+'×',tw=g.measureText(lab2).width+20;g.fillStyle='rgba(40,20,0,.85)';g.beginPath();g.roundRect(cx-tw/2,cy-42,tw,26,8);g.fill();g.strokeStyle='#ffd76a';g.lineWidth=1.5;g.stroke();g.fillStyle='#ffd76a';g.fillText(lab2,cx,cy-29)}}
   if(st==='cd'){rx=96+Math.sin(now*.05)*1.6;ry=Ht-76+Math.cos(now*.06)*1.4;ra=-.55}
   if(st==='idle'){ra=-.55+Math.sin(now/900)*.03;ry=Ht-76+Math.sin(now/700)*2}
   /* exhaust + smoke particles from the rocket */
   const flyingNow=st==='fly'||st==='cashed',cdOn=st==='cd';
   if(flyingNow||cdOn){const ca=Math.cos(ra),sa2=Math.sin(ra),ex=rx-ca*22,ey=ry-sa2*22;for(let k=0;k<(cdOn?2:3);k++){const sp2=(60+Math.random()*120)*(cdOn?.6:1);add({x:ex,y:ey,vx:-ca*sp2+(Math.random()-.5)*50,vy:-sa2*sp2+(Math.random()-.5)*50+(cdOn?30:0),l:1,d:.45+Math.random()*.35,r:3+Math.random()*4,c:['#fff3a0','#ffb030','#ff6a1a'][k%3],add:1,g:0});if(Math.random()<.5)add({x:ex,y:ey,vx:-ca*40+(Math.random()-.5)*40,vy:-sa2*40+(Math.random()-.5)*40-(cdOn?10:0),l:1,d:1.2+Math.random()*.8,r:6+Math.random()*7,c:cdOn?'#a8a0c0':'#605a80',g:cdOn?-20:0,k:'smoke'})}}
   if(fx.cash){fx.cash=0;for(let i=0;i<46;i++){const a=Math.random()*TAU,s=80+Math.random()*320;add({x:rx,y:ry,vx:Math.cos(a)*s,vy:Math.sin(a)*s-60,l:1,d:.9+Math.random()*.8,r:3+Math.random()*5,c:['#ffe27a','#fff6c0','#ffb030','#fff'][i%4],add:1,g:300})}rings.push({x:rx,y:ry,l:1,c:'#ffd76a',w:.8})}
   /* milestone pops */
   if(st==='fly'||st==='cashed')for(const ms of[2,5,10,20,50,100,200,500]){if(m>=ms&&!done.has(ms)){done.add(ms);if(st==='fly'){rings.push({x:rx,y:ry,l:1,c:tier(ms)[0],w:.9,txt:ms+'×'});beep(700+Math.log2(ms)*90,.14,'triangle',.5);setTimeout(()=>beep(1000+Math.log2(ms)*90,.18,'triangle',.45),110);fl=Math.max(fl,ms>=20?.35:.15)}}}
   /* particles */
   for(let i=pts.length-1;i>=0;i--){const q=pts[i];q.x+=q.vx*dt;q.y+=q.vy*dt;q.vy+=(q.g||0)*dt;q.l-=dt/q.d;if(q.l<=0){pts.splice(i,1);continue}
    if(q.k==='smoke'){g.globalAlpha=Math.max(0,q.l)*.38;g.fillStyle=q.c;g.beginPath();g.arc(q.x,q.y,q.r*(1.6-q.l*.6),0,TAU);g.fill()}
    else if(q.k==='deb'){g.globalAlpha=Math.max(0,q.l);g.save();g.translate(q.x,q.y);g.rotate(q.rot+tnow*6);g.fillStyle=q.c;g.fillRect(-4,-1.5,8,3);g.restore()}
    else{g.globalAlpha=Math.max(0,q.l);if(q.add)g.globalCompositeOperation='lighter';g.fillStyle=q.c;g.beginPath();g.arc(q.x,q.y,q.r*q.l+.8,0,TAU);g.fill();g.globalCompositeOperation='source-over'}}g.globalAlpha=1;
   for(let i=rings.length-1;i>=0;i--){const q=rings[i];q.l-=dt*(q.big?1.1:1.5);if(q.l<=0){rings.splice(i,1);continue}const r=(1-q.l)*(q.big?260:q.w*130)+8;g.strokeStyle=q.c;g.globalAlpha=q.l;g.lineWidth=q.big?6*q.l+1:4*q.l+1;g.beginPath();g.arc(q.x,q.y,r,0,TAU);g.stroke();
    if(q.txt){g.font="400 34px 'Pirata One',Georgia,serif";g.textAlign='center';g.fillStyle=q.c;g.shadowColor=q.c;g.shadowBlur=16;g.fillText(q.txt,q.x,q.y-34-(1-q.l)*40);g.shadowBlur=0}}g.globalAlpha=1;
   /* the rocket */
   if(st!=='crash'){const L=18+Math.min(34,Math.log10(Math.max(1,m))*20)+Math.random()*10;rkt(g,rx,ry,ra,st==='cashed'?1.1:1.25,flyingNow||cdOn,cdOn?14+Math.random()*10:L,now)}
   /* big readout */
   g.textAlign='center';g.textBaseline='middle';
   if(st==='cd'){const n=Math.max(1,Math.ceil(cdT*2.7)),ph=1-((cdT*2.7)%1);g.save();g.translate(Wd/2,Ht/2);g.scale(1+(1-ph)*.25,1+(1-ph)*.25);g.globalAlpha=.55+.45*ph;g.font="400 120px 'Pirata One',Georgia,serif";g.shadowColor='#ffb030';g.shadowBlur=26;g.fillStyle='#ffd76a';g.fillText(n,0,0);g.restore()}
   else{const big=m>=20&&st!=='crash',sc=1+(st==='fly'?Math.sin(now/160)*.012*(1+alt*2):0);g.save();g.translate(Wd/2,Ht/2-14);g.scale(sc,sc);g.font="400 "+(st==='idle'?118:136)+"px 'Pirata One',Georgia,serif";g.lineWidth=9;g.strokeStyle='rgba(0,0,12,.55)';const txt=(st==='idle'?1:m).toFixed(2)+'×';g.strokeText(txt,0,0);
    g.shadowColor=st==='crash'?'#ff2a40':st==='cashed'?'#ffb020':tr[1];g.shadowBlur=st==='idle'?6:30;g.fillStyle=st==='crash'?'#ff6a7a':st==='cashed'?'#ffd76a':st==='idle'?'#ffffffaa':tr[0]==='#7dffb0'?'#ffffff':tr[0];g.fillText(txt,0,0);g.restore();
    if(st==='idle'){g.font="400 30px 'Pirata One',Georgia,serif";g.fillStyle='#ffe9b0aa';g.fillText('Place a bet and press Launch',Wd/2,Ht/2+62)}
    if(st==='fly'&&m>=20){g.font="400 44px 'Pirata One',Georgia,serif";g.fillStyle=m>=100?'#ff6ae0':'#ffd76a';g.shadowColor=g.fillStyle;g.shadowBlur=22;g.globalAlpha=.7+.3*Math.sin(now/130);g.fillText(m>=100?'TO THE STARS!':'MOONSHOT!',Wd/2,Ht/2+60);g.globalAlpha=1;g.shadowBlur=0}
    if(st==='crash'){const sh=Math.max(0,1-(now-crashT)/600)*8;g.font="400 56px 'Pirata One',Georgia,serif";g.fillStyle='#ff6a7a';g.shadowColor='#ff2a40';g.shadowBlur=20;g.fillText('CRASHED',Wd/2+(Math.random()-.5)*sh,Ht/2+62);g.shadowBlur=0}
    if(st==='cashed'){g.font="400 40px 'Pirata One',Georgia,serif";g.fillStyle='#ffd76a';g.shadowColor='#ffb020';g.shadowBlur=14;g.fillText('You cashed out at '+cashM.toFixed(2)+'×',Wd/2,Ht/2+62);g.shadowBlur=0}}
   g.restore();
   /* vignette and flash */
   g.fillStyle=gR(g,Wd/2,Ht/2,Ht*.35,Wd*.62,['rgba(0,0,0,0)',st==='crash'?'rgba(120,0,16,.5)':'rgba(0,0,10,.5)']);g.fillRect(0,0,Wd,Ht);
   if(fl>0){g.fillStyle=st==='crash'?`rgba(255,200,140,${fl*.55})`:`rgba(255,240,170,${fl*.35})`;g.fillRect(0,0,Wd,Ht)}
   if(st==='fly')setLab('Cash out '+cmn(bet*m));else if(st==='cd')setLab('Get ready…');else setLab('Launch');
   $('rkg').disabled=st==='cd';
  }});
 $('rkg').onclick=launch;wireBet();CAS.key={' ':launch,enter:launch};msg('Place your bet and press Launch. Space also launches and cashes out.')}
