/* ===== RUNESTONE TOWER DEFENSE 10.0: the Clockwork Hive, art (98h, after 98a) =====
   The eleventh tower (TD_WORLDS_PLAN.md section 3): a brass beehive skep of stacked coils with honeycomb windows, on an iron stand on a
   stone pad, a hexagonal door (a honeycomb cell) with a hinged brass hatch over a landing lip, clockwork on its side (gears and a
   wind-up key) and a copper queen-bee weathervane.
   Live: the door hatch swings open when bees leave or come home (98i sets RPHV.cur, the tower being drawn, whose tw.door = 0..1 drives
   it; icons and the tier sheet flap it now and then and show two decorative bees), honey drips form at the landing lip and the comb windows, stretch, fall and splat on the pad; the side gears turn and the
   wind-up key twists; the weathervane bee swings in the wind; the comb glows in a slow pulse.
   Tiers: 1 a small brass skep, a three-legged iron stand, a wind-up key and one comb window; 2 taller, riveted brass bands, two windows,
   a side gear, a honey jar on the pad; 3 Honeycomb: honey-gold coils, big glowing comb, honey overflowing the platform, two meshing
   gears, flowers and a fallen comb chunk; 4 Royal Jelly (Mythic: violet stone, violet-iron coils with gold grooves, glowing royal
   jelly cells, violet flowers, gems, orbiting runes); 5 Queen's Court (Celestial: marble, white-gold coils, a jewelled crown on top
   where the Queen Bee perches when she is home, white lilies, wings and halo).
   Plugs into the shared 95c pipeline (RPPAL/RPLAY/RPPULSE/RPWING/RPHALO + wrapped rpBodyArt, rpGlowList, rpTowerParts), so the build
   and upgrade animations, the tier 4-5 ascension, icons and warming are the shared ones. No shadowBlur, no ctx.filter.
   API (all baked sprites; per frame only drawImage and a few short paths)
     rphvDoor(tier)                      the door (bee exit) relative to the pad centre {x,y}, in model units (97k scales by RPG.k)
     rphvPerch(tier)                     where the Queen sits on the crown (tier 5) {x,y}
     rphvBee(g,x,y,dir,tier,t,sc,a)      a mechanical bee at (x,y) (body centre), facing dir (+1 right / -1 left), wings blurring
     rphvQueen(g,x,y,dir,tier,t,sc,a,ch) the Queen Bee; ch = 0..1 burst charge (glow, wings faster)
     rphvShadow(g,x,y,s,a)               a soft shadow on the ground
     rphvPuddle(g,x,y,r,k,t,tier,seed)   a honey puddle on the road (ground layer), k = 0..1 strength
     rphvSting(g,x,y,u,tier)             the sting spark (top layer), u = 0..1
     rphvBurst(g,x,y,r,u,tier,h,part)    the Queen's sting burst, u = 0..1, h = her height above the ground point; part 0 = the ground
                                         (golden sheet, shock ring, comb cells), 1 = the air (flash, stingers), omitted = both
     rphvPollen(g,x,y,t,a,top,ph)        pollen grains spiralling up a tower buffed by Royal Jelly (top = its height)
     rphvDot(col), rphvGrainS()          a small glowing dot (pollen trails), a pollen grain sprite
   Bees and the Queen are drawn outside rpTowerDraw (in world space by 98i), so mastery skins do not recolour them. */
RPTW.hive={n:'Clockwork Hive',role:'Swarm',col:'#ffb52a'};
RPSKIN.hive=['base'];
RPPAL.hive={base:{stone:RPSTONE.base,iron:'#3c3652',ironL:'#7a7498',ironD:'#1c182c',trim:'#ffd45a',trimL:'#fff0a8',trimD:'#b07a1a',
 copper:'#e0844a',copperL:'#ffc89a',copperD:'#8a3e14',wood:'#a3683a',woodL:'#d4955c',woodD:'#5e3519',honey:'#ffb52a',honeyL:'#ffe27a',honeyD:'#c8700a',
 glow:'#ffb84a',glow2:'#ffe27a',rune:'#ffb84a',door:'#2a1206',doorL:'#6a3410'}};
/* per tier: skep radius R, height H, dome base y db, coils n, comb windows win [ph, th0, th1, half-width], gears [longitude, latitude, radius]
   (on the right side), jar, flowers, crown, top, tier 4-5 gems */
RPLAY.hive=[0,
 {R:24,H:40,db:-26,n:5,win:[[-.78,.32,.72,.34]],gears:[],jar:0,flw:0,chunk:0,top:96,runes:[]},
 {R:26,H:46,db:-29,n:6,win:[[-.8,.3,.72,.34],[.8,.3,.72,.34]],gears:[[1.3,.42,9]],jar:1,flw:0,chunk:0,top:110,runes:[]},
 {R:28,H:52,db:-32,n:7,win:[[-.82,.26,.78,.4],[.82,.26,.78,.4]],gears:[[1.3,.34,10],[1.42,.7,6.5]],jar:1,flw:1,chunk:1,top:124,runes:[]},
 {R:29,H:54,db:-33,n:7,win:[[-.82,.26,.8,.4],[.82,.26,.8,.4]],gears:[[1.3,.34,10.5],[1.42,.7,7]],jar:1,flw:1,chunk:1,top:132,runes:[],inl:[[0,-9,4.2],[-25,-14,3.4],[25,-14,3.4]]},
 {R:30,H:56,db:-34,n:7,win:[[-.82,.26,.8,.4],[.82,.26,.8,.4]],gears:[[1.3,.34,11],[1.42,.7,7.5]],jar:1,flw:1,chunk:1,crown:1,top:146,runes:[],inl:[[0,-9,4.4],[-26,-15,3.6],[26,-15,3.6]]}];
RPPULSE.hive=[2.2,.22];RPWING.hive=[36,-74];RPHALO.hive=[-150,24];
const rphvT=t=>Math.max(1,Math.min(5,t|0||1));
/* coil metal per tier [light, mid, dark, deep], groove colour, comb [honey light, honey, honey deep, empty cell], eye of the bees */
const rphvMet=tier=>tier>=5?{m:['#fffdf2','#f6e6b4','#d6aa52','#7a5a1a'],gr:'#c99a2a',band:'#ffffff',bandD:'#c99a2a',comb:['#ffffff','#fff0a0','#e0b040','#5a3c10'],wax:'#fffaf0'}
 :tier===4?{m:['#9a8ec8','#5c4e90','#30265a','#16102c'],gr:'#ffd45a',band:'#ffd45a',bandD:'#a8741a',comb:['#fbe8ff','#e08aff','#9a3ad0','#2a1040'],wax:'#f4e0ff'}
 :tier===3?{m:['#fff2b8','#ffc83a','#c47e12','#6a3c08'],gr:'#7a4208',band:'#fff0a8',bandD:'#b07a1a',comb:['#fff6c8','#ffb52a','#c8700a','#4a2406'],wax:'#fff0c0'}
 :tier===2?{m:['#ffe8a0','#e2b048','#a8701a','#5a3a10'],gr:'#5a3410',band:'#e0844a',bandD:'#8a3e14',comb:['#ffe9a0','#ffaa2a','#c06a0a','#4a2406'],wax:'#ffeec0'}
 :{m:['#ffe8a0','#d8a644','#9a6618','#5a3a10'],gr:'#5a3410',band:'#c8803a',bandD:'#7a3a10',comb:['#ffe9a0','#ffaa2a','#c06a0a','#4a2406'],wax:'#ffeec0'};
/* a point on the skep: latitude th (0 base .. PI/2 top), longitude ph (0 = facing the viewer) */
const rphvSP=(L,th,ph)=>({x:L.R*Math.cos(th)*Math.sin(ph),y:L.db+L.R*RPSQ*Math.cos(th)*Math.cos(ph)-L.H*Math.sin(th)});
function rphvDome(g,L){g.beginPath();g.ellipse(0,L.db,L.R,L.H,0,Math.PI,0);g.ellipse(0,L.db,L.R,L.R*RPSQ,0,0,Math.PI);g.closePath()}
/* the door: an arched opening at the foot of the skep, facing the viewer */
const rphvDoorG=L=>{const r=6.6+L.R*.07;return{x:0,y:L.db+L.R*RPSQ-r*.95-1.5,r}};
function rphvDoor(tier){const L=RPLAY.hive[rphvT(tier)],D=rphvDoorG(L);return{x:0,y:D.y}}
function rphvPerch(tier){const L=RPLAY.hive[rphvT(tier)];return{x:0,y:L.db-L.H-12}}
/* a flat-topped hexagon (the door is a honeycomb cell); sy squashes it about its top edge (the hinge of the flap) */
function rphvHexF(g,x,y,r,sy){const hy=y-r*.866;g.beginPath();for(let i=0;i<6;i++){const a=i*Math.PI/3,px=x+Math.cos(a)*r,py=y+Math.sin(a)*r;i?g.lineTo(px,hy+(py-hy)*sy):g.moveTo(px,hy+(py-hy)*sy)}g.closePath()}
function rphvHex(g,x,y,r){g.beginPath();for(let i=0;i<6;i++){const a=Math.PI/6+i*Math.PI/3;i?g.lineTo(x+Math.cos(a)*r,y+Math.sin(a)*r):g.moveTo(x+Math.cos(a)*r,y+Math.sin(a)*r)}g.closePath()}
/* honeycomb cells clipped to the current path: honey (glossy), capped wax, empty */
function rphvComb(g,x0,y0,x1,y1,s,M,seed,full){const dx=s*Math.sqrt(3),dy=s*1.5;let r=0;
 for(let y=y0-s;y<y1+s;y+=dy,r++)for(let x=x0-s+(r%2)*dx/2;x<x1+s;x+=dx){const q=rpR(seed+r*13.7+x*.71),k=full?(q<.7?0:q<.9?1:2):(q<.55?0:q<.8?1:2);rphvHex(g,x,y,s*.92);
  if(k===0){const gr=g.createLinearGradient(x-s,y-s,x+s*.6,y+s);gr.addColorStop(0,M.comb[0]);gr.addColorStop(.45,M.comb[1]);gr.addColorStop(1,M.comb[2]);g.fillStyle=gr}else g.fillStyle=k===1?M.wax:M.comb[3];
  g.fill();g.lineWidth=1.1;g.strokeStyle='rgba(18,8,31,.65)';g.stroke();
  if(k===0){g.fillStyle='rgba(255,255,255,.75)';g.beginPath();g.ellipse(x-s*.32,y-s*.34,s*.26,s*.16,-.5,0,TAU);g.fill()}
  else if(k===1){g.fillStyle='rgba(18,8,31,.12)';g.beginPath();g.arc(x+s*.2,y+s*.2,s*.45,0,TAU);g.fill()}}}
/* the comb window patch on the skep surface */
function rphvWinPath(g,L,w){const [ph,t0,t1,hw]=w,pts=[];for(let k=0;k<=8;k++)pts.push(rphvSP(L,t0,ph-hw+2*hw*k/8));for(let k=1;k<=6;k++)pts.push(rphvSP(L,t0+(t1-t0)*k/6,ph+hw*(1-.25*k/6)));
 for(let k=8;k>=0;k--)pts.push(rphvSP(L,t1,ph-hw*.75+1.5*hw*k/8));for(let k=5;k>0;k--)pts.push(rphvSP(L,t0+(t1-t0)*k/6,ph-hw*(1-.25*k/6)));
 g.beginPath();pts.forEach((p,i)=>i?g.lineTo(p.x,p.y):g.moveTo(p.x,p.y));g.closePath();return pts}
/* pad decorations */
function rphvJar(g,x,y,tier,M){const h=13,w=7;g.fillStyle='rgba(8,4,20,.32)';g.beginPath();g.ellipse(x+2,y+1,w+2,3.2,0,0,TAU);g.fill();
 g.beginPath();g.moveTo(x-w,y-2);g.quadraticCurveTo(x-w-1,y-h*.55,x-w+1.5,y-h);g.lineTo(x+w-1.5,y-h);g.quadraticCurveTo(x+w+1,y-h*.55,x+w,y-2);g.quadraticCurveTo(x,y+2.4,x-w,y-2);g.closePath();
 g.fillStyle=rpHG(g,x-w,x+w,M.comb[0],M.comb[1],M.comb[2]);g.fill();rpOut(g,1.8);
 g.fillStyle='rgba(255,255,255,.6)';g.beginPath();g.ellipse(x-w*.45,y-h*.55,1.3,3.6,-.1,0,TAU);g.fill();
 /* cloth lid tied with string */
 g.beginPath();g.ellipse(x,y-h,w+1.5,2.6,0,0,TAU);g.fillStyle=tier>=5?'#f4ecff':tier===4?'#b07ae0':'#d84a4a';g.fill();rpOut(g,1.4);
 g.beginPath();g.moveTo(x-w-1,y-h);g.lineTo(x-w-2.4,y-h+4.5);g.lineTo(x-w+1.4,y-h+2);g.closePath();g.fill();rpOut(g,1.1);
 g.fillStyle='rgba(255,255,255,.35)';for(const dx of [-3,1,5]){g.beginPath();g.arc(x+dx,y-h-.4,.9,0,TAU);g.fill()}
 g.strokeStyle='#f4e2c0';g.lineWidth=1.1;g.beginPath();g.moveTo(x-w,y-h+1.8);g.quadraticCurveTo(x,y-h+3.2,x+w,y-h+1.8);g.stroke();
 /* a wooden dipper leaning on it */
 g.save();g.translate(x+w-1,y-h-2);g.rotate(.55);g.beginPath();g.rect(-1.2,-9,2.4,12);g.fillStyle='#d4955c';g.fill();rpOut(g,1.1);g.beginPath();g.ellipse(0,-11,2.6,3.4,0,0,TAU);g.fillStyle=rpVG(g,-14,-8,M.comb[0],M.comb[2]);g.fill();rpOut(g,1.2);g.restore()}
function rphvFlower(g,x,y,s,c,cc,seed){g.strokeStyle=RPTO;g.lineWidth=3*s;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x-2*s,y-5*s,x+(rpR(seed)-.5)*4*s,y-10*s);g.stroke();g.strokeStyle='#5aa040';g.lineWidth=1.5*s;g.stroke();
 const fx=x+(rpR(seed)-.5)*4*s,fy=y-10*s;for(let k=0;k<5;k++){const a=k/5*TAU+seed;g.beginPath();g.ellipse(fx+Math.cos(a)*2.6*s,fy+Math.sin(a)*2.2*s,2.2*s,1.6*s,a,0,TAU);g.fillStyle=c;g.fill();g.lineWidth=.9;g.strokeStyle=RPTO;g.stroke()}
 g.beginPath();g.arc(fx,fy,1.6*s,0,TAU);g.fillStyle=cc;g.fill();g.lineWidth=.9;g.strokeStyle=RPTO;g.stroke()}
function rphvChunk(g,x,y,M){g.save();g.translate(x,y);g.rotate(-.35);const s=3.4;g.beginPath();for(const [a,b] of [[0,0],[1,0],[.5,-1],[-.5,-1],[1.5,-1],[0,-2]]){rphvHex(g,a*s*1.73,b*s*1.5,s+1.6)}
 g.fillStyle=RPTO;g.fill();for(const [a,b] of [[0,0],[1,0],[.5,-1],[-.5,-1],[1.5,-1],[0,-2]]){rphvHex(g,a*s*1.73,b*s*1.5,s*.9);g.fillStyle=rpVG(g,b*s*1.5-s,b*s*1.5+s,M.comb[0],M.comb[2]);g.fill();
  g.fillStyle='rgba(255,255,255,.6)';g.beginPath();g.arc(a*s*1.73-1,b*s*1.5-1,.9,0,TAU);g.fill()}g.restore()}

/* ---------- static body ---------- */
function rphvBodyArt(g,tier,P){const L=RPLAY.hive[tier],M=rphvMet(tier),R=L.R,db=L.db,top=db-L.H,iron=tier>=5?['#fff6dc','#e6cf98','#a88a4a']:tier===4?['#8a7ab8','#4a3c78','#22183e']:[P.ironL,P.iron,P.ironD];
 rpPadArt(g);
 /* the iron stand: a back leg, a platform disc, two splayed front legs with curled feet (tier 3+: a brace ring) */
 const pY=db+3,pr=R+4,pb=pY+5;
 const leg=(x0,y0,x1,y1,curl)=>{rpBeam(g,x0,y0,x1,y1,3.4,iron[1],iron[0]);g.beginPath();g.arc(x1+curl*2.6,y1-1,2.8,0,TAU);g.lineWidth=4.6;g.strokeStyle=RPTO;g.stroke();g.lineWidth=2;g.strokeStyle=iron[0];g.stroke()};
 leg(0,pb-pr*RPSQ*.5,0,-7,0);
 if(tier>=3){g.beginPath();g.ellipse(0,(pb+8)/2+1,pr*.92,pr*.92*RPSQ,0,.15,Math.PI-.15);g.lineWidth=4.4;g.strokeStyle=RPTO;g.stroke();g.lineWidth=2;g.strokeStyle=M.band;g.stroke()}
 for(const k of [-1,1])leg(k*pr*.62,pb+pr*RPSQ*.7,k*(pr*.92+4),10,k);
 rpTube(g,0,pb,pr,pr,5,iron[0],iron[1],iron[2],2.2);rpCap(g,0,pY,pr,iron[0],iron[2],2.2);
 if(tier>=2)for(let i=0;i<7;i++){const a=(i+.5)/7*Math.PI;rpRiv(g,Math.cos(a)*pr*.97,pb-2.5+Math.sin(a)*pr*RPSQ,1.3,M.band)}
 /* honey overflowing the platform rim (tier 3+) */
 if(tier>=3)for(const [x,l] of [[-pr*.55,9],[pr*.2,13],[pr*.7,7]]){const y=pb+Math.sqrt(Math.max(0,1-(x/pr)**2))*pr*RPSQ-1;g.beginPath();g.moveTo(x-3.4,y-2);g.lineTo(x-2.2,y+l-3);g.arc(x,y+l-3,2.4,Math.PI,0,true);g.lineTo(x+3.4,y-2);g.closePath();
  g.fillStyle=rpVG(g,y-2,y+l,M.comb[1],M.comb[2]);g.fill();rpOut(g,1.4);g.fillStyle='rgba(255,255,255,.55)';g.beginPath();g.ellipse(x-.9,y+l-4,.8,1.6,0,0,TAU);g.fill()}
 /* the wind-up key on the left side (turned live) sits behind the skep: just its socket here */
 /* the skep */
 rphvDome(g,L);g.fillStyle=rpHG(g,-R,R,M.m[0],M.m[1],M.m[2]);g.fill();
 g.save();rphvDome(g,L);g.clip();
 /* coils: a rope highlight along each band, a dark groove under it */
 const n=L.n,thA=k=>k/n*1.5;
 for(let k=0;k<n;k++){const ta=thA(k),tb=thA(k+1),tm=(ta+tb)/2,cy=db-L.H*Math.sin(tm),rr=R*Math.cos(tm),bw=L.H*(Math.sin(tb)-Math.sin(ta));
  g.beginPath();g.ellipse(0,cy,rr+.5,(rr+.5)*RPSQ,0,0,Math.PI);g.lineWidth=bw*.62;g.strokeStyle=rpA(M.m[0],.42);g.stroke();
  g.beginPath();g.ellipse(-rr*.18,cy-bw*.18,rr*.55,rr*.55*RPSQ,0,.35,Math.PI-.6);g.lineWidth=bw*.22;g.strokeStyle='rgba(255,255,255,.45)';g.stroke();
  const ty=db-L.H*Math.sin(tb),tr=R*Math.cos(tb);g.beginPath();g.ellipse(0,ty,tr,tr*RPSQ,0,0,Math.PI);g.lineWidth=2.6;g.strokeStyle=rpA(RPTO,.55);g.stroke();g.lineWidth=1.1;g.strokeStyle=M.gr;g.stroke()}
 /* riveted brass band (tier 2+) */
 if(tier>=2){const tb=thA(2),cy=db-L.H*Math.sin(tb)+1,rr=R*Math.cos(tb)+.6;g.beginPath();g.ellipse(0,cy,rr,rr*RPSQ,0,0,Math.PI);g.lineWidth=5.2;g.strokeStyle=RPTO;g.stroke();g.lineWidth=3.4;g.strokeStyle=M.band;g.stroke();
  g.lineWidth=1;g.strokeStyle='rgba(255,255,255,.55)';g.beginPath();g.ellipse(0,cy-1,rr,rr*RPSQ,0,.4,Math.PI-.4);g.stroke();
  for(let i=1;i<8;i++){const a=i/8*Math.PI;rpRiv(g,Math.cos(a)*rr,cy+Math.sin(a)*rr*RPSQ,1.2,M.bandD)}}
 /* shading: highlight upper left, shadow on the right */
 g.fillStyle='rgba(255,255,255,.2)';g.beginPath();g.ellipse(-R*.45,top+L.H*.38,R*.24,L.H*.26,-.35,0,TAU);g.fill();
 const q=g.createLinearGradient(-R,0,R,0);q.addColorStop(0,'rgba(18,8,31,0)');q.addColorStop(.6,'rgba(18,8,31,0)');q.addColorStop(1,'rgba(18,8,31,.36)');g.fillStyle=q;g.fillRect(-R,top-2,R*2,L.H+R);
 g.restore();
 /* comb windows: honeycomb behind a brass frame */
 for(const w of L.win){if(Math.abs(w[0])>1.2)continue;g.save();const pts=rphvWinPath(g,L,w);g.fillStyle=M.comb[3];g.fill();g.clip();let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;for(const p of pts){x0=Math.min(x0,p.x);y0=Math.min(y0,p.y);x1=Math.max(x1,p.x);y1=Math.max(y1,p.y)}
  rphvComb(g,x0,y0,x1,y1,tier>=3?3.3:3,M,(w[0]>0?7:3)+tier,tier>=3);g.fillStyle='rgba(18,8,31,.18)';g.fillRect(x0-2,y0-2,x1-x0+4,4);g.restore();
  rphvWinPath(g,L,w);g.lineWidth=4.6;g.strokeStyle=RPTO;g.stroke();g.lineWidth=2.4;g.strokeStyle=M.band;g.stroke();g.lineWidth=.9;g.strokeStyle='rgba(255,255,255,.5)';g.stroke();
  if(tier>=2){const a=rphvSP(L,w[1],w[0]-w[3]),b=rphvSP(L,w[1],w[0]+w[3]),c=rphvSP(L,w[2],w[0]);for(const p of [a,b,c])rpRiv(g,p.x,p.y,1.4,M.band)}}
 rphvDome(g,L);rpOut(g,2.6);
 /* the door: a hexagonal opening (a honeycomb cell) with a warm glow inside, a riveted brass frame and a landing lip */
 const D=rphvDoorG(L);rphvHexF(g,0,D.y,D.r+3,1);g.fillStyle=rpVG(g,D.y-D.r,D.y+D.r,M.band,M.bandD);g.fill();rpOut(g,2.2);
 for(let i=0;i<6;i++){const a=i*Math.PI/3;rpRiv(g,Math.cos(a)*(D.r+1.5),D.y+Math.sin(a)*(D.r+1.5),1,M.band)}
 rphvHexF(g,0,D.y,D.r,1);const dg=g.createRadialGradient(0,D.y+2,1,0,D.y,D.r*1.2);dg.addColorStop(0,'#ffd27a');dg.addColorStop(.4,'#c86a18');dg.addColorStop(1,P.door);g.fillStyle=dg;g.fill();rpOut(g,1.8);
 {const y=D.y+D.r*.866+2.2,w=D.r+4.5;g.beginPath();g.moveTo(-w,y);g.quadraticCurveTo(-w*.8,y+6.5,0,y+6.8);g.quadraticCurveTo(w*.8,y+6.5,w,y);g.closePath();g.fillStyle=rpVG(g,y,y+7,M.m[1],M.m[3]);g.fill();rpOut(g,1.6);
  g.beginPath();g.ellipse(0,y,w,2.3,0,0,TAU);g.fillStyle=rpHG(g,-w,w,M.m[0],M.m[1],M.m[2]);g.fill();rpOut(g,1.6);
  for(const [x,l] of [[-w*.5,4],[w*.45,6]]){const yy=y+Math.sqrt(Math.max(0,1-(x/w)**2))*6.4;g.beginPath();g.moveTo(x-1.8,yy-1);g.lineTo(x-1.2,yy+l-1.4);g.arc(x,yy+l-1.4,1.3,Math.PI,0,true);g.lineTo(x+1.8,yy-1);g.closePath();g.fillStyle=M.comb[1];g.fill();rpOut(g,1)}}
 /* gear hubs on the right side (the gears turn live) */
 for(const [ph,th,r] of L.gears){const p=rphvSP(L,th,ph);g.beginPath();g.arc(p.x+r*.25,p.y,2.6,0,TAU);g.fillStyle=M.bandD;g.fill();rpOut(g,1.2)}
 /* top: the weathervane rod, a copper ball and the compass cross; tier 5: a jewelled crown */
 if(!L.crown){const y0=top+1;g.strokeStyle=RPTO;g.lineWidth=3.6;g.beginPath();g.moveTo(0,y0);g.lineTo(0,y0-17);g.stroke();g.strokeStyle=P.copper;g.lineWidth=1.8;g.stroke();
  g.beginPath();g.arc(0,y0-1,3.6,0,TAU);g.fillStyle=rpHG(g,-3.6,3.6,P.copperL,P.copper,P.copperD);g.fill();rpOut(g,1.4);
  const cy=y0-8;g.strokeStyle=RPTO;g.lineWidth=3;g.beginPath();g.moveTo(-7,cy);g.lineTo(7,cy);g.moveTo(-2.4,cy+2.8);g.lineTo(2.4,cy-2.8);g.stroke();g.strokeStyle=P.copper;g.lineWidth=1.3;g.stroke();
  for(const [x,y] of [[-7,cy],[7,cy],[-2.4,cy+2.8],[2.4,cy-2.8]]){g.beginPath();g.arc(x,y,1.5,0,TAU);g.fillStyle=P.copperL;g.fill();g.lineWidth=.9;g.strokeStyle=RPTO;g.stroke()}}
 else{const y=top+2;g.beginPath();g.ellipse(0,y,9,3.4,0,0,TAU);g.fillStyle='#e0b040';g.fill();rpOut(g,1.6);
  g.beginPath();g.moveTo(-12,y-2);g.lineTo(-13.5,y-13);g.lineTo(-7,y-7);g.lineTo(-3.5,y-16);g.lineTo(0,y-8);g.lineTo(3.5,y-16);g.lineTo(7,y-7);g.lineTo(13.5,y-13);g.lineTo(12,y-2);g.quadraticCurveTo(0,y+2.5,-12,y-2);g.closePath();
  g.fillStyle=rpHG(g,-13,13,'#fffbe6','#ffe27a','#c99a2a');g.fill();rpOut(g,1.8);
  g.beginPath();g.moveTo(-12,y-4.5);g.quadraticCurveTo(0,y-.4,12,y-4.5);g.lineWidth=2.6;g.strokeStyle='#c99a2a';g.stroke();
  for(const [x,yy,c] of [[-13.5,y-13,'#ff8aa8'],[-3.5,y-16,'#7ad8ff'],[3.5,y-16,'#8affb4'],[13.5,y-13,'#ff8aa8']]){g.beginPath();g.arc(x,yy,1.7,0,TAU);g.fillStyle=c;g.fill();g.lineWidth=1;g.strokeStyle=RPTO;g.stroke()}
  rpGemArt(g,0,y-4,2.4,{a:'#c08aff',aL:'#ffffff',aD:'#6a2ab0'})}
 /* pad decorations: honey jar (tier 2+), flowers and a fallen comb chunk (tier 3+) */
 if(L.flw){const fc=tier>=5?['#ffffff','#ffe27a']:tier===4?['#c08aff','#ffe27a']:['#ffe46a','#ff7a3a'],fc2=tier>=5?['#bfe8ff','#ffffff']:tier===4?['#ff8ad8','#fff0a8']:['#ffffff','#ffb02a'];
  rphvFlower(g,40,14,1,fc[0],fc[1],1);rphvFlower(g,34,20,.85,fc2[0],fc2[1],2);rphvFlower(g,-42,10,.8,fc2[0],fc2[1],3)}
 if(L.chunk)rphvChunk(g,22,22,M);
 if(L.jar)rphvJar(g,-30,22,tier,M);
 if(tier>=4)rpAscArt(g,'hive',tier,P,L)}
{const b0=rpBodyArt;rpBodyArt=function(g,type,tier,P){if(type==='hive')return rphvBodyArt(g,tier,P);return b0.apply(this,arguments)}}
{const l0=rpGlowList;rpGlowList=function(type,tier,P,L){if(type!=='hive')return l0.apply(this,arguments);const G=[],A=(x,y,rx,ry,c,a)=>G.push([x,y,rx,ry,c,a]),M=rphvMet(tier),D=rphvDoorG(L);
 A(0,D.y,16,16,P.glow,.75);for(const w of L.win){const p=rphvSP(L,(w[1]+w[2])/2,w[0]);A(p.x,p.y,15,15,M.comb[1],.6)}
 if(L.crown)A(0,L.db-L.H-8,18,16,'#fff0a0',.7);
 if(tier>=4){const A4=RPASC[tier];for(const [x,y,z] of L.inl)A(x,y,z*3.4,z*3.4,A4.glow,.85);A(0,-L.top*.5,46,L.top*.5,A4.glow,.16)}return G}}

/* ---------- live parts ---------- */
/* a gear: teeth, spokes, a hub (baked per tier and size, turned live) */
function rphvGearArt(g,r,M){const n=Math.max(7,Math.round(r*1.1));g.beginPath();for(let i=0;i<n*2;i++){const a=i/(n*2)*TAU,q=i%2?r:r+2.2;g.lineTo(Math.cos(a-.12)*q,Math.sin(a-.12)*q);g.lineTo(Math.cos(a+.12)*q,Math.sin(a+.12)*q)}g.closePath();
 g.fillStyle=rpHG(g,-r,r,M.m[0],M.m[1],M.m[2]);g.fill();rpOut(g,1.6);g.beginPath();g.arc(0,0,r*.62,0,TAU);g.fillStyle=M.m[2];g.fill();g.lineWidth=1;g.strokeStyle=RPTO;g.stroke();
 for(let i=0;i<4;i++){const a=i*Math.PI/2;g.beginPath();g.moveTo(Math.cos(a)*r*.2,Math.sin(a)*r*.2);g.lineTo(Math.cos(a)*r*.62,Math.sin(a)*r*.62);g.lineWidth=2.6;g.strokeStyle=RPTO;g.stroke();g.lineWidth=1.3;g.strokeStyle=M.m[1];g.stroke()}
 g.beginPath();g.arc(0,0,r*.24,0,TAU);g.fillStyle=M.band;g.fill();rpOut(g,1.2);g.fillStyle='rgba(255,255,255,.7)';g.beginPath();g.arc(-r*.08,-r*.08,r*.08,0,TAU);g.fill()}
const rphvGearS=(tier,r)=>rpSpr('hv|gr|'+tier+'|'+r,-r-4,-r-4,2*r+8,2*r+8,g=>rphvGearArt(g,r,rphvMet(tier)));
/* the wind-up key: a butterfly key seen side on (spun live by scaling it horizontally) */
function rphvKeyArt(g,M){g.beginPath();g.rect(-1.4,-1,2.8,8);g.fillStyle=M.m[1];g.fill();rpOut(g,1.2);
 for(const k of [-1,1]){g.beginPath();g.ellipse(k*5,-3,5,4,0,0,TAU);g.fillStyle=rpHG(g,k*5-5,k*5+5,M.m[0],M.m[1],M.m[2]);g.fill();rpOut(g,1.5);g.beginPath();g.ellipse(k*5,-3,1.8,1.4,0,0,TAU);g.fillStyle=M.m[3];g.fill()}}
const rphvKeyS=tier=>rpSpr('hv|key|'+tier,-12,-9,24,18,g=>rphvKeyArt(g,rphvMet(tier)));
/* the weathervane: a copper queen bee riding an arrow (seen side on; spun live) */
function rphvVaneArt(g,P){g.strokeStyle=RPTO;g.lineWidth=3.2;g.beginPath();g.moveTo(-15,0);g.lineTo(13,0);g.stroke();g.strokeStyle=P.copper;g.lineWidth=1.5;g.stroke();
 g.beginPath();g.moveTo(17,0);g.lineTo(11,-3.6);g.lineTo(12,0);g.lineTo(11,3.6);g.closePath();g.fillStyle=P.copperL;g.fill();rpOut(g,1.2);
 g.beginPath();g.moveTo(-16,0);g.lineTo(-20,-5);g.lineTo(-12,-1);g.lineTo(-12,1);g.lineTo(-20,5);g.closePath();g.fillStyle=P.copper;g.fill();rpOut(g,1.2);
 /* the bee: abdomen, stripes, head, wings */
 g.beginPath();g.ellipse(-3,-5,6,3.8,-.1,0,TAU);g.fillStyle=rpVG(g,-9,-1,P.copperL,P.copperD);g.fill();rpOut(g,1.4);
 g.strokeStyle=P.copperD;g.lineWidth=1.2;for(const x of [-5,-2]){g.beginPath();g.moveTo(x,-8.6);g.lineTo(x+.6,-1.4);g.stroke()}
 g.beginPath();g.arc(4,-5.6,2.8,0,TAU);g.fillStyle=P.copper;g.fill();rpOut(g,1.3);
 g.beginPath();g.ellipse(-1,-11,5,2.6,-.5,0,TAU);g.fillStyle=P.copperL;g.fill();rpOut(g,1.2);
 g.strokeStyle=RPTO;g.lineWidth=1;g.beginPath();g.moveTo(5,-8);g.lineTo(7,-11);g.stroke()}
const rphvVaneS=()=>rpSpr('hv|vane',-22,-15,42,22,g=>rphvVaneArt(g,RPPAL.hive.base));
/* honey drip cycle at (x,y): forms, stretches, falls to fy and splats; u = 0..1 */
function rphvDrip(g,x,y,fy,u,c,cd,s){s=s||1;if(u<.55){const k=u/.55,r=(1.2+1.6*k)*s,l=(1+5*k*k)*s;g.beginPath();g.moveTo(x-r*.8,y);g.quadraticCurveTo(x-r,y+l,x,y+l+r);g.quadraticCurveTo(x+r,y+l,x+r*.8,y);g.closePath();
  g.fillStyle=c;g.fill();g.lineWidth=1;g.strokeStyle=RPTO;g.stroke();g.fillStyle='rgba(255,255,255,.65)';g.beginPath();g.arc(x-r*.35,y+l*.6,r*.3,0,TAU);g.fill();return}
 if(u<.78){const k=(u-.55)/.23,yy=y+6*s+(fy-y-6*s)*k*k,r=2.4*s;g.beginPath();g.moveTo(x,yy-r*2.2);g.quadraticCurveTo(x+r,yy-r*.2,x,yy+r);g.quadraticCurveTo(x-r,yy-r*.2,x,yy-r*2.2);g.closePath();g.fillStyle=c;g.fill();g.lineWidth=1;g.strokeStyle=RPTO;g.stroke();return}
 const k=(u-.78)/.22,rr=(2+6*k)*s;g.globalAlpha*=1-k;g.beginPath();g.ellipse(x,fy,rr,rr*.38,0,0,TAU);g.fillStyle=cd;g.fill();g.lineWidth=1;g.strokeStyle=RPTO;g.stroke()}
function rphvLive(g,tier,P,t,o,L,ph){const M=rphvMet(tier),lt=RPFX.lite,tw=RPHV.cur&&RPHV.cur.type==='hive'?RPHV.cur:null,D=rphvDoorG(L),ga=RPGA;
 /* the wind-up key on the left (behind the skep edge), twisting */
 {const p=rphvSP(L,.42,-1.35),sp=Math.cos(t*2.4+ph*5);g.save();g.translate(p.x-3,p.y);g.rotate(-1.25);g.scale(Math.abs(sp)<.12?.12:sp,1);g.globalAlpha=ga;rpPut(g,rphvKeyS(tier));g.restore()}
 /* gears */
 L.gears.forEach(([gp,th,r],i)=>{const p=rphvSP(L,th,gp);g.save();g.translate(p.x+r*.25,p.y);g.rotate((i%2?-1:1)*t*(i?1.6:1)+ph+(i?.3:0));g.globalAlpha=ga;rpPut(g,rphvGearS(tier,r));g.restore()});
 /* the comb breathes: a soft honey glow over the windows */
 g.globalCompositeOperation='lighter';for(const w of L.win){const p=rphvSP(L,(w[1]+w[2])/2,w[0]);rpGlow(g,p.x,p.y,12,12,M.comb[0],.18+.14*Math.sin(t*2+ph*3+w[0]))}g.globalCompositeOperation='source-over';g.globalAlpha=ga;
 /* the door flap: a brass hex hatch hinged along its top edge; open = swung up and out (seen edge-on, then from below) */
 {const op=tw?Math.max(0,Math.min(1,tw.door||0)):Math.pow(Math.max(0,Math.sin(t*1.3+ph*4)),14)*.6,c=Math.cos(op*1.6),r=D.r+.6;
  if(op>.04){g.globalCompositeOperation='lighter';rpGlow(g,0,D.y,13+op*7,12+op*6,'#ffb84a',.6*op);g.globalCompositeOperation='source-over';g.globalAlpha=ga}
  rphvHexF(g,0,D.y,r,c);g.fillStyle=c>0?rpHG(g,-r,r,M.m[0],M.m[1],M.m[2]):rpHG(g,-r,r,M.m[1],M.m[2],M.m[3]);g.fill();rpOut(g,1.5);
  if(c>.35){rphvHexF(g,0,D.y-r*.866*(1-c)*.5,r*.48,c);g.lineWidth=1;g.strokeStyle=rpA(RPTO,.5);g.stroke();rpRiv(g,0,D.y-r*.866+r*.866*c*1.55,1.1,M.band)}
  g.beginPath();g.rect(-r*.55,D.y-r*.866-1.3,r*1.1,2.6);g.fillStyle=M.bandD;g.fill();rpOut(g,1)}
 /* honey drips: from the landing board and the comb windows */
 if(!lt){const per=2.6,dr=[[D.r*.45,D.y+D.r*.866+8.4,8]];for(const w of L.win)if(tier>=2){const p=rphvSP(L,w[1],w[0]);dr.push([p.x,p.y+1,Math.min(14,L.db+L.R*RPSQ+6-p.y)])}
  dr.forEach(([x,y,f],i)=>{if(i>tier)return;const u=((t+ph*3+i*.87)/per)%1;g.save();rphvDrip(g,x,y,y+f,u,M.comb[1],M.comb[2],.85+.1*tier);g.restore();g.globalAlpha=ga})}
 /* the weathervane bee swings with the wind; tier 5: the Queen sits on her crown when she is home */
 if(!L.crown){const y=L.db-L.H-16,a=Math.sin(t*.6+ph*2)*.55+Math.sin(t*1.9+ph)*.12,s=Math.cos(a);g.save();g.translate(0,y);g.scale((Math.abs(s)<.15?.15*Math.sign(s||1):s)*.78,.78);g.globalAlpha=ga;rpPut(g,rphvVaneS());g.restore();
  g.beginPath();g.arc(0,y,1.8,0,TAU);g.fillStyle=P.copperL;g.fill();g.lineWidth=1;g.strokeStyle=RPTO;g.stroke()}
 else{const q=rphvPerch(tier),home=tw?tw.qHome!==0:true;
  g.globalCompositeOperation='lighter';rpGlow(g,q.x,q.y+4,22,16,'#fff0a0',home?.35+.1*Math.sin(t*2+ph):.7+.25*Math.sin(t*5));g.globalCompositeOperation='source-over';g.globalAlpha=ga;
  if(home)rphvQueen(g,q.x,q.y-2+Math.sin(t*1.4+ph)*.8,Math.sin(t*.4+ph)>-.2?1:-1,tier,t*.18,.9,ga,0,1)}
 /* icons and the tier sheet: two decorative bees in a figure eight around the skep */
 if(!tw&&!lt){for(let i=0;i<2;i++){const a=t*1.4+ph+i*Math.PI,x=Math.sin(a)*L.R*1.45,y=L.db-L.H*.55+Math.sin(2*a)*9,d=Math.cos(a)>=0?1:-1;rphvBee(g,x,y,d,tier,t+i,.85,ga)}}
 g.globalAlpha=ga}
{const p0=rpTowerParts;rpTowerParts=function(g,type,tier,skin,t,o,nopad){if(type!=='hive')return p0.apply(this,arguments);
 const P=rpPalT(type,skin,tier),L=RPLAY[type][tier],ph=o.ph||0;
 if(tier>=4){if(!nopad)rpAscGround(g,tier,t,ph,1);rpAscLive(g,type,tier,t,ph,L,0)}
 g.globalAlpha=RPGA;rpPut(g,nopad?rpBody(type,tier,skin):rpBack(type,tier,skin));
 {const q=RPPULSE[type];g.globalCompositeOperation='lighter';g.globalAlpha=RPGA*(1-q[1]+q[1]*Math.sin(t*q[0]+ph*7));rpPut(g,rpGlowLayer(type,tier,skin));g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}
 if(!nopad){const u=((t+ph*2.3)*.28)%1;if(u<.12){const v=u/.12*tier,i=Math.min(tier-1,v|0);g.globalCompositeOperation='lighter';rpGlow(g,(i-(tier-1)/2)*10,RPPIPY-1,8,8,'#fff6c8',Math.sin(Math.PI*(v-i))*.95);g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}}
 rphvLive(g,tier,P,t,o,L,ph);
 if(tier>=4)rpAscLive(g,type,tier,t,ph,L,1);
 g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}}
{const w0=rpTowerWarm;rpTowerWarm=function(type,tier,skin){const r=w0.apply(this,arguments);if(type==='hive'){tier=rphvT(tier);try{const L=RPLAY.hive[tier];for(const g of L.gears)rphvGearS(tier,g[2]);rphvKeyS(tier);rphvVaneS();rphvBeeS(tier);rphvWingS(tier,0);rphvWingS(tier,1);if(tier>=5){rphvQueenS(tier);rphvQWingS(0);rphvQWingS(1)}if(tier>=3)for(let v=0;v<3;v++)rphvPudS(tier,v)}catch(e){}}return r}}
/* the tower being drawn (set by the battle module around rpTowerAt), so the door and the Queen follow the battle */
const RPHV={cur:null};

/* ---------- bees ---------- */
/* colours per tier: body [light, mid, dark], stripe, eye, wing tint */
const rphvBeeC=tier=>tier>=5?{b:['#fffdf2','#ffe9a6','#d8aa48'],s:'#c99a2a',eye:'#7ae8ff',wing:'#f4fbff',th:'#f6e6b4'}
 :tier===4?{b:['#e8d6ff','#a66cff','#5a2aa0'],s:'#ffd45a',eye:'#ff8ad8',wing:'#f0e4ff',th:'#5c4e90'}
 :tier===3?{b:['#fff2b8','#ffc83a','#c47e12'],s:'#2a1a10',eye:'#7ae8ff',wing:'#e8fbff',th:'#a8701a'}
 :tier===2?{b:['#ffe0a0','#e8a83a','#a8601a'],s:'#4a2210',eye:'#7ae8ff',wing:'#e8fbff',th:'#d0702a'}
 :{b:['#ffe8a0','#e2b048','#a8701a'],s:'#2a1a10',eye:'#7ae8ff',wing:'#e8fbff',th:'#8a5a1a'};
/* a mechanical bee facing right, body centre at 0,0 (about 20 units long) */
function rphvBeeArt(g,tier){const C=rphvBeeC(tier);
 /* stinger */
 g.beginPath();g.moveTo(-14,1.2);g.lineTo(-8,-.6);g.lineTo(-8,3);g.closePath();g.fillStyle='#d8e0f0';g.fill();g.lineWidth=1.2;g.strokeStyle=RPTO;g.stroke();
 /* legs */
 g.strokeStyle=RPTO;g.lineWidth=1.3;for(const [x,d] of [[0,-1.5],[2.6,.4],[5,1.8]]){g.beginPath();g.moveTo(x,3);g.lineTo(x+d-1,7);g.lineTo(x+d+.6,7.6);g.stroke()}
 /* abdomen with stripes */
 g.beginPath();g.ellipse(-4.2,.8,7.2,5.4,-.08,0,TAU);g.fillStyle=rpVG(g,-5,6,C.b[0],C.b[2]);g.fill();
 g.save();g.clip();g.fillStyle=C.s;for(const x of [-8.6,-4.6,-.8])g.fillRect(x,-6,2.2,14);g.fillStyle='rgba(255,255,255,.4)';g.beginPath();g.ellipse(-5,-2.4,4.6,1.6,-.1,0,TAU);g.fill();g.restore();
 g.beginPath();g.ellipse(-4.2,.8,7.2,5.4,-.08,0,TAU);rpOut(g,1.7);
 /* thorax: a brass ball with a rivet */
 g.beginPath();g.arc(3,-.2,4.2,0,TAU);g.fillStyle=rpHG(g,-1,7,C.b[0],C.th,C.b[2]);g.fill();rpOut(g,1.6);rpRiv(g,2.4,-1.4,1,C.b[0]);
 /* head and its lens eye */
 g.beginPath();g.arc(8.2,.6,3.4,0,TAU);g.fillStyle=rpHG(g,5,11.6,'#6a6488','#34304a','#16121f');g.fill();rpOut(g,1.5);
 g.beginPath();g.arc(9.2,-.1,1.9,0,TAU);g.fillStyle=C.eye;g.fill();g.lineWidth=.8;g.strokeStyle=RPTO;g.stroke();g.fillStyle='#ffffff';g.beginPath();g.arc(8.7,-.7,.7,0,TAU);g.fill();
 /* antennae */
 g.strokeStyle=RPTO;g.lineWidth=1.1;g.beginPath();g.moveTo(8.4,-2.4);g.quadraticCurveTo(9.6,-6.4,12.4,-6.8);g.moveTo(7,-2.4);g.quadraticCurveTo(7.4,-6.6,9.6,-7.8);g.stroke();
 for(const [x,y] of [[12.4,-6.8],[9.6,-7.8]]){g.beginPath();g.arc(x,y,1.2,0,TAU);g.fillStyle=C.b[1];g.fill();g.lineWidth=.8;g.strokeStyle=RPTO;g.stroke()}
 /* the wind-up key on its back (tiers 1-3); a gem (4); a star (5) */
 if(tier<=3){g.strokeStyle=RPTO;g.lineWidth=2.2;g.beginPath();g.moveTo(-4,-4.2);g.lineTo(-4,-7);g.stroke();g.strokeStyle=C.b[0];g.lineWidth=1;g.stroke();
  for(const k of [-1,1]){g.beginPath();g.ellipse(-4+k*2.2,-8.2,2,1.4,0,0,TAU);g.fillStyle=C.b[1];g.fill();g.lineWidth=.9;g.strokeStyle=RPTO;g.stroke()}}
 else if(tier===4)rpGemArt(g,-4,-5,1.6,{a:'#ffd45a',aL:'#ffffff',aD:'#b07a1a'});
 else{g.fillStyle='#ffffff';g.beginPath();for(let i=0;i<8;i++){const a=i*Math.PI/4-Math.PI/2,r=i%2?1:3;g.lineTo(-4+Math.cos(a)*r,-5.4+Math.sin(a)*r)}g.closePath();g.fill();g.lineWidth=.7;g.strokeStyle='#c99a2a';g.stroke()}}
const rphvBeeS=tier=>rpSpr('hv|bee|'+rphvT(tier),-16,-11,32,21,g=>rphvBeeArt(g,rphvT(tier)));
/* wings: two long glassy wings rooted on the thorax, swept up and back; frame 0 raised, 1 lowered (drawn alternately: the blur) */
function rphvWingDraw(g,x,y,sets,tint,vein){for(const [a,l,w,al] of sets){g.save();g.translate(x,y);g.rotate(a);g.beginPath();g.moveTo(0,0);g.bezierCurveTo(l*.3,-w*1.25,l*.95,-w*1.1,l,0);g.bezierCurveTo(l*.9,w*.9,l*.3,w*.8,0,0);g.closePath();
  g.fillStyle=rpA(tint,al);g.fill();g.lineWidth=1.1;g.strokeStyle=rpA(RPTO,.85);g.stroke();
  g.strokeStyle=rpA(vein,.9);g.lineWidth=.8;g.beginPath();g.moveTo(1,0);g.quadraticCurveTo(l*.5,-w*.3,l*.86,-w*.1);g.moveTo(l*.42,-w*.25);g.lineTo(l*.62,w*.45);g.stroke();
  g.fillStyle='rgba(255,255,255,.75)';g.beginPath();g.ellipse(l*.55,-w*.45,l*.18,w*.18,0,0,TAU);g.fill();g.restore()}}
function rphvWingArt(g,tier,f){const C=rphvBeeC(tier);rphvWingDraw(g,1.5,-3.8,f?[[-2.62,12,3.4,.5],[-2.86,10.5,3,.62]]:[[-2.02,13,3.6,.5],[-2.32,11.5,3.2,.62]],C.wing,tier>=4?'#ffffff':'#bfefff')}
const rphvWingS=(tier,f)=>rpSpr('hv|wg|'+rphvT(tier)+'|'+f,-15,-19,22,21,g=>rphvWingArt(g,rphvT(tier),f));
function rphvBee(g,x,y,dir,tier,t,sc,a){tier=rphvT(tier);const s=sc||1,sx=dir<0?-s:s,a0=g.globalAlpha,al=a==null?1:a,f=Math.floor(t*38)%2;
 /* no save/restore (many bees a frame): translate and scale, then undo them */
 g.translate(x,y);g.scale(sx,s);g.globalAlpha=al;rpPut(g,rphvBeeS(tier));
 /* the wing blur: the two wing poses drawn faintly over each other, the current one stronger */
 g.globalAlpha=al*.45;rpPut(g,rphvWingS(tier,1-f));g.globalAlpha=al*.9;rpPut(g,rphvWingS(tier,f));g.scale(1/sx,1/s);g.translate(-x,-y);g.globalAlpha=a0}
function rphvShadow(g,x,y,s,a){g.fillStyle=`rgba(8,4,20,${(.26*a).toFixed(3)})`;g.beginPath();g.ellipse(x,y,7*s,2.8*s,0,0,TAU);g.fill()}
/* the Queen Bee (tier 5): a long royal abdomen, a crown, a sceptre stinger; about twice a bee */
function rphvQueenArt(g){const C={b:['#fffdf2','#ffe27a','#c99a2a'],s:'#7a3ab0',eye:'#7ae8ff'};
 g.beginPath();g.moveTo(-27,3);g.lineTo(-17,-1);g.lineTo(-17,6.4);g.closePath();g.fillStyle=rpVG(g,-2,7,'#ffffff','#c8d0e8');g.fill();rpOut(g,1.4);
 g.strokeStyle=RPTO;g.lineWidth=1.6;for(const [x,d] of [[1,-2],[5,0],[9,2]]){g.beginPath();g.moveTo(x,5);g.lineTo(x+d-1.5,11);g.lineTo(x+d+1,12);g.stroke()}
 g.beginPath();g.ellipse(-8,2,12,8,-.06,0,TAU);g.fillStyle=rpVG(g,-6,10,C.b[0],C.b[2]);g.fill();
 g.save();g.clip();g.fillStyle=C.s;for(const x of [-16,-10,-4])g.fillRect(x,-8,3.2,20);g.fillStyle='#ffd45a';for(const x of [-12.6,-6.6])g.fillRect(x,-8,1,20);g.fillStyle='rgba(255,255,255,.45)';g.beginPath();g.ellipse(-9,-3.4,7,2.2,-.08,0,TAU);g.fill();g.restore();
 g.beginPath();g.ellipse(-8,2,12,8,-.06,0,TAU);rpOut(g,2);
 g.beginPath();g.arc(5,0,6.4,0,TAU);g.fillStyle=rpHG(g,-1,11,'#ffffff','#f6e6b4','#c99a2a');g.fill();rpOut(g,1.8);
 /* a little royal cape of fur at the neck */
 g.beginPath();g.arc(9.4,1,5,Math.PI*.6,Math.PI*1.75);g.lineWidth=3.6;g.strokeStyle='#ffffff';g.stroke();g.lineWidth=1;g.strokeStyle=RPTO;g.stroke();
 g.beginPath();g.arc(12.6,1.4,4.6,0,TAU);g.fillStyle=rpHG(g,8,17,'#7a64a0','#3e2c58','#1c1030');g.fill();rpOut(g,1.6);
 g.beginPath();g.arc(13.8,.6,2.4,0,TAU);g.fillStyle=C.eye;g.fill();g.lineWidth=.9;g.strokeStyle=RPTO;g.stroke();g.fillStyle='#ffffff';g.beginPath();g.arc(13.2,-.1,.9,0,TAU);g.fill();
 g.strokeStyle=RPTO;g.lineWidth=1.3;g.beginPath();g.moveTo(13.6,-3);g.quadraticCurveTo(16,-8,19,-8.4);g.stroke();g.beginPath();g.arc(19,-8.4,1.4,0,TAU);g.fillStyle='#ffe27a';g.fill();g.lineWidth=.9;g.stroke();
 /* crown */
 g.beginPath();g.moveTo(8.4,-3);g.lineTo(8,-10);g.lineTo(10.6,-6.6);g.lineTo(12.4,-11.6);g.lineTo(14.2,-6.6);g.lineTo(16.6,-10);g.lineTo(16.2,-3);g.closePath();g.fillStyle=rpHG(g,8,17,'#fffbe6','#ffe27a','#c99a2a');g.fill();rpOut(g,1.4);
 for(const [x,y,c] of [[8,-10,'#ff8aa8'],[12.4,-11.6,'#7ad8ff'],[16.6,-10,'#8affb4']]){g.beginPath();g.arc(x,y,1.2,0,TAU);g.fillStyle=c;g.fill();g.lineWidth=.7;g.strokeStyle=RPTO;g.stroke()}}
const rphvQueenS=()=>rpSpr('hv|queen',-29,-14,52,28,g=>rphvQueenArt(g));
function rphvQWingArt(g,f){rphvWingDraw(g,3,-5.5,f?[[-2.6,22,6,.48],[-2.84,19,5.2,.6]]:[[-2.0,24,6.4,.48],[-2.3,21,5.6,.6]],'#fbfdff','#ffe27a')}
const rphvQWingS=f=>rpSpr('hv|qw|'+f,-24,-33,30,34,g=>rphvQWingArt(g,f));
function rphvQueen(g,x,y,dir,tier,t,sc,a,ch,perch){g.save();g.translate(x,y);const s=sc||1;g.globalAlpha=a==null?1:a;
 if(ch>0){g.globalCompositeOperation='lighter';rpGlow(g,-4*dir*s,0,(28+18*ch)*s,(24+14*ch)*s,'#ffe27a',.35+.55*ch);g.globalCompositeOperation='source-over';g.globalAlpha=a==null?1:a}
 g.scale(dir<0?-s:s,s);rpPut(g,rphvQueenS());const ga=g.globalAlpha;
 if(perch){/* resting wings, now and then a flutter */const k=Math.sin(t*9)>.82?Math.floor(t*40)%2:1;g.globalAlpha=ga;rpPut(g,rphvQWingS(k))}
 else{const f=Math.floor(t*(30+30*(ch||0)))%2;g.globalAlpha=ga*.45;rpPut(g,rphvQWingS(1-f));g.globalAlpha=ga*.92;rpPut(g,rphvQWingS(f))}g.restore()}

/* ---------- honey puddles, sting sparks, the Queen's burst, pollen ---------- */
const rphvHoney=tier=>tier>=5?['#fffbe6','#ffe27a','#d8aa48']:tier===4?['#ffe8ff','#f0a8ff','#b060e0']:['#fff2b8','#ffb52a','#c8700a'];
function rphvPudArt(g,tier,v){const C=rphvHoney(tier),bl=[[0,0,28],[-17+v*3,-3,17],[17-v*2,3,16],[-5,9-v,14],[9+v*2,-9,13]];
 /* a flat, glossy sheet of honey: dark outline, an amber body with a deeper rim, a light sheen and a few bubbles */
 g.fillStyle=RPTO;for(const [x,y,r] of bl){g.beginPath();g.arc(x,y,r+2.4,0,TAU);g.fill()}
 g.fillStyle=C[2];for(const [x,y,r] of bl){g.beginPath();g.arc(x,y,r,0,TAU);g.fill()}
 g.fillStyle=C[1];for(const [x,y,r] of bl){g.beginPath();g.arc(x-1,y-1.6,r-4,0,TAU);g.fill()}
 g.fillStyle=rpA(C[0],.55);g.beginPath();g.ellipse(-6,-8,15,4.4,-.12,0,TAU);g.fill();g.beginPath();g.ellipse(13,-3,4.4,1.8,-.1,0,TAU);g.fill();
 g.fillStyle='rgba(255,255,255,.75)';g.beginPath();g.ellipse(-9,-9,6,1.7,-.12,0,TAU);g.fill();
 g.strokeStyle=rpA('#ffffff',.6);g.lineWidth=1.3;for(const [x,y,r] of [[6+v*3,5,2.6],[-12,6,1.8],[16,-8+v,1.6]]){g.beginPath();g.arc(x,y,r,0,TAU);g.stroke()}
 g.strokeStyle=rpA(C[2],.8);g.lineWidth=1.4;for(let i=0;i<2;i++){rphvHex(g,-15+i*24+v*3,4-i*10,3.4);g.stroke()}}
const rphvPudS=(tier,v)=>rpSpr('hv|pd|'+rphvT(tier)+'|'+v,-52,-52,104,104,g=>rphvPudArt(g,rphvT(tier),v),1);
function rphvPuddle(g,x,y,r,k,t,tier,seed){if(k<=.01)return;const v=(seed*3|0)%3,s=r/40,sq=RPFX.sq;g.save();g.translate(x,y);g.scale(s*(.82+.18*k),s*sq*(.82+.18*k));g.globalAlpha=Math.min(1,k*1.3)*.86;rpPut(g,rphvPudS(tier,v));
 /* a glint that slides over the surface */
 if(!RPFX.lite){const u=((t*.45+seed)%1);g.globalCompositeOperation='lighter';g.globalAlpha=Math.min(1,k)*.5*Math.sin(Math.PI*u);g.drawImage(rpGlowC('#fff6c8'),-30+60*u-10,-16,20,10);g.globalCompositeOperation='source-over'}
 g.restore();g.globalAlpha=1}
const rphvSpkS=tier=>rpSpr('hv|spk|'+rphvT(tier),-14,-14,28,28,g=>{const c=rphvBeeC(rphvT(tier)).b[1];g.drawImage(rpGlowC(c),-14,-14,28,28);g.fillStyle='#ffffff';g.beginPath();
 for(let i=0;i<8;i++){const a=i*Math.PI/4,r=i%2?2.2:9;g.lineTo(Math.cos(a)*r,Math.sin(a)*r)}g.closePath();g.fill()});
function rphvSting(g,x,y,u,tier){if(u<=0||u>=1)return;const z=(.6+.8*Math.sin(Math.PI*Math.min(1,u*1.6)))*(1-u*.4);g.save();g.translate(x,y);g.rotate(u*1.4);g.scale(z,z);g.globalAlpha=1-u*u;rpPut(g,rphvSpkS(tier));g.restore();g.globalAlpha=1}
const rphvDot=col=>rpSpr('hv|dot|'+col,-6,-6,12,12,g=>{g.drawImage(rpGlowC(col),-6,-6,12,12);g.fillStyle='#ffffff';g.beginPath();g.arc(0,0,1.3,0,TAU);g.fill()},1);
function rphvBurst(g,x,y,r,u,tier,h,part){if(u<=0||u>=1)return;const gr=part!==1,air=part!==0;h=h||60;const sq=RPFX.sq,e=1-Math.pow(1-u,3),C=rphvHoney(Math.max(5,tier)),rr=r*(.2+.85*e),qy=y-h,lt=RPFX.lite;
 /* the flash at the Queen and a golden sheet of light on the ground */
 g.save();g.globalCompositeOperation='lighter';if(air){rpGlow(g,x,qy,70+40*e,56+30*e,'#ffe27a',(1-u)*1.1);rpGlow(g,x,qy,30,30,'#ffffff',Math.max(0,1-u*2.6))}
 if(gr){g.globalAlpha=(1-u)*.4;g.fillStyle='#ffd23a';g.beginPath();g.ellipse(x,y,rr,rr*sq,0,0,TAU);g.fill()}g.restore();
 /* the shock ring with honeycomb cells riding on it (all cells in one path, all stingers in one path: few state changes) */
 g.save();if(gr){g.globalAlpha=(1-u)*.95;for(const [lw,c] of [[8*(1-u)+3,'rgba(18,8,31,.5)'],[5*(1-u)+1.6,C[1]],[1.4,'#ffffff']]){g.beginPath();g.ellipse(x,y,rr,rr*sq,0,0,TAU);g.lineWidth=lw;g.strokeStyle=c;g.stroke()}
 if(!lt){g.globalAlpha=1-u;g.beginPath();for(let i=0;i<12;i++){const a=i/12*TAU+u*.8,hx=x+Math.cos(a)*rr,hy=y+Math.sin(a)*rr*sq,z=5+4*(1-u);for(let j=0;j<6;j++){const b=Math.PI/6+j*Math.PI/3;j?g.lineTo(hx+Math.cos(b)*z,hy+Math.sin(b)*z):g.moveTo(hx+Math.cos(b)*z,hy+Math.sin(b)*z)}g.closePath()}
  g.fillStyle=rpA(C[0],.55);g.fill();g.lineWidth=1.6;g.strokeStyle=RPTO;g.stroke()}}
 if(air){ /* stingers fired from the Queen down to the ring */
 g.lineCap='round';const k=Math.min(1,u*2.2),P=[];for(let i=0;i<16;i++){const a=i/16*TAU+.2,tx=x+Math.cos(a)*r*.92,ty=y+Math.sin(a)*r*.92*sq-12,kb=Math.max(0,k-.22);P.push(x+(tx-x)*kb,qy+(ty-qy)*kb,x+(tx-x)*k,qy+(ty-qy)*k)}
 g.globalAlpha=Math.min(1,(1-u)*1.6);const line=(odd)=>{g.beginPath();for(let i=0;i<16;i++){if(odd!=null&&i%2!==odd)continue;g.moveTo(P[i*4],P[i*4+1]);g.lineTo(P[i*4+2],P[i*4+3])}};
 line(null);g.lineWidth=4;g.strokeStyle=RPTO;g.stroke();line(1);g.lineWidth=2.2;g.strokeStyle='#ffffff';g.stroke();line(0);g.strokeStyle=C[1];g.stroke();
 g.fillStyle='#ffffff';g.beginPath();for(let i=0;i<16;i++){g.moveTo(P[i*4+2]+1.6,P[i*4+3]);g.arc(P[i*4+2],P[i*4+3],1.6,0,TAU)}g.fill()}
 g.restore();g.globalAlpha=1}
/* a pollen grain: a fuzzy golden ball in a soft glow */
const rphvGrainS=()=>rpSpr('hv|grain',-8,-8,16,16,g=>{g.drawImage(rpGlowC('#ffc83a'),-8,-8,16,16);g.fillStyle='#b8600a';g.beginPath();for(let i=0;i<16;i++){const a=i/16*TAU,r=i%2?3.3:4.2;g.lineTo(Math.cos(a)*r,Math.sin(a)*r)}g.closePath();g.fill();
 g.beginPath();g.arc(0,0,3,0,TAU);g.fillStyle=rpVG(g,-3,3,'#fff6a0','#ffb52a');g.fill();g.fillStyle='rgba(255,255,255,.9)';g.beginPath();g.arc(-1,-1.1,1,0,TAU);g.fill()},2);
function rphvPollen(g,x,y,t,a,top,ph){if(a<=.01)return;const gr=rphvGrainS().c,st=rpStarS().c;g.save();g.globalCompositeOperation='lighter';
 g.globalAlpha=a*(.7+.2*Math.sin(t*2+ph));g.drawImage(rpGlowC("#ffd23a"),x-50,y-12,100,34);g.globalCompositeOperation='source-over';
 /* grains spiral up around the tower, a couple of sparkles among them */
 for(let i=0;i<8;i++){const u=((t*.3+i/8+ph)%1),an=u*TAU*1.5+i*.9+ph,r=26+8*Math.sin(i*1.7)+6*u,xx=x+Math.cos(an)*r,yy=y-4-top*(.06+.8*u)+Math.sin(an)*r*.3,f=Math.min(1,Math.sin(Math.PI*u)*1.6);
  g.globalAlpha=a*f;if(i%4===3){const z=5+3*f;g.drawImage(st,xx-z,yy-z,z*2,z*2)}else{const z=6.4+1.4*Math.sin(an);g.drawImage(gr,xx-z,yy-z,z*2,z*2)}}
 g.restore();g.globalAlpha=1}
