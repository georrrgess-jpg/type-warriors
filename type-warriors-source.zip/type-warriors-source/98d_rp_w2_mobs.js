/* ===== RUNESTONE TOWER DEFENSE 10.0: the World 2 (Tidebreak Isles) monsters (98d) =====
   The sea-folk cast, drawn in code in the 95b style (chunky #12081f outlines, cel shading lit from the upper left, white highlight
   strokes, 'lighter' radial glows, never shadowBlur or ctx.filter). Every drawing faces RIGHT with the feet at (0,0); ph 0..1 is one
   walk / swim / flap cycle and loops seamlessly (baked into 8 frames like World 1).
   Each RPMD[id](g,ph,o) draws its own map variant from o.v (World 1 recolours 95b drawings; these carry the variant in the drawing):
   - coral  Coral Shallows: tropical reef colours (coral pink, teal, sunny yellow) with starfish, shells, little corals, a hibiscus.
   - wreck  Shipwreck Cove: pirates - tricorns, bandanas, eye patches, rusty riveted iron, barnacles, gold earrings, lanterns,
            harpoons, a cutlass, a powder fuse, a barrel shell with a Jolly Roger.
   - abyss  Kraken's Maw: deep-sea glow - dark navy bodies with glowing cyan / magenta photophores, anglerfish lures, translucent fins.
   Cast: crab, shell, puffer, jelly (flies: RPMOB.jelly.lift), brute, siren, squid, leviathan (boss), plus two pose sprites the core
   swaps in while an ability is on: shell_in (the Shellback hidden in its shell) and puffer_big (the Puffer inflated, ~25% bigger).
   Wiring (no engine changes): RPMD / RPMB / RPMK / RPMOB / RPMDX entries; rpvDraw is wrapped so the ids of RPW_MOBS that belong to
   World 2 draw RPMD[id](g,ph,{v}) (rpvV in 98a already returns a valid World 2 variant), so rpvBake / rpMobBlit / rpMobIcon work
   unchanged (97l grades the sheets and draws monsters 8% larger, as in World 1); rpMobDeath is wrapped for sea debris in the
   variant's colours (a splash ring, water drops, shell shards, bubbles, starfish, gold coins, barnacles, ink, notes, glow sparks);
   rpMobPrebake(null, v) (called at every battle start) skips the World 2 sheets unless v is a World 2 variant.
   Abyss sprites get a soft cyan bioluminescent halo baked round the silhouette (rpw2mHalo; RPW2M.noHalo=1 turns it off) so the dark
   sea folk stay readable on the dark trench. Everything is baked: the per-frame cost is World 1's (two drawImage calls a monster).
   Globals and private helpers are prefixed rpw2m. */
const RPW2M={noHalo:0},RPW2M_V={coral:0,wreck:1,abyss:2},RPW2M_IDS=['crab','shell','puffer','jelly','brute','siren','squid','leviathan','shell_in','puffer_big'];
const rpw2mV=o=>RPW2M_V[o&&o.v]||0;
/* ---------- accessory helpers (in the caller's units) ---------- */
/* a soft five-armed starfish */
function rpw2mStar(g,x,y,r,ang,c1,c2){g.save();g.translate(x,y);g.rotate(ang||0);const P=[];for(let i=0;i<10;i++){const t=-Math.PI/2+i*Math.PI/5,rr=i%2?r*.4:r;P.push(Math.cos(t)*rr,Math.sin(t)*rr)}
 rpmBl(g,P);rpmFS(g,rpmRG(g,0,0,r,[0,rpmSh(c1,.45),.45,c1,1,c2],-r*.25,-r*.3),Math.max(1,r*.3));
 for(let i=0;i<5;i++){const t=-Math.PI/2+i*RPMT/5;for(const k of[.3,.58])rpmEl(g,Math.cos(t)*r*k,Math.sin(t)*r*k,r*.09,r*.09,rpmSh(c1,.6),0)}g.restore()}
/* a branching coral sprig with round tips (one outline pass, then the fill, so the joints stay clean) */
function rpw2mCoral(g,x,y,s,ang,col,tip){g.save();g.translate(x,y);g.rotate(ang||0);g.scale(s,s);
 const L=[[0,0,0,-6,-1,-10],[0,-4,4,-7,5,-11],[0,-6,-4,-8,-6,-11],[-1,-9,1,-12,0,-14],[4,-8,7,-9,8,-11]];
 const path=()=>{g.beginPath();for(const l of L){g.moveTo(l[0],l[1]);g.quadraticCurveTo(l[2],l[3],l[4],l[5])}};
 g.lineCap='round';path();g.lineWidth=5.6;g.strokeStyle=RPMO;g.stroke();path();g.lineWidth=2.8;g.strokeStyle=col;g.stroke();
 for(const l of L){rpmEl(g,l[4],l[5],1.9,1.9,tip||rpmSh(col,.4),1)}
 g.beginPath();g.moveTo(-.6,-1);g.quadraticCurveTo(-.6,-6,-1.6,-9.6);rpmHi(g,.45,.8);g.restore()}
/* a scallop shell, hinge at (x,y), fan pointing up */
function rpw2mScal(g,x,y,r,ang,c1,c2){g.save();g.translate(x,y);g.rotate(ang||0);g.beginPath();g.moveTo(0,0);g.lineTo(-r*.92,-r*.5);
 for(let i=0;i<5;i++){const t0=Math.PI*(1.15+i*.14),t1=Math.PI*(1.15+(i+1)*.14),tm=(t0+t1)/2;g.quadraticCurveTo(Math.cos(tm)*r*1.22,Math.sin(tm)*r*1.22+r*.1,Math.cos(t1)*r,Math.sin(t1)*r+r*.1)}
 g.closePath();rpmFS(g,rpmRG(g,0,-r*.5,r*1.1,[0,rpmSh(c1,.5),.55,c1,1,c2],-r*.3,-r*.8),Math.max(1,r*.26));
 g.beginPath();for(let i=1;i<5;i++){const t=Math.PI*(1.15+i*.14);g.moveTo(0,-r*.1);g.lineTo(Math.cos(t)*r*.92,Math.sin(t)*r*.92+r*.1)}g.lineWidth=Math.max(.6,r*.12);g.strokeStyle=rpmA(RPMO,.45);g.stroke();
 rpmP(g,[-r*.32,0,r*.32,0,r*.22,r*.28,-r*.22,r*.28]);rpmFS(g,c2,Math.max(.8,r*.2));g.restore()}
/* a spiral sea snail shell */
function rpw2mSnail(g,x,y,r,ang,c1,c2){g.save();g.translate(x,y);g.rotate(ang||0);rpmEl(g,0,0,r,r*.86,rpmRG(g,0,0,r,[0,rpmSh(c1,.45),.6,c1,1,c2],-r*.3,-r*.3),Math.max(1,r*.26));
 g.beginPath();for(let i=0;i<=24;i++){const t=i/24*RPMT*1.6,rr=r*.8*(1-i/28);i?g.lineTo(Math.cos(t)*rr*.9,Math.sin(t)*rr*.78):g.moveTo(Math.cos(t)*rr*.9,Math.sin(t)*rr*.78)}g.lineWidth=Math.max(.7,r*.16);g.strokeStyle=rpmA(RPMO,.6);g.stroke();g.restore()}
/* a barnacle cone (base at (x,y), pointing along ang) */
function rpw2mBarn(g,x,y,r,ang,col){col=col||'#d8d0c0';g.save();g.translate(x,y);g.rotate(ang||0);rpmP(g,[-r,0,-r*.5,-r*1.05,r*.5,-r*1.05,r,0]);rpmFS(g,rpmLG(g,-r,0,r,0,[0,rpmSh(col,.4),.5,col,1,rpmSh(col,-.35)]),Math.max(.9,r*.32));
 rpmEl(g,0,-r*1.05,r*.5,r*.2,'#2a2234',Math.max(.7,r*.2));g.beginPath();g.moveTo(-r*.25,-r*.1);g.lineTo(-r*.2,-r*.9);g.moveTo(r*.3,-r*.1);g.lineTo(r*.25,-r*.9);g.lineWidth=Math.max(.5,r*.14);g.strokeStyle=rpmA(RPMO,.4);g.stroke();g.restore()}
/* a barnacle seen from above: a ring of pale plates round a dark slit */
function rpw2mBarnT(g,x,y,r,col){col=col||'#efe8d8';rpmEl(g,x,y,r,r*.82,rpmRG(g,x,y,r,[0,rpmSh(col,.45),.6,col,1,rpmSh(col,-.4)],x-r*.3,y-r*.35),Math.max(.9,r*.26));
 g.beginPath();for(let i=0;i<6;i++){const t=i/6*RPMT+.3;g.moveTo(x+Math.cos(t)*r*.42,y+Math.sin(t)*r*.36);g.lineTo(x+Math.cos(t)*r*.92,y+Math.sin(t)*r*.76)}g.lineWidth=Math.max(.5,r*.12);g.strokeStyle=rpmA(RPMO,.4);g.stroke();
 rpw2mSlit(g,x,y,r);rpmFS(g,'#2a2234',Math.max(.6,r*.14))}
function rpw2mSlit(g,x,y,r){g.beginPath();g.moveTo(x-r*.42,y);g.quadraticCurveTo(x,y-r*.36,x+r*.42,y);g.quadraticCurveTo(x,y+r*.3,x-r*.42,y);g.closePath()}
/* a pirate tricorn: brim tips left/right, front tip pointing down; centred on (x,y) = the middle of the brim */
function rpw2mTri(g,x,y,s,ang,col,trim,skull){g.save();g.translate(x,y);g.rotate(ang||0);g.scale(s,s);col=col||'#2c2232';trim=trim||'#ffcf4a';
 g.beginPath();g.moveTo(-8,-3);g.quadraticCurveTo(-8,-13,0,-13.4);g.quadraticCurveTo(8,-13,8,-3);g.closePath();rpmFS(g,rpmCel(g,-8,-13,8,-2,rpmSh(col,-.1)),1.8);
 const B=()=>{g.beginPath();g.moveTo(-15,-10);g.quadraticCurveTo(-8,-1,1,2.6);g.quadraticCurveTo(9,-1,15.4,-10.4);g.quadraticCurveTo(8,-4.6,0,-5.6);g.quadraticCurveTo(-8,-4.4,-15,-10);g.closePath()};
 B();rpmFS(g,rpmLG(g,0,-11,0,3,[0,rpmSh(col,.25),.5,col,1,rpmSh(col,-.3)]),2);
 g.beginPath();g.moveTo(-13.4,-8.8);g.quadraticCurveTo(-7.4,-1.4,1,1.2);g.quadraticCurveTo(8.6,-1.4,13.8,-9.2);g.lineWidth=1.5;g.strokeStyle=trim;g.stroke();
 if(skull!==0){rpmEl(g,.6,-3,2.3,2,'#fff8e8',.9);g.fillStyle=RPMO;g.fillRect(-.6,-3.4,.9,.9);g.fillRect(1.2,-3.4,.9,.9);g.beginPath();g.moveTo(-2.4,-.2);g.lineTo(3.6,1.6);g.moveTo(3.6,-.2);g.lineTo(-2.4,1.6);g.lineWidth=.9;g.strokeStyle='#fff8e8';g.stroke()}
 g.beginPath();g.moveTo(-5,-11);g.quadraticCurveTo(-1,-13,3,-12.4);rpmHi(g,.4,1);g.restore()}
/* an eye patch with its strap from (x0,y0) to (x1,y1) */
function rpw2mPatch(g,x,y,r,x0,y0,x1,y1,ang){g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo(x,y-r*.2,x1,y1);g.lineWidth=2.6;g.strokeStyle=RPMO;g.stroke();g.lineWidth=1;g.strokeStyle='#4a3a4a';g.stroke();
 g.save();g.translate(x,y);g.rotate(ang||0);g.beginPath();g.moveTo(-r,-r*.5);g.quadraticCurveTo(0,-r*.9,r,-r*.5);g.quadraticCurveTo(r*.9,r*.9,0,r);g.quadraticCurveTo(-r*.9,r*.9,-r,-r*.5);g.closePath();
 rpmFS(g,rpmLG(g,0,-r,0,r,[0,'#3a2c3c',1,'#120a18']),1.3);g.beginPath();g.moveTo(-r*.5,-r*.4);g.quadraticCurveTo(0,-r*.6,r*.4,-r*.35);rpmHi(g,.35,.7);g.restore()}
/* a gold hoop earring hanging from (x,y) */
function rpw2mRing(g,x,y,r){g.beginPath();g.arc(x,y+r,r,0,RPMT);g.lineWidth=r*.5+2;g.strokeStyle=RPMO;g.stroke();g.lineWidth=r*.5;g.strokeStyle='#ffc93a';g.stroke();
 g.beginPath();g.arc(x,y+r,r,3.6,4.6);g.lineWidth=Math.max(.5,r*.2);g.strokeStyle='#fff6c8';g.stroke()}
/* a ship lantern hanging from (x,y), lit */
function rpw2mLantern(g,x,y,s,ph,col){col=col||'#ffb84a';const pu=.8+.2*Math.sin(ph*RPMT*2);g.save();g.translate(x,y);g.scale(s,s);
 rpmGlow(g,0,9,22*pu,col,.75);g.beginPath();g.arc(0,-.5,2.4,Math.PI,RPMT);g.lineWidth=2.8;g.strokeStyle=RPMO;g.stroke();g.lineWidth=1.2;g.strokeStyle='#8a8e9a';g.stroke();
 rpmP(g,[-4.4,4,-2.4,1,2.4,1,4.4,4]);rpmFS(g,'#4a4a56',1.3);
 g.beginPath();g.roundRect(-4.6,4,9.2,9.6,2.4);rpmFS(g,rpmRG(g,0,8.6,7,[0,'#fffbe0',.45,'#ffd86a',1,col],-1,7),1.5);
 g.beginPath();g.moveTo(-1.6,4.4);g.lineTo(-1.6,13.2);g.moveTo(1.6,4.4);g.lineTo(1.6,13.2);g.lineWidth=1;g.strokeStyle='rgba(60,40,30,.6)';g.stroke();
 rpmP(g,[-5,13.4,5,13.4,3.6,16,-3.6,16]);rpmFS(g,'#4a4a56',1.3);rpmEl(g,0,8.8,1.4,2.2,'#ffffff',0);g.restore()}
/* a bioluminescent spot */
function rpw2mDot(g,x,y,r,col,a){rpmGlow(g,x,y,r*3.4,col,a==null?.7:a);rpmEl(g,x,y,r,r,col,0);rpmEl(g,x-r*.2,y-r*.22,r*.45,r*.45,'#ffffff',0)}
/* an anglerfish lure: stalk from (x0,y0) bending over (cx,cy) to a glowing bulb at (x1,y1) */
function rpw2mLure(g,x0,y0,cx,cy,x1,y1,r,col,stalk){g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo(cx,cy,x1,y1);g.lineWidth=3.6;g.strokeStyle=RPMO;g.stroke();g.lineWidth=1.6;g.strokeStyle=stalk||'#3a4a80';g.stroke();
 rpmGlow(g,x1,y1,r*5,col,.85);rpmEl(g,x1,y1,r,r*1.1,rpmRG(g,x1,y1,r,[0,'#ffffff',.5,rpmSh(col,.5),1,col],x1-r*.3,y1-r*.3),1.2);rpmEl(g,x1-r*.3,y1-r*.35,r*.3,r*.3,'#ffffff',0)}
/* a fin from a polygon: gradient fill, optional translucency, ribs from the first point */
function rpw2mFin(g,p,c1,c2,al,ribs){const n=p.length>>1;let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;for(let i=0;i<n;i++){x0=Math.min(x0,p[i*2]);x1=Math.max(x1,p[i*2]);y0=Math.min(y0,p[i*2+1]);y1=Math.max(y1,p[i*2+1])}
 rpmBl(g,p);g.save();if(al!=null&&al<1)g.globalAlpha=al;g.fillStyle=rpmLG(g,p[0],p[1],(x0+x1)/2+(p[0]<(x0+x1)/2?1:-1)*(x1-x0)*.5,(y0+y1)/2+(p[1]<(y0+y1)/2?1:-1)*(y1-y0)*.5,[0,c1,1,c2]);g.fill();g.restore();
 g.lineWidth=1.8;g.strokeStyle=RPMO;g.stroke();
 if(ribs){g.beginPath();for(let i=2;i<n;i+=1){if(i%2)continue;g.moveTo(p[0],p[1]);g.lineTo(p[0]+(p[i*2]-p[0])*.86,p[1]+(p[i*2+1]-p[1])*.86)}g.lineWidth=.8;g.strokeStyle=rpmA(RPMO,.4);g.stroke()}}
/* a bubble */
function rpw2mBub(g,x,y,r,a,col){if(a<=0)return;g.save();g.globalAlpha*=a;g.beginPath();g.arc(x,y,r,0,RPMT);g.fillStyle='rgba(220,250,255,.22)';g.fill();g.lineWidth=Math.max(.7,r*.28);g.strokeStyle=col||'#e8fcff';g.stroke();
 rpmEl(g,x-r*.35,y-r*.35,r*.28,r*.28,'#ffffff',0);g.restore()}
/* a music note */
function rpw2mNote(g,x,y,s,col,ang){g.save();g.translate(x,y);g.rotate(ang||0);g.scale(s,s);const P=()=>{g.beginPath();g.ellipse(0,0,3,2.2,-.4,0,RPMT);g.moveTo(2.6,-.6);g.lineTo(2.6,-10);g.quadraticCurveTo(6,-8,6.4,-4.6)};
 P();g.lineWidth=3.6;g.strokeStyle=RPMO;g.stroke();g.beginPath();g.ellipse(0,0,3,2.2,-.4,0,RPMT);g.fillStyle=col;g.fill();
 g.beginPath();g.moveTo(2.6,-.6);g.lineTo(2.6,-10);g.quadraticCurveTo(6,-8,6.4,-4.6);g.lineWidth=1.5;g.strokeStyle=col;g.stroke();g.restore()}
/* a small cutlass, hilt at (x,y), blade along ang */
function rpw2mCut(g,x,y,ang,s){g.save();g.translate(x,y);g.rotate(ang);g.scale(s,s);
 g.beginPath();g.moveTo(-1.6,-3);g.quadraticCurveTo(-3.6,-12,1,-20);g.quadraticCurveTo(1.6,-12,1.8,-3);g.closePath();rpmFS(g,rpmLG(g,-3,0,2,0,[0,'#ffffff',.4,'#d6dde8',1,'#7e8898']),1.4);
 g.beginPath();g.moveTo(-.8,-5);g.quadraticCurveTo(-2,-11,.4,-17);rpmHi(g,.6,.7);
 rpmP(g,[-3.4,-3.4,3.4,-3.4,3.4,-1.8,-3.4,-1.8]);rpmFS(g,'#ffc93a',1.1);rpmP(g,[-1,-1.8,1,-1.8,1,3,-1,3]);rpmFS(g,'#6a3a22',1);rpmEl(g,0,3.6,1.3,1.3,'#ffc93a',.9);g.restore()}
/* a rusty riveted iron plate */
function rpw2mPlate(g,p,riv,col){rpmRock(g,p,col||'#7c7270',1.8,.55,.32);const n=p.length>>1;let cx=0,cy=0;for(let i=0;i<n;i++){cx+=p[i*2];cy+=p[i*2+1]}cx/=n;cy/=n;
 g.save();rpmP(g,p);g.clip();g.globalAlpha=.55;g.fillStyle='#b4582a';for(let i=0;i<3;i++){const x=p[i*2]*.6+cx*.4,y=p[i*2+1]*.6+cy*.4;g.beginPath();g.ellipse(x,y,2.2,1.4,.5,0,RPMT);g.fill();g.fillRect(x-.5,y,1,3.2)}g.restore();
 for(const r of riv||[])rpmEl(g,r[0],r[1],.95,.95,'#d8d2cc',.7)}
/* sea foam / splash at the water line (x, y), width w */
function rpw2mSplash(g,x,y,w,ph,col,seed){seed=seed||0;const t=ph*RPMT;rpmEl(g,x,y,w,w*.26,rpmA(col,.75),0);
 g.beginPath();for(let i=0;i<=8;i++){const u=i/8,xx=x-w+u*w*2,yy=y-Math.abs(Math.sin(u*Math.PI*3+t*2+seed))*w*.22-Math.sin(u*Math.PI)*w*.12;i?g.lineTo(xx,yy):g.moveTo(xx,yy)}
 g.lineTo(x+w,y+w*.1);g.quadraticCurveTo(x,y+w*.3,x-w,y+w*.1);g.closePath();rpmFS(g,rpmLG(g,0,y-w*.3,0,y+w*.3,[0,'#ffffff',1,'#bfefff']),1.4);
 for(let i=0;i<3;i++){const u=(ph*2+i/3+seed*.13)%1,xx=x+(i-1)*w*.6+Math.sin(i+seed)*2,yy=y-w*.2-Math.sin(u*Math.PI)*w*.55;g.globalAlpha=1-u*.6;rpmEl(g,xx,yy,1.3+(i%2)*.5,1.5+(i%2)*.5,'#ffffff',.9)}g.globalAlpha=1}
/* a little dust / sand kick behind a walker */
function rpw2mDust(g,x,y,ph,col,n){n=n||2;for(let i=0;i<n;i++){const u=(ph*2+i/n)%1,r=1.8+u*3.2;g.globalAlpha=(1-u)*.75;g.beginPath();g.ellipse(x-u*9,y-1.4-u*3.4,r,r*.78,0,0,RPMT);g.fillStyle=col;g.fill();g.lineWidth=.8;g.strokeStyle=rpmSh(col,-.35);g.stroke()}g.globalAlpha=1}

/* ---------- 1. Crabling: a small scuttler seen from the front (crabs walk sideways), claws up like a boxer ---------- */
const RPW2M_CRAB=[
 {sh:'#ff6a48',lg:'#f0583c',bl:'#ffd9a4',ir:'#2ad0c8',lid:'#c8402a',claw:'#ff7a52'},
 {sh:'#b8442c',lg:'#a03a28',bl:'#f2c6a0',ir:'#ffcf3a',lid:'#7a2a1c',claw:'#c8503a'},
 {sh:'#34469c',lg:'#2a3a88',bl:'#5a6cc0',ir:'#6af6ff',lid:'#1a2456',claw:'#3c50ac'}];
function rpw2mClaw(g,x,y,sc,fl,open,P,V){g.save();g.translate(x,y);g.scale(fl*sc,sc);
 /* the fixed finger, the moving one hinged at the palm top (opens outward), then the palm over their roots */
 g.beginPath();g.moveTo(5.8,-1.6);g.quadraticCurveTo(8.4,-9.4,3.8,-15.4);g.quadraticCurveTo(3,-8.6,.2,-4.2);g.closePath();rpmFS(g,rpmCel(g,0,-15,8,-2,P.claw),1.8);
 for(const yy of[-7.4,-10.4]){rpmP(g,[3.4,yy,1.4,yy-.6,3,yy-1.8]);g.fillStyle='#fffbe8';g.fill()}
 g.save();g.translate(-1.4,-3.6);g.rotate(-open);g.beginPath();g.moveTo(-4.4,1.6);g.quadraticCurveTo(-6.4,-6,-1.6,-11.6);g.quadraticCurveTo(-.6,-5.4,2,-.6);g.closePath();rpmFS(g,rpmCel(g,-6,-12,2,1,P.claw),1.8);
 for(const yy of[-3.4,-6.4]){rpmP(g,[-.4,yy,1.4,yy-.4,-.2,yy-1.8]);g.fillStyle='#fffbe8';g.fill()}g.restore();
 rpmBl(g,[-6.4,2.8,-6.8,-2.6,-2.8,-5.8,4.2,-5.8,7.2,-1.6,6,3.4,0,5.6]);rpmFS(g,rpmRG(g,0,0,9,[0,rpmSh(P.claw,.42),.5,P.claw,1,rpmSh(P.claw,-.38)],-2,-3),2);
 rpmAH(g,-.6,-.4,4.6,4,3.5,4.6,.6,1.2);
 if(V===2){rpw2mDot(g,3,1.2,1.1,'#6af6ff',.55);rpw2mDot(g,-2.6,2.6,.8,'#ff5ad8',.5)}
 g.restore()}
RPMD.crab=function(g,ph,o){const V=rpw2mV(o),P=RPW2M_CRAB[V],a=ph*RPMT,by=-Math.abs(Math.sin(a*2))*1.6,cy=-15+by,tl=.07;
 if(V<2)rpw2mDust(g,-15,0,ph,V?'#c8b89a':'#fff0c8',2);else for(let i=0;i<2;i++){const u=(ph+i*.5)%1;rpw2mBub(g,-14-u*4+Math.sin(u*9)*1.5,-6-u*18,1.2+u*1.2,1-u,'#8af4ff')}
 /* six legs: three to each side, scuttling in turn */
 const leg=(sd,i)=>{const p=a*2+i*2.09+(sd>0?0:1.05),L=V===2?1.1:1,hx=sd*(8+i*1.4),hy=cy+2.6+i*1.2,lift=Math.max(0,Math.cos(p))*3.4,fx=sd*(19+i*5.2)*L+2.6*Math.sin(p),fy=-lift-.4,
  kx=sd*(14.6+i*4.2)*L+1.6*Math.sin(p),ky=cy-3.6+i*2.2-lift*.6;const col=rpmSh(P.lg,sd<0?-.28:-.1);
  rpmLimb(g,[hx,hy,kx,ky],V===2?2:2.4,col,1.5);rpmLimb(g,[kx,ky,kx+(fx-kx)*.55+sd*1.2,ky+(fy-ky)*.45,fx,fy],V===2?1.5:1.8,col,1.5);rpmP(g,[fx-1,fy-.6,fx+1,fy-.6,fx+sd*.3,fy+1.6]);rpmFS(g,rpmSh(col,-.4),.9);
  rpmEl(g,kx,ky,1.4,1.4,rpmSh(col,.2),1);g.beginPath();g.moveTo(hx,hy-.9);g.lineTo(kx-sd*.5,ky-.9);rpmHi(g,.3,.7);
  if(V===2)rpw2mDot(g,fx,fy,.8,'#6af6ff',.6)};
 for(let i=2;i>=0;i--){leg(-1,i);leg(1,i)}
 g.save();g.translate(0,cy);g.rotate(tl);
 /* eye stalks behind the shell rim */
 const w1=Math.sin(a*2+.6)*1,w2=Math.sin(a*2+1.8)*1,E=[[-5.4,-19.4+w1],[5.8,-19.8+w2]];
 rpmLimb(g,[-3.4,-8,-4.4,-13,E[0][0],E[0][1]],2.4,rpmSh(P.sh,.12),1.6);rpmLimb(g,[3.6,-8,4.8,-13,E[1][0],E[1][1]],2.4,rpmSh(P.sh,.12),1.6);
 /* rim spikes */
 for(const [x,y,t] of[[-14.6,-1.6,-2.2],[-13,-6.4,-2.6],[14.6,-1.6,-1],[13,-6.4,-.6]]){g.save();g.translate(x,y);g.rotate(t);rpmP(g,[-1.8,0,0,3.8,1.8,0]);rpmFS(g,P.sh,1.3);g.restore()}
 if(V===2){g.save();g.globalAlpha=.6;for(let i=0;i<6;i++){const t=Math.PI*(1.12+i*.155);g.save();g.translate(Math.cos(t)*13,Math.sin(t)*8.6-1.6);g.rotate(t+Math.PI/2);rpmP(g,[-1.4,0,0,-4.6,1.4,0]);g.fillStyle='#6af0ff';g.fill();g.restore()}g.restore()}
 /* carapace */
 const C=[-15,-1,-13.4,-7,-7,-10.6,0,-11.6,7,-10.6,13.4,-7,15,-1,11,4.2,0,5.6,-11,4.2];
 rpmBl(g,C);rpmFS(g,rpmRG(g,0,-2,17,[0,rpmSh(P.sh,.45),.42,P.sh,.8,rpmSh(P.sh,-.25),1,rpmSh(P.sh,-.45)],-5,-8),2.4);
 rpmBl(g,[-11,2.6,0,1.2,11,2.6,10,4.4,0,5.4,-10,4.4]);g.fillStyle=rpmA(P.bl,.9);g.fill();
 for(const [x,y,r] of[[-6,-7.4,1.1],[-2,-9,.9],[3,-8.6,1.2],[7.6,-6.6,.9],[-9.6,-4.4,.8]])rpmEl(g,x,y,r,r*.8,rpmSh(P.sh,V===2?.25:.4),0);
 rpmAH(g,-1,1,12,9.6,3.5,4.4,.55,1.5);
 /* the grin */
 g.beginPath();g.moveTo(-6.4,-.2);g.quadraticCurveTo(0,5.4,6.4,-.4);g.quadraticCurveTo(0,1.8,-6.4,-.2);g.closePath();rpmFS(g,V===2?'#0a0a24':'#3a0a1a',1.3);
 for(const x of[-3.6,-.8,2,4.6]){rpmP(g,[x-1,.5+Math.abs(x)*.12,x+1,.5+Math.abs(x)*.12,x,2.4+Math.abs(x)*.05]);g.fillStyle='#fffbe8';g.fill()}
 /* variant dressing on the shell */
 if(V===0){rpw2mStar(g,-7.6,-4.4,3.6,.3,'#ffd23a','#f08a1a');rpw2mCoral(g,10.6,-6.6,.62,.45,'#ff7ab4','#ffd0e6');rpmEl(g,4,-3.6,1.2,.9,'#3ad8c8',.8);rpmEl(g,7,-1.6,.9,.7,'#3ad8c8',.7)}
 if(V===1){/* bandana over the shell, the knot and tails to the back */
  g.beginPath();g.moveTo(-13.4,-6.4);g.quadraticCurveTo(-7,-12.6,0,-12.8);g.quadraticCurveTo(7,-12.6,13.4,-6.8);g.lineTo(12.6,-4.2);g.quadraticCurveTo(0,-9.6,-12.6,-3.8);g.closePath();rpmFS(g,rpmLG(g,0,-13,0,-4,[0,'#4a6ad8',1,'#1e2e7a']),1.7);
  for(const [x,y] of[[-8,-8.6],[-2,-10.2],[4.4,-10],[10,-7.6]])rpmEl(g,x,y,.9,.8,'#fff4e8',0);
  const fw=Math.sin(a*2)*1.4;g.beginPath();g.moveTo(-13,-5.4);g.quadraticCurveTo(-17,-6+fw,-21,-3.4+fw);g.lineTo(-19.4,-1+fw);g.quadraticCurveTo(-16,-3,-12.6,-3.4);g.closePath();rpmFS(g,'#2a3e9a',1.4);
  g.beginPath();g.moveTo(-13,-4.6);g.quadraticCurveTo(-16,-1+fw*.6,-18.6,2.6+fw*.6);g.lineTo(-16.4,3.2+fw*.6);g.quadraticCurveTo(-14.6,0,-12.4,-3);g.closePath();rpmFS(g,'#1e2e7a',1.4);rpmEl(g,-13.2,-4.6,2,1.8,'#3a56c0',1.3);
  rpw2mBarn(g,9,1.6,1.8,.9,'#d8ccb8');rpw2mBarn(g,11.4,-1.4,1.3,1.1,'#d8ccb8')}
 if(V===2){for(const [x,y,c] of[[-11,-1,'#6af6ff'],[-6,2.4,'#6af6ff'],[6,2.4,'#6af6ff'],[11,-1,'#6af6ff'],[0,-8,'#ff5ad8']])rpw2mDot(g,x,y,c==='#ff5ad8'?1.5:1.1,c,.6)}
 /* the eyes on their stalks */
 for(let k=0;k<2;k++){const e=E[k],r=k?3.4:3.2;if(V===2)rpmGlow(g,e[0],e[1],r*3,'#6af6ff',.45);rpmEye(g,e[0],e[1],r,P.ir,P.lid,k?-.34:.34)}
 if(V===1){rpw2mPatch(g,E[0][0]+1.2,E[0][1]+.6,2.2,E[0][0]-3.6,E[0][1]-2,E[0][0]+3.4,E[0][1]-1,.2);rpw2mRing(g,E[1][0]+2.6,E[1][1]+2.6,1.5)}
 g.restore();
 /* claws: the leading one is bigger; they snap in time with the scuttle */
 const o1=.25+.4*(.5+.5*Math.sin(a*2)),o2=.25+.4*(.5+.5*Math.sin(a*2+2));
 rpmLimb(g,[-11,cy-.4,-17,cy-.6,-19.6,cy-6.4],2.8,rpmSh(P.claw,-.14),1.8);rpmLimb(g,[11.4,cy-.8,18,cy-1.2,21.4,cy-7],3,P.claw,1.8);
 if(V===1)rpw2mCut(g,-21.6,cy-15.6,-.5,.74);
 g.save();g.translate(-20.4,cy-8);g.rotate(-.3);rpw2mClaw(g,0,0,.86,-1,o2,P,V);g.restore();
 g.save();g.translate(22,cy-8.8);g.rotate(.3);rpw2mClaw(g,0,0,1.04,1,o1,P,V);g.restore()};

/* ---------- 2. Shellback: a grumpy armored turtle; shell_in is the same shell with everything tucked in ---------- */
const RPW2M_TURT=[
 {sk:'#52c4a2',sh:'#ff8a78',sc:'#ffb8a0',seam:'#c8504e',rim:'#ffd27a',nail:'#fff2d0',ir:'#ffcf3a',lid:'#2e8a72',beak:'#ffd27a'},
 {sk:'#b4b850',sh:'#7a665c',sc:'#96807a',seam:'#3e3236',rim:'#b0662e',nail:'#e8dcc0',ir:'#ffcf3a',lid:'#6a6a2a',beak:'#d8c08a'},
 {sk:'#3a5cae',sh:'#22306e',sc:'#2e3e8a',seam:'#6af6ff',rim:'#2a3a7a',nail:'#9ab4ff',ir:'#ff5ad8',lid:'#1a2656',beak:'#5a6cc0'}];
/* the shell and its dressing; hid = tucked in (shell sits on the ground, eyes peek from the front opening) */
function rpw2mTurtShell(g,V,P,ph,hid){const a=ph*RPMT;
 const D=()=>{g.beginPath();g.moveTo(-28,-12);g.bezierCurveTo(-30,-35,-16,-48.5,-2,-48.5);g.bezierCurveTo(14,-48.5,25,-35,22.6,-13);g.quadraticCurveTo(-3,-7.6,-28,-12);g.closePath()};
 /* abyss: bony spikes along the ridge, behind the dome */
 if(V===2)for(const [x,y,t] of[[-20,-40,-.9],[-11,-46.6,-.45],[0,-48.6,0],[11,-45.6,.45],[19,-37,.9]]){g.save();g.translate(x,y);g.rotate(t);rpmP(g,[-2.6,2,0,-6.4,2.6,2]);rpmFS(g,rpmLG(g,0,-6,0,2,[0,'#9af8ff',.35,'#3a5aa0',1,'#141c44']),1.5);g.restore()}
 D();rpmFS(g,rpmRG(g,-6,-30,32,[0,rpmSh(P.sh,.3),.5,P.sh,.85,rpmSh(P.sh,-.3),1,rpmSh(P.sh,-.45)],-12,-42),2.6);
 /* scutes, clipped to the dome: raised plates with growth rings */
 g.save();D();g.clip();
 const S=[[-15,-38.6,7.6],[-1.6,-43,7.6],[11.6,-38,7.4],[-22,-24,7.6],[-8.4,-28,7.8],[5.4,-27,7.6],[18,-22,6.6]];
 for(const [x,y,r] of S){const H=[];for(let i=0;i<6;i++){const t=i*Math.PI/3+Math.PI/6;H.push(x+Math.cos(t)*r,y+Math.sin(t)*r*.86)}
  rpmP(g,H);g.fillStyle=rpmRG(g,x,y,r,[0,rpmSh(P.sc,.25),.6,P.sc,1,rpmSh(P.sh,-.1)],x-r*.3,y-r*.3);g.fill();
  if(V===2){g.save();g.globalCompositeOperation='lighter';g.lineWidth=2.6;g.strokeStyle='rgba(60,200,255,.35)';g.stroke();g.restore();g.lineWidth=1;g.strokeStyle=P.seam;g.stroke()}
  else{g.lineWidth=1.5;g.strokeStyle=rpmA(P.seam,.85);g.stroke();rpmP(g,H.map((v,i)=>i%2?y+(v-y)*.55:x+(v-x)*.55));g.lineWidth=.8;g.strokeStyle=rpmA(P.seam,.4);g.stroke()}}
 g.restore();
 /* rim of marginal scutes */
 g.beginPath();g.moveTo(-29,-11.4);g.quadraticCurveTo(-3,-6.6,23.4,-12.4);g.lineTo(23,-16.6);g.quadraticCurveTo(-3,-11.4,-28.4,-15.6);g.closePath();rpmFS(g,rpmLG(g,0,-17,0,-7,[0,rpmSh(P.rim,.25),1,rpmSh(P.rim,-.2)]),1.8);
 g.beginPath();for(let i=1;i<9;i++){const u=i/9,x=-28.6+u*52,y=-11.6-Math.sin(u*Math.PI)*4.6+u*-.8;g.moveTo(x,y-4.2);g.lineTo(x+.4,y)}g.lineWidth=1;g.strokeStyle=rpmA(RPMO,.55);g.stroke();
 g.beginPath();g.moveTo(-24,-26);g.bezierCurveTo(-22,-38,-14,-45,-4,-46);rpmHi(g,V===2?.3:.5,1.8);
 if(V===2)for(const [x,y] of[[-23,-13.4],[-12,-11.4],[0,-10.4],[12,-11.2]])rpw2mDot(g,x,y,.9,'#6af6ff',.55);
 /* dressing */
 if(V===0){const sw=Math.sin(a*2)*.08;
  /* a sea anemone waving on the back */
  for(let i=0;i<7;i++){const t=-1.5+i*.5+Math.sin(a+i)*.12;g.beginPath();g.moveTo(-17,-43);g.quadraticCurveTo(-17+Math.cos(t)*5,-47+Math.sin(t)*3.4,-17+Math.cos(t)*8,-46.6+Math.sin(t)*7-3);g.lineWidth=3.6;g.strokeStyle=RPMO;g.stroke();g.lineWidth=1.8;g.strokeStyle=i%2?'#c86af0':'#e89aff';g.stroke()}
  rpmEl(g,-17,-43.6,4,2.2,'#a04ad0',1.4);
  rpw2mCoral(g,-4,-46.4,.9,-.08+sw,'#ff6aa8','#ffd0e4');rpw2mCoral(g,7,-44.6,.66,.35-sw,'#ff9a3a','#ffe0a0');
  rpw2mStar(g,-9,-24,5,.4,'#ffd23a','#f08a1a');rpw2mSnail(g,12,-30,3.6,.6,'#fff0e0','#e8a888');rpw2mScal(g,-21,-31,3.4,-.5,'#fff4d8','#e8b080')}
 if(V===1){/* riveted iron plates, a porthole and a little deck cannon */
  rpw2mPlate(g,[-25,-20,-22,-33,-12,-42,-6,-35,-10,-22,-20,-16],[[-22,-22],[-20,-31],[-13,-38],[-9,-24]],'#8a7068');
  rpw2mPlate(g,[2,-44,13,-42,19,-30,18,-18,9,-17,4,-28],[[5,-40],[14,-38],[17,-21],[8,-20]],'#8a7068');
  rpmEl(g,-3.4,-25,4.6,4.2,'#d8a43a',1.8);rpmEl(g,-3.4,-25,2.9,2.6,rpmRG(g,-3.4,-25,3,[0,'#e8fbff',.5,'#7ac8e8',1,'#2a5a7a'],-4.4,-26),1.2);rpmAH(g,-3.8,-25.6,1.8,1.6,3.6,4.6,.8,.7);
  for(const [x,y,t,r] of[[-25,-12.6,-.6,2.2],[-19,-11,-.2,1.6],[16,-12,.3,2],[20,-14,.6,1.5],[-27,-18,-1.2,1.4]])rpw2mBarn(g,x,y,r,t);
  g.save();g.translate(-1,-48);rpmP(g,[-7,1,-5,-4,5,-4,7,1]);rpmFS(g,rpmCel(g,-7,-4,7,1,'#7a4a2a'),1.6);rpmEl(g,-4,1,2.2,2.2,'#5a3a22',1.2);rpmEl(g,4,1,2.2,2.2,'#5a3a22',1.2);
  g.save();g.translate(0,-4);g.rotate(-.32);rpmP(g,[-4,-2.6,13,-2,13,2,-4,2.6]);rpmFS(g,rpmLG(g,0,-3,0,3,[0,'#7a7e8a',.45,'#3a3c46',1,'#16161e']),1.6);
  rpmP(g,[11.6,-3,14.6,-3,14.6,3,11.6,3]);rpmFS(g,'#d8a43a',1.2);rpmP(g,[1,-2.8,3,-2.8,3,2.8,1,2.8]);rpmFS(g,'#d8a43a',1);rpmEl(g,14.6,0,1,1.8,'#0a0a10',0);g.restore();g.restore()}
 if(V===2){for(const [x,y,r,c] of[[-15,-38,1.4,'#6af6ff'],[-2,-43,1.6,'#ff5ad8'],[11,-38,1.4,'#6af6ff'],[-8,-27,1.3,'#6af6ff'],[5,-26,1.3,'#ff5ad8'],[-21,-23,1.1,'#6af6ff']])rpw2mDot(g,x,y,r,c,.6)}
 if(hid){/* the front opening and a wary pair of eyes */
  g.beginPath();g.ellipse(19.6,-15.4,4.4,3.4,-.5,0,RPMT);rpmFS(g,'#0a0614',1.6);
  const bl=Math.sin(a)>.86?.2:1;rpmEl(g,18.6,-16,1.3,1.5*bl,V===2?'#ff8ae8':'#fff6d8',0);rpmEl(g,21.2,-15.2,1.1,1.3*bl,V===2?'#ff8ae8':'#fff6d8',0);
  if(V===2)rpmGlow(g,20,-15.6,6,'#ff5ad8',.55);
  g.beginPath();g.ellipse(-26.6,-14,3.2,2.4,.4,0,RPMT);rpmFS(g,'#0a0614',1.4)}}
function rpw2mTurtle(g,ph,o,hid){const V=rpw2mV(o),P=RPW2M_TURT[V],a=ph*RPMT;
 if(hid){const rk=Math.sin(a)*.03;g.save();g.translate(0,7.4);g.rotate(rk);rpw2mTurtShell(g,V,P,ph,1);g.restore();return}
 const by=-Math.abs(Math.sin(a))*1.5,tl=Math.sin(a)*.02;
 const leg=(hx,p,col,near)=>{const fx=hx+4*Math.sin(p),l=Math.max(0,-Math.cos(p))*3.2,top=-15+by;
  g.beginPath();g.moveTo(hx-4.6,top);g.quadraticCurveTo(fx-5.6,-8-l,fx-5,-1.8-l);g.quadraticCurveTo(fx+1,-.4-l,fx+6.4,-1.8-l);g.quadraticCurveTo(fx+5,-8-l,hx+4.4,top);g.closePath();
  rpmFS(g,rpmCel(g,fx-6,top,fx+6,-l,col),2.2);
  g.beginPath();g.arc(fx-1,-8-l,2.2,3.6,5.4);g.moveTo(fx+3.4,-10-l);g.arc(fx+2,-10-l,1.6,0,2);g.lineWidth=.9;g.strokeStyle=rpmA(RPMO,.4);g.stroke();
  for(const x of[1,3.6,6])rpmEl(g,fx+x-.6,-1.6-l,1.2,1.4,P.nail,.9);
  if(near&&V===2)rpw2mDot(g,fx-1,-6-l,.9,'#6af6ff',.55)};
 const SKD=rpmSh(P.sk,-.25);
 leg(-12,a,SKD,0);leg(13,a+Math.PI,SKD,0);
 g.save();g.translate(0,-14);g.rotate(tl);g.translate(0,14+by);
 /* tail */
 rpmP(g,[-26,-14,-34,-10.6,-26,-9.6]);rpmFS(g,P.sk,1.6);
 /* neck and head: a hooked beak, heavy brow, one grumpy eye */
 const hb=Math.sin(a*2)*.7,hx=Math.sin(a*2+.5)*.9;
 g.beginPath();g.moveTo(14,-25);g.quadraticCurveTo(24+hx,-27+hb,28+hx,-27+hb);g.lineTo(29+hx,-18.6+hb);g.quadraticCurveTo(22,-15,15,-15);g.closePath();rpmFS(g,rpmCel(g,14,-28,28,-15,P.sk),2.2);
 g.beginPath();g.moveTo(17,-17.6);g.quadraticCurveTo(21,-16.6,24,-18.6);g.moveTo(19,-21);g.quadraticCurveTo(22,-20,25,-21.6);g.lineWidth=1;g.strokeStyle=rpmA(RPMO,.4);g.stroke();
 g.save();g.translate(hx,hb);
 rpmBl(g,[24,-28,28.4,-34,36,-35,42,-31.4,43.6,-25.6,40.6,-20.4,33,-18.4,25.6,-20]);rpmFS(g,rpmRG(g,34,-27,11,[0,rpmSh(P.sk,.38),.55,P.sk,1,rpmSh(P.sk,-.3)],31,-32),2.3);
 g.beginPath();g.moveTo(40,-29);g.quadraticCurveTo(46.6,-27.6,45.4,-21.4);g.quadraticCurveTo(44,-23,41,-22.6);g.closePath();rpmFS(g,rpmLG(g,40,-29,46,-21,[0,rpmSh(P.beak,.3),1,rpmSh(P.beak,-.3)]),1.6);
 g.beginPath();g.moveTo(41.6,-22.4);g.quadraticCurveTo(37,-21.6,32,-23.4);g.lineWidth=1.5;g.strokeStyle=RPMO;g.stroke();
 for(const [x,y,r] of[[30,-31,1],[27.6,-27.4,.8],[36,-32.6,.8]])rpmEl(g,x,y,r,r*.8,rpmSh(P.sk,-.18),0);
 if(V===2){rpw2mDot(g,29,-24.6,.9,'#6af6ff',.6);rpw2mDot(g,33.6,-33.4,.8,'#6af6ff',.6);rpmGlow(g,36.4,-28,8,'#ff5ad8',.5)}
 rpmEye(g,36.4,-28,3.4,P.ir,P.lid,.42);
 g.beginPath();g.moveTo(31.4,-33.4);g.quadraticCurveTo(36,-34.6,40.4,-31);g.lineWidth=2.2;g.strokeStyle=RPMO;g.stroke();
 if(V===1){rpw2mPatch(g,36.4,-28,3.8,27,-32,43.6,-25.4,.1);g.beginPath();g.moveTo(31,-25.6);g.lineTo(34,-22.6);g.lineWidth=1;g.strokeStyle='#e8d8c8';g.stroke()}
 g.restore();
 rpw2mTurtShell(g,V,P,ph,0);
 g.restore();
 leg(-17,a+Math.PI,P.sk,1);leg(9,a,P.sk,1)}
RPMD.shell=function(g,ph,o){rpw2mTurtle(g,ph,o,0)};
RPMD.shell_in=function(g,ph,o){rpw2mTurtle(g,ph,o,1)};

/* ---------- 3. Puffer: a round pufferfish waddling on two little flipper feet; puffer_big is the same fish puffed up ---------- */
const RPW2M_PUF=[
 {b:'#ffd23a',bl:'#fff4cc',sp:'#26b8c8',fin:'#2ac0b0',fin2:'#a8fff0',ir:'#2a7aff',lid:'#e0a020',lip:'#ff7a8a',ft:'#ff9a3a'},
 {b:'#4e566e',bl:'#b8bcc8',sp:'#2a3040',fin:'#9a6a46',fin2:'#d8b080',ir:'#ffcf3a',lid:'#323a4e',lip:'#c88a7a',ft:'#5a4a3a'},
 {b:'#2e3e92',bl:'#4a5eb8',sp:'#6af6ff',fin:'#6af0ff',fin2:'#1e3a8a',ir:'#d8ff6a',lid:'#1a2456',lip:'#4a3a8a',ft:'#34469c'}];
function rpw2mPuffer(g,ph,o,big){const V=rpw2mV(o),P=RPW2M_PUF[V],a=ph*RPMT,R=big?22.6:17,rk=Math.sin(a)*(big?.05:.09),by=-Math.abs(Math.sin(a))*(big?2.2:1.6),
 cx=2,cy=-(big?R+6.6:R+7.4)+by,SPL=big?6.2:3,NS=big?20:15;
 /* little flipper feet */
 const foot=(hx,p,col)=>{const fx=hx+(big?1.6:2.6)*Math.sin(p),l=Math.max(0,-Math.cos(p))*(big?1.4:2.6);
  rpmLimb(g,[hx,cy+R*.75,fx+.6,-4-l],big?3.4:4.2,col,1.8);g.save();g.translate(fx,-2.6-l);g.rotate(Math.cos(p)*.12);
  g.beginPath();g.moveTo(-2.6,-1.8);g.quadraticCurveTo(2,-3.6,7.4,-1.6);g.quadraticCurveTo(8.4,0,7.4,1.4);g.quadraticCurveTo(4,.4,3.6,1.8);g.quadraticCurveTo(1,.6,-2.6,1.6);g.closePath();rpmFS(g,rpmLG(g,0,-3,0,2,[0,rpmSh(col,.3),1,col]),1.6);
  g.beginPath();g.moveTo(.4,-1.2);g.lineTo(5.6,-.8);g.moveTo(.4,0);g.lineTo(3.6,1);g.lineWidth=.7;g.strokeStyle=rpmA(RPMO,.45);g.stroke();g.restore()};
 foot(-3,a+Math.PI,rpmSh(P.ft,-.25));
 g.save();g.translate(cx,cy);g.rotate(rk);
 /* tail fin and dorsal fin behind the body */
 const tw=Math.sin(a*2)*.22;g.save();g.translate(-R+1,-1);g.rotate(tw);
 rpw2mFin(g,[0,0,-9,-9,-12,-7,-9,-1,-12,6,-9,8.6],P.fin2,P.fin,V===2?.6:1,1);g.restore();
 rpw2mFin(g,[-3,-R+2,-6,-R-6,-12,-R-4.6,-10,-R+4],P.fin2,P.fin,V===2?.6:1,1);
 /* spikes all round, then the body over their roots */
 for(let i=0;i<NS;i++){const t=i/NS*RPMT+.2,l=SPL*(.75+.25*((i*7)%3)/2),x=Math.cos(t)*(R-1),y=Math.sin(t)*(R-1)*.94;g.save();g.translate(x,y);g.rotate(t+Math.PI/2);
  rpmP(g,[-1.5*(big?1.6:1),1,0,-l-1,1.5*(big?1.6:1),1]);rpmFS(g,big?rpmLG(g,0,-l,0,1,[0,'#fffbe8',1,P.bl]):P.bl,big?1.1:1.3);g.restore()}
 rpmEl(g,0,0,R,R*.94,rpmRG(g,0,0,R*1.1,[0,rpmSh(P.b,.42),.45,P.b,.8,rpmSh(P.b,-.2),1,rpmSh(P.b,-.4)],-R*.35,-R*.45),2.6);
 /* the pale belly */
 g.save();g.beginPath();g.ellipse(0,0,R,R*.94,0,0,RPMT);g.clip();rpmEl(g,R*.18,R*.62,R*.95,R*.62,rpmA(P.bl,.95),0);g.restore();
 /* spots */
 const SP=[[-8,-9,2.6],[-1,-12,2],[-11,1,2.2],[-4,-3,1.6],[5,-7,1.4],[-12,-6,1.2]];
 if(V<2)for(const [x,y,r] of SP)rpmEl(g,x*R/17,y*R/17,r*R/17,r*R/17*.9,rpmA(P.sp,V?.6:.85),0);
 else for(const [x,y,r] of SP)rpw2mDot(g,x*R/17,y*R/17,r*.6,r>2?'#ff5ad8':'#6af6ff',.55);
 /* little spike ticks on the skin */
 rpmAH(g,0,0,R*.82,R*.76,3.5,4.6,.55,2);rpmEl(g,-R*.48,-R*.5,R*.12,R*.08,'rgba(255,255,255,.75)',0,-.6);
 /* wreck: one riveted iron band round the middle and a painted skull, like a cannon bomb */
 if(V===1){g.save();g.beginPath();g.ellipse(0,0,R,R*.94,0,0,RPMT);g.clip();const yb=R*.18;
  g.beginPath();g.ellipse(0,yb,R*1.1,3.4,0,0,RPMT);g.lineWidth=7.4;g.strokeStyle=RPMO;g.stroke();g.lineWidth=5;g.strokeStyle='#6e5a52';g.stroke();g.lineWidth=1.2;g.strokeStyle='#c08a5e';g.stroke();g.restore();
  for(let i=0;i<5;i++){const t=Math.PI*(.15+i*.17);rpmEl(g,Math.cos(t)*R*.92,yb+Math.sin(t)*3.4,.9,.9,'#e0d0c0',.6)}
  const kx=-R*.22,ky=-R*.3;rpmEl(g,kx,ky,3,2.7,'#f4ecd8',1.1);g.fillStyle=RPMO;g.fillRect(kx-1.6,ky-.9,1.1,1.1);g.fillRect(kx+.5,ky-.9,1.1,1.1);
  g.beginPath();g.moveTo(kx-3.6,ky+2.6);g.lineTo(kx+3.6,ky+5.2);g.moveTo(kx+3.6,ky+2.6);g.lineTo(kx-3.6,ky+5.2);g.lineWidth=2.6;g.strokeStyle=RPMO;g.stroke();g.lineWidth=1.2;g.strokeStyle='#f4ecd8';g.stroke()}
 /* gill line and the pectoral fin behind it (flaps) */
 g.beginPath();g.arc(R*.06,-R*.04,R*.36,-.9,.9);g.lineWidth=1.3;g.strokeStyle=rpmA(RPMO,.55);g.stroke();
 const fl=big?.45+.55*Math.abs(Math.sin(a*4)):.55+.45*Math.abs(Math.cos(a*2));g.save();g.translate(R*.14,R*.08);g.scale(1,fl);g.rotate(.15);
 rpmP(g,[0,-2.2,-5,-6.4,-9.4,-5.4,-12,-1.4,-10,3.6,-5,4,0,2.2]);g.save();if(V===2)g.globalAlpha=.62;g.fillStyle=rpmLG(g,0,0,-12,0,[0,P.fin,1,P.fin2]);g.fill();g.restore();g.lineWidth=1.6;g.strokeStyle=RPMO;g.stroke();
 g.beginPath();for(const [x,y] of[[-6.6,-5.2],[-10.6,-3.6],[-11,1.4],[-7.6,3.6]]){g.moveTo(-.6,0);g.lineTo(x,y)}g.lineWidth=.8;g.strokeStyle=rpmA(RPMO,.45);g.stroke();g.restore();
 if(V===1)rpw2mRing(g,R*.1,R*.3,1.8);
 /* face: big eye, pouty lips and two buck teeth */
 const ex=R*.5,ey=-R*.3,er=big?5.6:5;
 if(V===2)rpmGlow(g,ex,ey,er*2.6,'#d8ff6a',.4);
 rpmEye(g,ex,ey,er,P.ir,P.lid,big?.52:.38);
 g.beginPath();g.moveTo(ex-er*1.2,ey-er*1.15);g.quadraticCurveTo(ex,ey-er*1.75,ex+er*1.1,ey-er*.9);g.lineWidth=2.4;g.strokeStyle=RPMO;g.stroke();
 const mx=R*.98,my=R*.14;
 if(V===2){g.beginPath();g.ellipse(mx,my,3.4,4.4,0,0,RPMT);rpmFS(g,'#08061a',1.8);for(const [x,y,l] of[[-1.6,-3.6,3],[1.4,-3.6,2.6],[-1.6,3.6,-2.6],[1.2,3.6,-2.4]]){rpmP(g,[mx+x-.7,my+y,mx+x+.7,my+y,mx+x,my+y+l]);g.fillStyle='#e8f8ff';g.fill()}
  rpw2mLure(g,R*.55,-R*.88,R*1.5,-R*1.45,R*1.36,-R*.42,2.4,'#7affff','#2a3a7a')}
 else{rpmEl(g,mx,my,big?2.6:3.6,big?2.8:4,P.lip,2);rpmEl(g,mx+.4,my,big?1.1:1.6,big?1.3:2,'#3a0a1a',0);
  if(!big){rpmP(g,[mx-.4,my-2.2,mx+1.4,my-2.2,mx+1.4,my-.2,mx-.4,my-.2]);rpmFS(g,'#fffbe8',.8)}}
 if(big)for(const sx of[1]){rpmEl(g,R*.62,R*.24,3,2,rpmA(V===2?'#ff5ad8':'#ff6a6a',.4),0)}
 /* coral: a hibiscus behind the eye */
 if(V===0){g.save();g.translate(-R*.05,-R*.86);g.rotate(-.3);for(let i=0;i<5;i++){const t=i/5*RPMT;g.save();g.rotate(t);g.beginPath();g.moveTo(0,0);g.bezierCurveTo(-4,-3,-3.4,-8.4,0,-8);g.bezierCurveTo(3.4,-8.4,4,-3,0,0);rpmFS(g,rpmLG(g,0,0,0,-8,[0,'#c8183a',.5,'#ff4a6a',1,'#ff9ab0']),1.2);g.restore()}
  rpmEl(g,0,0,1.8,1.8,'#ffd23a',.8);g.beginPath();g.moveTo(0,0);g.lineTo(3.6,-4.6);g.lineWidth=1.2;g.strokeStyle='#ffd23a';g.stroke();rpmEl(g,3.8,-4.8,.9,.9,'#fff4a0',0);g.restore()}
 /* wreck: a lit fuse on a brass cap */
 if(V===1){g.save();g.translate(-R*.3,-R*.92);g.rotate(-.25);rpmP(g,[-3,1,-2.4,-2,2.4,-2,3,1]);rpmFS(g,'#d8a43a',1.3);
  g.beginPath();g.moveTo(0,-2);g.bezierCurveTo(-1,-6,4,-7,2.6,-11);g.lineWidth=3.4;g.strokeStyle=RPMO;g.stroke();g.lineWidth=1.6;g.strokeStyle='#c8a46a';g.stroke();
  g.setLineDash([1,1.4]);g.lineWidth=1.6;g.strokeStyle='#7a5a3a';g.stroke();g.setLineDash([]);
  const fk=.75+.25*Math.sin(a*4);rpmGlow(g,2.6,-11.4,9*fk,'#ffb43a',.85);rpvTwk(g,2.6,-11.4,1.3*fk,1,'#fff4c0');rpmEl(g,2.6,-11.4,1.4,1.4,'#ffd24a',0);
  rpvSparks(g,0,5,-12,7,ph,3,5);g.restore()}
 g.restore();
 foot(6,a,P.ft)}
RPMD.puffer=function(g,ph,o){rpw2mPuffer(g,ph,o,0)};
RPMD.puffer_big=function(g,ph,o){rpw2mPuffer(g,ph,o,1)};

/* ---------- 4. Jellyglide: a flying jellyfish; the bell pulses and the tentacles trail behind ---------- */
const RPW2M_JEL=[
 {bell:'#ffb0dc',rim:'#f07ac0',in:'#b05ad8',ten:'#ff8ac8',arm:'#ffd4ee',ir:'#b04ad0',lid:'#e07ab8',a:.78},
 {bell:'#9ae8cc',rim:'#4ab89a',in:'#ffb84a',ten:'#6ad0b0',arm:'#d4fff0',ir:'#ff8a2a',lid:'#4aa88a',a:.8},
 {bell:'#4a3aa8',rim:'#6af6ff',in:'#ff5ad8',ten:'#6af0ff',arm:'#9a8aff',ir:'#6af6ff',lid:'#2a1e6a',a:.72}];
RPMD.jelly=function(g,ph,o){const V=rpw2mV(o),P=RPW2M_JEL[V],a=ph*RPMT,k=Math.sin(a),sx=1+.07*k,sy=1-.08*k,bo=-k*2.2,by=-Math.cos(a)*1.4,cy=-30+bo+by;
 /* tentacles: thin trailing lines with a travelling wave */
 const T=(x0,n,len,w,col,ph0,glow)=>{const pts=[];for(let j=0;j<=n;j++){const u=j/n;pts.push(x0*sx-u*len*.55+Math.sin(a*1+u*5+ph0)*2.6*u,cy+2+u*len)}
  const path=()=>{g.beginPath();g.moveTo(pts[0],pts[1]);for(let j=2;j<pts.length;j+=2)g.lineTo(pts[j],pts[j+1])};
  path();g.lineWidth=w+2.4;g.strokeStyle=RPMO;g.stroke();path();g.lineWidth=w;g.strokeStyle=col;g.stroke();
  if(glow){g.save();g.globalCompositeOperation='lighter';path();g.lineWidth=w*2.4;g.strokeStyle=rpmA(col,.25);g.stroke();g.restore()}return pts};
 const TL=[];for(let i=0;i<6;i++)TL.push(T(-12+i*4.6,9,(22+(i%3)*5)*(V===2?1.3:1),1.3,rpmSh(P.ten,-.12),i*1.3,V===2));
 if(V===2)for(const p of TL)for(let j=4;j<p.length;j+=6)rpmEl(g,p[j],p[j+1],.9,.9,'#e8ffff',0);
 /* frilly oral arms */
 for(const [x0,len,ph0] of[[-4,20,0],[3,17,2]]){const n=8,L=[],Rr=[];for(let j=0;j<=n;j++){const u=j/n,x=x0*sx-u*len*.4+Math.sin(a+u*4+ph0)*2.2*u,y=cy+1+u*len,w=2.8*(1-u*.6)+Math.sin(u*14+a)*.7;L.push(x-w,y);Rr.unshift(x+w,y)}
  rpmBl(g,L.concat(Rr));g.save();g.globalAlpha=.9;rpmFS(g,rpmLG(g,0,cy,0,cy+len,[0,P.arm,1,rpmSh(P.ten,-.1)]),1.4);g.restore()}
 if(V===1){/* a ship lantern swinging from the arms */const sw=Math.sin(a+.6)*.2;g.save();g.translate(0,cy+12);g.rotate(sw);g.beginPath();g.moveTo(-3,-12);g.quadraticCurveTo(-1,-6,0,0);g.moveTo(3,-12);g.quadraticCurveTo(1,-6,0,0);g.lineWidth=2.6;g.strokeStyle=RPMO;g.stroke();g.lineWidth=1.2;g.strokeStyle=P.ten;g.stroke();rpw2mLantern(g,0,0,.95,ph);g.restore()}
 if(V===0){/* a string of pearls looped over the arms */g.beginPath();for(let j=0;j<=6;j++){const u=j/6,x=-6+u*12,y=cy+8+Math.sin(u*Math.PI)*4.6+Math.sin(a+u*3)*.6;rpmEl(g,x,y,1.2,1.2,rpmRG(g,x,y,1.4,[0,'#ffffff',1,'#e8d8f0'],x-.4,y-.4),.8)}}
 /* the bell */
 g.save();g.translate(0,cy);g.scale(sx,sy);
 const BELL=()=>{g.beginPath();g.moveTo(-17.4,2);g.bezierCurveTo(-18.6,-14,-9,-21.4,0,-21.4);g.bezierCurveTo(9,-21.4,18.6,-14,17.4,2);for(let i=0;i<8;i++){const x0=17.4-i*4.35,x1=x0-4.35;g.quadraticCurveTo((x0+x1)/2,5.2,x1,2)}g.closePath()};
 if(V===1)rpmGlow(g,0,-6,26,'#ffb84a',.5);if(V===2)rpmGlow(g,0,-6,30,'#ff5ad8',.35);
 BELL();g.save();g.globalAlpha=P.a;g.fillStyle=rpmRG(g,0,-8,22,[0,rpmSh(P.bell,.5),.5,P.bell,1,rpmSh(P.bell,-.3)],-6,-14);g.fill();g.restore();
 /* the inner pattern seen through the bell */
 g.save();BELL();g.clip();
 if(V===0)for(const [x,y] of[[-6,-6],[6,-6],[-2.4,-11],[2.4,-1.6]]){g.beginPath();g.ellipse(x,y,3.4,2.6,0,0,RPMT);g.lineWidth=2.2;g.strokeStyle=rpmA(P.in,.7);g.stroke()}
 if(V===1){rpmGlow(g,0,-4,16,'#ffd86a',.55);g.beginPath();g.ellipse(0,-6,9,6,0,0,RPMT);g.lineWidth=1.4;g.strokeStyle=rpmA(P.in,.5);g.stroke()}
 if(V===2){rpmGlow(g,0,-7,13,P.in,.6);for(const [x,y] of[[-8,-8],[8,-8],[0,-15]])rpw2mDot(g,x,y,1.2,'#ff8ae8',.5)}
 rpmBl(g,[-16,2,-12,-3,0,-4.6,12,-3,16,2,0,4]);g.fillStyle=rpmA(rpmSh(P.bell,-.35),.35);g.fill();
 g.restore();
 BELL();g.lineWidth=2.4;g.strokeStyle=RPMO;g.stroke();
 g.beginPath();for(let i=0;i<8;i++){const x0=17.4-i*4.35,x1=x0-4.35;i?g.quadraticCurveTo((x0+x1)/2,5.2,x1,2):(g.moveTo(x0,2),g.quadraticCurveTo((x0+x1)/2,5.2,x1,2))}g.lineWidth=1.6;g.strokeStyle=P.rim;g.stroke();
 if(V===2)for(let i=0;i<9;i++)rpw2mDot(g,17.4-i*4.35,2.2,.9,i%2?'#6af6ff':'#b8ffff',.55);
 rpmAH(g,-1,-4,14,15,3.6,4.5,.7,2.2);rpmEl(g,-10,-13,1.6,1.1,'rgba(255,255,255,.8)',0,-.7);
 /* face */
 if(V===2){rpmGlow(g,-4.6,-7.6,8,'#6af6ff',.45);rpmGlow(g,5,-7.8,7,'#6af6ff',.45)}
 rpmEye(g,-4.4,-7.8,3.4,P.ir,P.lid,.36);rpmEye(g,5,-8,3,P.ir,P.lid,-.36);
 g.beginPath();g.moveTo(-3,-2.6);g.quadraticCurveTo(.6,0,4,-2.8);g.lineWidth=1.5;g.strokeStyle=RPMO;g.stroke();
 for(const x of[-1.4,2]){rpmP(g,[x-.8,-1.8,x+.8,-1.8,x,-.2]);g.fillStyle='#fffbe8';g.fill()}
 /* dressing on the dome */
 if(V===0)rpw2mStar(g,9.6,-17,4.2,.5,'#ffd23a','#f08a1a');
 if(V===1)rpw2mTri(g,1.6,-19.6,.72,.16,'#2c2232','#ffcf4a');
 g.restore();
 if(V===2)for(const [x,t,c] of[[-6,-1,'#6af6ff'],[1,0,'#ff5ad8'],[7,1,'#6af6ff']]){const sw2=Math.sin(a+t)*2;rpw2mLure(g,x*sx,cy-20*sy,x*1.4*sx+t*2,cy-30,x*1.6+t*4+sw2,cy-34+Math.abs(t)*3,1.5,c,'#4a3aa8')}
 if(V<2)for(let i=0;i<2;i++){const u=(ph+i*.5)%1;rpw2mBub(g,-14-u*8,cy-4-u*14+Math.sin(u*8+i)*1.4,1+u*1.4,1-u)}
 else rpvSparks(g,-14,10,cy+18,30,ph,4,7,['#6af6ff','#ff8ae8'])};

/* ---------- 5. Barnacle Brute: a huge hermit crab hauling a barnacle-crusted home (a conch, a pirate barrel, a glowing deep shell) ---------- */
const RPW2M_BRU=[
 {b:'#e8503a',lg:'#d8442e',sh:'#ffb488',band:'#ff7a52',lip:'#ff8aa8',ir:'#2ad0c8',lid:'#b8301e',tip:'#fff0d8'},
 {b:'#b03c2a',lg:'#962e20',sh:'#9a6a40',band:'#6a4628',lip:'#4a2a1a',ir:'#ffcf3a',lid:'#6a2016',tip:'#f0dcc0'},
 {b:'#3c42a4',lg:'#30368e',sh:'#232c6c',band:'#2e3a86',lip:'#ff5ad8',ir:'#6af6ff',lid:'#1a1e56',tip:'#9ab4ff'}];
RPMD.brute=function(g,ph,o){const V=rpw2mV(o),P=RPW2M_BRU[V],a=ph*RPMT,by=-Math.abs(Math.sin(a))*2.2,tl=Math.sin(a)*.015;
 /* walking legs: two pairs out of the shell opening, arched, with dark pointed tips */
 const leg=(hx,hy,fx0,p,col,w)=>{const fx=fx0+5*Math.sin(p),l=Math.max(0,-Math.cos(p))*4.4,kx=hx+9+(fx-fx0)*.4,ky=hy-9-l*.5,ax=fx+5,ay=-13-l;
  rpmLimb(g,[hx,hy,kx,ky],w,col,2);rpmLimb(g,[kx,ky,ax,ay],w*.86,col,2);rpmLimb(g,[ax,ay,fx,-l-3.4],w*.66,col,2);rpmP(g,[fx-2.6,-l-4.6,fx,-l-4,fx-.6,-l+.4]);rpmFS(g,rpmSh(col,-.45),1.2);
  rpmEl(g,kx,ky,w*.44,w*.44,rpmSh(col,.15),1.3);rpmEl(g,ax,ay,w*.36,w*.36,rpmSh(col,.15),1.2);for(const t of[.4,.75]){const x=kx+(ax-kx)*t,y=ky+(ay-ky)*t;rpmP(g,[x+.4,y-1.2,x+3.6,y-.6,x+.8,y+1]);rpmFS(g,P.tip,.8)}
  g.beginPath();g.moveTo(hx,hy-w*.3);g.lineTo(kx-1,ky-w*.3);g.moveTo(kx+.6,ky-w*.3);g.lineTo(ax+.6,ay-w*.3);rpmHi(g,.3,1);if(V===2)rpw2mDot(g,ax,ay,1,'#6af6ff',.55)};
 const LD=rpmSh(P.lg,-.3);leg(12,-34+by,22,a+Math.PI,LD,5);leg(18,-34+by,36,a,LD,5);
 /* the far (small) claw */
 g.save();g.translate(0,by);rpmLimb(g,[16,-50,24,-56,30,-58],4.6,rpmSh(P.b,-.3),2);
 g.save();g.translate(32,-58);g.rotate(-.5);rpmBl(g,[-4,-4,6,-6,12,-3,12,3,4,5,-4,4]);rpmFS(g,rpmCel(g,-4,-6,12,5,rpmSh(P.b,-.25)),2);
 g.beginPath();g.moveTo(10,-3);g.quadraticCurveTo(17,-6,19,-2);g.quadraticCurveTo(15,-1.6,11,0);g.closePath();rpmFS(g,rpmSh(P.b,-.25),1.6);g.restore();g.restore();
 g.save();g.translate(0,-30);g.rotate(tl);g.translate(0,30+by);
 /* the home on its back */
 if(V===1){/* a pirate barrel: staves, iron hoops, barnacles, a harpoon and a Jolly Roger */
  g.save();g.translate(-18,-50);g.rotate(-.32);
  const BR=()=>{g.beginPath();g.moveTo(-17,-30);g.quadraticCurveTo(-23,0,-17,30);g.lineTo(17,30);g.quadraticCurveTo(23,0,17,-30);g.closePath()};
  /* the flag pole and flag first: behind the barrel */
  g.restore();
  const fw=Math.sin(a*2)*2.4;g.beginPath();g.moveTo(-28,-74);g.lineTo(-40,-108);g.lineWidth=4.4;g.strokeStyle=RPMO;g.stroke();g.lineWidth=2.2;g.strokeStyle='#8a5a32';g.stroke();
  g.beginPath();g.moveTo(-39,-106);g.quadraticCurveTo(-30,-110+fw,-18,-106+fw*1.2);g.lineTo(-20,-100+fw);g.lineTo(-16,-96+fw*1.1);g.quadraticCurveTo(-28,-94+fw*.6,-36,-96);g.closePath();rpmFS(g,rpmLG(g,-39,-106,-16,-96,[0,'#2a2230',1,'#140e1a']),1.8);
  rpmEl(g,-28,-101+fw*.6,2.6,2.3,'#f4ecd8',.9);g.beginPath();g.moveTo(-31.6,-97.6+fw*.5);g.lineTo(-24.4,-95+fw*.5);g.moveTo(-24.4,-97.6+fw*.5);g.lineTo(-31.6,-95+fw*.5);g.lineWidth=1.2;g.strokeStyle='#f4ecd8';g.stroke();
  g.save();g.translate(-18,-50);g.rotate(-.32);
  BR();rpmFS(g,rpmLG(g,-22,0,22,0,[0,'#c89058',.3,'#a8703e',.7,'#7a4a26',1,'#4e2c16']),2.8);
  g.save();BR();g.clip();g.beginPath();for(const x of[-11,-4,3,10]){g.moveTo(x*1.02,-31);g.quadraticCurveTo(x*1.25,0,x*1.02,31)}g.lineWidth=1.3;g.strokeStyle='rgba(40,18,6,.55)';g.stroke();
  for(const y of[-21,0,21]){g.beginPath();g.moveTo(-24,y);g.quadraticCurveTo(0,y+3.4,24,y);g.lineWidth=6.6;g.strokeStyle=RPMO;g.stroke();g.lineWidth=4.2;g.strokeStyle='#5e5a5e';g.stroke();g.lineWidth=1;g.strokeStyle='#9a9298';g.stroke();
   g.fillStyle='rgba(180,88,42,.6)';g.fillRect(-8,y,3,2.2);g.fillRect(9,y+.6,2.4,2.6)}
  g.restore();
  g.beginPath();g.ellipse(0,-30,17,4.6,0,0,RPMT);rpmFS(g,rpmLG(g,0,-34,0,-26,[0,'#d8a468',1,'#9a6a3a']),2.2);rpmEl(g,4,-30,2.6,1.2,'#3a2414',1);
  g.beginPath();g.moveTo(-12,-24);g.quadraticCurveTo(-17,0,-13,22);rpmHi(g,.35,2);
  g.restore();
  for(const [x,y,r,t] of[[-38,-34,3.4,-1.3],[-36,-26,2.4,-1.6],[-30,-18,2.8,-2.2],[-8,-30,2.2,.7],[-4,-40,2.8,.9],[-22,-76,2.2,-.4],[-31,-60,2,-1.1]])rpw2mBarn(g,x,y,r,t,'#d8ccb8');
  for(const [x,y,r] of[[-26,-30,3.6],[-20,-26,2.8],[-27,-23,2.4],[-14,-62,2.6]])rpw2mBarnT(g,x,y,r,'#e0d6c4');
  /* harpoon stuck in the barrel, rope trailing */
  g.beginPath();g.moveTo(-24,-56);g.lineTo(-52,-78);g.lineWidth=4.2;g.strokeStyle=RPMO;g.stroke();g.lineWidth=2.2;g.strokeStyle='#9a6a3a';g.stroke();
  rpmP(g,[-24,-56,-19,-55,-21,-58.6]);rpmFS(g,'#9aa2b0',1.2);rpmP(g,[-52,-78,-56,-77,-54,-82]);rpmFS(g,'#c8b88a',1.2);
  g.beginPath();g.moveTo(-46,-73.4);g.bezierCurveTo(-50,-60,-44+Math.sin(a)*2,-48,-50,-36);g.lineWidth=3.4;g.strokeStyle=RPMO;g.stroke();g.lineWidth=1.6;g.strokeStyle='#e0c890';g.stroke()}
 else{/* a conch with a spire, knobs and growth bands */
  const SH=()=>{g.beginPath();g.moveTo(6,-28);g.bezierCurveTo(-6,-14,-38,-10,-46,-26);g.bezierCurveTo(-52,-44,-44,-64,-28,-70);g.bezierCurveTo(-14,-74,4,-72,9,-58);g.bezierCurveTo(12,-46,10,-34,6,-28);g.closePath()};
  /* the spire: stacked whorls up and back, each with a row of knobs */
  const WH=[[-34,-90,4.6,2.6,-.55],[-30,-82,8,4.4,-.45],[-22,-73,14,7,-.32]];
  rpmP(g,[-41,-100,-36,-88,-31,-92]);rpmFS(g,rpmSh(P.sh,.2),1.8);
  for(const [x,y,rx,ry,r] of WH){rpmEl(g,x,y,rx,ry,rpmRG(g,x,y,rx,[0,rpmSh(P.sh,.4),.6,P.sh,1,rpmSh(P.sh,-.35)],x-rx*.3,y-ry*.5),2.4,r);
   for(let i=0;i<3;i++){const t=Math.PI*(1.2+i*.3),kx=x+Math.cos(t)*rx*.92*Math.cos(r)-Math.sin(t)*ry*.92*Math.sin(r),ky=y+Math.cos(t)*rx*.92*Math.sin(r)+Math.sin(t)*ry*.92*Math.cos(r);
    g.save();g.translate(kx,ky);g.rotate(t+Math.PI/2+r);rpmP(g,[-rx*.16-1,1,0,-rx*.28-2.4,rx*.16+1,1]);rpmFS(g,rpmLG(g,-3,0,3,0,[0,rpmSh(P.sh,.45),1,rpmSh(P.sh,-.3)]),1.4);if(V===2&&i===1)rpw2mDot(g,0,-rx*.2-1.6,.8,'#6af6ff',.6);g.restore()}}
  SH();rpmFS(g,rpmRG(g,-16,-50,40,[0,rpmSh(P.sh,.35),.5,P.sh,.85,rpmSh(P.sh,-.25),1,rpmSh(P.sh,-.42)],-24,-64),2.8);
  g.save();SH();g.clip();
  for(const [y0,k] of[[-30,1],[-46,.9],[-62,.8]]){g.beginPath();g.moveTo(-50,y0+8);g.bezierCurveTo(-30,y0-6,-8,y0-8,14,y0-18);g.lineTo(14,y0-12);g.bezierCurveTo(-8,y0-2,-30,y0,-50,y0+14);g.closePath();g.fillStyle=V===2?'rgba(60,180,255,.16)':rpmA(P.band,.55*k);g.fill()}
  /* whorl sutures */
  const SU=()=>{g.beginPath();g.moveTo(-48,-38);g.bezierCurveTo(-38,-56,-14,-62,9,-52)};
  if(V===2){g.save();g.globalCompositeOperation='lighter';SU();g.lineWidth=4.6;g.strokeStyle='rgba(60,200,255,.35)';g.stroke();g.restore();SU();g.lineWidth=1.4;g.strokeStyle='#6af6ff';g.stroke()}
  else{SU();g.lineWidth=1.8;g.strokeStyle=rpmA(RPMO,.6);g.stroke()}
  g.restore();
  /* knobs along the shoulder */
  for(const [x,y,t] of[[-40,-56,-1.1],[-30,-66,-.6],[-16,-70,-.1],[-2,-66,.5]]){g.save();g.translate(x,y);g.rotate(t);rpmP(g,[-3.4,1,0,-7,3.4,1]);rpmFS(g,rpmLG(g,-3,0,3,0,[0,rpmSh(P.sh,.45),1,rpmSh(P.sh,-.3)]),1.6);if(V===2)rpw2mDot(g,0,-5.6,.9,'#6af6ff',.6);g.restore()}
  g.beginPath();g.moveTo(-42,-36);g.bezierCurveTo(-42,-52,-34,-64,-24,-70);rpmHi(g,V===2?.3:.5,2);
  /* barnacle clusters, each cone standing out of the shell along its outward normal */
  for(const [x,y,r] of[[-45,-34,4.6],[-46,-44,3.8],[-41,-25,4],[-36,-18,3.4],[-28,-14,3.8],[-44,-54,3],[-38,-60,3.4],[-30,-64,2.8],[-18,-12,2.6]]){const t=Math.atan2(y+40,x+16)+Math.PI/2;rpw2mBarn(g,x,y,r,t,V===2?'#6a7aaa':'#f4eee0')}
  for(const [x,y,r] of[[6,-50,3.2],[8,-40,2.6]])rpw2mBarn(g,x,y,r,1.3,V===2?'#6a7aaa':'#f4eee0');
  for(const [x,y,r] of[[-38,-38,4.4],[-31,-32,3.6],[-36,-28,3],[-29,-41,2.8],[-12,-56,3.4],[-6,-52,2.6],[-20,-22,3]])rpw2mBarnT(g,x,y,r,V===2?'#7a8ac0':'#f4eee0');
  if(V===0){rpw2mCoral(g,-14,-76,1.05,.15,'#ff6aa8','#ffd0e4');rpw2mCoral(g,-4,-70,.8,.55,'#ff9a3a','#ffe0a0');rpw2mStar(g,-26,-46,6,.2,'#ffd23a','#f08a1a');rpw2mScal(g,-12,-34,4.6,.3,'#fff4d8','#e8b080');
   /* seaweed trailing from the shell */
   for(const [x,y,l,d] of[[-47,-48,15,0],[-46,-38,11,1.6]]){g.beginPath();g.moveTo(x,y);for(let j=1;j<=5;j++){const u=j/5;g.lineTo(x-u*3+Math.sin(a*2+u*4+d)*2,y+u*l)}g.lineWidth=5;g.strokeStyle=RPMO;g.stroke();g.lineWidth=2.6;g.strokeStyle=rpw2mWeed(d);g.stroke()}}
  if(V===2){for(const [x,y,r,c] of[[-30,-52,1.6,'#6af6ff'],[-18,-40,1.4,'#ff5ad8'],[-36,-34,1.2,'#6af6ff'],[-8,-60,1.3,'#6af6ff'],[-22,-64,1.1,'#ff5ad8']])rpw2mDot(g,x,y,r,c,.6)}
  /* the glossy lip of the opening */
  g.beginPath();g.ellipse(6,-46,7,17,.15,0,RPMT);rpmFS(g,rpmLG(g,0,-62,0,-30,[0,rpmSh(P.lip,.4),1,rpmSh(P.lip,-.3)]),2)}
 /* the crab: thorax, eye stalks, antennae */
 const aw=Math.sin(a*2)*2;
 for(const [x0,cx,x1,y1] of[[22,6,-14,-100],[26,18,4,-104]]){g.beginPath();g.moveTo(x0,-58);g.quadraticCurveTo(cx,-96,x1+aw,y1+aw*.5);g.lineWidth=3.6;g.strokeStyle=RPMO;g.stroke();g.lineWidth=1.6;g.strokeStyle=rpmSh(P.b,.2);g.stroke()}
 const E=[[17,-71+Math.sin(a*2+.4)],[27,-69+Math.sin(a*2+1.4)]];
 rpmLimb(g,[16,-58,15,-64,E[0][0],E[0][1]],3.4,rpmSh(P.b,.05),2);rpmLimb(g,[24,-58,26,-63,E[1][0],E[1][1]],3.4,rpmSh(P.b,.05),2);
 rpmBl(g,[2,-30,0,-48,8,-60,20,-62,30,-54,32,-42,26,-30,12,-26]);rpmFS(g,rpmRG(g,16,-44,22,[0,rpmSh(P.b,.38),.5,P.b,1,rpmSh(P.b,-.4)],10,-54),2.6);
 g.beginPath();g.moveTo(6,-52);g.quadraticCurveTo(16,-48,28,-50);g.moveTo(4,-40);g.quadraticCurveTo(16,-36,30,-40);g.lineWidth=1.3;g.strokeStyle=rpmA(RPMO,.45);g.stroke();
 for(const [x,y] of[[12,-57],[20,-58],[8,-46],[24,-46],[16,-44]])rpmEl(g,x,y,1.3,1,rpmSh(P.b,.4),0);
 rpmAH(g,14,-46,12,12,3.6,4.5,.5,1.6);
 /* mouth parts and a grumpy frown */
 g.beginPath();g.moveTo(25,-40);g.quadraticCurveTo(29,-42.6,32.6,-40.4);g.lineWidth=1.8;g.strokeStyle=RPMO;g.stroke();
 for(const [x,y] of[[30,-36],[27.6,-35]]){rpmLimb(g,[x,y,x+3,y+2.6,x+2.4,y+5],1.6,rpmSh(P.b,.25),1.3)}
 if(V===2)for(const [x,y,c] of[[10,-36,'#6af6ff'],[20,-34,'#6af6ff'],[14,-54,'#ff5ad8']])rpw2mDot(g,x,y,1.2,c,.6);
 for(let k=0;k<2;k++){const e=E[k],r=k?4.8:4.2;if(V===2)rpmGlow(g,e[0],e[1],r*3,'#6af6ff',.45);rpmEye(g,e[0],e[1],r,P.ir,P.lid,k?.42:.4)}
 if(V===1){rpw2mPatch(g,E[0][0]+.8,E[0][1]+.2,3.2,E[0][0]-4,E[0][1]-3,E[0][0]+3.8,E[0][1]-3.8,.15);rpw2mRing(g,E[1][0]+3,E[1][1]+3,2)}
 g.restore();
 leg(4,-30+by,6,a+2.2,P.lg,5.6);leg(12,-30+by,24,a+Math.PI+2.2,P.lg,5.6);
 /* the big crusher claw, held forward like a shield */
 const sn=.12+.16*(.5+.5*Math.sin(a*2));g.save();g.translate(0,by);
 rpmLimb(g,[20,-36,30,-28,36,-32],6.4,P.b,2.2);
 g.save();g.translate(40,-34);g.rotate(-.1);
 g.save();g.translate(10,-6);g.rotate(-sn);g.beginPath();g.moveTo(-2,-2);g.quadraticCurveTo(8,-12,18,-4);g.quadraticCurveTo(10,-4,0,3);g.closePath();rpmFS(g,rpmCel(g,-2,-12,18,3,P.b),2.2);
 for(const x of[5,9,13]){rpmP(g,[x,-3+(x-5)*.05,x+1.6,-1.4,x+2.6,-3.6]);g.fillStyle=P.tip;g.fill()}g.restore();
 g.beginPath();g.moveTo(10,4);g.quadraticCurveTo(20,4,24,-2);g.quadraticCurveTo(16,8,8,9);g.closePath();rpmFS(g,rpmCel(g,8,-2,24,9,P.b),2.2);
 rpmBl(g,[-8,-6,-4,-13,8,-14,16,-8,16,6,6,12,-6,10,-10,2]);rpmFS(g,rpmRG(g,2,-2,16,[0,rpmSh(P.b,.42),.5,P.b,.9,rpmSh(P.b,-.35),1,rpmSh(P.b,-.5)],-2,-8),2.6);
 for(const [x,y,r] of[[-2,-6,1.6],[4,-9,1.3],[9,-5,1.5],[2,1,1.2],[-4,3,1.1]]){rpmEl(g,x+.4,y+.5,r,r*.85,rpmSh(P.b,-.3),0);rpmEl(g,x,y,r,r*.85,rpmSh(P.b,.3),0)}
 rpmAH(g,2,-1,10,9,3.5,4.6,.6,1.6);
 if(V===0){rpw2mBarnT(g,-3,5,2.6,'#f4eee0');rpw2mBarnT(g,4,7,2,'#f4eee0')}
 if(V===1){rpw2mPlate(g,[-7,-8,3,-12,10,-8,6,2,-6,4],[[-4,-6],[6,-8],[3,0]],'#6e6a6a');rpw2mBarn(g,-2,8,2,2.8,'#d8ccb8')}
 if(V===2){rpw2mDot(g,0,-4,1.6,'#6af6ff',.6);rpw2mDot(g,8,2,1.2,'#ff5ad8',.6);rpw2mDot(g,-5,4,1,'#6af6ff',.6)}
 g.restore();g.restore()};
function rpw2mWeed(d){return d?'#4ab848':'#2a9a5a'}

/* ---------- 6. Siren: a fish-tailed songstress who hops along on her tail, singing ---------- */
const RPW2M_SIR=[
 {sk:'#a8f0dc',hair:'#ff5a8e',hair2:'#ffb0c8',tail:'#1eb4a8',tail2:'#9affe8',fin:'#ff8ab0',fin2:'#ffd0e0',ir:'#ff4a8a',lid:'#6ac8b0',note:'#ff6aa8'},
 {sk:'#b8d4c4',hair:'#3a2448',hair2:'#6a4a7a',tail:'#2e6a5e',tail2:'#7ab0a0',fin:'#5a8a7e',fin2:'#a8c8bc',ir:'#ffcf3a',lid:'#7a9a8a',note:'#ffcf4a'},
 {sk:'#4a5cbc',hair:'#c8fbff',hair2:'#6ad8ff',tail:'#283682',tail2:'#4a5cb4',fin:'#6af0ff',fin2:'#2a4aa8',ir:'#ff5ad8',lid:'#22307a',note:'#6af6ff'}];
RPMD.siren=function(g,ph,o){const V=rpw2mV(o),P=RPW2M_SIR[V],a=ph*RPMT,hh=Math.max(0,Math.sin(a))*7,sq=Math.max(0,-Math.sin(a)),by=-hh+sq*1.4;
 const hl=Math.sin(a-.8)*2.2;/* the hair lags the hop */
 /* hair mass behind everything */
 g.beginPath();g.moveTo(0,-57+by);g.bezierCurveTo(-10,-60+by,-15,-50+by,-14,-40+by+hl*.5);g.bezierCurveTo(-14,-32+by+hl,-20,-28+by+hl,-22,-22+by+hl);g.quadraticCurveTo(-14,-24+by+hl,-10,-30+by+hl*.6);
 g.quadraticCurveTo(-8,-26+by+hl,-4,-24+by+hl*.8);g.quadraticCurveTo(-6,-34+by,-2,-42+by);g.closePath();rpmFS(g,rpmLG(g,0,-58+by,-20,-24+by,[0,rpmSh(P.hair,.25),.6,P.hair,1,rpmSh(P.hair,-.3)]),2.2);
 g.beginPath();g.moveTo(-6,-52+by);g.quadraticCurveTo(-12,-44+by,-12,-36+by+hl*.6);g.moveTo(-3,-48+by);g.quadraticCurveTo(-8,-38+by,-15,-29+by+hl);g.lineWidth=1.1;g.strokeStyle=rpmA(V===2?'#ffffff':P.hair2,.7);g.stroke();
 if(V===2){g.save();g.globalCompositeOperation='lighter';rpmGlow(g,-10,-40+by,18,'#6ad8ff',.35);g.restore()}
 /* far arm, reaching back */
 rpmLimb(g,[-1,-41+by,-7,-38+by,-12,-41+by+Math.sin(a)*1.4],2.4,rpmSh(P.sk,-.22),1.8);rpmEl(g,-12.6,-41.4+by+Math.sin(a)*1.4,1.8,1.6,rpmSh(P.sk,-.22),1.3);
 /* the tail: a tapered S curve that coils on landing and trails in the air */
 const C=[0,-27+by,-3,-14+by,7,1+by*.5-sq*.6,-12-sq*2,-4+by*.6-hh*.3],N=14,L=[],R=[],M=[];
 const bz=(t,i)=>{const v=1-t;return v*v*v*C[i]+3*v*v*t*C[i+2]+3*v*t*t*C[i+4]+t*t*t*C[i+6]};
 for(let j=0;j<=N;j++){const t=j/N,x=bz(t,0),y=bz(t,1),t2=Math.min(1,t+.02),t1=Math.max(0,t-.02),dx=bz(t2,0)-bz(t1,0),dy=bz(t2,1)-bz(t1,1),d=Math.hypot(dx,dy)||1,w=6.6*Math.pow(1-t,.75)+1.4;
  M.push(x,y);L.push(x-dy/d*w,y+dx/d*w);R.unshift(x+dy/d*w,y-dx/d*w)}
 /* the tail fin at the tip */
 const tx=M[N*2],ty=M[N*2+1],ta=Math.atan2(ty-M[N*2-1],tx-M[N*2-2])+Math.sin(a*2)*.3;
 g.save();g.translate(tx,ty);g.rotate(ta);rpw2mFin(g,[-1,0,8,-9,6,-3,10,1,7,5,9,10],P.fin2,P.fin,V===2?.62:1,1);g.restore();
 rpmP(g,L.concat(R));rpmFS(g,rpmLG(g,-8,-30+by,8,0,[0,rpmSh(P.tail,.3),.5,P.tail,1,rpmSh(P.tail,-.35)]),2.4);
 /* scales along the tail and a pale belly line */
 g.save();rpmP(g,L.concat(R));g.clip();g.beginPath();for(let j=1;j<N-1;j++){const x=M[j*2],y=M[j*2+1],w=6.6*Math.pow(1-j/N,.75);for(const k of[-.45,.2]){g.moveTo(x-w*.35,y+k*w*1.4-1);g.quadraticCurveTo(x,y+k*w*1.4+1.4,x+w*.35,y+k*w*1.4-1)}}
 g.lineWidth=.9;g.strokeStyle=V===2?'rgba(106,246,255,.55)':rpmA(rpmSh(P.tail,-.5),.6);g.stroke();
 g.beginPath();for(let j=0;j<=N;j++){const i=j*2;j?g.lineTo((M[i]+R[(N-j)*2])/2,(M[i+1]+R[(N-j)*2+1])/2):g.moveTo((M[i]+R[N*2])/2,(M[i+1]+R[N*2+1])/2)}g.lineWidth=2.4;g.strokeStyle=rpmA(P.tail2,.6);g.stroke();g.restore();
 if(V===2)for(let j=2;j<N;j+=2)rpw2mDot(g,M[j*2],M[j*2+1],.9,j%4?'#6af6ff':'#ff8ae8',.55);
 /* a little fin halfway down */
 {const j=6,x=M[j*2],y=M[j*2+1];g.save();g.translate(x+3,y+1);g.rotate(.6);rpw2mFin(g,[0,0,5,4,8,2,6,-2],P.fin2,P.fin,V===2?.62:1,1);g.restore()}
 /* torso, the frilled waist and the top */
 rpmBl(g,[-4.6,-26+by,-5.6,-34+by,-4,-42+by,3,-44.6+by,7,-40+by,6,-32+by,4.4,-26+by]);rpmFS(g,rpmCel(g,-6,-45+by,7,-25+by,P.sk),2.2);
 g.beginPath();for(let i=0;i<=6;i++){const x=-6+i*2.1,y=-26.4+by+(i%2?2.4:0);i?g.lineTo(x,y):g.moveTo(x,y)}g.lineTo(6.8,-29+by);g.lineTo(-6,-29+by);g.closePath();rpmFS(g,P.fin,1.4);
 if(V===0){rpw2mScal(g,4.4,-34.4+by,3.6,.5,'#ffe27a','#f0a030');rpw2mScal(g,-1.6,-34.6+by,3.2,-.3,'#ffe27a','#f0a030');
  for(let i=0;i<5;i++)rpmEl(g,-1+i*1.7,-41+by+Math.sin(i/4*Math.PI)*1.6,.9,.9,'#fffaf0',.6)}
 if(V===1){rpmBl(g,[-5,-28+by,-5.4,-37+by,0,-39+by,6.6,-37+by,6.4,-28+by]);rpmFS(g,rpmLG(g,0,-38+by,0,-28+by,[0,'#3a4a8a',1,'#1a2250']),1.6);
  g.beginPath();g.moveTo(2,-38.4+by);g.lineTo(1.4,-29+by);g.lineWidth=1;g.strokeStyle='#ffd27a';g.stroke();for(const y of[-36,-33,-30])rpmEl(g,3.2,y+by,.8,.8,'#ffc93a',.5);
  g.beginPath();g.moveTo(-5.6,-30+by);g.quadraticCurveTo(0,-27.4+by,6.8,-29.6+by);g.lineWidth=4.4;g.strokeStyle=RPMO;g.stroke();g.lineWidth=2.4;g.strokeStyle='#d8283a';g.stroke();
  g.beginPath();g.moveTo(-5,-29.6+by);g.quadraticCurveTo(-9,-27+by,-11,-22+by-hl*.3);g.lineTo(-8.6,-21.6+by-hl*.3);g.quadraticCurveTo(-7,-26+by,-4,-28+by);g.closePath();rpmFS(g,'#c8283a',1.3)}
 if(V===2){rpmBl(g,[-5,-30+by,-5.4,-37+by,1,-39+by,6.6,-37+by,6.4,-30+by]);rpmFS(g,rpmLG(g,0,-38+by,0,-29+by,[0,'#2a3a8a',1,'#141c4a']),1.6);rpw2mDot(g,1,-34+by,1.3,'#ff5ad8',.6);rpw2mDot(g,-3,-32+by,.8,'#6af6ff',.6);rpw2mDot(g,5,-32+by,.8,'#6af6ff',.6)}
 /* head: fin ear, big eyes, open singing mouth */
 const hx=3.4,hy=-50.6+by;
 g.save();g.translate(hx-5,hy-.6);g.rotate(-.3);rpw2mFin(g,[0,0,-6,-6,-4,-1,-7,2,-3,4],P.fin2,P.fin,V===2?.62:1,1);g.restore();
 rpmEl(g,hx,hy,7,7.4,rpmRG(g,hx+1,hy+1,9,[0,rpmSh(P.sk,.4),.55,P.sk,1,rpmSh(P.sk,-.3)],hx-2,hy-3),2.2);
 /* bangs */
 g.beginPath();g.moveTo(hx-7.4,hy+1);g.bezierCurveTo(hx-8,hy-9,hx+2,hy-10.6,hx+7.6,hy-4);g.quadraticCurveTo(hx+3,hy-5.6,hx+1,hy-3);g.quadraticCurveTo(hx-1,hy-6,hx-3,hy-3.6);g.quadraticCurveTo(hx-5,hy-2,hx-7.4,hy+1);g.closePath();
 rpmFS(g,rpmLG(g,hx,hy-10,hx,hy,[0,rpmSh(P.hair,.3),1,P.hair]),1.8);
 if(V===2)rpmGlow(g,hx+4,hy+1,9,'#ff5ad8',.5);
 rpmEye(g,hx+3.2,hy+.4,2.7,P.ir,P.lid,.28);rpmEye(g,hx+7.6,hy,2,P.ir,P.lid,-.2);
 g.beginPath();g.moveTo(hx+.6,hy-3);g.lineTo(hx+4.4,hy-3.6);g.lineWidth=1.2;g.strokeStyle=RPMO;g.stroke();
 const mo=.8+.6*(.5+.5*Math.sin(a*2));rpmEl(g,hx+6.6,hy+4.6,1.5,1.4*mo,V===2?'#08061a':'#5a0a24',1.2);rpmP(g,[hx+5.8,hy+4.6-1.2*mo,hx+6.6,hy+4.6-1.2*mo,hx+6.2,hy+4.6-.2*mo]);g.fillStyle='#fffbe8';g.fill();
 rpmEl(g,hx+2.6,hy+3.6,1.4,.9,rpmA(V===2?'#ff5ad8':'#ff7a9a',.45),0);
 /* dressing on the head */
 if(V===0){rpw2mStar(g,hx-3.6,hy-7.6,3.6,-.3,'#ffd23a','#f08a1a');rpw2mScal(g,hx+1.6,hy-9,2.4,.4,'#ffffff','#ff9ab8')}
 if(V===1){const fw=Math.sin(a*2)*.8;g.beginPath();g.moveTo(hx-5,hy-11);g.bezierCurveTo(hx-12,hy-16+fw,hx-18,hy-10+fw,hx-20,hy-5+fw);g.quadraticCurveTo(hx-12,hy-10,hx-4,hy-9);g.closePath();rpmFS(g,rpmLG(g,hx-4,hy-11,hx-20,hy-5,[0,'#ffffff',1,'#d8d0e0']),1.4);
  rpw2mTri(g,hx-.4,hy-6.4,.64,-.14,'#2c2232','#ffcf4a');rpw2mRing(g,hx-2.6,hy+2.6,1.8)}
 if(V===2){const lw=Math.sin(a*2)*1.4;rpw2mLure(g,hx-2,hy-7,hx-2,hy-17,hx+4+lw,hy-17.6,1.8,'#ff5ad8','#3a4aa0');rpw2mLure(g,hx-4,hy-6,hx-9,hy-15,hx-12-lw*.5,hy-12,1.4,'#6af6ff','#3a4aa0')}
 /* near arm, reaching out to the audience */
 const hx2=14,hy2=-43+by+Math.sin(a*2)*1.2;
 rpmLimb(g,[4,-41+by,9,-37.4+by,hx2,hy2],2.6,P.sk,1.8);
 g.beginPath();g.ellipse(hx2+.8,hy2-.6,2.4,1.8,-.5,0,RPMT);rpmFS(g,P.sk,1.4);for(const t of[-1.3,-.8,-.3]){g.beginPath();g.moveTo(hx2+1,hy2-1);g.lineTo(hx2+1+Math.cos(t)*3.6,hy2-1+Math.sin(t)*3.6);g.lineWidth=2.6;g.strokeStyle=RPMO;g.stroke();g.lineWidth=1.2;g.strokeStyle=P.sk;g.stroke()}
 if(V===1)rpmEl(g,8.6,-37.6+by,1.6,1.6,'#ffc93a',1);
 /* the song */
 for(let i=0;i<3;i++){const u=(ph+i/3)%1,x=hx+10+u*14+Math.sin(u*6+i*2)*2.4,y=hy+2-u*16;g.globalAlpha=Math.sin(u*Math.PI);if(V===2)rpmGlow(g,x,y-3,7,P.note,.6);rpw2mNote(g,x,y,.62+(i%2)*.14,i===1&&V===0?'#ffd23a':P.note,Math.sin(u*5)*.3)}g.globalAlpha=1};

/* ---------- 7. Inkling: a squid walking on its arms, ink sac on its back ---------- */
const RPW2M_SQ=[
 {m:'#ff7a5a',sp:'#ffd8b8',fin:'#ffcf4a',arm:'#ff8a6a',ir:'#2ad0c8',lid:'#d0503a',sac:'#2a1838'},
 {m:'#8a4aa8',sp:'#c89ae0',fin:'#c87ad8',arm:'#9a5ab8',ir:'#ffcf3a',lid:'#5a2a78',sac:'#1a1024'},
 {m:'#3c2e9c',sp:'#6af6ff',fin:'#6af0ff',arm:'#4436a8',ir:'#6af6ff',lid:'#1c165a',sac:'#3a0a4a'}];
RPMD.squid=function(g,ph,o){const V=rpw2mV(o),P=RPW2M_SQ[V],a=ph*RPMT,by=-Math.abs(Math.sin(a))*1.4,lean=.06;
 /* an arm: a tapered curve from the head to a curled tip on the ground */
 const arm=(bx,p,col,len,cur)=>{const tx=bx+3.4*Math.sin(p)+cur,lift=Math.max(0,-Math.cos(p))*3.2,y0=-16+by,N=8,L=[],R=[],M=[];
  for(let j=0;j<=N;j++){const t=j/N,x=bx+(tx-bx)*t+Math.sin(t*Math.PI)*cur*.6,y=y0+(-lift-1.6-y0)*Math.pow(t,.9)-Math.sin(t*Math.PI)*1.6,w=2.6*(1-t)+.8;M.push(x,y);L.push(x-w,y);R.unshift(x+w,y)}
  rpmP(g,L.concat(R));rpmFS(g,rpmLG(g,0,y0,0,0,[0,col,1,rpmSh(col,-.25)]),1.7);
  const sd=cur>=0?1:-1;rpmP(g,[tx-.8,-lift-2.6,tx+.8,-lift-2.6,tx+sd*3.6,-lift-.8]);rpmFS(g,rpmSh(col,-.2),1.2);
  for(let j=2;j<N;j+=2)rpmEl(g,M[j*2]+(cur>0?1.4:-1.4)*(1-j/N),M[j*2+1],.8,.7,V===2?'#ff8ae8':rpmSh(col,.5),0)};
 const AD=rpmSh(P.arm,-.28);
 if(V===2)for(const [y0,cx,cy2,ex,ey,d] of[[-20,-20,-8,-27,-16,0],[-24,-18,-34,-27,-36,1.6]]){const sw2=Math.sin(a+d)*2.4;g.beginPath();g.moveTo(-5,y0+by);g.quadraticCurveTo(cx,cy2+by+sw2,ex,ey+by+sw2);g.lineWidth=3;g.strokeStyle=RPMO;g.stroke();g.lineWidth=1.2;g.strokeStyle='#8af8ff';g.stroke();rpw2mDot(g,ex,ey+by+sw2,1.3,d?'#ff5ad8':'#6af6ff',.7)}
 arm(-4,a+Math.PI,AD,0,-5);arm(1,a+2.1,AD,0,1.6);arm(6,a+Math.PI+2.1,AD,0,6);
 /* far feeding tentacle trailing back */
 g.beginPath();g.moveTo(-3,-17+by);g.bezierCurveTo(-12,-12+by,-14,-24+by+Math.sin(a)*2,-20,-20+by+Math.sin(a)*2);g.lineWidth=4.4;g.strokeStyle=RPMO;g.stroke();g.lineWidth=2.2;g.strokeStyle=AD;g.stroke();
 rpmEl(g,-20.6,-20+by+Math.sin(a)*2,2.2,1.6,AD,1.3);
 g.save();g.translate(0,-22);g.rotate(lean);g.translate(0,22+by);
 /* fins at the mantle tip (behind) */
 const ff=Math.sin(a*2)*.12;
 for(const sd of[-1,1]){const fw=1+ff*sd;rpmP(g,[-3,-60,-3+sd*13*fw,-47+ff*6,-2+sd*5,-41]);g.save();if(V===2)g.globalAlpha=.62;g.fillStyle=rpmLG(g,-3,-60,-3+sd*13,-45,[0,rpmSh(P.fin,.35),1,rpmSh(P.fin,-.15)]);g.fill();g.restore();
  g.lineWidth=2;g.strokeStyle=RPMO;g.stroke();g.beginPath();g.moveTo(-3,-56);g.lineTo(-3+sd*9*fw,-47.4+ff*4);g.moveTo(-3,-51);g.lineTo(-3+sd*6,-44.6);g.lineWidth=.8;g.strokeStyle=rpmA(RPMO,.4);g.stroke();
  if(V===2){g.beginPath();g.moveTo(-3,-60);g.lineTo(-3+sd*13*fw,-47+ff*6);g.lineWidth=1;g.strokeStyle='#bffcff';g.stroke()}}
 /* the ink sac bulging on the back */
 rpmEl(g,-10,-33,5.4,7,rpmRG(g,-10,-33,8,[0,'#6a4a8a',.5,P.sac,1,'#0a0412'],-12,-36),2);rpmAH(g,-11,-34,3,4.6,3.4,4.4,.55,1.1);
 if(V===2)rpmGlow(g,-10,-33,10,'#ff5ad8',.45);
 const dr=(ph*2)%1;g.globalAlpha=dr>.8?(1-dr)/.2:1;rpmEl(g,-13.6,-26+dr*14,1.4,1.9,V===2?'#5a1a7a':'#1a0a24',1);g.globalAlpha=1;
 /* the mantle */
 const MP=()=>{g.beginPath();g.moveTo(-8.6,-26);g.bezierCurveTo(-11,-38,-8,-50,-3,-59);g.bezierCurveTo(2,-51,8,-40,9.4,-27);g.closePath()};
 MP();rpmFS(g,rpmCel(g,-10,-58,10,-26,P.m,.6),2.4);
 g.save();MP();g.clip();
 if(V===0){for(const [x,y,r] of[[-4,-34,2],[2,-40,1.6],[-1,-48,1.4],[5,-31,1.4],[-6,-42,1.2]])rpmEl(g,x,y,r,r,rpmA(P.sp,.85),0);
  g.beginPath();g.moveTo(-10,-38);g.quadraticCurveTo(0,-42,10,-37);g.lineWidth=2.4;g.strokeStyle='rgba(42,208,200,.55)';g.stroke()}
 if(V===1)for(const [x,y,r] of[[-3,-36,1.6],[3,-42,1.3],[-1,-47,1.1]])rpmEl(g,x,y,r,r,rpmA(P.sp,.55),0);
 g.restore();
 if(V===2)for(const [x,y,r,c] of[[-3,-34,1.4,'#6af6ff'],[3,-38,1.2,'#6af6ff'],[-1,-45,1.1,'#ff5ad8'],[5,-30,1,'#6af6ff'],[-6,-29,1,'#ff5ad8']])rpw2mDot(g,x,y,r,c,.6);
 g.beginPath();g.moveTo(-6.4,-30);g.bezierCurveTo(-8,-40,-6,-48,-3.4,-54);rpmHi(g,V===2?.3:.5,1.6);
 if(V===2)rpw2mLure(g,-3,-59,2,-70,8+Math.sin(a*2)*1.6,-66,1.8,'#ff5ad8','#3c2e9c');
 /* the head */
 rpmEl(g,1.4,-22,10,7.6,rpmRG(g,2,-22,12,[0,rpmSh(P.m,.38),.55,P.m,1,rpmSh(P.m,-.35)],-1,-26),2.4);
 /* siphon */
 rpmP(g,[-7,-18,-11,-19,-11,-16,-7,-15]);rpmFS(g,rpmSh(P.m,-.15),1.3);
 if(V===2){rpmGlow(g,7,-23,10,'#6af6ff',.4)}
 rpmEye(g,7,-23.4,4.4,P.ir,P.lid,.42);rpmEye(g,-1.4,-24,3.2,P.ir,P.lid,-.3);
 g.beginPath();g.moveTo(3,-17.6);g.quadraticCurveTo(6.6,-19.6,10.4,-17.4);g.lineWidth=1.6;g.strokeStyle=RPMO;g.stroke();rpmP(g,[8,-18.4,9.4,-18.2,8.8,-16.4]);g.fillStyle='#fffbe8';g.fill();
 /* dressing */
 if(V===0){for(let i=0;i<6;i++){const x=-7+i*2.9,y=-27.4+Math.sin(i/5*Math.PI)*1.6;rpmEl(g,x,y,1.4,1.1,i%2?'#fff4e0':'#ffc8a8',.8)}rpw2mStar(g,3.4,-40,3.8,.35,'#ffd23a','#f08a1a');rpw2mCoral(g,-8.6,-42,.56,-.9,'#ff6aa8','#ffd0e4')}
 if(V===1){g.beginPath();g.moveTo(-9,-30);g.quadraticCurveTo(0,-26,10,-29.6);g.lineTo(10.4,-26);g.quadraticCurveTo(0,-22,-9.4,-26.4);g.closePath();rpmFS(g,rpmLG(g,0,-30,0,-23,[0,'#ff4a4a',1,'#a8182a']),1.6);
  const fw=Math.sin(a*2)*1.2;g.beginPath();g.moveTo(-9,-28);g.quadraticCurveTo(-14,-27+fw,-17,-23+fw);g.lineTo(-15,-21.4+fw);g.quadraticCurveTo(-12,-24,-8.6,-25.6);g.closePath();rpmFS(g,'#c8283a',1.3);
  rpw2mTri(g,-2.6,-54,.66,-.22,'#2c2232','#ffcf4a');rpw2mPatch(g,-1.4,-24,3.4,-6,-27,3.6,-28,0);rpw2mRing(g,9.2,-48,1.6)}
 g.restore();
 /* near feeding tentacle, reaching forward (it holds a cutlass on the wreck) */
 const rx=17,ry=-30+by+Math.sin(a*2)*1.4;
 g.beginPath();g.moveTo(6,-17+by);g.bezierCurveTo(14,-15+by,18,-22+by,rx,ry);g.lineWidth=4.6;g.strokeStyle=RPMO;g.stroke();g.lineWidth=2.4;g.strokeStyle=P.arm;g.stroke();
 if(V===1)rpw2mCut(g,rx,ry,.5,.86);
 rpmEl(g,rx,ry,2.6,2,P.arm,1.4);if(V===2)rpw2mDot(g,rx,ry,1.2,'#ff5ad8',.6);
 if(V===0)rpw2mSnail(g,rx+2.4,ry-2,2.6,.4,'#ffe0f0','#e888b0');
 arm(-1,a,P.arm,0,-3);arm(4,a+Math.PI-1,P.arm,0,4)};

/* ---------- 8. Leviathan (boss): a sea serpent swimming along the road in its own surf, head raised, coils breaking the water ---------- */
const RPW2M_LEV=[
 {b:'#1ab4aa',b2:'#7af0e0',bel:'#ffd88a',fin:'#ff7a9a',fin2:'#ffd0dc',wat:'#3ad8e8',ir:'#ffd23a',lid:'#0e7a74',mouth:'#8a1a3a'},
 {b:'#4e6c64',b2:'#8aa89a',bel:'#cdb88a',fin:'#a84a32',fin2:'#e0a070',wat:'#5a8a8a',ir:'#ffcf3a',lid:'#2e4440',mouth:'#5a1420'},
 {b:'#26348c',b2:'#3a4aa0',bel:'#4a4aa8',fin:'#6af0ff',fin2:'#1e3a9a',wat:'#1a4a9a',ir:'#6af6ff',lid:'#141c56',mouth:'#2a0a3a'}];
const rpw2mTip=S=>[S[S.length-1][2],S[S.length-1][3]];
/* a tube along a centreline M (flat x,y list) with half-widths W; L is the outer / left side of the direction of travel */
function rpw2mTube(M,W){const n=M.length>>1,L=[],R=[],NX=[],NY=[];for(let j=0;j<n;j++){const a=Math.max(0,j-1),b=Math.min(n-1,j+1);let dx=M[b*2]-M[a*2],dy=M[b*2+1]-M[a*2+1];const d=Math.hypot(dx,dy)||1;dx/=d;dy/=d;
 NX.push(dy);NY.push(-dx);L.push(M[j*2]+dy*W[j],M[j*2+1]-dx*W[j]);R.push(M[j*2]-dy*W[j],M[j*2+1]+dx*W[j])}const Rr=[];for(let j=n-1;j>=0;j--)Rr.push(R[j*2],R[j*2+1]);return{L,R,P:L.concat(Rr),NX,NY,n}}
RPMD.leviathan=function(g,ph,o){const V=rpw2mV(o),P=RPW2M_LEV[V],a=ph*RPMT,yw=-5;
 const fa=V===2?.62:1;
 /* the surf it swims in */
 rpmEl(g,-30,yw+2,98,10,rpmA(P.wat,V===2?.5:.42),0);g.beginPath();g.ellipse(-30,yw+2,98,10,0,0,RPMT);g.lineWidth=1.6;g.strokeStyle=rpmA('#ffffff',.5);g.stroke();
 if(V===2){g.save();g.translate(-30,yw);g.scale(1.6,.3);rpmGlow(g,0,0,60,'#2a8aff',.3);g.restore()}
 for(let i=0;i<5;i++){const u=(ph+i/5)%1,x=-112+i*36+u*10;g.globalAlpha=Math.sin(u*Math.PI)*.8;g.beginPath();g.ellipse(x,yw+3+(i%2)*2,8+u*6,1.6,0,0,RPMT);g.lineWidth=1.4;g.strokeStyle='#ffffff';g.stroke()}g.globalAlpha=1;
 /* a body part: scaled tube with belly plates, scales and a finned crest */
 const part=(M,W,crest,belly,clipY)=>{const T=rpw2mTube(M,W),n=T.n;g.save();if(clipY){g.beginPath();g.rect(-200,-300,420,300+yw+.5);g.clip()}
  if(crest){const S=[];for(let j=crest[0];j<=crest[1];j+=crest[3]||2){const fh=crest[2]*(1+.12*Math.sin(a*2+j))*(.75+.25*Math.sin(Math.PI*(j-crest[0])/Math.max(1,crest[1]-crest[0])));S.push([T.L[j*2]-T.NX[j]*2,T.L[j*2+1]-T.NY[j]*2,T.L[j*2]+T.NX[j]*fh-T.NY[j]*fh*.35*(M[2]>M[0]?1:-1),T.L[j*2+1]+T.NY[j]*fh+T.NX[j]*fh*.35*(M[2]>M[0]?1:-1)])}
   const FP=()=>{g.beginPath();g.moveTo(S[0][0],S[0][1]);g.lineTo(S[0][2],S[0][3]);for(let i=1;i<S.length;i++){const p0=S[i-1],p1=S[i],mx=(p0[0]+p1[0])/2,my=(p0[1]+p1[1])/2,cx=(p0[2]+p1[2])/2,cy=(p0[3]+p1[3])/2;g.quadraticCurveTo(mx+(cx-mx)*.25,my+(cy-my)*.25,p1[2],p1[3])}
    const e=S[S.length-1];g.lineTo(e[0],e[1]);for(let i=S.length-1;i>=0;i--)g.lineTo(S[i][0],S[i][1]);g.closePath()};
   FP();g.save();g.globalAlpha=fa;g.fillStyle=rpmLG(g,S[0][0],S[0][1]-20,rpw2mTip(S)[0],rpw2mTip(S)[1],[0,P.fin2,1,P.fin]);g.fill();g.restore();g.lineWidth=2.2;g.strokeStyle=RPMO;g.stroke();
   g.beginPath();for(const q of S){g.moveTo(q[0],q[1]);g.lineTo(q[0]+(q[2]-q[0])*.9,q[1]+(q[3]-q[1])*.9)}g.lineWidth=1.3;g.strokeStyle=rpmA(RPMO,.55);g.stroke();
   if(V===1){/* tattered notches */for(let i=0;i<S.length-1;i+=2){const q=S[i],r=S[i+1];rpmEl(g,(q[2]+r[2])/2*.7+(q[0]+r[0])/2*.3,(q[3]+r[3])/2*.7+(q[1]+r[1])/2*.3,1.6,1.6,'rgba(18,8,31,.6)',0)}}}
  let y0=1e9,y1=-1e9;for(let j=1;j<T.P.length;j+=2){y0=Math.min(y0,T.P[j]);y1=Math.max(y1,T.P[j])}
  rpmP(g,T.P);rpmFS(g,rpmLG(g,0,y0,0,y1,[0,rpmSh(P.b,.35),.45,P.b,1,rpmSh(P.b,-.4)]),2.8);
  g.save();rpmP(g,T.P);g.clip();
  /* belly plates on the inner side */
  if(belly){const BP=[];for(let j=0;j<n;j++)BP.push(M[j*2]-T.NX[j]*W[j]*.42,M[j*2+1]-T.NY[j]*W[j]*.42);for(let j=n-1;j>=0;j--)BP.push(T.R[j*2],T.R[j*2+1]);
   rpmP(g,BP);g.fillStyle=rpmLG(g,0,y0,0,y1,[0,rpmSh(P.bel,.3),1,rpmSh(P.bel,-.25)]);g.fill();g.beginPath();g.moveTo(BP[0],BP[1]);for(let j=1;j<n;j++)g.lineTo(BP[j*2],BP[j*2+1]);g.lineWidth=1.6;g.strokeStyle=RPMO;g.stroke();
   g.beginPath();for(let j=1;j<n-1;j++){g.moveTo(BP[j*2],BP[j*2+1]);g.lineTo(T.R[j*2],T.R[j*2+1])}g.lineWidth=1;g.strokeStyle=rpmA(RPMO,.45);g.stroke();
   if(V===2)for(let j=1;j<n-1;j+=2)rpw2mDot(g,(BP[j*2]+T.R[j*2])/2,(BP[j*2+1]+T.R[j*2+1])/2,1.1,'#ff5ad8',.55)}
  if(!belly){g.beginPath();g.moveTo(T.R[0],T.R[1]);for(let j=1;j<n;j++)g.lineTo(T.R[j*2],T.R[j*2+1]);g.lineWidth=W[n>>1]*.7;g.strokeStyle=rpmA(rpmSh(P.b,-.5),.45);g.stroke();g.lineWidth=2;g.strokeStyle=rpmA(P.bel,V===2?.5:.7);g.stroke()}
  /* scale rows */
  g.beginPath();for(let j=1;j<n-1;j++)for(const k of[.62,.18]){const cx=M[j*2]+T.NX[j]*W[j]*k,cy=M[j*2+1]+T.NY[j]*W[j]*k,th=Math.atan2(T.NY[j],T.NX[j]),r=Math.max(1.6,W[j]*.2);g.moveTo(cx+Math.cos(th+Math.PI+1.1)*r,cy+Math.sin(th+Math.PI+1.1)*r);g.arc(cx,cy,r,th+Math.PI+1.1,th+Math.PI-1.1,true)}
  g.lineWidth=1;g.strokeStyle=V===2?'rgba(106,246,255,.4)':rpmA(rpmSh(P.b,-.55),.55);g.stroke();
  g.beginPath();g.moveTo(T.L[2]-T.NX[1]*3,T.L[3]-T.NY[1]*3);for(let j=2;j<n-1;j++)g.lineTo(T.L[j*2]-T.NX[j]*3,T.L[j*2+1]-T.NY[j]*3);rpmHi(g,V===2?.25:.45,2.2);
  if(V===2)for(let j=2;j<n-1;j+=2)rpw2mDot(g,M[j*2]+T.NX[j]*W[j]*.4,M[j*2+1]+T.NY[j]*W[j]*.4,1.2,'#6af6ff',.6);
  g.restore();g.restore();return T};
 /* tail fin flicking out of the water */
 const tf=Math.sin(a+1.2)*.22;g.save();g.translate(-128,yw);g.rotate(-.3+tf);rpw2mFin(g,[0,2,-10,-12,-22,-32,-7,-24,5,-38,7,-18,9,2],P.fin2,P.fin,fa,1);g.restore();
 /* three coils, a wave travelling back from the head */
 const C=[[-124,-100,14,7],[-98,-46,30,13.4],[-44,10,40,16]],TS=[];
 C.forEach((c,i)=>{const h=c[2]*(1+.14*Math.sin(a-i*1.4-1)),dx=Math.sin(a-i*1.4)*1.5,N=14,M=[],W=[];for(let j=0;j<=N;j++){const t=j/N;M.push(c[0]+dx+(c[1]-c[0])*t,yw+2-h*Math.pow(Math.sin(Math.PI*t),.5));W.push(c[3]*(.86+.14*Math.sin(Math.PI*t)))}
  TS.push([M,W,part(M,W,i?[2,N-2,c[3]*1.15,3]:null,0,1)])});
 /* the neck rises out of the water to the raised head */
 const sw=Math.sin(a)*2,nb=Math.sin(a*2)*1.2,NP=[28,yw+2,30,-58,64+sw,-66,72+sw,-100+nb],N2=18,M2=[],W2=[];
 for(let j=0;j<=N2;j++){const t=j/N2,v=1-t;M2.push(v*v*v*NP[0]+3*v*v*t*NP[2]+3*v*t*t*NP[4]+t*t*t*NP[6],v*v*v*NP[1]+3*v*v*t*NP[3]+3*v*t*t*NP[5]+t*t*t*NP[7]);W2.push(16.4-t*5.4)}
 /* the dorsal frill along the back of the neck (L side) and the plates in front */
 const TN=part(M2,W2,[2,N2-1,12,3],1,1);
 /* dressing on coils and neck */
 const at=(k,j,u)=>{const T=TS[k][2],M=TS[k][0],W=TS[k][1];return[M[j*2]+T.NX[j]*W[j]*u,M[j*2+1]+T.NY[j]*W[j]*u]};
 if(V===0){let q=at(2,6,.7);rpw2mCoral(g,q[0],q[1],1.1,-.2,'#ff6aa8','#ffd0e4');q=at(2,9,.75);rpw2mCoral(g,q[0],q[1],.8,.35,'#ff9a3a','#ffe0a0');
  q=at(1,7,.35);rpw2mStar(g,q[0],q[1],5.4,.3,'#ffd23a','#f08a1a');q=at(2,4,.1);rpw2mScal(g,q[0],q[1]+2,4.4,-.4,'#fff4d8','#e8b080');q=at(0,7,.8);rpw2mCoral(g,q[0],q[1],.6,.1,'#ff6aa8','#ffd0e4');
  q=[M2[10*2]+TN.NX[10]*4,M2[10*2+1]+TN.NY[10]*4];rpw2mStar(g,q[0],q[1],4.6,-.2,'#ff8a3a','#c8401a');q=at(1,4,.1);rpw2mSnail(g,q[0],q[1],3.2,.4,'#fff0e0','#e8a888')}
 if(V===1){/* an anchor chain round the middle coil, harpoons in the back coil, barnacles */
  const c=TS[2],M=c[0];g.save();rpmP(g,c[2].P);g.clip();for(let i=0;i<7;i++){const j=4+i,x=M[j*2]+(i-3)*.6,y=M[j*2+1];g.save();g.translate(x,y);g.rotate(.9);g.beginPath();g.ellipse(0,0,i%2?3.4:4.4,i%2?2.2:2.8,0,0,RPMT);g.lineWidth=3.8;g.strokeStyle=RPMO;g.stroke();g.lineWidth=2;g.strokeStyle='#8a8a96';g.stroke();g.restore()}g.restore();
  for(const [k,j,ang] of[[1,5,-.6],[1,9,-.2]]){const q=at(k,j,.9);g.beginPath();g.moveTo(q[0],q[1]);g.lineTo(q[0]+Math.cos(ang-1.57)*26,q[1]+Math.sin(ang-1.57)*26);g.lineWidth=4.4;g.strokeStyle=RPMO;g.stroke();g.lineWidth=2.2;g.strokeStyle='#9a6a3a';g.stroke();
   const ex=q[0]+Math.cos(ang-1.57)*26,ey=q[1]+Math.sin(ang-1.57)*26;rpmEl(g,ex,ey,2.4,2,'#e0c890',1.2);
   g.beginPath();g.moveTo(ex,ey);g.quadraticCurveTo(ex-10,ey+8+Math.sin(a+j)*3,ex-16,ey+20);g.lineWidth=3;g.strokeStyle=RPMO;g.stroke();g.lineWidth=1.4;g.strokeStyle='#e0c890';g.stroke()}
  for(const [k,j,u,r] of[[2,3,-.5,3],[2,11,-.3,2.6],[1,3,-.6,2.6],[1,11,-.4,2.2],[0,5,-.3,2.2],[2,7,.2,2]]){const q=at(k,j,u),T=TS[k][2];rpw2mBarn(g,q[0],q[1],r,Math.atan2(T.NY[j],T.NX[j])+Math.PI/2,'#d8ccb8')}
  /* iron plates bolted on the neck */
  for(const [j,w] of[[5,1],[9,.9]]){const x=M2[j*2],y=M2[j*2+1],T=TN,ex=T.NX[j],ey=T.NY[j],tx=-ey,ty=ex,W=W2[j]*.95;
   rpw2mPlate(g,[x+ex*W-tx*6,y+ey*W-ty*6,x+ex*W+tx*6,y+ey*W+ty*6,x-ex*W*.2+tx*5,y-ey*W*.2+ty*5,x-ex*W*.2-tx*5,y-ey*W*.2-ty*5],[[x+ex*W*.7,y+ey*W*.7],[x+ex*W*.05+tx*3,y+ey*W*.05+ty*3],[x+ex*W*.05-tx*3,y+ey*W*.05-ty*3]],'#6e6a6c')}}
 /* the head: a crested dragon skull, jaws open */
 const hx=M2[N2*2],hy=M2[N2*2+1],jo=.2+.08*Math.sin(a*2);
 g.save();g.translate(hx-2,hy-4);g.rotate(-.1+Math.sin(a*2+.4)*.03);g.scale(1.42,1.42);
 /* back frill / fin ears */
 g.save();g.translate(-6,-6);g.rotate(-.5+Math.sin(a*2)*.06);rpw2mFin(g,[0,4,-14,-8,-10,-4,-24,-6,-14,2,-24,8,-10,8,0,10],P.fin2,P.fin,fa,1);g.restore();
 if(V===1)rpw2mRing(g,-16,4,3);
 /* swept horns */
 for(const [x,y,l,k] of[[10,-12,20,0],[3,-11,25,1]]){g.beginPath();g.moveTo(x+5,y+2);g.quadraticCurveTo(x-1,y-12,x-l,y-15);g.quadraticCurveTo(x-9,y-4,x-5,y+3);g.closePath();rpmFS(g,rpmLG(g,x,y,x-l,y-15,k?[0,'#fff4dc',.6,'#d8c098',1,'#a08868']:[0,'#9a8c74',1,'#5a4c3c']),2);
  if(k){g.beginPath();for(const u of[.3,.5,.7]){const bx=x+(-l)*u*.9,by=y-15*u*.95;g.moveTo(bx-1.6,by-1.6);g.lineTo(bx+1.4,by+1.8)}g.lineWidth=.9;g.strokeStyle=rpmA(RPMO,.45);g.stroke()}}
 /* lower jaw (hinged) with fangs, then the mouth */
 g.save();g.translate(4,6);g.rotate(jo);
 g.beginPath();g.moveTo(-4,-2);g.quadraticCurveTo(14,0,36,2);g.quadraticCurveTo(38,6,34,8);g.quadraticCurveTo(14,12,-2,7);g.closePath();rpmFS(g,rpmLG(g,0,-2,0,10,[0,rpmSh(P.b,.25),.6,P.b,1,rpmSh(P.b,-.3)]),2.4);
 g.beginPath();g.moveTo(0,8.4);g.quadraticCurveTo(16,11,32,7.6);g.lineWidth=3;g.strokeStyle=rpmA(P.bel,.8);g.stroke();
 for(const x of[10,17,24,31]){rpmP(g,[x-1.6,1+x*.03,x+1.6,1+x*.03,x,-4+x*.03]);rpmFS(g,'#fffbec',.9)}
 if(V===2)for(let i=0;i<4;i++){const x=6+i*7,sw2=Math.sin(a*2+i)*2.4;g.beginPath();g.moveTo(x,8);g.bezierCurveTo(x-2,16,x+4+sw2,22,x-2+sw2,28-i*1.4);g.lineWidth=4.6-i*.4+2.4;g.strokeStyle=RPMO;g.stroke();g.lineWidth=4.6-i*.4;g.strokeStyle='#30287e';g.stroke();
  for(const u of[.35,.65])rpmEl(g,x+(sw2*.6)*u,8+u*18,.9,.9,'#ff8ae8',0)}
 g.restore();
 g.beginPath();g.moveTo(2,4);g.quadraticCurveTo(18,6,38,4);g.lineTo(38,8);g.quadraticCurveTo(18,14+jo*20,4,10);g.closePath();g.fillStyle=P.mouth;g.fill();
 rpmEl(g,20,9+jo*8,8,2.4,V===2?'#ff5ad8':'#ff6a8a',0);
 /* upper skull */
 const SK=()=>{g.beginPath();g.moveTo(-8,-6);g.bezierCurveTo(-4,-16,10,-18,20,-13);g.bezierCurveTo(30,-10,40,-8,44,-2);g.quadraticCurveTo(45,3,40,5);g.quadraticCurveTo(20,7,2,6);g.quadraticCurveTo(-8,4,-8,-6);g.closePath()};
 SK();rpmFS(g,rpmRG(g,16,-4,30,[0,rpmSh(P.b,.42),.5,P.b,1,rpmSh(P.b,-.38)],10,-12),2.6);
 for(const x of[8,15,22,29,36]){rpmP(g,[x-1.8,5.2,x+1.8,5.4,x,11+(x===15||x===29?2:0)]);rpmFS(g,'#fffbec',.9)}
 g.save();SK();g.clip();g.beginPath();g.moveTo(0,5);g.quadraticCurveTo(20,1,42,1);g.lineWidth=4;g.strokeStyle=rpmA(P.bel,.55);g.stroke();
 g.beginPath();for(const [x,y] of[[26,-8],[31,-6],[35,-4.6],[22,-10],[30,-1]]){g.moveTo(x+1.6,y);g.arc(x,y,1.6,0,Math.PI,true)}g.lineWidth=.9;g.strokeStyle=rpmA(rpmSh(P.b,-.55),.6);g.stroke();g.restore();
 rpmAH(g,14,-2,18,12,3.5,4.4,.5,1.8);
 rpmEl(g,40,-3,1.4,1,RPMO,0);
 /* brow ridge and the eye */
 if(V===2)rpmGlow(g,15,-6,16,'#6af6ff',.55);
 rpmEye(g,15,-6,5.2,P.ir,P.lid,.5);
 g.beginPath();g.moveTo(7,-13);g.quadraticCurveTo(15,-15,24,-9);g.quadraticCurveTo(16,-11,8,-10);g.closePath();rpmFS(g,rpmSh(P.b,-.3),1.8);
 if(V===1){g.beginPath();g.moveTo(10,-14);g.lineTo(20,1);g.moveTo(12,-10.6);g.lineTo(16,-11.6);g.moveTo(14,-6.6);g.lineTo(18,-7.6);g.lineWidth=1.2;g.strokeStyle='#f0d8c8';g.stroke()}
 if(V===0){rpw2mStar(g,4,-12,4,-.4,'#ffd23a','#f08a1a');rpw2mCoral(g,-2,-14,.7,-.6,'#ff6aa8','#ffd0e4')}
 if(V===1)rpw2mTri(g,8,-15,1.25,-.12,'#2c2232','#ffcf4a');
 if(V===2){for(const [x,y] of[[2,-4],[26,-11],[33,-7]])rpw2mDot(g,x,y,1,'#6af6ff',.6);const lw=Math.sin(a*2)*2;rpw2mLure(g,22,-14,44,-34,52+lw,-12,3,'#ff5ad8','#2a3a8a')}
 g.restore();
 /* surf where the body meets the water */
 const SP=[[-124,8],[-100,8],[-98,13],[-46,13],[-44,15],[10,15],[28,18]];SP.forEach((q,i)=>rpw2mSplash(g,q[0]+Math.sin(a-i)*1,yw+3,q[1],ph+i*.17,P.wat,i));
 if(V<2)for(let i=0;i<3;i++){const u=(ph+i/3)%1;rpw2mBub(g,-90+i*44+Math.sin(u*7)*3,yw-6-u*24,1.6+u*1.8,1-u)}
 else rpvSparks(g,-110,40,yw,50,ph,8,9,['#6af6ff','#ff8ae8'])};

/* ---------- registration ---------- */
Object.assign(RPMK,{crab:.82,shell:.98,shell_in:.98,puffer:.98,puffer_big:.98,jelly:.94,brute:.88,siren:1,squid:.88,leviathan:.9});
Object.assign(RPMB,{crab:[-37,-42,36,6,18],shell:[-40,-65,51,5,26],shell_in:[-36,-57,31,4,25],puffer:[-33,-66,39,5,18],puffer_big:[-39,-76,47,5,22],jelly:[-37,-78,31,24,14],brute:[-54,-103,64,5,34],siren:[-30,-88,38,10,15],squid:[-34,-74,27,5,15],leviathan:[-149,-142,153,12,100]});
RPW_MOBS.shell_in=2;RPW_MOBS.puffer_big=2;
RPMOB.shell_in=Object.assign({},RPMOB.shell);RPMOB.puffer_big=Object.assign({},RPMOB.puffer,{h:62,w:56});
/* new ids draw their own variant (World 3 ids and World 1 fall through to the previous rpvDraw) */
/* abyss: a soft cyan bioluminescent halo round the silhouette (bake time only), so the dark sea folk stay readable on the dark trench */
function rpw2mHalo(g,id,ph,v,k){const B=RPMB[id],t=g.getTransform(),sc=Math.max(1,Math.hypot(t.a,t.b)),m=5,w=Math.ceil((B[2]-B[0]+m*2)*sc),h=Math.ceil((B[3]-B[1]+m*2)*sc);
 const o=document.createElement('canvas');o.width=w;o.height=h;const q=o.getContext('2d');q.setTransform(sc,0,0,sc,(m-B[0])*sc,(m-B[1])*sc);q.lineJoin='round';q.lineCap='round';q.scale(k,k);RPMD[id](q,ph,{v});
 const hl=document.createElement('canvas');hl.width=w;hl.height=h;const r=hl.getContext('2d');r.drawImage(o,0,0);r.globalCompositeOperation='source-in';r.fillStyle='#5ae4ff';r.fillRect(0,0,w,h);
 const x0=B[0]-m,y0=B[1]-m,dw=w/sc,dh=h/sc,ga=g.globalAlpha;
 for(const [rr,al] of[[3,.13],[1.7,.3]])for(let i=0;i<8;i++){const t2=i*Math.PI/4;g.globalAlpha=ga*al;g.drawImage(hl,x0+Math.cos(t2)*rr,y0+Math.sin(t2)*rr,dw,dh)}
 g.globalAlpha=ga;g.drawImage(o,x0,y0,dw,dh)}
{const d0=rpvDraw;rpvDraw=function(g,id,ph,v){if(RPW_MOBS[id]!==2||!RPMD[id])return d0.apply(this,arguments);ph=+ph||0;ph-=Math.floor(ph);v=rpvV(id,v);
 g.save();g.lineJoin='round';g.lineCap='round';const k=RPMK[id]||1;try{if(v==='abyss'&&!RPW2M.noHalo)rpw2mHalo(g,id,ph,v,k);else{g.scale(k,k);RPMD[id](g,ph,{v})}}finally{g.restore()}}}

/* the pose sprites share their parent's names */
for(const v of RPW_VARS[2]){const T=RPMOBV[v];if(T){if(T.shell)T.shell_in=T.shell;if(T.puffer)T.puffer_big=T.puffer}}
/* ---------- deaths: a white pop, a splash ring, then sea debris on arcs (deterministic, no state) ---------- */
/* kinds: shard / plate (shell pieces), claw, drop (water), bub (bubble, rises), ink, note (rises), thorn, plank, barn, X = the variant's own bit
   (coral: a starfish, wreck: a gold coin, abyss: a glowing spark) */
const RPW2M_DX={
 crab:['shard','shard','shard','claw','claw','drop','drop','bub','X','X'],
 shell:['plate','plate','plate','plate','plate','drop','drop','bub','bub','X','X'],
 shell_in:['plate','plate','plate','plate','plate','drop','drop','bub','bub','X','X'],
 puffer:['thorn','thorn','thorn','thorn','drop','drop','drop','bub','bub','bub','X','X'],
 puffer_big:['thorn','thorn','thorn','thorn','thorn','thorn','drop','drop','drop','bub','bub','bub','X','X'],
 jelly:['drop','drop','drop','drop','drop','drop','bub','bub','bub','X','X'],
 brute:['shard','shard','shard','shard','plate','plate','barn','barn','barn','claw','drop','drop','drop','bub','bub','X','X','X'],
 siren:['note','note','note','drop','drop','drop','plate','plate','bub','bub','X','X'],
 squid:['ink','ink','ink','ink','drop','drop','bub','bub','X','X'],
 leviathan:['plate','plate','plate','plate','plate','plate','shard','shard','shard','drop','drop','drop','drop','drop','drop','bub','bub','bub','bub','X','X','X','X','X']};
/* colours: [main, second, water] per variant and monster */
const RPW2M_DC={
 coral:{crab:['#ff6a48','#ffd9a4'],shell:['#ff8a78','#52c4a2'],puffer:['#ffd23a','#26b8c8'],jelly:['#ffb0dc','#ff8ac8'],brute:['#ffb488','#e8503a'],siren:['#1eb4a8','#ff6aa8'],squid:['#ff7a5a','#2a1838'],leviathan:['#1ab4aa','#ff7a9a'],_:{w:'#7ae8f8',x:'#ffd23a'}},
 wreck:{crab:['#b8442c','#2a3e9a'],shell:['#7c7270','#93a46e'],puffer:['#4e566e','#9a6a46'],jelly:['#9ae8cc','#ffb84a'],brute:['#a8703e','#b03c2a'],siren:['#2e6a5e','#ffcf4a'],squid:['#8a4aa8','#1a1024'],leviathan:['#4e6c64','#a84a32'],_:{w:'#a8d8d0',x:'#ffc93a'}},
 abyss:{crab:['#26346a','#6af6ff'],shell:['#1a2452','#6af6ff'],puffer:['#202c62','#6af6ff'],jelly:['#4a3aa8','#6af0ff'],brute:['#1a2050','#ff5ad8'],siren:['#1a2258','#6af6ff'],squid:['#2a2070','#3a0a4a'],leviathan:['#1a2460','#6af0ff'],_:{w:'#4a9aff',x:'#6af6ff'}}};
function rpw2mDeath(c,id,x,y,k,o){const M=RPMOB[id],K=RPW2M_DX[id];if(!M||!K||!(k<1))return;k=Math.max(0,k);o=o||{};
 const v=rpvV(id,o.v),VT=RPW2M_DC[v],X=VT._,pid=id==='shell_in'?'shell':id==='puffer_big'?'puffer':id,C=VT[pid];
 const s=o.s>0?o.s:1,fl=o.flip?-1:1,h=M.h*s,lift=M.air?(M.lift||38)*s:0,cy=y-lift-h*.5,ga=c.globalAlpha,seed=o.seed==null?Math.round(x*7+y*3):o.seed,big=M.boss?1:0;
 const fade=k<.6?1:1-(k-.6)/.4;
 if(k<.3){const u=k/.3;c.save();c.globalCompositeOperation='lighter';c.globalAlpha=ga*(1-u)*.7;const r=h*(.55+u*.5);const q=c.createRadialGradient(x,cy,0,x,cy,r);q.addColorStop(0,'rgba(235,252,255,.9)');q.addColorStop(1,'rgba(235,252,255,0)');c.fillStyle=q;c.fillRect(x-r,cy-r,r*2,r*2);c.restore()}
 if(k<.22){const S=rpvSheet(id,o.v);if(S){if(!S.wh2)S.wh2=rpvTint(S,0);const u=k/.22;c.save();c.globalAlpha=ga*(1-u);c.translate(x,y-lift);c.scale(fl*(1+u*.3),1-u*.55);c.drawImage(S.wh2,0,0,S.fw/2,S.fh/2,S.B[0]*s,S.B[1]*s,S.w*s,S.h*s);c.restore()}}
 /* the splash: a ring of water on the ground (a second one for the boss) and a puddle */
 for(let i=0;i<=big;i++){const kk=Math.max(0,k-i*.15),r=M.w*s*(.35+kk*.85)*(big?.8:1);if(kk>0&&kk<1){c.globalAlpha=ga*(1-kk)*.85;c.lineWidth=(big?5:3)*s*(1-kk)+1;c.strokeStyle=X.w;c.beginPath();c.ellipse(x,y,r,r*.28,0,0,RPMT);c.stroke();
  c.globalAlpha=ga*(1-kk)*.6;c.lineWidth=1.2*s;c.strokeStyle='#ffffff';c.beginPath();c.ellipse(x,y,r*.8,r*.22,0,0,RPMT);c.stroke()}}
 {const u=Math.min(1,k/.25),r=M.w*s*.42*(.6+u*.5);c.globalAlpha=ga*fade*.45;c.fillStyle=id==='squid'?C[1]:X.w;c.beginPath();c.ellipse(x,y,r,r*.22,0,0,RPMT);c.fill()}
 const G=h*3.4,T=k,n=K.length;
 for(let i=0;i<n;i++){let kd=K[i];const r1=rpmRn(seed+i*3.1),r2=rpmRn(seed+i*5.7+1),r3=rpmRn(seed+i*1.3+2);if(kd==='X')kd=v==='coral'?'star':v==='wreck'?'coin':'spark';
  const up=kd==='bub'||kd==='note'||kd==='spark',ang=-Math.PI/2+(r1-.5)*2.4,sp=h*(up?.45:1)*(.9+r2*1.1)*(big?1.25:1);
  let px=x+Math.cos(ang)*sp*T*fl+(r3-.5)*M.w*s*.3,py=cy+(r2-.5)*h*.4+Math.sin(ang)*sp*T+(up?-.25*G*T*T:.5*G*T*T);
  const sz=(kd==='plate'||kd==='shard'?(big?9:5.4):kd==='drop'?3:kd==='bub'?2.6+k*2:kd==='coin'?3.4:kd==='star'?4.4:kd==='barn'?3.4:3.6)*s*(.75+r3*.6);
  if(up)px+=Math.sin(T*8+i)*5*s;
  if(!up&&py>y-sz*.4)py=y-sz*.4;
  const rot=(r1*6+T*(8+r2*10))*(r3>.5?1:-1);c.globalAlpha=ga*fade;
  if(kd==='bub'){rpw2mBub(c,px,py,sz,(1-k)*.9,'#e8fcff');continue}
  if(kd==='spark'){c.save();c.globalCompositeOperation='lighter';c.fillStyle=i%2?X.x:'#ff8ae8';c.beginPath();c.arc(px,py,sz*(1-k*.5),0,RPMT);c.fill();c.globalAlpha=ga*fade*.35;c.beginPath();c.arc(px,py,sz*2.4*(1-k*.5),0,RPMT);c.fill();c.restore();continue}
  if(kd==='note'){c.save();c.globalAlpha=ga*fade*(1-k*.5);rpw2mNote(c,px,py,s*.75,C[1],Math.sin(T*6+i)*.4);c.restore();continue}
  if(kd==='drop'){c.save();c.translate(px,py);c.rotate(Math.atan2(Math.sin(ang)*sp+G*T,Math.cos(ang)*sp*fl)-Math.PI/2);c.fillStyle=X.w;c.beginPath();c.moveTo(0,-sz*1.6);c.quadraticCurveTo(sz,0,0,sz);c.quadraticCurveTo(-sz,0,0,-sz*1.6);c.fill();c.lineWidth=1*s;c.strokeStyle=RPMO;c.stroke();
   c.fillStyle='rgba(255,255,255,.7)';c.beginPath();c.arc(-sz*.3,0,sz*.3,0,RPMT);c.fill();c.restore();continue}
  if(kd==='ink'){c.fillStyle=C[1];c.beginPath();c.ellipse(px,py,sz*1.3,sz*1.1,rot,0,RPMT);c.fill();c.lineWidth=1.2*s;c.strokeStyle=RPMO;c.stroke();c.fillStyle='rgba(255,255,255,.35)';c.beginPath();c.arc(px-sz*.4,py-sz*.4,sz*.3,0,RPMT);c.fill();continue}
  if(kd==='star'){c.save();rpw2mStar(c,px,py,sz,rot,X.x,'#f08a1a');c.restore();continue}
  if(kd==='barn'){c.save();rpw2mBarn(c,px,py,sz,rot,v==='abyss'?'#5a6a9a':'#e8e0d0');c.restore();continue}
  c.save();c.translate(px,py);c.rotate(rot);c.lineWidth=1.3*s;c.strokeStyle=RPMO;c.beginPath();
  if(kd==='coin'){const w=Math.abs(Math.cos(T*14+i))*sz+.6;c.ellipse(0,0,w,sz,0,0,RPMT);c.fillStyle=X.x;c.fill();c.stroke();c.fillStyle='#fff6c8';c.beginPath();c.ellipse(-w*.3,-sz*.3,w*.25,sz*.25,0,0,RPMT);c.fill()}
  else if(kd==='plate'){for(let j=0;j<6;j++){const t=j*Math.PI/3;j?c.lineTo(Math.cos(t)*sz,Math.sin(t)*sz*.86):c.moveTo(sz,0)}c.closePath();c.fillStyle=i%3?C[0]:C[1];c.fill();c.stroke();c.fillStyle='rgba(255,255,255,.3)';c.beginPath();c.arc(-sz*.2,-sz*.2,sz*.35,0,RPMT);c.fill()}
  else if(kd==='shard'){c.moveTo(-sz,-sz*.5);c.lineTo(sz*.4,-sz);c.lineTo(sz,sz*.2);c.lineTo(-sz*.3,sz*.8);c.closePath();c.fillStyle=i%3?C[0]:C[1];c.fill();c.stroke()}
  else if(kd==='claw'){c.moveTo(-sz,sz*.6);c.quadraticCurveTo(-sz*1.2,-sz,sz*.4,-sz*1.4);c.quadraticCurveTo(-sz*.2,-sz*.4,sz*.4,sz*.6);c.closePath();c.fillStyle=C[0];c.fill();c.stroke()}
  else if(kd==='thorn'){c.moveTo(-sz*.6,0);c.lineTo(0,-sz*2.2);c.lineTo(sz*.6,0);c.closePath();c.fillStyle=C[1];c.fill();c.stroke()}
  else{c.rect(-sz*1.4,-sz*.5,sz*2.8,sz);c.fillStyle='#9a6a3a';c.fill();c.stroke()}
  c.restore()}
 c.globalAlpha=ga}
{const d0=rpMobDeath;rpMobDeath=function(c,id){if(RPW_MOBS[id]===2&&RPW2M_DX[id])return rpw2mDeath.apply(this,arguments);return d0.apply(this,arguments)}}
/* a battle start prebakes every monster in the map's variant (95e: rpMobPrebake(null, pal)); World 2 sheets are only baked on World 2 maps */
{const p0=rpMobPrebake;rpMobPrebake=function(ids,v){if(!ids)ids=Object.keys(RPMOB).filter(id=>RPW_MOBS[id]!==2||RPW_VARS[2].includes(v));return p0.call(this,ids,v)}}
/* World 1 style entries too, so anything reading RPMDX finds the new ids */
for(const id of RPW2M_IDS)RPMDX[id]={n:6,k:['puff','puff','spark','spark','puff','spark'],c:[RPW2M_DC.coral[id==='shell_in'?'shell':id==='puffer_big'?'puffer':id][0],'#7ae8f8']};
