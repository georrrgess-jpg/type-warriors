/* ===== 9.5 THE CROOKED CUE: How to Play (96v) =====
   House Rules becomes an illustrated, tabbed How to Play: Basics, Shooting, Fouls, the 8 and Controls, each lesson a
   baked little diagram and two lines. The full screen (from the hub) also has "Replay tutorials" and "Practice";
   the pause menu shows the same tabs in its wide modal. */
const PZ_HOW_ART={};
function pzHowArt(kind){if(PZ_HOW_ART[kind])return PZ_HOW_ART[kind];const W=320,H=180,c=pzCv(W*2,H*2),g=c.getContext('2d');g.scale(2,2);g.lineJoin='round';g.lineCap='round';const O=PZ_O;
 const tbl=()=>{g.fillStyle='#6a3414';pzRR(g,6,6,W-12,H-12,16);g.fill();g.strokeStyle=O;g.lineWidth=3;g.stroke();g.fillStyle=pzLin(g,0,20,0,H-20,[[0,'#2e8f5e'],[1,'#1b6a45']]);pzRR(g,20,20,W-40,H-40,6);g.fill();g.lineWidth=2;g.stroke();
  for(const [x,y] of[[20,20],[W/2,17],[W-20,20],[20,H-20],[W/2,H-17],[W-20,H-20]]){g.fillStyle='#07040a';g.beginPath();g.arc(x,y,9,0,TAU);g.fill();g.strokeStyle='#c99a3a';g.lineWidth=2;g.stroke()}
  g.fillStyle='rgba(255,255,255,.07)';g.fillRect(24,24,W-48,10)};
 const PAL=['#fff8ec','#f2c230','#2a5ad8','#d83a2a','#7a3ab8','#f07a20','#1a8a4a','#8a2a1a','#141414'];
 const ball=(x,y,n,r)=>{r=r||10;const s=n>8,col=n===0?PAL[0]:PAL[n>8?n-8:n];g.fillStyle=s?'#fff8ec':col;g.beginPath();g.arc(x,y,r,0,TAU);g.fill();
  if(s){g.save();g.beginPath();g.arc(x,y,r,0,TAU);g.clip();g.fillStyle=col;g.fillRect(x-r,y-r*.5,r*2,r);g.restore()}
  if(n>0){g.fillStyle='#fff';g.beginPath();g.arc(x,y,r*.45,0,TAU);g.fill();g.fillStyle='#12081f';g.font=`800 ${Math.round(r*.62)}px Poppins,sans-serif`;g.textAlign='center';g.textBaseline='middle';g.fillText(n,x,y+.5)}
  g.fillStyle='rgba(255,255,255,.5)';g.beginPath();g.ellipse(x-r*.35,y-r*.4,r*.28,r*.18,-.5,0,TAU);g.fill();g.strokeStyle=O;g.lineWidth=2.2;g.beginPath();g.arc(x,y,r,0,TAU);g.stroke()};
 const dots=(pts,col,w)=>{g.setLineDash([2,7]);g.strokeStyle=col;g.lineWidth=w||3.5;g.beginPath();pts.forEach(([x,y],i)=>i?g.lineTo(x,y):g.moveTo(x,y));g.stroke();g.setLineDash([])};
 const ring=(x,y,col)=>{g.strokeStyle=col;g.lineWidth=3.5;g.beginPath();g.arc(x,y,15,0,TAU);g.stroke()};
 const cross=(x,y,s)=>{s=s||9;g.strokeStyle='#12081f';g.lineWidth=8;g.beginPath();g.moveTo(x-s,y-s);g.lineTo(x+s,y+s);g.moveTo(x+s,y-s);g.lineTo(x-s,y+s);g.stroke();g.strokeStyle='#ff5a5a';g.lineWidth=4.5;g.stroke()};
 const tick=(x,y)=>{g.strokeStyle='#12081f';g.lineWidth=8;g.beginPath();g.moveTo(x-9,y);g.lineTo(x-2,y+8);g.lineTo(x+11,y-8);g.stroke();g.strokeStyle='#8affb4';g.lineWidth=4.5;g.stroke()};
 const arrow=(x0,y0,x1,y1,col)=>{const a=Math.atan2(y1-y0,x1-x0);g.strokeStyle=O;g.lineWidth=8;g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.stroke();g.beginPath();g.moveTo(x1,y1);g.lineTo(x1-Math.cos(a-.5)*13,y1-Math.sin(a-.5)*13);g.moveTo(x1,y1);g.lineTo(x1-Math.cos(a+.5)*13,y1-Math.sin(a+.5)*13);g.stroke();
  g.strokeStyle=col;g.lineWidth=4;g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.moveTo(x1,y1);g.lineTo(x1-Math.cos(a-.5)*13,y1-Math.sin(a-.5)*13);g.moveTo(x1,y1);g.lineTo(x1-Math.cos(a+.5)*13,y1-Math.sin(a+.5)*13);g.stroke()};
 const cue=(x,y,a,len)=>{g.save();g.translate(x,y);g.rotate(a);g.fillStyle='#e8c88a';g.fillRect(-len,-3,len*.7,6);g.fillStyle='#5a1a1a';g.fillRect(-len,-4,len*.3,8);g.fillStyle='#3a70d8';g.fillRect(-len*.3-4,-3,4,6);g.strokeStyle=O;g.lineWidth=2;g.strokeRect(-len,-4,len,8);g.restore()};
 const label=(t,x,y,col)=>{g.font='800 12px Poppins,sans-serif';g.textAlign='center';g.textBaseline='middle';g.lineWidth=4;g.strokeStyle=O;g.strokeText(t,x,y);g.fillStyle=col||'#fff';g.fillText(t,x,y)};
 if(kind==='groups'){tbl();[[70,70,1],[95,100,2],[70,120,3],[110,62,4]].forEach(([x,y,n])=>ball(x,y,n));[[215,70,9],[245,100,10],[210,118,11],[250,58,12]].forEach(([x,y,n])=>ball(x,y,n));label('SOLIDS 1-7',90,148,'#ffd45a');label('STRIPES 9-15',230,148,'#ffd45a')}
 else if(kind==='eight'){tbl();ball(150,98,0);ball(232,60,8);dots([[232,60],[W-28,26]],'#ffd45a');ring(W-20,20,'#8affb4');arrow(110,124,140,105,'#efe8ff');label('CALLED',W-60,48,'#8affb4')}
 else if(kind==='race'){g.fillStyle='#140c36';pzRR(g,6,6,W-12,H-12,16);g.fill();for(let k=0;k<3;k++){const x=70+k*90,y=96,on=k<2;g.save();g.translate(x,y);g.fillStyle=on?'#ffd45a':'#2a2070';g.beginPath();g.moveTo(0,-34);g.lineTo(34,26);g.lineTo(-34,26);g.closePath();g.fill();g.strokeStyle=O;g.lineWidth=3;g.stroke();
   if(on){for(const [bx,by,n] of[[0,-14,1],[-10,4,9],[10,4,3]])ball(bx,by,n,8.5)}g.restore()}label('FIRST TO THE RACE TARGET WINS',W/2,154,'#efe8ff')}
 else if(kind==='aim'){tbl();ball(76,110,0);g.strokeStyle='rgba(255,255,255,.6)';g.lineWidth=2;g.setLineDash([3,5]);g.beginPath();g.arc(196,76,10,0,TAU);g.stroke();g.setLineDash([]);dots([[86,106],[190,78]],'#efe8ff',2.5);ball(214,70,3);dots([[214,70],[W-28,26]],'#ffd45a');ring(W-20,20,'#8affb4');dots([[196,76],[232,140]],'#7ad8ff');label('GOLD: THE BALL',100,40,'#ffd45a');label('BLUE: CUE BALL',236,152,'#7ad8ff')}
 else if(kind==='power'){tbl();ball(170,90,0);cue(152,90,0,110);arrow(118,118,62,118,'#ffd45a');label('PULL BACK',92,140,'#ffd45a');ball(250,90,5);arrow(186,66,232,66,'#8affb4');label('LET GO',210,46,'#8affb4')}
 else if(kind==='spin'){g.fillStyle='#140c36';pzRR(g,6,6,W-12,H-12,16);g.fill();ball(90,90,0,52);for(const [dx,dy,col] of[[0,-30,'#8affb4'],[0,30,'#ff9a4a'],[30,0,'#c8a0ff']]){g.fillStyle=col;g.beginPath();g.arc(90+dx,90+dy,8,0,TAU);g.fill();g.strokeStyle=O;g.lineWidth=2;g.stroke()}
  label('HIGH: FOLLOW',236,46,'#8affb4');label('LOW: DRAW BACK',236,90,'#ff9a4a');label('SIDE: BENDS',236,134,'#c8a0ff')}
 else if(kind==='scratch'){tbl();ball(150,100,3);dots([[110,60],[146,96]],'#efe8ff',2.5);dots([[152,104],[W/2,H-24]],'#7ad8ff');g.globalAlpha=.85;ball(W/2,H-20,0,8);g.globalAlpha=1;cross(W/2+24,H-40);label('CUE BALL IN = FOUL',W/2,40,'#ff9a9a')}
 else if(kind==='wrong'){tbl();ball(90,90,0);dots([[100,90],[184,90]],'#efe8ff',2.5);ball(196,90,11);ball(250,120,2);cross(196,60);label('YOU ARE SOLIDS',170,148,'#ffd45a');label('STRIPE FIRST = FOUL',170,34,'#ff9a9a')}
 else if(kind==='bih'){tbl();ball(214,82,6);ball(250,120,4);g.save();g.translate(130,96);g.fillStyle='#f2d6b0';g.beginPath();g.ellipse(0,0,20,16,-.3,0,TAU);g.fill();g.strokeStyle=O;g.lineWidth=3;g.stroke();for(let i=0;i<3;i++){g.beginPath();g.ellipse(-12+i*10,-16,5,9,0,0,TAU);g.fillStyle='#f2d6b0';g.fill();g.stroke()}g.restore();ball(150,118,0);arrow(150,150,150,132,'#8affb4');label('PLACE IT ANYWHERE',W/2,40,'#8affb4')}
 else if(kind==='guide'){tbl();ball(70,120,0);ball(170,84,2);dots([[170,84],[W-60,42]],'#ffd45a');ball(230,140,13);dots([[80,118],[160,90]],'#efe8ff',2.5);dots([[160,92],[196,140]],'#7ad8ff');label('GOLD = OBJECT BALL',110,40,'#ffd45a')}
 else if(kind==='taunt'){g.fillStyle='#140c36';pzRR(g,6,6,W-12,H-12,16);g.fill();g.fillStyle='#efe8ff';pzRR(g,40,46,240,52,14);g.fill();g.strokeStyle=O;g.lineWidth=3;g.stroke();g.font='700 22px Poppins,sans-serif';g.textAlign='left';g.textBaseline='middle';g.fillStyle='#8a80c8';g.fillText('drip drip',60,72);g.fillStyle='#24124a';g.fillText('drip',60,72);
  g.fillStyle='#12081f';pzRR(g,40,112,240,14,7);g.fill();g.fillStyle='#ff9ad0';pzRR(g,42,114,150,10,5);g.fill();label('TYPE IT: THEIR NEXT SHOT WOBBLES',W/2,150,'#ff9ad0')}
 else if(kind==='fast'){g.fillStyle='#140c36';pzRR(g,6,6,W-12,H-12,16);g.fill();g.fillStyle='#2a2070';pzRR(g,84,52,152,58,14);g.fill();g.strokeStyle=O;g.lineWidth=3;g.stroke();label('SPACE',160,82,'#fff2c8');for(let k=0;k<2;k++){g.fillStyle='#ffd45a';g.beginPath();g.moveTo(250+k*22,62);g.lineTo(270+k*22,82);g.lineTo(250+k*22,102);g.closePath();g.fill();g.strokeStyle=O;g.lineWidth=2.5;g.stroke()}label('HOLD TO FAST-FORWARD',W/2,142,'#efe8ff')}
 return PZ_HOW_ART[kind]=c}
const PZ_HOW=[
 {k:'basics',t:'Basics',cards:[['groups','Solids or stripes','After the break, the first ball you pot picks your group. Your opponent gets the other one.'],['eight','Then the 8','Clear your group, <b>call a pocket</b> and sink the 8 there to win the rack. Sink it early and you lose the rack.'],['race','Win the race','A match is a race: the first to win the target number of racks (shown at the top) takes the pot.']]},
 {k:'shoot',t:'Shooting',cards:[['aim','Aim','<b>Move the mouse</b>. The guide shows the shot: gold for the ball you hit, blue for the cue ball.'],['power','Power','<b>Press on the table, pull back and let go</b>. Or set the power bar and press SHOOT (<kbd>Space</kbd>).'],['spin','Spin','Click the <b>spin ball</b> at the bottom left. Low draws the cue ball back, high makes it follow.']]},
 {k:'fouls',t:'Fouls',cards:[['scratch','Scratch','The cue ball drops in a pocket. Also a foul: hitting nothing, or no ball reaching a cushion after the hit.'],['wrong','Wrong ball first','Your first contact must be one of your own balls (or any ball while the table is open).'],['bih','Ball in hand','After a foul the other player may <b>place the cue ball anywhere</b>. Do not hand it to the monsters!']]},
 {k:'extras',t:'Guide & extras',cards:[['guide','The guide','<b>Gold</b>: where the ball you hit heads, up to its first cushion. <b>Blue</b>: the cue ball\'s first path. You judge the pocket. <kbd>G</kbd> switches Full / Short / Pro.'],['taunt','Taunts','When a monster misses you may get a taunt: <b>type it in time</b> and its next shot wobbles. <kbd>Esc</kbd> skips it.'],['fast','Fast-forward','Hold <kbd>Space</kbd> or the mouse while balls roll or a monster thinks. Paid matches run a shot clock.']]},
 {k:'keys',t:'Controls',keys:[['Mouse','Aim; press, pull back and let go to shoot'],['Shift / right button','Fine aim (slow mouse)'],['Wheel, ◀ ▶ arrows','Nudge the aim (Shift for tiny steps)'],['Space','Shoot with the power bar; hold to fast-forward'],['W A S D / R','Set the spin / reset it'],['1 - 6','Call a pocket for the 8'],['G','Change the guide'],['Esc','Menu (pause, rules, settings, forfeit)']]}];
function pzHowBody(tab,full){const T=PZ_HOW.find(x=>x.k===tab)||PZ_HOW[0];
 const body=T.keys?`<div class="pzhowk">${T.keys.map(([a,b])=>`<div><kbd>${a}</kbd><span>${b}</span></div>`).join('')}</div>`:`<div class="pzhowc">${T.cards.map(([art,h,p],i)=>`<div class="pzhcard" style="--i:${i}"><canvas width="640" height="360" data-how="${art}"></canvas><b>${h}</b><p>${p}</p></div>`).join('')}</div>`;
 return `<div class="pzhow ${full?'full':''}"><div class="pzhtabs">${PZ_HOW.map(x=>`<button data-h="${x.k}" class="${x.k===T.k?'on':''}">${x.t}</button>`).join('')}</div><div class="pzhbody" id="pzhbody">${body}</div></div>`}
function pzHowWire(host,full){const draw=()=>host.querySelectorAll('canvas[data-how]').forEach(cv=>{const g=cv.getContext('2d');g.drawImage(pzHowArt(cv.dataset.how),0,0)});draw();
 host.querySelectorAll('.pzhtabs button').forEach(b=>b.onclick=()=>{PZ.howTab=b.dataset.h;pzFx('tick');const box=host.querySelector('.pzhow');const n=document.createElement('div');n.innerHTML=pzHowBody(PZ.howTab,full);box.replaceWith(n.firstElementChild);pzHowWire(host,full)})}
function pzRules(){const tk=PZ.tok;PZ.howTab=PZ.howTab||'basics';
 show(`<div class="pzr pzhowscr" id="pzr"><canvas id="pzrbg" width="1600" height="900"></canvas><button class="pzback" id="pzbk">‹&nbsp; The bar</button><div class="pztitle sm">How to Play</div>
  <div class="pzrp pzhp">${pzHowBody(PZ.howTab,true)}<div class="pzhfoot"><button class="pzmb" id="pzhre">Replay the tutorials</button><button class="pzmb gold" id="pzhpr">Try it at the Practice Table</button></div></div></div>`,'casbg pzx');
 $('pzrbg').getContext('2d').drawImage(pzHubBake(),0,0);$('pzbk').onclick=()=>pzHub();S.back=()=>pzHub();pzHowWire($('pzr'),true);
 $('pzhre').onclick=()=>{pzCoachReset();pzFx('place');pzNote('Tutorials reset: they will show again as you play.');PZ.sel=null;const tk=PZ.tok;setTimeout(()=>{if(PZ.tok===tk&&$('pzhbody'))pzHub()},700)};
 $('pzhpr').onclick=()=>{pzMusicOff();pzStart({opp:'gloop',practice:true})};
 pzFitTM()}
if(!window.__pzHowKeys){window.__pzHowKeys=1;addEventListener('keydown',e=>{try{if(!$('pzhbody')||e.repeat||pzCoachActive())return;if(e.key!=='ArrowLeft'&&e.key!=='ArrowRight')return;const bs=[...document.querySelectorAll('.pzhtabs button')],i=bs.findIndex(b=>b.classList.contains('on')),n=bs[(i+(e.key==='ArrowRight'?1:-1)+bs.length)%bs.length];if(n){e.preventDefault();e.stopImmediatePropagation();n.click()}}catch(err){}},true)}
function pzRulesModal(){PZ.howTab=PZ.howTab||'basics';const m=pzModal(`<div class="pzh2">How to Play</div>${pzHowBody(PZ.howTab,false)}<button class="pzmb gold" data-a="back">Back</button>`,'pause wide how');pzHowWire(m,false);m.querySelector('[data-a=back]').onclick=()=>pzPauseMenu(true)}
{const st=document.createElement('style');st.textContent=`
.pzhp{left:150px;top:132px;width:1300px;box-sizing:border-box;padding:18px 26px 22px}
.pzhow{text-align:left}
.pzhtabs{display:flex;gap:8px;justify-content:center;margin-bottom:16px}
.pzhtabs button{height:44px;padding:0 20px;border-radius:14px;border:3px solid #12081f;background:#2a2070;color:#c4badf;font:800 15px Poppins,sans-serif;cursor:pointer;transition:transform .15s cubic-bezier(.3,1.6,.5,1)}
.pzhtabs button:hover{transform:translateY(-2px)}.pzhtabs button.on{background:linear-gradient(180deg,#ffe27a,#f2b631);color:#2a1a04;transform:translateY(-3px);box-shadow:0 4px 0 #9a6a10}
.pzhowc{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}
.pzhcard{background:#140c36;border:2px solid #3a3070;border-radius:18px;padding:12px 12px 14px;animation:pzhcIn .4s calc(var(--i)*.07s) cubic-bezier(.25,1.3,.45,1) both}
.pzhcard canvas{display:block;width:100%;aspect-ratio:16/9;border-radius:12px}
.pzhcard>b{display:block;margin:10px 4px 4px;font:400 28px/1.1 "Pirata One",Georgia,serif;color:#ffd45a}
.pzhcard p{margin:0 4px;font-size:14px;line-height:1.45;color:#d8d0f4;font-weight:500}.pzhcard p b{display:inline;margin:0;font:800 14px Poppins,sans-serif;color:#fff2c8}
.pzhow kbd{display:inline-block;padding:0 6px;border-radius:6px;background:#0a0620;border:1px solid #5a4ca0;font:800 12px/20px Poppins,sans-serif;color:#fff2c8}
.pzhowk{display:grid;grid-template-columns:1fr 1fr;gap:10px 22px;padding:6px 8px}
.pzhowk div{display:flex;align-items:center;gap:14px;padding:12px 14px;border-radius:14px;background:#140c36;border:2px solid #3a3070;animation:pzhcIn .35s both}
.pzhowk kbd{flex:none;min-width:150px;text-align:center;font-size:14px;line-height:30px}.pzhowk span{font-size:15px;color:#e2dafc;font-weight:600}
.pzhfoot{display:flex;justify-content:center;gap:14px;margin-top:18px}.pzhfoot .pzmb{width:auto;padding:0 24px;margin:0}
.pzmod.how .pzmp{width:1120px}.pzmod.how .pzhowc{gap:12px}.pzmod.how .pzhcard>b{font-size:23px}.pzmod.how .pzhcard p{font-size:12.5px}.pzmod.how .pzhtabs button{height:38px;font-size:13px;padding:0 14px}
.pzhowscr .pztitle{top:22px}
@keyframes pzhcIn{from{opacity:0;transform:translateY(18px) scale(.97)}to{opacity:1;transform:none}}
`;document.head.appendChild(st)}
