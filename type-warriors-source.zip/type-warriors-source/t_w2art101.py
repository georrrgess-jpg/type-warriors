# python3 t_w2art101.py [game.html] [--shots DIR] : World 2 polish (10.1, 98f3 + the 98f / 98f2 edits).
# Real mouse clicks through the battle canvas: pads, towers and monsters still win (select, build) and never trigger a reaction; clicks
# on the scenery do (lighthouse, chests, crabs, gulls, palms, water, the ship, the cannon, the skull rock, fog, the Kraken's eye and
# tentacles, glowcaps, clams, vents); battle events (wading splashes, crabs hiding from monsters, gulls scared by the cannon, glowcaps
# flaring when a tower fires, whirlpools spinning faster with monsters in them, the eye following the pointer); frame cost with
# reactions running (full, lite, reduced motion); the hub painting's live overlay. With --shots it saves before/after style shots.
import asyncio,os,sys,base64
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
A=[a for a in sys.argv[1:] if not a.startswith('--')]
SHOTS=sys.argv[sys.argv.index('--shots')+1] if '--shots' in sys.argv else None
if SHOTS and SHOTS in A:A.remove(SHOTS)
H='file://'+os.path.abspath(A[0] if A else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:500]),flush=True)
    if not ok:FAIL.append(name)
HELP=r"""()=>{
 window.w2New=(m)=>{try{rpLeave()}catch(e){}rpStart(m);const R=RPX;R.tut=null;R.hold=true;R.supply=1e9;R.banner=null;R.pause=false;const el=document.getElementById('rptut');if(el)el.style.display='none';return R};
 window.w2Full=(R)=>{const T=RP_TWORDER;R.pads.forEach((p,i)=>{if(i%5===4)return;rpBuild(p,T[i%T.length]);if(p.tw){p.tw.build=1;for(let k=0;k<i%3;k++)try{rpUpgrade(p.tw)}catch(e){}p.tw.upK=1}});
  const ids=['crab','shell','puffer','jelly','squid','siren','brute'];for(let i=0;i<30;i++){const e=rpSpawn(ids[i%ids.length],i%R.G.paths.length);if(e)e.s=60+i*(R.G.paths[e.pi||0].len-200)/30}for(let i=0;i<20;i++)rpStep(R,1/30)};
 window.w2Cv=()=>{const c=document.createElement('canvas');c.width=1600;c.height=900;return c};
 window.w2Layers=(R,c)=>{const m=R.map.id;for(const f of[RPW.amb[m],RPW.twist[m],RPW.ambTop[m]])if(f){c.save();f(c,R);c.restore()}};
 window.w2Shot=(R)=>{const c=w2Cv(),g=c.getContext('2d');g.drawImage(R.bake.c,0,0);w2Layers(R,g);return c};
 window.w2Diff=(a,b,x0,y0,w,h)=>{const A=a.getContext('2d').getImageData(x0,y0,w,h).data,B=b.getContext('2d').getImageData(x0,y0,w,h).data;let n=0;for(let i=0;i<A.length;i+=4){if(Math.abs(A[i]-B[i])+Math.abs(A[i+1]-B[i+1])+Math.abs(A[i+2]-B[i+2])>24)n++}return n/(A.length/4)};
 window.w2Lum=(c,x0,y0,w,h)=>{const d=c.getContext('2d').getImageData(x0,y0,w,h).data;let s=0;for(let i=0;i<d.length;i+=4)s+=d[i]*.3+d[i+1]*.59+d[i+2]*.11;return s/(d.length/4)};
 window.w2Frames=(R,n,dt)=>{const c=w2Cv().getContext('2d');for(let i=0;i<n;i++){R.t+=dt||1/30;w2Layers(R,c)}};
 window.w2Last=()=>RPX.w2a?RPX.w2a.last||null:null;
 window.w2Reset=()=>{if(RPX.w2a)RPX.w2a.last=null};
 return 1}"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]));pg.on('console',lambda m:er.append(m.text[:300]) if m.type=='error' and 'WebSocket' not in m.text and 'relay' not in m.text else None)
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E("()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const r=RPP();r.new99j=1;r.dragon=1;r.stars=Object.assign(r.stars||{},{moss:3,frost:3,ember:3});for(const k in r.tut)r.tut[k]=1;for(const k in RP_TUT)r.tut[k]=1;for(const m of RP_MAPS)r.tut['twist_'+m.id]=1}")
        await E(HELP)
        async def click(x,y):
            await pg.mouse.move(x,y);await pg.mouse.click(x,y);await pg.wait_for_timeout(30)
        async def last():return await E("()=>w2Last()")
        # ---- the hooks
        r=await E("()=>[typeof rpw2aPoke,typeof rpw2aPokeOk,['coral','wreck','abyss'].every(m=>RPW.amb[m]&&RPW.ambTop[m]),!!RPW.twist.coral&&!!RPW.twist.abyss,typeof rpClick==='function']")
        chk('98f3 is wired: rpClick wrapped, the three maps\' layers wrapped',r==['function','function',True,True,True],r)
        # ---- clicks on pads, towers and monsters keep their meaning and never trigger a reaction
        await E("()=>{w2New('coral')}")
        P=await E("()=>RPX.pads.map(p=>[p.x,p.y])")
        px,py=P[2]
        await click(px,py)
        r=await E("()=>[RPX.selPad===RPX.pads[2],w2Last()]")
        chk('a click on an empty pad selects it (the build ring) and nothing else reacts',r==[True,None],r)
        await click(px,py);await E("()=>{w2Reset();RPX.place='ballista'}")
        await click(px,py+4)
        r=await E("()=>[!!RPX.pads[2].tw,RPX.pads[2].tw&&RPX.pads[2].tw.type,w2Last()]")
        chk('placing a tower and clicking a pad still builds it, with no reaction',r[0] and r[1]=='ballista' and r[2] is None,r)
        await E("()=>{RPX.pads[2].tw.build=1;RPX.sel=null;w2Reset()}")
        await click(px,py-50)
        r=await E("()=>[RPX.sel===RPX.pads[2].tw,w2Last()]")
        chk('a click on a tower selects it, with no reaction',r==[True,None],r)
        r=await E("""()=>{const R=RPX;R.sel=null;const e=rpSpawn('crab',0);e.s=900;const q=rpPos(R,e);return [q.x,q.y]}""")
        await click(r[0],r[1]-14)
        r2=await E("()=>w2Last()")
        chk('a click on a monster triggers no reaction',r2 is None,r2)
        await E("()=>{const R=RPX;for(const e of R.foes)e.dead=1;R.foes.length=0;R.pause=true;w2Reset()}")
        await click(560,820)
        r=await E("()=>w2Last()")
        chk('nothing reacts while the game is paused',r is None,r)
        await E("()=>{RPX.pause=false;try{hide()}catch(e){}RPX.aim='slow';w2Reset()}")
        r=await E("()=>{rpClick(560,820,0,false);return [w2Last(),RPX.aim]}")
        chk('nothing reacts while an ability is being aimed',r[0] is None,r)
        await E("()=>{RPX.aim=null;if(typeof rpHudOn==='function')rpHudOn()}")
        # ---- Coral Shallows reactions (real clicks)
        await E("()=>{const R=w2New('coral');R.t=5;w2Frames(R,3)}")
        B=await E("()=>{const B=rpw2aCoralInit(RPX.bake);return{light:B.light,ch:B.chests.map(c=>[c.x,c.y,c.s]),crab:B.crab,gs:B.gstand,palm:B.palms.slice().sort((a,b)=>b.y-a.y).filter(p=>p.cy>140&&p.cy<720&&p.cx>60&&p.cx<1540&&rpw2aHudFree(p.cx,p.cy)&&!RPX.pads.some(q=>Math.hypot(q.x-p.cx,q.y-p.cy)<110)).map(p=>[p.cx,p.cy,p.i,p.h])}}")
        L=B['light']
        a=await E("()=>{const c=w2Shot(RPX);window._a=c;return 1}")
        await click(L['x'],L['y']+60)
        r=await E("()=>{const R=RPX;w2Frames(R,6);const b=w2Shot(R);const L=R.bake.light;return [w2Last(),+(w2Lum(b,L.x-30,L.y-30,60,60)-w2Lum(_a,L.x-30,L.y-30,60,60)).toFixed(1)]}")
        chk(f'coral: clicking the lighthouse flashes its lamp (+{r[1]} brightness) and spins the beam',r[0]=='light' and r[1]>8,r)
        cx,cy,cs=B['ch'][0]
        await click(cx,cy-cs*.4)
        r=await E(f"()=>{{const R=RPX;w2Frames(R,6);const b=w2Shot(R);return [w2Last(),R.w2a.ev.some(e=>e.k==='coins'),+w2Diff(_a,b,{cx}-30|0,{cy}-50|0,60,60).toFixed(3)]}}")
        chk('coral: clicking a treasure chest pops it open with coins and sparkles',r[0]=='chest' and r[1] and r[2]>0.15,r)
        wp=await E("()=>{w2New('coral');RPX.t=9;w2Frames(RPX,2);const F=RPX.bake.F;for(let i=0;i<4000;i++){const x=40+rpw2aR(i*2+1)*1520,y=40+rpw2aR(i*2+2)*820;if(F.at(x,y)>30&&rpw2aHudFree(x,y)&&!rpPick(RPX,x,y))return [x,y]}return null}")
        await click(wp[0],wp[1])
        r=await E("()=>{const R=RPX;const ev=R.w2a.ev.find(e=>e.k==='rip');w2Frames(R,6);return [w2Last(),!!ev]}")
        chk('coral: clicking the water sends out ripples (and the fish and turtle nearby scatter)',r==['water',True],r)
        k=B['crab'][1]
        await click(k[0],k[1]-6)
        r=await E("()=>{const R=RPX;w2Frames(R,12);return [w2Last(),+R.w2a.cr[1].h.toFixed(2)]}")
        chk('coral: a clicked crab ducks into the sand',r[0]=='crab' and r[1]>0.9,r)
        r=await E(f"""()=>{{const R=w2New('coral');R.t=3;w2Frames(R,40);const h0=R.w2a.cr[0].h;const B=R.bake,k=B.crab[0];let best=null,bd=1e9;for(const P of [R.G.paths[0]])for(let i=0;i<P.S.length;i+=4){{const d=Math.hypot(P.S[i].x-k[0],P.S[i].y-k[1]);if(d<bd){{bd=d;best=i}}}}
           const P0=R.G.paths[0];const e=rpSpawn('crab',0);e.s=best*P0.len/(P0.S.length-1);w2Frames(R,20);return [+h0.toFixed(2),Math.round(bd),+R.w2a.cr[0].h.toFixed(2)]}}""")
        chk(f'coral: crabs come out on their own and hide when a monster walks by ({r[1]} px from the road)',r[0]<0.05 and (r[2]>0.9 or r[1]>110),r)
        g=B['gs'][0]
        await E("()=>{w2New('coral');RPX.t=4;w2Frames(RPX,2)}")
        await click(g[0],g[1]-12)
        r=await E("()=>{const R=RPX;w2Frames(R,30);return [w2Last(),R.w2a.gs[0].f>0]}")
        chk('coral: a gull on the sand takes off when clicked (and lands again later)',r==['gull',True],r)
        r=await E("()=>{const R=RPX;w2Frames(R,330,1/30);return R.t-R.w2a.gs[0].f>9.5}")
        chk('coral: ... and it is back on the sand after its circle',r,r)
        if B['palm']:
            pc=B['palm'][0]
            r=await E(f"()=>{{const R=w2New('coral');R.t=7;w2Frames(R,2);const a=w2Shot(R);window._pa=a;return 1}}")
            await click(pc[0],pc[1])
            r=await E(f"()=>{{const R=RPX;w2Frames(R,4,1/30);const b=w2Shot(R);return [w2Last(),+w2Diff(_pa,b,{pc[0]}-{pc[3]}*.5|0,{pc[1]}-{pc[3]}*.4|0,{pc[3]},{pc[3]}*.8|0).toFixed(3),R.w2a.ev.some(e=>e.k==='leaf')]}}")
            chk('coral: a clicked palm shakes its crown and drops leaves',r[0]=='palm' and r[1]>0.05 and r[2],r)
        r=await E("""()=>{const R=w2New('coral');R.t=6;const p=R.bake.palms.find(p=>p.cy>80&&p.cx>60&&p.cx<1540);const S=[];for(const t of[6,6.8]){R.t=t;S.push(w2Shot(R))}return [R.bake.palms.length,+w2Diff(S[0],S[1],p.cx-p.h*.6|0,p.cy-p.h*.5|0,p.h*1.2|0,p.h|0).toFixed(3)]}""")
        chk(f'coral: {r[0]} palms have live crowns that sway',r[0]>=10 and r[1]>0.01,r)
        r=await E("""()=>{const R=w2New('coral');w2Full(R);R.tide={k:1,high:true};let n=0;for(const e of R.foes){if(e.dead||e.air)continue;const q=rpPos(R,e);if(R.map.tide.some(w=>Math.hypot(q.x-w[0],(q.y-w[1])*1.2)<w[2]*.95))n++}
          const T=R.map.tide[1],a=w2Cv(),b=w2Cv();R.t=6;rpw2aWade(a.getContext('2d'),R,R.map.tide,1);rpw2aWade(b.getContext('2d'),R,R.map.tide,0);return [n,+w2Lum(a,0,0,1600,900).toFixed(2),+w2Lum(b,0,0,1600,900).toFixed(2)]}""")
        chk(f'coral: monsters wading in the high tide splash ({r[0]} wading)',r[0]==0 or r[1]>r[2],r)
        # ---- Shipwreck Cove
        await E("()=>{const R=w2New('wreck');R.t=5;w2Frames(R,3);window._a=w2Shot(R)}")
        W=await E("()=>{const B=rpw2aWreckInit(RPX.bake,RPX.map);return{sk:B.skull?[B.skull.x,B.skull.y,B.skull.s]:null,box:B.shipBox,gp:B.gperch,can:RPX.map.cannon}}")
        await click(W['box'][0]+60,(W['box'][1]+W['box'][3])/2+40)
        r=await E("()=>{const R=RPX;w2Frames(R,5);return [w2Last(),+rpw2aShipJolt(R).toFixed(4)]}")
        chk('wreck: clicking the galleon makes it creak (the masts shudder, lanterns flare, rings on the water)',r[0]=='ship' and abs(r[1])>0.002,r)
        await click(W['can'][0],W['can'][1]-6)
        r=await E("()=>{const R=RPX;R.t+=.1;return [w2Last(),+rpw2aCanRec(R).toFixed(2),R.w2a.ev.some(e=>e.k==='smoke')]}")
        chk('wreck: clicking the cannon puffs smoke and kicks the barrel (no shot)',r[0]=='cannon' and r[1]>0.2 and r[2],r)
        if W['sk']:
            sx,sy,ss=W['sk']
            await click(sx,sy-ss*.5)
            r=await E(f"()=>{{const R=RPX;w2Frames(R,8);const b=w2Shot(R);return [w2Last(),+(w2Lum(b,{sx}-{ss}*.35|0,{sy}-{ss}*.7|0,{ss}*.7|0,{ss}*.3|0)-w2Lum(_a,{sx}-{ss}*.35|0,{sy}-{ss}*.7|0,{ss}*.7|0,{ss}*.3|0)).toFixed(1)]}}")
            chk("wreck: the skull rock's eyes glow when clicked",r[0]=='skull' and r[1]>4,r)
        r=await E("""()=>{const R=w2New('wreck');R.t=5;w2Frames(R,3);const n=R.bake.gperch.length;const f0=R.w2a.gs.map(g=>g.f);R.cannon={t:0,x:800,y:585,fire:.05,tx:600,ty:390};w2Frames(R,3);return [n,f0.every(f=>f<0),R.w2a.gs.every(g=>g.f>0)]}""")
        chk(f'wreck: the {r[0]} perched gulls fly off when the cannon fires',r[0]>=2 and r[1] and r[2],r)
        r=await E("""()=>{const R=w2New('wreck');R.fog=[{x:420,y:330,rx:150,ry:90}];R.t=3;return [rpw2aPoke(R,440,320),R.w2a.ev.some(e=>e.k==='swirl')]}""")
        chk('wreck: a click inside a fog bank swirls the fog',r==['fog',True],r)
        # ---- Kraken's Maw
        r=await E("""()=>{const R=w2New('abyss');R.t=5;w2Frames(R,2);R.mx=1400;R.my=150;w2Frames(R,40);const e1=R.w2a.eye.slice();R.mx=200;R.my=800;w2Frames(R,2);const e2=R.w2a.eye.slice();w2Frames(R,60);const e3=R.w2a.eye.slice();
          return [e1.map(Math.round),Math.hypot(e2[0]-200,e2[1]-800)>600,Math.hypot(e3[0]-200,e3[1]-800)<20]}""")
        chk('abyss: the Kraken\'s eye eases after the pointer (no snapping)',abs(r[0][0]-1400)<20 and r[1] and r[2],r)
        Ab=await E("()=>{const R=RPX,m=R.map,[lx,ly,rx,ry]=m.lake;return{eye:[lx,ly+ry*.18],tent:[lx+RPW2A_TENT[0][0]*rx+Math.cos(RPW2A_TENT[0][2])*30,ly+RPW2A_TENT[0][1]*ry+Math.sin(RPW2A_TENT[0][2])*26],cap:m.glow[0],vent:rpw2aAbyssInit(R.bake,m).vent,clam:R.bake.clams}}")
        await E("()=>{RPX.mx=-1;RPX.my=-1;RPX.w2a.mv[2]=-99}")
        await click(Ab['eye'][0],Ab['eye'][1])
        r=await E("()=>{const R=RPX;R.t+=.2;const E=rpw2aEyeAim(R,0,0,0,0);return [w2Last(),+E[2].toFixed(2),+rpw2aTentRk(R,3).toFixed(2)]}")
        chk('abyss: clicking the eye makes it blink and the tentacles flinch',r[0]=='eye' and r[1]<0.9 and r[2]>0.2,r)
        await E("()=>{RPX.t+=3}")
        await click(Ab['tent'][0],Ab['tent'][1])
        r=await E("()=>{const R=RPX;R.t+=.2;return [w2Last(),+rpw2aTentRk(R,0).toFixed(2)]}")
        chk('abyss: a clicked tentacle recoils',r[0]=='tentacle' and r[1]>0.5,r)
        v=Ab['vent'][-1] if Ab['vent'] else None
        if v:
            r=await E(f"()=>[rpw2aPoke(RPX,{v[0]},{v[1]}+10),RPX.w2a.ev.some(e=>e.k==='bub'&&e.n>=18)]")
            chk('abyss: a clicked vent bursts out bubbles',r==['vent',True],r)
        if Ab['clam']:
            c0=Ab['clam'][0]
            r=await E(f"()=>[rpw2aPoke(RPX,{c0[0]},{c0[1]}-8)]")
            chk('abyss: a clicked clam opens its pearl glow',r==['clam'],r)
        r=await E("""()=>{const R=w2New('abyss');R.t=4;const G=R.map.glow[0];let best=null;for(const p of R.pads){if(Math.hypot(p.x-G[0],p.y-G[1])<150){best=p;break}}if(!best)return ['no pad'];rpBuild(best,'ballista');best.tw.build=1;w2Frames(R,30);const g0=R.w2a.gl[0]||0;best.tw.fire=1;w2Frames(R,1);const g1=R.w2a.gl[0];best.tw.fire=0;w2Frames(R,60);return [+g0.toFixed(2),+g1.toFixed(2),+R.w2a.gl[0].toFixed(2)]}""")
        chk('abyss: a glowcap flares when a tower near it fires, then fades',r[0]<0.05 and r[1]>0.8 and r[2]<0.05,r)
        r=await E("""()=>{const R=w2New('abyss');R.t=4;w2Frames(R,30);const x0=(R.w2a.wh[0]||0);const W=R.map.whirl[0];let best=null,bd=1e9;const P=R.G.paths[0];for(let i=0;i<P.S.length;i+=2){const d=Math.hypot(P.S[i].x-W[0],P.S[i].y-W[1]);if(d<bd){bd=d;best=i}}
          for(let k=0;k<4;k++){const e=rpSpawn('shell',0);e.s=(best+k*3)*P.len/(P.S.length-1)}w2Frames(R,30);const x1=R.w2a.wh[0];return [+x0.toFixed(2),+x1.toFixed(2),+R.w2a.whn[0].toFixed(2)]}""")
        chk('abyss: a whirlpool spins faster with monsters in it',r[0]<0.05 and r[1]>0.3 and r[2]>2,r)
        # ---- frame cost with reactions running
        for m,pokes in [('coral',[(560,820),(104,250)]),('wreck',[(560,760),(800,580)]),('abyss',[(650,450),(300,500)])]:
            r=await E("""([m,P])=>{const R=w2New(m);w2Full(R);if(m==='coral')R.tide={k:.6,high:true};if(m==='wreck'){R.fog=[{x:420,y:330,rx:150,ry:90},{x:1060,y:420,rx:170,ry:100}];R.cannon={t:0,x:800,y:585,fire:.2,tx:640,ty:360}}
              for(const p of R.pads)if(p.tw)p.tw.fire=.5;const c=w2Cv().getContext('2d');R.mx=700;R.my=400;const one=()=>{R.t+=1/60;w2Layers(R,c)};for(const p of P)rpw2aPoke(R,p[0],p[1]);
              const meas=()=>{for(let i=0;i<6;i++)one();const L=[];for(let k=0;k<16;k++){const t0=performance.now();for(let i=0;i<8;i++)one();L.push((performance.now()-t0)/8)}L.sort((a,b)=>a-b);return +L[0].toFixed(3)};
              const full=meas();R.lite=1;const lite=meas();R.lite=0;R.rm=1;const rm=meas();R.rm=0;return [full,lite,rm]}""",[m,pokes])
            chk(f'{m}: all live layers with reactions running on a full battle cost {r[0]} ms a frame (lite {r[1]}, reduced motion {r[2]}) - under 1 ms',r[0]<1.0 and r[1]<=r[0]*1.3+.05 and r[2]<=r[0]*1.3+.05,r)
        # ---- the hub painting
        r=await E("""()=>{const W=RPW.world[2](),g=w2Cv().getContext('2d');const L=[];for(let k=0;k<7;k++){const t1=performance.now();for(let i=0;i<10;i++)W.anim(g,1+i*.05);L.push((performance.now()-t1)/10)}L.sort((a,b)=>a-b);
          const S=[];for(const t of[1,1.8]){const c=w2Cv(),h=c.getContext('2d');h.drawImage(W.c,0,0);W.anim(h,t);S.push(c)}return [+L[3].toFixed(3),+w2Diff(S[0],S[1],760,440,170,200).toFixed(3),+w2Diff(S[0],S[1],0,0,1600,900).toFixed(3)]}""")
        chk(f'the World 2 painting: tentacles wave, the beam sweeps, dolphins and the whale and clouds move; overlay {r[0]} ms',r[0]<1.5 and r[1]>0.01 and r[2]>0.004,r)
        chk('no page errors',not er,er)
        if SHOTS:
            os.makedirs(SHOTS,exist_ok=True)
            async def shot(name,clip=None):
                kw={'path':os.path.join(SHOTS,name+'.png')}
                if clip:kw['clip']={'x':clip[0],'y':clip[1],'width':clip[2],'height':clip[3]}
                await pg.screenshot(**kw)
            async def dump(js,name):
                d=await E(js);open(os.path.join(SHOTS,name+'.png'),'wb').write(base64.b64decode(d.split(',')[1]))
            for m in ['coral','wreck','abyss']:
                await E(f"()=>{{const R=w2New('{m}');R.t=2.2;rpDraw()}}");await pg.wait_for_timeout(250);await shot(m+'_start')
                await E(f"()=>{{const R=w2New('{m}');w2Full(R);R.t=4.1;for(const p of R.pads)if(p.tw)p.tw.fire=.6;w2Frames(R,2);rpDraw()}}");await pg.wait_for_timeout(250);await shot(m+'_battle')
            await E("()=>{const R=w2New('coral');w2Full(R);R.tide={k:1,high:true};R.t=6.3;rpDraw()}");await pg.wait_for_timeout(250);await shot('coral_tide_wading',(560,520,520,300))
            await E("()=>{const R=w2New('coral');R.t=6;const L=R.bake.light;rpw2aPoke(R,L.x,L.y+60);R.t=6.3;rpDraw()}");await pg.wait_for_timeout(200);await shot('coral_click_lighthouse',(0,60,420,340))
            await E("()=>{const R=RPX;const c=rpw2aCoralInit(R.bake).chests[0];R.t=9;rpw2aPoke(R,c.x,c.y-10);R.t=9.3;rpDraw()}");await pg.wait_for_timeout(200)
            cc=await E("()=>{const c=RPX.bake.chests[0];return [c.x,c.y]}");await shot('coral_click_chest',(cc[0]-110,cc[1]-110,220,150))
            await E("()=>{const R=RPX;R.t=12;const d=R.bake.dol[0];if(d)rpw2aPk(R,'dol0',d[0],d[1]);R.t=12.9;rpDraw()}");await pg.wait_for_timeout(200)
            dd=await E("()=>RPX.bake.dol[0]||[400,700]");await shot('coral_dolphin',(dd[0]-160,dd[1]-120,320,180))
            await E("()=>{const R=RPX;R.t=14;const g=R.bake.gstand[0];rpw2aPoke(R,g[0],g[1]-12);w2Frames(R,1);R.t=15;rpDraw()}");await pg.wait_for_timeout(200)
            gg=await E("()=>RPX.bake.gstand[0]");await shot('coral_gull_takeoff',(gg[0]-200,gg[1]-200,400,260))
            await E("()=>{const R=RPX;R.t=20;const k=R.bake.crab[1];rpw2aPoke(R,k[0],k[1]-6);w2Frames(R,8);R.t=20.4;rpDraw()}");await pg.wait_for_timeout(200)
            kk=await E("()=>RPX.bake.crab[1]");await shot('coral_crab_ducked',(kk[0]-120,kk[1]-80,240,120))
            await E("()=>{const R=w2New('wreck');R.t=6;rpw2aPoke(R,760,600);R.t=6.3;rpDraw()}");await pg.wait_for_timeout(200);await shot('wreck_click_ship',(560,380,460,320))
            await E("()=>{const R=RPX;R.t=8;const s=R.bake.skull;rpw2aPoke(R,s.x,s.y-30);R.t=8.4;rpDraw()}");await pg.wait_for_timeout(200);await shot('wreck_click_skull',(1130,0,240,130))
            await E("()=>{const R=RPX;R.t=10;R.cannon={t:0,x:800,y:585,fire:.06,tx:600,ty:390};w2Frames(R,2);R.t=10.5;rpDraw()}");await pg.wait_for_timeout(200);await shot('wreck_cannon_gulls_scared')
            await E("()=>{const R=w2New('abyss');R.t=5;R.mx=1000;R.my=200;w2Frames(R,60);rpDraw()}");await pg.wait_for_timeout(200);await shot('abyss_eye_follows_pointer',(350,240,600,380))
            await E("()=>{const R=RPX;R.t=8;rpw2aPoke(R,R.map.lake[0],R.map.lake[1]+R.map.lake[3]*.18);R.t=8.12;rpDraw()}");await pg.wait_for_timeout(200);await shot('abyss_click_eye_blink',(350,240,600,380))
            await E("()=>{const R=RPX;R.t=12;const c=R.bake.chestsA[0];rpw2aPoke(R,c.x,c.y-10);const v=R.bake.vent[0];rpw2aPoke(R,v[0],v[1]+10);R.t=12.6;rpDraw()}");await pg.wait_for_timeout(200)
            ca=await E("()=>{const c=RPX.bake.chestsA[0];return [c.x,c.y]}");await shot('abyss_click_chest',(max(0,ca[0]-150),max(0,ca[1]-110),300,200))
            await E("()=>{const R=w2New('abyss');w2Full(R);R.t=5;for(const p of R.pads)if(p.tw)p.tw.fire=1;w2Frames(R,1);rpDraw()}");await pg.wait_for_timeout(200);await shot('abyss_glowcaps_flare')
            for t in [1,3.4]:
                await dump(f"()=>{{const W=RPW.world[2]();const c=w2Cv(),g=c.getContext('2d');g.drawImage(W.c,0,0);W.anim(g,{t});return c.toDataURL()}}",f'world2_painting_t{t}')
            for m in ['coral','wreck','abyss']:
                await dump(f"()=>{{const R=w2New('{m}');R.t=2;const c=w2Cv(),g=c.getContext('2d');g.drawImage(R.bake.c,0,0);w2Layers(R,g);return c.toDataURL()}}",m+'_map_live_no_hud')
            print('screenshots in',SHOTS)
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed'+(' - FAILED: '+', '.join(FAIL) if FAIL else ''))
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
