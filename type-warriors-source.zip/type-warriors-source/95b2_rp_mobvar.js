/* ===== RUNESTONE RAMPARTS: map variants of the eight monsters =====
   moss  = the original look (95b), except the boss, which becomes the Mossback Behemoth.
   frost = icy palette plus snow caps, icicles, scarves, ice crystals and frozen breath.
   ember = charred / obsidian palette plus flames, horns, glowing cracks, magma drips and sparks
           (the ember boss keeps the original Basalt Behemoth colours and gains extra fire).
   How: the 95b drawing functions are run once per baked frame through a recolouring proxy of the 2D context
   (every fillStyle / strokeStyle / gradient stop goes through a palette map; no ctx.filter), then the variant's
   accessories are drawn on top (or behind) in the same units. The result is baked like 95b (8 frames, 2x, plus
   white flash and icy chill silhouettes), so the per-frame cost stays a few drawImage calls.
   API
   - RPMOBV[v][id] = {n}            variant display names (v = 'frost' | 'ember' | 'moss'; moss has only the boss)
   - rpMobName(id,v)                display name for a monster on a map variant
   - rpMobBlit(c,id,x,y,ph,o)       as 95b, plus o.v = 'moss' | 'frost' | 'ember' (default 'moss')
   - rpMobIcon(id,size,v)           portrait of the variant
   - rpMobDeath(c,id,x,y,k,o)       as 95b, plus o.v (debris colours match the variant)
   - rpMobPrebake(ids,v)            bake ahead of time (v optional, default moss)
   Private helpers are prefixed rpv. */
const RPMOBV={
 frost:{scamp:{n:'Frost Scamp'},bulwark:{n:'Rime Bulwark'},golem:{n:'Glacier Golem'},gloom:{n:'Frostwing'},ooze:{n:'Slush Ooze'},oozelet:{n:'Slush Oozelet'},shaman:{n:'Rime Shaman'},behemoth:{n:'Frozen Behemoth'}},
 ember:{scamp:{n:'Cinder Scamp'},bulwark:{n:'Ashen Bulwark'},golem:{n:'Magma Golem'},gloom:{n:'Emberwing'},ooze:{n:'Lava Ooze'},oozelet:{n:'Lava Oozelet'},shaman:{n:'Pyre Shaman'},behemoth:{n:'Basalt Behemoth'}},
 moss:{behemoth:{n:'Mossback Behemoth'}}};
function rpMobName(id,v){const V=RPMOBV[v]&&RPMOBV[v][id];return V?V.n:(RPMOB[id]?RPMOB[id].n:String(id))}
/* '' = use the original 95b sheet; otherwise the variant key */
function rpvV(id,v){v=v==='frost'||v==='ember'?v:'moss';return v==='moss'&&id!=='behemoth'?'':v}

/* ---------- colour mapping ---------- */
function rpvParse(s){if(s[0]==='#'){if(s.length===7){const n=parseInt(s.slice(1),16);return[n>>16,n>>8&255,n&255,1]}if(s.length===4){const r=parseInt(s[1],16),g=parseInt(s[2],16),b=parseInt(s[3],16);return[r*17,g*17,b*17,1]}return null}
 const m=/^rgba?\(([^)]+)\)/.exec(s);if(!m)return null;const p=m[1].split(',').map(parseFloat);return[p[0],p[1],p[2],p.length>3?p[3]:1]}
function rpvHSL(r,g,b){r/=255;g/=255;b/=255;const mx=Math.max(r,g,b),mn=Math.min(r,g,b),l=(mx+mn)/2,c=mx-mn;let h=0,s=0;
 if(c>0){s=l>.5?c/(2-mx-mn):c/(mx+mn);h=mx===r?(g-b)/c+(g<b?6:0):mx===g?(b-r)/c+2:(r-g)/c+4;h*=60}return[h,s,l,c]}
function rpvRGB(h,s,l){h=((h%360)+360)%360/360;s=Math.max(0,Math.min(1,s));l=Math.max(0,Math.min(1,l));
 if(!s){const v=Math.round(l*255);return v+','+v+','+v}const q=l<.5?l*(1+s):l+s-l*s,p=2*l-q,f=t=>{t=(t+1)%1;return t<1/6?p+(q-p)*6*t:t<.5?q:t<2/3?p+(q-p)*(2/3-t)*6:p};
 return Math.round(f(h+1/3)*255)+','+Math.round(f(h)*255)+','+Math.round(f(h-1/3)*255)}
/* generic palette maps on (hue, saturation, lightness, chroma); outlines and near-black stay as they are */
const RPVF={
 frost(h,s,l,c){if(l<.16)return[h,s,l];if(l>.93)return[200,.7,Math.max(l,.955)];
  if(c<.2)return[206,Math.min(.5,.22+s*.4),.26+l*.72];
  if(h>=65&&h<170)return[180+(h-65)*.14,Math.min(.75,s*.78),.3+l*.66];
  if(h>=170&&h<255)return[h*.4+115,Math.min(1,s),.08+l*.95];
  if(h>=255&&h<335)return[226+(h-255)*.14,s*.62,.1+l*.86];
  if(l<.55&&c<.5)return[214,.22+s*.15,.18+l*.8];
  if(l>.55)return[190,Math.min(1,s*.9),Math.max(.62,l)];
  return[208,Math.min(.85,s*.85),.2+l*.72]},
 ember(h,s,l,c){if(l<.16)return[h,s,l];if(l>.93)return[42,1,.9];
  if(c<.2)return[12,.16+s*.08,.1+l*.5];
  if(h>=65&&h<170)return[12,.22,.08+l*.46];
  if(h>=170&&h<255)return c>.4&&l>.45?[24,1,Math.max(.56,l*.95)]:[350,.28,.06+l*.45];
  if(h>=255&&h<335)return[350+(h-255)*.1,Math.min(.8,s*.75),.06+l*.62];
  if(l<.55&&c<.5)return[15,s*.6,.05+l*.62];
  return[h>=335?h:Math.max(8,h*.85),Math.min(1,s*1.08),l]},
 moss(h,s,l,c){if(l>.12&&c<.3&&h>=225&&h<300)return[138,s*.75,l];return[h,s,l]}};
/* exact overrides (any alpha) per variant and monster, from the 95b palette */
const RPVO={
 frost:{
  scamp:{'#ff8a5e':'#f2fbff','#e2442e':'#9ad4f4','#b02a2a':'#4a8ad4','#7a1626':'#28508e','#fff3da':'#ffffff','#72c040':'#ffffff','#c4f27a':'#ffffff','#f6e2b8':'#d4ecfa','#e98a7a':'#c4b4f0','#8a5a2c':'#3a6aa8'},
  bulwark:{'#efe3c2':'#eaf6ff','#b8a27a':'#86b0cc','#fffaea':'#ffffff'},
  golem:{'#a6e066':'#ffffff','#4f8a34':'#b4d8f2','#5c9a3a':'#d8f2ff'},
  gloom:{'#2e1460':'#183a74','#6a3cc4':'#3c86d4','#9c6cf0':'#8cc8f0','#c9a2ff':'#eef9ff','#241048':'#142a58','#3d1f78':'#20508e','#6c44b8':'#5a9ad4','#ff4fb8':'#3ad0ff','#8a2a6a':'#2a6aa0','#d24aa0':'#4ab8f0'},
  ooze:{'#c8ffd6':'#f4fcff','#52e0aa':'#a8daf4','#1fae8e':'#5aa4dc','#0f6e64':'#2a5a9c','#9a6a4a':'#f2fbff','#4a2a20':'#7cbce8','#c89a6a':'#e2f6ff','#e8304a':'#4a8ae8','#2fc49a':'#9ad0f0'},
  oozelet:{'#d4ffe0':'#f4fcff','#62e8b0':'#b0def6','#22b490':'#62aade','#127468':'#2e60a0','#9a6a4a':'#f2fbff','#4a2a20':'#7cbce8','#7cc843':'#bfe8ff','#9ad84e':'#e8f8ff','#6ab83e':'#a4d8f4'},
  shaman:{},
  behemoth:{'#ff6a1a':'#46d4ff','#ffd24a':'#eafcff','#8a1806':'#1a4a8a','#ff8a3a':'#7ae4ff'}},
 ember:{
  scamp:{'#ff8a5e':'#6a4444','#e2442e':'#4a2a2e','#b02a2a':'#2e1a22','#7a1626':'#1e1018','#fff3da':'#ffb43a','#72c040':'#ff6a1a','#c4f27a':'#ffd24a','#f6e2b8':'#8a4a2a','#e98a7a':'#ff7a3a'},
  bulwark:{'#b8a27a':'#5c524e','#7ffff0':'#ffd24a','#1aa79a':'#e8501a','#3ff2d2':'#ff8a2a','#0e3a3a':'#3a0e08','#eafffb':'#fff0c0','#3f6a74':'#4a2622','#2a4652':'#3a1c1c','#22394a':'#2e1618','#162636':'#1e0e10','rgba(160,220,230,.35)':'rgba(255,170,90,.35)'},
  golem:{'#a6e066':'#3a2c30','#4f8a34':'#1e161c','#5c9a3a':'#ff6a1a'},
  gloom:{'#2e1460':'#1a0a0e','#6a3cc4':'#3a1418','#9c6cf0':'#9a2a14','#c9a2ff':'#ff8a2a','#241048':'#140a0c','#3d1f78':'#2a1014','#6c44b8':'#7a2a14','#ff4fb8':'#ff5a1a','#8a2a6a':'#8a2a1a','#d24aa0':'#ff8a2a',
   '#fff1fb':'#ffe08a','#cfa8e8':'#e0501a','#c9a8f0':'#ff9a3a','#fff0ff':'#ffe9a0','#7a54b0':'#5a1a14','#c4a2e8':'#ff7a2a','#e88ad0':'#ff7a2a'},
  ooze:{'#c8ffd6':'#fff0a8','#52e0aa':'#ffa030','#1fae8e':'#e8461a','#0f6e64':'#8a1408','#9a6a4a':'#4a3a44','#4a2a20':'#1e1420','#c89a6a':'#3a2a34','#e8304a':'#ffd24a','#e8f0d8':'#8a7a74','#d0dcc0':'#6a5c58','#1a3a34':'#1a0a0a','#2fc49a':'#e8501a','#e8fff4':'#fff0b0'},
  oozelet:{'#d4ffe0':'#fff4b0','#62e8b0':'#ffaa36','#22b490':'#ec501e','#127468':'#8a1a0a','#9a6a4a':'#4a3a44','#4a2a20':'#1e1420','#e8fff4':'#fff0b0','#7cc843':'#3a2a2a','#9ad84e':'#4a3434','#6ab83e':'#3a2a2a'},
  shaman:{'#7fae7a':'#c45a3a'},
  behemoth:{}},
 moss:{behemoth:{'#ff6a1a':'#6ee04a','#ffd24a':'#e4ff9a','#8a1806':'#1e5a18','#ff8a3a':'#9af06a','#a49cbc':'#a4bca8'}}};
const RPVM={};
function rpvMap(v,id){if(v==='ember'&&id==='behemoth')return null;const key=v+'|'+id;if(RPVM[key])return RPVM[key];
 const F=RPVF[v],O={},src=(RPVO[v]||{})[id]||{};for(const k in src){const c=rpvParse(k);O[c[0]+','+c[1]+','+c[2]]=rpvParse(src[k])}
 const cache=new Map();
 return RPVM[key]=s=>{let r=cache.get(s);if(r!==undefined)return r;r=s;const c=rpvParse(String(s).replace(/\s+/g,'').toLowerCase());
  if(c){const o=O[c[0]+','+c[1]+','+c[2]];let rgb;if(o)rgb=o[0]+','+o[1]+','+o[2];else{const h=rpvHSL(c[0],c[1],c[2]),n=F(h[0],h[1],h[2],h[3]);rgb=rpvRGB(n[0],n[1],n[2])}
   r=c[3]<1?'rgba('+rgb+','+c[3]+')':'rgb('+rgb+')'}cache.set(s,r);return r}}
/* a 2D context proxy that recolours every style it is given (bake time only) */
function rpvPX(g,map){const B=new Map();return new Proxy(g,{
 get(t,p){if(p==='createLinearGradient'||p==='createRadialGradient')return function(){const q=t[p].apply(t,arguments),ad=q.addColorStop.bind(q);q.addColorStop=(o,c)=>ad(o,map(c));return q};
  const v=t[p];if(typeof v==='function'){let f=B.get(p);if(!f){f=v.bind(t);B.set(p,f)}return f}return v},
 set(t,p,v){if((p==='fillStyle'||p==='strokeStyle')&&typeof v==='string')v=map(v);t[p]=v;return true}})}

/* ---------- accessory helpers (drawn in the monster's own units) ---------- */
function rpvBox(p){let y0=1e9,y1=-1e9;for(let i=1;i<p.length;i+=2){if(p[i]<y0)y0=p[i];if(p[i]>y1)y1=p[i]}return[y0,y1]}
function rpvSnow(g,p,lw){const Y=rpvBox(p);rpmBl(g,p);rpmFS(g,rpmLG(g,0,Y[0],0,Y[1],[0,'#ffffff',.5,'#eef8ff',1,'#a6d0f0']),lw||1.8);
 g.save();g.clip();rpmBl(g,p.map((v,i)=>i%2?v+(Y[1]-Y[0])*.42:v));g.fillStyle='rgba(120,180,230,.28)';g.fill();g.restore()}
function rpvIce(g,x,y,l,w){w=w||Math.max(1.1,l*.3);g.beginPath();g.moveTo(x-w,y);g.quadraticCurveTo(x-w*.35,y+l*.55,x,y+l);g.quadraticCurveTo(x+w*.4,y+l*.5,x+w,y);g.closePath();
 rpmFS(g,rpmLG(g,x-w,0,x+w,0,[0,'#f6fdff',.45,'#bfe8fa',1,'#6ab2e4']),1.3);g.beginPath();g.moveTo(x-w*.4,y+l*.12);g.lineTo(x-w*.12,y+l*.62);rpmHi(g,.75,.8)}
function rpvXtal(g,x,y,l,w,ang){g.save();g.translate(x,y);g.rotate(ang||0);rpmP(g,[-w,0,-w,-l*.72,0,-l,w,-l*.72,w,0]);
 rpmFS(g,rpmLG(g,-w,0,w,0,[0,'#f6fdff',.42,'#b0e6fb',.5,'#72c4ee',1,'#3a88d0']),1.6);rpmP(g,[-w,-l*.72,0,-l,0,-l*.62]);g.fillStyle='rgba(255,255,255,.8)';g.fill();
 g.beginPath();g.moveTo(-w*.5,-1.5);g.lineTo(-w*.5,-l*.64);rpmHi(g,.65,.9);g.restore()}
function rpvFire(g,x,y,h,w,ph,lean,seed){seed=seed||0;const t=ph*RPMT,f=Math.sin(t*2+seed)*.14+Math.sin(t*3+seed*2)*.06,fh=h*(1+f),sw=(Math.sin(t+seed)*.22+(lean||0))*h;
 rpmGlow(g,x+sw*.3,y-fh*.38,h*.95,'#ff7a1a',.42);
 const F=(k,c,lw)=>{const yb=y-(1-k)*h*.12,hh=fh*k,ww=w*k,tx=x+sw*k;g.beginPath();g.moveTo(x-ww,yb);
  g.bezierCurveTo(x-ww*1.15,yb-hh*.5,tx-ww*.55,yb-hh*.62,tx,yb-hh);g.bezierCurveTo(tx+ww*.15,yb-hh*.58,x+ww*1.2,yb-hh*.42,x+ww,yb);g.quadraticCurveTo(x,yb+ww*.55,x-ww,yb);g.closePath();rpmFS(g,c,lw)};
 F(1,rpmLG(g,0,y-fh,0,y,[0,'#ffd24a',.45,'#ff7a1a',1,'#d8261a']),1.5);F(.58,rpmLG(g,0,y-fh*.6,0,y,[0,'#fffbe0',1,'#ffc23a']),0)}
function rpvHorn(g,x,y,l,w,ang,dir,cols){g.save();g.translate(x,y);g.rotate(ang||0);g.beginPath();g.moveTo(-w,0);g.quadraticCurveTo(-w*.9,-l*.62,dir*l*.38,-l);g.quadraticCurveTo(w*.35,-l*.5,w,0);g.closePath();
 rpmFS(g,rpmLG(g,-w,0,w,0,cols||[0,'#f2e4cc',.5,'#c4a884',1,'#76604c']),1.6);g.beginPath();g.moveTo(-w*.45,-l*.15);g.quadraticCurveTo(-w*.5,-l*.55,dir*l*.25,-l*.85);rpmHi(g,.45,.8);g.restore()}
function rpvPuff(g,x,y,ph,sc){sc=sc||1;for(let i=0;i<3;i++){const u=(ph+i/3)%1,px=x+u*11*sc,py=y-u*3.4*sc+Math.sin(u*6+i)*.8*sc,r=(1.3+u*2.8)*sc;
 g.globalAlpha=(1-u)*.9;g.beginPath();g.arc(px,py,r,0,RPMT);g.fillStyle='#f4fbff';g.fill();g.lineWidth=.9;g.strokeStyle='#7ab8e4';g.stroke()}g.globalAlpha=1}
function rpvSparks(g,x0,x1,y0,h,ph,n,seed,cols){cols=cols||['#ffd24a','#ff6a1a'];g.save();g.globalCompositeOperation='lighter';
 for(let i=0;i<n;i++){const u=(ph+i/n)%1,x=x0+(x1-x0)*rpmRn(seed+i*1.7)+Math.sin(u*7+i)*2.4,y=y0-u*h;g.globalAlpha=Math.sin(u*Math.PI)*.95;g.fillStyle=cols[i%cols.length];g.beginPath();g.arc(x,y,1.1+(i%3)*.45,0,RPMT);g.fill()}g.restore()}
function rpvTwk(g,x,y,r,a){g.save();g.globalAlpha=a==null?1:a;g.fillStyle='#ffffff';g.beginPath();g.moveTo(x,y-r*2.2);g.lineTo(x+r*.5,y);g.lineTo(x,y+r*2.2);g.lineTo(x-r*.5,y);g.closePath();
 g.moveTo(x-r*2.2,y);g.lineTo(x,y+r*.5);g.lineTo(x+r*2.2,y);g.lineTo(x,y-r*.5);g.closePath();g.fill();g.restore()}
function rpvFlake(g,x,y,r){g.beginPath();for(let i=0;i<3;i++){const t=i*Math.PI/3+.26;g.moveTo(x-Math.cos(t)*r,y-Math.sin(t)*r);g.lineTo(x+Math.cos(t)*r,y+Math.sin(t)*r)}
 for(let i=0;i<6;i++){const t=i*Math.PI/3+.26,cx=x+Math.cos(t)*r*.62,cy=y+Math.sin(t)*r*.62;g.moveTo(cx+Math.cos(t+2.4)*r*.32,cy+Math.sin(t+2.4)*r*.32);g.lineTo(cx,cy);g.lineTo(cx+Math.cos(t-2.4)*r*.32,cy+Math.sin(t-2.4)*r*.32)}
 g.lineCap='round';g.lineWidth=2.8;g.strokeStyle=RPMO;g.stroke();g.lineWidth=1.3;g.strokeStyle='#f4fdff';g.stroke()}
function rpvCrack(g,p,w){rpmGlow(g,p[2],p[3],w*3.4,'#ff6a1a',.5);rpmFiss(g,p,w,'#ff6a1a','#ffd24a')}
function rpvDrip(g,x,y,ph,l,seed){const u=(ph+(seed||0))%1,L=1.5+u*l;g.globalAlpha=u>.85?(1-u)/.15:1;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+.5,y+L*.6,x,y+L);
 g.lineWidth=4.4;g.strokeStyle='#1a0610';g.stroke();g.lineWidth=2.4;g.strokeStyle='#ff6a1a';g.stroke();rpmEl(g,x,y+L+.6,1.7,2.2,'#ffd24a',0);g.globalAlpha=1}
function rpvMoss(g,p,tufts){const Y=rpvBox(p);rpmBl(g,p);rpmFS(g,rpmLG(g,0,Y[0],0,Y[1],[0,'#b6ec6c',.5,'#6ab43e',1,'#3c7428']),1.8);
 for(const [x,y,r] of tufts||[]){g.beginPath();for(let j=0;j<10;j++){const t2=j/10*RPMT+x,rr=j%2?r*.55:r;j?g.lineTo(x+Math.cos(t2)*rr,y+Math.sin(t2)*rr*.8):g.moveTo(x+Math.cos(t2)*rr,y+Math.sin(t2)*rr*.8)}g.closePath();rpmFS(g,'#7cc843',1.1);rpmEl(g,x-r*.25,y-r*.25,r*.38,r*.28,'#d4f88a',0)}}
function rpvShroom(g,x,y,r){rpmP(g,[x-r*.32,y,x-r*.26,y-r*1.1,x+r*.26,y-r*1.1,x+r*.32,y]);rpmFS(g,'#f6e2b8',1.2);
 g.beginPath();g.moveTo(x-r,y-r*.95);g.bezierCurveTo(x-r,y-r*2.2,x+r,y-r*2.2,x+r,y-r*.95);g.quadraticCurveTo(x,y-r*.6,x-r,y-r*.95);g.closePath();rpmFS(g,rpmRG(g,x,y-r,r*1.4,[0,'#ff8a5e',.6,'#e2442e',1,'#9a1e26'],x-r*.4,y-r*1.6),1.4);
 rpmEl(g,x-r*.4,y-r*1.45,r*.2,r*.16,'#fff3da',0);rpmEl(g,x+r*.3,y-r*1.6,r*.16,r*.13,'#fff3da',0)}
function rpvFlower(g,x,y,r,c){for(let i=0;i<5;i++){const t=i/5*RPMT;rpmEl(g,x+Math.cos(t)*r,y+Math.sin(t)*r,r*.75,r*.75,c||'#ff9ad0',1)}rpmEl(g,x,y,r*.6,r*.6,'#ffd84a',.8)}
function rpvCrust(g,p){rpmRock(g,p,'#3a2a30',1.6,.55,.3);const n=p.length>>1;let cx=0,cy=0;for(let i=0;i<n;i++){cx+=p[i*2];cy+=p[i*2+1]}cx/=n;cy/=n;
 g.beginPath();g.moveTo((p[0]+cx)/2,(p[1]+cy)/2);g.lineTo(cx,cy);g.lineTo((p[4]+cx)/2,(p[5]+cy)/2);g.lineWidth=1;g.strokeStyle='#ff8a2a';g.stroke()}

/* ---------- accessories per variant: b = behind the body, f = in front ---------- */
const RPVA={frost:{},ember:{},moss:{}};
/* 1. scamp */
{const an=ph=>{const a=ph*RPMT,s=Math.sin(a),by=-Math.abs(s)*3;return{a,s,by,hx:8,hy:-27.6+by}};
 const cap=(g,A)=>{g.translate(A.hx-1.4,A.hy-8.6);g.rotate(-.2+A.s*.04);g.scale(.88,.88)};
 RPVA.frost.scamp={f(g,ph){const A=an(ph),by=A.by,w1=Math.sin(A.a*2)*1.6;
  /* knitted scarf with a fluttering tail */
  g.beginPath();g.moveTo(0,-19+by);g.quadraticCurveTo(-6,-20+by+w1,-13,-17+by+w1*1.4);g.lineTo(-12,-13.2+by+w1*1.4);g.quadraticCurveTo(-6,-15.4+by+w1,-.6,-15.6+by);g.closePath();rpmFS(g,rpmLG(g,0,0,-13,0,[0,'#2a9ad4',1,'#1a64a8']),1.6);
  g.beginPath();g.moveTo(-5,-19.4+by+w1*.9);g.lineTo(-4.6,-15.6+by+w1*.9);g.moveTo(-9,-18.6+by+w1*1.2);g.lineTo(-8.6,-14.6+by+w1*1.2);g.lineWidth=1.3;g.strokeStyle='#eaf8ff';g.stroke();
  rpmBl(g,[-2,-20.4+by,3,-18.6+by,8.4,-19.8+by,9,-15.4+by,3,-13.8+by,-2.6,-15.8+by]);rpmFS(g,rpmLG(g,0,-20+by,0,-14+by,[0,'#4ab8ec',1,'#1f78bc']),1.8);
  g.beginPath();g.moveTo(1.6,-19.2+by);g.lineTo(1.4,-14.4+by);g.moveTo(5.6,-19+by);g.lineTo(5.4,-14.2+by);g.lineWidth=1.3;g.strokeStyle='#eaf8ff';g.stroke();
  /* snow on the cap and icicles under the rim */
  g.save();cap(g,A);
  rpvSnow(g,[-13.6,-3,-12.6,-9.6,-6,-14.6,1,-17.4,8.4,-15.6,13.8,-10.4,15.4,-3.2,11,-6.6,7.4,-4.2,3.4,-7.6,-2,-5.6,-6.4,-7.6,-10.4,-4.2]);
  rpvTwk(g,-5,-12,.9,.9);
  rpvIce(g,-12,2.2,5.4);rpvIce(g,-7,3.2,4.2);rpvIce(g,15,1.8,3.8);
  g.restore();
  /* frozen breath */
  rpvPuff(g,A.hx+14,A.hy+3.4,ph,1)}};
 RPVA.ember.scamp={f(g,ph){const A=an(ph),by=A.by;
  /* glowing crack in the charred torso */
  g.save();g.translate(3,-19+by);g.rotate(.32);rpvCrack(g,[-2.6,-6,.4,-2,-1.6,2,1,5.6],2.4);g.restore();
  g.save();cap(g,A);
  /* the cap's spots smoulder, a flame burns on top */
  for(const [x,y,r] of[[-8,-6,2.6],[0,-10.4,2],[7.4,-6.4,2.9],[13,-1.6,1.6],[-12.4,-1.2,1.5],[1.6,-3,1.4]])rpmGlow(g,x,y,r*2.6,'#ff7a1a',.55);
  rpvFire(g,2.4,-12.4,15,4.6,ph,-.1,1);
  g.restore();
  rpvSparks(g,-8,6,-38+by,16,ph,4,3)}};
}
/* 2. bulwark */
{const an=ph=>{const a=ph*RPMT,s=Math.sin(a),by=-Math.abs(Math.cos(a))*1.8,sb=by*.8+Math.sin(a*2+.6)*.5;return{a,s,by,sb,kx:1.6,ky:-52.6+by}};
 RPVA.frost.bulwark={f(g,ph){const A=an(ph),by=A.by,kx=A.kx,ky=A.ky;
  /* white fur mantle over the shoulders */
  rpmBl(g,[-12.6,-41.6+by,-7,-46.2+by,-.6,-45.6+by,4,-42.4+by,.6,-38.6+by,-6.4,-38+by]);rpmFS(g,rpmLG(g,0,-46+by,0,-38+by,[0,'#ffffff',.6,'#e2f2ff',1,'#9cc8ec']),1.8);
  g.beginPath();for(const x of[-9,-5,-1.4]){g.moveTo(x,-41.4+by);g.lineTo(x+1,-39.4+by)}g.lineWidth=.9;g.strokeStyle='rgba(60,110,170,.6)';g.stroke();
  /* snow on the helmet and icicles on the brim */
  rpvSnow(g,[kx-8.2,ky-4.6,kx-6.4,ky-9.6,kx,ky-12.8,kx+6.4,ky-11.2,kx+9.8,ky-5.6,kx+5.4,ky-6.8,kx+1.2,ky-5.8,kx-3.2,ky-7]);
  rpvIce(g,kx-9.4,ky-1.8,4.6);rpvIce(g,kx-5.6,ky-1,3.4);rpvIce(g,kx+12.4,ky-2,3.8);
  /* the shield: snow on the rim, ice crystals at the corner */
  g.save();g.translate(2,A.sb+2.4);
  rpvXtal(g,26.4,-45,10,2.6,.55);rpvXtal(g,23.6,-48.4,7,2,.18);
  rpvSnow(g,[4.6,-42.6,6.6,-49.2,17,-54,26.6,-49.6,29.4,-43,26,-45.2,21.4,-46.2,17,-45,12.6,-46.6,8.4,-44.8]);
  rpvIce(g,9,-45.4,4.4);rpvIce(g,22,-45.8,5.2);
  g.restore();
  rpvPuff(g,kx+11.4,ky+4.4,ph,1)}};
 RPVA.ember.bulwark={f(g,ph){const A=an(ph),kx=A.kx,ky=A.ky;
  /* horned helm with a flame crest */
  rpvHorn(g,kx-5.6,ky-7.6,11,2.6,-.95,-1);rpvHorn(g,kx+6.4,ky-8.6,10,2.4,.55,1);
  rpvFire(g,kx+.2,ky-10.2,12,3.6,ph,-.18,2);
  /* cracks across the shield */
  g.save();g.translate(2,A.sb+2.4);rpvCrack(g,[8.6,-44,11.4,-38,9.4,-33],2);rpvCrack(g,[25.4,-12,23,-8,24.4,-4.6],1.8);g.restore();
  rpvSparks(g,-4,24,-50+A.by,22,ph,5,7)}};
}
/* 3. golem */
{const an=ph=>{const a=ph*RPMT,s=Math.sin(a);return{a,s,by:-Math.abs(s)*2.4,tl:s*.028,hb:Math.sin(a*2)*.6,sw:7*s}};
 const UP=(g,A)=>{g.translate(0,-30);g.rotate(A.tl);g.translate(0,30+A.by)};
 const T=(p,dx,dy)=>p.map((v,i)=>v+(i%2?dy:dx));
 RPVA.frost.golem={
  b(g,ph){const A=an(ph);UP(g,A);rpvXtal(g,-24,-74,26,5,-1.0);rpvXtal(g,-14,-82,30,6,-.48);rpvXtal(g,-30,-62,16,3.6,-1.35);rpvXtal(g,-4,-86,18,4,-.14)},
  f(g,ph){const A=an(ph),hb=A.hb;UP(g,A);
   rpvSnow(g,[-14.6,-81.4,-10.6,-90.4,0,-96,10.6,-94.4,19.6,-87.6,14,-86.8,6,-89.4,-2,-88.4,-8.6,-84]);
   rpvSnow(g,T([21.6,-91,26,-97.6,34,-102.2,44.6,-100.8,52.6,-94.6,47.4,-93,40.4,-94.4,33.4,-93,27,-91.4],0,hb));
   for(const [x,y,l] of[[31.6,-62.8,5],[36.4,-61.4,7.4],[42,-62.2,6],[46.6,-63.8,4.2]])rpvIce(g,x,y+hb,l);
   rpvIce(g,30,-44,6);rpvIce(g,35.2,-50.4,4.6);
   rpvTwk(g,-26,-56,1.1,.9);rpvTwk(g,8,-80,.9,.8);
   rpvPuff(g,53,-68.4+hb,ph,1.3)}};
 RPVA.ember.golem={
  b(g,ph){const A=an(ph);UP(g,A);rpvFire(g,-26,-74,17,5,ph,-.3,0);rpvFire(g,-15,-84,22,6,ph,-.2,2.2);rpvFire(g,-3,-88,15,4.6,ph,-.1,4.1)},
  f(g,ph){const A=an(ph),hb=A.hb,sw=A.sw;UP(g,A);
   rpvCrack(g,[-29,-66,-24.4,-58,-27,-50,-22,-43],4.2);
   rpvCrack(g,[-6,-86,-1,-78,-5,-70,1,-64],3.4);
   rpvCrack(g,T([30,-97,35,-92.6,33,-88.6],0,hb),2.4);
   rpvCrack(g,[1+sw,-31,5+sw,-25.6,2+sw,-20.6],2.6);
   rpvFire(g,-8.4,-97,9,2.8,ph,-.1,1);rpvFire(g,7,-101,10,3,ph,.05,3);
   rpvSparks(g,-34,10,-92,26,ph,6,11)}};
}
/* 4. gloomwing */
{const an=ph=>{const a=ph*RPMT,e=Math.cos(a),by=-Math.sin(a)*2.6,cy=-20+by;return{a,e,by,cy,hx:10,hy:cy-3}};
 const wing=(g,A)=>{g.translate(-1,A.cy-4);g.rotate(A.e*.8);g.scale(1,.78+.22*Math.abs(A.e))};
 RPVA.frost.gloom={
  b(g,ph){const A=an(ph);rpvXtal(g,A.hx-3,A.hy-3,13,2.4,-.85);rpvXtal(g,A.hx+.4,A.hy-4.4,10,2,-.32)},
  f(g,ph){const A=an(ph);
   g.save();wing(g,A);rpvFlake(g,-21,-10,5.6);rpvIce(g,-26,13.4,5.2,1.6);rpvIce(g,-20.4,10.2,3.8,1.3);rpvTwk(g,-31,-18.6,.9,.95);g.restore();
   rpvPuff(g,A.hx+9,A.hy+3.4,ph,.9)}};
 RPVA.ember.gloom={
  b(g,ph){const A=an(ph);g.save();g.translate(-13,A.cy+2.4);g.rotate(-Math.PI/2-.35);rpvFire(g,0,0,15,4,ph,0,1);g.restore()},
  f(g,ph){const A=an(ph);
   rpvHorn(g,A.hx-3.2,A.hy-5,7.4,1.8,-.75,-1,[0,'#f2e4cc',.5,'#b49474',1,'#5e4a3c']);
   g.save();wing(g,A);rpmGlow(g,-30,-14,10,'#ff7a1a',.45);g.restore();
   rpvSparks(g,-30,-6,A.cy+6,18,ph,5,5)}};
}
/* 5/6. oozes: the same squash and hop as 95b */
{const an=(ph,big)=>{const a=ph*RPMT,q=Math.sin(a),S=big?1:.52,hop=big?0:-Math.max(0,Math.sin(a))*7,sq=big?q:(Math.cos(a)>.6?-(Math.cos(a)-.6)*1.6:Math.sin(a)*.5);
  const sx=1+.07*sq,sy=1-.08*sq,lean=Math.cos(a)*(big?2.6:1.6),tx=(x,y)=>[(x*sx+lean*(-y/50))*S,y*sy*S+hop];return{a,S,hop,tx,P:p=>{const o=[];for(let i=0;i<p.length;i+=2)o.push(...tx(p[i],p[i+1]));return o}}};
 RPVA.frost.ooze={f(g,ph){const A=an(ph,1),tx=A.tx;
  rpvSnow(g,A.P([-26,-38,-20,-48.4,-9,-55,4,-57,15,-52.4,24,-44.4,27.4,-37,20.4,-41,13,-40.4,6,-43,-2,-41.8,-10,-43.4,-18,-40]),2);
  for(const [x,y,l] of[[-16,-40.4,5.6],[-6,-41.8,4],[14,-40.4,4.4],[23,-39.6,3.6]]){const p=tx(x,y);rpvIce(g,p[0],p[1],l)}
  for(const [x,y,r,k] of[[-27,-24,1,0],[27,-13,.9,.3],[-4,-12,.8,.6]]){const p=tx(x,y);rpvTwk(g,p[0],p[1],r,.55+.45*Math.sin(ph*RPMT*2+k*6))}}};
 RPVA.frost.oozelet={f(g,ph){const A=an(ph,0),tx=A.tx;
  rpvSnow(g,A.P([-22,-44,-16,-52.4,-6,-57.4,6,-58.4,16,-54.6,22,-47.4,24.4,-42,16,-45,8,-44.4,0,-46,-8,-45,-16,-43.6]),1.6);
  const p=tx(4,-56),q=tx(-5,-55);rpvXtal(g,p[0],p[1],8.4,2,.3);rpvXtal(g,q[0],q[1],6,1.6,-.45);
  const r=tx(-12,-44);rpvIce(g,r[0],r[1],3.2)}};
 RPVA.ember.ooze={f(g,ph){const A=an(ph,1),tx=A.tx;
  rpvCrust(g,A.P([-23,-37,-13,-44,-3,-43,-5,-36,-15,-33]));
  rpvCrust(g,A.P([-31,-18,-26,-23,-21,-19,-25,-12]));
  rpvCrust(g,A.P([10,-46.4,18,-47,22,-41.4,15,-39.4]));
  for(const [x,y,h,s] of[[-7,-47,12,1],[7,-49,16,2.6],[20,-43,10,4.2]]){const p=tx(x,y);rpvFire(g,p[0],p[1],h,3.6,ph,.05,s)}
  const p=tx(-28,-6);rpvDrip(g,p[0],p[1],ph,6,.3);
  rpvSparks(g,-24,22,-50,24,ph,5,13)}};
 RPVA.ember.oozelet={f(g,ph){const A=an(ph,0),tx=A.tx;
  rpvCrust(g,A.P([-22,-34,-12,-41,-4,-38,-8,-30,-18,-28]));
  const p=tx(2,-49);rpvFire(g,p[0],p[1]+1.5,13,3.6,ph,.06,1);
  rpvSparks(g,-8,10,-32+A.hop,14,ph,3,17)}};
}
/* 7. shaman */
{const an=ph=>{const a=ph*RPMT,s=Math.sin(a),by=-Math.abs(Math.cos(a))*1.6;return{a,s,by,hx:10,hy:-44+by,sx:21+s*1.2,top:-58+by}};
 const staff=(g,A)=>{g.translate(A.sx,0);g.rotate(.05+A.s*.03)};
 const qp=(x0,y0,cx,cy,x1,y1,u)=>{const v=1-u;return[v*v*x0+2*v*u*cx+u*u*x1,v*v*y0+2*v*u*cy+u*u*y1]};
 RPVA.frost.shaman={f(g,ph){const A=an(ph),by=A.by,hx=A.hx,hy=A.hy;
  rpvIce(g,-13.4,-57.6+by,6,1.6);rpvIce(g,-9.4,-59.2+by,4.4,1.3);
  /* fur trim around the hood opening */
  const pts=[];for(let i=0;i<=4;i++)pts.push(qp(hx-5,hy+7,hx-6,hy-6,hx+3,hy-7.4,.1+i*.9/4));for(let i=1;i<=2;i++)pts.push(qp(hx+3,hy-7.4,hx+9,hy-6,hx+9.4,hy+4,i*.2));
  g.beginPath();for(const p of pts){g.moveTo(p[0]+3,p[1]);g.arc(p[0],p[1],3,0,RPMT)}g.lineWidth=3.4;g.strokeStyle=RPMO;g.stroke();g.fillStyle=rpmLG(g,0,hy-10,0,hy+8,[0,'#ffffff',1,'#cfe6f6']);g.fill();
  g.fillStyle='rgba(110,170,225,.45)';g.beginPath();for(const p of pts){g.moveTo(p[0]+1.6,p[1]+1.3);g.arc(p[0]+.4,p[1]+1.3,1.2,0,RPMT)}g.fill();
  /* the totem holds an ice crystal; icicles under the carved head */
  g.save();staff(g,A);const top=A.top;
  rpmGlow(g,0,top-4,16,'#5ae0ff',.55);
  rpvXtal(g,-2.6,top+3,9.6,2.4,-.5);rpvXtal(g,2.6,top+3,9.6,2.4,.5);rpvXtal(g,0,top+2.4,15,3.2,0);
  rpvIce(g,-3.4,top+11,4.6);rpvIce(g,3,top+11,5.6);
  g.restore();
  rpvPuff(g,hx+15,hy+5.4,ph,.9)}};
 RPVA.ember.shaman={f(g,ph){const A=an(ph),by=A.by;
  rpvHorn(g,-4.6,-59.6+by,12,2.8,-.8,-1);rpvHorn(g,6.4,-60.4+by,10.4,2.5,.42,1);
  g.save();staff(g,A);rpvFire(g,0,A.top+1.6,19,5.2,ph,0,3);g.restore();
  for(const [x,y] of[[-17,-11],[-6,-12],[6,-11.4]])rpmGlow(g,x,y+by,6,'#ff6a1a',.35);
  rpvSparks(g,-16,12,-12+by,20,ph,5,19)}};
}
/* 8. behemoth */
{const an=ph=>{const a=ph*RPMT;return{a,by:(Math.cos(a*2)-1)*1.5,tl:Math.sin(a)*.012,hn:Math.sin(a*2+.8)*1.4}};
 const BODY=(g,A)=>{g.translate(0,-60);g.rotate(A.tl);g.translate(0,60+A.by)};
 const RAM=g=>{g.translate(-86,-110);g.rotate(-.15)};
 const COLS=[[-90,-84,10,22,-.62],[-82,-94,12,30,-.4],[-68,-102,10,20,-.16],[72,-112,9,18,.5],[80,-104,10,22,.72],[86,-94,8,14,.95]];
 const tip=c=>{const L=c[3]+c[2]*.35;return[c[0]+L*Math.sin(c[4]),c[1]-L*Math.cos(c[4])]};
 RPVA.moss.behemoth={f(g,ph){const A=an(ph);BODY(g,A);
  /* moss on the haunch and the shoulder */
  rpvMoss(g,[-97,-74,-94,-88,-82,-98,-68,-101,-58,-96,-70,-92,-80,-86,-90,-72],[[-88,-88,3.6],[-74,-97,3.2]]);
  rpvMoss(g,[66,-118,76,-121,86,-112,92,-98,86,-100,80,-108,72,-112],[[80,-114,3]]);
  /* moss and vines on the siege ram */
  g.save();RAM(g);
  rpvMoss(g,[4,-9,10,-15.6,24,-18.6,40,-15.6,52,-17.6,64,-13.6,66,-8,56,-10.4,46,-8.4,34,-10.6,22,-8.4,12,-9.8],[[18,-15,3.4],[44,-14.4,3]]);
  rpvMoss(g,[92,-9,98,-15.4,112,-17.6,124,-14,129,-8.6,118,-10.6,106,-8.6,98,-10.4],[[108,-15.4,3.2]]);
  rpvShroom(g,30,-15,3.6);rpvShroom(g,35,-14.2,2.4);rpvFlower(g,58,-15,1.6);rpvFlower(g,118,-14.6,1.5,'#fff0a0');
  for(const [x0,w,d] of[[30,22,9],[86,26,11],[118,14,7]]){const sw=Math.sin(ph*RPMT+x0)*.8;rpvMoss(g,[x0,9,x0+w*.5,10.6,x0+w,9,x0+w*.92,13+d*.4,x0+w*.75+sw,14+d*.6,x0+w*.6+sw,12.6,x0+w*.45+sw,13+d,x0+w*.3,13.6,x0+w*.15+sw,12+d*.7,x0+w*.05,12.6])}
  g.restore();
  /* moss cap on the head */
  g.save();g.translate(0,A.hn);rpvMoss(g,[84,-99,92,-107.6,106,-110.4,120,-104.6,127,-96,116,-99,104,-100.6,94,-98.2],[[98,-106,3],[114,-104,2.6]]);
  rpvFlower(g,108,-106.4,1.5);g.restore()}};
 RPVA.frost.behemoth={f(g,ph){const A=an(ph);BODY(g,A);
  g.save();RAM(g);
  rpvSnow(g,[2,-9,6,-15.6,20,-19,40,-17.4,60,-19.4,80,-17,100,-19,120,-16.4,136,-14.6,142,-9,130,-10.6,116,-9.4,100,-11,84,-9.4,66,-11.4,48,-9.4,30,-11,14,-9.4],2.2);
  rpvIce(g,24,10.4,7);rpvIce(g,34,10.6,5);rpvIce(g,112,10.4,8);
  g.restore();
  for(const c of COLS.slice(0,3)){const t=tip(c);rpvXtal(g,t[0]+2,t[1]+4,12,2.8,c[4]-.25)}
  for(const [x,l] of[[-86,7],[-32,11],[-22,7],[-4,13],[10,8],[24,10]])rpvIce(g,x,(x<-80?-49:-40.4-Math.max(0,x)*.02),l,l*.28);
  rpvTwk(g,-40,-80,1.4,.85);rpvTwk(g,12,-70,1.2,.7);rpvTwk(g,64,-84,1.3,.8);
  g.save();g.translate(0,A.hn);
  rpvSnow(g,[84,-99,92,-107.6,106,-110.4,120,-104.6,127,-96,116,-99,104,-100.6,94,-98.2],2);
  for(const [x,l] of[[97,7],[106.6,10],[116,6.4],[126,5]])rpvIce(g,x,-31.4,l);
  rpvPuff(g,141,-69,ph,2);g.restore()}};
 RPVA.ember.behemoth={f(g,ph){const A=an(ph);BODY(g,A);
  COLS.forEach((c,i)=>{const t=tip(c);rpvFire(g,t[0],t[1]+3,[16,22,15,14,19,12][i],[4.6,5.6,4.4,4,5,3.6][i],ph,Math.sin(c[4])*.25,i*1.7)});
  for(const [x,s] of[[-30,.1],[6,.45],[34,.75],[-60,.3]])rpvDrip(g,x,-41.4,ph,9,s);
  g.save();g.translate(0,A.hn);rpvFire(g,112,-101,15,5,ph,-.05,5);g.restore();
  rpvSparks(g,-90,90,-100,50,ph,9,23)}};
}

/* ---------- live draw of a variant ---------- */
function rpvDraw(g,id,ph,v){const f=RPMD[id];if(!f)return;ph=+ph||0;ph-=Math.floor(ph);const A=(RPVA[v]||{})[id]||{},M=rpvMap(v,id);
 g.save();g.lineJoin='round';g.lineCap='round';const k=RPMK[id]||1;g.scale(k,k);
 try{if(A.b){g.save();A.b(g,ph);g.restore()}
  g.save();f(M?rpvPX(g,M):g,ph,{});g.restore();
  if(A.f){g.save();g.lineJoin='round';g.lineCap='round';A.f(g,ph);g.restore()}}finally{g.restore()}}

/* ---------- baked variant sheets ---------- */
/* extra room around the 95b frame box for accessories [left, top, right, bottom] */
const RPVX={scamp:[3,8,8,0],bulwark:[2,8,8,0],golem:[6,10,12,0],gloom:[8,6,8,2],ooze:[2,10,2,0],oozelet:[2,8,2,0],shaman:[4,8,8,0],behemoth:[2,6,26,0]};
const RPVC={};
function rpvBake(id,v){const key=v+'|'+id;let C=RPVC[key];if(C)return C;const B0=RPMB[id];if(!B0)return null;const X=RPVX[id]||[0,0,0,0],B=[B0[0]-X[0],B0[1]-X[1],B0[2]+X[2],B0[3]+X[3],B0[4]];
 const w=B[2]-B[0],h=B[3]-B[1],fw=Math.ceil(w*RPSS),fh=Math.ceil(h*RPSS);
 const cv=document.createElement('canvas');cv.width=fw*RPNF;cv.height=fh;const g=cv.getContext('2d');
 for(let i=0;i<RPNF;i++){g.setTransform(RPSS,0,0,RPSS,i*fw-B[0]*RPSS,-B[1]*RPSS);g.save();g.beginPath();g.rect(B[0],B[1],w,h);g.clip();rpvDraw(g,id,i/RPNF,v);g.restore()}
 g.setTransform(1,0,0,1,0,0);return RPVC[key]={B,w,h,fw,fh,cv,wh:null,ic:null,sw:B[4]}}
function rpvSheet(id,v){v=rpvV(id,v);return v?(RPVC[v+'|'+id]||rpvBake(id,v)):(RPMC[id]||rpmBake(id))}
function rpMobPrebake(ids,v){for(const id of(ids||Object.keys(RPMOB)))rpvSheet(id,v)}
function rpMobBlit(c,id,x,y,ph,o){o=o||{};const C=rpvSheet(id,o.v);if(!C)return;const M=RPMOB[id];
 const s=o.s>0?o.s:1,a=o.a==null?1:Math.max(0,Math.min(1,o.a));if(a<=0)return;
 ph=+ph||0;ph-=Math.floor(ph);const fi=Math.min(RPNF-1,Math.floor(ph*RPNF)),sx=fi*C.fw,lift=M.air?(M.lift||38)*s:0,ga=c.globalAlpha;
 const sw=C.sw*s*(M.air?.7:1);c.globalAlpha=ga*a*(M.air?.5:1);c.drawImage(RPSHD,x-sw,y-sw*.3,sw*2,sw*.6);
 const fl=o.flash>0?Math.min(1,o.flash):0,ch=o.chill>0?Math.min(1,o.chill):0;
 if(ch&&!C.ic)C.ic=rpmTint(C,1);if(fl&&!C.wh)C.wh=rpmTint(C,0);
 const dw=C.w*s,dh=C.h*s;let dx,dy,tr=o.flip||o.rot;
 if(tr){c.save();c.translate(x,y-lift);if(o.rot){const cy=M.h*s*.5;c.translate(0,-cy);c.rotate(o.rot);c.translate(0,cy)}if(o.flip)c.scale(-1,1);dx=C.B[0]*s;dy=C.B[1]*s}
 else{dx=x+C.B[0]*s;dy=y-lift+C.B[1]*s}
 c.globalAlpha=ga*a;c.drawImage(C.cv,sx,0,C.fw,C.fh,dx,dy,dw,dh);
 if(ch){c.globalAlpha=ga*a*ch*.62;c.drawImage(C.ic,sx,0,C.fw,C.fh,dx,dy,dw,dh)}
 if(fl){c.globalAlpha=ga*a*fl;c.drawImage(C.wh,sx,0,C.fw,C.fh,dx,dy,dw,dh)}
 if(tr)c.restore();c.globalAlpha=ga}

/* ---------- portraits ---------- */
const RPVTB={};
function rpvTight(id,ph,v){const key=v+'|'+id+'|'+ph;if(RPVTB[key])return RPVTB[key];const B0=RPMB[id],X=RPVX[id]||[0,0,0,0],B=[B0[0]-X[0],B0[1]-X[1],B0[2]+X[2],B0[3]+X[3]];
 const w=Math.ceil(B[2]-B[0]),h=Math.ceil(B[3]-B[1]),cv=document.createElement('canvas');cv.width=w;cv.height=h;
 const g=cv.getContext('2d');g.translate(-B[0],-B[1]);rpvDraw(g,id,ph,v);let d;try{d=g.getImageData(0,0,w,h).data}catch(e){return RPVTB[key]=B.slice(0,4)}
 let x0=w,y0=h,x1=0,y1=0;for(let y=0;y<h;y++)for(let x=0;x<w;x++)if(d[(y*w+x)*4+3]>40){if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y}
 if(x1<x0)return RPVTB[key]=B.slice(0,4);return RPVTB[key]=[x0+B[0],y0+B[1],x1+1+B[0],Math.max(y1+1+B[1],0)]}
const RPVI={};
function rpMobIcon(id,size,v){size=Math.max(8,Math.round(size||64));v=rpvV(id,v);const key=id+'|'+size+'|'+v;if(RPVI[key])return RPVI[key];
 const cv=document.createElement('canvas');cv.width=cv.height=size;const M=RPMOB[id],B=RPMB[id];if(!M||!B)return cv;const g=cv.getContext('2d');
 const ph=M.air?.02:.12,T=(v?rpvTight(id,ph,v):rpmTight(id,ph)).slice(),h=T[3]-T[1];if(T[2]-T[0]>h*1.25)T[0]=T[2]-h*1.25;const w=T[2]-T[0],k=size*.9/Math.max(w,h);
 g.translate(size/2-(T[0]+w/2)*k,size/2-(T[1]+h/2)*k);g.scale(k,k);
 if(!M.air){g.drawImage(RPSHD,-B[4],-B[4]*.3,B[4]*2,B[4]*.6)}
 if(v)rpvDraw(g,id,ph,v);else rpMobDraw(g,id,ph,{icon:1});RPVI[key]=cv;return cv}

/* ---------- deaths with variant colours ---------- */
const RPVDX={
 frost:{scamp:['#bfe8f4','#8cc8ec','#5aa0e0','#ffffff'],bulwark:['#eaf6ff','#7af0ff'],golem:['#b8d4ec','#7ae4ff','#e8fbff','#ffffff'],gloom:['#4a8ad8','#e8fbff','#9ad8ff'],
  ooze:['#a8dcf4','#e8f8ff'],oozelet:['#b4e2f8'],shaman:['#3a5ab0','#9ae8ff','#e8fbff'],behemoth:['#7ea4c4','#46d4ff','#eafcff','#c8dcec'],_:{pud:'#9ad0f0',ring:'#e0f4ff',boss:'#7ae4ff'}},
 ember:{scamp:['#4a3a3a','#2e2226','#ff6a1a','#ffb43a'],bulwark:['#8a8078','#ff8a2a'],golem:['#3a3034','#ffb02e','#ff6a1a','#5a4c4c'],gloom:['#3a1418','#ffd24a','#ff6a1a'],
  ooze:['#ff7a1a','#2a1c20'],oozelet:['#ff8a2a'],shaman:['#4a1620','#ffb43a','#ff5a2a'],_:{pud:'#e8501a',ring:'#ff8a3a',boss:'#ff8a3a'}},
 moss:{behemoth:['#4c5a52','#7ae04a','#e4ff9a','#7a9a80'],_:{pud:'#2fc49a',ring:'#c8ccd8',boss:'#9af06a'}}};
function rpMobDeath(c,id,x,y,k,o){const M=RPMOB[id],D0=RPMDX[id];if(!M||!D0||!(k<1))return;k=Math.max(0,k);o=o||{};
 const vv=o.v==='frost'||o.v==='ember'?o.v:'moss',VT=RPVDX[vv],X=VT._,vc=VT[id],D=vc?{n:D0.n,k:D0.k,c:vc}:D0,base=!rpvV(id,o.v);
 const s=o.s>0?o.s:1,fl=o.flip?-1:1,h=M.h*s,lift=M.air?(M.lift||38)*s:0,cy=y-lift-h*.5,ga=c.globalAlpha,seed=o.seed==null?Math.round(x*7+y*3):o.seed,big=M.boss?1:0;
 const fade=k<.6?1:1-(k-.6)/.4;
 if(k<.3){const u=k/.3;c.save();c.globalCompositeOperation='lighter';c.globalAlpha=ga*(1-u)*.7;const r=h*(.55+u*.5);const q=c.createRadialGradient(x,cy,0,x,cy,r);q.addColorStop(0,'rgba(255,248,230,.9)');q.addColorStop(1,'rgba(255,248,230,0)');c.fillStyle=q;c.fillRect(x-r,cy-r,r*2,r*2);c.restore()}
 if(k<.22){const C=rpvSheet(id,o.v);if(C){if(!C.wh)C.wh=rpmTint(C,0);const u=k/.22;c.save();c.globalAlpha=ga*(1-u);c.translate(x,y-lift);c.scale(fl*(1+u*.3),1-u*.55);c.drawImage(C.wh,0,0,C.fw,C.fh,C.B[0]*s,C.B[1]*s,C.w*s,C.h*s);c.restore()}}
 if(id==='ooze'||id==='oozelet'){const u=Math.min(1,k/.25),r=M.w*s*.5*(.6+u*.6);c.globalAlpha=ga*fade*.75;c.fillStyle=base?'#2fc49a':X.pud;c.beginPath();c.ellipse(x,y,r,r*.22,0,0,RPMT);c.fill();c.fillStyle=vv==='ember'?'rgba(255,220,120,.55)':'rgba(220,245,255,.5)';c.beginPath();c.ellipse(x-r*.25,y-r*.05,r*.35,r*.06,0,0,RPMT);c.fill()}
 if(big||id==='golem'){const r=M.w*s*(.3+k*.9);c.globalAlpha=ga*(1-k)*.8;c.lineWidth=(big?6:4)*s*(1-k)+1;c.strokeStyle=big?(vv==='ember'?'#ff8a3a':X.boss):(vv==='moss'?'#c8ccd8':X.ring);c.beginPath();c.ellipse(x,y,r,r*.26,0,0,RPMT);c.stroke()}
 const G=h*3.4,T=k;
 for(let i=0;i<D.n;i++){const kd=D.k[i],r1=rpmRn(seed+i*3.1),r2=rpmRn(seed+i*5.7+1),r3=rpmRn(seed+i*1.3+2);
  const ang=-Math.PI/2+(r1-.5)*2.4,sp=h*(kd==='puff'?.5:1)*(.9+r2*1.1)*(big?1.2:1);
  let px=x+Math.cos(ang)*sp*T*fl+(r3-.5)*M.w*s*.3,py=cy+(r2-.5)*h*.4+Math.sin(ang)*sp*T+(kd==='puff'||kd==='spark'?-.1:.5)*G*T*T;
  const sz=(kd==='rock'?(big?11:7):kd==='lava'?4:kd==='puff'?7+k*12:kd==='cap'?7:kd==='skull'?5.4:kd==='bone'?3.4:3.6)*s*(.75+r3*.6);
  if(kd==='feather'||kd==='scrap'||kd==='leaf'){py=cy+Math.sin(ang)*sp*T*.6+h*.9*T*T+Math.sin(T*9+i)*3*s;px+=Math.sin(T*6+i)*6*s}
  if(kd!=='puff'&&kd!=='spark'&&py>y-sz*.4)py=y-sz*.4;
  const rot=(r1*6+T*(8+r2*10))*(r3>.5?1:-1);c.globalAlpha=ga*fade;
  if(kd==='puff'){c.globalAlpha=ga*fade*(1-k)*.55;c.fillStyle=D.c[(i%2)?0:D.c.length-1];c.beginPath();c.arc(px,py,sz,0,RPMT);c.fill();continue}
  if(kd==='spark'||kd==='lava'){c.save();c.globalCompositeOperation='lighter';c.fillStyle=kd==='lava'?(i%2?D.c[1]:D.c[2]):D.c[1+(i%Math.max(1,D.c.length-1))];c.beginPath();c.arc(px,py,sz*(1-k*.5),0,RPMT);c.fill();c.restore();continue}
  if(kd==='drop'){c.fillStyle=D.c[0];c.beginPath();c.arc(px,py,sz*1.3,0,RPMT);c.fill();c.lineWidth=1.2*s;c.strokeStyle=RPMO;c.stroke();c.fillStyle='rgba(255,255,255,.6)';c.beginPath();c.arc(px-sz*.4,py-sz*.4,sz*.4,0,RPMT);c.fill();continue}
  c.save();c.translate(px,py);c.rotate(rot);c.lineWidth=1.4*s;c.strokeStyle=RPMO;c.beginPath();
  if(kd==='bone'){c.rect(-sz*1.6,-sz*.4,sz*3.2,sz*.8);c.fillStyle=D.c[0];c.fill();c.stroke();c.beginPath();c.arc(-sz*1.6,0,sz*.55,0,RPMT);c.arc(sz*1.6,0,sz*.55,0,RPMT);c.fill();c.stroke()}
  else if(kd==='skull'){c.arc(0,0,sz,0,RPMT);c.fillStyle=D.c[0];c.fill();c.stroke();c.fillStyle=RPMO;c.fillRect(sz*.1,-sz*.3,sz*.35,sz*.4)}
  else if(kd==='rock'){c.moveTo(-sz,-sz*.6);c.lineTo(sz*.3,-sz);c.lineTo(sz,-sz*.1);c.lineTo(sz*.4,sz*.8);c.lineTo(-sz*.8,sz*.6);c.closePath();c.fillStyle=i%3?D.c[0]:D.c[3];c.fill();c.stroke();if(big&&i%2){c.beginPath();c.moveTo(-sz*.5,-sz*.3);c.lineTo(sz*.3,sz*.3);c.strokeStyle=D.c[1];c.stroke()}}
  else if(kd==='cap'){c.arc(0,0,sz,Math.PI,RPMT);c.closePath();c.fillStyle=D.c[2];c.fill();c.stroke();c.fillStyle=vv==='ember'?'#ffb43a':'#fff3da';c.beginPath();c.arc(-sz*.3,-sz*.4,sz*.2,0,RPMT);c.fill()}
  else if(kd==='thorn'){c.moveTo(-sz*.6,0);c.lineTo(0,-sz*2.2);c.lineTo(sz*.6,0);c.closePath();c.fillStyle=D.c[1];c.fill();c.stroke()}
  else{c.ellipse(0,0,sz*1.5,sz*.6,0,0,RPMT);c.fillStyle=kd==='feather'?D.c[1+(i%2)]:kd==='scrap'?D.c[0]:D.c[i%2];c.fill();c.stroke()}
  c.restore()}
 c.globalAlpha=ga}
