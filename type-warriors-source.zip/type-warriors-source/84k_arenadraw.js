/* ---------- Warden's Arena: the moonlit stone arena, the characters, the HUD and the timing bar ---------- */
const WA_F='"Pirata One",Georgia,serif',WA_G='Georgia,serif',WA_P='Poppins,system-ui,sans-serif';
let WA_BG=null,WA_BGS=null,WA_Q=2;
function waBuildBG(){const cv2=document.createElement('canvas');cv2.width=W;cv2.height=H;const g=cv2.getContext('2d');
 const R=i=>{const x=Math.sin(i*91.7+13.1)*43758.5453;return x-Math.floor(x)};
 /* a dusk sky over the colosseum */
 let q=g.createLinearGradient(0,0,0,330);q.addColorStop(0,'#120a36');q.addColorStop(.45,'#4a2264');q.addColorStop(.8,'#b0486a');q.addColorStop(1,'#f08a5a');g.fillStyle=q;g.fillRect(0,0,W,340);
 for(let i=0;i<90;i++){const x=R(i)*W,y=R(i+300)*150,s=R(i+7)*1.5+.4;g.globalAlpha=(.25+R(i+9)*.6)*(1-y/170);g.fillStyle='#fff';g.fillRect(x,y,s,s)}g.globalAlpha=1;
 /* the setting sun behind the far stands */
 {const mx=1250,my=226;let m=g.createRadialGradient(mx,my,30,mx,my,360);m.addColorStop(0,'#ffe2a0aa');m.addColorStop(.35,'#ff9a5a44');m.addColorStop(1,'#ff6a5a00');g.fillStyle=m;g.fillRect(mx-380,my-380,760,760);
  g.save();g.globalAlpha=.16;g.fillStyle='#ffe2a0';for(let i=0;i<9;i++){const a=-Math.PI*.95+i*Math.PI*.11;g.beginPath();g.moveTo(mx,my);g.lineTo(mx+Math.cos(a-.035)*900,my+Math.sin(a-.035)*900);g.lineTo(mx+Math.cos(a+.035)*900,my+Math.sin(a+.035)*900);g.fill()}g.restore();
  m=g.createRadialGradient(mx,my,0,mx,my,74);m.addColorStop(0,'#fff6d8');m.addColorStop(.7,'#ffd08a');m.addColorStop(1,'#ff9a5a');g.fillStyle=m;g.beginPath();g.arc(mx,my,74,0,TAU);g.fill()}
 /* clouds */
 g.fillStyle='#ff9a8a33';for(let i=0;i<7;i++){const cx=R(i+50)*W,cy=70+R(i+60)*130,w=180+R(i+70)*220;g.beginPath();g.ellipse(cx,cy,w,14+R(i+80)*10,0,0,TAU);g.fill()}
 /* the far stands: three tiers of arches, a crowd in every opening */
 const tierY=[188,262,340],tierH=[64,70,78];
 q=g.createLinearGradient(0,170,0,430);q.addColorStop(0,'#5a3a5a');q.addColorStop(1,'#3a2440');g.fillStyle=q;g.fillRect(0,168,W,262);
 g.fillStyle='#6a4a62';g.fillRect(0,160,W,14);g.fillStyle='#7a5a6a';for(let x=0;x<W;x+=38){g.fillRect(x+4,148,22,14)}
 for(let t2=0;t2<3;t2++){const y0=tierY[t2],h0=tierH[t2],aw=t2===2?96:t2===1?84:74,gap=t2===2?30:24;g.fillStyle='#7a5868';g.fillRect(0,y0-6,W,6);g.fillStyle='#2a1830';g.fillRect(0,y0+h0-2,W,3);
  for(let x=-20+t2*17;x<W;x+=aw+gap){g.fillStyle='#1a0e22';g.beginPath();g.moveTo(x,y0+h0);g.lineTo(x,y0+aw*.42);g.arc(x+aw/2,y0+aw*.42,aw/2,Math.PI,0);g.lineTo(x+aw,y0+h0);g.closePath();g.fill();
   /* the crowd: heads and shoulders in the shadows, a few bright robes */
   for(let k=0;k<6;k++){const hx=x+8+R(x*.3+k+t2*50)*(aw-16),hy=y0+h0-14-R(x+k*3+t2)*16,col=R(x+k+t2*9)<.22?['#c84a4a','#e8c86a','#5a8ad8','#e8e0d0'][Math.floor(R(x*k+t2)*4)]:'#3a2440';g.fillStyle=col;g.beginPath();g.arc(hx,hy,6+R(k+x)*2,0,TAU);g.fill();g.fillRect(hx-8,hy+4,16,14)}
   g.strokeStyle='#8a6a78';g.lineWidth=3;g.beginPath();g.moveTo(x,y0+h0);g.lineTo(x,y0+aw*.42);g.arc(x+aw/2,y0+aw*.42,aw/2,Math.PI,0);g.lineTo(x+aw,y0+h0);g.stroke();
   g.fillStyle='#6a4a5a';g.fillRect(x+aw+gap*.2,y0,gap*.6,h0)}}
 q=g.createLinearGradient(0,150,0,430);q.addColorStop(0,'#ff9a6a22');q.addColorStop(1,'#1a0e2a55');g.fillStyle=q;g.fillRect(0,150,W,280);
 /* the velarium: striped awnings hanging from the rim */
 for(const [x0,dir] of[[0,1],[W,-1]]){for(let i=0;i<5;i++){const xa=x0+dir*i*72,xb=xa+dir*72,sag=60+i*18;g.fillStyle=i%2?'#e8dcc0':'#b8283a';g.beginPath();g.moveTo(xa,0);g.lineTo(xb,0);g.quadraticCurveTo((xa+xb)/2,sag*.6,xb-dir*10,sag-20+i*4);g.lineTo(xa,sag+10-i*6);g.closePath();g.fill();g.fillStyle='#0003';g.fillRect(Math.min(xa,xb),0,72,6)}
  g.strokeStyle='#3a2018';g.lineWidth=4;g.beginPath();g.moveTo(x0+dir*360,0);g.lineTo(x0+dir*340,130);g.stroke()}
 /* the podium wall around the sand: marble with gold trim and painted panels */
 q=g.createLinearGradient(0,428,0,504);q.addColorStop(0,'#e8d8c8');q.addColorStop(.5,'#c8b0a8');q.addColorStop(1,'#8a6a70');g.fillStyle=q;g.fillRect(0,428,W,76);g.fillStyle='#d8a53a';g.fillRect(0,424,W,6);g.fillRect(0,498,W,4);
 for(let i=0;i<14;i++){const px=20+i*118;g.fillStyle=i%2?'#8a2a3a':'#2a3a6a';g.fillRect(px,442,92,46);g.strokeStyle='#d8a53a';g.lineWidth=2;g.strokeRect(px+4,446,84,38);g.fillStyle='#e8c86a';g.beginPath();g.arc(px+46,465,8,0,TAU);g.fill()}
 g.fillStyle='#0f0818';g.fillRect(0,502,W,6);
 /* sand: warm, raked and scuffed */
 q=g.createLinearGradient(0,506,0,H);q.addColorStop(0,'#a8705a');q.addColorStop(.35,'#c89068');q.addColorStop(1,'#6a3a3a');g.fillStyle=q;g.fillRect(0,506,W,H-506);
 for(let i=0;i<2600;i++){const x=R(i*3.1)*W,y=506+Math.pow(R(i*7.7),1.3)*(H-506),r=R(i*1.3)*1.6+.4;g.fillStyle=R(i)>.5?'#ffd8b022':'#3a181822';g.fillRect(x,y,r,r)}
 g.strokeStyle='#5a2a2a26';g.lineWidth=2;for(let r=0;r<9;r++){g.beginPath();g.ellipse(800,700,300+r*120,40+r*24,0,Math.PI*1.05,Math.PI*1.95);g.stroke()}
 /* the arena seal pressed in the sand */
 g.save();g.translate(800,646);g.scale(1,.2);g.strokeStyle='#ffd88a';g.lineWidth=12;g.globalAlpha=.35;g.beginPath();g.arc(0,0,640,0,TAU);g.stroke();g.lineWidth=5;g.globalAlpha=.45;g.beginPath();g.arc(0,0,560,0,TAU);g.stroke();
 g.fillStyle='#ffe2a8';g.globalAlpha=.18;g.beginPath();for(let i=0;i<16;i++){const a=i*TAU/16-Math.PI/2,r=i%2?110:300;g.lineTo(Math.cos(a)*r,Math.sin(a)*r)}g.closePath();g.fill();g.restore();
 /* columns that hold the braziers */
 for(const px of[70,470,1130,1530]){q=g.createLinearGradient(px-30,0,px+30,0);q.addColorStop(0,'#8a7078');q.addColorStop(.45,'#f0e0d8');q.addColorStop(1,'#6a5058');g.fillStyle=q;g.fillRect(px-30,262,60,250);
  g.strokeStyle='#5a4048aa';g.lineWidth=2;for(let k=-2;k<=2;k++){g.beginPath();g.moveTo(px+k*11,272);g.lineTo(px+k*11,504);g.stroke()}
  g.fillStyle='#d8c0b8';g.fillRect(px-42,250,84,16);g.fillStyle='#d8a53a';g.fillRect(px-42,262,84,4);g.fillStyle='#b8a0a0';g.fillRect(px-40,500,80,16);
  g.fillStyle='#4a3038';g.beginPath();g.moveTo(px-32,246);g.lineTo(px+32,246);g.lineTo(px+22,224);g.lineTo(px-22,224);g.fill();g.strokeStyle='#d8a53a';g.lineWidth=2;g.stroke()}
 /* warm vignette */
 q=g.createRadialGradient(W/2,H*.55,H*.35,W/2,H*.55,H*.95);q.addColorStop(0,'#0000');q.addColorStop(1,'#12061699');g.fillStyle=q;g.fillRect(0,0,W,H);
 return cv2}
/* the mode's cover: Taurox looms against the sunset while a warden raises his shield */
function waCover(){if(waCover.u)return waCover.u;try{if(!WA_BG)WA_BG=waBuildBG();const c=document.createElement('canvas');c.width=600;c.height=600;const g=c.getContext('2d');
 g.drawImage(WA_BG,560,60,640,640,0,0,600,600);g.fillStyle='#1a0a2a55';g.fillRect(0,0,600,600);
 let q=g.createRadialGradient(330,150,10,330,150,380);q.addColorStop(0,'#fff0c8ee');q.addColorStop(.22,'#ffb070aa');q.addColorStop(.6,'#c8406a33');q.addColorStop(1,'#2a0a2a00');g.fillStyle=q;g.fillRect(0,0,600,600);
 g.save();g.globalAlpha=.22;g.fillStyle='#fff0c8';for(let i=0;i<16;i++){const a=i*TAU/16+.1;g.beginPath();g.moveTo(330,170);g.lineTo(330+Math.cos(a-.045)*700,170+Math.sin(a-.045)*700);g.lineTo(330+Math.cos(a+.045)*700,170+Math.sin(a+.045)*700);g.fill()}g.restore();
 /* Taurox, huge and backlit, labrys raised */
 g.save();g.translate(372,445);const M=MON.gMino,sc=2.45;g.scale(sc,sc);g.shadowColor='#ffb06acc';g.shadowBlur=18;try{M.d(g,1.1,{lg:.55})}catch(e){}g.restore();
 /* rim light */
 g.save();g.globalCompositeOperation='source-atop';q=g.createLinearGradient(600,0,200,0);q.addColorStop(0,'#ffb06a00');q.addColorStop(1,'#ffb06a00');g.restore();
 /* the warden's shield in the foreground, catching the light */
 g.save();g.translate(118,330);g.rotate(-.12);g.globalCompositeOperation='lighter';glowW(g,0,0,150,'#5ac8ff55');g.globalCompositeOperation='source-over';g.scale(1.02,1.02);g.beginPath();g.moveTo(-26,-70);g.quadraticCurveTo(30,-82,52,-48);g.quadraticCurveTo(58,20,22,72);g.quadraticCurveTo(-4,92,-30,74);g.quadraticCurveTo(-50,20,-26,-70);g.closePath();q=g.createLinearGradient(-30,-70,50,70);q.addColorStop(0,'#f0f4fa');q.addColorStop(.5,'#8a97b4');q.addColorStop(1,'#4a5270');g.fillStyle=q;g.fill();g.lineWidth=5;g.strokeStyle='#0a0620';g.stroke();g.lineWidth=3;g.strokeStyle='#e8c24a';g.stroke();
 g.fillStyle='#8a1a2a';g.beginPath();g.arc(6,4,26,0,TAU);g.fill();g.strokeStyle='#e8c24a';g.lineWidth=2.5;g.stroke();g.fillStyle='#ffe27a';g.beginPath();g.moveTo(6,-16);g.lineTo(12,0);g.lineTo(28,0);g.lineTo(15,10);g.lineTo(20,26);g.lineTo(6,16);g.lineTo(-8,26);g.lineTo(-3,10);g.lineTo(-16,0);g.lineTo(0,0);g.closePath();g.fill();g.restore();
 /* embers and sparks */
 g.save();g.globalCompositeOperation='lighter';for(let i=0;i<70;i++){const x=Math.abs(Math.sin(i*12.9))*600,y=Math.abs(Math.sin(i*7.3))*560,r=1+Math.abs(Math.sin(i*3.1))*2.4;g.fillStyle=i%3?'#ffb86a':'#fff3c0';g.globalAlpha=.25+.6*Math.abs(Math.sin(i*5.7));g.beginPath();g.arc(x,y,r,0,TAU);g.fill()}g.restore();
 q=g.createRadialGradient(300,260,200,300,300,520);q.addColorStop(0,'#0000');q.addColorStop(1,'#0a0414cc');g.fillStyle=q;g.fillRect(0,0,600,600);
 waCover.u=c.toDataURL('image/jpeg',.86)}catch(e){waCover.u=''}return waCover.u}
function waBanner(c,x,y,w,h,t,ph,big){const sw=Math.sin(t*1.3+ph),sw2=Math.sin(t*1.9+ph*2);c.save();c.translate(x,y);
 c.fillStyle='#8a6a22';c.fillRect(-w/2-8,-6,w+16,10);c.fillStyle='#f0c24a';c.fillRect(-w/2-8,-6,w+16,4);
 const b=sw*h*.05,b2=sw2*h*.03;c.beginPath();c.moveTo(-w/2,0);c.lineTo(w/2,0);c.bezierCurveTo(w/2+b*.6,h*.4,w/2+b,h*.7,w/2+b2+2,h*.92);c.lineTo(b2*.5,h*1.0+Math.abs(sw)*4);c.lineTo(-w/2+b2-2,h*.92);c.bezierCurveTo(-w/2+b,h*.7,-w/2+b*.6,h*.4,-w/2,0);c.closePath();
 const q=c.createLinearGradient(0,0,0,h);q.addColorStop(0,'#c8283a');q.addColorStop(1,'#5a0a1a');c.fillStyle=q;c.fill();c.strokeStyle='#f0c24a';c.lineWidth=3;c.stroke();
 c.save();c.clip();const sh=c.createLinearGradient(-w/2,0,w/2,0);sh.addColorStop(0,'#0006');sh.addColorStop(.5,'#ffffff12');sh.addColorStop(1,'#0006');c.fillStyle=sh;c.fillRect(-w,0,w*2,h*1.2);c.restore();
 /* crest: a golden shield with a crown and a blade */
 c.translate(b*.45,h*.38);const s=w/90;c.scale(s,s);c.fillStyle='#f0c24a';c.strokeStyle='#5a3a08';c.lineWidth=2.2;c.beginPath();c.moveTo(-22,-26);c.lineTo(22,-26);c.lineTo(22,6);c.quadraticCurveTo(22,28,0,38);c.quadraticCurveTo(-22,28,-22,6);c.closePath();c.fill();c.stroke();
 c.fillStyle='#7a1020';c.beginPath();c.moveTo(-15,-19);c.lineTo(15,-19);c.lineTo(15,5);c.quadraticCurveTo(15,22,0,30);c.quadraticCurveTo(-15,22,-15,5);c.closePath();c.fill();
 c.fillStyle='#f0c24a';c.beginPath();c.moveTo(-10,-10);c.lineTo(-6,-18);c.lineTo(0,-10);c.lineTo(6,-18);c.lineTo(10,-10);c.lineTo(9,-3);c.lineTo(-9,-3);c.closePath();c.fill();c.fillRect(-2,-2,4,26);c.fillRect(-8,6,16,3.4);c.restore()}
function waTorch(c,x,y,t,ph){const f=Math.sin(t*11+ph)*.5+Math.sin(t*17+ph*2)*.5;c.save();c.translate(x,y);
 glowW(c,0,-18,150+f*14,'#ff9a3a55');
 c.fillStyle='#2a1c14';c.beginPath();c.moveTo(-26,0);c.lineTo(26,0);c.lineTo(18,26);c.lineTo(-18,26);c.closePath();c.fill();c.strokeStyle='#c8902a';c.lineWidth=3;c.stroke();c.fillStyle='#4a3020';c.fillRect(-20,-6,40,8);
 for(const [s,col] of[[1,'#e8501a'],[.74,'#ff9a2a'],[.46,'#ffe27a']]){const h=(46+f*7)*s,w=(18+f*2)*s;c.fillStyle=col;c.beginPath();c.moveTo(-w,-4);c.bezierCurveTo(-w*1.1,-h*.45,-w*.3+f*3,-h*.7,f*5,-h);c.bezierCurveTo(w*.3+f*3,-h*.7,w*1.1,-h*.45,w,-4);c.closePath();c.fill()}
 c.restore()}
const glowW=(c,x,y,r,col)=>{const q=c.createRadialGradient(x,y,0,x,y,r);q.addColorStop(0,col);q.addColorStop(1,col[0]==='#'?col.slice(0,7)+'00':col.replace(/,[^,]*\)$/,',0)'));c.fillStyle=q;c.fillRect(x-r,y-r,r*2,r*2)};
function waBGStatic(){if(WA_BGS)return WA_BGS;if(!WA_BG)WA_BG=waBuildBG();const k=document.createElement('canvas');k.width=W;k.height=H;const g=k.getContext('2d');g.drawImage(WA_BG,0,0);waBanner(g,255,262,92,170,1,0);waBanner(g,640,262,84,150,1,1.7);waBanner(g,960,262,84,150,1,3.1);waBanner(g,1345,262,92,170,1,4.6);for(const [i,px] of[70,470,1130,1530].entries())waTorch(g,px,206,1,i*1.9);return WA_BGS=k}
function waDrawBG(c,t){if(WA_Q<1){c.drawImage(waBGStatic(),0,0);return}if(!WA_BG)WA_BG=waBuildBG();c.drawImage(WA_BG,0,0);
 waBanner(c,255,262,92,170,t,0);waBanner(c,640,262,84,150,t,1.7);waBanner(c,960,262,84,150,t,3.1);waBanner(c,1345,262,92,170,t,4.6);
 for(const [i,px] of[70,470,1130,1530].entries())waTorch(c,px,206,t,i*1.9);
 /* embers rising from the braziers */
 if(WA_Q>=2){c.save();for(let i=0;i<22;i++){const px=[70,470,1130,1530][i%4],u=((t*.22+i*.137)%1),x=px+Math.sin(i*5.1+t*1.3)*40*u,y=200-u*210;c.globalAlpha=(1-u)*.9;c.fillStyle=i%3?'#ffb040':'#ffe9a0';c.fillRect(x,y,2.4,2.4)}c.restore()}}
/* ---------- icons ---------- */
function waIcShield(c,x,y,s,col,fill){c.save();c.translate(x,y);c.scale(s,s);c.beginPath();c.moveTo(-18,-20);c.lineTo(18,-20);c.lineTo(18,2);c.quadraticCurveTo(18,22,0,30);c.quadraticCurveTo(-18,22,-18,2);c.closePath();c.fillStyle=fill||'#c9a43a';c.fill();c.lineWidth=3;c.strokeStyle=col||'#fff3c0';c.stroke();c.beginPath();c.moveTo(0,-14);c.lineTo(0,22);c.moveTo(-12,0);c.lineTo(12,0);c.lineWidth=2.4;c.strokeStyle=col||'#fff3c0';c.globalAlpha=.8;c.stroke();c.restore()}
function waIcSword(c,x,y,s,col){c.save();c.translate(x,y);c.rotate(-.78);c.scale(s,s);c.fillStyle='#e8d8a0';c.strokeStyle=col||'#7a4a10';c.lineWidth=2.4;c.beginPath();c.moveTo(0,-34);c.lineTo(7,-24);c.lineTo(7,8);c.lineTo(-7,8);c.lineTo(-7,-24);c.closePath();c.fill();c.stroke();c.fillStyle='#d8a53a';c.fillRect(-16,8,32,7);c.strokeRect(-16,8,32,7);c.fillRect(-4,15,8,16);c.strokeRect(-4,15,8,16);c.restore()}
function waKey(c,x,y,w,h,label,glow){c.save();c.fillStyle='#2a2150';c.strokeStyle=glow?'#fff3c0':'#a9b8ff';c.lineWidth=2.4;c.beginPath();c.roundRect(x,y,w,h,10);c.fill();c.stroke();c.fillStyle=glow?'#ffe9a0':'#e8e4ff';c.font='700 '+Math.round(h*.4)+'px '+WA_P;c.textAlign='center';c.textBaseline='middle';c.fillText(label,x+w/2,y+h/2+1);c.restore()}
function waIcHand(c,x,y,s){c.save();c.translate(x,y);c.scale(s,s);c.strokeStyle='#bfe4ff';c.fillStyle='#e8f6ff22';c.lineWidth=2.4;c.lineJoin='round';c.beginPath();c.moveTo(-6,-8);c.lineTo(-6,-24);c.arc(-2,-24,4,Math.PI,0);c.lineTo(2,-6);c.lineTo(2,-14);c.arc(6,-14,4,Math.PI,0);c.lineTo(10,-6);c.arc(14,-8,4,Math.PI,0);c.lineTo(18,6);c.quadraticCurveTo(18,22,4,24);c.lineTo(-4,24);c.quadraticCurveTo(-12,20,-18,8);c.lineTo(-16,2);c.lineTo(-6,10);c.closePath();c.fill();c.stroke();
 for(const [a,b,d,e] of[[-24,-26,-17,-20],[-14,-34,-10,-26],[-26,-14,-18,-12]]){c.beginPath();c.moveTo(a,b);c.lineTo(d,e);c.stroke()}c.restore()}
function waIcMouse(c,x,y,s){c.save();c.translate(x,y);c.scale(s,s);c.strokeStyle='#bfe4ff';c.fillStyle='#e8f6ff22';c.lineWidth=2.6;c.beginPath();c.roundRect(-14,-24,28,48,14);c.fill();c.stroke();c.beginPath();c.moveTo(-14,-4);c.lineTo(14,-4);c.moveTo(0,-24);c.lineTo(0,-4);c.stroke();c.fillStyle='#ffd24a';c.beginPath();c.roundRect(-14,-24,14,20,[14,0,0,0]);c.fill();c.restore()}
function waHeart(c,x,y,s,full,t){c.save();c.translate(x,y);c.scale(s,s);c.beginPath();c.moveTo(0,10);c.bezierCurveTo(-24,-4,-18,-24,-6,-20);c.bezierCurveTo(-2,-19,0,-15,0,-13);c.bezierCurveTo(0,-15,2,-19,6,-20);c.bezierCurveTo(18,-24,24,-4,0,10);c.closePath();
 if(full){const q=c.createLinearGradient(0,-24,0,12);q.addColorStop(0,'#ff6a7e');q.addColorStop(1,'#d8203c');c.fillStyle=q;c.fill();c.lineWidth=3;c.strokeStyle='#5a0818';c.stroke();c.fillStyle='#ffffff88';c.beginPath();c.ellipse(-9,-13,4,2.6,-.6,0,TAU);c.fill()}else{c.fillStyle='#1a0e22';c.fill();c.lineWidth=3;c.strokeStyle='#5a3a52';c.stroke()}c.restore()}
function waPlate(c,x,y,w,h,col){c.save();const q=c.createLinearGradient(0,y,0,y+h);q.addColorStop(0,'#251b52f2');q.addColorStop(1,'#120c30f6');c.fillStyle=q;c.beginPath();c.roundRect(x,y,w,h,12);c.fill();c.strokeStyle=col||'#d8a53a';c.lineWidth=3;c.stroke();c.strokeStyle='#ffe9a044';c.lineWidth=1;c.beginPath();c.roundRect(x+5,y+5,w-10,h-10,8);c.stroke();
 c.fillStyle=col||'#f0c24a';for(const [px,py] of[[x,y],[x+w,y],[x,y+h],[x+w,y+h]]){c.beginPath();c.arc(px,py,4.6,0,TAU);c.fill()}c.restore()}
function waOutText(c,txt,x,y,sz,fill,o){o=o||{};c.save();c.font=sz+'px '+WA_F;c.textAlign=o.align||'center';c.textBaseline=o.base||'middle';c.lineJoin='round';c.lineWidth=Math.max(4,sz*.16);c.strokeStyle=o.stroke||'#0a0620';if(o.rot){c.translate(x,y);c.rotate(o.rot);x=0;y=0}c.shadowColor=o.glow||'#0000';c.shadowBlur=o.glow&&WA_Q>0?18:0;c.strokeText(txt,x,y);c.fillStyle=fill;c.fillText(txt,x,y);c.restore()}
/* ---------- characters ---------- */
function waDrawHero(c,t){const A=S.wa,h=A.hero,X=WAT.HX,Y=WAT.FY;let x=X+h.lunge*110-(h.stag>0?Math.sin(Math.PI*(1-h.stag))*40:0),rot=0,hop=0,sy=1,sx=1;const pz=h.pose,pt=h.poseT||0;
 {const b=Math.sin(t*2.3);sy=1+b*.011;sx=1-b*.006}
 if(h.st==='guard'||h.st==='brec'){sy*=.965;x-=(h.st==='guard'?-6:0)}
 if(pz==='victory'){hop=-Math.abs(Math.sin(pt*5.5))*24*Math.min(1,pt/.5)}
 else if(pz==='dead'){const k1=Math.min(1,pt/.2),k2=Math.max(0,Math.min(1,(pt-.2)/.5)),k3=Math.max(0,Math.min(1,(pt-.7)/.65));x-=Math.sin(k1*Math.PI)*28;sy*=1-.22*k2*(1-k3*.4);rot=.18*k2+1.32*k3*k3}
 /* shadow and aura */
 c.save();c.fillStyle='#0008';c.beginPath();c.ellipse(X+h.lunge*70,Y+8,92,15,0,0,TAU);c.fill();
 if(A.charged&&pz!=='dead'){const p=.6+.4*Math.sin(t*6);glowW(c,X+40,Y-150,230*p+60,'#ffd24a55');c.strokeStyle=`rgba(255,226,122,${.5+.3*p})`;c.lineWidth=4;c.setLineDash([14,10]);c.lineDashOffset=-t*40;c.beginPath();c.ellipse(X+10,Y+4,110,22,0,0,TAU);c.stroke();c.setLineDash([]);
  for(let i=0;i<6;i++){const a=t*2+i*TAU/6;c.fillStyle='#ffe27a';c.beginPath();c.arc(X+10+Math.cos(a)*100,Y-130+Math.sin(a)*120,3.4,0,TAU);c.fill()}}
 c.restore();
 c.save();c.translate(x,Y+hop);if(h.hurt>0&&pz!=='dead'&&Math.floor(t*28)%2)c.globalAlpha=.55;if(h.inv>A.t&&Math.floor(t*24)%2&&h.hurt<=0)c.globalAlpha=.6;c.rotate(rot);c.scale(2.05*sx,2.05*sy);
 const lg=waAtkLg(h,A);
 try{drawHero(c,{arm:P.armor,wp:P.weapon,col:P.col,t,lg:Math.min(1,lg),pose:pz,pu:pz==='victory'?Math.min(1,pt/.3):pz==='dead'?Math.min(1,pt/1.2):0})}catch(e){}
 c.restore()}
/* the warden's swing: a quick wind-back, a hard cut and a follow-through */
function waAtkLg(h,A){if((h.st!=='strike'&&h.st!=='whiff')||h.at0===undefined)return 0;const u=A.t-h.at0;return u<.035?-.32*(u/.035):u<.09?-.32+1.47*sstep(0,1,(u-.035)/.055):u<.2?1.15-.15*((u-.09)/.11):Math.max(0,1-(u-.2)/.14)}
function waDrawSlash(c,t){const A=S.wa,h=A.hero;if(h.at0===undefined||(h.st!=='strike'&&h.st!=='whiff'))return;const u=A.t-h.at0;if(u<.03||u>.3)return;
 const big=h.burstT>0,wf=h.atk==='whiff',k=Math.min(1,(u-.03)/.06),fade=u<.12?1:Math.max(0,1-(u-.12)/.18),alt=(h.atn||0)%2,X=WAT.HX+h.lunge*110+70,Y=WAT.FY-205+(alt?14:0),R=(big?205:170)*(wf?.9:1);
 const a0=alt?-2.05:-1.85,a1=alt?.62:.5,head=a0+(a1-a0)*k,tail=Math.max(a0,head-(big?2.2:1.7));if(head-tail<.02)return;
 c.save();c.translate(X,Y);c.lineCap='round';
 const col=wf?'200,210,240':big?'255,226,122':'255,244,214',core=wf?'#dfe6ff':'#ffffff';
 for(const [w,al] of[[big?54:38,.26],[big?30:20,.55],[big?12:8,1]]){if(WA_Q<1&&al<.4)continue;c.globalAlpha=fade*al*(wf?.6:1);const n=10;for(let i=0;i<n;i++){const a=tail+(head-tail)*i/n,b=tail+(head-tail)*(i+1)/n,v=(i+1)/n;c.strokeStyle=`rgba(${col},${v})`;c.lineWidth=w*(.25+.75*v);c.beginPath();c.arc(0,0,R-(1-v)*16,a,b);c.stroke()}}
 if(!wf){c.globalAlpha=fade;c.strokeStyle=core;c.lineWidth=big?5:3;c.beginPath();c.arc(0,0,R,Math.max(tail,head-.5),head);c.stroke()}
 if(big&&WA_Q>=1){c.globalAlpha=fade*.5;c.strokeStyle='#7fd8ff';c.lineWidth=8;c.beginPath();c.arc(0,0,R*.72,tail+.3,head+.2);c.stroke()}
 c.restore()}
function waDrawShield(c,t){const A=S.wa,h=A.hero;if(h.pose==='dead')return;if(h.bad>A.t){const u=(h.bad-A.t)/.6;c.save();c.globalAlpha=Math.min(1,u*1.6);const X=WAT.HX+168+Math.sin(t*70)*5*u,Y=WAT.FY-160;glowW(c,X,Y,150,'#ff6a3a55');waIcShield(c,X,Y,2.1,'#ffb090','#6a3a3a');c.strokeStyle='#ff5a3a';c.lineWidth=9;c.lineCap='round';c.beginPath();c.moveTo(X-28,Y-34);c.lineTo(X+28,Y+34);c.moveTo(X+28,Y-34);c.lineTo(X-28,Y+34);c.stroke();c.restore();return}const on=h.st==='guard',fade=h.st==='guard'?Math.min(1,(A.t-h.tg)/.05):h.st==='brec'?Math.max(0,1-(A.t-(h.until-A.br.rec))/.12):0;if(fade<=0)return;
 const X=WAT.HX+168,Y=WAT.FY-160,pr=h.ring;c.save();c.globalAlpha=fade;c.translate(X,Y);
 /* the blue ward behind the shield */
 const bub=.8+.2*Math.sin(t*14);glowW(c,0,0,190,on?`rgba(90,190,255,${.42*bub})`:'#5ac8ff22');c.strokeStyle=`rgba(150,225,255,${.9*fade})`;c.lineWidth=4;c.beginPath();c.ellipse(14,0,48+pr*6,118+pr*10,0,-1.3,1.3);c.stroke();c.strokeStyle=`rgba(255,255,255,${.5*fade})`;c.lineWidth=2;c.beginPath();c.ellipse(24,0,52+pr*8,124+pr*12,0,-1.2,1.2);c.stroke();
 c.scale(1.1+pr*.04,1.1+pr*.04);c.rotate(.06);
 c.beginPath();c.moveTo(-26,-70);c.quadraticCurveTo(30,-82,52,-48);c.quadraticCurveTo(58,20,22,72);c.quadraticCurveTo(-4,92,-30,74);c.quadraticCurveTo(-50,20,-26,-70);c.closePath();
 let q=c.createLinearGradient(-30,-70,50,70);q.addColorStop(0,'#cfd6e6');q.addColorStop(.5,'#8a97b4');q.addColorStop(1,'#56607e');c.fillStyle=q;c.fill();c.lineWidth=5;c.strokeStyle='#0a0620cc';c.stroke();c.lineWidth=3;c.strokeStyle='#e8c24a';c.stroke();
 c.save();c.clip();c.fillStyle='#ffffff30';c.beginPath();c.moveTo(-20,-70);c.lineTo(6,-72);c.lineTo(-18,76);c.lineTo(-40,70);c.closePath();c.fill();c.restore();
 c.fillStyle='#1c3a8a';c.beginPath();c.moveTo(-14,-34);c.quadraticCurveTo(22,-42,34,-24);c.quadraticCurveTo(34,14,12,44);c.quadraticCurveTo(-4,56,-16,46);c.quadraticCurveTo(-24,6,-14,-34);c.closePath();c.fill();c.strokeStyle='#e8c24a';c.lineWidth=2.6;c.stroke();
 c.fillStyle='#ffe27a';c.beginPath();c.moveTo(4,-26);c.lineTo(10,-8);c.lineTo(26,-8);c.lineTo(14,3);c.lineTo(19,20);c.lineTo(4,10);c.lineTo(-11,20);c.lineTo(-6,3);c.lineTo(-18,-8);c.lineTo(-2,-8);c.closePath();c.fill();
 c.restore()}
function waDrawEn(c,e,t){if(e.st==='gone')return;const A=S.wa,M=MON[e.id],sc=waSc(e),q=e.st==='wait',s2=q?.84:1,fy=M.fly?-48+Math.sin(t*2.2+e.ph)*9:0;if(e.al<=.01)return;
 const x=e.x+e.lx+e.kb*16,y=e.y+(q?-4:0);
 c.save();c.globalAlpha=e.al*(q?.9:1);
 if(e.st!=='dead'){c.fillStyle=`rgba(0,0,0,${.4*Math.min(1,e.al)})`;c.beginPath();c.ellipse(x-e.lx*.5,y+8,e.h0*s2*(M.fly?.2:.32),9,0,0,TAU);c.fill()}
 const exp=e.st==='exp';
 if(exp){const p=.6+.4*Math.sin(t*10);glowW(c,x,y-e.h0*.5+fy,e.h0*.95,`rgba(255,210,70,${.5*p})`)}
 else if(WAE[e.id].boss&&e.st!=='dead'){const D=WAE[e.id],holdL=(e.id==='gCent'||e.id==='gMino')&&e.st==='tele'&&e.hit&&e.hit.t>=e.hit.r&&e.hit.t<e.hit.r+e.hit.h,pu=.7+.3*Math.sin(t*(holdL?9:4));glowW(c,x,y-e.h0*.5,e.h0*(holdL?1.15:.9)*(1+e.pulse*.35),(e.phs>=3?D.col2:D.col)+(holdL?'66':e.phs>=3?'66':e.phs===2?'4a':'33'));if(holdL&&WA_Q>=1){c.save();c.strokeStyle=D.col+'bb';c.lineWidth=3;c.setLineDash([10,12]);c.lineDashOffset=-t*50;c.beginPath();c.ellipse(x,y+4,e.h0*.5*pu,e.h0*.09,0,0,TAU);c.stroke();c.restore()}}
 else if(!q&&e.st!=='dead'&&WA_Q>=2)glowW(c,x,y-e.h0*.5+fy,e.h0*.8,'#ff4a4a22');
 /* painted gladiators are cached as sprites when they wait in line, or whenever the machine is struggling */
  /* a recovery blends straight back to guard only when it starts from a finished strike, so the pose never jumps */
 if(e.st!=='rec')e._rv=null;else if(e._rv==null)e._rv=e.lg>=.6?Math.round(e.lg*20)/20:0;const RV=e._rv||0;
 if(M.gl&&e.fl<=0&&e.st!=='roar'&&(q||A.q<2)){const rv=RV&&e.lg>.02,spr=waGlSpr(e.id,sc*s2,(q?'q':'')+(rv?'r'+RV:''),e.st==='tele'||e.st==='exp'||e.st==='stun'||e.st==='dead'||e.st==='enter'||rv?e.lg:0,t+e.ph*3);if(spr){c.translate(x,y+fy);c.rotate(e.rot);c.drawImage(spr.c,spr.x0,spr.y0,spr.w,spr.h);c.restore();return}}
 const tint=e.fl>0?'rgba(255,255,255,.78)':e.st==='roar'?`rgba(255,70,40,${(.2+.12*Math.sin(t*30)).toFixed(3)})`:exp?`rgba(255,220,90,${(.16+.08*Math.sin(t*10)).toFixed(3)})`:q?'rgba(12,8,34,.34)':null;
 if(!tint){c.translate(x,y+fy);c.rotate(e.rot);c.scale(sc*s2,sc*s2);try{M.d(c,t+e.ph*3,{lg:e.lg,el:false,rv:RV})}catch(er){}c.restore();return}
 /* tints are painted over an off-screen copy (source-atop), which is far cheaper than canvas filters */
 const S2=waSpr(),g=S2.getContext('2d'),ox=S2.width/2,oy=S2.height-110;g.setTransform(1,0,0,1,0,0);g.globalCompositeOperation='source-over';g.clearRect(0,0,S2.width,S2.height);g.save();g.translate(ox,oy);g.rotate(e.rot);g.scale(sc*s2,sc*s2);try{M.d(g,t+e.ph*3,{lg:e.lg,el:false,rv:RV})}catch(er){}g.restore();
 g.globalCompositeOperation='source-atop';g.fillStyle=tint;g.fillRect(0,0,S2.width,S2.height);g.globalCompositeOperation='source-over';
 c.drawImage(S2,x-ox,y+fy-oy);c.restore()}
/* gladiator sprite cache: one bitmap per fighter, pose (lg in steps of .05) and idle frame. Bounded so memory stays small. */
const WA_GB={},WA_GS=new Map();
function waGlBox(id){if(WA_GB[id])return WA_GB[id];if(typeof GLAD_BB!=='undefined'&&GLAD_BB[id]){const q=GLAD_BB[id];return WA_GB[id]={x0:q[0]-4,y0:q[1]-4,x1:q[2]+4,y1:q[3]+4}}const M=MON[id],c=document.createElement('canvas');c.width=900;c.height=800;const g=c.getContext('2d',{willReadFrequently:true});let x0=900,x1=0,y0=800,y1=0;
 for(const lg of[-.4,0,.3,.55,.8,1,1.1])for(const t of[0,1.3,2.6]){g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,900,800);g.translate(560,740);g.scale(2,2);try{M.d(g,t,{lg})}catch(e){}const d=g.getImageData(0,0,900,800).data;for(let y=0;y<800;y+=3)for(let x=0;x<900;x+=3){if(d[(y*900+x)*4+3]>8){if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y}}}
 return WA_GB[id]={x0:(x0-560)/2-8,y0:(y0-740)/2-8,x1:(x1-560)/2+8,y1:(y1-740)/2+8}}
function waGlSpr(id,S0,tint,lg,t){const b=waGlBox(id),lq=Math.round(Math.max(-.4,Math.min(1.1,lg))*20)/20,fr=Math.abs(lq)<.001?((Math.floor(t/(TAU/2.4)*6)%6)+6)%6:0,key=id+'|'+lq+'|'+fr+'|'+tint+'|'+S0.toFixed(3);let o=WA_GS.get(key);
 if(o){WA_GS.delete(key);WA_GS.set(key,o);return o}
 const w=Math.ceil((b.x1-b.x0)*S0),h=Math.ceil((b.y1-b.y0)*S0);if(w<2||h<2||w>2400||h>2400)return null;const c=document.createElement('canvas');c.width=w;c.height=h;const g=c.getContext('2d');g.translate(-b.x0*S0,-b.y0*S0);g.scale(S0,S0);try{MON[id].d(g,fr*(TAU/2.4)/6,{lg:lq,rv:tint.indexOf('r')>=0?+tint.slice(tint.indexOf('r')+1):0})}catch(e){}
 if(tint[0]==='q'){g.setTransform(1,0,0,1,0,0);g.globalCompositeOperation='source-atop';g.fillStyle='rgba(12,8,34,.34)';g.fillRect(0,0,w,h)}
 o={c,x0:b.x0*S0,y0:b.y0*S0,w,h};WA_GS.set(key,o);while(WA_GS.size>40){WA_GS.delete(WA_GS.keys().next().value)}return o}
/* Panels, plates and icons never change from frame to frame, so each is painted once into a small bitmap and then simply stamped.
   (Keys include the render scale and whether the web fonts have arrived, so nothing is ever baked in the wrong font or blurry.) */
const WA_C={};
let WA_FR=0,WA_FT=0;
function waFontOK(){if(WA_FR)return 1;const n=performance.now();if(n-WA_FT>400){WA_FT=n;try{WA_FR=document.fonts&&document.fonts.check('20px "Pirata One"')?1:0}catch(e){WA_FR=1}}return WA_FR}
function waSprite(key,w,h,pad,fn){const k=key+'@'+RS+'f'+waFontOK();let o=WA_C[k];
 if(!o){const cv2=document.createElement('canvas');cv2.width=Math.ceil((w+pad*2)*RS);cv2.height=Math.ceil((h+pad*2)*RS);const g=cv2.getContext('2d');g.scale(RS,RS);g.translate(pad,pad);try{fn(g)}catch(e){}o=WA_C[k]={c:cv2,w:w+pad*2,h:h+pad*2,pad};const ks=Object.keys(WA_C);if(ks.length>60)delete WA_C[ks[0]]}
 return o}
function waStamp(c,o,x,y,sc){sc=sc||1;c.drawImage(o.c,x-o.pad*sc,y-o.pad*sc,o.w*sc,o.h*sc)}
function waSpr(){if(!waSpr.c){waSpr.c=document.createElement('canvas');waSpr.c.width=760;waSpr.c.height=620}return waSpr.c}
/* the sweep of the monster's weapon, so the blow reads as a blow */
function waDrawSwing(c,e,t){if(!e.hit||e.st!=='tele')return;if(e.hit.fk&&e.hit.done)return;const H=e.hit,u=(H.t-H.r-H.h)/H.s;if(u<=0&&!H.done&&!H.pend)return;const k=Math.min(1,Math.max(0,u)),a=H.done||H.pend?Math.max(0,1-(S.wa.t-(H.tc||S.wa.t))*5):1;if(a<=0)return;
 const D=WAE[e.id],sc=waSc(e),ex=WAT.SX+6,ey=WAT.SY+10;
 if(D.rng){/* the arrow itself is the telegraph: it flies from the bow to the shield and lands exactly on the beat */
  if(H.done||H.pend)return;const sx=e.x+e.lx-64,sy=e.y-e.h0*.62,px=sx+(ex+8-sx)*k,py=sy+(ey-sy)*k,ang=Math.atan2(ey-sy,ex-sx);
  c.save();c.globalAlpha=Math.min(1,k*6);const tr=c.createLinearGradient(px,py,sx,sy);tr.addColorStop(0,'#dff4ffcc');tr.addColorStop(1,'#dff4ff00');c.strokeStyle=tr;c.lineWidth=7;c.lineCap='round';c.beginPath();c.moveTo(px,py);c.lineTo(sx+(px-sx)*.1,sy+(py-sy)*.1);c.stroke();waArrow(c,px,py,ang,'#e8f4ff');c.restore();return}
 const sx=e.x+e.lx-30,sy=e.y-e.h0*.92,fc=H.fk?'#c88aff':(D.fx&&D.fx[0])||'#ffb24a';c.save();c.globalAlpha=Math.min(1,k*1.5)*a;
 const g=c.createLinearGradient(sx,sy,ex,ey);g.addColorStop(0,fc+'00');g.addColorStop(.6,fc+'cc');g.addColorStop(1,'#fff2c0');c.strokeStyle=g;c.lineCap='round';
 for(const [w,al,off] of[[26,.28,0],[14,.7,6],[5,1,12]]){if(WA_Q<1&&al<1)continue;c.globalAlpha=Math.min(1,k*1.5)*a*al;c.lineWidth=w*(.4+.6*k);c.beginPath();c.moveTo(sx,sy-30+off*0);c.bezierCurveTo(sx-(sx-ex)*.2,sy-100-off,sx-(sx-ex)*.65,sy+10-off*2,ex+10,ey+off);c.stroke()}c.restore()}
/* an arrow, drawn pointing along ang with its tip at (x,y) */
function waArrow(c,x,y,ang,col){c.save();c.translate(x,y);c.rotate(ang);c.lineJoin='round';c.lineCap='round';c.strokeStyle='#0a0620';c.lineWidth=7;c.beginPath();c.moveTo(-64,0);c.lineTo(0,0);c.stroke();c.strokeStyle=col||'#e8f4ff';c.lineWidth=3.4;c.beginPath();c.moveTo(-64,0);c.lineTo(0,0);c.stroke();
 c.fillStyle='#0a0620';c.beginPath();c.moveTo(10,0);c.lineTo(-12,-9);c.lineTo(-8,0);c.lineTo(-12,9);c.closePath();c.fill();c.fillStyle='#bfeaff';c.beginPath();c.moveTo(7,0);c.lineTo(-9,-6);c.lineTo(-6,0);c.lineTo(-9,6);c.closePath();c.fill();
 c.fillStyle='#8fc8ff';for(const dy of[-1,1]){c.beginPath();c.moveTo(-64,0);c.lineTo(-76,dy*9);c.lineTo(-52,dy*2);c.closePath();c.fill();c.stroke()}c.restore()}
function waDrawCue(c,e,t){const A=S.wa;if(e.st!=='tele'||!e.hit||e.hit.done&&!e.hit.pend)return;const H=e.hit,vd=waVd(H),lo=waPW(),fk=!!H.fk,inP=!fk&&vd>=lo.lo&&vd<=lo.hi;
 /* the shrinking ring: it closes on the shield at the moment of impact */
 const sx=WAT.SX+20,sy=WAT.SY,r=26+Math.min(1,vd/.9)*120;c.save();c.globalAlpha=Math.min(1,H.t/.15)*(H.pend?0:1);
 c.lineWidth=inP?8:4;c.strokeStyle=fk?'#c88affcc':inP?'#ffd24a':'#ffffffcc';c.setLineDash(inP?[]:[10,8]);c.lineDashOffset=-t*30;c.beginPath();c.arc(sx,sy,r,0,TAU);c.stroke();c.setLineDash([]);
 if(inP){for(let i=0;i<4;i++){const a=i*TAU/4+Math.PI/4;c.beginPath();c.moveTo(sx+Math.cos(a)*(r-10),sy+Math.sin(a)*(r-10));c.lineTo(sx+Math.cos(a)*(r+10),sy+Math.sin(a)*(r+10));c.stroke()}}
 c.restore();
 if(WAE[e.id].rng&&!H.pend){const bx=e.x+e.lx-64,by=e.y-e.h0*.62;c.save();c.globalAlpha=Math.min(1,H.t/.2)*.75;c.strokeStyle=inP?'#ffd24a':'#bfeaff';c.lineWidth=3;c.setLineDash([4,14]);c.lineCap='round';c.lineDashOffset=-t*120;c.beginPath();c.moveTo(bx,by);c.lineTo(sx,sy);c.stroke();c.restore()}
 /* the alert above the enemy and the combo pips */
 const [ax,ay]=waCueP(e,58),n=e.pat.length,hold=H.t>=H.r&&H.t<H.r+H.h,pul=.5+.5*Math.sin(t*(hold?6:16));
 c.save();c.translate(ax,ay);const sc2=1+pul*.08;c.scale(sc2,sc2);c.fillStyle=fk?'#1c0a2aee':'#2a0a0aee';c.strokeStyle=fk?'#c88aff':inP?'#ffd24a':'#ff5a4a';c.lineWidth=4;c.beginPath();c.arc(0,0,22,0,TAU);c.fill();c.stroke();
 if(hold){c.fillStyle='#e8e0ff';for(let i=0;i<3;i++){c.beginPath();c.arc(-9+i*9,2,2.8+(Math.floor(t*5)%3===i?1.4:0),0,TAU);c.fill()}}
 else if(fk){c.font='700 30px '+WA_P;c.textAlign='center';c.textBaseline='middle';c.fillStyle='#d8b0ff';c.fillText('?',0,2)}else{c.fillStyle=inP?'#ffd24a':'#ff6a5a';c.fillRect(-3.5,-12,7,15);c.beginPath();c.arc(0,10,4,0,TAU);c.fill()}c.restore();
 if(fk&&!hold){waOutText(c,'FEINT?',ax,ay-34-(n>1?28:0),24,'#d8b0ff')}
 if(n>1){c.save();const pw=26,sx0=ax-(n-1)*pw/2,py=ay-38;for(let i=0;i<n;i++){const cur=i===e.pi,dn=i<e.pi;c.beginPath();c.arc(sx0+i*pw,py,10,0,TAU);c.fillStyle=dn?'#5a6a9a':cur?(e.pat[i].fk?'#b47aff':'#ffd24a'):'#2a2258';c.fill();c.lineWidth=2.4;c.strokeStyle=cur?'#fff3c0':'#8a80c8';c.stroke();c.fillStyle=cur?'#2a1608':'#e8e4ff';c.font='700 13px '+WA_P;c.textAlign='center';c.textBaseline='middle';c.fillText(String(i+1),sx0+i*pw,py+1)}c.restore()}}
function waDrawExp(c,e,t){if(e.st!=='exp')return;const A=S.wa,[ax,ay]=waCueP(e,72),p=.5+.5*Math.sin(t*9),f=Math.min(1,e.ex/e.exMax);
 c.save();c.translate(ax,ay);c.scale(1+p*.07,1+p*.07);c.fillStyle='#3a1a08f2';c.strokeStyle='#ffb02a';c.lineWidth=4;c.beginPath();c.arc(0,0,26,0,TAU);c.fill();c.stroke();c.fillStyle='#ffd24a';c.fillRect(-4,-14,8,18);c.beginPath();c.arc(0,12,4.6,0,TAU);c.fill();
 c.fillStyle='#ff9a1a';c.beginPath();c.moveTo(-9,34);c.lineTo(9,34);c.lineTo(0,46);c.closePath();c.fill();c.restore();
 waOutText(c,'EXPOSED!',ax,ay-44,26,'#ffd24a');
 if(e.guardUp){c.save();c.translate(ax+50,ay+2);waIcShield(c,0,0,.7,'#fff3c0','#b8202e');c.restore();waOutText(c,'GUARD UP: strike twice',ax,ay+58,20,'#ffd86a')}
 /* time left: a bar that drains, plus the dizzy stars */
 c.save();c.fillStyle='#0008';c.beginPath();c.roundRect(ax-40,ay-70,80,8,4);c.fill();c.fillStyle="#ffd24a";c.beginPath();c.roundRect(ax-40,ay-70,80*f,8,4);c.fill();c.restore();
 for(let i=0;i<3;i++){const a=t*3+i*TAU/3,sx=e.x+e.lx+Math.cos(a)*44,sy=e.y-e.h0-6+Math.sin(a)*10;c.fillStyle='#ffe27a';c.beginPath();for(let k=0;k<10;k++){const r=k%2?3:7,b=k*Math.PI/5-Math.PI/2;c.lineTo(sx+Math.cos(b)*r,sy+Math.sin(b)*r)}c.closePath();c.fill()}}
function waHead(e){return e.y-e.h0-(MON[e.id].fly?54:0)}
/* where the alert sits: above the head, or in front of the face for giants whose heads reach the HUD */
function waCueP(e,up){const y=waHead(e)-up;return y<250?[e.x+e.lx*.4-e.h0*.32,Math.max(250,e.y-e.h0*.72)]:[e.x+e.lx*.4,y]}
function waDrawPips(c,e,t){if(e.st==='dead'||e.st==='gone'||e.st==='wait'||e.st==='enter'||WAE[e.id].boss)return;waPipRow(c,e,e.x+e.lx*.5,waHead(e)-18)}
function waPipRow(c,e,x,y){const mx=e.mh;c.save();if(mx>12){const w=150;c.fillStyle='#0b0718e8';c.strokeStyle='#e8c24a';c.lineWidth=2;c.beginPath();c.roundRect(x-w/2,y-8,w,16,6);c.fill();c.stroke();const q=c.createLinearGradient(x-w/2,0,x+w/2,0);q.addColorStop(0,'#ff4466');q.addColorStop(1,'#ff9a5a');c.fillStyle=q;c.beginPath();c.roundRect(x-w/2+3,y-5,Math.max(0,(w-6)*e.hp/mx),10,4);c.fill()}
 else{const pw=11,gap=3,tot=mx*(pw+gap)-gap;for(let i=0;i<mx;i++){const on=i<e.hp;c.fillStyle=on?'#ff5a6a':'#2a1630';c.strokeStyle=on?'#5a0a1a':'#5a3a52';c.lineWidth=2;c.beginPath();c.roundRect(x-tot/2+i*(pw+gap),y-6,pw,12,3);c.fill();c.stroke()}}c.restore()}
/* ---------- effects ---------- */
function waDrawFx(c,t){const A=S.wa;for(const p of A.fx){const u=p.l/p.m;c.save();
 if(p.k==='ripple'){const g=1-u,r=p.r*(1+(p.big?4.2:3)*g);c.globalAlpha=u*.9;c.strokeStyle=p.c;c.lineWidth=(p.big?7:4)*u+1;c.beginPath();if(p.flat)c.ellipse(p.x,p.y,r*2.6,r*.34,0,0,TAU);else c.ellipse(p.x,p.y,r*(p.big?.55:1),r*(p.big?1.2:1),0,0,TAU);c.stroke();if(p.big&&WA_Q>=1){c.globalAlpha=u*.45;c.lineWidth=2;c.beginPath();c.ellipse(p.x,p.y,r*.7,r*1.5,0,0,TAU);c.stroke()}}
 else if(p.k==='arrow'){c.globalAlpha=Math.min(1,u*3);waArrow(c,p.x,p.y,Math.atan2(p.vy,p.vx),p.c)}
 else if(p.k==='slash'){const g=1-u,R=p.r*(.8+.35*g),a0=-1.25+p.rot,sw=Math.min(1,g*2.6),a1=a0+2.5*sw;c.globalAlpha=Math.min(1,u*2.4);c.translate(p.x,p.y);c.lineCap='round';c.strokeStyle='#ffe9a8';c.lineWidth=(p.big?26:18)*u;c.beginPath();c.arc(-R*.55,0,R,a0,a1);c.stroke();c.strokeStyle='#ffffff';c.lineWidth=(p.big?10:6)*u;c.beginPath();c.arc(-R*.55,0,R,a0+.15,a1);c.stroke()}
 else if(p.k==='wave'){if(WA_Q<1){c.restore();continue}const g=1-u;c.globalAlpha=u*.8;const q=c.createRadialGradient(p.x||WAT.HX+120,WAT.FY-150,10,WAT.HX+120,WAT.FY-150,100+g*900);q.addColorStop(0,'#fff0');q.addColorStop(.8,'#ffffffaa');q.addColorStop(1,'#fff0');c.fillStyle=q;c.fillRect(0,0,W,H)}
 else if(p.k==='spark'){c.globalAlpha=Math.min(1,u*2);c.strokeStyle=p.c;c.lineWidth=p.s*.7;c.lineCap='round';c.beginPath();c.moveTo(p.x,p.y);c.lineTo(p.x-p.vx*.04,p.y-p.vy*.04);c.stroke()}
 else if(p.k==='coin'){c.globalAlpha=Math.min(1,u*3);const w=Math.abs(Math.cos(t*10+p.x));c.fillStyle='#ffd24a';c.strokeStyle='#8a5a10';c.lineWidth=2;c.beginPath();c.ellipse(p.x,p.y,6*Math.max(.25,w),6,0,0,TAU);c.fill();c.stroke()}
 else if(p.k==='conf'){c.globalAlpha=Math.min(1,u*2);c.translate(p.x,p.y);c.rotate(p.x*.05+t*3);c.fillStyle=p.c;c.fillRect(-p.s/2,-p.s/4,p.s,p.s/2)}
 else{c.globalAlpha=Math.min(1,u*1.6);c.fillStyle=p.c;c.beginPath();c.arc(p.x,p.y,p.s*(.4+.6*u),0,TAU);c.fill()}c.restore()}
 for(const q of A.tx){const u=q.t/q.m,pop=1+q.pop*.5;c.save();c.globalAlpha=Math.min(1,u*2.2);c.translate(q.x,q.y);c.scale(pop,pop);waOutText(c,q.txt,0,0,q.sz,q.c,{rot:q.rot});c.restore()}}
/* ---------- HUD ---------- */
function waDrawHUD(c,t){const A=S.wa;
 /* hearts */
 {const sp=A.max>4?58:A.max>3?66:78,hs=A.max>4?1.25:A.max>3?1.42:1.62;const pw=sp*A.max+30;waStamp(c,waSprite('hpl'+A.max,pw,70,8,g=>waPlate(g,0,0,pw,70)),24,20);const hF=waSprite('heartF',64,64,0,g=>{g.translate(32,32);waHeart(g,0,0,1,true,0)}),hE=waSprite('heartE',64,64,0,g=>{g.translate(32,32);waHeart(g,0,0,1,false,0)});for(let i=0;i<A.max;i++){const full=i<A.hp,pop=(A.hurtFl>0&&i===A.hp)?1+A.hurtFl*.4:1,k=hs*pop,hx=24+15+sp/2+i*sp;waStamp(c,full?hF:hE,hx-32*k,56-32*k,k)}}
 /* shieldburst pips */
 {const y=112;c.save();for(let i=0;i<WA_BURST_N;i++){const on=A.charged||i<A.streak;c.globalAlpha=on?1:.9;{const c1=on?(A.charged?'#fff3c0':'#bfeaff'):'#6a6a9a',c2=on?(A.charged?'#d8a53a':'#2a5ab8'):'#1a1636';waStamp(c,waSprite('shp'+c1+c2,48,64,0,g=>{g.translate(24,26);waIcShield(g,0,0,1,c1,c2)}),52+i*38-24*.56,y-26*.56,.56)}}
  c.restore();c.save();c.font='700 15px '+WA_G;c.fillStyle=A.charged?'#ffe27a':'#c8c4ec';c.textBaseline='middle';c.fillText(A.charged?'SHIELDBURST READY':'Shieldburst '+A.streak+'/'+WA_BURST_N,206,y+4);c.restore()
  if(A.charged){const p=.5+.5*Math.sin(t*8);c.save();c.strokeStyle=`rgba(255,226,122,${.4+.5*p})`;c.lineWidth=3;c.beginPath();c.roundRect(24,92,264,40,10);c.stroke();c.restore()}}
 /* streak call-out, tilted like the concept */
 if(A.streak>=2&&!A.charged){const pop=1+Math.max(0,A.streakPop||0)*.25;c.save();c.translate(205,300);c.rotate(-.2);c.scale(pop,pop);waOutText(c,A.streak+'-HIT STREAK!',0,0,44,'#ffd24a',{glow:'#ffb02a'});c.strokeStyle='#5ac8ff';c.lineWidth=5;c.beginPath();c.moveTo(-120,28);c.lineTo(110,12);c.stroke();c.restore()}
 /* title banner */
 waStamp(c,waSprite('title',620,100,10,g=>{g.translate(310,0);for(const sd of[-1,1]){g.save();g.translate(sd*268,6);g.fillStyle='#8a1424';g.strokeStyle='#e8c24a';g.lineWidth=3;g.beginPath();g.moveTo(-24,0);g.lineTo(24,0);g.lineTo(24,78);g.lineTo(0,92);g.lineTo(-24,78);g.closePath();g.fill();g.stroke();g.fillStyle='#f0c24a';g.beginPath();g.moveTo(0,22);g.lineTo(9,38);g.lineTo(0,54);g.lineTo(-9,38);g.closePath();g.fill();g.restore()}
  waPlate(g,-262,12,524,86,'#e8c24a');g.strokeStyle='#e8c24a';g.lineWidth=5;g.beginPath();g.moveTo(-18,10);g.lineTo(18,-4);g.moveTo(18,10);g.lineTo(-18,-4);g.stroke();
  waOutText(g,"WARDEN'S ARENA",0,56,60,'#ffd24a',{stroke:'#2a1204'})}),W/2-310,0);
 /* wave and coins */
 const wt=A.boss?'Boss Duel':'Wave '+A.wave+' / '+WAT.MAXW;waStamp(c,waSprite('wv'+wt,196,62,8,g=>{waPlate(g,0,0,196,62);waOutText(g,wt,98,31,30,'#fff',{stroke:'#0a0620'})}),1080,22);
 const cp=A.coinPop>0?1+A.coinPop*.4:1;waStamp(c,waSprite('cpl',286,62,8,g=>waPlate(g,0,0,286,62)),1290,22);c.save();c.translate(1332,53);c.scale(cp,cp);c.fillStyle='#ffc94a';c.strokeStyle='#7a4a08';c.lineWidth=3;c.beginPath();c.arc(0,0,19,0,TAU);c.fill();c.stroke();c.strokeStyle='#fff3b0';c.lineWidth=2.4;c.beginPath();c.arc(0,0,12,0,TAU);c.stroke();c.fillStyle='#b8801a';c.fillRect(-2,-8,4,16);c.restore();
 c.save();c.font='30px '+WA_F;c.fillStyle='#fff';c.textBaseline='middle';c.textAlign='left';c.fillText('Run Coins: '+Math.round(A.coinShow),1362,56);c.restore();
 if(A.boss&&A.cur&&WAE[A.cur.id].boss&&A.cur.st!=='dead'){const e=A.cur,D=WAE[e.id],w=560,x=W/2-w/2,y=118,f=Math.max(0,e.hp/e.mh);c.save();c.fillStyle='#0b0718ee';c.strokeStyle='#e8c24a';c.lineWidth=3;c.beginPath();c.roundRect(x,y,w,22,9);c.fill();c.stroke();const q=c.createLinearGradient(x,0,x+w,0);q.addColorStop(0,e.phs>=3?D.col2:D.col);q.addColorStop(1,'#ffb86a');c.fillStyle=q;c.beginPath();c.roundRect(x+4,y+4,Math.max(0,(w-8)*f),14,6);c.fill();
  c.strokeStyle='#0b0718';c.lineWidth=3;for(const m of[.33,.66]){c.beginPath();c.moveTo(x+4+(w-8)*m,y+3);c.lineTo(x+4+(w-8)*m,y+19);c.stroke()}c.restore();
  const ph=e.phs>=3?'  ·  FURY':e.phs===2?'  ·  ENRAGED':'';waOutText(c,D.n+ph,W/2,y+40,24,e.phs>=2?D.col:'#ffe2a8')}
 /* coaching tip */
 if(A.tip){const a=Math.min(1,A.tip.t*2,(5-A.tip.t+.01)*3);c.save();c.globalAlpha=Math.min(1,A.tip.t*2);c.font='22px '+WA_G;const tw=c.measureText(A.tip.txt).width+56;c.fillStyle='#0b0820ee';c.strokeStyle='#9fd8ff';c.lineWidth=2.4;c.beginPath();c.roundRect(W/2-tw/2,180,tw,48,24);c.fill();c.stroke();c.fillStyle='#e8f6ff';c.textAlign='center';c.textBaseline='middle';c.fillText(A.tip.txt,W/2,205);c.restore()}}
function waDrawBar(c,t){const A=S.wa,e=A.cur,BX=330,BW=940,BY=622,BH=44,lo=waPW(),x=v=>BX+BW*waBarX(v);
 c.save();/* frame */
 c.fillStyle='#1a1240';c.strokeStyle='#e8c24a';c.lineWidth=4;c.beginPath();c.roundRect(BX-22,BY-14,BW+44,BH+28,14);c.fill();c.stroke();
 for(const sd of[-1,1]){const cx=sd<0?BX-22:BX+BW+22;c.fillStyle='#e8c24a';c.beginPath();c.moveTo(cx,BY+BH/2-20);c.lineTo(cx+sd*24,BY+BH/2);c.lineTo(cx,BY+BH/2+20);c.lineTo(cx+sd*8,BY+BH/2);c.closePath();c.fill()}
 c.fillStyle='#07041a';c.beginPath();c.roundRect(BX,BY,BW,BH,8);c.fill();
 /* zones: good, perfect, good */
 c.save();c.beginPath();c.roundRect(BX,BY,BW,BH,8);c.clip();
 const GD=A.br.gd;
 /* too early: a hatched zone, so the bar itself says "not yet" */
 c.fillStyle='#3a1a1a';c.fillRect(BX,BY+3,x(GD)-BX,BH-6);c.save();c.beginPath();c.rect(BX,BY+3,x(GD)-BX,BH-6);c.clip();c.strokeStyle='#ff8a5a40';c.lineWidth=5;for(let k=BX-60;k<x(GD)+60;k+=18){c.beginPath();c.moveTo(k,BY+BH);c.lineTo(k+40,BY);c.stroke()}c.restore();
 let q=c.createLinearGradient(0,BY,0,BY+BH);q.addColorStop(0,'#3ee0b0');q.addColorStop(1,'#1fa080');c.fillStyle=q;c.fillRect(x(GD),BY+3,x(-WAT.LATE)-x(GD),BH-6);
 q=c.createLinearGradient(0,BY,0,BY+BH);q.addColorStop(0,'#ffe27a');q.addColorStop(1,'#e0a41a');c.fillStyle=q;c.fillRect(x(lo.hi),BY+3,x(lo.lo)-x(lo.hi),BH-6);
 c.fillStyle='#ffffff22';c.fillRect(x(GD),BY+3,x(-WAT.LATE)-x(GD),8);
 /* the impact line */
 c.fillStyle='#ffffff';c.fillRect(x(0)-1.5,BY,3,BH);c.fillStyle='#07041a99';c.fillRect(x(-WAT.LATE),BY,BX+BW-x(-WAT.LATE),BH);c.restore();
 /* zone captions: icons plus text, so colour is never the only cue */
 c.font='700 14px '+WA_G;c.textAlign='center';c.textBaseline='middle';c.fillStyle='#07201a';c.fillText('GOOD',(x(GD)+x(lo.hi))/2,BY+BH/2+1);c.fillStyle='#ffb89a';c.fillText('TOO EARLY · WAIT',(BX+x(GD))/2,BY+BH/2+1);c.fillStyle='#07201a';c.fillStyle='#3a2204';c.fillText('PERFECT',(x(lo.hi)+x(lo.lo))/2,BY+BH/2+1);
 /* the marker */
 if(e&&e.st==='tele'&&e.hit&&!(e.hit.done&&!e.hit.pend)){const H=e.hit,vd=waVd(H),mx=x(vd),hold=H.t>=H.r&&H.t<H.r+H.h,al=Math.min(1,H.t/.12);c.globalAlpha=al*(hold?.6+.4*Math.sin(t*22):1);
  glowW(c,mx,BY+BH/2,50,H.fk?'#c88aff88':'#7fd8ff88');c.fillStyle=H.fk?'#d8b8ff':'#bfeaff';c.strokeStyle=H.fk?'#6a2ab8':'#2a7ac8';c.lineWidth=2;c.beginPath();c.roundRect(mx-3.5,BY-10,7,BH+20,3);c.fill();c.stroke();c.fillStyle='#fff';c.beginPath();c.moveTo(mx-9,BY-18);c.lineTo(mx+9,BY-18);c.lineTo(mx,BY-5);c.closePath();c.fill();
  if(hold){c.globalAlpha=1;waOutText(c,'...',mx,BY-34,32,'#e8e0ff')}else if(H.fk){c.globalAlpha=1;waOutText(c,'FEINT',mx,BY-32,24,'#d8b0ff')}c.globalAlpha=1}
 
 /* where your last press landed, so a mistimed block is never a mystery */
 {const m=A.mark;if(m&&m.vd!==null&&m.vd!==undefined&&A.t-m.t<1.6&&(m.k||A.t-m.t>.05)){const k=m.k||(m.vd>GD?'early':null);if(k){const mx=x(Math.max(-WAT.LATE,Math.min(WAT.BAR,m.vd))),al=Math.min(1,(1.6-(A.t-m.t))*2.5),col=k==='perfect'?'#ffd24a':k==='good'?'#3ee0b0':'#ff9a5a',lab=k==='perfect'?'PERFECT':k==='good'?(m.vd>lo.hi?'GOOD · EARLY':m.vd<lo.lo?'GOOD · LATE':'GOOD'):'TOO EARLY';
   c.globalAlpha=al;c.fillStyle=col;c.strokeStyle='#0a0620';c.lineWidth=3;c.beginPath();c.moveTo(mx,BY+BH+2);c.lineTo(mx-9,BY+BH+16);c.lineTo(mx+9,BY+BH+16);c.closePath();c.stroke();c.fill();waOutText(c,lab,Math.max(BX+70,Math.min(BX+BW-70,mx)),BY+BH+30,20,col,{});c.globalAlpha=1}}}
 c.restore()}
function waDrawPanel(c,t){const A=S.wa,h=A.hero,e=A.cur,X=52,Y=722,PW=1496,PH=128,mid=X+PW/2;
 const canStrike=A.charged||(e&&e.st==='exp'),busyB=h.st==='brec'||h.st==='stag',busyS=h.st==='whiff';
 const fightS=canStrike&&A.ph==='fight',subB=h.st==='guard'?'g':busyB?'r':'n',subS=A.charged?'c':canStrike?'e':busyS?'r':'n',key='pn'+[h.st==='guard'?1:0,busyB?1:0,busyS?1:0,canStrike?1:0,fightS?1:0,subB,subS].join('');
 waStamp(c,waSprite(key,PW,PH,8,c=>{c.translate(-X,-Y);
 c.save();let q=c.createLinearGradient(0,Y,0,Y+PH);q.addColorStop(0,'#241a52f4');q.addColorStop(1,'#110b2cf8');c.fillStyle=q;c.beginPath();c.roundRect(X,Y,PW,PH,16);c.fill();c.strokeStyle='#d8a53a';c.lineWidth=4;c.stroke();c.strokeStyle='#ffe9a033';c.lineWidth=1.4;c.beginPath();c.roundRect(X+7,Y+7,PW-14,PH-14,11);c.stroke();
 if(h.st==='guard'){c.fillStyle='#5ac8ff22';c.beginPath();c.roundRect(X+6,Y+6,PW/2-12,PH-12,12);c.fill()}
 /* divider */
 c.strokeStyle='#d8a53a';c.lineWidth=2;c.beginPath();c.moveTo(mid,Y+16);c.lineTo(mid,Y+PH-16);c.stroke();c.fillStyle='#f0c24a';c.beginPath();c.moveTo(mid,Y+PH/2-9);c.lineTo(mid+7,Y+PH/2);c.lineTo(mid,Y+PH/2+9);c.lineTo(mid-7,Y+PH/2);c.closePath();c.fill();
 const cy=Y+PH/2;
 /* block */
 c.save();if(busyB)c.globalAlpha=.55;c.fillStyle='#16103a';c.strokeStyle='#d8a53a';c.lineWidth=4;c.beginPath();c.arc(X+88,cy,46,0,TAU);c.fill();c.stroke();waIcShield(c,X+88,cy-3,1.15,'#fff3c0','#c9a43a');
 waKey(c,X+160,cy-24,128,48,'Space',h.st==='guard');c.fillStyle='#d8c8ff';c.font='34px '+WA_G;c.textAlign='center';c.textBaseline='middle';c.fillText('/',X+316,cy);
 c.strokeStyle='#8fb4ff';c.lineWidth=2.4;c.fillStyle='#1c1646';c.beginPath();c.roundRect(X+342,cy-34,70,68,10);c.fill();c.stroke();waIcHand(c,X+377,cy+3,.9);
 c.textAlign='left';c.fillStyle='#fff';c.font='54px '+WA_F;c.fillText('Block',X+440,cy-14);c.font='19px '+WA_G;c.fillStyle=h.st==='guard'?'#9fe0ff':busyB?'#ffb8a0':'#b8b4e0';c.fillText(h.st==='guard'?'Guarding…':busyB?'Recovering…':'Space / Tap • Block',X+442,cy+26);c.restore();
 /* strike */
 c.save();if(busyS)c.globalAlpha=.55;c.fillStyle='#16103a';c.strokeStyle=canStrike?'#fff3c0':'#d8a53a';c.lineWidth=4;c.beginPath();c.arc(mid+88,cy,46,0,TAU);c.fill();c.stroke();waIcSword(c,mid+88,cy,1.05,'#7a4a10');
 c.strokeStyle='#8fb4ff';c.lineWidth=2.4;c.fillStyle='#1c1646';c.beginPath();c.roundRect(mid+150,cy-34,56,68,10);c.fill();c.stroke();waIcMouse(c,mid+178,cy,1);
 c.fillStyle='#d8c8ff';c.font='34px '+WA_G;c.textAlign='center';c.textBaseline='middle';c.fillText('/',mid+230,cy);waKey(c,mid+254,cy-24,116,48,'Enter',canStrike&&A.ph==='fight');
 c.textAlign='left';c.fillStyle='#fff';c.font='54px '+WA_F;c.fillText('Strike',mid+400,cy-14);c.font='19px '+WA_G;c.fillStyle=A.charged?'#ffe27a':canStrike?'#ffd24a':busyS?'#ffb8a0':'#b8b4e0';c.fillText(A.charged?'SHIELDBURST ready!':canStrike?'EXPOSED! Strike now!':busyS?'Recovering…':'Click / Enter • Strike when exposed',mid+402,cy+26);c.restore();
 c.restore()}),X,Y);
 c.save();
 if(fightS){const p=.5+.5*Math.sin(t*9);c.fillStyle=`rgba(255,210,70,${.1+.14*p})`;c.beginPath();c.roundRect(mid+6,Y+6,PW/2-12,PH-12,12);c.fill();c.strokeStyle=`rgba(255,226,122,${.5+.5*p})`;c.lineWidth=4;c.beginPath();c.roundRect(mid+6,Y+6,PW/2-12,PH-12,12);c.stroke()}
 if(h.st==='brec'){const u=1-(h.until-A.t)/A.br.rec;c.fillStyle='#ffffff22';c.fillRect(X+30,Y+PH-14,PW/2-60,5);c.fillStyle='#9fb8ff';c.fillRect(X+30,Y+PH-14,(PW/2-60)*Math.max(0,Math.min(1,u)),5)}
 if(h.st==='whiff'){const u=1-(h.until-A.t)/WAT.WREC;c.fillStyle='#ffffff22';c.fillRect(mid+30,Y+PH-14,PW/2-60,5);c.fillStyle='#ff9a7a';c.fillRect(mid+30,Y+PH-14,(PW/2-60)*Math.max(0,Math.min(1,u)),5)}
 c.restore()}
/* The hero tells you what to do right now: WAIT, then BLOCK, then NOW, and STRIKE when the foe is exposed. Icon + word + key, never colour alone. */
function waCoachState(){const A=S.wa,e=A.cur,h=A.hero;if(A.ph!=='fight'||!e||h.st==='stag'||h.st==='dead'||e.st==='dead'||e.st==='gone'||A.pause)return null;
 if(e.st==='exp')return{k:'strike',w:'STRIKE!',sub:waKs2(),col:'#ff9a3a'};
 const busy=h.st==='brec'||h.st==='stag'||h.st==='whiff';
 if(e.st==='tele'&&e.hit&&!(e.hit.done&&!e.hit.pend)){const H=e.hit,vd=waVd(H),lo=waPW(),hold=H.t>=H.r&&H.t<H.r+H.h;
  if(busy)return{k:'rec',w:'RECOVERING',sub:'shield is back soon',col:'#c8a090'};
  if(H.fk)return{k:'feint',w:'FEINT! HOLD',sub:'do not block',col:'#c88aff'};
  if(H.pend||(!hold&&vd>=lo.lo&&vd<=lo.hi))return{k:'now',w:'NOW!',sub:waKb2(),col:'#ffd24a'};
  if(!hold&&vd<A.br.gd)return{k:'block',w:'BLOCK!',sub:waKb2(),col:'#5ac8ff'};
  return{k:'wait',w:'WAIT…',sub:hold?'the blow is delayed':'not yet',col:'#b8b4e8'}}
 if(A.charged&&e.st==='stun')return{k:'strike',w:'STRIKE!',sub:waKs2(),col:'#ff9a3a'};
 if(busy)return{k:'rec',w:'RECOVERING',sub:'',col:'#c8a090'};
 return{k:'watch',w:'WATCH',sub:'next attack…',col:'#8a86b8'}}
const waKb2=()=>{try{return TM()?'TAP BLOCK':'SPACE'}catch(e){return 'SPACE'}},waKs2=()=>{try{return TM()?'TAP STRIKE':'ENTER'}catch(e){return 'ENTER'}};
function waDrawCoach(c,t){const A=S.wa,st=waCoachState();if(!st){A.coachK=null;return}if(A.coachK!==st.k){A.coachK=st.k;A.coachT=A.t}
 const age=Math.min(1,(A.t-(A.coachT||0))/.14),pop=1+(1-age)*.22*(st.k==='watch'||st.k==='rec'?0:1),pul=.5+.5*Math.sin(t*(st.k==='now'?18:st.k==='strike'?10:6)),X=WAT.HX+8,Y=268,w=270,h=70,dim=st.k==='watch'||st.k==='rec'?.62:1;
 c.save();c.globalAlpha=dim;c.translate(X,Y);c.scale(pop,pop);
 if(st.k==='now'||st.k==='strike')glowW(c,0,0,170,st.col+(st.k==='now'?'66':'55'));
 c.fillStyle='#0d0824ee';c.strokeStyle=st.col;c.lineWidth=st.k==='now'||st.k==='strike'?6:4;c.beginPath();c.roundRect(-w/2,-h/2,w,h,18);c.fill();c.stroke();
 c.fillStyle='#0d0824ee';c.strokeStyle=st.col;c.beginPath();c.moveTo(-14,h/2-1);c.lineTo(0,h/2+16);c.lineTo(14,h/2-1);c.closePath();c.fill();c.stroke();c.fillStyle='#0d0824';c.fillRect(-12,h/2-5,24,6);
 /* icon */
 c.save();c.translate(-w/2+44,0);
 if(st.k==='strike'){waIcSword(c,0,2,1.05,'#7a4a10')}
 else if(st.k==='wait'||st.k==='watch'||st.k==='rec'||st.k==='feint'){c.strokeStyle=st.col;c.lineWidth=4;c.lineJoin='round';c.beginPath();c.moveTo(-14,-20);c.lineTo(14,-20);c.lineTo(-14,20);c.lineTo(14,20);c.closePath();c.stroke();c.fillStyle=st.col;c.globalAlpha=dim*.8;c.beginPath();c.moveTo(-8,-14);c.lineTo(8,-14);c.lineTo(0,-3);c.closePath();c.fill();c.beginPath();c.moveTo(-10,17);c.lineTo(10,17);c.lineTo(0,5);c.closePath();c.fill()}
 else{waIcShield(c,0,-1,1.05,'#fff3c0',st.k==='now'?'#d8a53a':'#2a5ab8')}
 c.restore();
 waOutText(c,st.w,18,-9,st.k==='rec'||st.k==='feint'?34:44,st.col,{align:'center',stroke:'#0a0620'});
 if(st.sub){c.font='700 17px '+WA_P;c.textAlign='center';c.textBaseline='middle';c.fillStyle='#e8e4ff';c.fillText(st.sub,18,22)}
 c.restore()}
function waDrawBanner(c,t){const A=S.wa,b=A.banner;if(!b)return;const u=b.t/b.max,a=Math.min(1,(1-u)*5,u*4),k=1+(1-Math.min(1,(1-u)*6))*.4;c.save();c.globalAlpha=a;c.translate(W/2,360);c.scale(k,k);
 c.fillStyle='#0a0620aa';c.fillRect(-W,-70,W*2,140);c.strokeStyle='#e8c24a';c.lineWidth=3;c.beginPath();c.moveTo(-W,-70);c.lineTo(W,-70);c.moveTo(-W,70);c.lineTo(W,70);c.stroke();
 waOutText(c,b.big,0,-14,84,'#ffd24a',{glow:'#ffb02a'});waOutText(c,b.sub,0,42,32,'#fff',{});c.restore()}
/* the boss arena takes on the boss's colours: green soul-fog for the Crypt Lord, rising heat for the Ember Tyrant, torchlit gold for the King */
function waBossAtmos(c,e,t){const D=WAE[e.id];if(!D||!D.boss)return;const f=.55+.25*(e.phs-1);c.save();
 const q=c.createLinearGradient(0,430,0,H);q.addColorStop(0,'#0000');q.addColorStop(1,D.col+(e.phs>=3?'55':'33'));c.fillStyle=q;c.fillRect(0,430,W,H-430);
 c.fillStyle=D.col;for(let i=0;i<16;i++){const u=((t*(.1+.05*e.phs)+i*.137)%1),x=((i*197+Math.sin(t*.6+i)*40)%W+W)%W,y=H-u*(H-300);c.globalAlpha=Math.sin(u*Math.PI)*.45*f;c.beginPath();c.arc(x,y,e.id==='gCent'?3.4:2.4,0,TAU);c.fill()}c.restore()}
/* frame-time watch: if a machine cannot keep up, the arena quietly drops effects (and on very slow ones, render size) until it can. It never changes the rules. */
function waQuality(A,now){const lf=A.lf||now;A.lf=now;const f=now-lf;if(f<=0||f>250||A.t<.8)return;A.ft=A.ft?A.ft*.9+f*.1:f;
 if(A.ft>27&&A.q>0){A.qs+=f;if(A.qs>1400){A.q--;A.qs=0;A.qu=0;A.ft=17;waQApply(A)}}else{A.qs=Math.max(0,A.qs-f*.5);if(A.ft<18.5&&A.q<2&&(A.qlim||0)<2){A.qu+=f;if(A.qu>14000){A.q++;A.qu=0;A.qlim=(A.qlim||0)+1;waQApply(A)}}else A.qu=Math.max(0,A.qu-f)}}
function waQApply(A){try{if(ST.res==='auto'){if(A.q===0&&RS>1){RS=1;cv.width=W;cv.height=H}else if(A.q>0)applyLayout()}}catch(e){}}
/* ---------- the whole frame ---------- */
function waDraw(){const c=ctx,A=S.wa;if(!A)return;if(NEEDRESET){NEEDRESET=false;if(c.reset)c.reset()}c.globalAlpha=1;c.filter='none';c.globalCompositeOperation='source-over';c.shadowBlur=0;c.setTransform(RS,0,0,RS,0,0);c.save();
 if(A.shake>0&&ST.shake)c.translate((Math.random()-.5)*A.shake,(Math.random()-.5)*A.shake);
 const nowp=performance.now();WA_Q=A.q;waQuality(A,nowp);if(A.q===0&&RS>1&&ST.res==='auto')waQApply(A);
 const t=A.t;c.fillStyle='#000';c.fillRect(-30,-30,W+60,H+60);waDrawBG(c,t);if(A.boss&&A.q>=2&&A.cur)waBossAtmos(c,A.cur,t);
 /* queue first, then the fighter, then the hero, so the fight is always in front */
 const live=A.en.filter(e=>e.st!=='gone');for(const e of live)if(e!==A.cur)waDrawEn(c,e,t);
 if(A.cur)waDrawEn(c,A.cur,t);
 waDrawHero(c,t);waDrawShield(c,t);waDrawSlash(c,t);
 if(A.cur){waDrawSwing(c,A.cur,t);waDrawCue(c,A.cur,t);waDrawExp(c,A.cur,t)}
 for(const e of live)if(e.st!=='wait')waDrawPips(c,e,t);
 waDrawFx(c,t);
 c.restore();
 /* screen-wide tints */
 if(A.hurtFl>0){const g=c.createRadialGradient(W/2,H/2,H*.3,W/2,H/2,H*.9);g.addColorStop(0,'#0000');g.addColorStop(1,`rgba(255,30,50,${Math.min(.8,A.hurtFl)})`);c.fillStyle=g;c.fillRect(0,0,W,H)}
 if(A.flash>0&&ST.flash){c.fillStyle=`rgba(255,255,255,${Math.min(.5,A.flash*.5)})`;c.fillRect(0,0,W,H)}
 waDrawCoach(c,t);waDrawBanner(c,t);waDrawHUD(c,t);waDrawBar(c,t);waDrawPanel(c,t);waDrawLetterbox(c,t)}
/* the boss walks in like a headliner: black bars, a name and a title */
function waDrawLetterbox(c,t){const A=S.wa;if(!A.boss||A.ph!=='intro'||!A.cur)return;const u=A.phT,k=Math.min(1,u/.25)*Math.min(1,Math.max(0,(1.5-u)/.25));if(k<=0)return;const D=WAE[A.cur.id],bh=110*k;
 c.save();c.fillStyle='#05020c';c.fillRect(0,0,W,bh);c.fillRect(0,H-bh,W,bh);c.fillStyle=D.col;c.fillRect(0,bh-3,W,3);c.fillRect(0,H-bh,W,3);c.globalAlpha=k;
 waOutText(c,D.n.toUpperCase(),W/2,H-bh+52,52,D.col,{glow:D.col});c.font='italic 24px '+WA_G;c.fillStyle='#f0e6ff';c.textAlign='center';c.textBaseline='middle';c.fillText(D.ttl,W/2,bh-40);c.restore()}
