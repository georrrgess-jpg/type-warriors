/* ---------- Halloween weapons (WNEW builders: grip at the origin, tip toward +x, L=70 on the hero) ---------- */

/* Common: Jack-o'-Lantern Staff */
WNEW.hw_jack=(g,L,t,X)=>{const wood='#6a4a2a',P=[];for(let i=0;i<=16;i++){const u=i/16;P.push([-L*.2+u*L*.78,Math.sin(u*6+1)*1.3])}
 rib(g,P,u=>2.7-u*.5,wood);
 for(const u of[.3,.55]){const k=-L*.2+u*L*.78;ell(g,k,Math.sin(u*6+1)*1.3,2,2.6,shade(wood,-.3))}
 wrapG(g,-L*.05,L*.1,0,3.3,'#3a2010');
 /* a hooked iron cradle holds the pumpkin */
 g.strokeStyle='#2a2a30';g.lineWidth=2.4;g.beginPath();g.moveTo(L*.56,0);g.bezierCurveTo(L*.64,-9,L*.7,-10,L*.74,-8);g.moveTo(L*.56,0);g.bezierCurveTo(L*.64,9,L*.7,10,L*.74,8);g.stroke();
 g.save();g.translate(L*.9,0);g.rotate(Math.PI/2);hwPumpkin(g,0,0,L*.17,t);g.restore();
 /* a scrap of cobweb and a tiny spider on the shaft */
 g.strokeStyle='#ffffff77';g.lineWidth=.7;const wx=L*.3;for(let i=0;i<4;i++){const a=-.9+i*.6;g.beginPath();g.moveTo(wx,1.2);g.lineTo(wx+Math.cos(a)*9,Math.sin(a)*9+1.2);g.stroke()}g.beginPath();g.moveTo(wx+5,-7.6);g.quadraticCurveTo(wx+5.6,-1,wx+8,6.4);g.moveTo(wx+8,-5.4);g.quadraticCurveTo(wx+10,0,wx+9.2,5);g.stroke();
 const sy=-8+Math.sin(t*2)*1.6;g.strokeStyle='#111';g.lineWidth=.6;g.beginPath();g.moveTo(wx+6,-8);g.lineTo(wx+6,sy);g.stroke();ell(g,wx+6,sy,1.5,1.2,'#1a1418')};

/* Uncommon: Gravedigger's Spade */
WNEW.hw_spade=(g,L,t,X)=>{const wood='#8a6a42',P=[];for(let i=0;i<=14;i++){const u=i/14;P.push([-L*.2+u*L*.9,Math.sin(u*4)*.7])}
 rib(g,P,u=>2.5,wood);
 g.strokeStyle=shade(wood,-.5);g.lineWidth=1.6;g.beginPath();g.arc(-L*.22,0,5.6,Math.PI*.5,Math.PI*1.5);g.stroke();g.beginPath();g.moveTo(-L*.22,-5.6);g.lineTo(-L*.2,-5.6);g.moveTo(-L*.22,5.6);g.lineTo(-L*.2,5.6);g.stroke();
 wrapG(g,-L*.02,L*.12,0,3.3,'#3a2a1a');
 const bx=L*.66;
 /* socket collar, then the blade */
 g.fillStyle=metal(g,-5,5,'#6a6e76');g.beginPath();g.roundRect(bx-2,-4.6,10,9.2,2);g.fill();g.strokeStyle='#0008';g.lineWidth=1;g.stroke();
 const blade=()=>{g.beginPath();g.moveTo(bx+7,-4.4);g.quadraticCurveTo(bx+9,-10.6,bx+L*.12,-11.4);g.quadraticCurveTo(bx+L*.28,-9.6,bx+L*.36,0);g.quadraticCurveTo(bx+L*.28,9.6,bx+L*.12,11.4);g.quadraticCurveTo(bx+9,10.6,bx+7,4.4);g.closePath()};
 blade();g.fillStyle=metal(g,-11,11,X.c);g.fill();g.save();blade();g.clip();
 g.fillStyle='#8a4a1e66';for(const [x,y,r] of[[.1,-6,7],[.24,5,6],[.3,-2,4],[.06,6,4]])ell(g,bx+L*x+4,y,r,r*.7,'#8a4a1e55');
 g.strokeStyle='#ffffff55';g.lineWidth=1;g.beginPath();g.moveTo(bx+9,-6);g.quadraticCurveTo(bx+L*.14,-8,bx+L*.28,-3);g.stroke();
 g.strokeStyle='#00000055';g.lineWidth=1.2;g.beginPath();g.moveTo(bx+8,0);g.lineTo(bx+L*.34,0);g.stroke();
 g.fillStyle='#3a2410';for(const [x,y,r] of[[.2,-7,2.2],[.26,3,1.8],[.12,8,2.4],[.32,-3,1.4]])ell(g,bx+L*x+3,y,r,r*.8,'#3a2410');g.restore();
 blade();g.strokeStyle='#000000a8';g.lineWidth=1.3;g.stroke();
 /* falling grave dirt */
 for(let i=0;i<4;i++){const u=(t*.9+i/4)%1,x=bx+L*.2+i*5,y=10+u*16;g.globalAlpha=1-u;ell(g,x,y,1.5,1.2,'#4a3018');}g.globalAlpha=1;
 /* a bone charm on a cord */
 g.strokeStyle='#d8c8a0';g.lineWidth=.9;g.beginPath();g.moveTo(bx-.6,4);g.lineTo(bx-1,9);g.stroke();g.save();g.translate(bx-1,10);g.rotate(Math.sin(t*2.4)*.3);limb(g,0,-1,0,6,2.2,'#efe8d4');ell(g,-1.2,6.6,1.6,1.4,'#efe8d4');ell(g,1.2,6.6,1.6,1.4,'#efe8d4');g.restore()};

/* Rare: Batwing Bow */
WNEW.hw_bat=(g,L,t,X)=>wBow(g,L,t,{c:X.c,lw:3.2,grip:'#1a0e24',str:'#d8c8ff',sw:1.1,nock:'#ff4a60',head:'#cfc8ff',
 back:(g,G,h,bw)=>{g.save();g.globalCompositeOperation='lighter';glow(g,0,bw*.2,L*.42,'#8a4aff30');g.restore()},
 limb:(g,G,h,bw,gy)=>{for(const s of[-1,1]){
   const N=12,edge=[],outer=[];for(let i=0;i<=N;i++){const u=.07+i/N*.55,p=G.at(u,s);edge.push(p);const dep=(5+13*Math.sin(Math.PI*i/N)*.9)*(1+.06*Math.sin(t*3+s)),sc=.55+.45*Math.abs(Math.cos(i*Math.PI/4));outer.push([p.x+p.nx*dep*sc,p.y+p.ny*dep*sc])}
   g.beginPath();edge.forEach((p,i)=>i?g.lineTo(p.x,p.y):g.moveTo(p.x,p.y));for(let i=N;i>=0;i--)g.lineTo(outer[i][0],outer[i][1]);g.closePath();g.fillStyle=hgr(g,-h,h,'#2a1448','#4a2a78');g.fill();g.strokeStyle='#b890ff';g.lineWidth=.9;g.stroke();
   g.strokeStyle='#e0ccff88';g.lineWidth=.8;for(let i=1;i<N;i+=3){g.beginPath();g.moveTo(edge[i].x,edge[i].y);g.lineTo(outer[i][0],outer[i][1]);g.stroke()}
   const e=G.at(.02,s);poly(g,[e.x,e.y,e.x+s*3,e.y-2,e.x+s*1.6,e.y+2.4],'#cfc8ff')}
  /* the bat's face sits at the grip */
  g.save();g.translate(0,gy);poly(g,[-6,-3,-8,-9,-2.6,-5,0,-6,2.6,-5,8,-9,6,-3,5,4,0,7,-5,4],'#1c0e2c','#000a',1);
  const pu=.75+.25*Math.sin(t*4);g.globalAlpha=pu;glow(g,-2.6,-.4,6,'#ff305088');glow(g,2.6,-.4,6,'#ff305088');g.globalAlpha=1;ell(g,-2.6,-.4,1.4,1.1,'#ff4a60');ell(g,2.6,-.4,1.4,1.1,'#ff4a60');
  poly(g,[-1.6,3,-.8,5.6,-.2,3],'#fff');poly(g,[.2,3,.8,5.6,1.6,3],'#fff');g.restore()}});

/* Epic: Wraithbone Katana */
WNEW.hw_katana=(g,L,t,X)=>{const B=[],N=18;for(let i=0;i<=N;i++){const u=i/N;B.push([L*.16+u*L*.8,-Math.pow(u,2.2)*L*.1])}
 /* ribbon tail on the hilt */
 {const R=[];for(let i=0;i<=8;i++){const u=i/8;R.push([-L*.18-u*L*.2,2+Math.sin(t*5+u*5)*2.6*u+u*3])}rib(g,R,u=>2.6*(1-u*.6),'#3a2a50')}
 /* tsuka wrapped in dark cord */
 g.fillStyle=vgr(g,-3.4,3.4,'#4a3a60','#1a1228');g.beginPath();g.roundRect(-L*.18,-3.2,L*.32,6.4,3);g.fill();g.strokeStyle='#8a78b0';g.lineWidth=1;for(let x=-L*.16;x<L*.12;x+=4.4){g.beginPath();g.moveTo(x,-3);g.lineTo(x+2.4,3);g.moveTo(x+2.4,-3);g.lineTo(x,3);g.stroke()}
 ell(g,-L*.19,0,3.4,3.8,'#cfc8b0');ell(g,-L*.19,0,1.3,1.6,'#1a1228');
 /* skull tsuba */
 g.fillStyle=vgr(g,-9,9,'#f4f0e0','#9a9484');g.beginPath();g.ellipse(L*.145,0,3.6,8.8,0,0,TAU);g.fill();g.strokeStyle='#000a';g.lineWidth=1;g.stroke();
 ell(g,L*.15,-3.2,1.5,1.9,'#0a1a10');ell(g,L*.15,3.2,1.5,1.9,'#0a1a10');const gp=.7+.3*Math.sin(t*4);g.globalAlpha=gp;ell(g,L*.152,-3.2,.8,1,X.rc);ell(g,L*.152,3.2,.8,1,X.rc);g.globalAlpha=1;
 /* the blade: pale bone with a spectral edge */
 g.save();g.globalCompositeOperation='lighter';glow(g,L*.58,-L*.03,L*.5,'#5affb022');g.restore();
 rib(g,B,u=>3.6*(1-.45*u*u)+.3,'#ece8d4');
 g.strokeStyle='#5affb0';g.lineWidth=1.1;g.shadowColor='#5affb0';g.shadowBlur=7;g.beginPath();B.forEach((p,i)=>{const y=p[1]+3.2*(1-.4*(i/N)*(i/N));i?g.lineTo(p[0],y):g.moveTo(p[0],y)});g.stroke();g.shadowBlur=0;
 g.strokeStyle='#8a8a74';g.lineWidth=.8;for(let i=2;i<N-1;i+=3){g.beginPath();g.moveTo(B[i][0],B[i][1]-2);g.lineTo(B[i][0]+1.4,B[i][1]+1);g.stroke()}
 poly(g,[B[N][0],B[N][1]-3.4,B[N][0]+7,B[N][1]-5.6,B[N][0]+1,B[N][1]+.6],'#ece8d4','#000a',.8);
 /* ghostly fire licking from the back of the blade */
 g.save();g.globalCompositeOperation='lighter';for(let i=0;i<10;i++){const u=(i+.5)/10,p=B[Math.floor(u*N)],w=Math.sin(t*5+i*1.7),l=6+5*Math.abs(Math.sin(t*2.4+i*2.3));g.globalAlpha=.26+.12*w;g.beginPath();g.moveTo(p[0]-4.4,p[1]-3.2);g.bezierCurveTo(p[0]-5+w*2,p[1]-3.2-l*.6,p[0]-1+w*3,p[1]-3.6-l*.8,p[0]+2+w*4,p[1]-4-l);g.bezierCurveTo(p[0]+3+w*2,p[1]-3.2-l*.5,p[0]+5,p[1]-3.4-l*.2,p[0]+4.4,p[1]-3.2);g.closePath();g.fillStyle='#5affb0';g.fill()}for(let i=0;i<5;i++){const u=(t*.4+i/5)%1,p=B[Math.floor((i/5+.1)*N)];g.globalAlpha=Math.sin(u*Math.PI)*.8;ell(g,p[0]+Math.sin(u*7+i)*3,p[1]-5-u*18,1.2,1.2,'#caffe6')}g.restore()};

/* Legendary: Crimson Fang */
WNEW.hw_fang=(g,L,t,X)=>{const x0=L*.2,x1=L*1.02;
 /* blade: dark steel, a blood-red fuller, a hooked fang tip */
 g.save();g.globalCompositeOperation='lighter';glow(g,L*.62,0,L*.5,'#ff204030');g.restore();
 g.beginPath();g.moveTo(x0,-4.4);g.lineTo(x0+L*.5,-3.5);g.quadraticCurveTo(x1-L*.08,-2.6,x1,2.2);g.quadraticCurveTo(x1-L*.1,.8,x0+L*.55,3.2);g.lineTo(x0,4.4);g.closePath();
 g.fillStyle=metal(g,-4.4,4.4,X.c);g.fill();g.strokeStyle='#000b';g.lineWidth=1.2;g.stroke();
 g.save();g.beginPath();g.moveTo(x0,-4.4);g.lineTo(x0+L*.5,-3.5);g.quadraticCurveTo(x1-L*.08,-2.6,x1,2.2);g.quadraticCurveTo(x1-L*.1,.8,x0+L*.55,3.2);g.lineTo(x0,4.4);g.closePath();g.clip();
 g.fillStyle='#c0102a';g.fillRect(x0+4,-1.1,L*.62,2.2);g.fillStyle='#ff6a80aa';g.fillRect(x0+4,-1.1,L*.62,.7);g.fillStyle='#ffffff66';g.fillRect(x0+2,-3.6,L*.74,.9);g.restore();
 /* bat-wing guard */
 for(const s of[-1,1]){g.beginPath();g.moveTo(x0-1,s*2);g.quadraticCurveTo(x0+4,s*12,x0+2,s*17);g.quadraticCurveTo(x0-1,s*13,x0-3,s*15);g.quadraticCurveTo(x0-5,s*11,x0-7,s*12);g.quadraticCurveTo(x0-6,s*6,x0-4,s*2);g.closePath();g.fillStyle=hgr(g,x0-7,x0+4,'#5a0a1a','#2a0610');g.fill();g.strokeStyle='#e6b93e';g.lineWidth=1.1;g.stroke();g.strokeStyle='#e6b93e88';g.lineWidth=.7;g.beginPath();g.moveTo(x0-2,s*3);g.lineTo(x0+1,s*14);g.moveTo(x0-3,s*3);g.lineTo(x0-3,s*12);g.stroke()}
 g.fillStyle=metal(g,-5,5,'#3a2a30');g.beginPath();g.roundRect(x0-5.4,-4.4,7.6,8.8,2);g.fill();g.strokeStyle='#000a';g.lineWidth=1;g.stroke();gem(g,x0-1.6,0,2.4,'#ff2a4a');
 /* grip, gold rings and a ruby pommel */
 wrapG(g,-L*.1,x0-5.6,0,3.2,'#2a0a14');g.fillStyle='#e6b93e';for(const x of[-L*.08,L*.02,L*.11])g.fillRect(x,-3.6,2,7.2);
 {const gp=.7+.3*Math.sin(t*3);g.globalAlpha=gp;glow(g,-L*.13,0,14,'#ff204099');g.globalAlpha=1;poly(g,[-L*.1,0,-L*.13,-5,-L*.2,0,-L*.13,5],'#d01234','#400610',1);poly(g,[-L*.1,0,-L*.13,-5,-L*.15,-1],'#ff9aaa88')}
 /* a drop of blood that never quite falls */
 {const u=(t*.55)%1;g.globalAlpha=1-u*.8;const dx=x0+L*.5+Math.sin(u*3)*2,dy=3.6+u*18;g.fillStyle='#d01234';g.beginPath();g.moveTo(dx,dy-2.6);g.quadraticCurveTo(dx+2,dy+.4,dx,dy+2);g.quadraticCurveTo(dx-2,dy+.4,dx,dy-2.6);g.fill();g.globalAlpha=1}
 g.save();g.globalCompositeOperation='lighter';for(let i=0;i<6;i++){const u=(t*.45+i/6)%1;g.globalAlpha=Math.sin(u*Math.PI)*.8;const px=x0+L*(.12+.1*i)+Math.sin(u*6+i)*2;ell(g,px,-5-u*16,1.3*(1-u*.5),1.3*(1-u*.5),'#ff5a78')}g.restore()};

/* Mythic: Soulreaper */
WNEW.hw_scythe=(g,L,t,X)=>{const pu=.8+.2*Math.sin(t*4),sx=L*.9;
 g.save();g.globalCompositeOperation='lighter';glow(g,L*.7,L*.2,L*.85,'#5affb028');glow(g,sx,L*.14,L*.5,'#5affb02a');g.restore();
 /* haft of black wood with bone rings and a tattered ribbon */
 const P=[];for(let i=0;i<=16;i++){const u=i/16;P.push([-L*.22+u*L*1.1,Math.sin(u*5)*.9])}rib(g,P,u=>2.9,'#1c1426');
 for(const u of[.06,.28,.5,.72]){const x=-L*.22+u*L*1.1;g.fillStyle='#efe8d4';g.beginPath();g.roundRect(x-1.4,-3.8,3.2,7.6,1.4);g.fill();g.strokeStyle='#000a';g.lineWidth=.8;g.stroke()}
 wrapG(g,-L*.04,L*.1,0,3.4,'#0a0612');
 /* the great blade: a pale ghost-steel crescent with a living green edge */
 const C=[],N=26;for(let i=0;i<=N;i++){const u=i/N,m=1-u;C.push([m*m*sx+2*m*u*(sx+L*.06)+u*u*(sx-L*.5),m*m*4+2*m*u*(L*.9)+u*u*(L*.42)])}
 rib(g,C,u=>(1-Math.pow(u,1.25))*L*.1+.5,'#cfeedd');
 {const E=C.map((p,i)=>{const q=C[Math.min(N,i+1)],o=C[Math.max(0,i-1)],dx=q[0]-o[0],dy=q[1]-o[1],d=Math.hypot(dx,dy)||1,w=(1-Math.pow(i/N,1.25))*L*.1+.5;return[p[0]-dy/d*w,p[1]+dx/d*w]});g.strokeStyle='#5affb0';g.lineWidth=1.6;g.shadowColor='#5affb0';g.shadowBlur=10;g.beginPath();E.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.stroke();g.shadowBlur=0;
 g.strokeStyle='#ffffffaa';g.lineWidth=.8;g.beginPath();C.forEach((p,i)=>{if(i<2||i>N-3)return;i>2?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1])});g.stroke();
 g.save();g.globalCompositeOperation='lighter';for(let i=0;i<12;i++){const u=(i+.5)/12,k=Math.floor(u*N),p=E[k],w=Math.sin(t*5+i*1.9),l=5+5*Math.abs(Math.sin(t*2.6+i*1.4));g.globalAlpha=.34+.14*w;g.beginPath();g.moveTo(p[0]-2.6,p[1]);g.bezierCurveTo(p[0]-3+w,p[1]-l*.6,p[0]+w*2,p[1]-l*.8,p[0]+w*2.6,p[1]-l);g.bezierCurveTo(p[0]+3,p[1]-l*.5,p[0]+3.4,p[1]-l*.2,p[0]+2.6,p[1]);g.closePath();g.fillStyle='#5affb0';g.fill()}g.restore()}
 /* drifting souls */
 for(let i=0;i<3;i++){const u=(t*.22+i/3)%1,x=sx-L*.12+Math.sin(u*6+i*2)*L*.12,y=L*.35+u*L*.45;hwGhost(g,x,y,.6+.2*Math.sin(i),t+i,'#dfffee',Math.sin(u*Math.PI)*.8,'#04140c')}
 /* the skull where blade meets haft: big, upright, facing the viewer, drawn last so nothing hides it */
 {g.save();g.translate(sx-L*.06,1);{const m=g.getTransform();if(m.a*m.d-m.b*m.c>0)g.rotate(-Math.atan2(m.b,m.a))}g.scale(.9,.9);g.save();g.globalCompositeOperation='lighter';glow(g,0,0,17,'#5affb0'+hwA(.26+.12*pu));g.restore();
  poly(g,[-6.6,5.4,6.6,5.4,5,12.4,-5,12.4],'#e8e2d0','#000c',1);
  g.strokeStyle='#4a463a';g.lineWidth=.9;for(const x of[-3.4,-1.1,1.1,3.4]){g.beginPath();g.moveTo(x,7.4);g.lineTo(x,12);g.stroke()}
  ell(g,0,-.5,9.6,10.2,rgr(g,-3,-4,1,13,'#fbf8ec','#a39c88'));
  g.strokeStyle='#00000055';g.lineWidth=.8;g.beginPath();g.moveTo(1.4,-10);g.lineTo(2.4,-6);g.lineTo(.6,-4);g.stroke();
  ell(g,-3.7,-1.2,3.1,3.6,'#05020a');ell(g,3.7,-1.2,3.1,3.6,'#05020a');
  g.save();g.globalCompositeOperation='lighter';glow(g,-3.7,-1.2,7,'#5affb0'+hwA(.55*pu));glow(g,3.7,-1.2,7,'#5affb0'+hwA(.55*pu));g.restore();
  g.globalAlpha=.55+.45*pu;eye(g,-3.7,-1.2,1.7,'#9affd0');eye(g,3.7,-1.2,1.7,'#9affd0');g.globalAlpha=1;
  poly(g,[0,2.4,-1.8,5.4,1.8,5.4],'#05020a');
  poly(g,[-9.6,-6,-12.4,-14,-5.4,-8.6],'#efe8d4','#000a',.8);poly(g,[9.6,-6,12.4,-14,5.4,-8.6],'#efe8d4','#000a',.8);g.restore()}
 /* an hourglass swinging from the haft */
 {g.save();g.translate(L*.5,3);g.strokeStyle='#cfc8b0';g.lineWidth=.9;g.beginPath();g.moveTo(0,0);g.lineTo(0,4);g.stroke();g.translate(0,4);g.rotate(Math.sin(t*2.1)*.22);
  g.fillStyle='#ffffff30';g.strokeStyle='#e6b93e';g.lineWidth=1.1;g.beginPath();g.moveTo(-3.4,0);g.lineTo(3.4,0);g.lineTo(.8,5.4);g.lineTo(3.4,10.8);g.lineTo(-3.4,10.8);g.lineTo(-.8,5.4);g.closePath();g.fill();g.stroke();
  g.fillStyle='#5affb0';g.beginPath();g.moveTo(-2.6,10.4);g.lineTo(2.6,10.4);g.lineTo(0,7.6);g.fill();g.fillRect(-.3,5.4,.6,3);g.fillStyle='#e6b93e';g.fillRect(-4,-1.2,8,1.6);g.fillRect(-4,10.6,8,1.6);g.restore()}};
