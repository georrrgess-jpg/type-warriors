# python3 t_moon102.py [game.html] : the Moonblade Sentinel (99a art, 99b battle), the thirteenth tower of Runestone Tower Defense.
# Key M, 300 supply, ground and air; crescent glaives fly a boomerang loop out through the target to the edge of the range and back,
# cutting every monster they pass once on the way out and once on the way back (armor-piercing); tier 3 Twin Moons (two glaives on
# mirrored curves), tier 4 Moonlit Wake (20% slow on the road, no stacking, never over a stronger slow or a slow-immune monster), tier 5
# Eclipse (a third glaive, an eclipse crescent every fifth throw); Target modes, Overcharge, jams, hidden and fogged monsters, the
# Glowcap range, art per tier, frame cost, the info panel, texts, mastery skins, a real wave and a Wonderland wave.
import asyncio,os,sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:500]),flush=True)
    if not ok:FAIL.append(name)
HELP=r"""()=>{
 window.tdBuild=(R,p,t,tier)=>{rpBuild(p,t);const tw=p.tw;tw.build=1;while(tw.tier<(tier||1)&&rpUpgrade(tw));tw.upK=1;return tw};
 window.tdNew=(map,wave)=>{try{rpLeave()}catch(e){}rpStart(map);const R=RPX;R.tut=null;R.hold=false;R.supply=1e9;R.wst='run';R.wave=wave||1;R.q=[];R.banner=null;R.toast=null;R.foes=[];R.cd=999;
  if(R.cannon)R.cannon.t=1e9;if(R.gust)R.gust.t=1e9;if(R.rodK){R.boltT=1e9;R.boltTwT=1e9}return R};
 window.tdFoe=(R,id,s,pi)=>{const e=rpSpawn(id,pi||0);e.s=s;e._s=-1;e.sp=0;e.off=0;return e};
 window.tdTank=(e,hp)=>{e.hp=e.mx=hp||1e6;e.armor=e.arm0=0;return e};
 window.tdRun=(R,sec)=>{for(let i=0;i<Math.round(sec*30);i++)rpStep(R,1/30)};
 window.tdNear=(R,pad,pi)=>{let best=0,bd=1e9;const L=R.G.paths[pi||0].len;for(let s=0;s<L;s+=4){const q=rpAt(R.G,s,pi||0),d=Math.hypot(q.x-pad.x,q.y-pad.y);if(d<bd){bd=d;best=s}}return best};
 window.tdPad=(R)=>{let best=null,bd=1e9;for(const p of R.pads){const s=tdNear(R,p,0),q=rpAt(R.G,s,0),d=Math.hypot(q.x-p.x,q.y-p.y);if(d>70&&d<bd&&p.x>250&&p.x<1350){bd=d;best=p}}return best};
 /* a road spot at a ground-plane distance lo..hi from a tower */
 window.tdAt=(R,tw,lo,hi,pi)=>{const L=R.G.paths[pi||0].len;for(let s=10;s<L-10;s+=3){const q=rpAt(R.G,s,pi||0),d=Math.sqrt(rpD2(q.x,q.y,tw.x,tw.y));if(d>lo&&d<hi)return s}return null};
 /* one throw: reset the tower, run until the glaives are home again; per monster: hits on the way out / back */
 window.tdThrow=(R,tw,es,sec)=>{tw.cd=0;tw.mbW=0;const n0=R.mbThrows,log=new Map(es.map(e=>[e,[0,0]]));let maxd=0,gl=[],t=0;
  while(t<(sec||3)){rpStep(R,1/30);t+=1/30;for(const g of R.mbGl){if(g.tw!==tw)continue;if(!gl.includes(g))gl.push(g);maxd=Math.max(maxd,Math.sqrt(rpD2(g.X,g.Y*RPFX.sq,tw.x,tw.y)))}if(R.mbThrows>n0&&!R.mbGl.some(g=>g.tw===tw))break}
  for(const g of gl)for(const e of es){const L=log.get(e);if(g.hitO.has(e))L[0]++;if(g.hitB.has(e))L[1]++}return{n:R.mbThrows-n0,t:+t.toFixed(2),maxd:Math.round(maxd),gl,log:es.map(e=>log.get(e))}};
 return 1}"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        pg.on('console',lambda m:er.append('console: '+m.text[:300]) if m.type=='error' and 'WebSocket' not in m.text and 'net::' not in m.text else None)
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E("()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const r=RPP();r.new99j=1;r.dragon=1;r.stars=Object.assign(r.stars||{},{moss:3,frost:3,ember:3,coral:3,wreck:3,abyss:3,meadow:3,foundry:3});for(const k in r.tut)r.tut[k]=1;for(const k of['build','wave','coins','upgrade','abil','rune','twist','twist_frost','twist_ember','twist_wonder'])r.tut[k]=1;save()}")
        await E(HELP)
        # ---- data
        r=await E("()=>{const T=RP_TW.moon,i=RP_TWORDER.indexOf('moon');return [i,RP_KEYS[i],RPTW.moon.n,T.cost,T.air,T.ground,T.glaives,T.range,T.ap,RPSKIN.moon,[1,2,3,4,5].map(t=>rpTowerTop('moon',t)),new Set(RP_KEYS).size===RP_KEYS.length]}")
        chk('the Moonblade Sentinel is the thirteenth tower: key M (unique), 300 supply, ground and air, 1/1/2/2/3 glaives, range 210-270, armor-piercing 2/3/all, taller every tier',
            r[0]==12 and r[1]=='M' and r[2]=='Moonblade Sentinel' and r[3][0]==300 and r[4]==1 and r[5]==1 and r[6]==[1,1,2,2,3] and r[7][0]>=200 and r[7][4]<=280 and r[8][:2]==[2,3] and r[8][2]>=99 and r[9]==['base'] and r[10]==sorted(r[10]) and len(set(r[10]))==5 and r[11],r)
        r=await E("()=>{const T=RP_TW.moon;return [T.cost,T.dmg,T.cd,T.range,T.desc.length>40,T.up.length]}")
        chk('every tier is stronger (more damage, faster throws, more range) and has an upgrade text',all(r[1][i]<r[1][i+1] and r[2][i]>r[2][i+1] and r[3][i]<r[3][i+1] for i in range(4)) and r[4] and r[5]==4,r)
        # ---- hotkey, bar, ring, build, upgrade, sell
        r=await E("""async()=>{try{rpLeave()}catch(e){}rpStart('moss');const R=RPX;R.tut=null;R.supply=1000;await new Promise(r=>setTimeout(r,700));window.dispatchEvent(new KeyboardEvent('keydown',{key:'m'}));const a=R.place;R.place=null;R.ghost=null;
          const c=document.querySelector('.rpbar .rpcard[data-tw="moon"]'),ok=rpBuild(R.pads[0],'moon');const tw=R.pads[0].tw;tw.build=1;rpStep(R,1/30);const paid=1000-R.supply;
          rpUpgrade(tw);tw.upK=1;const t2=tw.tier,s0=R.supply;rpSell(tw);const refund=Math.round(R.supply-s0);
          R.selPad=R.pads[1];await new Promise(r=>setTimeout(r,400));const rb=document.querySelector('#rpring .rprb[data-tw="moon"]');let built=null;if(rb){rb.click();await new Promise(r=>setTimeout(r,100));built=R.pads[1].tw&&R.pads[1].tw.type}
          return [a,!!c,ok!==false,paid,t2,R.pads[0].tw,refund,!!rb,built]}""")
        chk('key M picks it, its card is in the bar and its button in the build ring (which builds it); 300 supply; an upgrade; selling refunds 70%',r[:6]==['moon',True,True,300,2,None] and r[6]==round(520*.7) and r[7] and r[8]=='moon',r)
        r=await E("""()=>{const R=RPX;R.ty=R.ty||{};const was=R.ty.on;R.ty.on=true;R.place=null;window.dispatchEvent(new KeyboardEvent('keydown',{key:'m'}));const a=R.place;R.ty.on=was;return a}""")
        chk('with Rune Typing on, M types a letter instead of picking the tower',r!='moon',r)
        # ---- the flight: out through the target to the edge of the range, back to the hand
        r=await E("""()=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'moon',1),rg=RP_TW.moon.range[0],s=tdAt(R,tw,rg*.45,rg*.55);const e=tdTank(tdFoe(R,'golem',s));
          let wind=0,held=0;for(let i=0;i<30&&!R.mbThrows;i++){rpStep(R,1/30);if(!R.mbThrows&&tw.mbW>0)held=tw.mbHold[0];wind=Math.max(wind,tw.mbW||0)}
          const f=tdThrow(R,tw,[e]);const g=f.gl[0],H=rpmbHandW(tw,g.slot,RPMB_A.hold);return [wind>=.99,held,R.mbThrows,f.maxd,rg,Math.round(Math.hypot(g.X-H.x,g.Y*RPFX.sq-H.y)),tw.mbOut,tw.mbHold[0],tw.mbC>0,f.t]}""")
        chk('the statue winds up, throws, the glaive flies to the edge of its range (not past it) and comes back to the hand (caught: recoil)',
            r[0] and r[1]==1 and r[2]>=1 and r[4]*.93<=r[3]<=r[4]*1.02 and r[5]<=3 and r[6]==0 and r[7]==1 and r[8] and r[9]<2,r)
        r=await E("""()=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'moon',1),rg=RP_TW.moon.range[0];const out=[];
          for(const [lo,hi] of [[.3,.45],[.5,.62],[.7,.82]]){R.foes=[];const s=tdAt(R,tw,rg*lo,rg*hi)??tdAt(R,tw,rg*(lo-.1),rg*hi);if(s==null){out.push('nos');continue}const e=tdTank(tdFoe(R,'golem',s));const h=e.hp;const f=tdThrow(R,tw,[e]);out.push([f.log[0][0],f.log[0][1],Math.round(h-e.hp)])}return [out,RP_TW.moon.dmg[0]]}""")
        chk('the glaive cuts the target on the way out and again on the way back (twice its damage per throw), wherever it stands in range',
            all(x!='nos' and x[0]==1 and x[1]==1 and x[2]==2*r[1] for x in r[0]),r)
        r=await E("""()=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'moon',1),rg=RP_TW.moon.range[0],s=tdAt(R,tw,rg*.5,rg*.6);const es=[];for(let k=0;k<6;k++)es.push(tdTank(tdFoe(R,'golem',s-40+k*22)));
          const per=new Map();const h0=rpHurt;rpHurt=function(e,d,ap,src){if(src===tw)per.set(e,(per.get(e)||0)+1);return h0.apply(this,arguments)};let f;try{f=tdThrow(R,tw,es)}finally{rpHurt=h0}
          return [f.n,es.map(e=>per.get(e)||0),f.log]}""")
        chk('a glaive cuts every monster along its way, each at most once per pass (at most two cuts per monster per throw)',r[0]==1 and max(r[1])<=2 and sum(1 for x in r[1] if x>0)>=3 and all(a<=1 and b<=1 for a,b in r[2]),r)
        r=await E("""()=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'moon',2),rg=RP_TW.moon.range[1],s=tdAt(R,tw,rg*.45,rg*.6);const e=tdTank(tdFoe(R,'gloom',s));const h=e.hp;tdRun(R,3);return [e.air,R.mbThrows,Math.round(h-e.hp)]}""")
        chk('it cuts flyers too',r[0]==True and r[1]>=2 and r[2]>=r[1]*46,r)
        r=await E("""()=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'moon',1),rg=RP_TW.moon.range[0];let far=0,fd=0;const L=R.G.paths[0].len;for(let s=0;s<L;s+=20){const q=rpAt(R.G,s,0),d=Math.sqrt(rpD2(q.x,q.y,pad.x,pad.y));if(d>fd){fd=d;far=s}}
          const e=tdTank(tdFoe(R,'golem',far));tdRun(R,3);const s1=tdAt(R,tw,rg*1.04,rg*1.12);R.foes=[];const f=tdTank(tdFoe(R,'golem',s1));tdRun(R,2);const n0=R.mbThrows;tw.rangeK=1.15;tdRun(R,2);const n1=R.mbThrows;
          tw.rangeK=0;tw.glowK=1.15;const n2=R.mbThrows;tdRun(R,2);return [Math.round(fd),n0,n1>0,R.mbThrows>n2]}""")
        chk('a monster out of range is left alone; a range bonus (tw.rangeK) or a Glowcap pad (tw.glowK) reaches one just past its range',r[0]>400 and r[1]==0 and r[2] and r[3],r)
        # ---- armor piercing
        r=await E("""()=>{const out=[];for(const t of [1,2,3]){const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'moon',t),rg=RP_TW.moon.range[t-1],s=tdAt(R,tw,rg*.45,rg*.6);const e=tdFoe(R,'brute',s);e.hp=e.mx=1e6;e.armor=e.arm0=10;
           const h=e.hp;const f=tdThrow(R,tw,[e]);const n=f.log[0][0]+f.log[0][1];out.push(+((h-e.hp)/n).toFixed(1))}const T=RP_TW.moon;return [out,[T.dmg[0]-(10-T.ap[0]),T.dmg[1]-(10-T.ap[1]),T.dmg[2]]]}""")
        chk('armor-piercing: against armor 10 a cut does its damage minus (10 - 2), minus (10 - 3), and the full damage from tier 3',r[0]==r[1],r)
        # ---- Twin Moons
        r=await E("""()=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'moon',3),rg=RP_TW.moon.range[2],s=tdAt(R,tw,rg*.45,rg*.6);const e=tdTank(tdFoe(R,'golem',s));const f=tdThrow(R,tw,[e]);
          const g=f.gl;return [g.length,g.map(x=>x.slot).sort().join(','),g.length==2&&g[0].sd===-g[1].sd,f.log[0][0],f.log[0][1],JSON.stringify(tw.mbHold),tw.mbOut]}""")
        chk('tier 3 Twin Moons: one glaive from each hand on mirrored curves, both cut the target on the way out',r[0]==2 and r[1]=='0,1' and r[2] and r[3]==2 and r[4]>=1 and r[5]=='[1,1,1]' and r[6]==0,r)
        # ---- tier 4 Moonlit Wake
        r=await E("""()=>{const R=tdNew('wonder',30),pad=tdPad(R),tw=tdBuild(R,pad,'moon',4),rg=RP_TW.moon.range[3],s=tdAt(R,tw,rg*.45,rg*.6);const e=tdTank(tdFoe(R,'golem',s));tdThrow(R,tw,[e]);
          const n=R.mbWake.length,onRoad=R.mbWake.every(w=>rpmbRoad(R,w.x,w.y));const w=R.mbWake[0];R.foes=[];R.mbGl=[];tw.cd=99;
          const a=tdTank(tdFoe(R,'golem',0));const q=w;let best=0,bd=1e9;for(let ss=0;ss<R.G.paths[0].len;ss+=2){const p=rpAt(R.G,ss,0),d=Math.hypot(p.x-q.x,p.y-q.y);if(d<bd){bd=d;best=ss}}a.s=best;a._s=-1;
          const fl=tdTank(tdFoe(R,'gloom',best));rpStep(R,1/30);rpStep(R,1/30);const sl=[a.slowK,a.slowT>0,fl.slowT>0];
          const R3=tdNew('moss',3),t3=tdBuild(R3,R3.pads[pad.i]||R3.pads[0],'moon',3),e3=tdTank(tdFoe(R3,'golem',tdNear(R3,R3.pads[pad.i]||R3.pads[0],0)));tdRun(R3,2);
          return [n>0,onRoad,...sl,R3.mbWake.length,RPMBL.wakeK,RPMBL.wakeT]}""")
        chk('tier 4 Moonlit Wake: glaives leave a silver wake on the road; a ground monster on it is slowed 20%, a flyer is not; no wake below tier 4',
            r[0] and r[1] and abs(r[2]-0.2)<1e-6 and r[3] and not r[4] and r[5]==0 and r[7]==1.5,r)
        r=await E("""()=>{const R=tdNew('moss',3),s=500;const e=tdTank(tdFoe(R,'golem',s));e.sp=60;e.mbWk=1.5;const s0=e.s;tdRun(R,1);const d1=e.s-s0;const f=tdTank(tdFoe(R,'golem',s));f.sp=60;const s1=f.s;tdRun(R,1);const d2=f.s-s1;f.sp=0;
          const g=tdTank(tdFoe(R,'golem',s));g.slowK=.6;g.slowT=5;g.mbWk=1.5;rpStep(R,1/30);const strong=g.slowK;
          const v=tdTank(tdFoe(R,'golem',s));v.mbWk=1.5;v.vent=1;v.slowK=0;v.slowT=0;rpStep(R,1/30);const vent=[v.slowK||0,v.slowT>0];
          const h=tdTank(tdFoe(R,'golem',s));h.mbWk=1.5;h.hnS=1.5;rpStep(R,1/30);const both=h.slowK;
          const w=tdTank(tdFoe(R,'golem',s));R.mbWake.push({x:0,y:0,t:0,d:2,tier:4,rot:0});const q=rpPos(R,w);for(let k=0;k<3;k++)R.mbWake.push({x:q.x+k*3,y:q.y,t:0,d:2,tier:4,rot:0});rpStep(R,1/30);rpStep(R,1/30);const many=w.slowK;
          R.mbWake=[];const x=tdTank(tdFoe(R,'golem',s+200));x.mbWk=1.5;tdRun(R,1.6);return [+(d1/d2).toFixed(3),strong,...vent,both,many,x.mbWk,x.slowK]}""")
        chk('the wake really slows 20%; a stronger slow is kept; a venting (slow-immune) monster ignores it; honey (15%) is replaced, not added to; many marks do not stack; it wears off after 1.5 s',
            abs(r[0]-0.8)<0.02 and r[1]==0.6 and r[2]==0 and abs(r[4]-0.2)<1e-6 and abs(r[5]-0.2)<1e-6 and r[6]==0 and r[7]==0,r)
        # ---- tier 5 Eclipse
        r=await E("""()=>{const R=tdNew('wonder',30),pad=tdPad(R),tw=tdBuild(R,pad,'moon',5),rg=RP_TW.moon.range[4],s=tdAt(R,tw,rg*.45,rg*.6);const e=tdTank(tdFoe(R,'golem',s));const e2=tdTank(tdFoe(R,'golem',s+40));
          const f=tdThrow(R,tw,[e,e2]);const n3=f.gl.length,slots=f.gl.map(g=>g.slot).sort().join(',');
          const ring=tdAt(R,tw,rg*RPMBL.eclR*.97,rg*RPMBL.eclR*1.03);R.foes=[];const c=tdTank(tdFoe(R,'golem',ring));const far=tdTank(tdFoe(R,'golem',tdAt(R,tw,rg*.92,rg*.98)));
          const hc=[];const h0=rpHurt;rpHurt=function(x,d,ap,src){if(src===tw&&d===RPMBL.eclDmg)hc.push(x);return h0.apply(this,arguments)};let made=0,life=0;
          let E0=null,nv=0;try{for(let k=0;k<5&&!R.mbEclN;k++)tdThrow(R,tw,[c,far]);made=R.mbEclN;E0=R.mbEcl[0];nv=tw.nv;life=E0?E0.t:0;for(let i=0;i<200&&R.mbEcl.length;i++){rpStep(R,1/30);life+=1/30}}finally{rpHurt=h0}
          return [n3,slots,made,nv%5,+life.toFixed(1),hc.filter(x=>x===c).length,hc.filter(x=>x===far).length]}""")
        chk('tier 5 Eclipse: a third glaive (over the helm); every fifth throw an eclipse crescent circles the tower for about 3 s and cuts the monsters on its orbit (not the ones far outside it)',
            r[0]==3 and r[1]=='0,1,2' and r[2]==1 and r[3]==0 and 2.4<=r[4]<=3.1 and r[5]>=1 and r[6]==0,r)
        # ---- target modes
        r=await E("""()=>{const res={};for(const pr of ['first','strong','close']){const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'moon',1),rg=RP_TW.moon.range[0];tw.prio=pr;
           let sN=0,dn=1e9;for(let s=0;s<R.G.paths[0].len;s+=3){const q=rpAt(R.G,s,0),d=Math.sqrt(rpD2(q.x,q.y,tw.x,tw.y));if(d<dn){dn=d;sN=s}}const sF=tdAt(R,tw,rg*.75,rg*.9);const L=R.G.paths[0].len;let sL=null;for(let s=L-10;s>0;s-=3){const q=rpAt(R.G,s,0);if(Math.sqrt(rpD2(q.x,q.y,tw.x,tw.y))<rg*.9){sL=s;break}}
           const a=tdTank(tdFoe(R,'scamp',sN),1e5),b=tdTank(tdFoe(R,'golem',sF),9e6),c=tdTank(tdFoe(R,'scamp',sL),1e5);const t=rpmbTargets(R,tw,1)[0];res[pr]=t===a?'near':t===b?'big':t===c?'lead':'?'}return res}""")
        chk('Target modes: First picks the monster furthest along the road, Strong the toughest, Close the nearest',r=={'first':'lead','strong':'big','close':'near'},r)
        # ---- Overcharge
        r=await E("""()=>{const run=over=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'moon',1),rg=RP_TW.moon.range[0],e=tdTank(tdFoe(R,'golem',tdAt(R,tw,rg*.45,rg*.55)),1e7);tdRun(R,1.5);const n0=R.mbThrows,h0=e.hp,c0=R.mbHits;if(over)tw.over=99;tdRun(R,8);return [R.mbThrows-n0,(h0-e.hp)/(R.mbHits-c0)]};
          const a=run(0),b=run(1);return [a[0],b[0],+(b[0]/a[0]).toFixed(2),+(b[1]/a[1]).toFixed(3)]}""")
        chk('Overcharge: throws come about twice as often and cut 15% harder',r[2]>=1.8 and abs(r[3]-1.15)<0.01,r)
        # ---- jams
        r=await E("""()=>{const R=tdNew('meadow',3),pad=tdPad(R),tw=tdBuild(R,pad,'moon',2),rg=RP_TW.moon.range[1],e=tdTank(tdFoe(R,'golem',tdAt(R,tw,rg*.5,rg*.6)));for(let i=0;i<60&&!R.mbGl.length;i++)rpStep(R,1/30);rpStep(R,1/30);const out=R.mbGl.length;
          rpwJam(R,tw,3,'emp');const h=e.hp,n0=R.mbThrows;tdRun(R,.2);const home=R.mbGl.every(g=>g.home);tdRun(R,2.6);const d=Math.round(h-e.hp),n1=R.mbThrows-n0;tdRun(R,2.5);return [out,tw.jam>0||true,home,d,n1,R.mbThrows-n0>0,tw.mbOut]}""")
        chk('a jam (EMP): the glaive in flight loses its edge and flies home, no new throws and no cuts until the jam ends, then it throws again',r[0]>=1 and r[2] and r[3]==0 and r[4]==0 and r[5],r)
        # ---- hidden and fogged monsters
        r=await E("""()=>{const R=tdNew('abyss',3),pad=tdPad(R),tw=tdBuild(R,pad,'moon',3),rg=RP_TW.moon.range[2],s=tdAt(R,tw,rg*.45,rg*.6);const e=tdTank(tdFoe(R,'leviathan',s));e.dvI=0;e.dive=60;e.hide=1;const h=e.hp;tdRun(R,3);const a=[R.mbThrows,Math.round(h-e.hp)];
          const t2=tdTank(tdFoe(R,'golem',s+10));const h2=t2.hp,hh=e.hp;tdRun(R,3);return [...a,R.mbThrows>0,Math.round(h2-t2.hp)>0,Math.round(hh-e.hp)]}""")
        chk('a hidden monster (a diving Leviathan) is never picked nor cut, even when a glaive thrown at a monster next to it passes through it',r[0]==0 and r[1]==0 and r[2] and r[3] and r[4]==0,r)
        r=await E("""()=>{const R=tdNew('wreck',3);R.fog.forEach(g=>{g.x=-3000;g.v=0});let res='nos';for(const p of R.pads){if(p.tw)rpSell(p.tw);R.foes=[];const tw=tdBuild(R,p,'moon',3);const s=tdAt(R,tw,175,Math.min(230,RP_TW.moon.range[2]*.95));if(s==null){rpSell(tw);continue}
           const e=tdTank(tdFoe(R,'brute',s));const q=rpPos(R,e),f=R.fog[0];f.x=q.x;f.y=q.y;f.rx=60;f.ry=40;const h=e.hp;tdRun(R,4);const fd=e.fogd,d1=Math.round(h-e.hp),n1=R.mbThrows;f.x=-3000;tdRun(R,4);res=[fd,d1,n1,Math.round(h-e.hp)>d1];break}return res}""")
        chk('fog (Shipwreck Cove): a fogged monster beyond 150 px is not picked; once the fog drifts off it is',r!='nos' and r[0]==True and r[1]==0 and r[2]==0 and r[3],r)
        # ---- art
        r=await E("""()=>{const out=[];for(let t=1;t<=5;t++){const c=document.createElement('canvas');c.width=c.height=260;const g=c.getContext('2d');g.translate(130,200);rpTowerDraw(g,'moon',t,'base',1,{});
           const d=g.getImageData(0,0,260,260).data;let n=0;for(let i=3;i<d.length;i+=4)if(d[i]>20)n++;out.push([n,c.toDataURL().length])}
          for(let t=1;t<=5;t++)rpTowerWarm('moon',t,'base');const keys=[1,2,3,4,5].every(t=>RPSPR.has('mb|arm|'+t+'|0')&&RPSPR.has('mb|arm|'+t+'|1')&&RPSPR.has('mb|bl|'+t)&&RPSPR.has('tw|moon|'+t+'|base'))&&RPSPR.has('mb|wk|4')&&RPSPR.has('mb|ecl');
          const ic=rpTowerIcon('moon',1,'base',96);return [out.map(x=>x[0]),new Set(out.map(x=>x[1])).size,ic.width,keys]}""")
        chk('each tier draws differently and grander (tier 5 fuller than tier 3, tier 3 than tier 1); the icon renders; every sprite is baked by the warm-up',r[1]==5 and r[0][2]>r[0][0] and r[0][4]>r[0][2] and r[2]==96 and r[3],r)
        r=await E("""()=>{const out=[];const P=[{mbW:0,mbHold:[1,1,1]},{mbW:1,mbHold:[1,1,1]},{mbT:.6,mbHold:[0,0,0]},{mbT:0,mbHold:[0,0,0]},{mbC:.6,mbHold:[1,1,1]}];
          for(const s of P){const c=document.createElement('canvas');c.width=c.height=220;const g=c.getContext('2d');g.translate(110,170);RPMB_ART.cur=Object.assign({type:'moon',mbSide:1},s);try{rpTowerDraw(g,'moon',3,'base',1,{})}finally{RPMB_ART.cur=null}out.push(c.toDataURL().length)}
          const c=document.createElement('canvas');c.width=c.height=220;const g=c.getContext('2d');const idle=[];for(const t of [0,.8]){g.clearRect(0,0,220,220);g.save();g.translate(110,170);rpTowerDraw(g,'moon',1,'base',t,{});g.restore();idle.push(c.toDataURL().length)}
          return [new Set(out).size,idle[0]!==idle[1]]}""")
        chk('the statue is alive: hold, wind-up, throw, empty open hand and catch are five different poses; it breathes when idle',r==[5,True],r)
        # frame cost per tower (the best of several batches), against the Starfall Observatory
        r=await E("""()=>{if(typeof RPG!=='undefined')RPG.off=1;const c=document.createElement('canvas');c.width=1600;c.height=900;const g=c.getContext('2d');for(let t=1;t<=5;t++){rpTowerWarm('moon',t,'base');rpTowerWarm('star',t,'base')}
          const best=f=>{let m=1e9;for(let k=0;k<7;k++){const t0=performance.now();for(let i=0;i<8;i++)f(i);m=Math.min(m,(performance.now()-t0)/8)}return m};
          const row=ty=>best(f=>{for(let t=1;t<=5;t++){g.save();g.translate(100+t*200,400);if(ty==='moon')RPMB_ART.cur={type:'moon',mbW:(f%8)/8,mbT:0,mbC:0,mbHold:[1,1,1],mbSide:1};rpTowerDraw(g,ty,t,'base',f/30,{aim:.3});RPMB_ART.cur=null;g.restore()}})/5;
          const mb=row('moon'),sf=row('star');if(typeof RPG!=='undefined')RPG.off=0;return [+mb.toFixed(3),+sf.toFixed(3),!!RPG_SRC.moon&&RPG_SRC.moon.length===6,!!RPG_PAR.moon]}""")
        chk('frame cost: one Sentinel draws in about 0.15 ms (or no more than the Starfall Observatory); it is in the 9.9p glow and particle layer',(r[0]<0.15 or r[0]<=1.2*r[1]) and r[2] and r[3],r)
        r=await E("""()=>{const R=tdNew('wonder',40);const pads=R.pads.slice(0,8);for(const p of pads)tdBuild(R,p,'moon',5);for(let k=0;k<30;k++){const f=tdTank(tdFoe(R,k%3?'golem':'gloom',150+k*50,k%2),1e8);f.sp=30}
          for(let i=0;i<300&&!(R.mbGl.length>=10&&R.mbEcl.length);i++)rpStep(R,1/30);const n=R.mbGl.length,ne=R.mbEcl.length,nw=R.mbWake.length;
          const c=document.createElement('canvas').getContext('2d');c.canvas.width=1600;c.canvas.height=900;const sq=RPFX.sq;
          /* only the Sentinel's own layers: wake, shadows, trails, glaives, eclipses, sparks */
          const layer=()=>{R.t+=1/30;c.save();c.globalCompositeOperation='lighter';for(const w of R.mbWake)rpmbWake(c,w.x,w.y,.8,w.tier,w.rot);c.restore();
            if(!R.lite&&!R.rm){c.save();c.globalCompositeOperation='lighter';for(const gl of R.mbGl){const T=gl.tr,m=T.length/3;for(let k=1;k<m;k++)rpmbGhost(c,T[k*3],T[k*3+1],gl.tier,T[k*3+2],.55,1,.5)}c.restore()}
            for(const gl of R.mbGl){c.fillStyle='rgba(8,4,20,.2)';c.beginPath();c.ellipse(gl.X,gl.Y*sq,10,4,0,0,TAU);c.fill();rpmbBlade(c,gl.X,gl.Y*sq-gl.h,gl.tier,gl.spin,.55,1.18,1)}
            for(const E of R.mbEcl){const P=rpmbEclPos(R,E);rpmbEclipse(c,P.X,P.Y*sq-34,5,R.t,1.05,1)}if(!R.lite)for(const f of R.mbFx)rpmbSpark(c,f.x,f.y,.4,5)};
          const best=f=>{let m=1e9;for(let k=0;k<7;k++){const t0=performance.now();for(let i=0;i<8;i++)f();m=Math.min(m,(performance.now()-t0)/8)}return m};
          const obs=()=>{for(const p of pads){c.save();c.translate(p.x,p.y);rpTowerDraw(c,'star',5,'base',R.t,{});c.restore()}};
          let full=1e9,ref=1e9;for(let k=0;k<4;k++){full=Math.min(full,best(layer));ref=Math.min(ref,best(obs))}R.lite=1;const lite=best(layer);R.lite=0;
          return [n,ne,nw,+full.toFixed(3),+lite.toFixed(3),+ref.toFixed(3)]}""")
        chk('frame cost: eight tier 5 Sentinels with their glaives, trails, wake and eclipse draw in well under a millisecond (or no more than eight Observatories when the machine is busy); Performance mode draws less',
            r[0]>=10 and (r[3]<0.8 or r[3]<=1.2*r[5]) and r[4]<=r[3]*1.05,r)
        r=await E("""()=>{const res=[];for(const lite of [0,1]){const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'moon',3),rg=RP_TW.moon.range[2],e=tdTank(tdFoe(R,'golem',tdAt(R,tw,rg*.45,rg*.55)),1e7);R.lite=lite;tdRun(R,.4);
           let n=0;const g0=rpmbGhost;rpmbGhost=function(){n++;return g0.apply(this,arguments)};try{rpDraw()}finally{rpmbGhost=g0}tdRun(R,4);res.push([n,Math.round(1e7-e.hp)])}return res}""")
        chk('Performance mode draws no motion trails, and the glaives cut just as hard',r[0][0]>0 and r[1][0]==0 and r[0][1]==r[1][1],r)
        # ---- info panel, texts, skins
        r=await E("""async()=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'moon',2);R.sel=tw;await new Promise(r=>setTimeout(r,400));const el=document.getElementById('rpinfo');
          const t=el?el.textContent:'';const b=el.getBoundingClientRect(),pr=[...el.querySelectorAll('.rppri button')].map(x=>x.dataset.p).join(',');return [/Glaive damage/.test(t),/Glaives/.test(t),/Throw rate/.test(t),/out and back/.test(t),/armor-piercing/.test(t),/Moonblade Sentinel/.test(t),pr,b.bottom<=780,b.top>=70,/Keen|Twin Moons/.test(t)]}""")
        chk('the info panel shows range, glaive damage, glaives, throw rate, the extras, the target modes and the upgrade, inside the stage',r[:6]==[True]*6 and r[6]=='first,strong,close' and r[7] and r[8] and r[9],r)
        r=await E("""async()=>{try{rpLeave()}catch(e){}rampartsMenu(title);await new Promise(r=>setTimeout(r,500));let ok=false,cnt=false;try{rpHowTo();await new Promise(r=>setTimeout(r,200));const w=ov.querySelector('#rpmod .rphw');ok=!!w&&/Moonblade Sentinel\\./.test(w.textContent)&&/key M/.test(w.textContent);cnt=!!w&&/All thirteen are open/.test(w.textContent)&&!!w.querySelector('.rputw img')}catch(e){}
          const h=HELP.Modes.find(x=>x[0]==='Runestone Tower Defense');return [ok,cnt,!!h&&h[1].includes('Moonblade Sentinel (M, 300 supply)')]}""")
        chk('How to Play and the Help text describe the Moonblade Sentinel (and count thirteen towers)',r==[True,True,True],r)
        r=await E("""async()=>{const S=RPY_SET.moon;const ok=S&&S.length===5&&S.every(x=>RPY_TH[x[0]]);const urls=new Set(['base','m1','m2','m3','m4','m5'].map(k=>rpIconCanvas('moon',3,k,88)));
          const r=RPP();const was=JSON.stringify(r.mast||{});rpyXP('moon');r.mast.moon=RPY_LV[5];rpySync();const own=[1,2,3,4,5].every(n=>r.own['moon:m'+n]);
          let sk=false;try{rpLeave()}catch(e){}try{rampartsMenu(title);await new Promise(r=>setTimeout(r,300));rpSkins(title);await new Promise(r=>setTimeout(r,500));sk=/Moonblade Sentinel/.test(ov.textContent)}catch(e){}
          r.mast=JSON.parse(was);for(let n=1;n<=5;n++)delete r.own['moon:m'+n];save();return [ok,urls.size,own,sk]}""")
        chk('five Tower Mastery skins (themes from RPY_TH) that look different, unlocked by its mastery levels and shown on the Tower Skins screen',r[0] and r[1]==6 and r[2] and r[3],r)
        r=await E("""async()=>{const r=RPP(),was=JSON.stringify(r.mast||{});r.mast={};rpStart('moss');const R=RPX;R.tut=null;R.supply=5000;for(const i of [2,4,6]){rpBuild(R.pads[i],'moon');R.pads[i].tw.build=1}R.wave=0;rpWaveStart();let n=0;while(R.wst!=='build'&&n<30*120){rpStep(R,1/30);n++}
          R.won=true;R.free=false;rpFinish(true);await new Promise(r=>setTimeout(r,2500));const m=ov.querySelector('.rpyres');const out=[m?/Moonblade|Sentinel/.test(m.textContent):false,m?/XP/.test(m.textContent):false,rpyXP('moon')>0];
          try{rpLeave()}catch(e){}r.mast=JSON.parse(was);save();return out}""")
        chk('a battle with Sentinels earns Moonblade mastery XP, listed on the results card',r==[True,True,True],r)
        # ---- a real wave and a Wonderland wave
        r=await E("""()=>{const R=tdNew('moss',6);R.wst='build';const pads=[...R.pads].sort((a,b)=>a.i-b.i);tdBuild(R,pads[2],'moon',3);tdBuild(R,pads[5],'moon',2);tdBuild(R,pads[7],'ballista',3);tdBuild(R,pads[9],'moon',1);R.cd=0;rpWaveStart();let t=0;
          while(R.wst==='run'&&t<240){rpStep(R,1/30);t+=1/30}return [R.wst,R.hp>0,R.mbHits>20,R.foes.filter(e=>!e.dead&&!isFinite(e.hp)).length,R.mbGl.every(g=>isFinite(g.X)&&isFinite(g.Y))]}""")
        chk('a real wave with three Sentinels ends cleanly (no broken monsters or glaives)',r[0]=='build' and r[1] and r[2] and r[3]==0 and r[4],r)
        r=await E("""()=>{const R=tdNew('wonder',30);R.wst='build';for(const p of R.pads.slice(0,5))tdBuild(R,p,'moon',5);for(const p of R.pads.slice(5,9))tdBuild(R,p,'prism',4);R.cd=0;rpWaveStart();let t=0;
          while(R.wst==='run'&&t<300){rpStep(R,1/30);t+=1/30}rpDraw();return [R.wst,R.hp>0,R.mbEclN>0,R.mbWakeN>0,R.pads.filter(p=>p.tw&&p.tw.type==='moon').every(p=>p.tw.mbOut>=0)]}""")
        chk('a Wonderland wave with tier 5 Sentinels ends cleanly, with eclipses and wakes',r[0]=='build' and r[1] and r[2] and r[3] and r[4],r)
        os.makedirs(os.path.join(HERE,'shots'),exist_ok=True);await pg.screenshot(path=os.path.join(HERE,'shots','moon_test.png'))
        chk('no page errors',not er,er[:3])
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
