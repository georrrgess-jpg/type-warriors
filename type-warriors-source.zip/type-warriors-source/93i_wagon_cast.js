/* ===== LANTERN CARAVAN 8.6: Conductor Bogsworth, and a hero who stays behind the wagon =====
   The hero no longer fights. He walks behind the wagon the whole run, saluting when the wagon wins a round and stumbling when it
   is hit, while the caravan's conductor does the work: Conductor Bogsworth, a pot-bellied toad in a too-small cap, rides on the
   crate and lashes monsters with a very long tongue, punches their tickets, blows his whistle when the wheel jams and gives
   running commentary in speech bubbles.
   - wrConductorDraw(g,t,{mode,k,p}): feet at the origin, facing right, about 110 units tall. Modes: idle (taps a boot, checks his
     pocket watch now and then), lash (p 0..1 over 0.6 s: windup, strike at 0.12 s, hold, retract), toot, cheer, sad, think, point.
   - wrTongueDraw: the tongue from his mouth to the monster; wrSay/wrSayDraw: speech bubbles; wrCond(mode,dur) sets his mood.
   - Hero: a damped spring behind the wagon (lags when it pulls away, hurries to catch up), a stride phase tied to his speed over
     the ground (no skating), a forward lean, a bob, a salute (the victory arm pose, partly raised) and a stumble.
   - Pet: follows the hero on its own spring with a hysteresis on walk and idle, a gait clock that runs with its speed, a small
     idle wander, a hop on a kill and a flinch on a hit.
   MON.wrcond (flagged nx, so the Bestiary lists do not pick him up) gives him a thumbnail and lets any monster screen draw him. */
const WRC={x:8,y:-206,s:1.1};/* where he stands on the crate (wagon-local) and his scale */
const WRCP={
 idle:{nh:[34,-30],fh:[-31,-42],mo:0,pf:0,lid:.55,ln:0,hl:0,fw:.2,lk:.4},
 lash:{nh:[46,-58],fh:[-31,-48],mo:1,pf:0,lid:.9,ln:0,hl:0,fw:.3,lk:1},
 toot:{nh:[25,-56],fh:[-31,-46],mo:0,pf:1,lid:1,ln:-.04,hl:0,fw:.25,lk:.6},
 cheer:{nh:[36,-100],fh:[-33,-104],mo:.55,pf:0,lid:1,ln:0,hl:3,fw:.8,lk:0},
 sad:{nh:[26,-14],fh:[-27,-22],mo:0,pf:0,lid:.2,ln:.06,hl:-5,fw:0,lk:-.3},
 think:{nh:[19,-57],fh:[-31,-38],mo:0,pf:0,lid:.7,ln:0,hl:0,fw:.1,lk:.5},
 point:{nh:[52,-66],fh:[-31,-44],mo:.2,pf:0,lid:1,ln:.03,hl:1,fw:.3,lk:1}};
const wrL=(a,b,u)=>a+(b-a)*u;
const wrCF=(g,fill,sx,lw,dk)=>rrkFS(g,fill,sx,lw==null?2.6:lw,dk||'rgba(10,0,40,.22)');
const wrCEl=(g,x,y,rx,ry,fill,sx,lw,rot)=>{g.beginPath();g.ellipse(x,y,rx,ry,rot||0,0,TAU);wrCF(g,fill,sx,lw)};
const wrCSeg=(g,x0,y0,x1,y1,w,col)=>{g.lineCap='round';g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.lineWidth=w+5;g.strokeStyle=WRO;g.stroke();g.lineWidth=w;g.strokeStyle=col;g.stroke()};
function wrConductorDraw(g,t,st){st=st||{};const mode=st.mode&&WRCP[st.mode]?st.mode:'idle',lashP=mode==='lash'?(st.p||0):0;
 let e,T=WRCP[mode];
 if(mode==='lash'){const wd=wrEase(lashP/.07),out=1-wrEase(wrClamp((lashP-.45)/.5,0,1));e=wd*out}else e=mode==='idle'?0:wrEase(st.k==null?1:st.k);
 /* a pocket-watch check every ten seconds while idle */
 const tc=((t%10)+10)%10,pw=mode==='idle'?wrEase(wrClamp((tc-7)/.5,0,1))*wrEase(wrClamp((9.3-tc)/.5,0,1)):0;
 const nhx=wrL(wrL(WRCP.idle.nh[0],T.nh[0],e),23,pw),nhy=wrL(wrL(WRCP.idle.nh[1],T.nh[1],e),-78,pw);
 const fhx=wrL(WRCP.idle.fh[0],T.fh[0],e),fhy=wrL(WRCP.idle.fh[1],T.fh[1],e);
 const mo=wrL(0,T.mo,e)*(mode==='lash'?(lashP<.55?1:1-wrEase((lashP-.55)/.2)):1),pf=wrL(0,T.pf,e),hl=wrL(0,T.hl,e),fw=wrL(WRCP.idle.fw,T.fw,e);
 let ln=wrL(0,T.ln,e);if(mode==='lash')ln=lashP<.07?-.09*wrEase(lashP/.07):.1*(1-wrEase(wrClamp((lashP-.27)/.3,0,1)))-.09*(1-wrEase(wrClamp((lashP-.07)/.04,0,1)))*(lashP<.11?1:0);
 const br=Math.sin(t*2.3)*.9,pul=Math.sin(t*3.1),bl=((t+1.3)%4.2)<.13,lid=bl?0:wrL(WRCP.idle.lid,T.lid,e),look=wrL(WRCP.idle.lk,T.lk,e);
 const hop=mode==='cheer'?-Math.abs(Math.sin(e*Math.PI*3))*7*e:0,tap=mode==='idle'||mode==='think'?Math.max(0,Math.sin(t*5.6))*3.4:0;
 g.save();g.lineJoin='round';g.lineCap='round';g.translate(0,hop);g.rotate(ln);
 /* ground shadow is the caller's job; coat tail first (behind everything) */
 g.beginPath();g.moveTo(-22,-44);g.quadraticCurveTo(-40,-30+Math.sin(t*3)*2,-44,-12+Math.sin(t*3.4)*2);g.lineTo(-20,-10);g.closePath();wrCF(g,'#27336f',null,2.4);
 g.beginPath();g.moveTo(-42,-13+Math.sin(t*3.4)*2);g.lineTo(-20,-10);g.lineWidth=2;g.strokeStyle='#e8b83a';g.stroke();
 /* legs and boots (the near boot taps) */
 wrCEl(g,-11,-8,7,6,'#5aa244',null,2);wrCEl(g,11,-8,7,6,'#5aa244',null,2);
 const boot=(x,y,far)=>{g.save();g.translate(x,y);wrCEl(g,2,-3,14,7.5,far?'#15101e':'#201828',null,2.4);g.fillStyle='#ffffff40';g.beginPath();g.ellipse(-3,-7,6,1.6,0,0,TAU);g.fill();g.fillStyle='#e8b83a';g.fillRect(-1,-9,4,4);g.lineWidth=1;g.strokeStyle=WRO;g.strokeRect(-1,-9,4,4);g.restore()};
 boot(-13,0,true);boot(12,-tap,false);
 /* the far arm with a green signal flag */
 {const sx=-20,sy=-48,ex=(sx+fhx)/2-4,ey=(sy+fhy)/2+9;wrCSeg(g,sx,sy,ex,ey,9,'#27336f');wrCSeg(g,ex,ey,fhx,fhy,8,'#27336f');
  const wv=Math.sin(t*6)*fw*7,tx=fhx-6,ty=fhy-40;g.beginPath();g.moveTo(fhx,fhy+9);g.lineTo(tx,ty);g.lineWidth=4.4;g.strokeStyle=WRO;g.stroke();g.lineWidth=2.2;g.strokeStyle='#8a5a2c';g.stroke();
  g.beginPath();g.moveTo(tx,ty);g.quadraticCurveTo(tx-12,ty+2+wv,tx-26,ty+6+wv*1.5);g.lineTo(tx-24,ty+17+wv*1.4);g.quadraticCurveTo(tx-12,ty+13+wv,tx,ty+12);g.closePath();wrCF(g,'#37c274',null,2.2);
  g.fillStyle='#fffbe8';g.beginPath();g.arc(tx-13,ty+10+wv*.8,3,0,TAU);g.fill();wrCEl(g,fhx,fhy,5,5,'#6cb24e',null,2)}
 /* the body: a navy coat over a big round belly */
 const by=-36+br*.5;g.save();g.translate(0,by);g.scale(1+br*.004,1-br*.006);g.translate(0,-by);
 wrCEl(g,0,by,31,28,'#2b3a86',9,2.8);
 g.beginPath();g.ellipse(0,by,28.5,25.5,0,Math.PI*.18,Math.PI*.82);g.lineWidth=2.6;g.strokeStyle='#e8b83a';g.stroke();
 g.beginPath();g.moveTo(10,by-26);g.lineTo(11,by+27);g.lineWidth=2;g.strokeStyle='#e8b83a';g.stroke();
 for(let i=0;i<4;i++){const y=by-17+i*10.5;g.beginPath();g.arc(10.5,y,3.3,0,TAU);g.fillStyle='#f0c24a';g.fill();g.lineWidth=1.4;g.strokeStyle=WRO;g.stroke();g.fillStyle='#fff7c8';g.beginPath();g.arc(9.4,y-1,1,0,TAU);g.fill()}
 /* pocket-watch chain */
 g.beginPath();g.moveTo(10.5,by-6);g.quadraticCurveTo(24,by+2,22,by+8);g.lineWidth=1.8;g.strokeStyle='#e8b83a';g.stroke();
 if(pw<.05){g.beginPath();g.arc(22,by+11,3.6,0,TAU);g.fillStyle='#f0c24a';g.fill();g.lineWidth=1.4;g.strokeStyle=WRO;g.stroke()}
 g.restore();
 /* head: wide, warty, no neck */
 const hy0=-72;
 wrCEl(g,4,hy0,30,18,'#6cb24e',14,2.8);
 if(pf>.01){const r=7*pf;wrCEl(g,-24,hy0+4,r+2,r+1,'#6cb24e',null,2.4);wrCEl(g,32,hy0+4,r+2,r+1,'#6cb24e',null,2.4)}
 g.fillStyle='#4a8a3a';for(const [x,y,r] of[[-14,-70,2],[-6,-62,1.6],[22,-76,1.8],[28,-68,1.4],[-19,-78,1.5]]){g.beginPath();g.arc(x,y,r,0,TAU);g.fill()}
 /* the throat sac swells with every croak; a little red bow tie */
 {const ry=6+pul*1.8+pf*6;wrCEl(g,9,-52+ry*.2,13+pf*3,ry,'#dfe9a0',null,2.2);
  g.beginPath();g.moveTo(8,-52);g.lineTo(0,-57);g.lineTo(0,-47);g.closePath();wrCF(g,'#c8283e',null,1.8);g.beginPath();g.moveTo(8,-52);g.lineTo(16,-57);g.lineTo(16,-47);g.closePath();wrCF(g,'#a81e34',null,1.8);wrCEl(g,8,-52,2.6,2.6,'#e0384e',null,1.6)}
 /* mouth, under the moustache */
 if(mo>.02){const oy=2+9*mo;g.beginPath();g.ellipse(13,-60+oy*.3,17,oy,0,0,TAU);g.fillStyle='#7a1e3a';g.fill();g.lineWidth=2.4;g.strokeStyle=WRO;g.stroke();g.beginPath();g.ellipse(14,-57+oy*.4,10,Math.min(3.5,oy*.5),0,0,TAU);g.fillStyle='#ff7a9a';g.fill()}
 else{g.beginPath();g.moveTo(-20,-62);g.quadraticCurveTo(6,-51+(mode==='sad'?-6:0),33,-62);g.lineWidth=2.8;g.strokeStyle=WRO;g.stroke()}
 /* two bulging eyes either side of a cap that is far too small */
 const eye=(x,y,sc)=>{g.save();g.translate(x,y);g.scale(sc,sc);g.beginPath();g.arc(0,0,11.5,0,TAU);wrCF(g,'#6cb24e',null,2.6);g.beginPath();g.arc(0,0,8.8,0,TAU);g.fillStyle='#fff6d8';g.fill();
  const px=look*3.4,py=1.4;g.beginPath();g.arc(px,py,4.6,0,TAU);g.fillStyle='#1c1220';g.fill();g.fillStyle='#fff';g.beginPath();g.arc(px-1.4,py-1.6,1.5,0,TAU);g.fill();
  const lc=(1-lid)*17;if(lc>.2){g.save();g.beginPath();g.arc(0,0,8.8,0,TAU);g.clip();g.fillStyle='#5a9a40';g.fillRect(-12,-12,24,lc-1);g.fillStyle=WRO;g.fillRect(-12,-12+lc-1,24,2.2);g.restore()}
  g.beginPath();g.arc(0,0,11.5,0,TAU);g.lineWidth=2.6;g.strokeStyle=WRO;g.stroke();g.restore()};
 eye(-16,-85,1);eye(25,-86,1.04);
 /* the moustache: an enormous handlebar */
 {const tw=Math.sin(t*2)*1.2;g.beginPath();g.moveTo(-20,-72+tw);g.quadraticCurveTo(-30,-62,-14,-64);g.quadraticCurveTo(4,-71,9,-67);g.quadraticCurveTo(14,-71,30,-64);g.quadraticCurveTo(46,-62,36,-73-tw);
  g.lineWidth=11;g.strokeStyle=WRO;g.stroke();g.lineWidth=7.4;g.strokeStyle='#5a3416';g.stroke();g.lineWidth=2;g.strokeStyle='#8a5a30';g.beginPath();g.moveTo(-12,-66);g.quadraticCurveTo(4,-72,9,-68.5);g.stroke();
  for(const [x,y] of[[-20,-72+tw],[36,-73-tw]]){g.beginPath();g.arc(x,y,3.2,0,TAU);g.fillStyle='#5a3416';g.fill();g.lineWidth=1.6;g.strokeStyle=WRO;g.stroke()}}
 /* the cap */
 g.save();g.translate(0,-hl*.8);if(mode==='sad'){g.translate(7,4);g.rotate(.22)}
 g.beginPath();g.moveTo(-14,-91);g.quadraticCurveTo(-15,-110,4,-110);g.quadraticCurveTo(23,-110,22,-91);g.closePath();wrCF(g,'#232e72',4,2.6);
 g.beginPath();g.rect(-14,-98,36,6.4);g.fillStyle='#f0c24a';g.fill();g.lineWidth=1.6;g.strokeStyle=WRO;g.stroke();
 g.beginPath();g.arc(4,-102,4.6,0,TAU);wrCF(g,'#f0c24a',null,1.8);g.fillStyle='#232e72';g.fillRect(2.6,-104.4,2.8,4.4);
 g.beginPath();g.moveTo(14,-91);g.quadraticCurveTo(36,-92,40,-85);g.quadraticCurveTo(26,-86,13,-87.5);g.closePath();wrCF(g,'#171a40',null,2.2);g.restore();
 /* the near arm: tongs and a ticket, a pocket watch, or a whistle */
 {const sx=21,sy=-48,ex=(sx+nhx)/2+1,ey=(sy+nhy)/2+9;wrCSeg(g,sx,sy,ex,ey,9.4,'#2b3a86');wrCSeg(g,ex,ey,nhx,nhy,8.4,'#2b3a86');
  g.beginPath();g.arc(ex+(nhx-ex)*.62,ey+(nhy-ey)*.62,5.2,0,TAU);g.fillStyle='#f0c24a';g.fill();g.lineWidth=1.4;g.strokeStyle=WRO;g.stroke();
  if(mode==='toot'){g.beginPath();g.ellipse(nhx+7,nhy-3,9,3.8,-.35,0,TAU);wrCF(g,'#f0c24a',null,2);g.beginPath();g.arc(nhx-2,nhy-1,2.6,0,TAU);g.lineWidth=1.6;g.strokeStyle='#d9a441';g.stroke()}
  else if(pw>.05){g.beginPath();g.arc(nhx+2,nhy-4,6.4,0,TAU);wrCF(g,'#f0c24a',null,2);g.beginPath();g.arc(nhx+2,nhy-4,4.6,0,TAU);g.fillStyle='#fffbe8';g.fill();g.beginPath();g.moveTo(nhx+2,nhy-4);g.lineTo(nhx+2,nhy-7.6);g.moveTo(nhx+2,nhy-4);g.lineTo(nhx+4.6,nhy-3);g.lineWidth=1.3;g.strokeStyle=WRO;g.stroke()}
  else{g.beginPath();g.moveTo(nhx,nhy);g.lineTo(nhx+14,nhy-9);g.moveTo(nhx,nhy);g.lineTo(nhx+15,nhy+1);g.lineWidth=5;g.strokeStyle=WRO;g.stroke();g.lineWidth=2.4;g.strokeStyle='#d8d4e8';g.stroke();
   g.beginPath();g.rect(nhx+12,nhy-6,9,7);g.fillStyle='#fff3d0';g.fill();g.lineWidth=1.4;g.strokeStyle=WRO;g.stroke();g.fillStyle='#e8364e';g.beginPath();g.arc(nhx+16.5,nhy-2.5,1.5,0,TAU);g.fill()}
  wrCEl(g,nhx,nhy,5.2,5.2,'#6cb24e',null,2)}
 g.restore()}
/* a head-and-shoulders medallion for menus */
function wrCondPortrait(cv,t){const g=cv.getContext('2d'),w=cv.width,h=cv.height,r=Math.min(w,h)/2,lw=Math.max(3,r*.09);g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,w,h);
 g.save();g.beginPath();g.arc(w/2,h/2,r-lw*.5,0,TAU);g.clip();const q=g.createRadialGradient(w/2,h*.4,r*.1,w/2,h/2,r);q.addColorStop(0,'#4a3a9a');q.addColorStop(1,'#1c1446');g.fillStyle=q;g.fillRect(0,0,w,h);
 const s=r/42;g.translate(w/2-2*s,h/2+68*s);g.scale(s,s);wrConductorDraw(g,t,{mode:'idle'});g.restore();
 g.beginPath();g.arc(w/2,h/2,r-lw*.5,0,TAU);g.lineWidth=lw;g.strokeStyle='#ffd45a';g.stroke();g.lineWidth=lw*.35;g.strokeStyle=WRO;g.stroke()}
/* he is a monster too: a thumbnail for any monster screen (flagged nx so the Bestiary lists skip him) */
MON.wrcond={n:'Conductor Bogsworth',h:150,sp:40,th:114,tw:130,cx:0,nx:1,d:(g,t,o)=>{g.save();g.scale(-1,1);wrConductorDraw(g,t,{mode:(o&&o.lg>.3)?'lash':'idle',p:(o&&o.lg)||0});g.restore()}};
/* ---------- conduct the run ---------- */
const WR_SAY={
 kill:['Punched!','Ticket, please!','No ticket, no ride!','Next!','Bwarp!','Tut, tut!','Mind the gap!','All aboard! ...not you.','Thwap!','Terminus for you!'],
 haz:['Delay on the line!','Signal failure!','Wheel trouble! PHWEET!','Not on my timetable!'],
 fix:['Back on schedule!','Tickets all round!','Smooth as a ledger!'],
 hit:['Hrrk! My timetable!','Mind the paintwork!','Ow! First class!','Bwuh!'],
 flare:['FULL STEAM AHEAD!','Lanterns blazing!','Stand clear!'],
 gate:['Right on time!','Terminus! Tickets, please!','All change!'],
 broke:['Service cancelled...','Refunds at the gate...'],
 start:['All aboard! Tickets, please!','Mind the doors!','Next stop: the gate!'],
 boss:['That one has NO ticket!','Unauthorised horse!']};
function wrSay(kind,force){const R=WRX;if(!R)return;if(!force&&R.t<(R.sayT||0))return;const L=WR_SAY[kind];if(!L)return;R.say={txt:L[Math.random()*L.length|0],t0:R.t,dur:force?2.4:1.8};R.sayT=R.t+(force?1.4:2.8)}
function wrSayDraw(c,R){const q=R.say;if(!q||R.over&&S.mode!=='wagon')return;const a=R.t-q.t0;if(a>q.dur){R.say=null;return}const k=wrClamp(a/.28,0,1),s=R.rm?1:.6+.4*wrOver(k),al=Math.min(1,a*7,(q.dur-a)*4);
 c.save();c.globalAlpha=al;c.font='700 15px Poppins,system-ui,sans-serif';const w=c.measureText(q.txt).width+30,h=32,cx=WRT.WX+(R.ox||0)-4,bob=(R.bobY||0),bx=cx-w/2,by=GY+WRC.y-WRC.s*120-h-20+bob;
 c.translate(cx,by+h+10);c.scale(s,s);c.translate(-cx,-(by+h+10));c.fillStyle='#fff8e8';c.strokeStyle=WRO;c.lineWidth=2.4;c.beginPath();c.roundRect(bx,by,w,h,12);c.fill();c.stroke();
 c.beginPath();c.moveTo(cx+4,by+h-1);c.lineTo(cx+16,by+h-1);c.lineTo(cx+12,by+h+11);c.closePath();c.fill();c.beginPath();c.moveTo(cx+4,by+h);c.lineTo(cx+12,by+h+11);c.lineTo(cx+16,by+h);c.stroke();c.fillStyle='#fff8e8';c.fillRect(cx+5,by+h-3,10,4);
 c.fillStyle='#2a1a40';c.textAlign='center';c.textBaseline='middle';c.fillText(q.txt,cx,by+h/2+1);c.restore()}
function wrCond(mode,dur){const R=WRX;if(!R)return;if(R.cond&&R.cond.mode==='lash'&&mode!=='lash'&&R.t-R.cond.t0<R.cond.dur*.7)return;R.cond={mode,t0:R.t,dur:dur||1}}
/* draws him on the crate inside the wagon's bobbing transform (called from 93h) */
function wrCondDraw(c,R){const q=R.cond,t=S.t;let st={mode:'idle'};
 if(q){const a=R.t-q.t0;if(q.mode==='lash'){if(a>=q.dur)R.cond=null;else st={mode:'lash',p:a/q.dur}}else{if(a>=q.dur+.3)R.cond=null;else{let k=1;if(a<.25)k=a/.25;else if(a>q.dur)k=Math.max(0,1-(a-q.dur)/.3);st={mode:q.mode,k}}}}
 c.save();c.translate(WRC.x,WRC.y);c.scale(WRC.s,WRC.s);wrConductorDraw(c,t,st);c.restore()}
/* where his mouth is on screen (the wagon's tilt is small enough to ignore) */
function wrMouthXY(R){const cb=R.v>5?Math.sin(R.wheel*2.1-.5)*3:0,bob=R.v>5?Math.sin(R.wheel*2.1)*2.2:0;R.bobY=bob;return[WRT.WX+(R.ox||0)+WRC.x+WRC.s*24,GY+WRC.y-WRC.s*60+cb+bob]}
/* the lash: windup 0..0.07, strike (the tongue reaches the monster at 0.12 s, exactly when its hit flash starts), hold, retract */
function wrHeroStrike(e){const R=WRX;if(!R)return;R.cond={mode:'lash',t0:R.t,dur:.6,e,hit:0};R.heroCheer=Math.max(R.heroCheer||0,.55);wrSfx('lash');if(Math.random()<.42)wrSay('kill')}
function wrTongueDraw(c,R){const q=R.cond;if(!q||q.mode!=='lash')return;const p=(R.t-q.t0)/q.dur,e=q.e;if(!e||p>=1)return;
 const ext=p<.07?0:p<.2?wrEase((p-.07)/.13):p<.27?1:1-wrEase((p-.27)/.33);if(ext<=.005)return;
 const [rx,ry]=wrMouthXY(R),tx=e.x-(e.lg||0)*64,ty=e.y-e.h*.5;
 if(!q.hit&&p>=.2){q.hit=1;ptBurst(R.fx,tx,ty,R.rm?6:16,['#ff9ab0','#fff0f4','#ffd45a'],{v:300,s:4.5,g:160,l:.55});wrRing(tx,ty,'#ff9ab0',150,6);if(!R.rm)R.shake=Math.max(R.shake,5);if(Math.random()<.3)wrText(tx,ty-e.h*.5-30,'THWAP!','#ff9ab0',26)}
 const x=rx+(tx-rx)*ext,y=ry+(ty-ry)*ext,sag=(1-ext*.7)*18*Math.sin(Math.PI*Math.min(1,ext)),mx=(rx+x)/2,my=(ry+y)/2-ext*(24+.14*Math.hypot(tx-rx,ty-ry));
 c.save();c.lineCap='round';c.lineJoin='round';
 const wv=R.rm?0:Math.sin(p*38)*3*(1-Math.min(1,ext));
 c.beginPath();c.moveTo(rx,ry);c.quadraticCurveTo(mx,my+wv,x,y);c.lineWidth=11;c.strokeStyle=WRO;c.stroke();c.lineWidth=7;c.strokeStyle='#ff7a9a';c.stroke();c.lineWidth=2.2;c.strokeStyle='#ffc4d2';c.beginPath();c.moveTo(rx,ry-1.5);c.quadraticCurveTo(mx,my+wv-1.5,x,y-1.5);c.stroke();
 c.beginPath();c.arc(x,y,7.6,0,TAU);c.fillStyle='#ff7a9a';c.fill();c.lineWidth=2.4;c.strokeStyle=WRO;c.stroke();c.fillStyle='#ffd0dc';c.beginPath();c.arc(x-2.4,y-2.4,2.4,0,TAU);c.fill();c.restore()}
/* ---------- the conductor's reactions ---------- */
{const f=wrHazOpen;wrHazOpen=function(){const r=f.apply(this,arguments);wrCond('toot',1.2);wrSfx('toot');wrSay('haz',true);const R=WRX;if(R){const[x,y]=wrMouthXY(R);ptBurst(R.fx,x+6,y-4,R.rm?3:8,'#f4f0ff',{k:'dust',v:60,up:1,sp:1.6,g:-30,l:.8,s:5})}return r}}
{const f=wrRepair;wrRepair=function(){const r=f.apply(this,arguments);wrCond('cheer',1);wrSay('fix',true);const R=WRX;if(R)R.heroCheer=Math.max(R.heroCheer||0,.8);return r}}
{const f=wrHit;wrHit=function(e,why){const R=WRX,h=R&&R.hs;const r=f.apply(this,arguments);if(R&&R.st!=='break'){wrCond('sad',1);wrSfx('croak')}wrSay(R&&R.st==='break'?'broke':'hit',true);if(h){h.hv-=150;h.flin=.6}return r}}
{const f=wrFlare;wrFlare=function(){const R=WRX,on=R&&R.flareOn>0,r=f.apply(this,arguments);if(R&&!on&&R.flareOn>0){wrCond('cheer',1.6);wrSay('flare',true);R.heroCheer=1.4}return r}}
{const f=wrGate;wrGate=function(){const R=WRX,st=R&&R.st,r=f.apply(this,arguments);if(R&&st==='roll'&&R.st==='gate'){wrCond('cheer',2.6);wrSay('gate',true)}return r}}
{const f=wrStart;wrStart=function(){const r=f.apply(this,arguments);if(WRX){wrCond('point',1.6);WRX.sayT=0;setTimeout(()=>{if(WRX&&S.wr)wrSay('start',true)},700)}return r}}
{const f=wrSpawn;wrSpawn=function(id){const e=f.apply(this,arguments);if(e&&e.boss&&WRX&&WRX.boss===e)wrSay('boss',true);return e}}
{const f=wrBreak;wrBreak=function(){const R=WRX,r=f.apply(this,arguments);if(R){wrCond('sad',9)}return r}}
/* ---------- the hero: behind the wagon, never fighting ---------- */
const WRHS0={x:0,hv:0,ph:0,wb:0,pu:0,flin:0,g:0};
function wrMotion(R,dt){const h=R.hs||(R.hs={x:0,hv:0,ph:0,wb:0,pu:0,flin:0,g:0});
 /* a damped spring behind the wagon: it lags when the wagon pulls away and hurries to catch up (about 6 rad/s, nearly critically damped) */
 const acc=R.accel||0,tgt=R.st==='break'?0:wrClamp(-acc*.11,-24,18);
 h.hv+=((tgt-h.x)*38-h.hv*12)*dt;h.x+=h.hv*dt;
 /* the feet follow the ground: his speed over it is the road's speed plus how fast he moves on screen */
 const g=Math.max(0,(R.st==='break'?0:R.v)+h.hv);h.g+=(g-h.g)*Math.min(1,dt*10);h.ph+=h.g/60*8*dt;
 h.wb+=(wrEase(wrClamp(h.g/14,0,1))-h.wb)*Math.min(1,dt*8);
 h.flin=Math.max(0,h.flin-dt);
 /* the salute: the victory arm pose, partly raised and eased */
 R.heroCheer=Math.max(0,(R.heroCheer||0)-dt);const want=R.heroPose==='victory'?1:R.heroCheer>0?.72:0;h.pu+=(want-h.pu)*Math.min(1,dt*(want>h.pu?11:6));
 /* the pet */
 const p=R.ps||(R.ps={x:WRT.PX,v:0,clk:0,walk:0,dw:0,wb:0,hv:0});
 const ptx=WRT.HX+h.x-100-(R.v>10?acc*.05:0)+(R.v<5?Math.sin(R.t*.31)*9:0);p.v+=((ptx-p.x)*20-p.v*9)*dt;p.x+=p.v*dt;p.hv=p.v;
 const pg=Math.max(0,(R.st==='break'?0:R.v)+p.v);p.dw+=dt;
 if(!p.walk&&pg>14&&p.dw>.25){p.walk=1;p.dw=0}else if(p.walk&&pg<6&&p.dw>.3){p.walk=0;p.dw=0}
 p.wb+=((p.walk?1:0)-p.wb)*Math.min(1,dt*6);p.clk+=dt*(p.walk?.55+.75*wrClamp(pg/70,0,1.3):1)}
{const u0=wrUpdate;wrUpdate=function(dt){const R=WRX,r=u0.apply(this,arguments);if(WRX&&WRX===R&&!R.pause)wrMotion(R,Math.min(dt,.05));return r}}
function wrHeroDraw(c,R){const h=R.hs||WRHS0,b=Math.sin(S.t*2.3),syy=1+b*.011,sxx=1-b*.006,acc=R.accel||0;let hop=0,pu=h.pu;
 if(R.heroPose==='victory'){hop=-Math.abs(Math.sin((R.poseT||0)*5.5))*22*Math.min(1,(R.poseT||0)/.5)}
 else if(R.heroCheer>1){hop=-Math.abs(Math.sin(R.t*9))*6*wrClamp((R.heroCheer-1)*3,0,1)}
 const bob=h.wb*Math.abs(Math.sin(h.ph))*1.9,lean=wrClamp(acc*.0006+h.wb*.025,-.05,.07);
 c.save();c.translate(WRT.HX+h.x+(R.ox||0),GY);c.fillStyle='#0007';c.beginPath();c.ellipse(0,6,58,10,0,0,TAU);c.fill();
 const col=WCOL();glow(c,0,-100,120,col+'22');c.translate(0,hop-bob);c.rotate(lean);c.scale(1.5*sxx,1.5*syy);
 if(h.flin>0&&Math.floor(S.t*20)%2)c.globalAlpha=.55;
 drawHero(c,{arm:P.armor,wp:P.weapon,col:P.col,t:S.t,lg:0,wb:h.wb,wph:h.ph,pose:R.heroPose||(pu>.02?'victory':null),pu});c.restore()}
function wrPetDraw(c,R){const id=P.pet;if(!id||!PDEF[id])return;const p=R.ps||{x:WRT.PX,clk:0,wb:0,walk:0,v:0},hv=PDEF[id].hover;
 const hk=(R.t-(R.petHop||-9))/.38,fk=(R.t-(R.petFl||-9))/.34,hop=hk>=0&&hk<1?-Math.sin(hk*Math.PI)*13:0,fl=fk>=0&&fk<1?Math.sin(fk*Math.PI*3)*(1-fk)*7:0;
 const pose=R.heroPose==='victory'?{pose:'greet',u:(((R.poseT||0)%2.2)/2.2)}:p.walk?{pose:'walk',u:0}:{pose:'idle',u:0},tt=p.clk||S.t;
 c.save();c.translate(p.x+(R.ox||0)-fl,GY+2-(hv?34:0)+hop);c.rotate(-fl*.012);c.scale(.95,.95);petDraw(c,id,Object.assign({t:tt,pose:pose.pose,u:pose.u,noSh:hv||hop?1:0},petLook(id)));c.restore()}
