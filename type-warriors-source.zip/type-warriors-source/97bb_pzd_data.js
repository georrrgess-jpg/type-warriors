/* ===== 10.7 THE CROOKED CUE: The Gilded Hoard, a third venue (97bb): data, save, unlocks, money limits, AI style =====
   A dragon's treasure vault turned high-roller room. Five players climb a ladder that starts above Mortimer and Empress Vantara:
   Clasp (a mimic chest, the doorman), Zephyra (a smoke genie dealer), Sir Brassknuckle (a clockwork golem bouncer), Baron Hornsby
   (a minotaur high roller) and the boss, Aurelion the Hoardwing (an ancient gold dragon banker). They live in PZ_REG like the
   regulars and the Orbit 8 players, so the match flow, "wise to you", the 20 paid matches a day, resume and the results all work
   unchanged. Ladder: PZD_ORDER. Open once you beat Mortimer (the tavern champion) or Empress Vantara (the Orbit 8 boss).
   Money: this room alone takes stakes up to 10,000 (PZD_STAKE) and pays up to 50,000 (PZD_CAP); the tavern and Orbit 8 keep
   casCap('pz') = 5,000 and PZ_CAP = 15,000. The pool functions that used those two constants inline are re-declared here with the
   room's own limit (pzdStakeCap / pzdCap; a later function declaration wins and every wrapper still wraps it): pzMultS, pzStakeOf,
   pzStart, pzExtend and pzMatchEnd (bodies identical to 96a / 96i / 96j apart from the limit), so money still moves only through
   cTake / cPay inside the game's own code and the cheat guard (00a / 98t / 98v) sees nothing new.
   Save: P.pz.venue may be 'hoard' (97b1's pznNorm accepts it), P.pz.hoard {seen}. AI style `gild` (Aurelion): the fewer of his own
   balls are left, the sharper he gets (pzdAiK, shared with tools/pz/pzd_bal.js). Prefix pzd / PZD_. */
const PZD_ORDER=['clasp','zephyra','brass','hornsby','aurelion'];
const PZD_CAP=50000,PZD_STAKE=10000;
const PZD={bk:null,ms:0,last:-1,open0:null,vopen0:false,prevSel:null,fx:[]};
Object.assign(PZ_REG,{
 clasp:{id:'clasp',n:'Clasp',k:'The Vault Doorman',c:'#ffb43a',lvl:6,race:2,stakes:[2500,3000,4000,5000],mult:2,floor:1.6,venue:'hoard',
  ai:{sig:1.05,psig:.06,pos:.35,safe:.12,sTry:10,look:5,over:1.12,brk:.9},
  house:{},houseTxt:'No house rule: plain 8-ball. Mind your fingers near the lid.',cue:'pzd_clasp',skin:'#a8642a',
  voice:{f:150,t:'square',w:.35,creak:1},quirk:'His lid snaps open and shut, his tongue licks a gold coin and he guards the door with his life.',
  lines:{hi:['*CLACK* Welcome to the Hoard. Wipe your feet. Show me your gold.','Members only. And you look like a member. Barely.'],pot:['*CHOMP* Mine!','Into the box it goes.'],miss:['Hinge slipped.','Who put a pocket THERE?'],
   you:['Ooh, shiny shot.'],foul:['Sticky fingers, eh?'],win:['Lid closed. Gold kept.'],lose:['Fine. You may pass... this time.'],taunted:['*SNAP* WATCH IT!']},
  taunts:['empty chest','unlock this','tongue tied','rusty hinges']},
 zephyra:{id:'zephyra',n:'Zephyra',k:'The Smoke Dealer',c:'#4ae0d0',lvl:6,race:2,stakes:[2500,5000,7500],mult:2.6,floor:1.9,venue:'hoard',
  ai:{sig:.92,psig:.05,pos:.6,safe:.3,sTry:22,look:6,spin:1,brk:.7},
  house:{winnerBreaks:1},houseTxt:'House deals: whoever won the last rack breaks the next.',cue:'pzd_zephyra',skin:'#3ac8c0',
  voice:{f:540,t:'sine',w:.25,echo:1},quirk:'She curls out of her lamp in rings of smoke and her bangles chime with every move.',
  lines:{hi:['Three wishes, darling? I grant one: a lovely game.','Rub the lamp, take the cue. The house always deals.'],pot:['As you wish.','Poof. Gone.'],miss:['A puff of bad luck.','The smoke got in my eyes.'],
   you:['Oh, that was magic.'],foul:['Wish for better aim next time.'],win:['Back in the lamp you go.'],lose:['Your wish... is granted.'],taunted:['How RUDE. *poof*']},
  taunts:['blow smoke','lamp oil','wish you luck','genie in a bottle']},
 brass:{id:'brass',n:'Sir Brassknuckle',k:'The Clockwork Bouncer',c:'#e8a040',lvl:7,race:3,stakes:[5000,6000,7500],mult:3.3,floor:2.3,venue:'hoard',
  ai:{sig:.84,psig:.04,pos:.55,safe:.45,sTry:28,look:6,soft:.92,brk:.6},
  house:{shortGuide:1},houseTxt:'Bolted shut: the aim guide is short (no long object-ball line).',cue:'pzd_brass',skin:'#c8862a',
  voice:{f:95,t:'sawtooth',w:.02,robot:1},quirk:'Steam hisses from his vents, his gears turn and he polishes his knuckles between racks.',
  lines:{hi:['HALT. STATE YOUR BUSINESS. ...POOL? ACCEPTABLE.','I WAS BUILT TO GUARD GOLD. AND CORNER POCKETS.'],pot:['CLUNK. SECURED.','BALL ESCORTED OUT.'],miss:['GEAR SLIPPAGE.','RECALIBRATING SPRINGS.'],
   you:['*whirr* IMPRESSIVE.'],foul:['RULE BREACH. NOTED.'],win:['YOU ARE ESCORTED FROM THE PREMISES.'],lose:['STEAM... PRESSURE... FALLING.'],taunted:['*HISSSS* OVERHEATING!']},
  taunts:['rusty bucket','loose screw','scrap metal','out of steam']},
 hornsby:{id:'hornsby',n:'Baron Hornsby',k:'The High Roller',c:'#ff5a6a',lvl:7,race:3,stakes:[5000,7500,10000],mult:4,floor:2.7,venue:'hoard',
  ai:{sig:.74,psig:.04,pos:.5,safe:.15,sTry:12,look:6,over:1.1,brk:.45,streak:1},
  house:{clock:30},houseTxt:'High stakes, no stalling: a 30-second shot clock.',cue:'pzd_hornsby',skin:'#7a4a2a',
  voice:{f:120,t:'sawtooth',w:.12},quirk:'He adjusts his monocle, snorts steam and spins a gold coin across his knuckles.',
  lines:{hi:['Baron Hornsby. Charmed. I never play for less than a small fortune.','Shall we make this interesting? It already is.'],pot:['Ha! Into the pen.','Splendid. Splendid!'],miss:['Hmph. The monocle slipped.','A mere rounding error.'],
   you:['Bravo! A shot worth its weight in gold.'],foul:['Tsk. Frightfully clumsy.'],win:['Put it on my tab. Oh wait, you pay.'],lose:['I... shall need a fresh monocle.'],taunted:['How DARE you, sir!']},
  taunts:['bull market','see red','moo money','horn of plenty']},
 aurelion:{id:'aurelion',n:'Aurelion the Hoardwing',k:'Banker of the Deep Vault',c:'#ffd45a',lvl:7,race:3,stakes:[5000,7500,10000],mult:5,floor:3.2,venue:'hoard',
  ai:{sig:.6,psig:.025,pos:.9,safe:.38,sTry:30,look:8,spin:1,brk:.35,clutch:.75,gild:1},
  house:{proGuide:1},houseTxt:'Dragon’s eye: you see the aim line and nothing beyond it.',cue:'pzd_aurelion',skin:'#e8b030',
  voice:{f:85,t:'sine',w:.06,echo:1},quirk:'He counts coins with one claw, smoke curls from his nostrils and his hoard glitters under him.',
  lines:{hi:['Every coin in this vault was once someone’s confident little wager.','Sit, little one. The Hoardwing is accepting deposits.'],pot:['Deposited.','Mine, as all things are.'],miss:['A flicker of the flame. Nothing more.'],
   you:['Hm. You glitter more than I expected.'],foul:['Careless. I shall take that as interest.'],win:['Your gold sleeps with mine now.'],lose:['IMPOSSIBLE. My hoard... my beautiful hoard...'],taunted:['You DARE taunt a DRAGON?']},
  taunts:['fool’s gold','dragon breath','gold digger','hoard of nothing']}});
/* how each one thinks before a shot (seconds of routine, practice strokes, chalk) */
Object.assign(PZ_THINK,{clasp:{dur:.85,pr:1,chalk:0},zephyra:{dur:1.2,pr:2,chalk:1},brass:{dur:1.5,pr:1,chalk:1},hornsby:{dur:1,pr:1,chalk:1},aurelion:{dur:1.4,pr:1,chalk:1}});
Object.assign(PZ_MONH,{clasp:330,zephyra:410,brass:400,hornsby:440,aurelion:460});
Object.assign(PZ_TIPS,{clasp:'Hits hard and rarely plays safe. Leave him a long shot and he will often blast it.',
 zephyra:'Uses spin and plays position well. Winner breaks here, so a rack win is worth double.',
 brass:'Slow, solid and the safety king of the vault. Take your chances when you get them; he rarely gives two.',
 hornsby:'Never stalls and gets sharper on a run. Break his streaks early: one miss and he cools off.',
 aurelion:'Near perfect, and sharper as his hoard of balls shrinks and on the 8. You only get the aim line.'});
Object.assign(PZ97_HOUSE,{clasp:'None. Plain 8-ball.',zephyra:'Winner breaks.',brass:'Short aim guide only.',hornsby:'30-second shot clock.',aurelion:'Aim line only.'});
Object.assign(PZ97_PLATE,{clasp:'Clasp',zephyra:'Zephyra',brass:'Brassknuckle',hornsby:'Hornsby',aurelion:'Aurelion'});
Object.assign(PZ_SHORT,{clasp:'Clasp',zephyra:'Zephyra',brass:'Brass',hornsby:'Hornsby',aurelion:'Aurelion'});
/* the stake chips this room adds (the others keep their colours) */
Object.assign(PZ_CHIPC,{2500:'#2a8a5a',6000:'#b03a8a',7500:'#3a3ad8',10000:'#ffd45a'});
/* the cues they play with (match only: they are not in PZ_CUES, so the Cue Rack is unchanged) */
const PZD_CUES={
 pzd_clasp:{id:'pzd_clasp',n:'Hinge Pin',a:'#f4e2b8',b:'#c8862a',c:'#4a2008',d:'#ffb43a',wrap:'#2a1004',glow:'#ffd45a'},
 pzd_zephyra:{id:'pzd_zephyra',n:'Lamp Wand',a:'#e8fff8',b:'#7ae8d8',c:'#14304a',d:'#4ae0d0',wrap:'#081820',glow:'#8af8e8'},
 pzd_brass:{id:'pzd_brass',n:'Piston Rod',a:'#fff0c8',b:'#d8a040',c:'#3a2008',d:'#e8a040',wrap:'#1a1004',glow:'#ffc860'},
 pzd_hornsby:{id:'pzd_hornsby',n:'Gilded Horn Cane',a:'#fff4e0',b:'#e8c890',c:'#4a0a14',d:'#ff5a6a',wrap:'#240408',glow:'#ff9aa0'},
 pzd_aurelion:{id:'pzd_aurelion',n:'Hoardwing Spire',a:'#fff8d8',b:'#ffd45a',c:'#5a2a04',d:'#ffe890',wrap:'#2a1402',glow:'#ffe27a'}};
{const f0=pzCueSprite;pzCueSprite=function(id){const d=PZD_CUES[id];if(!d||PZ_CUES.some(c=>c.id===id))return f0.apply(this,arguments);PZ_CUES.push(d);try{return f0.apply(this,arguments)}finally{const i=PZ_CUES.indexOf(d);if(i>=0)PZ_CUES.splice(i,1)}}}
/* ---------- the room's limits ---------- */
const pzdIs=id=>PZD_ORDER.includes(id);
function pzdCap(id){return pzdIs(id)?PZD_CAP:PZ_CAP}
function pzdStakeCap(id){return pzdIs(id)?PZD_STAKE:casCap('pz')}
/* ---------- save and unlocks ---------- */
function pzdVenueOpen(Z){Z=Z||PZS();return (Z.beat.mortimer||0)>0||(Z.beat.vantara||0)>0}
function pzdOpen(id){const Z=PZS(),i=PZD_ORDER.indexOf(id);if(i<0||!pzdVenueOpen(Z))return false;return i===0||(Z.beat[PZD_ORDER[i-1]]||0)>0}
function pzdNorm(Z){if(!Z.hoard||typeof Z.hoard!=='object'||Array.isArray(Z.hoard))Z.hoard={seen:0};if(typeof Z.hoard.seen!=='number'||!isFinite(Z.hoard.seen)||Z.hoard.seen<0)Z.hoard.seen=0;
 if(Z.venue==='hoard'&&!pzdVenueOpen(Z))Z.venue='tavern';
 for(const k of PZD_ORDER){for(const o of[Z.beat,Z.rep])if(k in o){const v=o[k];if(typeof v!=='number'||!isFinite(v)||v<0)delete o[k];else o[k]=Math.floor(v)}}
 /* a stored live match against a Hoard player must respect this room's limits (and the others theirs) */
 const L=Z.live;if(L&&(L.stake>pzdStakeCap(L.opp)&&!L.practice))Z.live=null;return Z}
{const f0=PZS;PZS=function(){const Z=f0.apply(this,arguments);try{pzdNorm(Z)}catch(e){}return Z}}
{const f0=pzOpen;pzOpen=function(id){if(pzdIs(id))return pzdOpen(id);return f0.apply(this,arguments)}}
/* ---------- money: the pool functions that used the 5,000 / 15,000 limits inline, now per room ---------- */
/* a win never pays more than the room's ceiling: the multiplier shrinks to fit the stake (5,000 x 3.0 = 15,000; 10,000 x 5.0 = 50,000) */
function pzMultS(id,stake){const m=pzMult(id);return stake>0?Math.min(m,Math.floor(pzdCap(id)/stake*100)/100):m}
function pzStakeOf(id){PZ.stk=PZ.stk||{};const R=PZ_REG[id],cap=pzdStakeCap(id),list=R.stakes.filter(s=>s<=cap);if(!list.length)return 0;let s=PZ.stk[id];if(!list.includes(s)||s>P.gold)s=list.find(x=>x<=P.gold)||list[0];PZ.stk[id]=s;return s}
function pzStart(o){const R=PZ_REG[o.opp],Z=PZS();if(!R)return false;let stake=o.practice?0:(o.stake||0),practice=!!o.practice;
 const seed=o.resume?o.resume.seed:(o.seed||((Math.random()*1e9)|0));
 if(!o.resume){if(Z.live){pzNote('Finish or forfeit your match in progress first.');return false}
  if(stake&&Z.dayN>=PZ_DAILY){stake=0;practice=true}
  if(stake){if(stake>pzdStakeCap(R.id)){pzNote('That stake is above the table limit.');return false}if(stake>P.gold||!cTake(stake)){pzNote(`You need ${cmn(stake)} gold for that stake. The practice table is free.`);return false}Z.dayN++;
   /* the stake is gone, so the match exists from this instant: a reload during the intro resumes into it */
   Z.live={v:PZ_LIVE_V,pre:1,opp:R.id,stake,mult:o.mult||pzMultS(R.id,stake),race:o.race||R.race,practice:false,extended:false,score:[0,0],rack:1,breaker:0,bnr:0,golden:0,pots:0,banks:0,racks:[],bonus:0,seed,st:null,B:Array.from({length:16},(_,i)=>[i,0,0,1]),pend:null,rattled:0};save()}}
 PZ.tok++;const tok=PZ.tok;PZ.on=true;PZ.hub=false;CAS.on=true;CAS.key=null;PZ.reg=R;PZ.seed=seed;PZ.rng=pzRng(PZ.seed);PZ.paused=false;PZ.lite=false;PZ.silent=false;const race=o.race||R.race;
 PZ.M=pzMatchNew({opp:R.id,stake,mult:o.resume?o.resume.mult:(practice?1:(o.mult||pzMultS(R.id,stake))),race:o.resume?o.resume.race:race,practice,house:Object.assign({},R.house),hustle:!!R.hustler,breaker:0});
 PZ.M.bonus=0;PZ.M.proOnly=true;PZ.M.t0=Date.now();PZ.lastPow=.5;PZ.rattled=0;PZ.tauntOffer=false;PZ.nextTaunt=false;
 if(o.resume){const L=o.resume,M=PZ.M;M.score=L.score.slice();M.rack=L.rack;M.breaker=L.breaker;M.bnr=L.bnr;M.golden=L.golden;M.pots=L.pots;M.banks=L.banks;M.racks=L.racks||[];M.bonus=L.bonus||0;M.extended=!!L.extended;M.race=L.race;M.stake=L.stake;M.mult=L.mult;M.practice=!!L.practice;M.proOnly=L.proOnly!==0}
 pzCastInit(R.id);PZ.dim=!!R.house.dim;pzMount(R,tok);
 if(o.resume&&!o.resume.pre){pzResumeState(o.resume)}else{PZ.ph='intro';PZ.pht=0;pzIntro(R,()=>{if(PZ.tok!==tok)return;pzNewRack(true)})}
 return true}
function pzExtend(yes){const M=PZ.M;if(yes){M.extended=true;M.race=3;M.mult=Math.min(2.8,Math.floor(pzdCap(M.opp)/Math.max(1,M.stake)*100)/100);PZ.shadeK=1}else{PZ.shadeK=1}PZ.ph='endhold';PZ.pht=0;PZ.endT=0;pzNewRack(false)}
function pzMatchEnd(){const M=PZ.M,Z=PZS(),R=PZ.reg,win=M.over.winner===0;PZ.ph='over';PZ.on=true;try{pzTauntStop()}catch(e){}const open0=PZ_ORDER.filter(k=>pzOpen(k));
 const res={win,opp:R.id,stake:M.stake,score:M.score.slice(),race:M.race,practice:M.practice,pay:0,bonus:0,bnr:M.bnr,golden:M.golden,pots:M.pots,banks:M.banks,time:Math.round((Date.now()-M.t0)/1000),unlocks:[],mult:M.mult,forfeit:!!M.forfeit,beatN:0};
 if(!M.practice){
  Z.live=null;save();/* the snapshot goes first, so a crash after this can never pay twice */
  if(win){const bonus=Math.min(500*Math.max(1,M.bnr),Math.round(M.stake*.1)*M.bnr)+(M.golden?Math.min(1000,Math.round(M.stake*.25)*M.golden):0);const base=Math.round(M.stake*M.mult);res.pay=Math.min(pzdCap(R.id),base+bonus);res.bonus=Math.max(0,res.pay-base);
   ecSrc('pool',()=>cPay(M.stake,res.pay));Z.wins++;Z.streak++;if(Z.streak>Z.best)Z.best=Z.streak;Z.net+=res.pay-M.stake;
   if(R.id==='shade'){Z.shade.beat=(Z.shade.beat||0)+1}else{Z.beat[R.id]=(Z.beat[R.id]||0)+1;Z.rep[R.id]=(Z.rep[R.id]||0)+1}res.beatN=R.id==='shade'?Z.shade.beat:Z.beat[R.id];
   if(R.id==='mortimer'&&Z.guide==='pro'&&M.proOnly)Z.proGuideBeat=(Z.proGuideBeat||0)+1}
  else{ecSrc('pool',()=>cPay(M.stake,0));Z.losses++;Z.streak=0;Z.net-=M.stake}
  stat('pzw',Z.wins,'set')}
 else if(win){res.beatN=0}
 res.opened=PZ_ORDER.find(k=>pzOpen(k)&&!open0.includes(k))||null;res.unlocks=pzUnlockSweep();try{stat('pzall',PZ_ORDER.filter(k=>(Z.beat[k]||0)>0).length,'set');stat('pzchamp',Z.beat.mortimer||0,'set');stat('pzpro',Z.proGuideBeat||0,'set');stat('pzshade',Z.shade.beat||0,'set');stat('pztaunt',Z.taunts,'set')}catch(e){}
 Z.live=null;save();try{achCheck()}catch(e){}
 PZ.result=res;pzResults(res)}
/* ---------- AI style ---------- */
/* gild (Aurelion): every one of his own balls he has pocketed tightens his aim a little (up to 24% with one left) */
function pzdAiK(me,st){if(me&&me.gild&&st&&!st.brk&&!st.open){const g=st.grp[st.turn];if(g){const left=pzrLeft(st,st.turn);if(left<7)me.sig*=Math.max(.76,1-.04*(7-left))}}return me}
{const f0=pzAiBegin;pzAiBegin=function(){const r=f0.apply(this,arguments);try{const ai=PZ.ai;if(ai&&ai.me&&ai.me.gild)pzdAiK(ai.me,PZ.st)}catch(e){}return r}}
/* house rule proGuide is 97b1's (pzGuideMode / pzHudAll wrapped there for every player with house.proGuide) */
