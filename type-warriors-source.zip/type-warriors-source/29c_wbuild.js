/* ---------- second armoury: shared builders and the new archer weapons ----------
   WNEW[id](g,L,t,X) draws one weapon in the same frame as drawW0 (grip at the origin, tip toward +x, L=70 on the hero).
   X={c,rc,ra}: body colour, rarity colour, rarity rank. Mythic weapons get a rainbow body colour from drawW1, so always use X.c */
const WNEW={};
const wsh=(c,a)=>/^#[0-9a-f]{6}/i.test(c)?shade(c,a):c;
const wsin=(t,a,b)=>Math.sin(t*a+(b||0));
/* a ribbon along a polyline with a width per point, lit from one side: P=[[x,y]..], wf(u)=half width */
function rib(g,P,wf,c,o){o=o||{};const n=P.length,E=[];for(let i=0;i<n;i++){const a=P[Math.max(0,i-1)],b=P[Math.min(n-1,i+1)];let dx=b[0]-a[0],dy=b[1]-a[1];const d=Math.hypot(dx,dy)||1,w=wf(i/(n-1));E.push([-dy/d*w,dx/d*w])}
 const band=(a,b)=>{g.beginPath();for(let i=0;i<n;i++){const x=P[i][0]+E[i][0]*a,y=P[i][1]+E[i][1]*a;i?g.lineTo(x,y):g.moveTo(x,y)}for(let i=n-1;i>=0;i--)g.lineTo(P[i][0]+E[i][0]*b,P[i][1]+E[i][1]*b);g.closePath()};
 band(1.22,-1.22);g.fillStyle='#000b';g.fill();band(1,-1);g.fillStyle=c;g.fill();band(-.1,-1);g.fillStyle=wsh(c,-.34);g.fill();band(.3,.9);g.fillStyle=wsh(c,.38);g.fill();band(.62,.82);g.fillStyle='#ffffff55';g.fill()}
/* bow limb geometry: at(u,s) walks a limb from its tip (u=0) to the grip (u=1); s=-1 left, 1 right */
function bowGeo(h,bw,o){o=o||{};const cx=o.cx==null?.35:o.cx,cy=o.cy==null?.9:o.cy,gy=o.gy==null?.5:o.gy;
 return{at:(u,s)=>{const m=1-u,x=s*h*(m*m+2*m*u*cx),y=-bw*m*m+2*m*u*bw*cy+u*u*bw*gy,dx=s*h*(-2*m+2*cx*(m-u)),dy=2*bw*m+2*bw*cy*(m-u)+2*u*bw*gy;let d=Math.hypot(dx,dy)||1,nx=-dy/d,ny=dx/d;if(ny<0){nx=-nx;ny=-ny}return{x,y,tx:dx/d,ty:dy/d,nx,ny}}}}
function wrapG(g,x0,x1,y,hw,col){g.fillStyle=vgr(g,y-hw,y+hw,wsh(col,.3),wsh(col,-.4));g.beginPath();g.roundRect(x0,y-hw,x1-x0,hw*2,3);g.fill();g.strokeStyle=wsh(col,-.55);g.lineWidth=1.1;for(let x=x0+2;x<x1-1;x+=3.4){g.beginPath();g.moveTo(x,y-hw);g.lineTo(x+2.2,y+hw);g.stroke()}g.strokeStyle='#ffffff38';g.lineWidth=.8;g.beginPath();g.moveTo(x0+1,y-hw*.55);g.lineTo(x1-1,y-hw*.55);g.stroke()}
function feather(g,x,y,ang,len,wd,c1,c2){g.save();g.translate(x,y);g.rotate(ang);g.fillStyle=hgr(g,0,len,c1,c2);g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(len*.45,-wd,len,0);g.quadraticCurveTo(len*.45,wd,0,0);g.fill();g.strokeStyle='#0005';g.lineWidth=.7;g.stroke();g.strokeStyle='#ffffff77';g.lineWidth=.8;g.beginPath();g.moveTo(0,0);g.lineTo(len*.94,0);g.stroke();g.restore()}
function thorn(g,x,y,ang,len,wd,c){g.save();g.translate(x,y);g.rotate(ang);poly(g,[-wd,0,len,0,-wd,wd*2],c,'#000a',.7);g.restore()}
function leafG(g,x,y,ang,len,wd,c){g.save();g.translate(x,y);g.rotate(ang);g.fillStyle=c;g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(len*.5,-wd,len,0);g.quadraticCurveTo(len*.5,wd,0,0);g.fill();g.strokeStyle='#0004';g.lineWidth=.6;g.stroke();g.strokeStyle='#ffffff55';g.beginPath();g.moveTo(0,0);g.lineTo(len*.9,0);g.stroke();g.restore()}
function wBow(g,L,t,o){const h=L*.56*(o.hs||1),bw=L*.22*(o.bs||1),G=bowGeo(h,bw,o),gy=bw*(o.gy==null?.5:o.gy),N=24,P=[];
 if(o.back)o.back(g,G,h,bw,gy);
 for(let i=0;i<=N;i++){const p=G.at(i/N,-1);P.push([p.x,p.y])}for(let i=N-1;i>=0;i--){const p=G.at(i/N,1);P.push([p.x,p.y])}
 const lw=(o.lw||3.6)*1.18;rib(g,P,u=>{const q=1-Math.abs(2*u-1);return lw*(o.wf?o.wf(u,q):.58+.42*Math.pow(q,.8))},o.c);
 wrapG(g,-6,6,gy,3.6,o.grip||'#3a2010');
 if(o.limb)o.limb(g,G,h,bw,gy);
 for(const s of[-1,1])poly(g,[s*h,-bw,s*h+s*3,-bw-4,s*h+s*4,-bw+2],o.nock||'#e6b93e');
 const nx=-L*.02,ny=-bw*.35-L*.08;g.strokeStyle=o.str||'#f4ecd8';g.lineWidth=o.sw||1.1;g.beginPath();g.moveTo(-h,-bw);g.lineTo(nx,ny);g.lineTo(h,-bw);g.stroke();
 g.strokeStyle='#d8c8a0';g.lineWidth=2;g.beginPath();g.moveTo(nx,ny);g.lineTo(L*.02+bw*.4,bw*.35);g.stroke();poly(g,[L*.02+bw*.4,bw*.35-3,L*.02+bw*.4+8,bw*.35,L*.02+bw*.4,bw*.35+3],o.head||'#e8eefc');
 if(o.front)o.front(g,G,h,bw,gy)}
const bseed=(t,k)=>rnd(Math.floor(t*14)+k*31);

/* --- Willow Shortbow (common): slim pale bow with weeping leaf strands --- */
WNEW.willow=(g,L,t,X)=>wBow(g,L,t,{c:X.c,hs:.84,bs:.95,lw:3,str:'#e8e0c0',grip:'#4a7a3a',nock:'#e8e0c8',
 limb:(g,G)=>{for(const s of[-1,1])for(let i=0;i<5;i++){const u=.08+i*.17,p=G.at(u,s),sw=wsin(t,1.8,i+s*2)*3,ln=L*(.2-.018*i);g.strokeStyle='#6a9a46';g.lineWidth=1;g.beginPath();g.moveTo(p.x,p.y);g.quadraticCurveTo(p.x+p.nx*ln*.4+sw,p.y+p.ny*ln*.5,p.x+p.nx*ln*.2+sw*1.6,p.y+p.ny*ln);g.stroke();
   for(let k=0;k<3;k++){const q=.45+k*.25,lx=p.x+p.nx*ln*.2*q+sw*q*1.4,ly=p.y+p.ny*ln*q;leafG(g,lx,ly,1.2+(k%2?.5:-.3)+sw*.05,L*.07,L*.018,k%2?'#8ac060':'#6aa044')}}}});
/* --- Driftwood Bow (common): bleached, knotted, barnacled, with a shell on a twine --- */
WNEW.driftbow=(g,L,t,X)=>wBow(g,L,t,{c:X.c,lw:3.9,grip:'#5a4a38',str:'#d8d0b8',nock:'#c8c0a8',wf:(u,q)=>(.5+.55*Math.pow(q,.7))*(1+.28*Math.sin(u*37)+.16*Math.sin(u*71)),
 limb:(g,G,h,bw,gy)=>{for(const s of[-1,1])for(let i=0;i<4;i++){const p=G.at(.18+i*.2,s);g.fillStyle='#f0ece0';g.beginPath();g.arc(p.x+p.nx*2.2,p.y+p.ny*2.2,1.1+rnd(i+s)*.8,0,TAU);g.fill();g.fillStyle='#0003';g.beginPath();g.arc(p.x+p.nx*2.2+.6,p.y+p.ny*2.2+.6,.6,0,TAU);g.fill()}
  const e=G.at(.02,1);g.strokeStyle='#4a9a5a';g.lineWidth=1.8;g.beginPath();g.moveTo(e.x,e.y);for(let i=1;i<=6;i++)g.lineTo(e.x+i*1.6+wsin(t,2.5,i)*1.8,e.y+i*L*.04);g.stroke();
  g.strokeStyle='#c8b890';g.lineWidth=1;g.beginPath();g.moveTo(5,gy+3);g.lineTo(9,gy+L*.09);g.stroke();g.save();g.translate(9,gy+L*.1);g.rotate(.2+wsin(t,2,0)*.12);g.fillStyle=hgr(g,-6,6,'#ffd8c0','#e89a8a');g.beginPath();g.moveTo(0,5);g.quadraticCurveTo(-8,-1,-4,-5);g.quadraticCurveTo(0,-7,4,-5);g.quadraticCurveTo(8,-1,0,5);g.fill();g.strokeStyle='#8a4a3a';g.lineWidth=.7;for(let i=-2;i<=2;i++){g.beginPath();g.moveTo(0,4);g.lineTo(i*2,-5);g.stroke()}g.restore()}});
/* --- Thornwood Bow (uncommon): dark limbs wrapped in a vine, thorns and a rosebud --- */
WNEW.thornwood=(g,L,t,X)=>wBow(g,L,t,{c:X.c,lw:3.6,grip:'#3a2418',str:'#e8d0c0',nock:'#5a2a2a',
 limb:(g,G,h,bw,gy)=>{for(const s of[-1,1]){g.strokeStyle='#3a8a3a';g.lineWidth=1.6;g.beginPath();for(let i=0;i<=22;i++){const u=.05+i/22*.82,p=G.at(u,s),w=Math.sin(i*1.5)*3;i?g.lineTo(p.x+p.nx*w,p.y+p.ny*w):g.moveTo(p.x+p.nx*w,p.y+p.ny*w)}g.stroke();
   for(let i=0;i<7;i++){const u=.08+i*.12,p=G.at(u,s),sd=i%2?1:-1;thorn(g,p.x,p.y,Math.atan2(p.ny*sd,p.nx*sd)+(s*.25),L*.09,1.8,'#d8c8a0')}}
  const bx=0,by=gy+6;for(let k=0;k<5;k++){g.save();g.translate(bx,by);g.rotate(k*1.26+.3);g.fillStyle=k%2?'#e02a4a':'#b01a38';g.beginPath();g.ellipse(0,-3.4,2.6,4,0,0,TAU);g.fill();g.strokeStyle='#4a0a1a';g.lineWidth=.6;g.stroke();g.restore()}ell(g,bx,by,1.6,1.6,'#ffd76a')}});
/* --- Gilded Longbow (uncommon): tall ivory bow, gold inlay, curled finials, a ruby at the grip --- */
WNEW.gilded=(g,L,t,X)=>wBow(g,L,t,{c:X.c,hs:1.1,bs:1.08,lw:3.4,grip:'#7a1a2a',str:'#fff3c0',nock:'#ffd76a',
 limb:(g,G,h,bw,gy)=>{for(const s of[-1,1]){g.strokeStyle='#e6b93e';g.lineWidth=1.3;g.beginPath();for(let i=0;i<=20;i++){const p=G.at(.1+i/20*.78,s),w=(i%2?1:-1)*.9;i?g.lineTo(p.x+p.nx*w,p.y+p.ny*w):g.moveTo(p.x+p.nx*w,p.y+p.ny*w)}g.stroke();
   for(let i=0;i<4;i++){const p=G.at(.16+i*.2,s);poly(g,[p.x,p.y-2.4,p.x+2.2,p.y,p.x,p.y+2.4,p.x-2.2,p.y],'#ffd76a','#8a5a10',.6)}
   const e=G.at(0,s);g.strokeStyle='#e6b93e';g.lineWidth=2.2;g.beginPath();g.arc(e.x+s*3,e.y-3,3.6,s>0?Math.PI*.5:Math.PI*.5-.4,s>0?Math.PI*2.1:Math.PI*1.9,s>0?false:false);g.stroke()}
  gem(g,0,gy,3.2,'#ff3a5a');for(const s of[-1,1])ell(g,s*7,gy,2,2,'#ffd76a');
  for(let i=0;i<2;i++){g.strokeStyle='#ffd76a';g.lineWidth=1.2;g.beginPath();g.moveTo(-3+i*6,gy+4);g.lineTo(-3+i*6+wsin(t,3,i)*1.4,gy+L*.12);g.stroke();ell(g,-3+i*6+wsin(t,3,i)*1.4,gy+L*.13,1.6,2,'#ffd76a')}}});
/* --- Stormcaller Bow (rare): thunderhead cloud caps and a bolt that crawls the limbs --- */
WNEW.stormcall=(g,L,t,X)=>wBow(g,L,t,{c:X.c,lw:3.6,grip:'#1a2048',str:'#bfe0ff',sw:1.3,nock:'#dfe8ff',
 back:(g,G,h,bw)=>{g.save();g.globalCompositeOperation='lighter';glow(g,0,0,L*.5,'#7a8aff44');g.restore()},
 limb:(g,G,h,bw,gy)=>{for(const s of[-1,1]){const e=G.at(0,s);for(let k=0;k<5;k++){const a=k*1.7+s,r=4+rnd(k+s*3)*3;ell(g,e.x+Math.cos(a)*5*s*.6,e.y-3+Math.sin(a)*3,r,r*.75,k%2?'#dfe4f4':'#aab4d0')}
   g.save();g.globalCompositeOperation='lighter';g.strokeStyle='#fff';g.lineWidth=1.4;g.shadowColor='#8ac8ff';g.shadowBlur=8;g.beginPath();for(let i=0;i<=14;i++){const u=.08+i/14*.8,p=G.at(u,s),j=(bseed(t,i+(s>0?20:0))-.5)*6*Math.sin(i/14*Math.PI);i?g.lineTo(p.x+p.nx*j,p.y+p.ny*j):g.moveTo(p.x+p.nx*j,p.y+p.ny*j)}g.stroke();g.restore()}},
 front:(g,G,h,bw,gy)=>{g.save();g.globalCompositeOperation='lighter';g.strokeStyle='#dfefff';g.lineWidth=1;g.shadowColor='#8ac8ff';g.shadowBlur=6;const nx=-L*.02,ny=-bw*.35-L*.08;g.beginPath();g.moveTo(-h,-bw);for(let i=1;i<10;i++){const u=i/10,x=-h+(nx+h)*u,y=-bw+(ny+bw)*u;g.lineTo(x,y+(bseed(t,i)-.5)*5)}g.lineTo(nx,ny);for(let i=1;i<10;i++){const u=i/10,x=nx+(h-nx)*u,y=ny+(-bw-ny)*u;g.lineTo(x,y+(bseed(t,i+9)-.5)*5)}g.lineTo(h,-bw);g.stroke();g.restore()}});
/* --- Wyrmbone Bow (rare): limbs of dragon vertebrae, a horned skull at the grip, sinew string --- */
WNEW.wyrmbone=(g,L,t,X)=>wBow(g,L,t,{c:X.c,lw:2.2,grip:'#4a3a2a',str:'#c8a878',nock:'#8a7a60',wf:(u,q)=>.5+.5*q,
 limb:(g,G,h,bw,gy)=>{for(const s of[-1,1])for(let i=0;i<9;i++){const u=.06+i*.095,p=G.at(u,s),r=2.6+i*.28;g.save();g.translate(p.x,p.y);g.rotate(Math.atan2(p.ty,p.tx));ell(g,0,0,3.1,r*.95,wsh(X.c,.1));g.strokeStyle='#0008';g.lineWidth=.8;g.beginPath();g.ellipse(0,0,3.1,r*.95,0,0,TAU);g.stroke();poly(g,[-1,-r*.9,.5,-r*1.9,1.6,-r*.9],X.c,'#0008',.6);g.restore()}
  g.save();g.translate(0,gy+1);g.fillStyle=vgr(g,-9,9,'#f4eed8','#b8ae90');g.beginPath();g.moveTo(-6,-4);g.quadraticCurveTo(-6,-9,0,-9);g.quadraticCurveTo(6,-9,6,-4);g.lineTo(4,3);g.lineTo(-4,3);g.closePath();g.fill();g.strokeStyle='#000a';g.lineWidth=.9;g.stroke();poly(g,[-6,-6,-12,-12,-4,-8],'#e8e0c8','#000a',.8);poly(g,[6,-6,12,-12,4,-8],'#e8e0c8','#000a',.8);g.save();g.globalCompositeOperation='lighter';for(const s of[-1,1]){glow(g,s*2.6,-3,5,'#ff6a2acc')}g.restore();for(const s of[-1,1])ell(g,s*2.6,-3,1.5,1.9,'#ffb040');g.fillStyle='#3a2a1a';for(let i=-1;i<=1;i++)g.fillRect(i*2.4-.6,.4,1.2,3);g.restore()}});
/* --- Duskwing Bow (epic): bat-wing limbs with a scalloped membrane and a watching ruby --- */
WNEW.duskwing=(g,L,t,X)=>wBow(g,L,t,{c:X.c,lw:2.8,grip:'#1a1030',str:'#e8d0ff',nock:'#d8b8ff',
 back:(g,G,h,bw,gy)=>{for(const s of[-1,1]){const A=[];for(let i=0;i<=5;i++){const p=G.at(.02+i*.17,s);A.push(p)}const flap=wsin(t,2.2,s)*1.6;g.beginPath();g.moveTo(A[0].x,A[0].y);for(let i=1;i<=5;i++){const p=A[i],q=A[i-1];g.quadraticCurveTo((p.x+q.x)/2+p.nx*(11+i*1.6)+flap,(p.y+q.y)/2+p.ny*(11+i*1.6),p.x+p.nx*3,p.y+p.ny*3)}g.lineTo(A[5].x,A[5].y);g.closePath();g.fillStyle=hgr(g,0,h*s,'#2a1048','#7a3ab8');g.fill();g.strokeStyle='#e0b8ff99';g.lineWidth=.9;g.stroke();g.strokeStyle='#e0b8ff55';for(let i=1;i<5;i++){g.beginPath();g.moveTo(A[i].x,A[i].y);g.lineTo(A[i].x+A[i].nx*(8+i*1.6)+flap,A[i].y+A[i].ny*(8+i*1.6));g.stroke()}}},
 limb:(g,G,h,bw,gy)=>{for(const s of[-1,1]){const e=G.at(0,s);poly(g,[e.x-s*1,e.y-2,e.x+s*2,e.y-10,e.x+s*3.4,e.y-2],'#e8e0f0','#000a',.7)}gem(g,0,gy+1,3.4,'#ff3a5a');g.save();g.globalCompositeOperation='lighter';glow(g,0,gy+1,L*.12*(1+.2*wsin(t,3,0)),'#ff3a5a66');g.restore()}});
/* --- Reefsong Bow (epic): living coral branches, a pearl and rising bubbles --- */
WNEW.coral=(g,L,t,X)=>wBow(g,L,t,{c:X.c,lw:3.4,grip:'#2a6a7a',str:'#d8fff4',nock:'#fff0e8',
 limb:(g,G,h,bw,gy)=>{const br=(x,y,a,len,d)=>{if(d>3||len<3)return;const x2=x+Math.cos(a)*len,y2=y+Math.sin(a)*len;g.strokeStyle=d%2?'#ff9a8a':'#ff6a7a';g.lineWidth=Math.max(1,3-d*.7);g.beginPath();g.moveTo(x,y);g.lineTo(x2,y2);g.stroke();if(d===3||len<5)ell(g,x2,y2,1.6,1.6,'#ffe0d0');br(x2,y2,a-.55,len*.7,d+1);br(x2,y2,a+.5,len*.72,d+1)};
  for(const s of[-1,1])for(let i=0;i<4;i++){const p=G.at(.1+i*.2,s),a=Math.atan2(-p.ny,-p.nx)+(i%2?.5:-.5)*.7;br(p.x,p.y,a+Math.PI,L*.1,0)}
  g.fillStyle=rgr(g,-1,gy-1,.5,5,'#ffffff','#bfe8ff');g.beginPath();g.arc(0,gy+1,4.4,0,TAU);g.fill();g.strokeStyle='#ffffffaa';g.lineWidth=.8;g.stroke();
  g.save();g.globalCompositeOperation='lighter';g.strokeStyle='#d8ffff';g.lineWidth=.9;for(let i=0;i<6;i++){const u=(t*.3+i/6)%1,s=i%2?-1:1,x=s*(10+rnd(i)*h*.7)+Math.sin(t*2+i)*3,y=gy-u*L*.5;g.globalAlpha=Math.sin(u*Math.PI)*.8;g.beginPath();g.arc(x,y,1.5+rnd(i+3)*2,0,TAU);g.stroke()}g.restore()}});
/* --- Thunderbird (legendary): a golden pair of wings with a storm between the tips --- */
WNEW.thunderbird=(g,L,t,X)=>wBow(g,L,t,{c:X.c,hs:1.04,bs:1.1,lw:3,grip:'#3a3a70',str:'#fff8c0',sw:1.3,nock:'#fff',cy:1.05,
 back:(g,G,h,bw,gy)=>{g.save();g.globalCompositeOperation='lighter';glow(g,0,-bw*.5,L*.62,'#8aeaff44');g.restore();for(const s of[-1,1])for(let i=0;i<9;i++){const u=.04+i*.1,p=G.at(u,s),len=L*(.34-i*.022)*(1+.04*wsin(t,3,i+s)),a=Math.atan2(-p.ny,-p.nx)+s*(.55-i*.07)+wsin(t,2,i)*.03;feather(g,p.x,p.y,a,len,L*.05,i%2?'#fff4b0':'#ffe05a',i%2?'#ffd24a':'#ff9a2a')}},
 limb:(g,G,h,bw,gy)=>{g.save();g.globalCompositeOperation='lighter';g.strokeStyle='#bff4ff';g.lineWidth=1.6;g.shadowColor='#6adfff';g.shadowBlur=10;for(const s of[-1,1]){g.beginPath();let x=s*h,y=-bw;g.moveTo(x,y);for(let i=1;i<=6;i++){x-=s*(h*.28)*(.8+bseed(t,i+s)*.4);y=-bw-L*.14*i/6+(bseed(t,i*3+s)-.5)*L*.08;g.lineTo(x,y)}g.stroke()}g.restore();
  g.fillStyle=vgr(g,gy-6,gy+8,'#ffe9a0','#d89a2a');g.beginPath();g.ellipse(0,gy+2,5.4,6.6,0,0,TAU);g.fill();g.strokeStyle='#000a';g.lineWidth=.9;g.stroke();poly(g,[-3,gy+6,0,gy+14,3,gy+6],'#ff9a2a','#000a',.8);ell(g,-2,gy,1.4,1.4,'#101840');ell(g,2,gy,1.4,1.4,'#101840')}});
/* --- Wraithstring (legendary): a spectral bow, ghost flame on the tips, a skull and a burning string --- */
WNEW.wraith=(g,L,t,X)=>{const fl=(g,x,y,u0)=>{g.save();g.globalCompositeOperation='lighter';for(let i=0;i<5;i++){const u=(t*.9+i/5+u0)%1;g.globalAlpha=(1-u)*.85;mFl(g,x+Math.sin(u*6+i)*3,y-u*L*.2,L*(.11-.05*u),L*.03,t,i,'rgba(120,255,200,.8)','rgba(220,255,240,.95)')}g.restore()};
 wBow(g,L,t,{c:'#cfeee0',lw:3.3,grip:'#2a3a38',str:'#9affc8',sw:1.8,nock:'#e8fff4',wf:(u,q)=>(.4+.6*Math.pow(q,.8)),
 back:(g,G,h,bw,gy)=>{g.save();g.globalCompositeOperation='lighter';glow(g,0,0,L*.55,'#4affb044');g.restore()},
 limb:(g,G,h,bw,gy)=>{for(const s of[-1,1]){const e=G.at(0,s);fl(g,e.x,e.y,s>0?.3:0)}
  g.save();g.translate(0,gy+1);g.fillStyle=vgr(g,-9,9,'#f4fff8','#a8c8b8');g.beginPath();g.moveTo(-5.4,-4);g.quadraticCurveTo(-5.4,-9,0,-9);g.quadraticCurveTo(5.4,-9,5.4,-4);g.lineTo(3.6,3);g.lineTo(-3.6,3);g.closePath();g.fill();g.strokeStyle='#000a';g.lineWidth=.9;g.stroke();g.save();g.globalCompositeOperation='lighter';for(const s of[-1,1])glow(g,s*2.4,-3,6,'#4affb0dd');g.restore();for(const s of[-1,1])ell(g,s*2.4,-3,1.3,1.8,'#eafff4');g.restore();
  g.strokeStyle='#9affc888';g.lineWidth=1.6;for(let i=0;i<3;i++){g.beginPath();g.moveTo(-3+i*3,gy+6);g.quadraticCurveTo(-5+i*5+wsin(t,2,i)*3,gy+L*.1,-4+i*4+wsin(t,2.4,i)*4,gy+L*.2);g.stroke()}}})};
/* --- Orion's Oath (mythic): a slender night-sky bow; the constellation itself is drawn by MYA.m_bow3 --- */
WNEW.m_bow3=(g,L,t,X)=>wBow(g,L,t,{c:X.c,hs:1.08,bs:1.12,lw:3,grip:'#0c1030',str:'#e8f0ff',sw:1.3,nock:'#fff',cx:.3,cy:1,
 back:(g,G,h,bw,gy)=>{g.save();g.globalCompositeOperation='lighter';glow(g,0,-bw*.4,L*.55,'#5a7affaa');g.restore()},
 limb:(g,G,h,bw,gy)=>{for(const s of[-1,1]){g.save();g.globalCompositeOperation='lighter';g.strokeStyle='#ffffffcc';g.lineWidth=.9;g.beginPath();for(let i=0;i<=20;i++){const p=G.at(.04+i/20*.84,s);i?g.lineTo(p.x+p.nx*.4,p.y+p.ny*.4):g.moveTo(p.x+p.nx*.4,p.y+p.ny*.4)}g.stroke();g.restore();for(let i=0;i<6;i++){const p=G.at(.1+i*.15,s);mS(g,p.x+p.nx*(i%2?-1.6:1.6),p.y+p.ny*(i%2?-1.6:1.6),1.2+rnd(i+s)*1,'#fff')}}
  g.fillStyle='#0c1030';g.beginPath();g.arc(0,gy,4.4,0,TAU);g.fill();mS(g,0,gy,5.6,'#fff')}});
