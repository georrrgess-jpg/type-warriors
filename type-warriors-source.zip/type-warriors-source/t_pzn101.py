# python3 t_pzn101.py : 10.1 Orbit 8, the second venue of The Crooked Cue (97b1-97b4): the way in from the tavern hub (locked until
# Grizzle, NEW, the O key, remembered venue), the Orbit 8 hub (medallions, spotlight, stakes, keys, no overlaps), the new table and room,
# every new player in every expression and moving, the VS intro, shot flair, the AI styles and house rules, a whole paid match with the
# money checked, results / regulars / unlock cards, the save normaliser, resume, frame cost, lite mode and no page errors.
import asyncio,os,sys,json,re
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:600]),flush=True)
    if not ok:FAIL.append(name)
PRE="()=>{RS_ASK=false;PZ_TUT_OFF=true;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}P.gold=100000;P.pz=null;save()}"
HELP=r"""window.pzAuto=function(o){o=o||{};const me=Object.assign({sig:.9,psig:.05,pos:.4,safe:.3,sTry:12,look:5},o.me||{});PZ.speed=o.speed||6;const log={shots:0};
 const iv=setInterval(()=>{try{if(!PZ.on||!PZ.st)return;if(PZ.ph==='aim'&&!PZ.modal){const st=PZ.st;if(PZ.mode==='place'){pzaPlace(st,me);const c=PZ.B[0];const p=pzpNearestPlace(PZ.B,c.x,c.y,st.kitchen||st.brk);pzPlaceCue(p.x,p.y);return}
   if(PZ.mode==='aim'&&!PZ.shotFired){let d;if(st.brk){d=pzaBreak(st,me,Math.random);PZ.B[0].x=d.x||PZ.B[0].x}else d=pzaDecide(st,me,Math.random,{});const n=pzaNoise(d,me,Math.random,1);PZ.aim.ang=PZ.cueAng=n.ang;PZ.aim.pow=n.pow;PZ.aim.a=n.a;PZ.aim.b=n.b;if(pzrOn8(st)&&d.id===8){PZ.call=d.k;PZ.callManual=true}pzFireHuman();log.shots++}}}catch(e){log.err=String(e)}},60);log.stop=()=>clearInterval(iv);return log};
window.pzPix=(cv,x,y)=>Array.from(cv.getContext('2d').getImageData(x,y,1,1).data);
window.pzPainted=(cv)=>{const d=cv.getContext('2d').getImageData(0,0,cv.width,cv.height).data;let n=0,h=0;for(let i=3;i<d.length;i+=16){if(d[i]>40){n++;h=(h*31+d[i-3]*7+d[i-2]*3+d[i-1])|0}}return [n,h]};0"""
IDS=['bleep','octavia','facet','rex','vantara']
async def main():
    # ------------------------------------------------------------ code hygiene and registration
    mods=[f for f in sorted(os.listdir(HERE)) if re.match(r'97b\d_pzn_.*\.js$',f)]
    chk('four Orbit 8 modules (97b1 data, 97b2 cast, 97b3 venue, 97b4 hub)',mods==['97b1_pzn_data.js','97b2_pzn_cast.js','97b3_pzn_venue.js','97b4_pzn_hub.js'],mods)
    bad=[]
    for m in mods:
        s=re.sub(r'/\*.*?\*/','',open(os.path.join(HERE,m),encoding='utf8').read(),flags=re.S)
        for pat in [r'\bbackdrop-filter\b',r'\b\d+(\.\d+)?v[wh]\b',r'@media[^{]*(min|max)-(width|height)',r'soft-light',r'mix-blend-mode\s*:\s*screen',r'\.shadowBlur\s*=',r'ctx\.filter',r'\.filter\s*=\s*[\'"`]',r"globalCompositeOperation\s*=\s*['\"]screen",r'claude-|opus|sonnet']:
            if re.search(pat,s,re.I if pat.startswith('claude') else 0):bad.append((m,pat))
    chk('no backdrop-filter, vw/vh, viewport media queries, soft-light/screen blends, shadowBlur, ctx.filter or model ids in the Orbit 8 modules',not bad,bad)
    for f in ['build.sh','build_ast3.sh']:
        s=open(os.path.join(HERE,f)).read();i=[s.find(' '+m+' ') for m in ['97b_pz_fix99.js']+mods]
        chk(f'{f}: the modules are registered once each, in order, right after 97b_pz_fix99.js',all(x>0 for x in i) and i==sorted(i) and all(s.count(' '+m+' ')==1 for m in mods),i)
    async with async_playwright() as p:
        b=await p.chromium.launch();er=[]
        pg=await b.new_page(viewport={'width':1600,'height':900})
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        pg.on('console',lambda m:er.append('console:'+m.text[:300]) if m.type=='error' and 'ERR_' not in m.text and 'WebSocket' not in m.text else None)
        await pg.goto(H);await pg.wait_for_timeout(1500);await pg.evaluate(PRE);await pg.evaluate(HELP);E=pg.evaluate
        # ------------------------------------------------------------ data, money rules
        r=await E("""()=>{const o=PZN_ORDER.map(k=>{const R=PZ_REG[k];return {k,venue:R.venue,st:R.stakes,ok:R.stakes.every(s=>s<=casCap('pz')),pay:Math.max(...R.stakes.map(s=>Math.round(s*pzMultS(k,s)))),m:R.mult,f:R.floor,race:R.race,sig:R.ai.sig,cue:!!PZN_CUES[R.cue],think:!!PZ_THINK[k],h:PZ_MONH[k],lines:['hi','pot','miss','you','foul','win','lose','taunted'].every(x=>R.lines[x]&&R.lines[x].length),taunts:R.taunts.every(t=>t.length<=24)}});
          return {o,order:PZ_ORDER.length,cues:PZ_CUES.length,felts:PZ_FELT.length}}""")
        o=r['o']
        chk('five Orbit 8 players in PZ_REG with stakes under the 5,000 limit, no payout over 15,000, pay above the floor, races of 2-3, lines, taunts, think routines, heights and their own cues',
            len(o)==5 and all(x['venue']=='o8' and x['ok'] and x['pay']<=15000 and x['m']>x['f']>1 and 2<=x['race']<=3 and x['cue'] and x['think'] and x['h'] and x['lines'] and x['taunts'] for x in o),o)
        chk('the ladder gets harder: aim error falls from Bleep to Vantara, and Vantara is sharper than Mortimer',all(o[i]['sig']>o[i+1]['sig'] for i in range(4)) and o[4]['sig']<await E("()=>PZ_REG.mortimer.ai.sig"),[x['sig'] for x in o])
        chk('the tavern data is untouched: seven regulars, 13 cues and 5 felts (the Cue Rack is unchanged)',r['order']==7 and r['cues']==13 and r['felts']==5,r)
        r=await E("()=>{const s=pzCueSprite('pzn_vantara'),h=pzCueSprite('house');return [s.width,h.width,PZ_CUES.length,s!==h]}")
        chk('their match cues build sprites without joining the Cue Rack',r[0]==r[1] and r[2]==13 and r[3],r)
        # ------------------------------------------------------------ the way in: locked, then NEW
        await E("()=>{P.pz=null;const Z=PZS();Z.beat={gloop:1,moldwick:1};save();PZ.sel=null;PZ.shadeHere=false;PZ.shadeChecked=pzDay();casinoOpen();gameOpen('pz')}");await pg.wait_for_timeout(1500)
        r=await E("()=>{const t=document.getElementById('pzn8tk');return {t:!!t,lock:t&&t.classList.contains('lock'),txt:t&&t.textContent,venue:PZS().venue}}")
        chk('tavern hub: an Orbit 8 shuttle pass sits in the top bar, locked until Grizzle is beaten (it says so)',r['t'] and r['lock'] and 'Grizzle' in r['txt'] and r['venue']=='tavern',r)
        await pg.click('#pzn8tk');await pg.wait_for_timeout(500);await pg.keyboard.press('o');await pg.wait_for_timeout(500)
        chk('a locked pass and the O key stay in the tavern',await E("()=>!!document.querySelector('#pzh:not(.pzn8)')&&PZS().venue==='tavern'&&!!document.getElementById('pznote')"))
        r=await E("""()=>{const t=document.getElementById('pzn8tk').getBoundingClientRect(),hit=(a,c)=>a.left<c.right-1&&c.left<a.right-1&&a.top<c.bottom-1&&c.top<a.bottom-1;const o=[...document.querySelectorAll('.pzgold,.pzsign span,.pzsign .pzembw,.pzprog,.pznet,.pzback,#pzopp')].filter(e=>hit(t,e.getBoundingClientRect())).map(e=>e.className);return o}""")
        chk('the pass overlaps nothing in the tavern top bar',r==[],r)
        await E("()=>{const Z=PZS();Z.beat.grizzle=1;save();pzHub()}");await pg.wait_for_timeout(1200)
        r=await E("()=>{const t=document.getElementById('pzn8tk');return {lock:t.classList.contains('lock'),nw:t.classList.contains('new'),badge:!!t.querySelector('.pzbdg')}}")
        chk('after Grizzle the pass opens and shows NEW',not r['lock'] and r['nw'] and r['badge'],r)
        await pg.click('#pzn8tk');await pg.wait_for_timeout(1700)
        M="""()=>[...document.querySelectorAll('.pz97md')].map(b=>{const r=b.querySelector('.pz97m').getBoundingClientRect(),c=b.querySelector('canvas');return {k:b.dataset.k,sel:b.classList.contains('sel'),next:b.classList.contains('next'),lock:b.classList.contains('lock'),dis:b.disabled,nm:b.querySelector('.pz97nm').textContent,painted:pzPainted(c)[0]>300,x:r.left+r.width/2,y:r.top+r.height/2}})"""
        m=await E(M);st={x['k']:x for x in m}
        r=await E("()=>({o8:!!document.querySelector('#pzh.pzn8'),venue:PZS().venue,seen:PZS().o8.seen,title:document.querySelector('.pzn8sign').textContent,sel:PZ.sel})")
        chk('the pass flies you to the Orbit 8 hub; the venue is remembered and the first visit counted',r['o8'] and r['venue']=='o8' and r['seen']==1 and 'Orbit 8' in r['title'],r)
        chk('Orbit 8 hub: five medallions in ladder order, every portrait painted; Bleep is open, next and picked; the rest are locked "? ? ?"',[x['k'] for x in m]==IDS and all(x['painted'] for x in m) and st['bleep']['next'] and st['bleep']['sel'] and not st['bleep']['dis'] and all(st[k]['lock'] and st[k]['dis'] and st[k]['nm']=='? ? ?' for k in IDS[1:]),m)
        r=await E("""()=>{const bar=document.getElementById('pz97bar').getBoundingClientRect(),opp=document.getElementById('pzopp').getBoundingClientRect(),nav=document.querySelector('.pznav').getBoundingClientRect();
          const ms=[...document.querySelectorAll('.pz97md')].map(b=>({m:b.querySelector('.pz97m').getBoundingClientRect(),n:b.querySelector('.pz97nm').getBoundingClientRect(),t:(b.querySelector('.pz97tag')||b.querySelector('.pz97nm')).getBoundingClientRect()}));
          const hit=(a,c)=>a.left<c.right-1&&c.left<a.right-1&&a.top<c.bottom-1&&c.top<a.bottom-1;let bad=[];
          ms.forEach((a,i)=>{for(const z of[a.m,a.n,a.t]){if(hit(z,bar)||hit(z,opp)||hit(z,nav))bad.push(['panel',i])}ms.forEach((c,j)=>{if(j>i&&(hit(a.n,c.n)||hit(a.m,c.n)||hit(a.n,c.m)||hit(a.m,c.m)))bad.push(['med',i,j])})});
          const top=[...document.querySelectorAll('.pzback,.pzgold,.pzn8sign span,.pzn8prog,.pznet')].map(e=>e.getBoundingClientRect());top.forEach((a,i)=>top.forEach((c,j)=>{if(j>i&&hit(a,c))bad.push(['top',i,j])}));return bad}""")
        chk('Orbit 8 hub: medallions, plates and tags overlap nothing; the top bar items do not overlap each other',r==[],r)
        r=await E("()=>({name:document.querySelector('.pzoppi .pzh3').textContent,chips:[...document.querySelectorAll('.pz97ch')].map(x=>+x.dataset.s),play:document.getElementById('pzrackem').textContent,prac:document.getElementById('pzpracs').textContent,ret:document.getElementById('pz97ret').textContent,stake:pzStakeOf('bleep'),mult:pzMultS('bleep',pzStakeOf('bleep')),rew:(document.querySelector('.pzn8rew')||{}).textContent||'',stage:pzPainted(document.querySelector('#pzopp .pzstbg'))[0]})")
        win=round(r['stake']*r['mult'])
        chk('spotlight and stake bar: Bleep, his chips, Play • N coins, Practice vs Bleep, total return, the first-win bonus line and a holo stage',r['name']=='Bleep' and r['chips']==[300,500,1000,2000] and f"{r['stake']:,} coins" in r['play'] and r['prac']=='free vs Bleep' and r['ret']==f'{win:,}' and '+400' in r['rew'] and r['stage']>1000,r)
        await pg.click('.pz97md[data-k=octavia]',force=True);await pg.wait_for_timeout(300)
        chk('a locked Orbit 8 medallion cannot be picked',await E("()=>PZ.sel")=='bleep')
        # ------------------------------------------------------------ keys and remembering the venue
        await E("()=>{const Z=PZS();Z.beat.bleep=1;Z.beat.octavia=1;save();pzHub()}");await pg.wait_for_timeout(1200)
        await pg.keyboard.press('2');await pg.wait_for_timeout(300);k1=await E("()=>PZ.sel")
        await pg.keyboard.press('5');await pg.wait_for_timeout(300);k2=await E("()=>PZ.sel")
        await pg.keyboard.press('ArrowDown');await pg.wait_for_timeout(300);k3=await E("()=>PZ.sel")
        s0=await E("()=>pzStakeOf(PZ.sel)");await pg.keyboard.press('ArrowRight');await pg.wait_for_timeout(400);s1=await E("()=>pzStakeOf(PZ.sel)")
        await pg.keyboard.press('n');await pg.wait_for_timeout(300);k4=await E("()=>PZ.sel")
        chk('Orbit 8 keys: 2 picks Octavia, a locked 5 does nothing, down walks the ladder, right raises the stake, N jumps to the next one',[k1,k2,k3,k4]==['octavia','octavia','facet','facet'] and s1>s0,[k1,k2,k3,k4,s0,s1])
        await pg.keyboard.press('o');await pg.wait_for_timeout(900)
        r=await E("()=>({tav:!!document.querySelector('#pzh:not(.pzn8)'),venue:PZS().venue,sel:PZ.sel,pass:!!document.getElementById('pzn8tk')&&!document.getElementById('pzn8tk').classList.contains('new')})")
        chk('O goes back down to the tavern (a tavern regular picked again, the pass no longer NEW)',r['tav'] and r['venue']=='tavern' and r['sel'] in await E("()=>PZ_ORDER") and r['pass'],r)
        await E("()=>{PZS().venue='o8';save();lobby();casinoOpen();gameOpen('pz')}");await pg.wait_for_timeout(1200)
        chk('the casino tile opens the venue you were last in',await E("()=>!!document.querySelector('#pzh.pzn8')&&PZ.sel==='facet'"))
        await pg.keyboard.press('Escape');await pg.wait_for_timeout(900)
        chk('Esc in Orbit 8 goes back to the tavern hub',await E("()=>!!document.querySelector('#pzh:not(.pzn8)')&&PZS().venue==='tavern'"))
        # ------------------------------------------------------------ every player, every expression, always moving
        r=await E("""()=>{const out={};const cv=document.createElement('canvas');cv.width=420;cv.height=520;const g=cv.getContext('2d');g.lineJoin='round';g.lineCap='round';
          for(const id of PZN_ORDER){const row={};let base=null;for(const k of Object.keys(PZ_EXP)){g.clearRect(0,0,420,520);g.save();g.translate(210,500);try{pzMon[id](g,2.3,Object.assign(pzCastEx(),PZ_EXP[k]),{breath:0,tilt:0,bob:0,hop:0})}catch(e){row.err=String(e)}g.restore();const [n,h]=pzPainted(cv);row[k]=[n,h];if(k==='neutral')base=h}
           const mv=[];for(const t of[1,1.5,2.7]){g.clearRect(0,0,420,520);g.save();g.translate(210,500);pzMon[id](g,t,pzCastEx(),{breath:.01,tilt:.02,bob:1,hop:0});g.restore();mv.push(pzPainted(cv)[1])}
           const exs=Object.keys(PZ_EXP).filter(k=>k!=='neutral');out[id]={err:row.err||null,painted:Object.values(row).every(v=>!Array.isArray(v)||v[0]>2500),distinct:exs.filter(k=>row[k][1]!==base).length,of:exs.length,moving:new Set(mv).size,box:pzMonBox(id)}}return out}""")
        chk('every Orbit 8 player draws in every expression (neutral, happy, smug, sad, angry, think, rattled, cheer, wow) without errors',all(not r[k]['err'] and r[k]['painted'] for k in IDS),{k:(r[k]['err'],r[k]['painted']) for k in IDS})
        chk('each expression looks different from neutral',all(r[k]['distinct']==r[k]['of'] for k in IDS),{k:r[k]['distinct'] for k in IDS})
        chk('idle animation: each one keeps moving between frames (breathing, quirks)',all(r[k]['moving']==3 for k in IDS),{k:r[k]['moving'] for k in IDS})
        chk('their measured sizes fit the stage like the regulars (230-470 tall)',all(230<(r[k]['box']['y1']-r[k]['box']['y0'])<470 for k in IDS),{k:round(r[k]['box']['y1']-r[k]['box']['y0']) for k in IDS})
        r=await E("()=>{const cv=document.createElement('canvas');cv.width=cv.height=132;return PZN_ORDER.map(id=>{pzCastPortrait(cv.getContext('2d'),'mon',id,132,1,pzCastEx());return pzPainted(cv)[0]})}")
        chk('HUD portraits frame each head (painted across the card)',all(x>700 for x in r),r)
        # ------------------------------------------------------------ the table and room, the intro
        await E("()=>{const Z=PZS();Z.beat={grizzle:1,bleep:1,octavia:1,facet:1,rex:1};save();PZ.sel='bleep';PZS().venue='o8';pzHub()}");await pg.wait_for_timeout(800)
        await E("()=>{pzStart({opp:'rex',practice:true,seed:3})}");await pg.wait_for_timeout(1500)
        r=await E("()=>({cls:document.getElementById('pzintro').className,q:(document.querySelector('.pznvsq')||{}).textContent||'',pt:pzPainted(document.getElementById('pzvo'))[0],stk:!!document.querySelector('.pznstk')})")
        chk('VS intro: the Orbit 8 version with star streaks, the entrance on its own canvas and their opening line',('pznvs' in r['cls']) and r['stk'] and r['pt']>2000 and 'Rex' in r['q'],r)
        await E("()=>document.getElementById('pzintro').click()");await pg.wait_for_timeout(1600)
        r=await E("""()=>{const cv=PZ.cv,G=PZ_G,P=PZ_POCK[1];return {pzn:PZ.pzn,bk:PZ.bk===PZN.bk,cls:document.getElementById('pzm').classList.contains('pzn8m'),felt:pzPix(cv,G.x+300,G.y+330),ring:pzPix(PZN.bk,Math.round(G.x+P[0]+P[2]+5),Math.round(G.y+P[1])),window:pzPix(PZN.bk,1340,330),porthole:pzPix(PZN.bk,140,400),clock:pzClockMax(),av:pzPainted(document.getElementById('pzavo'))[0]}}""")
        chk('the match uses the Orbit 8 room and table (its own bake), the HUD portrait is painted',r['pzn'] and r['bk'] and r['cls'] and r['av']>500,r)
        f=r['felt'];rg=r['ring']
        chk('table colours: steel-blue felt, a magenta ring round each pocket, space in the windows',f[2]>f[0]+40 and f[2]>f[1] and rg[0]>150 and rg[2]>120 and rg[1]<140 and r['window'][2]>r['window'][1]-5,r)
        chk('Rex\'s house rule: a 30-second shot clock',r['clock']==30,r)
        r=await E("""()=>{const t=[];for(let i=0;i<3;i++)pzFrame(PZ.g);for(let i=0;i<40;i++){const a=performance.now();pzFrame(PZ.g);t.push(performance.now()-a)}t.sort((x,y)=>x-y);return [t[20],t[36]]}""")
        chk(f'frame cost at rest on the Orbit 8 table is small (median {r[0]:.2f} ms, p90 {r[1]:.2f} ms; under 4 / 9 ms)',r[0]<4 and r[1]<9,r)
        rest=r
        r=await E("""()=>{const c=document.createElement('canvas');c.width=1600;c.height=900;const g=c.getContext('2d');const t=[];for(let i=0;i<30;i++){const a=performance.now();pzDrawLamp(g,i*.1);pzDrawLights(g,i*.1);pzDrawDust(g,i*.1);t.push(performance.now()-a)}t.sort((x,y)=>x-y);
          const cnt={n:0};const g2=new Proxy(g,{get(o,k){const v=o[k];if(typeof v==='function')return (...a)=>{cnt.n++;return v.apply(o,a)};return v},set(o,k,v){o[k]=v;return true}});document.body.classList.add('pf-low');PZ_RMC.t=-1e9;pzDrawLights(g2,1);pzDrawDust(g2,1);const low=cnt.n;document.body.classList.remove('pf-low');PZ_RMC.t=-1e9;return {med:t[15],low}}""")
        chk(f'the venue ambience (halo, stars, shuttle, pods, motes) costs {r["med"]:.2f} ms a frame; Performance mode draws none of it',r['med']<1.2 and r['low']==0,r)
        await E("()=>{PZ.aim.pow=.95;pzFireHuman()}");await pg.wait_for_timeout(700)
        r=await E("""()=>{const t=[];for(let i=0;i<3;i++)pzFrame(PZ.g);for(let i=0;i<40;i++){const a=performance.now();pzFrame(PZ.g);t.push(performance.now()-a)}t.sort((x,y)=>x-y);return [t[20],t[36]]}""")
        chk(f'break frame cost on the Orbit 8 table (median {r[0]:.2f} ms, p90 {r[1]:.2f} ms; under 8 / 18 ms like t_pool)',r[0]<8 and r[1]<18,r)
        brk=r
        await E("()=>{PZ.lite=true}");await pg.wait_for_timeout(300)
        r=await E("()=>{let n=0;const f0=pznDrawAmb;pznDrawAmb=function(){n++;return f0.apply(this,arguments)};for(let i=0;i<5;i++)pzRender(PZ.g);pznDrawAmb=f0;return n}")
        chk('lite mode skips the venue ambience',r==0,r)
        await E("()=>{PZ.lite=false;pzForfeit()}");await pg.wait_for_timeout(500)
        # ------------------------------------------------------------ shot flair, AI styles, house rules
        r=await E("""()=>{const out={};const st0=PZ.st;for(const id of ['octavia','facet','rex','vantara']){PZ.reg=PZ_REG[id];PZ.pzn=true;PZ.pznFx=[];PZ.shot={ang:0,pow:.6};pznShotFx();out[id]=PZ.pznFx.length}PZ.pzn=false;return out}""")
        chk('shot flair: Octavia leaves notes, Facet a prism, Rex a booster flame, Vantara a gravity ring',all(v>0 for v in r.values()),r)
        r=await E("""()=>{const me=Object.assign({},PZ_REG.bleep.ai,{glitch:1}),s=pzaNoise({ang:0,pow:.5,a:0,b:0},me,()=>.3);const s2=pzaNoise({ang:0,pow:.5,a:0,b:0,brk:1},me,()=>.3);return [!!s.glitch,!s2.glitch]}""")
        chk('Bleep\'s glitch: now and then a wild shot (never on the break)',r==[True,True],r)
        r=await E("""()=>{const res={};const rng=pzRng(4);PZ.on=false;for(const [id,run,on8] of[['rex',0,0],['rex',3,0],['vantara',0,0],['vantara',0,1]]){PZ.reg=PZ_REG[id];const B=pzpRack(rng).sort((a,b)=>a.id-b.id);const st=pzrNew(B,0,{});st.brk=false;st.open=false;st.grp=['t','s'];st.turn=1;if(on8)for(const b of B)if(b.id>=1&&b.id<=7)b.on=false;PZ.st=st;PZ.B=B;PZ.rattled=0;PZ.M={rack:2,extended:true};PZ.pznRun=run;PZ.aim={};try{pzAiBegin()}catch(e){res.err=String(e)}res[id+run+on8]=Math.round(PZ.ai.me.sig*1000)/1000;PZ.ai=null}PZ.st=null;return res}""")
        chk('Rex sharpens on a run (aim error x0.64 after three visits); Vantara sharpens on the 8 (x0.7)',abs(r['rex30']/r['rex00']-.64)<.01 and abs(r['vantara01']/r['vantara00']-.7)<.01,r)
        r=await E("()=>{PZ.reg=PZ_REG.vantara;const a=pzGuideMode();PZ.reg=PZ_REG.facet;const Z=PZS();Z.guide='full';const b=pzGuideMode();PZ.reg=PZ_REG.bleep;const c=pzGuideMode();return [a,b,c]}")
        chk('house rules: Vantara shows the aim line only, Facet the short guide, Bleep the full guide',r==['pro','short','full'],r)
        # ------------------------------------------------------------ a whole paid match on the new table, with the money checked
        await E("()=>{P.pz=null;P.gold=20000;const Z=PZS();Z.beat={grizzle:1};Z.venue='o8';Z.mastPaid={house:10};for(const a of ACH)P.ach[a.id]=P.ach[a.id]||1;save();PZ.sel=null}");await pg.wait_for_timeout(200)
        await E("()=>{casinoOpen();gameOpen('pz')}");await pg.wait_for_timeout(900)
        chk('a fresh save that has beaten Grizzle opens Orbit 8 with Bleep picked',await E("()=>!!document.querySelector('#pzh.pzn8')&&PZ.sel==='bleep'"))
        g0=await E("()=>P.gold")
        await E("()=>{pzHubStake(300);document.getElementById('pzrackem').click();window.__a=pzAuto({speed:8,me:{sig:.35,psig:.03,pos:.6,look:6}});setTimeout(()=>{const i=document.getElementById('pzintro');if(i)i.click()},400)}")
        r=await E("()=>({live:!!PZS().live,gold:P.gold,opp:PZ.M&&PZ.M.opp,stake:PZ.M&&PZ.M.stake,pzn:PZ.pzn})")
        chk('Play takes the 300 stake at once and starts Bleep on the Orbit 8 table',r['live'] and r['gold']==g0-300 and r['opp']=='bleep' and r['stake']==300 and r['pzn'],r)
        done=False
        for i in range(300):
            await pg.wait_for_timeout(1000)
            if await E("()=>!!document.querySelector('.pzresc')"):done=True;break
        r=await E("()=>({res:PZ.result,gold:P.gold,err:__a.err||null,live:!!PZS().live,beat:PZS().beat.bleep|0,first:(PZS().first||{}).bleep|0,vs:pzVs().bleep||null})")
        chk('a whole match against Bleep runs to a result with no errors',done and not r['err'],r)
        if done:
            res=r['res'];exp=g0-300+(res['pay']+400 if res['win'] else 0)  # trophies and cue-mastery gold were taken out of the way above
            chk('the money matches (a win pays stake x multiplier + bonus + the 400 first-win bonus; a loss keeps the stake), nothing left live',r['gold']==exp and (not res['win'] or res['pay']>=round(300*res['mult'])) and not r['live'],(r,exp))
            chk('the record follows the result (beaten count, first-win flag, head to head)',(r['beat']==1 and r['first']==1) if res['win'] else (r['beat']==0 and r['vs'] and r['vs'][1]>=1),r)
            q=await E("()=>({o8:!!document.querySelector('.pzres9.pzn8r'),bar:document.getElementById('pzbb').textContent,goal:(document.querySelector('.pzgoal')||{}).textContent||'',opened:PZ.result.opened,card:[...document.querySelectorAll('.pzun')].map(x=>x.textContent).join('|'),stage:pzPainted(document.querySelector('.pzrstage .pzstbg'))[0]})")
            if res['win']:
                chk('results after a first win: the Orbit 8 backdrop, a NEW TABLE card for Octavia, Meet Octavia, The lounge',q['o8'] and q['opened']=='octavia' and 'Octavia' in q['card'] and 'lounge' in q['bar'] and q['stage']>1000,q)
            else:
                chk('results after a loss: the Orbit 8 backdrop, The lounge, a goal that points at Bleep',q['o8'] and 'lounge' in q['bar'] and 'Bleep' in q['goal'],q)
            await pg.wait_for_timeout(800);await pg.keyboard.press('Escape');await pg.wait_for_timeout(1200)
            r2=await E("()=>({o8:!!document.querySelector('#pzh.pzn8'),sel:PZ.sel})")
            chk('Esc from the results goes back to the Orbit 8 lounge',r2['o8'] and r2['sel']==('octavia' if res['win'] else 'bleep'),r2)
        # ------------------------------------------------------------ the first Grizzle win announces the venue
        await E("()=>{P.pz=null;P.gold=20000;const Z=PZS();Z.beat={gloop:1,moldwick:1};save();casinoOpen();gameOpen('pz');pzStart({opp:'grizzle',stake:200,seed:2})}");await pg.wait_for_timeout(600)
        await E("()=>{document.getElementById('pzintro').click()}");await pg.wait_for_timeout(1500)
        await E("()=>{PZ.M.over={winner:0};PZ.M.score=[2,0];pzMatchEnd()}");await pg.wait_for_timeout(1200)
        r=await E("()=>({card:!!document.querySelector('.pzun.pzn8un'),goal:(document.querySelector('.pzgoal')||{}).textContent||'',o8:!!document.querySelector('.pzn8r')})")
        chk('beating Grizzle the first time puts a NEW VENUE: Orbit 8 card and a pointer to the pass on the results (tavern backdrop kept)',r['card'] and 'Orbit 8' in r['goal'] and not r['o8'],r)
        await pg.wait_for_timeout(600);await pg.keyboard.press('Escape');await pg.wait_for_timeout(1000)
        chk('Esc from a tavern result goes to the tavern hub, where the pass now shows NEW',await E("()=>!!document.querySelector('#pzh:not(.pzn8)')&&document.getElementById('pzn8tk').classList.contains('new')"))
        # ------------------------------------------------------------ The Regulars
        await E("()=>{const Z=PZS();Z.beat.bleep=2;save();pzRegs()}");await pg.wait_for_timeout(900)
        r=await E("()=>({tabs:[...document.querySelectorAll('.pzn8tabs button')].map(b=>b.textContent),on:(document.querySelector('.pzn8tabs button.on')||{}).dataset.v,cards:document.querySelectorAll('.pzrg').length})")
        chk('The Regulars: a Crooked Cue / Orbit 8 switch (the tavern first, from the tavern)',r['tabs']==['The Crooked Cue','Orbit 8'] and r['on']=='tavern' and r['cards']>=7,r)
        await pg.click('.pzn8tabs button[data-v=o8]');await pg.wait_for_timeout(500)
        r=await E("()=>({cards:[...document.querySelectorAll('.pzrg')].map(b=>b.dataset.k+(b.disabled?'L':'')),pt:[...document.querySelectorAll('.pzrg canvas')].map(c=>pzPainted(c)[0]>500),txt:document.querySelector('.pzrg').textContent})")
        chk('Orbit 8 tab: five cards in order, open ones painted, locked ones dark, Bleep\'s record shown',r['cards']==['bleep','octavia','facetL','rexL','vantaraL'] and all(r['pt']) and '2' in r['txt'],r)
        await pg.click('.pzrg[data-k=octavia]');await pg.wait_for_timeout(1300)
        chk('clicking an Orbit 8 card goes to the Orbit 8 hub with them picked',await E("()=>!!document.querySelector('#pzh.pzn8')&&PZ.sel==='octavia'"))
        # ------------------------------------------------------------ save normaliser and resume
        r=await E("""()=>{P.pz={beat:{grizzle:0,bleep:'x',octavia:-2,facet:2.7},rep:{rex:NaN},venue:'mars',o8:[]};const Z=PZS();const a={venue:Z.venue,o8:JSON.stringify(Z.o8),beat:JSON.stringify(Z.beat),rep:JSON.stringify(Z.rep)};
          P.pz.venue='o8';const b=PZS().venue;P.pz.beat.grizzle=1;P.pz.venue='o8';const c=PZS().venue;return {a,b,c,open:[pznOpen('bleep'),pznOpen('octavia'),pznOpen('rex')]}}""")
        chk('save normaliser: an unknown venue or Orbit 8 before Grizzle falls back to the tavern, bad counts are dropped or floored, o8 rebuilt',r['a']['venue']=='tavern' and r['a']['o8']=='{"seen":0}' and 'bleep' not in r['a']['beat'] and 'octavia' not in r['a']['beat'] and '"facet":2' in r['a']['beat'] and 'rex' not in r['a']['rep'] and r['b']=='tavern' and r['c']=='o8',r)
        chk('unlocks follow the ladder (Bleep after Grizzle, then each one once the one before is beaten)',r['open']==[True,False,True],r)
        await E("()=>{P.pz=null;P.gold=20000;const Z=PZS();Z.beat={grizzle:1,bleep:1};Z.venue='o8';save();casinoOpen();gameOpen('pz');pzStart({opp:'octavia',stake:500,seed:9})}");await pg.wait_for_timeout(500)
        await E("()=>document.getElementById('pzintro').click()");await pg.wait_for_timeout(1500)
        snap=await E("()=>{pzSave();return {gold:P.gold,opp:PZS().live&&PZS().live.opp,ok:pzLiveOk(PZS().live)}}")
        await pg.reload();await pg.wait_for_timeout(1500);await E(PRE.replace('P.gold=100000;P.pz=null;save()','0'));await E(HELP)
        await E("()=>{casinoOpen();gameOpen('pz')}");await pg.wait_for_timeout(1000)
        r=await E("()=>({o8:!!document.querySelector('#pzh.pzn8'),res:!!document.getElementById('pzresume'),gold:P.gold,live:PZS().live&&PZS().live.opp,tag:!!document.querySelector('.pz97md[data-k=octavia] .pz97tag.live')})")
        chk('reload mid-match against Octavia: the stake stays taken, the Orbit 8 hub offers Resume and her medallion shows LIVE',snap['ok'] and snap['opp']=='octavia' and r['o8'] and r['res'] and r['gold']==snap['gold'] and r['live']=='octavia' and r['tag'],(snap,r))
        await pg.click('#pzrs1');await pg.wait_for_timeout(1500)
        r=await E("()=>({pzn:PZ.pzn,opp:PZ.reg.id,stake:PZ.M.stake,bk:PZ.bk===PZN.bk})")
        chk('Resume puts you back on the Orbit 8 table against Octavia with the same stake',r['pzn'] and r['opp']=='octavia' and r['stake']==500 and r['bk'],r)
        await E("()=>pzForfeit()");await pg.wait_for_timeout(900)
        r=await E("()=>({gold:P.gold,live:PZS().live,loss:PZS().losses})")
        chk('forfeiting keeps the stake and counts the loss once',r['gold']==snap['gold'] and not r['live'] and r['loss']==1,r)
        # ------------------------------------------------------------ hub frame cost
        await E("()=>{const Z=PZS();Z.beat={grizzle:1,bleep:1,octavia:1,facet:1,rex:1};save();pzHub()}");await pg.wait_for_timeout(1500)
        r=await E("""()=>{const L=LIVE.filter(l=>l.cv&&l.cv.isConnected);const t=[];for(let i=0;i<20;i++){const a=performance.now();for(const l of L)l.fn();t.push(performance.now()-a)}t.sort((x,y)=>x-y);return {n:L.length,med:t[10],p90:t[18]}}""")
        chk(f'Orbit 8 hub: all its live canvases together cost {r["med"]:.2f} ms (median of every live drawer at once; under 3 ms)',r['med']<3,r)
        chk('no page errors in the whole run',not er,er)
        print(f'frame cost: rest median {rest[0]:.2f} ms p90 {rest[1]:.2f}; break median {brk[0]:.2f} p90 {brk[1]:.2f}; hub live {r["med"]:.2f} ms')
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
