/* ===== MOONLIT FISHING: rod look signatures (update 5) =====
   The rod TIER (90h) keeps the rod's form: shape, guides, reel, grip and tip ornament. A rod LOOK sets the material and adds
   its own signature details and a small signature animation, so every look reads on any tier from a 70 px icon up to the
   Workshop showcase:
     willow    the tier's own natural palette (no entry here, so 90h draws it exactly as before)
     ember     charred black-red wood, glowing lava cracks pulsing up the shaft, ember guides, a tip flame and rising sparks
     frost     pale ice-wood with rime and frost ferns, ice crystal clusters at the joints, icicles that drip, a tip sparkle
     moonreed  deep indigo reed with silver moon-phase inlays (crescent to full), a crescent charm and rising moon motes
     abyss     black-violet driftwood, a tentacle curled round the shaft, glowing runes, a watching eye and drifting motes
     sun       gilded brass and gold with engraved suns, a glint running up the shaft and a sunstone with a turning ray halo
     aurora    a night-dark shaft with flowing rainbow ribbons, aurora curtains rising off it, prismatic guides and a
               colour-cycling star at the tip (the master look)
   90h asks fsRodLook(sk,tier) for the look; each entry gives colours (sh shaft [dark,light], gc grip [light,dark], th thread,
   ac accent [light,mid,dark] for coral/shell/reel inlays, lc leaves, gm guide metal) and the hooks back/inner/over, which get
   the rod geometry G (at, wAt, pt, loc, rail, path, K, LOD, t, tier, tip, reel ...). Detail follows G.LOD (0 icon, 1, 2 big).
   No filters, shadows or offscreen canvases: plain paths, a few gradients, additive blending for the glows. */
const RK_TAU=Math.PI*2;
/* hsl (deg, %, %) to #rrggbb, because fkGlow appends an alpha byte to a hex colour */
function rk_hex(h,s,l){h=((h%360)+360)%360;s/=100;l/=100;const k=n=>(n+h/30)%12,a=s*Math.min(l,1-l),f=n=>Math.round(255*(l-a*Math.max(-1,Math.min(k(n)-3,9-k(n),1))));return '#'+((1<<24)+(f(0)<<16)+(f(8)<<8)+f(4)).toString(16).slice(1)}
const rk_H=i=>{const x=Math.sin(i*91.7+17.3)*24634.6345;return x-Math.floor(x)};
/* where each tier has its bands/joints, and five free spots along the shaft for inlays */
const RK_JT=[[.22,.45,.68],[.3,.55,.78],[.27,.51,.75],[.2,.46,.71],[.22,.5,.78]];
const RK_SP=[[.29,.39,.51,.62,.74],[.36,.44,.63,.71,.87],[.33,.45,.57,.69,.81],[.29,.37,.54,.63,.8],[.255,.395,.535,.675,.815]];
/* the far end of the tier's tip ornament (star, trident) so tip effects sit on top of it */
function rk_tip(G,more){const p=G.at(.9999),e=([0,0,0,6.6,15][G.tier]+(more||0))*G.K;return{x:G.tip.x+p.tx*e,y:G.tip.y+p.ty*e,tx:p.tx,ty:p.ty,nx:p.nx,ny:p.ny}}
const rk_dot=(g,x,y,r,c,a)=>{if(a<=0)return;g.globalAlpha=a;g.fillStyle=c;g.beginPath();g.arc(x,y,r,0,RK_TAU);g.fill();g.globalAlpha=1};
/* a polygon between two offset functions along the shaft */
function rk_band(G,f1,f2,u0,u1,n){const A=[];for(let i=0;i<=n;i++){const u=u0+(u1-u0)*i/n;A.push(G.pt(u,f1(u)))}const g0=A;return{top:g0,bot:Array.from({length:n+1},(_,i)=>{const u=u0+(u1-u0)*i/n;return G.pt(u,f2(u))})}}
function rk_poly(g,B){g.beginPath();B.top.forEach((q,i)=>i?g.lineTo(q.x,q.y):g.moveTo(q.x,q.y));for(let i=B.bot.length-1;i>=0;i--)g.lineTo(B.bot[i].x,B.bot[i].y);g.closePath()}

/* ---------- Emberwood ---------- */
/* the lava crack: a zigzag along the shaft with small forks to the edges */
const RK_CRK=(()=>{const M=[],F=[];let u=.175,i=0;while(u<.975){M.push([u,(i%2?1:-1)*(.16+rk_H(i)*.38)]);if(i%3===1)F.push([M.length-1,(i%2?1:-1)*(.85+rk_H(i+9)*.2),.02+rk_H(i+4)*.025]);u+=.026+rk_H(i+30)*.018;i++}M.push([.99,0]);return{M,F}})();
function rk_emberIn(g,G){const {pt,K,LOD,t}=G;
 if(LOD){/* charred, checked wood */g.strokeStyle='#060100';g.lineWidth=.75*K;g.globalAlpha=.75;g.beginPath();const n=LOD>1?26:14;for(let i=0;i<n;i++){const u=.19+(i+rk_H(i)*.6)/n*.78,o=(rk_H(i+3)-.5)*1.1,a=pt(u,o-.32),b=pt(u+.006,o+.3);g.moveTo(a.x,a.y);g.lineTo(b.x,b.y)}g.stroke();g.globalAlpha=1}
 const M=RK_CRK.M,CH=LOD>1?5:7;
 {g.beginPath();M.forEach((m,i)=>{const q=pt(m[0],m[1]);i?g.lineTo(q.x,q.y):g.moveTo(q.x,q.y)});RK_CRK.F.forEach(f=>{const a=pt(M[f[0]][0],M[f[0]][1]),b=pt(M[f[0]][0]+f[2],f[1]);g.moveTo(a.x,a.y);g.lineTo(b.x,b.y)});
  g.globalCompositeOperation='lighter';g.strokeStyle='rgba(255,80,10,.3)';g.lineWidth=3.8*K;g.stroke();g.globalCompositeOperation='source-over'}
 for(let c0=0;c0<M.length-1;c0+=CH){const c1=Math.min(M.length-1,c0+CH),um=(M[c0][0]+M[c1][0])/2,al=.5+.5*Math.max(0,Math.sin(t*3.1-um*13)),P=[];
  for(let i=c0;i<=c1;i++)P.push(pt(M[i][0],M[i][1]));
  const fk=RK_CRK.F.filter(f=>f[0]>=c0&&f[0]<c1);
  const draw=()=>{g.beginPath();P.forEach((q,i)=>i?g.lineTo(q.x,q.y):g.moveTo(q.x,q.y));fk.forEach(f=>{const a=pt(M[f[0]][0],M[f[0]][1]),b=pt(M[f[0]][0]+f[2],f[1]);g.moveTo(a.x,a.y);g.lineTo(b.x,b.y)})};
  draw();
  g.strokeStyle='#ff5a12';g.globalAlpha=.55+.45*al;g.lineWidth=1.5*K;g.stroke();if(LOD||K>.7){g.strokeStyle='#ffe49a';g.lineWidth=.6*K;g.globalAlpha=.35+.65*al;g.stroke()}g.globalAlpha=1}
}
function rk_flame(g,H,W,c,fillOnly){g.beginPath();g.moveTo(0,-H);g.bezierCurveTo(W*.35,-H*.62,W*1.05,-H*.42,W,0);g.arc(0,0,W,0,Math.PI);g.bezierCurveTo(-W*1.05,-H*.42,-W*.35,-H*.62,0,-H);g.closePath();g.fillStyle=c;g.fill()}
function rk_emberOver(g,G){const {pt,K,LOD,t}=G;
 /* a hot pulse travelling up the crack */
 if(LOD){const f=(t*.32)%1,u=.2+f*.76,q=pt(u,0);fkGlow(g,q.x,q.y,9*K,'#ff6a1a',.45*Math.sin(f*Math.PI))}
 /* rising sparks */
 const n=[3,6,10][LOD];for(let i=0;i<n;i++){const P=1.5+rk_H(i)*1.1,ph=t/P+rk_H(i+7),m=Math.floor(ph),f=ph-m,u=.24+rk_H(m*7+i)*.72,q=pt(u,-.6),
  x=q.x+Math.sin(f*6+i)*3.5*K+f*7*K,y=q.y-f*(22+rk_H(i+2)*16)*K,s=(1.5-f)*K*(LOD?1:1.2),al=Math.min(1,f*6)*(1-f);
  if(LOD>1&&i%3===0)fkGlow(g,x,y,5*K,'#ff7a1a',.5*al);rk_dot(g,x,y,s,i%2?'#ffb04a':'#ff6a1a',al);if(LOD)rk_dot(g,x,y,s*.45,'#fff2c0',al)}
 /* the tip flame */
 const T=rk_tip(G,1.2),fz=LOD?1:1.25,H=(10+2.2*Math.sin(t*13)+1.4*Math.sin(t*21.7))*K*fz,W=3.4*K*fz,sw=Math.sin(t*7)*.12+Math.sin(t*11.3)*.06;
 fkGlow(g,T.x,T.y-H*.35,H*1.5,'#ff7a1a',.5+.12*Math.sin(t*9));
 g.save();g.translate(T.x,T.y);g.rotate(sw);
 rk_flame(g,H,W,'#ff4a10');g.lineWidth=G.ol*.85;g.strokeStyle=FKO;g.stroke();
 g.save();g.translate(0,W*.15);rk_flame(g,H*.72,W*.7,'#ffa22e');g.translate(0,W*.15);rk_flame(g,H*.42,W*.42,'#fff3b8');g.restore();
 g.restore()}

/* ---------- Frostline ---------- */
function rk_frostIn(g,G){const {pt,K,LOD,t,rail}=G;
 /* rime along the top edge */
 rail(-.84,.17,.99);g.strokeStyle='#ffffff';g.globalAlpha=.8;g.lineWidth=Math.max(1,1.3*K);g.stroke();g.globalAlpha=1;
 if(LOD){const n=LOD>1?46:24;g.fillStyle='#ffffff';for(let i=0;i<n;i++){const u=.18+rk_H(i)*.8,o=-1+Math.pow(rk_H(i+5),2)*1.1,q=pt(u,o);g.globalAlpha=.45+.5*rk_H(i+9);g.beginPath();g.arc(q.x,q.y,(.35+rk_H(i+2)*.5)*K,0,RK_TAU);g.fill()}g.globalAlpha=1;
  /* ice fractures inside */g.strokeStyle='#5a90c0';g.lineWidth=.6*K;g.globalAlpha=.55;g.beginPath();[.31,.57,.82].forEach((u,j)=>{let a=pt(u,.7);g.moveTo(a.x,a.y);for(let k=1;k<4;k++){a=pt(u+k*.012,.7-k*.38+(k%2?.12:-.1));g.lineTo(a.x,a.y)}});g.stroke();g.globalAlpha=1}
 if(LOD>1){/* frost ferns growing in from the top edge */g.strokeStyle='#ffffff';g.lineWidth=.55*K;g.globalAlpha=.7;g.beginPath();[.26,.42,.6,.77,.9].forEach((u,j)=>{const L=.035-u*.012;for(let k=0;k<=4;k++){const s=k/4,a=pt(u+L*s,-1+s*.9);if(!k)g.moveTo(a.x,a.y);else g.lineTo(a.x,a.y)}for(let k=1;k<4;k++){const s=k/4,a=pt(u+L*s,-1+s*.9),b=pt(u+L*s-.008,-1+s*.9+.28),c=pt(u+L*s+.009,-1+s*.9-.05);g.moveTo(a.x,a.y);g.lineTo(b.x,b.y);g.moveTo(a.x,a.y);g.lineTo(c.x,c.y)}});g.stroke();g.globalAlpha=1}
}
function rk_shard(g,x,y,dx,dy,L,w){const px=-dy,py=dx;g.moveTo(x-px*w*.5,y-py*w*.5);g.lineTo(x+dx*L*.4-px*w,y+dy*L*.4-py*w);g.lineTo(x+dx*L,y+dy*L);g.lineTo(x+dx*L*.4+px*w,y+dy*L*.4+py*w);g.lineTo(x+px*w*.5,y+py*w*.5);g.closePath()}
function rk_frostOver(g,G){const {pt,K,LOD,t,ol,tier}=G;
 /* ice crystal clusters at the joints */
 const JT=RK_JT[tier],SH=LOD?[[-.62,6.8],[0,11],[.55,6],[-1.15,4.2]]:[[-.45,7],[.25,9.5]],facets=[];
 g.beginPath();JT.forEach((u,j)=>{const p=G.at(u),b=pt(u,-.8),ox=-p.nx,oy=-p.ny,sc=(1.15-u*.45)*K;SH.forEach(([an,L],k)=>{const c=Math.cos(an+(j%2?.15:-.1)),s=Math.sin(an+(j%2?.15:-.1)),dx=ox*c-oy*s,dy=ox*s+oy*c,LL=L*sc;rk_shard(g,b.x+p.tx*(k-1)*1.4*K,b.y+p.ty*(k-1)*1.4*K,dx,dy,LL,LL*.26);facets.push([b.x+p.tx*(k-1)*1.4*K,b.y+p.ty*(k-1)*1.4*K,dx,dy,LL])});
  if(LOD){const d=pt(u,.85);[[.5,4],[-.35,3.2]].forEach(([an,L])=>{const c=Math.cos(an),s=Math.sin(an),dx=p.nx*c-p.ny*s,dy=p.nx*s+p.ny*c;rk_shard(g,d.x,d.y,dx,dy,L*sc,L*sc*.28)})}});
 g.fillStyle='#e9fbff';g.fill();g.lineWidth=ol*.8;g.strokeStyle=FKO;g.stroke();
 if(LOD){g.beginPath();facets.forEach(([x,y,dx,dy,L])=>{const w=L*.26;g.moveTo(x,y);g.lineTo(x+dx*L*.4+dy*w*.9,y+dy*L*.4-dx*w*.9);g.lineTo(x+dx*L,y+dy*L);g.closePath()});g.fillStyle='#a6dcf8';g.fill();
  g.beginPath();facets.forEach(([x,y,dx,dy,L])=>{g.moveTo(x+dx*L*.1,y+dy*L*.1);g.lineTo(x+dx*L*.9,y+dy*L*.9)});g.strokeStyle='#ffffff';g.lineWidth=.6*K;g.stroke()}
 /* icicles hanging under the shaft (they always hang straight down) */
 const IC=LOD?[.33,.41,.5,.59,.66,.74,.83,.9]:[.38,.55,.72,.86],tips=[];g.beginPath();IC.forEach((u,i)=>{const q=pt(u,.82),L=(6+rk_H(i+3)*7)*K*(1.2-u*.5)*(LOD?1:1.2),w=(1.7+rk_H(i)*1)*K*(1.1-u*.35);
  g.moveTo(q.x-w,q.y-.5);g.quadraticCurveTo(q.x-w*.45,q.y+L*.55,q.x,q.y+L);g.quadraticCurveTo(q.x+w*.45,q.y+L*.55,q.x+w,q.y-.5);g.closePath();tips.push([q.x,q.y,L,w])});
 g.fillStyle='rgba(176,230,255,.62)';g.fill();g.lineWidth=ol*.75;g.strokeStyle='#1b2a4a';g.stroke();
 g.beginPath();tips.forEach(([x,y,L,w])=>{g.moveTo(x-w*.45,y+.8);g.lineTo(x-w*.1,y+L*.66)});g.strokeStyle='#ffffff';g.lineWidth=Math.max(.7,.9*K);g.stroke();
 if(LOD){g.beginPath();tips.forEach(([x,y,L,w])=>{g.moveTo(x+w*.5,y+1);g.lineTo(x+w*.15,y+L*.5)});g.strokeStyle='#6ab8e8';g.lineWidth=.6*K;g.stroke()}
 /* one icicle at a time grows a drip and lets it fall */
 {const P=1.35,ph=t/P,k=Math.floor(ph)%tips.length,f=ph-Math.floor(ph),[x,y,L]=tips[(k*3)%tips.length];let r=1.1*K*Math.min(1,f/.55),dy=0,al=1;if(f>.6){const e=(f-.6)/.4;dy=e*e*20*K;al=1-e}
  if(al>0){g.globalAlpha=al;g.beginPath();g.arc(x,y+L+r*.6+dy,r,0,RK_TAU);g.fillStyle='#e6f8ff';g.fill();g.lineWidth=.5*K;g.strokeStyle=FKO;g.stroke();g.globalAlpha=1}}
 /* snowflakes drifting down past the rod */
 for(let i=0;i<[0,3,6][LOD];i++){const P=3.4+rk_H(i)*1.6,ph=t/P+rk_H(i+4),m=Math.floor(ph),f=ph-m,q=pt(.3+rk_H(m*3+i)*.65,-2.2),x=q.x+Math.sin(f*5+i)*5*K,y=q.y+f*34*K,r=(1.6+rk_H(i+8))*K,al=Math.sin(f*Math.PI)*.85;
  g.save();g.translate(x,y);g.rotate(f*2+i);g.globalAlpha=al;g.strokeStyle='#e8f8ff';g.lineWidth=.6*K;g.beginPath();for(let k=0;k<3;k++){const an=k*Math.PI/3;g.moveTo(-Math.cos(an)*r,-Math.sin(an)*r);g.lineTo(Math.cos(an)*r,Math.sin(an)*r)}g.stroke();g.restore()}
 /* the frost sparkle at the tip */
 const T=rk_tip(G,.6),s=(5+1.6*Math.sin(t*3.4))*K*(LOD?1:1.15);fkGlow(g,T.x,T.y,s*2.8,'#9ff0ff',.55);fkSpark(g,T.x,T.y,s,'#ffffff',.95);g.save();g.translate(T.x,T.y);g.rotate(Math.PI/4+t*.6);fkSpark(g,0,0,s*.6,'#c8f6ff',.85);g.restore();
 if(LOD){/* glints running over the ice */for(let i=0;i<2;i++){const P=2.6,f=((t+i*1.3)%P)/P;if(f<.25){const q=pt(.25+rk_H(Math.floor((t+i*1.3)/P)*5+i)*.7,-.55);fkSpark(g,q.x,q.y,4.5*K*Math.sin(f/.25*Math.PI),'#ffffff',.95)}}}
}

/* ---------- Moonreed ---------- */
/* a moon disc showing phase f (0 new .. 1 full), lit from +x */
function rk_moon(g,x,y,r,f,rot,K){g.save();g.translate(x,y);g.rotate(rot);g.beginPath();g.arc(0,0,r,0,RK_TAU);g.fillStyle='#07051c';g.fill();
 g.beginPath();if(f>=.99)g.arc(0,0,r,0,RK_TAU);else{g.arc(0,0,r,-Math.PI/2,Math.PI/2,false);g.ellipse(0,0,Math.abs(1-2*f)*r,r,0,Math.PI/2,-Math.PI/2,f<.5)}g.fillStyle='#f2f3ff';g.fill();
 g.beginPath();g.arc(0,0,r+.35*K,0,RK_TAU);g.lineWidth=Math.max(.8,1.5*K);g.strokeStyle=FKO;g.stroke();g.lineWidth=Math.max(.5,.75*K);g.strokeStyle='#e2e6ff';g.stroke();g.restore()}
function rk_moonIn(g,G){const {pt,K,LOD,t,rail,tier,wAt,at}=G;
 rail(-.84,.17,.99);g.strokeStyle='#b4b0ff';g.globalAlpha=.65;g.lineWidth=Math.max(.9,.9*K);g.stroke();g.globalAlpha=1;
 if(LOD){g.strokeStyle='#7a74d8';g.lineWidth=.6*K;g.globalAlpha=.28;[-.45,.15,.6].forEach(o=>{rail(o,.17,.99);g.stroke()});g.globalAlpha=1;
  rail(0,.2,.96);g.strokeStyle='#c8ccf2';g.globalAlpha=.5;g.lineWidth=.55*K;g.setLineDash([3*K,2*K]);g.stroke();g.setLineDash([]);g.globalAlpha=1}
}
function rk_moonOver(g,G){const {pt,K,LOD,t,tier,wAt,at,ol}=G;
 /* moon-phase inlays, crescent to full */
 const PH=[.2,.38,.6,.82,1];RK_SP[tier].forEach((u,i)=>{const p=at(u),r=Math.max(1.3*K,wAt(u)/2*.74);if(LOD>1)fkGlow(g,p.x,p.y,r*3,'#c8c4ff',.22+.12*Math.sin(t*1.7-i));rk_moon(g,p.x,p.y,r,PH[i],Math.atan2(p.ty,p.tx),K)});
 /* moonlight motes rising off the reed */
 const n=[2,4,7][LOD];for(let i=0;i<n;i++){const P=3.3,ph=t/P+i/n,m=Math.floor(ph),f=ph-m,q=pt(.24+rk_H(m*5+i)*.7,-1.3),x=q.x+Math.sin(f*4+i)*5*K,y=q.y-f*30*K,al=Math.sin(f*Math.PI)*.9;
  if(LOD>1||(LOD&&i%2))fkGlow(g,x,y,7*K,'#c8c0ff',.5*al);rk_dot(g,x,y,1.15*K,'#f6f4ff',al)}
 /* the crescent charm hanging under the reed near the grip */
 const q=pt(.265,1),sw=Math.sin(t*1.9+1)*.26+Math.sin(t*3.1)*.06,cl=(LOD?10:8)*K,ex=q.x+Math.sin(sw)*cl,ey=q.y+Math.cos(sw)*cl;
 if(LOD){g.strokeStyle=FKO;g.lineWidth=1.6*K;g.beginPath();g.moveTo(q.x,q.y);g.lineTo(ex,ey);g.stroke();g.strokeStyle='#d6dcf4';g.lineWidth=.75*K;g.setLineDash([1.3*K,.9*K]);g.stroke();g.setLineDash([])}
 else{g.strokeStyle='#c8ccf0';g.lineWidth=.8;g.beginPath();g.moveTo(q.x,q.y);g.lineTo(ex,ey);g.stroke()}
 const cr=(LOD?6:5.4)*K,cx=ex+Math.sin(sw)*cr*.85,cy=ey+Math.cos(sw)*cr*.85;
 fkGlow(g,cx,cy,cr*2.6*G.GK,'#d8d4ff',.4+.12*Math.sin(t*2.3));fsCrescP(g,cx,cy,cr,Math.PI/2-sw+Math.PI*.18,.5);g.fillStyle=fkRad(g,cx,cy,cr,['#ffffff','#e6e8ff','#8a90cc']);g.fill();g.lineWidth=ol*.9;g.strokeStyle=FKO;g.stroke();
 if(LOD)fkSpark(g,cx-Math.sin(sw)*cr*.1+cr*.42,cy+cr*.15,2.6*K*(.8+.2*Math.sin(t*3)),'#ffffff',.95);
 /* a silver halo round the tip */
 const T=rk_tip(G);if(LOD){g.strokeStyle=`rgba(220,216,255,${.45+.2*Math.sin(t*2)})`;g.lineWidth=.8*K;g.beginPath();g.arc(T.x,T.y,(5.5+.8*Math.sin(t*2))*K,0,RK_TAU);g.stroke()}
 fkGlow(g,T.x,T.y,10*K*G.GK,'#c8c0ff',.4)}

/* ---------- Abyssal ---------- */
/* the tentacle: a helix round the shaft (behind it where sin(phi)<0), leaving the top edge in a free curl */
const RK_TU0=.3,RK_TU1=.6,RK_TPH0=-.7,RK_TPH1=Math.PI*3;
function rk_tent(G){const {pt,K,LOD,t}=G,M=[16,26,34][LOD],S=[];
 for(let i=0;i<=M;i++){const s=i/M,u=RK_TU0+(RK_TU1-RK_TU0)*s,ph=RK_TPH0+(RK_TPH1-RK_TPH0)*s+Math.sin(t*1.3+s*4)*.06,o=Math.cos(ph)*1.15,q=pt(u,o),fr=Math.sin(ph)>0;S.push({x:q.x,y:q.y,w:(2.9-1.25*s)*K*(fr?1.06:.94),f:fr,s})}
 /* the free curl, in a local frame: +x along the shaft, away from it on the top side */
 const e=G.at(RK_TU1),E=S[S.length-1];let x=E.x,y=E.y,ps=.35+Math.sin(t*1.2)*.2;const n2=[8,12,18][LOD],kap=5.6+Math.sin(t*1.6)*.6,stp=26*K/n2;
 for(let i=1;i<=n2;i++){const s=i/n2;ps+=kap/n2*(.35+s*1.1);const c=Math.cos(ps),sn=Math.sin(ps),k=stp*(1-.6*s);x+=(e.tx*c-e.nx*sn)*k;y+=(e.ty*c-e.ny*sn)*k;S.push({x,y,w:Math.max(.4*K,1.65*K*(1-s*.85)),f:true,s:1+s})}
 for(let i=0;i<S.length;i++){const a=S[Math.max(0,i-1)],b=S[Math.min(S.length-1,i+1)],dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy)||1;S[i].nx=-dy/d;S[i].ny=dx/d}
 const R=[];let cur=null;S.forEach((p,i)=>{if(!cur||cur.f!==p.f){if(cur)cur.P.push(p);cur={f:p.f,P:cur?[S[i-1],p]:[p]};R.push(cur)}else cur.P.push(p)});return{S,R}}
function rk_tentRun(g,G,P,front){if(!fsRfRibbon(g,P))return;g.fillStyle=front?'#6a2c9c':'#2c1448';g.fill();g.lineWidth=G.ol;g.strokeStyle=FKO;g.stroke();
 if(!front)return;const side=(f,c,w,al)=>{g.beginPath();P.forEach((p,i)=>{const X=p.x+p.nx*p.w*f,Y=p.y+p.ny*p.w*f;i?g.lineTo(X,Y):g.moveTo(X,Y)});g.strokeStyle=c;g.globalAlpha=al;g.lineWidth=w;g.stroke()};
 side(.5,'#c062d8',Math.max(1,1.3*G.K),.9);if(G.LOD)side(-.5,'#9a66e8',Math.max(.6,.65*G.K),.8);g.globalAlpha=1}
function rk_abyssBack(g,G){const T=rk_tent(G);G._rkT=T;T.R.forEach(r=>{if(!r.f)rk_tentRun(g,G,r.P,false)})}
const rk_c8=(r,cx)=>Array.from({length:9},(_,k)=>[(cx||0)+Math.cos(k*Math.PI/4)*r,Math.sin(k*Math.PI/4)*r]);
const RK_GLY=[[rk_c8(.55),[[0,-1],[0,1]]],[[[0,-1],[.8,0],[0,1],[-.8,0],[0,-1]],[[-.2,0],[.2,0]]],[[[-.8,1],[-.8,-.2],[0,-1],[.8,-.2],[.8,1]],[[0,-.35],[0,1]]],[Array.from({length:12},(_,k)=>{const r=.12+.85*k/11,a=k*.95;return[Math.cos(a)*r,Math.sin(a)*r]})]];
function rk_abyssIn(g,G){const {pt,K,LOD,t,rail,tier,loc}=G;
 if(LOD){/* driftwood grain */g.strokeStyle='#04010a';g.lineWidth=.7*K;g.globalAlpha=.6;(LOD>1?[-.55,-.05,.45]:[-.4,.35]).forEach((o,j)=>{rail(u=>o+.18*Math.sin(u*(22+j*9)+j),.17,.99);g.stroke()});g.globalAlpha=1}
 /* a violet rim light keeps the black wood readable at night */
 rail(-.84,.17,.99);g.strokeStyle='#8a5ad8';g.globalAlpha=.85;g.lineWidth=Math.max(.9,1*K);g.stroke();g.globalAlpha=1;
 /* glowing runes */
 RK_SP[tier].forEach((u,i)=>{const al=.4+.6*Math.max(0,Math.sin(t*2.1-i*1.15)),c=i%2?'#c06aff':'#ff5ae0';
  loc(u,0,hw=>{const s=hw*.62;if(!LOD){g.fillStyle=c;g.globalAlpha=.55+.45*al;g.fillRect(-s*.9,-s*.25,s*1.8,s*.5);g.globalAlpha=1;return}
   g.beginPath();RK_GLY[i%4].forEach(L=>L.forEach(([x,y],k)=>k?g.lineTo(x*s,y*s):g.moveTo(x*s,y*s)));
   if(LOD>1){g.globalCompositeOperation='lighter';g.strokeStyle=c;g.globalAlpha=.4*al;g.lineWidth=2.6*K;g.stroke();g.globalCompositeOperation='source-over'}else{g.strokeStyle=c;g.globalAlpha=.3*al;g.lineWidth=2*K;g.stroke()}g.strokeStyle=fsMix(c,'#ffffff',.45);g.globalAlpha=.5+.5*al;g.lineWidth=.8*K;g.stroke();g.globalAlpha=1})});
}
function rk_abyssOver(g,G){const {pt,K,LOD,t,at,wAt,ol}=G;const T=G._rkT||rk_tent(G);G._rkT=null;
 T.R.forEach(r=>{if(r.f)rk_tentRun(g,G,r.P,true)});
 if(LOD){/* suckers on the visible tentacle, and glowing spots */const SK=T.S.filter((p,i)=>p.f&&!(i%(LOD>1?2:3))&&p.s<=1.75).map(p=>[p.x+p.nx*p.w*.3,p.y+p.ny*p.w*.3,p.w*.36]);g.beginPath();SK.forEach(([x,y,r])=>{g.moveTo(x+r,y);g.arc(x,y,r,0,RK_TAU)});g.fillStyle='#f0b8f6';g.fill();g.lineWidth=.45*K;g.strokeStyle=FKO;g.stroke();
  g.beginPath();SK.forEach(([x,y,r])=>{g.moveTo(x+r*.4,y);g.arc(x,y,r*.4,0,RK_TAU)});g.fillStyle='#7a2a8a';g.fill();
  T.S.forEach((p,i)=>{if(!p.f||i%4!==1)return;const al=.5+.5*Math.sin(t*2.6-i*.7),x=p.x-p.nx*p.w*.4,y=p.y-p.ny*p.w*.4;if(LOD>1)fkGlow(g,x,y,4.5*K,'#ff5ae0',.55*al);rk_dot(g,x,y,.75*K,'#ffc8f4',.4+.6*al)})}
 /* the eye near the grip */
 {const u=.245,p=at(u),hw=wAt(u)/2,rx=Math.max(2.4*K,hw*1.2),ry0=Math.max(1.7*K,hw*.82),bp=t%5.3,bl=bp<.2?Math.abs(Math.cos(bp/.2*Math.PI)):1,ry=ry0*Math.max(.08,bl);
  if(LOD)fkGlow(g,p.x,p.y,rx*2.6,'#ff4ad8',.3+.12*Math.sin(t*1.8));
  g.save();g.translate(p.x,p.y);g.rotate(Math.atan2(p.ty,p.tx));
  const alm=(x,y)=>{g.beginPath();g.moveTo(-x,0);g.quadraticCurveTo(0,-y*1.7,x,0);g.quadraticCurveTo(0,y*1.7,-x,0);g.closePath()};
  alm(rx*1.25,ry0*1.2);g.fillStyle='#160a26';g.fill();g.lineWidth=ol*.8;g.strokeStyle=FKO;g.stroke();
  alm(rx,ry);g.save();g.clip();const px=Math.sin(t*.7)*rx*.28;g.fillStyle=fkRad(g,px,0,ry0*1.05,['#fff4a8','#ff6ae8','#5a1478']);g.fillRect(-rx,-ry0*2,rx*2,ry0*4);
  g.fillStyle='#0a0210';g.beginPath();g.ellipse(px,0,Math.max(.4,ry0*.2),ry0*.82,0,0,RK_TAU);g.fill();if(LOD)rk_dot(g,px-ry0*.35,-ry0*.4,ry0*.2,'#ffffff',.9);g.restore();
  alm(rx,ry);g.lineWidth=.6*K;g.strokeStyle='#ff9af0';g.globalAlpha=.6;g.stroke();g.globalAlpha=1;g.restore()}
 /* abyssal motes drifting and sinking */
 const n=[1,4,7][LOD];for(let i=0;i<n;i++){const P=4.6+rk_H(i)*1.5,ph=t/P+rk_H(i+3),m=Math.floor(ph),f=ph-m,side=i%2?1.7:-1.9,q=pt(.28+rk_H(m*9+i)*.66,side),x=q.x+f*12*K+Math.sin(f*6+i)*3*K,y=q.y+f*9*K,al=Math.sin(f*Math.PI)*.85,c=i%2?'#c06aff':'#ff5ae0';
  if(LOD>1)fkGlow(g,x,y,6*K,c,.45*al);rk_dot(g,x,y,(LOD>1?.95:1.1)*K,'#ffd8fa',al)}
 const Tp=rk_tip(G);fkGlow(g,Tp.x,Tp.y,11*K*G.GK,'#ff5ae0',.4+.15*Math.sin(t*2.2))}

/* ---------- Sunforged ---------- */
function rk_sunIn(g,G){const {pt,K,LOD,t,tier,loc,at}=G;
 if(LOD)RK_SP[tier].forEach((u,i)=>loc(u,0,hw=>{const r=hw*.4,eng=(dx,dy,c,a)=>{g.save();g.translate(dx,dy);g.strokeStyle=c;g.globalAlpha=a;g.lineWidth=.6*K;g.beginPath();g.arc(0,0,r,0,RK_TAU);for(let k=0;k<8;k++){const an=k*Math.PI/4,r2=r*(k%2?1.8:2.7);g.moveTo(Math.cos(an)*r*1.35,Math.sin(an)*r*1.35);g.lineTo(Math.cos(an)*r2,Math.sin(an)*r2)}g.stroke();g.restore()};
  eng(.45*K,.45*K,'#fff8d0',.7);eng(0,0,'#6a3a04',.8)}));
 if(LOD>1){/* fine engraved chevrons between the suns */g.strokeStyle='#7a4a08';g.lineWidth=.45*K;g.globalAlpha=.5;g.beginPath();for(let i=0;i<14;i++){const u=.2+i*.055,a=pt(u,-.55),b=pt(u+.01,0),c=pt(u,.55);g.moveTo(a.x,a.y);g.lineTo(b.x,b.y);g.lineTo(c.x,c.y)}g.stroke();g.globalAlpha=1}
 /* a warm glint running up the gilt */
 const P=2.5,f=(t%P)/P;if(f<.55){const u=.17+f/.55*.83;loc(u,0,hw=>{const L=12*K;g.save();g.globalCompositeOperation='lighter';const q=g.createLinearGradient(-L,0,L,0);q.addColorStop(0,'rgba(255,240,180,0)');q.addColorStop(.5,'rgba(255,250,225,.85)');q.addColorStop(1,'rgba(255,240,180,0)');g.fillStyle=q;g.transform(1,0,-.5,1,0,0);g.fillRect(-L,-hw-1,L*2,hw*2+2);g.restore()})}
}
function rk_sunOver(g,G){const {pt,K,LOD,t,ol}=G;
 const P=2.5,f=(t%P)/P;if(f<.55){const u=.17+f/.55*.83,q=pt(u,-.6);fkSpark(g,q.x,q.y,(LOD?4.6:3.4)*K*Math.sin(f/.55*Math.PI),'#fffbe8',.95)}
 if(LOD>1)for(let i=0;i<4;i++){const P2=2.8,ph=t/P2+i/4,m=Math.floor(ph),f2=ph-m,q=pt(.25+rk_H(m*4+i)*.7,-1.2),al=Math.sin(f2*Math.PI)*.8;rk_dot(g,q.x+f2*4*K,q.y-f2*16*K,.8*K,'#ffe8a0',al)}
 /* the sunstone with its turning ray halo */
 const T=rk_tip(G,2.6),sc=LOD?1:1.45,R=3.8*K*sc,pul=1+.08*Math.sin(t*3);
 fkGlow(g,T.x,T.y,15*K*sc,'#ffc840',.55+.12*Math.sin(t*2.4));if(LOD)fkGlow(g,T.x,T.y,7*K*sc,'#fff2b0',.5);
 g.save();g.translate(T.x,T.y);g.rotate(t*.45);g.beginPath();const n=LOD?12:8;for(let k=0;k<n;k++){const an=k*RK_TAU/n,L=(k%2?6.2:9.8)*K*sc*pul,w=(k%2?.75:1)*K*sc*1.1;g.moveTo(Math.cos(an-.22)*R*1.05,Math.sin(an-.22)*R*1.05);g.lineTo(Math.cos(an)*L,Math.sin(an)*L);g.lineTo(Math.cos(an+.22)*R*1.05,Math.sin(an+.22)*R*1.05);g.closePath()}
 g.fillStyle='#ffd24a';g.fill();g.lineWidth=Math.max(.5,.55*K);g.strokeStyle='#a2580a';g.stroke();g.restore();
 g.beginPath();g.arc(T.x,T.y,R,0,RK_TAU);g.fillStyle=fkRad(g,T.x,T.y,R,['#fffbe0','#ffb02a','#c0420a']);g.fill();g.lineWidth=ol*.9;g.strokeStyle=FKO;g.stroke();
 if(LOD){g.strokeStyle='#ffe6a0';g.globalAlpha=.7;g.lineWidth=.5*K;g.beginPath();for(let k=0;k<6;k++){const an=k*Math.PI/3+.3;g.moveTo(T.x+Math.cos(an)*R*.45,T.y+Math.sin(an)*R*.45);g.lineTo(T.x+Math.cos(an+Math.PI/3)*R*.45,T.y+Math.sin(an+Math.PI/3)*R*.45)}g.stroke();g.globalAlpha=1}
 rk_dot(g,T.x-R*.35,T.y-R*.38,R*.24,'#ffffff',.9)}

/* ---------- Aurora ---------- */
function rk_aurGrad(g,G){const a=G.at(.17),b=G.at(.999),q=g.createLinearGradient(a.x,a.y,b.x,b.y),h0=G.t*42;for(let k=0;k<=5;k++)q.addColorStop(k/5,rk_hex(h0+k*62,95,62));return q}
function rk_aurIn(g,G){const {pt,K,LOD,t}=G;const q=rk_aurGrad(g,G);G._rkA=q;
 if(LOD){g.fillStyle='#ffffff';for(let j=0;j<2;j++){g.beginPath();for(let i=j;i<(LOD>1?16:9);i+=2){const p=pt(.2+rk_H(i+2)*.78,(rk_H(i+6)-.5)*1.4);g.moveTo(p.x+.5*K,p.y);g.arc(p.x,p.y,.5*K,0,RK_TAU)}g.globalAlpha=.35+.55*Math.abs(Math.sin(t*1.9+j*1.6));g.fill()}g.globalAlpha=1}
 g.save();g.globalCompositeOperation='lighter';g.fillStyle=q;const n=LOD?40:20;
 const RB=LOD?[[0,.24,.8],[2.2,.16,.55]]:[[0,.34,.95]];
 RB.forEach(([ph,th,al])=>{const c=u=>Math.sin(u*9+ph-t*1.9)*.46;rk_poly(g,rk_band(G,u=>c(u)-th,u=>c(u)+th,.17,.995,n));g.globalAlpha=al;g.fill()});g.restore();g.globalAlpha=1}
function rk_aurOver(g,G){const {pt,K,LOD,t,at}=G;const q=G._rkA||rk_aurGrad(g,G);G._rkA=null;
 /* aurora curtains rising off the top of the shaft */
 const n=LOD?36:18,u0=.21,u1=.985,H=u=>K*(LOD?1:.8)*(7+11*(.5+.5*Math.sin(u*17-t*1.5)))*(.62+.38*Math.sin(u*6.3+t*.8))*Math.min(1,(u-u0)/.08,(u1-u)/.06),base=[];
 for(let i=0;i<=n;i++){const u=u0+(u1-u0)*i/n,p=at(u),b=pt(u,-1);base.push([b.x,b.y,-p.nx,-p.ny,H(u)])}
 g.save();g.globalCompositeOperation='lighter';g.fillStyle=q;const LAY=LOD>1?[[1,.17],[.66,.22],[.33,.3]]:[[1,.24],[.5,.36]];
 LAY.forEach(([f,al])=>{g.beginPath();base.forEach(([x,y,ox,oy,h],i)=>{const X=x+ox*h*f+Math.sin(t*1.1+i*.7)*.6*K*f,Y=y+oy*h*f;i?g.lineTo(X,Y):g.moveTo(X,Y)});for(let i=base.length-1;i>=0;i--)g.lineTo(base[i][0],base[i][1]);g.closePath();g.globalAlpha=al;g.fill()});
 if(LOD){g.strokeStyle=q;g.lineWidth=Math.max(.8,1*K);g.globalAlpha=.5;g.beginPath();base.forEach(([x,y,ox,oy,h],i)=>{const X=x+ox*h+Math.sin(t*1.1+i*.7)*.6*K,Y=y+oy*h;i?g.lineTo(X,Y):g.moveTo(X,Y)});g.stroke()}
 if(LOD>1){g.strokeStyle=q;g.lineWidth=.7*K;g.globalAlpha=.35;g.beginPath();base.forEach(([x,y,ox,oy,h],i)=>{if(i%2)return;g.moveTo(x,y);g.lineTo(x+ox*h*.95,y+oy*h*.95)});g.stroke()}
 g.restore();g.globalAlpha=1;
 /* prismatic motes drifting up the curtain */
 for(let i=0;i<[1,3,6][LOD];i++){const P=3+rk_H(i)*1.4,ph=t/P+rk_H(i+5),m=Math.floor(ph),f=ph-m,b=pt(.25+rk_H(m*3+i)*.7,-1.4),x=b.x+Math.sin(f*4+i)*4*K,y=b.y-f*24*K,al=Math.sin(f*Math.PI);
  fkSpark(g,x,y,(2+1.2*Math.sin(t*5+i))*K,rk_hex(t*60+i*70,100,80),al*.9)}
 /* the star-bright tip with a colour-cycling glow */
 const T=rk_tip(G,.8),hc=rk_hex(t*90,100,66),s=(6.4+1.6*Math.sin(t*3.3))*K*(LOD?1:1.2);
 fkGlow(g,T.x,T.y,s*3.2,hc,.6);fkGlow(g,T.x,T.y,s*1.4,'#ffffff',.45);
 g.save();g.translate(T.x,T.y);g.rotate(t*.35);fkSpark(g,0,0,s,'#ffffff',1);g.rotate(Math.PI/4);fkSpark(g,0,0,s*.62,rk_hex(t*90+120,100,82),.95);g.restore()}
const rk_prism=(u,t)=>{const h=t*70+u*320;return[rk_hex(h,100,93),rk_hex(h,90,66),rk_hex(h,70,30)]};

/* ---------- the looks ---------- */
const FSRLOOK={
 ember:{sh:['#1a0b08','#4e1d12'],gc:['#3a1a12','#120604'],th:'#6a1e0c',ac:['#ffb066','#e2541a','#4a1206'],lc:[['#4a120a','#ff6a1a'],['#6a240a','#ffb04a']],gm:['#fff0b0','#ff8a2a','#8a2a08'],inner:rk_emberIn,over:rk_emberOver},
 frost:{sh:['#4a82b6','#d6f3ff'],gc:['#eef8ff','#93bcd9'],th:'#eaf8ff',ac:['#eaf9ff','#7cc2ea','#2a5a8a'],lc:[['#5a9ac8','#e2f6ff'],['#7ab8e0','#ffffff']],gm:['#ffffff','#c4ecff','#4a7aa8'],inner:rk_frostIn,over:rk_frostOver},
 moonreed:{sh:['#17144c','#4a44ac'],gc:['#2c2a72','#100e34'],th:'#c8ccec',ac:['#d8d4ff','#6a62d0','#1a1650'],lc:[['#2a2878','#b8b0ff'],['#3a3690','#e0dcff']],gm:['#ffffff','#dcdcf8','#6a6aa8'],inner:rk_moonIn,over:rk_moonOver},
 abyss:{sh:['#0e071c','#3e2668'],gc:['#2a1844','#0c0618'],th:'#5a2a8a',ac:['#ff8ae8','#8a3ad0','#1a0a36'],lc:[['#2a1048','#c86aff'],['#3a1a5a','#ff6ae8']],gm:['#f4d8ff','#8a52c8','#24103e'],back:rk_abyssBack,inner:rk_abyssIn,over:rk_abyssOver},
 sun:{sh:['#9a5c0a','#ffe27a'],gc:['#8a2c10','#3a1206'],th:'#ffd45a',ac:['#fff2b0','#f0a020','#7a3e06'],lc:[['#b07a14','#ffe07a'],['#c89020','#fff2b0']],gm:['#fff6c8','#f2c444','#8a5a0e'],inner:rk_sunIn,over:rk_sunOver},
 aurora:{sh:['#0a0922','#28225e'],gc:['#221c52','#0a0822'],th:'#7affd8',ac:['#b8fff0','#3ab8b0','#122e58'],lc:[['#1a7a8a','#7affd8'],['#7a2a9a','#ff8ae8']],gm:rk_prism,inner:rk_aurIn,over:rk_aurOver}};
/* which look a skin object is (by identity, then by name); null for Willow and anything unknown */
function fsRodLook(sk){if(!sk)return null;for(const k in FSKIN)if(FSKIN[k]===sk)return FSRLOOK[k]||null;if(sk.n)for(const k in FSKIN)if(FSKIN[k].n===sk.n)return FSRLOOK[k]||null;return null}
