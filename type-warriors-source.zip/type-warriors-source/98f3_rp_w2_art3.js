/* ===== RUNESTONE TOWER DEFENSE 10.1: World 2 art, part 3 - more detail, more life, things that react (98f3, after 98f2) =====
   98f / 98f2 paint the three World 2 maps and the hub painting; this module adds to them:
   - Bake detail (called from hooks in the 98f / 98f2 bakes): beach umbrellas, buckets, coconuts, footprints, crab burrows, anemones,
     clams, an amphora and an anchor on the reef, sunlight and a soft vignette (coral); nets, lobster pots, rope coils, a beached
     cannon, bottles, sunken barrels, the galleon's reflection, light through the mist (wreck); tube worms, glowing sea stars, fish
     bones and a sunken treasure chest (abyss). Props keep out of the pads' tower boxes like the rest (rpw2aFree / rpw2aPadHit).
   - Life (RPW.amb / twist / ambTop wrapped per map): swaying palm crowns (98f leaves them out of the bake, B.palms), crabs that scuttle
     and dive into the sand when a monster or the pointer comes close, gulls on the sand that fly off, butterflies, leaping dolphins,
     splashes round monsters wading in the tide (coral); perched gulls the cannon scares off, lantern reflections, fireflies, spray on
     the sea stacks, a ship that shudders when its cannon fires (wreck); jellyfish, a glowing fish school, moving light shafts, glowcaps
     that flare when a tower near them fires, whirlpools that spin faster with more monsters in them, plankton that shies away from the
     pointer, the Kraken's eye easing after the pointer or the leading monster (abyss).
   - Clicks / taps (rpClick wrapped): only when nothing of the battle is under the pointer (no pad, tower, monster, nothing being placed
     or aimed) and always after the game's own handling, so building and selecting never change. Lighthouse flash, chests that pop
     open with sparkles, palms that shake, crabs that duck, gulls and fish that scatter, ripples on any water, the ship creaks, the skull
     rock's eyes glow, fog swirls, clams open, vents burst, the Kraken blinks and its tentacles recoil. Pure decoration: no gameplay.
   - The World 2 hub painting gets live tentacles, a sweeping lighthouse beam, a whale spout, leaping dolphins and drifting clouds.
   State lives on the battle (R.w2a, rpw2aSt) and runs on R.t, so it is smooth, eased and stops with the game when paused.
   Everything is sprites baked once plus short batched paths; R.lite and R.rm draw less (rm: no motion). */
/* ---------- helpers ---------- */
const rpw2aEo=u=>u<=0?0:u>=1?1:1-(1-u)*(1-u)*(1-u);/* ease out */
const rpw2aEio=u=>u<=0?0:u>=1?1:u<.5?4*u*u*u:1-Math.pow(-2*u+2,3)/2;/* ease in-out */
const RPW2A_O=[0,0];
function rpw2aSt(R){let s=R.w2a;if(!s){s=R.w2a={pk:{},ev:[],lt:R.t,dt:0,eye:null,mv:[-1,-1,-99],wh:[],whn:[],gl:[],gp:[],cf:0}}return s}
/* per frame: dt from R.t (clamped), the pointer's last move */
function rpw2aTick(R){const s=rpw2aSt(R);if(s.fr===R.t)return s;s.fr=R.t;s.dt=Math.max(0,Math.min(.1,R.t-s.lt));s.lt=R.t;
 const mx=R.mx,my=R.my;if(my>=0&&(mx!==s.mv[0]||my!==s.mv[1])){s.mv[0]=mx;s.mv[1]=my;s.mv[2]=R.t}if(my<0)s.mv[2]=-99;
 if(s.ev.length)s.ev=s.ev.filter(e=>R.t-e.t0<e.d&&R.t>=e.t0-.01);return s}
const rpw2aAgo=(R,k)=>{const s=R.w2a,p=s&&s.pk[k];return p?R.t-p.t:1e9};
function rpw2aPk(R,k,x,y){rpw2aSt(R).pk[k]={t:R.t,x,y}}
function rpw2aEv(R,k,x,y,d,o){const s=rpw2aSt(R);if(s.ev.length>48)s.ev.shift();const e=Object.assign({k,x,y,t0:R.t,d},o||{});s.ev.push(e);return e}
/* a scatter offset: things near a poke dart away from it and ease back (into RPW2A_O) */
function rpw2aOff(R,k,x,y,i,amp){const s=R.w2a,p=s&&s.pk[k];RPW2A_O[0]=RPW2A_O[1]=0;if(!p)return RPW2A_O;const u=R.t-p.t;if(u<0||u>3.2)return RPW2A_O;
 const e=u<.35?rpw2aEo(u/.35):1-rpw2aEio((u-.35)/2.85),dx=x-p.x,dy=y-p.y,d=Math.hypot(dx,dy)||1,j=(rpw2aR(i*7+3)-.5)*1.1,ca=Math.cos(j),sa=Math.sin(j),f=amp*e*(.7+.6*rpw2aR(i*5+1));
 RPW2A_O[0]=(dx/d*ca-dy/d*sa)*f;RPW2A_O[1]=(dx/d*sa+dy/d*ca)*f;return RPW2A_O}
/* a monster's feet near (x, y) within r */
function rpw2aFoeNear(R,x,y,r){if(!R.foes)return false;for(const e of R.foes){if(e.dead||e.air)continue;let q;try{q=rpPos(R,e)}catch(x){continue}if(Math.abs(q.x-x)<r&&Math.abs(q.y-y)<r*.8)return true}return false}
function rpw2aFoeAt(R,x,y){if(!R.foes)return false;for(const e of R.foes){if(e.dead)continue;let q;try{q=rpPos(R,e)}catch(z){continue}const h=e.boss?150:e.air?100:66,w=e.boss?90:34;if(Math.abs(q.x-x)<w&&y>q.y-h&&y<q.y+16)return true}return false}
function rpw2aBeep(f,d,ty,v){try{if(typeof beep==='function')beep(f,d,ty||'sine',v||.18)}catch(e){}}
/* clear of the battle HUD (title, chips and buttons on top; the ability buttons, tower bar and wave button below) */
const rpw2aHudFree=(x,y)=>!(y<100&&(x<250||x>1390||(x>470&&x<1130)))&&!(y>760&&x>285&&x<1195)&&!(y>780&&(x<310||x>1290));
/* ---------- shared sprites ---------- */
/* a crab, side on, legs in two frames; c = [shell, light, dark] */
function rpw2aCrabSpr(f,v){return rpw2aSpr('crab'+f+v,44,34,g=>{const C=[['#ff6a3a','#ffb48a','#b8361a'],['#6a8aa0','#a8c4d4','#3a5266']][v];g.translate(22,26);
 g.strokeStyle=RPO;g.lineWidth=2.2;g.beginPath();for(const s of[-1,1])for(let k=0;k<3;k++){const bx=s*(5+k*3.4),ox=(f?(k%2?2:-2):(k%2?-2:2))*s;g.moveTo(bx,-2);g.lineTo(bx+s*6+ox,-6);g.lineTo(bx+s*8+ox,3)}g.stroke();
 g.strokeStyle=C[2];g.lineWidth=1.2;g.stroke();
 for(const s of[-1,1]){g.beginPath();g.ellipse(s*15,-11,5.2,4,s*.5,0,TAU);g.fillStyle=C[0];g.fill();rpw2aOut(g,1.6);g.beginPath();g.moveTo(s*17,-14);g.lineTo(s*20,-17);g.stroke()}
 g.beginPath();g.ellipse(0,-6,11,7.4,0,Math.PI,0);g.quadraticCurveTo(10,1,0,1);g.quadraticCurveTo(-10,1,-11,-6);g.closePath();g.fillStyle=C[0];g.fill();rpw2aOut(g,1.8);
 g.fillStyle=C[1];g.beginPath();g.ellipse(-3,-9,5,2.2,-.2,0,TAU);g.fill();g.fillStyle=C[2];g.beginPath();g.ellipse(4,-2,6,1.6,0,0,TAU);g.fill();
 g.strokeStyle=RPO;g.lineWidth=1.4;g.beginPath();g.moveTo(-3,-12);g.lineTo(-4,-17);g.moveTo(3,-12);g.lineTo(4,-17);g.stroke();
 for(const s of[-1,1]){g.fillStyle='#fff';g.beginPath();g.arc(s*4,-18,2.4,0,TAU);g.fill();rpw2aOut(g,1);g.fillStyle=RPO;g.beginPath();g.arc(s*4+.5,-18,1.1,0,TAU);g.fill()}})}
/* a standing gull, side on (head down for f = 1) */
function rpw2aGullStand(f){return rpw2aSpr('gst'+f,40,36,g=>{g.translate(20,30);rpw2aBlob(g,0,1,10,2.6,'#000',.2);g.strokeStyle='#e8a030';g.lineWidth=1.6;g.beginPath();g.moveTo(-2,-4);g.lineTo(-3,0);g.moveTo(2,-4);g.lineTo(2,0);g.stroke();
 g.fillStyle='#ffffff';g.beginPath();g.moveTo(-13,-9);g.quadraticCurveTo(-6,-15,4,-13);g.quadraticCurveTo(10,-9,6,-4);g.quadraticCurveTo(-4,-2,-13,-9);g.closePath();g.fill();rpw2aOut(g,1.6);
 g.fillStyle='#8a94a4';g.beginPath();g.moveTo(-12,-9);g.quadraticCurveTo(-4,-14,4,-11);g.quadraticCurveTo(-2,-7,-12,-9);g.closePath();g.fill();g.fillStyle='#2a2a34';g.beginPath();g.moveTo(-13,-9);g.lineTo(-17,-10);g.lineTo(-12,-7.5);g.closePath();g.fill();
 const hx=f?8:6,hy=f?-9:-16;g.fillStyle='#ffffff';g.beginPath();g.arc(hx,hy,4.2,0,TAU);g.fill();rpw2aOut(g,1.4);g.fillStyle='#ffb43a';g.beginPath();g.moveTo(hx+3.5,hy);g.lineTo(hx+9,hy+1.2);g.lineTo(hx+3.5,hy+2.2);g.closePath();g.fill();
 g.fillStyle=RPO;g.beginPath();g.arc(hx+1.2,hy-1,1,0,TAU);g.fill()})}
/* a dolphin, side on, pointing right */
function rpw2aDolphinSpr(){return rpw2aSpr('dolph',76,40,g=>{g.translate(38,22);g.beginPath();g.moveTo(-30,-2);g.quadraticCurveTo(-14,-14,10,-11);g.quadraticCurveTo(26,-9,32,-1);g.lineTo(37,0);g.lineTo(31,3);g.quadraticCurveTo(14,8,-14,5);g.lineTo(-28,6);g.lineTo(-36,11);g.lineTo(-33,1);g.lineTo(-37,-8);g.closePath();
 const q=g.createLinearGradient(0,-14,0,8);q.addColorStop(0,'#5a7ab8');q.addColorStop(.6,'#8aa8d8');q.addColorStop(1,'#e8f0ff');g.fillStyle=q;g.fill();rpw2aOut(g,2);
 g.fillStyle='#4a6aa8';g.beginPath();g.moveTo(-4,-11);g.lineTo(-10,-21);g.lineTo(4,-12);g.closePath();g.fill();rpw2aOut(g,1.6);g.beginPath();g.moveTo(4,4);g.lineTo(-2,11);g.lineTo(10,5);g.closePath();g.fill();rpw2aOut(g,1.4);
 g.fillStyle=RPO;g.beginPath();g.arc(20,-5,1.6,0,TAU);g.fill();g.strokeStyle='rgba(18,8,31,.5)';g.lineWidth=1.2;g.beginPath();g.moveTo(26,1);g.quadraticCurveTo(30,2,33,0);g.stroke();
 g.fillStyle='rgba(255,255,255,.55)';g.beginPath();g.ellipse(4,-9,10,2,-.1,0,TAU);g.fill()})}
/* a glowing jellyfish bell (k colour), two pulse frames */
function rpw2aJellySpr(k,f){return rpw2aSpr('jl'+k+f,60,52,g=>{const C=RPW2A_GLOW[k%5];g.translate(30,30);g.globalCompositeOperation='lighter';g.globalAlpha=.55;g.drawImage(rpw2aGl(C[1],26),-28,-30,56,52);g.globalAlpha=1;g.globalCompositeOperation='source-over';
 const w=f?15:13,h=f?12:15;g.beginPath();g.moveTo(-w,0);g.quadraticCurveTo(-w,-h*1.2,0,-h*1.15);g.quadraticCurveTo(w,-h*1.2,w,0);for(let j=4;j>=0;j--){const x=-w+j*w/2.5;g.quadraticCurveTo(x+w/5,3,x,0)}g.closePath();
 const q=g.createRadialGradient(-3,-h*.6,1,0,-h*.3,w*1.2);q.addColorStop(0,'rgba(255,255,255,.95)');q.addColorStop(.5,C[0]);q.addColorStop(1,'rgba(40,60,160,.8)');g.fillStyle=q;g.fill();g.lineWidth=1.8;g.strokeStyle=RPO;g.stroke();
 g.fillStyle='rgba(255,255,255,.75)';g.beginPath();g.ellipse(-w*.4,-h*.7,w*.25,h*.18,-.5,0,TAU);g.fill()})}
/* a coin sparkle star */
function rpw2aStar4(c,x,y,s){c.moveTo(x,y-s*1.6);c.lineTo(x+s*.3,y-s*.3);c.lineTo(x+s*1.6,y);c.lineTo(x+s*.3,y+s*.3);c.lineTo(x,y+s*1.6);c.lineTo(x-s*.3,y+s*.3);c.lineTo(x-s*1.6,y);c.lineTo(x-s*.3,y-s*.3);c.closePath()}
/* ---------- bake extras: Coral Shallows ---------- */
function rpw2aUmbrella(g,x,y,i){g.save();g.translate(x,y);const C=[['#ff5a6a','#fff6e8'],['#2ac0d8','#fff6e8'],['#ffc84a','#ff6a8a']][i%3];
 g.fillStyle='rgba(0,0,0,.18)';g.beginPath();g.ellipse(14,4,36,12,0,0,TAU);g.fill();
 /* a towel */g.save();g.rotate(-.12);g.fillStyle=C[1];g.fillRect(-30,-4,30,14);g.fillStyle=C[0];for(let k=0;k<3;k++)g.fillRect(-30,-4+k*5,30,2.4);g.strokeStyle=RPO;g.lineWidth=1.6;g.strokeRect(-30,-4,30,14);g.restore();
 g.strokeStyle=RPO;g.lineWidth=4;g.beginPath();g.moveTo(4,4);g.lineTo(10,-50);g.stroke();g.strokeStyle='#e8e0d0';g.lineWidth=2;g.stroke();
 const cx=10,cy=-50,r=32;for(let k=0;k<8;k++){const a0=Math.PI+k/8*Math.PI,a1=Math.PI+(k+1)/8*Math.PI;g.beginPath();g.moveTo(cx,cy-4);g.lineTo(cx+Math.cos(a0)*r,cy+Math.sin(a0)*r*.45+6);g.quadraticCurveTo(cx+Math.cos((a0+a1)/2)*r*.92,cy+Math.sin((a0+a1)/2)*r*.42+9,cx+Math.cos(a1)*r,cy+Math.sin(a1)*r*.45+6);g.closePath();g.fillStyle=C[k%2];g.fill();g.strokeStyle='rgba(18,8,31,.5)';g.lineWidth=1;g.stroke()}
 g.beginPath();g.moveTo(cx-r,cy+6);g.quadraticCurveTo(cx,cy-r*.62,cx+r,cy+6);g.strokeStyle=RPO;g.lineWidth=2.2;g.stroke();g.fillStyle='rgba(255,255,255,.35)';g.beginPath();g.ellipse(cx-10,cy-6,9,3,-.3,0,TAU);g.fill();
 g.fillStyle=C[0];g.beginPath();g.arc(cx,cy-5,2.6,0,TAU);g.fill();rpw2aOut(g,1.2);g.restore()}
function rpw2aBucket(g,x,y,i){g.save();g.translate(x,y);rpw2aBlob(g,2,1,11,3.4,'#000',.2);const col=['#2ab0e8','#ff6a4a','#ffd23a'][i%3];g.beginPath();g.moveTo(-7,-12);g.lineTo(7,-12);g.lineTo(5.4,0);g.lineTo(-5.4,0);g.closePath();g.fillStyle=col;g.fill();rpw2aOut(g,1.6);
 g.fillStyle='rgba(255,255,255,.35)';g.fillRect(-5,-11,2.4,10);g.beginPath();g.ellipse(0,-12,7,2.4,0,0,TAU);g.fillStyle='#f0d49a';g.fill();rpw2aOut(g,1.3);g.strokeStyle=RPO;g.lineWidth=1.2;g.beginPath();g.arc(0,-12,7.5,Math.PI*1.05,Math.PI*1.95);g.stroke();
 /* the spade */g.rotate(.5);g.fillStyle='#ffd23a';g.fillRect(9,-16,2.4,14);g.strokeStyle=RPO;g.lineWidth=1.1;g.strokeRect(9,-16,2.4,14);g.beginPath();g.moveTo(7,-2);g.lineTo(13.5,-2);g.lineTo(12,5);g.lineTo(8.5,5);g.closePath();g.fillStyle='#ff6a4a';g.fill();g.stroke();g.restore()}
function rpw2aCoconuts(g,x,y,i){for(let k=0;k<2+i%2;k++){const cx=x+k*7-4,cy=y+(k%2)*3;rpw2aBlob(g,cx+1,cy+3,5,1.6,'#000',.2);g.fillStyle='#6a4022';g.beginPath();g.arc(cx,cy,4.6,0,TAU);g.fill();rpw2aOut(g,1.4);g.fillStyle='rgba(255,220,160,.45)';g.beginPath();g.arc(cx-1.4,cy-1.6,1.4,0,TAU);g.fill()}}
function rpw2aBeachClam(g,x,y,i){rpw2aShell(g,x,y,10,(i%7)*.3,i);rpw2aShell(g,x+9,y+3,7,(i%5)*.4,i+1)}
/* footprints and crab burrows, then the extra props (they join the props list so they draw in depth order) */
function rpw2aCoralExtra(g,B,G,F,N,DR,items,free,taken){const beach=(x,y)=>{const f=F.at(x,y);return f<-10&&f>-90&&f+(N.at(x,y)-.5)*80+92>4};
 /* two trails of footprints wandering down the beach */
 for(let s=0;s<2;s++){let x=s?960:240,y=s?760:770,a=s?-.4:-.9;g.fillStyle='rgba(170,130,70,.32)';for(let k=0;k<26;k++){a+=(rpw2aR(k*3+s*40)-.5)*.35;x+=Math.cos(a)*12;y+=Math.sin(a)*12*.7;if(!beach(x,y)||DR.at(x,y)<40)continue;const sd=k%2?1:-1,px=x-Math.sin(a)*4*sd,py=y+Math.cos(a)*4*sd;
  g.save();g.translate(px,py);g.rotate(a);g.beginPath();g.ellipse(0,0,3.6,2,0,0,TAU);g.fill();g.beginPath();g.ellipse(4.4,0,1.6,1.6,0,0,TAU);g.fill();g.restore()}}
 /* crab burrows where the live crabs live (B.crab: [x, y, heading, i]) */
 B.crab=[];for(let i=0;i<900&&B.crab.length<6;i++){const x=rpw2aR(i*3+2100)*1560+20,y=rpw2aR(i*3+2101)*860+20;if(!beach(x,y)||!rpw2aHudFree(x,y)||!free(x,y,{road:84,pad:96,w:60,h:30})||B.crab.some(c=>Math.hypot(c[0]-x,c[1]-y)<170))continue;
  B.crab.push([x,y,(rpw2aR(i)-.5)*.6,B.crab.length]);for(const d of[-1,1]){g.fillStyle='rgba(120,84,40,.55)';g.beginPath();g.ellipse(x+d*30,y+4,4,2.2,0,0,TAU);g.fill();g.strokeStyle='rgba(255,240,200,.6)';g.lineWidth=1;g.beginPath();g.ellipse(x+d*30,y+3,5,2.8,0,Math.PI*1.1,Math.PI*1.9);g.stroke()}}
 /* standing gulls on the sand (B.gstand) */
 B.gstand=[];for(let i=0;i<900&&B.gstand.length<3;i++){const x=rpw2aR(i*3+3100)*1500+50,y=rpw2aR(i*3+3101)*820+40;if(!beach(x,y)||!rpw2aHudFree(x,y)||!free(x,y,{road:80,pad:90,w:40,h:30})||B.gstand.some(c=>Math.hypot(c[0]-x,c[1]-y)<220)||B.crab.some(c=>Math.hypot(c[0]-x,c[1]-y)<80))continue;B.gstand.push([x,y,B.gstand.length])}
 /* umbrellas, buckets by the sandcastles, coconuts under palms, shells */
 const add=(k,x,y,i,r,o)=>{if(!free(x,y,Object.assign({road:70},o||{})))return false;items.push({k,x,y,i});taken.push([x,y,r]);return true};
 let nu=0;for(let i=0;i<600&&nu<2;i++){const x=rpw2aR(i*5+4100)*1500+50,y=rpw2aR(i*5+4101)*800+60;if(!beach(x,y))continue;if(add('umb',x,y,i,70,{road:80,w:76,h:70}))nu++}
 for(const it of items.slice())if(it.k==='castle'){for(const [dx,dy] of[[30,6],[-30,8],[24,-10]])if(add('bucket',it.x+dx,it.y+dy,it.i+dx,14,{road:56,w:20,h:18}))break}
 let nc=0;for(const it of items.slice()){if(it.k!=='palm'||nc>14||rpw2aR(it.i+77)<.5)continue;const dx=it.h*.3+8;if(add('coco',it.x+dx,it.y+6,it.i,10,{road:56,w:20,h:12}))nc++}
 let ns=0;for(let i=0;i<600&&ns<12;i++){const x=rpw2aR(i*5+5100)*1560+20,y=rpw2aR(i*5+5101)*860+20;if(!beach(x,y))continue;if(add('clamb',x,y,i,16,{road:54,w:22,h:12}))ns++}}
/* under the water: anemones, giant clams, an amphora and an anchor, sand ripples, rays of light */
function rpw2aCoralReef(h,F,G){const deep=(x,y,a,b)=>{const f=F.at(x,y);return f>a&&f<b};
 h.strokeStyle='rgba(120,160,150,.35)';h.lineWidth=1.6;for(let i=0;i<70;i++){const x=rpw2aR(i*3+6000)*1600,y=rpw2aR(i*3+6001)*900;if(!deep(x,y,30,200))continue;h.beginPath();for(let k=0;k<3;k++){h.moveTo(x-16,y+k*6);h.quadraticCurveTo(x,y+k*6-4,x+16,y+k*6)}h.stroke()}
 for(let i=0;i<40;i++){const x=rpw2aR(i*3+6200)*1600,y=rpw2aR(i*3+6201)*900;if(!deep(x,y,20,140))continue;const C=RPW2A_CORAL[i%6];h.save();h.translate(x,y);
  for(let j=0;j<9;j++){const a=-Math.PI+.2+j/8*(Math.PI-.4),l=8+rpw2aR(i+j)*5;h.strokeStyle=RPO;h.lineWidth=4.2;h.beginPath();h.moveTo(0,-2);h.quadraticCurveTo(Math.cos(a)*l*.5,Math.sin(a)*l*.6-2,Math.cos(a)*l,Math.sin(a)*l-2);h.stroke();h.strokeStyle=C[0];h.lineWidth=2.4;h.stroke();h.fillStyle=C[1];h.beginPath();h.arc(Math.cos(a)*l,Math.sin(a)*l-2,1.6,0,TAU);h.fill()}h.restore()}
 for(let i=0;i<10;i++){const x=rpw2aR(i*3+6400)*1600,y=rpw2aR(i*3+6401)*900;if(!deep(x,y,40,160))continue;rpw2aClam(h,x,y,20,null)}
 {let k=0;for(let i=0;i<300&&k<2;i++){const x=rpw2aR(i*3+6600)*1600,y=rpw2aR(i*3+6601)*900;if(!deep(x,y,60,220))continue;
  if(k===0){h.save();h.translate(x,y);h.rotate(1.2);h.fillStyle='#c8784a';h.beginPath();h.moveTo(-6,-16);h.quadraticCurveTo(-14,-4,-8,10);h.lineTo(8,10);h.quadraticCurveTo(14,-4,6,-16);h.closePath();h.fill();rpw2aOut(h,2);
   h.fillStyle='#a85a32';h.fillRect(-5,-21,10,6);h.strokeRect(-5,-21,10,6);h.strokeStyle='#e8b080';h.lineWidth=1.4;h.beginPath();h.moveTo(-10,-2);h.lineTo(10,-2);h.stroke();h.restore()}else rpw2aAnchor(h,x,y,18,-.7);k++}}
 /* soft rays of light through the shallows */
 h.save();h.globalCompositeOperation='lighter';for(let i=0;i<9;i++){const x=rpw2aR(i*3+6800)*1600,y=rpw2aR(i*3+6801)*900;if(!deep(x,y,40,400))continue;h.globalAlpha=.07;h.save();h.translate(x,y);h.rotate(-.5);h.drawImage(rpw2aRaySpr(),-30,-90,60,200);h.restore()}h.restore()}
/* sunlight from the top left, a little shade in the far corners */
function rpw2aCoralLight(g,B,F){g.save();g.globalCompositeOperation='lighter';let q=g.createRadialGradient(240,40,30,240,40,900);q.addColorStop(0,'rgba(255,236,170,.16)');q.addColorStop(.5,'rgba(255,236,170,.05)');q.addColorStop(1,'rgba(255,236,170,0)');g.fillStyle=q;g.fillRect(0,0,1600,900);
 g.globalCompositeOperation='source-over';q=g.createRadialGradient(800,430,520,800,450,1050);q.addColorStop(0,'rgba(10,40,60,0)');q.addColorStop(1,'rgba(10,40,60,.22)');g.fillStyle=q;g.fillRect(0,0,1600,900);g.restore()}
/* ---------- bake extras: Shipwreck Cove ---------- */
function rpw2aNet(g,x,y,i){g.save();g.translate(x,y);rpw2aBlob(g,0,2,34,6,'#000',.25);for(const dx of[-26,26]){g.fillStyle='#5a3a22';g.fillRect(dx-3,-46,6,46);g.strokeStyle=RPO;g.lineWidth=1.8;g.strokeRect(dx-3,-46,6,46)}
 const sag=(u)=>-40+Math.sin(u*Math.PI)*14;g.beginPath();g.moveTo(-24,-40);for(let k=0;k<=10;k++){const u=k/10;g.lineTo(-24+u*48,sag(u))}for(let k=10;k>=0;k--){const u=k/10;g.lineTo(-24+u*48,sag(u)+22+Math.sin(u*Math.PI)*6)}g.closePath();g.fillStyle='rgba(60,50,40,.35)';g.fill();
 g.save();g.clip();g.strokeStyle='rgba(220,200,160,.75)';g.lineWidth=1;g.beginPath();for(let k=-6;k<10;k++){g.moveTo(-24+k*6,-44);g.lineTo(-24+k*6+30,-4);g.moveTo(-24+k*6+30,-44);g.lineTo(-24+k*6,-4)}g.stroke();g.restore();
 g.strokeStyle='#c8b08a';g.lineWidth=1.6;g.beginPath();g.moveTo(-24,-40);for(let k=0;k<=10;k++){const u=k/10;g.lineTo(-24+u*48,sag(u))}g.stroke();
 for(const [fx,c] of[[-12,'#ff6a3a'],[2,'#f0e0c0'],[14,'#ff6a3a']]){const fy=sag((fx+24)/48)+2;g.fillStyle=c;g.beginPath();g.arc(fx,fy,3.2,0,TAU);g.fill();rpw2aOut(g,1.2)}g.restore()}
function rpw2aPots(g,x,y,i){const pot=(px,py,s)=>{g.save();g.translate(px,py);rpw2aBlob(g,0,1,s*.6,s*.16,'#000',.25);g.beginPath();g.moveTo(-s*.5,0);g.lineTo(-s*.5,-s*.35);g.quadraticCurveTo(-s*.5,-s*.8,0,-s*.8);g.quadraticCurveTo(s*.5,-s*.8,s*.5,-s*.35);g.lineTo(s*.5,0);g.closePath();
  g.fillStyle='rgba(90,60,30,.45)';g.fill();g.strokeStyle='#8a6440';g.lineWidth=1.4;g.save();g.clip();g.beginPath();for(let k=-3;k<=3;k++){g.moveTo(k*s*.15,0);g.lineTo(k*s*.15,-s)}for(const v of[.2,.45,.65]){g.moveTo(-s*.6,-s*v);g.lineTo(s*.6,-s*v)}g.stroke();g.restore();
  g.beginPath();g.moveTo(-s*.5,0);g.lineTo(-s*.5,-s*.35);g.quadraticCurveTo(-s*.5,-s*.8,0,-s*.8);g.quadraticCurveTo(s*.5,-s*.8,s*.5,-s*.35);g.lineTo(s*.5,0);g.closePath();rpw2aOut(g,1.8);g.fillStyle='#6a4426';g.fillRect(-s*.55,-2,s*1.1,3);g.restore()};
 pot(x-14,y-4,26);pot(x+12,y,24);pot(x-2,y-22,20);g.fillStyle='#ff6a3a';g.beginPath();g.arc(x+26,y-2,3.6,0,TAU);g.fill();rpw2aOut(g,1.2)}
function rpw2aRope(g,x,y,i){g.save();g.translate(x,y);rpw2aBlob(g,0,2,16,5,'#000',.25);for(let k=0;k<4;k++){g.beginPath();g.ellipse(0,-k*2.6,14-k*2.4,5.4-k*.8,0,0,TAU);g.strokeStyle=RPO;g.lineWidth=4.6;g.stroke();g.strokeStyle=k%2?'#c8a878':'#b89868';g.lineWidth=2.8;g.stroke()}
 g.strokeStyle=RPO;g.lineWidth=4.6;g.beginPath();g.moveTo(12,-2);g.quadraticCurveTo(22,2,26,-4);g.stroke();g.strokeStyle='#c8a878';g.lineWidth=2.8;g.stroke();g.restore()}
function rpw2aBeachGun(g,x,y,i){g.save();g.translate(x,y);g.rotate(-.18);rpw2aBlob(g,0,3,34,7,'#000',.28);g.beginPath();g.moveTo(-28,-9);g.lineTo(22,-6);g.lineTo(26,-7);g.lineTo(26,6);g.lineTo(22,5);g.lineTo(-28,8);g.quadraticCurveTo(-36,0,-28,-9);g.closePath();
 const q=g.createLinearGradient(0,-9,0,8);q.addColorStop(0,'#5a6268');q.addColorStop(.4,'#3a4046');q.addColorStop(1,'#22262a');g.fillStyle=q;g.fill();rpw2aOut(g,2);g.fillStyle='#000';g.beginPath();g.ellipse(26,0,2,5,0,0,TAU);g.fill();
 g.fillStyle='rgba(160,90,40,.55)';for(let k=0;k<7;k++){g.beginPath();g.arc(-20+k*6,-2+rpw2aR(k+i)*5,1.5+rpw2aR(k)*1.5,0,TAU);g.fill()}
 g.fillStyle='#8a7a5e';g.beginPath();g.moveTo(-34,8);g.quadraticCurveTo(-4,0,30,9);g.lineTo(30,12);g.lineTo(-34,12);g.closePath();g.fill();g.restore()}
function rpw2aBottle(g,x,y,i){g.save();g.translate(x,y);g.rotate(1.2+rpw2aR(i)*.6);rpw2aBlob(g,0,3,9,2.4,'#000',.2);g.fillStyle=i%2?'rgba(90,170,110,.85)':'rgba(140,110,60,.85)';g.beginPath();g.roundRect(-4,-14,8,14,3);g.fill();rpw2aOut(g,1.3);g.fillRect(-1.8,-19,3.6,5);g.strokeRect(-1.8,-19,3.6,5);
 if(i%3===0){g.fillStyle='#f0e0b8';g.fillRect(-2.4,-11,4.8,8)}g.fillStyle='rgba(255,255,255,.55)';g.fillRect(-2.6,-12,1.4,10);g.restore()}
function rpw2aWreckExtra(g,B,G,F,DR,items,free,taken,shipIn){const add=(k,x,y,i,r,o)=>{if(!free(x,y,Object.assign({road:70},o||{})))return false;items.push({k,x,y,i});taken.push([x,y,r]);return true};
 const shore=(x,y)=>{const f=F.at(x,y);return f<-10&&f>-60};let n={net:0,pots:0,rope:0,gun:0,bottle:0};
 for(let i=0;i<1600;i++){const x=rpw2aR(i*5+7100)*1540+30,y=rpw2aR(i*5+7101)*820+40;if(!shore(x,y))continue;const r=rpw2aR(i*5+7102);
  if(n.net<2&&r<.2){if(add('net',x,y,i,60,{road:80,w:64,h:56}))n.net++}else if(n.pots<3&&r<.4){if(add('pots',x,y,i,40,{road:72,w:52,h:34}))n.pots++}else if(n.rope<4&&r<.6){if(add('rope',x,y,i,26,{road:60,w:32,h:16}))n.rope++}
  else if(n.gun<2&&r<.7){if(add('gun',x,y,i,40,{road:72,w:70,h:24}))n.gun++}else if(n.bottle<6){if(add('bottle',x,y,i,14,{road:50,w:16,h:14}))n.bottle++}}
 /* crabs on the dark sand (B.crab) */
 B.crab=[];for(let i=0;i<900&&B.crab.length<3;i++){const x=rpw2aR(i*3+7900)*1500+50,y=rpw2aR(i*3+7901)*820+40;if(!shore(x,y)||!rpw2aHudFree(x,y)||!free(x,y,{road:84,pad:96,w:60,h:30})||B.crab.some(c=>Math.hypot(c[0]-x,c[1]-y)<240))continue;B.crab.push([x,y,(rpw2aR(i)-.5)*.6,B.crab.length])}}
/* under the cove's water: sunken barrels, a cannon and shot, a chest of coins glinting */
function rpw2aWreckReef(h,F,shipIn){const ok=(x,y,a)=>F.at(x,y)>a&&!shipIn(x,y,20);let k=0;
 for(let i=0;i<400&&k<9;i++){const x=rpw2aR(i*3+8100)*1600,y=rpw2aR(i*3+8101)*900;if(!ok(x,y,30))continue;k++;if(k%3===0)rpw2aBalls(h,x,y,4);else rpw2aBarrel(h,x,y,18,i,k%2?.4:0)}
 for(let i=0;i<200;i++){const x=rpw2aR(i*3+8300)*1600,y=rpw2aR(i*3+8301)*900;if(!ok(x,y,50))continue;rpw2aChest(h,x,y,22);h.fillStyle='#ffd45a';for(let j=0;j<6;j++){h.beginPath();h.ellipse(x-14+j*6,y+3+(j%2)*2,3,1.6,0,0,TAU);h.fill()}break}
 for(let i=0;i<200;i++){const x=rpw2aR(i*3+8500)*1600,y=rpw2aR(i*3+8501)*900;if(!ok(x,y,40))continue;rpw2aBeachGun(h,x,y,i);break}}
/* the galleon's reflection: a dim, squashed, rippled mirror image below its waterline */
function rpw2aWreckRefl(g,sh){const k=sh[2]/330,kh=sh[3]/170,wl=sh[1]+24*kh,c=rpw2aCv(1600,900),h=c.getContext('2d');h.lineJoin='round';h.lineCap='round';
 rpw2aShip(h,sh[0],sh[1],sh[2],sh[3],{lant:[]});h.drawImage(rpw2aMastSpr(0),sh[0]-50*k-70,sh[1]-36*kh-196);h.save();h.translate(sh[0]+96*k,sh[1]-70*kh);h.rotate(0);h.drawImage(rpw2aMastSpr(1),-40,-146);h.restore();
 h.globalCompositeOperation='source-atop';h.fillStyle='rgba(16,42,52,.62)';h.fillRect(0,0,1600,900);h.globalCompositeOperation='destination-out';h.fillRect(0,wl,1600,900-wl);
 g.save();g.globalAlpha=.42;for(let y=0;y<180;y+=3){const sy=wl-y/.62,dx=Math.sin(y*.21)*2.6+Math.sin(y*.07)*1.5;if(sy<0)break;g.drawImage(c,0,sy-3/.62,1600,3/.62,dx,wl+y,1600,3)}g.restore()}
function rpw2aWreckLight(g,B,F){g.save();g.globalCompositeOperation='lighter';for(let i=0;i<5;i++){g.globalAlpha=.045;g.save();g.translate(160+i*330,-30);g.rotate(-.42+i*.03);g.drawImage(rpw2aRaySpr(),-50,0,110+(i%2)*60,820);g.restore()}
 g.globalCompositeOperation='source-over';g.globalAlpha=1;const q=g.createRadialGradient(800,450,480,800,450,1000);q.addColorStop(0,'rgba(8,16,22,0)');q.addColorStop(1,'rgba(8,16,22,.3)');g.fillStyle=q;g.fillRect(0,0,1600,900);g.restore()}
/* ---------- bake extras: Kraken's Maw ---------- */
function rpw2aTubeWorms(g,x,y,i,L){g.save();g.translate(x,y);rpw2aBlob(g,0,2,16,4,'#000',.35);for(let j=0;j<5;j++){const tx=(j-2)*6+(rpw2aR(i+j)-.5)*3,th=14+rpw2aR(i*3+j)*18,tw=2.6;g.fillStyle='#e8e4f0';g.beginPath();g.roundRect(tx-tw,-th,tw*2,th,[2,2,0,0]);g.fill();rpw2aOut(g,1.3);
  g.strokeStyle='rgba(18,8,31,.35)';g.lineWidth=.8;g.beginPath();for(let v=4;v<th;v+=4){g.moveTo(tx-tw,-v);g.lineTo(tx+tw,-v)}g.stroke();
  const col=j%2?'#ff4a6a':'#ff8a3a';g.fillStyle=col;for(let k=0;k<5;k++){const a=-Math.PI/2+(k-2)*.45;g.beginPath();g.ellipse(tx+Math.cos(a)*5,-th+Math.sin(a)*5,3.6,1.4,a,0,TAU);g.fill()}g.strokeStyle=RPO;g.lineWidth=1;g.beginPath();g.arc(tx,-th-1,4,Math.PI*1.1,Math.PI*1.9);g.stroke();if(L&&j===2)L.push([x+tx,y-th,10,'255,110,120'])}g.restore()}
function rpw2aGlowStar(g,x,y,i,L){const C=RPW2A_GLOW[(i+1)%5];g.save();g.globalCompositeOperation='lighter';g.globalAlpha=.5;g.drawImage(rpw2aGl(C[1],18),x-18,y-14,36,28);g.restore();rpw2aStar(g,x,y,9+rpw2aR(i)*3,rpw2aR(i+2)*6,C[0]);if(L)L.push([x,y,10,C[1]])}
function rpw2aFishBones(g,x,y,i){g.save();g.translate(x,y);g.rotate((rpw2aR(i)-.5)*.6);rpw2aBlob(g,0,3,26,4,'#000',.3);const P=()=>{g.beginPath();g.moveTo(-22,0);g.lineTo(16,0);for(let k=0;k<6;k++){const bx=-16+k*5.6;g.moveTo(bx,-9+Math.abs(k-2.5));g.quadraticCurveTo(bx+2,0,bx,9-Math.abs(k-2.5))}g.moveTo(-22,0);g.lineTo(-29,-7);g.moveTo(-22,0);g.lineTo(-29,7)};
 g.strokeStyle=RPO;g.lineWidth=4;P();g.stroke();g.strokeStyle='#c8d4e8';g.lineWidth=2;P();g.stroke();g.beginPath();g.ellipse(21,0,7,5.4,0,0,TAU);g.fillStyle='#c8d4e8';g.fill();rpw2aOut(g,1.8);g.fillStyle=RPO;g.beginPath();g.arc(23,-1.4,1.8,0,TAU);g.fill();g.restore()}
function rpw2aSunkChest(g,x,y,i){rpw2aChest(g,x,y,30);g.save();g.globalCompositeOperation='lighter';g.globalAlpha=.4;g.drawImage(rpw2aGl('255,210,110',26),x-26,y-36,52,40);g.restore();
 g.fillStyle='#2a8a7a';g.beginPath();g.ellipse(x-10,y-18,6,2,-.4,0,TAU);g.fill();g.fillStyle='#ffd45a';for(let j=0;j<5;j++){g.beginPath();g.ellipse(x-18+j*8,y+4+(j%2)*2,3,1.6,0,0,TAU);g.fill()}}
function rpw2aAbyssExtra(g,B,G,DR,items,free,taken,inPit){const add=(k,x,y,i,r,o)=>{if(!free(x,y,Object.assign({road:66},o||{})))return false;items.push({k,x,y,i});taken.push([x,y,r]);return true};
 let n={worms:0,gstar:0,skel:0,chestA:0};
 for(const [x0,y0] of[[1420,150],[470,840],[1330,700]]){if(n.chestA)break;for(let k=0;k<120;k++){const a=k*2.4,d=k*4,x=x0+Math.cos(a)*d,y=y0+Math.sin(a)*d*.7;if(x<40||x>1560||y<50||y>870)continue;if(add('chestA',x,y,0,50,{road:74,w:46,h:36})){n.chestA=1;break}}}
 for(let i=0;i<2400;i++){const x=rpw2aR(i*5+9100)*1560+20,y=rpw2aR(i*5+9101)*860+20,r=rpw2aR(i*5+9102);
  if(n.worms<8&&r<.4){if(add('worms',x,y,i,30,{w:34,h:36}))n.worms++}else if(n.gstar<10&&r<.8){if(add('gstar',x,y,i,20,{road:56,w:24,h:16}))n.gstar++}else if(n.skel<3){if(add('skel',x,y,i,40,{road:64,w:64,h:22}))n.skel++}}}
function rpw2aAbyssLight(g,B){g.save();g.globalCompositeOperation='lighter';const q=g.createLinearGradient(0,0,0,360);q.addColorStop(0,'rgba(60,150,200,.12)');q.addColorStop(1,'rgba(60,150,200,0)');g.fillStyle=q;g.fillRect(0,0,1600,360);g.restore()}
/* ---------- live pieces shared by the maps ---------- */
/* palm crowns, cut from the palm painter once per palm (the crown's centre is the sprite's centre at 46% height) */
function rpw2aCrown(p){return rpw2aSpr('pcr'+p.i+'_'+(p.h|0),Math.ceil(p.h*1.6),Math.ceil(p.h*1.5),(g,w,h)=>{rpw2aPalm(g,w/2-(p.cx-p.x),h*.46-(p.cy-p.y),p.h,p.i,{part:'crown'})})}
function rpw2aCrowns(c,R,L){const t=R.t,rm=R.rm;for(const p of L){const S=rpw2aCrown(p);let a=rm?0:.034*Math.sin(t*1.05-p.x*.004+p.i*.37)+.011*Math.sin(t*2.6+p.i);
  const u=rpw2aAgo(R,'palm'+p.i);if(u<2.4&&!rm)a+=.15*Math.sin(u*14)*Math.exp(-u*2.4);
  if(a===0)c.drawImage(S,p.cx-S.width/2,p.cy-S.height*.46);else{c.save();c.translate(p.cx,p.cy);c.rotate(a);c.drawImage(S,-S.width/2,-S.height*.46);c.restore()}}}
/* crabs: scuttle sideways round their burrow; they dive into the sand when a monster, the pointer or a click comes near */
function rpw2aCrabs(c,R,L,v){const s=rpw2aTick(R),t=R.t,dt=s.dt;if(!s.cr)s.cr=L.map(()=>({h:0,ct:0}));
 const pm=R.t-s.mv[2]<2.5;for(let i=0;i<L.length;i++){const [x0,y0,hd]=L[i],C=s.cr[i];if(!C)continue;
  const near=rpw2aFoeNear(R,x0,y0,110)||rpw2aAgo(R,'crab'+i)<3.2||(pm&&Math.abs(R.mx-x0)<70&&Math.abs(R.my-y0)<50);
  C.h=near?Math.min(1,C.h+dt*7):Math.max(0,C.h-dt*.9);if(!R.rm)C.ct+=dt*(1-C.h);
  const ph=C.ct*.55+i*2.1,w=Math.sin(ph),sp=Math.abs(Math.cos(ph)),x=x0+Math.cos(hd)*28*w,y=y0+Math.sin(hd)*16*w,hh=rpw2aEio(C.h);
  const S=rpw2aCrabSpr(sp>.35&&!R.rm?((C.ct*9)|0)%2:0,v);
  if(hh<.98){c.save();if(hh>0){c.beginPath();c.rect(x-24,y-40,48,40.5);c.clip()}c.drawImage(S,x-22,y-26+hh*22);c.restore()}
  if(hh>.02){c.fillStyle=v?'#6a6450':'#e8c88a';c.beginPath();c.ellipse(x,y,12*hh,4.4*hh,0,Math.PI,0);c.fill();c.strokeStyle='rgba(18,8,31,.55)';c.lineWidth=1.2;c.stroke();
   /* eyes peeking out while hidden */if(hh>.9&&(C.ct+t*.5+i)%3<1.6){for(const sd of[-1,1]){c.fillStyle='#fff';c.beginPath();c.arc(x+sd*3.4,y-6,2,0,TAU);c.fill();c.fillStyle=RPO;c.beginPath();c.arc(x+sd*3.4+.4,y-6,.9,0,TAU);c.fill()}}}}}
/* gulls on the ground: they take off when a monster, a click or the cannon comes, circle and land again (top: the flying ones) */
function rpw2aGsPos(x0,y0,i,u){const e=u<3?rpw2aEio(u/3):u<6.5?1:1-rpw2aEio((u-6.5)/3),dir=i%2?1:-1,ga=u*1.3+i;return[x0+dir*200*e+Math.cos(ga)*46*e-46*e,y0-40*e+Math.sin(ga)*24*e,e]}
function rpw2aGullsStand(c,R,L,top){const s=rpw2aTick(R),t=R.t;if(!s.gs)s.gs=L.map(()=>({f:-99}));const scare=R.cannon&&R.cannon.fire>0&&R.cannon.fire<.25;
 for(let i=0;i<L.length;i++){const x0=L[i][0],y0=L[i][1],G=s.gs[i];let u=t-G.f;
  const pk=s.pk['gst'+i];if(!top&&pk&&pk.t>G.f+9.5&&t-pk.t<9.5){G.f=pk.t;u=t-G.f}else if(!top&&u>9.5&&(scare||rpw2aFoeNear(R,x0,y0,90))){G.f=t;u=0}
  if(u>=9.5){if(!top){const bob=R.rm?0:((t*.7+i*1.3)%4<.5?1:0);c.drawImage(rpw2aGullStand(bob),x0-20,y0-30)}continue}
  const p=rpw2aGsPos(x0,y0,i,u),q=rpw2aGsPos(x0,y0,i,u+.06),alt=80*Math.sin(Math.min(1,p[2]*1.3)*Math.PI/2),hd=Math.atan2(q[0]-p[0],-(q[1]-p[1]))||0;
  if(top)rpw2aGull(c,p[0],p[1]-alt,.78+.2*p[2],hd,t*(u<1||u>8?17:9)+i,0);else rpw2aGull(c,p[0],p[1],.62,hd,t*9+i,1)}}
/* expanding ripple rings with a few drops (water clicks, splashes) */
function rpw2aRipple(c,x,y,u,r,col,a){const e=rpw2aEo(u);c.strokeStyle=col||'#ffffff';c.lineWidth=2;for(let j=0;j<3;j++){const v=e-j*.18;if(v<=0)continue;c.globalAlpha=(1-v)*(a||.8);c.beginPath();c.ellipse(x,y,r*v,r*v*.45,0,0,TAU);c.stroke()}
 if(u<.5){c.globalAlpha=(1-u*2)*(a||.8);c.fillStyle=col||'#ffffff';c.beginPath();for(let j=0;j<6;j++){const a2=-Math.PI*(.15+j/6*.7),v=u*2,dx=Math.cos(a2)*r*.5*v,dy=Math.sin(a2)*r*.8*v+r*1.2*v*v;c.moveTo(x+dx+2,y+dy);c.arc(x+dx,y+dy,2,0,TAU)}c.fill()}c.globalAlpha=1}
/* the transient effects of clicks: ripples, sand puffs, leaves, coins, smoke, swirls, bubbles, glow rings */
function rpw2aEvDraw(c,R,top){const s=R.w2a;if(!s||!s.ev.length)return;const t=R.t;c.save();
 for(const e of s.ev){const u=(t-e.t0)/e.d;if(u<0||u>1)continue;const k=e.k;
  if(!top){if(k==='rip')rpw2aRipple(c,e.x,e.y,u,e.r||40,e.col,e.a);
   else if(k==='puff'){c.fillStyle=e.col||'#f0d8a0';for(let j=0;j<7;j++){const a=-Math.PI*(j/6),v=rpw2aEo(u);c.globalAlpha=(1-u)*.7;c.beginPath();c.arc(e.x+Math.cos(a)*22*v,e.y+Math.sin(a)*9*v-4*v,3.4*(1-u*.5),0,TAU);c.fill()}}
   else if(k==='leaf'){const y=e.y+(e.y2-e.y)*rpw2aEio(Math.min(1,u*1.3)),x=e.x+Math.sin(u*9+e.x)*14;c.globalAlpha=Math.min(1,(1-u)*3);c.save();c.translate(x,y);c.rotate(Math.sin(u*7+e.x)*.9);c.fillStyle='#3fae4a';c.beginPath();c.ellipse(0,0,7,2.6,0,0,TAU);c.fill();rpw2aOut(c,1.2);c.restore()}
   else if(k==='bub'){c.strokeStyle='rgba(200,250,255,.85)';c.lineWidth=1.3;c.globalAlpha=1-u*u;c.beginPath();for(let j=0;j<(e.n||10);j++){const v=Math.min(1,u*(1+rpw2aR(j+e.x)*.6)),bx=e.x+(rpw2aR(j*3+e.y)-.5)*30+Math.sin(u*12+j)*4,by=e.y-v*(e.h||120),r=1.6+rpw2aR(j)*3;c.moveTo(bx+r,by);c.arc(bx,by,r,0,TAU)}c.stroke()}
   else if(k==='glowrip'){c.globalCompositeOperation='lighter';c.strokeStyle=e.col||'#8affff';c.lineWidth=2.4;for(let j=0;j<2;j++){const v=rpw2aEo(u)-j*.2;if(v<=0)continue;c.globalAlpha=(1-v)*.8;c.beginPath();c.ellipse(e.x,e.y,(e.r||50)*v,(e.r||50)*v*.5,0,0,TAU);c.stroke()}c.globalCompositeOperation='source-over'}}
  else{if(k==='coins'){c.globalCompositeOperation='lighter';c.globalAlpha=(1-u)*.8;c.drawImage(rpw2aGl('255,210,90',40),e.x-50,e.y-60,100,80);c.globalCompositeOperation='source-over';
    for(let j=0;j<9;j++){const a=-Math.PI*(.2+rpw2aR(j*3+e.x)*.6),v=10+rpw2aR(j+e.y)*90,tt=u*1.5,x=e.x+Math.cos(a)*v*.5*tt,y=e.y-10+Math.sin(a)*v*1.6*tt+160*tt*tt,w=Math.abs(Math.cos(u*20+j))*3+.6;
     c.globalAlpha=Math.min(1,(1-u)*2.5);c.fillStyle='#ffd23a';c.beginPath();c.ellipse(x,y,w,3.4,0,0,TAU);c.fill();c.strokeStyle='#a8641a';c.lineWidth=1.2;c.stroke()}
    c.fillStyle='#fffbe0';c.globalAlpha=1-u;c.beginPath();for(let j=0;j<6;j++){const v=(u*1.6+j/6)%1;rpw2aStar4(c,e.x+Math.cos(j*2.1)*30*v,e.y-20-Math.sin(j*1.3+1)*30*v-10*v,3.6*Math.sin(v*Math.PI))}c.fill()}
   else if(k==='spark'){c.fillStyle=e.col||'#ffffff';c.globalAlpha=1-u;c.beginPath();for(let j=0;j<7;j++){const a=j/7*TAU+e.x,v=rpw2aEo(u);rpw2aStar4(c,e.x+Math.cos(a)*(e.r||26)*v,e.y+Math.sin(a)*(e.r||26)*v*.6,3.4*Math.sin(Math.min(1,u*1.4)*Math.PI))}c.fill()}
   else if(k==='smoke'){const S=rpw2aSmokeSpr();for(let j=0;j<4;j++){const v=Math.max(0,u*1.2-j*.08),r=8+v*30;c.globalAlpha=(1-u)*.55;c.drawImage(S,e.x-r+j*6*v,e.y-r-v*40-j*4,r*2,r*2)}}
   else if(k==='swirl'){const S=rpw2aSmokeSpr();for(let j=0;j<8;j++){const a=j/8*TAU+u*3,r=20+rpw2aEo(u)*60,pr=14+u*16;c.globalAlpha=(1-u)*.5;c.drawImage(S,e.x+Math.cos(a)*r-pr,e.y+Math.sin(a)*r*.5-pr,pr*2,pr*2)}}}}
 c.restore();c.globalAlpha=1}
/* a chest that pops open (overlay on the baked one): the lid swings back, gold glows inside */
function rpw2aChestOpen(c,x,y,s,u){const k=u<.14?rpw2aEo(u/.14):u>.84?1-rpw2aEio((u-.84)/.16):1;if(k<=0)return;c.save();c.translate(x,y);
 c.globalCompositeOperation='lighter';c.globalAlpha=.7*k;c.drawImage(rpw2aGl('255,214,110',30),-s*1.1,-s*1.5,s*2.2,s*1.5);c.globalCompositeOperation='source-over';c.globalAlpha=1;
 /* the lid, tilted back: its inside (dark) with a gold rim, rising from the back edge */
 const lh=s*(.12+.5*k),y0=-s*.42;c.beginPath();c.moveTo(-s*.52,y0);c.lineTo(-s*.5,y0-lh);c.quadraticCurveTo(0,y0-lh-s*.16*k,s*.5,y0-lh);c.lineTo(s*.52,y0);c.closePath();c.fillStyle='#4a2810';c.fill();rpw2aOut(c,2);
 c.strokeStyle='#ffd45a';c.lineWidth=2.2;c.beginPath();c.moveTo(-s*.46,y0-lh+2);c.quadraticCurveTo(0,y0-lh-s*.16*k+2,s*.46,y0-lh+2);c.stroke();c.strokeStyle='#8a5028';c.lineWidth=1.2;c.beginPath();c.moveTo(-s*.2,y0);c.lineTo(-s*.2,y0-lh);c.moveTo(s*.2,y0);c.lineTo(s*.2,y0-lh);c.stroke();
 /* the box rim and the heaped gold */
 c.fillStyle='#8a5028';c.fillRect(-s*.52,y0-1,s*1.04,s*.1);c.strokeStyle=RPO;c.lineWidth=1.6;c.strokeRect(-s*.52,y0-1,s*1.04,s*.1);
 c.fillStyle='#ffd23a';c.beginPath();c.moveTo(-s*.46,y0+1);c.quadraticCurveTo(-s*.2,y0-s*.24,0,y0-s*.18);c.quadraticCurveTo(s*.24,y0-s*.26,s*.46,y0+1);c.closePath();c.fill();c.strokeStyle='#a8641a';c.lineWidth=1.2;c.stroke();
 c.fillStyle='#fff6c0';for(const [dx,dy] of[[-.24,-.1],[.06,-.16],[.28,-.12],[-.06,-.05]]){c.beginPath();c.arc(dx*s,y0+dy*s,s*.045+.6,0,TAU);c.fill()}
 c.fillStyle='#e8343a';c.beginPath();c.arc(s*.16,y0-s*.08,s*.05+.5,0,TAU);c.fill();c.fillStyle='#4ae0ff';c.beginPath();c.arc(-s*.14,y0-s*.12,s*.045+.5,0,TAU);c.fill();c.restore()}
/* splashes round ground monsters inside the circles L ([x, y, r]) while k > 0 (wading) */
function rpw2aWade(c,R,L,k,col){if(!R.foes||k<=.05)return;const t=R.t;c.save();c.strokeStyle=col||'#ffffff';c.lineWidth=2;c.beginPath();const D=[];
 for(let n=0;n<R.foes.length;n++){const e=R.foes[n];if(e.dead||e.air)continue;let q;try{q=rpPos(R,e)}catch(x){continue}let inn=false;for(const w of L){if(Math.hypot(q.x-w[0],(q.y-w[1])*1.2)<w[2]*.95){inn=true;break}}if(!inn)continue;
  const sz=e.boss?2.2:1;for(let j=0;j<2;j++){const u=(t*1.6+j*.5+n*.31)%1,r=(10+u*18)*sz;c.moveTo(q.x+r,q.y+2);c.ellipse(q.x,q.y+2,r,r*.42,0,0,TAU)}
  const ca=Math.cos(q.a),sa=Math.sin(q.a);c.moveTo(q.x-ca*8-sa*10*sz,q.y-sa*8+ca*5*sz);c.lineTo(q.x-ca*30*sz-sa*20*sz,q.y-sa*24*sz+ca*10*sz);c.moveTo(q.x-ca*8+sa*10*sz,q.y-sa*8-ca*5*sz);c.lineTo(q.x-ca*30*sz+sa*20*sz,q.y-sa*24*sz-ca*10*sz);
  if(!R.lite)D.push(q.x,q.y,n)}
 c.globalAlpha=.55*Math.min(1,k*2);c.stroke();c.fillStyle='#ffffff';c.globalAlpha=.8*Math.min(1,k*2);c.beginPath();for(let i=0;i<D.length;i+=3){for(let j=0;j<3;j++){const u=(t*2.2+j/3+D[i+2]*.17)%1,x=D[i]+(j-1)*9*u,y=D[i+1]-4-Math.sin(u*Math.PI)*12;c.moveTo(x+1.8,y);c.arc(x,y,1.8,0,TAU)}}c.fill();c.restore()}
/* ---------- Coral Shallows: live ---------- */
/* butterflies over the flowers inland (homes picked once per bake) and dolphins leaping in the deep water */
function rpw2aCoralInit(B){if(B._w2a)return B;B._w2a=1;const F=B.F,G=B.G,D=rpw2aRoadGrid(G);
 B.bfly=[];for(let i=0;i<700&&B.bfly.length<6;i++){const x=rpw2aR(i*3+5300)*1500+50,y=rpw2aR(i*3+5301)*800+60;if(F.at(x,y)>-150||D.at(x,y)<80||!rpw2aHudFree(x,y)||B.bfly.some(b=>Math.hypot(b[0]-x,b[1]-y)<200))continue;B.bfly.push([x,y,B.bfly.length])}
 B.dol=[];for(const p of(B.sea||[]).slice().sort((a,b)=>b[2]-a[2])){if(B.dol.length>=3)break;if(p[2]<70||!rpw2aHudFree(p[0]-60,p[1])||!rpw2aHudFree(p[0]+60,p[1])||p[0]<80||p[0]>1520||B.dol.some(d=>Math.hypot(d[0]-p[0],d[1]-p[1])<260))continue;B.dol.push([p[0],p[1],B.dol.length])}
 B.chests=B.trees.filter(o=>o.k==='chest');return B}
function rpw2aBfly(c,R,B){const t=R.t,rm=R.rm;for(const [x0,y0,i] of B.bfly){let x=x0+Math.cos(t*.62+i)*46+Math.sin(t*1.7+i*2)*14,y=y0+Math.sin(t*.83+i*1.3)*24+Math.sin(t*2.3+i)*6-18;
  const o=rpw2aOff(R,'bfly',x,y,i,120);x+=o[0];y+=o[1]-Math.abs(o[1])*.4;if(rm){x=x0;y=y0-18}
  const f=rm?.7:Math.abs(Math.sin(t*(rpw2aAgo(R,'bfly')<2?22:13)+i*1.9)),C=['#ff8ad0','#ffd84a','#8ae0ff','#ffffff','#ff9a4a','#b08aff'][i%6];
  c.fillStyle='rgba(20,40,20,.18)';c.beginPath();c.ellipse(x+4,y+26,4,1.6,0,0,TAU);c.fill();
  c.fillStyle=C;c.strokeStyle=RPO;c.lineWidth=1.1;for(const sd of[-1,1]){c.beginPath();c.ellipse(x+sd*(1+4.6*f),y-1.4,4.6*f+.6,4,sd*.3,0,TAU);c.ellipse(x+sd*(1+3.2*f),y+2.6,3.2*f+.5,2.6,-sd*.4,0,TAU);c.fill();c.stroke()}
  c.fillStyle=RPO;c.fillRect(x-.8,y-3.4,1.6,7)}}
/* 10.1f: the nose leads (98u rpcoLeap) and the body is clipped at the water line, so it rises out of the sea and dives back in */
function rpw2aDolPos(R,x0,y0,i){const per=14,off=i*4.7,pu=rpw2aAgo(R,'dol'+i);const ts=pu<2.6?pu:((R.t+off)%per);if(ts>2.6)return null;const dir=i%2?1:-1,u=(ts-.2)/1.5*1.24-.12;
 if(u<-.12||u>1.12)return{ts,dir,u:null};const [x,y,rot]=rpcoLeap(x0,y0,dir,u,110,58);return{ts,dir,u,x,y,rot}}
function rpw2aDolphins(c,R,B){for(const [x0,y0,i] of B.dol){const D=rpw2aDolPos(R,x0,y0,i);if(!D)continue;const {ts,dir}=D;
  if(ts<.75)rpw2aRipple(c,x0-55*dir,y0,ts/.75,26,'#ffffff',.85);if(ts>1.6&&ts<2.5)rpw2aRipple(c,x0+55*dir,y0,(ts-1.6)/.9,30,'#ffffff',.85);
  if(D.u!==null)rpcoLeapDraw(c,rpw2aDolphinSpr(),38,22,D.x,D.y,dir,D.rot,1,y0+3)}}
function rpw2aCoralLive(c,R){const B=rpw2aCoralInit(R.bake);rpw2aTick(R);c.save();
 if(!R.rm&&!R.lite)rpw2aDolphins(c,R,B);
 rpw2aCrabs(c,R,B.crab||[],0);rpw2aGullsStand(c,R,B.gstand||[],0);
 for(const ch of B.chests){const u=rpw2aAgo(R,'chest'+ch.x);if(u<3.4)rpw2aChestOpen(c,ch.x,ch.y,ch.s,u/3.4)}
 rpw2aCrowns(c,R,B.palms||[]);if(!R.lite)rpw2aBfly(c,R,B);rpw2aEvDraw(c,R,0);c.restore()}
function rpw2aCoralTopLive(c,R){const B=R.bake;rpw2aGullsStand(c,R,B.gstand||[],1);rpw2aEvDraw(c,R,1)}
/* a click on Coral Shallows */
function rpw2aCoralPoke(R,x,y){const B=rpw2aCoralInit(R.bake),t=R.t;
 const L=B.light;if(L&&Math.abs(x-L.x)<36&&y>L.y-34&&y<L.y+200){rpw2aPk(R,'light',x,y);rpw2aBeep(660,.12,'sine',.12);setTimeout(()=>rpw2aBeep(990,.18,'sine',.1),90);return 'light'}
 for(const ch of B.chests)if(Math.abs(x-ch.x)<ch.s*.75&&y>ch.y-ch.s*.9&&y<ch.y+8){if(rpw2aAgo(R,'chest'+ch.x)>3.4){rpw2aPk(R,'chest'+ch.x,x,y);rpw2aEv(R,'coins',ch.x,ch.y-ch.s*.5,1.4);rpw2aBeep(1046,.08,'triangle',.12);setTimeout(()=>rpw2aBeep(1568,.14,'triangle',.1),80)}return 'chest'}
 for(let i=0;i<(B.crab||[]).length;i++){const p=B.crab[i];if(Math.hypot(x-p[0],(y-p[1])*1.4)<48){rpw2aPk(R,'crab'+i,x,y);rpw2aEv(R,'puff',p[0],p[1],.7);return 'crab'}}
 for(let i=0;i<(B.gstand||[]).length;i++){const p=B.gstand[i];if(Math.hypot(x-p[0],y-p[1]+12)<44){rpw2aPk(R,'gst'+i,x,y);return 'gull'}}
 for(let i=0;i<3;i++){const G=rpw2aGullP(R,i);if(Math.hypot(x-G.x,y-G.y)<70){rpw2aPk(R,'gulls',x,y);rpw2aBeep(1250,.05,'triangle',.07);return 'gulls'}}
 let best=null;for(const p of B.palms||[])if(Math.hypot(x-p.cx,(y-p.cy)*1.2)<p.h*.42||(Math.abs(x-p.x)<p.h*.12&&y<p.y&&y>p.cy))if(!best||p.y>best.y)best=p;
 if(best){rpw2aPk(R,'palm'+best.i,x,y);for(let j=0;j<2;j++)rpw2aEv(R,'leaf',best.cx+(j?16:-12),best.cy+6,2.2,{y2:best.y+4});return 'palm'}
 for(const b of B.bfly||[])if(Math.hypot(x-b[0],y-b[1])<90){rpw2aPk(R,'bfly',x,y);return 'bfly'}
 for(const it of B.trees){if(it.k==='castle'&&Math.abs(x-it.x)<it.s*.7&&y>it.y-it.s&&y<it.y+6){rpw2aEv(R,'puff',it.x,it.y,.8);rpw2aEv(R,'spark',it.x,it.y-it.s*.7,.8,{col:'#fff6c0'});return 'sandcastle'}
  if(it.k==='pool'){const r=20+rpw2aR(it.i)*8;if(Math.hypot(x-it.x,(y-it.y)*2)<r*1.1){rpw2aEv(R,'rip',x,y,1,{r:r*.8});return 'pool'}}}
 if(B.F.at(x,y)>2){rpw2aEv(R,'rip',x,y,1.1,{r:42});rpw2aPk(R,'sea',x,y);for(const T of[[470,700,0],[1170,740,2]])if(Math.hypot(x-T[0],y-T[1])<190)rpw2aPk(R,'turt'+T[2],x,y);
  for(const d of B.dol)if(Math.hypot(x-d[0],y-d[1])<160&&rpw2aAgo(R,'dol'+d[2])>2.6){rpw2aPk(R,'dol'+d[2],x,y);break}rpw2aBeep(300,.06,'sine',.08);return 'water'}
 for(let i=0;i<(B.crab||[]).length;i++){const p=B.crab[i];if(Math.hypot(x-p[0],y-p[1])<130)rpw2aPk(R,'crab'+i,x,y)}
 rpw2aEv(R,'puff',x,y,.6,{col:B.F.at(x,y)>-60?'#f4dca6':'#a8d86a'});return 'ground'}
/* ---------- Shipwreck Cove: live ---------- */
/* the masts shudder when the cannon fires and when the ship is clicked; the barrel kicks when the cannon is clicked */
function rpw2aShipJolt(R){const f=R.cannon&&R.cannon.fire,jc=f>0&&f<.35?.05*Math.sin(f*55)*(1-f/.35):0,u=rpw2aAgo(R,'ship');return jc+(u<2.6?.07*Math.sin(u*8)*Math.exp(-u*1.7):0)}
function rpw2aCanRec(R){const u=rpw2aAgo(R,'can');return u<.6?(u<.08?u/.08:1-rpw2aEio((u-.08)/.52))*.7:0}
function rpw2aGullO(R,k,i,cx,cy,rx,ry){const t=R.t,a=t*(.16+i*.035)+i*2.6;let x=cx+Math.cos(a)*rx*(1-i*.15),y=cy+Math.sin(a)*ry*(1-i*.15),ph=t*7+i;const o=rpw2aOff(R,k,x,y,i,150);x+=o[0];y+=o[1];const u=rpw2aAgo(R,k);if(u<2)ph+=u*14*(1-u/2);return{x,y,a:a+Math.PI,ph}}
function rpw2aWreckInit(B,map){if(B._w2a)return B;B._w2a=1;const F=B.F,sh=map.ship||[790,610,330,170],k=sh[2]/330,kh=sh[3]/170;
 const inShip=(x,y)=>Math.abs(x-sh[0])<sh[2]*.6&&Math.abs(y-sh[1])<sh[3]*.75;B.lrefl=B.lant.filter(p=>F.at(p[0],p[1]+46)>4&&!inShip(p[0],p[1])).map(p=>[p[0],p[1]+30]);
 for(const dx of[118,136,152])B.lrefl.push([sh[0]+dx*k,sh[1]+30*kh]);
 B.gperch=[];for(const s of(B.stacks||[]).slice().sort((a,b)=>b[2]-a[2])){if(B.gperch.length>=3)break;if(s[1]<170||B.gperch.some(q=>Math.hypot(q[0]-s[0],q[1]-s[1])<200))continue;B.gperch.push([s[0]-s[2]*.1,s[1]-s[2]*1.82,B.gperch.length])}
 B.gperch.push([sh[0]+140*k,sh[1]-101*kh,B.gperch.length]);
 B.chests=B.trees.filter(o=>o.k==='chest');B.skull=B.trees.find(o=>o.k==='skull')||null;B.shipBox=[sh[0]-sh[2]*.62,sh[1]-sh[3]*.5-140,sh[0]+sh[2]*.55,sh[1]+sh[3]*.4];
 B.wfish=[];for(const p of B.sea||[]){if(B.wfish.length>=2)break;if(F.at(p[0],p[1])<60||B.wfish.some(q=>Math.hypot(q[0]-p[0],q[1]-p[1])<300)||Math.abs(p[0]-sh[0])<sh[2]*.6&&Math.abs(p[1]-sh[1])<sh[3]*.7)continue;B.wfish.push([p[0],p[1]])}
 return B}
function rpw2aWreckLive(c,R){const B=rpw2aWreckInit(R.bake,R.map),t=R.t,rm=R.rm,lite=R.lite,s=rpw2aTick(R);c.save();
 /* fish in the murky water */
 if(!rm&&!lite){const AT=rpw2aSeaAtlas();c.globalAlpha=.42;for(let q=0;q<B.wfish.length;q++){const [cx,cy]=B.wfish[q],a0=t*(q?.2:-.17)+q*2;for(let i=0;i<5;i++){const b=a0-i*.1,h=Math.atan2(Math.cos(b)*24,-Math.sin(b)*64)+(q?0:Math.PI);let x=cx+Math.cos(b)*(64+i%2*8),y=cy+Math.sin(b)*24;
   const o=rpw2aOff(R,'seaW',x,y,i+q*5,70);x+=o[0];y+=o[1];c.save();c.translate(x,y);rpcoFlipY(c,h);c.drawImage(AT,((i+q)%3)*40,0,40,24,-12,-7,24,14);c.restore()}}c.globalAlpha=1}
 /* lantern light shimmering on the water below */
 if(B.lrefl.length){c.globalCompositeOperation='lighter';c.fillStyle='rgba(255,190,100,.5)';c.beginPath();for(let i=0;i<B.lrefl.length;i++){const p=B.lrefl[i];for(let j=0;j<4;j++){const yy=p[1]+j*9,w=(10-j*1.6)*(.8+.2*Math.sin(t*3+i+j)),dx=rm?0:Math.sin(t*2.2+j*1.7+i)*3;c.rect(p[0]-w+dx,yy,w*2,2.2)}}
  c.globalAlpha=.55;c.fill();c.globalCompositeOperation='source-over';c.globalAlpha=1}
 /* spray off the sea stacks, now and then */
 if(!rm&&B.stacks){c.fillStyle='#e8f4f0';c.beginPath();for(let i=0;i<B.stacks.length;i++){const st=B.stacks[i],u=(t*.32+i*.37)%1;if(u>.22)continue;const v=u/.22;for(let j=0;j<5;j++){const a=-Math.PI*(.2+j/4*.6),r=st[2]*.8*v,x=st[0]+Math.cos(a)*r,y=st[1]-4+Math.sin(a)*r*1.1+v*v*18;c.moveTo(x+2.2,y);c.arc(x,y,2.2*(1-v*.5),0,TAU)}}c.globalAlpha=.8;c.fill();c.globalAlpha=1}
 rpw2aWreckShadows(c,R);rpw2aCrabs(c,R,B.crab||[],1);rpw2aGullsStand(c,R,B.gperch,0);
 for(const ch of B.chests){const u=rpw2aAgo(R,'chest'+ch.x);if(u<3.4)rpw2aChestOpen(c,ch.x,ch.y,ch.s,u/3.4)}
 /* the skull rock's eyes glow when clicked */
 if(B.skull){const u=rpw2aAgo(R,'skull');if(u<3){const k=(u<.2?u/.2:1-rpw2aEio((u-.2)/2.8))*(.85+.15*Math.sin(t*20)),x=B.skull.x,y=B.skull.y,sz=B.skull.s;c.globalCompositeOperation='lighter';c.globalAlpha=k;
  for(const sd of[-1,1]){c.drawImage(rpw2aGl('255,60,40',20),x+sd*sz*.2-20,y-sz*.55-20,40,40);c.fillStyle='#ffb04a';c.beginPath();c.arc(x+sd*sz*.2,y-sz*.55,3,0,TAU);c.fill()}c.globalCompositeOperation='source-over';c.globalAlpha=1}}
 /* lanterns flare when clicked; the ship's lanterns when the ship is clicked or the cannon fires */
 {const us=rpw2aAgo(R,'ship'),f=R.cannon&&R.cannon.fire,ks=Math.max(us<1.6?1-us/1.6:0,f>0&&f<.3?1-f/.3:0);c.globalCompositeOperation='lighter';const lg=rpw2aGl('255,190,90',30);
  for(let i=0;i<B.lant.length;i++){const p=B.lant[i],u=rpw2aAgo(R,'lant'+i),k=Math.max(u<1.4?1-rpw2aEio(u/1.4):0,i<6&&ks?ks:0);if(k<=0)continue;c.globalAlpha=.7*k;c.drawImage(lg,p[0]-46,p[1]-46,92,92)}
  /* fireflies round the lantern posts */
  if(!rm&&B.post&&B.post.length){c.fillStyle='#ffe08a';c.beginPath();const n=lite?8:20;for(let i=0;i<n;i++){const p=B.post[i%B.post.length],a=t*(.5+rpw2aR(i)*.6)+i*2.3,r=18+rpw2aR(i+3)*26,x=p[0]+8+Math.cos(a)*r,y=p[1]-40+Math.sin(a*1.3)*r*.5,bl=.5+.5*Math.sin(t*3+i*1.7);if(bl<.25)continue;c.moveTo(x+1.8*bl,y);c.arc(x,y,1.8*bl,0,TAU)}c.globalAlpha=.85;c.fill()}
  c.globalCompositeOperation='source-over';c.globalAlpha=1}
 rpw2aEvDraw(c,R,0);c.restore()}
function rpw2aWreckTopLive(c,R){const B=rpw2aWreckInit(R.bake,R.map);rpw2aGullsStand(c,R,B.gperch,1);
 if(!R.rm)for(let i=0;i<2;i++){const G=rpw2aGullO(R,'gullsW',i,830,520,430,230);rpw2aGull(c,G.x,G.y,.85,G.a,G.ph,0)}rpw2aEvDraw(c,R,1)}
function rpw2aWreckShadows(c,R){if(R.rm)return;for(let i=0;i<2;i++){const G=rpw2aGullO(R,'gullsW',i,830,520,430,230);rpw2aGull(c,G.x+50,G.y+70,.85,G.a,G.ph,1)}}
function rpw2aWreckPoke(R,x,y){const B=rpw2aWreckInit(R.bake,R.map),m=R.map;
 for(const ch of B.chests)if(Math.abs(x-ch.x)<ch.s*.75&&y>ch.y-ch.s*.9&&y<ch.y+8){if(rpw2aAgo(R,'chest'+ch.x)>3.4){rpw2aPk(R,'chest'+ch.x,x,y);rpw2aEv(R,'coins',ch.x,ch.y-ch.s*.5,1.4);rpw2aBeep(1046,.08,'triangle',.12);setTimeout(()=>rpw2aBeep(1568,.14,'triangle',.1),80)}return 'chest'}
 for(let i=0;i<B.gperch.length;i++){const p=B.gperch[i];if(Math.hypot(x-p[0],y-p[1]+12)<44){rpw2aPk(R,'gst'+i,x,y);return 'gull'}}
 for(let i=0;i<2;i++){const G=rpw2aGullO(R,'gullsW',i,830,520,430,230);if(Math.hypot(x-G.x,y-G.y)<70){rpw2aPk(R,'gullsW',x,y);rpw2aBeep(1250,.05,'triangle',.07);return 'gulls'}}
 for(let i=0;i<(B.crab||[]).length;i++){const p=B.crab[i];if(Math.hypot(x-p[0],(y-p[1])*1.4)<48){rpw2aPk(R,'crab'+i,x,y);rpw2aEv(R,'puff',p[0],p[1],.7,{col:'#7a7058'});return 'crab'}}
 const cn=m.cannon||[800,585];if(Math.hypot(x-cn[0],y-cn[1]+6)<36){rpw2aPk(R,'can',x,y);const A=rpw2aCannonAim(R);rpw2aEv(R,'smoke',A.x+Math.cos(A.a)*26,A.y-4+Math.sin(A.a)*26,1.2);rpw2aBeep(120,.12,'triangle',.18);return 'cannon'}
 if(B.skull&&Math.abs(x-B.skull.x)<B.skull.s*.6&&y>B.skull.y-B.skull.s*1.1&&y<B.skull.y+6){rpw2aPk(R,'skull',x,y);rpw2aBeep(140,.3,'sawtooth',.06);return 'skull'}
 for(let i=0;i<B.lant.length;i++){const p=B.lant[i];if(Math.hypot(x-p[0],y-p[1])<24){rpw2aPk(R,'lant'+i,x,y);rpw2aEv(R,'spark',p[0],p[1],.8,{col:'#ffe08a',r:20});return 'lantern'}}
 const sb=B.shipBox;if(x>sb[0]&&x<sb[2]&&y>sb[1]&&y<sb[3]){rpw2aPk(R,'ship',x,y);const sh=m.ship||[790,610,330,170];rpw2aEv(R,'rip',sh[0],sh[1]+sh[3]*.32,1.6,{r:sh[2]*.55,a:.6});rpw2aBeep(95,.28,'triangle',.16);return 'ship'}
 if(R.fog)for(const f of R.fog)if(Math.hypot((x-f.x)/f.rx,(y-f.y)/f.ry)<1){rpw2aEv(R,'swirl',x,y,1.4);return 'fog'}
 if(B.F.at(x,y)>2){rpw2aEv(R,'rip',x,y,1.1,{r:40,col:'#d8ece6'});rpw2aPk(R,'seaW',x,y);rpw2aBeep(300,.06,'sine',.08);return 'water'}
 rpw2aEv(R,'puff',x,y,.6,{col:'#8a8270'});return 'ground'}
/* ---------- Kraken's Maw: live ---------- */
/* the eye: the pointer while it moves (3 s), else the leading monster; eased; a click makes it blink */
function rpw2aEyeAim(R,x,y,tx,ty){const s=rpw2aTick(R);if(R.t-s.mv[2]<3&&s.mv[1]>=0){tx=s.mv[0];ty=s.mv[1]}
 if(!s.eye||R.rm)s.eye=[tx,ty];else{const k=1-Math.exp(-s.dt*5);s.eye[0]+=(tx-s.eye[0])*k;s.eye[1]+=(ty-s.eye[1])*k}
 const u=rpw2aAgo(R,'eye'),bl=u<.4?Math.abs(Math.cos(u/.4*Math.PI)):u>.5&&u<.8?Math.abs(Math.cos((u-.5)/.3*Math.PI)):1;return[s.eye[0],s.eye[1],bl]}
/* a tentacle recoils when clicked (all of them a little when the eye is) */
function rpw2aTentRk(R,k){const f=u=>u<1.8?(u<.22?rpw2aEo(u/.22):1-rpw2aEio((u-.22)/1.58)):0;return Math.max(f(rpw2aAgo(R,'tent'+k)),f(rpw2aAgo(R,'eye'))*.55)}
/* whirlpools spin faster with more monsters in them (extra angle, integrated) */
function rpw2aWhirlX(R){const s=rpw2aTick(R),W=R.map.whirl||[];if(s.whf===R.t)return s.wh;s.whf=R.t;
 for(let i=0;i<W.length;i++){const [x,y,r]=W[i];let n=0;if(R.foes)for(const e of R.foes){if(e.dead||e.air)continue;let q;try{q=rpPos(R,e)}catch(z){continue}if(Math.hypot(q.x-x,(q.y-y)*1.4)<r*1.7)n++}
  if(rpw2aAgo(R,'wh'+i)<1.5)n+=4;s.whn[i]=(s.whn[i]||0)+(Math.min(6,n)-(s.whn[i]||0))*Math.min(1,s.dt*2.5);s.wh[i]=(s.wh[i]||0)+s.dt*s.whn[i]*1.15}return s.wh}
function rpw2aFishASpr(k){return rpw2aSpr('fa'+k,30,16,g=>{const C=RPW2A_GLOW[k%5];g.translate(15,8);g.globalCompositeOperation='lighter';g.globalAlpha=.5;g.drawImage(rpw2aGl(C[1],10),-14,-8,28,16);g.globalAlpha=1;g.globalCompositeOperation='source-over';
 g.beginPath();g.moveTo(-9,0);g.lineTo(-13,-4);g.lineTo(-13,4);g.closePath();g.fillStyle=C[0];g.fill();g.beginPath();g.ellipse(0,0,8,3.6,0,0,TAU);g.fillStyle='#1a2a5a';g.fill();g.strokeStyle=C[0];g.lineWidth=1.4;g.stroke();g.fillStyle=C[0];g.fillRect(-3,-1,7,2);g.fillStyle='#fff';g.beginPath();g.arc(4.6,-.8,1.1,0,TAU);g.fill()})}
function rpw2aAbyssInit(B,map){if(B._w2a)return B;B._w2a=1;B.jel=[[190,0],[560,1],[1010,2],[1390,3]];B.chestsA=B.trees.filter(o=>o.k==='chestA');B.clams=B.clams||[];return B}
function rpw2aJellyPos(R,i,x0){const t=R.t,rm=R.rm;let y=rm?300+i*120:960-((t*13+i*260)%1080),x=x0+Math.sin(t*.35+i*1.9)*34;const u=rpw2aAgo(R,'jel'+i);if(u<2.4){y-=90*Math.sin(Math.min(1,u/2.4)*Math.PI*.5)}return[x,y]}
function rpw2aAbyssLive(c,R){const B=rpw2aAbyssInit(R.bake,R.map),t=R.t,rm=R.rm,lite=R.lite,map=R.map,[lx,ly,lrx,lry]=map.lake||[650,425,250,135];rpw2aTick(R);c.save();
 /* moving shafts of light from far above */
 if(!rm){c.globalCompositeOperation='lighter';const ray=rpw2aRaySpr();for(let i=0;i<(lite?1:3);i++){c.globalAlpha=.05+.03*Math.sin(t*.31+i*2);c.save();c.translate(300+i*480+Math.sin(t*.07+i*2)*90,-30);c.rotate(-.3+Math.sin(t*.05+i)*.05);c.drawImage(ray,-60,0,150,860);c.restore()}c.globalCompositeOperation='source-over';c.globalAlpha=1}
 /* a school of glowing fish circling the maw */
 if(!lite){const n=9;for(let i=0;i<n;i++){const a=(rm?0:t*.16)+i*.13+(i%3)*.04,rx=lrx+78+(i%3)*10,ry=lry+56+(i%2)*8;let x=lx+Math.cos(a)*rx,y=ly+Math.sin(a)*ry+Math.sin(t*2+i)*3;const o=rpw2aOff(R,'fishA',x,y,i,90);x+=o[0];y+=o[1];
   const h=Math.atan2(Math.cos(a)*ry,-Math.sin(a)*rx);c.save();c.translate(x,y);rpcoFlipY(c,h);c.drawImage(rpw2aFishASpr(i%5),-15,-8);c.restore()}}
 /* clams breathe bubbles; a clicked clam opens its pearl glow */
 for(let i=0;i<B.clams.length;i++){const [x,y,sz]=B.clams[i],u=rpw2aAgo(R,'clam'+i);if(u<2.6){const k=u<.2?u/.2:1-rpw2aEio((u-.2)/2.4);c.globalCompositeOperation='lighter';c.globalAlpha=k;c.drawImage(rpw2aGl('255,230,250',30),x-40,y-sz*.14-30,80,60);c.globalCompositeOperation='source-over';c.fillStyle='#ffffff';c.beginPath();rpw2aStar4(c,x+6,y-sz*.3,5*k);c.fill();c.globalAlpha=1}}
 /* the sunken chest */
 for(const ch of B.chestsA){const u=rpw2aAgo(R,'chestA');if(u<3.4)rpw2aChestOpen(c,ch.x,ch.y,30,u/3.4)}
 /* the stone face's eyes flash when clicked */
 if(B.face){const u=rpw2aAgo(R,'face');if(u<2){const k=1-rpw2aEio(u/2);c.globalCompositeOperation='lighter';c.globalAlpha=k;for(let j=0;j<2;j++)c.drawImage(rpw2aGl('120,250,255',26),B.face[j*2]-30,B.face[j*2+1]-30,60,60);c.globalCompositeOperation='source-over';c.globalAlpha=1}}
 /* jellyfish drifting up through the water */
 const nj=lite?2:4;for(let i=0;i<nj;i++){const [x,y]=rpw2aJellyPos(R,i,B.jel[i][0]),f=rm?0:(Math.sin(t*2.4+i)>0?0:1),sq=rm?1:1+.08*Math.sin(t*2.4+i*1.3),fl=rpw2aAgo(R,'jel'+i)<.8?1-rpw2aAgo(R,'jel'+i)/.8:0;
  c.globalCompositeOperation='lighter';c.strokeStyle=`rgba(${RPW2A_GLOW[i%5][1]},.55)`;c.lineWidth=1.6;c.beginPath();for(let j=0;j<4;j++){const bx=x-7+j*4.6;c.moveTo(bx,y+2);for(let k=1;k<=6;k++)c.lineTo(bx+Math.sin(t*3+j+k*.8)*3*k/6,y+2+k*6)}c.stroke();
  if(fl){c.globalAlpha=fl;c.drawImage(rpw2aGl(RPW2A_GLOW[i%5][1],40),x-50,y-50,100,90);c.globalAlpha=1}c.globalCompositeOperation='source-over';
  const S=rpw2aJellySpr(i,f);c.drawImage(S,x-30,y-30-(sq-1)*30,60,52*sq)}
 rpw2aEvDraw(c,R,0);c.restore()}
/* the glowcaps flare when a tower near them fires (and when clicked) */
function rpw2aAbyssTwist2(c,R){const s=rpw2aTick(R),G=R.map.glow||[],gr=R.map.glowR||150;if(!G.length)return;const tws=[];for(const p of R.pads)if(p.tw)tws.push(p.tw);
 c.save();c.globalCompositeOperation='lighter';for(let i=0;i<G.length;i++){const [x,y]=G[i];let k=0;for(const w of tws)if((w.fire||0)>k&&Math.hypot(w.x-x,w.y-y)<gr)k=w.fire;
  s.gl[i]=Math.max(k,(s.gl[i]||0)-s.dt*1.4);if(rpw2aAgo(R,'cap'+i)<.05)s.gl[i]=1.3;const g=Math.min(1.3,s.gl[i]);if(g<.02)continue;
  c.globalAlpha=.42*g;c.drawImage(rpw2aGl('90,240,255',40),x-50-20*g,y-60-20*g,100+40*g,90+40*g);
  if(!R.rm){const u=(R.t*1.6+i*.3)%1;c.globalAlpha=.5*g*(1-u);c.strokeStyle='#bff8ff';c.lineWidth=2;c.beginPath();c.ellipse(x,y+2,24+u*50,(24+u*50)*.45,0,0,TAU);c.stroke()}}c.restore()}
function rpw2aAbyssTopLive(c,R){rpw2aEvDraw(c,R,1)}
function rpw2aAbyssPoke(R,x,y){const B=rpw2aAbyssInit(R.bake,R.map),m=R.map,[lx,ly,lrx,lry]=m.lake||[650,425,250,135];
 const ex=lx,ey=ly+lry*.18;if(Math.abs(x-ex)<46&&Math.abs(y-ey)<30){rpw2aPk(R,'eye',x,y);rpw2aEv(R,'glowrip',ex,ey,1,{col:'#e0ff8a',r:70});rpw2aBeep(90,.35,'sine',.2);return 'eye'}
 for(let k=0;k<RPW2A_TENT.length;k++){const T=RPW2A_TENT[k],bx=lx+T[0]*lrx,by=ly+T[1]*lry;for(const f of[0,.25,.5]){const px=bx+Math.cos(T[2])*T[3]*f,py=by+Math.sin(T[2])*T[3]*f*.86;if(Math.hypot(x-px,y-py)<T[4]*1.6+12){rpw2aPk(R,'tent'+k,x,y);rpw2aBeep(70,.2,'sine',.16);return 'tentacle'}}}
 const G=m.glow||[];for(let i=0;i<G.length;i++)if(Math.hypot(x-G[i][0],y-G[i][1]+16)<36){rpw2aPk(R,'cap'+i,x,y);rpw2aEv(R,'glowrip',G[i][0],G[i][1],1,{r:80});rpw2aBeep(880,.1,'sine',.1);return 'glowcap'}
 for(let i=0;i<B.clams.length;i++){const [cx,cy,sz]=B.clams[i];if(Math.abs(x-cx)<sz*.8&&y>cy-sz*.9&&y<cy+8){rpw2aPk(R,'clam'+i,x,y);rpw2aEv(R,'bub',cx,cy-sz*.2,1.6,{n:8,h:110});rpw2aBeep(1320,.08,'sine',.1);return 'clam'}}
 for(const ch of B.chestsA)if(Math.abs(x-ch.x)<26&&y>ch.y-30&&y<ch.y+8){if(rpw2aAgo(R,'chestA')>3.4){rpw2aPk(R,'chestA',x,y);rpw2aEv(R,'coins',ch.x,ch.y-15,1.4);rpw2aEv(R,'bub',ch.x,ch.y-20,1.8,{n:12,h:150});rpw2aBeep(1046,.08,'triangle',.12)}return 'chest'}
 for(const v of B.vent||[])if(Math.hypot(x-v[0],y-v[1]-14)<32){rpw2aEv(R,'bub',v[0],v[1],2,{n:18,h:220});rpw2aBeep(220,.15,'sine',.1);return 'vent'}
 if(B.face&&Math.abs(x-(B.face[0]+B.face[2])/2)<40&&Math.abs(y-B.face[1])<40){rpw2aPk(R,'face',x,y);rpw2aEv(R,'bub',(B.face[0]+B.face[2])/2,B.face[1]+24,1.6,{n:8,h:110});return 'face'}
 for(let i=0;i<(R.lite?2:4);i++){const [jx,jy]=rpw2aJellyPos(R,i,B.jel[i][0]);if(Math.hypot(x-jx,y-jy+6)<34){rpw2aPk(R,'jel'+i,x,y);rpw2aBeep(1500,.08,'sine',.08);return 'jelly'}}
 const W=m.whirl||[];for(let i=0;i<W.length;i++)if(Math.hypot(x-W[i][0],(y-W[i][1])*1.6)<W[i][2]*1.2){rpw2aPk(R,'wh'+i,x,y);rpw2aEv(R,'glowrip',W[i][0],W[i][1],1,{r:70});return 'whirl'}
 if(Math.hypot((x-lx)/(lrx+120),(y-ly)/(lry+100))<1.05)rpw2aPk(R,'fishA',x,y);
 rpw2aEv(R,'glowrip',x,y,1,{r:46});rpw2aEv(R,'bub',x,y,1.3,{n:5,h:70});return 'water'}
/* ---------- wiring ---------- */
const RPW2A_LIVE={coral:{amb:rpw2aCoralLive,top:rpw2aCoralTopLive,poke:rpw2aCoralPoke,twist:(c,R)=>{const T=R.tide;if(T&&R.map.tide)rpw2aWade(c,R,R.map.tide,Math.max(0,Math.min(1,T.k||0)))}},
 wreck:{amb:rpw2aWreckLive,top:rpw2aWreckTopLive,poke:rpw2aWreckPoke},abyss:{amb:rpw2aAbyssLive,top:rpw2aAbyssTopLive,poke:rpw2aAbyssPoke,twist:rpw2aAbyssTwist2}};
for(const id in RPW2A_LIVE){const L=RPW2A_LIVE[id];
 {const a0=RPW.amb[id];RPW.amb[id]=function(c,R){a0(c,R);try{L.amb(c,R)}catch(e){console.error(e)}}}
 if(L.twist){const w0=RPW.twist[id];RPW.twist[id]=function(c,R){if(w0)w0(c,R);try{c.save();L.twist(c,R);c.restore()}catch(e){console.error(e)}}}
 {const t0=RPW.ambTop[id];RPW.ambTop[id]=function(c,R){if(t0)t0(c,R);try{L.top(c,R)}catch(e){console.error(e)}}}}
/* clicks: after the game's own handling, only when nothing of the battle was under the pointer */
function rpw2aPokeOk(R,x,y,btn,touch){return!!(R&&R.map&&RPW2A_LIVE[R.map.id]&&R.bake&&R.bake.id===R.map.id&&btn!==2&&!R.pause&&!R.over&&R.wst!=='done'&&!R.place&&!R.aim&&!rpPick(R,x,y)&&!(touch&&rpSnap(R,x,y))&&!rpw2aFoeAt(R,x,y))}
function rpw2aPoke(R,x,y){rpw2aTick(R);const r=RPW2A_LIVE[R.map.id].poke(R,x,y);rpw2aSt(R).last=r;return r}
{const c0=rpClick;rpClick=function(x,y,btn,touch){const R=RPX;let ok=false;try{ok=rpw2aPokeOk(R,x,y,btn,touch)}catch(e){}const r=c0.apply(this,arguments);if(ok)try{rpw2aPoke(R,x,y)}catch(e){console.error(e)}return r}}
/* ---------- the World 2 hub painting: more life in its overlay (called twice by rpw2aWorldLive: ph 0 under the waves, ph 1 on top) ---------- */
function rpw2aCloudSpr(k){return rpw2aSpr('wcl'+k,190,90,g=>{rpwCloud(g,95,52,k?16:20,'#ffffff','#cfe2ee',.95)})}
function rpw2aWorldLive2(g,W,t,ph){
 if(ph===0){if(!W.dol){W.dol=[];for(const [x,y] of[[640,640],[600,420],[1180,420],[150,740],[700,700]]){if(W.dol.length<2&&rpw2aGrid&&W.c)W.dol.push([x,y])}}
  /* tentacles waving out of the trench */
  for(const [bx,by,a0,Ln,w,cu,bd] of W.tent||[])rpw2aTentacle(g,bx,by,a0,Ln,w,cu,bd,bx,t,0);
  /* the whale blows now and then */
  if(W.whale){const u=(t%7)/1.8;if(u<1){const [x,y]=W.whale;g.fillStyle='#ffffff';g.beginPath();for(let j=0;j<10;j++){const a=-Math.PI/2+(j-4.5)*.12,v=Math.min(1,u*1.6)*(.6+.4*rpw2aR(j)),r=46*v,px=x-26+Math.cos(a)*r*.5,py=y-6+Math.sin(a)*r+u*u*18;g.moveTo(px+2.2,py);g.arc(px,py,2.2*(1-u*.5),0,TAU)}g.globalAlpha=.85*(1-u*u);g.fill();g.globalAlpha=1}}
  /* dolphins leaping in open water (10.1f: 98u's spots and leap: nose on the direction of travel, rising out of and diving into the sea) */
  for(let i=0;i<RPCO_W2DOL.length;i++){const D=rpcoW2Dol(i,t);if(!D)continue;const {x0,y0,dir,ts}=D;
   if(ts<.6)rpw2aRipple(g,x0-30*dir,y0,ts/.6,14,'#ffffff',.8);if(ts>1.25)rpw2aRipple(g,x0+30*dir,y0,Math.min(1,(ts-1.25)/.65),16,'#ffffff',.8);
   rpcoLeapDraw(g,rpw2aDolphinSpr(),38,22,D.x,D.y,dir,D.rot,.55,y0+2)}}
 else{/* the lighthouse beam sweeping the sea */
  if(W.light){const L=W.light,a=t*.9,dx=Math.cos(a),dy=Math.sin(a)*.5,l=Math.hypot(dx,dy);g.save();g.globalCompositeOperation='lighter';g.globalAlpha=.16+.12*Math.max(0,Math.sin(a));g.translate(L.x,L.y);g.rotate(Math.atan2(dy,dx));g.drawImage(rpw2aBeam(),0,-16,190*l,32);g.restore()}
  /* two little clouds drifting across, with their shadows */
  for(let k=0;k<2;k++){const S=rpw2aCloudSpr(k),x=((t*(9+k*4)+k*900)%2000)-200,y=k?6:762;g.globalAlpha=.16;g.fillStyle='#003048';g.beginPath();g.ellipse(x+130,y+110,62,16,0,0,TAU);g.fill();g.globalAlpha=.9;g.drawImage(S,x,y);g.globalAlpha=1}}}
