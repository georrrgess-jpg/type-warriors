/* ===== COMPANION HALL: Pets, Eggs and the Adventure Trail =====
   One screen, three tabs. Opened from the sidebar, the Collection and the Armory. */
const PTX={tab:'Pets',sel:'',filt:'all',sc:{}};
const ptRM=()=>{try{return matchMedia('(prefers-reduced-motion: reduce)').matches}catch(e){return false}};
const ptBadge=(r,sm)=>`<span class="ptbg ptbg-${r}${sm?' sm':''}">${PRAR[r].n.toUpperCase()}</span>`;
const ptCan=()=>!!$('pth');
function ptBeep(f,d,v){try{beep(f,d||.05,'triangle',v||.3)}catch(e){}}
/* soft, rounded tones for hatching: low taps, a warm swell and a final chord (no sharp pings) */
function ptTone(f,d,v,ty,at){try{ensureAudio();if(!ac||!sg||ST.svol<=0)return;const t=ac.currentTime+(at||0),o=ac.createOscillator(),g=ac.createGain();o.type=ty||'sine';o.frequency.value=f;g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(v||.2,t+Math.min(.08,d*.3));g.gain.exponentialRampToValueAtTime(.0008,t+d);o.connect(g);g.connect(sg);o.start(t);o.stop(t+d+.05)}catch(e){}}
const ptTap=()=>{ptTone(196,.18,.22,'sine');ptTone(392,.1,.06,'triangle')};
const ptSwell=(len)=>{[220,277,330,392].forEach((f,i)=>ptTone(f,len||1.2,.07,'sine',i*.08))};
const ptChord=(leg)=>{(leg?[262,330,392,523,659]:[294,370,440,587]).forEach((f,i)=>ptTone(f,1.6,.1,'sine',i*.05));ptTone(leg?1046:880,.9,.04,'triangle',.25)};

/* ---------- the courtyard stage behind the knight and companion ---------- */
const PTBG={};
function ptStageBG(w,h){const k=w+'x'+h;if(PTBG[k])return PTBG[k];const c=document.createElement('canvas');c.width=w;c.height=h;const g=c.getContext('2d');
 let q=g.createLinearGradient(0,0,0,h);q.addColorStop(0,'#1c1438');q.addColorStop(1,'#0d0a1c');g.fillStyle=q;g.fillRect(0,0,w,h);
 for(let y=0,r=0;y<h;y+=34,r++)for(let x=-(r%2)*36;x<w;x+=72){g.fillStyle=`rgba(255,255,255,${.02+((x*7+y*13)%9)/300})`;g.fillRect(x+2,y+2,68,30)}
 /* three arched windows onto a moonlit castle */
 const win=(cx,ww,wh,top)=>{g.save();g.beginPath();g.moveTo(cx-ww/2,top+wh);g.lineTo(cx-ww/2,top+ww/2);g.arc(cx,top+ww/2,ww/2,Math.PI,0);g.lineTo(cx+ww/2,top+wh);g.closePath();g.clip();
  q=g.createLinearGradient(0,top,0,top+wh);q.addColorStop(0,'#1a2a6a');q.addColorStop(1,'#3a3a8a');g.fillStyle=q;g.fillRect(cx-ww,top,ww*2,wh);
  for(let i=0;i<14;i++){g.fillStyle='#ffffffaa';g.fillRect(cx-ww/2+((i*37)%ww),top+((i*53)%(wh*.5)),1.5,1.5)}
  g.fillStyle='#141a44';for(let i=-3;i<=3;i++){const x=cx+i*ww*.16,th=wh*(.3+((i+3)%3)*.08);g.fillRect(x-6,top+wh-th,12,th);g.beginPath();g.moveTo(x-9,top+wh-th);g.lineTo(x,top+wh-th-18);g.lineTo(x+9,top+wh-th);g.fill()}
  g.restore();g.lineWidth=10;g.strokeStyle='#2c2448';g.beginPath();g.moveTo(cx-ww/2,top+wh);g.lineTo(cx-ww/2,top+ww/2);g.arc(cx,top+ww/2,ww/2,Math.PI,0);g.lineTo(cx+ww/2,top+wh);g.stroke();
  g.lineWidth=3;g.strokeStyle='#120c24';g.beginPath();g.moveTo(cx,top);g.lineTo(cx,top+wh);g.moveTo(cx-ww/2,top+wh*.55);g.lineTo(cx+ww/2,top+wh*.55);g.stroke()};
 win(w*.5,w*.3,h*.5,h*.06);win(w*.17,w*.17,h*.36,h*.16);win(w*.83,w*.17,h*.36,h*.16);
 /* the moon */q=g.createRadialGradient(w*.58,h*.18,0,w*.58,h*.18,60);q.addColorStop(0,'#fff6d080');q.addColorStop(1,'#fff6d000');g.fillStyle=q;g.fillRect(w*.58-60,h*.18-60,120,120);
 /* crowned banners */for(const x of[w*.06,w*.94]){g.fillStyle='#5a1e4a';g.beginPath();g.moveTo(x-22,0);g.lineTo(x+22,0);g.lineTo(x+22,h*.42);g.lineTo(x,h*.36);g.lineTo(x-22,h*.42);g.closePath();g.fill();g.strokeStyle='#c8963a';g.lineWidth=2;g.stroke();
  g.fillStyle='#e8b04a';g.beginPath();g.moveTo(x-11,h*.18);g.lineTo(x-11,h*.12);g.lineTo(x-5,h*.15);g.lineTo(x,h*.1);g.lineTo(x+5,h*.15);g.lineTo(x+11,h*.12);g.lineTo(x+11,h*.18);g.closePath();g.fill()}
 /* hanging vines */g.strokeStyle='#2a5a2a';g.lineWidth=4;for(const x of[w*.3,w*.7]){g.beginPath();g.moveTo(x,0);g.quadraticCurveTo(x+20,h*.15,x-6,h*.3);g.stroke();for(let i=0;i<6;i++){g.fillStyle=i%2?'#3a7a3a':'#2e6a30';g.beginPath();g.ellipse(x+Math.sin(i)*10,i*h*.05+10,7,4,i,0,TAU);g.fill()}}
 /* round stone floor */const fy=h*.82;q=g.createLinearGradient(0,fy-60,0,h);q.addColorStop(0,'#2a2240');q.addColorStop(1,'#120e20');g.fillStyle=q;g.fillRect(0,fy-30,w,h);
 g.fillStyle='#3a3054';g.beginPath();g.ellipse(w/2,fy,w*.42,46,0,0,TAU);g.fill();g.strokeStyle='#5a4a74';g.lineWidth=3;g.stroke();g.strokeStyle='#ffd45a55';g.lineWidth=2;g.setLineDash([6,9]);g.beginPath();g.ellipse(w/2,fy,w*.34,34,0,0,TAU);g.stroke();g.setLineDash([]);
 for(let i=0;i<10;i++){const a=i*TAU/10;g.beginPath();g.moveTo(w/2+Math.cos(a)*w*.1,fy+Math.sin(a)*12);g.lineTo(w/2+Math.cos(a)*w*.42,fy+Math.sin(a)*46);g.strokeStyle='#2a2240';g.lineWidth=2;g.stroke()}
 /* side plants */for(const x of[w*.04,w*.96])for(let i=0;i<5;i++)pLeaf(g,x,h,60+i*8,14,-Math.PI/2+(i-2)*.35*(x<w/2?1:-1),'#3a7a3a','#1e4a22',2);
 q=g.createRadialGradient(w/2,h*.6,h*.3,w/2,h*.6,w*.7);q.addColorStop(0,'#00000000');q.addColorStop(1,'#00000099');g.fillStyle=q;g.fillRect(0,0,w,h);
 return PTBG[k]=c}
function ptLantern(g,x,y,t){const f=.8+.2*Math.sin(t*7+x)+.1*Math.sin(t*13);g.save();g.translate(x,y);pGlow(g,0,0,70*f,'#ffb04a',.35);g.fillStyle='#2a1a10';g.fillRect(-2,-34,4,16);g.beginPath();g.roundRect(-11,-20,22,30,4);g.fillStyle='#ffcf6a';g.globalAlpha=.9;g.fill();g.globalAlpha=1;g.strokeStyle='#3a2410';g.lineWidth=3;g.stroke();g.beginPath();g.moveTo(-13,-20);g.lineTo(0,-30);g.lineTo(13,-20);g.closePath();g.fillStyle='#3a2410';g.fill();g.restore()}
const ptSilCv=document.createElement('canvas');
/* draw a companion as a silhouette onto g (for undiscovered pets) */
function ptSil(g,id,x,y,s,o){const w=Math.ceil(240*s),h=Math.ceil(220*s);ptSilCv.width=w;ptSilCv.height=h;const c=ptSilCv.getContext('2d');c.save();c.translate(w/2,h*.9);c.scale(s,s);petDraw(c,id,Object.assign({noSh:1},o));c.restore();c.globalCompositeOperation='source-atop';c.fillStyle='#1a1230';c.fillRect(0,0,w,h);g.drawImage(ptSilCv,x-w/2,y-h*.9)}
function ptStage(cv){const g=cv.getContext('2d'),w=cv.width,h=cv.height,bg=ptStageBG(w,h),fy=h*.82;let last=-1,an=null,t0=0;
 PTX.play=(pose,dur)=>{an={pose,dur,t:performance.now()/1000}};const hearts=[];
 cv.style.cursor='pointer';cv.title='Pet your companion';cv.onclick=e=>{const id=PTX.sel;if(!petOwned(id)||ptRM())return;an={pose:'greet',dur:1.6,t:performance.now()/1000};for(let i=0;i<5;i++)hearts.push({x:w*.31+(Math.random()-.5)*60,y:h*.82-90-Math.random()*30,t:performance.now()/1000+i*.08});try{beep(660,.05,'sine',.2);setTimeout(()=>beep(880,.07,'sine',.16),90)}catch(x){}};
 return t=>{g.setTransform(1,0,0,1,0,0);g.drawImage(bg,0,0);const rm=ptRM(),tt=rm?1.2:t;ptLantern(g,w*.2,h*.5,tt);ptLantern(g,w*.8,h*.5,tt+1.3);
  for(let i=0;i<6;i++){const a=tt*.4+i*1.7,x=w*(.2+.6*((i*.618)%1))+Math.sin(a)*20,y=h*(.35+.3*((i*.38)%1))+Math.cos(a*1.3)*12,al=Math.max(0,Math.sin(tt*1.2+i));pGlow(g,x,y,8,'#d8ff7a',.5*al)}
  const id=PTX.sel;if(id!==last){last=id;if(petOwned(id)&&!rm)an={pose:'greet',dur:1.6,t:performance.now()/1000}}
  /* knight */const ks=2.05;g.save();g.translate(w*.64,fy);g.fillStyle='#00000066';g.beginPath();g.ellipse(0,4,70,12,0,0,TAU);g.fill();g.scale(ks,ks);try{drawHero(g,{arm:P.armor,wp:P.weapon,col:P.col,t:tt})}catch(e){}g.restore();
  if(!id)return;const D=PDEF[id],own=petOwned(id),ps=D.hover?1.25:1.3,px=w*.31,py=fy+8;
  let pose='idle',u=0;if(an){const k=(performance.now()/1000-an.t)/an.dur;if(k>=1)an=null;else{pose=an.pose;u=k}}
  const lk=own?petLook(id):{};g.save();g.translate(px,py);g.scale(ps,ps);if(own){petDraw(g,id,Object.assign({t:tt,pose,u},lk));if(pose==='greet'&&lk.cel)petCelFx(g,id,u,tt,-50,70)}g.restore();
  const nw=performance.now()/1000;for(let i=hearts.length-1;i>=0;i--){const q=hearts[i],k=(nw-q.t)/1.1;if(k<0)continue;if(k>=1){hearts.splice(i,1);continue}g.globalAlpha=1-k;pHeart(g,q.x+Math.sin(k*6+i)*6,q.y-k*70,7+k*3,'#ff8ab4',2);g.globalAlpha=1}
  if(!own){g.save();g.fillStyle='#00000066';g.beginPath();g.ellipse(px,py+2,40*ps,8,0,0,TAU);g.fill();g.restore();ptSil(g,id,px,py,ps,{t:1.2});g.fillStyle='#ffffffcc';g.font='700 44px Poppins,system-ui';g.textAlign='center';g.fillText('?',px,py-50*ps)}}}

/* ---------- the hall ---------- */
function petHall(tab){S.mode='title';S.view='menu';petNorm();if(tab)PTX.tab=tab;
 /* a waiting starter choice is always the first thing the hall shows, whatever tab was open last */
 if(P.petSt===1){const hx=$('pthx');if(hx){if(hx._stop)hx._stop();hx.remove()}return ptStarter()}
 if(!PTX.sel||!PDEF[PTX.sel])PTX.sel=P.pet||PIDS.find(petOwned)||PIDS[0];
 const own=PIDS.filter(petOwned).length,eggs=petEggsN();
 const tabs=[['Pets','Pets'],['Eggs',`Eggs${eggs?` <i class="ptn">${eggs}</i>`:''}`],['Trail','Adventure Trail']];
 const body=PTX.tab==='Eggs'?ptEggsHTML():PTX.tab==='Trail'?ptTrailHTML():ptPetsHTML();
 show(`<div class="pth pt-${PTX.tab}" id="pth"><header class="pthd"><h2>Companion Hall</h2><div class="pttabs" role="tablist">${tabs.map(([k,l])=>`<button class="pttab${PTX.tab===k?' on':''}" data-pt="${k}" role="tab" aria-selected="${PTX.tab===k}">${ptTabIco(k)}<span>${l}</span></button>`).join('')}</div><span class="ptgp" title="Your gold">${PTICO.coin}<b id="ptgold">${P.gold.toLocaleString()}</b></span></header>
  ${body}
  ${PTX.tab==='Trail'?'':`<footer class="ptft"><span>${PTICO.paw} One active companion</span><span>${PTICO.swd} Powers work in Campaign &amp; Endless</span><span class="ptown">${own} / ${PIDS.length} discovered</span></footer>`}
  <div class="ptmod" id="ptmod"></div><div class="row"><button class="sm" id="b">Back</button></div></div>`,'m');
 S.back=()=>{const m=$('ptmod');if(m&&m.classList.contains('on')){ptClose();return}(PTX.back||title)()};$('b').onclick=S.back;
 ov.querySelectorAll('[data-pt]').forEach(b=>b.onclick=()=>{if(b.dataset.pt===PTX.tab)return;ptBeep(560);petHall(b.dataset.pt)});
 if(PTX.tab==='Eggs')ptEggsBind();else if(PTX.tab==='Trail')ptTrailBind();else ptPetsBind();
 /* an unfinished hatch is revealed straight away, on top of the hall, not a moment later */
 if(P.petPend&&!$('pthx'))ptHatchScene(P.petPend.id,P.petPend.k,{reveal:1,starter:P.petPend.st?1:0})}
const PTICO={paw:'<svg viewBox="0 0 24 24" aria-hidden="true"><ellipse cx="12" cy="15.5" rx="5" ry="4.2" fill="currentColor"/><ellipse cx="6" cy="9.5" rx="2.2" ry="2.8" fill="currentColor"/><ellipse cx="10" cy="6" rx="2.2" ry="2.8" fill="currentColor"/><ellipse cx="14" cy="6" rx="2.2" ry="2.8" fill="currentColor"/><ellipse cx="18" cy="9.5" rx="2.2" ry="2.8" fill="currentColor"/></svg>',
 egg:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2C17 2 19.5 10 19 15C18.4 19.6 15.4 22 12 22C8.6 22 5.6 19.6 5 15C4.5 10 7 2 12 2Z" fill="currentColor"/><path d="M6 12L9 14L12 12L15 14L18 12" stroke="#1a1028" stroke-width="1.6" fill="none"/></svg>',
 trail:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2L17 10H14L18 16H14L16 21H8L10 16H6L10 10H7Z" fill="currentColor"/></svg>',
 swd:'<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M20 4L9 15M20 4h-4M20 4v4M7 13l4 4M5 19l3-3"/></svg>',
 pen:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 20L5 15L16 4L20 8L9 19Z" fill="currentColor"/><path d="M14 6L18 10" stroke="#1a1028" stroke-width="1.6"/></svg>',
 lock:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 11V8a5 5 0 0 1 10 0v3" stroke="currentColor" stroke-width="2.6" fill="none"/><rect x="5" y="11" width="14" height="10" rx="2" fill="currentColor"/></svg>',
 chk:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12l5 5L19 7" stroke="currentColor" stroke-width="3.4" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>',
 play:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 4L20 12L7 20Z" fill="currentColor"/></svg>',
 coin:'<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9" fill="#ffd45a" stroke="#9a661a" stroke-width="2"/><path d="M12 7v10" stroke="#9a661a" stroke-width="2.4"/></svg>'};
const ptTabIco=k=>`<i class="ptti">${k==='Pets'?PTICO.paw:k==='Eggs'?PTICO.egg:PTICO.trail}</i>`;

PTICO.spark='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2l2.4 7.6L22 12l-7.6 2.4L12 22l-2.4-7.6L2 12l7.6-2.4z" fill="currentColor"/></svg>';
/* ----- PETS tab ----- */
function ptPetsHTML(){const f=PTX.filt,L=PIDS.filter(id=>f==='all'||PDEF[id].r===f),own=PIDS.filter(petOwned).length;
 const card=id=>{const o=petOwned(id),D=PDEF[id],eq=P.pet===id,nw=P.petNew[id];return `<button class="ptc ptc-${D.r}${o?'':' unk'}${PTX.sel===id?' on':''}" data-p="${id}" aria-label="${o?esc(petName(id)):'Undiscovered '+PRAR[D.r].n+' companion'}"><canvas width="132" height="112" data-pc="${id}"></canvas><span>${o?esc(petName(id)):'Undiscovered'}</span>${eq?`<i class="pteq">${PTICO.chk}</i>`:''}${nw&&o?'<i class="ptnw">NEW</i>':''}${o?'':'<b class="ptq">?</b>'}</button>`};
 return `<div class="ptg"><section class="ptp ptros"><div class="ptph"><h3>Companion Roster</h3><span>${own} / ${PIDS.length} owned</span></div>
  <div class="ptfl">${[['all','All'],['r','Rare'],['l','Legendary']].map(([k,l])=>`<button class="${f===k?'on':''}" data-f="${k}">${l}</button>`).join('')}</div>
  <div class="ptrg" id="ptrg">${L.map(card).join('')}</div></section>
  <section class="ptp ptstg"><canvas width="540" height="620" id="ptcv"></canvas><div class="ptnm" id="ptnm"></div></section>
  <section class="ptp ptdet" id="ptdet"></section></div>`}
function ptDetHTML(id){const D=PDEF[id],o=petOwned(id),lv=petLv(id),xp=petXpIn(id),eq=P.pet===id,A=D.ab,mx=petMaxed(id),pp=P.pets[id]||{};
 const mil=[[3,'acc',D.cos.acc,'Accessory'],[5,'pal',D.cos.pal,'Palette'],[7,'cel',D.cos.cel,'Greeting'],[10,'trim',D.cos.sig,'Signature']],nw=(P.petUnl||{})[id],nxm=mil.find(m=>lv<m[0]),adv=nxm?Math.max(1,Math.ceil((PBOND_T[nxm[0]-1]-(pp.b||0))/10)):0;
 return `<h3 class="ptdn">${o?esc(petName(id)):'Undiscovered'}</h3><div class="ptdr">${ptBadge(D.r)}<em style="color:${PFAM[D.fam]}">${D.fam}</em>${o&&pp.nk?`<small>${D.n}</small>`:''}</div>
  <div class="ptpo"><button class="ptar" data-d="-1" aria-label="Previous companion">‹</button><canvas width="220" height="170" id="ptpor"></canvas><button class="ptar" data-d="1" aria-label="Next companion">›</button></div>
  <div class="ptab"><canvas width="84" height="84" id="ptabi"></canvas><div><b>${A.n}</b><p>${A.d}</p><small>${A.x}</small></div></div>
  ${o?`<div class="ptbd" title="${pp.adv|0} adventures together · ${(pp.used|0).toLocaleString()} powers used"><div><b>Bond Level ${lv}</b><span>${mx?'MAX':`${xp} / ${petXpSpan(id)} XP`}</span></div><span class="ptbar${mx?' mx':''}"><i style="width:${mx?100:petXpPct(id)}%"></i></span><p class="ptnx">${nxm?`${PTICO.trail}<span>Next style <b>${nxm[2]}</b> in <b>${adv}</b> adventure${adv===1?'':'s'}</span>`:`${PTICO.chk}<span>Every style unlocked. ${esc(petName(id))} is fully bonded!</span>`}</p></div>
  <div class="ptms"><h4>Bond Styles <small>${mil.filter(m=>lv>=m[0]).length} / 4 unlocked</small></h4><div>${mil.map(([L,k,n,c])=>`<button class="ptmi${lv>=L?'':' lk'}${lv>=L&&pp[k]?' on':''}${nw===k?' nw':''}" data-cz="${id}" title="${c}: ${n} (Bond ${L})${lv>=L?'':' — locked'}"><canvas width="96" height="80" data-mc="${id}:${k}"></canvas><span>${n}</span><small>${lv>=L?(pp[k]?'Worn':'Unlocked'):'Bond '+L}</small>${lv>=L?'':`<i>${PTICO.lock}</i>`}${nw===k?'<em class="ptnwb">NEW</em>':''}</button>`).join('')}</div></div>

  <div class="ptbt"><button class="ptgo${eq?' done':''}" id="pteq" ${eq?'disabled':''}>${eq?PTICO.chk+' Equipped':'Equip'}</button><button class="ptgo b" id="ptpv">${PTICO.play} Preview ability</button></div>
  <button class="ptlink" data-cz="${id}">${PTICO.pen} Customize &amp; nickname</button>`
  :`<p class="ptlk">${D.r==='l'?'Hatch a Crownheart (Legendary) egg':'Hatch a Runeshell (Rare) egg'} to discover this companion. Eggs never repeat a companion until you own every one of that rarity.</p><div class="ptbt"><button class="ptgo b" id="ptto">${PTICO.egg} See my eggs</button></div>`}`}
function ptPetsBind(){const cv=$('ptcv');if(cv){LIVE.push({cv,fn:ptStage(cv),slow:2})}
 const paint=()=>{ov.querySelectorAll('canvas[data-pc]').forEach(c=>{const id=c.dataset.pc;try{petFit(c,id,Object.assign({t:1.2,sil:petOwned(id)?0:'#4a3c80'},petOwned(id)?petLook(id):{}))}catch(e){}})};paint();
 /* the selected card stays alive; the rest are still frames */
 const live=()=>{const c=ov.querySelector(`.ptc.on canvas`);if(c&&petOwned(PTX.sel)){const id=PTX.sel;LIVE.push({cv:c,fn:t=>{try{petFit(c,id,Object.assign({t:ptRM()?1.2:t},petLook(id)))}catch(e){}},slow:3})}};live();
 const det=()=>{const id=PTX.sel,d=$('ptdet');d.innerHTML=ptDetHTML(id);d.classList.remove('ptin');void d.offsetWidth;d.classList.add('ptin');const own=petOwned(id);
  try{petFit($('ptpor'),id,Object.assign({t:1.2,sil:own?0:'#4a3c80'},own?petLook(id):{}))}catch(e){}try{petIconCv($('ptabi'),PDEF[id].ab.k)}catch(e){}
  d.querySelectorAll('canvas[data-mc]').forEach(c=>{const [pid,k]=c.dataset.mc.split(':');try{if(k==='cel'){petFit(c,pid,{t:1.2,pose:'greet',u:.55,still:1});const g=c.getContext('2d'),s2=c.height/110;g.save();g.translate(c.width/2,c.height*.9);g.scale(s2,s2);petCelFx(g,pid,.4,1,-50,50);g.restore()}else petFit(c,pid,{t:1.2,still:1,[k]:1})}catch(e){}});
  d.querySelectorAll('[data-d]').forEach(b=>b.onclick=()=>{const L=PIDS.filter(x=>PTX.filt==='all'||PDEF[x].r===PTX.filt);const i=L.indexOf(PTX.sel);sel(L[(i+ +b.dataset.d+L.length)%L.length])});
  const eb=$('pteq');if(eb)eb.onclick=()=>{petEquip(id);ptBeep(700,.06,.35);setTimeout(()=>ptBeep(940,.08,.3),70);ccToast(`${petName(id)} will join your next adventure.`);petHall('Pets')};
  const pv=$('ptpv');if(pv)pv.onclick=()=>{if(PTX.play)PTX.play('ability',1.9);ptBeep(520)};
  const to=$('ptto');if(to)to.onclick=()=>petHall('Eggs');
  d.querySelectorAll('[data-cz]').forEach(b=>b.onclick=()=>{const z=b.dataset.cz;if(P.petUnl&&P.petUnl[z]){delete P.petUnl[z];save()}ptCustom(z)});
  const nm=$('ptnm');nm.innerHTML=own?`<button class="ptnk" data-cz="${id}"><b>${esc(petName(id))}</b>${PTICO.pen}</button>${(P.pets[id]||{}).nk?`<small>${PDEF[id].n}</small>`:''}`:`<b class="ptnk dim">Undiscovered</b><small>${PRAR[PDEF[id].r].n} companion</small>`;nm.querySelectorAll('[data-cz]').forEach(b=>b.onclick=()=>ptCustom(b.dataset.cz))};
 const sel=id=>{if(!id)return;PTX.sel=id;if(P.petNew[id]){delete P.petNew[id];save()}ov.querySelectorAll('.ptc').forEach(c=>c.classList.toggle('on',c.dataset.p===id));const nwb=ov.querySelector(`.ptc[data-p="${id}"] .ptnw`);if(nwb)nwb.remove();ptBeep(640,.04,.25);det();live()};
 ov.querySelectorAll('.ptc').forEach(c=>c.onclick=()=>sel(c.dataset.p));
 ov.querySelectorAll('[data-f]').forEach(b=>b.onclick=()=>{PTX.filt=b.dataset.f;const L=PIDS.filter(x=>PTX.filt==='all'||PDEF[x].r===PTX.filt);if(!L.includes(PTX.sel))PTX.sel=L.find(petOwned)||L[0];petHall('Pets')});
 if(P.petNew[PTX.sel]){delete P.petNew[PTX.sel];save()}det()}

/* ----- EGGS tab ----- */
function ptEggsHTML(){const E=k=>{const n=P.eggs[k]|0,pool=petPool(k),full=!pool.length,pc=pool.length?Math.round(1000/pool.length)/10:0;
  return `<section class="ptp pteg pteg-${k}"><div class="ptph"><h3>${PRAR[k].egg} Egg</h3>${ptBadge(k)}</div><div class="ptegc"><canvas width="260" height="250" data-eg="${k}"></canvas><b class="ptegn">×${n}</b></div>
   <p class="ptpool">${full?`You own every ${PRAR[k].n} companion.`:`Hatches one of <b>${pool.length}</b> undiscovered ${PRAR[k].n} companion${pool.length===1?'':'s'} (${pc}% each).`}</p>
   <div class="ptpl">${petList(k).map(id=>`<canvas width="44" height="40" data-pl="${id}" title="${petOwned(id)?esc(PDEF[id].n)+' (owned)':'Undiscovered'}" class="${petOwned(id)?'own':''}"></canvas>`).join('')}</div>
   ${full?`<button class="ptgo b" data-cv="${k}" ${n?'':'disabled'}>Convert to 50 bond XP</button>`:`<button class="ptgo${n?'':' off'}" data-ht="${k}" ${n?'':'disabled'}>${PTICO.egg} ${n?'Hatch one':'No eggs yet'}</button>`}</section>`};
 const M=k=>{const pr=PEGG_PRICE[k],can=P.gold>=pr,full=!petPool(k).length;return `<div class="ptmo"><canvas width="90" height="96" data-me="${k}"></canvas><div><b>${PRAR[k].egg} Egg</b>${ptBadge(k,1)}<span class="ptpr">${PTICO.coin}${pr.toLocaleString()}</span></div><button class="ptgo${can&&!full?'':' off'}" data-by="${k}" ${can&&!full?'':'disabled'}>${full?'Complete':can?'Buy':'Need gold'}</button></div>`};
 const nx=petNextEgg();
 return `<div class="ptge">${E('r')}${E('l')}<section class="ptp ptmer"><div class="ptph"><h3>Egg Merchant</h3><span class="ptgold">${PTICO.coin}${P.gold.toLocaleString()}</span></div>
  <p class="ptsm">Eggs go to your inventory and open when you choose.</p>${M('r')}${M('l')}
  <div class="ptrule"><h4>Collection protection</h4><p>An egg never repeats a companion until you own every companion of that rarity. After that, an egg becomes 50 bond XP for a companion you choose.</p></div>
  <button class="ptnext" data-pt2="Trail">${PTICO.trail}<span>${nx?`<b>${nx.left}</b> more adventure${nx.left===1?'':'s'} to a free ${PRAR[nx.k].egg} egg`:'Adventure Trail'}</span><i>›</i></button></section></div>`}
function ptEggsBind(){ov.querySelectorAll('canvas[data-eg]').forEach(c=>{const k=c.dataset.eg;LIVE.push({cv:c,fn:t=>{const tt=ptRM()?1:t;eggFit(c,k,{t:tt,lean:Math.sin(tt*1.4)*.03,glow:.25+.25*Math.sin(tt*2),zoom:1.05})},slow:2})});
 ov.querySelectorAll('canvas[data-me]').forEach(c=>eggFit(c,c.dataset.me,{t:1,noSh:1}));
 ov.querySelectorAll('canvas[data-pl]').forEach(c=>{const id=c.dataset.pl;petFit(c,id,{t:1.2,sil:petOwned(id)?0:'#3a2e5a'})});
 ov.querySelectorAll('[data-ht]').forEach(b=>b.onclick=()=>{const k=b.dataset.ht;b.disabled=true;const r=petHatch(k);if(!r){petHall('Eggs');return}if(r.full){petHall('Eggs');return}ptHatchScene(r.id,k,{})});
 ov.querySelectorAll('[data-by]').forEach(b=>b.onclick=()=>ptBuyModal(b.dataset.by));
 ov.querySelectorAll('[data-cv]').forEach(b=>b.onclick=()=>ptConvertModal(b.dataset.cv));
 ov.querySelectorAll('[data-pt2]').forEach(b=>b.onclick=()=>petHall(b.dataset.pt2))}

/* ----- ADVENTURE TRAIL tab ----- */
function ptTrailHTML(){const n=P.trail.n,nx=petNextEgg(),cyc=P.trail.c+1;
 const node=i=>{const s=i+1,egg=PTRAIL_EGG[s],done=s<=n,cur=s===n+1;return `<div class="ptst${done?' done':''}${cur?' cur':''}${egg?' egg egg-'+egg:''}" title="Stamp ${s}${egg?' · '+PRAR[egg].egg+' egg':''}">${egg?`<canvas width="64" height="72" data-te="${egg}:${done?1:0}"></canvas>`:done?PTICO.paw:`<b>${s}</b>`}</div>`};
 const acts=[[`${mico('camp',30)}`,'Finish a Campaign level','Any level, any stars'],[`${mico('endless',30)}`,'Clear 5 Endless rounds','Every block of 5 rounds counts'],[`<span class="ptai">⚔</span>`,"Finish a Warden's Arena run",'Win or lose, once you reach the end'],...(typeof ttMenu==='function'?[[`<span class="ptai">🎃</span>`,'Finish a Trick-or-Treat street','While the event is running']]:[])];
 return `<div class="ptgt"><section class="ptp pttr"><div class="ptph"><h3>Adventure Trail</h3><span>Trail ${cyc} · ${n} / ${PTRAIL} stamps</span></div>
  <p class="ptsm">Every finished adventure earns a stamp. Stamps never expire, even if you take a break.</p>
  <div class="ptpath">${Array.from({length:PTRAIL},(_,i)=>node(i)).join('')}</div>
  <div class="ptnx">${nx?`<b>${nx.left}</b> more adventure${nx.left===1?'':'s'} until your next <b style="color:${PRAR[nx.k].c}">${PRAR[nx.k].egg} egg</b>`:''}<span class="ptbar"><i style="width:${n/PTRAIL*100}%"></i></span></div></section>
  <section class="ptp ptacts"><div class="ptph"><h3>What earns a stamp</h3></div>${acts.map(a=>`<div class="ptact">${a[0]}<div><b>${a[1]}</b><small>${a[2]}</small></div><span>+1</span></div>`).join('')}
  <div class="ptrule"><h4>Each cycle of 20 stamps</h4><p><b style="color:${PRAR.r.c}">3 Runeshell eggs</b> at stamps 5, 10 and 15, and a <b style="color:${PRAR.l.c}">Crownheart egg</b> at stamp 20. Your equipped companion also gains 10 bond XP per stamp.</p></div>
  ${P.petSt===0?`<div class="ptres"><b>Rescue your first companion</b><p>Finish any adventure above and you'll get to choose your very first companion.</p></div>`:P.petSt===1?`<button class="ptgo" id="ptstb">${PTICO.paw} Choose your first companion</button>`:''}</section></div>`}
function ptTrailBind(){ov.querySelectorAll('canvas[data-te]').forEach(c=>{const [k,d]=c.dataset.te.split(':');eggFit(c,k,{t:1,noSh:1,glow:+d?0:.3});if(+d){const g=c.getContext('2d');g.globalCompositeOperation='source-atop';g.fillStyle='#ffd45a55';g.fillRect(0,0,c.width,c.height)}});
 const b=$('ptstb');if(b)b.onclick=()=>ptStarter()}

/* ---------- modals ---------- */
function ptOpen(html,cls){const m=$('ptmod');m.className='ptmod on '+(cls||'');m.innerHTML=`<div class="ptmc" role="dialog" aria-modal="true"><button class="ptx" aria-label="Close">×</button>${html}</div>`;m.querySelector('.ptx').onclick=ptClose;m.onclick=e=>{if(e.target===m)ptClose()};return m}
function ptClose(){const m=$('ptmod');if(!m||!m.classList.contains('on'))return;m.classList.add('out');setTimeout(()=>{m.className='ptmod';m.innerHTML=''},180)}
function ptBuyModal(k){const pr=PEGG_PRICE[k],after=P.gold-pr,pool=petPool(k);
 const m=ptOpen(`<h3>Buy a ${PRAR[k].egg} Egg?</h3><div class="ptbuy"><canvas width="160" height="170" id="ptbe"></canvas><div><p>Price <b>${PTICO.coin}${pr.toLocaleString()}</b></p><p>You have <b>${P.gold.toLocaleString()}</b> → <b>${after.toLocaleString()}</b></p>
  <p class="ptsm">Hatches one of ${pool.length} undiscovered ${PRAR[k].n} companions (${Math.round(1000/Math.max(1,pool.length))/10}% each). No duplicates.</p></div></div>
  <div class="ptmb"><button class="ptsoft" id="ptbn">Cancel</button><button class="ptgo" id="ptby">${PTICO.coin} Buy egg</button></div>`);
 eggFit($('ptbe'),k,{t:1,glow:.4});$('ptbn').onclick=ptClose;$('ptby').onclick=()=>{if(petBuy(k)){ptTone(523,.3,.12);ptTone(784,.4,.1,'sine',.08);ccToast(`${PRAR[k].egg} egg added to your inventory.`);ptClose();setTimeout(()=>petHall('Eggs'),190)}}}
function ptConvertModal(k){const L=petList(k).filter(id=>petOwned(id)&&!petMaxed(id));let sel=L[0];
 const m=ptOpen(`<h3>Convert a ${PRAR[k].egg} Egg</h3><p class="ptsm">You own every ${PRAR[k].n} companion, so this egg can become 50 bond XP for one of them.</p>
  ${L.length?`<div class="ptcvl">${L.map(id=>`<button data-cs="${id}" class="${id===sel?'on':''}"><canvas width="90" height="76" data-cc="${id}"></canvas><span>${esc(petName(id))}</span><small>Bond ${petLv(id)}</small></button>`).join('')}</div><div class="ptmb"><button class="ptsoft" id="ptcn">Keep egg</button><button class="ptgo" id="ptcy">Convert egg</button></div>`:`<p>Every ${PRAR[k].n} companion is already at maximum bond. Keep the egg for now.</p><div class="ptmb"><button class="ptgo b" id="ptcn">Keep egg</button></div>`}`);
 m.querySelectorAll('canvas[data-cc]').forEach(c=>petFit(c,c.dataset.cc,Object.assign({t:1.2},petLook(c.dataset.cc))));
 m.querySelectorAll('[data-cs]').forEach(b=>b.onclick=()=>{sel=b.dataset.cs;m.querySelectorAll('[data-cs]').forEach(x=>x.classList.toggle('on',x===b))});
 $('ptcn').onclick=ptClose;const cy=$('ptcy');if(cy)cy.onclick=()=>{const g=petConvert(k,sel);if(g){ptChord(0);ccToast(`${petName(sel)} gained ${g} bond XP.`)}ptClose();setTimeout(()=>petHall('Eggs'),190)}}
/* Bond & Personality: nickname and unlocked styles */
function ptCustom(id){if(!petOwned(id))return;const D=PDEF[id],p=P.pets[id],lv=petLv(id);const st={nk:p.nk||'',pal:p.pal,acc:p.acc,trim:p.trim};let cel=0;
 const opt=(k,L,a,b)=>`<div class="ptop"><h4>${k}</h4><div>${[0,1].map(v=>`<button data-o="${L}:${v}" class="${st[L]===v?'on':''}${v&&lv<a?' lk':''}" ${v&&lv<a?'disabled':''}><canvas width="76" height="64" data-oc="${L}:${v}"></canvas><span>${v?b:'Original'}</span>${v&&lv<a?`<i>${PTICO.lock}</i><small>Bond ${a}</small>`:''}</button>`).join('')}</div></div>`;
 const ms=[[1,'Companion','Your trusty '+D.n],[3,'Accessory',D.cos.acc],[5,'Palette',D.cos.pal],[7,'Celebration',D.cos.cel],[10,'Signature',D.cos.sig]];
 const m=ptOpen(`<h3>Bond &amp; Personality</h3><p class="ptsm">Styles you unlock stay yours forever. Bond never changes ${esc(D.ab.n)}.</p>
  <div class="ptcu"><div class="ptcuL"><canvas width="300" height="250" id="ptcuv"></canvas><label class="ptnkl">Nickname<input id="ptnki" maxlength="16" value="${esc(st.nk)}" placeholder="${D.n}"></label><div class="ptcub">Bond Level <b>${lv}</b></div></div>
  <div class="ptcuR">${opt('Accessory','acc',3,D.cos.acc)}${opt('Color palette','pal',5,D.cos.pal)}${opt('Signature form','trim',10,D.cos.sig)}
  <div class="ptop"><h4>Victory greeting</h4><button class="ptsoft${lv<7?' lk':''}" id="ptcel" ${lv<7?'disabled':''}>${lv<7?PTICO.lock+' Bond 7':PTICO.play+' '+D.cos.cel}</button></div></div></div>
  <div class="ptmsr">${ms.map(([L,n,d])=>`<div class="${lv>=L?'got':''}"><b>Lv ${L}</b><span>${n}</span><small>${esc(d)}</small></div>`).join('')}</div>
  <div class="ptmb"><button class="ptsoft" id="ptcc">Cancel</button><button class="ptgo" id="ptcs">Save appearance</button></div>`,'wide');
 const cv=$('ptcuv');LIVE.push({cv,fn:t=>{const g=cv.getContext('2d');g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,cv.width,cv.height);const q=g.createRadialGradient(150,170,10,150,170,150);q.addColorStop(0,'#3a2a6a');q.addColorStop(1,'#1a1236');g.fillStyle=q;g.fillRect(0,0,300,250);
  g.save();g.translate(150,220);g.scale(1.55,1.55);let pose='idle',u=0;if(cel){const k=(performance.now()/1000-cel)/1.8;if(k>=1)cel=0;else{pose='greet';u=k}}petDraw(g,id,{t:ptRM()?1.2:t,pose,u,pal:st.pal&&lv>=5?1:0,acc:st.acc&&lv>=3?1:0,trim:st.trim&&lv>=10?1:0});g.restore();
  if(cel){const k=(performance.now()/1000-cel)/1.8;for(let i=0;i<14;i++){const a=i*1.3+k*3,r=40+k*110;g.globalAlpha=1-k;pStar4(g,150+Math.cos(a)*r,150+Math.sin(a)*r*.6,5,['#ffd45a','#9aff8a','#ff9ad2','#5ad8ff'][i%4])}g.globalAlpha=1}}});
 m.querySelectorAll('canvas[data-oc]').forEach(c=>{const [L,v]=c.dataset.oc.split(':');petFit(c,id,{t:1.2,[L]:+v,sil:+v&&lv<({acc:3,pal:5,trim:10}[L])?'#2a2048':0})});
 m.querySelectorAll('[data-o]').forEach(b=>b.onclick=()=>{const [L,v]=b.dataset.o.split(':');st[L]=+v;m.querySelectorAll(`[data-o^="${L}:"]`).forEach(x=>x.classList.toggle('on',x===b));ptBeep(600,.04,.25)});
 const cb=$('ptcel');if(cb)cb.onclick=()=>{cel=performance.now()/1000;ptChord(0)};
 $('ptcc').onclick=ptClose;$('ptcs').onclick=()=>{const nk=($('ptnki').value||'').replace(/[<>]/g,'').trim().slice(0,16);p.nk=nk===D.n?'':nk;p.pal=st.pal;p.acc=st.acc;p.trim=st.trim;save();ptBeep(700,.06,.35);ptClose();setTimeout(()=>petHall(PTX.tab),190)}}

/* ---------- STARTER: choose your first companion ---------- */
function ptStarter(){S.mode='title';S.view='menu';let sel=PSTART[0];
 show(`<div class="pth ptstart" id="pth"><header class="ptsh"><h2>Your First Companion</h2><p>Choose one now. You'll discover the others through eggs.</p></header>
  <div class="ptsc">${PSTART.map(id=>{const D=PDEF[id];return `<button class="ptsk${id===sel?' on':''}" data-s="${id}"><h3>${D.n}</h3>${ptBadge(D.r)}<canvas width="300" height="230" data-sv="${id}"></canvas><span class="ptski"><canvas width="64" height="64" data-si="${D.ab.k}"></canvas><b>${D.ab.n}</b></span><p>${D.ab.d}</p><i class="ptskc">${PTICO.chk}</i></button>`}).join('')}</div>
  <button class="ptgo ptchoose" id="ptch">Choose ${PDEF[sel].n} ${PTICO.play}</button><p class="ptsm">One starter choice. Your adventure also earned its normal trail stamp.</p>
  <div class="ptmod" id="ptmod"></div><div class="row"><button class="sm" id="b">Back</button></div></div>`,'m');
 S.back=()=>title();$('b').onclick=S.back;
 ov.querySelectorAll('canvas[data-si]').forEach(c=>petIconCv(c,c.dataset.si));
 ov.querySelectorAll('canvas[data-sv]').forEach(c=>{const id=c.dataset.sv,g=c.getContext('2d');LIVE.push({cv:c,fn:t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,300,230);const on=sel===id;g.save();g.translate(150,200);g.scale(1.6,1.6);petDraw(g,id,{t:ptRM()?1.2:t+id.length,pose:on&&!ptRM()&&(t%5)<1.4?'greet':'idle',u:on?((t%5)/1.4):0});g.restore()},slow:2})});
 ov.querySelectorAll('[data-s]').forEach(b=>b.onclick=()=>{sel=b.dataset.s;ov.querySelectorAll('[data-s]').forEach(x=>x.classList.toggle('on',x===b));$('ptch').innerHTML=`Choose ${PDEF[sel].n} ${PTICO.play}`;ptBeep(620,.05,.3)});
 $('ptch').onclick=()=>{const r=petStarterPick(sel);if(r){PTX.sel=r.id;PTX.tab='Pets';ptHatchScene(r.id,'r',{starter:1})}}}

/* ---------- HATCHING ---------- */
/* the result is already owned and saved; this only presents it. Skip is available at once. */
function ptHatchScene(id,k,opt){opt=opt||{};const wrapEl=$('wrap')||document.body;let el=$('pthx');if(el)el.remove();el=document.createElement('div');el.id='pthx';el.className='pthx';
 const D=PDEF[id],leg=k==='l',T=leg?5.5:4.0,rm=ptRM()||opt.reveal;
 el.innerHTML=`<canvas width="1600" height="900" id="pthc"></canvas><button class="ptskip" id="ptsk">Skip ⏭</button><div class="ptrv" id="ptrv"></div>`;wrapEl.appendChild(el);
 const cv=$('pthc'),g=cv.getContext('2d'),W0=1600,H0=900,cx=W0/2,fy=H0*.6,t0=performance.now()/1000;let done=false,raf=0,lastPh=-1;const parts=[];
 const bgc=document.createElement('canvas');bgc.width=W0;bgc.height=H0;{const b=bgc.getContext('2d');let q=b.createRadialGradient(cx,fy-120,40,cx,fy-120,900);q.addColorStop(0,'#2a1e52');q.addColorStop(1,'#07040f');b.fillStyle=q;b.fillRect(0,0,W0,H0);
  for(const x of[cx-520,cx-300,cx+300,cx+520]){b.fillStyle='#1a1430';b.fillRect(x-40,0,80,fy+20);b.fillStyle='#ffffff08';b.fillRect(x-40,0,10,fy+20)}
  for(const x of[cx-410,cx+410]){b.fillStyle='#4a1a3e';b.beginPath();b.moveTo(x-40,60);b.lineTo(x+40,60);b.lineTo(x+40,330);b.lineTo(x,300);b.lineTo(x-40,330);b.closePath();b.fill();b.fillStyle='#e8b04a';b.beginPath();b.moveTo(x-18,190);b.lineTo(x-18,170);b.lineTo(x-8,180);b.lineTo(x,160);b.lineTo(x+8,180);b.lineTo(x+18,170);b.lineTo(x+18,190);b.closePath();b.fill()}
  /* pedestal */for(const [ry,dy,c0,c1] of[[70,26,'#2a2244','#120e22'],[56,0,'#4a3e6a','#221a38']]){q=b.createLinearGradient(0,fy+dy-ry,0,fy+dy+ry);q.addColorStop(0,c0);q.addColorStop(1,c1);b.fillStyle=q;b.beginPath();b.ellipse(cx,fy+dy,300,ry,0,0,TAU);b.fill();b.strokeStyle='#6a5a90';b.lineWidth=3;b.stroke()}
  b.strokeStyle='#ffd45a44';b.lineWidth=3;b.setLineDash([10,14]);b.beginPath();b.ellipse(cx,fy,230,40,0,0,TAU);b.stroke();b.setLineDash([])}
 const ES=2.1,PS=2.2;let popT=-1;const shards=()=>{if(rm)return;popT=performance.now()/1000-t0;const cs=leg?['#fffaf0','#f2e8d2','#ffd45a','#4a3aa8']:['#6a9aff','#3a6ad8','#e4ecfa','#cfd8ee'];for(let i=0;i<(leg?22:16);i++){const a=-Math.PI/2+(Math.random()-.5)*2.4,v=180+Math.random()*320;parts.push({x:cx+(Math.random()-.5)*60,y:fy-(leg?120:170),vx:Math.cos(a)*v,vy:Math.sin(a)*v,l:1.1+Math.random()*.5,c:cs[i%cs.length],s:5+Math.random()*7,sh:1,r:Math.random()*6,vr:(Math.random()-.5)*14})}};
 const fin=()=>{if(done)return;done=true;P.petPend=null;save();const rv=$('ptrv');const st=opt.starter;
  rv.innerHTML=`<div class="ptrvc">${ptBadge(D.r)}<h2>${D.n}</h2><div class="ptrva"><canvas width="72" height="72" id="ptrvi"></canvas><div><b>${D.ab.n}</b><p>${D.ab.d}</p></div></div>
   <div class="ptmb">${st?`<button class="ptgo" id="ptrvq">${PTICO.paw} Meet ${D.n}</button>`:P.pet===id?`<button class="ptgo" id="ptrvq">${PTICO.chk} Equipped</button>`:`<button class="ptgo" id="ptrve">Equip</button><button class="ptgo b" id="ptrvq">Keep current</button>`}</div></div>`;
  rv.classList.add('on');petIconCv($('ptrvi'),D.ab.k);$('ptsk').style.display='none';
  const close=()=>{cancelAnimationFrame(raf);el.classList.add('out');setTimeout(()=>{el.remove()},260);PTX.sel=id;PTX.tab='Pets';petHall('Pets')};
  const e=$('ptrve');if(e)e.onclick=()=>{petEquip(id);ptBeep(820,.06,.35);close()};$('ptrvq').onclick=close};
 const skip=()=>{if(done)return;skipT=performance.now()/1000-t0;ptChord(leg);fin()};let skipT=-1;
 $('ptsk').onclick=skip;el.tabIndex=-1;el.onkeydown=e=>{if(e.key==='Escape'||e.key===' '){e.preventDefault();if(!done)skip()}};setTimeout(()=>{try{el.focus()}catch(x){}},30);
 if(!rm){if(leg){ptSwell(1.4)}else ptTap()}
 const frame=()=>{if(!el.isConnected)return;const now=performance.now()/1000;let tt=rm?T:Math.min(T,now-t0);if(done&&skipT>=0)tt=T;const t=now;
  g.setTransform(1,0,0,1,0,0);g.drawImage(bgc,0,0);
  const S_=(a,b)=>pSeg(tt,a,b);
  let lean=0,crack=0,open=0,glow=0,lift=0,petY=60,petA=0,petX=0,pose='idle',pu=0,eggA=1,sil=0,eggDy=0,eggS=1;
  if(!leg){/* Runeshell: settle, crack, tip the cap, step out */
   const drop=1-S_(0,.35);eggDy=-drop*drop*120+(tt>.35&&tt<.6?-Math.sin((tt-.35)/.25*Math.PI)*10:0);lean=tt<.8?Math.sin(tt*9)*.05*S_(.3,.5)*(1-S_(.6,.8)):Math.sin(t*14)*.02*S_(.8,1.0)*(1-S_(1.6,1.8));
   glow=S_(.4,.8);crack=S_(.8,1.8);open=S_(1.8,2.5);petY=60-S_(1.9,2.8)*70;petA=S_(1.85,2.0);
   if(tt>2.8){petX=-S_(2.8,3.4)*0;petY=-10+S_(2.8,3.3)*10;eggA=1-S_(2.8,3.4);eggS=1-S_(2.8,3.4)*.15;pose='greet';pu=S_(2.9,4.0)}
   const ph=tt<.8?0:tt<1.8?1:tt<2.8?2:3;if(ph!==lastPh){lastPh=ph;if(!rm){if(ph===1){ptTap();setTimeout(ptTap,260);setTimeout(ptTap,520)}if(ph===2){ptSwell(.9)}if(ph===3)ptChord(0)}if(ph===2)shards()}
   if(tt>.9&&tt<1.8&&Math.random()<.25)parts.push({x:cx+(Math.random()-.5)*120,y:fy-150+(Math.random()-.5)*40,vx:(Math.random()-.5)*90,vy:-60-Math.random()*90,l:1,c:'#cfd8ee',s:4+Math.random()*4})}
  else{/* Crownheart: awaken, release, unfold, emerge, bond */
   glow=S_(0,1);lift=S_(1,2.2);open=S_(2.2,3.6);sil=1-S_(2.9,3.8);petA=S_(2.3,2.8);petY=40-S_(2.4,3.8)*50;eggA=1-S_(3.8,4.6);eggS=1-S_(3.8,4.6)*.12;
   if(tt>3.8){pose='greet';pu=S_(3.9,5.4)}lean=tt>1&&tt<2.2?Math.sin(t*16)*.015:0;
   const ph=tt<1?0:tt<2.2?1:tt<3.8?2:3;if(ph!==lastPh){lastPh=ph;if(!rm){if(ph===1){ptTap();setTimeout(ptTap,300)}if(ph===2)ptSwell(1.6);if(ph===3)ptChord(1)}if(ph===2)shards()}
   if(tt>.2&&tt<3.8&&Math.random()<.35)parts.push({x:cx+(Math.random()-.5)*260,y:fy-40-Math.random()*240,vx:(Math.random()-.5)*20,vy:-30-Math.random()*40,l:1.4,c:Math.random()<.5?'#ffd45a':'#fff6d0',s:3+Math.random()*4,st:1})}
  /* light behind (kept behind the pet and text) */
  const lc=leg?'#ffc23a':'#5ff0ff',lg2=leg?Math.max(glow*.5,open)*(1-S_(4.6,5.5)*.7):Math.max(glow*.4,open)*(1-S_(3.2,4)*.6);
  if(lg2>0){g.save();g.globalCompositeOperation='lighter';for(let i=0;i<10;i++){const a=-Math.PI/2+(i-4.5)*.22+Math.sin(t*.6+i)*.03,len=420+Math.sin(t+i)*40;g.save();g.translate(cx,fy-130);g.rotate(a+Math.PI/2);const q=g.createLinearGradient(0,0,0,-len);q.addColorStop(0,lc+Math.round(lg2*80).toString(16).padStart(2,'0'));q.addColorStop(1,lc+'00');g.fillStyle=q;g.beginPath();g.moveTo(-10,0);g.lineTo(10,0);g.lineTo(40,-len);g.lineTo(-40,-len);g.closePath();g.fill();g.restore()}
   pGlow(g,cx,fy-130,300,lc,.35*lg2);g.restore()}
  if(leg&&glow>0){g.save();g.translate(cx,fy+4);g.scale(1,.2);g.globalCompositeOperation='lighter';g.beginPath();g.arc(0,0,150+glow*60,0,TAU);g.strokeStyle='#ffd45a'+Math.round(glow*(1-S_(4.6,5.5))*200).toString(16).padStart(2,'0');g.lineWidth=14;g.stroke();g.restore()}
  /* particles */for(let i=parts.length-1;i>=0;i--){const p=parts[i];p.l-=1/60;p.x+=p.vx/60;p.y+=p.vy/60;p.vy+=p.st?0:(p.sh?520:90)/60;if(p.l<=0){parts.splice(i,1);continue}g.globalAlpha=Math.min(1,p.l);if(p.sh){p.r+=p.vr/60;g.save();g.translate(p.x,p.y);g.rotate(p.r);pP(g,[-p.s,-p.s*.6,p.s,-p.s*.2,-p.s*.2,p.s]);pF(g,p.c,2);g.restore()}else if(p.st)pStar4(g,p.x,p.y,p.s,p.c);else{g.fillStyle=p.c;g.fillRect(p.x,p.y,p.s,p.s)}g.globalAlpha=1}
  if(popT>=0){const v=(tt-popT)/.7;if(v>=0&&v<1){g.save();g.globalCompositeOperation='lighter';g.translate(cx,fy-150);g.scale(1,.55);g.beginPath();g.arc(0,0,40+v*260,0,TAU);g.strokeStyle=(leg?'#ffd45a':'#9ff8ff')+Math.round((1-v)*200).toString(16).padStart(2,'0');g.lineWidth=10*(1-v)+2;g.stroke();g.restore()}}
  /* the companion rises from inside the shell */
  const drawPet=()=>{if(petA<=0)return;g.save();g.globalAlpha=Math.min(1,petA);g.translate(cx+petX,fy+petY);g.scale(PS,PS);
   if(sil>0&&leg){const tmp=document.createElement('canvas');tmp.width=320;tmp.height=280;const c=tmp.getContext('2d');c.translate(160,250);petDraw(c,id,{t,pose,u:pu,noSh:1});c.globalCompositeOperation='source-atop';c.fillStyle='#fff2c8';c.globalAlpha=sil;c.fillRect(-200,-300,400,400);g.drawImage(tmp,-160,-250)}
   else petDraw(g,id,{t,pose,u:pu,noSh:tt<(leg?3.8:2.8)});g.restore()};
  const drawEgg=(front)=>{if(eggA<=0)return;g.save();g.globalAlpha=eggA;g.translate(cx,fy+eggDy);g.scale(ES*eggS,ES*eggS);eggDraw(g,k,{t,lean,crack,open,glow,lift,noSh:!front});g.restore()};
  if(open>0||(leg&&tt>2.2)){/* pet behind the lower shell while it emerges */
   if(tt<(leg?3.8:2.8)){g.save();g.beginPath();const hw=(leg?(60+open*40):46)*ES;g.rect(cx-hw,0,hw*2,fy-(leg?56:80)*ES*eggS);g.clip();drawPet();g.restore();drawEgg(1)}else{drawEgg(1);drawPet()}}
  else drawEgg(1);
  if(tt>=T-.6&&!done&&!rm)fin();if(rm&&!done)fin();
  raf=requestAnimationFrame(frame)};
 raf=requestAnimationFrame(frame)}

/* ---------- entry points: sidebar, Collection, Armory ---------- */
MG.paw='<g transform="translate(50 54)"><ellipse cx="0" cy="12" rx="20" ry="16" fill="#ffb06a" stroke="#1b1024" stroke-width="4"/><ellipse cx="-22" cy="-12" rx="8" ry="10" fill="#ffb06a" stroke="#1b1024" stroke-width="4"/><ellipse cx="-8" cy="-26" rx="8" ry="10" fill="#ffb06a" stroke="#1b1024" stroke-width="4"/><ellipse cx="8" cy="-26" rx="8" ry="10" fill="#ffb06a" stroke="#1b1024" stroke-width="4"/><ellipse cx="22" cy="-12" rx="8" ry="10" fill="#ffb06a" stroke="#1b1024" stroke-width="4"/><ellipse cx="-6" cy="6" rx="6" ry="4" fill="#fff" opacity=".45"/></g>';
SBN.splice(SBN.findIndex(x=>x[0]==='bt')+1,0,['pt','paw','Pets','']);
NAVGO.pt=()=>{PTX.back=title;petHall()};
NAVDET.unshift([/class="pth/,'pt']);
{const sh0=sbHTML;sbHTML=function(nav){const h=sh0.apply(this,arguments),bd=P.petSt===1||P.petPend?'<i class="bdg">!</i>':petEggsN()?`<i class="bdg">${petEggsN()}</i>`:'';return bd?h.replace(/(id="sb_pt"[^>]*>[\s\S]*?)(<\/button>)/,'$1'+bd+'$2'):h}}

/* Collection: a Pets tab that opens the hall */
try{if(!CTABS.includes('Pets'))CTABS.splice(CTABS.indexOf('Mastery'),0,'Pets')}catch(e){}
{const c1=catalog;catalog=function(back,tab){if(tab==='Pets'){PTX.back=()=>catalog(back||title,'Overview');return petHall('Pets')}return c1.apply(this,arguments)}}
/* Armory: a companion slot beside the weapon and armor slots */
{const a0=armory;armory=function(){const r=a0.apply(this,arguments);try{const sl=ov.querySelector('.arsl');if(sl&&!$('arsp')){const d=document.createElement('button');d.className='arsc arsp';d.id='arsp';const id=P.pet;
  d.title=id?`${petName(id)} · ${PDEF[id].ab.n} (open Companion Hall)`:'Open the Companion Hall';d.setAttribute('aria-label',d.title);d.innerHTML=`<small>Pet</small><div><span class="asi" style="--c:${id?PRAR[PDEF[id].r].c:'#8a7cf0'}"><canvas width="64" height="64" id="arspc"></canvas></span></div>${!id&&P.petSt===1?'<i class="arspb">!</i>':''}`;
  sl.appendChild(d);const c=$('arspc');if(id)petFit(c,id,Object.assign({t:1.2},petLook(id)));else eggFit(c,'r',{t:1,noSh:1});d.onclick=()=>{PTX.back=()=>armory();petHall('Pets')}}}catch(e){}return r}}

/* ---------- styles ---------- */
{const st=document.createElement('style');st.textContent=`
.pth{--ez:cubic-bezier(.2,.9,.3,1);--gold:#ffd45a;--ink:#e8e0ff;position:relative;display:flex;flex-direction:column;gap:12px;width:100%;max-width:1520px;margin:0 auto;padding-bottom:64px;text-align:left}.pth>.row{display:none}
.pthd{display:flex;align-items:center;gap:22px;flex-wrap:wrap;padding-right:170px;animation:ptdn .45s var(--ez) both}@keyframes ptdn{from{opacity:0;transform:translateY(-10px)}}
.pthd h2,.ptsh h2{margin:0;font:400 54px/1 'Pirata One',Georgia,serif;color:var(--gold);text-shadow:0 3px 0 #3a1a00,0 0 22px #ffb02a55}
.pttabs{display:flex;gap:8px}.pttab{all:unset;cursor:pointer;display:flex;align-items:center;gap:8px;padding:9px 18px;border-radius:14px 14px 10px 10px;font:700 16px var(--ui);color:var(--ink);background:linear-gradient(180deg,#1e1a4a,#120e30);border:1.5px solid #3a3070;transition:transform .18s var(--ez),border-color .18s}
.pttab:hover{transform:translateY(-1px);border-color:#8a7cf0}.pttab.on{background:linear-gradient(180deg,#fff0a0,#f0b030);color:#2a1406;border-color:#fff4b8;box-shadow:0 0 18px #ffb02a55}
.ptti svg{width:20px;height:20px;display:block}.ptn{font-style:normal;display:inline-grid;place-items:center;min-width:20px;height:20px;padding:0 5px;border-radius:10px;background:#ff5c6c;color:#fff;font:800 12px var(--ui);margin-left:2px}
.ptp{position:relative;padding:14px 16px;border-radius:18px;background:linear-gradient(180deg,#1a1236f2,#0c0820f6);border:2px solid #3a2f6a;box-shadow:0 10px 24px #000b,inset 0 1px 0 #ffffff10;animation:ptin .5s var(--ez) both}
@keyframes ptin{from{opacity:0;transform:translateY(16px)}}
.ptph{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:8px}.ptph h3{margin:0;font:400 30px/1 'Pirata One',Georgia,serif;color:var(--gold)}.ptph>span:not(.ptbg){font:600 15px var(--ui);color:#c8c2f0}
.ptg{display:grid;grid-template-columns:minmax(300px,1fr) 1.25fr minmax(320px,1fr);gap:14px;align-items:stretch}
.ptstg{padding:0;overflow:hidden;animation-delay:.06s;display:flex;flex-direction:column}.ptstg canvas{width:100%;height:100%;min-height:420px;display:block;object-fit:cover}
.ptnm{position:absolute;left:50%;bottom:16px;transform:translateX(-50%);display:flex;flex-direction:column;align-items:center;gap:2px}
.ptnk{all:unset;cursor:pointer;display:flex;align-items:center;gap:10px;padding:6px 22px;border-radius:14px;background:#0a0618e6;border:1.5px solid #5a4a90;font:400 26px 'Pirata One',Georgia,serif;color:#fff}.ptnk svg{width:18px;height:18px;color:#c8c2f0}.ptnk:hover{border-color:var(--gold)}.ptnk.dim{color:#8a80b0;cursor:default}
.ptnm small{font:600 13px var(--ui);color:#c8c2f0;background:#0a0618b0;padding:1px 10px;border-radius:8px}
.ptdet{animation-delay:.12s;display:flex;flex-direction:column;gap:8px}.ptdet.ptin{animation:ptfade .32s var(--ez)}@keyframes ptfade{from{opacity:.2;transform:translateY(6px)}}
.ptfl{display:flex;gap:6px;margin-bottom:10px}.ptfl button{all:unset;cursor:pointer;padding:6px 16px;border-radius:10px;font:700 14px var(--ui);color:var(--ink);background:#140e30;border:1.5px solid #3a3070}.ptfl button.on{background:linear-gradient(180deg,#5a4ae0,#3a2aa8);border-color:#a89aff}
.ptrg{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}
.ptc{all:unset;min-width:0;box-sizing:border-box;position:relative;cursor:pointer;display:flex;flex-direction:column;align-items:center;padding:4px 4px 6px;border-radius:12px;background:radial-gradient(circle at 50% 35%,#2a2050,#0e0a22);border:2px solid #3a3070;transition:transform .18s var(--ez),border-color .18s,box-shadow .18s}
.ptc canvas{width:100%;height:auto;aspect-ratio:132/112}.ptc span{font:600 11.5px var(--ui);color:var(--ink);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}
.ptc-r{border-color:#2a5aa8}.ptc-l{border-color:#a8801a}.ptc:hover{transform:translateY(-2px)}.ptc.on{border-color:var(--gold);box-shadow:0 0 0 2px #ffd45a55,0 0 18px #ffd45a55}
.ptc.unk span{color:#8a80b0}.ptq{position:absolute;top:30%;left:50%;transform:translate(-50%,-50%);font:800 26px var(--ui);color:#6a5a9a}
.pteq{position:absolute;top:4px;right:4px;width:22px;height:22px;border-radius:50%;background:var(--gold);color:#2a1406;display:grid;place-items:center}.pteq svg{width:14px;height:14px}
.ptnw{position:absolute;top:4px;left:4px;font:800 10px var(--ui);font-style:normal;padding:1px 6px;border-radius:8px;color:#2a1406;background:linear-gradient(180deg,#fff0a0,#f0a820);animation:ptnw 2.4s ease-in-out infinite}@keyframes ptnw{50%{box-shadow:0 0 12px #ffd45a}}
.ptbg{display:inline-block;align-self:flex-start;padding:3px 14px;border-radius:12px;font:800 13px var(--ui);letter-spacing:1.5px}.ptbg.sm{padding:1px 8px;font-size:10.5px}.ptbg-r{color:#dff0ff;background:linear-gradient(180deg,#2a6ad8,#1a3a8a);border:1.5px solid #7ac8ff}.ptbg-l{color:#2a1406;background:linear-gradient(180deg,#fff0a0,#f0a820);border:1.5px solid #fff4b8}
.ptdn{margin:0;text-align:center;font:400 36px/1 'Pirata One',Georgia,serif;color:var(--gold)}.ptdr{display:flex;justify-content:center;align-items:center;gap:10px}.ptdr em{font:italic 600 14px Georgia,serif}.ptdr small{font:600 12px var(--ui);color:#a8a2d8}
.ptpo{display:flex;align-items:center;justify-content:center;gap:6px}.ptpo canvas{width:170px;height:auto;aspect-ratio:220/170}
.ptar{all:unset;cursor:pointer;width:32px;height:44px;border-radius:10px;display:grid;place-items:center;font:700 26px var(--ui);color:#c8c2f0;background:#140e30;border:1.5px solid #3a3070}.ptar:hover{border-color:var(--gold);color:#fff}
.ptab{display:flex;gap:12px;align-items:center;padding:8px 10px;border-radius:14px;background:#0a0618;border:1.5px solid #2a2050}.ptab canvas{width:56px;height:56px;flex:none;border-radius:50%;background:radial-gradient(circle,#2a2050,#0a0618);border:2px solid #c8963a}
.ptab b{font:400 26px/1 'Pirata One',Georgia,serif;color:#9fffb0}.ptab p{margin:2px 0;font:600 13px/1.3 var(--ui);color:var(--ink)}.ptab small{font:500 12.5px var(--ui);color:#a8a2d8}
.ptbd>div{display:flex;justify-content:space-between;font:600 15px var(--ui);color:var(--ink)}.ptbd b{font:700 16px var(--ui)}.ptbd small{display:none}
.ptbar{display:block;height:10px;margin-top:4px;border-radius:6px;background:#0a0618;border:1px solid #ffffff1c;overflow:hidden}.ptbar i{display:block;height:100%;border-radius:6px;background:linear-gradient(90deg,#8a5aff,#c08aff);box-shadow:0 0 10px #a86aff88}.ptbar.mx i{background:linear-gradient(90deg,#ffd45a,#ffb02a)}
.ptms h4,.ptop h4,.ptrule h4{margin:0 0 6px;font:700 14px var(--ui);color:#c8c2f0}.ptms>div{display:flex;gap:8px}
.ptmi{all:unset;cursor:pointer;position:relative;flex:1;display:flex;flex-direction:column;align-items:center;padding:4px;border-radius:12px;background:#0a0618;border:1.5px solid #3a3070;transition:border-color .18s}.ptmi canvas{width:60px;height:50px}.ptmi span{font:600 11.5px var(--ui);color:var(--ink);text-align:center}.ptmi small{font:500 10.5px var(--ui);color:#a8a2d8}
.ptms h4 small{float:right;font:600 12px var(--ui);color:#a8a2d8}.ptmi.nw{border-color:#7affb0;box-shadow:0 0 14px #5aff9a55;animation:ptnw 2.4s ease-in-out infinite}.ptnwb{position:absolute;top:-7px;right:-4px;font:800 9.5px var(--ui);font-style:normal;padding:1px 6px;border-radius:8px;color:#06301a;background:linear-gradient(180deg,#c8ffd8,#3ad87a)}
.ptnx{display:flex;align-items:center;gap:7px;margin:6px 0 0;font:600 13px/1.25 var(--ui);color:#c8c2f0}.ptnx svg{width:16px;height:16px;flex:none;color:var(--gold)}.ptnx b{color:#fff}
.ptjr{display:flex;justify-content:center;gap:18px;font:600 12.5px var(--ui);color:#a8a2d8}.ptjr span{display:flex;align-items:center;gap:5px}.ptjr svg{width:14px;height:14px;color:#c8963a}.ptjr b{color:var(--ink)}
.ptmi.on{border-color:var(--gold)}.ptmi.lk canvas{filter:brightness(.35) saturate(.4)}.ptmi i{position:absolute;top:20px;color:#e8e0ff}.ptmi i svg{width:20px;height:20px}.ptmi:hover{border-color:#8a7cf0}
.ptbt{display:flex;gap:8px}.ptgo{all:unset;box-sizing:border-box;cursor:pointer;flex:1;display:flex;align-items:center;justify-content:center;gap:8px;white-space:nowrap;padding:10px 14px;border-radius:14px;font:800 17px var(--ui);color:#2a1406;background:linear-gradient(180deg,#fff0a0,#f0b030);border:2px solid #fff4b8;box-shadow:0 4px 0 #8a5a10,0 0 16px #ffb02a44;transition:transform .18s var(--ez),filter .18s}
.ptgo svg{width:18px;height:18px}.ptgo:hover{filter:brightness(1.08);transform:translateY(-1px)}.ptgo:active{transform:translateY(2px);box-shadow:0 2px 0 #8a5a10}
.ptgo.b{color:#fff;background:linear-gradient(180deg,#6a5af0,#3a2aa8);border-color:#a89aff;box-shadow:0 4px 0 #1e1660,0 0 16px #6a5af044}.ptgo.done,.ptgo.off,.ptgo:disabled{color:#c8c2f0;background:linear-gradient(180deg,#3a3460,#241e44);border-color:#5a5090;box-shadow:none;cursor:default;filter:none;transform:none}
.ptlink{all:unset;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:6px;font:700 13.5px var(--ui);color:#c8c2f0}.ptlink svg{width:15px;height:15px}.ptlink:hover{color:#fff}
.ptlk{font:500 14px var(--ui);color:#c8c2f0;margin:4px 0}
.ptft{display:flex;align-items:center;gap:22px;padding:8px 16px;border-radius:14px;background:#0a0618b8;border:1px solid #2a2050;font:600 14px var(--ui);color:#d4cef0;animation:ptin .5s var(--ez) .2s both}.ptft span{display:flex;align-items:center;gap:8px}.ptft svg{width:20px;height:20px;color:var(--gold)}.ptown{margin-left:auto;color:#a8a2d8}
.ptge{display:grid;grid-template-columns:1fr 1fr 1.05fr;gap:14px}.pteg{display:flex;flex-direction:column;align-items:center;gap:8px}.pteg-l{animation-delay:.06s}.ptmer{animation-delay:.12s;display:flex;flex-direction:column;gap:10px}
.ptegc{position:relative}.ptegc canvas{width:240px;height:auto;aspect-ratio:260/250}.ptegn{position:absolute;right:8px;bottom:10px;font:400 34px 'Pirata One',Georgia,serif;color:#fff;text-shadow:0 2px 0 #000}
.ptpool{margin:0;text-align:center;font:500 14px var(--ui);color:var(--ink)}.ptpl{display:flex;flex-wrap:wrap;justify-content:center;gap:4px}.ptpl canvas{width:40px;height:36px;border-radius:8px;background:#0a0618;border:1px solid #2a2050}.ptpl canvas.own{border-color:#5a8a5a}
.pteg .ptgo{width:100%;flex:none}.ptgold{display:flex;align-items:center;gap:6px;font:800 18px var(--ui)!important;color:var(--gold)!important}.ptgold svg,.ptpr svg{width:20px;height:20px}
.ptsm{margin:0;font:500 13.5px var(--ui);color:#a8a2d8}.ptmo{display:flex;align-items:center;gap:12px;padding:8px 10px;border-radius:14px;background:#0a0618;border:1.5px solid #2a2050}.ptmo canvas{width:64px;height:auto;aspect-ratio:90/96}.ptmo>div{flex:1;display:flex;flex-direction:column;gap:3px}.ptmo b{font:400 22px 'Pirata One',Georgia,serif;color:#fff}
.ptpr{display:flex;align-items:center;gap:6px;font:800 16px var(--ui);color:var(--gold)}.ptmo .ptgo{flex:none;padding:9px 18px}
.ptrule{padding:10px 12px;border-radius:12px;background:#140e30;border:1px solid #2a2050}.ptrule p{margin:0;font:500 13px/1.4 var(--ui);color:#d4cef0}
.ptnext{all:unset;cursor:pointer;display:flex;align-items:center;gap:10px;padding:10px 14px;border-radius:14px;background:linear-gradient(90deg,#1e3a1e,#140e30);border:1.5px solid #4a8a4a;font:600 14px var(--ui);color:var(--ink)}.ptnext svg{width:22px;height:22px;color:#9fffb0}.ptnext span{flex:1}.ptnext b{color:#9fffb0;font-size:17px}.ptnext i{font-style:normal;font-size:22px}
.ptgt{display:grid;grid-template-columns:1.7fr 1fr;gap:14px}.ptacts{animation-delay:.08s;display:flex;flex-direction:column;gap:8px}
.ptpath{display:grid;grid-template-columns:repeat(10,1fr);gap:10px 8px;margin:16px 0;padding:10px}
.ptst{position:relative;aspect-ratio:1;border-radius:50%;display:grid;place-items:center;background:radial-gradient(circle at 40% 35%,#2a2050,#0e0a22);border:2.5px solid #3a3070;color:#6a5a9a;font:800 15px var(--ui)}.ptst b{font:800 15px var(--ui)}
.ptst svg{width:58%;height:58%}.ptst.done{background:radial-gradient(circle at 40% 35%,#ffe48a,#c88a1a);border-color:#fff4b8;color:#3a1c00;box-shadow:0 0 12px #ffb02a66}
.ptst.cur{border-color:#9fffb0;box-shadow:0 0 0 3px #9fffb055,0 0 18px #9fffb066;animation:ptcur 1.8s ease-in-out infinite}@keyframes ptcur{50%{box-shadow:0 0 0 6px #9fffb022,0 0 26px #9fffb088}}
.ptst.egg{border-radius:18px;transform:scale(1.15)}.ptst.egg canvas{width:86%;height:auto}.ptst.egg-r{border-color:#5ab8ff}.ptst.egg-l{border-color:#ffc23a}
.ptnx{font:600 16px var(--ui);color:var(--ink)}.ptnx b{color:#9fffb0}
.ptact{display:flex;align-items:center;gap:12px;padding:8px 10px;border-radius:12px;background:#0a0618;border:1px solid #2a2050}.ptact>svg,.ptact .ptai{width:34px;height:34px;flex:none;display:grid;place-items:center;font-size:22px}.ptact div{flex:1;display:flex;flex-direction:column}.ptact b{font:700 14.5px var(--ui);color:var(--ink)}.ptact small{font:500 12px var(--ui);color:#a8a2d8}.ptact>span{font:800 15px var(--ui);color:#9fffb0}
.ptres{padding:12px;border-radius:12px;background:linear-gradient(90deg,#1e3a1e,#140e30);border:1.5px solid #4a8a4a}.ptres b{font:700 15px var(--ui);color:#9fffb0}.ptres p{margin:4px 0 0;font:500 13px var(--ui);color:var(--ink)}
.ptmod{position:absolute;inset:-6px -6px 40px;z-index:60;display:none;align-items:center;justify-content:center;background:#05031ad0;border-radius:20px;animation:ptfo .18s ease both}.ptmod.on{display:flex}.ptmod.out{animation:ptfo .18s ease reverse both}@keyframes ptfo{from{opacity:0}}
.ptmc{position:relative;width:min(560px,94%);padding:20px 24px;border-radius:18px;background:linear-gradient(180deg,#1c1644,#0a0822);border:2px solid #e8c36a;box-shadow:0 20px 50px #000d;animation:ptin .32s var(--ez)}.ptmod.wide .ptmc{width:min(900px,96%)}
.ptmc h3{margin:0 0 6px;font:400 34px 'Pirata One',Georgia,serif;color:var(--gold)}.ptx{all:unset;cursor:pointer;position:absolute;right:14px;top:6px;font:400 32px Georgia,serif;color:#e8c36a;transition:transform .18s var(--ez)}.ptx:hover{transform:rotate(90deg)}
.ptmb{display:flex;justify-content:flex-end;gap:10px;margin-top:14px}.ptmb .ptgo{flex:none;padding:11px 22px}
.ptsoft{all:unset;cursor:pointer;display:inline-flex;align-items:center;gap:6px;padding:10px 16px;border-radius:12px;font:700 14px var(--ui);color:#c8c2f0;border:1.5px solid #3a3070;background:#140e30}.ptsoft svg{width:16px;height:16px}.ptsoft:hover{border-color:#8a7cf0;color:#fff}.ptsoft.lk{opacity:.6;cursor:default}
.ptbuy{display:flex;gap:16px;align-items:center}.ptbuy canvas{width:130px;height:auto;aspect-ratio:160/170}.ptbuy p{margin:4px 0;font:600 15px var(--ui);color:var(--ink)}.ptbuy b{display:inline-flex;align-items:center;gap:4px;color:var(--gold)}.ptbuy b svg{width:18px;height:18px}
.ptcvl{display:flex;flex-wrap:wrap;gap:8px;margin-top:10px}.ptcvl button{all:unset;cursor:pointer;display:flex;flex-direction:column;align-items:center;padding:6px;border-radius:12px;background:#0a0618;border:2px solid #2a2050;width:100px}.ptcvl button.on{border-color:var(--gold)}.ptcvl canvas{width:80px;height:auto;aspect-ratio:90/76}.ptcvl span{font:600 12px var(--ui);color:var(--ink)}.ptcvl small{font:500 11px var(--ui);color:#a8a2d8}
.ptcu{display:grid;grid-template-columns:300px 1fr;gap:16px}.ptcuL{display:flex;flex-direction:column;gap:8px}.ptcuL canvas{width:300px;height:250px;border-radius:14px;border:1.5px solid #3a3070}
.ptnkl{display:flex;flex-direction:column;gap:4px;font:700 13px var(--ui);color:#c8c2f0}.ptnkl input{font:400 22px 'Pirata One',Georgia,serif;padding:6px 10px;border-radius:10px;border:1.5px solid #5a4a90;background:#0a0618;color:#fff;outline:none}.ptnkl input:focus{border-color:var(--gold)}
.ptcub{font:600 14px var(--ui);color:var(--ink)}.ptcub b{color:#c08aff}
.ptcuR{display:flex;flex-direction:column;gap:10px}.ptop>div{display:flex;gap:8px}.ptop button[data-o]{all:unset;cursor:pointer;position:relative;display:flex;flex-direction:column;align-items:center;padding:4px 8px;border-radius:12px;background:#0a0618;border:2px solid #2a2050}.ptop button[data-o].on{border-color:var(--gold);box-shadow:0 0 12px #ffd45a44}
.ptop canvas{width:76px;height:64px}.ptop span{font:600 12px var(--ui);color:var(--ink)}.ptop i{position:absolute;top:18px;color:#fff}.ptop i svg{width:18px;height:18px}.ptop small{font:500 10.5px var(--ui);color:#a8a2d8}.ptop button.lk{cursor:default}
.ptmsr{display:grid;grid-template-columns:repeat(5,1fr);gap:6px;margin-top:12px}.ptmsr div{padding:6px;border-radius:10px;background:#0a0618;border:1px solid #2a2050;opacity:.6}.ptmsr div.got{opacity:1;border-color:#a8801a}.ptmsr b{display:block;font:400 18px 'Pirata One',Georgia,serif;color:var(--gold)}.ptmsr span{display:block;font:700 12px var(--ui);color:var(--ink)}.ptmsr small{font:500 10.5px var(--ui);color:#a8a2d8}
.ptstart{align-items:center;text-align:center}.ptsh p{margin:6px 0 0;font:500 17px var(--ui);color:var(--ink)}.ptsc{display:flex;gap:18px;justify-content:center;flex-wrap:wrap}
.ptsk{all:unset;position:relative;cursor:pointer;width:300px;display:flex;flex-direction:column;align-items:center;gap:6px;padding:14px 12px 16px;border-radius:20px;background:linear-gradient(180deg,#1c1644,#0e0a26);border:2.5px solid #4a3a90;transition:transform .32s var(--ez),border-color .32s,box-shadow .32s;animation:ptin .55s var(--ez) both}
.ptsk:nth-child(2){animation-delay:.08s}.ptsk:nth-child(3){animation-delay:.16s}.ptsk:hover{transform:translateY(-4px)}.ptsk.on{border-color:var(--gold);box-shadow:0 0 0 3px #ffd45a44,0 0 30px #ffd45a55;transform:translateY(-6px)}
.ptsk h3{margin:0;font:400 34px 'Pirata One',Georgia,serif;color:var(--gold)}.ptsk canvas[data-sv]{width:280px;height:auto;aspect-ratio:300/230}.ptski{display:flex;align-items:center;gap:8px}.ptski canvas{width:44px;height:44px}.ptski b{font:400 22px 'Pirata One',Georgia,serif;color:#9fffb0}.ptsk p{margin:0;font:500 14px var(--ui);color:var(--ink)}
.ptskc{position:absolute;top:10px;right:10px;width:32px;height:32px;border-radius:50%;display:none;place-items:center;background:var(--gold);color:#2a1406}.ptskc svg{width:20px;height:20px}.ptsk.on .ptskc{display:grid;animation:ptpop .35s var(--ez)}@keyframes ptpop{from{transform:scale(.3)}}
.ptchoose{flex:none;padding:14px 36px;font-size:22px;margin-top:6px}
.pthx{position:absolute;inset:0;z-index:300;background:#05030c;animation:ptfo .3s ease both}.pthx.out{animation:ptfo .26s ease reverse both}.pthx>canvas{position:absolute;inset:0;width:100%;height:100%}
.ptskip{all:unset;cursor:pointer;position:absolute;right:28px;bottom:28px;padding:10px 20px;border-radius:12px;font:700 16px var(--ui);color:#e8e0ff;background:#140e30d8;border:1.5px solid #6a5ab0}.ptskip:hover{border-color:var(--gold)}
.ptrv{position:absolute;left:50%;bottom:28px;transform:translateX(-50%);opacity:0;pointer-events:none;transition:opacity .4s,transform .45s var(--ez)}.ptrv.on{opacity:1;pointer-events:auto;transform:translateX(-50%) translateY(-6px)}
.ptrvc{display:flex;flex-direction:column;align-items:center;gap:6px;padding:12px 24px;border-radius:18px;background:#0e0a26e8;border:2px solid #e8c36a;min-width:520px}.ptrvc h2{margin:0;font:400 54px/1 'Pirata One',Georgia,serif;color:var(--gold);text-shadow:0 3px 0 #3a1a00}
.ptrva{display:flex;gap:12px;align-items:center;text-align:left}.ptrva canvas{width:56px;height:56px}.ptrva b{font:400 24px 'Pirata One',Georgia,serif;color:#9fffb0}.ptrva p{margin:0;font:500 14px var(--ui);color:var(--ink);max-width:380px}
.arsp{all:unset;cursor:pointer;box-sizing:border-box;position:relative;flex:0 0 74px!important;min-width:0}.arsp:hover{filter:brightness(1.12)}.arspb{position:absolute;top:4px;right:6px;width:18px;height:18px;border-radius:50%;background:#ff5c6c;color:#fff;font:800 12px/18px var(--ui);text-align:center;font-style:normal}
@media (max-width:1100px){.ptg{grid-template-columns:1fr 1fr}.ptdet{grid-column:span 2}.ptge,.ptgt{grid-template-columns:1fr}}
@media (max-width:820px){.ptg{grid-template-columns:1fr}.ptdet{grid-column:auto}.pthd{padding-right:110px}.pthd h2{font-size:40px}.ptpath{grid-template-columns:repeat(5,1fr)}.ptcu{grid-template-columns:1fr}.ptrvc{min-width:0}}
@media (prefers-reduced-motion:reduce){.pth *,.pthd{animation:none!important;transition:none!important}}
`;document.head.appendChild(st)}
