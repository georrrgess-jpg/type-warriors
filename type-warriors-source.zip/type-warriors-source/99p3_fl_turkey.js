/* ===== 10.4 HARVEST FESTIVAL: Thunderplume, the Harvest Turkey (99p3, after 99p2; prefix flp) =====
   The Mythic harvest companion, its Golden Harvest Egg, the harvest hatch cinematics for all three harvest companions, and its
   power, Grand Feast. Quality bar: the Mythic tier in 87i (Glacierhorn, Solmane, the Starforge cinematic).
   - Art: a great bronze turkey with a fanned tail of autumn feathers (rust, a dark band, a gold band and a pale tip, with a front row of
     bronze coverts), golden-edged feather scallops, a barred wing, a red snood and wattle, a chest beard and a woven harvest crown of
     wheat, an apple, cranberries and a corn cob. Idle: breathing, tail breathing, head bobs, now and then a full strut with a tail rattle
     and a soft gobble. Walk: a head-bobbing strut. Greet: a hop and a full fan. Ability: it gathers, rises with the fan blazing, then
     thrusts its head forward and gobbles; rings and feathers burst from it. Bond 3: a cranberry garland; Bond 5: Royal Palm (white
     and black); Bond 7: a feast of falling leaves, pies and drumsticks; Bond 10: Thunderking (gold lightning crackles between the tail
     tips, a golden crown, storm-gold motes).
   - Grand Feast: see the battle section below. */
Object.assign(PDEF,{
 flturkey:{n:FL.petN.flturkey,t:'the Harvest Turkey',r:'m',fam:'Harvest',fl:1,box:[-80,-128,142,130],ab:{k:'grandfeast',n:'Grand Feast',N:25,d:'Every 25 correct words, gobble like thunder: stun every monster on screen for 3 seconds, heal 1 heart and feast: words score 50% more for 6 seconds.',x:'At full health you gain a shield instead of a heart. A typo costs a word of charge. A boss only loses the attack it was winding up.'},
  bio:'A great turkey crowned with woven wheat. When it fans its tail the whole field goes quiet, and when it gobbles, the sky answers with thunder.',cos:{acc:'Cranberry garland',pal:'Royal Palm',cel:'Harvest feast',sig:'Thunderking'},greet:'fans its tail and gobbles'}});
if(!PIDS.includes('flturkey'))PIDS.push('flturkey');
const FLT_CH={v:0};/* live Grand Feast charge (0..1), set while the turkey is drawn in battle, so its tail tips glow as it charges */

/* ---------- palettes ---------- */
Object.assign(PCOL,{
 flturkey:[{b:'#8a4a26',t2:'#ff9a3a',t1:'#c8461c',b2:'#b8692e',bd:'#4a2210',sc:'#ffcf7a',t3:'#ffd860',t4:'#3a1a10',tw:'#fff4dc',cv:'#9a5a2a',cvd:'#5a2e14',hd:'#c47a46',hdd:'#8a4a26',fc:'#fff0dc',bk:'#ffb42a',bkd:'#c8701a',wt:'#e8323c',wt2:'#ff7272',wtd:'#9a1424',lg:'#ff9a3a',lgd:'#c8641a',ey:'#c86a1a',cr:'#f0c060',cr2:'#ffe8a0',crd:'#a8762a',sh:'#2a0e06',wg:'#7a3e1e',wgb:'#f4ead8',ir:'#5ad0a0'},
           {b:'#ece8e4',t2:'#ffffff',t1:'#d8d4de',b2:'#ffffff',bd:'#a29aae',sc:'#2a2430',t3:'#c8d6ea',t4:'#1e1a26',tw:'#ffffff',cv:'#e2dee8',cvd:'#8a8498',hd:'#e8e0e4',hdd:'#aaa0b0',fc:'#ffffff',bk:'#ffc23a',bkd:'#c8801a',wt:'#e8323c',wt2:'#ff7272',wtd:'#9a1424',lg:'#ffb4a0',lgd:'#c87a6a',ey:'#3a6ad8',cr:'#f0c060',cr2:'#ffe8a0',crd:'#a8762a',sh:'#2a2440',wg:'#d8d2de',wgb:'#2a2430',ir:'#9ab8ff'}]});

/* ---------- shapes ---------- */
/* one tail feather from the fan centre outward (local +y is outward); R = length, w = half width */
function fltFeather(g,R,w,C,glo,alt){g.beginPath();g.moveTo(-w*.45,R*.12);g.bezierCurveTo(-w*1.05,R*.45,-w*1.1,R*.88,0,R);g.bezierCurveTo(w*1.1,R*.88,w*1.05,R*.45,w*.45,R*.12);g.closePath();
 const q=g.createLinearGradient(0,R*.12,0,R);q.addColorStop(0,alt?C.t1:C.cvd);q.addColorStop(.35,alt?C.t2:C.t1);q.addColorStop(.62,alt?C.t1:C.t2);q.addColorStop(.66,C.t4);q.addColorStop(.75,C.t4);q.addColorStop(.765,C.t3);q.addColorStop(.88,C.t3);q.addColorStop(.895,C.tw);q.addColorStop(1,C.tw);g.fillStyle=q;g.fill();
 g.lineWidth=2;g.strokeStyle=PTO;g.stroke();
 if(glo>0){g.save();g.globalCompositeOperation='lighter';g.beginPath();g.ellipse(0,R*.82,w*.8,R*.08,0,0,TAU);g.fillStyle=ptHexA('#ffd45a',.55*glo);g.fill();g.restore()}
 g.beginPath();g.moveTo(0,R*.16);g.lineTo(0,R*.9);g.strokeStyle=ptHexA('#fff4dc',.45);g.lineWidth=1;g.stroke()}
/* the fan draws thirteen feathers and eleven coverts every frame: each is painted once per palette into a 4x sprite and placed */
const FLT_FS={};function fltFSpr(C,alt,cov){const k=C.t1+C.t2+C.cv+(alt?1:0)+(cov?'c':'');if(FLT_FS[k])return FLT_FS[k];const v=document.createElement('canvas');v.width=104;v.height=336;const x=v.getContext('2d');x.lineJoin='round';x.lineCap='round';x.scale(4,4);x.translate(13,2);
 if(cov){const rr=80;x.beginPath();x.moveTo(-5,rr*.1);x.bezierCurveTo(-8.5,rr*.5,-7,rr*.92,0,rr);x.bezierCurveTo(7,rr*.92,8.5,rr*.5,5,rr*.1);x.closePath();pF(x,pLin(x,0,0,0,rr,[C.cvd,C.cv,C.b2]),1.8);x.beginPath();x.moveTo(-6.4,rr*.78);x.bezierCurveTo(-5,rr*.97,5,rr*.97,6.4,rr*.78);x.strokeStyle=ptHexA(C.sc,.85);x.lineWidth=1.6;x.stroke()}
 else fltFeather(x,80,7.6,C,0,alt);return FLT_FS[k]=v}
function fltFeatherD(g,rr,C,glo,alt,cov){const k=rr/80;g.save();g.scale(k,k);g.drawImage(fltFSpr(C,alt,cov),-13,-2,26,84);g.restore();
 if(glo>0&&!cov){g.save();g.globalCompositeOperation='lighter';g.beginPath();g.ellipse(0,rr*.82,7.6*.8*k,rr*.08,0,0,TAU);g.fillStyle=ptHexA('#ffd45a',.55*glo);g.fill();g.restore()}}
/* a stalk of wheat: (x,y) base, angle a (0 = up) */
function fltWheat(g,x,y,len,a,c1,c2){g.save();g.translate(x,y);g.rotate(a);g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(1,-len*.5,0,-len);g.strokeStyle=PTO;g.lineWidth=2.6;g.stroke();g.strokeStyle=c1;g.lineWidth=1.2;g.stroke();
 g.beginPath();for(let i=0;i<5;i++){const y2=-len*.55-i*len*.1;for(const s of[-1,1]){g.moveTo(s*1.8+Math.cos(s*.45)*1.7,y2+Math.sin(s*.45)*1.7);g.ellipse(s*1.8,y2,1.7,3.2,s*.45,0,TAU)}}g.moveTo(1.6,-len*1.04);g.ellipse(0,-len*1.04,1.6,3,0,0,TAU);g.fillStyle=c2;g.fill();g.lineWidth=.8;g.strokeStyle=PTO;g.stroke();g.restore()}
/* a lightning zig-zag from a to b */
function fltBolt(g,x0,y0,x1,y1,seed,col,w){const n=6,dx=x1-x0,dy=y1-y0,L=Math.hypot(dx,dy)||1,nx=-dy/L,ny=dx/L;g.beginPath();g.moveTo(x0,y0);for(let i=1;i<n;i++){const k=i/n,j=(Math.sin(seed*12.9+i*78.2)*43758.5%1)*2-1;g.lineTo(x0+dx*k+nx*j*L*.12,y0+dy*k+ny*j*L*.12)}g.lineTo(x1,y1);
 g.save();g.globalCompositeOperation='lighter';g.strokeStyle=ptHexA(col,.45);g.lineWidth=(w||2)*3;g.stroke();g.strokeStyle='#fffbe0';g.lineWidth=w||2;g.stroke();g.restore()}

/* ======================================================================
   THUNDERPLUME: the Harvest Turkey
   ====================================================================== */
PRIG.flturkey=(g,o,C)=>{const t=o.t,P=o.pose,u=o.u,walk=P==='walk',ab=P==='ability',gr=P==='greet',trim=o.trim;
 const ch=Math.max(FLT_CH.v||0,o.charge||0);
 /* ----- motion ----- */
 let by=0,sx=1,sy=1,fo=.72+.04*Math.sin(t*1.3),fanR=0,fanJ=0,wing=0,hx=0,hy=0,ha=Math.sin(t*.9)*.03,mouth=0,wob=0,happy=false,eyeO=pBlink(t,5),lx=.4,glow=0,puff=0,step=0;
 const br=Math.sin(t*2)*.014;sy+=br;sx-=br*.5;
 if(walk){const st=t*7;step=st;by=-Math.abs(Math.sin(st))*2.6;hx=Math.sin(st*2)*3.4;fo=.55+.03*Math.sin(st);fanR=Math.sin(st)*.04;wob=Math.sin(st*2)*.3}
 else if(P==='idle'){const ph=(t%8.8+8.8)%8.8;
  /* a quick look around and a head bob */if(ph>1.2&&ph<1.5){const k=(ph-1.2)/.3;hx=Math.sin(k*Math.PI)*4;hy=Math.sin(k*Math.PI)*1.5}if(ph>3.2&&ph<4.2)lx=-.6;
  /* now and then a full strut: puff, fan, rattle, a soft gobble */if(ph>5.4&&ph<7.6){const k=(ph-5.4)/2.2,e=Math.sin(Math.min(1,k*1.15)*Math.PI);puff=e;fo+=e*.3;wing=e;hx-=e*3;hy+=e*1;
   if(k>.35&&k<.6){fanJ=Math.sin(t*46)*.025*e;wob=Math.sin(t*30)*.6}if(k>.62&&k<.78){mouth=Math.sin((k-.62)/.16*Math.PI)*.7;wob=Math.sin(t*26);hx+=Math.sin((k-.62)/.16*Math.PI*3)*2}}}
 if(gr){const hop=u<.3?Math.sin(u/.3*Math.PI):0;by=-hop*12;if(u<.04||(u>.28&&u<.34)){sy*=.92;sx*=1.06}happy=u>.1&&u<.9;const e=pSeg(u,.1,.35)*(1-pSeg(u,.82,1));fo=.72+e*.36;wing=e;puff=e*.6;wob=Math.sin(u*30)*e*.7;glow=e*.4;fanJ=Math.sin(u*60)*.02*e}
 if(ab){const gat=pSeg(u,0,.22)*(1-pSeg(u,.22,.32)),rise=pSeg(u,.22,.42),gob=pSeg(u,.42,.5)*(1-pSeg(u,.78,.92)),set=pSeg(u,.8,1);
  fo=.72-gat*.38+rise*.5*(1-set*.9);sy*=1-gat*.08+rise*.05*(1-set);sx*=1+gat*.06-rise*.02;by=-rise*6*(1-set);puff=rise*(1-set);wing=Math.max(rise,gob)*(1-set);glow=Math.max(rise*.8,gob)*(1-set*.8);
  hx=-gat*4+gob*7;hy=gat*5-gob*3;ha=-gob*.22+gat*.15;mouth=gob;wob=gob?Math.sin(t*32):0;eyeO=gat>.5?.35:eyeO;fanJ=gob*Math.sin(t*50)*.03}
 g.save();g.translate(0,by);g.scale(sx,sy);
 /* ----- the tail fan, behind everything ----- */
 const TC=[-12,-61],R=(54+fo*18)*(trim?1.06:1),spread=.42+fo*.58,N=13,a0=-Math.PI/2,half=spread*Math.PI*.52;
 g.save();g.translate(TC[0],TC[1]);g.rotate(-.18+fanR+fanJ);
 if(glow>0||trim||ch>0){pGlow(g,0,-R*.5,R*1.25,trim?'#ffd45a':'#ffb03a',.16+glow*.3+(trim?.16:0)+ch*.2)}
 if(trim){/* Thunderking: a storm-gold halo of light rays behind the fan */g.save();g.globalCompositeOperation='lighter';g.rotate(-t*.15);for(let i=0;i<18;i++){g.rotate(TAU/36);const L=R*1.25+Math.sin(t*3+i*1.7)*8;g.beginPath();g.moveTo(-2,-R*.6);g.lineTo(0,-L);g.lineTo(2,-R*.6);g.closePath();g.fillStyle=ptHexA('#ffe27a',.28);g.fill()}g.restore()}
 const tipG=Math.min(1,ch*1.1+glow*.4+(trim?.3:0)),tips=[];
 for(let i=0;i<N;i++){const k=i/(N-1),a=Math.PI+(k*2-1)*half;/* rotate so +y points outward */const rr=R*(1-Math.abs(k-.5)*.18);g.save();g.rotate(a);fltFeatherD(g,rr,C,tipG,i%2);g.restore();tips.push([-Math.sin(a)*rr*.94,Math.cos(a)*rr*.94])}
 if(trim){/* gold lightning crackles between the tips */const s=Math.floor(t*7);for(let j=0;j<2;j++){const i=(s*5+j*6)%(N-1);if((s+j)%3===0)continue;fltBolt(g,tips[i][0],tips[i][1],tips[i+1][0],tips[i+1][1],s+j,'#ffd45a',1.6)}}
 /* front row of bronze coverts with golden edges */for(let i=0;i<11;i++){const k=i/10,a=Math.PI+(k*2-1)*half*.92,rr=R*.6;g.save();g.rotate(a);g.scale(1.9,1);fltFeatherD(g,rr,C,0,0,1);g.restore()}
 g.restore();
 /* ----- legs and feet ----- */
 const leg=(x,ph,far)=>{const sw=walk?Math.sin(step+ph):0,lift=walk?Math.max(0,Math.sin(step+ph+Math.PI/2))*4:0,fx=x+sw*6;g.save();g.translate(0,-lift);
  pLimb(g,x,-22,fx,-4,3.6,3,far?C.lgd:C.lg);g.translate(fx,-3.5);g.strokeStyle=PTO;g.lineCap='round';for(const [dx,dy] of[[8,1.5],[6,4],[-5,2.5]]){g.beginPath();g.moveTo(0,0);g.lineTo(dx,dy);g.lineWidth=4.6;g.strokeStyle=PTO;g.stroke();g.lineWidth=2.4;g.strokeStyle=far?C.lgd:C.lg;g.stroke()}g.restore()};
 leg(-6,Math.PI,1);leg(10,0,0);
 /* ----- body ----- */
 const bs=1+puff*.06;g.save();g.translate(4,-44);g.scale(bs,bs);g.translate(-4,44);
 const body=(ox,oy)=>pmFluff(g,4+ox,-44+oy,30,28,18,.05,.2);g.beginPath();body(0,0);pF(g,pRad(g,-6,-56,38,[C.b2,C.b,C.bd]),2.8);
 /* golden-edged feather scallops over the breast and flank */g.save();g.beginPath();body(0,0);g.clip();
 for(let r=0;r<6;r++){const y=-66+r*8.6,off=(r%2)*4.6;g.beginPath();for(let x=-28+off;x<40;x+=9.2){g.moveTo(x+4.8*Math.cos(.15),y+4.8*Math.sin(.15));g.arc(x,y,4.8,.15,Math.PI-.15)}g.strokeStyle=ptHexA(C.sc,.55-r*.04);g.lineWidth=1.5;g.stroke();
  g.beginPath();for(let x=-28+off;x<40;x+=9.2){g.moveTo(x+4.2*Math.cos(.3),y+.6+4.2*Math.sin(.3));g.arc(x,y+.6,4.2,.3,Math.PI-.3)}g.strokeStyle=ptHexA(C.bd,.35);g.lineWidth=1;g.stroke()}
 /* an iridescent sheen across the shoulder */g.globalCompositeOperation='lighter';pGlow(g,-6,-62,26,C.ir,.16);pGlow(g,16,-56,18,C.sc,.12);g.restore();
 pmShade(g,body,-6,-5,ptHexA(C.sh,.22));g.beginPath();g.ellipse(2,-44,26,24,0,Math.PI*1.08,Math.PI*1.42);g.strokeStyle='#ffffff40';g.lineWidth=2.4;g.stroke();
 /* the beard: a tuft of dark bristles on the chest */g.strokeStyle=PTO;g.lineWidth=1.8;for(let i=0;i<3;i++){g.beginPath();g.moveTo(25+i*1.2,-59);g.quadraticCurveTo(26+i+Math.sin(t*2+i)*.6,-55,25+i*1.4,-50.5+i%2*1.2);g.stroke()}
 if(o.acc){/* Cranberry garland: a string of cranberries and leaves draped round the neck */g.beginPath();g.moveTo(4,-66);g.quadraticCurveTo(16,-56,30,-66);g.strokeStyle='#6a3a1a';g.lineWidth=1.4;g.stroke();
  for(let i=0;i<9;i++){const k=i/8,m=1-k,x=m*m*4+2*m*k*16+k*k*30,y=m*m*-66+2*m*k*-56+k*k*-66;if(i%3===1)pLeaf(g,x,y,7,2.8,1.2+i*.3,'#8ad04a','#3a8a2a',1);else{pC(g,x,y+1.6,2.6);pF(g,pRad(g,x,y+1.6,3,['#ff8a9a','#d01a3a','#7a0a1a']),1);pC(g,x-.8,y+.8,.8);g.fillStyle='#ffffffcc';g.fill()}}}
 /* ----- the wing, barred like a real turkey's; it droops when it struts ----- */
 g.save();g.translate(-2,-58);g.rotate(.12+wing*.32);g.translate(0,wing*4);
 const wp=(ox,oy)=>{g.moveTo(4+ox,0+oy);g.bezierCurveTo(-8+ox,-4+oy,-24+ox,6+oy,-26+ox,22+oy);g.bezierCurveTo(-18+ox,28+oy,-4+ox,26+oy,8+ox,14+oy);g.closePath()};
 /* barred flight feathers peek out along the trailing edge */for(let i=0;i<4;i++){const k=i/3,x=-24+k*24,y=24-k*8;g.save();g.translate(x,y);g.rotate(.95-k*.25);g.beginPath();g.ellipse(0,4,4.2,9.5,0,0,TAU);pF(g,pLin(g,0,-5,0,14,[C.wg,C.bd]),1.8);
  g.beginPath();g.ellipse(0,4,4.2,9.5,0,0,TAU);g.save();g.clip();g.strokeStyle=ptHexA(C.wgb,.75);g.lineWidth=1.5;for(const yy of[3,7.4,11.6]){g.beginPath();g.moveTo(-5,yy);g.lineTo(5,yy-1.4);g.stroke()}g.restore();g.restore()}
 g.beginPath();wp(0,0);pF(g,pLin(g,0,0,-20,26,[C.b2,C.wg,C.bd]),2.4);
 /* covert scallops with golden edges */g.save();g.beginPath();wp(0,0);g.clip();g.beginPath();for(let r=0;r<3;r++)for(let k=0;k<4;k++){const x=-18+k*7+r*2.4,y=6+r*6.4+k*-1.6+(k%2)*1.2;g.moveTo(x+4.6*Math.cos(.2),y+4.6*Math.sin(.2));g.arc(x,y,4.6,.2,Math.PI-.2)}g.strokeStyle=ptHexA(C.sc,.6);g.lineWidth=1.4;g.stroke();g.restore();
 g.beginPath();g.moveTo(0,4);g.bezierCurveTo(-10,2,-20,10,-22,20);g.strokeStyle=ptHexA(C.sc,.6);g.lineWidth=1.6;g.stroke();g.restore();
 g.restore();
 /* ----- neck and head ----- */
 g.save();g.translate(hx,hy);g.translate(22,-78);g.rotate(ha);g.translate(-22,78);
 g.beginPath();pmTubePath(g,[12,-62, 14,-70, 18,-78, 22,-86],16,13);pF(g,pLin(g,0,-62,0,-88,[C.b,C.hd]),2.4);
 g.translate(25,-88);g.scale(1.12,1.12);g.translate(-25,88);
 /* wattle: wobbly red lobes under the chin */g.save();g.translate(30,-82);g.rotate(Math.sin(t*3)*.05+wob*.12);g.beginPath();pmFluff(g,0,6,4.6,8,6,.22,.6);pF(g,pLin(g,0,-2,0,14,[C.wt2,C.wt,C.wtd]),2);g.restore();
 const head=(ox,oy)=>{g.ellipse(25+ox,-90+oy,12.5,12,0,0,TAU)};g.beginPath();head(0,0);pF(g,pRad(g,20,-96,15,[C.hd,C.hd,C.hdd]),2.4);pmShade(g,head,-3,-3,ptHexA(C.sh,.18));
 g.beginPath();g.ellipse(29.5,-91.5,7.6,7.2,0,0,TAU);g.fillStyle=C.fc;g.fill();
 pmEye(g,29.5,-92,5,C.ey,eyeO,happy,lx,0,trim?'#ffd45a':null);
 /* beak (the lower half swings open for a gobble) and the snood draped over it */
 g.save();g.translate(34,-88);g.rotate(mouth*.4);g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(5,1,8,2.4);g.quadraticCurveTo(4,4,0,3.4);g.closePath();pF(g,C.bkd,1.6);g.restore();
 if(mouth>.1){g.beginPath();g.moveTo(34.6,-88.4);g.lineTo(40,-87.4+mouth*2);g.lineTo(35,-86);g.closePath();g.fillStyle='#7a1a2a';g.fill()}
 g.beginPath();g.moveTo(33,-93.6);g.quadraticCurveTo(40,-93,44,-88.2);g.quadraticCurveTo(38.6,-88.4,33.4,-87.6);g.closePath();pF(g,pLin(g,0,-94,0,-87,[C.bk,C.bkd]),1.8);
 g.save();g.translate(34.4,-95.4);g.rotate(.25+Math.sin(t*2.6)*.08+wob*.18);g.beginPath();pmTubePath(g,[0,0, 3,1, 5,5, 4.4,12],3.6,4.6);pF(g,pLin(g,0,0,0,12,[C.wt2,C.wt]),1.6);g.restore();
 pE(g,24.6,-86,3.4,2);g.fillStyle=ptHexA('#ff7a8a',.4);g.fill();
 /* ----- the woven harvest crown: braided straw, wheat ears, an apple, cranberries and a corn cob ----- */
 const gold=trim,c1=gold?'#ffd45a':C.cr,c2=gold?'#fff6c0':C.cr2,cd=gold?'#b8801a':C.crd;
 for(const [x,a,l] of[[19,-.42,13],[24.5,0,16],[30,.42,13]])fltWheat(g,x,-101,l,a,cd,gold?'#fff2a0':'#ffd860');
 g.beginPath();g.ellipse(24.5,-99.4,12.6,4.4,-.05,0,TAU);g.strokeStyle=PTO;g.lineWidth=6.4;g.stroke();g.strokeStyle=c1;g.lineWidth=4;g.stroke();
 for(const o of[0,1]){g.beginPath();for(let i=o;i<10;i+=2){const a=Math.PI*.05+i*Math.PI*.1,x=24.5+Math.cos(a)*12.6,y=-99.4+Math.sin(a)*4.4;g.moveTo(x-2.2,y-1.6);g.lineTo(x+1.4,y+1.8)}g.strokeStyle=o?c2:cd;g.lineWidth=1.4;g.stroke()}
 /* corn cob */g.save();g.translate(16.6,-102);g.rotate(-.7);g.beginPath();g.ellipse(0,0,2.8,5.6,0,0,TAU);pF(g,'#ffd23a',1.4);for(let i=-1;i<=1;i++){g.beginPath();g.moveTo(-2.4,i*2.6);g.lineTo(2.4,i*2.6);g.strokeStyle='#c8901a';g.lineWidth=.7;g.stroke()}pLeaf(g,0,4,9,2.6,1.2,'#d8e88a','#7a9a3a',1);g.restore();
 /* apple */pC(g,30.6,-102.6,3.8);pF(g,pRad(g,30.6,-102.6,4,['#ff8a8a','#e8323c','#8a0a1a']),1.6);g.beginPath();g.moveTo(30.6,-106);g.lineTo(31.4,-108.6);g.strokeStyle=PTO;g.lineWidth=1.2;g.stroke();pLeaf(g,31.2,-107.6,5,2,-.4,'#8ad04a','#3a8a2a',.9);pC(g,29.4,-103.8,1);g.fillStyle='#ffffffaa';g.fill();
 /* cranberries */for(const [x,y] of[[24.6,-97],[26.6,-96.6],[22.6,-96.8]]){pC(g,x,y,1.6);pF(g,'#c8183a',.9)}
 if(gold){/* Thunderking: a storm gem on the crown */const pu=.6+.4*Math.sin(t*3);pGlow(g,24.5,-104,12,'#ffd45a',.5*pu);pP(g,[24.5,-109,28,-104,24.5,-99.5,21,-104]);pF(g,pLin(g,0,-109,0,-99,['#fffbe0','#ffb42a','#c8641a']),1.4)}
 g.restore();
 g.restore();
 /* ----- the gobble: thunder rings and a burst of feathers and leaves from the beak ----- */
 if(ab&&u>.42){const v=pSeg(u,.42,.95),bx=44+hx,byk=-90+hy;g.save();g.globalCompositeOperation='lighter';
  for(let i=0;i<3;i++){const k=Math.max(0,Math.min(1,v*1.4-i*.16));if(k<=0||k>=1)continue;g.beginPath();g.arc(bx+k*80,byk+k*10,12+k*50,-1.1,1.1);g.strokeStyle=ptHexA('#ffd45a',(1-k)*.85);g.lineWidth=8*(1-k)+2;g.stroke();g.strokeStyle=ptHexA('#ffffff',(1-k)*.7);g.lineWidth=2;g.stroke()}g.restore();
  for(let i=0;i<9;i++){const k=Math.max(0,Math.min(1,v*1.3-i*.03));if(k<=0||k>=1)continue;const an=-1.1+i*.27,d=20+k*110,x=-12+Math.cos(an-Math.PI/2)*d*.4+k*90,y=-60+Math.sin(an-Math.PI/2)*d*.7+k*k*60;g.save();g.globalAlpha=1-k;g.translate(x,y);g.rotate(an+k*6);
   if(i%3===0)flpMaple(g,0,0,10,0,'#ffe27a','#e8541a',1.2,0,1);else{g.beginPath();g.ellipse(0,0,2.6,8,0,0,TAU);pF(g,pLin(g,0,-8,0,8,[C.tw,C.t2,C.t1]),1.2)}g.restore()}}
 if(gr&&u>.12&&u<.9){for(let i=0;i<6;i++){const v=(u*1.4+i/6)%1;g.globalAlpha=Math.sin(v*Math.PI);pStar4(g,-40+i*16+Math.sin(i*2+u*7)*5,-122-v*22,2.4+i%2,i%2?'#ffe2a0':'#ffffff');g.globalAlpha=1}}
 g.restore()};

/* ---------- Signature motes, the victory feast, the power icon ---------- */
Object.assign(PSIG,{flturkey:['#ffb42a','feather']});
Object.assign(PCEL,{flturkey:'feast'});
function fltFood(g,k,x,y,s,a){g.save();g.translate(x,y);g.rotate(a||0);g.scale(s/20,s/20);
 if(k===0){/* drumstick */g.beginPath();g.moveTo(-2,4);g.lineTo(-9,11);g.strokeStyle=PTO;g.lineWidth=5.4;g.stroke();g.strokeStyle='#fff4dc';g.lineWidth=3;g.stroke();for(const [dx,dy] of[[-10.6,9.4],[-7.4,12.6]]){pC(g,dx,dy,2.2);pF(g,'#fff4dc',1.2)}
  g.beginPath();g.ellipse(3,-3,9,7,-.7,0,TAU);pF(g,pRad(g,1,-5,10,['#ffc46a','#c8641a','#7a3a10']),2);pE(g,1,-6,3,1.6,-.7);g.fillStyle='#ffffff66';g.fill()}
 else if(k===1){/* pie slice */g.beginPath();g.moveTo(-10,6);g.lineTo(10,6);g.lineTo(0,-10);g.closePath();pF(g,pLin(g,0,-10,0,6,['#ffb45a','#e07a2a']),2);g.beginPath();g.moveTo(-10,6);g.lineTo(10,6);g.lineTo(9,2.4);g.lineTo(-9,2.4);g.closePath();pF(g,'#f2c48a',1.6);for(const x of[-5,0,5]){pC(g,x,3.8,1);g.fillStyle='#c8864a';g.fill()}pE(g,0,-2,3,1.6);g.fillStyle='#fff8e8';g.fill()}
 else if(k===2){/* corn cob */g.beginPath();g.ellipse(0,0,5,10,0,0,TAU);pF(g,pLin(g,-5,0,5,0,['#fff07a','#ffd23a','#c8901a']),2);for(let i=-2;i<=2;i++){g.beginPath();g.moveTo(-4.4,i*3.4);g.lineTo(4.4,i*3.4);g.strokeStyle='#c8901a';g.lineWidth=.8;g.stroke()}pLeaf(g,0,8,12,3.4,1.9,'#d8e88a','#7a9a3a',1.2);pLeaf(g,0,8,12,3.4,1.2,'#d8e88a','#7a9a3a',1.2)}
 else if(k===3){/* apple */pC(g,0,1,8);pF(g,pRad(g,0,1,8,['#ff9a9a','#e8323c','#8a0a1a']),2);g.beginPath();g.moveTo(0,-6);g.lineTo(1.4,-11);g.strokeStyle=PTO;g.lineWidth=2;g.stroke();pLeaf(g,1.4,-10,8,3,-.4,'#8ad04a','#3a8a2a',1.2);pE(g,-3,-2,2,3,-.4);g.fillStyle='#ffffff88';g.fill()}
 else{/* little pumpkin */for(const [dx,rx] of[[-4.6,4.6],[4.6,4.6],[0,5.4]]){pE(g,dx,1,rx,7);pF(g,pLin(g,0,-6,0,8,['#ffb45a','#ff7a1a','#c8481a']),1.8)}g.beginPath();g.moveTo(0,-5);g.quadraticCurveTo(1,-9,3.4,-10);g.strokeStyle=PTO;g.lineWidth=3;g.stroke();g.strokeStyle='#6a8a2a';g.lineWidth=1.6;g.stroke()}
 g.restore()}
/* cached sprites of the five foods and a falling feather (bursts and battle draw many of them a frame) */
const FLT_SPR={};function fltSpr(k){if(FLT_SPR[k])return FLT_SPR[k];const c=document.createElement('canvas');c.width=c.height=64;const x=c.getContext('2d');x.lineJoin='round';x.lineCap='round';
 if(k==='fe'){x.translate(32,32);x.beginPath();x.ellipse(0,0,7,26,0,0,TAU);pF(x,pLin(x,0,-26,0,26,['#fff4dc','#ffd860','#3a1a10','#ff9a3a','#c8461c']),2.4)}else fltFood(x,+k,32,32,48,0);return FLT_SPR[k]=c}
function fltFoodD(g,k,x,y,s,a){const c=fltSpr(k),q=s/48;g.save();g.translate(x,y);g.rotate(a||0);g.scale(q,q);g.drawImage(c,-32,-32);g.restore()}
{const a0=petAura;petAura=function(g,id,t,front){const r=a0.apply(this,arguments);if(id!=='flturkey')return r;try{const bx=PDEF[id].box;
 for(let i=0;i<8;i++){if((i%2===0)!==front)continue;const sd=i*1.618,v=((t*(.11+(i%3)*.03)+sd)%1+1)%1,lane=((i*.37+.11)%1),a=Math.sin(v*Math.PI);if(a<.04)continue;
  const x=bx[0]-6+lane*(bx[2]+12)+Math.sin(t*1.1+sd*3)*10,y=bx[1]-6+v*(bx[3]+8);g.save();g.globalAlpha=a;pGlow(g,x,y,11,'#ffd45a',.5);
  if(i%3===2)pStar4(g,x,y,4,'#fffbe0');else{g.translate(x,y);g.rotate(Math.sin(t*2+sd)*.8);g.beginPath();g.ellipse(0,0,2.6,8,0,0,TAU);pF(g,pLin(g,0,-8,0,8,['#fff6c0','#ffb42a','#c8461c']),1)}g.restore()}}catch(e){}return r}}
{const c0=petCelFx;petCelFx=function(g,id,u,t,cy,R){if(PCEL[id]!=='feast')return c0.apply(this,arguments);if(u<=0||u>=1)return;cy=cy||-50;R=R||70;const a0=1-pSeg(u,.65,1);g.save();g.translate(0,cy);
 for(let i=0;i<14;i++){const an=i/14*TAU+i*.37,sp=.6+((i*53)%10)/14,r=R*(.25+pSeg(u,0,.6)*sp),x=Math.cos(an)*r,y=Math.sin(an)*r*.75+pSeg(u,.2,1)*R*.45;g.globalAlpha=Math.max(0,a0*(i%3?1:.8));
  if(i%2)fltFoodD(g,i%5,x,y,13,t*2+i);else flpLeafD(g,x,y,10,t*2+i,i%4)}
 g.globalAlpha=1;g.restore()}}
Object.assign(PICO,{grandfeast:g=>{pGlow(g,0,0,52,'#ffb42a',.42);const C=PCOL.flturkey[0];for(let i=0;i<7;i++){g.save();g.translate(0,8);g.rotate(-1.35+i*.45+Math.PI);fltFeather(g,40,6.4,C,0,i%2);g.restore()}
 g.beginPath();g.arc(0,10,18,Math.PI,0);g.closePath();pF(g,pLin(g,0,-8,0,10,['#c47a46','#8a4a26']),3);fltFood(g,0,4,18,30,-.3);fltBolt(g,26,-34,10,-6,3,'#ffd45a',2.4)}});

/* ======================================================================
   THE GOLDEN HARVEST EGG
   o = {t, glow, charge (0..1: the seams blaze before a hatch), lean, noSh}
   A warm gold shell painted with autumn leaves, a woven wicker band, a wheat-sheaf belt, a fan of three tail feathers on top
   around an acorn finial, and a drift of light across the shell.
   ====================================================================== */
const FLE_CR=[[-46,-62],[-34,-70],[-22,-58],[-10,-68],[0,-56],[12,-66],[24,-56],[36,-68],[46,-60]];
const FLE_BR=[[2,[-22,-58],[-26,-46],[-20,-36]],[5,[12,-66],[16,-80],[10,-92]],[7,[36,-68],[40,-82]],[4,[0,-56],[-4,-44]]];
function eggHarvest(g,o){const t=o.t||0,gl=o.glow||0,ch=o.charge||0,pu=.5+.5*Math.sin(t*1.8),W=46,H=124,C=PCOL.flturkey[0];
 pGlow(g,0,-64,76,'#ffb03a',.16+gl*.25+ch*.3);
 /* a fan of tail feathers behind the top */g.save();g.translate(0,-108);for(let i=0;i<7;i++){g.save();g.rotate(Math.PI+(i/6*2-1)*1.1);fltFeatherD(g,i%2?36:42,C,ch,i%2);g.restore()}g.restore();
 eggPath(g,W,H);pF(g,pLin(g,-30,-H,30,0,['#ffe9a0','#ffc23a','#e88a24','#8a3a10']),3.4);
 g.save();eggPath(g,W,H);g.clip();
 /* warm inner glow that breathes */pGlow(g,-10,-84,40,'#fff6c0',.14+.08*pu+gl*.3);
 /* painted autumn leaves */flpMaple(g,-24,-74,22,-.5,'#ff8a3a','#c8281a',0,'#ffd8a066',1);flpMaple(g,22,-92,18,.6,'#ffb43a','#e8541a',0,'#ffe0a066',1);flpMaple(g,26,-44,16,.3,'#e8401a','#8a1a1a',0,'#ffb08066',1);
 pLeaf(g,-30,-44,14,5,-2.6,'#e8541a','#9a2a14',0);
 /* tiny painted dots */for(let i=0;i<10;i++){const x=Math.sin(i*12.9)*36,y=-24-((i*.37)%1)*88;pC(g,x,y,1.3);g.fillStyle=i%2?'#fff6d0aa':'#c8461caa';g.fill()}
 /* the wicker band: two braided rows of straw */g.beginPath();g.moveTo(-60,-44);g.quadraticCurveTo(0,-30,60,-44);g.lineTo(60,-24);g.quadraticCurveTo(0,-10,-60,-24);g.closePath();pF(g,pLin(g,0,-44,0,-12,['#a8682a','#7a4418','#4a2410']),2.4);
 for(let r=0;r<2;r++)for(let i=-8;i<=8;i++){const x=i*7.4,yc=-37+r*9+Math.pow(x/60,2)*-10,d=(i+r)%2?1:-1;g.save();g.translate(x,yc);g.rotate(d*.62);g.beginPath();g.roundRect(-5.4,-2.3,10.8,4.6,2.3);g.fillStyle=d>0?'#f0c070':'#d49a4a';g.fill();g.lineWidth=1;g.strokeStyle='#3a1a08';g.stroke();g.fillStyle='#fff2c070';g.fillRect(-4,-1.6,8,1.2);g.restore()}
 /* the wheat-sheaf belt above it */g.beginPath();g.moveTo(-60,-50);g.quadraticCurveTo(0,-36,60,-50);g.strokeStyle=PTO;g.lineWidth=6.6;g.stroke();g.strokeStyle=pLin(g,-46,0,46,0,['#e0a020','#fff2b0','#ffd45a','#c8861a']);g.lineWidth=4;g.stroke();
 for(let i=-4;i<=4;i++){const x=i*9.6,y=-47.2+Math.pow(x/60,2)*-10;g.beginPath();g.ellipse(x,y,1.8,3,.6,0,TAU);g.fillStyle='#fff6c0';g.fill()}
 /* kintsugi-like seams that blaze before a hatch */if(ch>0){const crk=()=>{g.beginPath();g.moveTo(FLE_CR[0][0],FLE_CR[0][1]);for(const p of FLE_CR)g.lineTo(p[0],p[1]);for(const b of FLE_BR){const p=FLE_CR[b[0]];g.moveTo(p[0],p[1]);for(let j=1;j<b.length;j++)g.lineTo(b[j][0],b[j][1])}};
  g.save();g.globalCompositeOperation='lighter';crk();g.strokeStyle=ptHexA('#ffb03a',.3+ch*.6);g.lineWidth=8+ch*10;g.stroke();crk();g.strokeStyle=ptHexA('#fff2c0',.4+ch*.6);g.lineWidth=3+ch*3;g.stroke();g.restore();crk();g.strokeStyle='#fffbe8';g.lineWidth=1.2;g.stroke()}
 g.beginPath();g.ellipse(-17,-90,7,20,-.3,0,TAU);g.fillStyle='#ffffff66';g.fill();g.beginPath();g.ellipse(-12,-108,3,6,-.3,0,TAU);g.fillStyle='#ffffffaa';g.fill();
 g.restore();
 eggFinish(g,W,H,t,'#fff2c8','#ffffff38');
 /* a gold cap with a garnet, and a golden acorn floating above it */g.beginPath();g.moveTo(-15,-119);g.bezierCurveTo(-10,-127,10,-127,15,-119);g.bezierCurveTo(8,-115,-8,-115,-15,-119);g.closePath();pF(g,pLin(g,0,-127,0,-115,['#fff2b0','#ffd45a','#b8801a']),2);pC(g,0,-120,2.2);pF(g,'#d81a3a',1);
 const fy=-140+Math.sin(t*1.6)*2.2;pGlow(g,0,fy,20+gl*12+ch*16,'#ffd45a',.4+.2*pu+ch*.4);flpAcorn(g,0,fy-4,13,Math.sin(t*1.1)*.12,FLP_ACG,1.8);
 const tw=(t*.8)%3.2;if(tw<.5)pStar4(g,-18,-80,2+Math.sin(tw/.5*Math.PI)*5,'#ffffff');const tw2=((t+1.6)*.7)%3.6;if(tw2<.5)pStar4(g,20,-58,2+Math.sin(tw2/.5*Math.PI)*4,'#fffbe0')}
{const d0=eggDraw;eggDraw=function(g,kind,o){if(kind!=='h')return d0.apply(this,arguments);g.save();g.lineJoin='round';g.lineCap='round';o=o||{};
 if(!o.noSh){const q=g.createRadialGradient(0,2,0,0,2,52);q.addColorStop(0,'#00000080');q.addColorStop(1,'#00000000');g.fillStyle=q;g.beginPath();g.ellipse(0,2,50,10,0,0,TAU);g.fill()}
 g.rotate(o.lean||0);eggHarvest(g,o);g.restore()}}
{const f0=eggFit;eggFit=function(cv,kind,o){if(kind!=='h')return f0.apply(this,arguments);const q=Object.assign({},o||{});q.zoom=(q.zoom||1)*.86;return f0.call(this,cv,kind,q)}}
try{PT_EAC.h=[255,170,60]}catch(e){}
try{PEGGD.h={tag:'Laid under the harvest moon, warm as a hearth.',lore:'A festival treasure: hatches Thunderplume, the Harvest Turkey.'}}catch(e){}

/* ======================================================================
   THE EGGS TAB STAGE for the Golden Harvest Egg: a harvest arbor under the moon
   ====================================================================== */
const FLES={};
function flesBG(w,h){const k=w+'x'+h;if(FLES[k])return FLES[k];const c=document.createElement('canvas');c.width=w;c.height=h;const g=c.getContext('2d');let s=11;const r=()=>{s=(s*16807)%2147483647;return s/2147483647};
 let q=g.createLinearGradient(0,0,0,h);q.addColorStop(0,'#1a0e2c');q.addColorStop(1,'#0c0610');g.fillStyle=q;g.fillRect(0,0,w,h);
 /* an arched window onto a harvest night */const ax=w/2,ar=w*.36,ay=h*.36;g.save();g.beginPath();g.moveTo(ax-ar,h*.64);g.lineTo(ax-ar,ay);g.arc(ax,ay,ar,Math.PI,0);g.lineTo(ax+ar,h*.64);g.closePath();g.clip();
 q=g.createLinearGradient(0,ay-ar,0,h*.64);q.addColorStop(0,'#141030');q.addColorStop(.6,'#3a1a34');q.addColorStop(1,'#6a2a22');g.fillStyle=q;g.fillRect(0,0,w,h);
 for(let i=0;i<40;i++){g.fillStyle=`rgba(255,248,230,${.3+r()*.6})`;g.fillRect(ax-ar+r()*ar*2,ay-ar+r()*ar*.9,1.4,1.4)}
 const mx=ax+ar*.34,my=ay-ar*.3;pGlow(g,mx,my,120,'#ffb03a',.3);q=g.createRadialGradient(mx-10,my-12,4,mx,my,46);q.addColorStop(0,'#fff4cc');q.addColorStop(.6,'#ffc86a');q.addColorStop(1,'#e8862a');g.fillStyle=q;g.beginPath();g.arc(mx,my,46,0,TAU);g.fill();
 for(const [dx,dy,rr] of[[-14,-8,8],[10,10,6],[16,-14,4],[-6,16,5]]){g.fillStyle='#e8a05055';g.beginPath();g.arc(mx+dx,my+dy,rr,0,TAU);g.fill()}
 g.fillStyle='#1e0e1a';g.beginPath();g.moveTo(0,h*.6);for(let x=0;x<=w;x+=10)g.lineTo(x,h*.52-Math.sin(x*.012)*14-Math.sin(x*.031)*6);g.lineTo(w,h);g.lineTo(0,h);g.fill();
 g.fillStyle='#140810';for(let i=0;i<40;i++){const x=ax-ar+i*(ar*2/40)+r()*6,hh=34+r()*44,yb=h*.6;g.fillRect(x,yb-hh,2.4,hh);g.beginPath();g.moveTo(x+1,yb-hh*.6);g.quadraticCurveTo(x+12,yb-hh*.75,x+16,yb-hh*.55);g.lineTo(x+1,yb-hh*.5);g.fill();g.beginPath();g.moveTo(x+1,yb-hh*.35);g.quadraticCurveTo(x-10,yb-hh*.5,x-14,yb-hh*.3);g.lineTo(x+1,yb-hh*.28);g.fill()}
 g.restore();
 /* the wooden frame */g.lineWidth=14;g.strokeStyle='#4a2a16';g.beginPath();g.moveTo(ax-ar,h*.64);g.lineTo(ax-ar,ay);g.arc(ax,ay,ar,Math.PI,0);g.lineTo(ax+ar,h*.64);g.stroke();g.lineWidth=4;g.strokeStyle='#7a4a22';g.stroke();
 /* a leaf garland across the top */for(let i=0;i<=16;i++){const k=i/16,x=w*.06+k*w*.88,y=h*.08+Math.sin(k*Math.PI)*h*.06;flpMaple(g,x,y+8,16,(r()-.5)*1.4,['#ffe27a','#ff9a2a','#e8401a','#c8281a'][i%4],['#e8541a','#c8281a','#8a1a1a','#ff7a1a'][i%4],1.4,0,1)}
 /* wheat sheaves on both sides */for(const [x,sd] of[[w*.1,1],[w*.9,-1]])for(let i=0;i<9;i++)fltWheat(g,x+(i-4)*4,h*.64,70+r()*24,(i-4)*.07*sd,'#a8762a','#ffd860');
 /* floor and the hay-bale pedestal */const fy=h*.62;q=g.createLinearGradient(0,fy-40,0,h);q.addColorStop(0,'#2a1810');q.addColorStop(1,'#0e0806');g.fillStyle=q;g.fillRect(0,fy-26,w,h);
 for(const [rx,ry,dy,c0,c1] of[[w*.36,26,22,'#8a5a1e','#4a2a10'],[w*.3,20,0,'#d8a24a','#8a5a1e']]){q=g.createLinearGradient(0,fy+dy-ry,0,fy+dy+ry+18);q.addColorStop(0,c0);q.addColorStop(1,c1);g.fillStyle=q;g.beginPath();g.ellipse(ax,fy+dy+14,rx,ry,0,0,Math.PI);g.lineTo(ax-rx,fy+dy);g.ellipse(ax,fy+dy,rx,ry,0,Math.PI,0);g.closePath();g.fill();g.beginPath();g.ellipse(ax,fy+dy,rx,ry,0,0,TAU);g.fillStyle=c0;g.fill();g.strokeStyle='#3a1a08';g.lineWidth=2;g.stroke()}
 g.strokeStyle='#ffe0a066';g.lineWidth=1.2;for(let i=0;i<40;i++){const a=r()*TAU,d=r(),x=ax+Math.cos(a)*w*.28*d,y=fy+Math.sin(a)*18*d;g.beginPath();g.moveTo(x,y);g.lineTo(x+(r()-.5)*14,y+(r()-.5)*4);g.stroke()}
 /* pumpkins in the corners */const pk=(x,y,R)=>{for(const [dx,rx] of[[-R*.42,R*.5],[R*.42,R*.5],[0,R*.6]]){g.beginPath();g.ellipse(x+dx,y,rx,R*.82,0,0,TAU);g.fillStyle=pLin(g,0,y-R,0,y+R,['#ffb45a','#ff7a1a','#a8401a']);g.fill();g.lineWidth=2.4;g.strokeStyle='#3a1206';g.stroke()}
  g.beginPath();g.moveTo(x,y-R*.7);g.quadraticCurveTo(x+3,y-R*1.1,x+R*.3,y-R*1.2);g.lineWidth=6;g.strokeStyle='#3a1206';g.stroke();g.lineWidth=3;g.strokeStyle='#6a8a2a';g.stroke();g.beginPath();g.ellipse(x-R*.3,y-R*.3,R*.12,R*.3,-.3,0,TAU);g.fillStyle='#ffffff40';g.fill()};
 pk(w*.12,h*.72,34);pk(w*.25,h*.8,22);pk(w*.88,h*.72,38);pk(w*.76,h*.81,20);
 q=g.createRadialGradient(w/2,h*.55,h*.3,w/2,h*.55,w*.75);q.addColorStop(0,'#00000000');q.addColorStop(1,'#000000a0');g.fillStyle=q;g.fillRect(0,0,w,h);
 return FLES[k]=c}
function flpEggStage(cv){const w=520,h=560,k=PTK(),g=cv.getContext('2d'),bg=flesBG(w,h);cv.width=w*k;cv.height=h*k;const fr=PTX.eggFrom&&PTX.eggFrom!=='h'?PTX.eggFrom:null;PTX.eggFrom=null;
 const FX=[],R=[],TX=[];let tap=null,lt=ptNow(),spawn=0,pulse=0;const t0=ptNow(),ex0=w/2,ey0=h*.6-12,ES=1.3;
 const LV=Array.from({length:9},(_,i)=>({x:Math.random()*w,y:Math.random()*h,v:20+Math.random()*24,a:Math.random()*6,s:9+Math.random()*7,c:i%3}));
 cv.style.cursor='pointer';
 cv.onclick=e=>{const b=cv.getBoundingClientRect(),x=(e.clientX-b.left)*w/b.width,y=(e.clientY-b.top)*h/b.height;if(Math.abs(x-ex0)>90||y<ey0-ES*170||y>ey0+20)return;const rd=flpEggN()>0;tap={t:ptNow(),s:rd?1:.55};
  ptBurst(FX,ex0,ey0-90,rd?20:7,['#ffd45a','#ffffff','#ff9a2a'],{v:rd?220:130,g:120,l:.9,s:6});R.push({x:ex0,y:ey0+4,t:0,c:'#ffb43a',max:120,w:6,d:.7,fl:.24});
  const msg=rd?(petOwned('flturkey')?'Something sweet rattles inside!':['Something gobbled inside!','It feels warm as fresh bread!','A feather tickled your hand!','It wobbled to a drumbeat!'][Math.random()*4|0]):petOwned('flturkey')?'Thunderplume is already yours':'Buy one to hatch it';
  TX.length=0;TX.push({s:msg,x:ex0,y:ey0-ES*160+12,a:0,c:rd?'#fff2c0':'#e0c8a8',sz:rd?22:18,d:1.6});
  try{if(rd){fltGobbleSm()}else beep(300,.08,'triangle',.14)}catch(x){}};
 return t1=>{const rm=ptRM(),t=rm?1:t1,now=ptNow(),dt=Math.min(.05,Math.max(0,now-lt));lt=now;g.setTransform(k,0,0,k,0,0);g.drawImage(bg,0,0,w,h);const rd=flpEggN()>0;
  /* lanterns on the frame */for(const x of[w*.16,w*.84]){const f=.82+.18*Math.sin(t*7+x)+.08*Math.sin(t*13);pGlow(g,x,h*.3,80*f,'#ffb04a',.26);g.save();g.translate(x,h*.3);g.fillStyle='#2a1406';g.fillRect(-2,-40,4,18);g.beginPath();g.roundRect(-12,-22,24,30,5);g.fillStyle=ptHexA('#ffcf6a',.85+.15*f);g.fill();g.strokeStyle='#3a1a08';g.lineWidth=3;g.stroke();g.beginPath();g.moveTo(-14,-22);g.lineTo(0,-32);g.lineTo(14,-22);g.closePath();g.fillStyle='#3a1a08';g.fill();g.restore()}
  /* fireflies and falling leaves */if(!rm){for(let i=0;i<6;i++){const a=t*.4+i*1.7,x=w*(.2+.6*((i*.618)%1))+Math.sin(a)*20,y=h*(.4+.3*((i*.38)%1))+Math.cos(a*1.3)*12,al=Math.max(0,Math.sin(t*1.2+i));pGlow(g,x,y,8,'#ffe27a',.55*al)}
   for(const L of LV){L.y+=L.v*dt;L.x+=Math.sin(t*1.3+L.a)*14*dt;L.a+=dt*1.4;if(L.y>h+20){L.y=-20;L.x=Math.random()*w}g.globalAlpha=.85;flpLeafD(g,L.x,L.y,L.s,L.a,L.c);g.globalAlpha=1}}
  pGlow(g,w/2,h*.5,170,'#ffb43a',(rd?.32:.2)+.06*Math.sin(t*1.4));
  if(rd&&!rm){pulse+=dt;if(pulse>1.6){pulse=0;R.push({x:ex0,y:ey0+6,t:0,c:'#ffb43a',max:110,r0:30,w:4,d:1.3,fl:.22})}
   spawn+=dt*4;while(spawn>1){spawn--;const a=Math.random()*TAU,rr=40+Math.random()*30;FX.push({x:ex0+Math.cos(a)*rr,y:ey0-90+Math.sin(a)*rr*1.3,vx:(Math.random()-.5)*20,vy:-30-Math.random()*40,l:1.2,l0:1.2,c:Math.random()<.4?'#ffffff':'#ffd45a',s:3+Math.random()*3,k:Math.random()<.5?'star':'glow',g:-10,dr:.6})}}
  ptRings(g,R,dt);
  let L=0,hy=0;if(!rm){if(rd){const ph=t%3.4;if(ph<.9){const v=ph/.9;L+=Math.sin(v*Math.PI*4)*(1-v)*.1;hy=-Math.sin(Math.min(1,v*2.2)*Math.PI)*5}}if(tap){const v=(now-tap.t)/.9;if(v>=1)tap=null;else{L+=Math.sin(v*Math.PI*6)*(1-v)*.17*tap.s;hy-=Math.sin(Math.min(1,v*3)*Math.PI)*9*tap.s}}}
  const sw=fr&&!rm?Math.min(1,(now-t0)/.32):1;
  if(sw<1){g.save();g.globalAlpha=1-sw;g.translate(ex0,ey0);g.scale(ES,ES);eggDraw(g,fr,{t,glow:.2,noSh:1});g.restore()}
  const bob=rm?0:Math.sin(t*1.2)*3-4;g.save();g.globalAlpha=sw;g.translate(ex0,ey0+bob+hy+(1-pS(sw))*-24);g.scale(ES*.94,ES*.94);
  g.save();g.scale(1/(ES*.94),1/(ES*.94));g.fillStyle='#00000055';g.beginPath();g.ellipse(0,-hy+4,44,8,0,0,TAU);g.fill();g.restore();
  /* a wicker nest under the egg */g.save();g.translate(0,-2);g.beginPath();g.ellipse(0,0,56,13,0,0,Math.PI);g.lineTo(-56,-4);g.ellipse(0,-4,56,13,0,Math.PI,0,true);g.closePath();g.fillStyle=pLin(g,0,-14,0,14,['#c8863a','#7a4418']);g.fill();g.lineWidth=2;g.strokeStyle='#3a1a08';g.stroke();g.restore();
  eggDraw(g,'h',{t,glow:rd?.45+.3*Math.sin(t*2.4):.18+.1*Math.sin(t*1.6),lean:L,noSh:1});
  g.save();g.translate(0,-1);g.beginPath();g.ellipse(0,0,56,13,0,0,Math.PI);g.lineTo(52,-6);g.ellipse(0,-6,52,9,0,0,Math.PI);g.closePath();g.fillStyle=pLin(g,0,-6,0,13,['#e8b05a','#9a5a1e']);g.fill();g.lineWidth=2;g.strokeStyle='#3a1a08';g.stroke();
  for(let i=-5;i<=5;i++){g.beginPath();g.moveTo(i*9.4,-2+Math.abs(i)*.4);g.lineTo(i*9.4+4,10-Math.abs(i)*.6);g.strokeStyle='#5a2e10';g.lineWidth=1.2;g.stroke()}g.restore();
  g.restore();
  ptFxStep(g,FX,dt);ptTexts(g,TX,dt)}}

/* ======================================================================
   THE HARVEST HATCH: one moonlit ceremony, three ways
   Rare (a giant acorn, about 4.5 s), Legendary (a cocoon of maple leaves, about 5.6 s), Mythic (the Golden Harvest Egg, about 8 s).
   A harvest moon over a pumpkin patch and a corn field, a ring of pumpkin lanterns lighting one by one around a hay dais with a deep
   wooden chime, leaves on the wind, heartbeats, a burst, and the companion landing in the moonlight. For Thunderplume the moon turns
   gold and its feathered silhouette fans across it, the cornucopia spills and the sky answers its gobble with thunder.
   The result is committed (owned and saved) before this plays; Skip / Esc / Space end it at once. window.__flhT pins the time (tests).
   ====================================================================== */
const FLH={};
function flhBG(){if(FLH.bg)return FLH.bg;const W0=1600,H0=900,c=document.createElement('canvas');c.width=W0;c.height=H0;const b=c.getContext('2d'),cx=W0/2,fy=FLH_FY;let s=7;const r=()=>{s=(s*16807)%2147483647;return s/2147483647};
 let q=b.createLinearGradient(0,0,0,H0);q.addColorStop(0,'#0a0820');q.addColorStop(.42,'#22123a');q.addColorStop(.6,'#4a1e2a');q.addColorStop(.62,'#2a1018');q.addColorStop(1,'#0c0608');b.fillStyle=q;b.fillRect(0,0,W0,H0);
 for(let i=0;i<300;i++){const x=r()*W0,y=r()*fy*.85,rr=.5+r()*r()*1.8;b.fillStyle=`rgba(255,${240+r()*15|0},220,${.3+r()*.6})`;b.beginPath();b.arc(x,y,rr,0,TAU);b.fill()}
 /* the harvest moon */const mx=cx,my=FLH_MY,mr=150;b.globalCompositeOperation='lighter';for(const [rr,a] of[[520,.12],[340,.18],[230,.22]]){const g2=b.createRadialGradient(mx,my,0,mx,my,rr);g2.addColorStop(0,ptHexA('#ffb03a',a));g2.addColorStop(1,ptHexA('#ffb03a',0));b.fillStyle=g2;b.fillRect(mx-rr,my-rr,rr*2,rr*2)}b.globalCompositeOperation='source-over';
 q=b.createRadialGradient(mx-40,my-50,10,mx,my,mr);q.addColorStop(0,'#fff0cc');q.addColorStop(.55,'#f6c070');q.addColorStop(1,'#d6782e');b.fillStyle=q;b.beginPath();b.arc(mx,my,mr,0,TAU);b.fill();
 for(const [dx,dy,rr] of[[-50,-30,30],[40,40,22],[60,-60,14],[-20,70,18],[-80,40,12],[20,-10,10]]){b.fillStyle='#e8a05040';b.beginPath();b.arc(mx+dx,my+dy,rr,0,TAU);b.fill()}
 /* hills, a barn, a scarecrow and the corn field */b.fillStyle='#2a1426';b.beginPath();b.moveTo(0,fy-60);for(let x=0;x<=W0;x+=16)b.lineTo(x,fy-90-Math.sin(x*.004)*30-Math.sin(x*.011)*12);b.lineTo(W0,fy);b.lineTo(0,fy);b.fill();
 b.fillStyle='#180a16';b.fillRect(170,fy-150,120,90);b.beginPath();b.moveTo(160,fy-150);b.lineTo(230,fy-200);b.lineTo(300,fy-150);b.fill();b.fillStyle='#ffb04a';b.fillRect(214,fy-130,18,16);pGlow(b,223,fy-122,40,'#ffb04a',.3);
 b.strokeStyle='#160814';b.lineWidth=6;b.beginPath();b.moveTo(1360,fy-60);b.lineTo(1360,fy-170);b.moveTo(1320,fy-140);b.lineTo(1400,fy-140);b.stroke();b.fillStyle='#160814';b.beginPath();b.arc(1360,fy-182,14,0,TAU);b.fill();b.beginPath();b.moveTo(1336,fy-188);b.lineTo(1384,fy-188);b.lineTo(1360,fy-210);b.fill();
 b.fillStyle='#14080f';for(let i=0;i<140;i++){const side=i<70,x=side?r()*560:W0-r()*560,hh=70+r()*110,yb=fy-10+r()*10;b.fillRect(x,yb-hh,3,hh);for(const k of[.35,.6]){b.beginPath();b.moveTo(x+1.5,yb-hh*k);b.quadraticCurveTo(x+(r()<.5?18:-18),yb-hh*(k+.14),x+(r()<.5?24:-24),yb-hh*(k-.04));b.lineTo(x+1.5,yb-hh*(k-.06));b.fill()}b.beginPath();b.ellipse(x+1.5,yb-hh-6,3,8,0,0,TAU);b.fill()}
 /* the ground */q=b.createLinearGradient(0,fy-30,0,H0);q.addColorStop(0,'#2a1810');q.addColorStop(1,'#0c0605');b.fillStyle=q;b.fillRect(0,fy-30,W0,H0);
 /* the hay dais */for(const [rx,ry,dy,c0,c1] of[[360,74,30,'#6a3e14','#2a1406'],[320,62,8,'#a8702a','#5a3410'],[280,52,-6,'#e0aa4e','#9a6a24']]){q=b.createLinearGradient(0,fy+dy-ry,0,fy+dy+ry+24);q.addColorStop(0,c0);q.addColorStop(1,c1);b.fillStyle=q;b.beginPath();b.ellipse(cx,fy+dy+20,rx,ry,0,0,Math.PI);b.lineTo(cx-rx,fy+dy);b.ellipse(cx,fy+dy,rx,ry,0,Math.PI,0);b.closePath();b.fill();b.beginPath();b.ellipse(cx,fy+dy,rx,ry,0,0,TAU);b.fillStyle=c0;b.fill();b.strokeStyle='#3a1a06';b.lineWidth=2;b.stroke()}
 b.strokeStyle='#fff0c050';b.lineWidth=1.4;for(let i=0;i<220;i++){const a=r()*TAU,d=Math.sqrt(r()),x=cx+Math.cos(a)*270*d,y=fy-6+Math.sin(a)*48*d;b.beginPath();b.moveTo(x,y);b.lineTo(x+(r()-.5)*22,y+(r()-.5)*5);b.stroke()}
 /* wheat sheaves and pumpkins */for(const [x,sd] of[[520,1],[1080,-1]])for(let i=0;i<13;i++){b.save();b.translate(x+(i-6)*6,fy-4);b.scale(1.6,1.6);fltWheat(b,0,0,52+r()*16,(i-6)*.06*sd,'#a8762a','#ffd860');b.restore()}
 const pk=(x,y,R)=>{for(const [dx,rx] of[[-R*.42,R*.5],[R*.42,R*.5],[0,R*.6]]){b.beginPath();b.ellipse(x+dx,y,rx,R*.8,0,0,TAU);b.fillStyle=pLin(b,0,y-R,0,y+R,['#ffb45a','#ff7a1a','#9a3a14']);b.fill();b.lineWidth=3;b.strokeStyle='#2a0e04';b.stroke()}
  b.beginPath();b.moveTo(x,y-R*.7);b.quadraticCurveTo(x+4,y-R*1.1,x+R*.3,y-R*1.2);b.lineWidth=9;b.strokeStyle='#2a0e04';b.stroke();b.lineWidth=5;b.strokeStyle='#5a7a22';b.stroke();b.beginPath();b.ellipse(x-R*.3,y-R*.3,R*.1,R*.28,-.3,0,TAU);b.fillStyle='#ffffff38';b.fill()};
 pk(300,fy+110,62);pk(410,fy+170,40);pk(170,fy+190,46);pk(1290,fy+110,66);pk(1170,fy+175,38);pk(1440,fy+200,48);
 q=b.createRadialGradient(cx,H0*.5,H0*.32,cx,H0*.5,W0*.72);q.addColorStop(0,'#00000000');q.addColorStop(1,'#000000c0');b.fillStyle=q;b.fillRect(0,0,W0,H0);
 return FLH.bg=c}
const FLH_FY=560,FLH_MY=215;
/* sounds of the harvest */
const FLHS={
 chime:(A,at,f)=>{phTone(A,at,f,1.1,.07,{ty:'triangle',echo:1,att:.004});phTone(A,at,f*2,.35,.018);phTone(A,at,f*.5,.6,.03)},
 gust:(A,at,d)=>{phNoise(A,at,d||1,.14,{f:300,f2:1800,q:.6,swell:1});phNoise(A,at+(d||1)*.5,(d||1)*.6,.08,{f:2200,f2:600,q:.8})},
 crickets:(A,at,d)=>{for(let i=0;i<Math.round(d*5);i++)for(let j=0;j<3;j++)phTone(A,at+i*.2+j*.03,4200+(i%2)*300,.025,.008,{ty:'sine'})},
 gobble:(A,at,big)=>{const n=big?9:6;for(let i=0;i<n;i++){const f=(big?400:520)-i*12+(i%2?70:0);phTone(A,at+i*.055,f,.075,big?.075:.05,{ty:'sawtooth',f2:f*.6,fd:.06});phTone(A,at+i*.055,f*2.03,.05,.018,{ty:'triangle',f2:f*1.25})}},
 thunder:(A,at)=>{phNoise(A,at,1.8,.26,{ty:'lowpass',f:220,f2:60});phTone(A,at,70,1.2,.16,{ty:'triangle',f2:38});phNoise(A,at+.04,.25,.2,{ty:'highpass',f:1800,f2:600})},
 chitter:(A,at)=>{for(let i=0;i<7;i++)phTone(A,at+i*.045,1700+((i*37)%5)*160,.05,.03,{ty:'triangle',f2:2300})},
 yip:(A,at)=>{phTone(A,at,760,.16,.05,{ty:'triangle',f2:1400,fd:.08});phTone(A,at+.2,880,.18,.045,{ty:'triangle',f2:1560,fd:.08})},
 crackle:(A,at,d)=>{for(let i=0;i<Math.round(d*14);i++)phNoise(A,at+Math.random()*d,.03,.1,{ty:'highpass',f:3200+Math.random()*2000})}};
function fltGobbleSm(){const A=phAudio();if(!A)return;FLHS.gobble(A,0,false);setTimeout(()=>phStop(A),900)}
/* the ceremony draws many large soft glows a frame: a cached sprite per colour is far cheaper than a fresh radial gradient */
const FLGS={};function flGlowSpr(c){if(FLGS[c])return FLGS[c];const v=document.createElement('canvas');v.width=v.height=256;const x=v.getContext('2d'),q=x.createRadialGradient(128,128,0,128,128,128);q.addColorStop(0,c+'ff');q.addColorStop(.5,c+'5a');q.addColorStop(1,c+'00');x.fillStyle=q;x.fillRect(0,0,256,256);return FLGS[c]=v}
function flGlow(g,x,y,r,c,a){if(r<=0||a<=0)return;g.save();g.globalCompositeOperation='lighter';g.globalAlpha=Math.min(1,a);g.drawImage(flGlowSpr(c),x-r,y-r,r*2,r*2);g.restore()}
/* pumpkin lantern bodies, lit and unlit, drawn once */
function flLanSpr(lit){const k='lan'+lit;if(FLGS[k])return FLGS[k];const v=document.createElement('canvas');v.width=v.height=64;const g=v.getContext('2d');g.translate(32,52);g.scale(1.7,1.7);
 for(const [dx,rx] of[[-7,9],[7,9],[0,11]]){g.beginPath();g.ellipse(dx,-12,rx,13,0,0,TAU);g.fillStyle=lit?pLin(g,0,-25,0,1,['#ffc46a','#ff7a1a','#9a3a14']):'#4a2410';g.fill();g.lineWidth=2;g.strokeStyle='#2a0e04';g.stroke()}
 g.beginPath();g.moveTo(0,-25);g.lineTo(2,-30);g.lineWidth=3;g.strokeStyle='#3a5a1a';g.stroke();return FLGS[k]=v}
function flpHatch(id,k,opt){opt=opt||{};const pGlow=flGlow;const wrapEl=$('wrap')||document.body;let el=$('pthx');if(el){if(el._stop)el._stop();el.remove()}el=document.createElement('div');el.id='pthx';el.className='pthx pthx-fl';
 const D=PDEF[id],kind=D.r==='m'?'h':D.r,my=kind==='h',leg=kind==='l',rm=ptRM()||opt.reveal,AC=my?'#ffb42a':leg?'#ff7a2a':'#e8a85a',AC2=my?'#ffe07a':leg?'#ffd45a':'#ffe2a0',GD='#ffd45a';
 el.innerHTML=`<canvas width="1600" height="900" id="pthc"></canvas><button class="ptskip" id="ptsk">Skip <span>⏭</span></button><div class="ptrv" id="ptrv"></div>`;wrapEl.appendChild(el);
 const cv=$('pthc'),g=cv.getContext('2d'),W0=1600,H0=900,cx=W0/2,fy=FLH_FY,bg=flhBG(),t0=performance.now()/1000;let done=false,raf=0,last=t0,skipped=false;
 const A=rm?null:phAudio();el._stop=()=>{phStop(A);cancelAnimationFrame(raf)};
 const EC=my?140:110,bx=D.box||[-60,-110,120,115],PS=Math.min(my?2.6:2.5,(my?300:260)/bx[3],330/bx[2]);
 const TL=my?1.3:leg?.3:.35,TB=my?5.6:leg?3.8:3,TF=my?7.8:leg?5.6:4.5;
 const P_=[],shards=[],conf=[],rings=[],leaves=[];let flash=0,shake=0,moonG=0,fanS=0,bolt=-9;
 const rnd=(a,b)=>a+Math.random()*(b-a),S_=(tt,a,b)=>pSeg(tt,a,b);
 /* the lantern ring: one by one they light */const NL=8,LT=Array.from({length:NL},(_,i)=>{const a=Math.PI*.08+i*(Math.PI*.84/(NL-1));return{x:cx-Math.cos(a)*300,y:fy+14+Math.sin(a)*40,on:-1}});
 const lanStart=my?1.5:leg?1:.6,lanStep=my?.2:leg?.15:.1;
 for(let i=0;i<30;i++)leaves.push({x:rnd(0,W0),y:rnd(-200,H0),v:rnd(30,70),a:rnd(0,6),s:rnd(10,20),c:i%4,sw:rnd(.6,1.4)});
 const beats=[];const at=(t,f)=>beats.push({t,f,done:false});
 at(.02,()=>{FLHS.gust(A,0,1.4);FLHS.crickets(A,.1,2)});
 for(let i=0;i<NL;i++)at(lanStart+i*lanStep,()=>{LT[i].on=0;FLHS.chime(A,0,[196,220,247,262,294,330,392,440][i]);for(let j=0;j<6;j++)P_.push({x:LT[i].x,y:LT[i].y-14,vx:rnd(-40,40),vy:rnd(-90,-30),l:rnd(.5,.9),c:j%2?'#ffd45a':'#ff9a2a',s:rnd(2,4),g:60})});
 if(my){at(.5,()=>PHS.whoosh(A,0));at(TL,()=>{PHS.thud(A,0);shake=9;rings.push({t:0,c:GD,w:8,max:420,y:fy-6,fl:.22});burstLeaves(30,fy-10,260)});
  [3.5,4.1,4.65].forEach((t,i)=>at(t,()=>{PHS.heart(A,0);PHS.crack(A,.04,.5+i*.25);shake=4+i*3;flash=Math.max(flash,.16+i*.08);rings.push({t:0,c:AC,w:6,max:260+i*80,y:fy-EC,fl:.6});burstLeaves(10+i*6,fy-EC,200)}));
  at(3.4,()=>{PHS.rumble(A,0,2,.15);PHS.rise(A,.6,1.4);FLHS.gust(A,0,2.1)});at(5.05,()=>PHS.suck(A,0,.5));
  at(TB,()=>{PHS.boom(A,0,true);PHS.shatter(A,.04);PHS.chord(A,.08,[174.6,220,261.6,349.2,440],3.2,.045);PHS.sparkle(A,.12,14);FLHS.thunder(A,.05);burst()});
  at(TB+.35,()=>{bolt=0});at(TB+.9,()=>{PHS.sparkle(A,0,10);featherRain()});
  at(TB+1.05,()=>{PHS.thud(A,0);FLHS.gobble(A,.1,true);FLHS.thunder(A,.55);shake=Math.max(shake,8);rings.push({t:0,c:GD,w:8,max:380,y:fy-6,fl:.22});bolt=0})}
 else if(leg){at(.2,()=>FLHS.gust(A,0,1.6));at(1.7,()=>PHS.rumble(A,0,1.6,.12));[2.4,2.9,3.3].forEach((t,i)=>at(t,()=>{PHS.heart(A,0);FLHS.crackle(A,0,.3);shake=3+i*2;flash=Math.max(flash,.14+i*.06);rings.push({t:0,c:AC,w:6,max:220+i*60,y:fy-EC,fl:.6})}));at(3.4,()=>PHS.rise(A,0,.4));
  at(TB,()=>{PHS.boom(A,0,true);FLHS.crackle(A,.05,.9);PHS.chord(A,.08,[220,277.2,329.6,440],2.6,.045);PHS.sparkle(A,.1,12);burst()});at(TB+.9,()=>{PHS.thud(A,0);FLHS.yip(A,.1)})}
 else{at(.02,()=>PHS.whoosh(A,0));at(TL,()=>{PHS.thud(A,0);shake=6;burstLeaves(14,fy-6,180)});[1.7,2.1,2.5].forEach((t,i)=>at(t,()=>{PHS.crack(A,0,.7+i*.25);FLHS.chime(A,.02,523+i*130);shake=3+i*2.4}));at(2.7,()=>PHS.rise(A,0,.3));
  at(TB,()=>{PHS.boom(A,0,false);PHS.chord(A,.08,[293.7,370,440,587.3],2.2,.045);PHS.sparkle(A,.05,9);burst()});at(TB+.86,()=>{PHS.thud(A,0);FLHS.chitter(A,.1)})}
 at(TF,()=>{PHS.chord(A,0,my?[392,493.9,587.3,784,987.8]:[349.2,440,523.3,698.5],2,.03);fin()});
 function burstLeaves(n,y,v){for(let i=0;i<n;i++){const a=-Math.PI*rnd(.05,.95);conf.push({x:cx+rnd(-40,40),y,vx:Math.cos(a)*rnd(v*.4,v),vy:Math.sin(a)*rnd(v*.4,v),r:rnd(0,6),vr:rnd(-8,8),s:rnd(10,18),c:i%4,l:rnd(1.4,2.4),ph:rnd(0,6),lf:1})}}
 function burst(){flash=1;shake=my?24:leg?18:13;moonG=1;rings.push({t:0,c:AC,w:my?18:14,max:my?900:700,y:fy-EC},{t:-.1,c:'#ffffff',w:7,max:my?1100:820,y:fy-EC});if(my)rings.push({t:-.22,c:GD,w:12,max:1250,y:fy-EC},{t:-.34,c:'#ff6a2a',w:8,max:1400,y:fy-EC});
  const sc=my?['#ffd45a','#ffc23a','#e88a24','#fff2b0','#c8763a']:leg?['#ffe27a','#ff9a2a','#e8401a','#c8281a']:['#cf8a3e','#f2b866','#8a5428','#b47a40'];
  for(let i=0;i<(my?44:30);i++){const a=rnd(0,TAU),v=rnd(240,my?700:560);shards.push({x:cx+Math.cos(a)*30,y:fy-EC+Math.sin(a)*50,vx:Math.cos(a)*v,vy:Math.sin(a)*v-140,r:rnd(0,6),vr:rnd(-12,12),s:rnd(8,my?18:15),c:sc[i%sc.length],l:rnd(1.3,2.1),lf:leg&&i%2})}
  burstLeaves(my?50:leg?56:32,fy-EC,my?620:520);
  for(let i=0;i<34;i++){const a=rnd(0,TAU),v=rnd(80,420);P_.push({x:cx,y:fy-EC,vx:Math.cos(a)*v,vy:Math.sin(a)*v,l:rnd(.8,1.4),c:i%2?'#ffffff':AC2,s:rnd(3,7),g:-20,st:1})}
  if(my)for(let i=0;i<26;i++){const a=rnd(-Math.PI,0),v=rnd(200,560);P_.push({x:cx,y:fy-EC,vx:Math.cos(a)*v,vy:Math.sin(a)*v,l:rnd(1.6,2.6),g:240,food:i%5,s:rnd(20,30),r:rnd(0,6)})}}
 function featherRain(){for(let i=0;i<36;i++)P_.push({x:cx+rnd(-560,560),y:rnd(-60,80),vx:rnd(-30,30),vy:rnd(60,140),l:rnd(2.2,3.4),g:10,fe:1,s:rnd(10,16),r:rnd(0,6)})}
 /* pet layer */const pl=document.createElement('canvas');pl.width=1000;pl.height=860;const pg=pl.getContext('2d');
 const drawPet=(x,y,s,pose,u,sil,silC,t)=>{pg.setTransform(1,0,0,1,0,0);pg.clearRect(0,0,1000,860);pg.setTransform(s,0,0,s,500,700);petDraw(pg,id,{t,pose,u,noSh:1});
  if(sil>0){pg.setTransform(1,0,0,1,0,0);pg.globalCompositeOperation='source-atop';pg.globalAlpha=sil;pg.fillStyle=silC;pg.fillRect(0,0,1000,860);pg.globalAlpha=1;pg.globalCompositeOperation='source-over'}g.drawImage(pl,x-500,y-700)};
 const fin=()=>{if(done)return;done=true;P.petPend=null;save();const rv=$('ptrv');
  const MS=[['acc',3,D.cos.acc],['pal',5,D.cos.pal],['cel',7,D.cos.cel],['trim',10,D.cos.sig]],own=PIDS.filter(petOwned).length,pc=own/PIDS.length*100,hv=FLPC.ids.filter(petOwned).length;
  rv.className='ptrv flhv flh-'+kind;
  rv.innerHTML=`<div class="phc"><div class="phc-rib">${my?'✦ MYTHIC HARVEST COMPANION ✦':leg?'✦ LEGENDARY HARVEST COMPANION ✦':'NEW HARVEST COMPANION'}</div><div class="phc-l"><h2 class="phc-n">${esc(D.n)}</h2>${D.t?`<em class="flh-sub">${esc(D.t)}</em>`:''}<div class="phc-tags">${ptBadge(D.r)}<span class="phc-fam" style="--f:${PFAM[D.fam]}">${D.fam}</span></div></div>
   <div class="phc-ab"><canvas width="72" height="72" id="ptrvi"></canvas><div><b>${D.ab.n}</b><p>${D.ab.d}</p></div></div>
   <div class="phc-ms"><small>Bond rewards to unlock</small><div>${MS.map(([kk,L,n])=>`<span title="${esc(n)} at Bond ${L}"><canvas width="64" height="52" data-hm="${kk}"></canvas><i>Bond ${L}</i></span>`).join('')}</div></div>
   <div class="ptmb phc-b">${P.pet===id?`<button class="ptgo" id="ptrvq">${PTICO.chk} Equipped</button>`:`<button class="ptgo flh-eq" id="ptrve">Equip ${esc(D.n)}</button><button class="ptgo b" id="ptrvq">Keep current</button>`}</div>
   <div class="phc-prog"><div><span>${PTICO.paw} Collection</span><b>${own} / ${PIDS.length}</b></div><span class="phc-pb"><i style="--w:${pc}%"></i></span><small>${FLP_LEAF} ${hv} / 3 harvest companions</small></div></div>`;
  requestAnimationFrame(()=>rv.classList.add('on'));petIconCv($('ptrvi'),D.ab.k);
  rv.querySelectorAll('canvas[data-hm]').forEach(c=>{const kk=c.dataset.hm;if(kk==='cel'){petFit(c,id,{t:1.2,pose:'greet',u:.55,still:1});const gg=c.getContext('2d'),s=c.height/130;gg.save();gg.translate(c.width/2,c.height*.9);gg.scale(s,s);petCelFx(gg,id,.4,1,-56,52);gg.restore()}else petFit(c,id,{t:1.2,still:1,[kk]:1})});
  $('ptsk').style.display='none';
  const close=()=>{phStop(A);cancelAnimationFrame(raf);el.classList.add('out');setTimeout(()=>el.remove(),260);if(typeof opt.back==='function'){try{opt.back()}catch(e){console.error(e)}return}PTX.sel=id;PTX.tab='Pets';PTX.back=PTX.back||title;petHall('Pets')};
  const e=$('ptrve');if(e)e.onclick=()=>{petEquip(id);ptBeep(820,.06,.35);close()};$('ptrvq').onclick=()=>close();
  setTimeout(()=>{const f=$('ptrve')||$('ptrvq');try{f&&f.focus()}catch(x){}},420)};
 const skip=()=>{if(done)return;skipped=true;phStop(A);const B=phAudio();if(B){PHS.chord(B,0,[261.6,329.6,392,523.3],1.6,.04);FLHS.chime(B,.05,523.3);setTimeout(()=>phStop(B),2000)}flash=Math.max(flash,.5);fin()};
 $('ptsk').onclick=skip;el.tabIndex=-1;el.onkeydown=e=>{e.stopPropagation();if(e.key==='Escape'||(e.key===' '&&!done)){e.preventDefault();if(!done)skip()}};setTimeout(()=>{try{el.focus()}catch(x){}},30);
 /* the centrepiece before the burst */
 const center=(tt,t,eX,eY,eS,lean,charge,glow)=>{g.save();g.translate(eX,eY);g.rotate(lean);
  if(my){g.scale(2.25*eS,2.25*eS);eggDraw(g,'h',{t,glow,charge,noSh:1})}
  else if(!leg){/* a giant acorn */g.scale(eS,eS);pGlow(g,0,-90,90,'#ffd27a',.2+glow*.4);flpAcorn(g,0,-118,150,0,FLP_AC,4);if(charge>0){g.save();g.globalCompositeOperation='lighter';for(let i=0;i<5;i++){const a=-1.2+i*.6;g.beginPath();g.moveTo(Math.cos(a)*14,-60+Math.sin(a)*14);g.lineTo(Math.cos(a)*(40+charge*30),-60+Math.sin(a)*(40+charge*30));g.strokeStyle=ptHexA('#fff2c0',charge*.8);g.lineWidth=3;g.stroke()}g.restore()}}
  else{/* a cocoon of maple leaves that tightens as it charges */g.scale(eS,eS);const as=S_(tt,.2,1.7),sp=1-charge*.2;pGlow(g,0,-110,110,'#ff8a2a',.25+glow*.5);for(let i=0;i<18;i++){const a=i*TAU/18+t*(1.2+charge*4),r0=(1-as)*400+70*sp*(.8+.2*Math.sin(i*1.7)),x=Math.cos(a)*r0*.7,y=-110+Math.sin(a)*r0;g.save();g.globalAlpha=Math.min(1,as*1.5);flpMaple(g,x,y,40,a+Math.PI/2,['#ffe27a','#ff9a2a','#ff6a2a'][i%3],['#e8541a','#c8281a','#9a1a1a'][i%3],2.4,'#fff2c066',1);g.restore()}
   if(as>.9){pGlow(g,0,-110,40+charge*60,'#fff2c0',.5*charge+.2)}}
  g.restore()};
 const frame=()=>{if(!el.isConnected){phStop(A);return}const now=performance.now()/1000,dt=Math.min(.05,now-last);last=now;let tt=rm||skipped?Math.max(TF+.4,now-t0+TF):now-t0;if(window.__flhT!=null)tt=window.__flhT;const t=now;
  for(const b of beats)if(!b.done&&tt>=b.t&&!skipped&&!rm){b.done=true;try{b.f()}catch(e){}}
  if(rm&&!done)fin();
  const post=tt-TB,em=post;
  let z=post<0?.94+.12*pS(Math.max(0,tt)/TB):1+.18*Math.exp(-post*3.6)*Math.cos(post*6.5);if(rm||skipped)z=1;
  shake*=Math.pow(.02,dt);flash*=Math.pow(.006,dt);moonG=Math.max(moonG*Math.pow(.6,dt),post>0&&my?.55:0);const sx=(Math.random()-.5)*shake,sy=(Math.random()-.5)*shake;
  g.setTransform(1,0,0,1,0,0);g.globalAlpha=1;g.globalCompositeOperation='source-over';g.fillStyle='#000';g.fillRect(0,0,W0,H0);
  const bz=1+(z-1)*.35,night=rm||skipped?1:S_(tt,0,.6);g.globalAlpha=night;g.setTransform(bz,0,0,bz,cx*(1-bz)+sx*.3,(fy-EC)*(1-bz)+sy*.3);g.drawImage(bg,0,0);g.globalAlpha=1;
  /* the moon brightens as power gathers and turns gold at the burst */const mg=Math.max(post<0?S_(tt,TB*.55,TB)*.4:0,moonG);if(mg>.01){g.save();g.globalCompositeOperation='lighter';pGlow(g,cx,FLH_MY,260,'#ffd45a',.35*mg);pGlow(g,cx,FLH_MY,170,'#fff2c0',.3*mg);g.restore()}
  /* Thunderplume: its feathered silhouette fans across the moon */if(my&&post>.3&&!rm){fanS=Math.min(1,fanS+dt*.9);const f=pS(fanS)*(post>3?Math.max(.35,1-(post-3)*.2):1);if(!FLGS.sf){const v=document.createElement('canvas');v.width=80;v.height=250;const x=v.getContext('2d');x.translate(40,-28);x.beginPath();x.moveTo(-14,30);x.bezierCurveTo(-36,140,-34,240,0,272);x.bezierCurveTo(34,240,36,140,14,30);x.closePath();x.fillStyle='#1c0a0c';x.fill();x.lineWidth=3;x.strokeStyle=ptHexA('#ffd45a',.6);x.stroke();FLGS.sf=v}
   const fan=(gg,sp)=>{for(let i=0;i<15;i++){const a=Math.PI+(i/14*2-1)*1.25*sp;gg.save();gg.rotate(a);gg.drawImage(FLGS.sf,-40,28);gg.restore()}};
   g.save();g.globalAlpha=.9*f;if(fanS>=1){if(!FLGS.fan){const v=document.createElement('canvas');v.width=680;v.height=320;const x=v.getContext('2d');x.translate(340,300);fan(x,1);FLGS.fan=v}g.drawImage(FLGS.fan,cx-340,FLH_MY+140-300)}else{g.translate(cx,FLH_MY+140);fan(g,pS(fanS))}g.restore()}
  g.setTransform(z,0,0,z,cx*(1-z)+sx,(fy-EC)*(1-z)+sy);
  /* lightning answers the gobble */if(bolt>=0&&!rm){bolt+=dt;if(bolt<.45){const a=1-bolt/.45;g.save();g.globalAlpha=a;fltBolt(g,cx-420,0,cx-300,FLH_MY+40,Math.floor(bolt*30),'#ffd45a',5);fltBolt(g,cx+460,0,cx+330,FLH_MY+60,Math.floor(bolt*30)+7,'#ffd45a',4);g.restore();g.save();g.setTransform(1,0,0,1,0,0);g.fillStyle=`rgba(255,240,200,${.18*a})`;g.fillRect(0,0,W0,H0);g.restore()}else bolt=-9}
  /* leaves on the wind */if(!rm)for(const L of leaves){L.y+=L.v*dt;L.x+=(Math.sin(t*1.2+L.a)*30+(post>0&&post<1.5?160:30))*dt*L.sw;L.a+=dt*1.6;if(L.y>H0+30||L.x>W0+40){L.y=-30;L.x=rnd(-200,W0)}g.globalAlpha=.8*night;flpLeafD(g,L.x,L.y,L.s,L.a,L.c);g.globalAlpha=1}
  /* light pillar while the power gathers */const pil=post<0?S_(tt,TB*.3,TB)*.45:Math.max(0,.6-post*.25);if(pil>0&&!rm){g.save();g.globalCompositeOperation='lighter';const q=g.createLinearGradient(0,0,0,fy);q.addColorStop(0,ptHexA(AC,0));q.addColorStop(.7,ptHexA(AC,.12*pil));q.addColorStop(1,ptHexA(GD,.22*pil));g.fillStyle=q;g.beginPath();g.moveTo(cx-60,0);g.lineTo(cx+60,0);g.lineTo(cx+170,fy);g.lineTo(cx-170,fy);g.closePath();g.fill();g.restore()}
  /* the lantern ring */for(const L of LT){if(L.on>=0)L.on+=dt;const lit=rm||skipped?1:L.on<0?0:Math.min(1,L.on/.25),f=.85+.15*Math.sin(t*8+L.x);if(lit>0)pGlow(g,L.x,L.y-20,78*lit*f,'#ff9a2a',.4*lit);g.drawImage(flLanSpr(lit>0?1:0),L.x-32,L.y-52);g.save();g.translate(L.x,L.y);g.scale(1.7,1.7);
   if(lit>0){g.fillStyle=ptHexA('#fff2a0',lit*f);g.beginPath();g.moveTo(-8,-16);g.lineTo(-4,-20);g.lineTo(-2,-15);g.closePath();g.moveTo(8,-16);g.lineTo(4,-20);g.lineTo(2,-15);g.closePath();g.moveTo(-7,-8);g.quadraticCurveTo(0,-2,7,-8);g.lineTo(4,-6);g.lineTo(0,-8);g.lineTo(-4,-6);g.closePath();g.fill()}
   g.restore()}
  /* godrays from the centrepiece */const ri=post<0?S_(tt,TB*.3,TB)*.5:Math.max(.25,1-post*.35);if(ri>0&&!rm){g.save();g.globalCompositeOperation='lighter';g.translate(cx,fy-EC);g.rotate(t*.06);for(let i=0;i<12;i++){g.rotate(TAU/12);const len=720+Math.sin(t*1.2+i)*80,wd=i%2?22:42,q=g.createLinearGradient(0,0,0,-len);q.addColorStop(0,ptHexA(i%3?AC:'#ffffff',.18*ri));q.addColorStop(1,ptHexA(AC,0));g.fillStyle=q;g.beginPath();g.moveTo(-6,0);g.lineTo(6,0);g.lineTo(wd,-len);g.lineTo(-wd,-len);g.closePath();g.fill()}g.restore()}
  /* ----- the centrepiece ----- */
  let eX=cx,eY=fy-6,eS=1,eA=1,lean=0,glow=.3+.15*Math.sin(t*2),charge=0;
  if(!rm&&!skipped){if(tt<TL&&!leg){const k2=S_(tt,my?.4:0,TL),e2=k2*k2;eY=-260+(fy-6+260)*e2;eA=S_(tt,my?.35:0,(my?.35:0)+.12)}
   else if(post<0){const hv=S_(tt,TL,TL+.5),rise=S_(tt,TB*.6,TB);eY=fy-6-(my?hv*14+rise*40:rise*20)-Math.sin(t*1.6)*4*hv;glow=.35+S_(tt,TB*.3,TB*.6)*.35+rise*.6;charge=S_(tt,TB*.62,TB);
    if(tt>TB*.6)lean=Math.sin(t*34)*.012*(1+charge*2);const hb=my?[3.5,4.1,4.65]:leg?[2.4,2.9,3.3]:[1.7,2.1,2.5];for(const b of hb){const k3=(tt-b)/.4;if(k3>=0&&k3<1){eS*=1+Math.sin(k3*Math.PI)*.05;lean+=Math.sin(k3*Math.PI*3)*(1-k3)*.06}}
    if(tt>TB-.4){const im=S_(tt,TB-.4,TB);eS*=1-im*.12;glow=1.4}}else eA=0}
  else eA=0;
  if(eA>0)g.save(),g.globalAlpha=eA,center(tt,t,eX,eY,eS,lean,charge,glow),g.restore();
  if(charge>0&&post<0){pGlow(g,cx,eY-EC,60+charge*140,'#ffffff',.2*charge);pGlow(g,cx,eY-EC,120+charge*200,AC,.25*charge)}
  /* converging leaves before the burst */if(!rm&&!skipped&&post<0&&tt>TB*.6){for(let i=0;i<2;i++){const a=Math.random()*TAU,d=rnd(420,800);P_.push({x:cx+Math.cos(a)*d,y:fy-EC+Math.sin(a)*d*.6,tx:cx,ty:fy-EC,l:.7,c:i?AC:GD,s:rnd(2,4),seek:1,sp:rnd(3,6),st:1})}}
  /* ----- the companion ----- */
  let petY=fy+40,petA=0,silA=1,ps=PS,pose='idle',pu=0;
  if(em>=0){petA=S_(em,.05,.25);const up=S_(em,.05,.55),dn=S_(em,.6,1);petY=em<.6?fy-EC*.6-up*90:fy-EC*.6-90+(EC*.6+90)*dn*dn;silA=1-S_(em,.45,1.15);ps=PS*(.6+S_(em,.05,.6)*.4);
   if(em>1&&em<1.2){const k2=(em-1)/.2;ps*=1-Math.sin(k2*Math.PI)*.07}
   if(em>1.05){const gk=(em-1.05)/1.7;if(gk<1){pose='greet';pu=gk}else{const c2=(em-2.75)%6.5;if(c2>=0&&c2<2.2){pose='ability';pu=c2/2.2}else if(c2>4.2&&c2<5.8){pose='greet';pu=(c2-4.2)/1.6}}}else if(em>.6)pose='idle'}
  if(rm||skipped){petA=1;petY=fy;silA=0;ps=PS;const c2=(tt-TF)%7;if(c2>1&&c2<3.2){pose='ability';pu=(c2-1)/2.2}else if(c2>4.5&&c2<6.1){pose='greet';pu=(c2-4.5)/1.6}}
  if(em>=0||rm){const lc=rm?.4:Math.max(.25,1-em*.3);g.save();g.globalCompositeOperation='lighter';g.translate(cx,fy-280);g.scale(.42,1.8);pGlow(g,0,0,300,AC,.3*lc);g.restore();
   g.save();g.globalAlpha=petA;g.fillStyle='#00000070';g.beginPath();g.ellipse(cx,fy+2,100*ps/PS,16,0,0,TAU);g.fill();g.restore();
   if(petA>0){g.save();g.globalAlpha=petA;drawPet(cx,petY,ps,pose,pu,silA,'#fff2d0',t);g.restore();if(silA>.05)pGlow(g,cx,petY-bx[3]*ps*.5,240*silA,'#fff6e0',.45*silA)}}
  if(em>1.05&&em<2.9&&!rm){g.save();g.translate(cx,fy);g.scale(ps,ps);petCelFx(g,id,(em-1.05)/1.85,t,-bx[3]*.5,Math.max(bx[2],bx[3])*.75);g.restore()}
  /* ----- shockwaves, flash, debris ----- */
  g.save();g.globalCompositeOperation='lighter';
  for(let i=rings.length-1;i>=0;i--){const r=rings[i];r.t+=dt;if(r.t<0)continue;const v=r.t/1.2;if(v>=1){rings.splice(i,1);continue}g.save();g.translate(cx,r.y);g.scale(1,r.fl||.6);g.beginPath();g.arc(0,0,40+pS(v)*r.max,0,TAU);g.strokeStyle=ptHexA(r.c,(1-v)*.9);g.lineWidth=r.w*(1-v)+2;g.stroke();g.restore()}
  if(flash>.01){pGlow(g,cx,fy-EC,600*(1.5-flash*.5),AC,.5*flash);pGlow(g,cx,fy-EC,260,'#ffffff',.7*flash);g.save();g.setTransform(1,0,0,1,0,0);g.fillStyle=ptHexA('#ffffff',Math.max(0,flash-.55)*1.4);g.fillRect(0,0,W0,H0);g.restore()}
  g.restore();
  for(let i=shards.length-1;i>=0;i--){const s=shards[i];s.l-=dt;if(s.l<=0||s.y>H0+60){shards.splice(i,1);continue}s.vy+=620*dt;s.vx*=Math.pow(.5,dt);s.x+=s.vx*dt;s.y+=s.vy*dt;s.r+=s.vr*dt;g.globalAlpha=Math.min(1,s.l*1.4);
   if(s.lf)flpLeafD(g,s.x,s.y,s.s*1.6,s.r,1);else{g.save();g.translate(s.x,s.y);g.rotate(s.r);pP(g,[-s.s,-s.s*.5,s.s*.9,-s.s*.3,s.s*.3,s.s*.85,-s.s*.4,s.s*.5]);pF(g,s.c,2.4);pStar4(g,-s.s*.2,0,s.s*.22,'#ffffffaa');g.restore()}g.globalAlpha=1}
  for(let i=conf.length-1;i>=0;i--){const c=conf[i];c.l-=dt;if(c.l<=0){conf.splice(i,1);continue}c.vy+=240*dt;c.vx*=Math.pow(.35,dt);c.vy*=Math.pow(.55,dt);c.x+=(c.vx+Math.sin(t*3+c.ph)*40)*dt;c.y+=c.vy*dt;c.r+=c.vr*dt;g.globalAlpha=Math.min(1,c.l);
   flpLeafD(g,c.x,c.y,c.s,c.r,c.c);g.globalAlpha=1}
  for(let i=P_.length-1;i>=0;i--){const p=P_[i];p.l-=dt;if(p.l<=0){P_.splice(i,1);continue}if(p.seek){const k2=Math.min(1,dt*(p.sp||5));p.x+=(p.tx-p.x)*k2;p.y+=(p.ty-p.y)*k2}else{p.vy+=(p.g||0)*dt;p.x+=p.vx*dt;p.y+=p.vy*dt}g.globalAlpha=Math.min(1,p.l*2);
   if(p.food!=null){p.r+=dt*3;fltFoodD(g,p.food,p.x,p.y,p.s,p.r)}else if(p.fe){p.r+=dt*2;g.save();g.translate(p.x+Math.sin(t*2+p.r)*10,p.y);g.rotate(Math.sin(t*2.4+p.r)*.6);const q=p.s/26;g.scale(q,q);g.drawImage(fltSpr('fe'),-32,-32);g.restore()}
   else if(p.st)pStar4(g,p.x,p.y,p.s,p.c);else{pGlow(g,p.x,p.y,p.s*2.4,p.c,.5);g.fillStyle=p.c;g.fillRect(p.x-p.s/2,p.y-p.s/2,p.s,p.s)}g.globalAlpha=1}
  if(em>1.2||rm){for(let i=0;i<10;i++){const u=((t*.06+i/10)%1),x=cx+Math.sin(i*2.2+t*.3)*300*(.5+u*.5),y=fy-u*520,a=Math.sin(u*Math.PI)*.6;pGlow(g,x,y,9,i%2?AC:GD,a)}}
  raf=requestAnimationFrame(frame)};
 raf=requestAnimationFrame(frame)}
/* harvest companions always hatch in the harvest ceremony */
{const h0=ptHatchScene;ptHatchScene=function(id,k,opt){if(PDEF[id]&&PDEF[id].fl)return flpHatch(id,k,opt);return h0.apply(this,arguments)}}
/* a Golden Harvest Egg opened while Thunderplume is already owned: a shower of coins and a note */
function flpRefundFx(g){try{let el=$('flprf');if(el)el.remove();el=document.createElement('div');el.id='flprf';el.className='flprf';el.setAttribute('role','status');
 el.innerHTML=`<canvas width="120" height="120"></canvas><div><b>+${g.toLocaleString()} coins</b><small>Thunderplume is already yours, so the egg became coins and +${FLPC.bond} bond.</small></div>`;($('wrap')||document.body).appendChild(el);
 const c=el.querySelector('canvas'),x=c.getContext('2d'),t0=performance.now();const C=Array.from({length:18},(_,i)=>({a:i/18*TAU,v:30+Math.random()*30,s:.6+Math.random()*.6}));
 const step=()=>{if(!el.isConnected)return;const t=(performance.now()-t0)/1000;x.setTransform(1,0,0,1,0,0);x.clearRect(0,0,120,120);x.save();x.translate(60,64);x.scale(.62,.62);eggDraw(x,'h',{t,glow:.5,noSh:1});x.restore();
  for(const q of C){const d=Math.min(1,t/1.2)*q.v,yy=60+Math.sin(q.a)*d+t*t*40,xx=60+Math.cos(q.a)*d;x.save();x.globalAlpha=Math.max(0,1-t/1.6);x.translate(xx,yy-20);x.scale(Math.abs(Math.cos(t*6+q.a))*.8+.2,1);x.beginPath();x.arc(0,0,5*q.s,0,TAU);x.fillStyle='#ffd45a';x.fill();x.lineWidth=1.2;x.strokeStyle='#9a661a';x.stroke();x.restore()}
  if(t<1.7)requestAnimationFrame(step)};requestAnimationFrame(step);
 const A=phAudio();if(A){for(let i=0;i<8;i++)phTone(A,i*.06,1200+i*140,.2,.04,{ty:'triangle',echo:1});FLHS.gobble(A,.2,false);setTimeout(()=>phStop(A),1600)}
 requestAnimationFrame(()=>el.classList.add('on'));setTimeout(()=>{el.classList.remove('on');setTimeout(()=>el.remove(),400)},3600)}catch(e){try{ccToast(`+${g.toLocaleString()} coins`)}catch(x){}}}

/* ======================================================================
   GRAND FEAST (Thunderplume's Mythic power)
   Charge: every correct word (like every charged power); a typo takes FLTK.typo words off the charge (a softer streak than Solmane's).
   Unleash with Shift or the power icon when READY. The gobble: every ordinary monster on screen is stunned (frozen in place, attacks
   held) for FLTK.stun s, projectiles in the air are blown away, a boss is not stunned but the attack it winds up is cancelled
   and its next one waits FLTK.boss s (flpBossDaze, 99p),
   the knight heals 1 heart if hurt, or at full health gains a shield (at most one above the run's starting shields), and a Banquet
   of FLTK.ban s begins: words finished during it score
   +50% and Fury from typing is doubled. Every stunned monster drops a feast morsel that flies to the knight for a little score and
   gold. Campaign and standard Endless only, like every companion power. Balance: see t_flpets104.py (balance) and the 10.4 handoff.
   ====================================================================== */
const FLTK={N:25,typo:1,stun:3,boss:3,ban:6,morsel:30,fx:[],mo:[]};
PM_MAN.add('grandfeast');
{const r0=petRunInit;petRunInit=function(){const r=r0.apply(this,arguments);try{FLTK.fx=[];FLTK.mo=[];const p=S.pet;if(p){p.heals=0;p.shs=0;p.banT=-9;p.feN=0;p.sh0=S.shield|0}}catch(e){}return r}}
const fltOn=p=>!!(p&&!p.cos&&PDEF[p.id]&&PDEF[p.id].ab.k==='grandfeast');
const fltBan=()=>{const p=PP();return fltOn(p)&&S.t<(p.banT||-9)};
{const w0=pmWhyNot;pmWhyNot=function(p){if(PDEF[p.id].ab.k==='grandfeast')return S.en.some(e=>e.x<W-10&&e.x>KX)||S.pj.some(j=>!j.b)?'':'Nothing to feast on yet';return w0.apply(this,arguments)}}
/* a typo knocks a little off the charge */
{const ky0=key;key=function(c){const ch0=S.chars,ok0=S.ok,f0=S.fury;const r=ky0.apply(this,arguments);try{const p=PP();if(fltOn(p)&&S.mode==='play'){
  if(S.chars>ch0&&S.ok===ok0&&!p.ready&&p.w>0){p.w=Math.max(0,p.w-FLTK.typo);p.brk=S.t;if(p.w>=3&&S.t-(p._tf||-9)>1.5){p._tf=S.t;float(KX+40,GY-250,`Typo: −${FLTK.typo}`,'#ffb04a',22)}}
  /* Banquet: Fury from typing is doubled */if(S.t<(p.banT||-9)){const df=S.fury-f0;if(df>0)S.fury=Math.min(S.fm,S.fury+df)}}}catch(e){}return r}}
/* Banquet: words score half again */
{const k0=kill;kill=function(e,force){const sc0=S.score,ban=fltBan(),typed=!force&&e&&!e.boss&&e.i>=(e.w||'').length;const r=k0.apply(this,arguments);try{if(ban&&typed){const d=S.score-sc0;if(d>0){const b=Math.round(d*.5);S.score+=b;FLTK.fx.push({k:'bon',t:0,ml:.9,x:e.x,y:e.y-(e.h||80)-60,n:b})}}}catch(x){}return r}}
function fltFeast(p){petSpend();p.feN=(p.feN|0)+1;p.banT=S.t+FLTK.ban;S.flash=Math.max(S.flash,.55);S.shake=Math.max(S.shake,22);S.lunge=1;
 const pj=S.pj.filter(j=>!j.b);for(const j of pj){burst(j.x,j.y,'#ffd45a',10,{v:240});FLTK.fx.push({k:'fea',t:0,ml:.9,x:j.x,y:j.y,a:Math.random()*6})}S.pj=S.pj.filter(j=>j.b);
 let n=0;for(const e of S.en){if(e.x>W-10)continue;if(e.boss){if(flpBossDaze(e,FLTK.boss))float(e.x-40,GY-e.h-40,'Dazed!','#ffd45a',36);continue}
  e.flst=FLTK.stun;n++;FLTK.mo.push({x:e.x,y:e.y-(e.h||80)*.6,x0:e.x,y0:e.y-(e.h||80)*.6,t:-.15-n*.06,d:.85+Math.random()*.25,k:(n+Math.floor(Math.random()*5))%5,r:Math.random()*6})}
 /* a heart, or at full health a feast shield (never more than one above the shields the run started with) */const hurt=S.hp>0&&S.hp<S.max;if(hurt){heal(S,1);p.heals=(p.heals|0)+1;float(KX,GY-300,'+1 ♥','#7dffb0',40)}
 else if((S.shield|0)<(p.sh0|0)+1){S.shield=(S.shield|0)+1;p.shs=(p.shs|0)+1;float(KX,GY-300,'Feast shield!','#7fd8ff',36)}
 float(W*.5,GY-340,'GRAND FEAST!','#ffd45a',60);if(n)float(W*.5,GY-282,`Stunned ×${n}`,'#ffe8b0',30);
 FLTK.fx.push({k:'gob',t:0,ml:1.6,x:petPx()+40,y:petPy()-70});petAnim('ability',1.8);
 flpAud(A=>{FLHS.gobble(A,0,true);FLHS.thunder(A,.32);PHS.boom(A,.3,false);PHS.chord(A,.45,[174.6,220,261.6,349.2],1.6,.035);PHS.sparkle(A,.5,8)},2800);return true}
{const u0=update;update=function(dt){const p=S&&S.pet;if(!p||S.mode!=='play'||p.cos)return u0.apply(this,arguments);const mod=[];
 if(!S.cine){if(fltOn(p)&&p.ready&&p.go)fltFeast(p);
  for(const e of S.en){if(e.flst>0){e.flst-=dt;mod.push([e,e.sp,e.at]);e.sp=0}}
  /* morsels fly to the knight */for(let i=FLTK.mo.length-1;i>=0;i--){const m=FLTK.mo[i];m.t+=dt;if(m.t>=m.d){FLTK.mo.splice(i,1);const sc=Math.round(FLTK.morsel*mult()*(S.sc||1));S.score+=sc;try{gain(1)}catch(e){}FLTK.fx.push({k:'yum',t:0,ml:.7,x:KX+10,y:GY-150,n:sc});try{beep(880+Math.random()*240,.05,'triangle',.18)}catch(e){}}}
  for(let i=FLTK.fx.length-1;i>=0;i--){const f=FLTK.fx[i];f.t+=dt;if(f.t>=f.ml)FLTK.fx.splice(i,1)}}
 const r=u0.apply(this,arguments);
 for(const [e,sp,at] of mod){e.sp=sp;if(at!=null&&e.at!=null)e.at=at}
 return r}}
/* the tail tips glow with the charge while the turkey is drawn in battle */
{const d0=petDrawGame;petDrawGame=function(){const p=S&&S.pet;try{FLT_CH.v=fltOn(p)?(p.ready?1:Math.min(1,(p.w||0)/FLTK.N)):0}catch(e){}try{return d0.apply(this,arguments)}finally{FLT_CH.v=0}}}
{const w0=drawWorld;drawWorld=function(){const r=w0.apply(this,arguments);try{const c=ctx,t=S.t;if(!S.pet&&!FLTK.fx.length&&!FLTK.mo.length)return r;
 /* stunned monsters: golden feathers and stars circle their heads */for(const e of S.en){if(!(e.flst>0))continue;const h=e.h||80,top=e.y-h,a=Math.min(1,e.flst/.4);c.save();c.globalAlpha=a;
  c.save();c.globalCompositeOperation='lighter';c.translate(e.x,e.y-4);c.scale(1,.28);c.beginPath();c.arc(0,0,h*.5,0,TAU);c.strokeStyle='rgba(255,212,90,.5)';c.lineWidth=6;c.stroke();c.restore();
  for(let i=0;i<4;i++){const an=t*4.4+i*TAU/4,x=e.x+Math.cos(an)*30,y=top-12+Math.sin(an)*8;if(i%2){pStar4(c,x,y,7,'#fff2b0')}else{c.save();c.translate(x,y);c.rotate(an);c.beginPath();c.ellipse(0,0,3,9,0,0,TAU);pF(c,pLin(c,0,-9,0,9,['#fff4dc','#ffd860','#c8461c']),1.2);c.restore()}}c.restore()}
 /* morsels in flight */for(const m of FLTK.mo){if(m.t<0)continue;const v=Math.min(1,m.t/m.d),x=m.x0+(KX+10-m.x0)*pS(v),y=m.y0+(GY-150-m.y0)*v-Math.sin(v*Math.PI)*170;m.r+=.05;c.save();c.globalCompositeOperation='lighter';pGlow(c,x,y,26,'#ffd45a',.4);c.restore();fltFoodD(c,m.k,x,y,34,m.r)}
 for(const f of FLTK.fx){const u=Math.min(1,f.t/f.ml);
  if(f.k==='gob'){/* a thunderous shockwave of feathers and leaves rolls across the field */c.save();c.globalCompositeOperation='lighter';for(let j=0;j<4;j++){const v=Math.max(0,Math.min(1,u*1.4-j*.12));if(v<=0||v>=1)continue;c.beginPath();c.arc(f.x,f.y,40+pS(v)*(W-f.x+200),-1.25,1.25);c.strokeStyle=`rgba(255,${200+j*12},${90+j*30},${.8*(1-v)})`;c.lineWidth=30*(1-v)+5;c.stroke();c.strokeStyle=`rgba(255,250,220,${.6*(1-v)})`;c.lineWidth=5;c.stroke()}
    const q=c.createLinearGradient(f.x,0,W,0);q.addColorStop(0,`rgba(255,200,90,${.24*(1-u)})`);q.addColorStop(1,'rgba(255,140,40,0)');c.fillStyle=q;c.fillRect(f.x,0,W-f.x,H);c.restore();
   c.save();for(let j=0;j<18;j++){const v=Math.max(0,Math.min(1,u*1.3-(j%6)*.05)),an=-1.1+(j/17)*2.2,d=40+pS(v)*(700+((j*53)%7)*60),x=f.x+Math.cos(an)*d,y=f.y+Math.sin(an)*d*.6+v*v*80;if(v<=0||v>=1)continue;c.globalAlpha=1-v;c.save();c.translate(x,y);c.rotate(an+v*8);if(j%3===0)flpLeafD(c,0,0,18,0,0);else{c.beginPath();c.ellipse(0,0,4,13,0,0,TAU);pF(c,pLin(c,0,-13,0,13,['#fff4dc','#ffd860','#3a1a10','#ff9a3a']),1.4)}c.restore()}c.restore();
   if(u<.3)fltBolt(c,f.x+80,f.y-260,f.x+30,f.y-40,Math.floor(u*40),'#ffd45a',3)}
  else if(f.k==='fea'){c.save();c.globalAlpha=1-u;c.translate(f.x,f.y-u*30);c.rotate(f.a+u*6);c.beginPath();c.ellipse(0,0,4,12,0,0,TAU);pF(c,pLin(c,0,-12,0,12,['#fff4dc','#ffd860','#c8461c']),1.4);c.restore()}
  else if(f.k==='yum'||f.k==='bon'){c.save();c.globalAlpha=1-u*u;c.font=`800 ${f.k==='bon'?24:22}px Poppins,system-ui`;c.textAlign='center';c.lineWidth=5;c.strokeStyle='#2a1006';const s=`+${f.n}`,y=f.y-u*40;c.strokeText(s,f.x,y);c.fillStyle=f.k==='bon'?'#ffe27a':'#ffb45a';c.fillText(s,f.x,y);c.restore()}}
 /* Banquet: a warm glow and drifting leaves at the knight's feet */const p=S.pet;if(p&&fltOn(p)&&S.t<(p.banT||-9)){const left=(p.banT-S.t)/FLTK.ban;c.save();c.globalCompositeOperation='lighter';pGlow(c,KX+6,GY-60,170,'#ffb43a',.18+.06*Math.sin(t*6));c.restore();
  for(let i=0;i<6;i++){const v=((t*.6+i/6)%1),x=KX-60+i*26+Math.sin(t*2+i)*8,y=GY-10-v*200;c.globalAlpha=Math.sin(v*Math.PI)*Math.min(1,left*4);flpLeafD(c,x,y,12,t*2+i,i%3);c.globalAlpha=1}}
 }catch(e){}return r}}
/* HUD: a Mythic ring on the power icon, heal pips and the Banquet timer */
{const hd0=drawHUD;drawHUD=function(){const r=hd0.apply(this,arguments);try{const p=S.pet;if(!fltOn(p)||S.mode==='title')return r;const c=ctx,x=W/2+220+52,y=H-56,R=28,t=S.t,A=PDEF[p.id].ab;
  c.save();const rg=c.createLinearGradient(x-R,y-R,x+R,y+R);rg.addColorStop(0,'#ffd45a');rg.addColorStop(.5,'#ff8a2a');rg.addColorStop(1,'#c8281a');c.strokeStyle=rg;c.lineWidth=2.4;c.beginPath();c.arc(x,y,R+6,0,TAU);c.stroke();
  const br=(t-(p.brk||-9));if(br<.5){c.strokeStyle=`rgba(255,92,108,${1-br/.5})`;c.lineWidth=5;c.beginPath();c.arc(x,y,R+2,0,TAU);c.stroke()}
  c.font='500 13px Poppins,system-ui';c.textAlign='left';
  const ban=S.t<(p.banT||-9);if(ban){const left=(p.banT-S.t)/FLTK.ban,bx2=x+R+14,bw=110;c.fillStyle='#2a1810';c.beginPath();c.roundRect?c.roundRect(bx2,y+8,bw,10,5):c.rect(bx2,y+8,bw,10);c.fill();
   const q=c.createLinearGradient(bx2,0,bx2+bw,0);q.addColorStop(0,'#ff8a2a');q.addColorStop(1,'#ffe27a');c.fillStyle=q;c.beginPath();c.roundRect?c.roundRect(bx2,y+8,bw*left,10,5):c.rect(bx2,y+8,bw*left,10);c.fill();c.fillStyle='#ffe8b0';c.fillText('Banquet!',bx2+bw+8,y+18)}
  else{c.fillStyle='#ffe0a8';c.fillText(p.ready?'Gobble with Shift!':'A typo takes 1 word off',x+R+14,y+18)}
  c.restore()}catch(e){}return r}}

/* ---------- styles: the harvest reveal card, the refund note ---------- */
{const st=document.createElement('style');st.textContent=`
.pthx-fl{background:#06040a}.pthx-fl .ptskip{z-index:3}
.ptrv.flhv .phc{border:2px solid transparent;background:linear-gradient(180deg,#2a1420f4,#120a10f8) padding-box,linear-gradient(120deg,#ffe27a,#ff9a2a 35%,#e8401a 65%,#ffd45a) border-box;box-shadow:0 20px 60px #000c,0 0 50px #ff8a2a33}
.ptrv.flhv .phc-rib{color:#2a1006;background:linear-gradient(90deg,#ffe27a,#ff9a2a 50%,#ffd45a);border-color:#fff2c0;letter-spacing:2.5px}
.ptrv.flh-h .phc-rib{color:#fff;background:linear-gradient(90deg,#c8281a,#ff8a2a 50%,#ffd45a);text-shadow:0 1px 0 #3a0a0a;letter-spacing:3px}
.ptrv.flhv .phc-n{background-image:linear-gradient(100deg,transparent 0%,transparent 42%,rgba(255,255,255,.95) 50%,transparent 58%,transparent 100%),linear-gradient(180deg,#fffbe8 0%,#ffd27a 45%,#ff8a2a 100%);filter:drop-shadow(0 2px 0 #3a1406) drop-shadow(0 0 1px #3a1406) drop-shadow(0 0 18px rgba(255,140,40,.5))}
.flh-sub{display:block;font:italic 600 16px/1.2 var(--ui);color:#ffcf8a;margin-top:4px}
.ptrv.flhv .phc-ab b{color:#ffd27a}.ptrv.flhv .phc-ab{border-color:#6a3a1e}.ptrv.flhv .phc-ms span{border-color:#6a3a1e;background:#1e0e12}
.ptrv.flhv .phc-prog small svg{width:13px;height:13px;color:#ffa53a;vertical-align:-2px}
.flh-eq{background:linear-gradient(180deg,#fff0a0,#ffb43a 55%,#d8641a)!important;color:#2a1006!important;box-shadow:0 4px 0 #7a2e0a!important}
.flprf{position:absolute;left:50%;top:120px;z-index:400;display:flex;align-items:center;gap:14px;padding:12px 22px 12px 12px;border-radius:18px;transform:translate(-50%,-20px) scale(.92);opacity:0;pointer-events:none;
 background:linear-gradient(180deg,#2a1420f6,#120a10f8) padding-box,linear-gradient(120deg,#ffe27a,#ff9a2a,#e8401a) border-box;border:2px solid transparent;box-shadow:0 14px 40px #000b;transition:opacity .3s ease,transform .45s cubic-bezier(.3,1.5,.5,1)}
.flprf.on{opacity:1;transform:translate(-50%,0) scale(1)}.flprf canvas{width:72px;height:72px}.flprf b{display:block;font:400 30px 'Pirata One',Georgia,serif;color:#ffd45a}.flprf small{display:block;max-width:320px;font:600 13px var(--ui);color:#f4e2c8}
@media (prefers-reduced-motion:reduce){.flprf{transition:none}}
`;document.head.appendChild(st)}
/* ---------- in the Companion Hall, petting a harvest companion gets its own voice: a chitter, a yip, a soft gobble ---------- */
{const b0=ptPetsBind;ptPetsBind=function(){const r=b0.apply(this,arguments);try{const cv=$('ptcv');if(cv&&!cv._flv){cv._flv=1;let last=0;cv.addEventListener('click',()=>{const id=PTX.sel;if(!flpIs(id)||!petOwned(id)||ptRM())return;const n=performance.now();if(n-last<900)return;last=n;
  const A=phAudio();if(!A)return;if(id==='flsquir')FLHS.chitter(A,.05);else if(id==='flfox')FLHS.yip(A,.05);else FLHS.gobble(A,.05,false);setTimeout(()=>phStop(A),1000)})}}catch(e){}return r}}
