/* ===== RUNESTONE TOWER DEFENSE 10.2: the Phantom Lantern, art (99c, after 98v) =====
   The fourteenth tower (UPDATE_10_2_PLAN.md section 2): a haunted iron lantern hanging from a gnarled grave-post over a small stone
   crypt. A hooded spectral keeper glows inside the glass; a soul jar on the pad fills with the souls the lantern harvests; the crypt's
   arched door glows when a phantom is ready and swings open when one rises.
   Tiers: 1 a weathered post, a plain iron lantern, a mossy crypt, a headstone; 2 taller, a gold-banded lantern with a crown cap, an iron
   band and spike on the post, crypt pillars, candles; 3 Grave Chill: a gold-trimmed crypt with a glowing rune, frost crystals, glowing
   mushrooms, a crescent-moon finial and a hanging charm; 4 Mythic (violet stone, violet iron, violet ghost light, gems, orbiting runes);
   5 Celestial (marble, white gold, pale driftwood, white-gold light, a star finial, wings and halo).
   Plugs into the shared 95c pipeline (RPPAL/RPLAY/RPPULSE/RPWING/RPHALO + wrapped rpBodyArt, rpGlowList, rpTowerParts, rpTowerWarm),
   so the build / upgrade / ascension animations, icons, mastery recolours and the 97k glow layer work as for every tower.
   Baked (rpSpr): the static body (pad, post, crypt, props, the empty jar), the lantern (per tier), its glow, the door panel, the jar's
   liquid and its glass front; the wisp, soul, phantom knight, Reaper, scythe, slash, haunt and burst sprites. Per tower and frame: about
   eight drawImage calls and a few short paths. No shadowBlur, no ctx.filter.
   Live: the lantern sways from its hook (99d adds a kick when it fires), the keeper's light flickers and flares on a shot, the jar fills
   (tw.jarK) and bubbles, the crypt door glows while a phantom is ready (tw.ready) and opens when one rises (tw.door).
   API (used by 99d; positions in model units relative to the pad centre, 99d multiplies by RPG.k)
     rplnHook(tier) the lantern's hook {x,y};  rplnGlass(tier) the centre of the glass (the keeper);  rplnDoorP(tier) the crypt door
     (bottom centre) {x,y,h};  rplnJarP(tier) the soul jar's mouth {x,y}
     rplnWisp(g,x,y,a,tier,t,sc,al)        a soul wisp flying in direction a
     rplnSoulDraw(g,x,y,tier,t,al)         a harvested soul (pale, smaller)
     rplnKnight(g,x,y,dir,tier,t,al,sw)    the phantom knight (feet at x,y; dir +1 right / -1 left; sw = 0..1 sword swing)
     rplnReaper(g,x,y,dir,tier,t,al,sw)    the Reaper (feet at x,y; sw = 0..1 scythe swing)
     rplnSlash(g,x,y,u,tier,dir,big)       a cut, u = 0..1
     rplnHauntDraw(g,x,y,w,k,t,tier)       the haunt on a monster (feet x,y; w its width; k 0..1)
     rplnBurst(g,x,y,u,tier)               a wisp hit, u = 0..1
     rplnShadow(g,x,y,s,a)                 a soft shadow
     rplnGh(tier)                          the ghost-light colours {w,l,m,d,k} */
RPTW.lant={n:'Phantom Lantern',role:'Haunt',col:'#5af0c8'};
RPSKIN.lant=['base'];
RPPAL.lant={base:{stone:RPSTONE.base,iron:'#3c3852',ironL:'#6e6890',ironD:'#1c1828',trim:'#ffd45a',trimL:'#fff0a8',trimD:'#b07a1a',
 wood:'#5e4334',woodL:'#8a6a52',woodD:'#2e1e16',moss:'#4f8a3e',mossL:'#7cc24e',glow:'#5af0c8',glow2:'#c8fff0',rune:'#5af0c8'}};
/* per tier: crypt centre cx, front base cb, half width cw, wall ch, roof rise rh, depth dx/dy; post x px, base pb, top pt; hook hx/hy;
   lantern scale ls; jar jx/jy/js; top; tier 4-5 gems inl */
RPLAY.lant=[0,
 {cx:-5,cb:15,cw:21,ch:24,rh:10,dx:10,dy:-7,px:30,pb:-3,pt:-97,hx:-3,hy:-85,ls:1.15,jx:34,jy:13,js:.95,top:106,runes:[]},
 {cx:-5,cb:15,cw:22.5,ch:27,rh:11,dx:10,dy:-7,px:31,pb:-3,pt:-106,hx:-3,hy:-94,ls:1.25,jx:35,jy:13,js:1.02,top:118,runes:[]},
 {cx:-5,cb:15,cw:24,ch:29,rh:12,dx:11,dy:-7.5,px:32,pb:-3,pt:-115,hx:-3,hy:-101.5,ls:1.35,jx:36,jy:13,js:1.08,top:128,runes:[]},
 {cx:-5,cb:15,cw:24.5,ch:30,rh:12.5,dx:11,dy:-7.5,px:32,pb:-3,pt:-119,hx:-3,hy:-105,ls:1.4,jx:36,jy:13,js:1.1,top:136,runes:[],inl:[[-5,-4,4.2],[-30,8,3.4],[20,8,3.4]]},
 {cx:-5,cb:15,cw:25,ch:31,rh:13,dx:11,dy:-7.5,px:33,pb:-3,pt:-123,hx:-3,hy:-109,ls:1.45,jx:36,jy:13,js:1.12,top:146,runes:[],inl:[[-5,-4,4.4],[-31,8,3.6],[21,8,3.6]]}];
RPPULSE.lant=[1.7,.24];RPWING.lant=[32,-34];RPHALO.lant=[-156,24];
const rplnT=t=>Math.max(1,Math.min(5,t|0||1));
/* ghost light per tier: white, light, mid, deep, the dark inside of the glass */
const rplnGh=tier=>tier>=5?{w:'#ffffff',l:'#fff4c8',m:'#a8ecff',d:'#4a8ac8',k:'#18223e'}:tier===4?{w:'#fdf2ff',l:'#e8b8ff',m:'#b878ff',d:'#6a2ab0',k:'#1e0a36'}
 :{w:'#f0fff8',l:'#a6ffe0',m:'#3ee6be',d:'#139884',k:'#082a2c'};
/* metals and wood per tier: iron [light, mid, dark], gold [light, mid, dark], wood [light, mid, dark] */
const rplnMet=(tier,P)=>tier>=5?{ir:['#fffaf0','#ecd9a8','#a8823a'],gd:['#fffbe6','#ffe27a','#c99a2a'],wd:['#fffaf2','#e6d6bc','#a8906c'],moss:['#cfe8b8','#9acb7a']}
 :tier===4?{ir:['#a496d0','#5c4e90','#2a2050'],gd:['#fff0a8','#ffd45a','#b07a1a'],wd:['#8a6aac','#54386e','#2a1838'],moss:['#9a7ac8','#6a4aa0']}
 :{ir:[P.ironL,P.iron,P.ironD],gd:[P.trimL,P.trim,P.trimD],wd:[P.woodL,P.wood,P.woodD],moss:[P.mossL,P.moss]};
/* ---------- the crypt ---------- */
function rplnBlocks(g,x0,y0,x1,y1,rows,cols,S,seed){const h=(y1-y0)/rows;for(let r=0;r<rows;r++){const off=(r%2)*.5,w=(x1-x0)/cols;
  for(let c=-1;c<cols;c++){let a=x0+(c+off)*w,b=a+w;a=Math.max(x0,a)+.6;b=Math.min(x1,b)-.6;if(b-a<2)continue;const n=seed*17+r*5+c,ya=y0+r*h+.6,yb=y0+(r+1)*h-.6;
   g.fillStyle=rpMix(S.d,S.l,.35+(rpR(n)-.5)*.3+(1-r/rows)*.15);g.fillRect(a,ya,b-a,yb-ya);
   g.fillStyle='rgba(255,255,255,.22)';g.fillRect(a,ya,b-a,1);g.fillStyle='rgba(18,8,31,.25)';g.fillRect(a,yb-1,b-a,1)}}}
function rplnCrypt(g,L,P,tier,M,G){const S=P.stone,{cx,cb,cw,ch,rh,dx,dy}=L,x0=cx-cw,x1=cx+cw,yt=cb-ch,ov=3;
 /* plinth step under the crypt */
 g.beginPath();g.moveTo(x0-3,cb+3);g.lineTo(x1+3,cb+3);g.lineTo(x1+3+dx,cb+3+dy);g.lineTo(x1+3+dx,cb-1+dy);g.lineTo(x0-3+dx,cb-1+dy);g.lineTo(x0-3,cb-1);g.closePath();g.fillStyle=S.d;g.fill();rpOut(g,2);
 g.beginPath();g.rect(x0-3,cb-1,cw*2+6,4);g.fillStyle=rpVG(g,cb-1,cb+3,S.l,S.m);g.fill();rpOut(g,1.8);
 /* side wall (back right, in shade) */
 g.beginPath();g.moveTo(x1,cb);g.lineTo(x1+dx,cb+dy);g.lineTo(x1+dx,yt+dy);g.lineTo(x1,yt);g.closePath();g.fillStyle=rpVG(g,yt,cb,S.m,S.d);g.fill();
 g.save();g.clip();g.strokeStyle='rgba(18,8,31,.3)';g.lineWidth=1;for(let k=1;k<4;k++){const y=yt+ch*k/4;g.beginPath();g.moveTo(x1,y);g.lineTo(x1+dx,y+dy);g.stroke()}g.restore();
 g.beginPath();g.moveTo(x1,cb);g.lineTo(x1+dx,cb+dy);g.lineTo(x1+dx,yt+dy);g.lineTo(x1,yt);g.closePath();rpOut(g,2.2);
 /* front wall: masonry */
 g.beginPath();g.rect(x0,yt,cw*2,ch);g.fillStyle=S.k;g.fill();rplnBlocks(g,x0,yt,x1,cb,tier>=3?5:4,4,S,tier);
 g.save();g.beginPath();g.rect(x0,yt,cw*2,ch);g.clip();const q=g.createLinearGradient(x0,0,x1,0);q.addColorStop(0,'rgba(255,255,255,.1)');q.addColorStop(.5,'rgba(255,255,255,0)');q.addColorStop(1,'rgba(18,8,31,.3)');g.fillStyle=q;g.fillRect(x0,yt,cw*2,ch);g.restore();
 g.beginPath();g.rect(x0,yt,cw*2,ch);rpOut(g,2.4);
 /* corner pillars (tier 2+) */
 if(tier>=2)for(const x of [x0+2.6,x1-2.6]){g.beginPath();g.rect(x-3,yt+2,6,ch-2);g.fillStyle=rpHG(g,x-3,x+3,S.l,S.m,S.d);g.fill();rpOut(g,1.6);
  g.beginPath();g.rect(x-4,yt,8,3);g.fillStyle=tier>=3?M.gd[1]:S.l;g.fill();rpOut(g,1.3);g.beginPath();g.rect(x-4,cb-3,8,3);g.fillStyle=S.m;g.fill();rpOut(g,1.3)}
 /* cornice ledge */
 g.beginPath();g.rect(x0-ov,yt-4,cw*2+ov*2,4.4);g.fillStyle=rpVG(g,yt-4,yt,S.l,S.m);g.fill();rpOut(g,1.8);
 g.beginPath();g.moveTo(x1+ov,yt-4);g.lineTo(x1+ov+dx,yt-4+dy);g.lineTo(x1+ov+dx,yt+.4+dy);g.lineTo(x1+ov,yt+.4);g.closePath();g.fillStyle=S.d;g.fill();rpOut(g,1.6);
 /* roof: the side slope, then the front pediment */
 const ry=yt-4,ax=cx,ay=ry-rh;
 g.beginPath();g.moveTo(ax,ay);g.lineTo(ax+dx,ay+dy);g.lineTo(x1+ov+dx+1,ry+dy);g.lineTo(x1+ov+1,ry);g.closePath();g.fillStyle=rpVG(g,ay,ry,S.m,S.d);g.fill();
 g.save();g.clip();g.strokeStyle='rgba(18,8,31,.28)';g.lineWidth=1.1;for(let k=1;k<4;k++){const u=k/4;g.beginPath();g.moveTo(ax+(x1+ov+1-ax)*u,ay+(ry-ay)*u);g.lineTo(ax+(x1+ov+1-ax)*u+dx,ay+(ry-ay)*u+dy);g.stroke()}g.restore();
 g.beginPath();g.moveTo(ax,ay);g.lineTo(ax+dx,ay+dy);g.lineTo(x1+ov+dx+1,ry+dy);g.lineTo(x1+ov+1,ry);g.closePath();rpOut(g,2);
 g.beginPath();g.moveTo(x0-ov-1,ry);g.lineTo(ax,ay);g.lineTo(x1+ov+1,ry);g.closePath();g.fillStyle=rpVG(g,ay,ry,S.l,S.m);g.fill();rpOut(g,2.4);
 g.beginPath();g.moveTo(x0+2,ry-1.6);g.lineTo(ax,ay+3.4);g.lineTo(x1-2,ry-1.6);g.closePath();g.fillStyle=rpA(S.d,.55);g.fill();g.lineWidth=1;g.strokeStyle='rgba(18,8,31,.4)';g.stroke();
 g.strokeStyle='rgba(255,255,255,.45)';g.lineWidth=1.2;g.beginPath();g.moveTo(x0-ov+1,ry-.8);g.lineTo(ax-1,ay+1.2);g.stroke();
 /* the emblem in the pediment: a carved skull (tier 1-2), a glowing rune ring in gold (tier 3+) */
 const ey=ry-rh*.42;
 if(tier>=3){g.beginPath();g.arc(ax,ey,4.2,0,TAU);g.fillStyle=rpHG(g,ax-4,ax+4,M.gd[0],M.gd[1],M.gd[2]);g.fill();rpOut(g,1.4);g.beginPath();g.arc(ax,ey,2.4,0,TAU);g.fillStyle=G.m;g.fill();g.lineWidth=.9;g.strokeStyle=RPTO;g.stroke();g.fillStyle=G.w;g.beginPath();g.arc(ax-.6,ey-.6,.9,0,TAU);g.fill()}
 else{g.beginPath();g.ellipse(ax,ey,3.2,2.8,0,0,TAU);g.fillStyle=tier>=2?M.gd[1]:S.l;g.fill();rpOut(g,1.2);g.fillStyle=RPTO;g.beginPath();g.arc(ax-1.2,ey-.2,.8,0,TAU);g.arc(ax+1.2,ey-.2,.8,0,TAU);g.fill()}
 /* finial on the ridge */
 if(tier>=2){g.beginPath();g.moveTo(ax-2.4,ay+1);g.lineTo(ax,ay-6);g.lineTo(ax+2.4,ay+1);g.closePath();g.fillStyle=rpHG(g,ax-3,ax+3,M.gd[0],M.gd[1],M.gd[2]);g.fill();rpOut(g,1.2)}
 /* the doorway: a stone arch round a dark recess (the door panel is drawn live) */
 const D=rplnDoorG(L);g.beginPath();g.moveTo(D.x-D.w-3,cb);g.lineTo(D.x-D.w-3,cb-D.h+D.w);g.arc(D.x,cb-D.h+D.w,D.w+3,Math.PI,0);g.lineTo(D.x+D.w+3,cb);g.closePath();g.fillStyle=rpHG(g,D.x-D.w-3,D.x+D.w+3,S.l,S.m,S.d);g.fill();rpOut(g,2);
 for(let i=0;i<5;i++){const a=Math.PI+(i+.5)/5*Math.PI;g.beginPath();g.moveTo(D.x+Math.cos(a)*(D.w+.4),cb-D.h+D.w+Math.sin(a)*(D.w+.4));g.lineTo(D.x+Math.cos(a)*(D.w+3),cb-D.h+D.w+Math.sin(a)*(D.w+3));g.lineWidth=1;g.strokeStyle='rgba(18,8,31,.45)';g.stroke()}
 rplnArch(g,D,cb,0);g.fillStyle=G.k;g.fill();rpOut(g,1.6);
 /* keystone (gold with a gem at tier 3+) */
 {const ky=cb-D.h-2.6;g.beginPath();g.moveTo(D.x-2.6,ky-1.6);g.lineTo(D.x+2.6,ky-1.6);g.lineTo(D.x+1.8,ky+3.4);g.lineTo(D.x-1.8,ky+3.4);g.closePath();g.fillStyle=tier>=3?M.gd[1]:S.l;g.fill();rpOut(g,1.2);
  if(tier>=3){g.beginPath();g.arc(D.x,ky+.8,1.1,0,TAU);g.fillStyle=G.l;g.fill()}}
 /* moss and ivy */
 rpMoss(g,x0+3,cb-1,.62,7);rpMoss(g,x1+dx-2,yt+dy+2,.5,9);if(tier<5)rpMoss(g,ax+4,ay+5,.45,4);
 if(tier>=3){g.strokeStyle=RPTO;g.lineWidth=3;g.beginPath();g.moveTo(x0+1,yt+1);g.quadraticCurveTo(x0+5,yt+8,x0+2,yt+15);g.stroke();g.strokeStyle=M.moss[1];g.lineWidth=1.4;g.stroke();
  for(const [x,y] of [[x0+3,yt+4],[x0+4.6,yt+9],[x0+2.6,yt+14]]){g.beginPath();g.ellipse(x,y,2.4,1.5,.5,0,TAU);g.fillStyle=M.moss[0];g.fill();g.lineWidth=.9;g.strokeStyle=RPTO;g.stroke()}}
 /* tier 3+: frost crystals at the corners (Grave Chill) */
 if(tier>=3)for(const [x,y,s,k] of [[x0-1,cb+1,1,-1],[x1+dx-1,cb+dy+1,.85,1]]){for(const [a,h] of [[-.35*k,9],[.05*k,12],[.42*k,7]]){g.save();g.translate(x,y);g.rotate(a);g.beginPath();g.moveTo(-2*s,0);g.lineTo(0,-h*s);g.lineTo(2*s,0);g.closePath();
   g.fillStyle=rpVG(g,-h*s,0,G.w,G.m);g.fill();g.lineWidth=1.1;g.strokeStyle=RPTO;g.stroke();g.restore()}}}
/* the doorway's arch (x, half width, height) and its path */
function rplnDoorG(L){return{x:L.cx,w:L.cw*.42,h:L.ch*.74}}
function rplnArch(g,D,cb,inset){const w=D.w-inset;g.beginPath();g.moveTo(D.x-w,cb);g.lineTo(D.x-w,cb-D.h+D.w);g.arc(D.x,cb-D.h+D.w,w,Math.PI,0);g.lineTo(D.x+w,cb);g.closePath()}
/* ---------- the grave-post ---------- */
function rplnPost(g,L,P,tier,M){const W=M.wd,{px,pb,pt,hx,hy}=L,lw=tier>=3?9.5:8.6;
 /* the trunk: a crooked post, slightly leaning */
 const mid=[px+4,(pb+pt)/2];rpBeam(g,px,pb,px-1,pt+6,lw,W[1],W[0],mid);
 /* bark grooves and knots */
 g.lineWidth=1.1;g.strokeStyle=rpA(W[2],.9);for(let k=0;k<5;k++){const u=.12+k*.17,y=pb+(pt-pb)*u,x=px+Math.sin(u*Math.PI)*2.4+(k%2?1.5:-1.5);g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+1.2,y-5,x-.4,y-10);g.stroke()}
 for(const u of [.32,.66]){const y=pb+(pt-pb)*u,x=px+Math.sin(u*Math.PI)*2.4;g.beginPath();g.ellipse(x+1.4,y,1.8,2.6,0,0,TAU);g.fillStyle=W[2];g.fill();g.lineWidth=.9;g.strokeStyle=RPTO;g.stroke()}
 /* roots at the base */
 for(const [x,c] of [[-9,-4],[8,5]]){rpBeam(g,px,pb-1,px+x,pb+4,3,W[1],null,[px+c,pb+3])}
 /* a broken twig stub on the trunk */
 rpBeam(g,px+3,pb+(pt-pb)*.45,px+11,pb+(pt-pb)*.5,2.6,W[1],W[0]);
 /* the arm: out to the left from near the top, gnarled, ending at the hook */
 const ay=pt+12;rpBeam(g,px-1,ay,hx+5,hy-3,lw*.62,W[1],W[0],[(px+hx)/2+4,ay-14]);
 rpBeam(g,(px+hx)/2+6,ay-8,(px+hx)/2+1,ay-18,2.2,W[1],null);
 /* an iron band where the arm meets the post (tier 2+), gold at tier 3+ */
 if(tier>=2){const C=tier>=3?M.gd:M.ir;g.beginPath();g.ellipse(px-1,ay+1,lw*.62,2.6,0,0,TAU);g.lineWidth=5;g.strokeStyle=RPTO;g.stroke();g.lineWidth=2.6;g.strokeStyle=C[1];g.stroke();rpRiv(g,px-1,ay+3.2,1.2,C[0])}
 /* the hook: iron, from the arm's end down to the chain */
 g.beginPath();g.moveTo(hx+5,hy-3);g.quadraticCurveTo(hx+1,hy-8,hx-1,hy-3);g.quadraticCurveTo(hx-2,hy+1,hx,hy+1.6);g.lineWidth=4.4;g.strokeStyle=RPTO;g.stroke();g.lineWidth=2;g.strokeStyle=M.ir[0];g.stroke();
 /* the top of the post */
 const ty=pt+4;
 if(tier>=5){/* a white-gold star */g.beginPath();for(let i=0;i<10;i++){const a=i*Math.PI/5-Math.PI/2,r=i%2?3.4:8;g.lineTo(px-1+Math.cos(a)*r,ty-8+Math.sin(a)*r)}g.closePath();g.fillStyle=rpHG(g,px-9,px+7,M.gd[0],M.gd[1],M.gd[2]);g.fill();rpOut(g,1.6)}
 else if(tier>=3){/* a crescent moon */g.beginPath();g.arc(px-1,ty-8,7,.9,TAU-.9+Math.PI*.2,false);g.arc(px+2,ty-10,5.4,TAU-.6+Math.PI*.2,1.2,true);g.closePath();g.fillStyle=rpHG(g,px-8,px+6,M.gd[0],M.gd[1],M.gd[2]);g.fill();rpOut(g,1.6);
  if(tier===4)rpGemArt(g,px-1,ty-2.5,2.2,RPASC[4])}
 else if(tier===2){g.beginPath();g.moveTo(px-4.4,ty);g.lineTo(px-1,ty-12);g.lineTo(px+2.4,ty);g.closePath();g.fillStyle=rpHG(g,px-5,px+3,M.ir[0],M.ir[1],M.ir[2]);g.fill();rpOut(g,1.6)}
 else{g.beginPath();g.moveTo(px-5,pt+8);g.lineTo(px-3,pt);g.lineTo(px,pt+4);g.lineTo(px+2,pt-1);g.lineTo(px+4,pt+8);g.closePath();g.fillStyle=W[1];g.fill();rpOut(g,1.6)}}
/* ---------- pad props ---------- */
function rplnHeadstone(g,x,y,s,S,cross){g.save();g.translate(x,y);g.scale(s,s);
 if(cross){g.beginPath();g.rect(-1.8,-15,3.6,15);g.rect(-6,-11,12,3.4);g.fillStyle=rpHG(g,-6,6,S.l,S.m,S.d);g.fill();rpOut(g,1.6)}
 else{g.beginPath();g.moveTo(-6,0);g.lineTo(-6,-10);g.arc(0,-10,6,Math.PI,0);g.lineTo(6,0);g.closePath();g.fillStyle=rpHG(g,-6,6,S.l,S.m,S.d);g.fill();rpOut(g,1.8);
  g.strokeStyle='rgba(18,8,31,.45)';g.lineWidth=1;g.beginPath();g.moveTo(0,-13);g.lineTo(0,-6);g.moveTo(-2.6,-10.6);g.lineTo(2.6,-10.6);g.stroke();
  g.strokeStyle='rgba(255,255,255,.4)';g.beginPath();g.arc(0,-10,4.6,Math.PI*1.1,Math.PI*1.5);g.stroke()}
 g.restore()}
function rplnCandle(g,x,y,h,G,M){g.beginPath();g.rect(x-1.8,y-h,3.6,h);g.fillStyle=rpHG(g,x-2,x+2,'#fff8e8','#f0e0c0','#b8a080');g.fill();rpOut(g,1.2);
 g.beginPath();g.ellipse(x,y-h,1.8,.8,0,0,TAU);g.fillStyle='#fffaf0';g.fill();
 g.beginPath();g.moveTo(x,y-h-6);g.quadraticCurveTo(x+2.4,y-h-2,x,y-h-.6);g.quadraticCurveTo(x-2.4,y-h-2,x,y-h-6);g.fillStyle=G.l;g.fill();g.lineWidth=.9;g.strokeStyle=RPTO;g.stroke();
 g.fillStyle=G.w;g.beginPath();g.ellipse(x,y-h-2.2,.8,1.4,0,0,TAU);g.fill()}
function rplnShroom(g,x,y,s,G){g.save();g.translate(x,y);g.scale(s,s);g.beginPath();g.rect(-1.4,-6,2.8,6);g.fillStyle='#e8f0e8';g.fill();rpOut(g,1.1);
 g.beginPath();g.moveTo(-5,-5);g.quadraticCurveTo(-4.6,-11,0,-11);g.quadraticCurveTo(4.6,-11,5,-5);g.closePath();g.fillStyle=rpVG(g,-11,-5,G.l,G.d);g.fill();rpOut(g,1.2);
 g.fillStyle=G.w;for(const [a,b] of [[-2,-8.4],[1.6,-9],[2.6,-6.6]]){g.beginPath();g.arc(a,b,.8,0,TAU);g.fill()}g.restore()}
/* ---------- the soul jar (back half baked into the body; liquid and glass front live) ---------- */
function rplnJarPath(g,x,y,s){const w=7*s,h=15*s,n=3.6*s;g.beginPath();g.moveTo(x-w,y-2*s);g.quadraticCurveTo(x-w-1.4*s,y-h*.55,x-w+1,y-h+2*s);g.quadraticCurveTo(x-n-1.5*s,y-h-1*s,x-n,y-h-2.6*s);g.lineTo(x+n,y-h-2.6*s);
 g.quadraticCurveTo(x+n+1.5*s,y-h-1*s,x+w-1,y-h+2*s);g.quadraticCurveTo(x+w+1.4*s,y-h*.55,x+w,y-2*s);g.quadraticCurveTo(x,y+2.4*s,x-w,y-2*s);g.closePath()}
function rplnJarBack(g,L,G){const x=L.jx,y=L.jy,s=L.js;g.fillStyle='rgba(8,4,20,.35)';g.beginPath();g.ellipse(x+2,y+1,9*s,3.2*s,0,0,TAU);g.fill();
 rplnJarPath(g,x,y,s);g.fillStyle=rpA(G.k,.9);g.fill();rpOut(g,2)}
function rplnJarFrontArt(g,tier,L,G,M){const x=L.jx,y=L.jy,s=L.js,w=7*s,h=15*s,n=3.6*s;
 /* glass sheen */
 g.fillStyle='rgba(255,255,255,.55)';g.beginPath();g.ellipse(x-w*.5,y-h*.5,1.3*s,4.6*s,-.08,0,TAU);g.fill();g.fillStyle='rgba(255,255,255,.3)';g.beginPath();g.ellipse(x+w*.55,y-h*.4,.9*s,2.6*s,0,0,TAU);g.fill();
 rplnJarPath(g,x,y,s);rpOut(g,2);
 /* the lid: an iron cap with a gold band and a ring */
 const ly=y-h-2.6*s;g.beginPath();g.rect(x-n-1.6*s,ly-3.6*s,(n+1.6*s)*2,3.8*s);g.fillStyle=rpHG(g,x-n-2,x+n+2,M.ir[0],M.ir[1],M.ir[2]);g.fill();rpOut(g,1.5);
 g.beginPath();g.rect(x-n-1.6*s,ly-1.6*s,(n+1.6*s)*2,1.4*s);g.fillStyle=M.gd[1];g.fill();g.lineWidth=.8;g.strokeStyle=RPTO;g.stroke();
 g.beginPath();g.arc(x,ly-5.2*s,1.8*s,0,TAU);g.lineWidth=2.6;g.strokeStyle=RPTO;g.stroke();g.lineWidth=1.2;g.strokeStyle=M.gd[0];g.stroke();
 /* a little skull label */
 g.beginPath();g.ellipse(x,y-h*.42,2.6*s,3.2*s,0,0,TAU);g.fillStyle='#f4ead2';g.fill();g.lineWidth=1;g.strokeStyle=RPTO;g.stroke();
 g.fillStyle=RPTO;g.beginPath();g.arc(x-.9*s,y-h*.45,.7*s,0,TAU);g.arc(x+.9*s,y-h*.45,.7*s,0,TAU);g.fill()}
const rplnJarFrontS=(tier,skin)=>{const L=RPLAY.lant[tier];return rpSpr('ln|jf|'+tier+'|'+skin,L.jx-14,L.jy-30,28,34,g=>rplnJarFrontArt(g,tier,L,rplnGh(tier),rplnMet(tier,rpPalT('lant',skin,tier))))};
/* the liquid: the whole jar full of soul-light (drawn cut off at the fill level with rpPutBelow) */
const rplnJarLiqS=tier=>{const L=RPLAY.lant[tier],G=rplnGh(tier);return rpSpr('ln|jl|'+tier,L.jx-10,L.jy-24,20,28,g=>{const x=L.jx,y=L.jy,s=L.js;g.save();rplnJarPath(g,x,y,s);g.clip();
 g.fillStyle=rpVG(g,y-15*s,y+2,G.l,G.d);g.fillRect(x-10,y-24,20,28);g.globalCompositeOperation='lighter';g.drawImage(rpGlowC(G.w),x-7*s,y-13*s,14*s,12*s);g.globalCompositeOperation='source-over';
 g.fillStyle=rpA(G.w,.8);for(const [a,b,r] of [[-2.4,-4,1.1],[2,-8,.9],[-.6,-11,.7],[3,-3,.6]]){g.beginPath();g.arc(x+a*s,y+b*s,r*s,0,TAU);g.fill()}g.restore()})};
/* ---------- static body ---------- */
function rplnBodyArt(g,tier,P){const L=RPLAY.lant[tier],M=rplnMet(tier,P),G=rplnGh(tier),S=P.stone;
 rpPadArt(g);
 /* back props: a headstone (and a cross from tier 2) */
 rplnHeadstone(g,-36,-6,tier>=3?1.05:.95,S,0);if(tier>=2)rplnHeadstone(g,-43,6,.8,S,1);
 rplnPost(g,L,P,tier,M);
 rplnCrypt(g,L,P,tier,M,G);
 /* front props: candles (tier 2+), glowing mushrooms (tier 3+), the jar */
 if(tier>=2){rplnCandle(g,-33,19,7,G,M);rplnCandle(g,-27,23,4.6,G,M)}
 if(tier>=3){rplnShroom(g,20,22,.8,G);rplnShroom(g,25,24,.6,G);rplnShroom(g,-40,15,.55,G)}
 rplnJarBack(g,L,G);
 if(tier>=4)rpAscArt(g,'lant',tier,P,L)}
{const b0=rpBodyArt;rpBodyArt=function(g,type,tier,P){if(type==='lant')return rplnBodyArt(g,tier,P);return b0.apply(this,arguments)}}
/* the static glows (baked into one layer that pulses): the lantern, the doorway, the jar, candles and mushrooms */
{const l0=rpGlowList;rpGlowList=function(type,tier,P,L){if(type!=='lant')return l0.apply(this,arguments);const G=[],A=(x,y,rx,ry,c,a)=>G.push([x,y,rx,ry,c,a]),Gh=rplnGh(tier),q=rplnGlass(tier),D=rplnDoorG(L);
 A(q.x,q.y,30*L.ls,30*L.ls,Gh.m,.55);A(D.x,L.cb-D.h*.45,14,14,Gh.m,.35);A(L.jx,L.jy-8,13,13,Gh.m,.4);
 if(tier>=2){A(-33,4,9,9,Gh.l,.5);A(-27,10,8,8,Gh.l,.45)}if(tier>=3){A(22,13,12,9,Gh.m,.5);A(0,L.cb-L.ch-8-L.rh*.42,9,9,Gh.l,.6)}
 if(tier>=4){const A4=RPASC[tier];for(const [x,y,z] of L.inl)A(x,y,z*3.4,z*3.4,A4.glow,.85);A(0,-L.top*.5,46,L.top*.5,A4.glow,.16)}return G}}
/* ---------- the lantern (baked, origin at the hook; swung live) ---------- */
/* model geometry of the lantern at scale ls: chain to the cap ring, cap, glass body, base plate, finial */
const rplnLG=ls=>{const c=5*ls,cap=9*ls,bh=22*ls,wt=10*ls,wb=8*ls;return{c,cap,bh,wt,wb,y0:c+cap,y1:c+cap+bh,base:3*ls,fin:5*ls}};
function rplnHook(tier){const L=RPLAY.lant[rplnT(tier)];return{x:L.hx,y:L.hy}}
function rplnGlass(tier){const L=RPLAY.lant[rplnT(tier)],q=rplnLG(L.ls);return{x:L.hx,y:L.hy+(q.y0+q.y1)/2}}
function rplnDoorP(tier){const L=RPLAY.lant[rplnT(tier)],D=rplnDoorG(L);return{x:D.x,y:L.cb,h:D.h}}
function rplnJarP(tier){const L=RPLAY.lant[rplnT(tier)];return{x:L.jx,y:L.jy-15*L.js}}
/* the keeper: a hooded figure of light inside the glass, holding a tiny flame */
function rplnKeeper(g,cx,cy,s,G){g.save();g.translate(cx,cy);g.scale(s,s);
 g.globalCompositeOperation='lighter';g.globalAlpha=.9;g.drawImage(rpGlowC(G.m),-12,-12,24,26);g.globalCompositeOperation='source-over';g.globalAlpha=1;
 /* robe and hood */
 g.beginPath();g.moveTo(-6,9);g.quadraticCurveTo(-6.4,0,-4.4,-3.4);g.quadraticCurveTo(-5,-9.6,0,-10.4);g.quadraticCurveTo(5,-9.6,4.4,-3.4);g.quadraticCurveTo(6.4,0,6,9);g.quadraticCurveTo(3,7.6,0,9.4);g.quadraticCurveTo(-3,7.6,-6,9);g.closePath();
 g.fillStyle=rpVG(g,-10,9,G.w,G.m);g.fill();g.lineWidth=1.2;g.strokeStyle=rpA(G.d,.95);g.stroke();
 /* the dark opening of the hood and two eyes */
 g.beginPath();g.ellipse(0,-4.6,2.9,3.3,0,0,TAU);g.fillStyle=G.k;g.fill();
 g.fillStyle=G.w;g.beginPath();g.ellipse(-1.1,-4.8,.7,.9,0,0,TAU);g.ellipse(1.1,-4.8,.7,.9,0,0,TAU);g.fill();
 /* a fold line and the hands with the flame */
 g.strokeStyle=rpA(G.d,.6);g.lineWidth=.8;g.beginPath();g.moveTo(-2,0);g.quadraticCurveTo(-2.6,4,-2,8);g.moveTo(2,0);g.quadraticCurveTo(2.6,4,2,8);g.stroke();
 g.beginPath();g.ellipse(0,2.6,2.6,1.4,0,0,TAU);g.fillStyle=G.l;g.fill();g.lineWidth=.8;g.strokeStyle=rpA(G.d,.8);g.stroke();
 g.beginPath();g.moveTo(0,-1.6);g.quadraticCurveTo(1.6,.8,0,2);g.quadraticCurveTo(-1.6,.8,0,-1.6);g.fillStyle='#ffffff';g.fill();g.restore()}
function rplnLantArt(g,tier,P){const L=RPLAY.lant[tier],M=rplnMet(tier,P),G=rplnGh(tier),q=rplnLG(L.ls),s=L.ls,I=M.ir,Au=tier>=2?M.gd:M.ir;
 /* chain */
 for(let i=0;i<3;i++){const y=1+i*q.c/3+q.c/6;g.beginPath();g.ellipse(0,y,i%2?.9:1.6,q.c/5,0,0,TAU);g.lineWidth=2.6;g.strokeStyle=RPTO;g.stroke();g.lineWidth=1.1;g.strokeStyle=I[0];g.stroke()}
 /* the cap ring */
 g.beginPath();g.arc(0,q.c+.4,2.2*s,0,TAU);g.lineWidth=3.4;g.strokeStyle=RPTO;g.stroke();g.lineWidth=1.5;g.strokeStyle=Au[0];g.stroke();
 /* the glass body: three panes seen from the front (the middle one wide), dark inside, the keeper glowing in the middle */
 const y0=q.y0,y1=q.y1,wt=q.wt,wb=q.wb;
 g.beginPath();g.moveTo(-wt,y0);g.lineTo(wt,y0);g.lineTo(wb,y1);g.lineTo(-wb,y1);g.closePath();g.fillStyle=rpVG(g,y0,y1,rpMix(G.k,G.d,.5),G.k);g.fill();
 g.save();g.clip();rplnKeeper(g,0,(y0+y1)/2+1.5*s,1.05*s,G);
 /* the glass: a soft tint and streaks */
 g.fillStyle=rpA(G.l,.12);g.fillRect(-wt,y0,wt*2,y1-y0);g.fillStyle='rgba(255,255,255,.5)';g.beginPath();g.moveTo(-wt+2.4*s,y0+2);g.lineTo(-wt+4.4*s,y0+2);g.lineTo(-wb+3.4*s,y1-3);g.lineTo(-wb+2*s,y1-3);g.closePath();g.fill();g.restore();
 g.beginPath();g.moveTo(-wt,y0);g.lineTo(wt,y0);g.lineTo(wb,y1);g.lineTo(-wb,y1);g.closePath();rpOut(g,2.4);
 /* frame bars: the pane edges (the side panes are narrow) and a cross bar */
 for(const k of [-1,1]){const xa=k*wt*.62,xb=k*wb*.62;g.beginPath();g.moveTo(xa,y0);g.lineTo(xb,y1);g.lineWidth=3.6;g.strokeStyle=RPTO;g.stroke();g.lineWidth=1.8;g.strokeStyle=I[1];g.stroke()}
 if(tier>=2){const ym=y0+(y1-y0)*.34;g.beginPath();g.moveTo(-wt+.8,ym);g.lineTo(-wt*.62,ym);g.moveTo(wt*.62,ym);g.lineTo(wt-.8,ym);g.lineWidth=3;g.strokeStyle=RPTO;g.stroke();g.lineWidth=1.4;g.strokeStyle=Au[1];g.stroke()}
 /* top rim and the cap: a pointed roof with ribs, a gold crown from tier 2 */
 const capY=q.c+1;g.beginPath();g.moveTo(-wt-2.6*s,y0+.6);g.lineTo(-wt*.55,capY+q.cap*.42);g.quadraticCurveTo(0,capY-1.2*s,wt*.55,capY+q.cap*.42);g.lineTo(wt+2.6*s,y0+.6);g.closePath();
 g.fillStyle=rpHG(g,-wt-3,wt+3,I[0],I[1],I[2]);g.fill();rpOut(g,2.2);
 g.strokeStyle=rpA(RPTO,.6);g.lineWidth=1;for(const k of [-.5,0,.5]){g.beginPath();g.moveTo(k*wt*.5,capY+q.cap*.36);g.lineTo(k*(wt+2.6*s)*.9,y0);g.stroke()}
 g.beginPath();g.rect(-wt-3.2*s,y0-1.6*s,(wt+3.2*s)*2,3.2*s);g.fillStyle=rpVG(g,y0-2,y0+2,Au[0],Au[2]);g.fill();rpOut(g,1.6);
 if(tier>=2){/* little crown points on the cap */for(const k of [-1,0,1]){const x=k*wt*.62;g.beginPath();g.moveTo(x-1.8*s,y0-1.6*s);g.lineTo(x,y0-5*s);g.lineTo(x+1.8*s,y0-1.6*s);g.closePath();g.fillStyle=rpHG(g,x-2,x+2,M.gd[0],M.gd[1],M.gd[2]);g.fill();g.lineWidth=1.1;g.strokeStyle=RPTO;g.stroke()}}
 if(tier>=4)rpGemArt(g,0,capY+q.cap*.55,1.8*s,RPASC[tier]);
 /* bottom rim, base plate and finial */
 g.beginPath();g.rect(-wb-2.4*s,y1-1.2*s,(wb+2.4*s)*2,q.base);g.fillStyle=rpVG(g,y1-1,y1+q.base,Au[0],Au[2]);g.fill();rpOut(g,1.6);
 const fy=y1-1.2*s+q.base;g.beginPath();g.moveTo(-wb*.7,fy);g.quadraticCurveTo(-wb*.5,fy+q.fin*.6,0,fy+q.fin);g.quadraticCurveTo(wb*.5,fy+q.fin*.6,wb*.7,fy);g.closePath();g.fillStyle=rpHG(g,-wb,wb,I[0],I[1],I[2]);g.fill();rpOut(g,1.6);
 g.beginPath();g.arc(0,fy+q.fin+1.2*s,1.5*s,0,TAU);g.fillStyle=tier>=2?M.gd[1]:I[1];g.fill();g.lineWidth=1;g.strokeStyle=RPTO;g.stroke();
 /* rivets on the rims */
 for(const k of [-1,1]){rpRiv(g,k*(wt+1.6*s),y0,1*s,Au[0]);rpRiv(g,k*(wb+1.2*s),y1+.4,1*s,Au[0])}
 /* tier 3+: a teal rune plate on the base; tier 5: little wings on the cap */
 if(tier>=3){g.beginPath();g.moveTo(0,y1-1.2*s);g.lineTo(2*s,y1+.8*s);g.lineTo(0,y1+2.6*s);g.lineTo(-2*s,y1+.8*s);g.closePath();g.fillStyle=G.l;g.fill();g.lineWidth=.9;g.strokeStyle=RPTO;g.stroke()}
 if(tier>=5)for(const k of [-1,1]){g.save();g.translate(k*(wt+2*s),y0-1);g.scale(k,1);g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(6*s,-6*s,10*s,-4*s);g.quadraticCurveTo(7*s,-2.4*s,8.6*s,-.6*s);g.quadraticCurveTo(5*s,-.6*s,0,2);g.closePath();
  g.fillStyle=rpHG(g,0,10*s,'#ffffff','#fff4d0','#e0c070');g.fill();g.lineWidth=1.2;g.strokeStyle=RPTO;g.stroke();g.restore()}}
const rplnLantS=(tier,skin)=>{const L=RPLAY.lant[tier],q=rplnLG(L.ls),w=q.wt+16*L.ls;return rpSpr('ln|lt|'+tier+'|'+skin,-w,-4,w*2,q.y1+q.base+q.fin+8,g=>rplnLantArt(g,tier,rpPalT('lant',skin,tier)))};
/* the light of the glass (drawn with 'lighter' at a flickering alpha) */
const rplnLantGlowS=tier=>{const L=RPLAY.lant[tier],q=rplnLG(L.ls),G=rplnGh(tier),cy=(q.y0+q.y1)/2,r=30*L.ls;return rpSpr('ln|lg|'+tier,-r,cy-r,r*2,r*2,g=>{g.drawImage(rpGlowC(G.m),-r,cy-r,r*2,r*2);g.globalAlpha=.85;
 g.beginPath();g.moveTo(-q.wt+1,q.y0+1);g.lineTo(q.wt-1,q.y0+1);g.lineTo(q.wb-1,q.y1-1);g.lineTo(-q.wb+1,q.y1-1);g.closePath();g.fillStyle=rpA(G.l,.35);g.fill();g.globalAlpha=1;g.drawImage(rpGlowC(G.w),-7*L.ls,cy-9*L.ls,14*L.ls,16*L.ls)},1.5)};
/* ---------- the crypt door (live: glows when a phantom is ready, swings open when one rises) ---------- */
function rplnDoorArt(g,tier,L,M){const D=rplnDoorG(L),cb=L.cb,W=tier>=5?['#fff6e0','#e8d2a8','#a88a5a']:tier===4?['#7a5aa0','#4a3070','#24143a']:['#8a5e3e','#5e3a22','#2e1a0e'],I=M.ir;
 rplnArch(g,D,cb,.6);g.fillStyle=rpHG(g,D.x-D.w,D.x+D.w,W[0],W[1],W[2]);g.fill();
 g.save();g.clip();g.strokeStyle=rpA(RPTO,.45);g.lineWidth=1;for(const k of [-.5,0,.5]){g.beginPath();g.moveTo(D.x+k*D.w*1.2,cb);g.lineTo(D.x+k*D.w*1.2,cb-D.h);g.stroke()}
 for(const u of [.28,.7]){const y=cb-D.h*u;g.beginPath();g.rect(D.x-D.w,y-1.4,D.w*2,2.8);g.fillStyle=I[1];g.fill();g.lineWidth=.8;g.strokeStyle=RPTO;g.stroke();for(const k of [-.6,.6])rpRiv(g,D.x+k*D.w,y,.8,I[0])}g.restore();
 rplnArch(g,D,cb,.6);rpOut(g,1.6);
 g.beginPath();g.arc(D.x+D.w*.45,cb-D.h*.46,1.6,0,TAU);g.lineWidth=2.2;g.strokeStyle=RPTO;g.stroke();g.lineWidth=1;g.strokeStyle=tier>=2?M.gd[0]:I[0];g.stroke()}
const rplnDoorS=(tier,skin)=>{const L=RPLAY.lant[tier],D=rplnDoorG(L);return rpSpr('ln|dr|'+tier+'|'+skin,D.x-D.w-2,L.cb-D.h-2,D.w*2+4,D.h+4,g=>rplnDoorArt(g,tier,L,rplnMet(tier,rpPalT('lant',skin,tier))))};
const rplnDoorGlowS=tier=>{const L=RPLAY.lant[tier],D=rplnDoorG(L),G=rplnGh(tier);return rpSpr('ln|dg|'+tier,D.x-D.w*3,L.cb-D.h*2,D.w*6,D.h*2.6,g=>{
 g.drawImage(rpGlowC(G.m),D.x-D.w*3,L.cb-D.h*1.9,D.w*6,D.h*2.5);rplnArch(g,D,L.cb,-1.2);g.fillStyle=rpA(G.l,.55);g.fill();
 /* light spilling out on the step */
 g.fillStyle=rpA(G.l,.4);g.beginPath();g.ellipse(D.x,L.cb+1.6,D.w*1.6,2.4,0,0,TAU);g.fill()},1.5)};
/* the open doorway: the light of the crypt inside */
const rplnDoorInS=tier=>{const L=RPLAY.lant[tier],D=rplnDoorG(L),G=rplnGh(tier);return rpSpr('ln|di|'+tier,D.x-D.w-1,L.cb-D.h-1,D.w*2+2,D.h+2,g=>{rplnArch(g,D,L.cb,.6);g.fillStyle=rpVG(g,L.cb-D.h,L.cb,G.d,G.l);g.fill();
 g.globalCompositeOperation='lighter';g.drawImage(rpGlowC(G.w),D.x-D.w,L.cb-D.h*.7,D.w*2,D.h*.8)})};
/* ---------- live parts ---------- */
const RPLN={cur:null};
function rplnLive(g,tier,P,t,o,L,ph){const lt=RPFX.lite,tw=RPLN.cur&&RPLN.cur.type==='lant'?RPLN.cur:null,G=rplnGh(tier),ga=RPGA,D=rplnDoorG(L),fire=Math.max(0,Math.min(1,o.fire||0));
 /* the crypt door: closed, ajar or open; a glow while a phantom is ready */
 const op=tw?Math.max(0,Math.min(1,tw.door||0)):0,ready=tw?!!tw.ready:false;
 if(op>.02){g.globalAlpha=ga;rpPut(g,rplnDoorInS(tier))}
 {const c=Math.cos(op*1.35);if(c>.05){g.save();g.translate(D.x-D.w,0);g.scale(c,1);g.translate(-(D.x-D.w),0);g.globalAlpha=ga;rpPut(g,rplnDoorS(tier,'base'));g.restore()}}
 if(ready||op>.02){const k=ready?.55+.35*Math.sin(t*4.2+ph*5):0;g.globalCompositeOperation='lighter';g.globalAlpha=ga*Math.min(1,k+op);rpPut(g,rplnDoorGlowS(tier));g.globalCompositeOperation='source-over';g.globalAlpha=ga}
 /* the jar: soul-light up to the fill level, a bobbing surface, bubbles; a glow when full */
 const fill=tw?Math.max(0,Math.min(1,tw.jarK||0)):.35+.25*Math.sin(t*.7+ph*3)+.15;
 {const s=L.js,y0=L.jy+1.6*s,y1=L.jy-13.6*s,lv=y0+(y1-y0)*fill+Math.sin(t*2.6+ph)*.5*(fill>.02&&fill<.98?1:0);
  if(fill>.02){g.globalAlpha=ga;rpPutBelow(g,rplnJarLiqS(tier),lv);
   if(fill<.98){const w=Math.max(1.5,7*s*Math.min(1,Math.sin(Math.PI*Math.min(.98,Math.max(.06,fill))))*1.05);g.fillStyle=rpA(G.w,.85);g.beginPath();g.ellipse(L.jx,lv,w,1,0,0,TAU);g.fill()}
   if(!lt){g.globalCompositeOperation='lighter';for(let i=0;i<2;i++){const u=((t*.6+i*.5+ph)%1),by=y0-(y0-lv)*u;if(by<lv+1)continue;g.globalAlpha=ga*(1-u)*.9;g.drawImage(rpGlowC(G.w),L.jx-3+i*2.6-1.6,by-1.6,3.2,3.2)}
    g.globalCompositeOperation='source-over';g.globalAlpha=ga}}
  if(fill>=.98){g.globalCompositeOperation='lighter';rpGlow(g,L.jx,L.jy-8*s,16,16,G.l,.45+.25*Math.sin(t*5+ph));g.globalCompositeOperation='source-over';g.globalAlpha=ga}
  g.globalAlpha=ga;rpPut(g,rplnJarFrontS(tier,'base'))}
 /* the lantern: sways from its hook (a kick when it fires); the keeper's light flickers and flares */
 const kick=tw?(tw.swk||0):fire*Math.sin(t*14)*.12,an=Math.sin(t*1.25+ph*6)*.055+Math.sin(t*2.7+ph*2)*.018+kick;
 const fl=.78+.12*Math.sin(t*9.3+ph*7)+.08*Math.sin(t*23.1+ph*3)+(rpR(Math.floor(t*12+ph*40))-.5)*.1;
 g.save();g.translate(L.hx,L.hy);g.rotate(an);g.globalAlpha=ga;rpPut(g,rplnLantS(tier,'base'));
 g.globalCompositeOperation='lighter';g.globalAlpha=ga*Math.min(1,fl*(.75+fire*.6));rpPut(g,rplnLantGlowS(tier));
 if(fire>.05){const q=rplnLG(L.ls),cy=(q.y0+q.y1)/2;rpGlow(g,0,cy,(30+22*fire)*L.ls,(30+22*fire)*L.ls,G.l,fire*.8);rpGlow(g,0,cy,12*L.ls,14*L.ls,'#ffffff',fire*.9)}
 g.globalCompositeOperation='source-over';g.restore();g.globalAlpha=ga;
 /* icons and the tier sheet: two little wisps circling the lantern */
 if(!tw&&!lt){const q=rplnGlass(tier);for(let i=0;i<2;i++){const a=t*1.6+ph+i*Math.PI,x=q.x+Math.cos(a)*24*L.ls,y=q.y+Math.sin(a)*8*L.ls,d=Math.sin(a)>0;if(!d)continue;rplnWisp(g,x,y,a+Math.PI/2,tier,t+i,.7,ga*.9)}}
 g.globalAlpha=ga}
{const p0=rpTowerParts;rpTowerParts=function(g,type,tier,skin,t,o,nopad){if(type!=='lant')return p0.apply(this,arguments);
 const P=rpPalT(type,skin,tier),L=RPLAY[type][tier],ph=o.ph||0;
 if(tier>=4){if(!nopad)rpAscGround(g,tier,t,ph,1);rpAscLive(g,type,tier,t,ph,L,0)}
 /* wisps behind the lantern (icons) */
 g.globalAlpha=RPGA;rpPut(g,nopad?rpBody(type,tier,skin):rpBack(type,tier,skin));
 {const q=RPPULSE[type];g.globalCompositeOperation='lighter';g.globalAlpha=RPGA*(1-q[1]+q[1]*Math.sin(t*q[0]+ph*7))*(1+.5*Math.max(0,Math.min(1,o.fire||0)));rpPut(g,rpGlowLayer(type,tier,skin));g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}
 if(!nopad){const u=((t+ph*2.3)*.28)%1;if(u<.12){const v=u/.12*tier,i=Math.min(tier-1,v|0);g.globalCompositeOperation='lighter';rpGlow(g,(i-(tier-1)/2)*10,RPPIPY-1,8,8,'#fff6c8',Math.sin(Math.PI*(v-i))*.95);g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}}
 rplnLive(g,tier,P,t,o,L,ph);
 if(tier>=4)rpAscLive(g,type,tier,t,ph,L,1);
 g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}}
/* ---------- wisps, souls ---------- */
/* a wisp: a ghost flame with a little face, pointing right (rotated to its heading), a tail behind */
function rplnWispArt(g,G){g.globalCompositeOperation='lighter';g.drawImage(rpGlowC(G.m),-22,-16,38,32);g.drawImage(rpGlowC(G.w),-9,-8,16,16);g.globalCompositeOperation='source-over';
 g.beginPath();g.moveTo(-17,0);g.quadraticCurveTo(-10,-3,-5,-6.4);g.quadraticCurveTo(3.4,-9,7,-2.4);g.quadraticCurveTo(8.8,2,5.2,5.4);g.quadraticCurveTo(-1,7.8,-6,4.2);g.quadraticCurveTo(-11,2.8,-17,0);g.closePath();
 g.fillStyle=rpHG(g,-17,8,rpA(G.m,.35),G.l,G.w);g.fill();g.lineWidth=1.5;g.strokeStyle=rpA(RPTO,.8);g.stroke();
 g.beginPath();g.moveTo(-15,1.4);g.quadraticCurveTo(-9,4,-4,2.4);g.lineWidth=1.2;g.strokeStyle=rpA(G.d,.7);g.stroke();
 g.fillStyle=G.k;g.beginPath();g.ellipse(1.8,-1.6,1.1,1.6,0,0,TAU);g.ellipse(4.6,-1.4,1,1.5,0,0,TAU);g.fill();
 g.fillStyle='#ffffff';g.beginPath();g.ellipse(-.6,-4,2.4,1.2,-.4,0,TAU);g.fill()}
const rplnWispS=tier=>rpSpr('ln|w|'+rplnT(tier),-22,-16,38,32,g=>rplnWispArt(g,rplnGh(rplnT(tier))));
function rplnWisp(g,x,y,a,tier,t,sc,al){const s=(sc||1)*(1+.07*Math.sin(t*14)),a0=g.globalAlpha;g.save();g.translate(x,y);g.rotate(a);const f=Math.cos(a)<0?-1:1;g.scale(s,s*f);g.globalAlpha=al==null?1:al;rpPut(g,rplnWispS(tier));g.restore();g.globalAlpha=a0}
const rplnDotS=tier=>rpSpr('ln|d|'+rplnT(tier),-6,-6,12,12,g=>{const G=rplnGh(rplnT(tier));g.drawImage(rpGlowC(G.m),-6,-6,12,12);g.fillStyle=G.w;g.beginPath();g.arc(0,0,1.4,0,TAU);g.fill()},1);
/* a soul: a pale round wisp with a sleepy face */
const rplnSoulS=tier=>rpSpr('ln|s|'+rplnT(tier),-11,-11,22,22,g=>{const G=rplnGh(rplnT(tier));g.globalCompositeOperation='lighter';g.drawImage(rpGlowC(G.l),-11,-11,22,22);g.globalCompositeOperation='source-over';
 g.beginPath();g.moveTo(0,-5.6);g.quadraticCurveTo(4.6,-5.4,4.6,0);g.quadraticCurveTo(4.4,4,1.6,4.6);g.quadraticCurveTo(0,7.6,-2.6,6.6);g.quadraticCurveTo(-1,5.2,-2.4,4.4);g.quadraticCurveTo(-4.6,3,-4.6,0);g.quadraticCurveTo(-4.6,-5.4,0,-5.6);g.closePath();
 g.fillStyle=rpVG(g,-6,6,G.w,G.l);g.fill();g.lineWidth=1.1;g.strokeStyle=rpA(RPTO,.65);g.stroke();
 g.strokeStyle=G.d;g.lineWidth=.9;g.beginPath();g.arc(-1.6,-.6,.9,.2,Math.PI-.2);g.moveTo(2.5,-.6);g.arc(1.6,-.6,.9,.2,Math.PI-.2);g.stroke()},2);
function rplnSoulDraw(g,x,y,tier,t,al){const s=1.45+.1*Math.sin(t*9),a0=g.globalAlpha;g.globalAlpha=al==null?1:al;const S=rplnSoulS(tier);g.drawImage(S.c,x+S.x0*s,y+S.y0*s,S.w*s,S.h*s);g.globalAlpha=a0}
/* ---------- the phantom knight (feet at 0,0, facing right; drawn RPLN_KS times its model size, the Reaper RPLN_RS) ---------- */
const RPLN_KS=1.3,RPLN_RS=1.4;
function rplnKnightArt(g,G,tier){const A=tier>=5?['#ffffff','#fff2c8','#e0c070']:tier===4?['#fff0a8','#ffd45a','#b07a1a']:['#ffffff','#c8fff0','#5ad8b8'];
 /* the wispy tail where legs would be */
 g.beginPath();g.moveTo(-9,-20);g.quadraticCurveTo(-13,-10,-21,-6);g.quadraticCurveTo(-15,-6,-12,-3);g.quadraticCurveTo(-8,-1,-4,-3);g.quadraticCurveTo(-1,-6,4,-4);g.quadraticCurveTo(7,-8,8,-20);g.closePath();
 g.fillStyle=rpVG(g,-22,-2,rpA(G.l,.95),rpA(G.d,.25));g.fill();g.lineWidth=1.3;g.strokeStyle=rpA(RPTO,.55);g.stroke();
 /* body: a breastplate with a rune, a skirt of mail */
 g.beginPath();g.moveTo(-9,-20);g.quadraticCurveTo(-11,-32,-7,-38);g.lineTo(7,-38);g.quadraticCurveTo(11,-32,8,-20);g.quadraticCurveTo(0,-17,-9,-20);g.closePath();g.fillStyle=rpHG(g,-10,10,G.w,G.l,G.m);g.fill();rpOut(g,1.8);
 g.strokeStyle=rpA(G.d,.8);g.lineWidth=1;g.beginPath();g.moveTo(-8,-24);g.quadraticCurveTo(0,-21.4,7.4,-24);g.stroke();
 g.beginPath();g.moveTo(0,-34);g.lineTo(2.4,-30);g.lineTo(0,-26);g.lineTo(-2.4,-30);g.closePath();g.fillStyle=A[1];g.fill();g.lineWidth=1;g.strokeStyle=RPTO;g.stroke();
 /* pauldrons */
 for(const [x,k] of [[-8,-1],[8,1]]){g.beginPath();g.ellipse(x,-37,5.4,3.6,k*.3,0,TAU);g.fillStyle=rpVG(g,-41,-33,G.w,G.m);g.fill();rpOut(g,1.5)}
 /* helmet: a great helm with a glowing visor slit and a plume */
 g.beginPath();g.moveTo(-6.4,-38);g.lineTo(-6.6,-47);g.quadraticCurveTo(-6,-53,0,-53.4);g.quadraticCurveTo(6,-53,6.6,-47);g.lineTo(6.4,-38);g.closePath();g.fillStyle=rpHG(g,-7,7,G.w,G.l,G.m);g.fill();rpOut(g,1.8);
 g.beginPath();g.moveTo(-1,-46.6);g.lineTo(6.4,-46.6);g.lineTo(6.4,-44.2);g.lineTo(-1,-44.2);g.closePath();g.fillStyle=G.k;g.fill();
 g.fillStyle='#ffffff';g.beginPath();g.ellipse(2.6,-45.4,1.3,.8,0,0,TAU);g.ellipse(5.4,-45.4,1,.7,0,0,TAU);g.fill();
 g.beginPath();g.moveTo(0,-53);g.quadraticCurveTo(-6,-60,-15,-55);g.quadraticCurveTo(-9,-55.6,-6,-51);g.closePath();g.fillStyle=A[1];g.fill();g.lineWidth=1.3;g.strokeStyle=RPTO;g.stroke();
 g.strokeStyle='rgba(255,255,255,.6)';g.lineWidth=1.2;g.beginPath();g.moveTo(-4.6,-49);g.lineTo(-4.6,-41);g.stroke();
 /* the shield on the near arm */
 g.beginPath();g.moveTo(-14,-34);g.lineTo(-4,-34);g.lineTo(-4,-26);g.quadraticCurveTo(-5,-19,-9,-17);g.quadraticCurveTo(-13,-19,-14,-26);g.closePath();g.fillStyle=rpHG(g,-14,-4,G.l,G.m,G.d);g.fill();rpOut(g,1.8);
 g.beginPath();g.moveTo(-12,-32.4);g.lineTo(-6,-32.4);g.lineTo(-6,-26);g.quadraticCurveTo(-6.6,-21.6,-9,-20);g.quadraticCurveTo(-11.4,-21.6,-12,-26);g.closePath();g.lineWidth=1.2;g.strokeStyle=A[1];g.stroke();
 g.beginPath();g.arc(-9,-27,1.8,0,TAU);g.fillStyle=A[0];g.fill();g.lineWidth=.9;g.strokeStyle=RPTO;g.stroke()}
const rplnKnightS=tier=>rpSpr('ln|kn|'+rplnT(tier),-24,-62,40,64,g=>rplnKnightArt(g,rplnGh(rplnT(tier)),rplnT(tier)));
/* the sword (grip at 0,0, pointing up) */
function rplnSwordArt(g,G,tier){const A=tier>=5?['#ffffff','#fff2c8','#e0c070']:tier===4?['#fff0a8','#ffd45a','#b07a1a']:['#ffffff','#c8fff0','#5ad8b8'];
 g.globalCompositeOperation='lighter';g.globalAlpha=.7;g.drawImage(rpGlowC(G.m),-7,-30,14,30);g.globalCompositeOperation='source-over';g.globalAlpha=1;
 g.beginPath();g.moveTo(-1.8,-4);g.lineTo(-1.8,-24);g.lineTo(0,-28);g.lineTo(1.8,-24);g.lineTo(1.8,-4);g.closePath();g.fillStyle=rpHG(g,-2,2,G.w,G.l,G.m);g.fill();rpOut(g,1.4);
 g.beginPath();g.rect(-5,-5,10,2.4);g.fillStyle=A[1];g.fill();rpOut(g,1.2);g.beginPath();g.rect(-1,-3,2,4.6);g.fillStyle=A[2];g.fill();rpOut(g,1);g.beginPath();g.arc(0,2.4,1.5,0,TAU);g.fillStyle=A[0];g.fill();g.lineWidth=.9;g.strokeStyle=RPTO;g.stroke()}
const rplnSwordS=tier=>rpSpr('ln|sw|'+rplnT(tier),-8,-31,16,36,g=>rplnSwordArt(g,rplnGh(rplnT(tier)),rplnT(tier)));
/* a glow behind a phantom (baked) */
const rplnAuraS=(tier,big)=>rpSpr('ln|au|'+rplnT(tier)+'|'+(big?1:0),-40,-46,80,72,g=>{const G=rplnGh(rplnT(tier)),k=big?1.35:1;g.drawImage(rpGlowC(G.m),-30*k,-38*k,60*k,60*k)},1);
function rplnKnight(g,x,y,dir,tier,t,al,sw){const a0=g.globalAlpha,b=Math.sin(t*5.4)*2,lean=.06+(sw||0)*.12;g.save();g.translate(x,y-4+b);g.scale(dir<0?-RPLN_KS:RPLN_KS,RPLN_KS);
 g.globalCompositeOperation='lighter';g.globalAlpha=al*.8;rpPut(g,rplnAuraS(tier,0),0,-6);g.globalCompositeOperation='source-over';
 g.rotate(lean);g.globalAlpha=al;rpPut(g,rplnKnightS(tier));
 /* the sword arm: raised, then a swing forward on a cut */
 const s=sw||0,ang=-.25+Math.sin(t*3)*.06+(s>0?(s>.5?-1.1+(1-s)*2.4:-1.1*s*2):0);g.translate(7,-28);g.rotate(ang+.5);rpPut(g,rplnSwordS(tier));g.restore();g.globalAlpha=a0}
/* ---------- the Reaper (feet at 0,0, facing right; about 1.6x a knight) ---------- */
function rplnReaperArt(g,G){const robe=[rpMix(G.d,G.k,.15),rpMix(G.d,G.k,.6)];
 /* tattered robe: dark spectral cloth with a ghost-light rim */
 g.beginPath();g.moveTo(-10,-64);g.quadraticCurveTo(-18,-40,-30,-10);g.lineTo(-24,-12);g.lineTo(-22,-4);g.lineTo(-16,-9);g.lineTo(-11,-1);g.lineTo(-6,-8);g.lineTo(-1,-2);g.lineTo(3,-9);g.lineTo(8,-3);g.quadraticCurveTo(12,-30,10,-62);g.closePath();
 const rg=g.createLinearGradient(0,-66,0,-2);rg.addColorStop(0,rpA(robe[0],.98));rg.addColorStop(.7,rpA(robe[1],.9));rg.addColorStop(1,rpA(robe[1],.45));g.fillStyle=rg;g.fill();g.lineWidth=2;g.strokeStyle=rpA(RPTO,.8);g.stroke();
 g.save();g.clip();g.strokeStyle=rpA(G.l,.75);g.lineWidth=2.4;g.beginPath();g.moveTo(-11,-62);g.quadraticCurveTo(-19,-38,-31,-9);g.stroke();g.restore();
 g.strokeStyle=rpA(G.m,.55);g.lineWidth=1.2;for(const [x0,x1] of [[-4,-12],[2,-2],[6,6]]){g.beginPath();g.moveTo(x0,-56);g.quadraticCurveTo(x0-2,-30,x1,-8);g.stroke()}
 /* a ghost-light sash with a gold clasp */
 g.beginPath();g.moveTo(-12,-46);g.quadraticCurveTo(0,-41,11,-47);g.lineWidth=4.4;g.strokeStyle=RPTO;g.stroke();g.lineWidth=2.6;g.strokeStyle=G.l;g.stroke();
 g.beginPath();g.arc(-1,-43.6,2.4,0,TAU);g.fillStyle='#ffd45a';g.fill();g.lineWidth=1;g.strokeStyle=RPTO;g.stroke();
 /* the hood */
 g.beginPath();g.moveTo(-12,-60);g.quadraticCurveTo(-14,-78,0,-82);g.quadraticCurveTo(14,-80,14,-64);g.quadraticCurveTo(12,-56,4,-54);g.quadraticCurveTo(-6,-54,-12,-60);g.closePath();g.fillStyle=rpHG(g,-14,14,G.m,G.d,robe[1]);g.fill();rpOut(g,2);
 g.strokeStyle=rpA(G.w,.7);g.lineWidth=1.4;g.beginPath();g.moveTo(-10,-62);g.quadraticCurveTo(-12,-76,0,-80);g.stroke();
 /* the dark face with a pale skull and burning eyes */
 g.beginPath();g.ellipse(4,-67,7.6,8.6,.1,0,TAU);g.fillStyle='#08040f';g.fill();
 g.globalCompositeOperation='lighter';g.drawImage(rpGlowC(G.l),-6,-77,20,18);g.globalCompositeOperation='source-over';
 g.beginPath();g.ellipse(5,-67,5,5.6,.1,0,TAU);g.fillStyle=rpVG(g,-73,-61,'#fbf6ea','#cfc6b4');g.fill();g.lineWidth=1;g.strokeStyle=RPTO;g.stroke();
 g.fillStyle='#08040f';g.beginPath();g.ellipse(3,-68,1.7,2,0,0,TAU);g.ellipse(7.2,-68,1.6,1.9,0,0,TAU);g.fill();g.fillStyle=G.l;g.beginPath();g.arc(3.2,-68,.9,0,TAU);g.arc(7.2,-68,.9,0,TAU);g.fill();
 g.strokeStyle=RPTO;g.lineWidth=.8;g.beginPath();for(const x of [3.4,5,6.6]){g.moveTo(x,-63.6);g.lineTo(x,-62)}g.stroke();
 /* a bony hand reaching forward */
 g.beginPath();g.ellipse(12,-44,3.4,2.6,0,0,TAU);g.fillStyle='#ece4d4';g.fill();g.lineWidth=1.1;g.strokeStyle=RPTO;g.stroke()}
const rplnReaperS=tier=>rpSpr('ln|rp|'+rplnT(tier),-34,-88,52,92,g=>rplnReaperArt(g,rplnGh(rplnT(tier))));
/* the scythe (grip at 0,0; the shaft runs up, the blade curls forward at the top) */
function rplnScytheArt(g,G,tier){const A=tier>=5?['#ffffff','#fff2c8','#e0c070']:tier===4?['#fff0a8','#ffd45a','#b07a1a']:['#ffffff','#c8fff0','#5ad8b8'];
 g.globalCompositeOperation='lighter';g.globalAlpha=.6;g.drawImage(rpGlowC(G.m),-6,-66,40,34);g.globalCompositeOperation='source-over';g.globalAlpha=1;
 rpBeam(g,0,18,0,-58,3,'#3a3050','#7a6a98');
 g.beginPath();g.moveTo(0,-56);g.quadraticCurveTo(16,-68,32,-52);g.quadraticCurveTo(20,-60,2,-50);g.closePath();g.fillStyle=rpHG(g,0,32,G.l,G.w,G.m);g.fill();rpOut(g,1.8);
 g.strokeStyle='rgba(255,255,255,.8)';g.lineWidth=1.2;g.beginPath();g.moveTo(4,-56.6);g.quadraticCurveTo(16,-64.6,28,-54);g.stroke();
 g.beginPath();g.rect(-2.6,-58,5.2,5);g.fillStyle=A[1];g.fill();rpOut(g,1.2)}
const rplnScytheS=tier=>rpSpr('ln|sc|'+rplnT(tier),-8,-72,44,94,g=>rplnScytheArt(g,rplnGh(rplnT(tier)),rplnT(tier)));
function rplnReaper(g,x,y,dir,tier,t,al,sw){const a0=g.globalAlpha,b=Math.sin(t*3.6)*2.6;g.save();g.translate(x,y-6+b);g.scale(dir<0?-RPLN_RS:RPLN_RS,RPLN_RS);
 g.globalCompositeOperation='lighter';g.globalAlpha=al*.8;rpPut(g,rplnAuraS(tier,1),0,-16);g.globalCompositeOperation='source-over';
 g.globalAlpha=al;rpPut(g,rplnReaperS(tier));
 const s=sw||0,ang=-.35+Math.sin(t*2.2)*.05+(s>0?(s>.45?-.9+(1-s)*2.2:-.9*s/.45):0);g.translate(12,-42);g.rotate(ang);rpPut(g,rplnScytheS(tier));g.restore();g.globalAlpha=a0}
/* ---------- cuts, hits, haunts ---------- */
const rplnSlashS=(tier,big)=>rpSpr('ln|sl|'+rplnT(tier)+'|'+(big?1:0),-34,-34,68,68,g=>{const G=rplnGh(rplnT(tier)),r=big?28:20;g.lineCap='round';
 g.beginPath();g.arc(0,0,r,-2.2,.5);g.lineWidth=big?9:7;g.strokeStyle=rpA(G.m,.7);g.stroke();g.lineWidth=big?4:3;g.strokeStyle=G.w;g.stroke();g.lineWidth=1.2;g.strokeStyle=rpA(RPTO,.5);g.beginPath();g.arc(0,0,r+(big?5:4),-2,.4);g.stroke()},1.5);
function rplnSlash(g,x,y,u,tier,dir,big){if(u<=0||u>=1)return;const a0=g.globalAlpha;g.save();g.translate(x,y);g.scale(dir<0?-1:1,.8);g.rotate(-.6+u*1.1);const z=.7+.5*u;g.scale(z,z);g.globalAlpha=(1-u)*(1-u);g.globalCompositeOperation='lighter';rpPut(g,rplnSlashS(tier,big));g.restore();g.globalAlpha=a0}
const rplnHauntS=tier=>rpSpr('ln|ha|'+rplnT(tier),-24,-12,48,24,g=>{const G=rplnGh(rplnT(tier));g.drawImage(rpGlowC(G.m),-24,-12,48,24);g.beginPath();g.ellipse(0,0,17,6,0,0,TAU);g.lineWidth=2.2;g.strokeStyle=rpA(G.l,.85);g.stroke()},1.5);
function rplnHauntDraw(g,x,y,w,k,t,tier){if(k<=.02)return;const a0=g.globalAlpha,s=Math.max(.6,Math.min(1.6,w/40));g.globalCompositeOperation='lighter';g.globalAlpha=k*(.55+.2*Math.sin(t*6));const H=rplnHauntS(tier);g.drawImage(H.c,x+H.x0*s,y+H.y0*s,H.w*s,H.h*s);
 const D=rplnDotS(tier).c;for(let i=0;i<3;i++){const a=t*3+i*2.094,u=((t*.8+i/3)%1);g.globalAlpha=k*Math.sin(Math.PI*u);g.drawImage(D,x+Math.cos(a)*16*s-5,y+Math.sin(a)*5*s-6-u*24-5,10,10)}
 g.globalCompositeOperation='source-over';g.globalAlpha=a0}
function rplnBurst(g,x,y,u,tier){if(u<=0||u>=1)return;const G=rplnGh(tier),a0=g.globalAlpha,e=1-(1-u)*(1-u);g.globalCompositeOperation='lighter';rpGlow(g,x,y,10+18*e,10+18*e,G.m,(1-u)*1.1);
 const D=rplnDotS(tier).c;g.globalAlpha=1-u;for(let i=0;i<6;i++){const a=i/6*TAU+.4,r=4+16*e;g.drawImage(D,x+Math.cos(a)*r-4,y+Math.sin(a)*r*.7-4,8,8)}g.globalCompositeOperation='source-over';g.globalAlpha=a0}
function rplnShadow(g,x,y,s,a){g.fillStyle=`rgba(8,4,20,${(.22*a).toFixed(3)})`;g.beginPath();g.ellipse(x,y,12*s,4*s,0,0,TAU);g.fill()}
/* ---------- warming: every sprite of a tier baked before it is first drawn ---------- */
{const w0=rpTowerWarm;rpTowerWarm=function(type,tier,skin){const r=w0.apply(this,arguments);if(type==='lant'){tier=rplnT(tier);skin=RPPAL.lant[skin]?skin:'base';try{
  rplnLantS(tier,'base');rplnLantGlowS(tier);rplnDoorS(tier,'base');rplnDoorGlowS(tier);rplnDoorInS(tier);rplnJarFrontS(tier,'base');rplnJarLiqS(tier);
  rplnWispS(tier);rplnDotS(tier);rplnSoulS(tier);rplnKnightS(tier);rplnSwordS(tier);rplnAuraS(tier,0);rplnSlashS(tier,0);rplnHauntS(tier);
  if(tier>=5){rplnReaperS(tier);rplnScytheS(tier);rplnAuraS(tier,1);rplnSlashS(tier,1)}}catch(e){console.error(e)}}return r}}
/* the 9.9p glow and particle layer (97k): light at the lantern, the doorway and the jar; ghost motes rising from the crypt */
try{if(typeof RPG_SRC!=='undefined'){RPG_SRC.lant=[0,1,2,3,4,5].map(t=>{if(!t)return null;const L=RPLAY.lant[t],G=rplnGh(t),q=rplnGlass(t),D=rplnDoorG(L);
  return [[q.x,q.y,26*L.ls+6,G.m],[D.x,L.cb-D.h*.5,16,G.m,'f'],[L.jx,L.jy-8,12,G.l]]});
 RPG_PAR.lant={k:'rise',n:[0,2,3,4,5,6],c:['#c8fff0','#7dffd8'],s:'dot',y:[0,-8,-10,-12,-12,-12],x:-5,w:22,h:44,z:2.4}}}catch(e){}
