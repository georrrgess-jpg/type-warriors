/* ===== RUNESTONE RAMPARTS: HUD, hub, result and hooks =====
   The in-run HUD is a DOM layer (#rphud, 1600x900 inside #wrap, pointer-events only on its controls): top chips (wave, keep, supply),
   speed and pause, the Start-wave button, the tower info panel (right), the build ring around a pad, the "new foe" card, and the dock:
   command bar (word, Command meter, three abilities) over the four tower cards and the next-wave preview. rpHudTick() writes only what
   changed. Menus (hub, pause, victory choice, result) use show() like every other mode. */
const RPI={
 skull:'<svg viewBox="0 0 24 24"><path d="M12 2C7 2 4 5.5 4 9.6c0 2.6 1.3 4.4 3 5.4V19h2v-2h2v2h2v-2h2v2h2v-4c1.7-1 3-2.8 3-5.4C20 5.5 17 2 12 2z" fill="#f4ecd8" stroke="#12081f" stroke-width="1.6"/><circle cx="9" cy="10" r="2" fill="#12081f"/><circle cx="15" cy="10" r="2" fill="#12081f"/></svg>',
 keep:'<svg viewBox="0 0 24 24"><path d="M4 21V8h3V5h2v3h2V5h2v3h2V5h2v3h3v13h-6v-5h-4v5z" fill="#ffd45a" stroke="#12081f" stroke-width="1.6" stroke-linejoin="round"/></svg>',
 sup:'<svg viewBox="0 0 24 24"><path d="M12 2l9 5v10l-9 5-9-5V7z" fill="#e0a85a" stroke="#12081f" stroke-width="1.6" stroke-linejoin="round"/><path d="M3 7l9 5 9-5M12 12v10" fill="none" stroke="#12081f" stroke-width="1.6"/><path d="M7.5 4.6l9 5" stroke="#fff4c8" stroke-width="1.4" opacity=".6"/></svg>',
 over:'<svg viewBox="0 0 24 24"><path d="M13 2L4 14h7l-1 8 9-12h-7z" fill="#ffd45a" stroke="#12081f" stroke-width="1.6" stroke-linejoin="round"/></svg>',
 slow:'<svg viewBox="0 0 24 24"><g stroke="#9fe8ff" stroke-width="2.2" stroke-linecap="round"><path d="M12 2v20M3.3 7l17.4 10M3.3 17L20.7 7"/><path d="M9.5 3.5L12 6l2.5-2.5M9.5 20.5L12 18l2.5 2.5" fill="none"/></g></svg>',
 repair:'<svg viewBox="0 0 24 24"><path d="M12 2l8 3v6c0 5-3.4 9-8 11-4.6-2-8-6-8-11V5z" fill="#7dffb0" stroke="#12081f" stroke-width="1.6" stroke-linejoin="round"/><path d="M12 8v8M8 12h8" stroke="#12081f" stroke-width="2.4" stroke-linecap="round"/></svg>',
 play:'<svg viewBox="0 0 24 24"><path d="M7 4l13 8-13 8z" fill="#3a1a04" stroke="#3a1a04" stroke-width="1.5" stroke-linejoin="round"/></svg>',
 star:(on,s)=>`<svg viewBox="0 0 24 24" width="${s||22}" height="${s||22}"><path d="M12 2l3 6.6 7.2.8-5.4 4.9 1.5 7.1L12 17.8l-6.3 3.6 1.5-7.1L1.8 9.4 9 8.6z" fill="${on?'#ffd45a':'#2a2050'}" stroke="${on?'#7a4a0a':'#5a4ca0'}" stroke-width="1.6" stroke-linejoin="round"/>${on?'<path d="M9.6 9.2L12 4.4" stroke="#fff6c0" stroke-width="1.4" stroke-linecap="round"/>':''}</svg>`};
let RPH=null;/* cached HUD state */
const rpIconURL={};
function rpIconCanvas(type,tier,skin,size){try{const c=rpTowerIcon(type,tier,skin,size);const k=type+tier+skin+size;if(!rpIconURL[k])rpIconURL[k]=c.toDataURL();return rpIconURL[k]}catch(e){return''}}
function rpMobURL(id,size){const k='m'+id+size;if(!rpIconURL[k])try{rpIconURL[k]=rpMobIcon(id,size).toDataURL()}catch(e){rpIconURL[k]=''}return rpIconURL[k]}
function rpHudOn(){const R=RPX;if(!R)return;let h=$('rphud');if(!h){h=document.createElement('div');h.id='rphud';wrap.appendChild(h)}h.className='rph'+(R.rm?' rprm':'');h.hidden=false;
 const ab=(k,n)=>`<button class="rpab" data-ab="${k}" title="${n}"><span class="rpabi">${RPI[k]}</span><b>${n}</b><small>${RPT.CMD}</small><kbd>${k==='over'?1:k==='slow'?2:3}</kbd></button>`;
 const card=t=>{const T=RP_TW[t],TW=RPTW[t];return `<button class="rpcard" data-tw="${t}" style="--c:${TW.col}"><img alt="" src="${rpIconCanvas(t,1,rpSkinOf(t),96)}"><span class="rpct"><b>${TW.n}</b><em>${TW.role}</em><small>${T.desc}</small></span><span class="rpcost">${RPI.sup}<b>${T.cost[0]}</b></span></button>`};
 h.innerHTML=`<div class="rpplq"><b>Runestone Ramparts</b><small>${esc(R.map.n)}</small></div>
  <div class="rpchips"><span class="rpchip" id="rpcw">${RPI.skull}<span>Wave</span><b id="rpcwv">0 / ${R.map.waves}</b></span><span class="rpchip" id="rpck">${RPI.keep}<span>Keep</span><b id="rpckv">20 / 20</b><em class="rpkb"><i id="rpckb"></i></em></span><span class="rpchip" id="rpcs">${RPI.sup}<span>Supply</span><b id="rpcsv">0</b></span></div>
  <div class="rptr"><button class="rpsq" id="rpspd" title="Game speed (Tab)">1×</button><button class="rpsq" id="rppau" title="Pause (Esc)"><svg viewBox="0 0 24 24"><path d="M7 5h4v14H7zM13 5h4v14h-4z" fill="currentColor"/></svg></button></div>
  <button class="rpgo" id="rpgo"><span class="rpgoi">${RPI.play}</span><span class="rpgot"><b id="rpgob">Start wave 1</b><small id="rpgos">Space</small></span></button>
  <div class="rpboss" id="rpboss" hidden><img alt="" src="${rpMobURL('behemoth',64)}"><span><b>Basalt Behemoth</b><em><i id="rpbossf"></i></em></span></div>
  <div class="rpinfo" id="rpinfo" hidden></div>
  <div class="rpring" id="rpring" hidden></div>
  <div class="rpfoe" id="rpfoe" hidden></div>
  <div class="rptoast" id="rptoast" hidden></div>
  <div class="rpdock">
   <div class="rpcmd"><div class="rphint">Towers fire on their own.<br>Type words to charge Command.</div>
    <div class="rpword" id="rpword" tabindex="-1"></div>
    <div class="rpmeter"><label>Command <b id="rpcmdn">0 / ${RPT.CMD}</b></label><i><s id="rpcmdf"></s></i><span class="rpcombo" id="rpcombo"></span></div>
    <div class="rpabs">${ab('over','Overcharge')}${ab('slow','Slow field')}${ab('repair','Repair')}</div></div>
   <div class="rpcards" id="rpcards">${RP_TWORDER.map(card).join('')}<div class="rpnext" id="rpnext"></div></div>
   <div class="rpkbd" id="rpkbd" hidden>${['qwertyuiop','asdfghjkl','zxcvbnm'].map(r=>`<div>${[...r].map(c=>`<button data-c="${c}" tabindex="-1">${c}</button>`).join('')}</div>`).join('')}<div><button class="rpkx" data-x="1" tabindex="-1">Towers</button></div></div>
  </div>`;
 RPH={};
 h.querySelector('#rpgo').onclick=()=>{if(R.wst==='build')rpWaveStart();else rpSpeed()};
 h.querySelector('#rpspd').onclick=()=>rpSpeed();h.querySelector('#rppau').onclick=()=>rpPause(true);
 h.querySelectorAll('.rpab').forEach(b=>b.onclick=()=>{const k=b.dataset.ab;rpAbility(k,k==='repair'?true:k==='over'?(R.sel?true:undefined):undefined)});
 h.querySelectorAll('.rpcard').forEach(b=>b.onclick=()=>{const t=b.dataset.tw;if(R.supply<rpCost(t,1)){rpSfx('no');rpToast('Not enough supply',1.2,'#ff8a9a');return}
  if(R.selPad&&!R.selPad.tw){rpBuild(R.selPad,t);return}R.place=R.place===t?null:t;R.sel=null;R.selPad=null;if(R.place)rpToast(`Click a glowing pad to build the ${RPTW[t].n}`,2,'#ffd45a')});
 const kb=h.querySelector('#rpkbd');kb.addEventListener('pointerdown',e=>{const b=e.target.closest('button');if(!b)return;e.preventDefault();if(b.dataset.c)rpKey(b.dataset.c);else if(b.dataset.x){kb.hidden=true;$('rpcards').hidden=false}});
 h.querySelector('#rpword').onclick=()=>{let tm=false;try{tm=TM()}catch(e){}if(tm){kb.hidden=!kb.hidden;$('rpcards').hidden=!kb.hidden}};
 try{if(TM()){kb.hidden=false;$('rpcards').hidden=true}}catch(e){}
 rpHudType();rpHudTick(true);pb.style.display='none';try{$('cn').classList.add('dkhid')}catch(e){}}
function rpHudOff(){const h=$('rphud');if(h){h.hidden=true;h.innerHTML=''}RPH=null}
function rpHudType(){const R=RPX,el=$('rpword');if(!R||!el)return;el.innerHTML=[...R.word].map((c,i)=>`<i class="${i<R.wi?'d':i===R.wi?'n':''}">${c}</i>`).join('')+'<s class="rpcaret"></s>';
 el.classList.toggle('bad',!!R.bad);if(R.bad){el.classList.remove('shk');void el.offsetWidth;el.classList.add('shk')}}
function rpHudWord(gain){const el=$('rpword'),m=$('rpcmdn');if(!el)return;const f=document.createElement('span');f.className='rpgain';f.textContent=`+${gain}`;el.parentNode.appendChild(f);setTimeout(()=>f.remove(),900);
 el.classList.remove('pop');void el.offsetWidth;el.classList.add('pop')}
function rpHudFoeCard(id){const el=$('rpfoe');if(!el||!RPMOB[id])return;const r=RPP();r.hint[id]=1;
 el.innerHTML=`<img alt="" src="${rpMobURL(id,96)}"><span><small>NEW FOE</small><b>${esc(RPMOB[id].n)}</b><em>${esc(RP_FOETIP[id]||RPMOB[id].desc||'')}</em></span>`;el.hidden=false;el.classList.remove('in');void el.offsetWidth;el.classList.add('in');
 clearTimeout(rpHudFoeCard.t);rpHudFoeCard.t=setTimeout(()=>{if(el.isConnected)el.hidden=true},6500)}
function rpHudVictory(){const R=RPX;if(!R)return;const k=R.winKeep,st=k>=18?3:k>=10?2:1;rpHudOff();
 show(`<div class="rpvic"><h2>Victory!</h2><div class="rpvst">${[0,1,2].map(i=>`<span style="--d:${i*.18}s">${RPI.star(i<st,58)}</span>`).join('')}</div><p>${esc(R.map.n)} is safe. The keep stands at ${k} / ${RPT.KEEP}.</p>
  <div class="rpvch"><button id="rpv1">Claim rewards</button><button class="sm" id="rpv2">Keep defending: Freeplay</button></div><small>Freeplay: endless waves after victory. Each wave you survive banks extra coins, paid when the keep falls or you stop.</small></div>`,'rpx rpvx');
 $('rpv1').onclick=()=>rpFinish(true);$('rpv2').onclick=()=>{hide();rpFreeplay()};S.back=()=>rpFinish(true)}
function rpSetText(el,v){if(el&&el.textContent!==v)el.textContent=v}
function rpHudTick(force){const R=RPX,h=$('rphud');if(!R||!h||h.hidden||!RPH)return;const C=RPH;
 const sv=String(Math.floor(R.supply));if(force||C.s!==sv){C.s=sv;rpSetText($('rpcsv'),sv);const b=$('rpcs');if(b&&!force){b.classList.remove('bump');void b.offsetWidth;b.classList.add('bump')}}
 const wv=R.free?`${R.wave-R.map.waves} · free`:`${R.wave} / ${R.map.waves}`;if(C.w!==wv){C.w=wv;rpSetText($('rpcwv'),wv)}
 if(C.k!==R.keep){if(C.k!==undefined&&R.keep<C.k){const b=$('rpck');b.classList.remove('hurt');void b.offsetWidth;b.classList.add('hurt')}C.k=R.keep;rpSetText($('rpckv'),`${R.keep} / ${RPT.KEEP}`);const f=$('rpckb');if(f)f.style.transform=`scaleX(${R.keep/RPT.KEEP})`}
 const cm=Math.floor(R.cmd);if(C.c!==cm){C.c=cm;rpSetText($('rpcmdn'),`${cm} / ${RPT.CMD}`);const f=$('rpcmdf');if(f){f.style.transform=`scaleX(${cm/RPT.CMD})`;f.parentNode.classList.toggle('full',cm>=RPT.CMD)}}
 const co=R.combo>=2?`${R.combo} word streak${R.combo>=5?' · ×1.25':''}`:'';if(C.co!==co){C.co=co;rpSetText($('rpcombo'),co)}
 const ab=`${cm>=RPT.CMD}|${R.repairUsed}|${R.keep>=RPT.KEEP}|${R.aim}`;if(C.ab!==ab){C.ab=ab;h.querySelectorAll('.rpab').forEach(b=>{const k=b.dataset.ab,ok=cm>=RPT.CMD&&!(k==='repair'&&(R.repairUsed||R.keep>=RPT.KEEP));b.classList.toggle('ok',ok);b.classList.toggle('aim',R.aim===k);
  b.title=k==='repair'&&R.repairUsed?'Repair: used this wave':''})}
 /* the go button */
 const go=R.wst==='build'?(R.wave===0?`Start wave 1`:`Wave ${R.wave+1} in ${Math.ceil(Math.max(0,R.cd))}`):R.wst==='run'?(R.spd>1?'Fast ×2':'Speed ×1'):'';
 const gos=R.wst==='build'?(R.wave===0?'Space':`Space: call early +${Math.ceil(Math.max(0,R.cd))*RPT.EARLY}`):'Tab';
 if(C.go!==go+gos){C.go=go+gos;rpSetText($('rpgob'),go);rpSetText($('rpgos'),gos);const b=$('rpgo');b.hidden=R.wst==='done';b.classList.toggle('run',R.wst==='run');b.classList.toggle('fast',R.spd>1)}
 const sp=R.spd+'×';if(C.sp!==sp){C.sp=sp;rpSetText($('rpspd'),sp);$('rpspd').classList.toggle('on',R.spd>1)}
 /* cards: affordability and placement */
 const ck=RP_TWORDER.map(t=>R.supply>=rpCost(t,1)?1:0).join('')+(R.place||'');if(C.ck!==ck){C.ck=ck;h.querySelectorAll('.rpcard').forEach(b=>{b.classList.toggle('no',R.supply<rpCost(b.dataset.tw,1));b.classList.toggle('on',R.place===b.dataset.tw)})}
 /* next-wave preview */
 const nw=R.wst==='done'?-1:R.wave+(R.wst==='build'?1:0);if(C.nw!==nw){C.nw=nw;const el=$('rpnext');if(el){if(nw<0||(!R.free&&nw>R.map.waves)){el.innerHTML=''}else{const W=rpWave(R.map,nw),agg={};for(const g of W)agg[g.id]=(agg[g.id]||0)+g.n;
   el.innerHTML=`<small>${R.wst==='build'?'Next':'Now'}: wave ${R.free?nw-R.map.waves+' (free)':nw}</small><div>${Object.keys(agg).map(id=>`<span title="${esc(RPMOB[id]?RPMOB[id].n:id)}"><img alt="" src="${rpMobURL(id,56)}"><b>×${agg[id]}</b></span>`).join('')}</div>`}}}
 /* boss bar */
 const bo=R.boss&&!R.boss.dead?R.boss:null;if(C.bo!==!!bo){C.bo=!!bo;$('rpboss').hidden=!bo}if(bo){const f=$('rpbossf');if(f)f.style.transform=`scaleX(${Math.max(0,bo.hp/bo.mx)})`}
 /* info panel and build ring */
 rpHudInfo(R,C);rpHudRing(R,C);
 /* toast */
 const tt=R.toast?R.toast.txt:'';if(C.tt!==tt){C.tt=tt;const el=$('rptoast');el.hidden=!tt;if(tt){el.textContent=tt;el.style.color=R.toast.c;el.classList.remove('in');void el.offsetWidth;el.classList.add('in')}}
 /* the Play tab stays lit; the touch keyboard follows the device */
}
function rpHudInfo(R,C){const el=$('rpinfo'),tw=R.sel;const key=tw?`${tw.type}|${tw.tier}|${tw.prio}|${R.supply>=(tw.tier<3?rpCost(tw.type,tw.tier+1):1e9)}|${tw.kills}|${tw.over>0}`:'';
 if(C.in===key)return;C.in=key;if(!tw){el.hidden=true;return}const T=RP_TW[tw.type],TW=RPTW[tw.type],i=tw.tier-1,nx=tw.tier<3?tw.tier:null;
 const bar=(lab,v,max,nv)=>`<div class="rpst"><span>${lab}</span><i>${[0,1,2,3,4,5].map(k=>`<s class="${k<Math.round(v/max*6)?'on':nv!=null&&k<Math.round(nv/max*6)?'up':''}"></s>`).join('')}</i></div>`;
 const dps=(t,j)=>T.dmg[j]/T.cd[j]*(T.chain?T.chain[j]*.7:1);
 const extra=T.slow?bar('Slow',T.slow[i],.6,nx!=null?T.slow[nx]:null):T.splash?bar('Splash',T.splash[i],90,nx!=null?T.splash[nx]:null):T.chain?bar('Chain',T.chain[i],5,nx!=null?T.chain[nx]:null):bar('Armor pierce',Math.min(T.ap[i],12),12,nx!=null?Math.min(T.ap[nx],12):null);
 const can=nx!=null&&R.supply>=rpCost(tw.type,tw.tier+1);
 el.innerHTML=`<button class="rpix" id="rpix" aria-label="Close">×</button><div class="rpih"><img alt="" src="${rpIconCanvas(tw.type,tw.tier,tw.skin,120)}"><span><b>${TW.n}</b><em>${[1,2,3].map(k=>RPI.star(k<=tw.tier,16)).join('')} Tier ${tw.tier}</em><small>${T.desc}</small></span></div>
  ${nx!=null?`<button class="rpup${can?'':' no'}" id="rpup"><b>Upgrade · ${rpCost(tw.type,tw.tier+1)} supply</b><small>${T.up[tw.tier-1]}</small></button>`:`<div class="rpmax">Fully upgraded</div>`}
  <div class="rpsts">${bar('Range',T.range[i],300,nx!=null?T.range[nx]:null)}${bar('Damage',dps(T,i),220,nx!=null?dps(T,nx):null)}${bar('Fire rate',1/T.cd[i],1.7,nx!=null?1/T.cd[nx]:null)}${extra}</div>
  <div class="rppri"><span>Target</span>${['first','strong','close'].map(p=>`<button data-p="${p}" class="${tw.prio===p?'on':''}">${p[0].toUpperCase()+p.slice(1)}</button>`).join('')}</div>
  <div class="rpif"><span>${tw.kills} defeated${tw.over>0?' · <b class="rpoc">Overcharged</b>':''}</span><button class="rpsell" id="rpsell">Sell +${Math.round(tw.spent*RPT.SELL)}</button></div>`;
 el.hidden=false;$('rpix').onclick=()=>{R.sel=null};const up=$('rpup');if(up)up.onclick=()=>rpUpgrade(tw);$('rpsell').onclick=()=>rpSell(tw);
 el.querySelectorAll('.rppri button').forEach(b=>b.onclick=()=>{tw.prio=b.dataset.p;rpSfx('key',2)})}
function rpHudRing(R,C){const el=$('rpring'),p=R.selPad&&!R.selPad.tw?R.selPad:null,key=p?`${p.i}|${RP_TWORDER.map(t=>R.supply>=rpCost(t,1)?1:0).join('')}`:'';if(C.rg===key)return;C.rg=key;
 if(!p){el.hidden=true;return}const ang=[-150,-110,-70,-30],rad=108;
 el.innerHTML=RP_TWORDER.map((t,i)=>{const a=ang[i]*Math.PI/180,x=Math.cos(a)*rad,y=Math.sin(a)*rad,ok=R.supply>=rpCost(t,1);return `<button class="rprb${ok?'':' no'}" data-tw="${t}" style="--x:${x}px;--y:${y}px;--d:${i*.04}s;--c:${RPTW[t].col}" title="${RPTW[t].n}: ${RP_TW[t].desc}"><img alt="" src="${rpIconCanvas(t,1,rpSkinOf(t),80)}"><b>${RPI.sup}${rpCost(t,1)}</b><em>${RPTW[t].n}</em></button>`}).join('');
 el.style.left=Math.max(140,Math.min(1460,p.x))+'px';el.style.top=Math.max(150,p.y-6)+'px';el.hidden=false;
 el.querySelectorAll('.rprb').forEach(b=>b.onclick=e=>{e.stopPropagation();rpBuild(p,b.dataset.tw)})}
/* ---------- pause ---------- */
function rpPauseMenu(){const R=RPX;rpHudOff();show(`<div class="rppause"><h2>Paused</h2><p>Runestone Ramparts · ${esc(R.map.n)} · ${R.free?`freeplay wave ${R.wave-R.map.waves}`:`wave ${R.wave} of ${R.map.waves}`} · keep ${R.keep} / ${RPT.KEEP}</p>
 <div class="rpph"><span><kbd>Click</kbd> a pad to build, a tower to upgrade</span><span><kbd>Type</kbd> words to charge Command</span><span><kbd>1</kbd><kbd>2</kbd><kbd>3</kbd> Overcharge, Slow field, Repair</span><span><kbd>Space</kbd> start or call the next wave</span><span><kbd>Tab</kbd> game speed</span><span><kbd>Esc</kbd> resume</span></div>
 <div class="row"><button id="rp1">Resume</button></div><div class="row">${R.free?'<button class="sm" id="rp4">End freeplay and claim</button>':''}<button class="sm" id="rp2">Restart</button><button class="sm dg" id="rp3">Quit to maps</button></div></div>`,'rpx rppx');
 S.back=()=>rpPause(false);$('rp1').onclick=()=>rpPause(false);const f=$('rp4');if(f)f.onclick=()=>{R.pause=false;hide();rpFinish(true)};
 $('rp2').onclick=e=>{const t=e.target;if(t.dataset.a)rpRestart();else{t.dataset.a=1;t.textContent='Click again to restart';setTimeout(()=>{if(t.isConnected){t.dataset.a='';t.textContent='Restart'}},3000)}};$('rp3').onclick=()=>rpQuit()}
/* ---------- result ---------- */
function rpResult(){const R=RPX,r=R&&R.result;if(!r)return;S.mode='over';const map=R.map,nx=RP_MAPS[RP_MAPS.indexOf(map)+1];
 const unl=r.unl.map(s=>`<span class="rpunl"><img alt="" src="${rpIconCanvas(s.tw,3,s.k,96)}"><b>${esc(s.n)}</b><small>New tower skin</small></span>`).join('');
 show(`<div class="rpres ${r.won?'win':'lose'}"><h2>${r.won?(r.free?'Freeplay over':'Victory!'):'The keep has fallen'}</h2>
  <div class="rpvst">${[0,1,2].map(i=>`<span style="--d:${.25+i*.2}s">${RPI.star(i<r.stars,62)}</span>`).join('')}</div>
  <p class="rpsub">${esc(map.n)} · ${r.won?`keep ${r.keep} / ${RPT.KEEP}${r.newStars?' · <b class="rpnb">new best!</b>':''}`:`held ${r.cleared} of ${map.waves} waves`}${r.free?` · ${r.fpWaves} freeplay waves`:''}</p>
  <div class="res"><div><b>${r.kills}</b>Monsters defeated</div><div><b>${r.words}</b>Words typed</div><div><b>${r.maxCombo}</b>Best word streak</div><div><b>${r.built}</b>Towers built</div><div><b>${r.leaked}</b>Got through</div><div><b>${rpFmtT(r.time)}</b>Time</div></div>
  <div class="wrpay"><span class="wrpayc"><i class="wrcoinb" id="wrcoinb"></i><b id="wrtot">+0</b> coins</span><small>${r.won?'victory':'defense'} pay ${r.pay.toLocaleString()}${r.first?' (first win today ×1.5)':''}${r.fp?` · freeplay ${r.fp}`:''}${r.lg?` · level-up bonus ${r.lg}`:''}</small></div>
  <p class="wrxp">Earned <b>${r.xp.toLocaleString()} XP</b>${r.l1>r.l0?`<br><b>Level up! You are now level ${r.l1}.</b>`:''}${r.xn||''}${r.ttl?'<br><b style="color:#ffd45a">Rampart Warden! The title is yours in the bounty exchange.</b>':''}</p>
  ${unl?`<div class="rpunls">${unl}</div>`:''}
  <div class="row"><button id="rp1">${r.won&&nx&&RP_MAPOPEN(nx)&&!(RPP().stars[nx.id])?`Next map: ${esc(nx.n)}`:'Play again'}</button><button class="sm" id="rp2">Maps</button><button class="sm" id="hm">Home</button></div></div>`,'rpx rprx');
 const goNext=r.won&&nx&&RP_MAPOPEN(nx)&&!(RPP().stars[nx.id]);$('rp1').onclick=()=>{const id=goNext?nx.id:map.id;rpLeave();rpStart(id)};$('rp2').onclick=()=>rpQuit();$('hm').onclick=()=>{rpLeave();title()};S.back=()=>{rpLeave();title()};
 const tt=$('wrtot');if(rpRM()||!r.total){if(tt)tt.textContent='+'+r.total.toLocaleString()}else setTimeout(()=>{try{wrCount(tt,r.total);wrCoinsFly(tt)}catch(e){if(tt)tt.textContent='+'+r.total.toLocaleString()}},700)}
const rpFmtT=s=>`${Math.floor(s/60)}:${String(Math.floor(s%60)).padStart(2,'0')}`;
/* ---------- the hub ---------- */
let RPSEL='moss';
function rampartsMenu(back){const r=RPP();r.seen=1;save();if(!RP_MAPOPEN(RP_MAP(RPSEL)))RPSEL='moss';const sn=rpStarN();
 const mcard=m=>{const open=RP_MAPOPEN(m),st=r.stars[m.id]||0,b=r.best[m.id],prev=RP_MAPS[RP_MAPS.indexOf(m)-1];
  return `<button class="rpmc${m.id===RPSEL?' on':''}${open?'':' lock'}" data-m="${m.id}" ${open?'':'aria-disabled="true"'}><canvas width="480" height="198" data-m="${m.id}"></canvas>
  <span class="rpmct"><b>${esc(m.n)}</b><small>${esc(m.sub)} · ${m.waves} waves</small></span><span class="rpmcs">${[0,1,2].map(i=>RPI.star(i<st,24)).join('')}</span>
  <em class="rpmcb">${open?(b?`Best keep ${b.keep} / ${RPT.KEEP}${r.fp[m.id]?` · freeplay ${r.fp[m.id]}`:''}`:'Not yet defended'):`Earn a star on ${esc(prev.n)}`}</em></button>`};
 const skin=s=>{const own=!!r.own[s.tw+':'+s.k],on=rpSkinOf(s.tw)===s.k;return `<button class="rpsk${own?'':' lock'}${on?' on':''}" data-tw="${s.tw}" data-k="${s.k}" title="${own?(on?'Equipped. Click to use the standard look.':'Click to equip'):`Unlocks at ${s.need} stars`}"><img alt="" src="${rpIconCanvas(s.tw,3,s.k,88)}"><b>${esc(s.n)}</b><small>${own?(on?'Equipped':'Owned'):`${RPI.star(1,13)} ${s.need}`}</small></button>`};
 const m=RP_MAP(RPSEL);
 show(`<div class="rpx rphub"><canvas class="rphbg" id="rphbg" width="1600" height="900"></canvas>
  <div class="rphl"><p class="rpkick">TOWER DEFENSE</p><h1 class="rptitle">Runestone Ramparts</h1><p class="rptag">Build towers. Type to command. Hold the keep.</p>
   <div class="rpready"><small>Ready to defend</small><b id="rprn">${esc(m.n)}</b><span id="rpri">${m.waves} waves · up to ${Math.round(m.pay*1.0*RPT.FIRSTDAY).toLocaleString()} coins today</span><button class="rpgo2" id="rpdef"><span>Defend the keep</span><i>›</i></button></div>
   <div class="rphow"><span><b>1</b>Click a stone pad and pick a tower</span><span><b>2</b>Type words to charge Command</span><span><b>3</b>Overcharge, slow or repair</span></div></div>
  <div class="rphr"><div class="rpmaps">${RP_MAPS.map(mcard).join('')}</div>
   <div class="rparm"><div class="rparmh"><b>Rampart Armory</b><span>${RPI.star(1,16)} ${sn} / 9 stars</span><em><i style="transform:scaleX(${sn/9})"></i></em></div><div class="rpsks">${RP_SKINS.map(skin).join('')}<span class="rpsk rpttl${sn>=RP_TITLE_NEED?'':' lock'}"><span class="rpttli">${RPI.keep}</span><b>Rampart Warden</b><small>${sn>=RP_TITLE_NEED?'Title earned':`Title · ${RPI.star(1,13)} 9`}</small></span></div><p class="rparmn">Skins and the title are only found here. Stars: win = 1, keep 10+ = 2, keep 18+ = 3.</p></div></div>
  <button class="sm" id="b">Back</button></div>`,'rpx rphubx');
 S.view='ramparts';S.back=back||title;{const bb=$('b');if(bb)bb.onclick=back||title}
 $('rpdef').onclick=()=>rpStart(RPSEL);
 ov.querySelectorAll('.rpmc').forEach(b=>{b.onclick=()=>{if(b.classList.contains('lock')){rpSfx('no');return}if(RPSEL===b.dataset.m){rpStart(RPSEL);return}RPSEL=b.dataset.m;rampartsMenu(back)}});
 ov.querySelectorAll('.rpmc canvas').forEach(cv2=>{const mm=RP_MAP(cv2.dataset.m),B=rpBake(mm),g=cv2.getContext('2d');g.drawImage(B.c,0,0,1600,660,0,0,480,198)});
 ov.querySelectorAll('.rpsk[data-k]').forEach(b=>b.onclick=()=>{if(b.classList.contains('lock')){rpSfx('no');return}const r2=RPP();r2.skin[b.dataset.tw]=rpSkinOf(b.dataset.tw)===b.dataset.k?'base':b.dataset.k;save();rpSfx('up');rampartsMenu(back)});
 rpHubBG()}
/* the hub backdrop: the first map, with a ring of towers firing at a slow parade of monsters */
function rpHubBG(){const cv2=$('rphbg');if(!cv2)return;const map=RP_MAP(RPSEL),B=rpBake(map),G=rpGeo(map),g=cv2.getContext('2d');
 const tws=G.pads.slice(0,8).map((p,i)=>({x:p.x,y:p.y,type:RP_TWORDER[i%4],tier:1+(i%3)}));const ids=['scamp','bulwark','gloom','golem','ooze','shaman'];
 const draw=t=>{g.setTransform(1,0,0,1,0,0);g.drawImage(B.c,0,0,1600,660,0,0,1600,900*660/660*1.0);g.save();g.scale(1,900/660);
  for(let i=0;i<6;i++){const s=((t*40+i*230)%G.len),p=rpAt(G,s),id=ids[i];try{rpMobBlit(g,id,p.x,p.y,(t*1.2+i*.3)%1,{s:1,flip:Math.cos(p.a)<-.2,a:1})}catch(e){}}
  for(const tw of tws){g.save();g.translate(tw.x,tw.y);try{rpTowerDraw(g,tw.type,tw.tier,rpSkinOf(tw.type),t,{aim:Math.sin(t*.6+tw.x)*1.2,fire:0,over:0})}catch(e){}g.restore()}
  g.restore();const q=g.createLinearGradient(0,0,1600,0);q.addColorStop(0,'rgba(8,5,22,.92)');q.addColorStop(.36,'rgba(8,5,22,.55)');q.addColorStop(.6,'rgba(8,5,22,.25)');q.addColorStop(1,'rgba(8,5,22,.5)');g.fillStyle=q;g.fillRect(0,0,1600,900)};
 draw(1);if(!rpRM())LIVE.push({cv:cv2,fn:draw,slow:2})}
/* ---------- hooks ---------- */
MG.ramparts=bP('M18 82V40h12v-12h10v12h20v-12h10v12h12v42H58V64H42v18z','#8a8aa8')+bF('M60 40h22v42H60z','#000',.2)+bP('M44 64h12v18H44z','#3a2414')+bP('M28 22l6-10 6 10z','#ffd45a')+bH('M22 46h20','#fff',3)+bS(76,22,5,'#9fe8ff');
MA.ramparts='#9fe8ff';
{const m0=modeSheet;modeSheet=function(){const r=m0.apply(this,arguments);try{const sh=document.querySelector('.dks .dkpv[data-v="m"]')||document.querySelector('.dkpv[data-v="m"]'),g=sh&&sh.querySelector('.dkmg');if(g&&!sh.querySelector('#dmrp')){const p=RPP(),b=document.createElement('button');b.className='dkm dkmrp';b.id='dmrp';b.style.setProperty('--c','#9fe8ff');
  b.innerHTML=`<span class="dkmi">${mico('ramparts',58)}</span><span class="dkmt"><b>Runestone Ramparts${p.seen?'':' <em class="dkmnew">NEW</em>'}</b><small>Tower defense. Build, type to command, hold the keep. ${rpStarN()} / 9 stars.</small></span><i class="dkchv">›</i>`;
  g.insertBefore(b,g.firstChild);b.onclick=()=>{dkClose(true);setTimeout(()=>rampartsMenu(title),0)}}}catch(e){console.error(e)}return r}}
/* the home card takes Moonlit Fishing's slot (Fishing stays in Choose a mode and on the F key) */
{const t0=title;title=function(){const r=t0.apply(this,arguments);try{rpHomeCard()}catch(e){console.error(e)}return r}}
function rpHomeCard(){const sc=ov.querySelector('.dksc');if(!sc||sc.querySelector('#dkrp'))return;const p=RPP(),n=rpStarN(),fish=sc.querySelector('#dkfish'),d=document.createElement('div');
 d.innerHTML=`<button class="dkcard dkrp dklive dkg dktilt" id="dkrp" title="Runestone Ramparts (U)" aria-label="Runestone Ramparts, tower defense${p.seen?'':', new mode'}. ${n} of 9 stars"><canvas class="dkcv" width="560" height="320" aria-hidden="true"></canvas><i class="dkgl"></i>${p.seen?'':'<em class="dknew">NEW</em>'}<span class="dkcl"><small>${p.seen?'TOWER DEFENSE':'NEW MODE'}</small><b>Runestone Ramparts</b><small class="dkevv">${n?`${n} / 9 stars`:'Hold the keep'} <i>›</i></small></span></button>`;
 const card=d.firstChild;if(fish)fish.replaceWith(card);else{sc.appendChild(card)}card.onclick=()=>rampartsMenu(title);
 const cv2=card.querySelector('canvas'),g=cv2.getContext('2d'),map=RP_MAP('moss'),B=rpBake(map),G=rpGeo(map);
 const draw=t=>{g.setTransform(1,0,0,1,0,0);g.drawImage(B.c,560,150,700,400,0,0,560,320);const k=560/700;g.save();g.scale(k,k);g.translate(-560,-150);
  for(let i=0;i<3;i++){const s=((t*36+i*180)%G.len),pp=rpAt(G,s);if(pp.x>540&&pp.x<1280)try{rpMobBlit(g,['scamp','bulwark','golem'][i],pp.x,pp.y,(t+i*.3)%1,{s:1,flip:Math.cos(pp.a)<-.2})}catch(e){}}
  for(const pd of G.pads)if(pd.x>580&&pd.x<1260&&pd.y>170&&pd.y<540){g.save();g.translate(pd.x,pd.y);try{rpTowerDraw(g,RP_TWORDER[pd.x%4],2,'base',t,{aim:Math.sin(t+pd.x)})}catch(e){}g.restore()}g.restore();
  const q=g.createLinearGradient(0,0,560,0);q.addColorStop(0,'#0c0822c0');q.addColorStop(.45,'#0c082230');q.addColorStop(1,'#0c082200');g.fillStyle=q;g.fillRect(0,0,560,320)};
 draw(2);if(!dkRM())LIVE.push({cv:cv2,fn:draw,slow:3,ph:1})}
{const hk0=homeKey;homeKey=function(e){if(HOME&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&(e.key==='u'||e.key==='U')&&!document.querySelector('.dks.on')){const ae=document.activeElement;if(!(ae&&ae!==inp&&/INPUT|TEXTAREA|SELECT/.test(ae.tagName))){e.preventDefault();rampartsMenu(title);return true}}return hk0.apply(this,arguments)}}
{const d0=dkDetect;dkDetect=function(html){if(typeof html==='string'&&/class="rpx rphub/.test(html))return'pl';return d0.apply(this,arguments)}}
try{HELP.Modes.unshift(['Runestone Ramparts','Tower defense. Monsters march along the road toward your keep. Click a stone pad to build a Rune Ballista (single target, hits flyers, pierces armor), an Ember Brazier (splash), a Frost Spire (slows) or a Storm Bell (chain lightning, double damage to flyers); click a tower to upgrade it (three tiers) or sell it. Towers fire on their own. Type the word in the command bar to charge Command, then press 1 Overcharge (a tower fires much faster), 2 Slow Field (on the road) or 3 Repair (once per wave). Space starts or calls the next wave early for bonus supply; Tab switches speed. Win a map for stars: they unlock tower skins and the Rampart Warden title, found only here. After a win, Freeplay keeps the waves coming for bonus coins.']);
 const sc=HELP.Shortcuts&&HELP.Shortcuts.find(x=>x[0]==='F W G');if(sc){sc[0]='F W G U';sc[1]='Moonlit Fishing, Lantern Caravan, Runestone Riddle, Runestone Ramparts.'}}catch(e){}
try{const t={k:'ramparts',tier:1,ok:()=>true,mk:r=>({n:1}),txt:c=>'Win a Runestone Ramparts map'};BTPL.push(t);BTK.ramparts=t}catch(e){}
try{BT_TITLES.push(['rampartwarden','Rampart Warden',1e9]);const b0=bountyBoard;bountyBoard=function(){const r=b0.apply(this,arguments);try{const x=ov.querySelector('[data-buy="t:rampartwarden"]');if(x){const s=document.createElement('span');s.className='rrlock';s.textContent='Earn: 9 stars in Runestone Ramparts';x.replaceWith(s)}}catch(e){}return r}}catch(e){}
/* music: the caravan's soundtrack engine plays the road theme in a run and the camp theme on the hub */
function wraWant(){try{if(typeof S==='undefined')return null;if(WRX&&S.wr&&(S.mode==='wagon'||S.mode==='over'))return 'road';if(S.mode==='title'&&S.view==='wagon'&&$('wrhub'))return 'camp';
 if(RPX&&S.rp&&(S.mode==='ramparts'||S.mode==='over'))return 'road';if(S.mode==='title'&&S.view==='ramparts'&&ov.querySelector('.rphub'))return 'camp';return null}catch(e){return null}}
{const s0=wraState;wraState=function(){const R=RPX;if(R&&S.rp&&S.mode==='ramparts'){if(R.over||R.pause||R.wst!=='run')return{v:0,danger:0,flare:0};let d=0;for(const e of R.foes)if(!e.dead&&e.s>R.G.len*.8)d++;return{v:1,danger:Math.min(1,d/4+(R.boss?.5:0)),flare:R.cmd>=RPT.CMD?1:0}}return s0.apply(this,arguments)}}
/* touch: the run has its own keyboard in the dock */

/* the legacy corner buttons stay hidden for the whole run, the victory choice and the result */
{const m0=mfxCorner;mfxCorner=function(){const r=m0.apply(this,arguments);try{const c=$('cn');if(c&&(S.rp||RPX))c.classList.add('mfxhid')}catch(e){}return r}}
