/* ===== RUNESTONE TOWER DEFENSE 9.9i: the Starfall Observatory in battle (97e, after 97d) =====
   The tenth tower (key U, 450 supply), the winner of the Tower Vote. A global support tower: it reaches the whole map, ground and air.
   While a star charges, the telescope swings toward the toughest monster on the map (tw.aim = lean, on a damped spring, so the turn
   eases in and settles), then calls a star down on it. The red reticle shows where it will land. A star hit:
   - marks the monster: it takes RP_TW.star.mark more damage from every tower for markT seconds (several Observatories do not stack the
     bonus, they spread out: a target that is already marked counts for less);
   - finishes it if it is left below exec of its health (never a boss); bosses take double star damage instead (RPSF.boss).
   Tier 3 Star Shards: the star bursts into shards that hit and mark the toughest monsters near the impact. Tier 4 Mythic Comet: the
   impact also hits and marks everything within RP_TW.star.comet px. Tier 5 Meteor Shower: every shower[4]th cast also drops RPSF.showerN
   more stars on the next toughest monsters. Overcharge speeds it up and adds 15% damage like every other tower.
   Targeting (the info panel's Target buttons): Strong (default) = the toughest monster, preferring one the star can finish and one
   that is not marked yet; First = the one closest to the castle; Close = the nearest to the tower.
   Monster state: e.mk (mark seconds left), e.mkK (bonus). State on RPX: sfStars [{e,x0,y0,cx,cy,x1,y1,t,d,tw,tier,dmg,kind,seed}],
   sfHits [{x,y,t,d,tier,big}], sfCasts. Tower: tw.cd, tw.charge, tw.fire, tw.aim (lean), tw.lv (lean speed), tw.tg (target), tw.nv. */
RP_TW.star={cost:[450,320,560,1100,1800],range:[0,0,0,0,0],dmg:[150,220,320,420,560],cd:[3,2.9,2.8,2.7,2.6],ap:[5,8,99,99,99],
 mark:[.18,.2,.22,.25,.28],markT:[4,4.5,5,5.5,6],exec:[.1,.12,.14,.15,.15],shards:[0,0,2,3,4],comet:[0,0,0,90,100],shower:[0,0,0,0,4],air:1,ground:1,
 desc:'Calls falling stars down on the toughest monster anywhere on the map, ground or air. A hit marks it: it takes more damage from every tower. Finishes weakened monsters; bosses take double.',
 up:['Brighter stars: more damage, a stronger and longer mark.','Star Shards: each star bursts into two shards that hit and mark nearby monsters.','Mythic comet: the impact hits and marks everything around it.','Celestial meteor shower: every fourth cast rains five more stars.']};
RP_TWORDER.push('star');RP_KEYS.push('U');
const RPSF={boss:2,shardK:.45,shardR:180,cometK:.35,showerN:5,showerK:.7,charge:.85,flight:.72,k:30,z:.72};
/* marked monsters take more damage from everything */
{const h0=rpHurt;rpHurt=function(e,dmg,ap,src){if(e&&e.mk>0&&e.mkK)dmg*=1+e.mkK;return h0.call(this,e,dmg,ap,src)}}
/* default target mode: the toughest monster */
{const b0=rpBuild;rpBuild=function(pad,type){const r=b0.apply(this,arguments);try{if(r!==false&&type==='star'&&pad&&pad.tw&&pad.tw.type==='star'){pad.tw.prio='strong';pad.tw.aim=.55;pad.tw.lv=0}}catch(e){}return r}}
const rpsfAt=(R,e)=>{const q=rpPos(R,e);return{x:q.x,y:q.y-(e.air?40:16)}};
/* pick a target anywhere: excl = monsters already chosen this cast */
function rpsfPick(R,tw,dmg,excl){const T=RP_TW.star,i=tw.tier-1,ex=T.exec[i];let best=null,bv=-1e18;
 const aimed=new Map();for(const s of R.sfStars)if(s.e)aimed.set(s.e,(aimed.get(s.e)||0)+s.dmg);
 for(const e of R.foes){if(e.dead||e.s<0||(excl&&excl.has(e)))continue;const inc=aimed.get(e)||0,left=e.hp-inc;if(left<=0||(inc&&!e.boss&&left<=ex*e.mx))continue;/* already doomed by a star on its way */
  const d=dmg*(e.boss?RPSF.boss:1)*(1+(e.mk>.8?e.mkK||0:0)),fin=!e.boss&&left-d<=ex*e.mx;let v;
  if(tw.prio==='first')v=e.s/rpLen(R,e)*1e3+(fin?300:0);
  else if(tw.prio==='close'){const q=rpPos(R,e);v=-rpD2(q.x,q.y,tw.x,tw.y)}
  else{v=e.mx*(e.boss?1.4:1)*(fin?3:1)*(e.mk>1.2?.55:1)*(inc?.5:1)+left*.01}
  if(v>bv){bv=v;best=e}}
 return best}
function rpsfSfx(k){try{if(k==='charge'){beep(1320,.06,'sine',.06)}
 else if(k==='cast'){[1568,2093,2637].forEach((f,j)=>setTimeout(()=>beep(f,.07,'triangle',.08),j*45))}
 else if(k==='hit'){beep(880+Math.random()*120,.06,'triangle',.12);setTimeout(()=>beep(220,.14,'sine',.12),30)}
 else if(k==='fin'){[1175,1568,2349].forEach((f,j)=>setTimeout(()=>beep(f,.08,'square',.06),j*50))}
 else if(k==='shower'){[784,988,1175,1568,1976].forEach((f,j)=>setTimeout(()=>beep(f,.1,'triangle',.1),j*70))}}catch(e){}}
/* launch a star at monster e: it falls out of the sky from the tower's side, curving in */
function rpsfLaunch(R,tw,e,dmg,kind,delay,from){const p=rpsfAt(R,e),side=p.x>=tw.x?1:-1;let x0,y0,cx,cy,d;
 if(from){x0=from.x;y0=from.y;cx=(x0+p.x)/2;cy=Math.min(y0,p.y)-90;d=.38}
 else{x0=p.x-side*(150+Math.random()*60);y0=Math.min(p.y-380,-30);cx=p.x-side*40;cy=y0+60;d=RPSF.flight}
 R.sfStars.push({e,x0,y0,cx,cy,x1:p.x,y1:p.y,t:-(delay||0),d,tw,tier:tw.tier,dmg,kind:kind||'main',seed:Math.random()*99})}
function rpStarFire(R,tw,dt){const T=RP_TW.star,i=tw.tier-1,sp=tw.over>0?RPT.AB.over.k:1;tw.over=Math.max(0,tw.over-dt);
 tw.fire=Math.max(0,(tw.fire||0)-dt*1.7);tw.cd-=dt*sp;const dmgK=tw.over>0?1.15:1,dmg=T.dmg[i]*dmgK;
 /* the target: chosen as the charge starts (so the scope has time to swing), kept while it lives */
 if(tw.tg&&(tw.tg.dead||tw.tg.s<0))tw.tg=null;
 if(tw.cd<RPSF.charge){if(!tw.tg)tw.tg=rpsfPick(R,tw,dmg);if(tw.tg&&!(tw.charge>0))rpsfSfx('charge');tw.charge=tw.tg?Math.min(1,1-tw.cd/RPSF.charge):Math.max(0,(tw.charge||0)-dt*3)}
 else tw.charge=Math.max(0,(tw.charge||0)-dt*3);
 /* the swing: a damped spring toward the target's side, it keeps following the last target, and scans the sky slowly when idle */
 {let goal;const ref=tw.tg||(tw.lt&&!tw.lt.dead&&tw.lt.s>=0?tw.lt:null);if(ref){const p=rpsfAt(R,ref),a=Math.atan2(p.y-tw.y,p.x-tw.x);goal=Math.max(-1,Math.min(1,Math.cos(a)*1.25))}else goal=Math.sin(R.t*.35+tw.ph)*.55;
  const k=RPSF.k,c=2*RPSF.z*Math.sqrt(k);tw.lv=(tw.lv||0)+(k*(goal-(tw.aim||0))-c*(tw.lv||0))*dt;tw.aim=(tw.aim||0)+tw.lv*dt}
 if(tw.cd>0)return;
 const e=tw.tg&&!tw.tg.dead?tw.tg:rpsfPick(R,tw,dmg);if(!e){tw.cd=.15;tw.charge=Math.max(0,tw.charge-.4);return}
 tw.cd=T.cd[i];tw.fire=1;tw.charge=0;tw.nv=(tw.nv||0)+1;tw.lt=e;R.sfCasts=(R.sfCasts||0)+1;rpsfLaunch(R,tw,e,dmg,'main',0);
 const lz=rpsfLens(tw.tier,tw.aim,1);try{ptBurst(R.fx,tw.x+lz.x,tw.y+lz.y,R.lite?4:9,rpsfBoltC(tw.tier),{v:160,s:3,up:1,g:120})}catch(x){}
 rpsfSfx('cast');
 /* tier 5: the meteor shower */
 const sn=T.shower[i];if(sn&&tw.nv%sn===0){const ex=new Set([e]);for(let k=0;k<RPSF.showerN;k++){const f=rpsfPick(R,tw,dmg*RPSF.showerK,ex);if(!f)break;ex.add(f);rpsfLaunch(R,tw,f,dmg*RPSF.showerK,'shower',.18+k*.13)}
  rpText(tw.x,tw.y-RPLAY.star[5].top-14,'METEOR SHOWER','#fff2b0',20);setTimeout(()=>rpsfSfx('shower'),150)}
 tw.tg=null}
/* hurt, finish and mark one monster */
function rpsfStrike(R,e,dmg,tw,i){const T=RP_TW.star;if(!e||e.dead)return false;rpHurt(e,dmg*(e.boss?RPSF.boss:1),T.ap[i],tw);if(e.dead)return true;
 if(!e.boss&&e.hp<=T.exec[i]*e.mx){const p=rpsfAt(R,e);rpKillFoe(e,tw);R.sfFin=(R.sfFin||0)+1;rpText(p.x,p.y-46,'FINISHED!','#fff2b0',18);rpsfSfx('fin');
  try{ptBurst(R.fx,p.x,p.y,R.lite?5:12,['#fff6c8','#ffc83a','#ffffff'],{v:220,s:3.2,g:300})}catch(x){}return true}
 e.mkK=e.mk>0?Math.max(e.mkK||0,T.mark[i]):T.mark[i];e.mk=Math.max(e.mk||0,T.markT[i]);return false}
function rpsfLand(R,s){const T=RP_TW.star,i=Math.max(0,Math.min(4,s.tw.tier-1));let e=s.e;
 if(!e||e.dead){e=null;let bd=60*60;for(const f of R.foes){if(f.dead||f.s<0)continue;const p=rpsfAt(R,f),d=rpD2(p.x,p.y,s.x1,s.y1);if(d<bd){bd=d;e=f}}}
 rpsfStrike(R,e,s.dmg,s.tw,i);
 const big=s.kind==='main';R.sfHits.push({x:s.x1,y:s.y1+(e&&e.air?0:12),t:0,d:big?.6:.42,tier:s.tier,big:big&&s.tier>=4});if(R.sfHits.length>30)R.sfHits.shift();
 R.shake=Math.max(R.shake||0,big?1.8:.8);rpsfSfx('hit');
 try{ptBurst(R.fx,s.x1,s.y1,R.lite?4:10,rpsfBoltC(s.tier),{v:200,s:3,g:260})}catch(x){}
 if(!big)return;
 /* tier 4: the comet splash */
 const cr=T.comet[i];if(cr){for(const f of R.foes){if(f.dead||f.s<0||f===e)continue;const p=rpsfAt(R,f);if(rpD2(p.x,p.y,s.x1,s.y1)<cr*cr)rpsfStrike(R,f,s.dmg*RPSF.cometK,s.tw,i)}rpRing(s.x1,s.y1+12,s.tier>=5?'#fff2b0':'#c08aff',cr*1.1,5)}
 /* tier 3: shards to the toughest monsters nearby */
 const n=T.shards[i];if(n){const near=[];for(const f of R.foes){if(f.dead||f.s<0||f===e)continue;const p=rpsfAt(R,f);if(rpD2(p.x,p.y,s.x1,s.y1)<RPSF.shardR*RPSF.shardR)near.push(f)}
  near.sort((a,b)=>b.mx-a.mx||b.hp-a.hp);for(let k=0;k<Math.min(n,near.length);k++)rpsfLaunch(R,s.tw,near[k],s.dmg*RPSF.shardK,'shard',k*.05,{x:s.x1,y:s.y1})}}
function rpsfStep(R,dt){if(!R.sfStars)return;
 for(const s of R.sfStars){s.t+=dt;if(s.e&&!s.e.dead&&s.t>0){const p=rpsfAt(R,s.e);s.x1=p.x;s.y1=p.y}if(s.t>=s.d&&!s.done){s.done=1;rpsfLand(R,s)}}R.sfStars=R.sfStars.filter(s=>!s.done);
 for(const h of R.sfHits)h.t+=dt;R.sfHits=R.sfHits.filter(h=>h.t<h.d);
 for(const e of R.foes){if(e.mk>0){e.mk-=dt;if(e.mk<=0||e.dead){e.mk=0;e.mkK=0}}}}
/* hooks: fire routine, battle state, step, upgrade */
{const f0=rpFire;rpFire=function(R,tw,dt){if(tw.type==='star')return rpStarFire(R,tw,dt);return f0.apply(this,arguments)}}
{const s0=rpStart;rpStart=function(){const r=s0.apply(this,arguments);if(RPX)Object.assign(RPX,{sfStars:[],sfHits:[],sfCasts:0,sfFin:0});return r}}
{const s0=rpStep;rpStep=function(R,dt){const r=s0.apply(this,arguments);try{rpsfStep(R,dt)}catch(e){console.error(e)}return r}}
{const u0=rpUpgrade;rpUpgrade=function(tw){const r=u0.apply(this,arguments);if(r&&tw&&tw.type==='star'){tw.charge=0;tw.fire=0}return r}}
/* drawing: reticles and mark rings on the ground; stars with dashed trails, impacts and mark badges on top */
const rpsfBez=(s,u)=>{const a=1-u;return{x:a*a*s.x0+2*a*u*s.cx+u*u*s.x1,y:a*a*s.y0+2*a*u*s.cy+u*u*s.y1}};
{const a0=rpAmbient;rpAmbient=function(c,R){const r=a0.apply(this,arguments);try{if(R&&R.sfStars){
 for(const e of R.foes){if(!(e.mk>0)||e.dead)continue;const q=rpPos(R,e);rpStarMarkRing(c,q.x,q.y+2,e.boss?40:22,R.t+e.ph*3,Math.min(1,e.mk*2))}
 for(const s of R.sfStars){if(s.kind==='shard'||s.t<0)continue;const u=Math.max(0,Math.min(1,s.t/s.d)),gy=s.e&&s.e.air?rpPos(R,s.e).y:s.y1+16;rpStarReticle(c,s.x1,gy,s.e&&s.e.boss?46:30,u,Math.min(1,u*3))}}}catch(e){console.error(e)}return r}}
{const b0=rpBeamsDraw;rpBeamsDraw=function(c,R){b0.apply(this,arguments);if(!R.sfStars)return;
 for(const h of R.sfHits)rpStarImpact(c,h.x,h.y,h.t/h.d,h.tier,h.big);
 for(const s of R.sfStars){if(s.t<0)continue;const u=Math.max(0,Math.min(1,s.t/s.d)),p=rpsfBez(s,u),C=rpsfBoltC(s.tier),sm=s.kind==='shard';
  /* the dashed trail: golden dashes along the path just behind the star */
  if(!R.lite||!sm){c.save();c.lineCap='round';const u0=Math.max(0,u-(sm?.5:.42)),n=sm?5:9;for(let k=0;k<n;k++){const a=u0+(u-u0)*k/n,b=u0+(u-u0)*(k+.55)/n,P1=rpsfBez(s,a),P2=rpsfBez(s,b);
    c.globalAlpha=(k+1)/n*.9;c.lineWidth=sm?3:5;c.strokeStyle=RPTO;c.beginPath();c.moveTo(P1.x,P1.y);c.lineTo(P2.x,P2.y);c.stroke();c.lineWidth=sm?1.6:3;c.strokeStyle=C[1];c.stroke()}c.restore()}
  c.save();c.globalCompositeOperation='lighter';rpGlow(c,p.x,p.y,sm?16:38,sm?16:38,C[1],.85);rpGlow(c,p.x,p.y,sm?8:16,sm?8:16,'#ffffff',.7);c.restore();c.globalAlpha=1;
  rpStarBolt(c,p.x,p.y,s.tier,s.t*7+s.seed,sm?.75:s.kind==='shower'?1.3:1.6)}}}
{const f0=rpFoeDraw;rpFoeDraw=function(c,R,e,q){const r=f0.apply(this,arguments);if(e.mk>0&&!e.dead){try{const h=(RPMOB[e.id]?RPMOB[e.id].h:50)+(e.air?44:8);
  rpStarMark(c,q.x+(e.acid>0&&e.melt>0?-22:0),q.y-h-(e.hp<e.mx?16:8),R.t+e.ph,Math.min(1,e.mk*2))}catch(x){}}return r}}
/* while an Observatory is selected: a crosshair on the monster it would pick now */
{const d0=rpDraw;rpDraw=function(){const r=d0.apply(this,arguments);try{const R=RPX;if(!R||!S.rp||!R.sel||R.sel.type!=='star'||R.sel.build<1)return r;const tw=R.sel,e=tw.tg&&!tw.tg.dead?tw.tg:rpsfPick(R,tw,RP_TW.star.dmg[tw.tier-1]);
  if(e){const c=ctx;c.save();c.setTransform(RS,0,0,RS,0,0);const p=rpsfAt(R,e);rpStarReticle(c,p.x,p.y+(e.air?0:16),e.boss?46:30,.5+.5*Math.sin(R.t*3),.8);c.restore()}}catch(e){}return r}}
/* the info panel */
{const i0=rpInfoBuild;rpInfoBuild=function(R,tw,el){const r=i0.apply(this,arguments);if(tw.type!=='star')return r;try{const T=RP_TW.star,i=tw.tier-1,top=RP_MAXT(R.map),nx=tw.tier<top?tw.tier:null;
  const seg=(v,max)=>Math.max(0,Math.min(6,Math.round(v/max*6))),bar=(lab,v,max,nv)=>`<div class="rpst"><span>${lab}</span><i>${[0,1,2,3,4,5].map(k=>`<s class="${k<seg(v,max)?'on':nv!=null&&k<seg(nv,max)?'up':''}"></s>`).join('')}</i></div>`;
  const st=el.querySelector('.rpsts');if(st)st.innerHTML=bar('Star damage',Math.sqrt(T.dmg[i]),Math.sqrt(500),nx!=null?Math.sqrt(T.dmg[nx]):null)+bar('Mark',T.mark[i],.28,nx!=null?T.mark[nx]:null)+bar('Finish',T.exec[i],.15,nx!=null?T.exec[nx]:null)+bar('Fire rate',1/T.cd[i],1/2.8,nx!=null?1/T.cd[nx]:null);
  const ex=[`Range <b>whole map</b>`,`marked: <b>+${Math.round(T.mark[i]*100)}%</b> damage for ${T.markT[i]} s`,`finishes below <b>${Math.round(T.exec[i]*100)}%</b>`,`bosses take <b>double</b>`];
  if(T.shards[i])ex.push(`<b>${T.shards[i]}</b> shards`);if(T.comet[i])ex.push(`comet splash`);if(T.shower[i])ex.push(`meteor shower every <b>${T.shower[i]}</b>`);
  if(st)st.insertAdjacentHTML('afterend',`<div class="rpsfx">${ex.join(' · ')}</div>`);
  {const b=el.querySelector('.rpih b');if(b){b.style.fontSize='23px';b.style.whiteSpace='nowrap'}}
  const hgt=el.offsetHeight||420;el.style.top=rpClamp(tw.y-hgt*.62,76,770-hgt)+'px'}catch(e){console.error(e)}return r}}
/* key U picks it */
{const k0=rpKeyDown;window.removeEventListener('keydown',rpKeyDown,true);rpKeyDown=function(e){const R=RPX;if(R&&S.rp&&S.mode==='ramparts'&&!R.pause&&!R.over&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&e.key.length===1&&e.key.toLowerCase()==='u'){e.preventDefault();e.stopImmediatePropagation();if(!e.repeat)rpPlace('star');return}return k0.apply(this,arguments)};window.addEventListener('keydown',rpKeyDown,true)}
/* ten buttons in the build ring: wider still (the 95v pass already spreads nine by 1.12) */
{const g0=rpHudRing;rpHudRing=function(R,C){const was=C.rg;const r=g0.apply(this,arguments);try{if(C.rg!==was&&C.rg){const bs=[...$('rpring').querySelectorAll('.rprb')],p=R.selPad;if(bs.length>=10){bs.forEach(b=>{for(const v of ['--x','--y']){const n=parseFloat(b.style.getPropertyValue(v));if(isFinite(n))b.style.setProperty(v,(n*1.08).toFixed(1)+'px')}});
   if(p){const xs=bs.map(b=>p.x+(parseFloat(b.style.getPropertyValue('--x'))||0)),lo=Math.min(...xs)-46,hi=Math.max(...xs)+46,dx=lo<0?-lo:hi>1600?1600-hi:0;
    if(dx)bs.forEach(b=>b.style.setProperty('--x',((parseFloat(b.style.getPropertyValue('--x'))||0)+dx).toFixed(1)+'px'))}}}}catch(e){console.error(e)}return r}}
/* ten tiles in the bar */
{const st=document.createElement('style');st.textContent=`.rph.rp7.rp8.rp9.rp10 .rpbar{gap:3px}.rph.rp7.rp8.rp9.rp10 .rpcard{width:82px}.rph.rp7.rp8.rp9.rp10 .rpct>b{max-width:80px;font-size:11.5px}.rph.rp7.rp8.rp9.rp10 .rpcard img{width:66px;height:66px;margin-left:-33px;top:-18px}
.rpsfx{margin:6px 0 2px;font:600 12px Poppins,system-ui,sans-serif;color:#f4e8c8;line-height:1.35}.rpsfx b{color:#ffd45a}`;document.head.appendChild(st)}
{const h0=rpHudOn;rpHudOn=function(){const r=h0.apply(this,arguments);try{const h=$('rphud');if(h&&RP_TWORDER.length>=10)h.classList.add('rp10')}catch(e){}return r}}
try{const h=HELP.Modes.find(x=>x[0]==='Runestone Tower Defense');if(h)h[1]+=" The Starfall Observatory (U, 450 supply) reaches the whole map: it calls falling stars down on the toughest monster, marks it so every tower hits it harder, finishes weakened monsters and hits bosses for double."}catch(e){}
{const h0=rpHowTo;rpHowTo=function(){const r=h0.apply(this,arguments);try{const w=ov.querySelector('#rpmod .rphw');if(w)w.insertAdjacentHTML('beforeend',`<p><b>Starfall Observatory.</b> A support tower (450 supply, key U) that reaches the whole map, ground and air. Its telescope finds the toughest monster and calls a falling star down on it: the star marks it (every tower hits it harder for a few seconds), finishes it if it is left badly hurt, and hits bosses for double. Tier 3 stars burst into shards, tier 4 comets splash and mark a whole group, tier 5 calls a meteor shower every fourth cast.</p>`)}catch(e){}return r}}
/* fix: the base rpTowerWarm (95c) treats any tower it does not know as a Storm Bell and bakes the bell's front and bell sprites with the
   other tower's layout; those sprites are cached by tier and skin only, so warming a Mortar, Still, Tidecaller, Dragon, Prism or
   Observatory before a Storm Bell of the same tier left the Bell drawn wrong for the rest of the session. Sprites of that kind made
   while warming another type are thrown away again. */
{const w0=rpTowerWarm,CL=['ballista','brazier','frost','bell'];rpTowerWarm=function(type,tier,skin){if(CL.includes(type))return w0.apply(this,arguments);
  const had=new Set(RPSPR.keys()),bf=rpBellFront,ba=rpBellArt;rpBellFront=rpBellArt=()=>{};let r;try{r=w0.apply(this,arguments)}finally{rpBellFront=bf;rpBellArt=ba}for(const k of [...RPSPR.keys()])if(!had.has(k)&&(k.startsWith('bf|')||k.startsWith('bl|')))RPSPR.delete(k);return r}}
