/* ===== 99u2: The Great Turkey Trot (10.5), the race model (xorshift32 stream per race, state in st.rs), odds, cash out and settling. Pure functions, no DOM; loads in plain node too. =====
   One deterministic model: fixed 30 Hz steps over 1000 m. The result is fixed by (card, raceSeed). Odds come from Monte Carlo with other seeds.
   Extras beyond the contract: gttOffers(st,bets[,n,salt]) (all bets' offers from ONE set of continuations, cheaper than gttOffer per bet), gttLiveAll, gttMultFor(p,kind),
   gttFork / gttForkInto, gttReseed, gttKFor; the option {fast:true} on gttSimNew / gttRun skips the event log, ranks (pos) and run.x sync (order, times, photo stay exact). */
const GTTM={v0:47,relax:.12,gof:.016,wxslow:{clear:1,wind:1,drizzle:.992},gl:{firm:1.012,good:1,muddy:.972},drz:.35,
 gate:.14,gateLen:80,tilt:.03,fade:.26,fadeMud:1.5,fadeFirm:1.3,xf0:380,xf1:560,kick:.085,kickAt:667,kickRamp:150,
 wn:.016,wnK:.97,wa:.985,df:.012,
 ps0:.006,ps1:.022,pb0:.006,pb1:.022,pp:.020,fo:.9,evMin:50,evMax:970,
 stm:.45,stl:.8,bum:1.25,bul:1.5,pim:.04,pil:.7,gum:.055,gul0:1.6,gul1:2.4,gp:{clear:.010,wind:.09,drizzle:.018}};
const GTT_ROLL=Array.from({length:15},(_,ph)=>{const q=(15-ph)%15;return q%2===0&&q/2<6?q/2:-1});
function gttMix(s){s=(s^0x9E3779B9)|0;s=Math.imul(s^(s>>>16),0x85ebca6b);s=Math.imul(s^(s>>>13),0xc2b2ae35);return(s^(s>>>16))|0}
function gttRng(seed){let s=gttMix(seed|0);return function(){s=(s+0x6D2B79F5)|0;let t=Math.imul(s^(s>>>15),1|s);t=(t+Math.imul(t^(t>>>7),61|t))^t;return((t^(t>>>14))>>>0)/4294967296}}
/* per-runner constants for a card (shared, never mutated by a race): the pace curve along the track is baked into 1 m tables */
function gttKFor(card){
 const M=GTTM,gv=(card.going==='firm'?-1:card.going==='muddy'?1:0)+(card.weather==='drizzle'?M.drz:0),gl=M.gl[card.going]*M.wxslow[card.weather];
 return card.field.map(id=>{const r=GTT_RUN[GTT_IDX[id]];
  const tl=r.style==='front'?M.tilt:r.style==='close'?-M.tilt:0,xf=M.xf0+M.xf1*r.sta,fr=M.fade*(card.going==='muddy'?M.fadeMud:card.going==='firm'?M.fadeFirm:1),
   b=M.v0*r.spd*gl*(1+M.gof*r.mud*gv+(r.wx[card.weather]||0)),ga=(r.gate-.5)*M.gate,kk=r.kick*M.kick,A=new Float64Array(1001),Kt=new Float64Array(1001);
  for(let m=0;m<=1000;m++){let f=b;if(m<M.gateLen)f*=1+ga*(1-m/M.gateLen);f*=1+tl*(1-m*.002);if(m>xf)f*=1-fr*(m-xf)*.001;A[m]=f;
   Kt[m]=m>M.kickAt?kk*(m-M.kickAt>=M.kickRamp?1:(m-M.kickAt)/M.kickRamp):0}
  return{A,Kt,wn:M.wn*1.706*(r.wild*M.wnK+(1-M.wnK)*.5),ps:M.ps0+M.ps1*r.wild,pb:M.pb0+M.pb1*r.wild,pp:M.pp,fo:r.focus*M.fo,gf:M.gum*r.gust,ke:r.kick>=.5}})}
/* (re)start a race on an existing state object: same result as a fresh gttSimNew with that seed */
function gttReseed(st,raceSeed){
 let s=gttMix((raceSeed|0)^0x5bd1e995)||1;const rnd=()=>{s^=s<<13;s^=s>>>17;s^=s<<5;return(s>>>0)*2.3283064365386963e-10};
 const R=st.run,N=R.length;
 for(let i=0;i<N;i++){const r=R[i];st.X[i]=0;st.V[i]=0;st.W[i]=0;st.F[i]=0;st.DF[i]=(rnd()+rnd()-1)*GTTM.df;st.KR[i]=.5+rnd();r.x=0;r.v=0;r.fin=null;r.ev=null;r.ke=null;r.pos=i+1;st.times[i]=null}
 st.t=0;st.n=0;st.ev=[];st.done=false;st.order.length=0;st.photo=false;st.rs=s;st.gust=null;st.pc=false;return st}
function gttSimNew(card,raceSeed,opt){
 opt=opt||{};const N=card.field.length;
 const run=card.field.map((id,lane)=>({lane,id,x:0,v:0,fin:null,ev:null,pos:lane+1,ke:null}));
 const st={card,t:0,n:0,len:GTT.len,run,ev:[],done:false,order:[],times:new Array(N).fill(null),photo:false,rs:0,K:opt.K||gttKFor(card),gust:null,lg:!opt.fast,fast:!!opt.fast,need:N,pc:false,
  X:new Float64Array(N),V:new Float64Array(N),W:new Float64Array(N),F:new Float64Array(N),DF:new Float64Array(N),KR:new Float64Array(N)};
 return gttReseed(st,raceSeed)}
/* advance up to maxSteps fixed steps until `need` runners are home (all the model lives here, so gttStep, gttRun and the odds share it) */
function gttAdv(st,maxSteps,need){
 const M=GTTM,K=st.K,R=st.run,nR=R.length,lg=st.lg,fast=st.fast,dt=1/30,ord=st.order,X=st.X,V=st.V,W=st.W,F=st.F,DF=st.DF,KR=st.KR;
 let s=st.rs|0,n=st.n,steps=0,fc=ord.length;
 const rnd=()=>{s^=s<<13;s^=s>>>17;s^=s<<5;return(s>>>0)*2.3283064365386963e-10};
 const gpr=M.gp[st.card.weather],wa=M.wa*M.wa*M.wa,rl=M.relax,kat=M.kickAt;let fin=null;
 while(steps<maxSteps&&fc<need){
  n++;steps++;const t=n*dt;let g=st.gust;
  if(g&&t>=g.t1){for(let i=0;i<nR;i++)if(R[i].ev===g)R[i].ev=null;st.gust=g=null}
  if(!g&&n%30===0&&t<24&&rnd()<gpr){const d=M.gul0+rnd()*(M.gul1-M.gul0);g=st.gust={k:'gust',t0:t,t1:t+d,m:1};if(lg)st.ev.push({t,lane:-1,k:'gust',t1:t+d});for(let i=0;i<nR;i++)if(!R[i].ev&&F[i]===0)R[i].ev=g}
  const rl_=GTT_ROLL[n%15],wm=n%3;
  for(let i=0;i<nR;i++){
   const r=R[i];let x=X[i],v=V[i];
   if(F[i]===0){
    const k=K[i];let ev=r.ev;
    if(ev!==null&&ev.t1<=t){ev=r.ev=(x>=kat&&r.ke!==null)?r.ke:(g||null)}
    if(i===rl_&&x>M.evMin&&x<M.evMax&&(ev===null||ev.k==='gust'||ev.k==='kick')){
     const u=rnd();let e=null;
     if(u<k.ps)e={k:'stumble',t0:t,t1:t+M.stl,m:M.stm};
     else if(u<k.ps+k.pb)e={k:'burst',t0:t,t1:t+M.bul,m:M.bum};
     else if(u<k.ps+k.pb+k.pp&&rnd()>=k.fo)e={k:'pie',t0:t,t1:t+M.pil,m:M.pim};
     if(e!==null){ev=r.ev=e;if(lg)st.ev.push({t,lane:i,k:e.k,t1:e.t1})}}
    if(k.ke&&x>=kat&&r.ke===null){r.ke={k:'kick',t0:t,t1:99,m:1};if(ev===null||ev.k==='gust'){ev=r.ev=r.ke}if(lg)st.ev.push({t,lane:i,k:'kick',t1:t+6})}
    const xi=x|0;
    let f=k.A[xi]*(1+DF[i]);
    if(x>kat)f*=1+k.Kt[xi]*KR[i];
    let w=W[i];if((i+wm)%3===0){w=w*wa+(rnd()-.5)*k.wn;W[i]=w}f*=1+w;
    if(g!==null)f*=1-k.gf;
    if(ev!==null)f*=ev.m;
    v+=(f-v)*rl;
    const xn=x+v*dt;
    if(xn>=1000){const ft=(n-1)*dt+(1000-x)/(xn-x)*dt;F[i]=ft;st.times[i]=ft;r.ev=null;if(fin===null)fin=[];fin.push(i)}
    X[i]=xn;V[i]=v}
   else{v*=.985;V[i]=v;X[i]=x+v*dt}}
  if(fin!==null){if(fin.length>1)fin.sort((a,b)=>F[a]-F[b]||a-b);for(const i of fin)ord.push(i);fc=ord.length;fin=null;
   if(!st.pc&&fc>=2){st.pc=true;const a=ord[0],b=ord[1],gap=F[b]-F[a];if(gap<GTT.photoGap)st.photo={a,b,gap}}}
  if(!fast){for(let i=0;i<nR;i++){const ka=F[i]!==0?F[i]-1e4:-X[i];let p=1;for(let j=0;j<nR;j++){if(j===i)continue;const kb=F[j]!==0?F[j]-1e4:-X[j];if(kb<ka||(kb===ka&&j<i))p++}R[i].pos=p}}}
 st.rs=s;st.n=n;st.t=n*dt;if(fc>=nR)st.done=true;
 if(!fast)for(let i=0;i<nR;i++){const r=R[i];r.x=X[i];r.v=V[i];r.fin=F[i]!==0?F[i]:null}
 return st}
function gttStep(st){return gttAdv(st,1,st.run.length)}
function gttRun(card,raceSeed,opt){const st=gttSimNew(card,raceSeed,opt);gttAdv(st,4000,st.run.length);return st}
/* copy a state for a continuation: only what the model reads and writes, a fresh stream, no log. gttForkInto reuses a scratch state (no allocation). */
function gttFork(st,seed){
 const N=st.run.length,o={card:st.card,t:0,n:0,len:st.len,run:st.run.map(r=>({lane:r.lane,id:r.id,x:0,v:0,fin:null,ev:null,pos:r.pos,ke:null})),ev:null,done:false,order:[],times:new Array(N).fill(null),photo:false,rs:1,K:st.K,gust:null,lg:false,fast:true,need:st.need,pc:false,
  X:new Float64Array(N),V:new Float64Array(N),W:new Float64Array(N),F:new Float64Array(N),DF:st.DF,KR:st.KR};
 return gttForkInto(o,st,seed)}
function gttForkInto(o,st,seed){
 const R=o.run,S=st.run,N=R.length;
 for(let i=0;i<N;i++){R[i].ev=S[i].ev;R[i].ke=S[i].ke}
 o.X.set(st.X);o.V.set(st.V);o.W.set(st.W);o.F.set(st.F);o.DF=st.DF;o.KR=st.KR;o.K=st.K;
 const so=st.order,oo=o.order;oo.length=0;for(let i=0;i<so.length;i++)oo.push(so[i]);
 for(let i=0;i<N;i++)o.times[i]=st.times[i];
 o.t=st.t;o.n=st.n;o.done=false;o.photo=st.photo;o.pc=st.pc;o.gust=st.gust;o.rs=gttMix(seed)||1;return o}
/* ---- odds ---- */
function gttStepMult(m){m=m<3?Math.floor(m*20+1e-9)/20:m<10?Math.floor(m*10+1e-9)/10:m<25?Math.floor(m*2+1e-9)/2:Math.floor(m+1e-9);return Math.round(m*100)/100}
/* kind: 'win'|'top2'|'top3'|'exact' -> multiplier or null (not offered: p under 0.6%, a sure thing over 90%, or a long shot whose capped multiplier would return under 88%) */
function gttMultFor(p,kind){
 if(!(p>=GTT.minP))return null;let m=GTT.rtp/p;
 if(m<GTT.minMult){if(p>GTT.maxOfferedP)return null;return GTT.minMult}
 m=gttStepMult(m);const mx=kind==='exact'?GTT.maxExact:GTT.maxWin;if(m>mx){if(p*mx<GTT.minRet)return null;m=mx}return m}
function gttPriceCounts(card,n,seedBase,from,to,C,st){
 const N=card.field.length;
 for(let k=from;k<to;k++){
  gttReseed(st,(seedBase+Math.imul(k,0x9E3779B1))|0);gttAdv(st,4000,3);
  const o=st.order;C.win[o[0]]++;C.top2[o[0]]++;C.top2[o[1]]++;C.top3[o[0]]++;C.top3[o[1]]++;C.top3[o[2]]++;C.exact[o[0]*N+o[1]]++}}
function gttPriceFin(card,n,C){
 const N=card.field.length,al=.5,out={n,win:[],top2:[],top3:[],exact:[],mult:{win:[],top2:[],top3:[],exact:[]}};
 for(let i=0;i<N;i++){out.win.push(C.win[i]/n);out.top2.push(C.top2[i]/n);out.top3.push(C.top3[i]/n);
  out.mult.win.push(gttMultFor(C.win[i]/n,'win'));out.mult.top2.push(gttMultFor(C.top2[i]/n,'top2'));out.mult.top3.push(gttMultFor(C.top3[i]/n,'top3'))}
 const cells=N*(N-1);
 for(let i=0;i<N;i++){const pr=[],mr=[];for(let j=0;j<N;j++){const p=i===j?0:(C.exact[i*N+j]+al)/(n+al*cells);pr.push(p);mr.push(i===j?null:gttMultFor(p,'exact'))}out.exact.push(pr);out.mult.exact.push(mr)}
 return out}
function gttPriceBase(card){return gttMix((card.seed|0)^0x1f3d5b79)}
function gttNewC(N){return{win:new Array(N).fill(0),top2:new Array(N).fill(0),top3:new Array(N).fill(0),exact:new Array(N*N).fill(0)}}
function gttPriceSync(card,n){n=n||GTT.priceRuns;const C=gttNewC(card.field.length);gttPriceCounts(card,n,gttPriceBase(card),0,n,C,gttSimNew(card,0,{fast:true}));return gttPriceFin(card,n,C)}
/* chunked over frames/timers; cb(result) at the end; returns a cancel function */
function gttPrice(card,n,cb){
 n=n||GTT.priceRuns;const C=gttNewC(card.field.length),K=gttSimNew(card,0,{fast:true}),base=gttPriceBase(card);let k=0,dead=false;
 const now=()=>typeof performance!=='undefined'&&performance.now?performance.now():Date.now();
 const tick=()=>{if(dead)return;const t0=now();while(k<n&&now()-t0<7){const to=Math.min(n,k+100);gttPriceCounts(card,n,base,k,to,C,K);k=to}
  if(k<n)setTimeout(tick,0);else{const r=gttPriceFin(card,n,C);if(cb)cb(r)}};
 setTimeout(tick,0);return()=>{dead=true}}
/* ---- cash out ---- */
function gttNeed(b){return b.k==='win'?1:b.k==='top3'?3:2}
function gttHit(b,o){const a=o[0];return b.k==='win'?a===b.a:b.k==='top2'?(a===b.a||o[1]===b.a):b.k==='top3'?(a===b.a||o[1]===b.a||o[2]===b.a):(a===b.a&&o[1]===b.b)}
/* P(each bet wins | the race so far) from n short continuations with fresh seeds (never the hidden seed); one set of runs serves every bet */
function gttLiveAll(st,bets,n,salt){
 n=n||GTT.coRuns;const need=Math.max(1,...bets.map(gttNeed)),c=new Array(bets.length).fill(0),sd=0x2c1b3c6d^Math.imul(salt|0,0x85ebca6b);let f=null;
 for(let k=0;k<n;k++){const seed=Math.imul(k+1,0x9E3779B1)^sd;f=f?gttForkInto(f,st,seed):gttFork(st,seed);if(f.order.length<need)gttAdv(f,4000,need);
  for(let i=0;i<bets.length;i++)if(gttHit(bets[i],f.order))c[i]++}
 return c.map(v=>v/n)}
function gttLiveP(st,bet,n,salt){return gttLiveAll(st,[bet],n,salt)[0]}
/* the offer: floor(coRtp * p * stake * mult); 0 in the last 10% of the track (leader past coLast), once done, or when it would be under 1 coin */
function gttCoOpen(st){if(st.done||st.order.length)return false;let m=0;for(const r of st.run)if(r.x>m)m=r.x;return m<GTT.len*GTT.coLast}
function gttOffers(st,bets,n,salt){
 if(!gttCoOpen(st))return bets.map(()=>0);const ps=gttLiveAll(st,bets,n,salt);
 return bets.map((b,i)=>{const o=Math.floor(GTT.coRtp*ps[i]*b.stake*b.mult+1e-9);return o>=1?Math.min(o,GTT.cap):0})}
function gttOffer(st,bet,n,salt){return gttOffers(st,[bet],n,salt)[0]}
/* ---- settle: bets against st.order; the total is capped at GTT.cap (lines are cut in order so they add up to the total) ---- */
function gttSettle(bets,st){
 const o=st.order,lines=[];let tot=0;
 for(const b of bets){const won=o.length>=gttNeed(b)&&gttHit(b,o);let pay=won?Math.floor(b.stake*b.mult+1e-9):0;
  if(tot+pay>GTT.cap)pay=Math.max(0,GTT.cap-tot);tot+=pay;lines.push({bet:b,won,pay})}
 return{lines,total:tot}}
