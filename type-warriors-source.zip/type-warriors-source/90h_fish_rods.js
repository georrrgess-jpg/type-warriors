/* ===== MOONLIT FISHING: rod models (update 3) =====
   Every rod tier has its own hand-drawn storybook model (fsTier() 0-4, from the total upgrade level):
   0 Willow: a hand-cut willow branch - knots, bark, a twig with living leaves, twine wraps, wire guides, a cork grip and a
     tin reel with a wooden knob.
   1 Ashwood: polished ash with grain, red silk wraps, engraved brass ferrules and guides, a stitched leather grip, a brass
     butt cap and a geared brass reel with an ivory crank.
   2 Moonreed: a segmented reed with silver node bands and sheaths, crescent inlays, moon-glow guides, a silk-corded grip, a
     moonstone butt cap, a crescent-moon reel and a dangling crescent charm.
   3 Starwoven: midnight starwood speckled with stars, a glowing constellation inlay, star-shaped guides, a gold-spiral grip
     with a star pommel, an ornate eight-point star reel and a star at the tip.
   4 Tidecaller: coral-and-gold shaft with a gold spiral, pearl inlays, glowing tide runes and coral spurs, a sharkskin grip
     with a pearl cap, a scallop-shell reel and a gold trident at the tip.
   A rod look (FSKIN) sets the rod's material: the tier keeps the FORM (shape, guides, reel, grip, tip ornament) and a look
   from 90h3 (fsRodLook) supplies the shaft/grip/thread/accent colours, guide metal and its own signature details through
   three hooks (back: behind the shaft, inner: clipped inside it, over: on top). The Willow look and any look 90h3 does not
   know keep the old palette: c = [shaft dark, shaft light] mixed into the tier palette, gl tints the glows, tip the tip bead,
   rb adds a rainbow shimmer. Fine detail is only drawn when the rod is big on screen.
   fsRod(g,hx,hy,a,b,len,t,sk,tier,fl) keeps the old signature (hand point, angle, bend 0..1, length) and returns the tip;
   fl (optional, radians) flexes the shaft: the tip swings round the hand while the butt keeps its direction (cast whip).
   The last drawn rod's geometry is kept in FSRODG for the tier effects (90h2). */
const fsTier=lv=>{lv=lv==null?fsLv():lv;return lv>=15?4:lv>=10?3:lv>=6?2:lv>=3?1:0};
const FSTIERN=['Willow Rod','Ashwood Rod','Moonreed Rod','Starwoven Rod','Tidecaller Rod'];
let FSRODG=null;
/* the Starwoven constellation inlay: [u along the shaft, offset across it (-1 top edge .. 1 bottom edge)] */
const FSCONS=[[.25,-.3],[.33,.32],[.41,-.12],[.5,.38],[.58,-.36],[.67,.16],[.76,-.28],[.85,.24]];
/* ---------- shared shape helpers (also used by the rod effects) ---------- */
const fsRh=i=>{const x=Math.sin(i*127.1+311.7)*43758.5453;return x-Math.floor(x)};
function fsMix(a,b,f){const x3=h=>h.length===4?'#'+[...h.slice(1)].map(q=>q+q).join(''):h;a=x3(a);b=x3(b);const A=parseInt(a.slice(1,7),16),B=parseInt(b.slice(1,7),16),m=s=>Math.round(((A>>s)&255)*(1-f)+((B>>s)&255)*f);return '#'+((1<<24)+(m(16)<<16)+(m(8)<<8)+m(0)).toString(16).slice(1)}
function fsStarP(g,x,y,r,ri,n,rot){g.beginPath();for(let i=0;i<n*2;i++){const rr=i%2?ri:r,an=(rot||0)+i*Math.PI/n-Math.PI/2;i?g.lineTo(x+Math.cos(an)*rr,y+Math.sin(an)*rr):g.moveTo(x+Math.cos(an)*rr,y+Math.sin(an)*rr)}g.closePath()}
/* a crescent opening towards +x (rotated by rot); th = how thick (0..1) */
function fsCrescP(g,x,y,R,rot,th){const d=R*(th==null?.5:th),r=R*.92,ix=(d*d+R*R-r*r)/(2*d),iy=Math.sqrt(Math.max(0,R*R-ix*ix)),t1=Math.atan2(iy,ix),p1=Math.atan2(iy,ix-d);
 g.save();g.translate(x,y);g.rotate(rot||0);g.beginPath();g.arc(0,0,R,t1,TAU-t1,false);g.arc(d,0,r,-p1,p1,true);g.closePath();g.restore()}
/* a slender willow leaf from (x,y) pointing along ang */
function fsLeafP(g,x,y,L,ang,wd){const w=L*(wd||.24);g.save();g.translate(x,y);g.rotate(ang);g.beginPath();g.moveTo(0,0);g.bezierCurveTo(L*.3,-w,L*.7,-w*.8,L,0);g.bezierCurveTo(L*.7,w*.8,L*.3,w,0,0);g.closePath();g.restore()}
function fsLeaf(g,x,y,L,ang,c,a){if(a!=null&&a<=0)return;g.save();if(a!=null)g.globalAlpha*=a;c=c||['#3e8a3a','#9ad860'];fsLeafP(g,x,y,L,ang);g.fillStyle=fkLin(g,x,y,x+Math.cos(ang)*L,y+Math.sin(ang)*L,[c[0],c[1]]);g.fill();g.lineWidth=Math.max(.8,L*.09);g.strokeStyle=FKO;g.stroke();
 if(L>5){g.strokeStyle=shade(c[1],.35);g.lineWidth=Math.max(.5,L*.05);g.beginPath();g.moveTo(x+Math.cos(ang)*L*.12,y+Math.sin(ang)*L*.12);g.lineTo(x+Math.cos(ang)*L*.8,y+Math.sin(ang)*L*.8);g.stroke()}g.restore()}
function fsGearP(g,x,y,r,n,rot){const ri=r*.76;g.beginPath();for(let i=0;i<n;i++){const a0=(rot||0)+i*TAU/n,s=TAU/n;
  const P=[[ri,a0],[r,a0+s*.18],[r,a0+s*.5],[ri,a0+s*.68]];P.forEach(([rr,an],k)=>{const px=x+Math.cos(an)*rr,py=y+Math.sin(an)*rr;i||k?g.lineTo(px,py):g.moveTo(px,py)})}g.closePath()}
/* a water droplet pointing along ang (the round end trails) */
function fsDropP(g,x,y,r,ang){g.save();g.translate(x,y);g.rotate(ang);g.beginPath();g.moveTo(r*1.9,0);g.quadraticCurveTo(r*.4,-r*1.05,-r*.2,-r*.95);g.arc(0,0,r,-Math.PI*.6,Math.PI*.6,true);g.quadraticCurveTo(r*.4,r*1.05,r*1.9,0);g.closePath();g.restore()}
function fsRrect(g,x,y,w,h,r){r=Math.min(r,w/2,h/2);g.beginPath();g.moveTo(x+r,y);g.lineTo(x+w-r,y);g.quadraticCurveTo(x+w,y,x+w,y+r);g.lineTo(x+w,y+h-r);g.quadraticCurveTo(x+w,y+h,x+w-r,y+h);g.lineTo(x+r,y+h);g.quadraticCurveTo(x,y+h,x,y+h-r);g.lineTo(x,y+r);g.quadraticCurveTo(x,y,x+r,y);g.closePath()}
/* metal palettes: [highlight, body, shadow] */
const FSMET={tin:['#ffffff','#c4c6d4','#5e6072'],brass:['#fff4c0','#e6b43a','#7a4e0c'],silver:['#ffffff','#d6dcf4','#6e76a8'],gold:['#fff6c8','#f2c444','#8a5a0e'],pale:['#ffffff','#e8e6ff','#8a86b8']};
/* ---------- the rod ---------- */
function fsRod(g,hx,hy,a,b,len,t,sk,tier,fl){sk=sk||fsSkin();tier=tier==null?fsTier():tier;t=t||0;b=b||0;const X=sk!==FSKIN.willow&&typeof fsRodLook==='function'?fsRodLook(sk,tier):null;
 const M=g.getTransform(),PX=len*(Math.hypot(M.a,M.b)||1),LOD=PX<135?0:PX<340?1:2,KW=Math.max(.8,Math.min(1.3,len/190)),K=LOD?KW:Math.max(.55,Math.min(1.3,len/190)),GS=A=>LOD?A:A.filter((_,i)=>i%2);
 const ca=Math.cos(a),sa=Math.sin(a),fa=a+(fl||0)*.85,tx=hx+Math.cos(fa)*len,ty=hy+Math.sin(fa)*len,bx=tx+b*len*.08,by=ty+b*len*.34,fc=a+(fl||0)*.12,cpx=hx+Math.cos(fc)*len*.55+sa*b*len*.12,cpy=hy+Math.sin(fc)*len*.55-ca*b*len*.12+b*len*.12;
 const bx0=hx-ca*len*.2,by0=hy-sa*len*.2;/* butt end */
 const N=LOD?30:20,P=[];for(let i=0;i<=N;i++){const u=i/N;let x,y;if(u<.16){const k=u/.16;x=bx0+(hx-bx0)*k;y=by0+(hy-by0)*k}else{const k=(u-.16)/.84;x=(1-k)*(1-k)*hx+2*k*(1-k)*cpx+k*k*bx;y=(1-k)*(1-k)*hy+2*k*(1-k)*cpy+k*k*by}P.push([x,y])}
 const at=u=>{u=Math.max(0,Math.min(.9999,u));const f=u*N,i=Math.min(N-1,Math.floor(f)),r=f-i,A=P[i],B=P[i+1],dx=B[0]-A[0],dy=B[1]-A[1],d=Math.hypot(dx,dy)||1;return{x:A[0]+dx*r,y:A[1]+dy*r,tx:dx/d,ty:dy/d,nx:-dy/d,ny:dx/d}};
 const W0=[8,8,8.4,10,9.4][tier]*KW,W1=[2.8,2.6,2.9,3.6,3.3][tier]*KW,NODES=[.27,.39,.51,.63,.75,.87];
 const wob=tier===0?u=>1+.1*Math.sin(u*41+1)+.06*Math.sin(u*97):tier===2?u=>{for(let i=0;i<NODES.length;i++){const a0=i?NODES[i-1]:.16,a1=NODES[i];if(u<=a1)return 1+.09*Math.sin(Math.PI*(u-a0)/(a1-a0))}return 1+.07*Math.sin(Math.PI*(u-.87)/.13)}:()=>1;
 const wAt=u=>(u<.16?W0*1.45:W0+(W1-W0)*Math.pow((u-.16)/.84,1.15))*wob(u);
 const pt=(u,o)=>{const p=at(u),w=wAt(u)/2*o;return{x:p.x+p.nx*w,y:p.y+p.ny*w,p}};
 /* draw fn in a local frame at u: +x along the shaft, +y across it (towards the underside); o = offset across (in half widths) */
 const loc=(u,o,fn)=>{const p=at(u),hw=wAt(u)/2,q=o?hw*o:0;g.save();g.translate(p.x+p.nx*q,p.y+p.ny*q);g.rotate(Math.atan2(p.ty,p.tx));fn(hw,p);g.restore()};
 const rail=(o,u0,u1)=>{const n=Math.max(2,Math.ceil((u1-u0)*N*1.5));g.beginPath();for(let i=0;i<=n;i++){const q=pt(u0+(u1-u0)*i/n,typeof o==='function'?o(u0+(u1-u0)*i/n):o);i?g.lineTo(q.x,q.y):g.moveTo(q.x,q.y)}};
 const strip=(o1,o2,u0,u1)=>{const n=Math.max(2,Math.ceil((u1-u0)*N*1.5));g.beginPath();for(let i=0;i<=n;i++){const q=pt(u0+(u1-u0)*i/n,o1);i?g.lineTo(q.x,q.y):g.moveTo(q.x,q.y)}for(let i=n;i>=0;i--){const q=pt(u0+(u1-u0)*i/n,o2);g.lineTo(q.x,q.y)}g.closePath()};
 const L=[],R=[];for(let i=0;i<=N;i++){const u=i/N,p=at(u),w=wAt(u)/2;L.push([p.x+p.nx*w,p.y+p.ny*w]);R.push([p.x-p.nx*w,p.y-p.ny*w])}
 const path=()=>{g.beginPath();g.moveTo(L[0][0],L[0][1]);for(const q of L)g.lineTo(q[0],q[1]);g.arc(P[N][0],P[N][1],wAt(1)/2,Math.atan2(L[N][1]-P[N][1],L[N][0]-P[N][0]),Math.atan2(R[N][1]-P[N][1],R[N][0]-P[N][0]),true);for(let i=R.length-1;i>=0;i--)g.lineTo(R[i][0],R[i][1]);g.closePath()};
 /* palette: the tier's own colours with the look mixed in */
 const TT=[[sk.c[0],sk.c[1]],['#b07a42','#f4dcae'],['#2e3a8a','#aab8ff'],['#2c2470','#7462d4'],['#c23c56','#ffae98']][tier];
 const plain=tier===0||sk===FSKIN.willow,c0=X?X.sh[0]:plain?TT[0]:fsMix(sk.c[0],TT[0],.5),c1=X?X.sh[1]:plain?TT[1]:fsMix(sk.c[1],TT[1],.45);
 const AC=X&&X.ac,TH=X?X.th:null,GM=X&&X.gm?(typeof X.gm==='function'?X.gm:()=>X.gm):null;
 const GL=sk.gl||['#e0ffb0','#ffe2a0','#c8d8ff','#c8b8ff','#7affe0'][tier],RB=i=>`hsl(${(t*80+i*50)%360},90%,72%)`,OL=2.2+.8*KW,ol=Math.max(.9,1.1*K),GK=LOD?1:Math.min(.6,K);
 const metal=(c,x0,y0,x1,y1)=>fkLin(g,x0,y0,x1,y1,[c[0],c[1],c[1],c[2]]);
 /* a band round the shaft (ferrule, wrap, node): w long, sticks out by o */
 const band=(u,w,c,o,eng)=>loc(u,0,hw=>{const h=hw+(o==null?1:o)*K;fsRrect(g,-w/2,-h,w,h*2,Math.min(w*.3,1.6*K));g.fillStyle=Array.isArray(c)?metal(c,0,-h,0,h):c;g.fill();g.lineWidth=ol;g.strokeStyle=FKO;g.stroke();
  if(Array.isArray(c)){g.fillStyle='#ffffff99';g.fillRect(-w/2+.8,-h+.9,w-1.6,Math.max(.8,h*.28))}
  if(eng&&LOD){g.strokeStyle=c[2];g.globalAlpha=.8;g.lineWidth=.6*K;g.beginPath();g.moveTo(-w*.28,-h+1);g.lineTo(-w*.28,h-1);g.moveTo(w*.28,-h+1);g.lineTo(w*.28,h-1);g.stroke();
   if(LOD>1){g.beginPath();for(let k=-2;k<=2;k++){g.moveTo(-w*.14,k*h*.36);g.lineTo(w*.14,k*h*.36+h*.18)}g.stroke()}g.globalAlpha=1}});
 /* a line guide on the top side */
 const guide=(u,kind,glow)=>{const p=at(u),hw=wAt(u)/2,r=(2.4+(1-u)*1.6)*K,gx=p.x-p.nx*(hw+r+.8*K),gy=p.y-p.ny*(hw+r+.8*K),f=at(u);
  if(kind==='star'){const sr=r*1.9,sx=p.x-p.nx*(hw+sr*.42),sy=p.y-p.ny*(hw+sr*.42),rot=Math.atan2(-p.ny,-p.nx)+Math.PI/2+Math.sin(t*.9+u*5)*.12;if(glow)fkGlow(g,sx,sy,r*3.2,glow,.38+.18*Math.sin(t*2.6+u*11));
   fsStarP(g,sx,sy,sr,sr*.5,5,rot);g.arc(sx,sy,r*.62,0,TAU,true);g.fillStyle=metal(GM?GM(u,t):FSMET.gold,sx,sy-sr,sx,sy+sr);g.fill('evenodd');g.lineWidth=ol*.85;g.strokeStyle=FKO;g.stroke();if(LOD)fkSpark(g,sx-sr*.3,sy-sr*.42,sr*.32,'#ffffff',.5+.5*Math.sin(t*3+u*9));return}
  if(glow)fkGlow(g,gx,gy,r*3.2*GK,glow,.38+.18*Math.sin(t*2.6+u*11));
  const fx=gx+f.nx*r*.85,fy=gy+f.ny*r*.85;g.strokeStyle=FKO;g.lineWidth=1.6*K+1.2;g.beginPath();g.moveTo(f.x-f.nx*hw*.7-f.tx*r*.9,f.y-f.ny*hw*.7-f.ty*r*.9);g.lineTo(fx,fy);g.lineTo(f.x-f.nx*hw*.7+f.tx*r*.9,f.y-f.ny*hw*.7+f.ty*r*.9);g.stroke();
  const mc=GM?GM(u,t):kind==='wire'?FSMET.tin:kind==='brass'?FSMET.brass:kind==='silver'?FSMET.silver:FSMET.gold;g.strokeStyle=mc[1];g.lineWidth=1*K;g.stroke();
  g.beginPath();g.arc(gx,gy,r,0,TAU);g.lineWidth=1.4*K+1.4;g.strokeStyle=FKO;g.stroke();g.lineWidth=1.3*K;g.strokeStyle=mc[1];g.stroke();if(LOD){g.beginPath();g.arc(gx,gy,r,Math.PI*1.1,Math.PI*1.6);g.strokeStyle=mc[0];g.lineWidth=.8*K;g.stroke()}};
 const LC=X&&X.lc?X.lc:sk===FSKIN.willow?[['#2e7a34','#8ad05a'],['#3e8a3a','#b2e070']]:[[fsMix('#2e7a34',sk.c[0],.45),fsMix('#8ad05a',sk.tip,.5)],[fsMix('#3e8a3a',sk.c[0],.4),fsMix('#b2e070',sk.tip,.45)]];
 const G={at,wAt,pt,loc,rail,strip,path,N,K,KW,LOD,GK,ol,OL,t,tier,len,sk,X,c0,c1,GL,LC,a,b,hx,hy};
 g.save();g.lineJoin='round';g.lineCap='round';
 /* ===== behind the shaft ===== */
 if(tier===0){/* the twig fork with leaves */const q=pt(.56,-1),an=Math.atan2(at(.56).ty,at(.56).tx)-.75,tl=14*K,ex=q.x+Math.cos(an)*tl,ey=q.y+Math.sin(an)*tl;
  g.strokeStyle=FKO;g.lineWidth=4.2*K;g.beginPath();g.moveTo(q.x,q.y);g.quadraticCurveTo(q.x+Math.cos(an+.3)*tl*.6,q.y+Math.sin(an+.3)*tl*.6,ex,ey);g.stroke();g.strokeStyle=shade(c0,.1);g.lineWidth=2.2*K;g.stroke();
  fsLeaf(g,ex,ey,17*K,an-.55+Math.sin(t*1.7)*.16,LC[0]);fsLeaf(g,ex,ey,15*K,an+.6+Math.sin(t*1.9+1)*.18,LC[1]);fsLeaf(g,ex,ey,12*K,an+.05+Math.sin(t*2.3+2)*.12,LC[0]);
  {const m=pt(.56,-1),mx=m.x+Math.cos(an+.3)*tl*.5,my=m.y+Math.sin(an+.3)*tl*.5;fsLeaf(g,mx,my,11*K,an-1.3+Math.sin(t*1.5+3)*.15,LC[1])}
}
 if(tier===4){/* coral spurs */[[.31,1],[.47,-1],[.63,1],[.79,-1]].forEach(([u,s],i)=>{const q=pt(u,s*.7),p=q.p,base=Math.atan2(p.ty,p.tx),an=base+s*1.0,l=(15-u*6)*K,ex=q.x+Math.cos(an)*l,ey=q.y+Math.sin(an)*l,mx=q.x+Math.cos(an)*l*.5,my=q.y+Math.sin(an)*l*.5,a2=an+s*.9*(i%2?-1:1),e2x=mx+Math.cos(a2-s*.2)*l*.55,e2y=my+Math.sin(a2-s*.2)*l*.55;
  const m3x=q.x+Math.cos(an)*l*.75,m3y=q.y+Math.sin(an)*l*.75,a3=an-s*.8*(i%2?-1:1),e3x=m3x+Math.cos(a3)*l*.35,e3y=m3y+Math.sin(a3)*l*.35;g.strokeStyle=FKO;g.lineWidth=5*K;g.beginPath();g.moveTo(q.x,q.y);g.lineTo(ex,ey);g.moveTo(mx,my);g.lineTo(e2x,e2y);g.moveTo(m3x,m3y);g.lineTo(e3x,e3y);g.stroke();g.strokeStyle=AC?AC[1]:'#e8505e';g.lineWidth=3*K;g.stroke();g.strokeStyle=AC?AC[0]:'#ff9aa0';g.lineWidth=1.2*K;g.stroke();g.fillStyle=AC?fsMix(AC[0],'#ffffff',.5):'#ffd8d0';[[ex,ey],[e2x,e2y],[e3x,e3y]].forEach(([x,y])=>{g.beginPath();g.arc(x,y,1.5*K,0,TAU);g.fill();g.lineWidth=.6*K;g.strokeStyle=FKO;g.stroke()})})}
 if(X&&X.back)X.back(g,G);
 /* ===== the shaft ===== */
 path();g.lineWidth=OL;g.strokeStyle=FKO;g.stroke();
 const gr=g.createLinearGradient(bx0,by0,bx,by);gr.addColorStop(0,shade(c0,-.2));gr.addColorStop(.42,c0);gr.addColorStop(1,tier===3?shade(c1,-.1):c1);g.fillStyle=gr;g.fill();
 g.save();path();g.clip();
 if(tier===0&&LOD){/* bark streaks */g.strokeStyle=shade(c0,-.45);g.lineWidth=.8*K;g.globalAlpha=.7;for(let i=0;i<(LOD>1?16:9);i++){const u0=.18+fsRh(i)*.72,l=.04+fsRh(i+20)*.08,o=(fsRh(i+40)-.5)*1.3;rail(u=>o+.12*Math.sin(u*60+i),u0,Math.min(.97,u0+l));g.stroke()}g.globalAlpha=1}
 if(tier===1&&LOD){/* ash grain */g.strokeStyle=shade(c0,-.3);g.lineWidth=.7*K;g.globalAlpha=.5;[-.55,-.1,.35,.7].forEach((o,j)=>{rail(u=>o+.16*Math.sin(u*(26+j*7)+j*2),.17,.99);g.stroke()});if(LOD>1){for(let i=0;i<5;i++){const u=.25+i*.15;loc(u,(fsRh(i)-.5)*.6,hw=>{g.beginPath();g.ellipse(0,0,6*K,hw*.32,0,0,TAU);g.stroke()})}}g.globalAlpha=1}
 if(tier===2&&LOD){/* reed fibres */g.strokeStyle=shade(c1,.3);g.lineWidth=.6*K;g.globalAlpha=.35;[-.4,.1,.5].forEach(o=>{rail(o,.17,.99);g.stroke()});g.globalAlpha=1}
 if(tier===3){/* star speckles inside the starwood */for(let i=0;i<(LOD?(LOD>1?26:16):8);i++){const q=pt(.18+fsRh(i+5)*.8,(fsRh(i+9)-.5)*1.4),tw=.4+.6*Math.abs(Math.sin(t*1.8+i*1.7));g.fillStyle=i%3?(AC?AC[0]:'#c8c0ff'):'#fff6dc';g.globalAlpha=tw*.8;g.beginPath();g.arc(q.x,q.y,(.45+fsRh(i)*.5)*K,0,TAU);g.fill()}g.globalAlpha=1}
 if(tier===4){/* the gold spiral */g.strokeStyle='#ffd45a';g.lineWidth=(LOD?1.1:.9)*K;rail(u=>Math.sin(u*70)*.95,.18,.97);g.globalAlpha=.9;g.stroke();if(LOD){g.strokeStyle='#8a5a10';g.lineWidth=.5*K;g.globalAlpha=.6;rail(u=>Math.sin(u*70)*.95+.18,.18,.97);g.stroke()}g.globalAlpha=1;
  if(LOD>1){g.fillStyle='#ffe0d8';for(let i=0;i<18;i++){const q=pt(.2+fsRh(i+3)*.76,(fsRh(i+7)-.5)*1.3);g.globalAlpha=.45;g.beginPath();g.arc(q.x,q.y,.5*K,0,TAU);g.fill()}g.globalAlpha=1}}
 /* roundness: shadow underneath, highlight on top */
 strip(.15,1.1,.1,1);g.fillStyle=shade(c0,-.6);g.globalAlpha=tier===3?.32:.3;g.fill();
 strip(-.78,-.42,.17,.995);g.fillStyle=sk.rb?RB(0):shade(c1,.55);g.globalAlpha=tier===3?.45:.7;g.fill();g.globalAlpha=1;
 if(tier===3){/* a cool rim light along the top edge keeps the dark starwood readable on night skies */rail(-.86,.17,.995);g.strokeStyle=fsMix(c1,'#c8d4ff',.6);g.lineWidth=Math.max(1,.9*K);g.globalAlpha=.9;g.stroke();g.globalAlpha=1}
 if(X&&X.inner)X.inner(g,G);
 g.restore();
 /* ===== per-tier decoration ===== */
 if(tier===0){
  [.34,.78].forEach((u,i)=>loc(u,i?-.15:.25,hw=>{g.fillStyle=shade(c0,-.35);g.beginPath();g.ellipse(0,0,3.2*K,hw*.62,0,0,TAU);g.fill();g.lineWidth=.9*K;g.strokeStyle=FKO;g.stroke();g.fillStyle=shade(c0,-.6);g.beginPath();g.ellipse(.4*K,0,1.2*K,hw*.26,0,0,TAU);g.fill();if(LOD){g.strokeStyle=shade(c1,.25);g.lineWidth=.6*K;g.beginPath();g.ellipse(0,0,4.4*K,hw*.8,0,Math.PI*1.1,Math.PI*1.7);g.stroke()}}));
  loc(.56,-.2,hw=>{g.fillStyle=shade(c0,-.3);g.beginPath();g.ellipse(0,0,2.6*K,hw*.5,0,0,TAU);g.fill()});
  const tw=(u,w)=>loc(u,0,hw=>{const h=hw+.7*K;fsRrect(g,-w/2,-h,w,h*2,1*K);g.fillStyle=TH||'#dcc48c';g.fill();g.lineWidth=ol;g.strokeStyle=FKO;g.stroke();if(LOD){g.strokeStyle=TH?shade(TH,-.35):'#9a7a44';g.lineWidth=.6*K;g.beginPath();for(let k=-w/2+1.2*K;k<w/2;k+=1.4*K){g.moveTo(k-.8*K,-h+.6);g.lineTo(k+.8*K,h-.6)}g.stroke()}});
  [.22,.45,.68].forEach(u=>tw(u,4*K));tw(.9,2.8*K);
  GS([.37,.6,.81,.95]).forEach(u=>guide(u,'wire'));
  /* a leaf hanging from the lower knot */
  {const q=pt(.42,1);fsLeaf(g,q.x,q.y,14*K,1.25+Math.sin(t*1.5+2)*.2,LC[1]);fsLeaf(g,q.x,q.y,11*K,.55+Math.sin(t*1.8+1)*.2,LC[0])}
  {const q=pt(.79,.9);fsLeaf(g,q.x,q.y,12*K,.9+Math.sin(t*2.1+4)*.22,LC[0])}}
 if(tier===1){
  [.3,.55,.78].forEach(u=>{if(LOD){band(u-.026,1.8*K,TH||'#a8302e',.35);band(u+.026,1.8*K,TH||'#a8302e',.35)}band(u,5.4*K,FSMET.brass,1.3,1)});
  GS([.37,.58,.77,.9,.97]).forEach(u=>{if(LOD)band(u,2.2*K,TH||'#a8302e',.3);guide(u,'brass')});
  if(LOD)loc(.255,-.05,hw=>{const rx=6.2*K,ry=hw*1.25;g.beginPath();g.ellipse(0,0,rx,ry,0,0,TAU);g.fillStyle=metal(FSMET.brass,0,-ry,0,ry);g.fill();g.lineWidth=ol;g.strokeStyle=FKO;g.stroke();g.beginPath();g.ellipse(0,0,rx*.76,ry*.7,0,0,TAU);g.strokeStyle='#8a5a10';g.lineWidth=.6*K;g.stroke();
   g.fillStyle='#8a5a10';g.beginPath();g.ellipse(-.6*K,0,2.4*K,ry*.3,0,0,TAU);g.moveTo(1.4*K,0);g.lineTo(3.2*K,-ry*.32);g.lineTo(3.2*K,ry*.32);g.closePath();g.fill();g.fillStyle='#fff4c0';g.beginPath();g.arc(-1.6*K,-ry*.06,.45*K,0,TAU);g.fill()})}
 if(tier===2){
  if(LOD)NODES.forEach((u,i)=>loc(u,.2,hw=>{g.beginPath();g.moveTo(1.4*K,-hw*.2);g.quadraticCurveTo(5*K,hw*.9,10*K*(1.1-u*.5),hw*1.05);g.quadraticCurveTo(4*K,hw*1.2,1.4*K,hw*.95);g.closePath();g.fillStyle=shade(c1,.25);g.fill();g.lineWidth=.8*K;g.strokeStyle=FKO;g.stroke()}));
  NODES.forEach(u=>band(u,3.4*K,FSMET.silver,1.5));
  if(LOD)[.45,.69].forEach(u=>loc(u,-.05,hw=>{fsCrescP(g,0,0,hw*.62,-Math.PI/2,.5);g.fillStyle='#f4f6ff';g.fill();g.lineWidth=.5*K;g.strokeStyle=FKO;g.stroke()}));
  GS([.44,.68,.88,.96]).forEach(u=>guide(u,'silver',GL))}
 if(tier===3){
  const CP=FSCONS.map(([u,o])=>pt(u,o));g.strokeStyle=sk.rb?RB(2):fsMix(GL,'#ffffff',.5);g.lineWidth=.9*K;g.globalAlpha=.75;g.beginPath();CP.forEach((q,i)=>i?g.lineTo(q.x,q.y):g.moveTo(q.x,q.y));g.stroke();g.globalAlpha=1;
  CP.forEach((q,i)=>{const tw=.5+.5*Math.sin(t*2.4+i*1.3);if(LOD)fkGlow(g,q.x,q.y,6*K,GL,.35+.2*tw);fkSpark(g,q.x,q.y,(2.2+1.4*tw)*K*(i%3===1?1.25:1),sk.rb?RB(i):'#fff6dc',.95)});
  band(.2,3.6*K,FSMET.gold,1.2,1);[.46,.71].forEach(u=>band(u,2*K,FSMET.pale,.6));
  GS([.4,.62,.82,.93]).forEach(u=>guide(u,'star',GL))}
 if(tier===4){
  [.22,.5,.78].forEach(u=>{band(u,5.6*K,FSMET.gold,1.6,1);if(LOD)loc(u,0,hw=>{g.beginPath();g.arc(0,0,1.6*K,0,TAU);g.fillStyle=fkRad(g,0,0,1.6*K,['#ffffff','#ffe4ee','#b88aa8']);g.fill();g.lineWidth=.6*K;g.strokeStyle=FKO;g.stroke()})});
  [.36,.64,.88].forEach(u=>loc(u,0,hw=>{const r=Math.max(1.2*K,hw*.55);g.beginPath();g.arc(0,0,r,0,TAU);g.fillStyle=fkRad(g,0,0,r,['#ffffff','#ffe8f2','#c49ab4']);g.fill();g.lineWidth=.7*K;g.strokeStyle=FKO;g.stroke()}));
  [.29,.42,.57,.71,.83].forEach((u,i)=>loc(u,0,hw=>{const a2=.45+.55*Math.max(0,Math.sin(t*2.6-i*.9)),s=hw*.7;if(LOD)fkGlow(g,0,0,7*K,GL,.3*a2);g.strokeStyle=sk.rb?RB(i):fsMix(GL,'#ffffff',.3);g.globalAlpha=.55+.45*a2;g.lineWidth=1.1*K;g.beginPath();g.moveTo(-4*K,s*.3);g.bezierCurveTo(-2*K,-s,0,-s,0,0);g.bezierCurveTo(0,s,2*K,s,4*K,-s*.3);g.stroke();g.globalAlpha=1}));
  GS([.39,.6,.8,.93]).forEach(u=>guide(u,'gold',GL))}
 if(sk.rb&&tier<3&&!X){for(let i=0;i<7;i++){const q=pt(.26+i*.1,-.1);g.fillStyle=RB(i);g.beginPath();g.arc(q.x,q.y,1.5*K,0,TAU);g.fill()}}
 /* ===== the grip ===== */
 {const u0=.015,u1=.168,p0=at(u0),p1=at(u1),gw=W0*1.45,gc=X?X.gc:[['#dcae70','#a8743c'],['#6a3a1e','#3a1e0e'],['#30306e','#1c1c4a'],['#26163e','#120a24'],['#227482','#103a46']][tier];
  g.strokeStyle=FKO;g.lineWidth=gw+OL*2;g.beginPath();g.moveTo(p0.x,p0.y);g.lineTo(p1.x,p1.y);g.stroke();
  const gg=g.createLinearGradient(p0.x-p0.nx*gw/2,p0.y-p0.ny*gw/2,p0.x+p0.nx*gw/2,p0.y+p0.ny*gw/2);gg.addColorStop(0,shade(gc[0],.25));gg.addColorStop(.45,gc[0]);gg.addColorStop(1,gc[1]);g.strokeStyle=gg;g.lineWidth=gw;g.stroke();
  const gu=k=>u0+(u1-u0)*k;
  if(tier===0&&LOD){g.fillStyle=X?shade(X.gc[1],-.3):'#8a5a2e';for(let i=0;i<(LOD>1?18:10);i++){const q=pt(gu(fsRh(i+50)),(fsRh(i+60)-.5)*1.3);g.globalAlpha=.55;g.beginPath();g.arc(q.x,q.y,(.5+fsRh(i)*.6)*K,0,TAU);g.fill()}g.globalAlpha=1}
  if(tier===1){if(LOD){g.strokeStyle='#e8c89a';g.lineWidth=.7*K;rail(0,gu(.05),gu(.95));g.setLineDash([1.6*K,1.6*K]);g.stroke();g.setLineDash([]);g.strokeStyle='#2a1408';g.lineWidth=.7*K;for(let k=0;k<9;k++){loc(gu((k+.5)/9),0,hw=>{g.beginPath();g.moveTo(-1.4*K,-hw*.55);g.lineTo(1.4*K,hw*.55);g.stroke()})}}}
  if(tier===2&&LOD){g.strokeStyle='#c8d0ff';g.lineWidth=.7*K;g.globalAlpha=.75;for(let k=0;k<7;k++)loc(gu((k+.5)/7),0,hw=>{const h=hw*.95;g.beginPath();g.moveTo(-2.2*K,0);g.lineTo(0,-h);g.lineTo(2.2*K,0);g.lineTo(0,h);g.closePath();g.stroke()});g.globalAlpha=1}
  if(tier===3){g.strokeStyle='#f2c444';g.lineWidth=(LOD?1:.8)*K;for(let k=0;k<6;k++)loc(gu((k+.5)/6),0,hw=>{g.beginPath();g.moveTo(-2.4*K,hw*.95);g.lineTo(2.4*K,-hw*.95);g.stroke()})}
  if(tier===4&&LOD){g.strokeStyle=AC?AC[0]:'#6ad8d8';g.lineWidth=.6*K;g.globalAlpha=.6;for(let k=0;k<8;k++)for(let j=-1;j<=1;j++)loc(gu((k+.5)/8),j*.55,hw=>{g.beginPath();g.arc(0,0,1.5*K,-Math.PI*.9,-Math.PI*.1);g.stroke()});g.globalAlpha=1}
  g.strokeStyle='#ffffff';g.globalAlpha=.22;g.lineWidth=Math.max(1,gw*.18);g.beginPath();const h0=pt(gu(.08),-.55),h1=pt(gu(.92),-.55);g.moveTo(h0.x,h0.y);g.lineTo(h1.x,h1.y);g.stroke();g.globalAlpha=1;
  /* winding checks and butt caps */
  if(tier===0)loc(u1,0,hw=>{const h=hw+.6*K;fsRrect(g,-1.8*K,-h,3.6*K,h*2,1*K);g.fillStyle=TH||'#dcc48c';g.fill();g.lineWidth=ol;g.strokeStyle=FKO;g.stroke()});
  if(tier===1){band(u1+.005,3.2*K,FSMET.brass,1.2,1);loc(.004,0,hw=>{const r=gw/2+1.2*K;g.beginPath();g.ellipse(0,0,r*.75,r,0,0,TAU);g.fillStyle=metal(FSMET.brass,0,-r,0,r);g.fill();g.lineWidth=ol;g.strokeStyle=FKO;g.stroke();g.beginPath();g.ellipse(-r*.25,0,r*.3,r*.62,0,0,TAU);g.strokeStyle='#8a5a10';g.lineWidth=.7*K;g.stroke()})}
  if(tier===2){band(u1+.005,3*K,FSMET.silver,1.1);const q=at(.004),r=gw/2+1.2*K;fkGlow(g,q.x,q.y,r*3.4*GK,GL,.45+.15*Math.sin(t*2));g.beginPath();g.arc(q.x,q.y,r,0,TAU);g.fillStyle=metal(FSMET.silver,q.x,q.y-r,q.x,q.y+r);g.fill();g.lineWidth=ol;g.strokeStyle=FKO;g.stroke();
   g.beginPath();g.arc(q.x,q.y,r*.68,0,TAU);g.fillStyle=fkRad(g,q.x,q.y,r*.68,['#ffffff','#dce6ff','#8a98e0']);g.fill();g.lineWidth=.7*K;g.stroke();g.fillStyle='#ffffffcc';g.beginPath();g.arc(q.x-r*.25,q.y-r*.25,r*.18,0,TAU);g.fill()}
  if(tier===3){band(u1+.005,3.4*K,FSMET.gold,1.2,1);const q=at(.004),r=gw/2+3*K;fkGlow(g,q.x,q.y,r*2.2,GL,.4);fsStarP(g,q.x,q.y,r,r*.45,5,-a+Math.sin(t*.8)*.15);g.fillStyle=metal(FSMET.gold,q.x,q.y-r,q.x,q.y+r);g.fill();g.lineWidth=ol;g.strokeStyle=FKO;g.stroke()}
  if(tier===4){band(u1+.005,3.6*K,FSMET.gold,1.3,1);band(gu(.45),2.4*K,FSMET.gold,.7);const q=at(.004),r=gw/2+1.6*K;g.beginPath();g.arc(q.x,q.y,r,0,TAU);g.fillStyle=metal(FSMET.gold,q.x,q.y-r,q.x,q.y+r);g.fill();g.lineWidth=ol;g.strokeStyle=FKO;g.stroke();
   g.beginPath();g.arc(q.x,q.y,r*.62,0,TAU);g.fillStyle=fkRad(g,q.x,q.y,r*.62,['#ffffff','#ffe8f2','#c49ab4']);g.fill();g.lineWidth=.7*K;g.stroke()}}
 /* ===== the reel, just above the hand ===== */
 let reel;{const p=at(.195),R0=[7.6,8.6,9.4,9.8,10.4][tier]*K,off=wAt(.195)/2+R0*.72,rx=p.x-p.nx*off,ry=p.y-p.ny*off,ra=Math.atan2(p.ty,p.tx),spin=b>.2?t*16:0;reel={x:rx,y:ry,r:R0};
  g.strokeStyle=FKO;g.lineWidth=3.4*K;g.beginPath();g.moveTo(p.x,p.y);g.lineTo(rx,ry);g.stroke();g.strokeStyle=tier===0?FSMET.tin[1]:tier===2?FSMET.silver[1]:FSMET.gold[1];g.lineWidth=1.4*K;g.stroke();
  g.save();g.translate(rx,ry);
  const crank=(col,knob)=>{g.save();g.rotate(spin+ra+.6);g.strokeStyle=FKO;g.lineWidth=2.8*K;g.beginPath();g.moveTo(0,0);g.lineTo(R0+2.4*K,0);g.stroke();g.strokeStyle=col;g.lineWidth=1.3*K;g.stroke();const kr=2.3*K;g.beginPath();g.ellipse(R0+3*K,0,kr*1.2,kr,0,0,TAU);g.fillStyle=fkRad(g,R0+3*K,0,kr*1.2,knob);g.fill();g.lineWidth=ol;g.strokeStyle=FKO;g.stroke();g.restore()};
  const disc=(r,cols)=>{g.beginPath();g.arc(0,0,r,0,TAU);g.fillStyle=fkRad(g,0,0,r,cols);g.fill();g.lineWidth=ol+.3;g.strokeStyle=FKO;g.stroke()};
  if(tier===0){disc(R0,['#ffffff','#c4c6d4','#5e6072']);g.beginPath();g.arc(0,0,R0*.66,0,TAU);g.strokeStyle='#7a7c8e';g.lineWidth=.9*K;g.stroke();if(LOD){g.fillStyle='#4a4c5c';for(let k=0;k<3;k++){const an=spin+k*TAU/3;g.beginPath();g.arc(Math.cos(an)*R0*.82,Math.sin(an)*R0*.82,.8*K,0,TAU);g.fill()}}
   g.beginPath();g.arc(0,0,R0*.3,0,TAU);g.fillStyle=sk.ln;g.fill();g.lineWidth=.8*K;g.strokeStyle=FKO;g.stroke();crank('#c4c6d4',['#e0a868','#9a6232','#5a3418'])}
  if(tier===1){g.save();g.rotate(spin*.5);fsGearP(g,0,0,R0+1.8*K,LOD?16:10,0);g.fillStyle=FSMET.brass[2];g.fill();g.lineWidth=ol;g.strokeStyle=FKO;g.stroke();g.restore();disc(R0,['#fff4c0','#e6b43a','#8a5a10']);
   g.save();g.rotate(spin);g.strokeStyle='#7a4e0c';g.lineWidth=1*K;for(let k=0;k<4;k++){g.rotate(TAU/4);g.beginPath();g.moveTo(R0*.25,0);g.lineTo(R0*.78,0);g.stroke()}g.restore();g.beginPath();g.arc(0,0,R0*.82,0,TAU);g.strokeStyle='#8a5a10';g.lineWidth=.7*K;g.stroke();
   g.beginPath();g.arc(0,0,R0*.26,0,TAU);g.fillStyle='#fff4c0';g.fill();g.lineWidth=.8*K;g.strokeStyle=FKO;g.stroke();crank('#e6b43a',['#fffaf0','#efe2c4','#a89070'])}
  if(tier===2){fkGlow(g,0,0,R0*1.9*GK,GL,.3+.1*Math.sin(t*2));fsCrescP(g,0,0,R0,ra-Math.PI*.75,.52);g.fillStyle=fkRad(g,0,0,R0,['#ffffff','#dfe4ff','#7e86c0']);g.fill();g.lineWidth=ol+.3;g.strokeStyle=FKO;g.stroke();
   if(LOD){fsCrescP(g,0,0,R0*.78,ra-Math.PI*.75,.5);g.strokeStyle='#9aa2d8';g.lineWidth=.6*K;g.stroke()}const sx=Math.cos(ra-Math.PI*.75)*R0*.42,sy=Math.sin(ra-Math.PI*.75)*R0*.42;fkSpark(g,sx,sy,3.2*K*(.85+.15*Math.sin(t*3)),'#fff6dc',1);
   g.beginPath();g.arc(0,0,R0*.2,0,TAU);g.fillStyle='#e8ecff';g.fill();g.lineWidth=.8*K;g.strokeStyle=FKO;g.stroke();crank('#d6dcf4',['#ffffff','#d6dcf4','#6e76a8'])}
  if(tier===3){fkGlow(g,0,0,R0*2.1,GL,.32);fsStarP(g,0,0,R0+3.2*K,R0*.92,8,spin*.3+t*.2);g.fillStyle=metal(FSMET.gold,0,-R0,0,R0);g.fill();g.lineWidth=ol;g.strokeStyle=FKO;g.stroke();disc(R0*.86,AC?[AC[0],AC[1],AC[2]]:['#8a7aff','#2e2278','#120a32']);
   if(LOD){g.beginPath();g.arc(0,0,R0*.66,0,TAU);g.strokeStyle='#f2c44488';g.lineWidth=.7*K;g.stroke();for(let k=0;k<3;k++){const an=t*.6+k*TAU/3;fkSpark(g,Math.cos(an)*R0*.55,Math.sin(an)*R0*.55,1.4*K,'#fff6dc',.9)}}
   fkGlow(g,0,0,R0*.7,GL,.6);fkSpark(g,0,0,R0*.5*(.9+.1*Math.sin(t*3)),'#ffffff',1);crank('#f2c444',['#fff6c8','#f2c444','#8a5a0e'])}
  if(tier===4){g.save();g.rotate(ra-Math.PI/2);const sr=R0*1.12;g.beginPath();g.moveTo(0,sr*.42);for(let k=0;k<=10;k++){const an=Math.PI*1.08+k/10*Math.PI*.84,an2=an+Math.PI*.042,rr=sr*(k%1?1:1);g.lineTo(Math.cos(an)*rr,Math.sin(an)*rr+sr*.2);if(k<10)g.quadraticCurveTo(Math.cos(an2)*rr*1.12,Math.sin(an2)*rr*1.12+sr*.2,Math.cos(an+Math.PI*.084)*rr,Math.sin(an+Math.PI*.084)*rr+sr*.2)}g.closePath();
   g.fillStyle=fkRad(g,0,0,sr,AC?[fsMix(AC[0],'#ffffff',.6),AC[0],AC[1]]:['#fff6ee','#ffb8c4','#c4587a']);g.fill();g.lineWidth=ol+.3;g.strokeStyle=FKO;g.stroke();
   g.strokeStyle=AC?AC[1]:'#c4587a';g.lineWidth=.8*K;g.beginPath();for(let k=1;k<10;k++){const an=Math.PI*1.08+k/10*Math.PI*.84;g.moveTo(0,sr*.38);g.lineTo(Math.cos(an)*sr*.92,Math.sin(an)*sr*.92+sr*.2)}g.stroke();
   g.beginPath();g.moveTo(-sr*.42,sr*.3);g.lineTo(sr*.42,sr*.3);g.lineTo(sr*.24,sr*.56);g.lineTo(-sr*.24,sr*.56);g.closePath();g.fillStyle=metal(FSMET.gold,0,sr*.3,0,sr*.56);g.fill();g.lineWidth=ol;g.strokeStyle=FKO;g.stroke();g.restore();
   g.beginPath();g.arc(0,0,R0*.28,0,TAU);g.fillStyle=fkRad(g,0,0,R0*.28,['#ffffff','#ffe8f2','#c49ab4']);g.fill();g.lineWidth=.8*K;g.strokeStyle=FKO;g.stroke();crank('#f2c444',['#ffffff','#ffe8f2','#c49ab4'])}
  g.restore()}
 /* ===== tip ornaments ===== */
 const tp=at(.9999),ta=Math.atan2(tp.ty,tp.tx);
 if(tier===0){band(.985,2.4*K,'#dcc48c',.5)}
 if(tier===1){band(.988,2.6*K,FSMET.brass,.6)}
 if(tier===2){/* the dangling crescent charm */const q=pt(.9,1),sw=Math.sin(t*2.2)*.3+Math.sin(t*3.7)*.08,cl=13*K,ex=q.x+Math.sin(sw)*cl,ey=q.y+Math.cos(sw)*cl;
  g.strokeStyle=FKO;g.lineWidth=1.8*K;g.beginPath();g.moveTo(q.x,q.y);g.lineTo(ex,ey);g.stroke();g.strokeStyle='#e8ecff';g.lineWidth=.8*K;g.setLineDash([1.4*K,1*K]);g.stroke();g.setLineDash([]);
  const cr=7.6*K,cx=ex+Math.sin(sw)*cr*.9,cy=ey+Math.cos(sw)*cr*.9;fkGlow(g,cx,cy,cr*2.6*GK,'#fff4d0',.38+.12*Math.sin(t*2.6));fsCrescP(g,cx,cy,cr,-Math.PI*.5-sw+Math.PI,.48);g.fillStyle=fkRad(g,cx,cy,cr,['#ffffff','#fff2c8','#e0b860']);g.fill();g.lineWidth=ol;g.strokeStyle=FKO;g.stroke();
  band(.986,2.4*K,FSMET.silver,.6)}
 if(tier===3){const r=6.4*K,sx=tp.x+tp.tx*r*.55,sy=tp.y+tp.ty*r*.55;fkGlow(g,sx,sy,r*4,GL,.45+.15*Math.sin(t*2.4));fsStarP(g,sx,sy,r,r*.46,5,ta+Math.PI/2+Math.sin(t*1.3)*.12);g.fillStyle=metal(FSMET.gold,sx,sy-r,sx,sy+r);g.fill();g.lineWidth=ol;g.strokeStyle=FKO;g.stroke();fkSpark(g,sx,sy,r*.5,'#ffffff',.9)}
 if(tier===4){/* the gold trident */g.save();g.translate(tp.x,tp.y);g.rotate(ta);const s=K;
  const prongs=()=>{g.beginPath();g.moveTo(-5*s,0);g.lineTo(13*s,0);g.moveTo(-4*s,0);g.bezierCurveTo(-1*s,-1*s,-1*s,-7*s,2*s,-7*s);g.lineTo(9*s,-7*s);g.moveTo(-4*s,0);g.bezierCurveTo(-1*s,1*s,-1*s,7*s,2*s,7*s);g.lineTo(9*s,7*s)};
  const barbs=()=>{g.beginPath();[[13,0],[9,-7],[9,7]].forEach(([x,y])=>{g.moveTo((x+4)*s,y*s);g.lineTo((x-1)*s,(y-2.6)*s);g.lineTo((x+.4)*s,y*s);g.lineTo((x-1)*s,(y+2.6)*s);g.closePath()})};
  fkGlow(g,6*s,0,22*s,GL,.35+.15*Math.sin(t*2.2));prongs();g.strokeStyle=FKO;g.lineWidth=4.6*s;g.stroke();barbs();g.lineWidth=2.2*s;g.stroke();g.fillStyle=FKO;g.fill();
  prongs();g.strokeStyle=metal(FSMET.gold,0,-7*s,0,7*s);g.lineWidth=2.4*s;g.stroke();barbs();g.fillStyle=metal(FSMET.gold,0,-7*s,0,7*s);g.fill();
  if(LOD){prongs();g.strokeStyle='#fff6c8';g.lineWidth=.7*s;g.stroke()}
  fsRrect(g,-7*s,-3.4*s,5*s,6.8*s,1.4*s);g.fillStyle=metal(FSMET.gold,0,-3.4*s,0,3.4*s);g.fill();g.lineWidth=ol;g.strokeStyle=FKO;g.stroke();
  g.beginPath();g.arc(-4.5*s,0,2*s,0,TAU);g.fillStyle=fkRad(g,-4.5*s,0,2*s,['#ffffff',GL,shade(GL,-.4)]);g.fill();g.lineWidth=.7*s;g.stroke();g.restore()}
 if(tier<3&&(sk.gl||tier===2))fkGlow(g,tp.x,tp.y,(16+tier*2)*GK,sk.gl||GL,.4+.18*Math.sin(t*3));
 if(tier!==4){g.fillStyle=sk.tip;g.beginPath();g.arc(tp.x,tp.y,2.2*K,0,TAU);g.fill();g.lineWidth=.7*K;g.strokeStyle=FKO;g.stroke()}
 G.reel=reel;G.tip={x:tp.x,y:tp.y,a:ta};if(X&&X.over)X.over(g,G);
 g.restore();
 FSRODG={at,wAt,tier,sk,GL,LC,t,len,K,tip:{x:tp.x,y:tp.y},reel,hx,hy,a,b,pt,LOD,look:X};
 return{x:tp.x,y:tp.y}}
