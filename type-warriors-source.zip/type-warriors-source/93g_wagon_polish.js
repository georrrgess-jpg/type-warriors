/* ===== LANTERN CARAVAN 8.5 polish: motion, impact and readability =====
   Overrides only (later declarations win), loaded after 93f.
   - The wagon feels heavy: it pitches back as it pulls away and dips its nose when it stops (a damped spring on WRX.pitch,
     applied about the rear axle in 93b), wheels roll without slipping, dust kicks up behind both wheels, and the lantern
     throws a warm pool of light on the deck.
   - A jam reads at a glance: sparks from the locked wheel (spawned here, not in the painter), a red ! over the driver that
     pulses faster once the fuse is under 3 s, a sweat drop, and the wrench bubble swelling red as it runs out.
   - Hits read before the death: each letter flashes the monster white (an offscreen silhouette, no ctx.filter) and nudges it;
     a killed monster holds a white frame for 0.12 s while the hero's blow lands, then squashes; its tag bursts into sparks.
   - Tags and toasts spring in; the typed letter pops; floating texts step aside instead of stacking.
   - The breakdown: the front wheel rolls off and topples, the nose drops, dust when it lands.
   - The gate throws a shower of sparks as its doors open; the HUD coin count rolls up, the lantern meter fills smoothly and
     sparkles when full, a restored shield pops back with a ring.
   - Reduced motion: no pitch, no tumbles, no springs (tags, toasts, doors), fewer sparks. Low performance mode drops the
     dust, embers, window flicker, waterfall mist and the hit silhouettes. */
const wrLow=()=>{try{return PFM()==='low'}catch(e){return false}};
/* ---------- painters used by 93b ---------- */
function wrLightPool(c,R,t,LA){const k='wr_pool_'+LA.glow,spr=abSprite(k,300,300,g=>{const q=g.createRadialGradient(150,150,0,150,150,150);q.addColorStop(0,`rgba(${LA.glow},1)`);q.addColorStop(.45,`rgba(${LA.glow},.42)`);q.addColorStop(1,`rgba(${LA.glow},0)`);g.fillStyle=q;g.fillRect(0,0,300,300)});
 const f=.32+.04*Math.sin(t*11.3)+.03*Math.sin(t*7.1),b=R.flareOn>0?1.9:1;c.save();c.globalCompositeOperation='lighter';c.globalAlpha=Math.min(1,f*b);c.drawImage(spr,126-310,-30,620,58);c.restore()}
function wrAlarm(c,R,t){const h=R.haz,a=h.fuse-h.t,low=h.t<3,p=R.rm?1:wrOver(Math.min(1,a/.28)),pu=low?1+.12*Math.max(0,Math.sin(t*16)):1,y=-292+(R.rm?0:Math.sin(t*(low?14:7))*2.5);
 c.save();c.translate(222,y);c.scale(p*pu,p*pu);c.beginPath();c.arc(0,0,15,0,TAU);c.fillStyle=low?'#ff3b55':'#e8364e';c.fill();wrStroke(c,3);
 c.fillStyle='#fff';c.font='800 21px Poppins,system-ui,sans-serif';c.textAlign='center';c.textBaseline='middle';c.fillText('!',0,1);c.restore();
 if(low){const u=(t*1.7)%1;c.save();c.globalAlpha=1-u;c.translate(150,-238+u*26);c.beginPath();c.moveTo(0,-7);c.quadraticCurveTo(6,1,0,5);c.quadraticCurveTo(-6,1,0,-7);c.fillStyle='#9fe0ff';c.fill();c.lineWidth=1.6;c.strokeStyle=WRO;c.stroke();c.restore()}}
/* the front wheel after a breakdown: it rolls on, wobbles and falls flat */
function wrWheelOff(c,R,PA){const d=R.doneT||0,dist=R.rm?120:210*(1-Math.exp(-d*2.2)),k=R.rm?1:wrEase(Math.min(1,Math.max(0,(d-.75)/.45)));
 c.save();c.translate(150+dist,0);c.rotate((R.rm?0:Math.sin(d*13)*.1*(1-k)));c.scale(1,1-.8*k);wrWheel(c,0,-44,44,R.wheel*52/44+dist/44,PA.rim,false);c.restore()}
/* ---------- the run's extra motion ---------- */
{const u0=wrUpdate;wrUpdate=function(dt){const R=WRX;if(!R)return u0.apply(this,arguments);const int0=R.int,fl0=R.flare,d0=R.doneT,r=u0.apply(this,arguments);
 if(WRX!==R||R.pause)return r;dt=Math.min(dt,.05);R._dt=dt;const low=wrLow();
 /* pitch: a damped spring toward a target set by the acceleration */
 {const tg=(R.rm||R.st==='break')?0:wrClamp(-(R.accel||0)*.00034,-.032,.032);R.pv=(R.pv||0)+((tg-(R.pitch||0))*90-(R.pv||0)*11)*dt;R.pitch=(R.pitch||0)+R.pv*dt}
 /* dust behind the wheels */
 R.dust=R.dust||[];if(!low&&R.v>15){R.dustT=(R.dustT||0)-dt;if(R.dustT<=0){R.dustT=R.flareOn>0?.035:.06;for(const wx of[WRT.WX-8,WRT.WX+146])R.dust.push({x:wx+(Math.random()-.5)*14,y:GY-3,vx:-R.v*.9-Math.random()*30,vy:-8-Math.random()*22,l:.8,l0:.8,s:3+Math.random()*4})}}
 for(const q of R.dust){q.x+=q.vx*dt;q.y+=q.vy*dt;q.vy*=Math.pow(.2,dt);q.s+=dt*10;q.l-=dt}if(R.dust.length)R.dust=R.dust.filter(q=>q.l>0).slice(-70);
 /* sparks from the locked wheel */
 if(R.haz&&R.st==='roll'){R.spkT=(R.spkT||0)-dt;if(R.spkT<=0){R.spkT=.05*(R.rm?3:1)*(low?2:1);ptBurst(R.fx,WRT.WX+188+(Math.random()-.5)*10,GY-18,1,['#ffd45a','#ff9a5a','#fff2b0'],{v:250,s:3,up:1,sp:1.6,g:440,l:.45})}}
 /* letter nudges and the HUD's eased numbers */
 for(const e of R.mobs)if(e.nud)e.nud=Math.max(0,e.nud-dt*7);
 R.coinShow=R.coinShow==null?R.coins:R.coinShow+(R.coins-R.coinShow)*Math.min(1,dt*9);if(Math.abs(R.coins-R.coinShow)<.5)R.coinShow=R.coins;
 R.flareShow=R.flareShow==null?R.flare:R.flareShow+(R.flare-R.flareShow)*Math.min(1,dt*10);if(Math.abs(R.flare-R.flareShow)<.3)R.flareShow=R.flare;
 R.hfx=R.hfx||[];
 if(R.int>int0)R.gainT={i:R.int-1,t:0};if(R.gainT){R.gainT.t+=dt;if(R.gainT.t>.8)R.gainT=null}
 if(fl0<WRT.FLARE&&R.flare>=WRT.FLARE){ptBurst(R.hfx,1332,41,R.rm?6:16,['#ffe9a0','#fff8d8','#ffb84a'],{v:150,s:4,g:60,l:.8});R.flareShow=R.flare}
 /* the gate's shower of sparks as the doors open */
 if(R.st==='gate'&&!R.gConf){const gs=R.gx-R.x;if(gs<1060){R.gConf=1;ptBurst(R.fx,gs,GY-340,R.rm?14:44,['#ffd45a','#fff4c8','#ff9a5a','#9fd0ff'],{v:460,up:1,sp:2.6,g:300,l:1.7,s:6});wrRing(gs,GY-200,'#ffe08a',360,8,.5)}}
 /* the fallen wheel lands */
 if(R.st==='break'&&d0<1.15&&R.doneT>=1.15){const xw=WRT.WX+150+(R.rm?120:210*(1-Math.exp(-1.15*2.2)));ptBurst(R.fx,xw,GY-4,R.rm?5:14,'#8a7a6a',{k:'dust',v:130,up:1,sp:2.8,g:60,s:6});if(!R.rm)R.shake=Math.max(R.shake,6)}
 return r}}
/* dust is painted behind the wagon (the gate is drawn just before the pet and the wagon) */
{const g0=wrGateDraw;wrGateDraw=function(c,R){const r=g0.apply(this,arguments);const D=R&&R.dust;if(D&&D.length){c.save();c.fillStyle='#8a7aa0';for(const q of D){c.globalAlpha=.26*(q.l/q.l0);c.beginPath();c.arc(q.x,q.y,q.s,0,TAU);c.fill()}c.restore()}return r}}
/* ---------- input: the typed letter pops, the monster is nudged ---------- */
{const k0=wrKey;wrKey=function(ch){const R=WRX,t0=R&&R.tgt,i0=t0?t0.i:-1,r=k0.apply(this,arguments);const t=R&&R.tgt;
 if(t&&(t!==t0||t.i>i0)&&t.i>0&&t.w[t.i-1]===String(ch).toLowerCase()){t.popT=R.t;t.popI=t.i-1;if(!t.hz)t.nud=1}return r}}
/* the finished word's tag bursts */
{const k0=wrKill;wrKill=function(e){const b=e&&e.tagBox,R=WRX,r=k0.apply(this,arguments);if(b&&R){ptBurst(R.fx,b.x+b.w/2,b.y+b.h/2,R.rm?5:14,['#ff6a7a','#ffd45a','#fff8e8'],{v:260,s:4,g:220,l:.6})}return r}}
{const p0=wrRepair;wrRepair=function(){const R=WRX,b=R&&R.haz&&R.haz.tagBox,r=p0.apply(this,arguments);if(b){ptBurst(R.fx,b.x+b.w/2,b.y+b.h/2,R.rm?5:14,['#9fd0ff','#ffffff','#6ab0ff'],{v:260,s:4,g:220,l:.6})}return r}}
/* ---------- monsters: the white hit silhouette and a death that waits for the blow ---------- */
const WRFL=document.createElement('canvas');
function wrSil(c,e,M,sc,t,a){const k=Math.min(2,RS||1),bw=(M.tw||M.th*1.1)*1.8,bh=M.th*1.7,cw=Math.ceil(bw*sc*k),ch=Math.ceil(bh*sc*k);if(cw<2||ch<2||cw*ch>2.5e6)return;
 if(WRFL.width<cw)WRFL.width=cw;if(WRFL.height<ch)WRFL.height=ch;const g=WRFL.getContext('2d');g.setTransform(1,0,0,1,0,0);g.globalCompositeOperation='source-over';g.globalAlpha=1;g.clearRect(0,0,cw,ch);
 g.setTransform(sc*k,0,0,sc*k,bw/2*sc*k,bh*.9*sc*k);try{M.d(g,t,{lg:e.lg||0})}catch(x){}g.setTransform(1,0,0,1,0,0);g.globalCompositeOperation='source-atop';g.fillStyle='#fff8ec';g.fillRect(0,0,cw,ch);g.globalCompositeOperation='source-over';
 c.globalAlpha*=a;c.drawImage(WRFL,0,0,cw,ch,-bw/2,-bh*.9,bw,bh)}
function wrMobDraw(c,e){const M=MON[e.id];if(!M)return;const R=WRX,sc=e.h/M.th,dead=e.st==='dead',fl=e.st==='fling',t=S.t+e.ph*3,HOLD=.12,dk=dead?Math.max(0,(e.dt-HOLD)/.45):0;if(dk>=1)return;
 const ox=e.x-(e.lg||0)*64+(e.badT>0?Math.sin(e.badT*60)*4:0)+(e.nud||0)*7;
 if(!dead&&!fl&&!e.fly){c.fillStyle='rgba(0,0,0,.32)';c.beginPath();c.ellipse(e.x,GY+6,e.h*.3,8,0,0,TAU);c.fill()}
 if(!dead&&!fl){glow(c,e.x,e.y-e.h*.5,e.h*.62,(e.boss?'#ff8a9a':R.rt.far==='forest'?'#8ad8c8':R.rt.far==='keep'?'#c88aff':'#ffb86a')+(e.boss?'44':'22'))}
 const xf=()=>{if(dead&&dk>0){c.globalAlpha=1-dk;c.translate(e.x,e.y);c.scale(1+dk*.35,Math.max(.02,1-dk*1.1));if(!R.rm)c.rotate(dk*.4);c.translate(-e.x,-e.y)}
  if(fl&&!R.rm){c.translate(e.x,e.y-e.h*.5);c.rotate(e.rot);c.translate(-e.x,-(e.y-e.h*.5))}c.translate(ox,e.y);c.scale(sc,sc)};
 c.save();xf();M.d(c,t,{lg:e.lg||0});c.restore();
 const fa=dead?(e.dt<HOLD?1:Math.max(0,1-(e.dt-HOLD)/.14)):e.fl>0?Math.min(1,e.fl/.12)*.7:0;
 if(fa>.02){if(wrLow()){c.save();c.globalCompositeOperation='lighter';c.globalAlpha=fa*.8;glow(c,ox,e.y-e.h*.5,e.h*.5,'#fff8e8');c.restore()}else{c.save();xf();wrSil(c,e,M,sc,t,fa);c.restore()}}}
/* ---------- tags spring in; the typed letter pops; the hazard bubble swells red as its fuse runs out ---------- */
function wrTag(c,e,tgt){const R=WRX,hz=!!e.hz,dt=(R&&R._dt)||1/60;wrTagFont(c);const pw=c.measureText('M').width,tw=pw*e.w.length,w=tw+72,h=44;let x=wrClamp((hz?e.x:e.x-(e.lg||0)*30)-w/2,8,W-w-8),y=hz?e.y-h:e.y-e.h-30-h-(e.tlift||0);if(!hz&&e.fly)y=Math.max(90,y);
 e.tagA=(e.tagA||0)+dt;const rm=R&&R.rm,bob=rm?0:Math.sin(S.t*3+(e.ph||0))*3;y+=bob;if(e.badT>0)x+=Math.sin(e.badT*60)*5;
 const low=hz&&e.t<3,col=WCOL(),fill=hz?(low?'#3a1530':'#1a2550'):'#3a0c18',bd=hz?(low?'#ff6a8a':'#6ab0ff'):tgt?col:'#e8364e';
 let s=rm?1:wrOver(Math.min(1,e.tagA/.28));if(low&&!rm)s*=1+.05*Math.max(0,Math.sin(S.t*16));
 e.tagBox={x,y,w,h};
 c.save();c.translate(x+w/2,y+h+10);c.scale(s,s);c.translate(-(x+w/2),-(y+h+10));
 c.fillStyle=fill;c.strokeStyle=bd;c.lineWidth=tgt||low?3:2;c.beginPath();c.roundRect(x,y,w,h,13);c.fill();c.stroke();
 c.fillStyle=fill;c.beginPath();c.moveTo(x+w/2-9,y+h-1);c.lineTo(x+w/2+9,y+h-1);c.lineTo(x+w/2,y+h+10);c.closePath();c.fill();c.strokeStyle=bd;c.lineWidth=2;c.beginPath();c.moveTo(x+w/2-9,y+h);c.lineTo(x+w/2,y+h+10);c.lineTo(x+w/2+9,y+h);c.stroke();
 c.strokeStyle='rgba(255,255,255,.14)';c.lineWidth=1;c.beginPath();c.moveTo(x+12,y+2);c.lineTo(x+w-12,y+2);c.stroke();
 if(hz){const u=Math.max(0,e.t/e.fuse);c.fillStyle='rgba(0,0,0,.35)';c.beginPath();c.roundRect(x+12,y+h-7,w-24,3.5,2);c.fill();c.fillStyle=low?'#ff6a8a':u<.6?'#ffd45a':'#6ab0ff';c.beginPath();c.roundRect(x+12,y+h-7,(w-24)*u,3.5,2);c.fill()}
 c.save();c.translate(x+26,y+h/2);if(hz){if(!rm)c.rotate(Math.sin(S.t*(low?18:6))*.18);wrIcoWrench(c,0,0,11,low?'#ffb0c0':'#9fd0ff')}else wrIcoSword(c,0,0,11,'#ff6a7a');c.restore();
 wrTagFont(c);c.textBaseline='middle';c.textAlign='center';const x0=x+50,cy=y+h/2,pop=e.popT!=null&&R?(R.t-e.popT)/.16:9;
 for(let i=0;i<e.w.length;i++){const lx=x0+i*pw+pw/2;c.fillStyle=i<e.i?(hz?'#9fd0ff':col):'#fff8e8';if(i===e.popI&&pop<1&&!rm){c.save();c.translate(lx,cy);const z=1+.4*(1-pop);c.scale(z,z);c.fillText(e.w[i],0,0);c.restore()}else c.fillText(e.w[i],lx,cy)}
 if(tgt&&e.i<e.w.length){c.fillStyle=hz?'#9fd0ff':col;c.globalAlpha=rm?1:.75+.25*Math.sin(S.t*10);c.fillRect(x0+e.i*pw,cy+13,pw,3.4);c.globalAlpha=1}c.restore()}
/* ---------- toasts spring in; floating texts step aside ---------- */
function wrToastDraw(c,t){const R=WRX,k=t.d-t.t,a=Math.min(1,k*5,t.t*2.5),s=R&&R.rm?1:.72+.28*wrOver(Math.min(1,k/.34));c.save();c.globalAlpha=a;c.font='700 22px Poppins,system-ui,sans-serif';c.textAlign='center';c.textBaseline='middle';const w=c.measureText(t.txt).width+56,y=108;
 c.translate(W/2,y+23);c.scale(s,s);c.translate(-W/2,-(y+23));c.fillStyle='rgba(8,4,20,.86)';c.strokeStyle=t.c;c.lineWidth=2;c.beginPath();c.roundRect(W/2-w/2,y,w,46,16);c.fill();c.stroke();c.strokeStyle='rgba(255,255,255,.12)';c.lineWidth=1;c.beginPath();c.moveTo(W/2-w/2+16,y+2);c.lineTo(W/2+w/2-16,y+2);c.stroke();c.fillStyle=t.c;c.fillText(t.txt,W/2,y+24);c.restore()}
function wrText(x,y,s,c,sz){const L=WRX.tx;for(let n=0;n<5;n++){const hit=L.some(q=>{const qy=q.y-(q.a/(q.d||1.3))*46;return q.a<.7&&Math.abs(q.x-x)<170&&Math.abs(qy-y)<40});if(!hit)break;y-=44}L.push({x,y,s,c,sz:sz||24,a:0,d:1.2})}
/* ---------- HUD: rolling numbers, the full-lantern sparkle, a restored shield pops back ---------- */
{const h0=wrHUD;wrHUD=function(c,R){const c0=R.coins,f0=R.flare;if(R.coinShow!=null)R.coins=Math.round(R.coinShow);if(R.flareShow!=null)R.flare=R.flareShow;let r;try{r=h0.apply(this,arguments)}finally{R.coins=c0;R.flare=f0}
 if(R.gainT){const g=R.gainT,u=Math.min(1,g.t/.6),x=52+g.i*38;c.save();if(!R.rm){c.strokeStyle=`rgba(125,255,176,${1-u})`;c.lineWidth=3*(1-u)+1;c.beginPath();c.arc(x,60,13+u*20,0,TAU);c.stroke()}wrShieldIcon(c,x,60,13*(1+(R.rm?0:.45*(1-wrOver(Math.min(1,g.t/.35))))),true,null);c.restore()}
 if(R.hfx&&R.hfx.length)ptFxStep(c,R.hfx,R._dt||1/60);return r}}
/* ---------- the result card: sparkles around the medal ---------- */
{const r0=wrResult;wrResult=function(){const r=r0.apply(this,arguments);try{const R=WRX,m=document.querySelector('.wrmed');if(m&&R&&R.result&&R.result.won&&!wrRM())for(let i=0;i<4;i++){const s=document.createElement('i');s.className='wrspk';s.style.setProperty('--i',i);m.appendChild(s)}}catch(e){}return r}}
{const st=document.createElement('style');st.textContent=`
.wrmed .wrspk{position:absolute;width:30px;height:30px;opacity:0;pointer-events:none;background:linear-gradient(135deg,#fffbe0,#ffd45a);clip-path:polygon(50% 0,60% 40%,100% 50%,60% 60%,50% 100%,40% 60%,0 50%,40% 40%);animation:wrSpk .9s calc(.75s + var(--i)*.12s) cubic-bezier(.2,.8,.3,1) both}
.wrmed .wrspk:nth-of-type(1){left:-14px;top:22px}.wrmed .wrspk:nth-of-type(2){right:-10px;top:10px}.wrmed .wrspk:nth-of-type(3){left:6px;bottom:4px;width:22px;height:22px}.wrmed .wrspk:nth-of-type(4){right:2px;bottom:18px;width:20px;height:20px}
@keyframes wrSpk{0%{opacity:0;transform:scale(0) rotate(0)}40%{opacity:1;transform:scale(1.15) rotate(45deg)}100%{opacity:0;transform:scale(.3) rotate(90deg)}}
.wrres .res>div{animation:fsIn .45s var(--sp) both}.wrres .res>div:nth-child(1){animation-delay:.35s}.wrres .res>div:nth-child(2){animation-delay:.41s}.wrres .res>div:nth-child(3){animation-delay:.47s}.wrres .res>div:nth-child(4){animation-delay:.53s}.wrres .res>div:nth-child(5){animation-delay:.59s}.wrres .res>div:nth-child(6){animation-delay:.65s}.wrres .res>div:nth-child(7){animation-delay:.71s}
.wrres .wrpay{animation:fsWb .45s .6s var(--sp) both}
.wrrt{animation:wrCardIn .5s var(--sp) both}.wrrt:nth-child(1){animation-delay:.16s}.wrrt:nth-child(2){animation-delay:.23s}.wrrt:nth-child(3){animation-delay:.3s}
@keyframes wrCardIn{from{opacity:0;transform:translateX(-24px)}}
.wrchip:active,.wrrt:active{transform:scale(.95)}
.wrhub .fshgo:active{transform:scale(.97)}
@media (prefers-reduced-motion:reduce){.wrmed .wrspk,.wrres .res>div,.wrres .wrpay,.wrrt{animation:none!important}}`;document.head.appendChild(st)}
