/* ===== MOONLIT FISHING: Rod Workshop, redesigned =====
   A showcase bench that plays each rod's animation (preview any tier), a rod-level track toward the next rod,
   upgrade cards with animated canvas icons, plain before/after numbers and a worked example, a "Best value" tag,
   a buy animation (coins fly to the purse, pips pop), and a rod-look gallery with one detail card.
   Keys: 1 / 2 / 3 buy Line / Lure / Hook. */
const FWRING=['#7a7498','#c8803a','#c8803a','#dfe3f6','#dfe3f6','#ffd45a'];
/* animated upgrade icons: k = line / lure / hook, lv 0..5 (the medallion ring turns bronze, silver, gold) */
function fsUpArt(g,k,t,lv,S){S=S||120;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,S,S);g.save();g.scale(S/120,S/120);g.lineJoin='round';g.lineCap='round';
 const ring=FWRING[lv]||FWRING[0];fkGlow(g,60,60,64,ring,.16+.05*Math.sin(t*2));
 g.beginPath();g.arc(60,60,52,0,TAU);g.fillStyle=fkRad(g,52,46,58,['#3e3488','#221a5a','#140e3a']);g.fill();g.lineWidth=7;g.strokeStyle=FKO;g.stroke();g.lineWidth=4;g.strokeStyle=ring;g.stroke();
 g.save();g.beginPath();g.arc(60,60,48,0,TAU);g.clip();g.fillStyle='#ffffff10';g.beginPath();g.ellipse(46,30,40,18,-.4,0,TAU);g.fill();g.restore();
 if(k==='line'){const ln=lv>=3?'#bfe8ff':'#f4ecd8',ln2=lv>=3?'#7ab8e8':'#c8b898';
  /* thread end curling off the spool */
  g.strokeStyle=FKO;g.lineWidth=4;g.beginPath();g.moveTo(84,40);g.bezierCurveTo(100,30,96,16,84,18);g.stroke();g.strokeStyle=ln;g.lineWidth=2;g.stroke();
  g.fillStyle='#e8364e';g.beginPath();g.arc(84,18,4,0,TAU);g.fill();g.lineWidth=2;g.strokeStyle=FKO;g.stroke();
  /* back disc, wound core, front disc */
  const wood=lv>=5?['#fff2b0','#e6b93e','#8a5a10']:['#d8a868','#a8743a','#6a4218'];
  g.beginPath();g.ellipse(34,60,11,33,0,0,TAU);g.fillStyle=wood[2];g.fill();g.lineWidth=3;g.strokeStyle=FKO;g.stroke();
  g.save();g.beginPath();g.rect(34,37,52,46);g.clip();g.fillStyle=fkLin(g,0,37,0,83,[ln2,ln,ln2]);g.fillRect(34,37,52,46);
  g.strokeStyle=ln2;g.lineWidth=1.3;const off=(t*14)%5;for(let y=35+off;y<86;y+=5){g.beginPath();g.moveTo(34,y);g.quadraticCurveTo(60,y+2,86,y);g.stroke()}
  g.fillStyle='#ffffff55';g.fillRect(34,44,52,4);g.restore();g.lineWidth=3;g.strokeStyle=FKO;g.beginPath();g.moveTo(34,37);g.lineTo(86,37);g.moveTo(34,83);g.lineTo(86,83);g.stroke();
  g.beginPath();g.ellipse(86,60,12,34,0,0,TAU);g.fillStyle=fkLin(g,74,26,98,94,[wood[0],wood[1],wood[2]]);g.fill();g.lineWidth=3;g.stroke();
  g.strokeStyle=wood[2];g.lineWidth=2.4;for(let i=0;i<4;i++){const a=t*2.2+i*Math.PI/2;g.beginPath();g.moveTo(86,60);g.lineTo(86+Math.cos(a)*9,60+Math.sin(a)*27);g.stroke()}
  g.beginPath();g.ellipse(86,60,3.5,8,0,0,TAU);g.fillStyle='#3a2414';g.fill();g.lineWidth=1.6;g.strokeStyle=FKO;g.stroke();
  g.strokeStyle='#ffffff88';g.lineWidth=2;g.beginPath();g.ellipse(86,60,8,28,0,Math.PI*1.1,Math.PI*1.45);g.stroke()}
 else if(k==='lure'){const wb=Math.sin(t*3.2)*.09;g.save();g.translate(60,54);g.rotate(wb);
  const c0=lv>=5?['#fff2b0','#ffc83a','#c87a10']:lv>=3?['#ffb0e8','#ff6ab8','#a82a7a']:['#ffd45a','#ff7a3a','#b8401a'];
  /* treble hooks */
  const treble=(x,y,s)=>{g.strokeStyle=FKO;g.lineWidth=3.4;g.beginPath();g.moveTo(x,y);g.lineTo(x,y+12*s);g.stroke();g.strokeStyle='#d8dcf0';g.lineWidth=1.6;g.stroke();
   [[-1,0],[1,0],[0,1]].forEach(([dx])=>{g.strokeStyle=FKO;g.lineWidth=3.2;g.beginPath();g.moveTo(x,y+12*s);g.quadraticCurveTo(x+dx*8*s,y+22*s,x+dx*8*s,y+14*s);g.stroke();g.strokeStyle='#d8dcf0';g.lineWidth=1.5;g.stroke()});g.beginPath();g.arc(x,y,2.6,0,TAU);g.fillStyle='#d8dcf0';g.fill();g.lineWidth=1.4;g.strokeStyle=FKO;g.stroke()};
  treble(-12,12,1);treble(14,12,.9);
  /* lip */
  g.beginPath();g.moveTo(30,4);g.lineTo(46,16);g.lineTo(40,22);g.lineTo(26,10);g.closePath();g.fillStyle='#bfe8ffaa';g.fill();g.lineWidth=2.4;g.strokeStyle=FKO;g.stroke();
  /* tail fin */
  g.beginPath();g.moveTo(-30,0);g.lineTo(-44,-12+Math.sin(t*6)*3);g.lineTo(-40,0);g.lineTo(-44,12-Math.sin(t*6)*3);g.closePath();g.fillStyle=c0[0];g.fill();g.lineWidth=2.6;g.stroke();
  /* two-part body */
  const body=()=>{g.beginPath();g.moveTo(-32,0);g.bezierCurveTo(-26,-17,20,-20,34,-4);g.bezierCurveTo(36,4,30,12,20,14);g.bezierCurveTo(0,18,-24,12,-32,0);g.closePath()};
  body();g.fillStyle=fkLin(g,0,-18,0,16,[c0[2],c0[1],c0[0],'#fff8e0']);g.fill();g.lineWidth=3;g.strokeStyle=FKO;g.stroke();
  g.save();body();g.clip();g.strokeStyle='#00000030';g.lineWidth=1.4;for(let x=-24;x<24;x+=7)for(let y=-12;y<12;y+=7){g.beginPath();g.arc(x+(y%14?3.5:0),y,4,.2,Math.PI-.2);g.stroke()}
  g.fillStyle='#ffffff66';g.beginPath();g.ellipse(-2,-10,22,4,-.06,0,TAU);g.fill();g.fillStyle=c0[2];g.fillRect(-2,-20,3,40);g.restore();
  g.strokeStyle=FKO;g.lineWidth=2.4;g.beginPath();g.moveTo(-1,-15);g.lineTo(-1,15);g.stroke();
  g.beginPath();g.arc(22,-3,6.5,0,TAU);g.fillStyle='#fff';g.fill();g.lineWidth=2.2;g.stroke();g.beginPath();g.arc(23.5,-3,3.6,0,TAU);g.fillStyle='#1b1024';g.fill();g.fillStyle='#fff';g.beginPath();g.arc(25,-4.6,1.4,0,TAU);g.fill();
  g.restore();fkSpark(g,92,30,3+3*Math.abs(Math.sin(t*2.6)),'#fff6c0',.95);fkSpark(g,30,84,2+2*Math.abs(Math.sin(t*2.6+2)),'#fff',.8)}
 else{const steel=lv>=5?['#fff2b0','#e6b93e','#8a5a10']:['#ffffff','#c8cce0','#6a7090'];
  const hook=()=>{g.beginPath();g.moveTo(66,28);g.lineTo(66,70);g.arc(52,70,14,0,Math.PI,false);g.lineTo(38,56)};
  g.strokeStyle=FKO;g.lineWidth=11;hook();g.stroke();g.beginPath();g.moveTo(38,56);g.lineTo(46,64);g.stroke();
  g.strokeStyle=fkLin(g,38,20,70,90,steel);g.lineWidth=6;hook();g.stroke();g.beginPath();g.moveTo(38,56);g.lineTo(45,63);g.stroke();
  g.beginPath();g.moveTo(38,58);g.lineTo(36,46);g.lineTo(42,54);g.closePath();g.fillStyle=steel[1];g.fill();g.lineWidth=2;g.strokeStyle=FKO;g.stroke();
  g.strokeStyle='#ffffffcc';g.lineWidth=1.8;g.beginPath();g.moveTo(64,32);g.lineTo(64,66);g.stroke();
  g.beginPath();g.arc(66,21,8,0,TAU);g.lineWidth=7;g.strokeStyle=FKO;g.stroke();g.lineWidth=3.6;g.strokeStyle=steel[1];g.stroke();
  g.strokeStyle=lv>=3?'#bfe8ff':'#f4ecd8';g.lineWidth=2;g.beginPath();g.moveTo(66,13);g.quadraticCurveTo(70,4,82,2);g.stroke();
  /* a shine runs down the hook */
  const u=(t*.55)%1.6;if(u<1){let x,y;if(u<.55){x=66;y=28+u/.55*42}else{const a=(u-.55)/.45*Math.PI;x=52+Math.cos(a)*14;y=70+Math.sin(a)*14}fkGlow(g,x,y,14,'#ffffff',.7);fkSpark(g,x,y,5,'#ffffff',1)}
  /* a drop falls from the point */
  const d=(t*.7)%1;g.fillStyle=`rgba(170,220,255,${1-d})`;g.beginPath();g.ellipse(38,50+d*36,2.4,3.4,0,0,TAU);g.fill()}
 g.restore()}
FSH.wprev=null;FSH.wlook=null;
fsWorkshop=function(){S.mode='fish';S.view='fishwork';FS.on=false;const F=fsP(),lv=fsLv(),tier=fsTier(),TL=[0,3,6,10,15],next=TL.find(x=>x>lv);
 if(FSH.wprev!=null&&FSH.wprev===tier)FSH.wprev=null;if(!FSH.wlook||!FSKIN[FSH.wlook])FSH.wlook=F.skin;
 const cheap=FSUPK.filter(k=>fsUpCost(k)!=null).sort((a,b)=>fsUpCost(a)-fsUpCost(b))[0];
 const LK=['×1','×1.08','×1.16','×1.26','×1.38','×1.5'],fx={line:l=>FSUP.line.fx(l),lure:l=>`${l?'−'+l*6+'% wait':'base wait'} · rare ${LK[l]}`,hook:l=>FSUP.hook.fx(l)};
 const ex={line:l=>`A 6-letter rare word: <b>${fsTime('aaaaaa',l,'r').toFixed(1)}s</b>`,lure:l=>`Average wait <b>${(4*(1-l*.06)).toFixed(1)}s</b>`,hook:l=>`A 40 cm trout grows to <b>${Math.round(40*(1+l*.04))} cm</b>`};
 const ups=FSUPK.map((k,i)=>{const U=FSUP[k],l=F.up[k]||0,c=fsUpCost(k),can=c!=null&&P.gold>=c;
  return `<div class="fw-up${c==null?' max':''}${FSH.wjust===k?' just':''}" data-uk="${k}" style="--ring:${FWRING[l]}">${k===cheap&&can?'<span class="fw-best">Best value</span>':''}
   <canvas class="fw-ic" width="120" height="120" data-ic="${k}"></canvas>
   <div class="fw-ub"><div class="fw-ut"><b>${U.n}</b><span class="fw-lv">Lv ${l} / 5</span><span class="fw-pips">${[0,1,2,3,4].map(j=>`<i class="${j<l?'on':''}${FSH.wjust===k&&j===l-1?' new':''}"></i>`).join('')}</span></div>
    <small class="fw-d">${U.d}</small>
    <div class="fw-fx"><span class="fw-now"><small>Now</small>${fx[k](l)}</span>${c!=null?`<span class="fw-ar">➜</span><span class="fw-nx"><small>Next</small>${fx[k](l+1)}</span>`:'<span class="fw-nx mx"><small>Maxed</small>The best there is</span>'}</div>
    <small class="fw-ex">${ex[k](l)}${c!=null?` <span>➜</span> ${ex[k](l+1).replace(/^.*?<b>/,'<b>')}`:''}</small></div>
   <div class="fw-buy">${c==null?'<span class="fw-max">♛ MAX</span>':`<button data-up="${k}" ${can?'':'disabled'}><kbd>${i+1}</kbd>${fsCoin}${c.toLocaleString()}</button><small>${can?'+1 rod level':`Need ${(c-P.gold).toLocaleString()} more`}</small>`}</div></div>`}).join('');
 const pv=FSH.wprev!=null?FSH.wprev:tier;
 const track=Array.from({length:15},(_,i)=>`<i class="${i<lv?'on':''}${TL.includes(i+1)?' tk':''}"></i>`).join('');
 const looks=FSKINK.map(k=>{const K=FSKIN[k],own=F.sk[k],eq=F.skin===k,can=fsCanSkin(k);return `<button class="fw-sw${own?' own':''}${eq?' eq':''}${can?' can':''}${FSH.wlook===k?' on':''}" data-lk="${k}" style="--sc:${K.gl||K.c[1]}" aria-label="${K.n}"><canvas width="96" height="60"></canvas><em>${K.n}</em>${eq?'<i class="fw-ck">✓</i>':can?'<i class="fw-ex2">!</i>':own?'':'<i class="fw-lk">🔒</i>'}</button>`}).join('');
 show(`<div class="fsx fswx fw" id="fsx"><canvas id="fswb" width="1600" height="900" aria-hidden="true"></canvas>
 <div class="fstr"><span class="fsgold fsg" id="fwpurse">${fsCoin}<b id="fsgold">${P.gold.toLocaleString()}</b></span><button class="fsback fsg" id="fsback"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 5l-7 7 7 7" stroke="currentColor" stroke-width="2.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>Back <kbd>Esc</kbd></button></div>
 <h2 class="fswh">Rod Workshop</h2><p class="fw-sub">Upgrade your rod with gold. Every 3–5 upgrades it becomes a brand-new rod.</p>
 <section class="fw-bench${FSH.wtier?' tierup':''}"><canvas id="fswrod" width="880" height="260"></canvas>${FSH.wprev!=null?`<span class="fw-pvtag">Preview${FSH.wprev>tier?` · unlocks at level ${TL[FSH.wprev]}`:''}<button id="fwmine">Show my rod</button></span>`:''}
  <div class="fw-info"><b class="fw-name">${FSTIERN[pv]}</b><small class="fw-lvl">Rod level <b>${lv}</b> / 15</small>
   <div class="fw-track">${track}</div><small class="fw-next">${next?`<b>${next-lv}</b> more upgrade${next-lv>1?'s':''} until the <b>${FSTIERN[TL.indexOf(next)]}</b>`:'You own the finest rod there is!'}</small>
   <div class="fw-tiers">${FSTIERN.map((n,i)=>`<button class="${i<=tier?'got':'lk'}${i===tier?' cur':''}${i===pv?' pv':''}" data-tier="${i}" title="${i<=tier?'Show':'Preview'} the ${n}"><canvas width="132" height="48"></canvas><em>${n.replace(' Rod','')}</em><small>${i<=tier?(i===tier?'Yours':'Owned'):'Lv '+TL[i]}</small></button>`).join('')}</div></div></section>
 <section class="fw-col"><h4 class="fssub">Upgrades <small>each one adds a rod level · keys 1 2 3</small></h4>${ups}</section>
 <section class="fw-col r"><h4 class="fssub">Rod looks <small>cosmetic · turn in fish you kept in your basket</small></h4><div class="fw-sws">${looks}</div><div class="fw-ld" id="fwld"></div></section></div>`,'fshx');
 {const back=FSH.wback||fsHub;S.back=()=>{FSH.wback=null;back()};$('fsback').onclick=S.back}{const cn=$('cn');if(cn)cn.classList.add('dkhid')}
 const bd=$('fswb');LIVE.push({cv:bd,fn:fsBackdrop(bd,'rgba(6,3,20,.74)'),slow:3});
 const skn=fsSkin();
 live('fswrod',cv=>{const g=cv.getContext('2d');return t=>{const tt=fsRM()?1.2:t;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,880,260);
  if(typeof fsRodShowcase==='function'){try{fsRodShowcase(g,440,128,880,275,tt,pv,skn)}catch(e){}}else{g.save();g.scale(1.9,1.9);fsRod(g,40,110,-.2,0,400,tt,skn,pv);g.restore()}}});
 ov.querySelectorAll('canvas[data-ic]').forEach(cv=>{const k=cv.dataset.ic,l=F.up[k]||0,g=cv.getContext('2d');LIVE.push({cv,fn:t=>fsUpArt(g,k,fsRM()?1:t,l),slow:2})});
 ov.querySelectorAll('.fw-tiers [data-tier]').forEach(b=>{const i=+b.dataset.tier,cv=b.querySelector('canvas'),g=cv.getContext('2d');fsRod(g,10,40,-.26,0,122,1,i<=tier?skn:{c:['#3a3260','#5a5288'],tip:'#5a5288',bob:['#333','#555'],ln:'#555'},i);if(i>tier){g.globalCompositeOperation='source-atop';g.fillStyle='#1a1440aa';g.fillRect(0,0,132,48)}
  b.onclick=()=>{FSH.wprev=i===tier?null:i;FSH.wjust=null;FSH.wtier=0;try{beep(640,.04,'triangle',.12)}catch(e){}fsWorkshop()}});
 const mine=$('fwmine');if(mine)mine.onclick=()=>{FSH.wprev=null;fsWorkshop()};
 ov.querySelectorAll('[data-up]').forEach(x=>x.onclick=()=>fsWorkBuy(x.dataset.up));
 ov.querySelectorAll('[data-lk]').forEach(b=>{const k=b.dataset.lk,g=b.querySelector('canvas').getContext('2d');fsRod(g,8,50,-.42,0,94,1,FSKIN[k],tier);b.onclick=()=>{FSH.wlook=k;ov.querySelectorAll('[data-lk]').forEach(x=>x.classList.toggle('on',x===b));fsWorkLook()}});
 fsWorkLook();
 /* buy feedback: coins fly from the button to the purse */
 if(FSH.wjust&&!fsRM()){const b=ov.querySelector(`.fw-up[data-uk="${FSH.wjust}"] .fw-buy`)||ov.querySelector(`.fw-up[data-uk="${FSH.wjust}"]`),p=$('fwpurse'),x=$('fsx');if(b&&p&&x){const sc=x.getBoundingClientRect().width/1600||1,rb=b.getBoundingClientRect(),rp=p.getBoundingClientRect(),rx=x.getBoundingClientRect();
  for(let i=0;i<7;i++){const c=document.createElement('i');c.className='fw-coin';const sx=(rb.left+rb.width/2-rx.left)/sc,sy=(rb.top+rb.height/2-rx.top)/sc,ex2=(rp.left+28-rx.left)/sc,ey=(rp.top+rp.height/2-rx.top)/sc;c.style.cssText=`left:${ex2}px;top:${ey}px;--dx:${sx-ex2+(Math.random()-.5)*40}px;--dy:${sy-ey+(Math.random()-.5)*20}px;animation-delay:${i*45}ms`;x.appendChild(c);setTimeout(()=>c.remove(),900+i*45)}}}
 if(FSH.wtier){setTimeout(()=>fsWorkToast(`New rod unlocked: the ${FSTIERN[tier]}!`),120)}
 FSH.wjust=null;FSH.wtier=0};
function fsWorkBuy(k){const t0=fsTier();if(!fsBuyUp(k)){try{beep(200,.08,'square',.08)}catch(e){}const c=ov.querySelector(`.fw-up[data-uk="${k}"]`);if(c&&!fsRM()){c.classList.remove('no');void c.offsetWidth;c.classList.add('no')}return}
 fsSfx('buy');FSH.wjust=k;FSH.wprev=null;const t2=fsTier();if(t2>t0){FSH.wtier=1;try{fsSfx('r')}catch(e){}}fsWorkshop()}
function fsWorkLook(){const d=$('fwld');if(!d)return;const F=fsP(),k=FSH.wlook,K=FSKIN[k],own=F.sk[k],eq=F.skin===k,can=fsCanSkin(k);
 const req=Object.entries(K.k).map(([id,n])=>{const have=F.cr.filter(c=>c.id===id).length,seen=F.b[id]&&F.b[id].n;return `<span class="fw-rq${have>=n?' ok':''}" title="${seen?FISH[id].n:'Undiscovered fish'}"><canvas width="66" height="40" data-rq="${id}"></canvas><b>${Math.min(have,n)} / ${n}</b><small>${seen?FISH[id].n:'???'}</small></span>`}).join('');
 d.style.setProperty('--sc',K.gl||K.c[1]);
 d.innerHTML=`<canvas id="fwlcv" width="660" height="96"></canvas><div class="fw-lt"><b>${K.n}</b><small>${K.d}</small></div>
  ${own?'':`<div class="fw-rqs">${req}</div>`}
  <div class="fw-la">${eq?'<span class="fw-eq">✓ Equipped</span>':own?'<button id="fwleq">Equip this look</button>':`<button id="fwleq" ${can?'':'disabled'}>Turn in fish</button><small>${can?'You have every fish needed.':'Keep these fish after a catch to collect them. The smallest ones are used first.'}</small>`}</div>`;
 d.querySelectorAll('canvas[data-rq]').forEach(cv=>{const id=cv.dataset.rq;fsThumb(cv,id,!(F.b[id]&&F.b[id].n),.4,'#5a4ca0')});
 live('fwlcv',cv=>{const g=cv.getContext('2d');return t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,660,96);fsRod(g,24,70,-.07,0,600,fsRM()?1:t,K,fsTier())}});
 const b=$('fwleq');if(b)b.onclick=()=>{const F2=fsP();if(F2.sk[k]){F2.skin=k;save();try{beep(760,.05,'triangle',.12)}catch(e){}}else if(fsCraft(k)){fsSfx('r')}fsWorkshop()}}
/* the pond side panel's Rod tab: a compact version with the same icons; rod looks live in the workshop */
function fsRodHTML(){const F=fsP(),lv=fsLv(),tier=fsTier(),TL=[0,3,6,10,15],next=TL.find(x=>x>lv);
 const ups=FSUPK.map(k=>{const U=FSUP[k],l=F.up[k]||0,c=fsUpCost(k);return `<div class="fw-mu" style="--ring:${FWRING[l]}"><canvas width="64" height="64" data-mic="${k}"></canvas><div><b>${U.n} <span class="fw-mpips">${[0,1,2,3,4].map(j=>`<i class="${j<l?'on':''}"></i>`).join('')}</span></b><small>${U.fx(l)}${c!=null?` <span>➜ ${U.fx(l+1)}</span>`:''}</small></div>${c==null?'<span class="fw-mmax">MAX</span>':`<button data-up="${k}" ${P.gold<c?'disabled':''}>${fsCoin}${c.toLocaleString()}</button>`}</div>`}).join('');
 return `<div class="fsrodh"><canvas id="fsrv" width="360" height="90"></canvas><div><h3>${FSTIERN[tier]}</h3><span>Level ${lv} / 15${next?` · ${next-lv} more for the ${FSTIERN[TL.indexOf(next)].replace(' Rod','')}`:''}</span></div></div>
 <h4 class="fssub">Upgrades</h4>${ups}<button class="fsjopen" id="fswopen">Open the Rod Workshop · rod looks ›</button>`}
{const t0=fsTabs;fsTabs=function(){t0.apply(this,arguments);if(FSU.tab!=='r')return;const F=fsP();ov.querySelectorAll('canvas[data-mic]').forEach(cv=>fsUpArt(cv.getContext('2d'),cv.dataset.mic,1,F.up[cv.dataset.mic]||0,64));
 const w=$('fswopen');if(w)w.onclick=()=>{if(FS.st!=='idle'){fsToast('Finish this catch first, then open the Rod Workshop.');return}fsStop();FSH.wback=fsPond;fsWorkshop()}}}
/* keep the Rod tab's buy buttons in step with your gold */
{const h0=fsHudRefresh;fsHudRefresh=function(){const r=h0.apply(this,arguments);try{if(S.view==='fish'&&FSU.tab==='r'&&$('fsbody'))ov.querySelectorAll('.fw-mu [data-up]').forEach(b=>{const c=fsUpCost(b.dataset.up);b.disabled=c==null||P.gold<c})}catch(e){}return r}}
document.addEventListener('keydown',e=>{if(S.mode!=='fish'||S.view!=='fishwork'||e.ctrlKey||e.metaKey||e.altKey||e.repeat)return;const i='123'.indexOf(e.key);if(i>=0&&FSUPK[i]){e.preventDefault();fsWorkBuy(FSUPK[i])}});
{const st=document.createElement('style');st.textContent=`
.fw .fswh{top:22px}.fw-mu{display:grid;grid-template-columns:52px 1fr auto;align-items:center;gap:10px;padding:6px 10px 6px 6px;margin-bottom:8px;border-radius:14px;background:#120c34cc;border:1.5px solid #3a3070}.fw-mu canvas{width:52px;height:52px}.fw-mu b{display:flex;align-items:center;gap:8px;font:800 15px var(--ui)}.fw-mu small{font:600 12px var(--ui);color:#c4badf}.fw-mu small span{color:#9affc8}
.fw-mpips{display:inline-flex;gap:3px}.fw-mpips i{width:12px;height:7px;border-radius:4px;background:#0a0620;border:1px solid #4a3e8a}.fw-mpips i.on{background:#2ac87a;border-color:#1b1024}
.fw-mu button{height:40px;padding:0 12px;border-radius:11px;border:2px solid #1b1024;background:linear-gradient(180deg,#ffe27a,#f2b631);color:#3a2006;font:800 14px var(--ui);box-shadow:0 3px 0 #9a6a10;display:flex;align-items:center;cursor:pointer}.fw-mu button:disabled{background:#3a3260;color:#a8a0d0;box-shadow:none;cursor:not-allowed}.fw-mmax{font:800 13px var(--ui);color:#ffd45a;padding:0 8px}
.fw-sub{position:absolute;left:66px;top:92px;margin:0;font:600 15px var(--ui);color:#cfc6ee}
.fw-bench{position:absolute;left:64px;right:64px;top:124px;height:282px;border-radius:22px;border:3px solid #1b1024;background:repeating-linear-gradient(180deg,#0000 0 56px,#00000038 56px 59px),repeating-linear-gradient(90deg,#ffffff06 0 3px,#00000008 3px 9px),linear-gradient(180deg,#6e4632,#3e2618);box-shadow:inset 0 0 0 3px #8a5a3a,inset 0 0 0 5px #e6b93e44,0 18px 40px #000a}
.fw-bench::before{content:'';position:absolute;left:14px;top:14px;width:880px;bottom:14px;border-radius:16px;background:radial-gradient(70% 80% at 45% 50%,#2e2470,#150e3c 75%);border:2px solid #1b1024;box-shadow:inset 0 0 30px #000a}
.fw-bench.tierup::before{animation:fwTier 1.1s ease-out}@keyframes fwTier{0%{opacity:.4}25%{opacity:1}}
.fw-bench canvas#fswrod{position:absolute;left:14px;top:12px;width:880px;height:260px}
.fw-pvtag{position:absolute;left:30px;top:24px;display:flex;align-items:center;gap:10px;padding:4px 6px 4px 12px;border-radius:10px;background:#0a0620cc;border:1.5px solid #ffffff22;font:700 13px var(--ui);color:#ffe9a0}.fw-pvtag button{height:28px;padding:0 10px;border-radius:8px;border:none;background:#ffd45a;color:#3a2006;font:800 12px var(--ui);cursor:pointer}
.fw-info{position:absolute;left:916px;right:22px;top:18px;bottom:16px;display:flex;flex-direction:column;gap:4px}
.fw-name{font:400 44px/1 'Pirata One',Georgia,serif;color:#ffe9a0;text-shadow:0 3px 0 #1b1024}.fw-lvl{font:600 14px var(--ui);color:#f0dcc0}.fw-lvl b{color:#fff}
.fw-track{display:flex;gap:3px;margin-top:4px}.fw-track i{flex:1;height:12px;border-radius:3px;background:#1b1024aa;border:1.5px solid #1b1024}.fw-track i.on{background:linear-gradient(180deg,#ffe27a,#e6a82a)}.fw-track i.tk{margin-right:7px;position:relative}.fw-track i.tk::after{content:'';position:absolute;right:-8px;top:-4px;width:8px;height:8px;background:#ffd45a;border:1.5px solid #1b1024;transform:rotate(45deg)}
.fw-next{font:600 13.5px var(--ui);color:#f0dcc0}.fw-next b{color:#ffe9a0}
.fw-tiers{display:grid;grid-template-columns:repeat(5,1fr);gap:6px;margin-top:auto}
.fw-tiers button{display:flex;flex-direction:column;align-items:center;gap:0;padding:4px 2px 5px;border-radius:12px;border:2px solid #1b1024;background:#1b1024aa;color:#fff;cursor:pointer;transition:transform .15s var(--sp)}
.fw-tiers button:hover{transform:translateY(-2px)}.fw-tiers canvas{width:100%;height:auto}.fw-tiers em{font:800 12px var(--ui);font-style:normal}.fw-tiers small{font:600 10.5px var(--ui);color:#cfc6ee}
.fw-tiers button.lk{opacity:.8}.fw-tiers button.cur small{color:#9affc8}.fw-tiers button.pv{border-color:#ffd45a;background:#3a2a1acc;box-shadow:0 0 0 2px #ffd45a55}
.fw-col{position:absolute;left:64px;width:716px;top:418px;bottom:14px}.fw-col.r{left:812px;width:724px}.fw-col .fssub{margin:0 2px 8px}
.fw-up{position:relative;display:grid;grid-template-columns:96px 1fr 150px;align-items:center;gap:12px;height:142px;margin-bottom:10px;padding:0 16px 0 10px;border-radius:18px;border:2px solid #3a3070;background:linear-gradient(180deg,#241c5eee,#120c34f4);box-shadow:inset 0 0 0 1px #ffffff10,0 8px 18px #0006}
.fw-up.max{border-color:#e6b93e77}.fw-up.just{animation:fwJust .7s var(--sp)}@keyframes fwJust{30%{transform:scale(1.025);border-color:#ffd45a}}.fw-up.no{animation:fwNo .35s}@keyframes fwNo{25%{transform:translateX(-6px)}75%{transform:translateX(6px)}}
.fw-ic{width:96px;height:96px}
.fw-ub{display:flex;flex-direction:column;gap:5px;min-width:0}.fw-ut{display:flex;align-items:center;gap:10px}.fw-ut b{font:800 21px var(--ui);color:#fff}.fw-lv{padding:1px 8px;border-radius:8px;background:#0a0620;border:1.5px solid var(--ring);font:800 12px var(--ui);color:var(--ring)}
.fw-pips{display:flex;gap:4px;margin-left:auto}.fw-pips i{width:24px;height:10px;border-radius:5px;background:#0a0620;border:1.5px solid #4a3e8a}.fw-pips i.on{background:linear-gradient(180deg,#9affc8,#2ac87a);border-color:#1b1024}.fw-pips i.new{animation:fwPip .6s var(--sp) .15s both}@keyframes fwPip{0%{transform:scale(.2);opacity:0}60%{transform:scale(1.5)}}
.fw-d{font:500 13.5px var(--ui);color:#c4badf}
.fw-fx{display:flex;align-items:center;gap:8px}.fw-fx span{white-space:nowrap;display:flex;flex-direction:column;padding:3px 10px;border-radius:9px;font:800 14px var(--ui)}.fw-fx small{font:700 10px var(--ui);letter-spacing:.1em;text-transform:uppercase;opacity:.75}
.fw-now{background:#0a0620;color:#d8d0f4}.fw-nx{background:#123a2a;color:#9affc8;border:1.5px solid #2ac87a66}.fw-nx.mx{background:#3a2a10;color:#ffe9a0;border-color:#e6b93e66}.fw-ar{padding:0!important;color:#9affc8;font-size:16px!important}
.fw-ex{font:500 12.5px var(--ui);color:#a8a0d0}.fw-ex b{color:#fff}.fw-ex span{color:#9affc8}
.fw-buy{display:flex;flex-direction:column;align-items:stretch;gap:5px;text-align:center}.fw-buy small{font:600 11.5px var(--ui);color:#a8a0d0}
.fw-buy button{position:relative;height:54px;border-radius:14px;border:3px solid #1b1024;background:linear-gradient(180deg,#ffe27a,#f2b631);color:#3a2006;font:800 18px var(--ui);box-shadow:0 4px 0 #9a6a10;display:flex;align-items:center;justify-content:center;gap:2px;cursor:pointer;transition:transform .12s var(--sp)}
.fw-buy button:hover:not(:disabled){transform:translateY(-2px)}.fw-buy button:active:not(:disabled){transform:translateY(2px);box-shadow:0 2px 0 #9a6a10}
.fw-buy button:disabled{background:#3a3260;color:#a8a0d0;box-shadow:0 4px 0 #1b1440;cursor:not-allowed}.fw-buy kbd{position:absolute;left:6px;top:4px;font:800 10px var(--ui);padding:0 4px;border-radius:4px;background:#00000022}
.fw-max{height:54px;display:grid;place-items:center;border-radius:14px;border:2px solid #e6b93e;background:#2a1f6e;color:#ffd45a;font:800 18px var(--ui)}
.fw-best{position:absolute;right:12px;top:-11px;padding:2px 10px;border-radius:8px;border:2px solid #1b1024;background:#9affc8;color:#0a3a20;font:800 11.5px var(--ui);letter-spacing:.04em;text-transform:uppercase}
.fw-coin{position:absolute;width:20px;height:20px;margin:-10px 0 0 -10px;border-radius:50%;background:radial-gradient(circle at 35% 35%,#fff6c0,#ffc83a 50%,#b8801a);border:2px solid #5a3a10;z-index:9;pointer-events:none;animation:fwCoin .7s cubic-bezier(.5,0,.8,.6) both}
@keyframes fwCoin{0%{transform:translate(var(--dx),var(--dy)) scale(.6);opacity:0}15%{opacity:1;transform:translate(var(--dx),calc(var(--dy) - 30px)) scale(1)}100%{transform:translate(0,0) scale(.7);opacity:.2}}
.fw-sws{display:grid;grid-template-columns:repeat(7,1fr);gap:6px}
.fw-sw{position:relative;display:flex;flex-direction:column;align-items:center;gap:2px;padding:6px 2px 6px;border-radius:14px;border:2px solid #3a3070;background:linear-gradient(180deg,#221a5aee,#100a30f2);color:#fff;cursor:pointer;transition:transform .15s var(--sp)}
.fw-sw canvas{width:100%;height:auto}.fw-sw em{font:700 11px var(--ui);font-style:normal;white-space:nowrap}.fw-sw:hover{transform:translateY(-2px)}
.fw-sw:not(.own) canvas{opacity:.5}.fw-sw.on{border-color:var(--sc);box-shadow:0 0 0 2px color-mix(in srgb,var(--sc) 45%,transparent),0 0 18px color-mix(in srgb,var(--sc) 35%,transparent)}
.fw-sw i{position:absolute;top:-7px;right:-5px;width:22px;height:22px;display:grid;place-items:center;border-radius:50%;border:2px solid #1b1024;font:900 12px var(--ui);font-style:normal}.fw-ck{background:#2ac87a;color:#fff}.fw-ex2{background:#ffd45a;color:#3a2006;animation:fsPin 1.4s ease-in-out infinite}.fw-lk{background:#2a1f6e;font-size:10px!important}
.fw-ld{margin-top:10px;height:290px;border-radius:18px;border:2px solid color-mix(in srgb,var(--sc) 55%,#3a3070);background:radial-gradient(80% 60% at 50% 0,color-mix(in srgb,var(--sc) 18%,#221a5a),#100a30 80%);padding:8px 18px 14px;display:flex;flex-direction:column;gap:6px;box-shadow:0 8px 18px #0006}
.fw-ld canvas#fwlcv{width:100%;height:auto;margin:0 -6px}.fw-lt b{display:block;font:400 32px/1 'Pirata One',Georgia,serif;color:var(--sc)}.fw-lt small{font:500 14px var(--ui);color:#d8d0f4}
.fw-rqs{display:flex;gap:8px;flex-wrap:wrap}.fw-rq{display:grid;grid-template-columns:66px auto;grid-template-rows:auto auto;column-gap:8px;align-items:center;padding:4px 10px 4px 4px;border-radius:12px;background:#0a0620aa;border:1.5px solid #ffffff1a}
.fw-rq canvas{grid-row:1/3;width:66px;height:40px}.fw-rq b{font:800 15px var(--ui);color:#ffd0a0}.fw-rq small{font:600 11px var(--ui);color:#a8a0d0}.fw-rq.ok{border-color:#2ac87a88}.fw-rq.ok b{color:#9affc8}
.fw-la{display:flex;align-items:center;gap:12px;margin-top:auto}.fw-la button{height:46px;padding:0 20px;border-radius:12px;border:3px solid #1b1024;background:linear-gradient(180deg,#ffe27a,#f2b631);color:#3a2006;font:800 16px var(--ui);box-shadow:0 4px 0 #9a6a10;cursor:pointer}.fw-la button:disabled{background:#3a3260;color:#a8a0d0;box-shadow:0 4px 0 #1b1440;cursor:not-allowed}
.fw-la small{font:500 12.5px/1.35 var(--ui);color:#a8a0d0}.fw-eq{height:42px;display:grid;place-items:center;padding:0 18px;border-radius:12px;background:#123a2a;border:2px solid #2ac87a;color:#9affc8;font:800 15px var(--ui)}`;document.head.appendChild(st)}
