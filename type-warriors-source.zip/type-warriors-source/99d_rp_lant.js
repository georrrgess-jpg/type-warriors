/* ===== RUNESTONE TOWER DEFENSE 10.2: the Phantom Lantern in battle (99d, after 99c) =====
   The fourteenth tower (key L, ground and air; UPDATE_10_2_PLAN.md section 2). Three parts:
   - Soul wisps: every RP_TW.lant.cd s it fires a ghostly wisp from the keeper in its glass at a monster in range (the Target setting:
     First, Strong, Close; rpTarget, so hidden monsters, fog and the Glowcap range follow the core's rules). The wisp homes on its target
     (a new one nearby if it dies on the way), deals RP_TW.lant.dmg and Haunts it: RP_TW.lant.haunt damage per second for RPLNB.hauntT s
     that ignores armor (rpHurt with ap 99). A haunt refreshes; it does not stack from one lantern, and with several lanterns the
     strongest one applies (a weaker haunt never replaces a stronger one that is still running).
   - Soul harvest: a monster that dies within a lantern's range (killed by any tower; a leak is not a death) sends its soul flying to that
     lantern (every lantern in range gets one, as long as its jar is not full); the soul jar fills (tw.souls / RP_TW.lant.souls).
   - Phantom Host: with a full jar, and a ground monster on the road ahead, the crypt door opens and a phantom knight rises and marches the
     wrong way down the road: from the road point nearest the lantern (the road with the most ground monsters coming, within range)
     toward the spawn at RPLNB.walk px/s along the road itself (bridges and curves included), cutting every ground monster it passes
     through once (RP_TW.lant.ph, ignores armor) until its will (RP_TW.lant.will monsters) is spent or after RPLNB.life s, then it fades.
     Flyers are passed under, hidden monsters (dive, leap, glimmer) are not touched, a monster on a road that only crosses the phantom's
     road (another direction) is not cut.
   Tier 3 Grave Chill: phantoms chill the monsters they cut (RPLNB.chill slower for RPLNB.chillT s; never on top of a stronger slow, not
   while slow-immune) and wisps jump on to a second monster within RPLNB.jumpR px (RPLNB.jumpK damage, the haunt too). Tier 4 Spectral
   Legion: two phantoms per release (the second follows on the next best road, or on the same one a moment later). Tier 5 The Reaper:
   every RPLNB.reapN-th release is the Reaper (with a knight): bigger, wider cuts (RPLNB.reapK damage, RPLNB.reapW will); a non-boss it
   leaves below RPLNB.reapExec of its health is finished, bosses take RPLNB.reapBoss times the cut.
   Overcharge: wisps come RPT.AB.over.k times faster and hit 15% harder, haunts and phantoms released then 15% harder. A jam (tw.jam)
   stops wisps and releases (phantoms already out keep marching, souls still fly in). Fog: wisps aim only at fogged monsters within
   map.fogNear px (98p's veil). Glowcaps: the range is x tw.glowK (or tw.rangeK) for wisps, the harvest and the phantom's start.
   Drawing: R.lite / Performance mode draw no trails and no phantom echoes; reduced motion (R.rm) drops trails, echoes and sparkles.
   State on the tower: tw.souls, tw.inc (souls on the way), tw.rel (releases), tw.ready, tw.door (0..1), tw.dOp (door timer), tw.jarK,
   tw.swk / tw.swv (lantern sway spring), tw.fire, tw.cd, tw.relCd.  Monster: e.lnH (haunt dps), e.lnT (s left), e.lnS (its lantern).
   On RPX: lnWisps, lnSouls, lnPh (phantoms), lnFx; counters lnShots, lnHits, lnJumps, lnSoulN, lnPhN, lnCuts, lnReapN, lnFin. */
RP_TW.lant={cost:[450,300,560,1050,1750],range:[220,232,245,258,270],dmg:[80,115,162,230,330],cd:[1,.95,.9,.85,.8],haunt:[18,26,38,54,78],
 souls:[6,6,6,5,5],ph:[95,140,200,280,400],will:[4,5,6,7,9],legion:[1,1,1,2,2],ap:[0,0,0,0,0],air:1,ground:1,
 desc:'Soul wisps home on monsters, ground or air, and Haunt them: damage over time through armor. Souls of monsters that fall nearby raise phantom knights that march back down the road.',
 up:['Brighter wisps, a stronger haunt and a sturdier phantom.','Grave Chill: phantoms chill the monsters they cut (30% slower) and wisps jump to a second monster.','Spectral Legion: two phantoms rise from every release.','The Reaper: every third release is the Reaper, who finishes monsters left below 15% health and hits bosses three times as hard.']};
RP_TWORDER.push('lant');RP_KEYS.push('L');
const RPLNB={hauntT:3,wspd:290,turn:5,wlife:2.6,jumpR:150,jumpK:.7,walk:70,life:8,rise:.75,fade:.6,hitR:28,hitRR:42,chill:.3,chillT:2,reapN:3,reapExec:.15,reapBoss:3,reapK:1.6,reapW:1.5,
 legionGap:.9,relCd:1.4,ovK:1.15,par:.7,f:0};
const rplnK=()=>{try{return typeof RPG!=='undefined'&&!RPG.off?RPG.k:1}catch(e){return 1}};
const rplnMs=()=>{try{return RPC.mob||1}catch(e){return 1}};
/* the lantern's reach: its tier's range x tw.rangeK, x the Glowcap bonus (tw.glowK) */
function rplnRange(R,tw){return RP_TW.lant.range[tw.tier-1]*(tw.rangeK||1)*(tw.glowK>1?tw.glowK:1)}
/* world positions of the keeper (where wisps leave and souls arrive) and of the crypt door */
function rplnGlassW(tw){const q=rplnGlass(tw.tier),K=rplnK();return{x:tw.x+q.x*K,y:tw.y+q.y*K}}
function rplnDoorW(tw){const q=rplnDoorP(tw.tier),K=rplnK();return{x:tw.x+q.x*K,y:tw.y+q.y*K,h:q.h*K}}
/* the point wisps aim at: the middle of the monster's body */
function rplnBody(R,e){const q=rpPos(R,e),M=RPMOB[e.id]||{h:50,w:40},s=rplnMs(),l=e.air?(M.lift||38)*s:0;return{x:q.x,y:q.y-l-M.h*s*.5,w:(M.w||40)*s,top:l+M.h*s}}
const rplnCan=e=>!!e&&!e.dead&&e.s>=0&&!e.hide;
function rplnSfx(k){try{const n=performance.now();
 if(k==='wisp'){if(n-(RPLNB.f||0)<70)return;RPLNB.f=n;beep(620+Math.random()*80,.09,'sine',.04);setTimeout(()=>beep(930,.07,'sine',.03),40)}
 else if(k==='hit'){if(Math.random()<.5)return;beep(360+Math.random()*60,.07,'triangle',.04)}
 else if(k==='soul'){[880,1175].forEach((f,j)=>setTimeout(()=>beep(f,.08,'sine',.035),j*50))}
 else if(k==='rise'){beep(220,.4,'sine',.08);setTimeout(()=>beep(330,.35,'triangle',.06),80);setTimeout(()=>beep(165,.5,'sine',.06),160)}
 else if(k==='cut'){beep(1300+Math.random()*200,.05,'sawtooth',.03);setTimeout(()=>beep(500,.06,'triangle',.04),25)}
 else if(k==='reap'){beep(110,.4,'sawtooth',.1);setTimeout(()=>beep(880,.2,'sine',.06),60)}
 else if(k==='reaper'){[196,147,110].forEach((f,j)=>setTimeout(()=>beep(f,.3,'sawtooth',.07),j*90))}}catch(e){}}
{const s0=rpSfx;rpSfx=function(k,v){if(typeof k==='string'&&k.slice(0,2)==='ln')return rplnSfx(k.slice(2).toLowerCase());return s0.apply(this,arguments)}}
/* ---------- haunt and chill ---------- */
function rplnHaunt(e,dps,tw){if(!e||e.dead||!(dps>0))return;if(!(e.lnT>0)||dps>=(e.lnH||0)-1e-9){e.lnH=dps;e.lnS=tw;e.lnT=RPLNB.hauntT}}
function rplnChill(e){if(!e||e.dead||e.air||e.vent>0)return;const k=RPLNB.chill;if(e.slowT>0&&e.slowK>k)return;e.slowK=k;e.slowT=Math.max(e.slowT>0&&e.slowK===k?e.slowT:0,RPLNB.chillT)}
/* ---------- wisps ---------- */
function rplnLaunch(R,tw,e,dmg,hd,from,jump){const o=from||rplnGlassW(tw),B=rplnBody(R,e),dx=B.x-o.x,dy=B.y-o.y,d=Math.hypot(dx,dy)||1,sp=RPLNB.wspd*(from?.8:.55),side=Math.random()<.5?-1:1;
 R.lnWisps.push({x:o.x,y:o.y,vx:dx/d*sp-dy/d*sp*.6*side,vy:dy/d*sp+dx/d*sp*.6*side-(from?0:sp*.5),e,tw,dmg,hd,tier:tw.tier,t:0,jump:!!jump,tr:[],tt:0,fade:0,a:Math.atan2(dy,dx),ph:Math.random()*9});
 if(R.lnWisps.length>80)R.lnWisps.shift();R.lnShots=(R.lnShots||0)+1}
function rplnWispHit(R,w,e){const tw=w.tw;rpHurt(e,w.dmg,0,tw);if(!e.dead)rplnHaunt(e,w.hd,tw);R.lnHits=(R.lnHits||0)+1;tw.nv=(tw.nv||0)+1;
 R.lnFx.push({k:'hit',x:w.x,y:w.y,t:0,d:.4,tier:w.tier});if(R.lnFx.length>60)R.lnFx.shift();rplnSfx('hit');
 /* tier 3+: the wisp jumps on to a second monster */
 if(tw.tier>=3&&!w.jump){const q=rpPos(R,e);let best=null,bd=RPLNB.jumpR*RPLNB.jumpR;for(const f of R.foes){if(f===e||!rplnCan(f))continue;const p=rpPos(R,f),d=rpD2(p.x,p.y,q.x,q.y);if(d<bd){bd=d;best=f}}
  if(best){rplnLaunch(R,tw,best,w.dmg*RPLNB.jumpK,w.hd,{x:w.x,y:w.y},1);R.lnJumps=(R.lnJumps||0)+1}}}
function rplnWispStep(R,dt){for(const w of R.lnWisps){w.t+=dt;if(w.fade>0){w.fade+=dt;continue}
  let e=w.e;if(!rplnCan(e)){/* the target is gone: find another one close by, or fizzle out */let best=null,bd=140*140;for(const f of R.foes){if(!rplnCan(f))continue;const B=rplnBody(R,f),d=(B.x-w.x)**2+(B.y-w.y)**2;if(d<bd){bd=d;best=f}}w.e=e=best}
  if(!e||w.t>RPLNB.wlife){w.fade=dt;continue}
  const B=rplnBody(R,e),dx=B.x-w.x,dy=B.y-w.y,d=Math.hypot(dx,dy)||1,sp=RPLNB.wspd*(1+Math.min(1,w.t*1.5)*.5),k=Math.min(1,dt*RPLNB.turn*(1+w.t*3));
  w.vx+=(dx/d*sp-w.vx)*k;w.vy+=(dy/d*sp-w.vy)*k;w.x+=w.vx*dt;w.y+=w.vy*dt;w.a=Math.atan2(w.vy,w.vx);
  if(Math.hypot(B.x-w.x,B.y-w.y)<10+B.w*.25){w.done=1;rplnWispHit(R,w,e);continue}
  if(!R.lite&&!R.rm){w.tt-=dt;if(w.tt<=0){w.tt=.03;w.tr.unshift(w.x,w.y);if(w.tr.length>12)w.tr.length=12}}}
 R.lnWisps=R.lnWisps.filter(w=>!w.done&&!(w.fade>.3))}
/* ---------- souls ---------- */
function rplnHarvest(R,e){const q=rpPos(R,e),M=RPMOB[e.id]||{h:50},y=q.y-(e.air?50:M.h*rplnMs()*.5);
 for(const p of R.pads){const tw=p.tw;if(!tw||tw.type!=='lant'||tw.build<1)continue;const rg=rplnRange(R,tw);if(rpD2(q.x,q.y,tw.x,tw.y)>rg*rg)continue;
  const need=RP_TW.lant.souls[tw.tier-1];if((tw.souls||0)+(tw.inc||0)>=need)continue;tw.inc=(tw.inc||0)+1;const g=rplnGlassW(tw),d=Math.hypot(g.x-q.x,g.y-y);
  R.lnSouls.push({x0:q.x,y0:y,x:q.x,y:y,tw,t:0,d:.55+d/420,seed:Math.random()*9,side:Math.random()<.5?-1:1,tr:[],tt:0});if(R.lnSouls.length>60){const o=R.lnSouls.shift();if(o.tw)o.tw.inc=Math.max(0,(o.tw.inc||0)-1)}}}
function rplnSoulStep(R,dt){for(const s of R.lnSouls){s.t+=dt;const tw=s.tw,alive=tw&&tw.pad&&tw.pad.tw===tw;if(!alive){s.gone=(s.gone||0)+dt;if(s.gone>.4)s.done=1;continue}
  const g=rplnGlassW(tw),u=Math.min(1,s.t/s.d),e=u*u*(3-2*u),dx=g.x-s.x0,dy=g.y-s.y0,d=Math.hypot(dx,dy)||1,nx=-dy/d,ny=dx/d,sw=Math.sin(u*Math.PI)*Math.min(70,d*.35)*s.side,sp=Math.sin(u*Math.PI*3+s.seed)*10*(1-u);
  s.x=s.x0+dx*e+nx*(sw+sp);s.y=s.y0+dy*e+ny*(sw+sp)-Math.sin(u*Math.PI)*28;
  if(!R.lite&&!R.rm){s.tt-=dt;if(s.tt<=0){s.tt=.035;s.tr.unshift(s.x,s.y);if(s.tr.length>10)s.tr.length=10}}
  if(u>=1){s.done=1;tw.inc=Math.max(0,(tw.inc||0)-1);const need=RP_TW.lant.souls[tw.tier-1];tw.souls=Math.min(need,(tw.souls||0)+1);tw.flare=1;R.lnSoulN=(R.lnSoulN||0)+1;
   R.lnFx.push({k:'soul',x:g.x,y:g.y,t:0,d:.45,tier:tw.tier});if(!R.rm)rplnSfx('soul')}}
 R.lnSouls=R.lnSouls.filter(s=>!s.done)}
/* ---------- phantoms ---------- */
/* where a phantom would start: for every road, its point nearest the lantern (within range) and the ground monsters coming along it */
function rplnPlan(R,tw,any){const rg=rplnRange(R,tw),reach=RPLNB.walk*RPLNB.life,out=[];
 R.G.paths.forEach((P,pi)=>{const S=P.S;let bi=-1,bd=1e18;for(let i=0;i<S.length;i++){const d=rpD2(S[i].x,S[i].y,tw.x,tw.y);if(d<bd){bd=d;bi=i}}if(bi<0||bd>rg*rg)return;const s=bi*4;
  let n=0;if(!any)for(const e of R.foes){if(!rplnCan(e)||e.air||(e.pi||0)!==pi)continue;if(e.s<s+6&&e.s>s-reach)n+=e.boss?3:1}
  out.push({pi,s,x:S[bi].x,y:S[bi].y,n,d:Math.sqrt(bd)})});
 out.sort((a,b)=>(b.n*10-b.d/50)-(a.n*10-a.d/50));return any?out:out.filter(o=>o.n>0)}
function rplnSpawn(R,tw,plan,kind,wait){const T=RP_TW.lant,i=tw.tier-1,reap=kind==='reaper',ov=tw.over>0?RPLNB.ovK:1,D=rplnDoorW(tw);
 const ph={pi:plan.pi,s:plan.s,x:D.x,y:D.y,x0:D.x,y0:D.y,h:0,tw,tier:tw.tier,kind,st:'rise',t:0,wait:wait||0,life:0,will:Math.round(T.will[i]*(reap?RPLNB.reapW:1)),
  dmg:T.ph[i]*ov*(reap?RPLNB.reapK:1),hit:new Set(),dir:plan.x<D.x?-1:1,sw:0,tr:[],tt:0,a:0,cut:0};
 R.lnPh.push(ph);if(R.lnPh.length>24)R.lnPh.shift();return ph}
function rplnRelease(R,tw){const T=RP_TW.lant,i=tw.tier-1,need=T.souls[i];tw.ready=(tw.souls||0)>=need;if(!tw.ready||tw.relCd>0)return false;
 const L=rplnPlan(R,tw);if(!L.length)return false;
 tw.souls-=need;tw.rel=(tw.rel||0)+1;tw.relCd=RPLNB.relCd;tw.dOp=1.4;tw.ready=tw.souls>=need;
 const reap=tw.tier>=5&&tw.rel%RPLNB.reapN===0;rplnSpawn(R,tw,L[0],reap?'reaper':'knight',0);
 if(T.legion[i]>1){/* the second phantom takes another road if one starts somewhere else in range, else it follows the first */const o=L.find(q=>q!==L[0]&&Math.hypot(q.x-L[0].x,q.y-L[0].y)>60);rplnSpawn(R,tw,o||L[0],'knight',RPLNB.legionGap)}
 R.lnPhN=(R.lnPhN||0)+1;if(reap){R.lnReapN=(R.lnReapN||0)+1;rpText(tw.x,tw.y-rpTowerTop('lant',tw.tier)-16,'THE REAPER!','#e8fff8',22);rplnSfx('reaper')}else rplnSfx('rise');
 return true}
function rplnCut(R,ph,f){const tw=ph.tw,reap=ph.kind==='reaper';ph.hit.add(f);ph.will--;ph.sw=1;ph.cut++;R.lnCuts=(R.lnCuts||0)+1;
 const q=rpPos(R,f),M=RPMOB[f.id]||{h:50},fl=f.fl;rpHurt(f,ph.dmg*(reap&&f.boss?RPLNB.reapBoss:1),99,tw);
 if(!f.dead&&ph.tier>=3)rplnChill(f);
 if(reap&&!f.dead&&!f.boss&&f.hp<=RPLNB.reapExec*f.mx){rpKillFoe(f,tw);if(f.dead){R.lnFin=(R.lnFin||0)+1;rpText(q.x,q.y-50,'REAPED!','#e8fff8',18);rplnSfx('reap')}}
 R.lnFx.push({k:'slash',x:q.x,y:q.y-M.h*rplnMs()*.45,t:0,d:.32,tier:ph.tier,dir:ph.dir,big:reap});if(R.lnFx.length>60)R.lnFx.shift();
 if(!R.rm)rplnSfx('cut')}
function rplnPhStep(R,dt){const G=R.G;
 for(const ph of R.lnPh){if(ph.wait>0){ph.wait-=dt;if(ph.wait<=0){const D=rplnDoorW(ph.tw);ph.x0=ph.x=D.x;ph.y0=ph.y=D.y;if(ph.tw.pad&&ph.tw.pad.tw===ph.tw)ph.tw.dOp=Math.max(ph.tw.dOp||0,1)}continue}
  ph.t+=dt;ph.sw=Math.max(0,ph.sw-dt*3.2);
  if(ph.st==='rise'){const p=rpAt(G,ph.s,ph.pi),u=Math.min(1,ph.t/RPLNB.rise),e=u*u*(3-2*u);ph.x=ph.x0+(p.x-ph.x0)*e;ph.y=ph.y0+(p.y-ph.y0)*e;ph.h=Math.sin(u*Math.PI)*34+ (1-u)*0;
   if(Math.abs(p.x-ph.x0)>4)ph.dir=p.x<ph.x0?-1:1;if(u>=1){ph.st='march';ph.t=0;ph.h=0}continue}
  if(ph.st==='march'){ph.life+=dt;ph.s=Math.max(0,ph.s-RPLNB.walk*dt);const p=rpAt(G,ph.s,ph.pi),b=rpAt(G,Math.max(0,ph.s-10),ph.pi);ph.x=p.x;ph.y=p.y;ph.a=p.a;
   if(Math.abs(b.x-p.x)>1.5)ph.dir=b.x<p.x?-1:1;
   /* cut the ground monsters it walks through (each once) */
   const r=ph.kind==='reaper'?RPLNB.hitRR:RPLNB.hitR,r2=r*r;
   for(const f of R.foes){if(ph.will<=0)break;if(!rplnCan(f)||f.air||ph.hit.has(f))continue;const q=rpPos(R,f);if(rpD2(q.x,q.y,p.x,p.y)>r2)continue;
    if((f.pi||0)!==ph.pi&&Math.abs(Math.cos(q.a-p.a))<RPLNB.par)continue;/* another road crossing this one */
    rplnCut(R,ph,f)}
   if(!R.lite&&!R.rm){ph.tt-=dt;if(ph.tt<=0){ph.tt=.07;ph.tr.unshift(ph.x,ph.y);if(ph.tr.length>6)ph.tr.length=6}}
   if(ph.will<=0||ph.life>=RPLNB.life||ph.s<=0){ph.st='fade';ph.t=0;try{ptBurst(R.fx,ph.x,ph.y-30,R.lite?3:9,[rplnGh(ph.tier).l,rplnGh(ph.tier).w],{v:90,s:2.6,up:1})}catch(x){}}
   continue}
  if(ph.st==='fade'&&ph.t>=RPLNB.fade)ph.done=1}
 R.lnPh=R.lnPh.filter(p=>!p.done)}
/* ---------- the tower ---------- */
function rplnFire(R,tw,dt){const T=RP_TW.lant,i=tw.tier-1,ov=tw.over>0;tw.over=Math.max(0,(tw.over||0)-dt);tw._lnS=R.time;
 tw.cd=(tw.cd||0)-dt*(ov?RPT.AB.over.k:1);tw.relCd=Math.max(0,(tw.relCd||0)-dt);
 if(tw.cd<=0){const e=rplnPick(R,tw);
  if(e){const k=ov?RPLNB.ovK:1;tw.cd=T.cd[i];tw.fire=1;rplnLaunch(R,tw,e,T.dmg[i]*k,T.haunt[i]*k);const q=rpPos(R,e);tw.aim=Math.atan2(q.y-tw.y,q.x-tw.x);tw.swv=(tw.swv||0)+(q.x<tw.x?.9:-.9);rplnSfx('wisp')}
  else tw.cd=.1}
 rplnRelease(R,tw)}
/* the wisp's target: the Target setting (First, Strong, Close) among the monsters in range; First and Close prefer a monster this lantern's
   haunt is not already on (or about to be: a wisp on its way), so one lantern keeps several monsters haunted; Strong stays on the toughest.
   Hidden and fogged monsters are veiled by 98p around the fire routine (s < 0); the core's rpTarget rules otherwise. */
function rplnPick(R,tw){const rg=rplnRange(R,tw),r2=rg*rg,hd=RP_TW.lant.haunt[tw.tier-1],pr=tw.prio||'first',fl=new Set();for(const w of R.lnWisps)if(w.tw===tw&&w.fade<=0&&w.e)fl.add(w.e);
 let best=null,bv=-1e18;for(const e of R.foes){if(e.dead||e.s<0||e.hide)continue;const q=rpPos(R,e),d2=rpD2(q.x,q.y,tw.x,tw.y);if(d2>r2)continue;
  let v=pr==='strong'?e.hp:pr==='close'?-d2:e.s/rpLen(R,e);if(pr!=='strong'&&(fl.has(e)||e.lnT>1&&(e.lnH||0)>=hd*.99))v-=1e9;if(v>bv){bv=v;best=e}}return best}
/* every step, for every lantern (jammed or not): the door, the jar, the sway, the souls it waits for */
function rplnTowerStep(R,tw,dt){const T=RP_TW.lant,need=T.souls[tw.tier-1];tw.fire=Math.max(0,(tw.fire||0)-dt*2.6);tw.flare=Math.max(0,(tw.flare||0)-dt*3);
 if(tw._lnS!==R.time)tw.relCd=Math.max(0,(tw.relCd||0)-dt);
 tw.ready=(tw.souls||0)>=need;tw.dOp=Math.max(0,(tw.dOp||0)-dt);const u=1.4-tw.dOp;tw.door=tw.dOp>0?(u<.2?u/.2:tw.dOp<.45?tw.dOp/.45:1):0;
 tw.jarK=(tw.jarK||0)+(Math.min(1,(tw.souls||0)/need)-(tw.jarK||0))*Math.min(1,dt*5);
 tw.swv=(tw.swv||0)+(-38*(tw.swk||0)-3.2*(tw.swv||0))*dt;tw.swk=Math.max(-.35,Math.min(.35,(tw.swk||0)+tw.swv*dt))}
function rplnAfter(R,dt){if(!R.lnWisps)return;
 for(const e of R.foes){if(!(e.lnT>0))continue;if(e.dead){e.lnT=0;continue}const d=Math.min(dt,e.lnT);e.lnT-=dt;if(e.hide)continue;const fl=e.fl;rpHurt(e,e.lnH*d,99,e.lnS);if(!e.dead)e.fl=fl}
 rplnWispStep(R,dt);rplnSoulStep(R,dt);rplnPhStep(R,dt);
 for(const f of R.lnFx)f.t+=dt;R.lnFx=R.lnFx.filter(f=>f.t<f.d);
 for(const p of R.pads){const tw=p.tw;if(!tw||tw.type!=='lant')continue;if(tw.build<1)continue;rplnTowerStep(R,tw,dt)}}
/* ---------- hooks ---------- */
/* fire: the core's jam rule (98b) and the hidden / fog veil (98p) applied here, since this wrapper comes after theirs */
{const f0=rpFire;rpFire=function(R,tw,dt){if(!tw||tw.type!=='lant')return f0.apply(this,arguments);
 if(tw.jamImm>0)tw.jamImm-=dt;
 if(tw.jam>0){tw.jam=Math.max(0,tw.jam-dt);if(tw.jam===0)tw.jamImm=typeof RPWK!=='undefined'?RPWK.jamImm:4;tw.jamT=(tw.jamT||0)+dt;tw.over=Math.max(0,(tw.over||0)-dt);return}
 if(typeof rpiaVeil==='function'&&!(typeof RPIA!=='undefined'&&RPIA.off))return rpiaVeil(R,tw,true,()=>rplnFire(R,tw,dt));return rplnFire(R,tw,dt)}}
try{RPIA.fogT.lant=1}catch(e){}
{const s0=rpStart;rpStart=function(){const r=s0.apply(this,arguments);if(RPX)Object.assign(RPX,{lnWisps:[],lnSouls:[],lnPh:[],lnFx:[],lnShots:0,lnHits:0,lnJumps:0,lnSoulN:0,lnPhN:0,lnCuts:0,lnReapN:0,lnFin:0});return r}}
{const s0=rpStep;rpStep=function(R,dt){const r=s0.apply(this,arguments);try{rplnAfter(R,dt)}catch(e){console.error(e)}return r}}
{const k0=rpKillFoe;rpKillFoe=function(e,src){const was=!e||e.dead;const r=k0.apply(this,arguments);try{const R=RPX;if(!was&&e.dead&&!e.leak&&R&&R.lnSouls)rplnHarvest(R,e)}catch(x){console.error(x)}return r}}
{const b0=rpBuild;rpBuild=function(pad,type){const r=b0.apply(this,arguments);try{if(r!==false&&type==='lant'&&pad&&pad.tw&&pad.tw.type==='lant')Object.assign(pad.tw,{souls:0,inc:0,rel:0,ready:false,door:0,dOp:0,jarK:0,swk:0,swv:0,relCd:0,cd:.3})}catch(e){}return r}}
{const u0=rpUpgrade;rpUpgrade=function(tw){const r=u0.apply(this,arguments);if(r&&tw&&tw.type==='lant'){const n=RP_TW.lant.souls[tw.tier-1];tw.souls=Math.min(n,tw.souls||0)}return r}}
/* ---------- drawing ---------- */
const rplnPhPos=ph=>({x:ph.x,y:ph.y-(ph.h||0)});
function rplnPhAlpha(ph){if(ph.st==='rise')return Math.min(1,ph.t/RPLNB.rise*1.6)*.9;if(ph.st==='fade')return Math.max(0,1-ph.t/RPLNB.fade)*.9;return .9}
function rplnDrawPh(c,R,ph){if(ph.wait>0)return;const p=rplnPhPos(ph),a=rplnPhAlpha(ph),reap=ph.kind==='reaper',t=R.t+ph.s*.01;
 let sc=1;if(ph.st==='rise')sc=.45+.55*Math.min(1,ph.t/RPLNB.rise);else if(ph.st==='fade')sc=1+.15*ph.t/RPLNB.fade;const y=p.y-(ph.st==='fade'?ph.t*30:0);
 /* the ghost trail: faded copies at the last few positions */
 if(ph.tr.length>=4&&ph.st==='march'&&!R.lite&&!R.rm){const S=reap?rplnReaperS(ph.tier):rplnKnightS(ph.tier),n=ph.tr.length/2;for(let k=n-1;k>=1;k--){c.save();c.globalAlpha=a*.22*(1-k/n);c.translate(ph.tr[k*2],ph.tr[k*2+1]-4);const z=reap?RPLN_RS:RPLN_KS;c.scale(ph.dir<0?-z:z,z);rpPut(c,S);c.restore()}c.globalAlpha=1}
 c.save();c.translate(p.x,y);c.scale(sc,sc);if(reap)rplnReaper(c,0,0,ph.dir,ph.tier,t,a,ph.sw);else rplnKnight(c,0,0,ph.dir,ph.tier,t,a,ph.sw);c.restore();c.globalAlpha=1}
{const a0=rpAmbient;rpAmbient=function(c,R){const r=a0.apply(this,arguments);try{if(R&&R.lnPh){
 for(const ph of R.lnPh){if(ph.wait>0)continue;rplnShadow(c,ph.x,ph.y+2,ph.kind==='reaper'?1.5:1,rplnPhAlpha(ph)*(ph.st==='rise'?.5:1))}
 /* a selected lantern shows where its phantoms would rise onto the road */
 const s=R.sel;if(s&&s.type==='lant'&&s.build>=1){if(!s._pvT||R.t-s._pvT>.3||R.t<s._pvT){s._pvT=R.t;s._pv=rplnPlan(R,s,1)[0]||null}const P=s._pv;
  if(P){const G=rplnGh(s.tier),k=.55+.25*Math.sin(R.t*4);c.save();c.globalAlpha=k;c.setLineDash([5,6]);c.lineDashOffset=R.t*18;c.lineWidth=2.2;c.strokeStyle=G.l;c.beginPath();c.ellipse(P.x,P.y,20,20*RPFX.sq,0,0,TAU);c.stroke();c.setLineDash([]);
   const b=rpAt(R.G,Math.max(0,P.s-36),P.pi);c.lineWidth=3;c.beginPath();c.moveTo(P.x,P.y);c.lineTo(b.x,b.y);c.stroke();const an=Math.atan2(b.y-P.y,b.x-P.x);c.beginPath();c.moveTo(b.x+Math.cos(an)*6,b.y+Math.sin(an)*6);c.lineTo(b.x+Math.cos(an+2.5)*8,b.y+Math.sin(an+2.5)*8);c.lineTo(b.x+Math.cos(an-2.5)*8,b.y+Math.sin(an-2.5)*8);c.closePath();c.fillStyle=G.l;c.fill();c.restore()}}}}catch(e){console.error(e)}return r}}
{const b0=rpBeamsDraw;rpBeamsDraw=function(c,R){b0.apply(this,arguments);if(!R.lnWisps)return;try{
 /* rising columns at crypt doors while a phantom climbs out */
 for(const ph of R.lnPh){if(ph.st!=='rise'||ph.wait>0)continue;const u=ph.t/RPLNB.rise,G=rplnGh(ph.tier);c.globalCompositeOperation='lighter';rpGlow(c,ph.x0,ph.y0-16,22,30,G.m,(1-u)*.9);c.globalCompositeOperation='source-over';c.globalAlpha=1}
 for(const ph of R.lnPh.length>1?R.lnPh.slice().sort((a,b)=>a.y-b.y):R.lnPh)rplnDrawPh(c,R,ph);
 /* trails of wisps and souls in one pass */
 if(!R.lite&&!R.rm){c.globalCompositeOperation='lighter';for(const w of R.lnWisps){const D=rplnDotS(w.tier).c,n=w.tr.length/2;for(let k=1;k<n;k++){const z=8*(1-k/n)+2;c.globalAlpha=(1-k/n)*.8*(w.fade>0?1-w.fade/.3:1);c.drawImage(D,w.tr[k*2]-z,w.tr[k*2+1]-z,z*2,z*2)}}
  for(const s of R.lnSouls){const D=rplnDotS(s.tw?s.tw.tier:1).c,n=s.tr.length/2;for(let k=1;k<n;k++){const z=6*(1-k/n)+1.5;c.globalAlpha=(1-k/n)*.7;c.drawImage(D,s.tr[k*2]-z,s.tr[k*2+1]-z,z*2,z*2)}}
  c.globalCompositeOperation='source-over';c.globalAlpha=1}
 for(const s of R.lnSouls)rplnSoulDraw(c,s.x,s.y,s.tw?s.tw.tier:1,R.t+s.seed,s.gone?Math.max(0,1-s.gone/.4):Math.min(1,s.t*5));
 for(const w of R.lnWisps)rplnWisp(c,w.x,w.y,w.a,w.tier,R.t+w.ph,w.jump?.85:1,w.fade>0?Math.max(0,1-w.fade/.3):Math.min(1,.4+w.t*6));
 for(const f of R.lnFx){const u=f.t/f.d;if(f.k==='slash')rplnSlash(c,f.x,f.y,u,f.tier,f.dir,f.big);else if(f.k==='soul'){c.globalCompositeOperation='lighter';rpGlow(c,f.x,f.y,14+20*u,14+20*u,rplnGh(f.tier).w,(1-u)*.9);c.globalCompositeOperation='source-over';c.globalAlpha=1}
  else if(!R.rm||u<.5)rplnBurst(c,f.x,f.y,u,f.tier)}}catch(e){console.error(e)}}}
/* the tower being drawn: its door, jar and sway follow the battle */
{const t0=rpTowerAt;rpTowerAt=function(c,R,tw){if(!tw||tw.type!=='lant')return t0.apply(this,arguments);RPLN.cur=tw;try{return t0.apply(this,arguments)}finally{RPLN.cur=null}}}
/* a haunted monster: a ghost-light ring at its feet and wisps rising off it */
{const f0=rpFoeDraw;rpFoeDraw=function(c,R,e,q){const r=f0.apply(this,arguments);if(e&&!e.dead&&e.lnT>0&&q)try{const M=RPMOB[e.id]||{w:40},w=(M.w||40)*rplnMs();
  rplnHauntDraw(c,q.x,q.y,w,Math.min(1,e.lnT*2)*(R.rm?.6:1),R.rm?0:R.t+(e.ph||0)*7,e.lnS?e.lnS.tier:1)}catch(x){}return r}}
/* ---------- the info panel ---------- */
{const i0=rpInfoBuild;rpInfoBuild=function(R,tw,el){const r=i0.apply(this,arguments);if(tw.type!=='lant')return r;try{const T=RP_TW.lant,i=tw.tier-1,top=RP_MAXT(R.map),nx=tw.tier<top?tw.tier:null;
  const seg=(v,max)=>Math.max(0,Math.min(6,Math.round(v/max*6))),bar=(lab,v,max,nv)=>`<div class="rpst"><span>${lab}</span><i>${[0,1,2,3,4,5].map(k=>`<s class="${k<seg(v,max)?'on':nv!=null&&k<seg(nv,max)?'up':''}"></s>`).join('')}</i></div>`;
  const wd=j=>Math.sqrt((T.dmg[j]+T.haunt[j]*RPLNB.hauntT*.6)/T.cd[j]),pd=j=>Math.sqrt(T.ph[j]*T.will[j]*T.legion[j]/T.souls[j]);
  const st=el.querySelector('.rpsts');if(st)st.innerHTML=bar('Range',T.range[i],320,nx!=null?T.range[nx]:null)+bar('Wisp damage',wd(i),wd(4),nx!=null?wd(nx):null)+bar('Phantom',pd(i),pd(4),nx!=null?pd(nx):null)+bar('Fire rate',1/T.cd[i],1/.85,nx!=null?1/T.cd[nx]:null);
  const need=T.souls[i],ex=[`haunt <b>${T.haunt[i]}/s</b> for ${RPLNB.hauntT} s, ignores armor`,`souls <b id="rplnsl">${Math.min(need,tw.souls||0)} / ${need}</b>`,`phantom <b>${T.ph[i]}</b> to <b>${T.will[i]}</b> monsters`];
  if(tw.tier>=3)ex.push(`Grave Chill <b>-${Math.round(RPLNB.chill*100)}%</b>, wisps jump`);if(T.legion[i]>1)ex.push(`<b>${T.legion[i]}</b> phantoms a release`);if(tw.tier>=5)ex.push(`the Reaper every <b>${RPLNB.reapN}</b> releases`);
  if(st)st.insertAdjacentHTML('afterend',`<div class="rplnx">${ex.join(' · ')}</div>`);
  const hgt=el.offsetHeight||420;el.style.top=rpClamp(tw.y-hgt*.62,76,770-hgt)+'px'}catch(e){console.error(e)}return r}}
/* the soul count updates live */
{const h0=rpHudInfo;rpHudInfo=function(R,C){const r=h0.apply(this,arguments);try{const tw=R&&R.sel;if(tw&&tw.type==='lant'){const el=document.getElementById('rplnsl');if(el){const need=RP_TW.lant.souls[tw.tier-1],t=`${Math.min(need,tw.souls||0)} / ${need}`;if(el.textContent!==t)el.textContent=t;el.classList.toggle('on',(tw.souls||0)>=need)}}}catch(e){}return r}}
{const st=document.createElement('style');st.textContent=`.rplnx{margin:6px 0 2px;font:600 12px Poppins,system-ui,sans-serif;color:#dffff4;line-height:1.35}.rplnx b{color:#7dffd8}.rplnx b.on{color:#ffffff;text-shadow:0 0 6px #5af0c8}`;document.head.appendChild(st)}
/* key L picks it (letters belong to Rune Typing while it is on) */
{const k0=rpKeyDown;window.removeEventListener('keydown',rpKeyDown,true);rpKeyDown=function(e){const R=RPX;if(R&&S.rp&&S.mode==='ramparts'&&!R.pause&&!R.over&&!(R.ty&&R.ty.on)&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&e.key.length===1&&e.key.toLowerCase()==='l'){e.preventDefault();e.stopImmediatePropagation();if(!e.repeat)rpPlace('lant');return}return k0.apply(this,arguments)};window.addEventListener('keydown',rpKeyDown,true)}
/* help, How to Play, mastery skins */
try{const h=HELP.Modes.find(x=>x[0]==='Runestone Tower Defense');if(h)h[1]+=" The Phantom Lantern (L, 450 supply) fires soul wisps that haunt monsters, ground or air, with damage that ignores armor; the souls of monsters that fall near it fill its jar, and a full jar sends a phantom knight down the road the wrong way to cut the monsters coming."}catch(e){}
{const h0=rpHowTo;rpHowTo=function(){const r=h0.apply(this,arguments);try{const w=ov.querySelector('#rpmod .rphw');if(w)w.insertAdjacentHTML('beforeend',`<p><b>Phantom Lantern.</b> A haunting tower (${rpCost('lant',1)} supply, key L), ground and air. Its keeper fires soul wisps that home on monsters and Haunt them: damage over time that ignores armor (the strongest haunt applies, they do not stack). Every monster that falls in its range, whoever beat it, sends its soul into the lantern's jar; when the jar is full a phantom knight rises from the crypt and marches the wrong way down the road, cutting each ground monster it meets until its will is spent. Flyers pass over it. Tier 3 phantoms chill what they cut and wisps jump to a second monster, tier 4 sends two phantoms at a time, and at tier 5 every third release is the Reaper, who finishes monsters left below 15% health.</p>`)}catch(e){}return r}}
try{RPY_SET.lant=[['toxic','Bog Light Lantern'],['inferno','Hellfire Lantern'],['glacier','Frostwake Lantern'],['amethyst','Amethyst Lantern'],['aurora','Aurora Lantern']]}catch(e){}
/* 97k's particles: the ghost motes take the tier's colour */
{const p0=rpgParts;rpgParts=function(g,type,tier){if(type!=='lant')return p0.apply(this,arguments);const P=RPG_PAR.lant,c0=P.c,G=rplnGh(tier);P.c=[G.l,G.m];try{return p0.apply(this,arguments)}finally{P.c=c0}}}
