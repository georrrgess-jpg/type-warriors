# python3 t_look102.py [game.html] [-v] : animation and look checks for the two 10.2 towers, the Moonblade Sentinel (99a/99b) and the Phantom
# Lantern (99c/99d). Frames are sampled at 60 fps from real battles (rpStep 1/60 then rpDraw) with the drawing calls recorded where they
# land on the stage (the canvas transform at the call), so the numbers are what a player sees:
#  - Moonblade: the held and flying glaives move without jumps through the wind-up, release, flight, catch and recoil at every tier (a
#    release or catch may not move a glaive further than a normal flight step), the arms turn without snaps, the single-glaive statue keeps
#    one throwing hand, glaives come back into the hand, the eclipse and the wake move and fade smoothly;
#  - Lantern: wisps leave the keeper and move smoothly, souls end in the lantern, phantoms rise from the crypt door, march on the road
#    (never off it), fade out, swing their swords and scythes without snaps, Legion and the Reaper appear;
#  - both: no sprite baked in the middle of a fight after warm-up (cache misses), no blank or flickering frames, depth order (phantoms are
#    drawn behind the towers and monsters in front of them and in front of those behind, on four maps), the build and upgrade animations,
#    the five mastery skins (also on what the towers throw and raise), Performance mode / lite / reduced motion (less drawn, the same
#    damage), and frame cost (each tower, and a busy battle with six of each at tier 5).
# Screenshots: shots/w102_review/look/.
import asyncio,os,sys,math,json
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
_A=[a for a in sys.argv[1:] if not a.startswith('-')]
H='file://'+os.path.abspath(_A[0] if _A else os.path.join(HERE,'out.html'))
SHOT=os.path.join(HERE,'shots','w102_review','look');os.makedirs(SHOT,exist_ok=True)
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('  '+str(info)[:600] if (not ok or '-v' in sys.argv) else ''),flush=True)
    if not ok:FAIL.append(name)
HELP=r"""()=>{
 window.tdBuild=(R,p,t,tier)=>{rpBuild(p,t);const tw=p.tw;tw.build=1;while(tw.tier<(tier||1)&&rpUpgrade(tw));tw.upK=1;return tw};
 window.tdNew=(map,wave)=>{try{rpLeave()}catch(e){}rpStart(map);const R=RPX;R.tut=null;R.hold=false;R.supply=1e9;R.wst='run';R.wave=wave||1;R.q=[];R.banner=null;R.toast=null;R.foes=[];R.cd=999;
  if(R.cannon)R.cannon.t=1e9;if(R.gust)R.gust.t=1e9;if(R.rodK){R.boltT=1e9;R.boltTwT=1e9}return R};
 window.tdFoe=(R,id,s,pi)=>{const e=rpSpawn(id,pi||0);e.s=s;e._s=-1;e.sp=0;e.off=0;return e};
 window.tdTank=(e,hp)=>{e.hp=e.mx=hp||1e6;e.armor=e.arm0=0;return e};
 window.tdNear=(R,pad,pi)=>{let best=0,bd=1e9;const L=R.G.paths[pi||0].len;for(let s=0;s<L;s+=4){const q=rpAt(R.G,s,pi||0),d=Math.hypot(q.x-pad.x,q.y-pad.y);if(d<bd){bd=d;best=s}}return best};
 window.tdPad=(R)=>{let best=null,bd=1e9;for(const p of R.pads){const s=tdNear(R,p,0),q=rpAt(R.G,s,0),d=Math.hypot(q.x-p.x,q.y-p.y);if(d>70&&d<bd&&p.x>250&&p.x<1350){bd=d;best=p}}return best};
 window.tdAt=(R,tw,lo,hi,pi)=>{const L=R.G.paths[pi||0].len;for(let s=10;s<L-10;s+=3){const q=rpAt(R.G,s,pi||0),d=Math.sqrt(rpD2(q.x,q.y,tw.x,tw.y));if(d>lo&&d<hi)return s}return null};
 window.tdFrame=(R)=>{rpStep(R,1/60);R.t+=1/60;R.banner=null;R.tx=[];R.toast=null;REC.list=[];REC.arms=[];REC.ph=[];REC.wi=[];REC.so=[];REC.ord=[];rpDraw()};
 /* the recorder: where each glaive / phantom / wisp / soul lands on the stage */
 window.REC={on:0,list:[],arms:[],ph:[],wi:[],so:[],ord:[],live:0};
 const sp=(g,x,y)=>{const m=g.getTransform(),p=m.transformPoint({x,y});return{x:p.x/RS,y:p.y/RS,k:Math.hypot(m.a,m.b)/RS}};
 {const f0=rpmbBlade;rpmbBlade=function(g,x,y,tier,rot,sy,sc,a){if(REC.on){const p=sp(g,x,y);REC.list.push({live:REC.live,tw:REC.tw,x:p.x,y:p.y,s:(sc||1)*p.k,sy:sy==null?1:sy})}return f0.apply(this,arguments)}}
 {const f0=rpmbLive;rpmbLive=function(){REC.live=1;REC.tw=RPMB_ART.cur;try{return f0.apply(this,arguments)}finally{REC.live=0;REC.tw=null}}}
 /* (the 10.2 build before the review had no rpmbArmAt: the arm angle came from rpmbArmA directly, so the test can be run on it too) */
 if(typeof rpmbArmAt==='function'){const f0=rpmbArmAt;rpmbArmAt=function(tw,side){const a=f0.apply(this,arguments);if(REC.on&&REC.live)REC.arms.push({tw,side,ang:a});return a}}
 else{const f0=rpmbArmA;rpmbArmA=function(tw,side){const a=f0.apply(this,arguments);if(REC.on&&REC.live)REC.arms.push({tw,side,ang:a});return a}}
 if(typeof rplnSwing!=='function')window.rplnSwing=(sw,b,f)=>{const s=sw||0;return s>0?(s>.5?-1.1+(1-s)*2.4:-1.1*s*2):0};
 if(typeof rpmbSkG!=='function')window.rpmbSkG=c=>c;if(typeof rplnSkG!=='function')window.rplnSkG=c=>c;
 {const f0=rplnDrawPh;rplnDrawPh=function(c,R,ph){if(REC.on&&!(ph.wait>0))REC.ord.push({k:'ph',y:ph.y,x:ph.x,o:ph});return f0.apply(this,arguments)}}
 /* towers and monsters are logged after they are drawn (a phantom drawn just before them inside the call comes first) */
 {const f0=rpTowerAt;rpTowerAt=function(c,R,tw){const r=f0.apply(this,arguments);if(REC.on&&tw&&c===ctx)REC.ord.push({k:'tw',y:tw.y,x:tw.x,o:tw});return r}}
 {const f0=rpFoeDraw;rpFoeDraw=function(c,R,e,q){const r=f0.apply(this,arguments);if(REC.on&&e&&q&&!e.air&&!e.dead&&c===ctx)REC.ord.push({k:'foe',y:q.y,x:q.x,o:e});return r}}
 {const f0=rplnKnight;rplnKnight=function(g,x,y,dir,tier,t,al,sw){if(REC.on){const p=sp(g,x,y);REC.ph.push({k:'kn',x:p.x,y:p.y,al,sw:sw||0})}return f0.apply(this,arguments)}}
 {const f0=rplnReaper;rplnReaper=function(g,x,y,dir,tier,t,al,sw){if(REC.on){const p=sp(g,x,y);REC.ph.push({k:'rp',x:p.x,y:p.y,al,sw:sw||0})}return f0.apply(this,arguments)}}
 return 1}"""
SETUP="()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const r=RPP();r.new99j=1;r.dragon=1;r.stars=Object.assign(r.stars||{},{moss:3,frost:3,ember:3,coral:3,wreck:3,abyss:3,meadow:3,foundry:3});for(const k in r.tut)r.tut[k]=1;for(const k of['build','wave','coins','upgrade','abil','rune','twist','twist_frost','twist_ember','twist_wonder'])r.tut[k]=1;save()}"
# one throw cycle per tier: per frame the drawn glaives (held / flying), arm angles; 260 frames (about two throws)
MOONCYC=r"""([m,tier,side])=>{const R=tdNew(m,3),pad=tdPad(R),tw=tdBuild(R,pad,'moon',tier),rg=RP_TW.moon.range[tier-1];
 const mk=s=>{const e=tdTank(tdFoe(R,'golem',s));e.sp=14;return e};
 if(side==='both'){/* monsters on both sides of the statue: the single-glaive statue must keep one hand */let a=null,b=null;const L=R.G.paths[0].len;
   for(let s=10;s<L-10;s+=3){const q=rpAt(R.G,s,0),d=Math.sqrt(rpD2(q.x,q.y,tw.x,tw.y));if(d<rg*.8&&d>rg*.3){if(q.x<tw.x-30&&a==null)a=s;if(q.x>tw.x+30&&b==null)b=s}}
   if(a!=null)mk(a);if(b!=null)mk(b);tw.prio='close'}else mk(tdAt(R,tw,rg*.5,rg*.6));
 const F=[];REC.on=1;for(let f=0;f<260;f++){tdFrame(R);F.push({w:tw.mbW||0,out:tw.mbOut||0,bl:REC.list.filter(b=>!b.live||b.tw===tw).map(b=>[b.live,+b.x.toFixed(1),+b.y.toFixed(1),+b.s.toFixed(3),+b.sy.toFixed(3)]),
  arms:REC.arms.filter(a=>a.tw===tw).map(a=>+a.ang.toFixed(3)),gl:R.mbGl.map(g=>[g.slot,g.u])})}REC.on=0;
 const H=[0,1,2].map(sl=>{const p=rpmbHandW(tw,sl,RPMB_A.hold);return[p.x,p.y-p.h]});return {F,tx:tw.x,throws:R.mbThrows,H}}"""
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await br.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        pg.on('console',lambda m:er.append('console: '+m.text[:300]) if m.type=='error' and 'WebSocket' not in m.text and 'net::' not in m.text else None)
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E(SETUP);await E(HELP)
        # ================= Moonblade =================
        worst={'jump':0,'rel':0,'cat':0,'scale':0,'arm':0,'step':0};per={}
        for (m,t) in (('moss',1),('moss',2),('moss',3),('wonder',4),('wonder',5)):
            r=await E(MOONCYC,[m,t,'one']);F=r['F'];j=rel=cat=sc=arm=step=0;nrel=ncat=0
            for i in range(1,len(F)):
                a,b=F[i-1]['bl'],F[i]['bl']
                if a and b and len(a)==len(b):
                    for q in b:
                        d,o=min((math.hypot(q[1]-o[1],q[2]-o[2]),o) for o in a)
                        j=max(j,d);sc=max(sc,abs(q[3]-o[3]))
                        if not q[0] and not o[0]:step=max(step,d)
                    dd=lambda q,L:min([math.hypot(q[1]-o[1],q[2]-o[2]) for o in L] or [1e9])
                    ha=[x for x in a if x[0]];fa=[x for x in a if not x[0]]
                    for q in b:
                        if not q[0] and ha and dd(q,ha)<dd(q,fa):nrel+=1;rel=max(rel,dd(q,ha))   # a glaive that has just left a hand
                        if q[0] and fa and dd(q,fa)<dd(q,ha):ncat+=1;cat=max(cat,dd(q,fa))     # a glaive that has just been caught
                if F[i]['arms'] and len(F[i]['arms'])==len(F[i-1]['arms']):arm=max(arm,max(abs(x-y) for x,y in zip(F[i]['arms'],F[i-1]['arms'])))
            per[t]=dict(throws=r['throws'],rel=round(rel,1),cat=round(cat,1),jump=round(j,1),step=round(step,1),scale=round(sc,3),arm=round(arm,3),nrel=nrel,ncat=ncat)
            for k in worst:worst[k]=max(worst[k],per[t][k])
        print('   Moonblade per tier:',json.dumps(per))
        chk('Moonblade: at every tier the statue throws and catches (at least two throws in 4.3 s)',all(v['throws']>=2 and v['ncat']>=1 for v in per.values()),per)
        chk(f"Moonblade release: the glaive leaves the hand where it was held (largest jump at a release {worst['rel']:.0f} px, at most 20; it was 46-57 px)",worst['rel']<=20,per)
        chk(f"Moonblade catch: the glaive lands in the hand (largest jump at a catch {worst['cat']:.0f} px, at most 20; it was 15-29 px)",worst['cat']<=20,per)
        chk(f"Moonblade: no glaive moves more than 2.5 flight steps in a frame ({worst['jump']:.0f} px vs flight step {worst['step']:.0f} px) and no size pop (largest {worst['scale']:.2f}/frame, at most 0.2; it was 0.35)",
            worst['jump']<=max(30,2.5*worst['step']) and worst['scale']<=.2,per)
        chk(f"Moonblade: the arms turn without snapping (largest turn {worst['arm']:.2f} rad/frame, at most 0.6: the forward swing of the throw; the catch snapped 0.8, a hand swap 2.0)",worst['arm']<=.6,per)
        r=await E(MOONCYC,['moss',1,'both']);F=r['F'];tx=r['tx'];sides=[];hj=0;aj=0
        for i,f in enumerate(F):
            h=[x for x in f['bl'] if x[0]]
            if h:
                sides.append(1 if h[0][1]>tx else -1)
                if i and [x for x in F[i-1]['bl'] if x[0]]:o=[x for x in F[i-1]['bl'] if x[0]][0];hj=max(hj,math.hypot(h[0][1]-o[1],h[0][2]-o[2]))
            if i and len(f['arms'])==len(F[i-1]['arms']):aj=max(aj,max(abs(x-y) for x,y in zip(f['arms'],F[i-1]['arms'])))
        flips=sum(1 for i in range(1,len(sides)) if sides[i]!=sides[i-1])
        chk(f"Moonblade tiers 1-2: with monsters on both sides the statue passes the glaive to the other hand over the helm (largest step of the held glaive {hj:.0f} px a frame, at most 20; it jumped 80 px) and the arms trade poses without snapping ({aj:.2f} rad a frame)",
            flips>=1 and hj<=20 and aj<=.6 and r['throws']>=2,[flips,round(hj,1),round(aj,3),r['throws']])
        r=await E("""()=>{const out=[];for(const [m,t] of [['moss',1],['moss',3],['wonder',5]]){const R=tdNew(m,3),pad=tdPad(R),tw=tdBuild(R,pad,'moon',t),rg=RP_TW.moon.range[t-1];const e=tdTank(tdFoe(R,'golem',tdAt(R,tw,rg*.5,rg*.6)));
           let worst=0,n=0;const C=rpmbCatch;rpmbCatch=function(R,gl){const H=rpmbHandW(gl.tw,gl.slot,RPMB_A.hold);worst=Math.max(worst,Math.hypot(gl.X-H.x,gl.Y*RPFX.sq-(H.y)));n++;return C.apply(this,arguments)};
           try{for(let i=0;i<300;i++)rpStep(R,1/60)}finally{rpmbCatch=C}out.push([n,+worst.toFixed(2)])}return out}""")
        chk('Moonblade: every glaive comes back to its hand (the catch point is the hand, within 3 px, at tiers 1, 3 and 5)',all(x[0]>=2 and x[1]<=3 for x in r),r)
        # the eclipse and the wake: smooth motion and fades
        r=await E("""()=>{const R=tdNew('wonder',30),pad=tdPad(R),tw=tdBuild(R,pad,'moon',5),rg=RP_TW.moon.range[4];for(let k=0;k<6;k++)tdTank(tdFoe(R,'golem',tdAt(R,tw,rg*.4,rg*.6)+k*30)).sp=20;tw.nv=4;
          let prev=null,step=0,dk=0,n=0,wk=0,wkd=0,on=1;const seen=new Map();for(let f=0;f<420;f++){rpStep(R,1/60);R.t+=1/60;
           for(const E of R.mbEcl){const P=rpmbEclPos(R,E),k=Math.min(1,E.t/.25,(E.d-E.t)/.3);if(prev&&prev.E===E){step=Math.max(step,Math.hypot(P.X-prev.x,(P.Y-prev.y)*RPFX.sq));dk=Math.max(dk,Math.abs(k-prev.k))}prev={E,x:P.X,y:P.Y,k};n++}
           for(const w of R.mbWake){const k=Math.min(1,w.t*8,(w.d-w.t)/.5),o=seen.get(w);if(o!=null)wkd=Math.max(wkd,Math.abs(k-o));seen.set(w,k);if(!rpmbRoad(R,w.x,w.y))on=0;wk++}}
          return [R.mbEclN,n,+step.toFixed(1),+dk.toFixed(3),wk>0,+wkd.toFixed(3),on]}""")
        chk('Moonblade tier 5 Eclipse circles smoothly (at most 15 px a frame) and fades in and out (alpha steps at most 0.15); the tier 4-5 wake marks lie on the road and fade smoothly',
            r[0]>=1 and r[1]>60 and r[2]<=15 and r[3]<=.15 and r[4] and r[5]<=.15 and r[6]==1,r)
        # ================= Lantern =================
        LCYC=r"""([m,tier,n])=>{const R=tdNew(m,30),pad=tdPad(R),tw=tdBuild(R,pad,'lant',tier),rg=RP_TW.lant.range[tier-1];const s=tdAt(R,tw,rg*.3,rg*.5);if(tier>=5)tw.rel=2;
          for(let k=0;k<20;k++){const e=tdFoe(R,'scamp',s-150-k*40);e.hp=e.mx=50;e.sp=55}for(let k=0;k<12;k++){const e=tdTank(tdFoe(R,'golem',s+240+k*28),3e4);e.sp=25}
          const W=new Map(),S=new Map(),P=new Map();let wstep=0,wfirst=0,sstep=0,send=0,pstep=0,pal=0,proad=0,prise=0,pflip=0,nrise=0,fadeEnd=1,nsoul=0,nw=0,maxPh=0,reap=0;
          const door=rplnDoorW(tw),glass=()=>rplnGlassW(tw);
          for(let f=0;f<n;f++){rpStep(R,1/60);R.t+=1/60;maxPh=Math.max(maxPh,R.lnPh.filter(p=>!(p.wait>0)).length);if(R.lnPh.some(p=>p.kind==='reaper'))reap=1;
           for(const w of R.lnWisps){const o=W.get(w);if(o){wstep=Math.max(wstep,Math.hypot(w.x-o.x,w.y-o.y))}else if(!w.jump){nw++;const g=glass();wfirst=Math.max(wfirst,Math.hypot(w.x-g.x,w.y-g.y)-RPLNB.wspd*.6/60*1.3)}W.set(w,{x:w.x,y:w.y})}
           for(const s of R.lnSouls){const o=S.get(s);if(o)sstep=Math.max(sstep,Math.hypot(s.x-o.x,s.y-o.y));S.set(s,{x:s.x,y:s.y,t:s.t,d:s.d})}
           for(const [s,o] of S)if(!R.lnSouls.includes(s)){if(o.t+1/60>=o.d){const g=glass();send=Math.max(send,Math.hypot(o.x-g.x,o.y-g.y));nsoul++}S.delete(s)}
           for(const p of R.lnPh){if(p.wait>0)continue;const o=P.get(p),a=rplnPhAlpha(p);
            if(!o){nrise++;prise=Math.max(prise,Math.hypot(p.x0-door.x,p.y0-door.y))}else{pstep=Math.max(pstep,Math.hypot(p.x-o.x,(p.y-p.h)-(o.y-o.h)));pal=Math.max(pal,Math.abs(a-o.a));if(p.dir!==o.dir&&f-o.flip<10)pflip++}
            if(p.st==='march'){const q=rpAt(R.G,p.s,p.pi);proad=Math.max(proad,Math.hypot(q.x-p.x,q.y-p.y))}
            P.set(p,{x:p.x,y:p.y,h:p.h||0,a,dir:p.dir,flip:o&&p.dir!==o.dir?f:(o?o.flip:-99),st:p.st})}
           for(const [p,o] of P)if(!R.lnPh.includes(p)){if(o.st!=='fade'||o.a>.08)fadeEnd=Math.min(fadeEnd,0);P.delete(p)}}
          return {nw,wstep:+wstep.toFixed(1),wfirst:+wfirst.toFixed(1),nsoul,sstep:+sstep.toFixed(1),send:+send.toFixed(1),nrise,prise:+prise.toFixed(1),pstep:+pstep.toFixed(1),pal:+pal.toFixed(3),proad:+proad.toFixed(2),pflip,fadeEnd,maxPh,reap,cuts:R.lnCuts,rel:R.lnPhN}}"""
        res={}
        for (m,t,n) in (('moss',3,1500),('coral',4,1500),('wonder',5,2400)):
            res[f'{m}{t}']=await E(LCYC,[m,t,n])
        print('   Lantern:',json.dumps(res))
        V=list(res.values())
        chk('Lantern: wisps leave the keeper in the glass and fly smoothly (at most 12 px a frame)',all(v['nw']>=5 and v['wfirst']<=3 and v['wstep']<=12 for v in V),res)
        chk('Lantern: souls fly smoothly (at most 15 px a frame) and end in the lantern (the frame before they arrive within 8 px of the keeper)',all(v['nsoul']>=3 and v['sstep']<=15 and v['send']<=8 for v in V),res)
        chk('Lantern: phantoms rise from the crypt door, move smoothly (at most 5 px a frame), never leave the road while they march, do not flicker between directions and fade out before they vanish',
            all(v['nrise']>=1 and v['prise']<=3 and v['pstep']<=5 and v['proad']<=.5 and v['pflip']==0 and v['fadeEnd']==1 and v['pal']<=.1 for v in V),res)
        chk('Lantern: tier 4 Spectral Legion shows two phantoms at once; tier 5 sends the Reaper',res['coral4']['maxPh']>=2 and res['wonder5']['reap']==1,res)
        # sword and scythe: the swing as drawn, through real cuts (restarts included)
        r=await E("""()=>{const R=tdNew('moss',30),pad=tdPad(R),tw=tdBuild(R,pad,'lant',3),rg=RP_TW.lant.range[2];const s=tdAt(R,tw,rg*.3,rg*.5);for(let k=0;k<30;k++){const e=tdTank(tdFoe(R,'golem',s-100-k*16),2e4);e.sp=30}tw.souls=6;
          const A=new Map();let worst=0,cuts=0,n=0;const ang=(k,sw)=>k==='rp'?-.35+rplnSwing(sw,.4,.95):-.25+rplnSwing(sw,.45,1);REC.on=1;
          for(let f=0;f<900;f++){rpStep(R,1/60);R.t+=1/60;for(const p of R.lnPh){if(p.wait>0)continue;const a=ang(p.kind==='reaper'?'rp':'kn',p.sw),o=A.get(p);if(o!=null){worst=Math.max(worst,Math.abs(a-o));n++}A.set(p,a)}}REC.on=0;
          const curve=[];for(let i=0;i<=20;i++)curve.push(+rplnSwing(1-i/20,.45,1).toFixed(2));return [R.lnCuts,n,+worst.toFixed(3),curve[0],curve[20],Math.min(...curve),Math.max(...curve)]}""")
        chk(f"Lantern: phantom swords and the Reaper's scythe swing without snaps through real cuts (largest turn {r[2]} rad/frame, at most 0.35; the old curve snapped about 1.1 rad mid-swing); a swing starts and ends at the guard",
            r[0]>=3 and r[1]>100 and r[2]<=.35 and r[3]==0 and r[4]==0 and r[5]<-.3 and r[6]>.7,r)
        # ================= both =================
        # cache misses and blank frames: warm up, then a fight with every tier and every skin; sprites baked after the first half second
        r=await E("""()=>{const R=tdNew('wonder',30);const pads=[...R.pads].sort((a,b)=>a.x-b.x);const sk=['base','m1','m2','m3','m4','m5'];let i=0;const T=[];
          for(const ty of ['moon','lant'])for(let t=1;t<=5;t++){const p=pads[i++];if(!p)break;const tw=tdBuild(R,p,ty,t);tw.skin=sk[(t+(ty==='lant'?2:0))%6];rpTowerWarm(ty,t,tw.skin);if(ty==='lant')tw.souls=5;T.push(tw)}
          for(let k=0;k<50;k++){const e=tdTank(tdFoe(R,k%5?'golem':'gloom',40+k*30,k%2),4000);e.sp=35}
          let rc=0,on=0;const i0=rpyImg;rpyImg=function(T,img){if(on&&T&&img){const M=RPY_IC.get(img);if(!M||!M.get(T.id)){const k=NM.get(img);if(k&&/^(mb\\||ln\\|)/.test(k))rc++}}return i0.apply(this,arguments)};const NM=new Map();for(const [k,v] of RPSPR)NM.set(v.c,k);const own=k=>/^(mb\\||ln\\||tw\\|(moon|lant)\\|)/.test(k);const keys=()=>[...RPSPR.keys()].filter(own).length;let k0=0,ic0=0,miss=[],cov=new Map();
          const cv=document.createElement('canvas');cv.width=200;cv.height=230;const g=cv.getContext('2d');
          for(let f=0;f<600;f++){rpStep(R,1/60);R.t+=1/60;rpDraw();if(f===30){k0=keys();on=1;for(const [k,v] of RPSPR)NM.set(v.c,k)}
           if(f>=30&&f%3===0){for(const tw of T){g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,200,230);g.translate(100-tw.x,190-tw.y);rpTowerAt(g,R,tw);const d=g.getImageData(0,0,200,230).data;let n=0;for(let j=3;j<d.length;j+=16)if(d[j]>40)n++;
             (cov.get(tw)||cov.set(tw,[]).get(tw)).push(n)}}}
          const med=a=>{const s=[...a].sort((x,y)=>x-y);return s[s.length>>1]};const blank=T.map(tw=>{const a=cov.get(tw);return +(Math.min(...a)/med(a)).toFixed(3)});
          rpyImg=i0;const nk=[...RPSPR.keys()].filter(own).length;return [k0,nk-k0,rc,blank,R.mbThrows,R.lnPhN]}""")
        chk('no flicker: after warm-up no sprite of either tower is baked or recoloured in the middle of a fight (every tier, five mastery skins; before: the door, door glow and jar of a skinned lantern)',r[1]==0 and r[2]==0 and r[4]>5 and r[5]>=1,r)
        chk('no blank or flickering frames: each tower covers at least 85% of its usual pixels in every sampled frame (throws, recoil, door, sway)',min(r[3])>=.85,r)
        # depth order on four maps: a phantom is drawn after the towers and ground monsters behind it and before those in front of it
        r=await E("""()=>{const out={};for(const m of ['moss','coral','foundry','storm']){const R=tdNew(m,30);const pads=[...R.pads];let n=0;
           for(const p of pads){const s=tdNear(R,p,0),q=rpAt(R.G,s,0);if(Math.hypot(q.x-p.x,q.y-p.y)<170&&n<5){const tw=tdBuild(R,p,'lant',4);tw.souls=6;n++}else if(n>=5&&Math.random()<.5)tdBuild(R,p,'ballista',2)}
           for(let k=0;k<60;k++){const e=tdTank(tdFoe(R,k%4?'golem':'brute',20+k*26,k%(R.G.paths.length)),3e4);e.sp=26}
           let bad=0,pairs=0,frames=0;REC.on=1;for(let f=0;f<900;f++){rpStep(R,1/60);R.t+=1/60;if(f%4)continue;REC.ord=[];rpDraw();frames++;
            const O=REC.ord;O.forEach((a,i)=>{if(a.k!=='ph')return;for(let j=0;j<O.length;j++){const b=O[j];if(b.k==='ph'||Math.abs(b.x-a.x)>70||Math.abs(b.y-a.y)>140)continue;pairs++;if((j>i&&b.y<a.y-1)||(j<i&&b.y>a.y+1))bad++}})}REC.on=0;
           out[m]=[R.lnPhN,frames,pairs,bad]}return out}""")
        chk('depth order (moss, coral, foundry, storm): phantoms are drawn behind the towers and monsters standing in front of them and in front of those behind (before: always on top)',
            all(v[0]>=1 and v[2]>20 and v[3]==0 for v in r.values()),r)
        # build and upgrade animations
        r=await E("""()=>{const R=tdNew('wonder',30);const out={};const cv=document.createElement('canvas');cv.width=240;cv.height=260;const g=cv.getContext('2d');
          const px=()=>{const d=g.getImageData(0,0,240,260).data;let n=0;for(let j=3;j<d.length;j+=8)if(d[j]>40)n++;return n};
          for(const ty of ['moon','lant']){const p=tdPad(R);const tw=tdBuild(R,p,ty,1);const seq=[];tw.build=0;for(let k=0;k<=24;k++){tw.build=k/24;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,240,260);g.translate(120-tw.x,210-tw.y);rpTowerAt(g,R,tw);seq.push(px())}
           tw.build=1;const ups=[];for(let t=2;t<=5;t++){rpUpgrade(tw);const s=[];for(let k=0;k<=12;k++){tw.upK=k/12;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,240,260);g.translate(120-tw.x,210-tw.y);rpTowerAt(g,R,tw);s.push(px())}ups.push(s)}
           const fin=seq[seq.length-1];tw.build=1;tw.upK=1;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,240,260);g.translate(120-tw.x,210-tw.y);const tt=tw.tier;
           out[ty]={grow:seq.filter((v,i)=>i>0&&v<seq[i-1]*.8).length,start:seq[0]<fin,end:fin,upMin:Math.min(...ups.map(s=>Math.min(...s)/s[s.length-1])),upLast:ups.map(s=>s[s.length-1])};rpSell(tw)}return out}""")
        chk('build animation: each tower grows in without blank frames, and every upgrade to tier 5 animates without a blank frame (at least 60% of the pixels throughout)',
            all(v['grow']==0 and v['start'] and v['upMin']>=.6 and v['upLast']==sorted(v['upLast']) for v in r.values()),r)
        # mastery skins: tower art differs per skin, and what the tower throws or raises follows the skin
        r=await E("""()=>{const out=[];for(const ty of ['moon','lant']){const urls=new Set();for(let t=1;t<=5;t++)for(const k of ['base','m1','m2','m3','m4','m5']){const c=document.createElement('canvas');c.width=c.height=200;const g=c.getContext('2d');g.translate(100,170);rpTowerDraw(g,ty,t,k,1,{});const u=c.toDataURL();let h=0;for(let i=0;i<u.length;i+=7)h=(h*31+u.charCodeAt(i))|0;urls.add(h+':'+t)}out.push(urls.size)}
          const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'moon',3);const col=sk=>{tw.skin=sk;const c=document.createElement('canvas');c.width=c.height=120;const g=c.getContext('2d');const gl={tw,tier:3,slot:0,home:0,u:.5,X:60,Y:60/RPFX.sq,h:0,h0:0,P0:{X:60,Y:60/RPFX.sq},L1:1,L2:1,v:1};rpmbBlade(rpmbSkG(g,tw),60,60,3,0,.55,1.4,1);const d=g.getImageData(0,0,120,120).data;let r=0,gg=0,b=0,n=0;for(let i=0;i<d.length;i+=4)if(d[i+3]>100){r+=d[i];gg+=d[i+1];b+=d[i+2];n++}return [r/n|0,gg/n|0,b/n|0]};
          const base=col('base'),jade=col('m1');const L=R.pads.find(p=>!p.tw);const lw=tdBuild(R,L,'lant',3);const kc=sk=>{lw.skin=sk;const c=document.createElement('canvas');c.width=c.height=120;const g=c.getContext('2d');rplnKnight(rplnSkG(g,lw),60,100,1,3,0,1,0);const d=g.getImageData(0,0,120,120).data;let r=0,gg=0,b=0,n=0;for(let i=0;i<d.length;i+=4)if(d[i+3]>100){r+=d[i];gg+=d[i+1];b+=d[i+2];n++}return [r/n|0,gg/n|0,b/n|0]};
          return [out,base,jade,kc('base'),kc('m2')]}""")
        dif=lambda a,b:sum(abs(x-y) for x,y in zip(a,b))
        chk('mastery skins: thirty distinct looks per tower (five tiers x six skins); a Jade Sentinel throws a jade glaive and a Hellfire Lantern raises a fiery knight (they kept the base colours in flight)',
            r[0]==[30,30] and dif(r[1],r[2])>40 and dif(r[3],r[4])>40,r)
        # Performance mode / lite / reduced motion
        r=await E("""()=>{const res=[];for(const [lite,rm] of [[0,0],[1,0],[0,1]]){Math.random=(()=>{let a=7;return()=>{a=(a*16807)%2147483647;return a/2147483647}})();
           const R=tdNew('moss',3),P=[...R.pads].sort((a,b)=>a.x-b.x);let i=0;const tws=[];for(const p of P){const s=tdNear(R,p,0),q=rpAt(R.G,s,0);if(Math.hypot(q.x-p.x,q.y-p.y)<170&&i<4){tws.push(tdBuild(R,p,i%2?'lant':'moon',3));i++}}
           for(let k=0;k<30;k++){const e=tdFoe(R,'golem',30+k*30);e.hp=e.mx=900;e.armor=e.arm0=0;e.sp=40}R.lite=lite;R.rm=rm;let gh=0,tr=0,sp=0,echo=0;
           const g0=rpmbGhost,s0=rpmbSpark,d0=rpPut;rpmbGhost=function(){gh++;return g0.apply(this,arguments)};rpmbSpark=function(){sp++;return s0.apply(this,arguments)};
           try{for(let f=0;f<900;f++){rpStep(R,1/60);R.t+=1/60;if(f%5===0){rpDraw();for(const w of R.lnWisps)tr+=w.tr.length;for(const p of R.lnPh)echo+=p.tr.length}}}finally{rpmbGhost=g0;rpmbSpark=s0}
           res.push([gh,sp,tr,echo,Math.round(tws.reduce((a,t)=>a+(t.rpqD||0),0))])}return res}""")
        chk('Performance mode / lite draws no glaive trails, wisp trails or phantom echoes, reduced motion no sparks either; the towers deal the same damage in every mode (within 3%: particle counts change the random draws)',
            r[0][0]>0 and r[0][2]>0 and r[0][3]>0 and r[1][0]==0 and r[1][2]==0 and r[1][3]==0 and r[2][0]==0 and r[2][1]==0 and max(x[4] for x in r)<=1.03*min(x[4] for x in r),r)
        # frame cost: each tower (in battle, with the 9.9p glow layer), against the Starfall Observatory; then a busy battle with six of each at tier 5
        r=await E("""()=>{const R=tdNew('wonder',30);const c=document.createElement('canvas');c.width=1600;c.height=900;const g=c.getContext('2d');const P=tdPad(R);
          const one=(ty)=>{const res=[];for(let t=1;t<=5;t++){if(P.tw)rpSell(P.tw);const tw=tdBuild(R,P,ty,t);rpTowerWarm(ty,t,'base');for(let k=0;k<20;k++)rpTowerAt(g,R,tw);let m=1e9;
             for(let k=0;k<9;k++){const t0=performance.now();for(let i=0;i<20;i++){R.t+=1/60;if(ty==='moon'){tw.mbW=(i%10)/10}rpTowerAt(g,R,tw)}m=Math.min(m,(performance.now()-t0)/20)}res.push(m)}return res};
          const mb=one('moon'),ln=one('lant'),sf=one('star');return [mb.map(x=>+x.toFixed(3)),ln.map(x=>+x.toFixed(3)),sf.map(x=>+x.toFixed(3))]}""")
        avg=lambda a:sum(a)/len(a);mb,ln,sf=avg(r[0]),avg(r[1]),avg(r[2])
        chk(f"frame cost per tower: Moonblade {mb:.3f} ms, Lantern {ln:.3f} ms (Starfall {sf:.3f}): under 0.15 ms, or no more than 1.25 x the Starfall Observatory when the machine is busy",
            (mb<.15 or mb<=1.25*sf) and (ln<.15 or ln<=1.25*sf),r)
        BUSY=r"""(A)=>{Math.random=(()=>{let a=11;return()=>{a=(a*16807)%2147483647;return a/2147483647}})();const R=tdNew('wonder',40);const P=[...R.pads];for(let i=0;i<12&&i<P.length;i++){const ty=A[i%2];const tw=tdBuild(R,P[i],ty,5);if(ty==='lant')tw.souls=5}
          for(let k=0;k<70;k++){const e=tdTank(tdFoe(R,k%4?'golem':'gloom',20+k*26,k%R.G.paths.length),5e4);e.sp=30}for(let f=0;f<360;f++){rpStep(R,1/60);R.t+=1/60}
          const n=[R.mbGl.length,R.mbEcl.length,R.mbWake.length,R.lnWisps.length,R.lnPh.length];let m=1e9;for(let k=0;k<12;k++){const t0=performance.now();for(let i=0;i<3;i++)rpDraw();m=Math.min(m,(performance.now()-t0)/3)}return [+m.toFixed(2),n]}"""
        B={};
        for rep_ in range(2):
            for A in (['moon','lant'],['prism','dragon'],['star','hive'],['tide','grav']):
                x=await E(BUSY,A);k='+'.join(A);B[k]=[min(B[k][0],x[0]),x[1]] if k in B else x
        old=sorted(v[0] for k,v in B.items() if k!='moon+lant');med=old[len(old)//2]
        chk(f"busy battle (twelve tier 5 towers, 70 monsters): six Sentinels and six Lanterns with their glaives, eclipses, wake, wisps and phantoms draw a frame in {B['moon+lant'][0]} ms, the older pairs {', '.join(k+' '+str(v[0]) for k,v in B.items() if k!='moon+lant')} ms: at most 1.25 x their median",
            B['moon+lant'][1][0]>=6 and B['moon+lant'][1][4]>=2 and B['moon+lant'][0]<=1.25*med,B)
        await E(BUSY,['moon','lant']);await pg.evaluate("()=>{const R=RPX;R.banner=null;R.tx=[];R.toast=null;rpDraw()}");await pg.screenshot(path=os.path.join(SHOT,'busy_battle.png'))
        chk('no page errors',not er,er[:3])
        await br.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
