/* ---------- touch / mobile support ---------- */
const TMq=window.matchMedia?matchMedia('(pointer:coarse)'):{matches:false};
let physKb=false,ovTM=false,kbShown=false;
const TM=()=>ST.touch==='on'||(ST.touch!=='off'&&TMq.matches&&!physKb);
const cn=document.getElementById('cn'),CN0=cn.getAttribute('style');
const kb=document.createElement('div');kb.id='kb';
kb.innerHTML=['qwertyuiop','asdfghjkl','zxcvbnm'].map((r,i)=>`<div class="kr r${i+1}">${[...r].map(c=>`<button data-c="${c}" tabindex="-1">${c}</button>`).join('')}</div>`).join('')
 +`<div class="kr ka"><button data-a="pause" tabindex="-1" aria-label="Pause">II</button><button data-a="drop" tabindex="-1" aria-label="Drop target">Drop</button><button class="sp" data-c=" " tabindex="-1">space</button><button class="fy" data-a="fury" id="kf" tabindex="-1"><i></i><span>Fury</span></button></div>`;
document.body.appendChild(kb);
kb.addEventListener('pointerdown',e=>{const b=e.target.closest('button');if(!b)return;e.preventDefault();ensureAudio();
 b.classList.add('dn');
 if(b.dataset.c!==undefined)key(b.dataset.c);
 else if(b.dataset.a==='fury')fury();else if(b.dataset.a==='pause')pause();else if(b.dataset.a==='drop')tabTarget()});
const kbUp=e=>{kb.querySelectorAll('.dn').forEach(b=>b.classList.remove('dn'))};
kb.addEventListener('pointerup',kbUp);kb.addEventListener('pointercancel',kbUp);kb.addEventListener('pointerleave',kbUp);
kb.addEventListener('contextmenu',e=>e.preventDefault());
addEventListener('keydown',e=>{if(!physKb&&e.isTrusted&&e.key&&e.key.length===1&&/[a-z]/i.test(e.key)&&ST.touch==='auto'&&TMq.matches){physKb=true;applyLayout()}});
const kbWant=()=>TM()&&(S.mode==='play'||(typeof tkWant==='function'&&tkWant()));/* 8.7: tkWant (94a_fix_fishing.js) adds Moonlit Fishing and Trick-or-Treat typing */
function kbH(vw,vh){return Math.round(vh>=vw?Math.min(vh*.44,330):Math.min(vh*.5,210))}
function touchLayout(vw,vh,ah,on){
 const port=vh>=vw,vwid=port?640:1000,z=vw/vwid;
 if(!ovTM){document.body.appendChild(ov);document.body.appendChild(cn);ovTM=true}
 const clear=ov.classList.contains('clear'),h=clear?ah:vh;
 ov.style.cssText=`position:fixed;left:0;top:0;right:auto;bottom:auto;inset:auto;z-index:20;zoom:${z};width:${vw/z}px;height:${h/z}px`;
 cn.style.cssText=`position:fixed;right:8px;bottom:8px;z-index:30;display:${on?'none':'flex'};gap:8px;zoom:${z}`;
 kb.classList.toggle('on',on);kb.style.height=on?kbH(vw,vh)+'px':''}
function touchOff(){if(!ovTM)return;wrap.insertBefore(ov,pb);wrap.appendChild(cn);ov.removeAttribute('style');cn.setAttribute('style',CN0);ovTM=false;kb.classList.remove('on');wrap.style.top='50%'}
function touchTick(){const w=kbWant();if(w!==kbShown){kbShown=w;applyLayout()}
 if(w){const f=kb.querySelector('#kf'),v=Math.min(100,S.fury||0);f.style.setProperty('--f',v);f.classList.toggle('rd',v>=100)}}
