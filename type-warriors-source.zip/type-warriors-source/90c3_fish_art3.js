/* ===== MOONLIT FISHING: fish art 3 (rare + legendary) =====
   moonfin, angler, ray, sun (Rare) and aurora, moonmaw, tidecrown (Legendary). Uses the fk kit from 90b.
   Private helpers are prefixed fa3_. Each fish: centred on the origin, facing right, ~200 units long. */
/* run fn in a frame rotated by a around the joint (x,y) */
function fa3_at(g,x,y,a,fn){g.save();g.translate(x,y);g.rotate(a);fn();g.restore()}
/* slight whole-body bend while thrashing on the line */
function fa3_bend(g,t,o){const f=o.flex||0;if(f)g.rotate(Math.sin(t*7.3)*.06*f)}
/* twinkle 0..1 */
const fa3_tw=(t,i,sp)=>.5+.5*Math.sin(t*(sp||3)+i*1.91);
/* ribbon outline points from a centre line fn(s)->[x,y,halfWidth] */
function fa3_rib(n,fn){const c=[];for(let i=0;i<=n;i++)c.push(fn(i/n));const L=[],R=[];
 for(let i=0;i<=n;i++){const a=c[Math.max(0,i-1)],b=c[Math.min(n,i+1)],dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy)||1,nx=-dy/d,ny=dx/d,w=c[i][2];
  L.push(c[i][0]+nx*w,c[i][1]+ny*w);R.unshift(c[i][0]-nx*w,c[i][1]-ny*w)}return L.concat(R)}
/* centre line samples only */
function fa3_line(n,fn){const c=[];for(let i=0;i<=n;i++)c.push(fn(i/n));return c}
/* rib lines radiating from (x0,y0) to targets, clipped to path */
function fa3_ribs(g,pathFn,x0,y0,tg,c,a,lw){g.save();pathFn();g.clip();g.strokeStyle=c||FKO;g.globalAlpha=a==null?.28:a;g.lineWidth=lw||1.3;
 for(let i=0;i<tg.length;i+=2){g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo((x0+tg[i])/2,(y0+tg[i+1])/2+(tg[i+1]-y0)*.08,tg[i],tg[i+1]);g.stroke()}g.restore()}
/* gill arc */
/* gill: soft shadow behind the cover, a crisp 1.7 line, a faint second slit and a light lip on the cover edge */
function fa3_gill(g,x,y0,y1,bow,a){a=a==null?.55:a;const ym=(y0+y1)/2,arc=(dx,b,s0,s1)=>{const P=(s)=>{const u=1-s;return [u*u*(x+dx)+2*u*s*(x+dx-b)+s*s*(x+dx),u*u*y0+2*u*s*ym+s*s*y1]};const p0=P(s0),pm=P((s0+s1)/2),p1=P(s1);
  g.beginPath();g.moveTo(p0[0],p0[1]);g.quadraticCurveTo(2*pm[0]-(p0[0]+p1[0])/2,2*pm[1]-(p0[1]+p1[1])/2,p1[0],p1[1])};
 g.save();g.lineCap='round';
 arc(-3,bow,.06,.94);g.strokeStyle='rgba(10,4,30,.16)';g.lineWidth=6;g.stroke();
 arc(-7,bow*.8,.22,.8);g.strokeStyle=FKO;g.globalAlpha=a*.45;g.lineWidth=1.2;g.stroke();
 arc(0,bow,0,1);g.globalAlpha=a+.15;g.lineWidth=1.7;g.stroke();
 arc(2.2,bow,.12,.82);g.globalAlpha=1;g.strokeStyle='rgba(255,255,255,.28)';g.lineWidth=1.3;g.stroke();
 g.restore();g.globalAlpha=1}
/* a small smiling mouth with an optional lip tint and a corner dimple */
function fa3_smile(g,x,y,w,c,lip){g.save();g.lineCap='round';
 if(lip){g.beginPath();g.moveTo(x-w,y-w*.25);g.quadraticCurveTo(x-w*.1,y+w*.55,x+w*.6,y-w*.3);g.quadraticCurveTo(x,y+w*1.15,x-w,y-w*.25);g.fillStyle=lip;g.fill()}
 g.beginPath();g.moveTo(x-w,y-w*.25);g.quadraticCurveTo(x-w*.1,y+w*.55,x+w*.6,y-w*.3);g.strokeStyle=c||FKO;g.lineWidth=1.9;g.stroke();
 g.beginPath();g.moveTo(x-w*1.2,y-w*.62);g.quadraticCurveTo(x-w*1.32,y-w*.18,x-w*1.0,y-w*.12);g.lineWidth=1.3;g.stroke();
 if(lip){g.beginPath();g.moveTo(x-w*.5,y+w*.5);g.quadraticCurveTo(x-w*.05,y+w*.78,x+w*.32,y+w*.3);g.strokeStyle='rgba(255,255,255,.45)';g.lineWidth=1.1;g.stroke()}
 g.restore()}
/* closed spline without starting a new path (to combine several shapes) */
function fa3_blob(g,p,cont){const n=p.length/2,mx=i=>(p[(i%n)*2]+p[((i+1)%n)*2])/2,my=i=>(p[(i%n)*2+1]+p[((i+1)%n)*2+1])/2;if(!cont)g.beginPath();g.moveTo(mx(n-1),my(n-1));for(let i=0;i<n;i++)g.quadraticCurveTo(p[i*2],p[i*2+1],mx(i),my(i));g.closePath()}
/* gem */
function fa3_gem(g,x,y,r,c){g.beginPath();g.moveTo(x,y-r);g.lineTo(x+r*.8,y);g.lineTo(x,y+r);g.lineTo(x-r*.8,y);g.closePath();fkFill(g,fkLin(g,x-r,y-r,x+r,y+r,[shade(c,.55),c,shade(c,-.35)]),1.6);
 g.beginPath();g.moveTo(x-r*.35,y-r*.2);g.lineTo(x,y-r*.62);g.strokeStyle='rgba(255,255,255,.85)';g.lineWidth=1.2;g.stroke()}
function fa3_pearl(g,x,y,r){g.beginPath();g.arc(x,y,r,0,TAU);fkFill(g,fkRad(g,x,y,r,['#ffffff','#f4ecff','#c9b8e0']),1.3);g.beginPath();g.arc(x-r*.3,y-r*.32,r*.3,0,TAU);g.fillStyle='#fff';g.fill()}
/* inner rim stroke of a path (clipped), then re-outline */
function fa3_rim(g,pf,c,lw,olw){g.save();pf();g.clip();pf();g.strokeStyle=c;g.lineWidth=lw||4;g.stroke();g.restore();if(olw!==0){pf();g.lineWidth=olw||2.4;g.strokeStyle=FKO;g.stroke()}}
/* crescent path (bulging toward -x before rotation) */
function fa3_cres(g,x,y,R,k,rot){g.save();g.translate(x,y);g.rotate(rot);g.beginPath();g.arc(0,0,R,-Math.PI/2,Math.PI/2,true);g.ellipse(0,0,R*k,R,0,Math.PI/2,Math.PI*1.5,false);g.closePath();g.restore()}
/* cubic / quadratic bezier point + tangent */
function fa3_cub(a,b,c,d,s){const u=1-s;return [u*u*u*a[0]+3*u*u*s*b[0]+3*u*s*s*c[0]+s*s*s*d[0],u*u*u*a[1]+3*u*u*s*b[1]+3*u*s*s*c[1]+s*s*s*d[1],
 3*u*u*(b[0]-a[0])+6*u*s*(c[0]-b[0])+3*s*s*(d[0]-c[0]),3*u*u*(b[1]-a[1])+6*u*s*(c[1]-b[1])+3*s*s*(d[1]-c[1])]}
function fa3_quad(a,b,c,s){const u=1-s;return [u*u*a[0]+2*u*s*b[0]+s*s*c[0],u*u*a[1]+2*u*s*b[1]+s*s*c[1],2*u*(b[0]-a[0])+2*s*(c[0]-b[0]),2*u*(b[1]-a[1])+2*s*(c[1]-b[1])]}
/* sample the fkPath spline of points p into a polyline */
function fa3_spl(p){const n=p.length/2,out=[],mx=i=>(p[(i%n)*2]+p[((i+1)%n)*2])/2,my=i=>(p[(i%n)*2+1]+p[((i+1)%n)*2+1])/2;let x0=mx(n-1),y0=my(n-1);
 for(let i=0;i<n;i++){const cx=p[i*2],cy=p[i*2+1],x1=mx(i),y1=my(i);for(let k=1;k<=8;k++){const s=k/8,u=1-s;out.push([u*u*x0+2*u*s*cx+s*s*x1,u*u*y0+2*u*s*cy+s*s*y1])}x0=x1;y0=y1}return out}
/* top (top=true) or bottom edge y of a sampled outline at x */
function fa3_edge(pts,x,top){let b=null;for(let i=0;i<pts.length;i++){const a=pts[i],c=pts[(i+1)%pts.length];if((a[0]-x)*(c[0]-x)<=0&&a[0]!==c[0]){const y=a[1]+(c[1]-a[1])*(x-a[0])/(c[0]-a[0]);if(b===null||(top?y<b:y>b))b=y}}return b==null?0:b}
/* tapered whisker along a cubic: root half-width w0 to tip w1 */
function fa3_whisk(g,a,b,c,d,w0,w1,fill,lw){const p=fa3_rib(14,s=>{const q=fa3_cub(a,b,c,d,s);return [q[0],q[1],w0+(w1-w0)*s]});fkPath(g,p);fkFill(g,fill,lw||1.5)}

/* ===== polish kit ===== */
/* '#rrggbb' + alpha -> rgba() */
function fa3_rgba(h,a){const n=parseInt(h.slice(1,7),16);return `rgba(${n>>16},${n>>8&255},${n&255},${Math.max(0,Math.min(1,a))})`}
/* rich eye: socket shade, sclera shading, gradient iris with fibres and limbal ring, pupil, lid shadow, two catch-lights + lower reflection */
function fa3_eye(g,x,y,r,iris,look,ring){look=look||0;const ix=x+r*.18+look*r*.12,iy=y+r*.05,ir=r*.62;
 g.beginPath();g.arc(x+r*.04,y+r*.1,r*1.2,0,TAU);g.fillStyle='rgba(8,3,22,.2)';g.fill();
 if(ring){g.beginPath();g.arc(x,y,r*1.16,0,TAU);g.fillStyle=ring;g.fill()}
 g.beginPath();g.arc(x,y,r,0,TAU);g.fillStyle=fkLin(g,x,y-r,x,y+r,['#ded8ec','#fffdf8','#ffffff']);g.fill();
 g.save();g.beginPath();g.arc(x,y,r,0,TAU);g.clip();
 const q=g.createRadialGradient(ix-ir*.1,iy+ir*.45,ir*.08,ix,iy,ir);q.addColorStop(0,shade(iris,.6));q.addColorStop(.5,iris);q.addColorStop(1,shade(iris,-.5));
 g.beginPath();g.arc(ix,iy,ir,0,TAU);g.fillStyle=q;g.fill();
 g.beginPath();for(let i=0;i<12;i++){const a=i*TAU/12+.13;g.moveTo(ix+Math.cos(a)*ir*.42,iy+Math.sin(a)*ir*.42);g.lineTo(ix+Math.cos(a)*ir*.86,iy+Math.sin(a)*ir*.86)}
 g.strokeStyle=fa3_rgba(shade(iris,.7),.38);g.lineWidth=Math.max(.6,r*.05);g.stroke();
 g.beginPath();g.arc(ix,iy,ir*.94,0,TAU);g.strokeStyle=fa3_rgba(shade(iris,-.65),.9);g.lineWidth=Math.max(.9,r*.1);g.stroke();
 g.beginPath();g.arc(ix+r*.04,iy+r*.03,r*.34,0,TAU);g.fillStyle='#0b0512';g.fill();
 g.beginPath();g.ellipse(x,y-r*1.02,r*1.25,r*.58,0,0,TAU);g.fillStyle='rgba(24,10,52,.24)';g.fill();
 g.beginPath();g.arc(ix,iy+r*.02,ir*.74,Math.PI*.18,Math.PI*.82);g.strokeStyle='rgba(255,255,255,.55)';g.lineWidth=Math.max(.8,r*.08);g.stroke();
 g.restore();
 g.beginPath();g.arc(x,y,r,0,TAU);g.lineWidth=Math.max(2,r*.24);g.strokeStyle=FKO;g.stroke();
 g.fillStyle='#fff';g.beginPath();g.ellipse(x+r*.36,y-r*.25,r*.26,r*.21,-.5,0,TAU);g.fill();
 g.beginPath();g.arc(x+r*.02,y+r*.04,r*.095,0,TAU);g.fill();
 g.beginPath();g.arc(x-r*.1,y+r*.42,r*.075,0,TAU);g.fillStyle='rgba(255,255,255,.75)';g.fill()}
/* soft rim light: an offset inner stroke whose alpha fades from y0 to y1 (dy>0 lights the back, dy<0 the belly) */
function fa3_rl(g,pf,y0,y1,c,a,dy,w){g.save();pf();g.clip();g.translate(0,dy);pf();const q=g.createLinearGradient(0,y0,0,y1);q.addColorStop(0,fa3_rgba(c,a));q.addColorStop(1,fa3_rgba(c,0));g.strokeStyle=q;g.lineWidth=w||3;g.stroke();g.restore()}
/* crisp specular glint: a soft-edged bar plus a tiny dot */
function fa3_glint(g,x,y,s,rot,a){g.save();g.translate(x,y);g.rotate(rot||0);g.globalAlpha=a==null?.9:a;g.fillStyle='#fff';
 g.beginPath();g.ellipse(0,0,s*1.7,s*.5,0,0,TAU);g.fill();g.beginPath();g.arc(s*2.5,s*.12,s*.4,0,TAU);g.fill();g.restore()}
/* batched fine scale arcs (one stroke call), clipped to a path */
function fa3_scl(g,pf,x0,x1,y0,y1,s,c,a,lw,dy){g.save();pf();g.clip();g.translate(0,dy||0);g.beginPath();
 for(let y=y0,r=0;y<y1;y+=s*.62,r++)for(let x=x0+(r%2?s/2:0);x<x1;x+=s){const a0=Math.PI*.15,ax=x+Math.cos(a0)*s*.52,ay=y+Math.sin(a0)*s*.52;g.moveTo(ax,ay);g.arc(x,y,s*.52,a0,Math.PI*.85)}
 g.strokeStyle=c;g.globalAlpha=a;g.lineWidth=lw||1;g.stroke();g.restore()}
/* embossed micro-scales: dark arcs with light arcs just above */
function fa3_tex(g,pf,x0,x1,y0,y1,s,dk,lt,a){fa3_scl(g,pf,x0,x1,y0,y1,s,dk,a,1.1,0);fa3_scl(g,pf,x0,x1,y0,y1,s,lt,a*.85,.9,-1.1)}
/* fin membrane: fine light rays between the main ribs, and a translucent-looking light sheen toward the fin edge */
function fa3_fx(g,pf,x0,y0,tg,c,a,R){g.save();pf();g.clip();
 if(tg&&tg.length>3){g.beginPath();for(let i=0;i+3<tg.length;i+=2){const tx=(tg[i]+tg[i+2])/2,ty=(tg[i+1]+tg[i+3])/2;g.moveTo(x0,y0);g.quadraticCurveTo((x0+tx)/2,(y0+ty)/2+(ty-y0)*.08,tx,ty)}
  g.strokeStyle=fa3_rgba(c,(a==null?.5:a)*.9);g.lineWidth=.9;g.stroke()}
 if(R){const q=g.createRadialGradient(x0,y0,R*.3,x0,y0,R);q.addColorStop(0,fa3_rgba(c,0));q.addColorStop(1,fa3_rgba(c,(a==null?.5:a)*.7));g.fillStyle=q;g.fillRect(x0-R,y0-R,R*2,R*2)}
 g.restore()}
/* re-stroke an outline at a given weight */
function fa3_ol(g,pf,lw){pf();g.lineWidth=lw;g.strokeStyle=FKO;g.lineJoin='round';g.stroke()}

/* ---------- 18 Silver Moonfin (Rare) ---------- */
FISHART.moonfin=(g,t,o)=>{const gl=o.glow||0,sw=fkSway(o,3.2,.13),fl=Math.sin(t*4.2)*.12,pu=.5+.5*Math.sin(t*2.2),sh=k=>`rgba(255,255,255,${.5+.35*Math.sin(t*3+k)+gl*.15})`;
 fa3_bend(g,t,o);
 /* moon-glow aura */
 fkGlow(g,8,-4,118+gl*16,'#a8f2ff',.2+.08*pu+gl*.45);
 const silver=(y0,y1)=>fkLin(g,0,y0,0,y1,['#ffffff','#bdeef9','#f2fdff','#a6dff0','#ffffff']);
 /* lunate crescent tail: both lobes curl inward to sharp points */
 fa3_at(g,-52,0,sw,()=>{const tp=()=>{g.beginPath();g.moveTo(14,-10);g.bezierCurveTo(-8,-24,-32,-62,-60,-57);g.bezierCurveTo(-42,-44,-31,-22,-30,0);g.bezierCurveTo(-31,22,-42,44,-60,57);g.bezierCurveTo(-32,62,-8,24,14,10);g.closePath()};
  tp();fkFill(g,silver(-60,60),2.6);fa3_ribs(g,tp,8,0,[-56,-52,-46,-36,-36,-18,-33,0,-36,18,-46,36,-56,52],'#3a7a9a',.33);fa3_fx(g,tp,8,0,[-56,-52,-46,-36,-36,-18,-33,0,-36,18,-46,36,-56,52],'#5aa8c8',.5,0);fa3_fx(g,tp,12,0,null,'#d8c4ff',.5,64);
  g.save();tp();g.clip();g.beginPath();g.moveTo(-54,-50);g.bezierCurveTo(-38,-38,-29,-18,-28,0);g.bezierCurveTo(-29,18,-38,38,-54,50);g.strokeStyle='rgba(140,236,255,.9)';g.lineWidth=3.2;g.stroke();g.restore();
  fa3_rim(g,tp,sh(0),3.6,2.6)});
 /* small crescent anal fin (back) */
 fa3_at(g,-14,40,-fl*.7,()=>{const p=()=>{g.beginPath();g.moveTo(10,-4);g.quadraticCurveTo(0,22,-36,28);g.quadraticCurveTo(-14,14,-14,-2);g.closePath()};p();fkFill(g,silver(-4,30),2.4);fa3_ribs(g,p,2,-2,[-32,26,-20,22,-10,14],'#3a7a9a',.3);fa3_fx(g,p,2,-2,[-36,28,-32,26,-20,22,-10,14],'#5aa8c8',.45,38);fa3_rim(g,p,sh(1),3,2.4)});
 /* crescent-hook dorsal sweeping back, with silver spiky tips */
 fa3_at(g,14,-52,fl*.5,()=>{const A=[26,2],B=[16,-28],C=[-22,-34],D=[-58,-26];
  [.32,.52,.72].forEach((s,i)=>{const q=fa3_cub(A,B,C,D,s),L=Math.hypot(q[2],q[3])||1,tx=q[2]/L,ty=q[3]/L,nx=-ty,ny=tx,h=9-i;
   g.beginPath();g.moveTo(q[0]-tx*5,q[1]-ty*5);g.lineTo(q[0]+nx*h+tx*5,q[1]+ny*h+ty*5);g.lineTo(q[0]+tx*4,q[1]+ty*4);g.closePath();fkFill(g,fkLin(g,q[0],q[1],q[0]+nx*h,q[1]+ny*h,['#a8dcef','#ffffff']),2)});
  const p=()=>{g.beginPath();g.moveTo(A[0],A[1]);g.bezierCurveTo(B[0],B[1],C[0],C[1],D[0],D[1]);g.bezierCurveTo(-34,-22,-22,-14,-26,6);g.closePath()};
  p();fkFill(g,silver(-34,6),2.5);fa3_ribs(g,p,-6,8,[-54,-25,-42,-29,-28,-31,-14,-30,0,-26,14,-16],'#3a7a9a',.3);fa3_fx(g,p,-6,8,[-54,-25,-42,-29,-28,-31,-14,-30,0,-26,14,-16],'#5aa8c8',.45,0);fa3_fx(g,p,-6,8,null,'#d8c4ff',.5,46);
  g.save();p();g.clip();g.beginPath();g.moveTo(-52,-24);g.bezierCurveTo(-34,-20,-24,-12,-24,2);g.strokeStyle='rgba(140,236,255,.9)';g.lineWidth=2.8;g.stroke();g.restore();
  fa3_rim(g,p,sh(2),3.4,2.5)});
 /* deep opah-like body with a tall chest */
 const BP=[100,8,96,-22,72,-50,30,-62,-12,-54,-42,-30,-56,-8,-54,8,-40,26,-10,46,30,58,70,48,94,26],body=()=>fkPath(g,BP);
 body();fkFill(g,fkLin(g,0,-60,0,56,['#0b6e90','#1fb4cc','#4ee6e0','#b6fff2']),3);
 fkShade(g,body,-14,-60,'#0a3a6a',.45);
 g.save();body();g.clip();
 /* embossed micro-scales, lateral line of silver pores */
 fa3_tex(g,body,-56,52,-62,58,7.5,'#063e5e','#d6fff8',.17);
 g.beginPath();for(let i=0;i<13;i++){const s=i/12,q=fa3_quad([-50,-2],[10,-16],[64,-6],s);g.moveTo(q[0]+1.3,q[1]);g.arc(q[0],q[1],1.3,0,TAU)}g.fillStyle='rgba(230,255,255,.6)';g.fill();
 /* gold spots */
 const sp=[[-36,-16,4.4],[-24,4,3.6],[-12,-28,5.2],[-4,-6,3.8],[6,22,4.6],[12,-40,3.4],[-40,10,3],[32,28,3.4],[-18,28,3],[44,-38,3.2],[-48,-2,2.4],[46,-20,2.8],[22,12,2.6],[-28,-36,3],[2,40,2.8],[-6,-46,2.6],[-34,26,2.4],[48,8,2.4],[18,46,2.6]];
 g.globalCompositeOperation='lighter';sp.forEach(([x,y,r],i)=>{const k=fa3_tw(t,i,1.7);g.beginPath();g.arc(x,y,r*2.4,0,TAU);g.fillStyle=`rgba(255,210,80,${.06+.1*k+gl*.12})`;g.fill()});g.globalCompositeOperation='source-over';
 for(const [x,y,r] of sp){g.beginPath();g.arc(x,y,r,0,TAU);g.fillStyle=fkRad(g,x,y,r,['#fff6b8','#ffd34a','#c47a08']);g.fill();g.lineWidth=1.2;g.strokeStyle='rgba(27,16,36,.5)';g.stroke();g.beginPath();g.arc(x-r*.34,y-r*.36,r*.3,0,TAU);g.fillStyle='rgba(255,255,240,.95)';g.fill()}
 /* clean silver crescent-moon emblem */
 fa3_cres(g,22,-14,12.5,.42,-.55);g.fillStyle=fkLin(g,10,-26,30,0,['#ffffff','#e8fbff','#bfeef8']);g.fill();g.lineWidth=1.5;g.strokeStyle='rgba(20,90,130,.6)';g.stroke();
 g.restore();
 fkGlow(g,18,-14,26,'#d8fcff',.2+.12*pu+gl*.35);
 fkShade(g,body,12,58,'#0b5a7a',.32);
 fa3_rl(g,body,-62,-20,'#d8ffff',.75,3.6,3);fa3_rl(g,body,58,24,'#9ff6ff',.55,-3.4,2.6);
 fkHi(g,body,.6,3.4);
 fa3_glint(g,56,-44,4.2,-.5,.85);fa3_glint(g,-30,-40,2.6,-.9,.55);
 fa3_gill(g,58,-36,12,12);
 /* thin crescent-sickle pectoral */
 fa3_at(g,50,18,fl,()=>{const p=()=>{g.beginPath();g.moveTo(4,-7);g.bezierCurveTo(-2,12,-22,28,-52,25);g.bezierCurveTo(-34,13,-18,2,-4,7);g.closePath()};p();fkFill(g,fkLin(g,4,-7,-40,26,['#ffffff','#c6f0fb','#7cc6e2']),2.4);fa3_ribs(g,p,2,0,[-50,25,-42,24,-34,22,-26,19,-18,14],'#3a7a9a',.35);fa3_fx(g,p,2,0,[-50,25,-42,24,-34,22,-26,19,-18,14],'#ffffff',.6,52);fa3_rim(g,p,sh(3),3,2.4)});
 fa3_eye(g,74,-14,11.5,'#1a86a8',.3);
 fa3_smile(g,93,12,6,null,'rgba(255,140,180,.8)');
 /* moon sparkles */
 const ss=[[-74,-52,7,'#ffffff'],[66,-62,6,'#fff3b0'],[-88,44,5,'#c8fbff'],[100,-28,4.5,'#ffffff'],[-8,64,5,'#fff3b0'],[34,-76,4,'#c8fbff']];
 ss.forEach(([x,y,r,c],i)=>{const k=fa3_tw(t,i,2.6);fkSpark(g,x,y+Math.sin(t+i)*2,r*(.6+.5*k)*(1+gl*.5),c,.35+.6*k)});
};

/* ---------- 19 Dusk Angler (Rare) ---------- */
FISHART.angler=(g,t,o)=>{const gl=o.glow||0,sw=fkSway(o,3.6,.16),fl=Math.sin(t*5)*.15,fx=o.flex||0,lp=.5+.5*Math.sin(t*3);
 fa3_bend(g,t,o);
 const ox=96+Math.sin(t*1.7)*3+Math.sin(t*9)*fx*3,oy=-54+Math.sin(t*2.3)*4;
 fkGlow(g,ox,oy,42,'#ffd98a',.2+.08*lp+gl*.45);
 /* tail */
 fa3_at(g,-54,2,sw,()=>{const p=[14,-10,-12,-22,-46,-44,-36,-14,-32,0,-36,14,-46,44,-12,22,14,10];
  fkFin(g,p,'#d08cff','#5a2a9a',[[4,0,-44,-40],[4,0,-40,-20],[4,0,-36,0],[4,0,-40,20],[4,0,-44,40]],2.4);const pf=()=>fkPath(g,p);
  fa3_fx(g,pf,4,0,[-46,-44,-44,-40,-40,-20,-36,0,-40,20,-44,40,-46,44],'#f0c8ff',.5,48);fa3_ol(g,pf,2.4)});
 /* spiky violet dorsal crest */
 const crest=()=>{g.beginPath();g.moveTo(4,-62);g.quadraticCurveTo(0,-74,-8,-87);g.quadraticCurveTo(-11,-76,-16,-68);g.quadraticCurveTo(-20,-78,-28,-85);g.quadraticCurveTo(-29,-72,-34,-62);g.quadraticCurveTo(-39,-70,-48,-77);g.quadraticCurveTo(-48,-62,-56,-44);g.closePath()};
 crest();fkFill(g,fkLin(g,0,-87,0,-50,['#f6c8ff','#c070f4','#7a34c8','#4a1a8a']),2.3);
 fa3_ribs(g,crest,-18,-50,[-8,-86,-28,-84,-48,-76],FKO,.3,1.3);fa3_fx(g,crest,-18,-50,[0,-80,-8,-86,-28,-84,-48,-76,-54,-50],'#ffe0ff',.5,36);
 fa3_rim(g,crest,'rgba(255,220,255,.5)',2.4,2.3);
 fa3_at(g,-30,46,-fl*.6,()=>{const P=[8,-6,-6,16,-26,22,-22,6,-18,-6];fkFin(g,P,'#c080f8','#5a2a9a',[[2,-2,-22,18],[2,-2,-12,18]],2.3);fa3_fx(g,()=>fkPath(g,P),2,-2,[-26,22,-22,18,-12,18,-2,16],'#f0c8ff',.45,26)});
 /* mouth interior (shows through the body's open grin) */
 const cav=()=>{g.beginPath();g.moveTo(102,-12);g.quadraticCurveTo(70,-6,38,8);g.quadraticCurveTo(76,40,112,8);g.closePath()};
 cav();g.fillStyle=fkLin(g,0,-10,0,30,['#4a0c32','#22051a']);g.fill();
 g.save();cav();g.clip();g.beginPath();g.ellipse(66,24,17,6.5,-.12,0,TAU);g.fillStyle='#d04a7a';g.fill();g.beginPath();g.ellipse(62,22,7,2,-.12,0,TAU);g.fillStyle='rgba(255,170,200,.5)';g.fill();g.restore();
 /* body with an underbite: the lower jaw juts past the upper */
 const body=()=>{g.beginPath();g.moveTo(102,-12);g.quadraticCurveTo(100,-50,54,-66);g.quadraticCurveTo(4,-78,-40,-54);g.quadraticCurveTo(-66,-34,-64,0);g.quadraticCurveTo(-62,34,-40,50);
  g.quadraticCurveTo(4,72,54,62);g.quadraticCurveTo(104,52,112,8);g.quadraticCurveTo(76,40,38,8);g.quadraticCurveTo(70,-6,102,-12);g.closePath()};
 body();fkFill(g,fkRad(g,24,-16,104,['#a865dc','#6a33a4','#3a1664','#25103f']),3);
 fkShade(g,body,10,66,'#1a0830',.4);
 /* glowing freckles (kept clear of the fin) */
 g.save();body();g.clip();
 /* mottled deep-sea skin: soft darker blotches and fine pale speckles */
 g.fillStyle='rgba(30,8,60,.22)';[[-36,-44,14,9,.4],[-50,22,12,10,0],[-6,-60,16,7,.1],[20,40,16,8,-.2],[-18,8,10,8,.6]].forEach(([x,y,a,b,r])=>{g.beginPath();g.ellipse(x,y,a,b,r,0,TAU);g.fill()});
 g.beginPath();for(let i=0;i<46;i++){const x=-60+((i*37)%118),y=-64+((i*53)%124),r=.7+(i%3)*.35;g.moveTo(x+r,y);g.arc(x,y,r,0,TAU)}g.fillStyle='rgba(230,200,255,.28)';g.fill();
 [[-30,-30],[-14,-44],[4,-50],[-40,-8],[-22,-14],[-46,16],[-48,32],[22,48],[12,-34],[-6,-22]].forEach(([x,y],i)=>{const k=fa3_tw(t,i,2.2),c=i%3?'#7af0ff':'#ff8ae0';
  g.globalAlpha=.18+.22*k;g.fillStyle=c;g.beginPath();g.arc(x,y,6.5,0,TAU);g.fill();g.globalAlpha=.35+.4*k;g.beginPath();g.arc(x,y,4,0,TAU);g.fill();g.globalAlpha=1;g.beginPath();g.arc(x,y,2,0,TAU);g.fillStyle='#ffffff';g.fill()});
 /* the lure's warm light on the forehead and eye */
 fkGlow(g,(ox+58)/2,(oy-34)/2+4,58,'#ffc878',.24+.1*lp+gl*.3);
 /* lower lip band */
 g.beginPath();g.moveTo(40,13);g.quadraticCurveTo(76,45,112,13);g.strokeStyle='rgba(206,150,255,.6)';g.lineWidth=3.2;g.stroke();
 g.restore();
 fa3_rl(g,body,-78,-30,'#ffd8a0',.6,3.6,3);fa3_rl(g,body,70,30,'#c890ff',.55,-3.4,2.8);
 fkHi(g,body,.45,3.4);
 fa3_glint(g,24,-60,4,-.25,.75);fa3_glint(g,-44,-36,2.4,-1,.45);
 fa3_gill(g,18,-30,12,8,.3);
 /* teeth: upper row hangs from the upper lip, lower row stands on the lower lip */
 g.fillStyle='#fffaf0';g.strokeStyle=FKO;g.lineWidth=1.2;
 const qp=(a,b,c,s)=>[(1-s)*(1-s)*a[0]+2*(1-s)*s*b[0]+s*s*c[0],(1-s)*(1-s)*a[1]+2*(1-s)*s*b[1]+s*s*c[1]];
 for(let i=1;i<9;i++){const s=i/9.4,p=qp([102,-12],[70,-6],[38,8],s),q=qp([102,-12],[70,-6],[38,8],s+.06),L=7-s*3;g.beginPath();g.moveTo(p[0],p[1]-1);g.lineTo(q[0],q[1]-1);g.lineTo((p[0]+q[0])/2+1,(p[1]+q[1])/2+L);g.closePath();g.fill();g.stroke()}
 for(let i=1;i<9;i++){const s=i/9,p=qp([38,8],[76,40],[112,8],s-.035),q=qp([38,8],[76,40],[112,8],s+.035),L=4.5+s*5.5;g.beginPath();g.moveTo(p[0],p[1]+1.5);g.lineTo(q[0],q[1]+1.5);g.lineTo((p[0]+q[0])/2+.5,(p[1]+q[1])/2-L);g.closePath();g.fill();g.stroke()}
 /* front pectoral */
 fa3_at(g,6,22,fl,()=>{const p=[6,-6,-14,-4,-34,10,-30,22,-12,22,4,8];fkFin(g,p,'#e0a0ff','#7a3ab8',[[2,0,-30,12],[2,0,-24,22],[2,0,-12,20]],2.3);fa3_fx(g,()=>fkPath(g,p),2,0,[-34,6,-30,12,-24,22,-12,20,-2,14],'#ffe0ff',.5,34)});
 /* eye with a cheeky brow */
 fa3_eye(g,58,-30,13.5,'#ffa21a',.4);
 g.beginPath();g.moveTo(44,-48);g.quadraticCurveTo(58,-54,72,-46);g.strokeStyle=FKO;g.lineWidth=3;g.stroke();
 /* lure stalk */
 g.beginPath();g.moveTo(36,-66);g.quadraticCurveTo(58,-96,ox-2,oy-7);g.strokeStyle=FKO;g.lineWidth=6.5;g.stroke();g.strokeStyle='#9a5ad6';g.lineWidth=3.2;g.stroke();
 g.beginPath();g.moveTo(40,-72);g.quadraticCurveTo(58,-94,ox-6,oy-9);g.strokeStyle='rgba(240,200,255,.6)';g.lineWidth=1.2;g.stroke();
 /* the little moon */
 g.beginPath();g.arc(ox,oy,10,0,TAU);fkFill(g,fkRad(g,ox,oy,10,['#ffffff','#fff2a8','#f2b448']),2.4);
 g.fillStyle='rgba(214,150,60,.55)';[[2,3,2.4],[-3,-2,1.6],[4,-4,1.2]].forEach(([a,b,r])=>{g.beginPath();g.arc(ox+a,oy+b,r,0,TAU);g.fill()});
 g.beginPath();g.arc(ox-3,oy-3.5,3,0,TAU);g.fillStyle='#fff';g.fill();
 g.beginPath();g.arc(ox,oy,15+3*lp,0,TAU);g.strokeStyle=`rgba(255,236,170,${.25+.2*lp+gl*.2})`;g.lineWidth=1.2;g.stroke();
 fkGlow(g,ox,oy,24,'#fff4c0',.5+.2*lp+gl*.3);
 [[ox+16,oy-10,4],[ox-15,oy+8,3],[ox+10,oy+16,2.6]].forEach(([x,y,r],i)=>fkSpark(g,x,y,r*(.6+.6*fa3_tw(t,i,3.4)),'#fff6c8',.3+.6*fa3_tw(t,i,3.4)));
};

/* ---------- 20 Ghostwing Ray (Rare) ---------- */
FISHART.ray=(g,t,o)=>{const gl=o.glow||0,fx=o.flex||0,A=6.5*(1+fx*1.9),ph=t*2.4,w1=Math.sin(ph)*A,w2=Math.sin(ph-.35)*A*.9,sw=fkSway(o,3,.1);
 fa3_bend(g,t,o);
 fkGlow(g,8,0,126+gl*14,'#b8c6ff',.2+.06*Math.sin(t*2)+gl*.45);
 /* one side of the wing outline, snout -> tail root; sg -1 upper, 1 lower */
 const side=(sg,wv)=>{const P=[],tx=-32+wv*.3,ty=68+wv;
  for(let i=0;i<=6;i++){const s=i/6,q=fa3_cub([90,12],[86,42],[28,80+wv*.6],[tx,ty],s);P.push(q[0],sg*(q[1]+Math.sin(s*5-ph*1.2)*2.2*s))}
  P.push(tx,sg*ty);
  for(let i=1;i<=9;i++){const s=i/9,q=fa3_quad([tx,ty],[10,40+wv*.3],[-44,8],s),off=(i%2?3.8:0)+Math.sin(s*8-ph*2)*1.4;P.push(q[0]-off*.9,sg*(q[1]+off*.4))}
  return P};
 const up=side(-1,w1),lo=side(1,w2),lr=[];for(let i=lo.length-2;i>=0;i-=2)lr.push(lo[i],lo[i+1]);
 const BP=up.concat(lr,[102,0]),body=()=>fkPath(g,BP),tip1=[-32+w1*.3,-(68+w1)],tip2=[-32+w2*.3,68+w2],outside=fn=>{g.save();g.beginPath();g.rect(-200,-200,400,400);fa3_blob(g,BP,1);g.clip('evenodd');fn();g.restore()};
 /* spectral wisps drifting off the wing tips */
 [[tip1,-1],[tip2,1]].forEach(([tp,sg],j)=>{for(let k=0;k<2;k++){const L=58+k*16,ph2=t*1.8+j*1.3+k*2;
  const fn=s=>[tp[0]-2-s*L,tp[1]+sg*(4+k*8)*s*s-sg*k*3+Math.sin(ph2-s*5)*7*s,(3.2-k*.8)*Math.sin(Math.PI*Math.min(1,s*1.6+.08))*(1-s*.6)+.15];const p=fa3_rib(12,fn);
  fkPath(g,p);g.fillStyle=fkLin(g,tp[0],0,tp[0]-L,0,[`rgba(220,228,255,${.42+.12*Math.sin(ph2)})`,'rgba(200,212,255,.18)','rgba(200,212,255,0)']);g.fill()}});
 /* long whip tail with a gentle S-sway */
 outside(()=>fa3_at(g,-34,0,sw,()=>{const fn=s=>[-s*76,Math.sin(t*3.1-s*5)*8*s*(1+fx*1.4)+Math.sin(s*Math.PI*1.6)*3*s,5.2*(1-s)+.7];const p=fa3_rib(18,fn);fkPath(g,p);fkFill(g,fkLin(g,0,0,-76,0,['rgba(232,238,255,.9)','rgba(190,192,246,.8)']),2);
  const c=fa3_line(18,fn);g.beginPath();g.moveTo(c[0][0],c[0][1]-1.6);for(let i=1;i<15;i++)g.lineTo(c[i][0],c[i][1]-c[i][2]*.45);g.strokeStyle='rgba(255,255,255,.75)';g.lineWidth=1.1;g.stroke()}));
 /* curled cephalic horn lobes pointing forward */
 outside(()=>[-1,1].forEach(s=>{const c=Math.sin(t*2+s)*1.8;const hp=[82,s*6,92,s*20,106,s*25,116+c*.4,s*(19+c),115,s*(10+c),108,s*(12+c*.5),98,s*12,89,s*4];
  fkPath(g,hp);fkFill(g,fkLin(g,86,0,116,0,['rgba(226,232,255,.9)','rgba(176,178,244,.9)']),2.3);g.save();fkPath(g,hp);g.clip();g.beginPath();g.moveTo(90,s*7);g.quadraticCurveTo(104,s*17,114,s*(17+c));g.strokeStyle='rgba(255,255,255,.7)';g.lineWidth=1.4;g.stroke();g.restore();
  g.beginPath();g.moveTo(92,s*12);g.quadraticCurveTo(106,s*20,111,s*(14+c*.6));g.strokeStyle='rgba(120,110,210,.45)';g.lineWidth=1.6;g.stroke()}));
 /* translucent body + wings */
 body();fkFill(g,fkLin(g,0,-80,0,80,['rgba(168,176,250,.6)','rgba(222,230,255,.66)','rgba(246,250,255,.74)','rgba(222,230,255,.66)','rgba(184,190,252,.6)']),2.8);
 g.save();body();g.clip();
 g.fillStyle='rgba(90,90,190,.12)';g.fillRect(-80,-96,200,84);
 /* ripple bands across the wings */
 for(let i=0;i<4;i++){const xx=-10+i*22+Math.sin(ph+i)*3;g.beginPath();g.moveTo(xx+12,-90);g.quadraticCurveTo(xx-6+Math.sin(ph-i)*4,0,xx+12,90);g.strokeStyle='rgba(255,255,255,.16)';g.lineWidth=5;g.stroke()}
 /* fine cartilage rays fanning through both wings, rippling with the wingbeat */
 const fan=(c,lw,dx)=>{g.beginPath();for(let i=0;i<16;i++){const x=-34+i*7.6+dx;[-1,1].forEach(sg=>{const wv=sg<0?w1:w2,ex=x-46-i*1.2,ey=sg*(96+wv);g.moveTo(x,sg*12);g.quadraticCurveTo(x-14+Math.sin(ph-i*.4)*3,sg*(54+wv*.5),ex,ey)})}g.strokeStyle=c;g.lineWidth=lw;g.stroke()};
 fan('rgba(110,104,210,.16)',1.1,0);fan('rgba(255,255,255,.3)',.8,1.4);
 /* soft dappled mottling */
 g.beginPath();for(let i=0;i<40;i++){const x=-40+((i*41)%130),y=(i%2?1:-1)*(16+((i*29)%62)),r=.8+(i%3)*.45;g.moveTo(x+r,y);g.arc(x,y,r,0,TAU)}g.fillStyle='rgba(140,130,230,.25)';g.fill();
 /* raised body ridge */
 g.beginPath();g.ellipse(28,0,60,18,0,0,TAU);g.fillStyle=fkLin(g,0,-18,0,18,['rgba(255,255,255,.7)','rgba(214,220,255,.45)']);g.fill();
 g.beginPath();g.moveTo(-34,0);g.quadraticCurveTo(20,-3,72,-1);g.strokeStyle='rgba(120,120,210,.3)';g.lineWidth=2;g.stroke();
 /* vertebra beads along the spine and a crisp ridge sheen */
 g.beginPath();for(let i=0;i<9;i++){const x=-26+i*10,y=-1.4-Math.sin(i/8*Math.PI)*1.2;g.moveTo(x+1.5,y);g.ellipse(x,y,1.5,1.1,0,0,TAU)}g.fillStyle='rgba(130,120,220,.4)';g.fill();
 g.beginPath();g.ellipse(34,-9,40,4,-.03,0,TAU);g.fillStyle='rgba(255,255,255,.55)';g.fill();
 /* glowing lavender spots with soft halos */
 g.globalCompositeOperation='lighter';
 const SP=[[-4,-50,5],[14,-40,3.8],[4,-62,3],[30,-34,3.2],[-20,-30,3.2],[0,50,5.2],[18,42,3.8],[-14,34,3.4],[6,62,3],[32,36,3.2],[-28,-52,2.8],[-22,54,2.8]];
 SP.forEach(([x,y,r],i)=>{const k=fa3_tw(t,i,2.1);g.fillStyle=i%4?`rgba(170,120,255,${.16+.14*k+gl*.15})`:`rgba(255,130,220,${.16+.14*k+gl*.15})`;g.beginPath();g.arc(x,y,r*2.6,0,TAU);g.fill()});
 g.globalCompositeOperation='source-over';
 SP.forEach(([x,y,r],i)=>{g.beginPath();g.arc(x,y,r,0,TAU);g.fillStyle=i%4?'rgba(160,112,246,.85)':'rgba(255,136,220,.85)';g.fill();g.beginPath();g.arc(x-r*.3,y-r*.3,r*.38,0,TAU);g.fillStyle='rgba(255,255,255,.75)';g.fill()});
 g.restore();
 fkShade(g,body,20,80,'#6a6ad0',.2);
 /* bright spectral inner rim */
 fa3_rim(g,body,`rgba(226,238,255,${.55+.2*Math.sin(t*2.2)+gl*.3})`,8,0);
 fa3_rim(g,body,'rgba(255,255,255,.8)',2.4,2.8);
 /* face */
 /* spiracles behind the eyes */
 [-1,1].forEach(s=>{g.beginPath();g.ellipse(56,s*20,3.4,2,s*.4,0,TAU);g.fillStyle='rgba(70,60,160,.55)';g.fill();g.beginPath();g.ellipse(56.6,s*20-.8,2,.7,s*.4,0,TAU);g.fillStyle='rgba(255,255,255,.6)';g.fill()});
 fa3_eye(g,72,-14,9.5,'#6a5ae8',.5);fa3_eye(g,74,14,9.5,'#6a5ae8',.5);
 g.beginPath();g.moveTo(95,-6);g.quadraticCurveTo(102,0,95,6);g.quadraticCurveTo(99,0,95,-6);g.fillStyle='rgba(255,150,200,.6)';g.fill();
 g.beginPath();g.moveTo(96,-5);g.quadraticCurveTo(101,0,96,5);g.strokeStyle=FKO;g.lineWidth=1.9;g.stroke();
 fa3_glint(g,52,-6,3.4,-.08,.8);
 [-1,1].forEach(s=>{g.beginPath();g.ellipse(84,s*24,4.5,2.6,0,0,TAU);g.fillStyle='rgba(255,140,200,.55)';g.fill()});
 /* twinkles on the wings + ghost motes */
 [[-8,-44],[22,-50],[-2,40],[24,56]].forEach(([x,y],i)=>{const k=fa3_tw(t,i+2,3.2);fkSpark(g,x,y,(2.5+3*k)*(1+gl*.5),'#ffffff',.3+.65*k)});
 [[-62,-70,5],[64,-64,4],[-76,62,4.5],[56,68,3.6],[-96,-14,3.4]].forEach(([x,y,r],i)=>{const k=fa3_tw(t,i,2);fkSpark(g,x+Math.sin(t*.8+i)*4,y-k*4,r*(.6+.5*k)*(1+gl*.4),'#e6eeff',.3+.5*k)});
};

/* ---------- 21 Sunscale Sturgeon (Rare) ---------- */
/* bevelled bony diamond plate with a sun emblem: cast shadow, four lit facets (light top-left, dark bottom-right), warm pulsing core */
function fa3_sun(g,x,y,r,t,i){const k=.5+.5*Math.sin(t*2+i*1.3),P=r*1.85,W=P*1.32,f=.56;
 const O=[[x-W,y],[x,y-P],[x+W,y],[x,y+P]],I=O.map(([a,b])=>[x+(a-x)*f,y+(b-y)*f]);
 const dia=(Q,dx,dy)=>{g.beginPath();Q.forEach(([a,b],j)=>j?g.lineTo(a+dx,b+dy):g.moveTo(a+dx,b+dy));g.closePath()};
 dia(O,1.6,2.2);g.fillStyle='rgba(70,24,0,.42)';g.fill();
 const FC=['#fff6c8','#ffd45a','#9a4e08','#d48a22'];
 for(let j=0;j<4;j++){const a=O[j],b=O[(j+1)%4],c=I[(j+1)%4],d=I[j];g.beginPath();g.moveTo(a[0],a[1]);g.lineTo(b[0],b[1]);g.lineTo(c[0],c[1]);g.lineTo(d[0],d[1]);g.closePath();g.fillStyle=FC[j];g.fill()}
 dia(I,0,0);g.fillStyle=fkLin(g,x-W*f,y-P*f,x+W*f,y+P*f,['#ffe48a','#f2a830','#c26a10']);g.fill();
 dia(O,0,0);g.lineWidth=1.5;g.strokeStyle=FKO;g.lineJoin='round';g.stroke();
 g.beginPath();g.moveTo(O[0][0]+1.4,O[0][1]);g.lineTo(O[1][0],O[1][1]+1.4);g.strokeStyle='rgba(255,255,240,.9)';g.lineWidth=1;g.stroke();
 /* warm glowing core */
 g.save();g.globalCompositeOperation='lighter';const q=g.createRadialGradient(x,y,0,x,y,r*1.9);q.addColorStop(0,`rgba(255,236,150,${.55+.35*k})`);q.addColorStop(.45,`rgba(255,180,60,${.22+.18*k})`);q.addColorStop(1,'rgba(255,150,40,0)');g.fillStyle=q;g.beginPath();g.arc(x,y,r*1.9,0,TAU);g.fill();g.restore();
 /* small sun: eight bevelled rays + disc */
 for(let k2=0;k2<8;k2++){const a=k2*TAU/8+i*.4,L=k2%2?r*.92:r*1.18,c=Math.cos(a),s=Math.sin(a);g.beginPath();g.moveTo(x+Math.cos(a-.42)*r*.5,y+Math.sin(a-.42)*r*.5);g.lineTo(x+c*L,y+s*L);g.lineTo(x+Math.cos(a+.42)*r*.5,y+Math.sin(a+.42)*r*.5);g.closePath();g.fillStyle=(c+s)<0?'#fff4b8':'#e89a22';g.fill();g.strokeStyle='rgba(110,46,4,.7)';g.lineWidth=.8;g.stroke()}
 g.beginPath();g.arc(x,y,r*.56,0,TAU);fkFill(g,fkRad(g,x,y,r*.56,['#ffffff','#ffe066','#d4840c']),1.2);g.beginPath();g.arc(x-r*.18,y-r*.2,r*.17,0,TAU);g.fillStyle='#fff';g.fill()}
/* a pointed bony scute; dir -1 points up, 1 points down. Two lit faces split along a keel */
function fa3_scute(g,x,y,h,w,dir,c1,c2,c3){const P=()=>{g.beginPath();g.moveTo(x-w,y-dir*3);g.quadraticCurveTo(x-w*.4,y+dir*h*.6,x+1,y+dir*h);g.quadraticCurveTo(x+w*.55,y+dir*h*.4,x+w,y-dir*3);g.quadraticCurveTo(x,y-dir*6,x-w,y-dir*3);g.closePath()};
 P();fkFill(g,fkLin(g,x,y+dir*h,x,y-dir*4,[c1,c2,c3]),1.7);
 g.save();P();g.clip();g.beginPath();g.moveTo(x+1,y+dir*h);g.lineTo(x+w+2,y-dir*4);g.lineTo(x+1.5,y-dir*6);g.closePath();g.fillStyle='rgba(120,52,4,.38)';g.fill();g.restore();
 g.beginPath();g.moveTo(x-w*.5,y-dir*1.5);g.quadraticCurveTo(x-w*.25,y+dir*h*.5,x+.4,y+dir*h*.85);g.strokeStyle='rgba(255,255,235,.9)';g.lineWidth=1.2;g.stroke();
 g.beginPath();g.arc(x,y,1.4,0,TAU);g.fillStyle='#7a3c06';g.fill()}
/* fin membrane: alternate wedges between the ribs shaded darker */
function fa3_web(g,pf,x0,y0,tg,c,a){g.save();pf();g.clip();g.beginPath();for(let i=0;i+3<tg.length;i+=4){g.moveTo(x0,y0);g.lineTo(tg[i],tg[i+1]);g.lineTo(tg[i+2],tg[i+3]);g.closePath()}g.fillStyle=c;g.globalAlpha=a;g.fill();g.restore()}
/* embossed rib: a dark rib with a light line just up-left of it */
function fa3_ribs2(g,pf,x0,y0,tg,dk,lt,a){fa3_ribs(g,pf,x0,y0,tg,dk,a,1.8);g.save();g.translate(-.9,-1);fa3_ribs(g,pf,x0,y0,tg,lt,a*1.1,.8);g.restore()}
FISHART.sun=(g,t,o)=>{const gl=o.glow||0,sw=fkSway(o,2.8,.12),fl=Math.sin(t*4)*.12,pu=.5+.5*Math.sin(t*2);
 fa3_bend(g,t,o);
 /* golden aura with slowly turning sun rays */
 fkGlow(g,10,-2,124+8*pu+gl*16,'#ffb43a',.2+.1*pu+gl*.45);
 g.save();g.globalCompositeOperation='lighter';g.translate(10,-2);g.rotate(t*.22);g.beginPath();for(let i=0;i<12;i++){const a=i*TAU/12;g.moveTo(0,0);g.arc(0,0,118,a-.07,a+.07)}
 const rq=g.createRadialGradient(0,0,20,0,0,118);rq.addColorStop(0,`rgba(255,214,110,${.09+.07*pu+gl*.15})`);rq.addColorStop(1,'rgba(255,190,80,0)');g.fillStyle=rq;g.fill();g.restore();
 const finR=(x0,y0,R)=>{const q=g.createRadialGradient(x0,y0,0,x0,y0,R);q.addColorStop(0,'#ffe27a');q.addColorStop(.3,'#ffb42a');q.addColorStop(.7,'#f06a18');q.addColorStop(1,'#c8360e');return q};
 const fin=(pf,x0,y0,tg,R)=>{pf();g.fillStyle=finR(x0,y0,R);g.fill();fa3_web(g,pf,x0,y0,tg,'#9a2a04',.24);fa3_ribs2(g,pf,x0,y0,tg,'#5a1a02','#fff2c0',.62);fa3_fx(g,pf,x0,y0,tg,'#fff2b8',.45,0);fa3_rim(g,pf,'rgba(255,90,24,.85)',4,2.4)};
 /* clean heterocercal shark tail, upper lobe edged with a dark keel */
 fa3_at(g,-64,-3,sw,()=>{const p=()=>{g.beginPath();g.moveTo(12,-7);g.quadraticCurveTo(-16,-18,-50,-50);g.quadraticCurveTo(-42,-22,-34,-2);g.quadraticCurveTo(-40,14,-36,28);g.quadraticCurveTo(-14,14,12,7);g.closePath()};
  fin(p,8,0,[-50,-50,-44,-38,-40,-26,-36,-14,-34,-3,-36,8,-37,18,-36,27],60);
  g.save();p();g.clip();g.beginPath();g.moveTo(12,-7);g.quadraticCurveTo(-16,-18,-50,-50);g.strokeStyle='rgba(110,34,4,.6)';g.lineWidth=5;g.stroke();g.beginPath();g.moveTo(8,-4);g.quadraticCurveTo(-18,-14,-44,-40);g.strokeStyle='rgba(255,244,190,.75)';g.lineWidth=1.3;g.stroke();g.restore();fa3_ol(g,p,2.4)});
 /* back fins: dorsal behind the last scute, anal and pelvic */
 fa3_at(g,-46,-16,fl*.4,()=>{const p=()=>{g.beginPath();g.moveTo(10,2);g.quadraticCurveTo(2,-20,-18,-24);g.quadraticCurveTo(-12,-12,-16,2);g.closePath()};fin(p,0,2,[-18,-24,-16,-18,-10,-21,-3,-16,4,-9],28)});
 fa3_at(g,-44,13,-fl*.5,()=>{const p=()=>{g.beginPath();g.moveTo(10,-2);g.quadraticCurveTo(0,14,-18,18);g.quadraticCurveTo(-12,6,-14,-2);g.closePath()};fin(p,0,-2,[-18,18,-15,12,-9,15,-2,11,4,7],24)});
 fa3_at(g,-6,26,-fl*.6,()=>{const p=()=>{g.beginPath();g.moveTo(8,-2);g.quadraticCurveTo(-2,14,-20,15);g.quadraticCurveTo(-12,4,-12,-2);g.closePath()};fin(p,0,-2,[-20,15,-16,10,-10,13,-3,10,3,6],24)});
 /* body: powerful front third tapering to the tail, long flat shovel snout */
 const BP=[118,-15,112,-8,96,-3,78,8,56,26,20,33,-20,27,-50,14,-70,4,-70,-6,-52,-16,-24,-28,10,-39,42,-41,64,-35,88,-25,108,-20,116,-18],body=()=>fkPath(g,BP),PT=fa3_spl(BP),top=x=>fa3_edge(PT,x,true),bot=x=>fa3_edge(PT,x,false);
 body();fkFill(g,fkLin(g,0,-41,0,33,['#5a2a06','#a85e10','#f0a828','#ffd870','#fff0c8','#fff8ea']),3);
 fkShade(g,body,-8,-41,'#4a2006',.5);
 fa3_tex(g,body,-70,62,-18,30,8,'#7a3a06','#fff4c8',.22);
 g.save();body();g.clip();
 /* dark armoured back band: ridged bronze plating over the gold */
 const bh=x=>11-Math.max(0,x-60)*.12-Math.max(0,-40-x)*.12,bx=[];for(let x=-72;x<=120;x+=4)bx.push(x);
 const bandP=()=>{g.beginPath();bx.forEach((x,j)=>j?g.lineTo(x,top(x)-4):g.moveTo(x,top(x)-4));for(let j=bx.length-1;j>=0;j--)g.lineTo(bx[j],top(bx[j])+bh(bx[j]));g.closePath()};
 bandP();g.fillStyle=fkLin(g,0,-42,0,-14,['#2e1204','#5a2a06','#86440c']);g.globalAlpha=.88;g.fill();g.globalAlpha=1;
 g.beginPath();for(let x=-62;x<=100;x+=6.5){const y0=top(x)+1,y1=top(x)+bh(x)-.5;g.moveTo(x,y0);g.lineTo(x-1.5,y1)}g.strokeStyle='rgba(20,6,0,.45)';g.lineWidth=1.3;g.stroke();
 g.save();g.translate(1.1,0);g.beginPath();for(let x=-62;x<=100;x+=6.5){const y0=top(x)+1.5,y1=top(x)+bh(x)-1;g.moveTo(x,y0);g.lineTo(x-1.5,y1)}g.strokeStyle='rgba(255,200,110,.35)';g.lineWidth=.9;g.stroke();g.restore();
 g.beginPath();bx.forEach((x,j)=>{const y=top(x)+bh(x);j?g.lineTo(x,y):g.moveTo(x,y)});g.strokeStyle='rgba(27,16,36,.7)';g.lineWidth=1.6;g.stroke();
 g.save();g.translate(0,1.4);g.beginPath();bx.forEach((x,j)=>{const y=top(x)+bh(x);j?g.lineTo(x,y):g.moveTo(x,y)});g.strokeStyle='rgba(255,236,170,.7)';g.lineWidth=1;g.stroke();g.restore();
 /* bevelled bony plates tiling the head and shovel snout */
 const cols=[60,72,84,96,108,120],plate=(a,b,r0,r1,dx)=>{const xa=a+dx,xb=b+dx,P=[[xa,top(xa)+r0],[xb,top(xb)+r0],[xb-1,top(xb)+r1],[xa-1,top(xa)+r1]];
  g.beginPath();P.forEach(([x,y],j)=>j?g.lineTo(x,y):g.moveTo(x,y));g.closePath();g.fillStyle=fkLin(g,xa,P[0][1],xb,P[2][1],['rgba(255,226,140,.34)','rgba(190,110,24,.22)','rgba(80,30,2,.45)']);g.fill();
  g.strokeStyle='rgba(70,28,2,.7)';g.lineWidth=1.2;g.stroke();
  g.beginPath();g.moveTo(P[3][0]+1,P[3][1]-1);g.lineTo(P[0][0]+1,P[0][1]+1);g.lineTo(P[1][0]-1,P[1][1]+1);g.strokeStyle='rgba(255,248,214,.7)';g.lineWidth=.9;g.stroke()};
 for(let j=0;j+1<cols.length;j++){plate(cols[j],cols[j+1],-4,8,0);plate(cols[j],cols[j+1],8,17,6)}
 g.restore();
 g.beginPath();[[92,-12],[98,-11.5],[104,-11],[110,-11],[95,-7],[101,-6.5],[107,-7.5]].forEach(([x,y])=>{g.moveTo(x+1.1,y);g.arc(x,y,1.1,0,TAU)});g.fillStyle='rgba(110,44,6,.6)';g.fill();
 fkGlow(g,24,-6,72,'#ffd060',.08+.08*pu+gl*.4);
 g.save();body();g.clip();
 /* lateral row of bevelled sun-emblem plates */
 [[-44,-1,4],[-21,-3,4.8],[4,-4,5.3],[29,-5,5.3],[52,-6,4.6]].forEach(([x,y,r],i)=>fa3_sun(g,x,y,r,t,i));
 /* lower row of small bronze scutes */
 for(let i=0;i<7;i++){const x=-38+i*14,y=bot(x)-7.5,w=4.6-Math.abs(i-3)*.3,h=3.4;g.beginPath();g.moveTo(x-w,y);g.quadraticCurveTo(x-w*.3,y-h*.9,x+w*.2,y-h);g.quadraticCurveTo(x+w*.7,y-h*.5,x+w,y);g.quadraticCurveTo(x+w*.3,y+h*.9,x-w*.2,y+h);g.quadraticCurveTo(x-w*.7,y+h*.5,x-w,y);g.closePath();
  fkFill(g,fkLin(g,x-w,y-h,x+w,y+h,['#fff0b0','#d48a30','#8a4a10']),1.4);g.beginPath();g.moveTo(x-w*.7,y+.4);g.lineTo(x+w*.7,y-.4);g.strokeStyle='rgba(255,240,200,.75)';g.lineWidth=1;g.stroke()}
 /* sweeping golden sheen */
 g.globalCompositeOperation='lighter';const sx=((t*55)%280)-140,sq=g.createLinearGradient(sx-22,0,sx+22,0);sq.addColorStop(0,'rgba(255,230,140,0)');sq.addColorStop(.5,`rgba(255,236,160,${.28+gl*.2})`);sq.addColorStop(1,'rgba(255,230,140,0)');g.fillStyle=sq;g.fillRect(sx-22,-50,44,100);g.globalCompositeOperation='source-over';
 g.restore();
 fkShade(g,body,14,34,'#e0b070',.2);
 fa3_rl(g,body,-42,-12,'#fff2b0',.75,3.4,2.8);fa3_rl(g,body,34,14,'#ffb860',.6,-3,2.4);
 fkHi(g,body,.6,3.2);
 fa3_glint(g,92,-21,3,-.2,.85);fa3_glint(g,-8,-30,2.4,-.35,.6);
 /* evenly spaced dorsal ridge of bony scutes */
 for(let i=0;i<6;i++){const x=52-i*18;fa3_scute(g,x,top(x)+2,i===0||i===5?8:10,7,-1,'#fff3b0','#ffc23a','#a8600c')}
 fa3_gill(g,58,-30,16,10);
 /* pectoral */
 fa3_at(g,52,20,fl,()=>{const p=()=>{g.beginPath();g.moveTo(6,-4);g.quadraticCurveTo(-10,2,-30,18);g.quadraticCurveTo(-18,24,-4,12);g.closePath()};fin(p,2,0,[-30,18,-26,19,-20,20,-13,17,-6,13,0,8],34)});
 /* four short barbels hanging under the snout, ahead of the mouth */
 [[103,9,0],[98,11,1],[93,8.5,2],[88,10.5,3]].forEach(([x,L,i])=>{const y=bot(x)-1,c=Math.sin(t*2.6+i*1.4)*1.8;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+1,y+L*.6,x-1+c,y+L);g.strokeStyle=FKO;g.lineWidth=3.6;g.stroke();g.strokeStyle='#ffe6b0';g.lineWidth=1.7;g.stroke()});
 /* underslung mouth */
 const my=bot(76);g.beginPath();g.ellipse(76,my-1.5,6.2,3.4,-.35,0,TAU);g.fillStyle='#ffb070';g.fill();g.beginPath();g.ellipse(76,my-1.2,4.6,2.2,-.35,0,TAU);fkFill(g,'#5a1a0a',1.5);g.beginPath();g.ellipse(74.5,my-3,2.6,.7,-.35,0,TAU);g.fillStyle='rgba(255,240,210,.7)';g.fill();
 /* teal-ringed eye set in a bevelled bony socket */
 g.beginPath();g.arc(70.8,-14,14.4,0,TAU);g.fillStyle='rgba(60,22,0,.4)';g.fill();
 g.beginPath();g.arc(70,-15,13,0,TAU);g.fillStyle=fkRad(g,70,-15,13,['#8afff0','#1ab8b0','#0a7a7a']);g.fill();g.lineWidth=1.6;g.strokeStyle=FKO;g.stroke();
 g.beginPath();g.arc(70,-15,11.6,Math.PI*1.1,Math.PI*1.7);g.strokeStyle='rgba(220,255,250,.7)';g.lineWidth=1.2;g.stroke();
 fa3_eye(g,70,-15,10,'#0e9a92',.2);
 g.beginPath();g.moveTo(58,-30);g.quadraticCurveTo(70,-34,82,-28);g.strokeStyle=FKO;g.lineWidth=2.6;g.stroke();
 [[-84,-56,6],[30,-62,5],[104,-36,4],[-40,46,4.5],[-100,30,4],[70,44,4],[-14,-64,3.6]].forEach(([x,y,r],i)=>{const k=fa3_tw(t,i,2.4);fkSpark(g,x,y,r*(.6+.6*k)*(1+gl*.6),i%3?'#fff0a0':'#ffd060',.4+.6*k)});
};

/* ---------- 22 Aurora Koi (Legendary) ---------- */
const FA3_AUR=['#7ff6ff','#8a7cff','#ff8ad8','#ffe27a'];
FISHART.aurora=(g,t,o)=>{const gl=o.glow||0,fx=o.flex||0,sw=fkSway(o,2.4,.1),W=1+fx*1.5,sh=Math.sin(t*.9);
 fa3_bend(g,t,o);
 fkGlow(g,0,0,130+gl*22,'#b48cff',.18+.06*Math.sin(t*1.7)+gl*.6);
 fkGlow(g,-74,0,74,'#7ff6ff',.12+.05*Math.sin(t*2.3)+gl*.3);
 const silk=(x0,y0,x1,y1)=>fkLin(g,x0,y0,x1,y1,['rgba(240,250,255,.96)','rgba(110,240,255,.92)','rgba(146,118,255,.9)','rgba(255,128,214,.9)','rgba(255,222,110,.94)']);
 /* clean aurora gradient along a ribbon: teal -> violet -> pink -> gold, starting at palette slot k */
 const AU=[[110,240,255],[146,118,255],[255,128,214],[255,222,110]];
 const aur=(x0,y0,x1,y1,k,a)=>{const q=g.createLinearGradient(x0,y0,x1,y1);q.addColorStop(0,`rgba(244,250,255,${a})`);for(let i=0;i<4;i++){const c=AU[(k+i)%4];q.addColorStop(.14+i*.286,`rgba(${c[0]},${c[1]},${c[2]},${a})`)}return q};
 const streak=(c,n,a)=>{g.save();g.strokeStyle=`rgba(255,255,255,${a||.45})`;g.lineWidth=1.1;for(let k=1;k<n;k++){const f=k/n;g.beginPath();g.moveTo(c[0][0],c[0][1]+(f-.5)*4);for(let i=1;i<c.length;i++)g.lineTo(c[i][0],c[i][1]+(f-.5)*c[i][2]*1.5);g.stroke()}g.restore()};
 /* a little gold bead + twinkle at each silk ribbon tip */
 const tipB=fn=>{const e=fn(1),k=fa3_tw(t,e[0]*.13+e[1]*.07,3.1);g.beginPath();g.arc(e[0],e[1],2.4,0,TAU);fkFill(g,fkRad(g,e[0],e[1],2.4,['#fffbe0','#ffd23a','#c47e0c']),1.1);fkSpark(g,e[0],e[1],(3+3*k)*(1+gl*.5),'#fff6c8',.35+.55*k)};
 const orbit=front=>{for(let i=0;i<7;i++){const a=t*.7+i*TAU/7;if((Math.sin(a)>0)!==front)continue;const x=Math.cos(a)*106,y=Math.sin(a)*60,k=fa3_tw(t,i,3.3);
  g.beginPath();g.ellipse(0,0,106,60,0,a-.42,a);g.strokeStyle=FA3_AUR[i%4]+(gl>0?'99':'66');g.lineWidth=2.2+gl;g.stroke();fkSpark(g,x,y,(4+3*k)*(1+gl*.8),FA3_AUR[i%4],.5+.5*k)}};
 orbit(false);
 /* long layered silk tail: six translucent aurora ribbons that sweep out in S-curves and overlap */
 const veil=(yEnd,len,wid,ph,k,a,lw)=>{const fn=s=>[12-s*len,yEnd*Math.pow(s,1.25)-yEnd*.22*Math.sin(Math.PI*s)+Math.sin(t*2.5-s*4.4-ph)*9*s*(1+fx*(.9-Math.abs(yEnd)/100)),(2.4+Math.sin(Math.PI*Math.min(1,s*1.08))*wid)*(1-s*.55)+.5];
  const p=fa3_rib(18,fn);fkPath(g,p);g.fillStyle=aur(10,0,12-len,yEnd,k,a);g.fill();g.lineWidth=lw;g.strokeStyle=FKO;g.lineJoin='round';g.stroke();
  g.save();fkPath(g,p);g.clip();streak(fa3_line(18,fn),4,.36);fa3_rl(g,()=>fkPath(g,p),-80,80,'#ffffff',.5,1.6,1.6);g.restore();tipB(fn)};
 fa3_at(g,-44,0,sw,()=>{
  veil(-60,74,15,0,0,.7,1.6);veil(60,74,15,2.4,2,.7,1.6);
  veil(-34,80,13,.8,1,.74,1.7);veil(34,80,13,1.6,3,.74,1.7);
  veil(-12,82,10,1.2,0,.84,1.8);veil(12,82,10,2,2,.84,1.8)});
 /* dorsal ribbon: long clean aurora silk sweeping back */
 fa3_at(g,16,-32,Math.sin(t*2)*.05,()=>{const fn=s=>[6-s*92,-s*30-Math.sin(Math.PI*s)*12+Math.sin(t*2.4-s*4)*6*s*W,(3+Math.sin(Math.PI*s)*10)*(1-s*.5)];const p=fa3_rib(14,fn);fkPath(g,p);g.fillStyle=aur(0,0,-86,-30,0,.92);g.fill();g.lineWidth=2;g.strokeStyle=FKO;g.stroke();g.save();fkPath(g,p);g.clip();streak(fa3_line(14,fn),3,.4);g.restore();tipB(fn)});
 /* bold gold crown crest, rooted behind the body's gold band */
 g.save();g.translate(40,-35);g.rotate(-.12);g.scale(2.1,2.1);
 g.beginPath();g.moveTo(-14,8);g.lineTo(-13,-5);g.lineTo(-7,1);g.lineTo(-2,-13);g.lineTo(3,0);g.lineTo(9,-9);g.lineTo(11,3);g.lineTo(16,-3);g.lineTo(16,9);g.closePath();
 fkFill(g,fkLin(g,0,-13,0,8,['#fff8d0','#ffd23a','#c47e0c']),1.3);
 /* bevel: right faces of each point in shadow, left edges lit */
 g.beginPath();g.moveTo(-13,-5);g.lineTo(-7,1);g.lineTo(-10,3);g.closePath();g.moveTo(-2,-13);g.lineTo(3,0);g.lineTo(-.5,2);g.closePath();g.moveTo(9,-9);g.lineTo(11,3);g.lineTo(8.5,3);g.closePath();g.fillStyle='rgba(150,74,6,.45)';g.fill();
 g.beginPath();g.moveTo(-12.4,-3);g.lineTo(-12.4,4);g.moveTo(-2.4,-10);g.lineTo(-4.6,-1);g.moveTo(8.6,-6.5);g.lineTo(7,1);g.moveTo(15.4,-1);g.lineTo(15.4,5);g.strokeStyle='rgba(255,255,240,.85)';g.lineWidth=.8;g.stroke();
 [[-13,-5,'#7ff6ff'],[-2,-13,'#ff6ac8'],[9,-9,'#b48cff'],[16,-3,'#7ff6ff']].forEach(([x,y,c],i)=>{const k=fa3_tw(t,i+1,2.6);g.beginPath();g.arc(x,y,2.2,0,TAU);fkFill(g,fkRad(g,x,y,2.2,['#ffffff',c,shade(c,-.35)]),.8);g.beginPath();g.arc(x-.7,y-.8,.7,0,TAU);g.fillStyle='#fff';g.fill();fkSpark(g,x+.6,y-.6,(1.6+1.6*k)*(1+gl*.6),'#ffffff',.3+.6*k)});
 g.restore();
 /* long trailing pelvic + anal ribbons (behind) */
 fa3_at(g,12,30,Math.sin(t*2.4)*.06,()=>{const fn=s=>[2-s*56,s*40+Math.sin(t*2.7-s*4+.6)*5*s*W,(2.6+Math.sin(Math.PI*s)*6)*(1-s*.45)];const p=fa3_rib(10,fn);fkPath(g,p);g.fillStyle=aur(0,0,-54,40,1,.9);g.fill();g.lineWidth=2;g.strokeStyle=FKO;g.stroke();g.save();fkPath(g,p);g.clip();streak(fa3_line(10,fn),3,.38);g.restore();tipB(fn)});
 fa3_at(g,-16,28,Math.sin(t*2.2)*.06,()=>{const fn=s=>[4-s*66,s*22+Math.sin(t*2.6-s*4+1)*5*s*W,(3+Math.sin(Math.PI*s)*6.5)*(1-s*.5)];const p=fa3_rib(10,fn);fkPath(g,p);g.fillStyle=aur(0,0,-62,22,3,.9);g.fill();g.lineWidth=2;g.strokeStyle=FKO;g.stroke();g.save();fkPath(g,p);g.clip();streak(fa3_line(10,fn),3,.38);g.restore();tipB(fn)});
 /* body */
 const BP=[98,2,88,-22,54,-38,6,-38,-32,-26,-50,-9,-50,9,-32,26,6,36,54,34,88,18],body=()=>fkPath(g,BP),PT=fa3_spl(BP),top=x=>fa3_edge(PT,x,true);
 body();fkFill(g,fkLin(g,0,-38,0,36,['#ddd2ff','#f6f2ff','#f1eaff','#c8baf0']),3);
 g.save();body();g.clip();
 /* soft iridescent wash over the whole body */
 const iw=g.createLinearGradient(-50+sh*20,-30,100+sh*20,30);iw.addColorStop(0,'rgba(127,246,255,.26)');iw.addColorStop(.35,'rgba(170,140,255,.2)');iw.addColorStop(.7,'rgba(255,150,220,.24)');iw.addColorStop(1,'rgba(255,226,122,.2)');g.fillStyle=iw;g.fillRect(-60,-50,170,100);
 fa3_tex(g,body,-50,62,-38,38,7,'#8a70c8','#ffffff',.2);
 /* aurora patches */
 const pat=()=>{fa3_blob(g,[-56,-12,-34,-38,6,-44,40,-42,52,-30,38,-14,22,-4,6,-14,-12,2,-30,10,-46,4]);fa3_blob(g,[-24,18,-4,6,20,10,34,24,12,42,-20,38],1);fa3_blob(g,[-56,8,-44,14,-38,30,-56,26],1)};
 /* soft luminous halo bleeding from the patch edges onto the pale body */
 const hq=g.createLinearGradient(-60,0,60,0);hq.addColorStop(0,'rgba(90,230,255,1)');hq.addColorStop(.5,'rgba(170,120,255,1)');hq.addColorStop(1,'rgba(255,120,210,1)');
 [[16,.1],[10,.14],[5,.2]].forEach(([w,a])=>{pat();g.strokeStyle=hq;g.globalAlpha=a+gl*.1+.04*Math.sin(t*2);g.lineWidth=w;g.lineJoin='round';g.stroke()});g.globalAlpha=1;
 const pq=g.createLinearGradient(-60+sh*14,-30,80+sh*14,20);pq.addColorStop(0,'#26d8ff');pq.addColorStop(.35,'#6a44ff');pq.addColorStop(.65,'#ff4ec0');pq.addColorStop(1,'#ffc430');
 pat();g.fillStyle=pq;g.fill();
 /* starfield inside the patches */
 g.save();pat();g.clip();
 /* deep night core so the stars glow, then drifting luminous nebula clouds */
 g.fillStyle=fkLin(g,0,-44,0,42,['rgba(20,10,70,.34)','rgba(20,10,70,.06)','rgba(20,10,70,.3)']);g.fillRect(-60,-50,120,100);
 g.globalCompositeOperation='lighter';[[-30+Math.sin(t*.6)*8,-24,24,'#9ff8ff'],[24+Math.sin(t*.5+2)*8,-30,22,'#ffb0ea'],[6+Math.sin(t*.7+4)*6,24,18,'#fff0a8'],[-50,16,14,'#c0a8ff']].forEach(([x,y,r,c])=>{const q=g.createRadialGradient(x,y,0,x,y,r);q.addColorStop(0,fa3_rgba(c,.5+gl*.2));q.addColorStop(1,fa3_rgba(c,0));g.fillStyle=q;g.fillRect(x-r,y-r,r*2,r*2)});
 /* shimmering aurora band drifting through the patches */
 const ax=((t*30)%200)-100,aq=g.createLinearGradient(ax-26,-40,ax+26,40);aq.addColorStop(0,'rgba(255,255,255,0)');aq.addColorStop(.5,`rgba(220,255,255,${.3+gl*.2})`);aq.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=aq;g.fillRect(-60,-50,170,100);
 g.globalCompositeOperation='source-over';
 const st=[[-38,-12],[-22,-26],[-6,-30],[12,-34],[30,-30],[44,-26],[-28,-4],[0,-20],[22,-16],[-8,22],[8,30],[18,20],[-14,14],[-46,18],[36,-36],[-50,-4],[-44,-22],[-14,-38],[4,-40],[26,-38],[-34,-30],[14,-26],[-2,16],[26,30],[-18,30],[-52,22],[38,-20],[-10,-8]];
 g.beginPath();st.forEach(([x,y],i)=>{const r=i%4?.8:1.3;g.moveTo(x+r,y);g.arc(x,y,r,0,TAU)});g.fillStyle='rgba(255,255,255,.5)';g.fill();
 st.forEach(([x,y],i)=>{const k=fa3_tw(t,i,2.8+(i%3)*.7);if(k<.35)return;g.globalAlpha=k;g.beginPath();g.arc(x,y,i%3?1.2:1.8,0,TAU);g.fillStyle='#fff';g.fill()});g.globalAlpha=1;
 /* glowing constellation lines */
 const cl=()=>{g.beginPath();g.moveTo(-38,-12);g.lineTo(-22,-26);g.lineTo(-6,-30);g.lineTo(12,-34);g.lineTo(22,-16);g.moveTo(12,-34);g.lineTo(30,-30);g.lineTo(44,-26);g.moveTo(-8,22);g.lineTo(8,30);g.lineTo(18,20);g.lineTo(-2,16);g.moveTo(-46,18);g.lineTo(-52,22)};
 cl();g.strokeStyle='rgba(200,240,255,.28)';g.lineWidth=3;g.stroke();cl();g.strokeStyle='rgba(255,255,255,.8)';g.lineWidth=.9;g.stroke();
 [[-22,-26],[12,-34],[8,30],[-46,18],[44,-26]].forEach(([x,y],i)=>fkSpark(g,x,y,3.8*(.6+.6*fa3_tw(t,i+4,3))*(1+gl*.4),'#ffffff',.95));
 g.restore();
 pat();g.strokeStyle='rgba(255,255,255,.55)';g.lineWidth=3.4;g.stroke();pat();g.strokeStyle='#ffe9a8';g.lineWidth=1.3;g.stroke();
 /* scales shimmer + sweeping sheen */
 fkScales(g,body,-50,60,-36,36,10,'#8a70c8',.12);
 const bx=((t*40)%260)-130;const bq=g.createLinearGradient(bx-20,0,bx+20,0);bq.addColorStop(0,'rgba(255,255,255,0)');bq.addColorStop(.5,'rgba(255,255,255,.45)');bq.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=bq;g.fillRect(bx-20,-50,40,100);
 /* gold crown base band rooted along the back, set with gems */
 const bxs=[];for(let x=8;x<=74;x+=3)bxs.push(x);
 const bandP=()=>{g.beginPath();bxs.forEach((x,j)=>j?g.lineTo(x,top(x)-3):g.moveTo(x,top(x)-3));for(let j=bxs.length-1;j>=0;j--)g.lineTo(bxs[j],top(bxs[j])+7.5);g.closePath()};
 bandP();g.fillStyle=fkLin(g,0,-42,0,-28,['#fff6c0','#ffd23a','#b8700a']);g.fill();
 g.beginPath();bxs.forEach((x,j)=>j?g.lineTo(x,top(x)+7.5):g.moveTo(x,top(x)+7.5));g.strokeStyle=FKO;g.lineWidth=1.8;g.stroke();
 g.beginPath();bxs.forEach((x,j)=>j?g.lineTo(x,top(x)+2.2):g.moveTo(x,top(x)+2.2));g.strokeStyle='rgba(255,255,235,.85)';g.lineWidth=1;g.stroke();
 g.beginPath();bxs.forEach((x,j)=>j?g.lineTo(x,top(x)+9.5):g.moveTo(x,top(x)+9.5));g.strokeStyle='rgba(120,70,200,.22)';g.lineWidth=3;g.stroke();
 g.restore();
 [[18,'#7ff6ff',2.6],[40,'#ff5ab8',3.6],[61,'#b48cff',2.6]].forEach(([x,c,r],i)=>{const y=top(x)+3.4;g.beginPath();g.arc(x,y,r+1.2,0,TAU);fkFill(g,'#ffd23a',1.1);fa3_gem(g,x,y,r,c);const k=fa3_tw(t,i+7,2.4);fkSpark(g,x+r*.5,y-r*.5,(2+2.4*k)*(1+gl*.6),'#ffffff',.3+.6*k)});
 fkShade(g,body,6,38,'#6a50b8',.3);
 fa3_rl(g,body,-40,-12,'#ffd8f4',.8,3.4,3);fa3_rl(g,body,38,14,'#8af4ff',.7,-3.2,2.6);
 fkHi(g,body,.75,3.4);
 fa3_glint(g,74,-26,3.6,-.35,.9);fa3_glint(g,-26,-22,2.4,-.6,.6);
 fa3_gill(g,58,-24,22,11,.45);
 /* gold-trimmed gill cover */
 g.beginPath();g.moveTo(61,-20);g.quadraticCurveTo(50,-1,61,18);g.strokeStyle='rgba(255,214,90,.9)';g.lineWidth=1.4;g.stroke();
 [[-12],[0],[12]].forEach(([y],i)=>{const x=55.6+Math.abs(y)*.18;g.beginPath();g.arc(x,y,1.6,0,TAU);fkFill(g,'#ffe27a',.9)});
 /* long trailing pectoral ribbon */
 fa3_at(g,46,16,Math.sin(t*2.6)*.1,()=>{const fn=s=>[2-s*62,4+s*40+Math.sin(t*2.8-s*4)*6*s*W,(3+Math.sin(Math.PI*s)*7.5)*(1-s*.45)];const p=fa3_rib(12,fn);fkPath(g,p);fkFill(g,silk(0,0,-60,44),2.2);g.save();fkPath(g,p);g.clip();streak(fa3_line(12,fn),3,.4);g.restore();tipB(fn)});
 /* two short gold barbels curling outward */
 const bc=Math.sin(t*2.4)*1.6;
 fa3_whisk(g,[95,7],[102,13],[108,21],[105+bc,28],2.3,.7,fkLin(g,95,7,105,28,['#fff4fa','#ffb0dc','#ff7ac4']),1.5);
 fa3_whisk(g,[89,9],[91,17],[88,25],[82-bc,29],2.3,.7,fkLin(g,89,9,82,29,['#fff4fa','#ffb0dc','#ff7ac4']),1.5);
 fa3_eye(g,72,-10,11.5,'#8a44e0',.3);
 fa3_smile(g,93,6,5,null,'rgba(255,130,200,.75)');
 /* sparkles drifting off the silk tail */
 for(let i=0;i<6;i++){const u=((t*.35+i/6)%1),x=-56-u*54,y=Math.sin(i*2.1)*40*u+Math.sin(t*2+i)*4,a=Math.sin(Math.PI*u);fkSpark(g,x,y,(2.5+2.5*a)*(1+gl*.5),FA3_AUR[(i+1)%4],.85*a)}
 /* sparkles orbiting the crown; more and brighter with glow */
 const nc=3+Math.round(gl*3);for(let i=0;i<nc;i++){const a=t*1.3+i*TAU/nc,x=40+Math.cos(a)*(30+gl*6),y=-60+Math.sin(a)*9,k=fa3_tw(t,i+11,3.6);fkSpark(g,x,y,(2.6+2.4*k)*(1+gl*.7)*(Math.sin(a)>0?1:.7),FA3_AUR[i%4],(.45+.5*k)*(Math.sin(a)>0?1:.7)+gl*.2)}
 orbit(true);
 if(gl>0)fkGlow(g,40,-10,66,'#ffffff',gl*.35);
};

/* ---------- 23 Moonmaw (Legendary) ---------- */
/* silver cone barnacle: contact shadow, plated cone with a lit left face, dark opening with a bright rim */
function fa3_barn(g,x,y,r,a){g.save();g.translate(x,y);g.rotate(a);
 g.beginPath();g.ellipse(r*.12,r*.32,r*1.15,r*.42,0,0,TAU);g.fillStyle='rgba(2,4,24,.45)';g.fill();
 g.beginPath();g.moveTo(-r,r*.2);g.quadraticCurveTo(-r*.9,-r*.7,-r*.42,-r*1.25);g.lineTo(r*.42,-r*1.25);g.quadraticCurveTo(r*.9,-r*.7,r,r*.2);g.quadraticCurveTo(0,r*.5,-r,r*.2);g.closePath();
 fkFill(g,fkLin(g,-r,0,r,0,['#ffffff','#d0dcf2','#8a9ac0','#4a587e']),1.4);
 g.beginPath();g.moveTo(-r*.3,r*.1);g.lineTo(-r*.22,-r*1.1);g.moveTo(r*.3,r*.1);g.lineTo(r*.22,-r*1.1);g.moveTo(-r*.92,-r*.2);g.quadraticCurveTo(0,0,r*.92,-r*.2);g.strokeStyle='rgba(40,50,90,.55)';g.lineWidth=.9;g.stroke();
 g.beginPath();g.moveTo(-r*.74,r*.05);g.quadraticCurveTo(-r*.7,-r*.62,-r*.4,-r*1.05);g.strokeStyle='rgba(255,255,255,.95)';g.lineWidth=Math.max(.9,r*.2);g.lineCap='round';g.stroke();
 g.beginPath();g.ellipse(0,-r*1.25,r*.46,r*.2,0,0,TAU);g.fillStyle='#0c1236';g.fill();g.strokeStyle='rgba(230,240,255,.85)';g.lineWidth=.9;g.stroke();g.restore()}
/* barnacle seen from above, crusted on the hide: shadowed plated ring, lit upper-left, dark aperture */
function fa3_barnTop(g,x,y,r){g.beginPath();g.arc(x+r*.2,y+r*.3,r*1.12,0,TAU);g.fillStyle='rgba(2,4,24,.45)';g.fill();
 g.beginPath();for(let i=0;i<7;i++){const a=i*TAU/7+x,rr=r*(i%2?.9:1);i?g.lineTo(x+Math.cos(a)*rr,y+Math.sin(a)*rr):g.moveTo(x+Math.cos(a)*rr,y+Math.sin(a)*rr)}g.closePath();fkFill(g,fkLin(g,x-r,y-r,x+r,y+r,['#ffffff','#bccae6','#56648c']),1.3);
 g.beginPath();g.arc(x,y,r*.48,0,TAU);g.fillStyle='#0c1236';g.fill();g.strokeStyle='rgba(230,240,255,.8)';g.lineWidth=.8;g.stroke();
 g.beginPath();g.arc(x,y,r*.78,Math.PI*1.05,Math.PI*1.6);g.strokeStyle='rgba(255,255,255,.95)';g.lineWidth=Math.max(.8,r*.18);g.lineCap='round';g.stroke()}
/* a torn gap in a fin membrane (drawn dark, like seeing through to the water) */
function fa3_tear(g,x,y,w,h,rot){g.save();g.translate(x,y);g.rotate(rot||0);const P=[-w,0,-w*.5,-h*.9,w*.1,-h*.6,w*.6,-h,w,-h*.1,w*.4,h*.7,-w*.2,h,-w*.7,h*.5];
 g.beginPath();for(let i=0;i<P.length;i+=2)i?g.lineTo(P[i],P[i+1]):g.moveTo(P[i],P[i+1]);g.closePath();g.fillStyle='#17134c';g.fill();g.strokeStyle=FKO;g.lineWidth=1.3;g.lineJoin='round';g.stroke();
 g.beginPath();g.moveTo(-w*.7,h*.5);g.lineTo(-w*.2,h);g.lineTo(w*.4,h*.7);g.strokeStyle='rgba(190,214,255,.6)';g.lineWidth=.9;g.stroke();g.restore()}
FISHART.moonmaw=(g,t,o)=>{const gl=o.glow||0,fx=o.flex||0,sw=fkSway(o,2,.1),fl=Math.sin(t*3)*.08,mp=.5+.5*Math.sin(t*1.6);
 fa3_bend(g,t,o);
 fkGlow(g,0,0,130+gl*16,'#5a7aff',.13+gl*.35);
 const finG=(x0,y0,x1,y1)=>fkLin(g,x0,y0,x1,y1,['#0a1048','#1e3286','#5a7ad0','#9ab4f0']);
 /* tattered tail: deep ragged notches and torn gaps */
 fa3_at(g,-66,0,sw,()=>{const P=[-46,-58,-35,-46,-50,-38,-38,-30,-44,-22,-35,-15,-51,-6,-38,2,-47,10,-35,18,-50,28,-36,36,-47,46,-37,50,-44,58];
  const p=()=>{g.beginPath();g.moveTo(14,-10);g.quadraticCurveTo(-12,-28,-46,-58);for(let i=2;i<P.length;i+=2)g.lineTo(P[i],P[i+1]);g.quadraticCurveTo(-12,28,14,10);g.closePath()};
  p();fkFill(g,finG(10,0,-50,0),2.6);fa3_ribs(g,p,8,0,[-46,-56,-48,-38,-50,-6,-50,28,-44,52],'#04081e',.45);fa3_fx(g,p,8,0,[-46,-58,-46,-56,-48,-38,-50,-6,-50,28,-44,52,-44,58],'#c8dcff',.5,58);
  fa3_rim(g,p,'rgba(190,214,255,.5)',3,2.6);fa3_tear(g,-30,-30,4.5,2.6,-.7);fa3_tear(g,-33,24,5,2.4,.6);fa3_tear(g,-24,4,3,1.8,.1)});
 /* long dorsal + anal fins set back, ragged and torn */
 fa3_at(g,-20,-42,fl*.5,()=>{const p=()=>{g.beginPath();g.moveTo(30,6);g.quadraticCurveTo(10,-26,-20,-30);g.lineTo(-21,-18);g.lineTo(-30,-27);g.lineTo(-33,-15);g.lineTo(-41,-20);g.lineTo(-40,-10);g.lineTo(-48,-11);g.quadraticCurveTo(-40,4,-34,16);g.closePath()};p();fkFill(g,finG(0,10,0,-30),2.5);fa3_ribs(g,p,0,10,[-20,-30,-30,-26,-41,-19,6,-22],'#04081e',.42);fa3_fx(g,p,0,10,[20,-12,6,-22,-20,-30,-30,-26,-41,-19],'#c8dcff',.45,40);fa3_rim(g,p,'rgba(190,214,255,.45)',3,2.5);fa3_tear(g,-6,-14,3.8,2,-.4)});
 fa3_at(g,-26,38,-fl*.6,()=>{const p=()=>{g.beginPath();g.moveTo(26,-6);g.quadraticCurveTo(6,22,-22,26);g.lineTo(-23,15);g.lineTo(-32,24);g.lineTo(-35,12);g.lineTo(-42,14);g.quadraticCurveTo(-36,-4,-30,-10);g.closePath()};p();fkFill(g,finG(0,-6,0,26),2.5);fa3_ribs(g,p,0,-8,[-20,26,-32,23,-41,12,8,18],'#04081e',.42);fa3_fx(g,p,0,-8,[16,10,8,18,-20,26,-32,23,-41,12],'#c8dcff',.45,38);fa3_rim(g,p,'rgba(190,214,255,.4)',3,2.5);fa3_tear(g,-10,12,3.6,2,.5)});
 /* huge jaw with a cratered moon deep inside */
 const U0=[114,-28],U1=[86,-12],C0=[66,3],L1=[86,18],L0=[114,34],MX=95,MY=3,MR=13;
 const cav=()=>{g.beginPath();g.moveTo(U0[0],U0[1]);g.quadraticCurveTo(U1[0],U1[1],C0[0],C0[1]);g.quadraticCurveTo(L1[0],L1[1],L0[0],L0[1]);g.quadraticCurveTo(119,3,U0[0],U0[1]);g.closePath()};
 cav();g.fillStyle=fkRad(g,MX,MY,34,['#2a2058','#120a2c','#07041a']);g.fill();
 g.save();cav();g.clip();fkGlow(g,MX,MY,34,'#bcd4ff',.4+.3*mp+gl*.3);
 /* moonlight washing the inner jaw and gums */
 const lq=g.createRadialGradient(MX,MY,MR,MX,MY,36);lq.addColorStop(0,`rgba(214,228,255,${.6+.25*mp})`);lq.addColorStop(1,'rgba(214,228,255,0)');
 g.beginPath();g.moveTo(U0[0],U0[1]);g.quadraticCurveTo(U1[0],U1[1],C0[0],C0[1]);g.quadraticCurveTo(L1[0],L1[1],L0[0],L0[1]);g.strokeStyle=lq;g.lineWidth=7;g.stroke();
 g.beginPath();g.arc(MX,MY,MR,0,TAU);g.fillStyle=fkRad(g,MX,MY,MR,['#ffffff','#f2f4ff','#c4cceb']);g.fill();
 /* craters: dark bowl, shadowed upper-left wall, lit lower-right rim */
 [[90,-1,3.4],[99,7,2.6],[100,-4,1.9],[89,8,1.6],[95,-7,1.3],[103,2,1.2]].forEach(([x,y,r])=>{g.beginPath();g.arc(x,y,r,0,TAU);g.fillStyle='rgba(130,140,196,.55)';g.fill();
  g.beginPath();g.arc(x,y,r,Math.PI*.95,Math.PI*1.8);g.strokeStyle='rgba(80,88,150,.75)';g.lineWidth=Math.max(.7,r*.35);g.stroke();
  g.beginPath();g.arc(x,y,r,Math.PI*-.1,Math.PI*.7);g.strokeStyle='rgba(255,255,255,.9)';g.lineWidth=Math.max(.6,r*.28);g.stroke()});
 g.beginPath();g.arc(MX,MY,MR,Math.PI*-.35,Math.PI*.55);g.strokeStyle='rgba(150,160,210,.35)';g.lineWidth=3;g.stroke();
 g.restore();
 /* body: a big heavy head tapering to a slim tail */
 const body=()=>{g.beginPath();g.moveTo(U0[0],U0[1]);g.quadraticCurveTo(108,-54,70,-63);g.quadraticCurveTo(16,-72,-30,-46);g.quadraticCurveTo(-62,-28,-74,-8);g.lineTo(-74,8);g.quadraticCurveTo(-60,28,-24,42);g.quadraticCurveTo(36,64,84,55);g.quadraticCurveTo(110,47,L0[0],L0[1]);
  g.quadraticCurveTo(L1[0],L1[1],C0[0],C0[1]);g.quadraticCurveTo(U1[0],U1[1],U0[0],U0[1]);g.closePath()};
 body();fkFill(g,fkLin(g,0,-68,0,58,['#02031a','#080e40','#16266e','#3e5ca8','#a6bae2']),3);
 fkShade(g,body,-20,-68,'#010210',.6);
 fkScales(g,body,-74,74,-52,52,15,'#c8d8ff',.16);
 g.save();body();g.clip();
 /* finer ancient scale ridges inside the big scales, and silver patina speckles */
 fa3_scl(g,body,-74,60,-56,52,7.5,'#9ab4ff',.1,.9,0);
 g.beginPath();for(let i=0;i<52;i++){const x=-70+((i*43)%170),y=-62+((i*31)%118),r=.6+(i%4)*.3;g.moveTo(x+r,y);g.arc(x,y,r,0,TAU)}g.fillStyle='rgba(200,220,255,.3)';g.fill();
 /* slow moonlight caustics rippling across the hide */
 g.globalCompositeOperation='lighter';g.beginPath();for(let k=0;k<3;k++){const x0=((t*14+k*70)%210)-100;g.moveTo(x0,-70);for(let j=1;j<=8;j++){const y=-70+j*17.5;g.lineTo(x0+Math.sin(j*1.3+t*1.1+k)*7+j*2,y)}}g.strokeStyle=`rgba(170,200,255,${.07+gl*.1})`;g.lineWidth=4;g.stroke();g.globalCompositeOperation='source-over';
 /* pale lip band around the great jaw, brightest nearest the moon */
 g.beginPath();g.moveTo(U0[0],U0[1]);g.quadraticCurveTo(U1[0],U1[1],C0[0],C0[1]);g.quadraticCurveTo(L1[0],L1[1],L0[0],L0[1]);g.strokeStyle='#8ea4dc';g.lineWidth=7;g.stroke();
 const lb=g.createRadialGradient(MX,MY,6,MX,MY,40);lb.addColorStop(0,'rgba(255,255,255,.95)');lb.addColorStop(1,'rgba(230,238,255,.35)');g.strokeStyle=lb;g.lineWidth=2.6;g.stroke();
 /* silver-blue rim light along the back and belly */
 g.save();g.translate(0,4.5);body();g.strokeStyle='rgba(170,204,255,.55)';g.lineWidth=3.2;g.stroke();g.restore();
 g.save();g.translate(0,-4);body();g.strokeStyle='rgba(226,236,255,.6)';g.lineWidth=3;g.stroke();g.restore();
 /* glowing ancient glyphs along the flank, breathing with a slow pulse */
 const GL=[[-52,-4,0],[-32,2,1],[-11,-3,2],[9,1,3],[28,-4,4]];
 const glyph=(x,y,k)=>{g.beginPath();if(k===0){g.arc(x,y-1,6.5,0,Math.PI);g.quadraticCurveTo(x,y+3,x+6.5,y-1)}
  else if(k===1){for(let i=0;i<=26;i++){const a=i*.36,r=.8+a*.66,px=x+Math.cos(a)*r,py=y+Math.sin(a)*r;i?g.lineTo(px,py):g.moveTo(px,py)}}
  else if(k===2){g.arc(x,y,7,0,TAU);for(let i=0;i<=5;i++){const a=-Math.PI/2+i*TAU*2/5,px=x+Math.cos(a)*5,py=y+Math.sin(a)*5;i?g.lineTo(px,py):g.moveTo(px,py)}}
  else if(k===3){g.moveTo(x,y+7);g.lineTo(x,y-7);g.moveTo(x-5,y-6);g.lineTo(x,y-1);g.lineTo(x+5,y-6)}
  else{g.moveTo(x,y-7);g.lineTo(x+5,y-1);g.lineTo(x,y+4);g.lineTo(x-5,y-1);g.closePath();g.moveTo(x-1.5,y+3);g.lineTo(x-5,y+7.5);g.moveTo(x+1.5,y+3);g.lineTo(x+5,y+7.5)}};
 g.lineCap='round';g.lineJoin='round';
 /* engraved rune band framing the glyphs */
 [-14,12].forEach(dy=>{g.beginPath();g.moveTo(-64,dy-2);g.quadraticCurveTo(-10,dy-6,40,dy-4);g.strokeStyle=`rgba(120,210,255,${.24+.16*Math.sin(t*1.6)+gl*.2})`;g.lineWidth=1.3;g.stroke()});
 GL.forEach(([x,y,k],i)=>{const pz=.5+.5*Math.sin(t*1.6-i*.7),ra=Math.min(1,.5+.45*pz+gl*.5),R=11+5*pz;
  g.globalCompositeOperation='lighter';const hq=g.createRadialGradient(x,y,0,x,y,R);hq.addColorStop(0,`rgba(90,200,255,${.3*ra})`);hq.addColorStop(1,'rgba(90,200,255,0)');g.fillStyle=hq;g.fillRect(x-R,y-R,R*2,R*2);g.globalCompositeOperation='source-over';
  glyph(x,y,k);g.strokeStyle=`rgba(100,220,255,${ra*.4})`;g.lineWidth=5.5;g.stroke();glyph(x,y,k);g.strokeStyle=`rgba(200,248,255,${ra})`;g.lineWidth=1.9;g.stroke()});
 g.restore();
 fkShade(g,body,16,60,'#1a2a6a',.22);
 g.beginPath();g.moveTo(U0[0],U0[1]);g.quadraticCurveTo(U1[0],U1[1],C0[0],C0[1]);g.quadraticCurveTo(L1[0],L1[1],L0[0],L0[1]);g.strokeStyle=FKO;g.lineWidth=3;g.stroke();
 fkHi(g,body,.5,3.6);
 fa3_glint(g,84,-50,4,-.35,.8);fa3_glint(g,-20,-46,2.6,-.5,.5);
 /* crusted clusters of silver cone barnacles along the head and back */
 [[[114,-28],[108,-54],[70,-63],[[.36,4.4,0],[.45,2.8,1.5],[.53,5.6,0],[.62,3.4,1.5],[.7,2.6,-.5],[.49,2.2,5],[.58,2,5.5]]],
  [[70,-63],[16,-72],[-30,-46],[[.05,3.4,0],[.13,6,.5],[.21,3.8,1],[.28,6.6,0],[.36,4.2,1.5],[.43,3,0],[.5,5,.5],[.58,3,1],[.66,3.8,0],[.74,2.4,0],[.18,2.4,5.5],[.32,2.6,5.5],[.46,2.2,5]]]].forEach(([a,b,c,list])=>list.forEach(([s,r,dy])=>{
  const q=fa3_quad(a,b,c,s),L=Math.hypot(q[2],q[3])||1,nx=q[3]/L,ny=-q[2]/L;fa3_barn(g,q[0]-nx*(r*.5+dy*.8),q[1]-ny*(r*.5+dy*.8),r*1.3,Math.atan2(ny,nx)+Math.PI/2)}));
 [[86,-44,4.2],[94,-37,3],[97,-47,3.4],[80,-53,2.6],[90,-52,2.2],[18,-58,4],[28,-61,2.8],[8,-55,2.6],[-4,-50,3.2],[38,-60,2.4],[12,-63,2]].forEach(([x,y,r])=>fa3_barnTop(g,x,y,r));
 fa3_gill(g,48,-40,36,16,.6);g.globalAlpha=1;fa3_gill(g,40,-32,30,12,.35);
 /* fangs along both jaws, lit by the moon */
 const tq=g.createRadialGradient(MX,MY,4,MX,MY,44);tq.addColorStop(0,'#ffffff');tq.addColorStop(.5,'#eef3ff');tq.addColorStop(1,'#8e9cc8');g.fillStyle=tq;g.strokeStyle=FKO;g.lineWidth=1.3;
 const up=[.14,.36,.57,.78].map(s=>{const q=fa3_quad(U0,U1,C0,s);return [q[0]-3.4,q[1]-1,q[0]+3.4,q[1]-1.5,q[0]+.4,q[1]+9-s*3]}),dn=[.3,.52,.72,.9].map(s=>{const q=fa3_quad(C0,L1,L0,s);return [q[0]-3.4,q[1]+1.5,q[0]+3.4,q[1]+1,q[0]+.4,q[1]-7-s*2]});
 up.concat(dn).forEach(T=>{g.beginPath();g.moveTo(T[0],T[1]);g.lineTo(T[2],T[3]);g.lineTo(T[4],T[5]);g.closePath();g.fill();g.stroke()});
 g.beginPath();up.concat(dn).forEach(T=>{const sx=T[4]<MX?1:-1;g.moveTo((T[0]+T[2])/2+sx*1.2,(T[1]+T[3])/2);g.lineTo(T[4]+sx*.4,T[5])});g.strokeStyle='rgba(255,255,255,.9)';g.lineWidth=.9;g.stroke();
 /* tattered ribbed fan pectoral */
 fa3_at(g,32,22,Math.sin(t*3)*.12,()=>{const p=()=>{g.beginPath();g.moveTo(8,-6);g.quadraticCurveTo(-14,-7,-36,5);g.lineTo(-29,10);g.lineTo(-44,17);g.lineTo(-33,21);g.lineTo(-42,32);g.lineTo(-28,29);g.lineTo(-30,42);g.lineTo(-18,33);g.quadraticCurveTo(-2,22,8,8);g.closePath()};
  p();fkFill(g,fkLin(g,4,0,-40,30,['#7a98e0','#1e2e7a']),2.4);fa3_ribs(g,p,5,1,[-36,5,-44,17,-42,32,-30,42],'#04081e',.45);fa3_fx(g,p,5,1,[-36,5,-44,17,-42,32,-30,42],'#d8e6ff',.5,46);fa3_rim(g,p,'rgba(200,220,255,.45)',2.6,2.4);fa3_tear(g,-22,16,3.4,1.8,.7)});
 /* long thick whiskers rooted at the jaws, tapering and swaying */
 const c1=Math.sin(t*1.8)*6*(1+fx),c2=Math.sin(t*1.8+1)*6*(1+fx);
 const wk=(a,b,c,d,f)=>{fa3_whisk(g,a,b,c,d,4.2,1,f,1.8);g.beginPath();for(let i=0;i<=12;i++){const q=fa3_cub(a,b,c,d,i/12*.85);i?g.lineTo(q[0],q[1]-.9):g.moveTo(q[0],q[1]-.9)}g.strokeStyle='rgba(255,255,255,.75)';g.lineWidth=1.1;g.lineCap='round';g.stroke()};
 wk([104,-26],[118,-52],[80,-70+c1*.4],[30+c1,-78+c1*.2],fkLin(g,104,-26,30,-78,['#f2f6ff','#a8bce8','#6a80c0']));
 wk([103,33],[118,56],[80,72+c2*.4],[28+c2,78-c2*.2],fkLin(g,103,33,28,78,['#f2f6ff','#a8bce8','#6a80c0']));
 [[104,-26],[103,33]].forEach(([x,y])=>{g.beginPath();g.arc(x,y,4.4,0,TAU);fkFill(g,fkRad(g,x,y,4.4,['#e8f0ff','#8aa0d8','#4a5c98']),1.5)});
 /* wise ancient eye: gold iris, heavy lid */
 fa3_eye(g,64,-32,12.5,'#ffb82a',.2);
 g.beginPath();g.arc(64,-32,13.6,Math.PI*1.04,Math.PI*1.96);g.quadraticCurveTo(64,-35,51,-33.5);g.closePath();fkFill(g,'#121e5c',2.6);
 g.beginPath();g.moveTo(51,-33.5);g.quadraticCurveTo(64,-37,77.4,-33);g.strokeStyle='rgba(200,220,255,.55)';g.lineWidth=1.2;g.stroke();
 g.beginPath();g.moveTo(48,-48);g.quadraticCurveTo(64,-54,80,-46);g.moveTo(52,-53);g.quadraticCurveTo(64,-58,74,-53);g.strokeStyle='rgba(200,220,255,.5)';g.lineWidth=1.5;g.stroke();
 g.beginPath();g.arc(66,-20,13,Math.PI*.15,Math.PI*.85);g.strokeStyle='rgba(10,10,40,.45)';g.lineWidth=1.3;g.stroke();
 /* moon-glow spilling out of the mouth onto the jaws */
 fkGlow(g,100,3,48,'#dce8ff',.18+.2*mp+gl*.45);
 /* drifting moonlight motes */
 for(let i=0;i<6;i++){const u=((t*.12+i/6)%1),x=-90+i*36+Math.sin(t*.7+i)*6,y=70-u*150,a=Math.sin(Math.PI*u);fkSpark(g,x,y,(2.5+2*a)*(1+gl*.5),i%2?'#bcd4ff':'#ffffff',.75*a)}
 [[-84,-60,5],[100,-58,4],[-98,46,4.4]].forEach(([x,y,r],i)=>{const k=fa3_tw(t,i,1.8);fkSpark(g,x,y-k*3,r*(.6+.5*k)*(1+gl*.5),'#ffffff',.3+.6*k)});
};

/* ---------- 24 Tidecrown (Legendary) ---------- */
/* flowing cape fin path: base front (x0,y0) -> top edge -> tip (tx,ty) -> wavy hem -> rear base (xr,yr); sg -1 dorsal, 1 anal */
function fa3_cape(g,t,W,sg,x0,y0,xr,yr,tx,ty,pk,ph,lo){lo=lo||0;return ()=>{const bl=Math.sin(t*2.2-ph)*5*W,b2=Math.sin(t*2.2-ph+.9)*4*W;
 g.beginPath();g.moveTo(x0,y0);g.bezierCurveTo(x0-16,sg*pk,tx+52,sg*(pk-2)+b2,tx,ty+bl);
 let px=tx,py=ty+bl;const N=5;for(let i=1;i<=N;i++){const s=i/N,nx=tx+(xr-tx)*s,ny=ty+bl+(yr-ty-bl)*s-sg*Math.sin(Math.PI*s)*(4+lo),mx=(px+nx)/2,my=(py+ny)/2+Math.sin(t*3-s*6-ph)*1.5*W;g.quadraticCurveTo(mx+2,my-sg*3.5,nx,ny);px=nx;py=ny}
 g.quadraticCurveTo((xr+x0)/2,sg*20,x0,y0);g.closePath()}}
/* faceted gem: hexagonal outline, lit table, facet lines and a sparkle */
function fa3_facet(g,x,y,r,c,t,i,gl){const H=[];for(let k=0;k<6;k++){const a=k*TAU/6+Math.PI/6;H.push([x+Math.cos(a)*r,y+Math.sin(a)*r*.86])}
 g.beginPath();H.forEach(([a,b],k)=>k?g.lineTo(a,b):g.moveTo(a,b));g.closePath();fkFill(g,fkLin(g,x-r,y-r,x+r,y+r,[shade(c,.5),c,shade(c,-.45)]),1.4);
 const T=H.map(([a,b])=>[x+(a-x)*.5,y-r*.08+(b-y)*.5]);
 g.beginPath();T.forEach(([a,b],k)=>k?g.lineTo(a,b):g.moveTo(a,b));g.closePath();g.fillStyle=fa3_rgba(shade(c,.6),.85);g.fill();
 g.beginPath();for(let k=0;k<6;k++){g.moveTo(H[k][0],H[k][1]);g.lineTo(T[k][0],T[k][1])}g.strokeStyle=fa3_rgba(shade(c,-.5),.6);g.lineWidth=.7;g.stroke();
 g.beginPath();g.moveTo(T[3][0],T[3][1]);g.lineTo(T[4][0],T[4][1]);g.lineTo(T[5][0],T[5][1]);g.strokeStyle='rgba(255,255,255,.95)';g.lineWidth=.9;g.stroke();
 const k=fa3_tw(t,i,2.4);fkSpark(g,x-r*.3,y-r*.35,(r*.7+r*.8*k)*(1+gl*.5),'#ffffff',.45+.55*k)}
FISHART.tidecrown=(g,t,o)=>{const gl=o.glow||0,fx=o.flex||0,sw=fkSway(o,2.4,.1),W=1+fx*1.5;
 fa3_bend(g,t,o);
 fkGlow(g,10,-4,128+gl*22,'#ffcf4a',.15+.05*Math.sin(t*2)+gl*.55);
 const sea=(x0,y0,x1,y1)=>fkLin(g,x0,y0,x1,y1,['#0e8a78','#1cb894','#46dcb4','#9af4cc']);
 const gold=(x0,y0,x1,y1)=>fkLin(g,x0,y0,x1,y1,['#ffe9a0','#ffc93a','#d08a10']);
 const trim=(pf,lw)=>fa3_rim(g,pf,'rgba(255,226,122,.92)',lw||4,2.5);
 /* broad veil tail with a scalloped gold hem */
 fa3_at(g,-48,0,sw,()=>{const pf=()=>{const a=Math.sin(t*2.4)*6*W,b=Math.sin(t*2.4+1.2)*6*W;g.beginPath();g.moveTo(12,-12);g.bezierCurveTo(-12,-22,-38,-46+a,-60,-52+a);
   let px=-60,py=-52+a;const N=7;for(let i=1;i<=N;i++){const s=i/N,nx=-60-Math.sin(Math.PI*s)*4+Math.sin(t*3-s*6)*2.5*W,ny=-52+a+(104+b-a)*s,mx=(px+nx)/2,my=(py+ny)/2;g.quadraticCurveTo(mx-7,my,nx,ny);px=nx;py=ny}
   g.bezierCurveTo(-38,46+b,-12,22,12,12);g.closePath()};
  pf();g.fillStyle=fkLin(g,10,0,-64,0,['#1a3cb0','#1c6cd0','#3ab0e0','#a8e8f4']);g.fill();g.save();pf();g.clip();g.globalCompositeOperation='lighter';g.fillStyle=fkLin(g,0,-50,0,50,['rgba(120,200,255,0)','rgba(120,220,255,.22)','rgba(120,200,255,0)']);g.fillRect(-70,-60,90,120);g.restore();fa3_ribs(g,pf,8,0,[-62,-50,-62,-30,-62,-10,-62,10,-62,30,-62,50],'#0a1a5a',.35);fa3_fx(g,pf,8,0,[-62,-56,-62,-50,-62,-30,-62,-10,-62,10,-62,30,-62,50,-62,56],'#d8f8ff',.5,0);trim(pf,4.5)});
 /* layered cape fins: gold drape underneath, sea-green drape over it, both folded and rippling */
 const dG=fa3_cape(g,t,W,-1,36,-48,-38,-24,-106,-42,72,.15,12),dS=fa3_cape(g,t,W,-1,36,-48,-38,-28,-94,-50,72,0);
 const aG=fa3_cape(g,t,W,1,22,46,-36,22,-98,38,66,.95,12),aS=fa3_cape(g,t,W,1,22,46,-36,26,-86,46,66,.8);
 const folds=(pf,sg,ph,dk,lt)=>{g.save();pf();g.clip();for(let k=0;k<6;k++){const x=20-k*20+Math.sin(t*2.2-k*.9-ph)*4*W,q=g.createLinearGradient(x-10,0,x+10,0);q.addColorStop(0,dk);q.addColorStop(.5,'rgba(0,0,0,0)');q.addColorStop(.75,lt);q.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=q;g.fillRect(x-10,sg<0?-90:0,20,90)}g.restore()};
 [[dG,dS,-1,.15],[aG,aS,1,.9]].forEach(([G,S,sg,ph])=>{G();g.fillStyle=gold(0,sg*40,-100,sg*60);g.fill();folds(G,sg,ph,'rgba(140,70,0,.3)','rgba(255,250,200,.35)');fa3_ribs2(g,G,0,sg*36,[-104,sg*44,-84,sg*62,-64,sg*72,-44,sg*72,-24,sg*68],'#7a4a06','#fff4c0',.4);trim(G,3);
  S();g.fillStyle=sea(0,sg*36,-90,sg*58);g.fill();folds(S,sg,ph,'rgba(0,70,60,.32)','rgba(220,255,240,.3)');fa3_ribs2(g,S,0,sg*36,[-88,sg*48,-70,sg*62,-50,sg*66,-30,sg*66,-10,sg*62],'#06463a','#e8fff4',.42);fa3_fx(g,S,0,sg*36,[-96,sg*46,-88,sg*48,-70,sg*62,-50,sg*66,-30,sg*66,-10,sg*62,8,sg*56],'#e8fff0',.45,96);trim(S,4)});
 /* deep discus body with a proud chest: royal-blue back fading to teal */
 const BP=[98,4,90,-28,58,-54,10,-60,-30,-43,-50,-17,-54,0,-50,17,-30,42,10,58,58,52,90,27],body=()=>fkPath(g,BP),PT=fa3_spl(BP);
 body();fkFill(g,fkLin(g,0,-62,0,60,['#08104e','#122486','#1650b4','#18a2c4','#5ee2cc']),3);
 fkShade(g,body,-16,-62,'#050a3a',.45);
 /* large, clean gold-trimmed scales: soft dark under-arc, gold trim, faint teal sheen */
 fa3_scl(g,body,-56,64,-54,58,17,'#04104a',.3,2.2,1.6);
 fa3_scl(g,body,-56,64,-54,58,17,'#ffd34a',.62,1.5,0);
 fa3_scl(g,body,-56,64,-54,58,17,'#b8fff4',.2,1,-2.2);
 g.save();body();g.clip();[[-30,-30],[-6,-40],[18,-20],[-20,10],[6,28],[34,4]].forEach(([x,y],i)=>{const k=fa3_tw(t,i,2.3);fkSpark(g,x,y,(1.8+2.6*k)*(1+gl*.4),'#fff6c8',.25+.7*k)});g.restore();
 g.save();body();g.clip();g.globalCompositeOperation='lighter';const sx=Math.sin(t*1.1)*50;const sq=g.createLinearGradient(sx-30,-40,sx+30,40);sq.addColorStop(0,'rgba(255,220,120,0)');sq.addColorStop(.5,'rgba(255,220,120,.22)');sq.addColorStop(1,'rgba(255,220,120,0)');g.fillStyle=sq;g.fillRect(-70,-70,180,140);g.globalCompositeOperation='source-over';
 /* royal gold band along the back */
 const band=PT.filter(p=>p[1]<-14&&p[0]>-46&&p[0]<84).sort((a,b)=>a[0]-b[0]);
 const bandP=()=>{g.beginPath();band.forEach((p,i)=>{const yy=p[1]+6.5;i?g.lineTo(p[0],yy):g.moveTo(p[0],yy)})};
 bandP();g.strokeStyle=FKO;g.lineWidth=5.4;g.stroke();bandP();g.strokeStyle='#ffd34a';g.lineWidth=3;g.stroke();bandP();g.strokeStyle='rgba(255,250,210,.7)';g.lineWidth=1.2;g.stroke();
 /* the crown's shadow on the head, so it sits firmly */
 const cx=64,cy=fa3_edge(PT,cx,true),ca=Math.atan2(fa3_edge(PT,cx+4,true)-fa3_edge(PT,cx-4,true),8);
 g.save();g.translate(cx,cy+5);g.rotate(ca);g.beginPath();g.ellipse(2,5,27,6,0,0,TAU);g.fillStyle='rgba(4,8,50,.45)';g.fill();g.restore();
 g.restore();
 band.filter((p,i)=>i%9===4).forEach((p,i)=>{if(p[0]<-30||p[0]>40)return;g.beginPath();g.arc(p[0],p[1]+6.5,2.2,0,TAU);fkFill(g,i%2?'#ff4a6a':'#3ad8ff',1.1)});
 fkShade(g,body,16,62,'#0a3a6a',.3);
 fa3_rl(g,body,-62,-24,'#ffe9a0',.8,3.6,3);fa3_rl(g,body,62,26,'#8afff0',.6,-3.4,2.6);
 fkHi(g,body,.6,3.6);
 fa3_glint(g,89,-6,3,-1.25,.8);fa3_glint(g,-28,-36,2.6,-.7,.55);
 /* pearl necklace tucked along the gill line, clear of the face */
 fa3_gill(g,56,-42,40,16,.5);
 for(let i=0;i<9;i++){const s=i/8,y=-24+s*52,x=46-Math.sin(Math.PI*s)*9;fa3_pearl(g,x,y,i===4?3.8:2.7)}
 fa3_gem(g,33,10,4.6,'#ff4a6a');
 /* clean pectoral, below and behind the necklace */
 fa3_at(g,28,32,Math.sin(t*3)*.12,()=>{const pf=()=>{g.beginPath();g.moveTo(6,-5);g.bezierCurveTo(-10,-10,-32,-2,-42,12);g.bezierCurveTo(-30,20,-8,16,6,6);g.closePath()};pf();g.fillStyle=sea(0,-6,-40,14);g.fill();fa3_ribs(g,pf,4,0,[-40,10,-30,16,-18,14],'#0a4a3a',.35);fa3_fx(g,pf,4,0,[-42,12,-40,10,-30,16,-18,14,-4,10],'#e8fff0',.55,44);trim(pf,3.4)});
 /* glowing gold eye */
 fkGlow(g,70,-14,24,'#ffd34a',.3+.18*Math.sin(t*2.5)+gl*.35);
 fa3_eye(g,70,-14,11.5,'#ffb414',.3);
 g.beginPath();g.arc(72.5,-13,3.4,0,TAU);g.fillStyle='rgba(255,220,90,.35)';g.fill();
 fa3_smile(g,91,12,5,null,'rgba(255,120,140,.75)');
 /* big coral-and-gold crown seated on the head */
 g.save();g.translate(cx,cy+5);g.rotate(ca);g.scale(1.55,1.38);
 /* far rim of the circlet, seen behind the points */
 g.beginPath();g.moveTo(-15,-1);g.quadraticCurveTo(1,-9,17,-1);g.lineTo(17,2);g.quadraticCurveTo(1,-5,-15,2);g.closePath();fkFill(g,'#a8680a',1.4);
 /* coral branches with lit highlights */
 [[-11,-3,-23,-17,-1],[13,-3,25,-17,1]].forEach(([x0,y0,x1,y1,s])=>{const mx=(x0+x1)/2,my=y0-7;
  const br=()=>{g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo(mx,y0-5,x1,y1);g.moveTo(mx,my);g.lineTo(mx+s*5,my-8);g.moveTo(x1-s*1.5,y1+5);g.lineTo(x1-s*7,y1-2)};
  br();g.lineCap='round';g.strokeStyle=FKO;g.lineWidth=5.4;g.stroke();br();g.strokeStyle='#ff5a74';g.lineWidth=3;g.stroke();
  g.save();g.translate(-.6,-.7);br();g.strokeStyle='rgba(255,200,208,.9)';g.lineWidth=1;g.stroke();g.restore();
  [[x1,y1,2.5],[mx+s*5,my-8,2.1],[x1-s*7,y1-2,1.8]].forEach(([x,y,r])=>{g.beginPath();g.arc(x,y,r,0,TAU);fkFill(g,fkRad(g,x,y,r,['#ffe0e4','#ff8a9c','#e04a64']),1.1);g.beginPath();g.arc(x-r*.35,y-r*.35,r*.32,0,TAU);g.fillStyle='#fff';g.fill()})});
 /* crown body with bevelled points: left faces lit, right faces shaded */
 const CR=()=>{g.beginPath();g.moveTo(-15,4);g.lineTo(-15,-14);g.lineTo(-8,-6);g.lineTo(-4,-20);g.lineTo(1,-8);g.lineTo(6,-20);g.lineTo(10,-6);g.lineTo(17,-14);g.lineTo(17,4);g.quadraticCurveTo(1,0,-15,4);g.closePath()};
 CR();fkFill(g,fkLin(g,0,-20,0,4,['#fff6c0','#ffd34a','#d08a10']),2);
 g.save();CR();g.clip();g.beginPath();g.moveTo(-15,-14);g.lineTo(-8,-6);g.lineTo(-11,-2);g.lineTo(-15,-2);g.closePath();g.moveTo(-4,-20);g.lineTo(1,-8);g.lineTo(-2.5,-4);g.closePath();g.moveTo(6,-20);g.lineTo(10,-6);g.lineTo(6.5,-4);g.closePath();g.moveTo(17,-14);g.lineTo(17,-2);g.lineTo(13.5,-3);g.closePath();g.fillStyle='rgba(150,80,6,.42)';g.fill();g.restore();
 g.beginPath();g.moveTo(-13.8,-10);g.lineTo(-13.8,-2);g.moveTo(-4.4,-16);g.lineTo(-6.4,-7);g.moveTo(5.6,-16);g.lineTo(3.8,-7);g.moveTo(15.8,-10);g.lineTo(15.8,-3);g.strokeStyle='rgba(255,255,240,.9)';g.lineWidth=.9;g.stroke();
 /* bevelled band: lit top edge, shaded lower edge, beading */
 g.beginPath();g.moveTo(-15,-2);g.quadraticCurveTo(1,-5,17,-2);g.strokeStyle='#b06a08';g.lineWidth=1.3;g.stroke();
 g.beginPath();g.moveTo(-15,-1.2);g.quadraticCurveTo(1,-4.2,17,-1.2);g.strokeStyle='rgba(255,250,215,.85)';g.lineWidth=.7;g.stroke();
 g.beginPath();g.moveTo(-14,3.2);g.quadraticCurveTo(1,-.8,16,3.2);g.strokeStyle='rgba(150,80,6,.55)';g.lineWidth=1.1;g.stroke();
 g.beginPath();for(let i=0;i<9;i++){const x=-13+i*3.75,y=1.4-Math.sin(i/8*Math.PI)*1.6;g.moveTo(x+.7,y);g.arc(x,y,.7,0,TAU)}g.fillStyle='#fff3b8';g.fill();
 fa3_facet(g,1,-8.6,4,'#ff2a52',t,1,gl);fa3_facet(g,-9.4,-4,2.7,'#2ab8ff',t,2,gl);fa3_facet(g,11.4,-4,2.7,'#22e69a',t,3,gl);
 fa3_pearl(g,-4,-21,2);fa3_pearl(g,6,-21,2);fa3_pearl(g,-15,-15,1.8);fa3_pearl(g,17,-15,1.8);
 g.restore();
 /* floating pearls and rising bubbles */
 [[-76,-70],[92,-58],[-60,72]].forEach(([x,y],i)=>{const b=Math.sin(t*1.4+i*2)*3;fa3_pearl(g,x,y+b,3+i%2)});
 for(let i=0;i<4;i++){const u=((t*.18+i/4)%1),x=-20+i*30+Math.sin(t*1.5+i)*4,y=72-u*150,r=2+i%2*1.4;g.globalAlpha=Math.sin(Math.PI*u)*.8;g.beginPath();g.arc(x,y,r,0,TAU);g.strokeStyle='#d8fff6';g.lineWidth=1.2;g.stroke();g.beginPath();g.arc(x-r*.35,y-r*.35,r*.3,0,TAU);g.fillStyle='#fff';g.fill();g.globalAlpha=1}
 /* golden sparkles */
 [[-84,-50,6],[100,-42,5],[-100,40,5],[22,-80,4.5],[64,70,4.5],[-30,76,4],[106,30,4],[-40,-78,4]].forEach(([x,y,r],i)=>{const k=fa3_tw(t,i,2.7);fkSpark(g,x,y,r*(.6+.6*k)*(1+gl*.6),i%2?'#fff3b0':'#9ffff0',.35+.6*k)});
 if(gl>0)fkGlow(g,60,-50,44,'#fff2b0',gl*.5);
};
