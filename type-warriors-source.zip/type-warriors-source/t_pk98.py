# python3 t_pk98.py [game.html] : Casino 9.8 Penalty Kings (96zq-96zs) - listing, no typing, the ladder and its odds (best play returns
# at most 96% at every rung for every keeper, measured with the game's own pkShot/pkSave), a real run through the UI (shoot, save, cash
# out with the money checked), losing, the Golden Boot, the 20,000 cap, input locks, art and frame cost; plus the 9.8 menus: the tidy
# Choose a mode sheet and the tower defense bar sort.
import asyncio,os,re,sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:500]),flush=True)
    if not ok:FAIL.append(name)
W="new Promise(r=>setTimeout(r,350))"
OPEN=f"async()=>{{lobby();await {W};gameOpen('pk');await {W};CAS.bet=1000;betRefresh();return 1}}"
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E("()=>{RS_ASK=false;WCRELAYS=[];try{ST.perfAsked=1}catch(e){}try{PFW.asked=true}catch(e){}P.gold=100000;P.pk=null;pkStats().seen=1;for(const a of ACH)P.ach[a.id]=1;save()}")
        # ---------------------------------------------------------------- listing and rules
        r=await E(f"async()=>{{casinoOpen();await {W};return [GAMES[1].id,!!TA.pk,!!ICON.pk,GAMES.filter(g=>g.id==='pk').length]}}")
        chk('Penalty Kings is listed right after The Crooked Cue, with its own tile and icon',r==['pk',True,True,1],r)
        r=await E(f"async()=>{{await ({OPEN})();return [!!document.querySelector('#pkc'),document.querySelectorAll('input[type=text],textarea').length,CAS.cap]}}")
        chk('the game opens, has no text input (no typing) and bets up to 5,000',r==[True,0,5000],r)
        r=await E("()=>PK_OPP.map(o=>{const L=pkLadder(o.id);return [o.id,L.length,L.every((m,i)=>i===0||m>L[i-1]),L[0]>1,L[9]]})")
        chk('three keepers, each with a rising ten-rung ladder (Mossback < Gloop < Grimgate at the top)',all(x[1]==10 and x[2] and x[3] for x in r) and r[0][4]<r[1][4]<r[2][4],r)
        r=await E("""()=>{const out={};for(const o of PK_OPP){const N=150000,L=pkLadder(o.id),reach=new Array(11).fill(0);
          for(let n=0;n<N;n++){let k=1;for(;k<=10;k++){let win;if(pkKind(k)==='shoot'){const t=pkTell(o,'shoot');let best=null,bv=-1;for(let c=0;c<3;c++)for(const rr of [0,1]){const v=pkShotP(o,t.T,c,rr,'clean');if(v>bv){bv=v;best=[c,rr]}}win=pkShot(o,t.T,best[0],best[1],'clean').goal}
            else{const t=pkTell(o,'save');let bd=0,bv=-1;for(let d=0;d<3;d++){const v=pkSaveP(o,t.T,d);if(v>bv){bv=v;bd=d}}win=pkSave(o,t.T,bd).win}if(!win)break;reach[k]++}}
          out[o.id]=L.map((m,i)=>+(reach[i+1]/N*m).toFixed(3))}return out}""")
        allv=[v for L in r.values() for v in L]
        chk('perfect play (reading every tell, clean strikes) returns about 95% at every rung for every keeper, never above 100%',max(allv)<.99 and min(allv)>.9,r)
        r=await E("""()=>{const o=pkOpp('gloop');const N=40000;let s=0;for(let i=0;i<N;i++){const t=pkTell(o,'shoot');const c=(Math.random()*3)|0,rr=Math.random()<.5?0:1;s+=pkShot(o,t.T,c,rr,'clean').goal?1:0}
          const rnd=s/N,best=pkBest(o,'shoot');let s2=0;for(let i=0;i<N;i++){const t=pkTell(o,'shoot');s2+=pkShot(o,t.T,1,0,'wild').goal?1:0}return [+rnd.toFixed(3),+best.toFixed(3),s2]}""")
        chk('skill matters: random spots score less than the best spot, and a red strike at the top never scores',r[0]<r[1]-.04 and r[2]==0,r)
        # ---------------------------------------------------------------- a real run through the UI
        r=await E(f"""async()=>{{await ({OPEN})();const g0=P.gold;document.getElementById('pkgo').click();await {W};const ph1=PKDBG.ph(),taken=g0-P.gold,lob=document.getElementById('cb').disabled;
          const T=PKDBG.tell().T;CAS.key[T===0?'e':'q']();PKDBG.needle(.5);const r0=Math.random;Math.random=()=>.99;CAS.key[' ']();Math.random=r0;
          for(let i=0;i<40&&PKDBG.ph()!=='between'&&PKDBG.ph()!=='over';i++)await new Promise(r=>setTimeout(r,100));
          const ph2=PKDBG.ph(),st=PKDBG.step(),cov=document.getElementById('pkco').disabled;const g1=P.gold;document.getElementById('pkco').click();await {W};
          return [ph1,taken,lob,ph2,st,cov,P.gold-g1,Math.floor(1000*PKDBG.L()[0]),PKDBG.ph(),document.getElementById('cb').disabled]}}""")
        chk('a run: the stake is taken and the Lobby locks; a scored kick climbs a rung; Cash out pays bet x rung and unlocks',r[0]=='aim' and r[1]==1000 and r[2] and r[3]=='between' and r[4]==1 and r[5]==False and r[6]==r[7] and r[8]=='over' and r[9]==False,r)
        r=await E(f"""async()=>{{await ({OPEN})();const g0=P.gold;document.getElementById('pkgo').click();await {W};const r0=Math.random;Math.random=()=>.01;CAS.key.a();PKDBG.needle(.5);CAS.key[' ']();Math.random=r0;
          for(let i=0;i<40&&PKDBG.ph()!=='over'&&PKDBG.ph()!=='between';i++)await new Promise(r=>setTimeout(r,100));return [PKDBG.ph(),g0-P.gold,document.getElementById('pkco').disabled,/stake is gone/.test(document.getElementById('cm').textContent)]}}""")
        chk('a saved kick loses the stake and ends the run',r==['over',1000,True,True],r)
        r=await E(f"""async()=>{{await ({OPEN})();document.getElementById('pkgo').click();await {W};const T=PKDBG.tell().T;CAS.key[T===0?'e':'q']();PKDBG.needle(.5);const r0=Math.random;Math.random=()=>.99;CAS.key[' ']();Math.random=r0;
          for(let i=0;i<40&&PKDBG.ph()!=='between';i++)await new Promise(r=>setTimeout(r,100));document.getElementById('pkgo').click();await {W};const ph=PKDBG.ph(),kick=PKDBG.kick();
          const t=PKDBG.tell().T;CAS.key[['a','s','d'][t]]();Math.random=()=>.0;for(let i=0;i<50&&PKDBG.ph()==='runup';i++)await new Promise(r=>setTimeout(r,60));Math.random=r0;
          for(let i=0;i<40&&PKDBG.ph()!=='between'&&PKDBG.ph()!=='over';i++)await new Promise(r=>setTimeout(r,100));return [ph,kick,PKDBG.ph(),PKDBG.step()]}}""")
        chk('kick 2 is a save: the kicker runs up, you dive, a save climbs to rung 2',r==['runup',2,'between',2],r)
        r=await E("()=>{const ph=PKDBG.ph();const g=P.gold;CAS.key.c();return [ph,P.gold>g]}")
        chk('C cashes out between kicks',r==['between',True],r)
        r=await E(f"""async()=>{{await ({OPEN})();CAS.bet=5000;betRefresh();document.getElementById('pkgo').click();await {W};const g0=P.gold;
          /* jump to rung 9 of Grimgate's ladder is not allowed mid-run; instead check the pay rule directly */
          const L=pkLadder('grim');return [Math.min(PK_CAP,Math.floor(5000*L[9])),PK_CAP]}}""")
        chk('no round ever pays more than 20,000 (5,000 at Grimgate x59.92 would be 299,600)',r[0]==20000 and r[1]==20000,r)
        await E("()=>{lobby()}");await pg.wait_for_timeout(300)
        r=await E(f"""async()=>{{const s=pkStats();const b0=s.boots;await ({OPEN})();opp:{{}}document.getElementById('pkgo').click();await {W};const r0=Math.random;
          for(let k=1;k<=10;k++){{if(!PKDBG.tell())return ['stuck',k,PKDBG.ph(),PKDBG.step()];if(pkKind(k)==='shoot'){{const T=PKDBG.tell().T;CAS.key[T===0?'e':'q']();PKDBG.needle(.5);Math.random=()=>.99;CAS.key[' ']();Math.random=r0}}
            else{{const t=PKDBG.tell().T;CAS.key[['a','s','d'][t]]();Math.random=()=>0;for(let i=0;i<50&&PKDBG.ph()==='runup';i++)await new Promise(r=>setTimeout(r,60));Math.random=r0}}
            for(let i=0;i<60&&PKDBG.ph()==='fly';i++)await new Promise(r=>setTimeout(r,100));if(PKDBG.ph()==='between'&&k<10){{document.getElementById('pkgo').click();await {W}}}}}
          return [PKDBG.ph(),PKDBG.step(),pkStats().boots-b0,/GOLDEN BOOT/.test(document.getElementById('cm').textContent)]}}""")
        chk('ten kicks won in a row: the Golden Boot pays out automatically',r==['over',10,1,True],r)
        # ---------------------------------------------------------------- input locks and art
        r=await E(f"""async()=>{{await ({OPEN})();const a=PKDBG.ph();CAS.key.q();CAS.key[' '];document.querySelector('.pkop[data-o=grim]').click();const o1=PKDBG.opp();document.getElementById('pkgo').click();await {W};
          document.querySelector('.pkop[data-o=moss]').click();return [a,o1,PKDBG.opp(),document.querySelector('.pkop[data-o=moss]').disabled]}}""")
        chk('you pick the keeper before kick-off; the keepers lock once the run starts',r==['idle','grim','grim',True],r)
        await E("()=>{lobby()}")
        r=await E("""()=>{const c=document.createElement('canvas');c.width=1080;c.height=600;const g=c.getContext('2d');const T=f=>{for(let i=0;i<5;i++)f(i);const t0=performance.now();for(let i=0;i<30;i++)f(i);return (performance.now()-t0)/30};
          return +T(i=>{g.drawImage(pkStadium(i%2),0,0);pkNet(g,i*.1,{x:600,y:250,k:.5});pkFrame(g,0);pkKeeper(g,540,404,pkOpp('grim'),{dive:.6,lift:.5,spread:.9},i*.1);pkKicker(g,700,640,pkOpp('moss'),{run:i*.1},i*.1);pkBall(g,600,300,20,i);pkBanner(g,'GOAL!',.4,'#ffd45a','x2');pkPower(g,36,540,360,.4,.1,.13,false)}).toFixed(2)}""")
        chk('a full Penalty Kings frame draws in under 4 ms (headless)',r<4,r)
        # ---------------------------------------------------------------- 9.8 menus
        r=await E(f"""async()=>{{title();await {W};modeSheet();await {W};const secs=[...document.querySelectorAll('.mdsec h4')].map(h=>h.textContent),tiles=[...document.querySelectorAll('.mdrow .dkm')];
          const sz=new Set(tiles.map(t=>{{const b=t.getBoundingClientRect();return Math.round(b.width)+'x'+Math.round(b.height)}}));const ov=tiles.some(t=>{{const b=t.getBoundingClientRect(),c=t.querySelector('.dkmt b').getBoundingClientRect();return c.right>b.right}});
          return [secs,tiles.length,[...sz],ov,[...document.querySelectorAll('.mdrow2 .dkpr2')].length]}}""")
        chk('Choose a mode: titled rows of identical tiles (one size for every mode) and the practice modes side by side',r[0][:3]==['Story & survival','Strategy & puzzles','Casino & events'] and r[1]>=9 and len(r[2])==1 and not r[3] and r[4]>=1,r)
        await E("()=>{const x=document.querySelector('.dks [data-x]');if(x)x.click()}")
        r=await E("""async()=>{RPP().sort='def';rpStart('moss');RPX.tut=null;RPX.supply=450;await new Promise(r=>setTimeout(r,800));const ord=()=>[...document.querySelectorAll('.rpbar .rpcard')].sort((a,b)=>a.style.order-b.style.order).map(c=>c.dataset.tw);
          const d=ord();document.querySelector('.rpsort').click();document.querySelector('.rpsortm [data-k=lo]').click();const lo=ord();document.querySelector('.rpsortm [data-k=hi]').click();const hi=ord();
          document.querySelector('.rpsortm [data-k=aff]').click();const af=ord();const keys=[...document.querySelectorAll('.rpbar .rpcard')].map(c=>c.dataset.tw+c.querySelector('kbd').textContent).join();
          const cost=t=>rpCost(t,1);const sorted=(a,f)=>a.every((t,i)=>i===0||f(a[i-1],t));window.dispatchEvent(new KeyboardEvent('keydown',{key:'s'}));const sk=RPP().sort;rpLeave();return [d.join(),sorted(lo.filter(t=>!rpLockedTw||!rpLockedTw(t)),(a,b)=>cost(a)<=cost(b)),sorted(hi.filter(t=>!rpLockedTw||!rpLockedTw(t)),(a,b)=>cost(a)>=cost(b)),af.slice(0,3).every(t=>450>=cost(t)),keys,sk]}""")
        chk('tower bar sort: Default keeps the usual order; Lowest/Highest price sort by cost; Can afford first puts affordable towers first; S cycles',r[0]==','.join(['ballista','brazier','frost','bell','prism','dragon','tide','mortar','still']) and r[1] and r[2] and r[3] and 'ballistaQ' in r[4] and r[5]=='air',r)
        chk('no page errors',not er,er)
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
