/* ===== RUNESTONE RIDDLE 8.4c: music and rune sounds =====
   Everything is synthesised live with WebAudio and scheduled about a second ahead from the game's own music tick (note()),
   the same way as the fishing music (90t).
   Music, "The Riddler's Study": F major 4/4, crotchet 120 (quaver steps, a light swing), 36 bars, about 72 s.
     intro 2 (celesta glissando, bassoon and pizzicato vamp) | A 8 (glockenspiel tune) | A' 8 (recorder takes the tune,
     glockenspiel sprinkles, tambourine on beat 3) | B 8 (Bb major lift: legato recorder, glockenspiel answers, slide whistle)
     | A'' 8 (full band: tune + recorder a third below, walking bassoon, tambourine) | tag 2 (a cuckoo-clock call), then back to A.
     Bassoon oom on the beat, pizzicato chords pah on 2 and 4, woodblock tick-tock with triplet fills, a soft frame drum.
     Every other loop varies: celesta doubles A, the glockenspiel and recorder swap in A' and B, the slide whistle becomes a
     woodblock run, the cuckoo becomes a glockenspiel ping.
   Practice riddles get "Study Lullaby": the same tune at crotchet 100 with harp arpeggios, celesta and recorder, a soft bassoon.
   Warmth (RR.heat) layers in parts as you get closer: 0.4+ a celesta sparkle in semiquavers, 0.7+ a whistled descant a third
   above the tune, 0.85+ tambourine on every quaver. A win plays a brass fanfare and a loss a gentle wah-wah with a celesta lift;
   both duck the track to -15 dB for their length.
   Hand-over: while the riddle is open (S.view 'riddle') the normal music master (mg) fades to 0 over 1.2 s and this track fades
   in on its own output (RRAM.vol mirrors the Music setting: ST.mute ? 0 : ST.mvol*.6); leaving fades it out and mg back up, and
   note() resumes the normal score. Mute, zero Music volume or a hidden tab stops it.
   Sound effects (through sg, the game's effects master, so the Effects volume applies; nothing plays at ST.svol 0):
     typing a soft woodblock tock that rises with warmth, delete a lower tock, carving a chisel thock, a rejected word a low stone
     grumble, green tiles a crystal chime climbing the F major pentatonic tile by tile, gold a warm bell, gray a stone tap, each
     arch rune waking a tiny ting timed to its glow (the keystone a triple ting), more warmth a rising celesta shimmer (no gain:
     a dim stone hum), rune powers a magical whoosh, a solve a cascading rune chord, a loss a stone settling.
   Hooks: rrSfx in 92b is a const, so its callers are wrapped instead: rrType, rrDel, rrEnter, rrFinish and rrUse run with the old
   beeps gated off (a sync flag, plus a short window for the beeps 92b fires on timers), rrHeatPulse (called on each tile flip)
   plays the tile sound, rrHeatSet schedules the rune tings, rrResonate is replaced. The keeper's speech chirp still plays.
   RRAX.on=0 restores the old sounds. Calendar and tab clicks and coin landings keep their old beeps.
   Levels: the theme renders near the Fisherman's Shanty in loudness with peaks under -3 dBFS before RRAM.lvl.
   CPU: one pump is a fraction of a millisecond; the noise buffer is made once, the reverb impulse in timer slices; every voice
   disconnects itself when it ends (RRAM.st counts voices made and ended). */
const RRAM={P:[],duck:0,dt:0,vol:null,dk:null,jg:null,ac:null,pos:{},lvl:.44,R:new WeakMap(),cpu:{n:0,ms:0,max:0},err:0,st:{on:0,off:0}};
const RRAX={on:1,sync:0,until:0,fi:0,C:null,cac:null};
const rraF=m=>440*Math.pow(2,(m-69)/12);
const rraMel=a=>a.map(s=>s?s.trim().split(/\s+/).map(x=>x.split(':').map(Number)):[]);
const RRA_PC={C:0,D:2,E:4,F:5,G:7,A:9,B:11},RRA_Q={'':[0,4,7],m:[0,3,7],'7':[0,4,7,10],m7:[0,3,7,10],M7:[0,4,7,11]};
function rraCh(s){const m=s.match(/^([A-G])([#b]?)(.*)$/);return{r:(RRA_PC[m[1]]+(m[2]==='#'?1:m[2]==='b'?-1:0)+12)%12,q:RRA_Q[m[3]]||RRA_Q['']}}
const rraBars=s=>s.split(/[\s|]+/).filter(Boolean).map(rraCh);
const rraUp=(pc,lo)=>lo+((((pc-lo)%12)+12)%12);
const rraVc=(c,lo)=>c.q.map(i=>rraUp((c.r+i)%12,lo)).sort((a,b)=>a-b);
/* move a note by scale degrees in F major (harmony and descant lines) */
function rraDia(m,deg){const sc=[0,2,4,5,7,9,11],rel=((m-5)%12+12)%12,i=sc.indexOf(rel);if(i<0)return m+(deg>0?3:-4);const j=i+deg;return m-rel+sc[((j%7)+7)%7]+12*Math.floor(j/7)}
function rraErr(e){if(RRAM.err++<3)try{console.warn('riddle audio',e)}catch(x){}}
const rraOff=X=>typeof OfflineAudioContext!=='undefined'&&X instanceof OfflineAudioContext;

/* ---------- shared resources per audio context: reed wave, 1 s of noise, a small-study reverb ----------
   The impulse response is built in timer slices live (R.ready turns on when the convolver is attached); offline at once. */
function rraRes(X){let R=RRAM.R.get(X);if(R)return R;const sr=X.sampleRate;R={ready:0};RRAM.R.set(X,R);R.out=X.createGain();
 {const N=20,re=new Float32Array(N),im=new Float32Array(N);for(let k=1;k<N;k++)im[k]=(k%2?1:.5)/Math.pow(k,.9);R.reed=X.createPeriodicWave(re,im)}
 R.nb=X.createBuffer(1,sr,sr);{const w=R.nb.getChannelData(0);for(let i=0;i<w.length;i++)w[i]=Math.random()*2-1}
 const hp=X.createBiquadFilter();hp.type='highpass';hp.frequency.value=220;hp.Q.value=.6;R.rv=hp;
 const len=sr*1.5|0,ir=X.createBuffer(1,len,sr),d=ir.getChannelData(0);let i=0,lp=0;
 const work=n=>{const e=Math.min(len,i+n);for(;i<e;i++){const u=i/len;lp+=((Math.random()*2-1)-lp)*(.7-.52*u);d[i]=lp*Math.pow(1-u,2.6)}return i>=len};
 const fin=()=>{try{const cv=X.createConvolver(),dl=X.createDelay(.05),mx=X.createChannelMerger(2);cv.buffer=ir;dl.delayTime.value=.011;
  cv.connect(mx,0,0);cv.connect(dl);dl.connect(mx,0,1);mx.connect(R.out);hp.connect(cv);R.ready=1}catch(e){rraErr(e)}};
 if(rraOff(X)){work(1e9);fin()}else{const go=()=>{try{if(work(16000))fin();else setTimeout(go,0)}catch(e){rraErr(e)}};setTimeout(go,0)}
 return R}

/* ---------- envelopes and voices (every envelope starts at 0; every voice disconnects itself when its source ends) ---------- */
function rraEnv(g,t,v,a,d,r){const p=g.gain;p.value=0;p.setValueAtTime(.0001,t);p.linearRampToValueAtTime(v,t+a);if(d>a)p.setValueAtTime(v,t+d);p.exponentialRampToValueAtTime(.0001,t+Math.max(a,d)+r)}
function rraPl(g,t,v,a,dec){const p=g.gain;p.value=0;p.setValueAtTime(.0001,t);p.linearRampToValueAtTime(v,t+a);p.exponentialRampToValueAtTime(.0001,t+a+dec)}
function rraO(X,w,f,t,e,dst,det){const o=X.createOscillator();if(typeof w==='string')o.type=w;else o.setPeriodicWave(w);o.frequency.value=f;if(det)o.detune.value=det;o.connect(dst);o.start(t);o.stop(e);return o}
function rraG(X,v,dst){const g=X.createGain();g.gain.value=v;if(dst)g.connect(dst);return g}
function rraEnd(src,ns){const C=RRAM.st;C.on++;src.onended=()=>{C.off++;src.onended=null;for(const n of ns)try{n.disconnect()}catch(e){}}}
function rraVib(X,os,t,e,dep,rate,del){const l=X.createOscillator(),g=X.createGain();l.frequency.value=rate;g.gain.setValueAtTime(0,t);g.gain.setValueAtTime(0,t+del);g.gain.linearRampToValueAtTime(dep,t+del+.3);
 l.connect(g);for(const o of os)g.connect(o.detune);l.start(t);l.stop(e);rraEnd(l,[g])}
/* noise burst through a filter (woodblock click, tambourine, breath, chisel, whoosh) */
function rraNz(X,bus,t,d,v,fc,ty,q,att,to){const s=X.createBufferSource(),f=X.createBiquadFilter(),g=X.createGain();att=att||.002;s.buffer=rraRes(X).nb;s.loop=true;
 f.type=ty||'bandpass';f.frequency.setValueAtTime(fc,t);if(to)f.frequency.exponentialRampToValueAtTime(to,t+att+d);f.Q.value=q||1;rraPl(g,t,v,att,d);
 s.connect(f);f.connect(g);g.connect(bus);s.start(t,Math.random()*.8);s.stop(t+att+d+.05);rraEnd(s,[f,g])}
/* struck partials [ratio, level, decay scale]: glockenspiel, celesta, sparkle, harp, crystal, warm bell, ting */
const RRA_B={gl:[[1,1,1],[2.76,.3,.28],[5.4,.1,.1]],cel:[[1,1,1],[2,.14,.4]],spk:[[1,1,1]],harp:[[1,1,1],[2,.3,.5],[3,.08,.3]],
 cry:[[1,1,1],[2,.28,.55],[4.01,.14,.22],[6.03,.05,.1]],warm:[[.5,.22,1.2],[1,1,1],[2,.28,.45],[2.41,.12,.32],[3,.06,.22]],ting:[[1,1,1],[2.76,.18,.3]]};
function rraBell(X,bus,t,f,v,dec,kind){const ny=X.sampleRate*.45;for(const [m,a,dm] of RRA_B[kind]){if(f*m>ny)continue;const o=X.createOscillator(),g=X.createGain(),dd=dec*dm;
 o.frequency.value=f*m;rraPl(g,t,v*a,.003,dd);o.connect(g);g.connect(bus);o.start(t);o.stop(t+dd+.05);rraEnd(o,[g])}}
/* pizzicato chord: detuned saws through one closing low-pass and one envelope */
function rraPizz(X,bus,t,fs,v,dec){const g=X.createGain(),fl=X.createBiquadFilter(),e=t+dec+.05;fl.type='lowpass';fl.Q.value=2;fl.frequency.setValueAtTime(3000,t);fl.frequency.exponentialRampToValueAtTime(480,t+.12);
 rraPl(g,t,v,.003,dec);fl.connect(g);g.connect(bus);let o;for(const f of fs)o=rraO(X,'sawtooth',f,t,e,fl,Math.random()*8-4);rraEnd(o,[fl,g])}
/* bassoon: a nasal reed wave scooping into pitch, a sine underneath, staccato */
function rraBsn(X,bus,t,f,d,v){const R=rraRes(X),g=X.createGain(),fl=X.createBiquadFilter(),e=t+d+.15;fl.type='lowpass';fl.frequency.value=900;fl.Q.value=2.2;fl.connect(g);rraEnv(g,t,v,.016,d*.6,.1);
 const a=rraO(X,R.reed,f,t,e,fl);a.frequency.setValueAtTime(f*.97,t);a.frequency.exponentialRampToValueAtTime(f,t+.03);const sg2=rraG(X,.7,g),b=rraO(X,'sine',f,t,e,sg2);
 g.connect(bus);rraEnd(a,[fl,g]);rraEnd(b,[sg2])}
/* recorder (sine + a little triangle, a breathy chiff) or whistle (pure sine scooping from the last note) */
function rraRec(X,bus,t,f,d,v,o){o=o||{};const g=X.createGain(),e=t+d+.2,os=[];rraEnv(g,t,v,o.w?.05:.03,d,.12);
 const a=rraO(X,'sine',f,t,e,g);os.push(a);if(!o.w){const tg=rraG(X,.18,g),b=rraO(X,'triangle',f,t,e,tg);os.push(b);rraEnd(b,[tg])}
 if(o.w&&o.from&&Math.abs(o.from-f)>1){a.frequency.setValueAtTime(o.from,t);a.frequency.exponentialRampToValueAtTime(f,t+.07)}
 if(d>.4)rraVib(X,os,t,e,o.w?16:10,5.4,Math.min(.3,d*.35));g.connect(bus);rraEnd(a,[g]);if(!o.w)rraNz(X,bus,t,.05,v*.3,Math.min(9000,f*2),'bandpass',3)}
function rraWood(X,bus,t,f,v,dec){const o=X.createOscillator(),fl=X.createBiquadFilter(),g=X.createGain();dec=dec||.055;o.type='triangle';o.frequency.setValueAtTime(f*1.06,t);o.frequency.exponentialRampToValueAtTime(f,t+.015);
 fl.type='bandpass';fl.frequency.value=f;fl.Q.value=3;rraPl(g,t,v,.001,dec);o.connect(fl);fl.connect(g);g.connect(bus);o.start(t);o.stop(t+dec+.05);rraEnd(o,[fl,g])}
function rraTamb(X,bus,t,v,dec){rraNz(X,bus,t,dec||.09,v,7200,'highpass',.8,.003)}
function rraDrum(X,bus,t,v,f0){const o=X.createOscillator(),g=X.createGain();o.frequency.setValueAtTime(f0*1.8,t);o.frequency.exponentialRampToValueAtTime(f0,t+.07);rraPl(g,t,v,.003,.25);o.connect(g);g.connect(bus);o.start(t);o.stop(t+.3);rraEnd(o,[g])}
function rraSlide(X,bus,t,f0,f1,d,v){const o=X.createOscillator(),g=X.createGain();o.frequency.setValueAtTime(f0,t);o.frequency.exponentialRampToValueAtTime(f1,t+d);rraEnv(g,t,v,.04,d,.08);
 o.connect(g);g.connect(bus);o.start(t);o.stop(t+d+.15);rraVib(X,[o],t,t+d+.15,25,6,.05);rraEnd(o,[g])}
function rraCuckoo(X,bus,t,v,gap){for(const [dt,m] of [[0,79],[gap,76]]){const o=X.createOscillator(),g=X.createGain(),fl=X.createBiquadFilter(),s=t+dt;fl.type='lowpass';fl.frequency.value=1900;o.type='triangle';o.frequency.value=rraF(m);
 rraEnv(g,s,v,.03,.12,.25);o.connect(fl);fl.connect(g);g.connect(bus);o.start(s);o.stop(s+.5);rraEnd(o,[fl,g])}}
/* brass for the fanfare; wah=1 is the muted "wah" with a swept resonant filter */
function rraBrass(X,bus,t,f,d,v,wah){const g=X.createGain(),fl=X.createBiquadFilter(),e=t+d+.25,p=fl.frequency;fl.type='lowpass';fl.Q.value=wah?6:1.5;
 if(wah){p.setValueAtTime(300,t);p.linearRampToValueAtTime(1300,t+Math.min(.18,d*.4));p.exponentialRampToValueAtTime(320,t+d)}else{p.setValueAtTime(600,t);p.linearRampToValueAtTime(3200,t+.04);p.exponentialRampToValueAtTime(1600,t+.25)}
 fl.connect(g);rraEnv(g,t,v,wah?.06:.025,d,wah?.2:.12);const a=rraO(X,'sawtooth',f,t,e,fl,-6),b=rraO(X,'sawtooth',f,t,e,fl,6);if(d>.5)rraVib(X,[a,b],t,e,wah?30:12,wah?4.5:5.5,.2);g.connect(bus);rraEnd(a,[fl,g])}

/* ---------- the score ---------- */
const RRA_CH=rraBars('F C7 | F Bb C7 F Dm G7 C C7 | F Bb C7 F Dm G7 C7 F | Bb F Gm C7 Am D7 G7 C7 | F Bb C7 F Dm G7 C7 F | Bb C7');
const RRA_M=(()=>{const A=['0:72:2 2:69:1 3:72:1 4:77:3 7:76:1','0:74:2 2:77:1 3:74:1 4:70:3 7:69:1','0:70:1 1:72:1 2:76:1 3:79:1 4:82:2 6:79:1 7:76:1',
  '0:77:2 2:81:1 3:77:1 4:72:2 6:69:1 7:70:1','0:74:2 2:77:1 3:81:1 4:86:3 7:84:1'],
 E1=['0:83:1 1:81:1 2:79:1 3:77:1 4:74:2 6:71:1 7:74:1','0:72:2 2:76:1 3:79:1 4:84:4','0:82:1 2:79:1 4:76:2 6:69:1 7:70:1'],
 E2=['0:79:1 1:81:1 2:83:1 3:86:1 4:84:2 6:83:1 7:81:1','0:79:2 2:76:1 3:79:1 4:82:2 6:81:1 7:79:1','0:77:3 3:72:1 4:77:2'],
 B=['0:74:3 3:72:1 4:70:2 6:74:2','0:72:4 4:69:1 5:70:1 6:72:2','0:70:3 3:69:1 4:67:2 6:70:2','0:69:2 2:67:2 4:64:4',
  '0:76:3 3:74:1 4:72:2 6:76:2','0:78:3 3:76:1 4:74:2 6:72:2','0:71:2 2:74:2 4:77:2 6:76:1 7:74:1','0:72:2 2:70:2 4:67:1 5:64:1 6:69:1 7:70:1'];
 return rraMel(['','6:69:1 7:70:1',...A,...E1,...A,...E2,...B,...A,...E2,'0:74:1 1:77:1 2:82:2 4:81:1 5:79:1 6:77:1 7:74:1','0:72:2 2:76:1 3:79:1 6:69:1 7:70:1'])})();
const rraSec=b=>b<2?0:b<10?1:b<18?2:b<26?3:b<34?4:5;
function rraStep(P,t0,bar,k){const X=P.X,B=P.B,sd=P.sd,cm=P.T.calm,c=RRA_CH[bar],sec=rraSec(bar),lp=P.lp,len=(k%2?1-P.sw:1+P.sw)*sd,t=t0+(k%2?P.sw*sd:0),h=P.heat(t0),
 nx=RRA_CH[bar+1<P.T.bars?bar+1:P.T.loop],root=rraUp(c.r,38),fifth=root+(root+7>50?-5:7),on=RRA_M[bar].filter(m=>m[0]===k),fill=sec&&sec<5&&(bar-2)%4===3&&bar!==25;
 /* bassoon: oom on the beat (fifth on beat 3), a bouncing octave and a chromatic walk-in from A'' on; calm: one long note a bar */
 if(!cm){if(k===0)rraBsn(X,B.bs,t,rraF(root),sd*1.4,.12);else if(k===4)rraBsn(X,B.bs,t,rraF(fifth),sd*1.4,.1);
  else if(k===6&&sec>=3&&sec<5)rraBsn(X,B.bs,t,rraF(root+12),sd*.6,.06);
  else if(k===7&&sec&&sec<5&&bar%2){const nr=rraUp(nx.r,38);if(nr!==root)rraBsn(X,B.bs,t,rraF(nr>root?nr-1:nr+1),sd*.5,.07)}}
 else{if(k===0)rraBsn(X,B.bs,t,rraF(root),sd*3,.075);else if(k===4&&(sec===3||sec===4))rraBsn(X,B.bs,t,rraF(fifth),sd*2.5,.055)}
 /* pah: pizzicato chords on 2 and 4; calm: harp arpeggio in quavers */
 if(!cm){if(k===2||k===6)rraPizz(X,B.pz,t,rraVc(c,58).map(rraF),sec===4?.05:.042,.26)}
 else{const r=rraUp(c.r,53),th=c.q[1];rraBell(X,B.pz,t,rraF([r,r+7,r+12,r+12+th,r+19,r+12+th,r+12,r+7][k]),k===0?.05:.035,1.3,'harp')}
 /* intro: a celesta glissando up the pentatonic */
 if(bar===0&&k===0)for(let i=0;i<10;i++)rraBell(X,B.sp,t+i*.05,rraF(77+[0,2,4,7,9][i%5]+12*Math.floor(i/5)),.03,.6,'cel');
 /* the tune */
 for(const [,p,l] of on){const d=l*sd;
  if(sec===3&&(cm||lp%2===0))rraRec(X,B.rec,t,rraF(p),d*.92,cm?.04:.05);
  else if(sec===2&&!cm&&lp%2===0){rraRec(X,B.rec,t,rraF(p),d*.85,.05);if(k%4===0)rraBell(X,B.gl,t,rraF(p+24),.02,1,'gl')}
  else{rraBell(X,B.gl,t,rraF(p+12),cm?.055:.07,Math.max(.9,d*1.5),cm?'cel':'gl');
   if(!cm&&(sec===1||sec===5)&&lp%2)rraBell(X,B.gl,t,rraF(p),.03,Math.max(.8,d*1.3),'cel');
   if(sec===4||(!cm&&lp%2&&(sec===2||sec===3)))rraRec(X,B.rec,t,rraF(rraDia(p,-2)),d*.85,cm?.025:.032);
   if(cm&&sec===2&&lp%2)rraBell(X,B.pz,t,rraF(p),.025,1.2,'harp')}}
 /* glockenspiel answers while the recorder sings B */
 if(sec===3&&(cm||lp%2===0)&&k%2&&!on.length){const tn=rraVc(c,79);rraBell(X,B.gl,t,rraF(tn[((k>>1)+bar)%tn.length]),cm?.022:.03,.8,cm?'cel':'gl')}
 /* tag: a cuckoo-clock call (every other loop a glockenspiel ping) */
 if(bar===35&&k===4){if(lp%2===0)rraCuckoo(X,B.ct,t,cm?.035:.05,sd*1.1);else rraBell(X,B.gl,t,rraF(94),.06,1.2,cm?'cel':'gl')}
 /* percussion */
 if(!cm){if(k===2||k===6)rraWood(X,B.perc,t,1180,.07);
  if(k===7&&sec&&bar%2&&!fill)rraWood(X,B.perc,t,820,.05);
  if(fill&&k===6)for(let j=1;j<3;j++)rraWood(X,B.perc,t+j*sd*2/3,j%2?950:1180,.05);
  if(k===0&&sec)rraDrum(X,B.perc,t,.14,85);if(k===4&&sec===4)rraDrum(X,B.perc,t,.1,95);
  const tb=h>=.85||(sec===4?(k%2||k===2||k===6):sec===3?(k===2||k===6):sec===2&&k===4);
  if(tb)rraTamb(X,B.perc,t,k===2||k===6?.05:.032,.09);
  if(bar===25&&k===4){if(lp%2===0)rraSlide(X,B.ct,t,rraF(67),rraF(84),sd*1.8,.035);else for(let j=0;j<4;j++)rraWood(X,B.perc,t+j*sd*.5,1400-j*140,.05)}}
 else{if((k===2||k===6)&&sec>=2)rraWood(X,B.perc,t,1050,.03);if((sec===4||h>=.85)&&k%2)rraTamb(X,B.perc,t,.016,.06)}
 /* warmth layers: celesta sparkle at 0.4+, whistled descant at 0.7+ */
 if(h>=.4){const u=Math.min(1,(h-.4)/.2),tn=rraVc(c,84).concat(rraVc(c,96)),pat=[0,1,2,3,4,3,2,1];
  for(let j=0;j<2;j++)rraBell(X,B.sp,t+j*len*.5,rraF(tn[pat[(k*2+j)%8]]),(cm?.012:.016)*u*(j?.75:1),.45,'spk')}
 if(h>=.7){const u=Math.min(1,(h-.7)/.15);for(const [,p,l] of on){if(l<2&&k%4)continue;let q=rraDia(p,2);if(q<79)q+=12;const f=rraF(q);rraRec(X,B.ct,t,f,l*sd*.9,(cm?.022:.03)*u,{w:1,from:P.wp});P.wp=f}}}
/* tracks: sd seconds per quaver, sw swing, loop bar, secs (section starts, for resuming), gain trim, bus {name:[dry, reverb send, pan]} */
const RRAT={main:{sd:60/120/2,sw:.1,spb:8,bars:36,loop:2,secs:[0,2,10,18,26],gain:2.1,step:rraStep,
  bus:{gl:[1,.3,.22],pz:[.9,.18,-.2],bs:[.8,.06],rec:[1,.35,-.3],perc:[.7,.12,.3],sp:[.7,.55,.4],ct:[1,.45,-.4]}},
 calm:{sd:60/100/2,sw:.06,calm:1,spb:8,bars:36,loop:2,secs:[0,2,10,18,26],gain:2.8,step:rraStep,
  bus:{gl:[1,.4,.22],pz:[.9,.35,-.25],bs:[.7,.1],rec:[1,.45,-.3],perc:[.6,.15,.3],sp:[.7,.6,.4],ct:[1,.5,-.4]}}};

/* ---------- jingles (on the music output, ducking the track) ---------- */
function rraFanfare(X,o,t){const s=.13,br=(dt,m,d,v)=>rraBrass(X,o,t+dt,rraF(m),d,v||.05);
 br(0,72,.09);br(s,72,.09);br(2*s,72,.09);br(3*s,77,.3);br(3*s,69,.3,.03);br(6*s,81,.1);br(7*s,84,1.1,.055);br(7*s,77,1.1,.035);br(7*s,72,1.1,.03);br(7*s,69,1.1,.03);
 rraDrum(X,o,t+3*s,.25,65);rraDrum(X,o,t+6*s,.2,82);rraDrum(X,o,t+7*s,.3,65);rraBsn(X,o,t+3*s,rraF(41),.3,.1);rraBsn(X,o,t+7*s,rraF(41),1,.1);
 [89,93,96,101,105].forEach((m,i)=>rraBell(X,o,t+7*s+.05+i*.07,rraF(m),.04,1.4,'gl'));for(let i=0;i<6;i++)rraTamb(X,o,t+7*s+i*.06,.04*(1-i/8),.08);return 7*s+1.5}
function rraWah(X,o,t){const s=.36;[58,57,56].forEach((m,i)=>rraBrass(X,o,t+i*s,rraF(m),.26,.045,1));rraBrass(X,o,t+3*s,rraF(55),.9,.045,1);
 [77,81,84].forEach((m,i)=>rraBell(X,o,t+3*s+1.25+i*.12,rraF(m),.03,1.2,'cel'));return 3*s+1.65}
function rraJing(kind){try{if(!ac||!RRAM.jg||RRAM.ac!==ac||ST.mute||ST.mvol<=0)return;const X=ac,now=X.currentTime+.03;
 const n=kind==='win'?rraFanfare(X,RRAM.jg,now+.4)+.4:rraWah(X,RRAM.jg,now+.25)+.25,d=RRAM.dk.gain;
 d.cancelScheduledValues(now);d.setValueAtTime(d.value,now);d.linearRampToValueAtTime(.18,now+.15);d.setValueAtTime(.18,now+n);d.linearRampToValueAtTime(1,now+n+1.4)}catch(e){rraErr(e)}}

/* ---------- players: one per playing track, each with its own fade ---------- */
function rraStart(key,tid,at,fi,X,list,off){const T=RRAT[tid],R=rraRes(X),P={key,tid,T,X,R,list,off,dead:0,sd:T.sd,sw:T.sw,nodes:[],lp:0,wp:0,heat:()=>{try{return RR&&RR.heat||0}catch(e){return 0}}};
 P.lv=T.gain;P.g=X.createGain();P.gw=X.createGain();P.fs=at;P.fe=at+fi;for(const g of [P.g,P.gw]){g.gain.setValueAtTime(0,X.currentTime);g.gain.setValueAtTime(0,at);g.gain.linearRampToValueAtTime(P.lv,at+fi)}
 P.g.connect(R.out);P.gw.connect(R.rv);P.B={};for(const k in T.bus){const [d,w,pn]=T.bus[k];let o=P.g;if(pn){o=X.createStereoPanner();o.pan.value=pn;o.connect(P.g);P.nodes.push(o)}
  const b=rraG(X,d,o);P.nodes.push(b);if(w){const s=rraG(X,w,P.gw);b.connect(s);P.nodes.push(s)}P.B[k]=b}
 let b0=0;if(!off){const sv=RRAM.pos[tid]|0;for(const s of T.secs)if(s<=sv)b0=s}P.n=b0*T.spb;P.nt=at;list.push(P);return P}
function rraFade(a,at,v0,v1,dur){a.cancelScheduledValues(at);a.setValueAtTime(v0,at);a.linearRampToValueAtTime(v1,at+dur)}
function rraKill(P,at,fo){let v;if(P.dead){if(P.ke<=at+fo)return;v=at<=P.ka?P.kv:P.kv*Math.max(0,(P.ke-at)/(P.ke-P.ka))}
 else{P.dead=1;v=at>=P.fe?P.lv:at<=P.fs?0:P.lv*(at-P.fs)/(P.fe-P.fs);if(!P.off)RRAM.pos[P.tid]=(P.n/P.T.spb)|0}
 P.ka=at;P.kv=v;P.ke=at+fo;for(const g of [P.g,P.gw])rraFade(g.gain,at,v,0,fo);P.end=at+fo+3}
/* live, the pump schedules at most two quavers per call (the tick comes every 100 ms, the look-ahead is 1.1 s), so no frame pays for many */
function rraSched(P,until,mx){const T=P.T,tot=T.bars*T.spb;let n=0;mx=mx||96;
 while(!P.dead&&P.nt<until&&n++<mx){const bar=(P.n/T.spb)|0,k=P.n%T.spb;try{T.step(P,P.nt,bar,k)}catch(e){rraErr(e)}P.n++;P.nt+=P.sd;if(P.n>=tot){P.n=T.loop*T.spb;P.lp++}}}
function rraWant(){try{if(typeof S==='undefined'||S.view!=='riddle'||!RR||!$('rr'))return null;return RR.mode==='p'?'calm':'main'}catch(e){return null}}
function rraVol(){if(RRAM.vol)RRAM.vol.gain.value=(ST.mute?0:ST.mvol*.6)*RRAM.lvl}
function rraDuck(on,now){RRAM.duck=on?1:0;RRAM.dt=now;const a=mg.gain;rraFade(a,now,a.value,on?0:(ST.mute?0:ST.mvol*.6),1.2)}
function rraPump(){if(!ac||!mg)return;const t0=performance.now(),X=ac,now=X.currentTime,R=rraRes(X);
 if(RRAM.ac!==X){RRAM.ac=X;RRAM.P=[];RRAM.vol=X.createGain();RRAM.vol.connect(X.destination);RRAM.dk=X.createGain();R.out.connect(RRAM.dk);RRAM.dk.connect(RRAM.vol);RRAM.jg=X.createGain();RRAM.jg.connect(RRAM.vol);rraVol()}
 const want=rraWant(),on=!!want;
 if(on!==!!RRAM.duck)rraDuck(on,now);
 else if(on&&now-RRAM.dt>1.4&&mg.gain.value>.001)mg.gain.setTargetAtTime(0,now,.2);  /* something raised the master: keep the normal score quiet */
 const key=on&&!document.hidden&&!ST.mute&&ST.mvol>0&&R.ready?want:null,cur=RRAM.P.find(p=>!p.dead);
 if(key){if(!cur||cur.key!==key){for(const p of RRAM.P)rraKill(p,now,1.2);rraStart(key,key,now+.06,1,X,RRAM.P)}}
 else if(cur)for(const p of RRAM.P)rraKill(p,now,document.hidden?.3:1.2);
 for(const p of RRAM.P)if(!p.dead)rraSched(p,now+1.1,2);
 if(RRAM.P.some(p=>p.dead&&now>p.end))RRAM.P=RRAM.P.filter(p=>{if(p.dead&&now>p.end){for(const x of [p.g,p.gw,...p.nodes])try{x.disconnect()}catch(e){}return false}return true});
 const ms=performance.now()-t0,C=RRAM.cpu;C.n++;C.ms+=ms;if(ms>C.max)C.max=ms}
/* what is playing now, and voice and CPU counters (for tests and the dev tools) */
function rraNow(){const p=RRAM.P.find(q=>!q.dead);return p?{track:p.tid,bar:(p.n/p.T.spb)|0,loop:p.lp}:null}
function rraStats(){const C=RRAM.cpu,S2=RRAM.st;return{live:S2.on-S2.off,made:S2.on,ended:S2.off,players:RRAM.P.length,pumpAvg:C.n?C.ms/C.n:0,pumpMax:C.max}}
/* offline render of a track (bars from `from`, heat a number or function of time) for level checks */
function rraRender(tid,secs,from,heat,sr){sr=sr||48000;const X=new OfflineAudioContext(2,Math.ceil(sr*secs),sr),R=rraRes(X);R.out.connect(X.destination);
 const P=rraStart('off',tid,0,.02,X,[],1);P.n=(from||0)*P.T.spb;if(heat!=null)P.heat=typeof heat==='function'?heat:()=>heat;rraSched(P,secs);return X.startRendering()}
{const n0=note;note=function(t,n){try{rraPump()}catch(e){rraErr(e)}if(RRAM.duck&&RRAM.ac===ac){try{if(typeof fm7Pump==='function')fm7Pump()}catch(e){}return}return n0(t,n)}}
{const a0=applyVol;applyVol=function(){const r=a0.apply(this,arguments);try{rraVol();if(RRAM.duck&&mg&&ac){mg.gain.cancelScheduledValues(ac.currentTime);mg.gain.value=0}}catch(e){}return r}}
document.addEventListener('visibilitychange',()=>{try{rraPump()}catch(e){}});
{const s0=show;show=function(){const r=s0.apply(this,arguments);try{if(ac&&(RRAM.ac===ac||rraWant()))setTimeout(()=>{try{rraPump()}catch(e){}},0)}catch(e){}return r}}

/* ---------- rune sound effects (C = {X, o: dry out, w: echo send}; t = start time) ---------- */
function rraFxBus(X,dst){const o=X.createGain(),w=X.createGain(),dl=X.createDelay(.5),fb=X.createGain(),lp=X.createBiquadFilter();o.connect(dst);dl.delayTime.value=.16;fb.gain.value=.3;
 lp.type='lowpass';lp.frequency.value=3800;w.connect(dl);dl.connect(lp);lp.connect(fb);fb.connect(dl);lp.connect(dst);
 /* five fixed pans, left to right, for the tiles and the two sides of the arch */
 const pan=[-.45,-.22,0,.22,.45].map(v=>{const n=X.createStereoPanner();n.pan.value=v;n.connect(o);return n});return{X,o,w,pan}}
function rraFxC(){if(RRAX.cac!==ac||!RRAX.C){RRAX.cac=ac;RRAX.C=rraFxBus(ac,sg)}return RRAX.C}
const RRA_CRY=[81,84,86,89,93],RRA_WARM=[69,72,74,77,79],RRA_TING=[84,86,88,91,93,96,98,100,103,105];
function rraThud(X,o,t,f0,f1,v,dec){const s=X.createOscillator(),g=X.createGain();s.frequency.setValueAtTime(f0,t);s.frequency.exponentialRampToValueAtTime(f1,t+dec*.6);rraPl(g,t,v,.003,dec);s.connect(g);g.connect(o);s.start(t);s.stop(t+dec+.06);rraEnd(s,[g])}
const RRAFX={
 key(C,t,i,h){const X=C.X;rraWood(X,C.o,t,(780+(h||0)*320)*(1+(Math.random()-.5)*.05),.095,.05);rraNz(X,C.o,t,.014,.014,3800,'highpass',.7)},
 del(C,t){const X=C.X;rraWood(X,C.o,t,520,.08,.06);rraNz(X,C.o,t,.02,.013,1600,'bandpass',1)},
 carve(C,t){const X=C.X;rraThud(X,C.o,t,170,70,.11,.16);rraNz(X,C.o,t,.05,.07,1500,'bandpass',1.2);rraNz(X,C.o,t+.004,.025,.03,5200,'highpass',.7);
  rraBell(X,C.o,t+.006,3150,.009,.12,'ting');rraBell(X,C.w,t+.006,3150,.006,.12,'ting')},
 bad(C,t){const X=C.X,g=X.createGain(),tg=X.createGain(),fl=X.createBiquadFilter(),l=X.createOscillator(),lg=X.createGain(),e=t+.62;fl.type='lowpass';fl.frequency.value=320;fl.Q.value=4;
  fl.connect(g);g.connect(tg);tg.connect(C.o);tg.gain.value=.7;l.frequency.value=15;lg.gain.value=.3;l.connect(lg);lg.connect(tg.gain);l.start(t);l.stop(e);rraEnd(l,[lg]);rraEnv(g,t,.045,.03,.22,.25);
  const a=rraO(X,'sawtooth',64,t,e,fl),b=rraO(X,'sawtooth',67.5,t,e,fl);for(const x of [a,b]){const f=x.frequency.value;x.frequency.setValueAtTime(f,t+.08);x.frequency.exponentialRampToValueAtTime(f*.8,t+.5)}
  rraEnd(a,[fl,g,tg]);rraNz(X,C.o,t,.3,.03,180,'lowpass',.8,.04)},
 c(C,t,i){const X=C.X,f=rraF(RRA_CRY[i%5]),o=C.pan[i%5];rraBell(X,o,t,f,.04,1.5,'cry');rraBell(X,C.w,t,f,.02,1,'cry');rraBell(X,o,t+.03,f*2,.01,.25,'ting');rraNz(X,o,t,.12,.01,9000,'highpass',.7,.01)},
 p(C,t,i){const X=C.X,f=rraF(RRA_WARM[i%5]);rraBell(X,C.pan[i%5],t,f,.04,1.6,'warm');rraBell(X,C.w,t,f,.016,1,'warm')},
 a(C,t,i){const X=C.X,o=C.pan[(i|0)%5];rraThud(X,o,t,220,150+Math.random()*20,.07,.08);rraNz(X,o,t,.04,.05,900,'lowpass',.8)},
 ting(C,t,o){const X=C.X;if(o>=10){[96,100,103].forEach((m,j)=>{rraBell(X,C.o,t+j*.03,rraF(m),.012,.7,'ting');rraBell(X,C.w,t+j*.03,rraF(m),.009,.5,'ting')});return}
  const f=rraF(RRA_TING[o|0]),pn=C.pan[o%2?4:0];rraBell(X,pn,t,f,.016,.35,'ting');rraBell(X,C.w,t,f,.01,.3,'ting')},
 rise(C,t,i,h){const X=C.X,n=4+Math.round(h*7),sc=[0,2,4,7,9];for(let j=0;j<n;j++){const m=77+sc[j%5]+12*Math.floor(j/5);rraBell(X,C.o,t+j*.05,rraF(m),.011+.009*j/n,.6,'cel');if(j%2)rraBell(X,C.w,t+j*.05,rraF(m),.009,.4,'cel')}
  rraNz(X,C.o,t,.5+h*.3,.014+h*.014,1400,'bandpass',4,.25,7000);
  if(h>=.6){const g=X.createGain(),e=t+2.2;rraEnv(g,t+.2,.009,.2,.5,1.2);let o;for(const m of [77,81,84,89])o=rraO(X,'sine',rraF(m),t+.2,e,g);g.connect(C.o);g.connect(C.w);rraEnd(o,[g])}},
 hum(C,t,i,h){const X=C.X,g=X.createGain(),e=t+1.4;rraEnv(g,t,.011+.01*h,.25,.35,.7);let o;for(const m of [53,60,65].slice(0,1+Math.min(2,Math.round(h*3))))o=rraO(X,'sine',rraF(m),t,e,g);g.connect(C.o);rraEnd(o,[g])},
 pow(C,t){const X=C.X;rraNz(X,C.o,t,.5,.1,350,'bandpass',2,.18,4500);rraNz(X,C.w,t+.15,.4,.05,4500,'bandpass',2,.05,900);
  const o=X.createOscillator(),g=X.createGain();o.frequency.setValueAtTime(300,t);o.frequency.exponentialRampToValueAtTime(1400,t+.45);rraEnv(g,t,.03,.2,.3,.25);o.connect(g);g.connect(C.o);o.start(t);o.stop(t+.65);rraVib(X,[o],t,t+.65,40,9,.05);rraEnd(o,[g]);
  [96,100,103,108].forEach((m,j)=>{rraBell(X,C.o,t+.42+j*.05,rraF(m),.018,.5,'ting');rraBell(X,C.w,t+.42+j*.05,rraF(m),.012,.4,'ting')})},
 win(C,t){const X=C.X;[93,89,86,84,81].forEach((m,j)=>{rraBell(X,C.pan[4-j],t+j*.07,rraF(m),.034,1.2,'cry');rraBell(X,C.w,t+j*.07,rraF(m),.017,.8,'cry')});
  [53,57,60,64,67,69,72].forEach((m,j)=>rraBell(X,C.o,t+.4+j*.045,rraF(m+12),.017,2.4,'warm'));rraNz(X,C.o,t+.35,1,.015,8000,'highpass',.7,.4);
  const g=X.createGain(),e=t+3.4;rraEnv(g,t+.45,.012,.3,1,1.6);let o;for(const m of [65,72,77,81])o=rraO(X,'sine',rraF(m),t+.45,e,g);g.connect(C.o);g.connect(C.w);rraEnd(o,[g])},
 lose(C,t){const X=C.X;rraNz(X,C.o,t,.5,.04,220,'lowpass',.8,.05);rraThud(X,C.o,t,110,55,.08,.5);rraBell(X,C.o,t+.15,rraF(69),.024,1.6,'warm');rraBell(X,C.o,t+.45,rraF(65),.024,2,'warm')}};
function rraSfxAt(kind,dt,i,h,x){try{if(!RRAX.on||!ac||!sg||ST.svol<=0)return;const f=RRAFX[kind];if(!f)return;const S2=RRAM.st;
 if(S2.on-S2.off>160&&(kind==='key'||kind==='del'||kind==='ting'))return;f(rraFxC(),ac.currentTime+.005+(dt||0),i,h,x)}catch(e){rraErr(e)}}
const rraSfx=(kind,i,h,x)=>rraSfxAt(kind,0,i,h,x);
/* each rune of the arch wakes as the displayed warmth (RR.hv, which eases toward RR.heat at rate 2.2/s) passes it:
   rune o (bottom up) at (o+.5)/11, the keystone at .775 */
function rraTings(a,b){for(let o=0;o<11;o++){const x=o<10?(o+.5)/11:.775;if(x<=a||x>b)continue;rraSfxAt('ting',Math.min(2.2,-Math.log(Math.max(1e-4,(b-x)/(b-a)))/2.2)+.02,o)}}

/* ---------- hooks into 92b/92h ---------- */
/* the old beeps are gated while a wrapped call runs (RRAX.sync) and for a short window after it (beeps 92b fires on timers);
   the keeper's speech chirp (beep 740 or 560, .05 s) always passes */
function rraGate(f,d){return RRAX.on&&typeof S==='object'&&S.view==='riddle'&&(RRAX.sync>0||performance.now()<RRAX.until)&&!(d===.05&&(f===740||f===560))}
{const b0=beep;beep=function(f,d){if(rraGate(f,d))return;return b0.apply(this,arguments)}}
function rraRun(f0,self,args){RRAX.sync++;try{return f0.apply(self,args)}finally{RRAX.sync--}}
{const f0=rrType;rrType=function(){const n=RR?RR.cur.length:0,r=rraRun(f0,this,arguments);if(RR&&RR.cur.length>n)rraSfx('key',n,RR.heat||0);return r}}
{const f0=rrDel;rrDel=function(){const n=RR?RR.cur.length:0,r=rraRun(f0,this,arguments);if(RR&&RR.cur.length<n)rraSfx('del');return r}}
{const f0=rrEnter;rrEnter=function(){let e=null,n=0,ok=false;try{if(RR&&!RR.busy){e=rrCur();n=e.g.length;ok=e.st==='p'}}catch(x){}const r=rraRun(f0,this,arguments);
 if(ok&&RRAX.on){if(e.g.length>n){RRAX.fi=0;RRAX.until=performance.now()+1500;rraSfx('carve')}else{RRAX.until=performance.now()+200;rraSfx('bad')}}return r}}
/* a tile's rune sound as it flips (with reduced motion all five flip at once, so their sounds are spread 70 ms apart) */
{const f0=rrHeatPulse;rrHeatPulse=function(s){const r=f0.apply(this,arguments);if(RR&&(s==='c'||s==='p'||s==='a')){const i=RRAX.fi++%5;let rm=false;try{rm=rrRM()}catch(x){}rraSfxAt(s,rm?i*.07:0,i,RR.heat||0)}return r}}
{const f0=rrHeatSet;rrHeatSet=function(snap){const a=RR?(RR.hv!=null?RR.hv:RR.heat||0):0,r=f0.apply(this,arguments);if(!snap&&RR&&(RR.heat||0)>a+.001)rraTings(a,RR.heat);return r}}
{const f0=rrResonate;rrResonate=function(h,dh,win){if(!RRAX.on)return f0.apply(this,arguments);if(win||h<=0)return;rraSfx(dh>0?'rise':'hum',0,h,dh)}}
{const f0=rrFinish;rrFinish=function(win){const r=rraRun(f0,this,arguments);if(RRAX.on){RRAX.until=performance.now()+650;rraSfx(win?'win':'lose');rraJing(win?'win':'lose')}return r}}
{const f0=rrUse;rrUse=function(k){let e=null,u=1;try{if(RR){e=rrCur();u=e.pw[k]}}catch(x){}const r=rraRun(f0,this,arguments);if(RRAX.on&&e&&!u&&e.pw[k]){RRAX.until=performance.now()+320;rraSfx('pow',k==='r'?0:1)}return r}}
