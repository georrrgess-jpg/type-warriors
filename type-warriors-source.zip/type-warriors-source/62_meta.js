/* ---------- icons ---------- */
const IC={
 hourglass:'M6 2h12M6 22h12M7 2v4l5 6-5 6v4M17 2v4l-5 6 5 6v4',bolt:'M13 2L4 14h7l-1 8 9-12h-7z',moon:'M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z',
 check:'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM7.5 12.5l3 3 6-6.5',star:'M12 2.5l2.9 6.2 6.6.8-4.9 4.6 1.3 6.7L12 17.5l-5.9 3.3 1.3-6.7L2.5 9.5l6.6-.8z',
 book:'M4 5c3-1 6-1 8 1 2-2 5-2 8-1v14c-3-1-6-1-8 1-2-2-5-2-8-1zM12 6v14',heart:'M12 20.5S3.5 15 3.5 9.2A4.7 4.7 0 0 1 12 6.6a4.7 4.7 0 0 1 8.5 2.6C20.5 15 12 20.5 12 20.5z',
 shield:'M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z',plus:'M9 3h6v6h6v6h-6v6H9v-6H3V9h6z',flame:'M12 2.5c.8 4 5.5 6 5.5 11.5a5.5 5.5 0 0 1-11 0c0-2.8 1.6-4 2-6.5 1.4.8 2.2 1.6 3.5-5z',
 tower:'M4 21V9h3V5h3v4h4V5h3v4h3v12zM10 21v-5h4v5',coin:'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 7v10M9.5 9.5c0-1.3 1.2-2 2.5-2s2.5.7 2.5 2-1.2 1.6-2.5 2-2.5.7-2.5 2 1.2 2 2.5 2 2.5-.7 2.5-2',
 chest:'M3 10a9 5 0 0 1 18 0v10H3zM3 12h18M12 11v4',target:'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 7a5 5 0 1 0 0 10 5 5 0 0 0 0-10zM12 11a1 1 0 1 0 0 2 1 1 0 0 0 0-2z',
 tag:'M3 12V4h8l10 10-8 8zM7.5 8.5h.01',clover:'M12 12a4 4 0 1 1 0-8 4 4 0 0 1 0 8zM12 12a4 4 0 1 0 8 0 4 4 0 0 0-8 0zM12 12a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM12 12a4 4 0 1 0-8 0 4 4 0 0 0 8 0zM12 12l0 10',
 crown:'M3 18L5 7l5 5 2-8 2 8 5-5 2 11zM4 21h16',flask:'M9 3h6M10 3v6l-6 11a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1l-6-11V3M7 15h10',
 swords:'M5 5l14 14M19 5L5 19M3 9l6-6M21 9l-6-6M3 15l6 6M21 15l-6 6',burst:'M12 2v6M12 16v6M2 12h6M16 12h6M5 5l4 4M15 15l4 4M19 5l-4 4M9 15l-4 4',
 skull:'M12 3a8 8 0 0 0-8 8c0 3 1.5 4.6 3 5.6V21h10v-4.4c1.5-1 3-2.6 3-5.6a8 8 0 0 0-8-8zM9 11.5v1M15 11.5v1M11 17v3M13 17v3',
 gem:'M6 3h12l4 6-10 12L2 9zM2 9h20M9 3l-2 6 5 12 5-12-2-6',rose:'M12 2l3 7 7 3-7 3-3 7-3-7-7-3 7-3z'};
const ico=(n,sz)=>`<svg viewBox="0 0 24 24" width="${sz||30}" height="${sz||30}" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="${IC[n]||IC.star}"/></svg>`;

/* ---------- achievements ---------- */
const TT=[['Bronze','#e8a062','#8a4a1a'],['Silver','#f2f6fa','#7a8896'],['Gold','#fff0a0','#c88a10'],['Platinum','#e6fbff','#3a9ed0']];
const AS=k=>(P.as&&P.as[k])||0,nCl=()=>Object.keys(P.stars).length,n3=()=>Object.values(P.stars).filter(s=>s>=3).length,nRanks=()=>Object.values(P.upg).reduce((a,b)=>a+b,0);
const ACH=[];const A=(id,cat,t,n,d,tg,v,g,sp)=>ACH.push({id,cat,t,n,d,tg,v,g,sp:sp||0});
A('flw25','Typing',0,'Clean Hands','Type 25 words in a row with no mistakes.',25,()=>AS('flw'),60);
A('flw50','Typing',1,'Steady Hands','Type 50 words in a row with no mistakes.',50,()=>AS('flw'),150);
A('flw100','Typing',2,'Flawless','Type 100 words with no mistakes.',100,()=>AS('flw'),400,1);
A('flw250','Typing',3,'Perfect Scribe','Type 250 words in a row with no mistakes.',250,()=>AS('flw'),1000,2);
const dcDays=()=>Object.values((P.dc&&P.dc.days)||{});
A('dc1','Campaign',0,'Daily Duty','Take on your first Daily Challenge.',1,()=>dcDays().length,100);
A('dc7','Campaign',1,'Creature of Habit','Reach a 7 day Daily Challenge streak.',7,()=>P.dc?Math.max(P.dc.best||0,P.dc.streak||0):0,400,1);
A('dcw5','Campaign',1,'Daily Victor','Win 5 Daily Challenges.',5,()=>dcDays().filter(d=>d.win).length,250);
A('dcS','Campaign',2,'Perfect Day','Earn an S rank on a Daily Challenge.',1,()=>dcDays().filter(d=>d.grade==='S').length,500,1);
A('kill100','Typing',0,'Monster Hunter','Slay 100 monsters.',100,()=>P.kills,80);
A('kill1k','Typing',1,'Slayer','Slay 1,000 monsters.',1000,()=>P.kills,300);
A('kill5k','Typing',2,'Exterminator','Slay 5,000 monsters.',5000,()=>P.kills,1000,1);
A('cmb50','Typing',0,'On Fire','Reach a streak of 50.',50,()=>AS('combo'),80);
A('cmb100','Typing',1,'Legendary Streak','Reach a streak of 100.',100,()=>AS('combo'),200);
A('cmb200','Typing',2,'Mythic Streak','Reach a streak of 200.',200,()=>AS('combo'),600,1);
A('wpm50','Typing',0,'Quick Fingers','Reach 50 words per minute in a run.',50,()=>AS('wpm'),80);
A('acc97','Typing',1,'Sharpshooter','Clear a campaign level with 97% accuracy or better.',97,()=>AS('acc'),250);
A('bsA','Catalog',0,'Field Notes','Discover 15 different monsters.',15,()=>seenN(REG()),100);
A('bsB','Catalog',2,'Naturalist','Discover every regular monster.',REG().length,()=>seenN(REG()),500,1);
A('bsC','Catalog',2,'Completionist Hunter','Slay every kind of regular monster at least once.',REG().length,()=>slainN(REG()),700,1);
A('bsD','Catalog',3,'Boss Compendium','Slay every one of the 30 bosses.',30,()=>slainN(BOSSES()),1500,2);
const ZV=z=>(P.zv&&P.zv[z]?P.zv[z].length:0);
['Woodsman','Grave Scholar','Web Reader','Forge Tongue','Frost Reader','Tidewise'].forEach((n,z)=>A('zv'+z,'Words',z%4,n,`Master the ${ZN2[z]} vocabulary: type all ${ZW[z].length} of its ${ZTAG[z]} words.`,ZW[z].length,()=>ZV(z),120+z*15,z>3?1:0));
A('zvall','Words',3,'Lexicon Lord','Master the vocabulary of all six zones.',6,()=>ZW.filter((l,z)=>ZV(z)>=l.length).length,1500,3);
A('shn1','Catalog',1,'Shimmer','Slay a shiny monster.',1,()=>P.shc||0,200,1);
A('shn2','Catalog',2,'Glitter Hunter','Slay 10 shiny monsters.',10,()=>P.shc||0,600,1);
A('shn3','Catalog',3,'Prismatic','Slay 50 shiny monsters.',50,()=>P.shc||0,2000,2);
A('mst1','Catalog',1,'Apprentice Scholar','Master any 3 monsters in the Bestiary.',3,()=>mbIds().filter(k=>mbTierOf(k)>=3).length,500,1);
A('mst2','Catalog',2,'Bestiary Warden','Reach the Warden rank in the Bestiary.',4,()=>mbRankInfo().i,1200,2);
A('boss1','Boss',0,'Giant Slayer','Defeat your first boss.',1,()=>AS('boss'),100);
A('boss10','Boss',1,'Boss Hunter','Defeat 10 bosses.',10,()=>AS('boss'),300);
A('boss30','Boss',2,'Bane of Tyrants','Defeat 30 bosses.',30,()=>AS('boss'),800,1);
A('bnh1','Boss',1,'Untouchable','Beat a boss without taking damage.',1,()=>AS('bnh'),250);
A('bnh5','Boss',3,'Dancer','Beat 5 bosses without taking damage.',5,()=>AS('bnh'),700,2);
A('par25','Boss',0,'Parry Practice','Parry 25 attacks with the space bar.',25,()=>AS('parry'),100);
A('par150','Boss',2,'Riposte Master','Parry 150 attacks.',150,()=>AS('parry'),400,1);
A('fur10','Boss',0,'Fury Unleashed','Fire 10 Fury Strikes.',10,()=>AS('fury'),100);
A('fk5','Boss',1,'Wide Swing','Defeat 5 monsters with one Fury Strike.',5,()=>AS('fk'),150);
A('cp1','Campaign',0,'First Steps','Clear campaign level 1.',1,nCl,50);
A('cp10','Campaign',1,'Wayfarer','Clear 10 campaign levels.',10,nCl,300);
A('cp30','Campaign',3,'Dragon\'s End','Clear all 30 campaign levels.',30,nCl,1500,3);
A('st1','Campaign',0,'Shining Star','Earn three stars on a level.',1,n3,120);
A('st10','Campaign',2,'Untarnished','Earn three stars on 10 levels.',10,n3,600,2);
A('lv10','Campaign',1,'Deep Delver','Reach level 10 in endless mode.',10,()=>P.bestLv,200);
A('lv20','Campaign',2,'Abyss Walker','Reach level 20 in endless mode.',20,()=>P.bestLv,600,1);
A('lv30','Campaign',3,'Edge of the World','Reach level 30 in endless mode.',30,()=>P.bestLv,1200,2);
A('pl5','Campaign',0,'Rising Hero','Reach player level 5.',5,()=>lvl(P.xp),100);
A('pl10','Campaign',1,'Seasoned Hero','Reach player level 10.',10,()=>lvl(P.xp),300);
A('pl20','Campaign',3,'Living Legend','Reach player level 20.',20,()=>lvl(P.xp),1000,2);
A('pl30','Campaign',3,'Max Level','Reach the maximum player level, 30.',30,()=>lvl(P.xp),2500,3);
A('cr1','Loot',0,'Crate Cracker','Open your first crate.',1,()=>AS('crates'),50);
A('cr25','Loot',1,'Treasure Hoarder','Open 25 crates.',25,()=>AS('crates'),200);
A('cr100','Loot',3,'Crate Baron','Open 100 crates.',100,()=>AS('crates'),500,1);
A('ep','Loot',1,'Lucky Find','Find an Epic item.',3,()=>AS('epic'),150);
A('lg','Loot',2,'Legend Found','Find a Legendary item.',4,()=>AS('epic'),400,1);
A('my','Loot',3,'Mythic!','Find a Mythic item.',5,()=>AS('epic'),1500,3);
A('pcr1','Loot',2,'Eclipse Opened','Open an Eclipse Chest.',1,()=>AS('pcr'),300);
A('mya','Loot',3,'Ascendant','Own the mythic Ascendant Panoply armor.',1,()=>P.ownA.ascend?1:0,1500,2);
A('myb','Loot',3,'Eclipsed','Own the mythic Eclipse Sovereign armor.',1,()=>P.ownA.eclipse?1:0,1500,2);
A('wm1','Loot',1,'Well Worn','Reach Mastery I with any weapon.',1,()=>wmCount(1),300,1);
A('wm2','Loot',2,'Weapon Master','Reach Mastery II with any weapon.',1,()=>wmCount(2),800,1);
A('wm3','Loot',3,'Armory of Legends','Reach Mastery II with 5 different weapons.',5,()=>wmCount(2),2000,2);
A('wm4','Loot',3,'Master Smith','Reach Mastery IV with any weapon.',1,()=>wmCount(4),1200,1);
A('wm5','Loot',3,'Grandmaster','Reach Mastery V with any weapon.',1,()=>wmCount(5),3000,2);
A('rf1','Campaign',1,'Stargazer','Complete a Starfall Rift run.',1,()=>AS('rift'),400,1);
A('rf2','Campaign',2,'Comet Catcher','Catch 5 Treasure Comets in the Rift.',5,()=>AS('comet'),900,1);
A('rf3','Campaign',3,'Starfall Legend','Score 30000 in a single Starfall Rift.',30000,()=>AS('riftScore'),1800,2);
A('pg1','Campaign',2,'Ascended','Prestige for the first time.',1,()=>P.pres||0,800,1);
A('pg5','Campaign',3,'Paragon of Words','Reach Prestige V.',5,()=>P.pres||0,2500,2);
A('pg10','Campaign',3,'Eternal Champion','Reach Prestige X.',10,()=>P.pres||0,6000,3);
A('col','Loot',1,'Collector','Own 20 weapons and armor sets.',20,()=>Object.keys(P.own).length+Object.keys(P.ownA).length,250);
A('gd5','Loot',0,'Coin Collector','Earn 5,000 gold from runs.',5000,()=>AS('gold'),100);
A('gd50','Loot',2,'Dragon\'s Hoard','Earn 50,000 gold from runs.',50000,()=>AS('gold'),800,1);
A('up1','Loot',0,'Fresh Perk','Buy your first skill tree upgrade.',1,nRanks,60);
A('up15','Loot',1,'Skilled','Buy 15 skill tree ranks.',15,nRanks,300);
A('upAll','Loot',3,'Grandmaster','Max out every skill tree perk.',1,()=>nRanks()>=NTOT()?1:0,3000,3);
A('daily','Loot',1,'Faithful','Claim the daily gift 7 days in a row.',7,()=>P.dstreak||0,200);
A('bj5','Casino',1,'Hot Hand','Win 5 blackjack hands in a row.',5,()=>AS('bj'),150);
A('bj10','Casino',2,'Card Shark','Win 6 blackjack hands in a row.',6,()=>AS('bj'),500,1);
A('bjn','Casino',0,'Twenty-One','Be dealt a natural blackjack.',1,()=>AS('bjn'),100);
A('tw5','Casino',1,'Stair Master','Reach floor 5 in Tower Climb.',5,()=>AS('twf'),200);
A('tw8','Casino',2,'Sky Walker','Reach floor 8 in Tower Climb.',8,()=>AS('twf'),600,1);
A('tw10','Casino',3,'Top of the Tower','Reach the summit of Tower Climb.',1,()=>AS('tws'),1500,2);
A('rk10','Casino',2,'To the Moon','Cash out the rocket at 10x or more.',10,()=>AS('rk'),300,1);
A('sl25','Casino',2,'Jackpot!','Land a slot spin that pays 20x your bet or more.',20,()=>AS('slotx'),400,1);
A('big1k','Casino',1,'High Roller','Win 1,000 gold or more on a single bet.',1000,()=>AS('bigwin'),250);
A('cw5','Casino',1,'Lucky Streak','Win 5 casino rounds in a row.',5,()=>AS('cwb'),150);
A('cp100','Casino',1,'Regular','Play 100 casino rounds.',100,()=>(P.cas&&P.cas.plays)||0,150);
A('qz50','Casino',1,'Quiz Whiz','Answer 50 Quiz Showdown clues correctly.',50,()=>AS('qzc'),150);
A('qz10','Casino',2,'On a Roll','Answer 8 Quiz Showdown clues in a row.',8,()=>AS('qzs'),300,1);
A('bty1','Loot',0,'Bounty Hunter','Claim your first bounty.',1,()=>AS('bty'),100);
A('bty25','Loot',1,'Hired Blade','Claim 25 bounties.',25,()=>AS('bty'),500,1);
A('bty100','Loot',3,'Legend of the Board','Claim 100 bounties.',100,()=>AS('bty'),2000,2);
A('qz2x','Casino',2,'Final Answer','Finish a Quiz Showdown with the top payout, 2.5x your stake.',1,()=>AS('qzx'),400,1);
A('plk','Casino',2,'Bullseye','Land a Plinko ball on a 10x slot or better.',10,()=>AS('plk'),300,1);
A('whl','Casino',2,'Fortune Favors','Hit a 10x or better slice on the Wheel of Fortune.',10,()=>AS('whl'),300,1);
const ACAT=['All','Typing','Words','Catalog','Boss','Campaign','Loot','Casino'];
let TQ=[],TB=0;
function achCheck(){if(!P||!P.ach)return;for(const a of ACH)if(!P.ach[a.id]&&a.v()>=a.tg){P.ach[a.id]=Date.now();P.gold+=a.g;P.spb+=a.sp;save();toast(a)}}
function trophy(t,on,sz){const c=TT[t];return `<svg class="tro${on?'':' off'}" viewBox="0 0 64 72" width="${sz||72}" height="${sz*72/64||81}"><defs><linearGradient id="tg${t}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${c[1]}"/><stop offset="1" stop-color="${c[2]}"/></linearGradient></defs><g fill="none" stroke="url(#tg${t})" stroke-width="4.5" stroke-linecap="round"><path d="M14 12H7c0 11 5 17 11 18M50 12h7c0 11-5 17-11 18"/></g><path d="M13 5h38v14c0 13-8 21-19 21S13 32 13 19z" fill="url(#tg${t})" stroke="${c[2]}" stroke-width="1.5"/><path d="M19 8h6v12c0 8 3 13 7 16-8-1-13-8-13-17z" fill="#fff" opacity=".35"/><path d="M28 40h8v9h-8z" fill="url(#tg${t})" stroke="${c[2]}" stroke-width="1.2"/><path d="M19 50h26l4 9v4H15v-4z" fill="url(#tg${t})" stroke="${c[2]}" stroke-width="1.5"/><path d="M32 12l2.4 5 5.4.6-4 3.7 1.1 5.3-4.9-2.7-4.9 2.7 1.1-5.3-4-3.7 5.4-.6z" fill="#fff" opacity=".85"/></svg>`}
function toast(a){TQ.push(a);if(!TB)nextToast()}
function nextToast(){const a=TQ.shift();if(!a){TB=0;return}TB=1;let el=document.getElementById('toast');if(!el){el=document.createElement('div');el.id='toast';wrap.appendChild(el)}
 el.className='';el.innerHTML=`${trophy(a.t,true,54)}<div><i>${esc(a.lb||'Trophy unlocked')}</i><b>${esc(a.n)}</b><span>${esc(a.d)}</span><em>+${a.g} gold${a.sp?'  +'+a.sp+' skill point'+(a.sp>1?'s':''):''}</em></div>`;void el.offsetWidth;el.className='show';
 try{[[880,0],[1108,110],[1318,220],[1760,340]].forEach(([f,d])=>setTimeout(()=>beep(f,.16,'triangle',.7),d))}catch(e){}
 setTimeout(nextToast,3800)}
function trophyCase(cat){cat=cat||'All';const list=ACH.filter(a=>cat==='All'||a.cat===cat),got=ACH.filter(a=>P.ach[a.id]).length;
 return `<div class="tcase" id="tc"><h3 class="sec" style="text-align:center">Trophy case <span style="font:17px Georgia,serif;opacity:.75">${got} of ${ACH.length} earned</span></h3><div class="xp" style="min-width:420px;margin:0 auto 12px"><i style="width:${got/ACH.length*100}%"></i></div>
 <div class="tabs">${ACAT.map(c=>`<button class="tab${c===cat?' on':''}" data-tc="${c}">${c}</button>`).join('')}</div>
 <div class="tgrid">${list.map(a=>{const on=!!P.ach[a.id],v=Math.min(a.tg,Math.floor(a.v()));return `<div class="tr${on?' on':''} t${a.t}" title="${esc(a.d)}">${trophy(a.t,on,70)}<b>${esc(a.n)}</b><small>${esc(a.d)}</small>${on?`<em>Earned</em>`:`<div class="pg"><i style="width:${Math.max(2,v/a.tg*100)}%"></i></div><span class="pv">${v.toLocaleString()} / ${a.tg.toLocaleString()}</span>`}<span class="rw">${TT[a.t][0]}: ${a.g} gold${a.sp?' + '+a.sp+' SP':''}</span></div>`}).join('')}</div></div>`}
function bjTrack(res){const a=P.as;if(res==='bj'||res==='win'){a.bjc=(a.bjc||0)+1;stat('bj',a.bjc,'max');if(res==='bj')stat('bjn',1,'add')}else if(res!=='push')a.bjc=0}
function casTrack(bet,pay){const a=P.as,net=pay-bet;if(net>0){a.cwc=(a.cwc||0)+1;stat('cwb',a.cwc,'max');stat('bigwin',net,'max')}else if(net<0)a.cwc=0;achCheck()}

/* ---------- pity ---------- */
const PITY=()=>12-U('fortune');
const price=k=>Math.round(PRICE[k]*(1-.04*U('haggle')));

/* ---------- skill tree ---------- */
const BRN={focus:{n:'Focus',s:'Typing and streaks',c:'#6fd8ff'},vital:{n:'Vitality',s:'Survival',c:'#7dffb0'},fort:{n:'Fortune',s:'Gold and loot',c:'#ffd76a'},fury:{n:'Fury',s:'Power and bosses',c:'#ff8a5a'}};
const TN=['Minor','Notable','Major','Keystone'],TCG=[200,500,1200,3000];
const ND=[];const N=(id,b,x,y,t,max,n,ic,req,e)=>ND.push({id,b,x,y,t,max,n,ic,req,e});
N('keeper','focus',620,215,0,3,'Combo Keeper','hourglass',['root'],r=>`A slip or a hit keeps ${50+5*r}% of your streak (base 50%).`);
N('qmul','focus',480,135,1,1,'Quick Multiplier','bolt',['keeper'],r=>'Each multiplier level needs 1 fewer letter in a row.');
N('calm','focus',480,250,1,3,'Calm Mind','moon',['keeper'],r=>`Monsters walk ${2*r}% slower.`);
N('forgive','focus',330,100,2,1,'Forgiving Fingers','check',['qmul'],r=>'Every word forgives one extra slip.');
N('flaw','focus',180,80,3,1,'Flawless Form','star',['forgive'],r=>'Words typed with no slip add 2 fury and bonus points.');
N('scholar','focus',330,250,2,3,'Scholar','book',['calm'],r=>`+${5*r}% XP from every run.`);
N('hardy','vital',620,385,0,1,'Hardy','heart',['root'],r=>`+${r} max HP in every run.`);
N('iron','vital',480,460,1,1,'Ironskin','shield',['hardy'],r=>`Start every run with ${r} shield${r>1?'s':''}.`);
N('rec','vital',480,350,1,1,'Rally','plus',['hardy'],r=>'Heal 1 HP every third round you clear.');
N('wind','vital',330,530,3,1,'Second Wind','flame',['iron'],r=>'Start every run with a free revive.');
N('will','vital',330,390,2,2,'Iron Will','tower',['rec'],r=>`After a hit you stay safe for ${(.75+.2*r).toFixed(2)}s (base 0.75s).`);
N('prosp','fort',880,215,0,4,'Prospector','coin',['root'],r=>`+${4*r}% gold from everything.`);
N('lucky','fort',1020,135,1,3,'Lucky Charm','chest',['prosp'],r=>`About ${(.48*r).toFixed(1)} more crate drops per 100 kills.`);
N('bounty','fort',1020,250,1,2,'Bounty Hunter','target',['prosp'],r=>`Bosses pay ${25*r}% more gold.`);
N('haggle','fort',1170,100,2,2,'Haggler','tag',['lucky'],r=>`Shop crates cost ${4*r}% less.`);
N('fortune','fort',1320,80,3,2,'Fortune\'s Favor','clover',['haggle'],r=>`Epic or better crates come sooner: guaranteed within ${12-r} crates instead of 12.`);
N('treasure','fort',1170,250,2,1,'Treasure Sense','crown',['bounty'],r=>'Cleared rounds pay 25% more gold.');
N('kind','fury',880,385,0,3,'Kindling','flame',['root'],r=>`Fury fills ${5*r}% faster.`);
N('vessel','fury',1020,460,1,2,'Fury Vessel','flask',['kind'],r=>r===1?'The fury bar is 25% bigger and can overfill past one strike.':'The fury bar is 50% bigger, banking a strike and a half.');
N('parry','fury',1020,350,1,2,'Riposte','swords',['kind'],r=>`Parry recovers ${(.06*r).toFixed(2)}s faster and gives ${3*r} extra fury.`);
N('breaker','fury',1170,390,2,2,'Boss Breaker','burst',['parry'],r=>`The boss weak spot window lasts ${(3.2+.3*r).toFixed(1)}s (base 3.2s).`);
N('berserk','fury',1170,530,3,1,'Berserker','skull',['vessel'],r=>'Every round starts with the fury bar 20% full.');
const NM={};for(const n of ND)NM[n.id]=n;const NTOT=()=>ND.reduce((a,n)=>a+n.max,0);
const gCost=(n,r)=>Math.round(TCG[n.t]*(1+.6*r)/10)*10,sCost=(n,r)=>[1,2,3,5][n.t]+(r>0?1:0);
const spTotal=()=>lvl(P.xp)-1+P.spb,spLeft=()=>spTotal()-P.us;
const reqOk=n=>n.req.some(q=>q==='root'||U(q)>0);
const nState=n=>{const r=U(n.id);return r>=n.max?'max':r>0?'own':reqOk(n)?'avail':'lock'};
function buyNode(id,mode){const n=NM[id],r=U(id);if(!n||r>=n.max||!reqOk(n))return false;
 if(mode==='g'){const c=gCost(n,r);if(P.gold<c)return false;P.gold-=c;P.ug+=c}else{const c=sCost(n,r);if(spLeft()<c)return false;P.us+=c}
 P.upg[id]=r+1;save();achCheck();return true}
/* auto allocate (prestige 1 and up): spends every skill point it can, always giving the next point to whichever branch would stay lowest */
const AAB=['focus','vital','fort','fury'];
function autoAlloc(){const sp0=spLeft(),got={focus:0,vital:0,fort:0,fury:0},w={};
 for(const b of AAB){w[b]=0;for(const n of ND)if(n.b===b)for(let r=0;r<U(n.id);r++)w[b]+=sCost(n,r)}
 for(;;){let pick=null,pw=1e9;
  for(const b of AAB){
   const c=ND.filter(n=>n.b===b&&U(n.id)<n.max&&reqOk(n)&&sCost(n,U(n.id))<=spLeft()).sort((x,y)=>U(x.id)/x.max-U(y.id)/y.max||x.t-y.t||ND.indexOf(x)-ND.indexOf(y));
   if(c.length){const a=w[b]+sCost(c[0],U(c[0].id));if(a<pw){pw=a;pick=c[0]}}}
 if(!pick)break;
  const cost=sCost(pick,U(pick.id));P.us+=cost;P.upg[pick.id]=U(pick.id)+1;w[pick.b]+=cost;got[pick.b]+=cost}
 const spent=sp0-spLeft();if(spent>0){save();achCheck()}return{spent,got,left:spLeft()}}
function respec(){try{sgSnap('Before respec','safe')}catch(e){}const back=Math.floor(P.ug*.75);P.gold+=back;P.ug=0;P.us=0;P.upg={};save();return back}
function upPanel(id){const B=$('up');if(!B)return;const st=$('utree').dataset.sel;id=id||st;
 if(!id||id==='root'){B.innerHTML=`<div class="uic" style="--c:#ffd76a">${ico('rose',40)}</div><div class="ui"><b>Warrior's Core</b><em>Where every path begins</em><p>Spend <b>gold</b> or <b>skill points</b> on permanent perks that apply to every run. Pick a branch, work outward, and finish with a keystone. You earn one skill point for every player level and more from trophies.</p></div><div class="ub"><small>Click a node to see its details.</small></div>`;return}
 const n=NM[id],r=U(id),Bc=BRN[n.b],stt=nState(n),gc=gCost(n,r),sc=sCost(n,r);
 B.innerHTML=`<div class="uic ${stt}" style="--c:${Bc.c}">${ico(n.ic,40)}</div><div class="ui"><b>${n.n}</b><em style="color:${Bc.c}">${Bc.n} branch &middot; ${TN[n.t]}</em><div class="pips">${Array.from({length:n.max},(_,i)=>`<i class="${i<r?'on':''}" style="--c:${Bc.c}"></i>`).join('')}<span>Rank ${r} of ${n.max}</span></div>
 ${r>0?`<p><span class="lab">Now</span> ${n.e(r)}</p>`:''}${r<n.max?`<p><span class="lab">${r>0?'Next':'Rank 1'}</span> ${n.e(r+1)}</p>`:''}${stt==='lock'?`<p class="need">Requires: ${n.req.map(q=>NM[q]?NM[q].n:q).join(' or ')}</p>`:''}</div>
 <div class="ub">${r>=n.max?'<div class="mast">Mastered</div>':stt==='lock'?'<div class="mast" style="opacity:.6">Locked</div>':`<button id="bg" ${P.gold>=gc?'':'disabled'}><span class="coin"></span> ${gc.toLocaleString()} gold</button><button id="bs" class="sp" ${spLeft()>=sc?'':'disabled'}><span class="spg"></span> ${sc} skill point${sc>1?'s':''}</button>`}</div>`;
 if($('bg'))$('bg').onclick=()=>doBuy(id,'g');if($('bs'))$('bs').onclick=()=>doBuy(id,'s')}
function doBuy(id,m){if(buyNode(id,m)){try{[[660,0],[880,70],[1320,150]].forEach(([f,d])=>setTimeout(()=>beep(f,.14,'triangle',.8),d))}catch(e){}upgrades(id,1)}else beep(140,.15,'sawtooth',.6)}
function upgrades(sel,pop){S.mode='title';S.view='menu';sel=sel||'root';const RX=750,RY=300;
 const edges=ND.flatMap(n=>n.req.map(q=>{const p=q==='root'?{x:RX,y:RY}:NM[q],mx=(p.x+n.x)/2,on=q==='root'||U(q)>0,full=on&&U(n.id)>0;return `<path d="M${p.x} ${p.y} C${mx} ${p.y} ${mx} ${n.y} ${n.x} ${n.y}" class="ed${full?' full':on?' open':''}" style="--c:${BRN[n.b].c}"/>`})).join('');
 const nodes=ND.map(n=>{const s=nState(n),r=U(n.id);return `<button class="un ${s} t${n.t}${pop&&sel===n.id?' pop':''}${sel===n.id?' sel':''}" data-n="${n.id}" style="left:${n.x}px;top:${n.y}px;--c:${BRN[n.b].c}" aria-label="${esc(n.n)}, rank ${r} of ${n.max}">${ico(n.ic,n.t===3?38:32)}<span class="rk">${r}/${n.max}</span></button>`}).join('');
 const lab={focus:[40,175,'start'],vital:[40,455,'start'],fort:[1460,175,'end'],fury:[1460,455,'end']};
 const labels=Object.keys(BRN).map(k=>`<text x="${lab[k][0]}" y="${lab[k][1]}" text-anchor="${lab[k][2]}" class="bl" fill="${BRN[k].c}">${BRN[k].n}</text><text x="${lab[k][0]}" y="${lab[k][1]+24}" text-anchor="${lab[k][2]}" class="bs2" fill="${BRN[k].c}">${BRN[k].s}</text>`).join('');
 show(`<div class="uhd"><h2>Skill Tree</h2><div class="ubal"><span class="ch"><span class="coin"></span><b>${P.gold.toLocaleString()}</b> gold</span><span class="ch"><span class="spg"></span><b>${spLeft()}</b> skill points</span><span class="ch dim">${nRanks()} of ${NTOT()} ranks</span></div><div class="row">${(P.pres||0)>=1?`<button class="sm hgd" id="aal"${spLeft()>=Math.min(...ND.filter(n=>U(n.id)<n.max&&reqOk(n)).map(n=>sCost(n,U(n.id))),1e9)?'':' disabled'}>Auto Allocate</button>`:''}<button class="sm dg" id="rsp">Respec</button><button class="sm" id="b">Back</button></div></div>
<div class="utree" id="utree" data-sel="${sel}"><svg viewBox="0 0 1500 600" class="uline"><defs><radialGradient id="rg"><stop offset="0" stop-color="#ffd76a" stop-opacity=".35"/><stop offset="1" stop-color="#ffd76a" stop-opacity="0"/></radialGradient></defs>
<circle cx="${RX}" cy="${RY}" r="300" fill="url(#rg)"/>${[140,290,440,600].map((r,i)=>`<circle cx="${RX}" cy="${RY}" r="${r}" class="ring"/>`).join('')}${edges}${labels}</svg>
<button class="un root${sel==='root'?' sel':''}" data-n="root" style="left:${RX}px;top:${RY}px;--c:#ffd76a" aria-label="Warrior's Core">${ico('rose',48)}</button>${nodes}</div>
<div class="upanel" id="up"></div>`,'ut');
 S.back=title;$('b').onclick=title;upPanel(sel);
 if($('aal'))$('aal').onclick=()=>{const r=autoAlloc();if(!r.spent){beep(140,.15,'sawtooth',.6);return}
  try{[[660,0],[880,70],[1320,150],[1760,230]].forEach(([f,d])=>setTimeout(()=>beep(f,.14,'triangle',.8),d))}catch(e){}
  upgrades('root');const B=$('up');if(B)B.innerHTML=`<div class="uic" style="--c:#ffd76a">${ico('rose',40)}</div><div class="ui"><b>Skill points allocated</b><em>${r.spent} point${r.spent>1?'s':''} spent evenly</em><p>${AAB.map(k=>`<span style="color:${BRN[k].c}">${BRN[k].n} ${r.got[k]}</span>`).join(' &middot; ')}${r.left?`<br>${r.left} left over, too few for any perk that is still open.`:''}</p></div><div class="ub"><small>Not what you wanted? Respec refunds every skill point.</small></div>`};
 $('rsp').onclick=e=>{const t=e.target;if(nRanks()===0){beep(140,.12,'sawtooth',.5);return}if(t.dataset.a){const b=respec();upgrades('root')}else{t.dataset.a=1;t.textContent=`Confirm: refund ${P.us} SP and ${Math.floor(P.ug*.75).toLocaleString()} gold (75%)`;setTimeout(()=>{if(t.isConnected){t.dataset.a='';t.textContent='Respec'}},4000)}};
 ov.querySelectorAll('.un').forEach(el=>{const id=el.dataset.n;el.onclick=()=>{$('utree').dataset.sel=id;ov.querySelectorAll('.un.sel').forEach(x=>x.classList.remove('sel'));el.classList.add('sel');upPanel(id);beep(520,.04,'triangle',.4)};el.onmouseenter=()=>upPanel(id);el.onmouseleave=()=>upPanel()})}
