/* ===== 9.4 THE CROOKED CUE: 8-ball rules and match state (96c). Pure functions. Ported from pool_plan/pzrules.js. =====
   Tavern rules:
   - Break: legal if a ball is pocketed or 4+ object balls reach a cushion. An illegal break or a scratch is a foul (opponent: ball
     in hand behind the head string). The 8 on the break without a scratch = GOLDEN BREAK (breaker wins the rack). The 8 on the break
     with a scratch is spotted. The table is open after the break.
   - Open table: the first ball hit may be any ball except the 8. The first legally pocketed ball sets the groups.
   - Groups set: the first ball hit must be your group (the 8 once your group is gone).
   - Foul: scratch, no ball hit, wrong ball first, or no cushion touched after contact while nothing was pocketed.
     Opponent gets ball in hand anywhere. Balls pocketed on a foul stay down.
   - You keep shooting while you legally pocket one of yours (any ball on an open table).
   - The 8: with your group gone you call a pocket for it. 8 in the called pocket = win the rack. 8 elsewhere, 8 too early, or 8 with a
     foul = lose the rack. House rule bank8 (Barnacle): the 8 must kiss a cushion before it drops, or it is spotted and that is a foul. */
const pzSol=b=>b>=1&&b<=7,pzStr=b=>b>=9&&b<=15,pzGrp=b=>pzSol(b)?'s':pzStr(b)?'t':null;
function pzrNew(B,breaker,house){return {B,turn:breaker,breaker,grp:[null,null],open:true,brk:true,bih:false,kitchen:false,over:null,call:null,golden:false,
 house:house||{},visits:[0,0],fouls:[0,0],shots:0,runs:[0,0],run:0}}
function pzrLeft(st,p){const g=st.grp[p];if(!g)return 7;return st.B.filter(b=>b.on&&pzGrp(b.id)===g).length}
/* is the shooter on the 8? */
function pzrOn8(st){const g=st.grp[st.turn];return !st.open&&!!g&&!st.B.some(b=>b.on&&pzGrp(b.id)===g)}
/* legal first-contact targets for the player to move */
function pzrTargets(st){const p=st.turn,g=st.grp[p],on=st.B.filter(b=>b.on&&b.id);
 if(st.open||!g){const t=on.filter(b=>b.id!==8).map(b=>b.id);return t.length?t:[8]}
 const mine=on.filter(b=>pzGrp(b.id)===g).map(b=>b.id);return mine.length?mine:[8]}
/* note a turn change (visits are how break-and-run is told) */
function pzrPass(st,to){st.turn=to;st.visits[to]++;st.run=0}
/* judge a finished shot. ev = physics events. Updates st and returns the report:
   {foul,reason,keep,win,pk,first,scratch,banks,combos,golden,spot8,runLen} */
/* the 8 goes back on the foot spot, or the nearest free spot along the table (never on top of another ball) */
function pzrSpot8(B,e){const R=PZ_PHY.R,W=PZ_PHY.W,H=PZ_PHY.H,ok=(x,y)=>x>R&&x<W-R&&y>R&&y<H-R&&B.every(b=>b===e||!b.on||(b.x-x)**2+(b.y-y)**2>=(2*R+1)**2);
 for(let k=0;k<12;k++)for(const [dx,dy] of [[k,0],[-k,0],[0,k],[0,-k],[k,k],[k,-k],[-k,k],[-k,-k]]){const x=W*.75+dx*(2*R+2),y=H/2+dy*(2*R+2);if(ok(x,y)){e.x=x;e.y=y;e.on=true;e.vx=e.vy=e.ux=e.uy=e.es=0;return}}
 e.x=W*.75;e.y=H/2;e.on=true;e.vx=e.vy=e.ux=e.uy=e.es=0}
function pzrJudge(st,ev){const p=st.turn,o=1-p,B=st.B,brk0=!!st.brk;let first=null,railAfter=false;const cuOb=new Set(),rails=new Set(),bbWith={},bbCue={};
 for(const e of ev){if(e.t==='bb'){if(first===null&&(e.a===0||e.b===0))first=e.a===0?e.b:e.a;
   if(e.a===0||e.b===0){const x=e.a===0?e.b:e.a;bbCue[x]=1}else{bbWith[e.a]=1;bbWith[e.b]=1}}
  if(e.t==='cu'){if(first!==null)railAfter=true;if(e.a){cuOb.add(e.a);if(!e.j)rails.add(e.a)}}}
 const pk=ev.filter(e=>e.t==='pk').map(e=>e.a),scratch=pk.includes(0),objPk=pk.filter(b=>b),eightIn=objPk.includes(8);
 const banks=brk0?0:objPk.filter(b=>b!==8&&rails.has(b)).length,combos=objPk.filter(b=>bbWith[b]&&!bbCue[b]).length;
 const r={foul:false,reason:'',keep:false,win:null,pk:objPk,first,scratch,banks,combos,golden:false,spot8:false,hit8:false};
 const finish=(winner,why)=>{st.over={winner,why};r.win=winner;return r};
 st.shots++;
 /* ---- the break ---- */
 if(st.brk){st.brk=false;const legal=objPk.length>0||cuOb.size>=4;
  if(eightIn&&!scratch){st.golden=true;r.golden=true;return finish(p,'golden')}
  if(eightIn&&scratch){pzrSpot8(B,B.find(b=>b.id===8));r.spot8=true}
  if(scratch||!legal){r.foul=true;r.reason=scratch?'Scratch on the break':'Illegal break';st.bih=true;st.kitchen=true;pzrPass(st,o);st.fouls[p]++;return r}
  r.keep=objPk.length>0;if(!r.keep)pzrPass(st,o);else st.run++;return r}
 /* ---- legality is judged against the table as it was before the shot ---- */
 const gp=st.grp[p],mineBefore=gp&&!st.open?B.filter(b=>b.id&&pzGrp(b.id)===gp&&(b.on||objPk.includes(b.id))).length:7;
 const legalFirst=id=>st.open||!gp?(id!==8||B.filter(b=>b.id&&b.id!==8&&(b.on||objPk.includes(b.id))).length===0):mineBefore>0?pzGrp(id)===gp:id===8;
 if(scratch){r.foul=true;r.reason='Scratch'}
 else if(first===null){r.foul=true;r.reason='No ball hit'}
 else if(!legalFirst(first)){r.foul=true;r.reason='Wrong ball first'}
 else if(!railAfter&&objPk.length===0){r.foul=true;r.reason='No cushion after contact'}
 if(first===8)r.hit8=true;
 if(eightIn){
  /* bank-the-8 house rule: no cushion = spotted and a foul (not a loss) */
  if(st.house.bank8&&!rails.has(8)&&!r.foul&&!st.open&&gp&&mineBefore===0){const e=B.find(b=>b.id===8);pzrSpot8(B,e);
   r.foul=true;r.reason='8 without a bank';r.spot8=true;st.bih=true;st.kitchen=false;pzrPass(st,o);st.fouls[p]++;return r}
  const was=!st.open&&gp&&mineBefore===0;
  const e8=ev.find(e=>e.t==='pk'&&e.a===8),pocketOk=st.call==null||e8.p===st.call;
  if(r.foul)return finish(o,'8 with a foul');if(!was)return finish(o,'8 too early');if(!pocketOk)return finish(o,'8 in the wrong pocket');return finish(p,'8 ball')}
 if(r.foul){st.bih=true;st.kitchen=false;pzrPass(st,o);st.fouls[p]++;return r}
 /* ---- groups ---- */
 if(st.open){const g=objPk.map(pzGrp).find(x=>x);if(g){st.grp[p]=g;st.grp[o]=g==='s'?'t':'s';st.open=false}}
 const mineIn=objPk.some(b=>st.grp[p]?pzGrp(b)===st.grp[p]:b!==8);
 r.keep=mineIn;if(!r.keep)pzrPass(st,o);else st.run++;st.bih=false;return r}
/* match state: a race to N racks; break order alternates (winnerBreaks: the winner breaks) */
function pzMatchNew(o){return {opp:o.opp,stake:o.stake||0,mult:o.mult||1,race:o.race||2,score:[0,0],rack:1,breaker:o.breaker==null?0:o.breaker,practice:!!o.practice,
 house:o.house||{},over:null,hustle:!!o.hustle,extended:false,bnr:0,golden:0,pots:0,banks:0,racks:[]}}
/* a rack is over: record it and set up the next breaker. returns the match (M.over set when someone reached the race) */
function pzMatchRack(M,st,rackInfo){const w=st.over.winner;M.score[w]++;
 const bnr=w===st.breaker&&st.visits[1-st.breaker]===0&&st.over.why!=='golden';
 M.racks.push({w,why:st.over.why,bnr,golden:st.golden,shots:st.shots});
 if(w===0){if(bnr)M.bnr++;if(st.golden)M.golden++}
 if(M.score[w]>=M.race)M.over={winner:w};
 else{M.rack++;M.breaker=M.house.winnerBreaks?w:1-M.breaker}
 return {bnr,w}}
