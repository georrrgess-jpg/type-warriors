# python3 t_pool96.py : 9.6 The Crooked Cue: ball sets (8, with their unlocks and paint cost), the new cues, the player
# portrait, the emblem (hub, casino tile, Special switcher), ball speed (no auto fast-forward, smooth slow-down) and the
# balanced aim guide (no simulated paths or pocket rings; Full/Short/Pro lengths) with its texts.
import asyncio,os,sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:500]),flush=True)
    if not ok:FAIL.append(name)
PRE="()=>{RS_ASK=false;PZ_TUT_OFF=true;WCRELAYS=[];ST.perfAsked=1;PFW.asked=true;P.gold=100000;P.pz=null;save()}"
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();er=[]
        pg=await b.new_page(viewport={'width':1600,'height':900})
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(H);await pg.wait_for_timeout(1500);await pg.evaluate(PRE);E=pg.evaluate
        # ---------------------------------------------------------------- ball sets
        r=await E("()=>[PZ_BALLS.map(b=>b.id),PZ_BALLS.every(b=>PZ_BPAL[b.id]&&PZ_BPAL[b.id].kind&&b.n&&b.how),PZ_BALLS.filter(b=>b.price).map(b=>b.price),PZ_BALLS.filter(b=>b.beat).map(b=>b.beat)]")
        chk('eight ball sets, each with a material and a way to get it',len(r[0])==8 and r[1] and len(set(r[0]))==8,r)
        r=await E("()=>{P.pz=null;const Z=PZS();Z.balls='nope';save();P.pz=JSON.parse(JSON.stringify(P.pz));return PZS().balls}")
        chk('an unknown ball set in a save falls back to Classic',r=='classic',r)
        r=await E("()=>{P.pz=null;const Z=PZS();Z.beat.grizzle=1;const got=pzUnlockSweep();return [!!PZS().ballsets.lava,got.some(x=>x.t==='balls'&&x.id==='lava'),!!PZS().ballsets.galaxy]}")
        chk('beating Grizzle once unlocks Ember Core (and only that set)',r[0] and r[1] and not r[2],r)
        r=await E("""()=>{const R={};for(const s of PZ_BALLS.map(b=>b.id)){pzbSetup(52,s);const t0=performance.now();for(let k=0;k<12;k++)for(let n=0;n<16;n++)pzbPaint(n,n,pzbRot(pzbI(),0,1,0,k*.3+n*.1));R[s]=+((performance.now()-t0)/12).toFixed(2)}return R}""")
        chk('repainting all 16 balls costs under 12 ms for every set (headless)',all(v<12 for v in r.values()),r)
        r=await E("""()=>{pzbSetup(52,'lava');const B=[];for(let i=0;i<16;i++)B.push({id:i,M:pzbRot(pzbI(),0,1,0,i*.2),dirty:1});pzbSync(B);B.forEach(b=>b.dirty=1);const t0=performance.now();const n=pzbSync(B);const dt=performance.now()-t0;let left=B.filter(b=>b.dirty).length;for(let k=0;k<8&&left;k++){pzbSync(B);left=B.filter(b=>b.dirty).length}return [n,+dt.toFixed(2),left]}""")
        chk('moving balls repaint inside a frame budget and every ball catches up within a few frames',r[0]>=4 and r[1]<6 and r[2]==0,r)
        r=await E("""()=>{const out={};for(const s of PZ_BALLS.map(b=>b.id)){pzbSetup(52,s);pzbPaint(0,3,pzbI());const d=PZ_BS.ax.getImageData(0,0,52,52).data;let op=0,lum=0;for(let i=0;i<d.length;i+=4){if(d[i+3]>200){op++;lum+=d[i]+d[i+1]+d[i+2]}}out[s]=[op,Math.round(lum/op/3)]}pzbSetup(52,'classic');return out}""")
        chk('every set paints a solid, visible ball (enough opaque pixels, not black, not blown out)',all(v[0]>1500 and 25<v[1]<245 for v in r.values()),r)
        # ---------------------------------------------------------------- cues and portrait
        r=await E("""()=>PZ_CUES.map(c=>{PZ_CUE.cache={};const s=pzCueSprite(c.id),g=s.c.getContext('2d');const px=(x,y)=>g.getImageData(x,y,1,1).data[3];return [c.id,s.W===(PZ_CUE.L+22)*2&&s.H===60,px(s.W-24,30)>200,px(40,30)>200,px(Math.round(s.W*.3),30)>200]})""")
        chk('every cue sprite builds at the old size with a solid tip, butt and wrap',all(x[1] and x[2] and x[3] and x[4] for x in r),[x for x in r if not all(x[1:])])
        await E("()=>{casinoOpen();gameOpen('pz');pzStart({opp:'gloop',practice:true,seed:3});setTimeout(()=>{const i=document.getElementById('pzintro');if(i)i.click()},400);0}");await pg.wait_for_timeout(3500)
        r=await E("""()=>{const c=document.createElement('canvas');c.width=c.height=132;const g=c.getContext('2d');pzCastPortrait(g,'hero',null,132,0);const d=g.getImageData(0,0,132,132).data;const a=(x,y)=>d[(y*132+x)*4+3];let top=0;for(let x=0;x<132;x++)if(a(x,4)>0)top++;return [a(66,50),a(66,110),top]}""")
        chk('the player portrait is a head-and-shoulders crop centred on the face',r[0]>200 and r[1]>200,r)
        # ---------------------------------------------------------------- ball speed
        r=await E("""()=>{const ph=PZ.ph;PZ.ph='roll';const B=PZ.B;const sv=B.map(b=>[b.vx,b.vy]);B.forEach(b=>{b.vx=40;b.vy=0});const a=pzFF();PZ.ffHeld=true;const h=pzFF();PZ.ffHeld=false;B.forEach((b,i)=>{b.vx=sv[i][0];b.vy=sv[i][1]});PZ.ph=ph;return [a,h]}""")
        chk('no automatic fast-forward at the end of a shot (holding still speeds up)',r[0]==1 and r[1]==3,r)
        r=await E("""()=>{const mk=()=>({id:0,x:100,y:220,vx:0,vy:0,ux:0,uy:0,es:0,on:true});let worst=0,prev=1e9,steps=0;const b=mk();pzpStrike(b,0.02,.35,0,0);const B=[b];for(let i=0;i<600;i++){pzpStep(B,1/120,[]);const s=Math.hypot(b.vx,b.vy);if(s>prev+1e-6)worst=Math.max(worst,s-prev);prev=s;if(s===0){steps=i;break}}return [worst,steps/120,PZ_PHY.MURL>0]}""")
        chk('a rolling ball only ever slows down and settles in under 4 s (a little extra drag at crawling speed)',r[0]==0 and 0<r[1]<4 and r[2],r)
        # ---------------------------------------------------------------- the guide
        r=await E("""()=>{let sims=0;const g0=window.pzGuideSimGet;window.pzGuideSimGet=function(){sims++;return g0.apply(this,arguments)};const B=PZ.B;PZ.st.brk=false;B.forEach((b,i)=>{if(i>1)b.on=false});B[0].x=200;B[0].y=220;B[1].on=true;B[1].x=500;B[1].y=200;const cv=document.createElement('canvas');cv.width=1600;cv.height=900;const g=cv.getContext('2d');
          const L={};for(const m of['full','short','pro']){g.clearRect(0,0,1600,900);pzDrawGuide(g,B,Math.atan2(200-220,488-200),m,0,0);const d=g.getImageData(0,0,1600,900).data;let gold=0,minx=1e9,maxx=-1;for(let i=0;i<d.length;i+=4){if(d[i+3]>60&&d[i]>200&&d[i+1]>170&&d[i+2]<140){gold++;const x=(i/4)%1600;if(x<minx)minx=x;if(x>maxx)maxx=x}}L[m]=[gold,maxx-minx]}
          window.pzGuideSimGet=g0;return [sims,L,PZ_GUIDE.full.obj,PZ_GUIDE.short.obj]}""")
        L=r[1]
        chk('the guide never plays the shot out (no simulated paths or pocket rings)',r[0]==0,r)
        chk('Full shows a longer gold line than Short, Pro shows none, and Full stops at 230 px',L['full'][0]>L['short'][0]>0 and L['pro'][0]==0 and L['full'][1]<=240 and r[2]==230,r)
        await E("()=>{pzForfeit&&pzForfeit()}");await pg.wait_for_timeout(300)
        r=await E("()=>{const h=pzSettingsModal.toString(),t=pzTipsTurn.toString(),v=(typeof PZ_HOWTO!=='undefined'?JSON.stringify(PZ_HOWTO):'')+[...document.scripts].length;return [/every ball goes/.test(h),/green ring/.test(t),/first cushion/.test(h)]}")
        chk('the settings and the first-match lesson describe the new guide',not r[0] and not r[1] and r[2],r)
        # ---------------------------------------------------------------- emblem and casino logo
        await E("()=>{P.pz=null;save();pzHub();0}");await pg.wait_for_timeout(1500)
        r=await E("()=>[!!document.querySelector('.pztitle .pzemb'),/Crooked Cue/.test(TA.pz),/pzeF/.test(TA.pz)]")
        chk('the emblem sits beside the hub title and on the casino tile',all(r),r)
        await E("()=>{if(typeof pzLeave==='function')pzLeave();S.mode='title';casinoOpen();CAS.sp='pz';0}");await pg.wait_for_timeout(800)
        await E("()=>{const t=[...document.querySelectorAll('button')].find(x=>/Special/.test(x.textContent));if(t)t.click();0}");await pg.wait_for_timeout(800)
        r=await E("()=>[!!document.querySelector('.pzfeat .pzemb, .pzfeat svg'),!!document.querySelector('[data-sp=pz] .pzemb'),(document.querySelector('.pzrib')||{}).textContent||'']")
        chk('the Special card shows the emblem art and the switcher button carries the emblem',r[0] and r[1] and '9.6' in r[2],r)
        # ---------------------------------------------------------------- the Cue Rack ball wall
        await E("()=>{P.pz=null;save();PZ.rackTab='balls';pzCueRack();0}");await pg.wait_for_timeout(1500)
        r=await E("()=>{const w=document.querySelector('.pzkwall.balls'),c=[...w.querySelectorAll('.pzki')];const wb=w.getBoundingClientRect();return [c.length,c.every(x=>{const r=x.getBoundingClientRect();return r.bottom<=wb.bottom+1&&r.right<=wb.right+1}),[...w.querySelectorAll('.pzktag canvas')].every(x=>x.getBoundingClientRect().width<40)]}")
        chk('the Cue Rack ball wall shows all eight sets inside the wall, with small regular badges',r[0]==8 and r[1] and r[2],r)
        chk('no page errors',not er,er)
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
