/* ===== WILDCARD: room codes over a public relay =====
   A browser cannot accept incoming connections, so two devices need a go-between just long enough to swap their
   WebRTC connection details. Here that go-between is a free public MQTT broker reached over a secure WebSocket (no
   account, no setup). Several brokers are tried at once and whichever answer are used together, so one being down
   does not matter. Messages are encrypted with a key made from the room code (AES-GCM) and posted to a topic hashed
   from it, so the brokers only ever see scrambled bytes. Once the data channel opens, the game itself goes straight
   from device to device and the relay is no longer needed.
     guest -> host   knock {gid,name}        (repeated until answered)
     host  -> guest  offer {sdp} | full | started
     guest -> host   answer {gid,sdp}
   A tiny MQTT 3.1.1 client (CONNECT, SUBSCRIBE, PUBLISH at QoS 0, PING) is all that is needed.
   School networks: most only allow ordinary web traffic on port 443, so the list mixes brokers on 443 with Nostr relays
   (89q, entries starting 'nostr:'), which are all on 443. If the two devices still cannot reach each other directly,
   the game itself is carried over this relay (89r). */
var WCRELAYS=['wss://mqtt.eclipseprojects.io:443/mqtt','wss://public:public@public.cloud.shiftr.io:443',
 'nostr:wss://relay.damus.io','nostr:wss://nos.lol','nostr:wss://relay.primal.net','nostr:wss://nostr.mom',
 'wss://broker.emqx.io:8084/mqtt','wss://broker.hivemq.com:8884/mqtt','wss://test.mosquitto.org:8081/mqtt'];
const WCSTUN={iceServers:[{urls:['stun:stun.l.google.com:19302','stun:stun1.l.google.com:19302']},{urls:'stun:stun.cloudflare.com:3478'}]};
const wcTE=new TextEncoder(),wcTD=new TextDecoder();
function wcMqStr(s){const b=wcTE.encode(s);return[b.length>>8,b.length&255,...b]}
function wcMqPkt(type,body){const L=[];let n=body.length;do{let d=n%128;n=Math.floor(n/128);if(n>0)d|=128;L.push(d)}while(n>0);return new Uint8Array([type,...L,...body])}
/* one broker connection: calls onMsg(topic, bytes) and onState('open'|'closed') */
function wcMq(url,topics,onMsg,onState){const o={ok:false,ws:null,buf:new Uint8Array(0),pid:1,ping:0,dead:false};let user='',pass='';
 try{const u=new URL(url);if(u.username){user=decodeURIComponent(u.username);pass=decodeURIComponent(u.password);u.username='';u.password='';url=u.href}}catch(e){}
 try{o.ws=new WebSocket(url,['mqtt']);o.ws.binaryType='arraybuffer'}catch(e){o.dead=true;setTimeout(()=>onState('closed',o),0);return o}
 const send=p=>{try{if(o.ws.readyState===1)o.ws.send(p)}catch(e){}};o.send=send;
 o.ws.onopen=()=>{const id='tw'+Math.random().toString(36).slice(2,14);send(wcMqPkt(0x10,[...wcMqStr('MQTT'),4,user?0xC2:2,0,40,...wcMqStr(id),...(user?[...wcMqStr(user),...wcMqStr(pass)]:[])]))};
 o.ws.onmessage=e=>{const a=new Uint8Array(e.data),b=new Uint8Array(o.buf.length+a.length);b.set(o.buf);b.set(a,o.buf.length);o.buf=b;
  for(;;){if(o.buf.length<2)break;let mul=1,len=0,i=1,d;do{if(i>=o.buf.length)return;d=o.buf[i++];len+=(d&127)*mul;mul*=128}while(d&128);if(o.buf.length<i+len)break;
   const t=o.buf[0]>>4,body=o.buf.slice(i,i+len);o.buf=o.buf.slice(i+len);
   if(t===2){if(body[1]===0){o.ok=true;for(const tp of topics)send(wcMqPkt(0x82,[0,o.pid++,...wcMqStr(tp),0]));o.ping=setInterval(()=>send(new Uint8Array([0xC0,0])),25000);onState('open',o)}else{o.ws.close()}}
   else if(t===3){const tl=(body[0]<<8)|body[1],tp=wcTD.decode(body.slice(2,2+tl));onMsg(tp,body.slice(2+tl))}}};
 o.ws.onclose=o.ws.onerror=()=>{if(o.dead)return;o.dead=true;o.ok=false;clearInterval(o.ping);onState('closed',o)};
 o.pub=(tp,bytes)=>{if(o.ok)send(wcMqPkt(0x30,[...wcMqStr(tp),...bytes]))};
 o.close=()=>{o.dead=true;clearInterval(o.ping);try{send(new Uint8Array([0xE0,0]));o.ws.close()}catch(e){}};return o}
/* ---------- the relay for one room: open, send, close ---------- */
const WCR={code:'',inbox:'',conns:[],key:null,base:'',seen:new Set(),on:null,state:'off',st:null};
async function wcRKey(code){const h=await crypto.subtle.digest('SHA-256',wcTE.encode('twwc-key|'+code));return crypto.subtle.importKey('raw',h,'AES-GCM',false,['encrypt','decrypt'])}
async function wcRBase(code){const h=new Uint8Array(await crypto.subtle.digest('SHA-256',wcTE.encode('twwc-topic|'+code)));return 'twwc/v1/'+Array.from(h.slice(0,10),b=>b.toString(16).padStart(2,'0')).join('')}
/* direct connections are no longer required: when they are blocked, the game goes over the relay instead */
const wcRelayOk=()=>typeof WebSocket==='function'&&!!(window.crypto&&crypto.subtle);
/* inbox: 'h' for the host, 'g'+id for a guest. onMsg(obj). onState(state) with state 'connecting' | 'online' | 'offline' */
async function wcRelayOpen(code,inbox,onMsg,onState){wcRelayClose();if(!wcRelayOk()){onState&&onState('offline');return false}
 const tok={};WCR.tok=tok;Object.assign(WCR,{code,inbox,conns:[],on:onMsg,st:onState,state:'connecting',seen:new Set()});
 try{WCR.key=await wcRKey(code);WCR.base=await wcRBase(code)}catch(e){onState&&onState('offline');return false}if(WCR.tok!==tok)return false;
 const topic=WCR.base+'/'+inbox;onState&&onState('connecting');let closed=0;
 /* a relay that worked and then dropped (school filters often cut long connections) is reconnected, with a growing pause */
 const mk=u=>{const o=/^nostr:/.test(u)?wcNostr(u.slice(6),[topic],msg,st):wcMq(u,[topic],msg,st);o.url=u;return o},tries={};
 const st=(s,o)=>{if(WCR.tok!==tok)return;if(s==='open'){o.was=1;tries[o.url]=0;if(WCR.state!=='online'){WCR.state='online';onState&&onState('online')}}
  if(s==='closed'&&o.was&&o.url&&(tries[o.url]=(tries[o.url]||0)+1)<=12)setTimeout(()=>{if(WCR.tok!==tok)return;const i=WCR.conns.indexOf(o);if(i>=0){const n=mk(o.url);n.was=1;WCR.conns[i]=n}},Math.min(30000,1500*tries[o.url]));
  else{closed++;if(closed>=WCRELAYS.length&&!WCR.conns.some(c=>c.ok)){WCR.state='offline';onState&&onState('offline')}else if(!WCR.conns.some(c=>c.ok)&&WCR.state==='online'){WCR.state='connecting';onState&&onState('connecting')}}};
 const msg=async(tp,bytes)=>{if(WCR.tok!==tok||bytes.length<14)return;try{const pt=await crypto.subtle.decrypt({name:'AES-GCM',iv:bytes.slice(0,12)},WCR.key,bytes.slice(12));const o=JSON.parse(wcTD.decode(pt));
  if(!o||!o.mid||WCR.seen.has(o.mid))return;WCR.seen.add(o.mid);if(WCR.seen.size>400)WCR.seen=new Set([...WCR.seen].slice(-200));WCR.on&&WCR.on(o)}catch(e){}};
 WCR.conns=WCRELAYS.map(mk);
 setTimeout(()=>{if(WCR.tok===tok&&WCR.state==='connecting'&&!WCR.conns.some(c=>c.ok)){WCR.state='offline';onState&&onState('offline')}},9000);return true}
/* the key, topic and connections are taken when the call is made, so a message sent just before closing still goes out */
async function wcRelaySend(to,obj){const key=WCR.key,conns=WCR.conns,base=WCR.base;if(!key||!conns.some(c=>c.ok))return false;const o=Object.assign({mid:Math.random().toString(36).slice(2)+Date.now().toString(36)},obj),iv=crypto.getRandomValues(new Uint8Array(12));
 const ct=new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv},key,wcTE.encode(JSON.stringify(o)))),b=new Uint8Array(12+ct.length);b.set(iv);b.set(ct,12);
 for(const c of conns)c.pub(base+'/'+to,b);return true}
function wcRelayClose(){WCR.tok=null;const cs=WCR.conns;WCR.conns=[];WCR.state='off';WCR.key=null;if(cs.length)setTimeout(()=>{for(const c of cs)c.close()},700)}
/* room codes use 32 unambiguous characters (no I, O, 0 or 1) */
const WCAB='ABCDEFGHJKLMNPQRSTUVWXYZ23456789',wcCodeNorm=s=>String(s||'').toUpperCase().split('').filter(ch=>WCAB.includes(ch)).join('').slice(0,4);
