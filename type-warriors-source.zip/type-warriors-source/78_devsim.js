/* developer tool: "Win level" in the Developer tools Cheats tab (password-protected) while playing a campaign level.
   It settles the level as a three-star win with randomly generated results. There is no keyboard shortcut. */
(function(){
  const rnd=(a,b)=>a+Math.random()*(b-a),ri=(a,b)=>Math.round(rnd(a,b));
 function sim(){
  if(S.mode!=='play'||!(S.camp>0)||S.prac||S.rift||S.dc)return;
  const n=S.camp;
  S.en=[];S.pj=[];S.bk=[];S.blind=0;S.spawnLeft=0;S.ban=0;
  /* settle the rest of the level exactly the way a flawless normal run would score it:
     every remaining enemy, in every remaining round, is "typed" with the live combo multiplier, elite and crit odds,
     boss sentences and phase breaks, so victory() pays the same player XP a real completion would. */
  const zi=zoneIdx(S.wave),step=Math.max(S.qm?3:4,10-2*(S.cq||0)-(S.qm||0));
  let combo=S.combo||0,score=S.score,kills=S.kills,chars=0,maxC=S.maxCombo;
  const type=(len,wt,el)=>{const m=Math.min(10,1+Math.floor(combo/step));score+=len*10*m*wt*el*S.sc*(1+(S.crit||0)*(wt>1?0:1));combo+=len;chars+=len;if(combo>maxC)maxC=combo;kills++};
  const avgLen=(role,d)=>{const sh=Math.min(4,d/13|0),[lo,hi]=[[4,6+sh],[3,4+sh],[7+(sh>>1),10+sh]][role];return (lo+hi)/2};
  for(let r=S.round;r<=5;r++){
   const wv=S.wave+(r-S.round),z=lvDef(wv),md=z.mod,d=S.d+(r-S.round)*(S.camp>=27?.4:.6),boss=r===5;
   let sl=Math.min(S.camp>=28?11:S.camp>=27?14:18,4+r*2+(S.camp>=28?4:S.camp>=27?7:S.camp/3|0));
   if(S.camp>=13)sl=Math.max(4,Math.round(sl*Math.max(.8,.9-.0075*(S.camp-13))));
   if(md==='swarm'||md==='finale')sl=Math.min(20,Math.round(sl*1.45));if(md==='giants')sl=Math.max(3,Math.round(sl*.6));
   let foes=boss?3:sl,bossLeft=boss;
   if(r===S.round){const live=S.en.filter(e=>!e.boss).length,bAlive=S.en.some(e=>e.boss);
    if(boss){bossLeft=S.spawnLeft>0||bAlive;foes=Math.max(0,(S.spawnLeft>0?S.spawnLeft-1:0)+live)}else foes=S.spawnLeft+live}
   const p=md==='elite'?.34:d>=4?.12:0;
   for(let i=0;i<foes;i++){const q=Math.random(),role=md==='giants'?2:r===1?(q<.55?0:1):(q<.4?0:q<.75?1:2);type(Math.round(avgLen(role,d)),1,1+p)}
   if(bossLeft){const tier=((lvOf(wv)-1)/6)|0,live=S.en.find(e=>e.boss);
    const phs=live?live.phs:Math.max(3,Math.min(6,3+tier)-(S.camp>=27?3:S.camp>=20?2:S.camp>=11?1:0));
    const L=()=>{let t=0;for(let k=0;k<6;k++){try{t+=bossLine(z,tier,[]).length}catch(e){t+=34}}return Math.round(t/6)};
    for(let k=1;k<phs;k++){const m=Math.min(10,1+Math.floor(combo/step));score+=150*m*S.sc;type(L(),1,1)}
    type(L(),3,1)}}
  S.kills=kills;S.wk=Math.max(S.wk||0,kills);S.score=Math.max(S.score,Math.round(score));S.maxCombo=Math.max(maxC,S.maxCombo);
  /* speed is capped at 55 WPM for simulated levels */
  S.ok=Math.max(S.ok,S.ok+chars);S.chars=Math.max(S.chars,Math.round(S.ok/rnd(.95,.995)));
  const wpm=ri(38,Math.max(40,Math.min(55,44+n*.35)));
  S.tt=Math.max(S.tt||0,S.ok*12/wpm);S.wpm=Math.min(55,Math.round(S.ok/5/(S.tt/60)));
  S.dmgTaken=0;S.pt0=0;
  const g=ri(60,150)+n*ri(6,14);S.gold+=g;P.gold+=g;
  const cr=ri(0,3);for(let i=0;i<cr;i++)collect({k:Math.random()<.25?'s':Math.random()<.5?'a':'w'});
  S.cr=[];
  victory()}
 /* no keyboard shortcut: the Developer tools Cheats tab calls this, and only while the tools are unlocked */
 window.devSimLevel=function(){if(typeof DEV==='undefined'||!DEV.on)return false;if(S.mode!=='play'||!(S.camp>0)||S.prac||S.rift||S.dc)return false;sim();return true}
})();
