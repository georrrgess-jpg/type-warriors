/* ===== 9.5 THE CROOKED CUE: first-time tutorials at the table (96s) =====
   Replaces the 9.4 tip cards (96p) with the coach engine (96q). Each lesson plays once (P.pz.tut) at the moment it is
   needed: the first break, the first time the monster shoots, groups, reading the guide, spin, ball in hand, the 8,
   the first foul and the menu. While a card is up the shot clock is held. */
const PZT_TBL=()=>({x:PZ_G.x-6,y:PZ_G.y-6,w:PZ_G.w+12,h:PZ_G.h+12});
function pztOk(){return PZ.on&&PZ.M&&!PZ.M.trick&&!PZ.modal&&PZ.ph!=='intro'&&PZ.ph!=='over'&&!(PZ.taunt)&&!pzCoachActive()&&$('pzm')}
function pztGrpName(g){return g==='s'?'Solids':'Stripes'}
function pztGrpNums(g){return g==='s'?'1 to 7':'9 to 15'}
/* the old tip cards stay quiet */
function pzTip(){}
function pzTipsTurn(){if(!pztOk()||!PZ.st)return;const st=PZ.st,Z=PZS(),T=Z.tut,M=PZ.M;
 if(st.turn!==0){pztAiTurn();return}
 if(PZ.ph!=='aim')return;
 /* 1. the very first shot: what 8-ball is, aiming, power */
 if(!T.m1){pzCoach('m1',[
  {title:'Welcome to the table!',text:`This is <b>8-ball</b>. One of you gets the <b>solids</b> (1-7), the other the <b>stripes</b> (9-15). Pot all of yours, then sink the <b>8</b> to win the rack. ${M.race>1?`First to <b>${M.race} racks</b> wins the match.`:'One rack wins the match.'}`,w:460},
  {sel:PZT_TBL,side:'right',w:300,r:18,title:'Aim',text:'<b>Move the mouse</b> over the table to aim. The dotted guide shows your shot: <b>gold</b> is where the ball you hit will go, <b>blue</b> is the cue ball.'},
  {sel:['.pzpw','#pzgo'],side:'top',title:'Power and shoot',text:'<b>Press on the table, pull the mouse back</b> and <b>let go</b> to shoot. The further you pull, the harder the hit. Or drag the <b>power bar</b> and press <b>SHOOT</b> (<kbd>Space</kbd>).',w:440},
  {sel:PZT_TBL,free:true,btn:false,kicker:'YOUR TURN',title:st.brk?'Break the rack!':'Take your shot',text:st.brk?'Pull back far for a strong break. You can drag the cue ball along the left line first if you like.':'Aim at one of the balls and let go.',at:{x:14,y:236,side:'c'},w:296,until:()=>PZ.ph!=='aim'}
 ],{kicker:'FIRST MATCH',skipLast:true});return}
 /* the rest only teach what is on the table right now */
 if(st.bih&&PZ.mode==='place'&&!st.brk&&!T.bih){pzCoach('bih',[{sel:PZT_TBL,free:true,btn:false,kicker:'BALL IN HAND',title:'Put the cue ball anywhere',text:'Your opponent fouled, so <b>click anywhere</b> on the table to place the cue ball. Pick a spot with an easy shot, then aim as usual.',at:{x:14,y:236,side:'c'},w:296,until:()=>PZ.mode!=='place'||PZ.ph!=='aim'}]);return}
 if(pzrOn8(st)&&!T.call8){pzCoach('call8',[{sel:PZT_TBL,free:true,btn:false,kicker:'THE 8',title:'Call your pocket',text:'Only the 8 is left. <b>Click the pocket</b> you will sink it in (or press <kbd>1</kbd>-<kbd>6</kbd>), then shoot. The 8 in any other pocket loses the rack.',at:{x:14,y:236,side:'c'},w:296,until:()=>PZ.callManual||PZ.ph!=='aim'}]);return}
 if(!st.open&&st.grp[0]&&!T.grp){const g=st.grp[0];pzCoach('grp',[{sel:'#pzcm',side:'bottom',title:`You are ${pztGrpName(g)}`,text:`Your balls are the <b>${pztGrpName(g).toLowerCase()}</b> (${pztGrpNums(g)}), shown here; they fade as you pot them. Hit one of yours first on every shot. When they are gone, go for the <b>8</b>.`,w:420}],{kicker:'GROUPS'});return}
 if(!st.brk&&!T.guide&&Z.guide!=='pro'&&(M.rack>1||(st.shots||0)>=1)){pzCoach('guide',[{sel:PZT_TBL,side:'right',w:300,r:18,title:'Read the guide',text:'The <b style="color:#ffd45a">gold line</b> shows where the ball you hit heads, up to the first cushion. The <b style="color:#9fe8ff">blue line</b> is where the cue ball goes after the hit. Whether it drops is up to your eye! Change the guide with <kbd>G</kbd>.'}],{kicker:'TIP'});return}
 if(!T.spin&&(st.shots||0)>=4&&(PZ.humShots||0)>=2){pzCoach('spin',[{sel:'#pzspin',round:true,pad:6,side:'top',title:'Spin the cue ball',text:'Click this ball to choose where the cue hits it. <b>Low</b> = draw: the cue ball comes back. <b>High</b> = follow: it rolls on. Sides bend the bounce off a cushion. <kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd> work too, <kbd>R</kbd> resets.',w:430}],{kicker:'TIP'});return}
 if(!T.menu&&M.rack>=2){pzCoach('menu',[{sel:'#pzmb',side:'top',title:'The menu',text:'House rules, settings (aim guide, taunts) and forfeit are in the menu. <kbd>Esc</kbd> opens it too.',w:360}],{kicker:'TIP'});return}}
/* the monster's first turn: show how to speed it up */
function pztAiTurn(){const T=PZS().tut;if(T.ai1||!T.m1)return;pzCoach('ai1',[{sel:'#pzco',side:'bottom',free:true,btn:'OK',kicker:'THEIR TURN',title:'The monster shoots',text:'Hold <kbd>Space</kbd> or keep the mouse pressed to <b>fast-forward</b> its turn. Click to skip pauses.',w:380,until:()=>!PZ.st||PZ.st.turn===0||PZ.ph==='over'}])}
/* the player's first foul: what happened and what counts as a foul */
function pztFoul(rep){const T=PZS().tut;if(T.foul||!T.m1||!rep||!rep.foul||(PZ.st&&PZ.st.over))return;setTimeout(()=>{if(!PZ.on||!PZ.M||PZ.M.trick||pzCoachActive())return;
 pzCoach('foul',[{sel:'#pzco',side:'bottom',free:true,btn:'Got it',kicker:'FOUL',title:rep.reason||'Foul',text:'Your opponent now has <b>ball in hand</b>: they may place the cue ball anywhere. A foul is: the cue ball dropping, hitting nothing, hitting the other group (or the 8) first, or no ball reaching a cushion after the hit.',w:440,until:()=>!PZ.st||(PZ.st.turn===0&&PZ.ph==='aim')}])},1700)}
{const f0=pzJudgeShot;pzJudgeShot=function(silent){const who=PZ.st?PZ.st.turn:-1;const r=f0.apply(this,arguments);try{if(!silent&&who===0&&PZ.M&&!PZ.M.trick){PZ.humShots=(PZ.humShots||0)+1;pztFoul(PZ.rep)}}catch(e){}return r}}
{const f0=pzStart;pzStart=function(){const r=f0.apply(this,arguments);PZ.humShots=0;return r}}
