/* ---------- endless scenery blend: when a stage ends, a wall of light sweeps across the field and the old world melts into the next one ---------- */
const BGX_DUR=5.4;
function bgBlend(L){const en=!S.camp&&!S.prac&&!S.rift&&!S.dc&&S.mode!=='title'&&S.mode!=='crate';
 if(en&&S.bgL&&S.bgL!==L){S.bgx={from:S.bgL,to:L,t0:S.t,p:[],rings:[{t:0},{t:.35}],sh:0};if(ST.shake)S.shake=Math.max(S.shake||0,12);bgxSfx()}
 if(en)S.bgL=L;
 const x=S.bgx;
 if(!x||S.t-x.t0>=BGX_DUR||S.t<x.t0){S.bgx=null;zoneBG(L.z,S.t,L);return}
 const c=ctx,u=(S.t-x.t0)/BGX_DUR,e=u<.5?2*u*u:1-Math.pow(-2*u+2,2)/2,t=S.t;
 const seam=-260+e*(W+520),F=x.to.a||'#ffd76a',O=x.from.a||'#ffffff';
 const edge=y=>seam+Math.sin(y*.011+t*2.6)*46+Math.sin(y*.029-t*4.8)*20+(y-H*.5)*.16;
 zoneBG(x.from.z,t,x.from);
 /* feathered reveal of the new world behind the wall of light */
 const clipTo=off=>{c.beginPath();c.moveTo(-60,-30);for(let y=-30;y<=H+30;y+=30)c.lineTo(edge(y)+off,y);c.lineTo(-60,H+30);c.closePath();c.clip()};
 [[-90,1],[-45,.34],[0,.4],[45,.5]].forEach(([off,a])=>{c.save();clipTo(off);c.globalAlpha=a;zoneBG(x.to.z,t,x.to);c.restore()});
 /* the wall of light */
 c.save();c.globalCompositeOperation='lighter';
 for(let y=0;y<=H;y+=60){const ex=edge(y);glow(c,ex,y,150,F+'66');glow(c,ex+40,y,90,'#ffffff55')}
 c.lineJoin='round';const path=()=>{c.beginPath();for(let y=-30;y<=H+30;y+=20){const ex=edge(y);y===-30?c.moveTo(ex,y):c.lineTo(ex,y)}};
 c.shadowColor=F;c.shadowBlur=40;c.strokeStyle=F;c.lineWidth=26;c.globalAlpha=.7;path();c.stroke();
 c.shadowBlur=18;c.strokeStyle='#fff';c.lineWidth=7;c.globalAlpha=.95;path();c.stroke();
 c.shadowBlur=0;c.lineWidth=2.4;c.strokeStyle=O;c.globalAlpha=.8;c.save();c.translate(-34,0);path();c.stroke();c.restore();c.save();c.translate(36,0);c.strokeStyle=F;path();c.stroke();c.restore();
 /* light beams streaming off the wall */
 c.globalAlpha=.5;for(let i=0;i<9;i++){const y=(i*173+t*90*(i%2?1:-1))%(H+200)-100,ex=edge(y),len=260+Math.sin(t*3+i)*120;const g=c.createLinearGradient(ex,0,ex+len,0);g.addColorStop(0,'#ffffffaa');g.addColorStop(1,'#ffffff00');c.fillStyle=g;c.fillRect(ex,y-2.5,len,5)}
 c.restore();
 /* sparks and shockwaves */
 const dt=Math.min(.05,Math.max(0,t-(x.lt||t)));x.lt=t;
 for(let i=0;i<4+Math.sin(u*Math.PI)*8;i++){const y=Math.random()*H;x.p.push({x:edge(y),y,vx:60+Math.random()*320,vy:-120-Math.random()*200,l:.8+Math.random()*1,s:2+Math.random()*4,c:Math.random()<.5?F:Math.random()<.5?'#fff':O,a:Math.random()<.35})}
 c.save();c.globalCompositeOperation='lighter';for(const p of x.p){p.l-=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=80*dt;c.globalAlpha=Math.max(0,Math.min(1,p.l*1.3));c.fillStyle=p.c;if(p.a)mS(c,p.x,p.y,p.s*1.8,p.c);else c.fillRect(p.x,p.y,p.s,p.s)}c.restore();x.p=x.p.filter(p=>p.l>0);if(x.p.length>600)x.p.length=600;
 c.save();c.globalCompositeOperation='lighter';for(const r of x.rings){const k=(t-x.t0-r.t)/1.8;if(k<=0||k>=1)continue;const rr=k*1500;c.globalAlpha=(1-k)*.8;c.strokeStyle=F;c.lineWidth=4+(1-k)*14;c.shadowColor=F;c.shadowBlur=24;c.beginPath();c.ellipse(KX+60,GY-120,rr,rr*.5,0,0,TAU);c.stroke()}c.restore();
 /* colour wash at the moment of crossing */
 const w=Math.max(0,1-Math.abs(u-.5)*4);if(w>0){c.save();c.globalCompositeOperation='lighter';c.globalAlpha=w*.28;c.fillStyle=F;c.fillRect(-30,-30,W+60,H+60);c.restore()}
 if(ST.shake&&Math.abs(u-.5)<.04&&!x.sh){x.sh=1;S.shake=Math.max(S.shake||0,10)}}
/* title card drawn above the world */
function bgxOver(){const x=S.bgx;if(!x)return;const c=ctx,el=S.t-x.t0;if(el<.5||el>BGX_DUR-.2)return;const a=Math.min(1,(el-.5)/.7)*Math.min(1,(BGX_DUR-.2-el)/.8),L=x.to,F=L.a||'#ffd76a';
 c.save();c.globalAlpha=a;c.textAlign='center';c.textBaseline='middle';
 
 c.font='italic 22px Georgia,serif';c.fillStyle='#fff';c.shadowColor=F;c.shadowBlur=12;c.fillText('THE WAR PUSHES ON',W/2,128);
 const name=(L.n||'').toUpperCase();c.font='400 74px "Pirata One",Georgia,serif';const sp=10,ws=[...name].map(g=>c.measureText(g).width+sp),tot=ws.reduce((p,q)=>p+q,0);let px=W/2-tot/2;
 for(let i=0;i<name.length;i++){const k=Math.min(1,Math.max(0,(el-.7-i*.045)/.4)),sc=1+(1-k)*1.6;c.save();c.translate(px+ws[i]/2,184);c.scale(sc,sc);c.globalAlpha=a*k;c.shadowColor=F;c.shadowBlur=26;c.lineWidth=7;c.strokeStyle='#000c';c.lineJoin='round';c.strokeText(name[i],0,0);c.fillStyle='#fff';c.fillText(name[i],0,0);c.globalAlpha=a*k*.5;c.fillStyle=F;c.fillText(name[i],0,0);c.restore();px+=ws[i]}
 c.restore()}
function bgxSfx(){if(!axOn())return;try{const o=ac.createGain();o.gain.value=1;o.connect(sg);const T=ac.currentTime+.02,nf=n=>440*Math.pow(2,(n-69)/12);
 cNoise(o,T,2.6,.18,{rev:1,type:'bandpass',f1:300,f2:5200,q:1.3});cTone(o,T,110,2.4,'sine',.13,{f2:880,swell:1});cKick(o,T+.05,.5,90,32,1);
 [57,64,69,73,76].forEach((m,i)=>cChoir(o,T+.4+i*.12,nf(m),3.4,.014));[81,85,88,93].forEach((m,i)=>cBell(o,T+1.6+i*.14,nf(m),.05,2))}catch(e){}}
