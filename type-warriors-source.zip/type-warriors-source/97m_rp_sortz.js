/* ===== RUNESTONE TOWER DEFENSE 9.9r: the Sort tab no longer covers a raised tower card (97m) =====
   The Sort tab above the tower bar (96zp) had z-index 5, the selected card 4, so the leftmost card (the Rune Ballista in the
   default order), once selected and lifted, slid under the tab. The tab now sits below any lifted or hovered card and comes back
   on top only while its menu is open. */
{const st=document.createElement('style');st.textContent=`.rph .rpsortw{z-index:3}.rph .rpsortw:has(.rpsortm.open),.rph .rpsortw.rpsopen{z-index:9}.rph.rp7 .rpcard.on{z-index:5}`;document.head.appendChild(st)}
/* for browsers without :has(), mirror the open state on the wrapper */
document.addEventListener('click',()=>{setTimeout(()=>{try{for(const w of document.querySelectorAll('.rpsortw'))w.classList.toggle('rpsopen',!!w.querySelector('.rpsortm.open'))}catch(e){}},0)},true);
