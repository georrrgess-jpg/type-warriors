/* ===== WILDCARD CARD BACKS: the 14 detailed designs (Lounge Velvet lives in 89y0, which also holds the WB kit) =====
   Each back keeps its name and theme so players recognise what they unlocked, and follows the series rules from 89y0:
   white border, mid-value field with low-contrast pattern layers, ornate gold frame, one bright central emblem that still
   reads at 48 px, bevel edge and sheen. The six Ranked sleeves share one frame (rank metal, the four element gems in the
   corners, WILDCARD plaques) so they read as their own set. Everything is drawn once into a bitmap by 89y0. */
const BX={
 /* bat silhouette, wings spread, centred at x,y */
 bat:(x,y,s,c)=>`<path transform="translate(${x} ${y}) scale(${s})" fill="${c||'#12081f'}" d="M0-3C2-5 3-4 3.5-2 6-4 10-5 14-3 12-2 11 0 12 2 9 0 7 1 6 3 4 1 2 1 0 3-2 1-4 1-6 3-7 1-9 0-12 2-11 0-12-2-14-3-10-5-6-4-3.5-2-3-4-2-5 0-3Z"/>`,
 /* soft cloud made of circles, with a shadow copy */
 cloud:(x,y,s,c,sh)=>{const C=[[0,0,14],[13,-6,12],[26,0,13],[-12,3,10],[38,5,9],[12,6,13]];const one=(dx,dy,f)=>C.map(([a,b,r])=>`<circle cx="${WB.f1(x+(a+dx)*s)}" cy="${WB.f1(y+(b+dy)*s)}" r="${WB.f1(r*s)}" fill="${f}"/>`).join('');return one(1.5,3,sh||'#b48ad8')+one(0,0,c||'#fff')},
 /* flame tongue from the base point x,y, height h, width w, leaning by lean */
 flame:(x,y,h,w,lean)=>{const l=lean||0;return `M${WB.f1(x-w/2)} ${y}C${WB.f1(x-w/2)} ${WB.f1(y-h*.4)} ${WB.f1(x-w*.1+l*.4)} ${WB.f1(y-h*.6)} ${WB.f1(x+l)} ${WB.f1(y-h)}C${WB.f1(x+w*.15+l*.5)} ${WB.f1(y-h*.55)} ${WB.f1(x+w/2)} ${WB.f1(y-h*.35)} ${WB.f1(x+w/2)} ${y}Z`},
 /* four-leaf clover at x,y */
 clover:(x,y,s,c)=>{const leaf=r=>`<path transform="translate(${x} ${y}) rotate(${r}) scale(${s})" d="M0 0C-2-4-9-6-9-11-9-15-4-16 0-12 4-16 9-15 9-11 9-6 2-4 0 0Z" fill="${c}" stroke="#12081f" stroke-width="${WB.f1(1.6/s)}"/>`;return [0,90,180,270].map(leaf).join('')+`<path d="M${x} ${y}q4 8 1 16" stroke="#12081f" stroke-width="2.6" fill="none"/><path d="M${x} ${y}q4 8 1 16" stroke="${c}" stroke-width="1.2" fill="none"/>`},
 /* fleur-de-lis centred at x,y (about 30 units tall at s=1) */
 fleur:s=>`<g transform="scale(${s})"><path d="M0-16C5-10 5-4 0 2-5-4-5-10 0-16Z"/><path d="M-2 0C-6-6-14-6-14 0-14 4-9 6-6 3-8 2-9 0-7-1-5-1-3 1-2 4Z"/><path d="M2 0C6-6 14-6 14 0 14 4 9 6 6 3 8 2 9 0 7-1 5-1 3 1 2 4Z"/><path d="M-6 4H6V7H-6Z"/><path d="M-2 7C-3 11-6 13-8 13-5 15-1 13 0 10 1 13 5 15 8 13 6 13 3 11 2 7Z"/></g>`,
 /* hammered metal: a tile of dimples with a light and a dark rim */
 dimples:(id,w,lt,dk,n,seed)=>{const R=WB.rng(seed||5);let s='';for(let i=0;i<(n||14);i++){const x=R()*w,y=R()*w,r=4+R()*5;for(const [dx,dy] of [[0,0],[w,0],[-w,0],[0,w],[0,-w]])s+=`<circle cx="${WB.f1(x+dx)}" cy="${WB.f1(y+dy)}" r="${WB.f1(r)}" fill="url(#${id}d)"/>`}
  return WB.rg(id+'d',[[0,lt,.0],[.55,lt,.18],[.8,dk,.0],[1,dk,.3]],.62,.66,.5)+WB.tile(id,w,w,s)},
 /* ten little rune glyphs (strokes on a 20 unit cell, centred) */
 RUNES:['M0-9V9M0-9L6-3M0-1L6 5','M-5-9V9M-5-9L5-2-5 5','M0-9V9M-6-4L6 4M6-4L-6 4','M-4-9V9M4-9V9M-4-2L4 3','M0-9V9M0 0L-6-6M0 0L6-6','M-5 9L0-9 5 9M-3 3H3','M-5-9L5 9M5-9L-5 9M-6 0H6','M0-9V9M-5-9H5M-5 9H5','M-5-9L5-9-5 9 5 9','M0-9L6 0 0 9-6 0Z'],
 /* frost feather: a branching ice crystal from 0,0 toward +x,+y (for WB.corners) */
 frost:(n,seed)=>{const R=WB.rng(seed||9);let d='';const br=(x,y,a,l,k)=>{if(k>3||l<6)return;const x2=x+l*Math.cos(a),y2=y+l*Math.sin(a);d+=`M${WB.f1(x)} ${WB.f1(y)}L${WB.f1(x2)} ${WB.f1(y2)}`;
  for(let i=1;i<=3;i++){const t=i/4,px=x+(x2-x)*t,py=y+(y2-y)*t,bl=l*(.42-.06*i)*(.8+R()*.4);br(px,py,a-.85,bl,k+1);br(px,py,a+.85,bl,k+1)}};for(let i=0;i<(n||3);i++)br(0,0,.25+i*.5,70+R()*30,0);return d},
 /* the shared Ranked sleeve: field (body), rank metal id, the emblem, plaques, element gems in the corners */
 RG:[['#ff9a7a','#ff4a1f','#6a0a00'],['#9ad6ff','#1f8cff','#062a6a'],['#9af0b8','#22c55e','#04401c'],['#fff09a','#ffc21a','#6a4400']],
 sleeve(o){const cx=150,cy=219,M=o.metal;
  const frame=WB.frame({i:10,step:15,c:`url(#${M})`,w:3.8,mid:false,corner:WB.fan(12,40,{n:8,c:`url(#${M})`,fill:o.deep,fo:.55})})+
   WB.corners(`<path d="M0-12L12 0 0 12-12 0Z" fill="url(#${M})" stroke="#12081f" stroke-width="3"/>`,32,32)+
   [[32,32,0],[268,32,1],[32,406,2],[268,406,3]].map(([x,y,i])=>WB.gem(x,y,6.5,{c:BX.RG[i],bezel:0})).join('')+
   [[28,219],[272,219]].map(([x,y])=>`<g transform="translate(${x} ${y})">${WB.ol('M0-26L9 0 0 26-9 0Z',`url(#${M})`,{w:3})}<circle r="3.4" fill="${o.accent}" stroke="#12081f" stroke-width="1.6"/></g>`).join('');
  const plq=WB.rot2(WB.plaque('WILDCARD',150,394,{size:24,ls:1.2,w:132,h:30,fill:o.deep,c:`url(#${M})`,tc:`url(#${M})`}));
  const medal=`<circle cx="${cx}" cy="${cy}" r="${o.halo||120}" fill="url(#hal)"/>`+WB.medal(cx,cy,o.r||66,{c:`url(#${M})`,band:o.band||'url(#goldD)',beads:o.beads==null?36:o.beads})+o.emblem;
  return WB.doc(WB.card(o.base)+WB.clip(o.field)+o.deco+medal+frame+plq+WB.edge({c:o.deep,hl:o.hl||'#ffffff'})+WB.sheen(),{defs:o.defs+WB.metal(M,o.mk,1)+WB.rg('hal',[[0,o.glow,.55],[.45,o.glow,.16],[1,o.glow,0]])})}};

/* ---------- Neon Arcade: synthwave sunset over a glowing grid ---------- */
WCBKX.neon={base:'#3a0a5e',art(){const cx=150,hz=258;
 const defs=WB.lg('sky',[[0,'#0a0322'],[.42,'#2a0a5a'],[.72,'#8a1a7a'],[1,'#ff3a8a']],0,0,0,1)+WB.lg('sun',[[0,'#fff27a'],[.45,'#ffb03a'],[.75,'#ff4a7a'],[1,'#c81a8a']],0,0,0,1)+
  WB.lg('flo',[[0,'#3a0650'],[1,'#0a0222']],0,0,0,1)+WB.lg('chr',[[0,'#ffffff'],[.42,'#b8e8ff'],[.5,'#3a2a7a'],[.56,'#ff9ad8'],[1,'#ffe6fa']],0,0,0,1)+
  WB.rg('sglo',[[0,'#ff5aa8',.75],[.5,'#ff3a8a',.25],[1,'#ff3a8a',0]])+
  `<filter id="gl" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="3.2"/></filter>`+
  WB.tile('scan',4,4,`<rect width="4" height="1.3" fill="#000" opacity=".22"/>`)+
  `<clipPath id="sc"><circle cx="${cx}" cy="200" r="66"/></clipPath><clipPath id="fl"><rect x="18" y="${hz}" width="264" height="170"/></clipPath>`;
 /* sky, stars, a soft glow behind the sun */
 let f=`<rect x="18" y="18" width="264" height="402" fill="url(#sky)"/>`+WB.stars(41,90,{x:18,y:18,w:264,h:170,r0:.4,r1:1.5,c:'#ffe6ff',sp:.12})+`<circle cx="${cx}" cy="205" r="130" fill="url(#sglo)"/>`;
 /* striped sun: bands get thinner gaps toward the top */
 let bands='';for(let i=0;i<7;i++){const y=212+i*9.5,h=2+i*1.15;bands+=`<rect x="80" y="${WB.f1(y)}" width="140" height="${WB.f1(h)}"/>`}
 f+=`<g clip-path="url(#sc)"><rect x="80" y="130" width="140" height="140" fill="url(#sun)"/><g fill="#2a0a5a">${bands}</g>${WB.lines(cx,200,40,0,70,{c:'#fff8c0',sw:.5,op:.18})}</g>`;
 /* far mountains with a neon rim */
 const mtn='M18 258L44 232 62 244 86 214 108 238 128 226 150 246 172 222 196 240 220 210 244 236 262 226 282 240V258Z';
 f+=`<path d="${mtn}" fill="#1a0638"/><path d="${mtn.replace('V258Z','')}" fill="none" stroke="#ff5ad0" stroke-width="2.2" opacity=".9"/><path d="${mtn.replace('V258Z','')}" fill="none" stroke="#ff5ad0" stroke-width="5" opacity=".5" filter="url(#gl)"/>`;
 /* the floor and the perspective grid (glow copy behind a crisp copy) */
 let g='';for(let i=1;i<=12;i++){const t=i/12,y=hz+170*t*t;g+=`M18 ${WB.f1(y)}H282`}for(let i=-12;i<=12;i++){const xb=cx+i*36;g+=`M${cx+i*1.5} ${hz}L${xb} 438`}
 f+=`<g clip-path="url(#fl)"><rect x="18" y="${hz}" width="264" height="170" fill="url(#flo)"/><path d="${g}" stroke="#29f0ff" stroke-width="4" opacity=".55" filter="url(#gl)" fill="none"/><path d="${g}" stroke="#7af8ff" stroke-width="1.5" fill="none"/></g>`+
  `<rect x="18" y="${hz-1.5}" width="264" height="3" fill="#fff0fa"/><rect x="18" y="${hz-4}" width="264" height="9" fill="#ff5ad0" opacity=".55" filter="url(#gl)"/>`;
 /* palm silhouettes on both sides */
 const palm=(x,y,s,fl)=>`<g transform="translate(${x} ${y}) scale(${fl?-s:s} ${s})" fill="#12051e"><path d="M0 0C2-30 6-60 14-92L18-91C11-60 6-30 5 0Z"/>`+
  [[-48,8],[-20,-14],[8,-20],[36,-8],[52,14]].map(([a,b])=>`<path d="M16-92C${WB.f1(16+a*.5)} ${WB.f1(-104+b*.4)} ${WB.f1(16+a)} ${WB.f1(-92+b)} ${WB.f1(16+a*1.2)} ${WB.f1(-80+b*1.3)}C${WB.f1(16+a*.8)} ${WB.f1(-90+b)} ${WB.f1(16+a*.4)} ${WB.f1(-96+b*.5)} 16-92Z"/>`).join('')+`</g>`;
 f+=palm(36,300,1,0)+palm(266,306,.9,1)+palm(64,290,.6,0);
 f+=`<rect x="18" y="18" width="264" height="402" fill="url(#scan)"/>`;
 /* neon tube frame: glow, pink tube, white core */
 const tube=`<rect x="30" y="30" width="240" height="378" rx="16" fill="none"`;
 const fr=`${tube} stroke="#ff3ab0" stroke-width="9" opacity=".6" filter="url(#gl)"/>${tube} stroke="#12081f" stroke-width="7"/>${tube} stroke="#ff5ad0" stroke-width="4"/>${tube} stroke="#ffe0f6" stroke-width="1.3"/>`+
  `<rect x="40" y="40" width="220" height="358" rx="10" fill="none" stroke="#29f0ff" stroke-width="5" opacity=".45" filter="url(#gl)"/><rect x="40" y="40" width="220" height="358" rx="10" fill="none" stroke="#7af8ff" stroke-width="1.4"/>`+
  WB.corners(`<circle r="5" fill="#29f0ff" stroke="#12081f" stroke-width="2.4"/><circle r="2" fill="#fff"/>`,40,40);
 /* chrome lettering with a pink glow */
 const word=`<g filter="url(#gl)" opacity=".8">${WB.word('WILDCARD',cx,356,44,{fill:'#ff3ab0',ls:1})}</g>`+WB.word('WILDCARD',cx,356,44,{fill:'url(#chr)',ls:1,stroke:'#12081f',sw:5})+
  `<path d="M70 366H230" stroke="#29f0ff" stroke-width="2"/><path d="M90 372H210" stroke="#ff5ad0" stroke-width="1.4"/>`+WB.spark(232,320,8,'#fff')+WB.spark(78,330,5,'#bff8ff');
 return WB.doc(WB.card('#2a0a5a',{border:[[0,'#ffffff'],[.6,'#fdf4ff'],[1,'#ead8f8']]})+WB.clip(f)+fr+word+WB.edge({c:'#1a0638',hl:'#ffb0e8'})+WB.sheen({op:.4}),{defs})}};

/* ---------- Hallow's Eve: moonlit graveyard and a carved jack-o'-lantern ---------- */
WCBKX.hallow={base:'#3a1a62',art(){const cx=150;
 const defs=WB.lg('nt',[[0,'#1a0a3a'],[.5,'#3e1a6e'],[1,'#5a2a6a']],0,0,0,1)+WB.rg('mn',[[0,'#fffbe0'],[.6,'#ffe8a0'],[1,'#e8b860']],.42,.38,.6)+WB.rg('mg',[[0,'#fff2b0',.6],[.4,'#ffd880',.18],[1,'#ffd880',0]])+
  WB.rg('pk',[[0,'#ffcf5a'],[.45,'#ff8a1a'],[.85,'#c8480a'],[1,'#7a2204']],.4,.35,.7)+WB.rg('cand',[[0,'#fffbd0'],[.5,'#ffd23a'],[1,'#ff7a0a']],.5,.6,.6)+WB.rg('pglo',[[0,'#ff9a2a',.5],[1,'#ff9a2a',0]])+
  WB.rg('fog',[[0,'#e0d4ff',.34],[.6,'#e0d4ff',.12],[1,'#e0d4ff',0]])+WB.grain('gr',{f:1,k:-2.4,k0:1.3})+`<clipPath id="pkc"><ellipse cx="150" cy="300" rx="62" ry="50"/></clipPath>`;
 let f=`<rect x="18" y="18" width="264" height="402" fill="url(#nt)"/>`+WB.stars(13,70,{x:18,y:18,w:264,h:220,r0:.4,r1:1.4,c:'#f4e8ff',sp:.1});
 /* the moon: glow, disc, craters, a terminator shade */
 f+=`<circle cx="${cx}" cy="138" r="120" fill="url(#mg)"/><circle cx="${cx}" cy="138" r="70" fill="url(#mn)" stroke="#12081f" stroke-width="3"/>`+
  [[124,112,12],[170,128,8],[140,165,15],[178,165,6],[118,145,5],[160,96,6]].map(([x,y,r])=>`<circle cx="${x}" cy="${y}" r="${r}" fill="#d8a850" opacity=".45"/><path d="M${x-r*.7} ${y-r*.5}A${r} ${r} 0 0 1 ${x+r*.8} ${y-r*.2}" stroke="#fff8d8" stroke-width="1.1" fill="none" opacity=".7"/>`).join('')+
  `<path d="M196 92A70 70 0 0 1 196 184A80 80 0 0 0 196 92Z" fill="#b88840" opacity=".35"/>`;
 /* bats across the moon */
 f+=BX.bat(108,96,2.2)+BX.bat(196,74,1.5)+BX.bat(214,130,1.1)+BX.bat(80,150,1)+BX.bat(232,96,.8);
 /* gnarled tree and the graveyard hill */
 f+=`<path d="M18 262C40 254 60 250 70 238 74 226 70 210 60 196 70 202 76 214 80 222 86 204 96 192 112 186 100 196 92 210 90 226 100 216 112 214 122 216 108 220 98 230 94 246 104 252 118 256 130 262Z" fill="#12081f"/>`+
  `<path d="M60 196C54 186 44 182 34 184M96 192C100 182 108 176 118 176M112 186C120 184 126 178 128 170" stroke="#12081f" stroke-width="3" fill="none" stroke-linecap="round"/>`+
  `<path d="M18 300C60 270 110 262 150 266 196 268 240 278 282 296V420H18Z" fill="#1e0e36"/><path d="M18 300C60 270 110 262 150 266 196 268 240 278 282 296" fill="none" stroke="#7a5aaa" stroke-width="1.4" opacity=".6"/>`+
  [[48,282,14,24,1],[236,284,12,22,0],[262,296,10,18,1],[30,300,9,16,0]].map(([x,y,w,h,cr])=>cr?`<path d="M${x-2} ${y-h}H${x+2}V${y-h+6}H${x+7}V${y-h+10}H${x+2}V${y}H${x-2}V${y-h+10}H${x-7}V${y-h+6}H${x-2}Z" fill="#3a2a5a" stroke="#12081f" stroke-width="2.4"/>`:`<path d="M${x-w/2} ${y}V${y-h+w/2}A${w/2} ${w/2} 0 0 1 ${x+w/2} ${y-h+w/2}V${y}Z" fill="#3a2a5a" stroke="#12081f" stroke-width="2.4"/><path d="M${x-w/4} ${y-h+w/2+4}H${x+w/4}M${x-w/4} ${y-h+w/2+8}H${x+w/5}" stroke="#12081f" stroke-width="1.2"/>`).join('');
 /* fog bands and grain */
 f+=`<ellipse cx="80" cy="282" rx="110" ry="16" fill="url(#fog)"/><ellipse cx="230" cy="296" rx="100" ry="14" fill="url(#fog)"/><ellipse cx="120" cy="352" rx="150" ry="20" fill="url(#fog)"/><ellipse cx="220" cy="392" rx="120" ry="18" fill="url(#fog)"/>`+
  `<rect x="18" y="18" width="264" height="402" fill="#fff" filter="url(#gr)" opacity=".08"/>`;
 /* the jack-o'-lantern: glow, ribs, carved face lit from inside, stem and leaf */
 const pk=`<circle cx="${cx}" cy="300" r="110" fill="url(#pglo)"/><ellipse cx="${cx}" cy="306" rx="66" ry="52" fill="#12081f" opacity=".45"/><ellipse cx="${cx}" cy="300" rx="62" ry="50" fill="url(#pk)" stroke="#12081f" stroke-width="4.5"/>`+
  `<g clip-path="url(#pkc)" fill="none" stroke="#9a3a06" stroke-width="2" opacity=".75"><ellipse cx="${cx}" cy="300" rx="20" ry="50"/><ellipse cx="${cx}" cy="300" rx="42" ry="50"/></g>`+
  `<path d="M104 280Q112 266 124 262" stroke="#ffe0a0" stroke-width="3" fill="none" opacity=".55" stroke-linecap="round"/>`+
  `<path d="M120 288L134 270 142 292Z M180 288L166 270 158 292Z" fill="url(#cand)" stroke="#12081f" stroke-width="3" stroke-linejoin="round"/><path d="M146 302L150 294 154 302Z" fill="url(#cand)" stroke="#12081f" stroke-width="2.4"/>`+
  `<path d="M112 312Q150 344 188 312L180 318 172 314 166 324 156 318 150 328 144 318 134 324 128 314 120 318Z" fill="url(#cand)" stroke="#12081f" stroke-width="3" stroke-linejoin="round"/>`+
  `<path d="M146 252C144 244 146 236 152 232L158 236C154 240 152 246 154 252Z" fill="#4a7a2a" stroke="#12081f" stroke-width="3"/><path d="M156 246C166 236 180 238 184 246 174 244 166 248 160 252Z" fill="#5a9a32" stroke="#12081f" stroke-width="2.4"/>`;
 /* spider webs in the corners and a spider */
 const web=`<path d="${[0,1,2,3,4,5].map(i=>{const a=i*Math.PI/10;return `M0 0L${WB.f1(64*Math.cos(a))} ${WB.f1(64*Math.sin(a))}`}).join('')}" stroke="#e8e0ff" stroke-width=".9" opacity=".7" fill="none"/>`+[18,32,46,58].map(r=>{let d='';for(let i=0;i<5;i++){const a=i*Math.PI/10,b=(i+1)*Math.PI/10;d+=`M${WB.f1(r*Math.cos(a))} ${WB.f1(r*Math.sin(a))}Q${WB.f1(r*.82*Math.cos((a+b)/2))} ${WB.f1(r*.82*Math.sin((a+b)/2))} ${WB.f1(r*Math.cos(b))} ${WB.f1(r*Math.sin(b))}`}return `<path d="${d}" stroke="#e8e0ff" stroke-width=".8" fill="none" opacity=".65"/>`}).join('');
 const deco=WB.corners(web,22,22)+`<path d="M244 22V58" stroke="#e8e0ff" stroke-width=".8" opacity=".7"/><circle cx="244" cy="62" r="4" fill="#12081f"/><path d="M238 58L250 66M250 58L238 66M237 62H251" stroke="#12081f" stroke-width="1.2"/>`;
 const fr=WB.frame({i:12,step:14,mid:false,c:'url(#gold)',corner:false})+WB.corners(WB.gem(0,0,6,{c:'amethyst',bezel:2}),34,34);
 return WB.doc(WB.card('url(#nt)')+WB.clip(f+pk)+deco+fr+WB.plaque("HALLOW'S EVE",150,398,{size:17,ls:1.5,w:124,h:24,fill:'#1a0a2a'})+WB.edge({c:'#1a0a2a',hl:'#d8b8ff'})+WB.sheen({op:.45}),{defs})}};

/* ---------- Emerald Jackpot: stitched casino felt, a triple-seven slot window and gold coins ---------- */
WCBKX.emerald={base:'#0e6a32',art(){const cx=150,cy=219;
 const defs=WB.rg('felt',[[0,'#2ad070'],[.45,'#13924a'],[.85,'#086030'],[1,'#043a1c']],.5,.45,.75)+WB.grain('gr',{f:1.3,k:-2.6,k0:1.4})+
  WB.lg('reel',[[0,'#8a7a5a'],[.18,'#fff8e6'],[.5,'#ffffff'],[.82,'#fff8e6'],[1,'#8a7a5a']],0,0,0,1)+WB.lg('sev',[[0,'#ff7a8a'],[.5,'#e8102a'],[1,'#8a0414']],0,0,0,1)+
  WB.rg('coin',[[0,'#fff6c0'],[.5,'#ffcf3a'],[.85,'#c8861a'],[1,'#7a4a0a']],.38,.32,.7)+WB.rg('bulb',[[0,'#ffffff'],[.4,'#fff09a'],[1,'#ffb020',0]])+
  WB.tile('dia',22,22,`<path d="M11 0L22 11 11 22 0 11Z" fill="none" stroke="#7affb0" stroke-width=".6" opacity=".14"/>`);
 let f=`<rect x="18" y="18" width="264" height="402" fill="url(#felt)"/><rect x="18" y="18" width="264" height="402" fill="url(#dia)"/>`+
  `<rect x="18" y="18" width="264" height="402" fill="#fff" filter="url(#gr)" opacity=".12"/>`+WB.rays(cx,cy,24,300,{c:'#a8ffcc',op:.05,w:.05});
 /* scattered coins: flat ones with embossed rims, edge-on ones, all with ink outlines */
 const coin=(x,y,r,rot)=>`<g transform="rotate(${rot} ${x} ${y})"><ellipse cx="${x}" cy="${y+2}" rx="${r}" ry="${r}" fill="#12081f" opacity=".4"/><circle cx="${x}" cy="${y}" r="${r}" fill="url(#coin)" stroke="#12081f" stroke-width="2.4"/><circle cx="${x}" cy="${y}" r="${WB.f1(r*.72)}" fill="none" stroke="#9a6010" stroke-width="1.2"/>${WB.lines(x,y,24,r*.78,r*.95,{c:'#8a5a10',sw:.6,op:.6})}<path d="${WB.star(x,y,5,r*.45,r*.2)}" fill="#ffe680" stroke="#9a6010" stroke-width=".9"/></g>`;
 const edge=(x,y,w,rot)=>`<g transform="rotate(${rot} ${x} ${y})"><rect x="${x-w/2}" y="${y-5}" width="${w}" height="10" rx="5" fill="url(#coin)" stroke="#12081f" stroke-width="2.2"/><path d="M${x-w/2+4} ${y-2}V${y+2}M${x-w/4} ${y-3}V${y+3}M${x} ${y-3}V${y+3}M${x+w/4} ${y-3}V${y+3}M${x+w/2-4} ${y-2}V${y+2}" stroke="#8a5a10" stroke-width="1"/></g>`;
 f+=coin(62,86,15,-10)+coin(240,100,12,20)+coin(56,346,13,15)+coin(246,330,16,-25)+coin(222,388,9,0)+coin(84,394,10,30)+edge(228,62,26,-30)+edge(70,300,22,40)+edge(250,250,20,70)+edge(46,150,18,-60);
 /* clover filigree in the corners */
 const deco=WB.corners(BX.clover(0,0,1.3,'#3ad87a'),48,52)+WB.stars(23,16,{x:40,y:60,w:220,h:320,r0:.6,r1:1.6,c:'#fff6c0',sp:.5});
 /* stitched felt border and the gold rope frame */
 const st=`<rect x="34" y="34" width="232" height="370" rx="14" fill="none" stroke="#fff6d0" stroke-width="1.4" stroke-dasharray="5 4" opacity=".55"/>`;
 const rope=`<rect x="26" y="26" width="248" height="386" rx="19" fill="none" stroke="#12081f" stroke-width="9"/><rect x="26" y="26" width="248" height="386" rx="19" fill="none" stroke="url(#gold)" stroke-width="5.5"/><rect x="26" y="26" width="248" height="386" rx="19" fill="none" stroke="#8a5410" stroke-width="5.5" stroke-dasharray="3 3.5" opacity=".7"/><rect x="26" y="26" width="248" height="386" rx="19" fill="none" stroke="#fff3c0" stroke-width="1.2" stroke-dasharray="2 4.5" opacity=".8"/>`;
 /* the slot window: cabinet, marquee bulbs, three reels with sevens, a payline */
 const bx=78,by=172,bw=144,bh=94;let bulbs='';for(let i=0;i<11;i++){bulbs+=`<circle cx="${WB.f1(bx-6+i*(bw+12)/10)}" cy="${by-12}" r="4.6" fill="url(#bulb)"/><circle cx="${WB.f1(bx-6+i*(bw+12)/10)}" cy="${by+bh+12}" r="4.6" fill="url(#bulb)"/>`}
 for(let i=1;i<5;i++)bulbs+=`<circle cx="${bx-12}" cy="${WB.f1(by-12+i*(bh+24)/5)}" r="4.6" fill="url(#bulb)"/><circle cx="${bx+bw+12}" cy="${WB.f1(by-12+i*(bh+24)/5)}" r="4.6" fill="url(#bulb)"/>`;
 const cab=`<rect x="${bx-22}" y="${by-24}" width="${bw+44}" height="${bh+48}" rx="18" fill="#12081f" opacity=".45" transform="translate(0 5)"/>`+WB.ol(`M${bx-12} ${by-24}H${bx+bw+12}Q${bx+bw+22} ${by-24} ${bx+bw+22} ${by-14}V${by+bh+14}Q${bx+bw+22} ${by+bh+24} ${bx+bw+12} ${by+bh+24}H${bx-12}Q${bx-22} ${by+bh+24} ${bx-22} ${by+bh+14}V${by-14}Q${bx-22} ${by-24} ${bx-12} ${by-24}Z`,'url(#gold)',{w:5})+
  `<rect x="${bx-14}" y="${by-16}" width="${bw+28}" height="${bh+32}" rx="10" fill="#5a0a14" stroke="#12081f" stroke-width="2.6"/>`+bulbs+
  `<rect x="${bx-3}" y="${by-3}" width="${bw+6}" height="${bh+6}" rx="7" fill="#12081f"/>`+[0,1,2].map(i=>{const x=bx+i*48;return `<rect x="${x+2}" y="${by}" width="44" height="${bh}" rx="5" fill="url(#reel)"/>`+
   `<g opacity=".35">${WB.word('7',x+24,by+14,30,{fill:'#e8102a'})}${WB.word('7',x+24,by+bh+12,30,{fill:'#e8102a'})}</g>`+WB.word('7',x+24,by+bh/2+19,54,{fill:'url(#sev)',stroke:'#12081f',sw:4.5})}).join('')+
  `<path d="M${bx-8} ${by+bh/2}H${bx+bw+8}" stroke="#ffd45a" stroke-width="1.6" opacity=".9"/><path d="M${bx-14} ${by+bh/2-7}L${bx-4} ${by+bh/2} ${bx-14} ${by+bh/2+7}ZM${bx+bw+14} ${by+bh/2-7}L${bx+bw+4} ${by+bh/2} ${bx+bw+14} ${by+bh/2+7}Z" fill="#ffd45a" stroke="#12081f" stroke-width="2"/>`+
  `<path d="M${bx} ${by+6}H${bx+bw}" stroke="#fff" stroke-width="3" opacity=".35"/>`+WB.plaque('JACKPOT',cx,by+bh+52,{size:20,ls:2,w:118,h:27,fill:'#12081f'})+WB.plaque('LUCKY',cx,by-50,{size:17,ls:2,w:96,h:23,fill:'#12081f'});
 return WB.doc(WB.card('url(#felt)')+WB.clip(f)+deco+st+rope+cab+WB.corners(WB.gem(0,0,7,{c:'emerald',bezel:2.4}),28,28)+WB.edge({c:'#03301a',hl:'#b8ffd8'})+WB.sheen(),{defs})}};

/* ---------- Royal Gold: hammered gold, fleur-de-lis, a jewelled crown on a velvet cushion ---------- */
WCBKX.royal={base:'#d8a02a',art(){const cx=150,cy=219;
 const defs=WB.metal('fg','gold',1)+BX.dimples('ham',38,'#fff8d0','#7a4a0a',16,3)+WB.tile('fl',54,60,`<g fill="#7a4a0a" opacity=".18" transform="translate(27 30)">${BX.fleur(.7)}</g><g fill="#7a4a0a" opacity=".18" transform="translate(0 0)">${BX.fleur(.7)}</g><g fill="#7a4a0a" opacity=".18" transform="translate(54 0)">${BX.fleur(.7)}</g><g fill="#7a4a0a" opacity=".18" transform="translate(0 60)">${BX.fleur(.7)}</g><g fill="#7a4a0a" opacity=".18" transform="translate(54 60)">${BX.fleur(.7)}</g>`)+
  WB.rg('cus',[[0,'#e83a5a'],[.55,'#a8102e'],[1,'#4a0414']],.45,.35,.7)+WB.rg('vig',[[0,'#000',0],[.65,'#000',0],[1,'#4a2a00',.55]],.5,.5,.72)+WB.lg('erm',[[0,'#ffffff'],[1,'#e8e2d6']],0,0,0,1)+
  WB.rg('rglo',[[0,'#fff6c0',.7],[.5,'#ffd45a',.2],[1,'#ffd45a',0]]);
 let f=`<rect x="18" y="18" width="264" height="402" fill="url(#fg)"/><rect x="18" y="18" width="264" height="402" fill="url(#ham)"/><rect x="18" y="18" width="264" height="402" fill="url(#fl)"/>`+WB.rays(cx,cy,48,300,{c:'#fff8d0',op:.08,w:.03})+`<rect x="18" y="18" width="264" height="402" fill="url(#vig)"/>`;
 /* baroque frame with pearls */
 let pearls='';for(let i=0;i<22;i++){const t=i/21;pearls+=`<circle cx="${WB.f1(48+t*204)}" cy="40" r="2.6"/><circle cx="${WB.f1(48+t*204)}" cy="398" r="2.6"/>`}for(let i=1;i<33;i++){const t=i/33;pearls+=`<circle cx="40" cy="${WB.f1(40+t*358)}" r="2.6"/><circle cx="260" cy="${WB.f1(40+t*358)}" r="2.6"/>`}
 const fr=WB.frame({i:8,step:18,c:'url(#goldD)',w:4,mid:true})+`<g fill="#fffaf0" stroke="#8a6a3a" stroke-width=".9">${pearls}</g>`+WB.corners(`<g transform="translate(6 6)">${WB.filigree({c:'url(#goldD)',sz:1.1})}</g>`,24,24)+WB.corners(WB.gem(0,0,8,{c:'sapphire',bezel:2.6,bc:'url(#goldD)'}),40,40);
 /* the ermine-trimmed oval medallion holding the cushion and the crown */
 let spots='';for(let i=0;i<20;i++){const a=i/20*Math.PI*2;const x=cx+95*.78*Math.cos(a),y=cy+95*Math.sin(a);spots+=`<path transform="translate(${WB.f1(x)} ${WB.f1(y)})" d="M0-4L1.6 0 0 4-1.6 0Z" fill="#12081f"/>`}
 const med=`<circle cx="${cx}" cy="${cy}" r="128" fill="url(#rglo)"/><ellipse cx="${cx}" cy="${cy+5}" rx="${95*.78+10}" ry="105" fill="#12081f" opacity=".4"/>`+
  `<ellipse cx="${cx}" cy="${cy}" rx="${95*.78+9}" ry="104" fill="url(#erm)" stroke="#12081f" stroke-width="4"/>${spots}`+
  `<ellipse cx="${cx}" cy="${cy}" rx="${95*.78-6}" ry="89" fill="url(#cus)" stroke="#12081f" stroke-width="3.4"/>`+WB.gring(cx,cy,74,80,{n:30,k:3,c:'#ffd45a',sw:.7,op:.5}).replace(/<path/,`<path transform="translate(${cx} ${cy}) scale(.82 1) translate(-${cx} -${cy})"`)+
  /* cushion with tufting and tassels */
  `<path d="M98 262Q150 236 202 262Q206 286 150 296 94 286 98 262Z" fill="#7a0a22" stroke="#12081f" stroke-width="3"/><path d="M104 262Q150 244 196 262" stroke="#ff8aa0" stroke-width="1.4" fill="none" opacity=".6"/>`+
  [[100,276],[200,276]].map(([x,y])=>`<path d="M${x} ${y}V${y+18}" stroke="#12081f" stroke-width="5"/><path d="M${x} ${y}V${y+18}" stroke="url(#goldL)" stroke-width="2.6"/><path d="M${x-5} ${y+16}L${x} ${y+30} ${x+5} ${y+16}Z" fill="url(#goldL)" stroke="#12081f" stroke-width="1.8"/>`).join('')+
  /* the crown: band with gems, five points with pearls, arches, orb and cross */
  `<path d="M104 254L98 196 122 222 136 182 150 214 164 182 178 222 202 196 196 254Z" fill="url(#goldL)" stroke="#12081f" stroke-width="4" stroke-linejoin="round"/>`+
  `<path d="M108 248L104 210 122 232 136 196 150 226 164 196 178 232 196 210 192 248Z" fill="none" stroke="#fff3c0" stroke-width="1.2" opacity=".75"/>`+
  `<path d="M122 222Q136 168 150 162Q164 168 178 222" fill="none" stroke="#12081f" stroke-width="7"/><path d="M122 222Q136 168 150 162Q164 168 178 222" fill="none" stroke="url(#goldL)" stroke-width="3.4"/>`+
  `<circle cx="150" cy="152" r="9" fill="url(#goldL)" stroke="#12081f" stroke-width="3"/><path d="M150 132V146M144 138H156" stroke="#12081f" stroke-width="6" stroke-linecap="round"/><path d="M150 132V146M144 138H156" stroke="url(#goldL)" stroke-width="3" stroke-linecap="round"/>`+
  [[98,196],[136,182],[164,182],[202,196]].map(([x,y])=>`<circle cx="${x}" cy="${y-5}" r="5" fill="#fffaf0" stroke="#12081f" stroke-width="2"/><circle cx="${x-1.6}" cy="${y-6.6}" r="1.4" fill="#fff"/>`).join('')+
  `<rect x="102" y="240" width="96" height="16" rx="4" fill="url(#goldD)" stroke="#12081f" stroke-width="3"/>`+WB.gem(150,248,8,{c:'ruby',bezel:2})+WB.gem(122,248,5,{c:'emerald',bezel:1.5})+WB.gem(178,248,5,{c:'sapphire',bezel:1.5})+
  WB.gem(150,226,6,{c:'ruby',cut:'oval',bezel:1.6})+WB.spark(192,170,8,'#fff8d0')+WB.spark(110,188,5,'#fff8d0');
 const plq=WB.rot2(WB.plaque('WILDCARD',150,394,{size:23,ls:1.2,w:130,h:29,fill:'#5a0a1e',c:'url(#goldD)'}));
 return WB.doc(WB.card('url(#fg)')+WB.clip(f)+fr+med+plq+WB.edge({c:'#6a3a06',hl:'#fff6c0'})+WB.sheen(),{defs})}};

/* ---------- Astral: a rose and violet nebula with a constellation drawn into a W ---------- */
WCBKX.astral={base:'#3a1a6a',art(){const cx=150,cy=219;
 const defs=WB.rg('sp',[[0,'#3a1a7a'],[.6,'#1a0a4a'],[1,'#0a0424']],.5,.45,.8)+`<filter id="neb" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="14"/></filter><filter id="gl" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="3"/></filter>`+
  WB.rg('core',[[0,'#ffffff'],[.25,'#fff0fa'],[.55,'#ff9ae0',.6],[1,'#9a5aff',0]])+WB.rg('ring',[[0,'#2a1a6a'],[1,'#120838']],.4,.35,.8);
 let f=`<rect x="18" y="18" width="264" height="402" fill="url(#sp)"/>`+
  `<g filter="url(#neb)">`+[[90,120,90,60,'#ff4aa8',.55],[210,170,80,70,'#8a4aff',.55],[120,300,110,60,'#4a6aff',.45],[220,340,70,50,'#ff6ac8',.45],[150,220,60,90,'#c85aff',.35],[60,220,50,80,'#3a8aff',.35]].map(([x,y,rx,ry,c,o])=>`<ellipse cx="${x}" cy="${y}" rx="${rx}" ry="${ry}" fill="${c}" opacity="${o}"/>`).join('')+`</g>`+
  `<g filter="url(#neb)" opacity=".7"><path d="M18 260C80 220 120 280 180 240 220 214 250 230 282 210V250C240 270 210 260 170 290 120 320 70 280 18 310Z" fill="#ffb0e8" opacity=".35"/></g>`+
  WB.stars(5,240,{r0:.3,r1:1.2,c:'#ffffff',sp:.02})+WB.stars(17,40,{r0:.8,r1:2,c:'#ffe6fa',sp:.4});
 /* orbit rings around the centre star */
 const orb=`<g fill="none" stroke="#ffd8f4" opacity=".5"><ellipse cx="${cx}" cy="${cy}" rx="112" ry="38" transform="rotate(-24 ${cx} ${cy})" stroke-width="1.2"/><ellipse cx="${cx}" cy="${cy}" rx="98" ry="30" transform="rotate(32 ${cx} ${cy})" stroke-width=".8" stroke-dasharray="3 4"/></g>`+
  `<circle cx="${cx+102*Math.cos(-.42)}" cy="${cy+38*Math.sin(-.42)-40}" r="4" fill="#9ad6ff" stroke="#12081f" stroke-width="1.6"/>`;
 /* the W constellation */
 const P=[[66,118],[104,206],[150,150],[196,206],[234,118]];
 const con=`<path d="${WB.pth(P,false)}" fill="none" stroke="#fff0fa" stroke-width="5" opacity=".35" filter="url(#gl)"/><path d="${WB.pth(P,false)}" fill="none" stroke="#fff0fa" stroke-width="1.6" stroke-dasharray="1 0"/>`+
  P.map(([x,y],i)=>`<circle cx="${x}" cy="${y}" r="9" fill="#ffd0f0" opacity=".45" filter="url(#gl)"/>`+WB.spark(x,y,i===2?10:8,'#fff')+`<circle cx="${x}" cy="${y}" r="2.6" fill="#fff"/>`).join('');
 /* the glowing central star in a ringed medallion */
 const med=`<circle cx="${cx}" cy="${cy+46}" r="100" fill="url(#core)" opacity=".6"/>`+WB.medal(cx,cy+46,52,{beads:30,band:'url(#ring)'})+WB.gring(cx,cy+46,30,36,{n:24,k:3,c:'#ffd8f4',sw:.6,op:.6})+
  `<circle cx="${cx}" cy="${cy+46}" r="30" fill="url(#core)"/><path d="${WB.star(cx,cy+46,8,32,8)}" fill="#fff" stroke="#12081f" stroke-width="2.6" stroke-linejoin="round"/><path d="${WB.star(cx,cy+46,4,46,6)}" fill="#fff6fe" stroke="#12081f" stroke-width="2.6" stroke-linejoin="round"/><circle cx="${cx}" cy="${cy+46}" r="6" fill="#ffd0f0"/>`;
 const fr=WB.frame({i:12,step:16,mid:false,c:'url(#gold)',corner:WB.fan(14,42,{n:10,fill:'#1a0a4a'})})+WB.corners(WB.gem(0,0,7,{c:'amethyst',bezel:2.4}),34,34)+
  [[30,219],[270,219]].map(([x,y])=>WB.spark(x,y,10,'#ffd45a')).join('');
 const plq=WB.plaque('ASTRAL',150,394,{size:20,ls:3,w:116,h:27,fill:'#1a0a4a'});
 return WB.doc(WB.card('url(#sp)')+WB.clip(f+orb)+con+med+fr+plq+WB.edge({c:'#0a0424',hl:'#ffc8f0'})+WB.sheen(),{defs})}};

/* ---------- Dragonfire: molten scales and the burning eye of the lounge's dragon ---------- */
WCBKX.dragon={base:'#8a1a06',art(){const cx=150,cy=219;
 /* one scale: dark plate with a hot rim; tiled in a half-drop so the seams glow like lava */
 const sc=`<path d="M0 0C0 14 9 24 20 24 31 24 40 14 40 0" fill="url(#scl)" stroke="#ff8a1a" stroke-width="1.6"/><path d="M0 0C0 14 9 24 20 24 31 24 40 14 40 0" fill="none" stroke="#2a0400" stroke-width=".8" transform="translate(0 1.4)"/><path d="M8 6C10 14 15 18 20 19" fill="none" stroke="#ffb05a" stroke-width="1" opacity=".55"/>`;
 const defs=WB.lg('scl',[[0,'#3a0800'],[.6,'#7a1806'],[1,'#c8400a']],0,0,0,1)+WB.tile('scales',40,24,`<g>${sc}</g><g transform="translate(-20 -12)">${sc}</g><g transform="translate(20 -12)">${sc}</g><g transform="translate(-20 12)">${sc}</g><g transform="translate(20 12)">${sc}</g><g transform="translate(0 -24)">${sc}</g>`)+
  WB.rg('lava',[[0,'#ffcf5a'],[.25,'#ff6a12'],[.55,'#a8200a'],[1,'#3a0600']],.5,.5,.7)+WB.rg('vig',[[0,'#000',0],[.6,'#000',0],[1,'#200200',.7]],.5,.5,.72)+
  WB.rg('iris',[[0,'#fffbd0'],[.22,'#ffe23a'],[.5,'#ff7a0a'],[.8,'#c81a04'],[1,'#4a0400']],.5,.5,.5)+WB.rg('hot',[[0,'#ffb02a',.75],[.4,'#ff5a0a',.3],[1,'#ff3a0a',0]])+
  WB.lg('fl',[[0,'#fff3a0'],[.35,'#ffb020'],[.75,'#ff4a0a'],[1,'#a8100a',.0]],0,1,0,0)+`<filter id="gl" x="-40%" y="-40%" width="180%" height="180%"><feGaussianBlur stdDeviation="2.5"/></filter>`+
  `<clipPath id="eye"><path d="M92 219Q150 160 208 219Q150 278 92 219Z"/></clipPath>`;
 let f=`<rect x="18" y="18" width="264" height="402" fill="url(#lava)"/><rect x="18" y="18" width="264" height="402" fill="url(#scales)" opacity=".92"/><rect x="18" y="18" width="264" height="402" fill="url(#vig)"/><circle cx="${cx}" cy="${cy}" r="150" fill="url(#hot)"/>`;
 /* flames rising from the bottom and licking down from the top (glow copy, then crisp tongues) */
 const R=WB.rng(77);let up='',dn='';for(let i=0;i<13;i++){const x=24+i*21+R()*8,h=36+R()*46,w=18+R()*10;up+=BX.flame(x,424,h,w,(R()-.5)*14);dn+=BX.flame(x+10,424,h*.7,w*.8,(R()-.5)*10)}
 f+=`<path d="${up}" fill="#ff5a0a" opacity=".65" filter="url(#gl)"/><path d="${up}" fill="url(#fl)"/><g transform="rotate(180 150 219)"><path d="${dn}" fill="url(#fl)" opacity=".8"/></g>`;
 /* rising embers */
 const em=WB.rng(31);for(let i=0;i<34;i++){const x=30+em()*240,y=40+em()*360,r=.8+em()*2.2;f+=`<circle cx="${WB.f1(x)}" cy="${WB.f1(y)}" r="${WB.f1(r)}" fill="${em()<.5?'#ffd23a':'#ff8a1a'}" opacity="${WB.f1(.5+em()*.5)}"/>`}
 /* the socket: horned brow plates around the eye */
 const sock=`<path d="M70 219Q100 150 150 142Q200 150 230 219Q200 290 150 298Q100 290 70 219Z" fill="#12081f" opacity=".5" transform="translate(0 6)"/>`+
  WB.ol('M66 219Q96 146 150 136Q204 146 234 219Q204 292 150 302Q96 292 66 219Z','url(#goldD)',{w:6})+
  `<path d="M78 219Q104 158 150 150Q196 158 222 219Q196 280 150 288Q104 280 78 219Z" fill="#2a0600" stroke="#12081f" stroke-width="3"/>`+
  [[-1,1],[1,1]].map(([sx])=>`<g transform="translate(150 0) scale(${sx} 1) translate(-150 0)">${WB.ol('M150 136C128 120 104 104 76 98 92 112 104 126 112 146Z','url(#goldL)',{w:4})}${WB.ol('M234 219C252 206 266 186 272 164 268 192 256 214 238 232Z','url(#goldL)',{w:3.4})}</g>`).join('')+
  WB.gring(cx,cy,64,72,{n:28,k:3,c:'#ffb05a',sw:.7,op:.6}).replace('<path','<path transform="translate(150 219) scale(1 .78) translate(-150 -219)"');
 /* the eye: fiery iris, slit pupil, veins, catch-lights */
 const eye=`<path d="M92 219Q150 160 208 219Q150 278 92 219Z" fill="#12081f"/><g clip-path="url(#eye)"><rect x="92" y="160" width="116" height="118" fill="url(#iris)"/>`+
  WB.lines(cx,cy,80,8,58,{c:'#7a1404',sw:.9,op:.5})+WB.lines(cx,cy,40,12,50,{c:'#fff3a0',sw:.6,op:.45,rot:.04})+
  `<path d="M150 178Q166 219 150 260Q134 219 150 178Z" fill="#ffe680" opacity=".3"/><path d="M150 184Q162 219 150 254Q138 219 150 184Z" fill="#12081f"/><path d="M150 194Q155 219 150 244" stroke="#8a2a10" stroke-width="1.6" fill="none"/>`+
  `<path d="M98 219Q150 170 202 219" fill="none" stroke="#12081f" stroke-width="9" opacity=".4"/><path d="M118 207Q130 192 152 190Q136 197 124 212Z" fill="#fff" opacity=".9"/><circle cx="170" cy="234" r="2.4" fill="#fff" opacity=".7"/></g>`+
  `<path d="M92 219Q150 160 208 219Q150 278 92 219Z" fill="none" stroke="#12081f" stroke-width="4.5" stroke-linejoin="round"/><path d="M92 219Q150 160 208 219" fill="none" stroke="#ffb05a" stroke-width="1.6" opacity=".8"/>`+WB.spark(214,170,8,'#fff3c0');
 const fr=WB.frame({i:11,step:16,mid:false,c:'url(#gold)',corner:WB.fan(14,42,{n:9,fill:'#2a0400'})})+WB.corners(WB.gem(0,0,7.5,{c:'topaz',bezel:2.4}),34,34)+
  [[29,219],[271,219]].map(([x,y])=>`<g transform="translate(${x} ${y})">${WB.ol('M0-24L8 0 0 24-8 0Z','url(#goldL)',{w:3})}</g>${WB.gem(x,y,4.2,{c:'ruby',bezel:1.4})}`).join('');
 const plq=WB.rot2(WB.plaque('WILDCARD',150,396,{size:23,ls:1.2,w:130,h:29,fill:'#2a0400'}));
 return WB.doc(WB.card('url(#lava)')+WB.clip(f)+sock+eye+fr+plq+WB.edge({c:'#2a0400',hl:'#ffc890'})+WB.sheen(),{defs})}};

/* ---------- Pastel Wyrm: cotton-candy sky, rainbow and the dapper pastel dragon ---------- */
WCBKX.pastel={base:'#e8c8f4',art(){const cx=150,cy=219;
 const defs=WB.lg('sky',[[0,'#ffd0ea'],[.45,'#e6cdfa'],[1,'#bfe2ff']],0,0,0,1)+WB.rg('sun',[[0,'#fffbe6',.9],[.5,'#fff0f8',.4],[1,'#fff',0]])+
  WB.rg('head',[[0,'#ffd6ea'],[.55,'#ffa6cc'],[1,'#e46aa8']],.4,.35,.75)+WB.rg('belly',[[0,'#fff6e0'],[1,'#ffd8b0']],.5,.4,.7)+WB.lg('wing',[[0,'#c9e8ff'],[1,'#8ab8ff']],0,0,1,1)+
  WB.rg('eye',[[0,'#8ad8ff'],[.6,'#3a7ae0'],[1,'#1a2a7a']],.45,.4,.6)+WB.lg('bow',[[0,'#8ad0ff'],[1,'#3a8ae0']],0,0,0,1)+WB.tile('dots',26,26,`<circle cx="6" cy="6" r="1.3" fill="#fff" opacity=".55"/><circle cx="19" cy="19" r="1" fill="#fff" opacity=".4"/>`);
 let f=`<rect x="18" y="18" width="264" height="402" fill="url(#sky)"/><rect x="18" y="18" width="264" height="402" fill="url(#dots)"/><circle cx="${cx}" cy="${cy}" r="170" fill="url(#sun)"/>`;
 /* soft rainbow arc behind the dragon */
 ['#ffb3c6','#ffd6a5','#fdffb6','#caffbf','#a0e7ff','#c8b6ff'].forEach((c,i)=>{const r=128-i*9;f+=`<path d="M${cx-r} ${cy+40}A${r} ${r} 0 0 1 ${cx+r} ${cy+40}" fill="none" stroke="${c}" stroke-width="9.5" opacity=".9"/>`});
 f+=`<path d="M${cx-132} ${cy+40}A132 132 0 0 1 ${cx+132} ${cy+40}M${cx-78} ${cy+40}A78 78 0 0 1 ${cx+78} ${cy+40}" fill="none" stroke="#fff" stroke-width="1.6" opacity=".9"/>`;
 /* layered clouds */
 f+=BX.cloud(24,92,1.3,'#ffffff','#e6c8f4')+BX.cloud(196,70,1.1,'#ffffff','#e6c8f4')+BX.cloud(18,282,1.6,'#ffffff','#d8c4f4')+BX.cloud(196,296,1.7,'#ffffff','#d8c4f4')+BX.cloud(70,380,1.9,'#ffffff','#cdd8ff')+BX.cloud(230,408,1.4,'#ffffff','#cdd8ff');
 f+=WB.stars(9,22,{x:30,y:40,w:240,h:340,r0:1,r1:2.4,c:'#ffffff',sp:.7})+[[60,160],[244,180],[96,58],[230,250]].map(([x,y])=>WB.spark(x,y,7,'#fff')).join('');
 /* the dragon: wings, head, snout, horns, eyes, blush, smile, bow tie */
 const wing=s=>`<g transform="translate(150 0) scale(${s} 1) translate(-150 0)">${WB.ol('M104 214C78 196 58 194 44 204 54 208 58 214 56 222 66 218 74 222 76 230 84 224 94 226 100 232Z','url(#wing)',{w:3.4})}<path d="M100 220L62 206M100 226L74 222" stroke="#5a8ad8" stroke-width="1.4" fill="none"/></g>`;
 const drg=wing(1)+wing(-1)+
  `<ellipse cx="${cx}" cy="${cy+4}" rx="56" ry="50" fill="#12081f" opacity=".2" transform="translate(0 6)"/>`+
  [[-1],[1]].map(([sx])=>`<g transform="translate(150 0) scale(${sx} 1) translate(-150 0)">${WB.ol('M118 182C112 166 112 152 120 142 122 156 128 166 136 172Z','#fff6e0',{w:3})}${WB.ol('M108 196C96 190 90 182 90 172 100 176 108 182 114 190Z','#ffd6ea',{w:3})}</g>`).join('')+
  WB.ol(`M${cx} 168C182 168 206 190 206 220 206 252 182 270 ${cx} 270 118 270 94 252 94 220 94 190 118 168 ${cx} 168Z`,'url(#head)',{w:4.5})+
  `<path d="M108 190Q120 174 140 172" stroke="#fff" stroke-width="3.4" fill="none" opacity=".7" stroke-linecap="round"/>`+
  /* eyes */
  [[124,-1],[176,1]].map(([x])=>`<ellipse cx="${x}" cy="210" rx="14" ry="16" fill="#fff" stroke="#12081f" stroke-width="3"/><ellipse cx="${x+1}" cy="213" rx="9.5" ry="11" fill="url(#eye)"/><circle cx="${x+1}" cy="214" r="4.6" fill="#12081f"/><circle cx="${x-3}" cy="207" r="3.6" fill="#fff"/><circle cx="${x+4}" cy="219" r="1.6" fill="#fff"/>`).join('')+
  `<path d="M110 194Q124 186 136 194M164 194Q176 186 190 194" stroke="#12081f" stroke-width="2.6" fill="none" stroke-linecap="round"/>`+
  /* snout, nostrils, smile, blush, a little tooth */
  WB.ol(`M${cx} 226C170 226 182 236 182 248 182 260 168 266 ${cx} 266 132 266 118 260 118 248 118 236 130 226 ${cx} 226Z`,'url(#belly)',{w:3.4})+
  `<ellipse cx="140" cy="242" rx="3" ry="2.2" fill="#c06090"/><ellipse cx="160" cy="242" rx="3" ry="2.2" fill="#c06090"/><path d="M134 252Q150 264 166 252" stroke="#12081f" stroke-width="2.8" fill="none" stroke-linecap="round"/><path d="M156 256L159 262 162 255Z" fill="#fff" stroke="#12081f" stroke-width="1.2"/>`+
  `<ellipse cx="108" cy="236" rx="10" ry="6" fill="#ff7ab0" opacity=".45"/><ellipse cx="192" cy="236" rx="10" ry="6" fill="#ff7ab0" opacity=".45"/>`+
  /* dapper bow tie */
  WB.ol('M150 280L124 268 122 294Z','url(#bow)',{w:3.2})+WB.ol('M150 280L176 268 178 294Z','url(#bow)',{w:3.2})+`<circle cx="${cx}" cy="281" r="7" fill="#5aa8ff" stroke="#12081f" stroke-width="3"/><path d="M128 274L136 280M172 274L164 280" stroke="#fff" stroke-width="1.6" opacity=".7"/>`+
  WB.spark(204,168,8,'#fff')+WB.spark(98,268,6,'#fff');
 const fr=WB.frame({i:12,step:16,mid:true,c:'url(#goldL)',w:3,corner:WB.filigree({c:'url(#goldL)',sz:.95})})+WB.corners(WB.gem(0,0,6.5,{c:['#fff0f8','#ffb0d8','#c05a98'],bezel:2.2}),34,34);
 const plq=WB.plaque('PASTEL WYRM',150,396,{size:17,ls:1.6,w:132,h:25,fill:'#7a3a8a'});
 return WB.doc(WB.card('url(#sky)')+WB.clip(f)+drg+fr+plq+WB.edge({c:'#a87ac8',hl:'#ffffff',op:.7})+WB.sheen(),{defs})}};

/* ---------- Elder Rune: carved stone, moss, and a ring of glowing teal runes round the elder sigil ---------- */
WCBKX.rune={base:'#3a4a48',art(){const cx=150,cy=219;
 const defs=WB.lg('stone',[[0,'#6a7a76'],[.5,'#4a5856'],[1,'#2e3836']],0,0,.4,1)+`<filter id="rough" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency=".022 .06" numOctaves="5" seed="11"/><feColorMatrix type="matrix" values="0 0 0 0 .08 0 0 0 0 .12 0 0 0 0 .11 0 0 0 -2.6 1.45"/><feComposite in2="SourceGraphic" operator="in"/></filter>`+
  `<filter id="gl" x="-40%" y="-40%" width="180%" height="180%"><feGaussianBlur stdDeviation="3.4"/></filter>`+WB.rg('glo',[[0,'#6affe0',.65],[.45,'#2ad8b8',.22],[1,'#2ad8b8',0]])+WB.rg('vig',[[0,'#000',0],[.6,'#000',0],[1,'#0a1210',.7]],.5,.5,.72)+
  WB.rg('disc',[[0,'#3a5a56'],[1,'#1a2826']],.45,.4,.7)+WB.metal('brz','copper',1)+WB.grain('grit',{f:1.4,k:-2.4,k0:1.35});
 let f=`<rect x="18" y="18" width="264" height="402" fill="url(#stone)"/><rect x="18" y="18" width="264" height="402" fill="#fff" filter="url(#rough)"/>`;
 /* chisel marks and cracks (dark groove with a light lip) */
 const cr='M40 70L66 96 62 120 84 140M232 40L218 74 236 98M258 300L230 318 238 344 216 372M44 330L70 344 64 372 86 396M96 410L108 384 132 380';
 /* masonry joints: the slab is built from fitted blocks */
 const jt='M18 112H120M150 112H282M18 330H96M126 330H282M120 112V60M210 112V18M96 330V420M200 330V380';
 f+=`<path d="${jt}" stroke="#141f1d" stroke-width="3" fill="none"/><path d="${jt}" stroke="#a8bcb6" stroke-width="1" fill="none" transform="translate(1.2 1.4)" opacity=".45"/>`;
 f+=`<path d="${cr}" stroke="#12201e" stroke-width="2.6" fill="none" stroke-linejoin="round"/><path d="${cr}" stroke="#9ab0aa" stroke-width="1" fill="none" transform="translate(1 1.2)" opacity=".55"/>`;
 /* moss patches */
 const R=WB.rng(51);for(const [mx,my,n] of [[34,46,14],[262,404,16],[30,250,9],[268,150,8]]){for(let i=0;i<n;i++){const x=mx+(R()-.5)*44,y=my+(R()-.5)*30,r=3+R()*7;f+=`<circle cx="${WB.f1(x)}" cy="${WB.f1(y)}" r="${WB.f1(r)}" fill="${R()<.5?'#4a7a3a':'#3a6a30'}" opacity="${WB.f1(.55+R()*.4)}"/>`}}
 f+=`<rect x="18" y="18" width="264" height="402" fill="#fff" filter="url(#grit)" opacity=".16"/><circle cx="${cx}" cy="${cy}" r="150" fill="url(#glo)" opacity=".7"/><rect x="18" y="18" width="264" height="402" fill="url(#vig)"/>`;
 /* the carved rune ring: a groove, then the glyphs glowing teal */
 const N=12;let gl='';for(let i=0;i<N;i++){const a=i/N*360;gl+=`<g transform="rotate(${a} ${cx} ${cy}) translate(${cx} ${cy-86})"><path d="${BX.RUNES[i%BX.RUNES.length]}"/></g>`}
 const ring=`<circle cx="${cx}" cy="${cy+5}" r="104" fill="#12081f" opacity=".35"/><circle cx="${cx}" cy="${cy}" r="104" fill="#26332f" stroke="#12081f" stroke-width="4"/><circle cx="${cx}" cy="${cy}" r="98" fill="none" stroke="#7a908a" stroke-width="1.2" opacity=".6"/>`+
  `<circle cx="${cx}" cy="${cy}" r="72" fill="url(#disc)" stroke="#12081f" stroke-width="3.4"/><circle cx="${cx}" cy="${cy}" r="68" fill="none" stroke="#6affe0" stroke-width="1.2" opacity=".55"/>`+
  `<g fill="none" stroke="#2affd0" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" opacity=".55" filter="url(#gl)">${gl}</g><g fill="none" stroke="#12081f" stroke-width="5.4" stroke-linecap="round" stroke-linejoin="round">${gl}</g><g fill="none" stroke="#9affea" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round">${gl}</g>`+
  WB.lines(cx,cy,48,74,96,{c:'#12201e',sw:.9,op:.35});
 /* the elder sigil */
 const sig='M150 166V272M118 186L182 252M182 186L118 252M150 166L136 180M150 166L164 180M150 272L136 258M150 272L164 258M132 219H168';
 const sg=`<path d="${sig}" stroke="#2affd0" stroke-width="12" fill="none" stroke-linecap="round" opacity=".6" filter="url(#gl)"/><path d="${sig}" stroke="#12081f" stroke-width="9" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="${sig}" stroke="#d8fff6" stroke-width="4" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`+
  `<circle cx="${cx}" cy="${cy}" r="11" fill="#12081f"/><circle cx="${cx}" cy="${cy}" r="7" fill="#6affe0"/><circle cx="${cx-2}" cy="${cy-2}" r="2.4" fill="#fff"/>`;
 /* weathered bronze corner clasps with rivets, and a carved border groove */
 const clasp=WB.ol('M0 0H64L52 12H12V52L0 64Z','url(#brz)',{w:3.4})+`<path d="M8 8H50M8 8V50" stroke="#ffe0c4" stroke-width="1" opacity=".55"/>`+WB.rivet(14,14,4.4,{c:'copper'})+WB.rivet(40,8,2.8,{c:'copper'})+WB.rivet(8,40,2.8,{c:'copper'})+`<path d="M20 30Q30 24 34 14" stroke="#4aa890" stroke-width="2" opacity=".6" fill="none"/>`;
 const groove=`<rect x="34" y="34" width="232" height="370" rx="10" fill="none" stroke="#12201e" stroke-width="3"/><rect x="35.5" y="35.5" width="232" height="370" rx="10" fill="none" stroke="#9ab0aa" stroke-width="1" opacity=".5"/>`+
  [[34,219],[266,219],[150,34],[150,404]].map(([x,y],i)=>`<g transform="translate(${x} ${y})"><path d="${BX.RUNES[(i*3+1)%10]}" transform="scale(.7)" stroke="#2affd0" stroke-width="3" fill="none" opacity=".75" stroke-linecap="round"/></g>`).join('');
 return WB.doc(WB.card('url(#stone)',{border:[[0,'#f4f8f6'],[.6,'#e8eeec'],[1,'#c8d4d0']]})+WB.clip(f)+groove+ring+sg+WB.clip(WB.corners(clasp,18,18))+WB.edge({c:'#12201e',hl:'#c8fff0',ho:.2})+WB.sheen({op:.35}),{defs})}};

/* ---------- the Ranked sleeves (one shared frame; rank metal, field and emblem change) ---------- */
/* Forged Copper (first match / Bronze): hammered copper, rivets, forge sparks, a flame crest */
WCBKX.rkcopper={base:'#9a4a1a',art(){const cx=150,cy=219,R=WB.rng(61);let sp='';
 for(let i=0;i<26;i++){const x=40+R()*220,y=60+R()*330,l=6+R()*16,a=-1.9+R()*.6;sp+=`M${WB.f1(x)} ${WB.f1(y)}l${WB.f1(l*Math.cos(a))} ${WB.f1(l*Math.sin(a))}`}
 let rv='';for(let i=0;i<9;i++){const y=60+i*40;rv+=WB.rivet(44,y,3,{c:'copper'})+WB.rivet(256,y,3,{c:'copper'})}
 return BX.sleeve({metal:'cu',mk:'copper',deep:'#3a1206',glow:'#ff8a3a',accent:'#ff6a2a',hl:'#ffd0b0',base:'url(#cf)',
  defs:WB.metal('cf','copper',1)+BX.dimples('ham',34,'#ffe0c4','#4a1606',14,7)+WB.rg('cvig',[[0,'#000',0],[.6,'#000',0],[1,'#2a0a00',.65]],.5,.5,.72)+WB.lg('spk',[[0,'#fff3a0'],[1,'#ff6a0a',0]],0,0,1,0)+
   WB.rg('fl',[[0,'#fff6c0'],[.4,'#ffb020'],[.8,'#ff4a0a'],[1,'#a81a04']],.5,.7,.7)+WB.rg('band',[[0,'#7a3410'],[1,'#3a1206']],.45,.4,.7),
  field:`<rect x="18" y="18" width="264" height="402" fill="url(#cf)"/><rect x="18" y="18" width="264" height="402" fill="url(#ham)"/><rect x="18" y="18" width="264" height="402" fill="url(#cvig)"/>`+
   `<path d="${sp}" stroke="#ffb040" stroke-width="2" stroke-linecap="round" opacity=".85"/><path d="${sp}" stroke="#fff6c0" stroke-width=".8" stroke-linecap="round"/>`+
   WB.lines(cx,cy,60,90,260,{c:'#3a1206',sw:.6,op:.22}),
  deco:rv+`<path d="M44 40V400M256 40V400" stroke="#3a1206" stroke-width="1" opacity=".5"/>`,
  band:'url(#band)',emblem:`<path d="M150 170C162 186 178 196 178 222 178 244 164 262 150 262 136 262 122 244 122 222 122 206 132 196 138 182 140 196 146 202 152 204 148 192 146 182 150 170Z" fill="url(#fl)" stroke="#12081f" stroke-width="4" stroke-linejoin="round"/>`+
   `<path d="M150 214C158 222 164 230 162 242 160 252 154 256 150 256 144 256 138 250 138 242 138 232 144 226 150 214Z" fill="#fff3b0" stroke="#12081f" stroke-width="2.6"/>`+WB.lines(cx,cy,32,36,52,{c:'#ffb070',sw:1,op:.5})+WB.spark(176,180,6,'#fff6d0')})}};

/* Moonsteel (Silver): brushed silver, a star chart, a crescent moon with moonstones */
WCBKX.rkmoon={base:'#5a6a8a',art(){const cx=150,cy=219;let br='';for(let y=20;y<420;y+=3)br+=`M18 ${y}H282`;
 const st=[[56,74],[88,58],[112,92],[70,120]],st2=[[214,330],[244,306],[232,272],[202,288],[188,256]];
 return BX.sleeve({metal:'ag',mk:'silver',deep:'#141c34',glow:'#c8d8ff',accent:'#9ad0ff',hl:'#ffffff',base:'url(#mf)',r:66,
  defs:WB.lg('mf',[[0,'#3a4a72'],[.5,'#22305a'],[1,'#121a38']],0,0,.5,1)+WB.rg('mvig',[[0,'#000',0],[.6,'#000',0],[1,'#060a1a',.6]],.5,.5,.72)+WB.rg('moon',[[0,'#ffffff'],[.6,'#dfe8ff'],[1,'#8a9ac8']],.35,.35,.75)+WB.rg('band',[[0,'#2a3a6a'],[1,'#0e1430']],.45,.4,.7),
  field:`<rect x="18" y="18" width="264" height="402" fill="url(#mf)"/><path d="${br}" stroke="#c8d8ff" stroke-width=".5" opacity=".08"/>`+
   `<g fill="none" stroke="#c8d8ff" opacity=".22"><circle cx="${cx}" cy="${cy}" r="110" stroke-width="1"/><circle cx="${cx}" cy="${cy}" r="140" stroke-width=".7" stroke-dasharray="2 5"/><ellipse cx="${cx}" cy="${cy}" rx="180" ry="70" stroke-width=".7"/></g>`+
   WB.lines(cx,cy,24,100,250,{c:'#c8d8ff',sw:.5,op:.14})+WB.stars(33,90,{r0:.4,r1:1.3,c:'#e6eeff',sp:.1})+
   [st,st2].map(P=>`<path d="${WB.pth(P,false)}" stroke="#e6eeff" stroke-width="1" fill="none" opacity=".7"/>`+P.map(([x,y])=>WB.spark(x,y,5,'#fff')).join('')).join('')+`<rect x="18" y="18" width="264" height="402" fill="url(#mvig)"/>`,
  deco:WB.rot2(`<path d="M60 170Q50 219 60 268" fill="none" stroke="#c8d8ff" stroke-width="1.2" opacity=".5"/>`)+WB.corners(WB.gem(0,0,4.5,{c:['#ffffff','#c8e0ff','#5a7ab0'],bezel:1.6,bc:'url(#ag)'}),56,56),
  band:'url(#band)',emblem:`<circle cx="${cx}" cy="${cy}" r="44" fill="#0e1430"/>`+WB.stars(71,18,{x:110,y:180,w:80,h:80,r0:.4,r1:1.2,c:'#fff',sp:.2})+
   `<path d="M168 184A40 40 0 1 0 168 254A32 32 0 1 1 168 184Z" fill="url(#moon)" stroke="#12081f" stroke-width="3.4" stroke-linejoin="round"/>`+
   `<circle cx="132" cy="206" r="4" fill="#b8c4e0" opacity=".7"/><circle cx="124" cy="232" r="6" fill="#b8c4e0" opacity=".6"/><circle cx="140" cy="248" r="3" fill="#b8c4e0" opacity=".7"/>`+WB.spark(176,214,8,'#fff')+WB.spark(186,240,4.5,'#fff')})}};

/* Sunforged (Gold): a blazing sunburst field and a sun disc with a face */
WCBKX.rksun={base:'#e0601a',art(){const cx=150,cy=219;
 const face=`<circle cx="${cx}" cy="${cy}" r="34" fill="url(#sd)" stroke="#12081f" stroke-width="3.4"/>`+
  `<path d="M134 212Q140 206 146 212M154 212Q160 206 166 212" stroke="#7a3a04" stroke-width="2.6" fill="none" stroke-linecap="round"/><path d="M138 232Q150 242 162 232" stroke="#7a3a04" stroke-width="2.6" fill="none" stroke-linecap="round"/>`+
  `<ellipse cx="132" cy="226" rx="5" ry="3" fill="#ff7a3a" opacity=".5"/><ellipse cx="168" cy="226" rx="5" ry="3" fill="#ff7a3a" opacity=".5"/><path d="M128 200Q140 188 156 190" stroke="#fff" stroke-width="2.4" fill="none" opacity=".6" stroke-linecap="round"/>`;
 return BX.sleeve({metal:'au',mk:'gold',deep:'#5a1a04',glow:'#ffe066',accent:'#ff4a1f',hl:'#fff3c0',base:'url(#sf)',r:66,
  defs:WB.rg('sf',[[0,'#ffe066'],[.35,'#ffa020'],[.75,'#e8440a'],[1,'#8a1404']],.5,.5,.75)+WB.rg('sd',[[0,'#fffbe0'],[.5,'#ffd23a'],[1,'#e8800a']],.4,.35,.7)+WB.rg('band',[[0,'#c8500a'],[1,'#6a1a04']],.45,.4,.7),
  field:`<rect x="18" y="18" width="264" height="402" fill="url(#sf)"/>`+WB.rays(cx,cy,36,320,{c:'#fff3a0',op:.22,w:.045})+WB.rays(cx,cy,36,320,{c:'#8a1404',op:.12,w:.03,rot:.087})+
   WB.gring(cx,cy,118,128,{n:40,k:3,c:'#fff3c0',sw:.6,op:.35})+WB.gring(cx,cy,150,160,{n:48,k:3,c:'#fff3c0',sw:.5,op:.25}),
  deco:'',band:'url(#band)',
  emblem:`<path d="${WB.star(cx,cy,16,52,38)}" fill="url(#goldL)" stroke="#12081f" stroke-width="3" stroke-linejoin="round"/><path d="${WB.star(cx,cy,16,46,36,Math.PI/16)}" fill="#ffb020" stroke="#12081f" stroke-width="2" stroke-linejoin="round"/>`+face+WB.spark(184,184,7,'#fffbe0')})}};

/* Glacier Rune (Platinum): layered ice shards, frost feathers, a snowflake rune */
WCBKX.rkglacier={base:'#2a8a92',art(){const cx=150,cy=219,R=WB.rng(91);let sh='';
 for(let i=0;i<28;i++){const x=18+R()*264,y=18+R()*402,w=20+R()*50,h=40+R()*90,a=(R()-.5)*.6;const P=[[x,y-h/2],[x+w/2,y-h/6],[x+w/3,y+h/2],[x-w/2,y+h/3],[x-w/3,y-h/4]].map(([px,py])=>[x+(px-x)*Math.cos(a)-(py-y)*Math.sin(a),y+(px-x)*Math.sin(a)+(py-y)*Math.cos(a)]);
  sh+=`<path d="${WB.pth(P)}" fill="${R()<.5?'#bff6ff':'#5ad0e0'}" opacity="${WB.f1(.08+R()*.16)}" stroke="#e6ffff" stroke-width=".8" stroke-opacity=".35"/>`}
 const fz=BX.frost(3,12);const flake=a=>`<g transform="rotate(${a} ${cx} ${cy})"><path d="M150 219V175M150 186L141 178M150 186L159 178M150 198L138 188M150 198L162 188" stroke="#12081f" stroke-width="7" stroke-linecap="round" fill="none"/><path d="M150 219V175M150 186L141 178M150 186L159 178M150 198L138 188M150 198L162 188" stroke="#effcff" stroke-width="3.2" stroke-linecap="round" fill="none"/></g>`;
 return BX.sleeve({metal:'pt',mk:'silver',deep:'#06343a',glow:'#bff6ff',accent:'#5ae8ff',hl:'#e6ffff',base:'url(#gf)',r:66,
  defs:WB.lg('gf',[[0,'#6adbe6'],[.45,'#1f9aa8'],[1,'#0a4a58']],0,0,.4,1)+WB.rg('gvig',[[0,'#000',0],[.6,'#000',0],[1,'#03202a',.6]],.5,.5,.72)+WB.rg('band',[[0,'#1f8a98'],[1,'#063040']],.45,.4,.7)+WB.rg('ice',[[0,'#ffffff'],[.6,'#c8f6ff'],[1,'#6ad0e0']],.4,.35,.7),
  field:`<rect x="18" y="18" width="264" height="402" fill="url(#gf)"/>${sh}<rect x="18" y="18" width="264" height="402" fill="url(#gvig)"/>`+
   WB.corners(`<path d="${fz}" stroke="#e6ffff" stroke-width="1.4" fill="none" opacity=".75" stroke-linecap="round"/>`,22,22)+WB.stars(19,30,{r0:.5,r1:1.6,c:'#ffffff',sp:.6}),
  deco:'',band:'url(#band)',emblem:`<circle cx="${cx}" cy="${cy}" r="46" fill="url(#ice)" opacity=".35"/>`+[0,60,120,180,240,300].map(flake).join('')+`<path d="${WB.poly(cx,cy,6,12)}" fill="#effcff" stroke="#12081f" stroke-width="3" stroke-linejoin="round"/><circle cx="${cx}" cy="${cy}" r="4" fill="#5ae8ff"/>`+WB.spark(182,180,7,'#fff')})}};

/* Prism Facet (Diamond): a faceted crystal field with rainbow refractions, a cut diamond with crystal wings */
WCBKX.rkprism={base:'#2a5ad0',art(){const cx=150,cy=219,R=WB.rng(23);let tri='';const cs=['#8ad0ff','#4a8aff','#2a5ad0','#bfe8ff','#1a3a9a','#6ab0ff'];
 for(let r=0;r<12;r++)for(let c=0;c<8;c++){const x=18+c*36-(r%2?18:0),y=18+r*36;const up=`M${x} ${y+36}L${x+18} ${y} ${x+36} ${y+36}Z`,dn=`M${x+18} ${y}L${x+54} ${y} ${x+36} ${y+36}Z`;
  tri+=`<path d="${up}" fill="${cs[Math.floor(R()*cs.length)]}" opacity="${WB.f1(.55+R()*.45)}"/><path d="${dn}" fill="${cs[Math.floor(R()*cs.length)]}" opacity="${WB.f1(.55+R()*.45)}"/>`}
 const wing=s=>`<g transform="translate(150 0) scale(${s} 1) translate(-150 0)">${[[0,0],[8,16],[16,32]].map(([a,b],i)=>WB.ol(`M104 ${206+b}L${64-a} ${190+b*1.2}L${80-a} ${212+b}L${54-a*1.2} ${214+b*1.3}L${98} ${226+b*.8}Z`,i%2?'#cfe8ff':'#8ad0ff',{w:3})).join('')}</g>`;
 return BX.sleeve({metal:'di',mk:'silver',deep:'#0a1a5a',glow:'#bfe8ff',accent:'#8ad0ff',hl:'#ffffff',base:'url(#pf)',r:62,
  defs:WB.lg('pf',[[0,'#4a8aff'],[1,'#12307a']],0,0,0,1)+WB.lg('rb',[[0,'#ff7ab0',0],[.2,'#ff7ab0',.5],[.4,'#ffd23a',.5],[.6,'#5ae87a',.5],[.8,'#5ac8ff',.5],[1,'#9a5aff',0]],0,0,1,0)+
   WB.lg('dia',[[0,'#ffffff'],[.5,'#cfe8ff'],[1,'#5a8ae0']],0,0,1,1)+WB.rg('band',[[0,'#2a5ad0'],[1,'#0a1a5a']],.45,.4,.7)+WB.rg('pvig',[[0,'#000',0],[.6,'#000',0],[1,'#040c30',.55]],.5,.5,.72),
  field:`<rect x="18" y="18" width="264" height="402" fill="url(#pf)"/>${tri}<g transform="rotate(-28 150 219)"><rect x="-60" y="120" width="420" height="22" fill="url(#rb)"/><rect x="-60" y="300" width="420" height="14" fill="url(#rb)" opacity=".7"/></g><rect x="18" y="18" width="264" height="402" fill="url(#pvig)"/>`+WB.stars(29,26,{r0:.8,r1:2,c:'#ffffff',sp:.8}),
  deco:wing(1)+wing(-1),band:'url(#band)',
  emblem:`<path d="M122 204L134 188H166L178 204 150 244Z" fill="url(#dia)" stroke="#12081f" stroke-width="3.6" stroke-linejoin="round"/><path d="M122 204H178M134 188L142 204 150 188 158 204 166 188M142 204L150 244 158 204" stroke="#3a6ac8" stroke-width="1.4" fill="none"/>`+
   `<path d="M136 192L141 202 147 192Z" fill="#fff" opacity=".85"/>`+WB.spark(176,180,8,'#fff')+WB.spark(124,238,4.5,'#fff')})}};

/* Celestial (Legend): violet and gold heavens, great feathered wings round a radiant star */
WCBKX.rkcelest={base:'#4a1a8a',art(){const cx=150,cy=219;
 const feathers=s=>{let d='';for(let i=0;i<7;i++){const a=-0.55+i*.2,len=78-i*5,x0=cx-50,y0=cy-8+i*3;const x1=x0-len*Math.cos(a),y1=y0+len*Math.sin(a)*.9-30+i*6;
  d+=WB.ol(`M${x0} ${y0}Q${WB.f1((x0+x1)/2)} ${WB.f1(y1-14)} ${WB.f1(x1)} ${WB.f1(y1)}Q${WB.f1((x0+x1)/2+6)} ${WB.f1(y1+10)} ${x0} ${y0+12}Z`,i%2?'url(#goldL)':'#ffe9a0',{w:3})}
  return `<g transform="translate(150 0) scale(${s} 1) translate(-150 0)">${d}<path d="M${cx-50} ${cy-4}Q${cx-80} ${cy-70} ${cx-130} ${cy-84}" stroke="#fff6d0" stroke-width="1.2" fill="none" opacity=".6"/></g>`};
 return BX.sleeve({metal:'cg',mk:'gold',deep:'#1e0640',glow:'#e6b8ff',accent:'#c88aff',hl:'#f0d8ff',base:'url(#vf)',r:58,halo:150,
  defs:WB.rg('vf',[[0,'#9a5aff'],[.45,'#5a1aa8'],[.85,'#2a0a62'],[1,'#14042e']],.5,.42,.78)+WB.rg('band',[[0,'#6a2ab8'],[1,'#1e0640']],.45,.4,.7)+WB.rg('core',[[0,'#ffffff'],[.4,'#fff3c0'],[1,'#ffd45a',0]]),
  field:`<rect x="18" y="18" width="264" height="402" fill="url(#vf)"/>`+WB.rays(cx,cy,48,330,{c:'#ffd45a',op:.14,w:.03})+WB.rosette(cx,cy,140,{n:18,k:5,a:.3,r0:90,c:'#f0d8ff',sw:.5,op:.28})+
   WB.stars(83,120,{r0:.4,r1:1.5,c:'#fff6ff',sp:.15})+`<g fill="none" stroke="#ffd45a" opacity=".5"><ellipse cx="${cx}" cy="${cy}" rx="120" ry="34" stroke-width="1.4"/><ellipse cx="${cx}" cy="${cy}" rx="132" ry="40" stroke-width=".7" stroke-dasharray="3 4"/></g>`+
   `<path d="${WB.pth([[60,70],[96,96],[84,130],[120,150]],false)}M${WB.pth([[240,368],[206,344],[220,312],[184,292]],false).slice(1)}" stroke="#fff3c0" stroke-width=".9" fill="none" opacity=".55"/>`+[[60,70],[96,96],[84,130],[120,150],[240,368],[206,344],[220,312],[184,292]].map(([x,y])=>WB.spark(x,y,4,'#fff')).join(''),
  deco:feathers(1)+feathers(-1),
  band:'url(#band)',beads:30,
  emblem:`<circle cx="${cx}" cy="${cy}" r="38" fill="url(#core)" opacity=".8"/><path d="${WB.star(cx,cy,8,42,14,Math.PI/8)}" fill="url(#goldL)" stroke="#12081f" stroke-width="2.6" stroke-linejoin="round" opacity=".9"/>`+
   `<path d="${WB.star(cx,cy,4,40,9)}" fill="#fffbe6" stroke="#12081f" stroke-width="3" stroke-linejoin="round"/><circle cx="${cx}" cy="${cy}" r="7" fill="#e6b8ff" stroke="#12081f" stroke-width="2"/>`+WB.spark(182,186,9,'#fff')+WB.spark(118,252,6,'#fff')})}};
