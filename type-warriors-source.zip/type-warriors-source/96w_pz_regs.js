/* ===== 9.5 THE CROOKED CUE: The Regulars (96w) =====
   A screen for your career at the Crooked Cue: every regular as a card (your record against them, wins toward their
   cue, their felt), your numbers, and the pool trophies with progress. Click a regular to go and play them. */
function pzRegs(){const Z=PZS(),tk=++PZ.tok;PZ.on=false;PZ.hub=true;CAS.on=true;CAS.key=null;CAS.tok++;try{pzMusicOn()}catch(e){}
 const v=pzVs(),ids=[...PZ_ORDER,...((Z.shade.seen||0)>0?['shade']:[])];
 const card=(k,i)=>{const R=PZ_REG[k],open=k==='shade'||pzOpen(k),n=k==='shade'?(Z.shade.beat||0):(Z.beat[k]||0),r=v[k]||[0,0],cue=k==='shade'?PZ_CUES.find(c=>c.beatShade):PZ_CUES.find(c=>c.beat===k),felt=PZ_FELT.find(f=>f.beat===k),cn=Math.min(3,n),cueOwn=cue&&Z.cues[cue.id];
  const prev=i?PZ_REG[PZ_ORDER[i-1]]:null;
  return `<button class="pzrg ${open?'':'lock'} ${n?'won':''}" data-k="${k}" style="--c:${R.c};--i:${i}" ${open?'':'disabled'}><canvas width="176" height="176" data-p="${k}"></canvas>
   <b>${open?R.n:'? ? ?'}</b><small>${open?R.k:`Beat ${prev?prev.n:'the last regular'} to meet them`}</small>
   ${open?`<div class="pzrgr"><span><b>${r[0]}</b>W</span><span><b>${r[1]}</b>L</span><span><b>${n}</b>beaten</span></div>
   <div class="pzrgc"><span>${cue?cue.n:''}</span><i>${[0,1,2].map(j=>`<u class="${cueOwn||j<cn?'on':''}"></u>`).join('')}</i></div>
   ${felt?`<div class="pzrgf ${Z.felts[felt.id]?'on':''}">${felt.n} felt · ${Z.felts[felt.id]?'won':'win once'}</div>`:'<div class="pzrgf"></div>'}`:''}</button>`};
 const W=Z.wins||0,L=Z.losses||0,tot=W+L,net=Z.net||0;
 const stats=[[W,'Wins'],[L,'Losses'],[tot?Math.round(W/tot*100)+'%':'-','Win rate'],[Z.best||0,'Best streak'],[(net<0?'−':'+')+cmn(Math.abs(net)),'Pool net'],[Z.rackWins||0,'Racks won'],[Z.pots||0,'Balls potted'],[Z.banks||0,'Bank shots'],[Z.bnr||0,'Break & runs'],[Z.golden||0,'Golden breaks'],[Z.taunts||0,'Taunts typed'],[typeof pzTrickTotal==='function'?pzTrickTotal()+' ★':'-','Trick stars']];
 const tro=pzTrophies(),got=tro.filter(a=>P.ach&&P.ach[a.id]).length;
 show(`<div class="pzk pzrgs" id="pzk"><canvas id="pzkbg" width="1600" height="900"></canvas><button class="pzback" id="pzbk">‹&nbsp; The bar</button><div class="pzgold"><i></i><b>${cmn(P.gold)}</b></div>
  <div class="pztitle sm">The Regulars</div>
  <div class="pzrggrid">${ids.map(card).join('')}</div>
  <div class="pzrgside"><div class="pzrgh">Your numbers</div><div class="pzrgst">${stats.map(([n,l],i)=>`<div style="--i:${i}"><b>${n}</b><small>${l}</small></div>`).join('')}</div>
   <div class="pzrgh">Trophies <span>${got} / ${tro.length}</span></div><div class="pzrgtr">${tro.map(a=>{const on=!!(P.ach&&P.ach[a.id]);let pv=0;try{pv=Math.min(a.tg,Math.floor(a.v()))}catch(e){}return `<div class="${on?'on':''}" title="${a.d.replace(/"/g,'&quot;')}">${typeof trophy==='function'?trophy(a.t,on,24):''}<span><b>${a.n}</b><small>${on?'Earned':a.d}</small>${!on&&a.tg>1?`<em><i style="transform:scaleX(${pv/a.tg})"></i></em>`:''}</span></div>`}).join('')}</div></div></div>`,'casbg pzx');
 $('pzkbg').getContext('2d').drawImage(pzHubBake(),0,0);
 $('pzbk').onclick=()=>pzGo(pzHub);S.back=()=>pzGo(pzHub);
 ov.querySelectorAll('.pzrg canvas[data-p]').forEach(cv=>{const k=cv.dataset.p,g=cv.getContext('2d'),lock=cv.closest('.lock');pzCastPortrait(g,'mon',k,176,1.3,Object.assign(pzCastEx(),PZ_EXP.happy));if(lock){g.globalCompositeOperation='source-in';g.fillStyle='#0c0818';g.fillRect(0,0,176,176);g.globalCompositeOperation='source-over'}});
 ov.querySelectorAll('.pzrg').forEach(b=>b.onclick=()=>{if(b.disabled)return;const k=b.dataset.k;if(k==='shade'&&!PZ.shadeHere){pzNote('Slick Shade only turns up when he feels like it. Keep an eye on the bar.');return}PZ.sel=k;pzFx('tick');pzGo(pzHub)});
 const root=$('pzk');root.classList.add('pzscrin');setTimeout(()=>{if(root.isConnected)root.classList.remove('pzscrin')},900);pzFitTM()}
{const st=document.createElement('style');st.textContent=`
.pzrggrid{position:absolute;left:28px;top:112px;width:1040px;display:grid;grid-template-columns:repeat(4,1fr);gap:16px;z-index:2}
.pzrg{position:relative;height:362px;padding:12px 12px 10px;border-radius:22px;background:linear-gradient(180deg,#241c60,#110a32);border:3px solid #4a3e90;color:#efe8ff;cursor:pointer;text-align:center;box-shadow:inset 0 1px 0 #ffffff24,0 10px 26px #0009;transition:transform .22s cubic-bezier(.3,1.5,.5,1);animation:pzrise .45s calc(.05s + var(--i)*.04s) cubic-bezier(.25,1.25,.45,1) both}
.pzrg:hover:not(:disabled){transform:translateY(-6px) rotate(-.6deg);border-color:var(--c)}.pzrg.won{border-color:var(--c)}
.pzrg canvas{display:block;width:150px;height:150px;margin:0 auto 4px;border-radius:50%;background:radial-gradient(circle at 50% 42%,#4a3a8a,#140c36 70%);border:3px solid #12081f;box-shadow:0 0 0 3px var(--c)}
.pzrg.lock canvas{box-shadow:0 0 0 3px #3a3456}.pzrg.lock{cursor:default;opacity:.7}
.pzrg>b{display:block;font:400 25px/1.1 "Pirata One",serif;color:var(--c);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.pzrg.lock>b{color:#8a86a0}
.pzrg>small{display:block;font:600 12px Poppins,sans-serif;color:#c4badf;min-height:16px}
.pzrgr{display:flex;justify-content:center;gap:12px;margin:8px 0 6px;font:700 11px Poppins,sans-serif;color:#9a90c8}.pzrgr b{font:400 22px/1 "Pirata One",serif;color:#efe8ff;margin-right:3px}
.pzrgc{display:flex;align-items:center;justify-content:space-between;gap:6px;padding:6px 10px;border-radius:11px;background:#0c0824;border:2px solid #2a2468;font:700 11.5px Poppins,sans-serif;color:#e2dafc}
.pzrgc span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.pzrgc i{display:flex;gap:3px;flex:none}.pzrgc u{width:10px;height:10px;border-radius:50%;background:#2a2468;border:2px solid #12081f}.pzrgc u.on{background:var(--c)}
.pzrgf{margin-top:6px;min-height:15px;font:700 11px Poppins,sans-serif;color:#8a80b8}.pzrgf.on{color:#8affb4}
.pzrgside{position:absolute;left:1088px;top:112px;width:484px;height:764px;box-sizing:border-box;padding:14px 18px;border-radius:24px;background:linear-gradient(180deg,#221a5a,#100a30);border:3px solid #4a3e90;box-shadow:inset 0 1px 0 #ffffff1f,0 10px 28px #0009;z-index:2;animation:pzfromR .45s .1s cubic-bezier(.25,1.25,.45,1) both}
.pzrgh{display:flex;justify-content:space-between;align-items:baseline;font:400 30px/1.1 "Pirata One",serif;color:#ffd45a;margin:2px 2px 8px}.pzrgh span{font:800 14px Poppins,sans-serif;color:#c4badf}
.pzrgst{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:14px}.pzrgst div{padding:7px 4px 6px;border-radius:12px;background:#140c36;border:2px solid #3a3070;text-align:center;animation:pzpopIn .35s calc(.2s + var(--i)*.025s) both}
.pzrgst b{display:block;font:400 24px/1 "Pirata One",serif;color:#efe8ff;white-space:nowrap}.pzrgst small{display:block;margin-top:2px;font:800 9px Poppins,sans-serif;letter-spacing:.08em;color:#9a90c8;text-transform:uppercase}
.pzrgtr{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:6px;text-align:left}
.pzrgtr>div{display:flex;align-items:center;gap:8px;padding:5px 8px;min-height:44px;box-sizing:border-box;border-radius:12px;background:#140c36;border:2px solid #2a2468;opacity:.78}.pzrgtr>div.on{opacity:1;border-color:#c99a3a}
.pzrgtr svg{flex:none}.pzrgtr span{flex:1;min-width:0}.pzrgtr b{display:block;font:800 12px/1.2 Poppins,sans-serif;color:#efe8ff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.pzrgtr small{display:block;font:500 11px/1.3 Poppins,sans-serif;color:#9a90c8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.pzrgtr .on small{color:#ffd45a}
.pzrgtr em{display:block;height:4px;margin-top:3px;border-radius:2px;background:#2a2468;overflow:hidden}.pzrgtr em i{display:block;height:100%;background:#ffd45a;transform-origin:0 50%}
`;document.head.appendChild(st)}
