/* ---------- Resume Run: if the tab closes or refreshes mid-run (Endless or Campaign), the next visit offers to re-enter that run
   from the start of its last round, or close and delete it. There is no save-and-quit: the run is only kept for an unexpected exit.
   Health, shields, revives and damage taken carry over from the moment of the exit, and gold or crates already banked that round
   are not paid out a second time, so reloading never makes a run easier or richer. ---------- */
const RSK='typeWarriorsResume';let RSV=null,RSV_LAST='';
const RS_SKIP=new Set(['back','tgt','cr2','boonList','swap','fx','dn','sl','shots','chips','pose','late','ps','fl','dy','pj','en','cr','tip','ban','dcq']);
const rsOk=()=>!!S&&!S.rift&&!S.prac&&!S.dc&&(S.mode==='play'||S.mode==='pause'||S.mode==='boon');
function rsSnap(){try{if(!rsOk()||S.mode!=='play')return;const o={};for(const k in S){if(RS_SKIP.has(k))continue;const v=S[k];if(typeof v==='function')continue;o[k]=v}
  RSV={v:1,ts:Date.now(),camp:S.camp,wave:S.wave,round:S.round,pg0:P.gold,S:JSON.parse(JSON.stringify(o)),live:null};RSV_LAST='';rsLive(1)}catch(e){}}
function rsLive(force){if(!RSV)return;try{if(!rsOk())return;RSV.live={hp:S.hp,shield:S.shield,rev:S.rev,revFull:S.revFull,dmg:S.dmgTaken,gold:S.gold,runC:S.runC||0,fury:S.fury,t:Date.now()};
  const j=JSON.stringify(RSV);if(!force&&j===RSV_LAST)return;RSV_LAST=j;sgPut(RSK,j)}catch(e){}}
function rsClear(){RSV=null;RSV_LAST='';try{sgDel(RSK)}catch(e){}}
function rsRead(){try{const r=JSON.parse(sgGet(RSK)||'null');if(!r||r.v!==1||!r.S||typeof r.S!=='object'||!(r.S.wave>0))return null;return r}catch(e){return null}}
/* hooks: every new round takes a fresh snapshot; any ending clears it */
{const sw=startWave;startWave=function(){const r=sw.apply(this,arguments);rsSnap();return r}}
{const ov0=over;over=function(){rsClear();return ov0.apply(this,arguments)}}
{const vi=victory;victory=function(){rsClear();return vi.apply(this,arguments)}}
{const st0=start;start=function(){RS_ASK=false;rsClear();return st0.apply(this,arguments)}}
{const g0=gain;gain=function(n){const b=S.gold;g0(n);if(S.gdebt>0){const d=S.gold-b,t=Math.min(S.gdebt,Math.max(0,d));if(t>0){S.gold-=t;P.gold-=t;S.gdebt-=t}}}}
{const d0=drop;drop=function(e){if(S.cdebt>0){S.cdebt--;return}return d0(e)}}
setInterval(()=>rsLive(),500);
window.addEventListener('pagehide',()=>rsLive(1));document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')rsLive(1)});
function rsLabel(r){return r.S&&r.S.bg?`Beginner's Mode, level ${lvOf(r.wave)}, round ${r.round} of 5`:r.S&&r.S.gy?`Monster Mash, level ${lvOf(r.wave)}, round ${r.round} of 5`:r.camp?`Campaign level ${r.camp}, round ${r.round} of 5`:`Endless, level ${lvOf(r.wave)}, round ${r.round} of 5`}
function rsOffer(){const r=rsRead();if(!r){if(sgGet(RSK)!==null)rsClear();return}
 const L=r.live||{},hp=L.hp!=null?L.hp:r.S.hp,mx=r.S.max||3,ago=Math.max(0,Math.round((Date.now()-(L.t||r.ts))/60000));let armed=false;
 S.mode='rsoffer';S.view='menu';
 const draw=()=>show(`<div class="rsm"><div class="rsi"><svg viewBox="0 0 64 64" width="64" height="64" aria-hidden="true"><circle cx="32" cy="32" r="29" fill="#241a60" stroke="#ffd76a" stroke-width="3"/><path d="M22 14h20M22 50h20M24 14c0 10 16 12 16 18s-16 8-16 18M40 14c0 10-16 12-16 18s16 8 16 18" fill="none" stroke="#ffe9a0" stroke-width="3" stroke-linecap="round"/><path d="M27 46c2-3 8-3 10 0z" fill="#ffc94a"/></svg></div>
  <h2>Unfinished run</h2><p class="rss">${esc(rsLabel(r))}</p>
  <div class="rsg"><span><b>${(r.S.score||0).toLocaleString()}</b><small>score</small></span><span><b>${Math.max(0,hp)} / ${mx}</b><small>health</small></span><span><b>${(r.S.bl||[]).length}</b><small>boon${(r.S.bl||[]).length===1?'':'s'}</small></span><span><b>${ago<1?'just now':ago<60?ago+' min ago':Math.round(ago/60)+' h ago'}</b><small>left</small></span></div>
  <p class="rsn">Your last game ended without finishing. Re-enter it to replay the current round from its start, with the health you had when you left. Close and delete ends it for good, with no rewards.</p>
  <div class="row"><button id="rsy">Re-enter game</button><button class="sm dg" id="rsn">${armed?'Click again to delete':'Close and delete'}</button></div></div>`,'m nosb');
 draw();S.back=()=>{};
 const wire=()=>{$('rsy').onclick=()=>{RS_ASK=false;rsResume(r)};$('rsn').onclick=()=>{if(!armed){armed=true;draw();wire();return}RS_ASK=false;rsClear();title()}};wire()}
function rsResume(r){reset();Object.assign(S,JSON.parse(JSON.stringify(r.S)));
 for(const k of['en','pj','dy','cr','fx','dn','sl','shots','chips','ps','fl'])S[k]=[];S.tgt=null;S.back=null;S.boonList=null;S.swap=null;S.cr2=null;S.pose=null;S.late=null;S.tip=null;
 const L=r.live;if(L){S.hp=Math.min(S.max,L.hp);S.shield=L.shield;S.rev=L.rev;S.revFull=L.revFull;S.dmgTaken=Math.max(S.dmgTaken||0,L.dmg||0);S.fury=Math.min(S.fm||100,L.fury||0);
  const banked=Math.max(0,Math.min((L.gold||0)-(r.S.gold||0),P.gold-(r.pg0||0)));S.gdebt=banked;S.gold=(r.S.gold||0)+banked;S.cdebt=Math.max(0,(L.runC||0)-(r.S.runC||0));S.runC=Math.max(S.runC||0,L.runC||0)}
 if(S.hp<=0){S.hp=1}
 S.mode='play';S.wpn=S.wpn||P.weapon;hide();
 S.ban={t:3.2,txt:'Run resumed',c:'#7dffb0',sub:`Round ${S.round} starts over. Your health carries over.`};
 RSV=r;RSV.live=null;rsSnapKeep(r);try{jingle(S.round===5?'boss':'wave')}catch(e){}}
function rsSnapKeep(r){RSV=r;RSV_LAST='';rsLive(1)}
/* the choice is shown whenever the home screen would appear, until the player picks A or B, so no other start-up screen can hide it */
let RS_ASK=true,RS_MEMNOTE=false;
{const t0=title;title=function(){
  if(SGS.mem&&!RS_MEMNOTE){RS_MEMNOTE=true;S.mode='rsoffer';S.view='menu';
   show(`<div class="rsm"><h2>This window can't save</h2><p class="rsn">Your browser is blocking storage for the game here, so progress, gold and unfinished runs will be lost when this tab is refreshed or closed. This often happens in private windows, in some browsers' strict tracking protection, or when the game was opened in a separate tab from a website. Play the game on its main page to keep your progress.</p><div class="row"><button id="rsmc">Continue anyway</button></div></div>`,'m nosb');
   $('rsmc').onclick=()=>title();S.back=()=>{};return}
  if(RS_ASK&&rsRead()){rsOffer();return}
  return t0.apply(this,arguments)}}
setTimeout(()=>{if(RS_ASK&&rsRead()&&S.mode!=='rsoffer'&&S.mode!=='play')rsOffer()},600);
