/* ===== CELESTIAL CHEST: the art =====
   A midnight-navy chest banded in gold, a crescent moon on the lid, a four pointed star gem on the seam, violet crystals at the sides and
   a constellation on the front that lights up star by star. Drawn at (x,y) = bottom centre; s = scale; u = lid open 0..1.
   o = { lit: constellation stars lit (0..5), pw: glow power 0..1, gem: 1 = star gem on the seam, tc: accent colour, lid: lid angle in radians (hinged at the BACK edge), crL/crR: side crystal boost 0..1, lift: hop in units, lock: keyhole glow 0..1 } */
const CXC={nv0:'#262d68',nv1:'#0f1342',nv2:'#1a2058',au0:'#fff0b4',au1:'#e8c36a',au2:'#a8742c',au3:'#5a3a12',ink:'#070918'};
const CX_DOTS=[[-46,-39],[-23,-25],[0,-17],[23,-25],[46,-39]];
const cxDomeY=x=>-62-50*Math.pow(Math.max(0,1-(x/76)*(x/76)),.72);
/* a crescent opening toward +x */
function cxMoon(g,x,y,r,rot){g.save();g.translate(x,y);g.rotate(rot||0);const p=()=>{g.beginPath();g.arc(0,0,r,-.9,.9,true);g.arc(r*.38,0,r*.82,1.27,TAU-1.27,false);g.closePath()};
 p();g.fillStyle=vgr(g,-r,r,CXC.au0,CXC.au2);g.fill();g.strokeStyle=CXC.ink;g.lineWidth=2;g.lineJoin='round';g.stroke();p();g.save();g.clip();g.fillStyle='#fff6d066';g.fillRect(-r,-r,r*.9,r*.5);g.restore();g.restore()}
/* the four pointed star gem in its gold frame */
function cxGemStar(g,x,y,r,pw,t){pw=pw==null?1:pw;g.save();g.globalCompositeOperation='lighter';glow(g,x,y,r*3.4,'#7fe0ff'+hxA(.5*pw));g.restore();
 g.beginPath();g.moveTo(x,y-r*1.45);g.lineTo(x+r*1.2,y);g.lineTo(x,y+r*1.45);g.lineTo(x-r*1.2,y);g.closePath();g.fillStyle=vgr(g,y-r*1.4,y+r*1.4,CXC.au0,CXC.au2);g.fill();g.strokeStyle=CXC.ink;g.lineWidth=2.2;g.stroke();g.strokeStyle='#fff3c288';g.lineWidth=1;g.beginPath();g.moveTo(x-r*.9,y-r*.1);g.lineTo(x,y-r*1.1);g.lineTo(x+r*.9,y-r*.1);g.stroke();
 const sp=a=>{g.beginPath();for(let i=0;i<8;i++){const an=-Math.PI/2+i*Math.PI/4,rr=i%2?r*.3:r*1.0;g.lineTo(x+Math.cos(an)*rr*(i%2?1:1),y+Math.sin(an)*rr)}g.closePath()};sp();g.fillStyle=rgr(g,x-r*.2,y-r*.3,0,r*1.1,'#f2ffff','#2f9ee8');g.fill();g.strokeStyle='#0b3a78';g.lineWidth=1.3;g.stroke();
 g.fillStyle='#ffffffaa';g.beginPath();g.moveTo(x,y-r);g.lineTo(x+r*.3,y-r*.1);g.lineTo(x,y);g.closePath();g.fill();g.fillStyle='#1a68c055';g.beginPath();g.moveTo(x,y+r);g.lineTo(x-r*.3,y+r*.1);g.lineTo(x,y);g.closePath();g.fill()}
/* a violet crystal that glows from within */
function cxCrystal(g,x,y,w,h,t,ph,pw,bo){bo=bo||0;const p=.7+.3*Math.sin(t*2+ph);g.save();g.globalCompositeOperation='lighter';glow(g,x,y,h*.95,'#b07aff'+hxA(.4*p*(.6+.4*(pw==null?1:pw))));if(bo>0)glow(g,x,y,h*1.7,'#c9a0ff'+hxA(.55*bo));g.restore();
 g.beginPath();g.moveTo(x,y-h/2);g.lineTo(x+w/2,y);g.lineTo(x,y+h/2);g.lineTo(x-w/2,y);g.closePath();g.fillStyle=vgr(g,y-h/2,y+h/2,'#e2c6ff','#6a3ab8');g.fill();g.strokeStyle=CXC.ink;g.lineWidth=2;g.stroke();
 g.fillStyle='#ffffff77';g.beginPath();g.moveTo(x,y-h/2);g.lineTo(x+w/2,y);g.lineTo(x,y);g.closePath();g.fill();g.fillStyle='#3a1a7a66';g.beginPath();g.moveTo(x,y+h/2);g.lineTo(x-w/2,y);g.lineTo(x,y);g.closePath();g.fill();ell(g,x-w*.14,y-h*.18,w*.07,h*.09,'#fff');if(bo>0){g.fillStyle='#ffffff'+hxA(.4*bo);g.beginPath();g.moveTo(x,y-h/2);g.lineTo(x+w/2,y);g.lineTo(x,y+h/2);g.lineTo(x-w/2,y);g.closePath();g.fill()}}
function cxGold(g,x0,y0,x1,y1){const q=g.createLinearGradient(x0,y0,x1,y1);q.addColorStop(0,CXC.au0);q.addColorStop(.3,CXC.au1);q.addColorStop(.75,CXC.au2);q.addColorStop(1,CXC.au3);return q}

function cxChest(g,x,y,s,u,t,o){o=o||{};u=u||0;const k=.8*s,pw=o.pw==null?.55:o.pw,lit=o.lit==null?2.4+2.6*(.5+.5*Math.sin(t*1.1)):o.lit,gem=o.gem==null?1:o.gem,tc=o.tc||'#8ad8ff',hexA=hxA;
 const TH=o.lid!=null?o.lid:(u>0?(u<1?1-Math.pow(1-u,2.2):1)*1.72:0),opn=Math.min(1,TH/.55),lift=o.lift||0,lock=o.lock||0,bm=o.bm==null?1:o.bm;
 g.save();g.translate(x,y);g.scale(k,k);g.lineJoin='round';g.lineCap='round';
 /* the rune ring on the floor and a soft aura */
 g.save();g.globalCompositeOperation='lighter';glow(g,0,-58,175+pw*40,tc+hexA(.16+.14*pw));if(opn>0){const op=opn;glow(g,0,-70,230,tc+hexA(.34*op));glow(g,0,-78,110,'#bfeaff'+hexA(.2*op))}g.restore();
 ell(g,0,6,122,19,'#241552aa');g.save();g.setLineDash([11,8]);g.lineDashOffset=-t*10;g.strokeStyle='#a98aff88';g.lineWidth=1.8;g.beginPath();g.ellipse(0,6,122,19,0,0,TAU);g.stroke();g.restore();
 g.strokeStyle='#8a6aff44';g.lineWidth=1.2;g.beginPath();g.ellipse(0,6,98,14,0,0,TAU);g.stroke();
 g.translate(0,-lift);
 /* the far half of the orbit */
 const orb=(front)=>{g.save();g.translate(0,-60);g.rotate(-.1);g.strokeStyle=tc+hexA(front?.8:.4);g.lineWidth=front?2.2:1.6;g.shadowColor=tc;g.shadowBlur=front?9:4;g.beginPath();g.ellipse(0,0,132,38,0,front?0:Math.PI,front?Math.PI:TAU);g.stroke();g.shadowBlur=0;
  for(let i=0;i<2;i++){const a=t*1.15*(.6+pw*.9)+i*Math.PI+.6,sx=Math.cos(a)*132,sy=Math.sin(a)*38;if((sy>0)===front)cxStar(g,sx,sy,i?6:8.5,i?'#bfe8ff':'#8ad8ff',t,i*2)}g.restore()};
 orb(false);
 /* crystals */
 cxCrystal(g,-91,-36,17,42,t,0,pw,o.crL);cxCrystal(g,91,-36,17,42,t,2,pw,o.crR);
 /* body */
 g.beginPath();g.roundRect(-72,-62,144,62,6);g.fillStyle=vgr(g,-62,0,CXC.nv0,CXC.nv1);g.fill();g.strokeStyle=CXC.ink;g.lineWidth=2.8;g.stroke();
 g.save();g.beginPath();g.roundRect(-72,-62,144,62,6);g.clip();g.strokeStyle='#ffffff10';g.lineWidth=1;for(let i=1;i<4;i++){g.beginPath();g.moveTo(-72,-62+i*15.5);g.lineTo(72,-62+i*15.5);g.stroke()}
 g.fillStyle='#ffffff10';g.fillRect(-72,-62,144,5);g.restore();
 /* front panel with its constellation */
 g.beginPath();g.roundRect(-56,-51,112,39,5);g.fillStyle=vgr(g,-51,-12,'#0d1140','#171c58');g.fill();g.strokeStyle='#4a58b8aa';g.lineWidth=1.6;g.stroke();g.strokeStyle='#00000088';g.lineWidth=1;g.beginPath();g.roundRect(-58,-53,116,43,6);g.stroke();
 for(let i=0;i<4;i++){const a=Math.max(0,Math.min(1,lit-i-.5)),b=CX_DOTS[i],c=CX_DOTS[i+1];if(a<=0)continue;g.save();g.globalAlpha=a;g.strokeStyle='#9ae6ff';g.lineWidth=1.6;g.shadowColor='#6ad4ff';g.shadowBlur=7;g.beginPath();g.moveTo(b[0],b[1]);g.lineTo(c[0],c[1]);g.stroke();g.restore()}
 CX_DOTS.forEach((d,i)=>{const a=Math.max(0,Math.min(1,lit-i));g.save();g.globalCompositeOperation='lighter';if(a>0)glow(g,d[0],d[1],13,'#7fe0ff'+hexA(.55*a*(.8+.2*Math.sin(t*4+i))));g.restore();ell(g,d[0],d[1],3.1,3.1,a>0?'#d8f8ff':'#2a3478');g.strokeStyle=a>0?'#7fe0ff':'#4a58b8';g.lineWidth=1;g.beginPath();g.arc(d[0],d[1],3.1,0,TAU);g.stroke()});
 /* gold pillars and pyramid feet */
 for(const sd of[-1,1]){const X=v=>sd*v;
  g.beginPath();g.moveTo(X(60),-4);g.lineTo(X(92),-4);g.lineTo(X(86),-18);g.lineTo(X(66),-18);g.closePath();g.fillStyle=cxGold(g,X(60),-18,X(92),0);g.fill();g.strokeStyle=CXC.ink;g.lineWidth=2.4;g.stroke();
  g.beginPath();g.moveTo(X(60),-4);g.lineTo(X(92),-4);g.lineTo(X(96),6);g.lineTo(X(56),6);g.closePath();g.fillStyle=vgr(g,-4,6,CXC.au2,CXC.au3);g.fill();g.stroke();
  g.beginPath();g.moveTo(X(64),-16);g.lineTo(X(86),-16);g.lineTo(X(86),-64);g.lineTo(X(64),-64);g.closePath();g.fillStyle=cxGold(g,X(64),0,X(86),0);g.fill();g.stroke();
  g.fillStyle='#fff2c055';g.fillRect(Math.min(X(66),X(70)),-62,3,44);g.fillStyle='#00000030';g.fillRect(Math.min(X(82),X(86)),-62,4,44);
  g.beginPath();g.moveTo(X(62),-62);g.lineTo(X(88),-62);g.lineTo(X(82),-74);g.lineTo(X(68),-74);g.closePath();g.fillStyle=cxGold(g,0,-74,0,-62);g.fill();g.stroke()}
 /* the seam band with its socket */
 g.beginPath();g.roundRect(-82,-70,164,13,2);g.fillStyle=vgr(g,-70,-57,CXC.au0,CXC.au2);g.fill();g.strokeStyle=CXC.ink;g.lineWidth=2.4;g.stroke();g.fillStyle='#fff6d088';g.fillRect(-80,-69,160,2.4);
 /* the open mouth: a pool of cyan-violet light inside */
 if(opn>0){const op=opn;g.beginPath();g.ellipse(0,-67,67,Math.max(.1,6.5*op),0,0,TAU);g.fillStyle='#04041c';g.fill();g.save();g.beginPath();g.rect(-300,-500,600,438);g.clip();g.globalCompositeOperation='lighter';glow(g,0,-66,74*op,'#a8e4ff'+hexA(.46));glow(g,0,-70,46*op,'#c9a8ff'+hexA(.5));g.restore();
  g.save();g.beginPath();g.rect(-300,-500,600,438);g.clip();g.globalCompositeOperation='lighter';for(let i=0;i<9;i++){const a=-Math.PI/2+(i-4)*.17,L=(90+60*rnd(i+3)+Math.sin(t*3+i)*12)*opn*(.5+.5*bm);g.globalAlpha=.26*op*(.12+.88*bm);g.fillStyle=i%2?'#c9b0ff':'#bfeaff';g.beginPath();g.moveTo(Math.cos(a)*5,-66);g.lineTo(Math.cos(a)*5+Math.cos(a)*L-6,-66+Math.sin(a)*L);g.lineTo(Math.cos(a)*5+Math.cos(a)*L+6,-66+Math.sin(a)*L);g.closePath();g.fill()}g.restore()}
 /* the lid: a barrel-vaulted dome hinged on the BACK edge. It lifts, tips over the hinge and comes to rest standing behind the chest, never leaving it. */
 {const D=46,KP=.24,yh=-62-KP*D,sn=Math.sin(TH),cs=Math.cos(TH),Yf=-62-D*sn-KP*D*(1-cs),sv=Math.max(.02,cs+KP*sn);
  const arch=[];for(let i=0;i<=24;i++){const q=i/24,m=1-q;arch.push([m*m*m*-76+3*m*m*q*-76+3*m*q*q*-42,-(m*m*m*-62+3*m*m*q*-100+3*m*q*q*-112+q*q*q*-112+62)])}
  for(let i=23;i>=0;i--)arch.push([-arch[i][0],arch[i][1]]);
  const rear=arch.map(p=>[p[0],yh-p[1]*cs-KP*p[1]*sn]),front=arch.map(p=>[p[0],Yf-p[1]*sv]);
  const poly=()=>{g.beginPath();rear.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));for(let i=front.length-1;i>=0;i--)g.lineTo(front[i][0],front[i][1]);g.closePath()};
  const ex=sstep(0,.12,TH)*(1-sstep(.15,.45,TH)),inn=sstep(.15,.45,TH);
  if(ex>0){g.save();g.globalAlpha=ex;poly();g.fillStyle=vgr(g,-135,-62,CXC.nv0,CXC.nv1);g.fill();g.strokeStyle=CXC.ink;g.lineWidth=2.6;g.stroke();g.restore()}
  if(inn>0){g.save();g.globalAlpha=inn;poly();const yt=Math.min(Yf,yh)-52,yb=Math.max(Yf,yh);g.fillStyle=vgr(g,yt,yb,'#2c3a9a','#0b0f3a');g.fill();g.strokeStyle=CXC.ink;g.lineWidth=2.6;g.stroke();
   g.save();poly();g.clip();g.globalCompositeOperation='lighter';glow(g,0,yh+6,120,tc+hexA(.32*opn*(.5+.5*pw)));g.globalCompositeOperation='source-over';g.strokeStyle='#d8b86a99';g.lineWidth=2;for(const ix of[-34,0,34]){const k0=arch.findIndex(p=>p[0]>=ix-.1);const pr=rear[k0],pf=front[k0];g.beginPath();g.moveTo(pr[0],pr[1]);g.lineTo(pf[0],pf[1]);g.stroke()}g.restore();g.restore()}
  const ha=sstep(.04,.3,TH);if(ha>0){g.save();g.globalAlpha=ha;for(const hx of[-56,56]){g.beginPath();g.roundRect(hx-11,yh-9,22,13,3);g.fillStyle=cxGold(g,hx,yh-9,hx,yh+4);g.fill();g.strokeStyle=CXC.ink;g.lineWidth=2;g.stroke()}g.restore()}
  g.save();g.translate(0,Yf);g.scale(1,sv);g.translate(0,62);
  g.beginPath();g.moveTo(-76,-62);g.bezierCurveTo(-76,-100,-42,-112,0,-112);g.bezierCurveTo(42,-112,76,-100,76,-62);g.closePath();g.fillStyle=vgr(g,-112,-62,CXC.nv0,CXC.nv1);g.fill();g.strokeStyle=CXC.ink;g.lineWidth=2.8;g.stroke();
  g.save();g.clip();g.strokeStyle='#080a2488';g.lineWidth=1.6;for(const sx of[-34,34]){g.beginPath();g.moveTo(sx,-62);g.lineTo(sx,cxDomeY(sx)+2);g.stroke()}
  g.strokeStyle='#8e98e866';g.lineWidth=2.4;g.beginPath();for(let xx=-66;xx<=0;xx+=6)g.lineTo(xx,cxDomeY(xx)+7);g.stroke();
  g.fillStyle='#00000030';g.fillRect(-80,-76,160,14);g.restore();
  g.save();g.beginPath();g.moveTo(-76,-62);g.bezierCurveTo(-76,-100,-42,-112,0,-112);g.bezierCurveTo(42,-112,76,-100,76,-62);g.closePath();g.clip();
  for(const sd of[-1,1]){g.save();g.beginPath();g.rect(sd>0?44:-200,-200,156,200);g.clip();g.beginPath();g.moveTo(-76,-62);g.bezierCurveTo(-76,-100,-42,-112,0,-112);g.bezierCurveTo(42,-112,76,-100,76,-62);g.strokeStyle=CXC.ink;g.lineWidth=27;g.stroke();g.strokeStyle=cxGold(g,sd*44,-112,sd*76,-62);g.lineWidth=22;g.stroke();g.strokeStyle='#fff4c8aa';g.lineWidth=3;g.save();g.translate(0,7);g.stroke();g.restore();g.restore()}
  g.restore();
  g.beginPath();g.moveTo(-76,-62);g.bezierCurveTo(-76,-100,-42,-112,0,-112);g.bezierCurveTo(42,-112,76,-100,76,-62);g.strokeStyle=CXC.ink;g.lineWidth=2.8;g.stroke();
  cxMoon(g,0,-93,17,-.35);g.restore()}
 /* the star gem on the seam: gone when the star key has flown away, leaving a keyhole */
 if(gem>0){g.save();g.globalAlpha=Math.min(1,gem);cxGemStar(g,0,-62,13,pw,t);g.restore()}
 if(gem<1){g.save();g.globalAlpha=1-gem;g.beginPath();g.moveTo(-5,-66);g.lineTo(5,-66);g.lineTo(3,-52);g.lineTo(-3,-52);g.closePath();g.fillStyle='#04041a';g.fill();g.strokeStyle=CXC.au1;g.lineWidth=1.6;g.stroke();g.beginPath();g.arc(0,-66,5,0,TAU);g.fill();g.stroke();g.restore()}
 if(lock>0){g.save();g.globalCompositeOperation='lighter';glow(g,0,-60,30+20*lock,'#8ee8ff'+hexA(.8*lock));glow(g,0,-60,11,'#ffffff'+hexA(.9*lock));g.restore()}
 orb(true);
 g.restore()}

/* the Celestial Chest takes the 'c' slot wherever the game draws a crate */
{const c0=chest;chest=function(g,x,y,s,u,k,t){if(k==='c')return cxChest(g,x,y,s,u,t);return c0(g,x,y,s,u,k,t)}}
