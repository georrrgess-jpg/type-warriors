# python3 t_ramparts.py : Runestone Ramparts (95a-95g) - rules, abilities, waves, rewards, menus and hooks, plus a bot that plays every map
# to check the balance (an average player should win map 1 comfortably, and maps 2 and 3 with a sensible build).
import asyncio,os,sys
from playwright.async_api import async_playwright
QUICK='--quick' in sys.argv
BOT=r"""
window.rpBot=function(id,wpm,opt){opt=opt||{};rpStart(id);const R=RPX;R.spd=2;let wordT=0;const order=opt.order||['ballista','brazier','frost','bell'];let bi=0,steps=0;
 const G=R.G;const cov=p=>{let n=0;for(let j=0;j<G.S.length;j+=3){const q=G.S[j];if((q.x-p.x)**2+(q.y-p.y)**2<200*200)n++}return n};
 const pads=[...R.pads].sort((a,b)=>cov(b)-cov(a));
 const act=()=>{for(let k=0;k<6;k++){const free=pads.find(p=>!p.tw);const t=order[bi%order.length];
   if(free&&R.supply>=rpCost(t,1)&&(!opt.maxT||R.pads.filter(p=>p.tw).length<opt.maxT)){rpBuild(free,t);bi++;continue}
   if(!free||opt.up){const tw=R.pads.filter(p=>p.tw&&p.tw.tier<3).map(p=>p.tw).sort((a,b)=>a.tier-b.tier)[0];if(tw&&R.supply>=rpCost(tw.type,tw.tier+1)+(free?rpCost(order[bi%order.length],1):0)){rpUpgrade(tw);continue}}
   break}R.sel=null};
 while(!R.over&&steps<60*60*40){steps++;
  if(R.wst==='build'){act();rpWaveStart()}
  if(R.wst==='done'){if(!R.over){rpFinish(R.won)}break}
  wordT+=1/30;const per=(R.word.length+1)/(wpm*5/60);if(wpm>0&&wordT>=per){wordT=0;for(const c of R.word.slice(R.wi))rpKey(c)}
  if(R.cmd>=100&&!opt.noAbil){if(R.keep<=15&&!R.repairUsed&&R.keep<20)rpAbility('repair',true);else if(R.foes.filter(e=>!e.dead).length>8)rpAbility('slow',true);else if(R.wst==='run')rpAbility('over',true)}
  if(R.wst==='run'&&steps%30===0)act();
  rpUpdate(1/30)}
 return{id,won:!!R.won,keep:R.keep,wave:R.wave,stars:R.result?R.result.stars:0,kills:R.kills,leaked:R.leaked,towers:R.pads.filter(p=>p.tw).map(p=>p.tw.type.slice(0,2)+p.tw.tier).join(' '),time:Math.round(R.time),pay:R.result?R.result.total:0}};
"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        pg.on('console',lambda m:er.append('CE '+m.text[:300]) if m.type=='error' and 'ERR_' not in m.text else None)
        await pg.goto('file://'+os.path.abspath('out.html'));await pg.wait_for_timeout(1200);E=pg.evaluate;bad=0
        def chk(n,v,ok):
            nonlocal bad
            if not ok:bad+=1
            print(n,v,'OK' if ok else 'BAD')
        await E("()=>{RS_ASK=false;P.gold=1000;delete P.rp;save();title()}");await pg.wait_for_timeout(400)
        await E("()=>{"+BOT+"}")
        # menus and hooks
        r=await E("async()=>{const sl=ms=>new Promise(r=>setTimeout(r,ms));title();await sl(400);const card=!!document.querySelector('#dkrp');modeSheet();await sl(400);const ms=!!document.querySelector('#dmrp');dkClose(true);await sl(200);"
          "title();await sl(300);document.dispatchEvent(new KeyboardEvent('keydown',{key:'u'}));window.dispatchEvent(new KeyboardEvent('keydown',{key:'u'}));await sl(500);const hub=!!document.querySelector('.rphub');"
          "return [card,ms,hub,ov.querySelectorAll('.rpmc').length,ov.querySelectorAll('.rpmc.lock').length,ov.querySelectorAll('.rpsk.lock').length]}")
        chk('home card, Choose-mode card, U key opens the hub; map 2 and 3 locked, skins locked',r,r[:3]==[True,True,True] and r[3]==3 and r[4]==2 and r[5]==5)
        # rules
        r=await E("()=>{rpStart('moss');const R=RPX;const s0=R.supply,p=R.pads[0];const ok=rpBuild(p,'ballista');const s1=R.supply;const up=rpUpgrade(p.tw);const s2=R.supply;const spent=p.tw.spent;rpSell(p.tw);return [ok,s0-s1,s1-s2,R.supply-s2,Math.round(spent*.7),!p.tw]}")
        chk('build costs 100, upgrade 150, selling refunds 70% of what was spent',r,r[0] and r[1]==100 and r[2]==150 and r[3]==r[4] and r[5])
        r=await E("()=>{const R=RPX;R.supply=50;const ok=rpBuild(R.pads[1],'frost');return [ok,R.supply,!!R.pads[1].tw]}")
        chk('cannot build without supply',r,r==[False,50,False])
        r=await E("()=>{const R=RPX;const w=R.word,c0=R.cmd,s0=R.supply;for(const c of w)rpKey(c);return [R.words,R.cmd>c0,R.supply-s0,R.word!==w||R.word.length>0]}")
        chk('typing the word adds Command and +2 supply and brings a new word',r,r[0]==1 and r[1] and r[2]==2)
        r=await E("()=>{const R=RPX;const c=R.cmd,cb=R.combo;rpKey(R.word[R.wi]==='q'?'z':'q');return [R.cmd===c,R.combo,R.bad]}")
        chk('a wrong key resets the streak but costs no Command',r,r[0] and r[1]==0 and r[2]==1)
        r=await E("()=>{const R=RPX;R.cmd=50;const a=rpAbility('repair',true);R.cmd=100;R.keep=12;const b=rpAbility('repair',true);const k1=R.keep;R.cmd=100;const c=rpAbility('repair',true);return [a,b,k1,c,R.cmd]}")
        chk('Repair needs a full meter, heals 4 and works once per wave',r,r==[False,True,16,False,100])
        r=await E("()=>{const R=RPX;R.supply=500;rpBuild(R.pads[2],'ballista');const tw=R.pads[2].tw;R.sel=tw;R.cmd=100;const a=rpAbility('over');R.cmd=100;R.sel=null;const b=rpAbility('slow',true);return [a,tw.over>0,b]}")
        chk('Overcharge powers the selected tower; Slow Field needs foes to auto-place',r,r[0] and r[1] and r[2]==False)
        r=await E("()=>{const R=RPX;R.cmd=100;const ok=rpAbility('slow',{x:R.G.S[200].x,y:R.G.S[200].y});return [ok,R.fields.length,R.cmd]}")
        chk('Slow Field placed on the road',r,r==[True,1,0])
        r=await E("()=>{const R=RPX;rpWaveStart();for(let i=0;i<60*5;i++)rpUpdate(1/60);return [R.wave,R.wst,R.foes.length>0]}")
        chk('wave 1 starts and spawns monsters',r,r[0]==1 and r[1]=='run' and r[2])
        r=await E("()=>{const R=RPX;R.pads.forEach(p=>{if(p.tw)p.tw.cd=99});const k0=R.keep;for(let i=0;i<60*40;i++)rpUpdate(1/60);return [k0-R.keep,R.leaked,R.wst]}")
        chk('monsters that reach the keep cost keep health',r,r[0]>0 and r[1]>0)
        r=await E("()=>{const R=RPX;R.keep=1;const e=rpSpawn('golem');e.s=R.G.len-1;for(let i=0;i<60*4;i++)rpUpdate(1/60);return [R.keep,R.wst,!!R.banner]}")
        chk('the keep falls at 0 and the run ends',r,r[0]==0 and r[1]=='done')
        await pg.wait_for_timeout(2800)
        r=await E("()=>{const r=RPX&&RPX.result;return r?[r.won,r.stars,r.total>0,!!document.querySelector('.rpres'),RPP().runs]:null}")
        chk('a loss pays a part, gives no stars and shows the result',r,r is not None and r[0]==False and r[1]==0 and r[3])
        r=await E("()=>{rpLeave();title();return [S.rp,RPX===null,S.mode,$('rphud')?$('rphud').hidden:true]}")
        chk('leaving clears the run and the HUD',r,r==[0,True,'title',True])
        # rewards
        r=await E("()=>{const g0=P.gold;rpStart('moss');const R=RPX;R.wave=10;R.keep=19;rpVictory();R.winKeep=19;rpFinish(true);const r=R.result;return [r.won,r.stars,r.first,P.gold-g0===r.total,RPP().stars.moss,RP_MAPOPEN(RP_MAPS[1])]}")
        chk('victory at keep 19 gives 3 stars, the first-win bonus, opens map 2',r,r==[True,3,True,True,3,True])
        r=await E("()=>{const g0=P.gold;rpLeave();rpStart('moss');const R=RPX;R.wave=10;R.keep=9;rpVictory();R.winKeep=9;rpFinish(true);return [R.result.stars,R.result.first,RPP().stars.moss,R.result.unl.map(s=>s.k)]}")
        chk('a second win the same day: 1 star does not lower the best, no daily bonus',r,r[0]==1 and r[1]==False and r[2]==3)
        r=await E("()=>{const r=RPP();r.stars={moss:3,frost:3,ember:3};const u=rpUnlockSweep();let t=false;try{t=rpStarN()>=RP_TITLE_NEED}catch(e){}return [u.map(s=>s.k),t,rpSkinOf('ballista')]}")
        r2=await E("()=>RP_SKINS.every(s=>RPP().own[s.tw+':'+s.k])")
        chk('stars unlock the four tower skins (only here) and reach the title',[r,r2],r2 and 'thunderking' in r[0] and r[1])
        r=await E("()=>{const r=RPP();r.skin.ballista='gilded';save();const a=rpSkinOf('ballista');r.own['ballista:gilded']=0;const b=rpSkinOf('ballista');r.own['ballista:gilded']=1;return [a,b]}")
        chk('equipped skin needs ownership',r,r==['gilded','base'])
        r=await E("()=>{rpLeave();rpStart('moss');const R=RPX;R.wave=10;R.keep=20;rpVictory();R.winKeep=20;rpFreeplay();R.supply=99999;R.spd=2;for(const p of R.pads)if(!p.tw)rpBuild(p,'ballista');for(const p of R.pads){rpUpgrade(p.tw);rpUpgrade(p.tw)}for(let i=0;i<30*60*8;i++){if(R.wst==='build')rpWaveStart();rpUpdate(1/30);if(R.fpWaves>=2)break}const fp=R.fpCoins;R.keep=0;rpDefeat();rpFinish(false);return [R.free,R.fpWaves>=2,fp>0,R.result.won,R.result.fp===fp,R.result.stars]}")
        chk('freeplay after a win banks coins per wave and keeps the win',r,r[0] and r[1] and r[2] and r[3] and r[4] and r[5]==3)
        # pause
        r=await E("async()=>{rpLeave();rpStart('moss');const R=RPX;rpPause(true);const a=R.pause,b=!!document.querySelector('.rppause');const t0=R.t;rpUpdate(1/60);const c=R.t===t0;rpPause(false);await new Promise(r=>setTimeout(r,100));return [a,b,c,R.pause,$('rphud').hidden]}")
        chk('pause stops time and shows the menu; resume restores the HUD',r,r==[True,True,True,False,False])
        await pg.screenshot(path='shots/rp_run.png') if os.path.isdir('shots') else None
        r=await E("()=>{const r=RPP();P.rp={stars:{moss:9},skin:'x',own:5};const q=RPP();return [q.stars.moss===undefined,typeof q.skin,typeof q.own]}")
        chk('save normaliser drops bad values',r,r==[True,'object','object'])
        # balance: a bot at 35 WPM with a mixed build
        await E("()=>{rpLeave();delete P.rp;RPP()}")
        maps=['moss'] if QUICK else ['moss','frost','ember']
        for m in maps:
            r=await E(f"()=>rpBot('{m}',35,{{up:1}})")
            chk(f'bot 35 WPM wins {m}',r,r['won'])
        r=await E("()=>rpBot('moss',0,{noAbil:1,order:['ballista']})")
        chk('even a bot that only builds ballistas and never types wins map 1 (easy start)',r,r['won'])
        if not QUICK:
            r=await E("()=>rpBot('ember',0,{noAbil:1,order:['ballista'],maxT:4})")
            chk('four untyped ballistas are not enough for map 3 (it still needs thought)',r,not r['won'])
        print('bad',bad);print(er[:6]);await b.close()
asyncio.run(main())
