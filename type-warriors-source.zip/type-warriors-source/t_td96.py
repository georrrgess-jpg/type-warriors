# python3 t_td96.py [game.html] : Runestone Tower Defense 9.6 (95q) - the Tidecaller balanced (sweep fatigue, groups keep their
# spacing), the shaman-pile glitch (waves that never ended), one shaman heal per pulse, the boss bar with two bosses, Freeplay
# oozelets, and wave/health invariants over real waves.
import asyncio,os,sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:500]),flush=True)
    if not ok:FAIL.append(name)
HELP=r"""()=>{
 window.tdPadAt=(R,x,y)=>R.pads.reduce((a,p)=>Math.hypot(p.x-x,p.y-y)<Math.hypot(a.x-x,a.y-y)?p:a,R.pads[0]);
 window.tdBuild=(R,p,t,tier)=>{rpBuild(p,t);const tw=p.tw;tw.build=1;while(tw.tier<tier)rpUpgrade(tw);tw.upK=1;return tw};
 window.tdNear=(R,p)=>{let best=0,bd=1e9,bp=0;R.G.paths.forEach((P2,pi)=>{for(let s=0;s<P2.len;s+=4){const q=rpAt(R.G,s,pi);const d=Math.hypot(q.x-p.x,(q.y-p.y)/.75);if(d<bd){bd=d;best=s;bp=pi}}});return [best,bp]};
 window.tdNew=(map,wave)=>{try{rpLeave()}catch(e){}rpStart(map);const R=RPX;R.tut=null;R.hold=false;R.supply=1e9;R.wst='run';R.wave=wave;R.q=[];R.banner=null;return R};
 /* a real wave with invariant checks every step */
 window.tdPlay=(R,wave,T)=>{R.wave=wave-1;R.wst='build';R.cd=0;rpWaveStart();const an={nan:0,over:0,neg:0,heal:0,t:0,maxHeal:0};
  while(an.t<T&&R.wst==='run'){const b=new Map();for(const e of R.foes)b.set(e,e.hp);rpStep(R,1/30);an.t+=1/30;
   for(const e of R.foes){if(e.dead)continue;if(!isFinite(e.hp)||!isFinite(e.s)||!isFinite(e.mx))an.nan++;if(e.hp>e.mx+1e-6)an.over++;if(e.hp<=0)an.neg++;const h=b.get(e);if(h!=null&&e.hp>h){an.heal+=e.hp-h;an.maxHeal=Math.max(an.maxHeal,(e.hp-h)/e.mx)}}
   if(!(R.hp>=0&&R.hp<=RPT.HP&&R.hp===Math.round(R.hp)))an.nan++}
  an.wst=R.wst;an.left=R.foes.filter(e=>!e.dead).length+R.q.length;an.t=Math.round(an.t);an.heal=Math.round(an.heal);an.maxHeal=+an.maxHeal.toFixed(3);return an};
 return 1}"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E("()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const T=RPP().tut;for(const k of['build','wave','coins','upgrade','abil','twist_frost','twist_ember','twist_wonder'])T[k]=1;RPP().stars.ember=1;RPP().dragon=1}")
        await E(HELP)
        # ---------------------------------------------------------------- balance numbers
        r=await E("()=>{const T=RP_TW.tide;return [T.cost,T.knock,T.dmg,T.cd,typeof RPTB!=='undefined'?[RPTB.fat,RPTB.half,RPTB.bossCap]:null]}")
        chk('Tidecaller numbers: cost 150/190/320/650/1050, sweep 100-180 px, damage and fire rate unchanged; sweep fatigue x0.5 per sweep, 8 s half-life',
            r==[[150,190,320,650,1050],[100,120,140,160,180],[34,56,92,150,230],[2.5,2.3,2.1,1.95,1.8],[0.5,8,30]],r)
        # ---------------------------------------------------------------- the glitch: a sweep must not collapse a group into one pile
        r=await E("""()=>{const R=tdNew('moss',4),p=[...R.pads].sort((a,b)=>a.x-b.x)[4],tw=tdBuild(R,p,'tide',1);const [s0,pi]=tdNear(R,p);
          const F=[];for(let k=0;k<6;k++){const e=rpSpawn('bulwark',pi);e.s=s0+k*16;e.sp=0;e.hp=e.mx=1e7;F.push(e)}const sp0=F[5].s-F[0].s,b0=F.map(e=>e.s);tw.cd=0;
          for(let i=0;i<30*2.4;i++)rpStep(R,1/30);const sp1=Math.max(...F.map(e=>e.s))-Math.min(...F.map(e=>e.s));const back=Math.min(...F.map((e,i)=>b0[i]-e.s));return [Math.round(sp0),Math.round(sp1),Math.round(back)]}""")
        chk('a Tidecaller wave knocks every monster back by its own distance: the group keeps its spacing (it used to collapse into one pile)',r[1]>=r[0]*.7 and r[2]>=40,r)
        r=await E("""()=>{const R=tdNew('ember',8),at=[[270,530,'tide',3],[930,440,'ballista',3],[1080,320,'ballista',3],[1090,530,'tide',3]];
          for(const [x,y,t,k] of at)tdBuild(R,tdPadAt(R,x,y),t,k);const a=tdPlay(R,8,240);return [a.wst,a.left,a.t,a.nan,a.over,a.maxHeal]}""")
        chk('Ember Crown wave 8 (only shamans and flyers) with a Tidecaller at the road start ends: the shaman pile no longer heals itself forever',r[0]=='build' and r[1]==0 and r[2]<200 and r[3]==0 and r[4]==0,r)
        # ---------------------------------------------------------------- no shaman pile: a sweep keeps a shaman group spread out
        r=await E("""()=>{const R=tdNew('ember',8),[s0,pi]=tdNear(R,{x:270,y:530});tdBuild(R,tdPadAt(R,270,530),'tide',3);const S=[];for(let k=0;k<6;k++){const e=rpSpawn('shaman',pi);e.s=s0-60+k*24;e.sp=50;e.hp=e.mx=1e7;S.push(e)}
          let pile=0,heal=0,big=0;for(let i=0;i<30*20;i++){const h=S.map(e=>e.hp);for(const e of S)e.hp=Math.min(e.hp,e.mx*.5);rpStep(R,1/30);S.forEach((e,j)=>{if(e.hp>e.mx*.5)heal+=(e.hp-e.mx*.5)/e.mx});
           const ss=S.map(e=>e.s).sort((a,b)=>a-b);for(let j=0;j<ss.length;j++){let n=0;for(let k=j;k<ss.length&&ss[k]-ss[j]<8;k++)n++;pile=Math.max(pile,n)}if(pile>=4)big++;pile=0}return [+(big/600).toFixed(2),+heal.toFixed(2)]}""")
        chk('six shamans under a Tidecaller do not collapse into a lasting pile (4+ within 8 px less than a fifth of the time; it used to be 94% of it)',r[0]<0.2,r)
        # ---------------------------------------------------------------- diminishing returns: stacked shrines cannot hold a monster forever
        r=await E("""()=>{const R=tdNew('moss',6);const [s0,pi]=tdNear(R,{x:700,y:560});const pads=[...R.pads].sort((a,b)=>{const q=rpAt(R.G,s0,pi);return Math.hypot(a.x-q.x,a.y-q.y)-Math.hypot(b.x-q.x,b.y-q.y)}).slice(0,4);
          for(const p of pads)tdBuild(R,p,'tide',3);const e=rpSpawn('shaman',pi);e.s=s0-260;e.hp=e.mx=1e9;e.heal=0;const st=e.s;const K=[],hk=typeof rptKnock==='function',k0=hk?rptKnock:null;if(hk)rptKnock=function(f,d){if(f===e)K.push(Math.round(d));return k0.apply(this,arguments)};
          let t=0;while(t<40&&!e.dead&&e.s<rpLen(R,e)){rpStep(R,1/30);t+=1/30}if(hk)rptKnock=k0;return [Math.round(e.s-st),K.length,K.slice(0,6),Math.round(t)]}""")
        chk('four tier-3 Tidecallers on one slow monster: each sweep pushes it less (x0.5) and it still walks on (no permanent stun-lock)',
            r[0]>500 and r[1]>=3 and len(r[2])>=3 and r[2][0]>=100 and r[2][2]<=r[2][0]*.5,r)
        # ---------------------------------------------------------------- the boss bar with two bosses
        r=await E("""()=>{const R=tdNew('wonder',30);const a=rpSpawn('behemoth',0);a.s=100;const b2=rpSpawn('behemoth',0);b2.s=60;const first=R.boss;rpKillFoe(R.boss,null);rpStep(R,1/30);
          const ok1=R.boss&&!R.boss.dead&&R.boss!==first;if(R.boss)rpKillFoe(R.boss,null);rpStep(R,1/30);return [!!ok1,R.boss]}""")
        chk('two bosses on the road: when one falls the boss bar follows the other; when both fall it hides',r==[True,None],r)
        # ---------------------------------------------------------------- Freeplay oozelets
        r=await E("""()=>{const R=tdNew('moss',20);R.free=true;R.won=true;const e=rpSpawn('ooze',0);e.s=200;const n0=R.foes.length;rpKillFoe(e,null);const c=R.foes.slice(n0);
          const want=Math.round(RP_FOE.oozelet.hp*rpHpK(R.map,R.wave)*(1+.05*(R.wave-R.map.waves)));return [c.length,c.map(x=>x.mx),want,c.every(x=>x.hp===x.mx)]}""")
        chk('Freeplay oozelets carry the Freeplay hit-point bonus like every other Freeplay monster',r[0]==2 and all(abs(m-r[2])<=1 for m in r[1]) and r[3],r)
        # ---------------------------------------------------------------- wave and health invariants over real waves
        out=[]
        for m,w,build in [('moss',9,[['tide',3],['tide',3],['tide',3]]),('frost',8,[['tide',2],['ballista',3],['tide',2],['bell',3]]),('wonder',27,[['tide',5],['tide',5],['tide',5],['tide',5]]),('wonder',31,[['tide',5],['dragon',5],['bell',5],['frost',5]])]:
            r=await E("""([m,w,build])=>{const R=tdNew(m,w);const cov=p=>{let n=0;for(const q of R.G.U){if((q.x-p.x)**2+((q.y-p.y)/.75)**2<210*210)n++}return n};const pads=[...R.pads].sort((a,b)=>cov(b)-cov(a));
              build.forEach((b,i)=>tdBuild(R,pads[i],b[0],b[1]));const a=tdPlay(R,w,400);a.hp=R.hp;return a}""",[m,w,build]);out.append(r)
            chk(f'{m} wave {w} with {"+".join(x[0]+str(x[1]) for x in build)}: the wave ends, no NaN, hit points never above max or stuck at 0, castle health whole and in range',
                r['wst'] in('build','done') and r['left']==0 and r['nan']==0 and r['over']==0 and r['neg']==0 and r['t']<300,r)
        r=await E("""()=>{const R=tdNew('moss',3);R.hp=3;const g=rpSpawn('golem',0);g.s=rpLen(R,g)-1;rpStep(R,1/30);const a=[R.hp,R.wst];const g2=rpSpawn('golem',0);g2.s=rpLen(R,g2)-1;rpStep(R,1/30);
          const R2=tdNew('moss',3);R2.hp=18;R2.abCd.repair=0;rpAbility('repair',true);const b=R2.hp;R2.abCd.repair=0;const again=rpAbility('repair',true);return [a,R.hp,b,again,R2.hp]}""")
        chk('castle health: a leak takes it to 0 (never below) and ends the run once; Repair heals up to 20 and not past it',r==[[0,'done'],0,20,False,20],r)
        chk('no page errors',not er,er)
        await b.close()
    print(f'{N[0]-len(FAIL)} / {N[0]} passed');sys.exit(1 if FAIL else 0)
asyncio.run(main())
