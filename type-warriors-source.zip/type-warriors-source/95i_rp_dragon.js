/* ===== RUNESTONE TOWER DEFENSE 9.0: the Clockwork Dragon Roost in battle (95i, after 95h2; art in 95c4) =====
   The sixth tower, unlocked by winning Ember Crown (the third map) and then usable on every map. Every few seconds the dragon
   turns to its target and breathes a sweeping cone of fire that burns every monster it crosses, flyers included. Tier 3 leaves
   burning ground; tier 4 (Wonderland) splits the breath into twin streams; tier 5 adds the wing dive: every fourth attack the
   dragon leaves its roost, swoops low along the road in a trail of fire and returns. Any tier can be wound up (C, or the panel's
   Wind up button): the gears spin and the next breath comes at once, then the crank needs RPD_CRANK seconds to reset.
   State on the tower: br/brD (breath time left/total), a0/a1 (sweep angles), face (-1..1, eased), nb (breaths since a dive),
   dive {t,d,pts,trail}, ck (crank flash), ckCd (crank cooldown). The HUD gains a sixth card (key Y) and a sixth ring button.
   9.1 rework (the dragon twitched and missed): a state machine st 'idle' -> 'wind' (a short inhale: the neck pulls back, the jaw parts,
   the chest glows) -> 'breath' (the stream locks onto its target tg, aimed at where it will be, and follows it at most RPD_TURN rad/s;
   a dead target hands over to the next one; no target left ends the breath and returns part of the cooldown). The dragon turns
   (fs, eased into face) only between breaths and only when the target is clearly on the other side (a dead zone), so it never
   flips back and forth. Head, jaw, neck and wings are springs (tw.an) shared by the drawing and the mouth position, so the fire
   always leaves the mouth. Hits are tested against the same arc the stream is drawn on (rpdCtl), widening from the mouth. */
RP_TW.dragon={cost:[500,550,850,1500,2500],range:[225,240,260,280,300],dps:[270,370,520,800,1180],beams:[1,1,1,2,2],cd:[1.6,1.5,1.4,1.3,1.2],dur:[2.2,2.4,2.6,2.8,3],wind:.4,
 burn:[0,0,26,40,60],dive:[0,0,0,0,1500],diveN:3,ap:[6,8,10,99,99],air:1,ground:1,
 desc:'A clockwork dragon breathes sweeping fire that burns every monster it crosses, flyers too.',
 up:['Bigger dragon: longer, hotter breath.','Crowned wyrm: its fire leaves the ground burning.','Mythic dragon: twin streams of violet fire, each locked on its own target.','Celestial dragon: every fourth attack it dives from the roost in a trail of fire.']};
RP_TWORDER.push('dragon');RP_KEYS.push('Y');
const RPD_CRANK=20,RPD_TURN=6.5;
let RPDTW=null;
const rpDragonOpen=()=>{try{const r=RPP();return (r.stars.ember||0)>0||r.dragon===1}catch(e){return false}};
const rpLockedTw=t=>t==='dragon'&&!rpDragonOpen();
function rpSfxRoar(){try{beep(150,.16,'sawtooth',.16);setTimeout(()=>beep(104,.32,'sawtooth',.14),80);setTimeout(()=>beep(70,.36,'triangle',.18),160)}catch(e){}}
/* building: locked until Ember Crown is won */
{const b0=rpBuild;rpBuild=function(pad,type){if(rpLockedTw(type)){rpSfx('no');rpToast('Win Ember Crown to unlock the Dragon Roost',1.8,'#ffb04a');return false}return b0.apply(this,arguments)}}
{const p0=rpPlace;rpPlace=function(type){if(rpLockedTw(type)){rpSfx('no');rpToast('Win Ember Crown to unlock the Dragon Roost',1.8,'#ffb04a');return}return p0.apply(this,arguments)}}
/* ---------- the breath ---------- */
const rpAngD=(a,b)=>{let d=a-b;while(d>Math.PI)d-=TAU;while(d<-Math.PI)d+=TAU;return d};
/* the pose the dragon is drawn with (shared by rpTowerDraw and the mouth, so the stream always leaves the mouth) */
function rpdO(tw){const A=tw.an||{};return{face:tw.face==null?1:tw.face,la:A.la,jaw:A.jaw||0,neck:A.nk||0,flare:A.fl||0,puff:A.puff||0,charge:tw.charge||0,ph:tw.ph,away:tw.dive?1:0,crank:tw.ck||0}}
function rpDMouthW(tw,t){const m=rpDragonMouth(tw.tier,Object.assign(rpdO(tw),{t}));return{x:tw.x+m.x,y:tw.y+m.y}}
const rpdOk=(R,tw,e,rg)=>{if(!e||e.dead||e.s<0)return false;const q=rpPos(R,e);return rpD2(q.x,q.y,tw.x,tw.y)<=rg*rg};
/* near = {m,a}: in a breath, hand over to the monster closest to where the fire already points (a short swing) */
function rpdPick(R,tw,rg,not,side,near){let best=null,bv=-1e9;const r2=rg*rg;
 for(const e of R.foes){if(e.dead||e.s<0||e===not)continue;const q=rpPos(R,e),d2=rpD2(q.x,q.y,tw.x,tw.y);if(d2>r2)continue;if(side&&side*(q.x-tw.x)<-24)continue;
  let v=near?-Math.abs(rpAngD(Math.atan2(q.y-(e.air?40:18)-near.m.y,q.x-near.m.x),near.a)):tw.prio==='strong'?e.hp:tw.prio==='close'?-d2:e.s/rpLen(R,e);if(v>bv){bv=v;best=e}}return best}
/* where a monster's body will be in k seconds (the point the fire aims at) */
function rpdLead(R,e,k){const sp=e.stun>0?0:e.sp*(e.slowT>0?1-e.slowK:1),p=rpAt(R.G,Math.min(rpLen(R,e),e.s+sp*k),e.pi),o=e.off||0;return{x:p.x-Math.sin(p.a)*o,y:p.y+Math.cos(p.a)*o-(e.air?40:18)}}
/* springs for the head angle, jaw, neck and wings */
function rpdSpr(A,k,v,tg,K,dt){const c=2*Math.sqrt(K)*.92;A[v]+=((tg-A[k])*K-A[v]*c)*dt;A[k]+=A[v]*dt}
function rpdAnim(tw,A,dt,T){rpdSpr(A,'la','lav',T.la,T.br?260:110,dt);rpdSpr(A,'jaw','jv',T.jaw,T.jaw>A.jaw?220:420,dt);rpdSpr(A,'nk','nkv',T.nk,150,dt);rpdSpr(A,'fl','flv',T.fl,90,dt);
 A.jaw=rpClamp(A.jaw,-.05,1.15);A.puff=Math.max(0,(A.puff||0)-dt*1.4)}
/* burn every monster whose body is inside the stream: the same arc as the drawing, widening from the mouth */
function rpdBurn(R,tw,T,i,dt,m,E,k){const over=tw.over>0?1.3:1,dmg=T.dps[i]*over*dt*k,[cx,cy]=rpdCtl(m.x,m.y,E.x,E.y),pts=[];let hit=0;
 for(let j=0;j<=10;j++){const u=j/10,a=1-u;pts.push(a*a*m.x+2*a*u*cx+u*u*E.x,a*a*m.y+2*a*u*cy+u*u*E.y)}
 const x0=Math.min(m.x,E.x)-60,x1=Math.max(m.x,E.x)+60,y0=Math.min(m.y,E.y,cy)-60,y1=Math.max(m.y,E.y)+60;
 for(const e of R.foes){if(e.dead||e.s<0)continue;const q=rpPos(R,e),px=q.x,py=q.y-(e.air?40:18);if(px<x0||px>x1||py<y0||py>y1)continue;
  let best=1e9,bu=0;for(let j=0;j<10;j++){const ax=pts[j*2],ay=pts[j*2+1],dx=pts[j*2+2]-ax,dy=pts[j*2+3]-ay,l2=dx*dx+dy*dy||1;let f=((px-ax)*dx+(py-ay)*dy)/l2;f=f<0?0:f>1?1:f;const ex=ax+dx*f-px,ey=ay+dy*f-py,d2=ex*ex+ey*ey;if(d2<best){best=d2;bu=(j+f)/10}}
  const hw=(e.air?20:16)+26*bu;if(best<hw*hw){const fl=e.fl;rpHurt(e,dmg*(bu>.8?1.2:1),T.ap[i],tw);e.fl=fl;e.scorch=.3;hit++}}return hit}
/* one stream: the angle chases the target at most RPD_TURN rad/s; the stream ends just past the target, within reach */
function rpdStream(R,tw,T,i,dt,m,e,key,rg){const tp=rpdLead(R,e,.1),ta=Math.atan2(tp.y-m.y,tp.x-m.x);let a=tw[key];
 a=a==null?ta:a+rpClamp(rpAngD(ta,a),-RPD_TURN*dt,RPD_TURN*dt);tw[key]=a;const d=Math.min(Math.hypot(tp.x-m.x,tp.y-m.y)+30,rg*1.15);return{m,e:{x:m.x+Math.cos(a)*d,y:m.y+Math.sin(a)*d},a}}
function rpDragonFire(R,tw,dt){const T=RP_TW.dragon,i=tw.tier-1,rg=T.range[i],L=RPDL[tw.tier],sp=tw.over>0?RPT.AB.over.k:1;
 tw.over=Math.max(0,tw.over-dt);tw.ck=Math.max(0,(tw.ck||0)-dt*1.5);if(tw.ckCd>0)tw.ckCd=Math.max(0,tw.ckCd-dt);
 const A=tw.an||(tw.an={la:.3,lav:0,jaw:0,jv:0,nk:0,nkv:0,fl:0,flv:0,puff:0});if(tw.face==null)tw.face=1;if(!tw.fs)tw.fs=tw.face<0?-1:1;if(!tw.st)tw.st='idle';
 if(tw.dive){rpDragonDive(R,tw,T,i,dt);rpdAnim(tw,A,dt,{la:.2,jaw:0,nk:0,fl:0});tw.face+=(tw.fs-tw.face)*Math.min(1,dt*11);return}
 /* the target: kept while it is alive and in reach; in a breath it must stay on the side the dragon faces */
 if(!rpdOk(R,tw,tw.tg,rg)||tw.st==='breath'&&tw.fs*(rpPos(R,tw.tg).x-tw.x)<-24)tw.tg=rpdPick(R,tw,rg,null,tw.st==='breath'?tw.fs:0,tw.st==='breath'&&tw.sa!=null&&tw.m?{m:tw.m,a:tw.sa}:null);
 const e=tw.tg,tp=e?rpdLead(R,e,.15):null;
 /* turning: only between breaths, and only when the target is clearly on the other side */
 if(tp&&tw.st==='idle'){if(tp.x>tw.x+22)tw.fs=1;else if(tp.x<tw.x-22)tw.fs=-1}
 tw.face+=(tw.fs-tw.face)*Math.min(1,dt*11);const turned=Math.abs(tw.face-tw.fs)<.12;
 const B={x:tw.x+tw.face*10*L.s,y:tw.y-L.h-46*L.s},look=tp?Math.atan2(tp.y-B.y,Math.max(6,tw.fs*(tp.x-B.x))):.3+Math.sin(R.t*1.3+tw.ph)*.06;
 if(tw.st==='idle'){tw.cd-=dt*sp;tw.charge=Math.max(0,(tw.charge||0)-dt*4);tw.fire=Math.max(0,(tw.fire||0)-dt*3);tw.br=0;
  if(tw.cd<=0){tw.cd=0;if(e&&turned){if(T.dive[i]&&(tw.nb||0)>=T.diveN){tw.nb=0;rpdAnim(tw,A,dt,{la:look,jaw:0,nk:0,fl:0});return rpDragonDiveStart(R,tw,e)}tw.st='wind';tw.wt=T.wind}}
  rpdAnim(tw,A,dt,{la:look,jaw:0,nk:0,fl:0});return}
 if(tw.st==='wind'){tw.wt-=dt*sp;tw.charge=.3*(1-Math.max(0,tw.wt)/T.wind);rpdAnim(tw,A,dt,{la:look,jaw:.3,nk:-1,fl:.75});
  if(!e){tw.st='idle';tw.cd=.25;return}
  if(tw.wt<=0){tw.st='breath';tw.br=tw.brD=T.dur[i];tw.bt=.05;tw.sa=null;tw.sa2=null;tw.tg2=null;A.nkv+=16;A.jv+=6;if(!R.rm||Math.random()<.5)rpSfxRoar()}return}
 /* breath */
 tw.br-=dt;tw.fire=1;const u=1-tw.br/tw.brD;tw.charge=Math.min(1,u*9,Math.max(0,tw.br)*5);
 if(!e||tw.br<=0){const used=rpClamp(u,0,1);tw.st='idle';tw.br=0;tw.cd=T.cd[i]*(.35+.65*used);tw.nb=(tw.nb||0)+1;tw.streams=null;A.puff=1;tw.charge=0;tw.sa=tw.sa2=null;
  rpdAnim(tw,A,dt,{la:look,jaw:0,nk:0,fl:0});return}
 const m=rpDMouthW(tw,R.t),S=[rpdStream(R,tw,T,i,dt,m,e,'sa',rg)];
 if(T.beams[i]>1){if(!rpdOk(R,tw,tw.tg2,rg)||tw.tg2===e||tw.fs*(rpPos(R,tw.tg2).x-tw.x)<-24)tw.tg2=rpdPick(R,tw,rg,e,tw.fs,tw.sa2!=null?{m,a:tw.sa2}:null);
  if(tw.tg2)S.push(rpdStream(R,tw,T,i,dt,m,tw.tg2,'sa2',rg));else{tw.sa2=null;const a=S[0].a+.3*Math.sin(R.t*2.4+tw.ph)+.22,d=Math.hypot(S[0].e.x-m.x,S[0].e.y-m.y);S.push({m,e:{x:m.x+Math.cos(a)*d,y:m.y+Math.sin(a)*d},a})}}
 const k=Math.min(1,tw.charge*1.15);for(const st of S)rpdBurn(R,tw,T,i,dt,st.m,st.e,1);tw.streams=S.map(st=>({m:st.m,e:st.e,k}));tw.m=m;
 if(T.burn[i]){tw.bt=(tw.bt||0)-dt;if(tw.bt<=0){tw.bt=.3;for(const st of S){const x=st.e.x,y=st.e.y+18;if(R.G.dRoad(x,y)<70&&R.burns.length<40)R.burns.push({x,y,r:52,t:0,d:2.4,dps:T.burn[i],tw})}}}
 /* the head follows the stream: its angle in the facing frame */
 const sa=S[0].a;rpdAnim(tw,A,dt,{la:Math.atan2(Math.sin(sa),Math.max(.05,tw.fs*Math.cos(sa))),jaw:.96+.05*Math.sin(R.t*31+tw.ph*5),nk:.45,fl:.55,br:1})}
/* the tier-5 wing dive: up from the roost, low along the road over the target, and back */
function rpDragonDiveStart(R,tw,e){const P=R.G.paths[e.pi||0]||R.G.paths[0],len=P.len,s0=Math.min(len-10,e.s+150),s1=Math.max(10,e.s-170),pts=[];
 for(let k=0;k<=8;k++){const p=rpAt(R.G,s0+(s1-s0)*k/8,e.pi);pts.push({x:p.x,y:p.y-34})}
 tw.dive={t:0,d:2.6,pts,hx:tw.x,hy:tw.y-RPDL[5].h-30,trail:[],tt:0};tw.charge=0;rpSfxRoar();setTimeout(()=>{try{rpSfx('boom')}catch(x){}},200);
 rpText(tw.x,tw.y-170,'Wing dive!','#fff2b0',26)}
function rpDivePos(D,u){const H={x:D.hx,y:D.hy},A=D.pts[0],B=D.pts[D.pts.length-1];
 if(u<.24){const v=rpEase(u/.24),cx=(H.x+A.x)/2,cy=Math.min(H.y,A.y)-120;const a=1-v;return{x:a*a*H.x+2*a*v*cx+v*v*A.x,y:a*a*H.y+2*a*v*cy+v*v*A.y}}
 if(u<.76){const v=(u-.24)/.52*(D.pts.length-1),k=Math.min(D.pts.length-2,v|0),f=v-k,p=D.pts[k],q=D.pts[k+1];return{x:p.x+(q.x-p.x)*f,y:p.y+(q.y-p.y)*f}}
 const v=rpEase((u-.76)/.24),cx=(B.x+H.x)/2,cy=Math.min(H.y,B.y)-140,a=1-v;return{x:a*a*B.x+2*a*v*cx+v*v*H.x,y:a*a*B.y+2*a*v*cy+v*v*H.y}}
function rpDragonDive(R,tw,T,i,dt){const D=tw.dive;D.t+=dt;const u=Math.min(1,D.t/D.d),p=rpDivePos(D,u),p2=rpDivePos(D,Math.min(1,u+.01));D.x=p.x;D.y=p.y;D.a=Math.atan2(p2.y-p.y,p2.x-p.x);
 if(u>.2&&u<.8){const over=tw.over>0?1.3:1;for(const e of R.foes){if(e.dead||e.s<0)continue;const q=rpPos(R,e);if((q.x-p.x)**2+((q.y-34-p.y)/.8)**2<80*80){const fl=e.fl;rpHurt(e,T.dive[i]*over*dt,99,tw);e.fl=fl;e.scorch=.25}}
  D.tt-=dt;if(D.tt<=0){D.tt=.16;if(R.burns.length<40)R.burns.push({x:p.x,y:p.y+34,r:48,t:0,d:2.2,dps:T.burn[i],tw})}}
 if(!R.lite||D.trail.length<8){D.trail.push({x:p.x,y:p.y,t:0});if(D.trail.length>26)D.trail.shift()}for(const q of D.trail)q.t+=dt;
 if(u>=1){tw.dive=null;tw.cd=T.cd[i]*.6;tw.st='idle';rpRing(tw.x,tw.y,'#fff2b0',120,6);try{ptBurst(R.fx,tw.x,tw.y-RPDL[5].h-20,16,['#fff2b0','#ffd45a','#ffffff'],{v:220,s:4,k:'star'})}catch(e){}}}
/* winding it up */
function rpCrank(tw){const R=RPX;if(!R||!tw||tw.type!=='dragon'||tw.build<1||R.wst==='done')return false;if(tw.ckCd>0||tw.st&&tw.st!=='idle'||tw.dive){rpSfx('no');return false}
 tw.cd=0;tw.ckCd=RPD_CRANK;tw.ck=1;rpSfx('ability');rpText(tw.x,tw.y-150,'Wound up!','#ffd45a',22);try{ptBurst(R.fx,tw.x,tw.y-RPDL[tw.tier].h*.5,10,['#ffd45a','#fff4c8','#c88a10'],{v:200,s:3.5})}catch(e){}return true}
{const f0=rpFire;rpFire=function(R,tw,dt){if(tw.type==='dragon')return rpDragonFire(R,tw,dt);return f0.apply(this,arguments)}}
{const u0=rpUpgrade;rpUpgrade=function(tw){const r=u0.apply(this,arguments);if(r&&tw&&tw.type==='dragon'){tw.br=0;tw.dive=null;tw.charge=0;tw.st='idle';tw.streams=null;tw.sa=tw.sa2=null}return r}}
/* drawing: the tower gets its face, dive and crank state; the streams and the flying dragon draw over the battle */
{const d0=rpTowerDraw;rpTowerDraw=function(g,type,tier,skin,t,o){if(type==='dragon'&&RPDTW){o=Object.assign({},o,rpdO(RPDTW))}return d0.call(this,g,type,tier,skin,t,o)}}
{const b0=rpTowerBuild;rpTowerBuild=function(g,type,tier,skin,k,t,o){if(type==='dragon'&&RPDTW){o=Object.assign({},o,{face:RPDTW.face==null?1:RPDTW.face})}return b0.call(this,g,type,tier,skin,k,t,o)}}
{const a0=rpTowerAt;rpTowerAt=function(c,R,tw){if(tw.type!=='dragon')return a0.apply(this,arguments);RPDTW=tw;try{return a0.apply(this,arguments)}finally{RPDTW=null}}}
{const b0=rpBeamsDraw;rpBeamsDraw=function(c,R){b0.apply(this,arguments);for(const p of R.pads){const tw=p.tw;if(!tw||tw.type!=='dragon'||tw.build<1)continue;
  if(tw.st==='breath'&&tw.streams){const m=rpDMouthW(tw,R.t);for(const st of tw.streams)rpDragonBreath(c,m.x,m.y,st.e.x+m.x-st.m.x,st.e.y+m.y-st.m.y,R.t,st.k,tw.tier,tw.skin,R.lite)}
  if(tw.dive&&tw.dive.x!=null){const D=tw.dive,P=rpdP(tw.skin,tw.tier);c.save();c.globalCompositeOperation='lighter';
   for(const q of D.trail){const f=Math.max(0,1-q.t/.7);if(f<=0)continue;rpGlow(c,q.x,q.y+6,26*f+8,20*f+6,P.fl[1],.55*f);rpGlow(c,q.x,q.y+6,10*f+4,8*f+3,P.fl[3],.6*f)}c.restore();RPGA=1;
   c.globalAlpha=.35;c.fillStyle='#12081f';c.beginPath();c.ellipse(D.x,D.y+52,40,12,0,0,TAU);c.fill();c.globalAlpha=1;
   rpDragonFly(c,D.x,D.y,D.a,tw.tier,tw.skin,R.t,1)}}}}
/* ---------- the HUD: a sixth card and ring button (locked until Ember Crown is won), the Wind up button ---------- */
{const h0=rpHudOn;rpHudOn=function(){const r=h0.apply(this,arguments);try{const h=$('rphud');if(h){h.classList.add('rp6');const c=h.querySelector('.rpcard[data-tw="dragon"]');if(c&&rpLockedTw('dragon')){c.classList.add('lock');c.insertAdjacentHTML('beforeend',`<i class="rplk">${RPI.lock}</i>`);const tp=c.querySelector('.rptip');if(tp)tp.innerHTML='<b>Dragon Roost · locked</b>Win Ember Crown (the third map) to unlock the clockwork dragon.'}}}catch(e){}return r}}
{const g0=rpHudRing;rpHudRing=function(R,C){const was=C.rg;const r=g0.apply(this,arguments);try{if(C.rg!==was&&C.rg){const el=$('rpring'),p=R.selPad,below=p.y<330,ang=below?[172,140,108,72,40,8]:[-172,-140,-108,-72,-40,-8],rad=158;
  el.querySelectorAll('.rprb').forEach((b,i)=>{const a=ang[i]*Math.PI/180;b.style.setProperty('--x',(Math.cos(a)*rad).toFixed(1)+'px');b.style.setProperty('--y',(Math.sin(a)*rad*.72).toFixed(1)+'px');if(rpLockedTw(b.dataset.tw)){b.classList.add('lock');b.insertAdjacentHTML('beforeend',`<i class="rplk">${RPI.lock}</i>`)}})}}catch(e){}return r}}
{const i0=rpInfoBuild;rpInfoBuild=function(R,tw,el){const r=i0.apply(this,arguments);if(tw.type!=='dragon')return r;try{const T=RP_TW.dragon,i=tw.tier-1,top=RP_MAXT(R.map),nx=tw.tier<top?tw.tier:null;
  const seg=(v,max)=>Math.max(0,Math.min(6,Math.round(v/max*6))),bar=(lab,v,max,nv)=>`<div class="rpst"><span>${lab}</span><i>${[0,1,2,3,4,5].map(k=>`<s class="${k<seg(v,max)?'on':nv!=null&&k<seg(nv,max)?'up':''}"></s>`).join('')}</i></div>`;
  const pw=j=>Math.sqrt(T.dps[j]*T.dur[j]/(T.cd[j]+T.dur[j]+T.wind)*T.beams[j]*3);
  const st=el.querySelector('.rpsts');if(st)st.innerHTML=bar('Range',T.range[i],320,nx!=null?T.range[nx]:null)+bar('Damage',pw(i),Math.sqrt(1400),nx!=null?pw(nx):null)+bar('Breath',T.dur[i],2.6,nx!=null?T.dur[nx]:null)+bar('Burn',T.burn[i]+(T.dive[i]?20:0),62,nx!=null?T.burn[nx]+(T.dive[nx]?20:0):null);
  const pr=el.querySelector('.rppri');if(pr)pr.insertAdjacentHTML('beforebegin',`<button class="rpcrank" id="rpcrank"><span class="rpcrg">${RPI.gear}</span><b>Wind up</b><small id="rpcrks">Breathe fire now</small><kbd>C</kbd></button>`);
  const b=$('rpcrank');if(b)b.onclick=()=>rpCrank(tw);
  /* the panel grew: place it again so the Sell row still clears the tower bar */
  const hgt=el.offsetHeight||460;el.style.top=rpClamp(tw.y-hgt*.62,76,770-hgt)+'px'}catch(e){console.error(e)}return r}}
{const i0=rpHudInfo;rpHudInfo=function(R,C){i0.apply(this,arguments);const tw=R.sel;if(!tw||tw.type!=='dragon')return;const b=$('rpcrank');if(!b)return;
 const s=tw.ckCd>0?`Ready in ${Math.ceil(tw.ckCd)} s`:tw.st==='breath'||tw.st==='wind'?'Breathing fire…':tw.dive?'Diving…':'Breathe fire now',dis=tw.ckCd>0||tw.st==='breath'||tw.st==='wind'||!!tw.dive;if(b.dataset.s!==s){b.dataset.s=s;rpSetText($('rpcrks'),s);b.classList.toggle('no',dis)}}}
RPI.gear='<svg viewBox="0 0 24 24"><path d="M10.4 2h3.2l.5 2.6 1.9.8 2.2-1.5 2.3 2.3-1.5 2.2.8 1.9 2.6.5v3.2l-2.6.5-.8 1.9 1.5 2.2-2.3 2.3-2.2-1.5-1.9.8-.5 2.6h-3.2l-.5-2.6-1.9-.8-2.2 1.5-2.3-2.3 1.5-2.2-.8-1.9L2 13.6v-3.2l2.6-.5.8-1.9-1.5-2.2 2.3-2.3 2.2 1.5 1.9-.8z" fill="#ffd45a" stroke="#12081f" stroke-width="1.5" stroke-linejoin="round"/><circle cx="12" cy="12" r="3.4" fill="#8a5a14" stroke="#12081f" stroke-width="1.4"/></svg>';
/* keys: Y picks the dragon, C winds up the selected one */
{const k0=rpKeyDown;window.removeEventListener('keydown',rpKeyDown,true);rpKeyDown=function(e){const R=RPX;if(R&&S.rp&&S.mode==='ramparts'&&!R.pause&&!R.over&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&e.key.length===1){const lk=e.key.toLowerCase();
  if(lk==='y'){e.preventDefault();e.stopImmediatePropagation();if(!e.repeat)rpPlace('dragon');return}
  if(lk==='c'&&R.sel&&R.sel.type==='dragon'){e.preventDefault();e.stopImmediatePropagation();if(!e.repeat)rpCrank(R.sel);return}}return k0.apply(this,arguments)};window.addEventListener('keydown',rpKeyDown,true)}
/* winning Ember Crown unlocks the dragon: a card on the result screen, once */
{const r0=rpResult;rpResult=function(){const R=RPX,res=R&&R.result;const out=r0.apply(this,arguments);try{const rp=RPP();if(res&&res.won&&R.map.id==='ember'&&!rp.dragonSeen){rp.dragon=1;rp.dragonSeen=1;save();
  const box=ov.querySelector('.rpres'),unls=box&&box.querySelector('.rpunls');if(unls){unls.insertAdjacentHTML('afterbegin',`<span class="rpunl rpunld"><img alt="" src="${rpIconCanvas('dragon',3,'base',96)}"><b>Dragon Roost</b><small>New tower! Key Y</small></span>`)}
  else if(box){const d=document.createElement('div');d.className='rpdun';d.innerHTML=`<img alt="" src="${rpIconCanvas('dragon',3,'base',120)}"><span><small>NEW TOWER UNLOCKED</small><b>Dragon Roost</b><em>A clockwork dragon that breathes sweeping fire. Build it on any map (key Y).</em></span>`;
   const row=box.querySelector('.row');if(row)row.before(d);else box.appendChild(d)}}}catch(e){console.error(e)}return out}}
/* help texts */
try{const h=HELP.Modes.find(x=>x[0]==='Runestone Tower Defense');if(h)h[1]=h[1].replace('or the Celestial Prism (the costliest: ramping radiant beams).','the Celestial Prism (the costliest: ramping radiant beams) or, once you win Ember Crown, the Dragon Roost (Y: a clockwork dragon whose sweeping fire breath burns every monster it crosses; C winds it up).')}catch(e){}
{const s0=document.createElement('style');s0.textContent=`
.rph.rp6 .rpbar{left:742px;gap:8px}.rph.rp6 .rpcard{width:120px}.rph.rp6 .rpcard img{width:64px;height:64px;margin:-12px -8px 0 -6px}
.rph.rp6 .rpct b{font-size:13px}
.rpcard.lock img,.rprb.lock img{opacity:.45}.rpcard.lock .rpcost,.rprb.lock b{opacity:.5}
.rplk{position:absolute;left:28px;top:26px;width:26px;height:26px;pointer-events:none}.rplk svg{width:100%;height:100%}.rprb .rplk{left:27px;top:20px}
.rpcrank{position:relative;display:grid;grid-template-columns:34px 1fr;grid-template-rows:auto auto;column-gap:10px;align-items:center;width:100%;margin:8px 0 2px;padding:8px 44px 8px 10px;border-radius:14px;border:2px solid #ffb04a;background:linear-gradient(180deg,#4a2a14,#2a140c);color:#fff8e8;text-align:left;cursor:pointer;transition:transform .15s var(--sp)}
.rpcrank:hover{transform:translateY(-2px)}.rpcrank.no{opacity:.55;filter:none}.rpcrank .rpcrg{grid-row:1/3;width:34px;height:34px;display:block;transition:transform .5s var(--sp)}.rpcrank:hover .rpcrg{transform:rotate(90deg)}.rpcrank .rpcrg svg{width:100%;height:100%}
.rpcrank b{font:800 15px var(--ui);color:#ffd45a}.rpcrank small{font:600 12px var(--ui);color:#e8d8c8}.rpcrank kbd{position:absolute;right:10px;top:50%;transform:translateY(-50%)}
.rpdun{display:flex;align-items:center;gap:14px;margin:10px auto 6px;max-width:560px;padding:10px 18px 10px 10px;border-radius:18px;border:2px solid #ffb04a;background:linear-gradient(90deg,#4a2410,#1a0e30);box-shadow:0 0 0 2px #12081f;text-align:left;animation:rpdun .6s var(--sp) both .6s}
.rpdun img{width:96px;height:96px;flex:none;margin:-14px 0 -8px}.rpdun small{display:block;font:800 12px var(--ui);letter-spacing:.14em;color:#ffb04a}.rpdun b{display:block;font:400 32px/1.05 'Pirata One',var(--ui);color:#ffd45a}.rpdun em{display:block;font:600 14px var(--ui);font-style:normal;color:#e8e0ff}
@keyframes rpdun{from{opacity:0;transform:scale(.8)}}
#ov .rpunl.rpunld{border-color:#ffb04a;background:linear-gradient(180deg,#4a2410,#1a0e30)}.rpunl.rpunld b{color:#ffd45a}`;document.head.appendChild(s0)}
