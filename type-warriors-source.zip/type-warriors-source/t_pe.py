import asyncio,os,sys
from playwright.async_api import async_playwright
TAG=sys.argv[1] if len(sys.argv)>1 else 'a'
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append('PE '+str(e)[:300]))
        await pg.goto('file://'+os.path.abspath('out.html'));await pg.wait_for_timeout(1500);E=pg.evaluate
        await E("()=>{RS_ASK=false;P.gold=51413;P.pets={};['antler','bramble','cinder','ember','beetle','gloom','lily','mosskip','noct','crab','prism','quill','starcoil','tick','wisp'].forEach((k,i)=>P.pets[k]={b:i*40,t:Date.now()-i*1e6});P.pets.ember.acc=1;P.pets.ember.pal=1;P.pet='ember';P.petSt=2;P.eggs={r:2,l:1};petNorm();PTX.sel='ember';petHall('Pets')}")
        await pg.wait_for_timeout(1500);await pg.screenshot(path=f'shots/pe_pets_{TAG}.png')
        await E("()=>{P.pets={antler:{b:100},bramble:{b:0}};P.pet='antler';petNorm();petHall('Eggs')}");await pg.wait_for_timeout(1500);await pg.screenshot(path=f'shots/pe_eggs_{TAG}.png')
        print(er[:5]);await b.close()
asyncio.run(main())
