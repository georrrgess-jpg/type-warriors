/* ===== WILDCARD RANKED (8.3): ranks, points, seasons, rewards and the AI ladder =====
   Ranked lives inside Wildcard: a normal 4-player game with the usual rules (+2 stacking on), no coin stake, 15-second
   turns. The game ends when someone empties their hand; everyone else is placed by fewest cards, then fewest card points
   (numbers count their value, actions 20, wilds 50), then whoever played last. Your place moves a 100-point bar; fill it to
   rank up (the bar starts again at 0). The bar never goes below 0 and you never drop a rank during a season.
   Seasons last 6 weeks; at the end you drop 2 ranks (Bronze is the floor) and the bar resets. Legend has no bar: Legend
   points keep counting. Every rank up gives a sleeve (a card back in the vault), a moment emote and coins (coins again each
   season you reach that rank). Leaving a match, closing the page during one, or three timeouts in a row place you 4th.
   Save data: P.rk (rkSt). Sleeves live in the Wildcard vault (W.backs, keys rk*); emotes in P.rk.em. */
const WCRN=[
 {k:'bronze',n:'Bronze',pts:[30,20,10,0],coins:0,back:'rkcopper',emo:null,c:'#ffb070',c2:'#8a4418',ai:'Plays a random legal card and picks a random element for wilds.'},
 {k:'silver',n:'Silver',pts:[30,15,5,-5],coins:1500,back:'rkmoon',emo:'stun',c:'#e8eefa',c2:'#7a86a8',ai:'Plays number cards first, saves its wilds and picks the element it holds most.'},
 {k:'gold',n:'Gold',pts:[30,10,0,-10],coins:3000,back:'rksun',emo:'rev',c:'#ffd45a',c2:'#a86a10',ai:'Aims action cards at whoever has the fewest cards and always calls WILD!'},
 {k:'plat',n:'Platinum',pts:[25,10,-5,-15],coins:5000,back:'rkglacier',emo:'stack',c:'#8af0d8',c2:'#1a8a7a',ai:'Remembers which elements each player could not match and switches to them.'},
 {k:'dia',n:'Diamond',pts:[25,5,-10,-20],coins:8000,back:'rkprism',emo:'slam',c:'#8ad0ff',c2:'#2a5ad0',ai:'Counts the cards played and holds its +4 until someone is down to one or two cards.'},
 {k:'leg',n:'Legend',pts:[25,5,-10,-20],coins:12000,back:'rkcelest',emo:'over',c:'#e6b8ff',c2:'#7a3ad0',title:'Legend',ai:'Counts the cards played and holds its +4 until someone is down to one or two cards.'}];
const WCREMO={stun:{n:'Stunned!',r:1,when:'you skip someone with a Stun card',c:'#5ab8ff',c2:'#1a3a9a'},rev:{n:'Reversed!',r:2,when:'you flip the turn order with a Turnabout',c:'#ffc94a',c2:'#9a5a10'},
 stack:{n:'Stack Attack',r:3,when:'you add to a +2 stack and pass it on',c:'#4ae0b8',c2:'#0a6a5a'},slam:{n:'+4 Slam',r:4,when:'you play a +4 Hex',c:'#8ab8ff',c2:'#2a3ab8'},over:{n:'Game Over',r:5,when:'you play your last card and win',c:'#c88aff',c2:'#4a1a8a'}};
const WCREMK=['stun','rev','stack','slam','over'];
const WCRSEA={start:Date.UTC(2026,9,12),len:42*864e5};
const rkSeason=()=>Math.max(1,Math.floor((Date.now()-WCRSEA.start)/WCRSEA.len)+1),rkSeasonEnd=s=>WCRSEA.start+s*WCRSEA.len;
const rkLvl=r=>Math.min(4,Math.max(0,r|0));
function rkSt(){let R=P.rk;if(!R||typeof R!=='object'||Array.isArray(R))R=P.rk={};
 const d={r:0,bar:0,lp:0,season:rkSeason(),peak:0,n:0,w:0,paid:{},em:{},hist:[],title:'',met:{},note:'',moved:0};
 for(const k in d)if(R[k]==null||typeof R[k]!==typeof d[k]||Array.isArray(d[k])!==Array.isArray(R[k]))R[k]=JSON.parse(JSON.stringify(d[k]));
 if(R.live===undefined)R.live=null;R.r=Math.max(0,Math.min(5,R.r|0));R.bar=Math.max(0,Math.min(99,R.bar|0));R.lp=Math.max(0,R.lp|0);
 const cur=rkSeason();if(R.season<cur){const drop=2*(cur-R.season),from=R.r;R.r=Math.max(0,R.r-drop);R.bar=0;R.lp=0;R.season=cur;
  R.note=`Season ${cur} has started.${from!==R.r?` You start it in ${WCRN[R.r].n} (down from ${WCRN[from].n}).`:''} Your sleeves and emotes are yours to keep.`;
  for(const s in R.paid)if(+s<cur-2)delete R.paid[s]}
 try{const W=wcSt();if(!W.byd.rk||typeof W.byd.rk!=='object')W.byd.rk={g:0,w:0}}catch(e){}return R}
const rkPts=(place,r)=>WCRN[r].pts[Math.max(0,Math.min(3,place))];
/* rewards for reaching rank r: sleeve and emote once ever, coins once per season */
function rkReward(r){const R=rkSt(),W=wcSt(),T=WCRN[r],o={r,back:T.back,newBack:false,emo:T.emo,newEmo:false,coins:0,title:T.title||''};
 if(T.back&&!W.backs[T.back]){W.backs[T.back]=1;o.newBack=true}if(T.emo&&!R.em[T.emo]){R.em[T.emo]=1;o.newEmo=true}
 const ps=R.paid[R.season]||(R.paid[R.season]=[]);if(T.coins&&!ps.includes(r)){ps.push(r);P.gold=Math.min(1e12,P.gold+T.coins);o.coins=T.coins}
 if(T.title)R.title=T.title;return o}
/* apply a finished match: place 0..3 */
function rkApply(place,why){const R=rkSt(),W=wcSt(),from={r:R.r,bar:R.bar,lp:R.lp},d=rkPts(place,R.r),o={place,d,from,up:null,first:false,why:why||''};
 R.n++;if(place===0)R.w++;if(!W.backs.rkcopper){W.backs.rkcopper=1;o.first=true}
 if(R.r===5)R.lp=Math.max(0,R.lp+d);else{const b=R.bar+d;if(b>=100){R.r++;R.bar=0;o.up=rkReward(R.r)}else R.bar=Math.max(0,b)}
 R.peak=Math.max(R.peak,R.r);R.hist.push({p:place,d,r:from.r,t:Date.now(),why:why||''});if(R.hist.length>20)R.hist.splice(0,R.hist.length-20);
 R.live=null;o.to={r:R.r,bar:R.bar,lp:R.lp};save();return o}
/* a ranked match left behind (page closed mid-game) counts as 4th */
function rkDodge(){const R=rkSt();if(!R.live)return null;if(WX.rk&&WX.G&&WX.G.phase!=='over'&&$('wct'))return null;const o=rkApply(3,'left');rkSt().note='Your last ranked match counted as 4th because you left it before the end.';save();return o}
setTimeout(()=>{try{if(P&&P.rk&&P.rk.live)rkDodge()}catch(e){}},2500);

/* ---------- placing: winner, fewest cards, fewest card points, then whoever played last ---------- */
{const p0=wcPlay;wcPlay=function(G,pi){const r=p0.apply(this,arguments);if(r)G.P[pi].lp=G.seq;return r}}
function wcRank(G){return G.P.map((p,i)=>({i,n:p.hand.length,pts:p.hand.reduce((a,c)=>a+wcPts(c),0),lp:p.lp||0})).sort((a,b)=>(a.i===G.win?-1:b.i===G.win?1:0)||a.n-b.n||a.pts-b.pts||b.lp-a.lp).map(x=>x.i)}

/* ---------- the AI ladder: five levels, Diamond and Legend share the top one ---------- */
Object.assign(WCB,{r0:{forget:.35,catch:.2,react:[1600,2800]},r1:{forget:.2,catch:.4,react:[1200,2300]},r2:{forget:0,catch:.65,react:[900,1800]},r3:{forget:0,catch:.8,react:[700,1500]},r4:{forget:0,catch:.92,react:[500,1200]}});
/* Platinum and up remember which elements each player could not match (forgotten again once they play that element) */
{const p0=wcPlay;wcPlay=function(G,pi,idx){const c=G.P[pi]&&G.P[pi].hand[idx];const r=p0.apply(this,arguments);if(r&&c&&c.s!=='w'&&G.P[pi].lack)G.P[pi].lack[c.s]=0;return r}}
function rkCol(G,pi,lv){const p=G.P[pi],cnt={e:0,t:0,g:0,s:0};for(const c of p.hand)if(c.s!=='w')cnt[c.s]++;
 if(lv===0)return WCS[Math.floor(G.r()*4)];const sc={};for(const s of WCS)sc[s]=cnt[s]*2;
 if(lv>=3){const nx=G.P[wcNext(G)];for(const s of WCS)if(nx.lack[s])sc[s]+=cnt[s]?4:1.5}
 if(lv>=4){const un=rkUnseen(G,pi);for(const s of WCS)sc[s]+=(25-un[s])*.12}
 let best=WCS[0];for(const s of WCS)if(sc[s]>sc[best])best=s;return best}
const rkUnseen=(G,pi)=>{const u={e:25,t:25,g:25,s:25};for(const c of G.disc)if(c.s!=='w')u[c.s]--;for(const c of G.P[pi].hand)if(c.s!=='w')u[c.s]--;return u};
function wcBotRk(G,pi,lv){const p=G.P[pi],L=wcLegal(G,pi),nxI=wcNext(G),nx=G.P[nxI],pv=G.P[wcNext(G,-1)],mine=p.hand.length;
 const minOpp=Math.min(...G.P.map((q,i)=>i===pi?99:q.hand.length)),danger=minOpp<=2,lead=nx.hand.length===minOpp,col=c=>c.s==='w'?rkCol(G,pi,lv):null;
 if(G.phase==='drawn'){if(!L.length)return{t:'pass'};const c=p.hand[L[0]];
  if(lv>=4&&c.v==='d4'&&!danger&&mine>2)return{t:'pass'};if(lv===1&&c.s==='w'&&mine>3)return{t:'pass'};return{t:'play',i:L[0],col:col(c)}}
 if(!L.length)return{t:'draw'};
 if(lv===0){const i=L[Math.floor(G.r()*L.length)];return{t:'play',i,col:col(p.hand[i])}}
 const cnt={e:0,t:0,g:0,s:0};for(const c of p.hand)if(c.s!=='w')cnt[c.s]++;const un=lv>=4?rkUnseen(G,pi):null;
 let best=-1e9,pick=L[0];
 for(const i of L){const c=p.hand[i],act=c.v==='stun'||c.v==='d2'||c.v==='turn';let s=0;
  if(c.s==='w'){s+=(mine<=2?16:c.v==='d4'?-7:-4);if(c.v==='d4'&&lv>=2&&(danger||lead&&nx.hand.length<=3))s+=14}
  else{s+=10+(wcIsNum(c)?(+c.v)*.45:2);s+=(cnt[c.s]-1)*1.1;
   if(lv>=2&&act&&(lead||nx.hand.length<=2))s+=nx.hand.length<=2?10:4;
   if(lv>=2&&c.v==='turn'&&G.P.length>2&&pv.hand.length<nx.hand.length&&pv.hand.length<=3)s-=7;
   if(lv>=3&&nx.lack[c.s])s+=nx.hand.length<=3?8:5;
   if(lv>=4)s+=(25-un[c.s])*.1}
  if(lv>=4&&c.v==='d4'&&!danger&&mine>2)s-=6;
  if(lv>=3&&danger)s+=wcPts(c)*(lv>=4?.3:.2);
  if(G.stack>0&&lv>=2&&c.v==='d2')s+=6;
  s+=G.r()*(lv>=3?.4:lv>=2?.8:1.6);if(s>best){best=s;pick=i}}
 return{t:'play',i:pick,col:col(p.hand[pick])}}
{const b0=wcBot;wcBot=function(G,pi){const p=G.P[pi];if(p&&/^r[0-4]$/.test(p.diff||''))return wcBotRk(G,pi,+p.diff[1]);return b0.apply(this,arguments)}}
/* the AI thinks for 0.8 to 2 seconds in ranked */
{const m0=wcBotMove;wcBotMove=function(pi,again){if(WX.rk&&!again){const G=WX.G;wcLater(()=>wcBotMove(pi,1),G?G.r()*600:0);return}return m0.call(this,pi)}}

/* ---------- a ranked match ---------- */
/* every new game starts unranked unless it says otherwise */
{const r0=wcReset;wcReset=function(o){Object.assign(WX,{rk:null,rkDone:0,rkTo:0,rkLeft:null,rkWait:0,rkFin:null,rkRank:null,rkWaitFin:0,rkAfkRes:null,rkSendRk:0,mute:{},emoT:0,rkMom:null});return r0.apply(this,arguments)}}
WCT.rk={n:'Ranked',lab:'R',stake:0,chip:'#ffd45a',chip2:'#7a4a10'};
function rkStart(o){o=o||{};const R=rkSt();rkDodge();
 wcReset({mode:'solo',tbl:'rk',stake:0,fee:0,cfg:{timer:15,tbl:'rk'},rk:{r:R.r,id:Date.now().toString(36)},rkTo:0,rkDone:0,mute:{}});
 const lv='r'+rkLvl(R.r),crew=wcCrewGen(3,null,{rare:.1});
 const players=[{id:'me',name:P.name||'You',kind:'you',av:wcMyAv(),title:R.title},...crew.map((A,i)=>({id:'r'+i,name:A.name,kind:'bot',diff:lv,ai:1,av:A}))];
 WX.G=wcNew({players,hand:7,rules:{stack:1},seed:(Date.now()^Math.floor(Math.random()*1e9))>>>0});R.live={t:Date.now(),r:R.r};save();wcTable();
 const rg=players.find(p=>p.av&&p.av.rare);if(rg)wcToast(`✨ A rare guest takes an AI seat: <b>${esc(rg.name)}</b>. Win to earn the Pastel Wyrm card back!`);wcPump()}
/* the table: rank pills on top, the blue ranked felt, AI tags and titles on the seats */
{const t0=wcTable;wcTable=function(){const r=t0.apply(this,arguments);try{if(WX.rk){const t=$('wct');t.classList.remove('green');t.classList.add('blue','rkt');const R=rkSt();
 const top=t.querySelector('.wctop');if(top)top.innerHTML=`<span class="wcpill tb rkpil">${rkInsig(R.r,30)}<b>Ranked · ${WCRN[R.r].n}</b></span><span class="wcpill">${R.r===5?`Legend points <b>${R.lp}</b>`:`<b>${R.bar}</b> / 100`}</span><span class="wcpill">15-second turns</span>`}}catch(e){}return r}}
{const s0=wcSeatHTML;wcSeatHTML=function(i){let h=s0.apply(this,arguments);try{const p=WX.G.P[i];
 if(WX.rk&&p.kind==='bot'&&p.ai&&!(p.av&&p.av.rare))h=h.replace(/(<div class="wcnm[^"]*"><b>[^<]*<\/b>)(<small[^>]*>[^<]*<\/small>)?/,'$1<small class="d-ai"><i>AI</i> '+WCRN[WX.rk.r].n+'</small>');
 if(p.title==='Legend')h=h.replace(/(<div class="wcnm[^"]*"><b>[^<]*<\/b>)/,'$1<small class="d-leg">★ Legend</small>')}catch(e){}return h}}
/* who acted: a move the player sent themselves resets the timeout count; a timer move adds to it */
{const s0=wcSend;wcSend=function(a){WX.rkUser=1;try{return s0.apply(this,arguments)}finally{WX.rkUser=0}}}
{const a0=wcApply;wcApply=function(pi,a){const G=WX.G,mine=!!(WX.rk&&G&&pi===WX.me&&G.P[pi]&&G.P[pi].kind==='you'),user=!!WX.rkUser;const r=a0.apply(this,arguments);
 if(mine&&r&&a&&a.t!=='call'&&a.t!=='catch'){if(user)WX.rkTo=0;else if(a.t==='draw'||a.t==='pass'){WX.rkTo=(WX.rkTo||0)+1;if(WX.rkTo>=3&&WX.G&&WX.G.phase!=='over')setTimeout(rkAfk,600);else if(WX.rkTo===2)wcToast('One more timeout and an AI takes your seat. That counts as leaving (4th).')}}return r}}
function rkAfk(){if(!WX.rk||WX.rkDone||!WX.G)return;const G=WX.G;G.P[WX.me].kind='bot';G.P[WX.me].diff='r'+rkLvl(WX.rk.r);G.P[WX.me].ai=1;WX.rkDone=1;const res=rkApply(3,'afk');
 /* hosting an online match: the game keeps running for the others, an AI plays this seat */
 if(WX.rk.net&&WX.host){WX.rkAfkRes=res;try{wcRecord({forfeit:1})}catch(e){}wcToast('Three timeouts: an AI took your seat. This counts as 4th.');wcRender();wcStep();return}
 try{wcRecord({forfeit:1})}catch(e){}WX.tok++;wcClear();rkResults(res,null,{afk:1})}
/* leaving through the menu */
{const r0=wcRecord;wcRecord=function(o){if(WX.rk&&o&&o.forfeit&&!WX.rkDone&&WX.G&&WX.G.phase!=='over'){WX.rkDone=1;WX.rkLeft=rkApply(3,'left');rkSt().note='You left your last ranked match, so it counted as 4th.';save()}
 if(WX.rk&&!(o&&o.forfeit)){const W=wcSt(),fw=W.fw;W.fw=wcDay();const R=r0.apply(this,arguments);W.fw=fw;return R}return r0.apply(this,arguments)}}
{const e0=wcEnd;wcEnd=function(){if(!WX.rk)return e0.apply(this,arguments);const G=WX.G;if(WX.rkAfkRes&&$('wct')){const r=WX.rkAfkRes;WX.rkAfkRes=null;rkResults(r,null,{afk:1});return}if(!G||!$('wct')||WX.rkDone)return;WX.rkDone=1;
 const rank=wcRank(G),place=rank.indexOf(WX.me);try{wcRecord()}catch(e){}const res=rkApply(place);rkResults(res,rank)}}
