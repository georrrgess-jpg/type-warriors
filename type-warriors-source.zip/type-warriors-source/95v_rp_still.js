/* ===== RUNESTONE TOWER DEFENSE 9.9: the Alchemist's Still in battle (95v, after 95u) =====
   The ninth tower (key P, 220 supply, ground only). A support tower: it brews a flask, throws it where it will soak the most ground
   monsters (preferring armored ones and ones not soaked yet; it leads them with rpqLand from 95t, so slides, stuns and slows are read),
   and the flask shatters into an acid splash and a puddle on the road. Soaked monsters lose armor (RP_TW.still.melt) for a few seconds,
   so every tower hits them harder; melt beyond a monster's armor makes it take RPSTL.over more damage per point instead (an unarmored
   scamp soaked at tier 1 takes +20%). Monsters walking through the puddle are soaked again and burned (RP_TW.still.acid per second).
   Tier 3 Midas Gold: monsters that die soaked drop RP_TW.still.midas more coins. Tier 4 Mythic: violet brew that also slows like glue.
   Tier 5 Celestial: every RP_TW.still.gold[4]th flask turns the weakest monster in the splash (not a boss, and only one already below RPSTL.goldHp of its health) into a pile of gold, which
   pays half its coins again on top. Overcharge speeds it up and adds 15% damage like every other tower.
   Monster state: e.acid (s left), e.melt (points), e.arm0 (armor before melting), e.atier, e.midas, e.glue. e.armor itself is lowered
   while soaked and restored when it dries, so every armor reader (rpHurt, the Prism's beam) sees the melted value.
   State on RPX: alFlasks [{x0,y0,x1,y1,t,d,h,tw,tier,dmg,r,gold,seed}], alSplash [{x,y,r,t,d,tier,seed}],
   alPools [{x,y,r,t,d,tier,soak,seed,tw}], alGold [{x,y,t,d,seed}], alCoins [{x,y,vx,vy,t,d,r}]. Tower: tw.cd, tw.charge, tw.fire, tw.aim, tw.nv. */
RP_TW.still={cost:[220,180,320,700,1150],range:[200,215,230,245,260],dmg:[18,30,48,75,115],cd:[1.8,1.65,1.5,1.4,1.3],splash:[66,74,84,94,104],
 melt:[4,5,6,8,10],soak:[4,4.5,5,5.5,6],pool:[2,2.5,3,3.5,4],acid:[6,10,16,26,40],midas:[0,0,.3,.3,.35],glue:[0,0,0,.15,.18],gold:[0,0,0,0,4],air:0,ground:1,
 desc:'Lobs acid flasks that splash a stretch of road. Soaked monsters lose armor for a few seconds, so every other tower hits them harder. Cannot hit flyers.',
 up:['Stronger brew: more armor melts, longer puddles.','Midas Gold: monsters that die soaked drop 30% more coins.','Mythic brew: violet potions that also slow like glue.','Celestial flasks: every fourth flask turns the weakest wounded monster in the splash into a pile of gold.']};
RP_TWORDER.push('still');RP_KEYS.push('P');
const RPSTL={brew:.6,edge:.7,over:.05,poolK:.5,goldK:.5,goldHp:.35};
const rplFlight=d=>.5+d/900;
/* soak a monster: the strongest brew wins; armor drops at once */
function rplSoak(e,tw,dur){if(e.dead||e.air)return;const T=RP_TW.still,i=Math.max(0,Math.min(4,tw.tier-1));if(e.arm0==null)e.arm0=e.armor;
 const fresh=!(e.acid>0);e.acid=Math.max(e.acid||0,dur);
 if(fresh||T.melt[i]>=(e.melt||0)){e.melt=T.melt[i];e.atier=tw.tier;e.midas=Math.max(fresh?0:e.midas||0,T.midas[i]);e.glue=Math.max(fresh?0:e.glue||0,T.glue[i]);e.asrc=tw}
 e.armor=Math.max(0,e.arm0-e.melt);if(e.glue){e.slowK=Math.max(e.slowK||0,e.glue);e.slowT=Math.max(e.slowT||0,.25)}}
function rplDry(e){if(e.arm0!=null)e.armor=e.arm0;e.acid=0;e.melt=0;e.midas=0;e.glue=0}
/* melt beyond the armor: more damage taken (any source) */
{const h0=rpHurt;rpHurt=function(e,dmg,ap,src){if(e&&e.acid>0&&e.melt>(e.arm0||0))dmg*=1+(e.melt-(e.arm0||0))*RPSTL.over;return h0.call(this,e,dmg,ap,src)}}
/* Midas: soaked monsters pay more coins when they die */
{const k0=rpKillFoe;rpKillFoe=function(e,src){const R=RPX,was=e&&!e.dead;let extra=0;
 if(was&&R&&e.acid>0&&e.midas>0){extra=e.coin*(e.midas+(e.gold?RPSTL.goldK:0))}else if(was&&R&&e.gold)extra=e.coin*RPSTL.goldK;
 const r=k0.apply(this,arguments);
 if(was&&extra>0&&R){R.coins+=extra;R.cKill+=extra;R.alMidas=(R.alMidas||0)+extra;const p=rpPos(R,e);
  rpText(p.x+18,p.y-(e.boss?110:62),`+${Math.max(1,Math.round(extra))} coin${Math.round(extra)>1?"s":""}`,'#ffe27a',e.boss?26:16);
  const n=R.lite?2:Math.min(7,3+Math.round(extra));for(let k=0;k<n;k++)R.alCoins.push({x:p.x,y:p.y-24,vx:(Math.random()-.5)*150,vy:-160-Math.random()*130,t:0,d:.9+Math.random()*.3,r:Math.random()*6});
  if(R.alCoins.length>60)R.alCoins.splice(0,R.alCoins.length-60);try{beep(1320+Math.random()*200,.05,'triangle',.07)}catch(x){}}
 return r}}
/* where to throw: the predicted spot that soaks the most monsters, armored and dry ones first */
function rplAim(R,tw,T,i){const rg=T.range[i],r2=rg*rg,cand=[];
 for(const e of R.foes){if(e.dead||e.air||e.s<0)continue;const q=rpPos(R,e);if(rpD2(q.x,q.y,tw.x,tw.y)>r2)continue;cand.push(e)}
 if(!cand.length)return null;
 const pr=new Map(),P=e=>{let v=pr.get(e);if(!v){const q=rpPos(R,e);v=rpqLand(R,e,rplFlight(Math.sqrt(rpD2(q.x,q.y,tw.x,tw.y))));pr.set(e,v)}return v};
 const sp=T.splash[i]*.85,s2=sp*sp,mt=T.melt[i];let best=null,bv=-1e18;
 for(const e of cand){const L=P(e);let v=0;for(const f of R.foes){if(f.dead||f.air||f.s<0)continue;const M=P(f);if(rpD2(M.x,M.y,L.x,L.y)>s2)continue;
   const a0=f.arm0!=null?f.arm0:f.armor,dry=!(f.acid>.8)||(f.melt||0)<mt;v+=10+(dry?9:0)+Math.min(a0,mt)*(dry?2.5:.5)+(f.boss?12:0)}
  v+=tw.prio==='strong'?e.hp/1e6:tw.prio==='close'?-rpD2(L.x,L.y,tw.x,tw.y)/1e6:e.s/rpLen(R,e);if(v>bv){bv=v;best={e,x:L.x,y:L.y,s:L.s}}}
 return best}
function rpStillFire(R,tw,dt){const T=RP_TW.still,i=tw.tier-1,sp=tw.over>0?RPT.AB.over.k:1;tw.over=Math.max(0,tw.over-dt);
 tw.fire=Math.max(0,(tw.fire||0)-dt*1.8);tw.cd-=dt*sp;tw.charge=tw.cd<RPSTL.brew?Math.min(1,1-tw.cd/RPSTL.brew):Math.max(0,(tw.charge||0)-dt*3);
 if(tw.cd>0)return;const a=rplAim(R,tw,T,i);if(!a){tw.cd=.15;tw.charge=Math.max(0,tw.charge-.4);return}
 const dmgK=tw.over>0?1.15:1;tw.cd=T.cd[i];tw.fire=1;tw.charge=0;tw.aim=Math.atan2(a.y-tw.y,a.x-tw.x);tw.nv=(tw.nv||0)+1;
 const m=rplMouth(tw.tier),x0=tw.x+m.x,y0=tw.y+m.y,d=Math.hypot(a.x-x0,a.y-y0),gn=T.gold[i],gold=!!(gn&&tw.nv%gn===0);
 R.alFlasks.push({x0,y0,x1:a.x,y1:a.y,t:0,d:rplFlight(d),h:70+d*.28,tw,tier:tw.tier,dmg:T.dmg[i]*dmgK,r:T.splash[i],gold,seed:Math.random()*99});
 try{ptBurst(R.fx,x0,y0,R.lite?3:6,[rplBrew(tw.tier).c,rplBrew(tw.tier).l,'#ffffff'],{v:110,s:2.8,up:1,g:240})}catch(e){}
 rplSfx('throw')}
function rplSfx(k){try{if(k==='throw'){beep(380,.05,'sine',.12);setTimeout(()=>beep(620,.06,'sine',.1),40)}
 else if(k==='smash'){beep(1500+Math.random()*300,.04,'square',.06);setTimeout(()=>beep(220,.12,'sawtooth',.08),20);setTimeout(()=>beep(900,.05,'triangle',.06),70)}
 else if(k==='gold'){[880,1175,1568,2093].forEach((f,j)=>setTimeout(()=>beep(f,.09,'triangle',.12),j*55))}}catch(e){}}
/* turn a monster into a pile of gold */
function rplGoldify(R,e,tw){const p=rpPos(R,e);e.gold=1;rplSoak(e,tw,1);rpKillFoe(e,tw);e.dk=1;
 R.alGold.push({x:p.x,y:p.y,t:0,d:1.7,seed:Math.random()*99});if(R.alGold.length>12)R.alGold.shift();R.alGolds=(R.alGolds||0)+1;
 rpText(p.x,p.y-80,'GOLD!','#ffe27a',24);rpRing(p.x,p.y-10,'#ffd45a',90,5);rplSfx('gold');
 try{ptBurst(R.fx,p.x,p.y-20,R.lite?6:16,['#fff0a8','#ffd45a','#ffffff'],{v:240,s:3.4,up:1,g:380})}catch(x){}}
/* a flask lands: soak, hurt, puddle, gold */
function rplLand(R,f){const T=RP_TW.still,i=Math.max(0,Math.min(4,f.tw.tier-1)),x=f.x1,y=f.y1,r2=f.r*f.r;let weak=null;
 for(const e of R.foes){if(e.dead||e.air||e.s<0)continue;const q=rpPos(R,e),d2=rpD2(q.x,q.y,x,y);if(d2>r2)continue;
  rplSoak(e,f.tw,T.soak[i]);const k=1-(1-RPSTL.edge)*Math.sqrt(d2)/f.r;rpHurt(e,f.dmg*k,0,f.tw);
  if(f.gold&&!e.dead&&!e.boss&&e.hp<=e.mx*RPSTL.goldHp&&(!weak||e.hp<weak.hp))weak=e}
 if(weak)rplGoldify(R,weak,f.tw);
 R.alSplash.push({x,y,r:f.r,t:0,d:.6,tier:f.tier,seed:f.seed});if(R.alSplash.length>30)R.alSplash.shift();
 R.alPools.push({x,y,r:f.r*.82,t:0,d:T.pool[i],tier:f.tier,soak:T.soak[i]*RPSTL.poolK,dps:T.acid[i]*(f.dmg/T.dmg[i]),seed:f.seed,tw:f.tw});if(R.alPools.length>24)R.alPools.shift();
 try{ptBurst(R.fx,x,y-6,R.lite?4:10,[rplBrew(f.tier).c,rplBrew(f.tier).l,'#e8fff6'],{v:170,s:3,up:1,g:420})}catch(e){}
 rplSfx('smash')}
function rplStep(R,dt){if(!R.alFlasks)return;
 for(const f of R.alFlasks){f.t+=dt;if(f.t>=f.d&&!f.done){f.done=1;rplLand(R,f)}}R.alFlasks=R.alFlasks.filter(f=>!f.done);
 for(const s of R.alSplash)s.t+=dt;R.alSplash=R.alSplash.filter(s=>s.t<s.d);
 for(const p of R.alPools){p.t+=dt;for(const e of R.foes){if(e.dead||e.air||e.s<0)continue;const q=rpPos(R,e);if(rpD2(q.x,q.y,p.x,p.y)<p.r*p.r){rplSoak(e,p.tw,p.soak);if(p.dps){const fl=e.fl;rpHurt(e,p.dps*dt,99,p.tw);e.fl=fl}}}}
 R.alPools=R.alPools.filter(p=>p.t<p.d);
 for(const g of R.alGold)g.t+=dt;R.alGold=R.alGold.filter(g=>g.t<g.d);
 for(const c of R.alCoins){c.t+=dt;c.vy+=520*dt;c.x+=c.vx*dt;c.y+=c.vy*dt;c.r+=dt*12}R.alCoins=R.alCoins.filter(c=>c.t<c.d);
 for(const e of R.foes){if(!(e.acid>0))continue;e.acid-=dt;if(e.acid<=0||e.dead)rplDry(e);else if(e.glue){e.slowK=Math.max(e.slowK||0,e.glue);e.slowT=Math.max(e.slowT||0,.2)}}}
/* hooks: fire routine, battle state, step, upgrade */
{const f0=rpFire;rpFire=function(R,tw,dt){if(tw.type==='still')return rpStillFire(R,tw,dt);return f0.apply(this,arguments)}}
{const s0=rpStart;rpStart=function(){const r=s0.apply(this,arguments);if(RPX)Object.assign(RPX,{alFlasks:[],alSplash:[],alPools:[],alGold:[],alCoins:[],alMidas:0,alGolds:0});return r}}
{const s0=rpStep;rpStep=function(R,dt){const r=s0.apply(this,arguments);try{rplStep(R,dt)}catch(e){console.error(e)}return r}}
{const u0=rpUpgrade;rpUpgrade=function(tw){const r=u0.apply(this,arguments);if(r&&tw&&tw.type==='still'){tw.charge=0;tw.fire=0}return r}}
/* drawing: puddles and flask shadows on the ground; flasks, splashes, gold and coins on top; badges and drips on soaked monsters */
const rplPos=f=>{const u=Math.max(0,Math.min(1,f.t/f.d));return{u,x:f.x0+(f.x1-f.x0)*u,y:f.y0+(f.y1-f.y0)*u-f.h*4*u*(1-u),gx:f.x0+(f.x1-f.x0)*u,gy:f.y0+(f.y1-f.y0)*u}};
{const a0=rpAmbient;rpAmbient=function(c,R){const r=a0.apply(this,arguments);try{if(R&&R.alPools){
 for(const p of R.alPools){const k=Math.min(1,p.t*7,(p.d-p.t)/.7);rpStillPuddle(c,p.x,p.y,p.r,k,R.t,p.tier,p.seed%1)}
 for(const f of R.alFlasks){const p=rplPos(f),k=.35+.65*p.u;c.fillStyle=`rgba(8,4,20,${(.3*k).toFixed(3)})`;c.beginPath();c.ellipse(p.gx,p.gy+2,7*k,3*k,0,0,TAU);c.fill()}}}catch(e){console.error(e)}return r}}
{const b0=rpBeamsDraw;rpBeamsDraw=function(c,R){b0.apply(this,arguments);if(!R.alFlasks)return;
 for(const s of R.alSplash)rpStillSplash(c,s.x,s.y,s.r,s.t/s.d,s.tier,s.seed|0);
 for(const f of R.alFlasks){const p=rplPos(f),B=rplBrew(f.gold?5:f.tier);
  c.save();c.globalCompositeOperation='lighter';const n=R.lite?2:4;for(let k=1;k<=n;k++){const q=rplPos({x0:f.x0,y0:f.y0,x1:f.x1,y1:f.y1,h:f.h,t:Math.max(0,f.t-k*.03),d:f.d});rpGlow(c,q.x,q.y,10-k*1.5,10-k*1.5,B.c,.7-k*.13)}
  if(f.gold)rpGlow(c,p.x,p.y-6,26,26,'#ffd45a',.8+.2*Math.sin(R.t*30));c.restore();c.globalAlpha=1;
  rpStillFlask(c,p.x,p.y,f.gold?5:f.tier,f.t*11,1.35)}
 for(const g of R.alGold)rpStillGold(c,g.x,g.y,g.t/g.d,g.seed);
 for(const k of R.alCoins){c.globalAlpha=Math.min(1,(k.d-k.t)*4);rpStillCoin(c,k.x,k.y,k.r,1.05)}c.globalAlpha=1}}
{const f0=rpFoeDraw;rpFoeDraw=function(c,R,e,q){const r=f0.apply(this,arguments);if(e.acid>0&&!e.dead&&e.melt>0){try{
  if(!R.rm&&Math.random()<(R.lite?.04:.1)){const B=rplBrew(e.atier||1);ptBurst(R.fx,q.x+(Math.random()-.5)*16,q.y-22,1,[B.c,B.d],{v:24,s:2.4,g:260})}
  const h=(RPMOB[e.id]?RPMOB[e.id].h:50)+(e.air?44:8);rpStillBadge(c,q.x,q.y-h-(e.hp<e.mx?14:6),e.melt,e.atier||1,Math.min(1,e.acid*2))}catch(x){}}return r}}
/* the info panel: range, melt, splash, fire rate */
{const i0=rpInfoBuild;rpInfoBuild=function(R,tw,el){const r=i0.apply(this,arguments);if(tw.type!=='still')return r;try{const T=RP_TW.still,i=tw.tier-1,top=RP_MAXT(R.map),nx=tw.tier<top?tw.tier:null;
  const seg=(v,max)=>Math.max(0,Math.min(6,Math.round(v/max*6))),bar=(lab,v,max,nv)=>`<div class="rpst"><span>${lab}</span><i>${[0,1,2,3,4,5].map(k=>`<s class="${k<seg(v,max)?'on':nv!=null&&k<seg(nv,max)?'up':''}"></s>`).join('')}</i></div>`;
  const st=el.querySelector('.rpsts');if(st)st.innerHTML=bar('Range',T.range[i],300,nx!=null?T.range[nx]:null)+bar('Armor melt',T.melt[i],10,nx!=null?T.melt[nx]:null)+bar('Splash',T.splash[i],100,nx!=null?T.splash[nx]:null)+bar('Fire rate',1/T.cd[i],.72,nx!=null?1/T.cd[nx]:null);
  const ex=[`Armor <b>-${T.melt[i]}</b> for ${T.soak[i]} s`];if(T.midas[i])ex.push(`<b>+${Math.round(T.midas[i]*100)}%</b> coins`);if(T.glue[i])ex.push(`<b>${Math.round(T.glue[i]*100)}%</b> glue slow`);if(T.gold[i])ex.push(`gold every <b>${T.gold[i]}</b>`);
  if(st)st.insertAdjacentHTML('afterend',`<div class="rplx">${ex.join(' · ')}</div>`);
  const hgt=el.offsetHeight||420;el.style.top=rpClamp(tw.y-hgt*.62,76,770-hgt)+'px'}catch(e){console.error(e)}return r}}
/* key P picks it */
{const k0=rpKeyDown;window.removeEventListener('keydown',rpKeyDown,true);rpKeyDown=function(e){const R=RPX;if(R&&S.rp&&S.mode==='ramparts'&&!R.pause&&!R.over&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&e.key.length===1&&e.key.toLowerCase()==='p'){e.preventDefault();e.stopImmediatePropagation();if(!e.repeat)rpPlace('still');return}return k0.apply(this,arguments)};window.addEventListener('keydown',rpKeyDown,true)}
/* nine buttons in the build ring: a wider arc so they keep their spacing */
{const g0=rpHudRing;rpHudRing=function(R,C){const was=C.rg;const r=g0.apply(this,arguments);try{if(C.rg!==was&&C.rg){const bs=[...$('rpring').querySelectorAll('.rprb')],p=R.selPad;if(bs.length>=9)bs.forEach(b=>{for(const v of ['--x','--y']){const n=parseFloat(b.style.getPropertyValue(v));if(isFinite(n))b.style.setProperty(v,(n*1.12).toFixed(1)+'px')}});
  /* keep the whole ring on the stage: slide it sideways off the left and right edges */
  if(p&&bs.length){const xs=bs.map(b=>p.x+(parseFloat(b.style.getPropertyValue('--x'))||0)),lo=Math.min(...xs)-46,hi=Math.max(...xs)+46,dx=lo<0?-lo:hi>1600?1600-hi:0;
   if(dx)bs.forEach(b=>b.style.setProperty('--x',((parseFloat(b.style.getPropertyValue('--x'))||0)+dx).toFixed(1)+'px'))}}}catch(e){console.error(e)}return r}}
/* nine tiles in the bar: narrower still */
{const st=document.createElement('style');st.textContent=`.rph.rp7.rp8.rp9 .rpbar{gap:4px}.rph.rp7.rp8.rp9 .rpcard{width:90px}.rph.rp7.rp8.rp9 .rpct>b{max-width:86px;font-size:12.5px}.rph.rp7.rp8.rp9 .rpcard img{width:70px;height:70px;margin-left:-35px;top:-20px}
.rplx{margin:6px 0 2px;font:600 12px Poppins,system-ui,sans-serif;color:#cfe9c8;line-height:1.35}.rplx b{color:#7dff6a}`;document.head.appendChild(st)}
{const h0=rpHudOn;rpHudOn=function(){const r=h0.apply(this,arguments);try{const h=$('rphud');if(h&&RP_TWORDER.length>=9)h.classList.add('rp9')}catch(e){}return r}}
try{const h=HELP.Modes.find(x=>x[0]==='Runestone Tower Defense');if(h)h[1]+=" The Alchemist's Still (P, 220 supply) throws acid flasks that melt monsters' armor for a few seconds, so every other tower hits them harder; at tier 3 soaked monsters drop more coins."}catch(e){}
{const h0=rpHowTo;rpHowTo=function(){const r=h0.apply(this,arguments);try{const w=ov.querySelector('#rpmod .rphw');if(w)w.insertAdjacentHTML('beforeend',`<p><b>Alchemist's Still.</b> A support tower (220 supply, key P). Its acid flasks soak a stretch of road: soaked monsters lose armor for a few seconds, so every other tower hits them harder, and the puddle burns and soaks whoever walks through it. Tier 3 Midas Gold: soaked monsters drop 30% more coins. Tier 4 glue slows them. Tier 5 turns the weakest wounded monster in a splash into a pile of gold every fourth flask. Cannot hit flyers.</p>`)}catch(e){}return r}}
