import asyncio,os,sys
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();er=[]
        pg=await b.new_page(viewport={'width':1600,'height':900});pg.on('pageerror',lambda e:er.append('PE '+str(e)[:300]))
        await pg.goto('file://'+os.path.abspath('out.html'));await pg.wait_for_timeout(900);E=pg.evaluate
        await E("()=>{RS_ASK=false;title();P.petSt=2;P.pets={noct:{b:350},crab:{b:0}};P.pet='noct';P.eggs={r:1,l:0};petNorm();armory()}");await pg.wait_for_timeout(900);await pg.screenshot(path='shots/en_armory.png')
        print('armory slot',await E("()=>!!document.getElementById('arsp')"))
        await pg.click('#arsp');await pg.wait_for_timeout(800);print('to hall',await E("()=>!!document.getElementById('pth')"))
        await pg.keyboard.press('Escape');await pg.wait_for_timeout(600);print('back to armory',await E("()=>document.querySelector('h2')&&document.querySelector('h2').textContent"))
        await E("()=>catalog(title)");await pg.wait_for_timeout(600);await pg.click('.hltabs [data-ct="Pets"]');await pg.wait_for_timeout(800);print('collection->pets',await E("()=>!!document.getElementById('pth')"))
        await pg.keyboard.press('Escape');await pg.wait_for_timeout(600);print('back to collection',await E("()=>!!document.querySelector('.chl')"))
        await E("()=>title()");await pg.wait_for_timeout(500);await pg.click('#dk_pt');await pg.wait_for_timeout(700);print('sidebar',await E("()=>[!!document.getElementById('pth'),document.querySelector('#dk_pt').className]"))
        # reload during hatch: commit then reload page
        await E("()=>{petNorm();const r=petHatch('r');window.__h=r;ptHatchScene(r.id,'r',{})}");await pg.wait_for_timeout(700)
        hid=await E("()=>window.__h.id");pend=await E("()=>JSON.stringify(P.petPend)")
        await pg.reload();await pg.wait_for_timeout(1000)
        print('after reload',hid,pend,await E("()=>[JSON.stringify(P.petPend),Object.keys(P.pets).join(','),P.eggs.r]"))
        await E("()=>{RS_ASK=false;title();petHall()}");await pg.wait_for_timeout(900);print('reveal shown',await E("()=>!!document.getElementById('pthx')"),await E("()=>JSON.stringify(P.petPend)"))
        await pg.screenshot(path='shots/en_reveal.png')
        await pg.close()
        pg=await b.new_page(viewport={'width':390,'height':844});pg.on('pageerror',lambda e:er.append('PE '+str(e)[:300]))
        await pg.goto('file://'+os.path.abspath('out.html'));await pg.wait_for_timeout(900)
        await pg.evaluate("()=>{RS_ASK=false;title();P.petSt=2;P.pets={noct:{b:350}};P.pet='noct';petNorm();petHall('Pets')}");await pg.wait_for_timeout(900);await pg.screenshot(path='shots/en_phone.png')
        print(er[:6]);await b.close()
asyncio.run(main())
