/* ===== RUNESTONE RAMPARTS (Update 8.8b): data =====
   A strategy tower-defense mode: no typing. Monsters walk the roads toward the castle; towers on stone pads fire on their own; three
   abilities (Overcharge, Slow Field, Repair) recharge on cooldowns. Supply builds and upgrades towers during a run; coins are earned per
   monster, per wave and for a win, with no ceiling (Freeplay keeps paying).
   Maps fill the whole 1600x900 stage. Each map has its own twist: Mossgate Hollow one long road over a river bridge; Frostfang Pass two
   entrances that merge and icy patches that speed monsters up; Ember Crown a road that splits and rejoins, and lava vents that scorch
   monsters walking past. Code prefix rp, state RPX (95e), save P.rp via RPP(). */
const RPT={HP:20,SELL:.7,EARLY:3,BUILD_T:15,BUILD_ANIM:.9,UP_ANIM:.7,FIRSTDAY:1.5,
 AB:{over:{cd:45,dur:10,k:2.4,n:'Overcharge',key:'1',desc:'A tower fires 2.4x faster for 10 s.'},slow:{cd:40,dur:7,k:.45,r:100,n:'Slow Field',key:'2',desc:'Freezes a stretch of road for 7 s: monsters there move at half speed.'},
  repair:{cd:70,heal:4,n:'Repair',key:'3',desc:'Restores 4 health to the castle.'}},
 ICE_K:1.45,VENT_T:9,VENT_R:78,VENT_K:.1,
 UI:{top:108,bottom:772,castleX:1325}};
/* towers: arrays are per tier 1..3. cost[0] builds, cost[1]/cost[2] upgrade. cd = seconds between shots. ap = armor it ignores. */
const RP_TW={
 ballista:{cost:[100,150,280],range:[230,250,280],dmg:[24,44,84],cd:[.95,.8,.62],ap:[3,6,99],air:1,ground:1,
  desc:'Strong single shots. Hits flyers and pierces armor.',up:['Heavier bow: more damage and range.','Twin-rune bolts: armor no longer matters, and each bolt passes through to a second foe.']},
 brazier:{cost:[120,170,300],range:[175,190,210],dmg:[20,34,60],cd:[1.3,1.15,1.0],splash:[62,74,92],burn:[0,0,10],air:0,ground:1,
  desc:'Burning embers that splash every foe nearby. Cannot hit flyers.',up:['Wider, hotter blasts.','Triple vents: blasts leave burning ground.']},
 frost:{cost:[90,130,240],range:[160,178,198],dmg:[6,10,16],cd:[1.05,.95,.85],slow:[.36,.46,.58],slowT:[1.6,1.9,2.3],air:0,ground:1,
  desc:'Frost pulses chill and slow every ground foe in range.',up:['Colder pulse: slows harder and longer.','Frost crown: chilled foes take double damage from the pulse.']},
 bell:{cost:[110,160,290],range:[220,238,265],dmg:[24,40,70],cd:[1.15,1.0,.85],chain:[2,3,5],airK:2,air:1,ground:1,
  desc:'Lightning that chains between foes. Double damage to flyers.',up:['A second bell: longer chains.','Storm crown: five-foe chains that stun flyers.']}};
const RP_TWORDER=['ballista','brazier','frost','bell'];
/* foes: hp at wave 1 of the first map, speed px/s, bounty = supply, coin = coins paid for the kill, dmg = health lost when it gets through */
const RP_FOE={
 scamp:{hp:30,sp:96,bounty:5,coin:2,dmg:1,armor:0},
 bulwark:{hp:72,sp:54,bounty:7,coin:3,dmg:1,armor:4},
 golem:{hp:280,sp:36,bounty:18,coin:8,dmg:3,armor:9},
 gloom:{hp:44,sp:78,bounty:7,coin:3,dmg:1,armor:0,air:1},
 ooze:{hp:120,sp:48,bounty:8,coin:4,dmg:2,armor:0,split:'oozelet',splitN:2},
 oozelet:{hp:32,sp:74,bounty:2,coin:1,dmg:1,armor:0},
 shaman:{hp:96,sp:50,bounty:12,coin:5,dmg:2,armor:0,heal:.08,healR:105,healT:2.4},
 behemoth:{hp:2600,sp:24,bounty:150,coin:90,dmg:10,armor:10,boss:1}};
const RP_FOETIP={scamp:'Fast runners. Cover the road early.',bulwark:'Shielded squads. Splash from the Ember Brazier breaks them.',golem:'Heavy armor. Rune Ballista bolts pierce it.',
 gloom:'Flies over everything. Only the Rune Ballista and the Storm Bell can hit it.',ooze:'Splits in two when it pops.',oozelet:'Small, quick and squishy.',
 shaman:'Heals nearby monsters. Take it down first.',behemoth:'The boss. Slow it, focus it, and keep Repair ready.'};
/* maps. paths: every road from an entrance to the castle gate (shared stretches repeat the same points). pads are chosen from the roads. */
const RP_MAPS=[
 {id:'moss',n:'Mossgate Hollow',sub:'One long forest road',waves:10,start:300,hpk:1,spk:1,coinK:1,bonus:400,xp:120,pal:'moss',pads:12,
  twist:'A single winding road crosses the river on an old bridge.',
  paths:[[[-60,330],[120,322],[250,380],[330,500],[300,620],[400,712],[600,722],[720,640],[740,500],[690,380],[760,250],[930,190],[1080,240],[1130,380],[1080,520],[1150,660],[1300,690],[1450,628]]],
  river:[[842,-30],[876,170],[856,380],[924,560],[896,760],[958,930]]},
 {id:'frost',n:'Frostfang Pass',sub:'Two entrances, icy road',waves:15,start:340,hpk:1.45,spk:1.04,coinK:.55,bonus:600,xp:200,pal:'frost',pads:13,
  twist:'Monsters come from two caves at once, and icy patches speed them up.',
  paths:[[[-60,200],[150,210],[300,282],[400,400],[470,470],[620,470],[720,360],[700,232],[820,162],[1000,172],[1080,282],[1010,410],[1060,560],[1180,642],[1320,648],[1450,628]],
         [[-60,700],[160,690],[310,620],[420,520],[470,470],[620,470],[720,360],[700,232],[820,162],[1000,172],[1080,282],[1010,410],[1060,560],[1180,642],[1320,648],[1450,628]]],
  ice:[[690,300,46],[1040,350,46],[1250,646,48],[560,470,40]]},
 {id:'ember',n:'Ember Crown',sub:'A split road through fire',waves:20,start:380,hpk:1.9,spk:1.08,coinK:.45,bonus:900,xp:300,pal:'ember',pads:13,
  twist:'The road forks around a lava lake and rejoins; lava vents erupt and scorch any monster nearby.',
  paths:[[[-60,470],[140,470],[300,440],[380,430],[470,300],[640,212],[840,232],[960,330],[1040,430],[1150,400],[1260,470],[1310,590],[1450,628]],
         [[-60,470],[140,470],[300,440],[380,430],[480,560],[660,690],[860,662],[980,560],[1040,430],[1150,400],[1260,470],[1310,590],[1450,628]]],
  vents:[[560,262],[780,700],[1185,452]],lake:[700,450,170,110]}];
const RP_MAP=id=>RP_MAPS.find(m=>m.id===id)||RP_MAPS[0];
const RP_MAPOPEN=m=>{const i=RP_MAPS.indexOf(m);return i<=0||(RPP().stars[RP_MAPS[i-1].id]||0)>0};
/* reward track: stars across all maps unlock tower skins only found here, then the title */
const RP_SKINS=[{tw:'ballista',k:'gilded',n:'Gilded Ballista',need:2},{tw:'brazier',k:'azure',n:'Azure Brazier',need:4},{tw:'frost',k:'aurora',n:'Aurora Spire',need:6},{tw:'bell',k:'thunderking',n:'Thunderking Bell',need:8}];
const RP_TITLE_NEED=9;
/* the save */
function RPP(){let r=P.rp;const D={stars:{},best:{},wins:0,runs:0,kills:0,gold:0,skin:{},own:{},seen:0,intro:0,day:'',dayDone:{},hint:{},fp:{},tut:{}};
 if(!r||typeof r!=='object'||Array.isArray(r))r=P.rp={};
 for(const k in D)if(r[k]===undefined||typeof r[k]!==typeof D[k]||Array.isArray(r[k])!==Array.isArray(D[k]))r[k]=D[k];
 for(const m of RP_MAPS){const v=r.stars[m.id];if(v!==undefined&&!(v>=0&&v<=3))delete r.stars[m.id]}
 for(const t of RP_TWORDER){if(r.skin[t]&&r.skin[t]!=='base'&&!r.own[t+':'+r.skin[t]])r.skin[t]='base'}
 return r}
const rpStarN=()=>{const r=RPP();return RP_MAPS.reduce((a,m)=>a+(r.stars[m.id]||0),0)};
function rpSkinOf(tw){const r=RPP(),k=r.skin[tw];return k&&k!=='base'&&r.own[tw+':'+k]?k:'base'}
function rpDay(){const d=new Date();return d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate()}
/* waves: groups {id,n,gap,at}; map 1 is hand-made; later maps and Freeplay are generated */
const RP_W1=[
 [{id:'scamp',n:8,gap:1.1,at:0}],
 [{id:'scamp',n:10,gap:.9,at:0},{id:'bulwark',n:3,gap:1.6,at:6}],
 [{id:'bulwark',n:7,gap:1.0,at:0},{id:'scamp',n:6,gap:.7,at:7}],
 [{id:'gloom',n:5,gap:1.4,at:0},{id:'scamp',n:10,gap:.7,at:3}],
 [{id:'golem',n:2,gap:4,at:0},{id:'scamp',n:12,gap:.6,at:2}],
 [{id:'ooze',n:3,gap:2.4,at:0},{id:'bulwark',n:8,gap:.9,at:4}],
 [{id:'shaman',n:2,gap:3,at:2},{id:'bulwark',n:10,gap:.8,at:0},{id:'gloom',n:6,gap:1,at:6}],
 [{id:'golem',n:4,gap:3,at:0},{id:'scamp',n:14,gap:.5,at:3},{id:'gloom',n:6,gap:.9,at:9}],
 [{id:'ooze',n:4,gap:2,at:0},{id:'shaman',n:3,gap:2.5,at:3},{id:'bulwark',n:12,gap:.7,at:5}],
 [{id:'behemoth',n:1,gap:1,at:3},{id:'bulwark',n:8,gap:.8,at:0},{id:'scamp',n:10,gap:.5,at:8},{id:'gloom',n:6,gap:1,at:12}]];
function rpWave(map,w){const W=map.waves;if(map.id==='moss'&&w<=W)return RP_W1[w-1];
 const free=w>W,f=free?w-W:0,pool=[['scamp',1,1],['bulwark',2,2],['gloom',2,3],['ooze',4,5],['golem',7,6],['shaman',6,7]].filter(p=>w>=p[2]);
 const groups=[];let at=0,bud=(14+w*7.5)*(map.id==='ember'?1.1:1)*(1+f*.12);
 const last=w===W||(free&&f%5===0);
 if(last){groups.push({id:'behemoth',n:free?1+Math.floor(f/10):1,gap:6,at:3});bud*=.55}
 let i=0;while(bud>2&&i<4){const p=pool[(w*7+i*3)%pool.length],cost=p[1],n=Math.max(2,Math.min(18,Math.round(bud/cost/(i<1?1.4:2))));
  groups.push({id:p[0],n,gap:p[0]==='golem'?2.6:p[0]==='ooze'?1.8:p[0]==='shaman'?2.2:Math.max(.42,1-w*.02),at});at+=n*.45+2;bud-=n*cost;i++}
 return groups}
const rpHpK=(map,w)=>map.hpk*(1+.12*(w-1)+.007*(w-1)*(w-1));
const rpBountyK=w=>1+.015*(w-1);
const rpWaveBonus=w=>30+6*w;
/* coins (the game's money, no ceiling): every kill, every wave cleared, and a win bonus */
const rpWaveCoins=(map,w)=>Math.round((12+4*w)*map.coinK);
const rpWinCoins=(map,stars)=>Math.round(map.bonus*(.6+.2*stars));
