/* ===== LANTERN CARAVAN 8.6: the camp hub, after the concept art =====
   Redeclares wagonMenu, wrHubDraw, wrRouteCard, wrSelect, wagonMenuRefresh (later declarations win); everything else in 93d
   (modals, workshop, route log, how-to, hitch, keys) keeps working on the same ids: #wrhub #wrgo #wrgot #wrroutes #wrws #wrlog
   #wrhelp #wrmod #wrmu #wrback #wrgold.
   Layout on the 1600x900 stage: a painted camp scene behind everything; top left the brand, the big title, a flourish and the
   tagline; under them the "Ready for departure" panel for the chosen route with its gold Start Journey button; three route cards
   with painted scene art, a lock or compass badge, three medal slots and a status line; a bar of three tiles at the bottom.
   The scene (wrCamp): sky, moon, village and a castle on its hill, a stone bridge at the right, pines framing the left and right,
   a signpost with the guild banner, crates and barrels, a lean-to awning, the wagon at 1.15x with its goblin driver and the
   conductor, the hero standing behind it with his pet, a campfire with a pot on a tripod, string lights and leaves in front.
   Static layers are baked once; live each frame: the wagon, the hero and pet, the fire, smoke, sparks and fireflies. */
const WRCG=500,WRCX=1045,WRCS=1.15,WRHX=700,WRHS=1.7,WRFX=858;
let WRCAMP=null;
/* ---------- small props ---------- */
function wrCrateProp(g,x,y,w,h,seed){g.save();g.translate(x,y);g.beginPath();g.rect(0,-h,w,h);const q=g.createLinearGradient(0,-h,w,0);q.addColorStop(0,'#b07a40');q.addColorStop(1,'#6e4220');g.fillStyle=q;g.fill();wrStroke(g,2.6);
 g.save();g.beginPath();g.rect(0,-h,w,h);g.clip();for(let k=1;k<3;k++){g.fillStyle='rgba(30,12,4,.5)';g.fillRect(0,-h+k*h/3-1,w,2)}wrGrain(g,0,-h+2,w,h/3-4,seed+3,'rgba(30,12,4,.22)');wrGrain(g,0,-h/3+2,w,h/3-4,seed+9,'rgba(30,12,4,.22)');g.restore();
 for(const [cx,cy,sx,sy] of[[0,-h,1,1],[w,-h,-1,1],[0,0,1,-1],[w,0,-1,-1]]){g.beginPath();g.moveTo(cx,cy);g.lineTo(cx+sx*11,cy);g.lineTo(cx+sx*11,cy+sy*4);g.lineTo(cx+sx*4,cy+sy*4);g.lineTo(cx+sx*4,cy+sy*11);g.lineTo(cx,cy+sy*11);g.closePath();g.fillStyle=WRIRON;g.fill();g.lineWidth=1.3;g.strokeStyle=WRO;g.stroke()}
 g.beginPath();g.rect(0,-h,w,h);wrStroke(g,2.6);wrHi(g,4,-h+4,w-12,-h+4,1.6,.3);g.restore()}
function wrBarrelProp(g,x,y,w,h){g.save();g.translate(x,y);g.beginPath();g.moveTo(3,-h+4);g.quadraticCurveTo(-4,-h/2,3,0);g.lineTo(w-3,0);g.quadraticCurveTo(w+4,-h/2,w-3,-h+4);g.closePath();const q=g.createLinearGradient(0,0,w,0);q.addColorStop(0,'#9a6434');q.addColorStop(.4,'#b47a44');q.addColorStop(1,'#6a3e1c');g.fillStyle=q;g.fill();wrStroke(g,2.6);
 g.strokeStyle='rgba(30,12,4,.4)';g.lineWidth=1.2;for(let i=1;i<5;i++){const xx=i*w/5;g.beginPath();g.moveTo(xx,-h+5);g.quadraticCurveTo(xx+(xx-w/2)*.12,-h/2,xx,0);g.stroke()}
 for(const yy of[-h+14,-14]){g.beginPath();g.moveTo(0,yy);g.quadraticCurveTo(w/2,yy+4,w,yy);g.lineWidth=6;g.strokeStyle=WRO;g.stroke();g.lineWidth=3.6;g.strokeStyle=WRIRON;g.stroke()}
 g.beginPath();g.ellipse(w/2,-h+4,w/2-3,5,0,0,TAU);g.fillStyle='#7a4a22';g.fill();wrStroke(g,2);g.restore()}
function wrStoolProp(g,x,y){g.save();g.translate(x,y);g.beginPath();g.moveTo(-14,-28);g.lineTo(-18,0);g.moveTo(14,-28);g.lineTo(18,0);g.lineWidth=7;g.strokeStyle=WRO;g.stroke();g.lineWidth=3.6;g.strokeStyle='#8a5a2c';g.stroke();g.beginPath();g.roundRect(-24,-36,48,10,4);g.fillStyle='#a06a38';g.fill();wrStroke(g,2.6);wrHi(g,-18,-33,12,-33,1.6,.3);g.restore()}
function wrMiniLantern(g,x,y,s,glow){g.save();g.translate(x,y);g.scale(s,s);if(glow){g.globalCompositeOperation='lighter';const q=g.createRadialGradient(0,12,2,0,12,46);q.addColorStop(0,'rgba(255,200,100,.55)');q.addColorStop(1,'rgba(255,170,60,0)');g.fillStyle=q;g.fillRect(-46,-34,92,92);g.globalCompositeOperation='source-over'}
 g.beginPath();g.arc(0,-4,6,Math.PI,0);g.lineWidth=4.4;g.strokeStyle=WRO;g.stroke();g.lineWidth=2;g.strokeStyle='#d9a441';g.stroke();g.beginPath();g.moveTo(-8,2);g.lineTo(8,2);g.lineTo(6,6);g.lineTo(-6,6);g.closePath();wrFill(g,'#d9a441',2);
 g.beginPath();g.roundRect(-7,6,14,18,3);g.fillStyle='#ffe9a0';g.fill();wrStroke(g,2);g.fillStyle='#ffc23a';g.beginPath();g.ellipse(0,16,2.6,5,0,0,TAU);g.fill();g.beginPath();g.rect(-8,24,16,4);g.fillStyle='#d9a441';g.fill();wrStroke(g,1.8);g.restore()}
/* the signpost with the guild banner */
function wrSignPost(g,x,y){g.save();g.translate(x,y);g.beginPath();g.rect(-6,-230,12,230);g.fillStyle='#5a3a1c';g.fill();wrStroke(g,2.6);g.beginPath();g.rect(-62,-226,124,10);g.fillStyle='#6a4422';g.fill();wrStroke(g,2.4);
 g.beginPath();g.moveTo(-46,-216);g.lineTo(46,-216);g.lineTo(46,-120);g.lineTo(0,-98);g.lineTo(-46,-120);g.closePath();const q=g.createLinearGradient(0,-216,0,-98);q.addColorStop(0,'#3a2a7a');q.addColorStop(1,'#241a56');g.fillStyle=q;g.fill();wrStroke(g,2.8);
 g.strokeStyle='#ffd45a';g.lineWidth=2.4;g.beginPath();g.moveTo(-40,-210);g.lineTo(40,-210);g.lineTo(40,-124);g.lineTo(0,-106);g.lineTo(-40,-124);g.closePath();g.stroke();
 g.beginPath();g.arc(0,-164,24,0,TAU);g.strokeStyle='#ffd45a';g.lineWidth=3;g.stroke();g.fillStyle='#ffd45a';g.beginPath();g.roundRect(-8,-180,16,22,3);g.fill();g.fillStyle='#3a2a7a';g.fillRect(-4,-175,8,13);g.fillStyle='#ffd45a';g.beginPath();g.moveTo(-10,-180);g.lineTo(10,-180);g.lineTo(6,-188);g.lineTo(-6,-188);g.closePath();g.fill();g.fillRect(-9,-158,18,4);
 g.restore()}
/* a canvas lean-to hanging off the wagon's rear rail, over the hero */
function wrAwningArt(g){const L=[650,205],R=[806,238],D=46;
 g.beginPath();g.moveTo(L[0],L[1]);g.lineTo(R[0],R[1]);g.lineTo(R[0],R[1]+D);for(let i=1;i<=7;i++){const u=1-i/7,x=L[0]+(R[0]-L[0])*u,y=L[1]+(R[1]-L[1])*u+D+(i%2?6:0);g.lineTo(x,y)}g.lineTo(L[0],L[1]+D);g.closePath();
 const q=g.createLinearGradient(0,L[1],0,L[1]+D+30);q.addColorStop(0,'#e8d6a8');q.addColorStop(1,'#b89a66');g.fillStyle=q;g.fill();wrStroke(g,3);
 g.save();g.clip();g.strokeStyle='rgba(90,60,30,.28)';g.lineWidth=1.6;for(let i=1;i<5;i++){const u=i/5,x=L[0]+(R[0]-L[0])*u,y=L[1]+(R[1]-L[1])*u;g.beginPath();g.moveTo(x,y);g.lineTo(x,y+D+10);g.stroke();g.setLineDash([4,4]);g.beginPath();g.moveTo(x+3,y);g.lineTo(x+3,y+D+10);g.stroke();g.setLineDash([])}
 const sh=g.createLinearGradient(L[0],0,R[0],0);sh.addColorStop(0,'rgba(255,255,255,.12)');sh.addColorStop(1,'rgba(20,6,40,.22)');g.fillStyle=sh;g.fillRect(L[0],L[1]-10,R[0]-L[0],D+40);g.restore();
 g.beginPath();g.moveTo(L[0],L[1]-1);g.lineTo(R[0],R[1]-1);g.lineWidth=5;g.strokeStyle=WRO;g.stroke();g.lineWidth=2.6;g.strokeStyle='#8a5a2c';g.stroke();
 g.beginPath();g.moveTo(L[0],L[1]+D-4);g.lineTo(R[0],R[1]+D-4);g.lineTo(R[0],R[1]+D+12);for(let i=0;i<=10;i++){const u=1-i/10,x=L[0]+(R[0]-L[0])*u,y=L[1]+(R[1]-L[1])*u+D+12+Math.sin(i*Math.PI)*5;g.lineTo(x,y)}g.lineTo(L[0],L[1]+D-4);g.closePath();g.fillStyle='#3a2a7a';g.fill();wrStroke(g,2.6);
 g.strokeStyle='#ffd45a';g.lineWidth=1.6;g.setLineDash([5,4]);g.beginPath();g.moveTo(L[0],L[1]+D+1);g.lineTo(R[0],R[1]+D+1);g.stroke();g.setLineDash([]);
 /* the pole and its guy rope to a stake */
 g.beginPath();g.rect(L[0]-5,L[1]-4,10,CGYA(L[1]));g.fillStyle='#5a3a1c';g.fill();wrStroke(g,2.4);
 g.beginPath();g.moveTo(L[0]+2,L[1]+4);g.quadraticCurveTo(L[0]-30,L[1]+120,L[0]-64,WRCG-6);g.lineWidth=3.4;g.strokeStyle=WRO;g.stroke();g.lineWidth=1.8;g.strokeStyle='#d8c090';g.stroke();
 g.beginPath();g.moveTo(L[0]-64,WRCG-14);g.lineTo(L[0]-64,WRCG+2);g.lineWidth=6;g.strokeStyle=WRO;g.stroke();g.lineWidth=3;g.strokeStyle='#8a5a2c';g.stroke()}
const CGYA=y=>WRCG-y+4;
/* ---------- the static scene ---------- */
function wrCamp(){if(WRCAMP)return WRCAMP;const B=wrBake(WR_RT('mill')),mk=()=>{const c=document.createElement('canvas');c.width=1600;c.height=900;return c},bg=mk(),fg=mk(),aw=mk(),g=bg.getContext('2d');g.lineJoin='round';g.lineCap='round';
 g.drawImage(B.sky,0,0);{const q=g.createLinearGradient(0,0,0,640);q.addColorStop(0,'rgba(20,40,120,.22)');q.addColorStop(1,'rgba(20,40,120,0)');g.fillStyle=q;g.fillRect(0,0,1600,640)}
 g.drawImage(B.ridge,0,196);g.drawImage(B.far,-165,138);
 /* the castle on its hill, with a lit path winding down to the bridge */
 g.fillStyle='#1c1648';g.beginPath();g.ellipse(1470,372,250,62,0,Math.PI,0);g.fill();abCastle(g,1470,372,.6,'#241c58','#ffd37a','#ffb860');
 for(let i=0;i<14;i++){const px=1450-i*24+Math.sin(i*.9)*14,py=376+i*8;glow(g,px,py,15,'#ffc86a88');g.fillStyle='#ffe9a8';g.beginPath();g.arc(px,py,2,0,TAU);g.fill()}
 /* tall pines framing the scene */
 for(const [x,h] of[[30,640],[120,520],[230,420],[1560,600],[1500,470]])abPine(g,x,WRCG+30,h,'#050c1a');
 /* the bridge at the right: parapet, lantern posts, deck */
 for(let x=1236;x<1700;x+=480){g.drawImage(B.wall,x,WRCG-150);g.drawImage(B.deck,x,WRCG)}
 for(const px of[1236+240,1236+480+240]){g.save();g.globalCompositeOperation='lighter';g.globalAlpha=.9;g.drawImage(B.postGlow,px-130,WRCG-268-130);g.restore();wrMiniLantern(g,px,WRCG-262,1.4,false)}
 /* grass bank and trodden earth under the camp */
 {const q=g.createLinearGradient(0,WRCG,0,WRCG+60);q.addColorStop(0,'#16342a');q.addColorStop(1,'#0a1a1a');g.fillStyle=q;g.fillRect(0,WRCG-6,1250,400)
  g.fillStyle='#3a2a20';g.beginPath();g.ellipse(930,WRCG+6,430,16,0,0,TAU);g.fill();g.fillStyle='#4a3626';g.beginPath();g.ellipse(930,WRCG+4,360,10,0,0,TAU);g.fill();
  for(let i=0;i<70;i++){const x=rnd(i+11)*1250,y=WRCG-4+rnd(i+31)*30;g.strokeStyle=i%3?'#1e4a34':'#2a5a3a';g.lineWidth=1.6;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+3,y-8,x+(rnd(i)-.5)*8,y-12-rnd(i+2)*8);g.stroke()}
  for(let i=0;i<22;i++){const x=300+rnd(i+51)*900,y=WRCG+4+rnd(i+61)*12;g.fillStyle=i%2?'#5a4a58':'#6a5a68';g.beginPath();g.ellipse(x,y,5+rnd(i)*6,3+rnd(i+1)*3,0,0,TAU);g.fill()}}
 g.fillStyle='#17122e';g.fillRect(1236,WRCG+120,400,300);g.fillStyle='#120e26';g.fillRect(1236,WRCG+150,400,300);
 wrSignPost(g,1566,WRCG+8);
 /* crates, barrels and a stool around the camp */
 wrCrateProp(g,560,WRCG+4,66,56,3);wrCrateProp(g,586,WRCG-52,52,46,17);wrBarrelProp(g,632,WRCG+4,40,52);
 wrCrateProp(g,1300,WRCG+6,74,60,23);wrCrateProp(g,1330,WRCG-54,56,48,31);wrBarrelProp(g,1392,WRCG+6,42,56);wrCrateProp(g,1440,WRCG+6,50,40,41);wrStoolProp(g,1480,WRCG+6);
 /* the lean-to */
 const a=aw.getContext('2d');a.lineJoin='round';a.lineCap='round';wrAwningArt(a);
 /* in front: leaves top left and right, string lights with pennants */
 const f=fg.getContext('2d');f.lineJoin='round';f.lineCap='round';
 for(let i=0;i<150;i++){const x=rnd(i+700)*470,y=rnd(i+730)*250*(1-x/620),r=14+rnd(i+760)*22,ang=rnd(i+790)*TAU;if(y>230-x*.35)continue;f.save();f.translate(x,y);f.rotate(ang);f.fillStyle=i%4?'#0b2a22':i%3?'#103a2a':'#16482e';f.beginPath();f.ellipse(0,0,r,r*.42,0,0,TAU);f.fill();f.strokeStyle='#050f10';f.lineWidth=1.6;f.stroke();f.fillStyle='rgba(255,210,120,.12)';f.beginPath();f.ellipse(-r*.2,-r*.1,r*.5,r*.14,0,0,TAU);f.fill();f.restore()}
 for(let i=0;i<40;i++){const x=1350+rnd(i+900)*250,y=rnd(i+930)*90*(1-(x-1350)/300);if(y<2)continue;f.save();f.translate(x,y);f.rotate(rnd(i+960)*TAU);f.fillStyle='#0b2a22';f.beginPath();f.ellipse(0,0,16+rnd(i)*14,7,0,0,TAU);f.fill();f.strokeStyle='#050f10';f.lineWidth=1.4;f.stroke();f.restore()}
 /* the string lights hang behind the cast (aw layer) */
 for(const [x0,y0,x1,y1,sag,n] of[[650,203,1146,148,40,18],[1146,148,1566,226,46,14]]){a.beginPath();for(let i=0;i<=n;i++){const u=i/n,x=x0+(x1-x0)*u,y=y0+(y1-y0)*u+Math.sin(u*Math.PI)*sag;i?a.lineTo(x,y):a.moveTo(x,y)}a.lineWidth=2.4;a.strokeStyle='#1a1020';a.stroke();
  for(let i=1;i<n;i++){const u=i/n,x=x0+(x1-x0)*u,y=y0+(y1-y0)*u+Math.sin(u*Math.PI)*sag;if(i%2){a.fillStyle=i%4===1?'#5a3ab0':'#ffd45a';a.beginPath();a.moveTo(x-8,y);a.lineTo(x+8,y);a.lineTo(x,y+18);a.closePath();a.fill();a.lineWidth=1.6;a.strokeStyle=WRO;a.stroke()}else{glow(a,x,y+6,22,'#ffc86a66');a.fillStyle='#fff0b0';a.beginPath();a.arc(x,y+6,3.4,0,TAU);a.fill();a.lineWidth=1.4;a.strokeStyle=WRO;a.stroke()}}}
 return WRCAMP={bg,fg,aw,B}}
/* the campfire, in front of the wagon: logs, stones, flames in three layers, a pot on a tripod */
function wrFire(g,x,y,t,M){
 g.save();g.translate(x,y);
 /* tripod behind the flames */
 for(const dx of[-40,0,40]){g.beginPath();g.moveTo(0,-92);g.lineTo(dx,2+(dx?0:6));g.lineWidth=7;g.strokeStyle=WRO;g.stroke();g.lineWidth=3.6;g.strokeStyle='#6a4422';g.stroke()}
 g.beginPath();g.moveTo(0,-92);g.lineTo(0,-58);g.lineWidth=4.4;g.strokeStyle=WRO;g.stroke();g.lineWidth=2;g.strokeStyle='#8a8aa0';g.stroke();
 g.save();g.translate(0,-50+Math.sin(t*1.3)*.6);g.beginPath();g.moveTo(-17,-12);g.lineTo(17,-12);g.quadraticCurveTo(21,10,10,16);g.lineTo(-10,16);g.quadraticCurveTo(-21,10,-17,-12);g.closePath();const q=g.createLinearGradient(-17,0,17,0);q.addColorStop(0,'#3a3650');q.addColorStop(1,'#14101e');g.fillStyle=q;g.fill();wrStroke(g,2.6);g.beginPath();g.ellipse(0,-12,17,4.4,0,0,TAU);g.fillStyle='#2a2638';g.fill();wrStroke(g,2);wrHi(g,-12,-6,-10,8,1.8,.4);g.restore();
 /* logs and stones */
 for(const [ang,col] of[[-.32,'#5a3a1c'],[.32,'#6a4422']]){g.save();g.rotate(ang);g.beginPath();g.roundRect(-34,-8,68,13,6);g.fillStyle=col;g.fill();wrStroke(g,2.6);g.beginPath();g.ellipse(34,-1.5,3,6,0,0,TAU);g.fillStyle='#c8905a';g.fill();g.restore()}
 for(let i=0;i<9;i++){const a=i/9*TAU,sx=Math.cos(a)*44,sy=Math.sin(a)*9+4;g.beginPath();g.ellipse(sx,sy,9,6,0,0,TAU);g.fillStyle=i%2?'#7a7490':'#6a6480';g.fill();wrStroke(g,2)}
 /* flames */
 const fl=(h,w,col,ph,sx)=>{const sway=Math.sin(t*6+ph)*5*sx,hh=h*(1+.13*Math.sin(t*9+ph)+.06*Math.sin(t*15+ph*2));g.beginPath();g.moveTo(-w,0);g.quadraticCurveTo(-w*1.1,-hh*.45,sway*.4,-hh*.8);g.quadraticCurveTo(sway,-hh*1.04,sway*1.2,-hh);g.quadraticCurveTo(w*.9,-hh*.55,w,0);g.closePath();g.fillStyle=col;g.fill()};
 g.globalCompositeOperation='lighter';fl(78,30,'#d8501a',0,1);fl(60,20,'#ff9a2a',1.7,1.2);g.globalCompositeOperation='source-over';
 g.save();g.translate(-14,0);fl(46,10,'#ff8a2a',3.1,1.4);g.restore();g.save();g.translate(15,0);fl(52,11,'#ff9a30',.8,1.4);g.restore();
 fl(52,15,'#ffc23a',2.4,1.6);fl(32,8,'#fff4b0',4,1.8);
 /* a warm light on the ground and the camp */
 g.globalCompositeOperation='lighter';const pu=.9+.1*Math.sin(t*11)+.05*Math.sin(t*17);let gq=g.createRadialGradient(0,-30,6,0,-30,240*pu);gq.addColorStop(0,'rgba(255,160,60,.34)');gq.addColorStop(.5,'rgba(255,120,40,.12)');gq.addColorStop(1,'rgba(255,100,30,0)');g.fillStyle=gq;g.fillRect(-260,-270,520,360);
 g.save();g.scale(1,.16);gq=g.createRadialGradient(0,0,10,0,0,230);gq.addColorStop(0,'rgba(255,150,60,.4)');gq.addColorStop(1,'rgba(255,120,40,0)');g.fillStyle=gq;g.fillRect(-240,-230,480,460);g.restore();g.restore();
 g.restore()}
/* ---------- drawing the camp ---------- */
function wrHubDraw(g,M,t){const C=wrCamp(),R=M;R.t=t;R._dt=Math.min(.1,Math.max(.001,t-(R._lt||t)))||1/30;R._lt=t;R.x=200;R.swing=Math.sin(t*1.7)*.05;R.cond=null;
 g.setTransform(1,0,0,1,0,0);g.globalAlpha=1;g.globalCompositeOperation='source-over';g.drawImage(C.bg,0,0);
 g.drawImage(C.aw,0,0);
 /* two little lanterns under the awning */
 for(const x of[684,770]){const sw=Math.sin(t*1.3+x)*.04;g.save();g.translate(x,236);g.rotate(sw);g.beginPath();g.moveTo(0,0);g.lineTo(0,10);g.lineWidth=2;g.strokeStyle=WRO;g.stroke();g.restore();wrMiniLantern(g,x+Math.sin(t*1.3+x)*.4,246+8,1.05,!wrLow());}
 /* the wagon, bigger than in the run */
 g.save();g.translate(WRCX,WRCG);g.scale(WRCS,WRCS);g.translate(-WRT.WX,-GY);try{wrWagonDraw(g,R)}catch(e){console.error(e)}g.restore();
 /* the hero stands behind it, with his pet */
 {const b=Math.sin(t*2.3);g.save();g.translate(WRHX,WRCG);g.fillStyle='#0007';g.beginPath();g.ellipse(0,6,70,12,0,0,TAU);g.fill();glow(g,0,-110*WRHS,150,WCOL()+'22');g.scale(WRHS*(1-b*.005),WRHS*(1+b*.01));drawHero(g,{arm:P.armor,wp:P.weapon,col:P.col,t,lg:0});g.restore()}
 {const id=P.pet;if(id&&PDEF[id]){g.save();g.translate(604,WRCG+4-(PDEF[id].hover?38:0));g.scale(1.15,1.15);petDraw(g,id,Object.assign({t:t+3,pose:'idle',u:0},petLook(id)));g.restore()}}
 /* the fire and its sparks and smoke */
 wrFire(g,WRFX,WRCG+6,t,R);
 if(!R.fx)R.fx=[];if(!wrLow()&&!wrRM()){R.fT=(R.fT||0)-R._dt;if(R.fT<=0){R.fT=.07;ptBurst(R.fx,WRFX+(Math.random()-.5)*26,WRCG-40,1,['#ffc23a','#ff9a2a','#fff0b0'],{up:1,sp:.9,v:70,l:1.6,s:3,g:-40,k:'glow',jx:6});if(Math.random()<.4)ptBurst(R.fx,WRFX+(Math.random()-.5)*14,WRCG-130,1,'#9a96b0',{up:1,sp:.5,v:22,l:2.8,s:9,g:-8,k:'dust',jx:8})}}
 ptFxStep(g,R.fx,R._dt);
 /* fireflies */
 if(!wrLow()){g.save();g.globalCompositeOperation='lighter';for(let i=0;i<16;i++){const x=(rnd(i+5)*1500+t*(6+rnd(i)*8))%1500+50,y=250+rnd(i+9)*240+Math.sin(t*.8+i)*14,a=.35+.4*Math.sin(t*1.7+i*2.3);g.globalAlpha=Math.max(0,a);glow(g,x,y,14,'#c8ff9a');g.fillStyle='#f0ffd0';g.fillRect(x-1,y-1,2,2)}g.restore()}
 g.drawImage(C.fg,0,0);
 if(R.fadeT){const u=(performance.now()-R.fadeT)/420;if(u<1){g.fillStyle=`rgba(7,4,26,${(1-u)*.85})`;g.fillRect(0,0,W,H)}else R.fadeT=0}}
/* ---------- route art: the real scenes, painted into a card ---------- */
/* painted scenes for the three route cards, drawn on a 1600x900 canvas and scaled down; the lower part sits under the card's text */
const WRCARDP={
 mill:g=>{g.fillStyle=abLin(g,0,900,[[0,'#0b1a55'],[.42,'#3b3d96'],[.7,'#8a5aa2'],[1,'#e8a08c']]);g.fillRect(0,0,1600,900);abStars(g,130,7,400,'#fff',1.7);abMoon(g,1190,200,125,'#fffbe8','#e8e0c8','#fff0c088');
  const cl=abCloud('wrcc1',900,160,'#7a6ab8bb','#7a6ab800',5);g.globalAlpha=.75;g.drawImage(cl,60,110);g.drawImage(cl,700,40,760,130);g.globalAlpha=1;
  abRidge(g,520,150,1.9,'#38388a',.0042);abRidge(g,590,100,4.4,'#28286e',.006,8);
  for(let i=0;i<26;i++){const x=90+rnd(i+3)*720,y=540-rnd(i+8)*100;wrHouse(g,x,y,30+rnd(i+9)*26,34+rnd(i+11)*26,'#1e1850','#140e38',rnd(i+20)<.85?'#ffd27a':null)}
  g.fillStyle='#1e1850';g.fillRect(400,330,58,210);g.beginPath();g.moveTo(390,330);g.lineTo(429,236);g.lineTo(468,330);g.fill();g.fillStyle='#ffd27a';g.fillRect(420,384,18,28);glow(g,429,398,46,'#ffd27a99');
  abRidge(g,650,60,6.1,'#18144a',.008,10);
  g.fillStyle=abLin(g,610,900,[[0,'#1c2c70'],[1,'#080a2a']]);g.fillRect(0,610,1600,290);
  for(let i=0;i<46;i++){const x=1190+(rnd(i+1)-.5)*190*(1+rnd(i)),y=640+rnd(i+2)*220;g.fillStyle=`rgba(255,244,200,${.12+rnd(i+3)*.22})`;g.fillRect(x,y,30+rnd(i+4)*70,3)}
  /* the arched bridge */
  g.fillStyle='#2e2a64';g.fillRect(60,452,1480,190);for(let r=0;r<6;r++)for(let i=0;i<20;i++)wrBlock(g,70+i*74+(r%2?37:0),456+r*30,70,26,r%2?'#2e2a64':'#322e6a');
  for(let i=0;i<4;i++){const cx=250+i*370;g.beginPath();g.moveTo(cx-130,660);g.lineTo(cx-130,560);g.arc(cx,560,130,Math.PI,0);g.lineTo(cx+130,660);g.closePath();g.fillStyle='#0a1240';g.fill();g.lineWidth=10;g.strokeStyle='#4a4488';g.stroke();
   g.save();g.globalCompositeOperation='lighter';g.fillStyle='rgba(255,200,110,.12)';g.fillRect(cx-100,570,200,90);g.restore()}
  g.fillStyle='#4a4488';g.fillRect(40,424,1520,34);g.fillStyle='#ffffff26';g.fillRect(40,424,1520,4);g.fillStyle='#363070';g.fillRect(40,390,1520,36);for(let i=0;i<26;i++)wrBlock(g,48+i*60,394,56,28,'#363070');g.fillStyle='#4a4488';g.fillRect(40,384,1520,10);
  for(const x of[150,520,890,1260,1500]){g.fillStyle='#1a1438';g.fillRect(x-7,300,14,90);wrMiniLantern(g,x,296,2.6,true);g.save();g.globalCompositeOperation='lighter';const q=g.createLinearGradient(0,640,0,900);q.addColorStop(0,'rgba(255,190,100,.26)');q.addColorStop(1,'rgba(255,190,100,0)');g.fillStyle=q;g.fillRect(x-14,640,28,260);g.restore()}
  for(const [x,h] of[[40,640],[130,500],[1570,620],[1490,460]])abPine(g,x,720,h,'#050c1a');
  for(let i=0;i<22;i++){glow(g,rnd(i+60)*1500+50,250+rnd(i+70)*300,16,'#c8ff9a');}},
 pines:g=>{g.fillStyle=abLin(g,0,900,[[0,'#06143a'],[.45,'#12325a'],[1,'#2a5c6a']]);g.fillRect(0,0,1600,900);abStars(g,120,9,380,'#e8f0ff',1.5);abMoon(g,1280,190,104,'#fffbe8','#dfe6e8','#d0f0ff77');
  const cl=abCloud('wrcc2',900,150,'#4a6a9acc','#4a6a9a00',9);g.globalAlpha=.8;g.drawImage(cl,820,120,820,140);g.drawImage(cl,-100,60,800,130);g.globalAlpha=1;
  abRidge(g,470,160,2.2,'#173a56',.0045);abRidge(g,540,120,5.1,'#12304a',.006,10);
  for(let i=0;i<80;i++)abPine(g,rnd(i)*1600,610+rnd(i+30)*50,110+rnd(i+60)*110,'#0f2c42');
  g.globalAlpha=.55;g.drawImage(abFog('wrfg1','#8ab0d080'),0,470);g.drawImage(abFog('wrfg1','#8ab0d080'),1000,470);g.globalAlpha=1;
  for(let i=0;i<44;i++)abPine(g,rnd(i+100)*1600,700+rnd(i+130)*60,190+rnd(i+160)*120,'#0a2034');
  /* the woodcutter's cabin, lit from inside */
  const cx=1010,cy=640;g.fillStyle='#4a2e1a';g.fillRect(cx-110,cy-130,220,130);for(let k=1;k<6;k++){g.fillStyle='rgba(20,8,2,.5)';g.fillRect(cx-110,cy-130+k*22,220,2.4)}g.lineWidth=4;g.strokeStyle=WRO;g.strokeRect(cx-110,cy-130,220,130);
  g.fillStyle='#24160f';g.beginPath();g.moveTo(cx-136,cy-126);g.lineTo(cx,cy-228);g.lineTo(cx+136,cy-126);g.closePath();g.fill();g.stroke();g.fillStyle='#e8f0ff';g.beginPath();g.moveTo(cx-136,cy-126);g.lineTo(cx,cy-228);g.lineTo(cx+136,cy-126);g.lineTo(cx+120,cy-134);g.lineTo(cx,cy-210);g.lineTo(cx-120,cy-134);g.closePath();g.fill();
  g.fillStyle='#3a2418';g.fillRect(cx+62,cy-250,30,70);g.strokeRect(cx+62,cy-250,30,70);for(let i=0;i<5;i++){g.fillStyle=`rgba(190,200,220,${.5-i*.09})`;g.beginPath();g.arc(cx+78+i*12+Math.sin(i)*6,cy-268-i*30,12+i*7,0,TAU);g.fill()}
  for(const wx of[cx-72,cx+28]){glow(g,wx+22,cy-76,70,'#ffb04acc');g.fillStyle='#ffd27a';g.fillRect(wx,cy-98,44,44);g.lineWidth=3;g.strokeStyle=WRO;g.strokeRect(wx,cy-98,44,44);g.beginPath();g.moveTo(wx+22,cy-98);g.lineTo(wx+22,cy-54);g.moveTo(wx,cy-76);g.lineTo(wx+44,cy-76);g.stroke()}
  g.fillStyle='#2a1a12';g.fillRect(cx-22,cy-84,40,84);g.strokeRect(cx-22,cy-84,40,84);
  /* a lantern-lit path down to the card's corner */
  g.fillStyle='#3a2a1c';g.beginPath();g.moveTo(cx-30,cy);g.quadraticCurveTo(cx-260,cy+60,cx-520,cy+240);g.lineTo(cx-300,cy+240);g.quadraticCurveTo(cx-120,cy+60,cx+30,cy);g.closePath();g.fill();
  for(const [x,y] of[[cx-150,cy+30],[cx-330,cy+110],[cx+170,cy+10]]){g.fillStyle='#2a1c10';g.fillRect(x-4,y-70,8,70);wrMiniLantern(g,x,y-78,2.2,true)}
  for(let i=0;i<30;i++){glow(g,rnd(i+60)*1500+50,330+rnd(i+70)*320,14,'#c8ff9a')}},
 gallows:g=>{g.fillStyle=abLin(g,0,900,[[0,'#10041c'],[.42,'#4a1848'],[.78,'#b0503e'],[1,'#f09a4a']]);g.fillRect(0,0,1600,900);abStars(g,100,3,360,'#ffe8f0',1.5);abMoon(g,1180,230,138,'#fff2d8','#f0c090','#ffb07088');
  const cl=abCloud('wrcc3',900,150,'#2a0f3acc','#2a0f3a00',13);g.globalAlpha=.9;g.drawImage(cl,100,120,860,130);g.drawImage(cl,900,60,700,120);g.globalAlpha=1;
  abRidge(g,520,170,1.2,'#36143e',.004,12);abRidge(g,590,120,4.1,'#26102e',.006,12);
  g.fillStyle='#160a24';g.beginPath();g.moveTo(1010,900);g.lineTo(1010,520);g.quadraticCurveTo(1100,470,1180,450);g.lineTo(1600,430);g.lineTo(1600,900);g.closePath();g.fill();abCastle(g,1330,452,1.05,'#160a24','#ff9a5a','#ffb07a');
  g.fillStyle='#12081e';g.beginPath();g.moveTo(0,900);g.lineTo(0,470);g.lineTo(260,470);g.quadraticCurveTo(480,490,520,560);g.lineTo(560,900);g.closePath();g.fill();
  for(let i=0;i<5;i++)abDead(g,40+i*90+rnd(i)*30,478,160+rnd(i+4)*90,'#0a0414',i);
  /* the gallows */
  g.fillStyle='#0a0414';g.fillRect(300,250,16,232);g.fillRect(300,250,150,14);g.beginPath();g.moveTo(316,300);g.lineTo(358,264);g.lineTo(366,276);g.lineTo(324,314);g.closePath();g.fill();g.strokeStyle='#0a0414';g.lineWidth=4;g.beginPath();g.moveTo(436,264);g.lineTo(436,318);g.stroke();g.beginPath();g.ellipse(436,330,12,14,0,0,TAU);g.stroke();
  /* the rope bridge between the cliffs, with lanterns */
  const bx0=520,by0=520,bx1=1020,by1=500,sag=70;g.strokeStyle='#0a0414';g.lineWidth=6;for(const dy of[-46,0]){g.beginPath();for(let i=0;i<=24;i++){const u=i/24,x=bx0+(bx1-bx0)*u,y=by0+(by1-by0)*u+Math.sin(u*Math.PI)*sag+dy;i?g.lineTo(x,y):g.moveTo(x,y)}g.stroke()}
  for(let i=0;i<=24;i++){const u=i/24,x=bx0+(bx1-bx0)*u,y=by0+(by1-by0)*u+Math.sin(u*Math.PI)*sag;g.fillStyle='#0a0414';g.fillRect(x-8,y-2,16,8);if(i%3===0){g.beginPath();g.moveTo(x,y-46);g.lineTo(x,y);g.stroke()}}
  for(const u of[.25,.5,.75]){const x=bx0+(bx1-bx0)*u,y=by0+(by1-by0)*u+Math.sin(u*Math.PI)*sag-46;wrMiniLantern(g,x,y+8,2,true)}
  g.globalAlpha=.6;g.drawImage(abFog('wrfg2','#d08a9a66'),0,560);g.drawImage(abFog('wrfg2','#d08a9a66'),900,560);g.globalAlpha=1;
  for(let i=0;i<36;i++){glow(g,rnd(i+60)*1500+50,300+rnd(i+70)*380,12,'#ff9a5a')}}};
const WRCARDC={};
function wrRouteArt(cv,rt){let c=WRCARDC[rt.id];if(!c){const V=document.createElement('canvas');V.width=1600;V.height=900;const g=V.getContext('2d');g.lineJoin='round';g.lineCap='round';try{(WRCARDP[rt.id]||WRCARDP.mill)(g)}catch(e){console.error(e)}
  c=WRCARDC[rt.id]=document.createElement('canvas');c.width=478;c.height=265;const x=c.getContext('2d');x.imageSmoothingEnabled=true;x.imageSmoothingQuality='high';x.drawImage(V,0,0,1600,900,0,-2,478,269);
  const q=x.createLinearGradient(0,265*.44,0,265);q.addColorStop(0,'rgba(8,4,24,0)');q.addColorStop(1,'rgba(8,4,24,.84)');x.fillStyle=q;x.fillRect(0,0,478,265);const v=x.createLinearGradient(0,0,0,60);v.addColorStop(0,'rgba(8,4,24,.4)');v.addColorStop(1,'rgba(8,4,24,0)');x.fillStyle=v;x.fillRect(0,0,478,60)}
 const g=cv.getContext('2d');g.setTransform(1,0,0,1,0,0);g.drawImage(c,0,0)}
const wrCompass=sz=>`<svg viewBox="0 0 48 48" width="${sz}" height="${sz}" aria-hidden="true"><circle cx="24" cy="24" r="20" fill="#1a1244" stroke="#ffd45a" stroke-width="2.4"/><circle cx="24" cy="24" r="15" fill="none" stroke="#ffd45a" stroke-opacity=".5" stroke-width="1.2"/><path d="M24 7l4.4 13.6L42 24l-13.6 3.4L24 41l-4.4-13.6L6 24l13.6-3.4z" fill="#ffd45a" stroke="#12081f" stroke-width="1.4" stroke-linejoin="round"/><circle cx="24" cy="24" r="3.4" fill="#1a1244" stroke="#ffd45a" stroke-width="1.4"/></svg>`;
const wrPadlock=sz=>`<svg viewBox="0 0 48 48" width="${sz}" height="${sz}" aria-hidden="true"><circle cx="24" cy="24" r="21" fill="#140e36" stroke="#cfc4f0" stroke-width="2.4"/><rect x="14" y="22" width="20" height="15" rx="3.5" fill="#e8e0ff" stroke="#12081f" stroke-width="1.6"/><path d="M18 22v-5a6 6 0 0 1 12 0v5" fill="none" stroke="#e8e0ff" stroke-width="3.4" stroke-linecap="round"/><circle cx="24" cy="29" r="2.6" fill="#3a2a7a"/></svg>`;
const wrDiamond='<svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path d="M12 1l3.2 8.8L24 12l-8.8 3.2L12 24l-3.2-8.8L0 12l8.8-3.2z" fill="#ffd45a" stroke="#12081f" stroke-width="1.2" stroke-linejoin="round"/></svg>';
/* a medal slot: empty, or the earned bronze/silver/gold disc */
const wrSlot=(i,on)=>{const c=WR_MED[i+1].c;return `<i class="wrsl${on?' on':''}" style="--c:${c}" title="${WR_MED[i+1].n}">${on?`<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5l2 4.6 5 .5-3.8 3.4 1.1 4.9L12 15.6 7.7 18.4l1.1-4.9L5 10.1l5-.5z" fill="#12081f" fill-opacity=".55"/></svg>`:''}</i>`};
function wrRouteCard(r,w){const open=wrRouteOpen(r),m=w.med[r.id]||0,b=w.best[r.id],sel=r.id===wrSel;
 const st=open?(m?`${WR_MED[m].n} medal${b?` · best ${wrFmtT(b.t)}`:''}`:'No medal yet'):`Earn ${esc(wrNeedTxt(r.unlock).replace(/ on (.*)$/,''))} at<br>${esc((wrNeedTxt(r.unlock).match(/ on (.*)$/)||[0,''])[1])}`;
 return `<button class="wrcd${sel?' on':''}${open?'':' lock'}" data-id="${r.id}" role="option" aria-selected="${sel}" ${open?'':'aria-disabled="true"'}><canvas width="478" height="265" aria-hidden="true"></canvas>${open?'':'<i class="wrdim"></i>'}<span class="wrbadge">${open?wrCompass(46):wrPadlock(46)}</span>
  <span class="wrcdt"><b>${esc(r.n)}</b><small>${esc(r.sub)}</small><span class="wrcdm"><span class="wrsls">${[0,1,2].map(i=>wrSlot(i,m>i)).join('')}</span><em class="${open?'':'wrlk'}">${st}</em></span></span></button>`}
function wrCardsPaint(){document.querySelectorAll('#wrroutes .wrcd').forEach(b=>{const cv=b.querySelector('canvas');if(cv)try{wrRouteArt(cv,WR_RT(b.dataset.id))}catch(e){console.error(e)}})}
function wrBindCards(){const rc=$('wrroutes');if(!rc)return;rc.querySelectorAll('.wrcd').forEach(b=>{b.onclick=()=>wrSelect(b.dataset.id);b.ondblclick=()=>{wrSelect(b.dataset.id);wrHitch()}})}
function wrReadyFill(){const r=WR_RT(wrSel),n=$('wrrn'),i=$('wrri');if(n)n.textContent=r.n;if(i)i.textContent=`${r.legs} legs  •  Up to ${Math.round(r.pay*1.15*1.5).toLocaleString()} coins`}
function wrSelect(id){const r=WR_RT(id);if(!wrRouteOpen(r)){wrToastUi(`Locked · ${wrNeedTxt(r.unlock)}`);const b=document.querySelector(`.wrcd[data-id="${id}"]`);if(b&&!wrRM()){b.classList.remove('nope');void b.offsetWidth;b.classList.add('nope')}try{beep(180,.08,'sawtooth',.4)}catch(e){}return}
 const same=wrSel===id;wrSel=id;document.querySelectorAll('#wrroutes .wrcd').forEach(b=>{const on=b.dataset.id===id;b.classList.toggle('on',on);b.setAttribute('aria-selected',on)});wrReadyFill();
 if(!same){const p=$('wrready');if(p&&!wrRM()){p.classList.remove('pop');void p.offsetWidth;p.classList.add('pop')}try{beep(660,.05,'triangle',.25)}catch(e){}}
 WRM.rt=r}
function wagonMenuRefresh(){const w=WRP(),rc=$('wrroutes');if(rc){rc.innerHTML=WR_ROUTES.map(r=>wrRouteCard(r,w)).join('');wrBindCards();wrCardsPaint()}
 const ws=$('wrws');if(ws){const s=ws.querySelector('small');if(s)s.textContent=`${wrOwnedN(w)} / ${wrCosN()} looks`;const d=ws.querySelector('.fshdot');const nw=['lan','ban','paint'].some(f=>WR_COSK[f].some(k=>w.seen[f+':'+k]===0));if(d&&!nw)d.remove()}
 const lg=$('wrlog');if(lg){const s=lg.querySelector('small');if(s)s.textContent=`${w.clears} clear${w.clears===1?'':'s'} · ${wrMedN(w)} / 9 medals`}
 if(WRM.M){WRM.M.look={lan:w.lan,ban:w.ban,paint:w.paint}}}
function wrHubFit(){const r=$('wrhub');if(!r)return;const W2=ov.clientWidth||1600,H2=ov.clientHeight||900,nar=W2<1100;r.classList.toggle('wr-narrow',nar);const z=nar?1:Math.min(1,W2/1600,H2/900);r.style.zoom=z<.999?z.toFixed(3):''}
/* ---------- the hub ---------- */
function wagonMenu(back){S.mode='title';S.view='wagon';const w=WRP();if(!w.seen85){w.seen85=1;save()}if(!wrRouteOpen(WR_RT(wrSel)))wrSel='mill';const rt=WR_RT(wrSel),nw=['lan','ban','paint'].some(f=>WR_COSK[f].some(k=>w.seen[f+':'+k]===0));
 show(`<div class="wrx wrhub wrcamp" id="wrhub"><canvas id="wrhb" width="1600" height="900" aria-hidden="true"></canvas><i class="wrvig"></i>
 <div class="fstr"><span class="fsgold fsg">${fsCoin}<b id="wrgold">${P.gold.toLocaleString()}</b></span><button class="wrmu fsg" id="wrmu" aria-pressed="${ST.mute?'false':'true'}">${wrMuIc()}<span>Music: ${ST.mute?'off':'on'}</span></button><button class="fsback fsg" id="wrback"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 5l-7 7 7 7" stroke="currentColor" stroke-width="2.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>Back <kbd>Esc</kbd></button></div>
 <header class="wrhead"><p class="wrbrand"><span class="wrcomp">${wrCompass(40)}</span><span>TYPE WARRIORS</span></p><h1 class="wrtitle">Lantern Caravan</h1>
  <p class="wrflour">${wrDiamond}<u></u><span>THE CARAVAN CAMP</span><u></u>${wrDiamond}</p><p class="wrtag">Clear the road. Repair the wheels. Reach the gate.</p></header>
 <section class="wrready" id="wrready" aria-label="Chosen route"><span class="wrorn t"></span><span class="wrorn b"></span><div class="wrrdy"><span class="wrcomp">${wrCompass(40)}</span><span class="wrrl">Ready for departure</span></div>
  <h2 class="wrrn" id="wrrn">${esc(rt.n)}</h2><p class="wrri" id="wrri"></p>
  <button class="wrstart" id="wrgo"><span class="wrsi" aria-hidden="true">${wrGoIc()}</span><span id="wrgot">Start Journey</span><i>›</i></button></section>
 <div class="wrcards" id="wrroutes" role="listbox" aria-label="Routes">${WR_ROUTES.map(r=>wrRouteCard(r,w)).join('')}</div>
 <nav class="wrbar" aria-label="Caravan tools"><i class="wrbo l"><u></u>${wrDiamond}</i>
  <button class="wrbb" id="wrws"><span class="wrbi"><canvas id="wrwsc" width="120" height="96"></canvas></span><span class="wrbt"><b>Convoy Workshop</b><small>${wrOwnedN(w)} / ${wrCosN()} looks</small></span><i class="wrch">›</i>${nw?'<i class="fshdot">!</i>':''}</button>
  <button class="wrbb" id="wrlog"><span class="wrbi"><canvas id="wrlogc" width="120" height="96"></canvas></span><span class="wrbt"><b>Route Log</b><small>${w.clears} clear${w.clears===1?'':'s'} · ${wrMedN(w)} / 9 medals</small></span><i class="wrch">›</i></button>
  <button class="wrbb" id="wrhelp"><span class="wrbi"><canvas id="wrhelpc" width="120" height="96"></canvas></span><span class="wrbt"><b>How to Play</b><small>Repair or defend</small></span><i class="wrch">›</i></button>
  <i class="wrbo r">${wrDiamond}<u></u></i></nav>
 <div class="fsmod" id="wrmod" hidden></div></div>`,'fshx wrhx nosb');
 S.back=()=>{if(wrModal(null,true))return;title()};{const cn=$('cn');if(cn)cn.classList.add('dkhid')}
 WRM.rt=rt;const M=WRM.M=wrMenuState(rt);const bd=$('wrhb'),g=bd.getContext('2d');wrReadyFill();wrCardsPaint();wrBindCards();wrHubDraw(g,M,2);if(!dkRM())LIVE.push({cv:bd,fn:t=>wrHubDraw(g,M,t),slow:2});
 live('wrwsc',c=>{const x=c.getContext('2d');return t=>{x.setTransform(1,0,0,1,0,0);x.clearRect(0,0,120,96);x.save();x.translate(60,14);wrLantern(x,0,-8,.52,WR_COS.lan[w.lan]||WR_COS.lan.brass,t,Math.sin(t*1.5)*.08,0);x.restore()}});
 live('wrlogc',c=>{const x=c.getContext('2d');return t=>{x.setTransform(1,0,0,1,0,0);x.clearRect(0,0,120,96);wrMedalDraw(x,60,50,30,Math.max(1,...WR_ROUTES.map(r=>w.med[r.id]||0)),t)}});
 {const x=$('wrhelpc').getContext('2d');x.save();x.translate(60,54);wrWheel(x,0,0,28,.4,'#d9a441',false);x.restore();x.save();x.translate(60,54);x.rotate(-.5);wrIcoWrench(x,26,-26,13,'#9fd0ff');x.restore()}
 $('wrback').onclick=()=>S.back();$('wrgo').onclick=()=>wrHitch();$('wrws').onclick=()=>wrWorkshop();$('wrlog').onclick=()=>wrRouteLog();$('wrhelp').onclick=()=>wrHowTo();
 $('wrmu').onclick=()=>{try{$('mt').click()}catch(e){}wrMuSync()};
 wrHubFit()}
