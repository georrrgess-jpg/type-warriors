/* ===== 10.1e integrity marker (00a: the very first lines of the game script) =====
   98t_integrity.js tells the game's own code apart from code a cheat injects (a browser extension, the console, an injected <script>):
   it reads the call stack of every write to coins / XP / prestige and needs to know where the game script starts. mark(f) runs f with
   a frame from this line on the stack. wd: whether the page runs under browser automation (the test scripts), read from the prototype
   before anything else can patch it. */
const TWAC0=(()=>{const o={wd:false};try{const d=Object.getOwnPropertyDescriptor(Navigator.prototype,'webdriver');o.wd=!!(d&&d.get&&d.get.call(navigator))}catch(e){}
 o.mark=f=>f();
 /* the real storage functions, taken before any other script can patch them (98v writes the save back with these) */
 try{const SP=Storage.prototype;o.ls=Object.freeze({get:SP.getItem,set:SP.setItem});o.idb=window.indexedDB||null;o.rnd=crypto.getRandomValues.bind(crypto)}catch(e){}
 /* 10.1h: WebCrypto for the device key (98v keeps it as a key object the page can use but never read out) */
 try{const SC=crypto.subtle,SP=SubtleCrypto.prototype;o.sub=Object.freeze({imp:(...a)=>Reflect.apply(SP.importKey,SC,a),der:(...a)=>Reflect.apply(SP.deriveBits,SC,a)})}catch(e){o.sub=null}
 /* 10.1h: the stack formatter the guard reads cannot be swapped out for good by a later script (it stays settable, so tools keep working) */
 try{const d=Object.getOwnPropertyDescriptor(Error,'prepareStackTrace');let v=d&&'value' in d?d.value:undefined;
  Object.defineProperty(Error,'prepareStackTrace',{get(){return v},set(n){v=n},configurable:false,enumerable:false})}catch(e){}
 return Object.freeze(o)})();
