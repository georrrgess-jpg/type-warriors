/* ===== CASINO 9.8: Penalty Kings, the rules and the odds (96zq; art in 96zr, the game in 96zs) =====
   A penalty shoot-out against a monster keeper, from the owner's concept (no typing). Ten kicks alternate: odd kicks you SHOOT, even
   kicks you SAVE. Every kick you win climbs the Golden Boot ladder; lose one and the stake is gone; cash out between any two kicks.
   SHOOT: pick one of six spots (left/centre/right x top/low), then stop the swinging power needle. The keeper dives left, stays or
   dives right; his TELL (shown before you aim) points at the side he favours with the opponent's reliability. Same column = he gets
   there: low shots are saved, top shots only sometimes (corners less than the centre). Top shots can clip the bar even when struck
   cleanly; a scuffed strike (yellow) adds a miss chance and gives the keeper a little reach; a red strike skies a top shot and
   dribbles a low one.
   SAVE: the monster runs up; its TELL (run-up, hips, eyes) points at a column; dive left / stay / dive right before the strike.
   Kickers miss sometimes (top shots more). Same column = saved (top corners not always); a side dive can still reach a low middle
   shot, a centre stand can still reach a low corner.
   Pricing: a kick's win chance with the BEST play (read the tell, best spot, clean strike) is pkP(opp,k); the ladder pays
   PK_RTP / (product of those chances) rounded down, so cashing out at any rung returns at most 96% and worse play returns less.
   Every pkShot / pkSave call draws its own randomness (Math.random), after the player has committed. */
const PK_RTP=.95,PK_CAP=20000,PK_KICKS=10,PK_BET=[10,5000];
/* opponents: tell reliability (a = favoured side, b = stays centre), keeper reach on top shots, kicker miss rates */
const PK_OPP=[
 {id:'moss',n:'Mossback',t:'The orc in goal',d:'Loud tells, slow hands. A gentle climb.',col:'#7ac24a',kit:'#ff8a2a',kit2:'#c05a10',num:1,a:.6,b:.18,topC:.38,topM:.7,mT:.16,mL:.06,saveT:.82,reachS:.42,reachC:.22},
 {id:'gloop',n:'Gloop',t:'The stretchy slime',d:'Long arms, mixed tells. The classic ladder.',col:'#5ad8a0',kit:'#3a8ad8',kit2:'#1a4a9a',num:7,a:.52,b:.2,topC:.45,topM:.78,mT:.14,mL:.05,saveT:.8,reachS:.4,reachC:.2},
 {id:'grim',n:'Grimgate',t:'The rune golem',d:'Stone hands, quiet tells. Huge payouts.',col:'#9a8ac8',kit:'#7a3ad0',kit2:'#3a1a7a',num:9,a:.46,b:.22,topC:.52,topM:.85,mT:.12,mL:.04,saveT:.78,reachS:.36,reachC:.18}];
const pkOpp=id=>PK_OPP.find(o=>o.id===id)||PK_OPP[1];
const PK_BAR=.06;/* clean top shots that still clip the bar or post */
/* the keeper's dive column for a shot: T = the tell side (0 or 2) */
function pkKeeperDist(o,T){const p=[0,0,0];p[T]=o.a;p[1]=o.b;p[2-T]=1-o.a-o.b;return p}
/* chance that a shot at column c (0..2), row r (0 top, 1 low) with strike quality q ('clean'|'scuff'|'wild') scores */
function pkShotP(o,T,c,r,q){const K=pkKeeperDist(o,T);if(q==='wild')return r===0?0:K.reduce((s,p,k)=>s+(Math.abs(k-c)<=1?0:p),0);
 const miss=r===0?PK_BAR+(q==='scuff'?.14:0):(q==='scuff'?.05:0),reach=q==='scuff'?.18:0;let s=0;
 for(let k=0;k<3;k++){const kp=K[k];let saved=0;if(k===c)saved=r===1?1:(c===1?o.topM:o.topC);else if(Math.abs(k-c)===1&&r===1)saved=reach;s+=kp*(1-saved)}
 return (1-miss)*s}
/* the kicker's column for a save: T = tell column (0..2) */
function pkKickDist(o,T){const p=[0,0,0];for(let k=0;k<3;k++)p[k]=k===T?o.a+.05:(1-o.a-.05)/2;return p}
/* chance you win a save kick diving to column d (0..2) */
function pkSaveP(o,T,d){const K=pkKickDist(o,T);let s=0;for(let c=0;c<3;c++)for(const r of [0,1]){const pr=K[c]*(r===0?.45:.55),miss=r===0?o.mT:o.mL;let sv=0;
  if(d===c)sv=1;
  s+=pr*(miss+(1-miss)*sv)}return s}
/* best play per kick type (the tell side is symmetric, so T=0 for shots and T=0 for saves; a centre tell is priced too) */
function pkBest(o,kind){if(kind==='shoot'){let b=0;for(let c=0;c<3;c++)for(const r of [0,1])b=Math.max(b,pkShotP(o,0,c,r,'clean'));return b}
 /* saves: the kicker's tell is a side 80% of the time and the middle 20% (pkTell); price the average of the best answers */
 const best=T=>Math.max(...[0,1,2].map(d=>pkSaveP(o,T,d)));return .8*best(0)+.2*best(1)}
const pkKind=k=>k%2===1?'shoot':'save';/* k = 1..10 */
function pkLadder(id){const o=pkOpp(id),L=[];let pr=1;for(let k=1;k<=PK_KICKS;k++){pr*=pkBest(o,pkKind(k));L.push(Math.floor(PK_RTP/pr*100)/100)}return L}
/* resolve a shot: returns {goal, keeper:0..2, how:'goal'|'saved'|'bar'|'over'|'tipped'|'weak'} */
function pkShot(o,T,c,r,q){const K=pkKeeperDist(o,T);let u=Math.random(),k=0;for(;k<2;k++){if(u<K[k])break;u-=K[k]}
 if(q==='wild'){if(r===0)return{goal:false,keeper:k,how:'over'};return Math.abs(k-c)<=1?{goal:false,keeper:k,how:'weak'}:{goal:true,keeper:k,how:'goal'}}
 const miss=r===0?PK_BAR+(q==='scuff'?.14:0):(q==='scuff'?.05:0);if(Math.random()<miss)return{goal:false,keeper:k,how:r===0?'bar':'wide'};
 let saved=0;if(k===c)saved=r===1?1:(c===1?o.topM:o.topC);else if(Math.abs(k-c)===1&&r===1)saved=q==='scuff'?.18:0;
 if(Math.random()<saved)return{goal:false,keeper:k,how:k===c&&r===0?'tipped':'saved'};return{goal:true,keeper:k,how:'goal'}}
/* resolve a save: returns {win, col, row, how:'saved'|'miss'|'goal'} */
function pkSave(o,T,d){const K=pkKickDist(o,T);let u=Math.random(),c=0;for(;c<2;c++){if(u<K[c])break;u-=K[c]}const r=Math.random()<.45?0:1;
 if(Math.random()<(r===0?o.mT:o.mL))return{win:true,col:c,row:r,how:'miss'};
 /* 9.9c: a dive saves exactly when it goes to the column the shot goes to (top or low); a wrong dive never saves */
 return d===c?{win:true,col:c,row:r,how:'saved'}:{win:false,col:c,row:r,how:'goal'}}
/* tells: the keeper's side (0 left / 2 right, seen from the shooter) or the kicker's column, and the words for it */
const PK_TELLK={moss:['eyes drifting left','leaning on his left foot','glancing at the left post'],gloop:['wobbling to the left','stretching left','bubbling on the left side'],grim:['left rune glowing','grinding to the left','left shoulder low']};
function pkTell(o,kind){if(kind==='shoot'){const T=Math.random()<.5?0:2,base=PK_TELLK[o.id][(Math.random()*3)|0];return{T,txt:T===0?base:base.replace(/left/g,'right')}}
 const r=Math.random(),T=r<.4?0:r<.8?2:1;const W=T===1?['long run-up: blasting it down the middle','head down, straight run','eyes on the crossbar']:[['hips open to the left','eyes on the left corner','short stutter step, left'],['hips open to the right','eyes on the right corner','short stutter step, right']][T===0?0:1];
 return{T,txt:W[(Math.random()*3)|0]}}
/* the save: kick-tell sides as they appear to the KEEPER (you face the kicker, so it is mirrored in the words only) */
function pkStats(){let s=P.pk;if(!s||typeof s!=='object'||Array.isArray(s))s=P.pk={};const D={plays:0,goals:0,saves:0,shots:0,faced:0,best:0,boots:0,opp:'gloop',seen:0,won:0};
 for(const k in D)if(typeof s[k]!==typeof D[k])s[k]=D[k];if(!PK_OPP.some(o=>o.id===s.opp))s.opp='gloop';return s}
