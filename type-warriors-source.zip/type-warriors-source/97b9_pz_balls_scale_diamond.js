/* ===== 10.6 THE CROOKED CUE: Dragonscale and Diamond Brilliance (97b9, prefix pzb9, after 97b6) =====
   Two premium ball sets for the Cue Rack, painted by the shared material painter of 97b6 (pzb3Reg).
   - Dragonscale (35,000): rows of overlapping, pointed dragon scales laid on the ball's own coordinates (so they roll with it), each scale a
     little dome with a dark gap, a bright bevel and a fine glint along its edge; the colour drifts toward a neighbouring hue with the view
     angle (a metallic, iridescent sheen). Stripes: ivory-pearl scales on the caps and a coloured scale band. The 8: black scales with a thin
     molten red-gold line round every scale, an ivory disc ringed in gold. Number discs: bone ivory.
   - Diamond Brilliance (75,000): a brilliant cut. The ball's own normal is quantised into rings and sectors round the poles (stars at the
     table, kites, a girdle of small facets); every facet is flat and has its own brightness and its own flash, worked out once per ball from
     the real rotation (so the glints change as it rolls), rainbow-dispersion fire on the facet edges and corners, and up to three four-point
     star glints on the brightest facets. Solids: fancy coloured diamonds. Stripes: white diamond caps. The 8: black carbonado with white and
     violet glints and a white disc. Number discs: white diamond.
   The painter's own cost is the whole cost: no allocation inside the materials, tables built once. */
const PZB9={M:null};
/* a fast atan2 (error about 1e-5 rad); Math.atan2 was the dearest call in both materials */
function pzb9At2(y,x){const ax=x<0?-x:x,ay=y<0?-y:y,mx=ax>ay?ax:ay;if(mx<1e-9)return 0;const a=(ax>ay?ay:ax)/mx,s=a*a;let r=((-.0464964749*s+.15931422)*s-.327622764)*s*a+a;if(ay>ax)r=1.57079637-r;if(x<0)r=3.14159274-r;return y<0?-r:r}
/* the painter does not hand the rotation to prep(), so remember it (pzbPaint always runs first) */
{const f0=pzbPaint;pzbPaint=function(slot,n,M){PZB9.M=M;return f0.apply(this,arguments)}}

/* ---------------------------------------------------------------- Dragonscale */
const pzb9NCOL=13,pzb9H=Math.PI/pzb9NCOL,pzb9IH=1/pzb9H,pzb9RHO=1/(1.3*1.3);
const pzb9NC=new Int16Array(26),pzb9PW=new Float32Array(26);
for(let i=-12;i<=12;i++){const c=Math.abs(Math.cos(i*pzb9H)),nc=Math.max(3,Math.round(pzb9NCOL*c));pzb9NC[i+12]=nc;pzb9PW[i+12]=2*Math.PI/(nc*pzb9H)}
/* the neighbouring hue: the ball colour turned 48 degrees round the grey axis (set in prep, read in mat) */
let pzb9n0=0,pzb9n1=0,pzb9n2=0,pzb9NS=0;
{const a=-.8,cs=Math.cos(a),sn=Math.sin(a),k=(1-cs)/3,s3=.57735027*sn;PZB9.rot=[cs+k,k-s3,k+s3]}
function pzb9DragPrep(P,pal,n,C,is8,stripe){const R=PZB9.rot,a=R[0],b=R[1],c=R[2];
 pzb9n0=C[0]*a+C[1]*b+C[2]*c;pzb9n1=C[0]*c+C[1]*a+C[2]*b;pzb9n2=C[0]*b+C[1]*c+C[2]*a}
function pzb9DragMat(o){
 const lx=o.lx,ly=o.ly,lz=o.lz,wz=o.wz,rad=Math.sqrt(lx*lx+lz*lz),t=pzb9At2(ly,rad)*pzb9IH,i0=Math.floor(t+.5),fr=pzb9At2(lx,lz)*.15915494;
 let dd=9,xx=0,yy=0,hs=.5;
 /* the row above is checked first: it lies over the row below it, like roof tiles */
 for(let k=1;k>=-1;k--){const i=i0+k,nc=pzb9NC[i+12],u=fr*nc-((i&1)?.5:0),jn=Math.floor(u+.5),du=u-jn,y=i-t,x=du*pzb9PW[i+12]*rad,yc=y>1.2?1.2:y<-1.2?-1.2:y,d=(x*x/(1-.22*yc)+y*y)*pzb9RHO;
  if(d<1||k===-1){dd=d;xx=x;yy=y;const jw=jn<0?jn+nc:jn>=nc?jn-nc:jn;hs=pzb2Hash(jw,i,5);break}}
 const C=o.C,CP=o.CP,band=o.band,ab=o.ab,dif=o.dif;
 /* a raised plate: a lighter middle, a slope, a bright lip, then a dark gap to the next scale */
 const lip0=1-(dd>.78?dd-.78:.78-dd)*7.5,lip=lip0>0?lip0:0,gap=dd>.78?(dd-.78)*4.55:0,gp=gap>1?1:gap,
  dome=1.16-.34*dd-.06*yy+(hs-.5)*.16+lip*(.3-.12*yy),
  ri=(1-(xx<0?-xx:xx)*1.5>0?1-(xx<0?-xx:xx)*1.5:0)*(.08-.1*dd),bv=lip;
 let ks=(dome+ri)*(1-(.3+.34*o.band)*gp*gp)*(1+.1*o.ab);
 /* the sheen: toward the neighbouring hue at a glancing angle, and a little on every scale */
 let kk=.05+.4*(1-wz)+.25*(hs-.5);kk=kk<0?0:kk>.5?.5:kk;
 const br=C[0]+(pzb9n0-C[0])*kk,bg=C[1]+(pzb9n1-C[1])*kk,bb=C[2]+(pzb9n2-C[2])*kk;
 let r,g,b,er=0,eg=0,eb=0;
 if(o.is8){/* black scales, a molten line round each, a faint ember in the gap */
  r=C[0]*ks*1.8;g=C[1]*ks*1.8;b=C[2]*ks*1.8;
  const m=Math.max(0,1-Math.abs(dd-.86)*6.5),m2=m*m,gp2=dd>.9?(dd-.9)*10:0;
  er=255*m2*(.5+.5*hs)+70*gp2;eg=(105+75*hs)*m2+14*gp2;eb=34*m2;
  const hi=bv*.1*(.4+dif);er+=60*hi;eg+=56*hi;eb+=50*hi}
 else{
  /* caps: ivory pearl with a faint rainbow; band (and solids): the coloured, shifting scale */
  let cr=CP[0],cg=CP[1],cb=CP[2];
  if(ab>0){const ir=ab*(1-wz)*26,a=fr*50+t*3.1;cr+=ir*pzb2Sin(a);cg+=ir*pzb2Sin(a+2.1);cb+=ir*pzb2Sin(a+4.2)}
  r=(cr+(br-cr)*band)*ks;g=(cg+(bg-cg)*band)*ks;b=(cb+(bb-cb)*band)*ks;
  /* a fine shine along the scale edges (strongest where the light is) and a bevel catch-light */
  const gl=Math.max(0,1-Math.abs(dd-.82)*7),sh=gl*gl*(.3+.7*dif),cb2=bv*(.3+.5*dif);
  const wc=ab*.7+.3;const lf=ab*38;er=(o.hr*.55+90*wc)*sh*.8+(o.hr*.3+60)*cb2*.16+lf;eg=(o.hg*.55+90*wc)*sh*.8+(o.hg*.3+60)*cb2*.16+lf*.93;eb=(o.hb*.55+90*wc)*sh*.8+(o.hb*.3+60)*cb2*.16+lf*.8;
  /* a gold line where the band meets the caps */
  if(o.edge>0){const e=o.edge*o.edge*.55;er+=210*e;eg+=160*e;eb+=70*e}}
 o.r=r;o.g=g;o.b=b;o.er=er;o.eg=eg;o.eb=eb}

pzb3Reg({id:'dragon',n:'Dragonscale',price:35000,tag:'Armour grown by dragons.',mat:pzb9DragMat,pal:{
 col:{1:[238,186,40],2:[54,110,228],3:[218,44,62],4:[136,66,202],5:[240,114,34],6:[30,162,106],7:[180,50,80],8:[12,10,16]},
 white:[246,244,236],cap:[248,242,224],disc:[240,230,202],num:[54,34,22],disc8:[252,246,226],num8:[34,20,12],ring8:[255,190,70],spec:1.25,win:.12,rim:.3,prep:pzb9DragPrep}});

/* ---------------------------------------------------------------- Diamond Brilliance */
/* rings from the pole to the equator (stars, kites, kites, kites, the girdle), sectors per ring, and the ring height as an arc */
const pzb9RS=[8,16,16,16],pzb9RO=[0,.5,0,.5],pzb9RB=[0,8,24,40],pzb9RW=[.45,.45,.4,.28],pzb9RC=[13,39,63,82],pzb9ES=[1,.899,.616,.276,0],pzb9NR=4,pzb9HF=56;
const pzb9KD=new Float32Array(112),pzb9FL=new Float32Array(112),pzb9FR=new Float32Array(112),pzb9FG=new Float32Array(112),pzb9FB=new Float32Array(112),pzb9FA=new Float32Array(112),pzb9GR=new Float32Array(112);
const pzb9SX=new Float32Array(3),pzb9SY=new Float32Array(3),pzb9SS=new Float32Array(3),pzb9WX=new Float32Array(112),pzb9WY=new Float32Array(112),pzb9WZ=new Float32Array(112);
/* four studio lights (view space) and the half vectors toward the viewer */
const pzb9LH=(()=>{const L=[[-.42,-.58,.7,1],[.7,-.3,.64,.8],[-.15,.75,.64,.7],[.1,0,1,.5]],o=[];for(const l of L){const m=Math.hypot(l[0],l[1],l[2]);let x=l[0]/m,y=l[1]/m,z=l[2]/m+1;const h=Math.hypot(x,y,z);o.push([x/h,y/h,z/h,l[3]])}return o})();
function pzb9DiamPrep(P,pal,n,C,is8,stripe){const M=PZB9.M;if(!M)return;
 const m0=M[0],m1=M[1],m2=M[2],m3=M[3],m4=M[4],m5=M[5],m6=M[6],m7=M[7],m8=M[8];
 for(let rg=0;rg<pzb9NR;rg++){const S=pzb9RS[rg],th=pzb9RC[rg]*.0174533,sn=Math.sin(th),cs=Math.cos(th);
  for(let hm=0;hm<2;hm++){const sgn=hm?-1:1,off=pzb9RO[rg]+(hm?.5:0);
   for(let si=0;si<S;si++){const f=pzb9RB[rg]+si+hm*pzb9HF,ph=((si+.5-off)/S-.5)*6.2831853,cx=sn*Math.sin(ph),cy=cs*sgn,cz=sn*Math.cos(ph),
     wx=m0*cx+m1*cy+m2*cz,wy=m3*cx+m4*cy+m5*cz,wz=m6*cx+m7*cy+m8*cz;pzb9WX[f]=wx;pzb9WY[f]=wy;pzb9WZ[f]=wz;
    const lam=wx*-.42+wy*-.58+wz*.7,hs=pzb2Hash(f,3,11);let gl=0;
    for(let q=0;q<4;q++){const h=pzb9LH[q];let s=wx*h[0]+wy*h[1]+wz*h[2];s=s>0?s:0;const s2=s*s,s4=s2*s2,s8=s4*s4;gl+=s8*s8*s8*h[3]}
    pzb9KD[f]=.5+.5*(lam>0?lam:0)+.36*hs;pzb9GR[f]=hs>.5?.22:-.22;pzb9FL[f]=gl>1.3?1.3:gl;
    const p=11*wx+7*wy+4*wz;{let a=.5+.9*pzb2Sin(p),c=.5+.9*pzb2Sin(p+2.1),d=.5+.9*pzb2Sin(p+4.2);pzb9FR[f]=a<0?0:a>1?1:a;pzb9FG[f]=c<0?0:c>1?1:c;pzb9FB[f]=d<0?0:d>1?1:d}pzb9FA[f]=.3+.7*(gl>1?1:gl)}}}
 /* the three brightest facets facing us get four-point stars */
 pzb9NS=0;for(let k=0;k<3;k++){let best=-1,bv=.3;for(let f=0;f<2*pzb9HF;f++){if(pzb9WZ[f]<.3||pzb9FL[f]<=bv)continue;let ok=1;for(let q=0;q<pzb9NS;q++){const dx=pzb9WX[f]-pzb9SX[q],dy=pzb9WY[f]-pzb9SY[q];if(dx*dx+dy*dy<.3){ok=0;break}}if(ok){best=f;bv=pzb9FL[f]}}
  if(best>=0){pzb9SX[pzb9NS]=pzb9WX[best];pzb9SY[pzb9NS]=pzb9WY[best];const s=(bv-.3)*1.7;pzb9SS[pzb9NS++]=s>1?1:s}}}
function pzb9DiamMat(o){
 const lx=o.lx,ly=o.ly,lz=o.lz,ay=o.ay,rad=Math.sqrt(lx*lx+lz*lz),south=ly<0,ph=pzb9At2(lx,lz)*.15915494+.5,q=ph*16;
 /* the ring boundaries zigzag (a tooth per sector pair, each boundary half a tooth off the one before) so the rings break into kites and stars */
 const q1=q-(q|0),q2=q1<.5?q1:1-q1,q3=q1>.5?q1-.5:q1+.5,q4=q3<.5?q3:1-q3,z1=(q2-.25)*4*.075,z2=(q4-.25)*4*.07,z3=(q2-.25)*4*.06;
 const B1=.899+z1,B2=.616-z2,B3=.276+z3;let rg=0,U=1,Lo=B1;
 if(ay<B1){rg=1;U=B1;Lo=B2;if(ay<B2){rg=2;U=B2;Lo=B3;if(ay<B3){rg=3;U=B3;Lo=0}}}
 const fr=(U-ay)/(U-Lo),S=pzb9RS[rg];
 let fs=ph*S+pzb9RO[rg]+(south?.5:0);let si=fs|0;fs-=si;if(si>=S)si-=S;
 const f=pzb9RB[rg]+si+(south?pzb9HF:0),fl=pzb9FL[f],fa=pzb9FA[f],
  dr=(fr<.5?fr:1-fr)*pzb9RW[rg],es=(fs<.5?fs:1-fs)*6.2831853*rad/S,e=dr<es?dr:es,le=1-e*34,cn=1-(dr*dr+es*es)*1200,
  kd=pzb9KD[f]*(1+pzb9GR[f]*(fr-.5)),C=o.C,band=o.band,dif=o.dif,lt=.66+.34*dif,fR=pzb9FR[f],fG=pzb9FG[f],fB=pzb9FB[f];
 let r,g,b,er=0,eg=0,eb=0;
 if(o.is8){/* carbonado: black stone, white and violet flashes */
  const k=kd*lt*2;r=C[0]*k;g=C[1]*k;b=C[2]*k;
  const ff=fl*.5*.4;er=(140+70*fR)*ff;eg=(100+60*fG)*ff;eb=(200+50*fB)*ff;
  if(le>0){const ee=le*(.3+.4*fl);er+=150*ee;eg+=115*ee;eb+=215*ee}
  if(cn>0){const c=cn*fa;er+=178*c;eg+=141*c;eb+=204*c}}
 else{
  /* white diamond caps: cool grey-blue in the shade of a facet, white in the light; the band: the fancy colour. Flat per facet. */
  let t=(kd-.45)*1.5;t=t<0?0:t>1?1:t;const lc=.86+.14*dif,cr=(176+79*t)*lc,cg=(200+55*t)*lc,cb=(236+19*t)*lc,k=kd*lt;
  r=cr+(C[0]*k-cr)*band;g=cg+(C[1]*k-cg)*band;b=cb+(C[2]*k-cb)*band;
  /* the flash: tinted by the stone on the band, white on the caps */
  const ab=1-band,ffl=fl*(band?.5:.22),tr=band*(C[0]*.55+120)+ab*255,tg=band*(C[1]*.55+120)+ab*255,tb=band*(C[2]*.55+120)+ab*255;er=tr*ffl;eg=tg*ffl;eb=tb*ffl;
  /* facet edges: a bright line in the stone's lightest tint (on the caps a cool grey line), rainbow fire where a facet is flashing, fire at the corners */
  if(le>0){const eL=le*(.45+.4*kd)*.5*band,ef=le*fa*112;
   r-=ab*le*.3*r;g-=ab*le*.22*g;b-=ab*le*.1*b;
   er+=(o.hr*.45+100)*eL+fR*ef;eg+=(o.hg*.45+100)*eL+fG*ef;eb+=(o.hb*.45+100)*eL+fB*ef}
  if(cn>0){const c=cn*fa;er+=(fR*230+40)*c;eg+=(fG*230+40)*c;eb+=(fB*230+40)*c}
  if(o.edge>0){const q=o.edge*o.edge*.6;er+=235*q;eg+=240*q;eb+=255*q}}
 /* four-point stars on the brightest facets, screen aligned, white with a hint of fire */
 for(let q=0;q<pzb9NS;q++){const s=pzb9SS[q];const dx=o.wx-pzb9SX[q],dy=o.wy-pzb9SY[q],ax=dx<0?-dx:dx,ay2=dy<0?-dy:dy;
  if(ax>.34||ay2>.34)continue;let a1=1-ax*3.6,a2=1-ay2*24,b1=1-ay2*3.6,b2=1-ax*24,core=1-(ax*ax+ay2*ay2)*200;a1=a1>0?a1*a1:0;b1=b1>0?b1*b1:0;a2=a2>0?a2:0;b2=b2>0?b2:0;core=core>0?core:0;
   const st=(a1*a2+b1*b2+core)*s;if(st>0){const w=o.is8?.85:1;er+=250*st*w;eg+=240*st*w;eb+=255*st*w}}
 o.r=r;o.g=g;o.b=b;o.er=er;o.eg=eg;o.eb=eb;o.metal=1}

pzb3Reg({id:'diamond',n:'Diamond Brilliance',price:75000,tag:'Cut like the finest diamond in the vault.',mat:pzb9DiamMat,pal:{
 col:{1:[255,206,24],2:[28,104,255],3:[244,34,64],4:[162,50,250],5:[255,120,8],6:[14,200,104],7:[138,24,50],8:[8,7,12]},
 white:[248,250,255],cap:[250,252,255],disc:[255,255,255],num:[18,22,60],disc8:[252,252,255],num8:[14,10,30],ring8:[190,150,255],spec:1.2,win:.14,rim:.35,prep:pzb9DiamPrep}});
