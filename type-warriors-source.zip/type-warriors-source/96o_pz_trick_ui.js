/* ===== 9.4 THE CROOKED CUE: Trick Shots, the screens and the one-shot flow (96o) =====
   The puzzle list, the puzzle itself (it reuses the match screen: Granny Moldwick coaches, one shot at a time, the layout resets on a miss),
   stars by tries, a one-time 200 gold for the first 3 stars on a puzzle. Data and the judge are in 96n. */
const PZ_TRICK_SAY={miss:['Try again, dear.','Almost, dear. Almost.','Chin up, sweetheart.',"The table's a little crooked, isn't it?"],win:['Lovely shot, dear!','Oh my! Well done!','Pure mischief. I love it.','Now THAT is how it is done.']};
const pzTrickStars=n=>Math.max(0,Math.min(3,PZS().trick[n]|0));
function pzTrickTotal(){let s=0;for(let i=0;i<PZ_TRICK.length;i++)s+=pzTrickStars(i);return s}
function pzTrick(){PZ.on=false;PZ.hub=true;CAS.on=true;CAS.key=null;CAS.tok++;pzCastInit('moldwick');try{pzMusicOn()}catch(e){}const Z=PZS();pzbSetup(52,Z.balls);
 const card=(t,i)=>{const s=pzTrickStars(i);return `<button class="pzti" data-i="${i}"><div class="pztm"><div class="pztf">${[0,1,2,3,4,5].map(k=>`<s style="left:${[0,50,100,0,50,100][k]}%;top:${k<3?0:100}%"></s>`).join('')}${t.balls.map(([id,x,y])=>`<img src="${pzbIcon(id,16)}" style="left:${x/8.8}%;top:${y/4.4}%" alt="">`).join('')}<i style="left:${t.cue[0]/8.8}%;top:${t.cue[1]/4.4}%"></i></div></div><b>${i+1}. ${t.n}</b><span>${pzTrickGoalText(t)}</span><p>${t.hint}</p><em class="st${s}">${'★'.repeat(s)}<u>${'★'.repeat(3-s)}</u></em></button>`};
 show(`<div class="pzk pzt" id="pzk"><canvas id="pzkbg" width="1600" height="900"></canvas><button class="pzback" id="pzbk">‹&nbsp; The bar</button><div class="pzgold"><i></i><b>${cmn(P.gold)}</b></div>
  <div class="pztitle sm">Trick Shots</div><div class="pztsub">${pzTrickTotal()} of ${PZ_TRICK.length*3} stars · solve it in 3 tries for 3 stars, 8 tries for 2 · 3 stars the first time pays 200 gold</div>
  <div class="pztgrid">${PZ_TRICK.map(card).join('')}</div></div>`,'casbg pzx');
 $('pzkbg').getContext('2d').drawImage(pzHubBake(),0,0);$('pzbk').onclick=()=>pzHub();S.back=()=>pzHub();
 ov.querySelectorAll('.pzti').forEach(b=>b.onclick=()=>{pzFx('tick');pzMusicOff();pzStart({trick:+b.dataset.i})});pzFitTM()}
/* ---------- the puzzle ---------- */
function pzTrickStart(n){if(!(n>=0&&n<PZ_TRICK.length))return false;const R=PZ_REG.moldwick;PZ.tok++;const tok=PZ.tok;PZ.on=true;PZ.hub=false;CAS.on=true;CAS.key=null;PZ.reg=R;PZ.seed=n*977+13;PZ.rng=pzRng(PZ.seed);PZ.paused=false;PZ.lite=false;PZ.silent=false;
 PZ.M=pzMatchNew({opp:'moldwick',stake:0,mult:1,race:1,practice:true,house:{},breaker:0});const M=PZ.M;M.bonus=0;M.t0=Date.now();M.trick={n,tries:0,done:false,stars:0};PZ.lastPow=.5;PZ.rattled=0;PZ.tauntOffer=false;PZ.nextTaunt=false;PZ.trickReset=false;PZ.st=null;PZ.B=null;
 pzCastInit('moldwick');PZ.dim=false;pzMount(R,tok);const m=$('pzm');if(m)m.classList.add('trick');pzTrickLoad(true);return true}
function pzTrickLoad(first){const M=PZ.M,T=PZ_TRICK[M.trick.n],B=[];for(let id=0;id<16;id++)B.push({id,x:0,y:0,on:false,vx:0,vy:0,ux:0,uy:0,es:0});
 B[0].x=T.cue[0];B[0].y=T.cue[1];B[0].on=true;for(const [id,x,y] of T.balls){B[id].x=x;B[id].y=y;B[id].on=true}
 PZ.B=B;pzbInitBalls(B,pzRng(PZ.seed+M.trick.tries));const st=PZ.st=pzrNew(B,0,{});st.brk=false;st.open=true;st.bih=false;st.kitchen=false;st.turn=0;
 PZ.tray=[];PZ.drops=[];PZ.fx=[];PZ.rings=[];PZ.flashes=[];PZ.floats=[];PZ.ev=[];PZ.cueA=0;PZ.call=-1;PZ.trickReset=false;PZ.slow=null;PZ.ts=1;PZ.tsT=1;PZ.slowDone=false;PZ.hitStop=0;PZ.crack=false;
 const rm=pzRM();PZ.rk={t:0,items:B.map((b,i)=>({id:b.id,delay:b.id===0?.35:.05+i*.06,done:false})),notri:true,dur:rm?.3:(first?1.15:.85)};for(const b of B)b.fly=rm?null:{t:-1};
 PZ.vis=true;PZ.ph='rerack';PZ.pht=0;PZ.mode=null;pzCastReact('hero','neutral');pzCastReact('mon','neutral');pzCastLean('hero',0);pzCastLean('mon',0);pzHudAll()}
function pzTrickTurn(){const st=PZ.st,B=PZ.B,M=PZ.M,T=PZ_TRICK[M.trick.n];if(PZ.trickReset){pzTrickLoad(false);return}
 PZ.who=0;st.turn=0;PZ.cueA=0;PZ.call=-1;PZ.callManual=false;PZ.clockOn=false;PZ.stroke=null;PZ.shotFired=false;pzCastLean('hero',1);pzCastLean('mon',0);
 const tg=B[T.goal.first!=null?T.goal.first:T.goal.pot[0]],ang=Math.atan2(tg.y-B[0].y,tg.x-B[0].x);
 PZ.ph='aim';PZ.mode='aim';PZ.aim={ang,pow:.55,a:0,b:0};PZ.moved=false;PZ.fineOff=0;PZ.lastPtr=null;PZ.cueAng=ang;PZ.cueAv=0;PZ.pull=0;PZ.drag=null;PZ.place=null;PZ.canPick=false;
 if(!M.trick.said||M.trick.tries===0&&!M.trick.said){M.trick.said=1;pzSay(T.hint,6500)}
 pzBanner(M.trick.tries?`Try ${M.trick.tries+1}`:`Trick shot ${M.trick.n+1}`,'turn',900);pzSpinDraw();pzHudBar();pzHudAll()}
function pzTrickJudge(){const M=PZ.M,T=M.trick,G=PZ_TRICK[T.n],Z=PZS();PZ.slowDone=false;pzLetterbox(false);PZ.tsT=1;PZ.cueA=0;T.tries++;
 const r=pzTrickCheck(G.goal,PZ.ev,PZ.B);PZ.rep={foul:false,pk:[],keep:false};
 if(!r.ok){pzBanner(r.why,'foul',1500);pzFx('foul');pzCastReact('hero','sad',900);pzCastReact('mon','smug',1300);pzSay(pzPick(PZ_TRICK_SAY.miss,PZ.rng),1800);PZ.trickReset=true;PZ.ph='gap';PZ.pht=0;PZ.gapT=1.5;pzHudAll();return}
 const stars=T.tries<=3?3:T.tries<=8?2:1,old=Z.trick[T.n]|0;T.stars=stars;T.done=true;if(stars>old)Z.trick[T.n]=stars;
 let pay=0;if(stars===3&&!Z.trick['$'+T.n]){Z.trick['$'+T.n]=1;pay=200;try{ecSrc('pool',()=>{P.gold+=pay;balUp(pay)})}catch(e){P.gold+=pay}}
 save();try{stat('pztrick',PZ_TRICK.every((_,i)=>pzTrickStars(i)===3)?1:0,'set')}catch(e){}try{achCheck()}catch(e){}
 pzBanner(stars===3?'PERFECT!':stars===2?'Nice shot!':'Got it!','gold',1600);pzFx(stars===3?'golden':'rackwin');pzCastReact('hero','cheer',2000);pzCastReact('mon','cheer',2000);pzSay(pzPick(PZ_TRICK_SAY.win,PZ.rng),2200);
 if(!pzRM())pzCoinBurst(PZ_G.x+PZ_PHY.W*.5,PZ_G.y+PZ_PHY.H*.5,stars*5);pzFloat(800,430,'★'.repeat(stars),'#ffd45a');
 PZ.ph='trickdone';PZ.pht=0;pzHudAll();setTimeout(()=>{if(PZ.on&&PZ.M===M&&PZ.ph==='trickdone')pzTrickDone(stars,pay)},1500)}
function pzTrickDone(stars,pay){const M=PZ.M,n=M.trick.n,last=n>=PZ_TRICK.length-1;PZ.paused=false;
 const m=pzModal(`<div class="pzh2" style="color:#ffd45a">${stars===3?'Perfect!':'Solved!'}</div><div class="pztst">${'★'.repeat(stars)}<u>${'★'.repeat(3-stars)}</u></div><p class="pzmm">${PZ_TRICK[n].n} · ${M.trick.tries} ${M.trick.tries===1?'try':'tries'}${pay?` · <b>+${pay} gold</b> for the first 3 stars`:''}</p>
  ${last?'':`<button class="pzmb gold" data-a="next">Next trick shot</button>`}<button class="pzmb ${last?'gold':''}" data-a="again">${stars<3?'Try for 3 stars':'Play it again'}</button><button class="pzmb" data-a="list">All trick shots</button>`,'pause');
 if(!m)return;const go=f=>()=>{pzModalClose();f()};
 const nx=m.querySelector('[data-a=next]');if(nx)nx.onclick=go(()=>pzStart({trick:n+1}));m.querySelector('[data-a=again]').onclick=go(()=>pzStart({trick:n}));m.querySelector('[data-a=list]').onclick=go(()=>pzTrickLeave());
 S.back=()=>m.querySelector('[data-a=list]').click()}
function pzTrickLeave(){PZ.tok++;PZ.on=false;PZ.ph='';PZ.M=null;try{pzLetterbox(false)}catch(e){}pzTrick()}
function pzTrickPause(){PZ.paused=true;const M=PZ.M,T=PZ_TRICK[M.trick.n],m=pzModal(`<div class="pzh2">Paused</div><p class="pzmm">Trick shot ${M.trick.n+1}: ${T.n}<br>${pzTrickGoalText(T)}</p><button class="pzmb gold" data-a="resume">Resume</button><button class="pzmb" data-a="hint">Hint</button><button class="pzmb" data-a="restart">Restart the puzzle</button><button class="pzmb" data-a="list">All trick shots</button>`,'pause');
 S.back=()=>{const b=document.querySelector('#pzmod [data-a=resume]');if(b)b.click();else if(PZ.modal)pzPauseMenu(true)};
 m.querySelector('[data-a=resume]').onclick=()=>{pzModalClose();S.back=()=>pzPauseMenu()};
 m.querySelector('[data-a=hint]').onclick=()=>{pzModalClose();S.back=()=>pzPauseMenu();pzSay(T.hint,7000)};
 m.querySelector('[data-a=restart]').onclick=()=>{pzModalClose();S.back=()=>pzPauseMenu();if(PZ.ph==='aim'){PZ.trickReset=true;pzTrickLoad(false)}};
 m.querySelector('[data-a=list]').onclick=()=>{pzModalClose();pzTrickLeave()}}
function pzTrickHud(){const M=PZ.M,T=M.trick,G=PZ_TRICK[T.n];$('pzrace').textContent=`TRICK SHOT ${T.n+1} OF ${PZ_TRICK.length}  ·  ${T.tries} ${T.tries===1?'TRY':'TRIES'}`;$('pzpot').textContent=G.n;
 $('pzsm').textContent=`Best ${'★'.repeat(pzTrickStars(T.n))||'none yet'}`;$('pzso').textContent='Trick shot host';$('pzno').textContent=PZ_REG.moldwick.n;$('pzbm').innerHTML='';$('pzbo').innerHTML='';
 $('pzcm').classList.add('turn');$('pzco').classList.remove('turn');$('pztm').textContent=PZ.ph==='aim'?'YOUR SHOT':'';$('pzto').textContent='';
 $('pzgdv').textContent=pzGuideMode()==='short'&&PZS().guide==='full'?'Short':PZS().guide==='full'?'Full':PZS().guide==='short'?'Short':'Pro';
 const h=$('pzhint');if(h)h.textContent=PZ.ph==='aim'?'Goal: '+pzTrickGoalText(G):'';$('pzbar').classList.toggle('mine',PZ.ph==='aim'&&PZ.mode==='aim');$('pzbar').classList.remove('ai')}
/* the hooks into the match engine */
{const f0=pzStart;pzStart=function(o){if(o&&o.trick!=null)return pzTrickStart(o.trick);return f0.apply(this,arguments)}}
{const f0=pzBeginTurn;pzBeginTurn=function(){if(PZ.M&&PZ.M.trick)return pzTrickTurn();return f0.apply(this,arguments)}}
{const f0=pzJudgeShot;pzJudgeShot=function(){if(PZ.M&&PZ.M.trick)return pzTrickJudge();return f0.apply(this,arguments)}}
{const f0=pzSave;pzSave=function(){if(PZ.M&&PZ.M.trick)return;return f0.apply(this,arguments)}}
{const f0=pzHudAll;pzHudAll=function(){if(PZ.on&&PZ.M&&PZ.M.trick&&$('pzm')&&PZ.st){pzTrickHud();return}return f0.apply(this,arguments)}}
{const f0=pzPauseMenu;pzPauseMenu=function(again){if(PZ.M&&PZ.M.trick){if(!PZ.on||(PZ.modal&&!again)||PZ.ph==='trickdone'||PZ.ph==='rerack')return;return pzTrickPause()}return f0.apply(this,arguments)}}
{const f0=pzSayMaybeTaunt;pzSayMaybeTaunt=function(){if(PZ.M&&PZ.M.trick)return;return f0.apply(this,arguments)}}
