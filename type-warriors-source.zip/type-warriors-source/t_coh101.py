# python3 t_coh101.py [game.html] [--base OLD_GAME.html] : coherent world maps (10.1f, 98u + the 95d / 95h / 98f / 98f2 / 98f3 / 98g3 edits).
# Everything that moves on the three hub paintings and the battle maps is sampled over time through a recorder on the 2D context
# (drawImage / paths with their transforms), so the checks run on what the layers really draw:
# water things stay on water (the painting's island / trench fields, the battle bake's water field), nothing crosses castles, labels,
# islands, mills or chimney smoke, sprites face the way they travel and stay upright, river streaks keep off the bridges, castles'
# live layers come before the things that fly in front of them, no jumps; plus no page errors and the frame cost (against --base).
import asyncio,os,sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
A=[a for a in sys.argv[1:] if not a.startswith('--')]
BASE=sys.argv[sys.argv.index('--base')+1] if '--base' in sys.argv else None
if BASE and BASE in A:A.remove(BASE)
H='file://'+os.path.abspath(A[0] if A else os.path.join(HERE,'out.html'))
if not BASE:
    for c in(os.path.join(HERE,'..','type-warriors.html'),'/home/user/type-warriors/type-warriors.html'):
        if os.path.exists(c):BASE=c;break
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:600]),flush=True)
    if not ok:FAIL.append(name)
SETUP="()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const r=RPP();r.new99j=1;r.dragon=1;r.stars=Object.assign(r.stars||{},{moss:3,frost:3,ember:3,coral:3,wreck:3,abyss:3,meadow:3,foundry:3});for(const k in r.tut)r.tut[k]=1;for(const k in RP_TUT)r.tut[k]=1;for(const m of RP_MAPS)r.tut['twist_'+m.id]=1;save()}"
HELP=r"""()=>{
 /* the recorder: every drawImage (with its transform and alpha), every stroked / filled path (points in stage coords), and markers */
 window.coRec=(fn)=>{const P=CanvasRenderingContext2D.prototype,orig={},log=[];let path=[];window.coLog=log;
  const wrap=(k,f)=>{orig[k]=P[k];P[k]=function(...a){try{f.call(this,a)}catch(e){}return orig[k].apply(this,a)}};
  const T=(c,x,y)=>{const m=c.getTransform();return[m.a*x+m.c*y+m.e,m.b*x+m.d*y+m.f]};
  wrap('drawImage',function(a){const m=this.getTransform(),img=a[0];let dx,dy,dw,dh,sx=0,sy=0;if(a.length>=9){sx=a[1];sy=a[2];dx=a[5];dy=a[6];dw=a[7];dh=a[8]}else if(a.length>=5){dx=a[1];dy=a[2];dw=a[3];dh=a[4]}else{dx=a[1];dy=a[2];dw=img.width;dh=img.height}
   const C=[[dx,dy],[dx+dw,dy],[dx,dy+dh],[dx+dw,dy+dh]].map(p=>[m.a*p[0]+m.c*p[1]+m.e,m.b*p[0]+m.d*p[1]+m.f]);
   log.push({k:'img',img,sx,sy,m:[m.a,m.b,m.c,m.d,m.e,m.f],cx:m.a*(dx+dw/2)+m.c*(dy+dh/2)+m.e,cy:m.b*(dx+dw/2)+m.d*(dy+dh/2)+m.f,
    x0:Math.min(...C.map(p=>p[0])),x1:Math.max(...C.map(p=>p[0])),y0:Math.min(...C.map(p=>p[1])),y1:Math.max(...C.map(p=>p[1])),al:this.globalAlpha})});
  wrap('beginPath',function(){path=[]});wrap('moveTo',function(a){path.push([T(this,a[0],a[1])])});
  for(const k of['lineTo'])wrap(k,function(a){if(!path.length)path.push([]);path[path.length-1].push(T(this,a[0],a[1]))});
  wrap('quadraticCurveTo',function(a){if(!path.length)path.push([]);path[path.length-1].push(T(this,a[2],a[3]))});
  wrap('stroke',function(){log.push({k:'stroke',st:String(this.strokeStyle),lw:this.lineWidth,al:this.globalAlpha,p:path.map(s=>s.slice())})});
  wrap('fill',function(){log.push({k:'fill',st:String(this.fillStyle),al:this.globalAlpha,p:path.map(s=>s.slice()),m:(m=>[m.a,m.b,m.c,m.d,m.e,m.f])(this.getTransform())})});
  try{fn()}finally{for(const k in orig)P[k]=orig[k];window.coLog=null}return log};
 /* markers: calls of the castles' live layers land in the log */
 window.coMark=(name)=>{const f=window[name];if(!f||f._co)return;const w=function(){if(window.coLog)window.coLog.push({k:'mark',n:name});return f.apply(this,arguments)};w._co=1;window[name]=w};
 ['rpCastleLive','rpw2aCastleLive','rpw3aCastleLive','rpw2aGull'].forEach(coMark);
 /* the World 1 painting's plank bridges (as painted by rpWorldArt): distance from their deck */
 window.coBrD=(x,y)=>{let d=1e9;for(const [x0,y0,x1,y1,w] of[[516,442,566,410,16],[888,260,982,258,14]]){const dx=x1-x0,dy=y1-y0,u=Math.max(0,Math.min(1,((x-x0)*dx+(y-y0)*dy)/(dx*dx+dy*dy)));d=Math.min(d,Math.hypot(x-x0-dx*u,y-y0-dy*u)-w/2)}return d};
 window.coNorm=s=>{const c=document.createElement('canvas').getContext('2d');c.fillStyle=s;return c.fillStyle};
 window.coCv=()=>{const c=document.createElement('canvas');c.width=1600;c.height=900;return c.getContext('2d')};
 window.coHit=(a,b)=>a.x0<b[2]&&a.x1>b[0]&&a.y0<b[3]&&a.y1>b[1];
 /* the hub's node labels (stage coords) for world w */
 window.coLabels=(w)=>{RPW_FORCE=w;rampartsMenu();const cv=document.getElementById('rphbg'),cr=cv.getBoundingClientRect(),k=1600/cr.width;
  return[...document.querySelectorAll('.rphub .rpnode .rpnbn > *')].map(e=>{const r=e.getBoundingClientRect();return[(r.left-cr.left)*k,(r.top-cr.top)*k,(r.right-cr.left)*k,(r.bottom-cr.top)*k]})};
 window.coBattle=(m)=>{try{rpLeave()}catch(e){}rpStart(m);const R=RPX;R.tut=null;R.hold=true;R.banner=null;R.pause=false;R.lite=false;R.rm=false;R.mx=-1;R.my=-1;const el=document.getElementById('rptut');if(el)el.style.display='none';return R};
 window.coLayers=(R,c)=>{rpAmbient(c,R);const m=R.map.id;for(const f of[RPW.twist[m],RPW.ambTop[m]])if(f){c.save();f(c,R);c.restore()}};
 return 1}"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]));pg.on('console',lambda m:er.append(m.text[:300]) if m.type=='error' and 'WebSocket' not in m.text and 'relay' not in m.text else None)
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E(SETUP);await E(HELP)
        # ================= World 1 painting =================
        r=await E("""()=>{const g=coCv();rpWorldArt(true);const st=coNorm('rgba(255,255,255,.5)');let n=0,bad=[],ord=[];
         for(let i=0;i<240;i++){const t=i*.37;const L=coRec(()=>rpWorldLive(g,t,true));
          for(const e of L)if(e.k==='stroke'&&coNorm(e.st)===st&&Math.abs(e.lw-1.6)<.01)for(const s of e.p)for(const q of s){n++;if(coBrD(q[0],q[1])<4)bad.push([t,q.map(Math.round)])}
          const lc=L.map(e=>e.k==='mark'&&e.n==='rpCastleLive').lastIndexOf(true),sp=L.findIndex(e=>e.k==='fill'&&coNorm(e.st)===coNorm('#ffb84a'));if(sp>=0&&lc>sp)ord.push(t)}
         return[n,bad.slice(0,6),bad.length,ord.length]}""")
        chk(f'World 1 painting: the river shimmer ({r[0]} streak points over 240 frames) never touches the plank bridges',r[0]>500 and r[2]==0,r)
        chk('World 1 painting: the castles\' live layer is drawn before the sparks and snow that drift in front of them',r[3]==0,r)
        # ================= World 2 painting =================
        lab2=await E("()=>coLabels(2)")
        r=await E("""(LB)=>{const g=coCv(),A=rpwWorldArt(2),W=RPW2A.world,hull=coNorm('#8a5a32'),bad=[],face=[],jump=[],cast=[];let n=0,prev=null;
         const castB=W.cast.map(it=>{const C=rpw2aCastle(it.id),s=RPW2A_WS;return{b:[it.x0+20*s,it.y0+40*s,it.x0+(C.w-20)*s,it.y0+C.h*s],base:it.y}});
         const props=[[740,380,870,465]].concat([[150,250,16],[1080,300,14],[520,440,12],[1240,640,18],[770,620,12],[60,700,14]].map(([x,y,s])=>[x-s*1.4,y-2,x+s*1.4,y+8]));
         const per=typeof RPCO!=='undefined'&&RPCO.w2s?RPCO.w2s.len/15+14:110;
         for(let i=0;i<=Math.ceil(per/.25);i++){const t=i*.25,L=coRec(()=>A.anim(g,t)),H=L.filter(e=>e.k==='fill'&&coNorm(e.st)===hull&&e.al>.02);
          if(!H.length){prev=null;continue}const P=H[0].p.flat();n++;const xs=P.map(q=>q[0]),ys=P.map(q=>q[1]),bx={x0:Math.min(...xs),x1:Math.max(...xs),y0:Math.min(...ys)-24,y1:Math.max(...ys)},cx=(bx.x0+bx.x1)/2,cy=bx.y1;
          for(const q of P){if(q[0]<0||q[0]>1600)continue;if(rpw2aIsle(q[0],q[1])>-4||rpw2aTrench(q[0],q[1])>-6)bad.push(['land',t,q.map(Math.round)])}
          for(const l of LB)if(coHit(bx,l))bad.push(['label',t,Math.round(cx),Math.round(cy)]);
          for(const p of props)if(coHit({x0:bx.x0+4,x1:bx.x1-4,y0:bx.y1-3,y1:bx.y1},p))bad.push(['prop',t,Math.round(cx),Math.round(cy),p]);
          for(const c of castB)if(c.base>cy&&coHit(bx,c.b))cast.push([t,Math.round(cx),Math.round(cy)]);
          const fx=H[0].m[0];if(prev&&Math.abs(cx-prev[0])>.4&&Math.sign(cx-prev[0])!==Math.sign(fx))face.push([t,fx,cx-prev[0]]);if(prev&&Math.hypot(cx-prev[0],cy-prev[1])>25)jump.push([t,cx,prev[0]]);prev=[cx,cy]}
         return[n,bad.slice(0,6),bad.length,face.slice(0,4),jump.slice(0,4),cast.slice(0,4)]}""",lab2)
        chk(f'World 2 painting: the ship ({r[0]} samples over a whole voyage) sails on open water only - no land, trench, rock, wreck or label under it',r[0]>200 and r[2]==0,r)
        chk('World 2 painting: the ship never overlaps a castle standing in front of it',not r[5],r[5])
        chk('World 2 painting: the ship\'s bow leads (the sprite faces the way it moves) and it never jumps',not r[3] and not r[4],r)
        r=await E("""(LB)=>{const g=coCv(),A=rpwWorldArt(2),S=rpw2aDolphinSpr();const bad=[],face=[],up=[];let n=0;
         for(let i=0;i<620;i++){const t=i*.05,L1=coRec(()=>A.anim(g,t)),L2=coRec(()=>A.anim(g,t+.02)),D1=L1.filter(e=>e.k==='img'&&e.img===S),D2=L2.filter(e=>e.k==='img'&&e.img===S);
          for(let j=0;j<D1.length&&j<D2.length;j++){const a=D1[j],b=D2[j];n++;const hx=a.m[0],hy=a.m[1],mx=b.cx-a.cx,my=b.cy-a.cy;if(hx*mx+hy*my<=0)face.push([t,a.cx|0,a.cy|0]);if(a.m[3]<=0)up.push([t,a.cx|0]);
           if(rpw2aIsle(a.cx,a.cy)>-8||rpw2aTrench(a.cx,a.cy)>-10)bad.push(['land',t,a.cx|0,a.cy|0]);for(const l of LB)if(coHit(a,l))bad.push(['label',t])}}
         return[n,face.slice(0,4),face.length,up.length,bad.slice(0,4),bad.length]}""",lab2)
        chk(f'World 2 painting: the dolphins ({r[0]} sampled frames) leap nose first in the direction they travel',r[0]>40 and r[2]==0,r)
        chk('World 2 painting: the dolphins stay upright and leap over open water (no land, trench or label)',r[3]==0 and r[5]==0,r)
        r=await E("""()=>{const g=coCv(),A=rpwWorldArt(2),F=rpw2aFogSpr(0);let ord=0,pop=[],n=0;
         for(let i=0;i<200;i++){const t=i*.5,L=coRec(()=>A.anim(g,t));const lc=L.map(e=>e.k==='mark'&&e.n==='rpw2aCastleLive').lastIndexOf(true),gl=L.findIndex(e=>e.k==='mark'&&e.n==='rpw2aGull');if(gl>=0&&lc>gl)ord++;
          for(const e of L)if(e.k==='img'&&e.img===F&&e.x1-e.x0<260){n++;const x=e.x0;if((x<466||x>754)&&e.al>.06)pop.push([t,x|0,e.al])}}return[ord,n,pop.slice(0,4)]}""")
        chk('World 2 painting: the gulls fly in front of the castles (their live layer comes first)',r[0]==0,r)
        chk('World 2 painting: the cove mist fades out and back in instead of jumping at the end of its drift',r[1]>100 and not r[2],r)
        # ================= World 3 painting =================
        lab3=await E("()=>coLabels(3)")
        r=await E("""(LB)=>{const W=rpw3aWorld(),A=rpwWorldArt(3),g=coCv(),N=W.nodes,S=W.scale;
         /* an island mask painted with the painting's own island shapes */
         const mk=document.createElement('canvas');mk.width=1600;mk.height=900;const h=mk.getContext('2d'),MC=['#5cc24a','#86dc62','#a87a52','#5a4a48'];
         for(const [x,y,rx,ry,dep,sd] of[[110,470,80,30,150,11],[480,470,90,32,160,13],[N.meadow.x,N.meadow.y-14,200,64,240,5],[160,740,70,26,120,17],[N.foundry.x,N.foundry.y-10,190,62,210,3],[N.storm.x,N.storm.y+20,150,52,330,7]])rpw3aIsle(h,x,y,rx,ry,dep,MC,sd);
         const MD=h.getImageData(0,0,1600,900).data,isl=(x,y)=>{x=x|0;y=y|0;return x>=0&&y>=0&&x<1600&&y<900&&MD[(y*1600+x)*4+3]>40};
         const castB=W.cast.map(c=>{const C=rpw3aCastle(c.id);return[c.x0+20*S,c.y0+30*S,c.x0+(C.w-20)*S,c.y0+C.h*S]});
         const mills=W.mills.filter(m=>!m.gear).map(m=>[m.x-m.r-4,m.y-m.r-4,m.x+m.r+4,m.y+48]).concat(W.mills.filter(m=>m.gear).map(m=>[m.x-m.r,m.y-m.r,m.x+m.r,m.y+m.r]));
         const smoke=W.smoke.map(([x,y,w])=>[x-24,y-96,x+50,y]);
         const ships=[0,1].map(i=>rpw3aShip('wm'+i,.38,i===1?['#ffd45a','#c8402a','#8a2a1a','#ffffff']:['#ffffff','#3a8ae0','#2a5aa8','#ffd45a']).c);
         const fit=(b,inset)=>({x0:b.x0+inset,x1:b.x1-inset,y0:b.y0+inset,y1:b.y1-inset});
         const islFrac=(b)=>{let n=0,k=0;for(let x=b.x0;x<=b.x1;x+=4)for(let y=b.y0;y<=b.y1;y+=4){k++;if(isl(x,y))n++}return k?n/k:0};
         const bad=[],face=[],jump=[],prev={};let n=0,nb=0,nf=0;
         for(let i=0;i<900;i++){const t=i*.1,L=coRec(()=>A.anim(g,t));
          for(const e of L){if(e.k!=='img')continue;const si=ships.indexOf(e.img);
           if(si>=0){if(e.x1<0||e.x0>1600)continue;n++;const b=fit(e,8);for(const c of castB.concat(LB,mills,smoke))if(coHit(b,c))bad.push(['ship'+si,t,e.cx|0,e.cy|0,c.map(Math.round)]);if(islFrac(b)>.02)bad.push(['ship-island',si,t,e.cx|0,e.cy|0]);
            const pv=prev[si];if(pv&&pv[2]===t-.1){const dx=e.cx-pv[0];if(Math.abs(dx)>.5&&Math.abs(e.m[0])>.95&&Math.sign(dx)!==Math.sign(e.m[0]))face.push([si,t,dx]);if(Math.hypot(dx,e.cy-pv[1])>25)jump.push([si,t])}prev[si]=[e.cx,e.cy,t]}
           else if(W.x3&&W.x3.bal.includes(e.img)){nb++;const b=fit(e,4);for(const c of castB.concat(LB,mills,smoke))if(coHit(b,c))bad.push(['balloon',t,e.cx|0,e.cy|0,c.map(Math.round)]);if(islFrac(b)>.02)bad.push(['balloon-island',t,e.cx|0,e.cy|0])}
           else if(e.img===rpw3aVee(0,'#2a1e3e').c){nf++;for(const c of castB.concat(mills))if(coHit(e,c))bad.push(['flock',t,e.cx|0,e.cy|0])}}}
         return[n,nb,nf,bad.slice(0,6),bad.length,face.slice(0,4),jump.slice(0,4)]}""",lab3)
        chk(f'World 3 painting: the airships ({r[0]} samples), balloons ({r[1]}) and the flock ({r[2]}) keep clear of castles, islands, windmills, gears, chimney smoke and labels',r[0]>800 and r[1]>800 and r[2]>100 and r[4]==0,r)
        chk('World 3 painting: the airships face the way they fly (they turn slowly at the ends) and never jump back',not r[5] and not r[6],r)
        r=await E("""()=>{const W=rpw3aWorld(),A=rpwWorldArt(3),g=coCv(),C=W.cast.find(c=>c.id==='storm'),CA=rpw3aCastle('storm'),S=W.scale,cb=[C.x0+14*S,C.y0+20*S,C.x0+(CA.w-14)*S,C.y0+CA.h*S],st=coNorm('#e8f8ff');
         let n=0,bad=[],ends=[],ord=0;for(let i=0;i<620;i++){const t=i*.05,L=coRec(()=>A.anim(g,t));
          for(const e of L)if(e.k==='stroke'&&coNorm(e.st)===st&&Math.abs(e.lw-2.4)<.01){n++;for(const s of e.p){for(const q of s)if(q[0]>cb[0]&&q[0]<cb[2]&&q[1]>cb[1]&&q[1]<cb[3])bad.push([t,q.map(Math.round)]);const z=s[s.length-1];ends.push(Math.min(...[-130,-90,90,130].map(dx=>Math.hypot(z[0]-W.storm[0]-dx,z[1]-W.storm[1]+26))))}}
          const lc=L.map(e=>e.k==='mark'&&e.n==='rpw3aCastleLive').lastIndexOf(true),fl=L.findIndex(e=>e.k==='img'&&e.img===rpw3aShip('wm0',.38,['#ffffff','#3a8ae0','#2a5aa8','#ffd45a']).c);if(fl>=0&&lc>fl)ord++}
         return[n,bad.slice(0,4),bad.length,Math.max(0,...ends),ord]}""")
        chk(f'World 3 painting: the lightning ({r[0]} strokes) strikes the lightning rods beside the citadel, never through it',r[0]>10 and r[2]==0 and r[3]<3,r)
        chk('World 3 painting: the castles\' live layer comes before the airships, balloons and birds',r[4]==0,r)
        # ================= battle maps =================
        for m in('moss','wonder'):
            r=await E("""(m)=>{const R=coBattle(m),G=R.G,st=coNorm(R.bake.pal.waterHi),g=coCv();let n=0,bad=[];
             for(let i=0;i<300;i++){R.t=i*.23;const L=coRec(()=>coLayers(R,g));for(const e of L)if(e.k==='stroke'&&coNorm(e.st)===st&&Math.abs(e.lw-2.4)<.01&&e.al>.01)for(const s of e.p)for(const q of s){n++;if(G.dRoad(q[0],q[1])<42)bad.push([R.t.toFixed(2),q.map(Math.round)])}}
             return[n,bad.slice(0,5),bad.length]}""",m)
            chk(f'{m}: the river streaks ({r[0]} points over 300 frames) flow under the bridge instead of over it',r[0]>1000 and r[2]==0,r)
        r=await E("""()=>{const R=coBattle('coral'),B=R.bake,F=B.F,AT=rpw2aSeaAtlas(),DS=rpw2aDolphinSpr(),g=coCv();let nt=0,nf=0,nd=0;const land=[],up=[],face=[];rpw2aCoralInit(B);
          const wet=(x,y,m)=>F.at(x,y)>(m||2);
          for(let i=0;i<300;i++){R.t=i*.1;const L1=coRec(()=>coLayers(R,g));R.t+=.02;const L2=coRec(()=>coLayers(R,g));
           for(const e of L1){if(e.k!=='img')continue;if(e.img===AT&&e.sy===24){nt++;for(const [dx,dy] of[[0,0],[26,0],[-26,0],[0,22],[0,-22]])if(!wet(e.cx+dx,e.cy+dy))land.push(['turtle',R.t.toFixed(1),e.cx|0,e.cy|0])}
            else if(e.img===AT&&e.sy===0){nf++;if(!wet(e.cx,e.cy))land.push(['fish',e.cx|0,e.cy|0]);if(e.m[3]<=0)up.push(['fish',e.cx|0])}}
           const D1=L1.filter(e=>e.k==='img'&&e.img===DS),D2=L2.filter(e=>e.k==='img'&&e.img===DS);for(let j=0;j<D1.length&&j<D2.length;j++){const a=D1[j],b=D2[j];nd++;
            if(a.m[0]*(b.cx-a.cx)+a.m[1]*(b.cy-a.cy)<=0)face.push([R.t.toFixed(1),a.cx|0]);if(a.m[3]<=0)up.push(['dolphin',a.cx|0]);
            const d=B.dol.reduce((p,q)=>Math.abs(q[0]-a.cx)<Math.abs(p[0]-a.cx)?q:p);if(!wet(a.cx,d[1],8))land.push(['dolphin',a.cx|0,d[1]])}}
          return[nt,nf,nd,land.slice(0,5),land.length,up.slice(0,4),face.slice(0,4),face.length]}""")
        chk(f'coral: the turtles ({r[0]}) and fish ({r[1]}) stay in the water',r[0]>200 and r[1]>500 and r[4]==0,r)
        chk(f'coral: the dolphins ({r[2]} frames) leap nose first in their direction of travel, upright, over water',r[2]>20 and r[7]==0 and not r[5],r)
        r=await E("""()=>{const R=coBattle('wreck'),B=R.bake,F=B.F,AT=rpw2aSeaAtlas(),g=coCv();let n=0;const bad=[];
          for(let i=0;i<200;i++){R.t=i*.13;const L=coRec(()=>coLayers(R,g));for(const e of L)if(e.k==='img'&&e.img===AT&&e.sy===0){n++;if(F.at(e.cx,e.cy)<=2)bad.push(['land',e.cx|0,e.cy|0]);if(e.m[3]<=0)bad.push(['upside down',e.cx|0])}}return[n,bad.slice(0,5),bad.length]}""")
        chk(f'wreck: the fish ({r[0]}) swim upright and stay in the water',r[0]>300 and r[2]==0,r)
        r=await E("""()=>{const R=coBattle('abyss'),g=coCv(),S=[0,1,2,3,4].map(k=>rpw2aFishASpr(k));let n=0;const bad=[];
          for(let i=0;i<200;i++){R.t=i*.13;const L=coRec(()=>coLayers(R,g));for(const e of L)if(e.k==='img'&&S.includes(e.img)){n++;if(e.m[3]<=0)bad.push([R.t.toFixed(1),e.cx|0,e.cy|0])}}return[n,bad.slice(0,4),bad.length]}""")
        chk(f'abyss: the glowing fish ({r[0]}) circle the maw upright',r[0]>500 and r[2]==0,r)
        r=await E("""()=>{const R=coBattle('meadow'),g=coCv(),V=rpw3aVee(0,'#2a2a4a').c;let n=0,bad=0;
          for(let i=0;i<60;i++){R.t=i*.4;const L=coRec(()=>coLayers(R,g));const lc=L.map(e=>e.k==='mark'&&e.n==='rpw3aCastleLive').lastIndexOf(true),v=L.findIndex(e=>e.k==='img'&&e.img===V);if(v>=0){n++;if(lc>v)bad++}}return[n,bad]}""")
        chk('meadow: the birds fly in front of the castle (its live layer comes first)',r[0]>20 and r[1]==0,r)
        r=await E("""()=>{const R=coBattle('storm'),B=R.bake,g=coCv(),SP=rpw3aSplash().c,C=rpw3aCastle('storm'),cb=[B.cast.x+10,B.cast.y+30,B.cast.x+C.w-10,B.cast.y+C.h];let n=0;const bad=[];
          for(let i=0;i<120;i++){R.t=i*.17;const L=coRec(()=>coLayers(R,g));for(const e of L)if(e.k==='img'&&e.img===SP){n++;if(e.cx>cb[0]&&e.cx<cb[2]&&e.cy>cb[1]&&e.cy<cb[3])bad.push([e.cx|0,e.cy|0])}}return[n,bad.slice(0,4),bad.length]}""")
        chk(f'storm: the rain splashes ({r[0]}) land on the stone, never on the citadel\'s walls',r[0]>500 and r[2]==0,r)
        # ================= frame cost =================
        COST="""()=>{const out={};const g=(()=>{const c=document.createElement('canvas');c.width=1600;c.height=900;return c.getContext('2d')})();
          const med=f=>{for(let i=0;i<8;i++)f(i);const L=[];for(let k=0;k<15;k++){const t0=performance.now();for(let i=0;i<8;i++)f(i);L.push((performance.now()-t0)/8)}L.sort((a,b)=>a-b);return +L[3].toFixed(3)};
          for(const w of[1,2,3]){let A;if(w===1){rpWorldArt(true);A={anim:(h,t)=>rpWorldLive(h,t,true)}}else A=rpwWorldArt(w);out['hub'+w]=med(i=>A.anim(g,3+i*.05))}
          for(const m of['moss','coral','wreck','abyss','meadow','storm']){try{rpLeave()}catch(e){}rpStart(m);const R=RPX;R.tut=null;R.hold=true;R.lite=false;R.rm=false;
           out[m]=med(i=>{R.t=5+i*.033;rpAmbient(g,R);const id=R.map.id;for(const f of[RPW.twist[id],RPW.ambTop[id]])if(f){g.save();f(g,R);g.restore()}})}
          try{rpLeave()}catch(e){}return out}"""
        new=await E(COST)
        if BASE and os.path.exists(BASE):
            p2=await b.new_page(viewport={'width':1600,'height':900});await p2.goto('file://'+os.path.abspath(BASE));await p2.wait_for_timeout(1500);await p2.evaluate(SETUP)
            old=await p2.evaluate(COST);await p2.close()
            new2=await E(COST);new={k:min(new[k],new2[k]) for k in new}
            worse={k:(old[k],new[k]) for k in new if new[k]>old[k]*1.25+.06}
            chk(f'frame cost unchanged or better than {os.path.basename(BASE)}: new {new} old {old}',not worse,worse)
        else:
            chk(f'frame cost of the live layers: {new} (all under 1.5 ms)',all(v<1.5 for v in new.values()),new)
        chk('no page errors',not er,er[:5])
        await b.close()
    print(f'\n{N[0]-len(FAIL)}/{N[0]} passed');sys.exit(1 if FAIL else 0)
asyncio.run(main())
