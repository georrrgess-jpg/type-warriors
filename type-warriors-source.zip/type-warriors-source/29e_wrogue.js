/* ---------- second armoury: rogue daggers and katanas (dagger blade x0=L*.13, katana blade x0=L*.12, edge curves toward -y) ---------- */
const wgold=(g,y0,y1)=>metal(g,y0,y1,'#e6b93e');
function bladeFill(g,path,c,wd,x0,len,o){o=o||{};g.save();path(g);g.fillStyle=o.fill||metal(g,-wd,wd,c);g.fill();g.save();g.clip();
 g.fillStyle='#00000026';g.fillRect(x0,0,len+L2,wd*2.4);if(o.clip)o.clip(g);
 if(!o.nofull){g.strokeStyle='#ffffff99';g.lineWidth=.9;g.beginPath();g.moveTo(x0+4,-wd*.35);g.lineTo(x0+len*.95,-wd*.2);g.stroke();g.strokeStyle='#0004';g.lineWidth=1.2;g.beginPath();g.moveTo(x0+4,wd*.05);g.lineTo(x0+len*.92,wd*.08);g.stroke()}
 g.restore();path(g);g.strokeStyle='#000b';g.lineWidth=1.2;g.stroke();g.restore()}
let L2=0;
function wDag(g,L,t,o){L2=L*.2;const x0=L*.13,len=o.len||L*.44,wd=o.wd||4.8;
 wrapG(g,-L*.15,x0,0,3.4,o.grip||'#2a1a18');if(o.back)o.back(g,x0,len);
 bladeFill(g,gg=>o.path(gg,x0,len,wd),o.c,wd,x0,len,o);
 if(o.guard)o.guard(g,x0,len);else{g.fillStyle=wgold(g,-9,9);g.beginPath();g.roundRect(x0-3.5,-9,8,18,3);g.fill();g.strokeStyle='#0007';g.lineWidth=1;g.stroke()}
 if(o.pommel)o.pommel(g);else{ell(g,-L*.17,0,4.6,4.6,wgold(g,-5,5));g.strokeStyle='#0006';g.lineWidth=1;g.stroke()}
 if(o.front)o.front(g,x0,len)}
function wKat(g,L,t,o){const len=o.len||L*.78,x0=L*.12,wd=o.wd||4.4,cv=o.cv==null?L*.09:o.cv,tp=o.tp==null?L*.07:o.tp;L2=L*.2;
 if(o.back)o.back(g,x0,len,cv);
 wrapG(g,-L*.16,x0,0,3.6,o.grip||'#2a2038');if(o.wrap)o.wrap(g,x0);
 const path=gg=>{gg.beginPath();gg.moveTo(x0,-wd*.9);gg.quadraticCurveTo(x0+len*.55,-wd*1.1-cv*.6,x0+len+tp,-cv*1.4);gg.quadraticCurveTo(x0+len*.6,wd*.5-cv*.5,x0,wd*.9);gg.closePath()};
 g.save();path(g);g.fillStyle=o.fill?o.fill(g,x0,len,wd,cv):metal(g,-wd,wd,o.c);g.fill();g.save();g.clip();
 g.strokeStyle='#ffffffc0';g.lineWidth=1.1;g.beginPath();g.moveTo(x0,wd*.55);g.quadraticCurveTo(x0+len*.55,-wd*.1-cv*.4,x0+len+tp*.7,-cv*1.3);g.stroke();g.strokeStyle='#0000004a';g.lineWidth=1.6;g.beginPath();g.moveTo(x0+4,-wd*.3);g.quadraticCurveTo(x0+len*.55,-wd*.6-cv*.5,x0+len*.95,-cv*1.2);g.stroke();
 if(o.clip)o.clip(g,x0,len,wd,cv);g.restore();path(g);g.strokeStyle='#000a';g.lineWidth=1.1;g.stroke();g.restore();
 if(o.tsuba)o.tsuba(g,x0);else{g.fillStyle=wgold(g,-9,9);g.beginPath();g.ellipse(x0,0,3.4,9.5,0,0,TAU);g.fill();g.strokeStyle='#0007';g.lineWidth=1;g.stroke()}
 if(o.pommel)o.pommel(g);if(o.front)o.front(g,x0,len,cv)}
const wkb=(x0,len,wd,cv,u)=>[x0+len*u,-cv*(.6*u+.8*u*u)*.95-wd*(1.1-.5*u)*0];  /* approx centreline of the katana blade */

/* --- Iron Kunai (common): a leaf blade, a ring pommel and a cord that sways --- */
WNEW.kunai=(g,L,t,X)=>wDag(g,L,t,{c:X.c,len:L*.4,wd:3.6,grip:'#1a1a22',
 path:(g,x0,len,wd)=>{g.beginPath();g.moveTo(x0,-wd*.5);g.quadraticCurveTo(x0+len*.35,-wd*2.2,x0+len*1.2,0);g.quadraticCurveTo(x0+len*.35,wd*2.2,x0,wd*.5);g.closePath()},
 guard:(g,x0)=>{g.fillStyle=metal(g,-6,6,'#6a6a78');g.beginPath();g.roundRect(x0-2,-5,5,10,2);g.fill();g.strokeStyle='#000a';g.lineWidth=.9;g.stroke()},
 pommel:g=>{const cx=-L*.24,r=L*.07;g.strokeStyle='#000a';g.lineWidth=5;g.beginPath();g.arc(cx,0,r,0,TAU);g.stroke();g.strokeStyle=metal(g,-r,r,'#8a8a98');g.lineWidth=3;g.stroke();g.strokeStyle='#ffffff77';g.lineWidth=.8;g.beginPath();g.arc(cx,0,r,3.6,5);g.stroke();
  g.strokeStyle='#c8283a';g.lineWidth=2;g.beginPath();g.moveTo(cx-r,0);for(let i=1;i<=6;i++)g.lineTo(cx-r-i*L*.025,Math.sin(t*3+i*.7)*i*.9+i*.4);g.stroke();poly(g,[cx-r-L*.17,-1,cx-r-L*.23,Math.sin(t*3+4.2)*5.4+3,cx-r-L*.17,5],'#c8283a','#5a0a14',.7)}});
/* --- Flamewave Kris (uncommon): a serpentine blade, heat-forged from dull red to white --- */
WNEW.kris=(g,L,t,X)=>wDag(g,L,t,{c:X.c,len:L*.46,wd:4.6,grip:'#4a2a18',nofull:1,
 fill:null,
 path:(g,x0,len,wd)=>{const N=26,A=[],B=[];for(let i=0;i<=N;i++){const u=i/N,cy=Math.sin(u*TAU*3.2)*L*.034*(1-u*.35),w=wd*(1.25*Math.pow(1-u,.55)+.12);A.push([x0+u*len*1.14,cy-w]);B.push([x0+u*len*1.14,cy+w])}g.beginPath();A.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));for(let i=N;i>=0;i--)g.lineTo(B[i][0],B[i][1]);g.closePath()},
 clip:(g)=>{const q=g.createLinearGradient(L*.13,0,L*.7,0);q.addColorStop(0,'#7a1a10');q.addColorStop(.45,'#ff7a2a');q.addColorStop(.85,'#ffe08a');q.addColorStop(1,'#fff8e0');g.fillStyle=q;g.fillRect(L*.1,-L*.1,L*.7,L*.2);g.strokeStyle='#ffffffaa';g.lineWidth=.9;g.beginPath();for(let i=0;i<=26;i++){const u=i/26,y=Math.sin(u*TAU*3.2)*L*.034*(1-u*.35);i?g.lineTo(L*.13+u*L*.52,y):g.moveTo(L*.13,y)}g.stroke()},
 guard:(g,x0)=>{poly(g,[x0-3,-11,x0+4,-5,x0+4,5,x0-3,11,x0-5,3,x0-5,-3],wgold(g,-11,11),'#0007',1)},
 front:(g,x0,len)=>{g.save();g.globalCompositeOperation='lighter';for(let i=0;i<7;i++){const u=.1+i*.12,cy=Math.sin(u*TAU*3.2)*L*.034*(1-u*.35);wflame(g,x0+u*len*1.14,cy-3,L*(.1+.04*Math.sin(t*6+i)),L*.03,t,i,.8,0)}g.restore()}});
/* --- Obsidian Dirk (rare): knapped volcanic glass; the edge catches light in cold facets --- */
WNEW.obsidian=(g,L,t,X)=>wDag(g,L,t,{c:X.c,len:L*.46,wd:5.2,grip:'#d8d0b8',nofull:1,
 path:(g,x0,len,wd)=>{const T=[[0,-.9],[.12,-1.25],[.28,-1.05],[.46,-1.3],[.66,-1.05],[.84,-.62],[1.16,0],[.82,.72],[.6,1.12],[.4,1.0],[.2,1.3],[0,.9]];g.beginPath();T.forEach((p,i)=>i?g.lineTo(x0+p[0]*len,p[1]*wd):g.moveTo(x0+p[0]*len,p[1]*wd));g.closePath()},
 fill:'#241a34',
 clip:(g)=>{const x0=L*.13,len=L*.46,wd=5.2,F=[[[0,-1.2],[.4,-1.4],[.3,0]],[[.3,0],[.4,-1.4],[.7,-1.1],[.62,.1]],[[.62,.1],[.7,-1.1],[1.2,0]],[[0,0],[.3,0],[.36,1.3],[0,1.2]],[[.3,0],[.62,.1],[.6,1.2],[.36,1.3]]],cs=['#5a4682','#34264e','#8a64b0','#241a38','#4a3470'];F.forEach((f,i)=>{g.fillStyle=cs[i];g.beginPath();f.forEach((p,k)=>k?g.lineTo(x0+p[0]*len,p[1]*wd):g.moveTo(x0+p[0]*len,p[1]*wd));g.closePath();g.fill();g.strokeStyle='#d8b8ff55';g.lineWidth=.7;g.stroke()});
  g.strokeStyle='#ff4a6a99';g.lineWidth=.8;g.beginPath();g.moveTo(x0+len*.1,.5);g.lineTo(x0+len*.34,-.4);g.lineTo(x0+len*.5,.6);g.lineTo(x0+len*.78,-.2);g.stroke();g.fillStyle='#ffffff88';g.fillRect(x0+len*(.15+.7*((t*.4)%1)),-wd,1.4,wd*2)},
 guard:(g,x0)=>{g.fillStyle='#2a2a32';for(const s of[-1,1])poly(g,[x0-3,s*3,x0+1,s*10,x0+5,s*3],'#3a3a44','#000a',.9)},
 pommel:g=>{poly(g,[-L*.15,-4,-L*.2,0,-L*.15,4],'#e8e0c8','#000a',.9);for(let i=0;i<3;i++)ell(g,-L*.1+i*0,0,0,0,'#0000')}});
/* --- Jester's Jape (epic): harlequin blade, a jester's crown for a guard and bells that jingle --- */
WNEW.jester=(g,L,t,X)=>wDag(g,L,t,{c:'#ffe0f4',len:L*.46,wd:5.4,grip:'#2a0a3a',nofull:1,
 path:(g,x0,len,wd)=>{g.beginPath();g.moveTo(x0,-wd);g.lineTo(x0+len,-wd*.8);g.lineTo(x0+len+L*.13,0);g.lineTo(x0+len,wd*.8);g.lineTo(x0,wd);g.closePath()},
 fill:'#ffe0f4',
 clip:(g)=>{const x0=L*.13,w=L*.07;for(let i=0;i<8;i++)for(let j=-2;j<=1;j++){if((i+j)&1){g.fillStyle=(i%3)?'#ff2ab0':'#2a1050';g.beginPath();g.moveTo(x0+i*w*.6,j*w*.42);g.lineTo(x0+i*w*.6+w*.3,j*w*.42-w*.42);g.lineTo(x0+i*w*.6+w*.6,j*w*.42);g.lineTo(x0+i*w*.6+w*.3,j*w*.42+w*.42);g.closePath();g.fill()}}g.strokeStyle='#ffffffaa';g.lineWidth=.9;g.beginPath();g.moveTo(x0+4,-4.4);g.lineTo(x0+L*.5,-3.2);g.stroke()},
 guard:(g,x0)=>{for(const s of[-1,1]){g.fillStyle=s>0?'#5a2ab8':'#ff2ab0';g.beginPath();g.moveTo(x0-3,s*3);g.quadraticCurveTo(x0-1,s*L*.1,x0+2,s*L*.15);g.lineTo(x0+5,s*4);g.closePath();g.fill();g.strokeStyle='#000a';g.lineWidth=.9;g.stroke();ell(g,x0+2,s*(L*.15+2),2.4,2.4,'#ffd24a')}},
 pommel:g=>{for(let i=0;i<3;i++){const a=wsin(t,5,i*2)*.4,bx=-L*.18-i*L*.045,by=(i-1)*L*.07+Math.sin(t*5+i)*1.4;g.save();g.translate(bx,by);g.rotate(a);g.fillStyle=rgr(g,-1,-1,.5,5,'#fff0a0','#d8961c');g.beginPath();g.arc(0,0,3.6,0,TAU);g.fill();g.strokeStyle='#5a3a08';g.lineWidth=.8;g.stroke();g.beginPath();g.moveTo(-3,1);g.lineTo(3,1);g.stroke();g.restore()}}});
/* --- Heartseeker (legendary): a ruby heart for a guard, a blade like a lover's note, a pulse in the steel --- */
WNEW.heartseeker=(g,L,t,X)=>{const hb=1+.1*Math.max(0,Math.sin(t*5.5))**3*3+.05*Math.sin(t*5.5);wDag(g,L,t,{c:'#f4e0e8',len:L*.5,wd:3.8,grip:'#5a0a1a',
 back:(g,x0,len)=>{g.save();g.globalCompositeOperation='lighter';glow(g,x0+len*.5,0,L*.5*hb,'#ff3a6a55');g.restore()},
 path:(g,x0,len,wd)=>{g.beginPath();g.moveTo(x0,-wd);g.lineTo(x0+len,-wd*.7);g.lineTo(x0+len+L*.15,0);g.lineTo(x0+len,wd*.7);g.lineTo(x0,wd);g.closePath()},
 clip:(g)=>{const x0=L*.13,q=g.createLinearGradient(x0,0,x0+L*.65,0);q.addColorStop(0,'#ff3a6a');q.addColorStop(.55,'#ffd0dc');q.addColorStop(1,'#ffffff');g.fillStyle=q;g.globalAlpha=.55;g.fillRect(x0,-6,L*.7,12);g.globalAlpha=1;g.save();g.translate(x0+L*.12,0);g.scale(hb,hb);g.fillStyle='#d8103a';g.beginPath();g.moveTo(0,3);g.bezierCurveTo(-6,-1,-3,-5,0,-2);g.bezierCurveTo(3,-5,6,-1,0,3);g.fill();g.strokeStyle='#ffffff99';g.lineWidth=.6;g.stroke();g.restore()},
 guard:(g,x0)=>{g.save();g.translate(x0+1,0);g.rotate(-Math.PI/2);g.scale(hb,hb);g.fillStyle=wgold(g,-12,12);g.beginPath();g.moveTo(0,12);g.bezierCurveTo(-22,-2,-9,-17,0,-7);g.bezierCurveTo(9,-17,22,-2,0,12);g.fill();g.strokeStyle='#5a3a08';g.lineWidth=1.2;g.stroke();g.restore();gem(g,x0+1,0,3.6*hb,'#ff2a58')},
 pommel:g=>{ell(g,-L*.17,0,4,4,wgold(g,-5,5));gem(g,-L*.17,0,2,'#ff2a58')},
 front:(g,x0,len)=>{g.save();g.globalCompositeOperation='lighter';for(let k=0;k<2;k++){const u=((t*.9+k*.5)%1);g.globalAlpha=(1-u)*.6;g.strokeStyle='#ff6a8a';g.lineWidth=1.4;g.beginPath();g.arc(x0+1,0,10+u*L*.3,-1.1,1.1);g.stroke()}g.restore();ell(g,x0+len+L*.08,L*.06+((t*26)%12),1.4,2.4,'#ff2a58')}})};

/* --- Wooden Bokken (common): an oak practice sword, scuffed, with a red knot --- */
WNEW.bokken=(g,L,t,X)=>wKat(g,L,t,{c:X.c,len:L*.72,wd:4.2,cv:L*.03,tp:L*.04,grip:'#e8e0cc',
 fill:(g,x0,len,wd)=>vgr(g,-wd,wd,'#d8a868','#7a5028'),
 clip:(g,x0,len,wd)=>{g.strokeStyle='#5a381866';g.lineWidth=.8;for(let i=0;i<9;i++){const y=-wd*.8+i*wd*.2;g.beginPath();g.moveTo(x0,y);g.bezierCurveTo(x0+len*.3,y+Math.sin(i)*1.4,x0+len*.6,y-Math.cos(i)*1.4,x0+len,y*.6);g.stroke()}g.fillStyle='#3a200c88';for(let i=0;i<4;i++)g.fillRect(x0+len*(.25+.17*i),-wd+rnd(i)*wd*1.4,3,1.4)},
 tsuba:(g,x0)=>{ell(g,x0,0,3.6,9,'#1a1a1e');g.strokeStyle='#5a5a62';g.lineWidth=.9;g.beginPath();g.ellipse(x0,0,3.6,9,0,0,TAU);g.stroke()},
 pommel:g=>{g.fillStyle='#c8283a';g.beginPath();g.arc(-L*.18,0,3.6,0,TAU);g.fill();g.strokeStyle='#c8283a';g.lineWidth=2;g.beginPath();g.moveTo(-L*.18,0);g.lineTo(-L*.18-L*.1,Math.sin(t*3)*3+4);g.moveTo(-L*.18,0);g.lineTo(-L*.18-L*.08,Math.sin(t*3+2)*3-4);g.stroke()}});
/* --- Corsair Cutlass (uncommon): a broad curved blade, a gold basket hilt and a red sash --- */
WNEW.cutlass=(g,L,t,X)=>wKat(g,L,t,{c:X.c,len:L*.6,wd:6.4,cv:L*.13,tp:L*.05,grip:'#3a1a10',
 clip:(g,x0,len,wd,cv)=>{g.strokeStyle='#0003';g.lineWidth=1;g.beginPath();g.moveTo(x0+len*.05,-wd*.1);g.quadraticCurveTo(x0+len*.55,-wd*.5-cv*.4,x0+len*.9,-cv*1.1);g.stroke()},
 tsuba:(g,x0)=>{const sw=(k)=>{g.beginPath();g.moveTo(x0,0);g.bezierCurveTo(x0-4,k*L*.1,-L*.1,k*L*.14,-L*.17,k*3);};g.lineCap='round';for(const k of[.55,.85,1.15]){sw(k);g.strokeStyle='#4a2a04';g.lineWidth=4;g.stroke();sw(k);g.strokeStyle=wgold(g,0,L*.15);g.lineWidth=2.4;g.stroke()}g.fillStyle=wgold(g,-9,9);g.beginPath();g.roundRect(x0-3,-9,6,16,2);g.fill();g.strokeStyle='#0007';g.lineWidth=1;g.stroke()},
 pommel:g=>{ell(g,-L*.19,0,4.4,4.4,wgold(g,-5,5));g.strokeStyle='#c8283a';g.lineWidth=3.2;g.beginPath();g.moveTo(-L*.19,0);for(let i=1;i<=7;i++)g.lineTo(-L*.19-i*L*.03,Math.sin(t*4+i*.7)*i*1.1-i*.6);g.stroke()}});
/* --- Windcutter (rare): a pale blade with the wind still trapped in it --- */
WNEW.windcutter=(g,L,t,X)=>wKat(g,L,t,{c:X.c,len:L*.84,wd:3.8,cv:L*.07,tp:L*.06,grip:'#2a4a44',
 clip:(g,x0,len,wd,cv)=>{g.save();g.globalCompositeOperation='lighter';g.strokeStyle='#ffffffcc';g.lineWidth=1.1;for(let k=0;k<3;k++){const u=((t*.45+k/3)%1),cx=x0+u*len;g.globalAlpha=Math.sin(u*Math.PI);g.beginPath();g.arc(cx,-cv*.8*u,wd*(.9+k*.2),-1.9,1.2);g.stroke()}g.restore()},
 tsuba:(g,x0)=>{g.save();g.translate(x0,0);g.scale(.45,1);g.rotate(t*.8);for(let i=0;i<4;i++){g.rotate(Math.PI/2);poly(g,[0,0,9,-2,10,5],'#d8f0e4','#2a4a44',.9)}g.fillStyle='#2a4a44';g.beginPath();g.arc(0,0,2.2,0,TAU);g.fill();g.restore()},
 pommel:g=>{g.strokeStyle='#5ad8a8';g.lineWidth=2;g.beginPath();g.moveTo(-L*.17,0);for(let i=1;i<=7;i++)g.lineTo(-L*.17-i*L*.032,Math.sin(t*5+i*.8)*i*.9);g.stroke();for(let i=0;i<4;i++){const u=(t*.4+i/4)%1;leafG(g,-L*.1-u*L*.5,Math.sin(u*9+i)*L*.14,u*7+i,L*.05,L*.018,'#8af0b8')}},
 back:(g,x0,len,cv)=>{g.save();g.globalCompositeOperation='lighter';glow(g,x0+len*.6,-cv*.6,len*.5,'#8affd055');g.restore()}});
/* --- Oni's Fang (epic): a crimson saw-backed blade, a demon mask for a guard, flame along the spine --- */
WNEW.oni=(g,L,t,X)=>wKat(g,L,t,{c:'#d8302a',len:L*.78,wd:4.6,cv:L*.08,grip:'#14080a',
 fill:(g,x0,len,wd)=>vgr(g,-wd,wd,'#ff6a5a','#6a0a14'),
 clip:(g,x0,len,wd,cv)=>{g.fillStyle='#1a0408';g.beginPath();g.moveTo(x0,-wd);g.quadraticCurveTo(x0+len*.55,-wd*1.1-cv*.6,x0+len+L*.07,-cv*1.4);g.lineTo(x0+len+L*.07,-cv*1.4+2.4);g.quadraticCurveTo(x0+len*.55,-wd*.5-cv*.6,x0,-wd*.3);g.fill()},
 tsuba:(g,x0)=>{g.save();g.translate(x0,0);g.rotate(-Math.PI/2);for(const s of[-1,1])poly(g,[s*5,-5,s*12,-13,s*8,-2],'#e8d8c0','#000a',.9);g.fillStyle=rgr(g,0,-2,1,12,'#ff6a4a','#6a0a14');g.beginPath();g.ellipse(0,0,10,8.4,0,0,TAU);g.fill();g.strokeStyle='#000a';g.lineWidth=1.1;g.stroke();g.save();g.globalCompositeOperation='lighter';for(const s of[-1,1])glow(g,s*4,-2,5,'#ffe03acc');g.restore();for(const s of[-1,1])poly(g,[s*2,-3.4,s*6.6,-4.4,s*4.6,-1],'#fff0a0','#000',.5);g.fillStyle='#1a0408';g.beginPath();g.moveTo(-5,3);g.lineTo(5,3);g.lineTo(3.4,6);g.lineTo(-3.4,6);g.fill();for(const s of[-1,1])poly(g,[s*3,3,s*4,7.4,s*1.6,3],'#fff','#000',.4);g.restore()},
 front:(g,x0,len,cv)=>{g.save();g.globalCompositeOperation='lighter';for(let i=0;i<9;i++){const u=.1+i*.1,x=x0+u*len,y=-cv*(.6*u+.9*u*u)-4.4;wflame(g,x,y,L*(.09+.035*Math.sin(t*7+i)),L*.025,t,i,.85,0)}g.restore()},
 pommel:g=>{for(const s of[-1,1])poly(g,[-L*.16,s*2,-L*.24,s*9,-L*.19,s*1],'#e8d8c0','#000a',.9);ell(g,-L*.17,0,3.6,3.6,'#3a0a10')}});
/* --- Ryujin's Scale (legendary): a sea-dragon's blade; the hamon is a running wave, the guard bites --- */
WNEW.ryujin=(g,L,t,X)=>wKat(g,L,t,{c:'#cff8ee',len:L*.82,wd:4.6,cv:L*.085,grip:'#0a3a40',
 back:(g,x0,len,cv)=>{g.save();g.globalCompositeOperation='lighter';glow(g,x0+len*.55,-cv*.5,len*.6,'#3affd055');g.restore()},
 fill:(g,x0,len,wd)=>vgr(g,-wd,wd,'#e8fff8','#3ab8a8'),
 clip:(g,x0,len,wd,cv)=>{g.fillStyle='#1a8a8a66';for(let i=0;i<10;i++)for(let j=0;j<2;j++){const x=x0+len*(.1+i*.085)+(j?len*.04:0),y=-wd*.9-cv*.4*(i/10)+j*3.2;g.beginPath();g.arc(x,y,2.4,0,Math.PI);g.fill()}
  g.strokeStyle='#ffffffee';g.lineWidth=1.3;g.beginPath();for(let i=0;i<=32;i++){const u=i/32,x=x0+len*(.06+u*.9),y=wd*.28-cv*.55*u*(.9)+Math.sin(u*TAU*5+t*2.5)*1.5;i?g.lineTo(x,y):g.moveTo(x,y)}g.stroke();
  g.save();g.globalCompositeOperation='lighter';for(let i=0;i<5;i++){const u=(t*.35+i/5)%1;g.globalAlpha=Math.sin(u*Math.PI)*.8;glow(g,x0+len*u,-cv*.7*u+Math.sin(u*10+i)*2,4,'#aaffee')}g.restore()},
 tsuba:(g,x0)=>{g.fillStyle=wgold(g,-12,12);g.beginPath();g.moveTo(x0-6,-4);g.quadraticCurveTo(x0-12,-12,x0-18,-9);g.lineTo(x0-9,-2);g.closePath();g.fill();g.strokeStyle='#4a2a04';g.lineWidth=1;g.stroke();g.beginPath();g.moveTo(x0-6,4);g.quadraticCurveTo(x0-12,12,x0-18,9);g.lineTo(x0-9,2);g.closePath();g.fill();g.stroke();
  g.fillStyle=wgold(g,-12,12);g.beginPath();g.moveTo(x0-5,-3);g.lineTo(x0+2,-12);g.lineTo(x0+9,-5);g.lineTo(x0+7,-1.6);g.lineTo(x0+7,1.6);g.lineTo(x0+9,5);g.lineTo(x0+2,12);g.lineTo(x0-5,3);g.closePath();g.fill();g.strokeStyle='#4a2a04';g.lineWidth=1.1;g.stroke();
  for(const s of[-1,1]){poly(g,[x0+6,s*2,x0+9,s*4.4,x0+4,s*3.2],'#fff','#000',.4);poly(g,[x0+4,s*10.4,x0+8,s*9,x0+6,s*13],'#e8c870','#4a2a04',.6)}g.save();g.globalCompositeOperation='lighter';for(const s of[-1,1])glow(g,x0+2,s*7,4,'#3affd0cc');g.restore();for(const s of[-1,1])ell(g,x0+2,s*7,1.3,1.3,'#eafffa');
  g.strokeStyle='#e8c870';g.lineWidth=1;for(const s of[-1,1]){g.beginPath();g.moveTo(x0-16,s*9);for(let i=1;i<=5;i++)g.lineTo(x0-16-i*L*.03,s*(9+i*1.5)+Math.sin(t*3+i)*1.4);g.stroke()}},
 pommel:g=>{g.save();g.globalCompositeOperation='lighter';glow(g,-L*.19,0,10,'#aaffee');g.restore();ell(g,-L*.19,0,4.2,4.2,rgr(g,-L*.19-1,-1,.5,5,'#ffffff','#8ae8d8'));g.strokeStyle='#0a3a40';g.lineWidth=.8;g.stroke()}});
