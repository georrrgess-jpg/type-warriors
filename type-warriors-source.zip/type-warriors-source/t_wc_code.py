# Wildcard room codes, end to end: two browsers, a real MQTT broker as the relay (start one locally first, e.g.
# amqtt with a websocket listener on 127.0.0.1:18083), the guest types the 4-letter code, both ready up and play.
import asyncio,os,sys,time
from playwright.async_api import async_playwright
RELAY=os.environ.get('WCRELAY','ws://127.0.0.1:18083/mqtt')
async def main():
    html=os.path.abspath(sys.argv[1] if len(sys.argv)>1 else 'out.html')
    async with async_playwright() as p:
        b=await p.chromium.launch();A=await (await b.new_context(viewport={'width':1600,'height':900})).new_page();B=await (await b.new_context(viewport={'width':1600,'height':900})).new_page();er=[];bad=0
        for pg,n in ((A,'A'),(B,'B')):pg.on('pageerror',lambda e,n=n:er.append(n+' PE '+str(e)[:300]))
        def chk(name,r,ok):
            nonlocal bad;bad+=not ok;print(name,r,'OK' if ok else 'BAD')
        await A.goto('file://'+html);await B.goto('file://'+html);await A.wait_for_timeout(1200)
        for pg,nm,g in ((A,'Seth',3000),(B,'Mia',900)):await pg.evaluate(f"()=>{{RS_ASK=false;WCRELAYS=['{RELAY}'];P.name='{nm}';P.gold={g};save();wcHome()}}")
        await A.click('#wchost');t0=time.time()
        while time.time()-t0<10 and await A.evaluate("()=>WCL.net")!='online':await A.wait_for_timeout(100)
        code=await A.evaluate("()=>WCL.room");chk('host online',[await A.evaluate("()=>WCL.net"),code,round(time.time()-t0,1)],await A.evaluate("()=>WCL.net")=='online')
        await A.click('[data-stk="50"]');await A.wait_for_timeout(200)
        await A.screenshot(path='shots/wc_code_lobby.png')
        # the guest types the code letter by letter, exactly like a player would
        await B.click('#wcotp input[data-o="0"]');await B.keyboard.type(code.lower(),delay=60);await B.wait_for_timeout(150)
        await B.click('#wcjoin');t1=time.time();await B.wait_for_timeout(250);await B.screenshot(path='shots/wc_code_find.png')
        while time.time()-t1<25 and not await B.evaluate("()=>!!document.getElementById('wcrdy')"):await B.wait_for_timeout(100)
        r=await B.evaluate("()=>[!!document.getElementById('wcrdy'),WCNET.guest&&WCNET.guest.lobby&&WCNET.guest.lobby.room]");chk(f'guest in room {time.time()-t1:.1f}s',r,r[0] and r[1]==code)
        r=await A.evaluate("()=>WCL.seats.map(s=>s.k+':'+(s.name||''))");chk('host sees Mia',r,'net:Mia' in r)
        await B.wait_for_timeout(600);await B.screenshot(path='shots/wc_code_guest.png')
        await B.click('#wcrdy');await A.wait_for_timeout(700);await A.screenshot(path='shots/wc_code_ready.png')
        r=await A.evaluate("()=>[document.getElementById('wcgo').disabled,WCL.seats.find(s=>s.k==='net').ready]");chk('ready, can deal',r,r==[False,1])
        await A.click('#wcgo');await A.wait_for_timeout(1500)
        r=await B.evaluate("()=>[!!document.getElementById('wct'),WX.mode,WX.host,WX.G&&WX.G.P.map(p=>p.name),P.gold]");chk('both at the table',r,r[0] and r[1]=='net' and not r[2] and r[4]==850)
        for pg in (A,B):await pg.add_script_tag(path=os.path.abspath('t_wc_agent.js'))
        t2=time.time();shot=0
        while time.time()-t2<420:
            await A.wait_for_timeout(600)
            if not shot and time.time()-t2>25:await B.screenshot(path='shots/wc_code_play_B.png');shot=1
            if await A.evaluate("()=>!!document.getElementById('wcr')") and await B.evaluate("()=>!!document.getElementById('wcr')"):break
        ra=await A.evaluate("()=>{const R=wcRank(WX.G);return [R.indexOf(WX.me),P.gold,wcSt().byd.net.g,__ag.errs]}");rb=await B.evaluate("()=>{const R=wcRank(WX.G);return [R.indexOf(WX.me),P.gold,wcSt().byd.net.g,__ag.errs]}")
        pay=lambda pl:[180,20,0,0][pl]+(150 if pl==0 else 0)
        chk(f'game over {time.time()-t2:.0f}s A',ra,ra[1]==3000-50+pay(ra[0]) and ra[2]==1 and not ra[3]);chk('B',rb,rb[1]==900-50+pay(rb[0]) and rb[2]==1 and not rb[3])
        await B.screenshot(path='shots/wc_code_result_B.png')
        # a code nobody is hosting, and no relay at all
        await B.evaluate("()=>{wcNetClose();wcHome();wcJoinCode('ZZZZ')}");await B.wait_for_timeout(24000);r=await B.evaluate("()=>document.querySelector('.wcjs h2').textContent");chk('unknown code',r,r=='No room found')
        await B.evaluate("()=>{WCRELAYS=['ws://127.0.0.1:9/mqtt'];wcNetClose();wcHome();wcJoinCode('ABCD')}");await B.wait_for_timeout(2500);r=await B.evaluate("()=>document.querySelector('.wcjs h2').textContent");chk('no internet',r,"reach the room servers" in r)
        await B.screenshot(path='shots/wc_code_nonet.png')
        print('bad',bad);print(er[:6]);await b.close()
asyncio.run(main())
