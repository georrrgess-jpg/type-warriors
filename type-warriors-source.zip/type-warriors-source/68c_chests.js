/* ===== THE FOUR SHOP CHESTS, redrawn: Weapon crate, Armor crate, Special crate and Eclipse Chest =====
   One painted rig per chest, drawn at (x,y) = bottom centre, scale s, lid open u (0..1), time t.
   NCX carries the extra state the caller can set: hov = hover glow 0..1, ch = charge while a crate is being opened 0..1.
   Body: y -70..0, x about -80..80. The lock / emblem sits on the seam so the flying key in the crate scene lands on it.
   The Celestial Chest and the Graveyard Crate keep their own art and animations. */
const NCX={hov:0,ch:0};
const NCO='#150c1c';
const ncA=n=>Math.round(Math.max(0,Math.min(1,n))*255).toString(16).padStart(2,'0');
function ncP(g,p){g.beginPath();g.moveTo(p[0],p[1]);for(let i=2;i<p.length;i+=2)g.lineTo(p[i],p[i+1]);g.closePath()}
function ncF(g,f,lw,sc){g.fillStyle=f;g.fill();if(lw!==0){g.strokeStyle=sc||NCO;g.lineWidth=lw||2.4;g.lineJoin='round';g.stroke()}}
function ncRR(g,x,y,w,h,r){g.beginPath();g.roundRect(x,y,w,h,r)}
function ncLin(g,x0,y0,x1,y1,stops){const q=g.createLinearGradient(x0,y0,x1,y1);stops.forEach((c,i)=>q.addColorStop(i/(stops.length-1),c));return q}
const NCAU=['#fff4c0','#ffd45a','#e0a02a','#9a6012'];
const ncGold=(g,x0,y0,x1,y1)=>ncLin(g,x0,y0,x1,y1,NCAU);
function ncGlow(g,x,y,r,c){if(r<=0)return;const q=g.createRadialGradient(x,y,0,x,y,r);q.addColorStop(0,c);q.addColorStop(1,c.slice(0,7)+'00');g.fillStyle=q;g.beginPath();g.arc(x,y,r,0,Math.PI*2);g.fill()}
/* a faceted diamond stud */
function ncStud(g,x,y,r,c){c=c||NCAU;ncP(g,[x,y-r,x+r,y,x,y+r,x-r,y]);ncF(g,ncLin(g,x-r,y-r,x+r,y+r,[c[0],c[1],c[3]]),1.4);g.fillStyle='#ffffffaa';ncP(g,[x,y-r,x+r*.45,y-r*.1,x,y]);g.fill()}
/* a round rivet */
function ncRiv(g,x,y,r){g.beginPath();g.arc(x,y,r,0,Math.PI*2);ncF(g,g.createRadialGradient(x-r*.35,y-r*.4,0,x,y,r),1.4);const q=g.createRadialGradient(x-r*.35,y-r*.4,0,x,y,r);q.addColorStop(0,'#fff6c8');q.addColorStop(.45,'#ffcf4a');q.addColorStop(1,'#9a6012');g.fillStyle=q;g.beginPath();g.arc(x,y,r,0,Math.PI*2);g.fill();g.strokeStyle=NCO;g.lineWidth=1.4;g.stroke()}
/* the four-point star used for sparkles */
function ncStar(g,x,y,r,c){g.fillStyle=c;g.beginPath();g.moveTo(x,y-r);g.quadraticCurveTo(x+r*.14,y-r*.14,x+r,y);g.quadraticCurveTo(x+r*.14,y+r*.14,x,y+r);g.quadraticCurveTo(x-r*.14,y+r*.14,x-r,y);g.quadraticCurveTo(x-r*.14,y-r*.14,x,y-r);g.fill()}

/* ---------- lid motion: each chest opens in its own way ---------- */
const ncEOB=u=>{const c1=1.70158,c3=c1+1;return 1+c3*Math.pow(u-1,3)+c1*Math.pow(u-1,2)};
function ncLidPose(k,u){if(u<=0)return{a:0,lift:0,sh:0};const s=x=>x*x*(3-2*x);
 const P0=.25,pk=s(Math.min(1,u/P0)),m=Math.max(0,(u-P0)/(1-P0));
 /* u up to .25 is a gentle peek (hover); beyond that each lid opens in its own way */
 if(k==='w')return{a:.5*pk+(1.95-.5)*Math.min(1.06,ncEOB(Math.min(1,m))),lift:0,sh:0,pk};/* the wooden lid cracks, then flies back and rocks on its hinge */
 if(k==='a'){/* the heavy stone slab: a jolt, a short crack, then a slow heave */const c=Math.min(1,u/.25),h=Math.max(0,(u-.25)/.75);return{a:.16*s(c)+1.74*s(h),lift:0,sh:u<.3?Math.sin(u*90)*1.5*(1-u/.3):0}}
 if(k==='s')return{a:1.9*s(Math.max(0,(u-.2)/.8)),lift:22*Math.sin(Math.min(1,u)*Math.PI*.5),sh:0};/* the crystal lid lifts on its own light first */
 return{a:1.85*s(Math.max(0,(m-.3)/.7)),lift:9*pk+25*s(Math.min(1,m/.45))+pk*Math.sin((NCX.t||0)*2.1)*1.6*(1-Math.min(1,m*3)),sh:0,pk}/* the eclipse lid levitates on its light, bobbing, then turns */}

function ncSheen(g,x,y,w,h,t,per,off){const p=((t+off)%per)/1.1;if(p>=1)return;g.save();ncRR(g,x,y,w,h,3);g.clip();g.globalCompositeOperation='lighter';const yy=y-30+p*(h+60),q=g.createLinearGradient(0,yy-18,0,yy+18);q.addColorStop(0,'#ffffff00');q.addColorStop(.5,'#ffffff88');q.addColorStop(1,'#ffffff00');g.fillStyle=q;g.translate(x+w/2,yy);g.rotate(-.5);g.fillRect(-w*1.5,-18,w*3,36);g.restore()}
/* ---------- WEAPON CRATE: oak planks, heavy gold posts, crossed swords on a gold medallion ---------- */
function ncSword(g,len,grip){g.save();/* drawn along +x, crossguard at 0 */
 ncP(g,[2,-3.6,len*.86,-3.2,len,0,len*.86,3.2,2,3.6]);ncF(g,ncLin(g,0,-4,0,4,['#ffffff','#c8d0e0','#7a8296']),1.8);g.strokeStyle='#5a627a';g.lineWidth=1;g.beginPath();g.moveTo(5,0);g.lineTo(len*.8,0);g.stroke();
 g.fillStyle='#ffffffcc';ncP(g,[4,-2.6,len*.8,-2.2,len*.84,-1.2,4,-1.2]);g.fill();
 ncRR(g,-3,-8,6,16,2.4);ncF(g,ncGold(g,-3,-8,3,8),1.6);
 ncRR(g,-15,-2.6,12,5.2,2);ncF(g,grip,1.6);g.strokeStyle='#ffffff55';g.lineWidth=1;for(let i=0;i<3;i++){g.beginPath();g.moveTo(-13+i*4,-2.4);g.lineTo(-11+i*4,2.4);g.stroke()}
 g.beginPath();g.arc(-17,0,3.6,0,Math.PI*2);ncF(g,ncGold(g,-20,-3,-14,3),1.6);g.restore()}
function ncWeapon(g,u,t,P){const hv=NCX.hov,ch=NCX.ch,L=ncLidPose('w',u);
 const lidFace=()=>{/* domed oak lid, local: bottom 0, top about -46 */
  g.beginPath();g.moveTo(-76,0);g.lineTo(-76,-30);g.quadraticCurveTo(0,-74,76,-30);g.lineTo(76,0);g.closePath();ncF(g,ncLin(g,0,-46,0,0,['#b07440','#8a5228','#5e3418']),2.6);
  g.save();g.beginPath();g.moveTo(-76,0);g.lineTo(-76,-30);g.quadraticCurveTo(0,-74,76,-30);g.lineTo(76,0);g.closePath();g.clip();
  g.strokeStyle='#3a1e0c';g.lineWidth=2;for(const d of[12,25,38]){g.beginPath();g.moveTo(-76,-30+d);g.quadraticCurveTo(0,-74+d*1.05,76,-30+d);g.stroke()}
  g.strokeStyle='#c88a52aa';g.lineWidth=1.2;for(const d of[14,27,40]){g.beginPath();g.moveTo(-60,-28+d);g.quadraticCurveTo(0,-68+d,60,-28+d);g.stroke()}g.restore();
  for(const sx of[-1,1]){/* gold arched end bands */g.beginPath();g.moveTo(sx*58,0);g.lineTo(sx*58,-41);g.quadraticCurveTo(sx*70,-39,sx*80,-31);g.lineTo(sx*80,0);g.closePath();ncF(g,ncGold(g,sx*58,-41,sx*80,0),2.4);ncStud(g,sx*69,-14,4.2);ncStud(g,sx*69,-30,3.6)}
  g.beginPath();g.moveTo(-58,-43);g.quadraticCurveTo(0,-68,58,-43);g.strokeStyle='#ffe9a066';g.lineWidth=2;g.stroke()};
 const lidIn=h=>{/* the inside of the lid, seen once it swings past upright */g.beginPath();g.moveTo(-70,0);g.lineTo(-62,-h);g.lineTo(62,-h);g.lineTo(70,0);g.closePath();ncF(g,ncLin(g,0,-h,0,0,['#2a1408','#4a2a14']),2.4);g.strokeStyle=NCAU[2];g.lineWidth=3;g.stroke()};
 ncOpenLid(g,P,L,lidFace,lidIn,54,'#ffd890');
 /* body */
 ncRR(g,-72,-70,144,70,4);ncF(g,ncLin(g,0,-70,0,0,['#a06836','#7a4622','#4e2a12']),2.6);
 g.save();ncRR(g,-72,-70,144,70,4);g.clip();g.strokeStyle='#341a0a';g.lineWidth=2.2;for(const y of[-52,-34,-17]){g.beginPath();g.moveTo(-72,y);g.lineTo(72,y);g.stroke()}
 g.strokeStyle='#c48a54aa';g.lineWidth=1.1;for(const y of[-50,-32,-15]){g.beginPath();g.moveTo(-72,y);g.lineTo(72,y);g.stroke()}
 g.strokeStyle='#5a301455';g.lineWidth=1.4;for(const [x,y,w] of[[-40,-62,22],[18,-44,26],[-22,-26,20],[34,-9,18],[-50,-8,14]]){g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+w/2,y-3,x+w,y);g.stroke()}g.restore();
 /* gold posts with chunky feet */
 for(const sx of[-1,1]){ncRR(g,sx>0?58:-80,-74,22,66,3);ncF(g,ncGold(g,sx*58,-74,sx*80,-8),2.4);g.fillStyle='#ffffff44';g.fillRect(sx>0?60:-78,-70,4,58);
  ncP(g,[sx*54,2,sx*54,-16,sx*60,-22,sx*80,-22,sx*86,-16,sx*86,2]);ncF(g,ncGold(g,sx*54,-22,sx*86,2),2.4);ncSheen(g,sx>0?58:-80,-74,22,66,t,5.5,sx>0?.35:0);ncStud(g,sx*70,-9,5);ncStud(g,sx*69,-58,4.2);ncStud(g,sx*69,-38,4.2)}
 P.lid&&P.lid();P.lid=null;
 /* gold band on the seam */
 ncRR(g,-60,-76,120,10,2);ncF(g,ncGold(g,0,-76,0,-66),2.2);for(const x of[-46,-30,30,46])ncStud(g,x,-71,3.4);
 /* the medallion and the crossed swords */
 const my=-70,gl=.25+.35*hv+.7*ch+.15*Math.sin(t*2.2);
 g.save();g.globalCompositeOperation='lighter';ncGlow(g,0,my,34+ch*30,'#ffd45a'+ncA(gl*.55));g.restore();
 g.beginPath();g.arc(0,my,22,0,Math.PI*2);ncF(g,ncGold(g,-22,my-22,22,my+22),2.6);
 g.beginPath();g.arc(0,my,15,0,Math.PI*2);ncF(g,g.createRadialGradient(-4,my-5,1,0,my,15),2);const q=g.createRadialGradient(-4,my-5,1,0,my,15);q.addColorStop(0,'#5a3a7a');q.addColorStop(1,'#1a0c2a');g.fillStyle=q;g.beginPath();g.arc(0,my,15,0,Math.PI*2);g.fill();g.strokeStyle=NCO;g.lineWidth=2;g.stroke();
 for(let i=0;i<8;i++){const a=i*Math.PI/4+Math.PI/8;ncRiv(g,Math.cos(a)*18.5,my+Math.sin(a)*18.5,1.8)}
 const sw=Math.sin(t*1.6)*.03+hv*.1+ch*Math.sin(t*30)*.04;
 g.save();g.translate(0,my);g.rotate(-.78+sw);g.translate(-26,0);ncSword(g,52,ncLin(g,0,-3,0,3,['#e04a4a','#8a1a1a']));g.restore();
 g.save();g.translate(0,my);g.rotate(Math.PI+.78-sw);g.scale(1,-1);g.translate(-26,0);ncSword(g,52,ncLin(g,0,-3,0,3,['#7a5230','#3a2010']));g.restore();
 /* a glint runs along the blades */
 const gp=((t*.45)%1.6);if(gp<1){const a=-.78,x=Math.cos(a)*(gp*56-26),y=my+Math.sin(a)*(gp*56-26);g.save();g.globalCompositeOperation='lighter';ncGlow(g,x,y,9+ch*8,'#ffffff'+ncA(.7));ncStar(g,x,y,5+ch*4,'#ffffffdd');g.restore()}
 /* embers drift up from the planks */
 g.save();g.globalCompositeOperation='lighter';for(let i=0;i<6;i++){const v=(t*.3+i/6)%1,x=-55+i*22+Math.sin(t*.9+i*1.3)*7*v;g.globalAlpha=Math.sin(v*Math.PI)*(.4+hv*.4+ch*.5);ncGlow(g,x,-14-v*84,3.2+v*1.5,'#ffb04a');g.fillStyle='#ffe0a0';g.fillRect(x-.8,-14-v*84-.8,1.6,1.6)}g.restore()}

/* ---------- ARMOR CRATE: stone blocks bound in blue steel, a gold heater shield as the lock ---------- */
function ncArmor(g,u,t,P){const hv=NCX.hov,ch=NCX.ch,L=ncLidPose('a',u);
 const stone=y0=>ncLin(g,0,y0,0,y0+70,['#b4bacc','#8e94aa','#5e6680']);
 const lidFace=()=>{ncP(g,[-80,0,-80,-28,-72,-38,72,-38,80,-28,80,0]);ncF(g,stone(-38),2.6);
  g.save();ncP(g,[-80,0,-80,-28,-72,-38,72,-38,80,-28,80,0]);g.clip();g.strokeStyle='#4a5068';g.lineWidth=1.6;for(const [x0,y0,x1,y1] of[[-36,-38,-36,0],[20,-38,20,-18],[-10,-18,60,-18],[-56,-18,-36,-18]]){g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.stroke()}
  g.strokeStyle='#ffffff55';g.lineWidth=2;g.beginPath();g.moveTo(-70,-35);g.lineTo(70,-35);g.stroke();g.restore();
  for(const sx of[-1,1]){ncP(g,[sx*58,0,sx*58,-38,sx*72,-38,sx*82,-28,sx*82,0]);ncF(g,ncLin(g,0,-38,0,0,['#6a8ae0','#3a5ab8','#1e2f6a']),2.4);ncRiv(g,sx*70,-19,4.4)}
  ncRR(g,-34,-38,10,38,1);ncF(g,ncLin(g,0,-38,0,0,['#5a7ad0','#24387a']),2);ncRR(g,24,-38,10,38,1);ncF(g,ncLin(g,0,-38,0,0,['#5a7ad0','#24387a']),2)};
 const lidIn=h=>{ncP(g,[-74,0,-66,-h,66,-h,74,0]);ncF(g,ncLin(g,0,-h,0,0,['#3a4058','#5a6078']),2.4);g.strokeStyle='#3a5ab8';g.lineWidth=3;g.stroke()};
 g.save();g.translate(L.sh,0);
 ncOpenLid(g,P,L,lidFace,lidIn,40,'#bfe0ff');
 /* body: stone blocks */
 ncRR(g,-74,-70,148,70,3);ncF(g,stone(-70),2.6);
 g.save();ncRR(g,-74,-70,148,70,3);g.clip();g.strokeStyle='#454c64';g.lineWidth=1.8;for(const [x0,y0,x1,y1] of[[-74,-36,74,-36],[-48,-70,-48,-36],[8,-70,8,-36],[-20,-36,-20,0],[44,-36,44,0]]){g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.stroke()}
 g.strokeStyle='#ffffff40';g.lineWidth=1.4;for(const [x0,y0,x1,y1] of[[-72,-34,72,-34],[-72,-68,72,-68]]){g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.stroke()}
 /* cracks that fill with blue light as the crate is opened */
 const cr=[[-60,-60,-52,-50,-56,-42],[30,-28,38,-18,34,-8],[-30,-24,-38,-14,-32,-4]];g.lineWidth=1.4;for(const c of cr){g.strokeStyle='#3a4058';g.beginPath();g.moveTo(c[0],c[1]);for(let i=2;i<c.length;i+=2)g.lineTo(c[i],c[i+1]);g.stroke()}
 if(ch>0||hv>0){g.save();g.globalCompositeOperation='lighter';g.strokeStyle='#7ac8ff'+ncA(.4*hv+ch);g.lineWidth=2+ch*2;for(const c of cr){g.beginPath();g.moveTo(c[0],c[1]);for(let i=2;i<c.length;i+=2)g.lineTo(c[i],c[i+1]);g.stroke()}g.restore()}
 g.restore();
 P.lid&&P.lid();P.lid=null;
 /* blue steel: two straps, a seam band and chamfered corner blocks */
 for(const x of[-34,24]){ncRR(g,x,-70,10,70,1);ncF(g,ncLin(g,0,-70,0,0,['#5a7ad0','#3a5ab8','#1e2f6a']),2)}
 ncRR(g,-74,-76,148,10,2);ncF(g,ncLin(g,0,-76,0,-66,['#6a8ae0','#2a4290']),2.2);for(const x of[-46,-14,14,46])ncRiv(g,x,-71,3);
 for(const sx of[-1,1]){ncP(g,[sx*58,2,sx*58,-76,sx*74,-76,sx*84,-66,sx*84,-8,sx*76,2]);ncF(g,ncLin(g,0,-76,0,2,['#6a8ae0','#3a5ab8','#1a2a60']),2.6);g.fillStyle='#ffffff38';g.fillRect(sx>0?60:-82,-72,4,64);
  ncRiv(g,sx*71,-58,5);ncRiv(g,sx*71,-18,5);ncRR(g,sx>0?60:-82,-40,22,8,2);ncF(g,ncLin(g,0,-40,0,-32,['#b4bacc','#6a7088']),1.8)}
 /* the gold heater shield with its keyhole */
 const sy=-74,gl=.2+.35*hv+.8*ch+.12*Math.sin(t*2);
 g.save();g.globalCompositeOperation='lighter';ncGlow(g,0,sy,40+ch*30,'#ffe08a'+ncA(gl*.25));g.restore();
 const sh=(w,h,y0)=>{g.beginPath();g.moveTo(0,y0);g.lineTo(w,y0+h*.12);g.lineTo(w,y0+h*.48);g.quadraticCurveTo(w*.86,y0+h*.86,0,y0+h);g.quadraticCurveTo(-w*.86,y0+h*.86,-w,y0+h*.48);g.lineTo(-w,y0+h*.12);g.closePath()};
 sh(24,58,sy-28);ncF(g,ncGold(g,-24,sy-28,24,sy+30),2.8);sh(17,44,sy-21);ncF(g,ncLin(g,-17,sy-21,17,sy+23,['#ffe9a0','#f0b838','#b8781a']),1.6,'#8a5a10');
 g.fillStyle='#ffffff66';g.beginPath();g.moveTo(-15,sy-18);g.lineTo(-2,sy-21);g.lineTo(-2,sy-4);g.lineTo(-15,sy-2);g.closePath();g.fill();
 const kg=.15+ch*.85+hv*.3;g.save();if(kg>.2){g.globalCompositeOperation='lighter';ncGlow(g,0,sy,16+ch*10,'#7ac8ff'+ncA(kg))}g.restore();
 g.beginPath();g.arc(0,sy-4,5.4,0,Math.PI*2);g.moveTo(-3,sy-1);g.lineTo(-5,sy+12);g.lineTo(5,sy+12);g.lineTo(3,sy-1);g.fillStyle=ch>.3?'#bfe6ff':'#1a0c14';g.fill();g.strokeStyle=NCO;g.lineWidth=1.4;g.stroke();
 /* a slow shine across the shield */
 const sp=(t*.4)%2;if(sp<1){g.save();sh(24,58,sy-28);g.clip();g.globalCompositeOperation='lighter';g.fillStyle='#ffffff55';g.translate(-30+sp*60,sy);g.rotate(.4);g.fillRect(-4,-40,7,80);g.restore()}
 g.restore()}

/* ---------- SPECIAL CRATE: violet panels framed in gold, a crystal lid, an emerald lock and a teal seam of light ---------- */
function ncSpecial(g,u,t,P){const hv=NCX.hov,ch=NCX.ch,L=ncLidPose('s',u),pulse=.5+.5*Math.sin(t*2.6);
 const lidFace=()=>{ncP(g,[-80,0,-68,-36,68,-36,80,0]);ncF(g,ncLin(g,0,-36,0,0,['#b07ae8','#7a3ac0','#4a1e78']),2.6);
  /* facets */g.save();ncP(g,[-80,0,-68,-36,68,-36,80,0]);g.clip();const F=[[-80,0,-40,-36,-24,0],[24,0,40,-36,80,0]];g.fillStyle='#ffffff22';for(const f of F){ncP(g,f);g.fill()}g.fillStyle='#2a0a4a44';ncP(g,[-24,0,0,-36,24,0]);g.fill();
  g.strokeStyle='#e0b8ff77';g.lineWidth=1.4;for(const [a,b,c2,d] of[[-40,-36,-24,0],[40,-36,24,0],[0,-36,-24,0],[0,-36,24,0]]){g.beginPath();g.moveTo(a,b);g.lineTo(c2,d);g.stroke()}g.restore();
  g.beginPath();g.moveTo(-68,-36);g.lineTo(68,-36);g.strokeStyle=NCAU[1];g.lineWidth=3;g.stroke();
  for(const sx of[-1,1]){ncP(g,[sx*62,0,sx*56,-36,sx*70,-36,sx*84,-6,sx*84,0]);ncF(g,ncGold(g,sx*56,-36,sx*84,0),2.4);ncP(g,[sx*30,-36,sx*44,-36,sx*52,-24,sx*38,-24]);ncF(g,ncGold(g,sx*30,-36,sx*52,-24),2)}};
 const lidIn=h=>{ncP(g,[-74,0,-64,-h,64,-h,74,0]);ncF(g,ncLin(g,0,-h,0,0,['#2a0a4a','#4a1e78']),2.4);g.strokeStyle='#5ff0e0';g.lineWidth=3;g.stroke()};
 ncOpenLid(g,P,L,lidFace,lidIn,38,'#9ffff0');
 /* body */
 ncRR(g,-74,-70,148,70,3);ncF(g,ncLin(g,0,-70,0,0,['#5a2a8a','#3a1660','#24103e']),2.6);
 const icons=[(x,y,c)=>{/* axe */g.beginPath();g.moveTo(x,y-18);g.lineTo(x,y+18);g.moveTo(x-1,y-12);g.quadraticCurveTo(x-14,y-16,x-14,y-6);g.quadraticCurveTo(x-10,y-2,x-1,y-4);g.moveTo(x+1,y-12);g.quadraticCurveTo(x+14,y-16,x+14,y-6);g.quadraticCurveTo(x+10,y-2,x+1,y-4);g.strokeStyle=c;g.stroke()},
  (x,y,c)=>{/* crossed arrows in a ring */g.beginPath();g.arc(x,y,11,0,Math.PI*2);g.moveTo(x-15,y+15);g.lineTo(x+15,y-15);g.moveTo(x+15,y-15);g.lineTo(x+8,y-14);g.moveTo(x+15,y-15);g.lineTo(x+14,y-8);g.moveTo(x-15,y-15);g.lineTo(x+15,y+15);g.moveTo(x-15,y-15);g.lineTo(x-8,y-14);g.moveTo(x-15,y-15);g.lineTo(x-14,y-8);g.strokeStyle=c;g.stroke()},
  (x,y,c)=>{/* scepter */g.beginPath();g.arc(x,y-11,7,0,Math.PI*2);g.moveTo(x,y-4);g.lineTo(x,y+18);g.moveTo(x-6,y+4);g.lineTo(x+6,y+4);g.moveTo(x-4,y+11);g.lineTo(x+4,y+11);g.strokeStyle=c;g.stroke();g.beginPath();g.arc(x,y-11,2.4,0,Math.PI*2);g.fillStyle=c;g.fill()}];
 [-42,0,42].forEach((x,i)=>{ncRR(g,x-18,-62,36,52,3);ncF(g,ncLin(g,0,-62,0,-10,['#2a0e4a','#3a1a60']),2);
  const lit=Math.max(hv*.6,Math.min(1,(ch-i*.25)*3)),lc=lit>.05?'#7affe8':NCAU[1];g.lineWidth=2.6;g.lineCap='round';g.lineJoin='round';
  if(lit>.05){g.save();g.globalCompositeOperation='lighter';ncGlow(g,x,-36,26,'#5ff0e0'+ncA(lit*.6));g.restore()}
  g.save();g.strokeStyle=NCO;g.lineWidth=4.6;icons[i](x,-36,NCO);g.restore();g.lineWidth=2.6;icons[i](x,-36,lc)});
 /* gold frame between the panels and a gold plinth */
 for(const x of[-21,21]){ncRR(g,x-3,-66,6,58,1);ncF(g,ncGold(g,x-3,-66,x+3,-8),1.6)}
 ncP(g,[-80,2,-80,-8,-70,-12,70,-12,80,-8,80,2]);ncF(g,ncGold(g,0,-12,0,2),2.4);
 P.lid&&P.lid();P.lid=null;
 /* the teal seam of light */
 g.save();g.globalCompositeOperation='lighter';ncGlow(g,0,-71,90,'#5ff0e0'+ncA(.12+.2*pulse*(.5+hv)+.5*ch));g.restore();
 ncRR(g,-76,-75,152,8,3);ncF(g,ncLin(g,-76,0,76,0,['#2ab8b0','#bffff6','#5ff0e0','#bffff6','#2ab8b0']),2);
 /* side crystals in gold frames */
 for(const sx of[-1,1]){const x=sx*78,y=-40;ncP(g,[x,y-26,x+sx*10,y,x,y+26,x-sx*10,y]);ncF(g,ncGold(g,x-10,y-26,x+10,y+26),2.4);
  const cg=.6+.4*Math.sin(t*2+sx);g.save();g.globalCompositeOperation='lighter';ncGlow(g,x,y,20,'#c08aff'+ncA(.25*cg+.5*ch+.2*hv));g.restore();
  ncP(g,[x,y-19,x+sx*6.5,y,x,y+19,x-sx*6.5,y]);ncF(g,ncLin(g,0,y-19,0,y+19,['#f0d8ff','#a868f0','#5a2aa0']),1.6);g.fillStyle='#ffffff99';ncP(g,[x,y-19,x+sx*6.5,y,x,y]);g.fill()}
 /* the emerald lock */
 const ey=-72,eg=.3+.3*pulse+.4*hv+ch;g.save();g.globalCompositeOperation='lighter';ncGlow(g,0,ey,30+ch*36,'#5ff0c8'+ncA(Math.min(1,eg)*.6));g.restore();
 ncP(g,[0,ey-26,22,ey,0,ey+26,-22,ey]);ncF(g,ncGold(g,-22,ey-26,22,ey+26),2.6);
 ncP(g,[0,ey-17,10,ey-8,10,ey+8,0,ey+17,-10,ey+8,-10,ey-8]);ncF(g,ncLin(g,0,ey-17,0,ey+17,['#c8fff0','#3ae0b0','#0a7a64']),1.8);
 g.fillStyle='#ffffffaa';ncP(g,[0,ey-17,10,ey-8,0,ey-4,-6,ey-10]);g.fill();g.fillStyle='#04403688';ncP(g,[0,ey+17,10,ey+8,0,ey+4]);g.fill();
 /* violet sparkles rise */
 g.save();g.globalCompositeOperation='lighter';for(let i=0;i<6;i++){const v=(t*.42+i/6)%1;g.globalAlpha=(1-v)*(.5+hv*.4+ch*.5);ncStar(g,-60+i*24+Math.sin(t*1.3+i)*5,-30-v*96,2.6+ch*2,i%2?'#e0b8ff':'#9ffff0')}g.restore()}

/* ---------- ECLIPSE CHEST: a dark vault between crowned gold pillars, a black sun ringed in fire ---------- */
function ncEclipse(g,u,t,P){const hv=NCX.hov,ch=NCX.ch,L=ncLidPose('p',u);
 /* aura and orbiting motes */
 g.save();g.globalCompositeOperation='lighter';ncGlow(g,0,-56,140+Math.sin(t*1.6)*10+ch*80,'#b070ff'+ncA(.16+.12*hv+.25*ch));
 const mote=front=>{for(let i=0;i<7;i++){const a=t*.55+i*Math.PI*2/7,d=Math.sin(a);if((d>0)!==front)continue;const x=Math.cos(a)*108,y=-58+d*26,al=.35+.65*(d+1)/2,r=2.2+1.4*(d+1)/2;ncGlow(g,x,y,8*r/3,'#ffd45a'+ncA(.7*al));ncStar(g,x,y,r,'#fff6d0'+ncA(al))}};mote(false);g.restore();
 const lidFace=()=>{ncP(g,[-64,0,-64,-24,-40,-34,40,-34,64,-24,64,0]);ncF(g,ncLin(g,0,-34,0,0,['#4a2a6a','#2a1640','#160a24']),2.6);
  g.strokeStyle=NCAU[1];g.lineWidth=2.4;g.beginPath();g.moveTo(-64,-24);g.lineTo(-40,-34);g.lineTo(40,-34);g.lineTo(64,-24);g.stroke();g.strokeStyle='#ffffff22';g.lineWidth=1.4;g.beginPath();g.moveTo(-60,-12);g.lineTo(60,-12);g.stroke();
  ncP(g,[-10,-33,0,-54,10,-33]);ncF(g,ncGold(g,-10,-54,10,-33),2.2);ncP(g,[-30,-31,-22,-42,-14,-33]);ncF(g,ncGold(g,-30,-42,-14,-31),1.8);ncP(g,[30,-31,22,-42,14,-33]);ncF(g,ncGold(g,14,-42,30,-31),1.8)};
 const lidIn=h=>{ncP(g,[-60,0,-52,-h,52,-h,60,0]);ncF(g,ncLin(g,0,-h,0,0,['#120820','#2a1640']),2.4);g.strokeStyle='#ffd45a';g.lineWidth=3;g.stroke()};
 ncOpenLid(g,P,L,lidFace,lidIn,36,'#ffe8a0',64);
 /* body: dark layered vault with drapes */
 ncRR(g,-66,-70,132,70,3);ncF(g,ncLin(g,0,-70,0,0,['#3a2058','#22123a','#140a22']),2.6);
 g.save();ncRR(g,-66,-70,132,70,3);g.clip();g.fillStyle='#00000040';for(const y of[-56,-28])g.fillRect(-66,y,132,6);
 for(const sx of[-1,1]){g.beginPath();g.moveTo(sx*66,-70);g.quadraticCurveTo(sx*40,-50,sx*50,0);g.lineTo(sx*66,0);g.closePath();g.fillStyle=ncLin(g,sx*40,0,sx*66,0,['#7a3ab8','#4a1e78']);g.fill();g.strokeStyle='#2a0e4a';g.lineWidth=1.6;g.beginPath();g.moveTo(sx*58,-66);g.quadraticCurveTo(sx*46,-40,sx*56,-4);g.stroke()}g.restore();
 ncRR(g,-70,-6,140,8,2);ncF(g,ncGold(g,0,-6,0,2),2);
 P.lid&&P.lid();P.lid=null;
 /* crowned pillars */
 for(const sx of[-1,1]){const x0=sx>0?64:-86;ncRR(g,x0,-104,22,108,2);ncF(g,ncGold(g,x0,-104,x0+22,4),2.6);g.fillStyle='#ffffff40';g.fillRect(x0+3,-100,4,96);
  ncP(g,[x0-4,-104,x0+26,-104,x0+22,-110,x0,-110]);ncF(g,ncGold(g,x0,-110,x0+22,-104),2);
  /* the crown: three spikes */ncP(g,[x0,-110,x0-2,-126,x0+5,-118,x0+11,-140,x0+17,-118,x0+24,-126,x0+22,-110]);ncF(g,ncGold(g,x0,-140,x0+22,-110),2.4);
  const cx=x0+11;ncP(g,[cx,-82,cx+6,-66,cx,-50,cx-6,-66]);ncF(g,ncLin(g,0,-82,0,-50,['#f0c8ff','#a050e0','#4a1a80']),1.8);
  const gg=.5+.5*Math.sin(t*2.2+sx*1.5);g.save();g.globalCompositeOperation='lighter';ncGlow(g,cx,-66,16,'#d080ff'+ncA(.3*gg+.6*ch));g.restore();
  ncP(g,[cx,-36,cx+4,-28,cx,-20,cx-4,-28]);ncF(g,'#120820',1.4);ncSheen(g,x0,-104,22,108,t,6.5,sx>0?.4:0)}
 /* the black sun */
 const ey=-44,R=22,cg=.5+.5*Math.sin(t*1.8),pw=.35+.25*cg+.4*hv+ch;
 g.save();g.globalCompositeOperation='lighter';ncGlow(g,0,ey,46+ch*60,'#ffb02a'+ncA(Math.min(1,pw)*.7));
 g.translate(0,ey);g.rotate(t*.35);for(let i=0;i<16;i++){g.rotate(Math.PI/8);g.fillStyle='#ffd45a'+ncA((.25+.3*cg+ch*.4)*(i%2?.6:1));ncP(g,[-2.6,-R-2,2.6,-R-2,0,-R-12-(i%2?0:8)-ch*14]);g.fill()}g.restore();
 for(let i=0;i<4;i++){g.save();g.translate(0,ey);g.rotate(i*Math.PI/2);ncP(g,[-6,-R+2,0,-R-20,6,-R+2]);ncF(g,ncGold(g,-6,-R-20,6,-R),2);g.restore()}
 g.beginPath();g.arc(0,ey,R,0,Math.PI*2);ncF(g,ncGold(g,-R,ey-R,R,ey+R),2.6);
 g.beginPath();g.arc(0,ey,R-5,0,Math.PI*2);g.fillStyle='#ffe9a0';g.fill();
 g.beginPath();g.arc(0,ey,R-7,0,Math.PI*2);ncF(g,g.createRadialGradient(0,ey,0,0,ey,R-7),0);const bq=g.createRadialGradient(-3,ey-3,0,0,ey,R-7);bq.addColorStop(0,'#2a1a3a');bq.addColorStop(1,'#04020a');g.fillStyle=bq;g.beginPath();g.arc(0,ey,R-7,0,Math.PI*2);g.fill();
 g.save();g.translate(0,ey);g.rotate(-t*.5);g.globalCompositeOperation='lighter';for(let i=0;i<12;i++){g.rotate(Math.PI/6);const tw=.5+.5*Math.sin(t*3+i);g.fillStyle='#fff2c0'+ncA((.25+.5*tw)*(.6+.4*hv+ch));g.beginPath();g.arc(0,-R-5,1.3+tw*.8,0,Math.PI*2);g.fill()}g.restore();
 /* the red gem above the sun, where the key fits */
 const gy=-80,rg=.5+.5*Math.sin(t*2.8);g.save();g.globalCompositeOperation='lighter';ncGlow(g,0,gy,22+ch*20,'#ff4a5a'+ncA(.35+.3*rg+.4*ch));g.restore();
 ncP(g,[0,gy-16,9,gy,0,gy+16,-9,gy]);ncF(g,ncGold(g,-9,gy-16,9,gy+16),2.2);ncP(g,[0,gy-11,6,gy,0,gy+11,-6,gy]);ncF(g,ncLin(g,0,gy-11,0,gy+11,['#ffd0d4','#ff3a4a','#8a0a1a']),1.4);g.fillStyle='#ffffffaa';ncP(g,[0,gy-11,6,gy,0,gy]);g.fill();
 P.lid&&P.lid();P.lid=null;g.save();g.globalCompositeOperation='lighter';mote(true);g.restore()}

/* the shared lid machinery: the gap that opens onto the light, the inside of the lid, and the lid itself */
function ncOpenLid(g,P,L,face,inner,lh,lc,hw){hw=hw||74;const a=L.a,ca=Math.cos(a),sa=Math.sin(a),gap=16*sa,top=-70-L.lift,t=NCX.t||0;
 if(a>.02||L.lift>.4){/* the opening: light pours out of the chest */
  const lg=Math.min(1,Math.max(a/1.2,L.lift/26));g.save();g.globalCompositeOperation='lighter';ncGlow(g,0,-74,90+lg*80,lc+ncA(.55*lg));ncGlow(g,0,-74,40+lg*30,'#ffffff'+ncA(.5*lg));
  /* soft rays fan up through the gap and sway slowly */
  for(let i=0;i<7;i++){const an=(i-3)*.2+Math.sin(t*.9+i*1.7)*.05,len=70+lg*110+Math.sin(t*1.7+i)*10,wd=7+(i%2)*5;g.save();g.translate((i-3)*hw*.2,-72);g.rotate(an);const q=g.createLinearGradient(0,0,0,-len);q.addColorStop(0,lc+ncA(.32*lg));q.addColorStop(1,lc+'00');g.fillStyle=q;g.beginPath();g.moveTo(-wd*.35,0);g.lineTo(wd*.35,0);g.lineTo(wd,-len);g.lineTo(-wd,-len);g.closePath();g.fill();g.restore()}
  g.restore();
  ncP(g,[-hw+4,-70,-hw+10,top-gap-2,hw-10,top-gap-2,hw-4,-70]);ncF(g,ncLin(g,0,top-gap,0,-70,['#fff8e0',lc,'#2a1408']),2.2)}
 if(ca<0){g.save();g.translate(0,top-gap);inner(lh*(-ca)*1.1+4);g.restore()}
 P.lid=()=>{if(ca>=0){g.save();g.translate(0,top-gap);g.scale(1,Math.max(.04,ca));face();g.restore()}}}

const NC_DRAW={w:ncWeapon,a:ncArmor,s:ncSpecial,p:ncEclipse};
function ncChest(g,x,y,s,u,k,t){u=Math.max(0,u||0);t=t||0;NCX.t=t;g.save();g.translate(x,y);g.scale(s,s);g.lineJoin='round';g.lineCap='round';
 /* ground shadow */
 const sh=g.createRadialGradient(0,4,0,0,4,96);sh.addColorStop(0,'#000a');sh.addColorStop(1,'#0000');g.fillStyle=sh;g.beginPath();g.ellipse(0,4,96,15,0,0,Math.PI*2);g.fill();
 if(NCX.hov>0){g.save();g.globalCompositeOperation='lighter';ncGlow(g,0,-56,130,{w:'#ffc04a',a:'#7ab4ff',s:'#c08aff',p:'#ffb02a'}[k]+ncA(.22*NCX.hov));g.restore()}
 const P={};NC_DRAW[k](g,u,t,P);if(P.lid)P.lid();
 g.restore()}
{const c0=chest;chest=function(g,x,y,s,u,k,t){if(NC_DRAW[k])return ncChest(g,x,y,s,u,k,t);return c0(g,x,y,s,u,k,t)}}

/* ---------- the opening scene: each chest charges and bursts in its own way ---------- */
const NC_TH={w:{c:'#ffd45a',d:['#8a5228','#b07440','#5e3418'],s:['#ffffff','#ffe9a0']},a:{c:'#7ac8ff',d:['#9aa0b4','#6a7088','#c8ccd8'],s:['#7ac8ff','#ffffff']},s:{c:'#5ff0e0',d:['#c08aff','#8a4ac8','#e0b8ff'],s:['#9ffff0','#5ff0e0']},p:{c:'#ffb02a',d:['#2a1640','#5a2a8a','#120820'],s:['#ffd45a','#fff6d0']}};
{const of0=openFx;openFx=function(q){of0(q);const k=q.ck||q.k,T=NC_TH[k];if(!T||q.cx||q.hw)return;const cx=W/2,y=CCY-40;
  /* debris in the chest's own materials: wood splinters, stone chips, crystal shards or eclipse ash */
  for(let i=0;i<70;i++){const a=-Math.PI/2+(Math.random()-.5)*2.6,v=260+Math.random()*620;fxAdd(q,{x:cx+(Math.random()-.5)*160,y:y+20,vx:Math.cos(a)*v,vy:Math.sin(a)*v,l:.9+Math.random()*.8,g:900,dr:.3,s:3+Math.random()*(k==='a'?7:5),c:T.d[i%3],ty:k==='s'?'star':'dot'})}
  for(let i=0;i<40;i++){const a=Math.random()*Math.PI*2,v=150+Math.random()*450;fxAdd(q,{x:cx,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v-120,l:.6+Math.random()*.7,g:200,dr:.8,s:2+Math.random()*3,c:T.s[i%2],ty:'star'})}
  q.rings.push({t0:q.t,x:cx,y,c:T.c,max:k==='p'?900:620,dur:k==='p'?1.4:1,i:0});if(k==='p')q.rings.push({t0:q.t+.12,x:cx,y,c:'#fff6d0',max:1100,dur:1.6,i:1})}}
{const dc0=drawCrateScene;drawCrateScene=function(){const q=S.cr2,k=q&&(q.ck||q.k);if(!q||!NC_DRAW[k]||q.cx||q.hw)return dc0();
  const t=q.t,O=q.O,ch=q.skipped?0:Math.max(0,Math.min(1,(t-1.9)/Math.max(.3,O-1.9))),c=ctx,cx=W/2,cy=GY-30-150;
  /* behind the chest: an eclipse that grows, or a rune circle on the floor */
  if(k==='p'&&t>1.2&&t<O+1.5){const u=Math.min(1,(t-1.2)/1.2)*(t>O?Math.max(0,1-(t-O)/1.5):1);c.save();c.globalCompositeOperation='lighter';ncGlow(c,cx,cy-40,260+ch*240,'#ffb02a'+ncA(.28*u));c.restore();
   c.save();c.globalAlpha=.85*u;c.fillStyle='#05020c';c.beginPath();c.arc(cx,cy-40,120+ch*60,0,Math.PI*2);c.fill();c.globalCompositeOperation='lighter';c.strokeStyle='#ffb02a55';c.lineWidth=26+ch*16;c.beginPath();c.arc(cx,cy-40,122+ch*60,0,Math.PI*2);c.stroke();c.strokeStyle='#ffd45a';c.lineWidth=6+ch*6;c.stroke();c.restore()}
  NCX.ch=ch;try{dc0()}finally{NCX.ch=0}
  c.save();c.globalCompositeOperation='lighter';
  if(k==='a'&&t>1.6&&t<O+.8){const u=Math.min(1,(t-1.6)/.6)*(t>O?Math.max(0,1-(t-O)/.8):1);c.translate(cx,GY-20);c.scale(1,.32);c.rotate(S.t*.6);c.strokeStyle='#7ac8ff'+ncA(.8*u);c.lineWidth=5;
   for(const r of[200,240]){c.beginPath();c.arc(0,0,r+ch*30,0,Math.PI*2);c.stroke()}for(let i=0;i<12;i++){c.rotate(Math.PI/6);c.beginPath();c.moveTo(205,0);c.lineTo(235,8);c.lineTo(235,-8);c.closePath();c.stroke()}}
  if(k==='s'&&t>1.9&&t<O+.4){const u=t>O?Math.max(0,1-(t-O)/.4):1;[-1,0,1].forEach((i,j)=>{const lit=Math.min(1,(ch-j*.25)*3);if(lit<=0)return;const x=cx+i*88,g2=c.createLinearGradient(0,cy+60,0,cy-600);g2.addColorStop(0,'#5ff0e0'+ncA(.55*lit*u));g2.addColorStop(1,'#5ff0e000');c.fillStyle=g2;c.fillRect(x-22,cy-600,44,660)})}
  if(k==='w'&&t>O-.5&&t<O+.35){/* two slashes cross the lock just before it bursts */for(const [d,t0] of[[1,O-.5],[-1,O-.32]]){const u=(t-t0)/.3;if(u<0||u>1.4)continue;const e=Math.min(1,u),al=u<1?1:1-(u-1)/.4;c.save();c.translate(cx,cy+10);c.rotate(d*.78);c.lineCap='round';c.globalAlpha=al;c.strokeStyle='#ffd45a66';c.lineWidth=34*(1-e*.6);c.beginPath();c.moveTo(-260,0);c.lineTo(-260+520*e,0);c.stroke();c.strokeStyle='#fff6d0';c.lineWidth=14*(1-e*.6);c.stroke();c.restore()}}
  c.restore()}}
