# python3 t_flchest104.py [game.html] : 10.4 Harvest Festival, the Harvest Chest (99o art, 99o2 roll and opening, 99o3 menus; prefix flc).
# Registration of crate key 'f' (CN / CT / CRN / PRICE / SH_INFO / SHOP), the drop table (flcOdds: tiers like the Graveyard Crate, fillers,
# companions, Legendary and Mythic secret), the roll measured over many chests, pity, grants (relics, duplicates, coins, XP, acorns and
# companions through fleGive / flpGive, kept in P.flcPend across a reload), the fallbacks when the other 10.4 parts are not loaded, the
# everyday crates / Eclipse / Celestial never giving harvest relics, save repair, flcAdd and its toast, the dock badges, the opening for
# every tier (lanterns, crows, gold moon, turkey, cornucopia, result, Back), Skip, the sound for every tier, reduced motion and
# Performance mode, Open 10, the crates menu banner and tabs, the shop row / odds window / Harvest Collection window and the Mythic purchase,
# the catalog card, DEV cheats, the 98t / 98v guard (window.TW_AC_TEST), frame cost against the Graveyard ritual, UI fit at
# 1600x900 / 1280x720 / 1024x640 (tools/td/rpu_ovl.js), no page errors. Screenshots in shots/w104_chest/.
# The other parts are stood in for by tools/fl/stub_chest.js (test only) in the pages that need them.
import asyncio,os,sys,json
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
OVL=open(os.path.join(HERE,'..','tools','td','rpu_ovl.js')).read()
STUB=open(os.path.join(HERE,'..','tools','fl','stub_chest.js')).read()
SHOTS=os.path.join(HERE,'shots','w104_chest');os.makedirs(SHOTS,exist_ok=True)
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:900]),flush=True)
    if not ok:FAIL.append(name)
SETUP="()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}window.FL_FORCE=1;return 1}"
HELP=r"""()=>{window.__h={
 seed(s){let a=s>>>0;window.__M0=window.__M0||Math.random;Math.random=function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}},
 unseed(){if(window.__M0)Math.random=window.__M0},
 adv(to){const q=S.cr2;if(!q)return;while(q.t<to){q.last=performance.now()-1000/30;flcUpdate();if(!S.cr2||S.cr2!==q)break}},
 open(T,K){FLC.force=T;FLC.forceK=K||null;P.fcr=Math.max(1,P.fcr|0);flcStart();return S.cr2},
 sleep(ms){return new Promise(r=>setTimeout(r,ms))},
 key(k){window.dispatchEvent(new KeyboardEvent('keydown',{key:k,bubbles:true}))}};return 1}"""
async def page(b,vw=1600,vh=900,stub=True,rm=False,init=None):
    ctx=await b.new_context(viewport={'width':vw,'height':vh},reduced_motion='reduce' if rm else 'no-preference')
    if init:await ctx.add_init_script(init)
    pg=await ctx.new_page();er=[];pg.on('pageerror',lambda e:er.append(str(e)[:300]))
    await pg.goto(H);await pg.wait_for_timeout(1400);E=pg.evaluate
    await E(SETUP);await E(OVL);await E(HELP)
    if stub:await E("()=>{"+STUB+"}")
    return ctx,pg,E,er

async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch()
        bl=[open(os.path.join(HERE,f)).read() for f in ('build.sh','build_ast3.sh')]
        def order(x):
            L=x.split();ix=[L.index(m) if m in L else -1 for m in ('99m_fl_core.js','99o_fl_chest_art.js','99o2_fl_chest_open.js','99o3_fl_chest_ui.js')]
            return -1 not in ix and ix==sorted(ix)
        chk('the three modules are registered in both build lists, in order, after 99m_fl_core.js (other 10.4 parts may sit between)',all(order(x) for x in bl))
        # ================= standalone: no other 10.4 part loaded =================
        ctx,pg,E,er0=await page(b,stub=False)
        r=await E("""()=>[CN.f,CT.f,CRN.f,PRICE.f,!!SH_INFO.f,FL.chest.key,typeof flcAdd,typeof flcOpenUI,typeof flcOdds,typeof flcCollection,SHOP[0]&&SHOP[0].k,price('f')]""")
        chk('crate key f registered: CN fcr, "Harvest Chest added!", CRN, 1,500 coins, shop info; flcAdd / flcOpenUI / flcOdds / flcCollection exist; the chest leads the shop list while the festival runs',
            r[:6]==['fcr','Harvest Chest added!','Harvest Chest',1500,True,'f'] and r[6:10]==['function']*4 and r[10]=='f' and r[11]<=1500,r)
        r=await E("""()=>{const o=flcOdds(),s=o.rows.reduce((a,x)=>a+x.p,0),byT=[0,1,2,3,4,5].map(t=>o.rows.filter(x=>x.tier===t).reduce((a,x)=>a+x.p,0));
          return [+s.toFixed(9),byT.map((v,i)=>Math.abs(v-HW_ODDS[i])<1e-9),o.pity,o.hide,o.rows.filter(x=>x.k==='pet').map(x=>[x.id,x.tier,+(x.p*100).toFixed(2)]),o.rows.filter(x=>x.k!=='relic'&&x.k!=='pet').map(x=>x.k+x.tier),o.gear.length]}""")
        chk('flcOdds: the table adds up to 100%, every tier matches the Graveyard Crate (40 / 29 / 20 / 8.25 / 2 / 0.75), pity 15, Legendary and Mythic secret, Acorn Scamp 1.5% (Rare) and Emberleaf 0.4% (Legendary), fillers only at Common / Uncommon',
            r[0]==1 and all(r[1]) and r[2]==15 and r[3]==[0,0,0,0,1,1] and r[4]==[['flsquir',2,1.5],['flfox',4,0.4]] and sorted(r[5])==sorted(['coin0','xp0','ac0','coin1','ac1']) and r[6]==6,r)
        # the merged build has every part: stand the other parts aside for these two checks (their relics, flgGive / flgBuy / flgWhyNot,
        # fleGive and flpGive), as when the chest part ships alone; they are put back right after
        MISS=await E("""()=>{const W=window,o={fn:{},a:{},w:{}};for(const k of ['flgGive','flgBuy','flgWhyNot','fleGive','flpGive']){o.fn[k]=W[k];W[k]=undefined}
          for(const id of FL.gear.a)if(AR[id]){o.a[id]=AR[id];delete AR[id]}for(const id of FL.gear.w)if(WP[id]){o.w[id]=WP[id];delete WP[id]}W.__miss=o;return Object.keys(o.a).length+Object.keys(o.w).length}""")
        r=await E("""()=>{__h.seed(11);const K={},g0=P.gold,x0=P.xp;P.fcr=400;P.fcpity=0;for(let i=0;i<400;i++){const q=crateRoll('f');K[q.fl.k]=(K[q.fl.k]||0)+1}__h.unseed();return [K,P.fcr,P.gold>g0,P.xp>x0,(P.flcPend||[]).length]}""")
        chk('without the gear, companion and festival parts: every pull still pays (a missing relic becomes a purse, acorns become coins, no companions), chests are spent and nothing waits',
            set(r[0].keys())<={'coin','xp'} and sum(r[0].values())==400 and r[1]==0 and r[2] and r[4]==0,r)
        r=await E("""async()=>{P.fcr=2;crateHub();await __h.sleep(500);const fb=document.getElementById('flcb');const st=fb&&fb.querySelectorAll('.flci canvas').length;flcCollection();await __h.sleep(500);const w=document.getElementById('flcwin');
          return [!!fb,st,!!w,[...document.querySelectorAll('.flcbuy')].map(b=>b.disabled),w&&w.textContent.includes('Coming soon')]}""")
        chk('standalone menus: the crates banner shows its twelve empty relic slots and the Harvest Collection opens with its Mythic cards waiting ("Coming soon", not buyable) when the gear part is missing',
            r[0] and r[1]==12 and r[2] and all(r[3]) and r[4],r)
        await E("""()=>{shClose();const W=window,o=W.__miss;if(!o)return;for(const k in o.fn)W[k]=o.fn[k];Object.assign(AR,o.a);Object.assign(WP,o.w);delete W.__miss;title()}""")
        # ... and the merged behaviour with every part loaded: relics through flgGive, acorns and companions waiting in P.flcPend and then paid once
        r=await E("""()=>{__h.seed(12);for(const id of FL.gear.a)delete P.ownA[id];for(const id of FL.gear.w)delete P.own[id];for(const id of [FL.pets.r,FL.pets.l])if(P.pets)delete P.pets[id];P.flcPend=[];
          const sp={g:0,e:[],p:[]},G=flgGive,E2=fleGive,F=flpGive;flgGive=function(){sp.g++;return G.apply(this,arguments)};fleGive=function(n,s,o){sp.e.push(n);return E2.call(this,n,s,Object.assign({},o,{quiet:1}))};flpGive=function(id,o){sp.p.push(id);return F.call(this,id,Object.assign({},o,{silent:1}))};
          const K={},a0=fleAcorns();let want=0;P.fcr=400;P.fcpity=0;for(let i=0;i<400;i++){const q=crateRoll('f');K[q.fl.k]=(K[q.fl.k]||0)+1;if(q.fl.k==='ac')want+=q.fl.n}const waiting=(P.flcPend||[]).length;
          const n=flcPendRun(),n2=flcPendRun();flgGive=G;fleGive=E2;flpGive=F;const got=fleAcorns()-a0;title();
          return {K,fcr:P.fcr,waiting,n,n2,want,got,e:sp.e.reduce((a,b)=>a+b,0),pets:sp.p,petOwn:sp.p.every(id=>petOwned(id)),relics:flgCount(),g:sp.g}}""")
        chk('merged: every pull pays through the real parts (relics through flgGive, acorns through fleGive, companions through flpGive), the acorns and companions wait in P.flcPend and are paid exactly once',
            r['fcr']==0 and r['K'].get('relic',0)>200 and r['K'].get('ac',0)>0 and r['g']>=r['K']['relic'] and r['waiting']==r['K'].get('ac',0)+r['K'].get('pet',0) and r['n']==r['waiting'] and r['n2']==0 and r['got']==r['want']==r['e'] and r['petOwn'] and r['relics']>=10,r)
        chk('standalone: no page errors',not er0,er0);await ctx.close()

        # ================= the main page, with the test stand-ins =================
        ctx,pg,E,er=await page(b)
        r=await E("""()=>{const out={},n=40000;__h.seed(7);const T=[0,0,0,0,0,0],K={};for(let i=0;i<n;i++){P.fcpity=0;const q=flcRoll();T[q.tier]++;K[q.k]=(K[q.k]||0)+1}__h.unseed();
          const o=flcOdds(),exp={};for(const x of o.rows)exp[x.k]=(exp[x.k]||0)+x.p;return [T.map(v=>+(v/n*100).toFixed(2)),Object.fromEntries(Object.entries(K).map(([k,v])=>[k,+(v/n*100).toFixed(2)])),Object.fromEntries(Object.entries(exp).map(([k,v])=>[k,+(v*100).toFixed(2)]))]}""")
        ok=all(abs(a-b2)<=max(.35,b2*.12) for a,b2 in zip(r[0],[40,29,20,8.25,2,.75])) and all(abs(r[1].get(k,0)-v)<=max(.4,v*.12) for k,v in r[2].items())
        chk(f'the roll over 40,000 picks matches the table: tiers {r[0]} %, kinds {r[1]} (expected {r[2]})',ok,r)
        r=await E("""()=>{__h.seed(3);P.fcr=3000;P.fcpity=0;let gap=0,mx=0,ep=0;for(let i=0;i<3000;i++){const q=crateRoll('f');if(q.fl.tier>=3){ep++;gap=0}else{gap++;mx=Math.max(mx,gap)}}const p14=(()=>{P.fcr=1;P.fcpity=14;return crateRoll('f').fl.tier})();__h.unseed();return [mx,ep,p14,P.fcpity]}""")
        chk('pity: over 3,000 chests never more than 14 in a row without Epic or better, and a chest at pity 14 is Epic or better (the counter then resets)',r[0]<=14 and r[2]>=3 and r[3]==0,r)
        r=await E("""()=>{P.fcr=5;for(const id of FL.gear.a)delete P.ownA[id];for(const id of FL.gear.w)delete P.own[id];__h.seed(5);
          FLC.force=3;FLC.forceK='relic';const g0=P.gold,x0=P.xp,c0=P.fcr,a=crateRoll('f');const own1=(a.kind==='a'?P.ownA:P.own)[a.id];
          FLC.force=3;FLC.forceK='relic';(a.kind==='a'?P.ownA:P.own)[a.kind==='a'?FL.gear.w[3]:FL.gear.a[3]]=1;const b=crateRoll('f');
          FLC.force=0;FLC.forceK='coin';const g1=P.gold,c=crateRoll('f');const coin=P.gold-g1;FLC.force=0;FLC.forceK='xp';const x1=P.xp,d=crateRoll('f');const xp=P.xp-x1;__h.unseed();
          return [!!own1,a.dup,b.dup,b.it.r,c.fl.n===coin,coin>=150&&coin<=250,d.fl.n===xp,c0-P.fcr,__flLog.filter(x=>x[0]==='flg').length>=2]}""")
        chk('grants: a new relic is owned at once (through flgGive), a duplicate turns into 40 XP and duplicate gold, a purse adds its 150-250 coins, XP adds its XP, one chest per pull',
            r[0] and r[1] is False and r[2] is True and r[4] and r[5] and r[6] and r[7]==4 and r[8],r)
        r=await E("""()=>{__flLog.length=0;P.fcr=2;P.flcPend=[];const a0=fleAcorns();FLC.force=1;FLC.forceK='ac';const a=crateRoll('f');const pend=JSON.stringify(P.flcPend);const n=flcPendRun();
          for(const id of [FL.pets.r,FL.pets.l])delete P.pets[id];FLC.force=2;FLC.forceK='pet';const b=crateRoll('f');const pend2=JSON.stringify(P.flcPend);flcPendRun();
          const owned=petOwned(FL.pets.r);const ok2=flcPetOk(FL.pets.r);return [a.fl.k,pend,n,fleAcorns()-a0===a.fl.n,b.fl.k,pend2,owned,ok2,__flLog.map(x=>x[0])]}""")
        chk('acorns and companions wait in P.flcPend until the reveal ends, then go through fleGive / flpGive; an owned companion is no longer rolled',
            r[0]=='ac' and '"k":"ac"' in r[1] and r[2]==1 and r[3] and r[4]=='pet' and 'flsquir' in r[5] and r[6] and r[7] is False and 'fle' in r[8] and 'flp' in r[8],r)
        r=await E("""()=>{__h.seed(9);const hw0=Object.keys(AR).concat(Object.keys(WP)).filter(id=>(AR[id]||WP[id]).fl&&(AR[id]||WP[id]).hw).length;const bad=[];const R={w:0,a:0,s:0,p:0,c:0};P.crates=600;P.acr=600;P.scr=600;P.pcr=200;P.ccr=200;
          for(const k of ['w','a','s','p','c']){for(let i=0;i<(k==='p'||k==='c'?200:600);i++){const q=crateRoll(k);if(!q)break;R[k]++;const it=(q.kind==='a'?AR:WP)[q.id];if(it&&it.fl)bad.push(k+':'+q.id)}}
          const od=['w','a','s'].map(k=>shItems(k).some(([t,id])=>(t==='a'?AR:WP)[id].fl)),hwleft=Object.keys(AR).concat(Object.keys(WP)).filter(id=>(AR[id]||WP[id]).fl&&(AR[id]||WP[id]).hw).length-hw0;__h.unseed();return [bad,R,od,hwleft,shOdds('a').Mythic]}""")
        chk('the everyday crates, the Eclipse and the Celestial Chest never give harvest relics (2,200 rolls), the shop lists them nowhere else, and the temporary hiding leaves no mark',
            r[0]==[] and r[1]=={'w':600,'a':600,'s':600,'p':200,'c':200} and r[2]==[False,False,False] and r[3]==0,r)
        r=await E("""()=>{const o=sgShape({fcr:-5,fcpity:99,flcPend:[{k:'ac',n:30},{k:'pet',id:'nope'},{k:'ac',n:-3},'x',{k:'pet',id:FL.pets.l}]}),o2=sgShape({fcr:'abc',fcpity:3.6}),o3=sgShape({fcr:7.9,flcPend:'zz'});
          const s=JSON.parse(JSON.stringify(P));s.fcr=-2;s.fcpity='q';s.flcPend=[{k:'ac',n:5000}];load(s);const p=[P.fcr,P.fcpity,P.flcPend];P.fcr=3.5;save();return [o.fcr,o.fcpity,o.flcPend,o2.fcr,o2.fcpity,o3.fcr,o3.flcPend,p,P.fcr]}""")
        chk('save repair: chest count, pity and waiting grants are cleaned on every load (bad numbers, unknown companions, junk entries) and the count stays a whole number on save',
            r[0]==0 and r[1]==14 and r[2]==[{'k':'ac','n':30},{'k':'pet','id':'flfox'}] and r[3]==0 and r[4]==3 and r[5]==7 and r[6]==[] and r[7]==[0,0,[]] and r[8]==3,r)
        r=await E("""async()=>{P.fcr=0;P.crates=P.acr=P.scr=P.pcr=P.hcr=P.ccr=0;save();crateHub();await __h.sleep(300);const n=flcAdd(3,'Harvest Calendar');await __h.sleep(450);const t=document.getElementById('flctoast');
          const tx=t&&t.textContent,on=t&&t.classList.contains('on');flcAdd(1);await __h.sleep(350);const tx2=t.textContent;const dock=document.getElementById('dk_sh'),sub=document.querySelector('.dkst[data-dks="cr"]');
          return [n,tx,on,tx2,dock&&dock.textContent.trim(),sub&&sub.textContent.trim(),dkBadge('sh'),__rpuOvl(t)]}""")
        chk('flcAdd adds chests with a toast that names the source and merges a quick second gift; the dock Shop badge and the Owned crates tab count the chests',
            r[0]==3 and '+3 Harvest Chests' in r[1] and 'Harvest Calendar' in r[1] and r[2] and '+4 Harvest Chests' in r[3] and r[4].endswith('4') and r[5].endswith('4') and r[6]==4 and r[7]==[],r)
        await pg.screenshot(path=os.path.join(SHOTS,'toast_1600.png'))
        # ---- the opening, every tier ----
        res=[]
        for T in range(6):
            r=await E("""async(T)=>{__h.seed(20+T);const q=__h.open(T,'relic');const O=q.O,E2=q.E;const out={T,fc:q.fc,O,E:E2};__h.adv(1.0);out.heap=q.leaves.some(L=>L.st);__h.adv(2.2);out.look=1;
              __h.adv(O-.3);out.heap=out.heap&&q.leaves.length===0;out.lit=q.lit.filter(Boolean).length;out.fly=q.crows.filter(c=>!c.p).length;out.coins=q.coins.length;__h.adv(O+.6);out.open=!!q.fired.open;out.title=1;__h.adv(E2+.1);await __h.sleep(80);
              out.done=q.done;const h=ov.querySelector('.flcres h2');out.h2=h&&h.textContent;out.eq=!!document.getElementById('a');__h.unseed();return out}""",T)
            if T in (3,5):await pg.screenshot(path=os.path.join(SHOTS,f'result_t{T}_1600.png'))
            await E("()=>{crateEnd();title()}");res.append(r)
        ok=all(x['fc']==1 and x['lit']==x['T']+1 and x['open'] and x['done'] and x['h2'] and x['h2'].startswith(['Common','Uncommon','Rare','Epic','Legendary','Mythic'][x['T']]) and x['eq'] for x in res)
        ok=ok and all((x['fly']>2)==(x['T']>=3) for x in res) and res[5]['coins']>0 and res[4]['coins']==0 and all(x['heap'] for x in res)
        chk('the opening for every tier: the gust blows the leaf heap away, one lantern per tier is lit before the lid, crows fly from Epic up, the cornucopia pours coins only at Mythic, the lid bursts, the result names the rarity and offers Equip',ok,res)
        r=await E("""()=>{const q=__h.open(5,'relic');const gt=q.goldT;__h.adv(gt+1.2);drawBG();drawCrateScene();const B=FLC_BK,mu=q.my;const s1=[!!B&&!!B.bg&&!!B.low&&!!B.cornL&&!!B.cornR,mu<300];__h.adv(7.5);const out=[s1,q.my];crateEnd();title();return [out,FLC_BK===null]}""")
        chk('Mythic: the scene is baked once (sky, corn rows, patch, front corn), the moon has risen high before the feathers fan, and the bake is released when the chest closes',r[0][0]==[True,True] and r[1],r)
        r=await E("""async()=>{P.fcr=3;const q=__h.open(5,'relic');__h.adv(1.0);crateSkip();const a=[q.t,q.skipped,q.lit.filter(Boolean).length,q.leaves.length];__h.adv(q.O+.3);crateSkip();const b=q.t>=q.E;__h.adv(q.E+.2);await __h.sleep(60);
          const res=!!ov.querySelector('.flcres');document.getElementById('b').click();await __h.sleep(200);return [a,+q.O.toFixed(2),b,res,S.mode,!!document.getElementById('flcb')]}""")
        chk('Skip: the first press jumps to the lid with every lantern lit and the heap gone, the second goes straight to the result; Back returns to the crates menu',
            abs(r[0][0]-(r[1]-.05))<.04 and r[0][1]==1 and r[0][2]==6 and r[0][3]==0 and r[2] and r[3] and r[5],r)
        r=await E("""async()=>{P.fcr=2;crateHub();await __h.sleep(300);FLC.force=1;FLC.forceK='coin';__h.key(' ');document.getElementById('flcop').click();await __h.sleep(120);const q=S.cr2;const fc=q&&q.fc;__h.key(' ');await __h.sleep(80);const t1=q.t;__h.key('Enter');await __h.sleep(80);const t2=q.t;
          __h.adv(q.E+.1);await __h.sleep(60);const m=document.getElementById('m');m.click();await __h.sleep(150);const q2=S.cr2;const again=!!(q2&&q2.fc&&q2!==q);__h.key('Escape');__h.key('Escape');__h.adv(q2.E+.1);await __h.sleep(60);return [fc,t1>=q.O-.06,t2>=q.E,again,P.fcr,!!ov.querySelector('.flcres')]}""")
        chk('keys and buttons: Open starts the ritual, Space skips to the lid, Enter to the result, "Open another" starts the next chest',r[0]==1 and r[1] and r[2] and r[3] and r[4]==0 and r[5],r)
        await E("()=>{crateEnd();title()}")
        r=await E("""()=>{ensureAudio();const out=[];let gy=1e9;for(let k=0;k<3;k++){const gq={tier:5,O:HXT.O[5],it:{col:'#fff'}};hxPrep(gq);const g0=performance.now();hxAudio(gq);gy=Math.min(gy,performance.now()-g0);try{gq.aud.disconnect()}catch(x){}}
          let f5=1e9;for(let k=0;k<3;k++){const q={tier:5,O:FLCT.O[5],pt:[],crowT:FLCT.O[5]-1.8,goldT:FLCT.O[5]-2.7};q.pt=flcTimes(q);const a=performance.now();flcAudio(q);f5=Math.min(f5,performance.now()-a);try{q.aud.disconnect()}catch(x){}}for(let T=0;T<6;T++){const q={tier:T,O:FLCT.O[T],pt:[],crowT:FLCT.O[T]-1.8,goldT:FLCT.O[T]-2.7};q.pt=flcTimes(q);let e=null;const t0=performance.now();try{flcAudio(q);const t1=performance.now();flcReveal(q.aud,ac.currentTime+.2,T,true);flcReveal(q.aud,ac.currentTime+.2,T,false);out.push([T,!!q.aud,Math.round(t1-t0)])}catch(x){out.push([T,'ERR',String(x)])}try{q.aud.disconnect()}catch(x){}}
          return [ac&&ac.state,out,Math.round(gy),Math.round(f5)]}""")
        chk('sound: every tier schedules its ritual (wind, crickets, gust, chimes, drum, crows, gold shimmer, feather fans, gobble, coins) and its full and short reveal without errors; the start costs no more than the Graveyard ritual\'s (the reveal is scheduled later)',
            all(len(x)==3 and x[1] is True for x in r[1]) and r[3]<=max(40,1.25*r[2]),r)
        r=await E("""async()=>{const q=__h.open(2,'relic');const s=[q.rm,q.lo,q.heapN];crateEnd();title();ST.perf='low';try{applyLayout()}catch(e){}const q2=__h.open(2,'relic');const s2=[q2.lo,q2.heapN,q2.vort.length];__h.adv(q2.O+.1);const f2=q2.fx.length;crateEnd();title();ST.perf='high';try{applyLayout()}catch(e){}
          const q3=__h.open(2,'relic');__h.adv(q3.O+.1);const f3=q3.fx.length;crateEnd();title();return [s,s2,f2,f3]}""")
        chk('Performance mode: fewer heap leaves, circling leaves and sparks, no mist',r[1][0] is True and r[1][1]<r[0][2] and r[2]<r[3],r)
        r=await E("""async()=>{P.fcr=23;P.fcpity=14;__flLog.length=0;crateHub();await __h.sleep(300);document.getElementById('flcop10').click();await __h.sleep(1300);const cards=ov.querySelectorAll('.flcbat .cbk').length;const best=ov.querySelector('.cbb')&&ov.querySelector('.cbb').textContent;
          const o=__rpuOvl(ov.querySelector('.flcbat'));return [cards,P.fcr,best,!!document.getElementById('m10'),(P.flcPend||[]).length,o]}""")
        chk('Open 10: ten pulls rolled at once (pity included), the summary shows each with its icon, waiting acorns / companions are handed over, "Open 10 more" stays while ten are left',
            r[0]==10 and r[1]==13 and r[2] in ('Epic','Legendary','Mythic') and r[3] and r[4]==0 and r[5]==[],r)
        await pg.screenshot(path=os.path.join(SHOTS,'batch_1600.png'))
        r=await E("""async()=>{__flLog.length=0;P.fcr=2;delete P.pets[FL.pets.l];const q=__h.open(4,'pet');__h.adv(q.O+1.2);drawBG();drawCrateScene();const sil=!!q.img;__h.adv(q.E+.1);await __h.sleep(200);
          const pg=document.getElementById('flcpg');return [q.res.k,sil,!!P.pets[FL.pets.l],__flLog.map(x=>x[0]).includes('flp'),!!pg,ov.textContent.includes('Emberleaf'),(P.flcPend||[]).length,__rpuOvl(ov.querySelector('.flcres'))]}""")
        chk('a companion pull: its glowing silhouette rises from the chest, then flpGive hands it over (its own reveal takes the screen; without one, a companion result with the Companion Hall button)',
            r[0]=='pet' and r[1] and r[2] and r[3] and r[4] and r[5] and r[6]==0 and r[7]==[],r)
        await pg.screenshot(path=os.path.join(SHOTS,'result_pet_1600.png'))
        r=await E("""async()=>{title();await __h.sleep(200);DEV.open=true;devAct('x:flct3');await __h.sleep(150);const q=S.cr2;const out=[!!q&&q.fc,q&&q.tier,DEV.open,S.mode];crateEnd();title();return out}""")
        chk('DEV "Open: Epic" starts an Epic Harvest Chest at once (the panel closes, the home screen does not take over)',r==[1,3,False,'crate'],r)
        # ---- the crates menu ----
        r=await E("""async()=>{P.fcr=4;P.hcr=2;FLC.tab=null;crateHub();await __h.sleep(700);const fb=document.getElementById('flcb'),hb=ov.querySelector('.hwb');const tabs=[...ov.querySelectorAll('.flctab')].map(b=>b.dataset.ft+':'+b.classList.contains('on'));
          const a=[getComputedStyle(fb).display,getComputedStyle(hb).display];ov.querySelector('.flctab[data-ft="h"]').click();await __h.sleep(100);const b=[getComputedStyle(fb).display,getComputedStyle(hb).display];ov.querySelector('.flctab[data-ft="f"]').click();await __h.sleep(100);
          const head=ov.querySelector('h2+p').textContent;return [tabs,a,b,head.includes('6'),fb.querySelectorAll('.flci').length,fb.querySelector('.flcpie')&&fb.querySelector('.flcpie').textContent.includes('???'),__rpuOvl(fb),__rpuOvl(ov.querySelector('.flctabs'))]}""")
        chk('crates menu: the Harvest Chest banner (odds pie with Legendary / Mythic hidden, pity bar, twelve relics) leads the seasonal section; with the Graveyard Crate up too, two tabs switch between them; the header counts the chests',
            r[0]==['f:true','h:false'] and r[1]==['grid','none'] and r[2][0]=='none' and r[2][1]!='none' and r[3] and r[4]==12 and r[5] and r[6]==[] and r[7]==[],r)
        await pg.screenshot(path=os.path.join(SHOTS,'hub_1600.png'))
        r=await E("""async()=>{window.FL_FORCE=-1;P.fcr=0;for(const id of FL.gear.a)delete P.ownA[id];for(const id of FL.gear.w)delete P.own[id];crateHub();await __h.sleep(400);const a=!!document.getElementById('flcb');P.fcr=1;crateHub();await __h.sleep(400);const b=!!document.getElementById('flcb'),bb=!!document.getElementById('flcbuy');
          shop();await __h.sleep(300);const s=SHOP.some(o=>o.k==='f');window.FL_FORCE=1;shop();await __h.sleep(300);return [a,b,bb,s,SHOP[0].k]}""")
        chk('after the festival: the chest leaves the shop and its banner only stays for players who still hold chests or relics (no Buy button)',r==[False,True,False,False,'f'],r)
        r=await E("""async()=>{flcOpenUI(()=>title());await __h.sleep(500);const fb=document.getElementById('flcb');const r1=fb.getBoundingClientRect();return [!!fb,r1.top>=0,typeof S.back==='function']}""")
        chk('flcOpenUI opens the crates menu with the Harvest Chest in view',all(r),r)
        # ---- the shop ----
        r=await E("""async()=>{P.gold=10000;P.fcr=0;SHX.sel='f';shop();await __h.sleep(700);const row=ov.querySelector('.shr[data-k="f"]');const rib=row&&row.querySelector('.flcrib');const box=document.getElementById('flcsh2');
          const p2=document.getElementById('shp2').textContent;document.getElementById('shbuy').click();await __h.sleep(200);const after=[P.gold,P.fcr];return [!!row,rib&&rib.textContent,!!box,box&&box.classList.contains('two'),p2.includes('Buy chest'),after,__rpuOvl(document.getElementById('shp'))]}""")
        chk('shop: the Harvest Chest row (LIMITED) is first, its panel says "Buy chest", buying takes 1,500 coins and adds a chest; the Harvest Collection banner sits beside the Graveyard one; nothing overlaps',
            r[0] and r[1]=='LIMITED' and r[2] and r[3] and r[4] and r[5]==[8500,1] and r[6]==[],r)
        await pg.screenshot(path=os.path.join(SHOTS,'shop_1600.png'))
        r=await E("""async()=>{shOddsModal('f');await __h.sleep(400);const m=document.querySelector('.flcodds');const t=m.textContent;const o=__rpuOvl(m);shClose();shOddsModal('a');await __h.sleep(200);const ta=document.querySelector('.shmc').textContent;shClose();
          return [t.includes('???'),t.includes('Acorn Scamp'),t.includes('Emberleaf'),t.includes('Horn of Plenty'),t.includes('15 chests'),o,FL.gear.a.concat(FL.gear.w).some(id=>ta.includes((AR[id]||WP[id]).n))]}""")
        chk('contents & odds: the pie keeps Legendary and Mythic secret, lists the twelve relics by rarity with the fillers and both companions, the pity; the Armor crate window lists no harvest relic',
            r[:5]==[True]*5 and r[5]==[] and r[6] is False,r)
        r=await E("""async()=>{P.gold=120000;const M={a:FL.gear.a[5],w:FL.gear.w[5]};delete P.ownA[M.a];delete P.own[M.w];flcCollection();await __h.sleep(600);const w=document.getElementById('flcwin');const o=__rpuOvl(w);
          const btn=[...w.querySelectorAll('[data-fb]')].map(b=>[b.dataset.fb,b.disabled]);{const bb=w.querySelector('[data-fb="a"]');bb.click();await __h.sleep(400);bb.click()};await __h.sleep(1200);const w2=document.getElementById('flcwin');const st=[P.gold,!!P.ownA[M.a],!!P.own[M.w]];
          const b2=[...w2.querySelectorAll('[data-fb]')].map(b=>[b.dataset.fb,b.disabled,b.textContent.trim().slice(0,12)]);const note=w2.querySelector('.flcnote')&&w2.querySelector('.flcnote').textContent;return [btn,st,b2,note,o,w2.textContent.includes(FL.ab.n)]}""")
        chk('Harvest Collection: Feastlord\'s Aegis, Horn of Plenty and the Feast Bundle at 100,000 / 100,000 / 175,000; buying the armor takes 100,000 and grants it (flgGive), the bundle then shows "Part owned"; the ability and the twelve relics are listed',
            r[0]==[['a',False],['w',False],['b',True]] and r[1]==[20000,True,False] and r[2][0][1] and r[2][2][1] and 'Part owned' in r[2][2][2] and r[3] and r[4]==[] and r[5],r)
        await pg.screenshot(path=os.path.join(SHOTS,'collection_1600.png'))
        await E("()=>shClose()")
        r=await E("""async()=>{P.gold=50;window.FL_FORCE=-1;flcCollection();await __h.sleep(300);const w=document.getElementById('flcwin');const d=[...w.querySelectorAll('[data-fb]')].every(b=>b.disabled);const t=w.textContent.includes('no longer sold');shClose();window.FL_FORCE=1;const g0=P.gold;flcBuyM('w');return [d,t,P.gold===g0]}""")
        chk('when the festival is over the Mythics are not sold (buttons off, no purchase)',all(r),r)
        # ---- catalog, DEV ----
        r=await E("""async()=>{catalog(title,'Crates');await __h.sleep(300);const c=ov.querySelector('.bgrid.c [data-c="f"]');const card=c&&c.closest('.mcd');return [!!c,card&&card.textContent.includes('Harvest Chest'),__rpuOvl(ov.querySelector('.bgrid.c'))]}""")
        chk('catalog › Crates has a Harvest Chest card',r[0] and r[1] and r[2]==[],r)
        r=await E("""async()=>{const h=dvxHTML();const ok=h.includes('Harvest Chest')&&h.includes('x:flc10');const c0=P.fcr|0;dvxAct('flc10');const c1=P.fcr;dvxAct('flcpity');const pi=P.fcpity;dvxAct('flcrel');const n=flcCount();dvxAct('flcclr');return [ok,c1-c0,pi,n,flcCount(),P.fcr]}""")
        chk('DEV › Cheats: Harvest Chest section (+1 / +10 / +100 chests, pity, own / clear relics, open any rarity)',r==[True,10,14,12,0,0],r)
        # ---- frame cost ----
        r=await E("""()=>{const c=ctx;c.setTransform(RS,0,0,RS,0,0);const T=(f,n)=>{let m=1e9;for(let k=0;k<4;k++){f();c.getImageData(0,0,1,1);const a=performance.now();for(let i=0;i<n;i++)f();c.getImageData(0,0,1,1);m=Math.min(m,(performance.now()-a)/n)}return m};
          const fr=()=>{c.setTransform(RS,0,0,RS,0,0);drawBG();drawCrateScene()};const out=[];P.fcr=5;P.hcr=5;
          for(const pt of [3.0,6.0,9.6,11.4]){const q=__h.open(5,'relic');__h.adv(pt);out.push(+T(fr,8).toFixed(2));crateEnd()}
          const r0=hwRoll;hwRoll=()=>({kind:'a',id:HWG_ID.a[5]});crateStart('h');hwRoll=r0;const g=[];for(const pt of [3.0,6.0,9.6,11.4]){const q=S.cr2;while(q.t<pt){q.last=performance.now()-33;crateUpdate(1/30)}g.push(+T(fr,8).toFixed(2))}crateEnd();title();
          ST.perf='low';const lo=[];{const q=__h.open(5,'relic');__h.adv(11.4);lo.push(+T(fr,8).toFixed(2));crateEnd()}ST.perf='high';title();return [out,g,lo]}""")
        chk(f'frame cost: the Mythic harvest ritual draws (scene and all) in no more than the Graveyard ritual at the same moments (or under 6 ms), Performance mode no more ({r})',
            all(a<=max(6,1.15*b2) for a,b2 in zip(r[0],r[1])) and r[2][0]<=r[0][3]*1.1+.3,r)
        # ---- 10.4b: every relic shows on the reveal, armor or weapon, and Equip puts it on the right slot ----
        r=await E("""async()=>{const out=[];for(const T of [0,1,2,3,4,5])for(const kd of ['a','w']){const id=(kd==='a'?FL.gear.a:FL.gear.w)[T];
            if(kd==='a')delete P.ownA[id];else delete P.own[id];const r0=flcRoll;flcRoll=()=>({k:'relic',kind:kd,id,tier:T});P.fcr=Math.max(1,P.fcr|0);flcStart();flcRoll=r0;const q=S.cr2;
            const im=flcPrizeImg(q),d=im.getContext('2d').getImageData(0,0,im.width,im.height).data;let px=0;for(let i=3;i<d.length;i+=4)if(d[i]>20)px++;
            __h.adv(q.E+.2);let eq='';const btn=document.getElementById('a');if(btn){btn.click();eq=kd==='a'?(P.armor===id?'ok':'armor '+P.armor):(P.weapon===id||P.wpn===id||P.eqW===id?'ok':'weapon')}else eq='no button';
            out.push([kd,id,px>4000,eq]);try{crateEnd()}catch(e){}title()}return out.filter(x=>!x[2]||x[3]!=='ok')}""")
        chk('10.4b: every harvest relic (six armors, six weapons) is drawn on the reveal, and its Equip button equips it in the right slot',r==[],r)
        chk('no page errors (stub page)',not er,er);await ctx.close()

        # ================= reduced motion =================
        ctx,pg,E,er2=await page(b,rm=True)
        r=await E("""()=>{const q=__h.open(4,'relic');const a=[q.rm,q.k];__h.adv(q.O-.2);const sh=q.shk;__h.adv(q.O+.05);const fl=q.fl,sh2=q.shk;crateEnd();title();return [a,sh,fl,sh2]}""")
        chk('reduced motion: no shake, a soft flash (at most 0.25), half the leaves and sparks',r[0]==[True,0.5] and r[1]==0 and r[2]<=.25 and r[3]==0,r)
        chk('no page errors (reduced motion)',not er2,er2);await ctx.close()

        # ================= the 98t / 98v guard enforced =================
        ctx,pg,E,er3=await page(b,init='window.TW_AC_TEST=1')
        r=await E("""async()=>{P.fcr=2;save();crateHub();await __h.sleep(400);window.g0=P.gold;FLC.force=0;FLC.forceK='coin';const b=document.getElementById('flcop').getBoundingClientRect();return [b.left+b.width/2,b.top+b.height/2,TWAC.stat().enforced]}""")
        await pg.mouse.click(r[0],r[1]);await pg.wait_for_timeout(400)
        q=await E("""async()=>{const q=S.cr2;const n=q&&q.res&&q.res.n;const g1=P.gold;try{P.gold=999999}catch(e){}const g2=P.gold;const L=(P.ldg||[]).slice(-3).map(e=>e.src);__h.adv(q.E+.1);await __h.sleep(80);return [window.g0,n,g1,g2,L]}""")
        chk('with the 98t / 98v guard enforced (window.TW_AC_TEST): a purse from a chest opened by a click pays (booked in the gold ledger as the harvest chest), a console write to the coins is refused',
            r[2] is True and q[1] and q[2]==q[0]+q[1] and q[3]==q[2] and any('harvest chest' in s for s in q[4]),[r,q])
        chk('no page errors (guard page)',not er3,er3);await ctx.close()

        # ================= UI fit at three sizes =================
        for (vw,vh) in [(1600,900),(1280,720),(1024,640)]:
            ctx,pg,E,er4=await page(b,vw,vh)
            o=[]
            o.append(await E("""async()=>{P.fcr=12;P.hcr=2;P.ownA[FL.gear.a[0]]=1;P.own[FL.gear.w[1]]=1;FLC.tab='f';crateHub();await __h.sleep(800);return __rpuOvl(document.getElementById('flcb')).concat(__rpuOvl(ov.querySelector('.flctabs')))}"""))
            await pg.screenshot(path=os.path.join(SHOTS,f'hub_{vw}.png'))
            o.append(await E("""async()=>{P.gold=4000;SHX.sel='f';shop();await __h.sleep(800);return __rpuOvl(document.getElementById('shp'))}"""))
            await pg.screenshot(path=os.path.join(SHOTS,f'shop_{vw}.png'))
            o.append(await E("""async()=>{shOddsModal('f');await __h.sleep(500);const r=__rpuOvl(document.querySelector('.flcodds'));return r}"""))
            await pg.screenshot(path=os.path.join(SHOTS,f'odds_{vw}.png'))
            o.append(await E("""async()=>{shClose();P.gold=130000;flcCollection();await __h.sleep(900);return __rpuOvl(document.getElementById('flcwin'))}"""))
            await pg.screenshot(path=os.path.join(SHOTS,f'collection_{vw}.png'))
            o.append(await E("""async()=>{shClose();const q=__h.open(4,'relic');__h.adv(q.E+.1);await __h.sleep(300);return __rpuOvl(ov.querySelector('.flcres'))}"""))
            await pg.screenshot(path=os.path.join(SHOTS,f'result_{vw}.png'))
            await E("()=>{crateEnd();title()}")
            if vw==1600:
                for T,pts in [(0,[0.25,1.0,3.0]),(3,[4.0,5.6]),(4,[5.6,8.4]),(5,[6.6,8.8,11.6,13.6])]:
                    await E("(T)=>{__h.seed(50+T);__h.open(T,'relic');__h.unseed()}",T)
                    for t in pts:
                        await E("(t)=>__h.adv(t)",t);await pg.wait_for_timeout(120);await pg.screenshot(path=os.path.join(SHOTS,f'open_t{T}_{t}.png'))
                    await E("()=>{crateEnd();title()}")
                await E("async()=>{catalog(title,'Crates');await __h.sleep(400)}");await pg.screenshot(path=os.path.join(SHOTS,'catalog_1600.png'))
            chk(f'UI fit at {vw}x{vh}: crates banner and tabs, shop, odds window, Harvest Collection, result screen: nothing overlaps, is clipped or leaves the stage',all(x==[] for x in o),o)
            chk(f'no page errors at {vw}x{vh}',not er4,er4);await ctx.close()
        # ================= 10.4c polish =================
        for (vw,vh) in [(1600,900),(1280,720),(1024,640)]:
            ctx,pg,E,er5=await page(b,vw,vh)
            r=await E("""async()=>{P.gold=500000;P.fcr=4;SHX.sel='f';shop();await __h.sleep(500);flcCollection();await __h.sleep(1100);const m=document.querySelector('.shmc.flcwin');
              const hd=document.querySelector('.flcht p').getBoundingClientRect(),bg=getComputedStyle(document.querySelector('.flcht p')).backgroundColor;
              return [m.scrollHeight-m.clientHeight,__rpuOvl(m),/^[A-Z]/.test(document.querySelector('.flcset span').textContent),bg!=='rgba(0, 0, 0, 0)',[m.scrollHeight,m.clientHeight,document.getElementById('shmod').offsetHeight]]}""")
            await pg.screenshot(path=os.path.join(SHOTS,f'c_collection_{vw}.png'))
            chk(f'10.4c {vw}x{vh}: the Harvest Collection window fits without scrolling, the subtitle sits on a dark plate and the set bonus starts with a capital',r[0]<=1 and r[1]==[] and r[2] and r[3],r)
            if vw==1600:
                r=await E("""async()=>{const g0=P.gold,b=document.querySelector('[data-fb="a"]');b.click();const a1=b.classList.contains('arm'),t1=b.textContent;b.click();const still=[P.gold===g0,b.classList.contains('arm')];
                await __h.sleep(500);b.click();await __h.sleep(1300);return [a1,/Tap again/.test(t1),still,g0-P.gold,!!P.ownA[FL.gear.a[5]]]}""")
                chk('10.4c: buying a Mythic relic asks once ("Tap again to buy"): a double click does not buy, a second tap does, exactly once',r[0] and r[1] and r[2]==[True,True] and r[3]==100000 and r[4],r)
                r=await E("""async()=>{flcCollection();await __h.sleep(900);const f=document.activeElement;const b=document.querySelector('[data-fb="w"]');b.click();await __h.sleep(400);const armed=b.classList.contains('arm');await __h.sleep(3800);return [f&&f.dataset&&f.dataset.fb,armed,b.classList.contains('arm'),/100,000/.test(b.textContent)]}""")
                chk('10.4c: focus starts on a Buy button, an armed button disarms by itself after a few seconds',r==['w',True,False,True],r)
            await ctx.close()
        ctx,pg,E,er6=await page(b)
        r=await E("""async()=>{P.fcr=2;window.FL_FORCE=-1;crateHub();await __h.sleep(500);const a=document.querySelector('.flcb .flclt'),at=a&&a.textContent;SHX.sel='w';shop();await __h.sleep(500);const sb=document.querySelector('.flcshb .flclt');const st=sb&&sb.textContent;flcCollection();await __h.sleep(700);const ct=document.querySelector('.flcht .flclt').textContent;window.FL_FORCE=1;return [at,st,ct]}""")
        chk('10.4c: once the festival is over the Harvest Chest banner, the shop banner and the Collection say FESTIVAL OVER, not LIMITED TIME',r==['FESTIVAL OVER']*3,r)
        r=await E("""async()=>{P.fcr=14;flcBatch(10);await __h.sleep(700);const g=document.querySelector('.cbg,.flcbat .cbg'),rw=document.querySelector('.flcbat .row');const a=g?g.getBoundingClientRect():null,c=rw.getBoundingClientRect();return [a&&c.top-a.bottom]}""")
        chk('10.4c: the Open 10 results leave a gap above Open another / Back',r[0] is not None and r[0]>=8,r)
        chk('no page errors (10.4c)',not er5 and not er6,[er5,er6]);await ctx.close()
        await b.close()
    print(f'\n{N[0]-len(FAIL)} / {N[0]} passed',flush=True)
    if FAIL:print('FAILED:',FAIL)
    print([] if not FAIL else FAIL)
asyncio.run(main())
