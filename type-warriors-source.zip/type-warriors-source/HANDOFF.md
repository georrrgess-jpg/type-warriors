# Type Warriors — Handoff Brief

Read this whole file before changing anything. It records how the game is built, the art and UI style the owner has approved, and the standing rules. Screenshots of the approved look are in `refs/`.

---

## 1. What the game is

Type Warriors is a browser typing game: a chunky cartoon knight (or archer, mage or rogue) fights monsters by typing words. It ships as **one self-contained HTML file** (`type-warriors.html`), with no external assets apart from Google Fonts. The owner plans to publish it on their Wix site.

Major systems:
- Campaign (regions such as Goblin Woods and Sunken Ruins, with stages, stars and region bosses), Endless, Daily Challenge (a new realm and modifier each day), Warden's Arena, Graveyard event, Halloween events.
- Armory: classes, weapons and armor with mastery, Skill Tree, Auto-Equip.
- Casino and minigames, Shop, chests (Celestial / Astral chest, Graveyard crate), Bounty board, Bestiary, Hall, Save Center, Updates/News (the bell), Calendar.
- Companion Hall (pets): roster, eggs (Runeshell = Rare, Crownheart = Legendary), hatching, Adventure Trail stamps, bond levels and cosmetics.
- Main menu: the "Console Dock" hub. A bright diorama of the current region on the right, a campaign panel on the left, a six-tab dock at the bottom (Play, Gear, Pets, Progress, Shop, More), and the bell and calendar in the bottom-right corner.

---

## 2. How the code is organised (important)

- Source is about 145 numbered modules (`00_head.html`, `10_data.js`, … `88c_dockicons.js`, `70_main.js`). `build.sh` concatenates them **in a fixed order** into `out.html`, then syntax-checks the extracted script with `node --check` (it prints `SYNTAX_OK`).
- The deliverable is `out.html`, copied to **`type-warriors.html`**. A second copy, **`type-warriors-act6-TEST.html`**, has always been delivered alongside it. It is byte-identical, built by `build_ast3.sh` into `out_ast.html`. Always build both, confirm `cmp out.html out_ast.html` passes, and deliver both.
- **Everything is one script, so later code overrides earlier code:**
  - A later `function foo(){}` replaces an earlier one everywhere.
  - Wrap an existing function with `{const f0=foo;foo=function(){const r=f0.apply(this,arguments);/*extra*/;return r}}`.
  - Some globals are `const` (for example `dcKey`, `hwOn`, `DKI`, `PTICO`) and cannot be reassigned. Mutate them (`Object.assign(DKI,{...})`) or wrap their callers.
- **Preferred way to make changes:** add a new module after the module you are changing (for example `87h_pet_fx.js` after `87g_pet_polish.js`), add it to the file lists in **both** `build.sh` and `build_ast3.sh`, and do the overrides there. When you edit an existing module, save a backup first (`file.js.v7bak`).
- **UI framework:**
  - `show(html, cls)` renders a menu into `#ov` and clears `LIVE`.
  - Animate canvases with `LIVE.push({cv, fn: t => draw(t), slow: N})`, where `slow` means "render every Nth frame".
  - `S.back` is the Back/Esc handler. `$('id')` is `getElementById`. `title()` opens the main menu.
- **CSS** is added by each module through `document.createElement('style')`. Later styles win.
- **Save data** is the global `P` (for example `P.gold`, `P.pets`, `P.eggs`, `P.petSort`). Call `save()` after changing it.
- **Pets:**
  - Data and logic: `87a_pet_data.js` (`PDEF`, `PIDS`, `petOwned`, `petHatch`, `petBuy`, `petEquip`, `petNextEgg`, `PEGG_PRICE = {r:2000, l:10000}`).
  - Art: `87b_pet_art.js` (`petDraw`, `petFit`, `eggDraw`, `eggFit`, `PSIG` signature colours).
  - Menus: `87c`, `87e`, `87g`, `87h`. Hatch cinematic: `87f` (`ptHatchScene`). State object: `PTX`.
- **Dock and hub:**
  - `88_dock.js` holds the dock, sheets and Daily card.
  - `88b_hub.js` holds the diorama `homeScene`/`drawBG`, the `DKI` icon set, glare and tilt (`.dkg`, `.dktilt`), the hero hotspot and the Daily medallion `dkDailyLive`.
  - `88c_dockicons.js` holds the current dock icons and their animations.

---

## 3. Art and UI style (the owner's approved look; match it)

Look at `refs/` first. In short: **a polished, warm, storybook-cartoon fantasy, lit at night.**

- **Illustration:** hand-built vector art drawn in canvas or inline SVG, never bitmaps.
  - Chunky shapes with **dark outlines** (`#12081f`, about 2.4–3px at a 100-unit scale).
  - Soft gradient fills, a darker "shade" half on the right, and a **white highlight stroke** on the upper left.
  - Small sparkles (4-point stars) and soft additive glows (`pGlow` / `globalCompositeOperation='lighter'`).
  - Characters are cute and round, with big friendly eyes.
- **SVG icon helpers** (in `31b_boonicons.js`; reuse them):
  - `bP(path, fill)`: outlined shape. `bF(path, fill, opacity)`: shade. `bH(path, colour, width)`: highlight.
  - `bC(x, y, r, fill)`: circle. `bEl(...)`: ellipse. `bL(...)`: outlined line. `bS(x, y, r, fill)`: sparkle.
  - Icons use a 100×100 viewBox, with the art roughly between 14 and 86.
- **Palette:**
  - Panels are deep indigo and purple: `#1c1446` to `#0c0822`, borders `#3a3070` / `#5a4ca0`, glassy, with a 1px inner top highlight.
  - Gold accent: `--gold: #ffc94a` / `#ffd45a`. Body text is warm white (`#fff8e8`, `#f4ecd8`). Muted text is lavender (`#c4badf`).
  - Rarity colours: Rare is blue `#5ab8ff`, Legendary is gold `#ffc23a`, and purple `#b47aff` marks magic.
  - Errors and badges use red `#e8364e`.
- **Type:**
  - **Pirata One** for big decorative titles ("Companion Hall", "Armory", pet names), in gold.
  - **Poppins** (`var(--ui)`) for all UI text, bold 700/800 on buttons. Cinzel is used occasionally.
- **Buttons:**
  - Primary is a gold gradient with dark-brown text and a 4px "pressed" bottom shadow.
  - Secondary is indigo with a lavender border. Soft and ghost buttons are text with a chevron.
  - Pills, tags and badges are rounded.
- **Motion:**
  - Springy and lively but tasteful: `cubic-bezier(.3,1.5,.5,1)` overshoot, short (0.2–0.7s) one-shot animations, staggered entrances.
  - Hover lifts things by 2–4px; presses squish them to about 0.9.
  - Idle life comes from bobbing, breathing, blinking and drifting motes.
  - Every animation must finish cleanly. Don't let a hover animation snap back halfway; play it once with a class and remove the class afterwards.
  - Respect `prefers-reduced-motion`.
- **Layout:** 1600×900 design space, scaled to fit. The dock is centred at the bottom. Panels have 18–22px radii. Don't clutter: give one clear next action per screen.

---

## 4. Performance rules (learned the hard way)

Rendering is fill-bound on weaker machines. **Avoid:**
- `backdrop-filter`
- `mix-blend-mode` soft-light or screen
- animated `box-shadow` or `filter`
- infinite `background-position` animations
- large full-screen additive glows every frame

**Prefer:**
- `transform` and `opacity` animations
- cached offscreen canvases for static layers
- `slow` on `LIVE` canvases
- one-shot timed shines instead of constant ones

Measure the frame rate before and after visual changes; headless Chromium gives roughly 18–27 fps as a baseline. For a weaker machine, add CDP `Emulation.setCPUThrottlingRate` (2 or 4) and test at device scale factor 1.5.

---

## 5. Testing

Python Playwright scripts (`t_*.py`) load `out.html` headless, drive the game with `page.evaluate`, print results and write screenshots to `shots/`. An empty `[]` at the end means no page errors. `ERR_TUNNEL_CONNECTION_FAILED` is only the offline font load and is harmless.

Useful patterns:
- Set up state with `await pg.evaluate("()=>{RS_ASK=false;P.gold=5000;P.petSt=2;petNorm();petHall('Pets')}")`.
- Change the date with `pg.clock.install(...)`, because `dcKey` is const.
- Freeze CSS animations mid-way: `el.getAnimations({subtree:true}).forEach(a=>{a.pause();a.currentTime=200})`.

Regression set to run after changes: `t_perf_casino t_wildcard t_wc_pp t_wc_scan t_access t_code81 t_petclick t_loadout_polish t_loadouts t_flow t_pe t_pdet t_entry t_misc t_trail t_modes t_start6 t_stuck2 t_dkacc t_audit t_sort t_fx t_dock t_dkanim`. Some depend on game state and may need small updates when a layout changes. Wildcard room codes have their own test, `t_wc_code.py`, which needs a local MQTT broker (see the Wildcard notes below). Keep element IDs stable where you can.

Always **look at screenshots** of what you changed (at 1600×900, and also at 1280×720 or smaller) before delivering.

---

## 6. Standing rules from the owner

1. **Updates tab (bell):** only add or push an in-game update notification when the owner explicitly asks. Even then, **ask for their okay first**.
2. **Do not alter the Celestial chest or Graveyard chest opening animations** unless asked.
3. Deliver **both** `type-warriors.html` and `type-warriors-act6-TEST.html` (identical), plus a few screenshots, with a short, honest summary of what changed and anything not done.
4. The owner gives you creative authority to polish and improve. Keep the existing art style, keep every menu reachable quickly, and keep things functional and intuitive.

---

## 7. Recent work (latest first)

- **Performance mode leaves the Casino alone (`88l_perf_casino.js`, small edit in `88k`):**
  - `PFSET()` is the saved choice (`ST.perf`); `PFM()` is the mode in effect and returns `'high'` whenever `pfCas()` is true, meaning `#ov` has the `casbg` class (the casino lobby, every casino game and all Wildcard screens).
  - So inside the Casino, Balanced and Performance change nothing: full canvas resolution, full-rate `LIVE` canvases, canvas `shadowBlur`, looping CSS animations, `backdrop-filter`, and Wildcard's full-length deal and effects (`wcRM()` only follows `prefers-reduced-motion` there).
  - `pfCasSync()` re-runs `applyLayout()` (which calls `pfApply`) the moment you enter or leave; it is hooked into `show`, `hide` and `loop`.
  - Settings shows the saved choice and notes that the Casino keeps its full animations; the "running slowly" offer also reads `PFSET()`.
  - Test: `t_perf_casino.py`.
- **Wildcard polish round (modules `89n`–`89p`, plus rewrites of `89b` and parts of `89d`/`89m`):**
  - **Cards (`89b_wc_cards.js`, rewritten):** brighter three-stop element palettes (`WCK`), white outer border, sunburst rays and element motif, a large faint element glyph, gloss sweep, gold diamond with cream centre, value or action icon, a ribbon pill for actions, and corner indexes with element coins. The four-element wild and +4 Hex keep their concepts.
  - **Card backs:** nine backs with rarities (`WCRAR`: Common, Rare, Epic, Legendary, Secret; colours `WCRARC`). `WCBK[k]` has `n` (name), `r` (rarity), `how` (unlock hint), `fl` (flavour text) and `need(W)` returning `[have, goal]` for progress bars. Unlocks live in `wcRecord`: Neon Arcade (10 games), Hallow's Eve, Emerald Jackpot (10 wins), Royal Gold, Astral, Dragonfire (5-win streak), Pastel Wyrm (win a game the rare guest sat at, `W.pbeat`), Elder Rune (secret, code WILDRUNE82). `W.seen` drives the NEW badges and the red dot on the home screen's Card backs button.
  - **Your Record and the Card Back Vault (`89o_wc_record.js`):** `wcStats()` is a full record screen (profile and rank via `WCRK`/`wcRank2`, win-rate ring, rank progress, highlight tiles, gold-per-game sparkline, recent games labelled 1st–4th via `WCPL`, wins by table). "Biggest pot" was removed at the owner's request. `wcVault(sel)` is a separate menu (home header › Card backs, and from the results unlock button): a tilting preview, rarity, flavour text, progress and Equip.
  - **Rare guest (`89n_wc_rare.js`):** a dragon in a pink (Baron Bubblegum) or baby-blue (Duke Azurine) suit, species `pdragon`, with an aura, wings, a tail, sparkles, gold horns and heart shades. `wcCrewGen(n, rnd, {rare: p})` swaps one regular for the guest with probability `p`: 10% per solo game or room, 25% on the home screen. Seats show "★ RARE GUEST".
  - **Effects (`89p_wc_fx2.js`):** `wcDeal2` (deck drop, riffle and bridge, round-robin deal straight into your hand slots face down, a flip wave, the first card to the pile), `wcWild2` (element orbs orbit and the chosen one slams into the pile), `wcRev2` (Turnabout arrow sweep and seat hops), `wcSkip2` (Stun bolt and a frozen seat). They wrap `wcAnim` for `deal`, `rev` and `skip`. All use WAAPI transforms and opacity only.
  - **Home:** header no longer overlaps the sign at 1280 wide; new add-player seat button (`.wcadd2`, a soft ping and a rotating dashed ring); a streak chip after 2+ wins in a row; card fan hover plays the `shimmer` chime.
  - **Tests:** `t_wildcard.py` now also checks the record screen, the vault, equipping a back, unlocks and the rare-guest rate (about 10%).
- **Update 8.2: Wildcard, the Dragon Lounge card game (modules `89a`–`89m`, after `88k_access_perf.js`):**
  - **Where it lives:** Casino → Cards tab (first tile, red NEW corner ribbon; the ribbon moved off Nebula Scratch) and the Special tab feature card (the Wildcard / Nebula / Tower switch defaults to Wildcard). `gameOpen('wc')` opens `wcHome()`.
  - **Casino grid:** with 13+ games the grid switches to 7 columns (`:has(>.gdt:nth-child(13))`), and from 15 games it scrolls, so no tile (Quiz Showdown last time) is ever cut off again.
  - **Modules:**
    - `89a_wc_core.js`: the pure rules engine. `wcNew` builds the game `G`; actions `wcPlay`, `wcDrawAct`, `wcPass`, `wcCall` (WILD!), `wcCatch`, all via `wcDo(G, seat, action)`. Every change is logged to `G.ev`; the table replays events as animations. Bots: `wcBot` (all lounge regulars play at the `m` level of `WCB`). Economy: `WCT` (four tables keyed `c50`, `c250`, `c1k`, `c2k5`), `WCTK`, `WCFEE`, `WCE`, `wcPayout`.
    - `89b_wc_cards.js`: SVG card art (`wcSVG`, cached): element gradients with element motifs (flames, waves, leaves, bolts), a gold inner frame with corner gems, a gold-rimmed shield, action ribbons (STUN, TURN, CURSE, WILD, HEX), four-element wilds. Card backs `WCBK` and `wcBack`.
    - `89c_wc_table.js`: the table. `WX` is the state. `wcPump` plays events through `wcAnim`; `wcStep` schedules the regulars, catch windows, the same-screen curtain and turn timers. Effects: `wcFly`, `wcBurst` (element-glyph particles), `wcWave` (wild colour sweep), `wcShake`, `wcFlash`, riffle shuffle. The status pill above the hand says whose turn it is and what to play. `wcMenu` is the in-game menu (Esc opens it). It also holds back the "Running slowly?" offer while a card game is on screen.
    - `89d_wc_menus.js`: home (`wcHome`: neon marquee, live regulars, chip table picker, room-code boxes), rules, save data in `P.wc` via `wcSt()` (the stats screen now lives in `89o`), solo start, `wcRecord`, results podium, the private room (`WCL`, `wcLobbyRender`, seat menu `wcSeatMenu`, chip buy-ins, segmented timer and hand size, house-rule tiles) and the join screens (`wcJoinView(state)`).
    - `89e_wc_net.js`: playing with friends on other devices (see below). Host is authoritative: guests get `wcView` (other hands masked) and send actions by card id.
    - `89f_wc_casino.js`: casino listing, `wcFeat`, the Special switch.
    - `89g_wc_qr.js`: QR encoder (`wcQR`). `89g9_wc82img.js`: the 8.2 collage. `89h_update82.js`: the 8.2 Updates entry (no News card, by the owner's choice) and the code **WILDRUNE82** (2,500 coins plus the Elder Rune card back, once per save), hidden at the end of the notes.
    - `89i_wc_crew.js`: the lounge regulars — monsters in suits drawn on canvas (dragon, goblin, orc, skeleton, lizard, wolf, frog, octopus) with random suits, ties, hats, eyewear and held items. `wcCrewGen(n)` makes a lineup with random names; `wcCrewDraw(g, A, t)` animates breathing, blinking and a flipping chip. `wcPortrait`/`wcFigure` are wrapped for `av.t==='crew'`.
    - `89j_wc_audio.js`: "Neon Wildcard", a synthesised arcade lounge theme (16 bars, A minor, the casino's 116 bpm) with menu, game and tense variations, routed through the casino music busses (so the Music setting applies), plus `wcFx(name)` sound effects through the sound-effects volume.
    - `89k_wc_relay.js`: room codes over public MQTT brokers on secure WebSockets (`WCRELAYS`), messages AES-GCM encrypted with a key from the room code. `89l_wc_scan.js`: camera scanning (`wcScan`) with a built-in QR decoder (`wcQRDecode`, Reed-Solomon corrected) for offline joining.
    - `89m_wc_style.js`: every Wildcard style.
  - **Playing with friends:**
    - *Room code (needs internet):* the host's room shows a 4-letter code. The guest types it on the home screen; the devices swap WebRTC details through the relay (several brokers at once, whichever answer), then play directly. STUN servers help devices on different networks; some strict networks still block direct play, and the join screen says so.
    - *Scan to join (no internet, same Wi-Fi):* the host taps Invite by QR, the guest scans it (Join a room › No internet? Scan to join), then the host scans the guest's reply QR. Paste and copy fallbacks exist for devices without a camera.
  - **Economy (3,000-game simulations, `sim2.js` style):** buy-ins 50 / 250 / 1,000 / 2,500 with a 12% house cut; the winner takes the pot less the cut, 2nd gets 40% of their buy-in back. Gold returned per gold staked: careless player 0.52, typical 0.98, sharp 1.12 (and a sharp player still wins only about 29% of games). 15 paid games a day (then practice), first win of the day +150, private rooms cut 10%, same-screen games are free.
  - **Tests:** `t_wildcard.py` (listing, payouts, the code, a staked solo game played by `t_wc_agent.js`, the in-game menu, forfeit, daily cap, stats, Esc), `t_wc_pp.py` (same screen), `t_wc_scan.py` (two browsers joined by scanning each other's QR through the real decoder), `t_wc_code.py` (two browsers joined by room code through a real MQTT broker; start one locally first, for example `pip install amqtt` and run its broker with a `ws` listener on `127.0.0.1:18083`).
- **Text visibility and Performance mode (`88k_access_perf.js`, Settings → Display):**
  - **Text visibility** (`ST.tvis`, Standard or Clear): `tvBuild()` reads every style rule once and writes stronger copies of the faint ones into `#tvcss`. Faded colours are brightened while vivid gold and rarity colours are kept, small text gets bolder, and light menu text gets a dark edge.
    - The copies are wrapped in `:where(body.tv)` so they never beat a more specific state rule such as a selected tab.
    - Note: weight and size are parsed from `font:` shorthands, because rules using `var(--ui)` report blank longhands.
  - **Performance mode** (`ST.perf`: `high`, `bal` or `low`). Profiling showed the canvas is fill-bound: the zone background is about 45% of a frame and the vignette about 15%.
    - Balanced: resolution at most 1×, the background is redrawn every 2nd frame (`PFBG` copies the freshly drawn background and replays it), and the vignette is pre-rendered.
    - Performance: resolution 0.75×, background every 4th frame, no decorative vignette, `runLive` at half rate, looping CSS animations paused (`pfAnims`), and a `shadowBlur` hook that exists only while Performance is on.
    - The background cache is bypassed while the screen shakes or a cutscene zooms.
    - In Quality mode the game offers Performance once after two 5-second windows under 20 fps outside gameplay (`ST.perfAsked`).
  - Tests: `t_access.py`.
- **Code NEWUPDATECOINS81 (`88j_code81.js`):**
  - A built-in code (in `CC_BUILTIN`, `max:0`) worth 1,500 coins plus a Runeshell egg.
  - Each save can redeem it once (`P.ccUsed`), and it's case-insensitive.
  - `ccGrant` and `ccPlay` are wrapped to add the egg and show it on the reward card.
  - The code is hidden at the end of the 8.1 notes in the Updates tab only (`.blsec`). The News card is unchanged.
  - Test: `t_code81.py`.
- **Update 8.1 notification (`88i_update81.js`), pushed with the owner's okay:**
  - Adds `u-8.1` to `UPDATES` and `n-8.1` (out) to `NEWS`, both titled "Companions & Loadouts".
  - Both carry a collage (`UPD81_IMG`, a 900px WebP data URL of about 102 KB, made from in-game screenshots).
  - `bellInner` is wrapped so Updates entries with `img` show it, as News does. Any `.blimg` opens full size on click (`updZoom`, Esc closes).
- **XP pacing (from another session, ported in):**
  - New `88h_xp_pacing.js`, plus small edits in `60_ui.js`, `70a_modes.js`, `73c_dc_game.js`, `84c_gy_mode.js`, `84i_beginner.js` and `85_astral.js` (backups `*.v11bak`).
  - The build matched the owner's `type-warriors_58.html` byte for byte before 8.1 was added.
- **Roster card flicker fix (`87j_pet_cardfix.js`, after `87i`):**
  - The bug: selecting a companion added an idle `LIVE` loop to its card but never removed the old one, re-clicking stacked more, and the hover greeting loop kept running after a click. Several loops drew different poses into one canvas, so the card glitched.
  - Also, the original `live()` takes the card's first canvas, which on a Mythic card is the backdrop.
  - The fix: `ptCardTidy()` runs after every click in the hall. It keeps exactly one idle loop on the selected card's `canvas[data-pc]`, returns other cards to a still frame, and keeps backdrop canvases on their own painter. `ptCardWake` stops as soon as its card is selected.
  - Test: `t_petclick.py`.
- **Mythic backdrop (`88g_mythic_bg.js`) and a tile fix:**
  - Every owned Mythic pet shown in a frame gets an animated cosmic backdrop on a canvas behind the art. Frames covered: Companion Hall roster cards and portrait, Loadout Locker cards, slots, picker and compare, the Armory pet slot, and egg pool lists.
  - The backdrop: a turning spiral nebula with stars, twinkles, a breathing glow, an upright halo, a gold magic circle under the feet, rising motes and a shooting star.
  - Palettes are per pet (`MYPAL`: yeti frost, sol sunfire, `_` default for any future Mythic). Sprites are cached in `MYIMG`.
  - A MutationObserver finds hosts (`MYHOST`) and adds the canvas to `LIVE` with `slow:3` (`slow:4` for small frames). Reduced motion shows a still frame.
  - Fix in `88f`: `.lotile` clips again, and canvases are absolutely positioned to the tile. Snap sparkles now live on the slot row, not inside the tile.
- **Loadout Locker polish (`88f_loadout_polish.js`, after `88e`):**
  - The right panel is now a slot editor. Click a slot, drop gear onto it, or press Enter on it to open the gear picker in the left panel. The picker has class or rarity filter chips, a "Sort:" dropdown in the Pets-tab style (saved in `P.lo.so`), and a "Best" badge.
  - Hovering or focusing an item previews it on the hero. A compare box shows overall strength (the Auto-Equip test run) and per-stat changes with green ▲ / red ▼.
  - Put an item in with the button, a double-click, Enter, or drag and drop. Clear a slot with × or Delete. Auto-fill best uses `autoPick` for the preset's class.
  - Slot snap animation with sparkles and a beep. Enter on the selected preset equips it. Esc closes the innermost layer (sort menu, then picker, then the page).
  - The Armory bar has a "Loadouts" button (`#arlo`).
  - Gotchas found:
    - The game's global `.em` class (Endless menu) leaked padding into empty slots, so they now use `lomt`.
    - HTML5 drag needs a `div` (Chromium won't drag a `<button>`) and `-webkit-user-drag:element` once `all:unset` is applied.
  - Test: `t_loadout_polish.py`.
- **Loadout Locker (`88e_loadouts.js`, Gear → Loadouts):**
  - Three named presets (default names Campaign, Endless, Gold Hunt) in `P.lo = {s:[{n,w,a,p,c}×3], sel, ask}`. Each stores weapon, armor, companion and the weapon's class.
  - The Gear sub-tab strip is now Armory · Loadouts · Skill Tree (`DKSUB.gr`, `DKG.lo`, and `DKGO.gr` remembers it). The page is detected by `class="lol"`.
  - Equip applies only owned, usable pieces: it checks `P.own`/`P.ownA`, `pathOpen` for the class and `petOwned`. Anything else is skipped, marked on the tile, and reported in a toast. Skill Tree ranks are never touched.
  - Save current loadout: overwriting a filled preset needs a second click. Rename is inline (pencil, Enter/Esc, 16 characters max). "Ask before replacing gear" (`P.lo.ask`) shows a confirm dialog listing each change.
  - Illustrated locker-room stage (cached background, torches, motes). It previews the hovered or selected preset; a swap sparkles and an equip plays a gold celebration. Keys 1–3 pick a preset.
  - Test: `t_loadouts.py`.
- **Source synced with the shipped HTML:** the changes that existed only in the delivered `type-warriors.html` now live in the source, and the build is byte-identical to it.
  - New `87i_pet_mythic.js` (after `87h`): Mythic companions Glacierhorn and Solmane, the Starforge egg (50,000 gold, `P.eggs.m`), the Starforge hatch cinematic, Mythic battle effects and the companion power hotkey.
  - New `88d_spnote.js` (after `88c`): `spNote()`, so the Skill Tree badge only appears when a point can actually be spent.
  - Small in-place edits (backups `*.v7bak`): `74_shell.js` and `88_dock.js` use `spNote()`; `86b_codes.js` adds the `BRAYDENSGIFT` code; `87a_pet_data.js` counts Mythic eggs; `87d_pet_game.js` draws the companion in front of the knight (`petDrawGame`).
- Tests need Python Playwright pinned to the installed browser (here `pip install playwright==1.56.0`).
- **Dock icons v2 (`88c_dockicons.js`):**
  - All six icons redrawn: crossed swords, knight's helm with plume, paw with a heart pad, rounded bar chart, coin pouch, three dots.
  - Each icon has a hover, focus and press animation that plays to the end.
  - Badges moved off the icon art, and the label no longer shifts on hover.
- **Pet and egg effects (`87h_pet_fx.js`):**
  - Descriptions for both eggs (`PEGGD`), on the stage and in an "About" card. Redrawn `PTICO` icons.
  - Pet stage: pop-in on select, signature-colour motes, petting with hearts and combos (every fifth pet plays the power animation), a "Tap to pet" hint, and a gold celebration on equip.
  - Roster: cards wake and greet on hover, and owned legendary cards get a gold shine.
  - Eggs: ready eggs rock, sparkle and pulse; tapping the egg gives a reaction; the hatch button gets a shine.
  - The hatch reveal shows collection progress and the next free egg.
- **Pets sort and Eggs declutter (`87g_pet_polish.js`):**
  - "Sort:" dropdown with Collection, Recommended, Rarity, Bond high/low, Name A–Z and Recently acquired, saved in `P.petSort`.
  - Rarity-bordered cards.
  - Eggs tab is now three columns: Your Eggs, the egg stage, and Hatchery (with Buy and "Earn one free").
- **Earlier:** Console Dock main-menu overhaul; bright region diorama; Manage pet / Manage gear buttons; Daily Challenge medallion that changes every day; smooth menu transitions; pet starter-screen fixes.
