# python3 t_potbal103.py [--quick] [--only camp,value,endless] [--seeds N] [--workers W] [--reuse] [--resume] [--html game.html] [--out results.json]
# Balance test for the 10.3 potions (UPDATE_10_3_PLAN.md section 4), with the bots the balance work has always used: the t_ramparts bot
# with t_bal102's fair pad choice and the map's tier cap, every run seeded (Math.random replaced by a seeded generator, as t_bal102).
# The bot uses its potions "well" (potBot below): the drinks that raise damage or slow the road and the throws when the wave is
# dangerous (a boss on the road, a crowd late in the map, or the castle already hurt), throws at the biggest crowd, the Elixir when the
# castle is down 5 health, the Gilded Tonic early on a busy wave, the Seer's Tincture when monsters hide in fog or dive (or the wave is
# dangerous). In the endless Wonderland it holds its potions until the castle is first hurt (when a run starts to go wrong).
# Three experiments:
#  1. camp     the nine campaign maps with the mixed build (Ballista, Blazer, Frost, Bell, Prism; upgrades, abilities), with no potions and
#              with a full satchel (Fury, Frostbite, Hourglass): win rate, health, stars.
#  2. value    the harder maps under stress (monster health x1.25 from wave 4, as t_bal102), the same build with: no potions; one
#              extra mid-price tower (+400 starting supply, no potions); one potion of each kind (a single slot); three of each kind (a
#              full satchel of it). 2a: the castle cannot fall (BALINV) and the health it would have lost is counted (a smooth measure
#              of what a potion saves; win / lose alone is chaotic: one perturbation flips a close run either way); 2b: normal games,
#              win rate (none, extra tower, one potion of each kind).
#  3. endless  the Wonderland reach (cap 125; --quick 60) of the reference build Prism, Dragon, Frost, Tide, Still without potions and
#              with a full satchel (Fury, Quicksilver, Hourglass), with a full board and with at most eight towers (a full board meets
#              97c's wall near wave 100 whatever it carries).
# Pass criteria (from the plan, stated before the numbers):
#  (a) campaign: potions gain a little: mean health at most +4 over the nine maps, no map gains more than one star (mean of seeds),
#      and no lost map turns into a three-star win.
#  (b) on the harder maps no single potion saves more castle health than one extra mid-price tower (+400 supply) (the castle cannot
#      fall in these runs, so the health it would have lost is a smooth measure); (b2) in normal games no single potion wins more often
#      than the extra tower, within 15 points (few seeds, so noisy).
#  (c) each potion's value (health saved by a full satchel of it) is positive (no useless potion) and at most 2.5 x the median of the
#      eight (no must-pick).
#  (d) endless Wonderland reach with potions at most +5 waves over the same build without them (mean of seeds).
#  (e) no page errors in any run.
# Results in ../tools/td/potbal103_results.json (--reuse evaluates that file again; --resume continues a stopped batch).
import asyncio,json,math,os,sys,time,statistics
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
ARGS=sys.argv[1:]
def opt(name,default=None):
    if name in ARGS:
        i=ARGS.index(name);return ARGS[i+1] if i+1<len(ARGS) and not ARGS[i+1].startswith('--') else True
    return default
QUICK='--quick' in ARGS
HTML=os.path.abspath(opt('--html') or os.path.join(HERE,'out.html'))
OUT=opt('--out') or os.path.join(HERE,'../tools/td/potbal103_results.json');PART=OUT+'.part'
W=int(opt('--workers',4));SEEDS=int(opt('--seeds',1 if QUICK else 2));VSEEDS=int(opt('--vseeds',2 if QUICK else 3));WSEEDS=int(opt('--wseeds',2 if QUICK else 4))
ONLY=(opt('--only') or 'camp,value,endless').split(',')
CAMP=['moss','ember','wreck','storm'] if QUICK else ['moss','frost','ember','coral','wreck','abyss','meadow','foundry','storm']
HARD=['ember','storm'] if QUICK else ['ember','wreck','abyss','foundry','storm']
POTS=['fury','quick','frost','fire','mend','hour','gild','seer']
BUILD=['ballista','brazier','frost','bell','prism']
GOOD=['fury','frost','hour'];EGOOD=['fury','quick','hour']
STRESS_K=1.25;STRESS_W=4;EXTRA=400
ECAP=60 if QUICK else 125
SRC=open(os.path.join(HERE,'t_ramparts.py')).read()
BOT=SRC.split('BOT=r"""',1)[1].split('"""',1)[0]
PICK="""const sam=R.map.paths.map(P=>{const o=[];for(let j=1;j<P.length;j++){const n=Math.ceil(Math.hypot(P[j][0]-P[j-1][0],P[j][1]-P[j-1][1])/25);for(let k=0;k<n;k++)o.push([P[j-1][0]+(P[j][0]-P[j-1][0])*k/n,P[j-1][1]+(P[j][1]-P[j-1][1])*k/n])}return o});
 const cvp=(p,i)=>sam[i].filter(q=>(q[0]-p.x)**2+((q[1]-p.y)/.75)**2<210*210).length;
 const pick=()=>{const fr=R.pads.filter(p=>!p.tw);if(!fr.length)return null;const load=sam.map((_,i)=>R.pads.filter(p=>p.tw).reduce((a,p)=>a+cvp(p,i),0));
   let best=null,bs=-1;for(const p of fr){let sc=0;sam.forEach((_,i)=>{sc+=cvp(p,i)/(1+load[i]/40)});if(sc>bs){bs=sc;best=p}}return best};"""
BOT=BOT.replace("const pads=[...R.pads].sort((a,b)=>cov(b)-cov(a));","const pads=[...R.pads].sort((a,b)=>cov(b)-cov(a));"+PICK).replace("const free=pads.find(p=>!p.tw);","const free=pick();")
BOT=BOT.replace("const top=RP_MAXT(R.map)","const top=R.map.maxT||RP_MAXT(R.map)").replace("p.tw.type.slice(0,2)","p.tw.type.slice(0,3)").replace("steps<30*60*90","steps<(opt.maxSteps||30*60*90)")
# potions: the satchel is written before the run, extra supply after the start, the potion policy every step, potions used in the result
BOT=BOT.replace("const R=RPX;R.spd=3;","const R=RPX;R.spd=3;if(opt.extra)R.supply+=opt.extra;")
BOT=BOT.replace("rpUpdate(1/30)}","if(opt.sat)potBot(R,opt);rpUpdate(1/30)}")
BOT=BOT.replace("abil:R.abil}};","abil:R.abil,pot:R.pt?R.pt.used.slice():[],potDmg:R.pt?Math.round(R.pt.dmg):0,potGold:R.pt?R.pt.gold:0,potHeal:R.pt?R.pt.heal:0,lost:R.balLost||0}};")
for k in ["const free=pick();","R.map.maxT||RP_MAXT","opt.maxSteps","if(opt.extra)","potBot(R,opt)","pot:R.pt?"]:assert k in BOT,k
POTBOT=r"""window.potBot=function(R,opt){if(!R.pt||R.wst!=='run'||R.over)return;const T=R.pt;
 /* a leak this moment (the castle lost health since the last look) */if(R._pbHp!=null&&R.hp<R._pbHp)R._pbLeak=R.time;R._pbHp=R.hp;
 if(T.cd>0||rpptLock(R)>0)return;
 /* a placebo (opt.noop uses): the same trigger as a drink, the same shared cooldown, a few random numbers drawn (the run diverges as
    it would after a real potion) and no effect: the fair baseline for runs whose outcome is chaotic */
 const noopGo=()=>{for(let j=0;j<9;j++)Math.random();T.cd=RPPTX.cd;R._pbN=(R._pbN||0)+1};
 const live=R.foes.filter(e=>!e.dead&&e.s>0),n=live.length,boss=live.some(e=>e.boss),end=!!R.map.endless,frac=end?1:R.wave/R.map.waves,pr=e=>e.s/rpLen(R,e);
 const late=live.filter(e=>pr(e)>.45).length,near=live.filter(e=>pr(e)>.7).length,leak=R._pbLeak!=null&&R.time-R._pbLeak<8;
 /* danger: monsters about to get through, a fresh leak with a crowd behind it, a boss on the second half of the road, or a big crowd late
    in the map; in the endless Wonderland the bot holds its potions until a run starts to go wrong (a leak) */
 const danger=end?(leak&&n>=5)||(boss&&R.wave>=40&&late>0):(near>=3)||(leak&&n>=4)||(boss&&late>0)||(n>=10&&frac>=.55);
 if(opt.noop&&(R._pbN||0)<opt.noop){if(danger)noopGo();return}
 for(let i=0;i<3;i++){const s=T.sl[i];if(!s||s.empty||s.used||rpptWhy(R,i))continue;const k=s.k;let go=false;
  if(k==='gild')go=end?R.wave>=4&&n>=8:R.wave>=2&&frac<=.6&&n>=6;
  else if(k==='mend')go=R.hp<=RPT.HP-5;
  else if(k==='seer')go=(live.some(e=>e.hide||e.fogd)&&n>=4)||danger;
  else if(k==='frost'||k==='fire'){if(!danger)continue;const r=RPPD[k].r;
   /* the biggest crowd on the second half of the road (where the danger is), else anywhere */
   const L=live.filter(e=>!e.hide&&pr(e)>.4),pool=L.length>=3?L:live.filter(e=>!e.hide);let best=null,bm=0;
   for(const e of pool){const p=rpPos(R,e);let m=0;for(const f of pool){const q=rpPos(R,f);if(rpD2(p.x,p.y,q.x,q.y)<r*r*.8)m+=(k==='fire'&&f.air?.6:1)*(f.boss?2:1)}if(m>bm){bm=m;best={x:p.x,y:p.y}}}
   if(best&&(bm>=3||(boss&&bm>=1))){rpptUse(i,best);return}continue}
  else go=danger;
  if(go){rpptUse(i);return}}};
 window.potSet=function(sat){const p=rpptSave();p.gift=1;p.seen=1;p.tip={belt:1,throw:1};p.st={};p.sat=['','',''];for(let i=0;i<3;i++){const k=sat[i]||'';p.sat[i]=k;if(k)p.st[k]=(p.st[k]||0)+1}save();return 1};"""
SETUP="()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const r=RPP();r.dragon=1;r.new99j=1;r.stars={moss:3,frost:3,ember:3,coral:3,wreck:3,abyss:3,meadow:3,foundry:3};for(const k in r.tut)r.tut[k]=1;for(const k of['build','wave','coins','upgrade','abil','rune','potbelt','potthrow','twist','twist_frost','twist_ember','twist_wonder'])r.tut[k]=1;save()}"
HARN=r"""(seed)=>{let a=seed>>>0;Math.random=function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296};
 window.BALHPK=1;window.BALHPW=0;window.BALINV=0;
 /* no HUD in these runs (the DOM updates cost more than the battle) */{const s0=rpStart;rpStart=function(){const r=s0.apply(this,arguments);try{rpHudOff()}catch(e){}return r}}
 {const d0=rpDefeat;rpDefeat=function(){const R=RPX;if(window.BALINV&&R){R.hp=1;return}return d0.apply(this,arguments)}}
 {const s0=rpStep;rpStep=function(R,dt){if(!window.BALINV||!R)return s0.apply(this,arguments);const L=R.foes.filter(e=>!e.dead);const r=s0.apply(this,arguments);for(const e of L)if(e.leak)R.balLost=(R.balLost||0)+e.dmg;if(R.hp<1&&R.wst!=='done')R.hp=1;return r}}
 {const s0=rpSpawn;rpSpawn=function(){const e=s0.apply(this,arguments);try{if(e&&RPX){const k=RPX.wave>=(window.BALHPW||0)?(window.BALHPK||1):1;if(k!==1){e.hp=Math.round(e.hp*k);e.mx=e.hp}}}catch(x){}return e}}
 return 1}"""
def tasks_camp():
    T=[]
    for m in CAMP:
        for s in range(SEEDS):
            for v,sat in [('none',[]),('good',GOOD)]:T.append({'kind':'camp','map':m,'v':v,'seed':501+s,'hpk':1,'sat':sat,'opt':{'up':1,'order':BUILD,'sat':bool(sat)}})
    return T
def tasks_value():
    # inv: the castle cannot fall and the health it would have lost is counted (a smooth measure of what a potion saves);
    # win: the normal game, win rate
    T=[]
    for m in HARD:
        for s in range(VSEEDS):
            base={'kind':'value','map':m,'seed':601+s,'hpk':STRESS_K,'hpw':STRESS_W,'inv':1}
            T.append(dict(base,v='none',sat=[],opt={'up':1,'order':BUILD}))
            T.append(dict(base,v='extra',sat=[],opt={'up':1,'order':BUILD,'extra':EXTRA}))
            T.append(dict(base,v='one:noop',sat=[],opt={'up':1,'order':BUILD,'sat':True,'noop':1}))
            T.append(dict(base,v='three:noop',sat=[],opt={'up':1,'order':BUILD,'sat':True,'noop':3}))
            for k in POTS:
                T.append(dict(base,v='one:'+k,sat=[k],opt={'up':1,'order':BUILD,'sat':True}))
                T.append(dict(base,v='three:'+k,sat=[k,k,k],opt={'up':1,'order':BUILD,'sat':True}))
        for s in range(WSEEDS):
            base={'kind':'win','map':m,'seed':801+s,'hpk':STRESS_K,'hpw':STRESS_W}
            T.append(dict(base,v='none',sat=[],opt={'up':1,'order':BUILD}))
            T.append(dict(base,v='extra',sat=[],opt={'up':1,'order':BUILD,'extra':EXTRA}))
            T.append(dict(base,v='one:noop',sat=[],opt={'up':1,'order':BUILD,'sat':True,'noop':1}))
            for k in POTS:T.append(dict(base,v='one:'+k,sat=[k],opt={'up':1,'order':BUILD,'sat':True}))
    return T
def tasks_endless():
    T=[]
    for s in range(SEEDS):
        for v,sat in [('none',[]),('good',EGOOD)]:T.append({'kind':'endless','map':'wonder','v':v,'seed':701+s,'hpk':1,'sat':sat,'opt':{'up':1,'order':['prism','dragon','frost','tide','still'],'maxW':ECAP,'maxSteps':30*60*400,'sat':bool(sat)}})
        # a full board meets 97c's wall near wave 100 whatever it carries, so the builds are also played with at most eight towers
        for v,sat in [('none8',[]),('good8',EGOOD)]:T.append({'kind':'endless','map':'wonder','v':v,'seed':701+s,'hpk':1,'sat':sat,'opt':{'up':1,'order':['prism','dragon','frost','tide','still'],'maxW':ECAP,'maxSteps':30*60*400,'maxT':8,'sat':bool(sat)}})
    return T
async def run(br,t,res,errs):
    pg=await br.new_page(viewport={'width':800,'height':450});er=[];pg.on('pageerror',lambda e:er.append(str(e)[:200]))
    await pg.goto('file://'+HTML,timeout=240000);await pg.wait_for_timeout(1000)
    await pg.evaluate(SETUP);await pg.evaluate("()=>{"+BOT+POTBOT+"}");await pg.evaluate(HARN,t['seed'])
    t0=time.time()
    r=await pg.evaluate("(t)=>{potSet(t.sat||[]);window.BALHPK=t.hpk||1;window.BALHPW=t.hpw||0;window.BALINV=t.inv?1:0;const r=rpBot(t.map,t.opt);try{rpLeave()}catch(e){}return r}",t)
    r.update({k:v for k,v in t.items() if k!='opt'});r['secs']=round(time.time()-t0);r['errors']=er[:3];res.append(r)
    if er:errs.append((t,er[:2]))
    await pg.close();return r
def fmt(r):
    return f"{r['kind']:<8}{r['map']:<8}{r['v']:<14} seed {r['seed']} won {str(r['won']):<5} hp {r['hp']:>2} stars {r['stars']} wave {r['wave']:>3} pots {','.join(r.get('pot',[])) or '-'} ({r['secs']}s)"
async def play(tasks,prev=None):
    res=list(prev or []);errs=[]
    async with async_playwright() as p:
        br=await p.chromium.launch();sem=asyncio.Semaphore(W);done=[0]
        async def one(t):
            async with sem:
                for att in range(2):
                    try:
                        r=await asyncio.wait_for(run(br,t,res,errs),5400);done[0]+=1
                        json.dump(res,open(PART,'w'))
                        print(f"[{done[0]}/{len(tasks)}] "+fmt(r),flush=True);return
                    except Exception as e:print('ERR',t.get('kind'),t.get('map'),t.get('v'),repr(e)[:200],flush=True)
                errs.append((t,['did not finish']))
        await asyncio.gather(*[one(t) for t in tasks]);await br.close()
    return res,errs
def score(r,waves):return (1+r['hp']/20) if r['won'] else min(1,max(0,r['wave']-1)/waves)
def evaluate(R,errs):
    FAIL=[];N=[0]
    def chk(name,ok,info=''):
        N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('  '+str(info) if info!='' else ''),flush=True)
        if not ok:FAIL.append(name)
    WV={'moss':10,'frost':15,'ember':20,'coral':15,'wreck':18,'abyss':20,'meadow':15,'foundry':18,'storm':20}
    C=[r for r in R if r['kind']=='camp']
    if C:
        print('\n== 1. campaign maps, mixed build: no potions vs a full satchel (Fury, Frostbite, Hourglass); per map: won/seeds, mean health, stars')
        maps=[m for m in CAMP if any(r['map']==m for r in C)]
        dh=[];bad=[];seedjump=[]
        for m in maps:
            row={v:[r for r in C if r['map']==m and r['v']==v] for v in ('none','good')}
            cell=lambda q:f"{sum(r['won'] for r in q)}/{len(q)} hp {statistics.mean(r['hp'] for r in q):4.1f} st {statistics.mean(r['stars'] for r in q):3.1f}" if q else '-'
            print(f"{m:<9} none {cell(row['none']):<24} potions {cell(row['good']):<24} used {', '.join('/'.join(r.get('pot',[])) or '-' for r in row['good'])}")
            if row['none'] and row['good']:
                a=row['none'];b=row['good'];dh.append(statistics.mean(r['hp'] for r in b)-statistics.mean(r['hp'] for r in a))
                ds=statistics.mean(r['stars'] for r in b)-statistics.mean(r['stars'] for r in a)
                if ds>1 or (not any(r['won'] for r in a) and all(r['won'] and r['stars']>=3 for r in b)):bad.append((m,round(ds,2)))
                for x in a:
                    y=[z for z in b if z['seed']==x['seed']]
                    if y and y[0]['stars']-x['stars']>1:seedjump.append((m,x['seed'],x['stars'],y[0]['stars']))
        md=statistics.mean(dh) if dh else 0
        if seedjump:print('   single seeds that gained two stars (the runs are chaotic: one change flips a close run either way):',seedjump)
        chk(f'(a) campaign: potions gain a little (mean health {md:+.1f} over the maps, at most +4), no map gains more than one star on average and no lost map becomes a three-star win',md<=4 and not bad,bad)
    V=[r for r in R if r['kind']=='value']
    if V:
        print(f'\n== 2a. harder maps under stress (monster health x{STRESS_K} from wave {STRESS_W}), the castle cannot fall: health it would have lost, less the Elixir\'s healing (lower is better)')
        vs=['none','extra','one:noop','three:noop']+[f'one:{k}' for k in POTS]+[f'three:{k}' for k in POTS]
        lost={}
        for v in vs:
            q=[r for r in V if r['v']==v]
            if not q:continue
            lost[v]=statistics.mean(r['lost']-r.get('potHeal',0) for r in q)
            print(f"{v:<14} lost {lost[v]:6.1f}  runs {len(q):>2}  potions used {statistics.mean(len(r.get('pot',[])) for r in q):3.1f}  "+' '.join(f"{m[:5]}:{statistics.mean([r['lost']-r.get('potHeal',0) for r in q if r['map']==m] or [0]):5.1f}" for m in HARD))
        if 'none' in lost and 'extra' in lost:
            ge=lost['none']-lost['extra'];b1=lost.get('one:noop',lost['none']);b3=lost.get('three:noop',lost['none'])
            g1={k:b1-lost['one:'+k] for k in POTS if 'one:'+k in lost}
            print(f"   baseline: no potions {lost['none']:.1f}; placebo once {b1:.1f}, three times {b3:.1f} (the same triggers and cooldowns, no effect: what a perturbed run loses anyway)")
            print(f"   health saved: one extra mid-price tower {ge:+.1f}; one potion (vs the placebo): "+'  '.join(f"{k} {g:+.1f}" for k,g in sorted(g1.items(),key=lambda z:-z[1])))
            over=[(k,round(g,1)) for k,g in g1.items() if g>max(ge,0)*1.1+1]
            chk(f"(b) no single potion saves more health than one extra mid-price tower (+{EXTRA} supply saves {ge:.1f})",not over,over)
            g3={k:b3-lost['three:'+k] for k in POTS if 'three:'+k in lost}
            if g3:
                med=statistics.median(list(g3.values()))
                print('   value (health saved by three of a kind, vs the placebo): '+'  '.join(f"{k} {g:+.1f}" for k,g in sorted(g3.items(),key=lambda z:-z[1]))+f"   median {med:+.1f}")
                useless=[k for k,g in g3.items() if g<=0];must=[k for k,g in g3.items() if med>0 and g>2.5*med]
                chk('(c) every potion is worth something (saves health) and none is a must-pick (at most 2.5 x the median)',not useless and not must,{'useless':useless,'must':must})
    Wn=[r for r in R if r['kind']=='win']
    if Wn:
        print(f'\n== 2b. the same harder maps under stress, normal game: win rate')
        wr={}
        for v in ['none','extra','one:noop']+[f'one:{k}' for k in POTS]:
            q=[r for r in Wn if r['v']==v]
            if not q:continue
            wr[v]=100*sum(r['won'] for r in q)/len(q)
            print(f"{v:<14} win {wr[v]:5.1f}%  runs {len(q):>2}  "+' '.join(f"{m[:5]}:{sum(r['won'] for r in q if r['map']==m)}/{len([r for r in q if r['map']==m])}" for m in HARD))
        if 'extra' in wr:
            if 'one:noop' in wr:print(f"   placebo once: {wr['one:noop']:.0f}% (a perturbed run's chance without any effect)")
            over=[(k,round(wr['one:'+k])) for k in POTS if 'one:'+k in wr and wr['one:'+k]>wr['extra']+15]
            chk(f"(b2) no single potion wins more often than one extra mid-price tower ({wr['extra']:.0f}%), within 15 points (few seeds: noisy)",not over,over)
    E=[r for r in R if r['kind']=='endless']
    if E:
        print(f'\n== 3. endless Wonderland reach (cap {ECAP}), Prism, Dragon, Frost, Tide, Still')
        reach={v:statistics.mean(r['wave'] for r in E if r['v']==v) for v in ('none','good','none8','good8') if any(r['v']==v for r in E)}
        for v in reach:print(f"{v:<6} {reach[v]:6.1f}   ({', '.join(str(r['wave'])+' ['+'/'.join(r.get('pot',[]))+']' for r in E if r['v']==v)})")
        for a,b,n in [('none','good','full board'),('none8','good8','at most eight towers')]:
            if a in reach and b in reach:chk(f"(d) Wonderland reach with potions ({n}) {reach[b]:.1f} <= without {reach[a]:.1f} + 5",reach[b]<=reach[a]+5)
    chk('(e) no page errors in any run',not errs,errs[:3])
    print(f"\n{N[0]-len(FAIL)}/{N[0]} passed"+(' FAILED: '+'; '.join(FAIL) if FAIL else ''))
    return FAIL
async def main():
    t0=time.time()
    if '--reuse' in ARGS:
        R=json.load(open(OUT));errs=[(r,r['errors']) for r in R if r.get('errors')]
    else:
        tasks=[]
        prev=json.load(open(PART)) if '--resume' in ARGS and os.path.exists(PART) else []
        if 'endless' in ONLY:tasks+=tasks_endless()
        if 'value' in ONLY:tasks+=tasks_value()
        if 'camp' in ONLY:tasks+=tasks_camp()
        key=lambda t:json.dumps({k:t.get(k) for k in ('kind','map','v','seed','hpk','inv')},sort_keys=True)
        have={key(r) for r in prev};tasks=[t for t in tasks if key(t) not in have]
        print(f"{len(tasks)} runs on {W} workers"+(f" ({len(prev)} kept)" if prev else ''),flush=True)
        R,errs=await play(tasks,prev)
        old=[]
        if os.path.exists(OUT) and '--fresh' not in ARGS:
            try:old=[r for r in json.load(open(OUT)) if r['kind'] not in ONLY and not (r['kind']=='win' and 'value' in ONLY)]
            except Exception:old=[]
        R=old+[r for r in R if r['kind'] in ONLY or (r['kind']=='win' and 'value' in ONLY)];json.dump(R,open(OUT,'w'),indent=0)
    F=evaluate(R,errs);print(f"({round(time.time()-t0)} s)")
    sys.exit(1 if F else 0)
asyncio.run(main())
