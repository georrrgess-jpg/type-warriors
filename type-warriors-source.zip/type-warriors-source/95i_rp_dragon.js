/* ===== RUNESTONE TOWER DEFENSE 9.0: the Clockwork Dragon Roost in battle (95i, after 95h2; art in 95c4) =====
   The sixth tower, unlocked by winning Ember Crown (the third map) and then usable on every map. Every few seconds the dragon
   turns to its target and breathes a sweeping cone of fire that burns every monster it crosses, flyers included. Tier 3 leaves
   burning ground; tier 4 (Wonderland) splits the breath into twin streams; tier 5 adds the wing dive: every fourth attack the
   dragon leaves its roost, swoops low along the road in a trail of fire and returns. Any tier can be wound up (C, or the panel's
   Wind up button): the gears spin and the next breath comes at once, then the crank needs RPD_CRANK seconds to reset.
   State on the tower: br/brD (breath time left/total), a0/a1 (sweep angles), face (-1..1, eased), nb (breaths since a dive),
   dive {t,d,pts,trail}, ck (crank flash), ckCd (crank cooldown). The HUD gains a sixth card (key Y) and a sixth ring button. */
RP_TW.dragon={cost:[300,420,650,1250,2100],range:[210,225,245,265,285],dps:[90,120,170,280,440],beams:[1,1,1,2,2],cd:[4.2,3.9,3.6,3.3,3],dur:[1.2,1.35,1.5,1.6,1.7],cone:.36,
 burn:[0,0,16,26,42],dive:[0,0,0,0,900],diveN:3,ap:[4,6,8,99,99],air:1,ground:1,
 desc:'A clockwork dragon breathes sweeping fire that burns every monster it crosses, flyers too.',
 up:['Bigger dragon: longer, hotter breath.','Crowned wyrm: its fire leaves the ground burning.','Mythic dragon: the breath splits into twin streams of violet fire.','Celestial dragon: every fourth attack it dives from the roost in a trail of fire.']};
RP_TWORDER.push('dragon');RP_KEYS.push('Y');
const RPD_CRANK=20;
let RPDTW=null;
const rpDragonOpen=()=>{try{const r=RPP();return (r.stars.ember||0)>0||r.dragon===1}catch(e){return false}};
const rpLockedTw=t=>t==='dragon'&&!rpDragonOpen();
function rpSfxRoar(){try{beep(150,.16,'sawtooth',.16);setTimeout(()=>beep(104,.32,'sawtooth',.14),80);setTimeout(()=>beep(70,.36,'triangle',.18),160)}catch(e){}}
/* building: locked until Ember Crown is won */
{const b0=rpBuild;rpBuild=function(pad,type){if(rpLockedTw(type)){rpSfx('no');rpToast('Win Ember Crown to unlock the Dragon Roost',1.8,'#ffb04a');return false}return b0.apply(this,arguments)}}
{const p0=rpPlace;rpPlace=function(type){if(rpLockedTw(type)){rpSfx('no');rpToast('Win Ember Crown to unlock the Dragon Roost',1.8,'#ffb04a');return}return p0.apply(this,arguments)}}
/* ---------- the breath ---------- */
function rpDMouthW(tw,t){const m=rpDragonMouth(tw.tier,{aim:tw.aim,face:tw.face,ph:tw.ph,charge:tw.charge,t});return{x:tw.x+m.x,y:tw.y+m.y}}
const rpAngD=(a,b)=>{let d=a-b;while(d>Math.PI)d-=TAU;while(d<-Math.PI)d+=TAU;return d};
function rpDragonHit(R,tw,T,i,dt,m,angs){const rg=T.range[i],over=tw.over>0?1.3:1,dmg=T.dps[i]*over*dt;
 for(const e of R.foes){if(e.dead||e.s<0)continue;const q=rpPos(R,e);if(rpD2(q.x,q.y,tw.x,tw.y)>rg*rg)continue;const a=Math.atan2(q.y-(e.air?40:18)-m.y,q.x-m.x);
  if(angs.some(b=>Math.abs(rpAngD(a,b))<T.cone)){const fl=e.fl;rpHurt(e,dmg,T.ap[i],tw);e.fl=fl;e.scorch=.25}}}
function rpDragonFire(R,tw,dt){const T=RP_TW.dragon,i=tw.tier-1,rg=T.range[i],sp=tw.over>0?RPT.AB.over.k:1;tw.over=Math.max(0,tw.over-dt);tw.ck=Math.max(0,(tw.ck||0)-dt*1.5);if(tw.ckCd>0)tw.ckCd=Math.max(0,tw.ckCd-dt);
 if(tw.face==null)tw.face=1;const tf=Math.cos(tw.aim||0)<0?-1:1;tw.face+=(tf-tw.face)*Math.min(1,dt*7);
 if(tw.dive)return rpDragonDive(R,tw,T,i,dt);
 if(tw.br>0){tw.br-=dt*(tw.over>0?1.15:1);const u=rpClamp(1-tw.br/tw.brD,0,1);tw.aim=tw.a0+(tw.a1-tw.a0)*rpEase(u);tw.charge=Math.min(1,u*7,Math.max(0,tw.br)*5);tw.fire=1;
  const m=rpDMouthW(tw,R.t),angs=T.beams[i]>1?[tw.aim-.24,tw.aim+.24]:[tw.aim];rpDragonHit(R,tw,T,i,dt,m,angs);tw.m=m;
  if(T.burn[i]){tw.bt=(tw.bt||0)-dt;if(tw.bt<=0){tw.bt=.32;for(const a of angs){const d=rg*.82,x=m.x+Math.cos(a)*d,y=m.y+Math.sin(a)*d;if(R.G.dRoad(x,y)<70&&R.burns.length<40)R.burns.push({x,y,r:52,t:0,d:2.4,dps:T.burn[i],tw})}}}
  if(tw.br<=0){tw.br=0;tw.cd=T.cd[i]-tw.brD;tw.nb=(tw.nb||0)+1}return}
 tw.charge=Math.max(0,(tw.charge||0)-dt*4);tw.fire=Math.max(0,(tw.fire||0)-dt*3);
 tw.cd-=dt*sp;if(tw.cd>0){const e=rpTarget(R,tw,rg,true,true,tw.prio,false);if(e){const q=rpPos(R,e);const m=rpDMouthW(tw,R.t);const ta=Math.atan2(q.y-(e.air?40:18)-m.y,q.x-m.x);tw.aim+=rpAngD(ta,tw.aim||0)*Math.min(1,dt*4)}return}
 const e=rpTarget(R,tw,rg,true,true,tw.prio,false);if(!e){tw.cd=.15;return}
 const q=rpPos(R,e);tw.aim=Math.atan2(q.y-(e.air?40:18)-(tw.y-RPDL[tw.tier].h-50),q.x-tw.x);tw.face=Math.cos(tw.aim)<0?-1:1;
 if(T.dive[i]&&(tw.nb||0)>=T.diveN){tw.nb=0;return rpDragonDiveStart(R,tw,e)}
 const m=rpDMouthW(tw,R.t),ta=Math.atan2(q.y-(e.air?40:18)-m.y,q.x-m.x);tw.sd=tw.sd===1?-1:1;tw.a0=ta-.42*tw.sd;tw.a1=ta+.42*tw.sd;tw.aim=tw.a0;
 tw.br=tw.brD=T.dur[i];tw.bt=.1;if(!R.rm||Math.random()<.5)rpSfxRoar()}
/* the tier-5 wing dive: up from the roost, low along the road over the target, and back */
function rpDragonDiveStart(R,tw,e){const P=R.G.paths[e.pi||0]||R.G.paths[0],len=P.len,s0=Math.min(len-10,e.s+150),s1=Math.max(10,e.s-170),pts=[];
 for(let k=0;k<=8;k++){const p=rpAt(R.G,s0+(s1-s0)*k/8,e.pi);pts.push({x:p.x,y:p.y-34})}
 tw.dive={t:0,d:2.6,pts,hx:tw.x,hy:tw.y-RPDL[5].h-30,trail:[],tt:0};tw.charge=0;rpSfxRoar();setTimeout(()=>{try{rpSfx('boom')}catch(x){}},200);
 rpText(tw.x,tw.y-170,'Wing dive!','#fff2b0',26)}
function rpDivePos(D,u){const H={x:D.hx,y:D.hy},A=D.pts[0],B=D.pts[D.pts.length-1];
 if(u<.24){const v=rpEase(u/.24),cx=(H.x+A.x)/2,cy=Math.min(H.y,A.y)-120;const a=1-v;return{x:a*a*H.x+2*a*v*cx+v*v*A.x,y:a*a*H.y+2*a*v*cy+v*v*A.y}}
 if(u<.76){const v=(u-.24)/.52*(D.pts.length-1),k=Math.min(D.pts.length-2,v|0),f=v-k,p=D.pts[k],q=D.pts[k+1];return{x:p.x+(q.x-p.x)*f,y:p.y+(q.y-p.y)*f}}
 const v=rpEase((u-.76)/.24),cx=(B.x+H.x)/2,cy=Math.min(H.y,B.y)-140,a=1-v;return{x:a*a*B.x+2*a*v*cx+v*v*H.x,y:a*a*B.y+2*a*v*cy+v*v*H.y}}
function rpDragonDive(R,tw,T,i,dt){const D=tw.dive;D.t+=dt;const u=Math.min(1,D.t/D.d),p=rpDivePos(D,u),p2=rpDivePos(D,Math.min(1,u+.01));D.x=p.x;D.y=p.y;D.a=Math.atan2(p2.y-p.y,p2.x-p.x);tw.face=Math.cos(D.a)<0?-1:1;
 if(u>.2&&u<.8){const over=tw.over>0?1.3:1;for(const e of R.foes){if(e.dead||e.s<0)continue;const q=rpPos(R,e);if((q.x-p.x)**2+((q.y-34-p.y)/.8)**2<80*80){const fl=e.fl;rpHurt(e,T.dive[i]*over*dt,99,tw);e.fl=fl;e.scorch=.25}}
  D.tt-=dt;if(D.tt<=0){D.tt=.16;if(R.burns.length<40)R.burns.push({x:p.x,y:p.y+34,r:48,t:0,d:2.2,dps:T.burn[i],tw})}}
 if(!R.lite||D.trail.length<8){D.trail.push({x:p.x,y:p.y,t:0});if(D.trail.length>26)D.trail.shift()}for(const q of D.trail)q.t+=dt;
 if(u>=1){tw.dive=null;tw.cd=T.cd[i]*.6;rpRing(tw.x,tw.y,'#fff2b0',120,6);try{ptBurst(R.fx,tw.x,tw.y-RPDL[5].h-20,16,['#fff2b0','#ffd45a','#ffffff'],{v:220,s:4,k:'star'})}catch(e){}}}
/* winding it up */
function rpCrank(tw){const R=RPX;if(!R||!tw||tw.type!=='dragon'||tw.build<1||R.wst==='done')return false;if(tw.ckCd>0||tw.br>0||tw.dive){rpSfx('no');return false}
 tw.cd=0;tw.ckCd=RPD_CRANK;tw.ck=1;rpSfx('ability');rpText(tw.x,tw.y-150,'Wound up!','#ffd45a',22);try{ptBurst(R.fx,tw.x,tw.y-RPDL[tw.tier].h*.5,10,['#ffd45a','#fff4c8','#c88a10'],{v:200,s:3.5})}catch(e){}return true}
{const f0=rpFire;rpFire=function(R,tw,dt){if(tw.type==='dragon')return rpDragonFire(R,tw,dt);return f0.apply(this,arguments)}}
{const u0=rpUpgrade;rpUpgrade=function(tw){const r=u0.apply(this,arguments);if(r&&tw&&tw.type==='dragon'){tw.br=0;tw.dive=null;tw.charge=0}return r}}
/* drawing: the tower gets its face, dive and crank state; the streams and the flying dragon draw over the battle */
{const d0=rpTowerDraw;rpTowerDraw=function(g,type,tier,skin,t,o){if(type==='dragon'&&RPDTW){o=Object.assign({},o,{face:RPDTW.face==null?1:RPDTW.face,away:RPDTW.dive?1:0,crank:RPDTW.ck||0,charge:RPDTW.charge||0})}return d0.call(this,g,type,tier,skin,t,o)}}
{const b0=rpTowerBuild;rpTowerBuild=function(g,type,tier,skin,k,t,o){if(type==='dragon'&&RPDTW){o=Object.assign({},o,{face:RPDTW.face==null?1:RPDTW.face})}return b0.call(this,g,type,tier,skin,k,t,o)}}
{const a0=rpTowerAt;rpTowerAt=function(c,R,tw){if(tw.type!=='dragon')return a0.apply(this,arguments);RPDTW=tw;try{return a0.apply(this,arguments)}finally{RPDTW=null}}}
{const b0=rpBeamsDraw;rpBeamsDraw=function(c,R){b0.apply(this,arguments);for(const p of R.pads){const tw=p.tw;if(!tw||tw.type!=='dragon'||tw.build<1)continue;
  if(tw.br>0&&tw.m){const i=tw.tier-1,T=RP_TW.dragon,rg=T.range[i]*.86,angs=T.beams[i]>1?[tw.aim-.24,tw.aim+.24]:[tw.aim],k=Math.min(1,tw.charge*1.2);
   for(const a of angs)rpDragonBreath(c,tw.m.x,tw.m.y,tw.m.x+Math.cos(a)*rg,tw.m.y+Math.sin(a)*rg,R.t,k,tw.tier,tw.skin,R.lite)}
  if(tw.dive&&tw.dive.x!=null){const D=tw.dive,P=rpdP(tw.skin,tw.tier);c.save();c.globalCompositeOperation='lighter';
   for(const q of D.trail){const f=Math.max(0,1-q.t/.7);if(f<=0)continue;rpGlow(c,q.x,q.y+6,26*f+8,20*f+6,P.fl[1],.55*f);rpGlow(c,q.x,q.y+6,10*f+4,8*f+3,P.fl[3],.6*f)}c.restore();RPGA=1;
   c.globalAlpha=.35;c.fillStyle='#12081f';c.beginPath();c.ellipse(D.x,D.y+52,40,12,0,0,TAU);c.fill();c.globalAlpha=1;
   rpDragonFly(c,D.x,D.y,D.a,tw.tier,tw.skin,R.t,1)}}}}
/* ---------- the HUD: a sixth card and ring button (locked until Ember Crown is won), the Wind up button ---------- */
{const h0=rpHudOn;rpHudOn=function(){const r=h0.apply(this,arguments);try{const h=$('rphud');if(h){h.classList.add('rp6');const c=h.querySelector('.rpcard[data-tw="dragon"]');if(c&&rpLockedTw('dragon')){c.classList.add('lock');c.insertAdjacentHTML('beforeend',`<i class="rplk">${RPI.lock}</i>`);const tp=c.querySelector('.rptip');if(tp)tp.innerHTML='<b>Dragon Roost · locked</b>Win Ember Crown (the third map) to unlock the clockwork dragon.'}}}catch(e){}return r}}
{const g0=rpHudRing;rpHudRing=function(R,C){const was=C.rg;const r=g0.apply(this,arguments);try{if(C.rg!==was&&C.rg){const el=$('rpring'),p=R.selPad,below=p.y<330,ang=below?[172,140,108,72,40,8]:[-172,-140,-108,-72,-40,-8],rad=158;
  el.querySelectorAll('.rprb').forEach((b,i)=>{const a=ang[i]*Math.PI/180;b.style.setProperty('--x',(Math.cos(a)*rad).toFixed(1)+'px');b.style.setProperty('--y',(Math.sin(a)*rad*.72).toFixed(1)+'px');if(rpLockedTw(b.dataset.tw)){b.classList.add('lock');b.insertAdjacentHTML('beforeend',`<i class="rplk">${RPI.lock}</i>`)}})}}catch(e){}return r}}
{const i0=rpInfoBuild;rpInfoBuild=function(R,tw,el){const r=i0.apply(this,arguments);if(tw.type!=='dragon')return r;try{const T=RP_TW.dragon,i=tw.tier-1,top=RP_MAXT(R.map),nx=tw.tier<top?tw.tier:null;
  const seg=(v,max)=>Math.max(0,Math.min(6,Math.round(v/max*6))),bar=(lab,v,max,nv)=>`<div class="rpst"><span>${lab}</span><i>${[0,1,2,3,4,5].map(k=>`<s class="${k<seg(v,max)?'on':nv!=null&&k<seg(nv,max)?'up':''}"></s>`).join('')}</i></div>`;
  const pw=j=>Math.sqrt(T.dps[j]*T.dur[j]/T.cd[j]*T.beams[j]*3);
  const st=el.querySelector('.rpsts');if(st)st.innerHTML=bar('Range',T.range[i],320,nx!=null?T.range[nx]:null)+bar('Damage',pw(i),Math.sqrt(1400),nx!=null?pw(nx):null)+bar('Breath',T.dur[i],1.8,nx!=null?T.dur[nx]:null)+bar('Burn',T.burn[i]+(T.dive[i]?20:0),62,nx!=null?T.burn[nx]+(T.dive[nx]?20:0):null);
  const pr=el.querySelector('.rppri');if(pr)pr.insertAdjacentHTML('beforebegin',`<button class="rpcrank" id="rpcrank"><span class="rpcrg">${RPI.gear}</span><b>Wind up</b><small id="rpcrks">Breathe fire now</small><kbd>C</kbd></button>`);
  const b=$('rpcrank');if(b)b.onclick=()=>rpCrank(tw);
  /* the panel grew: place it again so the Sell row still clears the tower bar */
  const hgt=el.offsetHeight||460;el.style.top=rpClamp(tw.y-hgt*.62,76,770-hgt)+'px'}catch(e){console.error(e)}return r}}
{const i0=rpHudInfo;rpHudInfo=function(R,C){i0.apply(this,arguments);const tw=R.sel;if(!tw||tw.type!=='dragon')return;const b=$('rpcrank');if(!b)return;
 const s=tw.ckCd>0?`Ready in ${Math.ceil(tw.ckCd)} s`:tw.br>0?'Breathing fire…':tw.dive?'Diving…':'Breathe fire now',dis=tw.ckCd>0||tw.br>0||!!tw.dive;if(b.dataset.s!==s){b.dataset.s=s;rpSetText($('rpcrks'),s);b.classList.toggle('no',dis)}}}
RPI.gear='<svg viewBox="0 0 24 24"><path d="M10.4 2h3.2l.5 2.6 1.9.8 2.2-1.5 2.3 2.3-1.5 2.2.8 1.9 2.6.5v3.2l-2.6.5-.8 1.9 1.5 2.2-2.3 2.3-2.2-1.5-1.9.8-.5 2.6h-3.2l-.5-2.6-1.9-.8-2.2 1.5-2.3-2.3 1.5-2.2-.8-1.9L2 13.6v-3.2l2.6-.5.8-1.9-1.5-2.2 2.3-2.3 2.2 1.5 1.9-.8z" fill="#ffd45a" stroke="#12081f" stroke-width="1.5" stroke-linejoin="round"/><circle cx="12" cy="12" r="3.4" fill="#8a5a14" stroke="#12081f" stroke-width="1.4"/></svg>';
/* keys: Y picks the dragon, C winds up the selected one */
{const k0=rpKeyDown;window.removeEventListener('keydown',rpKeyDown,true);rpKeyDown=function(e){const R=RPX;if(R&&S.rp&&S.mode==='ramparts'&&!R.pause&&!R.over&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&e.key.length===1){const lk=e.key.toLowerCase();
  if(lk==='y'){e.preventDefault();e.stopImmediatePropagation();if(!e.repeat)rpPlace('dragon');return}
  if(lk==='c'&&R.sel&&R.sel.type==='dragon'){e.preventDefault();e.stopImmediatePropagation();if(!e.repeat)rpCrank(R.sel);return}}return k0.apply(this,arguments)};window.addEventListener('keydown',rpKeyDown,true)}
/* winning Ember Crown unlocks the dragon: a card on the result screen, once */
{const r0=rpResult;rpResult=function(){const R=RPX,res=R&&R.result;const out=r0.apply(this,arguments);try{const rp=RPP();if(res&&res.won&&R.map.id==='ember'&&!rp.dragonSeen){rp.dragon=1;rp.dragonSeen=1;save();
  const box=ov.querySelector('.rpres'),unls=box&&box.querySelector('.rpunls');if(unls){unls.insertAdjacentHTML('afterbegin',`<span class="rpunl rpunld"><img alt="" src="${rpIconCanvas('dragon',3,'base',96)}"><b>Dragon Roost</b><small>New tower! Key Y</small></span>`)}
  else if(box){const d=document.createElement('div');d.className='rpdun';d.innerHTML=`<img alt="" src="${rpIconCanvas('dragon',3,'base',120)}"><span><small>NEW TOWER UNLOCKED</small><b>Dragon Roost</b><em>A clockwork dragon that breathes sweeping fire. Build it on any map (key Y).</em></span>`;
   const row=box.querySelector('.row');if(row)row.before(d);else box.appendChild(d)}}}catch(e){console.error(e)}return out}}
/* help texts */
try{const h=HELP.Modes.find(x=>x[0]==='Runestone Tower Defense');if(h)h[1]=h[1].replace('or the Celestial Prism (the costliest: ramping radiant beams).','the Celestial Prism (the costliest: ramping radiant beams) or, once you win Ember Crown, the Dragon Roost (Y: a clockwork dragon whose sweeping fire breath burns every monster it crosses; C winds it up).')}catch(e){}
{const s0=document.createElement('style');s0.textContent=`
.rph.rp6 .rpbar{left:742px;gap:8px}.rph.rp6 .rpcard{width:120px}.rph.rp6 .rpcard img{width:64px;height:64px;margin:-12px -8px 0 -6px}
.rph.rp6 .rpct b{font-size:13px}
.rpcard.lock img,.rprb.lock img{opacity:.45}.rpcard.lock .rpcost,.rprb.lock b{opacity:.5}
.rplk{position:absolute;left:28px;top:26px;width:26px;height:26px;pointer-events:none}.rplk svg{width:100%;height:100%}.rprb .rplk{left:27px;top:20px}
.rpcrank{position:relative;display:grid;grid-template-columns:34px 1fr;grid-template-rows:auto auto;column-gap:10px;align-items:center;width:100%;margin:8px 0 2px;padding:8px 44px 8px 10px;border-radius:14px;border:2px solid #ffb04a;background:linear-gradient(180deg,#4a2a14,#2a140c);color:#fff8e8;text-align:left;cursor:pointer;transition:transform .15s var(--sp)}
.rpcrank:hover{transform:translateY(-2px)}.rpcrank.no{opacity:.55;filter:none}.rpcrank .rpcrg{grid-row:1/3;width:34px;height:34px;display:block;transition:transform .5s var(--sp)}.rpcrank:hover .rpcrg{transform:rotate(90deg)}.rpcrank .rpcrg svg{width:100%;height:100%}
.rpcrank b{font:800 15px var(--ui);color:#ffd45a}.rpcrank small{font:600 12px var(--ui);color:#e8d8c8}.rpcrank kbd{position:absolute;right:10px;top:50%;transform:translateY(-50%)}
.rpdun{display:flex;align-items:center;gap:14px;margin:10px auto 6px;max-width:560px;padding:10px 18px 10px 10px;border-radius:18px;border:2px solid #ffb04a;background:linear-gradient(90deg,#4a2410,#1a0e30);box-shadow:0 0 0 2px #12081f;text-align:left;animation:rpdun .6s var(--sp) both .6s}
.rpdun img{width:96px;height:96px;flex:none;margin:-14px 0 -8px}.rpdun small{display:block;font:800 12px var(--ui);letter-spacing:.14em;color:#ffb04a}.rpdun b{display:block;font:400 32px/1.05 'Pirata One',var(--ui);color:#ffd45a}.rpdun em{display:block;font:600 14px var(--ui);font-style:normal;color:#e8e0ff}
@keyframes rpdun{from{opacity:0;transform:scale(.8)}}
#ov .rpunl.rpunld{border-color:#ffb04a;background:linear-gradient(180deg,#4a2410,#1a0e30)}.rpunl.rpunld b{color:#ffd45a}`;document.head.appendChild(s0)}
