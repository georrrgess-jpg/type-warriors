/* ---------- WARDEN'S ARENA: a timing-based block-and-strike mode (no typing). It temporarily takes Starfall Rift's place on the menus.
   Self-contained: S.wa holds the whole run, S.mode is 'arena', and update()/draw() are wrapped so the typing game is never touched.
   It never writes P.bestWpm, P.bestCombo, P.kills, bestiary, bounties or mastery. Coins are the only reward.
   Flip ARENA_ON to false to bring Starfall Rift back. ---------- */
const ARENA_ON=true;
const WAT={GD:.5,REC:.28,CEN:.15,HALF:.10,LATE:.1,BUF:.12,SREC:.34,WREC:.45,BAR:1.0,HX:470,FY:600,SX:650,SY:450,XA:1040,SLOTS:[1040,1290,1430,1550],HURT:.9,MAXW:5,DT:1/120,ARX:170,MISS:.1};
/* brackets: tk shortens every wind-up, pw narrows the perfect window, hp adds enemy hit points, gm scales coins */
const WAB=[{id:'bronze',n:'Bronze',c:'#e0954f',tk:1,pw:1,hp:-1,gm:1,hearts:6,gd:.5,boss:'gMino',heal:[1,2,3,4,5],rec:.2,exb:.15,gate:0,tw:4,tv:18,tl:0,d:'Slow, clear wind-ups, a roomy block window and 6 hearts. A great place to learn.'},
 {id:'silver',n:'Silver',c:'#cfe0f0',tk:.9,pw:.85,hp:0,gm:1.5,hearts:4,gd:.4,boss:'gCent',heal:[2,4],rec:.26,exb:0,gate:150,tw:5,tv:24,tl:8,d:'Faster strikes, tighter timing, longer combos.'},
 {id:'gold',n:'Gold',c:'#ffc94a',tk:.72,pw:.62,hp:1,gm:2,hearts:3,gd:.31,boss:'gSol',heal:[3],rec:.3,exb:0,gate:450,tw:6,tv:30,tl:12,d:'Quick, tight and ruthless. For champions.'}];
/* fighters: hp, coin value, display zoom, attack style and the special rule that makes each one different */
const WAE={gTiro:{n:'Pit Recruit',hp:5,coin:2,z:1,st:'direct',fx:['#ffd86a','#fff3c0'],tag:'Steady sword swings'},
 gDima:{n:'Twin Blade',hp:6,coin:4,z:1,st:'flurry',flurry:1,fx:['#ff8a7a','#ffffff'],tag:'Flurry: chains of quick slashes'},
 gReti:{n:'Net Caster',hp:6,coin:4,z:1,st:'net',fx:['#9fd8ff','#ffffff'],tag:'Net Snare: the marker freezes, then he thrusts'},
 gSagi:{n:'Sun Archer',hp:5,coin:3,z:1,st:'shot',rng:1,fx:['#bfeaff','#ffffff'],tag:'Perfect blocks reflect his arrows'},
 gMurm:{n:'Shield Wall',hp:9,coin:7,z:1,st:'guard',arm:1,quake:1,guard:1,fx:['#ffd86a','#ff9a5a'],tag:'Scutum Guard: only perfect blocks break it'},
 gThrx:{n:'Thraex Trickster',hp:6,coin:4,z:1,st:'feint',feint:1,uc:'#c88aff',fx:['#ffb86a','#ffffff'],tag:'Feints: never block a purple ?'},
 gMino:{n:'Taurox',ttl:'The Iron Minotaur',hp:24,coin:32,z:1,st:'boss',boss:1,arm:1,quake:1,fx:['#ffd86a','#ff7a3a'],col:'#ff7a3a',col2:'#ff3a2a'},
 gCent:{n:'The Hollow Centurion',ttl:'Legion of One',hp:24,coin:32,z:1,st:'boss',boss:1,arm:1,fx:['#9fe8ff','#ffffff'],col:'#5ac8ff',col2:'#b48aff'},
 gSol:{n:'Imperator Solaris',ttl:'The Golden Colossus',hp:24,coin:32,z:1,st:'boss',boss:1,arm:1,fx:['#ffd86a','#ff9a3a'],col:'#ffb02a',col2:'#ff4a1a'}};
const WAW=[['gTiro','gTiro'],['gDima','gTiro'],['gReti','gSagi','gTiro'],['gThrx','gMurm','gDima'],['gMurm','gThrx','gSagi','gReti']];
const WA_BURST_N=4;const WA_PERF_TXT=['PERFECT BLOCK!','PERFECT!','PERFECT PARRY!'];
/* the player's gold bonuses count here like they do everywhere else */
function waGm(){const w=WP[P.weapon]||{};return 1+.04*U('prosp')+.05*(P.pres||0)+(w.gm||0)}
function waP(){if(!P.wa||typeof P.wa!=='object')P.wa={runs:0,best:{bronze:0,silver:0,gold:0},cl:{bronze:0,silver:0,gold:0},perf:0,tut:0,bs:0};const w=P.wa;w.best=w.best||{bronze:0,silver:0,gold:0};w.cl=w.cl||{bronze:0,silver:0,gold:0};w.foes=w.foes||{};
 /* trophies arrived later: anyone who had already cleared a bracket keeps the doors they opened */
 if(typeof w.tr!=='number'){const t0=(w.cl.silver>0||w.cl.gold>0)?450:w.cl.bronze>0?150:0;w.tr=t0;w.trB=t0;w.road=WA_ROAD.filter(m=>m[0]<=t0).length;w.ws=0}
 return w}
/* ---------- trophies: every run moves you along the Trophy Road, and the road opens the brackets ---------- */
const WA_ROAD=[[25,{c:60}],[60,{c:100}],[100,{c:150}],[150,{b:1,c:200}],[210,{c:200}],[280,{c:250}],[360,{c:300}],[450,{b:2,c:400}],[560,{c:400}],[680,{c:500}],[820,{c:600}],[1000,{c:1000,r:1}]];
const WA_RANK=[[0,'Recruit','#d8a070'],[150,'Gladiator','#cfe0f0'],[450,'Champion','#ffc94a'],[1000,'Legend','#ff8ad8']];
function waRank(tr){let r=WA_RANK[0];for(const q of WA_RANK)if(tr>=q[0])r=q;return r}
function waNextRoad(tr){return WA_ROAD.find(m=>m[0]>tr)||null}
const waOpen=i=>i===0||waP().trB>=WAB[i].gate;
function waTrophies(A,won){const br=A.br,w=waP(),wc=won||A.boss?WAT.MAXW:Math.max(0,A.wave-1),parts=[];
 if(wc)parts.push(['Waves cleared',wc*br.tw]);if(won)parts.push(['Victory',br.tv]);if(won&&A.taken===0)parts.push(['Flawless',6]);if(won&&w.ws>0)parts.push(['Win streak',3*Math.min(w.ws,3)]);
 const pb=Math.min(5,Math.floor(A.perfects/6));if(pb)parts.push(['Perfect blocks',pb]);if(!won&&br.tl)parts.push(['Defeat',-br.tl]);
 let tot=parts.reduce((a,p)=>a+p[1],0),half=false;if(tot>0&&A.bi<2&&waOpen(A.bi+1)){tot=Math.ceil(tot/2);half=true}
 const before=w.tr,bB=w.trB,after=tot<0?Math.max(Math.min(before,br.gate),before+tot):before+tot;w.tr=after;w.trB=Math.max(bB,after);w.ws=won?(w.ws||0)+1:0;
 const claims=[],opened=[];while(w.road<WA_ROAD.length&&WA_ROAD[w.road][0]<=w.trB){const m=WA_ROAD[w.road];claims.push(m);if(m[1].c){P.gold+=m[1].c;stat('gold',m[1].c,'add')}if(m[1].b)opened.push(m[1].b);w.road++}
 return{tot:after-before,parts,half,before,after,claims,opened,rank:waRank(after),up:waRank(after)[0]>waRank(before)[0]}}
/* how far a monster's weapon reaches at full swing, measured once from its own art so the blow always lands on the shield */
const WA_REACH={};
function waReach(id){if(WA_REACH[id]!==undefined)return WA_REACH[id];const M=MON[id];let r=60;try{const c=document.createElement('canvas');c.width=520;c.height=360;const g=c.getContext('2d',{willReadFrequently:true}),o=OL;g.translate(260,300);g.scale(1.4,1.4);OL=1.3;M.d(g,1,{lg:1});OL=o;const d=g.getImageData(0,0,520,360).data;let mn=520;for(let y=0;y<360;y+=2)for(let x=0;x<260;x++){if(d[(y*520+x)*4+3]>40){if(x<mn)mn=x;break}}r=Math.max(40,(260-mn)/1.4)}catch(e){}return WA_REACH[id]=r}
const waSc=e=>MON[e.id].h*WAE[e.id].z/MON[e.id].th;
const wr=(a,b)=>a+Math.random()*(b-a);
/* ---------- run state ---------- */
function waNew(bi){const br=WAB[bi];return{bi,br,wave:0,hp:br.hearts,max:br.hearts,streak:0,charged:0,bestStreak:0,perfects:0,goods:0,taken:0,bursts:0,kills:0,score:0,coins:0,cb:{kill:0,perf:0,wave:0,boss:0,done:0},cd:0,
 en:[],t:0,ph:'intro',phT:0,fx:[],tx:[],shake:0,hs:0,flash:0,pause:false,over:false,tip:null,tipT:0,coach:{},bannerT:0,banner:null,tele:null,zoom:0,inq:[],sched:[],q:2,ft:0,qs:0,qu:0,seen:{},early:0,late:0,mark:null,fr:{block:0,perf:0},
 hero:{st:'idle',until:0,tg:-9,used:false,bad:0,q:null,lunge:0,lt:0,hurt:0,inv:0,pose:null,poseT:0,sh:0,bob:0,ring:0,stag:0},coinShow:0,hitN:0,sp:{k:0,perfect:0,good:0},pend:null,last:null}}
function waStart(bi){waFixRS();reset();S.mode='arena';S.view='';S.camp=0;S.wa=waNew(bi||0);hide();waWave();try{ensureAudio()}catch(e){}if(typeof inp!=='undefined')inp.blur&&inp.blur();if(!waP().guide){S.wa.pause=true;waGuide('start')}}
function waSlotX(id,k){return WAT.SLOTS[Math.min(k,3)]+(k===0&&WAE[id].rng?WAT.ARX:0)}
function waWave(){const A=S.wa;A.wave++;A.ph='intro';A.phT=0;const boss=A.wave>WAT.MAXW;A.boss=boss;A.roared=0;
 const ids=boss?[A.br.boss]:WAW[A.wave-1];A.en=ids.map((id,i)=>waMkEn(id,i));A.en.forEach((e,i)=>{e.x=waSlotX(e.id,i)+260+i*60});A.cur=A.en[0];
 /* the first time a foe shows up in a run, the banner names it and says what makes it special */
 const seen=A.seen||(A.seen={});let fresh=null;for(const id of ids){if(!seen[id]){seen[id]=1;if(!fresh&&!WAE[id].boss&&A.wave>1)fresh=id}}
 if(typeof waFoeCheck==='function')waFoeCheck(ids);
 const D=WAE[ids[0]];
 A.banner={t:boss?2.6:fresh?2.5:2.1,max:boss?2.6:fresh?2.5:2.1,big:boss?'BOSS DUEL':'WAVE '+A.wave,sub:boss?D.n+' · '+D.ttl:fresh?'New foe: '+WAE[fresh].n+' · '+WAE[fresh].tag:(A.wave===1?'Block, then strike!':A.wave+' of '+WAT.MAXW)};jingle(boss?'boss':'wave');
 if(!boss&&A.wave===1&&waP().tut<3)A.tip={t:3.5,txt:'Goal: BLOCK their attacks, then STRIKE when they are exposed.'}}
function waMkEn(id,i){const D=WAE[id],A=S.wa,hp=D.hp+(D.boss?A.br.hp*4:A.br.hp*(D.arm?2:1));return{id,hp,mh:hp,x:waSlotX(id,i),tx:waSlotX(id,i),y:WAT.FY,ph:Math.random()*6,st:'wait',tm:0,hit:null,pat:null,res:[],fat:0,lg:0,lx:0,fl:0,al:1,rot:0,ex:0,exMax:1.5,slot:i,phs:1,lastP:-1,dz:0,stun:0,face:0,kb:0,h0:MON[id].h*D.z,pulse:0}}
/* ---------- attack patterns ---------- */
function waHit(e,r,h,s){const A=S.wa,tk=A.br.tk;const rr=Math.max(.42,r*tk);return{r:rr,h:h||0,s:s||.24,T:0,t:0,done:false,res:null,pend:false}}
/* bosses breathe less as they get angrier, and Solaris never rests for long */
const waGapK=e=>WAE[e.id].boss?(1-.14*(e.phs-1))*(e.id==='gSol'?.88:1):1;
const waPhase=e=>{const f=e.hp/e.mh;return f>.66?1:f>.33?2:3};
/* a feint is a wind-up that never lands: purple ? and a purple marker. Blocking it drops your shield. */
function waFk(e,r,h){const q=waHit(e,r,h||0,.24);q.fk=1;return q}
function waPattern(e){const A=S.wa,w=A.wave,id=e.id,rn=Math.random(),H=(r,h,s)=>waHit(e,r,h,s),F=(r,h)=>waFk(e,r,h);let L;
 if(id==='gTiro'){L=w<3||rn<.7?[H(.72)]:[H(.64),H(.5)]}
 else if(id==='gDima'){/* flurry: quick chains, and a long opening once the whole chain is blocked */L=w<=2?(rn<.5?[H(.62),H(.46)]:[H(.6),H(.44),H(.44)]):rn<.5?[H(.58),H(.42),H(.42)]:[H(.58),H(.4),H(.4),H(.46)]}
 else if(id==='gReti'){/* net snare: the marker freezes while the net whirls, then the trident comes */L=w>=4&&rn<.4?[H(.55,wr(.35,.6),.26),H(.48,0,.24)]:[H(.56,wr(.35,.7),.26)]}
 else if(id==='gSagi'){L=w>=4&&rn<.4?[H(.6,0,.3),H(.46,0,.28)]:[H(.66,0,.3)]}
 else if(id==='gMurm'){/* shield bash: slow, heavy and it shakes the ground */L=rn<.35?[H(.9,0,.3)]:[H(.8,0,.28),H(.6,0,.28)]}
 else if(id==='gThrx'){L=rn<.45?[F(.62),H(.56)]:rn<.7||w<5?[H(.6)]:[H(.56),F(.5),H(.5)]}
 else{const ph=e.phs=waPhase(e);let pool;
  if(id==='gMino'){/* the bull: earth-shaking slams, and a charge after he paws the ground (the marker freezes) */
   pool=ph===1?[[H(.86,0,.3)],[H(.8,0,.3),H(.6,0,.28)],[H(.5,wr(.5,.8),.22)]]:ph===2?[[H(.74,0,.28),H(.56,0,.26),H(.6,0,.28)],[H(.46,wr(.4,.7),.2),H(.5,0,.26)],[H(.7,0,.28),H(.5,0,.26)]]:[[H(.6,0,.26),H(.46,0,.24),H(.5,0,.26),H(.44,0,.24)],[H(.44,wr(.3,.6),.2),H(.44,wr(.2,.5),.2)],[H(.66,0,.28),H(.44,0,.24),H(.44,0,.24)]]}
  else if(id==='gCent'){/* the ghost legion: soul holds and phantom feints */
   pool=ph===1?[[H(.6,.4,.26)],[F(.6),H(.56)],[H(.54,.3,.26),H(.46,0,.24)]]:ph===2?[[F(.52),H(.5,.35,.24)],[H(.5,.3,.24),F(.46),H(.46)],[H(.5,wr(.2,.6),.24),H(.44,.3,.24)]]:[[F(.46),H(.44,.3,.24),F(.42),H(.42)],[H(.42,wr(.2,.7),.22),H(.4,wr(.1,.5),.22),H(.4)],[H(.46,.5,.24),F(.4),H(.38,0,.22),H(.38,.4,.22)]]}
  else{/* Solaris: sun-forged chains that end in a Supernova */
   pool=ph===1?[[H(.84,0,.3)],[H(.72,0,.28),H(.56,0,.26)],[F(.62),H(.6,0,.28)]]:ph===2?[[H(.66,0,.28),H(.5,0,.26),H(.56,0,.28)],[F(.56),H(.5,0,.26),H(.5,0,.26)],[H(.6,.35,.26),H(.44,0,.24)]]:[[H(.56,0,.26),H(.44,0,.24),F(.42),H(.44,0,.24),H(.5,0,.26)],[H(.5,0,.26),H(.42,0,.24),H(.42,0,.24),H(.42,0,.24)],[F(.5),F(.46),H(.46,0,.24),H(.42,0,.24)]]}
  let k=Math.random()*pool.length|0;if(k===e.lastP)k=(k+1)%pool.length;e.lastP=k;L=pool[k]}
 for(const h of L)h.T=h.r+h.h+h.s;return L}
/* ---------- helpers ---------- */
const waBarX=vd=>Math.max(0,Math.min(1,(WAT.BAR-vd)/(WAT.BAR+WAT.LATE)));
function waPW(){return{lo:WAT.CEN-WAT.HALF*S.wa.br.pw,hi:WAT.CEN+WAT.HALF*S.wa.br.pw}}
function waVd(h){const p=h.t<h.r?h.t:h.t<h.r+h.h?h.r:h.r+(h.t-h.r-h.h);return Math.max(0,h.r+h.s-p)}
function waFx(x,y,c,n,o){o=o||{};const A=S.wa;if(A.fx.length>(A.q<1?40:A.q<2?100:240))return;if(A.q<2)n=Math.max(1,Math.ceil(n*(A.q<1?.4:.7)));for(let i=0;i<n;i++){const a=(o.a!==undefined?o.a+(Math.random()-.5)*(o.sp||1.4):Math.random()*TAU),v=(o.v||280)*(.35+Math.random());A.fx.push({x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v-(o.up||0),l:o.l||.55,m:o.l||.55,c,s:o.s||4,g:o.g===undefined?500:o.g,k:o.k||'d'})}}
function waText(x,y,txt,c,sz,o){o=o||{};S.wa.tx.push({x,y,t:o.t||1.1,m:o.t||1.1,txt,c:c||'#fff',sz:sz||40,rot:o.rot||0,vy:o.vy===undefined?-46:o.vy,pop:1})}
/* small steady rewards: every successful block pays a fraction of a coin, and whole coins pop out as they add up */
function waFrac(k,v,x,y){const A=S.wa;A.fr[k]+=v;if(A.fr[k]>=1){A.fr[k]-=1;waCoin(1,k,x,y-70)}}
function waCoin(n,why,x,y){const A=S.wa;n=Math.round(n*waGm()*A.br.gm);if(n<=0)n=1;A.coins+=n;A.cb[why]=(A.cb[why]||0)+n;P.gold+=n;stat('gold',n,'add');
 if(x!==undefined){for(let i=0;i<Math.min(8,2+n);i++)A.fx.push({x:x+wr(-14,14),y:y+wr(-14,14),vx:wr(-90,90),vy:wr(-260,-120),l:1.1,m:1.1,c:'#ffd24a',s:6,g:700,k:'coin',fly:1})}}
const waKb=()=>{try{return TM()?'tap BLOCK':'press SPACE'}catch(e){return 'press SPACE'}},waKs=()=>{try{return TM()?'tap STRIKE':'press ENTER'}catch(e){return 'press ENTER'}};
const waNow=()=>S.wa.t;
function waHeroReady(){const h=S.wa.hero;return h.st==='idle'}
function waSnd(k){try{if(k==='perfect'){beep(880,.07,'triangle',.7);setTimeout(()=>beep(1320,.12,'triangle',.7),55)}else if(k==='good'){beep(520,.08,'triangle',.6)}else if(k==='hit'){beep(180,.14,'sawtooth',.7)}else if(k==='strike'){beep(300,.05,'square',.45);setTimeout(()=>beep(520,.06,'square',.4),40)}else if(k==='whiff'){beep(150,.1,'triangle',.4)}else if(k==='tick'){beep(1100,.03,'sine',.25)}else if(k==='raise'){beep(240,.1,'sawtooth',.3)}else if(k==='burst'){jingle('fury')}else if(k==='kill'){beep(420,.08,'square',.5);setTimeout(()=>beep(630,.1,'square',.5),70)}}catch(e){}}
/* ---------- input ---------- */
function waBlock(){const A=S.wa;if(!A||A.over||A.pause||S.mode!=='arena'||A.ph==='intro'&&A.phT<.3&&false)return;const h=A.hero;
 if(h.st==='dead'||A.ph==='win'||A.ph==='lose')return;
 if(h.st!=='idle'){if(h.until-A.t<=WAT.BUF)h.q={a:'block',x:A.t+WAT.BUF};return}
 h.st='guard';h.tg=A.t;h.until=A.t+A.br.gd;h.used=false;h.sh=0;h.q=null;h.ring=1;waSnd('tick');
 {const c0=A.cur,H0=c0&&c0.st==='tele'&&c0.hit&&!c0.hit.done&&!c0.hit.pend?c0.hit:null;A.mark={vd:H0?waVd(H0):null,t:A.t,k:null}}
 /* a press just after the blow arrived still counts: the hit is waiting for it */
 const e=A.cur;if(e&&e.hit&&e.hit.pend&&A.t-e.hit.tc<=WAT.LATE){e.hit.pd=-(A.t-e.hit.tc);if(A.mark)A.mark.vd=e.hit.pd;waResolve(e,'good')}}
/* a feint pulls back mid-swing: reading it pays, biting on it drops your shield */
function waFeint(e){const A=S.wa,H=e.hit,h=A.hero;H.done=true;H.res='feint';H.after=0;A.feints=(A.feints||0)+1;
 const ex=e.x+e.lx-40,ey=e.y-e.h0*.8;waFx(ex,ey,'#c88aff',10,{v:260,l:.45,s:3,g:-40});
 if(h.st==='guard'&&!h.used){h.used=true;A.bit=(A.bit||0)+1;h.badAt=A.t;waMistime('FOOLED BY A FEINT!')}
 else{A.read=(A.read||0)+1;waText(ex-40,ey-40,'FEINT READ!','#d8b8ff',34,{t:.8});A.score+=15;waFrac('block',.35,WAT.SX,WAT.SY)}}
/* a block pressed too early: the shield drops before the blow, the Shieldburst streak breaks and the hero is slow to recover */
function waMistime(why){const A=S.wa,h=A.hero,e=A.cur,H=e&&e.st==='tele'&&e.hit&&!e.hit.done?e.hit:null;
 h.bad=A.t+.6;h.badAt=A.t;A.early++;A.streak=0;if(A.mark&&A.mark.k===null)A.mark.k='early';h.st='brec';h.until=A.t+A.br.rec+WAT.MISS;h.sh=1;
 waText(WAT.HX+40,WAT.FY-300,why||(H?'TOO EARLY!':'NOTHING TO BLOCK!'),why?'#d8a8ff':'#ffb04a',42,{t:1});waSnd('whiff');A.shake=Math.max(A.shake,4);waFx(WAT.SX+10,WAT.SY,'#ff9a5a',8,{v:240,a:Math.PI,sp:2.4,l:.35,s:3,g:300});
 if(why){if(!A.coach.feint){A.coach.feint=1;A.tip={t:5.5,txt:'That was a FEINT. A purple ? means a fake attack: do not block it.'}}return}
 if(!A.coach.early&&(A.early>=1)){A.coach.early=1;A.tip={t:5.5,txt:H?'Too early! Wait until the marker reaches the green zone, then press.':'Only block when an enemy attacks. Wait for the red ! and the sliding marker.'}}}
function waStrike(){const A=S.wa;if(!A||A.over||A.pause||S.mode!=='arena')return;const h=A.hero;if(h.st==='dead'||A.ph==='win'||A.ph==='lose')return;
 if(h.st!=='idle'){if(h.until-A.t<=WAT.BUF)h.q={a:'strike',x:A.t+WAT.BUF};return}
 h.q=null;const e=A.cur;
 if(A.charged&&e&&e.st!=='dead'&&A.ph==='fight'){waBurst(e);return}
 if(e&&e.st==='roar')return;
 if(e&&e.st==='exp'){h.st='strike';h.until=A.t+WAT.SREC;h.lt=0;h.pk=1;h.at0=A.t;h.atn=(h.atn||0)+1;h.atk='hit';
  if(e.guardUp){e.guardUp=0;e.kb=.6;A.shake=Math.max(A.shake,8);A.hs=Math.max(A.hs,.04);waSnd('good');const gx=e.x-50,gy=e.y-e.h0*.55;waFx(gx,gy,'#ffe9a8',16,{v:420,a:Math.PI,sp:1.8,l:.4,s:3,g:300,k:'spark'});A.fx.push({x:gx,y:gy,k:'ripple',l:.35,m:.35,r:20,c:'#ffd86a'});waText(gx-40,gy-60,'SHIELD BLOCKS IT!','#ffd86a',34,{t:.9});if(!A.coach.guard){A.coach.guard=1;A.tip={t:5.5,txt:'His scutum stopped that one. Strike again, or block every hit PERFECTLY to break his guard.'}}}
  else{waDamage(e,1);waSnd('strike')}}
 else{h.st='whiff';h.until=A.t+WAT.WREC;h.lt=0;h.pk=.5;h.at0=A.t;h.atk='whiff';waSnd('whiff');waText(WAT.HX+60,WAT.FY-300,'Too soon!','#ff8a7a',34,{t:.8});if(!A.coach.whiff&&waP().tut<3){A.coach.whiff=1;A.tip={t:4.5,txt:'Only strike when the enemy is EXPOSED. A wasted swing leaves you open.'}}}}
function waPauseToggle(on){const A=S.wa;if(!A||A.over||S.mode!=='arena')return;A.pause=on===undefined?!A.pause:on;if(A.pause)waPauseMenu();else{hide();try{inp.blur()}catch(e){}}}
/* ---------- resolving blocks, hits and damage ---------- */
function waContact(e){const A=S.wa,h=A.hero,H=e.hit;H.tc=A.t;const lo=waPW();
 if(h.st==='guard'&&A.t>=h.tg&&A.t<=h.until){const d=A.t-h.tg,perfect=d>=lo.lo&&d<=lo.hi;H.pd=d;if(A.mark&&A.mark.k===null)A.mark.vd=d;waResolve(e,perfect?'perfect':'good');return}
 H.pend=true}
function waResolve(e,kind){const A=S.wa,H=e.hit,h=A.hero;if(H.done)return;H.done=true;H.pend=false;H.res=kind;e.res.push(kind==='perfect'?1:.5);h.used=true;if(A.mark&&A.mark.k===null)A.mark.k=kind;
 const sx=WAT.SX,sy=WAT.SY;
 if(kind==='perfect'){A.streak++;A.perfects++;A.bestStreak=Math.max(A.bestStreak,A.streak);A.hs=.09;A.shake=Math.max(A.shake,9);A.flash=.35;h.ring=2;
  waFx(sx+16,sy,'#bfeaff',20,{v:520,a:0,sp:2.2,l:.5,s:4,g:200});waFx(sx+16,sy,'#ffd86a',16,{v:640,a:0,sp:1.6,l:.4,s:3,g:100,k:'spark'});A.fx.push({x:sx,y:sy,k:'ripple',l:.6,m:.6,r:30,c:'#7fd0ff',big:1});
  waText(sx-80,sy-140,WA_PERF_TXT[A.perfects%3],'#9fe0ff',54,{t:.9,rot:-.05});waSnd('perfect');waFrac('perf',.7,sx,sy);A.score+=Math.round(25*(1+Math.min(A.streak,5)*.2));
  if(A.streak>=2&&!A.charged)A.streakPop=.9;
  if(A.streak>=WA_BURST_N&&!A.charged){A.charged=1;A.streak=0;waText(W/2,230,'SHIELDBURST READY!','#ffd86a',60,{t:1.6,vy:-20});waFx(WAT.HX+110,WAT.FY-150,'#ffd86a',26,{v:380,l:.7,s:5,g:-80});jingle('boon');A.chBurst=1;
   if(waP().tut<3&&!A.coach.burst){A.coach.burst=1;A.tip={t:5,txt:'Shieldburst charged! '+waKs()+' any time to unleash it.'}}}}
 else{A.streak=0;A.goods++;A.hs=.05;A.shake=Math.max(A.shake,5);h.ring=1.3;A.fx.push({x:sx,y:sy,k:'ripple',l:.45,m:.45,r:26,c:'#7fb0e8'});waFx(sx+10,sy,'#cfe6ff',10,{v:360,a:0,sp:2,l:.35,s:3,g:200});{const lo=waPW(),pd=H.pd===undefined?lo.lo:H.pd,lab=pd>lo.hi?'Blocked · a bit early':pd<lo.lo?'Blocked · a bit late':'Blocked';waText(sx-70,sy-120,lab,'#cfe6ff',lab.length>9?30:34,{t:.8});if(pd>lo.hi){A.earlyG=(A.earlyG||0)+1;if(A.earlyG===2&&!A.coach.eg){A.coach.eg=1;A.tip={t:4.5,txt:'Blocked, but a bit early. Press when the marker is in the GOLD zone for a perfect.'}}}else if(pd<lo.lo){A.lateG=(A.lateG||0)+1;if(A.lateG===2&&!A.coach.lg){A.coach.lg=1;A.tip={t:4.5,txt:'Blocked, but a bit late. Press just before the marker reaches the white line.'}}}}waSnd('good');waFrac('block',.35,sx,sy)}
 waImpact(e,kind);if(A.cur===e)A.last=kind}
/* every foe leaves its own mark when its blow is stopped */
function waImpact(e,kind){const A=S.wa,D=WAE[e.id],fc=D.fx||['#cfe6ff','#fff'],pf=kind==='perfect',sx=WAT.SX,sy=WAT.SY;
 if(D.rng){waArrowEnd(e,kind);return}
 waFx(sx+34,sy+8,fc[0],pf?13:7,{v:pf?430:300,a:-.5,sp:2.2,l:.45,s:4,g:520});if(pf)waFx(sx+30,sy,fc[1],8,{v:520,a:-.3,sp:2,l:.35,s:3,g:200,k:'spark'});
 if(D.quake)waQuake(e,pf?.55:1)}
function waQuake(e,k){const A=S.wa;A.shake=Math.max(A.shake,(D=>D.boss?20:15)(WAE[e.id])*k);A.fx.push({x:WAT.SX+150,y:WAT.FY+10,k:'ripple',l:.55,m:.55,r:46,c:'#c8b0ff',flat:1});waFx(WAT.SX+80,WAT.FY+4,'#a898c8',9,{v:240,a:-Math.PI/2,sp:2.4,l:.6,s:6,g:-60})}
/* an arrow that is blocked splinters, a perfect block sends it back where it came from */
function waArrowEnd(e,kind){const A=S.wa,sx=WAT.SX+14,sy=WAT.SY,tx=e.x+e.lx-36,ty=e.y-e.h0*.6;
 if(kind==='perfect'){const T=Math.max(.12,(tx-sx)/2300);A.fx.push({x:sx,y:sy,vx:(tx-sx)/T,vy:(ty-sy)/T,l:T,m:T,k:'arrow',c:'#bfeaff',s:1,g:0,keep:1});
  A.sched.push({at:A.t+T,fn:()=>{if(!S.wa)return;e.fl=.14;waFx(tx,ty,'#ffffff',12,{v:420,l:.4,s:4,g:200});waFx(tx,ty,'#bfeaff',10,{v:520,l:.35,s:3,g:100,k:'spark'});A.fx.push({x:tx,y:ty,k:'ripple',l:.35,m:.35,r:18,c:'#bfeaff'});waText(tx-70,ty-70,'REFLECTED!','#bfeaff',34,{t:.8})}})}
 else{waFx(sx+10,sy,'#d8c8a0',9,{v:380,a:-.6,sp:2.4,l:.5,s:3,g:620,k:'spark'});waFx(sx+10,sy,'#bfeaff',6,{v:260,a:-.4,sp:2,l:.4,s:3,g:300})}}
function waEnrage(e,p){const A=S.wa,D=WAE[e.id];e.st='roar';e.tm=1.2;e.hit=null;e.cancel=false;e.pulse=1;e.res=[];
 A.shake=Math.max(A.shake,26);A.flash=Math.max(A.flash,.5);A.hs=Math.max(A.hs,.08);
 const hx=e.x,hy=e.y-e.h0*.55;A.fx.push({x:hx,y:hy,k:'ripple',l:.8,m:.8,r:50,c:D.col,big:1});A.fx.push({x:hx,y:hy,k:'ripple',l:1.05,m:1.05,r:30,c:D.col2,big:1});waFx(hx,hy,D.col,30,{v:620,l:.8,s:5,g:-40});waFx(hx,hy,'#ffffff',12,{v:520,l:.5,s:3,g:0,k:'spark'});
 waText(hx-20,e.y-e.h0*.9,p>=3?'FURY!':'ENRAGED!',D.col,60,{t:1.2,vy:-16});try{beep(90,.28,'sawtooth',.8);setTimeout(()=>beep(70,.4,'sawtooth',.7),120)}catch(x){}
 A.tip=null}
function waHurt(e){const A=S.wa,h=A.hero,pst=h.st;if(h.inv>A.t){e.hit.done=true;e.hit.res='dodge';return}
 e.hit.done=true;e.hit.pend=false;e.hit.res='hit';e.res.push(0);A.hp--;A.taken++;A.streak=0;A.charged=0;h.hurt=.5;h.inv=A.t+WAT.HURT;A.shake=22;A.hs=.12;A.flash=.6;A.hurtFl=.6;h.stag=1;h.st='stag';h.until=A.t+.34;h.q=null;
 waFx(WAT.HX+40,WAT.FY-170,'#ff4a5a',22,{v:420,l:.6,s:5});waText(WAT.HX,WAT.FY-290,'OUCH!','#ff7a6a',50,{t:.9});{const why=A.t-(h.badAt||-9)<1.3?'You blocked too early':pst==='brec'?'Shield was still recovering':'No block in time';waText(WAT.HX+20,WAT.FY-248,why,'#ffd0c0',26,{t:1.1})}waSnd('hit');
 e.cancel=true;if(WAE[e.id].quake)waQuake(e,1.1);if(WAE[e.id].rng)A.fx.push({x:WAT.SX+40,y:WAT.SY+30,vx:-140,vy:-60,l:.8,m:.8,k:'arrow',c:'#cfe0ff',s:1,g:900,keep:1});if(A.hp<=0)waLose()}
function waDamage(e,n){const A=S.wa;e.hp-=n;e.fl=.16;A.hs=Math.max(A.hs,.05);A.shake=Math.max(A.shake,7);e.kb=1;
 waFx(e.x-40,e.y-e.h0*.55,'#ffe9a8',14,{v:430,a:Math.PI,sp:1.6,l:.4,s:3.5,g:300,k:'spark'});waFx(e.x-30,e.y-e.h0*.5,'#fff',6,{v:300,l:.3,s:3});A.fx.push({x:e.x-30,y:e.y-e.h0*.5,k:'ripple',l:.28,m:.28,r:14,c:'#ffd86a'});
 waText(e.x-84,e.y-e.h0*.66,'-'+n,'#fff2c0',40,{t:.7});A.score+=10*n;A.fx.push({x:e.x-34,y:e.y-e.h0*.55,k:'slash',l:.26,m:.26,r:Math.min(150,e.h0*.5),rot:(Math.random()-.5)*.7,big:n>1});
 if(e.hp<=0)waKill(e);else if(WAE[e.id].boss){const p=waPhase(e);if(p>e.phs){e.phs=p;waEnrage(e,p)}}}
function waBurst(e){const A=S.wa,h=A.hero;A.charged=0;A.streak=0;A.bursts++;h.st='strike';h.until=A.t+.6;h.lt=0;h.pk=1.25;h.burstT=.7;h.at0=A.t;h.atk='hit';h.atn=(h.atn||0)+1;e.guardUp=0;A.hs=.14;A.shake=26;A.flash=.9;A.score+=150;
 const bx=WAT.HX+120,by=WAT.FY-150;A.fx.push({x:bx,y:by,k:'ripple',l:.75,m:.75,r:40,c:'#ffe27a',big:1});A.fx.push({x:bx,y:by,k:'ripple',l:1,m:1,r:20,c:'#7fd0ff',big:1});A.fx.push({x:bx,y:by,k:'wave',l:.8,m:.8});
 waFx(bx,by,'#ffe27a',44,{v:900,l:.8,s:5,g:0});waFx(bx,by,'#bfeaff',30,{v:700,l:.7,s:4,g:0,k:'spark'});waText(W/2,250,'SHIELDBURST!','#ffe27a',72,{t:1.3,vy:-14});jingle('fury');
 waDamage(e,3);const nx=A.en.find(q=>q!==e&&q.st!=='dead'&&q.st!=='gone');if(nx&&nx.hp>0){waDamage(nx,1)}
 if(e.hp>0&&e.st!=='roar'){e.st='stun';e.tm=.8;e.hit=null;e.cancel=false}
 for(const d of[.07,.14])A.sched.push({at:A.t+d,fn:()=>{if(S.wa&&e.st!=='gone')A.fx.push({x:e.x-30,y:e.y-e.h0*.5+(d>.1?30:-30),k:'slash',l:.24,m:.24,r:Math.min(170,e.h0*.55),rot:d>.1?.5:-.5,big:1})}})
 if(!A.coach.burst2&&waP().tut<3){A.coach.burst2=1}}
function waKill(e){const A=S.wa;if(e.st==='dead')return;e.st='dead';e.tm=0;e.hit=null;A.kills++;A.score+=100+20*A.wave+(WAE[e.id].boss?1400:0);const D=WAE[e.id];
 /* the crowd loves a kill; the last foe of a wave gets a finisher pause */
 const last=!A.en.some(q=>q!==e&&q.st!=='dead'&&q.st!=='gone');if(last&&!D.boss){A.hs=Math.max(A.hs,.22);waText(e.x-60,e.y-e.h0-60,'FINISHER!','#ffe27a',50,{t:1.1,vy:-24})}
 for(let i=0;i<(A.q<1?6:16);i++)A.fx.push({x:wr(80,1520),y:wr(180,300),vx:wr(-60,60),vy:wr(-120,-20),l:1.6,m:1.6,c:['#ffd24a','#ff7a8a','#e8e0d0','#7fd0ff'][i%4],s:wr(4,7),g:260,k:'conf'});
 waCoin(D.coin,D.boss?'boss':'kill',e.x,e.y-e.h0*.6);waFx(e.x,e.y-e.h0*.5,'#fff',24,{v:520,l:.55,s:5});waFx(e.x,e.y-e.h0*.5,'#ffd86a',16,{v:400,l:.6,s:4,k:'spark'});A.fx.push({x:e.x,y:e.y-e.h0*.5,k:'ripple',l:.5,m:.5,r:20,c:'#fff'});
 waSnd('kill');A.hs=Math.max(A.hs,D.boss?.35:.1);A.shake=Math.max(A.shake,D.boss?30:12);if(D.boss){A.boss_slow=1.2;for(let i=0;i<3;i++)A.fx.push({x:e.x,y:e.y-e.h0*.5,k:'ripple',l:.7+i*.25,m:.7+i*.25,r:30+i*14,c:i%2?D.col2:D.col,big:1});waFx(e.x,e.y-e.h0*.5,D.col,46,{v:760,l:1,s:6,g:60});waFx(e.x,e.y-e.h0*.5,'#ffffff',20,{v:640,l:.6,s:4,g:0,k:'spark'})}}
function waLose(){const A=S.wa;A.ph='lose';A.phT=0;A.hero.pose='dead';A.hero.poseT=0;A.hero.st='dead';jingle('lose');A.en.forEach(q=>{if(q.hit)q.hit=null})}
function waWin(){const A=S.wa;A.ph='win';A.phT=0;A.hero.pose='victory';A.hero.poseT=0;A.charged=0;jingle('win');waCoin(40,'done',WAT.HX+80,WAT.FY-200);A.score+=A.hp*300+800;
 for(let i=0;i<60;i++)A.fx.push({x:wr(100,1500),y:wr(-60,200),vx:wr(-40,40),vy:wr(60,200),l:2.4,m:2.4,c:['#ffd24a','#7fd0ff','#ff7aa8','#9affc8'][i%4],s:wr(4,8),g:60,k:'conf'})}
/* ---------- the clock ---------- */
/* Real presses are queued with their true time and applied at that exact moment inside a fixed-step simulation, so a slow
   laptop judges a block exactly as a fast PC does. Tests and bots may still call waBlock()/waStrike() directly. */
function waIn(k,ts){const A=S.wa;if(!A||A.over||A.pause||S.mode!=='arena')return;A.inq.push({k,w:ts||performance.now(),f:1})}
function waApplyIn(q){q.k==='b'?waBlock():waStrike()}
function waUpdate(dt){const A=S.wa;if(!A)return;dt=Math.min(dt,.1);if(A.pause){A.inq.length=0;A.wall=0;return}
 const now=performance.now(),prev=A.wall||now-dt*1000;A.wall=now;const span=Math.max(1,now-prev);for(const q of A.inq)q.f=Math.max(0,Math.min(1,(q.w-prev)/span));
 if(A.hs>0){A.hs-=dt;dt*=.06}if(A.boss_slow>0){A.boss_slow-=dt;dt*=.35}
 waVisual(dt);
 let el=0;const DT=WAT.DT;while(el<dt-1e-9){const ds=Math.min(dt-el,DT);while(A.inq.length&&A.inq[0].f*dt<=el+1e-9)waApplyIn(A.inq.shift());waSim(ds);el+=ds}
 while(A.inq.length)waApplyIn(A.inq.shift())}
/* things that only need to look right once per frame */
function waVisual(dt){const A=S.wa;
 A.shake=Math.max(0,A.shake-dt*60);A.flash=Math.max(0,A.flash-dt*2.6);A.hurtFl=Math.max(0,(A.hurtFl||0)-dt*1.6);if(A.streakPop>0)A.streakPop-=dt;if(A.tipT>0)A.tipT-=dt;
 if(A.tip){A.tip.t-=dt;if(A.tip.t<=0)A.tip=null}
 if(A.banner){A.banner.t-=dt;if(A.banner.t<=0)A.banner=null}
 for(let i=A.fx.length-1;i>=0;i--){const p=A.fx[i];p.l-=dt;if(p.l<=0){A.fx.splice(i,1);continue}if(p.k==='ripple'||p.k==='wave'||p.k==='slash')continue;
  if(p.fly){const tx=1330,ty=44,u=1-p.l/p.m;if(u>.45){p.x+=(tx-p.x)*Math.min(1,dt*6);p.y+=(ty-p.y)*Math.min(1,dt*6);p.vx=0;p.vy=0;if(Math.hypot(tx-p.x,ty-p.y)<30){p.l=0;A.coinPop=.25}continue}}
  p.vy+=p.g*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.vx*=p.k==='arrow'?1:.992}
 for(let i=A.tx.length-1;i>=0;i--){const q=A.tx[i];q.t-=dt;q.y+=q.vy*dt;q.vy*=.94;q.pop=Math.max(0,q.pop-dt*5);if(q.t<=0)A.tx.splice(i,1)}
 if(A.coinPop>0)A.coinPop-=dt;A.coinShow+=(A.coins-A.coinShow)*Math.min(1,dt*9);if(Math.abs(A.coins-A.coinShow)<.5)A.coinShow=A.coins;
 if(A.chBurst)A.chBurst=0}
/* the game itself: a fixed step of at most 1/120 s */
function waSim(dt){const A=S.wa;A.t+=dt;A.phT+=dt;S.t+=dt;const h=A.hero;
 if(A.sched.length)for(let i=A.sched.length-1;i>=0;i--){const q=A.sched[i];if(A.t>=q.at){A.sched.splice(i,1);try{q.fn()}catch(x){}}}
 if(h.st==='guard'&&A.t>=h.until){if(!h.used)waMistime();else{h.st='brec';h.until=A.t+A.br.rec;h.sh=1}}
 else if(h.st!=='idle'&&h.st!=='guard'&&h.st!=='dead'&&A.t>=h.until){h.st='idle';if(h.q&&A.t<=h.q.x){const q=h.q.a;h.q=null;q==='block'?waBlock():waStrike()}else h.q=null}
 h.lt+=dt;{const pk=h.pk||0;h.lunge=pk<=0?0:h.lt<.06?pk*sstep(0,1,h.lt/.06):pk*Math.exp(-(h.lt-.06)*6.5);if(h.lunge<.002&&h.lt>.06){h.lunge=0;h.pk=0}}h.hurt=Math.max(0,h.hurt-dt);h.stag=Math.max(0,h.stag-dt*3);h.ring=Math.max(0,h.ring-dt*2.4);if(h.burstT>0)h.burstT-=dt;
 if(h.pose){h.poseT+=dt}
 if(A.ph==='intro'){const e=A.cur;if(A.boss&&!A.roared&&A.phT>.75){A.roared=1;A.shake=Math.max(A.shake,22);const D=WAE[e.id];A.fx.push({x:e.x,y:e.y-e.h0*.5,k:'ripple',l:.9,m:.9,r:50,c:D.col,big:1});waFx(e.x,e.y-e.h0*.5,D.col,26,{v:520,l:.7,s:5,g:-30});try{beep(80,.35,'sawtooth',.8)}catch(x){}}
  if(A.phT>1.5){A.ph='fight';A.phT=0;if(e){waWake(e,.5)}}}
 else if(A.ph==='fight'){waFight(dt)}
 else if(A.ph==='clear'){if(A.phT>2.1){waWave()}}
 else if(A.ph==='win'){if(A.phT>2.4&&!A.over)waFinish(true)}
 else if(A.ph==='lose'){if(A.phT>2.0&&!A.over)waFinish(false)}
 for(const e of A.en){waEnemyAnim(e,dt);if(e.pulse>0)e.pulse=Math.max(0,e.pulse-dt*1.4)}}
function waWake(e,gap){e.st='gap';e.tm=gap;e.res=[];e.fat=0;e.hit=null;e.cancel=false}
function waFight(dt){const A=S.wa,e=A.cur;if(!e){return}
 if(e.st==='dead'){/* wait for the fall to finish, then promote the next fighter or end the wave */
  if(e.tm>.75){e.st='gone';const nx=A.en.find(q=>q.st!=='gone'&&q.st!=='dead');if(nx){A.cur=nx;nx.tx=waSlotX(nx.id,0);waWake(nx,.95);nx.st='enter';nx.tm=.7;A.en.forEach(q=>{if(q.st==='wait')q.slot=Math.max(0,q.slot-1)});waSlots()}
   else if(A.boss){waWin()}else{A.ph='clear';A.phT=0;waWaveClear()}}
  return}
 e.tm-=dt;
 if(e.st==='enter'){if(e.tm<=0)waWake(e,.5)}
 else if(e.st==='stun'){if(e.tm<=0)waWake(e,.4)}
 else if(e.st==='roar'){if(e.tm<=0)waWake(e,.6)}
 else if(e.st==='gap'){if(e.tm<=0){e.pat=waPattern(e);e.pi=0;e.hit=e.pat[0];e.hit.t=0;e.st='tele';e.res=[];e.cancel=false;waSnd('raise');if(A.tip&&A.tip.txt.indexOf('gold zone')<0&&false)A.tip=null}}
 else if(e.st==='tele'){const H=e.hit;if(!H){e.st='gap';e.tm=.6;return}
  if(!A.coach.tele&&waP().tut<3&&e.pi===0&&H.t<.05){A.coach.tele=1;A.tip={t:6,txt:'Red ! = attack coming. '+waKb()+' when the marker reaches the GOLD zone.'}}
  if(!H.pend&&!H.done){const before=H.t;H.t+=dt;if(!H.tickd&&H.t>=H.r&&H.h>0){H.tickd=1}
   if(H.fk){if(H.t>=H.r+H.h+H.s*.42)waFeint(e)}else if(before<H.T&&H.t>=H.T){H.t=H.T;waContact(e)}}
  else if(H.pend){/* waiting out the grace for a late block */if(A.t-H.tc>WAT.LATE){waHurt(e)}}
  if(H.done){e.lg=e.lg;/* move on once the strike has visibly landed */
   if(!H.after){H.after=0}H.after+=dt;const wait=H.res==='hit'?.5:H.res==='feint'?.16:.2;
   if(H.after>=wait){if(e.cancel){e.st='rec';e.tm=.75;e.hit=null}else if(e.pi+1<e.pat.length){e.pi++;e.hit=e.pat[e.pi];e.hit.t=0;waSnd('raise')}else waPatternEnd(e)}}}
 else if(e.st==='rec'){if(e.tm<=0)waWake(e,wr(.45,.75)*waGapK(e))}
 else if(e.st==='exp'){e.ex-=dt;if(e.ex<=0){e.st='rec';e.tm=.55;e.hit=null;waText(e.x,e.y-e.h0-70,'Recovered','#e0e0f0',28,{t:.6});}}}
function waPatternEnd(e){const A=S.wa,sum=e.res.reduce((a,b)=>a+b,0),n=e.res.length||1,sc=sum/n,D=WAE[e.id];e.hit=null;
 if(sc>=.5){const long=sc>=.75;e.st='exp';e.exMax=e.ex=(long?1.25:.8)+A.br.exb+(D.flurry&&n>=3?.3:0)+(D.guard?.35:0);e.fat=sc;
  if(D.guard){const allP=e.res.length&&e.res.every(v=>v>=1);e.guardUp=allP?0:1;if(allP){waText(e.x-40,e.y-e.h0-150,'GUARD BROKEN!','#ffe27a',40,{t:1,vy:-20});A.shake=Math.max(A.shake,10);waFx(e.x-60,e.y-e.h0*.5,'#ffd86a',18,{v:420,l:.5,s:4})}}waText(e.x,e.y-e.h0-100,'EXPOSED!','#ffd24a',46,{t:.9,vy:-20});waSnd('tick');
  if(waP().tut<3&&!A.coach.exp){A.coach.exp=1;A.tip={t:5.5,txt:'EXPOSED! '+waKs()+' to counter before the glow fades.'}}
  if(WAE[e.id].boss&&!long&&e.phs>=2){e.ex=e.exMax=.8}}
 else{e.st='rec';e.tm=.6}}
function waSlots(){const A=S.wa;let k=1;for(const e of A.en){if(e===A.cur||e.st==='gone'||e.st==='dead')continue;e.tx=WAT.SLOTS[Math.min(k,3)];k++}}
function waWaveClear(){const A=S.wa;A.hero.q=null;const b=3+2*A.wave;waCoin(b,'wave',W/2,300);A.score+=200;let heal=false;
 if(A.br.heal.includes(A.wave)&&A.hp<A.max){A.hp++;heal=true}
 A.banner={t:2.0,max:2.0,big:'WAVE '+A.wave+' CLEAR',sub:heal?'You catch your breath: +1 heart':'Well fought!'};jingle('wave');if(heal)waFx(110,60,'#ff8aa0',18,{v:240,l:.8,s:5,g:-120});save()}
function waEnemyAnim(e,dt){if(e.st==='gone'){e.al=0;return}const A=S.wa,M=MON[e.id],sc=waSc(e);e.h0=M.th*sc;e.ph+=0;
 {let d=(e.tx-e.x)*Math.min(1,dt*(e.st==='enter'?4:6));const cap=760*dt;if(d>cap)d=cap;if(d<-cap)d=-cap;e.x+=d}e.fl=Math.max(0,e.fl-dt);e.kb=Math.max(0,e.kb-dt*5);
 let lgT=0,lxT=0,al=1,rot=0;
 if(e.st==='tele'&&e.hit){const H=e.hit,reach=waReach(e.id)*sc,dist=Math.max(0,e.x-reach-(WAT.SX+10)),ghost=false,rng=!!WAE[e.id].rng,lgOn=!ghost,lxHold=ghost?-14:rng?10:0;
  if(H.t<H.r){const u=sstep(0,1,H.t/H.r);lgT=lgOn?.55*u:0;lxT=lxHold*u}
  else if(H.t<H.r+H.h){lgT=lgOn?.55:0;const q=Math.sin(H.t*40)*(ghost||rng?0:1.5);lxT=lxHold+q;al=ghost?.38+.12*Math.sin(H.t*18):1}
  else{const u=Math.min(1,(H.t-H.r-H.h)/H.s),k=u*u*(3-2*u);lgT=lgOn?.55+.45*k:0;al=1;lxT=ghost?-14-(dist+40)*k:rng?10-18*k:-dist*k}
  if(H.done&&H.res==='feint'){lgT=.15;lxT=0}
  else if(H.done||H.pend){lgT=lgOn?1:0;lxT=ghost?-14-(dist+40):rng?-8:-dist;al=1}
  e.lgT=lgT;e.lxT=lxT}
 else if(e.st==='roar'){lgT=.5+.1*Math.sin(S.t*30);rot=-.05;lxT=8+Math.sin(S.t*58)*3}
 else if(e.st==='exp'){lgT=-.35;rot=.09;lxT=26;al=1}
 else if(e.st==='stun'){lgT=-.2;rot=-.05;lxT=14}
 else if(e.st==='rec'){lgT=0;lxT=0}
 else if(e.st==='dead'){e.tm+=dt;rot=Math.min(1.2,e.tm*2.2);lxT=40*Math.min(1,e.tm*3);al=Math.max(0,1-e.tm/.75)}
 else if(e.st==='enter'){lgT=0}
 /* ease toward the target: snappy while winding up, smooth otherwise */
 const fkb=e.hit&&e.hit.res==='feint',kLg=e.st==='tele'?(e.hit&&e.hit.t>=e.hit.r+e.hit.h&&!fkb?60:14):8,kLx=e.st==='tele'&&e.hit&&e.hit.t>=e.hit.r+e.hit.h&&!fkb?70:fkb?14:10;
 e.lg+=(lgT-e.lg)*Math.min(1,dt*kLg);{let d=(lxT-e.lx)*Math.min(1,dt*kLx);const cap=(kLx>=60?4200:1500)*dt;if(d>cap)d=cap;if(d<-cap)d=-cap;e.lx+=d}e.al+=(al-e.al)*Math.min(1,dt*14);e.rot+=(rot-e.rot)*Math.min(1,dt*(e.st==='dead'?10:9));
 if(e.st==='dead'&&e.tm>.75)e.al=0;
 if(e.st==='wait'&&e.slot>0){/* idle shuffle for the queue */}
}
/* ---------- finishing: rewards stay no matter what ---------- */
function waFixRS(){try{if(ST.res==='auto')applyLayout()}catch(e){}}
function waFinish(won){const A=S.wa;if(A.over)return;A.over=true;waFixRS();const w=waP(),id=A.br.id;w.runs++;w.perf=Math.max(w.perf||0,A.bestStreak);w.bs=(w.bs||0)+A.bursts;w.tut=(w.tut||0)+1;
 const nb=A.score>(w.best[id]||0);if(nb)w.best[id]=A.score;if(won)w.cl[id]=(w.cl[id]||0)+1;
 /* the first win of the day pays a little extra */
 let daily=0;if(won){const d=new Date().toDateString();if(w.fw!==d){w.fw=d;const c0=A.coins;waCoin(40,'daily');daily=A.coins-c0}}
 const tr=waTrophies(A,won);A.trophy=tr;save();waResult(won,nb,tr.opened.length?tr.opened[tr.opened.length-1]:0,daily)}
function waQuit(){const A=S.wa;if(!A)return;waFixRS();if(!A.over){A.over=true;const w=waP();w.runs++;save()}S.wa=null;S.mode='title';title()}
