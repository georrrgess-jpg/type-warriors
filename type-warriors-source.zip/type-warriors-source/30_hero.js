/* ---------- hero (feet at origin, facing right, ~135 units tall) ---------- */
function drawHero(g,o){
 const xid=o.arm||'rags',A=AR[xid]||AR.rags,K=kitOf(xid,A),t=o.t||0,lg=o.lg||0,pv=o.pose==='victory'?(o.pu||0):0,pd=o.pose==='dead'?(o.pu||0):0,hc=hcOf(o.col||0),br=Math.sin(t*2.4)*1.4,S7=(o.walk?Math.sin(t*8)*7:Math.sin(t*1.8)*1.2),cw=Math.sin(t*3)*5+lg*-8,my=A.mythic||0;
 let M=A.m,D=A.dk,T=A.tr;
 if(my===1){M=hsx(t*50,55,80);D=hsx(t*50+50,50,42);T='#ffffff'}
 {const dy=o.dye!==undefined?o.dye:(typeof P!=='undefined'&&P&&P.dye)||0;if(dy&&!my){T=mixc(T,hc,dy>1?.55:.75);if(dy>1){M=mixc(M,hc,.5);D=mixc(D,hc,.42)}}}
 const c={M,D,T,hc,orbit:A.pr||0,acc:A.acc||T,tier:A.tier!==undefined?A.tier:(K.tier||0),t,my,br,cw,lg,S7};
 const pth=o.wp?WP[o.wp].p:'knight',hx=3,hy=-112+br*.4;OL=1.3;
 g.save();g.lineJoin='round';g.lineCap='round';
 arFxBack(g,K,c,hx,hy);arAura(g,K,c,0,hx,hy);
 if(pth==='archer'){g.save();g.translate(-18,-78);g.rotate(-.5);g.fillStyle=vgr(g,-4,26,'#6a4420','#3a2210');g.beginPath();g.roundRect(-6,0,13,32,3);g.fill();g.strokeStyle='#c8a050';g.lineWidth=1.6;g.stroke();for(let i=0;i<3;i++){g.strokeStyle='#e8d6a8';g.lineWidth=1.4;g.beginPath();g.moveTo(-3+i*4,0);g.lineTo(-4+i*4.5,-16);g.stroke();poly(g,[-3+i*4.5-3,-14,-4+i*4.5,-22,-3+i*4.5+3,-14],['#e8455a','#fff','#e8455a'][i])}g.restore()}
 if(pth==='mage'){for(let i=0;i<3;i++){const a=t*1.4+i*TAU/3,x=Math.cos(a)*30-4,y=-96+Math.sin(a)*8-i*3;glow(g,x,y,9,'#c86bff88');g.strokeStyle='#e8c8ff';g.lineWidth=1.3;g.beginPath();g.arc(x,y,3.2,0,TAU);g.moveTo(x-2,y);g.lineTo(x+2,y);g.stroke()}}
 arCape(g,K,c);
 arCrestBack(g,K,c,hx,hy);
 arLeg(g,K,c,-6,-10,-16+S7,0);arLeg(g,K,c,8,14,20-S7,1);
 /* back arm */
 {const bx=-24+pv*12,by=-64-pv*72;arArm(g,K,c,-14,-92-br*.3,bx,by,0);arHand(g,K,c,bx,by,0)}
 /* torso, belt, skirt */
 g.save();g.translate(0,br*.4);arTorso(g,K,c);arEmblem(g,K,c,br);arSkirt(g,K,c);arBelt(g,K,c);g.restore();
 if(pth==='rogue'){g.save();g.translate(0,br*.4);g.fillStyle='#b3243d';g.beginPath();g.moveTo(-4,-101);g.lineTo(14,-99);g.lineTo(16,-93);g.lineTo(-4,-95);g.closePath();g.fill();g.beginPath();g.moveTo(-3,-98);g.quadraticCurveTo(-24-cw,-96,-34-cw*1.5,-80+Math.sin(t*5)*4);g.lineTo(-28-cw,-76+Math.sin(t*5)*4);g.quadraticCurveTo(-18,-90,-2,-93);g.fill();g.strokeStyle='#6a0a1a';g.lineWidth=1;g.beginPath();g.moveTo(-4,-98);g.lineTo(15,-96);g.stroke();g.restore()}
 g.fillStyle='#00000040';g.beginPath();g.ellipse(hx+1,hy+17+br*.4,14,5.4,0,0,TAU);g.fill();
 /* neck, gorget, head */
 g.fillStyle=vgr(g,hy+8,hy+19,'#d8b088','#a87a58');g.fillRect(-1,hy+8,10,11);
 g.save();g.translate(0,br*.4);arGorget(g,K,c);g.restore();
 arHead(g,K,c,hx,hy);
 /* shoulders and front arm / weapon */
 g.fillStyle='#00000040';g.beginPath();g.ellipse(-14,-82+br*.4,12.5,8,0,0,TAU);g.fill();
 arPauld(g,K,c,-15,-92+br*.4,0);
 const sx=17,sy=-92+br*.4,hx2=30+lg*20-pv*2+pd*4+(o.wp&&WP[o.wp].t==='bow'?15:0),hy2=-66-lg*30-pv*82+pd*14+br*.3;
 arArm(g,K,c,sx,sy,hx2,hy2,1);
 g.save();g.translate(hx2,hy2);const wt=o.wp?WP[o.wp].t:'sword',base={bow:-1.55,staff:-1.32,wand:-1.05,katana:-1.2,scythe:-1.25}[wt]||-1.15,sw=wt==='bow'?.22:wt==='staff'?1.1:wt==='wand'?1.5:2.1;g.rotate(base+lg*sw+Math.sin(t*2)*.03-pv*(.3-Math.sin(t*7)*.12)+pd*1.2);if(o.wp)drawW(g,o.wp,70,t);g.restore();
 arHand(g,K,c,hx2,hy2,1);
 g.fillStyle='#00000040';g.beginPath();g.ellipse(19,-82+br*.4,12.5,8,0,0,TAU);g.fill();
 arPauld(g,K,c,19,-92+br*.4,1);
 OL=0;
 arAura(g,K,c,1,hx,hy);arFx(g,K,c);
 g.restore()}


/* ---------- icons, previews, portraits ---------- */
function art(cvs,k,id,t){const g=cvs.getContext('2d'),w=cvs.width,h=cvs.height,it=(k==='w'?WP:AR)[id];g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,w,h);
 const gl=g.createRadialGradient(w/2,h*.55,2,w/2,h*.55,w*.5);gl.addColorStop(0,it.col+'66');gl.addColorStop(1,it.col+'00');g.fillStyle=gl;g.fillRect(0,0,w,h);
 if(k==='w'){let ty=it.t,Q={bow:[.52,.5,.74,-1.05],staff:[.3,.9,.66,-.95],wand:[.2,.84,.92,-.9],katana:[.2,.84,.86,-.9],axe:[.16,.86,.74,-.9],scythe:[.3,.86,.8,-.9],spear:[.2,.84,.84,-.9]}[ty]||[.2,.82,1,-.9];if(id==='ast_orbit')Q=[.22,.79,.8,-.6];if(id==='ast_cleaver')Q=[.24,.76,.6,-.9];g.save();g.translate(w*Q[0],h*Q[1]);g.rotate(Q[3]);const s=Math.min(w,h)/78*Q[2];g.scale(s,s);drawW(g,id,84,t||0);g.restore()}
 else{g.save();g.translate(w/2,h-3);const s=Math.min(w/76,h/164);g.scale(s,s);drawHero(g,{arm:id,wp:null,col:P&&P.col||0,t:t||0});g.restore()}}
function heroView(cvs,o,live){const g=cvs.getContext('2d');return t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,cvs.width,cvs.height);const w=cvs.width,h=cvs.height;
 const wp=WP[o.wp||P.weapon];g.fillStyle='#0000';glow(g,w/2,h*.55,w*.6,wp.col+'44');
 g.save();g.translate(w*.45,h-8);const s=o.scale||Math.min(w/120,h/165);g.scale(s,s);drawHero(g,{arm:o.arm||P.armor,wp:o.wp||P.weapon,col:P.col,t});g.restore()}}
function portraitView(cvs){const g=cvs.getContext('2d');return t=>{const w=cvs.width,h=cvs.height;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,w,h);g.save();g.translate(w*.42,h*1.02);const s=w/64;g.scale(s,s);g.translate(0,58);drawHero(g,{arm:P.armor,wp:null,col:P.col,t});g.restore()}}

/* ---------- chest for crate opening ---------- */
function chest(g,x,y,s,u,k,t){ /* u = lid open 0..1, k='w'|'a' */
 const wood=k==='p'?'#1c1430':k==='a'?'#4a5468':k==='s'?'#5a2a7a':'#7a4a24',wd2=k==='p'?'#0a0616':k==='a'?'#2c3444':k==='s'?'#2e1244':'#4e2e14',band=k==='p'?'#ffd76a':k==='a'?'#8ea0c0':k==='s'?'#ffd76a':'#e0b040',bd2=k==='p'?'#a8701a':k==='a'?'#4a5a78':k==='s'?'#a8701a':'#8a6218';
 g.save();g.translate(x,y);g.scale(s,s);
 g.fillStyle='#0006';g.beginPath();g.ellipse(0,4,86,14,0,0,TAU);g.fill();if(k==='p'){glow(g,0,-44,150+Math.sin(t*2)*12,hsx(t*50,90,60)+'55');g.save();g.translate(0,-44);for(let i=0;i<8;i++){const a=t*.8+i*TAU/8,c=hsx(t*60+i*45,100,70);g.globalAlpha=.85;glow(g,Math.cos(a)*105,Math.sin(a)*38,10,c+'cc');ell(g,Math.cos(a)*105,Math.sin(a)*38,2.4,2.4,'#fff')}g.restore()}if(k==='s'){glow(g,0,-40,110+Math.sin(t*3)*10,'#d060ff66');for(let i=0;i<5;i++){const u=(t*.5+i/5)%1;g.fillStyle='#fff';g.globalAlpha=1-u;g.fillRect(-60+i*30,-20-u*90,3,3)}g.globalAlpha=1}
 const lidUp=u>0;
 if(lidUp){glow(g,0,-62,120*u+40,'#fff2b0'+Math.round(Math.min(255,u*255)).toString(16).padStart(2,'0'))}
 // body
 g.fillStyle=vgr(g,-70,0,wood,wd2);g.beginPath();g.roundRect(-70,-70,140,70,8);g.fill();
 g.strokeStyle=wd2;g.lineWidth=2;for(let i=1;i<4;i++){g.beginPath();g.moveTo(-70,-70+i*17.5);g.lineTo(70,-70+i*17.5);g.stroke()}
 if(lidUp){g.fillStyle='#fff6c8';g.beginPath();g.roundRect(-62,-70,124,10,4);g.fill()}
 if(k==='p'){g.strokeStyle='#ffd76acc';g.lineWidth=2;for(const sg of[-1,1]){g.beginPath();g.moveTo(sg*8,-64);g.bezierCurveTo(sg*34,-64,sg*36,-40,sg*20,-34);g.bezierCurveTo(sg*8,-30,sg*12,-16,sg*30,-14);g.stroke()}g.fillStyle='#ffd76a';g.beginPath();g.arc(0,-38,16,Math.PI*.3,Math.PI*1.7);g.arc(6,-38,12.5,Math.PI*1.62,Math.PI*.38,true);g.closePath();g.fill();glow(g,0,-38,26,'#ffd76a55')}
 for(const bx of[-52,52]){g.fillStyle=band;g.fillRect(bx-9,-70,18,70);g.fillStyle=bd2;g.fillRect(bx-9,-70,4,70);for(const yy of[-60,-10]){ell(g,bx,yy,3,3,bd2)}}
 // lid
 const ang=u*Math.PI*.58,ch=Math.cos(ang),lh=44;
 g.save();
 if(ang<Math.PI/2){const hh=Math.max(4,lh*ch),topH=lh*Math.sin(ang)*.55;
  g.fillStyle=vgr(g,-70-hh,-70,shade(wood,.15),wood);g.beginPath();g.moveTo(-70,-70);g.lineTo(-70,-70-hh-(u>0?topH*0:0));g.quadraticCurveTo(0,-70-hh-lh*.55*(1-ch*.4),70,-70-hh);g.lineTo(70,-70);g.closePath();g.fill();
  for(const bx of[-52,52]){g.fillStyle=band;g.beginPath();g.moveTo(bx-9,-70);g.lineTo(bx-9,-70-hh+ (Math.abs(bx)>0?2:0));g.quadraticCurveTo(bx,-70-hh-8,bx+9,-70-hh+2);g.lineTo(bx+9,-70);g.closePath();g.fill()}
  if(u<.05){g.fillStyle=band;g.beginPath();g.roundRect(-11,-84,22,28,4);g.fill();g.fillStyle=bd2;g.beginPath();g.arc(0,-74,4,0,TAU);g.fill();g.fillRect(-1.6,-74,3.2,10);if(k==='p'){const gc=hsx(t*90,100,66);glow(g,0,-72,30,gc+'aa');poly(g,[0,-88,9,-76,0,-62,-9,-76],gc,'#fff',1.4)}}}
 else{const hh=lh*(-ch)+8;g.fillStyle=vgr(g,-70-hh-30,-70,wd2,'#2a1608');g.beginPath();g.moveTo(-64,-72);g.lineTo(-58,-72-hh-20);g.lineTo(58,-72-hh-20);g.lineTo(64,-72);g.closePath();g.fill();g.strokeStyle=band;g.lineWidth=4;g.stroke()}
 g.restore();g.restore()}
function keyArt(g,x,y,r,s){g.save();g.translate(x,y);g.rotate(r);g.scale(s,s);g.shadowColor='#ffe08a';g.shadowBlur=14;g.fillStyle='#ffd76a';g.strokeStyle='#8a5a10';g.lineWidth=2;g.beginPath();g.arc(-26,0,13,0,TAU);g.arc(-26,0,6,0,TAU,true);g.fill('evenodd');g.stroke();g.fillRect(-14,-3.4,52,6.8);g.strokeRect(-14,-3.4,52,6.8);g.fillRect(26,3,7,12);g.fillRect(36,3,7,9);g.strokeRect(26,3,7,12);g.strokeRect(36,3,7,9);g.restore()}
function projArt(g,j,t){const x=j.x,y=j.y;switch(j.k){
 case 'arrow':limb(g,x-22,y,x+22,y,3,'#8a6a4a');poly(g,[x-22,y,x-30,y-6,x-26,y,x-30,y+6],'#fff');poly(g,[x-16,y-3,x-24,y-9,x-20,y-3],'#e8455a');break;
 case 'bone':g.save();g.translate(x,y);g.rotate(t*12);limb(g,-14,0,14,0,5,'#e8e2cc');ell(g,-15,-3,4,4,'#e8e2cc');ell(g,-15,3,4,4,'#e8e2cc');ell(g,15,-3,4,4,'#e8e2cc');ell(g,15,3,4,4,'#e8e2cc');g.restore();break;
 case 'venom':glow(g,x,y,26,'#9aff4a88');ell(g,x,y,11,9,'#7ad83a');ell(g,x-3,y-3,4,3,'#d8ff9a');for(let i=1;i<4;i++)ell(g,x+i*10,y+Math.sin(t*10+i)*3,5-i,5-i,'#7ad83a88');break;
 case 'fire':glow(g,x,y,34,'#ff7a1acc');ell(g,x,y,12,10,'#ff5a1a');ell(g,x-2,y,7,6,'#ffcf5a');for(let i=1;i<5;i++)ell(g,x+i*9,y+Math.sin(t*12+i)*3,7-i,6-i,`rgba(255,${120+i*25},40,.7)`);break;
 case 'ice':glow(g,x,y,24,'#9fe8ff99');poly(g,[x-20,y,x+8,y-6,x+16,y,x+8,y+6],'#dff6ff','#7fd8ff',2);break;
 case 'bubble':glow(g,x,y,22,'#8ff8e099');g.strokeStyle='#dfffff';g.lineWidth=2.4;g.beginPath();g.arc(x,y,11,0,TAU);g.stroke();ell(g,x-4,y-4,3,2,'#fff');break;
 case 'orb':{const c=j.c||'#c86bff';glow(g,x,y,50,c+'aa');for(let i=1;i<6;i++){g.globalAlpha=.55/i;ell(g,x+i*13,y+Math.sin(t*14+i)*3,15-i*2,15-i*2,c)}g.globalAlpha=1;ell(g,x,y,15,15,c);ell(g,x-3,y-3,8,8,'#fff');g.strokeStyle='#fff9';g.lineWidth=2;g.beginPath();g.arc(x,y,23,t*8,t*8+2.2);g.stroke();break}
  case 'wave':{const c=j.c||'#ff8a3a';glow(g,x,y-40,100,c+'77');g.fillStyle=c;g.beginPath();g.moveTo(x+26,y);g.quadraticCurveTo(x-8,y-50-Math.sin(t*12)*6,x-30,y-112);g.quadraticCurveTo(x-2,y-56,x-46,y);g.closePath();g.fill();g.fillStyle='#ffffffcc';g.beginPath();g.moveTo(x+10,y);g.quadraticCurveTo(x-6,y-40,x-16,y-80);g.quadraticCurveTo(x-2,y-40,x-22,y);g.closePath();g.fill();for(let i=0;i<4;i++)ell(g,x+20+i*18,y-3,10-i*2,4,c+'88');break}
  case 'meteor':{const c=j.c||'#ff7a1a',a=Math.atan2(j.vy||100,-j.v);glow(g,x,y,62,c+'aa');for(let i=1;i<7;i++){g.globalAlpha=.6/i;ell(g,x-Math.cos(a)*i*16,y-Math.sin(a)*i*16,17-i*2,17-i*2,c)}g.globalAlpha=1;ell(g,x,y,17,17,'#3a1a10');ell(g,x-2,y-2,11,11,c);ell(g,x-4,y-4,5,5,'#fff');break}
  case 'web':glow(g,x,y,28,'#e8f4ffaa');g.strokeStyle='#f4faff';g.lineWidth=2;g.beginPath();for(let i=0;i<8;i++){const a=i*TAU/8+t*3;g.moveTo(x,y);g.lineTo(x+Math.cos(a)*15,y+Math.sin(a)*15)}g.stroke();for(const r of[6,11,15]){g.beginPath();g.arc(x,y,r,0,TAU);g.stroke()}break;
  default:ell(g,x,y,10,10,'#ff5c6c')}}
