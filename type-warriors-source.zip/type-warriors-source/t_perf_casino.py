import asyncio,os,sys
from playwright.async_api import async_playwright
# Performance mode must leave every Casino screen exactly as in Quality, and still apply everywhere else.
PROBE="""async()=>{const f0=liveN;let fr=0;await new Promise(r=>{const t0=performance.now();const s=()=>{fr++;if(performance.now()-t0<1500)requestAnimationFrame(s);else r()};requestAnimationFrame(s)});const lv=liveN-f0;
 await new Promise(r=>setTimeout(r,1400));
 const g=document.createElement('canvas').getContext('2d');g.shadowBlur=12;
 const an=document.getAnimations().filter(a=>a.effect&&a.effect.getTiming().iterations===Infinity&&a.constructor.name==='CSSAnimation');
 return {cas:pfCas(),low:document.body.classList.contains('pf-low'),bal:document.body.classList.contains('pf-bal'),RS,cvw:cv.width,blur:g.shadowBlur,
  live:Math.round(lv/fr*100)/100,loops:an.length,paused:an.filter(a=>a.playState==='paused').length,wcRM:typeof wcRM==='function'?wcRM():null,
  bd:(()=>{const d=document.createElement('div');d.style.backdropFilter='blur(4px)';ov.appendChild(d);const v=getComputedStyle(d).backdropFilter;d.remove();return v})()}}"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900},device_scale_factor=1.5);er=[];bad=0
        pg.on('pageerror',lambda e:er.append('PE '+str(e)[:300]))
        await pg.goto('file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else 'out.html'));await pg.wait_for_timeout(1200);E=pg.evaluate
        def chk(n,v,ok):
            nonlocal bad;bad+=0 if ok else 1;print(n,v,'OK' if ok else 'FAIL')
        await E("()=>{RS_ASK=false;ST.perf='high';saveST();applyLayout();title()}");q=await E(PROBE);full=q['RS'];print('quality title',q);LQ=q['live']
        await E("()=>{casinoOpen()}");qc=await E(PROBE);print('quality casino',qc)
        for mode in ('low','bal'):
            await E(f"()=>{{casinoBack();ST.perf='{mode}';saveST();applyLayout();title()}}");o=await E(PROBE)
            if mode=='low':chk('low outside casino is lighter',o,o['low'] and o['RS']==.75 and o['blur']==0 and o['live']<.7*LQ and o['paused']==o['loops'] and o['bd']=='none')
            else:chk('bal outside casino',o,o['bal'] and o['RS']==1)
            await E("()=>casinoOpen()");c=await E(PROBE)
            chk(mode+' casino lobby = quality',c,c['cas'] and not c['low'] and not c['bal'] and c['RS']==full and c['blur']==12 and c['live']>.85*LQ and c['loops']>0 and c['paused']==0 and c['bd']!='none')
            await E("()=>gameOpen('wc')");w=await E(PROBE)
            chk(mode+' wildcard home = quality',w,w['cas'] and not w['low'] and w['RS']==full and w['blur']==12 and w['live']>.85*LQ and w['paused']==0 and w['wcRM']==False)
            await E("()=>{P.gold=5000;wcStartSolo()}");await pg.wait_for_timeout(600);t=await E(PROBE)
            chk(mode+' wildcard table = quality',t,t['cas'] and not t['low'] and t['wcRM']==False and t['paused']==0)
            await E("()=>{WX.tok++;wcClear&&wcClear();casinoOpen();gameOpen(GAMES.find(g=>g.id!=='wc').id)}");g=await E(PROBE)
            chk(mode+' a casino game = quality ('+await E("()=>GAMES.find(g=>g.id!=='wc').id")+')',g,g['cas'] and not g['low'] and g['blur']==12 and g['paused']==0)
        await E("()=>{casinoOpen();casinoBack()}");o=await E(PROBE)
        chk('leaving the casino restores Balanced',o,o['bal'] and not o['cas'] and o['RS']==1)
        await E("()=>{ST.perf='low';saveST();applyLayout();casinoOpen();settings()}");s=await E("()=>[pfCas(),document.body.classList.contains('pf-low'),(document.querySelector('#pfopt small')||{}).textContent,(document.querySelector('#pfopt .on')||{}).textContent]")
        chk('settings over the casino use the saved choice',s,s[0]==False and s[1] and 'Casino keeps' in s[2] and s[3]=='Performance')
        print('bad',bad);print(er[:5]);await b.close()
asyncio.run(main())
