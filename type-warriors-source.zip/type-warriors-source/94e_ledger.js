/* ===== 8.7 GOLD LEDGER (94e) =====
   Every change of P.gold is written as {t, d, bal, src} into a ring of the last 100 (P.ldg), and added to today's totals per source
   (P.ldgDay = {day, inc:{src:coins}, out:{src:coins}}). It is how the coins-per-minute bands of the economy plan get checked.
   How it works: P.gold becomes an accessor property (enumerable, so JSON.stringify and Object.assign still see one plain number).
   The value lives in a closure per P object. load() builds a new P every time, so load() and save() are wrapped to put the accessor
   back (ldgInstall is idempotent). The accessor is installed only after load() has finished, so loading itself records nothing.
   src is S.mode plus a label set with ukSrc('label') or ukSrc('label', fn) around a known grant, else the current screen (S.view).
   ledgerToday() gives today's totals, ledgerRecent(n) the last n entries, newest first. No visible UI in 8.7; a DEV button prints them. */
const LDG={max:100,srcMax:40,lab:'',clr:0,on:0};
function ukSrc(label,fn){
 if(typeof fn==='function'){const p=LDG.lab;LDG.lab=label?String(label).slice(0,24):'';try{return fn()}finally{LDG.lab=p}}
 LDG.lab=label?String(label).slice(0,24):'';
 if(LDG.lab&&!LDG.clr){LDG.clr=1;Promise.resolve().then(()=>{LDG.lab='';LDG.clr=0})}}
function ldgSrcNow(){let s='app';try{const m=S&&typeof S.mode==='string'?S.mode:'';if(m)s=m;
 if(LDG.lab)return(s+':'+LDG.lab).slice(0,40);
 let v='';try{if(typeof NAV!=='undefined'&&NAV)v=typeof NAV.key==='string'?NAV.key:typeof NAV.name==='string'?NAV.name:''}catch(e){}
 if(!v&&S&&typeof S.view==='string')v=S.view;
 if(v&&v!=='menu'&&v!==m)s+=':'+v}catch(e){}return s.slice(0,40)}
/* make the stored ring and totals safe whatever the save held */
function ldgPrep(p){const a=Array.isArray(p.ldg)?p.ldg:[],o=[];
 for(const e of a){if(!e||typeof e!=='object'||typeof e.src!=='string')continue;const d=+e.d,b=+e.bal;if(!isFinite(d)||!isFinite(b))continue;o.push({t:isFinite(+e.t)?+e.t:0,d,bal:b,src:e.src.slice(0,40)})}
 p.ldg=o.length>LDG.max?o.slice(-LDG.max):o;
 let D=p.ldgDay;if(!D||typeof D!=='object'||Array.isArray(D)||typeof D.day!=='string')D={day:'',inc:{},out:{}};
 for(const k of['inc','out']){const m=D[k],n={};let c=0;
  if(m&&typeof m==='object'&&!Array.isArray(m))for(const s of Object.keys(m)){const v=+m[s];if(SG_BAD.has(s)||!isFinite(v)||v<=0||c>=LDG.srcMax)continue;n[s.slice(0,40)]=v;c++}
  D[k]=n}
 D.day=D.day.slice(0,10);p.ldgDay=D}
function ldgRec(p,d,bal){if(!LDG.on||!p)return;if(!Array.isArray(p.ldg)||!p.ldgDay||typeof p.ldgDay!=='object')ldgPrep(p);
 d=Math.round(d*100)/100;if(!d)return;const src=ldgSrcNow(),a=p.ldg;a.push({t:Date.now(),d,bal:Math.round(bal*100)/100,src});if(a.length>LDG.max)a.splice(0,a.length-LDG.max);
 const day=wrDay();let D=p.ldgDay;if(D.day!==day)D=p.ldgDay={day,inc:{},out:{}};
 const m=d>0?D.inc:D.out;let k=src;if(!Object.prototype.hasOwnProperty.call(m,k)&&Object.keys(m).length>=LDG.srcMax)k='other';m[k]=(m[k]||0)+Math.abs(d)}
/* put the accessor on the current P (safe to call as often as you like) */
function ldgInstall(){const p=P;if(!p||typeof p!=='object')return false;
 try{const ds=Object.getOwnPropertyDescriptor(p,'gold');if(ds&&ds.get&&ds.get.ldg)return true;
  let v=ds?('value' in ds?ds.value:(ds.get?ds.get.call(p):0)):0;
  ldgPrep(p);
  const get=function(){return v};get.ldg=1;
  Object.defineProperty(p,'gold',{get,set(nv){const o=v;v=nv;if(nv!==o&&typeof nv==='number'&&typeof o==='number'&&isFinite(nv)&&isFinite(o)){try{ldgRec(p,nv-o,nv)}catch(e){}}},enumerable:true,configurable:true});
  return true}catch(e){console.error(e);return false}}
{const l0=load;load=function(){const r=l0.apply(this,arguments);ldgInstall();return r}}
{const s0=save;save=function(){ldgInstall();return s0.apply(this,arguments)}}
function ledgerToday(){ldgInstall();const D=P&&P.ldgDay,day=wrDay(),cur=!!D&&D.day===day,e=cur?Object.assign({},D.inc):{},s=cur?Object.assign({},D.out):{},sum=o=>Object.keys(o).reduce((a,k)=>a+o[k],0);
 return{day,earned:e,spent:s,total:sum(e),out:sum(s),net:sum(e)-sum(s)}}
function ledgerRecent(n){ldgInstall();const a=P&&Array.isArray(P.ldg)?P.ldg:[];n=n==null?20:Math.max(0,Math.min(LDG.max,Math.floor(+n)||0));return n?a.slice(-n).reverse().map(e=>Object.assign({},e)):[]}
/* labels for the grants and spends we know about */
{const c0=calGrant;calGrant=function(){return ukSrc('calendar',()=>c0.apply(this,arguments))}}
{const c0=crateRoll;crateRoll=function(){return ukSrc('crate',()=>c0.apply(this,arguments))}}
{const g0=levelGold;levelGold=function(){return LDG.lab?g0.apply(this,arguments):ukSrc('levelup',()=>g0.apply(this,arguments))}}
{const b0=buyNode;buyNode=function(){return ukSrc('skill',()=>b0.apply(this,arguments))}}
{const r0=respec;respec=function(){return ukSrc('respec',()=>r0.apply(this,arguments))}}
/* DEV › Cheats: print today's totals and the last entries to the console */
try{const h0=dvxHTML;dvxHTML=function(){let h=h0.apply(this,arguments);try{const t=ledgerToday();h+=`<div class="dvx"><h5>Gold ledger</h5><div class="dvrow"><span>Today: ${Math.round(t.total).toLocaleString()} earned, ${Math.round(t.out).toLocaleString()} spent</span>${dvBtn('x:ldgday','Print today')}${dvBtn('x:ldgrec','Print last 30')}</div></div>`}catch(e){}return h};
 const a0=dvxAct;dvxAct=function(a){if(!/^ldg/.test(a))return a0.apply(this,arguments);
  if(a==='ldgday'){const t=ledgerToday();console.table(t.earned);dvxMsg(`Today ${Math.round(t.total).toLocaleString()} earned, ${Math.round(t.out).toLocaleString()} spent (see the console).`)}
  else if(a==='ldgrec'){console.table(ledgerRecent(30));dvxMsg('Last 30 gold changes are in the console.')}}}catch(e){}
ldgInstall();LDG.on=1;
try{ecMigrate()}catch(e){console.error(e)}
