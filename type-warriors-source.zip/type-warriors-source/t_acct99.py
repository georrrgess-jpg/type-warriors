# python3 t_acct99.py [game.html] : Accounts (97j) end to end against local Nostr relays (t_nostr_relay.py, started here and stopped
# by PID). Separate browser contexts stand for separate devices / web addresses (each has its own storage).
# Covers: crypto test vectors (SHA-256, HMAC, PBKDF2, ChaCha20), sign-up from the account window, the recovery code, a taken
# username, wrong password / unknown user, signing in on a second device (progress follows), automatic sync both ways, conflicts,
# password change (old one stops working, same account), recovery code sign-in, the backup file with every relay down, a large save
# in several chunks, a dead relay, no crypto.subtle (plain-http pages), a forged key box, start-up pull, sign out (keep / clear).
import asyncio,os,sys,subprocess,json,time
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
PYLIB=os.path.abspath(os.path.join(HERE,'../tools/pylib'))
A,B,DEAD=18151,18152,18159
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:600]),flush=True)
    if not ok:FAIL.append(name)
def start(port):
    os.makedirs(os.path.join(HERE,'../lbt'),exist_ok=True);log=open(os.path.join(HERE,f'../lbt/acrelay{port}.log'),'w')
    return subprocess.Popen([sys.executable,'t_nostr_relay.py',str(port)],cwd=HERE,env={**os.environ,'PYTHONPATH':PYLIB+':'+HERE},stdout=log,stderr=subprocess.STDOUT)
LIVE=[f'ws://127.0.0.1:{A}',f'ws://127.0.0.1:{B}']
async def device(br,relays=None,extra=''):
    ctx=await br.new_context(viewport={'width':1600,'height':900})
    await ctx.add_init_script('window.TWA_RELAYS=%s;window.TWA_ITER=2000;window.TWA_NORELOAD=1;window.TWA_NOSTART=!sessionStorage.getItem("twa_start");%s'%(json.dumps(relays if relays is not None else LIVE),extra))
    pg=await ctx.new_page();er=[];pg.on('pageerror',lambda e:er.append(str(e)[:300]));await pg.goto(H);await pg.wait_for_timeout(1500)
    await pg.evaluate("()=>{RS_ASK=false;WCRELAYS=[];try{ST.perfAsked=1}catch(e){}try{PFW.asked=true}catch(e){}}");return ctx,pg,er
async def ui(pg,tab,u,p,p2=None,extra=None):
    for _ in range(100):
        if not await pg.evaluate("()=>TWAU.busy||!!(TWA.st.q)"):break
        await pg.wait_for_timeout(150)
    await pg.wait_for_timeout(300)
    await pg.evaluate("(t)=>{twaClose();TWAU.tab=t;TWAU.msg='';twaForm()}",tab)
    await pg.fill('#twau',u);await pg.fill('#twap',p)
    if p2 is not None:await pg.fill('#twap2',p2)
    if extra:
        for k,v in extra.items():await pg.fill(k,v)
    await pg.click('#twago')
    for _ in range(120):
        await pg.wait_for_timeout(150);st=await pg.evaluate("()=>[TWAU.busy,($('twamsg')||{}).textContent||'',!!$('twacode'),!!$('twasync'),!!document.getElementById('svm')]")
        if not st[0] and (st[2] or st[3] or st[4] or ('bad' in (await pg.evaluate("()=>($('twamsg')||{className:''}).className")))):return st
    return st
async def main():
    procs=[start(A),start(B)];time.sleep(1.2)
    try:
        async with async_playwright() as p:
            br=await p.chromium.launch();allerr=[]
            c1,d1,e1=await device(br);allerr.append(e1)
            r=await d1.evaluate("""async()=>{const H=twaHex,T=s=>twaTE.encode(s);const k=new Uint8Array(32).map((_,i)=>i),n=twaUnhex('000000000000004a00000000');
              return [H(twaSha(T('abc')))==='ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad',
               H(twaHmac(new Uint8Array(20).fill(11),T('Hi There')))==='b0344c61d8db38535ca8afceaf0bf12b881dc200c9833da726e9376c2e32cff7',
               H(await twaPbkdf2JSa(T('password'),T('salt'),4096,32,1))==='c5e478d59288c841aa530db6845c4c8d962893a001ce4e11a4963873aa98134a',
               H(await twaPbkdf2(T('password'),T('salt'),4096,32))==='c5e478d59288c841aa530db6845c4c8d962893a001ce4e11a4963873aa98134a',
               H(twaChacha(k,n,T("Ladies and Gentlemen of the class of '99: If I could offer you only one tip for the future, sunscreen would be it."),1)).startsWith('6e2e359a2568f98041ba0728dd0d6981e97e7aec1d4360c20a27afccfd9fae0bf91b65c5524733ab8f593dabcd62b3571639d624e65152ab8f530c359f0861d8'),
               TWA.iter>=250000]}""")
            chk('crypto: SHA-256, HMAC, PBKDF2 (JS and browser) and ChaCha20 match the published test vectors; 250,000 PBKDF2 rounds',all(r),r)
            r=await d1.evaluate("()=>{const c=$('twachip');return c?[c.className,c.textContent]:null}")
            chk('a guest sees a "Sign in" chip on the home screen',r and r[0]=='out' and 'Sign in' in r[1],r)
            await d1.screenshot(path=os.path.join(HERE,'shots','acct_home.png'))
            # ---- sign up on device 1 with some progress
            await d1.evaluate("()=>{P.xp=lvx(12);P.gold=4321;P.runs=7;P.name='Hero';save()}")
            await d1.evaluate("()=>{twaClose();TWAU.tab='up';twaForm()}");await d1.fill('#twau','Seth_42');await d1.fill('#twap','correct horse 1');await d1.fill('#twap2','correct horse 1');await d1.screenshot(path=os.path.join(HERE,'shots','acct_signup.png'))
            await d1.click('#twago')
            for _ in range(100):
                await d1.wait_for_timeout(150)
                if await d1.evaluate("()=>!!$('twacode')"):break
            r=await d1.evaluate("()=>{const s=twaLoadSes();return [!!$('twacode'),$('twagood').disabled,s&&s.u,s&&s.d,s&&s.rev,P.name,$('twacode').textContent.split('-').length]}")
            chk('sign-up: the recovery code shows (Continue waits for "I have saved it"), the save is uploaded (rev 1), the hero takes the username',r[0] and r[1] and r[2]=='seth_42' and r[3]=='Seth_42' and r[4]==1 and r[5]=='Seth_42' and r[6]==11,r)
            await d1.screenshot(path=os.path.join(HERE,'shots','acct_code.png'))
            code=await d1.evaluate("()=>$('twacode').textContent")
            await d1.check('#twaok');await d1.click('#twagood');await d1.wait_for_timeout(300)
            r=await d1.evaluate("()=>[!!$('twasync'),$('twachip').className,$('twachip').textContent]")
            chk('the account panel opens; the chip shows the account and "Synced"',r[0] and r[1]=='on' and 'Seth_42' in r[2] and 'Synced' in r[2],r)
            await d1.screenshot(path=os.path.join(HERE,'shots','acct_panel.png'))
            # ---- device 2: taken name, wrong password, unknown user, then sign in
            c2,d2,e2=await device(br);allerr.append(e2)
            st=await ui(d2,'up','seth_42','other password','other password')
            chk('creating an account with a taken username (any capitalisation) is refused',"taken" in st[1],st)
            st=await ui(d2,'in','Seth_42','wrong password')
            chk('a wrong password is refused with a clear message',"Wrong password" in st[1],st)
            st=await ui(d2,'in','nobody_here','whatever123')
            chk('an unknown username says no account was found',"No account" in st[1],st)
            await d2.evaluate("()=>{P.xp=0;P.runs=0;save()}")
            st=await ui(d2,'in','SETH_42','correct horse 1')
            r=await d2.evaluate("()=>[lvl(P.xp),P.gold,P.name,twaLoadSes()&&twaLoadSes().rev]")
            chk('signing in on another device (another web address) brings the progress over',r[:3]==[12,4321,'Seth_42'] and r[3]>=1,r)
            # ---- sync both ways
            await d1.evaluate("()=>{P.gold=5000;save()}");r1=await d1.evaluate("async()=>[await twaPush(false),twaLoadSes().rev]")
            r2=await d2.evaluate("async()=>[await twaPull(),P.gold,twaLoadSes().rev]")
            chk('a change on device 1 is uploaded and device 2 picks it up by itself (same revision on both)',r1[0]=='ok' and r2[:2]==['loaded',5000] and r2[2]==r1[1],[r1,r2])
            r=await d1.evaluate("async()=>await twaPush(false)")
            chk('nothing is uploaded when nothing changed',r=='same',r)
            # ---- conflict: both played
            await d1.evaluate("()=>{P.gold=6000;save()}");await d1.evaluate("async()=>twaPush(false)")
            await d2.evaluate("()=>{P.gold=7000;save()}");r=await d2.evaluate("async()=>await twaPush(false)")
            chk('when another device uploaded newer progress, an upload stops instead of overwriting it',r=='conflict',r)
            await d2.evaluate("()=>{twaPull('test')}");await d2.wait_for_timeout(1500)
            r=await d2.evaluate("()=>{const m=document.getElementById('svm');return m?m.textContent:''}")
            await d2.screenshot(path=os.path.join(HERE,'shots','acct_conflict.png'))
            chk('the player is asked which progress to keep, with both side by side',"Which progress" in r and 'Use my account save' in r and 'Keep this device' in r,r[:200])
            await d2.evaluate("()=>{[...document.querySelectorAll('#svm button')].find(b=>/Keep this device/.test(b.textContent)).click()}");await d2.wait_for_timeout(1500)
            r=await d2.evaluate("()=>[P.gold,TWA.st.conflict]")
            r1=await d1.evaluate("async()=>[await twaPull(),P.gold]")
            chk('"Keep this device" uploads it as the account save, and device 1 then gets it',r==[7000,None] and r1==['loaded',7000],[r,r1])
            # ---- password change
            pk=await d1.evaluate("()=>twaLoadSes().pk")
            r=await d1.evaluate("async()=>[await twaChangePw('nope nope','new secret 22'),await twaChangePw('correct horse 1','new secret 22')]")
            chk('changing the password needs the current one',('err' in r[0]) and r[1]=={'ok':1},r)
            c3,d3,e3=await device(br);allerr.append(e3)
            st=await ui(d3,'in','seth_42','correct horse 1')
            chk('after a password change the old password no longer works',"Wrong password" in st[1],st)
            st=await ui(d3,'in','seth_42','new secret 22')
            r=await d3.evaluate("()=>[twaLoadSes().pk,P.gold]")
            chk('the new password works, and it is the same account (same key, same progress)',r==[pk,7000],r)
            # ---- recovery code
            c4,d4,e4=await device(br);allerr.append(e4)
            st=await ui(d4,'rec','seth_42','fresh pass 33','fresh pass 33',{'#twac':code.lower().replace('-',' ')})
            r=await d4.evaluate("()=>[twaLoadSes()&&twaLoadSes().pk,P.gold]")
            chk('the recovery code (typed any way) opens the account and sets a new password',r==[pk,7000],[st,r])
            st=await ui(d4,'rec','seth_42','fresh pass 34','fresh pass 34',{'#twac':code[:2]+('0' if code[2]!='0' else '1')+code[3:]})
            chk('a mistyped recovery code is caught by its checksum',"not right" in st[1],st)
            # ---- forged key box for the same name
            r=await d4.evaluate("""async()=>{const M=twaRand(32),K=twaAcctKeys(M),pw=await twaPwKeys('seth_42','attacker pw 1');const ev=await twaBoxEvent(K,M,pw,'seth_42','Seth_42');return await twaSend([ev])}""")
            c5,d5,e5=await device(br);allerr.append(e5)
            st=await ui(d5,'in','seth_42','fresh pass 33')
            r=await d5.evaluate("()=>[twaLoadSes()&&twaLoadSes().pk,P.gold]")
            chk('a second, forged key box for the same username does not stop the owner signing in',r==[pk,7000],[st,r])
            # ---- big save in chunks, a dead relay
            r=await d5.evaluate("""async()=>{P.junk=Array.from({length:12000},(_,i)=>'entry'+i+'_'+Math.random().toString(36).slice(2,9));save();const res=await twaPush(true);const K=twaKeysOf(twaLoadSes());const m=(await twaManifest(K)).m;const sv=await twaFetchSave(K,m);
              const back=JSON.parse(JSON.parse(sv.txt).payload);return [res,m.n,JSON.stringify(P).length,back.junk.length,back.junk[11999]===P.junk[11999]]}""")
            chk('a large save (about 200 KB) goes up in several chunks and comes back intact',r[0]=='ok' and r[1]>=2 and r[3]==12000 and r[4],r)
            await d5.evaluate("()=>{delete P.junk;save()}")
            c6,d6,e6=await device(br,[f'ws://127.0.0.1:{DEAD}',LIVE[1]]);allerr.append(e6)
            st=await ui(d6,'in','seth_42','fresh pass 33')
            r=await d6.evaluate("()=>[!!twaLoadSes(),TWA.st.relays]")
            chk('with one account server down, signing in still works from the others',r==[True,1],[st,r])
            # ---- backup file with every relay down
            bk=await d5.evaluate("async()=>{P.gold=8888;save();await twaPush(true);return await twaBackupFile()}")
            c7,d7,e7=await device(br,[f'ws://127.0.0.1:{DEAD}']);allerr.append(e7)
            st=await ui(d7,'in','seth_42','fresh pass 33')
            chk('with every account server blocked, sign-in says so and points to the backup file',"could not be reached" in st[1] and "backup" in st[1],st)
            fp=os.path.join(HERE,'..','lbt','acct_backup.json');open(fp,'w').write(bk)
            await d7.evaluate("()=>{twaClose();TWAU.tab='file';twaForm()}");await d7.set_input_files('#twafile',fp);await d7.fill('#twau','Seth_42');await d7.fill('#twap','fresh pass 33');await d7.click('#twago');await d7.wait_for_timeout(2500)
            r=await d7.evaluate("()=>[P.gold,!!twaLoadSes()]")
            chk('the account backup file restores account and progress with no account server at all',r==[8888,True],r)
            await d7.evaluate("()=>{twaClose();TWAU.tab='file';twaForm()}");await d7.set_input_files('#twafile',fp);await d7.fill('#twau','Seth_42');await d7.fill('#twap','bad password 1');await d7.click('#twago');await d7.wait_for_timeout(1500)
            r=await d7.evaluate("()=>($('twamsg')||{}).textContent")
            chk('the backup file needs the right password',"Wrong password" in (r or ''),r)
            # ---- no crypto.subtle (a plain-http address): same keys, leaderboard signing still works
            c8,d8,e8=await device(br,None,'window.TWA_NOSUBTLE=1;');allerr.append(e8)
            st=await ui(d8,'in','seth_42','fresh pass 33')
            r=await d8.evaluate("async()=>{const K={d:5n,pk:wcHx(wcN2b(wcMul(5n)[0]))};const ev=await rkEvSign(K,30078,[['d','x']],'hi');return [twaLoadSes()&&twaLoadSes().pk,P.gold,await rkEvOk(ev)]}")
            chk('without crypto.subtle (plain http) sign-in gives the same account, and leaderboard signing still works',r==[pk,8888,True],[st,r])
            # ---- start-up pull on a signed-in device
            await d5.evaluate("()=>{P.gold=9999;save()}");await d5.evaluate("async()=>twaPush(false)")
            await d3.evaluate("()=>{sessionStorage.setItem('twa_start','1')}");await d3.reload();await d3.wait_for_timeout(3000)
            for _ in range(60):
                r=await d3.evaluate("()=>[P.gold,!!twaLoadSes()]")
                if r[0]==9999:break
                await d3.wait_for_timeout(250);await d3.evaluate("()=>{sessionStorage.removeItem('twa_start')}")
            chk('opening the game on a signed-in device loads newer progress from another device by itself',r==[9999,True],r)
            # ---- sign out
            r=await d3.evaluate("async()=>{await twaSignOut(false);return [!!twaLoadSes(),P.gold,$('twachip').className]}")
            chk('signing out keeps the progress on the device and turns the chip back to "Sign in"',r==[False,9999,'out'],r)
            st=await ui(d3,'in','seth_42','fresh pass 33')
            r=await d3.evaluate("async()=>{await twaSignOut(true);await new Promise(r=>setTimeout(r,500));return [!!twaLoadSes(),P.gold,lvl(P.xp)]}")
            chk('"Sign out and clear this device" removes the progress here (it stays on the account)',r[0]==False and r[1]==0 and r[2]==1,r)
            r=await d3.evaluate("()=>{const ok=[];for(const e of document.querySelectorAll('#twa'))ok.push(1);return document.documentElement.scrollWidth<=innerWidth+2}")
            for e in allerr:pass
            errs=[x for e in allerr for x in e]
            chk('no page errors on any device',not errs,errs[:4])
            await br.close()
    finally:
        for pr in procs:pr.terminate()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
