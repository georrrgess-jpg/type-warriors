# python3 shots_pzn101.py [outdir] : screenshots of Orbit 8 (10.1): the tavern pass, the Orbit 8 hub, matches on the new table,
# each new player in every expression, VS intros, results and The Regulars tab. Default outdir: ../../type-warriors-source/shots/w101_pool
import asyncio,os,sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.join(HERE,'out.html')
O=sys.argv[1] if len(sys.argv)>1 else '/home/user/type-warriors/type-warriors-source/shots/w101_pool'
os.makedirs(O,exist_ok=True)
PRE="()=>{RS_ASK=false;PZ_TUT_OFF=true;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}P.gold=48250;P.pz=null;save()}"
SHEET=r"""(id)=>{let c=document.getElementById('shc');if(!c){c=document.createElement('canvas');c.id='shc';c.width=1600;c.height=900;c.style.cssText='position:fixed;left:0;top:0;width:1600px;height:900px;z-index:99999';document.body.appendChild(c)}
 const g=c.getContext('2d'),R=PZ_REG[id];g.drawImage(pznHubBg(),0,0);g.fillStyle='rgba(6,4,24,.72)';g.fillRect(0,0,1600,900);g.lineJoin='round';g.lineCap='round';
 g.fillStyle=R.c;g.font='400 64px "Pirata One",serif';g.textAlign='left';g.fillText(R.n,40,78);g.fillStyle='#c4badf';g.font='700 20px Poppins,sans-serif';g.fillText(R.k+'  ·  '+R.quirk,44,112);
 const ks=Object.keys(PZ_EXP);ks.forEach((k,i)=>{const col=i%5,row=i/5|0,x=170+col*315,y=row?820:470,w=290,h=330;g.fillStyle='rgba(20,30,80,.55)';g.beginPath();g.roundRect(x-w/2,y-h+20,w,h,22);g.fill();g.strokeStyle='rgba(122,248,255,.35)';g.lineWidth=2;g.stroke();
  const b=pzMonBox(id),s=Math.min((w-30)/(b.x1-b.x0),(h-50)/(b.y1-b.y0));g.save();g.translate(x-(b.x0+b.x1)/2*s,y-b.y1*s);g.scale(s,s);const ex=Object.assign(pzCastEx(),PZ_EXP[k]);if(k!=='neutral'){for(const q in ex){const N=PZ_EXP.neutral[q];if(q!=='eo'&&q!=='sw'&&q!=='bl')ex[q]=N+(ex[q]-N)*1.45}}
  pzMon[id](g,2+i*.41,ex,{breath:0,tilt:0,bob:0,hop:0});g.restore();g.fillStyle='#fff';g.font='800 18px Poppins,sans-serif';g.textAlign='center';g.fillText(k.toUpperCase(),x,y+2)});
 {const x=1430,y=820;g.fillStyle='rgba(20,30,80,.55)';g.beginPath();g.roundRect(x-140,y-310,280,330,22);g.fill();g.strokeStyle='rgba(255,212,90,.5)';g.lineWidth=2;g.stroke();
  const cv=document.createElement('canvas');cv.width=cv.height=220;pzCastPortrait(cv.getContext('2d'),'mon',id,220,2,Object.assign(pzCastEx(),PZ_EXP.happy));g.save();g.beginPath();g.arc(x,y-170,110,0,TAU);g.clip();g.fillStyle='#14205a';g.fillRect(x-110,y-280,220,220);g.drawImage(cv,x-110,y-280);g.restore();
  g.strokeStyle='#ffd45a';g.lineWidth=5;g.beginPath();g.arc(x,y-170,110,0,TAU);g.stroke();g.fillStyle='#ffd45a';g.font='800 18px Poppins,sans-serif';g.fillText('HUD PORTRAIT',x,y+2)}
 return 0}"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)))
        await pg.goto(H);await pg.wait_for_timeout(1500);await pg.evaluate(PRE);E=pg.evaluate
        async def snap(n,w=0):
            if w:await pg.wait_for_timeout(w)
            await pg.screenshot(path=os.path.join(O,n));print('shot',n)
        # the tavern pass, new
        await E("()=>{const Z=PZS();Z.beat={gloop:2,moldwick:1,grizzle:1,vesper:1};save();PZ.shadeHere=false;PZ.shadeChecked=pzDay();casinoOpen();gameOpen('pz')}");await snap('01_tavern_pass.png',2200)
        # the Orbit 8 hub, mid progress
        await E("()=>{const Z=PZS();Z.beat.bleep=2;Z.beat.octavia=1;Z.wins=5;Z.losses=2;save();document.getElementById('pzn8tk').click()}");await snap('02_orbit8_hub.png',2600)
        await E("()=>{pzHubSel('octavia')}");await snap('03_orbit8_hub_octavia.png',1200)
        await E("()=>{const Z=PZS();for(const k of PZN_ORDER)Z.beat[k]=Z.beat[k]||1;save();PZ.sel='vantara';pzHub()}");await snap('04_orbit8_hub_vantara_all_beaten.png',2600)
        # VS intros
        for opp in ['rex','vantara','octavia']:
            await E("o=>{pzStart({opp:o,practice:true,seed:4})}",opp);await snap(f'05_vs_{opp}.png',1100 if opp!='vantara' else 650)
            await E("()=>{const i=document.getElementById('pzintro');if(i)i.click()}");await pg.wait_for_timeout(2200)
            await snap(f'06_match_{opp}.png',300)
            await E("()=>{pzForfeit()}");await pg.wait_for_timeout(300);await E("()=>{PZS().live=null;pzHub()}");await pg.wait_for_timeout(600)
        # the opponent at work: an AI shot mid routine, then the balls rolling
        await E("()=>{pzStart({opp:'facet',practice:true,seed:11})}");await pg.wait_for_timeout(400);await E("()=>{const i=document.getElementById('pzintro');if(i)i.click()}");await pg.wait_for_timeout(1800)
        await E("()=>{PZ.aim.pow=.95;pzFireHuman()}")
        for i in range(60):
            await pg.wait_for_timeout(250)
            if await E("()=>PZ.ph==='ai'&&PZ.ai&&PZ.ai.t>.6"):break
        await snap('07_match_facet_thinking.png')
        for i in range(40):
            await pg.wait_for_timeout(100)
            if await E("()=>PZ.ph==='roll'"):break
        await snap('08_match_facet_shot.png',350)
        await E("()=>{pzForfeit()}");await pg.wait_for_timeout(300);await E("()=>{PZS().live=null;pzHub()}");await pg.wait_for_timeout(600)
        # each player in every expression
        await E("()=>{lobby()}");await pg.wait_for_timeout(400)
        for id in ['bleep','octavia','facet','rex','vantara']:
            await E(SHEET,id);await snap(f'10_cast_{id}.png',200)
        await E("()=>{const c=document.getElementById('shc');if(c)c.remove()}")
        # results: a win against Bleep (first win, next table) and a loss against Vantara
        await E("()=>{P.pz=null;const Z=PZS();Z.beat={grizzle:1};Z.venue='o8';save();casinoOpen();gameOpen('pz')}");await pg.wait_for_timeout(900)
        await E("()=>{pzHubStake(500);document.getElementById('pzrackem').click()}");await pg.wait_for_timeout(500);await E("()=>document.getElementById('pzintro').click()");await pg.wait_for_timeout(1500)
        await E("()=>{PZ.M.over={winner:0};PZ.M.score=[2,1];PZ.M.racks=[{w:0,why:'8 ball'},{w:1,why:'8 ball'},{w:0,why:'8 ball'}];pzMatchEnd()}");await snap('11_results_win_bleep.png',2600)
        await E("()=>{const Z=PZS();for(const k of PZN_ORDER)Z.beat[k]=Z.beat[k]||1;Z.beat.vantara=0;save();pzStart({opp:'vantara',stake:2000,seed:5})}");await pg.wait_for_timeout(500);await E("()=>document.getElementById('pzintro').click()");await pg.wait_for_timeout(1500)
        await E("()=>{PZ.M.over={winner:1};PZ.M.score=[1,3];PZ.M.racks=[{w:1,why:'8 ball'},{w:0,why:'8 ball'},{w:1,why:'8 ball'},{w:1,why:'8 ball'}];pzMatchEnd()}");await snap('12_results_loss_vantara.png',2600)
        # The Regulars, Orbit 8 tab
        await E("()=>{pzRegs()}");await pg.wait_for_timeout(700);await E("()=>document.querySelector('.pzn8tabs button[data-v=o8]').click()");await snap('13_regulars_orbit8.png',900)
        print('errors',er)
        await b.close()
asyncio.run(main())
