# python3 t_dev99.py [game.html] : DEV > Cheats 9.9k (97i): the cheat list scrolls (panel kept on screen, scroll position kept after a
# cheat, wheel inside an embedding frame, jump chips) and the progress cheats for Tower Defense, Lantern Caravan, Moonlit Fishing spots
# and The Crooked Cue edit the real save.
import asyncio,os,sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:500]),flush=True)
    if not ok:FAIL.append(name)
OPEN="()=>{RS_ASK=false;WCRELAYS=[];DEV.on=true;DEV.open=true;DEV.tab='Cheats';devPanelEl();devRender();return 1}"
ACT="(a)=>{devAct('x:'+a);return 1}"
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1280,'height':720});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E(OPEN);await pg.wait_for_timeout(300)
        r=await E("()=>[...document.querySelectorAll('#devpanel .dvx h5')].map(h=>h.textContent)")
        chk('the Cheats tab has Tower Defense, Lantern Caravan, fishing spots and The Crooked Cue sections',all(x in r for x in ['Tower Defense','Lantern Caravan: routes','Moonlit Fishing: spots','The Crooked Cue']),r)
        # panel dragged low: it must stay on screen and scroll
        await E("()=>{const p=$('devpanel');p.style.top='520px';devRender()}");await pg.wait_for_timeout(200)
        r=await E("()=>{const p=$('devpanel').getBoundingClientRect(),B=document.querySelector('#devpanel .dvbody');return [Math.round(p.top),Math.round(p.bottom),innerHeight,B.scrollHeight>B.clientHeight+50]}")
        chk('a panel dragged low is kept on screen and its list becomes scrollable',r[1]<=r[2] and r[0]<=r[2]-150 and r[3],r)
        await E("()=>{const p=$('devpanel');p.style.top='60px';devRender()}")
        await pg.mouse.move(1000,400);await pg.mouse.wheel(0,900);await pg.wait_for_timeout(200)
        s1=await E("()=>document.querySelector('#devpanel .dvbody').scrollTop")
        await E("()=>{devAct('x:tddrag')}");await pg.wait_for_timeout(100)
        s2=await E("()=>document.querySelector('#devpanel .dvbody').scrollTop")
        chk('the wheel scrolls the list, and using a cheat keeps the place in the list',s1>300 and abs(s2-s1)<5,[s1,s2])
        r=await E("()=>{const B=document.querySelector('#devpanel .dvbody'),n=B.querySelector('.dvpnav');const btn=[...n.querySelectorAll('button')].find(x=>x.textContent==='The Crooked Cue');btn.click();const h=[...B.querySelectorAll('.dvx h5')].find(x=>x.textContent==='The Crooked Cue');const hr=h.getBoundingClientRect(),br=B.getBoundingClientRect();n.querySelector('button').click();return [hr.top>=br.top&&hr.bottom<=br.bottom,B.scrollTop]}")
        chk('the section chips jump to a section; Top goes back up',r==[True,0],r)
        await E("()=>{const B=document.querySelector('#devpanel .dvbody');B.scrollTop=0}");await pg.mouse.move(1000,400);await pg.keyboard.press('PageDown');await pg.wait_for_timeout(100)
        r=await E("()=>document.querySelector('#devpanel .dvbody').scrollTop")
        chk('PageDown scrolls the list while the pointer is over the panel',r>200,r)
        # tower defense
        r=await E("""()=>{devAct('x:tdreset');devAct('x:tdreset');const a=[Object.keys(RPP().stars).length];devAct('x:td3');devAct('x:tdasc');devAct('x:tdskins');$('dvptdb').value=77;devAct('x:tdbest');
          const r=RPP();a.push(RP_MAPS.filter(m=>!m.endless).every(m=>r.stars[m.id]===3),RP_MAPOPEN(RP_MAP('wonder')),RP_TWORDER.every(t=>r.asc[t]===5),RP_SKINLIST().every(s=>s.k==='base'||r.own[s.tw+':'+s.k]),r.ebest);
          $('dvptdm').value='frost';$('dvptds').value='1';devAct('x:tdstar');a.push(RPP().stars.frost);return a}""")
        chk('Tower Defense: reset (asks twice), 3 stars everywhere, Wonderland open, every tower ascended, every skin, best wave, stars per map',r==[0,True,True,True,True,77,1],r)
        r=await E("()=>{RPP().stars={};RPP().dragon=0;devAct('x:tdwon');devAct('x:tddrag');return [RP_MAPOPEN(RP_MAP('wonder')),rpDragonOpen()]}")
        chk('Tower Defense: unlock the Wonderland and the Dragon Roost',r==[True,True],r)
        # caravan
        r=await E("""()=>{const w=WRP();w.med={};$('dvpwr').value=WR_ROUTES[1].id;$('dvpwm').value='2';devAct('x:wrset');const a=[WRP().med[WR_ROUTES[1].id]];devAct('x:wropen');a.push(WR_ROUTES.every(x=>wrRouteOpen(x)),WRP().med[WR_ROUTES[1].id]);devAct('x:wrmed');a.push(WR_ROUTES.every(x=>WRP().med[x.id]===3));return a}""")
        chk('Lantern Caravan: a medal per route, open every route; the 8.5 All gold medals button still works',r==[2,True,2,True],r)
        r=await E("()=>{const t=[...document.querySelectorAll('#devpanel .dvpnav button')].map(b=>b.textContent);return [t.length,new Set(t).size]}")
        chk('the section chips are all different',r[0]==r[1] and r[0]>8,r)
        # fishing
        r=await E("()=>{devAct('x:fsspots');return FSLOCK.filter(k=>!FSLOCS[k].soon).every(k=>fsLocOpen(k))}")
        chk('Moonlit Fishing: every fishing spot unlocks',r,r)
        # pool
        r=await E("""()=>{devAct('x:pzbeat');devAct('x:pzown');devAct('x:pztrick');devAct('x:pzmast');const Z=PZS();return [PZ_ORDER.every(k=>Z.beat[k]>0),Z.shade.beat>0,PZ_CUES.every(c=>Z.cues[c.id]),PZ_FELT.every(f=>Z.felts[f.id]),PZ_BALLS.every(x=>Z.ballsets[x.id]),PZ_TRICK.every((t,i)=>pzTrickStars(i)===3),PZ_CUES.every(c=>pzMastLv(c.id)>=10)]}""")
        chk('The Crooked Cue: every regular and the Shade beaten, every cue, felt and ball set, 3-star trick shots, max mastery',all(r),r)
        r=await E("()=>{const s=JSON.stringify(P);return [s.includes('\"rp\"'),s.includes('\"wr\"'),s.includes('\"pz\"')]}")
        chk('the cheats edit the real save',r==[True,True,True],r)
        await E("()=>{devRender();const B=document.querySelector('#devpanel .dvbody');const h=[...B.querySelectorAll('.dvx h5')].find(x=>x.textContent==='Tower Defense');B.scrollTop=h.parentElement.offsetTop-50}");await pg.wait_for_timeout(200)
        await pg.screenshot(path=os.path.join(HERE,'shots','dev99_cheats.png'))
        # inside an embedding frame (the fit-screen wheel guard is on there)
        fp=os.path.join(HERE,'frame_test.html');open(fp,'w').write('<html><body style="margin:0"><iframe src="out.html" style="width:1280px;height:720px;border:0"></iframe></body></html>')
        await pg.goto('file://'+fp);await pg.wait_for_timeout(2500);F=pg.frames[1]
        await F.evaluate(OPEN);await pg.wait_for_timeout(300);await pg.mouse.move(1000,400);await pg.mouse.wheel(0,700);await pg.wait_for_timeout(250)
        r=await F.evaluate("()=>[inFrame(),document.querySelector('#devpanel .dvbody').scrollTop]")
        chk('inside an embedding frame the wheel still scrolls the cheat list',r[0] and r[1]>300,r)
        try:os.remove(fp)
        except Exception:pass
        chk('no page errors',not er,er)
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
