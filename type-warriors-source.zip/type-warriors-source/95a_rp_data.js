/* ===== RUNESTONE RAMPARTS (Update 8.8): data =====
   A tower-defense mode. Monsters walk a winding road toward the keep; towers on stone pads fire on their own; the player types words
   in the command bar to fill the Command meter, which powers Overcharge, Slow Field and Repair.
   Code prefix rp, state RPX (95e), save P.rp via RPP(). Art: 95b (monsters), 95c (towers, pads, effects), 95d (maps). UI: 95f/95g. */
const RPT={MAPH:660,KEEP:20,CMD:100,SELL:.7,EARLY:3,BUILD_T:14,REPAIR:4,OVER_T:10,OVER_K:2.4,SLOW_T:7,SLOW_K:.45,SLOW_R:95,WORD_SUP:2,FIRSTDAY:1.5};
/* towers: arrays are per tier 1..3 (index 0..2). cost[0] builds, cost[1]/cost[2] upgrade. cd = seconds between shots. ap = armor it ignores. */
const RP_TW={
 ballista:{cost:[100,150,280],range:[230,250,280],dmg:[24,44,84],cd:[.95,.8,.62],ap:[3,6,99],air:1,ground:1,
  desc:'High single-target damage. Rune bolts hit flyers and pierce armor.',up:['Heavier bow: more damage and range.','Twin-rune bolts: armor no longer matters, and each bolt passes through to a second foe.']},
 brazier:{cost:[120,170,300],range:[175,190,210],dmg:[20,34,60],cd:[1.3,1.15,1.0],splash:[62,74,92],burn:[0,0,10],air:0,ground:1,
  desc:'Hurls burning embers that splash every foe nearby. Cannot hit flyers.',up:['Wider, hotter blasts.','Triple vents: blasts leave burning ground.']},
 frost:{cost:[90,130,240],range:[160,178,198],dmg:[6,10,16],cd:[1.05,.95,.85],slow:[.36,.46,.58],slowT:[1.6,1.9,2.3],air:0,ground:1,
  desc:'Pulses frost that chills and slows every ground foe in range.',up:['Colder pulse: slows harder and longer.','Frost crown: the pulse also shatters chilled foes for bonus damage.']},
 bell:{cost:[110,160,290],range:[220,238,265],dmg:[24,40,70],cd:[1.15,1.0,.85],chain:[2,3,5],airK:2,air:1,ground:1,
  desc:'Calls lightning that chains between foes. Double damage to flyers.',up:['A second bell: longer chains.','Storm crown: five-foe chains that stun flyers for a moment.']}};
const RP_TWORDER=['ballista','brazier','frost','bell'];
/* foes: hp at wave 1 of the first map, speed in px/s, bounty in supply, dmg = keep damage when it gets through */
const RP_FOE={
 scamp:{hp:30,sp:96,bounty:4,dmg:1,armor:0},
 bulwark:{hp:72,sp:54,bounty:6,dmg:1,armor:4},
 golem:{hp:280,sp:36,bounty:16,dmg:3,armor:9},
 gloom:{hp:44,sp:78,bounty:6,dmg:1,armor:0,air:1},
 ooze:{hp:120,sp:48,bounty:7,dmg:2,armor:0,split:'oozelet',splitN:2},
 oozelet:{hp:32,sp:74,bounty:2,dmg:1,armor:0},
 shaman:{hp:96,sp:50,bounty:11,dmg:2,armor:0,heal:.08,healR:105,healT:2.4},
 behemoth:{hp:2600,sp:24,bounty:150,dmg:12,armor:10,boss:1}};
const RP_FOETIP={scamp:'Fast runners. Cover the road early.',bulwark:'Shielded squads. Splash from the Ember Brazier breaks them.',golem:'Heavy armor. Rune Ballista bolts pierce it.',
 gloom:'Flies over everything. Only the Rune Ballista and the Storm Bell can hit it.',ooze:'Splits in two when it pops.',oozelet:'Small, quick and squishy.',
 shaman:'Heals nearby monsters. Take it down first.',behemoth:'The boss. Slow it, focus it, and save Command for Repair.'};
/* maps: path points in stage px (the map is the top 660 px of the 1600x900 stage); the keep stands at the path's end */
const RP_MAPS=[
 {id:'moss',n:'Mossgate Hollow',sub:'The forest road',waves:10,start:270,hpk:1,spk:1,pay:850,xp:120,pal:'moss',
  path:[[-50,250],[140,245],[285,262],[392,318],[450,400],[540,470],[700,488],[830,435],[890,330],[990,250],[1135,248],[1235,318],[1268,420],[1340,468],[1450,468]]},
 {id:'frost',n:'Frostfang Pass',sub:'Frozen switchbacks',waves:15,start:300,hpk:1.45,spk:1.04,pay:1400,xp:200,pal:'frost',
  path:[[-50,520],[170,520],[255,430],[262,270],[350,165],[530,150],[630,250],[640,420],[735,520],[915,520],[1000,420],[1005,250],[1100,150],[1235,170],[1300,290],[1305,420],[1370,468],[1450,468]]},
 {id:'ember',n:'Ember Crown',sub:'Through the fire',waves:20,start:330,hpk:1.9,spk:1.08,pay:2100,xp:300,pal:'ember',
  path:[[-50,330],[110,330],[195,215],[330,135],[475,165],[525,300],[430,425],[350,540],[470,605],[640,598],[760,505],[770,355],[860,235],[1000,185],[1120,240],[1140,380],[1065,500],[1150,598],[1300,585],[1365,480],[1450,468]]}];
const RP_MAP=id=>RP_MAPS.find(m=>m.id===id)||RP_MAPS[0];
const RP_MAPOPEN=m=>{const i=RP_MAPS.indexOf(m);return i<=0||(RPP().stars[RP_MAPS[i-1].id]||0)>0};
/* reward track: stars across all maps (3 per map) unlock tower skins only found here, then the title */
const RP_SKINS=[{tw:'ballista',k:'gilded',n:'Gilded Ballista',need:2},{tw:'brazier',k:'azure',n:'Azure Brazier',need:4},{tw:'frost',k:'aurora',n:'Aurora Spire',need:6},{tw:'bell',k:'thunderking',n:'Thunderking Bell',need:8}];
const RP_TITLE_NEED=9;
/* words for the command bar: short, punchy, on theme */
const RP_WORDS=('ward keep rune wall gate moat tower stone guard shield spire flame frost storm bolt bell crown arrow siege blaze ember spark'+
 ' haste chill quake forge iron brave watch torch rally parry valor oath creed banner bastion rampart citadel sentinel barrier fortress'+
 ' garrison palisade bulwark catapult lantern warden beacon arcane glyph sigil mortar cannon volley turret parapet rookery herald'+
 ' thunder tempest frozen inferno crystal granite marble cobalt silver golden castle bridge harbor tunnel portal summit glacier canyon'+
 ' meadow thicket forest hollow cavern hamlet market lancer knight archer ranger squire bishop jester marshal captain steward'+
 ' defend resist uphold secure bolster harden temper kindle ignite shatter dazzle thrash vanquish triumph victory glory honor').split(/\s+/).filter(w=>/^[a-z]{3,9}$/.test(w));
/* the save */
function RPP(){let r=P.rp;const D={stars:{},best:{},wins:0,runs:0,kills:0,words:0,gold:0,skin:{},own:{},seen:0,intro:0,day:'',dayDone:{},hint:{},fp:{}};
 if(!r||typeof r!=='object'||Array.isArray(r))r=P.rp={};
 for(const k in D)if(r[k]===undefined||typeof r[k]!==typeof D[k]||Array.isArray(r[k])!==Array.isArray(D[k]))r[k]=D[k];
 for(const m of RP_MAPS){const v=r.stars[m.id];if(v!==undefined&&!(v>=0&&v<=3))delete r.stars[m.id]}
 for(const t of RP_TWORDER){if(r.skin[t]&&r.skin[t]!=='base'&&!r.own[t+':'+r.skin[t]])r.skin[t]='base'}
 return r}
const rpStarN=()=>{const r=RPP();return RP_MAPS.reduce((a,m)=>a+(r.stars[m.id]||0),0)};
function rpSkinOf(tw){const r=RPP(),k=r.skin[tw];return k&&k!=='base'&&r.own[tw+':'+k]?k:'base'}
function rpDay(){const d=new Date();return d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate()}
/* waves: a list of groups {id,n,gap,at} (at = seconds after the wave starts). Map 1 is hand-made; later maps and freeplay are generated. */
const RP_W1=[
 [{id:'scamp',n:8,gap:1.1,at:0}],
 [{id:'scamp',n:10,gap:.9,at:0},{id:'bulwark',n:3,gap:1.6,at:6}],
 [{id:'bulwark',n:7,gap:1.0,at:0},{id:'scamp',n:6,gap:.7,at:7}],
 [{id:'gloom',n:5,gap:1.4,at:0},{id:'scamp',n:10,gap:.7,at:3}],
 [{id:'golem',n:2,gap:4,at:0},{id:'scamp',n:12,gap:.6,at:2}],
 [{id:'ooze',n:3,gap:2.4,at:0},{id:'bulwark',n:8,gap:.9,at:4}],
 [{id:'shaman',n:2,gap:3,at:2},{id:'bulwark',n:10,gap:.8,at:0},{id:'gloom',n:6,gap:1,at:6}],
 [{id:'golem',n:4,gap:3,at:0},{id:'scamp',n:14,gap:.5,at:3},{id:'gloom',n:6,gap:.9,at:9}],
 [{id:'ooze',n:4,gap:2,at:0},{id:'shaman',n:3,gap:2.5,at:3},{id:'bulwark',n:12,gap:.7,at:5}],
 [{id:'behemoth',n:1,gap:1,at:3},{id:'bulwark',n:8,gap:.8,at:0},{id:'scamp',n:10,gap:.5,at:8},{id:'gloom',n:6,gap:1,at:12}]];
function rpWave(map,w){const W=map.waves;if(map.id==='moss'&&w<=W)return RP_W1[w-1];
 /* generated: a budget that grows with the wave, spent on the foe types this map has unlocked by then */
 const free=w>W,f=free?w-W:0,pool=[['scamp',1,1],['bulwark',2,2],['gloom',2,3],['ooze',4,5],['golem',7,6],['shaman',6,7]].filter(p=>w>=p[2]);
 const groups=[];let at=0,bud=(14+w*7.5)*(map.id==='ember'?1.1:1)*(1+f*.12);
 const last=w===W||(free&&f%5===0);
 if(last){groups.push({id:'behemoth',n:free?1+Math.floor(f/10):1,gap:6,at:3});bud*=.55}
 let i=0;while(bud>2&&i<4){const p=pool[(w*7+i*3)%pool.length],cost=p[1],n=Math.max(2,Math.min(18,Math.round(bud/cost/(i<1?1.4:2))));
  groups.push({id:p[0],n,gap:p[0]==='golem'?2.6:p[0]==='ooze'?1.8:p[0]==='shaman'?2.2:Math.max(.42,1-w*.02),at});at+=n*.45+2;bud-=n*cost;i++}
 return groups}
const rpHpK=(map,w)=>map.hpk*(1+.12*(w-1)+.007*(w-1)*(w-1));
const rpBountyK=w=>1+.015*(w-1);
const rpWaveBonus=w=>25+5*w;
