/* ===== MOONLIT FISHING: fish art kit =====
   fishDraw(g,id,o) draws one fish centred on the origin, facing right (snout toward +x), body about 200 units long
   (tail tip near x=-100, snout near x=+100) and inside y -75..75 (fins may reach a little further).
   o = {t: seconds (idle life: tail sway, fin flutter, glow pulse), flex: 0..1 (thrashing on the line), sil: draw a flat
   silhouette in colour o.sil (undiscovered fish), glow: 0..1 extra magic glow (catch spectacle)}.
   Each fish lives in FISHART[id](g,t,o) (90c/90c2/90c3). Style: chunky #1b1024 outlines, gradient bodies with a darker
   belly or back half, a white highlight stroke on the upper left, big friendly eyes, sparkles and additive glows for
   magical fish. Shared helpers below are prefixed fk. */
const FISHART={};
const FKO='#1b1024';
/* tail sway angle (radians) for a fish: slow idle sway plus thrash when on the line */
const fkSway=(o,sp,amp)=>Math.sin((o.t||0)*(sp||3)+((o.seed)||0))*(amp||.12)*(1+(o.flex||0)*3);
/* draw a closed smooth outline through points [x0,y0,x1,y1,...] (quadratic midpoint spline) */
function fkPath(g,p){const n=p.length/2,mx=i=>(p[(i%n)*2]+p[((i+1)%n)*2])/2,my=i=>(p[(i%n)*2+1]+p[((i+1)%n)*2+1])/2;g.beginPath();g.moveTo(mx(n-1),my(n-1));for(let i=0;i<n;i++)g.quadraticCurveTo(p[i*2],p[i*2+1],mx(i),my(i));g.closePath()}
/* fill the current path, then outline it */
function fkFill(g,f,lw){g.fillStyle=f;g.fill();if(lw!==0){g.lineWidth=lw||3;g.strokeStyle=FKO;g.lineJoin='round';g.stroke()}}
/* white highlight stroke along the current path (clipped to it), offset up-left */
function fkHi(g,pathFn,a,w){g.save();pathFn();g.clip();g.translate(-2.2,-2.6);pathFn();g.strokeStyle=`rgba(255,255,255,${a==null?.55:a})`;g.lineWidth=w||3.2;g.stroke();g.restore()}
/* shade the lower (or other) part of a path: draws a gradient wash inside the clip */
function fkShade(g,pathFn,y0,y1,c,a){g.save();pathFn();g.clip();const q=g.createLinearGradient(0,y0,0,y1);q.addColorStop(0,c+'00');q.addColorStop(1,c+Math.round((a==null?.55:a)*255).toString(16).padStart(2,'0'));g.fillStyle=q;g.fillRect(-140,y0,280,y1-y0);g.restore()}
/* scale pattern clipped to a path: rows of small arcs */
function fkScales(g,pathFn,x0,x1,y0,y1,s,c,a){g.save();pathFn();g.clip();g.strokeStyle=c;g.globalAlpha=a==null?.35:a;g.lineWidth=1.4;for(let y=y0,r=0;y<y1;y+=s*.62,r++)for(let x=x0+(r%2?s/2:0);x<x1;x+=s){g.beginPath();g.arc(x,y,s*.52,Math.PI*.15,Math.PI*.85);g.stroke()}g.restore()}
/* a fin from a base point: ribs radiate along it; pts = outline points (relative), c1->c2 gradient */
function fkFin(g,pts,c1,c2,ribs,lw){fkPath(g,pts);const b=[1e9,1e9,-1e9,-1e9];for(let i=0;i<pts.length;i+=2){b[0]=Math.min(b[0],pts[i]);b[1]=Math.min(b[1],pts[i+1]);b[2]=Math.max(b[2],pts[i]);b[3]=Math.max(b[3],pts[i+1])}
 const q=g.createLinearGradient(b[0],b[1],b[2],b[3]);q.addColorStop(0,c1);q.addColorStop(1,c2);fkFill(g,q,lw||2.6);
 if(ribs){g.save();fkPath(g,pts);g.clip();g.strokeStyle=FKO;g.globalAlpha=.28;g.lineWidth=1.3;for(const r of ribs){g.beginPath();g.moveTo(r[0],r[1]);g.lineTo(r[2],r[3]);g.stroke()}g.restore()}}
/* big friendly eye (r = radius); look = -1..1 sideways glance */
function fkEye(g,x,y,r,iris,look){look=look||0;g.beginPath();g.arc(x,y,r,0,TAU);g.fillStyle='#fffdf6';g.fill();g.lineWidth=Math.max(2,r*.24);g.strokeStyle=FKO;g.stroke();
 g.beginPath();g.arc(x+r*.18+look*r*.12,y+r*.05,r*.62,0,TAU);g.fillStyle=iris||'#2a1a3a';g.fill();g.beginPath();g.arc(x+r*.22+look*r*.12,y+r*.08,r*.36,0,TAU);g.fillStyle='#0c0612';g.fill();
 g.beginPath();g.arc(x+r*.36,y-r*.22,r*.24,0,TAU);g.fillStyle='#fff';g.fill();g.beginPath();g.arc(x-r*.08,y+r*.32,r*.11,0,TAU);g.fillStyle='#ffffffcc';g.fill()}
/* 4-point sparkle */
function fkSpark(g,x,y,r,c,a){g.save();g.globalAlpha=a==null?1:a;g.fillStyle=c||'#fff';g.beginPath();g.moveTo(x,y-r);g.quadraticCurveTo(x+r*.16,y-r*.16,x+r,y);g.quadraticCurveTo(x+r*.16,y+r*.16,x,y+r);g.quadraticCurveTo(x-r*.16,y+r*.16,x-r,y);g.quadraticCurveTo(x-r*.16,y-r*.16,x,y-r);g.fill();g.restore()}
/* soft additive glow */
function fkGlow(g,x,y,r,c,a){if(r<=0||a<=0)return;g.save();g.globalCompositeOperation='lighter';const q=g.createRadialGradient(x,y,0,x,y,r);q.addColorStop(0,c+Math.round(Math.min(1,a)*255).toString(16).padStart(2,'0'));q.addColorStop(1,c+'00');g.fillStyle=q;g.beginPath();g.arc(x,y,r,0,TAU);g.fill();g.restore()}
/* linear / radial gradient shortcuts */
function fkLin(g,x0,y0,x1,y1,cs){const q=g.createLinearGradient(x0,y0,x1,y1);cs.forEach((c,i)=>q.addColorStop(i/(cs.length-1),c));return q}
function fkRad(g,x,y,r,cs){const q=g.createRadialGradient(x-r*.3,y-r*.35,r*.05,x,y,r);cs.forEach((c,i)=>q.addColorStop(i/(cs.length-1),c));return q}
/* draw a fish; silhouettes are drawn into a scratch canvas and flattened to one colour */
let FKSIL=null;
function fishDraw(g,id,o){o=o||{};const f=FISHART[id];if(!f)return;
 if(o.sil){const k=g.getTransform(),sc=Math.hypot(k.a,k.b)||1,S=Math.ceil(Math.min(1024,260*sc));if(!FKSIL)FKSIL=document.createElement('canvas');if(FKSIL.width!==S){FKSIL.width=S;FKSIL.height=S}
  const c=FKSIL.getContext('2d');c.setTransform(1,0,0,1,0,0);c.clearRect(0,0,S,S);c.setTransform(S/260,0,0,S/260,S/2,S/2);f(c,o.t||0,Object.assign({},o,{sil:0}));c.setTransform(1,0,0,1,0,0);c.globalCompositeOperation='source-in';c.fillStyle=o.sil;c.fillRect(0,0,S,S);c.globalCompositeOperation='source-over';
  g.save();g.drawImage(FKSIL,-130,-130,260,260);g.restore();return}
 g.save();g.lineJoin='round';g.lineCap='round';f(g,o.t||0,o);g.restore()}
/* fit a fish into a box (w x h, centre cx,cy) */
function fishFit(g,id,cx,cy,w,h,o){const s=Math.min(w/220,h/160);g.save();g.translate(cx,cy);g.scale(s,s);fishDraw(g,id,o);g.restore()}
