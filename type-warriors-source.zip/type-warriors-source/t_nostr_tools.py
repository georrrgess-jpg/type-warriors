# Test helpers for the Wildcard leaderboard (89w): BIP-340 signing written from the specification (independent of the
# game's JavaScript), NIP-01 events, and a simulator that plays a ranked season with the game's own point table so the
# entries it makes are exactly what an honest game would post.
import hashlib,json,os,time
from t_nostr_relay_math import p,n,G,add,mul,lift_x,th,verify
PTS=[[30,20,10,0],[30,15,5,-5],[30,10,0,-10],[25,10,-5,-15],[25,5,-10,-20],[25,5,-10,-20]]
NEED=[110,150,200,250,290]  # points to fill the bar at each rank (89s WCRN[].need)
QCUT=1793491200  # Date.UTC(2026,10,1)/1000: until then season-1 matches may still use the old 100-point bar
SEASON_START=1791763200  # Date.UTC(2026,9,12)/1000
SEASON_LEN=42*86400
def season_start(s):return SEASON_START+(s-1)*SEASON_LEN
def keypair(seed):
    d=int.from_bytes(hashlib.sha256(('tw-test-'+str(seed)).encode()).digest(),'big')%n or 1
    P=mul(G,d);return d,P[0].to_bytes(32,'big').hex()
def sign(d,m,aux=None):
    P=mul(G,d);dd=d if P[1]%2==0 else n-d
    aux=aux or os.urandom(32);t=(dd^int.from_bytes(th('BIP0340/aux',aux),'big')).to_bytes(32,'big')
    pk=P[0].to_bytes(32,'big');k0=int.from_bytes(th('BIP0340/nonce',t+pk+m),'big')%n
    R=mul(G,k0);k=k0 if R[1]%2==0 else n-k0
    e=int.from_bytes(th('BIP0340/challenge',R[0].to_bytes(32,'big')+pk+m),'big')%n
    return (R[0].to_bytes(32,'big')+((k+e*dd)%n).to_bytes(32,'big')).hex()
def ser(ev):return json.dumps([0,ev['pubkey'],ev['created_at'],ev['kind'],ev['tags'],ev['content']],separators=(',',':'),ensure_ascii=False)
def event(d,pk,content,created_at,kind=30078,tags=None,season=1):
    tg='twwc-lb-s%d'%season
    ev={'pubkey':pk,'created_at':created_at,'kind':kind,'tags':tags if tags is not None else [['d',tg],['t',tg],['t','twwc-lb']],'content':content if isinstance(content,str) else json.dumps(content,separators=(',',':'))}
    ev['id']=hashlib.sha256(ser(ev).encode()).hexdigest();ev['sig']=sign(d,bytes.fromhex(ev['id']));return ev
def play(places,r0=0,season=1,t0=None,gap=90,legacy=False):
    """an honest season: the game's own rank/bar/LP rules (89s rkApply) for the given finishing places.
    legacy=True plays by the old rules (every bar 100) and lists matches the old way (4 numbers, v:1)"""
    r,b,lp=r0,0,0;h=[];t=t0 or season_start(season)+3600;w=0
    for pl in places:
        d=PTS[r][pl];q=0 if r==5 else (100 if legacy else NEED[r]);h.append([t,pl,d,r] if legacy else [t,pl,d,r,q]);t+=gap
        if pl==0:w+=1
        if r==5:lp=max(0,lp+d)
        else:
            nb=b+d
            if nb>=q:r+=1;b=0
            else:b=max(0,nb)
    return {'v':1 if legacy else 2,'s':season,'r':r,'b':b if r<5 else 0,'lp':lp if r==5 else 0,'m':len(places),'w':w,'r0':r0,'h':h[-10:]},t
