/* ===== RUNESTONE RAMPARTS: styles (HUD, dock, info panel, build ring, hub, pause, victory, result) =====
   Stage units only (the stage is 1600x900, scaled by #wrap). Motion: transform and opacity only, springy one-shots, calm under reduced motion. */
{const st=document.createElement('style');st.textContent=`
.rph{position:absolute;left:0;top:0;width:1600px;height:900px;pointer-events:none;z-index:6;font-family:var(--ui);color:#fff8e8;--rpg:#ffd45a;--rpb:#5a4ca0;--sp:cubic-bezier(.3,1.5,.5,1)}
.rph[hidden]{display:none}
.rph button{pointer-events:auto;font-family:var(--ui);cursor:pointer}
.rph svg{display:block}
.rpplq{position:absolute;left:14px;top:12px;padding:6px 22px 8px;border-radius:14px;background:linear-gradient(180deg,#2a1e5af0,#140c36f2);border:2px solid #c99a3a;box-shadow:0 0 0 2px #12081f,0 8px 20px #0008}
.rpplq b{display:block;font:400 30px/1 'Pirata One',Georgia,serif;letter-spacing:.02em;background:linear-gradient(180deg,#fff6c0,#ffd45a 55%,#e08a1a);-webkit-background-clip:text;background-clip:text;color:transparent;filter:drop-shadow(0 2px 0 #12081f)}
.rpplq small{display:block;margin-top:2px;font:800 10.5px var(--ui);letter-spacing:.32em;color:#e8dcff;text-transform:uppercase}
.rpchips{position:absolute;left:50%;top:12px;transform:translateX(-50%);display:flex;gap:10px}
.rpchip{display:flex;align-items:center;gap:8px;height:48px;padding:0 18px 0 12px;border-radius:14px;background:linear-gradient(180deg,#221a52ee,#120c34f2);border:2px solid var(--rpb);box-shadow:0 0 0 2px #12081f,0 6px 16px #0007;font:600 16px var(--ui);color:#e8e0ff;position:relative}
.rpchip svg{width:26px;height:26px}.rpchip b{font:800 20px var(--ui);color:#fff8e8;min-width:52px;text-align:right}
.rpchip.bump b{animation:rpBump .3s var(--sp)}.rpchip.hurt{animation:rpHurt .4s ease}
.rpkb{position:absolute;left:12px;right:12px;bottom:5px;height:4px;border-radius:2px;background:#0a0618;overflow:hidden}.rpkb i{display:block;height:100%;background:linear-gradient(90deg,#ff5a6a,#ffd45a 45%,#7dffb0);transform-origin:left;transition:transform .3s ease}
@keyframes rpBump{40%{transform:scale(1.22)}}@keyframes rpHurt{20%{transform:translateX(-6px)}45%{transform:translateX(5px)}70%{transform:translateX(-3px)}}
.rptr{position:absolute;right:14px;top:12px;display:flex;gap:8px}
.rpsq{width:52px;height:52px;border-radius:14px;border:2px solid var(--rpb);background:linear-gradient(180deg,#2a2060,#160f3e);color:#fff8e8;font:800 18px var(--ui);display:grid;place-items:center;box-shadow:0 0 0 2px #12081f,0 6px 14px #0007;transition:transform .12s}
.rpsq svg{width:24px;height:24px}.rpsq:hover{transform:translateY(-2px)}.rpsq:active{transform:scale(.92)}.rpsq.on{border-color:var(--rpg);color:var(--rpg)}
.rpgo{position:absolute;right:18px;top:578px;display:flex;align-items:center;gap:12px;height:64px;padding:0 24px 0 10px;border:none;border-radius:20px;background:linear-gradient(180deg,#fff0a8,#ffd45a 45%,#e8a426);color:#3a1a04;box-shadow:0 0 0 3px #12081f,0 5px 0 #8a4a0a,0 12px 24px #0009;transition:transform .15s var(--sp)}
.rpgo:hover{transform:translateY(-3px)}.rpgo:active{transform:translateY(2px) scale(.97)}.rpgo[hidden]{display:none}
.rpgoi{width:46px;height:46px;border-radius:50%;background:#fff6c8;display:grid;place-items:center;box-shadow:inset 0 -3px 0 #e0a83a}.rpgoi svg{width:24px;height:24px;margin-left:3px}
.rpgot{display:flex;flex-direction:column;align-items:flex-start;line-height:1.05}.rpgot b{font:800 21px var(--ui)}.rpgot small{font:700 12px var(--ui);opacity:.75}
.rpgo.run{background:linear-gradient(180deg,#2a2060,#160f3e);color:#fff8e8;box-shadow:0 0 0 3px #12081f,0 5px 0 #0a0620,0 12px 24px #0009}.rpgo.run .rpgoi{background:#3a3070;box-shadow:none}.rpgo.run .rpgoi svg path{fill:#ffd45a;stroke:#ffd45a}
.rpgo.run.fast .rpgoi{background:#ffd45a}.rpgo.run.fast .rpgoi svg path{fill:#3a1a04;stroke:#3a1a04}
.rpboss{position:absolute;left:50%;top:72px;transform:translateX(-50%);display:flex;align-items:center;gap:10px;padding:6px 16px 6px 8px;border-radius:14px;background:#160c1cee;border:2px solid #ff8a3a;box-shadow:0 0 0 2px #12081f}
.rpboss[hidden]{display:none}.rpboss img{width:44px;height:44px}.rpboss b{display:block;font:400 22px/1 'Pirata One',Georgia,serif;color:#ffb06a}.rpboss em{display:block;width:340px;height:10px;margin-top:5px;border-radius:5px;background:#2a0e14;overflow:hidden}
.rpboss em i{display:block;height:100%;background:linear-gradient(90deg,#ff5a2a,#ffb04a);transform-origin:left;transition:transform .2s}
.rptoast{position:absolute;left:50%;top:74px;transform:translateX(-50%);padding:8px 20px;border-radius:12px;background:#0c0822e6;border:1px solid var(--rpb);font:700 17px var(--ui);white-space:nowrap}
.rptoast[hidden]{display:none}.rptoast.in{animation:rpTin .35s var(--sp)}@keyframes rpTin{from{opacity:0;transform:translate(-50%,-10px) scale(.9)}}
/* info panel */
.rpinfo{position:absolute;right:14px;top:78px;width:312px;padding:14px 16px 14px;border-radius:20px;background:linear-gradient(180deg,#241a5cf4,#120a34f6);border:2px solid #c99a3a;box-shadow:0 0 0 2px #12081f,0 14px 30px #000a;pointer-events:auto;animation:rpPin .3s var(--sp)}
.rpinfo[hidden]{display:none}@keyframes rpPin{from{opacity:0;transform:translateX(30px)}}
.rpix{position:absolute;right:6px;top:4px;width:28px;height:28px;border:none;border-radius:50%;background:transparent;color:#c4badf;font:700 22px/1 var(--ui)}.rpix:hover{color:#fff8e8}
.rpih{display:flex;gap:10px;align-items:center}.rpih img{width:96px;height:96px;flex:none;margin:-6px -4px -4px -8px}
.rpih span{min-width:0;padding-right:18px}.rpih b{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font:400 26px/1 'Pirata One',Georgia,serif;color:var(--rpg);text-shadow:0 2px 0 #12081f}.rpih em{display:flex;align-items:center;gap:2px;margin:4px 0;font:700 12px var(--ui);font-style:normal;color:#e8e0ff}.rpih em svg{display:inline-block}
.rpih small{display:block;font:500 12.5px/1.3 var(--ui);color:#c4badf}
.rpup{display:flex;flex-direction:column;align-items:center;width:100%;margin:12px 0 10px;padding:8px 10px;border:none;border-radius:14px;background:linear-gradient(180deg,#fff0a8,#ffd45a 45%,#e8a426);color:#3a1a04;box-shadow:0 0 0 2px #12081f,0 4px 0 #8a4a0a;transition:transform .12s}
.rpup b{font:800 18px var(--ui)}.rpup small{font:600 11.5px/1.25 var(--ui);opacity:.8}.rpup:hover{transform:translateY(-2px)}.rpup:active{transform:translateY(2px)}
.rpup.no{background:linear-gradient(180deg,#4a4270,#2c2650);color:#c4badf;box-shadow:0 0 0 2px #12081f,0 4px 0 #120c30}
.rpmax{margin:12px 0 10px;padding:10px;border-radius:14px;background:#0c0824;border:1px solid #c99a3a;text-align:center;font:800 15px var(--ui);color:var(--rpg)}
.rpsts{display:flex;flex-direction:column;gap:6px;padding:10px 12px;border-radius:14px;background:#0a0620cc;border:1px solid #3a3070}
.rpst{display:flex;align-items:center;justify-content:space-between;font:600 13px var(--ui);color:#e8e0ff}.rpst i{display:flex;gap:3px}
.rpst s{width:20px;height:9px;border-radius:3px;background:#2a2450}.rpst s.on{background:linear-gradient(180deg,#7ad8ff,#2a8ae0)}.rpst s.up{background:#7ad8ff55;outline:1px dashed #7ad8ff}
.rppri{display:flex;align-items:center;gap:6px;margin-top:10px;font:700 12px var(--ui);color:#c4badf}.rppri span{margin-right:auto}
.rppri button{padding:5px 11px;border-radius:9px;border:1px solid #3a3070;background:#160f3e;color:#e8e0ff;font:700 12.5px var(--ui)}.rppri button.on{background:#ffd45a;color:#3a1a04;border-color:#ffd45a}
.rpif{display:flex;align-items:center;justify-content:space-between;margin-top:10px;font:600 12.5px var(--ui);color:#c4badf}.rpoc{color:var(--rpg)}
.rpsell{padding:6px 14px;border-radius:10px;border:1px solid #8a3a4a;background:#3a1424;color:#ffb0ba;font:800 13px var(--ui)}.rpsell:hover{background:#5a1a30}
/* build ring around a pad */
.rpring{position:absolute;width:0;height:0}.rpring[hidden]{display:none}
.rprb{position:absolute;left:-46px;top:-46px;width:92px;height:92px;border-radius:50%;border:3px solid var(--c);background:radial-gradient(circle at 50% 35%,#2e2470,#120a34);box-shadow:0 0 0 3px #12081f,0 10px 20px #000a;
 transform:translate(var(--x),var(--y));animation:rpRb .32s var(--d) var(--sp) backwards;transition:transform .14s var(--sp);display:grid;place-items:center;padding:0}
.rprb img{width:74px;height:74px;margin-top:-12px}.rprb b{position:absolute;bottom:-10px;left:50%;transform:translateX(-50%);display:flex;align-items:center;gap:3px;padding:2px 8px;border-radius:9px;background:#12081f;color:var(--rpg);font:800 13px var(--ui);white-space:nowrap}.rprb b svg{width:14px;height:14px}
.rprb em{position:absolute;top:-22px;left:50%;transform:translateX(-50%);font:700 11.5px var(--ui);font-style:normal;color:#fff8e8;white-space:nowrap;opacity:0;transition:opacity .15s;text-shadow:0 1px 3px #000}
.rprb:hover{transform:translate(var(--x),var(--y)) scale(1.1)}.rprb:hover em{opacity:1}.rprb.no{filter:grayscale(.8) brightness(.7)}.rprb.no b{color:#ff8a9a}
@keyframes rpRb{from{transform:translate(0,0) scale(.2);opacity:0}}
/* new foe card */
.rpfoe{position:absolute;left:14px;top:468px;display:flex;align-items:center;gap:12px;width:360px;padding:10px 16px 10px 8px;border-radius:18px;background:linear-gradient(180deg,#2a1e5af2,#140c36f4);border:2px solid #ff8a3a;box-shadow:0 0 0 2px #12081f,0 10px 24px #000a}
.rpfoe[hidden]{display:none}.rpfoe.in{animation:rpFin .45s var(--sp)}@keyframes rpFin{from{opacity:0;transform:translateX(-40px)}}
.rpfoe img{width:84px;height:84px;flex:none}.rpfoe small{display:block;font:800 10.5px var(--ui);letter-spacing:.24em;color:#ffb06a}.rpfoe b{display:block;font:400 26px/1.05 'Pirata One',Georgia,serif;color:#fff8e8}.rpfoe em{display:block;font:500 12.5px/1.3 var(--ui);font-style:normal;color:#c4badf}
/* the dock */
.rpdock{position:absolute;left:0;top:660px;width:1600px;height:240px;padding:8px 12px 10px;display:flex;flex-direction:column;gap:8px}
.rpcmd{position:relative;display:flex;align-items:center;gap:14px;height:84px;padding:0 14px;border-radius:18px;background:linear-gradient(180deg,#1e1650,#0f0a2c);border:2px solid #6a4ab0;box-shadow:0 0 0 2px #12081f,inset 0 1px 0 #ffffff14;pointer-events:auto}
.rphint{width:250px;font:600 14.5px/1.35 var(--ui);color:#e8e0ff}
.rpword{position:relative;flex:1;height:62px;display:flex;align-items:center;justify-content:center;gap:2px;border-radius:14px;background:#070414;border:2px solid #5a4ca0;box-shadow:inset 0 2px 10px #000;font:800 40px var(--ui);letter-spacing:.14em;text-transform:uppercase;color:#fff8e8;cursor:text}
.rpword i{font-style:normal;position:relative}.rpword i.d{color:var(--rpg)}.rpword i.n::after{content:'';position:absolute;left:8%;right:18%;bottom:2px;height:4px;border-radius:2px;background:#9fe8ff}
.rpcaret{display:none}.rpword.bad{border-color:#ff5a6a}.rpword.shk{animation:rpHurt .3s ease}.rpword.pop{animation:rpPop .3s var(--sp)}@keyframes rpPop{40%{transform:scale(1.04)}}
.rpgain{position:absolute;left:50%;top:0;font:800 24px var(--ui);color:var(--rpg);text-shadow:0 2px 0 #12081f;pointer-events:none;animation:rpGain .9s ease-out forwards}@keyframes rpGain{to{transform:translate(-50%,-46px);opacity:0}}
.rpmeter{width:260px}.rpmeter label{display:block;font:700 16px var(--ui);color:#9fd0ff}.rpmeter label b{color:#fff8e8}
.rpmeter i{display:block;position:relative;height:16px;margin-top:6px;border-radius:8px;background:#0a0620;border:2px solid #5a4ca0;overflow:hidden}
.rpmeter s{position:absolute;inset:0;background:linear-gradient(180deg,#fff0a8,#ffd45a 50%,#e0a020);transform-origin:left;transform:scaleX(0);transition:transform .25s ease}
.rpmeter i.full::after{content:'';position:absolute;inset:0;background:linear-gradient(90deg,#fff0,#fff9,#fff0);animation:rpShine 1.6s ease-in-out infinite}@keyframes rpShine{from{transform:translateX(-100%)}to{transform:translateX(100%)}}
.rpcombo{display:block;height:14px;margin-top:4px;font:700 11.5px var(--ui);color:var(--rpg)}
.rpabs{display:flex;gap:8px}
.rpab{position:relative;width:112px;height:70px;border-radius:14px;border:2px solid #3a3070;background:linear-gradient(180deg,#221a52,#120c34);color:#a89cc8;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px;opacity:.6;transition:transform .12s,opacity .2s}
.rpab .rpabi svg{width:26px;height:26px}.rpab b{font:700 12.5px var(--ui);white-space:nowrap}.rpab small{font:700 11px var(--ui);opacity:.8}.rpab kbd{position:absolute;left:6px;top:4px;font:800 11px var(--ui);color:#c4badf}
.rpab.ok{opacity:1;color:#fff8e8;border-color:#ffd45a}.rpab.ok::after{content:'';position:absolute;inset:-2px;border-radius:14px;border:2px solid #fff6c0;animation:rpAbP 1.4s ease-in-out infinite;pointer-events:none}@keyframes rpAbP{50%{opacity:0}}
.rpab.aim{transform:translateY(-4px)}.rpab:hover{transform:translateY(-3px)}.rpab:active{transform:scale(.94)}
.rpcards{display:flex;gap:10px;height:132px}.rpcards[hidden]{display:none}
.rpcard{position:relative;flex:1;display:flex;align-items:center;gap:6px;padding:0 12px 0 4px;border-radius:18px;border:2px solid #3a3070;background:linear-gradient(180deg,#1c1446,#0e0a2a);color:#fff8e8;text-align:left;box-shadow:0 0 0 2px #12081f;transition:transform .15s var(--sp)}
.rpcard img{width:116px;height:116px;flex:none}.rpct b{display:block;font:400 26px/1 'Pirata One',Georgia,serif;color:var(--rpg);text-shadow:0 2px 0 #12081f}.rpct em{display:block;margin:2px 0 4px;font:700 13px var(--ui);font-style:normal;color:var(--c)}
.rpct small{display:block;font:500 12px/1.3 var(--ui);color:#c4badf}
.rpcost{position:absolute;left:14px;bottom:8px;display:flex;align-items:center;gap:4px;padding:2px 9px 2px 5px;border-radius:10px;background:#0a0620;font:800 15px var(--ui);color:var(--rpg)}.rpcost svg{width:18px;height:18px}
.rpcard:hover{transform:translateY(-4px)}.rpcard.on{border-color:#ffd45a;transform:translateY(-6px)}.rpcard.no{opacity:.62}.rpcard.no .rpcost{color:#ff8a9a}
.rpnext{width:236px;flex:none;padding:10px 12px;border-radius:18px;border:2px solid #3a3070;background:#0c0824;box-shadow:0 0 0 2px #12081f}
.rpnext small{display:block;font:800 11px var(--ui);letter-spacing:.18em;color:#c4badf;text-transform:uppercase}.rpnext div{display:flex;flex-wrap:wrap;gap:4px 8px;margin-top:6px}
.rpnext span{display:flex;align-items:center}.rpnext img{width:42px;height:42px}.rpnext b{font:800 14px var(--ui);color:#fff8e8;margin-left:-4px}
.rpkbd{display:flex;flex-direction:column;gap:5px;height:132px;pointer-events:auto}.rpkbd[hidden]{display:none}.rpkbd div{display:flex;justify-content:center;gap:5px}
.rph .rpkbd button{min-height:0;padding:0;line-height:1;margin:0}.rpkbd button{width:118px;height:28px;border-radius:8px;border:1px solid #5a4ca0;background:#1c1446;color:#fff8e8;font:800 16px var(--ui);text-transform:uppercase}.rpkbd .rpkx{width:200px;background:#2a2060}
/* menus */
#ov.rphubx,#ov.rpvx,#ov.rprx,#ov.rppx{background:rgba(9,5,22,.8)}
#ov.rphubx{padding:0;overflow:hidden}
.rphub{position:absolute;inset:0;text-align:left}.rphbg{position:absolute;inset:0;width:1600px;height:900px}
.rphl{position:absolute;left:64px;top:64px;width:600px}
.rpkick{margin:0;font:800 13px var(--ui);letter-spacing:.42em;color:#9fe8ff}
.rptitle{margin:12px 0 14px;font:400 92px/1 'Pirata One',Georgia,serif;background:linear-gradient(180deg,#fff6c0 8%,#ffd45a 46%,#e8801a);-webkit-background-clip:text;background-clip:text;color:transparent;filter:drop-shadow(0 4px 0 #12081f);animation:none}
.rptag{margin:0 0 18px;font:italic 400 21px Georgia,serif;color:#e8e0ff}
.rpready{display:flex;flex-direction:column;gap:6px;padding:20px 24px;border-radius:22px;background:linear-gradient(180deg,#241a5cf2,#120a34f4);border:2px solid #5a4ca0;box-shadow:0 0 0 2px #12081f,0 16px 36px #000a}
.rpready small{font:italic 400 17px Georgia,serif;color:#c4badf}.rpready b{font:400 48px/1 'Pirata One',Georgia,serif;color:#fff8e8}.rpready span{font:600 16px var(--ui);color:#c4badf}
.rphub .rpgo2,.rphub .rpgo2 span{color:#3a1a04}#ov .rphub .rpgo2{font:800 28px var(--ui)!important;padding:0 26px!important}.rpgo2{display:flex;align-items:center;justify-content:space-between;margin-top:10px;height:66px;padding:0 26px;border:none;border-radius:18px;background:linear-gradient(180deg,#fff0a8,#ffd45a 45%,#e8a426);color:#3a1a04;font:800 28px var(--ui);box-shadow:0 0 0 3px #12081f,0 6px 0 #8a4a0a;cursor:pointer;transition:transform .15s var(--sp)}
.rpgo2 i{font-style:normal;font-size:34px}.rpgo2:hover{transform:translateY(-3px)}.rpgo2:active{transform:translateY(2px)}
.rphow{display:flex;gap:10px;margin-top:16px}.rphow span{flex:1;display:flex;align-items:center;gap:8px;padding:10px 12px;border-radius:14px;background:#0c0824d8;border:1px solid #3a3070;font:600 13px/1.3 var(--ui);color:#e8e0ff}
.rphow b{flex:none;width:26px;height:26px;border-radius:50%;display:grid;place-items:center;background:#ffd45a;color:#3a1a04;font:800 14px var(--ui)}
.rphr{position:absolute;left:700px;top:64px;width:860px}
.rpmaps{display:flex;gap:14px}
.rpmc{position:relative;flex:1;display:flex;flex-direction:column;padding:0 0 12px;border-radius:20px;border:2px solid #3a3070;background:linear-gradient(180deg,#1c1446,#0e0a2a);color:#fff8e8;text-align:left;overflow:hidden;box-shadow:0 0 0 2px #12081f,0 10px 24px #0009;cursor:pointer;transition:transform .16s var(--sp)}
.rpmc canvas{width:100%;height:auto;display:block;border-bottom:2px solid #12081f}.rpmct{padding:10px 14px 0}.rpmct b{display:block;font:400 28px/1 'Pirata One',Georgia,serif;color:#fff8e8}.rpmct small{font:600 12.5px var(--ui);color:#c4badf}
.rpmcs{display:flex;gap:2px;padding:6px 12px 0}.rpmcb{padding:4px 14px 0;font:700 12.5px var(--ui);font-style:normal;color:var(--rpg,#ffd45a)}
.rpmc:hover{transform:translateY(-4px)}.rpmc.on{border-color:#ffd45a;box-shadow:0 0 0 2px #12081f,0 0 0 6px #ffd45a33,0 14px 28px #000a}
.rpmc.lock{cursor:not-allowed}.rpmc.lock canvas{opacity:.35}.rpmc.lock .rpmcb{color:#c4badf}
.rparm{margin-top:18px;padding:16px 18px;border-radius:20px;background:linear-gradient(180deg,#221a52f0,#120c34f4);border:2px solid #5a4ca0;box-shadow:0 0 0 2px #12081f}
.rparmh{display:flex;align-items:center;gap:12px}.rparmh b{font:400 30px/1 'Pirata One',Georgia,serif;color:#ffd45a}.rparmh span{display:flex;align-items:center;gap:4px;font:800 15px var(--ui)}
.rparmh em{flex:1;height:10px;border-radius:5px;background:#0a0620;border:1px solid #3a3070;overflow:hidden}.rparmh em i{display:block;height:100%;background:linear-gradient(90deg,#ffd45a,#ff9a3a);transform-origin:left}
.rpsks{display:flex;gap:10px;margin-top:12px}
.rpsk{position:relative;flex:1;display:flex;flex-direction:column;align-items:center;gap:2px;padding:8px 6px 10px;border-radius:16px;border:2px solid #3a3070;background:#0c0824;color:#fff8e8;cursor:pointer;transition:transform .15s var(--sp)}
.rpsk img{width:84px;height:84px}.rpsk b{font:700 12.5px var(--ui);text-align:center}.rpsk small{display:flex;align-items:center;gap:3px;font:700 11.5px var(--ui);color:#c4badf}
.rpsk:hover{transform:translateY(-3px)}.rpsk.on{border-color:#ffd45a}.rpsk.on small{color:#ffd45a}.rpsk.lock img{opacity:.32;filter:grayscale(1)}.rpsk.lock{cursor:default}
.rpttl{cursor:default}.rpttli{width:84px;height:84px;display:grid;place-items:center}.rpttli svg{width:60px;height:60px}.rpttl.lock .rpttli{opacity:.32}
.rparmn{margin:10px 0 0;font:500 12.5px var(--ui);color:#c4badf}

.rppause,.rpvic,.rpres{display:flex;flex-direction:column;align-items:center;gap:12px}
.rpph{display:flex;flex-wrap:wrap;justify-content:center;gap:10px 22px;max-width:960px;font:15px var(--ui);color:#c4badf}.rpph kbd{font:700 13px var(--ui);color:#ffd45a;border:1px solid #5a4ca0;border-radius:6px;padding:1px 7px;margin-right:4px;background:#1c1446}
.rpvic,.rpres{width:min(940px,100%);padding:30px 34px 26px;border-radius:26px;background:linear-gradient(180deg,#221a5af4,#100a30fa);border:2px solid #c99a3a;box-shadow:0 30px 80px #000c}
.rpvic h2,.rpres h2{font-size:64px;margin:0}.rpres.lose{border-color:#8a3a4a}.rpres.lose h2{color:#ff8a9a;text-shadow:0 3px 0 #3a0c18}
.rpvst{display:flex;gap:10px}.rpvst span{animation:rpStar .5s var(--d) var(--sp) backwards}@keyframes rpStar{from{transform:scale(0) rotate(-40deg);opacity:0}}
.rpvch{display:flex;gap:12px}.rpvic>small{font:500 13px var(--ui);color:#c4badf;max-width:620px;text-align:center}
.rpsub{margin:0;font:600 17px var(--ui);color:#e8e0ff}.rpnb{color:#7dffb0}
.rpres .res{gap:8px 28px;font-size:16px}.rpres .res>div{display:flex;flex-direction:column;align-items:center}.rpres .res b{font:800 26px var(--ui);color:#fff8e8}
.rpunls{display:flex;gap:12px}.rpunl{display:flex;flex-direction:column;align-items:center;padding:8px 14px;border-radius:16px;border:2px solid #ffd45a;background:#1c1446;animation:rpStar .5s .9s var(--sp) backwards}
.rpunl img{width:84px;height:84px}.rpunl b{font:700 14px var(--ui);color:#ffd45a}.rpunl small{font:600 11.5px var(--ui);color:#c4badf}
@media (prefers-reduced-motion:reduce){.rph *,.rphub *,.rpvic *,.rpres *{animation:none!important;transition:none!important}}`;document.head.appendChild(st)}
