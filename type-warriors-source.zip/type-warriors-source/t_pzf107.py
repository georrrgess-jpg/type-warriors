# python3 t_pzf107.py [out.html] : 10.7 The Crooked Cue patterned felts and premium cues (97bg, prefix pzf7).
# Nine new felts (six for sale 5,000-40,000, three won once from the Gilded Hoard players through pzUnlockSweep), baked overlays shown in
# the match backdrop, the hub table, the Trick Shot minis and the Cue Rack (cards, preview, live demo) with no per-frame cost; the balls stay
# readable on every felt (measured in a real match screenshot, classic and Ember Core sets, against Tavern Green); the felts tab scrolls
# (arrows, PREMIUM marks, the equipped felt in view) and fits at three sizes; three premium cues (20,000 / 35,000 / 60,000) are bought,
# equipped, drawn with their inlay and earn mastery; the DEV "own everything" cheat covers them all; no page errors.
import asyncio,os,sys,json,io
from playwright.async_api import async_playwright
from PIL import Image
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
SHOTS=os.path.join(HERE,'shots','w107_felts');os.makedirs(SHOTS,exist_ok=True)
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:600]),flush=True)
    if not ok:FAIL.append(name)
PRE="()=>{PZ_TUT_OFF=true;RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}return 1}"
SHOP=[('sakura',5000),('starlight',8000),('abyssal',12000),('damask',18000),('aurora',25000),('forge',40000)]
BEAT=[('genie','zephyra'),('velvet','hornsby'),('hoard','aurelion')]
NEW=[f for f,_ in SHOP]+[f for f,_ in BEAT]
CUES=[('stormcue',20000),('phoenixcue',35000),('hoardcue',60000)]
OLDF=['tavern','crimson','royal','violet','gold']
def lum(c):
    f=lambda v:(v/255)/12.92 if v/255<=.04045 else(((v/255)+.055)/1.055)**2.4
    return .2126*f(c[0])+.7152*f(c[1])+.0722*f(c[2])
def measure(png,balls):
    """per ball: mean body colour (ring .3R-.8R) and the felt around it (ring 1.6R-2.4R, upper-left half, clear of the shadow)"""
    im=Image.open(io.BytesIO(png)).convert('RGB');px=im.load();out=[]
    for (bid,x,y,R) in balls:
        bs=[0,0,0,0];fs=[];
        for dy in range(-int(R*2.5),int(R*2.5)+1):
            for dx in range(-int(R*2.5),int(R*2.5)+1):
                d=(dx*dx+dy*dy)**.5;X,Y=int(x+dx),int(y+dy)
                if .3*R<d<.8*R:
                    c=px[X,Y];bs[0]+=c[0];bs[1]+=c[1];bs[2]+=c[2];bs[3]+=1
                elif 1.6*R<d<2.4*R and dx+dy<0:
                    fs.append(px[X,Y])
        b=[bs[i]/bs[3] for i in range(3)];f=[sum(c[i] for c in fs)/len(fs) for i in range(3)]
        L=[.2126*c[0]+.7152*c[1]+.0722*c[2] for c in fs];m=sum(L)/len(L);sd=(sum((v-m)**2 for v in L)/len(L))**.5
        dist=sum((b[i]-f[i])**2 for i in range(3))**.5;lb,lf=lum(b),lum(f);cr=(max(lb,lf)+.05)/(min(lb,lf)+.05)
        out.append((bid,round(dist,1),round(cr,2),round(sd,1),round(lb,3),round(lf,3)))
    return out
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();er=[]
        pg=await b.new_page(viewport={'width':1600,'height':900});pg.on('pageerror',lambda e:er.append(str(e)[:300]));E=pg.evaluate
        await pg.goto(H);await pg.wait_for_timeout(1400);await E(PRE)
        # ------------------------------------------------------------------ entries
        r=await E("()=>PZ_FELT.map(f=>[f.id,f.price||0,f.beat||'',!!f.pat,f.n,f.a,f.b,f.c,(PZ_FTAG97[f.id]||'').length])")
        d={x[0]:x for x in r}
        chk('PZ_FELT keeps the five old felts first and plain, then six shop felts in price order and three Gilded Hoard felts, each with a pattern, colours and a tag line',
            [x[0] for x in r]==OLDF+NEW and all(not d[f][3] for f in OLDF) and [(d[f][0],d[f][1]) for f,_ in SHOP]==SHOP and all(d[f][3] and d[f][8]>10 for f in NEW) and [d[f][2] for f,_ in BEAT]==[w for _,w in BEAT],r)
        chk('shop felts cost between 5,000 and 40,000; the won felts have no price',all(5000<=q<=40000 for _,q in SHOP) and all(d[f][1]==0 for f,_ in BEAT),r)
        r=await E("()=>PZ_CUES.map(c=>[c.id,c.price==null?-1:c.price,!!c.prem,!!c.glow,c.inl||''])")
        dc={x[0]:x for x in r};ids=[x[0] for x in r]
        chk('three premium cues in the shop part of the rack (after Dragonbone, before the won cues) at 20,000 / 35,000 / 60,000 with a glow and an inlay',
            all(dc[c][1]==q and dc[c][2] and dc[c][3] and dc[c][4] for c,q in CUES) and ids.index('stormcue')==ids.index('dragonbone')+1 and ids.index('hoardcue')<ids.index('slime') and len(ids)==16,r)
        # ------------------------------------------------------------------ beat felts unlock through the sweep
        r=await E("""()=>{P.pz=null;const Z=PZS();const a=pzUnlockSweep().filter(u=>u.t==='felt').map(u=>u.id);Z.beat.zephyra=1;const b=pzUnlockSweep();Z.beat.hornsby=1;Z.beat.aurelion=2;const c=pzUnlockSweep();save();
          return [a,b.map(u=>[u.t,u.id,u.n]),c.filter(u=>u.t==='felt').map(u=>u.id).sort(),!!Z.felts.genie&&!!Z.felts.velvet&&!!Z.felts.hoard,pzUnlockSweep().length]}""")
        chk('beating Zephyra, Baron Hornsby and Aurelion once unlocks Genie Smoke, Crimson Velvet and Gilded Hoard through pzUnlockSweep (once each, named for the results)',
            r[0]==[] and r[1]==[['felt','genie','Genie Smoke']] and r[2]==['hoard','velvet'] and r[3] and r[4]==0,r)
        r=await E("()=>{const out=[];for(const k of ['zephyra','hornsby','aurelion']){const p=pzPrizeOf(k);out.push(p.map(x=>x.t+':'+x.it.id))}return out}")
        chk('once won, the next-prize list no longer offers those felts',all(not any(x.startswith('felt:') for x in l) for l in r),r)
        await E("()=>{P.pz=null;PZS();save()}")
        r=await E("()=>['zephyra','hornsby','aurelion'].map(k=>pzPrizeOf(k).filter(x=>x.t==='felt').map(x=>x.it.id+'/'+x.need).join())")
        chk('before winning, each of those players offers their felt as the prize (need 1)',r==['genie/1','velvet/1','hoard/1'],r)
        # ------------------------------------------------------------------ baked overlays everywhere a felt shows (pixel checks)
        r=await E("""()=>{const diff=(a,b,x0,y0,w,h)=>{const A=a.getContext('2d').getImageData(x0,y0,w,h).data,B=b.getContext('2d').getImageData(x0,y0,w,h).data;let s=0;for(let i=0;i<A.length;i+=4)s+=Math.abs(A[i]-B[i])+Math.abs(A[i+1]-B[i+1])+Math.abs(A[i+2]-B[i+2]);return s/(A.length/4)/3};
          const out={};for(const f of %s){PZF7.on=1;const a=pzBake(f,false);PZF7.on=0;const b=pzBake(f,false);PZF7.on=1;out[f]=Math.round(diff(a,b,PZ_G.x+40,PZ_G.y+40,800,360)*100)/100}
          PZF7.on=1;const t=pzBake('tavern',false);PZF7.on=0;const t2=pzBake('tavern',false);PZF7.on=1;out.tavern=diff(t,t2,PZ_G.x+40,PZ_G.y+40,800,360);return out}"""%json.dumps(NEW))
        chk('the match backdrop (pzBake) carries each new felt\'s pattern, subtly (mean change 0.4-14 levels on the cloth), and the old felts are untouched',all(.4<r[f]<14 for f in NEW) and r['tavern']==0,r)
        r=await E("""()=>{const Z=PZS();const sum=c=>{const d=c.getContext('2d').getImageData(0,0,c.width,c.height).data;let s=0;for(let i=0;i<d.length;i+=4)s+=d[i]*3+d[i+1]*7+d[i+2]*11;return s};const out={};
          for(const f of ['hoard','starlight']){Z.felts[f]=1;Z.felt=f;PZF7.on=1;PZ97.tb=null;const a=sum(pz97Table());PZF7.on=0;PZ97.tb=null;const b=sum(pz97Table());
           PZF7.on=1;PZ97T.mini={};const c=sum(pz97Mini(148,88,11));PZF7.on=0;PZ97T.mini={};const d=sum(pz97Mini(148,88,11));
           const Pp=pzPersp(670,1.72,1.12,619,144),it=PZ_FELT.find(x=>x.id===f);PZF7.on=1;for(const k in PZ_PB)delete PZ_PB[k];const e=sum(pzPersBake(Pp,it,1340,720));PZF7.on=0;for(const k in PZ_PB)delete PZ_PB[k];const g=sum(pzPersBake(Pp,it,1340,720));
           const cv=document.createElement('canvas');cv.width=740;cv.height=264;PZF7.on=1;pzFeltCard97(cv,it,false);const h=sum(cv);PZF7.on=0;pzFeltCard97(cv,it,false);const i=sum(cv);
           out[f]=[a!==b,c!==d,e!==g,h!==i]}PZF7.on=1;PZ97.tb=null;PZ97T.mini={};for(const k in PZ_PB)delete PZ_PB[k];Z.felt='tavern';save();return out}""")
        chk('the hub table, the Trick Shot minis, the Cue Rack perspective table and the felt cards all show the pattern',all(all(v) for v in r.values()),r)
        r=await E("""()=>{const t=[];const T0=performance.now();for(const k in PZF7.tex)delete PZF7.tex[k];for(const f of %s){const a=performance.now();pzf7Tex(f);t.push([f,Math.round(performance.now()-a)])}return t}"""%json.dumps(NEW))
        chk('each pattern bakes once, quickly (under 900 ms each headless, once per felt per session), and is cached',all(x[1]<900 for x in r) and await E("()=>pzf7Tex('forge')===pzf7Tex('forge')"),r)
        # ------------------------------------------------------------------ a real match on every felt: per-frame cost and ball readability
        await E("()=>{const Z=PZS();for(const f of PZ_FELT)Z.felts[f.id]=1;Z.ballsets.lava=1;Z.felt='tavern';Z.balls='classic';save();casinoOpen();gameOpen('pz');pzStart({opp:'gloop',practice:true,seed:7});setTimeout(()=>{const i=document.getElementById('pzintro');if(i)i.click()},500);0}")
        await pg.wait_for_timeout(3200)
        LAY="""(f)=>{const Z=PZS();Z.felt=f;PZ.bk=pzBake(f,PZ.dim);const B=PZ.B;for(let i=0;i<16;i++){const b=B[i];b.on=true;b.vx=b.vy=0;b.x=110+(i%8)*94;b.y=i<8?150:300}PZ_BS.dirtyAll=1;
           return B.map(b=>[b.id,PZ_G.x+b.x,PZ_G.y+b.y,PZ_PHY.R])}"""
        async def frame_cost(f):
            await E(LAY,f);await pg.wait_for_timeout(200)
            return await E("()=>{const c=document.createElement('canvas');c.width=1600;c.height=900;const g=c.getContext('2d');const t=[];for(let i=0;i<40;i++){const a=performance.now();pzRender(g);t.push(performance.now()-a)}t.sort((x,y)=>x-y);return t[20]}")
        f0=await frame_cost('tavern');f1=await frame_cost('forge');f2=await frame_cost('hoard')
        chk('the table frame costs the same on a patterned felt (median render within 0.5 ms of Tavern Green)',abs(f1-f0)<.5 and abs(f2-f0)<.5,(f0,f1,f2))
        res={}
        for st in ['classic','lava']:
            await E("(s)=>{PZS().balls=s;pzbSetup(PZ.lite?36:52,s);PZ_BS.dirtyAll=1;0}",st)
            for f in OLDF+NEW:
                balls=await E(LAY,f);await pg.wait_for_timeout(260)
                png=await pg.screenshot();res[(st,f)]=measure(png,balls)
                if st=='classic' or f in ('forge','starlight','hoard'):open(os.path.join(SHOTS,f'read_{st}_{f}.png'),'wb').write(png)
        # the bar: no new felt may be less readable than the felts already in the game (their worst case per ball, per set), within 15%
        bad=[];info={}
        for st in ['classic','lava']:
            old={f:res[(st,f)] for f in OLDF}
            for f in NEW:
                m=res[(st,f)];row=[]
                for k,x in enumerate(m):
                    od=min(o[k][1] for o in old.values());oc=min(o[k][2] for o in old.values())
                    ok=x[1]>=min(od*.85,40) or x[2]>=min(oc*.85,3)
                    row.append((x[0],x[1],x[2]))
                    if not ok:bad.append((st,f,'ball',x[0],'dist',x[1],'old worst',od,'contrast',x[2],'old worst',oc))
                eight=[x for x in m if x[0]==8][0];cue=[x for x in m if x[0]==0][0]
                if not eight[4]<eight[5]:bad.append((st,f,'the 8 is not darker than the cloth',eight))
                if not cue[4]>cue[5]*1.6:bad.append((st,f,'the cue ball is not clearly lighter than the cloth',cue))
                osd=max(o[k][3] for o in old.values() for k in range(16))
                if max(x[3] for x in m)>osd*1.5:bad.append((st,f,'the cloth around the balls is busier than the old felts',max(x[3] for x in m),osd))
                info[f'{st}/{f}']=sorted(row,key=lambda r:r[1])[:3]
        chk('every ball stays readable on every new felt in a real match (classic and Ember Core sets): per ball, colour distance or contrast at least 85%% of the worst of the five old felts, the 8 darker than the cloth, the cue ball clearly lighter, the cloth around the balls no busier than the old felts',not bad,bad)
        print('   three hardest balls per felt (id, colour distance, contrast):',json.dumps(info))
        await E("()=>{try{pzForfeit()}catch(e){}}");await pg.wait_for_timeout(300)
        # ------------------------------------------------------------------ hold to buy a felt; one coin short
        await E("()=>{P.pz=null;const Z=PZS();P.gold=13000;save();PZ.rackTab='felts';PZ.rackSel=null;pzCueRack();0}");await pg.wait_for_timeout(1500)
        await E("()=>{const c=document.querySelector('.pzki[data-i=abyssal]');c.scrollIntoView({block:'center'});0}");await pg.wait_for_timeout(400)
        await pg.click('.pzki[data-i=abyssal]');await pg.wait_for_timeout(400)
        await pg.hover('#pzkbuy');await pg.mouse.down();await pg.wait_for_timeout(300);await pg.mouse.up();await pg.wait_for_timeout(300)
        r=await E("()=>[P.gold,!!PZS().felts.abyssal]");chk('felts: letting go early buys nothing',r==[13000,False],r)
        await pg.hover('#pzkbuy');await pg.mouse.down();await pg.wait_for_timeout(1500);await pg.mouse.up();await pg.wait_for_timeout(700)
        r=await E("()=>[P.gold,!!PZS().felts.abyssal,PZS().felt,(document.querySelector('.pzki[data-i=abyssal] .pzc97')||{}).textContent]")
        chk('felts: holding buys Abyssal Tide for exactly 12,000, owns it, puts it in your hand and the card says EQUIPPED',r[0]==1000 and r[1] and r[2]=='abyssal' and 'EQUIPPED' in (r[3] or ''),r)
        await E("()=>{P.gold=7999;pzRk97Wall();pzRk97Detail();0}");await pg.wait_for_timeout(300)
        await E("()=>{document.querySelector('.pzki[data-i=starlight]').scrollIntoView({block:'center'});0}");await pg.wait_for_timeout(300)
        await pg.click('.pzki[data-i=starlight]');await pg.wait_for_timeout(300)
        await pg.hover('#pzkbuy');await pg.mouse.down();await pg.wait_for_timeout(1500);await pg.mouse.up();await pg.wait_for_timeout(300)
        r=await E("()=>[P.gold,!!PZS().felts.starlight,(document.querySelector('#pzkbuy small')||{}).textContent]")
        chk('felts: one coin short (7,999 for 8,000) buys nothing and says what is missing',r[0]==7999 and not r[1] and 'MORE' in (r[2] or '').upper(),r)
        # the strip
        await E("()=>{const Z=PZS();Z.felts.hoard=1;Z.felt='hoard';save();PZ.rackTab='felts';PZ.rackSel=null;pzCueRack();0}");await pg.wait_for_timeout(1500)
        r=await E("""()=>{const s=document.querySelector('#pzkwall .pzkfg'),c=[...s.querySelectorAll('.pzkfc')],e=s.querySelector('.pzkfc.sel').getBoundingClientRect(),v=s.getBoundingClientRect();
          return [c.length,c.filter(x=>x.classList.contains('pzf7p')).map(x=>x.dataset.i),s.scrollHeight>s.clientHeight+20,s.scrollTop>0,e.top>=v.top-2&&e.bottom<=v.bottom+2,!!document.querySelector('.pzf7nav.u.on'),document.querySelectorAll('.pzf7sec').length,
           (document.querySelector('.pzktabs9 button[data-t=felts] em')||{}).textContent]}""")
        chk('felts tab: fourteen cards that scroll, PREMIUM on the six paid felts, the equipped Gilded Hoard scrolled into view, the up arrow on, section labels, the tab count',
            r[0]==14 and sorted(r[1])==sorted(f for f,_ in SHOP) and r[2] and r[3] and r[4] and r[5] and r[6]==3 and r[7]=='3/14',r)
        await pg.click('.pzf7nav.u');await pg.wait_for_timeout(900)
        r=await E("()=>{const s=document.querySelector('#pzkwall .pzkfg');return [s.scrollTop,!!document.querySelector('.pzf7nav.d.on')]}")
        chk('felts tab: the arrow scrolls the grid back up and the down arrow appears',r[1],r)
        await pg.screenshot(path=os.path.join(SHOTS,'t_rack_felts_1600.png'))
        # the Cue Rack live ball-set table (it bakes the equipped felt once): same frame cost on a patterned felt
        fc={}
        for f in ['tavern','hoard','tavern','hoard']:
            await E("(f)=>{const Z=PZS();Z.felts[f]=1;Z.felt=f;save();PZ.rackTab='balls';PZ.rackSel=null;pzCueRack();0}",f);await pg.wait_for_timeout(1600)
            t=await E("()=>{const L=LIVE.find(x=>x.cv&&x.cv.id==='pzkdemo');const t=[];for(let i=0;i<40;i++){const a=performance.now();L.fn();t.push(performance.now()-a)}t.sort((x,y)=>x-y);return t[20]}")
            fc[f]=min(fc.get(f,99),t)
        chk('the Cue Rack live table costs the same per frame on the Gilded Hoard felt as on Tavern Green (median within 1 ms)',abs(fc['hoard']-fc['tavern'])<1,fc)
        print('   live table median ms:',fc)
        await E("()=>{PZ.rackTab='felts';PZ.rackSel=null;pzCueRack();0}");await pg.wait_for_timeout(1200)
        # the Regulars: a Gilded Hoard player's card names the felt (fake card when the venue module is not in this build)
        r=await E("""()=>{const Z=PZS();Z.beat.mortimer=1;save();pzRegs();const grid=document.querySelector('.pzrggrid')||document.querySelector('.pzrg').parentElement;
          if(!grid.querySelector('.pzrg[data-k=zephyra]'))grid.insertAdjacentHTML('beforeend','<button class="pzrg" data-k="zephyra"><b>Zephyra</b><div class="pzrgf">first win +700 gold</div></button>');return 1}""")
        await pg.wait_for_timeout(400)
        r=await E("()=>{const c=document.querySelector('.pzrg[data-k=zephyra]');return c?[...c.querySelectorAll('.pzrgf')].map(x=>x.textContent):null}")
        chk('the Regulars: a Gilded Hoard player\'s card names the felt they give (and keeps its own line)',r and 'Genie Smoke felt · win once' in r and len(r)>=1,r)
        # ------------------------------------------------------------------ cues: buy, equip, draw, mastery
        await E("()=>{P.pz=null;PZS();P.gold=20000;save();PZ.rackTab='cues';PZ.rackSel=null;pzCueRack();0}");await pg.wait_for_timeout(1500)
        r=await E("()=>{const w=document.getElementById('pzkwall').getBoundingClientRect(),c=[...document.querySelectorAll('.pzkc97')];return [c.length,c.filter(x=>x.classList.contains('pzf7p')).length,c.every(x=>{const a=x.getBoundingClientRect();return a.left>=w.left-1&&a.right<=w.right+1&&a.bottom<=w.bottom+1})]}")
        chk('cues wall: sixteen cues, the three premium ones marked, every column inside the wall',r==[16,3,True],r)
        await pg.click('.pzki[data-i=stormcue]');await pg.wait_for_timeout(300)
        await pg.hover('#pzkbuy');await pg.mouse.down();await pg.wait_for_timeout(1500);await pg.mouse.up();await pg.wait_for_timeout(700)
        r=await E("()=>[P.gold,!!PZS().cues.stormcue,PZS().cue]");chk('cues: hold to buy the Storm Caller for exactly 20,000, owned and equipped',r==[0,True,'stormcue'],r)
        await E("()=>{P.gold=34999;pzRk97Wall();pzRk97Detail();0}");await pg.click('.pzki[data-i=phoenixcue]');await pg.wait_for_timeout(300)
        await pg.hover('#pzkbuy');await pg.mouse.down();await pg.wait_for_timeout(1500);await pg.mouse.up();await pg.wait_for_timeout(300)
        r=await E("()=>[P.gold,!!PZS().cues.phoenixcue]");chk('cues: one coin short buys nothing',r==[34999,False],r)
        r=await E("""()=>{const sum=(s,x0,x1)=>{const d=s.c.getContext('2d').getImageData(x0,0,x1-x0,s.H).data;let a=0;for(let i=0;i<d.length;i+=4)a+=d[i]*3+d[i+1]*7+d[i+2]*11;return a};const out={};
          for(const id of ['stormcue','phoenixcue','hoardcue']){const it=PZ_CUES.find(x=>x.id===id);for(const k in PZ_CUE.cache)if(k.startsWith(id))delete PZ_CUE.cache[k];const a=pzCueSprite(id);const keep=it.inl;it.inl='';for(const k in PZ_CUE.cache)if(k.startsWith(id))delete PZ_CUE.cache[k];
           const b=pzCueSprite(id);it.inl=keep;for(const k in PZ_CUE.cache)if(k.startsWith(id))delete PZ_CUE.cache[k];const c=pzCueSprite(id);const L=PZ_CUE.L,fx0=(L+10-L*.58-80)*2,fx1=(L+10-L*.58)*2;
           out[id]=[a.W===b.W&&a.H===b.H,sum(a,fx0,fx1)!==sum(b,fx0,fx1),sum(a,10,60)!==sum(b,10,60),sum(a,0,a.W)===sum(c,0,c.W)]}return out}""")
        chk('cues: each premium cue has its own forearm inlay and butt motif, at the standard sprite size, drawn the same every time',all(all(v) for v in r.values()),r)
        r=await E("""()=>{const Z=PZS();Z.cues.hoardcue=1;Z.mast=Z.mast||{};Z.mast.hoardcue=0;Z.mastPaid=Z.mastPaid||{};delete Z.mastPaid.hoardcue;const g0=P.gold;const m=pzMastAdd('hoardcue',460);const s4=pzCueSprite('hoardcue');Z.mast.hoardcue=3300;const s10=pzCueSprite('hoardcue');
          return [m.from,m.to,P.gold-g0,pzMastInfo('hoardcue').lv,s4!==s10&&s4.W===s10.W,pzMastCol('hoardcue')]}""")
        chk('cues: mastery works for a premium cue (Lv1 to Lv4 pays 150 gold, Lv10 changes the sprite, mastery colour is its glow)',r[0]==1 and r[1]==4 and r[2]==150 and r[4] and r[5]=='#ffcf5a',r)
        await E("()=>{const Z=PZS();Z.cue='hoardcue';Z.mast.hoardcue=700;save();casinoOpen();gameOpen('pz');pzStart({opp:'gloop',practice:true,seed:7});setTimeout(()=>{const i=document.getElementById('pzintro');if(i)i.click()},500);0}")
        await pg.wait_for_timeout(3200)
        r=await E("()=>[PZ.on,Object.keys(PZ_CUE.cache).some(k=>k.startsWith('hoardcue'))]")
        chk('cues: a match draws the equipped premium cue',all(r),r)
        await pg.screenshot(path=os.path.join(SHOTS,'t_match_hoardcue.png'))
        await E("()=>{try{pzForfeit()}catch(e){}}");await pg.wait_for_timeout(300)
        # ------------------------------------------------------------------ DEV cheat
        await E("()=>{P.pz=null;PZS();devAct('x:pzown');0}")
        r=await E("()=>{const Z=PZS();return [PZ_FELT.every(f=>Z.felts[f.id]),PZ_CUES.every(c=>Z.cues[c.id])]}")
        chk('the DEV "own everything" cheat covers the new felts and cues',all(r),r)
        chk('no page errors (1600x900)',not er,er)
        await pg.close()
        # ------------------------------------------------------------------ fit at three sizes
        for vw,vh in [(1600,900),(1280,720),(1024,640)]:
            pg=await b.new_page(viewport={'width':vw,'height':vh});er2=[];pg.on('pageerror',lambda e:er2.append(str(e)[:300]))
            await pg.goto(H);await pg.wait_for_timeout(1300);await pg.evaluate(PRE)
            await pg.evaluate("()=>{const Z=PZS();for(const f of PZ_FELT)Z.felts[f.id]=1;for(const c of PZ_CUES)Z.cues[c.id]=1;Z.felt='forge';P.gold=100000;save();PZ.rackTab='felts';PZ.rackSel=null;pzCueRack();0}");await pg.wait_for_timeout(1700)
            r=await pg.evaluate("""()=>{const w=document.getElementById('pzkwall').getBoundingClientRect(),s=document.querySelector('#pzkwall .pzkfg').getBoundingClientRect(),o=[];if(s.left<w.left-1||s.right>w.right+1||s.top<w.top-1||s.bottom>w.bottom+1)o.push('grid outside the wall');
              for(const c of document.querySelectorAll('.pzkfc')){const a=c.getBoundingClientRect();if(a.right>s.right+1||a.left<s.left-1)o.push('card wider than the grid '+c.dataset.i);const t=c.querySelector('b');if(t&&t.scrollWidth>t.clientWidth+1)o.push('clipped '+t.textContent)}
              for(const n of document.querySelectorAll('.pzf7nav.on')){const a=n.getBoundingClientRect();if(a.left<w.left||a.right>w.right)o.push('arrow outside')}return o}""")
            chk(f'Cue Rack felts tab at {vw}x{vh}: the scrolling grid stays inside the wall, names not clipped',r==[],r)
            await pg.screenshot(path=os.path.join(SHOTS,f't_rack_felts_{vw}x{vh}.png'))
            await pg.evaluate("()=>{PZ.rackTab='cues';PZ.rackSel='phoenixcue';pzCueRack();0}");await pg.wait_for_timeout(1500)
            r=await pg.evaluate("()=>{const w=document.getElementById('pzkwall').getBoundingClientRect(),c=[...document.querySelectorAll('.pzkc97')];return c.filter(x=>{const a=x.getBoundingClientRect();return a.left<w.left-1||a.right>w.right+1||a.bottom>w.bottom+1}).map(x=>x.dataset.i)}")
            chk(f'Cue Rack cues tab at {vw}x{vh}: sixteen columns inside the wall',r==[],r)
            await pg.screenshot(path=os.path.join(SHOTS,f't_rack_cues_{vw}x{vh}.png'))
            chk(f'no page errors at {vw}x{vh}',not er2,er2);await pg.close()
        await b.close()
    print(f'\n{N[0]-len(FAIL)} / {N[0]} passed',flush=True)
    if FAIL:print('FAILED:',FAIL)
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
