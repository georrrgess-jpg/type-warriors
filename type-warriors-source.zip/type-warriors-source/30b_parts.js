/* ---- body parts: cape, wings, legs, arms, cuirass, belt, skirt ---- */
function arCape(g,K,c){const kind=K.cape;if(!kind)return;if(kind==='wings'){arWings(g,K,c);return}
 const {T,hc,t,cw}=c;const cc=K.cc==='hc'?hc:K.cc==='hcd'?shade(hc,-.3):(K.cc||c.D);
 const len={short:.55,long:.95,royal:1,tatter:1.05,galaxy:1.1}[kind]||.9,ex=-40-cw*1.5-len*6,ey=-96+len*88;
 const path=()=>{g.beginPath();g.moveTo(-8,-98);g.quadraticCurveTo(-42-cw,-70,ex,ey);
  if(kind==='tatter'){const x1=-10,y1=-52;for(let i=1;i<=6;i++){const u=i/6;g.lineTo(ex+(x1-ex)*u+(i%2?-3:3)+Math.sin(t*4+i)*2.4,ey+(y1-ey)*u+(i%2?8:-2))}}
  g.lineTo(-10,-52);g.closePath()};
 g.save();path();let fc=shade(cc,-.4),fc2=shade(cc,.14);g.fillStyle=hgr(g,-50,-8,fc,fc2);g.fill();g.clip();
 if(kind==='galaxy'){g.fillStyle=vgr(g,-98,-8,'#3a2a8a55','#00000000');g.fillRect(-70,-100,70,100);for(let i=0;i<22;i++){const sx=-14-rnd(i+3)*36-cw*.6,sy=-94+rnd(i+9)*86,tw=.45+.55*Math.abs(Math.sin(t*2+i*1.9));g.globalAlpha=tw;g.fillStyle=i%4?'#ffffff':'#ffe9a0';g.fillRect(sx,sy,i%5?1.3:2.1,i%5?1.3:2.1)}g.globalAlpha=1}
 g.fillStyle=hgr(g,-34,-8,'#00000000','#00000066');g.fillRect(-60,-100,60,100);
 g.strokeStyle='#00000040';g.lineWidth=1.3;for(let i=0;i<3;i++){g.beginPath();g.moveTo(-14-i*3,-90);g.quadraticCurveTo(-30-cw*.8-i*4,-60,-30-cw*1.2-i*5-len*4,-92+len*84);g.stroke()}
 g.strokeStyle='#ffffff26';g.lineWidth=1.5;g.beginPath();g.moveTo(-12,-92);g.quadraticCurveTo(-34-cw,-66,-36-cw*1.4-len*5,-90+len*80);g.stroke();g.restore();
 g.save();path();g.lineWidth=1.3;g.strokeStyle='#000000b8';g.stroke();g.restore();
 if(kind==='royal'||kind==='galaxy'||kind==='long'&&K.trim){g.strokeStyle=T;g.lineWidth=2.2;g.beginPath();g.moveTo(-8,-98);g.quadraticCurveTo(-42-cw,-70,ex,ey);g.lineTo(-10,-52);g.stroke()}}
function arWings(g,K,c){const {M,D,T,t,my}=c,fl=Math.sin(t*1.7)*.07;
 for(const k of[1,0]){g.save();g.translate(-12,-96);const n=9;
  for(let row=0;row<2;row++)for(let i=0;i<n;i++){const a=Math.PI*(1.05+i/(n-1)*.5)+fl*(1+i*.1)+(k?.07:0),L=(row?.44:1)*(58+(n-1-i)*5.2)*(k?.84:1);
   let col=my===1?hsx(t*40+i*26+k*30+row*15,78,row?82:72):row?mixc(M,T,.55):(i%2?M:mixc(M,D,.28));if(k)col=shade(col,-.24);
   g.save();g.rotate(a);arBev(g,[0,-4.2,L*.32,-8.5,L*.72,-7,L,0,L*.72,7,L*.32,8.5,0,4.2],col,{sm:1,ow:1.1});g.strokeStyle='#00000040';g.lineWidth=.9;g.beginPath();g.moveTo(3,0);g.lineTo(L*.88,0);g.stroke();g.restore()}
  g.restore()}}
function arLeg(g,K,c,hx,kx,fx,front){const {M,D,T}=c,k=K.leg,dm=v=>front?v:shade(v,-.3),un=K.under||D;
 let th,sh,kn=null,bt,cf,wr=null;
 if(k==='cloth'){th=sh=shade(un,.06);bt=shade(un,-.4);cf=null;wr=T}
 else if(k==='leather'){th=sh=un;kn=M;bt=shade(M,-.4);cf=M}
 else if(k==='mail'){th=sh=M;bt=shade(D,.05);cf=T}
 else{th=M;sh=shade(M,.08);kn=M;bt=shade(D,-.05);cf=T}
 arSeg(g,hx,-48,kx,-25,12,dm(th));arSeg(g,kx,-25,fx,-6,10.5,dm(sh));
 const at=(a,b,u)=>a+(b-a)*u,band=(x0,y0,x1,y1,u,w,col)=>{const x=at(x0,x1,u),y=at(y0,y1,u),dx=x1-x0,dy=y1-y0,L=Math.hypot(dx,dy);arSeg(g,x-dx/L*1.3,y-dy/L*1.3,x+dx/L*1.3,y+dy/L*1.3,w,col)};
 if(k==='mail'){g.save();g.setLineDash([.9,2.5]);g.lineCap='butt';g.strokeStyle='#00000055';g.lineWidth=8;g.beginPath();g.moveTo(hx,-48);g.lineTo(kx,-25);g.lineTo(fx,-6);g.stroke();g.restore()}
 if(wr){g.strokeStyle=dm(wr);g.lineWidth=1.4;for(let i=0;i<4;i++){const u=.2+i*.2,x=at(kx,fx,u),y=at(-25,-6,u);g.beginPath();g.moveTo(x-5,y-1.8);g.lineTo(x+5,y+1.8);g.stroke()}}
 if(k==='plate'){band(hx,-48,kx,-25,.28,12.6,dm(T));band(kx,-25,fx,-6,.78,11.2,dm(T))}
 if(kn){if(k==='leather')arBevE(g,kx+2,-25,5.4,5.8,dm(kn),{});else arBev(g,[kx-5.5,-32,kx+5,-31.5,kx+10,-26,kx+6.5,-19.4,kx-5,-19.4,kx-7.4,-25.6],dm(kn),{sm:1,edge:T,ew:2.2})}
 /* boot */
 const bp=[fx-7,-16,fx+5,-16,fx+6,-9,fx+15,-6,fx+18,-2,fx+15.5,.5,fx-9,.5,fx-9,-8];
 arBev(g,bp,dm(bt),{sm:0});
 g.fillStyle=front?'#0008':'#0006';g.fillRect(fx-9,-1.6,26,2.1);
 if(cf)arBev(g,[fx-8,-18,fx+6,-18,fx+6.5,-12.5,fx-8.5,-12.5],dm(cf),{ow:1.1});
 if(k==='plate'||k==='mail')arBev(g,[fx+9,-6.6,fx+16.5,-4.4,fx+18,-1.6,fx+9.5,-1.6],dm(T),{ow:1})}
function arHand(g,K,c,x,y,front){const {M,D,T}=c,k=K.leg,dm=v=>front?v:shade(v,-.28);let gl=k==='cloth'?shade(D,-.25):k==='leather'?shade(D,-.35):k==='mail'?shade(D,.05):shade(M,-.12);if(K.glove)gl=K.glove;
 arBevE(g,x,y,7.2,7.2,dm(gl),{ow:1.2});if(k==='plate'||k==='mail'){g.strokeStyle='#00000066';g.lineWidth=.9;g.beginPath();g.moveTo(x+1,y-5);g.lineTo(x+2,y+5);g.moveTo(x+4,y-4);g.lineTo(x+5,y+4);g.stroke()}}
function arArm(g,K,c,sx,sy,hx,hy,front){const {M,D,T}=c,k=K.leg,dm=v=>front?v:shade(v,-.28),un=K.under||D,ex=(sx+hx)/2-4,ey=(sy+hy)/2+7,at=(a,b,u)=>a+(b-a)*u;
 let up,fa,el=false;
 if(k==='cloth'){up=fa=shade(un,.1)}else if(k==='leather'){up=un;fa=M}else if(k==='mail'){up=fa=M}else{up=shade(un,.1);fa=M;el=true}
 arSeg(g,sx,sy,ex,ey,11,dm(up));arSeg(g,ex,ey,hx,hy,10,dm(k==='cloth'?up:un));
 if(k==='mail'){g.save();g.setLineDash([.9,2.5]);g.lineCap='butt';g.strokeStyle='#00000055';g.lineWidth=7.5;g.beginPath();g.moveTo(sx,sy);g.lineTo(ex,ey);g.lineTo(hx,hy);g.stroke();g.restore()}
 if(k!=='cloth'){const b0=.3,b1=.86;arSeg(g,at(ex,hx,b0),at(ey,hy,b0),at(ex,hx,b1),at(ey,hy,b1),12.4,dm(fa));
  for(const u of[b0+.02,b1-.02])arSeg(g,at(ex,hx,u),at(ey,hy,u),at(ex,hx,u+(u<.5?.07:-.07)),at(ey,hy,u+(u<.5?.07:-.07)),13.2,dm(T))}
 else{arSeg(g,at(ex,hx,.76),at(ey,hy,.76),at(ex,hx,.9),at(ey,hy,.9),11,dm(T))}
 if(el)arBevE(g,ex,ey,6.2,6.2,dm(M),{edge:T,ew:2})}
/* ---- cuirass ---- */
function arTorso(g,K,c){const {M,D,T,hc,t}=c,m=K.mat,P0=[-17,-94,19,-94,18,-76,16,-46,-14,-46,-16,-76],B=[-18,-94,20,-46];
 arPP(g,P0);g.fillStyle=hgr(g,-17,19,shade(M,.2),shade(M,-.28));g.fill();g.save();arPP(g,P0);g.clip();
 const fold=()=>{g.strokeStyle='#00000030';g.lineWidth=1.5;for(const x of[-9,-2,6,13]){g.beginPath();g.moveTo(x,-92);g.quadraticCurveTo(x+3,-70,x-1,-47);g.stroke()}g.strokeStyle='#ffffff1c';g.lineWidth=1;for(const x of[-8,-1,7,14]){g.beginPath();g.moveTo(x+1.2,-92);g.quadraticCurveTo(x+4,-70,x,-47);g.stroke()}};
 const stitch=(x0,y0,x1,y1,col)=>{g.save();g.setLineDash([2,2]);g.strokeStyle=col||'#e8c890bb';g.lineWidth=.9;g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.stroke();g.restore()};
 if(m==='cloth'||m==='quilt'){
  if(m==='quilt'){g.strokeStyle='#00000040';g.lineWidth=1;for(let i=-60;i<70;i+=7){g.beginPath();g.moveTo(-18+i*.6,-94);g.lineTo(-18+i*.6+50,-44);g.moveTo(22+i*.6,-94);g.lineTo(22+i*.6-50,-44);g.stroke()}g.strokeStyle='#ffffff1a';for(let i=-60;i<70;i+=7){g.beginPath();g.moveTo(-17+i*.6,-94);g.lineTo(-17+i*.6+50,-44);g.stroke()}}else fold();
  const pat=K.pat;
  if(pat==='patch'){g.fillStyle=shade(D,.12);g.fillRect(-8,-84,10,10);g.fillStyle=shade(T,-.28);g.fillRect(4,-70,9,8);g.strokeStyle='#0005';g.lineWidth=1;g.setLineDash([2.4,2.4]);g.strokeRect(-8,-84,10,10);g.strokeRect(4,-70,9,8);g.setLineDash([])}
  else if(pat==='sash'){arBev(g,[7,-95,19,-95,-5,-46,-15,-46],shade(D,.05),{edge:T,ew:2.2})}
  else if(pat==='vwrap'){const wc=K.wrap||T;arBev(g,[-18,-95,-9,-95,9,-49,-3,-47],wc,{flat:0});arBev(g,[20,-95,11,-95,-7,-49,5,-47],shade(wc,-.1),{flat:0})}
  else{arBev(g,[-6,-95,10,-95,2,-80],shade(D,.2),{flat:1})}
  if(m==='quilt'){arBev(g,[-8,-95,12,-95,2,-83],shade(T,-.3),{flat:1})}
 }else if(m==='leather'||m==='brig'){
  if(m==='leather'){g.fillStyle=shade(D,.02);g.fillRect(-18,-94,9,50);g.fillRect(14,-94,9,50);g.strokeStyle='#00000066';g.lineWidth=1;g.beginPath();g.moveTo(-9,-94);g.lineTo(-9,-46);g.moveTo(14,-94);g.lineTo(14,-46);g.stroke();stitch(-8,-92,-8,-48);stitch(13,-92,13,-48);
   for(const y of[-76,-63])arBev(g,[-16,y,18,y,18,y+4.4,-16,y+4.4],shade(D,-.06),{ow:1});
   arBev(g,[-16,-95,-8,-95,17,-52,9,-49],shade(D,-.1),{edge:T,ew:2});
   for(const [x,y] of[[-9,-82],[-2,-71],[5,-60]])rivet(g,x,y,1.5,T)}
  else{const pl=K.plc||'#9aa6ba';g.fillStyle='#00000030';g.fillRect(-18,-94,40,50);for(let r=0;r<6;r++)for(let cx=0;cx<6;cx++){const x=-18+cx*7.6+(r%2)*3.8,y=-93.4+r*8,w=6.8;arBev(g,[x,y,x+w,y,x+w,y+7.2,x,y+7.2],shade(pl,r%2?-.08:0),{flat:0,ow:.8});rivet(g,x+w/2,y+3.6,.85,T)}}
 }else if(m==='mail'){
  arMail(g,B);g.fillStyle='#0000002e';g.fillRect(-18,-94,3,50);
  arBev(g,[-15,-95,-8,-95,-8,-48,-14,-48],shade(D,.05),{ow:1});arBev(g,[13,-95,19,-95,18,-48,13,-48],shade(D,.05),{ow:1});
  arBev(g,[-8,-60,13,-60,13,-56,-8,-56],shade(D,-.05),{ow:1});rivet(g,2.5,-58,1.5,T);
 }else if(m==='scale'){
  arScale(g,B,M,T);arBev(g,[-18,-95,20,-95,20,-88,-18,-88],shade(M,.05),{edge:T,ew:2.4});g.strokeStyle=T;g.lineWidth=1.2;g.beginPath();g.moveTo(1,-88);g.lineTo(1,-47);g.stroke();
  for(const y of[-80,-68,-56])rivet(g,1,y,1.6,T);
 }else if(m==='lacq'){
  for(let i=0;i<8;i++){const y=-94+i*6.1;arBev(g,[-18,y,20,y,20,y+6.4,-18,y+6.4],i%2?shade(M,-.08):shade(M,.04),{flat:0,ow:.8})}
  g.strokeStyle=T;g.lineWidth=1.1;for(const x of[-9,12]){g.beginPath();g.moveTo(x,-93);g.lineTo(x,-46);g.stroke()}g.fillStyle=T;for(const x of[-9,12])for(let y=-90;y<-46;y+=6.1)g.fillRect(x-1.2,y,2.4,1.5);
  g.fillStyle=T;g.fillRect(-18,-94,40,3.4);
 }else{ /* plate and crystal */
  const cr=m==='crystal',tx=cr?(g2,b)=>arFacets(g2,b,M,t):null;
  g.fillStyle=shade(D,.05);g.fillRect(-18,-94,40,50);
  arBev(g,[-14.5,-93,2,-93,2,-61,-3,-57,-10,-60,-15.5,-72],shade(M,-.05),{edge:T,ew:2.4,tex:tx});
  arBev(g,[2,-93,17.5,-93,17,-72,12,-60,7,-57,2,-61],shade(M,.08),{edge:T,ew:2.4,tex:tx});
  g.strokeStyle=shade(T,-.1);g.lineWidth=1.3;g.beginPath();g.moveTo(2,-92);g.lineTo(2,-61);g.stroke();
  for(let i=0;i<3;i++){const y=-60+i*5.4;arBev(g,[-15+i*.3,y,17-i*.3,y,17-i*.5,y+6.2,-14.5+i*.5,y+6.2],i%2?shade(M,-.07):shade(M,.02),{tex:tx,ow:1.05})}
  g.fillStyle='#00000030';g.fillRect(-18,-94,3,50);
  for(const [x,y] of[[-11,-88],[14,-88],[-12,-66],[15,-66]])rivet(g,x,y,1.5,T)}
 g.fillStyle=hgr(g,-17,-6,'#ffffff30','#ffffff00');g.fillRect(-18,-94,12,50);g.fillStyle=hgr(g,6,19,'#00000000','#00000060');g.fillRect(6,-94,14,50);
 g.restore();g.strokeStyle='#000000b8';g.lineWidth=1.3;arPP(g,P0);g.stroke()}
function arEmblem(g,K,c,br){if(!K.emb)return;const {T,acc,tier,t}=c;g.save();g.translate(1,-70+br*.3);g.globalAlpha=.78+.22*Math.sin(t*2.2);const col=K.embc||(tier>=3?acc:T);
 if(tier>=3)glow(g,0,0,17,col+'44');g.scale(.92,.92);arGlyph(g,K.emb,col,t);g.restore()}
function arGorget(g,K,c){const m=K.mat,{M,D,T}=c;
 if(m==='plate'||m==='crystal'||m==='scale'||m==='lacq'||m==='brig')arBev(g,[-10,-98,14,-98,13,-91,3,-86,-7,-90],shade(M,.06),{edge:T,ew:2.2});
 else if(m==='leather')arBev(g,[-10,-98,14,-98,12,-91,3,-87,-7,-90],shade(M,.1),{flat:1});
 else if(m==='cloth'||m==='quilt')arBev(g,[-8,-98,12,-98,10,-92,2,-89,-5,-92],shade(D,.1),{flat:1,ow:1})}
function arBelt(g,K,c){const {D,T,M}=c,m=K.mat,bc=K.belt||(m==='cloth'?shade(T,-.3):shade(D,-.3));
 arBev(g,[-14,-51,16,-51,16,-45,-14,-45],bc,{ow:1.2});
 arBev(g,[-3.8,-52.5,4.8,-52.5,4.8,-43.5,-3.8,-43.5],T,{ow:1.1});rivet(g,.5,-48,1.4,shade(T,-.2))}
function arSkirt(g,K,c){const {M,D,T,hc,t}=c,s=K.skirt,m=K.mat;
 if(s==='tassets'){for(let i=0;i<4;i++){const x0=-14+i*7.9,o=i%2?2.6:0;arBev(g,[x0,-45,x0+9.4,-45,x0+8.7,-31-o,x0+4.7,-26.5-o,x0+.7,-31-o],shade(M,i%2?-.14:-.02),{edge:T,ew:1.6})}
  g.fillStyle=T;for(let i=0;i<4;i++)rivet(g,-9+i*7.9,-42,1.2,T)}
 else if(s==='kilt'){for(let i=0;i<5;i++){const x0=-14+i*6.3,o=i%2?3:0;arBev(g,[x0,-45,x0+6.7,-45,x0+6.2,-31-o,x0+3.3,-28-o,x0+.4,-31-o],shade(m==='cloth'||m==='quilt'?D:M,i%2?-.3:-.18),{ow:1})}
  g.save();g.setLineDash([1.6,1.8]);g.strokeStyle='#e8c890aa';g.lineWidth=.8;for(let i=0;i<5;i++){const x0=-14+i*6.3+.8;g.beginPath();g.moveTo(x0,-44);g.lineTo(x0+.2,-33-(i%2?3:0));g.stroke()}g.restore()}
 else if(s==='rag'){const p=[-14,-45,16,-45];for(let i=0;i<=6;i++){const x=16-i*5+Math.sin(t*2+i)*.5,y=-32+((i*7)%5)*1.5-(i%2?4:0);p.push(x,y+Math.sin(t*3+i*1.7)*1.2)}arBev(g,p,shade(D,.04),{flat:0});g.strokeStyle='#00000033';g.lineWidth=1;for(let i=0;i<4;i++){g.beginPath();g.moveTo(-10+i*7,-44);g.lineTo(-11+i*7,-34);g.stroke()}}
 else if(s==='mail'){const p=[-14,-45,16,-45];for(let i=0;i<=6;i++)p.push(16.6-i*5.1,-29-(i%2?4:0));arBev(g,p,shade(M,-.04),{tex:(g2,b)=>arMail(g2,b),ow:1.2})}
 else if(s==='tabard'){const tc=K.tab==='hc'?hc:(K.tab||hc);
  for(const [x0,sd] of[[-15,0],[10,1]])for(let i=0;i<2;i++){const xx=x0+i*(sd?4.4:-4)+(sd?0:4.6);arBev(g,[xx,-45,xx+6,-45,xx+5.4,-33,xx+3,-29.5,xx+.6,-33],shade(M,i?-.14:-.04),{edge:T,ew:1.4})}
  arBev(g,[-6.4,-46,10.4,-46,11.5,-24+Math.sin(t*2)*.6,2,-17+Math.sin(t*2)*.8,-7.5,-24+Math.sin(t*2)*.6],tc,{edge:T,ew:2.8,flat:0});
  g.save();g.translate(2,-35);g.scale(.5,.5);if(K.emb&&K.emb!=='eclipse')arGlyph(g,K.emb,T,t);else if(K.emb==='eclipse')arGlyph(g,'star',T,t);g.restore()}}
