/* ===== WILDCARD: the deal and the big action moments =====
   The deal plays as one sequence: the deck drops onto the felt, a two-handed riffle shuffle with a bridge, a
   round-robin deal where every card arcs to its seat (yours fly face-down straight into their final places in your
   hand), a left-to-right flip that reveals your hand, then the first card turns over onto the pile.
   Wild cards spin the four element orbs round the pile until the chosen one bursts into a colour wave; Turnabout
   sweeps a giant double arrow round the table while every seat hops in the new direction; Stun drops a lightning bolt
   on the stunned player, freezes them blue and stamps them with the stun mark. Reduced motion keeps it all brief. */
function wcHandSlots(G){const cards=wcDisp(),n=cards.length,w=112,maxW=n>12?1000:880,step=n>1?Math.min(78,(maxW-w)/(n-1)):0,tot=w+(n-1)*step,m=(n-1)/2;
 return cards.map((c,i)=>({c,x:800-tot/2+i*step,y:718+Math.pow(i-m,2)*Math.min(2.2,30/(n*n)+.5),r:n>1?(i-m)*Math.min(3.2,26/n):0}))}
/* a temporary card in the effects layer; face can be shown later by flipping */
function wcTmp(back,face,at,r){const fx=$('wcfx');const d=document.createElement('div');d.className='wcfly'+(face?' flip':'');d.style.width=at.w+'px';d.style.height=at.h+'px';
 d.innerHTML=face?`<div class="fi" style="transform:rotateY(180deg)"><div class="ff">${face}</div><div class="fb">${back}</div></div>`:back;d.style.transform=`translate(${at.x}px,${at.y}px) rotate(${r||0}deg)`;fx.appendChild(d);return d}
function wcMove(d,from,to,o){o=o||{};const dur=wcRM()?40:(o.dur||300),mid=o.arc==null?-40:o.arc,sx=(from.w||to.w)/to.w;
 const k=[{transform:`translate(${from.x}px,${from.y}px) rotate(${o.r0||0}deg) scale(${o.s0||sx})`},{transform:`translate(${(from.x+to.x)/2}px,${(from.y+to.y)/2+mid}px) rotate(${((o.r0||0)+(o.r1||0))/2+(o.spin||0)}deg) scale(${o.pk||1.08})`,offset:.5},{transform:`translate(${to.x}px,${to.y}px) rotate(${o.r1||0}deg) scale(1)`}];
 return d.animate(k,{duration:dur,easing:o.ease||'cubic-bezier(.3,.7,.3,1)',fill:'forwards'}).finished.catch(()=>{})}
async function wcDeal2(e){const G=WX.G,n=e.hand,dk=wcDeckSpot(),fx=$('wcfx'),deck=$('wcdeck'),disc=$('wcdisc'),hand=$('wchand');if(!dk||!fx)return;
 WX.vc=G.P.map(()=>0);for(const i of G.P.keys())wcCount(i,0);if(hand)hand.innerHTML='';const stt=$('wcstat');if(stt)stt.style.visibility='hidden';const top=disc?disc.innerHTML:'';if(disc)disc.innerHTML='';
 const B=wcBack(wcBackSel()),rm=wcRM();
 if(!rm){/* 1. the deck drops in */deck.style.visibility='hidden';const drop=wcTmp(B,null,dk,-8);wcFx('bridge');
  await wcMove(drop,{x:dk.x+120,y:-220,w:dk.w,h:dk.h},dk,{dur:520,arc:0,r0:-40,r1:0,spin:-20,ease:'cubic-bezier(.2,.9,.25,1.15)'});drop.remove();deck.style.visibility='';deck.classList.remove('land');void deck.offsetWidth;deck.classList.add('land');await wcSleep(160);
  /* 2. riffle: two halves fan out, then interleave back together */
  deck.style.visibility='hidden';const L=[],R=[];for(let i=0;i<6;i++){L.push(wcTmp(B,null,dk,0));R.push(wcTmp(B,null,dk,0))}wcFx('riffle');
  const sp=(d,i,s)=>d.animate([{transform:`translate(${dk.x}px,${dk.y}px)`},{transform:`translate(${dk.x+s*(64+i*3)}px,${dk.y-10-i*2}px) rotate(${s*(14+i*2)}deg)`}],{duration:260,easing:'cubic-bezier(.2,.8,.3,1)',fill:'forwards'}).finished;
  await Promise.all([...L.map((d,i)=>sp(d,i,-1)),...R.map((d,i)=>sp(d,i,1))]);
  for(let i=5;i>=0;i--){for(const [d,s] of [[L[i],-1],[R[i],1]]){d.animate([{transform:`translate(${dk.x+s*(64+i*3)}px,${dk.y-10-i*2}px) rotate(${s*(14+i*2)}deg)`},{transform:`translate(${dk.x}px,${dk.y-(5-i)*1.2}px) rotate(${s*2}deg)`}],{duration:150,easing:'ease-in',fill:'forwards'})}await wcSleep(42)}
  await wcSleep(140);const all=[...L,...R];wcFx('bridge');
  all.forEach((d,i)=>d.animate([{transform:`translate(${dk.x}px,${dk.y}px)`},{transform:`translate(${dk.x}px,${dk.y-18}px) scale(1.04,.86)`,offset:.5},{transform:`translate(${dk.x}px,${dk.y}px)`}],{duration:300,easing:'ease-in-out',fill:'forwards'}));
  await wcSleep(320);all.forEach(d=>d.remove());deck.style.visibility=''}
 /* 3. round-robin deal: everyone else's cards to their seats, yours face-down into their final slots */
 const slots=wcHandSlots(G),mine=[];let k2=0;
 for(let k=0;k<n;k++)for(let j=0;j<G.P.length;j++){const i=(G.turn+j)%G.P.length,me=i===WX.me;
  if(me){const s=slots[k];if(!s)continue;const d=wcTmp(B,WX.cover?null:wcSVG(s.c),{x:dk.x,y:dk.y,w:112,h:164},0);mine.push(d);wcMove(d,dk,{x:s.x,y:s.y,w:112,h:164},{dur:rm?40:360,arc:-70,r1:s.r,spin:-14})}
  else{const to=wcSeatSpot(i);if(!to)continue;const d=wcTmp(B,null,{x:dk.x,y:dk.y,w:to.w,h:to.h},0);wcMove(d,dk,to,{dur:rm?40:320,arc:-46,spin:-26,r1:-8}).then(()=>{d.remove();wcCount(i,1)})}
  if(k2++%2===0)wcFx('deal2');await wcSleep(rm?5:58)}
 await wcSleep(rm?40:380);
 /* 4. your hand flips over, left to right */
 if(!WX.cover){wcFx('flipall');for(const d of mine){const fi=d.querySelector('.fi');if(fi)fi.animate([{transform:'rotateY(180deg)'},{transform:'rotateY(90deg) translateY(-14px)',offset:.5},{transform:'rotateY(0deg)'}],{duration:rm?40:320,easing:'ease-in-out',fill:'forwards'});await wcSleep(rm?0:55)}await wcSleep(rm?40:340)}
 WX.fresh=null;wcRenderHand();mine.forEach(d=>d.remove());
 /* 5. the first card turns over onto the pile */
 const fc=G.disc[0],to=wcPileSpot();if(fc&&to){const d=wcTmp(B,wcSVG(fc),dk,0);wcFx('swish');const fi=d.querySelector('.fi');
  if(fi)fi.animate([{transform:'rotateY(180deg)'},{transform:'rotateY(0deg)'}],{duration:rm?40:420,easing:'ease-in-out',fill:'forwards'});
  await wcMove(d,dk,to,{dur:rm?40:420,arc:-80,r1:wcRot(fc.id),spin:20,pk:1.25});d.remove()}
 if(disc){disc.innerHTML=top;const t=disc.querySelector('.top');if(t){t.classList.add('land')}}wcTint(G.color);wcFx('slap');
 const pl=wcPileSpot();if(pl)wcBurst({x:pl.x+pl.w/2,y:pl.y+pl.h/2},G.color,10);if(stt)stt.style.visibility='';await wcSleep(rm?40:260)}
/* Wild Rune / +4 Hex: the four orbs whirl round the pile, then the chosen element bursts out */
async function wcWild2(col,mid){const fx=$('wcfx');if(!fx)return;if(wcRM()){wcWave(col);return}
 const w=document.createElement('div');w.className='wcwild';w.style.left=mid.x+'px';w.style.top=mid.y+'px';w.innerHTML=WCS.map((s,i)=>`<i data-s="${s}" style="--a:${i*90}deg">${wcOrb(s,66)}</i>`).join('')+'<b></b>';fx.appendChild(w);wcFx('swirl');
 await wcSleep(720);w.classList.add('pick');w.querySelector(`[data-s="${col}"]`).classList.add('win');await wcSleep(300);wcWave(col);wcFx('elem',col);await wcSleep(260);w.remove()}
/* Turnabout: a giant double arrow sweeps the table and the seats hop the new way round */
async function wcRev2(e){const r=$('wcring');if(r){r.classList.toggle('rev',e.dir<0);r.classList.remove('flip');void r.offsetWidth;r.classList.add('flip')}const fx=$('wcfx');wcFx('whoosh');
 if(fx&&!wcRM()){const a=document.createElement('div');a.className='wcrev2'+(e.dir<0?' ccw':'');a.innerHTML=`<svg viewBox="-120 -120 240 240"><g fill="none" stroke-linecap="round"><path d="M-90 -30A95 95 0 0 1 55-78" stroke="#12081f" stroke-width="26"/><path d="M90 30A95 95 0 0 1 -55 78" stroke="#12081f" stroke-width="26"/><path d="M-90 -30A95 95 0 0 1 55-78" stroke="#8ad8ff" stroke-width="16"/><path d="M90 30A95 95 0 0 1 -55 78" stroke="#8ad8ff" stroke-width="16"/></g>
  <path d="M44-100L82-76 40-58Z" fill="#8ad8ff" stroke="#12081f" stroke-width="5" stroke-linejoin="round"/><path d="M-44 100L-82 76-40 58Z" fill="#8ad8ff" stroke="#12081f" stroke-width="5" stroke-linejoin="round"/></svg>`;fx.appendChild(a);setTimeout(()=>a.remove(),1000)
  const G=WX.G,n=G.P.length;for(let k=0;k<n;k++){const i=((G.turn-e.dir*k)%n+n)%n,s=wcSeatEl(i);if(s){setTimeout(()=>{s.classList.remove('hop');void s.offsetWidth;s.classList.add('hop')},120+k*110)}}}
 await wcSleep(620)}
/* Stun: a bolt drops on the stunned player, who freezes blue under the stun mark */
async function wcSkip2(e){const s=wcSeatEl(e.p),at=wcCen(e.p),fx=$('wcfx');wcFx('zap');
 if(fx&&!wcRM()){const b=document.createElement('div');b.className='wcbolt';b.style.left=at.x+'px';b.style.top=(at.y+56)+'px';b.innerHTML=`<svg viewBox="-30 -120 60 130"><path d="M8-118L-20-40H-2L-14 8 22-62H4L18-118Z" fill="#fff6a0" stroke="#12081f" stroke-width="5" stroke-linejoin="round"/></svg><i></i><em><svg viewBox="-20 -20 40 40"><circle r="15" fill="none" stroke="#12081f" stroke-width="9"/><circle r="15" fill="none" stroke="#ffd45a" stroke-width="5"/><path d="M-10 10L10-10" stroke="#12081f" stroke-width="9" stroke-linecap="round"/><path d="M-10 10L10-10" stroke="#ffd45a" stroke-width="5" stroke-linecap="round"/></svg></em>`;fx.appendChild(b);setTimeout(()=>b.remove(),1300)
  const z=document.createElement('div');z.className='wczap';z.style.left=at.x+'px';z.style.top=(at.y+56)+'px';z.innerHTML='<i></i><i></i><i></i><i></i><i></i>';fx.appendChild(z);setTimeout(()=>z.remove(),1300)}
 if(s){s.classList.remove('stun','frz');void s.offsetWidth;s.classList.add('stun','frz');setTimeout(()=>s&&s.classList.remove('frz'),1300)}
 wcShake(1);wcPop('Stunned!','stn',wcCen(e.p,-74));await wcSleep(560)}
{const a0=wcAnim;wcAnim=async function(e){if(e.k==='deal')return wcDeal2(e);if(e.k==='rev')return wcRev2(e);if(e.k==='skip')return wcSkip2(e);return a0.apply(this,arguments)}}
