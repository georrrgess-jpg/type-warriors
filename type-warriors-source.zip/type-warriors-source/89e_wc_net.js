/* ===== WILDCARD: playing with friends on other devices =====
   Two ways in, both ending in a direct WebRTC data channel between the devices:
   1. Room code (needs internet): the host's lobby shows a 4-letter code. A friend types it into "Join a room"; the
      two devices swap connection details through the encrypted relay in 89k, then talk directly. STUN servers help
      devices on different networks find each other.
   2. Scan to join (no internet needed, same Wi-Fi): the host shows an invite QR (also a code to copy), the friend
      scans it with their camera, then holds up the reply QR their screen shows for the host to scan back.
      Offline codes carry only the connection keys and local addresses, packed small:
        WC1~o|a~ufrag~password~fingerprint(base64)~address*port!address*port
   The host runs the game and sends each guest the table with only that guest's own hand visible. Gold stays on each
   player's own device: everyone pays the stake from their own save and collects their own payout. */
const WCNET={guest:null,peers:{},seq:0};
const WCRTC={iceServers:[]};
const wcB64=h=>btoa(h.split(':').map(x=>String.fromCharCode(parseInt(x,16))).join('')).replace(/=+$/,''),wcHex=b=>Array.from(atob(b),ch=>ch.charCodeAt(0).toString(16).padStart(2,'0').toUpperCase()).join(':');
function wcPack(kind,sdp){const g=r=>(sdp.match(r)||[])[1]||'';const u=g(/a=ice-ufrag:(\S+)/),p=g(/a=ice-pwd:(\S+)/),f=g(/a=fingerprint:sha-256 (\S+)/);
 const c=[...sdp.matchAll(/a=candidate:\S+ 1 udp \d+ (\S+) (\d+) typ host/gi)].map(m=>m[1]+'*'+m[2]);
 return['WC1',kind,u,p,wcB64(f),[...new Set(c)].join('!')].join('~')}
function wcUnpack(code){code=String(code||'').trim();const h=code.indexOf('#wcj=');if(h>=0)code=decodeURIComponent(code.slice(h+5));code=code.replace(/\s+/g,'');
 const a=code.split('~');if(a.length<6||a[0]!=='WC1'||!/^[oa]$/.test(a[1]))return null;let fp;try{fp=wcHex(a[4])}catch(e){return null}
 const cands=a[5]?a[5].split('!').map((x,i)=>{const [ip,port]=x.split('*');return `a=candidate:${i+1} 1 udp ${2122260223-i} ${ip} ${port} typ host generation 0`}):[];
 const sdp=['v=0','o=- '+(Date.now()%1e9)+' 2 IN IP4 127.0.0.1','s=-','t=0 0','a=group:BUNDLE 0','a=msid-semantic: WMS','m=application 9 UDP/DTLS/SCTP webrtc-datachannel','c=IN IP4 0.0.0.0',...cands,
  'a=ice-ufrag:'+a[2],'a=ice-pwd:'+a[3],'a=ice-options:trickle','a=fingerprint:sha-256 '+fp,'a=setup:'+(a[1]==='o'?'actpass':'active'),'a=mid:0','a=sctp-port:5000','a=max-message-size:262144',''].join('\r\n');
 return{kind:a[1],sdp,cands:cands.length}}
function wcIce(pc,ms){return new Promise(res=>{if(pc.iceGatheringState==='complete')return res();const t=setTimeout(res,ms||2500);pc.addEventListener('icegatheringstatechange',()=>{if(pc.iceGatheringState==='complete'){clearTimeout(t);res()}})})}
const wcRtcOk=()=>typeof RTCPeerConnection==='function';
const wcLink=code=>{try{if(!/^https?:/.test(location.protocol))return'';return location.href.split('#')[0]+'#wcj='+encodeURIComponent(code)}catch(e){return''}};
function wcCopy(t,btn){const ok=()=>{if(btn){const o=btn.innerHTML;btn.classList.add('done');btn.innerHTML='✓ Copied';setTimeout(()=>{btn.innerHTML=o;btn.classList.remove('done')},1600)}wcFx('coin')};
 try{navigator.clipboard.writeText(t).then(ok,()=>wcSel(btn))}catch(e){wcSel(btn)}}
function wcSel(btn){const box=btn&&btn.closest('.wcmb,.wcjs')&&btn.closest('.wcmb,.wcjs').querySelector('textarea[readonly]');if(box){box.focus();box.select()}}
/* ---------- host: one peer connection per guest seat ---------- */
function wcHostPeer(s,cfg){const pc=new RTCPeerConnection(cfg),dc=pc.createDataChannel('wildcard',{ordered:true});s.pc=pc;s.dc=dc;s.pid=s.pid||'n'+(++WCNET.seq)+Date.now().toString(36);WCNET.peers[s.pid]=s;
 dc.onopen=()=>{s.k='net';s.ready=0;wcFx('join');const m=$('wcmod');if(m&&!m.hidden&&m.dataset.inv!=null&&WCL.seats[+m.dataset.inv]===s){m.hidden=true;m.innerHTML='';wcScanStop()}s.fresh=1;if($('wcl'))wcLobbyRender();wcNetLobby()};
 dc.onmessage=e=>wcHostMsg(s,e.data);dc.onclose=()=>wcPeerGone(s);pc.onconnectionstatechange=()=>{if(['failed','closed'].includes(pc.connectionState))wcPeerGone(s)};return pc}
/* the relay: answer knocks from friends who typed the room code */
function wcHostRelay(){if(!wcRelayOk()){WCL.net='offline';return}if(WCR.code===WCL.room&&WCR.inbox==='h'&&WCR.state!=='off')return;
 WCL.net='connecting';wcRelayOpen(WCL.room,'h',wcHostRelayMsg,st=>{WCL.net=st;wcLobbyNet()})}
async function wcHostRelayMsg(m){if(!$('wcl')&&!(WX.G&&WX.host)){return}const gid=String(m.gid||'').slice(0,24);if(!gid)return;
 if(m.t==='knock'){if(!$('wcl')||WX.G&&WX.G.phase!=='over'&&$('wct')){wcRelaySend('g'+gid,{t:'started'});return}
  let s=WCL.seats.find(x=>x.gid===gid);if(s&&s.k==='net')return;if(s&&s.offer){wcRelaySend('g'+gid,{t:'offer',sdp:s.offer,room:WCL.room});return}if(s&&s.k==='inv')return;
  const i=WCL.seats.findIndex(x=>x.k==='open');if(i<0){wcRelaySend('g'+gid,{t:'full'});return}
  s=WCL.seats[i]={k:'inv',gid,via:'code',name:String(m.name||'Friend').replace(/[<>]/g,'').slice(0,14)};wcFx('pop');wcLobbyRender();
  const pc=wcHostPeer(s,WCSTUN);try{await pc.setLocalDescription(await pc.createOffer());await wcIce(pc,3000);s.offer=pc.localDescription.sdp;wcRelaySend('g'+gid,{t:'offer',sdp:s.offer,room:WCL.room})}catch(e){WCL.seats[i]={k:'open'};wcLobbyRender();return}
  setTimeout(()=>{if(s.k==='inv'&&WCL.seats[i]===s){try{s.pc.close()}catch(e){}s.gone=1;delete WCNET.peers[s.pid];WCL.seats[i]={k:'open'};if($('wcl'))wcLobbyRender()}},30000);return}
 if(m.t==='answer'){const s=WCL.seats.find(x=>x.gid===gid);if(!s||!s.pc||s.pc.signalingState!=='have-local-offer')return;try{await s.pc.setRemoteDescription({type:'answer',sdp:String(m.sdp||'')})}catch(e){}}}
/* offline invite for one seat: QR + code out, camera or paste for the reply */
async function wcInvite(i){const s=WCL.seats[i];if(!s)return;if(!wcRtcOk()){wcModal('<h3>Direct play is not available</h3><p class="wcp">This browser cannot make direct connections. Try Chrome, Edge, Safari or Firefox.</p>');WCL.seats[i]={k:'open'};wcLobbyRender();return}
 const m=wcModal(`<h3>Invite without internet</h3><p class="wcp sm">For a friend on the <b>same Wi-Fi</b>. Their device scans your code, then shows you a reply code to scan back.</p>
 <div class="wcinv2"><div class="wcinvq"><div class="wcqr" id="wcqr"><i class="wcspin"></i></div><b>1 · Your friend scans this</b><small>In Wildcard: Join a room › No internet? Scan to join.</small><button class="wcbtn sm" id="wcicp" disabled>${WCI.copy}Copy invite code</button></div>
 <div class="wcinvq"><div class="wcscan" id="wcscan"></div><b>2 · Scan their reply</b><small id="wcscs">Hold your friend's screen up to your camera.</small><button class="wcbtn sm" id="wcpst">Paste a reply code instead</button></div></div>
 <div class="wcpaste" id="wcpaste" hidden><textarea id="wcrep" class="wccode in" rows="3" spellcheck="false" placeholder="Paste the reply code your friend sent back"></textarea><button class="wcbtn gold" id="wcrgo">Connect</button></div><p class="wcerr" id="wcrerr"></p>`,'wide wcinvm');if(!m)return;m.dataset.inv=i;
 m.querySelector('.wcmx').addEventListener('click',wcScanStop);const er=$('wcrerr');
 $('wcpst').onclick=()=>{$('wcpaste').hidden=false;$('wcrep').focus()};const rep=$('wcrep');rep.onkeydown=e=>e.stopPropagation();
 if(!s.pc){wcHostPeer(s,WCRTC);try{await s.pc.setLocalDescription(await s.pc.createOffer());await wcIce(s.pc);s.code=wcPack('o',s.pc.localDescription.sdp)}catch(e){er.textContent='Could not make an invite on this device.';return}}
 if(!$('wcqr')||m.dataset.inv!=String(i))return;const link=wcLink(s.code);
 try{$('wcqr').innerHTML=wcQR(link||s.code);$('wcqr').classList.add('in')}catch(e){$('wcqr').textContent='Code too long for a QR. Copy it instead.'}
 $('wcicp').disabled=false;$('wcicp').onclick=()=>wcCopy(link||s.code,$('wcicp'));wcFx('coin');
 const use=async(txt)=>{const r=wcUnpack(txt);if(!r||r.kind!=='a'){er.className='wcerr';er.textContent=r&&r.kind==='o'?'That is an invite, not a reply. Scan the code your friend\'s screen shows.':'That does not look like a reply code.';wcFx('bad');return false}
  try{if(s.pc.signalingState!=='have-local-offer')throw 0;await s.pc.setRemoteDescription({type:'answer',sdp:r.sdp});er.className='wcerr ok';er.textContent='Got it! Connecting…';wcFx('coin');
   setTimeout(()=>{if(s.k!=='net'&&er.isConnected){er.className='wcerr';er.textContent='Could not connect. Make sure you are both on the same Wi-Fi, then try a new invite.'}},9000);return true}
  catch(e){er.className='wcerr';er.textContent='That reply belongs to a different invite. Close this and make a new invite.';return false}};
 const scan=()=>wcScan($('wcscan'),async t=>{if(!(await use(t)))setTimeout(()=>{if($('wcscan'))scan()},1500)},msg=>{$('wcscs').textContent=msg;$('wcpaste').hidden=false});scan();
 $('wcrgo').onclick=()=>use(rep.value)}
function wcPeerGone(s){if(s.gone)return;s.gone=1;delete WCNET.peers[s.pid];const G=WX.G;
 if(G&&WX.host&&WX.mode==='net'&&G.phase!=='over'){const i=G.P.findIndex(p=>p.kind==='net'&&p.id===s.pid);if(i>=0){G.P[i].kind='bot';wcChat('Lounge',`${G.P[i].name} left. A regular takes their seat.`);wcRender();wcStep()}}
 const li=WCL.seats.indexOf(s);if(li>=0){WCL.seats[li]={k:'open'};wcFx('leave');if($('wcl'))wcLobbyRender()}}
function wcNetDrop(i){const s=WCL.seats[i];if(s&&s.pc){s.gone=1;try{s.dc&&s.dc.send(JSON.stringify({t:'kick'}))}catch(e){}try{s.pc.close()}catch(e){}delete WCNET.peers[s.pid]}}
function wcTx(s,o){try{if(s.dc&&s.dc.readyState==='open')s.dc.send(JSON.stringify(o))}catch(e){}}
function wcSeatName(x,i){return x.k==='you'?P.name||'Host':x.k==='bot'?(WCL.crew[i-1]||{}).name||'Regular':x.name||''}
function wcNetLobby(){const set=WCL.set;for(const s of WCL.seats)if(s.k==='net')wcTx(s,{t:'lobby',room:WCL.room,set,seats:WCL.seats.map((x,i)=>({k:x.k,name:wcSeatName(x,i),ready:x.ready,av:x.k==='bot'?WCL.crew[i-1]:x.k==='net'?x.av:x.k==='you'?wcMyAv():null})),you:WCL.seats.indexOf(s)})}
function wcHostMsg(s,raw){let m;try{m=JSON.parse(raw)}catch(e){return}
 if(m.t==='hello'){s.name=String(m.name||'Friend').replace(/[<>]/g,'').slice(0,14);s.av=m.av&&m.av.t==='hero'?{t:'hero',arm:String(m.av.arm||''),wp:String(m.av.wp||''),col:+m.av.col||0}:{t:'hero'};s.gold=+m.gold||0;if($('wcl'))wcLobbyRender();wcNetLobby();return}
 if(m.t==='ready'){s.ready=m.v?1:0;wcFx(s.ready?'ready':'click');if($('wcl'))wcLobbyRender();wcNetLobby();return}
 if(m.t==='pong'){s.ms=Math.max(1,Math.round(performance.now()-m.ts));const e=document.querySelector(`.wcseat2[data-i="${WCL.seats.indexOf(s)}"] .wcms`);if(e)e.textContent=s.ms+' ms';return}
 if(m.t==='chat'){wcChat(s.name,String(m.x||'').slice(0,40));wcRelay({t:'chat',n:s.name,x:String(m.x||'').slice(0,40),emo:m.emo,seat:WX.G?WX.G.P.findIndex(p=>p.id===s.pid):-1},s);const G=WX.G;if(G){const i=G.P.findIndex(p=>p.id===s.pid);if(i>=0&&m.emo)wcBubble(i,String(m.x).slice(0,12))}return}
 if(m.t==='act'){const G=WX.G;if(!G)return;const i=G.P.findIndex(p=>p.id===s.pid&&p.kind==='net');if(i<0)return;const a=m.a||{};if(!['play','draw','pass','call','catch'].includes(a.t))return;
  wcApply(i,{t:a.t,id:a.id!=null?+a.id:null,col:WCS.includes(a.col)?a.col:null,p:+a.p})}}
function wcRelay(o,except){for(const k in WCNET.peers){const s=WCNET.peers[k];if(s!==except)wcTx(s,o)}}
setInterval(()=>{for(const k in WCNET.peers){const s=WCNET.peers[k];wcTx(s,{t:'ping',ts:performance.now()})}},2500);
/* the table each guest sees: their own hand, everyone else's card counts */
function wcView(G,j){const o={};for(const k in G)if(k!=='r'&&k!=='draw')o[k]=G[k];o.draw=G.draw.length;o.P=G.P.map((p,i)=>Object.assign({},p,{hand:i===j?p.hand:p.hand.map(()=>({id:-1,s:'x',v:'x'})),lack:{}}));return o}
function wcSync(){const G=WX.G;if(!G||!WX.host||WX.mode!=='net')return;G.P.forEach((p,i)=>{if(p.kind!=='net')return;const s=WCNET.peers[p.id];if(s)wcTx(s,{t:'st',G:wcView(G,i)})})}
function wcNetStart(){const G=WX.G;if(WX.mode!=='net')return;G.P.forEach((p,i)=>{if(p.kind==='net'){const s=WCNET.peers[p.id];if(s)wcTx(s,{t:'start',me:i,stake:WX.stake,room:WX.room,timer:WX.cfg.timer})}});wcSync()}
function wcLobbyBack(){wcRelay({t:'lobbyback'});for(const s of WCL.seats)if(s.k==='net')s.ready=0;wcLobby(WX.cfg)}
function wcNetClose(){const g=WCNET.guest;if(g){g.closing=1;clearInterval(g.knock);try{g.pc&&g.pc.close()}catch(e){}WCNET.guest=null}
 for(const k in WCNET.peers){const s=WCNET.peers[k];s.gone=1;wcTx(s,{t:'close'});try{s.pc.close()}catch(e){}}WCNET.peers={};wcRelayClose();wcScanStop()}
/* ---------- chat and emotes ---------- */
function wcChat(n,x){WX.chat.push([n,x]);if(WX.chat.length>5)WX.chat.shift();const l=$('wcchl');if(l)l.innerHTML=WX.chat.map(([a,b])=>`<p><b class="${a==='Lounge'?'sys':''}">${esc(a)}:</b> ${esc(b)}</p>`).join('')}
function wcEmote(x){const G=WX.G;if(!G)return;wcBubble(WX.me,x,1800);wcChat(G.P[WX.me].name,x);wcFx('pop');
 if(WX.mode!=='net')return;if(WX.host)wcRelay({t:'chat',n:G.P[WX.me].name,x,emo:1,seat:WX.me});else wcNetSend({t:'chat',x,emo:1})}
/* ---------- guest side ---------- */
function wcNetSend(o){const g=WCNET.guest;if(g&&g.dc&&g.dc.readyState==='open')try{g.dc.send(JSON.stringify(o))}catch(e){}}
function wcGuestPeer(cfg){wcNetClose();const pc=new RTCPeerConnection(cfg),g=WCNET.guest={pc,dc:null,lobby:null,ready:0};
 pc.ondatachannel=e=>{g.dc=e.channel;g.dc.onopen=()=>{if(WCNET.guest!==g)return;clearInterval(g.knock);clearTimeout(g.slow);wcRelayClose();wcNetSend({t:'hello',name:P.name||'Friend',av:wcMyAv(),gold:P.gold});wcFx('join');wcJoinView('in')};g.dc.onmessage=ev=>{if(WCNET.guest===g)wcGuestMsg(ev.data)};g.dc.onclose=()=>{if(WCNET.guest===g)wcHostGone()}};
 pc.onconnectionstatechange=()=>{if(WCNET.guest===g&&['failed'].includes(pc.connectionState))wcHostGone(g.via==='code'?'Could not connect to the host':null)};return g}
/* join by room code through the relay */
function wcJoinCode(raw){const code=wcCodeNorm(raw);if(code.length<4){wcJoinView('bad');return}
 if(!wcRelayOk()||!wcRtcOk()){wcJoinView('nonet');return}const g=wcGuestPeer(WCSTUN);g.via='code';g.code=code;g.gid=Math.random().toString(36).slice(2,10);g.tries=0;wcJoinView('find');
 const knock=()=>{if(WCNET.guest!==g||g.offer)return;g.tries++;wcRelaySend('h',{t:'knock',gid:g.gid,name:P.name||'Friend'});if(g.tries>9){clearInterval(g.knock);wcJoinView('none')}};
 wcRelayOpen(code,'g'+g.gid,async m=>{if(WCNET.guest!==g)return;
  if(m.t==='full'){clearInterval(g.knock);wcJoinView('full');return}if(m.t==='started'){clearInterval(g.knock);wcJoinView('started');return}
  if(m.t==='offer'&&!g.offer){g.offer=1;clearInterval(g.knock);g.room=String(m.room||code);wcJoinView('link');
   try{await g.pc.setRemoteDescription({type:'offer',sdp:String(m.sdp||'')});await g.pc.setLocalDescription(await g.pc.createAnswer());await wcIce(g.pc,3000);
    const sdp=g.pc.localDescription.sdp;wcRelaySend('h',{t:'answer',gid:g.gid,sdp});setTimeout(()=>{if(WCNET.guest===g&&!(g.dc&&g.dc.readyState==='open'))wcRelaySend('h',{t:'answer',gid:g.gid,sdp})},1500);
    g.slow=setTimeout(()=>{if(WCNET.guest===g&&!(g.dc&&g.dc.readyState==='open'))wcJoinView('slow')},15000)}catch(e){wcJoinView('none')}}},
  st=>{if(WCNET.guest!==g)return;if(st==='online'&&!g.knock){knock();g.knock=setInterval(knock,2000)}if(st==='offline'&&!g.offer)wcJoinView('nonet')})}
/* join from an offline invite (scanned or pasted) */
async function wcJoin(code){const r=wcUnpack(code);
 if(!r||r.kind!=='o'){wcJoinView('badinv');return}if(!wcRtcOk()){wcJoinView('nonet');return}
 const g=wcGuestPeer(WCRTC);g.via='scan';
 try{await g.pc.setRemoteDescription({type:'offer',sdp:r.sdp});await g.pc.setLocalDescription(await g.pc.createAnswer());await wcIce(g.pc);g.reply=wcPack('a',g.pc.localDescription.sdp)}catch(e){wcJoinView('badinv');return}
 wcJoinView('reply')}
function wcGuestMsg(raw){let m;try{m=JSON.parse(raw)}catch(e){return}const g=WCNET.guest;if(!g)return;
 if(m.t==='ping'){wcNetSend({t:'pong',ts:m.ts});return}
 if(m.t==='lobby'){g.lobby=m;g.room=m.room;if(m.set.stake&&P.gold<m.set.stake&&g.ready){g.ready=0;wcNetSend({t:'ready',v:0})}if($('wcj'))wcJoinView('in');return}
 if(m.t==='lobbyback'){g.ready=0;WX.G=null;wcJoinView('in');return}
 if(m.t==='kick'||m.t==='close'){wcHostGone(m.t==='kick'?'The host removed you from the room.':'The host closed the room.');return}
 if(m.t==='chat'){wcChat(m.n,m.x);if(m.emo&&m.seat!=null&&m.seat>=0)wcBubble(m.seat,String(m.x).slice(0,12));return}
 if(m.t==='start'){const stake=+m.stake||0;if(stake){P.gold=Math.max(0,P.gold-stake);wcSt().dayN++;save()}
  wcReset({mode:'net',host:false,me:+m.me,stake,fee:WCE.MPFEE,room:m.room,cfg:{timer:+m.timer||0}});g.paid=stake;return}
 if(m.t==='st'){const G=m.G;G.r=Math.random;G.draw=new Array(+G.draw||0);const first=!WX.G;WX.G=G;if(first||!$('wct')){wcTable()}wcPump();return}}
function wcHostGone(msg){const g=WCNET.guest;if(!g||g.closing)return;g.closing=1;clearInterval(g.knock);WCNET.guest=null;wcRelayClose();const G=WX.G,mid=G&&G.phase!=='over'&&!WX.host;
 if(mid&&g.paid){P.gold+=g.paid;save()}WX.tok++;wcClear();WX.G=null;wcHome();
 wcModal(`<h3>${msg||'Lost the connection to the host'}</h3><p class="wcp">${mid&&g.paid?`Your stake of <b>${cmn(g.paid)}</b> gold was returned.`:'You can join again with the room code.'}</p>`)}
/* opened from an invite link: go straight to joining */
setTimeout(()=>{try{const h=location.hash;if(h.indexOf('#wcj=')===0){const code=decodeURIComponent(h.slice(5));history.replaceState(null,'',location.href.split('#')[0]);const go=()=>{if(S.mode==='title'){CAS.on=true;wcJoin(code)}else setTimeout(go,500)};setTimeout(go,900)}}catch(e){}},0);
