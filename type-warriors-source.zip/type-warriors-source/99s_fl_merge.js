/* ===== UPDATE 10.4, THE HARVEST FESTIVAL: merge glue (99s, prefix flm; registered last of the fl modules) =====
   The five festival parts (gear 99n, chest 99o, companions 99p, festival 99q, Harvest Moon Rush 99r) were written against stand-ins of
   each other. This module makes them work as one:
   - Gear entry points: the Hall's "Find it in the Shop" on the Bountiful Harvest set opens the Harvest Collection (the chest part's
     shop face for the two Mythics; its purchase goes through flgBuy, see 99o3). The gear part's own window stays the fallback.
   - Choose a mode › Events: the Harvest Festival card first, then Harvest Moon Rush's own card (art, LIMITED TIME, days left).
   - The home screen's falling leaves fall over the scene only: the layer covers the stage area and sits under every panel and card,
     so no leaf crosses a panel or any text. Same leaves, transform-only animation.
   - The crates menu fits above the dock at every size while a seasonal banner is up (compact everyday crates).
   - Festival toasts: the acorn toast and the chest toast stack instead of covering each other; chest toasts name their source in words;
     the end of a Harvest Moon Rush run pays quietly (the results screen already shows the acorns and chests).
   - A Harvest Moon Rush wave never trips over a run that was started some other way (S.flrM missing).
   - The Harvest Market and the Harvest Calendar show their own note / reveal for chests and the Golden Harvest Egg (no extra toast);
     a companion bought at the market returns to the market after its reveal; a Rush run that ends counts for its Gratitude task
     even when it paid no acorns.
   - The Harvest Collection's Mythic purchase is the gear part's flgBuy (edit in 99o3, backup .v1bak); Performance mode drops the
     ritual's full-screen glows (edit in 99o2, backup .v1bak). */

/* ---------- the Hall: the Bountiful Harvest set leads to the Harvest Collection ---------- */
{const ch0=catHall;catHall=function(){const r=ch0.apply(this,arguments);try{const gl=hlGoal();if(gl&&gl.key==='s:bounty'&&typeof flcCollection==='function')
 ov.querySelectorAll('[data-gs]').forEach(b=>b.addEventListener('click',()=>setTimeout(()=>{if(document.getElementById('shmod'))flcCollection()},0)))}catch(e){}return r}}

/* ---------- Choose a mode › Events: the festival first, then the Rush's own card ---------- */
function flmSheet(){const sh=document.getElementById('dkms');if(!sh)return;const g=sh.querySelector('.dkpv[data-v="e"] .dkmg');if(!g)return;
 const fe=g.querySelector('#dmfl');let rc=g.querySelector('#dmflr');
 if(rc&&!rc.classList.contains('flrcard')&&typeof flrSheetCard==='function'){rc.remove();try{flrSheetCard()}catch(e){}rc=g.querySelector('#dmflr')}
 if(fe&&rc&&rc.parentElement===g){fe.after(rc);rc.removeAttribute('data-first');fe.setAttribute('data-first','')}
 const cur=sh.querySelector('.dkpv[data-v="e"]:not([hidden]) [data-first]');if(cur)try{cur.focus({preventScroll:true})}catch(e){}}
{const m0=modeSheet;modeSheet=function(){const r=m0.apply(this,arguments);try{flmSheet()}catch(e){}return r}}

/* ---------- the home screen's falling leaves: over the scene only ---------- */
/* the layer is the stage area of the home grid (.dkstage: right of the menu panel, under the header, above the dock); it is the first
   child of .dkh with z-index 0, so the menu panel, the championship card, the pet / gear buttons and the dock all paint over it */
function flmLeafFit(L){const h=L.parentElement,st=h&&h.querySelector('.dkstage');if(!st)return;
 const x=st.offsetLeft,y=st.offsetTop,w=st.offsetWidth,hh=st.offsetHeight;if(w<40||hh<40){L.style.display='none';return}L.style.display='';
 L.style.cssText+=`;left:${x}px;top:${y}px;width:${w}px;height:${hh}px`;L.style.setProperty('--fh',(hh+70)+'px');
 L.querySelectorAll('.fllf').forEach((f,i,A)=>{const u=(i+.5)/A.length;f.style.setProperty('--x',Math.round(w*(.04+.86*((u*7.3)%1)))+'px')})}
function fleLeaves(){const h=ov.querySelector('.dkh');if(!h||h.querySelector('.flleaves')||!fleLeavesOn())return;const L=document.createElement('div');L.className='flleaves flm';L.setAttribute('aria-hidden','true');
 const ks=['leaf','leaf2','oak','leaf3','leaf','leaf2','oak','leaf3','leaf','leaf2','leaf3','leaf','oak','leaf2'];let s='';
 ks.forEach((k,i)=>{const dur=11+(i*37%9),dl=-(i*3.7%dur),sz=30+(i*7%18),dx=(i%2?1:-1)*(50+(i*29%80));
  s+=`<i class="fllf" style="--dx:${dx}px;--d:${dur}s;--dl:${dl.toFixed(1)}s;--sw:${(2.4+(i%4)*.6).toFixed(1)}s"><i>${fleIco(k,sz)}</i></i>`});
 L.innerHTML=s;h.prepend(L);flmLeafFit(L)}
addEventListener('resize',()=>{clearTimeout(flmLeafFit.tm);flmLeafFit.tm=setTimeout(()=>{try{const L=ov&&ov.querySelector('.flleaves.flm');if(L)flmLeafFit(L)}catch(e){}},200)});

/* ---------- the crates menu fits above the dock while a seasonal banner is up ---------- */
function flmCratesFit(){const mn=ov.querySelector('.mn');if(!mn||!mn.querySelector('.chub'))return;const sea=mn.querySelector('#flcb,.hwb');if(!sea)return;mn.classList.add('flmfit');
 const tabs=mn.querySelector('.flctabs'),sec=tabs&&tabs.previousElementSibling;if(sec&&sec.classList.contains('chsec'))sec.classList.add('flmsea');
 mn.querySelectorAll('.chub .cc').forEach(cc=>{const sm=cc.querySelector('small');if(sm&&!cc.title)cc.title=sm.textContent})}
{const ch0=crateHub;crateHub=function(){const r=ch0.apply(this,arguments);try{flmCratesFit();if(typeof dkFit==='function')dkFit()}catch(e){}return r}}
/* switching between the Harvest Chest and the Graveyard Crate changes the page height: fit it again */
{const t0=flcTabSet;flcTabSet=function(){const r=t0.apply(this,arguments);try{if(typeof dkFit==='function'&&ov.querySelector('.mn.flmfit'))dkFit()}catch(e){}return r}}

/* ---------- toasts ---------- */
const FLM={quiet:0};
/* the chest toast names its source in words (the calendar and the market pass their short keys) */
{const a0=flcAdd;flcAdd=function(n,src){if(typeof src==='string'&&typeof FLE_SRC==='object'&&FLE_SRC[src])src=FLE_SRC[src];return a0.call(this,n,src)}}
{const t0=flcToast;flcToast=function(){if(FLM.quiet)return;const r=t0.apply(this,arguments);flmStack('flctoast');return r}}
{const t0=fleToast;fleToast=function(){if(FLM.quiet&&!(typeof S==='object'&&S&&S.mode==='play'))return;const r=t0.apply(this,arguments);flmStack('fletoast');return r}}
/* the newest toast goes under the one already showing (both sit at the top right of the stage) */
function flmStack(id){try{const a=document.getElementById(id),o=document.getElementById(id==='flctoast'?'fletoast':'flctoast');if(!a)return;
 const on=e=>!!e&&(e.classList.contains('on')||e.classList.contains('show'));
 if(on(o)&&o.style.top===''){a.style.top=(o.offsetTop+o.offsetHeight+10)+'px'}else if(!on(o)){a.style.top='';if(o)o.style.top=''}}catch(e){}}
/* the end of a Harvest Moon Rush run: the results screen lists the acorns and chests, so no toasts on top of it */
if(typeof flrPay==='function'){const p0=flrPay;flrPay=function(){FLM.quiet=1;try{return p0.apply(this,arguments)}finally{FLM.quiet=0}}}
{const g0=fleGive;fleGive=function(n,src,o){if(FLM.quiet){o=Object.assign({},o||{},{quiet:1})}return g0.call(this,n,src,o)}}

/* the Harvest Market and the Harvest Calendar show their own note / reveal for chests and the Golden Harvest Egg: no second toast there */
if(typeof flpEggAdd==='function'){const e0=flpEggAdd;flpEggAdd=function(n,o){if(FLM.quiet)o=Object.assign({},o||{},{quiet:1});return e0.call(this,n,o)}}
if(typeof FLE_MK==='object')for(const it of FLE_MK){const g0=it.give;
 if(/^(egg|chest|chest5)$/.test(it.k))it.give=function(){FLM.quiet=1;try{return g0.apply(this,arguments)}finally{FLM.quiet=0}};
 /* a companion bought at the market comes back to the market after its reveal (not to the Companion Hall) */
 else if(it.k==='squir'||it.k==='fox')it.give=function(){const id=it.k==='squir'?FL.pets.r:FL.pets.l;return flpGive(id,{back:()=>{try{fleMarket()}catch(e){title()}}})}}
if(typeof fleGift==='function'){const f0=fleGift;fleGift=function(k){if(k==='ch'||k==='gold'){FLM.quiet=1;try{return f0.apply(this,arguments)}finally{FLM.quiet=0}}return f0.apply(this,arguments)}}

/* "Finish a Harvest Moon Rush run" (Gratitude task): the festival counts a run when the Rush pays it acorns; a run that ends without
   acorns counts too (once per run, the same run id; a run quit at once does not) */
if(typeof flrOver==='function'){const o0=flrOver;flrOver=function(quit){const was=S.mode==='over';if(!was){S.ban=null;S.tip=null}/* the level banner would sit behind the results */const r=o0.apply(this,arguments);
 try{if(!was&&!quit&&typeof fleTask==='function'&&S.fleRushRid!==(S.fleRid||-1)){S.fleRushRid=S.fleRid||-1;fleTask('rush',1)}}catch(e){}return r}}

/* the Rush results have their own payout row (XP, gold, acorns, chests): the festival's "+N acorns" line would say it twice */
{const rb0=resBlock;resBlock=function(){const h=rb0.apply(this,arguments);try{if(S&&S.flr)return h.replace(/<p class="flres">[\s\S]*?<\/p>/,'')}catch(e){}return h}}

/* ---------- Harvest Moon Rush: a wave always has its milestone list ---------- */
{const w0=startWave;startWave=function(){try{if(S.flr&&!Array.isArray(S.flrM))S.flrM=[]}catch(e){}return w0.apply(this,arguments)}}

{const st=document.createElement('style');st.textContent=`
/* the Rush card shares a row with the festival card: its LIMITED TIME badge may wrap under the name, clear of the chevron */
.dkmg.flemg .dkm.flrcard .dkmt b{flex-wrap:wrap;white-space:normal;row-gap:3px}
.flleaves.flm{inset:auto;z-index:0}
.flleaves.flm .fllf{animation-name:flmfall}
@keyframes flmfall{from{transform:translate3d(var(--x),-60px,0)}to{transform:translate3d(calc(var(--x) + var(--dx)),var(--fh,960px),0)}}
.mn.flmfit{padding-top:20px}#ov.sh .mn.flmfit>h2+p{margin-top:-4px!important}
.mn.flmfit .chsec{margin:2px auto 8px}.mn.flmfit .chsec.flmsea{display:none}
.mn.flmfit .flctabs{margin:0 auto 10px}.mn.flmfit .flcb{margin-bottom:10px}.mn.flmfit .hwb{margin-bottom:10px}
.mn.flmfit .chub .cc{display:grid;grid-template-columns:92px minmax(0,1fr);grid-template-rows:auto auto auto;column-gap:8px;row-gap:4px;align-content:center;align-items:center;justify-items:start;text-align:left;padding:10px 10px 10px 6px;min-height:0}
.mn.flmfit .chub .cc canvas{grid-row:1/4;grid-column:1;width:92px;height:71px;align-self:center}
.mn.flmfit .chub .cc::after{display:none}
.mn.flmfit .chub .cc b{grid-column:2;font-size:21px;line-height:1.05}
.mn.flmfit .chub .cc small{display:none}
.mn.flmfit .chub .cc .ccn{grid-column:2;margin:0;font-size:12px;padding:2px 10px}
/* the crate card's .ccb also matches the redeem-code dialog's .ccb box (86b); in the compact card it is only a button row */
.mn.flmfit .chub .cc .ccb{grid-column:2;justify-content:flex-start;width:auto;padding:0;margin:0;border:0;border-radius:0;background:none;box-shadow:none;animation:none}
.mn.flmfit .chub .cc .ccb .sm{padding:5px 16px;font-size:14px}
.mn.flmfit>.row{display:none}
`;document.head.appendChild(st)}
