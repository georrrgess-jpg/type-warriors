import asyncio,os
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append('PE '+str(e)[:300]))
        await pg.goto('file://'+os.path.abspath('out.html'));await pg.wait_for_timeout(900);E=pg.evaluate
        await E("()=>{RS_ASK=false;title();P.petSt=2;P.pets={bramble:{b:0}};P.pet='bramble';P.trail={n:2,c:0};petNorm();waStart(0)}");await pg.wait_for_timeout(1500)
        print('arena running',await E("()=>[S.mode,!!S.wa]"))
        await E("()=>{try{waFinish(true)}catch(e){window.__e=String(e)}}");await pg.wait_for_timeout(1500)
        print('arena stamp',await E("()=>[P.trail.n,window.__e||'',S.mode]"))
        await E("()=>{try{waFinish(true)}catch(e){}}");await pg.wait_for_timeout(300);print('no double',await E("()=>P.trail.n"))
        await E("()=>{title();try{ttMenu()}catch(e){window.__t=String(e)}}");await pg.wait_for_timeout(800)
        await E("()=>{try{ttNewRun(0);ttFinish(true)}catch(e){window.__t=String(e)}}");await pg.wait_for_timeout(1000)
        print('treat stamp',await E("()=>[P.trail.n,window.__t||'']"))
        print(er[:6]);await b.close()
asyncio.run(main())
