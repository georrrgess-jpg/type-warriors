# python3 t_w3mobs.py [game.html] [--shots [dir]] : Runestone Tower Defense 10.0 (98e) - the World 3 (Skyforge Heights) monster
# cast: registry (eight constructs plus the Titan's two shed poses), variant names, every id x variant baking 8 animated frames of a
# sane size with nothing clipped, the three variants really differing, the rpvDraw / rpMobDeath wrappers passing other monsters
# through, icons, the gear-and-spring death, the flying Gyrocopter, battles on meadow / foundry / storm with every monster on the
# road (walking, dying, no page errors) and the frame cost of 60 monsters against World 1's.
# --shots also writes the screenshots (sheets per variant, close-ups, battles, deaths, icons) to dir (default shots/w10_w3mobs).
import asyncio,os,sys,base64
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
ARGS=[a for a in sys.argv[1:]]
SHOTS=None
if '--shots' in ARGS:
    i=ARGS.index('--shots');SHOTS=ARGS[i+1] if i+1<len(ARGS) and not ARGS[i+1].endswith('.html') else os.path.join(HERE,'shots','w10_w3mobs')
    ARGS=[a for a in ARGS if a not in('--shots',SHOTS)]
H='file://'+os.path.abspath(ARGS[0] if ARGS else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:500]),flush=True)
    if not ok:FAIL.append(name)
IDS=['cog','knight','steam','gyro','tinker','spring','jammer','titan','titan_p2','titan_p3']
VS=['meadow','foundry','storm']
SETUP="""()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const r=RPP();r.new99j=1;r.dragon=1;r.stars=Object.assign(r.stars||{},{moss:3,frost:3,ember:3});
 for(const k in RP_TUT)r.tut[k]=1;for(const m of['meadow','foundry','storm','coral','wreck','abyss','frost','ember','wonder'])r.tut['twist_'+m]=1;try{save()}catch(e){}}"""
# helpers: opaque pixel counts per frame of a sheet, border alpha, mean colour, a live render graded like the bake
HELP="""()=>{
 window.w3Px=(cv,x,y,w,h)=>{const d=cv.getContext('2d').getImageData(x,y,w,h).data;let n=0,r=0,g=0,b=0;for(let i=3;i<d.length;i+=4)if(d[i]>40){n++;r+=d[i-3];g+=d[i-2];b+=d[i-1]}return n?[n,r/n,g/n,b/n]:[0,0,0,0]};
 window.w3Edge=(cv,x,w,h)=>{const d=cv.getContext('2d').getImageData(x,0,w,h).data,A=(i,j)=>d[(j*w+i)*4+3];let n=0,t=0;for(let i=0;i<w;i++){t+=2;if(A(i,0)>60)n++;if(A(i,h-1)>60)n++}for(let j=0;j<h;j++){t+=2;if(A(0,j)>60)n++;if(A(w-1,j)>60)n++}return n/t};
 window.w3Live=(id,v,ph,S)=>{const B=RPMB[id],X=RPVX[id]||[0,0,0,0],x0=B[0]-X[0],y0=B[1]-X[1],x1=B[2]+X[2],y1=B[3]+X[3],cv=document.createElement('canvas');cv.width=Math.ceil((x1-x0)*S);cv.height=Math.ceil((y1-y0)*S);
  const g=cv.getContext('2d');g.setTransform(S,0,0,S,-x0*S,-y0*S);rpvDraw(g,id,ph,v);g.setTransform(1,0,0,1,0,0);try{rpcGrade(cv,RPC_MG)}catch(e){}return{cv,x0,y0}};
 return 1}"""
# screenshot pages, drawn on a canvas and saved as PNG
ROLE={'cog':'swarm','knight':'guard','steam':'tank','gyro':'flyer','tinker':'support','spring':'leaper','jammer':'disruptor','titan':'boss','titan_p2':'boss, first shed (66%)','titan_p3':'boss, second shed (33%)'}
SHEET="""([v,ROLE])=>{const W=2400,H=1560,c0=document.createElement('canvas');c0.width=W;c0.height=H;const c=c0.getContext('2d'),MAPN={meadow:'Cloudspire Meadows',foundry:'Gearworks Foundry',storm:'Storm Citadel'};
 const bg=c.createLinearGradient(0,0,0,H);bg.addColorStop(0,'#160c2c');bg.addColorStop(1,'#2c1d56');c.fillStyle=bg;c.fillRect(0,0,W,H);
 const vg=c.createRadialGradient(W/2,H*.55,200,W/2,H*.55,W*.7);vg.addColorStop(0,'rgba(120,90,220,.18)');vg.addColorStop(1,'rgba(0,0,0,0)');c.fillStyle=vg;c.fillRect(0,0,W,H);
 c.textAlign='center';c.textBaseline='middle';c.font="400 76px 'Pirata One',Georgia,serif";c.lineWidth=8;c.strokeStyle='#12081f';c.strokeText(MAPN[v],W/2,70);
 const tg=c.createLinearGradient(0,30,0,110);tg.addColorStop(0,'#fff6c0');tg.addColorStop(.55,'#ffd45a');tg.addColorStop(1,'#e08a1a');c.fillStyle=tg;c.fillText(MAPN[v],W/2,70);
 c.font="600 24px Poppins,system-ui,sans-serif";c.fillStyle='#d8ccff';c.fillText('World 3 - Skyforge Heights - the clockwork cast ('+v+' variant)',W/2,128);
 const put=(id,x,y,S,ph)=>{const M=RPMOB[id],B=RPMB[id],L=w3Live(id,v,ph,S),lift=M.air?(M.lift||38)*S:0,sw=B[4]*S*(M.air?.7:1);
  c.save();c.globalAlpha=.55;c.fillStyle='rgba(40,26,80,.9)';c.beginPath();c.ellipse(x,y+6,Math.max(80,sw*1.7),22,0,0,7);c.fill();c.restore();
  c.save();c.globalAlpha=M.air?.5:1;c.drawImage(RPSHD,x-sw,y-sw*.3,sw*2,sw*.6);c.restore();c.drawImage(L.cv,x+L.x0*S,y-lift+L.y0*S);
  c.font="700 27px Poppins,system-ui,sans-serif";c.lineWidth=6;c.strokeStyle='#12081f';const n=rpMobName(id,v);c.strokeText(n,x,y+52);c.fillStyle='#ffffff';c.fillText(n,x,y+52);
  c.font="600 19px Poppins,system-ui,sans-serif";c.fillStyle='#ffd45a';c.fillText((RPMOB[id].n)+' - '+ROLE[id],x,y+84)};
 const R1=['cog','knight','steam','gyro','tinker','spring','jammer'];R1.forEach((id,i)=>put(id,180+i*340,690,id==='steam'?3.4:id==='cog'?4.4:3.9,id==='gyro'?.3:.12));
 ['titan','titan_p2','titan_p3'].forEach((id,i)=>put(id,430+i*770,1400,2.25,.12));
 return c0.toDataURL()}"""
CLOSE="""([id,S,ph,ROLE])=>{const vs=['meadow','foundry','storm'],L=vs.map(v=>w3Live(id,v,ph,S)),cw=Math.max(...L.map(q=>q.cv.width))+40,W=cw*3+40,H=Math.max(...L.map(q=>q.cv.height))+150,c0=document.createElement('canvas');c0.width=W;c0.height=H;const c=c0.getContext('2d');
 const bg=c.createLinearGradient(0,0,0,H);bg.addColorStop(0,'#1a1032');bg.addColorStop(1,'#2e2058');c.fillStyle=bg;c.fillRect(0,0,W,H);c.textAlign='center';c.textBaseline='middle';
 vs.forEach((v,i)=>{const q=L[i],x=20+cw*i+cw/2,y=H-110,M=RPMOB[id],B=RPMB[id],lift=M.air?(M.lift||38)*S:0,sw=B[4]*S*(M.air?.7:1);
  c.save();c.globalAlpha=M.air?.45:.9;c.drawImage(RPSHD,x-sw,y-sw*.3,sw*2,sw*.6);c.restore();c.drawImage(q.cv,x+q.x0*S,y-lift+q.y0*S);
  c.font="700 30px Poppins,system-ui,sans-serif";c.lineWidth=6;c.strokeStyle='#12081f';const n=rpMobName(id,v);c.strokeText(n,x,H-56);c.fillStyle='#fff';c.fillText(n,x,H-56);
  c.font="600 20px Poppins,system-ui,sans-serif";c.fillStyle='#ffd45a';c.fillText(v+' - '+ROLE[id],x,H-22)});return c0.toDataURL()}"""
DEATH="""(v)=>{const ids=['cog','knight','steam','gyro','tinker','spring','jammer','titan_p3'],ks=[0,.06,.16,.3,.45,.62,.82],cw=230,ch=250,W=cw*ks.length,H=ch*ids.length,c0=document.createElement('canvas');c0.width=W;c0.height=H;
 const c=c0.getContext('2d');c.fillStyle='#4e6a3e';c.fillRect(0,0,W,H);c.fillStyle='rgba(255,255,255,.06)';for(let j=0;j<ids.length;j+=2)c.fillRect(0,j*ch,W,ch);
 ids.forEach((id,j)=>ks.forEach((k,i)=>{const x=i*cw+cw*.45,y=j*ch+ch-34,s=id==='titan_p3'?.62:1.7;if(!k)rpMobBlit(c,id,x,y,.12,{s,v});else rpMobDeath(c,id,x,y,k,{s,v,seed:11+j})}));
 c.font="600 18px Poppins,system-ui,sans-serif";c.fillStyle='#fff';c.textAlign='left';ks.forEach((k,i)=>c.fillText(k?'death k='+k:'alive',i*cw+8,22));return c0.toDataURL()}"""
ICONS="""()=>{const ids=['cog','knight','steam','gyro','tinker','spring','jammer','titan','titan_p2','titan_p3'],vs=['meadow','foundry','storm'],S=112,W=ids.length*(S+14)+14,H=vs.length*(S+14)+14,c0=document.createElement('canvas');c0.width=W;c0.height=H;const c=c0.getContext('2d');
 c.fillStyle='#1c1238';c.fillRect(0,0,W,H);vs.forEach((v,j)=>ids.forEach((id,i)=>{const x=14+i*(S+14),y=14+j*(S+14);c.fillStyle='#352a62';c.beginPath();c.roundRect(x,y,S,S,14);c.fill();c.drawImage(rpMobIcon(id,S,v),x,y)}));return c0.toDataURL()}"""
FRAMES="""(v)=>{const ids=['cog','knight','steam','gyro','tinker','spring','jammer','titan'],S=1.7,rows=ids.map(id=>[0,1,2,3,4,5,6,7].map(i=>w3Live(id,v,i/8,id==='titan'?.8:S))),cw=Math.max(...rows.flat().map(q=>q.cv.width))+10,
 rh=rows.map(r=>Math.max(...r.map(q=>q.cv.height))+12),W=cw*8+20,H=rh.reduce((a,b)=>a+b,0)+20,c0=document.createElement('canvas');c0.width=W;c0.height=H;const c=c0.getContext('2d');c.fillStyle='#5a7a4c';c.fillRect(0,0,W,H);
 let y=10;rows.forEach((r,j)=>{r.forEach((q,i)=>c.drawImage(q.cv,10+i*cw,y));y+=rh[j]});return c0.toDataURL()}"""
async def save(pg,expr,arg,name):
    d=await pg.evaluate(expr,arg) if arg is not None else await pg.evaluate(expr)
    open(os.path.join(SHOTS,name),'wb').write(base64.b64decode(d.split(',')[1]));print('  shot',name,flush=True)
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E(SETUP);await E(HELP)
        chk('the game loads with the 98e module and no page errors',not er and await E("()=>typeof rpw3mTitan==='function'"),er)
        # ---------------------------------------------------------------- registry
        r=await E("""(ids)=>ids.map(id=>[id,typeof RPMD[id]==='function',!!RPMB[id]&&RPMB[id].length===5,RPMK[id]>0,!!RPMOB[id],RPW_MOBS[id]===3])""",IDS)
        chk('all ten sprites are registered (RPMD, RPMB, RPMK, RPMOB, RPW_MOBS = 3)',all(all(x[1:]) for x in r),[x for x in r if not all(x[1:])])
        r=await E("()=>['titan_p2','titan_p3'].map(id=>['n','h','w','air','boss','desc'].every(k=>RPMOB[id][k]===RPMOB.titan[k]))")
        chk("titan_p2 / titan_p3 copy the Titan's card (name, size, boss, flags)",all(r),r)
        r=await E("()=>[rpMobName('cog','meadow'),rpMobName('steam','foundry'),rpMobName('gyro','storm'),rpMobName('titan_p2','foundry'),rpMobName('titan_p3','storm'),rpMobName('titan','meadow')]")
        chk('variant names come from RPMOBV (the shed poses keep the Titan name)',r==['Mossy Cogling','Furnace Golem','Storm Gyro','Foundry Titan','Storm Titan','Overgrown Titan'],r)
        r=await E("()=>[rpvV('cog','storm'),rpvV('cog','moss'),rpvV('titan_p3','frost'),rpvV('scamp','frost'),RPMOB.gyro.air,RPMOB.gyro.lift]")
        chk("each map's palette picks the variant (anything else falls back to meadow); the Gyrocopter flies at lift 42",r==['storm','meadow','meadow','frost',True,42],r)
        # ---------------------------------------------------------------- bakes
        r=await E("""([ids,vs])=>{const out=[];for(const id of ids)for(const v of vs){const C=rpvSheet(id,v),M=RPMOB[id];if(!C){out.push([id,v,'none']);continue}
          const px=[];for(let i=0;i<RPNF;i++)px.push(w3Px(C.cv,i*C.fw,0,C.fw,C.fh)[0]);
          const ok=C.cv.width===C.fw*RPNF&&C.h>=M.h*.9&&C.h<=M.h*1.75&&C.w>=M.w*.8&&C.w<=M.w*2.6&&Math.min(...px)>C.fw*C.fh*.08;out.push([id,v,ok,C.fw,C.fh,Math.round(C.w),Math.round(C.h),Math.min(...px)])}return out}""",[IDS,VS])
        chk('every id x variant bakes an 8-frame sheet of a sane size (30 sheets)',len(r)==30 and all(x[2] is True for x in r),[x for x in r if x[2] is not True])
        r=await E("""([ids,vs])=>{const out=[];for(const id of ids)for(const v of vs){const C=rpvSheet(id,v),g=C.cv.getContext('2d'),a=g.getImageData(0,0,C.fw,C.fh).data,b=g.getImageData(C.fw*4,0,C.fw,C.fh).data,c2=g.getImageData(C.fw*2,0,C.fw,C.fh).data;
          let d1=0,d2=0;for(let i=0;i<a.length;i+=4){if(Math.abs(a[i+3]-b[i+3])>80||Math.abs(a[i]-b[i])>60)d1++;if(Math.abs(a[i+3]-c2[i+3])>80||Math.abs(a[i]-c2[i])>60)d2++}out.push([id,v,d1,d2])}return out}""",[IDS,VS])
        chk('the frames animate (walk, hop, rotor, gears: frames 0, 2 and 4 differ)',all(x[2]>150 and x[3]>150 for x in r),[x for x in r if not(x[2]>150 and x[3]>150)])
        r=await E("""([ids,vs])=>{const out=[];for(const id of ids)for(const v of vs){const C=rpvSheet(id,v);let mx=0;for(let i=0;i<RPNF;i++)mx=Math.max(mx,w3Edge(C.cv,i*C.fw,C.fw,C.fh));out.push([id,v,+mx.toFixed(4)])}return out}""",[IDS,VS])
        chk('nothing is clipped by the frame box (opaque pixels on a frame edge stay under 1%)',all(x[2]<.01 for x in r),[x for x in r if x[2]>=.01])
        r=await E("""(ids)=>ids.map(id=>{const m=['meadow','foundry','storm'].map(v=>{const C=rpvSheet(id,v),q=w3Px(C.cv,0,0,C.fw,C.fh);return q.slice(1).map(Math.round)});
          const dist=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1],a[2]-b[2]);const lum=q=>.3*q[0]+.59*q[1]+.11*q[2];return [id,Math.round(dist(m[0],m[1])),Math.round(dist(m[0],m[2])),Math.round(dist(m[1],m[2])),lum(m[1])<lum(m[2]),m[0][1]-m[0][2]>m[2][1]-m[2][2]]})""",IDS)
        chk('the three variants really differ (meadow greener than storm, foundry soot darker than storm silver)',all(min(x[1:4])>20 and x[4] and x[5] for x in r),r)
        r=await E("""()=>{const out={};for(const [id,v] of [['cog','meadow'],['knight','foundry'],['steam','storm'],['tinker','meadow'],['spring','storm'],['jammer','foundry'],['titan','meadow']]){
          const cv=document.createElement('canvas');cv.width=400;cv.height=400;const g=cv.getContext('2d');g.translate(200,330);rpvDraw(g,id,.12,v);let d=g.getImageData(0,0,400,400).data,y0=400,y1=0,x0=400,x1=0;
          for(let y=0;y<400;y++)for(let x=0;x<400;x++)if(d[(y*400+x)*4+3]>60){if(y<y0)y0=y;if(y>y1)y1=y;if(x<x0)x0=x;if(x>x1)x1=x}out[id]=[+((y1-y0)/RPMOB[id].h).toFixed(2)]}return out}""")
        chk('the drawn height matches RPMOB.h (0.85 to 1.45 of it, crests and smoke included)',all(.85<=x[0]<=1.45 for x in r.values()),r)
        # ---------------------------------------------------------------- wrappers
        r=await E("""()=>{const cv=document.createElement('canvas');cv.width=cv.height=200;const g=cv.getContext('2d');g.translate(100,170);let err='';try{rpvDraw(g,'scamp',.2,'frost');rpvDraw(g,'golem',.2,'ember')}catch(e){err=String(e)}
          let e2='';try{rpvDraw(g,'crab',.2,'coral');rpvDraw(g,'leviathan',.2,'abyss')}catch(e){e2=String(e)}return [err,e2,w3Px(cv,0,0,200,200)[0]>800,!!rpvSheet('scamp','frost'),!!rpvSheet('behemoth','moss')]}""")
        chk('rpvDraw passes every other monster through (World 1 variants still draw; World 2 ids are left to their module)',r[0]=='' and r[1]=='' and r[2] and r[3] and r[4],r)
        # ---------------------------------------------------------------- icons
        r=await E("""([ids,vs])=>{const out=[];for(const id of ids)for(const v of vs){const cv=rpMobIcon(id,64,v);out.push([id,v,cv.width,w3Px(cv,0,0,64,64)[0]])}return out}""",[IDS,VS])
        chk('icons: a 64 px portrait for every id x variant',all(x[2]==64 and x[3]>500 for x in r),[x for x in r if not(x[2]==64 and x[3]>500)])
        r=await E("()=>{const a=rpMobIcon('cog',64,'meadow'),b=rpMobIcon('cog',64,'storm');return a!==b&&a.toDataURL()!==b.toDataURL()}")
        chk('icons differ per variant',r,r)
        # ---------------------------------------------------------------- deaths
        r=await E("""([ids,vs])=>{const out=[];let err='';for(const id of ids)for(const v of vs){const ks=[.04,.2,.45,.75,.95],n=[];for(const k of ks){const cv=document.createElement('canvas');cv.width=cv.height=420;const g=cv.getContext('2d');
          try{rpMobDeath(g,id,210,320,k,{v,seed:5})}catch(e){err=id+v+e}n.push(w3Px(cv,0,0,420,420)[0])}const cv=document.createElement('canvas');cv.width=cv.height=420;rpMobDeath(cv.getContext('2d'),id,210,320,1,{v});n.push(w3Px(cv,0,0,420,420)[0]);out.push([id,v,n])}return [err,out]}""",[IDS,VS])
        chk('the death draws a pop and debris all the way through and nothing at k = 1',r[0]=='' and all(min(x[2][:4])>40 and x[2][5]==0 for x in r[1]),[r[0]]+[x for x in r[1] if not(min(x[2][:4])>40 and x[2][5]==0)][:4])
        r=await E("""()=>{const kinds=['g','h','b','s','p','l','q'],out=[];for(const v of ['meadow','foundry','storm'])for(const k of kinds){const cv=rpw3mDeb(v,k);out.push(w3Px(cv,0,0,40,40)[0])}
          const cv=document.createElement('canvas');cv.width=cv.height=300;rpMobDeath(cv.getContext('2d'),'scamp',150,250,.3,{v:'frost'});return [Math.min(...out),w3Px(cv,0,0,300,300)[0]]}""")
        chk('the debris sprites (gears, nuts, springs, plates, leaves) bake; World 1 deaths still work',r[0]>60 and r[1]>200,r)
        r=await E("""()=>{const cv=document.createElement('canvas');cv.width=300;cv.height=300;const g=cv.getContext('2d');rpMobBlit(g,'gyro',150,260,.2,{v:'storm'});const d=g.getImageData(0,0,300,300).data;let yb=0;
          for(let y=0;y<300;y++)for(let x=0;x<300;x++)if(d[(y*300+x)*4+3]>120)yb=Math.max(yb,y);return yb}""")
        chk('the Gyrocopter is drawn in the air above its shadow',r<260-20 and r>100,r)
        # ---------------------------------------------------------------- battles
        for m in VS:
            r=await E("""([m,ids])=>{rpStart(m);RPX.tut=null;const R=RPX,L=R.G.paths[0].S.length*4,out=[];let err='';
              ids.forEach((id,i)=>{const e=rpSpawn(id.startsWith('titan')?'titan':id,i%R.G.paths.length);e.id=id;e.s=L*(.05+i*.075);out.push(e)});
              for(let i=0;i<42;i++){const id=ids[i%7],e=rpSpawn(id,i%R.G.paths.length);e.s=L*(.02+.76*i/42)}
              R.wst='run';R.q=[];try{for(let i=0;i<120;i++){rpStep(R,1/60);if(i%10===0)rpDraw()}}catch(e){err=String(e)}
              const moved=out.filter(e=>e.s>0).length,alive=R.foes.length;for(const e of R.foes.slice(0,20))if(!e.dead)rpKillFoe(e);let dying=0;try{for(let i=0;i<30;i++){rpStep(R,1/60);rpDraw();if(i===8)dying=R.foes.filter(e=>e.dead&&!e.leak).length}}catch(e){err=err||String(e)}
              return [err,moved,alive,dying,R.map.pal,R.foes.filter(e=>e.dead).length]}""",[m,IDS])
            chk('battle on '+m+': all ten sprites walk the road with 42 more, then die into debris, without errors',r[0]=='' and r[1]==10 and r[2]>=48 and r[3]>=15 and r[4]==m and not er,[r,er])
        # ---------------------------------------------------------------- frame cost
        r=await E("""async()=>{const run=(m,ids,boss)=>{rpStart(m);RPX.tut=null;const R=RPX,L=R.G.paths[0].S.length*4;for(let i=0;i<60;i++){const e=rpSpawn(i===0?boss:ids[i%ids.length],i%R.G.paths.length);e.s=L*(.03+.94*i/60)}
           for(let i=0;i<15;i++)rpDraw();const c=document.createElement('canvas');c.width=1600;c.height=900;const g=c.getContext('2d'),F=R.foes.map(e=>[e,rpPos(R,e)]);
           const blit=()=>{const t=performance.now();for(let k=0;k<20;k++)for(const [e,q] of F)rpMobBlit(g,e.id,q.x,q.y,(e.ph+k*.05)%1,{v:R.map.pal,flip:Math.cos(q.a)<-.2});return (performance.now()-t)/20};
           const draw=()=>{const t=performance.now();for(let k=0;k<20;k++){for(const e of R.foes)e.ph=(e.ph+.05)%1;rpDraw()}return (performance.now()-t)/20};
           blit();const b=[],d=[];for(let k=0;k<5;k++){b.push(blit());d.push(draw())}b.sort((x,y)=>x-y);d.sort((x,y)=>x-y);return [+b[2].toFixed(2),+d[2].toFixed(2)]};
          const w1=run('moss',['scamp','bulwark','golem','gloom','ooze','shaman'],'behemoth'),w3=['meadow','foundry','storm'].map(m=>run(m,['cog','knight','steam','gyro','tinker','spring','jammer'],'titan'));return [w1,w3]}""")
        w1,w3=r;print('  frame cost, 60 monsters (median ms): World 1 blit %.2f / frame %.2f; World 3 blit %s / frame %s'%(w1[0],w1[1],[x[0] for x in w3],[x[1] for x in w3]),flush=True)
        chk('frame cost: blitting 60 World 3 monsters costs about what 60 World 1 monsters cost (baked, two drawImages each)',all(x[0]<=w1[0]*1.6+1 for x in w3),r)
        chk('frame cost: a whole battle frame with 60 World 3 monsters stays close to World 1',all(x[1]<=w1[1]*1.5+3 for x in w3),r)
        chk('no page errors during the run',not er,er)
        # ---------------------------------------------------------------- screenshots
        if SHOTS:
            os.makedirs(SHOTS,exist_ok=True)
            await E("()=>{try{rpLeave()}catch(e){}RPX=null}")  # full detail (a slow test machine may have switched the battle to lite)
            for v in VS:await save(pg,SHEET,[v,ROLE],'sheet_%s.png'%v)
            for id,S,ph in [('cog',8.4,.12),('knight',6,.12),('steam',4.6,.12),('gyro',7.2,.3),('tinker',6,.12),('spring',6.4,.12),('jammer',6.4,.12),('titan',2.6,.12),('titan_p2',2.6,.12),('titan_p3',2.6,.12)]:
                await save(pg,CLOSE,[id,S,ph,ROLE],'close_%s.png'%id)
            for v in VS:await save(pg,DEATH,v,'deaths_%s.png'%v)
            await save(pg,ICONS,None,'icons.png')
            for v in VS:await save(pg,FRAMES,v,'frames_%s.png'%v)
            for m in VS:
                await E("""([m,ids])=>{rpStart(m);RPX.tut=null;const R=RPX,L=R.G.paths[0].S.length*4;R.foes.length=0;
                  const pads=R.pads.slice().sort((a,b)=>a.x-b.x),T=RP_TWORDER.filter(t=>RP_TW[t]);pads.forEach((p,i)=>{if(i%2)return;R.supply=1e6;if(rpBuild(p,T[(i/2)%T.length])){p.tw.build=1;rpUpgrade(p.tw);if(p.tw.upK!=null)p.tw.upK=1}});
                  const pick=[];for(let s=L*.38;s<L*.97&&pick.length<3;s+=8){const q=rpAt(R.G,s,0);if(q.y>320&&q.y<700&&q.x<1300&&pick.every(p=>Math.hypot(p.x-q.x,p.y-q.y)>270))pick.push(s)}
                  ids.forEach((id,i)=>{const e=rpSpawn(id.startsWith('titan')?'titan':id,i<7?i%R.G.paths.length:0);e.id=id;e.s=i<7?L*(.1+i*.055):(pick[i-7]||L*(.5+(i-7)*.15));e.hp=e.mx*40;e.mx=e.hp});
                  for(let i=0;i<30;i++){const e=rpSpawn(ids[i%7],i%R.G.paths.length);e.s=L*(.04+.86*i/30);e.hp=e.mx*40;e.mx=e.hp}R.wst='run';R.q=[];R.cd=99;
                  for(let i=0;i<50;i++)rpStep(R,1/60);for(const e of R.foes)e.hp=e.mx*(.35+Math.random()*.6);R.supply=860;R.tx.length=0}""",[m,IDS])
                await pg.wait_for_timeout(500)
                await pg.screenshot(path=os.path.join(SHOTS,'battle_%s.png'%m));print('  shot battle_%s.png'%m,flush=True)
                await pg.screenshot(path=os.path.join(SHOTS,'battle_%s_zoom.png'%m),clip={'x':140,'y':120,'width':800,'height':560})
                await E("()=>{RPX.pause=true}")
            await E("()=>{try{rpLeave()}catch(e){}}")
        await b.close()
    print('%d/%d checks passed'%(N[0]-len(FAIL),N[0]))
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
