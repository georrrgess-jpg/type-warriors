# python3 t_pzb106c.py [out.html] : 10.6 ball sets Dragonscale and Diamond Brilliance (97b9_pz_balls_scale_diamond.js).
# Registration (id, name, price, tag, PZ_BALLS entry, palette kind), the owner's ball rule measured for just these two sets (same
# measurement and thresholds as t_pzb102.py), paint cost against Starfall and Ember Core, no broken pixels (NaN would paint black),
# the sets differ from each other and from Gemstone / Champion Gold, a real match with each set equipped, screenshots in shots/w106_balls.
import asyncio,os,sys,re
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
SHOTS=os.path.join(HERE,'shots','w106_balls');os.makedirs(SHOTS,exist_ok=True)
src=open(os.path.join(HERE,'t_pzb102.py')).read().split('async def start')[0]
_argv=sys.argv;sys.argv=[_argv[0]];NS={'__file__':os.path.join(HERE,'t_pzb102.py')};exec(src,NS);sys.argv=_argv
MEASURE=NS['MEASURE'].replace("PZ_BALLS.map(b=>b.id)","['dragon','diamond']");SETUP=NS['SETUP'];PRE=NS['PRE']
SETS=[('dragon','Dragonscale',35000,'Armour grown by dragons.'),('diamond','Diamond Brilliance',75000,'Cut like the finest diamond in the vault.')]
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:700]),flush=True)
    if not ok:FAIL.append(name)
SHEETJS=r"""(sets)=>{const D=64,S=64,G=6,Z=3,views=[pzbRot(pzbRot(pzbI(),0,1,0,.28),1,0,0,-.22),pzbRot(pzbRot(pzbI(),1,0,0,1.05),0,1,0,.5)];
 const rowsH=sets.length*(2*(S+G)+S*Z+G+10)+6,W=16*(S+G)+G,c=document.createElement('canvas');c.width=W;c.height=rowsH;const g=c.getContext('2d');g.imageSmoothingEnabled=false;g.fillStyle='#1d6b45';g.fillRect(0,0,W,rowsH);
 let y=6;for(const s of sets){pzbSetup(D,s);views.forEach((M,vi)=>{for(let n=0;n<16;n++){pzbPaint(15,n,M);g.drawImage(PZ_BS.atlas,15*D,0,D,D,G+n*(S+G),y+vi*(S+G),S,S)}});y+=2*(S+G);
  [1,9,8].forEach((n,i)=>{pzbPaint(15,n,views[0]);g.drawImage(PZ_BS.atlas,15*D,0,D,D,G+i*(S*Z+G),y,S*Z,S*Z)});[3,12,8].forEach((n,i)=>{pzbPaint(15,n,views[1]);g.drawImage(PZ_BS.atlas,15*D,0,D,D,G+(i+3)*(S*Z+G),y,S*Z,S*Z)});y+=S*Z+G+10}
 pzbSetup(52,'classic');return c.toDataURL('image/png')}"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();er=[]
        pg=await b.new_page(viewport={'width':1600,'height':900});E=pg.evaluate
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(H);await pg.wait_for_timeout(1500);await E(PRE);await E("()=>document.fonts.ready");await pg.add_script_tag(path=os.path.join(HERE,"..","tools","pz","scen.js"))
        # registration
        r=await E("""(S)=>S.map(([id,n,pr,tag])=>{const b=PZ_BALLS.find(x=>x.id===id),pal=PZ_BPAL[id];return !!b&&b.n===n&&b.price===pr&&!!b.how&&b.how.includes(pr.toLocaleString())&&!!pal&&pal.kind===id&&PZ_TAG97[id]===tag&&typeof pzBallCard97==='function'}).concat([PZ_BALLS.filter(b=>b.id==='dragon'||b.id==='diamond').length===2])""",[list(s) for s in SETS])
        chk('both sets registered: id, name, price (35,000 / 75,000), how-to-get, tag, palette kind, one PZ_BALLS entry each',all(r),r)
        # the rule
        R=await E(MEASURE)
        keys=['stripeLight','capMin','solidLight','pairGap','solidCol','stripeCol','y8','yMin','ratio8','disc8','num8','numMin','cueY','cueS']
        print('  %-8s'%'set'+''.join('%11s'%k for k in keys))
        for s,v in R.items():print('  %-8s'%s+''.join('%11s'%v[k] for k in keys))
        bad=lambda f:{s:v for s,v in R.items() if not f(v)}
        x=bad(lambda v:v['stripeLight']>=.22 and v['capMin']>=.2 and v['stripeCol']>=.2);chk('stripes: clearly light caps above and below a coloured band',not x,x)
        x=bad(lambda v:v['solidLight']<=.08 and v['solidCol']>=.5);chk('solids: coloured all over',not x,x)
        x=bad(lambda v:v['pairGap']>=.18 and v['stripeLight']-v['solidLight']>=.18);chk('stripes and solids told apart by the light area',not x,x)
        x=bad(lambda v:v['ratio8']<=.62 and v['y8']<=60);chk('the 8 is clearly the darkest ball',not x,x)
        x=bad(lambda v:v['disc8']>=4.5 and v['num8']>=4.5);chk('the 8 has a high-contrast disc and number',not x,x)
        x=bad(lambda v:v['numMin']>=4);chk('every number is readable on its disc (>= 4:1)',not x,x)
        x=bad(lambda v:v['cueY']>=150 and v['cueS']<=.12);chk('the cue ball is white',not x,x)
        # no broken pixels, no matter how it is turned
        r=await E("""()=>{const out={};for(const s of ['dragon','diamond']){pzbSetup(64,s);const P=PZ_BS,D=P.D;let bad=0,seed=77;const rng=()=>{seed=(seed*16807)%2147483647;return seed/2147483647};
          for(let k=0;k<40;k++){const M=pzbRandM(rng);for(const n of [1,4,8,9,12,15]){pzbPaint(15,n,M);const d=P.ax.getImageData(15*D,0,D,D).data;for(let j=0;j<P.n;j++){if(P.al[j]<.98)continue;const o=P.idx[j]*4;if(d[o]+d[o+1]+d[o+2]<4&&n!==8)bad++;if(d[o+3]<250)bad++}}}out[s]=bad}pzbSetup(52,'classic');return out}""")
        chk('no broken pixels (black or transparent holes) in 240 random turns per set',all(v==0 for v in r.values()),r)
        # the patterns roll with the ball: the same orientation gives the same picture, a different one a different picture
        r=await E("""()=>{const out={};for(const s of ['dragon','diamond']){pzbSetup(64,s);const P=PZ_BS,D=P.D,px=M=>{pzbPaint(15,1,M);return P.ax.getImageData(15*D,0,D,D).data};
          const a=px(pzbRot(pzbI(),0,1,0,.4)),a2=px(pzbRot(pzbI(),0,1,0,.4)),c=px(pzbRot(pzbI(),0,1,0,1.3));let same=0,diff=0;for(let i=0;i<a.length;i++){same+=Math.abs(a[i]-a2[i]);diff+=Math.abs(a[i]-c[i])}out[s]=[same,diff>a.length*4]}pzbSetup(52,'classic');return out}""")
        chk('paint is repeatable and the pattern changes as the ball turns',all(v[0]==0 and v[1] for v in r.values()),r)
        # differ from each other and from the older metal / gem sets
        r=await E("""()=>{const sets=['dragon','diamond','gem','metal','royal','moon'],px={},D=64;for(const s of sets){pzbSetup(D,s);const P=PZ_BS,a=[];for(const n of [1,9,8]){pzbPaint(15,n,pzbRot(pzbRot(pzbI(),0,1,0,.28),1,0,0,-.22));a.push(P.ax.getImageData(15*D,0,D,D).data)}px[s]=a}
          const dist=(x,y)=>{let t=0,c=0;for(let k=0;k<3;k++)for(let i=0;i<x[k].length;i+=4){if(x[k][i+3]<250)continue;t+=Math.abs(x[k][i]-y[k][i])+Math.abs(x[k][i+1]-y[k][i+1])+Math.abs(x[k][i+2]-y[k][i+2]);c++}return t/c};
          const o={};for(const s of ['dragon','diamond'])for(const t of sets)if(t!==s)o[s+'/'+t]=+dist(px[s],px[t]).toFixed(1);pzbSetup(52,'classic');return o}""")
        chk('Dragonscale and Diamond Brilliance clearly differ from each other, Gemstone, Champion Gold, Royal and Moonstone (mean colour distance >= 25)',min(r.values())>=25,r)
        # cost
        r=await E("""()=>{const S=['galaxy','lava','dragon','diamond'],R={};S.forEach(s=>R[s]=1e9);const ns=[1,5,9,12,8,3];for(let tr=0;tr<7;tr++)for(const s of S){pzbSetup(64,s);for(let w=0;w<12;w++)pzbPaint(15,ns[w%6],pzbRot(pzbI(),1,0,0,w*.1));const t0=performance.now();for(let k=0;k<200;k++)pzbPaint(15,ns[k%6],pzbRot(pzbRot(pzbI(),0,1,0,k*.07),1,0,0,tr));R[s]=Math.min(R[s],+((performance.now()-t0)/200).toFixed(3))}pzbSetup(52,'classic');return R}""")
        print('  ms per 64 px paint',r)
        lim=1.65*max(r['galaxy'],r['lava'])
        chk('paint cost per 64 px ball within about 1.5x (limit 1.65x for machine noise) of the dearer of Starfall and Ember Core',r['dragon']<=lim and r['diamond']<=lim,[r,lim])
        # sheet
        import base64
        u=await E(SHEETJS,['dragon','diamond']);open(os.path.join(SHOTS,'c_sheet.png'),'wb').write(base64.b64decode(u.split(',')[1]))
        # a real match with each set equipped, the Cue Rack with both
        for sid,nm,_,_ in SETS:
            await E(PRE)
            await E("(a)=>{const [s]=a;const Z=PZS();Z.ballsets[s]=1;Z.balls=s;Z.beat.grizzle=1;save()}",[sid])
            await E("()=>{casinoOpen();gameOpen('pz');pzStart({opp:'grizzle',practice:true,seed:7});setTimeout(()=>{const i=document.getElementById('pzintro');if(i)i.click()},500);0}")
            await pg.wait_for_timeout(3500);await E("async()=>{await SC.ready()}")
            await E(SETUP,['s',-1,0]);await pg.wait_for_timeout(900)
            ok=await E("()=>!!PZ.on&&PZ.B.length>=16&&PZ_BS.pal===PZ_BPAL[PZ.pzSet||PZS().balls]||PZ_BS.set==='%s'"%sid)
            await pg.screenshot(path=os.path.join(SHOTS,'c_match_%s.png'%sid))
            chk('a match with %s equipped draws (screenshot c_match_%s.png)'%(nm,sid),ok,ok)
            await E("()=>{pzForfeit&&pzForfeit()}");await pg.wait_for_timeout(400)
        await E("()=>{if(typeof pzLeave==='function')pzLeave(true);PZ.rackTab='balls';pzCueRack();0}");await pg.wait_for_timeout(1500)
        r=await E("""()=>{const cs=[...document.querySelectorAll('.pzkwall.balls canvas[data-sw]')];return cs.map(c=>{const d=c.getContext('2d').getImageData(0,0,300,100).data;let k=0;for(let i=3;i<d.length;i+=4)if(d[i]>200)k++;return k})}""")
        chk('the Cue Rack draws a card (solid, stripe, 8) for the new sets too',len(r)>=10 and min(r)>6000,r)
        await pg.screenshot(path=os.path.join(SHOTS,'c_rack.png'))
        chk('no page errors',not er,er)
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
