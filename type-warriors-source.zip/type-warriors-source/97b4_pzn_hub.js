/* ===== 10.1 THE CROOKED CUE: Orbit 8, the hub and the way in (97b4) =====
   The way in: a "shuttle pass" button in the Crooked Cue hub's top bar (pznTicket). Locked until you beat Grizzle (it says so),
   NEW until your first visit, then a plain switch; O works as a key both ways. Beating Grizzle the first time puts a NEW VENUE card
   on the results. Which hub you were last in is remembered (P.pz.venue), so the casino tile, "The bar" on the results, the side
   screens and a finished Orbit 8 match all come back to the right room (pzHub is wrapped; it opens pznHub when P.pz.venue is 'o8').
   The Orbit 8 hub (pznHub) mirrors the 9.7 hub so every key, test hook and the stake logic carry over: the same ids (#pzh, .pzrow
   medallions, #pzopp spotlight via the shared pzHubOpp, #pz97bar with #pzrackem and #pzprac, .pznav), the same money flow
   (pzStart with the stake, the daily cap, the 5,000 limit). Its own look: a panoramic window on a ringed gas giant, a floating halo
   light, the table in perspective on a holo platform (chrome rails, neon inlay, glowing pockets, hover pods), holo medallions in a
   clockwise orbit (Bleep, Octavia, Facet, Rex, then Empress Vantara in the champion's seat), Bleep tending a hover bar at the
   bottom left and the VIP lounge at the bottom right where the players you have met relax. Results, The Regulars and the
   spotlight are wrapped to show the Orbit 8 players with venue backdrops. Per frame: two slow LIVE canvases (window, foreground). */
const PZN_SLOT={bleep:[418,500,120],octavia:[440,262,120],facet:[926,262,120],rex:[930,500,120],vantara:[682,546,128]};
const PZN_HUB={bg:null,tb:null,cone:null,port:{},stage:{},ico:{}};
/* ---------- baked art ---------- */
function pznIco(kind,S){const key=kind+S;if(PZN_HUB.ico[key])return PZN_HUB.ico[key];const c=pzCv(S,S),g=c.getContext('2d');g.scale(S/120,S/120);g.lineJoin='round';g.lineCap='round';
 if(kind==='planet'){pzGlow(g,60,60,58,'rgba(140,200,255,1)',.35);g.save();g.translate(60,62);g.rotate(-.35);g.strokeStyle='#ffe0a8';g.lineWidth=7;g.beginPath();g.ellipse(0,0,54,13,0,Math.PI,TAU);g.stroke();g.restore();
  g.save();g.beginPath();g.arc(60,62,32,0,TAU);g.clip();g.fillStyle='#e8a060';g.fillRect(20,20,80,90);for(let i=0;i<6;i++){g.fillStyle=['#f4d0a0','#d8804a','#f0c088','#b8603a','#e8b07a','#c87048'][i];g.fillRect(20,30+i*11,80,6)}g.fillStyle='rgba(20,8,40,.45)';g.beginPath();g.arc(74,74,34,0,TAU);g.fill();g.restore();
  g.strokeStyle=PZ_O;g.lineWidth=4;g.beginPath();g.arc(60,62,32,0,TAU);g.stroke();g.fillStyle='#fff';g.beginPath();g.arc(56,58,13,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2.5;g.stroke();g.fillStyle='#12081f';g.font='800 17px Poppins,sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillText('8',56,59);
  g.save();g.translate(60,62);g.rotate(-.35);g.strokeStyle='#ffe0a8';g.lineWidth=7;g.beginPath();g.ellipse(0,0,54,13,0,0,Math.PI);g.stroke();g.strokeStyle=PZ_O;g.lineWidth=2;g.beginPath();g.ellipse(0,0,58,16,0,0,Math.PI);g.stroke();g.restore()}
 else if(kind==='mug'){g.fillStyle='#e8a43a';pzRR(g,30,34,52,66,10);g.fill();g.strokeStyle=PZ_O;g.lineWidth=4;g.stroke();g.strokeStyle=PZ_O;g.lineWidth=12;g.beginPath();g.arc(84,66,16,-1.2,1.2);g.stroke();g.strokeStyle='#c8862a';g.lineWidth=6;g.stroke();
  g.fillStyle='#fff8e8';g.beginPath();g.arc(38,34,12,0,TAU);g.arc(56,30,14,0,TAU);g.arc(74,34,11,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();g.fillStyle='rgba(255,255,255,.45)';g.fillRect(38,46,6,44);g.strokeStyle='rgba(120,60,10,.6)';g.lineWidth=3;g.beginPath();g.moveTo(56,48);g.lineTo(56,92);g.stroke()}
 return PZN_HUB.ico[key]=c}
function pznHubBg(){if(PZN_HUB.bg)return PZN_HUB.bg;const c=pzCv(1600,900),g=c.getContext('2d');g.lineJoin='round';g.lineCap='round';g.fillStyle='#0a0a22';g.fillRect(0,0,1600,900);
 /* ceiling and skylight */
 g.fillStyle=pzLin(g,0,0,0,112,[[0,'#151838'],[1,'#0c0e26']]);g.fillRect(0,0,1600,112);g.save();g.beginPath();g.rect(0,6,1600,96);g.clip();pznSpaceFill(g,0,6,1600,96,71);g.restore();
 for(let x=-20;x<1640;x+=160){g.fillStyle=pzLin(g,x-10,0,x+10,0,[[0,'#1a1e3a'],[.5,'#4a5278'],[1,'#1a1e3a']]);g.fillRect(x-9,0,18,106);g.strokeStyle=PZ_O;g.lineWidth=3;g.strokeRect(x-9,0,18,106)}
 /* the panoramic window */
 const wy0=118,wy1=338;g.save();g.beginPath();g.rect(0,wy0,1600,wy1-wy0);g.clip();pznSpaceFill(g,0,wy0,1600,wy1-wy0,97);pznNebula(g,880,200,260,'rgba(255,90,190,A)',.22);pznNebula(g,420,300,240,'rgba(70,200,255,A)',.18);
 pznPlanet(g,560,262,92,-.28);pznStation(g,866,268,40);g.fillStyle='#d8d4e8';g.beginPath();g.arc(1000,196,22,0,TAU);g.fill();g.fillStyle='rgba(20,10,40,.55)';g.beginPath();g.arc(1008,201,21,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2.5;g.beginPath();g.arc(1000,196,22,0,TAU);g.stroke();g.restore();
 g.fillStyle=pzLin(g,0,104,0,124,[[0,'#3a4470'],[1,'#1a1e3a']]);g.fillRect(0,104,1600,18);g.fillStyle='#7af8ff';g.fillRect(0,114,1600,2.5);
 for(const x of[408,1036]){g.fillStyle=pzLin(g,x-12,0,x+12,0,[[0,'#1a1e3a'],[.5,'#5a6490'],[1,'#1a1e3a']]);g.fillRect(x-11,wy0,22,wy1-wy0);g.strokeStyle=PZ_O;g.lineWidth=3;g.strokeRect(x-11,wy0,22,wy1-wy0)}
 g.fillStyle='rgba(255,255,255,.04)';g.beginPath();g.moveTo(430,wy0);g.lineTo(520,wy0);g.lineTo(440,wy1);g.lineTo(420,wy1);g.closePath();g.fill();
 /* the sill */
 g.fillStyle=pzLin(g,0,wy1,0,wy1+26,[[0,'#4a5278'],[1,'#1a1e3a']]);g.fillRect(0,wy1,1600,24);g.strokeStyle=PZ_O;g.lineWidth=3;g.beginPath();g.moveTo(0,wy1);g.lineTo(1600,wy1);g.moveTo(0,wy1+24);g.lineTo(1600,wy1+24);g.stroke();g.fillStyle='#ff6ad5';g.fillRect(0,wy1+15,1600,2.5);for(let x=0;x<1600;x+=90)pzGlow(g,x+45,wy1+16,46,'rgba(255,106,213,1)',.14);
 /* the deck in perspective */
 const fy=wy1+24,vx=PZ97_TX,vy=-340,tq=(fy-vy)/(900-vy);g.fillStyle='#141838';g.fillRect(0,fy,1600,900-fy);
 for(let i=-24;i<=24;i++){const b0=vx+i*90,b1=vx+(i+1)*90,t0=vx+(b0-vx)*tq,t1=vx+(b1-vx)*tq;g.fillStyle=pzMix('#161a40','#1c2150',pzNoise(i+31));g.beginPath();g.moveTo(t0,fy);g.lineTo(t1,fy);g.lineTo(b1,900);g.lineTo(b0,900);g.closePath();g.fill();
  g.strokeStyle=i%4===0?'rgba(122,248,255,.35)':'rgba(0,0,0,.45)';g.lineWidth=i%4===0?2.5:2;g.beginPath();g.moveTo(t0,fy);g.lineTo(b0,900);g.stroke()}
 for(let k=1;k<9;k++){const yy=fy+(900-fy)*Math.pow(k/9,1.5);g.strokeStyle='rgba(0,0,0,.4)';g.lineWidth=2;g.beginPath();g.moveTo(0,yy);g.lineTo(1600,yy);g.stroke();g.strokeStyle='rgba(150,170,255,.06)';g.beginPath();g.moveTo(0,yy+2);g.lineTo(1600,yy+2);g.stroke()}
 g.fillStyle=pzLin(g,0,fy,0,fy+100,[[0,'rgba(4,2,16,.7)'],[1,'rgba(4,2,16,0)']]);g.fillRect(0,fy,1600,100);
 /* the holo platform under the table */
 {const cx=PZ97_TX,cy=470;g.fillStyle='rgba(4,2,16,.55)';g.beginPath();g.ellipse(cx,cy+8,292,94,0,0,TAU);g.fill();g.fillStyle='#10163a';g.beginPath();g.ellipse(cx,cy,284,88,0,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();
  for(const [rx,ry,c,lw] of[[270,82,'rgba(122,248,255,.75)',3],[240,72,'rgba(122,248,255,.3)',2],[200,58,'rgba(255,106,213,.35)',2],[150,42,'rgba(122,248,255,.18)',1.5]]){g.strokeStyle=c;g.lineWidth=lw;g.beginPath();g.ellipse(cx,cy,rx,ry,0,0,TAU);g.stroke()}
  for(let i=0;i<36;i++){const a=i/36*TAU;g.strokeStyle='rgba(122,248,255,.4)';g.lineWidth=2;g.beginPath();g.moveTo(cx+Math.cos(a)*270,cy+Math.sin(a)*82);g.lineTo(cx+Math.cos(a)*282,cy+Math.sin(a)*87);g.stroke()}
  pzGlow(g,cx,cy,300,'rgba(120,220,255,1)',.14)}
 pzGlow(g,PZ97_TX,410,330,'rgba(200,235,255,1)',.12);
 /* bottom left: a hydroponic tank and Bleep's hover bar (back half; the counter front is drawn live) */
 {const x=22,y=770;g.fillStyle='rgba(20,60,40,.6)';pzRR(g,x,y,78,200,30);g.fill();g.fillStyle=pzLin(g,0,y,0,y+200,[[0,'rgba(120,255,180,.25)'],[1,'rgba(40,160,110,.35)']]);pzRR(g,x,y,78,200,30);g.fill();
  for(let i=0;i<5;i++){g.strokeStyle='#3ad88a';g.lineWidth=5;g.beginPath();g.moveTo(x+20+i*10,y+196);g.quadraticCurveTo(x+10+i*14,y+120-i*8,x+28+i*8,y+40+i*12);g.stroke();pzEll(g,'#8affb4',x+28+i*8,y+40+i*12,7,4,.6,1.6)}
  for(let i=0;i<6;i++){g.fillStyle='rgba(220,255,240,.5)';g.beginPath();g.arc(x+18+((i*23)%44),y+30+i*28,2.5,0,TAU);g.fill()}
  g.strokeStyle=PZ_O;g.lineWidth=4;pzRR(g,x,y,78,200,30);g.stroke();g.strokeStyle='rgba(255,255,255,.4)';g.lineWidth=3;g.beginPath();g.moveTo(x+12,y+30);g.lineTo(x+12,y+150);g.stroke();
  g.fillStyle='#3a4470';pzRR(g,x-6,y+190,90,22,8);g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();pzRR(g,x-6,y-14,90,20,8);g.fill();g.stroke();pzGlow(g,x+39,y+100,110,'rgba(120,255,180,1)',.16)}
  /* bottom right: the VIP lounge sofa (back) and its sign */
 {g.fillStyle=pzLin(g,0,760,0,840,[[0,'#8a2a7a'],[1,'#4a1048']]);g.beginPath();g.moveTo(1080,840);g.quadraticCurveTo(1090,760,1180,756);g.lineTo(1560,756);g.quadraticCurveTo(1600,760,1600,800);g.lineTo(1600,840);g.closePath();g.fill();g.strokeStyle=PZ_O;g.lineWidth=4;g.stroke();
  g.strokeStyle='rgba(255,180,240,.35)';g.lineWidth=2;for(let x=1200;x<1600;x+=90){g.beginPath();g.moveTo(x,764);g.lineTo(x,836);g.stroke()}
  g.fillStyle='rgba(8,6,24,.85)';pzRR(g,1380,664,150,34,12);g.fill();g.strokeStyle='#ff6ad5';g.lineWidth=2.5;g.stroke();g.fillStyle='#ffd8f4';g.font='800 15px Poppins,sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillText('VIP LOUNGE',1455,682);pzGlow(g,1455,681,90,'rgba(255,106,213,1)',.16)}
 const v=g.createRadialGradient(760,470,380,760,470,1050);v.addColorStop(0,'rgba(0,0,0,0)');v.addColorStop(1,'rgba(4,2,16,.6)');g.fillStyle=v;g.fillRect(0,0,1600,900);
 return PZN_HUB.bg=c}
/* the table in perspective, stage box x 450-994, y 320-556 (2x canvas, like pz97Table) */
function pznHubTable(){const key=PZ_BS.set;if(PZN_HUB.tb&&PZN_HUB.tbKey===key)return PZN_HUB.tb;const F=PZN_FELT;
 const c=pzCv(1088,472),g=c.getContext('2d');g.scale(2,2);g.translate(-450,-320);g.lineJoin='round';g.lineCap='round';const cx=PZ97_TX,tr=(y0,y1,w0,w1)=>(u,v)=>[cx+(u-.5)*(w0+(w1-w0)*v),y0+(y1-y0)*v];
 const O=tr(338,482,414,462),C=tr(351,468,382,428),Fe=tr(355,463,370,414);
 const quad=(T,a0=0,a1=1,b0=0,b1=1)=>{g.beginPath();const p=[T(a0,b0),T(a1,b0),T(a1,b1),T(a0,b1)];g.moveTo(...p[0]);for(const q of p.slice(1))g.lineTo(...q);g.closePath()};
 /* hover pods and their light */
 for(const u of[.2,.8]){const [x,y]=O(u,1);pzGlow(g,x,y+44,60,'rgba(120,240,255,1)',.5);g.fillStyle=pzLin(g,x-24,0,x+24,0,[[0,'#20264a'],[.5,'#6a74a0'],[1,'#20264a']]);pzRR(g,x-24,y+20,48,16,8);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2.5;g.stroke();g.fillStyle='#7af8ff';pzRR(g,x-16,y+32,32,3,1.5);g.fill()}
 {const [ax0,ay]=O(0,1),[ax1]=O(1,1);g.fillStyle=pzLin(g,0,ay,0,ay+22,[[0,'#4a5480'],[.5,'#2a3058'],[1,'#141830']]);g.beginPath();g.moveTo(ax0,ay);g.lineTo(ax1,ay);g.lineTo(ax1-7,ay+22);g.lineTo(ax0+7,ay+22);g.closePath();g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();
  g.strokeStyle='#7af8ff';g.lineWidth=2;g.beginPath();g.moveTo(ax0+12,ay+15);g.lineTo(ax1-12,ay+15);g.stroke();g.strokeStyle='rgba(220,230,255,.3)';g.lineWidth=1.5;g.beginPath();g.moveTo(ax0+10,ay+4);g.lineTo(ax1-10,ay+4);g.stroke()}
 quad(O);g.fillStyle=pzLin(g,0,338,0,482,[[0,'#2a3058'],[.6,'#4a5480'],[1,'#6a74a0']]);g.fill();g.strokeStyle=PZ_O;g.lineWidth=3.4;g.stroke();
 g.strokeStyle='rgba(230,240,255,.5)';g.lineWidth=2;g.beginPath();g.moveTo(...O(.01,.985));g.lineTo(...O(.99,.985));g.stroke();
 quad(C,-.012,1.012,-.03,1.03);g.strokeStyle='rgba(122,248,255,.9)';g.lineWidth=1.6;g.stroke();
 for(const u of[.125,.25,.375,.625,.75,.875])for(const v of[-.045,1.045]){const [x,y]=C(u,v);pzGlow(g,x,y,5,'rgba(140,250,255,1)',.8);g.fillStyle='#e8ffff';g.beginPath();g.ellipse(x,y+(v>.5?2:0),1.8,1.2,0,0,TAU);g.fill()}
 quad(C);g.fillStyle=pzMix(F.c,'#000000',.25);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2;g.stroke();
 g.save();quad(Fe);g.clip();g.fillStyle=F.b;g.fillRect(450,320,560,240);g.translate(cx,404);g.scale(1,.42);const q=g.createRadialGradient(0,0,10,0,0,240);q.addColorStop(0,pzMix(F.a,'#ffffff',.22));q.addColorStop(.45,F.a);q.addColorStop(1,F.c);g.fillStyle=q;g.fillRect(-300,-300,600,600);g.restore();
 g.save();quad(Fe);g.clip();for(let i=0;i<500;i++){g.fillStyle=`rgba(255,255,255,${.02+pzNoise(i+4)*.03})`;g.fillRect(cx-210+pzNoise(i+19)*420,354+pzNoise(i+43)*110,1,1)}g.fillStyle='rgba(0,0,20,.22)';g.beginPath();g.moveTo(...Fe(0,0));g.lineTo(...Fe(1,0));g.lineTo(...Fe(1,.12));g.lineTo(...Fe(0,.12));g.fill();g.restore();
 quad(Fe);g.strokeStyle='rgba(0,0,0,.45)';g.lineWidth=1.5;g.stroke();
 for(const [u,v,r] of[[0,0,10],[.5,0,9],[1,0,10],[0,1,13],[.5,1,11.5],[1,1,13]]){const [x,y]=C(u,v),k=.55+.12*v;pzGlow(g,x,y,r+9,'rgba(255,106,213,1)',.5);g.fillStyle='#c8d0f0';g.beginPath();g.ellipse(x,y,r+3,(r+3)*k,0,0,TAU);g.fill();g.strokeStyle='#ff6ad5';g.lineWidth=1.6;g.beginPath();g.ellipse(x,y,r+1,(r+1)*k,0,0,TAU);g.stroke();g.fillStyle='#04020e';g.beginPath();g.ellipse(x,y,r,r*k,0,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2;g.stroke()}
 const balls=[[0,.25,.52]],cols=[[1],[9,2],[10,8,3],[11,7,14,4],[5,13,15,6,12]];cols.forEach((col,ci)=>col.forEach((n,ri)=>balls.push([n,.685+ci*.037,.5+(ri-(col.length-1)/2)*.095])));
 balls.sort((a,b)=>a[2]-b[2]);for(const [n,u,v] of balls){const [x,y]=Fe(u,v),d=15+v*2,im=pz97Ball(n,9);g.fillStyle='rgba(0,0,0,.35)';g.beginPath();g.ellipse(x+2,y+d*.42,d*.5,d*.2,0,0,TAU);g.fill();if(im)g.drawImage(im,x-d/2,y-d*.62,d,d)}
 PZN_HUB.tbKey=key;return PZN_HUB.tb=c}
function pznCone(){if(PZN_HUB.cone)return PZN_HUB.cone;const K=pzCv(320,300),k=K.getContext('2d');const q=k.createLinearGradient(0,0,0,300);q.addColorStop(0,'rgba(190,240,255,.3)');q.addColorStop(.75,'rgba(190,240,255,.08)');q.addColorStop(1,'rgba(190,240,255,0)');k.fillStyle=q;k.beginPath();k.moveTo(60,0);k.lineTo(260,0);k.lineTo(318,300);k.lineTo(2,300);k.closePath();k.fill();return PZN_HUB.cone=K}
/* the bar counter (with glowing bottles) and the lounge sofa front, baked for the live foreground */
function pznCounter(){if(PZN_HUB.ctr)return PZN_HUB.ctr;const c=pzCv(330,100),g=c.getContext('2d');g.lineJoin='round';
 for(let i=0;i<4;i++){const bx=22+i*30,bh=22+pzNoise(i+5)*16,bc=['#7af8ff','#ff6ad5','#ffc23a','#8affb4','#c8a0ff','#ff8a5a'][i];pzGlow(g,bx+7,52-bh/2,20,pzRgba(bc),.4);g.fillStyle=bc;pzRR(g,bx,52-bh,14,bh,4);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2;g.stroke();g.fillStyle='rgba(255,255,255,.55)';g.fillRect(bx+3,56-bh,3,bh-10)}
 g.fillStyle=pzLin(g,0,48,0,100,[[0,'#6a74a0'],[.25,'#2a3058'],[1,'#141830']]);g.beginPath();g.moveTo(8,50);g.lineTo(322,50);g.lineTo(314,100);g.lineTo(16,100);g.closePath();g.fill();g.strokeStyle=PZ_O;g.lineWidth=4;g.stroke();
 g.fillStyle='#7af8ff';g.fillRect(16,60,298,3);g.fillStyle='rgba(255,255,255,.3)';g.fillRect(12,52,306,2);return PZN_HUB.ctr=c}
function pznSofa(){if(PZN_HUB.sofa)return PZN_HUB.sofa;const c=pzCv(540,54),g=c.getContext('2d');g.lineJoin='round';
 g.fillStyle=pzLin(g,0,0,0,54,[[0,'#d04ab4'],[1,'#5a1050']]);g.beginPath();g.moveTo(10,54);g.quadraticCurveTo(14,4,80,2);g.lineTo(540,2);g.lineTo(540,54);g.closePath();g.fill();g.strokeStyle=PZ_O;g.lineWidth=4;g.stroke();
 g.strokeStyle='rgba(255,200,245,.4)';g.lineWidth=2;g.beginPath();g.moveTo(80,12);g.lineTo(540,12);g.stroke();for(let x=170;x<540;x+=130){g.fillStyle='#ffd8f4';g.beginPath();g.arc(x,32,4,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=1.5;g.stroke()}return PZN_HUB.sofa=c}
/* a medallion portrait on a starry holo backdrop */
function pznPort(id,lock){const key=id+(lock?'L':'');if(PZN_HUB.port[key])return PZN_HUB.port[key];const S=180,c=pzCv(S,S),g=c.getContext('2d'),R=PZ_REG[id];
 const q=g.createRadialGradient(S/2,S*.38,8,S/2,S*.5,S*.62);if(lock){q.addColorStop(0,'#1a2050');q.addColorStop(1,'#070a20')}else{q.addColorStop(0,pzMix(R.c,'#2a3a8a',.45));q.addColorStop(.62,pzMix(R.c,'#101a50',.72));q.addColorStop(1,'#080c28')}g.fillStyle=q;g.fillRect(0,0,S,S);
 pznStars(g,0,0,S,S,30,id.length*7);g.strokeStyle='rgba(122,248,255,.12)';g.lineWidth=1;for(let y=8;y<S;y+=12){g.beginPath();g.moveTo(0,y);g.lineTo(S,y);g.stroke()}
 const f=pzCv(S,S),fg=f.getContext('2d');pz97Bust(fg,id,S,Object.assign(pzCastEx(),PZ_EXP[lock?'neutral':id==='vantara'?'smug':'happy']),1.3);
 if(lock){const rim=pzCv(S,S),rg=rim.getContext('2d');rg.drawImage(f,0,0);rg.globalCompositeOperation='source-in';rg.fillStyle='#3a6ab8';rg.fillRect(0,0,S,S);fg.globalCompositeOperation='source-in';fg.fillStyle='#050818';fg.fillRect(0,0,S,S);fg.globalCompositeOperation='source-over';g.drawImage(rim,0,-2.5);g.drawImage(f,0,0);g.drawImage(pzIco('lock',84),S/2-42,S/2-34)}
 else g.drawImage(f,0,0);
 return PZN_HUB.port[key]=c}
/* a holo pedestal stage for the spotlight card and the results (W x H) */
function pznStage(col,W,H){const key=col+W+'x'+H;if(PZN_HUB.stage[key])return PZN_HUB.stage[key];const c=pzCv(W,H),g=c.getContext('2d');
 g.fillStyle=pzLin(g,0,0,0,H,[[0,'#0c1238'],[1,'#05071a']]);g.fillRect(0,0,W,H);pznStars(g,0,0,W,H*.7,Math.round(W*H/2600),W);
 g.strokeStyle='rgba(122,248,255,.08)';g.lineWidth=1;for(let y=10;y<H;y+=14){g.beginPath();g.moveTo(0,y);g.lineTo(W,y);g.stroke()}
 g.save();g.globalCompositeOperation='lighter';const cone=g.createLinearGradient(0,H-40,0,60);cone.addColorStop(0,pzRgba(col).replace(',1)',',.34)'));cone.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=cone;g.beginPath();g.moveTo(W*.18,H-34);g.lineTo(W*.82,H-34);g.lineTo(W,40);g.lineTo(0,40);g.closePath();g.fill();g.restore();
 const py=H-34;g.fillStyle='#1a2050';g.beginPath();g.ellipse(W/2,py+8,W*.44,16,0,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();g.fillStyle='#2a3468';g.beginPath();g.ellipse(W/2,py,W*.44,14,0,0,TAU);g.fill();g.stroke();
 g.strokeStyle=pzRgba(col).replace(',1)',',.9)');g.lineWidth=2.5;g.beginPath();g.ellipse(W/2,py,W*.38,10,0,0,TAU);g.stroke();pzGlow(g,W/2,py,W*.5,pzRgba(col),.35);
 g.fillStyle='#3a4470';pzRR(g,W/2-46,-10,92,26,10);g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();g.fillStyle='#bff8ff';g.beginPath();g.ellipse(W/2,15,32,5,0,0,TAU);g.fill();pzGlow(g,W/2,17,44,'rgba(190,245,255,1)',.5);
 return PZN_HUB.stage[key]=c}
/* ---------- the Orbit 8 hub ---------- */
function pznHub(){const Z=PZS();if(!pznVenueOpen(Z)){Z.venue='tavern';save();return pzHub()}
 const tokH=++PZ.tok;PZ.on=false;PZ.hub=true;CAS.on=true;CAS.key=null;CAS.tok++;pzCastInit(PZN_ORDER[0]);try{pzMusicOn()}catch(e){}
 const first=!Z.o8.seen;Z.venue='o8';Z.o8.seen=(Z.o8.seen||0)+1;save();
 if(PZ.sel&&!pznIs(PZ.sel))PZN.prevSel=PZ.sel;
 const pick=()=>PZN_ORDER.slice().reverse().find(k=>pznOpen(k)&&!(Z.beat[k]>0))||PZN_ORDER.filter(pznOpen).pop()||'bleep';
 if(!pznIs(PZ.sel)||!pznOpen(PZ.sel))PZ.sel=pick();
 try{pzbSetup(52,Z.balls)}catch(e){}
 const beatN=PZN_ORDER.filter(k=>(Z.beat[k]||0)>0).length,nextK=PZN_ORDER.find(k=>pznOpen(k)&&!(Z.beat[k]>0)),rm=pzRM();
 const med=(k,i)=>{const R=PZ_REG[k],[cx,cy,d]=PZN_SLOT[k],open=pznOpen(k),n=Z.beat[k]||0,lv=Z.live&&Z.live.opp===k,next=k===nextK,prev=i>0?PZ_REG[PZN_ORDER[i-1]]:null,boss=k==='vantara';
  const tag=lv?`<em class="pz97tag live"><i></i>LIVE ${Z.live.score[0]}-${Z.live.score[1]}</em>`:!open?`<em class="pz97tag stars">${'★'.repeat(i+3)}<u>${'★'.repeat(4-i)}</u></em>`:boss&&n?'<em class="pz97tag champ">♛ ORBIT CHAMPION</em>':next?'<em class="pz97tag nx">NEXT</em>':boss?'<em class="pz97tag boss">BOSS</em>':'';
  const tip=!open?`Beat ${prev.n} to open this table`:`${R.n}: ${R.k}${n?` · beaten ×${n}`:''}`;
  return `<button class="pzrow pz97md ${PZ.sel===k?'sel':''} ${open?'':'lock'} ${next?'next':''} ${n?'won':''} ${lv?'live':''} ${boss?'boss':''}" data-k="${k}" ${open?'':'disabled'} title="${tip.replace(/"/g,'&quot;')}" aria-label="${tip.replace(/"/g,'&quot;')}" style="left:${cx-300-d/2}px;top:${cy-116-d/2}px;--d:${d}px;--c:${R.c};--i:${i}">
   <span class="pz97in"><span class="pz97m"><i class="pz97halo"></i><canvas width="180" height="180" data-m="${k}"></canvas>${n?'<s class="pz97ck"></s>':''}</span><b class="pz97nm">${open?PZ97_PLATE[k]:'? ? ?'}</b>${tag}</span></button>`};
 const live=Z.live?`<div class="pzresume2 pz97res" id="pzresume"><canvas width="88" height="88" data-p="${Z.live.opp}"></canvas><div><b>Match in progress</b><span>vs ${PZ_REG[Z.live.opp].n} · ${Z.live.score[0]} - ${Z.live.score[1]}${Z.live.stake&&!Z.live.practice?` · stake ${cmn(Z.live.stake)}`:' · practice'}</span></div><button id="pzrs1">Resume</button><button id="pzrs2" class="ghost">Forfeit</button></div>`:'';
 const own=pzOwnCount(),W=Z.wins||0,L=Z.losses||0,tro=pzTrophies(),troN=tro.filter(a=>P.ach&&P.ach[a.id]).length,nets=Z.net||0;
 const nav=[['tavern','#ffb04a','The Crooked Cue','back to the tavern','O',''],['cues','#ffd45a','Cue Rack',`${own.n} / ${own.t} owned${own.nw?` · ${own.nw} new`:''}`,'C',own.nw?`<s class="pzbdg">${own.nw} NEW</s>`:''],
  ['regs','#ff9ab0','The Regulars',`${W}W · ${L}L · ${troN} / ${tro.length} trophies`,'R',''],['rules','#c8a0ff','How to Play','rules, controls, tutorials','H','']];
 show(`<div class="pzh pzh9 pzh97 pzn8 pzin${rm?' rm':''}" id="pzh"><canvas id="pzhbg" width="1600" height="900"></canvas><canvas class="pzn8amb" width="1600" height="340"></canvas>
  <div class="pzboard pz97tab" id="pz97tab"><div class="pzn8halo"><canvas class="pzn8cone" width="320" height="300"></canvas><canvas class="pzn8ring" width="340" height="120"></canvas></div><canvas class="pz97tbc" width="1088" height="472"></canvas>${PZN_ORDER.every(k=>(Z.beat[k]||0)>0)?'<div class="pz97champ pzn8ch">♛ Ruler of Orbit 8</div>':''}${PZN_ORDER.map(med).join('')}</div>
  <canvas id="pzhfg" width="1600" height="900"></canvas>
  <button class="pzback" id="pzbk">‹&nbsp; Crooked Cue <kbd>Esc</kbd></button>
  <div class="pzgold"><i></i><b id="pzgold">${cmn(P.gold)}</b></div>
  <div class="pznet">Pool net <b class="${nets<0?'neg':''}">${nets<0?'−':'+'}${cmn(Math.abs(nets))}</b>${(Z.streak||0)>1?` · streak <b class="hot">${Z.streak}</b>`:''}</div>
  <div class="pztitle pzn8sign"><canvas class="pzn8emb" width="96" height="96"></canvas><span data-t="Orbit 8">Orbit 8</span></div><div class="pzprog pzn8prog"><b>${beatN}</b> of 5 beaten in orbit · <b>${Z.dayN}</b> / ${PZ_DAILY} paid matches today</div>
  <nav class="pznav">${nav.map(([a,c,t,s,k,x],i)=>`<button data-a="${a}" style="--c:${c};--i:${i}"><span class="pzni"><canvas width="72" height="72" data-ico="${a==='regs'?'trophy':a}"></canvas></span><span class="pznt"><b>${t}</b><span>${s}</span></span><i class="pz97chev"></i><kbd>${k}</kbd>${x}</button>`).join('')}</nav>
  <div class="pzopp pzopp9 pz97opp" id="pzopp"></div>
  <div class="pz97bar" id="pz97bar"><div class="pz97lab">Choose your stake:</div><div class="pz97chips" id="pz97chips"></div><i class="pz97sep"></i>
   <div class="pz97num"><small>Total return</small><b id="pz97ret">0</b><em id="pz97mx"></em></div><i class="pz97sep"></i><div class="pz97num g"><small>Net profit</small><b id="pz97net">0</b><em id="pz97nx"></em></div>
   <button class="pzrackem pz97play" id="pzrackem"><span class="pz97pt" id="pz97pt"><span id="pz97p1">Play</span><i>•</i><span id="pz97p2"></span></span><kbd>Enter</kbd><i class="pzshine"></i></button>
   <button class="pzprac pz97prac" id="pzprac"><b>Practice</b><span id="pzpracs">free</span><kbd>P</kbd></button></div>${live}</div>`,'casbg pzx');
 const root=$('pzh');
 $('pzhbg').getContext('2d').drawImage(pznHubBg(),0,0);
 root.querySelector('.pzn8ring').getContext('2d').drawImage(pznHaloBake(),0,0);root.querySelector('.pzn8cone').getContext('2d').drawImage(pznCone(),0,0);
 root.querySelector('.pz97tbc').getContext('2d').drawImage(pznHubTable(),0,0);
 root.querySelector('.pzn8emb').getContext('2d').drawImage(pznIco('planet',96),0,0);
 root.querySelectorAll('canvas[data-m]').forEach(cv=>{cv.getContext('2d').drawImage(pznPort(cv.dataset.m,cv.closest('.lock')),0,0)});
 root.querySelectorAll('canvas[data-ico]').forEach(cv=>{const k=cv.dataset.ico;cv.getContext('2d').drawImage(k==='tavern'?pznIco('mug',72):pzIco(k,72),0,0)});
 {const cv=root.querySelector('.pzresume2 canvas');if(cv)pzCastPortrait(cv.getContext('2d'),'mon',cv.dataset.p,88,1,Object.assign(pzCastEx(),PZ_EXP.neutral))}
 /* the window: twinkles, a passing shuttle, a comet */
 {const cv=root.querySelector('.pzn8amb'),g=cv.getContext('2d');const tw=[[470,150],[700,140],[760,300],[930,160],[1010,300],[640,200],[820,180],[520,320]];
  const f=()=>{if(PZ.tok!==tokH||!cv.isConnected)return;const t=performance.now()/1000;g.clearRect(300,118,760,222);if(pzRM())return;
   tw.forEach(([x,y],i)=>{const a=Math.max(0,Math.sin(t*1.4+i*2.3));if(a<.25)return;g.globalAlpha=a;g.drawImage(pzGlowS('rgba(220,235,255,1)'),x-8,y-8,16,16);g.fillStyle='#fff';g.fillRect(x-1,y-1,2,2)});g.globalAlpha=1;
   {const ph=(t%18)/6;if(ph<1){const x=1040-ph*640,y=170+ph*40;g.save();g.translate(x,y);g.rotate(.06);g.fillStyle='#c8d0f0';g.strokeStyle=PZ_O;g.lineWidth=2;g.beginPath();g.moveTo(-16,0);g.lineTo(10,-6);g.lineTo(16,0);g.lineTo(10,6);g.closePath();g.fill();g.stroke();pzGlow(g,18,0,14,'rgba(255,180,90,1)',.9);g.restore()}}
   {const ph=(t%13)/1.2;if(ph<1){const x=900-ph*300,y=130+ph*90;g.strokeStyle=`rgba(255,255,255,${(1-ph)*.8})`;g.lineWidth=2;g.beginPath();g.moveTo(x,y);g.lineTo(x+50,y-15);g.stroke()}}};
  f();LIVE.push({cv,fn:f,slow:2,ph:1})}
 /* the foreground: Bleep at his hover bar, the VIP lounge */
 const fg=$('pzhfg').getContext('2d');fg.lineJoin='round';fg.lineCap='round';
 let lounge=[];const loungeFill=()=>{const sel=PZ.sel,met=PZN_ORDER.filter(k=>k!=='bleep'&&k!==sel&&pznOpen(k)).sort((a,b)=>(Z.beat[b]||0)-(Z.beat[a]||0)).slice(0,3),now=performance.now()/1000;
  lounge=[1230,1360,1490].map((x,i)=>{const id=met[i];if(!id)return null;const old=lounge.find(o=>o&&o.i===i);if(old&&old.id===id)return old;const b=pzMonBox(id),s=Math.min(150/(b.x1-b.x0),190/(b.y1-b.y0));return {i,id,x:x-(b.x0+b.x1)/2*s,y:772-b.y0*s,s,ex:Object.assign(pzCastEx(),PZ_EXP[['happy','smug','happy'][i]]),ph:i*2.1,t0:old?now:0}}).filter(Boolean)};
 loungeFill();PZN.loungeFill=loungeFill;PZ97.barFill=null;
 const bb=pzMonBox('bleep'),bS=.64,bEx=Object.assign(pzCastEx(),PZ_EXP.happy);
 const drawFg=()=>{if(PZ.tok!==tokH)return;const t=performance.now()/1000;fg.clearRect(1060,600,540,300);fg.clearRect(0,600,450,300);
  for(const s of lounge){const u=s.t0?Math.min(1,(t-s.t0)/.5):1,rise=u<1?(1-u)*(1-u)*90:0;fg.save();fg.translate(s.x,s.y+rise);fg.scale(s.s,s.s);pzMon[s.id](fg,t+s.ph,s.ex,{breath:Math.sin(t*2.2+s.ph)*.012,tilt:Math.sin(t*.9+s.ph)*.02,bob:0,hop:0});fg.restore()}
  fg.drawImage(pznSofa(),1060,846);
  if(!lounge.length){fg.fillStyle='rgba(255,216,244,.85)';fg.font='700 14px Poppins,sans-serif';fg.textAlign='center';fg.fillText('Players you meet relax here',1360,800)}
  if(PZ.sel!=='bleep'){fg.save();fg.translate(318-(bb.x0+bb.x1)/2*bS,762-bb.y0*bS);fg.scale(bS,bS);pzMon.bleep(fg,t+1,bEx,{breath:Math.sin(t*2)*.012,tilt:Math.sin(t*.7)*.02,bob:0,hop:0});fg.restore()}
  else{fg.fillStyle='rgba(8,6,24,.85)';pzRR(fg,242,790,152,36,12);fg.fill();fg.strokeStyle='#7af8ff';fg.lineWidth=2.5;fg.stroke();fg.fillStyle='#bff8ff';fg.font='800 14px Poppins,sans-serif';fg.textAlign='center';fg.fillText('BACK IN 5 MIN',318,813)}
  fg.drawImage(pznCounter(),110,812);const gl=.6+.4*Math.sin(t*3);pzGlow(fg,272,856,120,'rgba(120,240,255,1)',.16*gl)};
 LIVE.push({cv:$('pzhfg'),fn:drawFg,slow:2,ph:0});drawFg();
 PZ.oppSwap=0;PZ.payShown=null;PZ.oppFace=null;pzHubOpp();
 root.querySelectorAll('.pz97md').forEach(b=>b.onclick=()=>{if(b.disabled)return;pzHubSel(b.dataset.k);try{if(PZN.loungeFill)PZN.loungeFill()}catch(e){}});
 const toTavern=()=>{pzFx('tick');Z.venue='tavern';save();PZ.sel=PZN.prevSel&&!pznIs(PZN.prevSel)?PZN.prevSel:null;pzGo(pzHub)};
 const go=a=>{pzFx('tick');if(a==='practice'){pzMusicOff();pzStart({opp:PZ.sel,practice:true})}else if(a==='tavern')toTavern();else if(a==='cues')pzGo(pzCueRack);else if(a==='rules')pzGo(pzRules);else if(a==='regs')pzGo(pzRegs)};
 root.querySelectorAll('.pznav button').forEach(b=>b.onclick=()=>go(b.dataset.a));$('pzprac').onclick=()=>go('practice');
 $('pzbk').onclick=toTavern;S.back=()=>$('pzbk').click();
 $('pzrackem').onclick=()=>{if(Z.live){$('pzrs1').click();return}const sel=PZ.sel,R=PZ_REG[sel],lo=Math.min(...R.stakes.filter(s=>s<=casCap('pz')));if(P.gold<lo){pzMusicOff();pzNote('Not enough gold for stakes, so this one is a free practice game.');pzStart({opp:sel,practice:true});return}pzMusicOff();pzStart({opp:sel,stake:pzStakeOf(sel)})};
 if(Z.live){$('pzrs1').onclick=()=>{pzStart({opp:Z.live.opp,resume:Z.live,race:Z.live.race})};$('pzrs2').onclick=function(){if(!this.dataset.sure){this.dataset.sure=1;const t=this.textContent;this.textContent=Z.live&&Z.live.stake&&!Z.live.practice?'Sure? You lose the stake':'Sure? Drop this match';setTimeout(()=>{if(this.isConnected){delete this.dataset.sure;this.textContent=t}},3200);return}const Lv=Z.live;Z.live=null;if(Lv.stake&&!Lv.practice){Z.losses++;Z.streak=0;ecSrc('pool',()=>cPay(Lv.stake,0));Z.net-=Lv.stake;const v=pzVs();v[Lv.opp]=v[Lv.opp]||[0,0];v[Lv.opp][1]++}save();
   const el=$('pzresume');el.classList.add('out');const lm=root.querySelector('.pz97md.live');if(lm){lm.classList.remove('live');const tg=lm.querySelector('.pz97tag.live');if(tg)tg.remove()}setTimeout(()=>{el.remove();pzHubOpp()},260)}}
 setTimeout(()=>{const h=$('pzh');if(h&&PZ.tok===tokH)h.classList.remove('pzin')},1500);
 pzFitTM();
 /* a short welcome the first time */
 if(!Z.tut.o8&&!Z.live){setTimeout(()=>{if(PZ.tok!==tokH||!$('pzh')||pzCoachActive())return;try{pzCoach('o8',[
  {title:'Welcome to Orbit 8!',text:'A zero-g lounge high above the gas giant. Five new players, a new table, and bigger pots. Beat each one to open the next seat.',w:420},
  {sel:()=>({x:340,y:150,w:704,h:500}),side:'right',pad:0,title:'Climb the orbit',text:'Start with <b>Bleep</b> at the bottom left and go round clockwise. <b>Empress Vantara</b> waits in the champion\'s seat.',w:330},
  {sel:'#pzbk',side:'bottom',title:'Back to the tavern',text:'The <b>Crooked Cue</b> button (or <kbd>O</kbd>) takes you back down. The game remembers where you were.',w:330}],{kicker:'ORBIT 8',last:"Let's play"})}catch(e){}},700)}}
/* the spotlight card in Orbit 8: a holo pedestal, and what a first win pays instead of a cue */
{const f0=pzHubOpp;pzHubOpp=function(){const r=f0.apply(this,arguments);try{const h=$('pzh');if(h&&h.classList.contains('pzn8')&&pznIs(PZ.sel)){const id=PZ.sel,R=PZ_REG[id],Z=PZS(),el=$('pzopp');
  const st=el.querySelector('.pzstbg');if(st)st.getContext('2d').drawImage(pznStage(R.c,214,496),0,0);
  const inf=el.querySelector('.pzoppi');if(inf&&!inf.querySelector('.pzn8rew')){const fb=!(Z.beat[id]>0)&&!((Z.first||{})[id]),boss=id==='vantara',d=document.createElement('div');d.className='pzrew pzn8rew'+(fb?'':' have');
   d.innerHTML=`<canvas width="44" height="44"></canvas><div><b>${fb?`First win: +${cmn(100*(R.lvl||1))} gold`:boss?'Ruler of Orbit 8':`Beaten ×${Z.beat[id]||0}`}</b><span>${fb?'a one-time bonus':boss?'keep the crown':'they are wise to you'}</span></div>`;inf.appendChild(d);d.querySelector('canvas').getContext('2d').drawImage(pznIco('planet',44),0,0)}}}catch(e){console.error(e)}return r}}
/* ---------- the way in from the tavern ---------- */
function pznTicket(){const h=$('pzh');if(!h||h.classList.contains('pzn8')||h.querySelector('#pzn8tk'))return;const Z=PZS(),open=pznVenueOpen(Z),nw=open&&!Z.o8.seen;
 const b=document.createElement('button');b.id='pzn8tk';b.className='pzn8tk'+(open?'':' lock')+(nw?' new':'');b.setAttribute('aria-label',open?'Go to Orbit 8, a new venue':'Orbit 8: beat Grizzle to get a shuttle pass');
 b.innerHTML=`<canvas width="56" height="56"></canvas><span><b>Orbit 8</b><small>${open?(nw?'new venue · fly up':'zero-g lounge'):'beat Grizzle to fly'}</small></span>${open?'<kbd>O</kbd>':'<i class="pzn8lk"></i>'}${nw?'<s class="pzbdg">NEW</s>':''}`;
 h.appendChild(b);b.querySelector('canvas').getContext('2d').drawImage(pznIco('planet',56),0,0);
 b.onclick=()=>{if(!pznVenueOpen()){pzFx('no');b.classList.remove('shake');void b.offsetWidth;b.classList.add('shake');pzNote('Beat Grizzle at the Crooked Cue to earn a shuttle pass to Orbit 8.');return}pzFx('tick');const Z2=PZS();Z2.venue='o8';save();pzGo(pzHub)}}
{const f0=pzHub;pzHub=function(){const Z=PZS();if(Z.venue==='o8'&&pznVenueOpen(Z))return pznHub();if(pznIs(PZ.sel))PZ.sel=PZN.prevSel&&!pznIs(PZN.prevSel)?PZN.prevSel:null;const r=f0.apply(this,arguments);try{pznTicket()}catch(e){console.error(e)}return r}}
/* playing an Orbit 8 player puts you in Orbit 8 when you come back (and a tavern player in the tavern) */
{const f0=pzStart;pzStart=function(o){const r=f0.apply(this,arguments);try{if(r&&o&&o.opp){const Z=PZS(),v=pznIs(o.opp)?'o8':'tavern';if(Z.venue!==v){Z.venue=v;save()}}}catch(e){}return r}}
/* O switches venue from either hub */
if(!window.__pznKeys){window.__pznKeys=1;addEventListener('keydown',e=>{try{if(e.repeat||!$('pzh')||PZ.modal||pzCoachActive()||PZ.on)return;if(document.activeElement&&/INPUT|TEXTAREA/.test(document.activeElement.tagName))return;if(e.ctrlKey||e.metaKey||e.altKey)return;
 const h=$('pzh'),inO=h.classList.contains('pzn8');if(e.key==='o'||e.key==='O'){const b=inO?$('pzbk'):$('pzn8tk');if(b){e.preventDefault();b.click()}return}
 if(inO&&/^[1-5]$/.test(e.key)){const b=ov.querySelector(`.pzrow[data-k="${PZN_ORDER[+e.key-1]}"]`);e.preventDefault();e.stopImmediatePropagation();if(b&&!b.disabled)b.click()}}catch(err){}},true)}
/* ---------- results, The Regulars ---------- */
{const f0=pzMatchEnd;pzMatchEnd=function(){try{PZN.open0=PZN_ORDER.filter(k=>pznOpen(k));PZN.vopen0=pznVenueOpen()}catch(e){}return f0.apply(this,arguments)}}
{const f0=pzResults;pzResults=function(res){let fresh=false;try{if(res&&pznIs(res.opp)&&!res.practice&&PZN.open0){res.opened=PZN_ORDER.find(k=>pznOpen(k)&&!PZN.open0.includes(k))||null}fresh=!!(PZN.open0&&!PZN.vopen0&&pznVenueOpen());PZN.open0=null}catch(e){}
 const r=f0.apply(this,arguments);try{pznResultsFix(res,fresh)}catch(e){console.error(e)}return r}}
function pznResultsFix(res,fresh){const root=ov.querySelector('.pzres9');if(!root)return;const Z=PZS();
 if(fresh){const u=root.querySelector('.pzuns');if(u)u.insertAdjacentHTML('afterbegin','<div class="pzun open pzn8un"><small>NEW VENUE</small><b>Orbit 8</b></div>');const gl=root.querySelector('.pzgoal');if(gl)gl.textContent='Next: a shuttle pass to Orbit 8 is waiting at the bar (top right).'}
 if(!pznIs(res.opp))return;const R=PZ_REG[res.opp],win=res.win;root.classList.add('pzn8r');
 {const bg=$('pzrbg');if(bg)bg.getContext('2d').drawImage(pznHubBg(),0,0)}
 {const st=root.querySelector('.pzrstage .pzstbg');if(st){const g=st.getContext('2d');g.clearRect(0,0,300,424);g.drawImage(pznStage(win?'#6a7aaa':R.c,300,424),0,0)}}
 const gl=root.querySelector('.pzgoal');if(gl&&!res.practice&&res.opened)gl.textContent=`Next: ${PZ_REG[res.opened].n} is waiting in the lounge.`;else if(gl&&!res.practice){const nx=PZN_ORDER.find(k=>pznOpen(k)&&!(Z.beat[k]>0));gl.textContent=nx?`Next: ${PZ_REG[nx].n} is still unbeaten in Orbit 8.`:'You rule Orbit 8. Come back and defend the crown.'}
 const bb=$('pzbb');if(bb)bb.innerHTML='The lounge <kbd>Esc</kbd>'}
{const f0=pzRegs;pzRegs=function(){const r=f0.apply(this,arguments);try{pznRegsTabs()}catch(e){console.error(e)}return r}}
function pznRegsTabs(){const Z=PZS(),grid=ov.querySelector('.pzrggrid');if(!grid||!pznVenueOpen(Z))return;const k0=grid.innerHTML,root=$('pzk');
 const tabs=document.createElement('div');tabs.className='pzn8tabs';tabs.innerHTML='<button data-v="tavern">The Crooked Cue</button><button data-v="o8">Orbit 8</button>';root.appendChild(tabs);
 const v=pzVs();const card=(k,i)=>{const R=PZ_REG[k],open=pznOpen(k),n=Z.beat[k]||0,r=v[k]||[0,0],prev=i?PZ_REG[PZN_ORDER[i-1]]:null,fb=!n&&!((Z.first||{})[k]);
  return `<button class="pzrg pzn8rg ${open?'':'lock'} ${n?'won':''}" data-k="${k}" style="--c:${R.c};--i:${i}" ${open?'':'disabled'}><canvas width="176" height="176" data-p="${k}"></canvas>
   <b>${open?R.n:'? ? ?'}</b><small>${open?R.k:`Beat ${prev?prev.n:'Grizzle'} to meet them`}</small>
   ${open?`<div class="pzrgr"><span><b>${r[0]}</b>W</span><span><b>${r[1]}</b>L</span><span><b>${n}</b>beaten</span></div>
   <div class="pzrgc"><span>Race to ${R.race} · pays ×${R.mult}</span><i>${'<u class="on"></u>'.repeat(Math.min(3,n))}${'<u></u>'.repeat(3-Math.min(3,n))}</i></div>
   <div class="pzrgf ${fb?'':'on'}">${fb?`first win +${cmn(100*(R.lvl||1))} gold`:k==='vantara'?'Ruler of Orbit 8':'beaten'}</div>`:''}</button>`};
 const show9=vn=>{tabs.querySelectorAll('button').forEach(b=>b.classList.toggle('on',b.dataset.v===vn));root.classList.toggle('pzn8k',vn==='o8');
  if(vn==='o8'){grid.innerHTML=PZN_ORDER.map(card).join('');grid.querySelectorAll('canvas[data-p]').forEach(cv=>{const k=cv.dataset.p,g=cv.getContext('2d'),lock=cv.closest('.lock');pzCastPortrait(g,'mon',k,176,1.3,Object.assign(pzCastEx(),PZ_EXP.happy));if(lock){g.globalCompositeOperation='source-in';g.fillStyle='#0c0818';g.fillRect(0,0,176,176);g.globalCompositeOperation='source-over'}});
   grid.querySelectorAll('.pzrg').forEach(b=>b.onclick=()=>{if(b.disabled)return;PZ.sel=b.dataset.k;const Z2=PZS();Z2.venue='o8';save();pzFx('tick');pzGo(pzHub)});const bg=$('pzkbg');if(bg)bg.getContext('2d').drawImage(pznHubBg(),0,0)}
  else{grid.innerHTML=k0;grid.querySelectorAll('canvas[data-p]').forEach(cv=>{const k=cv.dataset.p,g=cv.getContext('2d'),lock=cv.closest('.lock');pzCastPortrait(g,'mon',k,176,1.3,Object.assign(pzCastEx(),PZ_EXP.happy));if(lock){g.globalCompositeOperation='source-in';g.fillStyle='#0c0818';g.fillRect(0,0,176,176);g.globalCompositeOperation='source-over'}});
   grid.querySelectorAll('.pzrg').forEach(b=>b.onclick=()=>{if(b.disabled)return;const k=b.dataset.k;if(k==='shade'&&!PZ.shadeHere){pzNote('Slick Shade only turns up when he feels like it. Keep an eye on the bar.');return}PZ.sel=k;const Z2=PZS();Z2.venue='tavern';save();pzFx('tick');pzGo(pzHub)});const bg=$('pzkbg');if(bg)bg.getContext('2d').drawImage(pzHubBake(),0,0)}};
 tabs.querySelectorAll('button').forEach(b=>b.onclick=()=>{pzFx('tick');show9(b.dataset.v)});show9(Z.venue==='o8'?'o8':'tavern');
 const bk=$('pzbk');if(bk&&Z.venue==='o8')bk.innerHTML='‹&nbsp; Orbit 8'}
{const st=document.createElement('style');st.textContent=`
.pzn8 .pzn8amb{position:absolute;left:0;top:0;width:1600px;height:340px;pointer-events:none}
.pzn8 .pzn8sign{top:6px;display:flex;align-items:center;justify-content:center;gap:12px;font-size:72px;text-shadow:none}
.pzn8 .pzn8sign span{position:relative;background:linear-gradient(180deg,#ffffff 10%,#9ef0ff 55%,#8a9aff);-webkit-background-clip:text;background-clip:text;color:transparent;text-shadow:none}
.pzn8 .pzn8sign span::before{content:attr(data-t);position:absolute;left:0;top:0;z-index:-1;color:#12081f;-webkit-text-stroke:9px #12081f;text-shadow:0 5px 0 #12081f}
.pzn8 .pzn8emb{width:78px;height:78px;animation:pzn8spin 9s linear infinite}
@keyframes pzn8spin{0%,100%{transform:rotate(-6deg)}50%{transform:rotate(6deg)}}
.pzn8 .pzn8prog{border-color:#3a6ac8}.pzn8 .pzn8prog b{color:#9ef8ff}
.pzn8 .pzn8halo{position:absolute;left:292px;top:6px;width:260px;height:340px;animation:pzn8bob 4.2s ease-in-out infinite;pointer-events:none}
.pzn8 .pzn8halo canvas{position:absolute}.pzn8 .pzn8ring{left:0;top:0;width:260px;height:92px}.pzn8 .pzn8cone{left:-30px;top:58px;width:320px;height:300px;animation:pz97glow 3.4s ease-in-out infinite}
@keyframes pzn8bob{0%,100%{transform:translateY(0)}50%{transform:translateY(-7px)}}
.pzh97.pzn8.pzin .pzn8halo{animation:pzn8haloIn 1s .05s cubic-bezier(.25,1.3,.45,1) both,pzn8bob 4.2s ease-in-out 1.1s infinite}
@keyframes pzn8haloIn{from{opacity:0;transform:translateY(-120px) scale(.6)}to{opacity:1;transform:none}}
.pzh97.pzn8 .pz97m{background:linear-gradient(#081030,#081030) padding-box,linear-gradient(160deg,#b8faff,#4a7ae8 55%,#2a2a8a) border-box}
.pzh97.pzn8 .pz97md.lock .pz97m{background:linear-gradient(#060a1e,#060a1e) padding-box,linear-gradient(160deg,#2a3a70,#141c44) border-box}
.pzh97.pzn8 .pz97md.next .pz97m{background:linear-gradient(#081030,#081030) padding-box,linear-gradient(160deg,#fff2a8,#ffd45a 40%,#c88a1a) border-box}
.pzh97.pzn8 .pz97md.boss:not(.lock):not(.next) .pz97m{background:linear-gradient(#0a0620,#0a0620) padding-box,conic-gradient(from 0deg,#d8b8ff,#7a3aff,#ff9ad8,#ffe0a0,#d8b8ff) border-box}
.pzh97.pzn8 .pz97nm{background:linear-gradient(180deg,#16285a,#0a0c28);border-color:#3a7ac8}
.pzh97.pzn8 .pz97md.lock .pz97nm{border-color:#1e2a60}
.pzh97 .pz97tag.boss{background:linear-gradient(180deg,#d8b8ff,#8a5ae8);color:#12081f;box-shadow:0 4px 0 #0007}
.pzn8 .pzn8ch{background:linear-gradient(180deg,#e8d8ff,#a87af0)}
.pzh97.pzn8 .pz97opp{border-color:#3a8ae8}.pzh97.pzn8 .pz97bar{border-color:#3a6ac8;background:linear-gradient(180deg,#14205a,#080c30)}
.pzh97.pzn8 .pznav button{background:linear-gradient(180deg,#16205a,#080c30);border-color:#2e4a9a}
.pzh97.pzn8 .pzni{background:radial-gradient(circle at 50% 40%,#2a4a9a,#0a1038 72%)}
.pzh97 .pzrew.pzn8rew{gap:12px;padding:8px 12px}.pzh97 .pzn8rew canvas{width:40px;height:40px;flex:none}.pzh97 .pzn8rew div{text-align:left}.pzh97 .pzn8rew b{font-size:14px}.pzh97 .pzn8rew span{font-size:12px}
.pzn8tk{position:absolute;left:1064px;top:20px;width:274px;height:52px;box-sizing:border-box;padding:0 14px 0 6px;display:flex;align-items:center;gap:8px;border-radius:16px;background:linear-gradient(180deg,#1a2a6a,#0a1038);border:3px solid #5ac8ff;color:#e8f8ff;cursor:pointer;z-index:5;box-shadow:0 0 0 3px #12081f,0 8px 18px #0009;transition:transform .25s cubic-bezier(.3,1.6,.5,1);animation:pzfade .5s .3s both}
.pzn8tk canvas{width:46px;height:46px;flex:none}.pzn8tk span{display:flex;flex-direction:column;text-align:left;line-height:1.05;min-width:0}.pzn8tk b{font:400 24px/1 "Pirata One",serif;color:#bff8ff}.pzn8tk small{font:700 11.5px Poppins,sans-serif;color:#9ab8e8;white-space:nowrap}
.pzn8tk kbd{position:absolute;right:8px;top:6px;font-size:9.5px;opacity:.7}.pzn8tk:hover{transform:translateY(-3px) scale(1.02)}.pzn8tk:active{transform:scale(.97)}
.pzn8tk.new{border-color:#ffd45a}.pzn8tk.new canvas{animation:pzn8spin 2.4s ease-in-out infinite}.pzn8tk .pzbdg{top:-12px;right:6px}
.pzn8tk.lock{border-color:#3a3a6a;background:linear-gradient(180deg,#141838,#080a20);cursor:default}.pzn8tk.lock canvas{opacity:.35}.pzn8tk.lock b{color:#8a8aaa}
.pzn8lk{position:absolute;right:12px;top:15px;width:14px;height:11px;border-radius:3px;background:#8a8aaa;border:2px solid #12081f}.pzn8lk::before{content:'';position:absolute;left:1px;top:-9px;width:8px;height:8px;border:2.5px solid #8a8aaa;border-bottom:0;border-radius:6px 6px 0 0}
.pzn8tk.shake{animation:pzn8shake .4s}@keyframes pzn8shake{0%,100%{transform:none}25%{transform:translateX(-6px)}75%{transform:translateX(6px)}}
.pzn8tabs{position:absolute;left:200px;top:22px;display:flex;gap:6px;padding:5px;border-radius:16px;background:#100a30e8;border:2px solid #4a3e90;z-index:4}
.pzn8tabs button{height:32px;padding:0 18px;border-radius:12px;border:0;background:transparent;color:#c4badf;font:800 14px Poppins,sans-serif;cursor:pointer;box-shadow:none;transition:transform .2s cubic-bezier(.3,1.5,.5,1)}.pzn8tabs button:hover{transform:translateY(-2px)}
.pzn8tabs button.on{background:linear-gradient(180deg,#ffe27a,#f2b631);color:#2a1a04;box-shadow:0 3px 0 #9a6a10}.pzn8k .pzn8tabs button.on[data-v=o8]{background:linear-gradient(180deg,#bff8ff,#5ac8ff);color:#06122a;box-shadow:0 3px 0 #1a5a9a}
.pzn8k .pzn8rg canvas{background:radial-gradient(circle at 50% 42%,#2a4a9a,#08103a 70%)}
.pzn8r .pzun.pzn8un,.pzun.pzn8un{border-color:#5ac8ff}
`;document.head.appendChild(st)}
