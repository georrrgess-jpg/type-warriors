
/* ===== DOCK ICONS v2: a redrawn, evenly weighted set, with animations that always finish cleanly =====
   Every moving part is its own group with an explicit pivot in icon units (transform-box:view-box), and a
   whole animation plays once per hover/press/activation through a class that JS removes when it ends. */
{const sw=(tx,ty,tipX,tipY,bx,by)=>{/* one sword: tip -> guard point, then grip and pommel beyond it */
  const dx=bx-tipX,dy=by-tipY,L=Math.hypot(dx,dy),ux=dx/L,uy=dy/L,nx=-uy,ny=ux,hw=5.2,sx=tipX+ux*9,sy=tipY+uy*9,f=v=>v.toFixed(1);
  const blade=`M${f(tipX)} ${f(tipY)}L${f(sx+nx*hw)} ${f(sy+ny*hw)}L${f(bx+nx*hw)} ${f(by+ny*hw)}L${f(bx-nx*hw)} ${f(by-ny*hw)}L${f(sx-nx*hw)} ${f(sy-ny*hw)}Z`;
  const half=`M${f(tipX)} ${f(tipY)}L${f(sx-nx*hw)} ${f(sy-ny*hw)}L${f(bx-nx*hw)} ${f(by-ny*hw)}L${f(bx)} ${f(by)}L${f(sx)} ${f(sy)}Z`;
  const gx=bx+ux*15,gy=by+uy*15,px=bx+ux*20,py=by+uy*20;
  return bP(blade,'#e6edf8',2.6)+bF(half,'#8a9ab8',.45)+bH(`M${f(sx+nx*2.4)} ${f(sy+ny*2.4)}L${f(bx+nx*2.4-ux*4)} ${f(by+ny*2.4-uy*4)}`,'#ffffffd0',1.6)
   +bL(bx+ux*2,by+uy*2,gx,gy,'#8a5226',6.4)+bL(bx+nx*10,by+ny*10,bx-nx*10,by-ny*10,'#ffcc3a',6)+bC(px,py,5.6,'#ffcc3a',2.4)+bC(px-1.6,py-1.6,1.6,'#fff6c0',0)};
 Object.assign(DKI,{
 pl:`<g class="k-b">${sw(0,0,82,14,38,58)}</g><g class="k-a">${sw(0,0,18,14,62,58)}</g><g class="k-fx">${bS(50,38,11,'#fff6c0')}</g>`,
 gr:`<g class="k-all"><g class="k-plume">${bP('M52 19C48 4 28 0 14 10C12 14 14 20 18 24C22 16 32 14 42 24Z','#b47aff',2.6)}${bF('M18 24C22 16 32 14 42 24L36 22C30 19 24 20 18 24Z','#5a2a9a',.5)}${bH('M20 11C28 6 38 7 45 13','#e8d8ff',2.2)}</g>
  ${bP('M24 52C24 30 36 18 50 18C64 18 76 30 76 52V78C76 83 72 86 67 86H33C28 86 24 83 24 78Z','#cfd8e6')}${bF('M50 18C64 18 76 30 76 52V78C76 83 72 86 67 86H50Z','#2a3450',.22)}
  ${bP('M47 18H53V45H47Z','#ffcc3a',2.2)}${bP('M31 45H69C70 45 71 46 71 47V52C71 53 70 54 69 54H31C30 54 29 53 29 52V47C29 46 30 45 31 45Z','#1a1030',2)}${bP('M46.5 54H53.5V73C53.5 75 52 76 50 76C48 76 46.5 75 46.5 73Z','#1a1030',2)}
  ${bC(36,64,2.4,'#1a1030',0)}${bC(36,72,2.4,'#1a1030',0)}${bC(64,64,2.4,'#1a1030',0)}${bC(64,72,2.4,'#1a1030',0)}${bL(30,82,70,82,'#ffcc3a',3.6)}${bH('M31 47C31 35 37 26 44 22','#fff',3)}</g>`,
 pt:`<g class="k-pad">${bP('M50 46C37 46 26 57 27 68C28 78 37 83 50 81C63 83 72 78 73 68C74 57 63 46 50 46Z','#ffa24a')}${bF('M50 46C63 46 74 57 73 68C72 78 63 83 50 81Z','#a0400a',.22)}${bH('M35 58C39 52 44 50 50 50','#ffffffb0',2.6)}
  ${bP('M44.5 62C44.5 58.4 50 58.4 50 62C50 58.4 55.5 58.4 55.5 62C55.5 67 50 70.5 50 70.5C50 70.5 44.5 67 44.5 62Z','#ff5a8a',1.6)}</g>
  <g class="k-t1">${bEl(25,42,7,9,'#ffb86a',-22)}</g><g class="k-t2">${bEl(40,27,7.5,9.5,'#ffb86a',-8)}</g><g class="k-t3">${bEl(60,27,7.5,9.5,'#ffb86a',8)}</g><g class="k-t4">${bEl(75,42,7,9,'#ffb86a',22)}</g>
  ${bH('M22.5 37.5L24.5 35.5M37.5 22L39.5 20.5M57.5 21L59.5 20.5M72 36L74 35','#fff8',2)}`,
 pg:`${bP('M14 84H86V90H14Z','#6a5a8a',2.2)}<g class="k-b1">${bP('M20 59Q20 56 23 56H31Q34 56 34 59V84H20Z','#7ab8ff')}${bF('M27 56H31Q34 56 34 59V84H27Z','#1a2a6a',.25)}${bH('M23.5 61V80','#ffffffa0',2.2)}</g>
  <g class="k-b2">${bP('M43 45Q43 42 46 42H54Q57 42 57 45V84H43Z','#b47aff')}${bF('M50 42H54Q57 42 57 45V84H50Z','#2a0a6a',.25)}${bH('M46.5 47V80','#ffffffa0',2.2)}</g>
  <g class="k-b3">${bP('M66 33Q66 30 69 30H77Q80 30 80 33V84H66Z','#ff7ab4')}${bF('M73 30H77Q80 30 80 33V84H73Z','#6a0a3a',.25)}${bH('M69.5 35V80','#ffffffa0',2.2)}</g>
  <g class="k-fx">${bS(73,17,9,'#ffd45a')}</g>`,
 sh:`<g class="k-all"><g class="k-coin">${bC(50,30,8,'#ffd24a',2.2)}${bP('M48.6 26H51.4V34H48.6Z','#c8901a',0)}</g>
  ${bP('M33 37C27 30 31 22 38 25C40 18 47 16 50 21C53 16 60 18 62 25C69 22 73 30 67 37Z','#d89a34')}${bP('M32 40C18 52 18 83 50 85C82 83 82 52 68 40Z','#e8b040')}${bF('M50 40H68C82 52 82 83 50 85Z','#7a3a0a',.2)}
  ${bP('M31 35H69C70.5 35 71.5 36 71.5 37.5V40.5C71.5 42 70.5 43 69 43H31C29.5 43 28.5 42 28.5 40.5V37.5C28.5 36 29.5 35 31 35Z','#7a4a24',2.2)}
  ${bC(50,63,12.5,'#ffd24a')}${bC(50,63,8,'#f0b020',1.6)}${bP('M48.2 57H51.8V69H48.2Z','#fff0a0',0)}${bH('M27 55C28.5 49 31.5 45 35 43.5','#fff',2.8)}</g>`,
 mo:`<g class="k-d1">${bC(27,52,8.5,'#c8b8ff')}${bH('M23 49A5 5 0 0 1 27.5 46','#fff',1.8)}</g><g class="k-d2">${bC(50,52,8.5,'#ffd45a')}${bH('M46 49A5 5 0 0 1 50.5 46','#fff',1.8)}</g><g class="k-d3">${bC(73,52,8.5,'#c8b8ff')}${bH('M69 49A5 5 0 0 1 73.5 46','#fff',1.8)}</g>`});}

/* play the icon's animation once, to the end, on hover / focus / press / when it becomes the active tab */
function dkIcoPlay(btn){const s=btn&&btn.querySelector('.dkico');if(!s||(typeof dkRM==='function'&&dkRM()))return;if(s._busy)return;s._busy=1;s.classList.remove('k-go');void s.getBoundingClientRect();s.classList.add('k-go');
 clearTimeout(s._t);s._t=setTimeout(()=>{s.classList.remove('k-go');s._busy=0},900)}
document.addEventListener('pointerover',e=>{const b=e.target&&e.target.closest&&e.target.closest('.dki');if(!b||b.contains(e.relatedTarget))return;dkIcoPlay(b)},{passive:true});
document.addEventListener('focusin',e=>{const b=e.target&&e.target.closest&&e.target.closest('.dki');if(b&&b.matches(':focus-visible'))dkIcoPlay(b)});
document.addEventListener('pointerdown',e=>{const b=e.target&&e.target.closest&&e.target.closest('.dki');if(b){const s=b.querySelector('.dkico');if(s){s._busy=0}dkIcoPlay(b)}},{passive:true});

{const st=document.createElement('style');st.textContent=`
/* layout: the icon sits in a fixed box; nothing else moves when it animates */
.dki:hover,.dki:active{transform:none!important}
.dki .dkic{width:46px;height:46px;transition:transform .22s cubic-bezier(.3,1.5,.5,1)}
.dki .dkic svg{width:46px;height:46px;display:block;transform:scale(1.12)}
.dki:hover .dkic{transform:translateY(-3px) scale(1.06)}
.dki:active .dkic{transform:translateY(0) scale(.9);transition-duration:.08s}
.dkico{overflow:visible;filter:drop-shadow(0 3px 3px #0009)}
.dki.on .dkico{filter:drop-shadow(0 0 8px #ffffff55) drop-shadow(0 3px 3px #0009)}
.dkico g{transform-box:view-box;transform-origin:50px 50px;animation:none}
/* badges sit just off the icon's top-right corner instead of on top of the art */
.dki .bdg{top:2px!important;right:auto!important;left:calc(50% + 13px)!important;z-index:3}
/* pivots, in icon units */
.dkico-pl .k-a{transform-origin:62px 58px}.dkico-pl .k-b{transform-origin:38px 58px}.dkico-pl .k-fx,.dkico-pg .k-fx{opacity:0}
.dkico-pl .k-fx{transform-origin:50px 38px}
.dkico-gr .k-all{transform-origin:50px 86px}.dkico-gr .k-plume{transform-origin:46px 22px}
.dkico-pt .k-pad{transform-origin:50px 82px}.dkico-pt .k-t1{transform-origin:25px 50px}.dkico-pt .k-t2{transform-origin:40px 36px}.dkico-pt .k-t3{transform-origin:60px 36px}.dkico-pt .k-t4{transform-origin:75px 50px}
.dkico-pg .k-b1{transform-origin:27px 84px}.dkico-pg .k-b2{transform-origin:50px 84px}.dkico-pg .k-b3{transform-origin:73px 84px}.dkico-pg .k-fx{transform-origin:73px 17px}
.dkico-sh .k-all{transform-origin:50px 85px}.dkico-sh .k-coin{transform-origin:50px 30px;opacity:0}
.dkico-mo .k-d1{transform-origin:27px 52px}.dkico-mo .k-d2{transform-origin:50px 52px}.dkico-mo .k-d3{transform-origin:73px 52px}
/* the animations (each finishes before the class is removed) */
.k-go.dkico-pl .k-a{animation:kclA .62s ease-out}.k-go.dkico-pl .k-b{animation:kclB .62s ease-out}.k-go.dkico-pl .k-fx{animation:kspark .6s .1s ease-out}
@keyframes kclA{0%{transform:rotate(0)}30%{transform:rotate(11deg)}55%{transform:rotate(-3deg)}78%{transform:rotate(1deg)}100%{transform:rotate(0)}}
@keyframes kclB{0%{transform:rotate(0)}30%{transform:rotate(-11deg)}55%{transform:rotate(3deg)}78%{transform:rotate(-1deg)}100%{transform:rotate(0)}}
@keyframes kspark{0%{opacity:0;transform:scale(.2) rotate(0)}35%{opacity:1;transform:scale(1.25) rotate(45deg)}100%{opacity:0;transform:scale(.6) rotate(90deg)}}
.k-go.dkico-gr .k-all{animation:knod .7s cubic-bezier(.4,0,.3,1)}.k-go.dkico-gr .k-plume{animation:kplume .7s ease-in-out}
@keyframes knod{0%,100%{transform:rotate(0)}25%{transform:rotate(-7deg)}55%{transform:rotate(5deg)}80%{transform:rotate(-2deg)}}
@keyframes kplume{0%,100%{transform:rotate(0)}30%{transform:rotate(12deg)}60%{transform:rotate(-8deg)}85%{transform:rotate(3deg)}}
.k-go.dkico-pt .k-pad{animation:ksquish .6s cubic-bezier(.3,1.4,.5,1)}
.k-go.dkico-pt .k-t1{animation:kbean .5s .04s cubic-bezier(.3,1.6,.5,1)}.k-go.dkico-pt .k-t2{animation:kbean .5s .1s cubic-bezier(.3,1.6,.5,1)}.k-go.dkico-pt .k-t3{animation:kbean .5s .16s cubic-bezier(.3,1.6,.5,1)}.k-go.dkico-pt .k-t4{animation:kbean .5s .22s cubic-bezier(.3,1.6,.5,1)}
@keyframes ksquish{0%,100%{transform:scale(1)}30%{transform:scale(1.08,.9)}60%{transform:scale(.96,1.05)}}
@keyframes kbean{0%,100%{transform:translateY(0) scale(1)}40%{transform:translateY(-6px) scale(1.12)}}
.k-go.dkico-pg .k-b1{animation:kgrow .6s cubic-bezier(.3,1.5,.5,1)}.k-go.dkico-pg .k-b2{animation:kgrow .6s .08s cubic-bezier(.3,1.5,.5,1) backwards}.k-go.dkico-pg .k-b3{animation:kgrow .6s .16s cubic-bezier(.3,1.5,.5,1) backwards}.k-go.dkico-pg .k-fx{animation:kspark .55s .34s ease-out}
@keyframes kgrow{0%{transform:scaleY(.25)}100%{transform:scaleY(1)}}
.k-go.dkico-sh .k-all{animation:kjig .6s ease-in-out}.k-go.dkico-sh .k-coin{animation:kcoin .75s cubic-bezier(.3,.7,.4,1)}
@keyframes kjig{0%,100%{transform:rotate(0)}20%{transform:rotate(-6deg)}45%{transform:rotate(5deg)}70%{transform:rotate(-2deg)}}
@keyframes kcoin{0%{opacity:0;transform:translateY(8px) scaleX(1)}15%{opacity:1}45%{transform:translateY(-20px) scaleX(.15)}60%{transform:translateY(-22px) scaleX(1)}85%{opacity:1;transform:translateY(-4px) scaleX(.4)}100%{opacity:0;transform:translateY(6px) scaleX(1)}}
.k-go.dkico-mo .k-d1{animation:kbean .45s cubic-bezier(.3,1.6,.5,1)}.k-go.dkico-mo .k-d2{animation:kbean .45s .08s cubic-bezier(.3,1.6,.5,1)}.k-go.dkico-mo .k-d3{animation:kbean .45s .16s cubic-bezier(.3,1.6,.5,1)}
@media (prefers-reduced-motion:reduce){.dkico g{animation:none!important}.dki .dkic{transition:none}}
`;document.head.appendChild(st)}
