/* ===== FIT THE SCREEN WHEN EMBEDDED IN A WEBSITE =====
   On a website (for example a Wix HTML embed) the game's box can be taller than the screen can show: the game then scales
   to that box and its bottom part is off screen, even with the browser in fullscreen, because the box keeps its height.
   When the game is in an iframe and its box is taller than the visible screen, it scales to the visible screen height
   instead and sits at the top of its box. If the browser then reports that the bottom of the game is still cut off
   (a site banner or space above the game), it shrinks by that much (FIT.trim). Visible height: the whole screen when the browser is fullscreen, otherwise the
   available screen height minus the browser's tabs and address bar (FITBAR). It re-checks every 1.5 s, since going
   fullscreen with the keyboard does not resize the box. Settings › Display › "Fit to screen on websites" turns it off. */
Object.assign(defST,{fitscr:'auto'});if(ST.fitscr==null)ST.fitscr='auto';
const FIT={on:0,cap:0,trim:0},FITBAR=100;
function fitCap(){if(!inFrame())return 0;const sh=screen.height||0,ah=screen.availHeight||sh,oh=window.outerHeight||0;if(sh<300)return 0;
 return Math.round(oh>=sh-2?sh:Math.max(300,ah-FITBAR))}
{const a0=applyLayout;applyLayout=function(){const r=a0.apply(this,arguments);try{const cap=fitCap();FIT.cap=cap;const tgt=cap?Math.min(cap,innerHeight)-FIT.trim:0;
 if(ST.fitscr!=='off'&&cap&&!TM()&&tgt<innerHeight-24){let k=Math.min(innerWidth/W,tgt/H);if(ST.size!=='fit')k=Math.min(k,+ST.size);
  wrap.style.top=Math.round(H*k/2)+'px';wrap.style.transform=`translate(-50%,-50%) scale(${k})`;FIT.on=1}
 else if(FIT.on){FIT.on=0;if(!TM())wrap.style.top=''}}catch(e){}return r}}
setInterval(()=>{try{if(inFrame()&&fitCap()!==FIT.cap){FIT.trim=0;applyLayout()}}catch(e){}},1500);
/* what is really visible: the browser reports how much of the game is on screen even inside another site's page. When
   the top of the game shows but its bottom is cut off (a site banner, space above the game), shrink by the hidden part. */
try{if(inFrame()&&'IntersectionObserver' in window){new IntersectionObserver(es=>{try{const e=es[es.length-1];if(ST.fitscr==='off'||TM()||!e.isIntersecting)return;
 const B=e.boundingClientRect,I=e.intersectionRect,hidden=Math.round(B.bottom-I.bottom);
 if(I.top-B.top<2&&hidden>6&&FIT.trim+hidden<innerHeight*.45){FIT.trim+=hidden;applyLayout()}}catch(x){}},{threshold:[0,.25,.5,.7,.8,.85,.9,.93,.96,.98,.99,1]}).observe(wrap)}}catch(e){}
/* Settings › Display */
SETG.Display.push('Fit to screen on websites');
{const st0=settingsTabs;settingsTabs=function(){const r=st0.apply(this,arguments);try{const pf=ov.querySelector('#pfopt');if(pf&&!ov.querySelector('#fitopt')){
 const o=document.createElement('div');o.className='opt';o.id='fitopt';o.innerHTML=`<div><label>Fit to screen on websites</label><small>When the game is embedded in a website and its box is taller than your screen, shrink the game so all of it fits.</small></div><div class="seg">${[['auto','On'],['off','Off']].map(([v,l])=>`<button class="sm${ST.fitscr===v?' on':''}" data-k="fitscr" data-v="${v}">${l}</button>`).join('')}</div>`;
 pf.after(o);o.querySelectorAll('[data-k]').forEach(b=>b.onclick=()=>{ST.fitscr=b.dataset.v;saveST();applyLayout();o.querySelectorAll('[data-k]').forEach(x=>x.classList.toggle('on',x===b))})}}catch(e){}return r}}
