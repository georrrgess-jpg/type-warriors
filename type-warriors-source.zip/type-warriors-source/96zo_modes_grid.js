/* ===== MENUS 9.8: the Choose a mode sheet, tidied (96zo, after 96zn) =====
   The sheet had grown card by card (a tall Tower Defense card next to an empty gap, a full-width Caravan card, the rest in pairs).
   Now: three titled rows of three identical tiles, and the practice modes as two equal compact buttons under them.
     Story & survival     Campaign · Endless · Lantern Caravan
     Strategy & puzzles   Tower Defense · Runestone Riddle · Moonlit Fishing
     Casino & events      Casino · Wildcard · Events
   The existing buttons are moved, not rebuilt, so every click handler, badge, image and the gold "current" highlight stay.
   Anything a later module adds lands in the last row. Narrow screens (#ov.dknar) get two columns. */
const MDGROUPS=[['Story & survival',['dmc','dme','dmwr']],['Strategy & puzzles',['dmrp','dmd','dma']],['Casino & events',['dmk','dmwc','dmv']]];
function mdTidy(){try{const sh=document.querySelector('.dks .dkpv[data-v="m"]')||document.querySelector('.dkpv[data-v="m"]');if(!sh)return;
 const g=sh.querySelector('.dkmg:not(.dkmg1)');if(!g||g.dataset.tidy)return;g.dataset.tidy=1;
 const cards=[...g.querySelectorAll(':scope > .dkm')],byId=new Map(cards.map(c=>[c.id,c])),used=new Set();
 const wrap=document.createElement('div');wrap.className='mdsecs';
 MDGROUPS.forEach(([title,ids],gi)=>{const s=document.createElement('section');s.className='mdsec';s.innerHTML=`<h4>${title}</h4>`;const row=document.createElement('div');row.className='mdrow';
  for(const id of ids){const c=byId.get(id);if(c){row.appendChild(c);used.add(c)}}
  if(gi===MDGROUPS.length-1)for(const c of cards)if(!used.has(c)){row.appendChild(c);used.add(c)}
  if(row.children.length){s.appendChild(row);wrap.appendChild(s)}});
 g.replaceWith(wrap);
 /* the long title does not fit a tile */
 const td=wrap.querySelector('#dmrp .dkmt b');if(td)for(const n of td.childNodes)if(n.nodeType===3&&/Runestone Tower Defense/.test(n.textContent))n.textContent=n.textContent.replace('Runestone Tower Defense','Tower Defense');
 /* practice modes: two equal buttons side by side */
 const pr=[...sh.querySelectorAll(':scope > .dkpr2')];if(pr.length){const s=document.createElement('section');s.className='mdsec mdpr';s.innerHTML='<h4>Practice</h4>';const row=document.createElement('div');row.className='mdrow2';pr.forEach(b=>row.appendChild(b));s.appendChild(row);wrap.appendChild(s)}
 [...wrap.querySelectorAll('.dkm')].forEach((c,i)=>c.style.setProperty('--di',(i*.03).toFixed(2)+'s'))}catch(e){console.error(e)}}
{const m0=modeSheet;modeSheet=function(){const r=m0.apply(this,arguments);mdTidy();return r}}
{const st=document.createElement('style');st.textContent=`
.mdsecs{display:flex;flex-direction:column;gap:14px}
.mdsec h4{margin:0 0 8px 4px;font:800 12px var(--ui);letter-spacing:.22em;text-transform:uppercase;color:#a99be0}
.mdrow{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}
.mdrow .dkm{min-height:0;height:150px;flex-direction:column;align-items:flex-start;justify-content:flex-start;gap:8px;padding:14px 16px 12px;grid-column:auto}
.mdrow .dkm::after{background:linear-gradient(180deg,#0b0718c8 0%,#0b0718ec 55%,#0b0718f6)}
.mdrow .dkm .dkmi{display:flex;width:46px;height:46px;flex:none}.mdrow .dkm .dkmi svg,.mdrow .dkm .dkmi img{width:46px!important;height:46px!important}
.mdrow .dkm .dkmt{gap:3px;max-width:none;width:100%}
.mdrow .dkm .dkmt b{font:800 17.5px/1.15 var(--ui);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:auto;display:flex;align-items:center;gap:6px}
.mdrow .dkm .dkmt small{font:500 13px/1.3 var(--ui);padding-right:18px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.mdrow .dkm .dkchv{top:auto;bottom:12px;right:14px;transform:none}.mdrow .dkm:hover .dkchv{transform:translateX(3px)}
.mdrow .dkm .dkmt b>*{flex:none;margin:0!important;transform:scale(.92);transform-origin:left center}
.mdrow2{display:grid;grid-template-columns:1fr 1fr;gap:12px}.mdrow2 .dkpr2{margin-top:0;height:64px}
.dks.on .mdrow .dkm{animation-delay:var(--di,0s)}
#ov.dknar .mdrow{grid-template-columns:1fr 1fr}#ov.dknar .mdrow2{grid-template-columns:1fr}`;document.head.appendChild(st)}
