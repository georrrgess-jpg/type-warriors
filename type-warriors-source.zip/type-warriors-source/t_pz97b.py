# python3 t_pz97b.py : 9.7 The Crooked Cue How to Play, restyled to the concept art (96zi): the sign, five tabs, the
# regulars in the corners, every tab's cards and art, the Shooting selector, the Controls lists checked against the real
# input code (every listed key is pressed in a practice match), Replay the tutorials and the Practice Table, the
# pause-menu version, no text overflow or overlap, the frame cost of the loops, reduced motion and no page errors.
import asyncio,os,sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:600]),flush=True)
    if not ok:FAIL.append(name)
PRE="()=>{RS_ASK=false;PZ_TUT_OFF=true;WCRELAYS=[];ST.perfAsked=1;PFW.asked=true;P.gold=100000;P.pz=null;const Z=PZS();Z.tut={hub:1,m1:1,trick:1,rack:1,ai1:1};save()}"
TABS=['basics','shoot','fouls','extras','keys']
CARDS={'basics':3,'shoot':3,'fouls':3,'extras':5,'keys':5}
# every text block inside the tab body: no scrolling overflow, inside its card and the body, and no two blocks overlapping
LAYOUT="""(sel)=>{const root=document.querySelector(sel),body=root&&root.querySelector('#pzhbody');if(!body)return ['no body'];const bad=[],B=body.getBoundingClientRect(),txt=[];
 const R=r=>[Math.round(r.left),Math.round(r.top),Math.round(r.width),Math.round(r.height)];
 body.querySelectorAll('*').forEach(el=>{if(el.closest('svg')||el.parentElement.closest('.pzw-flow'))return;const cs=getComputedStyle(el);if(cs.display==='none'||cs.visibility==='hidden')return;
  const has=[...el.childNodes].some(n=>n.nodeType===3&&n.textContent.trim()),r=el.getBoundingClientRect();if(!r.width)return;
  if(r.right>B.right+1||r.bottom>B.bottom+1||r.left<B.left-1||r.top<B.top-1)bad.push(['outside body',el.tagName,el.className,(el.textContent||'').slice(0,30),R(r)]);
  if(!has)return;
  if(cs.display!=='inline'&&el.clientWidth>0&&(el.scrollWidth>el.clientWidth+1||el.scrollHeight>el.clientHeight+2))bad.push(['overflow',el.tagName,el.className,el.textContent.slice(0,40),el.scrollWidth,el.clientWidth,el.scrollHeight,el.clientHeight]);
  const card=el.parentElement.closest('.pzhcard,.pzw-det,.pzw-strip,.pzw-fh,.pzw-finfo,.pzw-kr,.pzw-sel,.pzw-gm,.pzw-tbl,.pzw-ktbl');
  if(card){const c=card.getBoundingClientRect();if(r.right>c.right+1||r.bottom>c.bottom+1||r.left<c.left-1||r.top<c.top-1)bad.push(['outside card',el.tagName,el.className,el.textContent.slice(0,30),R(r),R(c)])}
  if(cs.display!=='inline')txt.push([el,r])});
 for(let i=0;i<txt.length;i++)for(let j=i+1;j<txt.length;j++){const [a,ra]=txt[i],[b,rb]=txt[j];if(a.contains(b)||b.contains(a))continue;
  const w=Math.min(ra.right,rb.right)-Math.max(ra.left,rb.left),h=Math.min(ra.bottom,rb.bottom)-Math.max(ra.top,rb.top);if(w>1.5&&h>1.5)bad.push(['overlap',a.textContent.slice(0,24),b.textContent.slice(0,24),R(ra),R(rb)])}
 return bad.slice(0,8)}"""
# share of a canvas that is painted (sampled)
INK="""(cv)=>{try{const g=cv.getContext('2d'),d=g.getImageData(0,0,cv.width,cv.height).data;let n=0,t=0;for(let i=3;i<d.length;i+=4*37){t++;if(d[i]>20)n++}return n/t}catch(e){return -1}}"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();er=[]
        pg=await b.new_page(viewport={'width':1600,'height':900})
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(H);await pg.wait_for_timeout(1500);await pg.evaluate(PRE);E=pg.evaluate
        # ---------------------------------------------------------------- the screen
        await E("()=>{casinoOpen();gameOpen('pz');0}");await pg.wait_for_timeout(900)
        await E("()=>{PZ.howTab='basics';pzRules();0}");await pg.wait_for_timeout(500)
        r=await E("()=>{const s=document.querySelector('.pzhwS');return [!!s&&s.classList.contains('pzwin'),getComputedStyle(document.querySelector('.pzhwsign')).animationName]}")
        chk('the screen builds itself in (springy entrance on the sign, panel, tabs, cards and regulars)',r[0] and 'pzwSign' in r[1],r)
        await pg.wait_for_timeout(1800)
        r=await E("""()=>({root:!!document.querySelector('#pzr.pzr.pzhwscr'),sign:(document.querySelector('.pzhwsign span')||{}).textContent,back:(document.getElementById('pzbk')||{}).textContent,
          tabs:[...document.querySelectorAll('.pzhtabs button')].map(b=>[b.dataset.h,b.textContent,b.classList.contains('on')]),re:(document.querySelector('#pzhre span')||{}).textContent,pr:(document.querySelector('#pzhpr span')||{}).textContent,
          inwin:document.querySelector('.pzhwS').classList.contains('pzwin')})""")
        chk('wooden "How to Play" sign, "The bar" back button, Replay the tutorials and Try it at the Practice Table',r['root'] and r['sign']=='How to Play' and 'The bar' in r['back'] and r['re'].strip()=='Replay the tutorials' and r['pr'].strip()=='Try it at the Practice Table',r)
        chk('five tabs in the concept order with Basics active',[t[0] for t in r['tabs']]==TABS and [t[1] for t in r['tabs']]==['Basics','Shooting','Fouls','Guide & extras','Controls'] and r['tabs'][0][2] and not any(t[2] for t in r['tabs'][1:]),r['tabs'])
        chk('the entrance class is removed once it has played',not r['inwin'],r)
        r=await E("()=>{const tab=getComputedStyle(document.querySelector('.pzhtabs button.on')),off=getComputedStyle(document.querySelector('.pzhtabs button:not(.on)'));return [tab.backgroundImage.includes('255, 229'),off.backgroundImage.includes('61, 49')]}")
        chk('the active tab is gold and the others indigo',all(r),r)
        r=await E("()=>{const ink="+INK+";return {mon:[...document.querySelectorAll('.pzhwm canvas')].map(ink),ids:[...document.querySelectorAll('.pzhwm canvas')].map(c=>c._st&&c._st.id),sign:ink(document.querySelector('.pzhwsign canvas')),rail:ink(document.querySelector('canvas.pzhwrail')),z:[getComputedStyle(document.querySelector('.pzhwm')).zIndex,getComputedStyle(document.querySelector('.pzhwpan')).zIndex],live:LIVE.filter(L=>L.cv.closest('.pzhwm')).length}}")
        chk('two regulars peek from the bottom corners (drawn by their rigs, animated on LIVE, behind the panel so they never cover text)',len(r['mon'])==2 and all(x>.08 for x in r['mon']) and r['ids']==['grizzle','vesper'] and r['live']==2 and int(r['z'][0])<int(r['z'][1]),r)
        chk('the sign and the table rail are painted',r['sign']>.3 and r['rail']>.5,r)
        # ---------------------------------------------------------------- every tab
        ids={}
        for k in TABS:
            await pg.click(f'.pzhtabs button[data-h="{k}"]');await pg.wait_for_timeout(1300)
            r=await E("(k)=>{const ink="+INK+",b=document.getElementById('pzhbody');return {t:b.dataset.t,on:document.querySelector('.pzhtabs button.on').dataset.h,cards:b.querySelectorAll('.pzhcard').length,art:[...b.querySelectorAll('canvas[data-art]')].map(c=>[c.dataset.art,+ink(c).toFixed(3)]),ov:[...b.querySelectorAll('.pzw-flow')].map(f=>[f.querySelectorAll('.pzw-ln').length,[...f.querySelectorAll('.pzw-ln>i,.pzw-gl>i,.pzw-cuew canvas')].map(x=>x.getAnimations().filter(a=>a.playState==='running').length).reduce((s,n)=>s+n,0)]),live:LIVE.filter(L=>b.contains(L.cv)).length,mons:[...document.querySelectorAll('.pzhwm canvas')].map(c=>c._st&&c._st.id),txt:b.textContent}}",k)
            ids[k]=r['mons']
            chk(f'{k}: the tab opens with its {CARDS[k]} cards and every illustration painted',r['t']==k and r['on']==k and r['cards']==CARDS[k] and r['art'] and all(a[1]>.01 for a in r['art']),r)
            if k in('shoot','extras','keys'):chk(f'{k}: the guide lines on the felt flow with compositor-only loops (no canvas redraws)',len(r['ov'])==1 and r['ov'][0][0]>=1 and r['ov'][0][1]>=1 and r['live']==0,r)
            lay=await E(LAYOUT,'#pzr')
            chk(f'{k}: no text overflows, leaves its card or overlaps other text',not lay,lay)
            if k=='basics':
                chk('basics: Solids or stripes / Then the 8 / Win the race with the old hook (.pzhcard canvas = 3)',all(x in r['txt'] for x in['Solids or stripes','Then the 8','Win the race','call a pocket','race']) and await E("()=>document.querySelectorAll('.pzhcard canvas').length")==3,r['txt'][:200])
            if k=='fouls':
                rr=await E("()=>({x:document.querySelectorAll('.pzw-fart .pzw-xm').length,hi:getComputedStyle(document.querySelector('.pzw-f.hi')).borderTopColor,arr:!!document.querySelector('.pzw-farr svg'),hd:document.querySelector('.pzw-fhd').textContent,info:document.querySelector('.pzw-finfo').textContent})")
                chk('fouls: Scratch and Wrong ball first with red crosses, a gold arrow to the green "Opponent gets ball in hand" card, and the other fouls',rr['x']==2 and rr['arr'] and 'ball in hand' in rr['hd'].lower() and '62, 232, 160' in rr['hi'] and all(x in rr['info'] for x in['no ball at all','cushion','shot clock']),rr)
                chk('fouls: the texts match the rules (scratch, first contact, ball in hand anywhere)',all(x in r['txt'] for x in['enters a pocket','first contact','any ball but the 8','ball in hand','anywhere']),r['txt'][:300])
            if k=='extras':
                t=r['txt']
                chk('guide & extras: the 9.6 guide (aim line, ghost ball, gold to the first cushion, blue cue-ball path; Full / Short / Pro; G switches) and no "green ring"',all(x in t for x in['first cushion','Ghost ball','blue cue-ball path','Short','Pro','switches','judging the pocket']) and 'green ring' not in t.lower() and 'it drops' not in t.lower(),t[:400])
                chk('guide & extras: taunts, fast-forward, shot clock and house rules',all(x in t for x in['Taunts','type it in time','Fast-forward','3×','Shot clock','45 s','Mortimer: 25 s','House rules','25-second shot clock']) and 'bank the 8' not in t,t[:400])
                gm=await E("()=>[...document.querySelectorAll('.pzw-gm.on')].map(x=>x.dataset.g)")
                chk('guide & extras: your own guide setting is marked',gm==[await E("()=>PZS().guide")],gm)
            if k=='keys':
                rr=await E("""()=>{const t=document.querySelector('.pzw-ktbl').getBoundingClientRect(),bs=[...document.querySelectorAll('.pzw-pk')].map(p=>{const r=p.getBoundingClientRect();return [+p.textContent,(r.left+r.width/2-t.left)/t.width,(r.top+r.height/2-t.top)/t.height]});
                  const want=PZ_POCK.map(q=>[q[0]<100?0:q[0]>800?2:1,q[1]<220?0:1]);return {bs,want,ok:bs.every(([n,x,y])=>{const [wx,wy]=want[n-1];return (wx===0?x<.25:wx===2?x>.75:Math.abs(x-.5)<.1)&&(wy===0?y<.3:y>.7)}),rows:document.querySelectorAll('.pzhowk>div').length}}""")
                chk('controls: the pockets are numbered 1-6 exactly as the game numbers them (PZ_POCK: 1-3 along the top, 4-6 along the bottom)',rr['ok'] and len(rr['bs'])==6,rr)
                chk('controls: the Essential / Advanced lists keep the old hook (.pzhowk>div >= 8)',rr['rows']>=8,rr)
        chk('a different pair of regulars on each tab',len(set(tuple(v) for v in ids.values()))>=4,ids)
        # ---------------------------------------------------------------- tab keys
        await pg.click('.pzhtabs button[data-h="fouls"]');await pg.wait_for_timeout(500)
        await pg.keyboard.press('ArrowRight');await pg.wait_for_timeout(300);a=await E("()=>document.getElementById('pzhbody').dataset.t")
        await pg.keyboard.press('ArrowLeft');await pg.keyboard.press('ArrowLeft');await pg.wait_for_timeout(300);c=await E("()=>document.getElementById('pzhbody').dataset.t")
        chk('left / right switch tabs',a=='extras' and c=='shoot',[a,c])
        # ---------------------------------------------------------------- the Shooting selector
        await pg.wait_for_timeout(800);res=[]
        for s,title in [('aim','Aim'),('spin','Spin'),('power','Power')]:
            await pg.click(f'.pzw-sel button[data-s="{s}"]');await pg.wait_for_timeout(500)
            res.append(await E("()=>{const d=document.getElementById('pzwdet');return [d.dataset.s,d.querySelector('.pzw-dt').textContent,document.querySelector('.pzw-sel button.on').dataset.s,getComputedStyle(document.querySelector('.pzw-sel')).getPropertyValue('--k').trim(),d.querySelectorAll('canvas[data-art]').length,!!d.querySelector('.pzw-pb'),!!d.querySelector('.pzw-shootb'),d.textContent]}"))
        chk('shooting: Aim / Power / Spin switch the detail panel (title, art, the gold pill moves)',[x[0] for x in res]==['aim','spin','power'] and [x[1] for x in res]==['Aim','Spin','Power'] and [x[2] for x in res]==['aim','spin','power'] and [x[3] for x in res]==['0','2','1'] and res[0][4]>=3 and res[1][4]>=1 and res[2][4]>=3,[x[:5] for x in res])
        chk('shooting: Power shows pull back, the power bar and SHOOT (Space); Aim and Spin show their own controls',res[2][5] and res[2][6] and 'pull back' in res[2][7] and 'Space' in res[2][7] and 'fine aim' in res[0][7] and 'Shift' in res[0][7] and all(x in res[1][7] for x in['W','A','S','D','R','spin ball']),[x[7][:120] for x in res])
        lay=await E(LAYOUT,'#pzr');chk('shooting: the detail panels fit (no overflow or overlap after switching)',not lay,lay)
        await pg.keyboard.press('ArrowDown');await pg.wait_for_timeout(300);a=await E("()=>PZW.sub")
        await pg.keyboard.press('ArrowUp');await pg.keyboard.press('ArrowUp');await pg.wait_for_timeout(300);c=await E("()=>PZW.sub")
        await pg.click('.pzw-mini[data-s="spin"]');await pg.wait_for_timeout(300);d=await E("()=>PZW.sub")
        chk('shooting: up / down and the three small cards also pick Aim, Power or Spin',a=='spin' and c=='aim' and d=='spin',[a,c,d])
        # ---------------------------------------------------------------- frame cost
        r=await E("""()=>{const Ls=LIVE.filter(L=>L.cv.closest('#pzr'));const out=Ls.map(L=>{const a=performance.now();for(let i=0;i<30;i++)L.fn(performance.now()/1000);const ms=(performance.now()-a)/30,ev=L.slow>1?L.slow:(L.slow?4:1);return [L.cv.dataset.flow||'regular',+ms.toFixed(3),ev]});
          return {out,frame:+out.reduce((s,[k,ms,ev])=>s+ms/ev,0).toFixed(3)}}""")
        chk('the loops cost well under 1 ms a frame (only the two regulars are on LIVE, and they repaint only to blink)',r['frame']<.2 and len(r['out'])==2,r)
        r=await E("()=>{const s=[...document.querySelectorAll('#pzhbody *, .pzhwS *')].flatMap(el=>el.getAnimations()).filter(a=>a.effect&&a.effect.getComputedTiming().iterations===Infinity);const props=new Set();s.forEach(a=>a.effect.getKeyframes().forEach(k=>Object.keys(k).forEach(x=>props.add(x))));return [s.length,[...props].filter(x=>!['offset','easing','composite','computedOffset','transform','opacity','scale','rotate','translate'].includes(x))]}")
        chk('every looping animation on the screen animates only transform or opacity',r[0]>0 and not r[1],r)
        css=await E("()=>[...document.styleSheets].map(s=>{try{return [...s.cssRules].map(r=>r.cssText).join('\\n')}catch(e){return ''}}).join('\\n').split('\\n').filter(l=>/pzw|pzhw/.test(l)).join('\\n')")
        chk('performance rules: no backdrop-filter, blend modes, animated box-shadow/filter or background-position in the new styles',not any(x in css for x in['backdrop-filter','mix-blend-mode','soft-light'])and not __import__('re').search(r'@keyframes pzw[^{]*\{[^@]*(box-shadow|filter|background-position|width|height|left|top)\s*:',css),'')
        src=await E("()=>[pzwMonPaint.toString(),Object.values(PZW_ART).map(f=>f.toString()).join(''),pzwFlowHtml.toString()].join('')")
        chk('canvas art uses no ctx.filter or shadowBlur',('shadowBlur' not in src) and ('.filter=' not in src),'')
        # ---------------------------------------------------------------- Controls: every listed key does what it says (practice match)
        await pg.click('.pzhtabs button[data-h="keys"]');await pg.wait_for_timeout(900)
        keys=await E("()=>Object.fromEntries([...document.querySelectorAll('.pzhowk>div')].map(d=>[d.dataset.probe,d.querySelector('kbd').textContent.replace(/\\s+/g,' ').trim()]))")
        want={'mouse':'Mouse','space':'Space / Enter','call':'1 – 6','esc':'Esc','fine':'Shift / right mouse button','nudge':'Wheel / ◀ ▶','power':'▲ ▼','spin':'W A S D / R','guide':'G','place':'Arrows + Space'}
        chk('controls: the lists show Mouse, Space / Enter, 1-6, Esc, Shift / right button, wheel and arrows, up/down, W A S D / R, G, ball in hand',keys==want,keys)
        cards=await E("()=>[...document.querySelectorAll('.pzw-kc,.pzw-kx')].map(c=>c.textContent.replace(/\\s+/g,' ').trim())")
        chk('controls: Aim, Shoot (Space), Spin (W A S D, R), Call a pocket (1-6) and Guide (G) cards',len(cards)==5 and 'Aim' in cards[0] and 'Space' in cards[1] and all(x in cards[2] for x in['W','A','S','D','R']) and all(str(n) in cards[3] for n in range(1,7)) and 'G' in cards[4],cards)
        await E("()=>{pzStart({opp:'gloop',practice:true,seed:4});0}");await pg.wait_for_timeout(400);await E("()=>{const i=document.getElementById('pzintro');if(i)i.click();0}")
        await E("async()=>{for(let i=0;i<80&&!(PZ.ph==='aim'&&PZ.mode==='aim');i++)await new Promise(r=>setTimeout(r,100))}")
        P0=await E("()=>[PZ.ph,PZ.mode,PZ.B[0].x,PZ.B[0].y]");cx,cy=360+P0[2],214+P0[3]
        await pg.mouse.move(cx+260,cy-30);await pg.wait_for_timeout(200)
        pr={}
        await E("()=>{PZ.aim.a=0;PZ.aim.b=0;0}")
        for k in 'wd':await pg.keyboard.press(k)
        s1=await E("()=>[PZ.aim.a,PZ.aim.b]");
        for k in 'sas':await pg.keyboard.press(k)
        s2=await E("()=>[PZ.aim.a,PZ.aim.b]");await pg.keyboard.press('r');s3=await E("()=>[PZ.aim.a,PZ.aim.b]")
        pr['spin']=s1[0]>0 and s1[1]>0 and s2[0]<s1[0] and s2[1]<0 and s3==[0,0]
        g0=await E("()=>PZS().guide");await pg.keyboard.press('g');await pg.wait_for_timeout(100);g1=await E("()=>PZS().guide");await pg.keyboard.press('g');await pg.keyboard.press('g');g3=await E("()=>PZS().guide")
        pr['guide']=g0!=g1 and g3==g0
        a0=await E("()=>PZ.aim.ang");await pg.keyboard.press('ArrowRight');a1=await E("()=>PZ.aim.ang");await pg.mouse.wheel(0,120);await pg.wait_for_timeout(100);a2=await E("()=>PZ.aim.ang")
        pr['nudge']=a1>a0 and abs(a2-a1)>0.001
        p0=await E("()=>PZ.aim.pow");await pg.keyboard.down('ArrowUp');await pg.wait_for_timeout(500);await pg.keyboard.up('ArrowUp');p1=await E("()=>PZ.aim.pow")
        await pg.keyboard.down('ArrowDown');await pg.wait_for_timeout(300);await pg.keyboard.up('ArrowDown');p2=await E("()=>PZ.aim.pow")
        pr['power']=p1>p0 and p2<p1
        await pg.mouse.down(button='right');f1=await E("()=>PZ.fineBtn");await pg.mouse.up(button='right');f2=await E("()=>PZ.fineBtn")
        pr['fine']=f1 is True and f2 is False and await E("()=>/e\\.shiftKey\\|\\|PZ\\.fineBtn/.test(pzBindMatch.toString())")
        await pg.keyboard.press('Escape');await pg.wait_for_timeout(300);e1=await E("()=>!!document.querySelector('#pzmod [data-a=resume]')&&PZ.modal")
        await pg.click('#pzmod [data-a=resume]');await pg.wait_for_timeout(200);pr['esc']=e1 and not await E("()=>PZ.modal")
        await E("()=>{const st=PZ.st;st.brk=false;st.bih=true;st.kitchen=false;PZ.mode='place';PZ.place={x:520,y:200,ok:true};pzHudAll();0}")
        await pg.keyboard.press('ArrowRight');x1=await E("()=>PZ.place&&PZ.place.x");await pg.keyboard.press('Space');await pg.wait_for_timeout(100)
        pl=await E("()=>[PZ.mode,PZ.B[0].x]");pr['place']=x1 is not None and x1>520 and pl[0]=='aim' and abs(pl[1]-x1)<1
        await E("()=>{const B=PZ.B,st=PZ.st;st.open=false;st.grp=['s','t'];st.turn=0;for(const b of B)if(b.id>=1&&b.id<=7)b.on=false;pzHudAll();0}")
        await pg.keyboard.press('3');c3=await E("()=>[pzrOn8(PZ.st),PZ.call]");await pg.keyboard.press('6');c6=await E("()=>PZ.call")
        pr['call']=c3==[True,2] and c6==5
        await pg.mouse.move(cx+300,cy+10);await pg.wait_for_timeout(100);await E("()=>{PZ.moved=true;PZ.aim.pow=.45;0}")
        await pg.keyboard.press('Space');await pg.wait_for_timeout(150);ph=await E("()=>PZ.ph")
        await E("async()=>{for(let i=0;i<20&&PZ.ph!=='roll';i++)await new Promise(r=>setTimeout(r,50))}")
        await pg.keyboard.down('Space');await pg.wait_for_timeout(120);ff=await E("()=>[PZ.ph,PZ.ffHeld,pzFF()]");await pg.keyboard.up('Space');ff2=await E("()=>PZ.ffHeld")
        pr['space']=ph in('stroke','roll') and ff[1] is True and ff[2]==3 and ff2 is False
        # the mouse: a real press, pull back and let go fires a shot (fresh match)
        await E("()=>{pzStart({opp:'gloop',practice:true,seed:9});0}");await pg.wait_for_timeout(400);await E("()=>{const i=document.getElementById('pzintro');if(i)i.click();0}")
        await E("async()=>{for(let i=0;i<300&&!(PZ.ph==='aim'&&PZ.mode==='aim');i++){if(PZ.ph==='aim'&&PZ.mode==='place'&&PZ.place&&PZ.place.ok)pzPlaceCue(PZ.place.x,PZ.place.y);if(PZ.ph==='ai'&&PZ.ai)PZ.ai.skip=true;await new Promise(r=>setTimeout(r,100))}}")
        P0=await E("()=>[PZ.B[0].x,PZ.B[0].y,PZ.ph,PZ.mode]");cx,cy=360+P0[0],214+P0[1]
        # aim at the far side of the table, press out in front of the ball and pull straight back toward it
        tx,ty=(360+660,214+220) if P0[0]<440 else (360+220,214+220);dx,dy=tx-cx,ty-cy;L=max(1,(dx*dx+dy*dy)**.5);dx,dy=dx/L,dy/L
        await pg.mouse.move(cx+dx*300,cy+dy*300);await pg.wait_for_timeout(300);await pg.mouse.down();await pg.mouse.move(cx+dx*270,cy+dy*270,steps=4);await pg.mouse.move(cx+dx*140,cy+dy*140,steps=8);await pg.wait_for_timeout(250);await pg.mouse.up();await pg.wait_for_timeout(300)
        mo=await E("()=>[PZ.ph,PZ.mode,PZ.aim.pow]");pr['mouse']=mo[0] in('stroke','roll','settle')
        if not pr['mouse']:print('mouse probe',P0,mo)
        chk('controls: every listed binding does what the list says in a real match',set(pr)==set(want) and all(pr.values()),pr)
        # ---------------------------------------------------------------- the pause-menu version
        await E("async()=>{for(let i=0;i<120&&PZ.ph!=='aim';i++)await new Promise(r=>setTimeout(r,100))}")
        await E("()=>{PZ.howTab='basics';pzPauseMenu();0}");await pg.wait_for_timeout(400);await pg.click('#pzmod [data-a=rules]');await pg.wait_for_timeout(1500)
        r=await E("()=>{const m=document.getElementById('pzmod');return {how:!!m.querySelector('.pzhw.modal'),tabs:m.querySelectorAll('.pzhtabs button').length,cards:m.querySelectorAll('.pzhcard canvas').length,title:(m.querySelector('.pzh2')||{}).textContent,w:Math.round(m.querySelector('.pzmp').getBoundingClientRect().width),back:!!m.querySelector('[data-a=back]')}}")
        chk('pause menu: How to play opens the same five tabs in a wide modal with a Back button',r['how'] and r['tabs']==5 and r['cards']==3 and r['title']=='How to Play' and r['back'] and r['w']<=1340,r)
        bad=[]
        for k in TABS:
            await pg.click(f'#pzmod .pzhtabs button[data-h="{k}"]');await pg.wait_for_timeout(1100)
            lay=await E(LAYOUT,'#pzmod')
            if lay:bad.append([k,lay])
        chk('pause menu: every tab fits without overflow or overlap',not bad,bad)
        r=await E("()=>{const m=document.querySelector('#pzmod .pzmp').getBoundingClientRect();return [m.top>=0,m.bottom<=900,document.querySelectorAll('#pzmod .pzhowk>div').length]}")
        chk('pause menu: the modal stays on the stage and the Controls tab lists the keys',r[0] and r[1] and r[2]>=8,r)
        await pg.keyboard.press('ArrowLeft');await pg.wait_for_timeout(300);a=await E("()=>document.querySelector('#pzmod #pzhbody').dataset.t")
        await pg.keyboard.press('Escape');await pg.wait_for_timeout(300);c=await E("()=>!!document.querySelector('#pzmod [data-a=resume]')")
        await E("()=>{pzRulesModal();0}");await pg.wait_for_timeout(300);await pg.click('#pzmod [data-a=back]');await pg.wait_for_timeout(300);d=await E("()=>!!document.querySelector('#pzmod [data-a=resume]')")
        chk('pause menu: left/right switch tabs, Esc and Back return to the pause menu',a=='extras' and c and d,[a,c,d])
        await E("()=>{pzModalClose();pzForfeit&&pzForfeit();0}");await pg.wait_for_timeout(400)
        # ---------------------------------------------------------------- the buttons
        await E("()=>{const Z=PZS();Z.tut={hub:1,m1:1,trick:1,rack:1,ai1:1,spin:1};save();pzRules();0}");await pg.wait_for_timeout(1900)
        await pg.click('#pzhre');await pg.wait_for_timeout(150)
        r=await E("()=>[JSON.stringify(PZS().tut),(document.getElementById('pznote')||{}).textContent||'']");await pg.wait_for_timeout(900);h=await E("()=>!!document.getElementById('pzh')")
        chk('Replay the tutorials resets every tutorial, says so and goes back to the bar',r[0]=='{}' and 'Tutorials reset' in r[1] and h,[r,h])
        await E("()=>{PZS().tut={hub:1,m1:1,trick:1,rack:1,ai1:1};save();pzRules();0}");await pg.wait_for_timeout(1900)
        g0=await E("()=>P.gold");await pg.click('#pzhpr');await pg.wait_for_timeout(600)
        r=await E("()=>[PZ.on,PZ.M&&PZ.M.practice,PZ.reg&&PZ.reg.id,PZ.M&&PZ.M.stake||0,P.gold]")
        chk('Try it at the Practice Table starts a free practice match against Gloop',r[0] and r[1] and r[2]=='gloop' and not r[3] and r[4]==g0,r)
        await E("()=>{pzForfeit&&pzForfeit();0}");await pg.wait_for_timeout(400)
        await E("()=>{pzHub();0}");await pg.wait_for_timeout(1300);await E("()=>{pzRules();0}");await pg.wait_for_timeout(1900);await pg.click('#pzbk');await pg.wait_for_timeout(700)
        chk('The bar (and Esc) go back to the hub',await E("()=>!!document.getElementById('pzh')"))
        # ---------------------------------------------------------------- reduced motion
        await E("()=>{document.body.classList.add('pf-low');PZ_RMC.t=0;pzRules();0}");await pg.wait_for_timeout(400)
        r=await E("()=>{const root=document.querySelector('.pzhwS');return [root.classList.contains('pzwrm'),LIVE.filter(L=>L.cv.closest('#pzr')).length,[...document.querySelectorAll('.pzhwm canvas')].every(c=>c._st)]}")
        chk('reduced motion / low performance: no loops, still frames drawn',r[0] and r[1]==0 and r[2],r)
        await E("()=>{document.body.classList.remove('pf-low');PZ_RMC.t=0;pzHub();0}");await pg.wait_for_timeout(600)
        chk('no page errors',not er,er)
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
