/* ===== CASINO 9.7c: exploit and balance pass (96zm, after 96zl) =====
   An audit of every casino game except Pool, Wildcard and Nebula Scratch (return to player of every option, reload/leave/
   double-click flows, bet limits, hidden outcomes, trophy farming). Changes, together with two careful edits:
   - Higher or Lower (65_casino.js): HLE 1.075 -> .99 and no face-card cut (HLFACE 1). Every guess paid 107.5% on 2-10 and the
     face-card cut was dodged by cashing out on J-A, so a simple strategy returned ~109.5% (~+1,400 gold/min at 1,000 a bet).
     Now every guess returns at most 99% and a round 95-97.5% (multipliers are rounded down).
   - Quiz Showdown (67c_quiz.js + here): the top payout 2.5x -> 1.5x, cash-out only after QZ.MINP (4) clues, and after
     QZD.full (5) winning quizzes in a day the profit part of the payout is QZD.k (25%). A perfect player made ~2,500 gold/min;
     now ~1,000/min for the first five quizzes of the day and ~250/min after, in line with the typing modes (250-400/min).
   - Rocket: the crash curve gave exactly 100% at 1.5x and at 60x-1000x. It now returns 96% at every cash-out target, and a
     single round pays at most RKWIN (250,000; 5,000 x 1,000 used to pay 5,000,000).
   - Slots: crowns pay 125 (was 100): 94.6% -> 96.0%, in line with Dice, Plinko and the Wheel.
   - Blackjack (65_casino.js): a fresh 6-deck shoe for every hand. The shoe used to last until 90 cards were left, so a card
     counter betting 1 / 3,750 by the count beat the house (100.9%); basic strategy stays at 99.05%.
   - Tower Climb: the launch-day boost (110% on 2026-10-06) is retired; setting the computer clock back to that day turned it on.
   - Trophies for multipliers and streaks (To the Moon, Jackpot!, Bullseye, Fortune Favors, the Tower Climb floors, the
     Blackjack streak trophies) need a bet of at least
     CASTRO (100); they were farmed with 1-gold bets. A round that only returns the stake no longer extends Lucky Streak. */
const RKWIN=250000,CASTRO=100,QZD={full:5,k:.25};
/* which game a payout belongs to (cFlush pays rounds left in the air while leaving, before the new game is set) */
{const g0=gameOpen;gameOpen=function(id){const r=g0.apply(this,arguments);CAS.gid=id;return r}}
{const l0=lobby;lobby=function(){const r=l0.apply(this,arguments);CAS.gid=null;return r}}
/* the last stake taken, for the trophy floor */
{const t0=cTake;cTake=function(b){const ok=t0.apply(this,arguments);if(ok)CAS.lb=Math.floor(b);return ok}}
{const s0=stat,TRO=new Set(['rk','slotx','plk','whl','twf','tws','bj','bjn']);stat=function(k,v,m){if(TRO.has(k)&&CAS&&CAS.on!==false&&(CAS.lb||0)<CASTRO)return;return s0.apply(this,arguments)}}
{const c0=casTrack;casTrack=function(bet,pay){if(Math.floor(pay)===Math.floor(bet)&&P.as)P.as.cwc=0;return c0.apply(this,arguments)}}
/* Rocket: P(crash >= x) = .96/x for every x up to 1,000 */
function rkCrash(){if(typeof window.__rkcp==='number')return window.__rkcp;const u=g01();return Math.min(1000,Math.max(1,Math.floor(96/(1-u))/100))}
/* Tower Climb: no more boost day */
TW.BOOST_DAY='retired';
/* Slots */
SLP.crown=125;
/* Quiz Showdown */
QZ.CAP=1.5;QZ.MINP=4;
const qzDay=()=>{const t=dlLocal(new Date());let d=P.qzd;if(!d||typeof d!=='object'||d.d!==t)d=P.qzd={d:t,n:0};d.n=Math.max(0,Math.floor(+d.n||0));return d};
{const m0=QZ.mult;QZ.mult=function(s){const m=m0.call(QZ,s);return m>1&&qzDay().n>=QZD.full?1+(m-1)*QZD.k:m}}
{const p0=cPay;cPay=function(bet,pay){
  if(CAS.gid==='rk'&&pay>RKWIN){pay=RKWIN;try{setTimeout(()=>msg('Maximum payout reached: '+cmn(RKWIN)+'.','w'),0)}catch(e){}}
  if(CAS.gid==='qz'&&pay>bet)qzDay().n++;
  return p0.call(this,bet,pay)}}
/* texts */
try{const a=ACH.find(x=>x.id==='qz2x');if(a)a.d='Finish a Quiz Showdown with the top payout, 1.5x your stake.'}catch(e){}
try{const g=GAMES.find(x=>x.id==='qz');if(g)g.d='Pick clues from a category board and answer for points. Daily Double, Final Clue. Your score sets the payout (up to 1.5x; cash out after 4 clues). The first 5 winning quizzes each day pay in full.'}catch(e){}
try{const g=GAMES.find(x=>x.id==='rk');if(g)g.d+=' Max payout '+cmn(RKWIN)+' per round.'}catch(e){}
