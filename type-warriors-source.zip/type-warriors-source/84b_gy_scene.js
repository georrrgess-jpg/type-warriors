/* ---------- Monster Mash scenery: three graveyards (moonlit, harvest and witching hour) ---------- */
const gyBatShape=(c,x,y,s,fl,col)=>{c.save();c.translate(x,y);c.scale(s,s);c.fillStyle=col;const f=Math.sin(fl)*7;c.beginPath();c.moveTo(0,0);c.quadraticCurveTo(-6,-8-f,-18,-5-f);c.quadraticCurveTo(-13,-1,-12,3);c.quadraticCurveTo(-8,0,-5,5);c.quadraticCurveTo(-2,2,0,6);c.quadraticCurveTo(2,2,5,5);c.quadraticCurveTo(8,0,12,3);c.quadraticCurveTo(13,-1,18,-5-f);c.quadraticCurveTo(6,-8-f,0,0);c.fill();ell(c,0,-1,2.4,3,col);poly(c,[-2,-3,-1.2,-6,0,-3],col);poly(c,[2,-3,1.2,-6,0,-3],col);c.restore()};
/* one gravestone: kind 0 rounded slab, 1 cross, 2 obelisk, 3 celtic cross, 4 broken slab */
function gyStone(c,x,y,kind,s,col,hl,lean,moss){c.save();c.translate(x,y);c.rotate(lean);c.scale(s,s);
 c.fillStyle='#0006';c.beginPath();c.ellipse(4,2,26,6,0,0,TAU);c.fill();
 const body=()=>{c.beginPath();
  if(kind===0){c.moveTo(-18,0);c.lineTo(-18,-50);c.arc(0,-50,18,Math.PI,0);c.lineTo(18,0)}
  else if(kind===1){c.moveTo(-18,0);c.lineTo(-14,-14);c.lineTo(-5,-14);c.lineTo(-5,-44);c.lineTo(-16,-44);c.lineTo(-16,-54);c.lineTo(-5,-54);c.lineTo(-5,-72);c.lineTo(5,-72);c.lineTo(5,-54);c.lineTo(16,-54);c.lineTo(16,-44);c.lineTo(5,-44);c.lineTo(5,-14);c.lineTo(14,-14);c.lineTo(18,0)}
  else if(kind===2){c.moveTo(-16,0);c.lineTo(-13,-14);c.lineTo(-9,-14);c.lineTo(-7,-86);c.lineTo(0,-98);c.lineTo(7,-86);c.lineTo(9,-14);c.lineTo(13,-14);c.lineTo(16,0)}
  else if(kind===3){c.moveTo(-14,0);c.lineTo(-14,-18);c.lineTo(-6,-18);c.lineTo(-6,-40);c.lineTo(-18,-40);c.lineTo(-18,-54);c.lineTo(-6,-54);c.lineTo(-6,-64);c.lineTo(6,-64);c.lineTo(6,-54);c.lineTo(18,-54);c.lineTo(18,-40);c.lineTo(6,-40);c.lineTo(6,-18);c.lineTo(14,-18);c.lineTo(14,0)}
  else{c.moveTo(-18,0);c.lineTo(-18,-34);c.lineTo(-10,-40);c.lineTo(-6,-32);c.lineTo(2,-44);c.lineTo(8,-30);c.lineTo(18,-36);c.lineTo(18,0)}
  c.closePath()};
 body();c.fillStyle=col;c.fill();c.save();body();c.clip();
 c.fillStyle=hl+'55';c.fillRect(-20,-100,9,104);c.fillStyle='#00000040';c.fillRect(10,-100,12,104);
 c.fillStyle='#00000033';for(const [dx,dy,r] of[[-6,-30,5],[8,-18,4],[-10,-8,3]])c.beginPath(),c.arc(dx,dy,r,0,TAU),c.fill();
 if(moss){c.fillStyle='#3a6a3a88';c.beginPath();c.ellipse(-8,-2,16,7,0,0,TAU);c.fill();c.beginPath();c.ellipse(10,-6,8,5,0,0,TAU);c.fill()}
 c.strokeStyle='#00000066';c.lineWidth=1.6;if(kind===0||kind===4){c.beginPath();c.moveTo(-8,-36);c.lineTo(8,-36);c.moveTo(-6,-30);c.lineTo(6,-30);c.moveTo(-9,-24);c.lineTo(9,-24);c.stroke()}
 c.restore();body();c.strokeStyle='#000000a0';c.lineWidth=1.8;c.stroke();
 c.strokeStyle=hl+'88';c.lineWidth=1.2;c.beginPath();c.moveTo(-17,-2);c.lineTo(-17,-44);c.stroke();
 c.fillStyle=shade(col,-.4);for(let k=0;k<6;k++){const gx=-22+k*8;poly(c,[gx,2,gx+2,-9-(k%3)*3,gx+4,2],'#1a2a1a')}
 c.restore()}
MID.gstones=(c,x,i,d)=>{const col=shade(d.p,.16),hl=d.a;for(let k=0;k<5;k++){const r=rnd(i*13+k);gyStone(c,x-150+k*76+(r-.5)*26,GY+2-(k%2)*3,Math.floor(r*5),.9+rnd(i*7+k)*.55,shade(col,(r-.5)*.14),hl,(rnd(i*5+k)-.5)*.2,rnd(i+k)>.5)}};
MID.gangel=(c,x,i,d,t)=>{const col=shade(d.p,.18),hl=d.a;c.save();c.translate(x,GY);c.fillStyle='#0006';c.beginPath();c.ellipse(0,2,64,8,0,0,TAU);c.fill();
 c.fillStyle=shade(col,-.06);c.fillRect(-42,-34,84,34);c.fillStyle=shade(col,.06);c.fillRect(-36,-52,72,20);
 c.fillStyle=col;c.beginPath();c.moveTo(-26,-52);c.quadraticCurveTo(-36,-130,-14,-176);c.quadraticCurveTo(0,-190,14,-176);c.quadraticCurveTo(36,-130,26,-52);c.closePath();c.fill();
 c.fillStyle=shade(col,-.1);c.beginPath();c.moveTo(-20,-150);c.quadraticCurveTo(-96,-170,-110,-96);c.quadraticCurveTo(-70,-110,-62,-60);c.quadraticCurveTo(-40,-100,-22,-100);c.closePath();c.fill();
 c.beginPath();c.moveTo(20,-150);c.quadraticCurveTo(96,-170,110,-96);c.quadraticCurveTo(70,-110,62,-60);c.quadraticCurveTo(40,-100,22,-100);c.closePath();c.fill();
 c.fillStyle=shade(col,.1);c.beginPath();c.arc(0,-178,13,0,TAU);c.fill();c.fillStyle=col;c.beginPath();c.roundRect(-16,-170,32,28,8);c.fill();
 c.strokeStyle='#00000060';c.lineWidth=2;for(let k=0;k<4;k++){c.beginPath();c.moveTo(-18+k*12,-130);c.lineTo(-20+k*12,-56);c.stroke()}
 c.strokeStyle=hl+'66';c.lineWidth=1.6;c.beginPath();c.moveTo(-26,-60);c.quadraticCurveTo(-36,-130,-14,-176);c.stroke();
 const w=.5+.3*Math.sin(t*1.4+i);c.fillStyle=hl+Math.round(w*70).toString(16).padStart(2,'0');c.beginPath();c.ellipse(5,-150,3,5,0,0,TAU);c.fill();c.restore()};
MID.gtree=(c,x,i,d,t)=>{ptree(c,x,GY+6,-Math.PI/2+(rnd(i)-.5)*.3,100+rnd(i+2)*60,18,6,i*3.3+1,shade(d.p,-.1));
 for(let k=0;k<3;k++){const bx=x-34+k*30+rnd(i+k)*14,by=GY-170-rnd(i*3+k)*90;c.fillStyle='#07040c';c.beginPath();c.ellipse(bx,by,7,4.4,0,0,TAU);c.fill();c.beginPath();c.arc(bx+6,by-3,3,0,TAU);c.fill();poly(c,[bx+8,by-3,bx+13,by-2,bx+8,by-1],'#07040c');poly(c,[bx-6,by,bx-14,by+3,bx-5,by+3],'#07040c')}
 const lx=x+22,ly=GY-140;c.strokeStyle='#07040c';c.lineWidth=1.6;c.beginPath();c.moveTo(lx,ly-34);c.lineTo(lx,ly-8);c.stroke();const f=.8+.2*Math.sin(t*7+i);glow(c,lx,ly,46,d.a+Math.round(f*120).toString(16).padStart(2,'0'));c.fillStyle='#0a0612';c.fillRect(lx-6,ly-8,12,3);c.fillRect(lx-6,ly+10,12,3);c.fillStyle=d.a+'cc';c.fillRect(lx-4,ly-5,8,15);ell(c,lx,ly+3,2.4,4*f,'#fff6d0')};
MID.gfence=(c,x,i,d,t)=>{const col=shade(d.p,.05),n=14,w=22;c.strokeStyle=col;c.lineWidth=4;c.beginPath();c.moveTo(x-n*w/2,GY-52);c.lineTo(x+n*w/2,GY-52);c.moveTo(x-n*w/2,GY-18);c.lineTo(x+n*w/2,GY-18);c.stroke();
 for(let k=0;k<=n;k++){const bx=x-n*w/2+k*w;c.lineWidth=3.6;c.beginPath();c.moveTo(bx,GY+4);c.lineTo(bx,GY-96);c.stroke();poly(c,[bx-5,GY-94,bx,GY-112,bx+5,GY-94],col);c.fillStyle=col;c.fillRect(bx-4,GY-100,8,3)}
 for(const px of[-n*w/2,n*w/2]){c.fillStyle=shade(col,.06);c.fillRect(x+px-9,GY-132,18,134);c.fillRect(x+px-12,GY-138,24,8);ell(c,x+px,GY-146,9,9,shade(col,.06))}
 if(rnd(i+3)>.5){c.strokeStyle=col;c.lineWidth=4;c.beginPath();c.arc(x,GY-96,56,Math.PI,0);c.stroke();c.lineWidth=2.4;for(let k=0;k<5;k++){const a=Math.PI+k*Math.PI/4;c.beginPath();c.moveTo(x+Math.cos(a)*56,GY-96+Math.sin(a)*56);c.lineTo(x+Math.cos(a)*40,GY-96+Math.sin(a)*40);c.stroke()}}};
MID.gcryptb=(c,x,i,d,t)=>{const col=shade(d.p,.16);c.save();c.translate(x,GY);c.fillStyle='#0006';c.beginPath();c.ellipse(0,2,150,10,0,0,TAU);c.fill();
 for(let s=0;s<3;s++){c.fillStyle=shade(col,-.04*s);c.fillRect(-112+s*10,-12+s*4,224-s*20,12-s*4)}
 c.fillStyle=col;c.fillRect(-96,-150,192,138);c.fillStyle=shade(col,-.12);for(let r=0;r<6;r++)for(let k=0;k<8;k++){if((r+k)%2)c.fillRect(-96+k*24,-150+r*23,24,23)}
 c.fillStyle=shade(col,.1);poly(c,[-116,-150,0,-218,116,-150],col);poly(c,[-100,-152,0,-206,100,-152],shade(col,-.08));
 c.fillStyle=shade(col,.14);for(const s of[-72,-26,26,72])c.fillRect(s-8,-148,16,138);c.fillStyle=shade(col,.2);for(const s of[-72,-26,26,72]){c.fillRect(s-11,-152,22,7);c.fillRect(s-11,-14,22,6)}
 const o=.5+.5*Math.sin(t*1.3+i),dc='#04020a';c.fillStyle=dc;c.beginPath();c.roundRect(-18,-112,36,100,[18,18,0,0]);c.fill();glow(c,0,-60,90,d.a+Math.round(60+o*90).toString(16).padStart(2,'0'));
 c.fillStyle=d.a+'aa';c.beginPath();c.moveTo(-6,-12);c.lineTo(-18,-12);c.lineTo(-14,-100);c.lineTo(-8,-108);c.fill();
 c.strokeStyle='#000';c.lineWidth=2;c.beginPath();c.moveTo(0,-112);c.lineTo(0,-12);c.stroke();
 ell(c,0,-130,9,9,'#0a0612');c.fillStyle=col;c.fillRect(-20,-136,40,6);
 for(const s of[-1,1]){const gx=s*112;c.fillStyle=shade(col,.02);c.fillRect(gx-12,-60,24,60);c.fillRect(gx-16,-66,32,8);poly(c,[gx-12,-66,gx-8,-90,gx+8,-90,gx+12,-66],shade(col,.04));glow(c,gx,-56,58,d.a+'44');ell(c,gx,-56,5,12+Math.sin(t*8+s)*3,d.a);ell(c,gx,-55,2.4,6,'#fff')}
 for(const s of[-1,1]){const gx=s*108,gy=-150;c.fillStyle=shade(col,-.2);poly(c,[gx-12,gy,gx-6,gy-26,gx+6,gy-26,gx+12,gy],shade(col,-.2));ell(c,gx,gy-30,8,8,shade(col,-.2));poly(c,[gx-8,gy-34,gx-12,gy-48,gx-3,gy-36],shade(col,-.2));poly(c,[gx+8,gy-34,gx+12,gy-48,gx+3,gy-36],shade(col,-.2));ell(c,gx-2,gy-31,1.4,1.4,d.a);ell(c,gx+3,gy-31,1.4,1.4,d.a)}
 c.restore()};
MID.gscare=(c,x,i,d,t)=>{const col='#0a0610',sw=Math.sin(t*.9+i)*.03;c.save();c.translate(x,GY);c.rotate(sw);c.strokeStyle=col;c.lineWidth=7;c.lineCap='round';c.beginPath();c.moveTo(0,4);c.lineTo(0,-150);c.moveTo(-58,-110);c.lineTo(58,-110);c.stroke();
 c.fillStyle=col;poly(c,[-20,-112,20,-112,16,-60,-16,-60],col);for(let k=0;k<5;k++)poly(c,[-14+k*7,-62,-16+k*7,-46,-10+k*7,-62],col);
 for(const s of[-1,1])for(let k=0;k<4;k++)poly(c,[s*(50+k*3),-112,s*(70+k*2),-118+k*5,s*(56+k*3),-104],col);
 ell(c,0,-132,15,16,'#1a0e04');ell(c,0,-132,15,16,col);poly(c,[-24,-142,24,-142,12,-146,6,-176,-6,-176,-12,-146],col);ell(c,0,-146,26,5,col);
 const f=.6+.4*Math.sin(t*3+i);glow(c,-5,-132,22,d.a+Math.round(f*100).toString(16).padStart(2,'0'));poly(c,[-9,-134,-3,-134,-6,-139],d.a);poly(c,[2,-134,8,-134,5,-139],d.a);
 c.beginPath();c.ellipse(34,-122,8,5,0,0,TAU);c.fill();c.beginPath();c.arc(40,-126,3.4,0,TAU);c.fill();poly(c,[42,-126,48,-125,42,-123],col);c.restore()};
/* foreground */
NEAR.gtomb=(c,x,i,d)=>{const y=GY+78+rnd(i)*34;gyStone(c,x,y,Math.floor(rnd(i+4)*4),1.5+rnd(i+2)*.5,shade(d.p,.1),d.a,(rnd(i+7)-.5)*.2,true)};
NEAR.gpump=(c,x,i,d,t)=>{const y=GY+84+rnd(i)*30,f=.82+.18*Math.sin(t*9+i*2)+.05*Math.sin(t*21+i);c.save();c.translate(x,y);c.scale(1.45,1.45);glow(c,0,-12,68,'#ff8a1a'+Math.round(f*135).toString(16).padStart(2,'0'));
 ell(c,-17,-14,13,17,'#a8480e');ell(c,17,-14,13,17,'#b8500e');ell(c,-8,-14,18,20,'#cc6014');ell(c,9,-14,18,19.6,'#d86a18');ell(c,0,-14,19,20.4,rgr(c,-5,-22,2,28,'#f89a3a','#d86a18'));
 c.strokeStyle='#7a2a06aa';c.lineWidth=1.6;for(const dx of[-12,0,12]){c.beginPath();c.moveTo(dx*.4,-32);c.quadraticCurveTo(dx*1.6,-14,dx*.5,5);c.stroke()}
 poly(c,[-3,-32,-4,-42,2,-46,6,-42,4,-32],'#4a6a22');c.strokeStyle='#6a9a3a';c.lineWidth=1.6;c.beginPath();c.moveTo(5,-42);c.bezierCurveTo(12,-46,14,-38,9,-36);c.stroke();
 const gc=f>.9?'#fff0a0':'#ffd040';c.fillStyle=gc;poly(c,[-14,-17,-4,-17,-9,-27],gc);poly(c,[4,-17,14,-17,9,-27],gc);poly(c,[0,-13,-3,-8,3,-8],gc);c.fillStyle='#ffb020';c.beginPath();c.moveTo(-14,-6);c.lineTo(-10,-1);c.lineTo(-6,-5);c.lineTo(-2,0);c.lineTo(2,-5);c.lineTo(6,-1);c.lineTo(10,-5);c.lineTo(14,-1);c.lineTo(13,-8);c.quadraticCurveTo(0,6,-13,-8);c.closePath();c.fill();c.restore()};
NEAR.gfresh=(c,x,i,d,t)=>{const y=GY+96+rnd(i)*20;c.fillStyle='#0006';c.beginPath();c.ellipse(x,y+4,70,10,0,0,TAU);c.fill();c.fillStyle='#2a1a14';c.beginPath();c.moveTo(x-70,y+2);c.quadraticCurveTo(x-30,y-44,x+10,y-42);c.quadraticCurveTo(x+54,y-40,x+70,y+2);c.closePath();c.fill();c.fillStyle='#3a261c';c.beginPath();c.ellipse(x-10,y-22,34,12,-.1,0,TAU);c.fill();
 for(let k=0;k<7;k++){ell(c,x-50+k*16+rnd(i+k)*8,y-6-rnd(i+k+3)*18,4+rnd(i+k)*4,3,'#1a0e0a')}
 c.strokeStyle='#5a3a1e';c.lineWidth=5;c.lineCap='round';c.beginPath();c.moveTo(x+50,y+10);c.lineTo(x+34,y-70);c.stroke();c.fillStyle='#7a7e86';poly(c,[x+22,y-70,x+44,y-76,x+48,y-100,x+34,y-112,x+18,y-96],'#7a7e86');c.strokeStyle='#000a';c.lineWidth=1.4;c.stroke();
 c.strokeStyle='#8a6a42';c.lineWidth=5;c.beginPath();c.moveTo(x-34,y-8);c.lineTo(x-34,y-60);c.moveTo(x-48,y-44);c.lineTo(x-20,y-44);c.stroke()};
/* far hills, a chapel on the ridge and bats crossing the moon */
FAR.gyhill=(c,t,d)=>{
 for(let k=0;k<3;k++){c.fillStyle=shade(d.p,.2-k*.09);c.beginPath();c.moveTo(0,GY);for(let x=0;x<=W+40;x+=30){const o=x+t*(2+k*3);c.lineTo(x,GY-86-k*38-Math.sin(o*.0045+k*2.1)*46-Math.sin(o*.012+k)*14)}c.lineTo(W,GY);c.fill()}
 tile(t,d.manor||1500,3,(x,i)=>{const bx=x,by=GY-176,col=shade(d.p,.05);
  poly(c,[bx-110,by+60,bx-110,by-30,bx-96,by-30,bx-96,by-70,bx-80,by-96,bx-64,by-70,bx-64,by-30,bx-20,by-30,bx-20,by-90,bx,by-140,bx+20,by-90,bx+20,by-30,bx+60,by-30,bx+60,by-60,bx+76,by-84,bx+92,by-60,bx+92,by-24,bx+110,by-24,bx+110,by+60],col);
  c.fillRect(bx-4,by-170,8,36);c.fillRect(bx-12,by-160,24,6);
  for(const [wx,wy,ww] of[[-88,-58,7],[-44,-60,8],[34,-38,8],[84,-40,6],[-6,-84,7]]){const f=.55+.45*Math.sin(t*(2+rnd(i+wx)*3)+wx);const wc=d.win||d.a;glow(c,bx+wx,by+wy+8,26,wc+Math.round(f*70).toString(16).padStart(2,'0'));c.fillStyle=wc+Math.round(110+f*140).toString(16).padStart(2,'0');c.beginPath();c.roundRect(bx+wx-ww/2,by+wy-2,ww,16,[ww/2,ww/2,0,0]);c.fill()}
  ptree(c,bx-150,GY-120,-Math.PI/2,46,6,4,i*2+1,shade(d.p,.03));ptree(c,bx+160,GY-118,-Math.PI/2+.1,40,5,4,i*2+9,shade(d.p,.03))});
 for(let k=0;k<5;k++){const sp=22+k*7,x=W+80-((t*sp+k*410)%(W+240)),y=96+rnd(k+3)*130+Math.sin(t*1.3+k*2)*18;gyBatShape(c,x,y,.9-k*.06,t*9+k*2,'#05030a')}};
GRD.gyground=(c,t,d)=>{tile(t,30,70,(x,i)=>{for(let k=0;k<2;k++){const r=rnd(i*3+k),gx=x+r*24,gy=GY+10+rnd(i*3+k+40)*(H-GY-16);if(r>.62){c.strokeStyle=shade(d.g[0],.2);c.lineWidth=1.4;for(let b=-1;b<=1;b++){c.beginPath();c.moveTo(gx+b*2,gy);c.lineTo(gx+b*4,gy-5-r*8);c.stroke()}}else if(r>.4){c.fillStyle=(i%3?'#8a4a1a':'#a8681e')+'88';c.beginPath();c.ellipse(gx,gy,4,2,rnd(i+k)*3,0,TAU);c.fill()}else{c.fillStyle='#00000030';c.fillRect(gx,gy,3+rnd(i)*4,2)}}});
 tile(t,520,70,(x,i)=>{if(rnd(i+11)>.5)return;c.fillStyle='#00000026';c.beginPath();c.ellipse(x,GY+44+rnd(i)*40,90,10,0,0,TAU);c.fill();if(rnd(i+4)>.6){c.fillStyle='#d8d0b0';c.fillRect(x-14,GY+52,28,4);ell(c,x-16,GY+54,4,4,'#d8d0b0');ell(c,x+16,GY+54,4,4,'#d8d0b0')}})};
const _wx1=weather;
weather=function(type,t,a){if(type==='fireflies'){const c=ctx;c.save();for(let i=0;i<30;i++){const x=(rnd(i)*W+Math.sin(t*.4+i)*80+t*6*(rnd(i+3)-.4))%W,y=GY-30-rnd(i+8)*300+Math.sin(t*.9+i*2)*24,f=Math.max(0,Math.sin(t*1.6+i*1.7));c.globalAlpha=f*.9;glow(c,x,y,16,'#d8ff7a');ell(c,x,y,1.8,1.8,'#f4ffb0')}c.restore();return}
 if(type==='leaves'){const c=ctx;c.save();for(let i=0;i<46;i++){const u=(t*(.05+rnd(i)*.06)+rnd(i+5))%1,x=((rnd(i+2)*W*1.3+t*(26+rnd(i+4)*30)+Math.sin(t*.8+i)*30)%(W*1.3))-80,y=-20+u*(H+40);c.save();c.translate(x,y);c.rotate(t*(1+rnd(i))+i);c.globalAlpha=.55+.4*rnd(i+1);c.fillStyle=['#c8501a','#e8801e','#9a3a10','#d8a030'][i%4];c.beginPath();c.moveTo(0,-6);c.quadraticCurveTo(7,-2,0,7);c.quadraticCurveTo(-7,-2,0,-6);c.fill();c.restore()}c.restore();return}
 if(type==='gybats'){const c=ctx;c.save();for(let k=0;k<7;k++){const sp=70+k*14,ph=(t*sp+k*370)%(W+500),x=W+120-ph,y=60+rnd(k+3)*250+Math.sin(t*2.2+k)*30;if(rnd(Math.floor((t*sp+k*370)/(W+500))*7+k)>.55)continue;c.globalAlpha=.9;gyBatShape(c,x,y,1.1+rnd(k)*.5,t*11+k*2,'#05030a')}c.restore();_wx1('motes',t,a);return}
 _wx1(type,t,a)};
SCN[32]={sky:['#04080f','#17403c'],stars:100,moon:[W*.22,190,74,'#e8fff4','#7affc866'],far:'gyhill',manor:1700,win:'#b8ffe0',p:'#07141a',a:'#7affc8',mid:[['gstones',470,12,.12],['gangel',1320,9,.5],['gtree',760,14,.45],['gfence',700,10,.55]],g:['#142822','#050c0c','#7affc833'],gt:'gyground',near:[['gtomb',320,70,.25],['candle',560,70,.55]],wx:'fireflies',haze:'#5affd022',fog:'#5affd01c'};
SCN[33]={sky:['#14080a','#843c16'],stars:30,moon:[W*.74,236,98,'#ffd48a','#ff8a3a77'],far:'gyhill',manor:1500,win:'#ffb040',p:'#1a0c0a',a:'#ffa030',mid:[['gstones',480,12,.1],['gfence',640,10,.25],['gtree',800,16,.4],['gscare',1500,10,.5]],g:['#2a1a12','#0e0806','#ffa03044'],gt:'gyground',near:[['gpump',280,70,.25],['gtomb',430,70,.35],['gfresh',1100,70,.6]],wx:'leaves',haze:'#ff8a2a24',fog:'#ff8a2a14'};
SCN[34]={sky:['#0a0414','#3e165c'],stars:80,moon:[W*.5,214,116,'#f2e4ff','#c86bff77'],far:'gyhill',manor:1400,win:'#d8a0ff',p:'#10061c',a:'#c86bff',mid:[['gcryptb',760,12,.2],['gstones',470,12,.12],['gangel',1150,9,.45],['gfence',700,10,.4]],g:['#1c1228','#08040e','#c86bff44'],gt:'gyground',near:[['gtomb',300,70,.25],['candle',460,70,.5]],wx:'gybats',haze:'#a03aff24',fog:'#a03aff18',top:'#030008'};
const GYLV=[
 {i:32,n:'Moonlit Boneyard',z:0,tint:'#7affc8',sky:['#04080f','#17403c'],wx:'fireflies',prop:'',m:['gyshamble','gywisp','gywitch'],b:'bhorse',bn:'Headless Horseman',bl:'the headless horseman',pl:'the boneyard',hue:0,blurb:'',a:'#7affc8'},
 {i:33,n:'Harvest Hollow',z:0,tint:'#ffa030',sky:['#14080a','#843c16'],wx:'leaves',prop:'',m:['gyjack','gyghost','gybrute'],b:'bpumpking',bn:'The Pumpkin King',bl:'the pumpkin king',pl:'harvest hollow',hue:0,blurb:'',a:'#ffa030'},
 {i:34,n:'Witching Hour',z:0,tint:'#c86bff',sky:['#0a0414','#3e165c'],wx:'gybats',prop:'',m:['gydigger','gycat','gyvamp'],b:'bhexmire',bn:'Mother Hexmire',bl:'mother hexmire',pl:'the witching hour',hue:0,blurb:'',a:'#c86bff'}];
