/* ===== RUNESTONE RIDDLE (8.4): the new daily mode that replaces the Daily Challenge =====
   One hidden five-letter word a day, the same for everyone on the same local date (seeded order over RR_ANS, riddle #1 is
   Thursday 22 October 2026). Six tries; green rune = right letter, right place; gold = right letter, wrong place.
   Payout falls with every guess (RR_PAY); a failed riddle still pays a small consolation. Rune powers (once each per riddle):
   Reveal shows one letter in place, Shatter crosses out three wrong letters; each costs coins and trims that day's payout.
   Streak: +500 coins on every 7th day in a row, and the Riddlemaster title at 30 days. Practice riddles are unlimited, free and pay nothing.
   Save: P.rr = {d:{'YYYY-MM-DD':{g:[guesses],st:'p'|'w'|'l',c:coins,cb:bonus,pw:{r,s},rv:[[i,l]],sh:[letters]}},st,best,last,wins,pl,dist[6],ttl,
   pr:{cur,wins,pl,dist,st,best}}. The board is kept between visits, so leaving never rerolls a riddle.
   Look: an indigo night, a carved graphite runestone with serif runes, an indigo glass side panel with a streak calendar, and a keyboard.
   Motion is transform and opacity only (pop, flip, shake, bounce, coin flight); the win burst is a short-lived canvas with no shadowBlur or filter. */
const RR_PAY=[1500,900,500,300,180,120],RR_FAIL=25,RR_CUT=.15,RR_BONUS7=500,RR_TITLE_DAYS=30;
const RR_POW={r:{n:'Reveal',cost:100,d:'Show one rune in place',l:'Shows one hidden rune in its place.'},s:{n:'Shatter',cost:60,d:'Clear 3 wrong letters',l:'Crosses out three letters that are not in the word.'}};
const RR_PRAISE=['Flawless!','Brilliant!','Splendid!','Great work!','Nicely done!','Phew!'];
const RR_GLY=['M4 2v20M4 6l8-4M4 12l8-4','M5 2v20M5 3l7 7-7 7','M4 22 12 2l8 20M7 14h10','M6 2v20M18 2v20M6 12h12M6 6l12 12'].map((d,i)=>`<svg class="g${i}" viewBox="0 0 24 24"><path d="${d}"/></svg>`).join('');
const RR_SAY={c:'right place',p:'in the word, wrong place',a:'not in the word'};
const RR_KB=['qwertyuiop','asdfghjkl','zxcvbnm'];
let RR=null;
const RRP=()=>{const R=P.rr||(P.rr={});R.d=R.d||{};R.st=R.st||0;R.best=R.best||0;R.last=R.last||'';R.wins=R.wins||0;R.pl=R.pl||0;R.dist=R.dist||[0,0,0,0,0,0];R.ttl=R.ttl||0;
 R.pr=R.pr||{};const Q=R.pr;Q.cur=Q.cur||null;Q.wins=Q.wins||0;Q.pl=Q.pl||0;Q.dist=Q.dist||[0,0,0,0,0,0];Q.st=Q.st||0;Q.best=Q.best||0;return R};
const rrKey=(d=new Date())=>dlLocal(d);
const rrDate=k=>{const [y,m,d]=k.split('-').map(Number);return new Date(y,m-1,d)};
const rrIdx=k=>{const [y,m,d]=k.split('-').map(Number);return Math.round((Date.UTC(y,m-1,d)-Date.UTC(2026,9,22))/864e5)};
const rrNum=k=>rrIdx(k)+1;
const rrPrev=k=>{const d=rrDate(k);d.setDate(d.getDate()-1);return rrKey(d)};
let RR_ORD=null;
function rrOrder(){if(RR_ORD)return RR_ORD;const a=RR_ANS.slice();let s=8403>>>0;const r=()=>{s=s+0x6D2B79F5|0;let t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296};
 for(let i=a.length-1;i>0;i--){const j=Math.floor(r()*(i+1));const x=a[i];a[i]=a[j];a[j]=x}return RR_ORD=a}
const rrWord=k=>{const o=rrOrder(),n=o.length;return o[((rrIdx(k)%n)+n)%n]};
function rrScore(g,w){const r=['a','a','a','a','a'],cnt={};for(let i=0;i<5;i++){if(g[i]===w[i])r[i]='c';else cnt[w[i]]=(cnt[w[i]]||0)+1}
 for(let i=0;i<5;i++)if(r[i]!=='c'&&cnt[g[i]]>0){r[i]='p';cnt[g[i]]--}return r}
const rrDone=k=>{const e=RRP().d[k||rrKey()];return!!(e&&e.st&&e.st!=='p')};
const rrStreak=()=>{const R=RRP();if(!R.last)return 0;const t=rrKey();return(R.last===t||R.last===rrPrev(t))?R.st:0};
const rrPay=(n,pw)=>Math.max(5,Math.round(RR_PAY[n-1]*(1-RR_CUT*((pw&&pw.r?1:0)+(pw&&pw.s?1:0)))/5)*5);
const rrRM=()=>{try{return ccReduce()}catch(e){return false}};
const rrFmt=n=>Math.round(n).toLocaleString('en-US');
const rrSfx=(k,i)=>{try{if(k==='key')beep(640+Math.random()*60,.03,'triangle',.06);else if(k==='del')beep(420,.03,'triangle',.05);
 else if(k==='c')beep(880+i*70,.12,'sine',.16);else if(k==='p')beep(620+i*40,.11,'triangle',.13);else if(k==='a')beep(300,.07,'sine',.08);
 else if(k==='bad'){beep(180,.09,'square',.05);setTimeout(()=>beep(150,.1,'square',.05),90)}
 else if(k==='win')[[784,0],[988,90],[1175,180],[1568,300],[1976,430]].forEach(([f,d])=>setTimeout(()=>{beep(f,.22,'sine',.22);beep(f*1.5,.1,'triangle',.08)},d));
 else if(k==='lose')[[392,0],[330,180],[262,380]].forEach(([f,d])=>setTimeout(()=>beep(f,.26,'triangle',.14),d));
 else if(k==='pow')[[1046,0],[1568,80],[2093,170]].forEach(([f,d])=>setTimeout(()=>beep(f,.14,'sine',.14),d));
 else if(k==='coin')beep(1318+Math.random()*300,.05,'triangle',.1)}catch(e){}};
/* the riddle being played: daily entry or the current practice riddle */
function rrCur(){const R=RRP();if(RR.mode==='p'){if(!R.pr.cur){const o=rrOrder(),n=o.length,b=((rrIdx(rrKey())%n)+n)%n,rec=R.pr.rec||(R.pr.rec=[]);let w,t=0;do{w=o[(b+366+Math.floor(Math.random()*(n-366)))%n]}while(rec.includes(w)&&++t<40);rec.push(w);if(rec.length>60)rec.shift();R.pr.cur={w,g:[],st:'p',pw:{r:0,s:0},rv:[],sh:[]}}return R.pr.cur}
 const k=RR.key||rrKey();const e=R.d[k]||(R.d[k]={g:[],st:'p',pw:{r:0,s:0},rv:[],sh:[]});e.w=rrWord(k);e.pw=e.pw||{r:0,s:0};e.rv=e.rv||[];e.sh=e.sh||[];return e}
function rrKeyStates(e){const m={};const rank={c:3,p:2,a:1};e.g.forEach(g=>{const s=rrScore(g,e.w);for(let i=0;i<5;i++){const l=g[i];if(!m[l]||rank[s[i]]>rank[m[l]])m[l]=s[i]}});
 (e.sh||[]).forEach(l=>{if(!m[l])m[l]='a'});(e.rv||[]).forEach(([i,l])=>{m[l]='c'});return m}
const rrLeft=()=>{const n=new Date(),t=new Date(n.getFullYear(),n.getMonth(),n.getDate()+1),s=Math.max(0,Math.floor((t-n)/1000));return`${Math.floor(s/3600)}h ${String(Math.floor(s%3600/60)).padStart(2,'0')}m`};
/* ---------- open ---------- */
function rrMenu(back,mode){RR={key:rrKey(),mode:mode||RR&&RR.mode||'d',back:typeof back==='function'?back:(RR&&RR.back)||title,cur:'',busy:false,tk:(RR&&RR.tk||0)+1};
 RRP();S.view='riddle';const e=rrCur();
 show(`<div class="rr${rrRM()?' rr-rm':''}" id="rr">
 <div class="rrsky" aria-hidden="true"><i></i><i></i><i></i></div>
 <header class="rrhd">
  <button class="rrbk" id="rrbk" aria-label="Back"><span aria-hidden="true">‹</span> Back</button>
  <div class="rrti"><h1>Runestone Riddle</h1><p>One hidden five-letter word a day, carved into a runestone. Six tries, green and gold runes for hints, and a streak calendar that pays coins.</p></div>
  <div class="rrtabs" role="tablist" aria-label="Riddle type"><button role="tab" data-m="d" aria-selected="${RR.mode==='d'}">Daily riddle</button><button role="tab" data-m="p" aria-selected="${RR.mode==='p'}">Practice</button></div>
  <div class="rrgold" id="rrgold" title="Your coins"><span class="rrcn" aria-hidden="true"></span><b id="rrgv" data-v="${P.gold}">${rrFmt(P.gold)}</b></div>
 </header>
 <div class="rrmain">
  <section class="rrboard" aria-label="Runestone">
   <div class="rrslab" id="rrslab"><div class="rrtoast" id="rrtoast" role="status" aria-live="polite"></div><div class="rrcarve" aria-hidden="true"></div><div class="rrglyph" aria-hidden="true">${RR_GLY}</div><div class="rrgrid" id="rrgrid" role="grid" aria-label="Your guesses"></div></div>
   <div class="rrpow" id="rrpow"></div>
   <p class="rrleg" id="rrleg"></p>
  </section>
  <section class="rrside">
   <div class="rrpanel" id="rrpanel"></div>
   <div class="rrkb" id="rrkb" aria-label="Keyboard"></div>
  </section>
 </div>
 <div class="rrres" id="rrres" hidden></div>
 <canvas class="rrfx" id="rrfx" aria-hidden="true"></canvas>
</div>`,'rrx nosb');
 S.view='riddle';S.back=rrBack;try{const c=$('cn');if(c)c.classList.add('dkhid')}catch(x){}
 $('rrbk').onclick=rrBack;
 ov.querySelectorAll('.rrtabs [data-m]').forEach(b=>b.onclick=()=>{b.blur();if(RR.busy||b.dataset.m===RR.mode)return;rrSfx('key');RR.mode=b.dataset.m;RR.cur='';rrSwap()});
 rrFit();rrBuildBoard(e,true);rrPanel();rrPowers();rrKeys();rrLegend();rrTick()}
/* size from the overlay itself: the game draws on a scaled 1600x900 stage, and touch layouts can resize the overlay */
function rrFit(){const r=$('rr');if(!r)return;const W=ov.clientWidth||1600,H=ov.clientHeight||900,nar=W<1100,tiny=W<700,sh=H<860;
 r.classList.toggle('rr-narrow',nar);r.classList.toggle('rr-tiny',tiny);r.classList.toggle('rr-short',sh);
 const t=nar?Math.min(64,(W-64)/6.4,Math.max(44,(H-300)/6.6)):Math.min(68,(H-(sh?250:300))/6.9,(W-48)/6.6);r.style.setProperty('--t',Math.max(34,Math.floor(t))+'px');
 r.style.setProperty('--k',Math.max(26,Math.min(tiny?56:50,Math.floor((Math.min(W,tiny?700:640)-(tiny?40:64))/10.6)))+'px')}
addEventListener('resize',()=>{if(RR&&$('rr'))rrFit()});
function rrBack(){const m=$('rrres');if(m&&!m.hidden){rrResClose();return}if(RR&&RR.busy)return;const b=RR?RR.back:title;RR=null;b();try{dkCorner()}catch(x){}}
function rrSwap(){ov.querySelectorAll('.rrtabs [data-m]').forEach(b=>b.setAttribute('aria-selected',b.dataset.m===RR.mode));const e=rrCur();
 const sl=$('rrslab');sl.classList.remove('rrswap');void sl.offsetWidth;sl.classList.add('rrswap');rrBuildBoard(e,true);rrPanel();rrPowers();rrKeys();rrLegend()}
/* ---------- the board ---------- */
function rrBuildBoard(e,intro){const G=$('rrgrid');let h='';for(let r=0;r<6;r++){h+=`<div class="rrrw" role="row" data-r="${r}" style="--r:${r}">`;for(let c=0;c<5;c++)h+=`<div class="rrt" role="gridcell" data-c="${c}" style="--i:${c}"><b></b></div>`;h+='</div>'}
 G.innerHTML=h;if(intro&&!rrRM()){G.classList.remove('rrin');void G.offsetWidth;G.classList.add('rrin')}
 e.g.forEach((g,r)=>{const s=rrScore(g,e.w);rrRow(r).forEach((t,i)=>{t.querySelector('b').textContent=g[i];t.classList.add('f',s[i]);t.setAttribute('aria-label',g[i].toUpperCase()+', '+RR_SAY[s[i]])})});
 if(e.st==='w'){const r=e.g.length-1;rrRow(r).forEach(t=>t.classList.add('won'))}
 const sl=$('rrslab');if(sl){sl.classList.toggle('awake',e.st==='w');sl.classList.toggle('dim',e.st==='l')}
 rrTyping()}
const rrRow=r=>[...ov.querySelectorAll(`#rrgrid .rrrw[data-r="${r}"] .rrt`)];
function rrTyping(){const e=rrCur(),r=e.g.length;if(e.st!=='p'||r>5){ov.querySelectorAll('#rrgrid .rrrw').forEach(w=>w.classList.remove('now'));return}
 ov.querySelectorAll('#rrgrid .rrrw').forEach(w=>w.classList.toggle('now',+w.dataset.r===r));
 const gh={};(e.rv||[]).forEach(([i,l])=>gh[i]=l);
 for(let rr=r;rr<6;rr++)rrRow(rr).forEach((t,i)=>{const l=rr===r?RR.cur[i]||'':'';const b=t.querySelector('b');b.textContent=l;t.classList.toggle('f',!!l);
  const g=!l&&gh[i]&&(rr===r)?gh[i]:'';t.classList.toggle('gh',!!g);if(g)t.dataset.gh=g;else delete t.dataset.gh;t.classList.toggle('cur',rr===r&&i===RR.cur.length)})}
function rrType(l){const e=rrCur();if(e.st!=='p'||RR.cur.length>=5||RR.busy&&RR.res&&RR.res.fin)return;RR.cur+=l;rrTyping();const t=rrRow(e.g.length)[RR.cur.length-1];if(t&&!rrRM()){t.classList.remove('pop');void t.offsetWidth;t.classList.add('pop')}rrSfx('key')}
function rrDel(){const e=rrCur();if(e.st!=='p'||!RR.cur.length)return;RR.cur=RR.cur.slice(0,-1);rrTyping();rrSfx('del')}
function rrToast(m,ms){const t=$('rrtoast');if(!t)return;const mo=$('rrres'),host=mo&&!mo.hidden&&mo.querySelector('.rrrc')||$('rrslab');if(host&&t.parentNode!==host)host.appendChild(t);t.textContent=m;t.classList.remove('on');void t.offsetWidth;t.classList.add('on');clearTimeout(rrToast.h);rrToast.h=setTimeout(()=>t.classList.remove('on'),ms||1700)}
function rrShake(){const e=rrCur(),w=ov.querySelector(`#rrgrid .rrrw[data-r="${e.g.length}"]`);if(!w)return;w.classList.remove('shk');void w.offsetWidth;w.classList.add('shk')}
function rrEnter(){const e=rrCur();if(RR.busy||e.st!=='p')return;const g=RR.cur;
 if(g.length<5){rrShake();rrSfx('bad');rrToast('Not enough runes. A riddle word has five letters.');return}
 if(!rrValid(g)){rrShake();rrSfx('bad');rrToast(`“${g.toUpperCase()}” is not in the rune lexicon.`);return}
 if(e.g.includes(g)){rrShake();rrSfx('bad');rrToast('You already carved that word.');return}
 const r=e.g.length,s=rrScore(g,e.w);e.g.push(g);RR.cur='';RR.res=null;const win=g===e.w,lose=!win&&e.g.length>=6;if(win||lose)e.st=win?'w':'l';save();
 RR.busy=true;const T=rrRow(r),rm=rrRM(),step=rm?0:270,half=rm?0:250;ov.querySelector(`#rrgrid .rrrw[data-r="${r}"]`).classList.remove('now');
 T.forEach((t,i)=>{t.classList.remove('cur','gh','pop');if(!rm)t.classList.add('flip');setTimeout(()=>{t.classList.add(s[i]);t.setAttribute('aria-label',g[i].toUpperCase()+', '+RR_SAY[s[i]]);rrSfx(s[i],i)},i*step+half)});
 setTimeout(()=>{RR.busy=false;rrKeys(true);rrPowers();T.forEach(t=>t.classList.remove('flip'));
  if(win||lose)rrFinish(win);else{rrTyping();rrPanel(true)}},4*step+half*2+60)}
/* ---------- finishing a riddle ---------- */
function rrFinish(win){const R=RRP(),e=rrCur(),n=e.g.length,daily=RR.mode==='d';let res={win,n,base:0,cut:0,bonus:0,tot:0,title:0};
 if(daily){const k=RR.key;R.pl++;if(win){R.wins++;R.dist[n-1]++;R.st=(R.last===rrPrev(k)||R.last===k)?R.st+1:1;R.last=k;R.best=Math.max(R.best,R.st);
   res.base=RR_PAY[n-1];res.tot=rrPay(n,e.pw);res.cut=res.base-res.tot;if(R.st%7===0){res.bonus=RR_BONUS7;res.tot+=RR_BONUS7}
   if(R.st>=RR_TITLE_DAYS&&!R.ttl){R.ttl=1;res.title=1;try{const B=BTY();B.own['t:riddlemaster']=1}catch(x){}}
   try{btyAdd('daily',1)}catch(x){}}
  else{R.st=0;res.base=RR_FAIL;res.tot=RR_FAIL}
  e.c=res.tot;e.cb=res.bonus;P.gold+=res.tot;try{stat('gold',res.tot,'add')}catch(x){}}
 else{const Q=R.pr;Q.pl++;if(win){Q.wins++;Q.dist[n-1]++;Q.st++;Q.best=Math.max(Q.best,Q.st)}else Q.st=0}
 save();RR.res=res;
 const sl0=$('rrslab');if(sl0)sl0.classList.add(win?'awake':'dim');
 if(win){rrSfx('win');const T=rrRow(n-1);if(!rrRM())T.forEach((t,i)=>setTimeout(()=>t.classList.add('won'),i*90));else T.forEach(t=>t.classList.add('won'));setTimeout(()=>rrBurst(T),rrRM()?0:420)}
 else{rrSfx('lose');const sl=$('rrslab');if(!rrRM()){sl.classList.remove('rrq');void sl.offsetWidth;sl.classList.add('rrq')}}
 RR.busy=true;rrPanel(true);rrPowers();rrLegend();setTimeout(()=>{if(RR&&$('rr'))rrResult(true);if(RR)RR.busy=false},win?(rrRM()?200:1250):(rrRM()?200:950))}
/* ---------- the side panel ---------- */
const RR_DAYS=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
function rrPanel(upd){const R=RRP(),el=$('rrpanel');if(!el)return;const k=RR.key,d=rrDate(k),e=rrCur();
 if(RR.mode==='p'){const Q=R.pr,pct=Q.pl?Math.round(Q.wins/Q.pl*100):0,mx=Math.max(1,...Q.dist);
  el.innerHTML=`<p class="rrey">Practice riddles <u>·</u> No coins, no pressure</p>
  <div class="rrstats"><div><b class="g">${Q.wins}</b><small>Solved</small></div><div><b class="m">${Q.st}</b><small>Win streak</small></div><div><b>${Q.pl?pct+'%':'–'}</b><small>Win rate</small></div></div>
  <p class="rrey">Guess spread</p><div class="rrdist">${Q.dist.map((v,i)=>`<div class="rrdr${e.st==='w'&&e.g.length===i+1?' me':''}"><span>${i+1}</span><i style="--w:${(v/mx).toFixed(3)}"><em>${v}</em></i></div>`).join('')}</div>
  <p class="rrnote">Practice riddles use a random word and never change your daily streak. Rune powers are free here.${e.st!=='p'?'':' Finish this one, or start fresh:'}</p>
  <button class="rrbtn rrnew" id="rrnew">${e.st==='p'?'Skip to a new riddle':'New practice riddle'} <i>›</i></button>`;
  $('rrnew').onclick=()=>{if(RR.busy)return;const c=R.pr.cur;if(c&&c.st==='p'&&c.g.length){if(!$('rrnew').dataset.ok){$('rrnew').dataset.ok=1;$('rrnew').innerHTML='Tap again to give up this riddle';return}Q.pl++;Q.st=0}R.pr.cur=null;RR.cur='';save();rrSwap()};
  return}
 const st=rrStreak(),wins=R.wins,avg=wins?(R.dist.reduce((a,v,i)=>a+v*(i+1),0)/wins).toFixed(1):'–',ce=R.d[k],coins=ce&&ce.st!=='p'?ce.c||0:null,n=e.g.length;
 const nx=e.st==='p'?Math.min(5,n):-1;
 const ym=k.slice(0,7),dim=new Date(d.getFullYear(),d.getMonth()+1,0).getDate();let cal='';
 for(let i=1;i<=dim;i++){const kk=ym+'-'+String(i).padStart(2,'0'),en=R.d[kk],fut=kk>k,pre=rrIdx(kk)<0&&!en;let c='rrcd',t='';
  if(kk===k)c+=' td';if(en&&en.st==='w'){c+=' w';t=`Solved in ${en.g.length} · +${rrFmt(en.c||0)} coins`}else if(en&&en.st==='l'){c+=' l';t='The rune stayed hidden'}else if(fut)c+=' fu';else if(kk!==k){c+=pre?' pre':' ms';t=pre?'Before the first riddle':'Missed'}
  if(kk===k&&!t)t='Today';cal+=`<span class="${c}" style="--i:${i}" title="${t}">${i}</span>`}
 const nb=7-(st%7);
 el.innerHTML=`<p class="rrey">Today <u>·</u> ${RR_DAYS[d.getDay()]} ${d.getDate()} ${DL_MONTHS[d.getMonth()]}${rrIdx(k)>=0?` <u>·</u> Riddle #${rrNum(k)}`:' <u>·</u> Preview'}</p>
 <div class="rrstats"><div><b class="m" data-cu="${st}">${st}</b><small>Day streak</small></div><div><b class="g">${coins==null?'up to '+rrFmt(rrPay(Math.max(1,n+1),e.pw)):'+'+rrFmt(coins)}</b><small>Coins today</small></div><div><b>${avg}</b><small>Avg guesses</small></div></div>
 <p class="rrey">Fewer guesses, bigger payout${e.pw.r||e.pw.s?` <u>·</u> <span class="rrcutn">−${Math.round(RR_CUT*100*((e.pw.r?1:0)+(e.pw.s?1:0)))}% rune powers</span>`:''}</p>
 <div class="rrlad">${RR_PAY.map((v,i)=>{let c='rrlp';if(e.st==='w'&&n===i+1)c+=' hit';else if(e.st==='p'&&i===nx)c+=' nx';else if(i<n||e.st!=='p')c+=' gone';return`<span class="${c}"><small>${['1st','2nd','3rd','4th','5th','6th'][i]}</small><b>${rrFmt(rrPay(i+1,e.pw))}</b></span>`}).join('')}</div>
 <p class="rrey">${DL_MONTHS[d.getMonth()]}</p><div class="rrcal${upd?'':' rrcin'}">${cal}</div>
 <p class="rrbon">Streak bonuses: every <b>7 days</b> +${RR_BONUS7} coins${st?` (next in ${nb} day${nb===1?'':'s'})`:''}, <b>${RR_TITLE_DAYS} days</b> the <em>Riddlemaster</em> title${R.ttl?' ✓':''}.</p>`}
/* ---------- rune powers ---------- */
function rrPowers(){const el=$('rrpow');if(!el)return;const e=rrCur(),pr=RR.mode==='p',done=e.st!=='p';
 const known=new Set();e.g.forEach(g=>{for(let i=0;i<5;i++)if(g[i]===e.w[i])known.add(i)});(e.rv||[]).forEach(([i])=>known.add(i));
 const ks=rrKeyStates(e),wrong=[...'abcdefghijklmnopqrstuvwxyz'].filter(l=>!e.w.includes(l)&&!ks[l]);
 const can={r:!done&&!e.pw.r&&known.size<5,s:!done&&!e.pw.s&&wrong.length>0};
 const fr=pr?0:(RRP().free||0);el.innerHTML=Object.keys(RR_POW).map(k=>{const p=RR_POW[k],used=e.pw[k],cost=pr||fr>0?0:p.cost,poor=P.gold<cost;
  return`<button class="rrpb rrp-${k}${used?' used':''}" data-pw="${k}" ${!can[k]||poor?'disabled':''} title="${esc(p.l)}"><span class="rrpi" aria-hidden="true">${k==='r'?RR_EYE:RR_BOLT}</span><span class="rrpt"><b>${p.n}<span class="rrpc">${used?'✓ Used':pr?'Free':fr>0?'Charm':`<i class="rrcn"></i>${cost}`}</span></b><small>${used?'Used on this riddle':pr?p.d+' · free in practice':fr>0?p.d+` · ${fr} Rune Charm${fr>1?'s':''} left`:poor?'Need '+cost+' coins':p.d}</small></span></button>`}).join('')
  +`<p class="rrpn">${pr?'Each power works once per riddle.':`Each power works once per riddle and trims today's payout by ${Math.round(RR_CUT*100)}%.`}</p>`;
 el.querySelectorAll('[data-pw]').forEach(b=>b.onclick=()=>rrUse(b.dataset.pw))}
const RR_EYE='<svg viewBox="0 0 24 24"><path d="M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12z" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round"/><circle cx="12" cy="12" r="3.4" fill="currentColor"/></svg>';
const RR_BOLT='<svg viewBox="0 0 24 24"><path d="M13.5 2 5 13.5h6L9.5 22 19 9.8h-6.2z" fill="currentColor" stroke="#12081f" stroke-width="1.2" stroke-linejoin="round"/></svg>';
function rrUse(k){const e=rrCur();if(RR.busy||e.st!=='p'||e.pw[k])return;const pr=RR.mode==='p',Rr=RRP(),ch=!pr&&(Rr.free||0)>0,cost=pr||ch?0:RR_POW[k].cost;if(P.gold<cost)return;if(ch)Rr.free--;
 if(k==='r'){const known=new Set();e.g.forEach(g=>{for(let i=0;i<5;i++)if(g[i]===e.w[i])known.add(i)});const op=[0,1,2,3,4].filter(i=>!known.has(i));if(!op.length)return;
  const i=op[Math.floor(Math.random()*op.length)];e.rv.push([i,e.w[i]]);rrToast(`Reveal: the rune “${e.w[i].toUpperCase()}” sits in place ${i+1}.`,2400)}
 else{const ks=rrKeyStates(e),wr=[...'abcdefghijklmnopqrstuvwxyz'].filter(l=>!e.w.includes(l)&&!ks[l]);if(!wr.length)return;
  for(let j=wr.length-1;j>0;j--){const q=Math.floor(Math.random()*(j+1));[wr[j],wr[q]]=[wr[q],wr[j]]}const pick=wr.slice(0,3);e.sh.push(...pick);
  rrToast(`Shatter: ${pick.map(l=>l.toUpperCase()).join(', ')} ${pick.length>1?'are':'is'} not in the word.`,2400);RR.shat=pick}
 e.pw[k]=1;if(cost){P.gold-=cost;rrGold()}save();rrSfx('pow');
 const b=ov.querySelector(`[data-pw="${k}"]`);if(b&&!rrRM()){b.classList.add('fire')}
 setTimeout(()=>{if(!RR||!$('rr'))return;rrPowers();rrKeys(true);rrTyping();rrPanel(true);
  if(k==='r'){const t=ov.querySelector('#rrgrid .rrt.gh');if(t&&!rrRM()){t.classList.add('ghin')}}},rrRM()?0:260)}
/* ---------- keyboard ---------- */
function rrKeys(anim){const el=$('rrkb');if(!el)return;const e=rrCur(),ks=rrKeyStates(e),old=RR.ks||{},sh=RR.shat||[];RR.shat=null;
 el.innerHTML=RR_KB.map((row,ri)=>`<div class="rrkr">${ri===2?'<button class="rrk wide" data-k="enter" aria-label="Enter">Enter</button>':''}${[...row].map(l=>`<button class="rrk${ks[l]?' '+ks[l]:''}${anim&&ks[l]&&ks[l]!==old[l]?' chg':''}${sh.includes(l)?' shat':''}" data-k="${l}" aria-label="${l.toUpperCase()}${ks[l]?', '+RR_SAY[ks[l]]:''}">${l}</button>`).join('')}${ri===2?`<button class="rrk wide" data-k="back" aria-label="Delete">${RR_DELI}</button>`:''}</div>`).join('');
 RR.ks=ks;el.querySelectorAll('[data-k]').forEach(b=>b.onclick=()=>{const k=b.dataset.k;if(k==='enter')rrEnter();else if(k==='back')rrDel();else rrType(k);if(!rrRM()){b.classList.remove('tap');void b.offsetWidth;b.classList.add('tap')}});
 el.classList.toggle('off',e.st!=='p')}
const RR_DELI='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 5h11v14H9l-6-7z" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round"/><path d="m12 9 5 6m0-6-5 6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>';
function rrLegend(){const el=$('rrleg');if(!el)return;const e=rrCur(),d=RR.mode==='d';
 el.innerHTML=`<span><i class="rrsw c"></i>Green: right rune, right place</span><span><i class="rrsw p"></i>Gold: right rune, wrong place</span>${d?`<span>Every player gets the same word</span><span>Next riddle in <b id="rrnext">${rrLeft()}</b></span>`:'<span>Practice: a random word each time</span>'}${e.st!=='p'?`<button class="rrlink" id="rrview">View result</button>`:''}`;
 const v=$('rrview');if(v)v.onclick=()=>rrResult(false)}
function rrTick(){const tk=RR&&RR.tk,day=rrKey();clearInterval(rrTick.h);rrTick.h=setInterval(()=>{if(!RR||RR.tk!==tk||!$('rr')){clearInterval(rrTick.h);return}
 const n=$('rrnext');if(n)n.textContent=rrLeft();const m=$('rrres'),e=rrCur();if(rrKey()!==day&&RR.mode==='d'&&!RR.busy&&!RR.cur&&(!m||m.hidden)&&(e.st!=='p'||!e.g.length)){rrMenu(RR.back,'d')}},15000)}
function rrGold(to){const el=$('rrgv');if(!el)return;const from=+(el.dataset.v||P.gold),tgt=to==null?P.gold:to;el.dataset.v=tgt;
 if(rrRM()||from===tgt){el.textContent=rrFmt(tgt);return}const t0=performance.now(),D=900;const f=t=>{const u=Math.min(1,(t-t0)/D),v=from+(tgt-from)*(1-Math.pow(1-u,3));el.textContent=rrFmt(v);if(u<1)requestAnimationFrame(f)};requestAnimationFrame(f)}
/* ---------- result card ---------- */
function rrShare(){const e=rrCur(),d=RR.mode==='d',k=RR.key;const rows=e.g.map(g=>rrScore(g,e.w).map(s=>s==='c'?'🟩':s==='p'?'🟨':'⬛').join('')).join('\n');
 const txt=`Runestone Riddle${d?(rrIdx(k)>=0?' #'+rrNum(k):''):' (practice)'} ${e.st==='w'?e.g.length:'X'}/6${e.pw.r||e.pw.s?' ✦':''}\n${rows}`;
 const ok=()=>rrToast('Result copied. Paste it anywhere to share!');try{navigator.clipboard.writeText(txt).then(ok,()=>{rrCopyFb(txt);ok()})}catch(x){rrCopyFb(txt);ok()}}
function rrCopyFb(t){try{const a=document.createElement('textarea');a.value=t;a.style.position='fixed';a.style.opacity='0';document.body.appendChild(a);a.select();document.execCommand('copy');a.remove()}catch(x){}}
function rrResult(fresh){const m=$('rrres');if(!m)return;const R=RRP(),e=rrCur(),d=RR.mode==='d',win=e.st==='w',n=e.g.length,k=RR.key;
 let res=fresh&&RR.res?RR.res:null;if(!res&&d){const tot=e.c||0,b=e.cb||0;res={win,n,base:win?RR_PAY[n-1]:RR_FAIL,bonus:b,tot,cut:win?RR_PAY[n-1]-(tot-b):0,title:0}}
 const dist=d?R.dist:R.pr.dist,mx=Math.max(1,...dist),st=d?rrStreak():R.pr.st,best=d?R.best:R.pr.best;
 const rows=d&&res?`<div class="rrpay"><p><span>${win?`Solved in ${n} guess${n>1?'es':''}`:'Consolation for trying'}</span><b>+${rrFmt(res.base)}</b></p>${res.cut>0?`<p class="neg"><span>Rune powers used</span><b>−${rrFmt(res.cut)}</b></p>`:''}${res.bonus?`<p class="bon"><span>${st}-day streak bonus</span><b>+${rrFmt(res.bonus)}</b></p>`:''}<p class="tot"><span>Total</span><b id="rrtot" data-v="${res.tot}">${fresh&&!rrRM()?'+0':'+'+rrFmt(res.tot)}</b><i class="rrcn"></i></p>${res.title?'<p class="ttl">✦ New title unlocked: <em>Riddlemaster</em> ✦</p>':''}</div>`:'';
 m.innerHTML=`<div class="rrrc${win?' win':' lose'}" role="dialog" aria-modal="true" aria-labelledby="rrrh">
  <p class="rrey">${d?`Runestone Riddle${rrIdx(k)>=0?' #'+rrNum(k):''}`:'Practice riddle'}</p>
  <h2 id="rrrh">${win?RR_PRAISE[n-1]:'The rune stays hidden'}</h2>
  <p class="rrsub">${win?`You read the runestone in ${n} ${n>1?'guesses':'guess'}.`:'The hidden word was:'}</p>
  <div class="rrword">${[...e.w].map((l,i)=>`<span class="rrt ${win?'c':'p'} f" style="--i:${i}"><b>${l}</b></span>`).join('')}</div>
  ${rows}
  <div class="rrdist big">${dist.map((v,i)=>`<div class="rrdr${win&&n===i+1?' me':''}"><span>${i+1}</span><i style="--w:${(v/mx).toFixed(3)}"><em>${v}</em></i></div>`).join('')}</div>
  <p class="rrstk">${d?'Day streak':'Win streak'} <b>${st}</b> <u>·</u> Best <b>${best}</b>${d?` <u>·</u> Next riddle in <b>${rrLeft()}</b>`:''}</p>
  <div class="rrbts"><button class="rrbtn ghost" id="rrshare">Share result</button>${d?`<button class="rrbtn" id="rrprac">Play a practice riddle <i>›</i></button>`:`<button class="rrbtn" id="rragain">New riddle <i>›</i></button>`}</div>
  <button class="rrxb" id="rrclose" aria-label="Close">×</button></div>`;
 m.style.top=ov.scrollTop+'px';m.style.height=ov.clientHeight+'px';ov.classList.add('rrlock');m.hidden=false;m.classList.remove('on');void m.offsetWidth;m.classList.add('on');
 $('rrclose').onclick=rrResClose;m.onclick=ev=>{if(ev.target===m)rrResClose()};$('rrshare').onclick=rrShare;
 const pr=$('rrprac');if(pr)pr.onclick=()=>{rrResClose();RR.mode='p';RR.cur='';rrSwap()};
 const ag=$('rragain');if(ag)ag.onclick=()=>{rrResClose();RRP().pr.cur=null;RR.cur='';save();rrSwap()};
 setTimeout(()=>{const b=$('rrprac')||$('rragain');if(b)b.focus()},40);
 if(fresh&&d&&res&&res.tot>0){const tt=$('rrtot');if(rrRM()){rrGold()}else setTimeout(()=>{rrCount(tt,res.tot);rrCoins(tt)},520)}}
function rrCount(el,v){if(!el)return;const t0=performance.now(),D=900;const f=t=>{const u=Math.min(1,(t-t0)/D);el.textContent='+'+rrFmt(v*(1-Math.pow(1-u,3)));if(u<1)requestAnimationFrame(f)};requestAnimationFrame(f)}
/* screen rect -> position inside #rr (the stage is scaled, so divide by the scale) */
function rrLoc(el){const root=$('rr'),B=root.getBoundingClientRect(),k=B.width/(root.offsetWidth||1)||1,r=el.getBoundingClientRect();return{left:(r.left-B.left)/k,top:(r.top-B.top)/k,width:r.width/k,height:r.height/k}}
function rrCoins(from){const g=$('rrgold'),mo=$('rrres');if(!from||!g||!from.isConnected||!mo||mo.hidden){rrGold();return}const a=rrLoc(from),b=rrLoc(g),root=$('rr');const n=12;
 for(let i=0;i<n;i++){const c=document.createElement('i');c.className='rrfly';const x0=a.left+a.width/2+(Math.random()-.5)*40,y0=a.top+a.height/2+(Math.random()-.5)*20,x1=b.left+18,y1=b.top+b.height/2;
  c.style.left=x0+'px';c.style.top=y0+'px';root.appendChild(c);const mx=(x1-x0)*.5+(Math.random()-.5)*160,my=(y1-y0)*.5-120-Math.random()*80;
  const an=c.animate([{transform:'translate(-50%,-50%) scale(.4)',opacity:0},{transform:`translate(calc(-50% + ${mx}px),calc(-50% + ${my}px)) scale(1.1)`,opacity:1,offset:.45},{transform:`translate(calc(-50% + ${x1-x0}px),calc(-50% + ${y1-y0}px)) scale(.55)`,opacity:.9}],{duration:900+i*40,delay:i*55,easing:'cubic-bezier(.45,0,.3,1)',fill:'both'});
  an.onfinish=()=>{c.remove();rrSfx('coin');if(i===n-1){rrGold();const gg=$('rrgold');if(gg){gg.classList.remove('bump');void gg.offsetWidth;gg.classList.add('bump')}}}}}
function rrResClose(){const m=$('rrres');if(!m||m.hidden)return;const t=$('rrtoast'),sl=$('rrslab');if(t&&sl&&t.parentNode!==sl){t.classList.remove('on');sl.appendChild(t)}m.classList.remove('on');m.hidden=true;m.innerHTML='';ov.classList.remove('rrlock');rrGold()}
/* ---------- the win burst: rune sparks from every tile of the winning row ---------- */
function rrBurst(T){if(rrRM())return;const cv=$('rrfx'),root=$('rr');if(!cv||!root)return;const W2=cv.width=root.offsetWidth,H2=cv.height=Math.min(2400,root.offsetHeight),g=cv.getContext('2d'),ps=[];
 T.forEach((t,i)=>{const r=rrLoc(t),cx=r.left+r.width/2,cy=r.top+r.height/2;for(let j=0;j<26;j++){const a=Math.random()*Math.PI*2,v=120+Math.random()*420;
  ps.push({x:cx,y:cy,vx:Math.cos(a)*v,vy:Math.sin(a)*v-200,l:0,ml:.9+Math.random()*.9,s:3+Math.random()*5,c:j%3?'#7af0b0':j%2?'#ffd45a':'#ffffff',k:j%4,r:Math.random()*6,d:i*.07})}});
 const t0=performance.now();let last=t0;const f=now=>{if(!$('rrfx'))return;const dt=Math.min(.05,(now-last)/1000);last=now;g.clearRect(0,0,W2,H2);let alive=0;
  for(const p of ps){if((now-t0)/1000<p.d){alive++;continue}p.l+=dt;if(p.l>p.ml)continue;alive++;p.vy+=520*dt;p.vx*=.985;p.x+=p.vx*dt;p.y+=p.vy*dt;p.r+=dt*5;const u=p.l/p.ml;
   g.globalAlpha=1-u*u;g.fillStyle=p.c;g.save();g.translate(p.x,p.y);g.rotate(p.r);if(p.k===0){g.beginPath();g.moveTo(0,-p.s*1.6);g.quadraticCurveTo(0,0,p.s*1.6,0);g.quadraticCurveTo(0,0,0,p.s*1.6);g.quadraticCurveTo(0,0,-p.s*1.6,0);g.quadraticCurveTo(0,0,0,-p.s*1.6);g.fill()}else g.fillRect(-p.s/2,-p.s/2,p.s,p.s*(p.k===1?1:.5));g.restore()}
  g.globalAlpha=1;if(alive)requestAnimationFrame(f);else g.clearRect(0,0,W2,H2)};requestAnimationFrame(f)}
/* ---------- keys ---------- */
addEventListener('keydown',e=>{if(!RR||!$('rr')||ov.className.indexOf('hide')>=0||e.ctrlKey||e.metaKey||e.altKey)return;const ae=document.activeElement;if(ae&&/INPUT|TEXTAREA|SELECT/.test(ae.tagName)&&ae!==inp)return;
 const m=$('rrres'),k=e.key;
 if(m&&!m.hidden){if(k==='Escape'){e.preventDefault();e.stopImmediatePropagation();rrResClose()}else if(k==='Tab'){const f=[...m.querySelectorAll('button')];if(f.length){const i=f.indexOf(ae);e.preventDefault();e.stopImmediatePropagation();f[(i+(e.shiftKey?-1:1)+f.length)%f.length].focus()}}return}
 if(k==='Escape'){e.preventDefault();e.stopImmediatePropagation();rrBack();return}
 if(k==='Enter'){if(ae&&ae.tagName==='BUTTON'&&ae!==inp&&!ae.closest('#rrkb'))return;e.preventDefault();e.stopImmediatePropagation();rrEnter();if(ae&&ae.blur)ae.blur();return}
 if(k==='Backspace'){e.preventDefault();e.stopImmediatePropagation();rrDel();return}
 if(/^[a-z]$/i.test(k)){e.preventDefault();e.stopImmediatePropagation();if(!e.repeat)rrType(k.toLowerCase())}},true);
