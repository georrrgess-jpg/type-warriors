# 8.7 fixes for touch typing and Moonlit Fishing (94a_fix_fishing.js): A1 leaving during the catch show keeps or sells the fish exactly
# once, A6 a full creel is never overfilled, A9 Back asks like Esc and leaving mid-fight counts as an escape, A4 the pond pauses on
# blur / hidden tab and resumes on a key, tap or focus, A2 + B1 the on-screen keyboard in Moonlit Fishing and Trick-or-Treat on
# 390x844 and 844x390 (no overlaps, no second keyboard in the Riddle or the Caravan) and B16 Big Screen treats the caravan and
# fishing as busy play. Run from the source folder against out.html; screenshots go to $SHOTS (default ./shots).
import asyncio,os,json,threading,http.server,functools,socketserver
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__));OVL=open(os.path.join(HERE,'t_riddle_ovl.js')).read()
SH=os.environ.get('SHOTS','shots');os.makedirs(SH,exist_ok=True)
URL='file://'+os.path.abspath('out.html')
CLAMP="(()=>{const r=Date.now.bind(Date),lim=new Date(2026,9,25).getTime();Date.now=()=>Math.min(r(),lim)})()"  # keeps the Halloween event open
PARENT="""<!doctype html><html><body style="margin:0;background:#000"><iframe id="g" src="/out.html" allow="fullscreen 'none'" style="width:1200px;height:700px;border:0"></iframe>
<script>window.got=[];addEventListener('message',e=>{if(!e.data||e.data.type!=='type-warriors-fullscreen')return;got.push('ask');e.source.postMessage({type:'type-warriors-fullscreen-ack'},'*')})</script></body></html>"""
class H(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path.startswith('/parent'):
            b=PARENT.encode();self.send_response(200);self.send_header('Content-Type','text/html');self.end_headers();self.wfile.write(b);return
        return super().do_GET()
    def log_message(self,*a):pass
BAD=[0];ER=[]
def chk(name,r,ok):
    BAD[0]+=not ok;print(name,r,'OK' if ok else 'BAD',flush=True)
def watch(pg):
    pg.on('pageerror',lambda e:ER.append('PE '+str(e)[:300]));pg.on('console',lambda m:ER.append('CE '+m.text[:200]) if m.type=='error' and 'ERR_' not in m.text and 'permissions policy' not in m.text else None)
PART=os.environ.get('PART','all')  # all | desk | touch | bs
async def desk(b):
    pg=await b.new_page(viewport={'width':1600,'height':900});watch(pg)
    await pg.goto(URL);await pg.wait_for_timeout(1200);E=pg.evaluate
    async def fresh(extra=''):
        await E("()=>{RS_ASK=false;P.gold=5000;delete P.fish;save();PFW.asked=true;title();const F=fsP();F.tut=1;F.seen=1;F.look=0;save();"+extra+"}")
        await pg.wait_for_timeout(300)
    async def pond():
        await E("()=>fsPond()");await pg.wait_for_timeout(800)
    async def hook(rk,id,cm=80):
        await E("a=>{if(!window.__fr){window.__fr=fsRoll;window.__fw=fsWait}fsRoll=()=>({id:a[1],rk:a[0],cm:a[2],g:false});fsWait=()=>0.3}",[rk,id,cm])
    async def unhook():
        await E("()=>{if(window.__fr){fsRoll=window.__fr;fsWait=window.__fw}}")
    async def typeword():
        await pg.wait_for_function("()=>FS.st==='reel'",timeout=7000);w=await E("()=>FS.word")
        for ch in w:await pg.keyboard.press(ch);await pg.wait_for_timeout(15)
    async def to_show(rk,id,cm=80):
        await hook(rk,id,cm);await pg.keyboard.press('Space');await pg.wait_for_function("()=>FS.st==='reel'",timeout=8000)
        n=await E("()=>FS.words.length")
        for i in range(n):await typeword()
        await pg.wait_for_function("()=>FS.st==='show'",timeout=7000)
    snap="a=>{const F=fsP();const b=F.b[a]||{};return {g:P.gold,cr:F.cr.length,ids:F.cr.map(c=>c.id).join(),n:b.n||0,esc:F.s.esc||0,streak:F.streak||0,view:S.view,on:FS.on,st:FS.st}}"
    # ---------- A1: leaving during the catch show ----------
    await fresh();await pond();await E("()=>{const F=fsP();F.b.reed={n:4,big:30,g:0};save()}")
    a=await E(snap,'aurora');await to_show('l','aurora');await pg.wait_for_timeout(500)
    st=await E("()=>[FS.st,!!FS.show,FS.show&&FS.show.c.id]");a2=await E(snap,'aurora');await pg.keyboard.press('Escape');await pg.wait_for_timeout(600)
    z=await E(snap,'aurora');e=await E("()=>{const c=fsP().cr[fsP().cr.length-1];return c&&[c.id,c.kp,typeof c.t,c.g,c.ft,c.cm]}")
    chk('A1 Esc during a Legendary show: in the creel once, gold unchanged, journal updated',[st,a,a2,z,e],st==['show',True,'aurora'] and z['cr']==a['cr']+1 and z['ids'].count('aurora')==1 and z['g']==a2['g'] and z['n']==a['n']+1 and z['view']=='fishhub' and not z['on'] and e[0]=='aurora' and e[1]==1 and e[2]=='number')
    await unhook();await fresh();await pond();await E("()=>{const F=fsP();F.b.reed={n:4,big:30,g:0};save()}")
    a=await E(snap,'reed');await to_show('c','reed',30);v=await E("()=>FS.show.c.val");await pg.wait_for_timeout(300)
    await E("()=>$('fsback').click()");await pg.wait_for_timeout(600);z=await E(snap,'reed')
    chk('A1 Back during a common show: sold once for its value, creel unchanged',[a,z,v],v>0 and z['g']==a['g']+v and z['cr']==a['cr'] and z['n']==a['n']+1 and z['view']=='fishhub')
    await unhook();await fresh();await pond();await E("()=>{const F=fsP();F.b.reed={n:4,big:30,g:0};save()}")
    a=await E(snap,'reed');await to_show('c','reed',30);v=await E("()=>FS.show.c.val");await E("()=>title()");await pg.wait_for_timeout(500);z=await E(snap,'reed')
    chk('A1 title() during a common show: sold once, creel unchanged',[a,z,v],v>0 and z['g']==a['g']+v and z['cr']==a['cr'] and z['n']==a['n']+1 and z['on'] is False)
    await unhook();await fresh();await pond();await E("()=>{const F=fsP();F.b.reed={n:4,big:30,g:0};F.auto=1;save()}")
    a=await E(snap,'reed');await to_show('c','reed',30);v=await E("()=>FS.show.c.val");await pg.keyboard.press('Escape');await pg.wait_for_timeout(500);z=await E(snap,'reed')
    chk('A1 auto-sell on: leaving in the show pays once, not twice',[a,z,v],z['g']==a['g']+v and z['cr']==a['cr'] and z['n']==a['n']+1)
    await unhook();await fresh();await pond()
    a=await E(snap,'aurora');await to_show('l','aurora');await pg.wait_for_function("()=>FS.st==='reveal'",timeout=9000);a2=await E(snap,'aurora');await pg.keyboard.press('Escape');await pg.wait_for_timeout(500);z=await E(snap,'aurora')
    chk('A1 reveal screen still keeps a Legendary once on leaving',[a,a2,z],z['cr']==a['cr']+1 and z['ids'].count('aurora')==1 and z['g']==a2['g'] and z['view']=='fishhub')
    await E("()=>{fsLeave();fsLeave()}");z2=await E(snap,'aurora');chk('A1 a second fsLeave changes nothing',z2,z2['cr']==z['cr'] and z2['g']==z['g'])
    # a mythic or odd catch settles through fsReveal as usual: leaving in the show never double-pays
    await unhook();await fresh();await pond();await E("()=>{const F=fsP();F.b.reed={n:4,big:30,g:0};save()}")
    a=await E(snap,'reed');await to_show('c','reed',30);await E("()=>{fsLeave()}");await pg.wait_for_timeout(300);z=await E(snap,'reed')
    chk('A1 fsLeave() during the show behaves the same',[a,z],z['g']>a['g'] and z['cr']==a['cr'] and z['n']==a['n']+1)
    # ---------- A6: a full creel is never overfilled ----------
    await unhook();await fresh();await pond()
    await E("()=>{const F=fsP(),cap=fsCreelCap();F.cr=[];for(let i=0;i<cap;i++)F.cr.push({id:'reed',cm:10,g:0,ft:0,kp:1,t:1});save()}")
    a=await E(snap,'aurora');cap=await E("()=>fsCreelCap()");await to_show('l','aurora');v=await E("()=>FS.show.c.val");a=await E(snap,'aurora');await pg.keyboard.press('Escape');await pg.wait_for_timeout(600);z=await E(snap,'aurora')
    toast=await E("()=>(document.getElementById('fztoast')||{}).textContent")
    chk('A6 full creel + Legendary + Esc: creel stays at its cap, sold instead',[cap,a['cr'],z['cr'],a['g'],z['g'],v,toast],z['cr']==cap and 'aurora' not in z['ids'] and z['g']==a['g']+v and 'creel was full' in (toast or ''))
    await unhook();await fresh();await pond()
    await E("()=>{const F=fsP(),cap=fsCreelCap();F.cr=[];for(let i=0;i<cap;i++)F.cr.push({id:'reed',cm:10,g:0,ft:0,kp:1,t:1});save()}")
    a=await E(snap,'aurora');await to_show('l','aurora');await pg.wait_for_function("()=>FS.st==='reveal'",timeout=9000);await E("()=>fsLeave()");await pg.wait_for_timeout(300);z=await E(snap,'aurora')
    chk('A6 full creel, leaving on the reveal screen: 30/30, sold',[a['cr'],z['cr'],a['g'],z['g']],z['cr']==a['cr'] and z['g']>a['g'])
    await unhook();await fresh();await pond()
    await E("()=>{const F=fsP();F.cr=[];for(let i=0;i<29;i++)F.cr.push({id:'reed',cm:10,g:0,ft:0,kp:1,t:1});save()}")
    a=await E(snap,'aurora');await to_show('l','aurora');await pg.wait_for_function("()=>FS.st==='reveal'",timeout=9000);await E("()=>fsLeave()");await pg.wait_for_timeout(300);z=await E(snap,'aurora')
    e=await E("()=>{const c=fsP().cr[fsP().cr.length-1];return [c.id,Object.keys(c).sort().join(),c.kp,typeof c.t]}")
    chk('A6 29/30: the last slot is taken, with the fields fsKeep writes',[z['cr'],e],z['cr']==30 and e==['aurora','cm,ft,g,id,kp,t',1,'number'])
    # ---------- A9: Back mid-fight asks like Esc; leaving mid-fight is an escape ----------
    await unhook();await fresh();await pond();await hook('c','reed',30);await E("()=>{const F=fsP();F.streak=5;save()}")
    a=await E(snap,'reed');await pg.keyboard.press('Space');await pg.wait_for_function("()=>FS.st==='reel'",timeout=8000)
    await E("()=>$('fsback').click()");await pg.wait_for_timeout(250);m=await E("()=>[FS.on,S.view,FS.st,document.getElementById('fstoast').textContent,document.getElementById('fstoast').classList.contains('on')]")
    chk('A9 first Back click mid-fight only asks (toast, still fighting)',m,m[0] and m[1]=='fish' and m[2]=='reel' and 'again' in m[3] and m[4])
    await E("()=>$('fsback').click()");await pg.wait_for_timeout(500);z=await E(snap,'reed')
    chk('A9 second Back click leaves: streak reset and one escape counted',[a,z],z['view']=='fishhub' and not z['on'] and z['streak']==0 and z['esc']==a['esc']+1)
    await unhook();await fresh();await pond();await hook('c','reed',30);await E("()=>{const F=fsP();F.streak=4;save()}")
    a=await E(snap,'reed');await pg.keyboard.press('Space');await pg.wait_for_function("()=>FS.st==='reel'",timeout=8000)
    await pg.keyboard.press('Escape');await pg.wait_for_timeout(150);m=await E("()=>[FS.on,S.view]");await E("()=>$('fsback').click()");await pg.wait_for_timeout(500);z=await E(snap,'reed')
    chk('A9 Esc then Back inside the window leaves (one shared question), escape counted',[m,z],m==[True,'fish'] and z['view']=='fishhub' and z['streak']==0 and z['esc']==a['esc']+1)
    await unhook();await fresh();await pond();await hook('c','reed',30)
    await pg.keyboard.press('Space');await pg.wait_for_function("()=>FS.st==='reel'",timeout=8000)
    await E("()=>{FS.escT=fsNow()-3}");await E("()=>$('fsback').click()");await pg.wait_for_timeout(250);m=await E("()=>[FS.on,S.view,FS.st]")
    chk('A9 an old warning does not count: Back asks again',m,m==[True,'fish','reel'])
    await pg.keyboard.press('Escape');await pg.wait_for_timeout(500);z=await E(snap,'reed')
    chk('A9 Back then Esc inside the window leaves, and counts as an escape',z,z['view']=='fishhub' and z['esc']>=1)
    await unhook();await fresh();await pond();await hook('c','reed',30);a=await E(snap,'reed');await pg.keyboard.press('Space');await pg.wait_for_function("()=>FS.st==='reel'",timeout=8000)
    await pg.keyboard.press('Escape');await pg.wait_for_timeout(150);m=await E("()=>[S.view,FS.st]");await pg.keyboard.press('Escape');await pg.wait_for_timeout(500);z=await E(snap,'reed')
    chk('A9 Esc twice leaves (as before) and now counts as an escape',[m,z],m==['fish','reel'] and z['view']=='fishhub' and z['esc']==a['esc']+1)
    await unhook();await fresh();await pond();await hook('c','reed',30);await E("()=>{const F=fsP();F.streak=3;save()}")
    a=await E(snap,'reed');await pg.keyboard.press('Space');await pg.wait_for_function("()=>FS.st==='reel'",timeout=8000);await E("()=>fsLeave()");await pg.wait_for_timeout(300);z=await E(snap,'reed')
    chk('A9 fsLeave() mid-fight: escape counted, streak reset, bounty run and rarity stat as fsEscape writes them',[a,z],z['streak']==0 and z['esc']==a['esc']+1 and await E("()=>{const s=fsP().s;return !!(s.rs&&s.rs.c&&s.rs.c[1]>=1)}"))
    await unhook();await fresh();await pond();await hook('c','reed',30);await pg.keyboard.press('Space');await pg.wait_for_function("()=>FS.st==='wait'||FS.st==='cast'",timeout=3000)
    await E("()=>$('fsback').click()");await pg.wait_for_timeout(400);m=await E("()=>[S.view,FS.on]");chk('A9 Back while waiting for a bite leaves at once (nothing to lose)',m,m==['fishhub',False])
    # ---------- A4: pause on blur / hidden tab ----------
    await unhook();await fresh();await pond();await hook('c','reed',30);await pg.keyboard.press('Space');await pg.wait_for_function("()=>FS.st==='reel'",timeout=8000)
    await E("()=>{FS.grace=0}");await pg.wait_for_timeout(300);t0=await E("()=>FS.tLeft");await E("()=>window.dispatchEvent(new Event('blur'))")
    s0=await E("()=>[FS.tLeft,FS.grace,FS.t0,FS.biteT]");await pg.wait_for_timeout(1500);s1=await E("()=>[FS.tLeft,FS.grace,FS.t0,FS.biteT]")
    note=await E("()=>{const n=document.getElementById('fspz');return n&&[n.textContent,getComputedStyle(n).display,n.getBoundingClientRect().width>100]}")
    chk('A4 blur mid-fight: FS.tLeft, grace and clocks stay constant for 1.5 s',[t0,s0,s1],abs(s0[0]-s1[0])<1e-9 and s0[1]==s1[1] and s0[2]==s1[2])
    chk('A4 the note says "Paused - press any key"',note,note is not None and note[0]=='Paused - press any key' and note[1]!='none' and note[2])
    await pg.screenshot(path=SH+'/fishing_pause_note_1600x900.png')
    typed=await E("()=>FS.typed");miss=await E("()=>FS.word[0]");other='q' if miss!='q' else 'w'
    await pg.keyboard.press(other);await pg.wait_for_timeout(120);r=await E("()=>[FS.paused,FS.typed,FS.tLeft,!!document.getElementById('fspz'),FS.st]")
    chk('A4 a key resumes and is not typed (no miss penalty)',[s1[0],r],r[0] is False and r[1]==typed and r[2]>=s1[0]-0.2 and r[3] is False and r[4]=='reel')
    await pg.wait_for_timeout(800);t1=await E("()=>FS.tLeft");chk('A4 after resuming the countdown runs again',[r[2],t1],t1<r[2]-.4)
    await E("()=>{FS.grace=0;window.dispatchEvent(new Event('blur'))}");a1=await E("()=>FS.tLeft");await pg.wait_for_timeout(700);await E("()=>window.dispatchEvent(new Event('focus'))");await pg.wait_for_timeout(150)
    r=await E("()=>[FS.paused,FS.tLeft]");chk('A4 window focus resumes',[a1,r],r[0] is False and r[1]>=a1-.25)
    await E("()=>{FS.grace=0;Object.defineProperty(document,'hidden',{configurable:true,get:()=>true});Object.defineProperty(document,'visibilityState',{configurable:true,get:()=>'hidden'});document.dispatchEvent(new Event('visibilitychange'))}")
    a1=await E("()=>[FS.paused,FS.tLeft]");await pg.wait_for_timeout(1200);a2=await E("()=>[FS.paused,FS.tLeft]")
    chk('A4 hidden tab (visibilitychange) pauses; no countdown while hidden',[a1,a2],a1[0] is True and a2[1]==a1[1])
    await E("()=>{delete document.hidden;delete document.visibilityState;document.dispatchEvent(new Event('visibilitychange'))}");await pg.wait_for_timeout(200)
    r=await E("()=>[FS.paused,document.hidden]");chk('A4 the tab coming back resumes',r,r[0] is False and r[1] is False)
    # pause also holds the wait for a bite and the catch show, and the clocks carry on without a jump
    await E("()=>{fsLeave()}");await pg.wait_for_timeout(300);await unhook();await fresh();await pond();await hook('c','reed',30)
    await E("()=>{fsWait=()=>1.2}");await pg.keyboard.press('Space');await pg.wait_for_function("()=>FS.st==='wait'",timeout=4000);await pg.wait_for_timeout(300)
    el0=await E("()=>{const e=fsNow()-FS.t0;window.dispatchEvent(new Event('blur'));return e}");await pg.wait_for_timeout(1800);r=await E("()=>[FS.st,FS.paused,FS.cur]")
    chk('A4 blur while waiting: no bite arrives while paused',r,r[0]=='wait' and r[1] is True and r[2] is None)
    el1=await E("()=>{window.dispatchEvent(new Event('focus'));return fsNow()-FS.t0}")
    chk('A4 the wait carries on from where it stopped (no jump)',[el0,el1],abs(el1-el0)<.05)
    await pg.wait_for_function("()=>FS.st==='reel'",timeout=4000)
    await unhook();await E("()=>{fsLeave()}");await fresh();await pond();await to_show('l','aurora');await pg.wait_for_timeout(700)
    el0=await E("()=>{const e=fsNow()-FS.t0;window.dispatchEvent(new Event('blur'));return e}");await pg.wait_for_timeout(1500);r=await E("()=>[FS.st,FS.paused,!!FS.show]")
    el1=await E("()=>{window.dispatchEvent(new Event('focus'));return fsNow()-FS.t0}")
    chk('A4 the catch show freezes and resumes without a jump',[r,el0,el1],r==['show',True,True] and abs(el1-el0)<.05)
    await pg.wait_for_function("()=>FS.st==='reveal'",timeout=9000);await E("()=>window.dispatchEvent(new Event('blur'))");r=await E("()=>FS.paused");chk('A4 no pause on the reveal screen (nothing is running)',r,r is False)
    await E("()=>fsDecide(false)");await E("()=>window.dispatchEvent(new Event('blur'))");r=await E("()=>FS.paused");chk('A4 no pause while idle',r,r is False)
    # a click on the pond while paused only resumes: it does not also skip the catch show
    await E("()=>{fsLeave()}");await unhook();await fresh();await pond();await to_show('c','reed',30);await pg.wait_for_timeout(500)
    await E("()=>window.dispatchEvent(new Event('blur'))");await pg.mouse.click(600,420);await pg.wait_for_timeout(150);r=await E("()=>[FS.paused,FS.st,FS.show&&FS.show.sk===undefined]")
    chk('A4 a click on the pond while paused resumes and does not skip the show',r,r==[False,'show',True])
    # typing through the hidden input (a phone keyboard) resumes first and is not typed
    await E("()=>{fsLeave()}");await unhook();await fresh();await pond();await hook('c','reed',30);await pg.keyboard.press('Space');await pg.wait_for_function("()=>FS.st==='reel'",timeout=8000)
    await E("()=>{FS.grace=0;window.dispatchEvent(new Event('blur'))}");tl=await E("()=>FS.tLeft");await E("()=>fsType('q')");r=await E("()=>[FS.paused,FS.tLeft,FS.typed]")
    chk('A4 fsType while paused resumes without a miss penalty',[tl,r],r[0] is False and r[1]>=tl-.1 and r[2]==0)
    await E("()=>{FS.grace=0;window.dispatchEvent(new Event('blur'))}");await pg.click('#fsback');await pg.wait_for_timeout(200);r=await E("()=>[FS.paused,S.view,FS.st,!!document.getElementById('fspz')]")
    chk('A4 a click on Back while paused resumes and asks (still in the pond)',r,r==[False,'fish','reel',False])
    await E("()=>fsLeave()");await pg.wait_for_timeout(300);r=await E("()=>[FS.paused,!!document.getElementById('fspz'),S.view]");chk('A4 leaving clears the pause state and note',r,r==[False,False,'fishhub'])
    # Esc while paused is "any key": it resumes and does not leave
    await unhook();await fresh();await pond();await hook('c','reed',30);await pg.keyboard.press('Space');await pg.wait_for_function("()=>FS.st==='reel'",timeout=8000)
    await E("()=>window.dispatchEvent(new Event('blur'))");await pg.keyboard.press('Escape');await pg.wait_for_timeout(200);r=await E("()=>[FS.paused,S.view,FS.st]")
    chk('A4 Esc while paused only resumes',r,r==[False,'fish','reel'])
    await E("()=>fsLeave()");await unhook()
    # ---------- reduced motion: no animation on the note ----------
    ctx=await b.new_context(viewport={'width':1600,'height':900},reduced_motion='reduce');pr=await ctx.new_page();watch(pr);await pr.goto(URL);await pr.wait_for_timeout(1200)
    await pr.evaluate("()=>{RS_ASK=false;P.gold=5000;delete P.fish;save();PFW.asked=true;title();const F=fsP();F.tut=1;F.seen=1;save();fsRoll=()=>({id:'reed',rk:'c',cm:30,g:false});fsWait=()=>0.3;fsPond()}");await pr.wait_for_timeout(800)
    await pr.keyboard.press('Space');await pr.wait_for_function("()=>FS.st==='reel'",timeout=8000);await pr.evaluate("()=>window.dispatchEvent(new Event('blur'))");await pr.wait_for_timeout(300)
    r=await pr.evaluate("()=>{const n=document.getElementById('fspz');return n&&[n.className,getComputedStyle(n).animationName,n.textContent]}")
    chk('A4 reduced motion: the note appears without animation',r,r is not None and 'rm' in r[0] and r[1]=='none' and r[2]=='Paused - press any key')
    await pr.screenshot(path=SH+'/fishing_pause_note_reduced.png');await ctx.close()
    await pg.close()
async def touch(b):
    # ---------- A2 + B1: the on-screen keyboard (touch) ----------
    for vw,vh in [(390,844),(844,390)]:
        tag=f'{vw}x{vh}'
        ctx=await b.new_context(viewport={'width':vw,'height':vh},has_touch=True,is_mobile=True,device_scale_factor=2);await ctx.add_init_script(CLAMP);pt=await ctx.new_page();watch(pt)
        await pt.goto(URL);await pt.wait_for_timeout(1300);Q=pt.evaluate
        await Q("()=>{RS_ASK=false;P.gold=5000;delete P.fish;save();PFW.asked=true;ST.touch='on';saveST();applyLayout();title();const F=fsP();F.tut=1;F.seen=1;F.look=0;F.b.reed={n:4,big:30,g:0};save()}");await pt.wait_for_timeout(400)
        await Q("()=>{"+OVL+"}")
        async def tap(sel):
            r=await Q("s=>{const e=document.querySelector(s);if(!e)return null;const b=e.getBoundingClientRect();return [b.x+b.width/2,b.y+b.height/2]}",sel)
            assert r,sel
            await pt.touchscreen.tap(r[0],r[1])
        geo="""()=>{const k=document.getElementById('kb').getBoundingClientRect(),f=document.getElementById('fsx').getBoundingClientRect(),o=ov.getBoundingClientRect();
          const bs=[...document.querySelectorAll('#kb button')].filter(b=>b.offsetParent&&getComputedStyle(b).display!=='none').map(b=>b.getBoundingClientRect());
          return {kbTop:Math.round(k.top),kbH:Math.round(k.height),kbOn:document.getElementById('kb').classList.contains('on'),fsxBottom:Math.round(f.bottom),fsxTop:Math.round(f.top),fsxW:Math.round(f.width),ovBottom:Math.round(o.bottom),
          inside:bs.every(r=>r.left>=-0.5&&r.right<=innerWidth+.5&&r.top>=-0.5&&r.bottom<=innerHeight+.5),minKeyH:Math.round(Math.min(...bs.map(r=>r.height))),minKeyW:Math.round(Math.min(...bs.map(r=>r.width))),n:bs.length,
          ovl:__ovl(document.getElementById('kb')),inputmode:inp.getAttribute('inputmode'),wrkb:!!document.getElementById('wrkb'),rrkb:!!document.getElementById('rrkb')}}"""
        await Q("()=>fsPond()");await pt.wait_for_timeout(900);g=await Q(geo)
        chk(f'A2 {tag}: pond opens with the keyboard on, phone keyboard closed, no Riddle/Caravan keyboard',g,g['kbOn'] and g['inputmode']=='none' and not g['wrkb'] and not g['rrkb'])
        chk(f'A2 {tag}: the keys sit below the pond (no overlap with the game UI), all inside the screen',[g['kbTop'],g['fsxBottom'],g['ovBottom']],g['fsxBottom']<=g['kbTop']+1 and g['ovBottom']<=g['kbTop']+1 and g['inside'] and g['fsxW']>=250)
        chk(f'A2 {tag}: keys are big enough to hit and no text overlaps in the keyboard',[g['minKeyH'],g['minKeyW'],g['ovl']],g['minKeyH']>=26 and g['minKeyW']>=30 and g['ovl']==[])
        await pt.screenshot(path=f'{SH}/fishing_touch_{tag}_idle.png')
        await Q("()=>{window.__fr=fsRoll;window.__fw=fsWait;fsRoll=()=>({id:'reed',rk:'c',cm:30,g:false});fsWait=()=>0.3}")
        await tap('#kb .sp');await pt.wait_for_function("()=>FS.st==='cast'||FS.st==='wait'||FS.st==='reel'",timeout=3000)
        chk(f'A2 {tag}: the Cast key casts (Space)',await Q("()=>FS.st"),True)
        await pt.wait_for_function("()=>FS.st==='reel'",timeout=8000);await pt.wait_for_timeout(300)
        r=await Q("()=>[FS.word,document.getElementById('tkt').textContent,document.getElementById('tksec').textContent,document.getElementById('kb').dataset.st,document.getElementById('tkfill').style.transform]")
        chk(f'A2 {tag}: the strip shows the word and its timer',r,r[1].lower()==r[0] and r[2].endswith('s') and r[3]=='reel' and r[4].startswith('scaleX'))
        g=await Q(geo);chk(f'A2 {tag}: reel state, no overlap',[g['kbTop'],g['fsxBottom'],g['ovl']],g['fsxBottom']<=g['kbTop']+1 and g['ovl']==[])
        await pt.screenshot(path=f'{SH}/fishing_touch_{tag}_reel.png')
        w=await Q("()=>FS.word");wrong='q' if w[0]!='q' else 'w';await tap(f'#kb [data-c="{wrong}"]');await pt.wait_for_timeout(100)
        r=await Q("()=>[FS.typed,FS.miss]");chk(f'A2 {tag}: a wrong tap is a miss',r,r[0]==0)
        for ch in w:
            await tap(f'#kb [data-c="{ch}"]');await pt.wait_for_timeout(60)
        await pt.wait_for_function("()=>FS.st==='show'||FS.st==='reveal'",timeout=5000)
        chk(f'A2 {tag}: tapping the word lands the fish',await Q("()=>FS.st"),True)
        await pt.wait_for_timeout(700)
        if await Q("()=>FS.st==='show'"):
            chk(f'A2 {tag}: Skip key during the show',await Q("()=>document.querySelector('#kb .sp').textContent"),await Q("()=>document.querySelector('#kb .sp').textContent")=='Skip');await tap('#kb .sp')
        await pt.wait_for_function("()=>FS.st==='reveal'",timeout=5000);await pt.wait_for_timeout(400)
        g=await Q(geo);vis=await Q("()=>{const d=document.querySelector('#kb [data-a=drop]'),f=document.querySelector('#kb #kf'),s=document.querySelector('#kb .sp');return [d.offsetParent!==null,f.offsetParent!==null,s.offsetParent===null,d.textContent,f.textContent]}")
        chk(f'A2 {tag}: reveal shows Sell and Keep keys, no overlap',[vis,g['ovl']],vis[0] and vis[1] and vis[2] and vis[3].startswith('Sell') and g['ovl']==[] and g['inside'])
        await pt.screenshot(path=f'{SH}/fishing_touch_{tag}_reveal.png')
        await Q("()=>{FS.t0=fsNow()}");await tap('#kb [data-a=drop]');await pt.wait_for_timeout(60);r=await Q("()=>FS.st")
        chk(f'A2 {tag}: a Sell tap in the first moments of the reveal is ignored (it was meant for Skip)',r,r=='reveal');await pt.wait_for_timeout(450)
        g0=await Q("()=>P.gold");await tap('#kb [data-a=drop]');await pt.wait_for_timeout(400);r=await Q("()=>[FS.st,P.gold]")
        chk(f'A2 {tag}: the Sell key sells the catch',[g0,r],r[0]=='idle' and r[1]>g0)
        # Keep
        await tap('#kb .sp');await pt.wait_for_function("()=>FS.st==='reel'",timeout=8000);await pt.wait_for_timeout(200);w=await Q("()=>FS.word")
        for ch in w:
            await tap(f'#kb [data-c="{ch}"]');await pt.wait_for_timeout(60)
        await pt.wait_for_function("()=>FS.st==='show'||FS.st==='reveal'",timeout=5000);await pt.wait_for_timeout(700)
        if await Q("()=>FS.st==='show'"):await tap('#kb .sp')
        await pt.wait_for_function("()=>FS.st==='reveal'",timeout=5000);await pt.wait_for_timeout(550);c0=await Q("()=>fsP().cr.length");await tap('#kb #kf');await pt.wait_for_timeout(400);r=await Q("()=>[FS.st,fsP().cr.length]")
        chk(f'A2 {tag}: the Keep key keeps the catch',[c0,r],r[0]=='idle' and r[1]==c0+1)
        # pause on blur on touch: the strip says so; a key tap resumes
        await tap('#kb .sp');await pt.wait_for_function("()=>FS.st==='reel'",timeout=8000);await Q("()=>{FS.grace=0;window.dispatchEvent(new Event('blur'))}");await pt.wait_for_timeout(300)
        r=await Q("()=>[FS.paused,document.getElementById('tkt').textContent,getComputedStyle(document.getElementById('fspz')||document.body).display,FS.tLeft]")
        await pt.screenshot(path=f'{SH}/fishing_touch_{tag}_paused.png');await pt.wait_for_timeout(500);t1=await Q("()=>FS.tLeft")
        chk(f'A4 {tag}: paused on touch: the strip says so and the timer holds',[r,t1],r[0] is True and r[1]=='Paused - tap to resume' and t1==r[3])
        await tap('#kb [data-c="z"]');await pt.wait_for_timeout(150);r=await Q("()=>[FS.paused,FS.typed]");chk(f'A4 {tag}: a tap on a key resumes and is not typed',r,r==[False,0])
        # Back mid-fight asks first
        await tap('#kb [data-a=pause]');await pt.wait_for_timeout(200);r=await Q("()=>[S.view,FS.on,document.querySelector('#kb [data-a=pause]').textContent]")
        chk(f'A9 {tag}: the Back key asks first ("Leave?")',r,r==['fish',True,'Leave?'])
        await pt.screenshot(path=f'{SH}/fishing_touch_{tag}_leave.png')
        await tap('#kb [data-a=pause]');await pt.wait_for_timeout(700);r=await Q("()=>[S.view,FS.on,document.getElementById('kb').classList.contains('on')]")
        chk(f'A9 {tag}: the second tap leaves; the keyboard goes away with the pond',r,r==['fishhub',False,False])
        await Q("()=>{fsRoll=window.__fr;fsWait=window.__fw}")
        # ---- Trick-or-Treat ----
        await Q("()=>{title();ttNormalize();P.treatData.active=null;TRT.run=null;ttNewRun(0)}");await pt.wait_for_timeout(500)
        r=await Q("()=>[S.mode,TRT.run&&TRT.run.phase,document.getElementById('kb').classList.contains('on')]");chk(f'B1 {tag}: Trick-or-Treat starts (keyboard waits for the typing phase)',r,r==['treat','choose',False])
        await Q("()=>ttChoose(0)");await pt.wait_for_timeout(2900)
        g=await Q("""()=>{const k=document.getElementById('kb').getBoundingClientRect(),o=ov.getBoundingClientRect(),w=document.getElementById('ttword').getBoundingClientRect(),i=document.getElementById('ttinput');
          const bs=[...document.querySelectorAll('#kb button')].filter(b=>b.offsetParent).map(b=>b.getBoundingClientRect());
          return {on:kb.classList.contains('on'),tk:kb.classList.contains('tk'),ovBottom:Math.round(o.bottom),kbTop:Math.round(k.top),wTop:Math.round(w.top),wBottom:Math.round(w.bottom),inputmode:i.getAttribute('inputmode'),inside:bs.every(r=>r.left>=-.5&&r.right<=innerWidth+.5&&r.bottom<=innerHeight+.5),ovl:__ovl(kb),n:bs.length,labels:[...document.querySelectorAll('#kb .ka button')].filter(b=>b.offsetParent).map(b=>b.textContent.trim())}}""")
        chk(f'B1 {tag}: Trick-or-Treat typing shows the keyboard, the word stays above it, the phone keyboard is off',g,g['on'] and g['tk'] and g['ovBottom']<=g['kbTop']+1 and g['wTop']>=0 and g['wBottom']<=g['kbTop'] and g['inputmode']=='none' and g['inside'] and g['ovl']==[] and g['labels']==['Pause','space'])
        await pt.screenshot(path=f'{SH}/fishing_touch_{tag}_treat.png')
        w=await Q("()=>{const r=TRT.run;return r.words[r.word]}");pos0=await Q("()=>TRT.run.pos");await tap(f'#kb [data-c="{w[0]}"]');await pt.wait_for_timeout(120)
        r=await Q("()=>[TRT.run.pos,TRT.run.ok]");chk(f'B1 {tag}: a key tap types into Trick-or-Treat',[pos0,r],r[0]==pos0+1 and r[1]>=1)
        for ch in w[1:]:
            await tap(f'#kb [data-c="{ch}"]');await pt.wait_for_timeout(40)
        r=await Q("()=>[TRT.run.word,TRT.run.pos]");chk(f'B1 {tag}: finishing a word moves to the next',r,r==[1,0])
        await tap('#kb [data-a=pause]');await pt.wait_for_timeout(500);r=await Q("()=>[TRT.paused,document.getElementById('kb').classList.contains('on'),ov.clientHeight>=innerHeight/ (parseFloat(ov.style.zoom)||1)-2]")
        chk(f'B1 {tag}: Pause on the keyboard pauses the route and the keyboard leaves',r,r[0] is True and r[1] is False)
        await Q("()=>{TRT.paused=false;ttScreen();}");await pt.wait_for_timeout(2600)
        await Q("()=>{TRT.run=null;P.treatData.active=null;title()}");await pt.wait_for_timeout(300)
        # ---- the Riddle and the Caravan keep their own keyboards, and the shared one stays off ----
        await Q("()=>rrMenu(title)");await pt.wait_for_timeout(900);r=await Q("()=>[kb.classList.contains('on'),kb.classList.contains('tk'),!!document.getElementById('rrkb')]")
        chk(f'B1 {tag}: Riddle: its own keyboard only, the shared one is off',r,r==[False,False,True])
        await Q("()=>{RR=null;title()}");await pt.wait_for_timeout(300)
        await Q("()=>{delete P.wr;WRP().intro=1;save();wagonMenu(title)}");await pt.wait_for_timeout(700);await Q("()=>document.getElementById('wrgo').click()");await pt.wait_for_timeout(900)
        r=await Q("()=>[kb.classList.contains('on'),kb.classList.contains('tk'),!!document.getElementById('wrkb')]");chk(f'B1 {tag}: Caravan run: its own keyboard only, the shared one is off',r,r==[False,False,True])
        await Q("()=>{wrLeave();title()}");await pt.wait_for_timeout(300)
        # the campaign keyboard is unchanged after the labels were borrowed
        await Q("()=>start(1)");await pt.wait_for_timeout(900)
        r=await Q("()=>[S.mode,kb.classList.contains('on'),kb.classList.contains('tk'),[...document.querySelectorAll('#kb .ka button')].map(b=>b.textContent.trim())]")
        chk(f'B1 {tag}: the campaign keyboard keeps its own keys (II, Drop, space, Fury)',r,r[0]=='play' and r[1] and r[2] is False and r[3]==['II','Drop','space','Fury'])
        await ctx.close()
async def bigscreen(b):
    # ---------- B16: Big Screen counts the caravan and fishing as busy play ----------
    socketserver.ThreadingTCPServer.allow_reuse_address=True;srv=socketserver.ThreadingTCPServer(('127.0.0.1',0),functools.partial(H,directory=os.path.abspath('.')));port=srv.server_address[1];threading.Thread(target=srv.serve_forever,daemon=True).start()
    async def frame(setup):
        pf=await b.new_page(viewport={'width':1300,'height':800});watch(pf);await pf.goto(f'http://127.0.0.1:{port}/parent');await pf.wait_for_timeout(2300)
        g=[f for f in pf.frames if f.url.endswith('/out.html')][0];await g.evaluate("()=>{RS_ASK=false;PFW.asked=true;P.gold=5000;P.pet='bramble';delete P.wr;delete P.fish;WRP().intro=1;fsP().tut=1;fsP().seen=1;save()}")
        await g.evaluate(setup);await pf.wait_for_timeout(900);await g.evaluate("()=>toggleFS()");await pf.wait_for_timeout(800);return pf,g
    pf,g=await frame("()=>{fsPond()}");r=await g.evaluate("()=>[(document.getElementById('fsnote')||{}).textContent,FSB.dormant,S.mode]")
    chk('B16 fishing pond in the Big Screen frame: the run-restarts note shows',r,r[0] and 'Opening Big Screen' in r[0] and 'restart there' in r[0] and r[1] is True and r[2]=='fish');await pf.close()
    pf,g=await frame("()=>{fsPond();fsRoll=()=>({id:'reed',rk:'c',cm:30,g:false});fsWait=()=>0.3;fsCast()}");
    r=await g.evaluate("()=>[FS.paused,FS.st,FSZ.why]");chk('B16 a cast line is paused behind the lightbox (and stays paused)',r,r[0] is True and r[2]=='sleep');await pf.wait_for_timeout(1200)
    r2=await g.evaluate("()=>[FS.paused,FS.st]");chk('B16 ... nothing advances while it sleeps',[r,r2],r2[1]==r[1] and r2[0] is True)
    await pf.locator('#g').click(position={'x':600,'y':350});await pf.wait_for_timeout(500);r=await g.evaluate("()=>[FS.paused,FSB.dormant]");chk('B16 the first tap back wakes and resumes it',r,r==[False,False]);await pf.close()
    pf,g=await frame("()=>{wrStart('mill');for(let i=0;i<120;i++)wrUpdate(1/60)}");r=await g.evaluate("()=>[(document.getElementById('fsnote')||{}).textContent,FSB.dormant,S.mode,WRX&&WRX.pause]")
    chk('B16 caravan run in the Big Screen frame: note shows and the run is paused',r,r[0] and 'Opening Big Screen' in r[0] and r[1] is True and r[2]=='wagon' and r[3] is True);await pf.close()
    pf,g=await frame("()=>{title()}");r=await g.evaluate("()=>[!!document.getElementById('fsnote'),FSB.dormant]");chk('B16 title screen is not busy: no note (as before)',r,r==[False,True]);await pf.close()
    pf,g=await frame("()=>{start(1)}");r=await g.evaluate("()=>[(document.getElementById('fsnote')||{}).textContent,S.mode]");chk('B16 a campaign run still counts as busy',r,r[0] and 'Opening Big Screen' in r[0] and r[1]=='pause');await pf.close()
    srv.shutdown()
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch()
        if PART in('all','desk'):await desk(b)
        if PART in('all','touch'):await touch(b)
        if PART in('all','bs'):await bigscreen(b)
        print('bad',BAD[0]);print(ER[:8]);await b.close()
asyncio.run(main())
