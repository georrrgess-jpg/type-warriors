/* ---------- Daily Challenge: twelve new monsters ---------- */
const cogFx=(g,t,q)=>{g.save();g.translate(-4,q.SH+12);g.rotate(t*2);const n=8;g.beginPath();for(let i=0;i<n*2;i++){const a=i*Math.PI/n,r=i%2?7:10;g.lineTo(Math.cos(a)*r,Math.sin(a)*r)}g.closePath();g.fillStyle='#d8a838';g.fill();g.strokeStyle='#4a3010';g.lineWidth=1;g.stroke();ell(g,0,0,3,3,'#2a1a08');g.restore()};
function sporeling(g,t,o){const b=Math.abs(Math.sin(t*8))*3;
 for(const [x,ph] of[[-8,0],[8,Math.PI]]){const a=Math.sin(t*8+ph)*5;limb(g,x,-14,x+a*.5,-3,5.4,'#eadcbc');ell(g,x+a,-2.5,6.8,3,'#c8b890')}
 ell(g,0,-28-b*.4,15,17,vgr(g,-45,-11,'#f6ecd4','#c8b890'));eye(g,-5,-28-b*.4,3,'#2a1a0a');eye(g,5,-28-b*.4,3,'#2a1a0a');g.strokeStyle='#5a3a2a';g.lineWidth=1.6;g.beginPath();g.moveTo(-4,-20-b*.4);g.quadraticCurveTo(0,-16-b*.4,5,-20-b*.4);g.stroke();
 g.save();g.translate(0,-42-b*.4);g.beginPath();g.ellipse(0,0,38,25,0,Math.PI,TAU);g.closePath();g.fillStyle=rgr(g,-10,-14,3,42,'#ff86c4','#8a1a62');g.fill();g.strokeStyle='#000a';g.lineWidth=1.6;g.stroke();
 for(const [x,y,r] of[[-18,-9,5],[4,-16,6.4],[20,-8,4.4],[-4,-5,3.4],[28,-3,2.8]])ell(g,x,y,r,r*.8,'#fff2f8');
 g.fillStyle='#e8c0d8';g.fillRect(-36,-1,72,4);g.restore();
 for(let i=0;i<5;i++){const u=(t*.5+i/5)%1;g.globalAlpha=1-u;glow(g,Math.sin(i*2.7+t)*30,-70-u*50,8,'#ff9ad0aa');g.globalAlpha=1}}
function mimic(g,t,o){const hop=Math.abs(Math.sin(t*6))*9,op=.55+.3*Math.sin(t*5.5)+((o&&o.lg)||0)*.2;
 for(const [x,ph] of[[-22,0],[22,Math.PI]]){const a=Math.sin(t*6+ph)*4;limb(g,x,-hop-8,x+a,-2,6,'#3a2412');poly(g,[x+a-8,-1,x+a+9,-1,x+a+4,-8],'#c8a050')}
 g.save();g.translate(0,-hop);
 g.fillStyle=vgr(g,-40,-6,'#9a6430','#4a2c12');g.beginPath();g.roundRect(-38,-38,76,34,[2,2,8,8]);g.fill();g.strokeStyle='#000a';g.lineWidth=1.6;g.stroke();
 g.fillStyle='#d8a838';g.fillRect(-38,-24,76,5);g.fillRect(-24,-38,6,34);g.fillRect(18,-38,6,34);
 g.fillStyle='#5a0a1a';g.fillRect(-35,-40,70,8);
 g.fillStyle='#fff6e0';for(let i=0;i<7;i++)poly(g,[-34+i*10.6,-39,-29+i*10.6,-39,-31.6+i*10.6,-30],'#fff6e0');
 g.save();g.translate(-36,-38);g.rotate(-op);g.fillStyle=vgr(g,-30,0,'#b87a3a','#6a4018');g.beginPath();g.roundRect(0,-30,76,30,[8,8,2,2]);g.fill();g.strokeStyle='#000a';g.lineWidth=1.6;g.stroke();g.fillStyle='#d8a838';g.fillRect(0,-8,76,5);g.fillRect(14,-30,6,30);g.fillRect(56,-30,6,30);
 g.fillStyle='#5a0a1a';g.fillRect(2,-6,72,5);for(let i=0;i<7;i++)poly(g,[3+i*10.6,-5,8+i*10.6,-5,5.6+i*10.6,3],'#fff6e0');
 ell(g,22,-20,5.4,5.4,'#ffe04a');ell(g,54,-20,5.4,5.4,'#ffe04a');ell(g,22,-20,1.6,3.6,'#2a1000');ell(g,54,-20,1.6,3.6,'#2a1000');g.restore();
 g.strokeStyle='#ff6a8a';g.lineWidth=5;g.lineCap='round';g.beginPath();g.moveTo(-10,-34);g.quadraticCurveTo(-4,-22+Math.sin(t*9)*4,10,-30);g.stroke();
 gem(g,0,-14,3,'#ffd76a');g.restore();
 for(let i=0;i<3;i++){const u=(t*.8+i/3)%1;g.globalAlpha=1-u;coin(g,-14+i*14,-50-u*30,4);g.globalAlpha=1}}
function gearbat(g,t,o){const cy=-50+Math.sin(t*6)*6,fl=Math.sin(t*14);glow(g,0,cy,64,'#ffb03066');
 for(const s of[-1,1]){g.save();g.translate(s*9,cy-2);g.rotate(s*(.35+fl*.5));for(let i=0;i<4;i++){const a=-.9+i*.55;poly(g,[0,0,Math.cos(a)*(36-i*3)*s,Math.sin(a)*(36-i*3)-6,Math.cos(a+.3)*(30-i*3)*s,Math.sin(a+.3)*(30-i*3)],vgr(g,-30,0,'#c8b890','#6a5a3a'),'#2a1a08',1)}g.restore()}
 ell(g,0,cy,15,13,rgr(g,-4,cy-5,2,20,'#e8c868','#6a4a18'));g.save();g.translate(0,cy);g.rotate(t*3);g.beginPath();for(let i=0;i<12;i++){const a=i*Math.PI/6,r=i%2?5:8;g.lineTo(Math.cos(a)*r,Math.sin(a)*r)}g.closePath();g.fillStyle='#4a3010';g.fill();g.restore();
 eye(g,-6,cy-6,2.6,'#ff4a2a');eye(g,6,cy-6,2.6,'#ff4a2a');poly(g,[-9,cy-12,-6,cy-20,-3,cy-12],'#c8b890');poly(g,[9,cy-12,6,cy-20,3,cy-12],'#c8b890')}
function pixie(g,t,o){const cy=-50+Math.sin(t*5)*7,fl=Math.sin(t*22);glow(g,0,cy,70,'#9affd888');
 for(const s of[-1,1]){g.save();g.translate(s*4,cy-2);g.rotate(s*(.5+fl*.35));g.globalAlpha=.8;ell(g,s*14,-10,16,7,'#d8fff4',s*.5);ell(g,s*12,6,11,5,'#b8ffe8',-s*.4);g.restore()}
 ell(g,0,cy+7,5,8,'#3ad8a8');ell(g,0,cy-4,8,8,'#ffe8d0');eye(g,-2.6,cy-5,1.9,'#2a1a3a');eye(g,2.8,cy-5,1.9,'#2a1a3a');
 poly(g,[-8,cy-8,0,cy-20,8,cy-8],'#7affd0','#0a5a3a',1);
 for(let i=0;i<7;i++){const u=(t*.9+i/7)%1;g.globalAlpha=1-u;sparkle(g,12+u*46,cy+Math.sin(i*2+t*6)*10,3.2,1,'#d8fff4');g.globalAlpha=1}}
function dustdevil(g,t,o){glow(g,0,-44,84,'#e8b86a55');
 for(let i=0;i<9;i++){const u=i/8,y=-4-u*84,w=10+u*28,x=Math.sin(t*5+i*.9)*6*(1-u*.4);g.globalAlpha=.85;ell(g,x,y,w,6+u*3,i%2?'#e8c888':'#c89a58',0);g.globalAlpha=1}
 eye(g,-6,-52,3.2,'#2a1408');eye(g,7,-52,3.2,'#2a1408');g.strokeStyle='#2a1408';g.lineWidth=2;g.beginPath();g.moveTo(-6,-42);g.quadraticCurveTo(0,-38,7,-42);g.stroke();
 for(let i=0;i<8;i++){const a=t*4+i*.8,r=22+i*3;ell(g,Math.cos(a)*r,-12-i*9+Math.sin(a)*3,2.4,1.6,'#6a4a2a')}}
function lanternWraith(g,t,o){const cy=-52+Math.sin(t*3)*6,sw=Math.sin(t*3.4)*5;glow(g,0,cy+10,76,'#7affd855');
 g.beginPath();g.moveTo(-18,cy-14);g.quadraticCurveTo(-34,cy+20,-26,cy+44+Math.sin(t*5)*3);for(let i=0;i<5;i++)g.lineTo(-26+i*13,cy+44+(i%2?-8:2)+Math.sin(t*6+i)*3);g.quadraticCurveTo(34,cy+20,18,cy-14);g.closePath();g.fillStyle=vgr(g,cy-16,cy+48,'#6a9a9a','#1a3a4a');g.fill();g.strokeStyle='#000a';g.lineWidth=1.6;g.stroke();
 ell(g,0,cy-14,17,19,'#0a1a24');eye(g,-6,cy-14,3,'#7affd8');eye(g,6,cy-14,3,'#7affd8');
 limb(g,-18,cy+4,-32+sw,cy+22,4.6,'#3a5a6a');g.strokeStyle='#2a1a10';g.lineWidth=1.8;g.beginPath();g.moveTo(-32+sw,cy+22);g.lineTo(-36+sw*1.4,cy+34);g.stroke();
 const lx=-36+sw*1.4,ly=cy+46;glow(g,lx,ly,50,'#ffd76acc');poly(g,[lx-9,ly-8,lx+9,ly-8,lx+11,ly+10,lx-11,ly+10],'#ffcf5a','#6a4a10',1.4);poly(g,[lx-7,ly-14,lx+7,ly-14,lx+9,ly-8,lx-9,ly-8],'#4a3a1a');ell(g,lx,ly+1,4,5,'#fffbe0')}
const metalFx=(c1)=>(g,t,q)=>{for(const [x,y] of[[-14,q.SH+6],[10,q.SH+10],[-4,q.SH+20]]){ell(g,x,y,2.4,2.4,c1);}};
Object.assign(DR,{sporeling,mimic,gearbat,pixie,dustdevil,lantern:lanternWraith,
 cogbot:(g,t,o)=>hum(g,t,{lg:o.lg,sk:'#9a8a6a',dk:'#4a3e2a',cl:'#5a4a30',top:'#6a5a3a',hd:13,eye:'#ffb030',wp:'sword',bl:'#d0c8b8',bulk:1.15,reach:5,legH:32,pad:'#b89a50',aura:'#ffb030',walk:.9,fx:cogFx}),
 raider:(g,t,o)=>hum(g,t,{lg:o.lg,sk:'#c89a6a',dk:'#6a4a2a',cl:'#8a2a1a',top:'#b0402a',hd:12,eye:'#fff0a0',wp:'sword',bl:'#ece4d4',bulk:.92,legH:34,hunch:.4,cape:'#d8a860',walk:1.15,pad:'#d8a860'}),
 ironcol:(g,t,o)=>hum(g,t,{lg:o.lg,sk:'#6a7078',dk:'#2a2e36',cl:'#3a3e48',hd:13,eye:'#ff8a2a',wp:'club',wsc:1.5,bulk:1.9,lw:12,reach:8,legH:32,belly:1,pad:'#8a9098',padspike:1,aura:'#ff8a2a',fx:(g2,t2,q)=>{cogFx(g2,t2,q);for(let i=0;i<3;i++){const u=(t2*.7+i/3)%1;g2.globalAlpha=(1-u)*.6;ell(g2,-8+i*9,-96-u*30,5+u*8,4+u*6,'#dde4ea');g2.globalAlpha=1}}}),
 mossgol:(g,t,o)=>hum(g,t,{lg:o.lg,sk:'#7a8a70',dk:'#3a4a38',cl:'#4a5a40',hd:14,eye:'#c8ff7a',wp:'club',wsc:1.4,bulk:1.9,lw:12,reach:8,legH:32,belly:1,hunch:1.1,fx:(g2,t2,q)=>{ell(g2,-12,q.SH+3,14,6,'#4a8a3a');ell(g2,10,q.SH+12,10,5,'#5a9a44');for(const x of[-16,2,14]){g2.fillStyle='#e8d8b8';g2.fillRect(x-1,q.SH-6,2.4,7);ell(g2,x,q.SH-8,5,3.4,'#ff86c4')}}}),
 sandgol:(g,t,o)=>hum(g,t,{lg:o.lg,sk:'#d8b078',dk:'#8a6a3a',cl:'#b08a50',hd:13,eye:'#fff0a0',wp:'club',wsc:1.5,bulk:1.85,lw:12,reach:8,legH:32,belly:1,aura:'#ffd88a',fx:(g2,t2,q)=>{g2.strokeStyle='#6a4a22';g2.lineWidth=1.6;for(const p of[[-12,q.SH+6,-2,q.SH+14,-10,q.SH+24],[8,q.SH+4,14,q.SH+16,6,q.SH+26]]){g2.beginPath();g2.moveTo(p[0],p[1]);g2.lineTo(p[2],p[3]);g2.lineTo(p[4],p[5]);g2.stroke()}for(let i=0;i<4;i++){const u=(t2*.6+i/4)%1;g2.globalAlpha=1-u;ell(g2,-14+i*9,-60-u*26,2.2,1.6,'#e8c888');g2.globalAlpha=1}}}),
 crystgol:(g,t,o)=>hum(g,t,{lg:o.lg,sk:'#8a7ae0',dk:'#3a2a8a',cl:'#4a3a9a',hd:14,eye:'#ffffff',wp:'club',wsc:1.4,bulk:1.9,lw:12,reach:8,legH:32,belly:1,aura:'#c8b8ff',fx:(g2,t2,q)=>{for(const [x,h] of[[-18,34],[0,44],[16,30]]){g2.save();g2.translate(x,q.SH-2);poly(g2,[-6,0,-3,-h,3,-h*.9,7,0],vgr(g2,-h,0,'#f0e8ff','#7a5ad8'),'#1a0a4a',1.2);g2.restore()}for(let i=0;i<4;i++)sparkle(g2,Math.sin(t2*2+i*1.6)*22,q.SH-30+Math.cos(t2*3+i)*14,3,.5+.5*Math.sin(t2*6+i),'#fff')}})});
Object.assign(MON,{
 cogbot:{n:'Cog Soldier',h:146,sp:54,th:98,pj:'bone',ds:'A clockwork soldier from the Foundry. Marches in step.'},
 raider:{n:'Dune Raider',h:142,sp:68,th:98,ds:'Fast on the sand and quick with a blade.'},
 sporeling:{n:'Sporecap',h:118,sp:60,th:80,ds:'A walking mushroom that sheds sleepy spores.'},
 mimic:{n:'Mimic',h:112,sp:64,th:72,ds:'It looked like treasure. It was not.'},
 gearbat:{n:'Gear Wing',h:96,sp:118,th:70,fly:1,ds:'A brass bat that ticks as it dives.'},
 pixie:{n:'Glimmer Pixie',h:88,sp:130,th:64,fly:1,ds:'A bright, jittery flier. Do not blink.'},
 dustdevil:{n:'Dust Devil',h:116,sp:110,th:84,fly:1,ds:'A spinning pillar of sand with an angry face.'},
 lantern:{n:'Lantern Wraith',h:150,sp:70,th:110,fly:1,ds:'A ghost that lures travellers with a pale lantern.'},
 ironcol:{n:'Iron Colossus',h:228,sp:30,th:120,ds:'A towering war machine, slow but crushing.'},
 mossgol:{n:'Moss Golem',h:222,sp:30,th:118,ds:'Stone, moss and patience.'},
 sandgol:{n:'Sand Golem',h:224,sp:30,th:118,ds:'The desert given a fist.'},
 crystgol:{n:'Crystal Titan',h:232,sp:30,th:120,ds:'A walking geode that hums with power.'}});
for(const k of['cogbot','raider','sporeling','mimic','gearbat','pixie','dustdevil','lantern','ironcol','mossgol','sandgol','crystgol'])MON[k].d=DR[k];
const DCMOB=['cogbot','raider','sporeling','mimic','gearbat','pixie','dustdevil','lantern','ironcol','mossgol','sandgol','crystgol'];
