import asyncio,os
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900},device_scale_factor=1.5);er=[]
        pg.on('pageerror',lambda e:er.append('PE '+str(e)[:300]))
        await pg.goto('file://'+os.path.abspath('out.html'));await pg.wait_for_timeout(900);E=pg.evaluate;bad=0
        def chk(name,ok,val):
            nonlocal bad;bad+=not ok;print(name,val,'OK' if ok else 'BAD')
        r=await E("()=>[ST.perf,ST.tvis,RS,document.body.classList.contains('tv')]");chk('defaults',r[0]=='high' and r[1]=='off' and r[2]>1 and not r[3],r)
        await E("()=>{RS_ASK=false;ST.perfAsked=1;settings.tab='Display';settings(title)}");await pg.wait_for_timeout(300)
        r=await E("()=>[...document.querySelectorAll('.opt label')].filter(l=>l.offsetParent).map(l=>l.textContent)");chk('display tab rows','Text visibility' in r and 'Performance mode' in r,r)
        await pg.click('[data-k="tvis"][data-v="on"]');await pg.wait_for_timeout(300)
        r=await E("()=>[ST.tvis,document.body.classList.contains('tv'),!!document.getElementById('tvcss'),document.querySelector('[data-k=tvis][data-v=on]').classList.contains('on')]");chk('clear on',all(r[1:]) and r[0]=='on',r)
        r=await E("()=>{const t=document.querySelector('.ctabs .tab.on');return getComputedStyle(t).color}");chk('selected tab keeps dark text',r.startswith('rgb(') and sum(int(x) for x in r[4:-1].split(',')[:3])<300,r)
        await pg.click('[data-k="perf"][data-v="bal"]');await pg.wait_for_timeout(300)
        r=await E("()=>[ST.perf,RS,cv.width]");chk('balanced caps resolution',r[0]=='bal' and r[1]==1 and r[2]==1600,r)
        await pg.click('[data-k="perf"][data-v="low"]');await pg.wait_for_timeout(300)
        r=await E("()=>[ST.perf,RS,cv.width,document.body.classList.contains('pf-low')]");chk('performance',r[0]=='low' and r[1]==.75 and r[2]==1200 and r[3],r)
        r=await E("()=>{const c=document.createElement('canvas').getContext('2d');c.shadowBlur=20;return c.shadowBlur}");chk('no shadow blur',r==0,r)
        await E("()=>{title()}");await pg.wait_for_timeout(1800)
        r=await E("()=>[document.getAnimations().filter(a=>a.playState==='running'&&a.effect&&a.effect.getTiming().iterations===Infinity&&a.constructor.name==='CSSAnimation').length,PFA.paused.size]");chk('looping css rests',r[0]==0,r)
        await E("()=>{hide();start(3)}");await pg.wait_for_timeout(1500)
        r=await E("()=>new Promise(res=>{let n=0,f=0;const t0=performance.now();const s=()=>{f++;if(performance.now()-t0<1500)requestAnimationFrame(s);else res([PFBG.ok,PFBG.key.split('|')[0],f])};requestAnimationFrame(s)})");chk('bg cache in play',r[0] and r[1]=='play',r)
        await E("()=>{S.shake=20}");r=await E("()=>new Promise(res=>requestAnimationFrame(()=>requestAnimationFrame(()=>res(PFBG.ok))))");chk('no cache while shaking',r is False,r)
        await E("()=>{S.shake=0;over(true)}");await pg.wait_for_timeout(500)
        # persistence
        await E("()=>{saveST();loadST();applyLayout()}");r=await E("()=>[ST.perf,ST.tvis,RS,document.body.classList.contains('tv')]");chk('persist',r[0]=='low' and r[1]=='on' and r[3],r)
        # back to quality restores everything
        await E("()=>{ST.perf='high';ST.tvis='off';applyLayout()}");await pg.wait_for_timeout(1300)
        r=await E("()=>{const c=document.createElement('canvas').getContext('2d');c.shadowBlur=20;return [RS,c.shadowBlur,document.body.classList.contains('pf-low'),document.body.classList.contains('tv'),PFA.paused.size]}");chk('quality restored',r[0]>1 and r[1]==20 and not r[2] and not r[3] and r[4]==0,r)
        # the slow-game offer
        await E("()=>{ST.perfAsked=0;PFW.asked=false;title();pfOffer()}");await pg.wait_for_timeout(400)
        r=await E("()=>!!document.getElementById('pfask')");chk('offer shows',r,r);await pg.screenshot(path='shots/pfoffer.png')
        await pg.click('#pfask .pfy');await pg.wait_for_timeout(400)
        r=await E("()=>[ST.perf,ST.perfAsked,!!document.getElementById('pfask')]");chk('offer accepted',r[0]=='low' and r[1]==1 and not r[2],r)
        await E("()=>pfOffer()");r=await E("()=>!!document.getElementById('pfask')");chk('offered only once',not r,r)
        print('bad',bad);print(er);await b.close()
asyncio.run(main())
