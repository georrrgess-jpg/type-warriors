/* ---------- casino: slots, roulette, dice, mines ---------- */
const SLW={cherry:7,lemon:6,bell:4,gem:3,seven:2,crown:2},SLP={cherry:5,lemon:8,bell:20,gem:50,seven:150,crown:100},SLN={cherry:'cherries',lemon:'lemons',bell:'bells',gem:'gems',seven:'sevens',crown:'crowns'};
function slotPay(a,b,c){if(a===b&&b===c)return SLP[a];const ch=(a==='cherry')+(b==='cherry')+(c==='cherry');return ch===2?2:0}
function roWin(k,n){if(k[0]==='n')return +k.slice(1)===n;if(n===0)return false;switch(k){case'red':return ROR.has(n);case'black':return!ROR.has(n);case'odd':return n%2===1;case'even':return n%2===0;case'lo':return n<=18;case'hi':return n>=19;case'd1':return n<=12;case'd2':return n>12&&n<=24;case'd3':return n>24}return false}
const roMul=k=>k[0]==='n'?36:k[0]==='d'?3:2;
/* ---------- dice ---------- */
function mDI(el,tok){
 const alive=()=>CAS.tok===tok;let over=false,chance=49,st='idle',bet=0;
 el.innerHTML=`<div class="felt" style="height:auto;padding:22px 20px"><div class="dice"><div class="dn0" id="dn">50.00</div><div class="dbar" id="db"><div class="gz" id="dg"></div><div class="dmk" id="dm"></div></div>
<input class="dsl" id="ds" type="range" min="2" max="95" step="1" value="49" aria-label="Win chance"><div class="seg2"><button id="dun" class="on">Roll under</button><button id="dov">Roll over</button></div>
<div class="dst"><span>Win chance<b id="dc"></b></span><span>Multiplier<b id="dx"></b></span><span>You win<b id="dw"></b></span></div></div></div>
<p class="cmsg" id="cm"> </p><div class="ctl">${betBar()}<div class="btns"><button class="bbig" id="dr">Roll</button></div></div>`;
 const mult=()=>Math.floor(9600/chance)/100;
 const U=()=>{const th=over?100-chance:chance;$('dg').style.left=over?th+'%':'0';$('dg').style.width=chance+'%';$('dc').textContent=chance+'%';$('dx').textContent='×'+mult().toFixed(2);$('dw').textContent=cmn(Math.floor(CAS.bet*mult()));$('dun').classList.toggle('on',!over);$('dov').classList.toggle('on',over);
  $('dun').textContent='Roll under '+chance;$('dov').textContent='Roll over '+(100-chance)};
 const roll=async()=>{if(st!=='idle'||CAS.lock)return;if(CAS.bet<1){msg(broke()||'Place a bet first.');return}if(CAS.bet>P.gold){msg('Not enough gold.');return}bet=CAS.bet;if(!cTake(bet))return;betLock(true);st='roll';$('dn').style.color='';$('dr').disabled=$('ds').disabled=$('dun').disabled=$('dov').disabled=true;msg('');
  const r=Math.floor(Math.random()*10000)/100,win=over?r>=100-chance:r<chance;const t0=performance.now();
  while(performance.now()-t0<850){if(!alive())return;$('dn').textContent=(Math.random()*100).toFixed(2);beep(300+Math.random()*300,.02,'square',.15);await csleep(55)}
  if(!alive())return;$('dn').textContent=r.toFixed(2);$('dm').style.left=`calc(${r}% - 3px)`;$('dn').style.color=win?'#7dff9a':'#ff8a98';await csleep(500);if(!alive())return;
  const pay=win?Math.floor(bet*mult()):0;cPay(bet,pay);msg(win?`${r.toFixed(2)} is ${over?'over '+(100-chance):'under '+chance}. You win +${cmn(pay-bet)}`:`${r.toFixed(2)} is ${over?'not over '+(100-chance):'not under '+chance}. −${cmn(bet)}.${broke()?' '+broke():''}`,win?'w':'l');
  st='idle';betLock(false);$('dr').disabled=$('ds').disabled=$('dun').disabled=$('dov').disabled=false;U()};
 $('ds').oninput=()=>{chance=+$('ds').value;U()};$('dun').onclick=()=>{over=false;U()};$('dov').onclick=()=>{over=true;U()};$('dr').onclick=roll;
 wireBet(U);CAS.key={' ':roll,enter:roll};U();msg('Slide the win chance, choose over or under, and roll. Space rolls.')}

/* ---------- mines ---------- */
function mMI(el,tok){
 const alive=()=>CAS.tok===tok;let nm=3,mines=new Set(),rev=new Set(),ph='idle',bet=0;
 const mult=k=>{if(k<1)return 1;let m=.96;for(let i=0;i<k;i++)m*=(25-i)/(25-nm-i);return Math.floor(m*100+1e-6)/100};
 el.innerHTML=`<div class="felt" style="flex-direction:row;gap:60px;padding:18px 40px"><div class="mgrid" id="mg">${Array.from({length:25},(_,i)=>`<button class="mt" data-i="${i}" disabled aria-label="Tile ${i+1}"></button>`).join('')}</div>
<div class="msi"><span>Bombs</span><div class="seg2" id="mn">${[1,3,5,10,15,24].map(v=>`<button data-n="${v}" class="${v===3?'on':''}">${v}</button>`).join('')}</div><span>Gems found <b id="mk">0</b></span><span>Multiplier <b id="mm">1.00×</b></span><span>Next gem <b id="mx"></b></span><span>Payout now <b id="mp">0</b></span></div></div>
<p class="cmsg" id="cm"> </p><div class="ctl">${betBar()}<div class="btns"><button class="bbig" id="m0">Start</button><button class="bbig" id="mc" style="display:none">Cash out</button></div></div>`;
 const tiles=()=>[...ov.querySelectorAll('#mg .mt')];
 const U=()=>{const k=rev.size,safe=25-nm;$('mk').textContent=k+' / '+safe;$('mm').textContent=mult(k).toFixed(2)+'×';$('mx').textContent=k<safe?'×'+mult(k+1).toFixed(2):'-';$('mp').textContent=cmn(ph==='play'?bet*mult(k):0);
  $('m0').style.display=ph==='idle'?'':'none';$('mc').style.display=ph==='play'?'':'none';$('mc').disabled=k<1;$('mc').textContent='Cash out '+cmn(bet*mult(k));
  ov.querySelectorAll('#mn button').forEach(b=>{b.disabled=ph!=='idle';b.classList.toggle('on',+b.dataset.n===nm)})};
 const end=(hit,i)=>{const T=tiles();T.forEach((b,j)=>{b.disabled=true;if(mines.has(j)){b.innerHTML=BOMB;b.classList.add(j===i?'bad':'dim')}else if(!rev.has(j)){b.innerHTML=GEM;b.classList.add('dim')}})};
 const finish=(cashed)=>{const k=rev.size,pay=cashed?Math.floor(bet*mult(k)):0;ph='idle';cPay(bet,pay);if(cashed)msg(`Cashed out ${mult(k).toFixed(2)}×  +${cmn(pay-bet)}`,'w');betLock(false);U();$('m0').textContent='Play again'};
 const start=()=>{if(ph!=='idle'||CAS.lock)return;if(CAS.bet<1){msg(broke()||'Place a bet first.');return}if(CAS.bet>P.gold){msg('Not enough gold.');return}bet=CAS.bet;if(!cTake(bet))return;betLock(true);
  mines=new Set();while(mines.size<nm)mines.add(Math.random()*25|0);rev=new Set();ph='play';tiles().forEach(b=>{b.className='mt';b.innerHTML='';b.disabled=false});U();msg('Uncover gems. Avoid the bombs.');beep(520,.05,'triangle',.5)};
 const pick=i=>{if(ph!=='play'||rev.has(i))return;const b=tiles()[i];
  if(mines.has(i)){ph='x';end(true,i);msg(`Boom! You lose ${cmn(bet)}.${broke()?' '+broke():''}`,'l');beep(90,.4,'sawtooth',.8);ph='play';finishLoss()}
  else{rev.add(i);b.className='mt ok';b.innerHTML=GEM;b.disabled=true;beep(660+rev.size*30,.07,'triangle',.6);U();if(rev.size>=25-nm){msg('Every gem found!','w');end(false,-1);finish(true)}}};
 const finishLoss=()=>{ph='idle';cPay(bet,0);betLock(false);U();$('m0').textContent='Play again'};
 const cash=()=>{if(ph!=='play'||rev.size<1)return;end(false,-1);finish(true)};
 tiles().forEach(b=>b.onclick=()=>pick(+b.dataset.i));$('m0').onclick=start;$('mc').onclick=cash;
 ov.querySelectorAll('#mn button').forEach(b=>b.onclick=()=>{if(ph!=='idle')return;nm=+b.dataset.n;U()});
 wireBet(U);CAS.key={' ':()=>{ph==='idle'?start():cash()},enter:()=>{if(ph==='idle')start()},c:cash};U();msg('Choose how many bombs, place your bet and press Start. Space starts or cashes out.')}
