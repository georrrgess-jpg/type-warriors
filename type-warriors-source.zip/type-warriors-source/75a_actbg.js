/* ---------- campaign: one painted, animated backdrop per act ---------- */
const ABW=1600,ABH=900,ABC={},ABS={};
const abSprite=(k,w,h,fn)=>{if(ABS[k])return ABS[k];const c=document.createElement('canvas');c.width=w;c.height=h;fn(c.getContext('2d'),w,h);return ABS[k]=c};
const abLin=(g,y0,y1,st)=>{const q=g.createLinearGradient(0,y0,0,y1);st.forEach(([o,c])=>q.addColorStop(o,c));return q};
function abRidge(g,base,amp,seed,fill,f,jag){g.beginPath();g.moveTo(0,ABH);for(let x=0;x<=ABW+8;x+=8){const y=base-amp*(Math.sin(x*f+seed)*.5+Math.sin(x*f*2.3+seed*1.7)*.28+Math.sin(x*f*5.1+seed*.6)*.14)+(jag?(rnd(x/8+seed*9)-.5)*jag:0);g.lineTo(x,y)}g.lineTo(ABW+8,ABH);g.closePath();g.fillStyle=fill;g.fill()}
function abStars(g,n,seed,y1,col,big){for(let i=0;i<n;i++){const x=rnd(i*3+seed)*ABW,y=rnd(i*3+seed+1)*y1,r=.5+rnd(i*3+seed+2)*(big||1.5);g.globalAlpha=.35+rnd(i+seed*2)*.65;g.fillStyle=col;g.beginPath();g.arc(x,y,r,0,TAU);g.fill()}g.globalAlpha=1}
function abMoon(g,x,y,r,c0,c1,halo){glow(g,x,y,r*3.4,halo);g.beginPath();g.arc(x,y,r,0,TAU);g.fillStyle=rgr(g,x-r*.3,y-r*.3,r*.1,r*1.05,c0,c1);g.fill();g.save();g.clip();g.fillStyle='#00000018';for(let i=0;i<9;i++){const a=rnd(i+3)*TAU,d=rnd(i+9)*r*.8;g.beginPath();g.arc(x+Math.cos(a)*d,y+Math.sin(a)*d,r*(.08+rnd(i+15)*.14),0,TAU);g.fill()}g.restore()}
function abPine(g,x,y,h,col){const w=h*.24;g.fillStyle=col;g.fillRect(x-h*.025,y-h*.12,h*.05,h*.14);for(let i=0;i<4;i++){const ty=y-h+i*h*.2,by=y-h*.1-(3-i)*h*.1,hw=w*(.5+i*.2);g.beginPath();g.moveTo(x,ty);g.lineTo(x+hw,by);g.lineTo(x-hw,by);g.closePath();g.fill()}}
function abDead(g,x,y,h,col,seed){g.strokeStyle=col;g.lineCap='round';const br=(bx,by,len,ang,w,d)=>{g.lineWidth=w;const ex=bx+Math.cos(ang)*len,ey=by+Math.sin(ang)*len;g.beginPath();g.moveTo(bx,by);g.quadraticCurveTo((bx+ex)/2+rnd(d+seed)*10-5,(by+ey)/2,ex,ey);g.stroke();if(d<4&&w>1.2){br(ex,ey,len*.7,ang-.5-rnd(d*3+seed)*.4,w*.62,d+1);br(ex,ey,len*.66,ang+.5+rnd(d*5+seed)*.4,w*.62,d+1)}};br(x,y,h*.38,-Math.PI/2+(rnd(seed)-.5)*.3,h*.05+2,0);br(x,y-h*.2,h*.26,-Math.PI/2-.8,h*.03+1,1);br(x,y-h*.28,h*.24,-Math.PI/2+.85,h*.03+1,1)}
function abCastle(g,x,y,s,col,win,wc){g.save();g.translate(x,y);g.scale(s,s);g.fillStyle=col;g.fillRect(-170,-110,340,112);
 const T=[[-165,60,250,0],[-70,46,190,1],[34,64,310,0],[140,52,210,1],[185,38,150,1]];
 for(const [cx,w,h,b] of T){g.beginPath();g.moveTo(cx-w/2,2);g.lineTo(cx-w/2,-h);if(b){g.lineTo(cx-w/2+8,-h-10);g.lineTo(cx-w/6,-h+16);g.lineTo(cx+w/8,-h-8);g.lineTo(cx+w/2-6,-h+24);g.lineTo(cx+w/2,-h+10)}else{for(let k=0;k<5;k++){const u=cx-w/2+k*w/5;g.lineTo(u,-h-12);g.lineTo(u+w/10,-h-12);g.lineTo(u+w/10,-h);g.lineTo(u+w/5,-h)}g.lineTo(cx+w/2,-h)}g.lineTo(cx+w/2,2);g.closePath();g.fill()}
 // a spire and a leaning flag
 g.beginPath();g.moveTo(34-24,-310);g.lineTo(34,-398);g.lineTo(34+24,-310);g.closePath();g.fill();g.strokeStyle=col;g.lineWidth=3;g.beginPath();g.moveTo(34,-398);g.lineTo(34,-428);g.stroke();g.beginPath();g.moveTo(34,-428);g.lineTo(64,-418);g.lineTo(34,-408);g.fill();
 // gate arch and windows
 g.globalCompositeOperation='destination-out';g.beginPath();g.moveTo(-26,2);g.lineTo(-26,-50);g.arc(0,-50,26,Math.PI,0);g.lineTo(26,2);g.fill();g.globalCompositeOperation='source-over';
 const wc2=wc||win;for(const [wx,wy] of [[-165,-170],[34,-240],[34,-170],[-70,-130],[140,-140],[-100,-70],[100,-70],[-165,-110]]){glow(g,wx,wy,26,win+'66');g.fillStyle=wc2;g.beginPath();g.moveTo(wx-5,wy+11);g.lineTo(wx-5,wy-3);g.arc(wx,wy-3,5,Math.PI,0);g.lineTo(wx+5,wy+11);g.fill()}
 g.restore()}
function abShip(g,x,y,s,tilt,col,sail){g.save();g.translate(x,y);g.rotate(tilt);g.scale(s,s);g.fillStyle=col;g.strokeStyle=col;g.beginPath();g.moveTo(-92,-22);g.quadraticCurveTo(-72,30,-10,34);g.lineTo(82,26);g.quadraticCurveTo(112,6,122,-38);g.lineTo(98,-26);g.lineTo(-92,-22);g.closePath();g.fill();
 g.lineWidth=5;g.beginPath();g.moveTo(-22,-20);g.lineTo(-32,-146);g.moveTo(42,-24);g.lineTo(58,-112);g.stroke();g.lineWidth=3;g.beginPath();g.moveTo(-60,-110);g.lineTo(8,-118);g.moveTo(34,-90);g.lineTo(84,-96);g.stroke();
 g.globalAlpha=sail||1;g.beginPath();g.moveTo(-32,-132);g.lineTo(-84,-72);g.lineTo(-58,-84);g.lineTo(-70,-34);g.lineTo(-26,-62);g.closePath();g.fill();g.beginPath();g.moveTo(58,-104);g.lineTo(96,-60);g.lineTo(76,-68);g.lineTo(84,-34);g.lineTo(54,-52);g.closePath();g.fill();g.globalAlpha=1;
 g.lineWidth=1.5;g.beginPath();g.moveTo(-32,-146);g.lineTo(-90,-24);g.moveTo(-32,-146);g.lineTo(30,-22);g.moveTo(58,-112);g.lineTo(118,-36);g.stroke();g.restore()}
function abTomb(g,x,y,s,col,k){g.fillStyle=col;g.save();g.translate(x,y);g.scale(s,s);if(k%3===0){g.beginPath();g.moveTo(-16,0);g.lineTo(-16,-40);g.arc(0,-40,16,Math.PI,0);g.lineTo(16,0);g.fill()}else if(k%3===1){g.fillRect(-4,-56,8,56);g.fillRect(-18,-42,36,8)}else{g.beginPath();g.moveTo(-18,0);g.lineTo(-14,-34);g.lineTo(-4,-44);g.lineTo(8,-36);g.lineTo(16,-30);g.lineTo(18,0);g.fill()}g.restore()}
const abCloud=(k,w,h,c0,c1,seed)=>abSprite(k,w,h,(g)=>{for(let i=0;i<16;i++){const r=h*(.16+rnd(seed+i+40)*.2),cx=w*(.14+rnd(seed+i)*.72),cy=h*.5+(rnd(seed+i+20)-.5)*(h*.5-r)*1.6;const q=g.createRadialGradient(cx,cy-r*.2,0,cx,cy,r);q.addColorStop(0,c0);q.addColorStop(1,c1);g.fillStyle=q;g.fillRect(cx-r,cy-r,r*2,r*2)}});
const abFog=(k,c)=>abSprite(k,1600,240,(g,w,h)=>{for(let i=0;i<9;i++){const cx=(i/8)*w,r=70+rnd(i+2)*46,cy=h*(.5+(rnd(i+7)-.5)*.3);const q=g.createRadialGradient(cx,cy,0,cx,cy,r);q.addColorStop(0,c);q.addColorStop(1,c.slice(0,7)+'00');g.fillStyle=q;g.fillRect(cx-r,cy-r,r*2,r*2);if(cx<r){g.save();g.translate(w,0);g.fillStyle=q;g.fillRect(cx-r,cy-r,r*2,r*2);g.restore()}}});
function abDrift(g,spr,x0,y,speed,t,al,sc){const w=spr.width*(sc||1);let x=((x0+t*speed)%w+w)%w-w;g.globalAlpha=al;for(;x<ABW;x+=w)g.drawImage(spr,x,y,w,spr.height*(sc||1));g.globalAlpha=1}
const abFlash=t=>{const u=t%6.7;return u<.09?1-u/.09:(u>.3&&u<.46?.55*(1-(u-.3)/.16):0)};

/* ===== static layers ===== */
const ABST=[
 /* I: a dawn over the goblin wood */
 g=>{g.fillStyle=abLin(g,0,ABH,[[0,'#16264a'],[.34,'#4a5f98'],[.58,'#c8869a'],[.74,'#ffb877'],[1,'#ffd9a0']]);g.fillRect(0,0,ABW,ABH);abStars(g,70,5,300,'#fff',1.2);
  glow(g,1090,610,520,'#ffd89a88');glow(g,1090,610,220,'#fff1c4cc');g.fillStyle='#fff4d0';g.beginPath();g.arc(1090,610,52,0,TAU);g.fill();
  abRidge(g,560,170,1.2,'#6a7aa8',.0042);abRidge(g,610,120,3.4,'#52638f',.0055,10);
  /* far village on a hill */
  g.fillStyle='#3f4f7c';g.fillRect(250,498,34,70);g.beginPath();g.moveTo(244,498);g.lineTo(267,452);g.lineTo(290,498);g.fill();glow(g,267,520,24,'#ffcf7a88');
  abCastle(g,420,596,.55,'#3c4a78','#ffd37a');abRidge(g,690,110,5.6,'#36507a',.0063);
  for(let i=0;i<60;i++)abPine(g,rnd(i)*ABW,710+rnd(i+30)*50,60+rnd(i+60)*50,'#2a4a62');abRidge(g,770,70,2.1,'#223c54',.007);
  for(let i=0;i<30;i=i+1)abPine(g,rnd(i+100)*ABW,810+rnd(i+130)*50,110+rnd(i+160)*90,'#12273a');abRidge(g,860,40,7.3,'#0c1c2c',.01,14);
  for(let i=0;i<10;i++)abPine(g,20+i*170+rnd(i)*90,905,250+rnd(i+50)*130,'#070f1a')},
 /* II: moon over a haunted graveyard */
 g=>{g.fillStyle=abLin(g,0,ABH,[[0,'#09051c'],[.4,'#2a1650'],[.7,'#6a3a82'],[1,'#a2589a']]);g.fillRect(0,0,ABW,ABH);abStars(g,130,9,520,'#e8dcff',1.4);
  abMoon(g,690,330,118,'#fff6ff','#cdbce8','#c8a8ff77');
  abRidge(g,600,150,.8,'#3e2260',.0045);abRidge(g,650,110,4.1,'#2e1a4e',.006,8);
  for(let i=0;i<34;i++)abDead(g,rnd(i+300)*ABW,680+rnd(i+50)*50,90+rnd(i+80)*80,'#1f1238',i);
  /* the manor on the hill */
  g.fillStyle='#160c2a';g.beginPath();g.ellipse(1060,740,320,70,0,Math.PI,0);g.fill();abCastle(g,1060,742,.78,'#160c2a','#ffd890','#9affc8');
  abRidge(g,780,70,6.2,'#170c2c',.007);
  for(let i=0;i<22;i++)abTomb(g,rnd(i+400)*ABW,790+rnd(i+430)*40,.8+rnd(i)*.5,'#120a22',i);
  g.strokeStyle='#0b0618';g.lineWidth=4;for(let x=0;x<ABW;x+=36){g.beginPath();g.moveTo(x,860);g.lineTo(x,812-((x/36|0)%3)*6);g.stroke()}g.beginPath();g.moveTo(0,834);g.lineTo(ABW,834);g.stroke();
  abRidge(g,880,40,2.2,'#080412',.012,14);
  for(let i=0;i<5;i++)abDead(g,60+i*380+rnd(i+8)*100,905,330+rnd(i+90)*120,'#06030e',i+40)},
 /* III: the forge-land */
 g=>{g.fillStyle=abLin(g,0,ABH,[[0,'#0e0202'],[.35,'#4a0f06'],[.65,'#b2380e'],[1,'#ff9a2a']]);g.fillRect(0,0,ABW,ABH);glow(g,800,700,860,'#ff6a1a55');
  abRidge(g,540,200,2.2,'#4a1408',.0038,16);
  /* the volcano and its rivers of lava */
  g.fillStyle='#1c0806';g.beginPath();g.moveTo(560,780);g.lineTo(810,300);g.lineTo(870,286);g.lineTo(930,300);g.lineTo(1200,780);g.closePath();g.fill();
  glow(g,870,292,150,'#ff8a2a');g.fillStyle='#ffb040';g.beginPath();g.ellipse(870,292,50,11,0,0,TAU);g.fill();
  g.lineCap='round';g.lineJoin='round';for(const [x,k] of [[870,0],[860,1],[885,2]]){const pts=[];for(let i=0;i<9;i++)pts.push([x+(k-1)*46*i/3+Math.sin(i*1.1+k*2)*22,300+i*58]);const path=()=>{g.beginPath();g.moveTo(pts[0][0],pts[0][1]);for(let i=1;i<pts.length-1;i++){const m=[(pts[i][0]+pts[i+1][0])/2,(pts[i][1]+pts[i+1][1])/2];g.quadraticCurveTo(pts[i][0],pts[i][1],m[0],m[1])}g.stroke()};g.shadowColor='#ff7a1a';g.shadowBlur=22;g.strokeStyle='#e0480e';g.lineWidth=15-k*3;path();g.shadowBlur=0;g.strokeStyle='#ff9a2a';g.lineWidth=8-k*1.6;path();g.strokeStyle='#ffe08a';g.lineWidth=2.6;path()}
  for(let i=0;i<5;i++){const x=640+i*160,y=700+rnd(i)*30;g.fillStyle='#ff7a1a';glow(g,x,y,60,'#ff6a1a88')}
  abRidge(g,700,140,5.1,'#2a0c08',.0058,18);
  /* the forge keep with its chimneys */
  abCastle(g,330,730,.9,'#180604','#ffb040','#ffcf70');for(const cx of [210,270,460]){g.fillStyle='#180604';g.fillRect(cx-15,500,30,230);g.fillRect(cx-21,490,42,14);glow(g,cx,490,36,'#ff7a1a88')}
  abRidge(g,780,90,3.3,'#150504',.008,20);
  g.fillStyle=abLin(g,780,ABH,[[0,'#ff7a1a'],[.4,'#d03a08'],[1,'#6a1204']]);g.beginPath();g.moveTo(0,820);for(let x=0;x<=ABW;x+=16)g.lineTo(x,826+Math.sin(x*.02)*6);g.lineTo(ABW,ABH);g.lineTo(0,ABH);g.fill();
  for(let i=0;i<14;i++){const x=rnd(i+3)*ABW;g.fillStyle='#0d0302';g.beginPath();g.moveTo(x-50-rnd(i)*40,ABH);g.lineTo(x-6,860-rnd(i+5)*140);g.lineTo(x+4,850-rnd(i+8)*140);g.lineTo(x+60+rnd(i+2)*40,ABH);g.fill()}
  abRidge(g,900,40,8.4,'#080201',.014,20)},
 /* IV: the bleeding coast */
 g=>{g.fillStyle=abLin(g,0,560,[[0,'#16040a'],[.45,'#4c0f1a'],[.8,'#9a2a2a'],[1,'#d86a4a']]);g.fillRect(0,0,ABW,ABH);glow(g,1040,470,520,'#ff5a4a55');
  for(let i=0;i<7;i++){g.fillStyle=`rgba(${20+i*6},4,10,${.5-i*.04})`;g.beginPath();g.moveTo(0,40+i*70);for(let x=0;x<=ABW;x+=40)g.lineTo(x,40+i*70+Math.sin(x*.006+i*2)*26+Math.sin(x*.017+i)*10);g.lineTo(ABW,0);g.lineTo(0,0);g.fill()}
  glow(g,1040,520,200,'#ffb08a66');
  g.fillStyle=abLin(g,560,ABH,[[0,'#a43a30'],[.1,'#6a1a22'],[1,'#1a0408']]);g.fillRect(0,560,ABW,340);
  /* the headland and the ruined castle */
  g.fillStyle='#10040a';g.beginPath();g.moveTo(0,640);g.lineTo(0,360);g.lineTo(60,350);g.lineTo(150,380);g.lineTo(250,410);g.lineTo(300,500);g.lineTo(380,560);g.lineTo(520,640);g.closePath();g.fill();
  abCastle(g,215,388,.82,'#10040a','#ffb070','#ffd890');
  g.fillStyle='#10040a';g.beginPath();g.moveTo(1180,640);g.lineTo(1260,560);g.lineTo(1330,520);g.lineTo(1420,470);g.lineTo(1500,420);g.lineTo(1600,400);g.lineTo(1600,640);g.closePath();g.fill();
  abShip(g,740,640,.9,-.12,'#13050a',.9);abShip(g,1010,610,.55,.2,'#1d070d',.8);abShip(g,540,625,.42,-.28,'#26090f',.8);
  abRidge(g,860,50,4.4,'#0b0206',.012,16)},
 /* V: the frozen throne under a rift */
 g=>{g.fillStyle=abLin(g,0,ABH,[[0,'#04030e'],[.4,'#14104a'],[.72,'#3c2c8c'],[1,'#7a5cc0']]);g.fillRect(0,0,ABW,ABH);abStars(g,190,13,560,'#fff',1.7);
  glow(g,820,300,460,'#ffd76a44');
  abRidge(g,640,170,1.7,'#2c2478',.0044);abRidge(g,700,120,5.2,'#211a62',.006,8);
  /* the citadel of ice */
  const sp=(x,y,w,h,c)=>{g.fillStyle=c;g.beginPath();g.moveTo(x-w/2,y);g.lineTo(x-w/2+w*.08,y-h*.7);g.lineTo(x,y-h);g.lineTo(x+w/2-w*.08,y-h*.7);g.lineTo(x+w/2,y);g.closePath();g.fill()};
  g.save();for(const [x,w,h,c] of [[680,90,300,'#33408f'],[760,70,230,'#2a3680'],[1000,100,280,'#33408f'],[930,70,210,'#2a3680'],[820,130,470,'#4a5cb4']]){sp(x,740,w,h,c);g.fillStyle='#ffffff22';g.beginPath();g.moveTo(x-w/2+4,740);g.lineTo(x-w/2+w*.1,740-h*.66);g.lineTo(x-2,740-h*.95);g.lineTo(x-w*.1,740-h*.5);g.closePath();g.fill()}g.restore();
  for(const [x,y] of [[820,560],[820,500],[820,440],[680,640],[1000,650],[760,640],[930,620]]){glow(g,x,y,34,'#ffd76a77');g.fillStyle='#ffe9a0';g.fillRect(x-4,y-9,8,18)}
  g.fillStyle='#ffd76a';g.beginPath();g.moveTo(820,270);g.lineTo(826,236);g.lineTo(820,206);g.lineTo(814,236);g.closePath();g.fill();
  abRidge(g,780,70,6.3,'#1a1550',.007);
  g.fillStyle=abLin(g,780,ABH,[[0,'#6a58b8'],[.2,'#3a3090'],[1,'#120d3c']]);g.fillRect(0,810,ABW,90);
  g.strokeStyle='#9a88e655';g.lineWidth=2;for(let i=0;i<26;i++){const x=rnd(i+11)*ABW,y=830+rnd(i+30)*60;g.beginPath();g.moveTo(x,y);g.lineTo(x+40+rnd(i)*80,y+rnd(i+4)*14-7);g.stroke()}
  abRidge(g,890,50,2.9,'#0b0830',.011,18);
  for(let i=0;i<16;i++){const x=rnd(i+70)*ABW,h=60+rnd(i+90)*150;g.fillStyle='#090624';g.beginPath();g.moveTo(x-18,ABH);g.lineTo(x,ABH-h);g.lineTo(x+22,ABH);g.fill();g.fillStyle='#ffffff18';g.beginPath();g.moveTo(x,ABH-h);g.lineTo(x+8,ABH-h*.4);g.lineTo(x+22,ABH);g.lineTo(x+3,ABH);g.fill()}}
];
function abStatic(a){if(ABC[a])return ABC[a];const c=document.createElement('canvas');c.width=ABW;c.height=ABH;const g=c.getContext('2d');try{ABST[a](g)}catch(e){console.error('act bg',a,e)}return ABC[a]=c}

/* ===== animated layers ===== */
const ABA=[
 (g,t)=>{abDrift(g,abCloud('c1a',900,220,'#ffd6b6aa','#ffd6b600',3),0,70,9,t,.8);abDrift(g,abCloud('c1b',1100,180,'#f2b8c0aa','#f2b8c000',17),300,210,5,t,.7);
  g.save();g.globalCompositeOperation='lighter';for(let i=0;i<9;i++){const a=-1.25+i*.19+Math.sin(t*.4+i)*.03;g.globalAlpha=.05+.025*Math.sin(t*.9+i*1.7);g.fillStyle='#ffd98a';g.beginPath();g.moveTo(1090,610);g.lineTo(1090+Math.cos(a)*1500-60,610+Math.sin(a)*1500);g.lineTo(1090+Math.cos(a)*1500+60,610+Math.sin(a)*1500);g.fill()}g.restore();
  abDrift(g,abFog('f1','#ffd9b8'),0,640,-12,t,.3);abDrift(g,abFog('f1','#ffd9b8'),500,730,-18,t,.22,1.2);
  for(let i=0;i<7;i++){const x=((i*270+t*(40+i*6))%1900)-150,y=130+i*38+Math.sin(t*1.3+i*2)*20,fl=Math.sin(t*9+i*3)*3;g.strokeStyle='#1a2442';g.lineWidth=2.4;g.beginPath();g.moveTo(x-10,y+fl);g.quadraticCurveTo(x-4,y-5,x,y);g.quadraticCurveTo(x+4,y-5,x+10,y+fl);g.stroke()}
  for(let i=0;i<46;i++){const x=(rnd(i)*ABW+Math.sin(t*.5+i)*30+t*6)%ABW,y=560+rnd(i+9)*300+Math.sin(t*.8+i*2)*24,tw=.5+.5*Math.sin(t*2.2+i*1.9);g.globalAlpha=tw;glow(g,x,y,12,'#ffe58a');g.fillStyle='#fffbd0';g.fillRect(x-1,y-1,2.4,2.4)}g.globalAlpha=1},
 (g,t)=>{g.save();g.globalCompositeOperation='lighter';abDrift(g,abCloud('c2a',1000,200,'#6a4a9a77','#6a4a9a00',7),0,160,7,t,.9);g.restore();
  abDrift(g,abCloud('c2b',1200,170,'#1c1034aa','#1c103400',21),200,250,14,t,.45);
  abDrift(g,abFog('f2','#b890e0'),0,640,-10,t,.42);abDrift(g,abFog('f2','#b890e0'),600,760,-16,t,.38,1.3);
  for(let i=0;i<26;i++){const x=(rnd(i+5)*ABW+Math.sin(t*.4+i*2)*50)%ABW,y=600+rnd(i+11)*230+Math.sin(t*.7+i)*30,a=.3+.5*Math.sin(t*1.6+i*1.3)**2;g.globalAlpha=a;glow(g,x,y,26,i%3?'#8affc8':'#caa0ff');g.fillStyle='#e8fff4';g.beginPath();g.arc(x,y,2.4,0,TAU);g.fill()}g.globalAlpha=1;
  for(let i=0;i<6;i++){const u=(t*.05+i*.17)%1,x=u*(ABW+300)-150,y=200+i*52+Math.sin(t*2+i*2)*30+Math.sin(u*9)*20,f=Math.sin(t*14+i)*.5+.5;g.save();g.translate(x,y);g.fillStyle='#07030f';g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(-16,-12*f-4,-30,-2+f*6);g.quadraticCurveTo(-18,2,-8,5);g.lineTo(8,5);g.quadraticCurveTo(18,2,30,-2+f*6);g.quadraticCurveTo(16,-12*f-4,0,0);g.fill();g.beginPath();g.arc(0,4,5,0,TAU);g.fill();g.restore()}},
 (g,t)=>{const p=.5+.5*Math.sin(t*1.7);g.save();g.globalCompositeOperation='lighter';glow(g,870,292,260+p*50,'#ff7a2a66');glow(g,800,820,600,'#ff781e'+Math.round(40+p*22).toString(16).padStart(2,'0'));g.restore();
  abDrift(g,abCloud('c3a',1200,230,'#2a0a06dd','#2a0a0600',31),0,20,18,t,1);abDrift(g,abCloud('c3b',1000,200,'#5a1a0acc','#5a1a0a00',37),400,150,11,t,.9);
  for(let k=0;k<4;k++){const u=(t*.07+k*.25)%1;g.globalAlpha=(1-u)*.5;g.drawImage(abCloud('c3s',500,360,'#1a0806cc','#1a080600',43),830+Math.sin(u*5+k)*60-u*60,250-u*260,260+u*300,200+u*200)}g.globalAlpha=1;
  g.save();g.globalCompositeOperation='lighter';for(let i=0;i<70;i++){const sp=.05+rnd(i+3)*.1,u=(t*sp+rnd(i))%1,x=(rnd(i+1)*ABW+Math.sin(t*.8+i)*40),y=ABH-u*(ABH+20),s=1.2+rnd(i+7)*2.4;g.globalAlpha=Math.min(1,u*5)*(1-u)*.95;glow(g,x,y,s*5,'#ff8a2a');g.fillStyle='#ffd890';g.fillRect(x-s/2,y-s/2,s,s)}g.restore();
  g.save();g.globalCompositeOperation='lighter';for(let i=0;i<24;i++){const x=rnd(i+30)*ABW,w=30+rnd(i)*120;g.globalAlpha=.12+.1*Math.sin(t*2.2+i*1.7);g.fillStyle='#ffc060';g.fillRect(x,826+Math.sin(t*1.3+i)*4,w,2.4)}g.restore();
  const b=(t%9);if(b<1.3){const u=b/1.3;g.save();g.globalCompositeOperation='lighter';g.strokeStyle='#ffa040';g.lineWidth=3;g.globalAlpha=1-u;for(let i=0;i<12;i++){const a=-Math.PI/2+(i-5.5)*.12,r=u*160;g.beginPath();g.moveTo(870+Math.cos(a)*r*.6,292+Math.sin(a)*r*.6);g.lineTo(870+Math.cos(a)*r,292+Math.sin(a)*r+u*u*120);g.stroke()}g.restore()}},
 (g,t)=>{const f=abFlash(t);abDrift(g,abCloud('c4a',1300,200,'#2a060cdd','#2a060c00',51),0,10,16,t,1);abDrift(g,abCloud('c4b',1200,190,'#58121acc','#58121a00',57),500,110,9,t,.9);
  if(f>.01){g.save();g.globalCompositeOperation='lighter';g.globalAlpha=f*.55;g.fillStyle=abLin(g,0,ABH,[[0,'#ff9a8a'],[.7,'#ff6a5a'],[1,'#401018']]);g.fillRect(0,0,ABW,ABH);g.restore();
   if(f>.35){const sd=Math.floor(t/6.7)*17;g.strokeStyle='#fff4ee';g.shadowColor='#ffb0a0';g.shadowBlur=24;g.lineWidth=4;g.lineJoin='round';g.beginPath();let x=500+rnd(sd)*700,y=40;g.moveTo(x,y);while(y<620){x+=(rnd(sd+y)-.5)*90;y+=40+rnd(sd+x)*50;g.lineTo(x,y)}g.stroke();g.shadowBlur=0}}
  /* the red sea */
  g.save();g.beginPath();g.rect(0,560,ABW,340);g.clip();for(let i=0;i<30;i++){const y=572+i*i*.36+i*3,k=i/30,amp=1+k*6;g.strokeStyle=`rgba(${230-k*80},${90-k*60},${80-k*50},${.1+k*.2})`;g.lineWidth=1+k*2.4;g.beginPath();for(let x=-10;x<=ABW+10;x+=20){const yy=y+Math.sin(x*(.012-k*.005)+t*(1+k)+i*1.7)*amp;x<0?g.moveTo(x,yy):g.lineTo(x,yy)}g.stroke()}
  g.globalCompositeOperation='lighter';for(let i=0;i<40;i++){const x=900+rnd(i)*340+Math.sin(t*1.1+i)*30,y=565+rnd(i+4)*90;g.globalAlpha=.1+.1*Math.sin(t*3+i);g.fillStyle='#ffb090';g.fillRect(x,y,30+rnd(i+7)*50,2)}g.restore();
  abDrift(g,abFog('f4','#ff8a7a'),0,560,-8,t,.34);abDrift(g,abFog('f4','#d8504a'),400,760,-14,t,.26,1.4);
  g.strokeStyle='#ffc8c866';g.lineWidth=1.4;g.beginPath();for(let i=0;i<150;i++){const x=(rnd(i)*ABW*1.2+t*(260+rnd(i+3)*200))%(ABW*1.2)-100,y=(rnd(i+9)*ABH+t*(900+rnd(i+5)*400))%ABH;g.moveTo(x,y);g.lineTo(x-12,y+30)}g.stroke();
  },
 (g,t)=>{g.save();g.globalCompositeOperation='lighter';for(let k=0;k<4;k++){const hs=[150,285,50,330][k];g.beginPath();g.moveTo(0,200+k*30);for(let x=0;x<=ABW;x+=24)g.lineTo(x,150+k*46+Math.sin(x*.004+t*.35+k*1.9)*54+Math.sin(x*.011+t*.8+k)*14);for(let x=ABW;x>=0;x-=24)g.lineTo(x,300+k*46+Math.sin(x*.004+t*.35+k*1.9+.8)*70+Math.sin(x*.009+t*.6+k)*22);g.closePath();const q=g.createLinearGradient(0,100,0,420);q.addColorStop(0,`hsla(${hs},90%,60%,0)`);q.addColorStop(.35,`hsla(${hs},90%,62%,.2)`);q.addColorStop(1,`hsla(${hs},90%,60%,0)`);g.fillStyle=q;g.fill()}g.restore();
  for(let i=0;i<40;i++){const x=rnd(i+99)*ABW,y=rnd(i+120)*480;g.globalAlpha=.3+.7*Math.abs(Math.sin(t*1.4+i*2.3));g.fillStyle='#fff';g.fillRect(x,y,1.6+rnd(i)*1.4,1.6+rnd(i)*1.4)}g.globalAlpha=1;
  /* the rift above the citadel */
  g.save();g.translate(820,214);g.globalCompositeOperation='lighter';glow(g,0,0,150+Math.sin(t*2)*18,'#ffd76a88');for(let i=0;i<3;i++){g.save();g.rotate(t*(.6+i*.3)*(i%2?-1:1));g.strokeStyle=`rgba(255,${200-i*30},120,.55)`;g.lineWidth=2.4;g.setLineDash([22,16]);g.beginPath();g.ellipse(0,0,52+i*20,20+i*8,0,0,TAU);g.stroke();g.restore()}g.restore();
  g.save();g.globalCompositeOperation='lighter';for(let i=0;i<7;i++){const a=Math.PI/2+(i-3)*.15+Math.sin(t*.5+i)*.03;g.globalAlpha=.035+.02*Math.sin(t*1.3+i);g.fillStyle='#ffe9a0';g.beginPath();g.moveTo(820,230);g.lineTo(820+Math.cos(a)*900-40,230+Math.sin(a)*900);g.lineTo(820+Math.cos(a)*900+40,230+Math.sin(a)*900);g.fill()}g.restore();
  for(let i=0;i<9;i++){const x=(rnd(i+4)*ABW+Math.sin(t*.3+i)*40),y=250+rnd(i+14)*380+Math.sin(t*.9+i*1.7)*18,s=10+rnd(i+24)*22,r=t*.4+i;g.save();g.translate(x,y);g.rotate(r);g.fillStyle='#8ab8ff55';g.strokeStyle='#d8ecff99';g.lineWidth=1.4;g.beginPath();g.moveTo(0,-s);g.lineTo(s*.5,0);g.lineTo(0,s*1.1);g.lineTo(-s*.5,0);g.closePath();g.fill();g.stroke();g.restore()}
  abDrift(g,abFog('f5','#a898f0'),0,740,-9,t,.3,1.2);
  for(let i=0;i<110;i++){const x=(rnd(i)*ABW+t*(14+rnd(i+2)*20)+Math.sin(t*.7+i)*24)%ABW,y=(rnd(i+7)*ABH+t*(34+rnd(i+4)*44))%ABH,r=1+rnd(i+3)*2.4;g.globalAlpha=.35+rnd(i+1)*.55;g.fillStyle='#fff';g.beginPath();g.arc(x,y,r,0,TAU);g.fill()}g.globalAlpha=1}
];
function actBG(g,a,t){g.save();g.globalAlpha=1;g.globalCompositeOperation='source-over';g.shadowBlur=0;g.drawImage(abStatic(a),0,0);try{ABA[a](g,t)}catch(e){if(!actBG.w){actBG.w=1;console.error('act anim',a,e)}}g.restore()}
