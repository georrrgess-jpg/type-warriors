/* ===== WILDCARD: the table — seats, hand, piles, the turn driver and every card animation =====
   One renderer serves Solo, Same screen (pass & play) and online rooms. The host (or Solo) owns WX.G and runs the
   regulars; a guest only receives the host's state and sends its own moves. New engine events are replayed one by one
   as animations, then the table is rebuilt from the final state. Seat kinds: you, local (same screen), bot, net. */
const WX={G:null,me:0,mode:'solo',host:true,tbl:'c250',stake:0,fee:0,seen:0,busy:false,tok:0,tm:[],sort:0,sel:-1,vc:[],hint:-2,chat:[],cfg:null,ended:false};
const wcSnd=(f,d,t,v,dl)=>{try{if(dl)setTimeout(()=>beep(f,d,t,v),dl);else beep(f,d,t,v)}catch(e){}};
const wcRM=()=>{try{return matchMedia('(prefers-reduced-motion: reduce)').matches||document.body.classList.contains('pf-low')}catch(e){return false}};
const wcSleep=ms=>new Promise(r=>setTimeout(r,wcRM()?Math.min(ms,60):ms));
function wcClear(){for(const t of WX.tm)clearTimeout(t);WX.tm=[]}
function wcLater(fn,ms){const tok=WX.tok,t=setTimeout(()=>{if(tok===WX.tok&&$('wct'))fn()},ms);WX.tm.push(t);return t}
/* portraits: heroes from the armory, older monsters from the bestiary (crew members are drawn by 89i) */
function wcPortrait(cv,av){const g=cv.getContext('2d'),w=cv.width,h=cv.height;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,w,h);
 try{if(av&&av.t==='mon'&&MON[av.id]){const M=MON[av.id],s=(h*1.18)/M.th;g.save();g.translate(w/2-(M.cx||0)*s,h*1.12);g.scale(s,s);M.d(g,1.2,{lg:0});g.restore()}
  else{const a=av||{};g.save();g.translate(w*.45,h*1.04);const s=w/60;g.scale(s,s);g.translate(0,58);drawHero(g,{arm:AR[a.arm]?a.arm:P.armor,wp:null,col:a.col!=null?a.col:P.col,t:1.2});g.restore()}}catch(e){}}
/* the real drawn size of a monster (glow and weapons included), measured once, so big ones are never cut off */
const WCBOX={};
function wcBox(id){if(WCBOX[id])return WCBOX[id];const M=MON[id];let B={w:M.tw||M.th*.9,h:M.th,cx:M.cx||0,b:0};
 try{const c=document.createElement('canvas');c.width=c.height=640;const g=c.getContext('2d');g.translate(320,600);M.d(g,1.2,{lg:0});
  const d=g.getImageData(0,0,640,640).data;let x0=640,x1=-1,y0=640,y1=-1;for(let y=0;y<640;y+=2)for(let x=0;x<640;x+=2)if(d[(y*640+x)*4+3]>10){if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y}
  if(x1>x0&&y1>y0)B={w:x1-x0+2,h:y1-y0+2,cx:(x0+x1)/2-320,b:y1+2-600}}catch(e){}
 return WCBOX[id]=B}
function wcFigure(cv,av){const g=cv.getContext('2d'),w=cv.width,h=cv.height;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,w,h);
 try{if(av&&av.t==='mon'&&MON[av.id]){const M=MON[av.id],B=wcBox(av.id),s=Math.min((h*.94)/B.h,(w*.94)/B.w,2.4);g.save();g.translate(w/2-B.cx*s,h*.98-B.b*s);g.scale(s,s);M.d(g,1.2,{lg:0});g.restore()}
  else{const a=av||{};g.save();g.translate(w/2,h*.97);const s=h/190;g.scale(s,s);drawHero(g,{arm:AR[a.arm]?a.arm:P.armor,wp:WP[a.wp]?a.wp:P.weapon,col:a.col!=null?a.col:P.col,t:1.2});g.restore()}}catch(e){}}
const wcMyAv=()=>({t:'hero',arm:P.armor,wp:P.weapon,col:P.col});
/* where each seat sits, counted from the player looking at the table */
const WCPOS={2:['b','t'],3:['b','l','r'],4:['b','l','t','r']};
const wcPos=(i)=>{const G=WX.G,n=G.P.length;return WCPOS[n][(i-WX.me+n)%n]};
const wcRot=id=>((id*37)%23)-11;
function wcDisp(){const h=WX.G.P[WX.me].hand.slice();if(WX.sort===1)h.sort((a,b)=>(WCS.indexOf(a.s)+1||9)-(WCS.indexOf(b.s)+1||9)||wcPts(a)-wcPts(b));else if(WX.sort===2)h.sort((a,b)=>wcPts(a)-wcPts(b)||(WCS.indexOf(a.s)+1||9)-(WCS.indexOf(b.s)+1||9));return h}
const wcMine=()=>WX.G&&WX.G.turn===WX.me&&WX.G.phase!=='over'&&(WX.G.P[WX.me].kind==='you'||WX.G.P[WX.me].kind==='local'||WX.mode==='net');
/* the dragon crest worked into the felt */
const WCCREST=`<svg viewBox="-100 -60 200 120" aria-hidden="true"><g fill="none" stroke="#ffd45a" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round"><path d="M0-34C-8-26-14-14-14 0-14 16-6 28 0 34 6 28 14 16 14 0 14-14 8-26 0-34Z"/><path d="M-14-6C-34-22-62-24-86-10-66-12-52-2-46 12-32 4-20 4-14 10"/><path d="M14-6C34-22 62-24 86-10 66-12 52-2 46 12 32 4 20 4 14 10"/>
 <path d="M-6-40L0-52 6-40M-6 8L0 18 6 8"/><circle cx="0" cy="-6" r="5"/><path d="M-60-14L-56 2M-36-18L-34-2M60-14L56 2M36-18L34-2"/></g></svg>`;
/* ---------- the screen ---------- */
function wcTable(){const G=WX.G,felt=WX.mode==='solo'?'green':'blue',T=WX.mode==='solo'?WCT[WX.tbl]:null,net=WX.mode==='net';
 const top=`${T?`<span class="wcpill tb">${wcChip(WX.tbl,28)}<b>${T.n}</b></span>`:`<span class="wcpill">Room <b>${esc(WX.room||'')}</b></span>`}${WX.stake?`<span class="wcpill">Pot <b>${cmn(WX.stake*G.P.length)}</b></span>`:`<span class="wcpill">${WX.mode==='pp'?'Same screen':'Practice'}</span>`}${net?`<span class="wcpill ok" id="wcnet"><i class="wcpd"></i>Connected</span>`:''}`;
 show(`<div class="wct ${felt}" id="wct"><div class="wcbg"></div><div class="wcfelt"><i></i><em class="wcemb">${WCCREST}</em><b class="wcflt">WILDCARD</b></div><div class="wcfglow" id="wcfglow"></div>
 <div class="wctop">${top}</div>
 <button class="wcmenu" id="wcmenu" aria-label="Menu">${WCI.menu}<span>Menu</span></button>
 <div class="wcring" id="wcring" aria-hidden="true"><svg viewBox="-120 -120 240 240"><g class="wcrg"><path d="M-96 -30A100 100 0 0 1 60-80" /><path d="M96 30A100 100 0 0 1 -60 80"/><path class="ah" d="M56-90L70-79 52-72Z"/><path class="ah" d="M-56 90L-70 79-52 72Z"/></g></svg></div>
 <div id="wcseats"></div>
 <div class="wcpiles"><button class="wcdeck" id="wcdeck" aria-label="Draw a card">${wcCardEl(null,'d3')}${wcCardEl(null,'d2')}${wcCardEl(null,'d1')}<span class="wcdn" id="wcdn"></span><span class="wcdl">DRAW</span></button><div class="wcglow" id="wcglow"></div><div class="wcdisc" id="wcdisc"></div></div>
 <div class="wcstack" id="wcstack"></div>
 <div class="wcstat" id="wcstat" aria-live="polite"></div>
 <div class="wchand" id="wchand" role="listbox" aria-label="Your hand"></div>
 <div class="wcdrawn" id="wcdrawn"></div>
 <div class="wctools"><button class="wctb" id="wchint"><svg viewBox="0 0 24 24"><path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.6 10.8c.6.5 1 1.2 1 2V16h5.2v-.2c0-.8.4-1.5 1-2A6 6 0 0 0 12 3z" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>Hint</button><button class="wctb" id="wcsort"><svg viewBox="0 0 24 24"><path d="M7 4v16M3.5 16.5L7 20l3.5-3.5M17 20V4M13.5 7.5L17 4l3.5 3.5" stroke="currentColor" stroke-width="2.2" fill="none" stroke-linecap="round"/></svg><span>${['Sort','By element','By value'][WX.sort]}</span></button></div>
 ${WX.mode==='net'||WX.mode==='pp'?`<div class="wcemo" id="wcemo">${['😂','😭','🔥','👏','😈','GG','Nice!','Oops'].map(x=>`<button data-emo="${x}">${x}</button>`).join('')}</div>`:''}${WX.mode==='net'?`<div class="wcchat" id="wcchat"><b>Table chat</b><div id="wcchl"></div></div>`:''}
 <button class="wcone" id="wcone" aria-label="Call WILD"><span>WILD!</span></button>
 <div class="wcflash" id="wcflash"></div><div class="wcfx" id="wcfx"></div><div class="wcmod" id="wcmod" hidden></div></div>`,'casbg wcx');
 S.back=wcMenu;$('wcmenu').onclick=wcMenu;
 $('wcdeck').onclick=()=>{if(!wcMine()||WX.busy)return;const G=WX.G;if(G.phase==='drawn')return;wcSend({t:'draw'})};
 $('wcone').onclick=()=>wcSend({t:'call'});
 $('wchint').onclick=wcHint;$('wcsort').onclick=()=>{WX.sort=(WX.sort+1)%3;wcFx('click');wcRenderHand(true);const b=$('wcsort');if(b)b.querySelector('span').textContent=['Sort','By element','By value'][WX.sort]};
 const em=$('wcemo');if(em)em.querySelectorAll('[data-emo]').forEach(b=>b.onclick=()=>wcEmote(b.dataset.emo));
 WX.vc=G.P.map(p=>p.hand.length);wcRender()}
function wcSeatHTML(i){const G=WX.G,p=G.P[i],pos=wcPos(i),n=p.hand.length,act=G.turn===i&&G.phase!=='over';
 const fan=Math.min(n,9),backs=Array.from({length:fan},(_,k)=>`<i class="wcmbk" style="--k:${k-(fan-1)/2}">${wcBack(wcBackSel())}</i>`).join('');
 return `<div class="wcseat p-${pos}${act?' on':''}${G.one&&G.one.p===i&&i!==WX.me?' catch':''}" data-seat="${i}" style="--tm:${WX.cfg&&WX.cfg.timer||0}s">
  <div class="wchalo"></div><button class="wcav" data-catch="${i}" aria-label="${esc(p.name)}, ${n} cards"><canvas width="128" height="128"></canvas><svg class="wctr" viewBox="0 0 100 100"><circle cx="50" cy="50" r="47"/></svg></button>
  <div class="wcnm"><b>${esc(p.name)}</b>${p.kind==='net'?'<small class="d-net">Online</small>':p.kind==='local'?'<small class="d-pp">This screen</small>':''}</div><span class="wcn" title="Cards in hand">${n}</span>
  ${n===1?'<span class="wcw1">WILD!</span>':''}
  ${pos==='b'?'':`<div class="wcbacks">${backs}</div>`}<div class="wcbub" id="wcbub${i}"></div></div>`}
function wcRender(){const G=WX.G;if(!G||!$('wct'))return;WX.vc=G.P.map(p=>p.hand.length);
 const st=$('wcseats');st.innerHTML=G.P.map((p,i)=>i===WX.me?'':wcSeatHTML(i)).join('')+wcSeatHTML(WX.me).replace('class="wcseat p-b','class="wcseat me p-b');
 st.querySelectorAll('.wcseat').forEach(s=>{const i=+s.dataset.seat,c=s.querySelector('canvas'),av=G.P[i].av;if(av&&av.t==='crew')wcLive(c,av,'por');else wcPortrait(c,av)});
 st.querySelectorAll('[data-catch]').forEach(b=>b.onclick=()=>{const t=+b.dataset.catch;if(WX.G.one&&WX.G.one.p===t&&t!==WX.me)wcSend({t:'catch',p:t})});
 const d=$('wcdisc');d.innerHTML=G.disc.slice(-4).map((c,k,a)=>wcCardEl(c,k===a.length-1?'top':'',`style="--r:${wcRot(c.id)}deg"`)).join('');
 wcTint(G.color);$('wcdn').textContent=G.draw.length;$('wcring').classList.toggle('rev',G.dir<0);
 wcStack();wcStatus();wcRenderHand();wcButtons()}
/* the current element tints the pile glow and the rim of the felt */
function wcTint(c){const gl=$('wcglow'),fg=$('wcfglow');if(gl){gl.style.setProperty('--gc',WCC[c]);gl.dataset.c=c}if(fg){fg.style.setProperty('--gc',WCC[c]);fg.dataset.c=c}}
function wcStack(){const e=$('wcstack'),G=WX.G;if(!e)return;e.className='wcstack'+(G.stack>0?' on':'');e.innerHTML=G.stack>0?`<b>+${G.stack}</b><small>incoming</small>`:''}
function wcStatus(t){const e=$('wcstat'),G=WX.G;if(!e)return;if(t){e.innerHTML=t;return}
 if(G.phase==='over'){e.innerHTML='';e.className='wcstat';return}const p=G.P[G.turn],col=`<i class="wcpd" style="background:${WCC[G.color]}"></i><b style="color:${WCK[G.color][0]}">${WCN[G.color]}</b>`,face=wcCorner(wcTop(G)),mine=G.turn===WX.me&&wcMine();
 if(mine){const L=wcLegal(G,WX.me);e.className='wcstat me';e.innerHTML='<span class="wcyt">YOUR TURN</span>'+(G.phase==='drawn'?'You drew a card that fits. <b>Play it</b> or <b>keep it</b>.':G.stack>0?`<b class="hot">+${G.stack} coming your way!</b> Stack a matching card, or tap the deck to take them.`:L.length?`Play ${col} or a <b>${face}</b>`:`No match. <b>Tap the deck</b> to draw.`)}
 else{e.className='wcstat';e.innerHTML=`<b>${esc(p.name)}</b> is playing · `+(G.stack>0?`<b class="hot">+${G.stack} stack</b> on them`:`needs ${col} or a <b>${face}</b>`)}}
function wcRenderHand(resort){const G=WX.G,h=$('wchand');if(!h)return;const me=G.P[WX.me],cards=wcDisp(),n=cards.length,mine=wcMine();
 const L=mine?new Set(wcLegal(G,WX.me).map(i=>me.hand[i].id)):new Set(),hidden=WX.cover;
 const w=112,maxW=n>12?1000:880,step=n>1?Math.min(78,(maxW-w)/(n-1)):0,tot=w+(n-1)*step;
 h.innerHTML=cards.map((c,i)=>{const m=(n-1)/2,x=800-tot/2+i*step,r=n>1?(i-m)*Math.min(3.2,26/n):0,y=Math.pow(i-m,2)*Math.min(2.2,30/(n*n)+.5);
  return `<button class="wcc wchc${L.has(c.id)?' ok':''}${mine&&!L.has(c.id)?' no':''}${G.pend===c.id&&G.turn===WX.me?' pend':''}${WX.fresh&&WX.fresh.has(c.id)?' fresh':''}" data-id="${c.id}" data-e="${c.s}" role="option" aria-label="${wcName(c)}${L.has(c.id)?', playable':''}" style="--x:${x}px;--y:${y}px;--r:${r}deg;--z:${i};--d:${i*.025}s;--ec:${WCC[c.s]}" tabindex="${mine?0:-1}">${hidden?wcBack(wcBackSel()):wcSVG(c)}</button>`}).join('');
 WX.fresh=null;if(resort)h.classList.add('resort'),setTimeout(()=>h&&h.classList.remove('resort'),400);
 h.querySelectorAll('.wchc').forEach(b=>{b.onclick=()=>wcTapCard(+b.dataset.id);if(b.classList.contains('ok'))b.onmouseenter=()=>wcFx('hover');b.onkeydown=e=>{const all=[...h.querySelectorAll('.wchc')],i=all.indexOf(b);if(e.key==='ArrowRight'&&all[i+1]){e.preventDefault();all[i+1].focus()}else if(e.key==='ArrowLeft'&&all[i-1]){e.preventDefault();all[i-1].focus()}}});
 const dr=$('wcdrawn');if(dr){if(G.phase==='drawn'&&G.turn===WX.me&&mine){dr.innerHTML=`<button class="wcbtn gold" id="wcplayd">Play it</button><button class="wcbtn" id="wckeep">Keep it</button>`;dr.classList.add('on');
  $('wcplayd').onclick=()=>wcTapCard(G.pend);$('wckeep').onclick=()=>wcSend({t:'pass'})}else{dr.innerHTML='';dr.classList.remove('on')}}}
function wcButtons(){const G=WX.G,me=G.P[WX.me],o=$('wcone');if(!o)return;const mine=wcMine();
 const can=(mine&&me.hand.length===2&&!me.called&&wcLegal(G,WX.me).length)||(G.one&&G.one.p===WX.me);
 o.classList.toggle('can',!!can);o.classList.toggle('urgent',!!(G.one&&G.one.p===WX.me));o.disabled=!can;
 const dk=$('wcdeck');dk.classList.toggle('can',mine&&G.phase==='play');dk.classList.toggle('need',mine&&G.phase==='play'&&!wcLegal(G,WX.me).length);
 const hb=$('wchint');if(hb)hb.disabled=!mine}
function wcTapCard(id){const G=WX.G;if(!wcMine()||WX.busy)return;const me=G.P[WX.me],c=me.hand.find(x=>x.id===id);if(!c)return;
 if(!wcCan(G,c)||(G.phase==='drawn'&&G.pend!==id)){const el=document.querySelector(`.wchc[data-id="${id}"]`);if(el){el.classList.remove('nope');void el.offsetWidth;el.classList.add('nope')}wcFx('bad');
  wcStatus(G.stack>0?`<b class="hot">That card can't stop the stack.</b> Play a +2 on a +2, a +4, or tap the deck.`:`<b class="hot">That card doesn't match.</b> It needs ${WCN[G.color]} or a ${wcCorner(wcTop(G))}.`);wcLater(()=>wcStatus(),2200);return}
 if(c.s==='w')return wcPickCol(col=>wcSend({t:'play',id,col}));wcSend({t:'play',id})}
/* the element picker for Wild Rune and +4 Hex */
function wcPickCol(cb){const m=$('wcmod');if(!m)return;const me=WX.G.P[WX.me],cnt={};for(const c of me.hand)cnt[c.s]=(cnt[c.s]||0)+1;
 m.hidden=false;m.className='wcmod wcpk';m.innerHTML=`<div class="wcpkb"><b>Choose an element</b><small>The next card must match it</small><div class="wcpkr">${WCS.map((s,i)=>`<button data-col="${s}" style="--c:${WCC[s]};--i:${i}">${wcOrb(s,70)}<span>${WCN[s]}</span><small>${cnt[s]||0} in your hand</small></button>`).join('')}</div><button class="wcpkx" id="wcpkx">Cancel</button></div>`;
 const close=()=>{m.hidden=true;m.innerHTML=''};m.querySelectorAll('[data-col]').forEach(b=>{b.onmouseenter=()=>wcFx('hover');b.onclick=()=>{close();wcFx('elem',b.dataset.col);cb(b.dataset.col)}});$('wcpkx').onclick=()=>{close();wcFx('back')};
 setTimeout(()=>{const b=m.querySelector('[data-col]');if(b)b.focus()},40);wcFx('pop')}
function wcHint(){const G=WX.G;if(!wcMine())return;const me=G.P[WX.me],sv=me.diff;me.diff='m';const a=wcBot(G,WX.me);me.diff=sv;
 document.querySelectorAll('.wchint').forEach(x=>x.classList.remove('wchint'));
 if(a.t==='play'||a.i!=null){const c=me.hand[a.i],el=c&&document.querySelector(`.wchc[data-id="${c.id}"]`);if(el)el.classList.add('wchint')}else{const d=$('wcdeck');if(d)d.classList.add('wchint')}
 wcFx('tick')}
/* the in-game menu (Esc opens it) */
function wcMenu(){const m=$('wcmod');if(!m)return;if(!m.hidden&&m.classList.contains('wccur'))return;if(!m.hidden){m.hidden=true;m.innerHTML='';wcFx('back');return}const G=WX.G;
 m.hidden=false;m.className='wcmod wcmn';m.innerHTML=`<div class="wcmnb"><b>Game menu</b><small>${WX.mode==='solo'?esc(WCT[WX.tbl].n)+(WX.stake?' · pot '+cmn(WX.stake*G.P.length):' · practice'):WX.mode==='pp'?'Same screen':'Room '+esc(WX.room||'')}</small>
 <button class="wcbtn gold big" id="wcres">Resume</button><div class="wcmn2">${wcMusBtn('wcmusm')}<button class="wcpb${ST.svol>0?'':' off'}" id="wcsfx">${WCI.snd}<span>${ST.svol>0?'Sounds on':'Sounds off'}</span></button><button class="wcpb" id="wcrules">${WCI.book}<span>How to play</span></button></div>
 <button class="wcbtn red big" id="wcquit">Leave the table</button><p>${WX.stake&&G&&G.phase!=='over'?`Leaving now forfeits your <b>${cmn(WX.stake)}</b> buy-in.`:'Leaving now counts as a loss.'}</p></div>`;
 $('wcres').onclick=()=>{m.hidden=true;m.innerHTML='';wcFx('click')};wcMusWire('wcmusm');
 $('wcsfx').onclick=()=>{if(ST.svol>0){WX.sv=ST.svol;ST.svol=0}else ST.svol=WX.sv||.7;try{applyVol();if(typeof saveSettings==='function')saveSettings()}catch(e){}wcFx('click');const b=$('wcsfx');b.classList.toggle('off',!(ST.svol>0));b.querySelector('span').textContent=ST.svol>0?'Sounds on':'Sounds off'};
 $('wcrules').onclick=()=>{wcHowTo()};$('wcquit').onclick=()=>{if(!WX.G||WX.G.phase==='over')return wcExit();m.hidden=true;m.innerHTML='';wcRecord({forfeit:1});wcExit()};
 setTimeout(()=>{const b=$('wcres');if(b)b.focus()},40);wcFx('pop')}

/* ---------- moves: Solo and the host apply them; a guest sends them to the host ---------- */
function wcSend(a){if(WX.busy&&a.t!=='call'&&a.t!=='catch')return;const G=WX.G;if(!G||G.phase==='over')return;
 if(WX.mode==='net'&&!WX.host){wcNetSend({t:'act',a});if(a.t==='play'){const el=document.querySelector(`.wchc[data-id="${a.id}"]`);if(el)el.classList.add('sent')}return}
 wcApply(WX.me,a)}
function wcApply(pi,a){const G=WX.G;if(!G||G.phase==='over')return false;const ok=wcDo(G,pi,a);if(!ok)return false;wcSync();wcPump();return true}
/* replay new events, then rebuild the table and decide who moves next */
async function wcPump(){if(WX.busy||!WX.G)return;WX.busy=true;const tok=WX.tok;
 try{while(WX.G){const e=WX.G.ev.find(x=>x.n>WX.seen);if(!e)break;WX.seen=e.n;await wcAnim(e);if(tok!==WX.tok||!$('wct'))return}}catch(err){console.error(err)}
 WX.busy=false;if(tok!==WX.tok||!$('wct'))return;wcRender();wcStep()}
function wcStep(){const G=WX.G;if(!G||!$('wct'))return;wcClear();
 if(G.phase==='over'){if(!WX.ended){WX.ended=true;wcLater(()=>wcEnd(),1700)}return}
 if(!WX.host)return;
 const cur=G.P[G.turn],win=G.one&&G.one.p!=null;
 /* a forgotten WILD! call: the regulars may catch it; the window stays open for a moment */
 if(win){const t=G.one.p,seq=G.one.n;G.P.forEach((p,i)=>{if(i===t||p.kind!=='bot')return;const B=WCB[p.diff]||WCB.m;if(G.r()<B.catch){const d=B.react[0]+G.r()*(B.react[1]-B.react[0]);wcLater(()=>{if(WX.G.one&&WX.G.one.n===seq&&!WX.busy)wcApply(i,{t:'catch',p:t})},d)}});
  wcLater(()=>{if(WX.G.one&&WX.G.one.n===seq){WX.G.one=null;wcSync();wcRender();wcStep()}},3200);
  if(G.P[t].kind==='bot'||t===WX.me)wcBubble(t===WX.me?WX.me:t,t===WX.me?'Call WILD!':'',0)}
 if(cur.kind==='bot'){const d=800+G.r()*600+(win?2600:0);wcLater(()=>wcBotMove(G.turn),d)}
 else if(WX.mode==='pp'&&cur.kind!=='bot'&&G.turn!==WX.me)wcCurtain(G.turn);
 else if(WX.cfg&&WX.cfg.timer&&(cur.kind==='you'||cur.kind==='local'||cur.kind==='net')){const seat=G.turn,turns=G.turns;
  if(seat===WX.me)for(let k=3;k>=1;k--)wcLater(()=>{const g=WX.G;if(g.turn===seat&&g.turns===turns)wcFx('tick')},WX.cfg.timer*1000-k*1000);
  wcLater(()=>{const g=WX.G;if(g.turn===seat&&g.turns===turns&&g.phase!=='over'){wcApply(seat,g.phase==='drawn'?{t:'pass'}:{t:'draw'});if(seat===WX.me)wcToast('Time ran out, so you drew a card.')}},WX.cfg.timer*1000)}
 if(G.one&&G.one.p!==WX.me&&G.P[G.one.p].kind==='bot')wcTip(`<b>${esc(G.P[G.one.p].name)}</b> forgot to call WILD! <b>Tap them</b> to catch it!`)}
function wcBotMove(pi){const G=WX.G;if(!G||G.turn!==pi||G.phase==='over'||WX.busy)return;const p=G.P[pi],a=wcBot(G,pi);
 if(a.t==='play'&&p.hand.length===2&&G.r()>=(WCB[p.diff]||WCB.m).forget)wcDo(G,pi,{t:'call'});
 if(a.t==='play')a.id=p.hand[a.i].id;wcApply(pi,a);wcTaunt(pi,a)}
/* ---------- animations ---------- */
function wcLocal(el){const st=$('wct');if(!st||!el)return null;const R=st.getBoundingClientRect(),k=R.width/1600,r=el.getBoundingClientRect();return{x:(r.left-R.left)/k,y:(r.top-R.top)/k,w:r.width/k,h:r.height/k}}
function wcFly(face,from,to,o){o=o||{};const fx=$('wcfx');if(!fx||!from||!to)return wcSleep(0);const d=document.createElement('div');d.className='wcfly'+(o.flip?' flip':'');
 d.style.width=to.w+'px';d.style.height=to.h+'px';d.innerHTML=o.flip?`<div class="fi"><div class="ff">${face}</div><div class="fb">${wcBack(wcBackSel())}</div></div>`:face;fx.appendChild(d);
 const sx=from.w/to.w,dur=wcRM()?60:(o.dur||360),mid=o.arc==null?-40:o.arc,spin=o.spin||0;
 const k=[{transform:`translate(${from.x}px,${from.y}px) rotate(${o.r0||0}deg) scale(${sx})`},{transform:`translate(${(from.x+to.x)/2}px,${(from.y+to.y)/2+mid}px) rotate(${((o.r0||0)+(o.r1||0))/2+spin}deg) scale(${(sx+1)/2*(o.pk||1.12)})`,offset:.5},{transform:`translate(${to.x}px,${to.y}px) rotate(${o.r1||0}deg) scale(1)`}];
 const an=d.animate(k,{duration:dur,easing:'cubic-bezier(.3,.7,.3,1)',fill:'forwards'});
 if(o.flip){const fi=d.querySelector('.fi');fi.animate([{transform:'rotateY(180deg)'},{transform:'rotateY(0deg)'}],{duration:dur,easing:'ease-in-out',fill:'forwards'})}
 return an.finished.then(()=>{if(o.keep)return d;d.remove()}).catch(()=>{d.remove()})}
function wcSeatEl(i){return document.querySelector(`.wcseat[data-seat="${i}"]`)}
function wcSeatSpot(i){const s=wcSeatEl(i);if(!s)return null;const b=s.querySelector(i===WX.me?'.wcav':'.wcbacks')||s.querySelector('.wcav');const r=wcLocal(b);return r&&{x:r.x+r.w/2-28,y:r.y+r.h/2-41,w:56,h:82}}
function wcHandSpot(){return{x:800-56,y:715,w:112,h:164}}
function wcPileSpot(){const d=$('wcdisc');const r=wcLocal(d);return r&&{x:r.x,y:r.y,w:r.w,h:r.h}}
function wcDeckSpot(){return wcLocal($('wcdeck').querySelector('.d1'))}
function wcPop(txt,cls,at){const fx=$('wcfx');if(!fx)return;const e=document.createElement('div');e.className='wcpop '+(cls||'');e.innerHTML=txt;if(at){e.style.left=at.x+'px';e.style.top=at.y+'px'}fx.appendChild(e);setTimeout(()=>e.remove(),1500)}
/* elemental burst: little flames, droplets, leaves or sparks fly out of the pile */
function wcBurst(at,s,n){const fx=$('wcfx');if(!fx||wcRM())return;const b=document.createElement('div');b.className='wcburst';b.style.left=at.x+'px';b.style.top=at.y+'px';b.style.setProperty('--c',WCC[s]||'#fff');const n2=n||10;
 b.innerHTML=Array.from({length:n2},(_,i)=>{const k=s==='w'?WCS[i%4]:s;return `<i style="--a:${i*360/n2+(i%2)*14}deg;--r:${90+(i%3)*36}px;--s:${.7+(i%3)*.25}"><svg viewBox="-13 -13 26 26">${WCG[k]||WCG.w}</svg></i>`}).join('')+'<b></b><b class="b2"></b>';fx.appendChild(b);setTimeout(()=>b.remove(),1000)}
function wcWave(c){const fx=$('wcfx');if(!fx||wcRM())return;const w=document.createElement('div');w.className='wcwave';w.style.setProperty('--c',WCC[c]);fx.appendChild(w);setTimeout(()=>w.remove(),900)}
function wcShake(k){const t=$('wct');if(!t||wcRM())return;t.classList.remove('shk','shk2');void t.offsetWidth;t.classList.add(k>1?'shk2':'shk');setTimeout(()=>t&&t.classList.remove('shk','shk2'),450)}
function wcFlash(c){const f=$('wcflash');if(!f)return;f.style.setProperty('--c',c);f.classList.remove('on');void f.offsetWidth;f.classList.add('on')}
function wcCount(i,d){WX.vc[i]=(WX.vc[i]||0)+d;const s=wcSeatEl(i);if(!s)return;const n=s.querySelector('.wcn');if(n){n.textContent=Math.max(0,WX.vc[i]);n.classList.remove('bump');void n.offsetWidth;n.classList.add('bump')}
 const bk=s.querySelector('.wcbacks');if(bk){const c=Math.min(9,Math.max(0,WX.vc[i]));bk.innerHTML=Array.from({length:c},(_,k)=>`<i class="wcmbk" style="--k:${k-(c-1)/2}">${wcBack(wcBackSel())}</i>`).join('')}}
const WCACT={stun:['STUN!','#ffd45a'],turn:['TURNABOUT!','#8ad8ff'],d2:['+2 CURSE!','#ff8a6a'],d4:['+4 HEX!','#d08aff'],wild:['WILD RUNE!','#fff']};
async function wcAnim(e){const G=WX.G;
 if(e.k==='deal'){const n=e.hand,dk=wcDeckSpot();if(!dk)return;const T=[];WX.vc=G.P.map(()=>0);for(const i of G.P.keys())wcCount(i,0);
  const deck=$('wcdeck');if(deck&&!wcRM()){deck.classList.add('riffle');wcFx('shuffle');await wcSleep(720);deck.classList.remove('riffle')}
  for(let k=0;k<n;k++)for(let i=0;i<G.P.length;i++){const me=i===WX.me;T.push(wcFly(wcBack(wcBackSel()),dk,me?wcHandSpot():wcSeatSpot(i),{dur:300,arc:-30,spin:me?0:-30}).then(()=>{if(!me)wcCount(i,1)}));if(i===0)wcFx('deal');await wcSleep(38)}
  await Promise.all(T);WX.fresh=new Set(G.P[WX.me].hand.map(c=>c.id));wcRenderHand();wcFx('flip');await wcSleep(250);return}
 if(e.k==='turn'){document.querySelectorAll('.wcseat').forEach(s=>s.classList.toggle('on',+s.dataset.seat===e.p));if(e.p===WX.me&&wcMine()){wcFx('turn');const st=$('wcstat');if(st){st.classList.remove('bump');void st.offsetWidth;st.classList.add('bump')}}return}
 if(e.k==='play'){const c=e.c,me=e.p===WX.me;let from;const el=me?document.querySelector(`.wchc[data-id="${c.id}"]`):null;
  if(el){from=wcLocal(el);el.style.visibility='hidden'}else from=wcSeatSpot(e.p);const to=wcPileSpot();if(!to)return;
  if(!me)wcCount(e.p,-1);wcFx('swish');
  await wcFly(wcSVG(c),from,to,{flip:!me,dur:me?320:420,r0:me?0:-20,r1:wcRot(c.id),arc:-60,spin:me?8:-8,pk:1.2});
  const d=$('wcdisc');d.querySelectorAll('.top').forEach(x=>x.classList.remove('top'));d.insertAdjacentHTML('beforeend',wcCardEl(c,'top land',`style="--r:${wcRot(c.id)}deg"`));while(d.children.length>4)d.firstElementChild.remove();
  if(el)el.remove();const gl=$('wcglow');wcTint(e.col);gl.classList.remove('pulse');void gl.offsetWidth;gl.classList.add('pulse');wcFx('slap');
  const mid={x:to.x+to.w/2,y:to.y+to.h/2},act=c.s==='w'||!wcIsNum(c);wcBurst(mid,c.s==='w'?'w':c.s,act?14:8);
  if(WCACT[c.v]){wcPop(WCACT[c.v][0],'act a-'+c.v,{x:800,y:258});wcFx(c.v==='d4'?'d4':c.v==='d2'?'d2':c.v==='turn'?'rev':c.v==='stun'?'stun':'wild');wcShake(c.v==='d4'?2:1)}
  if(c.s==='w'){wcWave(e.col);wcPop(`${wcOrb(e.col,52)}<span>${WCN[e.col]}!</span>`,'col',{x:800,y:352});wcFx('elem',e.col)}
  await wcSleep(WCACT[c.v]?420:150);return}
 if(e.k==='draw'){const me=e.p===WX.me,dk=wcDeckSpot();const n=e.c.length;if(e.stack){wcPop(`+${e.stack}`,'stk',wcCen(e.p));wcFx('big');wcFlash('#ff3a5a');wcShake(e.stack>=4?2:1)}
  for(let k=0;k<n;k++){const card=me?G.P[WX.me].hand.find(x=>x.id===e.c[k]):null;const to=me?{x:800+Math.min(380,G.P[WX.me].hand.length*30)-56,y:715,w:112,h:164}:wcSeatSpot(e.p);
   wcFly(card?wcSVG(card):wcBack(wcBackSel()),dk,to,{flip:!!card,dur:330,arc:-36}).then(()=>{if(!me)wcCount(e.p,1)});wcFx('draw');await wcSleep(n>4?70:110)}
  await wcSleep(330);if(me){WX.fresh=new Set(e.c);wcRenderHand()}const dn=$('wcdn');if(dn)dn.textContent=Math.max(0,+dn.textContent-n);return}
 if(e.k==='skip'){const s=wcSeatEl(e.p);if(s){s.classList.remove('stun');void s.offsetWidth;s.classList.add('stun');const at=wcCen(e.p);if(!wcRM()){const z=document.createElement('div');z.className='wczap';z.style.left=at.x+'px';z.style.top=(at.y+52)+'px';z.innerHTML='<i></i><i></i><i></i><i></i><i></i>';$('wcfx').appendChild(z);setTimeout(()=>z.remove(),1100)}}
  wcPop('Stunned!','stn',wcCen(e.p,-70));await wcSleep(420);return}
 if(e.k==='rev'){const r=$('wcring');r.classList.toggle('rev',e.dir<0);r.classList.remove('flip');void r.offsetWidth;r.classList.add('flip');await wcSleep(420);return}
 if(e.k==='stack'){wcStack();const s=$('wcstack');s.classList.remove('pop');void s.offsetWidth;s.classList.add('pop');return}
 if(e.k==='call'){wcPop('<span>WILD!</span>','call',wcCen(e.p,-84));wcFx('call');const s=wcSeatEl(e.p);if(s&&!s.querySelector('.wcw1'))s.insertAdjacentHTML('beforeend','<span class="wcw1">WILD!</span>');await wcSleep(320);return}
 if(e.k==='catch'){wcPop(`CAUGHT! <small>${esc(G.P[e.by].name)} spotted it · +2 cards</small>`,'caught',wcCen(e.p,-84));wcFx('catch');wcFlash('#ff3a5a');wcShake(1);const dk=wcDeckSpot(),me=e.p===WX.me;
  for(const id of e.c){const card=me?G.P[WX.me].hand.find(x=>x.id===id):null;wcFly(card?wcSVG(card):wcBack(wcBackSel()),dk,me?wcHandSpot():wcSeatSpot(e.p),{flip:!!card,dur:330}).then(()=>{if(!me)wcCount(e.p,1)});wcFx('draw');await wcSleep(120)}
  await wcSleep(350);wcTip('');return}
 if(e.k==='swap'){wcPop('Hands swapped!','act',{x:800,y:300});wcFx('rev');const a=wcSeatSpot(e.a)||wcHandSpot(),b=wcSeatSpot(e.b)||wcHandSpot();for(let k=0;k<4;k++){wcFly(wcBack(wcBackSel()),a,b,{dur:420,spin:180});wcFly(wcBack(wcBackSel()),b,a,{dur:420,spin:-180});await wcSleep(70)}
  await wcSleep(420);const t=WX.vc[e.a];WX.vc[e.a]=WX.vc[e.b];WX.vc[e.b]=t;return}
 if(e.k==='pass'){wcPop('Keeps it','sm',wcCen(e.p,-70));wcFx('flip');await wcSleep(200);return}
 if(e.k==='shuffle'){const d=$('wcdeck');d.classList.remove('riffle');void d.offsetWidth;d.classList.add('riffle');wcFx('shuffle');wcPop('Pile reshuffled','sm',{x:664,y:300});await wcSleep(720);d.classList.remove('riffle');return}
 if(e.k==='win'){const s=wcSeatEl(e.p);if(s)s.classList.add('won');document.querySelectorAll('.wcseat').forEach(x=>x.classList.remove('on'));wcPop(`${e.p===WX.me?'You win!':esc(G.P[e.p].name)+' wins!'}`,'win',{x:800,y:300});wcFx('big');wcFlash(e.p===WX.me?'#ffd45a':'#8a7cf0');await wcSleep(500)}}
function wcCen(i,dy){const s=wcSeatEl(i);const r=s&&wcLocal(s.querySelector('.wcav'));return r?{x:r.x+r.w/2,y:r.y+(dy||0)}:{x:800,y:600}}
function wcTip(h){let t=$('wctip');if(!h){if(t)t.remove();return}if(!t){t=document.createElement('div');t.id='wctip';t.className='wctip';const w=$('wct');if(!w)return;w.appendChild(t)}t.innerHTML=h}
function wcToast(h){const w=$('wct');if(!w)return;const t=document.createElement('div');t.className='wctoast';t.innerHTML=h;w.appendChild(t);setTimeout(()=>t.remove(),2600)}
function wcBubble(i,txt,ms){const b=$('wcbub'+i);if(!b||!txt)return;b.textContent=txt;b.classList.remove('on');void b.offsetWidth;b.classList.add('on');clearTimeout(b._t);b._t=setTimeout(()=>b.classList.remove('on'),ms||2200)}
const WCTAUNT={d4:['Hex on you!','Read \'em and weep.','Four for you!'],d2:['Take two, darling.','Curse you!'],stun:['Sit this one out.','Not so fast.'],turn:['Other way, folks!','Turnabout!'],one:['One card left!','Feeling lucky…'],win:['House wins.','Better luck next hand!']};
function wcTaunt(pi,a){const G=WX.G,p=G.P[pi];if(p.kind!=='bot'||G.r()>.42)return;const c=G.disc[G.disc.length-1];const k=G.phase==='over'?'win':p.hand.length===1?'one':c&&WCTAUNT[c.v]?c.v:null;if(!k)return;const L=WCTAUNT[k];wcLater(()=>wcBubble(pi,L[Math.floor(Math.random()*L.length)]),420)}
/* same screen: hide the hand until the next player taps in */
function wcCurtain(seat){const G=WX.G,m=$('wcmod');if(!m)return;WX.cover=true;wcRenderHand();m.hidden=false;m.className='wcmod wccur';
 m.innerHTML=`<div class="wccb"><canvas width="180" height="180"></canvas><small>Pass the device to</small><b>${esc(G.P[seat].name)}</b><p>Everyone else, look away! Your cards stay hidden until you tap.</p><button class="wcbtn gold" id="wcimr">I'm ${esc(G.P[seat].name)}, show my cards</button></div>`;
 wcPortrait(m.querySelector('canvas'),G.P[seat].av);wcFx('turn');
 $('wcimr').onclick=()=>{m.hidden=true;m.innerHTML='';WX.cover=false;WX.me=seat;wcFx('flip');wcRender();wcStep()};setTimeout(()=>{const b=$('wcimr');if(b)b.focus()},40)}
/* leaving mid-game forfeits the buy-in (kept for callers that ask directly) */
function wcLeaveAsk(){wcMenu()}
function wcExit(){WX.tok++;wcClear();try{wcNetClose()}catch(e){}WX.G=null;wcHome()}
addEventListener('keydown',e=>{if(!$('wct')||ov.className.indexOf('hide')>=0||e.ctrlKey||e.metaKey||e.altKey)return;const m=$('wcmod');if(m&&!m.hidden)return;const ae=document.activeElement;if(ae&&/INPUT|TEXTAREA/.test(ae.tagName))return;
 const k=e.key.toLowerCase();if(k==='d'){e.preventDefault();$('wcdeck').click()}else if(k==='w'){e.preventDefault();$('wcone').click()}else if(k==='h'){e.preventDefault();wcHint()}else if(k==='k'&&$('wckeep')){e.preventDefault();$('wckeep').click()}
 else if((k==='arrowleft'||k==='arrowright')&&!(ae&&ae.classList&&ae.classList.contains('wchc'))){const c=document.querySelector('.wchc.ok')||document.querySelector('.wchc');if(c){e.preventDefault();c.focus()}}});
/* a card game in progress counts as gameplay: the "Running slowly?" offer waits until the player is back in a menu */
{const o0=pfOffer;pfOffer=function(){if(document.getElementById('wct'))return;return o0.apply(this,arguments)}}
