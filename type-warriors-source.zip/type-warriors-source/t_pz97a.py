# python3 t_pz97a.py : 9.7 The Crooked Cue: the hub around a pool table (medallions for the regulars, the spotlight card, the stake
# bar with Play and Practice, Slick Shade, live matches, keys, the tour) and the Trick Shots chalkboard (ten little tables with their
# balls and stars, picking, the bottom bar, Start, keys, the tour), plus frame cost and no page errors.
import asyncio,os,sys,json
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:500]),flush=True)
    if not ok:FAIL.append(name)
PRE="()=>{RS_ASK=false;PZ_TUT_OFF=true;WCRELAYS=[];ST.perfAsked=1;PFW.asked=true;P.gold=100000;P.pz=null;save()}"
MED="""()=>[...document.querySelectorAll('.pz97md')].map(b=>{const r=b.querySelector('.pz97m').getBoundingClientRect(),c=b.querySelector('canvas'),d=c.getContext('2d').getImageData(90,90,1,1).data;
 return {k:b.dataset.k,sel:b.classList.contains('sel'),next:b.classList.contains('next'),lock:b.classList.contains('lock'),dis:b.disabled,won:b.classList.contains('won'),ck:!!b.querySelector('.pz97ck'),
  nm:b.querySelector('.pz97nm').textContent,tag:(b.querySelector('.pz97tag')||{}).textContent||'',x:r.left+r.width/2,y:r.top+r.height/2,w:r.width,painted:d[3]>200}})"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();er=[]
        pg=await b.new_page(viewport={'width':1600,'height':900})
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        pg.on('console',lambda m:er.append('console:'+m.text[:300]) if m.type=='error' and 'ERR_' not in m.text and 'WebSocket' not in m.text else None)
        await pg.goto(H);await pg.wait_for_timeout(1500);await pg.evaluate(PRE);E=pg.evaluate
        # ---------------------------------------------------------------- the hub, mid-progress (like the concept)
        await E("()=>{P.pz=null;P.gold=12006;const Z=PZS();Z.beat={gloop:2,moldwick:1,grizzle:1};Z.vs={gloop:[2,1]};save();PZ.sel=null;PZ.shadeHere=false;PZ.shadeChecked=pzDay();casinoOpen();gameOpen('pz');0}");await pg.wait_for_timeout(1800)
        m=await E(MED)
        st={x['k']:x for x in m}
        chk('hub: a medallion for each of the seven regulars, in ladder order, every portrait painted',[x['k'] for x in m]==['gloop','moldwick','grizzle','vesper','barnacle','hootsworth','mortimer'] and all(x['painted'] for x in m),[(x['k'],x['painted']) for x in m])
        chk('hub: beaten regulars wear a green check, the next one is gold with a NEXT tag and picked',all(st[k]['won'] and st[k]['ck'] for k in ['gloop','moldwick','grizzle']) and st['vesper']['next'] and st['vesper']['sel'] and st['vesper']['tag'].strip()=='NEXT' and not st['vesper']['ck'],m[:4])
        chk('hub: locked regulars are dark, disabled, "? ? ?" with a star row',all(st[k]['lock'] and st[k]['dis'] and st[k]['nm']=='? ? ?' and '★' in st[k]['tag'] for k in ['barnacle','hootsworth','mortimer']),[st[k] for k in ['barnacle','hootsworth','mortimer']])
        r=await E("""()=>{const t=document.getElementById('pz97tab').getBoundingClientRect(),bar=document.getElementById('pz97bar').getBoundingClientRect(),opp=document.getElementById('pzopp').getBoundingClientRect(),nav=document.querySelector('.pznav').getBoundingClientRect();
          const ms=[...document.querySelectorAll('.pz97md')].map(b=>({m:b.querySelector('.pz97m').getBoundingClientRect(),n:b.querySelector('.pz97nm').getBoundingClientRect(),t:(b.querySelector('.pz97tag')||b).getBoundingClientRect()}));
          const hit=(a,c)=>a.left<c.right-1&&c.left<a.right-1&&a.top<c.bottom-1&&c.top<a.bottom-1;let bad=[];
          ms.forEach((a,i)=>{for(const z of[a.m,a.n,a.t]){if(hit(z,bar)||hit(z,opp)||hit(z,nav))bad.push(['panel',i]);}ms.forEach((c,j)=>{if(j>i&&(hit(a.n,c.n)||hit(a.m,c.n)||hit(a.n,c.m)))bad.push(['med',i,j])})});
          const rows=[...document.querySelectorAll('.pzrow')].every(x=>x.getBoundingClientRect().bottom<=t.bottom-20);return {bad,rows}}""")
        chk('hub: medallions, plates and tags overlap neither each other nor the rail, spotlight or stake bar',not r['bad'] and r['rows'],r)
        r=await E("()=>({opp:!!document.querySelector('#pzopp .pzoppi'),name:document.querySelector('.pzoppi .pzh3').textContent,meters:document.querySelectorAll('.pzmtr u').length,chips:[...document.querySelectorAll('.pz97ch')].map(x=>+x.dataset.s),cardChips:document.querySelectorAll('.pz97c').length,play:document.getElementById('pzrackem').textContent,prac:document.getElementById('pzpracs').textContent,ret:document.getElementById('pz97ret').textContent,net:document.getElementById('pz97net').textContent,stake:pzStakeOf('vesper'),mult:pzMultS('vesper',pzStakeOf('vesper'))})")
        win=round(r['stake']*r['mult'])
        chk('hub: the spotlight shows Vesper; the stake bar has her chips, total return, net profit, Play • N coins and Practice vs Vesper',r['opp'] and 'Vesper' in r['name'] and r['meters']==20 and r['chips']==[300,500,1000,2000] and r['cardChips']==4 and f"{r['stake']:,} coins" in r['play'] and 'Play' in r['play'] and r['prac']=='free vs Vesper' and r['ret']==f'{win:,}' and r['net']==f'+{win-r["stake"]:,}',r)
        # picking a regular
        await pg.click('.pz97md[data-k=gloop]');await pg.wait_for_timeout(700)
        r=await E("()=>({sel:PZ.sel,cls:[...document.querySelectorAll('.pz97md.sel')].map(x=>x.dataset.k),name:document.querySelector('.pzoppi .pzh3').textContent,chips:[...document.querySelectorAll('.pz97ch')].map(x=>+x.dataset.s),play:document.getElementById('pzrackem').textContent,prac:document.getElementById('pzpracs').textContent,rec:document.querySelector('.pzfacts').textContent,stake:pzStakeOf('gloop'),scale:getComputedStyle(document.querySelector('.pz97md[data-k=gloop] .pz97m')).transform})")
        chk('hub: clicking a medallion picks that regular (it grows) and the spotlight, chips, Play and Practice follow',r['sel']=='gloop' and r['cls']==['gloop'] and r['name']=='Gloop' and r['chips']==[50,100,200] and f"{r['stake']:,} coins" in r['play'] and r['prac']=='free vs Gloop' and '2-1' in r['rec'] and r['scale']!='none',r)
        await pg.click('.pz97md[data-k=barnacle]',force=True);await pg.wait_for_timeout(300)
        chk('hub: a locked medallion cannot be picked',await E("()=>PZ.sel")=='gloop')
        # the stake bar
        await pg.click('.pz97ch[data-s="200"]');await pg.wait_for_timeout(600)
        r=await E("()=>({stake:pzStakeOf('gloop'),on:[...document.querySelectorAll('.pz97ch.on')].map(x=>+x.dataset.s),card:[...document.querySelectorAll('.pz97c.on')].map(x=>+x.dataset.s),ret:document.getElementById('pz97ret').textContent,net:document.getElementById('pz97net').textContent,pay:document.getElementById('pzpayv').textContent,mult:pzMultS('gloop',200),play:document.getElementById('pzrackem').textContent})")
        w2=round(200*r['mult'])
        chk('stake bar: a chip sets the stake; the pill, the card chips, total return, net profit and Play all follow',r['stake']==200 and r['on']==[200] and r['card']==[200] and r['ret']==f'{w2:,}' and r['net']==f'+{w2-200:,}' and r['pay']==f'{w2:,}' and '200 coins' in r['play'],r)
        await pg.click('.pz97c[data-s="50"]');await pg.wait_for_timeout(500)
        chk('spotlight: its stake chips drive the same stake',await E("()=>pzStakeOf('gloop')==50&&[...document.querySelectorAll('.pz97ch.on')].map(x=>+x.dataset.s).join()==='50'"))
        # keys
        await pg.keyboard.press('2');await pg.wait_for_timeout(300);k1=await E("()=>PZ.sel")
        await pg.keyboard.press('ArrowDown');await pg.wait_for_timeout(300);k2=await E("()=>PZ.sel")
        await pg.keyboard.press('ArrowUp');await pg.keyboard.press('ArrowUp');await pg.wait_for_timeout(300);k3=await E("()=>PZ.sel")
        await pg.keyboard.press('n');await pg.wait_for_timeout(300);k4=await E("()=>PZ.sel")
        s0=await E("()=>pzStakeOf('vesper')");await pg.keyboard.press('ArrowRight');await pg.wait_for_timeout(400);s1=await E("()=>pzStakeOf('vesper')")
        await pg.keyboard.press('5');await pg.wait_for_timeout(300);k5=await E("()=>PZ.sel")
        chk('hub keys: 2, down, up, N and right arrow pick regulars and raise the stake; a locked number does nothing',[k1,k2,k3,k4,k5]==['moldwick','grizzle','gloop','vesper','vesper'] and s1>s0,[k1,k2,k3,k4,k5,s0,s1])
        g0=await E("()=>P.gold");await pg.keyboard.press('Enter');await pg.wait_for_timeout(600)
        r=await E("()=>({on:PZ.on,opp:PZ.M&&PZ.M.opp,stake:PZ.M&&PZ.M.stake,prac:PZ.M&&PZ.M.practice,gold:P.gold})")
        chk('Enter plays the picked regular for the picked stake (the stake is taken)',r['on'] and r['opp']=='vesper' and r['stake']==s1 and not r['prac'] and r['gold']==g0-s1,[g0,r])
        await E("()=>pzForfeit()");await pg.wait_for_timeout(600);await E("()=>{PZ.sel='grizzle';pzHub();0}");await pg.wait_for_timeout(900)
        g0=await E("()=>P.gold");await pg.click('#pzprac');await pg.wait_for_timeout(600)
        r=await E("()=>({opp:PZ.M&&PZ.M.opp,prac:PZ.M&&PZ.M.practice,gold:P.gold})")
        chk('Practice starts a free game against the picked regular',r['opp']=='grizzle' and r['prac'] and r['gold']==g0,r)
        await E("()=>pzForfeit()");await pg.wait_for_timeout(500)
        # broke, friendly, live
        await E("()=>{P.pz=null;P.gold=10;const Z=PZS();Z.beat={gloop:1};save();PZ.sel=null;pzHub();0}");await pg.wait_for_timeout(900)
        r=await E("()=>({play:document.getElementById('pzrackem').textContent,net:document.getElementById('pz97net').textContent,dis:[...document.querySelectorAll('.pz97ch')].every(x=>x.disabled)})")
        await pg.click('#pzrackem');await pg.wait_for_timeout(600)
        r2=await E("()=>({prac:!!(PZ.M&&PZ.M.practice),gold:P.gold})")
        chk('broke: Play reads Free game, chips are out of reach, and it starts a free practice game',r['play'].startswith('Free game') and r['net']=='Free' and r['dis'] and r2['prac'] and r2['gold']==10,[r,r2])
        await E("()=>pzForfeit()");await pg.wait_for_timeout(500)
        await E("()=>{P.pz=null;P.gold=9000;const Z=PZS();Z.beat={gloop:1};Z.dayN=PZ_DAILY;save();PZ.sel=null;pzHub();0}");await pg.wait_for_timeout(900)
        chk('daily limit: Play reads Friendly and the bar says no stake',await E("()=>document.getElementById('pzrackem').textContent.startsWith('Friendly')&&document.getElementById('pz97nx').textContent==='no stake'"))
        await E("""()=>{P.pz=null;P.gold=9000;const Z=PZS();Z.beat={gloop:1,moldwick:1};Z.live={v:PZ_LIVE_V,opp:'grizzle',stake:500,mult:1.5,race:2,practice:false,extended:false,score:[1,0],rack:2,breaker:0,bnr:0,golden:0,pots:3,banks:0,racks:[],bonus:0,seed:5,st:null,B:Array.from({length:16},(_,i)=>[i,0,0,1]),pend:null,rattled:0,pre:1};save();PZ.sel=null;pzHub();0}""");await pg.wait_for_timeout(900)
        r=await E("()=>({res:!!document.getElementById('pzresume'),rs1:!!document.getElementById('pzrs1'),live:(document.querySelector('.pz97md.live .pz97tag')||{}).textContent||'',play:document.getElementById('pzrackem').textContent,dis:[...document.querySelectorAll('.pz97ch')].every(x=>x.disabled)})")
        chk('live match: the resume banner, a LIVE tag on that regular, Play reads Resume and the chips rest',r['res'] and r['rs1'] and 'LIVE 1-0' in r['live'] and r['play'].startswith('Resume') and r['dis'],r)
        await pg.click('#pzrackem');await pg.wait_for_timeout(900)
        chk('live match: Play resumes it',await E("()=>PZ.on&&PZ.M&&PZ.M.opp==='grizzle'"))
        await E("()=>pzForfeit()");await pg.wait_for_timeout(500)
        # Slick Shade and the champion
        await E("()=>{P.pz=null;P.gold=48000;const Z=PZS();for(const k of PZ_ORDER)Z.beat[k]=3;save();PZ.shadeHere=true;PZ.shadeChecked=pzDay();PZ.sel=null;pzHub();0}");await pg.wait_for_timeout(1200)
        m=await E(MED)
        r=await E("()=>({champ:!!document.querySelector('.pz97champ'),crown:(document.querySelector('.pz97md[data-k=mortimer] .pz97tag')||{}).textContent||''})")
        chk('all beaten: seven checks, a champion banner, Mortimer\'s crown, and Slick Shade at the table',sum(1 for x in m if x['won'])==7 and r['champ'] and 'CHAMPION' in r['crown'] and m[0]['k']=='shade' and not m[0]['dis'],[r,[x['k'] for x in m]])
        await pg.click('.pz97md[data-k=shade]');await pg.wait_for_timeout(700)
        r=await E("()=>({sel:PZ.sel,name:document.querySelector('.pzoppi .pzh3').textContent,chips:[...document.querySelectorAll('.pz97ch')].map(x=>+x.dataset.s),prac:document.getElementById('pzpracs').textContent})")
        chk('Slick Shade can be picked: his card, five chips up to the table limit, practice falls back to Gloop',r['sel']=='shade' and r['name']=='Slick Shade' and r['chips']==[500,1000,2000,3000,5000] and r['prac']=='free vs Gloop',r)
        r=await E("""()=>{const L=LIVE.filter(l=>l.cv.isConnected&&l.cv.closest('#pzh'));for(let i=0;i<10;i++)L.forEach(l=>l.fn());const t=[];for(let i=0;i<60;i++){const a=performance.now();L.forEach(l=>l.fn());t.push(performance.now()-a)}t.sort((x,y)=>x-y);return [L.length,t[30],t[57]]}""")
        chk('hub frame cost: everything the hub animates costs well under 3 ms (median, headless)',r[0]>=2 and r[1]<3,r)
        # the hub tour points at the new layout
        await E("()=>{P.pz=null;P.gold=3000;save();PZ.sel=null;PZ.shadeHere=false;PZ_TUT_OFF=false;pzHub();0}")
        ok=False
        for i in range(30):
            await pg.wait_for_timeout(150)
            if await E("()=>!!document.querySelector('.pztuc.in')"):ok=True;break
        steps=[]
        for k in range(7):
            await pg.wait_for_timeout(450)
            steps.append(await E("()=>{const s=document.querySelector('.pztus');return [document.querySelector('.pztut').textContent,!s.hidden]}"))
            await pg.click('.pztun')
        await pg.wait_for_timeout(400);await E("()=>{PZ_TUT_OFF=true;0}")
        chk('the hub tour walks seven steps and every step after the welcome spotlights something on screen',ok and len(steps)==7 and all(s[1] for s in steps[1:]) and steps[1][0]=="Tonight's regulars",steps)
        # ---------------------------------------------------------------- the Trick Shots board
        await E("()=>{P.pz=null;P.gold=1000;const Z=PZS();Z.trick={0:3,1:2,3:1,'$0':1,t0:1,t1:1,t3:1};save();PZ97T.sel=null;PZ97T.seen={};pzHub();0}");await pg.wait_for_timeout(500)
        await pg.click('.pznav button[data-a=trick]');await pg.wait_for_timeout(1700)
        r=await E("""()=>{const c=[...document.querySelectorAll('.pz97tc')];return {n:c.length,ids:c.map(x=>+x.dataset.i),imgs:document.querySelectorAll('.pzti .pztf img').length,want:PZ_TRICK.reduce((a,t)=>a+t.balls.length+1,0),stars:c.map(x=>x.querySelectorAll('.pz97st').length),on:c.map(x=>x.querySelectorAll('.pz97st.on').length),earned:PZ_TRICK.map((t,i)=>pzTrickStars(i)),names:c.map(x=>x.querySelector('b').textContent),nb:c.map(x=>x.querySelector('.pz97nb').textContent),pill:document.getElementById('pz97tp').textContent}}""")
        chk('trick board: ten little tables with every ball of their layout, a number, the name and three stars each',r['n']==10 and r['ids']==list(range(10)) and r['imgs']==r['want'] and all(x==3 for x in r['stars']) and r['nb']==[str(i+1) for i in range(10)] and r['names'][0]=='Straight In',r)
        chk('trick board: earned stars are gold and the header counts them (6 of 30)',r['on']==r['earned'] and '6 of 30 stars' in r['pill'] and '200 gold' in r['pill'],[r['on'],r['earned'],r['pill']])
        r=await E("""()=>{const bd=document.getElementById('pz97bd').getBoundingClientRect(),c=[...document.querySelectorAll('.pz97tc')].map(x=>x.getBoundingClientRect());let bad=[];c.forEach((a,i)=>{if(a.left<bd.left||a.right>bd.right||a.top<bd.top||a.bottom>bd.bottom-14)bad.push(['out',i]);c.forEach((d,j)=>{if(j>i&&a.left<d.right&&d.left<a.right&&a.top<d.bottom&&d.top<a.bottom)bad.push([i,j])})});return bad}""")
        chk('trick board: the cards sit inside the chalkboard without overlapping',not r,r)
        r=await E("()=>({sel:PZ97T.sel,cls:[...document.querySelectorAll('.pz97tc.sel')].map(x=>+x.dataset.i),title:document.querySelector('.pz97tih b').textContent,nb:document.querySelector('.pz97tih .pz97nb').textContent,goal:document.querySelector('.pz97ti p').textContent,want:pzTrickGoalText(PZ_TRICK[1])+'.',hint:document.querySelector('.pz97ti small').textContent,bars:document.querySelectorAll('.pz97tst .pz97st.on').length,prev:document.querySelectorAll('.pz97pvf img').length})")
        chk('trick board: the first unfinished trick is picked and the bar shows its table, number, name, goal, hint and stars',r['sel']==1 and r['cls']==[1] and r['title']=='The Cut' and r['nb']=='2' and r['goal']==r['want'] and 'ghost ball' in r['hint'] and r['bars']==2 and r['prev']==2,r)
        await pg.click('.pz97tc[data-i="6"]');await pg.wait_for_timeout(600)
        r=await E("()=>({sel:PZ97T.sel,cls:[...document.querySelectorAll('.pz97tc.sel')].map(x=>+x.dataset.i),title:document.querySelector('.pz97tih b').textContent,goal:document.querySelector('.pz97ti p').textContent,want:pzTrickGoalText(PZ_TRICK[6])+'.',hint:document.querySelector('.pz97ti small').textContent,prev:document.querySelectorAll('.pz97pvf img').length,on:PZ.on})")
        chk('trick board: clicking a table picks it (no match yet) and the bar follows; untried hints stay hidden',r['sel']==6 and r['cls']==[6] and r['title']=='Combination' and r['goal']==r['want'] and 'hint at the table' in r['hint'] and r['prev']==3 and not r['on'],r)
        await pg.keyboard.press('ArrowRight');await pg.wait_for_timeout(250);a=await E("()=>PZ97T.sel")
        await pg.keyboard.press('ArrowUp');await pg.wait_for_timeout(250);b2=await E("()=>PZ97T.sel")
        await pg.keyboard.press('0');await pg.wait_for_timeout(250);c=await E("()=>PZ97T.sel")
        await pg.keyboard.press('3');await pg.wait_for_timeout(250);d=await E("()=>[PZ97T.sel,document.querySelector('.pz97tih b').textContent]")
        chk('trick board keys: arrows walk the board, 0 picks the tenth, 3 the third',[a,b2,c,d[0]]==[7,2,9,2] and d[1]=='Draw Back',[a,b2,c,d])
        await pg.click('#pz97start');await wf(pg,"PZ.ph==='aim'&&PZ.mode==='aim'&&PZ.M&&PZ.M.trick")
        r=await E("()=>({on:PZ.on,n:PZ.M&&PZ.M.trick&&PZ.M.trick.n,balls:PZ.B&&PZ.B.filter(b=>b.on).length})")
        chk('Start launches the picked trick shot with its layout',r['on'] and r['n']==2 and r['balls']==2,r)
        await E("()=>pzTrickLeave()");await pg.wait_for_timeout(1700)
        r=await E("()=>({board:!!document.getElementById('pz97bd'),sel:PZ97T.sel,cls:[...document.querySelectorAll('.pz97tc.sel')].map(x=>+x.dataset.i)})")
        chk('leaving a trick comes back to the board with that trick still picked',r['board'] and r['sel']==2 and r['cls']==[2],r)
        await pg.click('.pz97tc[data-i="4"]');await pg.wait_for_timeout(400);await pg.click('.pz97tc[data-i="4"]');await wf(pg,"PZ.M&&PZ.M.trick")
        chk('clicking the picked table again starts it too',await E("()=>!!(PZ.on&&PZ.M&&PZ.M.trick&&PZ.M.trick.n===4)"))
        await E("()=>pzTrickLeave()");await pg.wait_for_timeout(1500)
        await pg.keyboard.press('Enter');await wf(pg,"PZ.M&&PZ.M.trick")
        chk('Enter starts the picked trick',await E("()=>!!(PZ.on&&PZ.M&&PZ.M.trick&&PZ.M.trick.n===4)"))
        await E("()=>pzTrickLeave()");await pg.wait_for_timeout(1500)
        r=await E("""()=>{const L=LIVE.filter(l=>l.cv.isConnected&&l.cv.closest('#pzk'));for(let i=0;i<10;i++)L.forEach(l=>l.fn());const t=[];for(let i=0;i<60;i++){const a=performance.now();L.forEach(l=>l.fn());t.push(performance.now()-a)}t.sort((x,y)=>x-y);return [L.length,t[30],t[57]]}""")
        chk('trick board frame cost: only Granny draws, well under 2 ms (median, headless)',r[0]==1 and r[1]<2,r)
        await pg.click('#pzbk');await pg.wait_for_timeout(900)
        chk('the back button returns to the hub',await E("()=>!!document.getElementById('pzh')&&!document.getElementById('pz97bd')"))
        # the trick tour
        await E("()=>{const Z=PZS();Z.tut.trick=0;save();PZ_TUT_OFF=false;pzTrick();0}")
        ok=False
        for i in range(30):
            await pg.wait_for_timeout(150)
            if await E("()=>!!document.querySelector('.pztuc.in')"):ok=True;break
        await pg.wait_for_timeout(450)
        s1=await E("()=>[document.querySelector('.pztut').textContent,!document.querySelector('.pztus').hidden,document.getElementById('pz97gb').classList.contains('hide')]")
        await pg.click('.pztun');await pg.wait_for_timeout(500)
        s2=await E("()=>[document.querySelector('.pztut').textContent,!document.querySelector('.pztus').hidden]")
        await pg.click('.pztun');await pg.wait_for_timeout(500);await E("()=>{PZ_TUT_OFF=true;0}")
        chk('the Trick Shots tour has Granny explain, then the stars and gold, and saves itself',ok and s1[0]=='Trick Shots' and s1[1] and s1[2] and s2[0]=='Stars and gold' and s2[1] and await E("()=>!!PZS().tut.trick"),[s1,s2])
        chk('no page errors',not er,er)
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
async def wf(pg,js,n=80,step=150):
    for i in range(n):
        if await pg.evaluate("()=>!!("+js+")"):return True
        await pg.wait_for_timeout(step)
    return False
asyncio.run(main())
