/* ---------- combat effects: slash trails, impact sparks, damage numbers ---------- */
const raW=()=>RKM[WP[P.weapon].r]||0,wtype=()=>WP[P.weapon].t||'sword';
const RAR_COL=['#f4ecd8','#7dffb0','#6fb4ff','#c47bff','#ffc94a','#ff5cf0'];
const fxCol=(i,ra)=>ra>=5?hsx((S.t*300+i*47)%360,100,64):ra===4?(i%2?'#ffe08a':'#ffb02e'):WP[P.weapon].col;
function dnum(x,y,txt,o){o=o||{};const ra=raW(),big=o.big;if(S.dn.length>40)S.dn.shift();S.dn.push({x,y,vx:(Math.random()-.5)*(big?90:50),vy:big?-190:-110,g:big?300:200,t:0,ml:big?1.1:.62,txt,sz:(big?36:19)+ra*(big?3:1.4)+(o.crit?14:0),ra,crit:!!o.crit,big,sd:Math.random()*6})}
function drawDn(c){c.save();c.textAlign='center';c.textBaseline='middle';c.lineJoin='round';for(const q of S.dn){const u=q.t/q.ml,pop=u<.12?.6+u/.12*.7:u<.22?1.3-(u-.12)/.1*.3:1,a=u>.68?1-(u-.68)/.32:1;c.globalAlpha=Math.max(0,a)*(q.big?1:.85);c.font=`${Math.round(q.sz*pop)}px "Pirata One",Georgia,serif`;
 let fill=q.ra>=5?hsx((S.t*400+q.sd*60)%360,100,68):RAR_COL[q.ra];if(q.crit)fill='#ff5c8a';
 c.lineWidth=q.big?6:4;c.strokeStyle=q.ra>=4?'#3a1a00':'#000';c.strokeText(q.txt,q.x,q.y);
 if(q.ra>=3&&q.big){c.shadowColor=fill;c.shadowBlur=8+q.ra*3}
 c.fillStyle=fill;c.fillText(q.txt,q.x,q.y);c.shadowBlur=0}c.restore()}
const SLK={sword:'slash',katana:'katana',scythe:'scythe',axe:'chop',mace:'chop',dagger:'stab',spear:'thrust'};
function slashFx(e){const ra=raW(),k=SLK[wtype()];if(!k)return;const o={k,ox:KX+80,oy:GY-140,tx:e.x,ty:e.y-e.h*.5,t:0,ml:.22+ra*.03,ra,col:WP[P.weapon].col,sd:Math.random()};S.sl.push(o);
 if(k==='stab')S.sl.push(Object.assign({},o,{oy:o.oy+26,tx:o.tx-8,ty:o.ty+14,t:-.07}));
 if(ra>=4)for(let i=0;i<6+ra*2;i++){const u=Math.random();S.ps.push({x:lerp(o.ox,o.tx,u),y:lerp(o.oy,o.ty,u)+(Math.random()-.5)*60,vx:(Math.random()-.5)*120,vy:-60-Math.random()*90,l:.6,ml:.6,c:ra>=5?hsx(Math.random()*360,100,70):'#ffe08a',s:3+Math.random()*3,g:120})}}
function slashPt(q,s){const {ox,oy,tx,ty}=q;let A,C,B;
 if(q.k==='slash'){A=[ox,oy-80];C=[(ox+tx)/2,Math.min(oy,ty)-170];B=[tx+40,ty+70]}
 else if(q.k==='katana'){A=[ox-30,oy-40];C=[(ox+tx)/2,Math.min(oy,ty)-90];B=[tx+90,ty+90]}
 else if(q.k==='scythe'){A=[ox-20,oy-110];C=[(ox+tx)/2+20,Math.min(oy,ty)-230];B=[tx+50,ty+110]}
 else if(q.k==='chop'){A=[tx-30,ty-200];C=[tx+80,ty-70];B=[tx+10,ty+50]}
 else{A=[ox+40,oy];C=[(ox+tx)/2,(oy+ty)/2];B=[tx,ty]}
 const u=1-s;return[u*u*A[0]+2*u*s*C[0]+s*s*B[0],u*u*A[1]+2*u*s*C[1]+s*s*B[1]]}
function drawSlash(c){c.save();c.lineJoin='round';for(const q of S.sl){if(q.t<0)continue;const u=q.t/q.ml,sB=Math.min(1,q.t/(q.ml*.4)),sA=Math.max(0,(q.t-q.ml*.25)/(q.ml*.75));if(sB-sA<.02)continue;
  const W0=({slash:26,katana:14,scythe:40,chop:36,stab:11,thrust:15})[q.k]*(1+q.ra*.16),fade=Math.pow(1-u,.7),N=18,pts=[];
  for(let i=0;i<=N;i++){const s=sA+(sB-sA)*i/N,p=slashPt(q,s),p2=slashPt(q,Math.min(1,s+.01)),p1=slashPt(q,Math.max(0,s-.01));let nx=-(p2[1]-p1[1]),ny=p2[0]-p1[0];const l=Math.hypot(nx,ny)||1;nx/=l;ny/=l;pts.push([p[0],p[1],nx,ny,Math.pow(Math.sin(Math.PI*i/N),.75)])}
  const strip=(w,fill,off)=>{c.fillStyle=fill;c.beginPath();for(let i=0;i<=N;i++){const p=pts[i];c.lineTo(p[0]+p[2]*(w*p[4]/2+off),p[1]+p[3]*(w*p[4]/2+off))}for(let i=N;i>=0;i--){const p=pts[i];c.lineTo(p[0]-p[2]*(w*p[4]/2-off),p[1]-p[3]*(w*p[4]/2-off))}c.closePath();c.fill()};
  c.globalAlpha=fade;
  if(q.ra>=5){for(let j=0;j<3;j++){c.globalCompositeOperation='lighter';strip(W0*.8,hsx((S.t*300+j*120)%360,100,60),(j-1)*W0*.22);c.globalCompositeOperation='source-over'}}
  else{if(q.ra>=2){c.shadowColor=q.ra>=4?'#ffd76a':q.col;c.shadowBlur=6+q.ra*4}strip(W0,q.ra===4?'#ffcf5a':q.col,0);c.shadowBlur=0}
  c.globalAlpha=fade*.9;strip(W0*.4,'#fff',0)}
 c.restore()}
function impactFx(x,y,big){const ra=raW(),t=wtype(),col=WP[P.weapon].col,k=big?1:.45,n=m=>Math.max(1,Math.round(m*k*(1+ra*.35))),C=i=>fxCol(i,ra);
 const add=o=>{if(S.fx.length<160)S.fx.push(Object.assign({x,y,t:0,ml:.35},o))};
 switch(t){
  case 'sword':for(let i=0;i<n(6);i++)add({k:'line',a:Math.random()*TAU,l:22+ra*4,v:260+Math.random()*200,w:3,c:C(i),ml:.28});break;
  case 'katana':for(let i=0;i<n(3);i++)add({k:'line',a:-.6+(Math.random()-.5)*.5,l:70+ra*8,v:400,w:2.4,c:i%2?'#dff8ff':C(i),ml:.24});break;
  case 'dagger':for(let i=0;i<n(5);i++)add({k:'line',a:(Math.random()-.5)*2.2-1,l:12+ra*2,v:420,w:2.6,c:C(i),ml:.22});break;
  case 'axe':burst(x,y,'#8a5a2a',n(9),{v:340,s:6,l:.7,up:200});add({k:'ring',r0:6,r1:60+ra*8,w:8,c:C(0),ml:.3});if(big)S.shake=Math.max(S.shake,8);break;
  case 'mace':add({k:'ring',r0:6,r1:90+ra*10,w:12,c:C(0),ml:.42});add({k:'ring',r0:2,r1:56,w:6,c:'#fff',ml:.3});burst(x,y+20,'#bfa88a',n(6),{v:220,s:8,l:.6,g:400});if(big)S.shake=Math.max(S.shake,8);break;
  case 'spear':for(let i=0;i<n(5);i++)add({k:'line',a:(Math.random()-.5)*.8,l:46+ra*6,v:520,w:2.6,c:C(i),ml:.26});break;
  case 'scythe':for(let i=0;i<n(5);i++)add({k:'star',s:5+Math.random()*4,vy:-60-Math.random()*70,rot:Math.random()*3,c:C(i),ml:.55,dx:(Math.random()-.5)*60});add({k:'ring',r0:4,r1:56,w:5,c:C(1),ml:.32});break;
  case 'bow':for(let i=0;i<n(4);i++)add({k:'line',a:Math.PI+(Math.random()-.5)*2,l:26,v:300,w:2,c:'#f4e4b8',ml:.3});burst(x,y,col,n(4),{v:200,s:4});break;
  case 'staff':add({k:'ring',r0:4,r1:70+ra*8,w:4,c:C(0),ml:.5});add({k:'ring',r0:2,r1:44,w:3,c:'#fff',ml:.4});for(let i=0;i<n(4);i++)add({k:'star',s:6,vy:-50,rot:i,c:C(i),ml:.5,dx:(i-2)*24});break;
  case 'wand':for(let i=0;i<n(6);i++)add({k:'star',s:5+Math.random()*5,vy:-90-Math.random()*60,rot:Math.random()*3,c:C(i),ml:.6,dx:(Math.random()-.5)*90});break}
 if(ra>=2&&big)add({k:'flash',r:50+ra*14,c:C(0),ml:.22});
 if(ra>=3)burst(x,y,'#ffffff',n(4),{v:300,s:3});
 if(ra>=4&&big)for(let i=0;i<n(6);i++)add({k:'star',s:6+Math.random()*4,vy:-120-Math.random()*80,rot:Math.random()*3,c:i%2?'#fff3a0':'#ffb02e',ml:.7,dx:(Math.random()-.5)*120});
 if(ra>=5&&big)add({k:'ring',r0:8,r1:130,w:8,c:hsx(S.t*300%360,100,65),ml:.5})}
function drawFxList(c){c.save();c.lineCap='round';for(const q of S.fx){const u=q.t/q.ml,a=1-u;c.globalAlpha=Math.max(0,a);
 if(q.k==='line'){const d=q.v*q.t,x0=q.x+Math.cos(q.a)*d,y0=q.y+Math.sin(q.a)*d,x1=x0+Math.cos(q.a)*q.l*a,y1=y0+Math.sin(q.a)*q.l*a;c.strokeStyle=q.c;c.lineWidth=q.w*(1+a);c.shadowColor=q.c;c.shadowBlur=6;c.beginPath();c.moveTo(x0,y0);c.lineTo(x1,y1);c.stroke();c.shadowBlur=0}
 else if(q.k==='ring'){const r=q.r0+(q.r1-q.r0)*(1-Math.pow(1-u,2.2));c.strokeStyle=q.c;c.lineWidth=Math.max(.5,q.w*a);c.beginPath();c.arc(q.x,q.y,r,0,TAU);c.stroke()}
 else if(q.k==='flash'){const r=q.r*(.6+u*.6),g=c.createRadialGradient(q.x,q.y,0,q.x,q.y,r);g.addColorStop(0,'#fff');g.addColorStop(.35,q.c);g.addColorStop(1,'#0000');c.fillStyle=g;c.globalAlpha=a*.85;c.beginPath();c.arc(q.x,q.y,r,0,TAU);c.fill()}
 else if(q.k==='star'){const x=q.x+q.dx*u,y=q.y+q.vy*q.t,s=q.s*(1-u*.5);c.save();c.translate(x,y);c.rotate(q.rot+q.t*4);c.fillStyle=q.c;c.beginPath();for(let i=0;i<8;i++){const r=i%2?s*.35:s;c.lineTo(Math.cos(i*Math.PI/4)*r,Math.sin(i*Math.PI/4)*r)}c.closePath();c.fill();c.restore()}}
 c.restore()}
