# python3 t_bal102.py [--quick] [--only slot,alone,all,endless] [--seeds N] [--workers W] [--reuse] [--html game.html] [--out results.json]
#        [--resume] [--xonly TOWER] [--slotseeds N --stressseeds N --aloneseeds N --allseeds N --eseeds N] [--amodes mix,hp]
# Balance test for the two 10.2 towers, the Moonblade Sentinel (moon) and the Phantom Lantern (lant), against the older towers,
# with the bots the balance work has always used (the t_ramparts bot with world_balance.py's fair pad choice and the map's tier cap).
# Four experiments, every run seeded (Math.random is replaced by a seeded generator, so a run is repeatable):
#  1. slot     the mixed build Ballista, Blazer, Frost, Bell + X (X fills every fifth tower), X = each new tower and its peers, on all
#              nine campaign maps (moss frost ember coral wreck abyss meadow foundry storm), several seeds: win rate, health, stars. The
#              plain maps are won by every X, so a "stress" copy plays the same with monster health x1.25 from wave 4 on, where X decides.
#  2. alone    damage removed per supply: X alone on the same four pads of each map, the same budget (early 1200, mid 3000, late 6500,
#              spent on tier 1 first, then the lowest tier up to the map's cap), the same waves (the castle cannot fall, no income, no
#              abilities); value = health the towers removed / supply spent (99e's damage meter: health actually lost, no overkill).
#              Waves get extra strength F per map and budget (calibrated first: the Prism alone removes about 60%), so that no tower
#              clears them outright and the number measures the tower, not the wave. Two wave models bracket real late waves (more
#              monsters and tougher ones): "mix" = sqrt(F) times as many monsters (at most 4) and the rest as health (favours towers that
#              hit crowds), "hp" = health only (the game's own crowd sizes; favours single-target damage). The criteria use the
#              geometric mean of the two.
#  3. all      all-of-one-tower builds on the nine maps: "lazy" (no upgrades, no abilities, like the lazy Ballista build) and "full"
#              (upgrades and abilities).
#  4. endless  endless Wonderland reach (cap 125) for the reference build prism/dragon/frost/tide/still and with each new tower swapped in
#              (the plain t_ramparts bot, as tools/td/grav_bot.py: the HANDOFF's reference is 110 with it). A full board of fourteen
#              tier-5 towers meets a wall near wave 110 whatever the towers (97c's curve), so the builds are also played with at most
#              eight towers.
# Pass criteria (stated before the numbers; UPDATE_10_2_PLAN.md and the review brief):
#  Moonblade  (a) value per supply (alone, both wave models) best or near-best among the mid-price towers (Still 220, Hive 350,
#                 Prism 400, Starfall 450): at least 0.95 x the best of them, and not above 1.30 x the best of them;
#             (b) lazy all-Moonblade loses at least five of the nine maps;
#             (c) endless Wonderland reach with a Moonblade swapped in at most reference + 10 waves (full board and eight towers).
#  Lantern    (d) value per supply (alone, both wave models) within 0.85-1.15 x the mean (geometric) of the Prism, Dragon Roost, Hive;
#             (e) in the stress slot test its win rate is within the range of the Prism, Dragon Roost and Hive (+-15 points).
#  Both       (f) no page errors in any run.
# Results go to ../tools/td/bal102_results.json (--reuse evaluates that file again without playing; --resume continues a stopped batch
# from results.json.part; --xonly lant replays one tower's runs after a retune). A full run is about 1,100 games: about three hours on
# four cores (the endless games take 10-15 minutes each); --quick (four maps, one seed, fewer towers) about 25 minutes.
import asyncio,json,math,os,sys,time
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
ARGS=sys.argv[1:]
def opt(name,default=None):
    if name in ARGS:
        i=ARGS.index(name);return ARGS[i+1] if i+1<len(ARGS) and not ARGS[i+1].startswith('--') else True
    return default
QUICK='--quick' in ARGS
HTML=os.path.abspath(opt('--html') or os.path.join(HERE,'out.html'))
OUT=opt('--out') or os.path.join(HERE,'../tools/td/bal102_results.json');PART=OUT+'.part'
W=int(opt('--workers',3));SEEDS=int(opt('--seeds',1 if QUICK else 3))
ONLY=(opt('--only') or 'slot,alone,all,endless').split(',')
MAPS=['moss','ember','wreck','storm'] if QUICK else ['moss','frost','ember','coral','wreck','abyss','meadow','foundry','storm']
NEW=['moon','lant'];MID=['still','hive','prism','star'];LPEER=['prism','dragon','hive']
SLOT_X=['moon','lant','prism','dragon','hive','still','star']
ALONE_X=['moon','lant','prism','dragon','hive','still','star'] if QUICK else ['moon','lant','prism','dragon','hive','still','star','ballista','bell','brazier','mortar','tide','grav']
ALL_X=['moon','lant','prism','hive','ballista'] if QUICK else ['moon','lant','prism','dragon','hive','star','ballista']
STRESS_K=1.25;STRESS_W=4   # monster health x STRESS_K from wave STRESS_W on (x1.5 from wave 1 broke every build before its fifth tower stood)
BUDGETS=[('early',1200,.30,.45),('mid',3000,.55,.70),('late',6500,.80,1.0)]  # name, supply, first and last wave as a share of the map's waves
CAL_F=.6
ENDLESS=[('reference',['prism','dragon','frost','tide','still']),('moon for still',['prism','dragon','frost','tide','moon']),('moon for prism',['moon','dragon','frost','tide','still']),
         ('lant for still',['prism','dragon','frost','tide','lant']),('lant for prism',['lant','dragon','frost','tide','still']),('lant for dragon',['prism','lant','frost','tide','still']),
         ('hive for still (control)',['prism','dragon','frost','tide','hive'])]
# a full board of fourteen tier-5 towers meets the endless health curve at a wall near wave 110 (97c), whatever the towers, so the same
# builds are also played with at most eight towers, where the reach still depends on how good the towers are
ENDLESS8=[(n+' (8 towers)',o) for n,o in ENDLESS if not n.startswith('hive') and n!='lant for dragon']
if QUICK:ENDLESS=ENDLESS[:3]+ENDLESS[3:4];ENDLESS8=[]
ECAP=60 if QUICK else 125

BOT=open(os.path.join(HERE,'t_ramparts.py')).read().split('BOT=r"""',1)[1].split('"""',1)[0]
# the endless runs use the plain t_ramparts bot, as tools/td/grav_bot.py does (the HANDOFF's Wonderland numbers: reference 110)
BOTP=BOT.replace("p.tw.type.slice(0,2)","p.tw.type.slice(0,3)").replace("steps<30*60*90","steps<(opt.maxSteps||30*60*90)")
BOT=BOT.replace("const top=RP_MAXT(R.map)","const top=R.map.maxT||RP_MAXT(R.map)").replace("p.tw.type.slice(0,2)","p.tw.type.slice(0,3)")
PICK="""const sam=R.map.paths.map(P=>{const o=[];for(let j=1;j<P.length;j++){const n=Math.ceil(Math.hypot(P[j][0]-P[j-1][0],P[j][1]-P[j-1][1])/25);for(let k=0;k<n;k++)o.push([P[j-1][0]+(P[j][0]-P[j-1][0])*k/n,P[j-1][1]+(P[j][1]-P[j-1][1])*k/n])}return o});
 const cvp=(p,i)=>sam[i].filter(q=>(q[0]-p.x)**2+((q[1]-p.y)/.75)**2<210*210).length;
 const pick=()=>{const fr=R.pads.filter(p=>!p.tw);if(!fr.length)return null;const load=sam.map((_,i)=>R.pads.filter(p=>p.tw).reduce((a,p)=>a+cvp(p,i),0));
   let best=null,bs=-1;for(const p of fr){let sc=0;sam.forEach((_,i)=>{sc+=cvp(p,i)/(1+load[i]/40)});if(sc>bs){bs=sc;best=p}}return best};"""
BOT=BOT.replace("const pads=[...R.pads].sort((a,b)=>cov(b)-cov(a));","const pads=[...R.pads].sort((a,b)=>cov(b)-cov(a));"+PICK).replace("const free=pads.find(p=>!p.tw);","const free=pick();")
BOT=BOT.replace("steps<30*60*90","steps<(opt.maxSteps||30*60*90)")   # the endless runs need more than the bot's 90-minute cap (it stopped every build at wave 77)
assert "const free=pick();" in BOT and "R.map.maxT||RP_MAXT" in BOT and "opt.maxSteps" in BOT
SETUP="()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const r=RPP();r.dragon=1;r.new99j=1;r.stars={moss:3,frost:3,ember:3,coral:3,wreck:3,abyss:3,meadow:3,foundry:3};for(const k in r.tut)r.tut[k]=1;for(const k of['build','wave','coins','upgrade','abil','rune','twist','twist_frost','twist_ember','twist_wonder'])r.tut[k]=1;save()}"
# seeded Math.random (mulberry32), monster health multiplier and the health spawned, per-type damage (99e meter)
HARN=r"""(seed)=>{let a=seed>>>0;Math.random=function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296};
 window.BALHPK=1;window.BALCNT=1;window.BALHPW=0;{const w0=rpWaveStart;rpWaveStart=function(){const R=RPX,n0=R&&R.wave;const r=w0.apply(this,arguments);try{const c=window.BALCNT||1;if(c>1&&R&&R.wave!==n0){const q=R.q.slice();for(const it of q)for(let j=1;j<c;j++)R.q.push({id:it.id,at:it.at+j*.45});R.q.sort((a,b)=>a.at-b.at)}}catch(x){}return r}}
 {const s0=rpSpawn;rpSpawn=function(){const e=s0.apply(this,arguments);try{if(e&&RPX){const k=RPX.wave>=(window.BALHPW||0)?(window.BALHPK||1):1;if(k!==1){e.hp=Math.round(e.hp*k);e.mx=e.hp}RPX.balHP=(RPX.balHP||0)+e.mx}}catch(x){}return e}}
 window.balDm=R=>{const o={};for(const p of R.pads){const tw=p.tw;if(!tw)continue;o[tw.type]=(o[tw.type]||0)+(tw.rpqD||0)}for(const s of R.rpqSold||[])o[s.type]=(o[s.type]||0)+s.d;for(const k in o)o[k]=Math.round(o[k]);return o};
 /* X alone on the K best pads (the same fair pick as the bot, made with no towers placed), budget B spent on tier 1 first then the lowest tier */
 window.balAlone=(m,t,B,w0,w1,K,hpk,am)=>{try{rpLeave()}catch(e){}rpStart(m);const R=RPX;R.tut=null;R.hold=false;R.spd=1;const top=R.map.maxT||RP_MAXT(R.map);
  const sam=R.map.paths.map(P=>{const o=[];for(let j=1;j<P.length;j++){const n=Math.ceil(Math.hypot(P[j][0]-P[j-1][0],P[j][1]-P[j-1][1])/25);for(let k=0;k<n;k++)o.push([P[j-1][0]+(P[j][0]-P[j-1][0])*k/n,P[j-1][1]+(P[j][1]-P[j-1][1])*k/n])}return o});
  const cvp=(p,i)=>sam[i].filter(q=>(q[0]-p.x)**2+((q[1]-p.y)/.75)**2<210*210).length;const chosen=[];
  for(let n=0;n<K;n++){const load=sam.map((_,i)=>chosen.reduce((a,p)=>a+cvp(p,i),0));let best=null,bs=-1;for(const p of R.pads){if(chosen.includes(p))continue;let sc=0;sam.forEach((_,i)=>{sc+=cvp(p,i)/(1+load[i]/40)});if(sc>bs){bs=sc;best=p}}if(best)chosen.push(best)}
  let spent=0;R.supply=1e9;for(const p of chosen){const c=rpCost(t,1);if(spent+c>B)break;rpBuild(p,t);if(p.tw){p.tw.build=1;p.tw.upK=1;spent+=c}}
  for(let g=0;g<40;g++){const tw=R.pads.filter(p=>p.tw&&p.tw.tier<top).map(p=>p.tw).sort((a,b)=>a.tier-b.tier)[0];if(!tw)break;const c=rpCost(tw.type,tw.tier+1);if(spent+c>B)break;rpUpgrade(tw);tw.upK=1;spent+=c}
  /* the extra wave strength F: monsters x c (more of them, half a second apart) and health x F/c */
  const cnt=am==='hp'?1:Math.max(1,Math.min(4,Math.round(Math.sqrt(hpk))));R.supply=0;R.hp=1e9;R.wave=w0-1;R.wst='build';R.cd=0;window.BALHPK=hpk/cnt;window.BALCNT=cnt;R.balHP=0;let steps=0;
  for(let w=w0;w<=w1;w++){if(R.wst==='done'||R.over)break;R.wst='build';R.cd=0;rpWaveStart();while(R.wst==='run'&&steps<30*60*40){steps++;R.hp=1e9;rpStep(R,1/30)}}
  const dm=balDm(R),d=Object.values(dm).reduce((a,b)=>a+b,0),out={map:m,t,B,w0,w1,spent,dmg:Math.round(d),hp:Math.round(R.balHP),kills:R.kills,towers:R.pads.filter(p=>p.tw).map(p=>p.tw.type.slice(0,3)+p.tw.tier).join(' '),
   un:Math.round(R.rpqUn||0),ln:[R.lnPhN||0,R.lnCuts||0,R.lnSoulN||0],mb:[R.mbThrows||0,R.mbHits||0],cnt};window.BALHPK=1;window.BALCNT=1;try{rpLeave()}catch(e){}return out};
 return 1}"""
SS={'slot':int(opt('--slotseeds',SEEDS)),'stress':int(opt('--stressseeds',SEEDS)),'alone':int(opt('--aloneseeds',max(1,SEEDS-1))),'all':int(opt('--allseeds',max(1,SEEDS-1)))}
def slot_tasks():
    T=[]
    for st in ([1.0,STRESS_K]):
        for m in MAPS:
            for x in SLOT_X:
                for s in range(SS['slot'] if st==1 else SS['stress']):T.append({'kind':'slot','map':m,'x':x,'seed':101+s,'hpk':st,'hpw':STRESS_W if st!=1 else 0,'opt':{'up':1,'order':['ballista','brazier','frost','bell',x]}})
    return T
def wrange(maxw,m,a,b):
    n=maxw[m];w0=max(1,round(n*a));return w0,max(w0,round(n*b))
AMODES=(opt('--amodes') or 'mix,hp').split(',')
AMX={'mix':ALONE_X,'hp':['moon','lant','prism','dragon','hive','still','star']}
def alone_tasks(maxw,hk):
    T=[]
    for am in AMODES:
        for m in MAPS:
            for (bn,B,a,b) in BUDGETS:
                w0,w1=wrange(maxw,m,a,b)
                for x in AMX[am]:
                    for s in range(SS['alone']):T.append({'kind':'alone','map':m,'x':x,'seed':201+s,'bud':bn,'B':B,'w0':w0,'w1':w1,'hpk':hk[(m,bn,am)],'am':am})
    return T
async def calibrate(maxw):
    # the wave health per map and budget: the Prism (the reference) alone should remove about CAL_F of it, so that no tower clears the
    # waves outright (then every tower would score the same) and the number measures the tower
    hk={};print(f'calibrating the alone waves (Prism removes about {CAL_F:.0%})',flush=True)
    async with async_playwright() as p:
        br=await p.chromium.launch();sem=asyncio.Semaphore(W)
        async def one(m,bn,B,a,b,am=None):
            async with sem:
                w0,w1=wrange(maxw,m,a,b);k=1.6;f=0
                for it in range(5):
                    r=await run(br,{'kind':'alone','map':m,'x':'prism','seed':201,'bud':bn,'B':B,'w0':w0,'w1':w1,'hpk':k,'am':am},[],[]);f=r['dmg']/max(1,r['hp'])
                    if abs(f-CAL_F)<=.08:break
                    k=round(k*(2.2 if f>.96 else max(.5,min(2,(f/CAL_F)**1.4))),2)
                hk[(m,bn,am)]=k;print(f'   {am:<4}{m:<8}{bn:<6} waves {w0}-{w1} strength x{k} (Prism {f:.0%})',flush=True)
        await asyncio.gather(*[one(m,*bb,am) for am in AMODES for m in MAPS for bb in BUDGETS]);await br.close()
    return hk
def all_tasks():
    T=[]
    for m in MAPS:
        for x in ALL_X:
            for s in range(SS['all']):
                T.append({'kind':'all','map':m,'x':x,'seed':301+s,'mode':'lazy','hpk':1,'opt':{'up':0,'noAbil':1,'order':[x]}})
                T.append({'kind':'all','map':m,'x':x,'seed':301+s,'mode':'full','hpk':1,'opt':{'up':1,'order':[x]}})
    return T
def endless_tasks():
    return [{'kind':'endless','map':'wonder','name':n,'seed':401+s,'hpk':1,'opt':{'up':1,'order':o,'maxW':ECAP,'maxSteps':30*60*400,**({'maxT':8} if '(8 towers)' in n else {})}} for n,o in ENDLESS+ENDLESS8 for s in range(int(opt('--eseeds',1)))]
async def run(br,t,res,errs):
    pg=await br.new_page(viewport={'width':800,'height':450});er=[];pg.on('pageerror',lambda e:er.append(str(e)[:200]))
    await pg.goto('file://'+HTML,timeout=240000);await pg.wait_for_timeout(1000)
    await pg.evaluate(SETUP);await pg.evaluate("()=>{"+(BOTP if t['kind']=='endless' else BOT)+"}");await pg.evaluate(HARN,t['seed'])
    t0=time.time()
    if t['kind']=='alone':
        r=await pg.evaluate("(t)=>balAlone(t.map,t.x,t.B,t.w0,t.w1,4,t.hpk,t.am||'mix')",t)
    else:
        r=await pg.evaluate("(t)=>{window.BALHPK=t.hpk;window.BALHPW=t.hpw||0;const r=rpBot(t.map,t.opt);r.dm=balDm(RPX);r.balHP=Math.round(RPX.balHP||0);try{rpLeave()}catch(e){}return r}",t)
    r.update({k:v for k,v in t.items() if k!='opt'});r['secs']=round(time.time()-t0);r['errors']=er[:3];res.append(r)
    if er:errs.append((t,er[:2]))
    await pg.close();return r
def fmt(r):
    if r['kind']=='alone':return f"alone {r['map']:<8}{r['bud']:<6}{r['x']:<9} spent {r['spent']:>5} dmg {r['dmg']:>8} of {r['hp']:>8} ({100*r['dmg']/max(1,r['hp']):4.0f}%)  per supply {r['dmg']/max(1,r['spent']):7.1f}  [{r['towers']}] ({r['secs']}s)"
    if r['kind']=='endless':return f"endless {r['name']:<26} seed {r['seed']} wave {r['wave']:>3} won {int(r['won'])}  [{r['towers'][:90]}] ({r['secs']}s)"
    tag=r['kind']+('/'+r['mode'] if r.get('mode') else '')+(f" x{r['hpk']}" if r.get('hpk',1)!=1 else '')
    return f"{tag:<12} {r['map']:<8}{r['x']:<9} seed {r['seed']} won {str(r['won']):<5} hp {r['hp']:>2} stars {r['stars']} wave {r['wave']:>2} ({r['secs']}s)"
async def play(tasks,prev=None):
    res=list(prev or []);errs=[]
    async with async_playwright() as p:
        br=await p.chromium.launch();sem=asyncio.Semaphore(W);done=[0]
        async def one(t):
            async with sem:
                for att in range(2):
                    try:
                        r=await asyncio.wait_for(run(br,t,res,errs),5400);done[0]+=1
                        if PART:json.dump(res,open(PART,'w'))   # partial results, so a long batch can be stopped and resumed (--resume)
                        if t['kind']!='slot' or not QUICK:print(f"[{done[0]}/{len(tasks)}] "+fmt(r),flush=True)
                        return
                    except Exception as e:
                        print('ERR',t.get('kind'),t.get('map'),t.get('x',t.get('name')),repr(e)[:200],flush=True)
                errs.append((t,['did not finish']))
        await asyncio.gather(*[one(t) for t in tasks]);await br.close()
    return res,errs
def gmean(v):
    v=[x for x in v if x>0];return math.exp(sum(math.log(x) for x in v)/len(v)) if v else 0
def evaluate(R,errs):
    FAIL=[];N=[0]
    def chk(name,ok,info=''):
        N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('  '+str(info) if info!='' else ''),flush=True)
        if not ok:FAIL.append(name)
    maps=[m for m in MAPS]
    # ---------- 1. slot
    S=[r for r in R if r['kind']=='slot']
    if S:
        print('\n== 1. slot 5 of Ballista, Blazer, Frost, Bell + X: win rate / mean health left / mean stars (per map: won of seeds, mean health)')
        for hk in (1.0,STRESS_K):
            print(f'-- monster health x{hk}')
            print(f"{'X':<8}"+''.join(f"{m:>10}" for m in maps)+'    win%  hp   stars')
            for x in SLOT_X:
                row=[r for r in S if r['x']==x and r['hpk']==hk]
                if not row:continue
                cells=''
                for m in maps:
                    q=[r for r in row if r['map']==m]
                    cells+=f"{sum(r['won'] for r in q)}/{len(q)} {sum(r['hp'] for r in q)/max(1,len(q)):4.1f}".rjust(10) if q else ' '*10
                print(f"{x:<8}{cells}  {100*sum(r['won'] for r in row)/len(row):5.0f} {sum(r['hp'] for r in row)/len(row):4.1f}  {sum(r['stars'] for r in row)/len(row):4.2f}")
        st={x:[r for r in S if r['x']==x and r['hpk']==STRESS_K] for x in SLOT_X}
        wr={x:100*sum(r['won'] for r in v)/len(v) for x,v in st.items() if v}
        if 'lant' in wr and all(p in wr for p in LPEER):
            lo=min(wr[p] for p in LPEER)-15;hi=max(wr[p] for p in LPEER)+15
            chk(f"(e) Lantern stress-slot win rate {wr['lant']:.0f}% within the Prism/Dragon/Hive range +-15 ({lo:.0f}-{hi:.0f})",lo<=wr['lant']<=hi)
        if 'moon' in wr:print(f"   Moonblade stress-slot win rate {wr['moon']:.0f}% (peers: "+', '.join(f"{p} {wr[p]:.0f}%" for p in SLOT_X if p in wr and p!='moon')+')')
    # ---------- 2. alone
    A=[r for r in R if r['kind']=='alone']
    IDX={}
    if A:
        IDXM={}
        for am in ('mix','hp'):
            AA=[r for r in A if r.get('am','mix')==am]
            if not AA:continue
            print(f"\n== 2{'a' if am=='mix' else 'b'}. damage removed per supply, each tower alone on the same four pads, same budget, same waves; "+
                  ("waves made stronger with more monsters (x sqrt F, at most 4) and more health" if am=='mix' else "waves made stronger with health only (the game's own crowd sizes)")+
                  f" so that the Prism alone removes about {round(CAL_F*100)}%")
            xs=[x for x in ALONE_X if any(r['x']==x for r in AA)]
            keys=sorted({(r['map'],r['bud']) for r in AA},key=lambda k:(maps.index(k[0]) if k[0] in maps else 99,[b[0] for b in BUDGETS].index(k[1])))
            val={};frac={}
            for r in AA:val.setdefault((r['map'],r['bud'],r['x']),[]).append(r['dmg']/max(1,r['spent']));frac.setdefault((r['map'],r['bud'],r['x']),[]).append(r['dmg']/max(1,r['hp']))
            print(f"{'map/budget':<15}"+''.join(f"{x[:7]:>8}" for x in xs)+'   (health removed per supply; moon vs the best mid-price tower, lant vs the Prism/Dragon/Hive mean)')
            rel={x:[] for x in xs}
            for k in keys:
                v={x:sum(val.get((k[0],k[1],x),[0]))/max(1,len(val.get((k[0],k[1],x),[1]))) for x in xs}
                ref=v.get('prism') or 1
                for x in xs:
                    if v[x]>0:rel[x].append(v[x]/ref)
                bm=max(v[m] for m in MID if m in v);lp=gmean([v[p] for p in LPEER if p in v])
                sat=[x for x in xs if (k[0],k[1],x) in frac and sum(frac[(k[0],k[1],x)])/len(frac[(k[0],k[1],x)])>.9]
                print(f"{k[0]+' '+k[1]:<15}"+''.join(f"{v[x]:8.1f}" for x in xs)+f"   moon {v.get('moon',0)/bm:4.2f}  lant {v.get('lant',0)/max(1e-9,lp):4.2f}"+(f"  (over 90% cleared: {','.join(sat)})" if sat else ''))
            IDXM[am]={x:gmean(rel[x]) for x in xs}
            print('index (geometric mean over maps and budgets, Prism = 1.00): '+'  '.join(f"{x} {IDXM[am][x]:.2f}" for x in sorted(xs,key=lambda z:-IDXM[am][z])))
            for bn,_,_,_ in BUDGETS:
                sub={x:gmean([sum(val[(m,bn,x)])/len(val[(m,bn,x)]) for m in maps if (m,bn,x) in val]) for x in xs}
                pr=sub.get('prism') or 1
                print(f'   {bn:<6}: '+'  '.join(f"{x} {sub[x]/pr:.2f}" for x in sorted(xs,key=lambda z:-sub[z])))
        both=[x for x in ALONE_X if all(x in IDXM[m] for m in IDXM)]
        IDX={x:gmean([IDXM[m][x] for m in IDXM]) for x in both}
        print('\nvalue per supply, both wave models (geometric mean; Prism = 1.00): '+'  '.join(f"{x} {IDX[x]:.2f}" for x in sorted(IDX,key=lambda z:-IDX[z])))
        unb=[(r['x'],r['map'],round(r['un']/max(1,r['dmg']+r['un']),3)) for r in A if r['map'] in ('moss','frost','coral','meadow') and r.get('un',0)>.02*(r['dmg']+r['un'])]
        chk('the damage meter credits every tower (on maps without hazards under 2% of the damage is unattributed)',not unb,unb[:6])
        if 'moon' in IDX:
            best=max(IDX[m] for m in MID if m in IDX);bn=[m for m in MID if IDX.get(m)==best][0];k=IDX['moon']/best
            chk(f"(a) Moonblade value per supply {IDX['moon']:.2f} = {k:.2f} x the best mid-price tower ({bn} {best:.2f}): wanted 0.95-1.30",.95<=k<=1.30)
        if 'lant' in IDX and all(p in IDX for p in LPEER):
            lp=gmean([IDX[p] for p in LPEER]);k=IDX['lant']/lp
            chk(f"(d) Lantern value per supply {IDX['lant']:.2f} = {k:.2f} x the Prism/Dragon/Hive mean ({lp:.2f}; "+', '.join(f"{p} {IDX[p]:.2f}" for p in LPEER)+"): wanted 0.85-1.15",.85<=k<=1.15)
    # ---------- 3. all of one tower
    L=[r for r in R if r['kind']=='all']
    if L:
        print('\n== 3. all-of-one-tower builds: maps won (of the nine; per map won/seeds), lazy = no upgrades or abilities, full = upgrades + abilities')
        for mode in ('lazy','full'):
            print(f'-- {mode}')
            for x in ALL_X:
                row=[r for r in L if r['x']==x and r['mode']==mode]
                if not row:continue
                won_maps=sum(1 for m in maps if any(r['map']==m for r in row) and sum(r['won'] for r in row if r['map']==m)*2>len([r for r in row if r['map']==m]))
                cells=' '.join(f"{m[:5]}:{sum(r['won'] for r in row if r['map']==m)}/{len([r for r in row if r['map']==m])}/{max([r['wave'] for r in row if r['map']==m] or [0])}" for m in maps)
                print(f"{x:<9} wins {won_maps}/{len(maps)}   {cells}")
        lz=[r for r in L if r['x']=='moon' and r['mode']=='lazy']
        if lz:
            lost=sum(1 for m in maps if [r for r in lz if r['map']==m] and sum(r['won'] for r in lz if r['map']==m)*2<=len([r for r in lz if r['map']==m]))
            need=math.ceil(len(maps)/2)
            chk(f"(b) lazy all-Moonblade loses {lost} of {len(maps)} maps (at least {need} wanted)",lost>=need)
    # ---------- 4. endless
    E=[r for r in R if r['kind']=='endless']
    if E:
        print(f'\n== 4. endless Wonderland reach (cap {ECAP}), mean of seeds')
        reach={}
        for n,_ in ENDLESS+ENDLESS8:
            q=[r['wave'] for r in E if r['name']==n]
            if q:reach[n]=sum(q)/len(q);print(f"{n:<26} {reach[n]:6.1f}   ({', '.join(str(x) for x in q)})")
        for suf in ('',' (8 towers)'):
            ref=reach.get('reference'+suf)
            if ref is None:continue
            mm=max([v for n,v in reach.items() if n.startswith('moon') and (('(8 towers)' in n)==bool(suf))] or [0])
            chk(f"(c{suf}) Wonderland reach with a Moonblade swapped in {mm:.0f} <= reference {ref:.0f} + 10",mm<=ref+10)
            for n,v in reach.items():
                if n.startswith('lant') and (('(8 towers)' in n)==bool(suf)):print(f"   {n}: {v-ref:+.0f} waves vs the reference")
    chk('(f) no page errors in any run',not errs,errs[:3])
    print(f"\n{N[0]-len(FAIL)}/{N[0]} passed"+(' FAILED: '+'; '.join(FAIL) if FAIL else ''))
    return FAIL
async def maxwaves():
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await br.new_page();await pg.goto('file://'+HTML,timeout=240000);await pg.wait_for_timeout(800)
        r=await pg.evaluate("()=>Object.fromEntries(RP_MAPS.map(m=>[m.id,m.waves]))");await br.close();return r
async def main():
    t0=time.time()
    if '--reuse' in ARGS:
        R=json.load(open(OUT));errs=[(r,r['errors']) for r in R if r.get('errors')]
    else:
        mw=await maxwaves();tasks=[]
        prev=json.load(open(PART)) if '--resume' in ARGS and os.path.exists(PART) else []
        if 'endless' in ONLY:tasks+=endless_tasks()   # the longest runs first
        if 'slot' in ONLY:tasks+=slot_tasks()
        if 'alone' in ONLY:
            hk=await calibrate(mw);tasks+=alone_tasks(mw,hk)
        if 'all' in ONLY:tasks+=all_tasks()
        XO=opt('--xonly')   # replay only one tower's runs (after a retune): slot / alone / all runs of that tower, endless builds naming it
        if XO:tasks=[t for t in tasks if t.get('x')==XO or XO in (t.get('name') or '')]
        key=lambda t:json.dumps(dict({k:t.get(k) for k in ('kind','map','x','name','seed','mode','bud','hpk')},am=t.get('am','mix') if t.get('kind')=='alone' else None),sort_keys=True)
        have={key(r) for r in prev};tasks=[t for t in tasks if key(t) not in have]
        print(f"{len(tasks)} runs on {W} workers, maps {' '.join(MAPS)}, seeds {SEEDS}"+(f" ({len(prev)} kept from the last partial run)" if prev else ''),flush=True)
        R,errs=await play(tasks,prev)
        old=[]
        if os.path.exists(OUT) and '--fresh' not in ARGS:
            try:old=[r for r in json.load(open(OUT)) if r['kind'] not in ONLY]
            except Exception:old=[]
        R=old+[r for r in R if r['kind'] in ONLY];json.dump(R,open(OUT,'w'),indent=0)
    F=evaluate(R,errs);print(f"({round(time.time()-t0)} s)")
    sys.exit(1 if F else 0)
asyncio.run(main())
