/* ===== UPDATE 10.5, THE GREAT TURKEY TROT: styles (99u6, classes gtt*) =====
   Chunky #12081f outlines, indigo glass panels, gold accents, Pirata One titles, Poppins UI. The game box is 1476 x 798 inside the casino
   frame (like Penalty Kings); the stage is a fixed 1600 x 900 scaled by #wrap, so the same layout fits every window size.
   Only transform / opacity animate; nothing blurs the backdrop and no filter or shadow is animated. */
{const st=document.createElement('style');st.textContent=`
.gttw{text-align:left;position:relative;width:1476px;height:798px;display:grid;grid-template-columns:884px 1fr;gap:14px;font-family:var(--ui)}
.gttl{display:flex;flex-direction:column;gap:7px;min-height:0}
.gtth{display:flex;align-items:center;gap:10px;height:60px;padding:0 12px 0 18px;border-radius:18px;background:linear-gradient(180deg,#2a1d66,#150e3a);border:2px solid #c99a3a;box-shadow:0 0 0 2px #12081f}
.gtth h3{margin:0 auto 0 0;font:400 38px/1 'Pirata One',Georgia,serif;color:#ffd45a;-webkit-text-stroke:1px #12081f;letter-spacing:.02em;white-space:nowrap}
.gttchip{display:inline-flex;align-items:center;gap:6px;height:32px;padding:0 12px;border-radius:16px;background:#12081fc8;border:2px solid #6a4ab0;font:700 13.5px var(--ui);color:#fff8e8;white-space:nowrap}
.gttchip.ph{border-color:#ffd45a;color:#ffd45a}
.gtthelp{all:unset;box-sizing:border-box;cursor:pointer;width:34px;height:34px;border-radius:50%;display:grid;place-items:center;font:800 18px var(--ui);color:#2a1002;background:linear-gradient(180deg,#fff0a0,#f0a820);border:2px solid #12081f;transition:transform .15s}
.gtthelp:hover{transform:scale(1.12)}
.gttcard{display:flex;flex-direction:column;gap:6px}
.gttrow{position:relative;display:grid;grid-template-columns:50px 126px 1fr 146px 122px;align-items:center;gap:10px;height:96px;padding:0 14px 0 10px;border-radius:18px;cursor:pointer;background:linear-gradient(180deg,#221a5c,#110b34);border:2px solid #3a3070;box-shadow:0 3px 0 #0a0620;transition:transform .16s cubic-bezier(.34,1.56,.64,1),border-color .15s,background .15s}
.gttrow:hover{transform:translateX(3px);border-color:#8a6ad0}
.gttrow:focus-visible{outline:3px solid #fff;outline-offset:2px}
.gttrow.sel{border-color:#ffd45a;background:linear-gradient(180deg,#3a2a7a,#1e1456);box-shadow:0 0 0 2px #12081f,0 0 0 4px #ffd45a55}
.gttrow.first{border-color:#7dff9a}
.gttrow.hop{animation:gtthop .4s cubic-bezier(.34,1.56,.64,1)}
@keyframes gtthop{0%{transform:translateY(0)}35%{transform:translateY(-6px)}100%{transform:translateY(0)}}
.gttcl{position:relative;display:grid;place-items:center;width:44px;height:58px;border-radius:8px 8px 14px 14px;border:3px solid #12081f;box-shadow:inset 0 -9px 0 var(--c2),0 3px 0 #0006}
.gttcl b{font:400 30px/1 'Pirata One',Georgia,serif;margin-top:-6px}
.gttrow canvas{width:126px;height:96px;display:block}
.gttnm{display:flex;flex-direction:column;gap:3px;min-width:0}
.gttnm b{font:400 28px/1.1 'Pirata One',Georgia,serif;color:#fff8e8;white-space:nowrap}
.gttnm em{align-self:flex-start;font:800 11px var(--ui);font-style:normal;letter-spacing:.08em;text-transform:uppercase;padding:2px 9px;border-radius:9px;border:1.5px solid #12081f;color:#12081f}
.gtts-front{background:#ffb04a}.gtts-close{background:#c8a0ff}.gtts-stalk{background:#7ae0c8}
.gttnm small{font:500 12.5px/1.2 var(--ui);color:#b8acdc;white-space:nowrap}
.gttform{display:flex;gap:4px;justify-content:center}
.gtm{display:grid;place-items:center;width:23px;height:23px;border-radius:50%;font:800 12px var(--ui);font-style:normal;border:2px solid #12081f;color:#12081f}
.gtm.m1{background:#ffd45a}.gtm.m2{background:#d8dcea}.gtm.m3{background:#e0a070}.gtm.m4{background:#4a4278;color:#e8e0ff}.gtm.m0{background:#ffffff10;border-color:#ffffff22;color:#ffffff44}
.gttodds{all:unset;box-sizing:border-box;cursor:pointer;display:grid;place-items:center;height:58px;border-radius:14px;font:800 28px var(--ui);color:#2a1002;background:linear-gradient(180deg,#fff0a0,#f4b020 60%,#d88a10);border:2px solid #12081f;box-shadow:0 4px 0 #7a4a08;transition:transform .12s}
.gttrow:hover .gttodds{transform:translateY(-2px)}
.gttodds.wait{background:linear-gradient(180deg,#4a4278,#2a2260);color:#b8acdc;box-shadow:0 4px 0 #0a0620;animation:gttpulse 1s ease-in-out infinite}
.gttodds.off{background:#2a2260;color:#8a7eb8;box-shadow:0 4px 0 #0a0620;font-size:24px}
.gttodds.first{background:linear-gradient(180deg,#9affb8,#22a85a);box-shadow:0 4px 0 #0e5a2a;font-size:22px}
@keyframes gttpulse{0%,100%{opacity:1}50%{opacity:.55}}
.gttmine{display:none;position:absolute;right:-6px;top:-8px;padding:2px 9px;border-radius:10px;border:2px solid #12081f;background:#ffd45a;font:900 11px var(--ui);letter-spacing:.12em;color:#2a1002;text-decoration:none;transform:rotate(6deg)}
.gttrow.mine{border-color:#ffd45a}.gttrow.mine .gttmine{display:block}
.gttfoot{display:flex;align-items:center;gap:10px;height:44px}
.gttbtn{all:unset;box-sizing:border-box;cursor:pointer;display:inline-flex;align-items:center;gap:8px;height:42px;padding:0 18px;border-radius:13px;font:700 15px var(--ui);color:#ffe9b0;background:linear-gradient(180deg,#8a1230,#3e0814);border:2px solid #b8861a;box-shadow:0 4px 0 #1a0408,0 6px 12px #0008;transition:transform .12s}
.gttbtn:hover:not(:disabled){transform:translateY(-2px)}.gttbtn:active:not(:disabled){transform:translateY(2px)}.gttbtn:focus-visible{outline:3px solid #fff;outline-offset:2px}
.gttw kbd{display:inline-block;min-width:20px;padding:1px 6px;border-radius:6px;background:#12081f66;border:1px solid #ffffff44;font:700 11px var(--ui);text-align:center;color:inherit;letter-spacing:.02em}
.gttpr{padding:6px 14px;border-radius:12px;background:#12081fc8;border:2px solid #ffd45a;font:700 14px var(--ui);color:#ffd45a;animation:gttpulse 1s ease-in-out infinite}.gttpr[hidden]{display:none}
.gttleg{margin-left:auto;font:600 12.5px var(--ui);color:#a99be0}
/* the bet slip */
.gtts{display:flex;flex-direction:column;gap:7px;padding:12px 14px 44px;border-radius:22px;background:linear-gradient(180deg,#1e1650,#0e0a2c);border:2px solid #6a4ab0;box-shadow:0 0 0 2px #12081f;min-height:0}
.gtts h4,.gttrcr h4{margin:0;text-align:center;font:400 32px/1 'Pirata One',Georgia,serif;color:#ffd45a;-webkit-text-stroke:1px #12081f}
.gtttabs{display:grid;grid-template-columns:repeat(4,1fr);gap:6px}
.gtttab{all:unset;box-sizing:border-box;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:2px;padding:6px 2px 5px;border-radius:12px;background:#ffffff0d;border:2px solid #3a3070;color:#c4badf;transition:transform .15s}
.gtttab b{font:800 15px var(--ui)}.gtttab:hover{transform:translateY(-2px)}.gtttab.on{background:linear-gradient(180deg,#ffe37a,#e8a018);border-color:#fff2a0;color:#3a1a04}
.gtttab:focus-visible{outline:3px solid #fff;outline-offset:2px}
.gttdesc{margin:0;text-align:center;font:500 13px var(--ui);color:#b8acdc;min-height:18px}
.gttpick{display:flex;align-items:center;justify-content:space-between;gap:10px;min-height:46px;padding:6px 14px;border-radius:14px;background:#12081f;border:2px solid #3a3070;font:600 14.5px/1.2 var(--ui);color:#fff8e8}
.gttpick b{font:800 24px var(--ui);color:#ffd45a;white-space:nowrap}.gttpick b.q{font-size:22px;color:#7dff9a}.gttpick span{min-width:0}
.gtts .ctl{padding:8px 12px;border-radius:16px;width:auto;max-width:none}
.gtts .bet{gap:6px 10px;justify-content:space-between}
.gtts .bv{font:700 15px var(--ui)}
.gtts .chips{gap:5px}.gtts .chip{width:46px;height:46px;font-size:15px;border-width:3px}
.gtts .bx{display:flex;gap:5px}.gtts .bx button{font-size:13px;padding:6px 10px;box-shadow:0 3px 0 #1a0408}
.gttadd{all:unset;box-sizing:border-box;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:10px;height:46px;border-radius:14px;font:800 17px var(--ui);color:#06301a;background:linear-gradient(180deg,#8affa8,#22a85a);border:2px solid #12081f;box-shadow:0 4px 0 #0e5a2a,0 6px 12px #0008;transition:transform .12s}
.gttadd small{font:700 13px var(--ui);opacity:.8}.gttadd:hover:not(:disabled){transform:translateY(-2px)}.gttadd:active{transform:translateY(2px)}.gttadd:focus-visible{outline:3px solid #fff;outline-offset:2px}
.gttslip{display:flex;flex-direction:column;gap:5px;min-height:0}
.gttempty{padding:10px 14px;border-radius:12px;border:2px dashed #3a3070;font:500 13px/1.35 var(--ui);color:#a99be0;text-align:center}
.gttsl{display:grid;grid-template-columns:70px 1fr auto 30px;align-items:center;gap:8px;min-height:48px;padding:0 8px 0 10px;border-radius:12px;background:#ffffff0d;border:2px solid #3a3070}
.gttsl>i{font:800 11px var(--ui);font-style:normal;letter-spacing:.06em;text-transform:uppercase;text-align:center;padding:3px 0;border-radius:8px;background:#ffd45a;color:#2a1002;border:1.5px solid #12081f}
.gttsl span{display:flex;flex-direction:column;min-width:0}.gttsl b{font:700 13px/1.2 var(--ui);color:#fff8e8;white-space:pre-line}.gttsl small{font:500 12px var(--ui);color:#b8acdc}
.gttsl u{text-decoration:none;font:800 16px var(--ui);color:#7dff9a}
.gttsl button{all:unset;cursor:pointer;width:28px;height:28px;border-radius:50%;display:grid;place-items:center;font:800 13px var(--ui);color:#ffd0d8;background:#5a0a1a;border:1.5px solid #b8861a}.gttsl button:hover{background:#8a1230}.gttsl button:focus-visible{outline:3px solid #fff}
.gtttot{display:grid;grid-template-columns:1fr 1fr;gap:4px 10px;padding:6px 10px;border-radius:12px;background:#12081f;border:2px solid #3a3070}
.gtttot small{display:block;font:700 11px var(--ui);letter-spacing:.12em;text-transform:uppercase;color:#a99be0}.gtttot b{font:800 20px var(--ui);color:#fff8e8;display:flex;align-items:center;gap:5px}
.gtttot p{grid-column:1/-1;margin:0;text-align:center;font:600 12.5px var(--ui);color:#a99be0}.gtttot p.cap{color:#ffb04a;font-weight:800}
.gttcn{display:inline-block;width:16px;height:16px;border-radius:50%;background:radial-gradient(circle at 35% 30%,#fff6b0,#e8a018);border:2px solid #12081f}
.gttgo{height:60px;width:100%;font-size:26px;padding:0;display:flex;align-items:center;justify-content:center;gap:12px}.gttgo:disabled{filter:grayscale(.7) brightness(.7)}.gttgo kbd{font-size:12px}
.gtts .cmsg{margin:0;min-height:36px;font:600 14px/1.25 var(--ui)!important;text-align:left;padding:6px 12px!important;border-radius:12px!important}
/* windows over the game box */
.gttmod{position:absolute;inset:0;z-index:6;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:16px;border-radius:22px;background:#0a0620f0;animation:gttpop .35s ease both}
.gttmod h3{margin:0;font:400 46px 'Pirata One',Georgia,serif;color:#ffd45a;-webkit-text-stroke:1px #12081f}
@keyframes gttpop{0%{opacity:0;transform:scale(.96)}100%{opacity:1;transform:none}}
.gtthg{display:grid;grid-template-columns:repeat(3,330px);gap:18px}
.gtthg>div{padding:16px 18px 18px;border-radius:20px;background:#1e1650;border:2px solid #6a4ab0;color:#e8e0ff;box-shadow:0 0 0 2px #12081f}
.gtthg b{display:block;margin:10px 0 6px;font:800 19px var(--ui);color:#fff8e8}.gtthg p{margin:0;font:500 14px/1.45 var(--ui)}
.gttil{display:flex;align-items:center;justify-content:center;gap:10px;height:110px;border-radius:14px;background:linear-gradient(180deg,#3a2a7a,#1a1250);border:2px solid #12081f;font-style:normal}
.il1 span{font:400 44px 'Pirata One',serif;color:#fff8e8;background:#c87a2a;border:3px solid #12081f;border-radius:10px;padding:0 12px;box-shadow:0 0 0 3px #ffd45a}
.il1 em,.il3 em{font:800 28px var(--ui);font-style:normal;padding:4px 12px;border-radius:12px;color:#2a1002;background:linear-gradient(180deg,#fff0a0,#f4b020);border:2px solid #12081f}
.il2{gap:6px;padding:10px}.il2 u{text-decoration:none;font:800 13px var(--ui);padding:5px 7px;border-radius:9px;background:#ffffff14;color:#e8e0ff;border:2px solid #3a3070}.il2 u:first-child{background:#ffd45a;color:#2a1002}
.il3{flex-direction:column;gap:12px}.il3 em{font-size:20px;background:linear-gradient(180deg,#8affa8,#22a85a);color:#06301a}
.gttdots{display:flex;gap:26px}.gttdots s{width:20px;height:20px;border-radius:50%;border:2px solid #12081f;background:#c8a0ff}.gttdots s:nth-child(2){background:#ffd45a;box-shadow:0 0 0 3px #ffd45a88}.gttdots s:nth-child(3){background:#7ae0c8}
.gttstg{display:grid;grid-template-columns:repeat(3,230px);gap:12px}
.gttstg>div{padding:10px 14px;border-radius:14px;background:#1e1650;border:2px solid #6a4ab0;text-align:center}.gttstg small{display:block;font:700 11px var(--ui);letter-spacing:.1em;text-transform:uppercase;color:#a99be0}.gttstg b{font:800 20px var(--ui);color:#fff8e8}
.gttstt{max-height:300px;overflow:auto;border-radius:14px;border:2px solid #3a3070;background:#12081f}
.gttstt table{border-collapse:collapse;min-width:560px;font:500 13.5px var(--ui);color:#e8e0ff}.gttstt th,.gttstt td{padding:4px 14px;text-align:left}.gttstt th{font:700 11px var(--ui);letter-spacing:.1em;text-transform:uppercase;color:#a99be0}.gttstt tr:nth-child(even){background:#ffffff08}.gttstt .hid{color:#7dff9a;font-size:12px}
/* the race */
.gttrace{display:block;overflow:hidden;border-radius:22px;border:3px solid #c99a3a;box-shadow:0 0 0 3px #12081f,0 16px 30px #000a;background:#120a2a}
.gttrace>canvas{position:absolute;left:0;top:-16px;width:1470px;height:827px;display:block}
.gttrace.shk>canvas{animation:gttshk .35s linear}
@keyframes gttshk{0%{transform:translate(0,0)}20%{transform:translate(-5px,3px)}40%{transform:translate(4px,-3px)}60%{transform:translate(-3px,2px)}80%{transform:translate(2px,-1px)}100%{transform:none}}
.gttclk{position:absolute;left:14px;top:12px;display:flex;flex-direction:column;padding:6px 16px;border-radius:14px;background:#12081fd0;border:2px solid #6a4ab0;color:#fff8e8}
.gttclk b{font:800 28px/1.25 var(--ui);font-variant-numeric:tabular-nums}.gttclk small{font:600 12px var(--ui);color:#b8acdc;white-space:nowrap}
.gttps{position:absolute;left:50%;top:10px;margin-left:-440px;width:880px;height:56px;border-radius:16px;background:#12081fd0;border:2px solid #6a4ab0}
.gttpsl{position:absolute;left:30px;right:50px;top:27px;height:4px;border-radius:2px;background:linear-gradient(90deg,#6a4ab0,#ffd45a)}
.gttpsf{position:absolute;left:836px;top:8px;width:20px;height:38px;background:repeating-conic-gradient(#fff 0 25%,#12081f 0 50%) 0 0/10px 10px;border:2px solid #12081f;border-radius:3px;box-shadow:0 0 0 2px #fff8}
.gttpd{position:absolute;left:30px;margin-left:-12px;width:24px;height:24px;border-radius:50%;display:grid;place-items:center;font:800 13px var(--ui);font-style:normal;border:2px solid #12081f;will-change:transform}
.gttpd b{font-weight:800}.gttpd.mine{box-shadow:0 0 0 3px #ffd45a}
.gttbets{position:absolute;right:14px;top:78px;width:320px;display:flex;flex-direction:column;gap:6px;padding:10px 12px;border-radius:16px;background:#12081fd0;border:2px solid #6a4ab0;color:#fff8e8}
.gttbets h5{margin:0;font:400 24px/1 'Pirata One',Georgia,serif;color:#ffd45a}
.gttb{position:relative;display:grid;grid-template-columns:1fr auto;gap:2px 8px;padding:6px 8px;border-radius:12px;background:#ffffff10;border:2px solid #ffd45a77}
.gttb .gttbk{grid-column:1/-1;font:800 10.5px var(--ui);letter-spacing:.14em;text-transform:uppercase;color:#ffd45a}
.gttb b{grid-column:1/-1;font:700 13.5px/1.2 var(--ui);white-space:pre-line}
.gttb small{grid-column:1;display:flex;flex-direction:column;font:500 12px var(--ui);color:#b8acdc}.gttb small .now{font-style:normal;color:#fff8e8;font-weight:700}
.gttco{all:unset;box-sizing:border-box;cursor:pointer;grid-column:2;grid-row:3;display:flex;flex-direction:column;align-items:center;justify-content:center;min-width:112px;height:44px;padding:0 10px;border-radius:12px;background:linear-gradient(180deg,#8affa8,#22a85a);border:2px solid #12081f;box-shadow:0 3px 0 #0e5a2a;color:#06301a;transition:transform .12s}
.gttco{gap:2px}.gttco span{font:800 10.5px/1.2 var(--ui);letter-spacing:.12em;text-transform:uppercase}.gttco u{text-decoration:none;font:800 17px/1.2 var(--ui)}
.gttco:hover:not(:disabled){transform:translateY(-2px)}.gttco:disabled{cursor:default;background:#3a3070;color:#a99be0;box-shadow:0 3px 0 #0a0620}.gttco[hidden]{display:none}
.gttb.done{border-color:#7dff9a88}.gttdone{grid-column:1/-1;font-style:normal;font:800 14px var(--ui);color:#7dff9a}
.gttcoh{margin:0;text-align:center;font:500 11.5px var(--ui);color:#a99be0}
.gttsay{position:absolute;left:50%;bottom:14px;width:860px;margin-left:-430px;display:flex;flex-direction:column;gap:4px;align-items:center;pointer-events:none}
.gttsay p{margin:0;padding:6px 20px;border-radius:14px;background:#12081fd8;border:2px solid #6a4ab0;font:700 19px var(--ui);color:#fff8e8;animation:gttin .3s cubic-bezier(.34,1.56,.64,1) both}
.gttsay p:first-child:not(:last-child){opacity:.6;font-size:15px}.gttsay p.mine{border-color:#ffd45a;color:#ffe9a8}
@keyframes gttin{0%{opacity:0;transform:translateY(10px) scale(.95)}100%{opacity:1;transform:none}}
.gttskip{all:unset;box-sizing:border-box;cursor:pointer;position:absolute;left:14px;bottom:14px;height:34px;padding:0 14px;border-radius:12px;font:700 13px var(--ui);color:#ffe9b0;background:#12081fd0;border:2px solid #6a4ab0}.gttskip:hover{border-color:#ffd45a}.gttskip:focus-visible{outline:3px solid #fff}
.gttban{position:absolute;left:0;right:0;top:34%;text-align:center;font:400 84px/1 'Pirata One',Georgia,serif;color:#ffd45a;-webkit-text-stroke:3px #12081f;paint-order:stroke fill;pointer-events:none;opacity:0}
.gttban.on{animation:gttban 1.9s ease both}
@keyframes gttban{0%{opacity:0;transform:scale(.5)}15%{opacity:1;transform:scale(1.08)}25%{transform:scale(1)}75%{opacity:1}100%{opacity:0;transform:scale(1.04)}}
.gttph .gttps,.gttph .gttbets,.gttph .gttclk,.gttph .gttskip{opacity:0;transition:opacity .2s}
/* results */
.gttrcl{display:flex;flex-direction:column;gap:8px;min-height:0}
.gttrh{display:flex;align-items:center;gap:10px;height:58px;padding:0 14px 0 18px;border-radius:18px;background:linear-gradient(180deg,#2a1d66,#150e3a);border:2px solid #c99a3a;box-shadow:0 0 0 2px #12081f}
.gttrh h3{margin:0 auto 0 0;font:400 36px/1 'Pirata One',Georgia,serif;color:#ffd45a;-webkit-text-stroke:1px #12081f;white-space:nowrap}
.gttpod{position:relative;width:884px;height:497px;border-radius:20px;overflow:hidden;border:3px solid #c99a3a;box-shadow:0 0 0 3px #12081f;background:#1a1040}
.gttpod canvas{position:absolute;left:0;top:0;width:100%;height:100%}
.gttorder{display:grid;grid-template-columns:repeat(2,1fr);gap:4px 12px}
.gttor{display:flex;align-items:center;gap:8px;height:34px;padding:0 12px 0 6px;border-radius:12px;background:#ffffff0d;border:2px solid #3a3070;font:500 14px var(--ui);color:#e8e0ff}.gttor.w{border-color:#ffd45a}
.gttor i{display:grid;place-items:center;width:24px;height:24px;border-radius:50%;border:2px solid #12081f;font:800 13px var(--ui);font-style:normal}
.gttor span{flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.gttor b{color:#ffd45a;margin-right:4px}.gttor u{text-decoration:none;font:700 13px var(--ui);color:#b8acdc;font-variant-numeric:tabular-nums}
.gttrcr{display:flex;flex-direction:column;gap:8px;padding:12px 14px 0;border-radius:22px;background:linear-gradient(180deg,#1e1650,#0e0a2c);border:2px solid #6a4ab0;box-shadow:0 0 0 2px #12081f;min-height:0}
.gttnote{margin:0;padding:6px 12px;border-radius:12px;background:#12081f;border:2px solid #ffd45a;font:600 13px/1.3 var(--ui);color:#ffe9a8;text-align:center}
.gttrb{display:flex;flex-direction:column;gap:6px}
.gttrl{display:grid;grid-template-columns:36px 1fr auto;align-items:center;gap:10px;min-height:56px;padding:4px 12px 4px 8px;border-radius:14px;background:#ffffff0d;border:2px solid #3a3070}
.gttrl>i{display:grid;place-items:center;width:30px;height:30px;border-radius:50%;border:2px solid #12081f;font:900 16px var(--ui);font-style:normal}
.gttrl.won{border-color:#3ad86a;background:linear-gradient(90deg,#1e5a3a,#163a2a)}.gttrl.won>i{background:#7dff9a;color:#06301a}
.gttrl.lost>i{background:#ff6a7a;color:#3a0610}.gttrl.cash{border-color:#9fe8ff}.gttrl.cash>i{background:#9fe8ff;color:#06122a}
.gttrl span{display:flex;flex-direction:column;min-width:0}.gttrl b{font:700 14px/1.2 var(--ui);color:#fff8e8;white-space:pre-line}.gttrl small{font:500 12px var(--ui);color:#b8acdc}
.gttrl u{text-decoration:none;font:800 15px var(--ui);color:#fff8e8;white-space:nowrap}.gttrl.won u{color:#9affb8}.gttrl.lost u{color:#ff9aa6}
.gttrt{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}
.gttrt>div{padding:6px 10px;border-radius:12px;background:#12081f;border:2px solid #3a3070;text-align:center}.gttrt small{display:block;font:700 11px var(--ui);letter-spacing:.12em;text-transform:uppercase;color:#a99be0}.gttrt b{font:800 22px var(--ui);color:#fff8e8}
.gttrt .up b{color:#7dff9a}.gttrt .dn b{color:#ff9aa6}
.gttcapn{margin:0;text-align:center;font:800 13px var(--ui);color:#ffb04a}
.gttac{display:flex;align-items:center;justify-content:center;gap:8px;margin:0;padding:6px 12px;border-radius:12px;background:#3a2208;border:2px solid #e8851a;font:800 14px var(--ui);color:#ffc04a}.gttac i{width:16px;height:20px;border-radius:50% 50% 45% 45%;background:#a8602a;border:2px solid #12081f}
.gttrec{margin-top:auto;padding:8px 12px;border-radius:14px;background:#12081f;border:2px solid #3a3070}.gttrec h5{margin:0 0 4px;font:700 11px var(--ui);letter-spacing:.12em;text-transform:uppercase;color:#a99be0;text-align:center}.gttrec>div{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;text-align:center}.gttrec span{font:600 12px var(--ui);color:#b8acdc}.gttrec b{display:block;font:800 20px var(--ui);color:#fff8e8}
.gttrbtn{display:flex;flex-direction:column;gap:8px;padding-bottom:42px}.gttrbtn>div{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.gttagain{height:62px;width:100%;font-size:28px;padding:0;display:flex;align-items:center;justify-content:center;gap:12px}.gttagain kbd{font-size:12px}
.gttrcr .cmsg{margin:0;min-height:36px;font:600 14px/1.25 var(--ui)!important;text-align:left;padding:6px 12px!important;border-radius:12px!important}
.gttbtn{justify-content:center}
/* the casino tile badge */
.gdt[data-g="gtt"]{position:relative}.gdt[data-g="gtt"]::after{content:'NEW';position:absolute;left:10px;top:10px;z-index:3;padding:3px 9px 2px;border-radius:9px;background:linear-gradient(180deg,#ff5a6e,#c8203a);border:2px solid #ffd45a;box-shadow:0 0 0 2px #12081f,0 4px 10px #0008;font:900 12px/1.1 Poppins,system-ui,sans-serif;letter-spacing:.12em;color:#fff8e0;pointer-events:none;animation:gttnewb 1.6s ease-in-out infinite}
@keyframes gttnewb{0%,100%{transform:scale(1) rotate(-6deg)}50%{transform:scale(1.1) rotate(-6deg)}}
@media (prefers-reduced-motion:reduce){.gttrow.hop,.gttrace.shk>canvas,.gttsay p,.gttmod{animation:none}.gttodds.wait,.gttpr,.gdt[data-g="gtt"]::after{animation:none}.gttban.on{animation-duration:.01s;opacity:1}}
`;document.head.appendChild(st)}
