/* ---------- Monster Mash: limited-time Halloween Endless variant ----------
   Every level the graveyard wakes a new curse that changes how words look or how they are typed. It runs on the normal Endless
   engine (levels, rounds, bosses, boons, boon swaps) so every boon, weapon and armor works as usual, and it pays out better. */
const HW_END=new Date(2026,10,8).getTime();/* event closes Nov 8 2026, local time (edit here to change the window) */
const hwOn=()=>Date.now()<HW_END;
function hwLeft(){const ms=HW_END-Date.now();if(ms<=0)return'Returned to the grave';const d=Math.floor(ms/864e5),h=Math.floor(ms%864e5/36e5);return d>=2?d+' days left':d===1?'1 day left':h>=1?h+' hours left':'Ending soon'}
const GYK=1.35,GYXP=1.3;/* gold and XP payout multipliers over normal Endless */
const GYW=('grave tomb crypt bone skull ghoul ghost spook haunt wraith shade spirit spectre phantom banshee coffin casket burial mourn funeral undead zombie shamble lurch rot rotting decay decayed dread doom gloom gloomy eerie creepy ' +
 'bats batwing cobweb spider web hex hexed curse cursed witch wizard cauldron brew potion toad newt broom moon moonlit midnight witching shadow shadows fog mist murk mire marsh swamp ' +
 'pumpkin gourd harvest scarecrow straw crow raven owl candle lantern wick flame ember ash ashes soot dust cinder dirt soil shovel spade digger mound mausoleum vault tombstone epitaph headstone ' +
 'fang fangs vampire bloodline coven ritual rune charm omen dusk dusk nightfall nightmare scream shriek howl wail moan groan rattle creak creaking chain chains iron gate rust rusty ' +
 'lurking looming gnarled twisted withered hollow howling restless sinister macabre morbid ghastly ghostly ghoulish spooky haunted bewitched cobwebbed skeleton skeletal graveyard cemetery boneyard necropolis ' +
 'sepulchre sarcophagus apparition poltergeist phantasm revenant lich specter reaper scythe hourglass torch pitchfork mask costume trick treat candy lollipop caramel').split(/\s+/).filter((w,i,a)=>w.length>=3&&a.indexOf(w)===i);
/* ---------- Graveyard crate: roll, odds and pity ---------- */
const HW_ODDS=[.40,.29,.20,.0825,.02,.0075],HW_PITY=15;/* Common..Mythic: 40 / 29 / 20 / 8.25 / 2 / 0.75 percent. Epic or better is guaranteed by the 15th crate. */
function hwRoll(){let tier=0,r=Math.random();const forced=(P.hpity||0)+1>=HW_PITY;
 if(forced){const w=HW_ODDS.slice(3),s=w.reduce((a,b)=>a+b,0);r=Math.random()*s;tier=3;for(let i=0;i<w.length;i++){r-=w[i];if(r<=0){tier=3+i;break}}}
 else{for(let i=0;i<HW_ODDS.length;i++){r-=HW_ODDS[i];if(r<=0){tier=i;break}tier=i}}
 const pool=[{kind:'a',id:HWG_ID.a[tier],own:!!P.ownA[HWG_ID.a[tier]]}];const wid=HWG_ID.w[tier];if(WP[wid]&&pathOpen(WP[wid].p))pool.push({kind:'w',id:wid,own:!!P.own[wid]});
 const wt=x=>x.own?1:3;let q=Math.random()*pool.reduce((a,x)=>a+wt(x),0),pick=pool[0];for(const x of pool){q-=wt(x);if(q<=0){pick=x;break}}
 return{kind:pick.kind,id:pick.id}}
function hwPityStep(it){P.hpity=RKM[it.r]>=3?0:(P.hpity||0)+1}
/* ---------- the three curses ---------- */
const GYC={
 ghost:{n:'Ghost Letters',d:'Letters flicker out of sight. Remember the word before it fades.',c:'#9fe8ff',ic:'👻'},
 hex:{n:'Hexed Letter',d:'One cursed letter in every word must be typed twice.',c:'#d08aff',ic:'✦'},
 ink:{n:'Vanishing Ink',d:'One letter in every word is missing. The ink writes itself back in once the monster passes the halfway mark.',c:'#7affc8',ic:'✒'}};
const GY_SEQ=['ghost','hex','ink'];
const gyHash=n=>{let x=(n*2654435761)>>>0;x^=x>>>15;x=Math.imul(x,2246822519)>>>0;x^=x>>>13;return x>>>0};
/* the curses simply rotate: level 1 ghost, 2 hex, 3 ink, 4 ghost again, and so on. One curse per level. */
function gyCurseFor(lv){return[GY_SEQ[(Math.max(1,lv)-1)%GY_SEQ.length]]}
const gyHas=k=>!!(S.gy&&S.gyc&&S.gyc.includes(k));
const gyDark=()=>S.gy&&gyHas('dark')&&S.mode==='play';
/* give a fresh word its curse (rev / hex / ink change what is displayed or typed) */
function gyCurseWord(e){e.cd=1;if(e.boss||e.mn&&e.w.length<3)return;const w=e.w;if(!w||w.length<3||w.includes(' '))return;e.dw=null;e.rv=0;e.hx=null;e.dh=null;e.dr=null;
 if(gyHas('rev')){e.dw=w;e.w=[...w].reverse().join('');e.rv=1}
 else if(gyHas('hex')){const hi=Math.floor(Math.random()*w.length);e.w=w.slice(0,hi+1)+w[hi]+w.slice(hi+1);e.hx=hi}
 else if(gyHas('ink')&&w.length>=4){e.dh=1+Math.floor(Math.random()*(w.length-2))}}
function gyRank(e){let r=0;for(const q of S.en)if(q!==e&&!q.boss&&q.x<e.x)r++;return r}
/* per-letter drawing for word pills. Returns the string index that is currently the "next" letter so the pill can underline it. */
function gyPillChar(e,i,ch,cx,cy,col,tgt){const L=e.w.length,rv=e.rv,ti=rv?L-1-i:i,typed=ti<e.i,next=tgt&&ti===e.i;let a=1,fill=typed?col:'#fff',glow=null,show=ch;
 if(e.hx!=null&&(ti===e.hx||ti===e.hx+1)){fill=typed?col:'#e2a8ff';glow='#c86bff'}
 if(e.dh!=null&&ti===e.dh&&!typed){
  /* vanishing ink: the gap stays blank until the monster crosses the halfway point of its walk, then the letter is written back in */
  if(e.dr==null&&e.x<=(W+KX)/2){e.dr=S.t;if(axOn()&&S.t-(S.dhSnd||-9)>.35){S.dhSnd=S.t;try{cBell(sg,ac.currentTime,nf(84),.025,.6);cNoise(sg,ac.currentTime,.12,.012)}catch(x){}}}
  if(e.dr==null){show='_';fill='#7affc8';glow='#7affc8'}
  else{const u=Math.min(1,(S.t-e.dr)/1.1);if(u<1){gyInk(e,ch,cx,cy,u);return ti}fill='#d6fff0';glow='#7affc8'}}
 if(gyHas('ghost')&&!typed){const ph=Math.sin(S.t*2.3+i*1.9+(e.ph||0));a=.1+.9*(.5+.5*ph);if(next)a=Math.max(a,.5)}
 const ga=ctx.globalAlpha;ctx.globalAlpha=ga*a;if(glow){ctx.shadowColor=glow;ctx.shadowBlur=10}ctx.fillStyle=fill;ctx.fillText(show,cx,cy);ctx.shadowBlur=0;ctx.globalAlpha=ga;
 return ti}
/* the ink writing itself in: a green blot spreads, the letter is revealed left to right behind a bright pen tip, and droplets run down */
function gyInk(e,ch,cx,cy,u){const c=ctx,fs=parseFloat(c.font)||26,w=c.measureText(ch).width||fs*.6,e1=1-Math.pow(1-u,3),ga=c.globalAlpha;
 c.save();c.textAlign='center';c.textBaseline=c.textBaseline||'middle';
 /* the blank fades out */
 c.globalAlpha=ga*(1-e1);c.fillStyle='#7affc8';c.fillText('_',cx,cy);
 /* blot */
 c.globalCompositeOperation='lighter';c.globalAlpha=ga*Math.sin(u*Math.PI)*.85;glow(c,cx,cy-fs*.1,fs*(.4+e1*.7),'#7affc855');
 /* the letter, wiped in from the left */
 c.globalCompositeOperation='source-over';c.globalAlpha=ga;c.save();c.beginPath();c.rect(cx-w/2-3,cy-fs,(w+6)*e1,fs*2);c.clip();
 const k=1+(1-e1)*.45;c.translate(cx,cy);c.scale(k,k);c.shadowColor='#7affc8';c.shadowBlur=14*(1-u)+4;c.fillStyle=u<.7?'#a8ffe0':'#d6fff0';c.fillText(ch,0,0);c.restore();
 /* pen tip */
 if(u<.95){const tx=cx-w/2+(w)*e1;c.globalCompositeOperation='lighter';c.globalAlpha=ga;glow(c,tx,cy,fs*.3,'#bfffe055');c.fillStyle='#fff';c.beginPath();c.arc(tx,cy+fs*.32,1.8,0,TAU);c.fill()}
 /* droplets running down from the blot */
 c.globalCompositeOperation='source-over';for(let i=0;i<4;i++){const ph=((u*1.2)-i*.12);if(ph<=0||ph>=1)continue;const dx=cx+(i-1.5)*w*.34,dy=cy+fs*.3+ph*fs*.9;c.globalAlpha=ga*(1-ph)*.9;c.fillStyle='#7affc8';c.beginPath();c.ellipse(dx,dy,1.7,2.6+ph*2,0,0,TAU);c.fill()}
 c.restore()}
/* ---------- HUD chip + darkness vignette ---------- */
function gyHud(c){if(!S.gy||!S.gyc||S.mode==='title')return;const L=lvOf(S.wave);let y=ST&&ST.fps?186:162;c.save();c.textAlign='right';
 for(const k of S.gyc){const q=GYC[k];c.fillStyle='rgba(6,4,16,.62)';c.beginPath();c.roundRect(W-280,y,266,30,10);c.fill();c.strokeStyle=q.c+'aa';c.lineWidth=1.5;c.stroke();c.fillStyle=q.c;c.font='19px "Pirata One",Georgia,serif';c.fillText(q.n,W-28,y+21);c.textAlign='left';c.fillText(q.ic,W-268,y+21);c.textAlign='right';y+=36}
 c.restore()}
function gyVignette(c){if(!gyDark())return;const g=c.createRadialGradient(KX+300,GY-160,160,KX+300,GY-160,900);g.addColorStop(0,'rgba(4,0,12,0)');g.addColorStop(1,'rgba(4,0,12,.62)');c.fillStyle=g;c.fillRect(-30,-30,W+60,H+60)}
/* ---------- run flow ---------- */
const gyLevelLabel=w=>GYLV[(lvOf(w)-1)%3].n;
{const sw=startWave;startWave=function(){const r=sw.apply(this,arguments);
  if(S.gy){const lv=lvOf(S.wave);if(S.round===1||!S.gyc||!S.gyc.length||S.gyLv!==lv){S.gyc=gyCurseFor(lv);S.gyLv=lv}
   if(S.round===1){const k=S.gyc[0],q=GYC[k];S.ban={t:4,txt:'Level '+lv+': '+gyLevelLabel(S.wave),c:q.c,sub:S.gyc.map(x=>GYC[x].n).join(' + ')+': '+GYC[k].d};try{jingle('boss')}catch(e){}}}
  return r}}
{const sb=shieldBreak;shieldBreak=function(t){sb(t);t.cd=0;t.dw=null;t.rv=0;t.hx=null;t.dh=null;t.dr=null}}
{const mt=modeTick;modeTick=function(dt){if(!S.gy)return mt(dt);
  /* a run resumed from before the rotation may still hold a retired curse or a reversed word, so clean those up */
  if(S.gyc&&S.gyc.some(k=>!GYC[k])){S.gyc=S.gyc.filter(k=>GYC[k]);if(!S.gyc.length){S.gyLv=lvOf(S.wave);S.gyc=gyCurseFor(S.gyLv)}}for(const e of S.en)if(e.rv){e.w=e.dw||e.w;e.dw=null;e.rv=0;e.i=0}
  for(const e of S.en)if(!e.cd&&e.w)gyCurseWord(e)}}
function gyDrop(e){if(S.cdebt>0&&e.boss){S.cdebt--;return}const q=e.boss?1:e.el?.1:.02;if(Math.random()<q)S.cr.push({x:e.x+(e.boss?30:0),y:e.y-e.h*.6,vy:-300,k:'h'})}
/* ---------- run summary (separate records so Endless bests are never touched) ---------- */
function gyOver(quit){if(S.mode==='over')return;S.mode='over';const xp=xpMode(Math.round((S.score/16+S.wave*8)*xpMulRun()*GYXP*ENDXP)),xn=xpNoteH(),G=P.gyb||(P.gyb={best:0,lv:0,runs:0,h:0}),nb=S.score>(G.best||0),l0=finishRun(),wxm=wxpEnd(),lv=lvOf(S.wave);
 P.xp+=xp;if(nb)G.best=S.score;G.lv=Math.max(G.lv||0,lv);G.runs=(G.runs||0)+1;G.h=(G.h||0)+(S.gyH||0);const l1=lvl(P.xp),cr=S.runC||0,lg=levelGold(l0,l1);save();jingle('lose');
 const later=()=>{const hc=S.gyH||0;show(`<div class="gyov"><h2>The Mash is over</h2>${resBlock()}<p>${nb?'<b style="color:var(--gold)">New Graveyard record!</b> ':''}Survived to level ${lv}, round ${S.round} of 5. Best: level ${G.lv}.${S.by&&!quit?` Slain by ${esc(S.by)}.`:''}<br>Earned ${xp} XP, ${S.gold+lg} gold and ${cr} crate${cr===1?'':'s'}${hc?`, <b class="hwtxt">${hc} of them Graveyard</b>`:''}.${xn}${wxm}${l1>l0?`<br><b style="color:var(--gold)">Level up! You are now level ${l1}, ${rankOf(l1)}. Bonus: ${lg} gold.</b>`:''}${pathMsg(l0,l1)}</p><div class="row"><button id="go">${hwOn()?'Rise again':'Back to Home'}</button>${P.hcr>0?`<button class="sm" id="hc">Open ${P.hcr} Graveyard crate${P.hcr===1?'':'s'}</button>`:''}<button class="sm" id="hm">Home</button></div></div>`);
  $('go').onclick=()=>hwOn()?start(0,'gy'):title();$('hm').onclick=title;if($('hc'))$('hc').onclick=()=>crateHub()};
 if(quit)later();else{S.pose='dead';S.poseT=0;S.landed=0;S.late=later;S.lateAt=2.2}}
/* Graveyard words: ask for the spooky list and retry a few times so the generic list only fills in when a length is unavailable */
{const pw=pickWord,GS=new Set(GYW);pickWord=function(role,zi,d,on){if(!S.gy||Array.isArray(zi))return pw(role,zi,d,on);let w;for(let i=0;i<8;i++){w=pw(role,GYW,d,on);if(GS.has(w))return w}return w}}
/* ---------- Monster Mash speed ----------
   Endless counts every moment a monster is on screen. Mash has curse banners, hidden letters, boss walk-ins and gaps between spawns, so that
   clock ran while the player was waiting or reading and the WPM read far too low. Here the clock is the time the player was actually typing:
   the gap before each keystroke, counted only while a word was on screen and capped at 1.5 s, so a long wait or a pause never counts. */
{const k0=ksLog;ksLog=function(exp,c){if((S.gy||S.camp>30/*ASTRAL*/)&&exp&&exp!==' '&&S.lk){const now=performance.now(),from=Math.max(S.lk,S.gyE||0);S.tt+=Math.min(1500,Math.max(0,now-from))/1000}return k0.apply(this,arguments)}}
{const w0=wpmStep;wpmStep=function(dt){if(!S.gy&&!(S.camp>30/*ASTRAL*/))return w0(dt);if(!S.pt0)return;const now=performance.now();S.wl=now;if(!S.en.some(e=>e.w&&e.x<W-10&&!(e.vul>0)))S.gyE=now;S.wpm=S.tt>=4&&S.ok>=8?Math.round(S.ok/5/(S.tt/60)):0}}
