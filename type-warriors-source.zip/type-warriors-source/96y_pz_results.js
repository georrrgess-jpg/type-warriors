/* ===== 9.5 THE CROOKED CUE: the results, redone (96y) =====
   The monster on a lamp-lit stage saying their line, how the match ended, a rack-by-rack strip, the money as a sum
   you can read (stake x pays + bonus = paid out, profit), the numbers, unlock cards that flip in one by one, your
   next goal, and buttons with their keys (Enter, R, Esc). Coins fly into a gold counter that counts up. */
const PZ_WHY={'8 ball':[w=>w?'You sank the 8 in the called pocket.':'{n} sank the 8.'],golden:[w=>w?'A golden break: the 8 dropped on the break!':'{n} sank the 8 on the break. Golden.'],
 '8 too early':[w=>w?'{n} sank the 8 before clearing their group.':'You sank the 8 before your group was clear.'],'8 in the wrong pocket':[w=>w?'{n} put the 8 in the wrong pocket.':'The 8 went into a pocket you had not called.'],
 '8 with a foul':[w=>w?'{n} fouled on the 8.':'You fouled while sinking the 8 (the cue ball dropped or hit the wrong ball first).'],forfeit:[()=>'You left the table.']};
function pzWhyTxt(why,win,R){const f=PZ_WHY[why];return f?f[0](win).replace('{n}',R.n):''}
function pzResults(res){PZ.on=false;PZ.resAt=performance.now();const R=PZ_REG[res.opp],win=res.win,Z=PZS(),tk=++PZ.tok;
 const racks=res.racks||(PZ.M&&PZ.M.opp===res.opp&&PZ.M.racks)||[],last=racks[racks.length-1];
 const why=res.forfeit?pzWhyTxt('forfeit',win,R):last?pzWhyTxt(last.why,last.w===0,R):'';
 const line=res.practice?(R.lines.hi[1]||R.lines.hi[0]):win?(R.lines.lose||['...'])[0]:(R.lines.win||['Ha!'])[0];
 const unl=[],fb=PZ.fbPending||0;if(fb)unl.push(`<div class="pzun open fb"><small>FIRST WIN BONUS</small><b>+${cmn(fb)} gold</b></div>`);
 if(res.opened)unl.push(`<div class="pzun open"><small>NEW TABLE</small><b>${PZ_REG[res.opened].n}</b></div>`);
 for(const u of res.unlocks)unl.push(`<div class="pzun"><small>NEW ${u.t==='cue'?'CUE':u.t==='felt'?'FELT':'BALL SET'}</small><b>${u.n}</b></div>`);
 const cue=res.opp==='shade'?PZ_CUES.find(c=>c.beatShade):PZ_CUES.find(c=>c.beat===res.opp),cn=res.opp==='shade'?(Z.shade.beat||0):(Z.beat[res.opp]||0);
 if(cue&&!res.practice&&!Z.cues[cue.id])unl.push(`<div class="pzun prog"><small>${cue.n}</small><b>${Math.min(cn,3)} / 3 wins</b><em><i style="transform:scaleX(${Math.min(cn,3)/3})"></i></em></div>`);
 /* the next goal */
 let goal='';if(!res.practice){if(res.opened)goal=`Next: a new regular, ${PZ_REG[res.opened].n}, is waiting at the bar.`;else if(cue&&!Z.cues[cue.id])goal=`Next: beat ${R.n} ${3-Math.min(cn,3)} more time${3-Math.min(cn,3)>1?'s':''} for the ${cue.n}.`;else{const nx=PZ_ORDER.find(k=>pzOpen(k)&&!(Z.beat[k]>0));if(nx)goal=`Next: ${PZ_REG[nx].n} has not lost to you yet.`;else if(!(Z.beat.mortimer>0))goal='Next: climb to Mortimer Bonechalk.'}}
 else goal='Practice done. Ready to play for real?';
 const fm=x=>x.toFixed(2).replace(/0$/,'').replace(/\.0$/,''),base=Math.round(res.stake*res.mult);
 const money=res.practice?`<div class="pzmon0">Practice table · no stake, no prize</div>`:win?`<div class="pzmon"><div><small>STAKE</small><b>${cmn(res.stake)}</b></div><i>×</i><div><small>PAYS</small><b>${fm(res.mult)}</b></div>${res.bonus?`<i>+</i><div><small>BONUS</small><b>${cmn(res.bonus)}</b></div>`:''}<i>=</i><div class="pay"><small>PAID OUT</small><b id="pzpayn">0</b></div><div class="pro"><small>PROFIT</small><b>+${cmn(res.pay-res.stake)}</b></div></div>`
  :`<div class="pzmon neg"><div class="pay"><small>STAKE LOST</small><b>−${cmn(res.stake)}</b></div><p>${R.n} keeps your stake. ${Z.dayN<PZ_DAILY?'A rematch costs the same stake.':''}</p></div>`;
 const strip=racks.length?`<div class="pzstrip">${racks.map((r,i)=>`<span class="${r.w===0?'w':'l'}">Rack ${i+1} · ${r.w===0?'You':R.n.split(' ').pop()}${r.golden?' · golden':r.bnr?' · break & run':''}</span>`).join('')}</div>`:'';
 const title=res.forfeit?'You forfeited':win?'You win!':'You lose';
 show(`<div class="pzr pzres9" id="pzr"><canvas id="pzrbg" width="1600" height="900"></canvas><div class="pzgold" id="pzrg"><i></i><b id="pzrgv">${cmn(P.gold-(win&&!res.practice?res.pay:0)-fb)}</b></div><div class="pzrgd" id="pzrgd"></div>
  <div class="pzresc ${win?'win':'lose'}"><div class="pzrstage"><canvas class="pzstbg" width="300" height="424"></canvas><canvas id="pzrpm" width="400" height="500"></canvas><div class="pzbub pop">“${line}”</div></div>
  <div class="pzrpn"><div class="pzh1">${[...title].map((c,i)=>`<i style="--i:${i}">${c===' '?'&nbsp;':c}</i>`).join('')}</div>
   <p class="pzrsub">${res.practice?'Practice table':`Race to ${res.race}`} · ${res.score[0]} - ${res.score[1]} · ${R.n} · ${Math.floor(res.time/60)}:${String(res.time%60).padStart(2,'0')}</p>${why?`<p class="pzwhy">${why}</p>`:''}${strip}
   ${money}
   <div class="pzstat"><div><b>${res.pots}</b><small>BALLS POTTED</small></div><div><b>${res.banks}</b><small>BANK SHOTS</small></div><div><b>${res.bnr}</b><small>BREAK &amp; RUNS</small></div><div><b>${res.golden||0}</b><small>GOLDEN BREAKS</small></div></div>
   <div class="pzuns">${unl.join('')}</div>${goal?`<p class="pzgoal">${goal}</p>`:''}
   <div class="pzrbt">${res.opened?`<button class="pzmb gold" id="pzch">Meet ${pzShort(res.opened)} <kbd>Enter</kbd></button><button class="pzmb" id="pzre">Rematch <kbd>R</kbd></button>`:`<button class="pzmb gold" id="pzre">${res.practice?'Again':'Rematch'} <kbd>Enter</kbd></button>`}<button class="pzmb" id="pzbb">The bar <kbd>Esc</kbd></button></div></div></div></div>`,'casbg pzx');
 $('pzrbg').getContext('2d').drawImage(pzHubBake(),0,0);S.back=()=>{$('pzbb').click()};
 ov.querySelector('.pzrstage .pzstbg').getContext('2d').drawImage(pzStageBake(win?'#6a6a8a':R.c),0,0);
 const cv=$('pzrpm'),g=cv.getContext('2d');g.lineJoin='round';g.lineCap='round';const ex=Object.assign(pzCastEx(),PZ_EXP[res.practice?'happy':win?'sad':'cheer']),rf=pzMonFit(R.id,340,440,10,1.1);
 const f=()=>{if(!cv.isConnected)return;const t=performance.now()/1000;g.clearRect(0,0,400,500);g.save();g.translate(rf.x+30,rf.y+30+(win?10:0));g.scale(rf.s,rf.s);g.translate(0,win||res.practice?0:-Math.abs(Math.sin(t*5))*16/rf.s);pzMon[R.id](g,t,ex,{breath:Math.sin(t*2.2)*.012,tilt:win?.06:Math.sin(t*3)*.03,bob:0,hop:0});g.restore()};f();LIVE.push({cv,fn:f,slow:1,ph:0});
 $('pzbb').onclick=()=>{if(res.opened)PZ.sel=res.opened;pzGo(pzHub)};{const ch=$('pzch');if(ch)ch.onclick=()=>{PZ.sel=res.opened;pzGo(pzHub)}}
 $('pzre').onclick=()=>{const k=res.opp;let stake=res.stake,prac=res.practice;if(!prac){const aff=(k==='shade'?[500,1000,2000,3000,5000]:PZ_REG[k].stakes).filter(s=>s<=casCap('pz')&&s<=P.gold);if(stake>P.gold||!stake){stake=aff.length?aff[aff.length-1]:0}if(!stake){prac=true;pzNote('Not enough gold for stakes: a free practice game.')}}pzMusicOff();pzStart({opp:k,stake,practice:prac})};
 /* the paid-out number counts up, coins fly to the gold counter and it counts up too */
 if(!res.practice&&win&&res.pay){const tgt=res.pay,all=tgt+fb,t0=performance.now(),el=$('pzpayn'),gv=$('pzrgv'),g0=P.gold-all,stp=()=>{if(!el.isConnected)return;const u=Math.min(1,(performance.now()-t0)/1300),e=1-Math.pow(1-u,3);el.textContent=cmn(Math.round(tgt*e));
   const u2=Math.max(0,Math.min(1,(performance.now()-t0-700)/900)),e2=1-Math.pow(1-u2,3);gv.textContent=cmn(Math.round(g0+all*e2));if(u<1||u2<1)requestAnimationFrame(stp)};requestAnimationFrame(stp);pzResCoins2();const d=$('pzrgd');d.textContent=`+${cmn(all)}`;d.classList.add('on')}
 if(win&&!res.practice&&!pzRM())pzConfetti();
 pzFx(win?'win':'lose');pzFitTM();
 if(!window.__pzResKeys){window.__pzResKeys=1;addEventListener('keydown',e=>{try{if(e.repeat||!$('pzr')||!ov.querySelector('.pzres9')||PZ.modal||pzCoachActive())return;if(performance.now()-(PZ.resAt||0)<700)return;const k=e.key.toLowerCase();if(k==='r'){const b=$('pzre');if(b){e.preventDefault();b.click()}}}catch(err){}})}}
function pzResCoins2(){const host=ov.querySelector('.pzres9'),from=$('pzpayn'),to=$('pzrg');if(!host||!from||!to||pzRM())return;const hb=host.getBoundingClientRect(),s=hb.width/1600||1,a=from.getBoundingClientRect(),b=to.getBoundingClientRect();
 const ax=(a.left+a.width/2-hb.left)/s,ay=(a.top+a.height/2-hb.top)/s,bx=(b.left+24-hb.left)/s,by=(b.top+b.height/2-hb.top)/s;
 for(let i=0;i<18;i++){const c=document.createElement('i');c.className='pzcoin2';c.style.left=ax+'px';c.style.top=ay+'px';c.style.setProperty('--x',(bx-ax)+'px');c.style.setProperty('--y',(by-ay)+'px');c.style.setProperty('--m',(-60-Math.random()*120)+'px');c.style.setProperty('--d',(.35+i*.045)+'s');host.appendChild(c);setTimeout(()=>c.remove(),2200)}}
function pzConfetti(){const host=ov.querySelector('.pzres9');if(!host)return;const cols=['#ffd45a','#8affb4','#7ad8ff','#ff9ad0','#c8a0ff'];for(let i=0;i<46;i++){const c=document.createElement('i');c.className='pzconf';c.style.left=(240+Math.random()*1120)+'px';c.style.background=cols[i%5];c.style.setProperty('--r',(Math.random()*720-360)+'deg');c.style.setProperty('--x',(Math.random()*160-80)+'px');c.style.setProperty('--d',(Math.random()*.6)+'s');c.style.setProperty('--t',(1.6+Math.random()*1)+'s');host.appendChild(c);setTimeout(()=>c.remove(),3400)}}
{const st=document.createElement('style');st.textContent=`
.pzres9 .pzresc{position:absolute;left:150px;top:96px;width:1300px;height:740px;box-sizing:border-box;border-radius:28px;padding:0;background:linear-gradient(180deg,#221a5a,#100a30);border:3px solid #4a3e90;box-shadow:inset 0 1px 0 #ffffff1f,0 16px 40px #000c;animation:pzrise .5s cubic-bezier(.25,1.25,.45,1) both;z-index:2}
.pzres9 .pzresc.win{border-color:#ffd45a}.pzres9 .pzresc.lose{border-color:#c83a6a}
.pzrstage{position:absolute;left:22px;top:22px;width:360px;height:692px;border-radius:22px;overflow:hidden;border:3px solid #12081f}
.pzrstage .pzstbg{position:absolute;left:0;top:0;width:360px;height:692px}.pzrstage #pzrpm{position:absolute;left:-20px;top:150px;width:400px;height:500px}
.pzrstage .pzbub{position:absolute;left:18px;right:18px;top:40px;font-size:15px}
.pzres9 .pzrpn{position:absolute;left:412px;top:20px;right:28px;text-align:left}
.pzres9 .pzh1{font:400 74px/1 "Pirata One",Georgia,serif;color:#ffd45a;text-shadow:0 4px 0 #12081f}.pzres9 .lose .pzh1{color:#ff8aa8}
.pzres9 .pzh1 i{display:inline-block;font-style:normal;animation:pzlet .5s calc(.15s + var(--i)*.045s) cubic-bezier(.3,1.7,.5,1) both}
.pzrsub{margin:4px 0 0!important;font:700 14px Poppins,sans-serif!important;color:#c4badf}
.pzwhy{margin:6px 0 0!important;font:600 15px Poppins,sans-serif!important;color:#fff2c8}
.pzstrip{display:flex;flex-wrap:wrap;gap:6px;margin-top:10px}.pzstrip span{padding:4px 10px;border-radius:10px;font:800 12px Poppins,sans-serif;border:2px solid #12081f;animation:pzpopIn .35s both}.pzstrip .w{background:#ffd45a;color:#2a1a04}.pzstrip .l{background:#3a2f8a;color:#e2dafc}
.pzmon{display:flex;align-items:flex-end;gap:12px;margin-top:14px;padding:14px 18px;border-radius:18px;background:#0c0824;border:2px solid #2a2468}.pzmon>i{font:800 22px Poppins,sans-serif;font-style:normal;color:#8a80c8;padding-bottom:4px}
.pzmon small{display:block;font:800 10px Poppins,sans-serif;letter-spacing:.12em;color:#9a90c8}.pzmon b{font:400 34px/1 "Pirata One",serif;color:#efe8ff}.pzmon .pay b{font-size:58px;color:#8affb4}.pzmon .pro{margin-left:auto;text-align:right}.pzmon .pro b{font-size:34px;color:#8affb4}
.pzmon.neg{flex-direction:column;align-items:flex-start;gap:4px}.pzmon.neg .pay b{color:#ff8aa8}.pzmon.neg p{margin:0;font:600 13px Poppins,sans-serif;color:#c4badf}
.pzmon0{margin-top:14px;padding:16px 18px;border-radius:18px;background:#0c0824;border:2px solid #2a2468;font:700 16px Poppins,sans-serif;color:#c4badf}
.pzres9 .pzstat{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-top:12px}.pzres9 .pzstat div{padding:8px 4px;border-radius:14px;background:#140c36;border:2px solid #3a3070;text-align:center;animation:pzpopIn .35s .5s both}.pzres9 .pzstat b{display:block;font:400 30px/1 "Pirata One",serif}.pzres9 .pzstat small{font:800 9.5px Poppins,sans-serif;letter-spacing:.1em;color:#9a90c8}
.pzres9 .pzuns{display:flex;flex-wrap:wrap;gap:10px;margin-top:12px;min-height:10px}
.pzres9 .pzun{position:relative;min-width:150px;padding:9px 14px 10px;border-radius:14px;background:#1a1046;border:2px solid #4a3e90;animation:pzflip .45s cubic-bezier(.3,1.4,.5,1) both}
.pzres9 .pzun:nth-child(2){animation-delay:.15s}.pzres9 .pzun:nth-child(3){animation-delay:.3s}.pzres9 .pzun:nth-child(4){animation-delay:.45s}.pzres9 .pzun:nth-child(1){animation-delay:.6s}
.pzres9 .pzun small{display:block;font:800 10px Poppins,sans-serif;letter-spacing:.12em;color:#9a90c8}.pzres9 .pzun b{font:800 15px Poppins,sans-serif;color:#efe8ff}.pzres9 .pzun.open{border-color:#8affb4}.pzres9 .pzun.open b{color:#8affb4}
.pzres9 .pzun em{display:block;height:5px;margin-top:5px;border-radius:3px;background:#2a2468;overflow:hidden}.pzres9 .pzun em i{display:block;height:100%;background:#ffd45a;transform-origin:0 50%;animation:pzgrow .8s 1s cubic-bezier(.3,1.3,.5,1) both}
.pzgoal{margin:12px 0 0!important;font:700 14px Poppins,sans-serif!important;color:#ffd45a}
.pzres9 .pzrbt{position:absolute;left:0;right:0;bottom:0;display:flex;gap:12px}.pzres9 .pzrpn{bottom:24px}.pzres9 .pzrbt .pzmb{flex:1;margin:0;height:58px;font-size:18px;display:flex;align-items:center;justify-content:center;gap:10px}
.pzres9 .pzrbt kbd{display:inline-block;padding:0 6px;border-radius:7px;background:#12081f33;border:1px solid #12081f55;font:800 11px/20px Poppins,sans-serif}
.pzrgd{position:absolute;right:28px;top:78px;font:800 18px Poppins,sans-serif;color:#8affb4;opacity:0;z-index:3}.pzrgd.on{animation:pzrgd 1.6s .9s both}
.pzcoin2{position:absolute;width:22px;height:22px;margin:-11px 0 0 -11px;border-radius:50%;background:radial-gradient(circle at 35% 30%,#fff3b0,#ffd45a 50%,#c88a10);border:2px solid #12081f;z-index:8;pointer-events:none;animation:pzcoinfly .8s var(--d) cubic-bezier(.5,0,.4,1) both}
.pzconf{position:absolute;top:-20px;width:10px;height:16px;border-radius:2px;z-index:7;pointer-events:none;animation:pzconf var(--t) var(--d) cubic-bezier(.3,.6,.5,1) both}
@keyframes pzcoinfly{0%{opacity:0;transform:scale(.4)}15%{opacity:1;transform:translate(calc(var(--x)*.1),var(--m)) scale(1)}100%{opacity:1;transform:translate(var(--x),var(--y)) scale(.6)}}
@keyframes pzconf{0%{opacity:1;transform:translate(0,0) rotate(0)}100%{opacity:0;transform:translate(var(--x),980px) rotate(var(--r))}}
@keyframes pzrgd{0%{opacity:0;transform:translateY(8px)}20%{opacity:1;transform:none}80%{opacity:1}100%{opacity:0;transform:translateY(-6px)}}
@keyframes pzgrow{from{transform:scaleX(0)}}
`;document.head.appendChild(st)}
