import asyncio,os,sys
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch()
        for (W,H) in [(1600,900),(1280,720),(1000,700),(800,600)]:
            pg=await b.new_page(viewport={'width':W,'height':H},device_scale_factor=2);er=[]
            pg.on('pageerror',lambda e:er.append(str(e)[:200]))
            await pg.goto('file://'+os.path.abspath('out.html'));await pg.wait_for_timeout(2500)
            await pg.evaluate("()=>{RS_ASK=false;try{title()}catch(e){}}");await pg.wait_for_timeout(1800)
            dk=pg.locator('.dk').first
            bb=await dk.bounding_box();print(W,H,bb,er)
            await pg.screenshot(path=f'shots/dk_{W}.png',clip={'x':max(0,bb['x']-10),'y':max(0,bb['y']-30),'width':min(W,bb['width']+20),'height':bb['height']+40})
            if W==1600:
                for k in ['pl','gr','pt','pg','sh','mo']:
                    await pg.hover(f'#dk_{k}');await pg.wait_for_timeout(200)
                    await pg.screenshot(path=f'shots/dkh_{k}.png',clip={'x':bb['x'],'y':bb['y']-30,'width':bb['width'],'height':bb['height']+40})
                await pg.click('#dk_pt');await pg.wait_for_timeout(1500)
                bb2=await pg.locator('.dk').first.bounding_box()
                await pg.screenshot(path='shots/dk_pets.png',clip={'x':bb2['x']-10,'y':bb2['y']-30,'width':bb2['width']+20,'height':bb2['height']+40})
            await pg.close()
        await b.close()
asyncio.run(main())
