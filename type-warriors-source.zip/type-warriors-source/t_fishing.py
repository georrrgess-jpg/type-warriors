# Moonlit Fishing regression: menu entries (home card, F key, mode picker, Warden's Arena row), every fish draws,
# a full catch of each rarity, sell/keep, creel, upgrades, rod looks, escape and the Legendary retry, stats, leaving
# with an undecided catch, and a profile reset. Run from the source folder against out.html.
import asyncio,os,json
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append('PE '+str(e)[:300]));pg.on('console',lambda m:er.append('CE '+m.text[:200]) if m.type=='error' and 'ERR_' not in m.text else None)
        await pg.goto('file://'+os.path.abspath('out.html'));await pg.wait_for_timeout(1200);E=pg.evaluate;bad=0
        def chk(name,r,ok):
            nonlocal bad;bad+=not ok;print(name,r,'OK' if ok else 'BAD')
        await E("()=>{RS_ASK=false;P.gold=100000;delete P.fish;save();title()}");await pg.wait_for_timeout(800)
        r=await E("()=>[!!document.getElementById('dkfish'),document.querySelectorAll('.dksc .dkcard').length,FIDS.length,FIDS.filter(i=>FISHART[i]).length]")
        chk('home card, 24 fish drawn',r,r[0] and r[2]==24 and r[3]==24)
        r=await E("""()=>{const c=document.createElement('canvas');c.width=300;c.height=200;const g=c.getContext('2d');let n=0;for(const id of FIDS)for(const t of [0,.7,2.3])for(const fl of [0,1]){fishFit(g,id,150,100,280,180,{t,flex:fl,glow:fl});n++}fishFit(g,'aurora',150,100,280,180,{sil:'#000'});return n}""")
        chk('every fish draws (t, flex, silhouette)',r,r==144)
        await E("()=>modeSheet()");await pg.wait_for_timeout(700)
        r=await E("()=>{const b=document.querySelector('#dma');return [b&&b.textContent.includes('Moonlit Fishing'),!!document.getElementById('dmwa')]}")
        chk('mode picker: fishing in the rift spot, arena row',r,all(r))
        await E("()=>document.getElementById('dmwa').click()");await pg.wait_for_timeout(700)
        r=await E("()=>!!document.querySelector('.wam')");chk('arena still reachable',r,r)
        await E("()=>title()");await pg.wait_for_timeout(600);await pg.keyboard.press('f');await pg.wait_for_timeout(1200)
        r=await E("()=>[S.mode,!!document.getElementById('fsx'),FS.st,!!document.getElementById('fscast')]")
        chk('F opens the pond, ready to cast',r,r[0]=='fish' and r[1] and r[2]=='idle' and r[3])
        async def catch(rk,typo=False):
            await E("(rk)=>{const ids=FIDS.filter(i=>FISH[i].r===rk);window.__id=ids[0];window.__fr=fsRoll;fsRoll=()=>{const f=FISH[__id];return{id:__id,rk,cm:f.len[1],g:false}};window.__fw=fsWait;fsWait=()=>0.4}",rk)
            await pg.keyboard.press('Space');await pg.wait_for_function("()=>FS.st==='reel'",timeout=6000)
            n=await E("()=>FS.words.length")
            for si in range(n):
                await pg.wait_for_function("()=>FS.st==='reel'",timeout=4000)
                w=await E("()=>FS.word")
                if typo and si==0:await pg.keyboard.press('q' if w[0]!='q' else 'z')
                for ch in w:await pg.keyboard.press(ch);await pg.wait_for_timeout(15)
            await pg.wait_for_function("()=>FS.st==='show'",timeout=4000);await pg.wait_for_timeout(1300)
            if await E("()=>FS.st==='show'"):await pg.keyboard.press('Space')  # skip the rest of a long spectacle
            await pg.wait_for_function("()=>FS.st==='reveal'",timeout=8000);await E("()=>{fsRoll=__fr;fsWait=__fw}")
            return n
        stages={}
        for rk in 'curl':
            stages[rk]=await catch(rk,typo=rk=='u')
            if rk!='l':await E("()=>fsDecide(fsDefKeep(FS.pend))")
        chk('stages per rarity',stages,stages=={'c':1,'u':1,'r':2,'l':3})
        r=await E("()=>[FS.pend&&FS.pend.id,!!document.querySelector('#fspv:not([hidden]) #fssell'),fsDefKeep(FS.pend)]")
        chk('legendary waits in the catch preview, default keep',r,r[0]=='aurora' and r[1] and r[2])
        g0=await E("()=>P.gold");await E("()=>document.getElementById('fssell').click()");g1=await E("()=>P.gold")
        chk('sell pays gold',[g0,g1],g1>g0)
        r=await E("()=>{const F=fsP();return [Object.keys(F.b).length,F.s.caught,F.s.leg,F.cr.length,fsFound()]}")
        chk('bestiary and creel recorded (first catches kept)',r,r[0]==4 and r[1]==4 and r[2]==1 and r[3]==3 and r[4]==4)
        for t in 'bcrs':
            await E("(t)=>{FSU.tab=t;fsTabs()}",t);await pg.wait_for_timeout(150)
        r=await E("()=>{FSU.tab='s';fsTabs();return document.querySelectorAll('.fsstats>div').length}");chk('stats tiles',r,r==9)
        r=await E("()=>{const g=P.gold,ok=fsBuyUp('line'),ok2=fsBuyUp('lure'),ok3=fsBuyUp('hook');return [ok&&ok2&&ok3,g-P.gold,fsLv(),fsRodName()]}")
        chk('upgrades cost gold',r,r[0] and r[1]==800 and r[2]==3 and r[3]=='Ashwood Rod')
        r=await E("()=>{const F=fsP();F.cr.push(...Array.from({length:5},()=>({id:'ember',cm:30,g:0})),{id:'cinder',cm:9,g:0});save();const can=fsCanSkin('ember'),ok=fsCraft('ember');return [can,ok,F.skin,F.cr.filter(c=>c.id==='ember'||c.id==='cinder').length]}")
        chk('turn in fish for the Emberwood rod',r,r==[True,True,'ember',0])
        r=await E("()=>{const F=fsP(),n=F.cr.length,v=fsSellCreel(0);return [n-F.cr.length,v>0]}");chk('sell from the creel',r,r==[1,True])
        # escape on a common, and a legendary that gets a second word after one timeout
        await E("()=>{FSU.tab='b';fsTabs();window.__ft=fsTime;fsTime=()=>0.5;window.__fw=fsWait;fsWait=()=>0.3}")
        await pg.keyboard.press('Space');await pg.wait_for_function("()=>FS.st==='escape'",timeout=8000)
        r=await E("()=>[fsP().s.esc,fsP().streak]");chk('escape counted, streak reset',r,r==[1,0])
        await pg.wait_for_function("()=>FS.st==='idle'",timeout=4000)
        await E("()=>{window.__fr=fsRoll;fsRoll=()=>({id:'moonmaw',rk:'l',cm:200,g:false})}")
        await pg.keyboard.press('Space');await pg.wait_for_function("()=>FS.st==='reel'",timeout=6000);w0=await E("()=>FS.word")
        await pg.wait_for_function("()=>FS.hp===1",timeout=4000);r=await E("()=>[FS.st,FS.hp,FS.si]")
        chk('legendary line holds once',r,r==['reel',1,0])
        await E("()=>{fsTime=__ft}");await E("()=>{FS.tMax=FS.tLeft=20}")
        r=await E("()=>FS.word");await pg.keyboard.press('Escape');await pg.wait_for_timeout(800)
        r=await E("()=>[S.mode,!!document.getElementById('fsx'),HOME]");chk('Esc leaves to the main menu',r,r[1]==False and r[2]==True)
        await E("()=>{fsRoll=__fr;fsWait=__fw}")
        # leave with an undecided catch: it is kept (rare) instead of lost
        await E("()=>fishing()");await pg.wait_for_timeout(800)
        await catch('r');n0=await E("()=>fsP().cr.length");await E("()=>fsLeave()");n1=await E("()=>fsP().cr.length")
        chk('leaving keeps an undecided rare catch',[n0,n1],n1==n0+1)
        # balance sanity: odds sum to 100, legendary rarer than 1%, rods
        r=await E("()=>{const a=fsOdds(0,{}),b=fsOdds(5,{});return [Math.round(a.c+a.u+a.r+a.l),a.l<1,b.l>a.l,b.r>a.r]}");chk('odds',r,r==[100,True,True,True])
        # reset profile clears fishing
        r=await E("()=>{load({});return !P.fish||!Object.keys(fsP().b).length}");chk('profile reset clears fishing',r,r)
        print('bad',bad);print(er[:8])
        await b.close()
asyncio.run(main())
