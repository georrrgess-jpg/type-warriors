/* ===== RUNESTONE RIDDLE: Silas Veil, the Crimson Masquerade Phantom =====
   Drawn live in the game's storybook style (chunky #12081f outlines, flat colours with a darker right half,
   small upper-left highlights). silasDraw(g,t,st) paints him with the base of his smoke at 0,0 (about 240 units tall);
   st={mode:'idle'|'ability'|'cheer'|'sad'|'think',k:0..1,heat:0..1,look:-1..1}. Stateless: everything comes from t and st.
   silasPortrait(cv,t) fills a canvas with his round gold-ringed portrait. No filters or shadow blurs; gradients and alpha only. */
const SILAS={n:'Silas Veil',t:'Crimson Masquerade Phantom'};
const SILAS_O='#12081f',SILAS_SK='#8ba6bb',SILAS_SKL='#a3bccd',SILAS_RED='#b3203a',SILAS_RED2='#8c1530',SILAS_CRM='#f6e7c4',SILAS_GLD='#f0bf3c',SILAS_TEAL='#1f9a94';
/* wisp anchors: x,y,angle,length,curl,width,phase,front(1)/back(0); group 0 base,1 left hand,2 right hand,3 body,4 head, 5+ heat extras */
const SILAS_WISP=[
 [-19,-30,-2.5,36,-2.7,9,0,1,0],[17,-28,-.6,38,2.7,9,1.3,1,0],[-5,-40,-2.0,30,2.8,7,2.1,0,0],[7,-42,-1.1,32,-2.8,7,3.0,0,0],[-26,-12,-2.95,30,-2.4,7,4.1,1,0],[27,-12,-.2,30,2.4,7,5.0,1,0],
 [0,0,2.4,26,-2.6,7,.5,1,1],[0,0,1.3,20,2.6,6,2.6,1,1],
 [0,0,.75,26,2.6,7,1.7,1,2],[0,0,1.9,20,-2.6,6,3.3,1,2],
 [-36,-110,-2.7,30,-2.8,6,.9,0,3],[38,-106,-.4,30,2.6,6,2.4,0,3],
 [-30,-176,-2.7,28,-2.9,6,1.1,0,4],[36,-182,-.35,30,2.9,6,3.7,0,4],
 [-42,-62,-2.6,34,-2.8,7,4.6,0,5],[44,-66,-.5,34,2.8,7,5.5,0,5],[-34,-150,-2.2,30,2.6,6,2.9,0,5],[40,-146,-.9,28,-2.6,6,6.1,0,5],[-12,-20,-1.9,40,2.9,8,1.9,1,5],[12,-18,-1.3,40,-2.9,8,3.9,1,5]];
/* arm keyframes: shoulder, elbow, wrist (left = viewer's left) */
const SILAS_ARM={
 idle:[[-32,-133,-54,-112,-62,-140],[32,-133,46,-108,52,-86]],
 open:[[-32,-133,-58,-134,-82,-152],[32,-133,58,-134,82,-152]],
 up:[[-32,-133,-48,-160,-52,-192],[32,-133,48,-160,52,-192]],
 sad:[[-31,-127,-41,-105,-43,-81],[31,-127,41,-105,43,-81]],
 think:[[-32,-133,-46,-106,-18,-98],[32,-133,41,-104,19,-136]]};
function silasSS(a,b,x){x=(x-a)/(b-a);return x<=0?0:x>=1?1:x*x*(3-2*x)}
function silasSt(g,lw,c){g.lineWidth=lw;g.strokeStyle=c||SILAS_O;g.stroke()}
function silasFS(g,fill,sx,lw,dk){g.fillStyle=fill;g.fill();if(sx!=null){g.save();g.clip();g.fillStyle=dk||'rgba(30,0,40,.2)';g.fillRect(sx,-420,600,840);g.restore()}if(lw)silasSt(g,lw)}
function silasEl(g,x,y,rx,ry,fill,lw,sx,rot){g.beginPath();g.ellipse(x,y,rx,ry,rot||0,0,Math.PI*2);silasFS(g,fill,sx,lw)}
function silasHi(g,x1,y1,cx,cy,x2,y2,w,a){g.beginPath();g.moveTo(x1,y1);g.quadraticCurveTo(cx,cy,x2,y2);g.lineWidth=w||2.4;g.strokeStyle='rgba(255,255,255,'+(a||.7)+')';g.stroke()}
function silasMix(A,B,u){const o=[];for(let i=0;i<A.length;i++)o.push(A[i]+(B[i]-A[i])*u);return o}
/* a tapered smoky ribbon along a point list */
function silasRib(g,p,wm,fill,edge,core){const n=p.length>>1,L=[],R=[];
 for(let i=0;i<n;i++){const i0=i?i-1:0,i1=i<n-1?i+1:n-1;let dx=p[i1*2]-p[i0*2],dy=p[i1*2+1]-p[i0*2+1];const l=Math.hypot(dx,dy)||1,s=i/(n-1),w=wm*Math.pow(Math.sin(Math.PI*(.14+.86*s)),.85)*.5;
  L.push(p[i*2]-dy/l*w,p[i*2+1]+dx/l*w);R.push(p[i*2]+dy/l*w,p[i*2+1]-dx/l*w)}
 g.beginPath();g.moveTo(L[0],L[1]);for(let i=1;i<n-1;i++)g.quadraticCurveTo(L[i*2],L[i*2+1],(L[i*2]+L[i*2+2])/2,(L[i*2+1]+L[i*2+3])/2);g.lineTo(L[n*2-2],L[n*2-1]);
 g.lineTo(R[n*2-2],R[n*2-1]);for(let i=n-2;i>0;i--)g.quadraticCurveTo(R[i*2],R[i*2+1],(R[i*2]+R[i*2-2])/2,(R[i*2+1]+R[i*2-1])/2);g.lineTo(R[0],R[1]);g.closePath();
 g.fillStyle=fill;g.fill();if(edge){g.lineWidth=1.3;g.strokeStyle=edge;g.stroke()}
 if(core){g.beginPath();g.moveTo(p[0],p[1]);for(let i=1;i<n-1;i++)g.quadraticCurveTo(p[i*2],p[i*2+1],(p[i*2]+p[i*2+2])/2,(p[i*2+1]+p[i*2+3])/2);g.lineWidth=wm*.22;g.strokeStyle=core;g.stroke()}}
/* points of one curling wisp */
function silasWispPts(x,y,a,len,curl,t,ph,droop,wob){const N=12,st=len/N,p=[x,y];let h=a;
 for(let i=1;i<=N;i++){const s=i/N;h+=curl*(-.35+6*s*s*s)/N+Math.sin(t*1.5+ph+s*4)*.07*wob;if(droop>0){let d=Math.PI/2-h;d=Math.atan2(Math.sin(d),Math.cos(d));h+=d*droop*.16}
  x+=Math.cos(h)*st;y+=Math.sin(h)*st;p.push(x,y)}return p}
/* ---- one card: 0 moon, 1 star, 2 key ---- */
function silasCard(g,kind,x,y,rot,sc,glow,t){g.save();g.translate(x,y);g.rotate(rot);g.scale(sc,sc);
 const tw=.85+.15*Math.sin(t*5+kind*2),gc=kind===1?'60,230,215':'255,205,90';
 if(glow>.04){g.globalCompositeOperation='lighter';const r=22+glow*16,gr=g.createRadialGradient(0,0,3,0,0,r);gr.addColorStop(0,'rgba('+gc+','+(.5*glow*tw).toFixed(3)+')');gr.addColorStop(1,'rgba('+gc+',0)');g.fillStyle=gr;g.fillRect(-r,-r,r*2,r*2);g.globalCompositeOperation='source-over'}
 g.beginPath();g.roundRect(-12,-17,24,34,4);silasFS(g,'#fff6e2',3,2.8,'rgba(150,100,30,.13)');
 g.beginPath();g.roundRect(-8.6,-13.6,17.2,27.2,2.6);g.lineWidth=1.7;g.strokeStyle='#d9a12a';g.stroke();
 for(const [cx,cy] of [[-8.6,-13.6],[8.6,13.6]]){g.beginPath();g.moveTo(cx,cy-2.4);g.lineTo(cx+2.4,cy);g.lineTo(cx,cy+2.4);g.lineTo(cx-2.4,cy);g.closePath();g.fillStyle='#d9a12a';g.fill()}
 const gold=glow>.6?'#ffd24a':'#e6a92a',teal=glow>.6?'#2fd8c8':SILAS_TEAL;
 if(kind===0){g.save();g.rotate(-.55);g.beginPath();g.arc(0,0,8,.939,5.344,false);g.arc(5.5,0,6.5,-3.0224,3.0224,true);g.closePath();g.fillStyle=gold;g.fill();g.lineWidth=1.6;g.strokeStyle=SILAS_O;g.stroke();g.restore();
  silasHi(g,-5.5,-2.5,-6,1.5,-4,4.5,1.4,.8)}
 else if(kind===1){g.beginPath();for(let i=0;i<8;i++){const a=i*Math.PI/4-Math.PI/2,r=i&1?3.1:10;i?g.lineTo(Math.cos(a)*r,Math.sin(a)*r):g.moveTo(Math.cos(a)*r,Math.sin(a)*r)}g.closePath();g.fillStyle=teal;g.fill();g.lineWidth=1.6;g.strokeStyle=SILAS_O;g.stroke();
  g.beginPath();g.moveTo(-1,-6);g.lineTo(-1.6,-2.4);g.lineWidth=1.3;g.strokeStyle='rgba(255,255,255,.8)';g.stroke()}
 else{g.beginPath();g.arc(0,-6,4.6,0,Math.PI*2);g.moveTo(1.6,-1.8);g.lineTo(1.6,9.5);g.lineTo(-1.6,9.5);g.lineTo(-1.6,-1.8);g.fillStyle=gold;g.fill();g.lineWidth=1.6;g.strokeStyle=SILAS_O;g.stroke();
  g.beginPath();g.rect(1.6,4.2,4,2.2);g.rect(1.6,7.6,3,2);g.fillStyle=gold;g.fill();g.stroke();g.beginPath();g.arc(0,-6,1.7,0,Math.PI*2);g.fillStyle=SILAS_O;g.fill()}
 if(glow>.3){g.globalCompositeOperation='lighter';const r=9+glow*7,gr=g.createRadialGradient(0,0,0,0,0,r);gr.addColorStop(0,'rgba('+gc+','+(.55*(glow-.3)*tw).toFixed(3)+')');gr.addColorStop(1,'rgba('+gc+',0)');g.fillStyle=gr;g.fillRect(-r,-r,r*2,r*2);g.globalCompositeOperation='source-over'}
 g.restore()}
/* ---- a 4-point sparkle ---- */
function silasSpark(g,x,y,r,a,col){if(r<.5)return;g.save();g.translate(x,y);g.globalCompositeOperation='lighter';const gr=g.createRadialGradient(0,0,0,0,0,r*1.6);gr.addColorStop(0,'rgba('+col+','+(.7*a).toFixed(3)+')');gr.addColorStop(1,'rgba('+col+',0)');g.fillStyle=gr;g.fillRect(-r*1.6,-r*1.6,r*3.2,r*3.2);
 g.beginPath();for(let i=0;i<8;i++){const q=i*Math.PI/4,rr=i&1?r*.16:r;i?g.lineTo(Math.cos(q)*rr,Math.sin(q)*rr):g.moveTo(rr,0)}g.closePath();g.fillStyle='rgba(255,255,240,'+a.toFixed(3)+')';g.fill();g.restore()}
/* ---- an arm: sleeve, cuff, ghostly mitt ---- */
function silasArm(g,a,col,t,side){const [sx,sy,ex,ey,wx,wy]=a,cx=2*ex-(sx+wx)/2,cy=2*ey-(sy+wy)/2;
 g.beginPath();g.moveTo(sx,sy);g.quadraticCurveTo(cx,cy,wx,wy);g.lineWidth=20;g.strokeStyle=SILAS_O;g.stroke();g.lineWidth=13.4;g.strokeStyle=col;g.stroke();
 g.save();g.translate(-2.2,-1.8);g.beginPath();g.moveTo(sx+(cx-sx)*.2,sy+(cy-sy)*.2);g.quadraticCurveTo(cx,cy,(cx+wx)/2,(cy+wy)/2);g.lineWidth=2;g.strokeStyle='rgba(255,190,190,.2)';g.stroke();g.restore();
 let dx=wx-cx,dy=wy-cy;const l=Math.hypot(dx,dy)||1;dx/=l;dy/=l;
 g.lineCap='butt';g.beginPath();g.moveTo(wx-dx*9.5,wy-dy*9.5);g.lineTo(wx+dx*2.5,wy+dy*2.5);g.lineWidth=21;g.strokeStyle=SILAS_O;g.stroke();
 g.beginPath();g.moveTo(wx-dx*8,wy-dy*8);g.lineTo(wx+dx*1,wy+dy*1);g.lineWidth=15.4;g.strokeStyle=SILAS_CRM;g.stroke();g.lineCap='round';
 g.beginPath();g.moveTo(wx-dx*8-dy*5,wy-dy*8+dx*5);g.lineTo(wx+dx*1-dy*5,wy+dy*1+dx*5);g.lineWidth=4;g.strokeStyle='rgba(150,100,40,.25)';g.stroke();
 silasEl(g,wx-dx*3.5+dy*side*4,wy-dy*3.5-dx*side*4,2.4,2.4,SILAS_GLD,1.6);
 const hx=wx+dx*8,hy=wy+dy*8,an=Math.atan2(dy,dx);
 silasEl(g,hx-dy*side*6+dx*1,hy+dx*side*6+dy*1,4,3.4,SILAS_SK,2.4,null,an);
 silasEl(g,hx,hy,8.6,8,SILAS_SK,2.8,hx+2,an);
 g.beginPath();g.moveTo(hx+dx*3+dy*side*3,hy+dy*3-dx*side*3);g.lineTo(hx+dx*7+dy*side*1,hy+dy*7-dx*side*1);g.lineWidth=1.6;g.strokeStyle='rgba(18,8,31,.6)';g.stroke();
 return [hx,hy,dx,dy]}
/* ---- the head, centred on 0,0 (drawn at 1.15x) ---- */
function silasHead(g,t,ex,sway){
 /* tufts behind the head */
 g.beginPath();g.moveTo(-24,-8);g.quadraticCurveTo(-36,-6,-40+sway,4);g.quadraticCurveTo(-30,0,-24,6);g.closePath();silasFS(g,'#e8c978',null,3);
 g.beginPath();g.moveTo(24,-8);g.quadraticCurveTo(36,-6,39+sway,6);g.quadraticCurveTo(30,2,24,8);g.closePath();silasFS(g,'#d6b25e',null,3);
 g.beginPath();g.moveTo(-6,-30);g.bezierCurveTo(-26,-30,-27,-14,-26,4);g.bezierCurveTo(-25,22,-16,32,0,32);g.bezierCurveTo(16,32,26,22,26,4);g.bezierCurveTo(27,-14,22,-30,-6,-30);g.closePath();silasFS(g,SILAS_SK,9,3.4,'rgba(20,30,70,.2)');
 silasHi(g,-22,10,-21,18,-16,24,2.2,.45);
 /* blush */
 g.save();g.globalAlpha=.6;silasEl(g,-15,12,6.5,3.6,'#ff78a8',0);silasEl(g,25,10,5.2,3.4,'#ff78a8',0);g.restore();
 /* eyes */
 const E=[[-8,0,9.6],[15,-1,9]];
 for(const [x,y,r] of E){
  if(ex.happy){g.beginPath();g.moveTo(x-7.5,y+3);g.quadraticCurveTo(x,y-8,x+7.5,y+3);silasSt(g,3.4);continue}
  if(ex.blink){g.beginPath();g.moveTo(x-8,y+1);g.quadraticCurveTo(x,y+5,x+8,y+1);silasSt(g,3.2);continue}
  silasEl(g,x,y,r,r,'#fffaf0',3);
  const px=x+ex.px*3.6+1,py=y+ex.py*3.6+.6;silasEl(g,px,py,4.6,4.8,'#1a1230',0);silasEl(g,px-1.6,py-1.8,1.6,1.6,'#fff',0);silasEl(g,px+1.8,py+1.6,.8,.8,'#fff',0);
  if(ex.lid>0){g.save();g.beginPath();g.arc(x,y,r-1.4,0,Math.PI*2);g.clip();g.translate(x,y);g.rotate(x<0?-.28:.28);g.fillStyle=SILAS_SK;g.fillRect(-r-2,-r-2,r*2+4,(r+2)*ex.lid*1.05);g.restore();
   g.save();g.translate(x,y);g.rotate(x<0?-.28:.28);g.beginPath();g.moveTo(-r*.9,-r-1+(r+2)*ex.lid*1.05);g.lineTo(r*.9,-r-1+(r+2)*ex.lid*1.05);silasSt(g,2.6);g.restore()}}
 /* the long friendly nose */
 g.beginPath();g.moveTo(1,-8);g.quadraticCurveTo(-1,5,4,12);g.quadraticCurveTo(8,19.5,14.5,15);g.quadraticCurveTo(18,9,11,4.5);g.quadraticCurveTo(7.5,-1,8,-8);silasFS(g,SILAS_SKL,11,2.8,'rgba(20,30,70,.16)');
 silasHi(g,4,8,6,13,9,14,1.6,.75);
 /* mouth */
 if(ex.happy){g.beginPath();g.moveTo(-6,18);g.quadraticCurveTo(6,34,21,16);g.quadraticCurveTo(7,22,-6,18);g.closePath();silasFS(g,'#3a0a1e',null,2.8);
  g.save();g.clip();silasEl(g,8,27,6,4,'#ff6a8a',0);g.restore()}
 else if(ex.sad>.5){g.beginPath();g.moveTo(-1,25);g.quadraticCurveTo(7,18,16,24);silasSt(g,2.8)}
 else if(ex.think){g.beginPath();g.moveTo(1,23);g.quadraticCurveTo(9,20.5,15,23.5);silasSt(g,2.8)}
 else{g.beginPath();g.moveTo(-5,20);g.quadraticCurveTo(6,28,18.5,18.5);silasSt(g,2.8);g.beginPath();g.moveTo(17,21.5);g.quadraticCurveTo(19.5,19.5,19.5,16.5);silasSt(g,2.2)}
 /* messy swept hair */
 const s=sway,P=[[-26,-2],[-37+s,-11],[-29,-19],[-39+s,-33],[-27,-37],[-26+s,-52],[-11,-47],[1+s*.8,-58],[10,-48],[24+s*.8,-52],[24,-40],[38+s,-38],[29,-28],[41+s,-16],[28,-14],[33+s,-3],[25,-6]];
 const F=[[20,-19],[14+s*.3,-12],[8,-21],[1+s*.3,-13],[-5,-22],[-12+s*.3,-14],[-18,-21],[-25+s*.3,-9]];
 g.beginPath();g.moveTo(P[0][0],P[0][1]);
 const seg=(a,b,bend)=>{const mx=(a[0]+b[0])/2,my=(a[1]+b[1])/2,dx=b[0]-a[0],dy=b[1]-a[1];g.quadraticCurveTo(mx-dy*bend,my+dx*bend,b[0],b[1])};
 for(let i=1;i<P.length;i++)seg(P[i-1],P[i],i&1?-.34:.16);
 let last=P[P.length-1];F.forEach((q,i)=>{seg(last,q,i&1?-.24:.1);last=q});seg(last,P[0],.1);g.closePath();silasFS(g,'#f4dc94',10,3.4,'rgba(150,95,20,.2)');
 g.beginPath();g.moveTo(-24,-30);g.quadraticCurveTo(-14,-48,8,-47);g.quadraticCurveTo(-4,-42,-12,-33);g.quadraticCurveTo(-18,-28,-24,-30);g.closePath();g.fillStyle='rgba(255,250,225,.9)';g.fill();
 g.lineWidth=1.8;g.strokeStyle='rgba(170,115,30,.55)';
 for(const [a,b,c,d,e,f] of [[6,-28,12,-34,14,-42],[22,-22,27,-26,31,-33],[-22,-18,-26,-22,-32,-25]]){g.beginPath();g.moveTo(a,b);g.quadraticCurveTo(c,d,e,f);g.stroke()}
}
/* ---- the whole phantom: base of the smoke at 0,0 ---- */
function silasDraw(g,t,st){st=st||{};t=t||0;const mode=st.mode||'idle',k=Math.max(0,Math.min(1,st.k||0)),heat=Math.max(0,Math.min(1,st.heat||0)),look=Math.max(-1,Math.min(1,st.look||0)),pt=!!st._pt;
 const env=silasSS(0,.2,k)*(1-silasSS(.8,1,k)),bump=Math.sin(Math.PI*k);
 const eA=mode==='ability'?env:0,eC=mode==='cheer'?env:0,eS=mode==='sad'?silasSS(0,.25,k)*(1-silasSS(.85,1,k)):0,eT=mode==='think'?1:0;
 const tt=t*(1+heat*.5),bob=Math.sin(t*1.6)*4*(1-eS*.5),br=Math.sin(t*2.1)*.9;
 const lift=-4+bob-eA*8-(mode==='cheer'?bump*20:0)+eS*4;
 const spin=mode==='cheer'?Math.cos(Math.PI*2*silasSS(.08,.55,k)):1,sx=(spin<0?-1:1)*(.55+.45*Math.abs(spin));
 const fade=1-eS*.55;
 g.save();g.lineJoin='round';g.lineCap='round';
 /* aura, ground smoke and shadow */
 {const gr=g.createRadialGradient(0,-120,10,0,-120,140);gr.addColorStop(0,'rgba(130,180,215,'+(.12+heat*.14).toFixed(3)+')');gr.addColorStop(1,'rgba(130,180,215,0)');g.fillStyle=gr;g.fillRect(-140,-260,280,280);
  g.save();g.globalAlpha=.3;silasEl(g,0,-2,40,7,'#000',0);g.restore();
  const g2=g.createRadialGradient(0,-4,2,0,-4,56);g2.addColorStop(0,'rgba(170,200,225,'+(.42+heat*.2).toFixed(3)+')');g2.addColorStop(1,'rgba(170,200,225,0)');g.save();g.scale(1,.26);g.fillStyle=g2;g.beginPath();g.arc(0,-15,56,0,Math.PI*2);g.fill();g.restore()}
 g.translate(0,lift);if(sx!==1)g.scale(sx,1);
 if(mode==='sad')g.rotate(.03*eS);
 if(mode==='cheer')g.rotate(Math.sin(k*Math.PI*3)*.05*env);
 /* pose */
 const AP=SILAS_ARM;let L=AP.idle[0].slice(),R=AP.idle[1].slice();
 L[5]+=Math.sin(t*2.2)*1.5;L[3]+=Math.sin(t*2.2)*.8;R[4]+=Math.sin(t*1.7)*1.2;
 if(pt){L=silasMix(L,AP.sad[0],.8);R=silasMix(R,AP.sad[1],.8)}
 if(eA){L=silasMix(L,AP.open[0],eA);R=silasMix(R,AP.open[1],eA)}
 if(eC){L=silasMix(L,AP.up[0],eC);R=silasMix(R,AP.up[1],eC)}
 if(eS){L=silasMix(L,AP.sad[0],eS);R=silasMix(R,AP.sad[1],eS)}
 if(eT){const th=Math.sin(t*1.3)*1.2;L=AP.think[0].slice();R=AP.think[1].slice();R[4]+=th*.5;R[5]+=th}
 L[1]+=br*.6;R[1]+=br*.6;
 const hx=3,hy=-182+br*.8+eS*7-eC*3,hr=Math.sin(t*1.1)*.03+eS*.12-eT*.07+(mode==='cheer'?Math.sin(k*Math.PI*4)*.06*env:0);
 /* hand positions (needed for wisps and the card fan) */
 const hand=a=>{const cx=2*a[2]-(a[0]+a[4])/2,cy=2*a[3]-(a[1]+a[5])/2;let dx=a[4]-cx,dy=a[5]-cy;const l=Math.hypot(dx,dy)||1;return [a[4]+dx/l*8,a[5]+dy/l*8,dx/l,dy/l]};
 const HL=hand(L),HR=hand(R);
 /* cards: x,y,rot,scale,front */
 const cards=[];if(!pt){const fa=-.1*(1-eS)+(-2.5)*eS;const px=HL[0]+HL[2]*3,py=HL[1]+HL[3]*3;
  for(let i=0;i<3;i++){const fr=44-20*eS,a=fa+(i-1)*(.5-.16*eS)+Math.sin(t*2.2+i)*.035;let c=[px+Math.sin(a)*fr,py-Math.cos(a)*fr+15*(1-eS),a,1,1];
   if(eT){const an=t*1.1+i*Math.PI*2/3,sn=Math.sin(an);c=[-66+Math.cos(an)*26,-194+sn*11+Math.sin(t*2+i)*2,Math.sin(t*.9+i)*.22,.86+.12*sn,sn>-.2?1:0]}
   if(eA){const an=i*Math.PI*2/3+k*Math.PI*2*1.6-1.2,sn=Math.sin(an),rise=Math.sin(k*Math.PI*2+i)*14;
    const o=[Math.cos(an)*88,-122+sn*30+rise,an*.5+k*6,1+.14*sn,sn>0?1:0];c=silasMix(c,o,eA);c[4]=eA>.3?o[4]:1}
   if(eC){const o=[[-70,-236],[4,-262],[76,-236]][i],u=silasSS(0,.45,k)*(1-silasSS(.65,1,k));c=silasMix(c,[o[0],o[1]+Math.sin(t*3+i)*3,(i-1)*.5+Math.sin(k*Math.PI*2)*(i-1)*1.2,1.06,1],u);c[4]=1}
   cards.push(c)}}
 const glow=.12+heat*.88;
 /* wisps */
 const wN=14+Math.round(heat*6),wA=(.5+heat*.28)*(1-eS*.3),wc=[Math.round(150-heat*10),Math.round(176+heat*50),Math.round(200+heat*30)];
 const wf='rgba('+wc+','+wA.toFixed(3)+')',we='rgba(40,60,110,'+(wA*.42).toFixed(3)+')',wco='rgba(230,248,255,'+(.18+heat*.3).toFixed(3)+')';
 const drawW=front=>{for(let i=0;i<SILAS_WISP.length;i++){const w=SILAS_WISP[i];if(w[7]!==front)continue;let al=1;if(i>=14){const need=(i-13)/7;al=Math.max(0,Math.min(1,(heat+.1-need)*4));if(al<=0)continue}
   let x=w[0],y=w[1];if(w[8]===1){x+=HL[0];y+=HL[1]}else if(w[8]===2){x+=HR[0];y+=HR[1]}if(pt&&w[8]===0)continue;
   const p=silasWispPts(x,y,w[2]+Math.sin(tt*.9+w[6])*.25,w[3]*(1+heat*.3)*(.92+.08*Math.sin(tt*1.3+w[6])),w[4]*(1+eC*.4),tt,w[6],eS*.9+(w[8]===0?0:.15),1+heat*.8);
   const fa2=w[8]===0?fade:1;if(al*fa2<.99){g.save();g.globalAlpha=al*fa2}
   silasRib(g,p,w[5]*(1+heat*.25),wf,we,wco);
   if(al*fa2<.99)g.restore()}};
 /* little floating motes */
 const motes=()=>{const n=4+Math.round(heat*5);for(let i=0;i<n;i++){const ph=i*1.7,rise=(t*(10+heat*8)+i*29)%70,x=Math.sin(ph*3.1)*58+Math.sin(t*.8+ph)*6,y=-30-((i*41)%150)-rise,a=Math.sin(Math.PI*rise/70)*(.5+heat*.4);
  silasEl(g,x,y,1.8+(i%3)*.7,1.8+(i%3)*.7,'rgba('+wc+','+a.toFixed(3)+')',0)}};
 /* vortex ribbons for the ability */
 const vortex=front=>{if(eA<.02)return;for(let j=0;j<3;j++){let pts=[];const a0=k*Math.PI*2*1.3+j*2.1,flush=()=>{if(pts.length>=8)silasRib(g,pts,9-j*1.5,'rgba('+wc+','+(eA*(.42+heat*.25)).toFixed(3)+')',null,'rgba(235,250,255,'+(eA*.45).toFixed(3)+')');pts=[]};
  for(let i=0;i<=16;i++){const s=i/16,an=a0+s*2.6,rr=(94-j*10)*(1-.12*s),sn=Math.sin(an);if((sn>0)!==front){flush();continue}pts.push(Math.cos(an)*rr,-70-j*40+sn*(26-j*4)-s*24)}flush()}};
 vortex(false);drawW(0);
 for(const c of cards)if(!c[4])silasCard(g,cards.indexOf(c),c[0],c[1],c[2],c[3],glow,t);
 /* coat tails, swaying */
 const sw=Math.sin(t*1.8)*3+eC*6*Math.sin(k*Math.PI*6),fl=eA*6+eC*8-eS*3;
 g.beginPath();g.moveTo(-30,-108);g.quadraticCurveTo(-42-fl*.5,-78,-50-fl+sw,-34+eS*3);g.lineTo(-37-fl*.6+sw,-42);g.quadraticCurveTo(-22,-66,-8,-96);g.closePath();silasFS(g,SILAS_RED,-30,3.2,'rgba(40,0,20,.22)');
 g.beginPath();g.moveTo(30,-108);g.quadraticCurveTo(42+fl*.5,-78,49+fl+sw*.8,-34+eS*3);g.lineTo(36+fl*.6+sw*.8,-42);g.quadraticCurveTo(22,-66,8,-96);g.closePath();silasFS(g,SILAS_RED2,99,3.2);
 g.beginPath();g.moveTo(-27,-100);g.quadraticCurveTo(-36,-74,-44-fl+sw,-38);g.lineWidth=2;g.strokeStyle='rgba(40,0,20,.35)';g.stroke();
 /* trousers fading into smoke, then the shoes beneath */
 {const lg=g.createLinearGradient(0,-54,0,-24);lg.addColorStop(0,'rgba(102,22,44,'+fade+')');lg.addColorStop(1,'rgba(102,22,44,0)');const lo=g.createLinearGradient(0,-50,0,-26);lo.addColorStop(0,SILAS_O);lo.addColorStop(1,'rgba(18,8,31,0)');
  const ld=g.createLinearGradient(0,-54,0,-24);ld.addColorStop(0,'rgba(66,10,30,'+fade+')');ld.addColorStop(1,'rgba(66,10,30,0)');
  for(const s of [-1,1]){g.beginPath();g.moveTo(0,-96);g.lineTo(s*23,-96);g.lineTo(s*20,-24);g.lineTo(s*3,-24);g.lineTo(0,-86);g.closePath();g.fillStyle=s<0?lg:ld;g.fill();g.lineWidth=3.2;g.strokeStyle=lo;g.stroke()}
  g.save();g.globalAlpha=.92*fade;for(const s of [-1,1]){const y0=-7;g.beginPath();g.moveTo(s*5,y0-12);g.quadraticCurveTo(s*6,y0-20,s*15,y0-20);g.quadraticCurveTo(s*29,y0-20,s*30,y0-7);g.quadraticCurveTo(s*18,y0-1,s*5,y0-3);g.closePath();silasFS(g,'#1c1424',null,2.8);silasHi(g,s*11,y0-15,s*15,y0-18,s*21,y0-16,2,.8)}g.restore()}
 /* torso: waistcoat, shirt, coat fronts, lapels, bow tie */
 g.save();g.translate(0,-96);g.scale(1,1+br*.006);g.translate(0,96);
 g.beginPath();g.rect(-7,-158,14,14);silasFS(g,SILAS_SK,1,2.8);
 g.beginPath();g.moveTo(-16,-142);g.lineTo(16,-142);g.lineTo(19,-96);g.lineTo(12,-84);g.lineTo(0,-92);g.lineTo(-12,-84);g.lineTo(-19,-96);g.closePath();silasFS(g,SILAS_TEAL,2,3);
 g.beginPath();g.moveTo(-11,-147);g.lineTo(11,-147);g.lineTo(0,-118);g.closePath();silasFS(g,'#fffcf2',2,2.6,'rgba(60,60,100,.12)');
 g.beginPath();g.moveTo(-1,-136);g.lineTo(-1,-122);g.lineWidth=1.4;g.strokeStyle='rgba(60,60,100,.3)';g.stroke();
 for(const y of [-111,-101,-91])silasEl(g,0,y,2.8,2.8,SILAS_GLD,1.8);
 g.beginPath();g.moveTo(-13,-147);g.quadraticCurveTo(-32,-147,-38,-135);g.quadraticCurveTo(-44,-112,-38,-90);g.quadraticCurveTo(-26,-90,-13,-102);g.lineTo(-12,-147);g.closePath();silasFS(g,SILAS_RED,-22,3.2,'rgba(40,0,20,.14)');
 g.beginPath();g.moveTo(13,-147);g.quadraticCurveTo(32,-147,38,-135);g.quadraticCurveTo(44,-112,38,-90);g.quadraticCurveTo(26,-90,13,-102);g.lineTo(12,-147);g.closePath();silasFS(g,SILAS_RED2,99,3.2);
 g.beginPath();g.moveTo(-10,-148);g.lineTo(-13,-104);g.lineTo(-19,-122);g.lineTo(-27,-129);g.lineTo(-22,-134);g.lineTo(-25,-141);g.lineTo(-16,-149);g.closePath();silasFS(g,SILAS_CRM,null,2.6);
 g.beginPath();g.moveTo(10,-148);g.lineTo(13,-104);g.lineTo(19,-122);g.lineTo(27,-129);g.lineTo(22,-134);g.lineTo(25,-141);g.lineTo(16,-149);g.closePath();silasFS(g,'#e0cca4',null,2.6);
 silasHi(g,-19,-140,-15,-128,-14,-114,1.8,.6);
 g.beginPath();g.moveTo(21,-117);g.lineTo(24,-124);g.lineTo(27,-119);g.lineTo(31,-124);g.lineTo(32,-117);g.closePath();silasFS(g,SILAS_CRM,null,1.8);g.beginPath();g.moveTo(19,-116.5);g.lineTo(34,-116.5);silasSt(g,2);
 g.beginPath();g.moveTo(-34,-96);g.lineTo(-18,-98);g.moveTo(18,-98);g.lineTo(34,-96);g.lineWidth=2;g.strokeStyle='rgba(18,8,31,.55)';g.stroke();
 /* bow tie with its gem stud */
 g.beginPath();g.moveTo(0,-143);g.quadraticCurveTo(-8,-151,-14,-149);g.quadraticCurveTo(-16,-143,-14,-136);g.quadraticCurveTo(-8,-135,0,-143);g.closePath();silasFS(g,'#1c1428',null,2.6);
 g.beginPath();g.moveTo(0,-143);g.quadraticCurveTo(8,-151,14,-149);g.quadraticCurveTo(16,-143,14,-136);g.quadraticCurveTo(8,-135,0,-143);g.closePath();silasFS(g,'#1c1428',null,2.6);
 silasHi(g,-11,-146,-9,-147,-6,-145,1.4,.5);
 silasEl(g,0,-143,4.2,4.2,SILAS_GLD,2.2,1.2,null);silasEl(g,-1.2,-144.4,1.3,1.3,'#fff8d0',0);
 {const gl=Math.max(0,1-Math.abs(((t*.45)%1)-.5)*10);if(gl>0)silasSpark(g,1.5,-145,7*gl,gl,'255,240,180')}
 g.restore();
 /* head */
 g.save();g.translate(hx,hy);g.rotate(hr);g.scale(1.15,1.15);
 const blink=((t+.4)%3.7)<.13,ex={happy:eC>.25,blink:blink&&!eC,px:look*(1-eT)+eT*.35,py:eT?-.85:eS?.5:.1,lid:eS*.38+eT*.08,sad:eS,think:eT};
 silasHead(g,t,ex,Math.sin(t*1.8)*1.3+eC*2*Math.sin(k*Math.PI*6));g.restore();
 for(const c of cards)if(c[4]&&eT===0&&!eA&&!eC)silasCard(g,cards.indexOf(c),c[0],c[1],c[2],c[3],glow,t);
 /* arms */
 silasArm(g,R,SILAS_RED2,t,1);silasArm(g,L,SILAS_RED,t,-1);
 drawW(1);motes();vortex(true);
 for(const c of cards)if(c[4]&&(eT||eA||eC))silasCard(g,cards.indexOf(c),c[0],c[1],c[2],c[3],glow,t);
 /* sparkle at the height of the ability / cheer */
 if(mode==='ability'){const p=Math.max(0,1-Math.abs(k-.5)/.2);if(p>0){silasSpark(g,0,-262,30*p,p,'90,240,225');silasSpark(g,0,-262,17*p,p,'255,215,110');for(const c of cards)silasSpark(g,c[0]+9,c[1]-13,9*p,p,'255,230,150')}}
 if(mode==='cheer'){const p=Math.max(0,1-Math.abs(k-.5)/.25);if(p>0)for(const c of cards)silasSpark(g,c[0],c[1]-22,10*p,p,'255,225,140')}
 if(heat>.5){const p=(heat-.5)*2;for(let i=0;i<cards.length;i++){const c=cards[i],tw=Math.max(0,Math.sin(t*3+i*2.1));if(tw>.05)silasSpark(g,c[0]+11,c[1]-15,7*p*tw,p*tw,i===1?'90,240,225':'255,220,120')}}
 g.restore()}
/* ---- round gold-ringed portrait on a deep purple disc ---- */
function silasPortrait(cv,t){const g=cv.getContext('2d'),w=cv.width,h=cv.height;t=t==null?1.2:t;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,w,h);
 const m=Math.min(w,h),R=m/2-Math.max(2,m*.035),cx=w/2,cy=h/2;
 g.save();g.beginPath();g.arc(cx,cy,R,0,Math.PI*2);const bg=g.createRadialGradient(cx,cy-R*.2,R*.1,cx,cy,R);bg.addColorStop(0,'#46206c');bg.addColorStop(1,'#1c0b34');g.fillStyle=bg;g.fill();g.clip();
 const s=R/64;g.translate(cx-9*s,cy+182*s+R*.12);g.scale(s,s);silasDraw(g,t,{mode:'idle',k:0,heat:.35,look:0,_pt:1});g.restore();
 g.save();g.beginPath();g.arc(cx,cy,R,0,Math.PI*2);g.lineWidth=Math.max(3,m*.07);g.strokeStyle=SILAS_O;g.stroke();
 const rg=g.createLinearGradient(cx-R,cy-R,cx+R,cy+R);rg.addColorStop(0,'#ffe08a');rg.addColorStop(.5,'#e0a630');rg.addColorStop(1,'#9a6a14');g.lineWidth=Math.max(1.6,m*.038);g.strokeStyle=rg;g.stroke();
 g.beginPath();g.arc(cx,cy,R,Math.PI*1.1,Math.PI*1.45);g.lineWidth=Math.max(.8,m*.012);g.strokeStyle='rgba(255,250,220,.8)';g.stroke();g.restore()}
