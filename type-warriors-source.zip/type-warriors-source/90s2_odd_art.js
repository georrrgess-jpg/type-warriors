/* ===== MOONLIT FISHING update 7: odd catch art (boot, bottle, chest, ring) =====
   Things you can reel in that aren't fish. They use the fish contract so the whole catch pipeline can draw them:
   FISHART.<id>=(g,t,o), centred on the origin, about 200 units wide, inside x -115..115 / y -80..80. o.glow lights
   the catch spectacle, o.sil (fishDraw passes o.sil===0 while it renders a silhouette) skips glows and loose sparkles.
   odPageArt(g,w,h,t) paints the torn parchment page behind the bottle-letter reader card (text is HTML on top).
   Private helpers are prefixed od_. */
function od_path(g,c){g.beginPath();let i=0;while(i<c.length){const k=c[i++];
 if(k==='M'){g.moveTo(c[i],c[i+1]);i+=2}else if(k==='L'){g.lineTo(c[i],c[i+1]);i+=2}
 else if(k==='Q'){g.quadraticCurveTo(c[i],c[i+1],c[i+2],c[i+3]);i+=4}else if(k==='C'){g.bezierCurveTo(c[i],c[i+1],c[i+2],c[i+3],c[i+4],c[i+5]);i+=6}
 else if(k==='Z')g.closePath()}}
function od_poly(g,p){g.beginPath();g.moveTo(p[0],p[1]);for(let i=2;i<p.length;i+=2)g.lineTo(p[i],p[i+1]);g.closePath()}
function od_grad(g,x0,y0,x1,y1,s){const q=g.createLinearGradient(x0,y0,x1,y1);for(const e of s)q.addColorStop(e[0],e[1]);return q}
function od_rgrad(g,x,y,r0,r1,s){const q=g.createRadialGradient(x,y,r0,x,y,r1);for(const e of s)q.addColorStop(e[0],e[1]);return q}
function od_fill(g,f,lw){g.fillStyle=f;g.fill();if(lw!==0){g.lineWidth=lw||3;g.strokeStyle='#1b1024';g.lineJoin='round';g.stroke()}}
const od_tw=(t,i,sp)=>.5+.5*Math.sin(t*(sp||3)+i*1.91);
const od_K='#1b1024';
function od_spark(g,x,y,r,c,a){g.save();g.globalAlpha=a==null?1:a;g.fillStyle=c||'#fff';g.beginPath();g.moveTo(x,y-r);g.quadraticCurveTo(x+r*.16,y-r*.16,x+r,y);g.quadraticCurveTo(x+r*.16,y+r*.16,x,y+r);g.quadraticCurveTo(x-r*.16,y+r*.16,x-r,y);g.quadraticCurveTo(x-r*.16,y-r*.16,x,y-r);g.fill();g.restore()}
function od_glow(g,x,y,r,c,a){if(r<=0||a<=0)return;g.save();g.globalCompositeOperation='lighter';g.fillStyle=od_rgrad(g,x,y,0,r,[[0,c+Math.round(Math.min(1,a)*255).toString(16).padStart(2,'0')],[1,c+'00']]);g.beginPath();g.arc(x,y,r,0,TAU);g.fill();g.restore()}
/* ribbon around a spine with half widths; returns a path builder */
function od_ribbon(g,P,W){const L=[],R=[],n=P.length;
 for(let i=0;i<n;i++){const a=P[Math.max(0,i-1)],b=P[Math.min(n-1,i+1)];let dx=b[0]-a[0],dy=b[1]-a[1];const d=Math.hypot(dx,dy)||1;dx/=d;dy/=d;L.push([P[i][0]-dy*W[i],P[i][1]+dx*W[i]]);R.push([P[i][0]+dy*W[i],P[i][1]-dx*W[i]])}
 return ()=>{g.beginPath();g.moveTo(L[0][0],L[0][1]);for(let i=1;i<n;i++){const m=[(L[i-1][0]+L[i][0])/2,(L[i-1][1]+L[i][1])/2];g.quadraticCurveTo(L[i-1][0],L[i-1][1],m[0],m[1])}
  g.lineTo(L[n-1][0],L[n-1][1]);g.lineTo(R[n-1][0],R[n-1][1]);for(let i=n-2;i>=0;i--){const m=[(R[i+1][0]+R[i][0])/2,(R[i+1][1]+R[i][1])/2];g.quadraticCurveTo(R[i+1][0],R[i+1][1],m[0],m[1])}
  g.lineTo(R[0][0],R[0][1]);g.closePath()}}
/* seaweed strand along points, swaying with t */
function od_weed(g,t,pts,w,ph,fx){const P=[],W=[],n=pts.length/2;for(let i=0;i<n;i++){const s=i/(n-1);P.push([pts[i*2]+Math.sin(t*2+ph+s*3)*3*s,pts[i*2+1]+Math.sin(t*1.6+ph-s*2)*1.5*s]);W.push(w*(.6+.4*Math.sin(Math.min(1,s*1.5)*Math.PI*.9))*(1-.45*s)+.5)}
 const R=od_ribbon(g,P,W);R();od_fill(g,od_grad(g,P[0][0],P[0][1],P[n-1][0],P[n-1][1],[[0,'#2a8a40'],[.55,'#56c860'],[1,'#b0f080']]),1.8);
 g.save();R();g.clip();g.beginPath();g.moveTo(P[0][0],P[0][1]);for(const p of P)g.lineTo(p[0],p[1]);g.strokeStyle='rgba(20,90,40,.5)';g.lineWidth=1.1;g.stroke();g.restore()}
/* barnacle cone (side view) */
function od_barn(g,x,y,w,h,rot){g.save();g.translate(x,y);g.rotate(rot||0);const P=()=>od_path(g,['M',-w/2,0,'Q',-w*.46,-h*.55,-w*.24,-h,'L',w*.24,-h,'Q',w*.46,-h*.55,w/2,0,'Z']);
 P();od_fill(g,od_grad(g,-w/2,-h,w/2,0,[[0,'#fffaf0'],[.5,'#e2d9c6'],[1,'#a89c8c']]),1.5);
 g.save();P();g.clip();g.strokeStyle='rgba(90,70,70,.45)';g.lineWidth=.9;g.beginPath();for(const f of [-.3,0,.3]){g.moveTo(w*f*1.4,0);g.lineTo(w*f*.62,-h)}g.stroke();g.restore();
 g.beginPath();g.ellipse(0,-h,w*.24,Math.max(1,h*.14),0,0,TAU);g.fillStyle='#3a2a3a';g.fill();g.lineWidth=1.1;g.strokeStyle=od_K;g.stroke();g.restore()}
/* a falling water drop: cycles from (x,y) down by dist */
function od_drip(g,t,x,y,dist,sp,ph){const p=((t*sp+ph)%1+1)%1,yy=y+p*p*dist,a=p<.15?p/.15:1-Math.max(0,(p-.75)/.25),s=p<.15?.5+p*3.3:1;
 g.save();g.globalAlpha=a;g.translate(x,yy);g.scale(s,s);od_path(g,['M',0,-6,'Q',4,0,3.2,2.6,'Q',0,6,-3.2,2.6,'Q',-4,0,0,-6,'Z']);od_fill(g,od_grad(g,0,-6,0,5,[[0,'#e8fbff'],[1,'#6ac8f0']]),1.3);
 g.beginPath();g.arc(-1,1.4,1,0,TAU);g.fillStyle='#fff';g.fill();g.restore()}

/* ---------- soggy old boot (with a lodger) ---------- */
FISHART.oddboot=(g,t,o)=>{const fx=o.flex||0,gl=o.glow||0,SIL=o.sil===0;
 g.save();g.translate(-4,1+Math.sin(t*1.4)*1.5);g.rotate(-.05+Math.sin(t*1.1)*.02+Math.sin(t*6)*fx*.04);
 // seaweed draped over the back of the shaft
 od_weed(g,t,[-80,-58,-94,-46,-98,-28,-94,-12,-100,4,-96,18],5,0,fx);
 // the curled toe (a tapering spiral, behind the foot outline)
 {const P=[[78,14],[92,10],[102,0],[105,-12],[99,-22],[90,-22],[86,-14],[91,-9]],W=[13,11,9.5,8,6.5,5,3.6,2.4];const R=od_ribbon(g,P,W);R();od_fill(g,od_grad(g,80,-24,104,18,[[0,'#a87444'],[.6,'#7a4a26'],[1,'#5a3218']]),3);
  g.save();R();g.clip();g.beginPath();g.moveTo(84,6);g.quadraticCurveTo(104,0,100,-16);g.strokeStyle='rgba(255,220,170,.35)';g.lineWidth=2.4;g.stroke();g.restore()}
 // inside of the boot opening (dark), with the little crab peeking out
 g.beginPath();g.ellipse(-58,-60,29,7,-.03,0,TAU);od_fill(g,od_rgrad(g,-58,-58,2,30,[[0,'#120a10'],[1,'#3a2216']]),2.6);
 {const pk=Math.max(0,Math.sin(t*.9))**.5,cy=-58-pk*7,wv=Math.sin(t*5);g.save();g.beginPath();g.rect(-100,-100,90,40+(-60+100));g.clip();
  // eyestalks
  for(const s of [-1,1]){const ex=-58+s*6+Math.sin(t*2+s)*.8,ey=cy-14;g.beginPath();g.moveTo(-58+s*4,cy-4);g.lineTo(ex,ey);g.strokeStyle=od_K;g.lineWidth=3.6;g.stroke();g.strokeStyle='#ff7a4a';g.lineWidth=1.8;g.stroke();
   g.beginPath();g.arc(ex,ey,3.4,0,TAU);od_fill(g,'#fffdf6',1.6);g.beginPath();g.arc(ex+.8,ey+.4,1.7,0,TAU);g.fillStyle='#120a14';g.fill()}
  // shell
  od_path(g,['M',-72,cy+6,'Q',-72,cy-8,-58,cy-8,'Q',-44,cy-8,-44,cy+6,'Z']);od_fill(g,od_grad(g,0,cy-8,0,cy+6,[[0,'#ff9a5a'],[1,'#d8442a']]),2.2);
  g.beginPath();g.arc(-62,cy-3,1.4,0,TAU);g.arc(-54,cy-3,1.4,0,TAU);g.fillStyle='rgba(255,230,200,.8)';g.fill();
  // one claw waving hello over the rim
  g.save();g.translate(-44,cy+2);g.rotate(-.7+wv*.35);g.beginPath();g.moveTo(0,0);g.lineTo(8,-6);g.strokeStyle=od_K;g.lineWidth=4.2;g.stroke();g.strokeStyle='#ff7a4a';g.lineWidth=2.2;g.stroke();
  od_path(g,['M',6,-5,'Q',10,-16,18,-12,'L',13,-9,'L',19,-6,'Q',14,0,6,-3,'Z']);od_fill(g,od_grad(g,6,-14,18,0,[[0,'#ff9a5a'],[1,'#d8442a']]),1.8);g.restore();
  g.restore()}
 // the boot: shaft and foot in one soggy leather outline
 const BO=()=>od_path(g,['M',-88,-60,'L',-30,-62,'Q',-27,-30,-14,-14,'Q',22,-4,58,2,'Q',84,6,94,16,'Q',99,26,92,34,'L',-84,38,'Q',-93,0,-88,-60,'Z']);
 BO();od_fill(g,od_grad(g,0,-62,0,38,[[0,'#9a6438'],[.5,'#7a4a26'],[1,'#5a3218']]),3.2);
 g.save();BO();g.clip();
 // wet darker patches, a lighter scuffed toe, leather creases and a stitched patch
 g.fillStyle='rgba(40,20,10,.28)';g.beginPath();g.ellipse(-60,10,30,26,0,0,TAU);g.fill();g.beginPath();g.ellipse(30,22,40,12,0,0,TAU);g.fill();
 g.fillStyle=od_rgrad(g,70,8,2,30,[[0,'rgba(220,170,120,.45)'],[1,'rgba(220,170,120,0)']]);g.fillRect(40,-20,60,60);
 g.strokeStyle='rgba(30,14,6,.45)';g.lineWidth=1.6;g.lineCap='round';for(const c of [[-18,-6,-6,14],[-6,-4,8,12],[6,-2,22,10]]){g.beginPath();g.moveTo(c[0],c[1]);g.quadraticCurveTo((c[0]+c[2])/2+4,(c[1]+c[3])/2,c[2],c[3]);g.stroke()}
 od_poly(g,[-74,-30,-52,-32,-50,-12,-72,-10]);g.fillStyle='#b07a48';g.fill();g.strokeStyle='rgba(40,20,10,.7)';g.lineWidth=1.2;g.setLineDash([2.4,2]);g.stroke();
 g.beginPath();g.moveTo(-82,32);g.quadraticCurveTo(0,30,90,28);g.stroke();g.beginPath();g.moveTo(-34,-58);g.quadraticCurveTo(-30,-30,-18,-18);g.stroke();g.setLineDash([]);
 // shine of wet leather
 g.beginPath();g.moveTo(-84,-50);g.quadraticCurveTo(-88,-10,-80,20);g.strokeStyle='rgba(255,230,200,.4)';g.lineWidth=3.4;g.stroke();
 g.beginPath();g.moveTo(10,-4);g.quadraticCurveTo(50,0,84,10);g.strokeStyle='rgba(255,230,200,.45)';g.lineWidth=2.4;g.stroke();
 g.restore();
 // rim of the opening (front lip over the crab)
 g.beginPath();g.ellipse(-58,-60,29,7,-.03,0,Math.PI);g.strokeStyle=od_K;g.lineWidth=5.4;g.stroke();g.strokeStyle='#b07a48';g.lineWidth=2.6;g.stroke();
 // pull tab at the back
 od_path(g,['M',-88,-60,'Q',-96,-70,-86,-72,'Q',-80,-68,-82,-60,'Z']);od_fill(g,'#8a5530',2);
 // eyelets and crossed laces, one lace dangling loose and dripping
 const E=[[-30,-52],[-27,-40],[-22,-29],[-14,-19]];
 g.lineCap='round';for(let i=0;i<E.length-1;i++){const a=E[i],b=E[i+1];g.beginPath();g.moveTo(a[0]-5,a[1]);g.lineTo(b[0]+5,b[1]+2);g.moveTo(a[0]+5,a[1]+1);g.lineTo(b[0]-5,b[1]);g.strokeStyle=od_K;g.lineWidth=4;g.stroke();g.strokeStyle='#e8d8b0';g.lineWidth=2;g.stroke()}
 for(const e of E){for(const s of [-5,5]){g.beginPath();g.arc(e[0]+s,e[1],2.6,0,TAU);od_fill(g,'#e0b04a',1.4);g.beginPath();g.arc(e[0]+s,e[1],1,0,TAU);g.fillStyle='#2a1810';g.fill()}}
 {const sw=Math.sin(t*1.8)*.18*(1+fx*2),P=[];for(let k=0;k<8;k++){const s=k/7,a=sw*s*s;P.push([-25+Math.sin(a)*s*58+s*14,-54+Math.cos(a)*s*58])}
  g.beginPath();g.moveTo(-25,-54);for(const p of P)g.lineTo(p[0],p[1]);g.strokeStyle=od_K;g.lineWidth=4.2;g.stroke();g.strokeStyle='#e8d8b0';g.lineWidth=2.2;g.stroke();
  const e=P[7];od_poly(g,[e[0]-1.6,e[1]-1,e[0]+1.6,e[1]-1,e[0]+1.4,e[1]+5,e[0]-1.4,e[1]+5]);od_fill(g,'#c8b890',1.2);
  if(!SIL)od_drip(g,t,e[0],e[1]+7,22,.8,.3);
  // a little bow loop
  g.beginPath();g.ellipse(-34,-58,6,3.4,-.5,0,TAU);g.strokeStyle=od_K;g.lineWidth=4;g.stroke();g.strokeStyle='#e8d8b0';g.lineWidth=2;g.stroke()}
 // sole: a heel block and a flapping front that gapes open like a mouth with nail "teeth"
 od_path(g,['M',-86,36,'L',30,34,'L',30,46,'L',-40,48,'L',-42,56,'L',-80,56,'L',-84,46,'Z']);od_fill(g,od_grad(g,0,34,0,56,[[0,'#4a2c1a'],[1,'#2a160c']]),2.8);
 {const fl=.1+.08*Math.max(0,Math.sin(t*2.4))+fx*.08;g.save();g.translate(30,40);g.rotate(fl);
  od_path(g,['M',0,-6,'L',62,-10,'Q',72,-8,72,-2,'Q',70,4,60,5,'L',0,6,'Z']);od_fill(g,od_grad(g,0,-10,0,6,[[0,'#4a2c1a'],[1,'#2a160c']]),2.8);
  for(let x=8;x<64;x+=9){g.beginPath();g.moveTo(x,-8.6);g.lineTo(x+1,-12.4);g.strokeStyle='#cfd6e0';g.lineWidth=1.6;g.stroke()}
  g.restore()}
 for(let x=-76;x<26;x+=10){g.beginPath();g.arc(x,42,1.2,0,TAU);g.fillStyle='#a8b0c0';g.fill()}
 // barnacle on the heel, seaweed bit on the toe
 od_barn(g,-60,57,9,6,Math.PI);od_barn(g,-74,-4,8,6,-1.5);
 od_weed(g,t,[88,-4,96,-14,110,-18,112,-30],2.6,2,fx);
 // drips
 if(!SIL){od_drip(g,t,90,40,26,.7,0);od_drip(g,t,-70,58,12,.6,.55);od_drip(g,t,-4,40,22,.75,.8);
  for(let i=0;i<3;i++){const k=od_tw(t,i*2,2.4);od_spark(g,[60,-70,10][i],[0,-22,-8][i],1.6+2.2*k,'#e8fbff',.35+.55*k)}
  if(gl>0)od_glow(g,0,0,110,'#c8f0ff',.2*gl)}
 g.restore()};

/* ---------- message in a green glass bottle ---------- */
FISHART.oddbottle=(g,t,o)=>{const fx=o.flex||0,gl=o.glow||0,SIL=o.sil===0;
 g.save();g.translate(2,2+Math.sin(t*1.6)*3.2);g.rotate(-.34+Math.sin(t*1.2)*.05+Math.sin(t*6)*fx*.05);
 if(!SIL)od_glow(g,0,0,100,'#9affc8',.08+gl*.2);
 // bottle outline: rounded base, body, shoulder, neck, lip
 const BO=()=>od_path(g,['M',-74,-30,'L',36,-30,'Q',52,-30,60,-14,'L',62,-11,'L',88,-11,'L',88,11,'L',62,11,'L',60,14,'Q',52,30,36,30,'L',-74,30,'Q',-88,30,-88,0,'Q',-88,-30,-74,-30,'Z']);
 // back glass
 BO();g.fillStyle=SIL?'#000':od_grad(g,0,-30,0,30,[[0,'rgba(90,200,130,.55)'],[.5,'rgba(40,140,90,.5)'],[1,'rgba(20,90,60,.7)']]);g.fill();
 // the rolled letter inside, tied with red string
 {const P=()=>od_path(g,['M',-58,-13,'L',18,-15,'Q',23,-15,23,-1,'Q',23,13,18,13,'L',-58,15,'Q',-63,15,-63,1,'Q',-63,-13,-58,-13,'Z']);
  P();od_fill(g,od_grad(g,0,-15,0,15,[[0,'#fff4d8'],[.45,'#f0dcae'],[1,'#c8a870']]),2);
  g.save();P();g.clip();g.strokeStyle='rgba(140,100,50,.35)';g.lineWidth=1;for(const y of [-6,0,6]){g.beginPath();g.moveTo(-60,y);g.lineTo(20,y-1);g.stroke()}g.restore();
  // rolled end (spiral)
  g.beginPath();g.ellipse(20,-1,4,14,0,0,TAU);od_fill(g,od_grad(g,16,0,24,0,[[0,'#e8d0a0'],[1,'#fff4d8']]),1.8);
  g.beginPath();g.ellipse(20,-1,2,7,0,0,TAU*.85);g.strokeStyle='rgba(140,100,50,.6)';g.lineWidth=1.1;g.stroke();
  // red string and bow
  g.beginPath();g.moveTo(-20,-15);g.lineTo(-21,15);g.moveTo(-15,-15);g.lineTo(-16,15);g.strokeStyle='#c8202a';g.lineWidth=2.2;g.stroke();
  for(const s of [-1,1]){g.beginPath();g.ellipse(-18+s*6,-17,6,3,s*.5,0,TAU);od_fill(g,'#e83a40',1.4)}
  g.beginPath();g.moveTo(-19,-16);g.quadraticCurveTo(-24,-6,-28,-4);g.moveTo(-17,-16);g.quadraticCurveTo(-12,-8,-10,-4);g.strokeStyle='#c8202a';g.lineWidth=2;g.stroke();
  g.beginPath();g.arc(-18,-16.5,2.2,0,TAU);od_fill(g,'#ff5a5a',1.2)}
 // a little seawater sloshing in the bottom
 g.save();BO();g.clip();{const lv=18,wv=Math.sin(t*2.2)*2.6;g.beginPath();g.moveTo(-90,lv-wv);g.quadraticCurveTo(-20,lv+wv*1.6,40,lv-wv*.4);g.quadraticCurveTo(60,lv-wv,70,lv);g.lineTo(70,40);g.lineTo(-90,40);g.closePath();
  g.fillStyle=SIL?'#000':'rgba(40,160,120,.45)';g.fill();g.strokeStyle='rgba(200,255,230,.6)';g.lineWidth=1.4;g.beginPath();g.moveTo(-86,lv-wv);g.quadraticCurveTo(-20,lv+wv*1.6,40,lv-wv*.4);g.stroke()}
 // glass front: tint, thick base, highlights
 g.fillStyle=od_grad(g,0,-30,0,30,[[0,'rgba(200,255,220,.18)'],[.5,'rgba(60,170,110,.12)'],[1,'rgba(10,60,40,.35)']]);g.fillRect(-90,-32,180,64);
 g.fillStyle=od_grad(g,-88,0,-74,0,[[0,'rgba(20,90,60,.55)'],[1,'rgba(20,90,60,0)']]);g.fillRect(-90,-32,18,64);
 g.restore();
 BO();g.lineWidth=3;g.strokeStyle=od_K;g.lineJoin='round';g.stroke();
 g.save();BO();g.clip();g.lineCap='round';
 g.beginPath();g.moveTo(-76,-22);g.lineTo(36,-22);g.quadraticCurveTo(48,-22,55,-12);g.strokeStyle='rgba(255,255,255,.75)';g.lineWidth=3.4;g.stroke();
 g.beginPath();g.moveTo(-60,-16);g.lineTo(-20,-16);g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=2;g.stroke();
 g.beginPath();g.moveTo(64,-6);g.lineTo(86,-6);g.strokeStyle='rgba(255,255,255,.6)';g.lineWidth=2;g.stroke();
 {const q=((t*.35)%1)*260-130;g.fillStyle=od_grad(g,q-16,-30,q+16,30,[[0,'rgba(255,255,255,0)'],[.5,'rgba(255,255,255,.4)'],[1,'rgba(255,255,255,0)']]);g.fillRect(-90,-32,180,64)}
 g.restore();
 // lip ring and cork
 g.beginPath();g.rect(84,-13,7,26);od_fill(g,od_grad(g,0,-13,0,13,[[0,'#a8f0c0'],[1,'#2a8a5a']]),2.4);
 od_path(g,['M',91,-10,'L',106,-9,'Q',110,-9,110,0,'Q',110,9,106,9,'L',91,10,'Z']);od_fill(g,od_grad(g,0,-10,0,10,[[0,'#e8b880'],[.5,'#c8905a'],[1,'#8a5a30']]),2.4);
 g.fillStyle='rgba(90,50,20,.55)';for(const d of [[96,-4],[101,3],[104,-5],[97,5]]){g.beginPath();g.arc(d[0],d[1],1,0,TAU);g.fill()}
 // barnacles
 od_barn(g,-40,30,11,8,Math.PI);od_barn(g,-28,31,7,5,Math.PI+.1);od_barn(g,10,-30,9,6,0);od_barn(g,-82,-18,8,6,-1.1);
 if(!SIL){const k=od_tw(t,0,2.2);od_spark(g,-48,-22,3+4*k+gl*3,'#ffffff',.6+.4*k);const k2=od_tw(t,2,2.8);od_spark(g,70,-8,2+3*k2,'#ffffff',.4+.5*k2);
  for(let i=0;i<4;i++){const s=((t*.3+i*.25)%1);g.beginPath();g.arc(-60+i*30+Math.sin(t+i)*4,34-s*18,1.4+s*1.6,0,TAU);g.strokeStyle=`rgba(220,255,240,${.7*(1-s)})`;g.lineWidth=1;g.stroke()}
  if(gl>0)od_glow(g,0,0,110,'#d8ffe8',.22*gl)}
 g.restore()};

/* ---------- small sunken treasure chest ---------- */
FISHART.oddchest=(g,t,o)=>{const fx=o.flex||0,gl=o.glow||0,SIL=o.sil===0,pu=.5+.5*Math.sin(t*2.1);
 g.save();g.translate(0,6+Math.sin(t*1.3)*1.2);g.rotate(Math.sin(t*6)*fx*.03);
 if(!SIL)od_glow(g,0,-16,90,'#ffd25a',.16+.08*pu+gl*.3);
 const W=80,top=-6,bot=54,lift=11+Math.sin(t*1.7)*1.6+fx*4;
 // interior back wall and the hoard heaped inside (seen through the open gap)
 od_poly(g,[-W+4,top,W-4,top,W-4,top-lift-18,-W+4,top-lift-18]);g.fillStyle='#2a140c';g.fill();
 if(!SIL){g.save();od_poly(g,[-W+4,top,W-4,top,W-4,top-lift-18,-W+4,top-lift-18]);g.clip();g.fillStyle=od_rgrad(g,0,top,4,70,[[0,`rgba(255,220,110,${.85+gl*.1})`],[.5,'rgba(255,170,60,.35)'],[1,'rgba(255,170,60,0)']]);g.fillRect(-W,top-40,W*2,44);g.restore()}
 const coin=(x,y,r,tilt)=>{g.beginPath();g.ellipse(x,y,r,r*(tilt||.55),0,0,TAU);od_fill(g,od_rgrad(g,x-r*.3,y-r*.3,1,r*1.1,[[0,'#fff6c0'],[.5,'#ffcf3a'],[1,'#b87a10']]),1.5);g.beginPath();g.ellipse(x,y,r*.6,r*.6*(tilt||.55),0,0,TAU);g.strokeStyle='rgba(150,90,10,.6)';g.lineWidth=.9;g.stroke()};
 [[-50,top-4,8],[-34,top-8,8],[-18,top-11,8],[2,top-13,8],[22,top-10,8],[40,top-7,8],[56,top-3,8],[-42,top-15,7],[-24,top-18,7],[30,top-17,7],[12,top-21,7],[-6,top-22,7.4]].forEach(c=>coin(c[0],c[1],c[2]));
 // a pearl strand and the big gem on top of the pile
 for(let i=0;i<7;i++){const x=34+i*5,y=top-14+Math.abs(i-3)*1.8;g.beginPath();g.arc(x,y,2.6,0,TAU);od_fill(g,od_rgrad(g,x-1,y-1,.3,3,[[0,'#ffffff'],[1,'#d8d0e8']]),1)}
 {const x=-30,y=top-24;od_poly(g,[x-9,y,x-5,y-6,x+5,y-6,x+9,y,x,y+10]);od_fill(g,od_grad(g,x-9,y-6,x+9,y+10,[[0,'#ff9ad0'],[.4,'#e8205a'],[1,'#7a0a3a']]),1.8);
  od_poly(g,[x-5,y-6,x+5,y-6,x+3,y,x-3,y]);g.fillStyle='rgba(255,220,240,.65)';g.fill();g.beginPath();g.moveTo(x-9,y);g.lineTo(x+9,y);g.moveTo(x-3,y);g.lineTo(x,y+10);g.lineTo(x+3,y);g.strokeStyle='rgba(120,0,40,.5)';g.lineWidth=.9;g.stroke();
  if(!SIL){const k=od_tw(t,1,2.6);od_glow(g,x,y,18,'#ff6aa8',.25+.2*k+gl*.2);od_spark(g,x+3,y-4,3+5*k+gl*2,'#ffffff',.6+.4*k)}}
 // lid (raised at the front, hinged at the back): a curved barrel top with iron bands
 {const ly=top-lift;g.save();g.translate(0,ly);g.rotate(-.02);
  const L=()=>od_path(g,['M',-W-4,4,'L',-W-4,-14,'Q',-W-2,-46,0,-48,'Q',W+2,-46,W+4,-14,'L',W+4,4,'Z']);
  L();od_fill(g,od_grad(g,0,-48,0,4,[[0,'#b07a44'],[.5,'#8a5a30'],[1,'#5a341a']]),3);
  g.save();L();g.clip();
  g.strokeStyle='rgba(40,20,8,.45)';g.lineWidth=1.4;for(const y of [-30,-16]){g.beginPath();g.moveTo(-W-4,y);g.quadraticCurveTo(0,y-6,W+4,y);g.stroke()}
  g.fillStyle='rgba(60,140,120,.22)';g.beginPath();g.ellipse(46,-30,22,10,0,0,TAU);g.fill();
  g.beginPath();g.moveTo(-70,-30);g.quadraticCurveTo(-40,-46,10,-46);g.strokeStyle='rgba(255,220,170,.35)';g.lineWidth=3;g.stroke();
  // underside of the lid catches the gold light
  if(!SIL){g.fillStyle=od_grad(g,0,4,0,-8,[[0,`rgba(255,210,100,${.55+gl*.2})`],[1,'rgba(255,210,100,0)']]);g.fillRect(-W-6,-8,W*2+12,14)}
  g.restore();
  for(const x of [-58,58]){g.save();L();g.clip();g.beginPath();g.rect(x-6,-60,12,66);od_fill(g,od_grad(g,x-6,0,x+6,0,[[0,'#3a3a4a'],[.5,'#8a8a9e'],[1,'#3a3a4a']]),2);g.restore();
   for(const y of [-28,-10])g.beginPath(),g.arc(x,y,1.6,0,TAU),g.fillStyle='#d8d8e8',g.fill()}
  L();g.lineWidth=3;g.strokeStyle=od_K;g.stroke();
  g.beginPath();g.rect(-W-4,-2,W*2+8,6);od_fill(g,od_grad(g,0,-2,0,4,[[0,'#9a9aae'],[1,'#3a3a4a']]),2);
  // hasp hanging from the lid
  od_path(g,['M',-7,2,'L',7,2,'L',6,16,'Q',0,20,-6,16,'Z']);od_fill(g,od_grad(g,-7,0,7,0,[[0,'#4a4a5a'],[.5,'#a8a8bc'],[1,'#4a4a5a']]),1.8);
  od_barn(g,-36,-44,10,7,-.2);od_barn(g,-24,-46,6,4,-.1);
  g.restore()}
 // chest body: planks, iron bands and corner brackets
 const B=()=>od_poly(g,[-W,top,W,top,W+2,bot,-W-2,bot]);
 B();od_fill(g,od_grad(g,0,top,0,bot,[[0,'#9a6838'],[.5,'#7a4a26'],[1,'#4a2a14']]),3);
 g.save();B();g.clip();g.strokeStyle='rgba(40,20,8,.5)';g.lineWidth=1.6;for(const y of [top+20,top+40]){g.beginPath();g.moveTo(-W-2,y);g.lineTo(W+2,y);g.stroke()}
 g.strokeStyle='rgba(40,20,8,.25)';g.lineWidth=1;for(let i=0;i<8;i++){const y=top+6+i*7;g.beginPath();g.moveTo(-W+4+(i*17)%30,y);g.quadraticCurveTo(-20,y+2,10+(i*23)%40,y);g.stroke()}
 g.fillStyle='rgba(60,140,120,.25)';g.beginPath();g.ellipse(-50,bot-6,30,10,0,0,TAU);g.fill();g.beginPath();g.ellipse(40,top+8,18,6,0,0,TAU);g.fill();
 g.fillStyle=od_grad(g,0,top,0,top+16,[[0,`rgba(255,210,100,${SIL?0:.45+gl*.2})`],[1,'rgba(255,210,100,0)']]);g.fillRect(-W,top,W*2,16);
 g.restore();
 for(const x of [-58,58]){od_poly(g,[x-6,top,x+6,top,x+6.4,bot,x-6.4,bot]);od_fill(g,od_grad(g,x-6,0,x+6,0,[[0,'#3a3a4a'],[.5,'#8a8a9e'],[1,'#3a3a4a']]),2);for(const y of [top+10,top+30,top+50])g.beginPath(),g.arc(x,y,1.6,0,TAU),g.fillStyle='#d8d8e8',g.fill()}
 for(const s of [-1,1]){od_poly(g,[s*W,top,s*(W-14),top,s*(W-14),top+5,s*(W-5),top+5,s*(W-5),top+14,s*W,top+14]);od_fill(g,'#6a6a7e',1.6);
  od_poly(g,[s*(W+2),bot,s*(W-14),bot,s*(W-14),bot-5,s*(W-4),bot-5,s*(W-3),bot-14,s*(W+1.6),bot-14]);od_fill(g,'#6a6a7e',1.6)}
 // padlock on the front plate (sprung open, hanging crooked)
 {const sw=Math.sin(t*1.9)*.12*(1+fx*2);g.beginPath();g.rect(-10,top+1,20,16);od_fill(g,od_grad(g,-10,0,10,0,[[0,'#4a4a5a'],[.5,'#a8a8bc'],[1,'#4a4a5a']]),1.8);
  g.save();g.translate(0,top+8);g.rotate(sw);
  g.beginPath();g.moveTo(-6,10);g.lineTo(-6,4);g.arc(0,4,6,Math.PI,TAU*.93);g.strokeStyle=od_K;g.lineWidth=5;g.stroke();g.strokeStyle='#c8c8d8';g.lineWidth=2.6;g.stroke();
  od_path(g,['M',-10,10,'L',10,10,'L',10,24,'Q',10,28,6,28,'L',-6,28,'Q',-10,28,-10,24,'Z']);od_fill(g,od_grad(g,-10,10,10,28,[[0,'#ffe07a'],[.5,'#e0a028'],[1,'#8a5a10']]),2.2);
  g.beginPath();g.arc(0,17,2.6,0,TAU);g.fillStyle='#2a1808';g.fill();od_poly(g,[-1.3,18,1.3,18,1.8,24,-1.8,24]);g.fill();
  g.beginPath();g.moveTo(-7,12.5);g.lineTo(-7,24);g.strokeStyle='rgba(255,255,255,.6)';g.lineWidth=1.2;g.stroke();g.restore()}
 // barnacles, seaweed, and coins spilled on the sea bed
 od_barn(g,-70,bot,12,8,Math.PI);od_barn(g,66,top+24,9,6,Math.PI/2);od_barn(g,74,bot,8,6,Math.PI);
 od_weed(g,t,[-78,top+2,-90,top+14,-96,top+30,-104,top+40],4,0,fx);
 [[-94,bot+2,7],[-84,bot+5,6.5],[90,bot+3,7],[100,bot+1,6],[84,bot-2,6]].forEach(c=>coin(c[0],c[1],c[2],.45));
 // twinkles over the gold
 if(!SIL){for(let i=0;i<6;i++){const k=od_tw(t,i*1.7,3.2);od_spark(g,[-48,-12,20,44,6,-30][i],[top-14,top-26,top-26,top-12,top-34,top-10][i]-lift*.3,1.8+4*k+gl*2,i%2?'#fff4c0':'#ffffff',.25+.7*k)}
  if(gl>0)od_glow(g,0,-10,115,'#fff0b0',.22*gl)}
 g.restore()};

/* ---------- lost gold ring with a big gem ---------- */
FISHART.oddring=(g,t,o)=>{const fx=o.flex||0,gl=o.glow||0,SIL=o.sil===0,pu=.5+.5*Math.sin(t*2);
 g.save();g.translate(0,4+Math.sin(t*1.5)*2.4);g.rotate(Math.sin(t*1.1)*.04+Math.sin(t*6)*fx*.05);
 const cy=20,RX=88,RY=44,rx=64,ry=28,gy=-36;
 if(!SIL){od_glow(g,0,gy,60,'#ff7ab8',.2+.1*pu+gl*.24);od_glow(g,0,cy,100,'#ffd27a',.1+gl*.16)}
 // the band: an ellipse ring seen from above-front; the far (top) half first, the near half after the gem
 const ring=(a0,a1)=>{g.beginPath();g.ellipse(0,cy,RX,RY,0,a0,a1);g.ellipse(0,cy+4,rx,ry,0,a1,a0,true);g.closePath()};
 const gold=od_grad(g,-RX,0,RX,0,[[0,'#a86a10'],[.18,'#ffd96a'],[.4,'#e8a628'],[.6,'#fff0b0'],[.8,'#d8921c'],[1,'#8a5208']]);
 // inner wall of the far side (we see inside the ring)
 g.beginPath();g.ellipse(0,cy+4,rx,ry,0,Math.PI,TAU);g.ellipse(0,cy+12,rx-4,ry-6,0,TAU,Math.PI,true);g.closePath();od_fill(g,od_grad(g,0,cy-ry,0,cy+10,[[0,'#8a5208'],[1,'#e8b048']]),2.2);
 g.beginPath();g.ellipse(0,cy,RX,RY,0,0,TAU);g.moveTo(rx,cy+4);g.ellipse(0,cy+4,rx,ry,0,TAU,0,true);od_fill(g,gold,3);
 // gem setting: a crown bezel with six claw prongs and two small side diamonds
 const dia=(x,y,r)=>{od_poly(g,[x-r,y,x-r*.55,y-r*.7,x+r*.55,y-r*.7,x+r,y,x,y+r*1.1]);od_fill(g,od_grad(g,x-r,y-r,x+r,y+r,[[0,'#ffffff'],[.5,'#cfe8ff'],[1,'#8aa8d8']]),1.6);
  g.beginPath();g.moveTo(x-r*.55,y-r*.7);g.lineTo(x,y);g.lineTo(x+r*.55,y-r*.7);g.moveTo(x-r,y);g.lineTo(x+r,y);g.strokeStyle='rgba(80,110,170,.5)';g.lineWidth=.8;g.stroke()};
 for(const s of [-1,1]){g.beginPath();g.ellipse(s*34,gy+20,9,7,0,0,TAU);od_fill(g,gold,2);dia(s*34,gy+17,7)}
 od_path(g,['M',-30,gy+26,'Q',-34,gy+8,-26,gy+4,'L',26,gy+4,'Q',34,gy+8,30,gy+26,'Q',0,gy+34,-30,gy+26,'Z']);od_fill(g,od_grad(g,0,gy+4,0,gy+30,[[0,'#fff0b0'],[.5,'#e8a628'],[1,'#8a5208']]),2.6);
 g.beginPath();g.moveTo(-26,gy+12);g.quadraticCurveTo(0,gy+20,26,gy+12);g.strokeStyle='rgba(120,70,10,.6)';g.lineWidth=1.2;g.stroke();
 // the big gem: an oval rose-ruby, cut with a table and crown facets
 {const x=0,y=gy-6,a=33,b=22;const O=[];for(let i=0;i<12;i++){const an=i/12*TAU;O.push([x+Math.cos(an)*a,y+Math.sin(an)*b])}
  const T=O.map(p=>[x+(p[0]-x)*.5,y-3+(p[1]-y)*.48]);
  g.beginPath();O.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.closePath();od_fill(g,SIL?'#000':od_rgrad(g,x-8,y-8,2,a*1.1,[[0,'#ffb0d8'],[.35,'#ff3a7a'],[.75,'#b8104a'],[1,'#5a0628']]),2.8);
  if(!SIL){for(let i=0;i<12;i++){const p=O[i],q=O[(i+1)%12],u=T[i],v=T[(i+1)%12];g.beginPath();g.moveTo(p[0],p[1]);g.lineTo(q[0],q[1]);g.lineTo(v[0],v[1]);g.lineTo(u[0],u[1]);g.closePath();
    const lit=Math.sin(i/12*TAU+t*.9);g.fillStyle=lit>0?`rgba(255,200,230,${.12+.3*lit})`:`rgba(60,0,30,${-.25*lit})`;g.fill()}
   g.beginPath();T.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.closePath();g.fillStyle=od_grad(g,x-a*.5,y-b*.5,x+a*.5,y+b*.5,[[0,'rgba(255,230,245,.75)'],[.5,'rgba(255,90,150,.35)'],[1,'rgba(255,200,230,.6)']]);g.fill();
   g.strokeStyle='rgba(255,220,240,.55)';g.lineWidth=.9;g.stroke();g.beginPath();for(let i=0;i<12;i++){g.moveTo(O[i][0],O[i][1]);g.lineTo(T[i][0],T[i][1])}g.stroke();
   g.beginPath();g.ellipse(x-12,y-9,7,3.4,-.4,0,TAU);g.fillStyle='rgba(255,255,255,.8)';g.fill()}
  // claw prongs over the rim
  for(const an of [.5,1.55,2.64,3.64,4.71,5.78]){const px=x+Math.cos(an)*a,py=y+Math.sin(an)*b;g.save();g.translate(px,py);g.rotate(an+Math.PI/2);od_path(g,['M',-3.4,3,'Q',-3.6,-5,0,-6.4,'Q',3.6,-5,3.4,3,'Z']);od_fill(g,od_grad(g,-3,0,3,0,[[0,'#b87a18'],[.5,'#fff0b0'],[1,'#b87a18']]),1.6);g.restore()}}
 // the near half of the band, with engraving and a travelling glint
 ring(0,Math.PI);g.fillStyle=gold;g.fill();g.lineWidth=3;g.strokeStyle=od_K;g.beginPath();g.ellipse(0,cy,RX,RY,0,0,Math.PI);g.stroke();g.beginPath();g.ellipse(0,cy+4,rx,ry,0,0,Math.PI);g.stroke();
 g.save();ring(0,Math.PI);g.clip();
 // engraved waves along the band
 g.strokeStyle='rgba(120,70,10,.55)';g.lineWidth=1.2;g.beginPath();for(let i=0;i<=48;i++){const an=i/48*Math.PI,r=.5+.06*Math.sin(i*1.6),ex=Math.cos(an)*(rx+(RX-rx)*r),ey=cy+2+Math.sin(an)*(ry+(RY-ry)*r);i?g.lineTo(ex,ey):g.moveTo(ex,ey)}g.stroke();
 g.fillStyle='rgba(120,70,10,.5)';for(let i=1;i<12;i++){const an=i/12*Math.PI;for(const r of [.22,.8]){g.beginPath();g.arc(Math.cos(an)*(rx+(RX-rx)*r),cy+2+Math.sin(an)*(ry+(RY-ry)*r),1.1,0,TAU);g.fill()}}
 g.beginPath();g.ellipse(0,cy,RX-4,RY-3,0,.35,2.6);g.strokeStyle='rgba(255,255,255,.6)';g.lineWidth=2.6;g.stroke();
 if(!SIL){const an=((t*.35)%1)*Math.PI*1.6-.3,gx=Math.cos(an)*(RX-10),gy2=cy+Math.sin(an)*(RY-7);g.fillStyle=od_rgrad(g,gx,gy2,0,22,[[0,'rgba(255,255,240,.8)'],[1,'rgba(255,255,240,0)']]);g.fillRect(gx-22,gy2-22,44,44)}
 g.restore();
 g.save();ring(Math.PI,TAU);g.clip();g.beginPath();g.ellipse(0,cy,RX-4,RY-3,0,Math.PI*1.15,Math.PI*1.6);g.strokeStyle='rgba(255,255,255,.55)';g.lineWidth=2.2;g.stroke();g.restore();
 // sparkle and shine
 if(!SIL){const k=od_tw(t,0,2.2),k2=od_tw(t,2.5,2.9);od_spark(g,-12,gy-15,4+8*k+gl*4,'#ffffff',.6+.4*k);od_spark(g,22,gy-2,2+4*k2,'#ffe8f4',.4+.5*k2);
  for(let i=0;i<4;i++){const kk=od_tw(t,i*1.9+1,2.5);od_spark(g,[-78,82,-60,56][i],[cy-20,cy+10,cy+40,cy+44][i],1.6+3*kk+gl*2,'#fff6d0',.3+.6*kk)}
  if(gl>0)od_glow(g,0,0,115,'#fff0c8',.22*gl)}
 g.restore()};

/* ---------- the torn parchment page behind the bottle-letter reader (no text: the text is HTML) ---------- */
function od_rng(s){return ()=>{s|=0;s=s+0x6D2B79F5|0;let r=Math.imul(s^s>>>15,1|s);r=r+Math.imul(r^r>>>7,61|r)^r;return((r^r>>>14)>>>0)/4294967296}}
function odPageArt(g,w,h,t){const R=od_rng(73),m=Math.max(6,Math.min(w,h)*.035),pts=[];
 // a torn outline: rough deckled edges, a big rip out of the bottom-right corner
 const edge=(x0,y0,x1,y1,n,amp,nx,ny)=>{for(let i=0;i<n;i++){const s=i/n,j=(R()-.5)*amp+(i%3===0?(R()-.3)*amp*1.4:0);pts.push([x0+(x1-x0)*s+nx*j,y0+(y1-y0)*s+ny*j])}};
 const n1=Math.max(10,Math.round(w/18)),n2=Math.max(8,Math.round(h/18));
 edge(m,m,w-m,m,n1,m*.9,0,1);edge(w-m,m,w-m,h*.72,Math.round(n2*.72),m*.6,-1,0);
 pts.push([w-m-m*.4,h*.74],[w-m*3.4,h*.8],[w*.86,h-m*2.6],[w*.8,h-m*1.2]);
 edge(w*.78,h-m,m,h-m,Math.round(n1*.78),m*1.1,0,-1);edge(m,h-m,m,m,n2,m*.6,1,0);
 const P=()=>{g.beginPath();pts.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.closePath()};
 g.save();g.lineJoin='round';
 // soft drop shadow (offset copies, no blur)
 for(const s of [[7,9,.18],[4,5,.22]]){g.save();g.translate(s[0],s[1]);P();g.fillStyle=`rgba(10,4,24,${s[2]})`;g.fill();g.restore()}
 P();g.fillStyle=od_grad(g,0,0,w*.3,h,[[0,'#f6e7c4'],[.5,'#efdcae'],[1,'#e2c890']]);g.fill();
 g.save();P();g.clip();
 // aged vignette and scorched edges
 g.fillStyle=od_rgrad(g,w*.48,h*.45,Math.min(w,h)*.2,Math.max(w,h)*.72,[[0,'rgba(255,248,225,.35)'],[.6,'rgba(190,140,70,0)'],[1,'rgba(120,70,20,.45)']]);g.fillRect(0,0,w,h);
 P();g.strokeStyle='rgba(110,60,20,.35)';g.lineWidth=m*1.6;g.stroke();P();g.strokeStyle='rgba(80,40,10,.5)';g.lineWidth=m*.45;g.stroke();
 // fold creases (a light and a dark line each)
 for(const c of [[w*.5,0,w*.5+m*.6,h],[0,h*.5,w,h*.5-m*.4]]){g.beginPath();g.moveTo(c[0],c[1]);g.lineTo(c[2],c[3]);g.strokeStyle='rgba(140,95,40,.22)';g.lineWidth=2;g.stroke();g.beginPath();g.moveTo(c[0]+1.5,c[1]+1.5);g.lineTo(c[2]+1.5,c[3]+1.5);g.strokeStyle='rgba(255,252,235,.5)';g.lineWidth=1.4;g.stroke()}
 // sea-water stains: rings and a soft blot
 for(const s of [[w*.78,h*.22,Math.min(w,h)*.13],[w*.2,h*.78,Math.min(w,h)*.09]]){g.beginPath();g.ellipse(s[0],s[1],s[2],s[2]*.82,.3,0,TAU);g.strokeStyle='rgba(150,100,40,.28)';g.lineWidth=2.4;g.stroke();
  g.fillStyle=od_rgrad(g,s[0],s[1],0,s[2],[[0,'rgba(170,120,60,.05)'],[.85,'rgba(170,120,60,.14)'],[1,'rgba(170,120,60,0)']]);g.fill()}
 g.fillStyle=od_rgrad(g,w*.12,h*.18,0,Math.min(w,h)*.16,[[0,'rgba(120,150,110,.18)'],[1,'rgba(120,150,110,0)']]);g.fillRect(0,0,w*.4,h*.5);
 // a faint compass rose watermark in the corner
 {const cx=w-m*5.5,cy=h*.6,r=Math.min(w,h)*.12;g.save();g.translate(cx,cy);g.globalAlpha=.12;g.fillStyle='#6a4018';g.strokeStyle='#6a4018';g.lineWidth=1.2;g.beginPath();g.arc(0,0,r,0,TAU);g.stroke();g.beginPath();g.arc(0,0,r*.8,0,TAU);g.stroke();
  for(let i=0;i<8;i++){const a=i*Math.PI/4,L=i%2?r*.55:r;g.beginPath();g.moveTo(Math.cos(a)*L,Math.sin(a)*L);g.lineTo(Math.cos(a+.25)*r*.16,Math.sin(a+.25)*r*.16);g.lineTo(Math.cos(a-.25)*r*.16,Math.sin(a-.25)*r*.16);g.closePath();g.fill()}g.restore()}
 // speckles of age
 for(let i=0;i<70;i++){const x=R()*w,y=R()*h,r=R()*1.6+.3;g.fillStyle=`rgba(110,70,30,${.08+R()*.18})`;g.beginPath();g.arc(x,y,r,0,TAU);g.fill()}
 g.restore();
 P();g.strokeStyle='rgba(90,50,20,.75)';g.lineWidth=1.4;g.stroke();
 g.restore()}
