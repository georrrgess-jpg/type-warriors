# Update 8.7 menu behaviour fixes (module 94c_fix_menus.js): B7 badges refreshed in place, B8 Settings scroll, B9 bell (Esc, focus, count, Clear,
# fresh saves), B10 corner buttons, B11 pet timers, B12 empty stats, B13 Performance mode pose, B14 used codes survive a reset, D6 Reset save in
# Settings > Data. Run from the source folder against out.html. Nothing waits for real time except short settles after clicks.
import asyncio,os,sys
from playwright.async_api import async_playwright
OVL=open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'t_riddle_ovl.js')).read()
HTML=sys.argv[1] if len(sys.argv)>1 else 'out.html'
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append('PE '+str(e)[:300]));pg.on('console',lambda m:er.append('CE '+m.text[:200]) if m.type=='error' and 'ERR_' not in m.text else None)
        await pg.goto('file://'+os.path.abspath(HTML));await pg.wait_for_timeout(1200);E=pg.evaluate;bad=0
        def chk(name,r,ok):
            nonlocal bad;bad+=not ok;print(name,r,'OK' if ok else 'BAD')
        fr=lambda n=3:E("async(n)=>{for(let i=0;i<n;i++)await new Promise(r=>requestAnimationFrame(r));await new Promise(r=>setTimeout(r,40))}",n)
        BASE="()=>{RS_ASK=false;load({});P.gold=5000;P.camp=6;for(let i=1;i<=5;i++)P.stars[i]=3;P.pet='';P.petSt=2;save()}"
        await E(BASE);await E("()=>{"+OVL+"}")
        BDG="(sel)=>{const e=document.querySelector(sel);const b=e&&e.querySelector(':scope>.bdg');return b?b.textContent:''}"

        # ---------------- B7: badges refreshed in place ----------------
        await E("()=>{P.crates=0;P.acr=0;P.scr=0;P.pcr=0;P.hcr=0;P.ccr=0;P.gold=50000;save();shop()}");await pg.wait_for_timeout(700)
        g=lambda sel:E("(a)=>{const [f,s]=a;return eval(f)(s)}",[BDG,sel])
        r=[await g('#dk_sh'),await g('.dkst[data-dks="cr"]')]
        chk('shop: no crate badges at the start',r,r==['',''])
        await E("()=>{window.__dk=document.querySelector('.dk');window.__sub=document.querySelector('.dksub');window.__rows=ov.querySelectorAll('.dkrow').length}")
        await pg.click('#shbuy');await fr()
        r=[await g('#dk_sh'),await g('.dkst[data-dks="cr"]'),await E("()=>[P.crates+P.acr+P.scr+P.pcr+P.hcr+P.ccr,window.__dk===document.querySelector('.dk'),window.__sub===document.querySelector('.dksub'),ov.querySelectorAll('.dkrow').length===window.__rows]")]
        chk('buy a crate: dock Shop badge and Owned-crates sub-tab badge update at once; the dock itself is not re-rendered',r,r[0]=='1' and r[1]=='1' and r[2]==[1,True,True,True])
        await pg.click('#shbuy');await fr()
        r=[await g('#dk_sh'),await g('.dkst[data-dks="cr"]')]
        chk('second crate: both badges say 2',r,r==['2','2'])
        r=await E("()=>new Promise(res=>{let n=0;const o=mfxBadgesNow;mfxBadgesNow=function(){n++;return o.apply(this,arguments)};for(let i=0;i<12;i++){dkRefreshBadges();save()}requestAnimationFrame(()=>requestAnimationFrame(()=>setTimeout(()=>{mfxBadgesNow=o;res(n)},250)))})")
        chk('debounce: 24 requests in one tick refresh once',r,r==1)
        await E("()=>{P.crates=0;P.acr=0;P.scr=0;P.pcr=0;P.hcr=0;P.ccr=0;save()}");await fr()
        r=[await g('#dk_sh'),await g('.dkst[data-dks="cr"]')]
        chk('crates gone: badges removed',r,r==['',''])
        # Gear badge and the bell follow a save made elsewhere
        await E("()=>{armory()}");await pg.wait_for_timeout(600)
        a0=await E("()=>[+((document.querySelector('#bell>.bdg')||{}).textContent||0),!!document.querySelector('#dk_gr>.bdg')]")
        await E("()=>{P.xp=lvx(7);save()}");await fr()
        a1=await E("()=>[+((document.querySelector('#bell>.bdg')||{}).textContent||0),(document.querySelector('#dk_gr>.bdg')||{}).textContent,newPaths().length,dkAlerts().some(a=>a[0]==='np2')]")
        chk('new path unlocked: Gear badge "!" and the bell count goes up by one',[a0,a1],a0[1]==False and a1[1]=='!' and a1[0]==a0[0]+1 and a1[3])
        await E("()=>{P.seen.archer=1;P.seen.mage=1;save()}");await fr()
        r=await E("()=>[(document.querySelector('#dk_gr>.bdg')||{}).textContent||'',+((document.querySelector('#bell>.bdg')||{}).textContent||0),dkAlerts().length+updUnread(),dkAlerts().some(a=>a[0]==='np2'),String(spNote()||'')]")
        chk('path seen: Gear badge shows only the skill points now, the "new path" alert is gone and the bell count equals alerts + unread',r,r[0]==r[4] and r[1]==r[2] and r[3]==False)
        # skill points on the Skill Tree sub-tab
        r=await E("()=>{P.us=0;P.spb=0;save();return [spNote(),spLeft()]}");await fr()
        s1=await g('.dkst[data-dks="ut"]');dk=await E("()=>String(spNote()||'')")
        chk('skill points: Skill Tree sub-tab badge equals spNote()',[r,s1,dk],s1==dk and r[0]>0)
        await E("()=>{P.us=spTotal();save()}");await fr()
        s2=await g('.dkst[data-dks="ut"]')
        chk('points spent: badge gone',s2,s2=='')
        # bounties sub-tab and the Progress dock badge
        await E("()=>{bountyBoard()}");await pg.wait_for_timeout(600)
        await E("()=>{const B=BTY();B.c.forEach(c=>{c.ok=0;c.cl=0});save()}");await fr()
        q0=[await g('.dkst[data-dks="bb"]'),await g('#dk_pg')]
        await E("()=>{const B=BTY();B.c[0].ok=1;B.c[0].cl=0;save()}");await fr()
        q1=[await g('.dkst[data-dks="bb"]'),await g('#dk_pg')]
        chk('bounty ready: sub-tab and Progress badges show 1',[q0,q1],q0==['',''] and q1==['1','1'])
        # calendar "!"
        await E("()=>{title()}");await pg.wait_for_timeout(600)
        await E("()=>{const i=calInfo();delete P.cal.c[i.td];save()}");await fr()
        c0=await g('#dkcal')
        await E("()=>{const i=calInfo();P.cal.c[i.td]=1;save()}");await fr()
        c1=await g('#dkcal')
        chk('calendar "!" follows claiming',[c0,c1],c0=='!' and c1=='')
        # bell: count refreshes after the updates are read
        await E("()=>{UPD().seen=[];save()}");await fr()
        n0=await E("()=>[+((document.querySelector('#bell>.bdg')||{}).textContent||0),updUnread(),dkAlerts().length,document.getElementById('bell').getAttribute('aria-label')]")
        chk('12 unread updates are counted on the bell',n0,n0[0]==n0[1]+n0[2] and n0[1]>=10)
        await pg.click('#bell');await pg.wait_for_timeout(300);await pg.click('[data-bt="u"]');await fr()
        n1=await E("()=>[+((document.querySelector('#bell>.bdg')||{}).textContent||0),updUnread(),dkAlerts().length,document.getElementById('bell').getAttribute('aria-label'),!!document.querySelector('[data-bt=u]>i')]")
        chk('after the Updates tab is opened the bell count drops and the label follows',n1,n1[1]==0 and n1[0]==n1[2] and n1[3]==('Notifications'+(' (%d new)'%n1[2] if n1[2] else '')) and n1[4]==False)
        await pg.keyboard.press('Escape');await fr()
        # the bell opens straight on Updates when there are no alerts: showing them counts as reading them
        await E("()=>{window.__uf=updFilter;updFilter=a=>[];UPD().seen=[];save();title()}");await pg.wait_for_timeout(600)
        u0=await E("()=>[BELL_TAB,updUnread(),+((document.querySelector('#bell>.bdg')||{}).textContent||0)]")
        await pg.click('#bell');await pg.wait_for_timeout(500)
        u1=await E("()=>[updUnread(),(document.querySelector('#bell>.bdg')||{}).textContent||'',document.querySelectorAll('.blu.new').length,document.getElementById('bell').getAttribute('aria-label')]")
        chk('the bell opened on Updates reads them: the count goes to 0 while the new ones stay highlighted for this visit',[u0,u1],u0[0]=='u' and u0[1]>=10 and u0[2]==u0[1] and u1[0]==0 and u1[1]=='' and u1[2]>=10 and u1[3]=='Notifications')
        await pg.keyboard.press('Escape');await fr()
        await E("()=>{updFilter=window.__uf;UPD().dis={};title()}");await pg.wait_for_timeout(400)

        # ---------------- B9: bell keyboard behaviour ----------------
        await E("()=>{armory()}");await pg.wait_for_timeout(600)
        await pg.click('#bell');await pg.wait_for_timeout(500)
        r=await E("()=>[$('bellp').classList.contains('open'),$('bellp').contains(document.activeElement),(document.activeElement.className||'')]")
        chk('click opens the bell and focus moves into the popover',r,r[0] and r[1])
        await pg.keyboard.press('Escape');await fr()
        r=await E("()=>[$('bellp').classList.contains('open'),document.activeElement.id,$('bell').getAttribute('aria-expanded'),(document.querySelector('#ov h2')||{}).textContent]")
        chk('Esc closes the bell, focus returns to it and the screen stays on the Armory',r,r[0]==False and r[1]=='bell' and r[2]=='false' and r[3].strip()=='Armory')
        await pg.keyboard.press('Escape');await pg.wait_for_timeout(500)
        r=await E("()=>[S.mode,!!document.querySelector('.dkh'),!!document.querySelector('.armory,.ar2')]")
        chk('a second Esc goes back to the hub as before',r,r[1]==True)
        await E("()=>{armory()}");await pg.wait_for_timeout(500)
        await E("()=>$('bell').focus()");await pg.keyboard.press('Enter');await pg.wait_for_timeout(500)
        r=await E("()=>[$('bellp').classList.contains('open'),$('bellp').contains(document.activeElement)]")
        chk('keyboard (Enter on the bell) opens it and moves focus in',r,r==[True,True])
        await pg.keyboard.press('Tab');await pg.keyboard.press('Escape');await fr()
        r=await E("()=>[$('bellp').classList.contains('open'),document.activeElement.id]")
        chk('Esc works from any control inside the popover',r,r==[False,'bell'])
        # Clear: the riddle alert used to come straight back
        await E("()=>{load({});P.gold=5000;UPD().seen=[];save();title()}");await pg.wait_for_timeout(600)
        ids0=await E("()=>dkAlerts().map(a=>a[0]).join(',')")
        await pg.click('#bell');await pg.wait_for_timeout(300);await pg.click('#blclr');await fr()
        r=await E("()=>[(document.querySelector('#bell>.bdg')||{}).textContent||'',updUnread(),dkAlerts().length,BELL_AL.length,$('blclr').disabled,document.querySelector('.blbody').textContent.slice(0,40)]")
        chk('Clear leaves nothing (the Riddle alert stays cleared for today)',[ids0,r],'dgc' in ids0 and r[0]=='' and r[1]==0 and r[2]==0 and r[3]==0 and r[4]==True and 'caught up' in r[5])
        await E("()=>{title()}");await pg.wait_for_timeout(600)
        r=await E("()=>[(document.querySelector('#bell>.bdg')||{}).textContent||'',dkAlerts().length]")
        chk('re-rendering the hub still shows no count',r,r==['',0])
        await E("()=>{UPD().dis={};title()}");await pg.wait_for_timeout(600)
        r=await E("()=>dkAlerts().map(a=>a[0]).join(',')")
        chk('the dismissal is per day: a new day brings the alerts back',r,'dgc' in r)
        # honest text when something cannot be cleared
        await E("()=>{window.__uf=updFilter;updFilter=a=>a;title()}");await pg.wait_for_timeout(600)
        await pg.click('#bell');await pg.wait_for_timeout(300);await pg.click('#blclr');await fr()
        r=await E("()=>[(document.querySelector('#bell>.bdg')||{}).textContent||'',BELL_AL.length,(document.querySelector('.blbody .blm')||{}).textContent||'',document.querySelectorAll('.belr').length]")
        chk('if something cannot be cleared the popover says how many actions are left and the badge agrees',r,r[1]>0 and r[0]==str(r[1]) and ('%d action'%r[1]) in r[2] and r[3]==r[1])
        await E("()=>{updFilter=window.__uf;UPD().dis={};title()}");await pg.wait_for_timeout(500)
        # fresh saves start with the old updates read
        r=await E("()=>{const n=UPDATES.length;load({});const a=[updUnread(),P.upd.seen.length>=n,updAll().length];load({upd:{seen:['zz'],mine:[],feed:[],dis:{}}});const b=[P.upd.seen.join(','),updUnread()];load({runs:5,xp:900,stars:{1:3}});const c=[updUnread(),!P.upd||!P.upd.seen||P.upd.seen.length===0];load({});return [n,a,b,c]}")
        chk('a brand-new save has no unread updates; a save with a read list or with progress is left alone',r,r[1][0]==0 and r[1][1] and r[2][0]=='zz' and r[2][1]>=10 and r[3][0]>=10 and r[3][1])

        # ---------------- B8: Settings keeps its scroll ----------------
        # real mouse clicks at the button's current position (a locator click would scroll the page to the button first)
        async def mclick(pg_,sel):
            bb=await pg_.evaluate("(s)=>{const r=document.querySelector(s).getBoundingClientRect();return [r.left+r.width/2,r.top+r.height/2,r.top>0&&r.bottom<innerHeight]}",sel)
            await pg_.mouse.click(bb[0],bb[1]);return bb[2]
        for (vw,vh) in [(1600,900),(390,844)]:
            pg2=await b.new_page(viewport={'width':vw,'height':vh});pg2.on('pageerror',lambda e:er.append('PE2 '+str(e)[:300]))
            await pg2.goto('file://'+os.path.abspath(HTML));await pg2.wait_for_timeout(1000);E2=pg2.evaluate
            await E2("()=>{RS_ASK=false;load({});save();ST.touch='auto';settings.tab='Display';settings(title)}");await pg2.wait_for_timeout(700)
            for phase in ('normal','touch layout'):
                if phase=='touch layout':
                    await E2("()=>{ST.touch='on';saveST();applyLayout();settings(title)}");await pg2.wait_for_timeout(900)
                tall=await E2("()=>[ov.scrollHeight,ov.clientHeight]")
                res=[]
                for k,v in [('fps','true'),('perf','bal'),('tvis','on'),('fps','false'),('perf','high'),('tvis','off')]:
                    await E2("()=>{ov.scrollTop=ov.scrollHeight}");await pg2.wait_for_timeout(150)
                    before=await E2("()=>ov.scrollTop");vis=await mclick(pg2,f'[data-k="{k}"][data-v="{v}"]');await pg2.wait_for_timeout(700)
                    after=await E2("(a)=>[ov.scrollTop,document.activeElement.dataset&&document.activeElement.dataset.k,document.activeElement.dataset&&document.activeElement.dataset.v,String(ST[a[0]]),Math.max(0,ov.scrollHeight-ov.clientHeight)]",[k,v])
                    # the position may only change when the new page is shorter than the old one (some descriptions are longer than others)
                    res.append((k,v,before,after[0],vis and before>0 and abs(after[0]-min(before,after[4]))<=.5 and after[1]==k and after[2]==v and after[3]==v))
                if tall[0]<=tall[1]:print('settings %dx%d (%s): the page does not scroll here, nothing to keep (n/a)'%(vw,vh,phase));continue
                chk(f'settings {vw}x{vh} ({phase}, scroll range {tall[0]-tall[1]}px): each option click keeps scrollTop and focus and is applied',res,all(x[4] for x in res))
            await pg2.close()

        # Settings opened from another screen that also has an options list starts at the top
        await E("()=>{load({});save();pracMenu(title)}");await pg.wait_for_timeout(700)
        sc=await E("()=>{ov.scrollTop=ov.scrollHeight;return ov.scrollTop}")
        await E("()=>{settings.tab='Display';settings(title)}");await pg.wait_for_timeout(600)
        r=await E("()=>[ov.scrollTop,(document.querySelector('#ov h2')||{}).textContent]")
        chk('Settings opened from the Practice Range does not inherit its scroll position',[sc,r],r[0]==0 and r[1].strip()=='Settings')

        # ---------------- B10: corner buttons ----------------
        CN="()=>{const c=document.getElementById('cn');const r=c.getBoundingClientRect();return [getComputedStyle(c).display,Math.round(r.width),S.mode,S.view]}"
        async def cn(js,wait=600):
            await E("()=>{try{if(typeof CAS!=='undefined'&&CAS.on)casinoBack()}catch(e){}S.mode='title';title()}");await pg.wait_for_timeout(350)
            await E("async()=>{const sl=ms=>new Promise(r=>setTimeout(r,ms));"+js+"}");await pg.wait_for_timeout(wait)
            return await E(CN)
        await E("()=>{load({});P.gold=5000;P.camp=6;for(let i=1;i<=5;i++)P.stars[i]=3;save()}")
        scr={'campaign':"campaign(cmCur())",'calendar':"dailyMenu(title)",'casino lobby':"casinoOpen()",'trick-or-treat menu':"ttMenu()",'trick-or-treat shop':"ttShop()",'endless menu':"endlessMenu(title)",'practice':"pracMenu(title)",'riddle menu':"dcMenu(title)",'profile':"profile()",'settings':"settings(title)",'help':"help(title)",'menu background':"hbgPick(title)",'save center':"saveCenter(title)",'armory':"armory()",'shop':"shop()",'bounties':"bountyBoard()"}
        allhid=True;rows=[]
        for k,js in scr.items():
            r=await cn(js);rows.append((k,r[0],r[1]));allhid=allhid and r[0]=='none'
        chk('corner buttons are hidden on every menu screen',rows,allhid)
        r=await cn("campaign(cmCur())")
        pan=await E("()=>{const s=document.querySelector('.cmside,.cmp,#cmp,#cm .side');return s?s.className:null}")
        chk('campaign map: the corner buttons are gone (no 0-width box over the right panel)',[r,pan],r[0]=='none' and r[1]==0)
        r=await cn("start(1);await sl(500)",300)
        r2=await cn("start(1);await sl(500);pause()",400)
        r3=await cn("start(1);await sl(500);over(true)",1000)
        chk('gameplay, pause and game over keep the corner buttons',[r,r2,r3],r[0]=='flex' and r2[0]=='flex' and r3[0]=='flex' and r2[2]=='pause' and r3[2]=='over')
        await E("()=>{S.mode='title';title()}")
        await cn("casinoOpen();await sl(400);gameOpen('bj')",700)
        r=await E("()=>{const v=id=>getComputedStyle(document.getElementById(id)).display;return [v('cn'),v('cz'),v('mt'),v('fs'),CAS.on,ov.className]}")
        chk('casino table: Music and Fullscreen stay, the Casino button is gone',r,r[0]=='flex' and r[1]=='none' and r[2]!='none' and r[3]!='none' and r[4])
        await E("()=>{casinoBack()}");await pg.wait_for_timeout(500)
        await E("()=>{title()}");await pg.wait_for_timeout(500);await pg.click('#dk_mo');await pg.wait_for_timeout(500)
        r=await E("()=>[!!$('mmu'),!!$('mfs'),!!$('mcz')]")
        chk('Music, Fullscreen and Casino stay reachable from More',r,r==[True,True,True])
        await pg.keyboard.press('Escape');await pg.wait_for_timeout(300)

        # ---------------- B12: empty stats ----------------
        await E("()=>{load({});P.rb=null;P.bestWave=0;P.gyb={};P.pres=0;save();profile.tab='Overview';profile()}");await pg.wait_for_timeout(700)
        r=await E("()=>{const t=[...document.querySelectorAll('.stt>div')].find(d=>/Rift best/.test(d.textContent));const n=t&&t.querySelector('.nrec');const pl=document.querySelector('.pres .pl');const pn=pl&&pl.querySelector('.nrec');const f=e=>e?getComputedStyle(e).fontFamily:'';return [n&&n.textContent,f(n),pn&&pn.textContent,f(pn),/none/i.test(document.querySelector('.stt').textContent),/none/i.test(pl.textContent)]}")
        chk('Profile: Rift best and Prestige show plain text in Poppins',r,r[0]=='No record yet' and 'Poppins' in r[1] and 'Pirata' not in r[1] and r[2]=='No prestige yet' and 'Poppins' in r[3] and r[4]==False and r[5]==False)
        await E("()=>{endlessMenu(title)}");await pg.wait_for_timeout(700)
        r=await E("()=>{const n=document.querySelector('.ems .nrec');return [n&&n.textContent,n?getComputedStyle(n).fontFamily:'',/none/i.test(document.querySelector('.ems').textContent)]}")
        chk('Endless menu: Best round shows "No record yet" in Poppins',r,r[0]=='No record yet' and 'Poppins' in r[1] and r[2]==False)
        await E("()=>{gyMenu(title)}");await pg.wait_for_timeout(700)
        r=await E("()=>{const n=document.querySelector('.gyr .nrec');return [n&&n.textContent,n?getComputedStyle(n).fontFamily:'',/none/i.test(document.querySelector('.gyr').textContent)]}")
        chk('Monster Mash menu: deepest level shows "No record yet" in Poppins',r,r[0]=='No record yet' and 'Poppins' in r[1] and r[2]==False)
        await E("()=>{P.rb={s:1234};P.bestWave=7;P.gyb={lv:4,best:10};P.pres=1;save();profile()}");await pg.wait_for_timeout(600)
        r=await E("()=>[document.querySelectorAll('.stt .nrec').length,document.querySelector('.pres .pl').textContent.slice(0,30)]")
        chk('with records the numbers are shown as before',r,r[0]==0 and 'Prestige' in r[1])
        await E("()=>{P.pres=0;P.rb=null;P.bestWave=0;P.gyb={};save()}")

        # ---------------- D6: Reset save moved to Settings > Data ----------------
        await E("()=>{load({});P.gold=777;P.runs=9;P.xp=500;save();profile.tab='Overview';profile()}");await pg.wait_for_timeout(700)
        r=await E("()=>[!!$('rs'),[...document.querySelectorAll('.pfhead button')].map(b=>b.textContent),[...document.querySelectorAll('#ov button')].some(b=>/reset save/i.test(b.textContent))]")
        chk('Profile header no longer has Reset save',r,r[0]==False and r[2]==False and 'Skill tree' in r[1])
        await E("()=>{settings.tab='Data';settings(title)}");await pg.wait_for_timeout(700)
        r=await E("()=>{const b=document.getElementById('mfxrsb');const o=b&&b.closest('.opt');return [!!b,b&&b.textContent,o&&o.style.display,b&&b.disabled,b&&b.className,[...document.querySelectorAll('.opts>.opt')].filter(o=>o.style.display!=='none').map(o=>o.querySelector('label').textContent)]}")
        chk('Settings > Data has a red Reset save button',r,r[0] and r[1]=='Reset save' and r[2]=='' and r[3]==False and 'dg' in r[4] and 'Reset save' in r[5])
        r=await E("()=>{settings.tab='Display';settings(title);const o=document.getElementById('mfxrs');return [o&&o.style.display]}")
        chk('...and the other tabs hide it',r,r[0]=='none')
        await E("()=>{settings.tab='Data';settings(title)}");await pg.wait_for_timeout(600)
        await pg.click('#mfxrsb');await pg.wait_for_timeout(200)
        r=await E("()=>[document.getElementById('mfxrsb').textContent,P.gold,P.runs]")
        chk('first click only asks again',r,r[0].startswith('Click again') and r[1]==777 and r[2]==9)
        await pg.wait_for_timeout(3200)
        r=await E("()=>document.getElementById('mfxrsb').textContent")
        chk('...and the question times out',r,r=='Reset save')
        await pg.click('#mfxrsb');await pg.click('#mfxrsb');await pg.wait_for_timeout(900)
        r=await E("()=>[P.gold,P.runs,P.xp,P.name,S.mode,!!document.querySelector('.dkh'),sgList().some(x=>x.why==='Before erase')]")
        chk('second click erases the save, keeps a backup and goes to the hub',r,r[0]==0 and r[1]==0 and r[2]==0 and r[4]=='title' and r[5] and r[6])
        r=await E("()=>[updUnread(),dkAlerts().length]")
        chk('after a reset the old updates are not shown as unread',r,r[0]==0)
        # not offered in the middle of a run
        await E("()=>{start(1)}");await pg.wait_for_timeout(500);await E("()=>pause()");await pg.wait_for_timeout(400)
        await pg.click('#st');await pg.wait_for_timeout(500);await E("()=>{settings.tab='Data';settings(pauseMenu)}");await pg.wait_for_timeout(500)
        r=await E("()=>{const b=document.getElementById('mfxrsb');return [!!b,b&&b.disabled,S.mode]}")
        chk('Settings opened from the pause menu: Reset save is disabled',r,r==[True,True,'pause'])
        await E("()=>{S.mode='play';over(true)}");await pg.wait_for_timeout(600);await E("()=>{title()}");await pg.wait_for_timeout(400)

        # ---------------- B14: used codes survive a reset ----------------
        await E("()=>{load({});P.gold=0;localStorage.removeItem('twCodesUsed87');P.ccUsed={};save()}")
        r=await E("async()=>{const x=await ccRedeem('COINS500');return [x.ok,P.gold,!!P.ccUsed.COINS500,JSON.parse(localStorage.getItem('twCodesUsed87')||'{}').COINS500]}")
        chk('a code is redeemed and remembered outside the save',r,r==[1,500,True,1])
        await E("()=>{ccStop()}")
        r=await E("async()=>{const x=await ccRedeem('COINS500');return [x.ok,P.gold]}")
        chk('the same save cannot redeem it twice',r,r==[0,500])
        await E("()=>{settings.tab='Data';settings(title)}");await pg.wait_for_timeout(600)
        await pg.click('#mfxrsb');await pg.click('#mfxrsb');await pg.wait_for_timeout(900)
        r=await E("async()=>{const a=[P.gold,P.runs,!!P.ccUsed.COINS500];const x=await ccRedeem('COINS500');return [a,x.ok,x.m,P.gold]}")
        chk('after Reset save the code is still used',r,r[0]==[0,0,True] and r[1]==0 and 'already used' in r[2] and r[3]==0)
        r=await E("async()=>{const x=await ccRedeem('COINS600');ccStop();return [x.ok,P.gold]}")
        chk('a different code still works after the reset',r,r==[1,600])
        r=await E("async()=>{P.ccUsed={};const x=await ccRedeem('COINS500');ccStop();return [x.ok]}")
        chk('another save (empty list) can still redeem a code once, as t_code81 expects',r,r==[1])
        await E("()=>{localStorage.removeItem('twCodesUsed87')}")

        # ---------------- B11: pet timers ----------------
        PET="()=>{RS_ASK=false;load({});P.gold=90000;P.petSt=2;P.pets={antler:{b:560,acc:1},bramble:{b:120}};P.pet='antler';P.eggs={r:1,l:0,m:0};P.trail={n:4,c:0};P.trSeen=4;petNorm();P.petUnl={};PTX.sel='antler';save();title()}"
        SNAP="()=>[!!document.getElementById('pth'),!!document.querySelector('.pat-wrap'),!!document.querySelector('.ptmod.on'),!!document.querySelector('.dkh'),S.mode,ov.classList.contains('hide')]"
        # convert an egg: press Convert, then leave before the hall refreshes (190 ms)
        PETC="()=>{PTX.back=title;petHall('Eggs');window.__cv=['r','l','m'].find(k=>petList(k).some(id=>petOwned(id)&&!petMaxed(id)));ptConvertModal(window.__cv)}"
        await E(PET);await pg.wait_for_timeout(500);await E(PETC);await pg.wait_for_timeout(500)
        has=await E("()=>!!document.getElementById('ptcy')")
        await pg.click('#ptcy');await pg.wait_for_timeout(40);await E("()=>title()");await pg.wait_for_timeout(900)
        r=await E(SNAP)
        chk('convert an egg, then Back before it refreshes: the Eggs tab does not come back over the hub',[has,r],has and r[0]==False and r[1]==False and r[3]==True)
        await E(PET);await pg.wait_for_timeout(400);await E(PETC);await pg.wait_for_timeout(500);await pg.click('#ptcy');await pg.wait_for_timeout(900)
        r=await E("()=>[!!document.getElementById('pth'),PTX.tab,!!document.querySelector('.ptmod.on')]")
        chk('...while without leaving, the Eggs tab still reopens after the convert',r,r[0]==True and r[1]=='Eggs')
        # appearance dialog: type a nickname, Save appearance, then Esc at once
        await E(PET);await pg.wait_for_timeout(400);await E("()=>{PTX.back=title;petHall('Pets');ptCustom('antler')}");await pg.wait_for_timeout(2500)
        await pg.fill('#patnk','Fern');await pg.wait_for_timeout(150)
        en=await E("()=>!document.getElementById('patsave').disabled")
        await pg.click('#patsave');await pg.wait_for_timeout(30);await E("()=>title()");await pg.wait_for_timeout(900)
        r=await E(SNAP);nk=await E("()=>P.pets.antler.nk")
        chk('save an appearance, then leave at once: the hall does not reopen over the hub',[en,nk,r],en and nk=='Fern' and r[0]==False and r[1]==False and r[3]==True)
        await E(PET);await pg.wait_for_timeout(400);await E("()=>{PTX.back=title;petHall('Pets');ptCustom('antler')}");await pg.wait_for_timeout(2500)
        await pg.fill('#patnk','Moss');await pg.wait_for_timeout(150);await pg.click('#patsave');await pg.wait_for_timeout(900)
        r=await E("()=>[!!document.getElementById('pth'),!!document.querySelector('.pat-wrap'),P.pets.antler.nk]")
        chk('...while without Esc the hall reopens after saving',r,r==[True,False,'Moss'])
        # "Try the new style" from a result screen
        await E(PET);await pg.wait_for_timeout(400)
        await E("()=>{PTX.back=title;petFromStyle('antler')}")
        await pg.wait_for_timeout(40);await pg.keyboard.press('Escape');await pg.wait_for_timeout(900)
        r=await E(SNAP)
        chk('"Try the new style", then Esc quickly: no dialog opens over the hub',r,r[0]==False and r[1]==False and r[3]==True)
        await E(PET);await pg.wait_for_timeout(400);await E("()=>{PTX.back=title;petFromStyle('antler')}");await pg.wait_for_timeout(1000)
        r=await E("()=>[!!document.querySelector('.pat-wrap'),!!document.getElementById('pth')]")
        chk('...while without Esc the appearance dialog opens',r,r==[True,True])
        await E("()=>{title()}");await pg.wait_for_timeout(2900)
        r=await E("()=>[$('cctoast')?$('cctoast').className:'']")
        chk('the toast that follows a pet action is not left hanging',r,r[0]=='')

        # ---------------- B13: Performance mode ----------------
        await E("()=>{load({});save();ST.perf='high';applyLayout();title()}");await pg.wait_for_timeout(500)
        r=await E("""()=>new Promise(res=>{const st=document.createElement('style');st.id='b13s';st.textContent='@keyframes b13k{0%{transform:scale(1)}50%{transform:scale(2)}100%{transform:scale(1)}}.b13{position:fixed;left:5px;top:5px;width:20px;height:20px;animation:b13k 1s linear infinite;z-index:9}.b13b{animation-delay:-.5s;left:40px}.b13c{animation-delay:-.25s;left:75px}';document.head.appendChild(st);
          for(const c of ['b13','b13 b13b','b13 b13c']){const d=document.createElement('div');d.className=c;document.body.appendChild(d)}
          setTimeout(()=>{ST.perf='low';pfApply();setTimeout(()=>{const els=[...document.querySelectorAll('.b13')];const out=els.map(e=>{const a=e.getAnimations()[0];return [a.playState,Math.round(a.currentTime*10)/10,getComputedStyle(e).transform]});res(out)},300)},450)})""")
        chk('Performance mode: looping animations rest at the start of their cycle (scale 1), including ones with a negative delay',r,all(x[0]=='paused' and (x[2] in ('matrix(1, 0, 0, 1, 0, 0)','none')) for x in r))
        r=await E("""()=>new Promise(res=>{setTimeout(()=>{const els=[...document.querySelectorAll('.b13')];res(els.map(e=>getComputedStyle(e).transform))},400)})""")
        chk('...and they stay at rest',r,all(x in ('matrix(1, 0, 0, 1, 0, 0)','none') for x in r))
        r=await E("""()=>{const all=document.getAnimations().filter(a=>a.playState==='paused'&&a.effect&&a.effect.getTiming().iterations===Infinity);return [all.length,all.filter(a=>a.currentTime>0).length]}""")
        chk('...every paused looping animation on the page sits at time 0 or earlier',r,r[0]>=3 and r[1]==0)
        r=await E("""()=>new Promise(res=>{ST.perf='high';pfApply();setTimeout(()=>{const els=[...document.querySelectorAll('.b13')];res(els.map(e=>e.getAnimations()[0].playState))},300)})""")
        chk('leaving Performance mode lets them run again',r,all(x=='running' for x in r))
        await E("()=>{document.querySelectorAll('.b13').forEach(e=>e.remove());document.getElementById('b13s').remove();ST.perf='high';applyLayout()}")

        # ---------------- overlap sweep on what changed ----------------
        for nm,js,root in [('settings Data: Reset save row',"()=>{settings.tab='Data';settings(title)}","#mfxrs"),('profile: stat tiles, prestige, header',"()=>{P.rb=null;P.pres=0;profile.tab='Overview';profile()}",".pfhead,.stt,.pres"),('endless: stats',"()=>{P.bestWave=0;endlessMenu(title)}",".ems"),('monster mash: stats',"()=>{P.gyb={};gyMenu(title)}",".gyr"),('bell popover',"()=>{title();setTimeout(()=>$('bell').click(),50)}","#bellp")]:
            await E(js);await pg.wait_for_timeout(900)
            r=await E("(sel)=>[...document.querySelectorAll(sel)].flatMap(e=>__ovl(e))",root)
            if 'bell' not in nm and 'Reset' not in nm:r=[x for x in r if 'nrec' in x]   # the tiles carry old 1-2px line-box overlaps that are not ours
            chk('text overlap sweep: '+nm,r[:4],r==[])
            await E("()=>{const p=$('bellp');if(p)p.classList.remove('open')}")
        print('bad',bad);print(er);await b.close()
asyncio.run(main())
