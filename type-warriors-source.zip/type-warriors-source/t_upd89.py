# python3 t_upd89.py [game.html] : update 8.9 (Harvest Festival) bell notice and its secret code (99t_update89.js).
# The entry is the newest in the Updates tab, its collage loads at 900x1386, the code is hidden in the notes and highlighted, redeeming
# it through the real box pays 2,500 coins once per save, no page errors. Screenshot in shots/w105_notice/.
import asyncio,os,sys
from playwright.async_api import async_playwright
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else 'out.html')
FAIL=[];N=[0]
def chk(n,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+n+('' if ok else '  '+str(info)[:400]),flush=True)
    if not ok:FAIL.append(n)
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]));await pg.goto(H);await pg.wait_for_timeout(1200);E=pg.evaluate
        await E("()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}P.gold=100;P.ccUsed={};save();title()}")
        r=await E("()=>{const u=UPDATES.filter(x=>x.id==='u-8.9');const all=UPDATES.map(x=>x.ts);return [u.length,u[0]&&u[0].h,u[0]&&u[0].ts===Math.max(...all),u[0]&&u[0].b.includes('harvestmoon'),u[0]&&u[0].b.includes('6 November')&&u[0].b.includes('1 December'),(u[0]&&u[0].alt||'').length>40]}")
        chk('the 8.9 entry exists once, is the newest, names the festival dates and hides the code at the end of the notes',r[0]==1 and r[1]=='8.9 The Harvest Festival is OUT!' and r[2] and r[3] and r[4] and r[5],r)
        r=await E("()=>new Promise(ok=>{const i=new Image();i.onload=()=>ok([i.naturalWidth,i.naturalHeight]);i.onerror=()=>ok(null);i.src=UPDATES.find(x=>x.id==='u-8.9').img})")
        chk('the collage decodes at 900x1386',r==[900,1386],r)
        await E("()=>{BELL_TAB='u';try{bellOpen()}catch(e){}}");await pg.wait_for_timeout(300)
        r=await E("()=>{const h=bellInner();return [h.includes('The Harvest Festival is OUT!'),h.includes('blsec')&&h.includes('harvestmoon')]}")
        chk('the Updates tab lists it and highlights the secret word',r==[True,True],r)
        try:await pg.screenshot(path='shots/w105_notice/bell.png')
        except Exception:pass
        r=await E("async()=>{const a=await ccRedeem('harvestmoon'),g1=P.gold,b2=await ccRedeem('HARVESTMOON');return [a.ok,g1,b2.ok,P.gold,!!P.ccUsed.HARVESTMOON]}")
        chk('HARVESTMOON pays 2,500 coins once per save',r==[1,2600,0,2600,True],r)
        await E("()=>{load(JSON.parse(JSON.stringify(P)))}");r=await E("async()=>{const x=await ccRedeem('HarvestMoon');return [x.ok,P.gold]}")
        chk('it stays used after the save is reloaded',r==[0,2600],r)
        chk('no page errors',not er,er);await b.close()
    print(f'\n{N[0]-len(FAIL)} / {N[0]} passed');print(FAIL)
asyncio.run(main())
