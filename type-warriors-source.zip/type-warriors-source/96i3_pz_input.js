/* ===== 9.4 THE CROOKED CUE: the match screen DOM, input, HUD, taunts (96i3) =====
   The HUD is DOM on top of the canvas (transform/opacity animations only). Non-interactive HUD parts have pointer-events:none so the
   canvas still receives the pointer through them. */
function pzMount(R,tok){const Z=PZS(),M=PZ.M;
 show(`<div class="pzm" id="pzm"><canvas id="pzcv" width="1600" height="900"></canvas>
 <div class="pzhud" id="pzhud">
  <div class="pzcard me" id="pzcm"><div class="pzav"><canvas id="pzavm" width="132" height="132"></canvas></div><div class="pzct"><b id="pznm">You</b><i id="pzsm">Open table</i></div><div class="pzballs" id="pzbm"></div><div class="pzpips" id="pzpm"></div><div class="pzturn" id="pztm">YOUR SHOT</div></div>
  <div class="pzcenter" id="pzcc"><small id="pzrace"></small><div class="pzscore"><b id="pzs0">0</b><i>-</i><b id="pzs1">0</b></div><span id="pzpot"></span></div>
  <div class="pzcard opp" id="pzco"><div class="pzav"><canvas id="pzavo" width="132" height="132"></canvas></div><div class="pzct"><b id="pzno">${R.n}</b><i id="pzso">Open table</i></div><div class="pzballs" id="pzbo"></div><div class="pzpips" id="pzpo"></div><div class="pzturn" id="pzto">SHOT</div></div>
 </div>
 <div class="pzbar" id="pzbar">
  <div class="pzspinw"><canvas id="pzspin" width="132" height="132" aria-label="Spin: click to set where the cue hits the ball"></canvas><small>SPIN</small><i id="pzspl">centre</i></div>
  <div class="pzpw"><small>POWER</small><div class="pzpb" id="pzpb"><i id="pzpf"></i><u></u></div><span id="pzpp">50%</span><p id="pzhint"></p></div>
  <div class="pzclk" id="pzclkw"><svg viewBox="0 0 80 80"><circle class="bg" cx="40" cy="40" r="35"/><circle class="fg" id="pzclr" cx="40" cy="40" r="35"/></svg><b id="pzclk">45</b><small>SHOT CLOCK</small></div>
  <button class="pzbtn" id="pzgd" aria-label="Aim guide">Guide<b id="pzgdv">Full</b></button>
  <button class="pzgo" id="pzgo">SHOOT</button>
 </div>
 <button class="pzmenu" id="pzmb">II&nbsp; Menu</button>
 <div class="pzban" id="pzban"></div><div class="pzsub" id="pzsub"></div>
 <div class="pzsay" id="pzsay"><span></span></div>
 <div class="pzlb t" id="pzlbt"></div><div class="pzlb b" id="pzlbb"></div>
 <div class="pztaunt" id="pztaunt" hidden><small>TAUNT!  type it before the bar empties  (Esc skips)</small><div class="pztl" id="pztl"></div><div class="pztb"><i id="pztbi"></i></div></div>
 <div class="pzmod" id="pzmod" hidden></div><div class="pzintro" id="pzintro" hidden></div>
</div>`,'casbg pzx');
 const cv=$('pzcv');PZ.g=cv.getContext('2d');PZ.cv=cv;PZ.fx=[];PZ.rings=[];PZ.floats=[];PZ.drops=[];PZ.tray=[];PZ.cam={z:1,cx:800,cy:450};PZ.shake=0;PZ.keys={};PZ.hadOpen=true;PZ.modal=false;PZ.t=0;PZ.last=performance.now();PZ.ts=1;PZ.tsT=1;PZ.B=null;PZ.st=null;PZ.heroPose=null;PZ.cueA=0;PZ.mode=null;
 pzbSetup(PZ.lite?36:52,Z.balls);PZ.bk=pzBake(Z.felt,PZ.dim);
 LIVE.push({cv,fn:()=>{try{pzFrame(PZ.g)}catch(e){console.error(e)}}});
 /* portraits (live, slow) */
 {const am=$('pzavm').getContext('2d'),ao=$('pzavo').getContext('2d');const draw=()=>{if(PZ.tok!==tok)return;pzCastPortrait(am,'hero',null,132,PZ.t);pzCastPortrait(ao,'mon',R.id,132,PZ.t,PZ_CAST.mon&&PZ_CAST.mon.ex)};draw();LIVE.push({cv:$('pzavo'),fn:draw,slow:2,ph:0})}
 pzBindMatch(tok);S.back=()=>{if(PZ.on&&PZ.tok===tok&&PZ.ph!=='over')pzPauseMenu();};
 pzHudAll();pzHudBar();pzSpinDraw();pzFitTM&&pzFitTM()}
/* ---------- HUD ---------- */
function pzBallsHTML(grp,B){if(!grp)return Array.from({length:7},(_,i)=>`<i class="open"></i>`).join('');const ids=grp==='s'?[1,2,3,4,5,6,7]:[9,10,11,12,13,14,15];return ids.map(n=>`<img class="${B[n]&&B[n].on?'':'out'}" src="${pzbIcon(n,22)}" alt="${n}">`).join('')}
function pzHudAll(){if(!PZ.on||!$('pzm'))return;const st=PZ.st,M=PZ.M,R=PZ.reg,B=PZ.B||[];if(!st)return;
 const sub=(p)=>{const g=st.grp[p];return g?(g==='s'?'Solids':'Stripes'):'Open table'};
 $('pzsm').textContent=sub(0);$('pzso').textContent=sub(1);$('pzbm').innerHTML=pzBallsHTML(st.grp[0],B);$('pzbo').innerHTML=pzBallsHTML(st.grp[1],B);
 $('pzs0').textContent=M.score[0];$('pzs1').textContent=M.score[1];$('pzrace').textContent=`RACE TO ${M.race}  ·  RACK ${M.rack}`;
 $('pzpot').textContent=M.practice?'Practice table':`Pot ${cmn(Math.round(M.stake*M.mult))}  (stake ${cmn(M.stake)} ×${M.mult.toFixed(2).replace(/0$/,'')})`;
 const pips=(p)=>Array.from({length:M.race},(_,i)=>`<i class="${i<M.score[p]?'on':''}"></i>`).join('');$('pzpm').innerHTML=pips(0);$('pzpo').innerHTML=pips(1);
 const mine=st.turn===0&&PZ.ph!=='endhold';$('pzcm').classList.toggle('turn',st.turn===0);$('pzco').classList.toggle('turn',st.turn===1);$('pztm').textContent=st.bih&&st.turn===0?'BALL IN HAND':'YOUR SHOT';$('pzto').textContent=st.bih&&st.turn===1?'BALL IN HAND':'THEIR SHOT';
 $('pzgdv').textContent=pzGuideMode()==='short'&&PZS().guide==='full'?'Short':PZS().guide==='full'?'Full':PZS().guide==='short'?'Short':'Pro';
 pzHudHint()}
function pzHudHint(){const h=$('pzhint');if(!h)return;const st=PZ.st,touch=PZ.touch;let t='';
 if(PZ.ph==='aim'){if(PZ.mode==='place')t=st.kitchen||st.brk?'Click to place the cue ball behind the line':'Ball in hand: click to place the cue ball';
  else if(pzrOn8(st))t=`The 8! Pocket ${(PZ.call>=0?PZ.call+1:'?')} is called · click a pocket or press 1-6`;
  else t=touch?'Drag on the table to aim · set power below · tap SHOOT':(st.brk?'Aim · drag the cue ball to move it · pull back to break':'Aim with the mouse · pull back to set power · release to shoot')}
 else if(PZ.ph==='ai'){t=`${PZ.reg.n} is lining up a shot…`}else if(PZ.ph==='roll'){t=''}else if(PZ.ph==='rerack'){t='Racking…'}
 h.textContent=t;$('pzbar').classList.toggle('mine',PZ.ph==='aim'&&PZ.mode==='aim');$('pzbar').classList.toggle('ai',PZ.ph==='ai')}
function pzHudBar(){const a=PZ.aim;if(!$('pzpf')||!a)return;$('pzpf').style.transform=`scaleX(${a.pow})`;$('pzpp').textContent=Math.round(a.pow*100)+'%'}
function pzHudClock(){const c=$('pzclk');if(!c)return;const on=PZ.clockOn&&PZ.ph==='aim',mx=pzClockMax();$('pzclkw').classList.toggle('off',!on);if(!on)return;const s=Math.max(0,Math.ceil(PZ.clock));if(c.textContent!==String(s))c.textContent=s;const u=Math.max(0,PZ.clock/mx);$('pzclr').style.strokeDashoffset=String(220*(1-u));$('pzclkw').classList.toggle('warn',PZ.clock<=10);$('pzclkw').classList.toggle('crit',PZ.clock<=5)}
let PZ_BAN_N=0;
function pzBanner(text,kind,ms){const el=$('pzban');if(!el)return;while(el.children.length>1)el.firstChild.remove();const d=document.createElement('div');d.className='pzbn '+(kind||'info');d.textContent=text;el.appendChild(d);setTimeout(()=>{d.classList.add('out');setTimeout(()=>d.remove(),400)},Math.max(600,ms||1200))}
function pzSub(text,ms){const el=$('pzsub');if(!el)return;el.textContent=text;el.classList.remove('on');void el.offsetWidth;el.classList.add('on');clearTimeout(PZ.subT);PZ.subT=setTimeout(()=>el&&el.classList.remove('on'),ms||1400)}
function pzSay(text,ms){const el=$('pzsay');if(!el||!text)return;el.firstChild.textContent=text;el.classList.remove('on');void el.offsetWidth;el.classList.add('on');clearTimeout(PZ.sayT);PZ.sayT=setTimeout(()=>el&&el.classList.remove('on'),ms||2000);try{pzFx('voice',{id:PZ.reg.id,n:text.length})}catch(e){}}
function pzLetterbox(on){const m=$('pzm');if(m)m.classList.toggle('lbx',!!on)}
/* ---------- the spin widget ---------- */
function pzSpinDraw(){const cv=$('pzspin');if(!cv||!PZ.aim)return;const g=cv.getContext('2d'),a=PZ.aim,r=60;g.clearRect(0,0,132,132);g.save();g.translate(66,66);
 const q=g.createRadialGradient(-18,-22,6,0,0,r);q.addColorStop(0,'#ffffff');q.addColorStop(.6,'#efe8d6');q.addColorStop(1,'#b8ad98');g.fillStyle=q;g.beginPath();g.arc(0,0,r,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=4;g.stroke();
 g.strokeStyle='rgba(0,0,0,.18)';g.lineWidth=1.6;g.beginPath();g.moveTo(-r,0);g.lineTo(r,0);g.moveTo(0,-r);g.lineTo(0,r);g.stroke();g.beginPath();g.arc(0,0,r*.55,0,TAU);g.stroke();
 g.fillStyle='rgba(120,60,40,.5)';g.font='700 11px Poppins,sans-serif';g.textAlign='center';g.fillText('FOLLOW',0,-r*.72);g.fillText('DRAW',0,r*.82);g.textAlign='left';g.fillText('L',-r*.92,4);g.textAlign='right';g.fillText('R',r*.92,4);
 const x=a.a*r*.8,y=a.b*-r*.8;g.fillStyle='rgba(0,0,0,.25)';g.beginPath();g.arc(x+1.5,y+2.5,9,0,TAU);g.fill();g.fillStyle='#e0262e';g.beginPath();g.arc(x,y,9,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2.4;g.stroke();g.fillStyle='rgba(255,255,255,.8)';g.beginPath();g.arc(x-3,y-3.5,2.6,0,TAU);g.fill();g.restore();
 const lab=Math.abs(a.a)<.08&&Math.abs(a.b)<.08?'centre':[a.b>.15?'follow':a.b<-.15?'draw':'',a.a<-.15?'left':a.a>.15?'right':''].filter(Boolean).join(' + ');const s=$('pzspl');if(s)s.textContent=lab}
/* ---------- input ---------- */
const pzXY=e=>{const r=PZ.cv.getBoundingClientRect();return{x:(e.clientX-r.left)/r.width*1600,y:(e.clientY-r.top)/r.height*900}};
function pzBindMatch(tok){const cv=PZ.cv,st=()=>PZ.st;
 cv.addEventListener('pointermove',e=>{if(PZ.tok!==tok||PZ.paused||PZ.modal)return;PZ.touch=e.pointerType==='touch';const p=pzXY(e),B=PZ.B;if(!B||PZ.ph!=='aim')return;const tx=p.x-PZ_G.x,ty=p.y-PZ_G.y,c=B[0];
  if(PZ.mode==='place'){const k=PZ.st.kitchen||PZ.st.brk;PZ.place=pzpNearestPlace(B,tx,ty,k);return}
  if(PZ.mode!=='aim')return;
  if(PZ.drag&&PZ.drag.id===e.pointerId){const d=PZ.drag,dx=Math.cos(d.ang),dy=Math.sin(d.ang),pull=(d.sx-p.x)*dx+(d.sy-p.y)*dy;PZ.aim.pow=Math.max(0,Math.min(1,pull/230));pzHudBar();return}
  if(Math.hypot(tx-c.x,ty-c.y)>26&&!(PZ.touch&&PZ.dragT))PZ.aim.ang=Math.atan2(ty-c.y,tx-c.x)});
 cv.addEventListener('pointerdown',e=>{if(PZ.tok!==tok||PZ.paused||PZ.modal||e.button===2)return;PZ.touch=e.pointerType==='touch';const p=pzXY(e),B=PZ.B;
  if(PZ.ph==='ai'&&PZ.ai){PZ.ai.skip=true;return}
  if(!B||PZ.ph!=='aim')return;const tx=p.x-PZ_G.x,ty=p.y-PZ_G.y,c=B[0];try{cv.setPointerCapture(e.pointerId)}catch(_){}
  if(PZ.mode==='place'){const k=PZ.st.kitchen||PZ.st.brk;const pl=pzpNearestPlace(B,tx,ty,k);PZ.place=pl;if(pl.ok){pzPlaceCue(pl.x,pl.y)}else{pzFx('no');pzBanner(k?'Too close to a ball, or past the line':'Too close to a ball','foul',700)}return}
  /* the 8: clicking a pocket calls it */
  if(pzrOn8(PZ.st)){for(let k=0;k<6;k++){const P=PZ_POCK[k];if(Math.hypot(tx-P[0],ty-P[1])<P[3]+10){PZ.call=k;PZ.callManual=true;pzFx('call');pzHudHint();return}}}
  /* on the break the cue ball can be picked up */
  if(PZ.canPick&&Math.hypot(tx-c.x,ty-c.y)<PZ_PHY.R+8){PZ.mode='place';PZ.place={x:c.x,y:c.y,ok:true};PZ.canPick=false;pzFx('lift');pzHudHint();return}
  if(PZ.touch){PZ.aim.ang=Math.atan2(ty-c.y,tx-c.x);PZ.dragT=true;return}
  PZ.drag={id:e.pointerId,sx:p.x,sy:p.y,ang:PZ.aim.ang};PZ.aim.pow=Math.max(.0,PZ.aim.pow);});
 const up=e=>{if(PZ.tok!==tok)return;PZ.dragT=false;if(PZ.drag&&PZ.drag.id===e.pointerId){const d=PZ.drag;PZ.drag=null;if(PZ.ph==='aim'&&PZ.mode==='aim'&&PZ.aim.pow>.045&&Math.hypot(pzXY(e).x-d.sx,pzXY(e).y-d.sy)>10)pzFireHuman();else{PZ.aim.pow=PZ.lastPow||.5;pzHudBar()}}};
 cv.addEventListener('pointerup',up);cv.addEventListener('pointercancel',e=>{PZ.drag=null;PZ.dragT=false});cv.addEventListener('contextmenu',e=>{e.preventDefault();if(PZ.drag){PZ.drag=null;PZ.aim.pow=PZ.lastPow||.5;pzHudBar()}});
 cv.addEventListener('wheel',e=>{if(PZ.tok!==tok||PZ.ph!=='aim'||PZ.mode!=='aim')return;e.preventDefault();PZ.aim.ang+=Math.sign(e.deltaY)*(e.shiftKey?.0087:.00087)*3},{passive:false});
 /* spin widget */
 const sp=$('pzspin'),spin=e=>{if(PZ.tok!==tok||PZ.ph!=='aim')return;const r=sp.getBoundingClientRect(),x=(e.clientX-r.left)/r.width*2-1,y=(e.clientY-r.top)/r.height*2-1;let a=x/.8,b=-y/.8;const l=Math.hypot(a,b);if(l>1){a/=l;b/=l}PZ.aim.a=Math.round(a*20)/20;PZ.aim.b=Math.round(b*20)/20;pzSpinDraw()};
 let sdown=false;sp.addEventListener('pointerdown',e=>{sdown=true;try{sp.setPointerCapture(e.pointerId)}catch(_){}spin(e)});sp.addEventListener('pointermove',e=>{if(sdown)spin(e)});sp.addEventListener('pointerup',()=>sdown=false);sp.addEventListener('dblclick',()=>{if(PZ.aim){PZ.aim.a=0;PZ.aim.b=0;pzSpinDraw()}});
 /* power bar */
 const pb=$('pzpb'),pw=e=>{if(PZ.tok!==tok||PZ.ph!=='aim'||PZ.mode!=='aim')return;const r=pb.getBoundingClientRect();PZ.aim.pow=Math.max(0,Math.min(1,(e.clientX-r.left)/r.width));pzHudBar()};
 let pdown=false;pb.addEventListener('pointerdown',e=>{pdown=true;try{pb.setPointerCapture(e.pointerId)}catch(_){}pw(e)});pb.addEventListener('pointermove',e=>{if(pdown)pw(e)});pb.addEventListener('pointerup',()=>pdown=false);
 $('pzgo').addEventListener('click',()=>pzFireHuman());
 $('pzgd').addEventListener('click',()=>{const Z=PZS(),o=['full','short','pro'];Z.guide=o[(o.indexOf(Z.guide)+1)%3];save();pzHudAll();pzFx('tick')});
 $('pzmb').addEventListener('click',()=>pzPauseMenu());
 const keep=e=>e.preventDefault();['pzgo','pzgd','pzmb'].forEach(i=>$(i).addEventListener('mousedown',keep))}
function pzFireHuman(){if(PZ.ph!=='aim'||PZ.mode!=='aim'||PZ.paused||PZ.modal)return;const a=PZ.aim;if(a.pow<.03){pzFx('no');return}PZ.lastPow=a.pow;pzTauntStop();pzStartStroke({ang:PZ.cueAng,pow:a.pow,a:a.a,b:a.b},false);a.a=0;a.b=0;pzSpinDraw()}
function pzPlaceCue(x,y){const c=PZ.B[0];c.x=x;c.y=y;c.on=true;c.placed=true;c.vx=c.vy=0;PZ.mode='aim';PZ.canPick=false;PZ.place=null;PZ.placePop={x,y,t:0};PZ.cueAng=PZ.aim.ang=pzDefaultAim();PZ.cueAv=0;pzFx('place');pzHudAll()}
/* keyboard: one listener for the whole mode */
if(!window.__pzKeys){window.__pzKeys=1;
 addEventListener('keydown',e=>{if(!PZ.on||!$('pzm')||e.ctrlKey||e.metaKey||e.altKey)return;if(document.activeElement&&/INPUT|TEXTAREA/.test(document.activeElement.tagName))return;
  /* a taunt swallows letters */
  if(PZ.taunt){if(e.key==='Escape'){pzTauntStop();e.preventDefault();e.stopPropagation();return}if(e.key.length===1){e.preventDefault();pzTauntKey(e.key);return}}
  if(PZ.modal)return;const k=e.key;
  if(k==='ArrowLeft'||k==='ArrowRight'||k==='ArrowUp'||k==='ArrowDown'){const m={ArrowLeft:'left',ArrowRight:'right',ArrowUp:'up',ArrowDown:'down'}[k];PZ.keys[m]=1;PZ.keys.shift=e.shiftKey;if(PZ.ph==='aim'&&PZ.mode==='place'){const d=e.shiftKey?24:6,p=PZ.place||{x:PZ.B[0].x,y:PZ.B[0].y};const q=pzpNearestPlace(PZ.B,p.x+(k==='ArrowRight'?d:k==='ArrowLeft'?-d:0),p.y+(k==='ArrowDown'?d:k==='ArrowUp'?-d:0),PZ.st.kitchen||PZ.st.brk);PZ.place=q}e.preventDefault();return}
  if(PZ.ph==='aim'){
   if(k===' '||k==='Enter'){e.preventDefault();if(PZ.mode==='place'&&PZ.place){if(PZ.place.ok)pzPlaceCue(PZ.place.x,PZ.place.y)}else pzFireHuman();return}
   if(PZ.mode==='aim'){const s=PZ.aim,l=k.toLowerCase();
    if(l==='w'){s.b=Math.min(1,s.b+.15);pzSpinDraw()}else if(l==='s'){s.b=Math.max(-1,s.b-.15);pzSpinDraw()}else if(l==='a'){s.a=Math.max(-1,s.a-.15);pzSpinDraw()}else if(l==='d'){s.a=Math.min(1,s.a+.15);pzSpinDraw()}else if(l==='r'){s.a=0;s.b=0;pzSpinDraw()}
    else if(l==='g'){$('pzgd').click()}
    else if(/^[1-6]$/.test(k)&&pzrOn8(PZ.st)){PZ.call=+k-1;PZ.callManual=true;pzFx('call');pzHudHint()}}}
  else if(PZ.ph==='ai'&&(k===' '||k==='Enter')&&PZ.ai){PZ.ai.skip=true}
 });
 addEventListener('keyup',e=>{if(!PZ.keys)return;const m={ArrowLeft:'left',ArrowRight:'right',ArrowUp:'up',ArrowDown:'down'}[e.key];if(m)PZ.keys[m]=0;PZ.keys.shift=e.shiftKey})}
/* ---------- taunts: type a line to rattle the monster ---------- */
function pzSayMaybeTaunt(){const Z=PZS(),M=PZ.M,R=PZ.reg;if(!PZ.nextTaunt)return;PZ.nextTaunt=false;if(!Z.tauntsOn||PZ.ph!=='aim'||PZ.st.bih||M.score[1]>=M.race-1||PZ.tauntRack===M.rack&&PZ.tauntN>=1||Math.random()>.45)return;
 if(PZ.tauntRack!==M.rack){PZ.tauntRack=M.rack;PZ.tauntN=0}PZ.tauntN++;const text=pzPick(R.taunts,PZ.rng);PZ.taunt={text,pos:0,t:0,dur:3+.12*text.length,err:0};pzTauntDraw();$('pztaunt').hidden=false;$('pztaunt').classList.remove('out');void $('pztaunt').offsetWidth;$('pztaunt').classList.add('in');PZ.tauntTick=setInterval(pzTauntTick,50)}
function pzTauntDraw(){const T=PZ.taunt;if(!T)return;$('pztl').innerHTML=`<b>${T.text.slice(0,T.pos).replace(/ /g,'&nbsp;')}</b>${T.text.slice(T.pos).replace(/ /g,'&nbsp;')}`}
function pzTauntTick(){const T=PZ.taunt;if(!T||PZ.paused||PZ.modal)return;T.t+=.05;$('pztbi').style.transform=`scaleX(${Math.max(0,1-T.t/T.dur)})`;if(T.t>=T.dur){pzTauntStop();pzCastReact('mon','smug',1200);pzSay(pzPick(['Hee hee!','Too slow!','Ha!'],PZ.rng),1500)}}
function pzTauntKey(ch){const T=PZ.taunt;if(!T)return;if(ch.toLowerCase()===T.text[T.pos].toLowerCase()){T.pos++;pzFx('key');if(T.pos>=T.text.length){pzTauntWin()}else pzTauntDraw()}else{T.err++;const l=$('pztl');l.classList.remove('shake');void l.offsetWidth;l.classList.add('shake');pzFx('no')}}
function pzTauntWin(){const Z=PZS();pzTauntStop(true);Z.taunts++;save();PZ.rattled=1;pzCastReact('mon','rattled',2400);pzSay(pzPick(PZ.reg.lines.taunted,PZ.rng),2200);pzFloat(1450,560,'RATTLED!','#ff9ad0');pzFx('taunt');pzBanner('Rattled!','gold',900)}
function pzTauntStop(won){clearInterval(PZ.tauntTick);PZ.tauntTick=0;const el=$('pztaunt');if(PZ.taunt&&el){el.classList.remove('in');el.classList.add('out');setTimeout(()=>{if(!PZ.taunt)el.hidden=true},300)}PZ.taunt=null}
