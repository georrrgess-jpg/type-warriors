/* ===== MOONLIT FISHING: the two MYTHIC fish (seraph, eclipse) =====
   Mythic sits above Legendary: prismatic, cosmic, the grandest art in the game. Same contract as every fish:
   FISHART.<id>=(g,t,o) centred, facing right, ~200 units long, inside x -115..115 / y -80..80.
   o.flex thrashes, o.glow lights the catch spectacle. fishDraw renders silhouettes with o.sil===0: ambient auras and
   loose motes are skipped there so the shadow keeps a crisp, readable outline. Private helpers are prefixed fm_. */
function fm_path(g,c){g.beginPath();let i=0;while(i<c.length){const k=c[i++];
 if(k==='M'){g.moveTo(c[i],c[i+1]);i+=2}else if(k==='L'){g.lineTo(c[i],c[i+1]);i+=2}
 else if(k==='Q'){g.quadraticCurveTo(c[i],c[i+1],c[i+2],c[i+3]);i+=4}else if(k==='C'){g.bezierCurveTo(c[i],c[i+1],c[i+2],c[i+3],c[i+4],c[i+5]);i+=6}
 else if(k==='Z')g.closePath()}}
function fm_poly(g,p){g.beginPath();g.moveTo(p[0],p[1]);for(let i=2;i<p.length;i+=2)g.lineTo(p[i],p[i+1]);g.closePath()}
function fm_grad(g,x0,y0,x1,y1,s){const q=g.createLinearGradient(x0,y0,x1,y1);for(const e of s)q.addColorStop(e[0],e[1]);return q}
function fm_rgrad(g,x,y,r0,r1,s){const q=g.createRadialGradient(x,y,r0,x,y,r1);for(const e of s)q.addColorStop(e[0],e[1]);return q}
function fm_at(g,x,y,a,fn){g.save();g.translate(x,y);g.rotate(a);fn();g.restore()}
const fm_tw=(t,i,sp)=>.5+.5*Math.sin(t*(sp||3)+i*1.91);
/* aurora hue (green -> teal -> blue -> violet -> pink) for a phase */
const fm_hue=s=>150+150*(.5+.5*Math.sin(s));
const fm_hsl=(h,a,l)=>`hsla(${h|0},96%,${l||68}%,${a==null?1:a})`;
/* a ribbon/tendril polygon from spine points [[x,y],...] and half widths [w,...]; returns the path builder */
function fm_ribbon(g,P,W){const L=[],R=[],n=P.length;
 for(let i=0;i<n;i++){const a=P[Math.max(0,i-1)],b=P[Math.min(n-1,i+1)];let dx=b[0]-a[0],dy=b[1]-a[1];const d=Math.hypot(dx,dy)||1;dx/=d;dy/=d;
  L.push([P[i][0]-dy*W[i],P[i][1]+dx*W[i]]);R.push([P[i][0]+dy*W[i],P[i][1]-dx*W[i]])}
 return ()=>{g.beginPath();g.moveTo(L[0][0],L[0][1]);for(let i=1;i<n;i++){const m=[(L[i-1][0]+L[i][0])/2,(L[i-1][1]+L[i][1])/2];g.quadraticCurveTo(L[i-1][0],L[i-1][1],m[0],m[1])}
  g.lineTo(L[n-1][0],L[n-1][1]);g.lineTo(R[n-1][0],R[n-1][1]);for(let i=n-2;i>=0;i--){const m=[(R[i+1][0]+R[i][0])/2,(R[i+1][1]+R[i][1])/2];g.quadraticCurveTo(R[i+1][0],R[i+1][1],m[0],m[1])}
  g.lineTo(R[0][0],R[0][1]);g.closePath()}}
/* a tiny six-armed snow crystal */
function fm_snow(g,x,y,r,rot,c,a){g.save();g.translate(x,y);g.rotate(rot);g.globalAlpha=a;g.strokeStyle=c;g.lineWidth=Math.max(.8,r*.22);g.lineCap='round';g.beginPath();
 for(let k=0;k<6;k++){const an=k*Math.PI/3,cx=Math.cos(an),sy=Math.sin(an);g.moveTo(0,0);g.lineTo(cx*r,sy*r);g.moveTo(cx*r*.55,sy*r*.55);g.lineTo(cx*r*.55+Math.cos(an+.8)*r*.3,sy*r*.55+Math.sin(an+.8)*r*.3);
  g.moveTo(cx*r*.55,sy*r*.55);g.lineTo(cx*r*.55+Math.cos(an-.8)*r*.3,sy*r*.55+Math.sin(an-.8)*r*.3)}g.stroke();g.restore()}


/* ---------- 14. Seraph of Everwinter: a celestial crystal angel-fish with six wings and an aurora halo ---------- */
/* one faceted ice-crystal wing in local space: root at the origin, reaching along +x for L; the convex leading
   edge is on +y and five crystal feathers fan out along -y. h = aurora hue, ph = shimmer phase, lt = lightness of the
   deep refracted planes (42 for the great wings, brighter for the small pectoral), wa = extra white on the bright planes */
function fm_wing(g,t,L,h,ph,gl,lt,wa){lt=lt||42;wa=wa||0;
 const O=[[0,.06],[.2,.2],[.6,.25],[1,.02],[.8,-.15],[.42,-.23],[.12,-.1]].map(p=>[p[0]*L,(p[1]-.14*p[0]*p[0])*L]),V=[[.28,.02],[.56,.03],[.8,.01]].map(p=>[p[0]*L,(p[1]-.14*p[0]*p[0])*L]);
 const P=()=>{g.beginPath();O.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.closePath()};
 P();g.fillStyle=fm_grad(g,0,0,L,0,[[0,'rgba(255,255,255,.97)'],[.3,fm_hsl(h,.8,84)],[.7,fm_hsl(h+22,.62,70)],[1,fm_hsl(h+44,.5,82)]]);g.fill();
 g.save();P();g.clip();
 // stained-crystal cells: bright planes on the leading half, deep refracted planes below
 const cells=[[O[0],O[1],V[0],.34],[O[1],O[2],V[1],V[0],.2],[O[2],V[2],V[1],.3],[O[2],O[3],V[2],.12],[O[0],V[0],O[6],-.1],[O[6],V[0],V[1],O[5],-.2],[O[5],V[1],V[2],O[4],-.12],[O[4],V[2],O[3],-.24]];
 cells.forEach((c,i)=>{const k=c[c.length-1];g.beginPath();for(let j=0;j<c.length-1;j++)j?g.lineTo(c[j][0],c[j][1]):g.moveTo(c[j][0],c[j][1]);g.closePath();
  g.fillStyle=k>0?`rgba(255,255,255,${Math.min(1,k+wa)})`:fm_hsl(h+30+i*16,-k*1.5,lt);g.fill()});
 // a prismatic shimmer sweeping out along the wing
 const q=((t*.45+ph)%1)*1.5-.25;g.fillStyle=fm_grad(g,(q-.13)*L,0,(q+.13)*L,0,[[0,'rgba(255,255,255,0)'],[.5,`rgba(255,255,255,${.5+gl*.3})`],[1,'rgba(255,255,255,0)']]);g.fillRect(-4,-.3*L,L*1.1,.6*L);
 // crystal veins
 g.lineCap='round';g.lineJoin='round';g.beginPath();g.moveTo(O[0][0],O[0][1]);V.forEach(p=>g.lineTo(p[0],p[1]));g.lineTo(O[3][0],O[3][1]);
 [[V[0],O[1]],[V[1],O[2]],[V[2],O[2]],[V[0],O[6]],[V[1],O[5]],[V[2],O[4]]].forEach(e=>{g.moveTo(e[0][0],e[0][1]);g.lineTo(e[1][0],e[1][1])});
 g.strokeStyle=fm_hsl(h+40,.4,lt>50?62:40);g.lineWidth=2.4;g.stroke();g.strokeStyle='rgba(255,255,255,.88)';g.lineWidth=1.1;g.stroke();
 // icy rim and a rainbow fringe along the leading edge
 P();g.strokeStyle='rgba(235,255,255,.6)';g.lineWidth=3;g.stroke();
 g.beginPath();g.moveTo(O[0][0],O[0][1]);g.lineTo(O[1][0],O[1][1]);g.lineTo(O[2][0],O[2][1]);g.lineTo(O[3][0],O[3][1]);
 g.strokeStyle=fm_grad(g,0,0,L,0,[[0,'rgba(255,255,255,.95)'],[.4,fm_hsl(h+80,.9,80)],[.75,fm_hsl(h+140,.9,80)],[1,'rgba(255,255,255,.95)']]);g.lineWidth=4;g.stroke();
 g.restore();
 P();g.lineJoin='round';g.lineWidth=2.3;g.strokeStyle=FKO;g.stroke();
 for(let i=0;i<3;i++){const k=fm_tw(t,ph*5+i*1.7,2.6),p=[O[3],O[2],O[4]][i];fkSpark(g,p[0],p[1],(i?1.8:3.4)+2.2*k+gl*1.6,'#ffffff',.3+.65*k)}}
FISHART.seraph=(g,t,o)=>{const fx=o.flex||0,gl=o.glow||0,SIL=(typeof FKSIL!=="undefined"&&g.canvas===FKSIL),sw=fkSway(o,2.2,.1),pu=.5+.5*Math.sin(t*1.7),bend=Math.sin(t*2.4)*fx*.05;
 g.save();g.translate(4,Math.sin(t*1.3)*1.4);g.rotate(-sw*.12+bend);
 if(!SIL){
  // cold radiant aura and slow god-rays of starlight behind everything; the catch glow sits back here too, so the
  // crystal body keeps its facets and soul-star instead of washing out to a white disc
  g.save();g.scale(1,.72);fkGlow(g,-4,0,126,'#bff4ff',.12+.05*pu+gl*.28);
  g.globalCompositeOperation='lighter';for(let i=0;i<12;i++){const a=t*.07+i*TAU/12,L=(i%2?84:104)+gl*8,h=fm_hue(i*1.1+t*.3);
   g.beginPath();g.moveTo(14,0);g.lineTo(14+Math.cos(a-.05)*L,Math.sin(a-.05)*L);g.lineTo(14+Math.cos(a+.05)*L,Math.sin(a+.05)*L);g.closePath();
   g.fillStyle=fm_rgrad(g,14,0,10,L,[[0,fm_hsl(h,.2+gl*.15,85)],[1,fm_hsl(h,0,85)]]);g.fill()}
  g.restore();
  if(gl>0)fkGlow(g,10,0,120,'#e6fbff',.26*gl);
  for(let i=0;i<9;i++){const p=((t*.07+i*.113)%1),x=104-p*220,y=-66+((i*37)%132)+Math.sin(t*.8+i)*5,a=Math.sin(p*Math.PI)*.75;fm_snow(g,x,y,2.4+(i%3),t*.4+i,'#e6fbff',a)}}
 // the aurora curtain tail: silk ribbons rippling from the tail joint, bright at the root, fanning open as they dissolve
 const rib=(sp,hw,ph,len)=>{const P=[],W=[],n=16;for(let k=0;k<n;k++){const s=k/(n-1);P.push([-32-s*len,sp*(.16+1.1*s)+Math.sin(t*2.3*(1+fx*.6)-s*4.2+ph)*(2+7*s)*(1+fx*1.3)]);W.push(1.6+hw*Math.sin(Math.min(1,s*1.15)*Math.PI*.9)*(1-.35*s))}
  const R=fm_ribbon(g,P,W),h=150+28*Math.sin(t*.4+ph*1.3),x1=-32-len;R();
  g.fillStyle=fm_grad(g,-32,0,x1,0,[[0,'rgba(255,255,255,.98)'],[.16,fm_hsl(h,.95,76)],[.42,fm_hsl(h+40,.9,68)],[.7,fm_hsl(h+100,.72,70)],[1,fm_hsl(h+140,0,76)]]);g.fill();
  // a soft silk highlight running along the ribbon
  g.save();R();g.clip();g.lineCap='round';g.lineJoin='round';g.beginPath();P.forEach((p,i)=>{const y=p[1]-W[i]*.3;i?g.lineTo(p[0],y):g.moveTo(p[0],y)});
  g.strokeStyle=`rgba(255,255,255,${.14+.14*fm_tw(t,ph,1.6)})`;g.lineWidth=hw*.5;g.stroke();g.strokeStyle='rgba(255,255,255,.42)';g.lineWidth=1.1;g.stroke();g.restore();
  R();g.lineWidth=2;g.strokeStyle=fm_grad(g,-32,0,x1,0,[[0,'rgba(27,16,36,.95)'],[.7,'rgba(27,16,36,.75)'],[1,'rgba(27,16,36,0)']]);g.stroke();
  const e=P[n-3],k=fm_tw(t,ph*1.7,2.8);if(!SIL)fkSpark(g,e[0],e[1],2+3*k+gl*2,'#ffffff',.3+.6*k)};
 g.save();g.translate(-38,0);g.rotate(sw);g.translate(38,0);
 rib(-30,6,0,74);rib(30,6,2.4,74);rib(-13,8,.9,80);rib(13,8,3.1,80);rib(0,7.5,1.7,78);
 g.restore();

 // SIX crystal wings as two great layered fans: three roots clustered on each shoulder, the blades overlapping and
 // sweeping back (longest at the back) so each trio reads as one wing. The lower trio is the mirror image, trailing behind.
 const WG=[[4,-30,-2.9,90,262,0],[17,-30,-2.55,72,196,.55],[30,-30,-2.15,54,150,1.1]];
 WG.forEach(w=>{const a=w[2]+Math.sin(t*2.3*(1+fx*.8)+w[5]*1.4)*.075*(1+fx*.8);
  for(const s of [1,-1]){g.save();g.translate(w[0],s*w[1]);g.scale(1,s);g.rotate(a);fm_wing(g,t,s>0?w[3]:w[3]*.94,w[4]+(s<0?14:0),w[5]+(s<0?.3:0),gl);g.restore()}});
 // a short crystal dorsal ridge along the back between the wing roots
 [[-4,-31,7],[8,-35.5,9],[20,-37.5,8],[34,-38,6]].forEach((s,i)=>{const x=s[0],y=s[1],hh=s[2]+.6*Math.sin(t*2+i);fm_poly(g,[x-3.2,y+3,x-1.2,y-hh,x+3.4,y+3]);fkFill(g,fm_grad(g,0,y-hh,0,y+3,[[0,'#ffffff'],[.5,'#c8fff4'],[1,'#8fd8ff']]),1.8);
  g.beginPath();g.moveTo(x-1.2,y-hh+1.5);g.lineTo(x-.4,y+2);g.strokeStyle='rgba(255,255,255,.8)';g.lineWidth=.8;g.stroke()});
 // body: luminous white crystal with an aurora flowing inside it, tapering to a real tail joint at the back
 const BP=[100,1,93,-11,78,-25,56,-36,30,-39,6,-35,-12,-27,-26,-16,-34,-8,-40,-3,-43,1,-40,5,-34,10,-26,18,-12,29,6,35,30,38,56,34,78,24,93,12],B=()=>fkPath(g,BP);
 B();fkFill(g,fm_grad(g,0,-39,0,38,[[0,'#ffffff'],[.35,'#def2ff'],[.7,'#a4c2ff'],[1,'#7c7ce8']]),3);
 g.save();B();g.clip();
 for(let k=0;k<3;k++){const x=10+32*Math.sin(t*.55+k*2.1),y=-1+10*Math.sin(t*.8+k*1.7),r=30+6*Math.sin(t*.9+k),h=fm_hue(t*.6+k*2.1);
  g.fillStyle=fm_rgrad(g,x,y,0,r,[[0,fm_hsl(h,.9,56)],[.55,fm_hsl(h,.45,60)],[1,fm_hsl(h,0,70)]]);g.fillRect(x-r,y-r,r*2,r*2)}
 {g.beginPath();for(let x=-40;x<=98;x+=6){const y=-8+Math.sin(x*.07+t*1.6)*6;x===-40?g.moveTo(x,y-6):g.lineTo(x,y-6)}for(let x=98;x>=-40;x-=6){const y=-8+Math.sin(x*.07+t*1.6)*6;g.lineTo(x,y+9+Math.sin(x*.13+t)*3)}g.closePath();
  const h=fm_hue(t*.6+3);g.fillStyle=fm_grad(g,-40,0,98,0,[[0,fm_hsl(h+60,0,70)],[.2,fm_hsl(h+40,.5,64)],[.5,fm_hsl(h,.62,60)],[.82,fm_hsl(h-30,.4,68)],[1,fm_hsl(h-30,0,70)]]);g.fill()}
 // cut-crystal facets catching the light
 g.lineCap='round';g.lineJoin='round';
 g.fillStyle='rgba(255,255,255,.26)';fm_poly(g,[58,-36,40,-8,10,-36]);g.fill();fm_poly(g,[14,6,-14,2,-12,-26]);g.fill();
 g.fillStyle='rgba(110,100,220,.14)';fm_poly(g,[40,-8,60,24,18,38,14,6]);g.fill();fm_poly(g,[-14,2,14,6,-14,26]);g.fill();
 const F=[[[58,-36],[40,-8],[60,24]],[[40,-8],[10,-36]],[[40,-8],[14,6],[18,38]],[[14,6],[-12,-26]],[[14,6],[-14,26]],[[-12,-26],[-14,2],[-14,26]],[[-14,2],[-40,0]],[[40,-8],[64,-2]]];
 for(const f of F){g.beginPath();f.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.strokeStyle='rgba(90,100,210,.24)';g.lineWidth=2.6;g.stroke();g.strokeStyle='rgba(255,255,255,.8)';g.lineWidth=1.1;g.stroke()}
 // tiny sparkles inside the crystal
 for(let i=0;i<6;i++){const k=fm_tw(t,i*2.3,2.1);fkSpark(g,[-20,0,24,46,-4,30][i],[-8,18,-22,12,-16,22][i],1.6+2.2*k,'#ffffff',.35+.6*k)}
 g.restore();
 fkShade(g,B,8,38,'#5a4ad0',.32);
 // a modest inner body glow (capped so the crystal never blows out to a flat disc)
 fkGlow(g,22,-2,42,'#e8fdff',Math.min(.3,.16+.08*pu+gl*.06));
 // the soul-star: a crystal heart of light pulsing at its core, drawn after the body glow so it always stays readable
 {const k=.5+.5*Math.sin(t*2.2),x=22,y=1,r=9+2*k+gl*3;g.save();B();g.clip();g.globalCompositeOperation='lighter';
  g.fillStyle=fm_rgrad(g,x,y,0,r*1.8,[[0,'rgba(255,255,255,.7)'],[.4,fm_hsl(fm_hue(t*.8),.35+.2*k,70)],[1,fm_hsl(fm_hue(t*.8),0,70)]]);g.fillRect(x-r*2,y-r*2,r*4,r*4);g.restore();
  g.save();g.translate(x,y);g.rotate(Math.sin(t*.6)*.15);fm_poly(g,[0,-r,r*.28,-r*.28,r*.75,0,r*.28,r*.28,0,r,-r*.28,r*.28,-r*.75,0,-r*.28,-r*.28]);
  g.fillStyle=fm_grad(g,0,-r,0,r,[[0,'#ffffff'],[.5,fm_hsl(fm_hue(t*.8+1),.9,88)],[1,'#ffe0fa']]);g.fill();g.strokeStyle='rgba(120,100,230,.55)';g.lineWidth=1.2;g.stroke();
  g.beginPath();g.moveTo(0,-r);g.lineTo(0,r);g.moveTo(-r*.75,0);g.lineTo(r*.75,0);g.strokeStyle='rgba(255,255,255,.9)';g.lineWidth=.8;g.stroke();g.restore()}
 g.save();B();g.clip();B();g.strokeStyle='rgba(255,255,255,.92)';g.lineWidth=4.2;g.stroke();g.restore();
 fkHi(g,B,.85,3.4);
 // gill: a pale crystal seam
 g.save();B();g.clip();g.lineCap='round';g.beginPath();g.arc(86,-1,28,Math.PI*.72,Math.PI*1.26);g.strokeStyle='rgba(60,50,140,.45)';g.lineWidth=2.6;g.stroke();g.beginPath();g.arc(88,-1,28,Math.PI*.76,Math.PI*1.2);g.strokeStyle='rgba(255,255,255,.85)';g.lineWidth=1.2;g.stroke();g.restore();
 // a crystal gem clasp on the tail joint where the aurora curtain meets the body
 {const cx=-40,cy=1;fm_poly(g,[cx,cy-8,cx+5,cy,cx,cy+8,cx-5,cy]);fkFill(g,fm_grad(g,cx-5,cy-8,cx+5,cy+8,[[0,'#ffffff'],[.45,'#ffa8ec'],[1,'#9a6aff']]),2);
  g.beginPath();g.moveTo(cx,cy-8);g.lineTo(cx,cy+8);g.moveTo(cx-5,cy);g.lineTo(cx+5,cy);g.strokeStyle='rgba(255,255,255,.7)';g.lineWidth=.9;g.stroke();fkSpark(g,cx-1,cy-3,2.4+2*fm_tw(t,4,3),'#fff',.9)}
 // delicate pectoral crystal fin: pale mint, seated just behind the gill seam and angled back-down
 g.save();g.translate(58,10);g.rotate(2.9+Math.sin(t*3.1)*.12*(1+fx));g.scale(1,-1);fm_wing(g,t,26,162,2.1,gl,74,.3);g.restore();
 // eye: a deep aurora iris with a star catchlight and graceful lashes
 {const ex=74,ey=-9,er=11.5,ih=fm_hue(t*.6+1);const I=fm_rgrad(g,ex+2,ey+1,0,er*.7,[[0,fm_hsl(ih+60,1,84)],[.55,fm_hsl(ih,1,52)],[1,fm_hsl(ih+100,1,28)]]);
  g.save();g.lineCap='round';g.strokeStyle=FKO;g.lineWidth=2.2;for(const a of [-1.2,-.85,-.5]){g.beginPath();g.moveTo(ex+Math.cos(a)*er*1.02,ey+Math.sin(a)*er*1.02);g.lineTo(ex+Math.cos(a)*er*1.42,ey+Math.sin(a)*er*1.42-1);g.stroke()}g.restore();
  fkEye(g,ex,ey,er,I,.2);fkSpark(g,ex+4.5,ey-3,3.2+1.4*fm_tw(t,0,2.2),'#ffffff',.95);
  fm_poly(g,[ex-2,ey+15,ex+1.8,ey+19,ex-2,ey+24,ex-5.8,ey+19]);fkFill(g,fm_grad(g,ex-6,ey+15,ex+2,ey+24,[[0,'#ffffff'],[.5,'#ff9ae8'],[1,'#b46aff']]),1.6)}
 g.save();g.globalAlpha=.35;g.fillStyle=fm_rgrad(g,84,6,0,8,[[0,'#ff8ad8'],[1,'rgba(255,138,216,0)']]);g.beginPath();g.ellipse(84,6,8,5,0,0,TAU);g.fill();g.restore();
 g.beginPath();g.moveTo(98,4);g.quadraticCurveTo(94,9,89,7.5);g.strokeStyle=FKO;g.lineWidth=2.3;g.lineCap='round';g.stroke();
 // the halo-crown of aurora light floating above the brow: a full ring, tall crystal spikes on the far rim and small ones on the near rim
 {const cx=66+Math.sin(t*.9)*1.2,cy=-53+Math.sin(t*1.5)*1.6,rx=24,ry=7;
  if(!SIL)fkGlow(g,cx,cy-5,38,'#c8fff0',.2+.08*pu+gl*.3);
  g.save();g.translate(cx,cy);g.rotate(-.12);
  const ring=(a0,a1)=>{const hs=t*.7;g.beginPath();g.ellipse(0,0,rx,ry,0,a0,a1);g.strokeStyle=FKO;g.lineWidth=7;g.stroke();
   g.strokeStyle=fm_grad(g,-rx,0,rx,0,[[0,fm_hsl(fm_hue(hs),1,72)],[.33,fm_hsl(fm_hue(hs+1.4),1,74)],[.66,fm_hsl(fm_hue(hs+2.8),1,76)],[1,fm_hsl(fm_hue(hs+4.2),1,72)]]);g.lineWidth=4.2;g.stroke();
   g.beginPath();g.ellipse(0,-.7,rx,ry,0,a0,a1);g.strokeStyle='rgba(255,255,255,.8)';g.lineWidth=1.1;g.stroke()};
  const spike=(a,hh,w,h,lw)=>{const x=Math.cos(a)*rx,y=Math.sin(a)*ry;fm_poly(g,[x,y-hh,x+w,y-hh*.42,x,y+1,x-w,y-hh*.42]);fkFill(g,fm_grad(g,0,y+1,0,y-hh,[[0,fm_hsl(h,.95,62)],[.6,fm_hsl(h+30,.95,84)],[1,'#ffffff']]),lw);
   g.beginPath();g.moveTo(x,y-hh+1);g.lineTo(x,y);g.strokeStyle='rgba(255,255,255,.8)';g.lineWidth=.9;g.stroke();return [x,y-hh-1]};
  ring(Math.PI,TAU);
  [[.16,7],[.33,10],[.5,13],[.67,10],[.84,7]].forEach((s,i)=>{const p=spike(Math.PI+s[0]*Math.PI,s[1]*(1+.08*Math.sin(t*2.2+i)),2.8+s[1]*.1,fm_hue(t*.7+i*.9),1.6),k=fm_tw(t,i*1.3,3);fkSpark(g,p[0],p[1],2+3*k+gl*2,'#ffffff',.4+.6*k)});
  ring(0,Math.PI);
  [[.22,5],[.5,6.5],[.78,5]].forEach((s,i)=>spike(s[0]*Math.PI,s[1]*(1+.08*Math.sin(t*2.2+i+2)),2.1,fm_hue(t*.7+i*.9+2),1.4));
  if(!SIL)for(let i=0;i<4;i++){const p=(t*.4+i/4)%1;g.beginPath();g.arc(-14+i*9+Math.sin(t+i)*2,5+p*14,1.2*(1-p)+.4,0,TAU);g.fillStyle=`rgba(230,255,250,${(1-p)*.8})`;g.fill()}
  g.restore()}
 if(!SIL)for(let i=0;i<10;i++){const a=t*.22+i/10*TAU,x=-4+Math.cos(a)*108,y=Math.sin(a)*70,k=fm_tw(t,i*1.37,2.4);if(Math.abs(x)>112||Math.abs(y)>76)continue;
   fkSpark(g,x,y,(i%3?1.6:3)+2.6*k,i%2?'#d6fff4':'#f0e6ff',.3+.6*k)}
 g.restore()};

/* ---------- 15. Eclipse Leviathan: a cosmic leviathan, a starry galaxy behind black-and-gold armour ---------- */
const fm_r=i=>{const s=Math.sin(i*127.1+311.7)*43758.5453;return s-Math.floor(s)};
/* a drifting nebula tendril: spine from (x0,y0) along a gentle curve to (x1,y1), waving with t; w0 = root half width */
function fm_tendril(g,t,x0,y0,cx,cy,x1,y1,w0,ph,amp,c0,c1,fx){const P=[],W=[],n=14;
 for(let k=0;k<n;k++){const s=k/(n-1),u=1-s,x=u*u*x0+2*u*s*cx+s*s*x1,y=u*u*y0+2*u*s*cy+s*s*y1,wv=Math.sin(t*1.8*(1+fx*.8)-s*4+ph)*amp*s*(1+fx*1.5);P.push([x,y+wv]);W.push(w0*(1-s*.88))}
 const R=fm_ribbon(g,P,W);R();g.fillStyle=fm_grad(g,x0,y0,x1,y1,[[0,c0],[.55,c1],[1,'rgba(90,120,255,0)']]);g.fill();
 g.save();g.globalCompositeOperation='lighter';g.lineCap='round';g.beginPath();P.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));
 g.strokeStyle=fm_grad(g,x0,y0,x1,y1,[[0,'rgba(255,200,240,.7)'],[.7,'rgba(200,170,255,.25)'],[1,'rgba(200,170,255,0)']]);g.lineWidth=1.2;g.stroke();g.restore();
 return P}
/* a starry nebula fill inside the current clip, for fins */
function fm_nebfin(g,t,P,x0,y0,x1,y1,seed){P();g.fillStyle=fm_grad(g,x0,y0,x1,y1,[[0,'rgba(255,90,216,.95)'],[.45,'rgba(150,80,255,.85)'],[1,'rgba(70,110,255,.35)']]);g.fill();
 g.save();P();g.clip();g.globalCompositeOperation='lighter';
 const mx=(x0+x1)/2,my=(y0+y1)/2;g.fillStyle=fm_rgrad(g,mx,my,0,22,[[0,'rgba(255,170,230,.45)'],[1,'rgba(255,170,230,0)']]);g.fillRect(mx-24,my-24,48,48);
 for(let i=0;i<9;i++){const u=fm_r(seed+i),v=fm_r(seed+i+40),x=x0+(x1-x0)*u+(v-.5)*14,y=y0+(y1-y0)*u+(v-.5)*14,k=fm_tw(t,seed+i,2.4);g.beginPath();g.arc(x,y,.5+k*.9,0,TAU);g.fillStyle=`rgba(255,255,255,${.4+.6*k})`;g.fill()}
 g.restore()}
FISHART.eclipse=(g,t,o)=>{const fx=o.flex||0,gl=o.glow||0,SIL=(typeof FKSIL!=="undefined"&&g.canvas===FKSIL),sw=fkSway(o,2,.1),pu=.5+.5*Math.sin(t*1.4),bend=Math.sin(t*2.2)*fx*.05;
 g.save();g.translate(0,6+Math.sin(t*1.1)*1.2);g.rotate(-sw*.1+bend);
 const GOLD=(x0,y0,x1,y1)=>fm_grad(g,x0,y0,x1,y1,[[0,'#fff4c0'],[.45,'#ffc840'],[1,'#b06a10']]);
 const orbit=front=>{for(let i=0;i<9;i++){const a=t*.35+i/9*TAU,z=Math.sin(a);if((z>0)!==front)continue;const x=Math.cos(a)*110,y=z*44-Math.cos(a)*14,k=fm_tw(t,i*1.6,2.6),r=front?1:.6;
  if(Math.abs(x)>106)continue;g.beginPath();g.arc(x,y,(1.3+k)*r,0,TAU);g.fillStyle=i%3?'#ffe6a8':'#e8d8ff';g.globalAlpha=(.45+.5*k)*r;g.fill();g.globalAlpha=1;
  if(i%2===0)fkSpark(g,x,y,(3+3*k)*r+gl*2,i%3?'#fff2c8':'#f0e0ff',(.4+.5*k)*r)}};
 if(!SIL){g.save();g.scale(1,.6);fkGlow(g,-8,0,124,'#a04aff',.16+.06*pu+gl*.22);g.restore();orbit(false)}
 // dorsal: a tall swept nebula sail with a gold-capped black spine and tendrils streaming off it
 {const dw=Math.sin(t*1.6)*2*(1+fx);
  fm_tendril(g,t,-34,-58,-60,-64,-96,-66+dw,4.5,0,5,'rgba(255,110,220,.9)','rgba(140,90,255,.55)',fx);
  fm_tendril(g,t,-26,-46,-54,-50,-90,-50+dw,4,1.2,5,'rgba(220,100,255,.85)','rgba(110,110,255,.5)',fx);
  const P=()=>fm_path(g,['M',28,-30,'C',14,-46,-8,-60,-46,-70+dw,'C',-38,-56,-30,-42,-24,-24,'Z']);
  fm_nebfin(g,t,P,22,-30,-44,-68,10);P();g.lineWidth=2.4;g.strokeStyle=FKO;g.stroke();
  g.lineCap='round';g.beginPath();g.moveTo(27,-31);g.bezierCurveTo(14,-46,-8,-60,-46,-70+dw);g.strokeStyle='#0a0612';g.lineWidth=5.5;g.stroke();g.strokeStyle=GOLD(22,-30,-46,-70);g.lineWidth=2.2;g.stroke()}
 // anal tendril fin
 {fm_tendril(g,t,-36,18,-56,38,-90,52,4.5,2.1,5,'rgba(255,110,220,.85)','rgba(130,100,255,.5)',fx);
  fm_tendril(g,t,-24,22,-44,46,-74,66,3.8,3,5,'rgba(200,110,255,.8)','rgba(100,120,255,.45)',fx)}
 // tail: a wide lunar crescent of nebula edged with gilded black blades
 fm_at(g,-74,0,sw*.8,()=>{const tw=Math.sin(t*2*(1+fx*.6))*2*(1+fx);
  fm_tendril(g,t,-20,-42+tw,-28,-50,-26,-57,3.5,.5,4,'rgba(255,140,230,.9)','rgba(150,110,255,.5)',fx);
  fm_tendril(g,t,-20,40-tw,-28,48,-26,55,3.5,1.6,4,'rgba(255,140,230,.9)','rgba(150,110,255,.5)',fx);
  fm_tendril(g,t,-16,0,-24,2,-30,4,4,2.6,3,'rgba(255,150,230,.8)','rgba(140,110,255,.4)',fx);
  const P=()=>fm_path(g,['M',4,-6,'C',-8,-16,-18,-32,-22,-46+tw,'C',-22,-28,-19,-12,-16,0,'C',-19,12,-22,26,-22,44-tw,'C',-18,30,-8,15,4,6,'Z']);
  fm_nebfin(g,t,P,0,0,-28,0,30);P();g.lineWidth=2.6;g.strokeStyle=FKO;g.lineJoin='round';g.stroke();
  g.lineCap='round';for(const s of [1,-1]){const ty=s>0?-46+tw:44-tw;g.beginPath();g.moveTo(2,-6*s);g.bezierCurveTo(-8,-16*s,-18,-32*s,-22,ty);
   g.strokeStyle='#0a0612';g.lineWidth=5.5;g.stroke();g.strokeStyle=GOLD(0,-6*s,-22,ty);g.lineWidth=2.2;g.stroke()}
  const k=fm_tw(t,3,2.4);fkSpark(g,-22,-46+tw,2.5+3*k+gl*2,'#fff2c8',.5+.5*k);fkSpark(g,-22,44-tw,2.5+3*(1-k)+gl*2,'#fff2c8',.5+.5*(1-k))});
 // body: a deep colossal hull that is a window into a starry galaxy
 const BP=[106,4,101,-8,90,-20,70,-31,44,-36,14,-36,-16,-31,-42,-21.5,-62,-12,-76,-5.4,-80,0,-76,5.4,-62,12,-42,20,-16,28,14,33.5,44,35,70,29.5,90,20,101,13.5],B=()=>fkPath(g,BP);
 B();fkFill(g,fm_grad(g,0,-36,0,35,[[0,'#140636'],[.45,'#22094e'],[.8,'#2e0c5e'],[1,'#160632']]),3);
 g.save();B();g.clip();g.globalCompositeOperation='lighter';
 const NB=[[16,-5,40,'255,58,200',.5],[-20,6,42,'138,74,255',.55],[-54,-1,26,'58,122,255',.5],[40,9,20,'64,224,255',.22],[0,-2,16,'255,190,230',.38]];
 NB.forEach((n,i)=>{const x=n[0]+Math.sin(t*.4+i*1.7)*5,y=n[1]+Math.sin(t*.5+i)*3,a=Math.min(1,n[4]+gl*.3);g.fillStyle=fm_rgrad(g,x,y,0,n[2],[[0,`rgba(${n[3]},${a})`],[.5,`rgba(${n[3]},${a*.45})`],[1,`rgba(${n[3]},0)`]]);g.fillRect(x-n[2],y-n[2],n[2]*2,n[2]*2)});
 // a slowly turning spiral galaxy at its heart, bright enough to read at card size
 {g.save();g.translate(-6,1);g.scale(1,.5);g.rotate(t*.16);
  for(let arm=0;arm<3;arm++){let px=0,py=0;for(let i=1;i<=18;i++){const f=i/18,a=arm*TAU/3+f*3.6,r=2+f*36,x=Math.cos(a)*r,y=Math.sin(a)*r;
    g.beginPath();g.moveTo(px,py);g.lineTo(x,y);g.strokeStyle=`rgba(${f<.45?'255,228,246':'205,165,255'},${Math.min(1,(1-f)*.7+gl*.25)})`;g.lineWidth=(1-f)*6.5+1.2;g.stroke();px=x;py=y;
    if(i%3===0){g.beginPath();g.arc(x+Math.sin(i*3+arm)*3,y+Math.cos(i*5)*3,1,0,TAU);g.fillStyle='rgba(255,255,255,.85)';g.fill()}}}
  const cr=13+gl*6;g.fillStyle=fm_rgrad(g,0,0,0,cr,[[0,'rgba(255,253,245,1)'],[.3,`rgba(255,222,246,${.75+.25*gl})`],[1,'rgba(255,200,240,0)']]);g.beginPath();g.arc(0,0,cr,0,TAU);g.fill();g.restore()}
 // nebula wisps
 g.lineCap='round';[[60,-14,30,-24,0,-10,'255,120,220'],[-10,14,-40,22,-66,8,'150,120,255'],[48,17,24,22,4,12,'120,200,255']].forEach((w,i)=>{const d=Math.sin(t*.7+i)*3;g.beginPath();g.moveTo(w[0],w[1]);g.quadraticCurveTo(w[2],w[3]+d,w[4],w[5]);g.strokeStyle=`rgba(${w[6]},.3)`;g.lineWidth=6;g.stroke();g.strokeStyle=`rgba(${w[6]},.4)`;g.lineWidth=2;g.stroke()});
 // stars drifting past the window, twinkling
 for(let i=0;i<38;i++){const x=((fm_r(i)*190-t*3.5)%190+190)%190-82,y=-33+fm_r(i+99)*66,k=fm_tw(t,i*2.3,1.6+fm_r(i+7)*2.4),big=i%8===0;
  if(big)fkSpark(g,x,y,2.2+2.4*k+gl,'#ffffff',.5+.5*k);else{g.beginPath();g.arc(x,y,.5+.9*k*fm_r(i+3)+.3,0,TAU);g.fillStyle=`rgba(255,${240+((i*7)%15)},255,${.35+.6*k})`;g.fill()}}
 g.globalCompositeOperation='source-over';
 // black-and-gold armour framing the window: rows of gilded scutes along the back and belly, a collar at the tail
 const ty=x=>-36+(Math.abs(x-20)/92)**2*30,by=x=>33.5-(Math.abs(x-30)/86)**2*26;
 const scute=(x,yf,dir,d,w)=>{const y0=yf(x+w/2),P=()=>{g.beginPath();g.moveTo(x-1,y0-dir*14);g.lineTo(x-1,yf(x)+dir*d*.45);g.quadraticCurveTo(x+w*.5,y0+dir*d*1.25,x+w+1,yf(x+w)+dir*d*.45);g.lineTo(x+w+1,y0-dir*14);g.closePath()};
  P();g.fillStyle=fm_grad(g,x,y0-dir*4,x+w*.4,y0+dir*d,dir>0?[[0,'#3e2e58'],[.55,'#150c22'],[1,'#06030c']]:[[0,'#06030c'],[.5,'#150c22'],[1,'#34264a']]);g.fill();
  g.beginPath();g.moveTo(x-1,yf(x)+dir*d*.45);g.quadraticCurveTo(x+w*.5,y0+dir*d*1.25,x+w+1,yf(x+w)+dir*d*.45);g.strokeStyle='#05030a';g.lineWidth=3.4;g.stroke();g.strokeStyle=GOLD(x,y0,x+w,y0+dir*d);g.lineWidth=1.5;g.stroke();
  g.beginPath();g.arc(x+w*.5,y0+dir*d*.35,1.1,0,TAU);g.fillStyle='#ffd870';g.fill()};
 for(let x=-76;x<=60;x+=17)scute(x,ty,1,8.5,17);
 for(let x=-72;x<=58;x+=17)scute(x,by,-1,7.5,17);
 {const P=()=>fm_path(g,['M',-60,-36,'Q',-66,0,-60,36,'L',-90,36,'L',-90,-36,'Z']);P();g.fillStyle=fm_grad(g,-80,-10,-62,10,[[0,'#06030c'],[.6,'#1a1028'],[1,'#3a2a50']]);g.fill();
  g.beginPath();g.moveTo(-60,-36);g.quadraticCurveTo(-66,0,-60,36);g.strokeStyle='#05030a';g.lineWidth=4;g.stroke();g.strokeStyle=GOLD(-62,-20,-62,20);g.lineWidth=2;g.stroke();
  g.beginPath();g.moveTo(-68,-36);g.quadraticCurveTo(-73,0,-68,36);g.strokeStyle='rgba(255,210,110,.5)';g.lineWidth=1;g.stroke();
  g.beginPath();g.arc(-64.5,0,3,0,TAU);g.fillStyle=fkRad(g,-64.5,0,3,['#fffbe0','#ffcc40','#a85e08']);g.fill();g.strokeStyle='#05030a';g.lineWidth=1.3;g.stroke()}
 g.restore();
 // glassy sheen across the window
 g.save();B();g.clip();g.lineCap='round';g.beginPath();g.moveTo(-50,-15);g.quadraticCurveTo(0,-31,52,-22);g.strokeStyle='rgba(255,255,255,.16)';g.lineWidth=6;g.stroke();g.beginPath();g.moveTo(-36,-16);g.quadraticCurveTo(0,-26,40,-20);g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=1.6;g.stroke();g.restore();
 // the helm: black lacquer with gold trim over the head
 {const H=()=>{g.beginPath();g.moveTo(60,-44);g.quadraticCurveTo(44,0,58,44);g.lineTo(130,44);g.lineTo(130,-44);g.closePath()};
  g.save();H();g.clip();B();g.fillStyle=fm_grad(g,60,-30,80,30,[[0,'#3c2c56'],[.35,'#140c22'],[.75,'#07040e'],[1,'#1c1230']]);g.fill();
  // engraved gold filigree: a brow sweep and sun-ray lines
  g.lineCap='round';g.beginPath();g.moveTo(66,-19);g.quadraticCurveTo(80,-25,98,-12);g.strokeStyle=GOLD(66,-22,98,-12);g.lineWidth=1.6;g.stroke();
  g.beginPath();g.arc(74,6,5,Math.PI*.35,Math.PI*1.55);g.arc(76,5,4,Math.PI*1.45,Math.PI*.45,true);g.closePath();g.fillStyle='rgba(255,206,90,.75)';g.fill();fkSpark(g,82,2,2.2,'rgba(255,220,120,1)',.8);
  g.beginPath();g.moveTo(62,10);g.quadraticCurveTo(70,19,84,19);g.strokeStyle='rgba(255,206,90,.5)';g.lineWidth=1.2;g.stroke();
  // lacquer gloss
  g.beginPath();g.moveTo(70,-24);g.quadraticCurveTo(86,-22,99,-10);g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=2.4;g.stroke();g.restore();
  g.save();B();g.clip();g.beginPath();g.moveTo(60,-44);g.quadraticCurveTo(44,0,58,44);g.strokeStyle='#05030a';g.lineWidth=5;g.stroke();g.strokeStyle=GOLD(50,-30,56,30);g.lineWidth=2.4;g.stroke();
  g.beginPath();g.moveTo(64,-44);g.quadraticCurveTo(49,0,62,44);g.strokeStyle='rgba(255,210,110,.45)';g.lineWidth=1;g.stroke();g.restore()}
 fkHi(g,B,.4,2.6);
 B();g.lineWidth=3;g.strokeStyle=FKO;g.stroke();
 // catch spectacle: the gold trim ignites along the hull and the helm seam
 if(gl>0){g.save();B();g.clip();g.globalCompositeOperation='lighter';B();g.strokeStyle=`rgba(255,222,130,${.75*gl})`;g.lineWidth=6;g.stroke();
  g.beginPath();g.moveTo(60,-44);g.quadraticCurveTo(44,0,58,44);g.strokeStyle=`rgba(255,230,150,${.6*gl})`;g.lineWidth=4;g.stroke();g.restore()}
 // pectoral: a nebula fin with tendrils, in front
 {const pw=Math.sin(t*2.2)*2.4*(1+fx);
  fm_tendril(g,t,30,48+pw,4,58,-30,66,3.4,.8,5,'rgba(255,120,220,.9)','rgba(140,100,255,.5)',fx);
  const P=()=>fm_path(g,['M',64,14,'C',58,28,46,40,28,50+pw,'C',36,38,44,27,50,15,'Z']);fm_nebfin(g,t,P,60,14,28,48,60);P();g.lineWidth=2.3;g.strokeStyle=FKO;g.stroke();
  g.lineCap='round';g.beginPath();g.moveTo(63,15);g.bezierCurveTo(58,28,46,40,28,50+pw);g.strokeStyle='#0a0612';g.lineWidth=4.6;g.stroke();g.strokeStyle=GOLD(60,14,30,48);g.lineWidth=1.8;g.stroke()}
 // the jaw: a black lacquer lower-jaw plate hanging slightly open beneath the lip, gold-edged, with long gold fangs
 {const J=()=>fm_path(g,['M',70,16.5,'Q',87,17.5,104,11.5,'Q',107.5,18,99,25,'Q',87,31,75,27,'Q',68,23,70,16.5,'Z']);
  fm_path(g,['M',105,6,'Q',94,11,80,11.5,'Q',88,17.5,104,11.5,'Z']);g.fillStyle='#2a0a28';g.fill();
  J();fkFill(g,fm_grad(g,70,16,100,30,[[0,'#2c1e42'],[.5,'#0a0614'],[1,'#1c1230']]),2.4);
  g.save();J();g.clip();g.lineCap='round';g.beginPath();g.moveTo(70,17);g.quadraticCurveTo(87,18,104,12);g.strokeStyle=GOLD(70,16,104,11);g.lineWidth=2;g.stroke();
  g.beginPath();g.moveTo(74,22);g.quadraticCurveTo(86,25,97,22);g.strokeStyle='rgba(255,210,110,.45)';g.lineWidth=1;g.stroke();g.restore();
  g.lineCap='round';g.beginPath();g.moveTo(105,6);g.quadraticCurveTo(96,10.5,82,11);g.strokeStyle=FKO;g.lineWidth=2.6;g.stroke();
  for(const f of [[98,8.4],[90,10.2]]){fm_poly(g,[f[0]-2.6,f[1]-.4,f[0]+2.6,f[1]-1,f[0]+.4,f[1]+8]);fkFill(g,fm_grad(g,0,f[1],0,f[1]+8,[[0,'#fff6d8'],[1,'#ffd070']]),1.3)}
  for(const f of [[94,18.2],[85,18.6]]){fm_poly(g,[f[0]-1.8,f[1]+.6,f[0]+1.8,f[1]+.6,f[0],f[1]-4.5]);fkFill(g,'#fff0c0',1.1)}}
 // eye: glowing white, under a gold-lined brow plate
 {const ex=83,ey=-7;if(!SIL)fkGlow(g,ex,ey,20+gl*6,'#f4f0ff',.42+.16*pu+gl*.5);
  const E=()=>fm_path(g,['M',ex-9,ey+1,'Q',ex-1,ey-8,ex+9,ey-4,'Q',ex+3,ey+5.5,ex-9,ey+1,'Z']);E();fkFill(g,fm_rgrad(g,ex,ey-1,0,10,[[0,'#ffffff'],[.6,'#f4eeff'],[1,'#c8b4ff']]),2.2);
  g.save();g.globalCompositeOperation='lighter';E();g.fillStyle=`rgba(255,255,255,${.25+.25*pu+.3*gl})`;g.fill();g.restore();
  g.beginPath();g.moveTo(ex-11,ey-2);g.quadraticCurveTo(ex,ey-12,ex+12,ey-6);g.strokeStyle='#05030a';g.lineWidth=3.6;g.stroke();g.strokeStyle=GOLD(ex-10,ey-10,ex+12,ey-6);g.lineWidth=1.6;g.stroke();
  fkSpark(g,ex+2,ey-2,3+1.6*fm_tw(t,1,2)+gl*2,'#ffffff',.95)}
 // the crown: a solar eclipse held in a gilded cradle above the brow
 {const cx=52,cy=-51,R=14.5,rot=t*.12;
  g.save();g.globalCompositeOperation='lighter';
  if(!SIL){for(let i=0;i<20;i++){const a=rot+i*TAU/20,L=(i%2?24:32)*(1+.06*Math.sin(t*2+i*1.7))+gl*8;g.beginPath();g.moveTo(cx+Math.cos(a-.11)*R,cy+Math.sin(a-.11)*R);g.lineTo(cx+Math.cos(a)*L,cy+Math.sin(a)*L);g.lineTo(cx+Math.cos(a+.11)*R,cy+Math.sin(a+.11)*R);g.closePath();
    g.fillStyle=fm_rgrad(g,cx,cy,R,L,[[0,`rgba(255,236,170,${.9+.1*gl})`],[.5,`rgba(255,180,70,${.45+.25*gl})`],[1,'rgba(255,140,40,0)']]);g.fill()}
   g.fillStyle=fm_rgrad(g,cx,cy,R*.9,R*2.1,[[0,'rgba(255,250,220,1)'],[.18,`rgba(255,214,110,${.85+.15*gl})`],[.5,`rgba(255,150,60,${.32+.3*gl})`],[1,'rgba(255,120,40,0)']]);g.beginPath();g.arc(cx,cy,R*2.1,0,TAU);g.fill()}
  g.restore();
  if(!SIL)fkGlow(g,cx,cy,44+gl*8,'#ffc860',.22+.1*pu+gl*.35);
  // solar prominences: tangential flame licks of varied size, pink with a yellow core, curling off the rim
  {const rp=(an,r)=>[cx+Math.cos(an)*r,cy+Math.sin(an)*r];
   [[-.05,10,1],[2.75,12,-1],[4.2,6,1],[5.0,8,-1]].forEach((pr,i)=>{const a=pr[0]+Math.sin(t*.5+i)*.06,h=pr[1]*(1+.22*Math.sin(t*1.9+i*2)),d=pr[2];
    const lick=k=>{const b0=rp(a-.22*k,R-1),b1=rp(a+.14*k,R-1),tp=rp(a+d*.32*k,R+h*k),c0=rp(a-.06,R+h*.6*k),c1=rp(a+d*.38*k,R+h*.4*k);
     g.beginPath();g.moveTo(b0[0],b0[1]);g.quadraticCurveTo(c0[0],c0[1],tp[0],tp[1]);g.quadraticCurveTo(c1[0],c1[1],b1[0],b1[1]);g.closePath()};
    lick(1);g.fillStyle='rgba(255,92,200,.9)';g.fill();lick(.55);g.fillStyle='rgba(255,222,130,.95)';g.fill()})}
  // gilded horn prongs rising from the helm to hold the eclipse
  for(const d of [-1,1]){const bx=cx+d*7,P=()=>fm_path(g,['M',bx-d*5,-29,'C',bx+d*4,-35,cx+d*(R+9),cy+12,cx+d*(R+5),cy-7,'C',cx+d*(R+3.5),cy+6,bx+d*2,-33,bx+d*6,-27,'Z']);
   P();fkFill(g,fm_grad(g,bx,-29,cx+d*R,cy,[[0,'#06030c'],[.5,'#1c1230'],[1,'#3e2e58']]),2.3);
   g.save();P();g.clip();g.beginPath();g.moveTo(bx-d*3,-29);g.bezierCurveTo(bx+d*5,-35,cx+d*(R+8.5),cy+12,cx+d*(R+5),cy-6);g.strokeStyle=GOLD(bx,-29,cx+d*R,cy);g.lineWidth=2.2;g.stroke();g.restore();
   fkSpark(g,cx+d*(R+5),cy-8,2.6+2*fm_tw(t,d*3,2.4)+gl,'#ffe6a0',.9)}
  {const y=-32;g.beginPath();g.moveTo(cx-9,y+3);g.quadraticCurveTo(cx,y-6,cx+9,y+3);g.closePath();fkFill(g,'#120a1c',2);g.beginPath();g.arc(cx,y-.5,2.4,0,TAU);g.fillStyle=fkRad(g,cx,y-.5,2.4,['#ffd0f4','#ff5ad8','#a0208a']);g.fill();g.strokeStyle='#05030a';g.lineWidth=1.2;g.stroke()}
  // the black disc of the moon, rimmed in fire
  g.beginPath();g.arc(cx,cy,R,0,TAU);g.fillStyle=fm_rgrad(g,cx-3,cy-3,0,R,[[0,'#0a0614'],[.8,'#05030a'],[1,'#1e1030']]);g.fill();
  g.beginPath();g.arc(cx,cy,R,0,TAU);g.strokeStyle='#fff6d8';g.lineWidth=1.5;g.stroke();
  g.beginPath();g.arc(cx,cy,R-2,Math.PI*.9,Math.PI*1.5);g.strokeStyle='rgba(180,140,255,.35)';g.lineWidth=1.4;g.stroke();
  // the diamond ring flash
  {const a=-.75+Math.sin(t*.3)*.1,x=cx+Math.cos(a)*R,y=cy+Math.sin(a)*R,k=.5+.5*Math.sin(t*2.1);fkSpark(g,x,y,6+5*k+gl*4,'#ffffff',.95);fkSpark(g,x,y,3+2*k,'#fff6d0',1);
   g.beginPath();g.arc(x,y,2.2,0,TAU);g.fillStyle='#ffffff';g.fill()}}
 if(!SIL){orbit(true);if(gl>0)fkGlow(g,10,0,120,'#ffd8f4',.3*gl)}
 g.restore()};

/* update 7: when drawn as an undiscovered silhouette (o.sil), these fish skip additive light (auras, glows, rays), so the
   journal shows a clean solid outline instead of a hazy blob. Normal drawing is untouched. */
(()=>{const P=new WeakMap(),wrap=c=>{let p=P.get(c);if(!p){const F=new Map();p=new Proxy(c,{get(t,k){const v=t[k];if(typeof v!=='function')return v;let f=F.get(k);
  if(!f){f=(k==='fill'||k==='fillRect'||k==='stroke'||k==='strokeRect'||k==='drawImage')?function(){if(t.globalCompositeOperation==='lighter')return;return v.apply(t,arguments)}:v.bind(t);F.set(k,f)}return f},
  set(t,k,v){t[k]=v;return true}});P.set(c,p)}return p};
 ['seraph','eclipse'].forEach(id=>{const f=FISHART[id];if(f)FISHART[id]=(g,t,o)=>f(typeof FKSIL!=='undefined'&&FKSIL&&g.canvas===FKSIL?wrap(g):g,t,o)})})();
