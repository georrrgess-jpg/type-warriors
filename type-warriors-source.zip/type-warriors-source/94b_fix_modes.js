/* ===== 94b: UPDATE 8.7 fixes for the Runestone Riddle, Wildcard and the Warden's Arena =====
   Riddle
   - A3  The daily result is settled in the same save as the state change. rrEnter (92b) used to set e.st and save, and
         rrFinish paid (stats, streak, gold, e.c) only after the tile-flip delay, so a reload inside that delay kept "solved"
         but lost the payout. rrEnter now calls rrSettle before its save(); rrFinish keeps only the visuals. A load-time
         recovery (rrRecover) settles any day that has st 'w'/'l' but no c (saves hit by the old bug), exactly once because
         settling sets c. Practice riddles are untouched (they pay nothing).
   - A10 A daily entry never stores the answer: rrCur hands out the entry with `w` as a non-enumerable property (derived with
         rrWord(k) on every call), so JSON.stringify(P) leaves it out; a stale `w` on an unsolved day is stripped on load.
   - B2  The four dead Daily Challenge trophies (dc1, dc7, dcw5, dcS) now follow the daily Riddle stats (P.rr). Ids, tiers,
         rewards and earned state stay; names and texts change; they sit in a "Runestone Riddle" trophy tab.
   Wildcard
   - A5  The Game menu pauses solo and same-screen tables (WCPZ): wcLater timers freeze and resume with their remaining time,
         wcPump waits at the next event, wcStep is held, user moves are ignored. Online rooms and ranked are unaffected.
   - A8  wcAnim no longer throws after the table was left mid-animation (reduced motion fell through to $('wcdisc') = null).
   - B6  (89d) the +150 first-win bonus is paid only for staked games inside the 15-game daily cap.
   Arena
   - A7  Enter on the result screen presses the first button (Fight again); the menu track plays while the arena is paused or over
         (one line in mk(), 70_main.js). */

/* ---------------------------------------------------------------------------------------------------------------
   RIDDLE  A3 / A10
   --------------------------------------------------------------------------------------------------------------- */
/* the answer of a daily riddle is derived, never stored: keep `w` on the entry but out of JSON */
function rrHideW(e){try{const d=Object.getOwnPropertyDescriptor(e,'w');if(d&&'value' in d&&d.enumerable)Object.defineProperty(e,'w',{value:d.value,writable:true,configurable:true,enumerable:false})}catch(x){}}
{const c0=rrCur;rrCur=function(){const e=c0.apply(this,arguments);if(e&&typeof e==='object'&&RR&&RR.mode!=='p')rrHideW(e);return e}}
const RRREC={msg:''};
/* Settle a finished daily riddle: counters, streak, bonus, title, bounty, gold and e.c. Returns the payout breakdown the
   result card shows, or null when the day was settled already (e.c is a number). `late` = an older day than the last win
   (recovery only): it pays and counts, but leaves the streak alone. */
function rrSettle(e,k,win,late){if(!e||typeof e.c==='number')return null;
 const R=RRP(),n=e.g.length,res={win,n,base:0,cut:0,bonus:0,tot:0,title:0};
 R.pl++;
 if(win){R.wins++;R.dist[n-1]++;
  if(!late){R.st=(R.last===rrPrev(k)||R.last===k)?R.st+1:1;R.last=k;R.best=Math.max(R.best,R.st)}
  res.base=RR_PAY[n-1];res.tot=rrPay(n,e.pw);res.cut=res.base-res.tot;
  if(!late&&R.st%7===0){res.bonus=RR_BONUS7;res.tot+=RR_BONUS7}
  if(!late&&R.st>=RR_TITLE_DAYS&&!R.ttl){R.ttl=1;res.title=1;try{const B=BTY();B.own['t:riddlemaster']=1}catch(x){}}
  if(k===rrKey())try{btyAdd('daily',1)}catch(x){}}
 else{if(!late)R.st=0;res.base=RR_FAIL;res.tot=RR_FAIL}
 e.c=res.tot;e.cb=res.bonus;P.gold+=res.tot;try{stat('gold',res.tot,'add')}catch(x){}
 return res}
/* Trophies for a finished daily riddle are checked when its result card is closed (or the riddle is left), so a pop-up never
   covers the card. Nothing is lost if the page is reloaded first: achCheck runs again on the next start (end of this module). */
const RRACH={pend:false};
function rrAch(){RRACH.pend=false;try{achCheck()}catch(x){}}
{const c0=rrResClose;rrResClose=function(){const m=$('rrres'),was=!!(m&&!m.hidden),r=c0.apply(this,arguments);if(was&&RRACH.pend)setTimeout(rrAch,rrRM()?0:350);return r}}
{const b0=rrBack;rrBack=function(){const left=!!RR,r=b0.apply(this,arguments);if(left&&!RR&&RRACH.pend)setTimeout(rrAch,300);return r}}
/* the entry of Enter: same as 92b, but the result is settled before the single save() */
function rrEnter(){const e=rrCur();if(RR.busy||e.st!=='p')return;const g=RR.cur;rrKeyFlash('enter');
 if(g.length<5){rrShake();rrSfx('bad');rrToast('Not enough runes. A riddle word has five letters.');try{rrHostSay('short')}catch(x){}return}
 if(!rrValid(g)){rrShake();rrSfx('bad');rrToast(`“${g.toUpperCase()}” is not in the rune lexicon.`);try{rrHostSay('bad')}catch(x){}return}
 if(e.g.includes(g)){rrShake();rrSfx('bad');rrToast('You already carved that word.');return}
 const h0=RR.heat,r=e.g.length,s=rrScore(g,e.w),tk=RR.tk;e.g.push(g);RR.cur='';RR.res=null;const win=g===e.w,lose=!win&&e.g.length>=6;
 if(win||lose){e.st=win?'w':'l';if(RR.mode==='d')RR.res=rrSettle(e,RR.key,win,false)}
 save();if((win||lose)&&RR.mode==='d')RRACH.pend=true;
 RR.busy=true;const T=rrRow(r),rm=rrRM(),step=rm?0:270,half=rm?0:250;ov.querySelector(`#rrgrid .rrrw[data-r="${r}"]`).classList.remove('now');
 /* each tile flips in turn; its key on the keyboard fills in at the same moment */
 T.forEach((t,i)=>{t.classList.remove('cur','gh','pop');if(!rm)t.classList.add('flip');setTimeout(()=>{t.classList.add(s[i]);t.setAttribute('aria-label',g[i].toUpperCase()+', '+RR_SAY[s[i]]);rrSfx(s[i],i);rrKeyFill(g[i],s[i]);try{rrHeatPulse(s[i])}catch(x){}},i*step+half)});
 setTimeout(()=>{if(!RR||RR.tk!==tk)return;RR.busy=false;rrKeys(true);rrPowers();T.forEach(t=>t.classList.remove('flip'));rrHeatSet();rrResonate(RR.heat,RR.heat-h0,win);
  if(win||lose)rrFinish(win);else{rrTyping();rrPanel(true);try{rrHostReact(RR.heat,RR.heat-h0,s)}catch(x){}}},4*step+half*2+60)}
/* finishing a riddle: visuals only for a daily (the bookkeeping already happened in rrEnter); practice keeps its own counters */
function rrFinish(win){const R=RRP(),e=rrCur(),n=e.g.length,daily=RR.mode==='d';let res=null;
 if(daily){res=RR.res;if(typeof e.c!=='number'){res=rrSettle(e,RR.key,win,false);save()}}
 else{const Q=R.pr;Q.pl++;if(win){Q.wins++;Q.dist[n-1]++;Q.st++;Q.best=Math.max(Q.best,Q.st)}else Q.st=0;save();res={win,n,base:0,cut:0,bonus:0,tot:0,title:0}}
 RR.res=res;
 const sl0=$('rrarchw');if(sl0)sl0.classList.add(win?'awake':'dim');try{rrHostReact(win?1:0,0,null,win?'win':'lose')}catch(x){}
 if(win){rrSfx('win');const T=rrRow(n-1);if(!rrRM())T.forEach((t,i)=>setTimeout(()=>t.classList.add('won'),i*90));else T.forEach(t=>t.classList.add('won'));setTimeout(()=>rrBurst(T),rrRM()?0:420)}
 else{rrSfx('lose');const sl=$('rrarchw');if(!rrRM()){sl.classList.remove('rrq');void sl.offsetWidth;sl.classList.add('rrq')}}
 RR.busy=true;rrPanel(true);rrPowers();rrLegend();setTimeout(()=>{if(RR&&$('rr'))rrResult(true);if(RR)RR.busy=false},win?(rrRM()?200:1250):(rrRM()?200:950))}
/* Load-time recovery. A daily day with st 'w'/'l' but no c was hit by the old order (saved, then paid after the flip): settle it
   once, oldest first. Also drops a stale answer from unsolved days (A10). Needs no DOM; safe to run on every load. */
function rrRecover(){const R=P&&P.rr;if(!R||typeof R!=='object'||!R.d||typeof R.d!=='object'||Array.isArray(R.d))return 0;let n=0,paid=0,lateWin=false;
 for(const k of Object.keys(R.d)){const e=R.d[k];if(e&&typeof e==='object'&&(!e.st||e.st==='p')&&'w' in e){delete e.w;n++}}
 const ks=Object.keys(R.d).filter(k=>{const e=R.d[k];return /^\d{4}-\d{2}-\d{2}$/.test(k)&&e&&typeof e==='object'&&(e.st==='w'||e.st==='l')&&typeof e.c!=='number'&&Array.isArray(e.g)&&e.g.length>=1&&e.g.length<=6}).sort();
 for(const k of ks){const e=R.d[k];try{const Rr=RRP(),late=!!Rr.last&&k<=Rr.last,win=e.st==='w';if(!e.pw||typeof e.pw!=='object')e.pw={r:0,s:0};
   const g0=P.gold,r=rrSettle(e,k,win,late);if(r){n++;paid+=P.gold-g0;if(win&&late)lateWin=true}}catch(x){}}
 if(lateWin&&R.last){let c=0,kk=R.last;while(R.d[kk]&&R.d[kk].st==='w'&&c<4000){c++;kk=rrPrev(kk)}R.st=Math.max(R.st||0,c);R.best=Math.max(R.best||0,R.st)}
 if(paid>0)RRREC.msg=`Restored ${rrFmt(paid)} coins from a riddle result that was interrupted.`;
 if(n){try{save()}catch(x){}}
 return n}
{const l0=load;load=function(){const r=l0.apply(this,arguments);try{rrRecover()}catch(x){}return r}}
{const m0=rrMenu;rrMenu=function(){try{rrRecover()}catch(x){}const r=m0.apply(this,arguments);try{if(RRREC.msg){const m=RRREC.msg;RRREC.msg='';setTimeout(()=>{if(RR&&$('rr'))rrToast(m,4200)},900)}}catch(x){}return r}}
try{rrRecover()}catch(x){}

/* ---------------------------------------------------------------------------------------------------------------
   B2  the four Daily Challenge trophies follow the daily Riddle stats
   --------------------------------------------------------------------------------------------------------------- */
{const RS=()=>(P&&P.rr&&typeof P.rr==='object'?P.rr:{});
 const T=(id,n,d,tg,v)=>{const a=ACH.find(x=>x.id===id);if(a)Object.assign(a,{cat:'Runestone Riddle',n,d,tg,v})};
 T('dc1','Riddle Apprentice','Solve your first daily Runestone Riddle.',1,()=>RS().wins|0);
 T('dc7','Rune Regular','Reach a 7-day Runestone Riddle streak.',7,()=>Math.max(RS().best|0,RS().st|0));
 T('dcw5','Stone Scholar','Solve 5 daily Runestone Riddles.',5,()=>RS().wins|0);
 T('dcS','Rune Whisperer','Solve a daily Runestone Riddle in 1 or 2 guesses.',1,()=>{const d=RS().dist;return Array.isArray(d)?(d[0]|0)+(d[1]|0):0});
 if(!ACAT.includes('Runestone Riddle'))ACAT.splice(Math.max(0,ACAT.indexOf('Campaign'))+1,0,'Runestone Riddle');
 /* players who already solved riddles earn these on the next trophy check; do it once the home screen is up */
 setTimeout(()=>{try{achCheck()}catch(x){}},1800)}

/* ---------------------------------------------------------------------------------------------------------------
   WILDCARD  A5: the Game menu pauses a solo or same-screen table
   The menu is the #wcmod modal with the .wcmn card. While it is open (and for a How-to opened from it, which reuses the same
   modal) nothing moves on its own: wcLater timers freeze and carry on with the time they had left, wcPump waits before the
   next event, wcStep is held until Resume, and user moves are ignored. Online rooms (WX.mode 'net') and ranked (15-second turns)
   are never paused. "Paused" is derived from the DOM, so a table that was left or rebuilt cannot stay paused.
   --------------------------------------------------------------------------------------------------------------- */
const WCPZ={menu:false,mod:null,obs:null,on:false,recs:new Set(),gates:[],stepPend:false,stepTok:-1};
const wcCanPause=()=>!!(WX.G&&WX.host&&!WX.rk&&WX.mode!=='net');
const wcPaused=()=>{if(!WCPZ.menu)return false;const m=$('wcmod');
 if(!m||m!==WCPZ.mod||m.hidden){WCPZ.menu=false;return false}   /* closed, or the table was rebuilt or left */
 return wcCanPause()};
function wcGateFlush(){const g=WCPZ.gates.splice(0);for(const x of g)x.res()}
/* freeze: stop every pending timer and remember what it had left; thaw: start them again with that time */
function wcPauseSync(){const p=wcPaused();
 if(p&&!WCPZ.on){WCPZ.on=true;const now=performance.now();for(const r of WCPZ.recs)if(r.id){clearTimeout(r.id);r.left=Math.max(0,r.due-now);r.id=0}}
 else if(!p&&WCPZ.on){WCPZ.on=false;for(const r of [...WCPZ.recs])if(!r.id){if(r.tok===WX.tok)r.arm(r.left);else WCPZ.recs.delete(r)}}
 if(!p){wcGateFlush();if(WCPZ.stepPend){WCPZ.stepPend=false;if(WCPZ.stepTok===WX.tok&&!WX.busy&&$('wct')){try{wcStep()}catch(e){console.error(e)}}}}}
function wcLater(fn,ms){const tok=WX.tok,rec={fn,tok,id:0,due:0,left:ms};
 const fire=()=>{WCPZ.recs.delete(rec);rec.id=0;if(tok===WX.tok&&$('wct'))fn()};
 rec.arm=d=>{rec.due=performance.now()+d;rec.id=setTimeout(fire,d);WX.tm.push(rec.id)};
 const p=wcPaused();if(WCPZ.on&&!p)wcPauseSync();   /* the menu was closed a moment ago: thaw first */
 WCPZ.recs.add(rec);if(p)rec.left=ms;else rec.arm(ms);return rec.id}
{const c0=wcClear;wcClear=function(){const r=c0.apply(this,arguments);WCPZ.recs.clear();return r}}
{const m0=wcMenu;wcMenu=function(){const r=m0.apply(this,arguments);try{const m=$('wcmod');
  if(m&&!m.hidden&&m.classList.contains('wcmn')&&wcCanPause()){WCPZ.menu=true;if(WCPZ.mod!==m){if(WCPZ.obs)WCPZ.obs.disconnect();WCPZ.mod=m;WCPZ.obs=new MutationObserver(()=>wcPauseSync());WCPZ.obs.observe(m,{attributes:true,attributeFilter:['hidden']})}}
  wcPauseSync()}catch(e){console.error(e)}return r}}
{const s0=wcStep;wcStep=function(){if(wcPaused()){WCPZ.stepPend=true;WCPZ.stepTok=WX.tok;return}if(WCPZ.on)wcPauseSync();return s0.apply(this,arguments)}}
{const s0=wcSend;wcSend=function(){if(wcPaused())return;return s0.apply(this,arguments)}}
/* a new table, or leaving one, drops any pause that was left over */
{const t0=wcTable;wcTable=function(){const r=t0.apply(this,arguments);try{wcPauseSync()}catch(e){}return r}}
{const x0=wcExit;wcExit=function(){const r=x0.apply(this,arguments);try{WCPZ.menu=false;wcPauseSync()}catch(e){}return r}}
{const h0=wcHome;wcHome=function(){const r=h0.apply(this,arguments);try{WCPZ.menu=false;wcPauseSync()}catch(e){}return r}}
{const r0=wcReset;wcReset=function(){const r=r0.apply(this,arguments);try{WCPZ.menu=false;wcPauseSync()}catch(e){}return r}}

/* WILDCARD  A8: wcAnim runs through a gate (A5) and never throws because the table was left while a card was in the air.
   The base animation reads $('wcdisc') and friends after an await; with reduced motion the shorter chain falls through to it. */
{const a0=wcAnim;wcAnim=async function(e){const tok=WX.tok;
  try{while(wcPaused()&&tok===WX.tok&&$('wct'))await new Promise(res=>WCPZ.gates.push({res,tok}));
   if(tok!==WX.tok||!$('wct'))return;
   return await a0.apply(this,arguments)}
  catch(err){if(tok!==WX.tok||!$('wct'))return;throw err}}}

/* ---------------------------------------------------------------------------------------------------------------
   ARENA  A7: Enter on the result screen presses the first button (Fight again), like the result screens of the other modes.
   (The arena keeps S.mode 'arena' after the fight, so the generic result-screen key handler never runs.)  Music: see mk() in 70_main.js.
   --------------------------------------------------------------------------------------------------------------- */
addEventListener('keydown',e=>{if(e.key!=='Enter'||e.repeat||e.ctrlKey||e.metaKey||e.altKey||e.shiftKey)return;
 if(!S||S.mode!=='arena'||!S.wa||!S.wa.over||ov.className.indexOf('hide')>=0||performance.now()-SHOWT<900)return;
 const ae=document.activeElement;if(ae&&ae.tagName==='BUTTON'&&ov.contains(ae))return;   /* a focused button keeps its own Enter */
 const b=$('wa1');if(!b||b.disabled)return;e.preventDefault();e.stopImmediatePropagation();b.click()},true);
