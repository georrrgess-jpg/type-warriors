/* ---------- Halloween limited-time gear: data, armor art ----------
   Six armors and six weapons, one per rarity. They are only found in the Graveyard crate (or bought, for the two Mythics).
   Armor art plugs into the kit renderer through the HWH / HWC / HWFX / HWA / HWG hook tables (see 30c_head.js). */
const HWG_ID={a:['hwscare','hwgrave','hwwitch','hwvamp','hwpump','hwreap'],w:['hw_jack','hw_spade','hw_bat','hw_katana','hw_fang','hw_scythe']};
Object.assign(AR,{
 hwscare:{n:"Scarecrow's Rags",r:'Common',d:'+3% score',sc:1.03,m:'#a8824a',dk:'#5e4624',tr:'#e0c070',hw:1,w:1},
 hwgrave:{n:"Gravekeeper's Coat",r:'Uncommon',d:'+1 max HP, foes 3% slower',hp:1,sl:.97,m:'#3a4252',dk:'#151a24',tr:'#9fb4c8',acc:'#8aff9a',base:'leather',tier:1,hw:1,w:1},
 hwwitch:{n:"Witch's Regalia",r:'Rare',d:'+1 max HP, a starting shield, +4% score',hp:1,sh:1,sc:1.04,m:'#5a2f8a',dk:'#1e0e3a',tr:'#ffb84a',acc:'#c86bff',tier:2,hw:1,w:1},
 hwvamp:{n:"Vampire Lord's Raiment",r:'Epic',d:'+2 max HP, foes 8% slower, +5% score',hp:2,sl:.92,sc:1.05,m:'#6a0f1e',dk:'#17030a',tr:'#e8d8e0',acc:'#ff3a5a',tier:3,hw:1,w:1},
 hwpump:{n:'Pumpkin Knight Plate',r:'Legendary',d:'+3 max HP, a starting shield, +10% score',hp:3,sh:1,sc:1.1,m:'#d86a1a',dk:'#5a2408',tr:'#ffd070',acc:'#ffa030',base:'plate',tier:4,hw:1,w:1},
 hwreap:{n:"Reaper's Shroud",r:'Mythic',d:'+4 max HP, 3 shields, foes 12% slower, +20% score',hp:4,sh:3,sl:.88,sc:1.2,m:'#1a1426',dk:'#07040e',tr:'#b8ffd0',acc:'#5affb0',mythic:2,tier:4,hw:1,w:1}});
Object.assign(WP,{
 hw_jack:{n:"Jack-o'-Lantern Staff",r:'Common',d:'+10% gold',gm:.1,t:'staff',c:'#c86a22',p:'mage',nw:1,hw:1,w:1},
 hw_spade:{n:"Gravedigger's Spade",r:'Uncommon',d:'+5% crit chance',cr:.05,t:'axe',c:'#8a8e96',p:'knight',nw:1,hw:1,w:1},
 hw_bat:{n:'Batwing Bow',r:'Rare',d:'+8% crit chance',cr:.08,t:'bow',c:'#5a3a8a',p:'archer',nw:1,hw:1,w:1},
 hw_katana:{n:'Wraithbone Katana',r:'Epic',d:'Enemies 8% slower, +8% crit chance',sl:.92,cr:.08,t:'katana',c:'#e8e4d0',p:'rogue',nw:1,hw:1,w:1},
 hw_fang:{n:'Crimson Fang',r:'Legendary',d:'Faster combos, fury +25%, +20% score',cq:1,fu:1.25,sc:1.2,t:'sword',c:'#d8c4d0',p:'knight',nw:1,hw:1,w:1},
 hw_scythe:{n:'Soulreaper',r:'Mythic',d:'Slower foes, +45% score, fury +40%, faster combos, +10% crit',sl:.87,sc:1.45,fu:1.4,cq:1,cr:.1,t:'scythe',c:'#9affc8',h:150,p:'knight',nw:1,hw:1,w:1}});
for(const o of[WP,AR])for(const k in o)if(o[k].hw)o[k].col=RC[o[k].r];
/* Mythic Halloween gear gets its own spooky palette instead of the rainbow shimmer */
AR.hwreap.col='#5affb0';WP.hw_scythe.col='#5affb0';
Object.assign(AK,{
 hwscare:{mat:'cloth',leg:'cloth',helm:'sack',pauld:'soft',skirt:'rag',cape:'',pat:'patch',fx:'hwstraw',tier:0},
 hwgrave:{mat:'leather',leg:'leather',helm:'gkhat',pauld:'strap',skirt:'kilt',cape:'long',cc:'#1c222e',emb:'tomb',embc:'#9fb4c8',fx:'hwwisp',tier:1},
 hwwitch:{mat:'cloth',leg:'cloth',helm:'witch',pauld:'soft',skirt:'rag',cape:'tatter',cc:'#2a1450',emb:'moon',fx:'hwbats',pat:'sash',tier:2},
 hwvamp:{mat:'leather',leg:'leather',helm:'vamp',pauld:'spike',skirt:'tabard',tab:'#2a0610',cape:'royal',cc:'#3a0612',emb:'bat',aura:'hwvamp',tier:3},
 hwpump:{mat:'plate',leg:'plate',helm:'pumpkin',crest:'',pauld:'lames',skirt:'tassets',cape:'long',cc:'#2a1a10',emb:'jack',fx:'hwsparks',aura:'hwpump',tier:4},
 hwreap:{mat:'cloth',leg:'cloth',helm:'reaper',crest:'hwreap',pauld:'spike',skirt:'rag',cape:'tatter',cc:'#0b0716',emb:'skull',embc:'#5affb0',fx:'souls',aura:'hwreap',tier:4}});

/* ---------- shared bits ---------- */
const hwA=n=>Math.round(Math.max(0,Math.min(1,n))*255).toString(16).padStart(2,'0');
/* a smooth tube along a polyline, as a flat polygon for arBev: pts=[[x,y]..], wf(u)=half width */
function hwTube(P,wf){const n=P.length,L=[],R=[];for(let i=0;i<n;i++){const a=P[Math.max(0,i-1)],b=P[Math.min(n-1,i+1)];let dx=b[0]-a[0],dy=b[1]-a[1];const d=Math.hypot(dx,dy)||1,w=wf(i/(n-1));L.push(P[i][0]-dy/d*w,P[i][1]+dx/d*w);R.unshift(P[i][0]+dy/d*w,P[i][1]-dx/d*w)}return L.concat(R)}
/* a little ghost: round head, wavy tail, hollow eyes. s = size, al = opacity */
function hwGhost(g,x,y,s,t,col,al,eyec){g.save();g.translate(x,y);g.scale(s,s);g.globalAlpha=(al==null?.8:al);const w=Math.sin(t*5+x)*2;
 g.beginPath();g.moveTo(-6,2);g.bezierCurveTo(-7,-9,7,-9,6,2);g.lineTo(6.5,9+w*.3);g.quadraticCurveTo(4.2,6.5,3,10+w);g.quadraticCurveTo(1,6.5,-.4,10-w);g.quadraticCurveTo(-2,6.5,-3.4,9.5+w);g.quadraticCurveTo(-5,7,-6.5,9);g.closePath();
 g.fillStyle=col||'#e8fff0';g.fill();g.strokeStyle='#ffffff99';g.lineWidth=.7;g.stroke();
 ell(g,-2.2,-1.4,1.3,1.8,eyec||'#0a2a1a');ell(g,2.4,-1.4,1.3,1.8,eyec||'#0a2a1a');ell(g,0,2.6,1.2,1.7,eyec||'#0a2a1a');g.restore()}
/* upright jack-o'-lantern, centred at (x,y), r = half width */
function hwPumpkin(g,x,y,r,t,o){o=o||{};const lit=o.lit!==false,f=.84+.16*Math.sin(t*9+x*.7)+.06*Math.sin(t*23+x),P=o.c||'#e8741c';g.save();g.translate(x,y);g.scale(r/12,r/12);
 if(lit)glow(g,0,2,26,'#ff8a1a'+hwA(.5*f));
 ell(g,-7.4,2,5.6,9.4,shade(P,-.34));ell(g,7.4,2,5.6,9.4,shade(P,-.34));ell(g,-3.8,2,7,10.2,shade(P,-.14));ell(g,3.8,2,7,10.2,shade(P,-.14));
 {const old=OL;OL=0;ell(g,0,2,7.4,10.4,rgr(g,-2.5,-3,1,12,shade(P,.28),P));OL=old}
 g.strokeStyle=shade(P,-.45)+'aa';g.lineWidth=.9;for(const dx of[-5.4,0,5.4]){g.beginPath();g.moveTo(dx*.4,-7.6);g.quadraticCurveTo(dx*1.5,2,dx*.5,11.2);g.stroke()}
 g.strokeStyle='#ffd8a0aa';g.lineWidth=.8;g.beginPath();g.arc(0,2,9,Math.PI*1.12,Math.PI*1.4);g.stroke();
 g.fillStyle='#4a6a22';g.strokeStyle='#14240a';g.lineWidth=.9;g.beginPath();g.moveTo(-2.4,-7.4);g.quadraticCurveTo(-2.8,-12,.4,-13.6);g.lineTo(3.4,-12.4);g.quadraticCurveTo(1.4,-10.4,2.8,-7.4);g.closePath();g.fill();g.stroke();
 g.strokeStyle='#6a9a3a';g.lineWidth=1;g.beginPath();g.moveTo(3,-11);g.bezierCurveTo(7,-12,8,-8,5.4,-7.4);g.stroke();
 if(lit){const c1='#ffe27a',c2=f>.9?'#fff6b8':'#ffd040';g.fillStyle=c2;
  g.beginPath();g.moveTo(-6.4,-1.6);g.lineTo(-1.6,-1.2);g.lineTo(-4.2,-6);g.closePath();g.fill();g.beginPath();g.moveTo(1.6,-1.2);g.lineTo(6.4,-1.6);g.lineTo(4.2,-6);g.closePath();g.fill();
  g.beginPath();g.moveTo(0,.2);g.lineTo(-1.8,3.4);g.lineTo(1.8,3.4);g.closePath();g.fill();
  g.fillStyle=c1;g.beginPath();g.moveTo(-6.6,4.6);g.lineTo(-4.6,6.8);g.lineTo(-3.2,4.8);g.lineTo(-1.6,7.2);g.lineTo(0,5);g.lineTo(1.6,7.2);g.lineTo(3.2,4.8);g.lineTo(4.6,6.8);g.lineTo(6.6,4.6);g.lineTo(5.2,9.2);g.quadraticCurveTo(0,11.6,-5.2,9.2);g.closePath();g.fill();
  g.fillStyle=P;for(const tx of[-2.2,2.2]){g.fillRect(tx-.7,4.8,1.4,2.2)}
  g.strokeStyle='#5a1a04';g.lineWidth=.8;g.stroke()}
 g.restore()}
function hwBatShape(g,x,y,s,fl,col,eye){arBat(g,x,y,s,fl,col,eye)}

/* ---------- HELMS ---------- */
HWH.sack=(g,K,c,hx,hy)=>{const {t,T}=c,bur=K.sackc||'#c4a26a',dk=shade(bur,-.4);
 for(let i=0;i<9;i++){const a=Math.PI*(1.0+i*.12),x=hx-1+Math.cos(a)*13,y=hy-1+Math.sin(a)*14,l=6+(i%3)*3;limb(g,x,y,x+Math.cos(a)*l+Math.sin(t*2+i)*.9,y+Math.sin(a)*l+2,2,i%2?'#ecc858':'#c8a030')}
 arBevE(g,hx,hy,15.4,16.6,bur,{ow:1.2});
 g.save();g.beginPath();g.ellipse(hx,hy,15.4,16.6,0,0,TAU);g.clip();g.fillStyle='#00000026';g.fillRect(hx-17,hy-18,10,36);g.strokeStyle=dk+'66';g.lineWidth=.7;for(let i=-16;i<18;i+=2.6){g.beginPath();g.moveTo(hx+i,hy-18);g.lineTo(hx+i,hy+18);g.stroke()}for(let j=-18;j<18;j+=2.6){g.beginPath();g.moveTo(hx-17,hy+j);g.lineTo(hx+17,hy+j);g.stroke()}g.restore();
 g.save();g.setLineDash([2.2,2]);g.strokeStyle=dk;g.lineWidth=1;g.beginPath();g.moveTo(hx-5,hy-16);g.quadraticCurveTo(hx-9,hy,hx-4,hy+16);g.stroke();g.restore();
 /* patch */
 g.save();g.translate(hx-6,hy-7);g.rotate(-.12);arBev(g,[-4.4,-3.6,4.4,-3.8,4,3.8,-4.6,3.6],'#8a4a3a',{ow:.9});g.setLineDash([1.4,1.4]);g.strokeStyle='#e8d8a8';g.lineWidth=.8;g.strokeRect(-3.2,-2.6,6.4,5.2);g.restore();
 /* rope tie at the neck */
 arBev(g,[hx-10,hy+11.4,hx+13,hy+12,hx+13.4,hy+16.4,hx-10.4,hy+16],'#7a5a30',{ow:1});g.strokeStyle='#4a3418';g.lineWidth=.8;for(let i=0;i<7;i++){g.beginPath();g.moveTo(hx-9+i*3.4,hy+11.4);g.lineTo(hx-7+i*3.4,hy+16.2);g.stroke()}
 limb(g,hx+9,hy+15,hx+12,hy+22+Math.sin(t*3)*1,1.8,'#7a5a30');limb(g,hx+7,hy+15,hx+5,hy+22,1.8,'#7a5a30');
 /* face: X eye, nose, stitched mouth */
 g.strokeStyle='#241408';g.lineWidth=1.9;g.lineCap='round';const ex=hx+8.4,ey=hy-2;g.beginPath();g.moveTo(ex-3.2,ey-3.2);g.lineTo(ex+3.2,ey+3.2);g.moveTo(ex+3.2,ey-3.2);g.lineTo(ex-3.2,ey+3.2);g.stroke();
 poly(g,[hx+14.4,hy+.4,hx+19,hy+4,hx+14.2,hy+6.4],shade(bur,.06),'#00000099',1);
 g.strokeStyle='#241408';g.lineWidth=1.5;g.beginPath();g.moveTo(hx+3.6,hy+9.4);for(let i=0;i<6;i++)g.lineTo(hx+5+i*2,hy+9.4+(i%2?2.6:-.4));g.stroke();g.lineWidth=1;for(let i=0;i<4;i++){g.beginPath();g.moveTo(hx+5.4+i*2.6,hy+7.4);g.lineTo(hx+5.4+i*2.6,hy+11.6);g.stroke()}
 /* hat */
 const hb=K.hatc||'#6a4a2a';
 arBevE(g,hx-1,hy-10.4,21,4.8,hb,{ow:1.2});
 arBev(g,[hx-10.4,hy-11,hx-8.6,hy-21,hx-2,hy-24.4,hx+7,hy-23,hx+10.6,hy-11],shade(hb,.06),{sm:1,ow:1.2});
 arBev(g,[hx-10.4,hy-12,hx+10.8,hy-12.4,hx+10.4,hy-16,hx-10,hy-15.6],T,{ow:1});g.save();g.setLineDash([1.6,1.6]);g.strokeStyle='#4a3010';g.lineWidth=.7;g.beginPath();g.moveTo(hx-10,hy-14);g.lineTo(hx+10.4,hy-14.2);g.stroke();g.restore();
 for(let i=0;i<4;i++)limb(g,hx-18+i*1.8,hy-9.6+i*.6,hx-21+i*1.8,hy-6.4+i*.8+Math.sin(t*2+i)*.6,1.6,'#e8c850');
 /* a crow keeps watch on the hat */
 {const bob=Math.sin(t*3.1)*.5,cx=hx-3,cy=hy-26+bob;g.save();g.translate(cx,cy);
  poly(g,[-8,-1,-14,-5,-13,1,-7,3],'#1a1620');ell(g,0,0,7,4.6,'#1c1824');ell(g,-2,-1.2,4.6,2.2,'#3a3448');
  ell(g,5.6,-3.6+Math.sin(t*1.4)*.5,3.3,3.2,'#1c1824');poly(g,[8.4,-4.4,13.2,-3.2,8.4,-2.4],'#e89a30','#000a',.7);ell(g,6.6,-4.2,.95,.95,'#fff');ell(g,6.8,-4.2,.45,.45,'#000');
  limb(g,-1,3.6,-1,6,1.1,'#a07030');limb(g,2,3.6,2,6,1.1,'#a07030');g.restore()}};

HWH.gkhat=(g,K,c,hx,hy,face)=>{const {t,T,acc,tier}=c;
 face(hx+4,hy+2,11.8,13);
 /* shadow cast by the brim */
 g.save();g.beginPath();g.ellipse(hx+4,hy+2,11.8,13,0,0,TAU);g.clip();g.fillStyle='#050810aa';g.fillRect(hx-10,hy-12,30,13);g.restore();
 {const p=.7+.3*Math.sin(t*2.6);g.save();g.globalCompositeOperation='lighter';glow(g,hx+9.6,hy-1.4,9,acc+hwA(.32*p));g.restore()}
 /* scarf */
 arBev(g,[hx-14,hy+6,hx+14,hy+4.6,hx+15.6,hy+10,hx+11,hy+19.6,hx-12,hy+21],K.scarf||'#56626a',{sm:1,ow:1.2});g.strokeStyle='#00000040';g.lineWidth=.9;for(let i=0;i<4;i++){g.beginPath();g.moveTo(hx-12+i*7,hy+7);g.quadraticCurveTo(hx-9+i*7,hy+14,hx-12+i*6.6,hy+20);g.stroke()}
 arBev(g,[hx+6,hy+14,hx+13,hy+14.6,hx+11,hy+31+Math.sin(t*2.4)*1.4,hx+4,hy+29],shade(K.scarf||'#56626a',-.12),{ow:1});
 /* hat */
 arBevE(g,hx+1,hy-10,22.4,4.6,'#161c26',{ow:1.3,edge:shade('#161c26',.35),ew:1});
 arBev(g,[hx-10.4,hy-10.4,hx-9.6,hy-25,hx+11,hy-25.4,hx+12.4,hy-10.4],'#1d2431',{sm:0,ow:1.3});
 ell(g,hx+.8,hy-25,10.2,3.4,'#2a3446');
 arBev(g,[hx-10.4,hy-10.4,hx-10.2,hy-15.4,hx+12.6,hy-15.6,hx+12.4,hy-10.4],'#3a1a4a',{ow:1});
 arBev(g,[hx+3.4,hy-16.4,hx+9.2,hy-16.4,hx+9.2,hy-9.6,hx+3.4,hy-9.6],T,{ow:1,edge:shade(T,-.4),ew:1.4});g.fillStyle='#0a0e18';g.fillRect(hx+5,hy-14.6,2.8,3.6)};

HWH.witch=(g,K,c,hx,hy,face)=>{const {t,T,acc}=c,sw=Math.sin(t*3)*2;
 arBev(g,[hx-8,hy-9,hx-21-sw,hy+4,hx-25-sw*1.4,hy+27,hx-15,hy+30,hx-9,hy+22,hx-3,hy+8],'#241046',{sm:1,ow:1.2});
 face(hx+4,hy+1.6,11.4,13);
 g.fillStyle='#8a3a6a';g.beginPath();g.moveTo(hx+9,hy+8.2);g.quadraticCurveTo(hx+11.6,hy+9.6,hx+14.6,hy+8.2);g.quadraticCurveTo(hx+11.6,hy+10.4,hx+9,hy+8.2);g.fill();
 /* fringe under the brim */
 arBev(g,[hx-12,hy-6,hx-2,hy-7.4,hx+8,hy-6.6,hx+14.6,hy-8,hx+13.6,hy-2.8,hx+8,hy-4,hx+1,hy-3.6,hx-7,hy-3,hx-12,hy-2],'#241046',{sm:1,ow:1});
 /* hat */
 arBevE(g,hx+.6,hy-11,25.4,5.4,'#2c1650',{ow:1.3,edge:'#4a2a7a',ew:1.2});
 const spine=[[hx+1,hy-12],[hx-1.4,hy-26],[hx+1,hy-38],[hx+8,hy-46],[hx+19,hy-47+Math.sin(t*2.2)*1.2]];
 arBev(g,hwTube(spine,u=>13*Math.pow(1-u,.9)+.3),'#38206a',{sm:1,ow:1.3,edge:'#5a3a96',ew:1});
 arBev(g,[hx-11,hy-10.6,hx-10.4,hy-17,hx+12.6,hy-17.6,hx+12.8,hy-11.2],'#1a0a30',{ow:1.1});
 arBev(g,[hx+2.6,hy-18.4,hx+9.2,hy-18.6,hx+9.4,hy-10,hx+2.8,hy-9.8],T,{ow:1.1,edge:shade(T,-.4),ew:1.4});g.fillStyle='#1a0a30';g.fillRect(hx+4.7,hy-16.4,2.8,4.6);
 g.save();g.translate(hx-3,hy-30);g.fillStyle=T;g.globalAlpha=.8+.2*Math.sin(t*3);g.beginPath();for(let i=0;i<8;i++){const a=-Math.PI/2+i*Math.PI/4,r=i%2?1.4:4;g.lineTo(Math.cos(a)*r,Math.sin(a)*r)}g.closePath();g.fill();glow(g,0,0,8,T+'66');g.restore();
 glow(g,hx+19,hy-47,9,acc+hwA(.6*(.7+.3*Math.sin(t*4))))};

HWH.vamp=(g,K,c,hx,hy,face)=>{const {t,T,acc,M,D}=c,col1='#3a0a14',lin=M;
 /* tall collar behind the head */
 arBev(g,[hx-13,hy+25,hx-23,hy-6,hx-9,hy+3,hx-2,hy+19],col1,{sm:0,ow:1.2,edge:lin,ew:1.8});
 arBev(g,[hx-8,hy+23,hx-17,hy-2,hx-7,hy+6],lin,{ow:.9,flat:1});
 /* pale face */
 const fx=hx+4,fy=hy+1.8,rx=11.4,ry=13.2;
 ell(g,fx,fy,rx,ry,rgr(g,fx-5,fy-6,1,rx+7,'#eee4ec','#8a7a9a'));
 g.save();g.beginPath();g.ellipse(fx,fy,rx,ry,0,0,TAU);g.clip();g.fillStyle='#4a2a5a22';g.beginPath();g.ellipse(fx+rx*.5,fy+ry*.1,5,8,0,0,TAU);g.fill();g.restore();
 const ex=fx+rx*.42,ey=fy-1,pu=.75+.25*Math.sin(t*3);g.globalAlpha=pu;glow(g,ex,ey,9,acc+'88');g.globalAlpha=1;
 ell(g,ex,ey,3.8,2.7,'#2a0610');ell(g,ex+.5,ey,2.8,2,acc);ell(g,ex+.8,ey,.9,1.5,'#100');ell(g,ex-.4,ey-.8,.8,.7,'#ffd0d8');
 g.strokeStyle='#14040a';g.lineWidth=1.8;g.beginPath();g.moveTo(ex-3.8,ey-4.4);g.lineTo(ex+3.8,ey-2.4);g.stroke();
 poly(g,[fx+rx*.9,fy-.6,fx+rx*1.34,fy+4.8,fx+rx*.86,fy+5.6],'#d8ccd8','#000000a0',1);g.fillStyle='#6a4a8a30';g.beginPath();g.ellipse(fx+rx*.12,fy+ry*.34,4.6,3.4,0,0,TAU);g.fill();g.fillStyle='#4a2a6a38';g.beginPath();g.ellipse(ex-.4,ey+2.8,3.8,1.6,0,0,TAU);g.fill();
 g.strokeStyle='#5a2434';g.lineWidth=1.3;g.beginPath();g.moveTo(fx+rx*.3,fy+ry*.52);g.lineTo(fx+rx*.8,fy+ry*.5);g.stroke();
 poly(g,[fx+rx*.52,fy+ry*.51,fx+rx*.64,fy+ry*.51,fx+rx*.58,fy+ry*.51+3.8],'#ffffff','#00000066',.5);
 /* slicked hair with a widow's peak */
 g.beginPath();g.moveTo(hx-14,hy+2);g.bezierCurveTo(hx-16,hy-16,hx+8,hy-20,hx+15.4,hy-7);g.lineTo(hx+14,hy-4.4);g.lineTo(hx+9.4,hy-9.4);g.lineTo(hx+7,hy-2.6);g.lineTo(hx+3.6,hy-9.6);g.bezierCurveTo(hx-4,hy-10,hx-9,hy-5,hx-9.4,hy+4);g.closePath();g.fillStyle=hgr(g,hx-15,hx+15,'#2a2034','#07040c');g.fill();g.strokeStyle='#000000b8';g.lineWidth=1.2;g.stroke();
 g.strokeStyle='#ffffff30';g.lineWidth=.9;for(let i=0;i<3;i++){g.beginPath();g.moveTo(hx-6+i*3,hy-14+i*.6);g.quadraticCurveTo(hx+4+i*2,hy-17+i,hx+13,hy-8);g.stroke()}
 /* front collar */
 arBev(g,[hx+4,hy+25,hx+7,hy+9,hx+20,hy+2,hx+13.4,hy+16,hx+14,hy+24],col1,{ow:1.2,edge:lin,ew:1.8});
 arBev(g,[hx+8,hy+23,hx+9.6,hy+12,hx+17.4,hy+6],lin,{ow:.9,flat:1})};

HWH.pumpkin=(g,K,c,hx,hy)=>{const {t,T,M,D,acc}=c,P='#e8741c',f=.84+.16*Math.sin(t*9)+.06*Math.sin(t*23);
 /* iron gorget under the gourd */
 arBev(g,[hx-12,hy+11,hx+14,hy+12,hx+15,hy+23,hx-10,hy+23],shade(M,-.2),{ow:1.2,edge:T,ew:1.2});g.fillStyle=T;for(const rx of[-7,1,9])ell(g,hx+rx,hy+18,1.1,1.1,shade(T,.2));
 glow(g,hx+4,hy,34,'#ff8a1a'+hwA(.34*f));
 /* gourd lobes */
 ell(g,hx-10,hy,6.2,15.2,shade(P,-.4));ell(g,hx-5.4,hy,8.4,16.4,shade(P,-.22));
 ell(g,hx+9,hy+.6,7.2,15.2,shade(P,-.18));
 {const old=OL;OL=1.1;ell(g,hx+1,hy+.4,9.6,16.4,rgr(g,hx-3,hy-6,1,20,shade(P,.3),shade(P,-.06)));OL=old}
 g.strokeStyle=shade(P,-.5)+'bb';g.lineWidth=1;for(const d of[-6,0,6.4]){g.beginPath();g.moveTo(hx+1+d*.4,hy-15.4);g.quadraticCurveTo(hx+1+d*1.6,hy,hx+1+d*.5,hy+16);g.stroke()}
 g.strokeStyle='#ffe0b088';g.lineWidth=1;g.beginPath();g.arc(hx+1,hy+.4,13.4,Math.PI*1.08,Math.PI*1.34);g.stroke();
 /* stem and vine */
 arBev(g,[hx-3,hy-14.4,hx-3.6,hy-21,hx+1,hy-24,hx+5.4,hy-22,hx+4,hy-14.8],'#4a6a22',{sm:1,ow:1.1});
 g.strokeStyle='#7aaa3a';g.lineWidth=1.3;g.beginPath();g.moveTo(hx+4,hy-20);g.bezierCurveTo(hx+11,hy-24,hx+13,hy-17,hx+9,hy-16);g.stroke();leafG(g,hx-1,hy-14.8,-2.6,9,3.2,'#5a8a2a');
 /* carved face: it glows from inside */
 const lit=f>.9?'#fff0a0':'#ffd040',lit2='#ffb020';g.save();
 glow(g,hx+9,hy-3,9,'#ffc040'+hwA(.5*f));glow(g,hx+1,hy-3,8,'#ffc040'+hwA(.4*f));
 g.fillStyle=lit;g.strokeStyle='#4a1404';g.lineWidth=.9;
 g.beginPath();g.moveTo(hx+5,hy-1);g.lineTo(hx+13.8,hy-1.8);g.lineTo(hx+9.8,hy-9.6);g.closePath();g.fill();g.stroke();
 g.beginPath();g.moveTo(hx-5.6,hy-1);g.lineTo(hx+1.4,hy-1.2);g.lineTo(hx-2.6,hy-8);g.closePath();g.fill();g.stroke();
 g.beginPath();g.moveTo(hx+4.2,hy+2.4);g.lineTo(hx+1.4,hy+7.2);g.lineTo(hx+6.6,hy+7.2);g.closePath();g.fill();g.stroke();
 g.fillStyle=lit2;g.beginPath();g.moveTo(hx-6,hy+9.6);g.lineTo(hx-3.6,hy+12.4);g.lineTo(hx-1.4,hy+10);g.lineTo(hx+1.2,hy+13);g.lineTo(hx+3.6,hy+10.2);g.lineTo(hx+6,hy+13);g.lineTo(hx+8.4,hy+10);g.lineTo(hx+11,hy+12);g.lineTo(hx+13.6,hy+9.2);g.lineTo(hx+12,hy+16.4);g.quadraticCurveTo(hx+4,hy+20,hx-4.6,hy+16);g.closePath();g.fill();g.stroke();
 g.fillStyle=P;for(const tx of[-1,4.6,9.6]){g.fillRect(hx+tx-.9,hy+9.8,1.8,3.2)}g.restore()};

HWH.reaper=(g,K,c,hx,hy)=>{const {t,T,M,D,acc}=c,fl=.75+.25*Math.sin(t*5)+.1*Math.sin(t*13);
 /* the hood, with a ragged hem */
 arBev(g,[hx-17,hy+23,hx-23,hy+3,hx-18,hy-14,hx-5,hy-25,hx+10,hy-21,hx+19,hy-8,hx+17,hy+5,hx+10,hy+15,hx+15,hy+26,hx+6,hy+21,hx+1,hy+29,hx-5,hy+22,hx-10,hy+28],M,{sm:1,ow:1.3,edge:shade(M,.22),ew:1.4});
 ell(g,hx+4,hy+1,13.4,15,'#05030a');
 glow(g,hx+6,hy+1,26,acc+hwA(.16*fl));
 /* the skull */
 const sx=hx+5.4,sy=hy+1.4;
 ell(g,sx,sy-1.6,10.6,11.4,rgr(g,sx-3,sy-6,1,15,'#f4f0e0','#9a9484'));
 poly(g,[sx-5,sy+5,sx+8.6,sy+4,sx+8,sy+11.6,sx+4,sy+14,sx-3,sy+12],shade('#e8e2d0',-.08),'#00000099',1);
 g.strokeStyle='#3a362a';g.lineWidth=.8;for(let i=0;i<5;i++){g.beginPath();g.moveTo(sx-2+i*2.6,sy+6.4);g.lineTo(sx-2+i*2.6,sy+12.4);g.stroke()}g.beginPath();g.moveTo(sx-3,sy+9.4);g.lineTo(sx+8,sy+8.6);g.stroke();
 ell(g,sx+4.6,sy-1.4,3.6,4.2,'#06030a');ell(g,sx-3,sy-1.2,3.2,3.8,'#06030a');
 g.globalAlpha=fl;eye(g,sx+4.8,sy-1.2,1.9,acc);eye(g,sx-2.6,sy-1,1.5,acc);g.globalAlpha=1;
 poly(g,[sx+9,sy+3.4,sx+7.4,sy+7,sx+10.6,sy+6.6],'#05030a');
 g.strokeStyle='#00000055';g.lineWidth=.9;g.beginPath();g.moveTo(sx+2,sy-9);g.lineTo(sx+4,sy-4.4);g.stroke();
 /* hood rim over the brow, with a faint green inner edge */
 arBev(g,[hx-19,hy-3,hx-16,hy-18,hx-3,hy-25,hx+10,hy-22,hx+19,hy-9,hx+16,hy-5.4,hx+10,hy-12,hx+3,hy-14.4,hx-6,hy-10.6,hx-12,hy-4],M,{sm:1,ow:1.3,edge:acc+'aa',ew:1.4});
 g.strokeStyle=acc+hwA(.4*fl);g.lineWidth=1;g.beginPath();g.moveTo(hx-5,hy-10);g.quadraticCurveTo(hx+3,hy-14,hx+10,hy-11.6);g.stroke()};

/* ---------- crest: the spectral flame above the Reaper's hood ---------- */
HWC.hwreap=(g,K,c,hx,hy)=>{const {t,acc}=c;glow(g,hx,hy-28,34,acc+'33');
 for(const [dx,s,ph] of[[-11,.8,1],[0,1.25,0],[10,.9,2.2],[-4,.6,3.4]]){const w=Math.sin(t*6+ph)*3,bx=hx+dx,by=hy-19;g.globalAlpha=.78;poly(g,[bx-5*s,by,bx-4*s+w*.4,by-15*s,bx+w*1.4,by-31*s,bx+4*s+w*.4,by-15*s,bx+5*s,by],acc+'cc');g.globalAlpha=.9;poly(g,[bx-2.4*s,by,bx+w*.6,by-17*s,bx+2.4*s,by],'#e8fff2')}g.globalAlpha=1};

/* ---------- FX ---------- */
HWFX.hwstraw=(g,K,c,rise)=>{const {t}=c;rise(6,(i,u)=>{const x=Math.sin(i*5.3+t*.7)*26,y=-130+u*100;g.save();g.translate(x,y);g.rotate(t*1.6+i);g.globalAlpha=Math.sin(u*Math.PI)*.9;g.strokeStyle=i%2?'#ecc858':'#c8a030';g.lineWidth=1.4;g.beginPath();g.moveTo(-3.4,0);g.lineTo(3.4,0);g.stroke();g.restore()})};
HWFX.hwwisp=(g,K,c,rise)=>{const {t,acc}=c;rise(4,(i,u)=>{const x=Math.sin(i*4.7+t*.9)*28,y=-40-u*96;g.globalAlpha=Math.sin(u*Math.PI)*.8;glow(g,x,y,9,acc+'88');ell(g,x,y,1.8,1.8,'#eaffee')});g.globalAlpha=1};
HWFX.hwbats=(g,K,c)=>{const {t}=c;for(let i=0;i<2;i++){const a=t*.9+i*3.14,x=Math.cos(a)*44,y=-112+Math.sin(a*1.6)*14;if(Math.abs(x)<30)continue;arBat(g,x,y,.62,Math.sin(t*14+i*2),'#2a1038','#ff4a60')}};
HWFX.hwsparks=(g,K,c,rise)=>{const {t}=c;rise(9,(i,u)=>{const x=Math.sin(i*4.1+t*1.2)*20+6,y=-110-u*70;g.globalAlpha=Math.sin(u*Math.PI)*.95;ell(g,x,y,1.6*(1-u)+.5,1.6*(1-u)+.5,i%2?'#ffd060':'#ff8a2a')});g.globalAlpha=1};

/* ---------- AURAS ---------- */
HWA.hwvamp=(g,K,c,post,hx,hy,orb)=>{const {t,acc}=c;
 if(!post){arSmoke(g,t,'#1a0008',.5);glow(g,-4,-100,76,'#ff204030');
  for(let i=0;i<6;i++){const x=-34+i*14+Math.sin(t*.8+i)*5;g.globalAlpha=.18+.1*Math.sin(t+i);ell(g,x,-3+Math.sin(t*1.3+i)*1.5,20,5,'#d8a0b8')}g.globalAlpha=1}
 orb(3,-2,-96,56,16,1.05,(x,y,i,a,z)=>{arBat(g,x,y,.9+z*.18,Math.sin(t*15+i*2.2),'#2e0a14',acc)})};
HWA.hwpump=(g,K,c,post,hx,hy,orb)=>{const {t}=c;
 if(!post)glow(g,-2,-80,80,'#ff8a1a2a');
 orb(3,-2,-80,46,15,.85,(x,y,i,a,z)=>{hwPumpkin(g,x,y,5.4+z*1.2,t+i)})};
HWA.hwreap=(g,K,c,post,hx,hy,orb)=>{const {t,acc}=c;
 if(!post){arSmoke(g,t,'#04140c',.62);glow(g,-6,-102,104,acc+'36');
  ell(g,-6,-104,35,35,rgr(g,-15,-114,2,46,'#eafff2','#5a8a78'));g.globalAlpha=.3;for(const [x,y,r] of[[-17,-114,6.2],[3,-94,8],[-13,-90,4.2],[7,-112,3.2]])ell(g,x,y,r,r,'#3a6a58');g.globalAlpha=1;g.strokeStyle=acc+'66';g.lineWidth=1.6;g.beginPath();g.arc(-6,-104,35,0,TAU);g.stroke();
  g.save();g.globalAlpha=.9;const tb='#04070a';g.fillStyle=tb;g.beginPath();g.moveTo(-36,-80);g.lineTo(-30,-84);g.lineTo(-27,-98);g.lineTo(-23,-84);g.lineTo(-14,-88);g.lineTo(-14,-80);g.fill();g.restore()}
 orb(4,-2,-90,60,20,.7,(x,y,i,a,z)=>{hwGhost(g,x,y,.8+z*.22,t+i,'#dfffee',.5+z*.25,'#04140c')})};

/* ---------- emblem glyphs (about 18 units across, drawn centred) ---------- */
const hwGl=(g,col,fill,pathFn)=>{g.beginPath();pathFn();g.strokeStyle='#000000b0';g.lineWidth=3.6;g.stroke();if(fill){g.fillStyle=col;g.fill()}g.strokeStyle=col;g.lineWidth=fill?1:1.9;g.stroke()};
HWG.tomb=(g,col)=>{hwGl(g,col,0,()=>{g.moveTo(-6,9);g.lineTo(-6,-3);g.arc(0,-3,6,Math.PI,0);g.lineTo(6,9);g.closePath()});hwGl(g,col,0,()=>{g.moveTo(0,-5);g.lineTo(0,5);g.moveTo(-3.4,-1.4);g.lineTo(3.4,-1.4)})};
HWG.skull=(g,col)=>{hwGl(g,col,1,()=>{g.arc(0,-2,7.6,Math.PI*.82,Math.PI*.18);g.lineTo(4.6,9);g.lineTo(-4.6,9);g.closePath()});g.fillStyle='#06030a';for(const x of[-3,3])g.beginPath(),g.arc(x,-2,2,0,TAU),g.fill();g.beginPath();g.moveTo(0,2.4);g.lineTo(-1.4,5);g.lineTo(1.4,5);g.fill();g.strokeStyle='#06030a';g.lineWidth=.9;for(const x of[-2,0,2]){g.beginPath();g.moveTo(x,6.6);g.lineTo(x,9);g.stroke()}};
HWG.bat=(g,col)=>{hwGl(g,col,1,()=>{g.moveTo(0,-4);g.lineTo(2,-7);g.lineTo(3,-3.6);g.quadraticCurveTo(7,-6,11,-3);g.quadraticCurveTo(9,-1,9.6,3);g.quadraticCurveTo(6,1,5,4.6);g.quadraticCurveTo(3,2,0,8);g.quadraticCurveTo(-3,2,-5,4.6);g.quadraticCurveTo(-6,1,-9.6,3);g.quadraticCurveTo(-9,-1,-11,-3);g.quadraticCurveTo(-7,-6,-3,-3.6);g.lineTo(-2,-7);g.closePath()})};
HWG.jack=(g,col)=>{hwGl(g,col,1,()=>{g.ellipse(0,1.2,9,7.6,0,0,TAU)});g.fillStyle='#2a1204';g.beginPath();g.moveTo(-5,-1.6);g.lineTo(-1.6,-1.4);g.lineTo(-3.4,-4.6);g.closePath();g.fill();g.beginPath();g.moveTo(1.6,-1.4);g.lineTo(5,-1.6);g.lineTo(3.4,-4.6);g.closePath();g.fill();g.beginPath();g.moveTo(-5,3);g.lineTo(-2.6,5.2);g.lineTo(0,3.4);g.lineTo(2.6,5.2);g.lineTo(5,3);g.lineTo(3.6,6.4);g.lineTo(-3.6,6.4);g.closePath();g.fill();g.fillStyle='#6aa03a';g.fillRect(-1,-8,2.4,3.4)};
