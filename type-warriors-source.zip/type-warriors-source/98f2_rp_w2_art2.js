/* ===== RUNESTONE TOWER DEFENSE 10.0: World 2 art, part 2 - Shipwreck Cove, Kraken's Maw, the world painting (98f2) =====
   Uses the toolkit of 98f (the water field, the per-pixel painter, the road, the props, the castles and the shared live helpers).
   - wreck: rpw2aWreckBake (dark cove water, sea stacks, the galleon at map.ship, a plank boardwalk with rope railings, lanterns, camps,
     shacks on stilts, dead trees, the skull rock, the Corsair Fort), rpw2aWreckAmb (water, swaying masts and the black flag, the cannon
     barrel aimed at R.cannon's target, lantern light, low mist) and rpw2aWreckTop (the fog banks of R.fog over the monsters, then the
     cannon's flash, smoke, ball and impact from R.cannon.fire 0..1).
   - abyss: rpw2aAbyssBake (the sea floor, the trench at map.lake with its glowing lip and veins, a sunken causeway, glowing coral,
     anemones, ruins, glowcaps at map.glow, the Sunken Palace), rpw2aAbyssAmb (light shafts, glow pulses, the Kraken's eye watching the
     leading monster, six tentacles, swaying kelp, bubbles, plankton) and rpw2aAbyssTwist (glowcap light pools, whirlpools at map.whirl).
   - rpw2aWorld: the World 2 painting for the hub (RPW.world[2]) and rpw2aIcon, the map pictures (RPW.icon). */
/* ---------- Shipwreck Cove ---------- */
const RPW2A_WR={l0:rpw2aCol('#4c5c52'),l1:rpw2aCol('#66786a'),moss:rpw2aCol('#3e6a4a'),sand:rpw2aCol('#8a8068'),wet:rpw2aCol('#3a4642'),floor:rpw2aCol('#3a5450'),floorD:rpw2aCol('#122a34'),
 w0:rpw2aCol('#4a8a8a'),w1:rpw2aCol('#2a6470'),w2:rpw2aCol('#173e50'),w3:rpw2aCol('#0c2234'),rim:rpw2aCol('#141e22')};
const RPW2A_WPAL={tree:['#24463e','#2e5a4c','#1a3630'],treeHi:'#7aa894',trunk:'#3a2a20',rock:'#56606a',rockHi:'#8a96a2'};
function rpw2aWreckSea(x,y){const nz=(rpw2aVN(x/70,y/70+7)-.5)*34+Math.sin(x*.027+y*.019)*7;
 let f=(118+18*Math.sin(x*.011+2)+12*Math.sin(x*.031))-y;/* the misty sea along the top */
 f=rpw2aSmax(f,rpw2aEll(x,y,820,800,470,300),60);/* the cove */
 f=rpw2aSmax(f,y-(790+14*Math.sin(x*.02)),40);
 f=rpw2aSmax(f,rpw2aEll(x,y,1560,760,260,200),40);
 return f+nz}
/* props */
function rpw2aBarrel(g,x,y,s,i,side){g.save();g.translate(x,y);rpw2aBlob(g,s*.1,1,s*.5,s*.16,'#000',.25);
 if(side){g.rotate(side);g.beginPath();g.ellipse(0,-s*.35,s*.6,s*.36,0,0,TAU);g.fillStyle='#7a4e2a';g.fill();rpw2aOut(g,2);g.strokeStyle='#3a3036';g.lineWidth=2;g.beginPath();for(const u of[-.35,.35]){g.moveTo(s*u,-s*.68);g.lineTo(s*u,-s*.02)}g.stroke();
  g.beginPath();g.ellipse(s*.6,-s*.35,s*.12,s*.34,0,0,TAU);g.fillStyle='#a8723e';g.fill();rpw2aOut(g,1.6);g.restore();return}
 const w=s*.42,h=s*.9;g.beginPath();g.moveTo(-w,0);g.quadraticCurveTo(-w*1.18,-h/2,-w,-h);g.lineTo(w,-h);g.quadraticCurveTo(w*1.18,-h/2,w,0);g.closePath();
 const q=g.createLinearGradient(-w,0,w,0);q.addColorStop(0,'#a8723e');q.addColorStop(.4,'#8a5a30');q.addColorStop(1,'#5a3a1e');g.fillStyle=q;g.fill();rpw2aOut(g,2);
 g.strokeStyle='rgba(30,15,5,.5)';g.lineWidth=1;g.beginPath();for(const u of[-.4,0,.4]){g.moveTo(w*u,-h+2);g.quadraticCurveTo(w*u*1.12,-h/2,w*u,-2)}g.stroke();
 g.strokeStyle='#3a3640';g.lineWidth=2.6;g.beginPath();for(const v of[.18,.82]){g.moveTo(-w*1.08,-h*v);g.quadraticCurveTo(0,-h*v+3,w*1.08,-h*v)}g.stroke();
 g.beginPath();g.ellipse(0,-h,w,w*.32,0,0,TAU);g.fillStyle='#b8844e';g.fill();rpw2aOut(g,1.8);if(i%3===0){g.fillStyle='#e8e0cc';g.beginPath();g.arc(0,-h*.5,s*.1,0,TAU);g.fill()}g.restore()}
function rpw2aCrate(g,x,y,s,i){g.save();g.translate(x,y);rpw2aBlob(g,s*.1,1,s*.6,s*.16,'#000',.25);const w=s*.5,h=s*.8;
 g.fillStyle='#9a6a3a';g.fillRect(-w,-h,w*2,h);g.fillStyle='#b88450';g.beginPath();g.moveTo(-w,-h);g.lineTo(-w+s*.18,-h-s*.18);g.lineTo(w+s*.18,-h-s*.18);g.lineTo(w,-h);g.closePath();g.fill();rpw2aOut(g,1.8);
 g.fillStyle='#6a4426';g.beginPath();g.moveTo(w,0);g.lineTo(w+s*.18,-s*.18);g.lineTo(w+s*.18,-h-s*.18);g.lineTo(w,-h);g.closePath();g.fill();rpw2aOut(g,1.8);
 g.strokeStyle=RPO;g.lineWidth=2;g.strokeRect(-w,-h,w*2,h);g.strokeStyle='rgba(40,20,5,.55)';g.lineWidth=1.6;g.beginPath();g.moveTo(-w+3,-3);g.lineTo(w-3,-h+3);g.moveTo(-w,-h/2);g.lineTo(w,-h/2);g.stroke();g.restore()}
/* a lantern on a post; returns the light point */
function rpw2aLanternPost(g,x,y,h){g.save();g.translate(x,y);rpw2aBlob(g,3,1,10,4,'#000',.3);g.fillStyle='#4a3020';g.fillRect(-3,-h,6,h);g.strokeStyle=RPO;g.lineWidth=1.8;g.strokeRect(-3,-h,6,h);
 g.beginPath();g.moveTo(0,-h);g.lineTo(12,-h);g.lineTo(12,-h+4);g.stroke();g.fillStyle='#2a2228';g.fillRect(6,-h+4,12,3);g.strokeRect(6,-h+4,12,3);
 g.fillStyle='#ffd27a';g.fillRect(7.5,-h+7,9,11);g.strokeRect(7.5,-h+7,9,11);g.fillStyle='#fff4c0';g.fillRect(10,-h+9,4,7);g.fillStyle='#2a2228';g.fillRect(6,-h+18,12,3);g.strokeRect(6,-h+18,12,3);g.restore();return[x+12,y-h+12]}
function rpw2aAnchor(g,x,y,s,a){g.save();g.translate(x,y);g.rotate(a);g.strokeStyle=RPO;g.lineWidth=s*.16+3;const P=()=>{g.beginPath();g.moveTo(0,-s);g.lineTo(0,s*.55);g.moveTo(-s*.5,s*.2);g.quadraticCurveTo(0,s*.9,s*.5,s*.2);g.moveTo(-s*.3,-s*.62);g.lineTo(s*.3,-s*.62)};
 P();g.stroke();g.strokeStyle='#5a5a66';g.lineWidth=s*.16;P();g.stroke();g.beginPath();g.arc(0,-s*1.08,s*.14,0,TAU);g.strokeStyle=RPO;g.lineWidth=2.4;g.stroke();g.restore()}
function rpw2aBalls(g,x,y,s){for(const [dx,dy] of[[-1,0],[1,0],[0,0],[-.5,-.8],[.5,-.8],[0,-1.6]]){g.fillStyle='#2a2a34';g.beginPath();g.arc(x+dx*s,y+dy*s*.9,s*.55,0,TAU);g.fill();rpw2aOut(g,1.4);g.fillStyle='rgba(255,255,255,.3)';g.beginPath();g.arc(x+dx*s-s*.18,y+dy*s*.9-s*.18,s*.16,0,TAU);g.fill()}}
/* a pirate shack on stilts with a lamplit window; returns the window point */
function rpw2aShack(g,x,y,s,i){g.save();g.translate(x,y);rpw2aBlob(g,6,2,s*.8,s*.18,'#000',.3);
 g.fillStyle='#4a3020';for(const dx of[-.55,-.1,.45]){g.fillRect(dx*s-3,-s*.3,6,s*.3);g.strokeStyle=RPO;g.lineWidth=1.6;g.strokeRect(dx*s-3,-s*.3,6,s*.3)}
 g.fillStyle='#6a4a2c';g.fillRect(-s*.62,-s*.36,s*1.24,s*.08);g.strokeRect(-s*.62,-s*.36,s*1.24,s*.08);
 const wall=()=>{g.beginPath();g.rect(-s*.5,-s*.86,s,s*.5)};wall();g.fillStyle='#7a5432';g.fill();g.save();wall();g.clip();g.strokeStyle='rgba(30,15,5,.55)';g.lineWidth=1.2;g.beginPath();for(let k=1;k<6;k++){g.moveTo(-s*.5+k*s/6,-s*.86);g.lineTo(-s*.5+k*s/6+(rpw2aR(i+k)-.5)*3,-s*.36)}g.stroke();g.fillStyle='rgba(0,0,0,.25)';g.fillRect(s*.2,-s*.9,s*.4,s*.6);g.restore();wall();rpw2aOut(g,2);
 g.fillStyle='#3a2a1a';g.beginPath();g.moveTo(-s*.66,-s*.82);g.lineTo(0,-s*1.22);g.lineTo(s*.66,-s*.82);g.closePath();g.fill();rpw2aOut(g,2.2);g.strokeStyle='rgba(160,120,70,.5)';g.lineWidth=1.4;g.beginPath();for(let k=1;k<4;k++){g.moveTo(-s*.66+k*s*.08,-s*.82-k*s*.05);g.lineTo(s*.66-k*s*.08,-s*.82-k*s*.05)}g.stroke();
 g.fillStyle='#ffc46a';g.fillRect(-s*.32,-s*.72,s*.22,s*.18);g.strokeStyle=RPO;g.lineWidth=1.6;g.strokeRect(-s*.32,-s*.72,s*.22,s*.18);g.beginPath();g.moveTo(-s*.21,-s*.72);g.lineTo(-s*.21,-s*.54);g.stroke();
 g.fillStyle='#3a2414';g.fillRect(s*.08,-s*.7,s*.2,s*.34);g.strokeRect(s*.08,-s*.7,s*.2,s*.34);g.restore();return[x-s*.21,y-s*.63]}
/* a twisted dead tree with hanging moss */
function rpw2aDeadTree(g,x,y,h,i){g.save();g.translate(x,y);rpw2aBlob(g,h*.1,2,h*.3,h*.08,'#000',.3);const P=()=>{g.beginPath();g.moveTo(-h*.06,0);g.quadraticCurveTo(-h*.02,-h*.4,h*.05,-h*.62);g.moveTo(h*.01,-h*.35);g.quadraticCurveTo(-h*.2,-h*.5,-h*.3,-h*.72);
 g.moveTo(h*.04,-h*.55);g.quadraticCurveTo(h*.22,-h*.62,h*.3,-h*.86);g.moveTo(-h*.16,-h*.55);g.lineTo(-h*.1,-h*.8);g.moveTo(h*.05,-h*.62);g.lineTo(h*.02,-h*.9)};
 g.strokeStyle=RPO;g.lineWidth=h*.08+3;P();g.stroke();g.strokeStyle='#4a3a32';g.lineWidth=h*.08;P();g.stroke();g.strokeStyle='#6a5a4c';g.lineWidth=h*.025;P();g.stroke();
 g.strokeStyle='#5a7a54';g.lineWidth=2;for(const [mx,my] of[[-h*.22,-h*.6],[h*.18,-h*.66]]){g.beginPath();g.moveTo(mx,my);g.quadraticCurveTo(mx+3,my+h*.1,mx-1,my+h*.2);g.stroke()}g.restore()}
/* a pirate camp: barrels, crates, a powder keg and a pile of shot */
function rpw2aCamp(g,x,y,s,i){const L=[[-s*.5,-s*.1,'b'],[-s*.2,-s*.3,'b'],[s*.25,-s*.2,'c'],[s*.55,s*.05,'s'],[-s*.05,s*.12,'b2'],[s*.2,s*.18,'c2']].sort((a,b)=>a[1]-b[1]);
 for(const [dx,dy,k] of L){if(k==='b')rpw2aBarrel(g,x+dx,y+dy,20,i+dx|0);else if(k==='b2')rpw2aBarrel(g,x+dx,y+dy,19,i+1,.25);else if(k==='c')rpw2aCrate(g,x+dx,y+dy,22,i);else if(k==='c2')rpw2aCrate(g,x+dx,y+dy,17,i+2);else rpw2aBalls(g,x+dx,y+dy,4.5)}}
/* a skull-shaped sea rock */
function rpw2aSkullRock(g,x,y,s){g.save();g.translate(x,y);const C=['#7e8a96','#aab4be','#4a545e'];
 g.beginPath();g.moveTo(-s*.5,0);g.quadraticCurveTo(-s*.62,-s*.6,-s*.38,-s*.9);g.quadraticCurveTo(0,-s*1.12,s*.38,-s*.9);g.quadraticCurveTo(s*.62,-s*.6,s*.5,0);g.closePath();
 const q=g.createLinearGradient(-s*.6,0,s*.6,0);q.addColorStop(0,C[1]);q.addColorStop(.5,C[0]);q.addColorStop(1,C[2]);g.fillStyle=q;g.fill();rpw2aOut(g,2.6);
 g.fillStyle='#141820';for(const sx of[-1,1]){g.beginPath();g.ellipse(sx*s*.2,-s*.55,s*.13,s*.16,sx*.3,0,TAU);g.fill()}g.beginPath();g.moveTo(0,-s*.42);g.lineTo(-s*.06,-s*.3);g.lineTo(s*.06,-s*.3);g.closePath();g.fill();
 g.fillStyle='#141820';g.fillRect(-s*.24,-s*.2,s*.48,s*.08);g.strokeStyle=C[0];g.lineWidth=2;g.beginPath();for(let k=-2;k<=2;k++){g.moveTo(k*s*.09,-s*.2);g.lineTo(k*s*.09,-s*.12)}g.stroke();
 g.fillStyle='#3a6a4a';g.beginPath();g.ellipse(-s*.2,-s*.92,s*.22,s*.07,-.2,0,TAU);g.fill();g.restore()}
/* the wrecked galleon at map.ship (centre x, y, w, h): a high stern castle with lit gallery windows, a beakhead, two rows of gunports,
   a broken side, barnacles and weed, sunk to its waterline; the masts are live (rpw2aMastSpr) */
function rpw2aShip(g,sx,sy,W,H,A){g.save();g.translate(sx,sy);const k=W/330,kh=H/170;g.scale(k,kh);g.rotate(.045);
 rpw2aBlob(g,0,52,200,36,'#000',.3);
 const hull=()=>{g.beginPath();g.moveTo(-174,-44);g.quadraticCurveTo(-150,22,-96,46);g.lineTo(104,50);g.quadraticCurveTo(152,40,162,-20);g.lineTo(170,-96);g.lineTo(112,-92);g.lineTo(100,-70);
  g.quadraticCurveTo(30,-44,-36,-36);g.quadraticCurveTo(-96,-36,-112,-44);g.lineTo(-130,-58);g.lineTo(-164,-56);g.closePath()};
 /* bowsprit with a broken end and rope */
 g.strokeStyle=RPO;g.lineWidth=10;g.beginPath();g.moveTo(-150,-50);g.lineTo(-228,-100);g.stroke();g.strokeStyle='#8a5a32';g.lineWidth=6;g.stroke();g.strokeStyle='#c8b08a';g.lineWidth=1.4;g.beginPath();g.moveTo(-218,-92);g.quadraticCurveTo(-186,-46,-134,-44);g.moveTo(-200,-80);g.quadraticCurveTo(-160,-60,-120,-56);g.stroke();
 hull();let q=g.createLinearGradient(0,-96,0,50);q.addColorStop(0,'#9a6438');q.addColorStop(.45,'#74482a');q.addColorStop(1,'#3a2414');g.fillStyle=q;g.fill();
 g.save();hull();g.clip();
 const sheer=(o)=>{g.beginPath();g.moveTo(-190,-48+o);g.quadraticCurveTo(-110,-34+o*.95,-36,-30+o*.9);g.quadraticCurveTo(40,-40+o*1.05,180,-84+o*1.35);g.stroke()};
 g.strokeStyle='rgba(25,12,4,.55)';g.lineWidth=1.6;for(let j=1;j<11;j++)sheer(j*9);g.strokeStyle='rgba(255,220,170,.16)';g.lineWidth=1.3;for(let j=1;j<11;j++)sheer(j*9+1.6);
 /* the red band under the rail, the gold wale */
 g.strokeStyle='#a8302a';g.lineWidth=7;sheer(5);g.strokeStyle='#c8963a';g.lineWidth=3.2;sheer(14);g.strokeStyle='#e8c060';g.lineWidth=1.2;sheer(13);
 /* the stern castle: panelled, with gold frames and lit gallery windows */
 g.fillStyle='#5a3418';g.beginPath();g.moveTo(104,-74);g.lineTo(166,-92);g.lineTo(162,-22);g.lineTo(108,-8);g.closePath();g.fill();g.strokeStyle='#c8963a';g.lineWidth=2;g.stroke();
 for(const [wx,wy] of[[112,-62],[128,-67],[144,-72],[116,-38],[134,-42],[150,-46]]){g.fillStyle='#2a1408';g.beginPath();g.roundRect(wx-1.5,wy-1.5,13,15,[6,6,1,1]);g.fill();g.fillStyle='#ffc46a';g.beginPath();g.roundRect(wx,wy,10,12,[5,5,1,1]);g.fill();g.strokeStyle=RPO;g.lineWidth=1.4;g.stroke();
  g.strokeStyle='rgba(120,60,10,.6)';g.lineWidth=1;g.beginPath();g.moveTo(wx+5,wy);g.lineTo(wx+5,wy+12);g.stroke();A.lant.push([sx+(wx+5)*k,sy+(wy+7)*kh])}
 /* two rows of gunports */
 for(let r=0;r<2;r++)for(let j=0;j<(r?5:6);j++){const px=-116+j*36+r*14,py=-14+r*20-j*(r?1.4:2.2);g.fillStyle='#1a0e08';g.fillRect(px,py,13,10);g.strokeStyle='#c8963a';g.lineWidth=1.3;g.strokeRect(px,py,13,10);
  if((j+r)%2===0){g.fillStyle='#2a2a34';g.beginPath();g.ellipse(px+6.5,py+5,4.6,3.6,0,0,TAU);g.fill();g.fillStyle='#000';g.beginPath();g.arc(px+6.5,py+5,2,0,TAU);g.fill()}
  else{g.fillStyle='#6a4022';g.save();g.translate(px,py);g.rotate(-.5);g.fillRect(0,-11,13,11);g.strokeStyle=RPO;g.lineWidth=1.1;g.strokeRect(0,-11,13,11);g.restore()}}
 /* the broken side: a jagged hole with splintered planks */
 g.fillStyle='#120a06';g.beginPath();g.moveTo(-26,6);g.lineTo(-10,-12);g.lineTo(4,0);g.lineTo(20,-10);g.lineTo(40,8);g.lineTo(34,30);g.lineTo(12,38);g.lineTo(-18,32);g.closePath();g.fill();
 g.strokeStyle='#a87240';g.lineWidth=3.2;g.beginPath();g.moveTo(-10,-12);g.lineTo(-6,6);g.moveTo(20,-10);g.lineTo(16,8);g.moveTo(40,8);g.lineTo(28,14);g.moveTo(-26,6);g.lineTo(-12,12);g.stroke();
 /* barnacles, weed and moss low on the hull */
 for(let j=0;j<34;j++){const bx=-140+rpw2aR(j*3)*290,by=8+rpw2aR(j*3+1)*30;g.fillStyle=j%3?'#d8d0c0':'#a8a094';g.beginPath();g.arc(bx,by,1.6+rpw2aR(j)*2.2,0,TAU);g.fill()}
 g.strokeStyle='rgba(60,120,74,.8)';g.lineWidth=3;for(let j=0;j<11;j++){const bx=-150+j*30+rpw2aR(j)*10;g.beginPath();g.moveTo(bx,2+rpw2aR(j+4)*8);g.quadraticCurveTo(bx+4,20,bx-2,40);g.stroke()}
 /* sunk to the waterline: the water over the lower hull, with foam */
 g.fillStyle='rgba(22,62,78,.78)';g.beginPath();g.moveTo(-200,24);for(let x=-200;x<=200;x+=10)g.lineTo(x,22+Math.sin(x*.08)*2.5);g.lineTo(200,80);g.lineTo(-200,80);g.closePath();g.fill();
 g.restore();hull();rpw2aOut(g,3);
 g.strokeStyle='rgba(225,240,236,.9)';g.lineWidth=2.4;g.beginPath();for(let x=-150;x<=158;x+=4)g.lineTo(x,22+Math.sin(x*.08)*2.5);g.stroke();
 g.strokeStyle='rgba(225,240,236,.55)';g.lineWidth=1.6;g.beginPath();for(const [x0,x1,y] of[[-190,-150,30],[150,200,26],[-120,-60,40],[40,110,42]]){g.moveTo(x0,y);g.quadraticCurveTo((x0+x1)/2,y-4,x1,y)}g.stroke();
 /* the deck strip, broken rail posts */
 g.beginPath();g.moveTo(-160,-56);g.lineTo(-130,-58);g.lineTo(-112,-44);g.quadraticCurveTo(-96,-36,-36,-36);g.quadraticCurveTo(30,-44,100,-70);g.lineTo(100,-78);g.quadraticCurveTo(30,-52,-36,-44);g.quadraticCurveTo(-96,-44,-112,-52);g.lineTo(-130,-66);g.lineTo(-160,-64);g.closePath();
 g.fillStyle='#c09058';g.fill();rpw2aOut(g,2);g.strokeStyle='rgba(60,30,10,.45)';g.lineWidth=1;g.beginPath();for(let x=-150;x<100;x+=12){g.moveTo(x,-60);g.lineTo(x+2,-36)}g.stroke();
 g.fillStyle='#6a4426';g.strokeStyle=RPO;g.lineWidth=1.4;for(const x of[-150,-122,-80,-48,-6,40,72]){const y=x<-112?-58:x<0?-38-(x+36)*0:-44-(x)*.32;g.fillRect(x-2,y-10,4,10);g.strokeRect(x-2,y-10,4,10)}
 g.fillStyle='#7a4e2a';g.beginPath();g.moveTo(112,-92);g.lineTo(170,-96);g.lineTo(170,-104);g.lineTo(112,-100);g.closePath();g.fill();rpw2aOut(g,1.8);
 /* the stern lantern, the figurehead, the fore mast stump */
 g.strokeStyle=RPO;g.lineWidth=2;g.beginPath();g.moveTo(166,-100);g.lineTo(176,-116);g.stroke();g.fillStyle='#2a2228';g.fillRect(170,-116,12,4);g.fillStyle='#ffd27a';g.fillRect(171,-112,10,11);g.strokeRect(171,-112,10,11);A.lant.push([sx+176*k,sy-106*kh]);
 g.fillStyle='#e8d0a0';g.beginPath();g.ellipse(-176,-50,7,10,-.5,0,TAU);g.fill();rpw2aOut(g,1.6);g.fillStyle='#c8963a';g.beginPath();g.moveTo(-178,-40);g.lineTo(-170,-30);g.lineTo(-164,-42);g.closePath();g.fill();rpw2aOut(g,1.2);
 g.fillStyle='#6a4426';g.fillRect(-126,-92,11,42);g.strokeStyle=RPO;g.lineWidth=2;g.strokeRect(-126,-92,11,42);g.fillStyle='#c8a070';g.beginPath();g.moveTo(-127,-92);g.lineTo(-121,-102);g.lineTo(-116,-94);g.lineTo(-112,-98);g.lineTo(-115,-92);g.closePath();g.fill();g.stroke();
 g.restore()}
/* the live masts and sails: a main mast with a crow's nest and a torn sail, a broken mizzen with the black flag (sprites) */
function rpw2aMastSpr(k){return rpw2aSpr('mast'+k,k?90:140,k?150:200,g=>{if(k===0){g.translate(70,196);
  g.fillStyle='#6a4426';g.strokeStyle=RPO;g.lineWidth=2;g.fillRect(-4,-176,8,176);g.strokeRect(-4,-176,8,176);
  g.fillStyle='#7a5030';g.fillRect(-34,-150,68,6);g.strokeRect(-34,-150,68,6);
  const sail=()=>{g.beginPath();g.moveTo(-32,-144);g.lineTo(32,-144);g.quadraticCurveTo(38,-110,30,-84);g.lineTo(18,-92);g.lineTo(10,-78);g.lineTo(-2,-90);g.lineTo(-14,-80);g.lineTo(-24,-94);g.quadraticCurveTo(-34,-114,-32,-144);g.closePath()};
  sail();const q=g.createLinearGradient(-32,0,32,0);q.addColorStop(0,'#e8dcc0');q.addColorStop(.6,'#c8b894');q.addColorStop(1,'#9a8a6a');g.fillStyle=q;g.fill();rpw2aOut(g,2);
  g.fillStyle='#2a1a10';g.beginPath();g.ellipse(8,-118,7,9,.3,0,TAU);g.fill();g.beginPath();g.ellipse(-14,-104,4,5,0,0,TAU);g.fill();
  g.strokeStyle='rgba(90,70,40,.5)';g.lineWidth=1.2;g.beginPath();g.moveTo(-10,-144);g.lineTo(-12,-94);g.moveTo(12,-144);g.lineTo(14,-90);g.stroke();
  g.fillStyle='#5a3a20';g.beginPath();g.moveTo(-14,-170);g.lineTo(14,-170);g.lineTo(10,-158);g.lineTo(-10,-158);g.closePath();g.fill();rpw2aOut(g,2);g.strokeStyle='rgba(30,15,5,.6)';g.lineWidth=1;g.beginPath();g.moveTo(-12,-165);g.lineTo(12,-165);g.stroke();
  g.strokeStyle='#c8b08a';g.lineWidth=1.2;g.beginPath();g.moveTo(0,-176);g.lineTo(-60,0);g.moveTo(0,-176);g.lineTo(60,-4);g.stroke()}
 else{g.translate(40,146);g.rotate(-.12);g.fillStyle='#6a4426';g.strokeStyle=RPO;g.lineWidth=2;g.beginPath();g.moveTo(-4,0);g.lineTo(-4,-104);g.lineTo(-1,-112);g.lineTo(2,-104);g.lineTo(4,-110);g.lineTo(4,0);g.closePath();g.fill();g.stroke()}})}
function rpw2aFlagSpr(f){return rpw2aSpr('jr'+f,60,40,g=>{const w=Math.sin(f/6*TAU);g.translate(4,6);g.beginPath();g.moveTo(0,0);for(let k=1;k<=6;k++){const u=k/6;g.lineTo(u*44,Math.sin(f/6*TAU-u*3)*3*u)}
 g.lineTo(44,24+Math.sin(f/6*TAU-3)*3);g.lineTo(36,20);g.lineTo(30,26);for(let k=4;k>=0;k--){const u=k/6;g.lineTo(u*44,24+Math.sin(f/6*TAU-u*3)*3*u)}g.closePath();g.fillStyle='#1a1420';g.fill();rpw2aOut(g,1.6);
 g.fillStyle='#f0e8d8';g.beginPath();g.arc(18,10+w,5,0,TAU);g.fill();g.fillRect(15,13+w,6,4);g.fillStyle='#1a1420';g.fillRect(15.5,8+w,2.4,2.4);g.fillRect(18.6,8+w,2.4,2.4);
 g.strokeStyle='#f0e8d8';g.lineWidth=1.8;g.beginPath();g.moveTo(10,18+w);g.lineTo(26,4+w);g.moveTo(10,4+w);g.lineTo(26,18+w);g.stroke()})}
function rpw2aWreckBake(map){const G=rpGeo(map),pal=RP_PAL.wreck,A=rpw2aCastle('wreck'),gt=G.gate;
 const cast={x:Math.round(gt.x-A.gx),y:Math.round(gt.y-A.gy),w:A.w,h:A.h},B={pal,G,cast,trees:[],id:'wreck',lant:[],post:[]};
 const sh=map.ship||[790,610,330,170],shipIn=(x,y,m)=>Math.abs(x-sh[0])<sh[2]/2+(m||0)&&y>sh[1]-sh[3]/2-(m||0)&&y<sh[1]+sh[3]/2+(m||0);
 const {F}=rpw2aField(map,G,(x,y)=>{let f=rpw2aWreckSea(x,y);/* the ship lies in water */return rpw2aSmax(f,rpw2aEll(x,y,sh[0],sh[1]+20,sh[2]*.62,sh[3]*.62),40)},{clear:58,padR:72,
  extra:(x,y,f)=>{const d=Math.hypot(x-gt.x-20,y-gt.y);return rpw2aSmin(f,d-100,30)}});
 const DR=rpw2aRoadGrid(G);
 const N=rpw2aGrid((x,y)=>rpw2aFbm(x,y,4.1)),C=RPW2A_WR;B.F=F;
 const M=rpw2aGrid((x,y)=>rpw2aVN(x/60+9,y/60)),HI=[220,230,220],BK=[0,0,0],RL=[150,200,200],CA=[180,230,220],FO=[210,230,225];
 const P=rpw2aPaint(F,N,M,(f,n,m,x,y,o,w)=>{
  if(f<=0){rpw2aM3(o,C.l0,C.l1,rpw2aSS(.35,.7,n));if(m>.6)rpw2aM3(o,o,C.moss,rpw2aSS(.6,.64,m)*.7);
   if(f>-40)rpw2aM3(o,o,C.sand,rpw2aSS(-40,-34,f+(n-.5)*20)*.8);if(f>-12)rpw2aM3(o,o,C.wet,rpw2aSS(-12,-9,f)*.85);
   const gr=rpw2aIH(x,y);if(gr>.93)rpw2aM3(o,o,HI,.12);else if(gr<.07)rpw2aM3(o,o,BK,.12);
   if(f>-2.4){w[0]=C.rim[0];w[1]=C.rim[1];w[2]=C.rim[2];w[3]=255*rpw2aSS(-2.4,-1.2,f)}return}
  rpw2aM3(o,C.floor,C.floorD,rpw2aSS(10,140,f));
  const fb=f+(n-.5)*24;let a;if(fb<22){rpw2aM3(w,C.w0,C.w1,fb/22*.6);a=.62}else if(fb<80){rpw2aM3(w,C.w1,C.w2,(fb-22)/58*.6);a=.78}else{rpw2aM3(w,C.w2,C.w3,Math.min(1,(fb-80)/120));a=.92}
  const d1=Math.min(Math.abs(fb-22),Math.abs(fb-80));if(d1<2){rpw2aM3(w,w,RL,.4*(1-d1/2));a=Math.max(a,.8)}
  if(fb<80){const ca=Math.sin(x*.07+Math.sin(y*.05)*2.4)+Math.sin(y*.09+Math.sin(x*.04)*2.2);if(ca>1.6)rpw2aM3(w,w,CA,.3*(ca-1.6))}
  if(f<1.3){w[0]=C.rim[0];w[1]=C.rim[1];w[2]=C.rim[2];a=1}else if(f<5&&n>.35){const k=1-rpw2aSS(3.5,5,f);rpw2aM3(w,w,FO,k*.9);a=Math.max(a,k*.9)}
  w[3]=255*a},1);
 const c=rpw2aCv(1600,900),g=c.getContext('2d');g.lineJoin='round';g.lineCap='round';g.drawImage(P.base,0,0);B.c=c;
 /* under the water: kelp, rocks and a sunken chest */
 rpw2aMasked(g,P.mask,h=>{for(let k=0;k<120;k++){const x=rpw2aR(k*3+15)*1600,y=rpw2aR(k*3+16)*900,f=F.at(x,y);if(f<14||f>120||shipIn(x,y,10))continue;
   if(k%3)rpw2aTuft(h,x,y,18+rpw2aR(k)*14,k%2?'#2a5a4a':'#3a6a50',5);else rpw2aStone(h,x,y,16+rpw2aR(k)*20,k,['#4a5e60','#6a8084','#2a3a40'])}
  rpw2aAnchor(h,560,770,22,.6)});
 g.drawImage(P.surf,0,0);
 /* ground detail: moss blots, pebbles, marsh grass */
 for(let i=0;i<90;i++){const x=rpw2aR(i+300)*1600,y=rpw2aR(i+330)*900,f=F.at(x,y);if(f>-50||DR.at(x,y)<70)continue;rpw2aBlob(g,x,y,30+rpw2aR(i)*50,12+rpw2aR(i+1)*16,i%2?'#3a5a44':'#5a6a5a',.4)}
 for(let i=0;i<900;i++){const x=rpw2aR(i*2+90)*1600,y=rpw2aR(i*2+91)*900,f=F.at(x,y);if(f>-16||DR.at(x,y)<42)continue;g.strokeStyle=i%3?'#3e5a46':'#6a8a64';g.lineWidth=1.6;g.beginPath();g.moveTo(x,y);g.lineTo(x-2,y-7-rpw2aR(i)*6);g.moveTo(x+3,y);g.lineTo(x+4,y-6-rpw2aR(i+3)*6);g.stroke()}
 for(let i=0;i<260;i++){const x=rpw2aR(i+1000)*1600,y=rpw2aR(i+1300)*900,f=F.at(x,y);if(f>-8||DR.at(x,y)<44)continue;g.fillStyle=['#8a8a80','#6a6e6a','#a8a294'][i%3];g.beginPath();g.ellipse(x,y,2.6,1.8,0,0,TAU);g.fill()}
 /* the road: a plank boardwalk on dark sand, rope railings on posts */
 rpw2aRoad(g,G,{edge:'#2a2420',curb:'#5a4a38',fill:'#7a6a54',texStep:3,
  tex:(g,P,i,p)=>{const nx=-Math.sin(p.a),ny=Math.cos(p.a),tx=Math.cos(p.a)*4.4,ty=Math.sin(p.a)*4.4,L=28+(rpw2aR(i)-.5)*4;
   g.fillStyle=['#8a6440','#9a7048','#7a5638','#a87a4e'][(i/3|0)%4];g.beginPath();g.moveTo(p.x+nx*L-tx,p.y+ny*L-ty);g.lineTo(p.x+nx*L+tx,p.y+ny*L+ty);g.lineTo(p.x-nx*L+tx,p.y-ny*L+ty);g.lineTo(p.x-nx*L-tx,p.y-ny*L-ty);g.closePath();g.fill();
   g.strokeStyle='rgba(30,16,6,.55)';g.lineWidth=1.2;g.stroke();if(rpw2aR(i+3)<.25){g.strokeStyle='rgba(30,16,6,.4)';g.beginPath();g.moveTo(p.x+nx*L*.6,p.y+ny*L*.6);g.lineTo(p.x-nx*L*.2,p.y-ny*L*.2);g.stroke()}
   g.fillStyle='#2a2228';for(const s of[-1,1]){g.beginPath();g.arc(p.x+nx*L*.82*s,p.y+ny*L*.82*s,1.1,0,TAU);g.fill()}},
  stStep:12,stone:(g,x,y,a,i,sd)=>{g.fillStyle='#4a3020';g.strokeStyle=RPO;g.lineWidth=1.6;g.beginPath();g.rect(x-3.5,y-14,7,16);g.fill();g.stroke();g.fillStyle='#8a6a48';g.fillRect(x-3.5,y-14,7,3)},chev:'rgba(255,230,180,.22)'});
 /* rope between the railing posts */
 g.strokeStyle='#c8b08a';g.lineWidth=1.8;for(const Pp of G.paths){const S=Pp.S;for(const sd of[-1,1]){let prev=null;for(let i=0;i<S.length;i+=12){const p=S[i],x=p.x-Math.sin(p.a)*35*sd,y=p.y+Math.cos(p.a)*35*sd-12;
   const ok=Pp.own[i]&&G.dRoad(x,y+12)>=30;if(ok&&prev){g.beginPath();g.moveTo(prev[0],prev[1]);g.quadraticCurveTo((prev[0]+x)/2,(prev[1]+y)/2+6,x,y);g.stroke()}prev=ok?[x,y]:null}}}
 /* the wreck */
 rpw2aShip(g,sh[0],sh[1],sh[2],sh[3],B);B.mast=[[sh[0]-50*sh[2]/330,sh[1]-36*sh[3]/170],[sh[0]+96*sh[2]/330,sh[1]-70*sh[3]/170]];
 {const [cx,cy]=map.cannon||[800,585];g.fillStyle='#4a2c18';g.fillRect(cx-12,cy-2,24,9);g.strokeStyle=RPO;g.lineWidth=2;g.strokeRect(cx-12,cy-2,24,9);for(const dx of[-8,8]){g.fillStyle='#2a2228';g.beginPath();g.arc(cx+dx,cy+8,4,0,TAU);g.fill();g.stroke()}}
 /* props by depth */
 const taken=[[sh[0],sh[1],sh[2]*.55]],items=[],free=(x,y,o)=>rpw2aFree(G,B,x,y,Object.assign({taken},o||{}));
 const near=(x0,y0,w,h,wet)=>{for(let k=0;k<160;k++){const a=k*2.4,d=k*4,x=x0+Math.cos(a)*d,y=y0+Math.sin(a)*d*.7;if(x<30||x>1570||y<40||y>880)continue;const f=F.at(x,y);if(wet?f<30:f>-14)continue;if(wet?!rpw2aPadHit(G,x-w/2,y-h,x+w/2,y)&&!shipIn(x,y,30):free(x,y,{road:70,w,h}))return[x,y]}return null};
 /* fixed set pieces: the skull rock, shacks on stilts, a dock with a boat, a buried chest, pirate camps (barrels, crates, shot) */
 for(const [x0,y0,k,s,wet] of[[1250,70,'skull',66,1],[300,812,'shack',58],[1170,700,'shack',54],[470,560,'chest',26],[250,420,'camp',40],[1060,140,'camp',40],[560,150,'camp',34],[1340,620,'camp',34],[90,450,'camp',34]]){
  const p=near(x0,y0,s*1.4,k==='shack'?s*1.5:s,wet);if(!p)continue;items.push({k,x:p[0],y:p[1],s,i:x0});taken.push([p[0],p[1],s*.9])}
 /* lanterns along the boardwalk, alternating sides, and crags along the shore */
 for(const P of G.paths){const S=P.S;for(let i=30,sd=1;i<S.length-40;i+=58,sd=-sd){if(!P.own[i])continue;const q=S[i];for(const s2 of[sd,-sd]){const x=q.x-Math.sin(q.a)*58*s2,y=q.y+Math.cos(q.a)*58*s2;
   if(F.at(x,y)>-10||!rpw2aFree(G,B,x,y,{road:50,pad:70,w:30,h:60,taken})||items.some(o=>o.k==='lamp'&&Math.hypot(o.x-x,o.y-y)<150))continue;items.push({k:'lamp',x,y,i});taken.push([x,y,20]);break}}}
 for(let i=0;i<500;i++){const x=rpw2aR(i*3+77)*1600,y=rpw2aR(i*3+78)*900,f=F.at(x,y);if(f<-26||f>-4||!free(x,y,{road:70,w:50,h:44}))continue;if(items.filter(o=>o.k==='rock').length>40)break;items.push({k:'rock',x,y,i})}
 for(let i=0;i<2400&&items.length<230;i++){const x=rpw2aR(i*4+21)*1640-20,y=rpw2aR(i*4+22)*940-20,f=F.at(x,y);if(f>-12||!free(x,y,{road:66}))continue;
  const d=DR.at(x,y),r=rpw2aR(i*4+23);if(rpw2aR(i+5)<(d>170?.15:.5))continue;const nr=d<110;
  let k=nr?(r<.12?'lamp':r<.4?'rock':r<.66?'tuft':r<.82?'pine':'dead'):(r<.5?'pine':r<.66?'dead':r<.8?'rock':'tuft');const h=60+rpw2aR(i*4+24)*40;
  if(k==='lamp'&&items.some(o=>o.k==='lamp'&&Math.hypot(o.x-x,o.y-y)<240))continue;
  if((k==='pine'||k==='dead')&&!free(x,y,{road:74,w:h*.7,h:h*1.05}))continue;  if((k==='pine'||k==='oak')&&!free(x,y,{road:74,w:h*.7,h:h*1.05}))continue;if(k==='lamp'&&!free(x,y,{w:24,h:60}))continue;items.push({k,x,y,i,h})}
 /* sea stacks in the water */
 for(let i=0;i<300;i++){const x=rpw2aR(i*5+61)*1600,y=rpw2aR(i*5+62)*900;if(F.at(x,y)<40||shipIn(x,y,40)||rpw2aPadHit(G,x-30,y-70,x+30,y))continue;if(items.filter(o=>o.k==='stack').length>=7)break;
  if(items.some(o=>o.k==='stack'&&Math.hypot(o.x-x,o.y-y)<140))continue;items.push({k:'stack',x,y,i,h:40+rpw2aR(i)*40})}
 items.sort((a,b)=>a.y-b.y);B.stacks=[];
 for(const it of items){const {x,y,i,h}=it;switch(it.k){
  case'pine':rpTree(g,x,y,h,RPW2A_WPAL,i,'moss');break;case'dead':rpw2aDeadTree(g,x,y,h*.8,i);break;case'camp':rpw2aCamp(g,x,y,it.s,i);break;case'rock':rpw2aCrag(g,x,y,24+rpw2aR(i)*20,18+rpw2aR(i+1)*16,i);break;
  case'barrel':rpw2aBarrel(g,x,y,20+rpw2aR(i)*6,i,i%5===0?.3:0);if(i%2)rpw2aBarrel(g,x+14,y+4,18,i+1);break;case'crate':rpw2aCrate(g,x,y,22,i);if(i%3===0)rpw2aCrate(g,x+6,y-17,16,i+1);break;
  case'lamp':{const L2=rpw2aLanternPost(g,x,y,46);B.lant.push(L2);B.post.push([x,y])}break;case'balls':rpw2aBalls(g,x,y,5);break;case'tuft':rpw2aTuft(g,x,y,18,'#5a7a54',6);break;
  case'skull':rpw2aSkullRock(g,x,y,it.s);B.stacks.push([x,y,it.s*.5]);break;case'shack':if(F.at(x+34,y+50)>10){rpw2aJetty(g,x+30,y-2,x+44,y+64,16);rpw2aBoat(g,x+78,y+60,46,1.4,'#5a4a3a')}B.lant.push(rpw2aShack(g,x,y,it.s,i));break;case'chest':rpw2aChest(g,x,y,it.s);break;
  case'stack':rpw2aCrag(g,x,y,h*.9,h,i,['#56606a','#8a96a2','#2e363e']);g.fillStyle='#3a6a4a';g.beginPath();g.ellipse(x-h*.12,y-h*.92,h*.2,h*.06,0,0,TAU);g.fill();B.stacks.push([x,y,h*.5]);break}}
 B.trees=items;
 g.save();g.globalCompositeOperation='lighter';for(const p of B.post){g.globalAlpha=.3;g.drawImage(rpw2aGl('255,170,70',40),p[0]-50,p[1]-24,110,50)}g.restore();
 for(const e of G.ent)rpw2aSeaCave(g,Math.max(30,e.x-14),e.y,'wreck');B.lant.push([96,173],[96,643]);
 g.drawImage(A.c,cast.x,cast.y,A.w,A.h);
 /* drifts of mist lying on the water and the low ground */
 for(let i=0;i<26;i++){const x=rpw2aR(i*5+500)*1600,y=rpw2aR(i*5+501)*900;if(F.at(x,y)<-60||DR.at(x,y)<60)continue;const r=60+rpw2aR(i)*70;g.globalAlpha=.16;g.drawImage(rpw2aGl('225,236,242',r),x-r*1.3,y-r*.45,r*2.6,r*.9)}g.globalAlpha=1;
 /* a cool sea haze over everything, thicker at the top */
 let q=g.createLinearGradient(0,0,0,900);q.addColorStop(0,'rgba(190,215,225,.22)');q.addColorStop(.4,'rgba(190,215,225,.06)');q.addColorStop(1,'rgba(150,180,200,.1)');g.fillStyle=q;g.fillRect(0,0,1600,900);
 B.shore=rpw2aShore(F,16,(x,y)=>!shipIn(x,y,-10)&&!(x>cast.x+10&&y>cast.y+cast.h-60));
 B.sea=[];for(let i=0;i<600&&B.sea.length<40;i++){const x=rpw2aR(i*7+80)*1600,y=rpw2aR(i*7+81)*900;if(F.at(x,y)>24&&!shipIn(x,y,10))B.sea.push([x,y])}
 return B}
/* the Corsair Fort: grey stone on dark rocks, timber hoardings and plank roofs, a crow's-nest watchtower with the black flag, a cannon
   bastion with a beacon fire, a palisade of sharpened logs and a skull over the gate */
function rpw2aPalisade(g,x0,x1,y,h,s){for(let x=x0,i=0;x<x1;x+=9,i++){const hh=h*(.82+rpw2aR(s+i)*.3);g.beginPath();g.moveTo(x,y);g.lineTo(x,y-hh);g.lineTo(x+4.5,y-hh-8);g.lineTo(x+9,y-hh);g.lineTo(x+9,y);g.closePath();
 const q=g.createLinearGradient(x,0,x+9,0);q.addColorStop(0,'#a8723e');q.addColorStop(1,'#5a3a1e');g.fillStyle=q;g.fill();rpw2aOut(g,1.8)}
 g.fillStyle='#3a3640';g.fillRect(x0,y-h*.72,x1-x0,3);g.fillRect(x0,y-h*.3,x1-x0,3)}
function rpw2aHoard(g,P,x,y,w){/* a timber gallery on a wall top */g.fillStyle='#6a4426';g.fillRect(x-4,y-14,w+8,14);g.strokeStyle=RPO;g.lineWidth=2;g.strokeRect(x-4,y-14,w+8,14);
 g.strokeStyle='rgba(25,12,4,.6)';g.lineWidth=1.2;g.beginPath();for(let xx=x;xx<x+w;xx+=7){g.moveTo(xx,y-14);g.lineTo(xx,y)}g.stroke();
 g.fillStyle='#4a2a16';g.beginPath();g.moveTo(x-8,y-14);g.lineTo(x+w/2,y-30);g.lineTo(x+w+8,y-14);g.closePath();g.fill();rpw2aOut(g,2);g.strokeStyle='rgba(200,150,90,.45)';g.lineWidth=1.2;g.beginPath();for(let k=1;k<3;k++){g.moveTo(x-8+k*6,y-14-k*4);g.lineTo(x+w+8-k*6,y-14-k*4)}g.stroke()}
function rpw2aCannonSide(g,x,y,dir){g.save();g.translate(x,y);g.scale(dir,1);g.fillStyle='#2a2a34';g.beginPath();g.moveTo(0,-4);g.lineTo(18,-3);g.lineTo(18,3);g.lineTo(0,4);g.closePath();g.fill();rpw2aOut(g,1.6);g.fillStyle='#000';g.beginPath();g.ellipse(18,0,1.6,3,0,0,TAU);g.fill();g.restore()}
function rpw2aPaintWreck(g,A){const P=RPW2A_CP.wreck,id='ember';A.P=P;
 g.fillStyle='rgba(0,0,0,.3)';g.beginPath();g.ellipse(196,508,116,16,0,0,TAU);g.fill();
 /* the cliff the fort stands on */
 rpwRocks(g,P,'wreck',[[282,300,44,70],[288,380,40,90],[282,460,48,90],[290,520,40,100],[236,520,60,40]],40);
 /* the watchtower with the crow's nest */
 {const cx=168,t=rpwDrum(g,P,cx,230,46,150,11);rpwWin(g,P,id,A,cx-5,t+26,10,18);rpwWin(g,P,id,A,cx-5,t+80,10,18);
  g.fillStyle='#6a4426';g.strokeStyle=RPO;g.lineWidth=2;for(const s of[-1,1]){g.beginPath();g.moveTo(cx+s*18,t);g.lineTo(cx+s*30,t-14);g.stroke()}
  g.fillStyle='#7a5030';g.beginPath();g.moveTo(cx-34,t-14);g.lineTo(cx+34,t-14);g.lineTo(cx+28,t-34);g.lineTo(cx-28,t-34);g.closePath();g.fill();rpw2aOut(g,2.2);
  g.strokeStyle='rgba(25,12,4,.6)';g.lineWidth=1.2;g.beginPath();for(let k=-3;k<=3;k++){g.moveTo(cx+k*9,t-14);g.lineTo(cx+k*8,t-34)}g.stroke();
  g.strokeStyle=RPO;g.lineWidth=3;g.beginPath();g.moveTo(cx,t-34);g.lineTo(cx,t-112);g.stroke();g.strokeStyle='#6a4426';g.lineWidth=1.6;g.stroke();
  g.fillStyle='#5a3a20';g.beginPath();g.moveTo(cx-14,t-80);g.lineTo(cx+14,t-80);g.lineTo(cx+10,t-68);g.lineTo(cx-10,t-68);g.closePath();g.fill();rpw2aOut(g,2);
  A.jolly=[cx,t-110];A.lant.push([cx+30,t-24]);g.fillStyle='#2a2228';g.fillRect(cx+25,t-30,10,3);g.fillStyle='#ffd27a';g.fillRect(cx+26,t-27,8,9);g.strokeStyle=RPO;g.lineWidth=1.4;g.strokeRect(cx+26,t-27,8,9)}
 /* the main hall with hoardings */
 rpwWall(g,P,112,196,114,146,31,10);rpw2aHoard(g,P,112,196,114);
 for(const [x,y] of[[126,226],[160,226],[194,226],[142,276],[184,276]])rpwWin(g,P,id,A,x,y,11,18);
 rpwBanner(g,P,'ember',152,292,20,40);
 for(const cx of[112,226]){const t=rpwDrum(g,P,cx,306,30,140,cx);rpwCone(g,{roof:'#7a4a2a',rl:'#b07a44',rd:'#4a2a16'},cx,t,19,46,A,cx===226?24:0);rpwWin(g,P,id,A,cx-4,t+30,8,15)}
 /* the palisade on the left and the curtain wall */
 rpw2aPalisade(g,40,120,350,74,3);rpwWall(g,P,184,306,40,170,61,9);rpwCren(g,P,'moss',184,306,40,9);
 /* the left tower */
 {const t=rpwDrum(g,P,46,366,46,168,71);rpwCone(g,{roof:'#7a4a2a',rl:'#b07a44',rd:'#4a2a16'},46,t,28,78,A,26);rpwWin(g,P,id,A,40,t+34,11,19);rpwWin(g,P,id,A,40,t+94,11,19);
  g.strokeStyle='#c8b08a';g.lineWidth=1.4;g.beginPath();g.moveTo(28,t+40);g.lineTo(28,t+150);g.moveTo(38,t+40);g.lineTo(38,t+150);for(let y=t+46;y<t+150;y+=9){g.moveTo(28,y);g.lineTo(38,y)}g.stroke()}
 rpwRocks(g,P,'wreck',[[18,388,40,30],[52,394,58,34],[88,388,40,24],[30,376,30,20]],7);
 /* the cannon bastion with a beacon fire */
 {const cx=248,w=70,t=rpwDrum(g,P,cx,492,w,212,81);rpwRing(g,P,'moss',cx,t,w);
  rpw2aCannonSide(g,cx-30,t-6,-1);rpw2aCannonSide(g,cx+30,t-6,1);rpw2aCannonSide(g,cx-36,t+60,-1);
  g.fillStyle='#2a2228';g.beginPath();g.moveTo(cx-14,t-14);g.lineTo(cx+14,t-14);g.lineTo(cx+9,t-30);g.lineTo(cx-9,t-30);g.closePath();g.fill();rpw2aOut(g,2);
  g.strokeStyle='#2a2228';g.lineWidth=2;g.beginPath();for(let k=-2;k<=2;k++){g.moveTo(cx+k*4,t-30);g.lineTo(cx+k*6,t-44)}g.stroke();A.fire=[cx,t-40];
  g.fillStyle='#ff8a2a';g.beginPath();g.moveTo(cx-12,t-30);g.quadraticCurveTo(cx-8,t-50,cx-2,t-56);g.quadraticCurveTo(cx+2,t-46,cx+6,t-58);g.quadraticCurveTo(cx+12,t-44,cx+12,t-30);g.closePath();g.fill();
  g.fillStyle='#ffe27a';g.beginPath();g.moveTo(cx-6,t-30);g.quadraticCurveTo(cx-3,t-42,cx+1,t-46);g.quadraticCurveTo(cx+5,t-38,cx+6,t-30);g.closePath();g.fill();
  rpwWin(g,P,id,A,cx-6,t+40,12,21);rpwWin(g,P,id,A,cx-16,t+106,11,19);rpwWin(g,P,id,A,cx+6,t+150,10,18);rpwBanner(g,P,'ember',cx-10,t+62,20,44)}
 /* the gatehouse: stone arch, a skull and crossbones, lanterns */
 rpwWall(g,P,96,326,88,148,91,9);rpw2aHoard(g,P,96,326,88);g.fillStyle=P.sl;g.fillRect(90,470,100,7);g.strokeStyle=RPO;g.lineWidth=2.2;g.strokeRect(90,470,100,7);
 rpwGate(g,P,'moss',A,RPW2A_GX,470,48,82);
 {const x=RPW2A_GX,y=352;g.strokeStyle='#f0e8d8';g.lineWidth=5;g.beginPath();g.moveTo(x-16,y+14);g.lineTo(x+16,y-6);g.moveTo(x-16,y-6);g.lineTo(x+16,y+14);g.stroke();g.strokeStyle=RPO;g.lineWidth=1.4;g.stroke();
  g.fillStyle='#f0e8d8';g.beginPath();g.arc(x,y,10,0,TAU);g.fill();rpw2aOut(g,2);g.fillRect(x-5,y+6,10,7);g.strokeRect(x-5,y+6,10,7);g.fillStyle=RPO;g.beginPath();g.arc(x-4,y-1,2.6,0,TAU);g.arc(x+4,y-1,2.6,0,TAU);g.fill()}
 rpwTorch(g,A,108,404);rpwTorch(g,A,172,404);
 for(const cx of[96,184]){g.fillStyle=P.sd;g.beginPath();g.moveTo(cx-12,360);g.lineTo(cx,382);g.lineTo(cx+12,360);g.closePath();g.fill();rpw2aOut(g,2.2);
  const t=rpwDrum(g,P,cx,362,24,48,cx+3);rpwCone(g,{roof:'#7a4a2a',rl:'#b07a44',rd:'#4a2a16'},cx,t,15,34,A,0)}
 rpwBridge(g,P,RPW2A_GX,476,48,22,412);
 /* barrels at the gate, a rowboat by the rocks */
 rpw2aBarrel(g,104,500,18,1);rpw2aBarrel(g,90,506,16,3);rpw2aCrate(g,184,500,18,2);
 rpwRocks(g,P,'wreck',[[206,512,56,30],[250,518,70,34],[290,516,40,26]],27);rpw2aBalls(g,226,494,4);
 A.spark.length=0}
/* ---------- Shipwreck Cove: live ---------- */
/* a fog bank sprite: overlapping soft puffs, denser in the middle (two variants) */
function rpw2aFogSpr(v){return rpw2aSpr('fog'+v,320,200,g=>{for(let k=0;k<46;k++){const a=rpw2aR(k*3+v*50)*TAU,d=Math.sqrt(rpw2aR(k*3+1+v*50))*.78,x=160+Math.cos(a)*d*124,y=100+Math.sin(a)*d*64,r=34+rpw2aR(k+v*9)*40*(1-d*.5);
 const q=g.createRadialGradient(x,y-r*.15,0,x,y,r);q.addColorStop(0,'rgba(236,244,248,.42)');q.addColorStop(.55,'rgba(220,232,240,.26)');q.addColorStop(1,'rgba(210,225,235,0)');g.fillStyle=q;g.fillRect(x-r,y-r,r*2,r*2)}
 const q=g.createRadialGradient(160,100,10,160,100,120);q.addColorStop(0,'rgba(240,246,250,.5)');q.addColorStop(1,'rgba(240,246,250,0)');g.fillStyle=q;g.save();g.scale(1,.6);g.fillRect(0,0,320,340);g.restore()})}
function rpw2aSmokeSpr(){return rpw2aSpr('smoke',64,64,g=>{const q=g.createRadialGradient(28,26,2,32,32,31);q.addColorStop(0,'rgba(230,226,218,.95)');q.addColorStop(.6,'rgba(190,186,178,.7)');q.addColorStop(1,'rgba(160,156,150,0)');g.fillStyle=q;g.fillRect(0,0,64,64)})}
/* the cannon barrel on the wreck's deck, aimed at a (radians), recoil 0..1 */
function rpw2aBarrel2(c,x,y,a,rec){c.save();c.translate(x,y-4);const fl=Math.cos(a)<0;c.rotate(a);c.scale(1.3,1.3);c.translate(-rec*7,0);
 c.fillStyle='#2a2a34';c.strokeStyle=RPO;c.lineWidth=2;c.beginPath();c.moveTo(-10,-6.5);c.lineTo(20,-4.5);c.lineTo(24,-5.5);c.lineTo(24,5.5);c.lineTo(20,4.5);c.lineTo(-10,6.5);c.quadraticCurveTo(-15,0,-10,-6.5);c.closePath();c.fill();c.stroke();
 c.fillStyle='rgba(255,255,255,.28)';c.fillRect(-8,fl?1.5:-4.5,26,2.2);c.strokeStyle='#c8963a';c.lineWidth=1.6;c.beginPath();c.moveTo(4,-5.6);c.lineTo(4,5.6);c.moveTo(16,-5);c.lineTo(16,5);c.stroke();c.restore()}
function rpw2aCannonAim(R){const C=R.cannon,m=R.map.cannon||[800,585],x=C&&C.x!=null?C.x:m[0],y=C&&C.y!=null?C.y:m[1];let a=-2.2;if(C&&C.tx!=null)a=Math.atan2(C.ty-y,C.tx-x);return{x,y,a}}
function rpw2aWreckAmb(c,R){const B=R.bake,t=R.t,lite=R.lite,rm=R.rm;c.save();
 /* water: drifting glints, waves on the shore and foam round the sea stacks */
 if(!rm){c.strokeStyle='rgba(200,230,230,.4)';c.lineWidth=1.8;c.beginPath();const S=B.sea,n=lite?10:22;for(let i=0;i<n&&i<S.length;i++){const p=S[i],u=(t*.04+i*.13)%1,x=p[0]+u*40-20,y=p[1];const l=8*Math.sin(u*Math.PI);c.moveTo(x-l,y);c.lineTo(x+l,y)}c.stroke();
  rpw2aWaves(c,B.shore,t*.8,lite,'#d8ece6',14);
  c.strokeStyle='rgba(220,240,236,.6)';c.lineWidth=2;for(let i=0;i<B.stacks.length;i++){const s=B.stacks[i],u=(t*.4+i*.3)%1;c.globalAlpha=.6*(1-u);c.beginPath();c.ellipse(s[0],s[1]-2,s[2]*(.9+u*.5),s[2]*(.9+u*.5)*.32,0,0,TAU);c.stroke()}c.globalAlpha=1}
 /* the swaying masts and the black flag */
 if(B.mast){const sw=rm?0:1,m0=B.mast[0],m1=B.mast[1];c.save();c.translate(m0[0],m0[1]);c.rotate(Math.sin(t*.7)*.022*sw);c.drawImage(rpw2aMastSpr(0),-70,-196);c.restore();
  c.save();c.translate(m1[0],m1[1]);c.rotate(Math.sin(t*.6+1)*.03*sw);c.drawImage(rpw2aMastSpr(1),-40,-146);c.translate(-12,-110);c.drawImage(rpw2aFlagSpr(rm?0:((t*8)|0)%6),-2,-4);c.restore()}
 /* the cannon barrel, aimed at its target, kicking back when it fires */
 {const A=rpw2aCannonAim(R),f=R.cannon&&R.cannon.fire>0?R.cannon.fire:1,rec=f<.25?1-f/.25:0;rpw2aBarrel2(c,A.x,A.y,A.a,rm?0:rec)}
 /* lanterns and window light */
 c.globalCompositeOperation='lighter';const lg=rpw2aGl('255,180,80',30);for(let i=0;i<B.lant.length;i+=lite?2:1){const p=B.lant[i],f=.8+.15*Math.sin(t*3.3+i*2.1)+(rm?0:.06*Math.sin(t*15+i*5));c.globalAlpha=.55*f;c.drawImage(lg,p[0]-34*f,p[1]-34*f,68*f,68*f)}
 c.globalCompositeOperation='source-over';c.globalAlpha=1;
 /* low mist drifting over the ground */
 if(!rm&&!lite){const ms=rpw2aFogSpr(1);for(let i=0;i<4;i++){const x=((t*(8+i*3)+i*430)%2000)-200,y=170+i*170+Math.sin(t*.2+i)*20;c.globalAlpha=.16;c.drawImage(ms,x-180,y-60,360,120)}c.globalAlpha=1}
 c.restore();try{rpw2aCastleLive(c,rpw2aCastle('wreck'),B.cast.x,B.cast.y,t,lite)}catch(e){}}
/* above everything: the fog banks, then the cannon's flash, smoke, ball and impact */
function rpw2aWreckTop(c,R){const t=R.t,rm=R.rm;
 if(R.fog&&R.fog.length){for(let i=0;i<R.fog.length;i++){const f=R.fog[i],w=f.rx*2.5,h=f.ry*2.7,d=rm?0:Math.sin(t*.3+i*2)*.04;
   c.globalAlpha=.92;c.drawImage(rpw2aFogSpr(i%2),f.x-w/2*(1+d),f.y-h/2,w*(1+d),h);if(!R.lite){c.globalAlpha=.55;const ox=rm?0:Math.sin(t*.23+i)*f.rx*.18;c.drawImage(rpw2aFogSpr((i+1)%2),f.x-w*.4+ox,f.y-h*.36,w*.8,h*.72)}}c.globalAlpha=1}
 const C=R.cannon;if(!C||!(C.fire>0&&C.fire<1))return;/* fire runs 0 -> 1 over a shot; 0 (or 1 and above) is idle */const f=C.fire,A=rpw2aCannonAim(R),mx=A.x+Math.cos(A.a)*24,my=A.y-4+Math.sin(A.a)*24;c.save();
 /* smoke from the muzzle */
 const sm=rpw2aSmokeSpr();for(let j=0;j<5;j++){const u=f-j*.03;if(u<0)continue;const r=10+u*52,dx=Math.cos(A.a)*(10+u*40)+u*20*(j-1.5),dy=Math.sin(A.a)*(10+u*30)-u*50;c.globalAlpha=Math.max(0,(1-u))*.75;c.drawImage(sm,mx+dx-r,my+dy-r,r*2,r*2)}
 /* the flash: a glow, a white-hot starburst and sparks */
 if(f<.18){const k=1-f/.18;c.globalCompositeOperation='lighter';c.globalAlpha=k;c.drawImage(rpw2aGl('255,190,80',60),mx-80*k-20,my-80*k-20,160*k+40,160*k+40);
  for(const [r0,col] of[[34,'#ffb84a'],[20,'#fff4c0']]){c.fillStyle=col;c.beginPath();for(let j=0;j<12;j++){const a=A.a+(j/12-.5)*2.2,r=j%2?r0*.35:(r0*k+10)*(j%4?1:1.4);c.lineTo(mx+Math.cos(a)*r,my+Math.sin(a)*r)}c.closePath();c.fill()}
  c.fillStyle='#ffe08a';for(let j=0;j<6;j++){const a=A.a+(rpw2aR(j)-.5)*1.4,r=10+(1-k)*60;c.beginPath();c.arc(mx+Math.cos(a)*r,my+Math.sin(a)*r,2.2*k+.6,0,TAU);c.fill()}c.globalCompositeOperation='source-over'}
 /* the ball in flight and its smoke trail */
 if(C.tx!=null){const d=Math.hypot(C.tx-mx,C.ty-my),H=70+d*.3,at=u=>({x:mx+(C.tx-mx)*u,y:my+(C.ty-my)*u-H*4*u*(1-u)});
  if(f<.42){const u=f/.42;for(let j=1;j<=4;j++){const p=at(Math.max(0,u-j*.05));c.globalAlpha=.4*(1-j/5);c.drawImage(sm,p.x-6-j*2,p.y-6-j*2,12+j*4,12+j*4)}
   const p=at(u);c.globalAlpha=1;c.fillStyle='#1a1a22';c.beginPath();c.arc(p.x,p.y,6,0,TAU);c.fill();c.strokeStyle=RPO;c.lineWidth=1.6;c.stroke();c.fillStyle='rgba(255,255,255,.5)';c.beginPath();c.arc(p.x-2,p.y-2,1.8,0,TAU);c.fill()}
  else if(f<.85){const v=(f-.42)/.43,x=C.tx,y=C.ty;for(let j=0;j<3;j++){const r=14+v*34+j*6;c.globalAlpha=(1-v)*Math.min(1,v*3)*.65;c.drawImage(sm,x-r+(j-1)*14,y-r-v*30-j*4,r*2,r*2)}c.globalCompositeOperation='lighter';c.globalAlpha=Math.max(0,1-v*1.6);c.drawImage(rpw2aGl('255,150,60',60),x-70,y-60,140,110);c.globalCompositeOperation='source-over';
   if(v<.55){const k=1-v/.55,r0=18+v*50;for(const [rr,col,lw] of[[1,'#ff8a2a',2.4],[.62,'#fff0b0',0]]){c.globalAlpha=Math.min(1,k*1.6);c.fillStyle=col;c.beginPath();for(let j=0;j<14;j++){const a=j/14*TAU+v,r=(j%2?.55:1)*r0*rr;c.lineTo(x+Math.cos(a)*r,y-8+Math.sin(a)*r*.7)}c.closePath();c.fill();if(lw){c.strokeStyle=RPO;c.lineWidth=lw;c.stroke()}}}
   c.globalAlpha=(1-v)*.9;c.strokeStyle='#fff0c0';c.lineWidth=4*(1-v)+1;c.beginPath();c.ellipse(x,y,12+60*v,(12+60*v)*.42,0,0,TAU);c.stroke();
   for(let j=0;j<7;j++){const a=-Math.PI*(.1+j/7*.8),r=10+v*50;c.fillStyle=j%2?'#5a4a3a':'#ffb84a';c.globalAlpha=1-v;c.beginPath();c.arc(x+Math.cos(a)*r,y+Math.sin(a)*r*.7+v*v*30,3,0,TAU);c.fill()}
}}
 c.restore();c.globalAlpha=1}
/* ---------- Kraken's Maw ---------- */
const RPW2A_AB={g0:rpw2aCol('#122a52'),g1:rpw2aCol('#1c3c6c'),g2:rpw2aCol('#0c1c3e'),sand:rpw2aCol('#2a4a7a'),rim:rpw2aCol('#040a1c')};
const RPW2A_GLOW=[['#6af0ff','90,240,255'],['#ff6ae0','255,100,230'],['#7affb8','120,255,190'],['#b08aff','170,130,255'],['#ffd86a','255,210,110']];
/* glowing props: tube coral, a fan, an anemone, a giant clam with a pearl, an urchin, a vent chimney, ruins, whale ribs */
function rpw2aGlowCoral(g,x,y,s,k,i,L){const C=RPW2A_GLOW[k%5];g.save();g.translate(x,y);rpw2aBlob(g,0,2,s*.6,s*.16,'#000',.35);
 if(i%3===0){for(let j=0;j<5;j++){const tx=(j-2)*s*.18,th=s*(.4+rpw2aR(i+j)*.5),tw=s*.08;g.beginPath();g.roundRect(tx-tw,-th,tw*2,th,[tw,tw,1,1]);g.fillStyle=j%2?'#2a3a6a':'#344a80';g.fill();rpw2aOut(g,1.6);
   g.fillStyle=C[0];g.beginPath();g.ellipse(tx,-th+1,tw*.85,tw*.5,0,0,TAU);g.fill();if(L)L.push([x+tx,y-th,10,C[1]])}}
 else if(i%3===1){g.beginPath();g.moveTo(0,0);for(let j=0;j<=10;j++){const a=-Math.PI*.92+j/10*Math.PI*.84,r=s*(.62+.08*Math.sin(j*2.1+i));g.lineTo(Math.cos(a)*r,Math.sin(a)*r)}g.closePath();g.fillStyle='#2a2a6a';g.fill();rpw2aOut(g,2);
  g.strokeStyle=C[0];g.lineWidth=1.3;g.globalAlpha=.85;g.beginPath();for(let j=0;j<12;j++){const a=-Math.PI*.9+j/11*Math.PI*.8;g.moveTo(0,0);g.lineTo(Math.cos(a)*s*.58,Math.sin(a)*s*.58)}for(const r of[.3,.5]){g.moveTo(Math.cos(-Math.PI*.9)*s*r,Math.sin(-Math.PI*.9)*s*r);g.arc(0,0,s*r,-Math.PI*.9,-Math.PI*.1)}g.stroke();g.globalAlpha=1;if(L)L.push([x,y-s*.35,s*.6,C[1]])}
 else{/* branching glow coral */const br=(px,py,a,l,d)=>{const ex=px+Math.cos(a)*l,ey=py+Math.sin(a)*l;g.moveTo(px,py);g.lineTo(ex,ey);if(d>0){br(ex,ey,a-.5,l*.72,d-1);br(ex,ey,a+.45,l*.7,d-1)}else if(L)L.push([x+ex,y+ey,7,C[1]])};
  g.beginPath();br(0,0,-Math.PI/2,s*.4,3);g.lineWidth=s*.13+3;g.strokeStyle=RPO;g.stroke();g.lineWidth=s*.13;g.strokeStyle='#3a3a80';g.stroke();g.lineWidth=s*.05;g.strokeStyle=C[0];g.stroke()}
 g.restore()}
function rpw2aAnemone(g,x,y,s,k,L){const C=RPW2A_GLOW[k%5];g.save();g.translate(x,y);rpw2aBlob(g,0,2,s*.6,s*.16,'#000',.35);g.fillStyle='#3a2a5a';g.beginPath();g.ellipse(0,-s*.12,s*.36,s*.18,0,0,TAU);g.fill();rpw2aOut(g,1.8);
 for(let j=0;j<11;j++){const a=-Math.PI+.15+j/10*(Math.PI-.3),l=s*(.45+rpw2aR(j+k)*.2),ex=Math.cos(a)*l*.8,ey=-s*.2+Math.sin(a)*l;g.strokeStyle=RPO;g.lineWidth=5;g.beginPath();g.moveTo(Math.cos(a)*s*.2,-s*.2);g.quadraticCurveTo(ex*.6+3,ey*.6,ex,ey);g.stroke();
  g.strokeStyle=C[0];g.lineWidth=3;g.stroke();g.fillStyle='#ffffff';g.beginPath();g.arc(ex,ey,1.6,0,TAU);g.fill()}if(L)L.push([x,y-s*.5,s*.7,C[1]]);g.restore()}
function rpw2aClam(g,x,y,s,L){g.save();g.translate(x,y);rpw2aBlob(g,0,3,s*.8,s*.2,'#000',.35);
 g.beginPath();g.moveTo(-s*.7,0);g.quadraticCurveTo(0,s*.3,s*.7,0);g.quadraticCurveTo(0,-s*.12,-s*.7,0);g.fillStyle='#5a6aa8';g.fill();rpw2aOut(g,2);
 g.fillStyle='#ffd0f0';g.beginPath();g.ellipse(0,-s*.06,s*.5,s*.12,0,0,TAU);g.fill();g.fillStyle='#ffffff';g.beginPath();g.arc(0,-s*.14,s*.16,0,TAU);g.fill();rpw2aOut(g,1.6);g.fillStyle='#e8f8ff';g.beginPath();g.arc(-s*.05,-s*.19,s*.05,0,TAU);g.fill();
 g.beginPath();g.moveTo(-s*.7,0);for(let j=0;j<=8;j++){const a=Math.PI+j/8*Math.PI*.95;g.quadraticCurveTo(Math.cos(a-.2)*s*.8,-s*.25+Math.sin(a-.2)*s*.75,Math.cos(a)*s*.7,-s*.25+Math.sin(a)*s*.65)}g.lineTo(s*.7,0);g.quadraticCurveTo(0,-s*.25,-s*.7,0);g.closePath();
 const q=g.createLinearGradient(0,-s,0,0);q.addColorStop(0,'#9aa8e8');q.addColorStop(1,'#4a5a98');g.fillStyle=q;g.fill();rpw2aOut(g,2);g.strokeStyle='rgba(18,8,31,.45)';g.lineWidth=1.2;g.beginPath();for(let j=1;j<8;j++){const a=Math.PI+j/8*Math.PI;g.moveTo(0,-s*.12);g.lineTo(Math.cos(a)*s*.62,-s*.25+Math.sin(a)*s*.58)}g.stroke();
 if(L)L.push([x,y-s*.14,s*.7,'255,230,250']);g.restore()}
function rpw2aUrchin(g,x,y,s){g.save();g.translate(x,y);rpw2aBlob(g,0,2,s*.6,s*.16,'#000',.3);g.strokeStyle='#1a1030';g.lineWidth=2;g.beginPath();for(let j=0;j<18;j++){const a=Math.PI+j/17*Math.PI;g.moveTo(0,-s*.3);g.lineTo(Math.cos(a)*s*.8,-s*.3+Math.sin(a)*s*.7)}g.stroke();
 g.strokeStyle='#8a5ad8';g.lineWidth=1;g.stroke();g.fillStyle='#2a1a4a';g.beginPath();g.arc(0,-s*.28,s*.34,0,TAU);g.fill();rpw2aOut(g,1.6);g.fillStyle='#c08aff';g.beginPath();g.arc(-s*.1,-s*.38,s*.07,0,TAU);g.fill();g.restore()}
function rpw2aVent(g,x,y,s){g.save();g.translate(x,y);rpw2aBlob(g,0,2,s*.6,s*.16,'#000',.35);for(const [dx,h,w] of[[-s*.25,s*.7,s*.16],[s*.12,s,s*.2],[s*.36,s*.5,s*.13]]){g.beginPath();g.moveTo(dx-w,0);g.lineTo(dx-w*.6,-h);g.lineTo(dx+w*.6,-h);g.lineTo(dx+w,0);g.closePath();
  const q=g.createLinearGradient(dx-w,0,dx+w,0);q.addColorStop(0,'#5a5a7a');q.addColorStop(1,'#24243a');g.fillStyle=q;g.fill();rpw2aOut(g,1.8);g.fillStyle='#ff9a4a';g.beginPath();g.ellipse(dx,-h,w*.55,w*.2,0,0,TAU);g.fill();rpw2aOut(g,1.2)}g.restore();return[x+s*.12,y-s]}
function rpw2aColumn(g,x,y,h,broken,i){g.save();g.translate(x,y);rpw2aBlob(g,6,2,22,6,'#000',.35);const w=11;
 g.fillStyle='#6a86b0';g.fillRect(-w-4,-8,w*2+8,8);g.strokeStyle=RPO;g.lineWidth=2;g.strokeRect(-w-4,-8,w*2+8,8);
 g.beginPath();g.moveTo(-w,-8);g.lineTo(-w,-h);if(broken){g.lineTo(-w*.4,-h-6);g.lineTo(0,-h+3);g.lineTo(w*.5,-h-8);}g.lineTo(w,-h+(broken?-2:0));g.lineTo(w,-8);g.closePath();
 const q=g.createLinearGradient(-w,0,w,0);q.addColorStop(0,'#a8c4e8');q.addColorStop(.4,'#7a98c8');q.addColorStop(1,'#3e5888');g.fillStyle=q;g.fill();rpw2aOut(g,2);
 g.strokeStyle='rgba(18,8,31,.35)';g.lineWidth=1.2;g.beginPath();for(const dx of[-5,0,5]){g.moveTo(dx,-10);g.lineTo(dx,-h+4)}g.stroke();
 if(!broken){g.fillStyle='#8aa8d8';g.fillRect(-w-5,-h-8,w*2+10,8);g.strokeStyle=RPO;g.strokeRect(-w-5,-h-8,w*2+10,8)}
 g.fillStyle='#2a8a7a';g.beginPath();g.ellipse(-3,-h*.4,5,3,.4,0,TAU);g.fill();g.fillStyle='#2a8a7a';g.beginPath();g.ellipse(4,-h*.7,4,2.5,-.3,0,TAU);g.fill();g.restore()}
function rpw2aArch(g,x,y,s){/* a ruined arch with a rune keystone */g.save();g.translate(x,y);rpw2aBlob(g,0,3,s*.9,s*.18,'#000',.35);
 const st=(x0,y0,w,h,c)=>{g.fillStyle=c;g.fillRect(x0,y0,w,h);g.strokeStyle=RPO;g.lineWidth=2;g.strokeRect(x0,y0,w,h)};
 for(const sx of[-1,1]){for(let k=0;k<4;k++)st(sx*s*.52-s*.12,-s*.26*(k+1),s*.24,s*.26,k%2?'#6a86b8':'#7a98c8')}
 g.beginPath();g.arc(0,-s*1.02,s*.64,Math.PI,Math.PI*1.72);g.arc(0,-s*1.02,s*.4,Math.PI*1.72,Math.PI,true);g.closePath();g.fillStyle='#7a98c8';g.fill();rpw2aOut(g,2.2);
 g.fillStyle='#4a6698';g.beginPath();g.moveTo(-s*.08,-s*1.66);g.lineTo(s*.12,-s*1.62);g.lineTo(s*.1,-s*1.4);g.lineTo(-s*.06,-s*1.42);g.closePath();g.fill();rpw2aOut(g,1.8);
 g.save();g.globalCompositeOperation='lighter';g.strokeStyle='rgba(110,240,255,.8)';g.lineWidth=1.6;g.beginPath();g.arc(-s*.52,-s*.62,4,0,Math.PI*1.4);g.moveTo(s*.46,-s*.4);g.lineTo(s*.56,-s*.5);g.lineTo(s*.48,-s*.6);g.stroke();g.restore();
 g.fillStyle='#2a8a7a';g.beginPath();g.ellipse(-s*.5,-s*1.04,s*.16,s*.05,-.4,0,TAU);g.fill();g.restore()}
function rpw2aRibs(g,x,y,s){g.save();g.translate(x,y);g.strokeStyle=RPO;g.lineWidth=7;const P=()=>{g.beginPath();g.moveTo(-s,0);g.quadraticCurveTo(0,-s*.12,s,0);for(let j=0;j<6;j++){const bx=-s*.8+j*s*.3;g.moveTo(bx,-s*.06);g.quadraticCurveTo(bx-s*.12,-s*.55,bx+s*.06,-s*.7+j*s*.05)}};
 P();g.stroke();g.strokeStyle='#d8e0f0';g.lineWidth=4;P();g.stroke();g.fillStyle='#d8e0f0';g.beginPath();g.ellipse(s*1.1,-s*.05,s*.22,s*.13,.2,0,TAU);g.fill();rpw2aOut(g,2);g.fillStyle=RPO;g.beginPath();g.arc(s*1.16,-s*.08,2.6,0,TAU);g.fill();g.restore()}
function rpw2aHead(g,x,y,s){/* a half-buried stone face */g.save();g.translate(x,y);rpw2aBlob(g,0,2,s*.8,s*.18,'#000',.35);g.beginPath();g.moveTo(-s*.55,0);g.quadraticCurveTo(-s*.62,-s*.8,0,-s*.92);g.quadraticCurveTo(s*.62,-s*.8,s*.55,0);g.closePath();
 const q=g.createLinearGradient(-s*.6,0,s*.6,0);q.addColorStop(0,'#9ab4dc');q.addColorStop(.5,'#6a86b8');q.addColorStop(1,'#34507e');g.fillStyle=q;g.fill();rpw2aOut(g,2.4);
 g.strokeStyle='rgba(18,8,31,.6)';g.lineWidth=2;g.beginPath();g.moveTo(-s*.3,-s*.5);g.quadraticCurveTo(-s*.18,-s*.56,-s*.06,-s*.5);g.moveTo(s*.06,-s*.5);g.quadraticCurveTo(s*.18,-s*.56,s*.3,-s*.5);g.moveTo(0,-s*.46);g.lineTo(-s*.05,-s*.28);g.lineTo(s*.04,-s*.26);g.moveTo(-s*.14,-s*.14);g.quadraticCurveTo(0,-s*.1,s*.14,-s*.14);g.stroke();
 g.fillStyle='#6af0ff';for(const sx of[-1,1]){g.beginPath();g.ellipse(sx*s*.18,-s*.44,s*.06,s*.03,0,0,TAU);g.fill()}g.fillStyle='#2a8a7a';g.beginPath();g.ellipse(-s*.3,-s*.82,s*.2,s*.07,-.3,0,TAU);g.fill();g.restore();return[x-s*.18,y-s*.44,x+s*.18,y-s*.44]}
/* a glowcap: a cluster of glowing mushroom caps on pale stalks (the range light) */
function rpw2aGlowcap(g,x,y,s,L){g.save();g.translate(x,y);rpw2aBlob(g,0,3,s*.75,s*.2,'#000',.4);
 for(const [dx,h,r,c] of[[-s*.36,s*.5,s*.26,1],[s*.34,s*.42,s*.22,2],[0,s*.78,s*.4,0]]){g.fillStyle='#d8f0ff';g.beginPath();g.moveTo(dx-r*.22,0);g.quadraticCurveTo(dx-r*.12,-h*.5,dx-r*.15,-h);g.lineTo(dx+r*.15,-h);g.quadraticCurveTo(dx+r*.12,-h*.5,dx+r*.22,0);g.closePath();g.fill();rpw2aOut(g,1.8);
  const C=RPW2A_GLOW[c],cy=-h;g.beginPath();g.moveTo(dx-r,cy+r*.1);g.quadraticCurveTo(dx-r*.95,cy-r*.85,dx,cy-r*.85);g.quadraticCurveTo(dx+r*.95,cy-r*.85,dx+r,cy+r*.1);g.quadraticCurveTo(dx,cy+r*.3,dx-r,cy+r*.1);g.closePath();
  const q=g.createLinearGradient(0,cy-r,0,cy+r*.2);q.addColorStop(0,'#ffffff');q.addColorStop(.4,C[0]);q.addColorStop(1,'#2a4aa8');g.fillStyle=q;g.fill();rpw2aOut(g,2);
  g.fillStyle='rgba(255,255,255,.9)';for(const [sx,sy,sr] of[[-.45,-.35,.12],[.1,-.6,.1],[.5,-.25,.09]]){g.beginPath();g.arc(dx+sx*r,cy+sy*r,sr*r,0,TAU);g.fill()}if(L)L.push([x+dx,y+cy-r*.3,r*1.6,C[1]])}
 g.restore()}
function rpw2aAbyssBake(map){const G=rpGeo(map),pal=RP_PAL.abyss,A=rpw2aCastle('abyss'),gt=G.gate;
 const cast={x:Math.round(gt.x-A.gx),y:Math.round(gt.y-A.gy),w:A.w,h:A.h},B={pal,G,cast,trees:[],id:'abyss',gl:[],bub:[],kelp:[]};
 const [lx,ly,lrx,lry]=map.lake||[650,425,250,135],inPit=(x,y,m)=>((x-lx)/(lrx+m))**2+((y-ly)/(lry+m))**2<1;
 /* no water field here: the whole map is the sea floor; F is the distance to the pit rim (> 0 inside) */
 const DR=rpw2aRoadGrid(G);
 const F=rpw2aGrid((x,y)=>rpw2aEll(x,y,lx,ly,lrx,lry)),N=rpw2aGrid((x,y)=>rpw2aFbm(x,y,6.3)),C=RPW2A_AB;B.F=F;
 const M=rpw2aGrid((x,y)=>rpw2aVN(x/70+3,y/70)),V=rpw2aGrid((x,y)=>{const v=Math.min(1,Math.hypot((x-800)/900,(y-450)/560));return v*v*.5}),GL=[140,240,255],BK=[0,0,0],DP=[4,8,24],PT=[6,12,30];
 const P=rpw2aPaint(F,N,M,(f,n,m,x,y,o,w)=>{rpw2aM3(o,C.g0,C.g1,rpw2aSS(.3,.75,n));const rip=Math.sin(x*.05+Math.sin(y*.04)*2.6+y*.03);if(rip>.7)rpw2aM3(o,o,C.sand,.35*(rip-.7)/.3);
  if(m>.62)rpw2aM3(o,o,C.g2,rpw2aSS(.62,.66,m)*.6);const gr=rpw2aIH(x,y);if(gr>.985)rpw2aM3(o,o,GL,.5);else if(gr<.06)rpw2aM3(o,o,BK,.15);
  /* darker toward the map edges and the pit */
  const fx=x>>3,fy=y>>3;rpw2aM3(o,o,DP,V.a[fy*V.W+fx]);if(f>-40)rpw2aM3(o,o,PT,rpw2aSS(-40,0,f)*.5)});
 const c=rpw2aCv(1600,900),g=c.getContext('2d');g.lineJoin='round';g.lineCap='round';g.drawImage(P.base,0,0);B.c=c;
 /* bioluminescent light pools on the floor */
 g.globalCompositeOperation='lighter';for(let i=0;i<40;i++){const x=rpw2aR(i*3+400)*1600,y=rpw2aR(i*3+401)*900;if(inPit(x,y,30))continue;const C2=RPW2A_GLOW[i%5][1],r=50+rpw2aR(i)*90;g.globalAlpha=.12;g.drawImage(rpw2aGl(C2,64),x-r,y-r*.6,r*2,r*1.2)}
 g.globalAlpha=1;for(let i=0;i<500;i++){const x=rpw2aR(i*2+800)*1600,y=rpw2aR(i*2+801)*900;if(inPit(x,y,10))continue;g.fillStyle=['#6af0ff','#ff8ae8','#8affc8'][i%3];g.globalAlpha=.35+rpw2aR(i)*.4;g.fillRect(x,y,1.8,1.8)}
 g.globalCompositeOperation='source-over';g.globalAlpha=1;
 /* sea grass and pebbles */
 for(let i=0;i<700;i++){const x=rpw2aR(i*2+90)*1600,y=rpw2aR(i*2+91)*900;if(inPit(x,y,30)||DR.at(x,y)<44)continue;g.strokeStyle=i%3?'#1a4a6a':'#2a6a7a';g.lineWidth=1.6;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x-3,y-5,x-1,y-9-rpw2aR(i)*6);g.moveTo(x+3,y);g.quadraticCurveTo(x+5,y-5,x+4,y-8-rpw2aR(i+3)*6);g.stroke()}
 /* the trench: a rocky lip, the pit falling away into the dark, ledges, the glowing rim */
 {rpw2aBlob(g,lx,ly+14,lrx+40,lry+30,'#000',.35);g.fillStyle='#1a2a50';g.beginPath();g.ellipse(lx,ly,lrx+22,lry+16,0,0,TAU);g.fill();rpw2aOut(g,3);
  g.save();g.beginPath();g.ellipse(lx,ly,lrx,lry,0,0,TAU);g.clip();
  let q=g.createRadialGradient(lx,ly+lry*.25,10,lx,ly,lrx*1.05);q.addColorStop(0,'#000000');q.addColorStop(.45,'#030818');q.addColorStop(.8,'#0c1c44');q.addColorStop(1,'#1c3468');g.fillStyle=q;g.fillRect(lx-lrx,ly-lry,lrx*2,lry*2);
  /* inner ledges: the far wall is lit, rings step down */
  for(let k=1;k<6;k++){const s=1-k*.13;g.strokeStyle=`rgba(90,140,220,${.32-k*.05})`;g.lineWidth=3;g.beginPath();g.ellipse(lx,ly+k*7,lrx*s,lry*s,0,Math.PI*1.04,Math.PI*1.96);g.stroke();
   g.strokeStyle=`rgba(0,0,0,${.4})`;g.lineWidth=2;g.beginPath();g.ellipse(lx,ly+k*7+3,lrx*s,lry*s,0,Math.PI*1.08,Math.PI*1.92);g.stroke()}
  g.globalCompositeOperation='lighter';for(let k=0;k<26;k++){const a=Math.PI*(1.05+rpw2aR(k+40)*.9),r=.55+rpw2aR(k+50)*.4,x=lx+Math.cos(a)*lrx*r,y=ly+Math.sin(a)*lry*r;g.globalAlpha=.5;g.fillStyle=RPW2A_GLOW[k%5][0];g.beginPath();g.arc(x,y,1.6+rpw2aR(k)*1.6,0,TAU);g.fill()}
  g.globalAlpha=.55;g.drawImage(rpw2aGl('60,200,160',90),lx-110,ly-40,220,130);g.globalCompositeOperation='source-over';g.globalAlpha=1;g.restore();
  g.lineWidth=3;g.strokeStyle=RPO;g.beginPath();g.ellipse(lx,ly,lrx,lry,0,0,TAU);g.stroke();
  g.save();g.globalCompositeOperation='lighter';g.strokeStyle='rgba(90,230,255,.32)';g.lineWidth=7;g.beginPath();g.ellipse(lx,ly,lrx-5,lry-4,0,Math.PI*.98,Math.PI*2.02);g.stroke();g.strokeStyle='rgba(170,250,255,.55)';g.lineWidth=2;g.stroke();
  /* glowing veins in the floor running out from the maw */
  for(let k=0;k<16;k++){const a=k/16*TAU+rpw2aR(k+90)*.3;let x=lx+Math.cos(a)*(lrx+26),y=ly+Math.sin(a)*(lry+20);const pts=[[x,y]];for(let j=0;j<5;j++){x+=Math.cos(a+(rpw2aR(k*9+j)-.5)*1.2)*26;y+=Math.sin(a+(rpw2aR(k*7+j)-.5)*1.2)*18;if(DR.at(x,y)<44||G.pads.some(p=>Math.hypot(p.x-x,(p.y-y)*1.3)<60))break;pts.push([x,y])}
   if(pts.length<3)continue;const col=k%3?'90,230,255':'255,110,230';for(const [lw,al] of[[6,.12],[2.2,.5]]){g.strokeStyle=`rgba(${col},${al})`;g.lineWidth=lw;g.beginPath();pts.forEach((p,j)=>j?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.stroke()}}
  g.restore();
  /* lip stones and glowing coral round the rim */
  const rim=[];for(let k=0;k<44;k++){const a=k/44*TAU+rpw2aR(k)*.08,x=lx+Math.cos(a)*(lrx+12),y=ly+Math.sin(a)*(lry+9);rim.push([x,y,k,a])}rim.sort((a,b)=>a[1]-b[1]);
  for(const [x,y,k,a] of rim){if(rpw2aPadHit(G,x-12,y-20,x+12,y))continue;if(k%4===1)rpw2aGlowCoral(g,x,y+4,16+rpw2aR(k)*8,k,k,B.gl);else rpw2aCrag(g,x,y+6,22+rpw2aR(k)*14,12+rpw2aR(k+3)*12,k,['#2a3c6a','#4a6496','#16223e'])}}
 /* the road: a sunken causeway of pale old flagstones with rune marks */
 rpw2aRoad(g,G,{edge:'#060c1e',curb:'#4a6494',fill:'#36507e',texStep:4,
  tex:(g,P,i,p)=>{const nx=-Math.sin(p.a),ny=Math.cos(p.a),tx=Math.cos(p.a),ty=Math.sin(p.a),row=(i/4|0);for(let k=0;k<3;k++){const o=-20+k*20+(row%2?10:0);if(o>26)continue;const cx=p.x+nx*o,cy=p.y+ny*o,hw=8.5,hh=7;
   g.fillStyle=['#46628e','#3e5a86','#4e6c9a','#42608c'][(row+k)%4];g.beginPath();g.moveTo(cx-nx*hw-tx*hh,cy-ny*hw-ty*hh);g.lineTo(cx+nx*hw-tx*hh,cy+ny*hw-ty*hh);g.lineTo(cx+nx*hw+tx*hh,cy+ny*hw+ty*hh);g.lineTo(cx-nx*hw+tx*hh,cy-ny*hw+ty*hh);g.closePath();g.fill();
   g.strokeStyle='rgba(6,12,30,.65)';g.lineWidth=1.3;g.stroke()}if(rpw2aR(i*7)<.06){g.save();g.globalCompositeOperation='lighter';g.strokeStyle='rgba(110,240,255,.55)';g.lineWidth=1.6;g.beginPath();g.arc(p.x+nx*6,p.y+ny*6,5,0,Math.PI*1.5);g.moveTo(p.x-nx*8,p.y-ny*8);g.lineTo(p.x-nx*2+tx*5,p.y-ny*2+ty*5);g.stroke();g.restore()}},
  stStep:6,stone:(g,x,y,a,i,sd)=>{g.fillStyle=i%3?'#5a78aa':'#4a6898';g.strokeStyle=RPO;g.lineWidth=1.6;g.beginPath();g.ellipse(x,y,7,5,a,0,TAU);g.fill();g.stroke();if(i%5===0){g.fillStyle='#6af0ff';g.beginPath();g.arc(x,y-1,1.6,0,TAU);g.fill()}},chev:'rgba(140,240,255,.3)'});
 /* props by depth: ruins, kelp roots, coral, anemones, clams, urchins, vents, whale bones; glowcaps at map.glow */
 const taken=[[lx,ly,Math.max(lrx,lry)+30]],items=[],free=(x,y,o)=>rpw2aFree(G,B,x,y,Object.assign({taken},o||{}))&&!inPit(x,y,40);
 for(const p of map.glow||[]){/* the glowcap stands at its light, nudged sideways if a pad's tower would cover it */let dx=0;for(const d of[0,8,-8,16,-16,22,-22,26,-26,30,-30,36,-36])if(!rpw2aPadHit(G,p[0]+d-22,p[1]-40,p[0]+d+20,p[1]+2)){dx=d;break}
  items.push({k:'cap',x:p[0]+dx,y:p[1]+4,i:0});taken.push([p[0],p[1],60])}
 /* hero props: each looks for a free spot near where it would like to be */
 const near=(x0,y0,w,h)=>{for(let k=0;k<160;k++){const a=k*2.4,d=k*4,x=x0+Math.cos(a)*d,y=y0+Math.sin(a)*d*.7;if(x<30||x>1570||y<40||y>880)continue;if(free(x,y,{road:70,w,h}))return[x,y]}return null};
 for(const [x0,y0,k,s] of[[1000,120,'ribs',62],[160,460,'head',56],[270,96,'col',92],[330,104,'colb',62],[1190,780,'col',84],[600,800,'arch',70],[90,820,'vent',44],[930,820,'vent',40],[1240,150,'vent',36],[1500,820,'clam',30],[60,420,'clam',26]]){
  const p=near(x0,y0,s*1.4,s);if(!p)continue;items.push({k,x:p[0],y:p[1],s,i:x0});taken.push([p[0],p[1],s*.9])}
 for(let i=0;i<2600&&items.length<200;i++){const x=rpw2aR(i*4+31)*1640-20,y=rpw2aR(i*4+32)*940-20;if(!free(x,y,{road:66}))continue;const d=DR.at(x,y),r=rpw2aR(i*4+33);if(rpw2aR(i+5)<(d>170?.2:.55))continue;
  let k=r<.3?'coral':r<.48?'anem':r<.6?'rock':r<.7?'urchin':r<.82?'kelp':'tuft';
  if(k==='kelp'){if(!free(x,y,{road:70,w:40,h:130}))continue;B.kelp.push([x,y,90+rpw2aR(i)*60,i]);continue}if(k==='clam'&&!free(x,y,{w:50,h:40}))continue;
  items.push({k,x,y,i,h:20+rpw2aR(i*4+34)*16})}
 items.sort((a,b)=>a.y-b.y);B.vent=[];B.face=null;
 for(const it of items){const {x,y,i,h}=it;switch(it.k){
  case'coral':rpw2aGlowCoral(g,x,y,h+8,i,i,B.gl);break;case'anem':rpw2aAnemone(g,x,y,h+6,i,B.gl);break;case'rock':rpw2aCrag(g,x,y,26+rpw2aR(i)*20,18+rpw2aR(i+1)*16,i,['#2a3c6a','#4a6496','#16223e']);break;
  case'urchin':rpw2aUrchin(g,x,y,14+rpw2aR(i)*6);break;case'clam':rpw2aClam(g,x,y,26,B.gl);break;case'tuft':rpw2aTuft(g,x,y,16,'#2a7a8a',6);break;
  case'cap':rpw2aGlowcap(g,x,y,36,B.gl);break;case'ribs':rpw2aRibs(g,x,y,it.s);break;case'head':B.face=rpw2aHead(g,x,y,it.s);break;
  case'col':rpw2aColumn(g,x,y,it.s,0,i);break;case'arch':rpw2aArch(g,x,y,it.s);break;case'colb':rpw2aColumn(g,x,y,it.s,1,i);break;case'vent':B.vent.push(rpw2aVent(g,x,y,it.s));break}}
 B.trees=items;
 for(const e of G.ent)rpw2aSeaCave(g,Math.max(30,e.x-14),e.y,'abyss');
 g.drawImage(A.c,cast.x,cast.y,A.w,A.h);
 /* light shafts from far above */
 g.save();g.globalCompositeOperation='lighter';for(let i=0;i<4;i++){g.globalAlpha=.06;g.save();g.translate(220+i*400,-20);g.rotate(-.32+i*.04);g.drawImage(rpw2aRaySpr(),-60,0,130+i%2*50,780);g.restore()}g.restore();
 /* every light source gets a soft halo baked in; a spread-out few of them pulse live (B.pulse) */
 g.save();g.globalCompositeOperation='lighter';for(const p of B.gl){const r=p[2]*1.3;g.globalAlpha=.22;g.drawImage(rpw2aGl(p[3],24),p[0]-r,p[1]-r,r*2,r*2)}g.restore();
 B.pulse=[];for(const p of B.gl.slice().sort((a,b)=>b[2]-a[2])){if(B.pulse.length>=12)break;if(B.pulse.some(q=>Math.hypot(q[0]-p[0],q[1]-p[1])<70))continue;B.pulse.push(p)}
 /* bubble sources: vents, clams, coral */
 for(const v of B.vent)B.bub.push([v[0],v[1],1]);for(let i=0;i<B.gl.length&&B.bub.length<26;i+=3)B.bub.push([B.gl[i][0],B.gl[i][1],0]);
 B.kelp.sort((a,b)=>a[1]-b[1]);
 return B}
/* the Sunken Palace: sea-glass stone with gold trim, verdigris onion domes, a great dome crowned by a glowing pearl, a columned portico
   at the gate, glowing windows, coral and anemones at its feet and one of the Kraken's tentacles coiled round the east tower */
function rpw2aOnion(g,P,cx,by,R,h,A,flag,pearl){const E=R*.3,ay=by-h;
 const path=()=>{g.beginPath();g.moveTo(cx-R,by);g.bezierCurveTo(cx-R*1.45,by-h*.42,cx-R*.25,by-h*.62,cx,ay);g.bezierCurveTo(cx+R*.25,by-h*.62,cx+R*1.45,by-h*.42,cx+R,by);g.ellipse(cx,by,R,E,0,0,Math.PI);g.closePath()};
 g.save();path();const q=g.createLinearGradient(cx-R*1.2,0,cx+R*1.2,0);q.addColorStop(0,P.roof);q.addColorStop(.3,P.rl);q.addColorStop(.6,P.roof);q.addColorStop(1,P.rd);g.fillStyle=q;g.fill();g.clip();
 g.strokeStyle='rgba(10,40,50,.4)';g.lineWidth=1.3;for(let k=-3;k<=3;k++){g.beginPath();g.moveTo(cx+k*R*.3,by+E*.8);g.bezierCurveTo(cx+k*R*.48,by-h*.42,cx+k*R*.1,by-h*.62,cx,ay);g.stroke()}
 g.fillStyle='rgba(255,255,255,.3)';g.beginPath();g.ellipse(cx-R*.45,by-h*.38,R*.2,h*.16,-.3,0,TAU);g.fill();g.restore();path();rpw2aOut(g,2.4);
 g.fillStyle='#ffc94a';g.beginPath();g.ellipse(cx,by,R*1.02,E+2,0,0,Math.PI);g.lineTo(cx-R*1.02,by-3);g.ellipse(cx,by-3,R*1.02,E+1,0,Math.PI,0,true);g.closePath();g.fill();rpw2aOut(g,1.6);
 g.strokeStyle=RPO;g.lineWidth=2;g.beginPath();g.moveTo(cx,ay+2);g.lineTo(cx,ay-12);g.stroke();
 if(pearl){g.fillStyle='#f4fcff';g.beginPath();g.arc(cx,ay-12-pearl,pearl,0,TAU);g.fill();rpw2aOut(g,2);g.fillStyle='#ffffff';g.beginPath();g.arc(cx-pearl*.35,ay-12-pearl*1.35,pearl*.3,0,TAU);g.fill();A.gem=[cx,ay-12-pearl];A.bub.push([cx,ay-12-pearl*2])}
 else{g.fillStyle='#ffd45a';g.beginPath();g.arc(cx,ay-12,3,0,TAU);g.fill();rpw2aOut(g,1.4);A.bub.push([cx,ay-16])}
 if(flag)A.flags.push({x:cx,y:ay-12,len:flag,col:P.ban,c2:P.ban2})}
function rpw2aTentacleBaked(g,pts,w0){const L=[],R=[];for(let i=0;i<pts.length;i++){const a=pts[Math.max(0,i-1)],b=pts[Math.min(pts.length-1,i+1)],an=Math.atan2(b[1]-a[1],b[0]-a[0]),w=w0*(1-i/pts.length*.85);
  L.push([pts[i][0]-Math.sin(an)*w,pts[i][1]+Math.cos(an)*w]);R.push([pts[i][0]+Math.sin(an)*w,pts[i][1]-Math.cos(an)*w])}
 g.beginPath();g.moveTo(L[0][0],L[0][1]);for(const p of L)g.lineTo(p[0],p[1]);for(let i=R.length-1;i>=0;i--)g.lineTo(R[i][0],R[i][1]);g.closePath();g.fillStyle='#7a2a6a';g.fill();rpw2aOut(g,2.2);
 g.fillStyle='#f0b0d8';for(let i=1;i<pts.length-1;i+=2){const p=L[i],q=pts[i];g.beginPath();g.ellipse((p[0]*2+q[0])/3,(p[1]*2+q[1])/3,2.6,2,0,0,TAU);g.fill();g.strokeStyle='rgba(18,8,31,.6)';g.lineWidth=1;g.stroke()}}
function rpw2aPaintAbyss(g,A){const P=RPW2A_CP.abyss,id='moss';A.P=P;
 g.fillStyle='rgba(0,0,0,.35)';g.beginPath();g.ellipse(196,508,118,16,0,0,TAU);g.fill();
 g.save();g.globalCompositeOperation='lighter';g.globalAlpha=.6;g.drawImage(rpw2aGl('60,200,255',120),30,60,280,300);g.restore();
 rpwRocks(g,P,'abyss',[[282,310,44,64],[288,390,40,84],[282,470,48,84],[290,520,40,90]],40);
 /* the great dome behind the hall, crowned with the pearl */
 {const cx=168,t=rpwDrum(g,P,cx,200,96,40,11);rpw2aOnion(g,P,cx,t,50,96,A,0,9);for(const dx of[-30,-10,10,30])rpwWin(g,P,id,A,cx+dx-4,t+12,8,16)}
 rpwWall(g,P,112,196,114,146,31,10);rpwCren(g,P,'wonder',112,196,114,10);
 for(const [x,y] of[[124,222],[204,222],[126,282],[202,282]])rpwWin(g,P,id,A,x,y,11,20);
 {const x=169,y=250,r=19;g.fillStyle='#ffc94a';g.beginPath();g.arc(x,y,r+4,0,TAU);g.fill();rpw2aOut(g,2.2);const q=g.createRadialGradient(x-5,y-5,2,x,y,r);q.addColorStop(0,'#ffffff');q.addColorStop(.5,'#8affff');q.addColorStop(1,'#2a8ad0');g.fillStyle=q;g.beginPath();g.arc(x,y,r,0,TAU);g.fill();
  g.strokeStyle=RPO;g.lineWidth=1.6;g.beginPath();g.moveTo(x,y-r);g.lineTo(x,y+r);g.moveTo(x-r*.7,y-r*.4);g.lineTo(x,y+2);g.lineTo(x+r*.7,y-r*.4);g.stroke();g.beginPath();g.arc(x,y,r,0,TAU);g.stroke();A.wins.push([x,y,36]);A.rose=[x,y]}
 for(const cx of[112,226]){const t=rpwDrum(g,P,cx,306,30,152,cx);rpw2aOnion(g,P,cx,t,17,40,A,cx===226?22:0);rpwWin(g,P,id,A,cx-4,t+30,8,15)}
 rpwWall(g,P,56,262,64,96,51,9);rpwCren(g,P,'wonder',56,262,64,9);rpwWall(g,P,184,300,40,176,61,9);rpwCren(g,P,'wonder',184,300,40,9);
 {const t=rpwDrum(g,P,46,362,46,176,71);rpw2aOnion(g,P,46,t,26,58,A,26);rpwWin(g,P,id,A,40,t+34,11,20);rpwWin(g,P,id,A,40,t+96,11,20)}
 rpwRocks(g,P,'abyss',[[18,384,40,30],[52,390,58,34],[88,384,40,24],[30,372,30,20]],7);
 rpw2aGlowCoral(g,16,392,22,0,0,null);rpw2aAnemone(g,40,394,18,1,null);rpw2aGlowCoral(g,84,388,16,3,1,null);
 /* the east tower with the Kraken's tentacle coiled round it */
 {const cx=246,w=70,t=rpwDrum(g,P,cx,490,w,224,81);rpwCren(g,P,'wonder',cx-35,t+2,70,9);const t2=rpwDrum(g,P,cx,t-4,50,30,82);rpw2aOnion(g,P,cx,t2,32,84,A,34);
  rpwWin(g,P,id,A,cx-6,t+40,12,22);rpwWin(g,P,id,A,cx-16,t+108,11,20);rpwWin(g,P,id,A,cx+8,t+156,10,18);rpwBanner(g,P,'wonder',cx-10,t+62,20,44);
  const pts=[];for(let k=0;k<=20;k++){const u=k/20;pts.push([cx+44-u*30+Math.sin(u*7)*10-(u>.8?(u-.8)*120:0),t+226-u*170+(u>.85?(u-.85)*90:0)])}rpw2aTentacleBaked(g,pts,12);
  A.glint=[[cx-30,t+130],[cx+20,t+80]]}
 /* the gatehouse as a columned portico with a pediment */
 rpwWall(g,P,96,326,88,148,91,9);g.fillStyle='#ffc94a';g.fillRect(90,470,100,7);g.strokeStyle=RPO;g.lineWidth=2.2;g.strokeRect(90,470,100,7);
 rpwGate(g,P,'abyss',A,RPW2A_GX,470,48,82);
 for(const x of[98,182]){g.fillStyle='#a8e0ee';g.fillRect(x-6,378,12,92);g.strokeStyle=RPO;g.lineWidth=2;g.strokeRect(x-6,378,12,92);g.strokeStyle='rgba(18,8,31,.35)';g.lineWidth=1;g.beginPath();g.moveTo(x-2,380);g.lineTo(x-2,468);g.moveTo(x+2,380);g.lineTo(x+2,468);g.stroke();
  g.fillStyle='#ffc94a';g.fillRect(x-9,372,18,7);g.strokeStyle=RPO;g.lineWidth=1.6;g.strokeRect(x-9,372,18,7)}
 g.fillStyle='#c8f4fa';g.beginPath();g.moveTo(84,372);g.lineTo(RPW2A_GX,334);g.lineTo(196,372);g.closePath();g.fill();rpw2aOut(g,2.4);g.fillStyle='#ffc94a';g.fillRect(84,370,112,5);g.strokeStyle=RPO;g.lineWidth=1.6;g.strokeRect(84,370,112,5);
 {const x=RPW2A_GX,y=356;g.strokeStyle='#ffc94a';g.lineWidth=3;g.beginPath();g.moveTo(x,y+12);g.lineTo(x,y-8);g.moveTo(x-8,y-6);g.quadraticCurveTo(x-8,y+2,x,y+2);g.quadraticCurveTo(x+8,y+2,x+8,y-6);g.stroke();
  g.fillStyle='#ffc94a';for(const dx of[-8,0,8]){g.beginPath();g.moveTo(x+dx-2.5,y-6);g.lineTo(x+dx,y-12);g.lineTo(x+dx+2.5,y-6);g.closePath();g.fill()}}
 rpwTorch(g,A,112,410);rpwTorch(g,A,168,410);
 rpwRocks(g,P,'abyss',[[206,508,56,30],[248,516,70,34],[288,516,40,26],[194,494,26,16]],27);
 rpw2aClam(g,228,512,24,null);rpw2aGlowCoral(g,200,502,20,1,0,null);rpw2aAnemone(g,268,512,18,4,null);rpw2aGlowCoral(g,290,506,16,2,2,null);
 A.gemCol='140,255,255';A.spark.push([169,250],[246,92])}
/* ---------- Kraken's Maw: live ---------- */
const RPW2A_TENT=[[-.84,.12,-2.1,190,24,-1,-.55,0],[-.42,-.8,-2.95,112,15,1,.7,1.3],[.42,-.8,-.19,112,15,-1,-.7,2.1],[.86,.1,-1.05,190,24,1,.55,3.4],[-.3,.64,-1.75,150,21,-1,-.45,4.2],[.3,.64,-1.4,146,21,1,.45,5.1]];
function rpw2aRaySpr(){return rpw2aSpr('ray',80,512,g=>{const q=g.createLinearGradient(0,0,0,512);q.addColorStop(0,'rgba(150,230,255,.9)');q.addColorStop(1,'rgba(150,230,255,0)');g.fillStyle=q;g.beginPath();g.moveTo(26,0);g.lineTo(54,0);g.lineTo(80,512);g.lineTo(0,512);g.closePath();g.fill()})}
function rpw2aWhirlSpr(){return rpw2aSpr('whirl',128,128,g=>{g.translate(64,64);const q=g.createRadialGradient(0,0,4,0,0,62);q.addColorStop(0,'rgba(0,4,16,.95)');q.addColorStop(.3,'rgba(14,50,110,.75)');q.addColorStop(.75,'rgba(40,130,210,.35)');q.addColorStop(1,'rgba(40,130,210,0)');g.fillStyle=q;g.beginPath();g.arc(0,0,62,0,TAU);g.fill();
 for(let k=0;k<5;k++){g.beginPath();for(let j=0;j<=34;j++){const u=j/34,a=k*TAU/5+u*4.4,r=5+u*56;j?g.lineTo(Math.cos(a)*r,Math.sin(a)*r):g.moveTo(Math.cos(a)*r,Math.sin(a)*r)}g.strokeStyle='rgba(18,8,31,.55)';g.lineWidth=7;g.stroke();g.strokeStyle='rgba(150,235,255,.9)';g.lineWidth=4;g.stroke();g.strokeStyle='#ffffff';g.lineWidth=1.4;g.stroke()}})}
/* one tentacle: base (x, y), heading a0, length L, base width w, tip curl (+-1), S-bend, wave phase; suckers on the inner side.
   The step shrinks toward the tip so the tip rolls up in a tight curl. */
function rpw2aTentacle(c,x,y,a0,L,w,curl,bend,ph,t,lite){const n=22,Lp=[],Rp=[],C=[];let px=x,py=y;
 for(let i=0;i<=n;i++){const s=i/n,e=Math.max(0,s-.5),a=a0+bend*Math.sin(s*Math.PI*1.25)+curl*e*e*24+Math.sin(t*.8+ph-s*3)*.3*s;C.push([px,py,a]);const ww=w*Math.pow(1-s,.7)+1.4,nx=-Math.sin(a),ny=Math.cos(a);
  Lp.push([px+nx*ww*curl,py+ny*ww*curl]);Rp.push([px-nx*ww*curl,py-ny*ww*curl]);const st=L/n*(1.25-s*.75);px+=Math.cos(a)*st;py+=Math.sin(a)*st*.86}
 c.fillStyle='rgba(0,0,0,.5)';c.beginPath();c.ellipse(x,y+3,w*1.6,w*.62,0,0,TAU);c.fill();
 const body=()=>{c.beginPath();c.moveTo(Lp[0][0],Lp[0][1]);for(const p of Lp)c.lineTo(p[0],p[1]);for(let i=Rp.length-1;i>=0;i--)c.lineTo(Rp[i][0],Rp[i][1]);c.closePath()};
 body();c.fillStyle='#5a2068';c.fill();
 c.beginPath();for(let i=0;i<=n;i++){const p=Lp[i],q=C[i];i?c.lineTo(p[0]*.5+q[0]*.5,p[1]*.5+q[1]*.5):c.moveTo(p[0]*.5+q[0]*.5,p[1]*.5+q[1]*.5)}for(let i=n;i>=0;i--)c.lineTo(Lp[i][0],Lp[i][1]);c.closePath();c.fillStyle='#d070b0';c.fill();
 c.strokeStyle='rgba(255,170,230,.45)';c.lineWidth=2;c.beginPath();for(let i=0;i<n;i++){const p=Rp[i],q=C[i];const xx=p[0]*.62+q[0]*.38,yy=p[1]*.62+q[1]*.38;i?c.lineTo(xx,yy):c.moveTo(xx,yy)}c.stroke();
 body();c.lineWidth=2.6;c.strokeStyle=RPO;c.stroke();
 if(lite)return;c.fillStyle='#ffd8ee';c.strokeStyle='rgba(60,10,50,.7)';c.lineWidth=1.1;c.beginPath();for(let i=1;i<n-2;i+=2){const p=Lp[i],q=C[i],r=Math.max(1.3,(w*Math.pow(1-i/n,.7))*.26);const xx=p[0]*.72+q[0]*.28,yy=p[1]*.72+q[1]*.28;c.moveTo(xx+r,yy);c.ellipse(xx,yy,r,r*.8,0,0,TAU)}c.fill();c.stroke();
 c.fillStyle='#7af0ff';c.beginPath();for(let i=2;i<n-3;i+=3){const p=Rp[i],q=C[i],xx=p[0]*.55+q[0]*.45,yy=p[1]*.55+q[1]*.45;c.moveTo(xx+1.8,yy);c.arc(xx,yy,1.8,0,TAU)}c.fill()}
/* the Kraken's eye deep in the maw: it glows, blinks and watches the leading monster (the eye white is a baked sprite) */
function rpw2aEyeSpr(){return rpw2aSpr('kreye',76,68,g=>{g.translate(38,34);const eye=()=>{g.beginPath();g.moveTo(-34,0);g.quadraticCurveTo(0,-30,34,0);g.quadraticCurveTo(0,30,-34,0);g.closePath()};
 eye();const q=g.createRadialGradient(0,0,2,0,0,34);q.addColorStop(0,'#fffbc0');q.addColorStop(.5,'#d8f04a');q.addColorStop(1,'#5a8a1a');g.fillStyle=q;g.fill();g.save();eye();g.clip();g.strokeStyle='rgba(90,120,20,.5)';g.lineWidth=1.2;
 g.beginPath();for(let k=0;k<14;k++){const a=k/14*TAU;g.moveTo(Math.cos(a)*7,Math.sin(a)*7);g.lineTo(Math.cos(a)*26,Math.sin(a)*20)}g.stroke();g.restore();eye();g.lineWidth=3;g.strokeStyle=RPO;g.stroke()})}
function rpw2aEye(c,R,x,y,t){const F=R.foes;let tx=x,ty=y+40;if(F&&F.length){let b=null;for(const e of F){if(e.dead)continue;if(!b||e.s>b.s)b=e}if(b){try{const q=rpPos(R,b);tx=q.x;ty=q.y}catch(e){}}}else{tx=x+Math.sin(t*.4)*200;ty=y+Math.cos(t*.3)*80}
 const bl=R.rm?1:((t%6.5)<.18?Math.abs(Math.cos((t%6.5)/.18*Math.PI)):1),a=Math.atan2(ty-y,tx-x),d=Math.min(1,Math.hypot(tx-x,ty-y)/300);
 c.globalCompositeOperation='lighter';c.globalAlpha=.55+.15*Math.sin(t*1.3);c.drawImage(rpw2aGl('200,255,90',60),x-80,y-46,160,92);c.globalCompositeOperation='source-over';c.globalAlpha=1;
 c.drawImage(rpw2aEyeSpr(),x-38,y-34*bl,76,68*bl);if(bl<.25)return;const px=x+Math.cos(a)*14*d,py=y+Math.sin(a)*6*d*bl;
 c.fillStyle='#0a0614';c.beginPath();c.ellipse(px,py,4.5,13*bl,0,0,TAU);c.fill();c.fillStyle='rgba(255,255,255,.8)';c.beginPath();c.ellipse(px-9,py-6*bl,3.4,2.2*bl,-.4,0,TAU);c.fill()}
function rpw2aAbyssAmb(c,R){const B=R.bake,t=R.t,lite=R.lite,rm=R.rm,map=R.map,[lx,ly,lrx,lry]=map.lake||[650,425,250,135];c.save();
 /* glow pulses over the coral, anemones and glowcaps */
 c.globalCompositeOperation='lighter';const L=B.pulse,st=lite?3:1;for(let i=0;i<L.length;i+=st){const p=L[i],a=.3*Math.max(0,Math.sin(t*1.3+i*1.37)),r=p[2]*1.5;if(a<.02)continue;c.globalAlpha=a;c.drawImage(rpw2aGl(p[3],24),p[0]-r,p[1]-r,r*2,r*2)}
 /* the eye's light and the glow deep in the maw */
 c.globalAlpha=.25+.1*Math.sin(t*.8);c.drawImage(rpw2aGl('80,220,190',80),lx-lrx*.7,ly-lry*.5,lrx*1.4,lry*1.2);c.globalCompositeOperation='source-over';c.globalAlpha=1;
 rpw2aEye(c,R,lx,ly+lry*.18,t);
 /* tentacles round the maw (back ones first) */
 const tt=rm?0:t;for(const T of RPW2A_TENT){if(T[1]>0)continue;rpw2aTentacle(c,lx+T[0]*lrx,ly+T[1]*lry,T[2],T[3],T[4],T[5],T[6],T[7],tt,lite)}
 for(const T of RPW2A_TENT){if(T[1]<=0)continue;rpw2aTentacle(c,lx+T[0]*lrx,ly+T[1]*lry,T[2],T[3],T[4],T[5],T[6],T[7],tt,lite)}
 /* swaying kelp: stems and leaves batched in two colour groups */
 for(let gi=0;gi<2;gi++){const S=[],Lf=[];for(let i=gi;i<B.kelp.length;i+=2){const [x,y,h,s]=B.kelp[i],n=8,sw=rm?0:1,pts=[[x,y]];for(let k=1;k<=n;k++){const u=k/n;pts.push([x+Math.sin(t*.9+s+u*2.4)*14*u*sw+u*6,y-h*u,u,k])}S.push(pts);
   for(let k=1;k<pts.length;k++){const [xx,yy,u]=pts[k],sd=k%2?1:-1;Lf.push([xx+sd*9*(1-u*.5)*.8,yy+2,9*(1-u*.5),sd*.6+Math.sin(t+k)*.1*sw])}}
  c.beginPath();for(const P of S){c.moveTo(P[0][0],P[0][1]);for(const p of P)c.lineTo(p[0],p[1])}c.lineWidth=7;c.strokeStyle=RPO;c.stroke();c.lineWidth=4.4;c.strokeStyle=gi?'#1a6a6a':'#227a62';c.stroke();
  c.beginPath();for(const [x,y,r,a] of Lf){c.moveTo(x+Math.cos(a)*r,y+Math.sin(a)*r);c.ellipse(x,y,r,3.6,a,0,TAU)}c.fillStyle=gi?'#2a8a7a':'#2e9a6e';c.fill();c.strokeStyle=RPO;c.lineWidth=1.4;c.stroke()}
 /* bubbles from vents, coral and clams */
 if(!rm){c.strokeStyle='rgba(190,250,255,.75)';c.lineWidth=1.3;c.beginPath();const bs=lite?2:1;for(let i=0;i<B.bub.length;i+=bs){const b=B.bub[i],n=b[2]?4:2;for(let k=0;k<n;k++){const u=(t*(b[2]?.5:.3)+k/n+i*.29)%1,x=b[0]+Math.sin(t*2+i+k)*4*u,y=b[1]-u*(b[2]?130:70),r=1.4+u*(b[2]?3:2);c.moveTo(x+r,y);c.arc(x,y,r,0,TAU)}}c.stroke()}
 /* plankton motes and the stone face's eyes */
 if(!rm){c.globalCompositeOperation='lighter';c.fillStyle='#8affff';const n=lite?16:40;c.beginPath();for(let i=0;i<n;i++){const ph=t*.12+i*1.7,x=((rpw2aR(i+3)*1600+Math.sin(ph)*50+t*6)%1600+1600)%1600,y=((rpw2aR(i+9)*900-t*(8+i%5*3))%900+900)%900;c.moveTo(x+1.8,y);c.arc(x,y,1.8,0,TAU)}c.globalAlpha=.5;c.fill();
  if(B.face){c.globalAlpha=.35+.25*Math.sin(t*1.1);for(let k=0;k<2;k++)c.drawImage(rpw2aGl('90,240,255',18),B.face[k*2]-18,B.face[k*2+1]-18)}c.globalCompositeOperation='source-over'}
 c.globalAlpha=1;c.restore();try{rpw2aCastleLive(c,rpw2aCastle('abyss'),B.cast.x,B.cast.y,t,lite)}catch(e){}}
/* the twists: glowcap light pools (towers inside get more range) and whirlpools spinning on the road */
function rpw2aAbyssTwist(c,R){const map=R.map,t=R.t,rm=R.rm;c.save();c.globalCompositeOperation='lighter';const gr=map.glowR||150;
 for(let i=0;i<(map.glow||[]).length;i++){const [x,y]=map.glow[i],p=.5+.5*Math.sin(t*1.2+i*1.7);c.globalAlpha=.16+.08*p;c.drawImage(rpw2aGl('90,240,255',64),x-gr*.75,y-gr*.75*RPFX.sq,gr*1.5,gr*1.5*RPFX.sq);
  c.globalAlpha=.36+.18*p;c.strokeStyle='#8affff';c.lineWidth=2;c.setLineDash([6,10]);c.lineDashOffset=-t*12;c.beginPath();c.ellipse(x,y,gr,gr*RPFX.sq,0,0,TAU);c.stroke();c.setLineDash([])}
 c.globalCompositeOperation='source-over';
 const W=rpw2aWhirlSpr();for(let i=0;i<(map.whirl||[]).length;i++){const [x,y,r]=map.whirl[i];c.save();c.translate(x,y);c.scale(1,.55);c.globalAlpha=.95;c.save();c.rotate(rm?0:-t*2.6);c.drawImage(W,-r*1.25,-r*1.25,r*2.5,r*2.5);c.restore();
  c.globalAlpha=.6;c.rotate(rm?0:-t*1.4+1);c.drawImage(W,-r*.8,-r*.8,r*1.6,r*1.6);c.restore();
  if(!rm){c.strokeStyle='rgba(200,250,255,.8)';c.lineWidth=1.4;c.beginPath();for(let k=0;k<6;k++){const u=(t*.5+k/6)%1,a=-t*3+k*2.1,rr=r*1.1*(1-u);const bx=x+Math.cos(a)*rr,by=y+Math.sin(a)*rr*.55;c.moveTo(bx+2,by);c.arc(bx,by,1.4+u*1.6,0,TAU)}c.stroke()}}
 c.restore()}
/* ---------- the World 2 painting for the hub: a sunny archipelago with the reef island (Coral Shallows), the misty cove (Shipwreck
   Cove) and the dark trench (Kraken's Maw), linked by dotted sea routes; each castle stands at its node (the hub puts the labels just
   below the nodes, as in World 1). RPW.world[2]() -> {c, nodes, anim(g, t)}; anim draws only the live overlay on top of c. ---------- */
const RPW2A_NODES={coral:{x:292,y:612},wreck:{x:668,y:352},abyss:{x:1032,y:622}},RPW2A_WS=.46;
function rpw2aIsle(x,y){/* > 0 on land: the reef island, the cove island; the trench islet */
 const nz=(rpw2aVN(x/60,y/60+11)-.5)*34+Math.sin(x*.05+y*.03)*5;
 let r=rpw2aEll(x,y,300,590,210,120);r=rpw2aSmax(r,rpw2aEll(x,y,160,520,100,72),40);r=rpw2aSmax(r,rpw2aEll(x,y,440,540,96,62),40);r=rpw2aSmin(r,-rpw2aEll(x,y,330,700,70,34),20);
 let w=rpw2aEll(x,y,668,290,250,160);w=rpw2aSmax(w,rpw2aEll(x,y,520,250,90,70),40);w=rpw2aSmin(w,-rpw2aEll(x,y,742,418,104,74),24);
 const t=rpw2aEll(x,y,1052,640,92,44);
 return Math.max(r,w,t)+nz}
const rpw2aTrench=(x,y)=>rpw2aEll(x,y,946,560,182,98)+(rpw2aVN(x/40,y/40+5)-.5)*18;
function rpw2aWorld(){if(RPW2A.world)return RPW2A.world;const W={nodes:RPW2A_NODES};
 const c=rpw2aCv(1600,900),g=c.getContext('2d');g.lineJoin='round';g.lineCap='round';W.c=c;
 const L=rpw2aGrid(rpw2aIsle),T=rpw2aGrid(rpw2aTrench),N=rpw2aGrid((x,y)=>rpw2aFbm(x,y,8.8));
 const sea0=rpw2aCol('#7ef0e6'),sea1=rpw2aCol('#2ec6d8'),sea2=rpw2aCol('#1a8ed0'),sea3=rpw2aCol('#1660b8'),tr0=rpw2aCol('#0a1840'),tr1=rpw2aCol('#020614'),sand=rpw2aCol('#f6dea4'),grass=rpw2aCol('#4cb848'),grass2=rpw2aCol('#86d85a'),
  rock=rpw2aCol('#5a6670'),moss=rpw2aCol('#3e6a50'),moss2=rpw2aCol('#56806a'),cove=rpw2aCol('#a89c80'),dark=rpw2aCol('#2a3a4c'),rim=rpw2aCol('#163a4a'),WH=[255,255,255],CY=[120,250,255],c2=[0,0,0];
 const P=rpw2aPaint(L,N,T,(f,n,m,x,y,o,w)=>{
  if(f>0){const reef=x<560&&y>380,isl=x>960&&y>560;
   if(reef){const b=rpw2aSS(-1.5,1.5,f-26-(n-.5)*30);rpw2aM3(c2,grass,grass2,rpw2aSS(.3,.75,n));rpw2aM3(o,sand,c2,b);if(f<8)rpw2aM3(o,o,[214,180,124],(1-f/8)*.7)}
   else if(isl){rpw2aM3(o,rock,dark,rpw2aSS(.3,.7,n));}
   else{const b=rpw2aSS(-1.5,1.5,f-18-(n-.5)*26);rpw2aM3(c2,moss,moss2,rpw2aSS(.3,.75,n));rpw2aM3(o,cove,c2,b);if(f<6)rpw2aM3(o,o,[90,96,90],(1-f/6)*.7)}
   if(rpw2aIH(x,y)>.93)rpw2aM3(o,o,WH,.12);if(f<2.2){rpw2aM3(o,o,rim,rpw2aSS(2.2,1,f))}return}
  /* the sea: shallow turquoise by the islands, deep blue offshore, the trench dark with a glowing lip */
  const d=-f+(n-.5)*20;if(d<26)rpw2aM3(o,sea0,sea1,d/26);else if(d<90)rpw2aM3(o,sea1,sea2,(d-26)/64);else rpw2aM3(o,sea2,sea3,Math.min(1,(d-90)/160));
  const ca=Math.sin(x*.06+Math.sin(y*.05)*2.2)+Math.sin(y*.08+Math.sin(x*.04)*2.4);if(ca>1.55&&d<120)rpw2aM3(o,o,WH,.4*(ca-1.55));
  if(d<1.2)rpw2aM3(o,o,rim,.9);else if(d<5&&n>.3)rpw2aM3(o,o,WH,(1-rpw2aSS(3,5,d))*.95);else if(d>9&&d<11.5)rpw2aM3(o,o,WH,.35);
  if(m>-30){const k=rpw2aSS(-30,6,m);rpw2aM3(o,o,tr0,k);if(m>6)rpw2aM3(o,o,tr1,rpw2aSS(6,80,m));const e=Math.abs(m-4);if(e<5)rpw2aM3(o,o,CY,(1-e/5)*.75)}});
 g.drawImage(P.base,0,0);
 /* sea texture: wave crests and a few sandbars */
 g.strokeStyle='rgba(255,255,255,.45)';g.lineWidth=2;g.beginPath();for(let i=0;i<120;i++){const x=rpw2aR(i*3+7)*1600,y=rpw2aR(i*3+8)*900;if(L.at(x,y)>-30||T.at(x,y)>-20)continue;g.moveTo(x-8,y);g.quadraticCurveTo(x-4,y-4,x,y);g.quadraticCurveTo(x+4,y-4,x+8,y)}g.stroke();
 for(const [x,y,r] of[[90,330,30],[560,760,40],[1250,300,50],[1400,720,36],[860,150,26]]){rpw2aBlob(g,x,y,r+8,r*.4+5,'#9ef6ea',.8);rpw2aBlob(g,x,y,r,r*.4,'#f6dea4');g.strokeStyle='#1e5e6e';g.lineWidth=1.6;g.beginPath();g.ellipse(x,y,r,r*.4,0,0,TAU);g.stroke();rpw2aPalm(g,x+r*.2,y+2,26,x,{n:6})}
 /* the trench: whirling dark water, glowing coral on the lip */
 {g.save();g.beginPath();g.ellipse(946,560,176,94,0,0,TAU);g.clip();g.globalCompositeOperation='lighter';for(let k=0;k<4;k++){g.strokeStyle='rgba(80,200,255,.18)';g.lineWidth=3;g.beginPath();for(let j=0;j<=40;j++){const u=j/40,a=k*Math.PI/2+u*5,r=10+u*170;j?g.lineTo(946+Math.cos(a)*r,560+Math.sin(a)*r*.54):g.moveTo(946+Math.cos(a)*r,560+Math.sin(a)*r*.54)}g.stroke()}
  g.globalAlpha=.6;g.drawImage(rpw2aGl('80,230,190',60),886,520,120,80);g.restore();
  for(let k=0;k<26;k++){const a=k/26*TAU,x=946+Math.cos(a)*186,y=560+Math.sin(a)*102;if(k%2)rpw2aGlowCoral(g,x,y+4,12,k,k,null);else rpw2aCrag(g,x,y+6,16,10,k,['#2a3c6a','#4a6496','#16223e'])}
  /* tentacles rising out of the trench */
  for(const [bx,by,a0,Ln,w,cu,bd] of[[836,540,-2.3,110,14,-1,.3],[870,500,-1.9,80,11,1,.2],[1030,505,-1.2,84,11,-1,-.2],[1070,560,-.9,100,13,1,-.3],[900,610,-1.7,70,11,-1,.2]])rpw2aTentacle(g,bx,by,a0,Ln,w,cu,bd,bx,0);
  W.eye=[946,566]}
 /* islands' props, back to front */
 const items=[],nd=RPW2A_NODES,keep=(x,y)=>{for(const k in nd){const n=nd[k];if(x>n.x-150*RPW2A_WS-16&&x<n.x+150*RPW2A_WS+16&&y>n.y-500*RPW2A_WS&&y<n.y+70)return false}return true};
 for(let i=0;i<2600&&items.length<330;i++){const x=rpw2aR(i*5+11)*1600,y=rpw2aR(i*5+12)*900,f=L.at(x,y);if(f<10||!keep(x,y))continue;const reef=x<560&&y>380,isl=x>960&&y>560;
  if(reef){if(f<30)continue;items.push({k:rpw2aR(i)<.75?'palm':'bush',x,y,i})}else if(isl){items.push({k:'crag',x,y,i})}else{if(f<22)continue;items.push({k:rpw2aR(i)<.8?'pine':'crag',x,y,i})}}
 items.push({k:'light',x:150,y:500},{k:'ship',x:808,y:446},{k:'hut',x:420,y:556});for(const k in nd)items.push({k:'castle',id:k,x:nd[k].x,y:nd[k].y});
 items.sort((a,b)=>a.y-b.y);W.cast=[];
 for(const it of items){const {x,y,i}=it;switch(it.k){
  case'palm':rpw2aPalm(g,x,y,30+rpw2aR(i)*12,i,{n:6});break;case'bush':rpw2aBush(g,x,y,12,i);break;case'crag':rpw2aCrag(g,x,y,18+rpw2aR(i)*10,14+rpw2aR(i)*10,i,['#56606a','#8a96a2','#2e363e']);break;
  case'pine':rpTree(g,x,y,26+rpw2aR(i)*12,RPW2A_WPAL,i,'moss');break;
  case'light':{const L2=rpw2aLighthouse(g,x,y,92);W.light=L2;break}
  case'hut':rpw2aSandcastle(g,x,y,22);break;
  case'ship':{g.save();g.translate(x,y);g.scale(.32,.32);rpw2aShip(g,0,0,330,170,{lant:[]});g.drawImage(rpw2aMastSpr(0),-70-50,-196-26);g.restore();W.ship=[x,y];break}
  case'castle':{const A=rpw2aCastle(it.id),s=RPW2A_WS,x0=x-155*s,y0=y-512*s;g.fillStyle='rgba(0,0,0,.3)';g.beginPath();g.ellipse(x+8,y-4,150*s,22*s,0,0,TAU);g.fill();
   if(it.id==='abyss'){g.save();g.globalCompositeOperation='lighter';g.globalAlpha=.6;g.drawImage(rpw2aGl('80,200,255',90),x-110,y-220,220,240);g.restore()}
   g.imageSmoothingQuality='high';g.drawImage(A.c2,x0,y0,A.w*s,A.h*s);it.x0=x0;it.y0=y0;W.cast.push(it);break}}}
 /* the sea routes: World 1 -> the reef -> the cove -> the trench */
 const gate=k=>[nd[k].x+(RPW2A_GX-155)*RPW2A_WS,nd[k].y+(RPW2A_GY+36-512)*RPW2A_WS];const gc=gate('coral'),gw=gate('wreck'),ga=gate('abyss');
 const R1=rpwSpl([[-20,470],[60,500],[120,560],[180,600],[gc[0]-30,gc[1]+4],gc],6),R2=rpwSpl([[gc[0]+40,gc[1]-30],[330,470],[390,420],[470,390],[540,370],[gw[0]-34,gw[1]+6],gw],6),
  R3=rpwSpl([[gw[0]+60,gw[1]+6],[760,330],[840,350],[900,440],[1000,470],[1110,520],[1120,570],[ga[0]+30,ga[1]],ga],6);
 W.routes=[R1,R2,R3];g.save();g.setLineDash([13,9]);for(const T of W.routes){const seg=[];let cur=[];for(const p of T){if(L.at(p[0],p[1])>2){if(cur.length>1)seg.push(cur);cur=[]}else cur.push(p)}if(cur.length>1)seg.push(cur);
  for(const S of seg){g.beginPath();S.forEach((p,j)=>j?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.lineDashOffset=0;g.strokeStyle='rgba(10,50,70,.55)';g.lineWidth=7;g.stroke();g.strokeStyle='#ffffff';g.lineWidth=3.6;g.stroke()}}g.restore();
 /* reef coral in the shallows round the reef island, rocks with foam out at sea, a whale */
 g.save();g.globalAlpha=.7;let np=0;for(let i=0;i<400&&np<16;i++){const x=rpw2aR(i*3+900)*640,y=330+rpw2aR(i*3+901)*480,f=L.at(x,y);if(f>-14||f<-40||T.at(x,y)>-30)continue;np++;
  const C=[];for(let j=0;j<9;j++){const a=rpw2aR(i*11+j)*TAU,d=rpw2aR(i*13+j)*20;const px=x+Math.cos(a)*d,py=y+Math.sin(a)*d*.6;if(L.at(px,py)>-8)continue;C.push([px,py,j])}C.sort((a,b)=>a[1]-b[1]);
  rpw2aBlob(g,x,y,26,12,'#ffffff',.18);g.globalAlpha=.7;for(const [px,py,j] of C)rpw2aCoral(g,px,py,9+rpw2aR(i+j)*6,(i+j)%4,RPW2A_CORAL[(i*2+j)%6],i*9+j)}g.restore();
 for(const [x,y,s] of[[150,250,16],[1080,300,14],[520,440,12],[1240,640,18],[770,620,12],[60,700,14]]){if(L.at(x,y)>-10)continue;g.strokeStyle='rgba(255,255,255,.7)';g.lineWidth=2;g.beginPath();g.ellipse(x,y+2,s*1.3,s*.45,0,0,TAU);g.stroke();rpw2aCrag(g,x,y+4,s*1.6,s*1.2,x|0,['#6a7480','#9aa6b2','#3e4650'])}
 {const x=868,y=716;g.fillStyle='#2a4a6a';g.beginPath();g.moveTo(x-4,y);g.quadraticCurveTo(x-6,y-14,x-22,y-24);g.quadraticCurveTo(x-8,y-22,x,y-14);g.quadraticCurveTo(x+8,y-22,x+22,y-24);g.quadraticCurveTo(x+6,y-14,x+4,y);g.closePath();g.fill();rpw2aOut(g,2);
  g.strokeStyle='rgba(255,255,255,.8)';g.lineWidth=2;g.beginPath();g.ellipse(x,y+1,16,4,0,0,TAU);g.stroke();W.whale=[x,y]}
 /* a compass rose and soft clouds with their shadows */
 {const x=1120,y=170,r=34;g.save();g.translate(x,y);g.fillStyle='rgba(0,40,60,.25)';g.beginPath();g.arc(3,4,r+6,0,TAU);g.fill();g.fillStyle='#f6eed8';g.beginPath();g.arc(0,0,r+4,0,TAU);g.fill();rpw2aOut(g,2.4);g.strokeStyle='#c8963a';g.lineWidth=1.6;g.beginPath();g.arc(0,0,r-2,0,TAU);g.stroke();
  for(let k=0;k<8;k++){const a=k*Math.PI/4-Math.PI/2,l=k%2?r*.55:r*.95;g.fillStyle=k%2?'#c8963a':(k===0?'#e8343a':'#2a4a6a');g.beginPath();g.moveTo(Math.cos(a)*l,Math.sin(a)*l);g.lineTo(Math.cos(a+.3)*7,Math.sin(a+.3)*7);g.lineTo(0,0);g.lineTo(Math.cos(a-.3)*7,Math.sin(a-.3)*7);g.closePath();g.fill();rpw2aOut(g,1.2)}
  g.fillStyle='#ffd45a';g.beginPath();g.arc(0,0,4,0,TAU);g.fill();rpw2aOut(g,1.4);g.fillStyle=RPO;g.font='bold 13px Georgia,serif';g.textAlign='center';g.fillText('N',0,-r-8);g.restore()}
 for(const [x,y,s] of[[520,110,18],[1340,210,22],[860,820,16],[180,190,14]]){g.fillStyle='rgba(0,40,70,.18)';g.beginPath();g.ellipse(x+40,y+70,s*3.2,s*1.1,0,0,TAU);g.fill();rpwCloud(g,x,y,s,'#ffffff','#cfe2ee',.92)}
 /* the misty cove: a veil of mist on the cove island */
 for(let k=0;k<7;k++){const x=560+rpw2aR(k+70)*260,y=230+rpw2aR(k+71)*150,r=60+rpw2aR(k)*50;g.globalAlpha=.22;g.drawImage(rpw2aGl('235,242,248',r),x-r,y-r*.6,r*2,r*1.2)}g.globalAlpha=1;
 /* sunlight from the top left and a soft vignette */
 let q=g.createRadialGradient(200,80,40,200,80,700);q.addColorStop(0,'rgba(255,250,210,.22)');q.addColorStop(1,'rgba(255,250,210,0)');g.fillStyle=q;g.fillRect(0,0,1600,900);
 q=g.createRadialGradient(170,130,40,170,130,520);q.addColorStop(0,'rgba(6,20,40,.5)');q.addColorStop(1,'rgba(6,20,40,0)');g.fillStyle=q;g.fillRect(0,0,800,700);
 q=g.createLinearGradient(0,660,0,900);q.addColorStop(0,'rgba(6,20,40,0)');q.addColorStop(1,'rgba(6,20,40,.45)');g.fillStyle=q;g.fillRect(0,660,1600,240);
 W.sea=[];for(let i=0;i<500&&W.sea.length<50;i++){const x=rpw2aR(i*7+300)*1600,y=rpw2aR(i*7+301)*900;if(L.at(x,y)<-30&&T.at(x,y)<-20)W.sea.push([x,y])}
 W.shore=rpw2aShore(L,14);for(const p of W.shore){p.nx=-p.nx;p.ny=-p.ny}
 W.anim=(g,t)=>rpw2aWorldLive(g,W,t);return RPW2A.world=W}
function rpw2aWorldLive(g,W,t){g.save();
 rpw2aWaves(g,W.shore,t,1,'#ffffff',10);g.globalAlpha=.9;rpw2aTwinkle(g,W.sea,t,3.6,'#ffffff',.4);g.globalAlpha=1;
 /* the trench glows and its eye opens now and then */
 g.globalCompositeOperation='lighter';g.globalAlpha=.25+.15*Math.sin(t*1.2);g.drawImage(rpw2aGl('80,230,200',70),W.eye[0]-90,W.eye[1]-50,180,100);g.globalCompositeOperation='source-over';
 {const o=Math.max(0,Math.sin(t*.5));if(o>.05){g.globalAlpha=1;g.save();g.translate(W.eye[0],W.eye[1]);g.scale(.5,.5*o);g.beginPath();g.moveTo(-34,0);g.quadraticCurveTo(0,-30,34,0);g.quadraticCurveTo(0,30,-34,0);g.closePath();g.fillStyle='#d8f04a';g.fill();g.lineWidth=4;g.strokeStyle=RPO;g.stroke();g.fillStyle='#0a0614';g.beginPath();g.ellipse(Math.sin(t*.7)*8,0,5,13,0,0,TAU);g.fill();g.restore()}}
 /* a little ship sailing the routes */
 {const T=W.routes[1],u=(t*.025)%1,n=T.length-1,i=Math.min(n-1,(u*n)|0),p=T[i],q=T[i+1];g.save();g.translate(p[0],p[1]-6+Math.sin(t*2)*1.5);g.scale(q[0]<p[0]?-.9:.9,.9);
  g.fillStyle='#8a5a32';g.beginPath();g.moveTo(-14,0);g.quadraticCurveTo(0,10,14,0);g.lineTo(18,-4);g.lineTo(-16,-4);g.closePath();g.fill();rpw2aOut(g,1.6);g.strokeStyle=RPO;g.lineWidth=1.6;g.beginPath();g.moveTo(0,-4);g.lineTo(0,-26);g.stroke();
  g.fillStyle='#fff8e8';g.beginPath();g.moveTo(1,-24);g.quadraticCurveTo(12,-16,1,-7);g.closePath();g.fill();rpw2aOut(g,1.4);g.fillStyle='#e8343a';g.fillRect(0,-30,7,4);g.restore();
  g.strokeStyle='rgba(255,255,255,.6)';g.lineWidth=1.4;g.beginPath();g.moveTo(p[0]-10,p[1]+2);g.quadraticCurveTo(p[0]-22,p[1]+5,p[0]-30,p[1]+2);g.stroke()}
 /* mist drifting over the cove */
 const ms=rpw2aFogSpr(0);for(let k=0;k<2;k++){g.globalAlpha=.24;g.drawImage(ms,520+((t*6+k*150)%300)-60,240+k*80+Math.sin(t*.3+k)*8,200,110)}g.globalAlpha=1;
 /* gulls and the lighthouse lamp */
 for(let i=0;i<3;i++){const a=t*(.18+i*.04)+i*2.1,x=330+Math.cos(a)*(140-i*20),y=540+Math.sin(a)*(70-i*10);rpw2aGull(g,x,y,.55,a+Math.PI,t*7+i,0)}
 if(W.light){g.globalCompositeOperation='lighter';g.globalAlpha=.5+.25*Math.sin(t*3);g.drawImage(rpw2aGl('255,240,170',20),W.light.x-20,W.light.y-20);g.globalCompositeOperation='source-over';g.globalAlpha=1}
 for(const it of W.cast){const s=RPW2A_WS;g.save();g.translate(it.x0,it.y0);g.scale(s,s);rpw2aCastleLive(g,rpw2aCastle(it.id),0,0,t,1);g.restore()}
 g.restore()}
/* ---------- the small map pictures (next-region cards): the castle on a themed tile ---------- */
function rpw2aIcon(id,w,h){w=Math.round(w||88);h=Math.round(h||88);const k='ic'+id+w+'x'+h;if(RPW2A.s[k])return RPW2A.s[k];const c=rpw2aCv(w,h),g=c.getContext('2d'),A=rpw2aCastle(id),r=Math.min(w,h)*.16;g.lineJoin='round';g.lineCap='round';
 g.beginPath();g.roundRect(0,0,w,h,r);g.save();g.clip();const Bc={coral:['#7ad0f0','#3ed6d6','#f6dea4'],wreck:['#5a6e7a','#2a5a66','#4c5c52'],abyss:['#0a1838','#14306a','#0c1c3e']}[id];
 let q=g.createLinearGradient(0,0,0,h);q.addColorStop(0,Bc[0]);q.addColorStop(.55,Bc[1]);q.addColorStop(.7,Bc[2]);q.addColorStop(1,Bc[2]);g.fillStyle=q;g.fillRect(0,0,w,h);
 if(id==='coral'){g.strokeStyle='rgba(255,255,255,.7)';g.lineWidth=Math.max(1.2,h*.02);g.beginPath();for(let x=0;x<=w;x+=4){const y=h*.66+Math.sin(x/w*12)*h*.012;x?g.lineTo(x,y):g.moveTo(x,y)}g.stroke()}
 if(id==='wreck'){g.globalAlpha=.4;g.drawImage(rpw2aFogSpr(0),-w*.2,h*.1,w*1.4,h*.6);g.globalAlpha=1}
 if(id==='abyss'){g.globalCompositeOperation='lighter';g.globalAlpha=.7;g.drawImage(rpw2aGl('60,200,255',60),-w*.1,h*.15,w*1.2,h*.9);g.globalAlpha=1;g.globalCompositeOperation='source-over';g.fillStyle='#8affff';for(let i=0;i<12;i++)g.fillRect(rpw2aR(i)*w,rpw2aR(i+5)*h*.6,1.5,1.5)}
 const s=Math.min(h*.98/500,w*1.2/300),x0=w/2-160*s,y0=h-512*s-h*.02;g.imageSmoothingQuality='high';g.drawImage(s<.35?A.c:A.c2,x0,y0,A.w*s,A.h*s);
 if(id==='coral'){rpw2aPalm(g,w*.1,h*1.02,h*.34,1,{n:6});rpw2aPalm(g,w*.92,h*1.04,h*.3,4,{n:6})}else if(id==='wreck'){rpTree(g,w*.08,h*1.02,h*.3,RPW2A_WPAL,1,'moss');rpTree(g,w*.92,h*1.03,h*.34,RPW2A_WPAL,2,'moss')}
 else{rpw2aGlowCoral(g,w*.1,h,h*.22,0,0,null);rpw2aAnemone(g,w*.9,h,h*.2,1,null)}
 q=g.createLinearGradient(0,0,0,h);q.addColorStop(0,'rgba(255,255,255,.12)');q.addColorStop(.4,'rgba(255,255,255,0)');g.fillStyle=q;g.fillRect(0,0,w,h);g.restore();
 g.beginPath();g.roundRect(1,1,w-2,h-2,r);g.strokeStyle='rgba(18,8,31,.85)';g.lineWidth=2;g.stroke();return RPW2A.s[k]=c}
/* ---------- registration ---------- */
RPW.bake.coral=rpw2aCoralBake;RPW.amb.coral=rpw2aCoralAmb;RPW.twist.coral=rpw2aCoralTwist;RPW.ambTop.coral=rpw2aCoralTop;
RPW.bake.wreck=rpw2aWreckBake;RPW.amb.wreck=rpw2aWreckAmb;RPW.ambTop.wreck=rpw2aWreckTop;
RPW.bake.abyss=rpw2aAbyssBake;RPW.amb.abyss=rpw2aAbyssAmb;RPW.twist.abyss=rpw2aAbyssTwist;
for(const id of['coral','wreck','abyss'])RPW.castleHit[id]=(c,x,y,k)=>rpw2aCastleHit(c,rpw2aCastle(id),x,y,k);
RPW.world[2]=()=>{const W=rpw2aWorld();return{c:W.c,nodes:W.nodes,anim:W.anim}};
for(const id of['coral','wreck','abyss'])RPW.icon[id]=(w,h)=>rpw2aIcon(id,w,h);
