/* ---------- Bounty Board: three rotating contracts, bounty tokens and the Token Exchange ---------- */
HIC.bounty='<path d="M6 3h12v18l-6-3-6 3z"/><path d="M9 8h6M9 11.5h6M9 15h3"/>';
const BTY_TIER=[{n:'Easy',c:'#7dd8a0',g:160,t:1},{n:'Medium',c:'#ffc94a',g:340,t:2},{n:'Hard',c:'#ff7a6a',g:680,t:3}];
const btyDay=()=>{const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
const btyR5=v=>Math.max(5,Math.round(v/5)*5);
/* contract templates: k = kind, run = must happen inside one run */
const BTPL=[
 {k:'kill',tier:0,mk:r=>({n:[60,80,100][r()*3|0]}),txt:c=>`Slay ${c.n} monsters`},
 {k:'fly',tier:0,mk:r=>({n:[20,25,30][r()*3|0]}),txt:c=>`Shoot down ${c.n} flying monsters`},
 {k:'flaw',tier:0,mk:r=>({n:[40,50,60][r()*3|0]}),txt:c=>`Type ${c.n} words without a slip`},
 {k:'crate',tier:0,mk:r=>({n:3}),txt:c=>`Pick up ${c.n} crates in battle`},
 {k:'clear',tier:0,mk:r=>({n:2}),txt:c=>`Clear ${c.n} campaign levels`},
 {k:'flyf',tier:1,mk:r=>({n:[25,30,35][r()*3|0]}),txt:c=>`Slay ${c.n} flying monsters without a slip`},
 {k:'boss',tier:1,mk:r=>({n:[2,3][r()*2|0]}),txt:c=>`Defeat ${c.n} bosses`},
 {k:'elite',tier:1,mk:r=>({n:[8,10,12][r()*3|0]}),txt:c=>`Slay ${c.n} elite monsters`},
 {k:'armor',tier:1,mk:r=>({n:[8,10][r()*2|0]}),txt:c=>`Break ${c.n} armored monsters`},
 {k:'streak',tier:1,run:1,mk:r=>({n:Math.min(70,Math.max(30,btyR5((P.bestCombo||30)*(.6+r()*.2))))}),txt:c=>`Reach a ${c.n} streak in one run`},
 {k:'wave',tier:1,run:1,mk:r=>({n:[10,12,15][r()*3|0]}),txt:c=>`Reach wave ${c.n} in Endless`},
 {k:'daily',tier:1,ok:()=>!dcDone(),mk:r=>({n:1}),txt:c=>`Finish today's Daily Challenge`},
 {k:'bossfast',tier:2,mk:r=>({n:1}),txt:c=>`Defeat a boss at 1.5× speed or faster`},
 {k:'nohit',tier:2,mk:r=>({n:1}),txt:c=>`Clear a campaign level without taking a hit`},
 {k:'wpm',tier:2,run:1,mk:r=>({n:Math.min(45,Math.max(25,btyR5((P.bestWpm||33)*.8))),a:94}),txt:c=>`Finish a run at ${c.n}+ WPM with ${c.a}% accuracy`},
 {k:'chainw',tier:2,run:1,mk:r=>({n:[35,45,55][r()*3|0]}),txt:c=>`Type ${c.n} words in a row without a slip`},
 {k:'rift',tier:2,ok:()=>riftOpen(),mk:r=>({n:[60,80][r()*2|0]}),txt:c=>`Slay ${c.n} monsters in Starfall Rift`},
 {k:'bossflaw',tier:2,mk:r=>({n:2}),txt:c=>`Defeat ${c.n} bosses at 1.25× speed or faster`}];
const BTK={};for(const t of BTPL)BTK[t.k]=t;
const btyGold=tier=>Math.round(BTY_TIER[tier].g*(1+lvl(P.xp)/40+.1*(P.pres||0))/10)*10;
function btyMake(tier,day,slot,rr,avoid){const r=dcRng(dcHash('bty'+day+':'+slot+':'+rr)),pool=BTPL.filter(t=>t.tier===tier&&(!t.ok||t.ok())&&!avoid.includes(t.k));
 const t=pool[r()*pool.length|0]||BTPL.find(x=>x.tier===tier),c=Object.assign({k:t.k,tier,p:0,ok:0,cl:0,g:btyGold(tier),t:BTY_TIER[tier].t},t.mk(r));return c}
/* state lives in the save: P.bty */
function BTY(){const today=btyDay();let B=P.bty;
 if(!B||typeof B!=='object'||Array.isArray(B))B=P.bty={d:'',c:[],tok:0,all:0,rr:0,own:{},title:'',trail:'',done:0,note:''};
 for(const c of(Array.isArray(B.c)?B.c:[]))if(c&&c.k==='wpm'){if(c.n>45)c.n=45;if(c.ok)c.p=c.n;}B.own=B.own&&typeof B.own==='object'?B.own:{};B.c=Array.isArray(B.c)?B.c:[];B.tok=Math.max(0,B.tok|0);
 if(B.d!==today){let auto=0,ag=0;for(const c of B.c)if(c&&c.ok&&!c.cl){B.tok+=c.t;B.all=(B.all||0)+c.t;P.gold+=c.g;ag+=c.g;auto+=c.t;B.done=(B.done||0)+1}
  B.note=auto?`Yesterday's finished bounties were paid out: ${ag.toLocaleString()} gold and ${auto} token${auto>1?'s':''}.`:'';
  B.d=today;B.rr=0;B.c=[];const used=[];for(let i=0;i<3;i++){const c=btyMake(i,today,i,0,used);used.push(c.k);B.c.push(c)}save()}
 return B}
const btyReady=()=>{try{return BTY().c.filter(c=>c.ok&&!c.cl).length}catch(e){return 0}};
const btyTxt=c=>(BTK[c.k]||{txt:()=>'Bounty'}).txt(c);
/* progress */
function btyAdd(k,v,run){if(S&&S.bg)return;const B=BTY();for(const c of B.c){if(c.k!==k||c.ok)continue;c.p=run?Math.max(c.p,v):c.p+v;if(c.p>=c.n){c.p=c.n;c.ok=1;btyDone(c)}}}
function btyDone(c){save();try{if(S.mode==='play')float(W/2,250,'Bounty complete!','#ffc94a',46);[[784,0],[988,90],[1176,180],[1568,300]].forEach(([f,d])=>setTimeout(()=>beep(f,.15,'triangle',.7),d))}catch(e){}}
const btyLive=()=>S&&!S.prac&&(S.mode==='play'||S.mode==='over');
function btyKill(e,force){if(S&&S.bg)return;if(!btyLive()||e.mn)return;const M=MON[e.id]||{};
 if(e.boss){if(e.phs>1)return;btyAdd('boss',1);if((S.gs||1)>=1.5)btyAdd('bossfast',1);if((S.gs||1)>=1.25)btyAdd('bossflaw',1);return}
 btyAdd('kill',1);if(M.fly)btyAdd('fly',1);if(e.el)btyAdd('elite',1);if(M.tr==='shield')btyAdd('armor',1);if(S.rift)btyAdd('rift',1);
 if(!force&&!e.bad){btyAdd('flaw',1);if(M.fly)btyAdd('flyf',1);btyAdd('chainw',S.cw||0,1)}}
function btyRunEnd(){if(S.prac)return;btyAdd('streak',S.maxCombo||0,1);if(!S.camp&&!S.rift&&!S.dc)btyAdd('wave',S.wave||0,1);
 /* Match the rounded metrics on the results screen and refresh the final WPM after the last letter. */
 if(S.tt>=4&&S.ok>=8)S.wpm=Math.round(S.ok*12/S.tt);
 const acc=S.chars?Math.round(S.ok/S.chars*100):0;for(const c of BTY().c)if(c.k==='wpm'&&!c.ok&&wpmValid()&&S.wpm>=c.n&&acc>=c.a){c.p=c.n;c.ok=1;S.btyWpmCompleted=btyTxt(c);btyDone(c)}}
function btyResultNotice(text){return text?`<p class="bnote" role="status"><b>Bounty completed!</b> ${esc(text)}. Claim your reward on the Bounty Board.</p>`:''}
function btyClear(){if(S.prac)return;btyAdd('clear',1);if(S.dmgTaken===0)btyAdd('nohit',1)}
/* claiming and rerolling */
function btyClaim(i){const B=BTY(),c=B.c[i];if(!c||!c.ok||c.cl)return false;c.cl=1;B.tok+=c.t;B.all=(B.all||0)+c.t;P.gold+=c.g;B.done=(B.done||0)+1;save();
 try{stat('bty',1,'add');achCheck()}catch(e){}return true}
function btyReroll(i){const B=BTY(),c=B.c[i];if(!c||c.ok||B.rr>=1)return false;B.rr++;const avoid=B.c.map(x=>x.k);B.c[i]=btyMake(c.tier,B.d,i,B.rr,avoid);save();return true}

/* ----- cosmetics ----- */
const BT_TITLES=[['wanted','Wanted',3],['wordslinger','Wordslinger',4],['keysmith','Keysmith',4],['duskstalker','Duskstalker',5],['inkblade','Inkblade',6],['runebreaker','Rune Breaker',6],['dragonbane','Dragonbane',8],['unbroken','The Unbroken',8],['nightquill','Nightquill',10],['legend','Legend of the Board',14]];
const BT_TRAILS=[['ember','Ember',6,'#ffe08a','#ff7a3a'],['frost','Frost',6,'#f0fbff','#6ad0ff'],['ink','Ink',8,'#d8c8ff','#5a3aa8'],['arcane','Arcane',10,'#ffd0f4','#d04aff'],['star','Starlight',10,'#ffffff','#9ad8ff'],['gold','Gold Coins',12,'#fff3a0','#ffb01e']];
const btyTitle=()=>{if(P.ttl&&MON[P.ttl]&&mbTierOf(P.ttl)>=2)return mbTitleOf(P.ttl);const B=P.bty;if(!B||!B.title)return'';const t=BT_TITLES.find(x=>x[0]===B.title);return t?t[1]:''};
const btyTitleHTML=()=>{const t=btyTitle();return t?`<small class="htl">${esc(t)}</small>`:''};
function btyBuy(kind,id){const B=BTY(),L=kind==='t'?BT_TITLES:BT_TRAILS,it=L.find(x=>x[0]===id),key=kind+':'+id;if(!it||B.own[key]||B.tok<it[2])return false;B.tok-=it[2];B.own[key]=1;if(kind==='t'){B.title=id;P.ttl=''}else B.trail=id;save();return true}
function btyEquip(kind,id){const B=BTY();if(id&&!B.own[kind+':'+id])return false;if(kind==='t'){B.title=id||'';if(id)P.ttl=''}else B.trail=id||'';save();return true}

/* ----- letter trails: each correct letter flies from the hero to the monster ----- */
let BTL=[];
function btyTrail(t,ch){const B=P.bty;if(!B||!B.trail)return;if(BTL.length>40)BTL.shift();
 BTL.push({x0:KX+70,y0:GY-120,x1:t.x,y1:t.y-t.h*.55,t0:performance.now(),ch:ch.toUpperCase(),k:B.trail,s:Math.random()*6})}
function btyTrailArt(g,k,x,y,u,ch,s,big){const T=BT_TRAILS.find(q=>q[0]===k)||BT_TRAILS[0],c0=T[3],c1=T[4];
 glow(g,x,y,big?26:24,c1+'dd');
 if(k==='gold'){coin(g,x,y,big?9:7)}
 else if(k==='frost'){poly(g,[x,y-9,x+5,y,x,y+9,x-5,y],c0,c1,1.4)}
 else{g.font=`800 ${big?22:22}px ui-monospace,Menlo,Consolas,monospace`;g.textAlign='center';g.textBaseline='middle';g.fillStyle=c0;g.fillText(ch,x,y+1)}
 if(k==='star')for(let i=0;i<3;i++)sparkle(g,x+Math.sin(s+i*2.1+u*9)*12,y+Math.cos(s+i*2.1+u*9)*10,4,.9,['#fff','#ffd0f4','#9ad8ff'][i]);
 if(k==='ember')for(let i=0;i<3;i++)ell(g,x-8-i*7,y+Math.sin(s+i)*4,2.4-i*.6,2.4-i*.6,'#ffb02e');
 if(k==='ink')for(let i=0;i<2;i++)ell(g,x-6-i*8,y+4+i*4,2.6-i,3.4-i,'#3a2080')}
function btyDrawTrails(g){if(!BTL.length)return;const now=performance.now(),D=320;g.save();
 BTL=BTL.filter(p=>now-p.t0<D);
 for(const p of BTL){const u=Math.min(1,(now-p.t0)/D),e=1-(1-u)*(1-u),x=p.x0+(p.x1-p.x0)*e,y=p.y0+(p.y1-p.y0)*e-Math.sin(u*Math.PI)*40;
  const T=BT_TRAILS.find(q=>q[0]===p.k)||BT_TRAILS[0];
  g.strokeStyle=T[4]+'77';g.lineWidth=7;g.lineCap='round';g.beginPath();const u0=Math.max(0,u-.25),e0=1-(1-u0)*(1-u0);g.moveTo(p.x0+(p.x1-p.x0)*e0,p.y0+(p.y1-p.y0)*e0-Math.sin(u0*Math.PI)*40);g.lineTo(x,y);g.stroke();
  btyTrailArt(g,p.k,x,y,u,p.ch,p.s)}
 g.restore()}
function btyTrailPreview(cv,k){const g=cv.getContext('2d');return t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,cv.width,cv.height);const w=cv.width,h=cv.height,T=BT_TRAILS.find(q=>q[0]===k);
 g.strokeStyle=T[4]+'55';g.lineWidth=4;g.lineCap='round';g.beginPath();for(let i=0;i<=20;i++){const u=i/20,x=16+u*(w-32),y=h*.7-Math.sin(u*Math.PI)*h*.4;i?g.lineTo(x,y):g.moveTo(x,y)}g.stroke();
 const L='SLAY';for(let i=0;i<4;i++){const u=((t*.45)+i*.25)%1,x=16+u*(w-32),y=h*.7-Math.sin(u*Math.PI)*h*.4;g.globalAlpha=Math.sin(u*Math.PI);btyTrailArt(g,k,x,y,u,L[i],i*1.7,1);g.globalAlpha=1}}}

/* ----- the screen ----- */
const btyLeft=()=>{const n=new Date(),e=new Date(n.getFullYear(),n.getMonth(),n.getDate()+1),s=Math.max(0,(e-n)/1000|0);return Math.floor(s/3600)+'h '+String(Math.floor(s%3600/60)).padStart(2,'0')+'m'};
function bountyBoard(tab){S.mode='title';S.view='menu';const B=BTY();tab='t';const keep=ov.scrollTop;
 const card=(c,i)=>{const T=BTY_TIER[c.tier],pc=c.ok?100:Math.round(c.p/c.n*100),st=c.cl?'cl':c.ok?'ok':'';
  return `<article class="bcn ${st}" style="--tc:${T.c};--rot:${[-1.6,.8,-.6][i]}deg"><i class="pin"></i><div class="bst">${T.n}</div><h3>${esc(btyTxt(c))}</h3>
  ${BTK[c.k]&&BTK[c.k].run?'<p class="bnt">Must happen within a single run.</p>':'<p class="bnt">Progress carries over between runs.</p>'}
  <div class="bpg"><span class="bbar"><i style="width:${pc}%"></i></span><b>${c.ok?'Completed':c.k==='wpm'?'Not yet':c.n>1?`${c.p} / ${c.n}`:'Not yet'}</b></div>
  <div class="brw"><span><span class="coin"></span>${c.g.toLocaleString()}</span><span>${btyTok(18)} ${c.t}</span></div>
  <div class="bac">${c.cl?'<span class="bcl">Claimed</span>':c.ok?`<button class="bclm" data-cl="${i}">Claim reward</button>`:`<button class="sm brr" data-rr="${i}" ${B.rr>=1?'disabled':''}>${B.rr>=1?'Reroll used':'Reroll'}</button>`}</div>
  ${c.cl?'<div class="bstamp">Paid</div>':''}</article>`};
 const item=(kind,it)=>{const key=kind+':'+it[0],own=!!B.own[key],eq=(kind==='t'?B.title:B.trail)===it[0];
  return `<div class="bit${eq?' eq':''}">${kind==='t'?`<div class="bti">${esc(it[1])}</div>`:`<canvas id="btp_${it[0]}" width="220" height="80"></canvas><b>${esc(it[1])}</b>`}
  <div class="bia">${eq?'<span class="beq">Equipped</span>':own?`<button class="sm" data-eq="${kind}:${it[0]}">Equip</button>`:`<button class="sm hgd" data-buy="${kind}:${it[0]}" ${B.tok<it[2]?'disabled':''}>${btyTok(16)} ${it[2]}</button>`}</div></div>`};
 const L=tab==='t'?BT_TITLES:BT_TRAILS,cur=tab==='t'?B.title:B.trail;
 show(`<h2>Bounty Board</h2><div class="bbx">
<div class="bhd"><span class="ch">${btyTok(24)}<b>${B.tok}</b> bounty tokens</span><span class="ch"><span class="coin"></span><b>${P.gold.toLocaleString()}</b> gold</span><span class="ch dim">New contracts in ${btyLeft()}</span><span class="ch dim">${B.done||0} bounties completed</span></div>
${B.note?`<p class="bnote">${esc(B.note)}</p>`:''}
<div class="bbd">${B.c.map(card).join('')}</div>
<p class="bhelp">Three contracts are posted every day: one Easy, one Medium and one Hard. Practice Range does not count. You get one free reroll a day for a contract you have not finished. Finished contracts that you forget to claim are paid out automatically the next day.</p>
<section class="bex"><div class="bexh"><h3>Token Exchange: Titles</h3></div>
<p class="bhelp">A title appears under your hero name on the home screen.</p>
<div class="bgrid">${L.map(it=>item(tab,it)).join('')}<div class="bit${!cur?' eq':''}"><div class="bti dim">${tab==='t'?'No title':'No trail'}</div><div class="bia">${!cur?'<span class="beq">Equipped</span>':`<button class="sm" data-eq="${tab}:">Equip</button>`}</div></div></div></section>
</div>`,'m top');
 ov.scrollTop=keep;S.back=title;
 ov.querySelectorAll('[data-cl]').forEach(b=>b.onclick=()=>{if(btyClaim(+b.dataset.cl)){try{[[660,0],[880,80],[1320,170],[1760,260]].forEach(([f,d])=>setTimeout(()=>beep(f,.15,'triangle',.8),d))}catch(e){}bountyBoard()}});
 ov.querySelectorAll('[data-rr]').forEach(b=>b.onclick=()=>{if(btyReroll(+b.dataset.rr)){beep(520,.06,'triangle',.5);bountyBoard()}});
 ov.querySelectorAll('[data-bt]').forEach(b=>b.onclick=()=>bountyBoard(b.dataset.bt));
 ov.querySelectorAll('[data-buy]').forEach(b=>b.onclick=()=>{const [k,id]=b.dataset.buy.split(':');if(btyBuy(k,id)){try{[[880,0],[1108,90],[1318,180]].forEach(([f,d])=>setTimeout(()=>beep(f,.15,'triangle',.7),d))}catch(e){}bountyBoard()}else beep(140,.12,'sawtooth',.5)});
 ov.querySelectorAll('[data-eq]').forEach(b=>b.onclick=()=>{const [k,id]=b.dataset.eq.split(':');if(btyEquip(k,id))bountyBoard()});
 if(tab==='r')for(const it of BT_TRAILS)live('btp_'+it[0],cv=>btyTrailPreview(cv,it[0]))}
const btyTok=s=>`<svg class="btok" viewBox="0 0 24 24" width="${s}" height="${s}" aria-hidden="true"><path d="M12 1.8l2.6 2.2 3.4-.4.9 3.3 3 1.7-1.2 3.2 1.2 3.2-3 1.7-.9 3.3-3.4-.4L12 22.2 9.4 20l-3.4.4-.9-3.3-3-1.7L3.3 12 2.1 8.6l3-1.7.9-3.3 3.4.4z" fill="#c8402e" stroke="#5a1408" stroke-width="1.2"/><circle cx="12" cy="12" r="6" fill="#e8584a" stroke="#7a1a0e" stroke-width="1"/><path d="M12 8.2l1.1 2.3 2.5.3-1.8 1.7.5 2.5-2.3-1.2-2.3 1.2.5-2.5-1.8-1.7 2.5-.3z" fill="#ffd76a"/></svg>`;
