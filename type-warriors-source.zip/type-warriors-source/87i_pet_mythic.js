/* ===== MYTHIC COMPANIONS: data =====
   A third rarity above Legendary. The Starforge egg is bought with coins only (50,000) and hatches one of the two Mythic companions,
   never a repeat: Glacierhorn (a crystal-horned mini yeti) and Solmane (a sun-maned lion cub).
   Everything here extends the existing tables in place (they are const objects/arrays), so every menu that loops PIDS/PRAR picks them up. */
Object.assign(PDEF,{
 yeti:{n:'Glacierhorn',r:'m',fam:'Frost',box:[-60,-124,122,126],ab:{k:'permafrost',n:'Permafrost Armor',N:30,d:'Start every run wrapped in ice armor that blocks 2 hits. Every 30 correct words, one cracked layer regrows.',x:'When a layer cracks, a frost nova freezes nearby monsters for 2 seconds. Bosses are chilled instead.'},
  bio:'Born inside a glacier that never melts. Its crystal horns ring like bells when danger is near.',cos:{acc:'Frostbloom scarf',pal:'Aurora',cel:'Snowfall',sig:'Glacier Titan'},greet:'shakes the snow from its horns'},
 sol:{n:'Solmane',r:'m',fam:'Sun',box:[-62,-128,124,130],ab:{k:'sunburst',n:'Sunburst Roar',N:15,cap:3,d:'Type 15 words in a row without a typo to roar: blast every monster on screen and restore 1 heart.',x:'Up to 3 roars per run. A typo restarts the streak. Bosses take heavy damage instead.'},
  bio:'A lion cub with the sunrise caught in its mane. When it roars, night itself takes a step back.',cos:{acc:'Sunstone crown',pal:'Eclipse',cel:'Solar flare',sig:'Supernova Mane'},greet:'shakes out its golden mane'}
});
for(const id of['yeti','sol'])if(!PIDS.includes(id))PIDS.push(id);
PRAR.m={n:'Mythic',c:'#ff6fae',egg:'Starforge'};
PEGG_PRICE.m=50000;
Object.assign(PFAM,{Frost:'#7fe8ff',Sun:'#ffb42a'});
const PMYTH=['yeti','sol'];
const petMythic=id=>!!(PDEF[id]&&PDEF[id].r==='m');
/* eggs.m is normalised in petNorm (87a); Starforge eggs are never placed on the Adventure Trail */
petNorm();
/* ===== MYTHIC COMPANIONS: art =====
   Glacierhorn and Solmane are drawn like every other companion (feet at the origin, facing right, about 100 units of body),
   with richer layering: fur scallops, crescent shading, rim highlights, glowing details and a full set of poses.
   The Starforge egg is a deep-space shell mended with gold, with drifting nebulae, twinkling constellations, a floating star finial
   and a little comet that circles it. */

/* ---------- shared helpers ---------- */
/* scalloped fur blob added to the current path */
function pmFluff(g,cx,cy,rx,ry,n,amp,a0,rot){a0=a0||0;rot=rot||0;const cr=Math.cos(rot),sr=Math.sin(rot),pt=(a,k)=>{const x=rx*k*Math.cos(a),y=ry*k*Math.sin(a);return[cx+x*cr-y*sr,cy+x*sr+y*cr]};
 let p=pt(a0,1);g.moveTo(p[0],p[1]);for(let i=0;i<n;i++){const am=a0+TAU*(i+.5)/n,q=pt(am,1+amp),e=pt(a0+TAU*(i+1)/n,1);g.quadraticCurveTo(q[0],q[1],e[0],e[1])}g.closePath()}
/* a tapered tube along a chain of cubic segments [x0,y0, c1x,c1y, c2x,c2y, x1,y1, c1x,...] */
function pmTubePath(g,p,w0,w1){const segs=(p.length-2)/6,N=14,pts=[];for(let s=0;s<segs;s++){const o=s*6;for(let k=s?1:0;k<=N;k++){const t=k/N,m=1-t;pts.push([m*m*m*p[o]+3*m*m*t*p[o+2]+3*m*t*t*p[o+4]+t*t*t*p[o+6],m*m*m*p[o+1]+3*m*m*t*p[o+3]+3*m*t*t*p[o+5]+t*t*t*p[o+7]])}}
 const L=[],R=[],n=pts.length;for(let i=0;i<n;i++){const a=pts[Math.max(0,i-1)],b=pts[Math.min(n-1,i+1)],dx=b[0]-a[0],dy=b[1]-a[1],l=Math.hypot(dx,dy)||1,w=(w0+(w1-w0)*i/(n-1))/2;L.push([pts[i][0]-dy/l*w,pts[i][1]+dx/l*w]);R.push([pts[i][0]+dy/l*w,pts[i][1]-dx/l*w])}
 const ang=(i,j)=>Math.atan2(pts[j][1]-pts[i][1],pts[j][0]-pts[i][0]),ae=ang(n-2,n-1),as=ang(0,1);
 g.moveTo(L[0][0],L[0][1]);for(const q of L)g.lineTo(q[0],q[1]);g.arc(pts[n-1][0],pts[n-1][1],Math.max(.1,w1/2),ae+Math.PI/2,ae-Math.PI/2,true);for(let i=n-1;i>=0;i--)g.lineTo(R[i][0],R[i][1]);g.arc(pts[0][0],pts[0][1],Math.max(.1,w0/2),as-Math.PI/2,as+Math.PI/2,true);g.closePath();return pts}
/* crescent shade on the lower right of a shape: fill the shape minus itself nudged up-left */
function pmShade(g,path,dx,dy,col){g.save();g.beginPath();path(0,0);g.clip();g.beginPath();g.rect(-600,-600,1200,1200);path(-dx,-dy);g.fillStyle=col;g.fill('evenodd');g.restore()}
/* white-sclera eye with a coloured iris (the concept-art eye), plus closed and happy states */
function pmEye(g,x,y,r,iris,open,happy,lx,ly,glow){lx=lx||0;ly=ly||0;
 if(happy){g.beginPath();g.arc(x,y+r*.45,r*.85,Math.PI*1.12,Math.PI*1.88);g.strokeStyle=PTO;g.lineWidth=Math.max(2,r*.36);g.stroke();return}
 if(open<.22){g.beginPath();g.moveTo(x-r*.9,y+r*.1);g.quadraticCurveTo(x,y+r*.42,x+r*.9,y+r*.1);g.strokeStyle=PTO;g.lineWidth=Math.max(2,r*.32);g.stroke();return}
 if(glow)pGlow(g,x,y,r*2.6,glow,.45);
 const ry=r*1.12*open;g.save();g.beginPath();g.ellipse(x,y,r,ry,0,0,TAU);g.fillStyle='#ffffff';g.fill();g.clip();
 const ix=x+lx*r*.26,iy=y+ly*r*.2+r*.1;const q=g.createRadialGradient(ix-r*.2,iy-r*.35,r*.05,ix,iy,r*.78);q.addColorStop(0,'#ffffff');q.addColorStop(.32,iris);q.addColorStop(1,iris);g.fillStyle=q;g.beginPath();g.arc(ix,iy,r*.74,0,TAU);g.fill();
 g.beginPath();g.arc(ix,iy+r*.04,r*.42,0,TAU);g.fillStyle='#0c0612';g.fill();g.beginPath();g.ellipse(x,y-ry*.95,r*1.3,r*.36,0,0,TAU);g.fillStyle='#1b102430';g.fill();g.restore();
 g.beginPath();g.ellipse(x,y,r,ry,0,0,TAU);g.strokeStyle=PTO;g.lineWidth=Math.max(1.6,r*.27);g.stroke();
 g.beginPath();g.arc(ix-r*.3,iy-r*.36*open,r*.27,0,TAU);g.fillStyle='#fff';g.fill();g.beginPath();g.arc(ix+r*.28,iy+r*.3*open,r*.12,0,TAU);g.fillStyle='#ffffffdd';g.fill()}
/* a faceted crystal shard pointing along angle a (0 = up) */
function pmCrystal(g,x,y,h,w,a,c1,c2,lw){g.save();g.translate(x,y);g.rotate(a);g.beginPath();g.moveTo(-w/2,0);g.lineTo(-w/2,-h*.7);g.lineTo(0,-h);g.lineTo(w/2,-h*.7);g.lineTo(w/2,0);g.closePath();pF(g,pLin(g,-w/2,-h,w/2,0,[c1,c2]),lw==null?2.2:lw);
 g.beginPath();g.moveTo(0,0);g.lineTo(0,-h*.7);g.lineTo(0,-h);g.lineTo(w/2,-h*.7);g.lineTo(w/2,0);g.closePath();g.fillStyle='#0a1a4a26';g.fill();
 g.beginPath();g.moveTo(-w*.28,-h*.08);g.lineTo(-w*.28,-h*.66);g.strokeStyle='#ffffffcc';g.lineWidth=Math.max(.8,w*.12);g.stroke();g.restore()}
function pmSnow(g,x,y,r,c,lw){g.save();g.translate(x,y);g.strokeStyle=c;g.lineWidth=lw||1.4;g.lineCap='round';for(let i=0;i<6;i++){g.rotate(Math.PI/3);g.beginPath();g.moveTo(0,0);g.lineTo(0,-r);g.moveTo(0,-r*.55);g.lineTo(r*.28,-r*.8);g.moveTo(0,-r*.55);g.lineTo(-r*.28,-r*.8);g.stroke()}g.restore()}
function pmSun(g,x,y,r,n,c1,c2,rot){g.save();g.translate(x,y);g.rotate(rot||0);g.beginPath();for(let i=0;i<n*2;i++){const a=i*Math.PI/n,rr=i%2?r*.55:r;g.lineTo(Math.cos(a)*rr,Math.sin(a)*rr)}g.closePath();pF(g,pLin(g,0,-r,0,r,[c1,c2]),Math.max(1,r*.16));g.restore()}
const pmEase=k=>1-Math.pow(1-Math.max(0,Math.min(1,k)),3);

/* ---------- palettes ---------- */
Object.assign(PCOL,{
 yeti:[{fu:'#ffffff',fu2:'#dcefff',fud:'#9cc4ee',sh:'#1d3a8a',sk:'#a8d4ff',skd:'#5f86d6',so:'#5a7cc8',sol:'#8fb0ea',h1:'#ffffff',h2:'#bff4ff',h3:'#3fa8ec',cr:'#e6fdff',crd:'#4fb8f4',ey:'#2ad8ff',ru:'#5ff0ff',bl:'#ff8ab8',sc1:'#3ac8c8',sc2:'#e8fffb'},
       {fu:'#fff8ff',fu2:'#f1e2ff',fud:'#c4a6ee',sh:'#4a1a7a',sk:'#e4c4ff',skd:'#9a6ad8',so:'#8a5ac8',sol:'#c4a0f0',h1:'#ffffff',h2:'#ffd6f4',h3:'#c86ae8',cr:'#fff0fb',crd:'#d07af0',ey:'#ff6ad0',ru:'#ff9ae8',bl:'#ff8ab8',sc1:'#8a5ae0',sc2:'#fff0ff'}],
 sol:[{b:'#fff3d6',b2:'#ffdca0',bd:'#e2a14a',be:'#fffaf0',mn:'#ffd45a',mn2:'#f08a1a',r1:'#ff6a2a',r2:'#ffb42a',r3:'#ffe07a',r4:'#ff9a2a',ie:'#ff9ab0',ey:'#ff9a10',no:'#c8506a',fl1:'#fff2a0',fl2:'#ffb42a',fl3:'#ff5a2a',mk:'#ffd45a',sh:'#7a3a10',col:'#ffd45a',cold:'#b8801a',gem:'#ff4f8b'},
      {b:'#f2eeff',b2:'#d8ceff',bd:'#9a88d0',be:'#ffffff',mn:'#a88aff',mn2:'#5a3ac8',r1:'#4a2aa8',r2:'#8a6aff',r3:'#e0d6ff',r4:'#6a4ad8',ie:'#d8b8ff',ey:'#3ae8ff',no:'#8a5aa8',fl1:'#e8f8ff',fl2:'#7ab8ff',fl3:'#6a4aff',mk:'#eef4ff',sh:'#2a1a5a',col:'#dfe6ff',cold:'#7a86b8',gem:'#5af0ff'}]});

/* ======================================================================
   GLACIERHORN: crystal-horned mini yeti
   ====================================================================== */
PRIG.yeti=(g,o,C)=>{const t=o.t,P=o.pose,u=o.u,walk=P==='walk',ab=P==='ability',gr=P==='greet',trim=o.trim;
 /* ----- motion ----- */
 let by=0,lean=0,sx=1,sy=1,aL=.26,aR=-.26,happy=false,glowB=0,lx=.5,ly=0,eyeO=pBlink(t,4),squint=0;
 if(walk){const w=t*8.5;lean=Math.sin(w)*.08;by=-Math.abs(Math.sin(w))*3.2;aL=.26+Math.sin(w)*.45;aR=-.26+Math.sin(w)*.45}
 else if(P==='idle'){/* every so often it glances around, and now and then gives a big contented stretch */const ph=(t%9.2+9.2)%9.2;if(ph>5.2&&ph<6.4)lx=-.7;else if(ph>6.4&&ph<6.9)lx=.1;
  if(ph<1.3){const k=ph/1.3,s=Math.sin(k*Math.PI);aL=.26+s*1.9;aR=-.26-s*1.9;sy=1+s*.04;sx=1-s*.02;if(k>.2&&k<.8)eyeO=0;}aL+=Math.sin(t*1.7)*.05;aR-=Math.sin(t*1.7+.6)*.05}
 if(gr){const hop=u<.3?Math.sin(u/.3*Math.PI):0;by=-hop*12;if(u<.05||(u>.28&&u<.34)){sy=.9;sx=1.08}happy=u>.12&&u<.92;
  const wv=pSeg(u,.12,.28)*(1-pSeg(u,.84,.98));aR=-.26-wv*(2.3+Math.sin(u*26)*.35);aL=.26+wv*.3;glowB=wv*.6}
 if(ab){const cr=pSeg(u,0,.2)*(1-pSeg(u,.2,.3)),up=pSeg(u,.22,.4)*(1-pSeg(u,.42,.5)),slam=pSeg(u,.44,.5),set=pSeg(u,.7,1);
  sy=1-cr*.12+up*.08-(u>.48&&u<.6?(1-pSeg(u,.48,.6))*.14:0);sx=1+cr*.08-up*.04+(u>.48&&u<.6?(1-pSeg(u,.48,.6))*.1:0);by=-up*14;
  const raise=pSeg(u,.18,.38)*(1-slam);aL=.26+raise*2.25-cr*.5+slam*(1-set)*.9;aR=-.26-raise*2.25+cr*.5-slam*(1-set)*.9;glowB=Math.max(raise,(1-set)*slam);squint=cr;eyeO=cr>.5?.35:eyeO}
 const hg=.55+.25*Math.sin(t*2.2)+glowB*.9+(trim?.3:0),rg=.5+.5*Math.sin(t*2.6)+glowB;
 g.save();g.translate(0,by);g.rotate(lean);g.scale(sx,sy);
 const ice=(c1,c2,c3)=>[c1,c2,c3];
 /* ----- signature: aurora mantle and orbiting shards (back half) ----- */
 const orb=(front)=>{if(!trim)return;for(let i=0;i<3;i++){const a=t*1.1+i*TAU/3,s=Math.sin(a);if((s>0)!==front)continue;const x=Math.cos(a)*56,y=-60+s*12+Math.sin(t*2+i)*3;g.globalAlpha=front?1:.75;pGlow(g,x,y,14,C.ru,.5);pmCrystal(g,x,y+6,14,7,Math.sin(t+i)*.4,C.cr,C.crd,1.6);g.globalAlpha=1}};
 if(trim){g.save();g.globalCompositeOperation='lighter';for(let i=0;i<3;i++){g.beginPath();for(let k=0;k<=20;k++){const x=-56+k*5.6,y=-112+i*8+Math.sin(k*.5+t*1.4+i)*6;k?g.lineTo(x,y):g.moveTo(x,y)}g.strokeStyle=ptHexA(['#7ff0ff','#b47aff','#7affc8'][i],.22);g.lineWidth=7;g.stroke()}g.restore();pGlow(g,2,-62,70,C.ru,.18+.06*Math.sin(t*1.5))}
 orb(false);
 /* ----- back crystals on the shoulders ----- */
 for(const [x,y,h,w,a] of[[-17,-52,16,7.5,-.55],[-23,-46,11,6,-.95],[21,-52,16,7.5,.55],[27,-46,11,6,.95]]){pGlow(g,x+Math.sin(a)*h*.6,y-Math.cos(a)*h*.6,12,C.ru,.18*hg);pmCrystal(g,x,y,h,w,a,C.cr,C.crd,2)}
 /* ----- feet ----- */
 const foot=(x,ph)=>{const lift=walk?Math.max(0,Math.sin(t*8.5+ph))*4:0,fx=walk?Math.cos(t*8.5+ph)*2:0;g.save();g.translate(x+fx,-4-lift-by*0);pE(g,0,0,12.5,6.6);pF(g,pLin(g,0,-6,0,6,[C.sol,C.so]),2.4);
  for(let i=-1;i<=1;i++){pC(g,i*6.2,-4.4,2.6);pF(g,C.sk,1.4)}g.restore()};
 foot(-12,Math.PI);foot(16,0);
 /* ----- body ----- */
 const body=(ox,oy)=>pmFluff(g,ox,-30+oy,29,26,13,.13,.25);
 g.beginPath();body(0,0);pF(g,pRad(g,-6,-40,34,[C.fu,C.fu2,C.fud]),2.6);pmShade(g,body,-7,-6,ptHexA(C.sh,.18));
 pE(g,2,-24,15,15);g.fillStyle='#ffffff8a';g.fill();
 /* chest rune: a frost diamond with a snowflake that pulses (brighter while a power gathers) */
 pGlow(g,2,-27,14+rg*6,C.ru,.25+.25*rg);pP(g,[2,-36,9,-27,2,-18,-5,-27]);pF(g,pLin(g,0,-36,0,-18,['#f0ffff',C.ru,C.crd]),1.8);pmSnow(g,2,-27,4.6,'#ffffff',1.1);
 /* ----- arms ----- */
 const arm=(x,a,front)=>{g.save();g.translate(x,-46);g.rotate(a);const pth=(ox,oy)=>pmFluff(g,ox,15+oy,10,17,9,.16,.3);g.beginPath();pth(0,0);pF(g,pRad(g,-3,8,20,[C.fu,C.fu2,C.fud]),2.4);pmShade(g,pth,-3,-3,ptHexA(C.sh,.16));
  pE(g,0,30,7.6,6.2);pF(g,pLin(g,0,24,0,36,[C.sk,C.skd]),2);g.beginPath();g.moveTo(-3,33);g.lineTo(-3,35.5);g.moveTo(1.5,34);g.lineTo(1.5,36.4);g.strokeStyle=PTO;g.lineWidth=1.2;g.stroke();g.restore()};
 arm(-24,aL);
 /* ----- horns (behind the head) ----- */
 const horn=(s)=>{g.save();g.translate(2,0);g.scale(s,1);const big=trim?1.12:1;g.scale(big,big);
  const H=[-19,-89, -30,-100, -47,-95, -47,-107, -47,-118, -37,-123, -33,-113];
  /* small crystal spikes on the outer curve */pmCrystal(g,-42,-97,9,5.4,-1.95,C.cr,C.crd,1.5);pmCrystal(g,-48,-106,8.5,5,-1.6,C.cr,C.crd,1.5);
  pGlow(g,-42,-106,16,C.ru,.16*hg);g.beginPath();const pts=pmTubePath(g,H,12.5,3.6);pF(g,pLin(g,-48,-122,-20,-90,[C.h1,C.h2,C.h3]),2.4);
  /* ridges */g.strokeStyle=ptHexA(C.h3,.7);g.lineWidth=1.2;for(const i of[5,9,13,17,21]){const p=pts[i],q=pts[i+1];const dx=q[0]-p[0],dy=q[1]-p[1],l=Math.hypot(dx,dy)||1,w=(13-9*i/(pts.length-1))/2-1;g.beginPath();g.moveTo(p[0]-dy/l*w,p[1]+dx/l*w);g.lineTo(p[0]+dy/l*w,p[1]-dx/l*w);g.stroke()}
  /* a highlight, and a glint that slides along every few seconds */g.beginPath();for(let i=2;i<pts.length-3;i++){const p=pts[i];i===2?g.moveTo(p[0]+1,p[1]-2.2):g.lineTo(p[0]+1,p[1]-2.2)}g.strokeStyle='#ffffffb0';g.lineWidth=1.6;g.stroke();
  const gl=((t*.35+(s>0?0:.5))%1.6);if(gl<1){const p=pts[Math.floor(gl*(pts.length-1))];pGlow(g,p[0],p[1],10,'#ffffff',.7*Math.sin(gl*Math.PI));pStar4(g,p[0],p[1]-1,3.4*Math.sin(gl*Math.PI),'#ffffff')}
  g.restore()};
 horn(1);horn(-1);
 /* ----- head ----- */
 const head=(ox,oy)=>pmFluff(g,2+ox,-72+oy,33,29,17,.1,.12);
 g.save();const tilt=gr?Math.sin(u*Math.PI)*-.1:ab?-.06*pSeg(u,.2,.4)*(1-pSeg(u,.5,.7)):Math.sin(t*.9)*.025;g.translate(4,-58);g.rotate(tilt);g.translate(-4,58);
 g.beginPath();head(0,0);pF(g,pRad(g,-6,-86,40,[C.fu,C.fu2,C.fud]),2.6);pmShade(g,head,-7,-6,ptHexA(C.sh,.16));
 g.beginPath();g.ellipse(2,-72,26.5,23,0,Math.PI*1.08,Math.PI*1.42);g.strokeStyle='#ffffffe6';g.lineWidth=2.4;g.stroke();
 /* tuft */g.beginPath();pmFluff(g,2,-101,9,6,7,.32,.4);pF(g,pRad(g,0,-104,10,[C.fu,C.fu2]),2.2);
 /* forehead crystal */pGlow(g,5,-90,10,C.ru,.25*hg);pmCrystal(g,5,-84,12,7,0,C.cr,C.crd,1.8);
 if(trim){/* frost crown */for(const [x,h,a] of[[-10,8,-.5],[-3,11,-.2],[13,11,.2],[20,8,.5]]){pmCrystal(g,x,-96+Math.abs(x-5)*.2,h,4.6,a,'#ffffff',C.crd,1.4)}}
 /* face patch */const face=(ox,oy)=>{g.moveTo(5+ox,-80+oy);g.bezierCurveTo(17+ox,-86+oy,30+ox,-79+oy,29+ox,-66+oy);g.bezierCurveTo(28+ox,-53+oy,17+ox,-46+oy,5+ox,-46+oy);g.bezierCurveTo(-7+ox,-46+oy,-18+ox,-53+oy,-19+ox,-66+oy);g.bezierCurveTo(-20+ox,-79+oy,-7+ox,-86+oy,5+ox,-80+oy);g.closePath()};
 g.beginPath();face(0,0);pF(g,pLin(g,0,-82,0,-46,[C.sk,C.skd]),2.2);pmShade(g,face,-3,-4,ptHexA(C.sh,.18));g.beginPath();g.ellipse(2,-71,15,9,0,0,TAU);g.fillStyle='#ffffff22';g.fill();
 /* brow fringe: soft fur bumps that tumble over the top of the face */g.save();g.beginPath();face(0,0);g.clip();g.fillStyle=pLin(g,0,-92,0,-74,[C.fu,C.fu2]);g.fillRect(-30,-100,70,16);
 for(let i=0;i<7;i++){const x=-15+i*6.7,y=-82.4+Math.sin(i/6*Math.PI)*-1.6+(i%2)*1.2;g.beginPath();g.arc(x,y,4.8,0,TAU);g.fill()}
 g.strokeStyle=PTO;g.lineWidth=1.7;for(let i=0;i<7;i++){const x=-15+i*6.7,y=-82.4+Math.sin(i/6*Math.PI)*-1.6+(i%2)*1.2;g.beginPath();g.arc(x,y,4.8,.25,Math.PI-.25);g.stroke()}g.restore();
 g.beginPath();face(0,0);g.strokeStyle=PTO;g.lineWidth=2.2;g.stroke();
 /* eyes */const eg=trim||glowB>.3?C.ru:null;pmEye(g,-4,-65,6.6,C.ey,eyeO*(1-squint*.5),happy,lx,ly,eg);pmEye(g,14,-65,6.6,C.ey,eyeO*(1-squint*.5),happy,lx,ly,eg);
 if(squint>.2){g.strokeStyle=PTO;g.lineWidth=2;g.beginPath();g.moveTo(-10,-73);g.lineTo(0,-71);g.moveTo(20,-73);g.lineTo(10,-71);g.stroke()}
 /* blush, nose, mouth */pE(g,-12,-56,4.6,2.6);g.fillStyle=ptHexA(C.bl,.55);g.fill();pE(g,22,-56,4.6,2.6);g.fill();
 g.beginPath();g.moveTo(1.4,-58.6);g.quadraticCurveTo(5,-61,8.6,-58.6);g.quadraticCurveTo(7.6,-55,5,-54.4);g.quadraticCurveTo(2.4,-55,1.4,-58.6);g.closePath();pF(g,'#3a3f8a',1.4);pC(g,4,-58.4,.9);g.fillStyle='#ffffffcc';g.fill();
 if(happy||(ab&&u>.44&&u<.75)){g.beginPath();g.moveTo(-.5,-51.5);g.quadraticCurveTo(5,-51,10.5,-51.5);g.quadraticCurveTo(9,-44.5,5,-44);g.quadraticCurveTo(1,-44.5,-.5,-51.5);g.closePath();pF(g,'#3a1238',1.6);pE(g,5,-46.2,3,1.6);g.fillStyle='#ff7aa8';g.fill();pP(g,[.6,-51,2.6,-48,4,-51]);g.fillStyle='#fff';g.fill()}
 else{g.beginPath();g.moveTo(.4,-51.6);g.quadraticCurveTo(2.7,-49.4,5,-51.2);g.quadraticCurveTo(7.3,-49.4,9.6,-51.6);g.strokeStyle=PTO;g.lineWidth=1.5;g.stroke();pP(g,[6.4,-50.6,7.6,-47.4,8.8,-50.6]);pF(g,'#fff',1)}
 g.restore();
 /* ----- accessory: frostbloom scarf (wraps the neck, over the chin fur) ----- */
 if(o.acc){const sw=Math.sin(t*2.2)*.12+(walk?Math.sin(t*8.5)*.15:0);g.save();g.beginPath();g.moveTo(-24,-44);g.quadraticCurveTo(2,-32,28,-44);g.lineTo(29,-37);g.quadraticCurveTo(2,-24,-25,-37);g.closePath();pF(g,pLin(g,0,-44,0,-32,[C.sc1,ptHexA(C.sc1,1)]),2.2);
  g.save();g.beginPath();g.moveTo(-24,-44);g.quadraticCurveTo(2,-32,28,-44);g.lineTo(29,-37);g.quadraticCurveTo(2,-24,-25,-37);g.closePath();g.clip();g.strokeStyle=C.sc2;g.lineWidth=3;for(let x=-20;x<30;x+=10){g.beginPath();g.moveTo(x,-46);g.lineTo(x+4,-24);g.stroke()}g.restore();
  g.translate(18,-35);g.rotate(sw);g.beginPath();g.moveTo(-4,0);g.quadraticCurveTo(2,10,0,22);g.lineTo(8,22);g.quadraticCurveTo(9,9,5,0);g.closePath();pF(g,C.sc1,2);g.fillStyle=C.sc2;g.fillRect(-1,9,8,3);for(let i=0;i<3;i++){g.beginPath();g.moveTo(1+i*3,22);g.lineTo(1+i*3,26);g.strokeStyle=C.sc1;g.lineWidth=1.6;g.stroke()}g.restore();
  pGlow(g,-14,-38,8,'#ffffff',.4);pmSnow(g,-14,-44,4.4,'#ffffff',1.6)}
 arm(28,aR);
 orb(true);
 /* ----- frosty breath now and then ----- */
 if(P==='idle'){const ph=((t+2.1)%6.4+6.4)%6.4;if(ph<1.4){const k=ph/1.4;for(let i=0;i<3;i++){const v=Math.max(0,Math.min(1,k*1.6-i*.22));if(v<=0||v>=1)continue;g.globalAlpha=Math.sin(v*Math.PI)*.7;pC(g,14+v*22+i*3,-52-v*10-i*2,2.6+v*4);g.fillStyle='#eaf8ff';g.fill();g.globalAlpha=1}}}
 g.restore();
 /* ----- ability: crystals erupt from the ground and a frost ring rolls out ----- */
 if(ab&&u>.46){const v=pSeg(u,.46,.62),f=1-pSeg(u,.8,1);g.save();g.globalAlpha=f;
  g.save();g.globalCompositeOperation='lighter';g.translate(2,0);g.scale(1,.26);const rr=20+pmEase(pSeg(u,.46,.9))*90;g.beginPath();g.arc(0,0,rr,0,TAU);g.strokeStyle=ptHexA(C.ru,.8*(1-pSeg(u,.6,1)));g.lineWidth=9;g.stroke();g.strokeStyle='#ffffffaa';g.lineWidth=3;g.stroke();g.restore();
  for(const [x,h,a,d] of[[-44,26,-.5,0],[-30,18,-.25,.03],[36,28,.45,.01],[50,18,.7,.05],[-58,14,-.8,.06],[64,13,.9,.07]]){const k=pmEase(pSeg(u,.46+d,.6+d));if(k<=0)continue;pGlow(g,x,-h*.4*k,16*k,C.ru,.35);pmCrystal(g,x,2,h*k,h*.4,a,'#ffffff',C.crd,1.8)}
  for(let i=0;i<10;i++){const a=i/10*TAU+.3,r=24+v*70;pmSnow(g,2+Math.cos(a)*r,-40+Math.sin(a)*r*.6-v*10,3+i%3,'#ffffff',1.2)}
  g.restore()}
 if(gr&&u>.12&&u<.95){for(let i=0;i<5;i++){const v=((u*1.6+i/5)%1);g.globalAlpha=Math.sin(v*Math.PI);pStar4(g,-30+i*16+Math.sin(i*3+u*8)*6,-110-v*26,2.4+i%2,'#ffffff');g.globalAlpha=1}}};

/* ======================================================================
   SOLMANE: sun-maned lion cub
   ====================================================================== */
const PM_CH={sol:0,yeti:0};/* live charge (0..1) set by the battle layer so the sun mark can brighten as a streak builds */
PRIG.sol=(g,o,C)=>{const t=o.t,P=o.pose,u=o.u,walk=P==='walk',ab=P==='ability',gr=P==='greet',trim=o.trim,ecl=!!o.pal;
 let by=0,tilt=Math.sin(t*.8)*.03,sx=1,sy=1,happy=false,eyeO=pBlink(t,9),mouth=0,flare=0,paw=0,pawL=0,pawR=0,mScale=1+Math.sin(t*1.9)*.025,lx=.4,earT=0;
 const ch=Math.max(PM_CH.sol||0,o.charge||0);
 if(walk){const w=t*9.5;by=-Math.abs(Math.sin(w))*3.6;pawL=Math.max(0,Math.sin(w))*4;pawR=Math.max(0,-Math.sin(w))*4;tilt+=Math.sin(w)*.04}
 else if(P==='idle'){const ph=(t%9.6+9.6)%9.6;/* a big cosy yawn */if(ph<1.5){const k=ph/1.5,s=Math.sin(k*Math.PI);mouth=s*.75;eyeO=s>.35?0:eyeO;tilt-=s*.16;mScale+=s*.05}
  if(ph>4&&ph<4.3)earT=Math.sin((ph-4)/.3*Math.PI);if(ph>6&&ph<7.2)lx=-.6}
 if(gr){happy=u>.08&&u<.92;const pf=Math.sin(Math.min(1,u/.3)*Math.PI);mScale+=pf*.14;by=-Math.sin(Math.min(1,u/.25)*Math.PI)*8;tilt=-Math.sin(u*Math.PI)*.16;paw=pSeg(u,.15,.3)*(1-pSeg(u,.8,.95))}
 if(ab){const gat=pSeg(u,0,.22),inh=pSeg(u,.18,.38),roar=pSeg(u,.38,.46)*(1-pSeg(u,.8,.95));sy=1-gat*.08*(1-inh)+inh*.04;sx=1+gat*.06*(1-inh);tilt=-inh*.22*(1-roar)+roar*-.1;mouth=roar;flare=Math.max(inh*.25,roar);mScale+=-gat*.08*(1-inh)+roar*.1;eyeO=roar>.4?.4:eyeO;by=-roar*4}
 const hx=1,hy=-70;
 g.save();g.translate(0,by);g.scale(sx,sy);
 /* ----- signature: corona and orbiting suns ----- */
 const suns=(front)=>{if(!trim)return;for(let i=0;i<3;i++){const a=t*.9+i*TAU/3,s=Math.sin(a);if((s>0)!==front)continue;const x=hx+Math.cos(a)*62,y=hy+4+s*14;pGlow(g,x,y,14,C.fl2,.6);pmSun(g,x,y,5.5,8,C.fl1,C.fl2,t*2+i);pC(g,x,y,2.6);g.fillStyle='#fffbe0';g.fill()}};
 if(trim){pGlow(g,hx,hy,92,C.fl2,.22+.08*Math.sin(t*2));g.save();g.globalCompositeOperation='lighter';g.translate(hx,hy);g.rotate(-t*.25);for(let i=0;i<24;i++){g.rotate(TAU/24);const L=64+Math.sin(t*3+i*1.7)*8+(i%2)*10;g.beginPath();g.moveTo(-2,-40);g.lineTo(0,-L);g.lineTo(2,-40);g.closePath();g.fillStyle=ptHexA(C.fl1,.35);g.fill()}g.restore()}
 suns(false);
 /* ----- tail with a sun-flame tuft ----- */
 const sw=Math.sin(t*(walk?6:2.1))*.16+(ab?pSeg(u,.38,.5)*.3*(1-pSeg(u,.8,1)):0);g.save();g.translate(18,-12);g.rotate(sw);
 g.beginPath();pmTubePath(g,[0,0, 18,6, 32,-6, 28,-28],7,5);pF(g,pLin(g,0,0,30,-28,[C.b2,C.bd]),2.2);
 g.translate(28,-30);const fl=Math.sin(t*11)*.14,fs=1+Math.sin(t*7)*.06+(trim?.25:0)+flare*.3;g.scale(fs,fs);pGlow(g,0,-6,16,C.fl2,.55+flare*.3);
 for(const [c,k] of[[C.fl3,1],[C.fl2,.72],[C.fl1,.42]]){g.beginPath();g.moveTo(-6*k,4*k);g.quadraticCurveTo(-10*k,-6*k,-2*k+fl*8,-18*k);g.quadraticCurveTo(0,-9*k,4*k,-13*k);g.quadraticCurveTo(9*k,-2*k,6*k,4*k);g.quadraticCurveTo(0,8*k,-6*k,4*k);g.closePath();pF(g,c,k===1?1.8:0)}g.restore();
 /* ----- haunches and body ----- */
 for(const x of[-19,21]){pE(g,x,-10,13.5,10.5);pF(g,pRad(g,x-3,-14,14,[C.b,C.b2,C.bd]),2.4)}
 const body=(ox,oy)=>{g.moveTo(-20+ox,-20+oy);g.bezierCurveTo(-22+ox,-40+oy,-10+ox,-48+oy,1+ox,-48+oy);g.bezierCurveTo(12+ox,-48+oy,24+ox,-40+oy,22+ox,-20+oy);g.bezierCurveTo(21+ox,-6+oy,12+ox,0+oy,1+ox,0+oy);g.bezierCurveTo(-10+ox,0+oy,-19+ox,-6+oy,-20+ox,-20+oy);g.closePath()};
 g.beginPath();body(0,0);pF(g,pRad(g,-5,-34,30,[C.b,C.b2,C.bd]),2.6);pmShade(g,body,-5,-5,ptHexA(C.sh,.16));pE(g,1,-17,10.5,13);g.fillStyle=ptHexA(C.be,.85);g.fill();
 /* front paws */const pawD=(x,lift,wave)=>{g.save();g.translate(x,-3.5-lift);if(wave>0){g.translate(0,-2);g.rotate(-wave*.5);g.translate(wave*6,-wave*22)}pE(g,0,0,8.4,5.6);pF(g,pRad(g,-2,-2,9,[C.be,C.b2]),2.2);g.strokeStyle=PTO;g.lineWidth=1.3;g.beginPath();g.moveTo(-2.4,-2.2);g.lineTo(-2.4,1.8);g.moveTo(2.4,-2.2);g.lineTo(2.4,1.8);g.stroke();
  if(wave>0){pE(g,0,-.6,3.4,2.4);g.fillStyle=ptHexA(C.ie,.9);g.fill()}g.restore()};
 pawD(-8,pawL,0);pawD(10,pawR,paw);
 /* collar and gem */g.beginPath();g.moveTo(-17,-46);g.quadraticCurveTo(1,-36,19,-46);g.lineTo(19.5,-41.5);g.quadraticCurveTo(1,-30,-17.5,-41.5);g.closePath();pF(g,pLin(g,0,-46,0,-32,[C.col,C.cold]),1.8);
 for(const x of[-11,13]){pC(g,x,-40.4,1.3);g.fillStyle='#fffbe0';g.fill()}pGlow(g,1,-30,10,C.gem,.5);pP(g,[1,-36,5.4,-31,1,-24.4,-3.4,-31]);pF(g,pLin(g,0,-36,0,-24,['#ffe0ee',C.gem]),1.6);pP(g,[1,-36,-3.4,-31,1,-30.4]);g.fillStyle='#ffffffaa';g.fill();
 /* ----- head group ----- */
 g.save();g.translate(hx,-52);g.rotate(tilt);g.translate(-hx,52);
 /* mane rays: rounded sun petals that slowly turn, flare on a roar */
 const rot=t*.12+(ab?u*.6:0);g.save();g.translate(hx,hy);g.scale(mScale,mScale);
 if(flare>0){pGlow(g,0,0,80+flare*40,C.fl2,.35*flare);}
 for(let i=0;i<14;i++){const a=rot+i*TAU/14,lg=i%2===0,r0=23,r1=(lg?50:42)*(1+flare*.2),wd=lg?.24:.21;
  const p0=[Math.cos(a-wd)*r0,Math.sin(a-wd)*r0],p2=[Math.cos(a+wd)*r0,Math.sin(a+wd)*r0],tp=[Math.cos(a)*r1,Math.sin(a)*r1],b=r1*.74,c0=[Math.cos(a-wd*1.3)*b,Math.sin(a-wd*1.3)*b],c2=[Math.cos(a+wd*1.3)*b,Math.sin(a+wd*1.3)*b];
  g.beginPath();g.moveTo(p0[0],p0[1]);g.bezierCurveTo(c0[0],c0[1],tp[0],tp[1],tp[0],tp[1]);g.bezierCurveTo(tp[0],tp[1],c2[0],c2[1],p2[0],p2[1]);g.closePath();
  if(trim){const fl2=Math.sin(t*9+i*1.3)*.08;g.save();g.scale(1+fl2,1+fl2);pF(g,lg?pLin(g,0,0,tp[0],tp[1],[C.fl3,C.fl2,C.fl1]):pLin(g,0,0,tp[0],tp[1],[C.fl2,C.fl1]),2);g.restore()}
  else pF(g,lg?pLin(g,Math.cos(a)*r0,Math.sin(a)*r0,tp[0],tp[1],[C.r1,C.r2]):pLin(g,Math.cos(a)*r0,Math.sin(a)*r0,tp[0],tp[1],[C.r4,C.r3]),2.1);
  g.beginPath();g.moveTo(Math.cos(a)*(r0+5),Math.sin(a)*(r0+5));g.lineTo(Math.cos(a)*(r1-9),Math.sin(a)*(r1-9));g.strokeStyle=ptHexA('#ffffff',.42);g.lineWidth=1.6;g.stroke()}
 const mane=(ox,oy)=>pmFluff(g,ox,oy,34,32,16,.15,.1);g.beginPath();mane(0,0);pF(g,pRad(g,-6,-8,40,[C.r3,C.mn,C.mn2]),2.4);pmShade(g,mane,-6,-5,ptHexA(C.sh,.18));
 g.beginPath();g.arc(0,0,30,Math.PI*1.1,Math.PI*1.45);g.strokeStyle='#ffffffa0';g.lineWidth=2;g.stroke();g.restore();
 /* ears */for(const [x,s] of[[-21,-1],[23,1]]){g.save();g.translate(x,-94);if(s>0)g.rotate(earT*.3);pC(g,0,0,8.6);pF(g,pRad(g,-2,-2,9,[C.b,C.b2]),2.2);pC(g,.4,.8,4.6);g.fillStyle=C.ie;g.fill();g.restore()}
 if(o.acc){/* sunstone crown */g.save();g.translate(hx,-93);g.rotate(-.06);pGlow(g,0,-6,16,C.fl2,.35);pP(g,[-12,3,-13,-6,-7,-2,-3,-11,1,-3,5,-11,9,-2,14,-6,13,3]);pF(g,pLin(g,0,-11,0,3,['#fff6c0','#ffd45a','#b8801a']),1.8);
  g.beginPath();g.roundRect(-12,1,25,4,1.5);pF(g,pLin(g,0,1,0,5,['#ffe48a','#c8901a']),1.2);pmSun(g,1,-3,3.6,6,'#fff2a0','#ff8a2a',t);for(const [x,y] of[[-13,-6],[-3,-11],[5,-11],[14,-6]]){pC(g,x,y,1.4);pF(g,'#fff8e8',.8)}g.restore()}
 /* face */const head=(ox,oy)=>{g.ellipse(hx+ox,-68+oy,25,23,0,0,TAU)};g.beginPath();head(0,0);pF(g,pRad(g,-6,-78,30,[C.be,C.b,C.b2]),2.5);pmShade(g,head,-5,-5,ptHexA(C.sh,.14));
 g.beginPath();g.ellipse(hx,-68,20,18,0,Math.PI*1.1,Math.PI*1.45);g.strokeStyle='#ffffffd0';g.lineWidth=2;g.stroke();
 /* the sun mark brightens as a streak builds, blazes on a roar */const mk=Math.min(1,ch+flare*.8+(gr?.4:0)),tw=.5+.5*Math.sin(t*3);pGlow(g,hx,-83.5,10+mk*16,C.fl2,.35+mk*.5+.1*tw);
 if(ecl){g.beginPath();g.arc(hx,-83.5,5.4,.6,Math.PI*1.7);g.arc(hx+2.2,-84.6,4.2,Math.PI*1.7,.6,true);g.closePath();pF(g,pLin(g,0,-89,0,-78,['#ffffff',C.mk]),1.2)}
 else{pmSun(g,hx,-83.5,5.6,8,C.fl1,C.mk,t*.4);pC(g,hx,-83.5,2);g.fillStyle=mk>.5?'#ffffff':C.fl1;g.fill();g.strokeStyle=ptHexA(C.sh,.6);g.lineWidth=.8;g.stroke()}
 /* brows */g.strokeStyle=ptHexA(C.sh,.55);g.lineWidth=1.6;g.beginPath();g.moveTo(-14,-79);g.quadraticCurveTo(-9,-81.5,-4,-79.5);g.moveTo(6,-79.5);g.quadraticCurveTo(11,-81.5,16,-79);g.stroke();
 pmEye(g,-8,-70,6.4,C.ey,eyeO,happy,lx,0,trim?C.fl2:null);pmEye(g,10,-70,6.4,C.ey,eyeO,happy,lx,0,trim?C.fl2:null);
 pE(g,-15,-61,4.6,2.6);g.fillStyle=ptHexA('#ff8a9a',.5);g.fill();pE(g,17,-61,4.6,2.6);g.fill();
 /* muzzle, nose, mouth */
 if(mouth>.05){const m=mouth;g.beginPath();g.ellipse(hx,-55+m*1.5,5+m*3,2+m*7,0,0,TAU);pF(g,'#4a0f1e',1.8);g.save();g.beginPath();g.ellipse(hx,-55+m*1.5,5+m*3,2+m*7,0,0,TAU);g.clip();pE(g,hx,-52+m*6,4+m*2,2.4+m*3);g.fillStyle='#ff7a9a';g.fill();g.restore();
  for(const x of[-3.4,5.4]){pP(g,[x-1.4,-57+m*.6,x+1.4,-57+m*.6,x,-53.4+m*.6]);pF(g,'#fff',.8)}}
 g.beginPath();g.ellipse(-3.6,-60,7,5,0,0,TAU);g.ellipse(5.6,-60,7,5,0,0,TAU);g.fillStyle=C.be;g.fill();g.beginPath();g.ellipse(-3.6,-60,7,5,0,Math.PI*.15,Math.PI*.95);g.strokeStyle=PTO;g.lineWidth=1.5;g.stroke();g.beginPath();g.ellipse(5.6,-60,7,5,0,Math.PI*.05,Math.PI*.85);g.stroke();
 for(const [x,y] of[[-6,-60],[-3,-58],[-7,-57.4],[8,-60],[5,-58],[9,-57.4]]){pC(g,x,y,.8);g.fillStyle=ptHexA(C.sh,.6);g.fill()}
 g.beginPath();g.moveTo(-2.4,-65.4);g.quadraticCurveTo(1,-67.4,4.4,-65.4);g.quadraticCurveTo(3,-61.4,1,-61);g.quadraticCurveTo(-1,-61.4,-2.4,-65.4);g.closePath();pF(g,C.no,1.3);pE(g,0,-65,1.2,.7);g.fillStyle='#ffffffaa';g.fill();
 if(mouth<=.05&&!happy){g.beginPath();g.moveTo(1,-61);g.lineTo(1,-57.6);g.strokeStyle=PTO;g.lineWidth=1.2;g.stroke()}
 if(happy&&mouth<=.05){g.beginPath();g.moveTo(-3,-56.6);g.quadraticCurveTo(1,-52,5,-56.6);g.strokeStyle=PTO;g.lineWidth=1.5;g.stroke()}
 g.restore();
 suns(true);
 g.restore();
 /* ----- ability: sunlight bursts forward in rings and rays ----- */
 if(ab&&u>.38){const v=pSeg(u,.38,.95);g.save();g.globalCompositeOperation='lighter';
  for(let i=0;i<3;i++){const k=Math.max(0,Math.min(1,v*1.4-i*.18));if(k<=0||k>=1)continue;g.beginPath();g.arc(20+k*90,-66,14+k*46,-1,1);g.strokeStyle=ptHexA(C.fl2,(1-k)*.9);g.lineWidth=9*(1-k)+2;g.stroke();g.strokeStyle=ptHexA('#ffffff',(1-k)*.8);g.lineWidth=2.4;g.stroke()}
  g.translate(hx,hy);for(let i=0;i<12;i++){const a=-.9+i*.16,L=(60+Math.sin(i*2.3)*16)*pmEase(v*1.6)*(1-pSeg(v,.6,1));g.beginPath();g.moveTo(Math.cos(a)*30,Math.sin(a)*30);g.lineTo(Math.cos(a-.03)*(30+L),Math.sin(a-.03)*(30+L));g.lineTo(Math.cos(a+.03)*(30+L),Math.sin(a+.03)*(30+L));g.closePath();g.fillStyle=ptHexA(i%2?C.fl1:C.fl2,.55);g.fill()}
  g.restore()}
 if(gr&&u>.1&&u<.95){for(let i=0;i<6;i++){const v=((u*1.4+i/6)%1);g.globalAlpha=Math.sin(v*Math.PI);pStar4(g,hx-36+i*14+Math.sin(i*2+u*7)*5,-118-v*24,2.4+i%2,i%2?'#fff2b0':'#ffffff');g.globalAlpha=1}}};

/* ---------- signature motes, victory greetings and ability icons ---------- */
Object.assign(PSIG,{yeti:['#7ff0ff','snow'],sol:['#ffb42a','sun']});
Object.assign(PCEL,{yeti:'snow',sol:'sun'});
{const a0=petAura;petAura=function(g,id,t,front){const r=a0.apply(this,arguments);if(id!=='yeti'&&id!=='sol')return r;try{const bx=PDEF[id].box;
 for(let i=0;i<8;i++){if((i%2===0)!==front)continue;const sd=i*1.618,v=((t*(.12+(i%3)*.03)+sd)%1+1)%1,lane=((i*.37+.11)%1),a=Math.sin(v*Math.PI);if(a<.04)continue;
  let x=bx[0]-6+lane*(bx[2]+12)+Math.sin(t*1.1+sd*3)*8,y;g.save();g.globalAlpha=a;
  if(id==='yeti'){y=bx[1]+v*(bx[3]+10);pGlow(g,x,y,9,'#bff6ff',.5);pmSnow(g,x,y,3+(i%3),'#ffffff',1.1)}
  else{y=bx[1]+bx[3]-v*(bx[3]+20);pGlow(g,x,y,10,'#ffb42a',.7);pmSun(g,x,y,2.8,6,'#fff6c0','#ffb42a',t*2+sd)}g.restore()}}catch(e){}return r}}
{const c0=petCelFx;petCelFx=function(g,id,u,t,cy,R){const k=PCEL[id];if(k!=='snow'&&k!=='sun')return c0.apply(this,arguments);if(u<=0||u>=1)return;cy=cy||-50;R=R||70;const a0=1-pSeg(u,.65,1);g.save();g.translate(0,cy);
 if(k==='sun'){g.save();g.globalCompositeOperation='lighter';g.globalAlpha=a0;g.rotate(u*1.5);for(let i=0;i<16;i++){g.rotate(TAU/16);const L=R*(.4+pSeg(u,0,.5)*.9)*(i%2?.7:1);g.beginPath();g.moveTo(-3,-R*.25);g.lineTo(0,-L);g.lineTo(3,-R*.25);g.closePath();g.fillStyle=i%2?'#fff2a0':'#ffb42a';g.fill()}g.restore()}
 for(let i=0;i<14;i++){const an=i/14*TAU+i*.37,sp=.6+((i*53)%10)/14,r=R*(.25+pSeg(u,0,.6)*sp),x=Math.cos(an)*r,y=Math.sin(an)*r*.75-pSeg(u,.2,1)*R*(k==='snow'?-.3:.5);g.globalAlpha=Math.max(0,a0*(i%3?1:.8));
  if(k==='snow'){if(i%3)pmSnow(g,x,y,4+i%3,'#ffffff',1.4);else pmCrystal(g,x,y,9,4,t*2+i,'#ffffff','#5ab8ff',1)}else{pGlow(g,x,y,10,'#ffb42a',.5);pmSun(g,x,y,4+i%2*1.5,6,'#fff6c0','#ff9a2a',t*3+i)}}
 g.globalAlpha=1;g.restore()}}
Object.assign(PICO,{
 permafrost:g=>{pGlow(g,0,0,46,'#7ff0ff',.35);g.beginPath();g.moveTo(0,-40);g.lineTo(32,-24);g.lineTo(30,10);g.quadraticCurveTo(22,32,0,42);g.quadraticCurveTo(-22,32,-30,10);g.lineTo(-32,-24);g.closePath();pF(g,pLin(g,-30,-40,30,42,['#f0ffff','#7fe0ff','#2a7ad8']),4);
  g.beginPath();g.moveTo(0,-40);g.lineTo(0,42);g.moveTo(-32,-24);g.lineTo(30,10);g.moveTo(32,-24);g.lineTo(-30,10);g.strokeStyle='#ffffff55';g.lineWidth=2;g.stroke();pmSnow(g,0,0,16,'#ffffff',3.4);pmCrystal(g,24,-30,22,10,.5,'#ffffff','#5ab8ff',2.6)},
 sunburst:g=>{pGlow(g,0,0,50,'#ffb42a',.45);for(let i=0;i<12;i++){const a=i*TAU/12;g.save();g.rotate(a);g.beginPath();g.moveTo(-6,-24);g.quadraticCurveTo(0,-46,0,-46);g.quadraticCurveTo(0,-46,6,-24);g.closePath();pF(g,i%2?'#ffe07a':'#ff8a2a',3);g.restore()}
  pC(g,0,0,24);pF(g,pRad(g,0,0,24,['#fffbe0','#ffd45a','#f08a1a']),4);g.beginPath();g.ellipse(4,6,9,7,0,0,TAU);pF(g,'#4a0f1e',2.4);pE(g,4,9,5,3);g.fillStyle='#ff7a9a';g.fill();for(const x of[-2,10])pE(g,x,-8,2.6,3.4),g.fillStyle=PTO,g.fill()}});

/* ======================================================================
   STARFORGE EGG (Mythic)
   o = {t, glow, charge (0..1: the cracks blaze before a hatch), lean, noComet, noSh}
   ====================================================================== */
const SF_CR=[[-50,-58],[-38,-66],[-28,-54],[-14,-64],[-4,-50],[8,-62],[20,-52],[32,-64],[44,-56],[52,-60]];
const SF_BR=[[4,[-4,-50],[-8,-40],[0,-30],[-6,-20]],[7,[32,-64],[38,-78],[30,-90],[36,-102]],[2,[-28,-54],[-34,-44]],[5,[8,-62],[4,-74],[12,-84]],[8,[44,-56],[48,-44]]];
const SF_ST=Array.from({length:26},(_,i)=>[Math.sin(i*12.9898)*34,-112+((i*.618)%1)*104,.6+((i*7)%5)*.22,i*1.7]);
const SF_K1=[[-26,-98],[-14,-106],[-4,-96],[-10,-84],[-24,-84]],SF_K2=[[10,-36],[22,-44],[32,-34],[24,-24]];
function eggStar(g,o){const t=o.t||0,gl=o.glow||0,ch=o.charge||0,pu=.5+.5*Math.sin(t*1.8),W=46,H=124;
 /* comet orbit, back half */const cA=t*1.15,cs=Math.sin(cA),comet=front=>{if(o.noComet)return;if((cs>0)!==front)return;g.save();g.translate(0,-60);g.rotate(.24);const x=Math.cos(cA)*64,y=cs*13;
  g.beginPath();g.ellipse(0,0,64,13,0,front?0:Math.PI,front?Math.PI:TAU);g.strokeStyle=ptHexA('#9ad8ff',front?.32:.18);g.lineWidth=1.2;g.setLineDash([3,4]);g.stroke();g.setLineDash([]);
  for(let i=1;i<9;i++){const a=cA-i*.07,px=Math.cos(a)*64,py=Math.sin(a)*13;g.globalAlpha=(1-i/9)*.7;pC(g,px,py,3.2*(1-i/9)+.6);g.fillStyle='#bff0ff';g.fill()}g.globalAlpha=1;
  pGlow(g,x,y,14,'#9ad8ff',.8);pC(g,x,y,3.6);pF(g,'#ffffff',1.4,'#2a3a7a');g.restore()};
 comet(false);
 /* halo behind the egg */pGlow(g,0,-64,74,'#8a6aff',.16+gl*.25+ch*.3);
 /* shell */eggPath(g,W,H);pF(g,pLin(g,-30,-H,30,0,['#7a64e8','#3a2694','#1a0f52','#0c0828']),3.4);
 g.save();eggPath(g,W,H);g.clip();
 /* drifting nebulae */const nb=.42+gl*.3+ch*.4;pGlow(g,-14+Math.sin(t*.31)*5,-84+Math.cos(t*.27)*4,40,'#ff5c9a',.42*nb);pGlow(g,18+Math.cos(t*.23)*4,-42+Math.sin(t*.35)*5,36,'#4fc8ff',.4*nb);pGlow(g,-8+Math.sin(t*.4)*3,-22,30,'#b47aff',.42*nb);pGlow(g,10,-104,22,'#ffd45a',.18*nb);
 /* stars */for(const [x,y,s,sd] of SF_ST){const tw=.35+.65*Math.max(0,Math.sin(t*2.2+sd));g.globalAlpha=.35+tw*.65;if(s>1.2)pStar4(g,x,y,s*1.6*tw+.6,'#ffffff');else{pC(g,x,y,s*.7);g.fillStyle='#ffffff';g.fill()}}g.globalAlpha=1;
 /* constellations */for(const K of[SF_K1,SF_K2]){g.beginPath();K.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.closePath();g.strokeStyle=ptHexA('#ffd45a',.42+.2*pu);g.lineWidth=.9;g.stroke();K.forEach((p,i)=>{const tw=.6+.4*Math.sin(t*2.6+i*1.9+p[0]);pGlow(g,p[0],p[1],5,'#ffd45a',.35*tw);pStar4(g,p[0],p[1],2.4*tw+.8,'#fff6d8')})}
 /* kintsugi cracks: rose light inside, gold seams outside */
 const crk=()=>{g.beginPath();g.moveTo(SF_CR[0][0],SF_CR[0][1]);for(const p of SF_CR)g.lineTo(p[0],p[1]);const nb2=Math.min(1,.5+ch*1.2);for(const b of SF_BR){const p=SF_CR[b[0]];g.moveTo(p[0],p[1]);const m=Math.max(1,Math.round((b.length-1)*nb2));for(let j=1;j<=m;j++)g.lineTo(b[j][0],b[j][1])}};
 g.save();g.globalCompositeOperation='lighter';crk();g.strokeStyle=ptHexA('#ff6fa8',.22+.22*pu+gl*.3+ch*.5);g.lineWidth=9+ch*10;g.stroke();crk();g.strokeStyle=ptHexA('#ffb0d0',.25+.2*pu+ch*.6);g.lineWidth=4.5+ch*4;g.stroke();g.restore();
 crk();g.strokeStyle=PTO;g.lineWidth=4.4;g.stroke();crk();g.strokeStyle=pLin(g,-50,-90,50,-20,['#fff2b0','#ffd45a','#e0a020','#ffe48a']);g.lineWidth=2.5;g.stroke();crk();g.strokeStyle=ch>.4?'#ffffff':'#fff8e0aa';g.lineWidth=.8+ch*1.2;g.stroke();
 /* a spark of light travels along the gold seams */{const L=[];let tot=0;for(let i=1;i<SF_CR.length;i++){const d=Math.hypot(SF_CR[i][0]-SF_CR[i-1][0],SF_CR[i][1]-SF_CR[i-1][1]);L.push(d);tot+=d}const ph=(t*.32)%1.6;if(ph<1){let d=ph*tot,i=0;while(i<L.length-1&&d>L[i]){d-=L[i];i++}const k=d/L[i],x=SF_CR[i][0]+(SF_CR[i+1][0]-SF_CR[i][0])*k,y=SF_CR[i][1]+(SF_CR[i+1][1]-SF_CR[i][1])*k,a=Math.sin(ph*Math.PI);pGlow(g,x,y,12,'#ffe0f0',.7*a);pC(g,x,y,1.6*a+.2);g.fillStyle='#ffffff';g.fill()}}
 /* now and then a shooting star streaks across the shell */{const ph=((t+.7)%4.6)/.55;if(ph<1){const x0=-40+ph*84,y0=-108+ph*30;g.save();g.globalCompositeOperation='lighter';const q=g.createLinearGradient(x0-22,y0-8,x0,y0);q.addColorStop(0,'#ffffff00');q.addColorStop(1,'#ffffffcc');g.strokeStyle=q;g.lineWidth=1.6;g.beginPath();g.moveTo(x0-22,y0-8);g.lineTo(x0,y0);g.stroke();g.restore();pStar4(g,x0,y0,2.6,'#ffffff')}}
 /* gold belt with gems */g.beginPath();g.moveTo(-46,-26);g.quadraticCurveTo(0,-4,46,-26);g.strokeStyle=PTO;g.lineWidth=7.4;g.stroke();g.strokeStyle=pLin(g,-46,0,46,0,['#e0a020','#fff2b0','#ffd45a','#c8861a']);g.lineWidth=4.6;g.stroke();g.strokeStyle='#fff6d080';g.lineWidth=1;g.beginPath();g.moveTo(-40,-25.4);g.quadraticCurveTo(0,-5.4,40,-25.4);g.stroke();
 for(let i=0;i<7;i++){const k=.14+i*.12,m=1-k,x=m*m*-46+2*m*k*0+k*k*46,y=m*m*-26+2*m*k*-4+k*k*-26;pC(g,x,y,i===3?2.8:1.9);pF(g,i===3?'#ff4f8b':i%2?'#5ad8ff':'#fff2b0',1.1)}
 g.restore();
 eggFinish(g,W,H,t,'#c8b8ff','#ffffff30');
 /* gold cap with filigree */g.beginPath();g.moveTo(-17,-118.6);g.bezierCurveTo(-11,-127,11,-127,17,-118.6);g.bezierCurveTo(9,-114,-9,-114,-17,-118.6);g.closePath();pF(g,pLin(g,0,-127,0,-114,['#fff2b0','#ffd45a','#b8801a']),2);
 g.beginPath();g.moveTo(-12,-120.4);g.bezierCurveTo(-7,-125,7,-125,12,-120.4);g.strokeStyle='#fff8d0b0';g.lineWidth=1;g.stroke();for(const [x,c] of[[-10,'#5ad8ff'],[0,'#ff4f8b'],[10,'#5ad8ff']]){pC(g,x,-118.6+Math.abs(x)*.05,x?1.5:2);pF(g,c,.9)}
 /* floating star finial: bobs, turns now and then, shines */const fy=-138+Math.sin(t*1.6)*2.2,spin=((t%6)<.8)?Math.cos((t%6)/.8*TAU):1;g.save();g.translate(0,fy);pGlow(g,0,0,24+gl*14+ch*20,'#ffd45a',.5+.2*pu+ch*.4);g.scale(Math.max(.18,Math.abs(spin)),1);
 pStar5(g,0,0,11,pLin(g,0,-11,0,11,['#fffbe0','#ffd45a','#e0961a']),2.2);pC(g,0,0,3);pF(g,'#ff4f8b',1.2);pC(g,-.8,-.8,1);g.fillStyle='#ffffffcc';g.fill();g.restore();
 const tw=(t*.8)%3.2;if(tw<.5)pStar4(g,7,fy-7,2+Math.sin(tw/.5*Math.PI)*5,'#ffffff');
 const tw2=((t+1.4)*.7)%3.6;if(tw2<.5)pStar4(g,-20,-72,2+Math.sin(tw2/.5*Math.PI)*5,'#ffffff');
 comet(true)}
{const d0=eggDraw;eggDraw=function(g,kind,o){if(kind!=='m')return d0.apply(this,arguments);g.save();g.lineJoin='round';g.lineCap='round';o=o||{};
 if(!o.noSh){const q=g.createRadialGradient(0,2,0,0,2,52);q.addColorStop(0,'#00000080');q.addColorStop(1,'#00000000');g.fillStyle=q;g.beginPath();g.ellipse(0,2,50,10,0,0,TAU);g.fill()}
 g.rotate(o.lean||0);eggStar(g,o);g.restore()}}
{const f0=eggFit;eggFit=function(cv,kind,o){if(kind!=='m')return f0.apply(this,arguments);const q=Object.assign({},o||{});q.zoom=(q.zoom||1)*.88;return f0.call(this,cv,kind,q)}}
/* ===== MYTHIC COMPANIONS: Companion Hall =====
   A Mythic filter and card style in the roster, a third egg in the Eggs tab (Starforge: coins only, 50,000),
   a savings meter so players can see how close they are, and a teaser for undiscovered Mythics. */
PEGGD.m={tag:'Forged in a fallen star and mended with gold.',
 lore:'Starforge eggs are the rarest treasure in the hall, and they are never found on the Adventure Trail. Save up 50,000 coins to buy one. Inside sleeps one of the two Mythic companions: Glacierhorn or Solmane.'};
const ptRank=id=>({m:2,l:1,r:0})[PDEF[id].r]||0;

/* ---------- roster: sorting knows Mythic is the highest rarity ---------- */
function ptSorted(L){const k=ptSortKey(),o=id=>petOwned(id),b=id=>(P.pets[id]&&P.pets[id].b)||0,r=ptRank,ix=id=>PIDS.indexOf(id);
 const own=L.filter(o),un=L.filter(id=>!o(id));let f;
 if(k==='rec')f=(a,c)=>((P.petNew[c]?1:0)-(P.petNew[a]?1:0))||((P.pet===c)-(P.pet===a))||(b(c)-b(a))||(r(c)-r(a))||(ix(a)-ix(c));
 else if(k==='rar')f=(a,c)=>(r(c)-r(a))||(ix(a)-ix(c));
 else if(k==='bhi')f=(a,c)=>(b(c)-b(a))||(ix(a)-ix(c));
 else if(k==='blo')f=(a,c)=>(b(a)-b(c))||(ix(a)-ix(c));
 else if(k==='az')f=(a,c)=>petName(a).localeCompare(petName(c));
 else if(k==='new')f=(a,c)=>(((P.pets[c]||{}).t||0)-((P.pets[a]||{}).t||0))||(ix(a)-ix(c));
 if(k==='col')return L;
 return[...own.sort(f),...un.sort((a,c)=>(r(c)-r(a))||(ix(a)-ix(c)))]}
{const h0=ptPetsHTML;ptPetsHTML=function(){let h=h0.apply(this,arguments);const f=PTX.filt;
 h=h.replace(/(<button class="[^"]*" data-f="l"[^>]*>)Legendary(<\/button>)/,`$1Legendary$2<button class="${f==='m'?'on':''} ptf-m" data-f="m" aria-pressed="${f==='m'}">Mythic</button>`);return h}}
{const d0=ptDetHTML;ptDetHTML=function(id){let h=d0.apply(this,arguments);const D=PDEF[id];if(D&&D.r==='m'){
  h=h.replace('<div class="ptdr">','<div class="ptdr ptdr-m">');
  if(!petOwned(id))h=h.replace(/<p class="ptlk">[\s\S]*?<\/p>/,`<p class="ptlk ptlk-m"><b>A Mythic companion.</b> Hatch a <em>Starforge egg</em> to discover it. Starforge eggs cost <b>${PEGG_PRICE.m.toLocaleString()} coins</b> in the Hatchery and never hatch a repeat.</p>`).replace(`${PTICO.egg} See my eggs`,`${PTICO.egg} See the Starforge Egg`)}
 return h}}
{const b0=ptPetsBind;ptPetsBind=function(){const r=b0.apply(this,arguments);try{const d=$('ptdet');if(d&&!d._myth){d._myth=1;d.addEventListener('click',e=>{if(e.target.closest('#ptto')&&PDEF[PTX.sel])PTX.egg=PDEF[PTX.sel].r},true)}
 /* undiscovered Mythic cards shimmer faintly so they catch the eye */
 }catch(e){}return r}}

/* ---------- EGGS: three eggs; Starforge is bought with coins only ---------- */
function ptEggsHTML(){const k=PTX.egg=['r','l','m'].includes(PTX.egg)?PTX.egg:'r',E=PRAR[k],n=P.eggs[k]|0,pool=petPool(k),full=!pool.length,pc=pool.length?Math.round(1000/pool.length)/10:0,pr=PEGG_PRICE[k],need=pr-P.gold,nx=petNextEgg(),my=k==='m';
 const card=r=>{const L=petList(r),o=L.filter(petOwned).length,m=P.eggs[r]|0;return `<button class="phx-c${r===k?' on':''} phx-${r}" data-egg="${r}" role="radio" aria-checked="${r===k}" aria-label="${PRAR[r].egg} egg, ${m} owned, ${o} of ${L.length} discovered"><canvas width="96" height="110" data-et="${r}"></canvas><div class="phx-ci"><b>${PRAR[r].egg}</b>${ptBadge(r,1)}<span class="phx-pg"><span class="ptbar phx-b${r}"><i style="width:${o/L.length*100}%"></i></span><small>${o}/${L.length}</small></span></div><em class="phx-cnt${m?'':' z'}">×${m}</em>${r==='m'&&!m?'<i class="phx-cnew">Coins only</i>':''}</button>`};
 const act=full?`<div class="phx-full"><p>You own every ${E.n} companion. Each ${E.egg} egg now becomes <b>50 bond XP</b>.</p><button class="ptgo b" id="phxcv2" ${n?'':'disabled'}>${n?'Choose a companion for 50 bond XP':'No eggs to convert'}</button></div>`
  :n?`<button class="ptgo phx-hatch${my?' phx-hm':''}" id="phxht">${PTICO.egg} Hatch ${E.egg}</button>`:`<button class="ptgo off phx-hatch" disabled>${PTICO.egg} No eggs to hatch</button><p class="phx-why">${my?`Buy one below for ${pr.toLocaleString()} coins.`:'Earn eggs on the Adventure Trail, or buy one below.'}</p>`;
 const save=Math.min(1,P.gold/pr),earn=my?`<div class="phx-row phx-save${save>=1?' ok':''}"><span class="phx-svi">${PTICO.coin}</span><div class="phx-rt"><b>${save>=1?'You can afford one!':'Coins only'}</b><small>${save>=1?'Starforge eggs are never found on the Trail.':`${P.gold.toLocaleString()} / ${pr.toLocaleString()} saved · never found on the Trail`}</small><span class="ptbar phx-svb"><i style="width:${save*100}%"></i></span></div></div>`
  :`<button class="phx-row phx-earn2" data-pt2="Trail">${PTICO.trail}<div class="phx-rt"><b>Earn one free</b><small>${nx?`${nx.left} adventure${nx.left===1?'':'s'} to a ${PRAR[nx.k].egg} egg`:'Play adventures to earn eggs'}</small></div><span class="phx-dots" aria-hidden="true">${nx?[0,1,2,3,4].map(i=>`<i class="${i<5-nx.left?'on':''}"></i>`).join(''):''}</span><i class="phx-chev">›</i></button>`;
 return `<div class="phx phx2 phx3 phx-k${k}"><section class="ptp phx-inv"><div class="ptph"><h3>Your Eggs</h3></div><div class="phx-cards" role="radiogroup" aria-label="Egg type">${card('r')}${card('l')}${card('m')}</div>
</section>
  <section class="phx-show"><canvas id="phxcv" aria-hidden="true"></canvas><div class="phx-tt"><h3>${E.egg} Egg</h3>${ptBadge(k)}</div>
   <div class="phx-pool"><p>${full?`Every ${E.n} companion discovered`:`<b>${pool.length}</b> undiscovered ${E.n} companion${pool.length===1?'':'s'} <em>(${pool.length===1?'guaranteed':pc+'% each'})</em>`}</p><div class="phx-pl">${petList(k).map(id=>`<span class="${petOwned(id)?'own':''}" title="${petOwned(id)?esc(PDEF[id].n)+' (owned)':'Undiscovered'}"><canvas width="56" height="48" data-pl="${id}"></canvas></span>`).join('')}</div><button class="ptsoft phx-vc" id="phxvc">View companions ›</button></div></section>
  <section class="ptp phx-act"><div class="ptph"><h3>Hatchery</h3></div><div class="phx-big"><b id="phxn">${n}</b><span>${E.egg} egg${n===1?'':'s'}<small>ready to hatch</small></span></div>
   ${act}
   <div class="phx-or"><i></i><span>more eggs</span><i></i></div>
   <div class="phx-row"><canvas width="64" height="72" id="phxme"></canvas><div class="phx-rt"><b>Buy one</b><small>${PTICO.coin}${pr.toLocaleString()} gold</small></div>
    <button class="ptgo b phx-buy${full||need>0?' off':''}${my&&!full&&need<=0?' phx-buym':''}" id="phxby" ${full||need>0?'disabled':''}>${full?'Collection complete':need>0?`Need ${need.toLocaleString()} more gold`:'Buy'}</button></div>
   ${earn}</section></div>`}
{const b0=ptEggsBind;ptEggsBind=function(){const r=b0.apply(this,arguments);try{
 /* arrow keys cycle through all three eggs */
 const ord=['r','l','m'];ov.querySelectorAll('.phx-c').forEach(b=>b.onkeydown=e=>{const d=e.key==='ArrowDown'||e.key==='ArrowRight'?1:e.key==='ArrowUp'||e.key==='ArrowLeft'?-1:0;if(!d)return;e.preventDefault();const i=ord.indexOf(b.dataset.egg),o=ov.querySelector(`.phx-c[data-egg="${ord[(i+d+3)%3]}"]`);if(o)o.click();setTimeout(()=>{const f=ov.querySelector('.phx-c.on');if(f)f.focus()},20)});
 const sv=ov.querySelector('.phx-svb i');if(sv&&!ptRM())sv.animate([{transform:'scaleX(0)'},{transform:'scaleX(1)'}],{duration:900,easing:'cubic-bezier(.2,1,.3,1)'});
 }catch(e){}return r}}

/* ---------- the egg stage: colour follows the egg; the Starforge egg sits under its own little sky ---------- */
const PT_EAC={r:[85,181,255],l:[255,194,58],m:[255,111,174]};
function ptHatchStage(cv){const w=520,h=560,k=PTK(),g=cv.getContext('2d'),bg=ptHatchBG(w,h);cv.width=w*k;cv.height=h*k;const fr=PTX.eggFrom;PTX.eggFrom=null;
 const S0={k:PTX.egg,from:fr&&fr!==PTX.egg?fr:null,t0:ptNow(),ac:(PT_EAC[fr||PTX.egg]||PT_EAC.r).slice()};
 const FX=[],R=[],TX=[];let tap=null,lt=ptNow(),spawn=0,pulse=0,sky=0;
 PTX.eggSwap=kk=>{if(kk===S0.k)return;S0.from=S0.k;S0.k=kk;S0.t0=ptNow()};
 const ex0=w/2,ey0=h*.6-12,ES=1.3;
 const lantern=(x,y,t)=>{const f=.82+.18*Math.sin(t*7+x)+.08*Math.sin(t*13);pGlow(g,x,y,90*f,'#ffb04a',.28);g.save();g.translate(x,y);g.beginPath();g.moveTo(-14,-18);g.lineTo(0,-30);g.lineTo(14,-18);g.closePath();g.fillStyle='#3a2410';g.fill();g.beginPath();g.roundRect(-13,-18,26,34,4);g.fillStyle=ptHex('#ffcf6a',.85+.15*f);g.fill();g.strokeStyle='#3a2410';g.lineWidth=3;g.stroke();g.beginPath();g.moveTo(0,-18);g.lineTo(0,16);g.moveTo(-13,0);g.lineTo(13,0);g.lineWidth=2;g.stroke();g.beginPath();g.roundRect(-15,16,30,5,2);g.fillStyle='#3a2410';g.fill();g.restore()};
 const ready=()=>(P.eggs[S0.k]|0)>0,acOf=kk=>kk==='l'?'#ffc23a':kk==='m'?'#ff6fae':'#5ff0ff';
 cv.style.cursor='pointer';
 cv.onclick=e=>{const r=cv.getBoundingClientRect(),x=(e.clientX-r.left)*w/r.width,y=(e.clientY-r.top)*h/r.height;if(Math.abs(x-ex0)>90||y<ey0-ES*160||y>ey0+20)return;
  const rd=ready(),ac=acOf(S0.k),my=S0.k==='m';tap={t:ptNow(),s:rd?1:.55};
  ptBurst(FX,ex0,ey0-90,rd?(my?24:16):7,my?[ac,'#ffffff','#ffd45a','#5ad8ff']:[ac,'#ffffff'],{v:rd?220:130,g:120,l:.9,s:6});R.push({x:ex0,y:ey0+4,t:0,c:ac,max:120,w:6,d:.7,fl:.24});
  const msg=rd?(my?['The stars inside are stirring…','A heartbeat, warm as a star!','It hummed like a comet!','Something mythic wants out!']:['Something stirs inside…','It wiggled back!','Someone wants to meet you!','Tap Hatch to say hello!'])[Math.random()*4|0]:my?'Save 50,000 coins to buy one':`Get a ${PRAR[S0.k].egg} egg to hatch one`;
  TX.length=0;TX.push({s:msg,x:ex0,y:ey0-ES*150+22,a:0,c:rd?'#fff2c0':'#c4badf',sz:rd?22:18,d:1.6});
  try{if(rd){beep(700,.05,'sine',.16);setTimeout(()=>beep(1040,.06,'sine',.14),70);setTimeout(()=>beep(1320,.05,'sine',.1),150);if(my)setTimeout(()=>beep(1760,.08,'sine',.08),240)}else beep(300,.08,'triangle',.14)}catch(x){}};
 return t0=>{const rm=ptRM(),t=rm?1:t0,now=ptNow(),dt=Math.min(.05,Math.max(0,now-lt));lt=now;g.setTransform(k,0,0,k,0,0);g.drawImage(bg,0,0,w,h);
  const tgt=PT_EAC[S0.k]||PT_EAC.r;for(let i=0;i<3;i++)S0.ac[i]+=(tgt[i]-S0.ac[i])*(rm?1:.12);const ac='#'+S0.ac.map(v=>Math.round(v).toString(16).padStart(2,'0')).join('');const rd=ready();
  sky+=((S0.k==='m'?1:0)-sky)*(rm?1:.08);
  lantern(w*.2,h*.2+6,t);lantern(w*.8,h*.2+6,t+1.4);for(const x of[w*.18,w*.82]){const f=rm?0:Math.sin(t*9+x)*1.2;pGlow(g,x,h*.56-8,22,'#ffb04a',.4);g.fillStyle='#ffcf6a';g.beginPath();g.ellipse(x+f*.4,h*.56-7,3.4,7,0,0,TAU);g.fill()}
  /* the Starforge sky: a slow nebula, twinkling stars and a turning constellation ring on the cushion */
  if(sky>.02){g.save();g.globalAlpha=sky;pGlow(g,w/2-60+Math.sin(t*.2)*20,h*.3,150,'#ff5c9a',.16);pGlow(g,w/2+70+Math.cos(t*.17)*20,h*.38,140,'#4fc8ff',.14);pGlow(g,w/2,h*.22,110,'#b47aff',.14);
   for(let i=0;i<22;i++){const x=w*(.12+((i*.618)%1)*.76),y=h*(.08+((i*.37)%1)*.5),tw=.3+.7*Math.max(0,Math.sin(t*1.8+i*2.1));g.globalAlpha=sky*tw;pStar4(g,x,y,1.4+tw*2.2,'#ffffff')}g.globalAlpha=sky;
   g.save();g.translate(ex0,ey0+6);g.scale(1,.24);g.rotate(t*.18);g.strokeStyle=ptHexA('#ffd45a',.45);g.lineWidth=3;g.beginPath();g.arc(0,0,150,0,TAU);g.stroke();g.setLineDash([10,14]);g.strokeStyle=ptHexA('#ff6fae',.5);g.beginPath();g.arc(0,0,128,0,TAU);g.stroke();g.setLineDash([]);
   for(let i=0;i<8;i++){const a=i*TAU/8;pStar4(g,Math.cos(a)*150,Math.sin(a)*150,7,'#fff2c0')}g.restore();g.restore()}
  g.save();g.globalCompositeOperation='lighter';let q=g.createLinearGradient(0,0,0,h*.8);q.addColorStop(0,ptHex(ac,0));q.addColorStop(1,ptHex(ac,rd?.2:.12));g.fillStyle=q;g.beginPath();g.moveTo(w/2-40,0);g.lineTo(w/2+40,0);g.lineTo(w/2+120,h*.62);g.lineTo(w/2-120,h*.62);g.closePath();g.fill();g.restore();
  pGlow(g,w/2,h*.44,170,ac,(rd?.36:.24)+.07*Math.sin(t*1.4));
  if(!rm)for(let i=0;i<6;i++){const u=((t*.08+i/6)%1),x=w/2+Math.sin(i*2.3+t*.4)*120*(.6+u*.4),y=h*.58-u*h*.5,a=Math.sin(u*Math.PI)*.6;g.save();g.translate(x,y);g.globalAlpha=a;g.fillStyle=ac;g.beginPath();g.ellipse(0,2,4,3.4,0,0,TAU);g.fill();for(const [dx,dy] of[[-4,-3],[0,-5],[4,-3]]){g.beginPath();g.ellipse(dx,dy,1.5,1.9,0,0,TAU);g.fill()}g.restore()}
  if(rd&&!rm){pulse+=dt;if(pulse>1.6){pulse=0;R.push({x:ex0,y:ey0+6,t:0,c:ac,max:110,r0:30,w:4,d:1.3,fl:.22})}
   spawn+=dt*5;while(spawn>1){spawn--;const a=Math.random()*TAU,rr=40+Math.random()*30;FX.push({x:ex0+Math.cos(a)*rr,y:ey0-80+Math.sin(a)*rr*1.3,vx:(Math.random()-.5)*20,vy:-30-Math.random()*40,l:1.2,l0:1.2,c:Math.random()<.4?'#ffffff':S0.k==='m'&&Math.random()<.5?'#ffd45a':ac,s:3+Math.random()*3,k:Math.random()<.5?'star':'glow',g:-10,dr:.6})}}
  ptRings(g,R,dt);
  const lean=kk=>{let L=0,hy=0;if(rm)return[0,0];if(kk===S0.k&&rd){const ph=t%3.4;if(ph<.9){const v=ph/.9;L+=Math.sin(v*Math.PI*4)*(1-v)*.1;hy=-Math.sin(Math.min(1,v*2.2)*Math.PI)*5}}
   if(tap&&kk===S0.k){const v=(now-tap.t)/.9;if(v>=1)tap=null;else{L+=Math.sin(v*Math.PI*6)*(1-v)*.17*tap.s;hy-=Math.sin(Math.min(1,v*3)*Math.PI)*9*tap.s}}return[L,hy]};
  const eggAt=(kk,a,dy)=>{if(a<=0)return;const my=kk==='m',bob=rm?0:Math.sin(t*1.2)*3+(my?Math.sin(t*.9)*3-6:0),[L,hy]=lean(kk),gl=kk===S0.k&&rd?.45+.3*Math.sin(t*2.4):.18+.1*Math.sin(t*1.6),es=my?ES*.96:ES;g.save();g.globalAlpha=a;g.translate(ex0,ey0+bob+dy+hy);g.scale(es,es);
   if(L||my){g.save();g.scale(1/es,1/es);g.fillStyle='#00000055';g.beginPath();g.ellipse(0,-hy-(my?bob*.0:0)+(my?6:0),my?40:46,my?7:8,0,0,TAU);g.fill();g.restore()}
   eggDraw(g,kk,{t,glow:gl,lean:L,noSh:L||my?1:0});g.restore()};
  const v=S0.from&&!rm?Math.min(1,(now-S0.t0)/.32):1;if(v<1){eggAt(S0.from,1-v,0);eggAt(S0.k,v,(1-pS(v))*-24)}else{S0.from=null;eggAt(S0.k,1,0)}
  ptFxStep(g,FX,dt);ptTexts(g,TX,dt)}}

/* ---------- styles ---------- */
{const st=document.createElement('style');st.textContent=`
.ptbg-m{color:#fff;background:linear-gradient(90deg,#ff4f8b,#b04aff 55%,#4fc8ff);border:1.5px solid #ffd6ea;text-shadow:0 1px 0 #3a0a3a99;box-shadow:0 0 12px #ff4f8b55}
.ptfl>button.ptf-m.on{background:linear-gradient(180deg,#ff6fae,#9a3ad8)!important;border-color:#ffd6ea!important;color:#fff!important}
.ptfl{gap:5px!important}.ptsob span{font-size:0!important}.ptsob span b{font-size:13.5px}.ptfl>button{padding:6px 10px!important}.ptsob{padding:6px 10px!important;gap:6px!important}
.ptc-m{background:radial-gradient(circle at 50% 30%,#4a1e5a,#1a0a2e 70%)!important;border-color:#ff6fae!important;overflow:hidden}
.ptc-m:not(.unk){box-shadow:inset 0 0 22px #ff4f8b33,0 0 0 1px #ff6fae55}
.ptc-m:not(.unk):hover{box-shadow:0 8px 18px #000a,0 0 22px #ff6fae77!important}
.ptc-m::before{content:"";position:absolute;inset:0;border-radius:inherit;padding:2px;background:linear-gradient(135deg,#ff4f8b,#b04aff,#4fc8ff,#ffd45a);-webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask-composite:exclude;pointer-events:none;opacity:.9}
.ptc-m.unk{background:radial-gradient(circle at 50% 30%,#2e1840,#120a24 70%)!important}.ptc-m.unk::before{opacity:.45}
.ptc-m::after{content:"";position:absolute;top:-20%;bottom:-20%;left:0;width:40%;background:linear-gradient(100deg,#fff0 0%,#ffd0ec44 45%,#c8f0ff44 55%,#fff0 100%);transform:translateX(-160%) skewX(-12deg);animation:ptsheen 4.2s ease-in-out infinite;pointer-events:none}
.ptc-m.unk::after{animation-duration:6s;opacity:.6}.ptc-m:nth-of-type(2n)::after{animation-delay:1.3s}
.ptc-m.unk .ptq{color:#ffb0d8;text-shadow:0 0 10px #ff4f8b}
.ptlk-m{padding:12px 14px;border-radius:14px;background:linear-gradient(180deg,#2a1240,#140a26);border:1px solid #6a2e7a;line-height:1.5}.ptlk-m b{color:#fff}.ptlk-m em{font-style:normal;font-weight:800;color:#ffb0d8}
.ptdr-m em{text-shadow:0 0 10px currentColor}
/* eggs: three compact horizontal cards */
.phx3 .phx-cards{gap:10px!important}
.phx3 .phx-c{flex:1;flex-direction:row!important;justify-content:flex-start!important;gap:12px!important;padding:8px 14px!important;text-align:left!important}
.phx3 .phx-c canvas{width:74px!important;height:85px!important;flex:none}
.phx3 .phx-ci{align-items:flex-start!important}.phx3 .phx-ci>*{align-self:flex-start!important}.phx3 .phx-pg{align-self:stretch!important}.phx3 .phx-ci b{font-size:25px!important}
.phx3 .phx-cnt{top:8px!important;right:12px!important}
.phx3 .phx-c.phx-m{background:radial-gradient(circle at 30% 40%,#3a1a5a,#140a2a 75%);border-color:#8a3a8a}
.phx3 .phx-c.phx-m.on{border-color:#ff6fae!important;box-shadow:0 0 0 1px #ff6fae66,0 0 26px #ff4f8b44}
.phx-buym{background:linear-gradient(180deg,#ff8ac0,#c03a8a)!important;box-shadow:0 3px 0 #5a0a3a!important;color:#fff!important}
.phx-cnew{position:absolute;right:12px;bottom:9px;font:800 10.5px var(--ui);font-style:normal;letter-spacing:.06em;text-transform:uppercase;color:#ffd0ea;padding:2px 8px;border-radius:8px;background:#5a1a4a;border:1px solid #ff6fae66}
.phx-save{flex-direction:row;align-items:center;background:linear-gradient(180deg,#22142a,#140a1e)!important;border-color:#6a4a2a!important}
.phx-save.ok{border-color:#ffd45a!important;box-shadow:0 0 18px #ffd45a33}
.phx-svi{display:grid;place-items:center;width:30px;height:30px;flex:none;border-radius:12px;background:#3a2a10;padding:7px}.phx-svi svg{width:22px;height:22px}
.phx-svb{display:block;height:8px;margin:6px 0 0;border-radius:5px;background:#2a1e18;overflow:hidden}.phx-svb i{display:block;height:100%;border-radius:5px;background:linear-gradient(90deg,#e0a020,#ffd45a,#fff2b0);transform-origin:0 50%}
.phx-hm{background:linear-gradient(180deg,#ffe48a,#ff8ac0 60%,#c050d0)!important;color:#2a0a2a!important;box-shadow:0 4px 0 #6a1a5a!important}
.phx-km .phx-tt h3{color:#ffd0ea;text-shadow:0 3px 0 #3a0a3a,0 0 22px #ff4f8b88}
.phx-ab-m{border-color:#7a2e7a}.phx-ab-m .phx-abh i{color:#ff6fae}
@media (prefers-reduced-motion:reduce){.ptc-m::after{animation:none!important}}
`;document.head.appendChild(st)}
/* progress bars for the Mythic egg card use the Mythic gradient */
{const st=document.createElement('style');st.textContent=`.phx-bm i,.ptbar.phx-bm i{background:linear-gradient(90deg,#ff4f8b,#b04aff,#4fc8ff)!important}`;document.head.appendChild(st)}
/* ===== MYTHIC HATCH: the Starforge cinematic (about 9 s, skippable at once) =====
   Night falls and a constellation draws itself across the sky. The egg arrives as a falling star and hovers over a golden dais.
   Three astrolabe rings assemble around it while a sigil lights up underfoot. The stars of the whole sky stream into the egg
   over three heartbeats; everything implodes into one point of light, then a supernova shatters the shell. The Mythic companion
   descends in a pillar of light, lands, greets you and shows off its power. The result is committed (owned and saved) before this plays. */
PHS.roar=(A,at)=>{phNoise(A,at,.9,.2,{ty:'lowpass',f:320,f2:1100,swell:1});phTone(A,at,98,.95,.07,{ty:'sawtooth',f2:150,fd:.6,att:.25});phTone(A,at+.05,196,.8,.04,{ty:'triangle',f2:262,fd:.5,att:.2})};
PHS.chime=(A,at)=>{[1568,2093,2637,3136,2349].forEach((f,i)=>phTone(A,at+i*.07,f,.9,.03,{echo:1}))};
PHS.drone=(A,at,d)=>{phTone(A,at,55,d,.06,{att:d*.5});phTone(A,at,82.4,d,.035,{att:d*.6,det:5});phNoise(A,at,d,.05,{ty:'lowpass',f:200,swell:1})};
PHS.suck=(A,at,d)=>{phNoise(A,at,d,.16,{f:3400,f2:260,q:.9,swell:1});phTone(A,at,880,d,.05,{f2:110,fd:d,att:d*.8})};

const PHM={},PHM_FY=505;
function phMythBG(){if(PHM.bg)return PHM.bg;const W0=1600,H0=900,c=document.createElement('canvas');c.width=W0;c.height=H0;const b=c.getContext('2d'),cx=W0/2,fy=PHM_FY;
 let q=b.createLinearGradient(0,0,0,H0);q.addColorStop(0,'#0a0624');q.addColorStop(.55,'#170c3e');q.addColorStop(1,'#05030c');b.fillStyle=q;b.fillRect(0,0,W0,H0);
 b.globalCompositeOperation='lighter';for(const [x,y,r,col,a] of[[470,250,560,'#ff4f8b',.2],[1170,300,520,'#3fb8ff',.17],[800,170,640,'#8a4aff',.2],[260,620,380,'#b04aff',.1],[1380,640,360,'#ff6fae',.08]]){const g2=b.createRadialGradient(x,y,0,x,y,r);g2.addColorStop(0,ptHexA(col,a));g2.addColorStop(.5,ptHexA(col,a*.4));g2.addColorStop(1,ptHexA(col,0));b.fillStyle=g2;b.fillRect(x-r,y-r,r*2,r*2)}
 /* a faint milky band */for(let i=0;i<900;i++){const u=Math.random(),x=u*W0,y=120+u*260+(Math.random()-.5)*(140+Math.random()*120);b.fillStyle=ptHexA('#ffffff',Math.random()*.25);b.fillRect(x,y,1.2,1.2)}
 for(let i=0;i<340;i++){const x=Math.random()*W0,y=Math.random()*(fy+40),s=Math.random(),r=.5+s*s*1.8;b.fillStyle=ptHexA(['#ffffff','#ffe6f4','#e0f4ff','#fff6d8'][i%4],.35+Math.random()*.6);b.beginPath();b.arc(x,y,r,0,TAU);b.fill();if(s>.93){pGlow(b,x,y,10,'#ffffff',.35);pStar4(b,x,y,6,'#ffffffaa')}}
 b.globalCompositeOperation='source-over';
 /* ground fading into the dark, and a golden astrolabe dais */q=b.createLinearGradient(0,fy-40,0,H0);q.addColorStop(0,'#120a2e00');q.addColorStop(.25,'#0e0826');q.addColorStop(1,'#040210');b.fillStyle=q;b.fillRect(0,fy-40,W0,H0);
 for(const [rx,ry,dy,c0,c1] of[[360,78,36,'#1c1440','#0a0620'],[320,66,12,'#33285e','#17113a'],[280,56,-4,'#463a82','#231a52']]){q=b.createLinearGradient(0,fy+dy-ry,0,fy+dy+ry+24);q.addColorStop(0,c0);q.addColorStop(1,c1);b.fillStyle=q;b.beginPath();b.ellipse(cx,fy+dy+20,rx,ry,0,0,Math.PI);b.lineTo(cx-rx,fy+dy);b.ellipse(cx,fy+dy,rx,ry,0,Math.PI,0);b.closePath();b.fill();b.beginPath();b.ellipse(cx,fy+dy,rx,ry,0,0,TAU);b.fillStyle=c0;b.fill();b.strokeStyle=dy===-4?'#c8963a':'#5a4a8a';b.lineWidth=dy===-4?3:2;b.stroke()}
 b.save();b.translate(cx,fy-4);b.scale(1,.2);b.strokeStyle='#c8963a66';b.lineWidth=3;for(const r of[230,180]){b.beginPath();b.arc(0,0,r,0,TAU);b.stroke()}for(let i=0;i<24;i++){const a=i*TAU/24;b.beginPath();b.moveTo(Math.cos(a)*180,Math.sin(a)*180);b.lineTo(Math.cos(a)*(i%2?205:218),Math.sin(a)*(i%2?205:218));b.stroke()}b.restore();
 q=b.createRadialGradient(cx,H0*.48,H0*.32,cx,H0*.48,W0*.72);q.addColorStop(0,'#00000000');q.addColorStop(1,'#000000c8');b.fillStyle=q;b.fillRect(0,0,W0,H0);
 return PHM.bg=c}
function ptMythHatch(id,k,opt){opt=opt||{};const wrapEl=$('wrap')||document.body;let el=$('pthx');if(el){if(el._stop)el._stop();el.remove()}el=document.createElement('div');el.id='pthx';el.className='pthx pthx-m';
 const D=PDEF[id],rm=ptRM()||opt.reveal,yeti=id==='yeti',AC=yeti?'#7fe8ff':'#ffb42a',AC2='#ff6fae',GD='#ffd45a';
 el.innerHTML=`<canvas width="1600" height="900" id="pthc"></canvas><button class="ptskip" id="ptsk">Skip <span>⏭</span></button><div class="ptrv" id="ptrv"></div>`;wrapEl.appendChild(el);
 const cv=$('pthc'),g=cv.getContext('2d'),W0=1600,H0=900,cx=W0/2,fy=PHM_FY,bg=phMythBG(),t0=performance.now()/1000;let done=false,raf=0,last=t0,skipped=false;
 const A=rm?null:phAudio();el._stop=()=>{phStop(A);cancelAnimationFrame(raf)};
 const ES=2.25,EC=140,bx=D.box||[-60,-110,120,115],PS=Math.min(2.5,290/bx[3],340/bx[2]);
 const TL=1.5,TB=5.75,TF=7.9;
 const P_=[],shards=[],conf=[],rings=[],beams=[],snow=[];let flash=0,shake=0,fin2=null;
 const rnd=(a,b)=>a+Math.random()*(b-a),S_=(tt,a,b)=>pSeg(tt,a,b);
 /* the big constellation ring in the sky */const CN=16,CR=Array.from({length:CN},(_,i)=>{const a=-Math.PI/2+i*TAU/CN,r=360+(i%3)*22;return[cx+Math.cos(a)*r,fy-200+Math.sin(a)*r*.62]});
 /* scripted beats */const beats=[];const at=(t,f)=>beats.push({t,f,done:false});
 at(.02,()=>{PHS.drone(A,0,3.2);PHS.sparkle(A,.25,6)});for(let i=0;i<8;i++)at(.12+i*.1,()=>PHS.rune(A,0,i+2));
 at(.55,()=>PHS.whoosh(A,0));at(.9,()=>PHS.suck(A,0,.55));
 at(TL,()=>{PHS.thud(A,0);PHS.bell(A,.02,523.3,.05);shake=9;rings.push({t:0,c:GD,w:8,max:420,y:fy-6,fl:.22},{t:-.1,c:'#ffffff',w:4,max:320,y:fy-6,fl:.22});for(let i=0;i<34;i++){const a=Math.PI+Math.random()*Math.PI;P_.push({x:cx+Math.cos(a)*50,y:fy,vx:Math.cos(a)*rnd(80,260),vy:-rnd(20,90),l:rnd(.6,1.1),c:i%2?GD:'#ffffff',s:rnd(2,4),g:80,st:i%3===0})}});
 [1.65,1.95,2.25].forEach((t,i)=>at(t,()=>PHS.bell(A,0,[659.3,784,987.8][i],.045)));for(let i=0;i<12;i++)at(1.7+i*.11,()=>PHS.rune(A,0,i));
 at(2.0,()=>PHS.choir(A,0,3.6,[220,277.2,329.6,440],.032));
 at(3.4,()=>{PHS.rumble(A,0,1.85,.17);PHS.rise(A,.4,1.4)});
 [3.6,4.2,4.75].forEach((t,i)=>at(t,()=>{PHS.heart(A,0);PHS.crack(A,.04,.5+i*.25);shake=4+i*3;flash=Math.max(flash,.18+i*.08);beams.push({t:0,n:6+i*2,len:420+i*180,w:14+i*8})}));
 at(5.15,()=>PHS.suck(A,0,.55));
 at(TB,()=>{PHS.boom(A,0,true);PHS.shatter(A,.04);PHS.chord(A,.08,[261.6,329.6,392,523.3,659.3],3.2,.045);PHS.choir(A,.05,3.6,[262,330,392,523],.045);PHS.sparkle(A,.12,16);burst()});
 at(TB+.85,()=>{PHS.sparkle(A,0,12);starRain()});
 at(TB+1.0,()=>{PHS.thud(A,0);PHS.bell(A,.05,1046.5,.05);PHS.bell(A,.22,1318.5,.04);shake=Math.max(shake,6);rings.push({t:0,c:AC,w:7,max:360,y:fy-6,fl:.22});
  if(yeti){PHS.chime(A,.1);for(let i=0;i<18;i++){const a=Math.PI+Math.random()*Math.PI;P_.push({x:cx+Math.cos(a)*40,y:fy-10,vx:Math.cos(a)*rnd(120,300),vy:-rnd(60,200),l:1.2,c:'#e8fbff',s:rnd(3,5),g:300,ice:1,r:Math.random()*6})}}else PHS.roar(A,.15)});
 at(TF,()=>{PHS.chord(A,0,[392,493.9,587.3,784,987.8],2,.03);fin()});
 function burst(){flash=1;shake=24;rings.push({t:0,c:AC2,w:18,max:900,y:fy-EC},{t:-.1,c:'#ffffff',w:7,max:1100,y:fy-EC},{t:-.22,c:GD,w:12,max:1250,y:fy-EC},{t:-.34,c:AC,w:8,max:1400,y:fy-EC});
  const sc=['#3a2694','#1a0f52','#5a48c0','#241866'];for(let i=0;i<46;i++){const a=rnd(0,TAU),v=rnd(240,720);shards.push({x:cx+Math.cos(a)*30,y:fy-EC+Math.sin(a)*60,vx:Math.cos(a)*v,vy:Math.sin(a)*v-120,r:Math.random()*6,vr:rnd(-12,12),s:rnd(8,18),c:sc[i%4],l:rnd(1.4,2.2),gold:i%3===0})}
  const cc=[GD,'#fff2c0',AC2,'#5ad8ff','#b47aff',AC];for(let i=0;i<120;i++){const a=rnd(0,TAU),v=rnd(140,620);conf.push({x:cx,y:fy-EC,vx:Math.cos(a)*v,vy:Math.sin(a)*v-180,r:Math.random()*6,vr:rnd(-10,10),s:rnd(3,7),c:cc[i%cc.length],l:rnd(2.2,3.6),ph:Math.random()*6})}
  for(let i=0;i<40;i++){const a=rnd(0,TAU),v=rnd(80,420);P_.push({x:cx,y:fy-EC,vx:Math.cos(a)*v,vy:Math.sin(a)*v,l:rnd(.8,1.5),c:i%2?'#ffffff':AC2,s:rnd(3,7),g:-20,st:1})}
  fin2={t:0}}
 function starRain(){for(let i=0;i<40;i++){P_.push({x:cx+rnd(-500,500),y:rnd(-40,120),vx:rnd(-40,40),vy:rnd(160,320),l:rnd(1.6,2.6),c:i%3?GD:'#ffffff',s:rnd(3,6),g:60,st:1})}}
 /* pet layer: drawn into its own canvas so it can rise as a glowing silhouette */
 const pl=document.createElement('canvas');pl.width=1000;pl.height=860;const pg=pl.getContext('2d');
 const drawPet=(x,y,s,pose,u,sil,silC,t)=>{pg.setTransform(1,0,0,1,0,0);pg.clearRect(0,0,1000,860);pg.setTransform(s,0,0,s,500,700);petDraw(pg,id,{t,pose,u,noSh:1});
  if(sil>0){pg.setTransform(1,0,0,1,0,0);pg.globalCompositeOperation='source-atop';pg.globalAlpha=sil;pg.fillStyle=silC;pg.fillRect(0,0,1000,860);pg.globalAlpha=1;pg.globalCompositeOperation='source-over'}
  g.drawImage(pl,x-500,y-700)};
 const fin=()=>{if(done)return;done=true;P.petPend=null;save();const rv=$('ptrv'),st=opt.starter,more=!st&&(P.eggs[k]|0)>0&&petPool(k).length>0;
  const MS=[['acc',3,D.cos.acc],['pal',5,D.cos.pal],['cel',7,D.cos.cel],['trim',10,D.cos.sig]],own=PIDS.filter(petOwned).length,pc=own/PIDS.length*100;
  rv.className='ptrv myth';
  rv.innerHTML=`<div class="phc"><div class="phc-rib">✦ MYTHIC COMPANION ✦</div><div class="phc-l"><h2 class="phc-n">${esc(D.n)}</h2><div class="phc-tags">${ptBadge(D.r)}<span class="phc-fam" style="--f:${PFAM[D.fam]}">${D.fam}</span></div></div>
   <div class="phc-ab"><canvas width="72" height="72" id="ptrvi"></canvas><div><b>${D.ab.n}</b><p>${D.ab.d}</p></div></div>
   <div class="phc-ms"><small>Bond rewards to unlock</small><div>${MS.map(([kk,L,n])=>`<span title="${esc(n)} at Bond ${L}"><canvas width="64" height="52" data-hm="${kk}"></canvas><i>Bond ${L}</i></span>`).join('')}</div></div>
   <div class="ptmb phc-b">${P.pet===id?`<button class="ptgo" id="ptrvq">${PTICO.chk} Equipped</button>`:`<button class="ptgo phc-eqm" id="ptrve">Equip ${esc(D.n)}</button><button class="ptgo b" id="ptrvq">Keep current</button>`}${more?`<button class="ptsoft" id="ptrvm">${PTICO.egg} Hatch another <em>${P.eggs[k]}</em></button>`:''}</div>
   <div class="phc-prog"><div><span>${PTICO.paw} Collection</span><b>${own} / ${PIDS.length}</b></div><span class="phc-pb"><i style="--w:${pc}%"></i></span><small>${PTICO.star} ${petPool('m').length?`${petPool('m').length} Mythic left to find`:'Every Mythic companion found!'}</small></div></div>`;
  requestAnimationFrame(()=>rv.classList.add('on'));petIconCv($('ptrvi'),D.ab.k);
  rv.querySelectorAll('canvas[data-hm]').forEach(c=>{const kk=c.dataset.hm;if(kk==='cel'){petFit(c,id,{t:1.2,pose:'greet',u:.55,still:1});const gg=c.getContext('2d'),s=c.height/130;gg.save();gg.translate(c.width/2,c.height*.9);gg.scale(s,s);petCelFx(gg,id,.4,1,-56,52);gg.restore()}else petFit(c,id,{t:1.2,still:1,[kk]:1})});
  $('ptsk').style.display='none';
  const close=(then)=>{phStop(A);cancelAnimationFrame(raf);el.classList.add('out');setTimeout(()=>el.remove(),260);PTX.sel=id;PTX.tab=then==='more'?'Eggs':'Pets';if(then==='more'){const r=petHatch(k);if(r&&r.id){petHall('Eggs');return ptHatchScene(r.id,k,{})}}petHall(PTX.tab)};
  const e=$('ptrve');if(e)e.onclick=()=>{petEquip(id);ptBeep(820,.06,.35);close()};$('ptrvq').onclick=()=>close();const mb=$('ptrvm');if(mb)mb.onclick=()=>close('more');
  setTimeout(()=>{const f=$('ptrve')||$('ptrvq');try{f&&f.focus()}catch(x){}},420)};
 const skip=()=>{if(done)return;skipped=true;phStop(A);const B=phAudio();if(B){PHS.chord(B,0,[261.6,329.6,392,523.3,659.3],1.6,.04);PHS.bell(B,.05,1046.5,.04);setTimeout(()=>phStop(B),2000)}flash=Math.max(flash,.6);fin()};
 $('ptsk').onclick=skip;el.tabIndex=-1;el.onkeydown=e=>{e.stopPropagation();if(e.key==='Escape'||(e.key===' '&&!done)){e.preventDefault();if(!done)skip()}};setTimeout(()=>{try{el.focus()}catch(x){}},30);
 const frame=()=>{if(!el.isConnected){phStop(A);return}const now=performance.now()/1000,dt=Math.min(.05,now-last);last=now;let tt=rm||skipped?Math.max(TF+.4,now-t0+TF):now-t0;if(window.__phT!=null)tt=window.__phT;const t=now;
  for(const b of beats)if(!b.done&&tt>=b.t&&!skipped&&!rm){b.done=true;try{b.f()}catch(e){}}
  if(rm&&!done)fin();
  const post=tt-TB,em=post;
  /* camera */let z=post<0?.94+.12*pS(Math.max(0,tt)/TB):1+.2*Math.exp(-post*3.6)*Math.cos(post*6.5);if(rm||skipped)z=1;
  shake*=Math.pow(.02,dt);flash*=Math.pow(.006,dt);const sx=(Math.random()-.5)*shake,sy=(Math.random()-.5)*shake;
  const night=rm||skipped?1:S_(tt,0,.8);
  g.setTransform(1,0,0,1,0,0);g.globalAlpha=1;g.globalCompositeOperation='source-over';g.fillStyle='#000';g.fillRect(0,0,W0,H0);
  const bz=1+(z-1)*.35;g.globalAlpha=night;g.setTransform(bz,0,0,bz,cx*(1-bz)+sx*.3,(fy-EC)*(1-bz)+sy*.3);g.drawImage(bg,0,0);g.globalAlpha=1;
  g.setTransform(z,0,0,z,cx*(1-z)+sx,(fy-EC)*(1-z)+sy);
  /* twinkling stars, drifting nebula light */if(!rm){g.save();g.globalCompositeOperation='lighter';for(let i=0;i<46;i++){const x=(i*271.3)%W0,y=(i*97.7)%(fy-60),tw=Math.max(0,Math.sin(t*1.6+i*2.3));if(tw<.05)continue;g.globalAlpha=night*tw;pStar4(g,x,y,1.6+tw*3.4,'#ffffff')}g.restore();g.globalAlpha=1;
   const nb=post>0?Math.max(.6,1.6-post*.3):S_(tt,3.4,5.2)*.5;if(nb>0){pGlow(g,cx-220,fy-260,520,'#ff4f8b',.14*nb);pGlow(g,cx+240,fy-220,480,'#3fb8ff',.12*nb);pGlow(g,cx,fy-340,560,'#8a4aff',.14*nb)}}
  /* the sky constellation draws itself, star by star */{const dr=rm||skipped?1:S_(tt,.1,1.2),al=(post<0?.85-S_(tt,1.5,3)*.4:Math.max(.25,.45-post*.05))*night;g.save();g.globalCompositeOperation='lighter';const n=dr*CN;
   g.beginPath();for(let i=0;i<=Math.min(CN,Math.ceil(n));i++){const p=CR[i%CN],q2=CR[Math.max(0,i-1)%CN];if(i===0){g.moveTo(p[0],p[1]);continue}const f=Math.min(1,n-(i-1));g.lineTo(q2[0]+(p[0]-q2[0])*f,q2[1]+(p[1]-q2[1])*f)}g.strokeStyle=ptHexA(GD,.35*al);g.lineWidth=1.6;g.stroke();
   for(let i=0;i<CN;i++){if(i>n)break;const p=CR[i],tw=.7+.3*Math.sin(t*3+i);pGlow(g,p[0],p[1],18,GD,.4*al*tw);pStar4(g,p[0],p[1],(4+(i%3)*2)*tw,ptHexA('#fff6d8',Math.min(1,al+.2)))}g.restore()}
  /* light pillar from above while the egg gathers power */const pil=post<0?S_(tt,1.5,3)*.35+S_(tt,3.4,5.2)*.4:Math.max(0,.7-post*.25);if(pil>0&&!rm){g.save();g.globalCompositeOperation='lighter';const q=g.createLinearGradient(0,0,0,fy);q.addColorStop(0,ptHexA(AC2,0));q.addColorStop(.7,ptHexA(AC2,.12*pil));q.addColorStop(1,ptHexA(GD,.22*pil));g.fillStyle=q;g.beginPath();g.moveTo(cx-60,0);g.lineTo(cx+60,0);g.lineTo(cx+170,fy);g.lineTo(cx-170,fy);g.closePath();g.fill();g.restore()}
  /* godrays */const ri=post<0?S_(tt,1.6,TB)*.5:Math.max(.3,1-post*.35);if(ri>0){g.save();g.globalCompositeOperation='lighter';g.translate(cx,fy-EC);g.rotate(t*.06);for(let i=0;i<18;i++){g.rotate(TAU/18);const len=760+Math.sin(t*1.2+i)*80,wd=i%2?24:46,q=g.createLinearGradient(0,0,0,-len);q.addColorStop(0,ptHexA(i%3?AC2:i%2?GD:'#ffffff',.2*ri));q.addColorStop(1,ptHexA(AC2,0));g.fillStyle=q;g.beginPath();g.moveTo(-6,0);g.lineTo(6,0);g.lineTo(wd,-len);g.lineTo(-wd,-len);g.closePath();g.fill()}g.restore()}
  /* floor sigil: twelve stars light one by one */{const on=rm||skipped?1:S_(tt,1.6,3),glow=post<0?.4+S_(tt,3.4,5.2)*.6:Math.max(.3,1-post*.3);g.save();g.translate(cx,fy-4);g.scale(1,.2);g.globalCompositeOperation='lighter';g.rotate(t*.1);
   g.strokeStyle=ptHexA(GD,.25+.45*on*glow);g.lineWidth=5;g.beginPath();g.arc(0,0,250,-Math.PI/2,-Math.PI/2+TAU*on);g.stroke();g.lineWidth=2.4;g.strokeStyle=ptHexA(AC2,.3*on*glow);g.beginPath();g.arc(0,0,214,0,TAU);g.stroke();
   if(on>.4){g.beginPath();for(let i=0;i<=12;i++){const a=-Math.PI/2+i*TAU*5/12;i?g.lineTo(Math.cos(a)*214,Math.sin(a)*214):g.moveTo(Math.cos(a)*214,Math.sin(a)*214)}g.strokeStyle=ptHexA('#fff2b0',.35*S_(on,.4,1)*glow);g.lineWidth=2;g.stroke()}
   for(let i=0;i<12;i++){const a=i*TAU/12;if(i/12<on){pStar4(g,Math.cos(a)*250,Math.sin(a)*250,16,'#fff2c0');pGlow(g,Math.cos(a)*250,Math.sin(a)*250,46,GD,.3*glow)}}g.restore()}
  /* ----- the egg ----- */
  let eX=cx,eY=fy-20,eS=1,eA=1,lean=0,glow=.3+.15*Math.sin(t*2),charge=0,comet=0,cometK=0;
  if(!rm&&!skipped){if(tt<TL){/* the falling star */const k2=S_(tt,.5,TL),e2=1-Math.pow(1-k2,3);eX=cx+760*(1-e2);eY=-260+(fy-20+260)*e2-Math.sin(e2*Math.PI)*120;eS=.35+.65*e2;comet=1-S_(tt,1.25,TL+.25);cometK=k2;eA=S_(tt,.45,.62)}
   else if(post<0){const hv=S_(tt,TL,TL+.5),rise=S_(tt,3.4,5.2);eY=fy-20-Math.sin(Math.min(1,(tt-TL)/.5)*Math.PI)*-10*(1-hv)-hv*14-rise*46-Math.sin(t*1.6)*5*hv;glow=.35+S_(tt,1.6,3.4)*.35+rise*.6;charge=S_(tt,3.55,5.2);
    if(tt>3.4)lean=Math.sin(t*34)*.012*(1+charge*2);for(const b of[3.6,4.2,4.75]){const k3=(tt-b)/.4;if(k3>=0&&k3<1){eS*=1+Math.sin(k3*Math.PI)*.05;lean+=Math.sin(k3*Math.PI*3)*(1-k3)*.05}}
    if(tt>5.2){const im=S_(tt,5.2,TB);eS*=1-im*.14;charge=1;glow=1.4}}
   else eA=0}
  const eCy=eY-EC*eS;
  /* astrolabe rings: assemble, turn faster while gathering, collapse inward on the implosion */
  const RG=[[200,.32,-.35,1.65],[244,.26,.42,1.95],[290,.2,1.25,2.25]],imp=S_(tt,5.2,TB),spin=t*.5+S_(tt,3.4,5.2)*t*1.4;
  const ring=(i,half)=>{const [r0,sq,tilt,ts]=RG[i],ap=rm||skipped?0:post>=0?0:ptBack(Math.min(1,Math.max(0,(tt-ts)/.55)))*(1-imp);if(ap<=.01)return;const r=r0*ap;g.save();g.translate(cx,eCy);g.rotate(tilt+Math.sin(t*.4+i)*.05);g.scale(1,sq);
   g.beginPath();g.arc(0,0,r,half?0:Math.PI,half?Math.PI:TAU);g.strokeStyle='#3a2410';g.lineWidth=11;g.stroke();g.strokeStyle=half?GD:'#b8801a';g.lineWidth=6;g.stroke();g.strokeStyle=half?'#fff2b0':'#e0a83a';g.lineWidth=1.6;g.stroke();
   for(let j=0;j<16;j++){const a=spin*(i%2?-1:1)+j*TAU/16,s=Math.sin(a);if((s>0)!==!!half)continue;const x=Math.cos(a)*r,y=s*r;if(j%4===0){pGlow(g,x,y,22,i===1?AC2:AC,.5);g.save();g.translate(x,y);g.scale(1,1/sq);pStar4(g,0,0,8,'#ffffff');g.restore()}else{g.fillStyle=half?'#fff2b0':'#c89a3a';g.fillRect(x-2,y-2,4,4)}}g.restore()};
  if(!rm)for(let i=0;i<3;i++)ring(i,0);
  /* converging starlight */if(!rm&&!skipped&&post<0&&tt>3.4){const n2=Math.round(2+charge*6);for(let i=0;i<n2;i++){const a=Math.random()*TAU,d=rnd(500,900);P_.push({x:cx+Math.cos(a)*d,y:eCy+Math.sin(a)*d*.7,tx:cx,ty:eCy,l:.7,c:i%3?'#ffffff':i%2?AC2:GD,s:rnd(2,4),seek:1,sp:rnd(3,6),st:i%4===0})}}
  /* heartbeat beams through the cracks */for(let i=beams.length-1;i>=0;i--){const b=beams[i];b.t+=dt;const v=b.t/.5;if(v>=1){beams.splice(i,1);continue}g.save();g.globalCompositeOperation='lighter';g.translate(cx,eCy);for(let j=0;j<b.n;j++){const a=j/b.n*TAU+.3+i,L=b.len*pS(Math.min(1,v*2.2));g.save();g.rotate(a);const q=g.createLinearGradient(0,0,L,0);q.addColorStop(0,ptHexA('#ffffff',.6*(1-v)));q.addColorStop(.4,ptHexA(AC2,.4*(1-v)));q.addColorStop(1,ptHexA(AC2,0));g.fillStyle=q;g.beginPath();g.moveTo(0,-4);g.lineTo(L,-b.w);g.lineTo(L,b.w);g.lineTo(0,4);g.closePath();g.fill();g.restore()}g.restore()}
  /* the egg itself, or the falling star carrying it */
  if(eA>0&&post<0){if(comet>0){g.save();g.globalCompositeOperation='lighter';const dx=760,dy=-(fy+240),ang=Math.atan2(dy,dx);g.translate(eX,eY-EC*eS*.5);g.rotate(ang);const L=520*comet,q=g.createLinearGradient(0,0,L,0);q.addColorStop(0,ptHexA('#ffffff',.85*comet));q.addColorStop(.2,ptHexA(AC2,.5*comet));q.addColorStop(1,ptHexA('#8a4aff',0));g.fillStyle=q;g.beginPath();g.moveTo(0,-34*eS);g.lineTo(L,-6);g.lineTo(L,6);g.lineTo(0,34*eS);g.closePath();g.fill();g.restore();pGlow(g,eX,eY-EC*eS*.5,200*eS*comet,'#ffffff',.55*comet);pGlow(g,eX,eY-EC*eS*.5,320*eS*comet,AC2,.35*comet)}
   g.save();g.globalAlpha=eA;g.translate(eX,eY);g.rotate(lean);g.scale(ES*eS,ES*eS);eggDraw(g,'m',{t,glow,charge,noSh:tt<TL?1:0,noComet:tt>3.4});g.restore();
   if(charge>0){pGlow(g,cx,eCy,60+charge*140,'#ffffff',.25*charge);pGlow(g,cx,eCy,120+charge*200,AC2,.25*charge)}}
  if(!rm)for(let i=0;i<3;i++)ring(i,1);
  /* implosion: the world dims to a single point of light */if(!rm&&!skipped&&imp>0&&post<0){g.save();g.setTransform(1,0,0,1,0,0);g.fillStyle=`rgba(3,2,10,${.62*imp})`;g.fillRect(0,0,W0,H0);g.restore();pGlow(g,cx,eCy,30+imp*80,'#ffffff',.9*imp);pStar4(g,cx,eCy,20+imp*40,'#ffffff')}
  /* ----- the companion ----- */
  let petY=fy+40,petA=0,silA=1,ps=PS,pose='idle',pu=0;
  if(em>=0){petA=S_(em,.05,.25);const up=S_(em,.05,.55),dn=S_(em,.6,1);petY=em<.6?fy-EC*.6-up*90:fy-EC*.6-90+(EC*.6+90)*dn*dn;silA=1-S_(em,.45,1.15);ps=PS*(.6+S_(em,.05,.6)*.4);
   if(em>1&&em<1.2){const k2=(em-1)/.2;ps*=1-Math.sin(k2*Math.PI)*.07}
   if(em>1.05){const gk=(em-1.05)/1.7;if(gk<1){pose='greet';pu=gk}else{const c2=(em-2.75)%6.5;if(c2>=0&&c2<2.2){pose='ability';pu=c2/2.2}else if(c2>4.2&&c2<5.8){pose='greet';pu=(c2-4.2)/1.6}}}else if(em>.6)pose='idle'}
  if(rm||skipped){petA=1;petY=fy;silA=0;ps=PS;const c2=(tt-TF)%7;if(c2>1&&c2<3.2){pose='ability';pu=(c2-1)/2.2}else if(c2>4.5&&c2<6.1){pose='greet';pu=(c2-4.5)/1.6}}
  /* signature backdrop behind the newcomer */if(em>.6||rm){const sa=rm?1:S_(em,.6,1.4);g.save();g.globalCompositeOperation='lighter';g.translate(cx,fy-bx[3]*PS*.55);g.rotate(t*(yeti?.05:.12));for(let i=0;i<(yeti?6:20);i++){g.rotate(TAU/(yeti?6:20));if(yeti){g.save();g.translate(0,-240);g.globalAlpha=.16*sa;pmSnow(g,0,0,40,'#bff6ff',6);g.restore()}else{const L=420+Math.sin(t*2+i)*40;const q=g.createLinearGradient(0,0,0,-L);q.addColorStop(0,ptHexA('#ffe07a',.28*sa));q.addColorStop(1,ptHexA('#ff8a2a',0));g.fillStyle=q;g.beginPath();g.moveTo(-8,0);g.lineTo(8,0);g.lineTo(34,-L);g.lineTo(-34,-L);g.closePath();g.fill()}}g.restore();g.globalAlpha=1;
   pGlow(g,cx,fy-bx[3]*PS*.5,260,AC,.22*sa)}
  if(em>=0||rm){const lc=rm?.4:Math.max(.25,1-em*.3);g.save();g.globalCompositeOperation='lighter';g.translate(cx,fy-280);g.scale(.42,1.8);pGlow(g,0,0,300,AC2,.3*lc);g.restore();
   g.save();g.globalAlpha=petA;g.fillStyle='#00000070';g.beginPath();g.ellipse(cx,fy+2,90*ps/PS,16,0,0,TAU);g.fill();g.restore();
   if(petA>0){g.save();g.globalAlpha=petA;drawPet(cx,petY,ps,pose,pu,silA,'#ffffff',t);g.restore();if(silA>.05){pGlow(g,cx,petY-bx[3]*ps*.5,240*silA,'#ffffff',.45*silA)}}}
  if(em>1.05&&em<2.9&&!rm){g.save();g.translate(cx,fy);g.scale(ps,ps);petCelFx(g,id,(em-1.05)/1.85,t,-bx[3]*.5,Math.max(bx[2],bx[3])*.75);g.restore()}
  /* yeti: a gentle snowfall once it arrives */if(yeti&&(em>1||rm)){if(snow.length<70&&Math.random()<.6)snow.push({x:rnd(0,W0),y:-10,v:rnd(30,70),s:rnd(2,5),ph:Math.random()*6});for(let i=snow.length-1;i>=0;i--){const f=snow[i];f.y+=f.v*dt;f.x+=Math.sin(t+f.ph)*12*dt;if(f.y>H0){snow.splice(i,1);continue}g.globalAlpha=.75;if(f.s>4)pmSnow(g,f.x,f.y,f.s,'#ffffff',1.2);else{g.fillStyle='#ffffff';g.beginPath();g.arc(f.x,f.y,f.s*.6,0,TAU);g.fill()}g.globalAlpha=1}}
  /* ----- shockwaves, flash, particles ----- */
  g.save();g.globalCompositeOperation='lighter';
  for(let i=rings.length-1;i>=0;i--){const r=rings[i];r.t+=dt;if(r.t<0)continue;const v=r.t/1.2;if(v>=1){rings.splice(i,1);continue}g.save();g.translate(cx,r.y);g.scale(1,r.fl||.6);g.beginPath();g.arc(0,0,40+pS(v)*r.max,0,TAU);g.strokeStyle=ptHexA(r.c,(1-v)*.9);g.lineWidth=r.w*(1-v)+2;g.stroke();g.restore()}
  if(flash>.01){pGlow(g,cx,fy-EC,600*(1.5-flash*.5),AC2,.5*flash);pGlow(g,cx,fy-EC,260,'#ffffff',.7*flash);g.save();g.setTransform(1,0,0,1,0,0);g.fillStyle=ptHexA('#ffffff',Math.max(0,flash-.55)*1.4);g.fillRect(0,0,W0,H0);g.restore()}
  g.restore();
  for(let i=shards.length-1;i>=0;i--){const s=shards[i];s.l-=dt;if(s.l<=0||s.y>H0+60){shards.splice(i,1);continue}s.vy+=620*dt;s.vx*=Math.pow(.5,dt);s.x+=s.vx*dt;s.y+=s.vy*dt;s.r+=s.vr*dt;g.globalAlpha=Math.min(1,s.l*1.4);g.save();g.translate(s.x,s.y);g.rotate(s.r);
   pP(g,[-s.s,-s.s*.5,s.s*.9,-s.s*.3,s.s*.3,s.s*.85,-s.s*.4,s.s*.5]);pF(g,s.c,2.4);if(s.gold){g.strokeStyle=GD;g.lineWidth=2;g.beginPath();g.moveTo(-s.s,-s.s*.5);g.lineTo(s.s*.9,-s.s*.3);g.stroke()}pStar4(g,-s.s*.2,0,s.s*.22,'#ffffffaa');g.restore();g.globalAlpha=1}
  for(let i=conf.length-1;i>=0;i--){const c=conf[i];c.l-=dt;if(c.l<=0){conf.splice(i,1);continue}c.vy+=240*dt;c.vx*=Math.pow(.35,dt);c.vy*=Math.pow(.55,dt);c.x+=(c.vx+Math.sin(t*3+c.ph)*40)*dt;c.y+=c.vy*dt;c.r+=c.vr*dt;g.save();g.globalAlpha=Math.min(1,c.l);g.translate(c.x,c.y);g.rotate(c.r);if(c.ph>3)pStar4(g,0,0,c.s,c.c);else{g.scale(1,Math.cos(t*8+c.ph));g.fillStyle=c.c;g.fillRect(-c.s,-c.s*.4,c.s*2,c.s*.8)}g.restore()}
  for(let i=P_.length-1;i>=0;i--){const p=P_[i];p.l-=dt;if(p.l<=0){P_.splice(i,1);continue}if(p.seek){const k2=Math.min(1,dt*(p.sp||5));p.x+=(p.tx-p.x)*k2;p.y+=(p.ty-p.y)*k2}else{p.vy+=(p.g||0)*dt;p.x+=p.vx*dt;p.y+=p.vy*dt}g.globalAlpha=Math.min(1,p.l*2);
   if(p.ice){g.save();g.translate(p.x,p.y);pmCrystal(g,0,0,p.s*2.6,p.s,p.r+=dt*4,'#ffffff','#5ab8ff',1.4);g.restore()}else if(p.st)pStar4(g,p.x,p.y,p.s,p.c);else{pGlow(g,p.x,p.y,p.s*2.4,p.c,.5);g.fillStyle=p.c;g.fillRect(p.x-p.s/2,p.y-p.s/2,p.s,p.s)}g.globalAlpha=1}
  /* ambient motes once revealed */if(em>1.2||rm){for(let i=0;i<10;i++){const u=((t*.06+i/10)%1),x=cx+Math.sin(i*2.2+t*.3)*300*(.5+u*.5),y=fy-u*520,a=Math.sin(u*Math.PI)*.6;pGlow(g,x,y,9,i%2?AC:AC2,a)}}
  raf=requestAnimationFrame(frame)};
 raf=requestAnimationFrame(frame)}
{const h0=ptHatchScene;ptHatchScene=function(id,k,opt){if(k==='m'&&PDEF[id]&&PDEF[id].r==='m')return ptMythHatch(id,k,opt);return h0.apply(this,arguments)}}
{const st=document.createElement('style');st.textContent=`
.ptrv.myth .phc{border:2px solid transparent;background:linear-gradient(180deg,#1f1248f4,#0c0822f8) padding-box,linear-gradient(120deg,#ff4f8b,#b04aff 35%,#4fc8ff 65%,#ffd45a) border-box;box-shadow:0 20px 60px #000c,0 0 50px #ff4f8b33}
.ptrv.myth .phc-rib{color:#fff;background:linear-gradient(90deg,#ff4f8b,#b04aff 50%,#4fc8ff);border-color:#ffe0f0;text-shadow:0 1px 0 #3a0a3a;letter-spacing:3px}
.ptrv.myth .phc-n{background-image:linear-gradient(100deg,transparent 0%,transparent 42%,rgba(255,255,255,.95) 50%,transparent 58%,transparent 100%),linear-gradient(180deg,#ffffff 0%,#ffd0ea 40%,#ffd45a 100%);filter:drop-shadow(0 2px 0 #3a0a3a) drop-shadow(0 0 1px #3a0a3a) drop-shadow(0 0 18px rgba(255,111,174,.55))}
.phc-eqm{background:linear-gradient(180deg,#ffe48a,#ff8ac0 60%,#c050d0)!important;color:#2a0a2a!important;box-shadow:0 4px 0 #6a1a5a!important}
.pthx-m .ptskip{z-index:3}
`;document.head.appendChild(st)}
/* ===== MYTHIC COMPANIONS IN BATTLE =====
   Glacierhorn - Permafrost Armor: the knight starts every run inside two layers of ice armor. A layer absorbs one hit (after your own
   shields), and when it cracks a frost nova freezes nearby monsters for 2 s (bosses are chilled), shattering projectiles in the air.
   Every 30 correct words one cracked layer regrows (no charging while the armor is whole).
   Solmane - Sunburst Roar: 15 words in a row without a typo charge a roar (a typo restarts the streak). The roar defeats every ordinary
   monster on screen, burns away projectiles and restores 1 heart; a boss loses a phase, or half of its current sentence. 3 roars per run.
   Powers work in Campaign and standard Endless only, like every companion. */
const PMG={fx:[]};
const pmAud=(f,ms)=>{try{const A=phAudio();if(!A)return;f(A);setTimeout(()=>phStop(A),ms||1800)}catch(e){}};
{const r0=petRunInit;petRunInit=function(){const r=r0.apply(this,arguments);try{PMG.fx=[];const p=S.pet;if(p){p.arm=p.cos?0:PDEF[p.id].ab.k==='permafrost'?2:0;p.grT=-9;p.crT=-9;p.brk=-9;p.armT=S.t}}catch(e){}return r}}
/* charge rules: Glacierhorn only charges while a layer is missing; Solmane counts clean words itself (below) */
{const w0=petWord;petWord=function(n){const p=PP();if(p){const k=PDEF[p.id].ab.k;if(k==='sunburst')return;if(k==='permafrost'&&(p.arm|0)>=2)return}return w0.apply(this,arguments)}}
function pmStreakAdd(n){const p=PP();if(!p||PDEF[p.id].ab.k!=='sunburst'||p.ready)return;const A=PDEF[p.id].ab;if(p.uses>=A.cap)return;
 p.w=Math.min(A.N,p.w+n);if(p.w>=A.N){p.ready=true;p.pingT=S.t;try{beep(880,.06,'sine',.25);setTimeout(()=>beep(1175,.08,'sine',.2),70);setTimeout(()=>beep(1568,.1,'sine',.16),150)}catch(e){}petAnim('greet',1)}}
{const k0=kill;kill=function(e,force){const had=e&&S.en.includes(e),boss=e&&e.boss,vul0=e&&e.vul,typed=!force&&e&&e.i>=(e.w||'').length,bad=e&&e.bad;const r=k0.apply(this,arguments);
 try{const p=PP();if(p&&typed&&!bad&&PDEF[p.id].ab.k==='sunburst'){if(boss){if(e.vul>0&&!(vul0>0))pmStreakAdd(Math.max(1,(e.w||'').trim().split(/\s+/).length))}else if(had&&!S.en.includes(e))pmStreakAdd(1)}}catch(x){}return r}}
/* a typo (or a forgiven slip) restarts Solmane's streak */
{const ky0=key;key=function(c){const ch0=S.chars,ok0=S.ok;const r=ky0.apply(this,arguments);try{const p=PP();if(p&&S.mode==='play'&&PDEF[p.id].ab.k==='sunburst'&&S.chars>ch0&&S.ok===ok0&&!p.ready&&p.w>0){if(p.w>=4)float(KX+40,GY-250,'Streak reset','#ffb04a',24);p.w=0;p.brk=S.t}}catch(e){}return r}}

/* ---------- Permafrost Armor: absorbs a hit, then a frost nova ---------- */
{const d0=dmg;dmg=function(d){try{const p=PP();if(p&&S.mode==='play'&&!S.rift&&!S.prac&&!(S.inv>0)&&!(S.shield>0)&&(p.arm|0)>0&&PDEF[p.id].ab.k==='permafrost'){
  p.arm--;p.uses++;p.crT=S.t;S.inv=S.invT;S.shake=Math.max(S.shake,12);S.flash=Math.max(S.flash,.18);
  const R=560;let fz=0;for(const e of S.en){if(e.x>W-10)continue;if(e.boss){e.pchl=2.5;PMG.fx.push({k:'frz',e,t:0,ml:.45});continue}if(e.x>KX+R)continue;e.pfrz=2;fz++;PMG.fx.push({k:'frz',e,t:0,ml:.45})}
  const pj=S.pj.filter(j=>!j.b&&j.x<KX+R);for(const j of pj){burst(j.x,j.y,'#bff6ff',10,{v:220});PMG.fx.push({k:'shat',x:j.x,y:j.y,t:0,ml:.5})}S.pj=S.pj.filter(j=>!pj.includes(j));
  PMG.fx.push({k:'crack',t:0,ml:.9,n:p.arm},{k:'nova',t:0,ml:.9,r:R});burst(KX,GY-130,'#bff6ff',34,{v:420});burst(KX,GY-130,'#ffffff',14,{v:260,s:3});
  float(KX,GY-262,p.arm?'Permafrost! 1 layer left':'Permafrost!','#9ff4ff',36);if(fz)float(KX+260,GY-200,`Frozen ×${fz}`,'#bff6ff',30);
  petAnim('ability',2);pmAud(A=>{PHS.shatter(A,0);PHS.crack(A,0,.9);phTone(A,.02,1568,.6,.04,{echo:1});phTone(A,.1,2093,.5,.03,{echo:1});phNoise(A,0,.5,.12,{ty:'highpass',f:4200})});return}}catch(e){}
 return d0.apply(this,arguments)}}

/* ---------- per frame: regrow armor, fire the roar, keep frozen monsters still ---------- */
function pmRoar(p){const A=PDEF[p.id].ab;p.ready=false;p.w=0;p.uses++;p.roT=S.t;S.flash=Math.max(S.flash,.7);S.shake=Math.max(S.shake,24);S.lunge=1;
 const pjn=S.pj.filter(j=>!j.b);for(const j of pjn)burst(j.x,j.y,'#ffb04a',10,{v:240});S.pj=S.pj.filter(j=>j.b);
 let n=0;S.inChain=1;for(const e of[...S.en]){if(!S.en.includes(e)||e.x>W-10)continue;if(!e.boss){kill(e,true);n++}
  else if(e.phs>1){kill(e,true);float(e.x,GY-e.h-70,'Scorched!','#ffb04a',38)}
  else if(!(e.vul>0)){const L=(e.w||'').length,i0=e.i|0;if(L>1&&i0<L-1){e.i=Math.min(L-1,i0+Math.ceil((L-i0)*.5));e.fl=.5;float(e.x,GY-e.h-70,'Scorched!','#ffb04a',38)}}}
 S.inChain=0;
 const healed=S.hp>0&&S.hp<S.max;if(healed){heal(S,1);float(KX,GY-300,'+1 ♥','#7dffb0',40)}
 float(W*.5,GY-330,'SUNBURST ROAR!','#ffd45a',58);PMG.fx.push({k:'roar',t:0,ml:1.6,x:petPx()+30,y:petPy()-40});petAnim('ability',1.8);
 pmAud(A=>{PHS.roar(A,0);PHS.boom(A,.12,false);PHS.chord(A,.2,[261.6,329.6,392,523.3],1.6,.04);PHS.sparkle(A,.3,8)},2600)}
{const u0=update;update=function(dt){const p=S&&S.pet;if(!p||S.mode!=='play'||p.cos)return u0.apply(this,arguments);
 const k=PDEF[p.id].ab.k,mod=[];
 if(!S.cine){
  if(k==='permafrost'&&p.ready&&(p.arm|0)<2){p.arm++;petSpend();p.grT=S.t;PMG.fx.push({k:'grow',t:0,ml:1.1});float(KX,GY-262,p.arm>=2?'Ice armor restored!':'Ice armor +1','#9ff4ff',30);petAnim('greet',1.4);
   pmAud(A=>{PHS.chime(A,0);phTone(A,0,523.3,.5,.04,{echo:1})},1600)}
  if(k==='sunburst'&&p.ready&&S.en.some(e=>e.x<W-10&&e.x>KX))pmRoar(p)}
 /* frozen monsters stand still (their attacks too); chilled bosses act at half speed */
 for(const e of S.en){if(e.pfrz>0){e.pfrz-=dt;mod.push([e,e.sp,e.at,1]);e.sp=0}else if(e.pchl>0){e.pchl-=dt;mod.push([e,e.sp,e.at,.5]);e.sp*=.5}}
 const r=u0.apply(this,arguments);
 for(const [e,sp,at,f] of mod){e.sp=sp;if(at!=null&&e.at!=null)e.at=f>=1?at:at+(e.at-at)*.5}
 return r}}

/* ---------- drawing: the ice armor around the knight, ice blocks on frozen monsters, the roar ---------- */
function pmIceShell(c,cx,cy,rx,ry,layer,al,t){c.save();c.globalAlpha=al;c.translate(cx,cy);const N=14,pts=[];for(let i=0;i<N;i++){const a=i/N*TAU+layer*.22,j=1+((i*37+layer*11)%7-3)*.018;pts.push([Math.cos(a)*rx*j,Math.sin(a)*ry*j])}
 c.globalCompositeOperation='lighter';c.beginPath();pts.forEach((p,i)=>i?c.lineTo(p[0],p[1]):c.moveTo(p[0],p[1]));c.closePath();const q=c.createRadialGradient(-rx*.3,-ry*.4,10,0,0,Math.max(rx,ry));q.addColorStop(0,'rgba(200,245,255,.05)');q.addColorStop(.75,'rgba(120,210,255,.09)');q.addColorStop(1,'rgba(160,235,255,.22)');c.fillStyle=q;c.fill();
 c.strokeStyle=`rgba(190,246,255,${.55})`;c.lineWidth=3;c.stroke();
 c.strokeStyle='rgba(220,250,255,.22)';c.lineWidth=1.4;c.beginPath();for(let i=0;i<N;i+=2){const p=pts[i],q2=pts[(i+5)%N];c.moveTo(p[0],p[1]);c.lineTo(p[0]*.55+q2[0]*.12,p[1]*.55+q2[1]*.12)}c.stroke();
 /* a glint that circles the shell */const ga=t*1.4+layer*2.4;c.beginPath();c.ellipse(0,0,rx,ry,0,ga,ga+.5);c.strokeStyle='rgba(255,255,255,.75)';c.lineWidth=4;c.stroke();c.restore()}
{const h0=drawHeroGame;drawHeroGame=function(){const p=S.pet;let ch=0;try{if(p&&!p.cos&&PDEF[p.id].ab.k==='sunburst')ch=Math.min(1,(p.w||0)/15)}catch(e){}const r=h0.apply(this,arguments);
 try{if(p&&!p.cos&&PDEF[p.id].ab.k==='permafrost'&&(S.mode==='play'||S.mode==='pause'||S.mode==='boon')){const c=ctx,t=S.t,g0=(t-p.grT)/.6,arm=p.arm|0;
   const grow=g0>=0&&g0<1?ptBack(g0):1;if(arm>0){const cx=KX+6,cy=GY-128;for(let L=0;L<arm;L++){const s=(L?1.12:1)*(L===arm-1?grow:1);pmIceShell(c,cx,cy,140*s,168*s,L,L===arm-1&&g0<1?Math.min(1,g0*2):1,t)}
    /* frost crystals at the knight's feet */for(const [x,h,a] of[[-120,26,-.4],[-96,16,-.15],[118,24,.4],[96,15,.2]]){c.save();c.globalAlpha=.9;pmCrystal(c,cx+x,GY+2,h,h*.42,a,'#ffffff','#5ab8ff',2);c.restore()}
    pGlow(c,cx,GY-6,150,'#7ff0ff',.12+.04*Math.sin(t*2))}}}catch(e){}
 /* the companion last: in front of the knight and his ice armour */PM_CH.sol=ch;try{petDrawGame()}finally{PM_CH.sol=0}return r}}
{const w0=drawWorld;drawWorld=function(){const r=w0.apply(this,arguments);try{const c=ctx,t=S.t;
 for(const e of S.en){if(e.pfrz>0){const h=e.h||80,w=Math.max(60,h*.82),y=e.y-h*.5,f=e.pfrz<.35?e.pfrz/.35:1;c.save();c.globalAlpha=.95*f;c.translate(e.x,y);
   c.globalCompositeOperation='lighter';pGlow(c,0,0,h*.8,'#7ff0ff',.25);c.globalCompositeOperation='source-over';c.beginPath();const P2=[[-w*.5,-h*.48],[-w*.15,-h*.6],[w*.38,-h*.52],[w*.52,-h*.05],[w*.42,h*.5],[-w*.3,h*.56],[-w*.56,h*.1]];P2.forEach((q,i)=>i?c.lineTo(q[0],q[1]):c.moveTo(q[0],q[1]));c.closePath();
   c.fillStyle='rgba(170,235,255,.32)';c.fill();c.strokeStyle='#e8fbff';c.lineWidth=3;c.stroke();c.strokeStyle='rgba(255,255,255,.4)';c.lineWidth=1.6;c.beginPath();c.moveTo(-w*.15,-h*.6);c.lineTo(w*.05,h*.1);c.lineTo(w*.42,h*.5);c.moveTo(w*.05,h*.1);c.lineTo(-w*.56,h*.1);c.stroke();
   c.beginPath();c.moveTo(-w*.38,-h*.36);c.lineTo(-w*.3,h*.2);c.strokeStyle='rgba(255,255,255,.8)';c.lineWidth=3;c.stroke();if(e.pfrz<.6){c.strokeStyle='#ffffff';c.lineWidth=2;c.beginPath();c.moveTo(0,-h*.2);c.lineTo(w*.18,0);c.lineTo(w*.05,h*.22);c.stroke()}
   pmSnow(c,w*.24,-h*.32,8,'#ffffff',2);c.restore()}
  else if(e.pchl>0){c.save();c.globalCompositeOperation='lighter';pGlow(c,e.x,e.y-(e.h||100)*.5,(e.h||100)*.7,'#7ff0ff',.3*Math.min(1,e.pchl));c.restore();for(let i=0;i<4;i++){const v=(t*.7+i/4)%1;c.globalAlpha=1-v;pmSnow(c,e.x-40+i*26,e.y-(e.h||100)-10+v*80,6,'#ffffff',1.6);c.globalAlpha=1}}}
 const L=PMG.fx;for(let i=L.length-1;i>=0;i--){const f=L[i];f.t+=1/60;const u=f.t/f.ml;if(u>=1){L.splice(i,1);continue}
  if(f.k==='crack'){const cx=KX+6,cy=GY-128;c.save();c.globalAlpha=1-u;for(let j=0;j<14;j++){const a=j/14*TAU,d=150+u*260,x=cx+Math.cos(a)*d,y=cy+Math.sin(a)*d*.9+u*u*160;pmCrystal(c,x,y,22*(1-u*.5),10,a+u*6,'#ffffff','#5ab8ff',2)}c.restore();pmIceShell(c,cx,cy,140*(1+u*.25),168*(1+u*.25),f.n,1-u,S.t)}
  else if(f.k==='nova'){c.save();c.globalCompositeOperation='lighter';c.translate(KX,GY-20);c.scale(1,.3);c.beginPath();c.arc(0,0,60+pS(u)*f.r,0,TAU);c.strokeStyle=`rgba(127,240,255,${.85*(1-u)})`;c.lineWidth=16*(1-u)+3;c.stroke();c.strokeStyle=`rgba(255,255,255,${.7*(1-u)})`;c.lineWidth=4;c.stroke();c.restore();
   for(let j=0;j<8;j++){const x=KX+40+(j/8)*f.r*pS(u),hh=40*(1-Math.abs(j/8-.5));c.save();c.globalAlpha=1-u;pmCrystal(c,x,GY+4,hh*(1-u*.4)+10,12,(j%2?.2:-.2),'#ffffff','#5ab8ff',2);c.restore()}}
  else if(f.k==='frz'&&f.e){c.save();c.globalAlpha=1-u;pmSnow(c,f.e.x,f.e.y-(f.e.h||80)*.5,30+u*40,'#ffffff',3);c.restore()}
  else if(f.k==='shat'){c.save();c.globalAlpha=1-u;for(let j=0;j<6;j++){const a=j/6*TAU;pmCrystal(c,f.x+Math.cos(a)*u*50,f.y+Math.sin(a)*u*50,10,5,a,'#ffffff','#5ab8ff',1.4)}c.restore()}
  else if(f.k==='grow'){const cx=KX+6,cy=GY-128;for(let j=0;j<10;j++){const a=j/10*TAU+u*2,d=(1-pS(u))*220+150,x=cx+Math.cos(a)*d,y=cy+Math.sin(a)*d*1.1;c.save();c.globalAlpha=Math.sin(u*Math.PI);pGlow(c,x,y,20,'#7ff0ff',.6);pmSnow(c,x,y,9,'#ffffff',2);c.restore()}}
  else if(f.k==='roar'){/* a wave of sunlight rolls across the battlefield */c.save();c.globalCompositeOperation='lighter';const x=f.x+pS(u)*(W-f.x+200);
   for(let j=0;j<3;j++){const v=Math.max(0,Math.min(1,u*1.3-j*.12));if(v<=0||v>=1)continue;c.beginPath();c.arc(f.x+v*(W-f.x+300)-300,GY-180,320,-1,1);c.strokeStyle=`rgba(255,${190+j*20},90,${.8*(1-v)})`;c.lineWidth=34*(1-v)+6;c.stroke();c.strokeStyle=`rgba(255,250,220,${.7*(1-v)})`;c.lineWidth=6;c.stroke()}
   const q=c.createLinearGradient(f.x,0,W,0);q.addColorStop(0,`rgba(255,200,90,${.28*(1-u)})`);q.addColorStop(1,'rgba(255,140,40,0)');c.fillStyle=q;c.fillRect(f.x,0,W-f.x,H);
   c.translate(f.x,f.y);for(let j=0;j<16;j++){const a=-.85+j*.11,Lr=(380+((j*53)%7)*60)*pS(Math.min(1,u*2.2))*(1-pS(u));c.beginPath();c.moveTo(0,0);c.lineTo(Math.cos(a-.02)*Lr,Math.sin(a-.02)*Lr);c.lineTo(Math.cos(a+.02)*Lr,Math.sin(a+.02)*Lr);c.closePath();c.fillStyle=j%2?'rgba(255,240,170,.35)':'rgba(255,170,60,.35)';c.fill()}
   c.restore();if(u<.5){pGlow(c,f.x,f.y,160*(1-u),'#ffd45a',.6*(1-u*2))}}}
 }catch(e){}return r}}

/* ---------- HUD: armor layers and the clean-word streak ---------- */
{const hd0=drawHUD;drawHUD=function(){const p=S.pet;let my=false;try{my=!!(p&&PDEF[p.id]&&(PDEF[p.id].ab.k==='permafrost'||PDEF[p.id].ab.k==='sunburst')&&S.mode!=='title')}catch(e){}
 if(!my)return hd0.apply(this,arguments);S.pet=null;let r;try{r=hd0.apply(this,arguments)}finally{S.pet=p}
 try{const c=ctx,D=PDEF[p.id],A=D.ab,x=W/2+220+52,y=H-56,R=28,yeti=A.k==='permafrost',t=S.t,arm=p.arm|0;
  c.save();c.fillStyle='#0a0618cc';c.beginPath();c.arc(x,y,R+6,0,TAU);c.fill();const rg=c.createLinearGradient(x-R,y-R,x+R,y+R);rg.addColorStop(0,'#ff4f8b');rg.addColorStop(.5,'#b04aff');rg.addColorStop(1,'#4fc8ff');c.strokeStyle=rg;c.lineWidth=2.4;c.stroke();
  let fr=0,col='#7ff0ff',lit=!p.cos;
  if(!p.cos){if(yeti){fr=arm>=2?1:(p.ready?1:p.w/A.N);col=arm>=2?'#bff6ff':'#7ff0ff'}else{fr=p.ready?1:p.w/A.N;col=p.ready?'#9fffb0':'#ffc23a';if(p.uses>=A.cap&&!p.ready){fr=0;lit=false}}
   const br=(t-(p.brk||-9));c.strokeStyle='#ffffff18';c.lineWidth=5;c.beginPath();c.arc(x,y,R+2,0,TAU);c.stroke();c.strokeStyle=br<.5?'#ff5c6c':col;c.beginPath();c.arc(x,y,R+2,-Math.PI/2,-Math.PI/2+TAU*fr);c.stroke()}
  if(p.ready||(yeti&&arm>0&&!p.cos)){const pu=.5+.5*Math.sin(t*(p.ready?6:2));pGlow(c,x,y,56,p.ready?'#9fffb0':'#7ff0ff',(p.ready?.35:.14)+.2*pu)}
  const cr=(t-(p.crT||-9));if(cr<.6){c.save();c.translate(x,y);c.translate(Math.sin(cr*60)*4*(1-cr/.6),0);c.globalAlpha=lit||p.ready?1:.45;petIcon(c,A.k,0,0,R*1.55);c.restore()}else{c.globalAlpha=lit||p.ready?1:.45;petIcon(c,A.k,x,y,R*1.55);c.globalAlpha=1}
  c.textAlign='left';c.font='600 16px Poppins,system-ui';c.fillStyle=p.cos?'#a8a2d8':p.ready?'#9fffb0':'#e8e0ff';
  let lab;if(p.cos)lab=`${petName(p.id)} (companion only)`;else if(yeti)lab=arm>=2?`${A.n}`:`${A.n} ${Math.floor(p.w)}/${A.N}`;else lab=p.ready?`${A.n}: READY`:`${A.n} ${Math.floor(p.w)}/${A.N}`;c.fillText(lab,x+R+14,y-4);
  if(!p.cos){c.font='500 13px Poppins,system-ui';if(yeti){for(let i=0;i<2;i++){const on=i<arm,cx2=x+R+22+i*20,cy2=y+14;c.save();c.translate(cx2,cy2);c.beginPath();c.moveTo(0,-8);c.lineTo(6.4,-2.6);c.lineTo(5,6);c.lineTo(-5,6);c.lineTo(-6.4,-2.6);c.closePath();c.fillStyle=on?'#bff6ff':'#2a2a50';c.fill();c.strokeStyle=on?'#ffffff':'#4a4a80';c.lineWidth=1.4;c.stroke();c.restore()}
    c.fillStyle='#c8e8ff';c.fillText(arm>=2?'Armor whole':arm===1?'1 layer left · regrowing':'Armor broken · regrowing',x+R+62,y+18)}
   else{for(let i=0;i<A.cap;i++){c.beginPath();c.arc(x+R+20+i*16,y+14,5,0,TAU);c.fillStyle=i<A.cap-p.uses?'#ffc23a':'#3a3460';c.fill()}c.fillStyle='#ffe0a8';c.fillText(p.uses>=A.cap&&!p.ready?'All roars used':'No typos!',x+R+20+A.cap*16+6,y+18)}}
  c.restore()}catch(e){}return r}}
/* ===== COMPANION POWER HOTKEY =====
   Charged companion powers no longer fire on their own: when one is READY the player unleashes it with a tap of Shift
   (on its own, so capitals never trigger it) or by clicking / tapping the power icon beside the Fury bar.
   Shields and rescues that answer a hit (Leafguard, Permafrost Armor, Last Lantern, Crystal Catch) and passive bonuses stay automatic.
   Pressing with nothing to hit gives a short hint instead of wasting the charge. */
const PM_MAN=new Set(['heartgrove','embertag','moonbind','echo','sweep','reservoir','prism','sunburst']);
const PM_KEY='Shift';
const pmManual=p=>!!(p&&!p.cos&&PDEF[p.id]&&PM_MAN.has(PDEF[p.id].ab.k));
/* can the ready power do something right now? returns '' if yes, or the reason it can't */
function pmWhyNot(p){const k=PDEF[p.id].ab.k,onScr=e=>e.x<W-10&&e.x>KX;
 if(k==='heartgrove')return S.hp>0&&S.hp<S.max?'':'You are already at full health';
 if(k==='embertag'||k==='moonbind')return petNearest()?'':'No monster in reach yet';
 if(k==='echo')return S.pj.some(j=>!j.b)?'':'No projectiles in the air';
 if(k==='sweep')return S.pj.some(j=>!j.b)||S.en.some(e=>!e.boss&&e.x<W-10)?'':'Nothing to sweep away yet';
 if(k==='reservoir')return S.fm-S.fury>=20?'':'Your Fury bar is nearly full';
 if(k==='sunburst')return S.en.some(onScr)?'':'No monsters to roar at yet';
 return ''}
function petUnleash(src){const p=S&&S.pet;if(!p||S.mode!=='play'||S.cine)return false;const D=PDEF[p.id],A=D.ab;p.tapT=S.t;
 if(p.cos){float(KX-110,GY-200,'Companion only in this mode','#c8c2f0',22);try{beep(220,.06,'triangle',.25)}catch(e){}return false}
 if(!PM_MAN.has(A.k)){float(KX-110,GY-200,`${A.n} works by itself`,'#c8c2f0',22);try{beep(260,.06,'triangle',.25)}catch(e){}return false}
 if(!p.ready){p.denyT=S.t;const left=A.k==='sunburst'?(A.cap&&p.uses>=A.cap?'All roars used':`${A.N-Math.floor(p.w)} clean words to go`):(A.cap&&p.uses>=A.cap?'No charges left this run':`${A.N-Math.floor(p.w)} words to go`);float(KX-110,GY-200,left,'#c8c2f0',22);try{beep(180,.07,'triangle',.25)}catch(e){}return false}
 if(p.go)return true;
 const why=pmWhyNot(p);if(why){p.denyT=S.t;float(KX-110,GY-200,why,'#ffd0a0',24);try{beep(200,.08,'triangle',.3)}catch(e){}return false}
 p.go=1;p.goT=S.t;if(A.k==='prism')float(KX+80,GY-240,'The next monster will be Shiny!','#fff2a0',28);
 try{beep(988,.05,'sine',.25);setTimeout(()=>beep(1318,.07,'sine',.2),50)}catch(e){}return true}
/* hold ready powers until the player asks; release them for exactly the frames after the request */
{const u0=update;update=function(dt){const p=S&&S.pet;let gate=false;
 if(p&&S.mode==='play'&&pmManual(p)&&p.ready&&!p.go){gate=true;p.ready=false}
 const r=u0.apply(this,arguments);
 if(p&&gate&&S.pet===p&&!p.ready)p.ready=true;
 if(p&&p.go&&!p.ready)p.go=0;
 if(p&&pmManual(p)&&p.ready&&p._rh!==p.pingT){p._rh=p.pingT;float(W/2+272,H-118,`${PDEF[p.id].ab.n} ready! Press ${PM_KEY}`,'#9fffb0',26)}
 return r}}
/* Shift, tapped on its own */
{let held=false,other=false;
 addEventListener('keydown',e=>{if(e.key==='Shift'){if(!e.repeat){held=true;other=false}}else if(held)other=true},true);
 addEventListener('keyup',e=>{if(e.key!=='Shift')return;const tap=held&&!other;held=false;if(tap&&S&&S.mode==='play')petUnleash('key')},true);
 addEventListener('blur',()=>{held=false})}
/* the power icon is a button: click or tap it */
const pmIcon=()=>({x:W/2+220+52,y:H-56,r:36});
function pmCanvasXY(e){const cv=ctx.canvas,b=cv.getBoundingClientRect();return[(e.clientX-b.left)/b.width*W,(e.clientY-b.top)/b.height*H]}
{const cv=ctx.canvas;
 /* caught at the window, before the canvas's own handler (a click low on the screen fires Fury there) */
 addEventListener('pointerdown',e=>{if(e.target!==cv||!S||S.mode!=='play'||!S.pet||S.cine)return;const [x,y]=pmCanvasXY(e),I=pmIcon();if(Math.hypot(x-I.x,y-I.y)>I.r)return;e.preventDefault();e.stopPropagation();ensureAudio&&ensureAudio();petUnleash('click');try{const i=document.activeElement;if(typeof inp!=='undefined'&&inp&&i!==inp)inp.focus()}catch(x){}},true);
 cv.addEventListener('pointermove',e=>{if(!S||S.mode!=='play'||!S.pet){if(cv.style.cursor==='pointer')cv.style.cursor='';return}const [x,y]=pmCanvasXY(e),I=pmIcon(),on=Math.hypot(x-I.x,y-I.y)<=I.r;cv.style.cursor=on?'pointer':''})}
/* HUD: a Shift keycap on the icon, a press flash, and a shake when it can't fire */
{const hd0=drawHUD;drawHUD=function(){const r=hd0.apply(this,arguments);try{const p=S.pet;if(!p||S.mode==='title'||!pmManual(p))return r;const c=ctx,I=pmIcon(),t=S.t,rd=p.ready;
  const dn=(t-(p.denyT||-9)),dx=dn<.4?Math.sin(dn*70)*4*(1-dn/.4):0;
  c.save();c.translate(I.x-30+dx,I.y-36);c.font='800 11px Poppins,system-ui';const tw=c.measureText('SHIFT').width+14;
  const pu=rd?.5+.5*Math.sin(t*6):0;c.beginPath();c.roundRect?c.roundRect(-tw/2,-9,tw,18,6):c.rect(-tw/2,-9,tw,18);c.fillStyle=rd?`rgba(${Math.round(150+60*pu)},255,${Math.round(170+40*pu)},1)`:'#241b58';c.fill();c.lineWidth=1.6;c.strokeStyle=rd?'#ffffff':'#6a5ac8';c.stroke();
  c.fillStyle=rd?'#0a3a1a':'#d8d0ff';c.textAlign='center';c.textBaseline='middle';c.fillText('SHIFT',0,.5);c.restore();
  const gk=(t-(p.goT||-9))/.45;if(gk>=0&&gk<1){c.save();c.globalCompositeOperation='lighter';c.beginPath();c.arc(I.x,I.y,30+gk*40,0,TAU);c.strokeStyle=`rgba(159,255,176,${1-gk})`;c.lineWidth=6*(1-gk)+1;c.stroke();c.restore()}
  }catch(e){}return r}}
/* How to play, and the companion details panel */
try{const t=HELP.Shortcuts,i=t.findIndex(r=>r[0]==='Touch');t.splice(i<0?t.length:i,0,['Shift','In battle: unleash your companion\'s power when it is READY (or click its icon beside the Fury bar).']);const tc=t.find(r=>r[0]==='Touch');if(tc&&!/companion/.test(tc[1]))tc[1]+=' Tap your companion\'s power icon to unleash it.'}catch(e){}
try{HELP.Basics.splice(4,0,['Shift',"Unleash your companion's power when its icon says READY. You can also click or tap the power icon beside the Fury bar. Shields that answer a hit, like Leafguard and Permafrost Armor, work by themselves."])}catch(e){}
{const d0=ptDetHTML;ptDetHTML=function(id){let h=d0.apply(this,arguments);try{const k=PDEF[id].ab.k,man=PM_MAN.has(k),auto=['leafguard','permafrost','lantern','catch'].includes(k);
  const note=man?`<span class="pthk"><kbd>Shift</kbd> or click its icon in battle to unleash it</span>`:auto?`<span class="pthk auto">Works by itself when you are hit</span>`:`<span class="pthk auto">Always on</span>`;
  h=h.replace(/(<div class="ptab">[\s\S]*?<small>[\s\S]*?<\/small>)/,`$1${note}`)}catch(e){}return h}}
{const st=document.createElement('style');st.textContent=`.pthk{display:flex;align-items:center;gap:6px;margin-top:6px;font:700 12px var(--ui);color:#9fffb0}.pthk.auto{color:#c4badf}
.pthk kbd{font:800 11px var(--ui);padding:1px 7px;border-radius:6px;background:#241b58;border:1.5px solid #6a5ac8;color:#e8e0ff;box-shadow:0 2px 0 #120c30}`;document.head.appendChild(st)}
