# python3 t_fx99.py [game.html] : Runestone Tower Defense 9.9p (97k): the concept-sheet redesign of the ten towers - larger models, glow
# at the light sources, particles, idle breath, squash on a shot, the build / upgrade ring - and that it stays light (Performance mode,
# lite flag, reduced motion) and that shots still leave from the art.
import asyncio,os,sys,json
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:500]),flush=True)
    if not ok:FAIL.append(name)
SETUP="()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const r=RPP();r.dragon=1;r.new99j=1;r.stars={moss:3,frost:3,ember:3};for(const k in r.tut)r.tut[k]=1;for(const k of['build','wave','coins','upgrade','abil','rune','twist_frost','twist_ember','twist_wonder'])r.tut[k]=1;save()}"
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E(SETUP)
        # the model is drawn larger: compare the painted height with and without the module
        r=await E("""()=>{const out={};const box=(off)=>{const c=document.createElement('canvas');c.width=300;c.height=320;const g=c.getContext('2d');g.translate(150,280);RPG.off=off;rpTowerDraw(g,ty,3,'base',1,{ph:.2,ghost:true});RPG.off=0;
           const d=g.getImageData(0,0,300,320).data;let top=320;for(let y=0;y<320&&top===320;y++)for(let x=0;x<300;x++)if(d[(y*300+x)*4+3]>40){top=y;break}return 280-top};let ty;
           for(ty of RP_TWORDER)out[ty]=+(box(0)/box(1)).toFixed(3);return out}""")
        chk('every tower is drawn about 15% larger (ratio of painted heights 1.08-1.25)',all(1.08<=v<=1.25 for v in r.values()),r)
        r=await E("()=>[RPG.k,+(rpTowerTop('ballista',3)/RPLAY.ballista[3].top).toFixed(3)]")
        chk('rpTowerTop grows with the model, so beams and the overcharge sit on the art',abs(r[1]-r[0])<.001,r)
        # glow and particles
        r=await E("""()=>{const res={};for(const ty of RP_TWORDER){const L=RPG_SRC[ty];res[ty]=[1,2,3,4,5].map(t=>(L[t]||[]).length)}return [res,Object.keys(RPG_PAR).length,RPG_GL.size>=0]}""")
        chk('glow sources are listed for every tower (ballista from tier 4) and particles for all ten',all(sum(v)>0 for v in r[0].values()) and r[1]==10,r)
        r=await E("""()=>{const c=document.createElement('canvas');c.width=400;c.height=400;const g=c.getContext('2d');let n=0;const d0=g.drawImage;g.drawImage=function(){n++;return d0.apply(this,arguments)};
           const cnt=(ty,t)=>{n=0;g.save();g.translate(200,330);rpgParts(g,ty,5,'base',t,{ph:.3},1);g.restore();return n};return RP_TWORDER.map(ty=>[ty,cnt(ty,1.3)+cnt(ty,2.7)])}""")
        chk('every tower shows particles at tier 5 (embers, glints, sparks, motes, bubbles, smoke, twinkles)',all(v>0 for _,v in r),r)
        # quality: Performance mode, lite flag, reduced motion
        r=await E("""()=>{const q=[];const old=ST.perf;ST.perf='low';q.push(rpgQ());ST.perf='bal';q.push(rpgQ());ST.perf=old;q.push(rpgQ());return q}""")
        chk('Performance mode turns particles off, Balanced keeps about 60%, Quality all',r[0]==0 and abs(r[1]-.6)<.01 and r[2] in (0,1),r)
        r=await E("""()=>{rpStart('moss');RPX.tut=null;RPX.lite=1;const a=rpgQ();RPX.lite=0;const b=rpgQ();rpLeave();return [a,b]}""")
        chk('the tower defense lite flag (slow device) turns particles off',r[0]==0,r)
        # icons get glow, no particles; skins recolour the glow
        r=await E("()=>{RPG_ICON=1;const q=RPG_ICON||0;RPG_ICON=0;return [q,rpgCol('brazier','azure','#ff9a3a'),rpgCol('bell','thunderking','#ffd45a'),rpgCol('frost','base','#8ae6ff')]}")
        chk('skins recolour the glow (Azure Blazer blue), gold bells stay gold',r[1:]==['#6ab8ff','#ffd45a','#8ae6ff'],r)
        # battle: shots leave from the art, the build / upgrade ring, frame cost
        r=await E("""()=>{rpStart('moss');const R=RPX;R.tut=null;R.supply=1e6;const cov=p=>{let n=0;for(const q of R.G.U){if((q.x-p.x)**2+((q.y-p.y)/.75)**2<160*160)n++}return n};const pd=[...R.pads].sort((a,b)=>cov(b)-cov(a))[0];
           rpBuild(pd,'bell');const tw=pd.tw;tw.build=1;tw.tier=3;tw.upK=1;R.wave=4;rpWaveStart();const n0=(R.arcs||[]).length;let o=null;
           for(let i=0;i<30*25&&!o;i++){const k0=(R.arcs||[]).length;rpStep(R,1/30);if((R.arcs||[]).length>k0)o=R.arcs[k0]}
           const dy=o&&o.pts?Math.round(o.pts[0].y-tw.y):null;rpLeave();return dy}""")
        chk('the Storm Bell lightning starts at the scaled bell (92 x 1.15 = 106 above the pad)',r is not None and abs(r+106)<=2,r)
        r=await E("""()=>{rpStart('moss');const R=RPX;R.tut=null;R.supply=1e6;const pd=R.pads[0];rpBuild(pd,'frost');const tw=pd.tw;for(let i=0;i<120;i++){rpUpdate(1/30);rpDraw()}
           const a=[tw.build>=1,tw._gR!=null];rpUpgrade(tw);for(let i=0;i<120;i++){rpUpdate(1/30);rpDraw()}a.push(tw.tier,tw._gT);rpLeave();return a}""")
        chk('building and upgrading a tower start the ground ring',r[0] and r[1] and r[2]==2 and r[3]==2,r)
        r=await E("""()=>{rpStart('frost');const R=RPX;R.tut=null;R.supply=1e6;R.lite=0;const T=RP_TWORDER;R.pads.forEach((pd,i)=>{rpBuild(pd,T[i%T.length]);pd.tw.build=1;pd.tw.tier=1+(i%5);pd.tw.upK=1});R.wave=8;rpWaveStart();for(let i=0;i<90;i++)rpStep(R,1/30);
           const c=ctx,tws=R.pads.filter(p=>p.tw).map(p=>p.tw),NN=120,run=f=>{for(let i=0;i<10;i++)for(const tw of tws)f(tw);let t0=performance.now();for(let i=0;i<NN;i++)for(const tw of tws){c.save();c.translate(tw.x,tw.y);f(tw);c.restore()}return (performance.now()-t0)/NN};
           const fx=run(tw=>{rpgGlows(c,tw.type,tw.tier,tw.skin,R.t,{ph:tw.ph});rpgParts(c,tw.type,tw.tier,tw.skin,R.t,{ph:tw.ph},1)});
           const mdl=run(tw=>{RPG_D++;try{rpTowerDraw(c,tw.type,tw.tier,tw.skin,R.t,{ph:tw.ph,aim:tw.aim})}finally{RPG_D--}});rpLeave();return [+fx.toFixed(3),+mdl.toFixed(3),tws.length]}""")
        chk('glow and particles for a full map of towers cost a small part of the towers themselves (under 35%, under 2 ms here)',r[0]<r[1]*.35 and r[0]<2,r)
        await pg.screenshot(path=os.path.join(HERE,'shots','fx99_battle.png'))
        chk('no page errors',not er,er)
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
