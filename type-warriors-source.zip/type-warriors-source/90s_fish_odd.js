/* ===== MOONLIT FISHING update 7: odd catches, bottle pages, Lighthouse Cove ===== */
/* Not every bite is a fish. Now and then the line brings up an old boot (1 in 80 casts), a message in a bottle (1 in 120),
   a sunken chest (1 in 250) or a lost ring (1 in 600). They are reeled in with words from a treasure list and land through
   the normal catch flow (each has a FISHART entry from 90s2 and a FISH entry that is NOT in FIDS, so no bestiary or bounty
   counts them), then show their own card. Bottles carry the 4 pages of the lighthouse keeper's story; the 4th page opens the
   secret spot, Lighthouse Cove (1 in 50 casts while pages are missing, and one is guaranteed after 80 dry casts). Rings are returned to their owners at the Tavern Bounty Board ("Lost & Found"); ten boots earn
   the "Bootlegger" title. Save: P.fish.odd {boot,bottle,chest,ring,pg,rings:[owner],ret:[owner],gold,title}. */
const FSODD={
 boot:{n:'Old Boot',p:1/80,rk:'c',c:'#b89a6a',d:'Soggy, smelly and very much not a fish.'},
 bottle:{n:'Message in a Bottle',p:1/120,rk:'u',c:'#7affc8',d:'A corked green bottle with a rolled-up page inside.'},
 chest:{n:'Sunken Chest',p:1/250,rk:'r',c:'#ffc23a',d:'Barnacled, heavy, and it rattles when you shake it.'},
 ring:{n:'Lost Ring',p:1/600,rk:'r',c:'#ff9ae0',d:'A gold ring with an engraving. Someone must be missing it.'}};
const FSODDK=['boot','bottle','chest','ring'];
FSODDK.forEach(k=>{const O=FSODD[k];FISH['odd'+k]={n:O.n,r:O.rk,len:k==='boot'?[24,34]:k==='bottle'?[20,30]:k==='chest'?[40,60]:[2,3],v:k==='boot'?1:0,w:0,odd:k,d:O.d}});
/* treasure words for the reel (short for boots and bottles, longer for chests and rings) */
const FSODDW=[['anchor','cork','coin','rope','sail','gull','pearl','kelp','mast','keel','crab','shell','tide','reef','salt','buoy','oar','dock'],
 ['lantern','compass','doubloon','galleon','seaweed','treasure','captain','harbour','cutlass','sextant','spyglass','barnacle','parchment','shipwreck','lighthouse']];
const FSPAGES=[
 'Day 1. I am Elias Thornwick, keeper of the Stormreach light. Each night I trim the wick and watch the sea. Tonight the water under the cliff glowed back at me, and the fish followed the glow like sheep follow a shepherd.',
 'Day 23. A storm drove the merchant ship Gilded Gull onto the reef. I lit every lamp I had, and every sailor reached the hidden cove beneath my lighthouse alive. No map shows it. Only lamplight finds it.',
 'To whoever finds this: the old lighthouse keeper never left Stormreach. On the night of the new moon, cast where his lamp still glows…',
 'Tucked behind the last page is a rough map: a lighthouse, a ring of rocks, a rickety pier… and an X where the beam meets the water. You know where to go now.'];
const FSPGN=FSPAGES.length;
const FSPAGEBY=['Elias Thornwick','Elias Thornwick','an unknown hand','a hand-drawn map'];
const FSNOTES=['"Day 41. My lamp is failing. I have been teaching the green light to carry it. It is a fish, and yet it waits for me at the steps each night." — E.T.','"Last entry. If my lamp goes dark, the light below will keep it burning. Bring a patient line and a kind heart." — E.T.','A keeper\'s shopping list: lamp oil, three candles, sardines (for the green light).','A child\'s drawing of a glowing fish carrying a lantern.','"The beam turns once a minute. The fish turn with it." — E.T.','A recipe for fish stew, with "NOT the green one!" underlined twice.','A sailor\'s thank-you note: "To the keeper of the cove, for my life."'];
/* until the cove is found, bottles bite more often (1 in 50 casts) and one is guaranteed after 80 casts without one */
const FSBOTP=1/50,FSBOTPITY=80;
const FSRINGS=[
 {n:'Old Bertha the cook',e:'To my Bertie, forty years and counting',g:250,gift:{worm:10},thx:'Bertha bursts into happy tears and sends you a pie and ten casts of Glow Worms.'},
 {n:'Captain Rook',e:'Fair winds — R.',g:300,gift:{moth:10},thx:'The old captain salutes you and hands over ten Moonmoth Lures from his sea chest.'},
 {n:'Lyra the bard',e:'Sing true, my love',g:280,gift:{shrimp:10},thx:'Lyra writes a song about you on the spot, and adds ten casts of Frost Shrimp.'},
 {n:'Sir Percival',e:'Courage, always',g:300,gift:{spore:10},thx:'Sir Percival bows deeply and gives you ten casts of Glowcap Spores.'},
 {n:'Mira the miller',e:'Mira & Tobin, forever',g:250,gift:{roe:4},thx:'Mira hugs you so hard your hat falls off, then gives you four Starlight Roe.'},
 {n:'The Mayor of Stormreach',e:'Property of the Mayor. Do NOT lose again.',g:400,gift:{roe:8},thx:'The Mayor pretends he never lost it, and quietly pays you well, plus eight Starlight Roe.'}];
function fsOddP(){const F=fsP();if(!F.odd||typeof F.odd!=='object')F.odd={};const O=F.odd;FSODDK.forEach(k=>O[k]=O[k]|0);O.pg=Math.min(FSPGN,O.pg|0);O.rings=Array.isArray(O.rings)?O.rings:[];O.ret=Array.isArray(O.ret)?O.ret:[];O.gold=O.gold|0;return O}
const fsCoveOpen=()=>fsOddP().pg>=FSPGN;
/* the secret spot opens with the eighth page, not with species */
function fsLocOpen(k){const L=FSLOCS[k];if(!L||L.soon)return false;if(L.secret)return!!(P.fish&&fsOddP().pg>=FSPGN);return fsFound()>=L.need}
/* ---------- rolling an odd catch (never in the first casts, never during the tutorial) ---------- */
let FSODDSCALE=1;
function fsOddRoll(rnd){rnd=rnd||Math.random;const F=fsP();if((F.s.cast||0)<8)return null;const O=fsOddP(),hunt=O.pg<FSPGN;let x=rnd();
 if(hunt){O.dry=(O.dry|0)+1;if(O.dry>=FSBOTPITY)x=FSODD.boot.p*FSODDSCALE+1e-9}
 for(const k of FSODDK){const p=(k==='bottle'&&hunt?FSBOTP:FSODD[k].p)*FSODDSCALE;if(x<p){const id='odd'+k,f=FISH[id];if(k==='bottle')O.dry=0;return{id,rk:FSODD[k].rk,cm:Math.round((f.len[0]+(f.len[1]-f.len[0])*rnd())*10)/10,g:false,odd:k}}x-=p}return null}
{const r0=fsRoll;fsRoll=function(rnd){if(FS.on&&!FS.tut){const o=fsOddRoll();if(o)return o}return r0.apply(this,arguments)}}
{const w0=fsWords;fsWords=function(rk){const c=FS.cur;if(c&&c.odd&&(FS.st==='wait'||FS.st==='reel'||FS.st==='stage'||FS.st==='cast')){const st=FSR[rk].st,L=FSODDW[c.odd==='chest'||c.odd==='ring'?1:0],out=[];for(let i=0;i<st;i++){const p=L.filter(w=>!out.includes(w));out.push(p[Math.random()*p.length|0])}return out}return w0.apply(this,arguments)}}
/* "Something's on the line… not a fish!" bubble by the bobber */
{const b0=fsBite;fsBite=function(){const r=b0.apply(this,arguments);try{const c=FS.cur;if(c&&c.odd){if(FS.words&&FS.words.length&&!FSODDW[0].includes(FS.words[0])&&!FSODDW[1].includes(FS.words[0])){FS.words=fsWords(c.rk);fsWord()}fsOddBubble()}}catch(e){console.error(e)}return r}}
function fsOddBubble(){const x=$('fsx');if(!x||!FS.bob)return;let b=$('fsodb');if(!b){b=document.createElement('div');b.id='fsodb';b.className='fsodb';x.appendChild(b)}
 b.textContent='Something\'s on the line… not a fish!';b.style.left=Math.max(260,Math.min(1100,FS.bob.x))+'px';b.style.top=Math.max(200,FS.bob.y-150)+'px';b.classList.remove('on');void b.offsetWidth;b.classList.add('on');clearTimeout(b._t);b._t=setTimeout(()=>b.classList.remove('on'),2200)}
/* odd catches never enter the bestiary, stats or bounties */
{const r0=fsRecord;fsRecord=function(c){if(c&&c.odd)return{first:false,record:false,rel:0};return r0.apply(this,arguments)}}
{const b0=fsBanner;fsBanner=function(t,sub,col,dur,rk){try{const S0=FS.show;if(FS.st==='show'&&S0&&S0.c&&S0.c.odd){const O=FSODD[S0.c.odd];return b0.call(this,'An odd catch!',O.n,O.c,1.4,'')}}catch(e){}return b0.apply(this,arguments)}}
{const e0=fsEscape;fsEscape=function(){const c=FS.cur,odd=c&&c.odd;const r=e0.apply(this,arguments);if(odd)try{fsBanner('It slipped away…','Whatever it was sank back into the deep.','#c4badf',1.6)}catch(e){}return r}}
/* ---------- landing: apply the reward and show the card ---------- */
{const v0=fsReveal;fsReveal=function(){const S0=FS.show;if(S0&&S0.c&&S0.c.odd){const c=S0.c;FS.show=null;FS.pend=null;let R;try{R=fsOddGive(c.odd)}catch(e){console.error(e);R={t:'',lines:[]}}FS.odd={c,R};fsSet('odd');try{fsOddCard(c,R)}catch(e){console.error(e)}return}return v0.apply(this,arguments)}}
function fsOddGive(k){const O=fsOddP(),F=fsP();O[k]++;let R={k,gold:0,lines:[]};
 if(k==='boot'){P.gold+=1;R.gold=1;R.lines.push(`Boots fished: <b>${O.boot}</b>${O.boot<10?` / 10 toward the “Bootlegger” title`:''}`);if(O.boot===10){O.title='Bootlegger';R.title=1}}
 else if(k==='bottle'){if(O.pg<FSPGN){O.pg++;R.page=O.pg;if(O.pg===FSPGN){R.cove=1;FS.unlockNote='cove'}}else{const g=40;P.gold+=g;R.gold=g;R.note=FSNOTES[(O.bottle-FSPGN-1+FSNOTES.length*10)%FSNOTES.length]}}
 else if(k==='chest'){const x=Math.random();if(x<.6){const g=80+Math.round(Math.random()*12)*10;P.gold+=g;R.gold=g;R.lines.push(`<b>${g}</b> gold coins, still shiny`)}
  else{const B=typeof fsBaitP==='function'?fsBaitP():null;const pool=x<.85?['worm','moth','shrimp','spore'].filter(b=>!FSBAIT[b].loc||fsLocOpen(FSBAIT[b].loc)):['roe'];const b=pool[Math.random()*pool.length|0],n=b==='roe'?6:10;
   if(B){B.inv[b]=(B.inv[b]||0)+n;if(!B.on)B.on=b}const g=b==='roe'?50:30;P.gold+=g;R.gold=g;R.bait={k:b,n};R.lines.push(`A crate of <b>${n} ${FSBAIT[b].n}</b>`,`<b>${g}</b> gold coins`)}}
 else if(k==='ring'){const left=FSRINGS.map((r,i)=>i).filter(i=>!O.rings.includes(i)&&!O.ret.includes(i));if(left.length){const i=left[0];O.rings.push(i);R.owner=i}else{P.gold+=250;R.gold=250;R.lines.push('Nobody is missing it any more. The tavern buys it for <b>250</b> gold.')}}
 O.gold+=R.gold;if(R.gold){fsSt('gold',R.gold,'add')}save();return R}
function fsOddCard(c,R){const x=$('fsx');if(!x)return;const k=c.odd,O=FSODD[k],P0=fsOddP();let body='',art='';
 if(k==='bottle'&&R.page){body=`<div class="fsod-pg"><canvas width="520" height="250" id="fsodpc" aria-hidden="true"></canvas><p>“${fsEsc(FSPAGES[R.page-1])}”</p><em>— page ${R.page} of ${FSPGN} · ${FSPAGEBY[R.page-1]}</em></div>
  <p class="fsod-s">${R.cove?'<b>The last page!</b> A secret fishing spot is waiting: <b>Lighthouse Cove</b>. Find it on the Fishing Spots map.':`Collect all ${FSPGN} pages to find a secret spot with its own Mythic. <b>${R.page} / ${FSPGN}</b> found.`}</p>`}
 else if(k==='bottle')body=`<div class="fsod-pg"><canvas width="520" height="250" id="fsodpc" aria-hidden="true"></canvas><p>${fsEsc(R.note||'')}</p><em>— a keeper's note · +${R.gold} gold</em></div>`;
 else if(k==='ring'&&R.owner!=null){const r=FSRINGS[R.owner];body=`<p class="fsod-eng">Engraved inside: <i>“${fsEsc(r.e)}”</i></p><p class="fsod-s">It belongs to <b>${r.n}</b>. Return it at the <b>Tavern Bounty Board</b> (Lost &amp; Found) for a reward.</p>`}
 else body=`<ul class="fsod-l">${R.lines.map(l=>`<li>${l}</li>`).join('')}</ul>${R.title?'<p class="fsod-s"><b>Title earned: “Bootlegger”!</b> It shows in your Trophy Hall.</p>':''}`;
 let d=$('fsod');if(!d){d=document.createElement('div');d.id='fsod';x.appendChild(d)}
 d.className='fsod fsg k-'+k;d.style.setProperty('--oc',O.c);d.setAttribute('role','dialog');d.setAttribute('aria-label',O.n);
 d.innerHTML=`<span class="fsod-tag">Odd catch</span><canvas class="fsod-art" width="300" height="190" id="fsodart" aria-hidden="true"></canvas><h3>${O.n}</h3><p class="fsod-d">${fsEsc(O.d)}</p>${body}
  <button class="fsod-ok" id="fsodok">${R.cove?'Wonderful!':'Collect'} <kbd>Space</kbd></button>`;
 const cv=$('fsodart'),g=cv.getContext('2d');live('fsodart',()=>t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,300,190);fkGlow(g,150,95,110,O.c,.18);fishFit(g,c.id,150,96+Math.sin(t*1.6)*4,270,170,{t,glow:.3})});
 const pc=$('fsodpc');if(pc){const pg=pc.getContext('2d');if(typeof odPageArt==='function')odPageArt(pg,520,250,0);else{pg.fillStyle='#f2e2bc';pg.fillRect(0,0,520,250)}}
 $('fsodok').onclick=fsOddDone;try{fsSfx(k==='chest'||k==='ring'?'r':k==='bottle'?'u':'c')}catch(e){}
 setTimeout(()=>{const b=$('fsodok');try{b&&b.focus({preventScroll:true})}catch(e){}},60)}
function fsOddDone(){if(FS.st!=='odd')return;const d=$('fsod');if(d)d.remove();const R=FS.odd&&FS.odd.R;FS.odd=null;try{fsHudRefresh()}catch(e){}fsSet('idle');
 if(R&&R.cove){try{fsBanner('Lighthouse Cove found!','The keeper\'s lamp flickers on. Open Fishing Spots (M) to go there.','#ffcf6a',3.2)}catch(e){}try{fsSfx('l2')}catch(e){}FS.unlockNote=null}}
window.addEventListener('keydown',e=>{if(S.mode!=='fish'||FS.st!=='odd'||e.ctrlKey||e.metaKey||e.altKey)return;if(e.key===' '||e.key==='Enter'){e.preventDefault();e.stopImmediatePropagation();if(!e.repeat)fsOddDone()}},true);
/* ---------- Lost & Found on the bounty board ---------- */
function fsRingReturn(i){const O=fsOddP(),j=O.rings.indexOf(i);if(j<0)return null;const r=FSRINGS[i];O.rings.splice(j,1);O.ret.push(i);P.gold+=r.g;fsSt('gold',r.g,'add');
 const B=typeof fsBaitP==='function'?fsBaitP():null;if(B)for(const [b,n] of Object.entries(r.gift)){B.inv[b]=(B.inv[b]||0)+n;if(!B.on)B.on=b}save();return r}
{const m0=fsBountyModal;fsBountyModal=function(from){const r=m0.apply(this,arguments);try{const O=fsOddP();if(!O.rings.length)return r;const box=document.querySelector('.fsbb');if(!box)return r;
  const s=document.createElement('div');s.className='fsbb-lf';s.innerHTML=`<h4>Lost &amp; Found</h4>${O.rings.map(i=>{const R=FSRINGS[i];return `<div class="fsbb-lfr"><canvas width="70" height="46" data-ring aria-hidden="true"></canvas><span><b>Ring for ${fsEsc(R.n)}</b><small>“${fsEsc(R.e)}”</small></span><button data-rret="${i}">Return it · ${fsCoin}${R.g} + a gift</button></div>`}).join('')}`;
  const ft=box.querySelector('.fsbb-ft');box.insertBefore(s,ft);s.querySelectorAll('canvas[data-ring]').forEach(cv=>fishFit(cv.getContext('2d'),'oddring',35,23,66,42,{t:.4}));
  s.querySelectorAll('[data-rret]').forEach(b=>b.onclick=()=>{const R=fsRingReturn(+b.dataset.rret);if(!R)return;try{fsSfx('buy');setTimeout(()=>fsSfx('r'),200)}catch(e){}b.parentNode.innerHTML=`<p class="fsbb-thx">${fsEsc(R.thx)} <b>+${R.g} gold</b></p>`;try{fsHudRefresh();const gd=$('fsgold');if(gd)gd.textContent=P.gold.toLocaleString()}catch(e){}})}catch(e){console.error(e)}return r}}
/* ---------- achievements for the odd catches ---------- */
FSACH.push({k:'boot',m:'catch',n:'Bootlegger',d:'Fish up 10 old boots',g:10,v:()=>fsOddP().boot,rw:100},
 {k:'pages',m:'bounty',n:'Message Received',d:`Collect all ${FSPGN} bottle pages`,g:FSPGN,v:()=>fsOddP().pg,rw:500},
 {k:'ringret',m:'gold',n:'Good Samaritan',d:'Return a lost ring',g:1,v:()=>fsOddP().ret.length,rw:150},
 {k:'chests',m:'gold',n:'Treasure Hunter',d:'Haul up 3 sunken chests',g:3,v:()=>fsOddP().chest,rw:200});
/* ---------- the Trophy Hall's Curios tab: pages, boots, chests, rings ---------- */
function fsCurHTML(){const O=fsOddP();
 return `<div class="ftr-cur"><section class="ftr-pages"><h4>The Keeper's Pages <small>${O.pg} / ${FSPGN}</small></h4><div class="ftr-pgl">${FSPAGES.map((p,i)=>i<O.pg?`<button class="ftr-pgb" data-pg="${i}"><b>${i+1}</b><span>${fsEsc(p.slice(0,58))}…</span></button>`:`<div class="ftr-pgb no"><b>${i+1}</b><span>A page still lost at sea</span></div>`).join('')}</div>
  <p class="ftr-pgn">${O.pg>=FSPGN?'You found every page. Lighthouse Cove is yours to fish.':`Message bottles bite about once in ${Math.round(1/FSBOTP)} casts (one is guaranteed within ${FSBOTPITY} casts). Each holds the next page.`}</p></section>
  <section class="ftr-odds">${FSODDK.map(k=>`<div class="ftr-odd" style="--oc:${FSODD[k].c}"><canvas width="120" height="80" data-oddart="odd${k}" aria-hidden="true"></canvas><span><b>${FSODD[k].n}</b><small>${O[k]} found · ${k==='boot'?(O.title?'Title: Bootlegger':`${Math.min(O.boot,10)} / 10 toward Bootlegger`):k==='ring'?`${O.ret.length} returned${O.rings.length?` · ${O.rings.length} waiting at the board`:''}`:k==='chest'?'gold, crates and rare bait':'pages and keeper\'s notes'}</small></span><em>1 in ${Math.round(1/(k==='bottle'&&O.pg<FSPGN?FSBOTP:FSODD[k].p))}</em></div>`).join('')}
   <p class="ftr-pgn">Gold from odd catches: <b>${O.gold.toLocaleString()}</b>${O.title?` · <b class="ftr-title">“${O.title}”</b>`:''}</p></section></div>`}
function fsCurBind(){ov.querySelectorAll('canvas[data-oddart]').forEach(cv=>fishFit(cv.getContext('2d'),cv.dataset.oddart,60,40,112,74,{t:.4}));
 ov.querySelectorAll('[data-pg]').forEach(b=>b.onclick=()=>{const i=+b.dataset.pg;fsU6Modal(`<div class="fsod fsg k-bottle fsod-m" style="--oc:#7affc8"><button class="fsx2" id="fsx2" aria-label="Close">✕</button><h3>Page ${i+1} of ${FSPGN}</h3><div class="fsod-pg"><canvas width="520" height="250" id="fsodpc" aria-hidden="true"></canvas><p>“${fsEsc(FSPAGES[i])}”</p><em>— ${FSPAGEBY[i]}</em></div></div>`,'trophy');const pc=$('fsodpc');if(pc){const pg=pc.getContext('2d');if(typeof odPageArt==='function')odPageArt(pg,520,250,0);else{pg.fillStyle='#f2e2bc';pg.fillRect(0,0,520,250)}}})}
/* ---------- Fishing Spots: the secret card stays a mystery until the eighth page ---------- */
{const s0=fsdgState;fsdgState=function(k){const s=s0.apply(this,arguments);if(s.L&&s.L.secret){s.secret=1;s.pg=fsOddP().pg}return s}}
{const c0=fsdgCard;fsdgCard=function(k,i){let h=c0.apply(this,arguments);const L=FSLOCS[k];if(!L||!L.secret||fsCoveOpen())return h;const pg=fsOddP().pg;
  h=h.replace(/<span class="fsdg-info">[\s\S]*<\/span><\/button>$/,`<span class="fsdg-info"><b>???</b><small>A secret spot, somewhere beyond the waves.</small><em>Collect ${FSPGN} bottle pages</em><i class="fsdg-bar lk" aria-hidden="true"><i style="width:${pg/FSPGN*100}%"></i></i><span class="fsdg-sub">${pg} / ${FSPGN} pages found</span></span></button>`)
   .replace(/<span class="fsdg-ban lk">[\s\S]*?<\/span>/,`<span class="fsdg-ban lk">${FSDGLOCK}Secret</span>`).replace(/aria-label="[^"]*"/,`aria-label="A secret spot. Collect ${FSPGN} bottle pages to find it. ${pg} of ${FSPGN} found."`);return h}}
{const p0=fsdgPanel;fsdgPanel=function(){let h=p0.apply(this,arguments);const k=FSDG.sel,L=FSLOCS[k];if(!L||!L.secret||fsCoveOpen())return h;const pg=fsOddP().pg;
  return h.replace(/<h3>[\s\S]*?<\/h3>/,'<h3>A secret spot</h3>').replace(/<p>[^<]*<\/p>/,'<p>Message bottles sometimes drift onto your line. Their pages tell where the keeper\'s lamp still glows.</p>').replace(/<p class="fsdg-pst">[\s\S]*?<\/p>/,`<p class="fsdg-pst">Collect all <b>${FSPGN}</b> bottle pages to find this spot.</p>`).replace(/<div class="fsdg-prow">[\s\S]*?<\/i><\/i><\/div>/,'').replace(/(bottle pages to find this spot\.)/,`$1 <b>${pg} / ${FSPGN}</b> found.`)}}
/* a hidden card shows the cove as a dark, foggy mystery (cached once; replaced when the cove opens) */
{const a0=fsdgArt;fsdgArt=function(k){const L=FSLOCS[k];if(!L||!L.secret)return a0.apply(this,arguments);const key=fsCoveOpen()?'cove':'cove?';if(FSDG.art[key])return FSDG.art[key];
  let c;if(!FSLOCART.cove){c=document.createElement('canvas');c.width=738;c.height=800;const g=c.getContext('2d');g.fillStyle=fkLin(g,0,0,0,800,['#0a1430','#081022','#04060f']);g.fillRect(0,0,738,800)}else{delete FSDG.art[k];c=a0.call(this,k);delete FSDG.art[k]}
  if(key==='cove?'){const m=document.createElement('canvas');m.width=738;m.height=800;const g=m.getContext('2d');g.drawImage(c,0,0);g.fillStyle='rgba(6,8,22,.72)';g.fillRect(0,0,738,800);
   for(let i=0;i<5;i++){const y=260+i*90,gr=g.createLinearGradient(0,y-60,0,y+60);gr.addColorStop(0,'rgba(140,160,200,0)');gr.addColorStop(.5,'rgba(140,160,200,.16)');gr.addColorStop(1,'rgba(140,160,200,0)');g.fillStyle=gr;g.fillRect(0,y-60,738,120)}
   fkGlow(g,369,250,120,'#ffcf6a',.22);g.font="400 220px 'Pirata One',Georgia,serif";g.textAlign='center';g.textBaseline='middle';g.lineWidth=12;g.strokeStyle='#12081f';g.strokeText('?',369,300);g.fillStyle='#ffcf6a';g.fillText('?',369,300);c=m}
  return FSDG.art[key]=c}}
/* five cards: a little narrower */
{const st=document.createElement('style');st.textContent=`
.fsdg:not(.fsdg-m):not(.fsdg-s) .fsdg-cards{grid-template-columns:repeat(5,1fr);gap:16px}
.fsdg:not(.fsdg-m):not(.fsdg-s) .fsdg-ban{top:228px}.fsdg:not(.fsdg-m):not(.fsdg-s) .fsdg-info em{font-size:16px;white-space:nowrap}
.fsdg:not(.fsdg-m):not(.fsdg-s) .fsdg-card .fsdg-info b{font-size:36px}.fsdg:not(.fsdg-m):not(.fsdg-s) .fsdg-card .fsdg-info small{font-size:14px}
.fsodb{position:absolute;z-index:4;transform:translate(-50%,-100%) scale(.6);opacity:0;padding:10px 18px;border-radius:18px;background:linear-gradient(180deg,#bff4ff,#7ad8ff);border:3px solid #1b1024;color:#0a1a3a;font:800 18px var(--ui);white-space:nowrap;box-shadow:0 6px 0 #1b1024a0;pointer-events:none;transition:transform .35s var(--sp),opacity .25s}
.fsodb::after{content:'';position:absolute;left:50%;bottom:-14px;margin-left:-10px;border:10px solid transparent;border-top:14px solid #1b1024}
.fsodb.on{opacity:1;transform:translate(-50%,-100%) scale(1)}
.fsod{position:absolute;left:50%;top:50%;z-index:5;width:620px;max-height:820px;transform:translate(-50%,-50%);display:flex;flex-direction:column;align-items:center;gap:6px;padding:22px 26px 20px;border-color:var(--oc);text-align:center;color:#fff8e8;animation:fsOdIn .45s var(--sp) both}
@keyframes fsOdIn{0%{opacity:0;transform:translate(-50%,-44%) scale(.86)}100%{opacity:1;transform:translate(-50%,-50%) scale(1)}}
.fsod-m{position:relative;left:auto;top:auto;transform:none;animation:fsWb .35s var(--sp) both}
.fsod-tag{position:absolute;top:-14px;left:50%;transform:translateX(-50%);padding:4px 14px;border-radius:10px;background:var(--oc);color:#1b1024;font:800 12px var(--ui);letter-spacing:.12em;text-transform:uppercase;border:2px solid #1b1024}
.fsod-art{width:300px;height:190px}.fsod h3{margin:0;font:400 40px/1 'Pirata One',Georgia,serif;color:var(--oc);text-shadow:0 3px 0 #1b1024}
.fsod-d{margin:0;font:500 15px var(--ui);color:#cfc6ee}
.fsod-pg{position:relative;width:520px;height:250px;margin:6px 0 2px}.fsod-pg canvas{position:absolute;inset:0;width:520px;height:250px}
.fsod-pg p{position:relative;margin:0;padding:34px 40px 0;font:italic 500 19px/1.45 Georgia,serif;color:#3a2414;text-align:left}
.fsod-pg em{position:absolute;right:40px;bottom:26px;font:700 13px var(--ui);color:#6a4a2a;font-style:normal}
.fsod-s,.fsod-eng{margin:6px 0 0;font:500 15px var(--ui);color:#e8e0ff;max-width:540px}.fsod-s b,.fsod-eng b{color:var(--oc)}.fsod-eng i{color:#ffe9a0}
.fsod-l{list-style:none;margin:6px 0 0;padding:0;font:600 17px var(--ui);color:#fff8e8}.fsod-l li{margin:3px 0}.fsod-l b{color:#ffd45a}
.fsod-ok{margin-top:12px;height:54px;padding:0 26px;border-radius:16px;border:3px solid #1b1024;background:linear-gradient(180deg,#ffe27a,#f2b631);color:#3a2006;font:800 20px var(--ui);display:flex;align-items:center;gap:10px;cursor:pointer;box-shadow:0 4px 0 #9a6a10}
.fsod-ok:hover{transform:translateY(-2px)}
.fsbb-lf{margin-top:12px;padding:10px 14px;border-radius:14px;background:#1b1024cc;border:2px solid #ff9ae066}
.fsbb-lf h4{margin:0 0 6px;font:400 26px 'Pirata One',Georgia,serif;color:#ff9ae0}
.fsbb-lfr{display:flex;align-items:center;gap:12px;padding:4px 0}.fsbb-lfr canvas{width:70px;height:46px}.fsbb-lfr span{flex:1;display:flex;flex-direction:column}.fsbb-lfr b{font:800 15px var(--ui);color:#fff8e8}.fsbb-lfr small{font:italic 500 13px Georgia,serif;color:#ffe9a0}
.fsbb-lfr button{height:40px;padding:0 14px;border-radius:11px;border:2px solid #1b1024;background:linear-gradient(180deg,#ffb0ec,#e85ac0);color:#2a0620;font:800 14px var(--ui);display:flex;align-items:center;gap:4px;cursor:pointer}
.fsbb-thx{margin:4px 0;font:600 14px var(--ui);color:#f4e4c8}.fsbb-thx b{color:#ffd45a}
.ftr-cur{display:grid;grid-template-columns:1fr 1fr;gap:20px;height:100%}
.ftr-pages,.ftr-odds{padding:14px 18px;border-radius:20px;background:linear-gradient(180deg,#221a5aee,#100a30f4);border:2px solid #3a3070;display:flex;flex-direction:column;gap:8px;align-self:start}
.ftr-pages h4{margin:0;font:400 30px 'Pirata One',Georgia,serif;color:var(--gold)}.ftr-pages h4 small{font:700 14px var(--ui);color:#c4badf}
.ftr-pgl{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.ftr-pgb{display:flex;align-items:center;gap:10px;min-height:62px;padding:6px 10px;border-radius:12px;border:2px solid #1b1024;background:linear-gradient(180deg,#f6e8c4,#e2c890);color:#3a2414;text-align:left;cursor:pointer;font:italic 500 13px/1.3 Georgia,serif}
.ftr-pgb b{flex:none;width:30px;height:30px;border-radius:50%;display:grid;place-items:center;background:#7a1020;color:#fff;font:800 14px var(--ui)}
.ftr-pgb.no{background:#120c34;color:#8a80b0;border-color:#3a3070;cursor:default}.ftr-pgb.no b{background:#2a2050;color:#8a80b0}
.ftr-pgb:not(.no):hover{transform:translateY(-2px)}
.ftr-pgn{margin:4px 0 0;font:600 13px var(--ui);color:#c4badf}.ftr-pgn b{color:#ffd45a}.ftr-title{color:#ffb45a!important}
.ftr-odd{display:flex;align-items:center;gap:12px;padding:6px 12px 6px 6px;border-radius:14px;background:#0b0724b8;border-left:4px solid var(--oc)}.ftr-odd canvas{width:120px;height:80px}.ftr-odd span{flex:1;display:flex;flex-direction:column}
.ftr-odd b{font:800 17px var(--ui);color:#fff8e8}.ftr-odd small{font:500 13px var(--ui);color:#c4badf}.ftr-odd em{font:800 12px var(--ui);color:var(--oc);font-style:normal}
@media (prefers-reduced-motion:reduce){.fsod,.fsodb{animation:none;transition:none}}
`;document.head.appendChild(st)}
