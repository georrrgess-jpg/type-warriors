/* ---------- Daily Challenge: same words and modifier for everyone each (local) day, one attempt, shareable result card ---------- */
const DC_EPOCH=Date.UTC(2026,8,28),DCT=['g','y','o','r','x'];
let DCN=false,DCRUN=null;
const DCP=()=>{P.dc=P.dc||{days:{},streak:0,best:0,last:'',started:''};if(!P.dc.days)P.dc.days={};return P.dc};
const DCPACE=22; /* pacing matches mid campaign levels so WPM reads like the campaign */
const dcKey=()=>window.__DCD||(()=>{const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')})();
const dcDate=k=>{const [y,m,d]=k.split('-').map(Number);return new Date(y,m-1,d)};
const dcNum=k=>{const [y,m,d]=k.split('-').map(Number);return Math.round((Date.UTC(y,m-1,d)-DC_EPOCH)/864e5)+1};
const dcAdd=(k,n)=>{const d=dcDate(k);d.setDate(d.getDate()+n);return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
const dcPretty=k=>dcDate(k).toLocaleDateString(undefined,{weekday:'long',month:'long',day:'numeric'});
const dcHash=s=>{let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0};
const dcRng=seed=>{let a=seed>>>0;return()=>{a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}};
const dcMod=(a,n)=>((a%n)+n)%n;
const dcPerm=(n,salt)=>{const r=dcRng(dcHash('perm'+salt)),a=[...Array(n).keys()];for(let i=n-1;i>0;i--){const j=r()*(i+1)|0;[a[i],a[j]]=[a[j],a[i]]}return a};
/* today's modifiers: most reuse the campaign level rules, a few are new */
const DCM=[
{k:'fog',n:'Creeping Fog',md:'fog',x:1.15},{k:'dark',n:'Endless Night',md:'dark',x:1.1},{k:'swarm',n:'Swarm',md:'swarm',x:1.1},
{k:'giants',n:'Giants',md:'giants',x:1.1},{k:'gusts',n:'Gale Winds',md:'gusts',x:1.15},{k:'frenzy',n:'Frenzy',md:'frenzy',x:1.2},
{k:'ranged',n:'Archers',md:'ranged',x:1.15},{k:'elite',n:'Elite Guard',md:'elite',x:1.2},
{k:'glass',n:'Glass Cannon',d:'One heart only. Every point counts for 60% more.',hearts:1,x:1.6},
{k:'turbo',n:'Turbo',d:'Every monster moves 30% faster.',spd:1.3,x:1.3},
{k:'wordsmith',n:'Wordsmith',d:'Only long words today.',long:1,x:1.25}];
for(const m of DCM)if(m.md)m.d=MODS[m.md].d;
const dcCache={};
function dcBuild(key){if(dcCache[key])return dcCache[key];
 const NEW=key>=DC_NEW,RL=NEW?REALMS:REALMS.slice(0,8),n=dcNum(key),cr=Math.floor((n-1)/RL.length),R0=RL[dcPerm(RL.length,(NEW?'R':'r')+cr)[dcMod(n-1,RL.length)]],R=NEW?dcRealmDay(R0,key):R0,cm=Math.floor((n-1)/DCM.length),M=DCM[dcPerm(DCM.length,'m'+cm)[dcMod(n-1,DCM.length)]];
 const rng=dcRng(dcHash('dc'+key)),hue=Math.round(rng()*52-26),bid=R.boss[rng()*R.boss.length|0];
 const L={i:40,n:R.n,z:R.zw,tint:0,sky:dcRot(R.sc.sky,hue),wx:R.sc.wx||0,prop:'',m:R.mob,mod:M.md||null,b:bid,bn:MON[bid].n,bl:'the '+MON[bid].n.toLowerCase(),pl:'the '+R.n.toLowerCase(),hue:Math.round(rng()*360),blurb:'',a:dcHexHue(R.a,hue)};
 const rounds=[],oR=Math.random,oRC=RECENT.slice();RECENT=[];Math.random=rng;let boss=[];
 try{for(let r=1;r<=5;r++){const cnt=r===5?4:Math.round([8,10,12,13][r-1]*(M.md==='swarm'?1.4:M.md==='giants'?.7:1)),arr=[],on=[];
   for(let i=0;i<cnt;i++){const q=Math.random();let role=r===1?(q<.55?0:1):(q<.4?0:q<.75?1:2);if(M.md==='giants')role=2;const id=R.mob[role],w0=DCPACE+r*1.8;
    const zp=NEW?dcPool(R):R.zw;let w=pickWord(role,zp,w0,on);if(M.long)for(let k=0;k<10&&w.length<(role===1?5:6);k++)w=pickWord(role,zp,w0,on);
    const mm=MON[id],el=M.md==='elite'?Math.random()<.34:r>=3&&Math.random()<.14,rg=role===0&&!!mm.pj&&(M.md==='ranged'?Math.random()<.7:Math.random()<.3);
    arr.push({id,role,w,el,rg});on.push(w);if(on.length>3)on.shift()}
   rounds.push(arr)}
  const used=[];for(let i=0;i<9;i++)boss.push(bossLine(L,0,used)),used.push(boss[i]);
  if(NEW&&DCTL[R.n]){const tl=DCTL[R.n].slice();for(let i=0;i<9;i+=2)if(tl.length)boss[i]=tl.splice(Math.random()*tl.length|0,1)[0]}}finally{Math.random=oR;RECENT=oRC}
 return dcCache[key]={key,n,R,M,L,hue,rounds,boss,sc:dcRot(R.sc,hue)}}
function dcApply(run){SCN[40]=run.sc}
/* ---------- state, streaks, forfeits ---------- */
const dcDone=key=>DCP().days[key||dcKey()];
function dcSync(){const D=DCP();if(D.started&&!D.days[D.started]&&!(S.dc&&S.mode!=='title')){dcRecord(D.started,{key:D.started,n:dcNum(D.started),forfeit:1,win:0,score:0,wpm:0,acc:0,time:0,combo:0,hl:0,tiles:['x','x','x','x','x'],grade:'F',xp:0,gold:0})}}
function dcRecord(key,res){const D=DCP(),run=dcBuild(key);res.realm=run.R.n;res.mod=run.M.n;D.days[key]=res;D.started='';D.streak=D.last===dcAdd(key,-1)?D.streak+1:1;D.best=Math.max(D.best,D.streak);D.last=key;res.streak=D.streak;try{if(res.win&&!res.forfeit)btyAdd('daily',1)}catch(x){}save();if(typeof achCheck==="function")achCheck()}
const dcStreak=()=>{const D=DCP(),k=dcKey();return D.last===k||D.last===dcAdd(k,-1)?D.streak:0};
const dcCd=()=>{const n=new Date(),e=new Date(n.getFullYear(),n.getMonth(),n.getDate()+1),s=Math.max(0,Math.floor((e-n)/1000));return String(Math.floor(s/3600)).padStart(2,'0')+':'+String(Math.floor(s%3600/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0')};
/* ---------- launching the run on the real combat engine ---------- */
function dcStart(){const key=dcKey(),D=DCP();if(D.days[key])return dcMenu(title);const run=dcBuild(key);D.started=key;save();DCRUN=run;
 const sv={w:P.weapon,a:P.armor,p:P.path,r:P.pres};DCN=true;P.weapon='rusty';P.armor='rags';P.path='knight';P.pres=0;
 try{start(0,'daily')}finally{P.weapon=sv.w;P.armor=sv.a;P.path=sv.p;P.pres=sv.r;DCN=false}S.wpn=P.weapon}
function dcSetup(){const r=DCRUN;dcApply(r);Object.assign(S,{dc:{run:r,L:r.L,key:r.key,n:r.n,M:r.M,si:0,bi:0,tiles:[],rs:{dm:0,ch:0,ok:0}},rift:0,prac:null,camp:0,wave:0,sc:r.M.x,slow:1,furyMul:1,cq:0,fg:0,chain:0,mev:0,crit:0,rev:0,qm:0,keep:.5,slowE:1,fm:100,pcdT:.55,pf:7,vm:3.2,cl:0,gm:1,flaw:0,invT:.75,xpm:0,shield:0,max:r.M.hearts||3,hp:r.M.hearts||3,dcSpd:r.M.spd||1});S.gs=1}
const dcNext=()=>{const D=S.dc,a=D.run.rounds[S.round-1]||[];return a[D.si++]||a[a.length-1]||{id:D.run.R.mob[0],role:0,w:'rune',el:0,rg:0}};
const dcBossLine=()=>{const D=S.dc;return D.run.boss[D.bi++%D.run.boss.length]};
function dcWave(){const D=S.dc;D.si=0;D.rs={dm:S.dmgTaken,ch:S.chars,ok:S.ok};S.d=DCPACE+S.round*1.8;const boss=S.round===5;S.spawnLeft=D.run.rounds[S.round-1].length+(boss?1:0);
 S.ban={t:S.round===1?3.8:2.8,txt:S.round===1?`Daily Challenge #${D.n}`:boss?'Boss round':`Round ${S.round} of 5`,c:boss?'#ff5c6c':D.run.L.a,sub:S.round===1?D.run.R.n+' · '+D.M.n+': '+D.M.d:boss?'Boss: '+D.run.L.bn:''}}
function dcTile(dead){const D=S.dc,dm=S.dmgTaken-D.rs.dm,ch=S.chars-D.rs.ch,ac=ch?(S.ok-D.rs.ok)/ch:1;return dead?'r':dm===0&&ac>=.92?'g':dm<=1&&ac>=.85?'y':'o'}
function dcRoundEnd(){const D=S.dc;D.tiles.push(dcTile(0));save();if(S.round===5)return dcOver(0,1);jingle('wave');float(W/2,300,'Round cleared','#7dffb0',44);startWave()}
const dcGrade=(win,acc,hl,cl)=>win?(acc>=97&&hl===0?'S':acc>=94&&hl<=1?'A':acc>=88?'B':'C'):(cl>=3?'D':'F');
const DCGC={S:'#ffd76a',A:'#7dffb0',B:'#6ac4ff',C:'#c88aff',D:'#ff9a5a',F:'#ff5c6c'};
function dcOver(quit,win){if(S.mode==='over')return;const D=S.dc;S.mode='over';S.en=[];S.pj=[];btyRunEnd();
 const tiles=D.tiles.slice();if(!win&&tiles.length<5)tiles.push(quit?'x':dcTile(1));while(tiles.length<5)tiles.push('x');
 const acc=S.chars?Math.round(S.ok/S.chars*100):100,hl=Math.max(0,S.max-Math.max(0,S.hp)),cl=D.tiles.length,g=quit&&!win?'F':dcGrade(win,acc,hl,cl);
 const D0=DCP(),l0=lvl(P.xp),st=D0.last===dcAdd(D.key,-1)?D0.streak+1:1;
 const xp=win?220+{S:200,A:120,B:60,C:0}[g]:40+cl*25,gold=win?160+{S:200,A:120,B:60,C:0}[g]+Math.min(300,st*20):30+cl*20;
 const res={bountyCompleted:S.btyWpmCompleted||'',key:D.key,n:D.n,win:win?1:0,forfeit:quit&&!win?1:0,score:S.score,wpm:wpmValid()?S.wpm:0,acc,time:Math.round(S.t),combo:S.maxCombo,hl,tiles,grade:g,xp,gold,boss:D.run.L.bn};
 P.xp+=xp;P.gold+=gold;const lg=levelGold(l0,lvl(P.xp));P.gold+=0;res.lg=lg;P.kills+=S.kills;stat('dc',1,'add');if(win)stat('dcw',1,'add');stat('combo',S.maxCombo,'max');dcRecord(D.key,res);jingle(win?'win':'lose');
 const later=()=>dcResult(res);if(quit)later();else{S.pose=win?'victory':'dead';S.poseT=0;S.landed=0;S.late=later;S.lateAt=win?1.8:2.2}}
/* ---------- the shareable result card (1080 x 1350 PNG) ---------- */
const dcTime=s=>Math.floor(s/60)+':'+String(s%60).padStart(2,'0');
const DCTC={g:'#3fd47a',y:'#f2c94c',o:'#f2994a',r:'#e8455a',x:'#2a2440'};
function dcCard(res){const run=dcBuild(res.key),R=run.R,c=document.createElement('canvas');c.width=1080;c.height=1350;const g=c.getContext('2d'),F='"Pirata One",Georgia,serif',acc=run.L.a,gc=DCGC[res.grade]||'#fff';
 dcApply(run);try{ctx.setTransform(RS,0,0,RS,0,0);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';zoneBG(0,3.1,run.L);g.drawImage(cv,(cv.width-cv.height*.8)/2,0,cv.height*.8,cv.height,0,0,1080,1350)}catch(e){g.fillStyle='#14102a';g.fillRect(0,0,1080,1350)}
 let q=g.createLinearGradient(0,0,0,1350);q.addColorStop(0,'rgba(8,4,20,.75)');q.addColorStop(.3,'rgba(8,4,20,.15)');q.addColorStop(.55,'rgba(8,4,20,.2)');q.addColorStop(1,'rgba(8,4,20,.94)');g.fillStyle=q;g.fillRect(0,0,1080,1350);
 g.textAlign='center';g.textBaseline='alphabetic';
 g.font='400 104px '+F;q=g.createLinearGradient(0,70,0,170);q.addColorStop(0,'#fff4c0');q.addColorStop(1,'#f0a820');g.fillStyle=q;g.shadowColor='#000';g.shadowBlur=18;g.lineWidth=10;g.strokeStyle='#1a0e04';g.lineJoin='round';g.strokeText('TYPE WARRIORS',540,150);g.fillText('TYPE WARRIORS',540,150);g.shadowBlur=0;
 g.font='italic 700 34px Georgia,serif';g.fillStyle='#fff';g.shadowColor=acc;g.shadowBlur=14;g.fillText('D A I L Y   C H A L L E N G E   #'+res.n,540,206);g.shadowBlur=0;
 g.font='26px Georgia,serif';g.fillStyle='#e8e0f8';g.fillText(dcPretty(res.key),540,246);
 const pill=(txt,y,col)=>{g.font='700 30px Georgia,serif';const w=g.measureText(txt).width+56;g.fillStyle='rgba(10,6,24,.7)';g.beginPath();g.roundRect(540-w/2,y-34,w,50,25);g.fill();g.strokeStyle=col;g.lineWidth=3;g.stroke();g.fillStyle=col;g.fillText(txt,540,y)};
 pill(R.n.toUpperCase(),300,acc);pill('MODIFIER: '+res.mod.toUpperCase(),362,'#ffd76a');
 /* hero */
 const hx=360,hy=980;let rg=g.createRadialGradient(hx,hy-190,10,hx,hy-190,330);rg.addColorStop(0,acc+'88');rg.addColorStop(1,acc+'00');g.fillStyle=rg;g.fillRect(hx-340,hy-520,680,680);
 g.save();g.translate(hx,hy);g.scale(3.5,3.5);try{drawHero(g,{arm:P.armor,wp:P.weapon,col:P.col,t:.4})}catch(e){}g.restore();
 /* grade stamp */
 const sx=800,sy=700;g.save();g.translate(sx,sy);g.rotate(-.12);rg=g.createRadialGradient(0,0,20,0,0,200);rg.addColorStop(0,gc+'66');rg.addColorStop(1,gc+'00');g.fillStyle=rg;g.fillRect(-210,-210,420,420);g.lineWidth=14;g.strokeStyle=gc;g.shadowColor=gc;g.shadowBlur=26;g.beginPath();g.arc(0,0,128,0,TAU);g.stroke();g.lineWidth=4;g.beginPath();g.arc(0,0,146,0,TAU);g.stroke();g.shadowBlur=0;g.fillStyle='rgba(10,6,24,.82)';g.beginPath();g.arc(0,0,118,0,TAU);g.fill();
 g.font='400 190px '+F;g.textBaseline='middle';g.fillStyle=gc;g.strokeStyle='#000';g.lineWidth=8;g.strokeText(res.grade,0,10);g.fillText(res.grade,0,10);g.restore();g.textBaseline='alphabetic';
 g.font='700 34px Georgia,serif';g.fillStyle=res.win?'#7dffb0':'#ff8a9a';g.fillText(res.win?'CHALLENGE CLEARED':res.forfeit?'FORFEITED':'FELL IN BATTLE',sx,sy+196);
 /* stats */
 g.fillStyle='rgba(10,6,24,.78)';g.beginPath();g.roundRect(60,1040,960,132,26);g.fill();g.strokeStyle=acc+'aa';g.lineWidth=3;g.stroke();
 [['SCORE',res.score.toLocaleString()],['WPM',String(res.wpm)],['ACCURACY',res.acc+'%'],['TIME',dcTime(res.time)]].forEach((s,i)=>{const x=60+960/8*(1+i*2);g.font='400 58px '+F;g.fillStyle='#fff';g.fillText(s[1],x,1110);g.font='700 19px Georgia,serif';g.fillStyle='#b8b0d8';g.fillText(s[0],x,1146)});
 /* round tiles */
 const tw=104,gap=18,t0=540-(5*tw+4*gap)/2;res.tiles.forEach((t,i)=>{const x=t0+i*(tw+gap),y=1204;g.fillStyle=DCTC[t];g.beginPath();g.roundRect(x,y,tw,tw*.86,16);g.fill();g.strokeStyle='rgba(255,255,255,.25)';g.lineWidth=3;g.stroke();g.fillStyle='rgba(0,0,0,.35)';g.font='400 44px '+F;g.fillText(i===4?'B':String(i+1),x+tw/2,y+tw*.58)});
 g.font='italic 26px Georgia,serif';g.fillStyle='#e8e0f8';g.fillText((res.streak>1?'🔥 '+res.streak+' day streak   ·   ':'')+'Same words for everyone. Can you beat me?',540,1328);
 return c}
function dcShareText(res){const E={g:'🟩',y:'🟨',o:'🟧',r:'🟥',x:'⬛'};return `Type Warriors Daily #${res.n}  ${res.grade}\n${res.tiles.map(t=>E[t]).join('')}\n⚔ ${res.mod} · ${res.realm}\n⌨ ${res.wpm} WPM · ${res.acc}% · ⏱ ${dcTime(res.time)}${res.streak>1?` · 🔥${res.streak}`:''}`}
function dcSave(res){const c=dcCard(res);c.toBlob(b=>{if(!b)return;const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=`type-warriors-daily-${res.n}.png`;document.body.appendChild(a);a.click();setTimeout(()=>{a.remove();URL.revokeObjectURL(a.href)},500)},'image/png')}
async function dcCopy(res,btn){const t=dcShareText(res);let ok=false;try{await navigator.clipboard.writeText(t);ok=true}catch(e){try{const ta=document.createElement('textarea');ta.value=t;ta.style.cssText='position:fixed;opacity:0';document.body.appendChild(ta);ta.select();ok=document.execCommand('copy');ta.remove()}catch(e2){}}if(btn){btn.textContent=ok?'Copied!':'Copy failed';setTimeout(()=>{btn.textContent='Copy result'},1800)}}
async function dcShare(res){const c=dcCard(res);c.toBlob(async b=>{try{const f=new File([b],`type-warriors-daily-${res.n}.png`,{type:'image/png'});if(navigator.canShare&&navigator.canShare({files:[f]}))await navigator.share({files:[f],text:dcShareText(res)});else await navigator.share({text:dcShareText(res)})}catch(e){}})}
/* ---------- screens ---------- */
function dcResult(res){S.mode='title';S.en=[];S.pj=[];const run=dcBuild(res.key),c=dcCard(res),url=c.toDataURL('image/png'),gc=DCGC[res.grade];S.view='dc';S.dcv=run.L;dcApply(run);
 show(`<div class="dcx dcr" style="--c:${run.L.a};--g:${gc}"><div class="dcrc"><img src="${url}" alt="Result card"></div><div class="dcrt"><small>DAILY CHALLENGE #${res.n}</small><h2>${res.win?'Challenge cleared':res.forfeit?'Forfeited':'Fallen in battle'}</h2><div class="dcg" style="color:${gc}">${res.grade}</div>
 <div class="dcsum"><span><b>${res.score.toLocaleString()}</b>Score</span><span><b>${res.wpm}</b>WPM</span><span><b>${res.acc}%</b>Accuracy</span><span><b>${dcTime(res.time)}</b>Time</span></div>
 ${btyResultNotice(res.bountyCompleted)}<div class="dctl">${res.tiles.map((t,i)=>`<i style="background:${DCTC[t]}">${i===4?'B':i+1}</i>`).join('')}</div>
 <p class="dcrw">${res.streak>1?`<b>${res.streak} day streak!</b> `:''}Earned ${res.xp} XP and ${res.gold+(res.lg||0)} gold.</p>
 <div class="row"><button id="dsv">Download card</button><button class="sm" id="dcp">Copy result</button>${navigator.share?'<button class="sm" id="dsh">Share</button>':''}</div>
 <div class="row"><button class="sm" id="dhm">Home</button><button class="sm" id="dmn">Challenge page</button></div>
 <p class="dcnx">Next challenge in <b id="dcd">${dcCd()}</b></p></div></div>`,'m dcm');
 $('dsv').onclick=()=>dcSave(res);$('dcp').onclick=e=>dcCopy(res,e.target);if($('dsh'))$('dsh').onclick=()=>dcShare(res);$('dhm').onclick=title;$('dmn').onclick=()=>dcMenu(title);S.back=title;dcTick()}
let dcTI=0;function dcTick(){clearInterval(dcTI);dcTI=setInterval(()=>{const e=document.getElementById('dcd');if(!e){clearInterval(dcTI);return}e.textContent=dcCd();if(dcKey()!==(window.__dcShown||dcKey())){clearInterval(dcTI)}},1000)}
function dcHist(){const D=DCP(),k=dcKey();let h='';for(let i=13;i>=0;i--){const kk=dcAdd(k,-i),r=D.days[kk],col=r?DCGC[r.grade]:'#2a2440';h+=`<i class="${i===0?'tdy':''}" style="background:${col}" title="#${dcNum(kk)} ${r?r.grade:'-'}"></i>`}return h}
function dcMenu(back){const key=dcKey(),run=dcBuild(key),D=DCP(),done=D.days[key],L=run.L;window.__dcShown=key;S.view='dc';S.dcv=L;dcApply(run);const st=dcStreak();
 const mobs=[...run.R.mob,L.b];
 show(`<div class="dcx" style="--c:${L.a}"><div class="dch"><small>DAILY CHALLENGE #${run.n}</small><h2 class="nogl">${run.R.n}</h2><p class="dcd">${dcPretty(key)}</p></div>
 <div class="dcmd"><span class="dcmc">Modifier</span><b>${run.M.n}</b><em>${run.M.d}</em></div>
 <div class="dcmobs">${mobs.map((m,i)=>`<div class="${i===3?'bs':''}"><canvas width="170" height="150" data-m="${m}"></canvas><span>${MON[m].n}</span>${i===3?'<u>Boss</u>':''}</div>`).join('')}</div>
 <ul class="dcrl"><li>The same words and modifier for everyone today.</li><li>A standard loadout: your gear, skills and boons do not apply.</li><li>Five rounds, a boss at the end, three hearts.</li><li><b>One attempt.</b> Leaving a run counts as your attempt.</li></ul>
 <div class="dcst"><span class="dcfl"><b>${st}</b> day streak</span><span>Best <b>${D.best}</b></span><span class="dcho">${dcHist()}</span></div>
 <div class="row">${done?`<button id="dvw">View today's card</button>`:`<button id="dgo">Begin challenge</button>`}<button class="sm" id="dbk">Back</button></div>
 <p class="dcnx">${done?`Next challenge in <b id="dcd">${dcCd()}</b>`:'Resets at midnight, your local time.'}</p></div>`,'m dcm');
 ov.querySelectorAll('canvas[data-m]').forEach(cv=>tileArt(cv,cv.dataset.m));
 if($('dgo'))$('dgo').onclick=dcStart;if($('dvw'))$('dvw').onclick=()=>dcResult(done);$('dbk').onclick=()=>{S.view='menu';(typeof back==='function'?back:title)()};S.back=()=>{S.view='menu';title()};if(done)dcTick()}
/* the home screen banner */
function dcBanner(){const key=dcKey(),run=dcBuild(key),done=dcDone(key),st=dcStreak();
 return `<button class="dcb${done?' dn':''}" id="dcb" style="--c:${run.L.a}"><span class="dci">${mico('daily',54)}</span><span class="dct"><small>DAILY CHALLENGE #${run.n}</small><b>${run.R.n}</b><em>${run.M.n}${st?` · <u>${st} day streak</u>`:''}</em></span><span class="dcs">${done?`<i style="color:${DCGC[done.grade]}">${done.grade}</i><small>Done</small>`:'<i>Play</i><small>New today</small>'}</span></button>`}
Object.assign(MG,{daily:bP('M24 30H76V80H24Z','#f4ecd8')+bP('M24 30H76V44H24Z','#e0344a')+bL(36,22,36,36,'#aab4c6',5)+bL(64,22,64,36,'#aab4c6',5)+bF('M24 44H76V50H24Z','#000',.1)+bP('M50 50L56 62L69 64L59 72L62 85L50 78L38 85L41 72L31 64L44 62Z','#ffc83a',2.2)+bS(80,28,6,'#fff0a0')});MA.daily='#ffd24a';
