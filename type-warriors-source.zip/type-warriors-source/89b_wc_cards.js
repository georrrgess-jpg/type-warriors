/* ===== WILDCARD: card art =====
   Inline SVG cards in the game's chunky storybook style: dark #12081f outlines, an element-coloured face with a soft
   darker right half and a faint tiled motif, a cream shield in the centre (with an upper-left highlight) holding the
   face value, and corner indices with the element glyph. Shared gradients live once in a hidden <svg>. Markup is
   cached per card face, so a full hand re-renders cheaply. */
const WCK={e:['#ff8a4a','#e8452e','#9a1e14'],t:['#6ab8ff','#2f7de0','#164a9a'],g:['#7ae07a','#2fa64a','#14662a'],s:['#ffe27a','#f0b21c','#a86a08']};
const WCG={/* element glyphs, drawn around 0,0 at about 20 units */
 e:'<path d="M0-11C5-5 8-1 7 4A7 7 0 0 1-7 4C-8-1-4-3-3-8-1-4 0-3 1-2 1-5 0-8 0-11Z" fill="#fff4e0" stroke="#12081f" stroke-width="2.2" stroke-linejoin="round"/><path d="M0-2C3 1 4 3 3 5A3 3 0 0 1-3 5C-4 3-2 1 0-2Z" fill="#ffb03a"/>',
 t:'<path d="M0-11C4-5 8-1 8 3A8 8 0 0 1-8 3C-8-1-4-5 0-11Z" fill="#eaf6ff" stroke="#12081f" stroke-width="2.2" stroke-linejoin="round"/><path d="M-4 2A4 4 0 0 0 0 6" stroke="#6ab8ff" stroke-width="2" fill="none" stroke-linecap="round"/>',
 g:'<path d="M-8 8C-9-2-3-9 9-10 9 2 3 9-8 8Z" fill="#effde8" stroke="#12081f" stroke-width="2.2" stroke-linejoin="round"/><path d="M-8 8L4-4" stroke="#2fa64a" stroke-width="2" stroke-linecap="round"/>',
 s:'<path d="M2-11L-7 2H0L-3 11 8-3H1Z" fill="#fffbe0" stroke="#12081f" stroke-width="2.2" stroke-linejoin="round"/>',
 w:'<path d="M0-10L3-3 10 0 3 3 0 10-3 3-10 0-3-3Z" fill="#fff" stroke="#12081f" stroke-width="2" stroke-linejoin="round"/>'};
const WCSHIELD='M50 34C60 38 70 39 77 37V72C77 92 64 104 50 110 36 104 23 92 23 72V37C30 39 40 38 50 34Z';
{const d=document.createElementNS('http://www.w3.org/2000/svg','svg');d.setAttribute('width','0');d.setAttribute('height','0');d.style.position='absolute';d.setAttribute('aria-hidden','true');
 d.innerHTML=`<defs>${Object.entries(WCK).map(([k,c])=>`<linearGradient id="wcf${k}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${c[0]}"/><stop offset=".55" stop-color="${c[1]}"/><stop offset="1" stop-color="${c[2]}"/></linearGradient>`).join('')}
 <linearGradient id="wcsh" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fffdf6"/><stop offset=".7" stop-color="#f4ead2"/><stop offset="1" stop-color="#dccba4"/></linearGradient>
 <linearGradient id="wcgl" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".55"/><stop offset=".35" stop-color="#fff" stop-opacity="0"/></linearGradient>
 <radialGradient id="wcbk" cx=".5" cy=".42" r=".75"><stop offset="0" stop-color="#3a2a8a"/><stop offset=".6" stop-color="#1c1450"/><stop offset="1" stop-color="#0c0826"/></radialGradient>
 <radialGradient id="wcbh" cx=".5" cy=".42" r=".75"><stop offset="0" stop-color="#ff8a24"/><stop offset=".55" stop-color="#8a2a10"/><stop offset="1" stop-color="#1a0804"/></radialGradient>
 <radialGradient id="wcbr" cx=".5" cy=".42" r=".75"><stop offset="0" stop-color="#c8283a"/><stop offset=".6" stop-color="#6a0a1c"/><stop offset="1" stop-color="#2a0410"/></radialGradient>
 <radialGradient id="wcba" cx=".35" cy=".3" r=".9"><stop offset="0" stop-color="#ff6fae"/><stop offset=".35" stop-color="#6a2ad8"/><stop offset=".8" stop-color="#140840"/><stop offset="1" stop-color="#05031a"/></radialGradient>
 <radialGradient id="wcbn" cx=".5" cy=".42" r=".75"><stop offset="0" stop-color="#2ac88a"/><stop offset=".6" stop-color="#0a5a44"/><stop offset="1" stop-color="#03241c"/></radialGradient>
 <clipPath id="wcshc"><path d="M50 34C60 38 70 39 77 37V72C77 92 64 104 50 110 36 104 23 92 23 72V37C30 39 40 38 50 34Z"/></clipPath>
 <clipPath id="wcclip"><rect x="6" y="6" width="88" height="134" rx="8"/></clipPath>
 <pattern id="wcpt" width="18" height="18" patternUnits="userSpaceOnUse"><path d="M9 3l2 4 4 2-4 2-2 4-2-4-4-2 4-2z" fill="#fff" opacity=".1"/></pattern></defs>`;
 (document.body||document.documentElement).appendChild(d)}
/* the face value inside the shield */
function wcFace(c){const col=c.s==='w'?'#2a1460':WCK[c.s][2];
 const txt=(t,sz)=>`<text x="50" y="${83+sz*.04}" text-anchor="middle" font-family="Poppins,Segoe UI,sans-serif" font-weight="900" font-size="${sz}" fill="${c.s==='w'?'#fff':WCK[c.s][1]}" stroke="#12081f" stroke-width="${sz>40?5:4}" paint-order="stroke" stroke-linejoin="round" letter-spacing="-1">${t}</text>`;
 if(/^\d$/.test(c.v))return txt(c.v,c.v==='1'?52:50);
 if(c.v==='d2')return txt('+2',38);if(c.v==='d4')return txt('+4',38);
 if(c.v==='stun')return `<g transform="translate(50 70)"><circle r="17" fill="${WCK[c.s][1]}" stroke="#12081f" stroke-width="4"/><circle r="10" fill="#fffaf0" stroke="#12081f" stroke-width="2.5"/><path d="M-12 12L12-12" stroke="#12081f" stroke-width="9" stroke-linecap="round"/><path d="M-12 12L12-12" stroke="${WCK[c.s][0]}" stroke-width="4" stroke-linecap="round"/>${[[-20,-15],[19,13],[16,-20]].map(([x,y])=>`<path d="M${x} ${y-4}l1.4 2.6 2.6 1.4-2.6 1.4-1.4 2.6-1.4-2.6-2.6-1.4 2.6-1.4z" fill="#ffd45a" stroke="#12081f" stroke-width=".9"/>`).join('')}</g>`;
 if(c.v==='turn')return `<g transform="translate(50 71)" stroke-linecap="round" stroke-linejoin="round"><path d="M-14-6A15 15 0 0 1 12-9" fill="none" stroke="#12081f" stroke-width="10"/><path d="M14 6A15 15 0 0 1-12 9" fill="none" stroke="#12081f" stroke-width="10"/><path d="M-14-6A15 15 0 0 1 12-9" fill="none" stroke="${WCK[c.s][1]}" stroke-width="5"/><path d="M14 6A15 15 0 0 1-12 9" fill="none" stroke="${WCK[c.s][1]}" stroke-width="5"/><path d="M8-17L17-9 6-4Z" fill="${WCK[c.s][1]}" stroke="#12081f" stroke-width="2.4"/><path d="M-8 17L-17 9-6 4Z" fill="${WCK[c.s][1]}" stroke="#12081f" stroke-width="2.4"/></g>`;
 /* wild: the four elements meet inside the shield around a rune */
 return `<g clip-path="url(#wcshc)"><rect x="20" y="30" width="30" height="42" fill="${WCK.e[1]}"/><rect x="50" y="30" width="30" height="42" fill="${WCK.t[1]}"/><rect x="20" y="72" width="30" height="42" fill="${WCK.g[1]}"/><rect x="50" y="72" width="30" height="42" fill="${WCK.s[1]}"/><path d="M50 30V114M20 72H80" stroke="#12081f" stroke-width="2"/></g>
  <circle cx="50" cy="72" r="15" fill="#fffaf0" stroke="#12081f" stroke-width="3"/>${c.v==='d4'?`<text x="50" y="79" text-anchor="middle" font-family="Poppins,Segoe UI,sans-serif" font-weight="900" font-size="19" fill="#2a1460">+4</text>`:'<path d="M50 61V83M42 66L58 78M58 66L42 78" stroke="#2a1460" stroke-width="3.2" stroke-linecap="round"/>'}`}
function wcCorner(c){if(c.s==='w')return c.v==='d4'?'+4':'W';return /^\d$/.test(c.v)?c.v:c.v==='d2'?'+2':c.v==='stun'?'⊘':'⇄'}
const WCSV=new Map();
function wcSVG(c){const k=c.s+c.v;if(WCSV.has(k))return WCSV.get(k);
 const bg=c.s==='w'?`<rect x="6" y="6" width="44" height="67" fill="${WCK.e[1]}"/><rect x="50" y="6" width="44" height="67" fill="${WCK.t[1]}"/><rect x="6" y="73" width="44" height="67" fill="${WCK.g[1]}"/><rect x="50" y="73" width="44" height="67" fill="${WCK.s[1]}"/>`:`<rect x="6" y="6" width="88" height="134" fill="url(#wcf${c.s})"/>`;
 const gl=c.s==='w'?WCG.w:WCG[c.s],cor=wcCorner(c),dark=c.s==='w'?'#2a1460':WCK[c.s][2];
 const ico=c.v==='stun'?'<g transform="translate(0 -6)"><circle r="6.5" fill="none" stroke="#12081f" stroke-width="5"/><path d="M-4.5 4.5L4.5-4.5" stroke="#12081f" stroke-width="5"/><circle r="6.5" fill="none" stroke="#fff" stroke-width="2.2"/><path d="M-4.5 4.5L4.5-4.5" stroke="#fff" stroke-width="2.2"/></g>'
  :c.v==='turn'?'<g transform="translate(0 -6)" fill="none" stroke-linecap="round"><path d="M-6-2A6 6 0 0 1 5-3M6 2A6 6 0 0 1-5 3" stroke="#12081f" stroke-width="5"/><path d="M-6-2A6 6 0 0 1 5-3M6 2A6 6 0 0 1-5 3" stroke="#fff" stroke-width="2.2"/></g>':null;
 const idx=(x,y,r)=>`<g transform="translate(${x} ${y}) rotate(${r})">${ico||`<text x="0" y="0" text-anchor="middle" font-family="Poppins,Segoe UI,sans-serif" font-weight="900" font-size="${cor.length>1?15:18}" fill="#fff" stroke="#12081f" stroke-width="3.6" paint-order="stroke" stroke-linejoin="round">${cor}</text>`}<g transform="translate(0 13) scale(.6)">${gl}</g></g>`;
 const svg=`<svg viewBox="0 0 100 146" class="wcsvg" aria-hidden="true"><rect x="2" y="2" width="96" height="142" rx="11" fill="#fff8ec" stroke="#12081f" stroke-width="3"/>
 <g clip-path="url(#wcclip)">${bg}<rect x="6" y="6" width="88" height="134" fill="url(#wcpt)"/><path d="M60 6H94V140H44Z" fill="#000" opacity=".12"/>
 <ellipse cx="50" cy="72" rx="40" ry="52" fill="#fff" opacity=".12"/></g><rect x="6" y="6" width="88" height="134" rx="8" fill="none" stroke="#12081f" stroke-width="1.6"/>
 <path d="${WCSHIELD}" fill="url(#wcsh)" stroke="#12081f" stroke-width="3.4" stroke-linejoin="round" transform="translate(50 72) scale(1.08) translate(-50 -72)"/>
 <g transform="translate(50 72) scale(1.08) translate(-50 -72)">${wcFace(c)}<path d="M50 72L77 37V72C77 92 64 104 50 110Z" fill="#000" opacity=".07"/><path d="M29 44C33 45 38 44 42 42" stroke="#fff" stroke-width="2.6" fill="none" stroke-linecap="round" opacity=".9"/></g>
 ${idx(16,24,0)}${idx(84,122,180)}
 <rect x="2" y="2" width="96" height="142" rx="11" fill="url(#wcgl)" opacity=".7"/></svg>`;
 WCSV.set(k,svg);return svg}
/* card backs: classic indigo, Hallow's Eve, Royal Gold, Astral and the secret Rune back */
const WCBK={classic:{n:'Tavern Indigo',g:'wcbk',rim:'#ffc94a',how:'Owned from the start'},hallow:{n:"Hallow's Eve",g:'wcbh',rim:'#ffb03a',how:'Win 3 games (or play one during Halloween)'},
 royal:{n:'Royal Gold',g:'wcbr',rim:'#ffd45a',how:'Win 25 games'},astral:{n:'Astral',g:'wcba',rim:'#ff9ad8',how:'Win 10 games at the Hard table'},rune:{n:'Elder Rune',g:'wcbn',rim:'#8affc8',how:'A secret from the 8.2 notes'}};
function wcBack(k){k=WCBK[k]?k:'classic';const B=WCBK[k],key='back:'+k;if(WCSV.has(key))return WCSV.get(key);
 const motif=k==='hallow'?`<g transform="translate(50 73)"><path d="M0-17C-14-17-20-8-20 2-20 13-11 19 0 19 11 19 20 13 20 2 20-8 14-17 0-17Z" fill="#ff8a1f" stroke="#12081f" stroke-width="3"/><path d="M-8-17C-10-8-10 10-6 19M8-17C10-8 10 10 6 19" stroke="#b8520e" stroke-width="2" fill="none"/><path d="M0-17C0-22 3-25 7-26" stroke="#3a6a1a" stroke-width="3.4" fill="none" stroke-linecap="round"/><path d="M-11-2L-5-6-3 0ZM11-2L5-6 3 0ZM-9 8Q0 15 9 8L5 10 2 7-2 10-5 7Z" fill="#2a0a04"/></g>`
  :k==='royal'?`<g transform="translate(50 73)"><path d="M-20 10L-22-12-11-2 0-18 11-2 22-12 20 10Z" fill="#ffd45a" stroke="#12081f" stroke-width="3" stroke-linejoin="round"/><path d="M-20 10H20V16H-20Z" fill="#e8a820" stroke="#12081f" stroke-width="3"/><circle cy="-2" r="3.4" fill="#c8283a" stroke="#12081f" stroke-width="1.6"/></g>`
  :k==='astral'?`<g transform="translate(50 73)">${[[-24,-30,2],[20,-36,1.6],[26,22,2.2],[-22,30,1.4],[6,-48,1.2],[-6,46,1.8]].map(([x,y,r])=>`<circle cx="${x}" cy="${y}" r="${r}" fill="#fff"/>`).join('')}<circle r="18" fill="#ffe9ff" opacity=".15"/><path d="M0-20L5-5 20 0 5 5 0 20-5 5-20 0-5-5Z" fill="#fff6ff" stroke="#12081f" stroke-width="2.6" stroke-linejoin="round"/></g>`
  :k==='rune'?`<g transform="translate(50 73)" stroke-linecap="round" stroke-linejoin="round"><circle r="21" fill="none" stroke="#8affc8" stroke-width="2.2" stroke-dasharray="4 3"/><path d="M0-15V15M-9-8L9 8M9-8L-9 8M-5 15H5" stroke="#12081f" stroke-width="7"/><path d="M0-15V15M-9-8L9 8M9-8L-9 8M-5 15H5" stroke="#bfffe0" stroke-width="3.2"/></g>`
  :`<g transform="translate(50 73)"><path d="M0-24L20 0 0 24-20 0Z" fill="#ffd45a" stroke="#12081f" stroke-width="3" stroke-linejoin="round"/><path d="M0-24L20 0 0 24Z" fill="#000" opacity=".15"/><text y="7" text-anchor="middle" font-family="Pirata One,Georgia,serif" font-size="22" fill="#2a1406">W</text></g>`;
 const svg=`<svg viewBox="0 0 100 146" class="wcsvg" aria-hidden="true"><rect x="2" y="2" width="96" height="142" rx="11" fill="#1a1238" stroke="#12081f" stroke-width="3"/><rect x="7" y="7" width="86" height="132" rx="8" fill="url(#${B.g})" stroke="${B.rim}" stroke-width="2.4"/>
 <rect x="7" y="7" width="86" height="132" rx="8" fill="url(#wcpt)"/><ellipse cx="50" cy="73" rx="32" ry="44" fill="none" stroke="${B.rim}" stroke-width="1.6" opacity=".7"/><ellipse cx="50" cy="73" rx="26" ry="37" fill="none" stroke="${B.rim}" stroke-width="1" opacity=".45" stroke-dasharray="3 3"/>
 ${motif}<text x="50" y="128" text-anchor="middle" font-family="Pirata One,Georgia,serif" font-size="12" letter-spacing="1.5" fill="${B.rim}">WILDCARD</text><text x="50" y="25" text-anchor="middle" font-family="Pirata One,Georgia,serif" font-size="12" letter-spacing="1.5" fill="${B.rim}" transform="rotate(180 50 21)">WILDCARD</text>
 <rect x="2" y="2" width="96" height="142" rx="11" fill="url(#wcgl)" opacity=".5"/></svg>`;WCSV.set(key,svg);return svg}
const wcCardEl=(c,cls,extra)=>`<div class="wcc${cls?' '+cls:''}" ${c?`data-id="${c.id}"`:''} ${extra||''}>${c?wcSVG(c):wcBack(wcBackSel())}</div>`;
function wcBackSel(){try{const W=wcSt();return WCBK[W.back]&&W.backs[W.back]?W.back:'classic'}catch(e){return'classic'}}
/* small element orb used by the colour picker and the table glow */
const wcOrb=(s,sz)=>`<svg viewBox="-16 -16 32 32" width="${sz||40}" height="${sz||40}" aria-hidden="true"><circle r="14" fill="${WCK[s][1]}" stroke="#12081f" stroke-width="2.6"/><circle r="14" fill="url(#wcgl)"/><g transform="scale(.82)">${WCG[s]}</g></svg>`;
