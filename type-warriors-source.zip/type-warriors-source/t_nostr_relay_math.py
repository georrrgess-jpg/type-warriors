# BIP-340 math shared by the test relay and the test tools (written from the specification).
import hashlib
p=2**256-2**32-977;n=0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141
G=(0x79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798,0x483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8)
def add(P1,P2):
    if P1 is None:return P2
    if P2 is None:return P1
    if P1[0]==P2[0] and P1[1]!=P2[1]:return None
    lam=(3*P1[0]*P1[0]*pow(2*P1[1],p-2,p))%p if P1==P2 else ((P2[1]-P1[1])*pow(P2[0]-P1[0],p-2,p))%p
    x=(lam*lam-P1[0]-P2[0])%p;return (x,(lam*(P1[0]-x)-P1[1])%p)
def mul(P,k):
    R=None
    for i in range(256):
        if (k>>i)&1:R=add(R,P)
        P=add(P,P)
    return R
def lift_x(x):
    if x>=p:return None
    c=(pow(x,3,p)+7)%p;y=pow(c,(p+1)//4,p)
    if pow(y,2,p)!=c:return None
    return (x,y if y%2==0 else p-y)
def th(tag,m):
    h=hashlib.sha256(tag.encode()).digest();return hashlib.sha256(h+h+m).digest()
def verify(pk,m,sig):
    P=lift_x(int.from_bytes(pk,'big'))
    if P is None:return False
    r=int.from_bytes(sig[:32],'big');s=int.from_bytes(sig[32:],'big')
    if r>=p or s>=n:return False
    e=int.from_bytes(th('BIP0340/challenge',sig[:32]+pk+m),'big')%n
    R=add(mul(G,s),mul(P,n-e))
    return R is not None and R[1]%2==0 and R[0]==r
# faster multiplication in Jacobian coordinates (same results as the affine version above, checked by the tests)
def _jd(P):
    X,Y,Z=P
    if Y==0 or Z==0:return (0,1,0)
    A=X*X%p;B=Y*Y%p;C=B*B%p;D=2*((X+B)*(X+B)-A-C)%p;E=3*A%p;F=E*E%p;X3=(F-2*D)%p
    return (X3,(E*(D-X3)-8*C)%p,2*Y*Z%p)
def _ja(P,Q):
    if P[2]==0:return Q
    if Q[2]==0:return P
    X1,Y1,Z1=P;X2,Y2,Z2=Q;Z1s=Z1*Z1%p;Z2s=Z2*Z2%p;U1=X1*Z2s%p;U2=X2*Z1s%p;S1=Y1*Z2s*Z2%p;S2=Y2*Z1s*Z1%p
    if U1==U2:return _jd(P) if S1==S2 else (0,1,0)
    H=(U2-U1)%p;I=4*H*H%p;J=H*I%p;r=2*(S2-S1)%p;V=U1*I%p;X3=(r*r-J-2*V)%p
    return (X3,(r*(V-X3)-2*S1*J)%p,((Z1+Z2)**2-Z1s-Z2s)*H%p)
_slow_mul=mul
def mul(P,k):
    if P is None:return None
    R=(0,1,0);A=(P[0],P[1],1)
    while k>0:
        if k&1:R=_ja(R,A)
        A=_jd(A);k>>=1
    if R[2]==0:return None
    zi=pow(R[2],p-2,p);return (R[0]*zi*zi%p,R[1]*zi*zi*zi%p)
