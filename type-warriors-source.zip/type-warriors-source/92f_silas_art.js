/* ===== RUNESTONE RIDDLE: Silas Veil, the Crimson Masquerade Phantom =====
   Drawn live in the game's storybook style (chunky #12081f outlines, flat colours with a darker right half,
   small upper-left highlights). silasDraw(g,t,st) paints him with the base of his smoke at 0,0 (about 240 units tall);
   st={mode:'idle'|'ability'|'cheer'|'sad'|'think',k:0..1,heat:0..1,look:-1..1}. Stateless: everything comes from t and st.
   He carries an ornate crimson-and-gold masquerade mask on a gold stick: in 'ability' he lifts it to his face (eyes glowing
   through it) while an arcane rune circle unfolds and his cards whirl; 'cheer' flourishes it beside a card fountain; 'sad'
   lowers it; 'think' taps its stick to his chin while the cards orbit.
   silasPortrait(cv,t) fills a canvas with his round gold-ringed portrait. No filters or shadow blurs; gradients and alpha only. */
const SILAS={n:'Silas Veil',t:'Crimson Masquerade Phantom'};
const SILAS_O='#12081f',SILAS_SK='#8ba6bb',SILAS_SKL='#a3bccd',SILAS_RED='#b3203a',SILAS_RED2='#8c1530',SILAS_CRM='#f6e7c4',SILAS_GLD='#f0bf3c',SILAS_GLD2='#c98a1c',SILAS_TEAL='#1f9a94',SILAS_PLUM='#3c1846',SILAS_TAU=Math.PI*2;
/* wisp anchors: x,y,angle,length,curl,width,phase,front(1)/back(0); group 0 base,1 left hand,2 right hand,3 body,4 head, 5+ heat extras */
const SILAS_WISP=[
 [-19,-30,-2.5,36,-2.7,9,0,1,0],[17,-28,-.6,38,2.7,9,1.3,1,0],[-5,-40,-2.0,30,2.8,7,2.1,0,0],[7,-42,-1.1,32,-2.8,7,3.0,0,0],[-26,-12,-2.95,30,-2.4,7,4.1,1,0],[27,-12,-.2,30,2.4,7,5.0,1,0],
 [0,0,2.4,26,-2.6,7,.5,1,1],[0,0,1.3,20,2.6,6,2.6,1,1],
 [0,0,.75,26,2.6,7,1.7,1,2],[0,0,1.9,20,-2.6,6,3.3,1,2],
 [-36,-110,-2.7,30,-2.8,6,.9,0,3],[38,-106,-.4,30,2.6,6,2.4,0,3],
 [-30,-176,-2.7,28,-2.9,6,1.1,0,4],[36,-182,-.35,30,2.9,6,3.7,0,4],
 [-42,-62,-2.6,34,-2.8,7,4.6,0,5],[44,-66,-.5,34,2.8,7,5.5,0,5],[-34,-150,-2.2,30,2.6,6,2.9,0,5],[40,-146,-.9,28,-2.6,6,6.1,0,5],[-12,-20,-1.9,40,2.9,8,1.9,1,5],[12,-18,-1.3,40,-2.9,8,3.9,1,5]];
/* arm keyframes: shoulder, elbow, wrist (left = viewer's left; the right hand holds the mask stick) */
const SILAS_ARM={
 idle:[[-32,-133,-54,-112,-62,-140],[32,-133,50,-108,56,-118]],
 open:[[-32,-133,-58,-138,-80,-160],[32,-133,58,-134,82,-152]],
 mask:[[-32,-133,-58,-146,-72,-170],[32,-133,56,-128,42,-146]],
 up:[[-32,-133,-48,-160,-52,-192],[32,-133,48,-160,52,-192]],
 sad:[[-31,-127,-41,-105,-43,-81],[31,-127,41,-105,43,-81]],
 think:[[-32,-133,-46,-106,-18,-98],[32,-133,46,-110,20,-134]]};
/* rune glyphs as line segments in a unit box */
const SILAS_RUNE=[[0,-1,0,1,0,-.5,.7,-1,0,0,.7,-.5],[-.4,-1,-.4,1,-.4,-1,.5,-.2,.5,-.2,-.4,.5],[0,-1,0,1,-.6,-.3,.6,.3],[-.5,1,0,-1,0,-1,.5,1,-.3,.2,.3,.2],
 [-.5,-1,-.5,1,.5,-1,.5,1,-.5,-.2,.5,.3],[0,-1,0,1,-.6,-.6,0,-.1,.6,-.6,0,-.1],[-.5,-1,.5,1,.5,-1,-.5,1,0,-1,0,1],[-.5,-.9,.5,-.9,0,-.9,0,1,-.5,.3,.5,.3],
 [-.5,1,-.5,-1,-.5,-1,.5,0,.5,0,-.5,1],[-.6,0,0,-1,0,-1,.6,0,.6,0,0,1,0,1,-.6,0]];
function silasSS(a,b,x){x=(x-a)/(b-a);return x<=0?0:x>=1?1:x*x*(3-2*x)}
function silasSt(g,lw,c){g.lineWidth=lw;g.strokeStyle=c||SILAS_O;g.stroke()}
function silasFS(g,fill,sx,lw,dk){g.fillStyle=fill;g.fill();if(sx!=null){g.save();g.clip();g.fillStyle=dk||'rgba(30,0,40,.2)';g.fillRect(sx,-420,600,840);g.restore()}if(lw)silasSt(g,lw)}
function silasEl(g,x,y,rx,ry,fill,lw,sx,rot){g.beginPath();g.ellipse(x,y,rx,ry,rot||0,0,SILAS_TAU);silasFS(g,fill,sx,lw)}
function silasHi(g,x1,y1,cx,cy,x2,y2,w,a){g.beginPath();g.moveTo(x1,y1);g.quadraticCurveTo(cx,cy,x2,y2);g.lineWidth=w||2.4;g.strokeStyle='rgba(255,255,255,'+(a||.7)+')';g.stroke()}
function silasLn(g,pts,w,c){g.beginPath();g.moveTo(pts[0],pts[1]);for(let i=2;i<pts.length;i+=4)g.quadraticCurveTo(pts[i],pts[i+1],pts[i+2],pts[i+3]);g.lineWidth=w;g.strokeStyle=c;g.stroke()}
function silasMix(A,B,u){const o=[];for(let i=0;i<A.length;i++)o.push(A[i]+(B[i]-A[i])*u);return o}
/* a gold filigree scroll: a stem with a curl at its end */
function silasCurl(g,x,y,a,s,dir){const c=Math.cos(a),n=Math.sin(a),P=(u,v)=>[x+(u*c-v*n)*s,y+(u*n+v*c)*s];
 const p0=P(0,0),p1=P(4,-2.5*dir),p2=P(7,0),p3=P(8.5,2.6*dir),p4=P(6.2,3.6*dir),p5=P(4.6,2.6*dir),p6=P(5.6,1.2*dir);
 g.moveTo(p0[0],p0[1]);g.quadraticCurveTo(p1[0],p1[1],p2[0],p2[1]);g.quadraticCurveTo(p3[0],p3[1],p4[0],p4[1]);g.quadraticCurveTo(p5[0],p5[1],p6[0],p6[1])}
/* a tapered smoky ribbon along a point list */
function silasRib(g,p,wm,fill,edge,core){const n=p.length>>1,L=[],R=[];
 for(let i=0;i<n;i++){const i0=i?i-1:0,i1=i<n-1?i+1:n-1;let dx=p[i1*2]-p[i0*2],dy=p[i1*2+1]-p[i0*2+1];const l=Math.hypot(dx,dy)||1,s=i/(n-1),w=wm*Math.pow(Math.sin(Math.PI*(.14+.86*s)),.85)*.5;
  L.push(p[i*2]-dy/l*w,p[i*2+1]+dx/l*w);R.push(p[i*2]+dy/l*w,p[i*2+1]-dx/l*w)}
 g.beginPath();g.moveTo(L[0],L[1]);for(let i=1;i<n-1;i++)g.quadraticCurveTo(L[i*2],L[i*2+1],(L[i*2]+L[i*2+2])/2,(L[i*2+1]+L[i*2+3])/2);g.lineTo(L[n*2-2],L[n*2-1]);
 g.lineTo(R[n*2-2],R[n*2-1]);for(let i=n-2;i>0;i--)g.quadraticCurveTo(R[i*2],R[i*2+1],(R[i*2]+R[i*2-2])/2,(R[i*2+1]+R[i*2-1])/2);g.lineTo(R[0],R[1]);g.closePath();
 g.fillStyle=fill;g.fill();if(edge){g.lineWidth=1.3;g.strokeStyle=edge;g.stroke()}
 if(core){g.beginPath();g.moveTo(p[0],p[1]);for(let i=1;i<n-1;i++)g.quadraticCurveTo(p[i*2],p[i*2+1],(p[i*2]+p[i*2+2])/2,(p[i*2+1]+p[i*2+3])/2);g.lineWidth=wm*.22;g.strokeStyle=core;g.stroke()}}
/* points of one curling wisp */
function silasWispPts(x,y,a,len,curl,t,ph,droop,wob){const N=12,st=len/N,p=[x,y];let h=a;
 for(let i=1;i<=N;i++){const s=i/N;h+=curl*(-.35+6*s*s*s)/N+Math.sin(t*1.5+ph+s*4)*.07*wob;if(droop>0){let d=Math.PI/2-h;d=Math.atan2(Math.sin(d),Math.cos(d));h+=d*droop*.16}
  x+=Math.cos(h)*st;y+=Math.sin(h)*st;p.push(x,y)}return p}
/* ---- an arcane ring of runes, built into the current path (call inside a transform) ---- */
function silasRunePath(g,r,n,sz,rot,seed){for(let i=0;i<n;i++){const a=rot+i*SILAS_TAU/n,c=Math.cos(a),s=Math.sin(a),G=SILAS_RUNE[(i*7+seed)%SILAS_RUNE.length],x=c*r,y=s*r;
  for(let j=0;j<G.length;j+=4){const u1=G[j]*sz*.6,v1=G[j+1]*sz,u2=G[j+2]*sz*.6,v2=G[j+3]*sz;
   g.moveTo(x-s*u1+c*v1,y+c*u1+s*v1);g.lineTo(x-s*u2+c*v2,y+c*u2+s*v2)}}}
/* the circle itself: rings, runes and a star; cx,cy centre, r radius, sy vertical squash, a alpha, rot spin */
function silasCircle(g,cx,cy,r,sy,a,rot,col,full){if(a<.01||r<4)return;
 g.save();g.globalCompositeOperation='lighter';g.lineCap='round';
 const gr=g.createRadialGradient(cx,cy,r*.1,cx,cy,r*1.05);gr.addColorStop(0,'rgba('+col+','+(a*.16).toFixed(3)+')');gr.addColorStop(.75,'rgba('+col+','+(a*.1).toFixed(3)+')');gr.addColorStop(1,'rgba('+col+',0)');
 g.save();g.translate(cx,cy);g.scale(1,sy);g.translate(-cx,-cy);g.fillStyle=gr;g.beginPath();g.arc(cx,cy,r*1.05,0,SILAS_TAU);g.fill();g.restore();
 const M=new DOMMatrix().translate(cx,cy).scale(1,sy);const T=()=>{g.save();g.setTransform(g.getTransform().multiply(M))};
 /* rings */
 T();g.beginPath();g.arc(0,0,r,0,SILAS_TAU);g.moveTo(r*.86,0);g.arc(0,0,r*.86,0,SILAS_TAU);if(full){g.moveTo(r*.5,0);g.arc(0,0,r*.5,0,SILAS_TAU)}g.restore();
 g.lineWidth=2.2;g.strokeStyle='rgba('+col+','+(a*.85).toFixed(3)+')';g.stroke();
 /* tick marks, runes and the inner star */
 T();g.beginPath();silasRunePath(g,r*.93,full?16:12,r*.05+1,rot,3);
 for(let i=0;i<24;i++){const q=-rot*1.3+i*SILAS_TAU/24;g.moveTo(Math.cos(q)*r*.86,Math.sin(q)*r*.86);g.lineTo(Math.cos(q)*r*(i&1?.8:.74),Math.sin(q)*r*(i&1?.8:.74))}
 if(full){for(let i=0;i<7;i++){const q=-rot*.7+i*SILAS_TAU/7*3-Math.PI/2;i?g.lineTo(Math.cos(q)*r*.72,Math.sin(q)*r*.72):g.moveTo(Math.cos(q)*r*.72,Math.sin(q)*r*.72)}g.closePath()}
 g.restore();g.lineWidth=1.6;g.strokeStyle='rgba(235,250,255,'+(a*.8).toFixed(3)+')';g.stroke();
 g.restore()}
/* ---- one card: 0 moon, 1 star, 2 key; back=1 draws the card back ---- */
function silasCard(g,kind,x,y,rot,sc,glow,t,back){g.save();g.translate(x,y);g.rotate(rot);g.scale(sc,sc);
 const tw=.85+.15*Math.sin(t*5+kind*2),gc=kind===1?'60,230,215':'255,205,90';
 if(glow>.04){g.globalCompositeOperation='lighter';const r=22+glow*16,gr=g.createRadialGradient(0,0,3,0,0,r);gr.addColorStop(0,'rgba('+gc+','+(.5*glow*tw).toFixed(3)+')');gr.addColorStop(1,'rgba('+gc+',0)');g.fillStyle=gr;g.fillRect(-r,-r,r*2,r*2);g.globalCompositeOperation='source-over'}
 const gold=glow>.6?'#ffd24a':'#e6a92a',teal=glow>.6?'#2fd8c8':SILAS_TEAL;
 if(back){g.beginPath();g.roundRect(-12,-17,24,34,4);silasFS(g,SILAS_RED2,2,2.8,'rgba(30,0,20,.25)');
  g.beginPath();g.roundRect(-8.6,-13.6,17.2,27.2,2.6);g.lineWidth=1.5;g.strokeStyle=gold;g.stroke();
  g.beginPath();g.moveTo(0,-11);g.lineTo(6.4,0);g.lineTo(0,11);g.lineTo(-6.4,0);g.closePath();g.lineWidth=1.2;g.stroke();
  g.beginPath();g.arc(0,0,4,.9,5.38);g.arc(2.4,0,3.1,-2.75,2.75,true);g.closePath();g.fillStyle=gold;g.fill();
  for(const [cx,cy] of [[-8.6,-13.6],[8.6,-13.6],[-8.6,13.6],[8.6,13.6]]){g.beginPath();g.arc(cx,cy,1.6,0,SILAS_TAU);g.fill()}
  g.restore();return}
 g.beginPath();g.roundRect(-12,-17,24,34,4);silasFS(g,'#fff6e2',3,2.8,'rgba(150,100,30,.13)');
 /* ornate double border with corner scrolls */
 g.beginPath();g.roundRect(-9,-14,18,28,2.6);g.lineWidth=1.6;g.strokeStyle='#d9a12a';g.stroke();
 g.beginPath();g.roundRect(-7,-12,14,24,1.6);g.lineWidth=.8;g.stroke();
 g.beginPath();for(const [cx,cy,sx,sy] of [[-9,-14,1,1],[9,-14,-1,1],[-9,14,1,-1],[9,14,-1,-1]]){g.moveTo(cx+sx*5,cy+sy*.2);g.quadraticCurveTo(cx+sx*2,cy+sy*3,cx+sx*.2,cy+sy*5);g.moveTo(cx+sx*3.4,cy+sy*1.4);g.arc(cx+sx*2.6,cy+sy*2.6,1,0,SILAS_TAU)}
 g.lineWidth=1.1;g.stroke();
 g.beginPath();g.moveTo(0,-16);g.lineTo(1.6,-14);g.lineTo(0,-12.4);g.lineTo(-1.6,-14);g.closePath();g.moveTo(0,16);g.lineTo(1.6,14);g.lineTo(0,12.4);g.lineTo(-1.6,14);g.closePath();g.fillStyle='#d9a12a';g.fill();
 if(kind===0){g.save();g.rotate(-.55);g.beginPath();g.arc(0,0,7.6,.939,5.344,false);g.arc(5.2,0,6.2,-3.0224,3.0224,true);g.closePath();g.fillStyle=gold;g.fill();g.lineWidth=1.6;g.strokeStyle=SILAS_O;g.stroke();g.restore();
  silasHi(g,-5.2,-2.4,-5.7,1.4,-3.8,4.3,1.4,.8);g.beginPath();g.arc(5,-6,.9,0,SILAS_TAU);g.arc(6.5,5,.7,0,SILAS_TAU);g.fillStyle=gold;g.fill()}
 else if(kind===1){g.beginPath();for(let i=0;i<8;i++){const a=i*Math.PI/4-Math.PI/2,r=i&1?2.9:9.5;i?g.lineTo(Math.cos(a)*r,Math.sin(a)*r):g.moveTo(Math.cos(a)*r,Math.sin(a)*r)}g.closePath();g.fillStyle=teal;g.fill();g.lineWidth=1.6;g.strokeStyle=SILAS_O;g.stroke();
  g.beginPath();g.moveTo(-1,-5.6);g.lineTo(-1.5,-2.3);g.lineWidth=1.3;g.strokeStyle='rgba(255,255,255,.8)';g.stroke()}
 else{g.beginPath();g.arc(0,-6,4.4,0,SILAS_TAU);g.moveTo(1.5,-1.9);g.lineTo(1.5,9.2);g.lineTo(-1.5,9.2);g.lineTo(-1.5,-1.9);g.fillStyle=gold;g.fill();g.lineWidth=1.6;g.strokeStyle=SILAS_O;g.stroke();
  g.beginPath();g.rect(1.5,4,3.8,2.1);g.rect(1.5,7.2,2.8,2);g.fillStyle=gold;g.fill();g.stroke();g.beginPath();g.arc(0,-6,1.6,0,SILAS_TAU);g.fillStyle=SILAS_O;g.fill()}
 if(glow>.3){g.globalCompositeOperation='lighter';const r=9+glow*7,gr=g.createRadialGradient(0,0,0,0,0,r);gr.addColorStop(0,'rgba('+gc+','+(.6*(glow-.3)*tw).toFixed(3)+')');gr.addColorStop(1,'rgba('+gc+',0)');g.fillStyle=gr;g.fillRect(-r,-r,r*2,r*2);g.globalCompositeOperation='source-over'}
 g.restore()}
/* ---- a 4-point sparkle ---- */
function silasSpark(g,x,y,r,a,col){if(r<.5)return;g.save();g.translate(x,y);g.globalCompositeOperation='lighter';const gr=g.createRadialGradient(0,0,0,0,0,r*1.6);gr.addColorStop(0,'rgba('+col+','+(.7*a).toFixed(3)+')');gr.addColorStop(1,'rgba('+col+',0)');g.fillStyle=gr;g.fillRect(-r*1.6,-r*1.6,r*3.2,r*3.2);
 g.beginPath();for(let i=0;i<8;i++){const q=i*Math.PI/4,rr=i&1?r*.16:r;i?g.lineTo(Math.cos(q)*rr,Math.sin(q)*rr):g.moveTo(rr,0)}g.closePath();g.fillStyle='rgba(255,255,240,'+a.toFixed(3)+')';g.fill();g.restore()}
/* ---- an arm: sleeve, gold-trimmed cuff, ghostly mitt ---- */
function silasArm(g,a,col,t,side){const [sx,sy,ex,ey,wx,wy]=a,cx=2*ex-(sx+wx)/2,cy=2*ey-(sy+wy)/2;
 g.beginPath();g.moveTo(sx,sy);g.quadraticCurveTo(cx,cy,wx,wy);g.lineWidth=20;g.strokeStyle=SILAS_O;g.stroke();g.lineWidth=13.4;g.strokeStyle=col;g.stroke();
 g.save();g.translate(-2.2,-1.8);g.beginPath();g.moveTo(sx+(cx-sx)*.2,sy+(cy-sy)*.2);g.quadraticCurveTo(cx,cy,(cx+wx)/2,(cy+wy)/2);g.lineWidth=2;g.strokeStyle='rgba(255,190,190,.22)';g.stroke();g.restore();
 let dx=wx-cx,dy=wy-cy;const l=Math.hypot(dx,dy)||1;dx/=l;dy/=l;
 /* gold braid where the sleeve meets the cuff */
 g.lineCap='butt';g.beginPath();g.moveTo(wx-dx*13,wy-dy*13);g.lineTo(wx-dx*9.5,wy-dy*9.5);g.lineWidth=17;g.strokeStyle=SILAS_O;g.stroke();g.lineWidth=13.4;g.strokeStyle=SILAS_GLD2;g.stroke();
 g.beginPath();g.moveTo(wx-dx*9.5,wy-dy*9.5);g.lineTo(wx+dx*2.5,wy+dy*2.5);g.lineWidth=21;g.strokeStyle=SILAS_O;g.stroke();
 g.beginPath();g.moveTo(wx-dx*8,wy-dy*8);g.lineTo(wx+dx*1,wy+dy*1);g.lineWidth=15.4;g.strokeStyle=SILAS_CRM;g.stroke();
 g.beginPath();g.moveTo(wx-dx*8-dy*5,wy-dy*8+dx*5);g.lineTo(wx+dx*1-dy*5,wy+dy*1+dx*5);g.lineWidth=4;g.strokeStyle='rgba(150,100,40,.25)';g.stroke();
 g.beginPath();g.moveTo(wx-dx*5.6+dy*7.2,wy-dy*5.6-dx*7.2);g.lineTo(wx-dx*5.6-dy*7.2,wy-dy*5.6+dx*7.2);g.lineWidth=1.5;g.strokeStyle=SILAS_GLD2;g.stroke();g.lineCap='round';
 g.beginPath();silasCurl(g,wx-dx*2-dy*side*5,wy-dy*2+dx*side*5,Math.atan2(dy,dx)+side*.4,.75,side);g.lineWidth=1.3;g.strokeStyle=SILAS_GLD2;g.stroke();
 silasEl(g,wx-dx*3.5+dy*side*4,wy-dy*3.5-dx*side*4,2.4,2.4,SILAS_GLD,1.6);
 const hx=wx+dx*8,hy=wy+dy*8,an=Math.atan2(dy,dx);
 silasEl(g,hx-dy*side*6+dx*1,hy+dx*side*6+dy*1,4,3.4,SILAS_SK,2.4,null,an);
 silasEl(g,hx,hy,8.6,8,SILAS_SK,2.8,hx+2,an);
 g.beginPath();g.moveTo(hx+dx*3+dy*side*3,hy+dy*3-dx*side*3);g.lineTo(hx+dx*7+dy*side*1,hy+dy*7-dx*side*1);g.lineWidth=1.6;g.strokeStyle='rgba(18,8,31,.6)';g.stroke();
 silasHi(g,hx-5,hy-2,hx-4,hy-5,hx-1,hy-6,1.5,.5);
 return [hx,hy,dx,dy]}
/* ---- the masquerade mask, centred between its eyeholes; holes at -11.5,1 and 11.5,0 ---- */
function silasMaskPath(g){g.moveTo(-32,-15);g.quadraticCurveTo(-23,-15.5,-13,-12.5);g.quadraticCurveTo(-4,-11,0,-6.5);g.quadraticCurveTo(4,-11,13,-12.5);g.quadraticCurveTo(23,-15.5,32,-15);
 g.quadraticCurveTo(31,1,22,9.5);g.quadraticCurveTo(12,15,3.5,9);g.quadraticCurveTo(0,6.5,-3.5,9);g.quadraticCurveTo(-12,15,-22,9.5);g.quadraticCurveTo(-31,1,-32,-15);g.closePath()}
function silasHoles(g){g.moveTo(-2.8,1.4);g.ellipse(-11.5,1,8.8,7.4,.1,0,SILAS_TAU);g.moveTo(20.3,0);g.ellipse(11.5,0,8.8,7.4,-.1,0,SILAS_TAU)}
function silasMask(g,x,y,rot,sc,fx,t,glow,heat){g.save();g.translate(x,y);g.rotate(rot);g.scale(sc*fx,sc);const dS=fx<0?-62:2;
 /* feather plume off the right wing */
 const fs=Math.sin(t*2.3)*.07;
 for(const [a,l,w,c] of [[-1.55,30,5.6,SILAS_PLUM],[-1.15,38,7.2,SILAS_RED],[-.75,28,5.6,'#e8b33a']]){const q=a+fs,ex=27+Math.cos(q)*l,ey=-12+Math.sin(q)*l,nx=-Math.sin(q)*w,ny=Math.cos(q)*w;
  g.beginPath();g.moveTo(27,-12);g.quadraticCurveTo(27+Math.cos(q)*l*.5+nx,-12+Math.sin(q)*l*.5+ny,ex,ey);g.quadraticCurveTo(27+Math.cos(q)*l*.5-nx,-12+Math.sin(q)*l*.5-ny,27,-12);
  silasFS(g,c,null,2.2);g.beginPath();g.moveTo(27,-12);g.quadraticCurveTo(27+Math.cos(q+.08)*l*.5,-12+Math.sin(q+.08)*l*.5,ex,ey);g.lineWidth=1;g.strokeStyle='rgba(255,240,210,.55)';g.stroke()}
 /* face of the mask */
 g.beginPath();silasMaskPath(g);silasHoles(g);g.fillStyle=SILAS_RED;g.fill('evenodd');
 g.save();g.clip('evenodd');g.fillStyle='rgba(40,0,20,.24)';g.fillRect(dS,-30,60,60);g.fillStyle='rgba(40,0,20,.22)';g.fillRect(-40,5,80,20);
 g.beginPath();silasMaskPath(g);g.lineWidth=5.6;g.strokeStyle=SILAS_GLD;g.stroke();
 g.beginPath();g.moveTo(-28*Math.sign(fx),-11);g.quadraticCurveTo(-20*Math.sign(fx),-12.5,-13*Math.sign(fx),-9);g.lineWidth=1.6;g.strokeStyle='rgba(255,220,220,.5)';g.stroke();g.restore();
 g.beginPath();silasMaskPath(g);silasHoles(g);g.lineWidth=2.8;g.strokeStyle=SILAS_O;g.stroke();
 /* gold rims round the eyeholes */
 g.beginPath();g.ellipse(-11.5,1,10.4,9,.1,0,SILAS_TAU);g.moveTo(21.9,0);g.ellipse(11.5,0,10.4,9,-.1,0,SILAS_TAU);g.lineWidth=2.2;g.strokeStyle=SILAS_GLD;g.stroke();
 /* filigree scrolls on the cheeks and wings */
 g.beginPath();silasCurl(g,-21,7,-2.7,1,1);silasCurl(g,21,7,-.44,1,-1);silasCurl(g,-26,-8,-1.9,.8,-1);silasCurl(g,26,-8,-1.24,.8,1);
 g.moveTo(-6,7);g.quadraticCurveTo(-3,4,0,5);g.quadraticCurveTo(3,4,6,7);g.lineWidth=1.3;g.strokeStyle='#ffd866';g.stroke();
 /* gem at the brow */
 g.beginPath();g.moveTo(0,-14);g.lineTo(4,-9);g.lineTo(0,-3.6);g.lineTo(-4,-9);g.closePath();silasFS(g,SILAS_GLD,null,2);
 g.beginPath();g.moveTo(0,-12);g.lineTo(2.4,-9);g.lineTo(0,-5.8);g.lineTo(-2.4,-9);g.closePath();g.fillStyle=glow>.3?'#7ffff0':'#2fd8c8';g.fill();
 g.beginPath();g.moveTo(-.8,-10.8);g.lineTo(-1.5,-9);g.lineWidth=1;g.strokeStyle='rgba(255,255,255,.9)';g.stroke();
 if(heat>.05||glow>.05){const a=Math.max(heat*.5,glow)*(.8+.2*Math.sin(t*6));silasSpark(g,0,-9,5+5*a,a*.8,'90,240,225')}
 g.restore()}
/* ---- the head, centred on 0,0 (drawn at 1.15x) ---- */
function silasHead(g,t,ex,sway){
 /* tufts behind the head */
 g.beginPath();g.moveTo(-24,-8);g.quadraticCurveTo(-36,-6,-40+sway,4);g.quadraticCurveTo(-30,0,-24,6);g.closePath();silasFS(g,'#e8c978',null,3);
 g.beginPath();g.moveTo(24,-8);g.quadraticCurveTo(36,-6,39+sway,6);g.quadraticCurveTo(30,2,24,8);g.closePath();silasFS(g,'#d6b25e',null,3);
 g.beginPath();g.moveTo(-6,-30);g.bezierCurveTo(-26,-30,-27,-14,-26,4);g.bezierCurveTo(-25,22,-16,32,0,32);g.bezierCurveTo(16,32,26,22,26,4);g.bezierCurveTo(27,-14,22,-30,-6,-30);g.closePath();silasFS(g,SILAS_SK,9,3.4,'rgba(20,30,70,.2)');
 silasHi(g,-22,10,-21,18,-16,24,2.2,.45);
 /* cool rim light on the shadow side */
 g.beginPath();g.moveTo(22.5,-6);g.bezierCurveTo(23.5,6,22,18,13,26.5);g.lineWidth=2.2;g.strokeStyle='rgba(160,235,255,.42)';g.stroke();
 /* blush */
 g.save();g.globalAlpha=.6;silasEl(g,-15,12,6.5,3.6,'#ff78a8',0);silasEl(g,25,10,5.2,3.4,'#ff78a8',0);g.restore();
 /* eyes */
 const E=[[-8,0,9.6],[15,-1,9]];
 for(const [x,y,r] of E){
  if(ex.happy&&!ex.glow){g.beginPath();g.moveTo(x-7.5,y+3);g.quadraticCurveTo(x,y-8,x+7.5,y+3);silasSt(g,3.4);continue}
  if(ex.blink&&!ex.glow){g.beginPath();g.moveTo(x-8,y+1);g.quadraticCurveTo(x,y+5,x+8,y+1);silasSt(g,3.2);continue}
  silasEl(g,x,y,r,r,'#fffaf0',3);
  const px=x+ex.px*3.6+1,py=y+ex.py*3.6+.6;
  if(ex.glow>.05){silasEl(g,px,py,5,5.2,ex.glow>.5?'#38e6d6':'#1d5a66',0);silasEl(g,px,py,2.2,2.4,'#eafffb',0)}
  else{silasEl(g,px,py,4.6,4.8,'#1a1230',0);silasEl(g,px-1.6,py-1.8,1.6,1.6,'#fff',0);silasEl(g,px+1.8,py+1.6,.8,.8,'#fff',0)}
  if(ex.lid>0){g.save();g.beginPath();g.arc(x,y,r-1.4,0,SILAS_TAU);g.clip();g.translate(x,y);g.rotate(x<0?-.28:.28);g.fillStyle=SILAS_SK;g.fillRect(-r-2,-r-2,r*2+4,(r+2)*ex.lid*1.05);g.restore();
   g.save();g.translate(x,y);g.rotate(x<0?-.28:.28);g.beginPath();g.moveTo(-r*.9,-r-1+(r+2)*ex.lid*1.05);g.lineTo(r*.9,-r-1+(r+2)*ex.lid*1.05);silasSt(g,2.6);g.restore()}}
 /* the long friendly nose */
 g.beginPath();g.moveTo(1,-8);g.quadraticCurveTo(-1,5,4,12);g.quadraticCurveTo(8,19.5,14.5,15);g.quadraticCurveTo(18,9,11,4.5);g.quadraticCurveTo(7.5,-1,8,-8);silasFS(g,SILAS_SKL,11,2.8,'rgba(20,30,70,.16)');
 silasHi(g,4,8,6,13,9,14,1.6,.75);
 /* mouth */
 if(ex.happy){g.beginPath();g.moveTo(-6,18);g.quadraticCurveTo(6,34,21,16);g.quadraticCurveTo(7,22,-6,18);g.closePath();silasFS(g,'#3a0a1e',null,2.8);
  g.save();g.clip();silasEl(g,8,27,6,4,'#ff6a8a',0);g.restore()}
 else if(ex.sad>.5){g.beginPath();g.moveTo(-1,25);g.quadraticCurveTo(7,18,16,24);silasSt(g,2.8)}
 else if(ex.think){g.beginPath();g.moveTo(1,23);g.quadraticCurveTo(9,20.5,15,23.5);silasSt(g,2.8)}
 else if(ex.glow>.5){g.beginPath();g.moveTo(-4,19);g.quadraticCurveTo(7,30,19,18);g.quadraticCurveTo(8,23,-4,19);g.closePath();silasFS(g,'#3a0a1e',null,2.6)}
 else{g.beginPath();g.moveTo(-5,20);g.quadraticCurveTo(6,28,18.5,18.5);silasSt(g,2.8);g.beginPath();g.moveTo(17,21.5);g.quadraticCurveTo(19.5,19.5,19.5,16.5);silasSt(g,2.2)}
 /* messy swept hair, every tuft drifting on its own */
 const s=sway,w=i=>s+Math.sin(t*2.1+i*1.7)*1.1,P=[[-26,-2],[-37+w(1),-11],[-29,-19],[-39+w(3),-33],[-27,-37],[-26+w(5),-52-w(5)*.4],[-11,-47],[1+w(7)*.8,-58-w(7)*.3],[10,-48],[24+w(9)*.8,-52],[24,-40],[38+w(11),-38],[29,-28],[41+w(13),-16],[28,-14],[33+w(15),-3],[25,-6]];
 const F=[[20,-19],[14+s*.3,-12],[8,-21],[1+s*.3,-13],[-5,-22],[-12+s*.3,-14],[-18,-21],[-25+s*.3,-9]];
 const hairPath=()=>{g.beginPath();g.moveTo(P[0][0],P[0][1]);
  const seg=(a,b,bend)=>{const mx=(a[0]+b[0])/2,my=(a[1]+b[1])/2,dx=b[0]-a[0],dy=b[1]-a[1];g.quadraticCurveTo(mx-dy*bend,my+dx*bend,b[0],b[1])};
  for(let i=1;i<P.length;i++)seg(P[i-1],P[i],i&1?-.34:.16);
  let last=P[P.length-1];F.forEach((q,i)=>{seg(last,q,i&1?-.24:.1);last=q});seg(last,P[0],.1);g.closePath()};
 hairPath();silasFS(g,'#f4dc94',10,null,'rgba(150,95,20,.2)');
 g.save();g.clip();g.beginPath();g.moveTo(18,-50);g.quadraticCurveTo(30,-30,26,-8);g.lineTo(60,-8);g.lineTo(60,-50);g.fillStyle='rgba(150,95,20,.14)';g.fill();
 g.beginPath();g.moveTo(-24,-30);g.quadraticCurveTo(-14,-48,8,-47);g.quadraticCurveTo(-4,-42,-12,-33);g.quadraticCurveTo(-18,-28,-24,-30);g.closePath();g.fillStyle='rgba(255,250,225,.9)';g.fill();
 g.beginPath();g.moveTo(-30,-17);g.quadraticCurveTo(-26,-26,-20,-27);g.quadraticCurveTo(-24,-23,-25,-15);g.closePath();g.fillStyle='rgba(255,250,225,.6)';g.fill();
 g.lineWidth=1.8;g.strokeStyle='rgba(170,115,30,.55)';
 for(const [a,b,c,d,e,f] of [[6,-28,12,-34,14,-42],[22,-22,27,-26,31,-33],[-22,-18,-26,-22,-32,-25],[-4,-30,-6,-38,-14,-44],[14,-24,20,-30,26,-44],[-14,-24,-16,-30,-24,-36]]){g.beginPath();g.moveTo(a,b);g.quadraticCurveTo(c,d,e,f);g.stroke()}
 g.beginPath();g.moveTo(33,-36);g.quadraticCurveTo(37,-24,38,-15);g.lineWidth=1.8;g.strokeStyle='rgba(160,235,255,.4)';g.stroke();
 g.restore();hairPath();silasSt(g,3.4);
}
/* ---- the whole phantom: base of the smoke at 0,0 ---- */
function silasDraw(g,t,st){st=st||{};t=t||0;const mode=st.mode||'idle',k=Math.max(0,Math.min(1,st.k||0)),heat=Math.max(0,Math.min(1,st.heat||0)),look=Math.max(-1,Math.min(1,st.look||0)),pt=!!st._pt;
 const env=silasSS(0,.2,k)*(1-silasSS(.8,1,k)),bump=Math.sin(Math.PI*k);
 const eA=mode==='ability'?env:0,eC=mode==='cheer'?env:0,eS=mode==='sad'?silasSS(0,.25,k)*(1-silasSS(.85,1,k)):0,eT=mode==='think'?1:0;
 const eW=mode==='ability'?silasSS(.04,.26,k)*(1-silasSS(.74,.94,k)):0,peak=mode==='ability'?Math.max(0,1-Math.abs(k-.5)/.16):0;
 const tt=t*(1+heat*.5),bob=Math.sin(t*1.6)*4*(1-eS*.5),br=Math.sin(t*2.1)*.9;
 const lift=-4+bob-eA*10-(mode==='cheer'?bump*20:0)+eS*4;
 const spin=mode==='cheer'?Math.cos(Math.PI*2*silasSS(.08,.55,k)):1,sx=(spin<0?-1:1)*(.55+.45*Math.abs(spin));
 const fade=1-eS*.55;
 g.save();g.lineJoin='round';g.lineCap='round';
 /* aura, arcane floor circle, ground smoke and shadow */
 if(!pt){const gr=g.createRadialGradient(0,-120,10,0,-120,140);gr.addColorStop(0,'rgba(130,180,215,'+(.12+heat*.14+eA*.12).toFixed(3)+')');gr.addColorStop(1,'rgba(130,180,215,0)');g.fillStyle=gr;g.fillRect(-140,-260,280,280);
  g.save();g.globalAlpha=.3;silasEl(g,0,-2,40,7,'#000',0);g.restore();
  const cr=58+heat*6+eA*34*silasSS(0,.3,k)+eC*6,ca=(.22+heat*.3)*(1-eS*.6)+eA*.6+eC*.25;
  silasCircle(g,0,-9,cr,.21,Math.min(1,ca),t*.25+(mode==='ability'?k*5:0),eA>.3||heat>.6?'120,235,240':'160,190,255',eA>.2||heat>.5);
  const g2=g.createRadialGradient(0,-4,2,0,-4,56);g2.addColorStop(0,'rgba(170,200,225,'+(.42+heat*.2).toFixed(3)+')');g2.addColorStop(1,'rgba(170,200,225,0)');g.save();g.scale(1,.26);g.fillStyle=g2;g.beginPath();g.arc(0,-15,56,0,SILAS_TAU);g.fill();g.restore();
  /* the great sigil that unfolds behind him */
  if(eA>.02){const u=silasSS(.05,.4,k)*(1-silasSS(.82,1,k));silasCircle(g,0,-142,30+66*u,1,u*.62,-k*3.2,'255,205,110',1);
   /* a column of light rising from the floor circle */
   const cg=g.createLinearGradient(0,0,0,-250);cg.addColorStop(0,'rgba(120,235,240,'+(eA*.3).toFixed(3)+')');cg.addColorStop(1,'rgba(120,235,240,0)');g.save();g.globalCompositeOperation='lighter';g.fillStyle=cg;
   g.beginPath();g.moveTo(-cr*.8,-8);g.lineTo(-cr*.45,-250);g.lineTo(cr*.45,-250);g.lineTo(cr*.8,-8);g.closePath();g.fill();g.restore()}}
 g.translate(0,lift);if(sx!==1)g.scale(sx,1);
 if(mode==='sad')g.rotate(.03*eS);
 if(mode==='cheer')g.rotate(Math.sin(k*Math.PI*3)*.05*env);
 /* pose */
 const AP=SILAS_ARM;let L=AP.idle[0].slice(),R=AP.idle[1].slice();
 L[5]+=Math.sin(t*2.2)*1.5;L[3]+=Math.sin(t*2.2)*.8;R[4]+=Math.sin(t*1.7)*1.2;R[5]+=Math.sin(t*1.7+1)*1;
 if(pt){L=silasMix(L,AP.sad[0],.8);R=[32,-133,50,-118,46,-150]}
 if(eA){L=silasMix(L,AP.mask[0],eA)}
 if(eW){R=silasMix(R,AP.mask[1],eW)}
 if(eC){L=silasMix(L,AP.up[0],eC);R=silasMix(R,AP.up[1],eC)}
 if(eS){L=silasMix(L,AP.sad[0],eS);R=silasMix(R,AP.sad[1],eS)}
 const tap=eT?Math.pow(Math.max(0,Math.sin(t*4.2)),6):0;
 if(eT){const th=Math.sin(t*1.3)*1.2;L=AP.think[0].slice();R=AP.think[1].slice();R[5]-=tap*3;L[4]+=th*.5;L[5]+=th}
 L[1]+=br*.6;R[1]+=br*.6;
 const hx=3,hy=-182+br*.8+eS*7-eC*3,hr=Math.sin(t*1.1)*.03+eS*.12-eT*.07+(mode==='cheer'?Math.sin(k*Math.PI*4)*.06*env:0)-eW*.06;
 /* hand positions (needed for wisps, cards and the mask) */
 const hand=a=>{const cx=2*a[2]-(a[0]+a[4])/2,cy=2*a[3]-(a[1]+a[5])/2;let dx=a[4]-cx,dy=a[5]-cy;const l=Math.hypot(dx,dy)||1;return [a[4]+dx/l*8,a[5]+dy/l*8,dx/l,dy/l]};
 const HL=hand(L),HR=hand(R);
 /* the mask: held on its stick, or raised to his face */
 let MK=null;{let th=-1.4+Math.sin(t*1.7)*.06,ro=-.05,ln=30;
  if(pt){th=-1.25;ro=.1;ln=24}
  if(eC){const f=Math.sin(k*Math.PI*2);th=th+(-1.3-th)*eC+f*.45*eC;ro=ro+f*.35*eC}
  if(eS){th=th+(1.62-th)*eS;ro=ro+(-.5-ro)*eS;ln-=14*Math.sin(Math.PI*eS)}
  if(eT){th=.5+tap*.16;ro=-1.75;ln=28}
  const sc=pt?.8:.88,mr0=th+Math.PI/2+ro,cr=Math.cos(mr0),sr=Math.sin(mr0),ax=HR[0]+Math.cos(th)*ln,ay=HR[1]+Math.sin(th)*ln;
  let mx=ax-(-cr*25-sr*8)*sc,my=ay-(-sr*25+cr*8)*sc,mr=mr0,ms=sc,fx=-1;
  if(eW>0){const fc=Math.cos(hr),fs=Math.sin(hr),fX=hx+(fc*3.5+fs*1)*1.15,fY=hy+(fs*3.5-fc*1)*1.15,u=eW;mx+=(fX-mx)*u;my+=(fY-my)*u;mr+=(hr-mr)*u;ms+=(1.15-ms)*u;fx=-1+2*silasSS(.15,.6,u)}
  const c2=Math.cos(mr),s2=Math.sin(mr),atx=mx+(c2*25*fx-s2*8)*ms,aty=my+(s2*25*fx+c2*8)*ms;MK=[mx,my,mr,ms,atx,aty,fx]}
 /* cards: x,y,rot,scale,front */
 const cardAt=(i,kk,ea)=>{const fa=-.1*(1-eS)+(-2.5)*eS;const px=HL[0]+HL[2]*3,py=HL[1]+HL[3]*3;
  const fr=44-20*eS,a=fa+(i-1)*(.5-.16*eS)+Math.sin(t*2.2+i)*.035;let c=[px+Math.sin(a)*fr,py-Math.cos(a)*fr+15*(1-eS),a,1,1];
  if(eT){const an=t*1.1+i*Math.PI*2/3,sn=Math.sin(an);c=[-60+Math.cos(an)*34,-200+sn*14+Math.sin(t*2+i)*2,Math.sin(t*.9+i)*.22,.84+.14*sn,sn>-.2?1:0]}
  if(ea){const an=i*Math.PI*2/3+kk*Math.PI*2*1.8-1.2,sn=Math.sin(an),rise=Math.sin(kk*Math.PI*2+i)*14-Math.sin(Math.PI*kk)*18;
   const o=[Math.cos(an)*86,-118+sn*30+rise,an*.5+kk*6,1+.16*sn,sn>0?1:0];c=silasMix(c,o,ea);c[4]=ea>.3?o[4]:1}
  if(eC){const o=[[-80,-212],[-26,-250],[30,-256]][i],u=silasSS(0,.45,kk)*(1-silasSS(.65,1,kk));c=silasMix(c,[o[0],o[1]+Math.sin(t*3+i)*3,(i-1)*.5+Math.sin(kk*Math.PI*2)*(i-1)*1.2,1.06,1],u);c[4]=1}
  return c};
 const cards=[];if(!pt)for(let i=0;i<3;i++)cards.push(cardAt(i,k,eA));
 const glow=.12+heat*.88+eA*.3;
 /* wisps */
 const wA=(.5+heat*.28)*(1-eS*.3),wc=[Math.round(150-heat*10),Math.round(176+heat*50),Math.round(200+heat*30)];
 const wf='rgba('+wc+','+wA.toFixed(3)+')',wfw='rgba('+wc+','+(wA*.28).toFixed(3)+')',we='rgba(40,60,110,'+(wA*.42).toFixed(3)+')',wco='rgba(230,248,255,'+(.18+heat*.3).toFixed(3)+')';
 const drawW=front=>{for(let i=0;i<SILAS_WISP.length;i++){const w=SILAS_WISP[i];if(w[7]!==front)continue;let al=1;if(i>=14){const need=(i-13)/7;al=Math.max(0,Math.min(1,(heat+.1-need)*4));if(al<=0)continue}
   let x=w[0],y=w[1];if(w[8]===1){x+=HL[0];y+=HL[1]}else if(w[8]===2){x+=HR[0];y+=HR[1]}if(pt&&w[8]===0)continue;
   const len=w[3]*(1+heat*.3)*(.92+.08*Math.sin(tt*1.3+w[6])),dr=eS*.9+(w[8]===0?0:.15);
   const p=silasWispPts(x,y,w[2]+Math.sin(tt*.9+w[6])*.25,len,w[4]*(1+eC*.4),tt,w[6],dr,1+heat*.8);
   const fa2=w[8]===0?fade:1;if(al*fa2<.99){g.save();g.globalAlpha=al*fa2}
   /* a soft trailing echo, then the wisp itself with a curled puff at its tip */
   if(w[8]!==1&&w[8]!==2){const p2=silasWispPts(x,y,w[2]+Math.sin(tt*.9+w[6]-.6)*.25,len*1.12,w[4]*1.15,tt-.35,w[6]+.8,dr,1+heat*.8);silasRib(g,p2,w[5]*1.7,wfw,null,null)}
   silasRib(g,p,w[5]*(1+heat*.25),wf,we,wco);
   const n=p.length;g.beginPath();g.arc(p[n-2],p[n-1],w[5]*.28+.6,0,SILAS_TAU);g.fillStyle=wf;g.fill();
   if(al*fa2<.99)g.restore()}};
 /* little floating motes and twinkles */
 const motes=()=>{const n=6+Math.round(heat*6)+Math.round(eA*6);for(let i=0;i<n;i++){const ph=i*1.7,rise=(t*(10+heat*8+eA*20)+i*29)%70,x=Math.sin(ph*3.1)*(58+eA*30)+Math.sin(t*.8+ph)*6,y=-30-((i*41)%150)-rise,a=Math.sin(Math.PI*rise/70)*(.5+heat*.4);
  if(i%3===2)silasSpark(g,x,y,3.2+heat*1.6,a*.9,i%2?'255,220,130':'140,240,235');else silasEl(g,x,y,1.8+(i%3)*.7,1.8+(i%3)*.7,'rgba('+wc+','+a.toFixed(3)+')',0)}};
 /* vortex ribbons and card light trails for the ability */
 const vortex=front=>{if(eA<.02)return;for(let j=0;j<4;j++){let pts=[];const a0=k*Math.PI*2*1.4+j*1.6,flush=()=>{if(pts.length>=8)silasRib(g,pts,10-j*1.6,'rgba('+wc+','+(eA*(.4+heat*.25)).toFixed(3)+')',null,'rgba(235,250,255,'+(eA*.5).toFixed(3)+')');pts=[]};
   for(let i=0;i<=18;i++){const s=i/18,an=a0+s*2.9,rr=(92-j*8)*(1-.14*s),sn=Math.sin(an);if((sn>0)!==front){flush();continue}pts.push(Math.cos(an)*rr,-40-j*42+sn*(24-j*3)-s*30)}flush()}
  g.save();g.globalCompositeOperation='lighter';
  for(let i=0;i<3;i++){let prev=null;for(let j=0;j<9;j++){const c=cardAt(i,k-j*.016,eA);if((c[4]===1)!==front){prev=null;continue}if(prev){g.beginPath();g.moveTo(prev[0],prev[1]);g.lineTo(c[0],c[1]);g.lineWidth=(9-j)*1.1;g.strokeStyle='rgba('+(i===1?'90,240,225':'255,215,120')+','+(eA*(.32-j*.032)).toFixed(3)+')';g.stroke()}prev=c}}
  g.restore()};
 /* a fountain of little cards for the cheer */
 const fountain=()=>{if(mode!=='cheer'||pt)return;for(let j=0;j<7;j++){const u=(k*1.7-j*.1);if(u<=0||u>=1)continue;const vx=-30+j*20,x=HL[0]+vx*u*1.7,y=HL[1]-20-150*u+150*u*u,a=Math.min(1,(1-u)*4);
   g.save();g.globalAlpha=a;silasCard(g,j%3,x,y,(j-3)*.3+u*(j&1?5:-5),.56,.4+heat*.5,t,j%2);g.restore()}};
 vortex(false);drawW(0);
 for(let i=0;i<cards.length;i++){const c=cards[i];if(!c[4])silasCard(g,i,c[0],c[1],c[2],c[3],glow,t,eA>.3||eT?1:0)}
 /* coat tails: crimson with plum lining, gold trim and scrollwork, swaying */
 const sw=Math.sin(t*1.8)*3+eC*6*Math.sin(k*Math.PI*6),sw2=Math.sin(t*1.8-.7)*3+eC*6*Math.sin(k*Math.PI*6-.6),fl=eA*8+eC*8-eS*3;
 const tl=[-50-fl+sw,-30+eS*3],tr=[49+fl+sw2*.8,-30+eS*3];
 g.beginPath();g.moveTo(-28,-104);g.quadraticCurveTo(-40-fl*.5,-76,tl[0]+2,tl[1]-8);g.lineTo(tl[0]+12,tl[1]-14);g.quadraticCurveTo(-24,-66,-12,-96);g.closePath();silasFS(g,SILAS_PLUM,null,3);
 g.beginPath();g.moveTo(28,-104);g.quadraticCurveTo(40+fl*.5,-76,tr[0]-2,tr[1]-8);g.lineTo(tr[0]-12,tr[1]-14);g.quadraticCurveTo(24,-66,12,-96);g.closePath();silasFS(g,'#2a0f34',null,3);
 const tailL=()=>{g.beginPath();g.moveTo(-30,-108);g.quadraticCurveTo(-42-fl*.5,-78,tl[0],tl[1]);g.quadraticCurveTo(tl[0]+6,tl[1]-4,tl[0]+13,tl[1]-12);g.quadraticCurveTo(-22,-66,-8,-96);g.closePath()};
 const tailR=()=>{g.beginPath();g.moveTo(30,-108);g.quadraticCurveTo(42+fl*.5,-78,tr[0],tr[1]);g.quadraticCurveTo(tr[0]-6,tr[1]-4,tr[0]-13,tr[1]-12);g.quadraticCurveTo(22,-66,8,-96);g.closePath()};
 tailL();silasFS(g,SILAS_RED,-30,null,'rgba(40,0,20,.22)');g.save();g.clip();tailL();g.lineWidth=4.4;g.strokeStyle=SILAS_GLD2;g.stroke();g.restore();tailL();silasSt(g,3.2);
 tailR();silasFS(g,SILAS_RED2,null,null);g.save();g.clip();tailR();g.lineWidth=4.4;g.strokeStyle=SILAS_GLD2;g.stroke();g.restore();tailR();silasSt(g,3.2);
 g.beginPath();silasCurl(g,tl[0]+12,tl[1]-20,-1.75,1.1,-1);silasCurl(g,tr[0]-12,tr[1]-20,-1.39,1.1,1);g.moveTo(-27,-98);g.quadraticCurveTo(-36,-74,tl[0]+8,tl[1]-22);g.lineWidth=1.4;g.strokeStyle='#e6a92a';g.stroke();
 g.beginPath();g.moveTo(-27,-100);g.quadraticCurveTo(-36,-74,-44-fl+sw,-40);g.lineWidth=2;g.strokeStyle='rgba(40,0,20,.3)';g.stroke();
 g.beginPath();g.moveTo(34,-100);g.quadraticCurveTo(43+fl*.4,-76,tr[0]-1,tr[1]-6);g.lineWidth=2;g.strokeStyle='rgba(160,235,255,.3)';g.stroke();
 /* trousers fading into smoke, then the shoes beneath */
 {const lg=g.createLinearGradient(0,-54,0,-24);lg.addColorStop(0,'rgba(102,22,44,'+fade+')');lg.addColorStop(1,'rgba(102,22,44,0)');const lo=g.createLinearGradient(0,-50,0,-26);lo.addColorStop(0,SILAS_O);lo.addColorStop(1,'rgba(18,8,31,0)');
  const ld=g.createLinearGradient(0,-54,0,-24);ld.addColorStop(0,'rgba(66,10,30,'+fade+')');ld.addColorStop(1,'rgba(66,10,30,0)');
  for(const s of [-1,1]){g.beginPath();g.moveTo(0,-96);g.lineTo(s*23,-96);g.lineTo(s*20,-24);g.lineTo(s*3,-24);g.lineTo(0,-86);g.closePath();g.fillStyle=s<0?lg:ld;g.fill();g.lineWidth=3.2;g.strokeStyle=lo;g.stroke()}
  g.save();g.globalAlpha=.92*fade;for(const s of [-1,1]){const y0=-7;g.beginPath();g.moveTo(s*5,y0-12);g.quadraticCurveTo(s*6,y0-20,s*15,y0-20);g.quadraticCurveTo(s*29,y0-20,s*30,y0-7);g.quadraticCurveTo(s*18,y0-1,s*5,y0-3);g.closePath();silasFS(g,'#1c1424',null,2.8);silasHi(g,s*11,y0-15,s*15,y0-18,s*21,y0-16,2,.8);
   g.beginPath();g.moveTo(s*9,y0-12);g.lineTo(s*15,y0-12);g.lineWidth=2.2;g.strokeStyle=SILAS_GLD2;g.stroke()}g.restore()}
 /* torso: waistcoat, shirt, coat fronts, lapels, bow tie */
 g.save();g.translate(0,-96);g.scale(1,1+br*.006);g.translate(0,96);
 /* high phantom collar standing behind the neck */
 for(const s of [-1,1]){g.beginPath();g.moveTo(s*8,-146);g.quadraticCurveTo(s*30,-150,s*46,-180);g.quadraticCurveTo(s*36,-158,s*22,-141);g.closePath();silasFS(g,s<0?SILAS_RED:SILAS_RED2,null,2.8);
  g.beginPath();g.moveTo(s*12,-148);g.quadraticCurveTo(s*29,-152,s*41,-172);g.lineWidth=1.4;g.strokeStyle=SILAS_GLD2;g.stroke()}
 g.beginPath();g.rect(-7,-158,14,14);silasFS(g,SILAS_SK,1,2.8);
 const vest=()=>{g.beginPath();g.moveTo(-16,-142);g.lineTo(16,-142);g.lineTo(19,-96);g.lineTo(12,-84);g.lineTo(0,-92);g.lineTo(-12,-84);g.lineTo(-19,-96);g.closePath()};
 vest();silasFS(g,SILAS_TEAL,null,null);
 g.save();g.clip();g.fillStyle='rgba(10,40,50,.24)';g.fillRect(2,-150,30,70);g.beginPath();for(let i=-6;i<6;i++){g.moveTo(-24+i*8,-150);g.lineTo(-24+i*8+70,-80);g.moveTo(24+i*8,-150);g.lineTo(24+i*8-70,-80)}g.lineWidth=.9;g.strokeStyle='rgba(120,240,225,.18)';g.stroke();
 g.beginPath();g.moveTo(0,-142);g.lineTo(0,-90);g.lineWidth=1.6;g.strokeStyle='rgba(10,30,40,.4)';g.stroke();g.restore();vest();silasSt(g,3);
 g.beginPath();g.moveTo(-11,-147);g.lineTo(11,-147);g.lineTo(0,-118);g.closePath();silasFS(g,'#fffcf2',2,2.6,'rgba(60,60,100,.12)');
 g.beginPath();g.moveTo(-1,-136);g.lineTo(-1,-122);g.moveTo(-4.5,-141);g.lineTo(-3,-130);g.moveTo(3,-141);g.lineTo(1.6,-130);g.lineWidth=1.2;g.strokeStyle='rgba(60,60,100,.3)';g.stroke();
 /* pocket slits and the watch chain */
 g.beginPath();g.moveTo(5,-112);g.lineTo(14,-113);g.moveTo(-14,-113);g.lineTo(-5,-112);g.lineWidth=1.8;g.strokeStyle='rgba(8,30,36,.65)';g.stroke();
 g.beginPath();g.moveTo(1.5,-101);g.quadraticCurveTo(8,-92,14.5,-112);g.lineWidth=1.7;g.setLineDash([1.8,1.6]);g.strokeStyle='#ffd866';g.stroke();g.setLineDash([]);
 silasEl(g,4.5,-96,2,2,SILAS_GLD,1.2);
 for(const y of [-111,-101,-91]){silasEl(g,0,y,3,3,SILAS_GLD,1.8);g.beginPath();g.arc(0,y,1.4,0,SILAS_TAU);g.lineWidth=.9;g.strokeStyle=SILAS_GLD2;g.stroke();silasEl(g,-.9,y-1,.9,.9,'#fff6c8',0)}
 const cL=()=>{g.beginPath();g.moveTo(-13,-147);g.quadraticCurveTo(-32,-147,-38,-135);g.quadraticCurveTo(-44,-112,-38,-90);g.quadraticCurveTo(-26,-90,-13,-102);g.lineTo(-12,-147);g.closePath()};
 const cR=()=>{g.beginPath();g.moveTo(13,-147);g.quadraticCurveTo(32,-147,38,-135);g.quadraticCurveTo(44,-112,38,-90);g.quadraticCurveTo(26,-90,13,-102);g.lineTo(12,-147);g.closePath()};
 cL();silasFS(g,SILAS_RED,-22,3.2,'rgba(40,0,20,.14)');cR();silasFS(g,SILAS_RED2,99,3.2);
 /* coat-front gold piping and buttons */
 g.beginPath();g.moveTo(-36,-94);g.quadraticCurveTo(-26,-94,-15,-104);g.moveTo(36,-94);g.quadraticCurveTo(26,-94,15,-104);g.lineWidth=1.5;g.strokeStyle=SILAS_GLD2;g.stroke();
 for(const [x,y] of [[-17,-101],[17,-101]])silasEl(g,x,y,2.2,2.2,SILAS_GLD,1.4);
 g.beginPath();g.moveTo(37.5,-133);g.quadraticCurveTo(42.5,-112,37.5,-93);g.lineWidth=2;g.strokeStyle='rgba(160,235,255,.38)';g.stroke();
 const lp=(s)=>{g.beginPath();g.moveTo(s*10,-148);g.lineTo(s*13,-104);g.lineTo(s*19,-122);g.lineTo(s*27,-129);g.lineTo(s*22,-134);g.lineTo(s*25,-141);g.lineTo(s*16,-149);g.closePath()};
 for(const s of [-1,1]){lp(s);g.fillStyle=s<0?SILAS_CRM:'#e0cca4';g.fill();g.save();g.clip();lp(s);g.lineWidth=4.2;g.strokeStyle=SILAS_GLD;g.stroke();g.restore();lp(s);silasSt(g,2.6);
  g.beginPath();silasCurl(g,s*16,-114,s<0?-1.75:-1.39,.95,s<0?1:-1);silasCurl(g,s*15,-134,s<0?-2.5:-.64,.75,s<0?-1:1);g.lineWidth=1.2;g.strokeStyle=SILAS_GLD2;g.stroke()}
 silasHi(g,-19,-140,-15,-128,-14.5,-116,1.8,.6);
 /* gold aiguillette looping from the shoulder to the lapel */
 g.beginPath();g.moveTo(-35,-138);g.quadraticCurveTo(-32,-118,-17,-124);g.moveTo(-35,-138);g.quadraticCurveTo(-36,-108,-15,-116);g.lineWidth=4;g.strokeStyle=SILAS_O;g.stroke();g.lineWidth=2.2;g.strokeStyle=SILAS_GLD;g.stroke();
 silasEl(g,-35,-138,3,3,SILAS_GLD,1.6);
 /* pocket square */
 g.beginPath();g.moveTo(21,-117);g.lineTo(24,-124);g.lineTo(27,-119);g.lineTo(31,-124);g.lineTo(32,-117);g.closePath();silasFS(g,SILAS_CRM,null,1.8);g.beginPath();g.moveTo(19,-116.5);g.lineTo(34,-116.5);silasSt(g,2);
 g.beginPath();g.moveTo(-34,-96);g.lineTo(-18,-98);g.moveTo(18,-98);g.lineTo(34,-96);g.lineWidth=2;g.strokeStyle='rgba(18,8,31,.55)';g.stroke();
 /* bow tie with its gem stud */
 for(const s of [-1,1]){g.beginPath();g.moveTo(0,-143);g.quadraticCurveTo(s*8,-151,s*14,-149);g.quadraticCurveTo(s*16,-143,s*14,-136);g.quadraticCurveTo(s*8,-135,0,-143);g.closePath();silasFS(g,'#1c1428',null,2.6);
  g.beginPath();g.moveTo(s*5,-143);g.lineTo(s*11,-146);g.moveTo(s*5,-142.5);g.lineTo(s*11,-139.5);g.lineWidth=1;g.strokeStyle='rgba(120,90,160,.5)';g.stroke()}
 silasHi(g,-11,-146,-9,-147,-6,-145,1.4,.5);
 silasEl(g,0,-143,4.4,4.4,SILAS_GLD,2.2,1.2,null);silasEl(g,0,-143,2.2,2.2,'#e0303f',0);silasEl(g,-1,-144.2,.9,.9,'#fff8d0',0);
 {const gl=Math.max(0,1-Math.abs(((t*.45)%1)-.5)*10);if(gl>0)silasSpark(g,1.5,-145,7*gl,gl,'255,240,180')}
 g.restore();
 /* head */
 const blink=((t+.4)%3.7)<.13,ex={happy:eC>.25,blink:blink&&!eC,px:look*(1-eT)*(1-eW)+eT*.35,py:eT?-.85:eS?.5:.1-eW*.1,lid:eS*.38+eT*.08,sad:eS,think:eT,glow:eW};
 g.save();g.translate(hx,hy);g.rotate(hr);g.scale(1.15,1.15);
 silasHead(g,t,ex,Math.sin(t*1.8)*1.3+eC*2*Math.sin(k*Math.PI*6));g.restore();
 for(let i=0;i<cards.length;i++){const c=cards[i];if(c[4]&&eT===0&&!eA&&!eC)silasCard(g,i,c[0],c[1],c[2],c[3],glow,t)}
 /* the mask stick sits behind the hand that grips it */
 {const [mx,my,mr,ms,ax,ay,fx]=MK;let dx=HR[0]-ax,dy=HR[1]-ay;const l=Math.hypot(dx,dy)||1;dx/=l;dy/=l;const bx=HR[0]+dx*10,by=HR[1]+dy*10;
  g.beginPath();g.moveTo(ax,ay);g.lineTo(bx,by);g.lineWidth=6.4;g.strokeStyle=SILAS_O;g.stroke();g.lineWidth=3;g.strokeStyle=SILAS_GLD;g.stroke();
  g.beginPath();g.moveTo(ax+dx*4-dy*.8,ay+dy*4+dx*.8);g.lineTo(bx-dx*16-dy*.8,by-dy*16+dx*.8);g.lineWidth=1;g.strokeStyle='rgba(255,250,220,.7)';g.stroke();
  silasEl(g,bx,by,3.2,3.2,SILAS_GLD,1.8);
  /* arms */
  silasArm(g,R,SILAS_RED2,t,1);silasArm(g,L,SILAS_RED,t,-1);
  if(Math.abs(fx)>.04)silasMask(g,mx,my,mr,ms,fx,t,eW*(.6+.4*peak),heat)}
 /* glowing eyes through the mask */
 if(eW>.3){const a=(eW-.3)/.7*(.75+.25*Math.sin(t*9));g.save();g.translate(hx,hy);g.rotate(hr);g.scale(1.15,1.15);g.globalCompositeOperation='lighter';
  for(const [x,y] of [[-8,0],[15,-1]]){const gr=g.createRadialGradient(x,y,1,x,y,16);gr.addColorStop(0,'rgba(120,255,240,'+(a*.8).toFixed(3)+')');gr.addColorStop(1,'rgba(120,255,240,0)');g.fillStyle=gr;g.fillRect(x-16,y-16,32,32)}
  g.restore()}
 drawW(1);motes();vortex(true);
 for(let i=0;i<cards.length;i++){const c=cards[i];if(c[4]&&(eT||eA||eC))silasCard(g,i,c[0],c[1],c[2],c[3],glow,t)}
 fountain();
 /* the burst at the height of the ability */
 if(peak>0){g.save();g.globalCompositeOperation='lighter';const cx=0,cy=-150,R2=40+110*(1-peak)*(k>.5?1:.4)+60*peak,rot=k*2;
  const rg=g.createRadialGradient(cx,cy,4,cx,cy,R2);rg.addColorStop(0,'rgba(255,245,200,'+(peak*.55).toFixed(3)+')');rg.addColorStop(.4,'rgba(120,240,230,'+(peak*.25).toFixed(3)+')');rg.addColorStop(1,'rgba(120,240,230,0)');
  g.fillStyle=rg;g.beginPath();for(let i=0;i<12;i++){const a=rot+i*SILAS_TAU/12,l=R2*(i&1?.7:1),w=.07;g.moveTo(cx,cy);g.lineTo(cx+Math.cos(a-w)*l,cy+Math.sin(a-w)*l);g.lineTo(cx+Math.cos(a+w)*l,cy+Math.sin(a+w)*l);g.closePath()}g.fill();
  const ring=Math.max(0,(k-.42)/.24);if(ring>0&&ring<1){g.beginPath();g.arc(cx,cy,30+80*ring,0,SILAS_TAU);g.lineWidth=5*(1-ring);g.strokeStyle='rgba(200,255,250,'+((1-ring)*.7).toFixed(3)+')';g.stroke()}
  g.restore();silasSpark(g,0,-268,28*peak,peak,'90,240,225');silasSpark(g,0,-268,16*peak,peak,'255,215,110');for(const c of cards)silasSpark(g,c[0]+9,c[1]-13,9*peak,peak,'255,230,150')}
 if(mode==='cheer'){const p=Math.max(0,1-Math.abs(k-.5)/.25);if(p>0){for(const c of cards)silasSpark(g,c[0],c[1]-22,10*p,p,'255,225,140');silasSpark(g,MK[0],MK[1]-14,12*p,p,'255,210,120')}}
 if(heat>.5){const p=(heat-.5)*2;for(let i=0;i<cards.length;i++){const c=cards[i],tw=Math.max(0,Math.sin(t*3+i*2.1));if(tw>.05)silasSpark(g,c[0]+11,c[1]-15,7*p*tw,p*tw,i===1?'90,240,225':'255,220,120')}}
 g.restore()}
/* ---- round gold-ringed portrait on a deep purple disc ---- */
function silasPortrait(cv,t){const g=cv.getContext('2d'),w=cv.width,h=cv.height;t=t==null?1.2:t;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,w,h);
 const m=Math.min(w,h),R=m/2-Math.max(2,m*.035),cx=w/2,cy=h/2;
 g.save();g.beginPath();g.arc(cx,cy,R,0,SILAS_TAU);const bg=g.createRadialGradient(cx,cy-R*.2,R*.1,cx,cy,R);bg.addColorStop(0,'#46206c');bg.addColorStop(1,'#1c0b34');g.fillStyle=bg;g.fill();g.clip();
 const s=R/68;g.save();g.translate(cx,cy+R*.15);g.scale(s,s);g.rotate(-t*.12);silasCircle(g,0,0,62,1,.4,0,'255,205,110',1);g.restore();
 g.translate(cx-6*s,cy+182*s+R*.1);g.scale(s,s);silasDraw(g,t,{mode:'idle',k:0,heat:.35,look:0,_pt:1});g.restore();
 g.save();g.beginPath();g.arc(cx,cy,R,0,SILAS_TAU);g.lineWidth=Math.max(3,m*.07);g.strokeStyle=SILAS_O;g.stroke();
 const rg=g.createLinearGradient(cx-R,cy-R,cx+R,cy+R);rg.addColorStop(0,'#ffe08a');rg.addColorStop(.5,'#e0a630');rg.addColorStop(1,'#9a6a14');g.lineWidth=Math.max(1.6,m*.038);g.strokeStyle=rg;g.stroke();
 g.beginPath();g.arc(cx,cy,R,Math.PI*1.1,Math.PI*1.45);g.lineWidth=Math.max(.8,m*.012);g.strokeStyle='rgba(255,250,220,.8)';g.stroke();g.restore()}
