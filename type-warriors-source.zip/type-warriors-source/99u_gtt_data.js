/* ===== 99u: The Great Turkey Trot (10.5), data. Pure data and repairs, no DOM; also loads in plain node (tools/gtt/rtp.js).
   GTT constants, the 12 runners, going and weather, commentary templates, the save normaliser gttNorm() and the race card gttCard(seed). ===== */
const GTT={rtp:.95,coRtp:.93,cap:20000,maxBet:5000,maxTotal:5000,minBet:10,maxBets:3,len:1000,hz:30,runners:6,acorn:{win:5,perDay:10},
 minMult:1.10,maxWin:40,maxExact:150,minP:.006,maxOfferedP:.9,photoGap:.06,coLast:.9,coRuns:300,priceRuns:4000,minRet:.88};
/* stats: spd = speed multiplier near 1; sta 0..1 (fades late when low); kick 0..1 (late burst); gate 0..1 (quick away);
   focus 0..1 (resists pies); mud -1..1 (-1 loves firm, +1 loves mud); wild 0..1 (variance); gust = how much a gust slows it (1 = average); wx = small hidden speed bonus or penalty per weather (the form guide shows it, the card does not). */
const GTT_RUN=[
 {id:'gravy',n:'Gravy Train',style:'front',spd:1.0250,sta:.34,kick:.12,gate:.86,focus:.60,mud:0,wild:.45,gust:1,wx:{clear:.006,wind:-.002,drizzle:-.004},col:['#b5651d','#f2c14e'],silk:['#d62839','#f7ede2'],jockey:{n:'Pip',kind:'goblin'},tip:'Fast away, can tire'},
 {id:'comet',n:'Cranberry Comet',style:'close',spd:1.0027,sta:.74,kick:.92,gate:.28,focus:.60,mud:.2,wild:.50,gust:1,wx:{drizzle:.003},col:['#8c2f39','#ff6b6b'],silk:['#9d0208','#ffd6a5'],jockey:{n:'Zip',kind:'imp'},tip:'Saves a big late kick'},
 {id:'gobbles',n:'Sir Gobblesworth',style:'stalk',spd:1.0120,sta:.66,kick:.40,gate:.55,focus:.88,mud:0,wild:.14,gust:1,wx:{wind:.002},col:['#5c4033','#9aa5b1'],silk:['#3a5a8a','#e8c547'],jockey:{n:'Sir Ned',kind:'skel'},tip:'Steady, rarely makes mistakes'},
 {id:'spice',n:'Pumpkin Spice',style:'front',spd:1.0128,sta:.50,kick:.20,gate:.70,focus:.12,mud:0,wild:.50,gust:1,wx:{clear:.008,wind:-.003,drizzle:-.003},col:['#d2691e','#f4a259'],silk:['#f77f00','#3d2b1f'],jockey:{n:'Gourdo',kind:'slime'},tip:'Easily distracted by pies'},
 {id:'willie',n:'Wishbone Willie',style:'close',spd:0.9976,sta:.70,kick:.76,gate:.35,focus:.55,mud:1,wild:.40,gust:1,wx:{drizzle:.004},col:['#6b4f3a','#c9b79c'],silk:['#2d6a4f','#d8f3dc'],jockey:{n:'Mossy',kind:'moss'},tip:'Loves a muddy track'},
 {id:'butter',n:'Butterball Bolt',style:'stalk',spd:1.0163,sta:.60,kick:.34,gate:.48,focus:.60,mud:.8,wild:.24,gust:.4,wx:{wind:.003},col:['#e9c46a','#f4e3b2'],silk:['#264653','#e9c46a'],jockey:{n:'Boulder',kind:'golem'},tip:'Strong but heavy on a firm track'},
 {id:'maple',n:'Maple Mayhem',style:'front',spd:1.0148,sta:.44,kick:.24,gate:.76,focus:.40,mud:0,wild:1,gust:1,wx:{wind:.008,clear:-.002},col:['#a4161a','#e5383b'],silk:['#ba181b','#fcbf49'],jockey:{n:'Spark',kind:'bat'},tip:'Wild: big bursts, big stumbles'},
 {id:'drum',n:'Drumstick Dash',style:'stalk',spd:1.0028,sta:.56,kick:.30,gate:.98,focus:.65,mud:-.1,wild:.30,gust:1,wx:{clear:.003,wind:.005,drizzle:-.004},col:['#7f5539','#ddb892'],silk:['#00b4d8','#caf0f8'],jockey:{n:'Tick',kind:'wisp'},tip:'Quick in the gate'},
 {id:'annie',n:'Acorn Annie',style:'close',spd:0.9975,sta:.80,kick:.70,gate:.55,focus:.70,mud:.1,wild:.60,gust:2.5,wx:{clear:.004},col:['#9c6644','#e6ccb2'],silk:['#7b2cbf','#e0aaff'],jockey:{n:'Nutmeg',kind:'frost'},tip:'Small and nimble, hates gusts'},
 {id:'stuff',n:'Stuffing Stampede',style:'front',spd:0.9984,sta:.96,kick:.10,gate:.60,focus:.60,mud:0,wild:.30,gust:1,wx:{drizzle:.007,wind:.004,clear:-.003},col:['#bc8a5f','#8b5e34'],silk:['#588157','#dad7cd'],jockey:{n:'Crumb',kind:'ghost'},tip:'Keeps going when others fade'},
 {id:'hank',n:'Hayride Hank',style:'stalk',spd:1.0056,sta:.70,kick:.35,gate:.45,focus:.90,mud:-1,wild:.20,gust:1,wx:{clear:.003,drizzle:-.005},col:['#6c584c','#adc178'],silk:['#bc6c25','#fefae0'],jockey:{n:'Old Jeb',kind:'zombie'},tip:'Old pro, loves a firm track'},
 {id:'duchess',n:'Duchess Thunderplume',style:'close',spd:1.0042,sta:.86,kick:1,gate:.10,focus:.50,mud:0,wild:.35,gust:1,wx:{drizzle:.003,wind:.002,clear:-.002},col:['#3c1f6b','#d4af37'],silk:['#5a189a','#ffd60a'],jockey:{n:'Regina',kind:'witch'},tip:'Slow to start, huge finish'}];
const GTT_IDX={};GTT_RUN.forEach((r,i)=>{GTT_IDX[r.id]=i});
const GTT_GOING={firm:{n:'Firm',desc:'Hard, fast ground'},good:{n:'Good',desc:'Ideal ground'},muddy:{n:'Muddy',desc:'Heavy, sticky ground'}};
const GTT_WEATHER={clear:{n:'Clear',desc:'Sunny harvest evening'},wind:{n:'Windy',desc:'Gusts across the track'},drizzle:{n:'Drizzle',desc:'Soft rain, softer ground'}};
/* Commentary templates per event kind. {n} = the turkey, {m} = another turkey (the one passed / beaten), {j} = the jockey. gttSayFmt(tpl,vars) fills them. */
const GTT_SAY={
 gate:['And they are off!','The gate snaps open!','Away they go at the Great Turkey Trot!'],
 lead:['{n} takes the lead!','{n} goes to the front!','{n} is bossing the field now!','{j} sends {n} into the lead!'],
 pass:['{n} sweeps past {m}!','{n} edges ahead of {m}!','{n} overtakes {m}!'],
 kick:['Here comes {n} on the outside!','{n} is finding a big late kick!','{j} asks {n} for everything!','{n} is flying home!'],
 stumble:['{n} trips over a hay bale!','Oh no, {n} stumbles on the hay!','{n} loses ground over the hay bale!'],
 burst:['{n} snaps up a corn kernel and bursts away!','Corn power for {n}!','{n} finds a sudden burst of speed!'],
 pie:['{n} stops to stare at a pie!','{j} cannot stop {n} gawping at a pie!','{n} is distracted by a pie on the fence!'],
 gust:['A gust sweeps across the track!','Leaves everywhere as a gust hits the field!','A big gust slows the whole field!'],
 gustAnnie:['The gust is hurting little {n}!'],
 mid:['Halfway, and {n} leads from {m}.','At the halfway mark it is {n} from {m}.'],
 close:['{n} and {m} are neck and neck!','{n} and {m} are locked together!'],
 final:['Into the final stretch! {n} leads!','Down the final straight it is {n}!','Only a furlong to go and {n} is in front!'],
 photo:['Too close to call! A photo finish!','They hit the line together! The judges need the photo!'],
 win:['{n} wins the Great Turkey Trot!','{n} takes it! What a turkey!','Victory for {n} and {j}!'],
 last:['{n} brings up the rear.','{n} is trailing the field.']};
function gttSayFmt(t,v){v=v||{};return String(t).replace(/\{(\w)\}/g,(_,k)=>v[k]==null?'':v[k])}
function gttHash(s){s=(s^0x9E3779B9)|0;s=Math.imul(s^(s>>>16),0x85ebca6b);s=Math.imul(s^(s>>>13),0xc2b2ae35);return(s^(s>>>16))>>>0}
function gttCard(seed){
 seed=(seed|0);let s=gttHash(seed^0x7a11)|0;const rnd=()=>{s=(s+0x6D2B79F5)|0;let t=Math.imul(s^(s>>>15),1|s);t=(t+Math.imul(t^(t>>>7),61|t))^t;return((t^(t>>>14))>>>0)/4294967296};
 const ids=GTT_RUN.map(r=>r.id);for(let i=ids.length-1;i>0;i--){const j=Math.floor(rnd()*(i+1));const q=ids[i];ids[i]=ids[j];ids[j]=q}
 const u=rnd(),w=u<.55?'clear':u<.75?'wind':'drizzle',g=rnd();
 const going=w==='drizzle'?(g<.5?'muddy':g<.9?'good':'firm'):(g<.17?'muddy':g<.67?'good':'firm');
 return{seed,no:(gttHash(seed)%99)+1,field:ids.slice(0,GTT.runners),going,weather:w}}
/* ---- save normaliser: repairs P.gtt (or the object given) in place of a broken save; a malformed pend is dropped ---- */
function gttInt(v,lo,hi,d){v=Math.floor(Number(v));return Number.isFinite(v)?Math.min(hi,Math.max(lo,v)):d}
function gttBetOk(b){
 if(!b||typeof b!=='object')return null;const k=b.k;if(k!=='win'&&k!=='top2'&&k!=='top3'&&k!=='exact')return null;
 const a=Number(b.a),st=Number(b.stake),m=Number(b.mult);if(!Number.isInteger(a)||a<0||a>=GTT.runners)return null;
 if(!Number.isFinite(st)||st<GTT.minBet||st>GTT.maxBet)return null;if(!Number.isFinite(m)||m<GTT.minMult||m>GTT.maxExact)return null;
 const o={k,a,stake:Math.floor(st),mult:Math.round(m*100)/100};
 if(k==='exact'){const c=Number(b.b);if(!Number.isInteger(c)||c<0||c>=GTT.runners||c===a)return null;o.b=c}return o}
function gttNorm(g){
 const useP=g===undefined&&typeof P!=='undefined'&&P&&typeof P==='object';if(useP)g=P.gtt;
 if(!g||typeof g!=='object'||Array.isArray(g))g={};
 const o={v:1,races:gttInt(g.races,0,1e9,0),bets:gttInt(g.bets,0,1e9,0),wins:gttInt(g.wins,0,1e9,0),best:gttInt(g.best,0,1e9,0),long:gttInt(g.long,0,1e9,0),fav:{},rec:{},seen:g.seen?1:0,pend:null,acorn:{day:'',n:0}};
 const fv=g.fav&&typeof g.fav==='object'&&!Array.isArray(g.fav)?g.fav:{},rc=g.rec&&typeof g.rec==='object'&&!Array.isArray(g.rec)?g.rec:{};
 for(const r of GTT_RUN){
  o.fav[r.id]=gttInt(fv[r.id],0,1e9,0);const q=rc[r.id]&&typeof rc[r.id]==='object'?rc[r.id]:{};
  const last=Array.isArray(q.last)?q.last.map(x=>Math.floor(Number(x))).filter(x=>x>=1&&x<=GTT.runners).slice(-5):[];
  o.rec[r.id]={s:gttInt(q.s,0,1e9,0),w:gttInt(q.w,0,1e9,0),p:gttInt(q.p,0,1e9,0),last}}
 if(g.acorn&&typeof g.acorn==='object')o.acorn={day:typeof g.acorn.day==='string'?g.acorn.day.slice(0,12):'',n:gttInt(g.acorn.n,0,1e6,0)};
 const p=g.pend;
 if(p&&typeof p==='object'&&!Array.isArray(p)&&Number.isFinite(Number(p.cardSeed))&&Number.isFinite(Number(p.raceSeed))&&Array.isArray(p.bets)){
  const bets=p.bets.map(gttBetOk);
  if(bets.length>=1&&bets.length<=GTT.maxBets&&bets.every(Boolean)&&bets.reduce((s,b)=>s+b.stake,0)<=GTT.maxTotal){
   const cash=[];if(Array.isArray(p.cash))for(const c of p.cash){if(c&&Number.isInteger(c.i)&&c.i>=0&&c.i<bets.length&&!cash.some(z=>z.i===c.i)){const pay=Number(c.pay);if(Number.isFinite(pay)&&pay>=0&&pay<=GTT.cap)cash.push({i:c.i,pay:Math.floor(pay)})}}
   o.pend={cardSeed:Math.floor(Number(p.cardSeed))|0,raceSeed:Math.floor(Number(p.raceSeed))|0,bets,cash,t0:Number.isFinite(Number(p.t0))?Number(p.t0):0}}}
 if(useP)P.gtt=o;return o}
