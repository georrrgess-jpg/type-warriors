/* ===== RUNESTONE TOWER DEFENSE 10.0: integration fixes (98n, after 98m) =====
   - The tower bar fits twelve cards once the Clockwork Hive (World 2) and the Singularity Engine (World 3) are unlocked: 95m/97e
     size the bar for up to ten (.rp10), 98i/98k add .rp11; this adds .rp12 (cards 68 px, smaller icons and names) in the same
     871 px between the abilities and Next wave. Locked towers stay hidden (98b's rpwTwOnly), so the bar shows 10, 11 or 12. */
{const st=document.createElement('style');const P='.rph.rp7.rp8.rp9.rp10.rp11.rp12';
 st.textContent=`${P} .rpbar{gap:2px;padding-left:8px;padding-right:8px}${P} .rpcard{width:68px}${P} .rpct>b{max-width:66px;font-size:10px;letter-spacing:-.1px}
${P} .rpcard img{width:56px;height:56px;margin-left:-28px;top:-15px}${P} .rpcard .rpcc{font-size:11px}`;document.head.appendChild(st)}
{const h0=rpHudOn;rpHudOn=function(){const r=h0.apply(this,arguments);try{const h=$('rphud');if(h){const n=h.querySelectorAll('.rpcard').length;h.classList.toggle('rp11',n>=11);h.classList.toggle('rp12',n>=12)}}catch(e){}return r}}
/* - Clockwork Hive (98i) hooks: its bees skip monsters the core hides this frame (glimmer, dive, leap, shell-free: e.hide), and its reach
     gets the Glowcap bonus like every other tower (tw.glowK, 98b). */
function rpwCanHit(e){return !!e&&!e.dead&&!e.hide}
{const r0=rphvRange;rphvRange=function(R,tw){const r=r0.apply(this,arguments);return tw&&tw.glowK>1&&!tw.rangeK?r*tw.glowK:r}}
