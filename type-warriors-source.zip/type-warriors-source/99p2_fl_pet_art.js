/* ===== 10.4 HARVEST FESTIVAL: harvest companion art (99p2, after 99p; prefix flp) =====
   Painted canvas rigs in the companion style (87b / 87i): feet at the origin, facing right, about 100 units of body, chunky #1b1024
   outlines, soft gradient fills with a darker shade side and a light rim, big friendly eyes. Every pose the system uses is drawn:
   idle (with its own little habits), walk, greet (the cheer) and ability (scrubbed by u), plus the Bond 3 accessory, the Bond 5
   palette, the Bond 7 victory greeting and the Bond 10 Signature form with its own drifting motes.
   - Acorn Scamp (flsquir, Rare): a red squirrel in an acorn-cap helmet, a satchel of acorns and a big curling tail. Nibbles its acorn,
     flicks its tail; its power winds up and throws the acorn, then fishes a new one out of the satchel.
   - Emberleaf (flfox, Legendary): a fox whose tail is a plume of glowing maple leaves. The leaves flutter and now and then one drifts
     off as an ember; its power whips the tail forward and a gale of burning leaves blows out.
   Thunderplume the Harvest Turkey (Mythic) is drawn in 99p3. */

/* ---------- shared harvest shapes ---------- */
/* a maple leaf, stem at (x,y), pointing along angle a (0 = up); s = height */
const FLP_MAPLE=(()=>{const R=[[0,-1],[.1,-.8],[.21,-.86],[.15,-.6],[.38,-.72],[.37,-.6],[.64,-.62],[.52,-.46],[.6,-.4],[.38,-.3],[.5,-.14],[.27,-.17],[.22,-.08],[.07,-.12],[.05,0]];return[...R,...R.slice(1,-1).reverse().map(p=>[-p[0],p[1]]),[-.05,0]]})();
function flpMaple(g,x,y,s,a,c1,c2,lw,vein,nost){g.save();g.translate(x,y);g.rotate(a||0);g.scale(s,s);
 if(!nost&&lw!==0){g.beginPath();g.moveTo(0,-.04);g.lineTo(0,.3);g.strokeStyle=PTO;g.lineWidth=(lw||2)/s*1.9;g.stroke();g.strokeStyle=c2;g.lineWidth=(lw||2)/s*.9;g.stroke()}
 g.beginPath();FLP_MAPLE.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.closePath();const q=g.createLinearGradient(0,-1,0,0);q.addColorStop(0,c1);q.addColorStop(1,c2);g.fillStyle=q;g.fill();
 if(lw!==0){g.lineWidth=(lw||2)/s;g.strokeStyle=PTO;g.stroke()}
 if(vein!==0){g.beginPath();for(const [vx,vy] of[[0,-.86],[.5,-.56],[-.5,-.56],[.4,-.2],[-.4,-.2]]){g.moveTo(0,-.04);g.lineTo(vx,vy)}g.strokeStyle=vein||'#ffffff88';g.lineWidth=.9/s;g.stroke()}
 g.restore()}
/* cached leaf sprites for anything drawn many times a frame (falling leaves, bursts, battle effects): i picks the colour pair */
const FLP_LC=[['#ffe27a','#e8541a'],['#ff9a2a','#c8281a'],['#ff6a2a','#9a1a1a'],['#e8401a','#7a1414'],['#f2ecff','#7a5ae0']],FLP_LSPR={};
function flpLeafSpr(i){i=i%FLP_LC.length;if(FLP_LSPR[i])return FLP_LSPR[i];const c=document.createElement('canvas');c.width=c.height=72;const x=c.getContext('2d');x.lineJoin='round';x.lineCap='round';flpMaple(x,36,46,38,0,FLP_LC[i][0],FLP_LC[i][1],2.8,'#fff2c055',1);return FLP_LSPR[i]=c}
function flpLeafD(g,x,y,s,a,i){const c=flpLeafSpr(i|0),k=s/38;g.save();g.translate(x,y);g.rotate(a||0);g.scale(k,k);g.drawImage(c,-36,-46);g.restore()}
/* an acorn: the nut hangs below (x,y), the cap sits on top; s = about the nut's height */
function flpAcorn(g,x,y,s,a,C,lw){C=C||FLP_AC;g.save();g.translate(x,y);g.rotate(a||0);g.scale(s/20,s/20);const L=(lw||2)*20/s;
 g.beginPath();g.moveTo(-8.4,-1);g.bezierCurveTo(-9,8,-4,15,0,18);g.bezierCurveTo(4,15,9,8,8.4,-1);g.closePath();pF(g,pLin(g,-8,0,8,16,[C.a2,C.a,C.ad]),L);
 g.beginPath();g.ellipse(-3.2,6,1.8,4.6,-.2,0,TAU);g.fillStyle='#ffffff55';g.fill();pC(g,0,17.2,1.2);g.fillStyle=C.ad;g.fill();
 g.beginPath();g.moveTo(-10.4,0);g.bezierCurveTo(-11,-9,11,-9,10.4,0);g.quadraticCurveTo(0,3.4,-10.4,0);g.closePath();pF(g,pLin(g,0,-8,0,2,[C.c2,C.c,C.cd]),L);
 g.save();g.clip();g.strokeStyle=C.cd;g.lineWidth=.9;for(let i=-12;i<=12;i+=3.4){g.beginPath();g.moveTo(i,-9);g.lineTo(i+6,3);g.moveTo(i,-9);g.lineTo(i-6,3);g.stroke()}g.restore();
 g.beginPath();g.moveTo(.6,-6.4);g.quadraticCurveTo(1.6,-10,4,-11);g.strokeStyle=PTO;g.lineWidth=L*1.3;g.stroke();g.strokeStyle=C.st;g.lineWidth=L*.6;g.stroke();g.restore()}
const FLP_AC={a:'#cf8a3e',a2:'#f2b866',ad:'#8a521e',c:'#8a5428',c2:'#b47a40',cd:'#5a3216',st:'#6a4220'};
const FLP_ACG={a:'#ffd45a',a2:'#fff2b0',ad:'#b8801a',c:'#c8901a',c2:'#ffe48a',cd:'#8a5a10',st:'#8a5a10'};
/* union-outline blobs: stroke a fat outline under, fill on top (one clean outline around overlapping circles) */
function flpBlobs(g,B,fill,lw){g.beginPath();for(const [x,y,r] of B){g.moveTo(x+r,y);g.arc(x,y,Math.max(.1,r),0,TAU)}g.strokeStyle=PTO;g.lineWidth=(lw||2.4)*2;g.stroke();g.fillStyle=fill;g.fill()}

/* ---------- palettes: [default, Bond 5 alternate]; the first three values are the Atelier swatches ---------- */
Object.assign(PCOL,{
 flsquir:[{f:'#e0662c',tl:'#d4582a',be:'#fff0d8',f2:'#f6904a',fd:'#a8401c',bed:'#ecc9a0',tl2:'#ff9e52',tlt:'#ffdcae',cap:'#8a5428',cap2:'#b47a40',capd:'#5a3216',ie:'#ff9c8a',ey:'#ffae3a',no:'#5a2a2a',bag:'#7a4a24',bagd:'#4e2c12',bagl:'#a8703a',sc:'#d8323a',sc2:'#ff6a5a',scd:'#8a1424'},
          {f:'#97a0b4',tl:'#8a93aa',be:'#f6f8fc',f2:'#c4cad8',fd:'#646a82',bed:'#d4dae6',tl2:'#c8cedc',tlt:'#ffffff',cap:'#8a6a48',cap2:'#b49470',capd:'#54402a',ie:'#ffb4c4',ey:'#5ad0ff',no:'#3a3a52',bag:'#5a6278',bagd:'#363c4e',bagl:'#8a92a8',sc:'#3a8ad8',sc2:'#7ac8ff',scd:'#1a4a8a'}],
 flfox:[{f:'#e8642a',lf2:'#ff9a2a',ch:'#fff3e0',f2:'#ff8e4a',fd:'#b0401a',chd:'#e6caa4',sk:'#3a2224',skd:'#24141a',ie:'#ffb0a0',ey:'#ffc23a',no:'#2a1418',lf1:'#ffe27a',lf3:'#e8401a',lf4:'#9a1a2a',gl:'#ffb03a',vn:'#fff2c0'},
        {f:'#c4cadc',lf2:'#b8a0ff',ch:'#ffffff',f2:'#eef0f8',fd:'#868ca6',chd:'#d4d8e8',sk:'#34344e',skd:'#1e1e32',ie:'#d8c0ff',ey:'#7affe8',no:'#1e1e32',lf1:'#f2ecff',lf3:'#7a5ae0',lf4:'#3a2a8a',gl:'#b8a0ff',vn:'#ffffff'}]});

/* ======================================================================
   ACORN SCAMP: a red squirrel in an acorn-cap helmet
   ====================================================================== */
PRIG.flsquir=(g,o,C)=>{const t=o.t,P=o.pose,u=o.u,walk=P==='walk',ab=P==='ability',gr=P==='greet',trim=o.trim;
 const AC=trim?FLP_ACG:FLP_AC;
 /* ----- motion ----- */
 let by=0,lean=0,sx=1,sy=1,armA=.9,nib=0,happy=false,eyeO=pBlink(t,6),tailK=0,earT=0,hold=1,newA=1,cheek=0;
 const br=Math.sin(t*2.3)*.015;sy+=br;sx-=br*.6;
 if(walk){const c=(t*1.5)%1,h=Math.sin(c*Math.PI);by=-h*13;lean=.16-h*.1;tailK=Math.cos(c*TAU)*.3;sy+=c<.08||c>.92?-.06:0;armA=.75}
 else if(P==='idle'){const ph=(t%7.4+7.4)%7.4;
  /* a nibble on the acorn now and then */if(ph<1.4){const k=ph/1.4;nib=Math.sin(Math.min(1,k*1.25)*Math.PI);cheek=nib*(.5+.5*Math.sin(t*28));eyeO=nib>.5?.4:eyeO}
  if(ph>3.6&&ph<4)earT=Math.sin((ph-3.6)/.4*Math.PI);if(ph>5.2&&ph<5.8)tailK=Math.sin((ph-5.2)/.6*TAU)*.4}
 if(gr){const hp=Math.sin(Math.min(1,u/.32)*Math.PI);by=-hp*16;happy=u>.1&&u<.9;const up=pSeg(u,.08,.3)*(1-pSeg(u,.82,.98));armA=.9-up*2.25+Math.sin(u*32)*.18*up;tailK=Math.sin(u*14)*.25;if(u<.04||(u>.3&&u<.36)){sy*=.92;sx*=1.06}}
 if(ab){/* an underhand lob: swing back, toss up and forward, then fish a new acorn from the satchel */const wind=pSeg(u,0,.28),thr=pSeg(u,.3,.4),fol=pSeg(u,.45,.75);
  armA=.9+wind*1.35-thr*2.85+fol*1.5;lean=-wind*.14+thr*.24-fol*.24;tailK=-wind*.35+thr*.55-fol*.2;hold=u<.4?1:0;newA=pSeg(u,.72,.9);sy*=1-wind*.05+thr*.04;happy=u>.42&&u<.7}
 g.save();g.translate(0,by);g.translate(-2,0);g.rotate(lean);g.translate(2,0);g.scale(sx,sy);
 /* ----- the tail: an S-shaped plume that rises behind the back and flips out at the top, made of overlapping fur blobs ----- */
 g.save();g.translate(-8,-14);g.rotate(Math.sin(t*1.6)*.04+tailK*.4);g.scale(.86,.86);
 const sw=Math.sin(t*1.9)*3+tailK*12,S1=[0,0,-30,2,-42,-26,-32,-52],S2=[-32,-52,-24,-72,-26+sw*.5,-92,-46+sw,-98],TB=[];
 const cb=(Q,k,i)=>{const m=1-k;return m*m*m*Q[i]+3*m*m*k*Q[i+2]+3*m*k*k*Q[i+4]+k*k*k*Q[i+6]};
 for(let i=0;i<=16;i++){const s=i/16,Q=s<.5?S1:S2,k=s<.5?s*2:(s-.5)*2,r=(5.5+10*Math.sin(Math.PI*Math.min(1,s*.95+.05))+(s>.55?4*Math.sin((s-.55)/.45*Math.PI):0))*(trim?1.06:1);TB.push([cb(Q,k,0),cb(Q,k,1),r])}
 flpBlobs(g,TB,pLin(g,-50,-100,0,0,[C.tl2,C.tl,C.fd]),2.4);
 /* fur streaks and a pale tip */g.strokeStyle=ptHexA(C.tlt,.55);g.lineWidth=1.5;for(let i=3;i<15;i+=3){const [x,y,r]=TB[i];g.beginPath();g.arc(x+r*.2,y+r*.15,r*.6,-2.8,-1.5);g.stroke()}
 {const [x,y,r]=TB[16],[x2,y2,r2]=TB[15];g.save();g.beginPath();for(const [a,b,rr] of TB){g.moveTo(a+rr,b);g.arc(a,b,rr,0,TAU)}g.clip();g.beginPath();g.arc(x,y,r*1.1,0,TAU);g.arc(x2,y2,r2*.7,0,TAU);g.fillStyle=ptHexA(C.tlt,.85);g.fill();g.restore()}
 if(trim){/* Golden Oak: glints of gold run along the tail */const gp=(t*.5)%1.4;if(gp<1){const [x,y,r]=TB[Math.floor(gp*16)];pGlow(g,x,y,r*1.6,'#ffd45a',.5*Math.sin(gp*Math.PI));pStar4(g,x,y-r*.4,5*Math.sin(gp*Math.PI),'#fff6c0')}
  for(const i of[5,9,13]){const [x,y,r]=TB[i];pLeaf(g,x-r*.7,y-r*.3,12,4.4,-2.4+i*.1+Math.sin(t*2+i)*.1,'#ffd45a','#b8801a',1.4)}}
 g.restore();
 /* ----- hind foot, body, haunch ----- */
 pE(g,9,-3.5,14,5.2,.04);pF(g,pLin(g,0,-8,0,2,[C.f,C.fd]),2.4);for(const x of[16,20])pE(g,x,-1.4,2.2,1.4),g.fillStyle=C.fd,g.fill();
 const body=(ox,oy)=>{g.ellipse(3+ox,-35+oy,18.5,26,-.1,0,TAU)};g.beginPath();body(0,0);pF(g,pRad(g,-3,-45,30,[C.f2,C.f,C.fd]),2.6);pmShade(g,body,-5,-4,ptHexA(C.fd,.3));
 g.beginPath();g.ellipse(11,-31,10,18.5,-.1,0,TAU);g.fillStyle=pLin(g,0,-48,0,-12,[C.be,C.bed]);g.fill();
 pE(g,-5,-17,15.5,13);pF(g,pRad(g,-8,-22,16,[C.f2,C.f,C.fd]),2.4);g.beginPath();g.arc(-5,-17,10,-2.4,-1.2);g.strokeStyle=ptHexA('#ffffff',.35);g.lineWidth=1.8;g.stroke();
 /* the satchel on its hip, strap over the shoulder, acorns peeking out */
 g.beginPath();g.moveTo(15,-55);g.quadraticCurveTo(2,-38,-9,-27);g.strokeStyle=PTO;g.lineWidth=4.6;g.stroke();g.strokeStyle=C.bagl;g.lineWidth=2.4;g.stroke();
 flpAcorn(g,-17,-31,8,-.4,AC,1.3);flpAcorn(g,-11,-33,7,.25,AC,1.3);
 g.beginPath();g.roundRect(-22,-29,18,14,5);pF(g,pLin(g,0,-29,0,-15,[C.bagl,C.bag,C.bagd]),2.2);g.beginPath();g.moveTo(-22,-25);g.quadraticCurveTo(-13,-19,-4,-25);g.lineTo(-4,-28);g.quadraticCurveTo(-13,-31,-22,-28);g.closePath();pF(g,C.bag,1.6);pC(g,-13,-21.6,1.8);pF(g,trim?'#ffd45a':'#e8c46a',1.1);
 /* ----- arms: the far one behind, the near one holds the acorn (in front of the head when raised) ----- */
 const sh=[11,-50],aL=14;let hx=sh[0]+Math.cos(armA)*aL,hy=sh[1]+Math.sin(armA)*aL;if(nib>0){hx+=(25-hx)*nib*.72;hy+=(-60-hy)*nib*.72}
 pLimb(g,5,-48,15,-40,4,3.6,C.fd);pE(g,16,-40,3.6,3.2);pF(g,C.fd,1.8);
 const arm=()=>{const acS=ab&&!hold?newA:1;if(acS>.02)flpAcorn(g,hx+1.5,hy-8*acS,14*acS,.15+(ab?(armA-.9)*.25:0),AC,1.8);pLimb(g,sh[0],sh[1],hx,hy,4.6,4,C.f);pE(g,hx,hy,4.4,3.8);pF(g,C.f2,2);if(trim)pGlow(g,hx+2,hy-3,16,'#ffd45a',.3+.15*Math.sin(t*3))};
 const raised=armA<-.25;if(!raised)arm();
 /* ----- head ----- */
 const tl=gr?Math.sin(u*Math.PI)*-.12:ab?pSeg(u,0,.28)*.06-pSeg(u,.3,.4)*.12*(1-pSeg(u,.6,.8)):Math.sin(t*.9)*.03;
 g.save();g.translate(10,-60);g.rotate(tl);g.scale(1.1,1.1);g.translate(-10,60);
 /* ears poking out from under the cap, with tufts */const ear=(x,y,a,far)=>{g.save();g.translate(x,y);g.rotate(a);g.beginPath();g.moveTo(-6,2);g.quadraticCurveTo(-5,-12,1,-18);g.quadraticCurveTo(6,-10,6,2);g.closePath();pF(g,far?C.fd:C.f,2.2);
  if(!far){g.beginPath();g.moveTo(-3,0);g.quadraticCurveTo(-2,-9,1,-13);g.quadraticCurveTo(3.4,-7,3.4,0);g.closePath();g.fillStyle=C.ie;g.fill()}
  g.beginPath();g.moveTo(-1,-15);g.lineTo(0,-24);g.lineTo(2,-16);g.moveTo(1,-16);g.lineTo(4,-23);g.lineTo(3.4,-15);g.fillStyle=far?C.fd:C.tl;g.fill();g.restore()};
 ear(1,-87,-.55-earT*.2,1);ear(19,-90,.25+earT*.35,0);
 const head=(ox,oy)=>{g.ellipse(13+ox,-72+oy,19.5,17.5,0,0,TAU)};g.beginPath();head(0,0);pF(g,pRad(g,6,-80,23,[C.f2,C.f,C.fd]),2.6);pmShade(g,head,-4,-4,ptHexA(C.fd,.28));
 /* cheek and muzzle in cream, puffing while it nibbles */
 g.beginPath();g.ellipse(24+cheek*1.2,-64.5,11.4+cheek*2.4,8.4+cheek*1.6,-.1,0,TAU);pF(g,pLin(g,0,-72,0,-56,[C.be,C.bed]),2.2);
 g.beginPath();g.ellipse(32,-68.5,6.6,5.4,-.2,0,TAU);pF(g,C.be,2);pE(g,36.6,-70.6,2.7,2.1);pF(g,C.no,1.2);pE(g,35.8,-71.4,.9,.6);g.fillStyle='#ffffffaa';g.fill();
 /* buck teeth and a little smile */g.beginPath();g.roundRect(31.2,-65,4.6,5,1.2);pF(g,'#ffffff',1.3);g.beginPath();g.moveTo(33.5,-65);g.lineTo(33.5,-60.4);g.strokeStyle=PTO;g.lineWidth=.8;g.stroke();
 if(happy){g.beginPath();g.moveTo(27.6,-63.4);g.quadraticCurveTo(31.6,-59.6,36,-63.8);g.strokeStyle=PTO;g.lineWidth=1.4;g.stroke()}
 for(const [x,y] of[[28.4,-66.6],[30,-64.4],[27,-64]]){pC(g,x,y,.7);g.fillStyle=ptHexA(C.fd,.7);g.fill()}
 pE(g,21.5,-63,4.2,2.5);g.fillStyle=ptHexA('#ff7a8a',.45);g.fill();
 pEye(g,23,-73,6.4,C.ey,eyeO,happy,.6);
 /* ----- the acorn-cap helmet ----- */
 const capP=()=>{g.beginPath();g.moveTo(-7.5,-81);g.bezierCurveTo(-7,-103,33,-105,34,-82);g.quadraticCurveTo(13,-88,-7.5,-81);g.closePath()};
 capP();pF(g,pLin(g,0,-103,0,-80,[C.cap2,C.cap,C.capd]),2.6);
 g.save();capP();g.clip();g.strokeStyle=ptHexA(C.capd,.85);g.lineWidth=1.3;for(let i=-16;i<=40;i+=5){g.beginPath();g.moveTo(i,-106);g.lineTo(i+14,-78);g.moveTo(i,-106);g.lineTo(i-14,-78);g.stroke()}
 g.beginPath();g.ellipse(4,-97,7,3.6,-.4,0,TAU);g.fillStyle='#ffffff30';g.fill();g.restore();
 /* rim band */g.beginPath();g.moveTo(-8.5,-81);g.quadraticCurveTo(13,-89.6,35,-82);g.lineTo(34.4,-78.2);g.quadraticCurveTo(13,-85.4,-7.8,-77.4);g.closePath();pF(g,pLin(g,0,-88,0,-77,[C.cap2,C.capd]),2);
 for(let i=0;i<8;i++){const k=i/7,x=-6+k*39,y=-79.6-Math.sin(k*Math.PI)*6;pC(g,x,y,1);g.fillStyle=C.cap2;g.fill()}
 /* stem */g.beginPath();g.moveTo(14,-100);g.quadraticCurveTo(15,-108,21,-110);g.strokeStyle=PTO;g.lineWidth=5.4;g.stroke();g.strokeStyle=C.capd;g.lineWidth=2.8;g.stroke();
 if(trim){/* Golden Oak: the cap is gilded with oak leaves and a glowing acorn gem */g.save();capP();g.clip();g.globalCompositeOperation='lighter';g.fillStyle=ptHexA('#ffb42a',.32);g.fillRect(-10,-112,50,40);g.restore();
  pLeaf(g,6,-94,16,6,-2.5,'#ffe27a','#c8901a',1.6);pLeaf(g,20,-95,16,6,-.6,'#ffe27a','#c8901a',1.6);pGlow(g,13,-93,12,'#ffd45a',.5+.2*Math.sin(t*3));pP(g,[13,-98,17,-93,13,-88,9,-93]);pF(g,pLin(g,0,-98,0,-88,['#fff6c0','#ffb42a']),1.4)}
 if(o.acc){/* Maple scarf: a knitted autumn scarf with a maple-leaf pin */g.save();g.translate(12,-57);g.beginPath();g.moveTo(-10,-2);g.quadraticCurveTo(4,5,19,-2);g.lineTo(19,4);g.quadraticCurveTo(4,11,-10,4);g.closePath();pF(g,pLin(g,0,-2,0,10,[C.sc2,C.sc,C.scd]),2);
  g.beginPath();g.moveTo(-6,4);g.lineTo(-11,18);g.lineTo(-3,19);g.lineTo(-1,6);g.closePath();pF(g,pLin(g,0,4,0,19,[C.sc,C.scd]),2);g.strokeStyle=ptHexA('#ffffff',.4);g.lineWidth=1;for(let i=0;i<4;i++){g.beginPath();g.moveTo(-8+i*7,1);g.lineTo(-6+i*7,6);g.stroke()}
  flpMaple(g,12,4,8,.3,'#ffe27a','#ff8a2a',1.2,0);g.restore()}
 g.restore();
 if(raised)arm();
 /* ----- greeting sparkles and the lob ----- */
 if(gr&&u>.1&&u<.9){for(let i=0;i<5;i++){const v=(u*1.6+i/5)%1;g.globalAlpha=Math.sin(v*Math.PI);pStar4(g,-8+i*12,-114-v*18,2.2+i%2,i%2?'#ffe2a0':'#ffffff');g.globalAlpha=1}}
 if(ab&&u>=.38&&u<.9){const v=pSeg(u,.38,.86),X0=24,Y0=-64,x=X0+v*150,y=Y0-Math.sin(v*Math.PI)*50+v*30;g.save();g.globalAlpha=1-pSeg(v,.75,1);
  for(let i=1;i<6;i++){const w=Math.max(0,v-i*.03),xx=X0+w*150,yy=Y0-Math.sin(w*Math.PI)*50+w*30;pC(g,xx,yy,5-i*.7);g.fillStyle=ptHexA('#ffe2a0',.35-i*.05);g.fill()}
  flpAcorn(g,x,y,13,v*14,AC,1.8);g.restore()}
 g.restore()};

/* ======================================================================
   EMBERLEAF: a fox whose tail is a plume of glowing maple leaves
   ====================================================================== */
PRIG.flfox=(g,o,C)=>{const t=o.t,P=o.pose,u=o.u,walk=P==='walk',ab=P==='ability',gr=P==='greet',trim=o.trim;
 let by=0,sit=0,fan=0,whip=0,crouch=0,happy=false,eyeO=pBlink(t,3),earT=0,hT=Math.sin(t*.8)*.04,lx=.4,gl=0;
 const st=walk?t*8:0,leg=ph=>walk?Math.sin(st+ph)*.5:0;
 if(walk){by=-Math.abs(Math.sin(st))*2.4}
 else if(P==='idle'){const ph=(t%8.6+8.6)%8.6;if(ph>2&&ph<2.35)earT=Math.sin((ph-2)/.35*Math.PI);if(ph>5&&ph<6.4){fan=Math.sin((ph-5)/1.4*Math.PI)*.5;gl=fan}if(ph>6.8&&ph<7.8)lx=-.5}
 if(gr){sit=pSeg(u,0,.22)*(1-pSeg(u,.84,1));fan=pSeg(u,.15,.4)*(1-pSeg(u,.8,1));happy=u>.2&&u<.9;hT=-.1*sit;gl=fan}
 if(ab){crouch=pSeg(u,0,.25)*(1-pSeg(u,.3,.42));fan=pSeg(u,.08,.3)*(1-pSeg(u,.75,1));whip=pSeg(u,.3,.46)*(1-pSeg(u,.72,.95));gl=Math.max(fan*.6,whip);hT=-crouch*.1+whip*.08;eyeO=whip>.5?.5:eyeO}
 g.save();g.translate(0,by+crouch*4);
 /* the body pivots on the hips when it sits */const HX=-20,HY=-34,ba=-sit*.42-crouch*.05,rot=(x,y)=>{const c=Math.cos(ba),s2=Math.sin(ba),dx=x-HX,dy=y-HY;return[HX+dx*c-dy*s2,HY+dx*s2+dy*c]};
 /* ----- the leaf plume: a fur brush with big maple leaves laid along it like scales ----- */
 const [tx,ty]=rot(-28,-44);g.save();g.translate(tx,ty);g.rotate(Math.sin(t*1.3)*.05-(walk?.22:0)+ba*.6+fan*.06+whip*1.1);
 const sp=1+fan*.16+(trim?.05:0),SP=[0,0,-18,-2,-34,-16,-36,-46],cb=(k,i)=>{const m=1-k;return m*m*m*SP[i]+3*m*m*k*SP[i+2]+3*m*k*k*SP[i+4]+k*k*k*SP[i+6]};
 const at=k=>{const a=[cb(k,0),cb(k,1)],b=[cb(Math.min(1,k+.02),0),cb(Math.min(1,k+.02),1)];return Math.atan2(b[1]-a[1],b[0]-a[0])};
 pGlow(g,-26*sp,-30*sp,40+fan*14+whip*16,C.gl,.14+gl*.22+(trim?.12:0)+.04*Math.sin(t*2));
 g.save();g.scale(sp,sp);
 /* the glowing brush underneath */const BR=[];for(let i=0;i<=9;i++){const k=i/9;BR.push([cb(k,0),cb(k,1),5.5+9*Math.sin(Math.PI*Math.min(1,k*.85+.1))])}flpBlobs(g,BR,pLin(g,0,0,-36,-46,[C.f,C.lf3,C.lf2]),2.2);
 /* maple leaves laid like feathers, two abreast, pointing to the tip; their points make the plume's flickering edge */
 const LV=[];for(let i=0;i<5;i++){const k=.22+i*.155;LV.push([k,-1,i],[k+.04,1,i])}LV.push([1,0,5]);
 LV.forEach(([k,sd,i],j)=>{const kk=Math.min(.98,k),a0=at(kk),nx=-Math.sin(a0),ny=Math.cos(a0),w=5.5+9*Math.sin(Math.PI*Math.min(1,kk*.85+.1)),x=cb(kk,0)+nx*w*.5*sd,y=cb(kk,1)+ny*w*.5*sd,s0=(sd?13+i*2.4:24)*(1+fan*.1),
  a=a0+Math.PI/2+sd*(.42+fan*.5)+Math.sin(t*3.1+j*1.7)*.07+(ab?Math.sin(t*16+j)*.1*whip:0),c1=(i+(sd>0?1:0))%2?C.lf1:C.lf2,c2=i<1?C.lf4:(j%3?C.lf3:C.lf2);
  flpMaple(g,x,y,s0,a,c1,c2,1.5,ptHexA(C.vn,.4),1);
  if(trim){/* Wildfire Crown: every leaf tip carries a living flame */const fx=x+Math.sin(a)*s0*.9,fy=y-Math.cos(a)*s0*.9,fs=.7+.2*Math.sin(t*11+j*1.3);g.save();g.translate(fx,fy);g.rotate(a);g.scale(fs,fs);g.globalCompositeOperation='lighter';
   for(const [cc,kk2] of[['#ff5a1a',1],['#ffb03a',.7],['#fff2b0',.4]]){g.beginPath();g.moveTo(-3.4*kk2,0);g.quadraticCurveTo(-5*kk2,-7*kk2,Math.sin(t*13+j)*3,-13*kk2);g.quadraticCurveTo(5*kk2,-7*kk2,3.4*kk2,0);g.closePath();g.fillStyle=cc;g.fill()}g.restore()}});
 /* inner glow through the leaves */g.save();g.globalCompositeOperation='lighter';pGlow(g,cb(.6,0),cb(.6,1),20,C.gl,.18+gl*.25+.06*Math.sin(t*2.4));g.restore();
 /* a glint drifts along the plume */const gp=(t*.45)%1.8;if(gp<1){const k=.2+gp*.8;pStar4(g,cb(k,0)+3,cb(k,1)-3,5*Math.sin(gp*Math.PI),'#fffbe0')}
 g.restore();g.restore();
 /* a leaf drifts off the plume now and then (an ember on the wind) */if(!ab&&!walk){const ph=((t+1.3)%5.2)/2.6;if(ph<1){const x=tx-46-ph*36+Math.sin(ph*9)*6,y=ty-58-ph*46,a=ph*5;g.save();g.globalAlpha=Math.sin(ph*Math.PI)*.9;pGlow(g,x,y,12,C.gl,.4);flpMaple(g,x,y,10,a,C.lf1,C.lf3,1.4,0);g.restore()}}
 /* ----- legs: each runs from its hip or shoulder to a paw on the ground ----- */
 const LG=(ax,ay,ph,far,front)=>{const [x0,y0]=rot(ax,ay);let fx=ax+Math.sin(st+ph)*(walk?9:0)+(front?0:sit*14)+(crouch?(front?3:-3)*crouch:0),lift=walk?Math.max(0,Math.sin(st+ph+Math.PI/2))*4:0;
  const fy=-lift,c=far?C.fd:C.f,cs=far?C.skd:C.sk;if(!front&&sit>0){/* folded haunch */pE(g,x0+4*sit,y0+8*sit,10+3*sit,9+3*sit);pF(g,c,2.4)}
  const kx=(x0+fx)/2+(front?-2:3),ky=(y0+fy)/2;pLimb(g,x0,y0,kx,ky,5.6,4.4,c);pLimb(g,kx,ky,fx,fy-2,4.4,3.6,cs);pE(g,fx+2,fy-.8,5.4,3.2);pF(g,cs,2)};
 LG(-22,-30,Math.PI,1,0);LG(14,-30,0,1,1);
 g.save();g.translate(HX,HY);g.rotate(ba);g.translate(-HX,-HY);
 const body=(ox,oy)=>{g.ellipse(-3+ox,-40+oy,28,15.5,-.04,0,TAU)};g.beginPath();body(0,0);pF(g,pRad(g,-8,-49,32,[C.f2,C.f,C.fd]),2.6);pmShade(g,body,-4,-4,ptHexA(C.fd,.3));
 g.beginPath();g.ellipse(5,-30.5,16,5.2,0,0,Math.PI);g.fillStyle=ptHexA(C.ch,.75);g.fill();
 g.beginPath();g.arc(-6,-40,11,-2.5,-1.5);g.strokeStyle=ptHexA('#ffffff',.35);g.lineWidth=2;g.stroke();
 g.restore();
 LG(-16,-29,0,0,0);LG(19,-29,Math.PI,0,1);
 /* ----- chest ruff, neck, head ----- */
 const [nx,ny]=rot(30,-66);g.save();g.translate(nx-30,ny+66);
 g.beginPath();pmFluff(g,20,-49,11,13,7,.16,.5,.2);pF(g,pLin(g,0,-62,0,-35,[C.ch,C.chd]),2.4);
 if(o.acc){/* Acorn charm: a woven collar with an acorn pendant */g.beginPath();g.moveTo(12,-60);g.quadraticCurveTo(22,-53,32,-60);g.strokeStyle=PTO;g.lineWidth=5.4;g.stroke();g.strokeStyle='#c8963a';g.lineWidth=3;g.stroke();g.strokeStyle='#ffe0a0';g.lineWidth=1;g.setLineDash([2,2]);g.stroke();g.setLineDash([]);flpAcorn(g,22,-53,8,-.1,FLP_AC,1.3)}
 g.translate(30,-66);g.rotate(hT);g.translate(-30,66);
 /* ears */for(const [x,a,far] of[[22,-.35,1],[34,.18,0]]){g.save();g.translate(x,-76);g.rotate(a+(far?0:earT*.3));g.beginPath();g.moveTo(-7,4);g.quadraticCurveTo(-5,-12,1,-22);g.quadraticCurveTo(7,-10,7,4);g.closePath();pF(g,far?C.fd:C.f,2.4);
  if(!far){g.beginPath();g.moveTo(-3.4,2);g.quadraticCurveTo(-2,-8,1,-15);g.quadraticCurveTo(4,-7,4,2);g.closePath();g.fillStyle=C.ie;g.fill()}
  g.save();g.beginPath();g.moveTo(-7,4);g.quadraticCurveTo(-5,-12,1,-22);g.quadraticCurveTo(7,-10,7,4);g.closePath();g.clip();g.fillStyle=far?C.skd:C.sk;g.fillRect(-10,-26,20,11);g.restore();g.restore()}
 const head=(ox,oy)=>{g.ellipse(29+ox,-67+oy,15.5,13.5,0,0,TAU)};g.beginPath();head(0,0);pF(g,pRad(g,24,-74,18,[C.f2,C.f,C.fd]),2.6);pmShade(g,head,-3,-3,ptHexA(C.fd,.26));
 /* long snout with a cream jaw and a dark nose */
 g.beginPath();g.moveTo(34,-74);g.quadraticCurveTo(48,-70,54,-63);g.quadraticCurveTo(46,-57,34,-58);g.closePath();pF(g,pLin(g,0,-74,0,-58,[C.f2,C.f]),2.4);
 g.beginPath();g.moveTo(31,-62);g.quadraticCurveTo(44,-63,53,-62);g.quadraticCurveTo(46,-55,33,-55);g.closePath();pF(g,C.ch,2);
 pE(g,53,-64,3.6,2.8,.3);pF(g,C.no,1.4);pE(g,52.4,-65,1.2,.7);g.fillStyle='#ffffffaa';g.fill();
 /* cheek fluff */g.beginPath();g.moveTo(18,-66);g.lineTo(13,-58);g.lineTo(20,-60);g.lineTo(19,-54);g.lineTo(26,-58);g.lineTo(31,-56);g.quadraticCurveTo(30,-64,24,-68);g.closePath();pF(g,C.ch,2);
 if(happy){g.beginPath();g.moveTo(41,-58.6);g.quadraticCurveTo(45,-56,49,-58.6);g.strokeStyle=PTO;g.lineWidth=1.4;g.stroke()}
 pEye(g,37,-70,5.4,C.ey,eyeO,happy,lx);pE(g,40,-62,3.4,1.8);g.fillStyle=ptHexA('#ff7a8a',.4);g.fill();
 g.beginPath();g.moveTo(33,-75.6);g.quadraticCurveTo(38,-77.8,42,-75.2);g.strokeStyle=ptHexA(C.fd,.8);g.lineWidth=1.4;g.stroke();
 if(trim){/* Wildfire Crown: three blazing maple leaves on its brow */const pu=.6+.4*Math.sin(t*3);pGlow(g,28,-86,16,C.gl,.5*pu);flpMaple(g,22,-79,12,-.5,'#fff2b0',C.lf2,1.1,0,1);flpMaple(g,35,-79,12,.5,'#fff2b0',C.lf2,1.1,0,1);flpMaple(g,28.5,-80,15,0,'#fffbe0',C.lf1,1.2,0,1)}
 g.restore();
 /* ----- the gale: a gust of burning leaves blows forward from the whipping tail ----- */
 if(ab&&u>.3){const v=pSeg(u,.3,.92);g.save();for(let i=0;i<12;i++){const k=Math.max(0,Math.min(1,v*1.5-i*.04));if(k<=0||k>=1)continue;const x=0+k*190+Math.sin(i*2.1+k*6)*10,y=-96+k*40-Math.sin(k*Math.PI)*20+(i%4-1.5)*12,a=k*9+i;
   g.globalAlpha=1-pSeg(k,.65,1);pGlow(g,x,y,16,C.gl,.45);flpMaple(g,x,y,9+i%3*2,a,C.lf1,i%2?C.lf3:C.lf2,1.4,0)}g.restore()}
 if(gr&&u>.2&&u<.92){for(let i=0;i<6;i++){const v=(u*1.4+i/6)%1,x=-60+i*16+Math.sin(i*2+u*8)*6,y=-104-v*26;g.globalAlpha=Math.sin(v*Math.PI);flpMaple(g,x,y,8,v*6+i,C.lf1,C.lf3,1.2,0);g.globalAlpha=1}}
 g.restore()};

/* ---------- Signature motes and victory greetings ---------- */
Object.assign(PSIG,{flsquir:['#ffd27a','acorn'],flfox:['#ff8a3a','maple']});
Object.assign(PCEL,{flsquir:'acorns',flfox:'maples'});
{const a0=petAura;petAura=function(g,id,t,front){const r=a0.apply(this,arguments);if(id!=='flsquir'&&id!=='flfox')return r;try{const bx=PDEF[id].box;
 for(let i=0;i<8;i++){if((i%2===0)!==front)continue;const sd=i*1.618,v=((t*(.13+(i%3)*.03)+sd)%1+1)%1,lane=((i*.37+.11)%1),a=Math.sin(v*Math.PI);if(a<.04)continue;
  const x=bx[0]-6+lane*(bx[2]+12)+Math.sin(t*1.2+sd*3)*9;g.save();g.globalAlpha=a;
  if(id==='flsquir'){/* golden acorns tumble down */const y=bx[1]-6+v*(bx[3]+8);pGlow(g,x,y,10,'#ffd45a',.45);flpAcorn(g,x,y,7,t*2+sd,FLP_ACG,1)}
  else{/* ember leaves rise */const y=bx[1]+bx[3]-v*(bx[3]+20);pGlow(g,x,y,10,'#ff8a2a',.6);flpLeafD(g,x,y,7,t*1.5+sd,i%3)}g.restore()}}catch(e){}return r}}
{const c0=petCelFx;petCelFx=function(g,id,u,t,cy,R){const k=PCEL[id];if(k!=='acorns'&&k!=='maples')return c0.apply(this,arguments);if(u<=0||u>=1)return;cy=cy||-50;R=R||70;const a0=1-pSeg(u,.65,1);g.save();g.translate(0,cy);
 for(let i=0;i<14;i++){const an=i/14*TAU+i*.37,sp=.6+((i*53)%10)/14,r=R*(.25+pSeg(u,0,.6)*sp),x=Math.cos(an)*r,y=Math.sin(an)*r*.75+pSeg(u,.2,1)*R*(k==='acorns'?.4:-.5);g.globalAlpha=Math.max(0,a0*(i%3?1:.8));
  if(k==='acorns'){if(i%3)flpAcorn(g,x,y,8,t*3+i,i%2?FLP_AC:FLP_ACG,1.2);else pLeaf(g,x,y,12,4.4,t*2+i,'#ffd45a','#c8641a',1.2)}
  else{pGlow(g,x,y,10,'#ff8a2a',.4);flpLeafD(g,x,y,9+i%3*2,t*2+i,i%3)}}
 g.globalAlpha=1;g.restore()}}
/* ---------- ability icons ---------- */
Object.assign(PICO,{
 acorntoss:g=>{g.save();g.globalAlpha=.9;for(let i=0;i<3;i++){g.beginPath();g.moveTo(-40,-6+i*12);g.quadraticCurveTo(-22,-10+i*12,-12,-4+i*10);g.strokeStyle='#ffe2a0';g.lineWidth=5-i;g.lineCap='round';g.stroke()}g.restore();
  flpAcorn(g,-2,-12,46,.5,FLP_AC,3.4);pStar5(g,30,-24,14,pLin(g,0,-38,0,-10,['#fff6c0','#ffd45a']),3);pStar4(g,34,18,7,'#ffffff')},
 maplegale:g=>{pGlow(g,0,0,48,'#ff8a2a',.4);g.beginPath();g.arc(0,4,30,-2.6,.4);g.strokeStyle='#ffe2a0';g.lineWidth=5;g.lineCap='round';g.stroke();
  flpMaple(g,-16,22,34,-.5,'#ffe27a','#e8401a',3.4,'#fff2c088');flpMaple(g,14,10,40,.35,'#fff2b0','#ff7a1a',3.6,'#fff2c088');flpMaple(g,30,-20,20,1.2,'#ffe27a','#c8281a',2.6,0)}});

/* ---------- the harvest Mythic backdrop palette (88g): amber moonlight, cranberry and gold ---------- */
try{Object.assign(MYPAL,{flturkey:{b1:'#4a1e14',b2:'#120608',c:['#ffb42a','#e8401a','#b04a2a','#ffe9a0'],ring:'#ffd45a',glow:'#ffa53a',mote:'#fff2c0',star:'#ffe9a0'}})}catch(e){}
