import asyncio,os,sys
from playwright.async_api import async_playwright
VP=(int(sys.argv[1]),int(sys.argv[2])) if len(sys.argv)>2 else (1600,900)
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':VP[0],'height':VP[1]});er=[]
        pg.on('pageerror',lambda e:er.append('PE '+str(e)[:300]))
        await pg.goto('file://'+os.path.abspath('out.html'));await pg.wait_for_timeout(900);E=pg.evaluate
        await E("()=>{RS_ASK=false;title();P.petSt=2;P.pets={antler:{b:560,acc:1,adv:56,used:23},bramble:{b:120,adv:12},prism:{b:900,acc:1,pal:1,trim:1,cel:1,adv:90,used:140}};P.pet='antler';P.petUnl={antler:'cel'};P.eggs={r:1,l:0};P.trail={n:8,c:0};P.trSeen=8;petNorm();PTX.sel='antler';petHall('Pets')}")
        await pg.wait_for_timeout(1500);await pg.screenshot(path=f'shots/pd_{VP[0]}.png')
        print(await E("()=>document.getElementById('ptdet').innerText"))
        await pg.click('.ptmi.nw');await pg.wait_for_timeout(900)
        print('atelier open',await E("()=>!!document.getElementById('ptat')"),'unl cleared',await E("()=>JSON.stringify(P.petUnl)"))
        await pg.keyboard.press('Escape');await pg.wait_for_timeout(500)
        await E("()=>{PTX.sel='prism';petHall('Pets')}");await pg.wait_for_timeout(1200);await pg.screenshot(path=f'shots/pd2_{VP[0]}.png')
        print(await E("()=>document.querySelector('.ptnx').innerText"))
        await E("()=>{PTX.sel='bramble';petHall('Pets')}");await pg.wait_for_timeout(800)
        print(await E("()=>document.querySelector('.ptnx').innerText"))
        print(er[:6]);await b.close()
asyncio.run(main())
