/* ===== MOONLIT FISHING: fish art 4 — Frostfall Lake: smelt (common), char (uncommon), flyfish (rare) =====
   Each FISHART.<id>(g,t,o) draws one fish facing right, centred on the origin, ~200 units long. Helpers prefixed fa4_
   (the polish kit is a private copy so this file never depends on another file's internals). */
/* path from a command list: 'M',x,y 'L',x,y 'Q',cx,cy,x,y 'C',c1x,c1y,c2x,c2y,x,y 'Z' */
function fa4_path(g,c){g.beginPath();let i=0;while(i<c.length){const k=c[i++];
 if(k==='M'){g.moveTo(c[i],c[i+1]);i+=2}else if(k==='L'){g.lineTo(c[i],c[i+1]);i+=2}
 else if(k==='Q'){g.quadraticCurveTo(c[i],c[i+1],c[i+2],c[i+3]);i+=4}
 else if(k==='C'){g.bezierCurveTo(c[i],c[i+1],c[i+2],c[i+3],c[i+4],c[i+5]);i+=6}else if(k==='Z')g.closePath()}}
/* crisp closed polygon */
function fa4_poly(g,p){g.beginPath();g.moveTo(p[0],p[1]);for(let i=2;i<p.length;i+=2)g.lineTo(p[i],p[i+1]);g.closePath()}
/* gradient with explicit stops [[pos,colour],...] */
function fa4_grad(g,x0,y0,x1,y1,s){const q=g.createLinearGradient(x0,y0,x1,y1);for(const e of s)q.addColorStop(e[0],e[1]);return q}
function fa4_rgrad(g,x,y,r0,r1,s){const q=g.createRadialGradient(x,y,r0,x,y,r1);for(const e of s)q.addColorStop(e[0],e[1]);return q}
/* run fn in a translated + rotated frame */
function fa4_at(g,x,y,a,fn){g.save();g.translate(x,y);g.rotate(a);fn();g.restore()}
/* twinkle 0..1 */
const fa4_tw=(t,i,sp)=>.5+.5*Math.sin(t*(sp||3)+i*1.91);
/* glossy highlight: a soft white curve inside the clip path */
function fa4_gloss(g,clip,x0,y0,cx,cy,x1,y1,w,a){g.save();clip();g.clip();g.lineCap='round';g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo(cx,cy,x1,y1);
 g.strokeStyle=`rgba(255,255,255,${a*.4})`;g.lineWidth=w*2.2;g.stroke();g.strokeStyle=`rgba(255,255,255,${a})`;g.lineWidth=w;g.stroke();g.restore()}
/* gill arc (clipped to the body) */
function fa4_gill(g,clip,x,y,r,a0,a1,c,a){g.save();clip();g.clip();g.beginPath();g.arc(x,y,r,a0,a1);g.strokeStyle=c||FKO;g.globalAlpha=a==null?.6:a;g.lineWidth=2.4;g.lineCap='round';g.stroke();g.restore()}
/* rib lines from a root point to each listed point, clipped to the clip path */
function fa4_ribs(g,clip,x0,y0,pts,a,c,lw){g.save();clip();g.clip();g.strokeStyle=c||FKO;g.globalAlpha=a==null?.25:a;g.lineWidth=lw||1.3;g.lineCap='round';
 for(let i=0;i<pts.length;i+=2){g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo((x0+pts[i])/2,(y0+pts[i+1])/2*1.04,pts[i],pts[i+1]);g.stroke()}g.restore()}
/* tapered strand along a chain of cubic beziers b=[x0,y0, c1x,c1y,c2x,c2y,x1,y1, ...] */
function fa4_strand(g,b,w0,w1,col,lw,rays){const P=[[b[0],b[1]]];let x=b[0],y=b[1];
 for(let i=2;i+5<b.length;i+=6){const c1x=b[i],c1y=b[i+1],c2x=b[i+2],c2y=b[i+3],ex=b[i+4],ey=b[i+5];
  for(let s=1;s<=12;s++){const u=s/12,v=1-u;P.push([v*v*v*x+3*v*v*u*c1x+3*v*u*u*c2x+u*u*u*ex,v*v*v*y+3*v*v*u*c1y+3*v*u*u*c2y+u*u*u*ey])}x=ex;y=ey}
 const n=P.length,L=[],R=[];for(let i=0;i<n;i++){const a=P[Math.max(0,i-1)],c=P[Math.min(n-1,i+1)],dx=c[0]-a[0],dy=c[1]-a[1],d=Math.hypot(dx,dy)||1,w=(w0+(w1-w0)*i/(n-1))/2;
  L.push([P[i][0]-dy/d*w,P[i][1]+dx/d*w]);R.push([P[i][0]+dy/d*w,P[i][1]-dx/d*w])}
 g.beginPath();g.moveTo(L[0][0],L[0][1]);for(const p of L)g.lineTo(p[0],p[1]);for(let i=n-1;i>=0;i--)g.lineTo(R[i][0],R[i][1]);g.closePath();
 g.lineJoin='round';g.lineWidth=lw||2.2;g.strokeStyle=FKO;g.stroke();g.fillStyle=col;g.fill();
 /* optional fin finish: fine rays along the strand and a soft highlight on one edge */
 if(rays){g.save();g.clip();g.lineCap='round';const line=(f,c,w)=>{g.beginPath();for(let i=0;i<n;i++){const px=L[i][0]+(R[i][0]-L[i][0])*f,py=L[i][1]+(R[i][1]-L[i][1])*f;i?g.lineTo(px,py):g.moveTo(px,py)}g.strokeStyle=c;g.lineWidth=w;g.stroke()};
  for(const f of [.3,.5,.7])line(f,rays,.7);line(.16,'rgba(255,255,255,.65)',1.1);g.restore()}}
/* eyelid: amt 0 open .. 1 shut */
function fa4_lid(g,x,y,r,amt,col){if(amt<=0)return;const ly=y-r+2*r*Math.min(1,amt);g.save();g.beginPath();g.arc(x,y,r,0,TAU);g.clip();
 g.beginPath();g.moveTo(x-r-3,y-r-3);g.lineTo(x+r+3,y-r-3);g.lineTo(x+r+3,ly);g.quadraticCurveTo(x,ly+r*.2,x-r-3,ly);g.closePath();g.fillStyle=col;g.fill();
 g.beginPath();g.moveTo(x+r+3,ly);g.quadraticCurveTo(x,ly+r*.2,x-r-3,ly);g.strokeStyle=FKO;g.lineWidth=Math.max(2,r*.26);g.stroke();if(amt>.7){g.globalAlpha=Math.min(1,(amt-.7)/.22);g.beginPath();g.moveTo(x-r*.8,y+r*.02);g.quadraticCurveTo(x,y+r*.56,x+r*.8,y+r*.02);g.lineWidth=Math.max(1.8,r*.24);g.stroke();g.beginPath();g.moveTo(x-r*.5,y-r*.32);g.quadraticCurveTo(x,y-r*.02,x+r*.5,y-r*.32);g.strokeStyle='rgba(255,255,255,.32)';g.lineWidth=Math.max(1,r*.13);g.stroke();g.globalAlpha=1}g.restore();
 g.beginPath();g.arc(x,y,r,0,TAU);g.lineWidth=Math.max(2,r*.24);g.strokeStyle=FKO;g.stroke()}
/* blink: 0 open, rising to 1 for a quick blink every few seconds */
function fa4_blink(t,s){const p=((t+s)%5.1+5.1)%5.1;return p>4.9?1-Math.abs(p-5)/.1:0}
/* small cartoon smile */
function fa4_smile(g,x0,y0,cx,cy,x1,y1,w){g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo(cx,cy,x1,y1);g.strokeStyle=FKO;g.lineWidth=w||2.4;g.lineCap='round';g.stroke()}
/* rosy cheek blush */
function fa4_blush(g,x,y,r,c,a){g.save();g.globalAlpha=a==null?.45:a;g.fillStyle=fa4_rgrad(g,x,y,0,r,[[0,c||'#ff7aa0'],[1,(c||'#ff7aa0')+'00']]);g.beginPath();g.ellipse(x,y,r,r*.62,0,0,TAU);g.fill();g.restore()}
/* pectoral fin: a fan hinged at (x,y), sweeping back; a = tilt */
function fa4_pec(g,x,y,a,L,c1,c2,al,rim){fa4_at(g,x,y,a,()=>{const P=()=>fa4_path(g,['M',3,-3.5,'C',-L*.3,-L*.34,-L*.78,-L*.3,-L,-L*.08,'Q',-L*1.02,L*.08,-L*.9,L*.18,'Q',-L*.8,L*.3,-L*.62,L*.3,'C',-L*.36,L*.28,-L*.1,L*.12,3,3.5,'Z']);
 g.globalAlpha=al||1;P();fkFill(g,fkLin(g,0,0,-L,L*.1,[c1,c2]),2.2);g.globalAlpha=1;fa4_ribs(g,P,2,0,[-L,-L*.12,-L,L*.04,-L*.9,L*.2,-L*.7,L*.3],.3);
 fa4_finfx(g,P,0,0,shade(c1,.45),[-L*.98,-L*.03,-L*.96,L*.12,-L*.82,L*.26],.6,0);
 g.save();P();g.clip();g.beginPath();g.moveTo(2,-3);g.bezierCurveTo(-L*.3,-L*.3,-L*.78,-L*.26,-L*.98,-L*.06);g.strokeStyle=rim||'rgba(255,255,255,.55)';g.lineWidth=2;g.stroke();g.restore();P();g.lineJoin='round';g.lineWidth=2.2;g.strokeStyle=FKO;g.stroke()})}
/* 6-armed snowflake crystal */
function fa4_snow(g,x,y,r,rot,c,a){g.save();g.translate(x,y);g.rotate(rot);g.globalAlpha=a==null?1:a;g.strokeStyle=c||'#fff';g.lineCap='round';g.lineWidth=Math.max(1,r*.26);
 for(let i=0;i<6;i++){g.rotate(TAU/6);g.beginPath();g.moveTo(0,0);g.lineTo(r,0);g.moveTo(r*.55,0);g.lineTo(r*.8,-r*.24);g.moveTo(r*.55,0);g.lineTo(r*.8,r*.24);g.stroke()}
 g.beginPath();g.arc(0,0,r*.2,0,TAU);g.fillStyle=c||'#fff';g.fill();g.restore()}
/* catch-spectacle wash */
function fa4_catch(g,o,c,k){const v=(o.glow||0)*(k||1);if(v>0)fkGlow(g,10,0,115,c||'#fff2c8',.24*v)}
/* ribbon outline from a centre line fn(s)->[x,y,halfWidth]; returns flat points (left side then right side reversed) */
function fa4_rib(n,fn){const c=[];for(let i=0;i<=n;i++)c.push(fn(i/n));const L=[],R=[];
 for(let i=0;i<=n;i++){const a=c[Math.max(0,i-1)],b=c[Math.min(n,i+1)],dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy)||1,nx=-dy/d,ny=dx/d,w=c[i][2];
  L.push(c[i][0]+nx*w,c[i][1]+ny*w);R.unshift(c[i][0]-nx*w,c[i][1]-ny*w)}return L.concat(R)}
/* closed smooth spline (same curve as fkPath) appended to the current path when cont is true */
function fa4_blob(g,p,cont){const n=p.length/2,mx=i=>(p[(i%n)*2]+p[((i+1)%n)*2])/2,my=i=>(p[(i%n)*2+1]+p[((i+1)%n)*2+1])/2;if(!cont)g.beginPath();g.moveTo(mx(n-1),my(n-1));for(let i=0;i<n;i++)g.quadraticCurveTo(p[i*2],p[i*2+1],mx(i),my(i));g.closePath()}
/* clip to everything OUTSIDE a spline outline (so see-through bodies do not show the fin roots behind them) */
function fa4_outside(g,p){g.beginPath();g.rect(-400,-400,800,800);fa4_blob(g,p,1);g.clip('evenodd')}
/* crystal fin polygon: pre points, then an outer edge with a sharp ice shard between every pair of edge points, then post points */
function fa4_crys(pre,edge,post,len){const out=pre.slice();let cx=0,cy=0;const all=pre.concat(edge,post);for(let i=0;i<all.length;i+=2){cx+=all[i];cy+=all[i+1]}cx/=all.length/2;cy/=all.length/2;
 for(let i=0;i<edge.length;i+=2){out.push(edge[i],edge[i+1]);if(i+3<edge.length){const ax=edge[i],ay=edge[i+1],bx=edge[i+2],by=edge[i+3],mx=(ax+bx)/2,my=(ay+by)/2;let nx=-(by-ay),ny=bx-ax;const d=Math.hypot(nx,ny)||1;nx/=d;ny/=d;
  if(nx*(mx-cx)+ny*(my-cy)<0){nx=-nx;ny=-ny}const L=len*(i/2%2?.72:1);out.push(mx+nx*L,my+ny*L)}}
 return out.concat(post)}
/* ---- polish kit (fa4_) ---- */
/* hex colour + alpha -> rgba() */
function fa4_rgba(h,a){const n=parseInt(h.slice(1,7),16);return `rgba(${n>>16},${n>>8&255},${n&255},${a})`}
/* rich eye: shaded sclera, gradient iris with a dark rim and fine striations, pupil, big catch-light, second glint and a soft lower reflection */
function fa4_eye(g,x,y,r,iris,look){look=look||0;const ix=x+r*.18+look*r*.12,iy=y+r*.05,ir=r*.62;
 g.beginPath();g.arc(x,y,r,0,TAU);g.fillStyle=fa4_rgrad(g,x-r*.25,y-r*.3,r*.1,r*1.05,[[0,'#ffffff'],[.62,'#fbf7f0'],[1,'#d8d0e6']]);g.fill();
 g.save();g.beginPath();g.arc(x,y,r,0,TAU);g.clip();
 g.beginPath();g.arc(ix,iy,ir,0,TAU);g.fillStyle=fa4_rgrad(g,ix-ir*.15,iy+ir*.25,ir*.08,ir,[[0,shade(iris,.5)],[.45,iris],[.85,shade(iris,-.35)],[1,shade(iris,-.6)]]);g.fill();
 g.strokeStyle=fa4_rgba(shade(iris,.55),.35);g.lineWidth=Math.max(.6,r*.06);g.beginPath();
 for(let i=0;i<10;i++){const a=i/10*TAU+.3;g.moveTo(ix+Math.cos(a)*ir*.42,iy+Math.sin(a)*ir*.42);g.lineTo(ix+Math.cos(a)*ir*.86,iy+Math.sin(a)*ir*.86)}g.stroke();
 g.beginPath();g.arc(ix,iy,ir,0,TAU);g.strokeStyle=fa4_rgba(shade(iris,-.7),.85);g.lineWidth=Math.max(.8,r*.08);g.stroke();
 g.beginPath();g.arc(x+r*.22+look*r*.12,y+r*.08,r*.34,0,TAU);g.fillStyle='#0c0612';g.fill();
 /* upper lid shadow */
 g.fillStyle=fa4_grad(g,0,y-r,0,y-r*.2,[[0,'rgba(40,20,60,.32)'],[1,'rgba(40,20,60,0)']]);g.fillRect(x-r,y-r,r*2,r*.8);
 /* lower reflection crescent */
 g.beginPath();g.arc(ix,iy,ir*.72,Math.PI*.25,Math.PI*.8);g.strokeStyle='rgba(255,255,255,.42)';g.lineWidth=Math.max(.8,r*.1);g.lineCap='round';g.stroke();
 g.restore();
 g.beginPath();g.arc(x,y,r,0,TAU);g.lineWidth=Math.max(2,r*.24);g.strokeStyle=FKO;g.stroke();
 g.beginPath();g.ellipse(x+r*.34,y-r*.24,r*.25,r*.21,-.5,0,TAU);g.fillStyle='#fff';g.fill();
 g.beginPath();g.arc(x+r*.08,y-r*.34,r*.08,0,TAU);g.fill();
 g.beginPath();g.arc(x-r*.06,y+r*.34,r*.1,0,TAU);g.fillStyle='rgba(255,255,255,.75)';g.fill()}
/* rim light: thin light just inside the top edge (moonlight) and a reflected glow inside the bottom edge */
function fa4_rim(g,clip,top,bot,a,w){a=a==null?1:a;w=w||2;g.save();clip();g.clip();
 if(top){g.save();g.translate(.6,w*1.25);clip();g.strokeStyle=top;g.globalAlpha=.55*a;g.lineWidth=w;g.stroke();g.restore()}
 if(bot){g.save();g.translate(-.6,-w*1.3);clip();g.strokeStyle=bot;g.globalAlpha=.5*a;g.lineWidth=w*1.2;g.stroke();g.restore()}
 g.restore()}
/* crisp specular glint (a bright tilted lozenge and a dot) */
function fa4_spec(g,x,y,s,a){g.save();g.globalAlpha=a==null?.95:a;g.fillStyle='#fff';g.beginPath();g.ellipse(x,y,3.4*s,1.25*s,-.42,0,TAU);g.fill();
 g.beginPath();g.arc(x+4.6*s,y-2.4*s,.9*s,0,TAU);g.fill();g.restore()}
/* fin finish: shadowed root, fine secondary rays, and a light translucent band toward the edge */
function fa4_finfx(g,P,rx,ry,edge,rays,a,lw){a=a==null?1:a;g.save();P();g.clip();
 if(rays&&rx!=null){g.strokeStyle=fa4_rgba(edge,.32*a);g.lineWidth=.8;g.lineCap='round';g.beginPath();for(let i=0;i<rays.length;i+=2){g.moveTo(rx,ry);g.lineTo(rx+(rays[i]-rx)*1.1,ry+(rays[i+1]-ry)*1.1)}g.stroke()}
 g.lineJoin='round';P();g.strokeStyle=fa4_rgba(edge,.16*a);g.lineWidth=12;g.stroke();P();g.strokeStyle=fa4_rgba(edge,.3*a);g.lineWidth=5;g.stroke();
 if(rx!=null&&ry!=null){g.fillStyle=fa4_rgrad(g,rx,ry,0,26,[[0,'rgba(20,8,30,.2)'],[1,'rgba(20,8,30,0)']]);g.fillRect(rx-28,ry-28,56,56)}
 g.restore();if(lw!==0){P();g.lineJoin='round';g.lineWidth=lw||2.4;g.strokeStyle=FKO;g.stroke()}}
/* embossed fine scales: dark scale edges with a lighter catch-light just inside */
function fa4_tex(g,clip,x0,x1,y0,y1,s,dark,light,a){fkScales(g,clip,x0,x1,y0,y1,s,dark,a);g.save();g.translate(0,-1);fkScales(g,clip,x0,x1,y0,y1,s,light,a*.75);g.restore()}
/* operculum: soft shade behind the gill, a crisp gill line, a highlight on its front lip and a faint second slit */
function fa4_gill2(g,clip,x,y,r,a0,a1,c,a){a=a==null?.6:a;g.save();clip();g.clip();g.lineCap='round';
 g.beginPath();g.arc(x,y,r,a0,a1);g.arc(x,y,r+10,a1,a0,true);g.closePath();g.fillStyle=fa4_rgrad(g,x,y,r,r+10,[[0,fa4_rgba(c,.24)],[1,fa4_rgba(c,0)]]);g.fill();
 g.beginPath();g.arc(x+7,y,r+6,a0+.08,a1-.08);g.strokeStyle=fa4_rgba(c,.28*a/.6);g.lineWidth=1.2;g.stroke();
 g.beginPath();g.arc(x,y,r,a0,a1);g.strokeStyle=c;g.globalAlpha=Math.min(1,a*1.2);g.lineWidth=1.8;g.stroke();
 g.beginPath();g.arc(x-1.6,y,r,a0+.06,a1-.06);g.strokeStyle='#ffffff';g.globalAlpha=.3;g.lineWidth=1.2;g.stroke();g.restore()}
/* mouth with a soft lower lip, a lip highlight and a curled corner */
function fa4_mouth(g,x0,y0,cx,cy,x1,y1,w,lip){g.save();g.lineCap='round';
 g.beginPath();g.moveTo(x0-.5,y0+1.8);g.quadraticCurveTo(cx,cy+2.4,x1+.5,y1+1.8);g.strokeStyle=fa4_rgba(lip||'#ff8aa8',.55);g.lineWidth=3.2;g.stroke();
 g.beginPath();g.moveTo(x0,y0-1.4);g.quadraticCurveTo(cx,cy-1.6,x1+1,y1-1.4);g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=1.1;g.stroke();
 fa4_smile(g,x0,y0,cx,cy,x1,y1,w||2);
 g.beginPath();g.arc(x1+1.6,y1,2,Math.PI*.72,Math.PI*1.28);g.strokeStyle=FKO;g.lineWidth=1.2;g.stroke();g.restore()}
/* gentle colour variation: a few soft tinted blotches inside a clip; b=[[x,y,r,colour,alpha],...] */
function fa4_mottle(g,clip,b){g.save();clip();g.clip();for(const m of b){g.fillStyle=fa4_rgrad(g,m[0],m[1],0,m[2],[[0,fa4_rgba(m[3],m[4])],[1,fa4_rgba(m[3],0)]]);g.fillRect(m[0]-m[2],m[1]-m[2],m[2]*2,m[2]*2)}g.restore()}
/* fine speckle texture (deterministic) inside a clip */
function fa4_speck(g,clip,x0,x1,y0,y1,n,col,a,r,seed){g.save();clip();g.clip();g.fillStyle=col;g.globalAlpha=a;g.beginPath();let s=seed||7;
 for(let i=0;i<n;i++){s=(s*9301+49297)%233280;const u=s/233280;s=(s*9301+49297)%233280;const v=s/233280;const x=x0+(x1-x0)*u,y=y0+(y1-y0)*v,rr=r*(.6+.8*((i*37)%10)/10);g.moveTo(x+rr,y);g.arc(x,y,rr,0,TAU)}g.fill();g.restore()}
/* frost rime: a dotted white crust just inside an outline */
function fa4_rime(g,P,a,w){g.save();P();g.clip();P();g.strokeStyle=`rgba(255,255,255,${a==null?.7:a})`;g.lineWidth=w||3;g.setLineDash([1.6,3.4]);g.lineCap='round';g.stroke();g.setLineDash([]);g.restore()}
/* frosted fin: translucent ice gradient, fine rays, a misty edge band and a rime crust */
function fa4_frostFin(g,pp,rx,ry,c1,c2,ribs,lw,al){const P=()=>fkPath(g,pp);g.globalAlpha=al==null?.92:al;fkFin(g,pp,c1,c2,ribs,lw||2.3);g.globalAlpha=1;
 fa4_finfx(g,P,null,null,'#ffffff',null,1,0);fa4_rime(g,P,.8,2.4);P();g.lineJoin='round';g.lineWidth=lw||2.3;g.strokeStyle=FKO;g.stroke()}
/* faceted ice crystal (a hexagonal prism with a pointed cap) standing at (x,y), pointing along angle a; length L, width w */
function fa4_icicle(g,x,y,a,L,w,al,t){fa4_at(g,x,y,a,()=>{const h=w*.5,P=()=>fa4_poly(g,[-2,-h,L*.66,-h,L,0,L*.66,h,-2,h]);
 g.globalAlpha=al==null?1:al;P();fkFill(g,fa4_grad(g,0,-h,0,h,[[0,'#ffffff'],[.45,'#d4f2ff'],[.5,'#9ad6ff'],[1,'#5aa8f0']]),2);
 g.save();P();g.clip();g.fillStyle='rgba(255,255,255,.55)';fa4_poly(g,[-2,-h,L*.66,-h,L,0,L*.62,-h*.15,-2,-h*.15]);g.fill();
 g.beginPath();g.moveTo(L*.66,-h);g.lineTo(L*.62,-h*.15);g.lineTo(L*.66,h);g.moveTo(L*.62,-h*.15);g.lineTo(L,0);g.strokeStyle='rgba(30,90,180,.5)';g.lineWidth=.9;g.stroke();g.restore();
 P();g.lineWidth=2;g.strokeStyle=FKO;g.stroke();g.globalAlpha=1})}
/* a little cluster of three ice crystals fanning out of a surface at (x,y); a = outward angle; a frosty rime patch hides the roots */
function fa4_cluster(g,x,y,a,s,t,i){const k=fa4_tw(t,i||0,2.2),ix=x-Math.cos(a)*3*s,iy=y-Math.sin(a)*3*s;
 fa4_icicle(g,ix+Math.sin(a)*3*s,iy-Math.cos(a)*3*s,a-.7,13*s,6.2*s);fa4_icicle(g,ix-Math.sin(a)*3*s,iy+Math.cos(a)*3*s,a+.66,11.5*s,5.8*s);fa4_icicle(g,ix,iy,a,18*s,7.4*s);
 g.save();g.translate(x-Math.cos(a)*1.5*s,y-Math.sin(a)*1.5*s);g.rotate(a+Math.PI/2);g.beginPath();g.ellipse(0,0,10*s,3.6*s,0,0,TAU);g.fillStyle=fa4_rgrad(g,0,0,0,8*s,[[0,'rgba(255,255,255,.95)'],[.6,'rgba(220,246,255,.7)'],[1,'rgba(200,240,255,0)']]);g.fill();
 g.fillStyle='#fff';for(const d of [[-5,.6,1],[4.5,.4,.9],[0,1.4,.8]]){g.beginPath();g.arc(d[0]*s,d[1]*s,d[2]*s,0,TAU);g.fill()}g.restore();
 fkSpark(g,x+Math.cos(a)*18*s,y+Math.sin(a)*18*s,(2.4+3.4*k)*s,'#ffffff',.45+.55*k)}
/* soft travelling sheen band clipped to a path */
function fa4_sheen(g,P,t,sp,c,a){const sx=((t*sp)%280)-130;g.save();P();g.clip();g.fillStyle=fa4_grad(g,sx-24,-34,sx+24,34,[[0,'rgba(255,255,255,0)'],[.5,fa4_rgba(c,a)],[1,'rgba(255,255,255,0)']]);g.fillRect(-120,-60,240,120);g.restore()}

/* ---------------- 1. Snowdrift Smelt (Common): a glassy little smelt — icy-blue back, see-through belly, pointed snout with an underbite ---------------- */
FISHART.smelt=(g,t,o)=>{const sw=fkSway(o,6,.17),fin=Math.sin(t*8)*.13;g.save();g.rotate(-sw*.22);
 const BP=[112,1,104,-7,86,-16,52,-19,12,-18,-28,-13,-54,-7,-68,-4,-68,4,-54,7,-28,12,12,17,52,17,84,13,100,8,109,4],B=()=>fkPath(g,BP);
 // tail: long, delicate, deeply forked; glassy blue at the root, frosted white at the tips
 const T=()=>fa4_path(g,['M',12,-3.5,'Q',-4,-4.5,-16,-10,'Q',-32,-22,-50,-39,'Q',-45,-26,-38,-15,'Q',-31,-5,-25,0,'Q',-31,5,-38,15,'Q',-45,26,-50,39,'Q',-32,22,-16,10,'Q',-4,4.5,12,3.5,'Z']);
 // everything behind the see-through body is clipped away so no fin roots show through the glass
 g.save();fa4_outside(g,BP);
 fa4_at(g,-62,0,sw,()=>{if(g.canvas===FKSIL){T();g.fillStyle='#000';g.fill()}T();g.fillStyle=fa4_grad(g,8,0,-50,0,[[0,'rgba(34,184,172,.92)'],[.35,'rgba(136,236,218,.6)'],[.68,'rgba(214,252,244,.3)'],[1,'rgba(255,255,255,.9)']]);g.fill();
  fa4_ribs(g,T,8,0,[-49,-37,-42,-26,-34,-13,-34,13,-42,26,-49,37],.28,'#16706a',1);
  fa4_finfx(g,T,10,0,'#ffffff',null,.8,0);
  g.save();T();g.clip();for(const k of [-1,1]){g.fillStyle=fa4_rgrad(g,-50,39*k,0,24,[[0,'rgba(255,255,255,1)'],[.45,'rgba(246,252,255,.85)'],[1,'rgba(240,250,255,0)']]);g.fillRect(-76,k<0?-62:0,62,62)}g.restore();
  fa4_rime(g,T,.9,2.4);
  for(const k of [-1,1])fa4_snow(g,-43,30*k,2.5,t*.4*k,'#ffffff',.95);
  T();g.lineJoin='round';g.lineWidth=2.3;g.strokeStyle=FKO;g.stroke()});
 const ice1='#ffffff',ice2='#36c4ae';
 fa4_at(g,4,-17,fin*.5,()=>fa4_frostFin(g,[10,1,5,-6,-3,-17,-10,-18,-14,-7,-16,2],2,0,ice1,ice2,[[4,0,-4,-15],[-3,0,-9,-16],[-9,0,-13,-8]],2.3,.82));
 // adipose fin: the smelt's little fleshy nub between the dorsal and the tail
 fa4_at(g,-36,-9,fin*.3,()=>fa4_frostFin(g,[6,2,3,-6,-3,-10,-9,-7,-10,2],0,0,ice1,'#48d2bc',null,2.1,.88));
 fa4_at(g,-28,11,-fin*.7,()=>fa4_frostFin(g,[6,-1,0,8,-11,11,-14,-1],0,0,ice1,ice2,[[0,0,-10,9]],2.2,.8));
 fa4_at(g,18,16,-fin,()=>fa4_frostFin(g,[6,-2,-1,8,-11,10,-11,-2],0,0,ice1,ice2,[[0,0,-9,8]],2.1,.8));
 g.restore();
 // body: opaque icy-blue back over a glassy belly; the whole rear half fades to see-through
 const BG=fa4_grad(g,0,-19,0,17,[[0,'#0c5560'],[.17,'#16928a'],[.32,'#5ed8c2'],[.42,'rgba(216,250,242,.86)'],[.54,'rgba(246,255,252,.5)'],[.8,'rgba(226,246,244,.34)'],[1,'rgba(206,236,236,.48)']]);
 if(g.canvas===FKSIL){B();g.fillStyle='#000';g.fill()}g.save();B();g.clip();g.fillStyle=BG;g.globalAlpha=.6;g.fillRect(-80,-25,200,50);g.globalAlpha=.17;for(let k=0;k<14;k++)g.fillRect(-62+k*7.5,-25,200,50);g.globalAlpha=1;
 // the head stays solid silver; the glassiness starts behind the gill
 g.fillStyle=fa4_grad(g,64,0,86,0,[[0,'rgba(232,242,255,0)'],[1,'rgba(232,242,255,.82)']]);g.fillRect(64,-8,60,30);
 // through the glass: a thin spine with vertebra ticks, a fan of fine ribs and a pearly swim bladder
 g.fillStyle=fa4_rgrad(g,14,5,0,20,[[0,'rgba(236,230,255,.4)'],[1,'rgba(236,230,255,0)']]);g.beginPath();g.ellipse(14,5,22,4.5,-.03,0,TAU);g.fill();
 g.lineCap='round';const spine=dy=>{g.beginPath();g.moveTo(80,1.6+dy);g.quadraticCurveTo(8,.2+dy,-70,1.2+dy)};
 spine(0);g.strokeStyle=fa4_grad(g,80,0,-66,0,[[0,'rgba(28,116,124,.2)'],[.35,'rgba(22,104,114,.75)'],[1,'rgba(22,104,114,.95)']]);g.lineWidth=3;g.stroke();
 spine(-.7);g.strokeStyle=fa4_grad(g,80,0,-66,0,[[0,'rgba(255,255,255,.15)'],[1,'rgba(255,255,255,.95)']]);g.lineWidth=1;g.stroke();
 g.beginPath();for(let i=0;i<20;i++){const x=56-i*6;g.moveTo(x,-.6);g.lineTo(x,3)}g.strokeStyle=fa4_grad(g,60,0,-66,0,[[0,'rgba(28,116,124,.15)'],[1,'rgba(28,116,124,.7)']]);g.lineWidth=1;g.stroke();
 g.beginPath();for(let i=0;i<13;i++){const x=62-i*9.4;g.moveTo(x,1.6);g.quadraticCurveTo(x-3,7,x-6.5,12.4-i*.5)}g.strokeStyle=fa4_grad(g,70,0,-62,0,[[0,'rgba(36,126,134,.22)'],[1,'rgba(36,126,134,.7)']]);g.lineWidth=1.1;g.stroke();
 // gentle aqua / lilac shimmer drifting along the flank
 const sh=Math.sin(t*1.4)*32;g.globalAlpha=.12;g.fillStyle=fa4_grad(g,-70+sh,-15,90+sh,15,[[0,'#8af0ff'],[.4,'#c8b4ff'],[.7,'#8ae4ff'],[1,'#d0b8ff']]);g.fillRect(-80,-22,200,20);g.globalAlpha=1;
 // soft white glassy edges
 B();g.strokeStyle='rgba(255,255,255,.2)';g.lineWidth=6.5;g.stroke();B();g.strokeStyle='rgba(255,255,255,.72)';g.lineWidth=2.6;g.stroke();
 g.restore();
 fa4_tex(g,B,-66,84,-19,-3,5.6,'#137a76','#ffffff',.13);
 fkShade(g,B,-5,-20,'#05384a',.5);
 // a light dusting of snowflake flecks along the back
 g.save();B();g.clip();
 [[56,-12,2.4],[34,-14,2.8],[12,-13,2.3],[-10,-11,2.5],[-30,-8,2],[22,-9,1.6]].forEach((s,i)=>fa4_snow(g,s[0],s[1],s[2],i*.6+Math.sin(t*.9+i)*.2,'#ffffff',.7+.3*fa4_tw(t,i,2.2)));
 g.restore();
 fa4_speck(g,B,-60,90,-18,-6,18,'#ffffff',.55,.6,5);
 // sparkling silver lateral line, set high so the spine shows beneath it
 {const lc=s=>{const x=94-158*s;return [x,-4.6+2.6*s-Math.sin(Math.PI*s)*1.4]},LB=fa4_rib(44,s=>{const c=lc(s);return [c[0],c[1],2.5*Math.pow(Math.sin(Math.PI*(s*.92+.04)),.6)]});
  const P=()=>fkPath(g,LB),sx=Math.sin(t*1.2)*34;g.save();B();g.clip();
  g.save();P();g.clip();g.fillStyle=fa4_grad(g,-80+sx,0,100+sx,0,[[0,'#b8fff0'],[.25,'#8ef0ff'],[.45,'#ffffff'],[.62,'#c8b8ff'],[.8,'#9ee8ff'],[1,'#e8f4ff']]);g.fillRect(-80,-12,180,18);g.restore();
  P();g.strokeStyle='rgba(18,96,104,.45)';g.lineWidth=.8;g.stroke();
  g.beginPath();for(let i=0;i<=30;i++){const c=lc(.04+i/30*.86);i?g.lineTo(c[0],c[1]-.6):g.moveTo(c[0],c[1]-.6)}g.lineCap='round';g.strokeStyle='#ffffff';g.lineWidth=1;g.stroke();
  g.restore();
  for(let k=0;k<3;k++){const c=lc((.15+k*.3+t*.12)%1*.9+.03),w=fa4_tw(t,k*2.1,3.1);fkSpark(g,c[0],c[1]-.6,2.4+3.6*w,'#ffffff',.35+.65*w)}}
 fa4_rim(g,B,'#e4f4ff',null,1,1.6);
 fa4_gloss(g,B,86,-12,40,-19,-30,-13,1.6,.6);
 B();g.lineJoin='round';g.lineWidth=2.8;g.strokeStyle=FKO;g.stroke();
 fa4_gill2(g,B,94,1,21,Math.PI*.74,Math.PI*1.26,'#1a5664',.55);
 // pectoral: tucked just behind the gill arc
 fa4_at(g,67,7,-.3+fin,()=>{const P=()=>fa4_path(g,['M',3,-3.5,'Q',-8,-6.5,-21,.5,'Q',-18,4.6,-11,4.6,'Q',-4,4.6,3,3,'Z']);
  g.globalAlpha=.92;P();g.fillStyle=fa4_grad(g,0,-4,-20,4,[[0,'#ffffff'],[.5,'#cfe8ff'],[1,'#36c4ae']]);g.fill();g.globalAlpha=1;
  fa4_ribs(g,P,2,0,[-20,.6,-17,3.6,-12,4.6],.3,'#16706a',.9);fa4_rime(g,P,.7,2);
  g.save();P();g.clip();g.beginPath();g.moveTo(3,-3.5);g.quadraticCurveTo(-8,-6.5,-21,.5);g.strokeStyle='#ffffff';g.lineWidth=2.4;g.stroke();g.restore();
  P();g.lineJoin='round';g.lineWidth=2;g.strokeStyle=FKO;g.stroke()});
 // jutting lower jaw (a smelt's underbite)
 const J=()=>fa4_path(g,['M',92,6.4,'Q',104,6,110.5,3.6,'Q',115,2.8,114.2,5.8,'Q',112,9.6,104,10.6,'Q',97,11.4,91,10,'Z']);
 J();fkFill(g,fa4_grad(g,0,3,0,11,[[0,'#ffffff'],[.6,'#e2f8f4'],[1,'#acdcd4']]),2.1);
 fa4_eye(g,86,-3.5,9.6,'#1a9c8e',.35);fa4_lid(g,86,-3.5,9.6,fa4_blink(t,.9),'#27a294');
 fa4_blush(g,84,9,4.4,'#ff8ab8',.5);
 fa4_smile(g,110.5,4.2,104,7,98,6.4,1.8);g.beginPath();g.arc(97.4,4.6,1.8,Math.PI*.45,Math.PI*1.05);g.lineWidth=1.3;g.stroke();
 fa4_spec(g,60,-12,.7,.9);
 fkSpark(g,24,-13,3.6+fa4_tw(t,1,2.3)*2.2,'#ffffff',.5+.5*fa4_tw(t,1,2.3));
 fa4_catch(g,o,'#e0fff8');g.restore()};

/* ---------------- 2. Glacier Char (Uncommon): heavy-headed arctic char with a hooked kype, frost spots, crimson belly, white-edged fins, crystals on the ridge ---------------- */
FISHART.char=(g,t,o)=>{const sw=fkSway(o,3.4,.14),fin=Math.sin(t*4.2)*.1,gl=o.glow||0;g.save();g.rotate(-sw*.2);
 // cold breath of air around it
 if(g.canvas!==FKSIL)fkGlow(g,8,-4,114,'#6ad6ff',.13+.05*Math.sin(t*1.5)+gl*.3);
 // a deep, heavy head and a thick, square-cut tail base
 const BP=[108,4,104,-17,82,-34,44,-38,4,-36,-34,-25,-58,-15,-66,-12.5,-75,-11.5,-75,11.5,-66,12.5,-58,15,-34,22,4,33,44,36,82,31,102,18],B=()=>fkPath(g,BP);
 // the char's signature: a bold white stripe on the fin's leading edge LE, with a thin dark line behind it
 const lead=(P,LE,w)=>{g.save();P();g.clip();g.lineCap='round';g.lineJoin='round';
  fa4_path(g,LE);g.strokeStyle='rgba(27,16,36,.9)';g.lineWidth=w*2+3.4;g.stroke();
  fa4_path(g,LE);g.strokeStyle='#ffffff';g.lineWidth=w*2;g.stroke();
  fa4_path(g,LE);g.strokeStyle='rgba(196,236,255,.9)';g.lineWidth=w*.5;g.stroke();g.restore()};
 const red1='#ff9a4a',red2='#d8241a';
 const redFin=(pp,LE,rays,w,lw)=>{const P=()=>fa4_path(g,pp);P();fkFill(g,fa4_grad(g,0,-3,0,16,[[0,red1],[1,red2]]),lw||2.3);
  fa4_ribs(g,P,0,0,rays,.32,'#5a0a08',1);fa4_finfx(g,P,0,0,'#ffe0c0',null,.8,0);lead(P,LE,w||3.8);P();g.lineJoin='round';g.lineWidth=lw||2.3;g.strokeStyle=FKO;g.stroke()};
 // tail: broad, gently forked, rooted in a thick wrist; deep teal fading to an ember-orange lower lobe
 const T=()=>fa4_path(g,['M',14,-11,'Q',-6,-16,-20,-27,'Q',-30,-37,-44,-43,'Q',-42,-21,-35,0,'Q',-42,21,-44,43,'Q',-30,37,-20,27,'Q',-6,16,14,11,'Z']);
 fa4_at(g,-66,0,sw,()=>{T();fkFill(g,fa4_grad(g,0,-44,0,44,[[0,'#0d3a62'],[.4,'#1b6e92'],[.62,'#3a8ea8'],[.85,'#e85a2c'],[1,'#ff8a46']]),2.6);
  fa4_ribs(g,T,8,0,[-44,-40,-40,-26,-36,-12,-36,12,-40,26,-44,40],.3,'#061e36');
  fa4_finfx(g,T,10,0,'#c8f0ff',[-44,-34,-38,-18,-35,-4,-35,6,-38,18,-44,34],.7,0);
  g.save();T();g.clip();g.fillStyle='rgba(238,250,255,.9)';[[-26,-22,2.2],[-34,-30,1.8],[-18,-12,1.7],[-30,-6,1.6],[-38,-16,1.6]].forEach(s=>{g.beginPath();g.arc(s[0],s[1],s[2],0,TAU);g.fill()});g.restore();
  lead(T,['M',-20,27,'Q',-30,37,-44,43],2.6);
  fa4_rim(g,T,'#bff0ff',null,1,1.6);T();g.lineJoin='round';g.lineWidth=2.6;g.strokeStyle=FKO;g.stroke()});
 // dorsal: deep teal with frost spots and a frosted rim; three sharp crystals grow from its top edge (roots tucked behind the fin)
 const DP=[16,2,10,-12,0,-24,-10,-27,-20,-21,-26,-6,-24,4];
 fa4_at(g,8,-32,fin*.4,()=>{const P=()=>fkPath(g,DP);
  fa4_icicle(g,3,-15,-1.42,14,5);fa4_icicle(g,-5,-21.5,-1.74,16.5,5.6);fa4_icicle(g,-14,-20,-2.06,13,4.8);
  fkFin(g,DP,'#2c8cae','#0c3a62',[[10,0,0,-22],[2,0,-8,-24],[-6,0,-16,-20],[-14,0,-22,-8]],2.4);
  fa4_finfx(g,P,0,2,'#c8f0ff',null,.7,0);g.save();P();g.clip();g.fillStyle='rgba(238,250,255,.92)';[[4,-12,2],[-8,-16,1.8],[-16,-8,1.6],[-2,-4,1.5]].forEach(s=>{g.beginPath();g.arc(s[0],s[1],s[2],0,TAU);g.fill()});g.restore();
  fa4_rime(g,P,.8,2.8);P();g.lineJoin='round';g.lineWidth=2.4;g.strokeStyle=FKO;g.stroke()});
 // adipose
 fa4_at(g,-48,-16,fin*.3,()=>{const pp=[5,2,2,-6,-5,-8,-9,1],P=()=>fkPath(g,pp);fkFin(g,pp,'#2a88aa','#0e4068',null,2.1);fa4_rime(g,P,.6,2.2);P();g.lineWidth=2.1;g.strokeStyle=FKO;g.stroke()});
 // more crystals growing out of the dorsal ridge, in front of and behind the dorsal fin (roots hidden by the body)
 fa4_icicle(g,56,-33.5,-1.6,15,5.2);fa4_icicle(g,40,-34.8,-1.8,13,4.8);fa4_icicle(g,-27,-23.8,-2,13,4.8);
 // anal + pelvic: ember-red with bold white leading edges
 fa4_at(g,-34,21,-fin*.6,()=>redFin(['M',10,-3,'Q',9,7,3,16,'Q',-6,19,-15,15,'Q',-20,9,-18,-3,'Z'],['M',10,-3,'Q',9,7,3,16],[3,15,-5,17,-13,14,-17,6]));
 fa4_at(g,12,31,-fin,()=>redFin(['M',8,-3,'Q',7,6,1,13,'Q',-7,15,-13,10,'Q',-15,4,-13,-3,'Z'],['M',8,-3,'Q',7,6,1,13],[1,12,-6,13,-12,8]));
 // body: deep teal-blue back, a pale silvery waist, vivid crimson-orange belly
 B();fkFill(g,fa4_grad(g,0,-38,0,36,[[0,'#08284a'],[.2,'#114f7c'],[.38,'#2290ac'],[.5,'#78ccc8'],[.58,'#ffc89e'],[.7,'#ff7c3c'],[.86,'#ee4426'],[1,'#c82a1a']]),3);
 fa4_mottle(g,B,[[40,-18,30,'#3ad8e8',.22],[-26,-10,26,'#3a6ad8',.2],[30,22,26,'#ffd060',.22],[-20,16,20,'#ff3a50',.2]]);
 fa4_tex(g,B,-72,80,-36,34,5,'#06243e','#e0faff',.05);
 fkShade(g,B,-8,-38,'#041a36',.42);
 // pale frost spots on the back, a few rosy ones along the belly
 g.save();B();g.clip();
 const FS=[[56,-22,3.6],[38,-27,3],[20,-20,3.8],[2,-26,3.2],[-16,-18,3.6],[-34,-14,3],[-52,-6,2.6],[30,-12,2.6],[10,-9,2.4],[-6,-10,2.6],[-24,-4,2.2],[48,-6,2.2],[-62,-1,2]];
 FS.forEach(([x,y,r],i)=>{g.fillStyle=fa4_rgrad(g,x,y,0,r*2.2,[[0,'rgba(170,236,255,.35)'],[1,'rgba(170,236,255,0)']]);g.fillRect(x-r*2.2,y-r*2.2,r*4.4,r*4.4);
  g.beginPath();g.arc(x,y,r,0,TAU);g.fillStyle=fa4_rgrad(g,x-r*.3,y-r*.3,0,r,[[0,'#ffffff'],[.7,'#e4f8ff'],[1,'#b4e4f4']]);g.fill();g.lineWidth=.9;g.strokeStyle='rgba(6,40,70,.35)';g.stroke()});
 [[34,8,2.4],[14,14,2],[-8,10,2.2],[-28,8,1.8],[44,14,1.8]].forEach(([x,y,r])=>{g.beginPath();g.arc(x,y,r,0,TAU);g.fillStyle='#ffd8c4';g.fill();g.lineWidth=.8;g.strokeStyle='rgba(150,30,20,.45)';g.stroke()});
 // cold sheen: an icy rim-light hugging the whole back line
 g.translate(0,2.4);B();g.strokeStyle=fa4_grad(g,0,-40,0,-16,[[0,'rgba(214,250,255,.95)'],[1,'rgba(214,250,255,0)']]);g.lineWidth=3.2;g.stroke();g.translate(0,-2.4);
 g.restore();
 fkShade(g,B,18,36,'#8a1010',.3);
 fa4_sheen(g,B,t,30,'#e4fbff',.26);
 fa4_rim(g,B,'#c8f4ff','#ffc0a0',1,2);
 fa4_gloss(g,B,86,-23,44,-35,-24,-29,3,.7);
 fa4_gill2(g,B,90,3,32,Math.PI*.74,Math.PI*1.26,'#06223e',.6);
 fa4_spec(g,48,-27,.9,.95);
 // pectoral: a tapered ember-red blade with the white leading edge, set behind the gill
 fa4_at(g,56,14,-.5+fin,()=>{const pp=['M',3,-5,'Q',-12,-9,-30,0,'Q',-29,7,-20,10,'Q',-8,10,3,5,'Z'],P=()=>fa4_path(g,pp);
  P();fkFill(g,fa4_grad(g,0,-6,-24,6,[[0,'#ffb070'],[.5,red1],[1,red2]]),2.2);fa4_ribs(g,P,2,0,[-29,2,-26,6.5,-20,9.5,-12,9.6,-5,7.6],.36,'#5a0a08',1);fa4_finfx(g,P,0,0,'#ffe0c0',null,.7,0);
  lead(P,['M',3,-5,'Q',-12,-9,-30,0],3.2);P();g.lineJoin='round';g.lineWidth=2.2;g.strokeStyle=FKO;g.stroke()});
 // hooked kype: the lower jaw juts forward and curls up in front of the snout
 const J=()=>fa4_path(g,['M',86,12,'Q',99,11.5,105.5,8.4,'Q',109.4,6.4,109.6,3,'Q',112.6,5.6,111.6,10,'Q',108.6,16.6,99,19.4,'Q',91,21,84,18,'Z']);
 J();fkFill(g,fa4_grad(g,0,1,0,20,[[0,'#ffd6b8'],[.45,'#ff9a68'],[1,'#e2522e']]),2.4);
 g.save();J();g.clip();g.beginPath();g.moveTo(88,13.6);g.quadraticCurveTo(100,13.2,108,8.4);g.strokeStyle='rgba(255,255,255,.55)';g.lineWidth=1.4;g.stroke();g.restore();
 fa4_eye(g,80,-12,11.5,'#e8a030',.3);fa4_lid(g,80,-12,11.5,fa4_blink(t,3.1),'#145a86');
 fa4_blush(g,92,5,6,'#ff7a6a',.5);
 // a determined little smile along the top of the hooked jaw
 fa4_smile(g,107,8,99,11.8,90,11.2,2.2);g.beginPath();g.arc(89.2,9.2,2,Math.PI*.45,Math.PI*1.05);g.lineWidth=1.4;g.stroke();
 // frost motes drifting up through the cold glow
 for(let i=0;i<5;i++){const p=((t*.2+i/5)%1),x=-70+i*36+Math.sin(t*1.2+i*2)*7,y=38-p*96;fkSpark(g,x,y,(2.4+i%3)*(1-Math.abs(p-.5)*1.4),'#e4f8ff',(1-Math.abs(p*2-1))*.85)}
 // glints on the crystal tips
 [[56,-49],[3,-65],[-32,-37]].forEach(([x,y],i)=>{const w=fa4_tw(t,i*2.3,2.4);fkSpark(g,x,y,2.4+3.4*w,'#ffffff',.3+.7*w)});
 fa4_catch(g,o,'#d8f6ff');g.restore()};

/* ---------------- 3. Icewing Flyfish (Rare): a flying fish on enormous wings of cut, living ice ---------------- */
/* faceted crystal wing hinged at (0,0): tips = ray tips [x,y,...] from the leading edge round to the trailing edge.
   Two jittered rings cut every sector between the spars into angular shard facets, alternately lit and shadowed, with bright
   facet-edge highlights and a refraction band along the sawtooth trailing edge. sc squashes it vertically (flap), ph offsets
   the shimmer, al = opacity, dark = deeper far-side tint, icy = cool white/cyan refraction instead of a rainbow. Returns the tips. */
function fa4_wing(g,tips,sc,t,ph,al,dark,lw,icy){const T=[];for(let i=0;i<tips.length;i+=2)T.push([tips[i],tips[i+1]*sc]);
 const n=T.length,E=[],p=[4,-3];
 for(let i=0;i<n;i++){E.push(T[i]);if(i<n-1){const k=.12;E.push([(T[i][0]+T[i+1][0])/2*(1-k),(T[i][1]+T[i+1][1])/2*(1-k)])}}
 for(const q of E)p.push(q[0],q[1]);p.push(4,3);
 const P=()=>fa4_poly(g,p);let R=0;for(const q of T)R=Math.max(R,Math.hypot(q[0],q[1]));const a0=T[0],a1=T[n-1],m=E.length;
 g.save();g.globalAlpha=al;g.lineJoin='round';
 P();g.fillStyle=fa4_grad(g,0,0,a0[0],a0[1],dark?[[0,'rgba(18,44,140,.84)'],[.6,'rgba(40,90,196,.76)'],[1,'rgba(96,156,236,.82)']]:[[0,'rgba(90,190,255,.5)'],[.55,'rgba(165,226,255,.48)'],[1,'rgba(235,250,255,.74)']]);g.fill();
 g.save();P();g.clip();
 // chunky shard facets: the sector between two neighbouring spars is cut by two jittered rings into a few big angular cells
 const N=[];for(let i=0;i<n-1;i++)N.push(E[i*2+1]);
 const f1=i=>.34+.12*((i*7)%3-1),f2=i=>.66+.1*((i*5)%3-1),I1=T.map((q,i)=>[q[0]*f1(i),q[1]*f1(i)]),I2=T.map((q,i)=>[q[0]*f2(i),q[1]*f2(i)]);
 const tri=(A,B,C,lit,k)=>{g.beginPath();g.moveTo(A[0],A[1]);g.lineTo(B[0],B[1]);g.lineTo(C[0],C[1]);g.closePath();
  g.fillStyle=lit?`rgba(255,255,255,${.1+.42*k})`:(dark?`rgba(12,30,120,${.22+.2*(1-k)})`:`rgba(24,84,190,${.16+.26*(1-k)})`);g.fill()};
 const ED=[];
 for(let i=0;i<n-1;i++){const s=t*2.3-i*.9+ph,k=.5+.5*Math.sin(s),k2=.5+.5*Math.sin(s+1.4),k3=.5+.5*Math.sin(s+2.6),o=i%2,A1=I1[i],B1=I1[i+1],A2=I2[i],B2=I2[i+1],Ti=T[i],Tj=T[i+1],Ni=N[i];
  tri([0,0],A1,B1,o,k);
  if(o){tri(A1,A2,B2,1,k2);tri(A1,B2,B1,0,k2);ED.push([A1,B2])}else{tri(A1,A2,B1,0,k2);tri(A2,B2,B1,1,k2);ED.push([A2,B1])}
  tri(A2,Ti,Ni,!o,k3);tri(A2,Ni,B2,o,k3*.85);tri(B2,Ni,Tj,!o,k3*.7);ED.push([A2,Ni],[B2,Ni],[A1,B1],[A2,B2])}
 // bright facet edges
 g.beginPath();for(const e of ED){g.moveTo(e[0][0],e[0][1]);g.lineTo(e[1][0],e[1][1])}g.strokeStyle='rgba(255,255,255,.8)';g.lineWidth=1.15;g.lineCap='round';g.lineJoin='round';g.stroke();
 // the spars: brighter, with a faint shadow side
 g.beginPath();for(const q of T){g.moveTo(1,1.4);g.lineTo(q[0]+1,q[1]+1.4)}g.strokeStyle=dark?'rgba(10,30,100,.32)':'rgba(30,70,170,.3)';g.lineWidth=1.5;g.stroke();
 g.beginPath();for(const q of T){g.moveTo(0,0);g.lineTo(q[0]*.98,q[1]*.98)}g.strokeStyle='rgba(255,255,255,.9)';g.lineWidth=1.4;g.stroke();
 // frosted outer band
 g.fillStyle=fa4_rgrad(g,0,0,0,R,[[0,'rgba(255,255,255,0)'],[.62,'rgba(255,255,255,0)'],[.86,'rgba(240,250,255,.16)'],[1,'rgba(255,255,255,.42)']]);g.fillRect(-R-10,-R-10,R*2+20,R*2+20);
 // refraction band along the sawtooth trailing edge, its colours sliding slowly
 g.beginPath();g.moveTo(E[0][0],E[0][1]);for(const q of E)g.lineTo(q[0],q[1]);
 const sl=Math.sin(t*.8+ph)*.06;g.strokeStyle=fa4_grad(g,a0[0],a0[1],a1[0],a1[1],icy?[[0,'#ffffff'],[.3,'#bff4ff'],[.6,'#7ad8ff'],[.85,'#d8f0ff'],[1,'#ffffff']]:
  [[0,'#b8a4ff'],[.16+sl,'#ff9ad8'],[.32+sl,'#fff0a0'],[.5+sl,'#a8ffd0'],[.68+sl,'#7ae8ff'],[.86,'#9ab8ff'],[1,'#d8b4ff']]);
 g.lineWidth=10;g.globalAlpha=al*.9;g.stroke();g.globalAlpha=al;g.strokeStyle='rgba(255,255,255,.95)';g.lineWidth=2.2;g.stroke();
 // leading-edge spar: a thick glassy rod
 g.beginPath();g.moveTo(2,-2.4);g.lineTo(a0[0]*.98,a0[1]*.98);g.strokeStyle='rgba(255,255,255,.95)';g.lineWidth=4.6;g.stroke();g.strokeStyle='rgba(140,230,255,.95)';g.lineWidth=1.6;g.stroke();
 g.fillStyle=fa4_rgrad(g,0,0,0,22,[[0,'rgba(16,26,80,.4)'],[1,'rgba(16,26,80,0)']]);g.fillRect(-24,-24,48,48);
 g.restore();
 P();g.lineWidth=lw||2.5;g.strokeStyle=FKO;g.stroke();g.restore();return T}

FISHART.flyfish=(g,t,o)=>{const fx=o.flex||0,gl=o.glow||0,sw=fkSway(o,4.4,.11),fp=t*(2.1+fx*2.4),pu=.5+.5*Math.sin(t*2);g.save();g.translate(0,6);g.rotate(-sw*.16);
 // frost aura: a pale-cyan halo hugging the fish, ringed by slowly orbiting frost motes
 g.save();g.translate(-6,-16);g.scale(1,.66);g.fillStyle=fa4_rgrad(g,0,0,20,116,[[0,'rgba(176,238,255,.2)'],[.55,'rgba(150,228,255,.15)'],[.82,'rgba(150,228,255,.07)'],[1,'rgba(150,228,255,0)']]);if(g.canvas!==FKSIL){g.beginPath();g.arc(0,0,116,0,TAU);g.fill()}g.restore();
 if(g.canvas!==FKSIL)fkGlow(g,-8,-18,108,'#8ae4ff',.17+.07*pu+gl*.3);
 for(let i=0;i<12;i++){const a=t*.22+i/12*TAU,x=-6+Math.cos(a)*104,y=-16+Math.sin(a)*60,w=fa4_tw(t,i*1.3,2.6);if(x<-113||x>113)continue;
  g.beginPath();g.arc(x,y,.9+.9*w,0,TAU);g.fillStyle=i%3?'#d8f6ff':'#ffffff';g.globalAlpha=.3+.5*w;g.fill();g.globalAlpha=1}
 const BP=[110,2,103,-9,82,-17,46,-21,6,-19,-32,-12,-56,-6,-67,-3.5,-67,4,-56,7,-32,12,6,17,46,19,82,14,103,8],B=()=>fkPath(g,BP);
 const WT=[-74,-66,-95,-69,-110,-59,-117,-44,-114,-29,-103,-17,-86,-8,-64,-2,-40,3];
 const PT=[-30,14,-44,21,-52,16,-48,7,-34,1];
 const fl1=Math.sin(fp),fl2=Math.sin(fp-.45),fa=1+fx*.8;
 // far wing: rooted at the same pectoral point behind the body, raised higher, darker and partly hidden
 fa4_at(g,54,-3,.62+fl2*.07*fa,()=>{g.scale(.76,.76);fa4_wing(g,WT,.9+.12*fl2*fa,t,1.4,.9,1,3.1)});
 // far pelvic wing
 fa4_at(g,-14,8,-.05-fl2*.04,()=>{g.scale(.78,.78);fa4_wing(g,PT,1,t,2.4,.82,1,3,1)});
 // tail: forked with the long lower lobe of a flying fish
 const T=()=>fa4_path(g,['M',12,-4,'Q',-4,-6,-16,-14,'Q',-28,-25,-42,-34,'Q',-39,-20,-31,-6,'Q',-28,0,-31,6,'Q',-40,24,-52,43,'Q',-32,33,-16,14,'Q',-4,6,12,4,'Z']);
 fa4_at(g,-62,0,sw,()=>{T();fkFill(g,fa4_grad(g,8,0,-54,0,[[0,'#c4e8ff'],[.5,'#6eaef2'],[1,'#2a50c0']]),2.5);
  fa4_ribs(g,T,8,0,[-41,-31,-36,-20,-30,-8,-32,10,-42,26,-50,40],.24,'#14307a');
  fa4_finfx(g,T,10,0,'#ffffff',[-42,-28,-34,-15,-29,-4,-32,8,-40,22,-48,36],.85,0);
  g.save();T();g.clip();g.globalAlpha=.85;g.strokeStyle=fa4_grad(g,-52,43,-42,-34,[[0,'#ffffff'],[.35,'#8ae8ff'],[.7,'#c8e4ff'],[1,'#ffffff']]);g.lineWidth=6;T();g.stroke();g.restore();
  fa4_rime(g,T,.7,2.2);fa4_rim(g,T,'#ffffff',null,1,1.5);T();g.lineJoin='round';g.lineWidth=2.5;g.strokeStyle=FKO;g.stroke()});
 // small dorsal + anal fins set far back, as on a real flying fish
 fa4_at(g,-46,-7,fl1*.06,()=>fa4_frostFin(g,[8,0,2,-8,-6,-12,-12,-9,-12,1],0,0,'#ffffff','#5a98ec',[[2,0,-5,-10],[-4,0,-10,-9]],2.2,.95));
 fa4_at(g,-44,8,-fl1*.06,()=>fa4_frostFin(g,[8,-1,3,7,-5,10,-12,7,-12,-1],0,0,'#ffffff','#5a98ec',[[2,0,-5,9]],2.1,.95));
 // body: a crisp dark-blue back over a silver mirror band and a pearly belly
 B();fkFill(g,fa4_grad(g,0,-21,0,19,[[0,'#071248'],[.2,'#0e2468'],[.35,'#1a44a0'],[.41,'#cfe4ff'],[.6,'#f6faff'],[.66,'#dde8fb'],[.86,'#eef3ff'],[1,'#b6c6ee']]),3);
 g.save();B();g.clip();const sh=Math.sin(t*1.3)*36;g.globalAlpha=.13;g.fillStyle=fa4_grad(g,-70+sh,-15,90+sh,15,[[0,'#7ae8ff'],[.3,'#c8a8ff'],[.55,'#a8f0ff'],[.8,'#e0f4ff'],[1,'#c8a8ff']]);g.fillRect(-80,-24,200,48);g.globalAlpha=1;g.restore();
 fa4_tex(g,B,-66,84,-20,-6,5.6,'#3a5ac0','#ffffff',.14);
 fa4_tex(g,B,-66,84,6,18,5.6,'#6a7ab8','#ffffff',.1);
 fkShade(g,B,-4,-22,'#040c40',.45);
 fa4_speck(g,B,-66,96,-19,-8,30,'#e8f8ff',.6,.6,3);
 // silver mirror band with a sliding reflection and a crisp dark edge where it meets the back
 {const mb=s=>{const x=98-164*s;return [x,-1.6+2.6*s-Math.sin(Math.PI*s)*1.4,5.4*Math.pow(Math.sin(Math.PI*(s*.94+.03)),.55)]},MB=fa4_rib(44,mb),P=()=>fkPath(g,MB),sx=Math.sin(t*1.1)*40;
  g.save();B();g.clip();g.save();P();g.clip();g.fillStyle=fa4_grad(g,-80+sx,0,100+sx,0,[[0,'#c0d4f4'],[.2,'#ffffff'],[.34,'#9cb8e6'],[.5,'#f4fbff'],[.62,'#b4ecff'],[.78,'#ffffff'],[1,'#bccdf2']]);g.fillRect(-80,-14,190,26);
  g.fillStyle=fa4_grad(g,0,-7,0,5,[[0,'rgba(255,255,255,.7)'],[.45,'rgba(255,255,255,0)'],[1,'rgba(30,60,150,.3)']]);g.fillRect(-80,-14,190,26);g.restore();
  P();g.strokeStyle='rgba(10,24,90,.5)';g.lineWidth=1;g.stroke();
  g.beginPath();for(let i=0;i<=30;i++){const c=mb(.05+i/30*.86);i?g.lineTo(c[0],c[1]-1.6):g.moveTo(c[0],c[1]-1.6)}g.lineCap='round';g.strokeStyle='#ffffff';g.lineWidth=1.3;g.stroke();g.restore();
  for(let k=0;k<2;k++){const c=mb((.2+k*.45+t*.1)%1*.9+.04),w=fa4_tw(t,k*2.6,2.8);fkSpark(g,c[0],c[1]-1.4,2.6+3.6*w,'#ffffff',.35+.65*w)}}
 fkShade(g,B,9,20,'#8aa4ec',.26);
 fa4_rim(g,B,'#9ad8ff','#c0d4ff',1,1.7);
 fa4_gloss(g,B,90,-12,52,-20,20,-19,1.8,.6);
 fa4_gill2(g,B,94,1,20,Math.PI*.72,Math.PI*1.28,'#162a70',.55);
 // near pelvic wing (icy)
 fa4_at(g,-10,13,.04+fl2*.05,()=>{g.scale(.9,.9);fa4_wing(g,PT,1,t,.4,.96,0,2.8,1)});
 fa4_eye(g,80,-5,11.5,'#2a86e8',.35);fa4_lid(g,80,-5,11.5,fa4_blink(t,1.4),'#163a9a');
 fa4_blush(g,91,8,5.5,'#9ad8ff',.5);
 fa4_mouth(g,106,4,101,8,95,6,2,'#a8c4ff');
 // near wing: the enormous crystal pectoral, rooted just behind the gill at the body's midline, sweeping back and up
 const sc=.88+.14*fl1*fa,wa=-fl1*.06*fa;
 fa4_at(g,60,2,.15+wa,()=>{const T2=fa4_wing(g,WT,sc,t,0,.93,0,2.6);
  g.beginPath();g.ellipse(-1,.5,4.6,3.4,-.35,0,TAU);fkFill(g,fa4_grad(g,0,-4,0,5,[[0,'#ffffff'],[.6,'#bfe2ff'],[1,'#6a9ae4']]),2);g.beginPath();g.ellipse(-3,-1,2.6,1.1,-.35,0,TAU);g.fillStyle='rgba(255,255,255,.8)';g.fill();
  fkGlow(g,-70,-38*sc,40,'#c8f0ff',.14+.12*pu+gl*.12);
  [[0,0],[2,1.6],[4,3.1],[6,4.5]].forEach(([i,ph])=>{const w=fa4_tw(t,ph,2.6),q=T2[i];fkSpark(g,q[0]*.96,q[1]*.96,2.6+4.4*w,'#ffffff',.35+.65*w)})});
 // glitter trail: a cascade of tiny sparkles peeling off the tail fork and lobes and streaming back
 fkGlow(g,-98,14,30,'#bff4ff',.16+.08*pu+gl*.2);
 for(let i=0;i<24;i++){const p=((t*.55+i/24)%1),u=((i*7)%24)/23,ex=u<.42?-104+u/.42*11:-93-(u-.42)/.58*21,ey=u<.42?-28+u/.42*30:2+(u-.42)/.58*44,
  x=ex-p*(10+(i%3)*4)+Math.sin(t*2+i)*1.5,y=ey+p*(14+(i%4)*4),s=(1-p*.6)*(1.6+(i%3)*1.1),c=['#ffffff','#bff4ff','#e4f0ff'][i%3];
  if(x<-114||y>74)continue;if(i%2)fkSpark(g,x,y,s*1.7,c,(1-p)*.95);else{g.beginPath();g.arc(x,y,s*.55,0,TAU);g.fillStyle=c;g.globalAlpha=(1-p)*.9;g.fill();g.globalAlpha=1}}
 // tiny snowflakes drifting in the frost aura
 for(let k=0;k<3;k++){const w=fa4_tw(t,k*2.2+.7,1.9),x=[-24,92,-100][k]+Math.sin(t*.7+k)*4,y=[-80,-46,-48][k]+Math.cos(t*.6+k*2)*3;fa4_snow(g,x,y,3+1.4*w,t*.4+k,'#e8f8ff',.45+.45*w)}
 [[100,-30,5,'#ffffff'],[48,-74,4,'#e8f8ff'],[100,30,3.5,'#ffffff'],[14,44,4,'#bff4ff']].forEach(([x,y,r,c],i)=>{const k=fa4_tw(t,i*1.7,2.3);fkSpark(g,x,y+Math.sin(t+i)*2,r*(.6+.5*k)*(1+gl*.4),c,.35+.6*k)});
 fa4_catch(g,o,'#d8f4ff',1.3);g.restore()};

/* update 7: nudge these fish fully inside the -115..115 / -80..80 frame (dorsal tips, crown or tail tips poked past it and were clipped in tight thumbnails) */
(()=>{const M={flyfish:[0,7,0.96]};for(const id in M){const f=FISHART[id],[x,y,k]=M[id];if(f)FISHART[id]=(g,t,o)=>{g.save();g.translate(x,y);g.scale(k,k);f(g,t,o);g.restore()}}})();
/* update 7: when drawn as an undiscovered silhouette (o.sil), these fish skip additive light (auras, glows, rays), so the
   journal shows a clean solid outline instead of a hazy blob. Normal drawing is untouched. */
(()=>{const P=new WeakMap(),wrap=c=>{let p=P.get(c);if(!p){const F=new Map();p=new Proxy(c,{get(t,k){const v=t[k];if(typeof v!=='function')return v;let f=F.get(k);
  if(!f){f=(k==='fill'||k==='fillRect'||k==='stroke'||k==='strokeRect'||k==='drawImage')?function(){if(t.globalCompositeOperation==='lighter')return;return v.apply(t,arguments)}:v.bind(t);F.set(k,f)}return f},
  set(t,k,v){t[k]=v;return true}});P.set(c,p)}return p};
 ['smelt','char','flyfish'].forEach(id=>{const f=FISHART[id];if(f)FISHART[id]=(g,t,o)=>f(typeof FKSIL!=='undefined'&&FKSIL&&g.canvas===FKSIL?wrap(g):g,t,o)})})();
