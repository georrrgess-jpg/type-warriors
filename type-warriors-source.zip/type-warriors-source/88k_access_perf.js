/* ===== TEXT VISIBILITY and PERFORMANCE MODE (Settings > Display) =====
   Text visibility: Clear brightens faded menu text (lavender and grey) toward white while gold and rarity colours stay vivid,
   makes small text bolder and puts a crisp dark edge under light text. Dark text on gold buttons is left alone.
   It works by reading the game's own style rules once and writing stronger copies of the faint ones, so every menu is covered
   without touching layouts. The copies are wrapped in :where() so they carry exactly the original weight: they beat the
   faint base rule but never a more specific state such as a selected tab or a hovered button. It only styles menus; gameplay is untouched.
   Performance mode (measured: the game canvas is fill-bound, and its full-screen background and vignette are the big costs):
     Quality      as before.
     Balanced     resolution at most 1x; the background is redrawn every 2nd frame and the vignette is pre-rendered.
     Performance  resolution 0.75x; background every 4th frame; no decorative edge vignette; menu canvases at half rate;
                  looping menu CSS animations rest; canvas shadow blur is skipped.
   The background is never cached while the screen shakes or a boss cutscene zooms, so motion stays correct.
   If the game runs slowly in Quality mode, it offers Performance mode once. Settings live in ST.tvis and ST.perf. */
Object.assign(defST,{tvis:'off',perf:'high'});if(ST.tvis==null)ST.tvis='off';if(ST.perf==null)ST.perf='high';
/* PFSET is the saved choice; PFM is what runs right now. The Casino always runs at Quality (see 88l_perf_casino.js). */
const PFSET=()=>ST.perf==='low'?'low':ST.perf==='bal'?'bal':'high';
const PFM=()=>pfCas()?'high':PFSET();

/* ---------- resolution ---------- */
{const a0=applyLayout;applyLayout=function(){const r=a0.apply(this,arguments);try{const m=PFM();let rs=RS;if(m==='bal'&&rs>1)rs=1;if(m==='low')rs=.75;
 if(rs!==RS){RS=rs;const nw=Math.round(W*RS),nh=Math.round(H*RS);if(cv.width!==nw||cv.height!==nh){cv.width=nw;cv.height=nh}}pfApply()}catch(e){}return r}}

/* ---------- background cache ---------- */
const PFBG={c:null,g:null,n:0,key:'',ok:false};
{const b0=drawBG;drawBG=function(){const m=PFM();if(m==='high')return b0.apply(this,arguments);
 const every=m==='low'?4:2,moving=(S.shake>0&&ST.shake)||(typeof cineZoom==='function'&&cineZoom());
 const key=[S.mode,S.view,S.wave,S.camp,HOME?1:0,S.dc?1:0,S.gy?1:0,S.rift?1:0,S.cr2?1:0,cv.width,cv.height].join('|');
 if(moving){PFBG.ok=false;return b0.apply(this,arguments)}
 if(!PFBG.c||PFBG.c.width!==cv.width||PFBG.c.height!==cv.height){PFBG.c=document.createElement('canvas');PFBG.c.width=cv.width;PFBG.c.height=cv.height;PFBG.g=PFBG.c.getContext('2d');PFBG.ok=false}
 if(!PFBG.ok||key!==PFBG.key||(PFBG.n++%every)===0){const r=b0.apply(this,arguments);try{PFBG.g.globalCompositeOperation='copy';PFBG.g.drawImage(cv,0,0);PFBG.g.globalCompositeOperation='source-over';PFBG.ok=true;PFBG.key=key}catch(e){PFBG.ok=false}return r}
 ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';ctx.filter='none';ctx.drawImage(PFBG.c,0,0);ctx.restore()}}

/* ---------- vignette, pre-rendered ---------- */
const PFV={c:null};
{const v0=vignette;vignette=function(){const m=PFM();if(m==='high')return v0.apply(this,arguments);if(m==='low')return;/* the soft edge darkening is purely decorative and costs a full-screen pass */
 if(!PFV.c){PFV.c=document.createElement('canvas');PFV.c.width=W/2;PFV.c.height=H/2;const g=PFV.c.getContext('2d'),q=g.createRadialGradient(W/4,H/4,H*.275,W/4,H/4,H*.54);q.addColorStop(0,'#0000');q.addColorStop(1,'#00000088');g.fillStyle=q;g.fillRect(0,0,W/2,H/2)}
 ctx.drawImage(PFV.c,0,0,W,H)}}

/* ---------- menu canvases at half rate ---------- */
{let k=0;const r0=runLive;runLive=function(t){if(PFM()==='low'&&(k^=1))return;return r0.apply(this,arguments)}}

/* ---------- no canvas shadow blur in Performance (the hook exists only while Performance is on, so Quality runs untouched) ---------- */
const PFS={d:null,on:false};
function pfShadow(on){try{const P2=CanvasRenderingContext2D.prototype;if(!PFS.d)PFS.d=Object.getOwnPropertyDescriptor(P2,'shadowBlur');const d=PFS.d;if(!d||!d.set||on===PFS.on)return;PFS.on=on;
 if(on)Object.defineProperty(P2,'shadowBlur',{configurable:true,enumerable:d.enumerable,get(){return d.get.call(this)},set(){d.set.call(this,0)}});else Object.defineProperty(P2,'shadowBlur',d)}catch(e){}}

/* ---------- looping CSS animations rest in Performance ---------- */
const PFA={paused:new Set(),tm:0};
function pfAnims(){try{if(PFM()!=='low'){for(const a of PFA.paused)try{a.play()}catch(e){}PFA.paused.clear();return}
 for(const a of document.getAnimations())if(a.playState==='running'&&a.effect&&a.effect.getTiming().iterations===Infinity&&a.constructor&&a.constructor.name==='CSSAnimation'){a.pause();PFA.paused.add(a)}
 for(const a of PFA.paused)if(!a.effect||!a.effect.target||!a.effect.target.isConnected)PFA.paused.delete(a)}catch(e){}}
function pfApply(){const m=PFM();pfShadow(m==='low');document.body.classList.toggle('pf-low',m==='low');document.body.classList.toggle('pf-bal',m==='bal');
 clearInterval(PFA.tm);PFA.tm=0;if(m==='low'){pfAnims();PFA.tm=setInterval(pfAnims,1200)}else pfAnims();
 document.body.classList.toggle('tv',ST.tvis==='on');if(ST.tvis==='on')tvBuild()}

/* ---------- text visibility: stronger copies of the faint text rules ---------- */
const TVX={done:0,el:null,cv:null};
function tvParse(v){if(!v||/var\(|inherit|initial|unset|currentcolor|transparent/i.test(v))return null;const g=TVX.cv||(TVX.cv=document.createElement('canvas').getContext('2d'));g.fillStyle='#010203';g.fillStyle=v;const s=g.fillStyle;if(s==='#010203'&&!/^#010203$/i.test(v.trim()))return null;
 let r,gr,b,a=1;if(s[0]==='#'){r=parseInt(s.slice(1,3),16);gr=parseInt(s.slice(3,5),16);b=parseInt(s.slice(5,7),16)}else{const m=s.match(/[\d.]+/g);if(!m)return null;[r,gr,b]=m.map(Number);a=m[3]!=null?+m[3]:1}return{r,g:gr,b,a}}
const tvLum=({r,g,b})=>{const f=x=>{x/=255;return x<=.03928?x/12.92:Math.pow((x+.055)/1.055,2.4)};return .2126*f(r)+.7152*f(g)+.0722*f(b)};
const tvSat=({r,g,b})=>{const mx=Math.max(r,g,b)/255,mn=Math.min(r,g,b)/255,l=(mx+mn)/2;return mx===mn?0:(mx-mn)/(1-Math.abs(2*l-1))};
/* returns a stronger colour, null if the colour is fine as it is, or 'dark' for dark text */
function tvBoost(v){const c=tvParse(v);if(!c)return null;const L=tvLum(c);if(L<.12&&c.a>.5)return'dark';if(c.a<.25)return null;
 const vivid=tvSat(c)>.6&&L>.3;if(L>.82&&c.a>=.9)return null;let{r,g,b}=c,a=Math.max(c.a,.96);
 if(!vivid){const t=L<.3?.75:L<.55?.65:.5;r+=(255-r)*t;g+=(255-g)*t;b+=(255-b)*t}else if(c.a>=.9)return null;
 return`rgba(${r|0},${g|0},${b|0},${a})`}
function tvSplit(sel){const out=[];let d=0,cur='';for(const ch of sel){if(ch==='('||ch==='[')d++;else if(ch===')'||ch===']')d--;if(ch===','&&d===0){out.push(cur);cur=''}else cur+=ch}out.push(cur);return out.map(s=>s.trim()).filter(Boolean)}
function tvBuild(){if(TVX.done)return;TVX.done=1;const rules=[];
 const walk=list=>{for(const R of list){if(R.cssRules&&!R.selectorText){if(R.media&&!/prefers-reduced-motion/.test(R.media.mediaText))walk(R.cssRules);continue}if(!R.selectorText||!R.style)continue;
  const st=R.style,out=[];const col=st.getPropertyValue('color');if(col){const b=tvBoost(col);if(b==='dark')out.push('text-shadow:none');else if(b)out.push('color:'+b)}
  for(let i=0;i<st.length;i++){const p=st[i];if(p.startsWith('--')){const b=tvBoost(st.getPropertyValue(p).trim());if(b&&b!=='dark')out.push(p+':'+b)}}
  /* weights and sizes usually come from a font shorthand with var(--ui), which the browser reports as blank longhands, so read the shorthand text too */
  let fw=parseInt(st.getPropertyValue('font-weight'))||0,fs=parseFloat(st.getPropertyValue('font-size'))||0;
  if(!fw||!fs){const m=String(st.getPropertyValue('font')||'').match(/^\s*(?:(?:italic|oblique|normal)\s+)?(\d{3}|bold|normal)?\s*([\d.]+)px/);if(m){fw=fw||(m[1]==='bold'?700:m[1]==='normal'||!m[1]?400:+m[1]);fs=fs||+m[2]}}if(fw&&fs&&fs<=16&&fw<=600)out.push('font-weight:'+Math.min(800,fw+(fw<=500?200:100)));
  if(out.length)rules.push(tvSplit(R.selectorText).map(s=>/^(html|body)\b/.test(s)?null:':where(body.tv) '+s).filter(Boolean).join(',')+'{'+out.join(';')+'}')}};
 for(const sh of document.styleSheets){let L;try{L=sh.cssRules}catch(e){continue}if(L&&sh.ownerNode!==TVX.el)walk(L)}
 const el=TVX.el=document.createElement('style');el.id='tvcss';
 el.textContent=`body.tv #ov,body.tv .bellp,body.tv #ccm,body.tv .sgm,body.tv #updz,body.tv .lomod,body.tv #cctoast{text-shadow:0 1px 1px #000000f2,0 0 3px #000000cc,0 0 1px #000;-webkit-font-smoothing:antialiased}
body.tv input::placeholder,body.tv textarea::placeholder{color:#d6ceff!important;opacity:1}
`+rules.join('\n');document.head.appendChild(el)}

/* ---------- Settings > Display ---------- */
SETG.Display.push('Text visibility','Performance mode');
{const st0=settingsTabs;settingsTabs=function(){const box=ov.querySelector('.opts');if(box&&!box.querySelector('#pfopt')){
 const seg=(k,opts)=>`<div class="seg">${opts.map(([v,l])=>`<button class="sm${String(ST[k])===String(v)?' on':''}" data-k="${k}" data-v="${v}">${l}</button>`).join('')}</div>`;
 const a=document.createElement('div');a.className='opt';a.id='tvopt';a.innerHTML=`<div><label>Text visibility</label><small>Clear makes menu text brighter, bolder and sharper against busy backgrounds. Gameplay is not changed.</small></div>${seg('tvis',[['off','Standard'],['on','Clear']])}`;
 const b=document.createElement('div');b.className='opt';b.id='pfopt';b.innerHTML=`<div><label>Performance mode</label><small>${PFSET()==='low'?'Performance: lowest resolution and lighter effects for slower computers. The Casino keeps its full animations.':PFSET()==='bal'?'Balanced: sharp at 1x with lighter background work. A good middle ground. The Casino keeps its full animations.':'Quality: full detail. Choose Balanced or Performance if the game feels slow.'}</small></div>${seg('perf',[['high','Quality'],['bal','Balanced'],['low','Performance']])}`;
 const fps=[...box.querySelectorAll(':scope>.opt')].find(o=>/Show FPS/.test(o.textContent));if(fps){fps.before(a);fps.before(b)}else{box.appendChild(a);box.appendChild(b)}}
 return st0.apply(this,arguments)}}

/* ---------- a one-time offer when the game is clearly struggling ---------- */
const PFW={t0:0,n:0,low:0,asked:false};
{const l0=loop;loop=function(ts){try{if(PFSET()==='high'&&!ST.perfAsked&&!document.hidden){if(!PFW.t0)PFW.t0=ts;PFW.n++;const el=ts-PFW.t0;
 if(el>=5000){const f=PFW.n*1000/el;PFW.low=f<20?PFW.low+1:0;PFW.t0=ts;PFW.n=0;if(PFW.low>=2&&S.mode!=='play')pfOffer()}}else PFW.t0=0}catch(e){}return l0(ts)}}
function pfOffer(){if(PFW.asked||document.getElementById('pfask'))return;PFW.asked=true;const d=document.createElement('div');d.id='pfask';d.setAttribute('role','dialog');d.setAttribute('aria-label','Performance mode');
 d.innerHTML=`<b>Running slowly?</b><span>Performance mode lowers the resolution and lightens effects so the game runs smoother on this computer.</span><div><button class="pfy">Turn on Performance mode</button><button class="pfn">Not now</button></div>`;document.body.appendChild(d);
 const done=on=>{ST.perfAsked=1;if(on)ST.perf='low';saveST();applyLayout();d.classList.add('out');setTimeout(()=>d.remove(),260);if(on)try{ccToast('Performance mode is on. Change it any time in Settings › Display.')}catch(e){}};
 d.querySelector('.pfy').onclick=()=>done(1);d.querySelector('.pfn').onclick=()=>done(0)}

{const st=document.createElement('style');st.textContent=`
body.pf-low *,body.pf-low *::before,body.pf-low *::after{backdrop-filter:none!important}
#pfask{position:fixed;left:50%;top:22px;z-index:250;transform:translateX(-50%);width:min(520px,92vw);display:flex;flex-direction:column;gap:8px;padding:16px 18px;border-radius:18px;font-family:var(--ui);color:#fff8e8;background:linear-gradient(180deg,#1e1650,#0e0a28);border:2px solid #5a4ca0;box-shadow:0 18px 40px #000c;animation:pfin .4s cubic-bezier(.3,1.5,.5,1)}
#pfask b{font:400 30px/1 'Pirata One',Georgia,serif;color:#ffd45a}#pfask span{font:500 14px/1.45 var(--ui);color:#e6deff}
#pfask div{display:flex;gap:10px;margin-top:4px}#pfask button{all:unset;cursor:pointer;padding:10px 16px;border-radius:12px;font:800 15px var(--ui);transition:transform .2s cubic-bezier(.3,1.5,.5,1)}
#pfask .pfy{color:#2a1406;background:linear-gradient(180deg,#ffe27a,#f6b830);border:2px solid #fff0b0;box-shadow:0 4px 0 #9a5a10}#pfask .pfn{color:#fff8e8;background:linear-gradient(180deg,#2c2470,#1a1450);border:1.5px solid #5a4ca0}
#pfask button:hover{transform:translateY(-2px)}#pfask button:active{transform:scale(.94)}#pfask button:focus-visible{outline:3px solid #8a7cf0;outline-offset:2px}
#pfask.out{opacity:0;transform:translate(-50%,-10px);transition:opacity .25s,transform .25s}
@keyframes pfin{from{opacity:0;transform:translate(-50%,-14px) scale(.95)}}
@media (prefers-reduced-motion:reduce){#pfask{animation:none}}
`;document.head.appendChild(st)}
setTimeout(()=>{try{applyLayout()}catch(e){}},0);
