/* ---------- armory (second design): class tiles, weapon grid, preview and equip panels ---------- */
const ARI={
 knight:'<svg viewBox="0 0 24 24" width="34" height="34"><path d="M12 2l8.5 3v6.2c0 5.2-3.6 8.8-8.5 11-4.9-2.2-8.5-5.8-8.5-11V5z" fill="#e8a820" stroke="#4a2c04" stroke-width="1.4"/><path d="M12 4.6l6 2.2v4.4c0 3.6-2.4 6.4-6 8.2z" fill="#ffd45a"/><path d="M12 4.6v14.8c-3.6-1.8-6-4.6-6-8.2V6.8z" fill="#c8861a"/></svg>',
 archer:'<svg viewBox="0 0 24 24" width="34" height="34"><path d="M3 21L17 7" stroke="#2a6a42" stroke-width="3.4" stroke-linecap="round"/><path d="M3 21L17 7" stroke="#8affc0" stroke-width="1.6" stroke-linecap="round"/><path d="M13 3.5c5 0 7.5 2.2 7.5 7.5-5 0-7.5-2.5-7.5-7.5z" fill="#4ad88a" stroke="#0a3a20" stroke-width="1.2"/><path d="M15 6c1.5 1.4 3 2.6 4 4" stroke="#c8ffe0" stroke-width="1.2" fill="none"/></svg>',
 mage:'<svg viewBox="0 0 24 24" width="34" height="34"><path d="M12 1.5c1.2 4.6 6.8 6.6 6.8 13a6.8 6.8 0 0 1-13.6 0c0-3.6 2.2-5 3.4-8 .8 1.8 1.6 2.4 3.4-5z" fill="#b058ff" stroke="#3a0a6a" stroke-width="1.2"/><path d="M12 11c1.2 2.4 3.4 3.4 3.4 6a3.4 3.4 0 0 1-6.8 0c0-2.6 2.2-3.6 3.4-6z" fill="#ffd8ff"/></svg>',
 rogue:'<svg viewBox="0 0 24 24" width="34" height="34"><path d="M5 19L18.5 5.5l1.5 1.5L6.5 20.5z" fill="#ffb0c8" stroke="#6a0a2a" stroke-width="1.2"/><path d="M4 16l4 4-2.4.8L3.2 18.4z" fill="#ff5c8a" stroke="#6a0a2a" stroke-width="1"/><path d="M18.5 5.5L21 3l.5 2.5z" fill="#fff"/></svg>',
 lock:'<svg viewBox="0 0 24 24" width="30" height="30"><rect x="5" y="10.5" width="14" height="10.5" rx="2.2" fill="#9a96b0"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5" fill="none" stroke="#9a96b0" stroke-width="2.4"/><circle cx="12" cy="15.6" r="1.6" fill="#3a3650"/></svg>'};
let ARSTG=null;
/* the workshop behind the character: painted once, torches flicker on top */
function arStageBG(w,h){const c=cdMk(w,h),g=c.getContext('2d');
 g.fillStyle=vgr(g,0,h,'#2a2034','#0e0916');g.fillRect(0,0,w,h);
 g.save();g.globalAlpha=.7;for(let r=0;r<10;r++){const y=r*50-10,off=(r&1)*40;for(let x=-80+off;x<w+80;x+=80){const k=rnd(r*17+x*.05);g.fillStyle='rgba('+(52+k*26|0)+','+(36+k*14|0)+','+(40+k*14|0)+',.55)';g.fillRect(x+2,y+2,76,46);g.strokeStyle='#0a0610aa';g.lineWidth=2.5;g.strokeRect(x+2,y+2,76,46)}}g.restore();
 for(const x of[w*.3,w*.7]){g.beginPath();g.moveTo(x-34,h*.5);g.lineTo(x-34,h*.2);g.quadraticCurveTo(x-34,h*.06,x,h*.06);g.quadraticCurveTo(x+34,h*.06,x+34,h*.2);g.lineTo(x+34,h*.5);g.closePath();g.fillStyle=vgr(g,h*.06,h*.5,'#d8884a','#5a2a24');g.fill();g.lineWidth=7;g.strokeStyle='#3a2a34';g.stroke();g.lineWidth=2;g.strokeStyle='#8a6a58';g.stroke();
  g.fillStyle='#1a0e1a';for(const dx of[-14,14]){g.fillRect(x+dx-1.5,h*.1,3,h*.4)}g.fillRect(x-34,h*.28,68,3)}
 /* banner and shield on the wall */
 const bx=w*.5,by=26;g.fillStyle='#caa030';g.fillRect(bx-34,by,68,6);g.beginPath();g.moveTo(bx-30,by+6);g.lineTo(bx+30,by+6);g.lineTo(bx+30,by+130);g.lineTo(bx,by+150);g.lineTo(bx-30,by+130);g.closePath();g.fillStyle=hgr(g,bx-30,bx+30,'#8a1430','#5a0a1c');g.fill();g.lineWidth=3;g.strokeStyle='#e8b030';g.stroke();cdSigil(g,bx,by+72,.7);
 /* floor */
 g.fillStyle=vgr(g,h*.72,h,'#00000000','#000000cc');g.fillRect(0,h*.6,w,h*.4);
 g.fillStyle=vgr(g,h*.78,h,'#3a2a34','#120a16');g.fillRect(0,h*.78,w,h*.22);
 for(let i=0;i<8;i++){g.strokeStyle='#00000066';g.lineWidth=2;g.beginPath();g.moveTo(w*.5+(i-3.5)*20,h*.78);g.lineTo(w*.5+(i-3.5)*120,h);g.stroke()}
 /* round stone podium */
 const px=w/2,py=h-72,rx=162,ry=38,th=34;
 g.fillStyle='#00000099';g.beginPath();g.ellipse(px,py+th+8,rx+26,ry+8,0,0,TAU);g.fill();
 g.beginPath();g.ellipse(px,py+th,rx,ry,0,0,Math.PI);g.lineTo(px-rx,py);g.ellipse(px,py,rx,ry,0,Math.PI,0,true);g.closePath();g.fillStyle=hgr(g,px-rx,px+rx,'#6a5560','#3a2c36');g.fill();
 g.save();g.clip();g.strokeStyle='#1a0e1a99';g.lineWidth=2;for(let i=-9;i<=9;i++){const a=i/9*Math.PI*.5;g.beginPath();g.moveTo(px+Math.sin(a)*rx,py);g.lineTo(px+Math.sin(a)*rx,py+th+ry);g.stroke()}g.beginPath();g.ellipse(px,py+th*.5,rx,ry,0,0,Math.PI);g.stroke();g.restore();
 g.beginPath();g.ellipse(px,py,rx,ry,0,0,TAU);g.fillStyle=rgr(g,px,py,10,rx,'#8a7480','#54424e');g.fill();g.lineWidth=3;g.strokeStyle='#241620';g.stroke();
 g.beginPath();g.ellipse(px,py,rx*.78,ry*.78,0,0,TAU);g.lineWidth=2;g.strokeStyle='#2a1a2488';g.stroke();
 return{c,px,py}}
function arStageFn(cv,get){const g=cv.getContext('2d'),w=cv.width,h=cv.height;if(!ARSTG||ARSTG.c.width!==w)ARSTG=arStageBG(w,h);const B=ARSTG;
 return t=>{g.setTransform(1,0,0,1,0,0);g.globalCompositeOperation='source-over';g.drawImage(B.c,0,0);
  g.globalCompositeOperation='lighter';for(const x of[w*.3,w*.7]){const f=.8+.2*Math.sin(t*11+x)+.08*Math.sin(t*19+x*2);cdGlow(g,x,h*.16,150*f,'rgba(255,140,50,.30)');mFl(g,x-4,h*.2,36*f,9,t,x|0,'rgba(255,120,24,.9)','rgba(255,240,170,.9)');mFl(g,x+5,h*.2,26*f,7,t,(x|0)+3,'rgba(255,190,60,.9)','rgba(255,250,200,.9)')}
  g.globalCompositeOperation='source-over';
  const o=get(),wp=WP[o.wp];glow(g,w/2,h*.55,200,wp.col+'55');
  g.save();g.translate(w/2+8,B.py+6);g.scale(o.scale,o.scale);drawHero(g,{arm:o.arm,wp:o.wp,col:P.col,t});g.restore()}}
const arSent=s=>String(s||'').split(/(?<=\.)\s+/).filter(Boolean);
function armory(tab){const keepG=ov.querySelector('.argrid');const keep=keepG?keepG.scrollTop:0;S.mode='title';S.view='menu';prevA=prevW=prevMK=null;if(typeof tab==='string'){armory.tab=tab}
 const tb=armory.tab||'Weapons',isA=tb==='Armor';
 const T=isA?AR:WP,o=isA?'ownA':'own',eq=isA?'armor':'weapon',k=isA?'a':'w';
 const ids=Object.keys(T).filter(id=>isA||T[id].p===P.path),have=ids.filter(id=>P[o][id]).length,hid=ids.length-have,showAll=armory.all&&hid>0;
 const rk=w=>w.pr?'Prestige '+PRN[w.pr-1]:w.r;
 const L=ids.filter(id=>showAll||P[o][id]||(!isA&&wxp(id)>0)).sort((x,y)=>(P[eq]===y)-(P[eq]===x)||(!!P[o][y]-!!P[o][x])||RKM[T[y].r]-RKM[T[x].r]).map(id=>{const w=T[id],h=P[o][id],mk=!isA&&!h&&wxp(id)>0,kn=h||mk;
  return `<button class="ac2${h?'':' lk'}${mk?' ms':''}${P[eq]===id?' eq':''}${h&&RKM[w.r]>=5?' myth':h&&RKM[w.r]===4?' leg':''}" data-g="${eq}" data-k="${id}" style="--c:${kn?w.col:'#8a84a8'}"><canvas width="236" height="150" data-a="${k}:${id}"></canvas><span class="wn${kn&&w.n.length>13?' lg':''}">${kn?esc(w.n):'???'}</span><small>${kn?rk(w):'Undiscovered'}</small><u class="pl eqp">equipped</u><u class="pl pvp">previewing</u></button>`}).join('');
 const lv=lvl(P.xp);P.seen[P.path]=1;for(const p of PK)if(pathOpen(p))P.seen[p]=1;save();
 const tiles=PK.map(p=>{const op=pathOpen(p),Q=PATHS[p];return `<button class="apt${P.path===p?' on':''}${op?'':' lk'}" data-p="${p}" style="--c:${Q.c}" ${op?'':'disabled'}><span class="api">${op?ARI[p]:ARI.lock}</span><span class="apx"><b>${Q.n}</b><small>${op?esc(arSent(Q.d)[0]):'Unlocks at player level '+Q.lv+'.'}</small></span></button>`}).join('');
 show(`<div class="ar2"><section class="arl"><header class="arh"><h2>Armory</h2><p>Equip new weapons and armor to customize your warrior.</p></header>
<div class="arcp"><i class="ark a"></i><i class="ark b"></i><i class="ark c"></i><i class="ark d"></i><div class="arct"><b>Character Preview</b><small>Changes shown here are previews. Click Equip to save.</small></div>
<canvas id="hv" width="420" height="470"></canvas><div class="arsl"><div class="arsc" id="arsw"></div><div class="arsc" id="arsa"></div></div>
<button class="arcz" id="dy"><svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><path d="M8.5 3L3 6l2 5 3-1v11h8V10l3 1 2-5-5.5-3a3.6 3.6 0 0 1-7 0z"/></svg><span>Customize appearance</span></button></div></section>
<section class="arr"><div class="artop"><div class="apts">${tiles}</div><button class="arbk" id="arbk"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg><span>Back</span></button></div>
<div class="arbar"><div class="arseg"><button class="${isA?'':'on'}" data-at="Weapons">Weapons</button><button class="${isA?'on':''}" data-at="Armor">Armor</button></div><button class="arauto" id="arauto" title="Pick the best weapon and armor you own"><svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><path d="M12 1.5l2.4 6.1 6.1 2.4-6.1 2.4L12 18.5l-2.4-6.1-6.1-2.4 6.1-2.4zM19 15l1 2.5 2.5 1-2.5 1-1 2.5-1-2.5-2.5-1 2.5-1z"/></svg><span>Auto-Equip Best</span></button><span class="arcnt" title="Hover to preview, click to equip.">${have} of ${ids.length} found</span>${hid?`<button class="arund" id="ta">${showAll?'Hide':'Show'} ${hid} undiscovered</button>`:''}</div>
<div class="argrid">${L}</div>
<div class="arbt"><div class="arpv" id="arpv"></div><div class="areq" id="areq"></div></div></section><div class="armod" id="armod" hidden></div></div>`,'m');
 ov.scrollTop=0;S.back=title;
 const grid=ov.querySelector('.argrid');grid.scrollTop=keep;
 let cardN=0;if(armory.io)armory.io.disconnect();const armIO=armory.io=window.IntersectionObserver?new IntersectionObserver(es=>{for(const e of es)if(e.target._L)e.target._L.vis=e.isIntersecting},{root:grid,rootMargin:'60px'}):null;
 ov.querySelectorAll('canvas[data-a]').forEach(c=>{const [kk,id]=c.dataset.a.split(':');const fn=t=>art(c,kk,id,t);fn(0);if(P[kk==='a'?'ownA':'own'][id]&&(kk==='a'?AR:WP)[id].r!=='Common'){const Lv={cv:c,fn,slow:4,ph:cardN++%4,vis:true};LIVE.push(Lv);c._L=Lv;if(armIO)armIO.observe(c)}});
 LIVE.push({cv:$('hv'),fn:arStageFn($('hv'),()=>({wp:prevMK||prevW||P.weapon,arm:prevA||P.armor,scale:2.4})),slow:2,ph:0,vis:true});
 const ico=(kk,id,w,h)=>{const c=document.createElement('canvas');c.width=w;c.height=h;art(c,kk,id,0);return c};
 const put=(el,kk,id,w,h)=>{const c=el.querySelector('canvas[data-i]');if(c){c.width=w;c.height=h;art(c,kk,id,0)}};
 let lkId=null;
 const upd=()=>{const wid=prevMK||prevW||P.weapon,aid=prevA||P.armor,W=WP[wid],A=AR[aid];
  $('arsw').innerHTML=`<small>Weapon</small><div><span class="asi" style="--c:${W.col}"><canvas data-i width="64" height="64"></canvas></span><span class="asx"><b style="color:${W.col}">${esc(W.n)}</b><em>${rk(W)}</em></span></div>`;put($('arsw'),'w',wid,64,64);
  const ast=arSent(A.d)[0]||'';$('arsa').innerHTML=`<small>Armor</small><div><span class="asi" style="--c:${A.col}"><canvas data-i width="64" height="64"></canvas></span><span class="asx"><b style="color:${A.col}">${esc(A.n)}</b><em>${rk(A)}</em><u>${esc(ast)}</u></span></div>`;put($('arsa'),'a',aid,64,64);
  const pid=lkId||(isA?aid:wid),Q=T[pid],eid=P[eq],E=T[eid],owned=!!P[o][pid],mk=!isA&&!owned&&wxp(pid)>0,kn=owned||mk,same=pid===eid;
  const mast=!isA&&kn?(()=>{const x=wxp(pid),t=wTier(pid),nx=t>=5?null:WT[t];return `<div class="apm"><span>Mastery</span><b>${t?WTN[t]:'Unproven'}</b><em>${nx?`${x.toLocaleString()} / ${nx.toLocaleString()} XP`:`${x.toLocaleString()} XP`}</em><s><i style="width:${Math.round(wProg(pid)*100)}%"></i></s></div><button class="arml" id="arml">${[1,2,3].map(i=>`<i style="height:${6+i*4}px"></i>`).join('')}<span>View mastery tiers</span></button>`})():'';
  $('arpv').style.setProperty('--c',kn?Q.col:'#8a84a8');
  $('arpv').innerHTML=`<u class="artag">PREVIEWING</u><span class="apv-i${kn?'':' lk'}"><canvas data-i width="150" height="186"></canvas></span><div class="apv-t"><b class="${!isA&&kn&&RKM[Q.r]>=5?'myth ':''}${kn&&Q.n.length>14?'lg':''}">${kn?esc(Q.n):'???'}</b><em>${kn?rk(Q):'Undiscovered'}</em><p>${kn?Q.d:'Not found yet. Open crates to discover it.'}${mk?' <i>Not in your armory. Mastery kept.</i>':''}</p>${kn&&typeof gabHTML==='function'?gabHTML(Q):''}${mast}</div>`;put($('arpv'),k,pid,150,186);
  $('areq').style.setProperty('--c',E.col);
  $('areq').innerHTML=`<div class="aeq"><u class="artag">CURRENTLY EQUIPPED</u><span class="aeq-i"><canvas data-i width="92" height="92"></canvas></span><div class="aeq-t"><b class="${E.n.length>14?'lg':''}">${esc(E.n)}</b><em>${rk(E)}</em><ul>${arSent(E.d).map(s=>`<li>${s}</li>`).join('')}</ul></div></div><button class="areb" id="areb" ${same||!owned?'disabled':''}><svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M20 3l1 1-9 11-2.4-.6L9 12zM8 14l2 2-2.4 3.6a1.6 1.6 0 0 1-2.6.2l-1-1.2a1.6 1.6 0 0 1 .4-2.4z"/></svg><span>${same?'Equipped':owned?'Equip '+esc(Q.n):'Not owned'}</span></button>`;put($('areq'),k,eid,92,92);
  if($('areb'))$('areb').onclick=()=>{if(same||!owned)return;if(isA){P.armor=pid;save()}else setWeapon(pid);armory()};
  if($('arml'))$('arml').onclick=()=>{const m=$('armod');m.hidden=false;m.innerHTML=`<div class="armb"><button class="armx" id="armx" aria-label="Close">×</button><h3 style="color:${Q.col}">${esc(Q.n)}</h3>${mastHTML(pid)}</div>`;const cl=()=>{m.hidden=true;m.innerHTML='';S.back=title};S.back=cl;$('armx').onclick=cl;m.onclick=e=>{if(e.target===m)cl()}};
  ov.querySelectorAll('.ac2').forEach(c=>{c.classList.toggle('pv',c.dataset.k===pid&&!same&&c.dataset.g===eq)})};
 upd();
 let pvTO=0;
 ov.querySelectorAll('[data-k]').forEach(el=>{const g=el.dataset.g,id=el.dataset.k,oo=g==='armor'?'ownA':'own';
  const on=()=>{clearTimeout(pvTO);lkId=null;if(P[oo][id]){if(g==='armor')prevA=id;else prevW=id;prevMK=null;upd()}else if(g!=='armor'&&wxp(id)>0){prevMK=id;upd()}else{lkId=id;upd()}};
  const off=()=>{pvTO=setTimeout(()=>{prevA=prevW=prevMK=null;lkId=null;upd()},60)};
  el.onmouseenter=on;el.onfocus=on;el.onmouseleave=off;el.onblur=off;
  el.onclick=()=>{if(P[oo][id]){if(g==='armor'){P.armor=id;save()}else setWeapon(id);armory()}}});
 ov.querySelectorAll('[data-p]').forEach(el=>el.onclick=()=>{setPath(el.dataset.p);armory()});
 ov.querySelectorAll('[data-at]').forEach(el=>el.onclick=()=>{if(el.classList.contains('on'))return;grid.scrollTop=0;armory.all=false;armory(el.dataset.at)});
 if($('ta'))$('ta').onclick=()=>{armory.all=!armory.all;armory()};
 $('arbk').onclick=()=>{if(S.back)S.back()};
 if($('arauto'))$('arauto').onclick=autoEquipUI;
 $('dy').onclick=()=>profile('Customize')}
