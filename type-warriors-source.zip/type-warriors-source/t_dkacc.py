import asyncio,os,sys
from playwright.async_api import async_playwright
SET="()=>{RS_ASK=false;P.camp=6;for(let i=1;i<=5;i++){P.stars[i]=3}P.gold=300719;P.pets={antler:{b:560}};P.pet='antler';P.petSt=2;petNorm();title()}"
ST="()=>[ov.className.split(' ').filter(c=>c!=='m'&&c!=='sh'&&c!=='top').join(' '),S.mode,S.view,(document.querySelector('#ov h2')||{}).textContent||'',!!document.querySelector('.dks'),typeof CAS!=='undefined'&&CAS.on]"
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append('PE '+str(e)[:300]))
        await pg.goto('file://'+os.path.abspath('out.html'));await pg.wait_for_timeout(1500);E=pg.evaluate
        async def home(): 
            await pg.mouse.move(2,2);await E(SET);await pg.wait_for_timeout(400)  # park the pointer: the hover tilt on a hub button keeps its box moving
        for cid,sub in [('dmc',None),('dme',None),('dma',None),('dmd',None),('dmk',None),('dmp',None),('dmv','dmt'),('dmv','dmg')]:
            await home();await pg.click('#dkmode');await pg.wait_for_timeout(300);await pg.click('#'+cid);await pg.wait_for_timeout(350)
            if sub: await pg.click('#'+sub);await pg.wait_for_timeout(450)
            print('mode',cid,sub or '',await E(ST))
            await E("()=>{if(typeof CAS!=='undefined'&&CAS.on)casinoBack()}");await pg.wait_for_timeout(200)
        for mid in ['mpf','mcl','mst','mhp','mbg','msv','mcz','mnt']:
            await home();await pg.click('#dk_mo');await pg.wait_for_timeout(300);await pg.click('#'+mid);await pg.wait_for_timeout(450)
            print('more',mid,await E(ST),await E("()=>{const p=document.getElementById('bellp');return p?getComputedStyle(p).display+':'+p.className:''}"))
            await E("()=>{if(typeof CAS!=='undefined'&&CAS.on)casinoBack()}");await pg.wait_for_timeout(200)
        await home();await pg.click('#dk_mo');await pg.wait_for_timeout(300);m0=await E("()=>ST.mute");await pg.click('#mmu');await pg.wait_for_timeout(100)
        print('music toggled',m0,'->',await E("()=>[ST.mute,document.querySelector('#mmu b').textContent,mt.textContent]"));await pg.click('#mmu');await pg.keyboard.press('Escape')
        # keyboard letters
        for k,exp in [('a','Armory'),('k','Skill'),('l','Collection'),('b','Bount'),('s','Shop'),('x','Crates'),('t','Profile'),('h','How')]:
            await home();await pg.keyboard.press(k);await pg.wait_for_timeout(350);print('key',k,await E(ST))
        # Tab trap in sheet
        await home();await pg.click('#dkmode');await pg.wait_for_timeout(300)
        ids=[]
        for i in range(10):
            await pg.keyboard.press('Tab');ids.append(await E("()=>document.activeElement.id||document.activeElement.className"))
        print('tab cycle',ids,'inside',await E("()=>document.querySelector('.dks').contains(document.activeElement)"))
        await pg.keyboard.press('Escape');await pg.wait_for_timeout(300);print('focus back',await E("()=>document.activeElement.id"))
        # stress: switching menus leaves no leftovers
        for i in range(6):
            for k in ['gr','pt','pg','sh','pl']:
                await pg.click('#dk_'+k);await pg.wait_for_timeout(120)
            await pg.click('#dk_mo');await pg.wait_for_timeout(120);await pg.keyboard.press('Escape');await pg.wait_for_timeout(120)
        print('after stress',await E("()=>[LIVE.length,document.querySelectorAll('.dks').length,document.querySelectorAll('.dkrow').length,ov.inert,[...ov.children].some(c=>c.inert)]"))
        # gold updates
        await E("()=>{P.gold-=1234}");await pg.wait_for_timeout(1300);print('gold shown',await E("()=>[document.getElementById('dkgold').textContent,P.gold.toLocaleString()]"))
        # continue campaign starts the level, menu chrome hides
        await pg.click('#dkcont');await pg.wait_for_timeout(800);print('continue',await E("()=>[S.mode,S.camp,ov.className,getComputedStyle(document.getElementById('cn')).display]"))
        await pg.keyboard.type('a');await pg.wait_for_timeout(100);print('typing ok',await E("()=>[S.mode,inp.value!==undefined]"))
        print(er[:6]);await b.close()
asyncio.run(main())
