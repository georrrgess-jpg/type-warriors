/* ===== 10.1e integrity marker (00a: the very first lines of the game script) =====
   98t_integrity.js tells the game's own code apart from code a cheat injects (a browser extension, the console, an injected <script>):
   it reads the call stack of every write to coins / XP / prestige and needs to know where the game script starts. mark(f) runs f with
   a frame from this line on the stack. wd: whether the page runs under browser automation (the test scripts), read from the prototype
   before anything else can patch it. */
const TWAC0=(()=>{const o={wd:false};try{const d=Object.getOwnPropertyDescriptor(Navigator.prototype,'webdriver');o.wd=!!(d&&d.get&&d.get.call(navigator))}catch(e){}
 o.mark=f=>f();return Object.freeze(o)})();
