/* ===== MOONLIT FISHING: the game loop =====
   States: idle -> cast -> wait -> bite/reel (one word per stage; Rare 2 stages, Legendary 3) -> show (the catch
   spectacle, scaled to rarity) -> reveal (Sell / Keep in the side panel) -> idle. A word that runs out of time costs a
   line heart (Legendary fish allow one retry); with no hearts left the fish escapes.
   Typing: physical keys (document keydown, capture) and the hidden input `inp` for touch keyboards. Space or Enter casts,
   skips a spectacle (after a moment) and takes the default choice on a catch. Esc leaves. Everything animates on one
   canvas (90d) plus a few HTML overlays (90f). */
const FS={st:'off',T:0,t0:0,pt:[],sh:[],bob:null,view:{},on:false};
const fsNow=()=>performance.now()/1000;
const fsRM=()=>{try{return matchMedia('(prefers-reduced-motion: reduce)').matches}catch(e){return false}};
function fsSet(st){FS.st=st;FS.t0=fsNow();try{fsHudState()}catch(e){}}
/* ---------- sounds (small synth phrases on the game's beep) ---------- */
function fsSfx(k,x){const B=(f,d,ty,v,at)=>setTimeout(()=>{try{beep(f,d,ty,v)}catch(e){}},(at||0)*1000),A=(fs,step,ty,v,d)=>fs.forEach((f,i)=>B(f,d||.12,ty||'triangle',v==null?.4:v,i*(step||.08)));
 if(k==='cast'){B(700,.05,'sine',.25);B(520,.06,'sine',.25,.05);B(380,.08,'sine',.2,.1)}
 else if(k==='plop'){B(240,.09,'sine',.55);B(360,.05,'sine',.3,.03)}
 else if(k==='nib'){B(520,.03,'sine',.18)}
 else if(k==='bite'){B(880,.07,'square',.35);B(1175,.12,'square',.35,.07)}
 else if(k==='key')B(900+(x||0)*35,.025,'triangle',.16);
 else if(k==='miss')B(150,.09,'sawtooth',.22);
 else if(k==='stage')A([523,784],.07,'triangle',.35);
 else if(k==='hold')A([392,523],.1,'square',.3);
 else if(k==='esc')A([392,330,262],.12,'sine',.4,.18);
 else if(k==='c')A([523,659,784],.07);
 else if(k==='u')A([523,659,784,1047],.07,'triangle',.45);
 else if(k==='r')A([659,880,1175,1568],.09,'triangle',.5,.2);
 else if(k==='l1'){A([110,98,82],.25,'sawtooth',.25,.3)}
 else if(k==='l2'){try{jingle('win')}catch(e){}A([1047,1319,1568,2093],.11,'triangle',.4,.3)}
 else if(k==='sell')A([1319,1760],.06,'square',.25);
 else if(k==='buy')A([784,1047,1319],.06,'triangle',.35);
 else if(k==='tick')B(1200,.03,'square',.2);
 else if(k==='whip'){B(1400,.03,'sine',.18);B(900,.05,'sine',.2,.03);B(500,.07,'sine',.18,.07)}
 else if(k==='snap'){B(2200,.02,'square',.25);B(1500,.03,'square',.2,.02);B(300,.08,'triangle',.25,.05)}}
/* ---------- particles ---------- */
function fsBurst(x,y,n,k,o){o=o||{};if(FS.pt.length>420)return;for(let i=0;i<n;i++){const a=o.a!=null?o.a+(Math.random()-.5)*(o.sp||Math.PI):Math.random()*TAU,v=(o.v||160)*(.4+Math.random()*.8);
  FS.pt.push({x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v-(o.up||0),g:o.g==null?420:o.g,life:0,max:(o.life||.8)*(.6+Math.random()*.6),k,c:o.c||'#e8f4ff',r:(o.r||3)*(.6+Math.random()*.8)})}}
function fsRing(x,y,c,r0,r1,dur,w){FS.pt.push({x,y,k:'ring',c,r0,r1,life:0,max:dur||.7,w:w||3})}
function fsSplash(x,y,big){fsBurst(x,y,big?36:14,'drop',{a:-Math.PI/2,sp:1.6,v:big?320:190,g:700,life:big?1:.7,c:'#d8eeff',r:big?4:3});fsRing(x,y,'#d8e8ff',6,big?90:46,big?1:.7,2.4);if(big)fsRing(x,y,'#ffffff',4,140,1.3,2)}
function fsDrawPt(g,dt){const L=FS.pt;for(let i=L.length-1;i>=0;i--){const p=L[i];p.life+=dt;if(p.life>=p.max){L.splice(i,1);continue}const u=p.life/p.max;
  if(p.k==='ring'){const r=p.r0+(p.r1-p.r0)*(1-Math.pow(1-u,2));g.strokeStyle=p.c;g.globalAlpha=(1-u)*.8;g.lineWidth=p.w*(1-u*.5);g.beginPath();g.ellipse(p.x,p.y,r,r*.3,0,0,TAU);g.stroke();continue}
  p.vy+=p.g*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;g.globalAlpha=Math.min(1,(1-u)*1.6);
  if(p.k==='drop'){g.fillStyle=p.c;g.beginPath();g.ellipse(p.x,p.y,p.r*.75,p.r*1.15,Math.atan2(p.vy,p.vx)+Math.PI/2,0,TAU);g.fill()}
  else if(p.k==='spark'){fkSpark(g,p.x,p.y,p.r*2*(1-u*.4),p.c,1)}
  else if(p.k==='gold'){g.fillStyle=p.c;g.save();g.translate(p.x,p.y);g.rotate(p.life*6);g.fillRect(-p.r,-p.r*.5,p.r*2,p.r);g.restore()}
  else if(p.k==='bub'){g.strokeStyle=p.c;g.lineWidth=1.4;g.beginPath();g.arc(p.x,p.y,p.r,0,TAU);g.stroke()}}g.globalAlpha=1}
/* ---------- fish shadows ---------- */
function fsShadowsInit(){FS.sh=[0,1,2].map(i=>({x:700+Math.random()*400,y:640+Math.random()*180,r:18+Math.random()*16,dir:Math.random()<.5?1:-1,a:.18,ph:Math.random()*9,tx:0,ty:0,amb:1}));FS.sh.forEach(fsShadowTarget)}
function fsShadowTarget(s){s.tx=660+Math.random()*460;s.ty=620+Math.random()*220}
function fsShadowStep(dt){FS.sh.forEach(s=>{if(s.hook){const b=FS.bob;if(!b)return;s.tx=b.x-s.dir*(s.r*1.1);s.ty=b.y+16}const dx=s.tx-s.x,dy=s.ty-s.y,d=Math.hypot(dx,dy);const sp=s.hook?(s.dart?260:46):22;
  if(d<4&&!s.hook)fsShadowTarget(s);else if(d>0){s.x+=dx/d*Math.min(d,sp*dt);s.y+=dy/d*Math.min(d,sp*dt);if(Math.abs(dx)>3)s.dir=dx>0?1:-1}
  if(s.dart){s.a=Math.max(0,s.a-dt*.5)}});FS.sh=FS.sh.filter(s=>s.a>0.01)}
/* ---------- start / stop ---------- */
function fsStart(){fsP();FS.on=true;FS.pt=[];FS.trail=[];FS.snap=null;FS.breach=null;FS.fly=null;FS.rel=null;FS.whip=0;FS.bob=null;FS.cur=null;FS.pend=null;FS.T=fsNow();FS.view={};fsShadowsInit();fsSet('idle')}
function fsStop(){FS.on=false;FS.st='off';FS.pt=[];FS.tut=0;clearTimeout(FS.tm)}
/* cast the line */
function fsCast(){if(FS.st!=='idle'||FS.tut)return;const F=fsP();fsSt('cast',1,'add');save();FS.tgt={x:760+Math.random()*320,y:590+Math.random()*70};FS.bob=null;fsSfx('cast');fsSet('cast')}
/* a fish bites */
function fsBite(){FS.biteT=fsNow();const c=fsRoll();FS.cur=c;FS.words=fsWords(c.rk);FS.si=0;FS.hp=FSR[c.rk].hp;FS.fightT=fsNow();FS.letters=FS.words.reduce((a,w)=>a+w.length,0);
 const sh=FS.sh.find(s=>s.hook);if(sh){sh.r=c.rk==='m'?62:c.rk==='l'?52:c.rk==='r'?40:c.rk==='u'?32:24}
 fsSplash(FS.bob.x,FS.bob.y+4,true);fsSfx('bite');FS.view.petHop=0.01;fsWord();fsSet('reel')}
function fsWord(){FS.word=FS.words[FS.si];FS.typed=0;FS.tMax=fsTime(FS.word,null,FS.cur.rk);FS.tLeft=FS.tMax;FS.grace=.35;try{fsHudWord()}catch(e){}}
/* typing during a fight */
function fsType(ch){if(FS.st!=='reel')return;ch=ch.toLowerCase();const w=FS.word,want=w[FS.typed];
 if(ch===want){FS.typed++;FS.pull=1;fsSfx('key',FS.typed);if(FS.bob){if(Math.random()<.5)fsBurst(FS.bob.x,FS.bob.y,3,'drop',{a:-Math.PI/2,sp:1.2,v:120,g:600,life:.4});const tp=FS.view.tip;if(tp){const u=.3+Math.random()*.6;fsBurst(tp.x+(FS.bob.x-tp.x)*u,tp.y+(FS.bob.y-tp.y)*u,2,'drop',{a:Math.PI/2,sp:1,v:40,g:500,life:.5,r:2})}}
  if(FS.typed>=w.length){if(FS.si<FS.words.length-1){FS.si++;fsSfx('stage');fsSplash(FS.bob.x,FS.bob.y,true);FS.thrash=1;FS.breach={t:fsNow(),x:FS.bob.x,y:FS.bob.y+6,dir:Math.random()<.5?-1:1,b2:0};fsSet('stage')}else fsLand()}
  try{fsHudWord()}catch(e){}}
 else if(/^[a-z ]$/.test(ch)){FS.tLeft=Math.max(.05,FS.tLeft-.25);FS.miss=1;fsSfx('miss');try{fsHudWord(1)}catch(e){}}}
/* time ran out on a word */
function fsTimeout(){FS.hp--;if(FS.hp>0){fsSfx('hold');fsBanner('The line holds!','One more try','#ffd45a',1.2);FS.words[FS.si]=fsWords(FS.cur.rk)[Math.min(FS.si,FSR[FS.cur.rk].st-1)];fsWord();return}
 fsEscape()}
function fsEscape(){const F=fsP();fsSt('esc',1,'add');F.streak=0;save();fsSfx('esc');fsSfx('snap');FS.snap={t:fsNow(),tip:FS.view.tip?{x:FS.view.tip.x,y:FS.view.tip.y}:null,bob:FS.bob?{x:FS.bob.x,y:FS.bob.y-20}:null};if(FS.bob){fsSplash(FS.bob.x,FS.bob.y,false);const s=FS.sh.find(s=>s.hook);if(s){s.hook=0;s.dart=1;s.tx=s.x+s.dir*-400;s.ty=s.y+60}}
 fsBanner('It got away…',FSR[FS.cur.rk].k>=2?`A ${FSR[FS.cur.rk].n.toLowerCase()} fish! Upgrade your Line for more time.`:'Cast again!','#c4badf',1.6);FS.cur=null;fsSet('escape')}
/* the fish is landed: record it and start the spectacle */
function fsLand(){const c=FS.cur,secs=fsNow()-FS.fightT;c.info=fsRecord(c,secs,FS.letters);c.val=fsValue(c);FS.bob&&fsSplash(FS.bob.x,FS.bob.y,true);
 const s=FS.sh.find(s=>s.hook);if(s)FS.sh.splice(FS.sh.indexOf(s),1);
 FS.show={c,dur:{c:1.15,u:1.5,r:2.5,l:5.2,m:7.6}[c.rk],x0:FS.bob.x,y0:FS.bob.y};fsSfx(c.rk==='l'?'l1':c.rk==='m'?'m1':c.rk);if(c.rk==='l')setTimeout(()=>{if(FS.show&&FS.show.c===c)fsSfx('l2')},900);
 FS.bob=null;fsSet('show');try{fsHudWord()}catch(e){}}
/* skip the spectacle */
function fsSkip(){if(FS.st!=='show')return;const el=fsNow()-FS.t0,d=FS.show.dur;if(el<Math.min(1.2,d*.4))return;FS.t0=fsNow()-d*.86}
function fsReveal(){const c=FS.show.c;FS.show=null;FS.pend=c;fsSet('reveal');
 if(fsP().auto&&FSR[c.rk].k<2&&!fsKeepWhy(c)){const v=fsSell(c);fsSfx('sell');FS.pend=null;fsToast(`Auto-sold ${FISH[c.id].n} for ${v.toLocaleString()} gold.`,1);try{fsHudRefresh();if(FSU.tab==='b')fsTabs()}catch(e){}fsSet('idle');return}
 try{fsPreview(c)}catch(e){}}
/* sell or keep the pending catch */
function fsDecide(keep){const c=FS.pend;if(!c||FS.st!=='reveal')return false;if(keep){if(!fsKeep(c)){fsToast('Your creel is full. Sell some fish first.');return false}fsToast(`${FISH[c.id].n} kept in your creel.`)}
 else{const v=fsSell(c);fsSfx('sell');fsToast(`Sold for ${v.toLocaleString()} gold.`,1)}
 FS.pend=null;try{fsPreview(null);fsHudRefresh()}catch(e){}fsSet('idle');return true}
/* default choice: keep rare and legendary fish (and anything you have no record of), sell the rest */
/* why a catch is worth keeping ('' = sell). Rare and Legendary fish, a first catch of a species and giants are always kept;
   fish needed for a rod look you haven't made are kept while "Save fish for rod looks" is on (the default) */
function fsKeepWhy(c){if(!c)return'';const F=fsP();if(FSR[c.rk].k>=2)return FSR[c.rk].n+' catch';if(c.info&&c.info.first)return'New species!';if(c.g)return'Giant!';
 if(F.look!==0)for(const k of FSKINK){const n=FSKIN[k].k[c.id];if(!F.sk[k]&&n){const have=F.cr.filter(x=>x.id===c.id).length;if(have<n)return`For the ${FSKIN[k].n} rod (${have}/${n})`}}return''}
const fsDefKeep=c=>!!c&&fsP().cr.length<fsCreelCap()&&!!fsKeepWhy(c);
/* ---------- per frame ---------- */
function fsFrame(g){const now=fsNow(),dt=Math.min(.05,now-(FS.T||now));FS.T=now;const el=now-FS.t0,V=FS.view,rm=fsRM();V.rm=rm;V.skin=fsSkin();V.lg=0;V.bend=0;V.slack=.4;V.rodA=-.62;V.cheer=0;V.dim=0;V.moonUp=0;V.shake=0;V.bob=null;V.lineTo=null;V.vib=0;V.noLine=0;V.bobA=1;
 if(V.petHop){V.petHop+=dt*2.6;if(V.petHop>=1)V.petHop=0}
 fsShadowStep(dt);
 /* state logic */
 if(FS.st==='cast'){const D=rm?.6:1,u=Math.min(1,el/D),ez=k=>k*k*(3-2*k);
  /* wind-up over the shoulder, a whip forward (the rod flexes), then the bobber sails out on a looping line */
  if(u<.32){const k=ez(u/.32);V.rodA=-.62-1.33*k;V.lg=-.15*k}
  else if(u<.46){const k=(u-.32)/.14,e=1-Math.pow(1-k,3);V.rodA=-1.95+1.73*e;V.bend=.4*Math.sin(k*Math.PI);V.lg=Math.sin(k*Math.PI)*.8;if(!FS.whip){FS.whip=1;fsSfx('whip')}}
  else{const k=Math.min(1,(u-.46)/.54);V.rodA=-.22-.33*ez(k)}
  if(u<.5&&V.tip&&!rm){FS.trail.push({x:V.tip.x,y:V.tip.y,t:now})}
  if(u>.42){if(!FS.rel)FS.rel=V.tip?{x:V.tip.x,y:V.tip.y}:{x:760,y:440};const k=Math.min(1,(u-.42)/.58),R=FS.rel,tx=FS.tgt.x,ty=FS.tgt.y;FS.fly={x:R.x+(tx-R.x)*k,y:R.y+(ty-R.y)*k-Math.sin(k*Math.PI)*200,k};V.bob=null;V.lineTo={x:FS.fly.x,y:FS.fly.y};V.slack=-.55*(1-k)+.12}
  if(u>=1){FS.fly=null;FS.rel=null;FS.whip=0;FS.landT=now;FS.bob={x:FS.tgt.x,y:FS.tgt.y,dip:0};fsSplash(FS.bob.x,FS.bob.y,false);fsSfx('plop');FS.wait=fsWait();FS.nib=[];const n=Math.random()*3|0;for(let i=0;i<n;i++)FS.nib.push(FS.wait*(.45+Math.random()*.45));
   const s={x:FS.bob.x+(Math.random()<.5?-1:1)*(260+Math.random()*120),y:FS.bob.y+40+Math.random()*60,r:22,dir:1,a:0,ph:Math.random()*9,hook:1};FS.sh.push(s);fsSet('wait')}}
 if(FS.bob){V.bob=FS.bob;V.lineTo=null}
 if(FS.st==='wait'){const s=FS.sh.find(s=>s.hook);if(s)s.a=Math.min(.36,s.a+dt*.25);FS.bob.dip=Math.max(0,FS.bob.dip-dt*3);{const lt=now-(FS.landT||0);if(lt<1.1)FS.bob.dip=Math.sin(lt*13)*Math.exp(-lt*4)*.5+Math.max(0,FS.bob.dip)}
  if(FS.nib.length&&el>FS.nib[0]){FS.nib.shift();FS.bob.dip=.35;fsRing(FS.bob.x,FS.bob.y,'#d8e8ff',4,24,.5,1.6);fsSfx('nib')}
  if(el>=FS.wait)fsBite()}
 if(FS.st==='reel'||FS.st==='stage'){const b=FS.bob,k=FSR[FS.cur.rk].k;FS.pull=Math.max(0,(FS.pull||0)-dt*4);FS.miss=Math.max(0,(FS.miss||0)-dt*3);
  b.dip=.55+.25*Math.sin(now*9)+(FS.st==='stage'?.3:0);b.x+=Math.sin(now*(2+k))*dt*(30+k*20);b.x=Math.max(700,Math.min(1120,b.x));
  V.bend=Math.min(1,.45+k*.12+FS.pull*.3+(FS.st==='stage'?.3:0));V.slack=0;V.rodA=-.5+Math.sin(now*7)*.03*(1+k)-FS.pull*.08;V.shake=FS.miss*3;V.vib=rm?0:FS.pull*2.4+k*.5+(FS.st==='stage'?2:0);
  {const bt=now-(FS.biteT||0);if(bt<.4){b.dip=1;V.bend=Math.max(V.bend,1-bt*1.2);V.rodA-=.18*(1-bt/.4);if(!rm)V.shake=Math.max(V.shake,4*(1-bt/.4))}}
  if(Math.random()<dt*(4+k*3))fsBurst(b.x+(Math.random()-.5)*20,b.y,2,'drop',{a:-Math.PI/2,sp:1.4,v:110,g:600,life:.4});
  if(FS.st==='reel'){if(FS.grace>0)FS.grace-=dt;else{FS.tLeft-=dt;if(FS.tLeft<=0){FS.tLeft=0;fsTimeout()}}try{fsHudTimer()}catch(e){}}
  else if(el>.6){fsWord();fsSet('reel')}}
 if(FS.st==='escape'){V.slack=.9;V.rodA=-.75-Math.max(0,.3-el)*1.2;V.noLine=1;if(FS.bob){FS.bob.dip=Math.max(-.35,FS.bob.dip-dt*3);FS.bob.x+=dt*18;V.bobA=Math.max(0,1-Math.max(0,el-.7)/.5)}if(el>1.2){FS.bob=null;fsSet('idle')}}
 if(FS.st==='show'){const d=FS.show.dur,u=Math.min(1,el/d);V.rodA=el<.22?-.55-el/.22*.8:-1.35+Math.min(1,(el-.22)/.5)*.4;V.bend=el<.22?.6:0;V.cheer=el>.5?1:0;V.cheerU=Math.min(1,(el-.5)*2);
  if(FS.show.c.rk==='m'&&typeof fsMythicView==='function')fsMythicView(V,el,d);
  if(FS.show.c.rk==='l'){const a=Math.min(1,el/.6),z=el>d-.9?Math.max(0,(d-el)/.9):1;V.dim=.62*a*z;V.moonUp=a*z;V.shake=el<.8?el*8:el<1.2?16*(1.2-el)/.4:0}
  if(u>=1)fsReveal()}
 /* draw */
 V.fx=(gg)=>{fsMotionFx(gg,now);fsDrawPt(gg,dt);if(FS.st==='show')fsShowFx(gg,now-FS.t0);if(FS.st==='reel'&&FS.cur&&FSR[FS.cur.rk].k>=2&&FS.bob){fkGlow(gg,FS.bob.x,FS.bob.y,60+20*Math.sin(now*6),FSR[FS.cur.rk].c,.25)}};
 V.shadows=FS.sh;fsScene(g,now,V);
 /* the "!" when a fish bites */
 if((FS.st==='reel'&&now-FS.fightT<.9)){const u=(now-FS.fightT)/.9,y=FSHERO.y-250-Math.sin(Math.min(1,u*3)*Math.PI/2)*20;g.save();g.globalAlpha=Math.min(1,(1-u)*3);g.font="400 64px 'Pirata One',Georgia,serif";g.textAlign='center';g.lineWidth=7;g.strokeStyle=FKO;g.strokeText('!',FSHERO.x+20,y);g.fillStyle='#ffd45a';g.fillText('!',FSHERO.x+20,y);g.restore()}}
/* where the fish flies to (the catch preview in the side panel) */
const FSPV={x:1290,y:700};
/* ---------- the catch spectacle ---------- */
function fsFishPx(c){const f=FISH[c.id],u=Math.min(1,c.cm/200);return 90+u*190+(c.rk==='m'?110:c.rk==='l'?80:c.rk==='r'?30:0)}
function fsShowFx(g,el){const S0=FS.show;if(!S0)return;const c=S0.c,d=S0.dur,rk=c.rk,col=FSR[rk].c,px=fsFishPx(c),t=fsNow();
 const hx=rk==='l'?780:rk==='r'?720:640,hy=rk==='l'?300:rk==='r'?360:420,x0=S0.x0,y0=S0.y0;
 /* timeline: leap (a) -> hold (h) -> fly to the panel (f) */
 const tl={c:[.55,.15,.45],u:[.6,.35,.5],r:[.7,1.1,.6],l:[1.9,2.3,.8]}[rk],aEnd=tl[0],hEnd=aEnd+tl[1];
 let x,y,s,rot,al=1;
 if(el<aEnd){const u=el/aEnd,e=1-Math.pow(1-u,2.2);if(rk==='l'){const k=Math.max(0,(el-.8)/(aEnd-.8));x=x0+(hx-x0)*k;y=y0+(hy-y0)*(1-Math.pow(1-k,2));s=.35+.65*k;rot=Math.sin(t*3)*.05;al=el<.8?0:Math.min(1,k*3)}
  else{x=x0+(hx-x0)*u;y=y0+(hy-y0)*e-Math.sin(u*Math.PI)*90;s=.5+.5*u;rot=(rk==='r'?u*TAU:0)+Math.sin(u*Math.PI)*-.5}}
 else if(el<hEnd){x=hx;y=hy+Math.sin(t*2.4)*6;s=1;rot=Math.sin(t*2)*.05}
 else{const u=Math.min(1,(el-hEnd)/tl[2]),e=u*u*(3-2*u);x=hx+(FSPV.x-hx)*e;y=hy+(FSPV.y-hy)*e-Math.sin(u*Math.PI)*60;s=1-.72*e;rot=Math.sin(u*Math.PI)*.3;al=1-Math.max(0,(u-.85)/.15)}
 /* rarity layers behind the fish */
 if(rk==='l'){fsLegendFx(g,el,x,y,x0,y0,px,col)}
 else if(rk==='r'&&el<hEnd+.2){const k=Math.min(1,el/.4)*(el>hEnd?1-(el-hEnd)/.2:1);fsRays(g,x,y,12,px*1.4,col,k*.55,t*.6);fkGlow(g,x,y,px*.9,col,.45*k);if(el<.12)fsFlash(g,col,.35*(1-el/.12))}
 else if(rk==='u'&&el<hEnd){const k=Math.min(1,el/.3);fkGlow(g,x,y,px*.7,col,.3*k)}
 /* one-time bursts */
 if(!S0.b1&&el>(rk==='l'?.8:.05)){S0.b1=1;fsSplash(x0,y0,true);if(rk==='l'){fsBurst(x0,y0,70,'drop',{a:-Math.PI/2,sp:1.2,v:520,g:500,life:1.5,c:'#e8f6ff',r:5});for(let i=0;i<3;i++)fsRing(x0,y0,i?'#ffe6a0':'#ffffff',10,220+i*120,1.2+i*.3,4)}}
 if(!S0.b2&&el>aEnd*.9){S0.b2=1;if(rk!=='c')fsBurst(x,y,rk==='l'?60:rk==='r'?34:18,'spark',{v:rk==='l'?420:260,g:rk==='l'?40:120,life:rk==='l'?1.6:1,c:rk==='u'?'#b6ffcc':rk==='r'?'#bfe4ff':'#fff2b0',r:rk==='l'?6:4});
  if(rk==='r'||rk==='l')fsRing(x,y,col,20,px*1.2,.9,4);if(rk==='u')fsRing(x,y,col,10,px*.8,.7,3);if(rk!=='c')fsBanner(rk==='l'?'LEGENDARY CATCH':rk==='r'?'Rare catch!':'',FISH[c.id].n,col,rk==='l'?2.6:1.3,rk)}
 if(rk==='l'&&el>aEnd&&el<hEnd&&Math.random()<.5)fsBurst(x+(Math.random()-.5)*900,-10,1,'gold',{a:Math.PI/2,sp:.4,v:90,g:120,life:2.4,c:Math.random()<.5?'#ffd45a':'#fff2b0',r:4});
 if(el<aEnd&&!fsRM()&&Math.random()<.8)fsBurst(x,y+6,rk==='c'?1:2,'drop',{v:70,g:520,life:.55,r:2.6,c:'#e0f2ff'});if(el<aEnd&&(rk==='r'||rk==='l')&&Math.random()<.5)fsBurst(x,y,1,'spark',{v:60,g:30,life:.6,c:col,r:3});
 /* the fish */
 g.save();g.globalAlpha=al;g.translate(x,y);g.rotate(rot);const sc=px/210*s;g.scale(sc,sc);if(rk!=='c')fkGlow(g,0,0,120,col,rk==='l'?.5:.25);fishDraw(g,c.id,{t,flex:el<aEnd?.8:.25,glow:rk==='l'||rk==='r'?1:0});g.restore();
 /* size stamp during the hold */
 if(rk!=='l'&&rk!=='c'&&el>aEnd&&el<hEnd+.1){const a=Math.min(1,(el-aEnd)*5)*Math.min(1,(hEnd+.1-el)*6);g.save();g.globalAlpha=a;g.textAlign='center';g.font="800 24px Poppins,system-ui,sans-serif";g.lineWidth=6;g.strokeStyle='#1b1024';const tx=`${c.cm} cm${c.g?'  ♛ GIANT':''}`;g.strokeText(tx,hx,hy+px*.42+30);g.fillStyle=c.g?'#ffd45a':'#fff8e8';g.fillText(tx,hx,hy+px*.42+30);g.restore()}
 /* name plate during the legendary hold */
 if(rk==='l'&&el>aEnd+.2&&el<hEnd){const a=Math.min(1,(el-aEnd-.2)*3)*Math.min(1,(hEnd-el)*3);g.save();g.globalAlpha=a;g.textAlign='center';g.font="400 54px 'Pirata One',Georgia,serif";g.lineWidth=8;g.strokeStyle='#1b1024';g.strokeText(FISH[c.id].n,hx,hy+px*.5+70);
  const q=g.createLinearGradient(0,hy+px*.5+30,0,hy+px*.5+80);q.addColorStop(0,'#fff6c0');q.addColorStop(1,'#ffb020');g.fillStyle=q;g.fillText(FISH[c.id].n,hx,hy+px*.5+70);g.font="700 22px Poppins,system-ui,sans-serif";g.fillStyle='#fff8e8';g.strokeText(`${c.cm} cm${c.g?' · GIANT':''}`,hx,hy+px*.5+104);g.fillText(`${c.cm} cm${c.g?' · GIANT':''}`,hx,hy+px*.5+104);g.restore()}}
function fsFlash(g,c,a){g.save();g.globalAlpha=a;g.fillStyle=c;g.fillRect(0,0,1600,900);g.restore()}
function fsRays(g,x,y,n,r,c,a,rot){if(a<=0)return;g.save();g.globalCompositeOperation='lighter';g.translate(x,y);g.rotate(rot);for(let i=0;i<n;i++){g.rotate(TAU/n);const q=g.createLinearGradient(0,0,r,0);q.addColorStop(0,c+Math.round(a*255).toString(16).padStart(2,'0'));q.addColorStop(1,c+'00');g.fillStyle=q;g.beginPath();g.moveTo(0,0);g.lineTo(r,-r*.09);g.lineTo(r,r*.09);g.closePath();g.fill()}g.restore()}
/* the legendary spectacle: churning water, a pillar of light, the fish rising in the beam, god rays, aurora ribbons and gold */
function fsLegendFx(g,el,x,y,x0,y0,px,col){const t=fsNow(),d=FS.show.dur,fade=el>d-.9?Math.max(0,(d-el)/.9):1;
 if(el<.85){const k=el/.85;for(let i=0;i<2;i++)if(Math.random()<.6)FS.pt.push({x:x0+(Math.random()-.5)*80*k,y:y0+Math.random()*10,vx:0,vy:-60-Math.random()*60,g:0,life:0,max:.6,k:'bub',c:'#d8f0ff',r:2+Math.random()*4});
  fkGlow(g,x0,y0,60+k*80,'#ffe6a0',.3*k);fsRing(x0,y0,'#ffffff',4,30+k*40,.3,1.4)}
 if(el>=.8){const k=Math.min(1,(el-.8)/.25)*fade,w=90+30*Math.sin(t*8);
  /* pillar of light */
  g.save();g.globalCompositeOperation='lighter';const q=g.createLinearGradient(x0-w,0,x0+w,0);q.addColorStop(0,'#fff2c000');q.addColorStop(.5,`rgba(255,242,192,${.55*k})`);q.addColorStop(1,'#fff2c000');g.fillStyle=q;g.fillRect(x0-w,0,w*2,y0+10);
  const q2=g.createLinearGradient(x0-w*.3,0,x0+w*.3,0);q2.addColorStop(0,'#ffffff00');q2.addColorStop(.5,`rgba(255,255,255,${.6*k})`);q2.addColorStop(1,'#ffffff00');g.fillStyle=q2;g.fillRect(x0-w*.3,0,w*.6,y0+10);g.restore();
  if(el<.95)fsFlash(g,'#fff6dc',.75*(1-(el-.8)/.15));
  /* aurora ribbons across the sky */
  g.save();g.globalCompositeOperation='lighter';for(let b=0;b<3;b++){g.beginPath();for(let i=0;i<=40;i++){const xx=i*40,yy=120+b*55+Math.sin(i*.35+t*1.2+b*2)*30;i?g.lineTo(xx,yy):g.moveTo(xx,yy)}for(let i=40;i>=0;i--){const xx=i*40,yy=120+b*55+Math.sin(i*.35+t*1.2+b*2)*30+44+Math.sin(i*.5+t+b)*14;g.lineTo(xx,yy)}g.closePath();
   const ag=g.createLinearGradient(0,0,1600,0);['#7affd8','#8a6aff','#ff7ae0','#ffd45a','#7affd8'].forEach((c,i)=>ag.addColorStop(i/4,c));g.fillStyle=ag;g.globalAlpha=.16*k;g.fill()}g.restore();
  /* god rays and halo behind the fish */
  fsRays(g,x,y,16,px*2.1,'#ffe6a0',.42*k,t*.35);fsRays(g,x,y,8,px*1.5,'#ffffff',.25*k,-t*.5);fkGlow(g,x,y,px*1.3,'#fff2c0',.55*k);
  /* orbiting sparkles */
  for(let i=0;i<10;i++){const a=t*1.4+i*TAU/10,r=px*.75+Math.sin(t*3+i)*12;fkSpark(g,x+Math.cos(a)*r,y+Math.sin(a)*r*.55,5+3*Math.sin(t*5+i),i%2?'#ffffff':'#ffe27a',k)}}}
/* ---------- input ---------- */
function fsKeyDown(e){if(!FS.on||!$('fsx')||S.mode!=='fish'||e.ctrlKey||e.metaKey||e.altKey)return;const ae=document.activeElement;if(ae&&ae!==inp&&/INPUT|TEXTAREA|SELECT/.test(ae.tagName))return;
 const k=e.key,mod=$('fsmod');if(mod&&!mod.hidden){if(k==='Escape'){e.preventDefault();e.stopImmediatePropagation();fsModal(null)}return}
 const stop=()=>{e.preventDefault();e.stopImmediatePropagation()};
 if(FS.tut){if(k===' '||k==='Enter'||k==='Escape'){stop();fsTutClose()}return}
 /* quick sell: Enter on the catch preview asks first, a second Enter sells; Esc only closes the question */
 if(FS.st==='reveal'&&FS.qs&&k==='Escape'){stop();fsQsOff();return}
 if(FS.st==='reveal'&&k==='Enter'){stop();if(e.repeat)return;if(FS.qs){fsQsOff();fsDecide(false)}else fsQsOn();return}
 if(k==='Escape'){stop();if((FS.st==='reel'||FS.st==='stage')&&!(FS.escT&&fsNow()-FS.escT<2.2)){FS.escT=fsNow();fsToast('Press Esc again to leave. The fish will get away.');return}fsLeave();return}
 if(FS.st==='reel'){if(k.length===1){stop();if(!e.repeat)fsType(k)}else if(k==='Backspace')stop();return}
 if(k===' '||k==='Enter'){if(e.repeat){stop();return}
  if(FS.st==='idle'){stop();fsCast()}else if(FS.st==='show'){stop();fsSkip()}else if(FS.st==='reveal'){stop();fsQsOff();if(!fsDefKeep(FS.pend)&&fsKeepWhy(FS.pend))fsToast('Your creel is full. Press S to sell it, or free a slot in your Fish Basket.');else fsDecide(fsDefKeep(FS.pend))}else stop();return}
 if(FS.st==='reveal'&&(k==='s'||k==='S')){stop();fsQsOff();fsDecide(false)}else if(FS.st==='reveal'&&(k==='k'||k==='K')){stop();fsQsOff();fsDecide(true)}}
document.addEventListener('keydown',fsKeyDown,true);
/* touch keyboards: the hidden input */
inp.addEventListener('beforeinput',e=>{if(S.mode!=='fish'||!FS.on)return;if(e.inputType!=='insertText'||!e.data)return;e.preventDefault();const v=e.data;if([...v].length!==1)return;if(FS.st==='reel')fsType(v);else if(v===' '&&FS.st==='idle')fsCast()});

/* cast trail, the flying bobber, the fish breaching between words and the line snapping */
function fsMotionFx(g,now){
 FS.trail=(FS.trail||[]).filter(p=>now-p.t<.2);if(FS.trail.length>1){g.save();g.lineCap='round';for(let i=1;i<FS.trail.length;i++){const a=FS.trail[i-1],b=FS.trail[i],k=1-(now-b.t)/.2;g.strokeStyle=`rgba(230,224,255,${k*.55})`;g.lineWidth=1+k*5;g.beginPath();g.moveTo(a.x,a.y);g.lineTo(b.x,b.y);g.stroke()}g.restore()}
 if(FS.st==='cast'&&FS.fly){const f=FS.fly,sk=FS.view.skin||fsSkin();g.save();g.translate(f.x,f.y);g.rotate(now*14);g.beginPath();g.arc(0,0,7,0,TAU);g.fillStyle=sk.bob[1];g.fill();g.beginPath();g.arc(0,0,7,Math.PI,TAU);g.fillStyle=sk.bob[0];g.fill();g.lineWidth=2.2;g.strokeStyle=FKO;g.beginPath();g.arc(0,0,7,0,TAU);g.stroke();g.restore()}
 const B=FS.breach;if(B&&FS.cur){const u=(now-B.t)/.75;if(u>=1){FS.breach=null}else{const px=fsFishPx(FS.cur)*.55,x=B.x+B.dir*u*60,y=B.y-Math.sin(u*Math.PI)*110,rot=B.dir*(-.9+u*1.8);
   if(u>.9&&!B.b2){B.b2=1;fsSplash(x,B.y,false)}if(Math.random()<.6)fsBurst(x,y,1,'drop',{v:50,g:500,life:.45,r:2.4});
   g.save();g.translate(x,y);g.rotate(rot);if(B.dir<0)g.scale(-1,1);const sc=px/210;g.scale(sc,sc);if(FSR[FS.cur.rk].k>=2)fkGlow(g,0,0,110,FSR[FS.cur.rk].c,.3);fishDraw(g,FS.cur.id,{t:now,flex:1});g.restore()}}
 const S0=FS.snap;if(S0){const u=(now-S0.t)/.6;if(u>=1)FS.snap=null;else{g.save();g.lineCap='round';g.globalAlpha=1-u;g.strokeStyle=(FS.view.skin||fsSkin()).ln;g.lineWidth=1.6;
   if(S0.tip){const T=S0.tip;g.beginPath();g.moveTo(T.x,T.y);g.quadraticCurveTo(T.x+30-u*60,T.y+20+u*30,T.x-20-u*50,T.y+40+u*70);g.stroke()}
   if(S0.bob){const Bb=S0.bob;g.beginPath();g.moveTo(Bb.x,Bb.y);g.quadraticCurveTo(Bb.x-40,Bb.y-30+u*40,Bb.x-90+u*20,Bb.y-10+u*60);g.stroke()}g.restore()}}}
