# python3 t_w10a.py [game.html] : Runestone Tower Defense 10.0 - Three Worlds (98a data, 98b rules): unlocks (no tower locks since 10.1), tier caps,
# waves per world, the sixteen monsters' abilities, the six map twists, jams, the boss naming, the hub's world tabs, locked-world card,
# world armory chests and next-world card, and that World 1 is unchanged.
import asyncio,os,sys,json
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:500]),flush=True)
    if not ok:FAIL.append(name)
SETUP="()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const r=RPP();r.new99j=1;r.dragon=1;r.stars={moss:3,frost:3,ember:3};for(const k in r.tut)r.tut[k]=1;save()}"
T=r"""()=>{const out={};const go=(m,fn)=>{rpStart(m);const R=RPX;R.tut=null;R.hold=false;R.supply=1e6;R.wave=3;R.wst='run';R.q=[];try{return fn(R)}finally{rpLeave()}};
 const step=(R,n)=>{for(let i=0;i<n;i++)rpStep(R,1/30)};
 const sp=(R,id,s)=>{const e=rpSpawn(id);e.s=s||200;return e};
 out.locks=[rpwTwLocked('hive'),rpwTwLocked('grav'),rpWorldOpen(2),rpWorldOpen(3),rpMapOpen2(RP_MAP('coral')),rpMapOpen2(RP_MAP('wreck'))];
 out.shell=go('coral',R=>{const e=sp(R,'shell');e.shT=.1;step(R,10);const a=[e.shIn>0,e.armor];const s0=e.s;step(R,10);a.push(Math.round(e.s-s0));step(R,60);a.push(e.armor,e.shIn>0);return a});
 out.puff=go('coral',R=>{const e=sp(R,'puffer');const a0=e.armor,sp0=e.sp;e.hp=e.mx*.4;step(R,2);return [e.puff,e.armor-a0,+(e.sp/sp0).toFixed(2)]});
 out.jelly=go('coral',R=>{const e=sp(R,'jelly');e.glT=.05;step(R,4);const hid=e.hide;const hp=e.hp;rpHurt(e,50,0,null);const t=rpTarget(R,{x:rpPos(R,e).x,y:rpPos(R,e).y,type:'ballista'},300,true,true,'first');return [hid,e.hp===hp,t===null]});
 out.brute=go('coral',R=>{const e=sp(R,'brute');e.hp=e.mx*.5;step(R,2);return [e.arm0,e.armor]});
 out.siren=go('coral',R=>{const s=sp(R,'siren',300),c=sp(R,'crab',320);s.sgT=.05;step(R,4);const sh=c.shield;const hp=c.hp;rpHurt(c,sh*.5,99,null);return [Math.round(sh),c.hp===hp]});
 out.ink=go('coral',R=>{const e=sp(R,'squid',150);const p=rpPos(R,e);const pd=[...R.pads].sort((a,b)=>Math.hypot(a.x-p.x,a.y-p.y)-Math.hypot(b.x-p.x,b.y-p.y))[0];rpBuild(pd,'ballista');pd.tw.build=1;e.hp=e.mx*.5;step(R,25);return [pd.tw.jam>0,pd.tw.jamBy,Math.hypot(pd.x-p.x,pd.y-p.y)|0]});
 out.lev=go('abyss',R=>{const e=sp(R,'leviathan',300);const n0=R.foes.length;e.hp=e.mx*.7;step(R,2);const a=[e.dive>0,e.hide];step(R,90);a.push(R.foes.filter(f=>f.id==='crab').length,e.dive<=0);return a});
 out.knight=go('meadow',R=>{const k=sp(R,'knight',400),k2=sp(R,'knight',380),c=sp(R,'cog',350);step(R,1);const hp=c.hp;rpHurt(c,10,99,null);return [c.guardK,+(hp-c.hp).toFixed(1),k2.guardK]});
 out.steam=go('meadow',R=>{const e=sp(R,'steam');e.hp=e.mx*.8;e.slowT=3;e.slowK=.5;step(R,2);return [e.vent>0,e.slowT]});
 out.tinker=go('meadow',R=>{const t=sp(R,'tinker',400),c=sp(R,'cog',420);const s0=c.sp;step(R,2);return [c.hasteK,+(c.sp/s0).toFixed(2)]});
 out.spring=go('meadow',R=>{const e=sp(R,'spring',200);e.lpT=.03;const s0=e.s;step(R,3);const mid=e.hide;step(R,20);return [mid,Math.round(e.s-s0)]});
 out.jammer=go('foundry',R=>{const e=sp(R,'jammer',100);e.hp=e.mx=1e7;let n=0;const tws=[];for(const p of R.pads.slice(0,6)){rpBuild(p,'ballista');p.tw.build=1;tws.push(p.tw)}step(R,300);return [tws.filter(t=>t.jamBy==='emp').length,e.emp.size]});
 out.titan=go('storm',R=>{const e=sp(R,'titan',300);const p=rpPos(R,e);const pd=[...R.pads].sort((a,b)=>Math.hypot(a.x-p.x,a.y-p.y)-Math.hypot(b.x-p.x,b.y-p.y))[0];rpBuild(pd,'frost');pd.tw.build=1;e.stT=.05;step(R,3);const a=[pd.tw.jam>0];const a0=e.armor;e.hp=e.mx*.6;step(R,2);a.push(e.shI,a0-e.armor);return a});
 out.tide=go('coral',R=>{const a=[];for(let i=0;i<30*30;i+=30){step(R,30);a.push(+R.tide.k.toFixed(2))}return a.join(',')});
 out.wade=go('coral',R=>{R.tide.t=4;step(R,1);const z=R.map.tide[0];const e=sp(R,'crab');let best=0,bd=1e9;for(let s=0;s<rpLen(R,e);s+=4){e.s=s;e._s=-1;const p=rpPos(R,e);const d=Math.hypot(p.x-z[0],p.y-z[1]);if(d<bd){bd=d;best=s}}e.s=best;e._s=-1;step(R,1);const hp=e.hp;rpHurt(e,10,99,null);const d1=hp-e.hp;const h2=e.hp;rpHurt(e,10,99,{type:'tide',dmg:0});return [e.wade,+d1.toFixed(1),+(h2-e.hp).toFixed(1)]});
 out.fog=go('wreck',R=>{const f=R.fog[0];f.x=600;f.y=420;f.rx=220;f.ry=120;f.v=0;const e=sp(R,'crab');let best=0;for(let s=0;s<rpLen(R,e);s+=4){e.s=s;e._s=-1;const p=rpPos(R,e);if(((p.x-600)/220)**2+((p.y-420)/120)**2<.3){best=s;break}}e.s=best;e._s=-1;step(R,1);const p=rpPos(R,e);const far=rpTarget(R,{x:p.x+300,y:p.y},400,true,true,'first'),near=rpTarget(R,{x:p.x+100,y:p.y},400,true,true,'first');return [e.fogd,far===null,near===e]});
 out.cannon=go('wreck',R=>{const e=sp(R,'brute',400);R.cannon.t=.05;const hp=e.hp;step(R,40);return [Math.round(hp-e.hp)]});
 out.whirl=go('abyss',R=>{const z=R.map.whirl[0];const e=sp(R,'puffer');let best=0,bd=1e9;for(let s=0;s<rpLen(R,e);s+=4){e.s=s;e._s=-1;const p=rpPos(R,e);const d=Math.hypot(p.x-z[0],p.y-z[1]);if(d<bd){bd=d;best=s}}const s0=e.sp;e.s=best;e._s=-1;step(R,1);return +(e.sp/s0).toFixed(2)});
 out.glow=go('abyss',R=>{const g=R.pads.filter(p=>p.glow).length;const p=R.pads.find(p=>p.glow);rpBuild(p,'ballista');return [g,p.tw.glowK]});
 out.gust=go('meadow',R=>{R.gust.t=.05;const e=sp(R,'gyro');const s0=e.sp;step(R,25);return [+(e.sp/s0).toFixed(2),+R.gust.k.toFixed(2)]});
 out.sw=go('foundry',R=>{R.wst='build';R.wave=1;R.q=[];rpWaveStart();const a=[R.wave,R.sw,R.foes.length?R.foes[0].pi:null];R.wst='build';R.foes=[];R.q=[];rpWaveStart();a.push(R.wave,R.sw);step(R,300);a.push([...new Set(R.foes.map(f=>f.pi))].join('/'));return a});
 out.conv=go('foundry',R=>{const z=R.map.conv[0];R.sw=0;const e=rpSpawn('cog',0);let best=0,bd=1e9;for(let s=0;s<rpLen(R,e);s+=4){e.s=s;e._s=-1;const p=rpPos(R,e);const d=Math.hypot(p.x-z[0],p.y-z[1]);if(d<bd){bd=d;best=s}}const s0=e.sp;e.s=best;e._s=-1;step(R,1);return +(e.sp/s0).toFixed(2)});
 out.storm=go('storm',R=>{const e=sp(R,'knight',300);R.boltT=.05;const hp=e.hp;step(R,4);const a=[Math.round(hp-e.hp),R.bolts.length>0];const rp=R.pads.filter(p=>p.rod).length;a.push(rp);for(const p of R.pads){rpBuild(p,'ballista');p.tw.build=1}R.boltTwT=.05;step(R,3);a.push(R.pads.filter(p=>p.tw&&p.tw.jam>0&&p.rod).length,R.pads.filter(p=>p.tw&&p.tw.jamBy==='bolt').length);return a});
 out.caps=['moss','coral','meadow','wonder'].map(m=>go(m,R=>{const p=R.pads[0];rpBuild(p,'ballista');p.tw.build=1;for(let i=0;i<5;i++){p.tw.upK=1;rpUpgrade(p.tw)}return [m,p.tw.tier]}));
 out.asc=go('coral',R=>{const r=RPP();r.asc={};const p=R.pads[0];rpBuild(p,'frost');p.tw.build=1;for(let i=0;i<4;i++){p.tw.upK=1;rpUpgrade(p.tw)}return [p.tw.tier,JSON.stringify(r.asc)]});
 out.waves=['coral','abyss','storm'].map(m=>{const M=RP_MAP(m);return [m,rpWave(M,1).map(g=>g.id+g.n).join(' '),rpWave(M,M.waves).map(g=>g.id+g.n).join(' ')]});
 return out}"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E(SETUP);o=await E(T)
        chk('unlocks: World 2 open with a star on Ember Crown, World 3 locked; the Hive and the Singularity Engine open from the start (10.1); Shipwreck Cove needs Coral Shallows',o['locks']==[False,False,True,False,True,False],o['locks'])
        chk('Shellback: hides in its shell (armor +12, stops), then walks on with its armor back',o['shell'][0] and o['shell'][1]==17 and o['shell'][2]<=2 and o['shell'][3]==5 and not o['shell'][4],o['shell'])
        chk('Puffer: puffs up below half health (armor +6, 25% slower)',o['puff']==[1,6,0.75],o['puff'])
        chk('Jellyglide: while glimmering it takes no damage and towers cannot target it',o['jelly']==[1,True,True],o['jelly'])
        chk('Barnacle Brute: its armor falls with its health',o['brute']==[14,7],o['brute'])
        chk('Siren: her song shields nearby monsters (the shield absorbs damage first)',o['siren'][0]>0 and o['siren'][1],o['siren'])
        chk('Inkling: below 60% it inks the nearest tower within reach: jammed',o['ink'][0] and o['ink'][1]=='ink',o['ink'])
        chk('Leviathan: dives out of reach at 75% and surfaces with four Crablings',o['lev']==[True,1,4,True],o['lev'])
        chk('Brass Knight: monsters right behind it take 25% less damage; knights do not guard each other',o['knight'][0]==0.25 and abs(o['knight'][1]-7.5)<.6 and o['knight'][2]==0,o['knight'])
        chk('Steam Golem: vents when hurt (speed burst, slows removed)',o['steam']==[True,0],o['steam'])
        chk('Chronotinker: nearby monsters move 25% faster',o['tinker']==[0.25,1.25],o['tinker'])
        chk('Springjack: leaps 80 px down the road, out of reach in mid-air',o['spring'][0]==1 and 85<=o['spring'][1]<=110,o['spring'])
        chk('Sparkjammer: jams each tower it passes once',o['jammer'][0]>=1 and o['jammer'][0]==o['jammer'][1],o['jammer'])
        chk('Titan: its stomp jams nearby towers; it sheds armor plates at 66%',o['titan']==[True,1,4],o['titan'])
        chk('Rising Tide: wading monsters take 20% less damage, but 50% more from the Tidecaller',o['wade']==[1,8,15],o['wade'])
        chk('Fog: a monster in the fog can only be targeted by towers close to it',o['fog']==[1,True,True],o['fog'])
        chk('the wreck\'s cannon hits the leading monster',o['cannon'][0]>50,o['cannon'])
        chk('whirlpools sweep monsters 40% faster; glowcap pads give towers +15% range',o['whirl']==1.4 and o['glow'][0]>0 and o['glow'][1]==1.15,[o['whirl'],o['glow']])
        chk('gales sweep flyers 80% faster',o['gust'][0]==1.8,o['gust'])
        chk('the switch track flips every wave and the whole wave takes its line; conveyors carry monsters 30% faster',o['sw'][1]==1 and o['sw'][4]==0 and o['sw'][5]=='0' and o['conv']==1.3,[o['sw'],o['conv']])
        chk('the storm strikes the leading monster; towers near a rod are never jammed by it',o['storm'][0]>0 and o['storm'][1] and o['storm'][2]>0 and o['storm'][3]==0,o['storm'])
        chk('tier caps: III in World 1, IV in World 2, V in World 3 and the Wonderland',[x[1] for x in o['caps']]==[3,4,5,5],o['caps'])
        chk('tier IV in World 2 does not count as a Wonderland ascension',o['asc']==[4,'{}'],o['asc'])
        chk('waves come from the world\'s monsters, with its boss on the last wave',all('leviathan' in w[2] for w in o['waves'][:2]) and 'titan' in o['waves'][2][2] and 'crab' in o['waves'][0][1] and 'cog' in o['waves'][2][1],o['waves'])
        r=await E("""()=>{rpStart('abyss');const R=RPX;R.tut=null;R.wave=R.map.waves-1;R.wst='build';rpWaveStart();const a=[R.banner&&R.banner.txt,rpName('behemoth',R),document.querySelector('#rpboss b')&&document.querySelector('#rpboss b').textContent];rpLeave();return a}""")
        chk('the boss is named and announced as the map\'s own boss (Kraken Leviathan), not the Behemoth',r[0]=='Kraken Leviathan!' and r[1]=='Kraken Leviathan' and (r[2] in (None,'Kraken Leviathan')),r)
        # hub
        await E("()=>{RPP().stars.coral=3;RPP().stars.wreck=1;save();RPSEL='moss';rampartsMenu()}");await pg.wait_for_timeout(1000)
        r=await E("()=>[ov.querySelectorAll('.rpwt').length,ov.querySelectorAll('.rpnode').length,!!ov.querySelector('.rpwt.on[data-w=\"1\"]'),!!ov.querySelector('.rpwt.lock[data-w=\"3\"]')]")
        chk('the hub has three world tabs; World 1 shows its four maps; World 3 is marked locked',r==[3,4,True,True],r)
        g0=await E("()=>P.gold");await pg.click('.rpwt[data-w="2"]');await pg.wait_for_timeout(1000)
        r=await E("()=>[RPW_VIEW,[...ov.querySelectorAll('.rpnode')].map(b=>b.dataset.m+(b.classList.contains('lock')?':L':'')).join(' '),P.gold,ov.querySelector('.rparmh b').textContent,!!ov.querySelector('.rpwtier'),ov.querySelector('.rpnr b')&&ov.querySelector('.rpnr b').textContent]")
        chk('World 2 tab: its three maps, the Tidebreak Armory pays the 3-star chest once, the tier IV note, next region Shipwreck Cove',r[0]==2 and r[1]=='coral wreck abyss' and r[2]-g0==3000 and r[3]=='Tidebreak Armory' and r[4] and r[5]=='Shipwreck Cove',r)
        await pg.screenshot(path=os.path.join(HERE,'shots','w10a_hub2.png'))
        await E("()=>{RPSEL='abyss';rampartsMenu()}");await pg.wait_for_timeout(800)
        r=await E("()=>[P.gold,!!document.getElementById('rpwnx'),document.querySelector('#rpwnx b')&&document.querySelector('#rpwnx b').textContent]")
        chk('the chest is not paid twice; the last map of World 2 offers the next world',r[0]-g0==3000 and r[1] and r[2]=='Skyforge Heights',r)
        await pg.click('#rpwnx');await pg.wait_for_timeout(900)
        r=await E("()=>[RPW_VIEW,!!ov.querySelector('.rpwlk'),document.getElementById('rpdef').classList.contains('lock')]")
        chk('World 3 locked: a card says how to reach it and the Defend button is locked',r==[3,True,True],r)
        await pg.screenshot(path=os.path.join(HERE,'shots','w10a_hub3_locked.png'))
        await pg.click('#rpwlkgo');await pg.wait_for_timeout(900)
        r=await E("()=>[RPW_VIEW,RPSEL]")
        chk('"Play Kraken\'s Maw" takes you to that map in World 2',r==[2,'abyss'],r)
        await pg.click('.rpwt[data-w="1"]');await pg.wait_for_timeout(900)
        r=await E("()=>[RPW_VIEW,ov.querySelectorAll('.rpnode').length,!!ov.querySelector('.rpnode[data-m=\"wonder\"]'),ov.querySelector('.rparmh b').textContent]")
        chk('back on World 1 everything is as before (four maps, the Wonderland, the Rampart Armory)',r==[1,4,True,'Rampart Armory'],r)
        chk('no page errors',not er,er)
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
