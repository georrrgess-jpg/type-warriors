/* ===== WILDCARD TABLE: the premium casino table =====
   Restyles the in-game table (wcTable in 89c, CSS in 89m) into a high-limit casino table: a padded leather rail with
   stitching, brass trim and a wood racetrack with an inlaid gold line; woven felt under a soft overhead spotlight with
   the dragon crests, the pile spots and the WILDCARD lettering printed into it; a deck with real card-edge thickness and
   a contact shadow, a neatly layered discard pile, velvet nameplates with brass studs and poker-chip card counts, a
   spotlight on the seat whose turn it is, a gliding direction track, and polished status, tool, WILD! and menu panels.
   Variants: green felt for Solo (the rail leather and the two inlaid chips take the table's chip colour from WCT), blue
   felt for rooms, navy and gold for Ranked (class rktbl).
   Why one image: the rail and felt hold hundreds of strokes, gradients, a blur and a woven texture. They are drawn as one
   standalone SVG (Blob URL, built once per variant) shown by an <img>, so Chrome rasterises it once and never repaints
   it per frame. The lettering stays inline (an image can't use the page's fonts). The direction arrows turn as a whole
   HTML layer (transform only) instead of an SVG group, so the spin costs no repaint. Everything else is static CSS;
   motion is transform/opacity only and stops in Performance mode and with reduced motion. The direction ring runs wider
   and taller than 89c's so its arrowheads clear the deck and discard at every angle, and it rests at 46deg (both heads in
   the gaps beside the piles) whenever the spin is off. Ids and classes are kept. */
const WC5={art:{},tile:null,ring:null};
const wc5hex=h=>{h=String(h||'#000').replace('#','');if(h.length===3)h=h.split('').map(x=>x+x).join('');return [0,2,4].map(i=>parseInt(h.substr(i,2),16)||0)};
const wc5mix=(a,b,t)=>{const A=wc5hex(a),B=wc5hex(b);return '#'+A.map((v,i)=>Math.round(v+(B[i]-v)*t).toString(16).padStart(2,'0')).join('')};
/* the felt weave: a 96 px tile of 2 px twill stripes plus a little grain, made once on a canvas (also the velvet nap) */
function wc5Tile(){if(WC5.tile!=null)return WC5.tile;let u='';
 try{const c=document.createElement('canvas');c.width=c.height=96;const g=c.getContext('2d'),im=g.createImageData(96,96),d=im.data;let s=90217;const r=()=>(s=(s*16807)%2147483647)/2147483647;
  for(let y=0;y<96;y++)for(let x=0;x<96;x++){const i=(y*96+x)*4,tw=(x+y)%4<2,v=r();let lite=!tw,a=tw?15:5;
   if(v<.14){lite=false;a+=16}else if(v>.9){lite=true;a+=12}d[i]=d[i+1]=d[i+2]=lite?255:0;d[i+3]=a}
  g.putImageData(im,0,0);u=c.toDataURL('image/png')}catch(e){}return WC5.tile=u}
/* the leather grain: a finer 64 px pebble (small soft cells with a dark rim and a lit top), so the rail reads as hide,
   not as the felt's twill */
function wc5Grain(){if(WC5.grain!=null)return WC5.grain;let u='';
 try{const c=document.createElement('canvas');c.width=c.height=64;const g=c.getContext('2d');let s=4471;const r=()=>(s=(s*16807)%2147483647)/2147483647;
  for(let i=0;i<150;i++){const x=r()*64,y=r()*64,R=1.2+r()*2.2;for(const dx of [-64,0,64])for(const dy of [-64,0,64]){
   g.beginPath();g.arc(x+dx,y+dy,R,0,7);g.strokeStyle='rgba(0,0,0,.2)';g.lineWidth=.9;g.stroke();
   g.beginPath();g.arc(x+dx-.4,y+dy-.6,R*.55,0,7);g.fillStyle='rgba(255,255,255,.07)';g.fill()}}
  u=c.toDataURL('image/png')}catch(e){}return WC5.grain=u}
/* the variant: felt, leather, stitching, wood and print colours. Every solo table keeps its leather in a warm dyed-hide
   family (cognac, espresso, tan, oxblood); the table's colour shows in the stitching and the inlaid chips. */
const WC5L={c50:['#6a2c14','#f0dcb4'],c250:['#44200f','#d2e2f4'],c1k:['#5e3a12','#ffe2a0'],c2k5:['#5a1018','#f2d6b8']};
function wc5Var(){const t=$('wct'),rk=t.classList.contains('rktbl'),blue=t.classList.contains('blue'),T=!rk&&!blue&&WX.mode==='solo'?WCT[WX.tbl]:null;
 if(rk)return{k:'rk',rk:1,fel:['#1f2f78','#101c50','#060b28'],lth:'#141c4c',sti:'#ffd45a',wd:['#060918','#1e2a5c'],ink:'#ffd45a',io:.46,t1:'WILDCARD',t2:'RANKED'};
 if(blue)return{k:'bl',fel:['#3a78da','#1f4ea8','#0c2662'],lth:'#2c2238',sti:'#e8d8bc',wd:['#2a1208','#6a3416'],ink:'#ffe39a',io:.32,t1:'WILDCARD',t2:'PRIVATE ROOM'};
 const L=T&&(WC5L[WX.tbl]||[wc5mix(T.chip2,'#2a0e08',.62),'#f0dcb4']);
 return{k:'g'+(T?WX.tbl:''),fel:['#34975f','#1d5e3b','#0c3020'],lth:L?L[0]:'#5a2416',sti:L?L[1]:'#f0dcb4',wd:['#2e1206','#743816'],ink:'#ffd45a',io:.32,t1:'WILDCARD',t2:'DRAGON LOUNGE'}}
/* the dragon crest from 89c, as plain paths so it can be printed into the felt */
const WC5CR='<path d="M0-34C-8-26-14-14-14 0-14 16-6 28 0 34 6 28 14 16 14 0 14-14 8-26 0-34Z"/><path d="M-14-6C-34-22-62-24-86-10-66-12-52-2-46 12-32 4-20 4-14 10"/><path d="M14-6C34-22 62-24 86-10 66-12 52-2 46 12 32 4 20 4 14 10"/><path d="M-6-40L0-52 6-40M-6 8L0 18 6 8"/><circle cx="0" cy="-6" r="5"/><path d="M-60-14L-56 2M-36-18L-34-2M60-14L56 2M36-18L34-2"/>';
/* the rail and felt as one standalone SVG (felt box 1360x648; rail 62 px; the pile centre is 26 px left of the table's) */
function wc5Art(V){if(WC5.art[V.k])return WC5.art[V.k];const cx=680,cy=324,tile=wc5Tile(),grain=wc5Grain();
 const so=V.rk?14:10,E=(o,a,dy)=>`<ellipse cx="${cx}" cy="${cy+(dy||0)}" rx="${680-o}" ry="${324-o}" ${a}/>`,L=V.lth;
 const L0=wc5mix(L,'#000',.55),L1=wc5mix(L,'#000',.25),L3=wc5mix(L,V.rk?'#fff':'#ffd8a8',.16),L4=wc5mix(L,V.rk?'#fff':'#ffe4b8',.46),ink=V.ink,io=V.io;
 const stud=(x,y)=>`<g transform="translate(${x} ${y})"><circle r="12.5" fill="#12081f"/><circle r="10" fill="url(#bs)"/>${V.rk?'<path d="M0-7L1.8-1.8 7 0 1.8 1.8 0 7-1.8 1.8-7 0-1.8-1.8Z" fill="#fff6c8" opacity=".9"/>':'<circle r="4.6" fill="none" stroke="#6a400a" stroke-width="1.4" opacity=".7"/>'}<ellipse cx="-3.4" cy="-4.2" rx="3.6" ry="2.2" fill="#fff" opacity=".55"/></g>`;
 const crest=(x,s)=>`<g transform="translate(${x} 326) scale(${s})" fill="none" stroke-linejoin="round" stroke-linecap="round"><g stroke="#000" stroke-width="3.4" opacity=".32" transform="translate(0 1.8)">${WC5CR}</g><g stroke="${ink}" stroke-width="2.3" opacity="${io+.06}">${WC5CR}</g><g stroke="#fff" stroke-width="1" opacity=".1" transform="translate(0 -1)">${WC5CR}</g></g>`;
 const frame=x=>`<rect x="${x}" y="216" width="146" height="207" rx="17" fill="#000" opacity=".07"/><rect x="${x}" y="216" width="146" height="207" rx="17" fill="none" stroke="${ink}" stroke-width="1.8" opacity="${io}"/><rect x="${x+6}" y="222" width="134" height="195" rx="12" fill="none" stroke="${ink}" stroke-width=".9" opacity="${io*.6}"/>`
  +[[x,216],[x+146,216],[x,423],[x+146,423]].map(p=>`<path d="M${p[0]} ${p[1]-5}l5 5-5 5-5-5z" fill="${ink}" opacity="${io+.1}"/>`).join('');
 let rk='';if(V.rk){rk+=`<rect x="0" y="0" width="1360" height="648" fill="url(#lt)"/><g stroke="${ink}" stroke-width="1.3" opacity=".11">`;
  for(let i=0;i<64;i++){const a=i*Math.PI/32;rk+=`<path d="M${(654+Math.cos(a)*300).toFixed(1)} ${(324+Math.sin(a)*156).toFixed(1)}L${(654+Math.cos(a)*720).toFixed(1)} ${(324+Math.sin(a)*380).toFixed(1)}"/>`}rk+='</g>'}
 const svg=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1360 648" width="1360" height="648"><defs>
<radialGradient id="fg" cx=".5" cy=".44" r=".6"><stop offset="0" stop-color="${V.fel[0]}"/><stop offset=".6" stop-color="${V.fel[1]}"/><stop offset="1" stop-color="${V.fel[2]}"/></radialGradient>
<radialGradient id="sp" cx=".48" cy=".38" r=".5"><stop offset="0" stop-color="#fff4d6" stop-opacity=".2"/><stop offset=".55" stop-color="#fff4d6" stop-opacity=".06"/><stop offset="1" stop-color="#fff4d6" stop-opacity="0"/></radialGradient>
<radialGradient id="vg" cx=".5" cy=".5" r=".5"><stop offset=".72" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".38"/></radialGradient>
<linearGradient id="lo" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".2"/><stop offset=".38" stop-color="#fff" stop-opacity="0"/><stop offset=".6" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".5"/></linearGradient>
<linearGradient id="br" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff6c4"/><stop offset=".22" stop-color="#e8b440"/><stop offset=".5" stop-color="#8e5c12"/><stop offset=".78" stop-color="#f2c656"/><stop offset="1" stop-color="#7a4c0c"/></linearGradient>
<radialGradient id="bs" cx=".38" cy=".32" r=".75"><stop offset="0" stop-color="#fff6c8"/><stop offset=".45" stop-color="#e8b03a"/><stop offset="1" stop-color="#6a400a"/></radialGradient>
<linearGradient id="wd" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${V.wd[1]}"/><stop offset=".5" stop-color="${V.wd[0]}"/><stop offset="1" stop-color="${V.wd[1]}"/></linearGradient>
${tile?`<pattern id="nz" width="96" height="96" patternUnits="userSpaceOnUse"><image href="${tile}" width="96" height="96"/></pattern>`:''}${grain?`<pattern id="gr" width="64" height="64" patternUnits="userSpaceOnUse"><image href="${grain}" width="64" height="64"/></pattern>`:''}
<pattern id="lt" width="44" height="44" patternUnits="userSpaceOnUse"><path d="M22 0L44 22 22 44 0 22Z" fill="none" stroke="${ink}" stroke-width="1" opacity=".13"/><circle cx="22" cy="22" r="1.8" fill="${ink}" opacity=".2"/></pattern>
<clipPath id="fc">${E(62,'')}</clipPath><filter id="bl" x="-5%" y="-10%" width="110%" height="120%"><feGaussianBlur stdDeviation="10"/></filter><filter id="b4" x="-3%" y="-6%" width="106%" height="112%"><feGaussianBlur stdDeviation="4"/></filter></defs>
${E(0,'fill="#12081f"')}
${E(26,`fill="none" stroke="${L0}" stroke-width="44"`)}${E(26,`fill="none" stroke="${L1}" stroke-width="37"`,-1)}${E(26,`fill="none" stroke="${L}" stroke-width="27"`,-2)}${E(26,`fill="none" stroke="${L3}" stroke-width="14"`,-3.5)}${E(26,`fill="none" stroke="${L4}" stroke-width="4" opacity=".3"`,-5)}
${grain?E(26,'fill="none" stroke="url(#gr)" stroke-width="44"'):''}${E(7,'fill="none" stroke="#000" stroke-width="7" opacity=".28" filter="url(#b4)"')}${E(25,`fill="none" stroke="${V.rk?'#dfe6ff':'#ffe6c4'}" stroke-width="13" opacity=".15" filter="url(#b4)"`,-3)}${E(26,'fill="none" stroke="url(#lo)" stroke-width="45"')}
${E(so,'fill="none" stroke="#000" stroke-width="2.6" opacity=".3"',.8)}${E(so,`fill="none" stroke="${V.sti}" stroke-width="1.6" stroke-dasharray="6 4.6" stroke-linecap="round" opacity=".8"`)}
${E(42,'fill="none" stroke="#000" stroke-width="2.6" opacity=".3"',.8)}${E(42,`fill="none" stroke="${V.sti}" stroke-width="1.6" stroke-dasharray="6 4.6" stroke-linecap="round" opacity=".8"`)}
${V.rk?E(6,'fill="none" stroke="url(#br)" stroke-width="8"')+E(10.4,'fill="none" stroke="#12081f" stroke-width="1.2" opacity=".6"')
 +E(21,`fill="none" stroke="${ink}" stroke-width=".9" opacity=".55"`,-1)+E(33,`fill="none" stroke="${ink}" stroke-width=".9" opacity=".55"`,-1)
 +E(27,'fill="none" stroke="#000" stroke-width="4.4" stroke-dasharray=".1 13" stroke-linecap="round" opacity=".4"',-.2)+E(27,'fill="none" stroke="url(#br)" stroke-width="3.6" stroke-dasharray=".1 13" stroke-linecap="round"',-1.4):''}${E(49,'fill="none" stroke="url(#br)" stroke-width="3.6"')}${E(51.5,'fill="none" stroke="#12081f" stroke-width="1.2" opacity=".6"')}
${E(56,'fill="none" stroke="url(#wd)" stroke-width="9.5"')}${E(53.5,'fill="none" stroke="#000" stroke-width=".8" stroke-dasharray="70 9 150 5 36 12" opacity=".22"')}${E(58.6,'fill="none" stroke="#fff" stroke-width=".8" stroke-dasharray="110 8 46 6" opacity=".09"')}
${E(56,`fill="none" stroke="#ffd45a" stroke-width="1.7"`)}${E(57.4,'fill="none" stroke="#000" stroke-width=".7" opacity=".4"')}
${E(61.4,'fill="none" stroke="url(#br)" stroke-width="3.2"')}
<g clip-path="url(#fc)">${E(62,'fill="url(#fg)"')}${tile?E(62,'fill="url(#nz)"'):''}${rk}${E(62,'fill="url(#sp)"')}
${E(88,`fill="none" stroke="${ink}" stroke-width="1.6" opacity="${io*.8}"`)}${E(94,`fill="none" stroke="${ink}" stroke-width=".8" opacity="${io*.5}"`)}
<ellipse cx="654" cy="324" rx="293" ry="167" fill="none" stroke="${ink}" stroke-width="2.4" stroke-dasharray=".1 10" stroke-linecap="round" opacity="${io+.08}"/><ellipse cx="654" cy="324" rx="313" ry="181" fill="none" stroke="${ink}" stroke-width="1" opacity="${io*.55}"/><ellipse cx="654" cy="324" rx="273" ry="153" fill="none" stroke="${ink}" stroke-width="1" opacity="${io*.55}"/>
${frame(471)}${frame(691)}${crest(250,.9)}${crest(1058,.9)}
${E(62,'fill="url(#vg)"')}${E(60,'fill="none" stroke="#000" stroke-width="34" opacity=".62" filter="url(#bl)"')}</g>
${E(63.4,'fill="none" stroke="#12081f" stroke-width="1.4" opacity=".7"')}
${stud(218,113)}${stud(1142,113)}${stud(218,535)}${stud(1142,535)}</svg>`;
 let u='';try{u=URL.createObjectURL(new Blob([svg],{type:'image/svg+xml'}))}catch(e){u='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg)}
 return WC5.art[V.k]=u}
/* the lettering printed into the felt along the upper arcs (inline, so it uses Pirata One) */
function wc5Print(V){const cx=680,cy=324,rx=516,ry=222,P=t=>{const a=t*Math.PI/180;return (cx+rx*Math.cos(a)).toFixed(1)+' '+(cy+ry*Math.sin(a)).toFixed(1)};
 const arc=(id,t0,t1)=>`<path id="${id}" d="M${P(t0)}A${rx} ${ry} 0 0 1 ${P(t1)}"/>`;
 const T=(id,s,sz)=>[['#000','.42','0 2'],[V.ink,String(V.io+.14),'0 0'],['#fff','.08','0 -1']].map(c=>`<text transform="translate(${c[2]})" fill="${c[0]}" opacity="${c[1]}" font-size="${sz}" letter-spacing="${sz>30?7:5}" text-anchor="middle"><textPath href="#${id}" startOffset="50%">${s}</textPath></text>`).join('');
 return `<svg class="wcprint" viewBox="0 0 1360 648" aria-hidden="true"><defs>${arc('wc5pa',204,247)}${arc('wc5pb',293,336)}</defs>${T('wc5pa',V.t1,38)}${T('wc5pb',V.t2,V.t2.length>9?30:38)}</svg>`}
/* the direction track: two comets of fading dots with chunky arrowheads; the whole layer turns, so nothing repaints */
function wc5Ring(){if(WC5.ring)return WC5.ring;const R=100,f2=v=>(+v).toFixed(2),pt=(t,r)=>{const a=t*Math.PI/180;return [r*Math.cos(a),r*Math.sin(a)]};let s='';
 for(const t0 of [196,16]){const te=t0+118;
  for(let i=0;i<14;i++){const f=i/13,a0=t0+i*(te-5-t0)/14,a1=a0+(te-5-t0)/14+.6,[x0,y0]=pt(a0,R),[x1,y1]=pt(a1,R);
   s+=`<path class="r5s" style="stroke-width:${f2(1.2+f*4.4)};opacity:${f2(.06+f*.9)}" d="M${f2(x0)} ${f2(y0)}A${R} ${R} 0 0 1 ${f2(x1)} ${f2(y1)}"/>`}
  const a=te*Math.PI/180,[hx,hy]=pt(te,R),tx=-Math.sin(a),ty=Math.cos(a),nx=Math.cos(a),ny=Math.sin(a),p=(u,v)=>f2(hx+tx*u+nx*v)+' '+f2(hy+ty*u+ny*v);
  s+=`<path class="r5h" d="M${p(14,0)}L${p(-7,8.5)}L${p(-2.5,0)}L${p(-7,-8.5)}Z"/>`}
 return WC5.ring=`<svg viewBox="-120 -120 240 240">${s}</svg>`}
/* Ranked: the player's rank insignia inlaid on the rail where Solo shows the table's chips */
function wc5Ins(){let h='';try{const r=rkSt().r;h=['l','r'].map(k=>`<span class="wc5chip ins ${k}">${rkInsig(r,86)}</span>`).join('')}catch(e){}return h}
function wc5Dress(){const t=$('wct');if(!t||t.classList.contains('wcv5'))return;const V=wc5Var(),T=V.k.length>1&&V.k[0]==='g'?WCT[WX.tbl]:null;
 t.classList.add('wcv5');const tile=wc5Tile();if(tile)t.style.setProperty('--wc5nz',`url(${tile})`);
 const f=t.querySelector('.wcfelt');if(f)f.insertAdjacentHTML('afterbegin',`<img class="wcart" alt="" draggable="false" src="${wc5Art(V)}">${wc5Print(V)}${T?`<span class="wc5chip l">${wcChip(WX.tbl,42)}</span><span class="wc5chip r">${wcChip(WX.tbl,42)}</span>`:V.rk?wc5Ins():''}`);
 const r=$('wcring');if(r)r.innerHTML=`<div class="wcrgf"><div class="wcrgr">${wc5Ring()}</div></div>`}
{const t0=wcTable;wcTable=function(){const r=t0.apply(this,arguments);try{wc5Dress()}catch(e){console.error(e)}return r}}
/* the in-game menu gets the table's crest above its title */
{const m0=wcMenu;wcMenu=function(){const r=m0.apply(this,arguments);try{const b=document.querySelector('.wct.wcv5 #wcmod:not([hidden]) .wcmnb');if(b&&!b.querySelector('.wc5mcr'))b.insertAdjacentHTML('afterbegin',`<i class="wc5mcr" aria-hidden="true"><svg viewBox="-96 -58 192 98"><g fill="none" stroke-linejoin="round" stroke-linecap="round"><g stroke="#12081f" stroke-width="7">${WC5CR}</g><g stroke="#ffd45a" stroke-width="3.4">${WC5CR}</g></g></svg></i>`)}catch(e){}return r}}

{const st=document.createElement('style');st.textContent=`
.wct.wcv5{--wc5nz:none;--rc:#ffd45a;--vel:#5c1a3a;--vel2:#2c0a20;--brs:linear-gradient(180deg,#fff2b4,#e2ac3c 34%,#8e5a12 62%,#f0c454 84%,#9a6410)}
.wct.wcv5.blue{--rc:#9ad2ff;--vel:#25327a;--vel2:#0e143e}.wct.wcv5.rktbl{--rc:#ffd45a;--vel:#1c2c78;--vel2:#0a1236}
/* the lounge round the table: warm overhead light, deep plum walls, dark corners */
.wct.wcv5 .wcbg{background:radial-gradient(ellipse 62% 58% at 50% 47%,#3e1644 0%,#250a32 42%,#11061c 74%,#07030c 100%)}
.wct.wcv5.blue .wcbg{background:radial-gradient(ellipse 62% 58% at 50% 47%,#262a6a 0%,#151848 42%,#0a0b26 74%,#040510 100%)}
.wct.wcv5.rktbl .wcbg{background:radial-gradient(circle,#ffd45a1c 1px,transparent 1.6px) 0 0/46px 46px,radial-gradient(ellipse 62% 58% at 50% 47%,#1e2c6a 0%,#111a48 42%,#080c26 74%,#03040e 100%)}
.wct.wcv5 .wcbg::before{content:'';position:absolute;left:50%;top:-60px;width:1500px;height:1000px;margin-left:-750px;background:radial-gradient(ellipse 42% 62% at 50% 0%,#ffe9bc24,#ffe9bc0a 55%,transparent 75%)}
.wct.wcv5 .wcbg::after{content:'';position:absolute;inset:0;background:radial-gradient(ellipse 75% 75% at 50% 50%,transparent 62%,#000000a8 100%)}
/* the table: one pre-drawn image (rail + felt) with the lettering and the table's chips on top */
.wct.wcv5 .wcfelt{border:0;border-radius:50%;background:radial-gradient(ellipse at 50% 44%,#2a7a50,#0c3020 80%,#12081f 81%);box-shadow:0 38px 60px -8px #000000e6,0 12px 26px #000a}
.wct.wcv5.blue .wcfelt{background:radial-gradient(ellipse at 50% 44%,#2a5096,#0d204e 80%,#12081f 81%)}.wct.wcv5.rktbl .wcfelt{background:radial-gradient(ellipse at 50% 44%,#1e3478,#0a133a 80%,#12081f 81%)}
.wct.wcv5 .wcfelt>i,.wct.wcv5 .wcemb,.wct.wcv5 .wcflt{display:none}
.wct.wcv5 .wcart,.wct.wcv5 .wcprint{position:absolute;left:0;top:0;width:1360px;height:648px;display:block;pointer-events:none;user-select:none}
.wct.wcv5 .wcprint{overflow:visible;font-family:'Pirata One',Georgia,serif}.wct.wcv5 .wcprint path{fill:none}
.wct.wcv5 .wc5chip{position:absolute;display:flex;align-items:center;justify-content:center;box-sizing:border-box;width:56px;height:56px;margin:-28px;top:113px;border-radius:50%;border:3px solid transparent;background:radial-gradient(circle at 50% 40%,#2a1a10,#0e0806 70%) padding-box,linear-gradient(160deg,#fff4c0,#e0a838 28%,#8a5410 56%,#ffd870 80%,#a86a14) border-box;box-shadow:0 0 0 2px #12081f,0 4px 6px #000b,inset 0 2px 5px #000c}
.wct.wcv5 .wc5chip.l{left:218px}.wct.wcv5 .wc5chip.r{left:1142px}.wct.wcv5 .wc5chip svg{display:block;flex:none}.wct.wcv5 .wc5chip>svg:not(.rkins){width:42px;height:42px}
/* Ranked: the insignia set into a navy medallion (its fanned cards rise just out of the bezel) */
.wct.wcv5 .wc5chip.ins{width:70px;height:70px;margin:-35px;background:radial-gradient(circle at 50% 38%,#24357e,#0a1236 72%) padding-box,linear-gradient(160deg,#fff4c0,#e0a838 28%,#8a5410 56%,#ffd870 80%,#a86a14) border-box}.wct.wcv5 .wc5chip.ins svg{width:86px;height:86px;margin-top:-2px;filter:drop-shadow(0 2px 1px #000a)}
/* the element light along the inside of the rail */
.wct.wcv5 .wcfglow{left:182px;top:154px;width:1236px;height:524px;box-shadow:inset 0 0 0 2px color-mix(in srgb,var(--gc,#ffd45a) 50%,transparent),inset 0 0 44px 3px color-mix(in srgb,var(--gc,#ffd45a) 30%,transparent);opacity:.85}
/* the direction track: the arrows glide round the printed track; .rev mirrors them */
.wct.wcv5 .wcring{opacity:.9}.wct.wcv5 .wcring.rev svg{transform:none}.wct.wcv5 .wcrgf,.wct.wcv5 .wcrgr{width:100%;height:100%}
.wct.wcv5 .wcrgf{transform:scale(1.1,1.2)}.wct.wcv5 .wcring.rev .wcrgf{transform:scale(-1.1,1.2)}
.wct.wcv5 .wcrgr{transform:rotate(46deg);animation:wc5spin 26s linear infinite}@keyframes wc5spin{from{transform:rotate(46deg)}to{transform:rotate(406deg)}}
.wct.wcv5 .wcring path.r5s{fill:none;stroke:var(--rc);stroke-linecap:round}
.wct.wcv5 .wcring path.r5h{fill:var(--rc);stroke:#12081f;stroke-width:2.6;stroke-linejoin:round;opacity:1}
/* the deck: a block of card edges under the top cards, sitting on its own shadow */
.wct.wcv5 .wcdeck::before{content:'';position:absolute;left:0;top:0;width:128px;height:187px;border-radius:13px;transform:translateY(13px);background:repeating-linear-gradient(180deg,#fbf4e4 0 1.5px,#b9ac94 1.5px 3px);box-shadow:0 0 0 2.5px #12081f,0 18px 20px -2px #000000d0,0 6px 8px #0009}
.wct.wcv5 .wcdeck .wcc{box-shadow:0 0 0 1.5px #12081f88}.wct.wcv5 .wcdeck .d3{transform:translateY(9px)}.wct.wcv5 .wcdeck .d2{transform:translateY(4.5px)}
.wct.wcv5 .wcdeck .d1{box-shadow:0 0 0 1.5px #12081f88,0 3px 6px #0006}.wct.wcv5 .wcdeck.can:hover .d1{transform:translateY(-12px) rotate(-1.5deg);box-shadow:0 0 0 1.5px #12081f88,0 14px 18px #000a}
.wct.wcv5 .wcdn{right:-16px;bottom:-22px;min-width:38px;height:38px;padding:0 7px;font:900 14px var(--ui);color:#2a1406;background:radial-gradient(circle at 38% 30%,#fff6c4,#f0b434 55%,#a8680e);border:2px solid #12081f;box-shadow:0 3px 0 #12081f,inset 0 0 0 2px #fff3b855}
.wct.wcv5 .wcdl{left:50%;right:auto;top:-40px;width:max-content;transform:translateX(-50%);padding:3px 12px 2px 14px;border-radius:9px;background:#12081fd9;border:1.5px solid #c8982c;box-shadow:0 0 0 1.5px #12081f,0 3px 8px #0009;text-shadow:0 1px 0 #12081f}
/* the discard: a contact shadow, older cards a touch darker so the top one reads */
.wct.wcv5 .wcdisc::before{content:'';position:absolute;left:-18px;right:-18px;bottom:-24px;height:50px;border-radius:50%;background:radial-gradient(closest-side,#000000b0,#0000 100%)}
.wct.wcv5 .wcdisc .wcc{box-shadow:0 0 0 1.5px #12081f66,0 4px 10px #0008}.wct.wcv5 .wcdisc .wcc:not(.top){filter:brightness(.82)}.wct.wcv5 .wcdisc .wcc.top{box-shadow:0 0 0 1.5px #12081f88,0 10px 18px #000a}
.wct.wcv5 .wcglow{opacity:.6}
/* seats: brass bezels, velvet nameplates with brass studs, poker-chip card counts */
.wct.wcv5 .wcav{border:4px solid transparent;background:radial-gradient(circle at 50% 38%,#4a3a8a,#160c34 72%) padding-box,linear-gradient(160deg,#fff4c0,#e0a838 28%,#8a5410 56%,#ffd870 80%,#a86a14) border-box;box-shadow:0 0 0 3px #12081f,0 10px 22px #000c}
.wct.wcv5 .wcseat.on .wcav{border-color:transparent;box-shadow:0 0 0 3px #12081f,0 0 0 6px #ffd45a,0 0 0 8px #12081f,0 0 30px 6px #ffd45a70}
.wct.wcv5 .wcseat.rare .wcav{background:radial-gradient(circle at 50% 38%,#4a3a8a,#160c34 72%) padding-box,linear-gradient(160deg,#ffe0f0,#ff9ad0 40%,#9ad8ff) border-box}
.wct.wcv5 .wcseat.catch .wcav{border-color:#ff5a6a}.wct.wcv5 .wcseat.frz .wcav{border-color:#8ad8ff}.wct.wcv5 .wcseat.won .wcav{border-color:#ffd45a}
.wct.wcv5 .wcnm{position:relative;margin-top:10px;padding:5px 24px 6px;border-radius:11px;border:2px solid transparent;background:var(--wc5nz) padding-box,linear-gradient(180deg,var(--vel),var(--vel2)) padding-box,var(--brs) border-box;box-shadow:0 0 0 2px #12081f,0 7px 14px #000b,inset 0 1px 0 #ffffff2a,inset 0 -6px 10px #0005}
.wct.wcv5 .wcnm::before,.wct.wcv5 .wcnm::after{content:'';position:absolute;top:50%;width:8px;height:8px;margin-top:-4px;border-radius:50%;background:radial-gradient(circle at 35% 30%,#fff8d0,#e0a838 50%,#6a400a);box-shadow:0 0 0 1.5px #12081f,0 1px 1px #000a}
.wct.wcv5 .wcnm::before{left:7px}.wct.wcv5 .wcnm::after{right:7px}
.wct.wcv5 .wcnm{max-width:214px;box-sizing:border-box}.wct.wcv5 .wcnm b{max-width:162px;color:#fff6e2;text-shadow:0 1.5px 0 #12081f;letter-spacing:.01em}
.wct.wcv5 .wcseat.on .wcnm{background:var(--wc5nz) padding-box,linear-gradient(180deg,var(--vel),var(--vel2)) padding-box,linear-gradient(180deg,#fffbe0,#ffd45a 40%,#c8901e) border-box;box-shadow:0 0 0 2px #12081f,0 0 22px #ffd45a66,0 7px 14px #000b,inset 0 1px 0 #ffffff2a}
.wct.wcv5 .wcseat.on .wcnm b{color:#ffe28a}
.wct.wcv5 .wcnm.rare{background:var(--wc5nz) padding-box,linear-gradient(90deg,#4a1650,#16245a) padding-box,linear-gradient(90deg,#ffb0dc,#9ad8ff) border-box}
.wct.wcv5 .wcn{min-width:38px;width:38px;height:38px;padding:0;border-radius:50%;top:-6px;color:#fff;font:900 15px/1 var(--ui);text-shadow:0 1.5px 0 #12081f;border:2px solid #12081f;background:radial-gradient(circle closest-side,#241a62 0 64%,#ffd45a 66% 74%,#0000 76%),repeating-conic-gradient(from -11.25deg,#e8a628 0 22.5deg,#fff4d4 22.5deg 45deg);box-shadow:0 3px 0 #12081f,0 5px 10px #0008}
/* whose turn: a warm light pool round the seat and a soft beam from above (opacity + transform only) */
.wct.wcv5 .wchalo{width:240px;height:240px;margin:-120px;background:radial-gradient(circle closest-side,#fff2c4b0 0%,#ffd45a66 26%,#ffd45a24 56%,#ffd45a00 100%);animation:none;transition:opacity .35s}
.wct.wcv5 .wchalo::before{content:'';position:absolute;left:50%;bottom:30%;width:190px;height:330px;margin-left:-95px;background:radial-gradient(closest-side at 50% 58%,#fff0c030,#fff0c012 52%,#fff0c000 100%)}
.wct.wcv5 .wcseat.p-l .wchalo::before,.wct.wcv5 .wcseat.p-r .wchalo::before{height:250px;opacity:.75}
.wct.wcv5 .wcseat.on .wchalo{opacity:1;animation:wc5halo 2.4s ease-in-out infinite alternate}@keyframes wc5halo{from{transform:scale(.92)}to{transform:scale(1.05)}}
/* the turn banner */
.wct.wcv5 .wcstat{top:612px;padding:9px 26px;border-radius:15px;border:2px solid transparent;background:linear-gradient(180deg,#261c62,#120c36) padding-box,linear-gradient(180deg,#9a8ae0,#3a2e80) border-box;box-shadow:0 0 0 2px #12081f,0 12px 26px #000b,inset 0 1px 0 #ffffff22;color:#f6f0ff}
.wct.wcv5 .wcstat::before,.wct.wcv5 .wcstat::after{content:'';position:absolute;top:50%;width:9px;height:9px;margin-top:-5.5px;transform:rotate(45deg);background:linear-gradient(135deg,#fff3b0,#e0a030);box-shadow:0 0 0 2px #12081f}
.wct.wcv5 .wcstat::before{left:-7px}.wct.wcv5 .wcstat::after{right:-7px}.wct.wcv5 .wcstat:empty{opacity:0}
.wct.wcv5 .wcstat.me{padding-left:8px;background:linear-gradient(90deg,#3e2c0e,#1e1648 42%,#120c36) padding-box,var(--brs) border-box}
.wct.wcv5 .wcyt{padding:3px 14px 2px;border-radius:9px;background:linear-gradient(180deg,#fff0a0,#f6bc3a 52%,#d88c16);box-shadow:inset 0 1px 0 #ffffffa0,0 2px 0 #12081f;text-shadow:0 1px 0 #fff4c080}
/* the +N stack badge */
.wct.wcv5 .wcstack{border:2px solid transparent;background:radial-gradient(circle at 50% 30%,#ff7484,#c0182e 60%,#7a0818) padding-box,var(--brs) border-box;box-shadow:0 0 0 3px #12081f,0 10px 20px #000b}
/* the top bar and the tool buttons */
.wct.wcv5 .wcpill{background:linear-gradient(180deg,#221a5af2,#110b34f2);border:2px solid #4a3c96;box-shadow:0 0 0 2px #12081f,0 6px 14px #0008,inset 0 1px 0 #ffffff1c;color:#d8ccf4}
.wct.wcv5 .wcpill.rkpil{border-color:#c8982c}.wct.wcv5 .wcpill.ok{border-color:#3a8a48}
.wct.wcv5 .wcmenu,.wct.wcv5 .wctb{border:2px solid transparent;background:linear-gradient(180deg,#30287a,#1a1352) padding-box,linear-gradient(180deg,#a090ee,#3a2e86) border-box;box-shadow:0 0 0 2px #12081f,0 5px 0 #0a0624,0 10px 18px #0008,inset 0 1px 0 #ffffff26;color:#fff6e2}
.wct.wcv5 .wctb{box-sizing:border-box;min-width:126px;height:48px;padding:0 18px 0 6px;gap:10px;border-radius:15px}
.wct.wcv5 .wctb svg,.wct.wcv5 .wcmenu svg{box-sizing:border-box;width:32px;height:32px;padding:6px;border-radius:50%;color:#2a1406;background:radial-gradient(circle at 38% 30%,#fff6c4,#f0b434 55%,#a8680e);box-shadow:0 0 0 2px #12081f}
.wct.wcv5 .wcmenu{padding:0 18px 0 7px;border-radius:15px}.wct.wcv5 .wcmenu:active,.wct.wcv5 .wctb:active:not(:disabled){transform:translateY(3px)}
.wct.wcv5 .wctb:disabled{opacity:.5}.wct.wcv5 .wctb:disabled svg{background:#5a5276}
.wct.wcv5 .rkemob.mom{border-color:var(--gold)}
/* the WILD! button: red lacquer dome in a knurled brass bezel */
.wct.wcv5 .wcone{width:146px;height:146px;border:0;font:400 42px 'Pirata One',Georgia,serif;letter-spacing:.02em;color:#fff;text-shadow:0 3px 0 #5a0610;-webkit-text-stroke:1.5px #12081f;paint-order:stroke fill;
 background:radial-gradient(circle closest-side,#ff7a7a 0,#e2283c 46%,#a00c20 64%,#12081f 65.5% 68.5%,#0000 69.5%),radial-gradient(circle closest-side,#0000 88%,#12081f 89%),repeating-conic-gradient(#fff2b4 0 5deg,#d29424 5deg 12deg,#8a5a10 12deg 15deg);box-shadow:0 0 0 3px #12081f,0 8px 0 #4a2a06,0 18px 32px #000c}
.wct.wcv5 .wcone::before{content:'';position:absolute;left:31%;top:20%;width:38%;height:20%;border-radius:50%;background:linear-gradient(180deg,#ffffff8c,#fff0);pointer-events:none}
.wct.wcv5 .wcone::after{content:'';position:absolute;inset:-16px;border-radius:50%;background:radial-gradient(circle closest-side,#ffd45a00 76%,#ffd45a99 86%,#ffd45a00 100%);opacity:0;pointer-events:none}
.wct.wcv5 .wcone span{position:relative}
.wct.wcv5 .wcone.can::after{animation:wc5ring 1.1s ease-in-out infinite alternate}@keyframes wc5ring{from{opacity:.25}to{opacity:1}}
.wct.wcv5 .wcone:disabled{opacity:.9;filter:none;cursor:default;color:#c8b0b8;text-shadow:none;-webkit-text-stroke:1.5px #12081f;
 background:radial-gradient(circle closest-side,#5a3a48 0,#3e2432 50%,#2a1622 64%,#12081f 65.5% 68.5%,#0000 69.5%),radial-gradient(circle closest-side,#0000 88%,#12081f 89%),repeating-conic-gradient(#8a7a60 0 5deg,#5a4a34 5deg 12deg,#3a2e1e 12deg 15deg);box-shadow:0 0 0 3px #12081f,0 6px 0 #1a1008,0 14px 26px #000a}
.wct.wcv5 .wcone:disabled::before{opacity:.25}
/* the in-game menu and the element picker: indigo glass in a brass frame */
.wct.wcv5 .wcmod{background:radial-gradient(ellipse at 50% 45%,#0a0414a8,#040108e0)}
.wct.wcv5 .wcmnb,.wct.wcv5 .wcpk .wcpkb{border:2px solid transparent;background:linear-gradient(180deg,#2a2070,#160f42 55%,#0e0a2c) padding-box,linear-gradient(180deg,#fff0b4,#d29a2c 30%,#6a4410 60%,#e8b850) border-box;box-shadow:0 0 0 3px #12081f,0 30px 70px #000d,inset 0 0 0 6px #0e0a2c,inset 0 0 0 7.5px #ffd45a44,inset 0 1px 0 #ffffff30}
.wct.wcv5 .wcmnb{width:460px;padding:30px 38px 26px;border-radius:26px}
.wct.wcv5 .wcmnb>b{display:flex;align-items:center;gap:14px;font-size:48px;text-shadow:0 3px 0 #12081f}
.wct.wcv5 .wcmnb>b::before,.wct.wcv5 .wcmnb>b::after{content:'';width:54px;height:10px;background:radial-gradient(circle,#ffd45a 0 3px,#0000 3.5px) right center/10px 10px no-repeat,linear-gradient(90deg,#ffd45a00,#ffd45a) left center/44px 2px no-repeat}
.wct.wcv5 .wcmnb>b::after{transform:scaleX(-1)}
.wct.wcv5 .wcmnb .wcpb{border:2px solid #4a3c96;background:linear-gradient(180deg,#2a2270,#17114a);box-shadow:0 0 0 2px #12081f,0 4px 0 #0a0624}.wct.wcv5 .wcmnb .wcpb svg{color:var(--gold)}
.wct.wcv5 .wcmnb .wcbtn{box-shadow:0 0 0 2px #12081f,0 5px 0 #0a0624}.wct.wcv5 .wcmnb .wcbtn.gold{box-shadow:0 0 0 2px #12081f,0 5px 0 #9a5a10,0 10px 22px #ffb02a33}.wct.wcv5 .wcmnb .wcbtn.red{box-shadow:0 0 0 2px #12081f,0 5px 0 #6a0a18}
.wct.wcv5 .wcmnb p{padding-top:8px;border-top:1px solid #ffd45a26;width:100%}
.wct.wcv5 .wc5mcr{display:block;width:118px;height:60px;margin:-6px 0 -10px;filter:drop-shadow(0 3px 0 #12081f)}.wct.wcv5 .wc5mcr svg{display:block;width:100%;height:100%}
.wct.wcv5 .wcmnb .wcbtn.gold{box-shadow:0 0 0 2px #12081f,0 5px 0 #9a5a10,0 10px 22px #ffb02a33,inset 0 2px 0 #fffbe0b0,inset 0 -3px 0 #c8801a66}
.wct.wcv5 .wcmnb .wcbtn.red{margin-top:10px}
/* Performance mode: the table stays, the looping light and spin stop */
body.pf-low .wct.wcv5 .wcrgr,body.pf-low .wct.wcv5 .wcseat.on .wchalo,body.pf-low .wct.wcv5 .wcone.can::after,body.pf-low .wct.wcv5 .wcseat.rare .wcav::before{animation:none}body.pf-low .wct.wcv5 .wcone.can::after{opacity:.8}
@media (prefers-reduced-motion:reduce){.wct.wcv5 .wcrgr,.wct.wcv5 .wcseat.on .wchalo,.wct.wcv5 .wcone.can::after,.wct.wcv5 .wcseat.rare .wcav::before{animation:none!important}.wct.wcv5 .wcone.can::after{opacity:.8}}
`;document.head.appendChild(st)}
