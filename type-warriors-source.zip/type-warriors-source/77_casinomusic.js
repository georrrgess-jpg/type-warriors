/* ---------- casino score: "The Dragon's Hoard", an epic adventure theme in D minor ----------
   32 bars of 4/4 at 116 bpm (about 66 s), then it loops:
   intro (4) -> A heroic brass theme (8) -> B soaring strings and choir (8) -> C full climax (8) -> outro (4)
   Everything is synthesised live: war drums, brass, spiccato strings, choir, harp and cymbals, through a hall reverb. */
const KS={on:0,n0:0,B:null,nb:null};
function kInit(){if(KS.B&&KS.ac===ac)return KS.B;KS.ac=ac;
 const rate=ac.sampleRate,len=rate*2.8|0,ir=ac.createBuffer(2,len,rate);
 for(let c=0;c<2;c++){const d=ir.getChannelData(c);let lp=0;for(let i=0;i<len;i++){lp+=((Math.random()*2-1)-lp)*(.55-.4*i/len);d[i]=lp*Math.pow(1-i/len,2.3)*2.2}}
 const mm=ac.createGain();mm.gain.value=.58;mm.connect(mg);const cv=ac.createConvolver();cv.buffer=ir;const wet=ac.createGain();wet.gain.value=.36;cv.connect(wet);wet.connect(mm);
 KS.nb=ac.createBuffer(1,rate,rate);{const d=KS.nb.getChannelData(0);for(let i=0;i<rate;i++)d[i]=Math.random()*2-1}
 const bus=s=>{const g=ac.createGain(),r=ac.createGain();r.gain.value=s;g.connect(mm);g.connect(r);r.connect(cv);return g};
 KS.B={br:bus(.55),st:bus(.5),pc:bus(.3),ch:bus(.9)};return KS.B}
/* one pitched voice: stacked oscillators -> opening low-pass -> swell/hold/release, optional vibrato */
function kv(t,f,d,o){const g=ac.createGain(),fl=ac.createBiquadFilter(),a=o.a||.04,r=o.r||.12,v=o.v||.05,lp=o.lp||2000,ty=o.ty||['sawtooth'],det=o.det||[0];
 fl.type='lowpass';fl.Q.value=o.q||.7;fl.frequency.setValueAtTime(lp*(o.f0||.45),t);fl.frequency.linearRampToValueAtTime(lp,t+a*1.6+.02);
 g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(v,t+a);g.gain.setValueAtTime(v,t+Math.max(a,d-.02));g.gain.exponentialRampToValueAtTime(.0001,t+d+r);
 const oc=ty.map((y,i)=>{const os=ac.createOscillator();os.type=y;os.frequency.value=f*((o.mul&&o.mul[i])||1);os.detune.value=det[i%det.length];os.connect(fl);return os});
 if(o.vib){const lf=ac.createOscillator(),lg=ac.createGain();lf.frequency.value=5.3;lg.gain.setValueAtTime(0,t);lg.gain.linearRampToValueAtTime(o.vib,t+.4);lf.connect(lg);for(const os of oc)lg.connect(os.detune);lf.start(t);lf.stop(t+d+r+.05)}
 fl.connect(g);g.connect(o.bus);for(const os of oc){os.start(t);os.stop(t+d+r+.05)}}
/* noise burst through a filter (snare body, cymbal, rim, swells) */
function kns(t,d,v,fc,ty,bus,q,att){const s=ac.createBufferSource(),f=ac.createBiquadFilter(),g=ac.createGain();att=att||.002;s.buffer=KS.nb;s.loop=true;f.type=ty;f.frequency.value=fc;f.Q.value=q||.8;
 g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(v,t+att);g.gain.exponentialRampToValueAtTime(.0001,t+att+d);s.connect(f);f.connect(g);g.connect(bus);s.start(t,Math.random()*.5);s.stop(t+att+d+.05)}
function ktaiko(t,v,f){const B=KS.B,o=ac.createOscillator(),g=ac.createGain();o.type='sine';o.frequency.setValueAtTime(f*2.3,t);o.frequency.exponentialRampToValueAtTime(f,t+.13);
 g.gain.setValueAtTime(v*.42,t);g.gain.exponentialRampToValueAtTime(.0001,t+1);o.connect(g);g.connect(B.pc);o.start(t);o.stop(t+1.05);kns(t,.07,v*.22,700,'bandpass',B.pc,.9)}
function ksnare(t,v){const B=KS.B;kns(t,.2,v*.2,1900,'bandpass',B.pc,.6);kns(t,.07,v*.12,6000,'highpass',B.pc);kv(t,200,.08,{ty:['triangle'],lp:900,a:.002,r:.08,v:v*.07,bus:B.pc})}
const KCH=(()=>{const m=r=>[r,'m'],M=r=>[r,'M'];return[m(0),m(0),M(-4),M(-5),                     /* intro  Dm Dm Bb A */
 m(0),M(-4),M(3),M(-2),m(0),M(-4),m(5),M(-5),                                                       /* A      Dm Bb F C | Dm Bb Gm A */
 m(5),M(-4),M(3),M(-2),m(5),M(-4),M(-5),M(-5),                                                      /* B      Gm Bb F C | Gm Bb A A */
 m(0),M(-4),M(3),M(-2),m(0),M(-4),M(-2),M(-5),                                                      /* C      Dm Bb F C | Dm Bb C A */
 M(-4),m(5),M(-5),M(-5)]})();                                                                       /* outro  Bb Gm A A */
/* melody: step:pitch:length (pitch in semitones above D2, so 24 = D4) */
const KMEL=(()=>{const a='0:36:3 3:34:1 4:31:2 6:36:2|0:32:3 3:31:1 4:27:2 6:32:2|0:34:3 3:31:1 4:27:2 6:31:2|0:38:3 3:36:1 4:34:2 6:29:2',
 a2='0:36:2 2:39:2 4:43:3 7:41:1|0:39:2 2:36:2 4:32:2 6:36:2|0:41:3 3:39:1 4:36:2 6:32:2|0:38:2 2:31:2 4:35:2 6:38:2',
 L=['0:24:7|0:27:2 2:31:2 4:36:4|0:32:6|0:35:2 2:38:2 4:31:4',a,a2,
  '0:32:4 4:36:4|0:39:4 4:36:2 6:32:2|0:31:2 2:34:2 4:39:4|0:38:4 4:41:3 7:38:1','0:36:4 4:41:4|0:39:3 3:41:1 4:36:4|0:35:2 2:38:2 4:43:4|0:41:2 2:38:2 4:35:2 6:38:2',
  a,'0:36:2 2:39:2 4:43:3 7:41:1|0:39:2 2:36:2 4:32:2 6:39:2|0:38:3 3:41:1 4:38:2 6:34:2|0:43:4 4:38:4',
  '0:36:4 4:32:4|0:32:4 4:29:4|0:31:4 4:35:4|0:38:6'].join('|').split('|');
 return L.map(s=>s.split(' ').map(x=>x.split(':').map(Number)))})();
const kSec=b=>b<4?0:b<12?1:b<20?2:b<28?3:4;
function kscore(t,n0){if(!KS.on){KS.on=1;KS.n0=n0}const n=n0-KS.n0,B=kInit(),bar=(n>>3)&31,k=n&7,sec=kSec(bar),sd=stepD(),bl=sd*8,[r,q]=KCH[bar],th=q==='m'?3:4,F=m=>fq(m);
 const tones=[r,r+th,r+7],crest=(bar===20||bar===24)&&k===0;
 /* ---- harmony: sustained strings ---- */
 if(k===0){const lv=[.009,.018,.024,.028,.016][sec];for(const iv of tones)kv(t,F(iv+12),bl*.96,{ty:['sawtooth','sawtooth'],det:[-9,9],lp:1100+sec*250,a:.45,r:.6,v:lv,bus:B.st});
  kv(t,F(r),bl*.96,{ty:['sawtooth','sine'],det:[0,0],mul:[1,.5],lp:380,a:.12,r:.4,v:[.035,.052,.05,.06,.045][sec],bus:B.br})}
 /* ---- driving bass pulse in the climax ---- */
 if(sec===3&&k%2===1)kv(t,F(r),sd*.9,{ty:['sawtooth'],lp:560,a:.01,r:.08,v:.05,bus:B.br});
 /* ---- ostinato strings: root-fifth-octave rolling figure ---- */
 if(sec>=1){const fig=[0,7,12,7,0,7,12,th+12][k],ac1=[1,.6,.8,.6,.95,.6,.8,.7][k],lv=sec===2?.02:sec===3?.042:sec===4?.026:.034;
  kv(t,F(r+24+fig),sd*.82,{ty:['sawtooth','sawtooth'],det:[-8,8],lp:2500,a:.008,r:.07,v:lv*ac1,bus:B.st,f0:.55})}
 /* ---- harp arpeggios: intro and the soaring middle ---- */
 if(sec===0||sec===2){const ar=[0,th,7,12,7,th+12,12,7][k],lv=sec===0?.024:.034;kv(t,F(r+24+ar+(sec===2&&k>=4?12:0)),.9,{ty:['triangle','sine'],mul:[1,2],lp:5200,a:.004,r:.3,v:lv,bus:B.st,f0:1})}
 /* sparkling top line over the climax */
 if(sec===3&&k%2===0)kv(t,F(r+48+[0,th,7,12][k>>1]),.5,{ty:['triangle'],lp:6000,a:.003,r:.2,v:.016,bus:B.st,f0:1});
 /* ---- melody ---- */
 const ph=KMEL[bar];for(const [st,p,len] of ph){if(st!==k)continue;const d=len*sd*.97,f=F(p);
  if(sec===0)kv(t,f,d,{ty:['sawtooth','sawtooth'],det:[-7,7],lp:1500,a:.2,r:.4,v:.03,vib:7,bus:B.br,q:1.1});
  else if(sec===1||sec===3){const big=sec===3;
   kv(t,f,d,{ty:['sawtooth','sawtooth','square'],mul:[1,1,.5],det:[-6,6,0],lp:big?3200:2700,f0:.3,a:.08,r:.14,v:big?.075:.062,vib:big?9:7,bus:B.br,q:1.2});
   if(big){kv(t,f*Math.pow(2,-7/12),d,{ty:['sawtooth','sawtooth'],det:[-5,5],lp:2400,f0:.3,a:.09,r:.14,v:.052,vib:8,bus:B.br,q:1.1});
    kv(t,f*.5,d,{ty:['sawtooth'],lp:900,a:.1,r:.14,v:.028,bus:B.br})}}
  else if(sec===2){kv(t,f,d,{ty:['sawtooth','sawtooth'],det:[-11,11],lp:4200,f0:.35,a:.1,r:.22,v:.048,vib:11,bus:B.st});
   kv(t,f*2,d,{ty:['triangle'],lp:5000,a:.12,r:.2,v:.011,vib:9,bus:B.st});
   kv(t,f*Math.pow(2,-4/12),d,{ty:['sawtooth','sawtooth'],det:[-9,9],lp:2600,a:.12,r:.2,v:.022,vib:8,bus:B.st})}
  else kv(t,f,d,{ty:['sawtooth','sawtooth'],det:[-6,6],lp:2000,f0:.3,a:.1,r:.3,v:.04,vib:7,bus:B.br})}
 /* ---- choir ooh/aah on the lift and the climax ---- */
 if(k===0&&(sec===2||sec===3)){for(const iv of tones){const f=F(iv+24);for(const dt of[-6,6]){const o=ac.createOscillator(),g=ac.createGain();o.type='sawtooth';o.frequency.value=f;o.detune.value=dt;
   for(const [fc,qq,gg] of[[680,5,1],[1120,6,.7],[2600,6,.25]]){const b=ac.createBiquadFilter();b.type='bandpass';b.frequency.value=fc;b.Q.value=qq;const e=ac.createGain();e.gain.value=gg;o.connect(b);b.connect(e);e.connect(g)}
   g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(sec===3?.068:.042,t+bl*.4);g.gain.setValueAtTime(sec===3?.068:.042,t+bl*.85);g.gain.exponentialRampToValueAtTime(.0001,t+bl*1.12);g.connect(B.ch);o.start(t);o.stop(t+bl*1.15)}}}
 /* ---- percussion ---- */
 const tf=F(r);
 if(sec===0){if(k===0)ktaiko(t,bar===0?.55:.7,tf);if(bar===3){if(k===0)kns(t,.9,.045,5200,'highpass',B.pc,.7,bl*.95);if(k===6)ktaiko(t,.5,tf);if(k===7)ktaiko(t,.6,tf)}}
 else if(sec===1){if(k===0)ktaiko(t,.9,tf);if(k===4)ktaiko(t,.65,tf);if(k===6)ktaiko(t,.35,tf*1.5);if(k===2||k===6)kns(t,.04,.05,3500,'highpass',B.pc);if(k===0&&bar===4)kns(t,1.4,.05,5200,'highpass',B.pc,.7,.01)}
 else if(sec===2){if(k===0)ktaiko(t,.7,tf);if(k===4)ktaiko(t,.5,tf);
  if(bar>=18){const cr=(bar-18)*8+k;ksnare(t,.2+cr/16*.7);ksnare(t+sd/2,.15+cr/16*.7)}
  if(bar===19&&k===0)kns(t,.9,.06,5200,'highpass',B.pc,.7,bl*.95)}
 else if(sec===3){if(k===0)ktaiko(t,1,tf);if(k===2)ktaiko(t,.45,tf*1.5);if(k===4)ktaiko(t,.85,tf);if(k===6)ktaiko(t,.5,tf*1.5);if(k===2||k===6)ksnare(t,.75);
  if(k%2===1)kns(t,.05,.05,7000,'highpass',B.pc);if(crest){kns(t,2.2,.12,4800,'highpass',B.pc,.7,.004);ktaiko(t,1.1,tf*.75)}}
 else{if(k===0)ktaiko(t,.8,tf);if(k===4)ktaiko(t,.55,tf);
  if(bar===31){ktaiko(t,.3+k*.1,tf*(k>5?1.5:1));ktaiko(t+sd/2,.25+k*.1,tf);if(k===0)kns(t,1.1,.07,5200,'highpass',B.pc,.7,bl*.95)}
  if(bar===28&&k===0)kns(t,1.6,.07,4800,'highpass',B.pc,.7,.004)}}
