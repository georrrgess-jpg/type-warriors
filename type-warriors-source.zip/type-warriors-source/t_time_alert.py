# Last 5 seconds countdown (89x_time_alert.js) in every timed game, its sounds, and the settings.
# Run: python3 t_time_alert.py [out.html]
import asyncio,os,sys,time
from playwright.async_api import async_playwright
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:300]),flush=True)
    if not ok:FAIL.append(name)
SPY="""()=>{window.__snd=[];if(!window.__spied){window.__spied=1;const b0=beep;beep=function(f){__snd.push(['beep',Math.round(f),Date.now()]);return b0.apply(this,arguments)};const w0=wcFx;
 /* wcFx is wrapped by the countdown; spy on the inner tick by watching WCFX.tick */const t0=WCFX.tick;WCFX.tick=function(){__snd.push(['wctick',0,Date.now()]);return t0.apply(this,arguments)}}}"""
STATE="()=>{const e=document.getElementById('tacd');return e&&!e.hidden?[+e.querySelector('.tanum').textContent,e.classList.contains('low'),e.querySelector('.talab').textContent,Math.round(parseFloat(e.style.left)),Math.round(parseFloat(e.style.top))]:null}"
async def watch(pg,secs):
    seen=[]
    t=time.time()
    while time.time()-t<secs:
        s=await pg.evaluate(STATE)
        if s and (not seen or seen[-1][0]!=s[0]):seen.append(s)
        await pg.wait_for_timeout(120)
    return seen
async def main():
    html='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else 'out.html')
    er=[]
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required'])
        async def page():
            c=await b.new_context(viewport={'width':1600,'height':900});pg=await c.new_page();pg.on('pageerror',lambda e:er.append(str(e)[:300]))
            await pg.goto(html);await pg.wait_for_timeout(1200);await pg.mouse.click(5,5)
            await pg.evaluate("()=>{RS_ASK=false;ST.tacd='on';ST.svol=.8;saveST();try{ensureAudio()}catch(e){}}");return pg
        # ---------------- Wildcard Ranked: your own 15-second turn
        pg=await page();E=pg.evaluate
        await E("()=>{WCRELAYS=[];delete P.rk;save();rkStart()}");await E(SPY)
        t=time.time()
        while time.time()-t<60 and not await E("()=>WX.G&&WX.G.turn===WX.me&&WX.G.phase==='play'&&!WX.busy"):await pg.wait_for_timeout(200)
        await E("()=>{__snd=[]}")
        r=await E(STATE);chk('nothing shown at the start of your turn',r is None,r)
        seen=await watch(pg,16)
        nums=[s[0] for s in seen]
        chk('ranked turn: 5-4-3-2-1 in the last 5 seconds',nums==[5,4,3,2,1],nums)
        chk('turns red at 3 seconds',all(s[1]==(s[0]<=3) for s in seen),seen)
        chk('label says seconds left / second left',seen and seen[0][2]=='seconds left' and seen[-1][2]=='second left',seen)
        chk('placed between the pile and your hand',seen and seen[0][3:]==[800,560],seen[:1])
        snd=await E("()=>__snd")
        beeps=[x for x in snd if x[0]=='beep'];ticks=[x for x in snd if x[0]=='wctick']
        chk('one tick per second (5), old 3-2-1 ticks replaced',len(beeps)==5 and len(ticks)==0,(len(beeps),len(ticks)))
        r=await E(STATE);chk('gone when the turn timed out',r is None,r)
        await pg.screenshot(path='shots/ta_none.png')
        # screenshot mid-countdown
        t=time.time()
        while time.time()-t<90:
            s=await E(STATE)
            if s and s[0]==4:break
            await pg.wait_for_timeout(100)
        await pg.wait_for_timeout(250);await pg.screenshot(path='shots/ta_wildcard_4.png')
        t=time.time()
        while time.time()-t<10:
            s=await E(STATE)
            if s and s[0]==2:break
            await pg.wait_for_timeout(100)
        await pg.wait_for_timeout(250);await pg.screenshot(path='shots/ta_wildcard_2.png')
        # never on someone else's turn
        bad=0
        t=time.time()
        while time.time()-t<20:
            r=await E("()=>[WX.G&&WX.G.turn===WX.me,!!document.querySelector('#tacd:not([hidden])')]")
            if r[1] and not r[0]:bad+=1
            await pg.wait_for_timeout(150)
        chk('never shown on an opponent\'s turn',bad==0,bad)
        # Silent and Off
        await E("()=>{ST.tacd='quiet';__snd=[]}")
        t=time.time()
        while time.time()-t<60 and not await E("()=>!!document.querySelector('#tacd:not([hidden])')"):await pg.wait_for_timeout(150)
        await pg.wait_for_timeout(5500);snd=await E("()=>__snd")
        chk('Silent: countdown shows without ticks',not [x for x in snd if x[0] in('beep','wctick')],snd[:5])
        # let the last match's result screens finish (three timeouts end it), then a fresh match
        await pg.wait_for_timeout(5000);await E("()=>{ST.tacd='off';WX.tok++;wcClear();WX.G=null;WX.rk=null;delete P.rk;save();rkHub()}");await pg.wait_for_timeout(1500)
        await E("()=>rkStart()");await pg.wait_for_timeout(1500);await E("()=>{__snd=[]}")
        shown=0;t=time.time()
        while time.time()-t<35:
            if await E("()=>!!document.querySelector('#tacd:not([hidden])')"):shown+=1
            await pg.wait_for_timeout(150)
        snd=await E("()=>__snd")
        chk('Off: no countdown, the old 3-2-1 ticks come back',shown==0 and len([x for x in snd if x[0]=='wctick'])>=3,(shown,len(snd),await E("()=>[!!document.getElementById('wct'),WX.G&&WX.G.phase]")))
        await E("()=>{ST.tacd='on'}")
        # a Wildcard room without a timer: never shown
        await E("()=>{WX.tok++;wcClear();WX.G=null;WX.rk=null;wcHome()}");await pg.wait_for_timeout(600)
        await E("()=>wcStartSolo('c250',true)");await pg.wait_for_timeout(1500)
        r=await E("()=>[!!document.getElementById('wct'),WX.cfg&&WX.cfg.timer]")
        shown=0
        if r[0]:
            t=time.time()
            while time.time()-t<20:
                if await E("()=>!!document.querySelector('#tacd:not([hidden])')"):shown+=1
                await pg.wait_for_timeout(200)
        chk('untimed Wildcard table: no countdown',r[0] and not r[1] and shown==0,(r,shown))
        await pg.context.close()
        # ---------------- Casino Quiz
        pg=await page();E=pg.evaluate
        await E("()=>{P.gold=50000;save();gameOpen('qz')}");await pg.wait_for_timeout(800)
        await pg.click('.chip.c100');await pg.click('#qgo');await pg.wait_for_timeout(1000)
        await pg.click('.qt >> nth=0');await pg.wait_for_timeout(600)
        if await E("()=>!document.getElementById('qtn')"):
            bs=await E("()=>[...document.querySelectorAll('#cg button')].map(b=>b.id||b.textContent.trim()).slice(0,8)");print('   quiz wager step:',bs)
            await E("()=>{const b=[...document.querySelectorAll('#cg button')].find(b=>/wager|lock|go|confirm/i.test(b.textContent));b&&b.click()}");await pg.wait_for_timeout(500)
        secs=await E("()=>+document.getElementById('qtn').textContent")
        seen=await watch(pg,secs+1.5)
        nums=[s[0] for s in seen]
        chk(f'quiz clue ({secs}s): 5-4-3-2-1',nums==[5,4,3,2,1],nums)
        await pg.screenshot(path='shots/ta_quiz.png')
        r=await E(STATE);chk('quiz: gone once the clue is answered or timed out',r is None,r)
        await pg.wait_for_timeout(3000);await E("()=>{const q=document.querySelector('.qt:not([disabled])');q&&q.click()}")
        await pg.wait_for_timeout(600)
        if await E("()=>!!document.getElementById('qtn')"):
            t=time.time()
            while time.time()-t<30 and not await E("()=>!!document.querySelector('#tacd:not([hidden])')"):await pg.wait_for_timeout(100)
            await pg.wait_for_timeout(300);await pg.screenshot(path='shots/ta_quiz.png')
            await E("()=>document.querySelector('.qa button').click()");await pg.wait_for_timeout(300)
            r=await E(STATE);chk('quiz: answering hides it at once',r is None,r)
        await pg.context.close()
        # ---------------- Trick-or-Treat
        pg=await page();E=pg.evaluate
        ok=await E("()=>{try{if(!hwOn())return 'event off';P.treatData.active=null;TRT.run=null;ttNewRun(0);ttChoose(0);return TRT.run&&TRT.run.phase}catch(e){return String(e)}}")
        if ok=='typing':
            await E("()=>{const r=TRT.run;r.walk=0;r.greet=0;r.freeze=0;r.remaining=7.2}")
            seen=await watch(pg,8.5);nums=[s[0] for s in seen]
            chk('Trick-or-Treat doorstep: 5-4-3-2-1',nums==[5,4,3,2,1] or nums[:4]==[5,4,3,2],nums)
            await E("()=>{TRT.run&&ttScreen&&0}")
            ok2=await E("()=>{if(!TRT.run||TRT.run.phase!=='typing'){P.treatData.active=null;TRT.run=null;ttNewRun(0);ttChoose(0)}const r=TRT.run;r.walk=0;r.greet=0;r.remaining=4.5;r.freeze=3;return r.phase}")
            await pg.wait_for_timeout(500);r=await E(STATE)
            chk('Trick-or-Treat: hidden while Moonfreeze holds the clock',r is None,r)
            await E("()=>{TRT.run.freeze=0;TRT.run.remaining=4.4}");await pg.wait_for_timeout(500)
            r=await E(STATE);chk('Trick-or-Treat: back when the clock runs',r and r[0]==4,r)
            await pg.screenshot(path='shots/ta_treat.png')
        else:
            print('   Trick-or-Treat not started:',ok)
        await pg.context.close()
        # ---------------- Practice (60-second drill) and Starfall Rift
        pg=await page();E=pg.evaluate
        await E("()=>{start(0,'prac')}");await pg.wait_for_timeout(500)
        r=await E("()=>[S.mode,S.prac&&S.prac.goal,S.prac&&S.prac.gn]")
        if r[1]!='time':await E("()=>{S.prac.goal='time';S.prac.gn=60}")
        await E("()=>{S.ban=null;S.pel=S.prac.gn-6.3}")
        seen=await watch(pg,7.5);nums=[s[0] for s in seen]
        chk('timed Practice: 5-4-3-2-1 at the top',nums[:4]==[5,4,3,2] and seen[0][3:]==[800,132],seen)
        await E("()=>{start(0,'prac');S.ban=null;S.prac.goal='time';S.prac.gn=60;S.pel=56.5}");await pg.wait_for_timeout(400)
        await E("()=>pause&&pause()");await pg.wait_for_timeout(400)
        r=await E(STATE);chk('paused game: hidden',r is None,[r,await E("()=>S.mode")])
        await E("()=>{start(0,'prac');S.ban=null;S.prac.goal='time';S.prac.gn=60;S.pel=56.2}");await pg.wait_for_timeout(500);await pg.screenshot(path='shots/ta_practice.png')
        await E("()=>{start(0,'rift');S.ban=null;S.time=4.6}");await pg.wait_for_timeout(500)
        r=await E(STATE);chk('Starfall Rift: shown when the clock is low',r and r[0] in (4,5),r)
        await E("()=>{S.time=12}");await pg.wait_for_timeout(300)
        r=await E(STATE);chk('Starfall Rift: hides again when time is added',r is None,r)
        await E("()=>{start(0)}");await pg.wait_for_timeout(1500)
        r=await E(STATE);chk('untimed campaign: nothing',r is None,r)
        await pg.context.close()
        # ---------------- Settings
        pg=await page();E=pg.evaluate
        await E("()=>settings()");await pg.wait_for_timeout(500)
        vis={}
        for tab in ['Display','Sound','Effects','Data']:
            await E(f"()=>document.querySelector('.ctabs [data-st=\"{tab}\"]').click()");await pg.wait_for_timeout(150)
            vis[tab]=await E("()=>[...document.querySelectorAll('.opts>.opt')].filter(o=>o.style.display!=='none').map(o=>(o.querySelector('label')||{}).textContent)")
        chk('countdown option only on the Effects tab',vis['Effects'].count('Last 5 seconds countdown')==1 and all('Last 5 seconds countdown' not in vis[t] for t in ('Display','Sound','Data')),vis)
        await E("()=>document.querySelector('.ctabs [data-st=\"Effects\"]').click()");await pg.wait_for_timeout(150)
        await pg.click('#taopt [data-v="quiet"]');r=await E("()=>[ST.tacd,Object.keys(localStorage).some(k=>String(localStorage.getItem(k)).includes('\"tacd\":\"quiet\"'))]")
        chk('Silent button saves the setting',r[0]=='quiet' and r[1],r)
        await pg.screenshot(path='shots/ta_settings.png')
        await pg.click('#taopt [data-v="on"]')
        await pg.context.close()
        # iframe: the fit option belongs to Display only (it showed on every tab before)
        c=await b.new_context(viewport={'width':1600,'height':900});pg=await c.new_page();await pg.goto(html);await pg.wait_for_timeout(800)
        await pg.set_content(f"<iframe src='{html}' style='width:1500px;height:850px;border:0'></iframe>");await pg.wait_for_timeout(2500)
        f=pg.frames[1];await f.evaluate("()=>{RS_ASK=false;settings()}");await pg.wait_for_timeout(500);vis={}
        for tab in ['Display','Sound','Effects','Data']:
            await f.evaluate(f"()=>document.querySelector('.ctabs [data-st=\"{tab}\"]').click()");await pg.wait_for_timeout(150)
            vis[tab]=await f.evaluate("()=>[...document.querySelectorAll('.opts>.opt')].filter(o=>o.style.display!=='none').map(o=>(o.querySelector('label')||{}).textContent)")
        chk('"Fit to screen on websites" only on the Display tab',vis['Display'].count('Fit to screen on websites')==1 and all('Fit to screen on websites' not in vis[t] for t in ('Sound','Effects','Data')),vis)
        await b.close()
    chk('no page errors',not er,er[:5])
    print(f'\n{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else None
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
