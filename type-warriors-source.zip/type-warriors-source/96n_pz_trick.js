/* ===== 9.4 THE CROOKED CUE: Trick Shots, the data and the judge (96n) =====
   Ten one-shot puzzles. balls: [id,x,y] in table pixels (880 x 440, ball radius 12), cue: [x,y].
   goal: pot [ids that must drop], first (id the cue ball must hit first), bank (ids that must touch a cushion before dropping),
   kick (cushions the cue ball must touch before it hits anything), cueIn [x0,y0,x1,y1] (where the cue ball must stop).
   Stars: solved in up to 3 tries 3, up to 8 tries 2, otherwise 1 (potting is precise work: a window of well under a degree is normal). */
const PZ_TRICK=[
 {n:'Straight In',hint:'No tricks. Line the cue ball up with the 1 and the pocket, and roll it in.',balls:[[1,680,200]],cue:[500,380],goal:{pot:[1]}},
 {n:'The Cut',hint:'Aim at the ghost ball, not at the 2. Cut it into the far corner.',balls:[[2,620,300]],cue:[340,320],goal:{pot:[2]}},
 {n:'Draw Back',hint:'Pot the 3, then hit low on the cue ball so it draws back and does not follow in.',balls:[[3,740,100]],cue:[560,260],goal:{pot:[3],cueIn:[0,0,640,440]}},
 {n:'Follow Through',hint:'Hit high on the cue ball: after the 4 drops, it should roll on past the middle of the table.',balls:[[4,420,220]],cue:[200,330],goal:{pot:[4],cueIn:[560,0,880,440]}},
 {n:'One-Rail Bank',hint:'Send the 5 into the bottom cushion and let it bounce into the top right pocket.',balls:[[5,300,300]],cue:[150,260],goal:{pot:[5],bank:[5]}},
 {n:'Kick Around',hint:'The 9 blocks the shot. Bounce the cue ball off a cushion to reach the 6.',balls:[[6,700,260],[9,440,290]],cue:[180,330],goal:{pot:[6],kick:1}},
 {n:'Combination',hint:'Hit the 2 so that it drives the 7 into the bottom right corner.',balls:[[2,645,264],[7,720,320]],cue:[420,200],goal:{pot:[7],first:2}},
 {n:'Carom Off the 8',hint:'Hit the 8 first and let it knock the 1 in.',balls:[[8,400,250],[1,440,380]],cue:[200,250],goal:{pot:[1],first:8}},
 {n:'Side Pocket',hint:'Cut the 9 into the middle pocket. Point the yellow line at the pocket mouth.',balls:[[9,560,90]],cue:[700,400],goal:{pot:[9]}},
 {n:'The Bonechalk',hint:'Bank the 8 off two cushions. Mortimer would smile.',balls:[[8,300,250]],cue:[160,200],goal:{pot:[8],bank:[8]}}
];
/* did the settled shot meet the goal? ev = physics events, B = balls after the shot */
function pzTrickCheck(goal,ev,B){const pk=ev.filter(e=>e.t==='pk'),potted=pk.filter(e=>e.a>0).map(e=>e.a);
 if(pk.some(e=>e.a===0))return {ok:false,why:'Scratch! The cue ball dropped.',potted};
 const fb=ev.find(e=>e.t==='bb'&&(e.a===0||e.b===0)),first=fb?(fb.a===0?fb.b:fb.a):-1;
 if(first<0)return {ok:false,why:'You missed everything.',potted};
 if(goal.first!=null&&first!==goal.first)return {ok:false,why:`Hit the ${goal.first} first.`,potted,first};
 if(goal.kick){let n=0;for(const e of ev){if(e.t==='bb'&&(e.a===0||e.b===0))break;if(e.t==='cu'&&e.a===0)n++}if(n<goal.kick)return {ok:false,why:'The cue ball has to bounce off a cushion first.',potted,first}}
 for(const id of goal.pot)if(!potted.includes(id))return {ok:false,why:`The ${id} did not drop.`,potted,first};
 if(goal.bank)for(const id of goal.bank){const p=pk.find(e=>e.a===id),c=ev.some(e=>e.t==='cu'&&e.a===id&&e.tm<=p.tm);if(!c)return {ok:false,why:`The ${id} must bank off a cushion first.`,potted,first}}
 if(goal.cueIn){const c=B[0];if(!(c.x>=goal.cueIn[0]&&c.x<=goal.cueIn[2]&&c.y>=goal.cueIn[1]&&c.y<=goal.cueIn[3]))return {ok:false,why:'The cue ball ended up in the wrong place.',potted,first}}
 return {ok:true,why:'',potted,first}}
/* the goal as one line for the card */
function pzTrickGoalText(t){const g=t.goal,p=g.pot.join(' and ');let s=`Pot the ${p}`;if(g.bank)s+=' off a cushion';if(g.first!=null)s+=`, hitting the ${g.first} first`;if(g.kick)s+=', kicking off a cushion first';if(g.cueIn){const [a,,b]=g.cueIn;s+=a===0?', cue ball ends on the left':', cue ball ends on the right'}return s}
