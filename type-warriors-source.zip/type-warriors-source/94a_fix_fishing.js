/* ===== 8.7 fixes: Moonlit Fishing and touch typing =====================================================================
   A1  Leaving (Esc, Back or the title) while a catch is on show no longer loses the fish. fsLeave finishes the show
       (fsReveal, so auto-sell and odd catches behave as usual) and then takes the same keep-or-sell choice as leaving on the
       reveal screen: the catch goes into the creel or is paid, exactly once, never both and never neither.
   A6  That choice never overfills the creel. A full creel sells the catch instead (fsKeep writes the same fields as every other
       keep: kp and t as well). A toast says what happened.
   A9  Back mid-fight asks like Esc does (press twice within 2.2 s). Leaving mid-fight counts as an escape, through fsEscape
       itself (streak reset, escape stat, rarity stat and bounty run), without its sounds.
   A4  The pond pauses when the window loses focus or the tab is hidden: every timer stops (FS.tLeft, the grace, the wait for a
       bite, the catch show) and a small "Paused - press any key" note appears. A key, a tap or focus resumes it. The clock
       is shifted by the time spent paused, so nothing jumps.
   A2  + B1  On a touch device (TM()) the shared on-screen keyboard (#kb) also serves Moonlit Fishing and Trick-or-Treat. In the
       pond it carries a word strip (the word to type and its timer), Back and Cast keys, and Sell / Keep on the catch; in
       Trick-or-Treat it carries the letters, space and Pause. kbWant (63_touch.js) asks tkWant(); the Riddle and the
       Caravan keep their own keyboards and are not affected. The phone's own keyboard stays closed (inputmode none).
   B16 Big Screen counts the caravan and fishing as busy play (the const fsBusy cannot change, so fsFallback and fsSleep are
       wrapped): the "run restarts there" note shows and the run is paused behind the lightbox. */
const FSZ={t:0,why:'',quiet:0};

/* ---------- A1, A6, A9: leaving ---------- */
/* settle a catch that is still on show or waiting on the reveal screen: kept in the creel, or sold (never both) */
function fsSettleCatch(){
 if(FS.st==='show'&&FS.show){try{fsReveal()}catch(e){console.error(e);FS.show=null}}
 let out=null;
 if(FS.st==='reveal'&&FS.pend){const c=FS.pend;FS.pend=null;try{fsQsOff()}catch(e){}
  const full=fsP().cr.length>=fsCreelCap()&&!!fsKeepWhy(c);
  if(fsDefKeep(c)&&fsKeep(c))out={k:1,c};
  else out={k:0,c,v:fsSell(c),full};
  try{fsPreview(null);fsHudRefresh()}catch(e){}}
 return out}
function fsLeave(){
 let msg='';
 try{
  if(FS.st==='reel'||FS.st==='stage'){FSZ.quiet=1;try{fsEscape()}finally{FSZ.quiet=0}}
  else if(FS.st==='show'||FS.st==='reveal'){const r=fsSettleCatch();
   if(r){const nm=fsNm(r.c);msg=r.k?`${nm} kept in your creel.`:r.full?`Your creel was full, so ${nm} was sold for ${r.v.toLocaleString()} gold.`:`${nm} sold for ${r.v.toLocaleString()} gold.`}}
 }catch(e){console.error(e)}
 fsStop();try{fsHub()}catch(e){title()}
 if(msg)try{fzNote(msg)}catch(e){}}
/* a note that outlives the pond screen (the pond's own toast goes with it): game-style, top centre, 3.4 s */
function fzNote(txt){let m=document.getElementById('fztoast');if(!m){m=document.createElement('div');m.id='fztoast';m.setAttribute('role','status');document.body.appendChild(m)}
 m.textContent=txt;m.className='';void m.offsetWidth;m.className='on'+(fsRM()?' rm':'');clearTimeout(fzNote.h);fzNote.h=setTimeout(()=>{m.className=''},3400)}
/* Back and Esc ask the same question in a fight: the first press warns, a second one within 2.2 s leaves */
function fsLeaveAsk(){
 if((FS.st==='reel'||FS.st==='stage')&&!(FS.escT&&fsNow()-FS.escT<2.2)){FS.escT=fsNow();fsToast(TM()?'Tap Back again to leave. The fish will get away.':'Press Esc or Back again to leave. The fish will get away.');try{tkTick()}catch(e){}return false}
 fsLeave();return true}
/* the pond's own Back button and S.back go through the question */
{const p0=fsPond;fsPond=function(){const r=p0.apply(this,arguments);try{const b=$('fsback');if(b&&$('fsx')){b.onclick=fsLeaveAsk;S.back=fsLeaveAsk}}catch(e){console.error(e)}return r}}
/* leaving mid-fight is quiet: the escape sounds belong to a line that snaps while you watch */
{const s0=fsSfx;fsSfx=function(k){if(FSZ.quiet&&(k==='esc'||k==='snap'))return;return s0.apply(this,arguments)}}
/* going to the title from the pond (or any other way out) settles a catch too */
{const t0=title;title=function(){try{if(FS.on&&S.mode==='fish'&&(FS.st==='show'||FS.st==='reveal')){const r=fsSettleCatch();if(r)fzNote(r.k?`${fsNm(r.c)} kept in your creel.`:`${fsNm(r.c)} sold for ${r.v.toLocaleString()} gold.`);fsStop()}}catch(e){console.error(e)}return t0.apply(this,arguments)}}

/* ---------- A4: pause on blur / hidden ---------- */
const fsPzOK=()=>{try{return S.mode==='fish'&&S.view==='fish'&&FS.on&&!FS.tut&&!!$('fsx')&&['cast','wait','reel','stage','show','escape'].indexOf(FS.st)>=0}catch(e){return false}};
function fsPause(why){if(FS.paused||!fsPzOK())return false;FS.paused=true;FSZ.t=fsNow();FSZ.why=why||'';fsPzUI(true);try{tkStrip();tkRefresh()}catch(e){}return true}
function fsResume(){if(!FS.paused)return false;const d=Math.max(0,fsNow()-FSZ.t);FS.paused=false;fsPzShift(d);fsPzUI(false);try{tkStrip();tkRefresh()}catch(e){}return true}
/* every stored timestamp moves forward by the time spent paused, so waits, fights and shows carry on where they stopped */
function fsPzShift(d){const now=fsNow(),sh=(o,k)=>{if(o&&typeof o[k]==='number')o[k]+=d},t00=FS.t0;
 ['t0','biteT','fightT','landT','escT'].forEach(k=>sh(FS,k));sh(FS.breach,'t');sh(FS.snap,'t');sh(FS.show,'sk');sh(FS.qs,'t');
 FS.T=now;if(FS.snap)FS.snap.T=now;
 if(typeof FSRF!=='undefined'&&FSRF){if(FSRF.showT0===t00)FSRF.showT0=FS.t0;FSRF.T=now;sh(FSRF.fl,'t0');(FSRF.tr||[]).forEach(p=>sh(p,'t'));(FSRF.fp||[]).forEach(p=>sh(p,'t'))}}
function fsPzUI(on){const o=$('fspz');if(o)o.remove();const x=$('fsx');if(!on||!x)return;
 const d=document.createElement('div');d.id='fspz';d.className='fspz'+(fsRM()?' rm':'');d.setAttribute('role','status');
 d.innerHTML='<span class="fspzi" aria-hidden="true"><i></i><i></i></span><b>Paused</b><span class="fspzs"> - press any key</span>';x.appendChild(d);d.addEventListener('pointerdown',()=>fsResume())}
/* a frozen pond draws nothing new: the last frame stays on the canvas */
{const f0=fsFrame;fsFrame=function(){if(FS.paused)return;return f0.apply(this,arguments)}}
{const t0=fsType;fsType=function(){if(FS.paused){fsResume();return}return t0.apply(this,arguments)}}
{const s0=fsStop;fsStop=function(){FS.paused=false;try{fsPzUI(false)}catch(e){}return s0.apply(this,arguments)}}
{const s0=fsStart;fsStart=function(){FS.paused=false;return s0.apply(this,arguments)}}
window.addEventListener('blur',()=>{try{fsPause('blur')}catch(e){}});
document.addEventListener('visibilitychange',()=>{try{if(document.hidden||document.visibilityState==='hidden')fsPause('hidden');else if(FS.paused&&FSZ.why!=='sleep'&&document.hasFocus())fsResume()}catch(e){}});
window.addEventListener('focus',()=>{try{if(FS.paused&&FSZ.why!=='sleep'&&!document.hidden)fsResume()}catch(e){}});
/* any key resumes (and is not typed); Ctrl, Alt and Cmd shortcuts are left alone. Window capture runs before the pond's own handler. */
window.addEventListener('keydown',e=>{if(!FS.paused||e.ctrlKey||e.metaKey||e.altKey)return;if(!fsPzOK()){FS.paused=false;fsPzUI(false);return}e.preventDefault();e.stopImmediatePropagation();fsResume()},true);
/* a tap or click on the pond only resumes it (the click that follows still reaches a button); the keyboard resumes through tkPress */
window.addEventListener('pointerdown',e=>{try{if(FS.paused&&!(e.target&&e.target.closest&&e.target.closest('#kb'))){fsResume();e.stopPropagation()}}catch(x){}},true);

/* ---------- A2 + B1: the touch keyboard for the pond and Trick-or-Treat ---------- */
const TK={dirty:0};
function tkMode(){try{if(!TM())return'';
 if(S.mode==='fish'&&S.view==='fish'&&$('fsx')&&!FS.tut){const m=$('fsmod');if(!m||m.hidden)return'fish'}
 else if(S.mode==='treat'&&S.view==='treat'&&typeof TRT!=='undefined'&&TRT.run&&TRT.run.phase==='typing'&&!TRT.paused)return'treat'}catch(e){}return''}
function tkWant(){return tkMode()!==''}
/* the pond's keyboard is the shared one with a word strip on top; elsewhere the size is the usual one */
function kbH(vw,vh){const port=vh>=vw;if(tkMode()==='fish')return Math.round(port?Math.min(vh*.42,330):Math.min(vh*.52,200));return Math.round(port?Math.min(vh*.44,330):Math.min(vh*.5,210))}
{const s=document.createElement('div');s.id='tks';s.className='tks';s.innerHTML='<div class="tkp" id="tkp"><i class="tkf" id="tkfill"></i><span class="tkt" id="tkt"></span><em class="tksec" id="tksec"></em></div>';kb.insertBefore(s,kb.firstChild)}
/* #ov stops above the keyboard (touchLayout gives a full-height box to anything that is not a clear overlay) */
{const t0=touchLayout;touchLayout=function(vw,vh,ah,on){const r=t0.apply(this,arguments);try{
 const m=on?tkMode():'';kb.classList.toggle('tk',!!m);kb.dataset.m=m;kb.dataset.o=vh>=vw?'p':'l';
 if(m){const z=parseFloat(ov.style.zoom)||1;ov.style.height=(ah/z)+'px';if(m==='treat')setTimeout(tkShowWord,60)}
 {const w=$('tkt');if(w)w.dataset.h=''}/* the word is fitted again at the new size */
 tkRefresh()}catch(e){console.error(e)}return r}}
/* Trick-or-Treat: the word box must stay above the keys */
function tkShowWord(){try{if(S.mode!=='treat'||!kb.classList.contains('tk'))return;const p=document.querySelector('.ttchallenge')||$('ttbody');if(p&&p.scrollIntoView)p.scrollIntoView({block:p.offsetHeight<=ov.clientHeight?'center':'start',inline:'nearest'})}catch(e){}}
{const t0=ttScreen;ttScreen=function(){const r=t0.apply(this,arguments);try{const i=$('ttinput');if(i&&TM())i.setAttribute('inputmode','none')}catch(e){}return r}}
/* labels and the strip follow the pond's state */
function tkRefresh(){
 const m=kb.classList.contains('on')&&kb.classList.contains('tk')?kb.dataset.m:'',pb=kb.querySelector('[data-a=pause]'),dr=kb.querySelector('[data-a=drop]'),sp=kb.querySelector('.sp'),fy=kb.querySelector('#kf span');
 if(!pb||!dr||!sp||!fy)return;
 if(!m){if(TK.dirty){TK.dirty=0;pb.textContent='II';dr.textContent='Drop';sp.textContent='space';fy.textContent='Fury';pb.classList.remove('warn');sp.classList.remove('go');kb.removeAttribute('data-st')}return}
 TK.dirty=1;
 if(m==='treat'){pb.textContent='Pause';dr.textContent='';sp.textContent='space';sp.classList.remove('go');pb.classList.remove('warn');kb.dataset.st='typing';return}
 const st=FS.paused?'paused':FS.st;kb.dataset.st=st;
 pb.textContent=tkWarn()?'Leave?':'Back';pb.classList.toggle('warn',tkWarn());
 sp.textContent={idle:'Cast',show:'Skip',cast:'Casting...',wait:'Waiting...',reel:'Reeling...',stage:'Reeling...',paused:'Paused',escape:'...',odd:'...'}[st]||'space';sp.classList.toggle('go',st==='idle');
 if(st==='reveal'&&FS.pend){const v=fsValue(FS.pend);dr.textContent='Sell '+v.toLocaleString();fy.textContent='Keep'}
 tkStrip()}
const tkWarn=()=>!!(FS.escT&&fsNow()-FS.escT<2.2&&(FS.st==='reel'||FS.st==='stage'));
function tkStrip(){const p=$('tkp'),t=$('tkt');if(!p||!t||kb.dataset.m!=='fish'||!kb.classList.contains('tk'))return;
 const st=FS.paused?'paused':FS.st;let h='',rc='#5a4ca0',w=0;
 if((st==='reel'||st==='stage')&&FS.cur&&FS.word){rc=FSR[FS.cur.rk].c;const n=Math.min(FS.word.length,FS.typed||0);h=`<span class="d">${fsEsc(FS.word.slice(0,n))}</span>${fsEsc(FS.word.slice(n))}`;w=1}
 else if(st==='reveal'&&FS.pend){rc=FSR[FS.pend.rk].c;h=fsEsc(fsNm(FS.pend))}
 else h={idle:'Ready to cast',cast:'Casting...',wait:'Watch the bobber...',show:'Landing it...',escape:'It got away...',odd:'A strange catch...',paused:'Paused - tap to resume'}[st]||'';
 if(t.dataset.h!==h){t.dataset.h=h;t.innerHTML=h;
  /* a long word shrinks to fit the strip: it must always show whole */
  if(w){const n=FS.word.length,mx=kb.dataset.o==='l'?19:Math.min(32,Math.max(22,innerWidth/15)),av=Math.max(60,p.clientWidth-92);t.style.fontSize=Math.max(13,Math.min(mx,av/(n*.92)))+'px'}else t.style.fontSize=''}
 t.classList.toggle('w',!!w);p.style.setProperty('--rc',rc);if(!w)tkTick()}
function tkTick(){const p=$('tkp');if(!p||!kb.classList.contains('tk')||kb.dataset.m!=='fish')return;const f=$('tkfill'),s=$('tksec'),rd=(FS.st==='reel'||FS.st==='stage')&&!FS.paused&&FS.tMax>0,k=rd?Math.max(0,Math.min(1,FS.tLeft/FS.tMax)):0;
 if(f)f.style.transform=`scaleX(${k.toFixed(3)})`;if(s){const v=rd?Math.ceil(FS.tLeft)+'s':'';if(s.textContent!==v)s.textContent=v}p.classList.toggle('low',rd&&FS.tLeft<1.6);
 const pb=kb.querySelector('[data-a=pause]');if(pb){const w=tkWarn();if(pb.classList.contains('warn')!==w){pb.classList.toggle('warn',w);pb.textContent=w?'Leave?':'Back'}}}
{const h0=fsHudState;fsHudState=function(){const r=h0.apply(this,arguments);try{tkRefresh()}catch(e){}return r}}
{const h0=fsHudWord;fsHudWord=function(){const r=h0.apply(this,arguments);try{tkStrip()}catch(e){}return r}}
{const h0=fsHudTimer;fsHudTimer=function(){const r=h0.apply(this,arguments);try{tkTick()}catch(e){}return r}}
/* Space on the screen does what Space does on the keyboard */
function tkSpace(){if(FS.tut)return;if(FS.st==='idle')fsCast();else if(FS.st==='show')fsSkip()}
function tkPress(m,b){const c=b.dataset.c,a=b.dataset.a;
 if(m==='fish'){if(FS.paused){fsResume();return}
  if(c!==undefined&&c!==' ')fsType(c);
  else if(c===' ')tkSpace();
  else if(a==='pause')fsLeaveAsk();
  /* Sell and Keep take the place of the Skip key when the show ends: a tap that was meant for Skip must not decide the catch */
  else if(a==='drop'){if(FS.st==='reveal'&&fsNow()-FS.t0>.45){fsQsOff();fsDecide(false)}}
  else if(a==='fury'){if(FS.st==='reveal'&&fsNow()-FS.t0>.45){fsQsOff();fsDecide(true)}}}
 else if(m==='treat'){if(c!==undefined)ttInput(c);else if(a==='pause')ttPause()}}
/* captured before the shared keyboard's own handler, which would send these keys to the campaign */
kb.addEventListener('pointerdown',e=>{const m=kb.classList.contains('tk')?kb.dataset.m:'';if(!m)return;const b=e.target.closest&&e.target.closest('button');if(!b)return;e.preventDefault();e.stopImmediatePropagation();try{ensureAudio()}catch(x){}b.classList.add('dn');try{tkPress(m,b)}catch(x){console.error(x)}},true);
{const st=document.createElement('style');st.textContent=`
#kb .tks{display:none;flex:none;height:50px}
#kb.tk[data-m=fish] .tks{display:flex}
#kb[data-o=l] .tks{height:30px}
#kb .tkp{position:relative;flex:1;min-width:0;display:flex;align-items:center;justify-content:center;overflow:hidden;border-radius:14px;background:linear-gradient(#251b55,#120c32);border:2px solid #12081f;box-shadow:inset 0 0 0 1.5px var(--rc,#5a4ca0)}
#kb[data-o=l] .tkp{border-radius:10px}
#kb .tkf{position:absolute;left:0;top:0;bottom:0;width:100%;background:linear-gradient(90deg,#2bd9c4b0,#2bd9c460);transform-origin:0 50%;transform:scaleX(0)}
#kb .tkp.low .tkf{background:linear-gradient(90deg,#ff5a6eb8,#ff5a6e66)}
#kb .tkt{position:relative;max-width:100%;padding:0 46px;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;font:700 15px/1.4 var(--ui);color:#e8e0ff;text-transform:none}
#kb .tkt.w{font:800 26px/1.3 var(--ui);letter-spacing:.16em;text-transform:uppercase;color:#fff8e8;text-shadow:0 2px 0 #12081f}
#kb[data-o=l] .tkt{font-size:13px}#kb[data-o=l] .tkt.w{font-size:19px}
#kb .tkt .d{color:#ffd45a}
#kb .tksec{position:absolute;right:12px;top:50%;transform:translateY(-50%);font:800 14px var(--ui);font-style:normal;color:#cfc6f0}
#kb.tk[data-m=fish] .ka [data-a=drop],#kb.tk[data-m=fish] .ka .fy,#kb.tk[data-m=treat] .ka [data-a=drop],#kb.tk[data-m=treat] .ka .fy{display:none}
#kb.tk[data-m=fish][data-st=reveal] .ka [data-a=drop],#kb.tk[data-m=fish][data-st=reveal] .ka .fy{display:block}
#kb.tk[data-m=fish][data-st=reveal] .ka .sp{display:none}
#kb.tk .ka button{font-family:var(--ui);font-weight:700;text-transform:none;letter-spacing:.02em}
#kb.tk .ka .fy{background:linear-gradient(#4a3a80,#2a1f52);border-color:#7a68b8}#kb.tk .ka .fy i{display:none}#kb.tk .ka .fy.rd{animation:none}
#kb.tk[data-m=fish][data-st=reveal] .ka .fy{background:linear-gradient(#ffe490,#f0a820);color:#2a1608;border-color:#8a5610}
#kb.tk .ka .sp.go{background:linear-gradient(#ffe490,#f0a820);color:#2a1608;border-color:#8a5610}
#kb.tk .ka [data-a=pause].warn{background:linear-gradient(#ff8a98,#d8304a);color:#fff;border-color:#8a1426}
#kb.tk[data-m=fish]:not([data-st=reel]):not([data-st=stage]) .kr:not(.ka) button{opacity:.42}
#kb.tk[data-m=fish]:not([data-st=idle]):not([data-st=show]) .ka .sp{opacity:.5}
.fspz{position:absolute;left:590px;top:262px;transform:translateX(-50%);z-index:40;display:flex;align-items:center;gap:14px;padding:12px 28px 12px 14px;border-radius:999px;white-space:nowrap;cursor:pointer;background:linear-gradient(#2c2070,#150f3e);border:4px solid #12081f;box-shadow:0 0 0 2px #ffd45a,0 10px 24px #000a;animation:fsPzIn .38s cubic-bezier(.3,1.5,.5,1) both}
.fspz.rm{animation:none}
.fspzi{display:flex;align-items:center;justify-content:center;gap:5px;width:42px;height:42px;border-radius:50%;background:radial-gradient(circle at 35% 30%,#fff6c0,#ffc94a 55%,#d48a10);border:3px solid #12081f}
.fspzi i{width:6px;height:18px;border-radius:2px;background:#12081f}
.fspz b{font:400 40px/1 'Pirata One',Georgia,serif;color:#ffd45a;text-shadow:0 3px 0 #12081f}
.fspzs{font:600 19px var(--ui);color:#e8e0ff}
body.tm .fspz{display:none}
#fztoast{position:fixed;left:12px;right:12px;top:22px;z-index:100000;width:max-content;max-width:min(560px,calc(100% - 24px));margin:0 auto;padding:12px 20px;border-radius:14px;text-align:center;background:linear-gradient(180deg,#221a5a,#120a30);border:2px solid #ffd45a;box-shadow:0 0 0 3px #12081f,0 12px 30px #000a;color:#fff8e8;font:700 15px/1.4 var(--ui);opacity:0;transform:translateY(-14px);pointer-events:none;transition:opacity .25s,transform .4s cubic-bezier(.3,1.5,.5,1)}
#fztoast.on{opacity:1;transform:none}#fztoast.rm{transition:none;transform:none}
@keyframes fsPzIn{from{opacity:0;transform:translate(-50%,12px) scale(.85)}}`;document.head.appendChild(st)}

/* ---------- B16: Big Screen counts the caravan and fishing as busy play ---------- */
{const f0=fsFallback;fsFallback=function(){
 const extra=(()=>{try{return inFrame()&&!FSB.wait&&!fsBusy()&&(!!S.wr||S.mode==='fish')}catch(e){return false}})();
 const r=f0.apply(this,arguments);
 if(extra&&FSB.wait){const ok0=FSB.wait.ok;FSB.wait.ok=function(d){try{fsNote(d&&d.action==='close'?'Back to the normal view. Your save is shared; this run will restart there.':'Opening Big Screen. Your save is shared; this run will restart there.')}catch(e){}return ok0.apply(this,arguments)}}
 return r}}
{const s0=fsSleep;fsSleep=function(){const r=s0.apply(this,arguments);
 try{if(typeof WRX!=='undefined'&&WRX&&S.wr&&S.mode==='wagon'&&!WRX.over&&!WRX.pause)wrPause(true)}catch(e){}
 try{fsPause('sleep')}catch(e){}return r}}
