/* ===== RUNESTONE RIDDLE 8.4c: menu detail =====
   - A music button sits beside the coin chip (it presses the game's own music toggle, so the setting is shared everywhere).
   - The side panels get a gilded crest gem, an inner gold filigree line and rune studs; the calendar button gets a slow light sweep.
   - The title gets a twinkling star and a carved underline. Everything animates transform/opacity only. */
const RRM_ICO=on=>`<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 17.5V5.5l10-2v12" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round"/><ellipse cx="6.6" cy="17.6" rx="2.9" ry="2.3" fill="currentColor"/><ellipse cx="16.6" cy="15.6" rx="2.9" ry="2.3" fill="currentColor"/>${on?'':'<path d="M3.5 3.5l17 17" stroke="#ff7a8a" stroke-width="2.6" stroke-linecap="round"/>'}</svg>`;
function rrMuSync(){const b=$('rrmu');if(!b)return;const on=!ST.mute;b.setAttribute('aria-pressed',on);b.classList.toggle('off',!on);b.title=on?'Music on':'Music off';b.innerHTML=RRM_ICO(on)}
function rrMenuDeco(){const hd=ov.querySelector('.rrhd'),g=$('rrgold');if(!hd||!g||$('rrmu'))return;
 const w=document.createElement('div');w.className='rrhr';g.replaceWith(w);
 const b=document.createElement('button');b.className='rrmu';b.id='rrmu';b.setAttribute('aria-label','Music');
 b.onclick=()=>{b.blur();try{$('mt').click()}catch(e){}rrMuSync()};w.append(b,g);rrMuSync();
 const ti=ov.querySelector('.rrti');if(ti&&!ti.querySelector('.rrtstar')){const s=document.createElement('i');s.className='rrtstar';s.setAttribute('aria-hidden','true');ti.appendChild(s)}
 const pw=ov.querySelector('.rrpowp');if(pw&&!pw.querySelector('.rrcrest'))pw.insertAdjacentHTML('beforeend','<i class="rrcrest sm" aria-hidden="true"></i>')}
{const m0=rrMenu;rrMenu=function(){const r=m0.apply(this,arguments);try{rrMenuDeco()}catch(e){}return r}}
{const p0=rrPanel;rrPanel=function(){const r=p0.apply(this,arguments);try{const el=$('rrpanel');if(el&&!el.querySelector('.rrcrest'))el.insertAdjacentHTML('beforeend','<i class="rrcrest" aria-hidden="true"></i><i class="rrfili" aria-hidden="true"></i>')}catch(e){}return r}}
{const st=document.createElement('style');st.textContent=`
#rr .rrhr{grid-column:5;grid-row:1;display:flex;align-items:center;gap:10px}
#rr.rr-narrow .rrhr{grid-column:3;grid-row:1}
.rrmu{width:52px;height:52px;flex:none;box-shadow:0 3px 0 #0a0720!important;display:grid;place-items:center;padding:0;border-radius:50%;cursor:pointer;color:#ffe08a;background:#110d30e6;border:2px solid #3e3790;transition:transform .18s cubic-bezier(.3,1.6,.5,1)}
.rrmu svg{width:24px;height:24px}.rrmu:hover{transform:translateY(-2px) scale(1.06);border-color:#ffcf5a}.rrmu:active{transform:scale(.92)}
.rrmu.off{color:#8a82b8}.rrmu:focus-visible{outline:3px solid #ffcf5a;outline-offset:2px}
.rrti{position:relative}
.rrti h1{position:relative}
.rrti::after{content:"";position:absolute;left:4px;right:12%;bottom:-4px;height:3px;border-radius:3px;background:linear-gradient(90deg,#0000,#ffcf5a 18%,#c98a10 60%,#0000);opacity:.75}
.rrtstar{position:absolute;right:-22px;top:4px;width:18px;height:18px;pointer-events:none;background:#fff3c0;clip-path:polygon(50% 0,62% 38%,100% 50%,62% 62%,50% 100%,38% 62%,0 50%,38% 38%);animation:rrTw 3.2s ease-in-out infinite}
@keyframes rrTw{0%,100%{transform:scale(.4) rotate(0);opacity:.35}45%{transform:scale(1) rotate(45deg);opacity:1}}
.rrcrest{position:absolute;left:50%;top:-15px;width:58px;height:26px;margin-left:-29px;pointer-events:none;z-index:2;
 background:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 58 26'%3E%3Cpath d='M2 15h14l6-6h14l6 6h14' fill='none' stroke='%2312081f' stroke-width='5' stroke-linecap='round'/%3E%3Cpath d='M2 15h14l6-6h14l6 6h14' fill='none' stroke='%23d9a22a' stroke-width='2.4' stroke-linecap='round'/%3E%3Cpath d='M29 1l10 12-10 12-10-12z' fill='%2312081f'/%3E%3Cpath d='M29 4l7.5 9L29 22l-7.5-9z' fill='%239a6aff'/%3E%3Cpath d='M29 4l7.5 9H21.5z' fill='%23d8c0ff'/%3E%3Cpath d='M26 9l3-3' stroke='%23fff' stroke-width='1.6' stroke-linecap='round'/%3E%3C/svg%3E") center/contain no-repeat}
.rrcrest::after{content:"";position:absolute;left:50%;top:50%;width:30px;height:30px;margin:-15px 0 0 -15px;border-radius:50%;background:radial-gradient(#c8a8ff99,#c8a8ff00 70%);animation:rrCrest 2.8s ease-in-out infinite}
@keyframes rrCrest{0%,100%{opacity:.25;transform:scale(.7)}50%{opacity:.9;transform:scale(1.15)}}
.rrcrest.sm{transform:scale(.8)}
.rrfili{position:absolute;inset:6px;border-radius:17px;border:1px solid #d9a22a38;pointer-events:none}
.rrfili::before,.rrfili::after{content:"";position:absolute;top:50%;width:6px;height:6px;margin-top:-3px;transform:rotate(45deg);background:#d9a22a88}
.rrfili::before{left:-3.5px}.rrfili::after{right:-3.5px}
#rr .rrcalb{position:relative;overflow:clip}
#rr .rrcalb::after{content:"";position:absolute;top:-10%;bottom:-10%;left:0;width:70px;background:linear-gradient(100deg,#ffffff00,#ffe8a838 45%,#ffffff00);transform:translateX(-120px) skewX(-18deg);animation:rrSweep 5.5s ease-in-out 1.2s infinite;pointer-events:none}
@keyframes rrSweep{0%{transform:translateX(-120px) skewX(-18deg)}38%,100%{transform:translateX(560px) skewX(-18deg)}}
#rr .rrcalb:hover{transform:translateY(-2px)}
@media (prefers-reduced-motion:reduce){.rrtstar,.rrcrest::after,#rr .rrcalb::after{animation:none}}
`;document.head.appendChild(st)}
