/* ===== MOONLIT FISHING update 7: polish (a calmer menu, an easier bait system) =====
   Menu: the bait button moves to the pond (where bait is used), the bounty strip becomes one slim notice, the moon's line becomes a
   welcoming tagline, and the Fishing Spots sign counts the secret spot only once it is found.
   Bait: a quick picker pops up from the pond's bait chip (B, or click; 1-5 pick, 0 none), and the Bait Pouch is a set of clear cards
   that say what each bait does here and now ("Rare 5% → 10%"), recommend one, and buy/craft/equip with one button each. */
const FSBAITFX={worm:'Uncommon ×1.6',moth:'Rare ×2',roe:'Legendary ×2.5',shrimp:'Frostfall fish ×2.5',spore:'Grotto fish ×2.5'};
const FSBAITFOR={worm:'Filling the bestiary and Uncommon bounties',moth:'Hunting Rare fish and Rare bounties',roe:'Legend and Mythic hunters',shrimp:'Finding Frostfall\'s own fish',spore:'Finding Glowcap Grotto\'s own fish'};
/* what a bait changes at this spot: [label, before %, after %] */
function fsBaitPreview(k){const K=FSBAIT[k],loc=fsLoc(),lure=fsP().up.lure||0,base=fsOdds(lure,{},loc);
 if(K.m){const rk=Object.keys(K.m)[0];FSBAITM=K.m;let w;try{w=fsOdds(lure,{},loc)}finally{FSBAITM=null}return[FSR[rk].n,base[rk],w[rk]]}
 if(K.loc!==loc)return null;const pl=FSPOOL[loc]||[];let a=0,b=0;for(const rk of FSRK){const ids=pl.filter(i=>FISH[i].r===rk);if(!ids.length)continue;const W0=ids.reduce((s,i)=>s+FISH[i].w,0),W1=ids.reduce((s,i)=>s+FISH[i].w*(FISH[i].loc===loc?2.5:1),0);
  ids.forEach(i=>{if(FISH[i].loc===loc){a+=base[rk]*FISH[i].w/W0;b+=base[rk]*FISH[i].w*2.5/W1}})}return[`${FSLOCS[loc].n.split(' ')[0]}'s own fish`,a,b]}
/* one bait to suggest right now */
function fsBaitRec(){const loc=fsLoc(),F=fsP(),open=k=>!FSBAIT[k].loc||fsLocOpen(FSBAIT[k].loc);
 for(const k of ['shrimp','spore'])if(FSBAIT[k].loc===loc&&FSPOOL[loc].some(i=>FISH[i].loc===loc&&!(F.b[i]&&F.b[i].n)&&FISH[i].r!=='m'))return k;
 try{const B=fsBtyGet();if(B.L.some(b=>!b.done&&b.k==='rk'&&b.rk==='r'))return'moth';if(B.L.some(b=>!b.done&&(b.k==='rk'||(b.k==='sp'&&FISH[b.id].r==='u'))))return'worm'}catch(e){}
 if(FSPOOL[loc].some(i=>FISH[i].r==='r'&&!(F.b[i]&&F.b[i].n)))return'moth';if(FSPOOL[loc].some(i=>FISH[i].r==='u'&&!(F.b[i]&&F.b[i].n)))return'worm';return open('roe')?'roe':'moth'}
const fsPct=v=>v<1?v.toFixed(2).replace(/0$/,'')+'%':v<10?v.toFixed(1).replace(/\.0$/,'')+'%':Math.round(v)+'%';
/* ---------- the Bait Pouch, as cards ---------- */
function fsBaitModal(from){const B=fsBaitP(),here=fsLoc(),rec=fsBaitRec();
 const cards=FSBAITK.map(k=>{const K=FSBAIT[k],have=B.inv[k]||0,on=B.on===k,need=fsBaitNeed(k),got=fsBaitFish(k).length,lock=K.loc&&!fsLocOpen(K.loc),away=K.loc&&!lock&&K.loc!==here,pv=lock?null:fsBaitPreview(k);
  const what=K.cr.rk?`${need} ${FSR[K.cr.rk].n} fish`:`${need} ${FSLOCS[K.cr.loc].n.split(' ')[0]} fish`;
  return `<div class="fsbp-c${on?' on':''}${lock?' lk':''}${k===rec&&!lock?' rec':''}" style="--bc:${K.c}" data-bk="${k}">${k===rec&&!lock?'<span class="fsbp-rec">Suggested</span>':''}${on?'<span class="fsbp-on">In use</span>':''}
   <div class="fsbp-top"><canvas width="96" height="96" data-bait="${k}" aria-hidden="true"></canvas><div><b>${K.n}</b><em class="fsbp-fx">${FSBAITFX[k]}</em><small class="fsbp-have${have?'':' no'}">${have?`${have} cast${have>1?'s':''} in your pouch`:'None in your pouch'}</small></div></div>
   <p class="fsbp-d">${K.d}</p><p class="fsbp-for">Best for: ${FSBAITFOR[k]}</p>
   <p class="fsbp-pv">${lock?`Unlock ${FSLOCS[K.loc].n} to use this bait.`:away?`Works only at <b>${FSLOCS[K.loc].n}</b>. You are at ${FSLOCS[here].n}.`:pv?`Here: ${pv[0]} <b>${fsPct(pv[1])}</b> → <b class="up">${fsPct(pv[2])}</b>`:''}</p>
   <div class="fsbp-b">${lock?'':`${have||on?`<button class="fsbp-use${on?' on':''}" data-eq="${k}">${on?'Stop using':'Use it'}</button>`:''}<button class="fsbp-buy" data-buy="${k}" ${P.gold<K.cost?'disabled':''}><span>${fsCoin}${K.cost}</span><small>Buy ${K.cast} casts</small></button>
    <button class="fsbp-cr" data-craft="${k}" ${got>=need?'':'disabled'} title="Uses the least valuable matching fish from your basket"><span>Craft</span><small>${what} · ${Math.min(got,need)}/${need}</small></button>`}</div></div>`}).join('');
 fsU6Modal(`<div class="fsbp fsg"><button class="fsx2" id="fsx2" aria-label="Close">✕</button><div class="fsbp-hd"><h3 class="fsu6h">Bait Pouch</h3><p>Bait changes which fish bite. Pick one to <b>use</b>; each cast uses one. Buy it with gold, or craft it from fish in your basket (fish saved for rod looks are never used).</p></div>
  <div class="fsbp-g">${cards}</div><p class="fsbp-f">Fishing at <b>${FSLOCS[here].n}</b> · ${B.on&&FSBAIT[B.on]?`using <b>${FSBAIT[B.on].n}</b> (${B.inv[B.on]||0} left)`:'no bait in use'} · in the pond, press <kbd>B</kbd> for a quick switch</p></div>`,from);
 const m=$('fsmod');m.querySelectorAll('canvas[data-bait]').forEach(cv=>{const k=cv.dataset.bait,g=cv.getContext('2d');const dr=t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,96,96);fsU6Bait(g,k,48,48,.86,t)};dr(.6);if(!fsRM())LIVE.push({cv,fn:dr,slow:3})});
 const re=()=>{fsBaitModal(from);try{fsHudRefresh()}catch(e){}};
 m.querySelectorAll('[data-buy]').forEach(b=>b.onclick=()=>{const k=b.dataset.buy;if(fsBaitBuy(k)){fsBaitP().on=k;save();fsSfx('buy');try{fsToast(`Bought ${FSBAIT[k].cast} casts of ${FSBAIT[k].n}. Now in use.`,1)}catch(e){}re()}});
 m.querySelectorAll('[data-craft]').forEach(b=>b.onclick=()=>{const k=b.dataset.craft;if(fsBaitCraft(k)){fsBaitP().on=k;save();fsSfx('r');try{fsToast(`Crafted ${FSBAIT[k].cast} casts of ${FSBAIT[k].n}. Now in use.`)}catch(e){}re()}});
 m.querySelectorAll('[data-eq]').forEach(b=>b.onclick=()=>{const k=b.dataset.eq,B2=fsBaitP();B2.on=B2.on===k?'':k;save();try{beep(760,.05,'triangle',.12)}catch(e){}re()})}
/* ---------- the quick picker above the pond's bait chip ---------- */
function fsBaitOpen(){if(S.view==='fish'&&FS.on){if(FS.st!=='idle'&&FS.st!=='reveal'){fsToast('Finish this catch first, then change your bait.');return}return fsBaitQuick()}fsBaitModal(S.view==='fish'?'pond':'hub')}
function fsBaitQuick(close){let q=$('fsbq');if(q||close){if(q)q.remove();return}const x=$('fsx');if(!x)return;const B=fsBaitP();
 const L=FSBAITK.filter(k=>(B.inv[k]||0)>0||B.on===k);
 q=document.createElement('div');q.id='fsbq';q.className='fsbq fsg';q.setAttribute('role','menu');
 q.innerHTML=`<b class="fsbq-h">Bait <small>each cast uses one</small></b>${L.map((k,i)=>{const K=FSBAIT[k],away=K.loc&&K.loc!==fsLoc();return `<button role="menuitemradio" aria-checked="${B.on===k}" class="fsbq-i${B.on===k?' on':''}" data-qb="${k}" style="--bc:${K.c}"><canvas width="44" height="44" aria-hidden="true"></canvas><span><b>${K.n}</b><small>${away?`only at ${FSLOCS[K.loc].n}`:FSBAITFX[k]} · ×${B.inv[k]||0}</small></span><kbd>${i+1}</kbd></button>`}).join('')}
  <button role="menuitemradio" aria-checked="${!B.on}" class="fsbq-i${!B.on?' on':''}" data-qb=""><canvas width="44" height="44" aria-hidden="true"></canvas><span><b>No bait</b><small>save your bait</small></span><kbd>0</kbd></button>
  <button class="fsbq-more" id="fsbqm">${L.length?'Get more bait…':'Buy or craft bait…'}</button>`;
 x.appendChild(q);q.querySelectorAll('[data-qb]').forEach(b=>{const k=b.dataset.qb,g=b.querySelector('canvas').getContext('2d');fsU6Bait(g,k||'none',22,22,.4,.6);b.onclick=()=>fsBaitPick(k)});
 $('fsbqm').onclick=()=>{fsBaitQuick(1);fsBaitModal('pond')};setTimeout(()=>{const f=q.querySelector('.fsbq-i.on')||q.querySelector('.fsbq-i');try{f&&f.focus({preventScroll:true})}catch(e){}},30)}
function fsBaitPick(k){const B=fsBaitP();B.on=k;save();fsBaitQuick(1);try{beep(760,.05,'triangle',.12)}catch(e){}try{fsToast(k?`Using ${FSBAIT[k].n}.`:'Fishing without bait.')}catch(e){}try{fsHudRefresh()}catch(e){}}
window.addEventListener('keydown',e=>{const q=$('fsbq');if(!q||S.mode!=='fish'||e.ctrlKey||e.metaKey||e.altKey)return;const k=e.key;
 if(k==='Escape'||k==='b'||k==='B'){e.preventDefault();e.stopImmediatePropagation();fsBaitQuick(1);return}
 if(/^[0-9]$/.test(k)){const L=[...q.querySelectorAll('[data-qb]')],i=k==='0'?L.length-1:+k-1;if(L[i]){e.preventDefault();e.stopImmediatePropagation();fsBaitPick(L[i].dataset.qb)}return}
 if(k===' '){e.preventDefault();e.stopImmediatePropagation();fsBaitQuick(1)}},true);
document.addEventListener('pointerdown',e=>{const q=$('fsbq');if(q&&!q.contains(e.target)&&!(e.target.closest&&e.target.closest('#fsbc')))fsBaitQuick(1)},true);
{const s0=fsSet;fsSet=function(st){if(st!=='idle'&&st!=='reveal'){const q=$('fsbq');if(q)q.remove()}return s0.apply(this,arguments)}}
/* the chip says what the bait does, and nudges when it has run out */
{const r0=fsU6PondRefresh;fsU6PondRefresh=function(){const r=r0.apply(this,arguments);try{const bc=$('fsbc');if(bc){const B=fsBaitP(),k=B.on,K=FSBAIT[k],n=K?B.inv[k]||0:0,sm=bc.querySelector('small');
  if(sm&&K&&n&&!(K.loc&&K.loc!==fsLoc()))sm.textContent=`${FSBAITFX[k]} · ${n} left`;bc.classList.toggle('out',!!K&&!n);if(sm&&!K)sm.textContent='None · press B to choose'}}catch(e){}return r}}
/* ---------- a calmer menu ---------- */
{const h0=fsU6HubHTML;fsU6HubHTML=function(h){h=h0.apply(this,arguments);try{const B=fsBtyGet(),st=fsBtyStreak(),dn=B.L.filter(b=>b.done).length,M=fsMoon();
  /* bounty notice: one slim line with three progress pips; the bait button lives in the pond now */
  h=h.replace(/<div class="fsh6">[\s\S]*?<\/button>\s*<button class="fsh6k[\s\S]*?<\/button><\/div>/,`<div class="fsh7"><button class="fsh7b fsg" id="fsh6b" title="Daily bounties (O)"><canvas width="104" height="88" data-ic="board" aria-hidden="true"></canvas><span class="fsh7t"><b>Daily Bounties</b><small>${dn===3?'All done today. New requests tomorrow!':`${dn} of 3 done · next: ${fsEsc(fsBtyShort(B.L.find(b=>!b.done)))}`}</small></span>
   <span class="fsh7p" aria-hidden="true">${B.L.map(b=>`<i class="${b.done?'ok':''}" style="--bc:${FSBTYD[b.d].c};--p:${Math.min(1,b.got/b.n)}"></i>`).join('')}</span>${st?`<em class="fsh7s">${FSFLAME}${st}</em>`:''}<i class="fsch">›</i></button></div>`);
  /* the moon's line welcomes you instead of repeating the rules */
  h=h.replace(/<p class="fsh2s">[^<]*<\/p>/,`<p class="fsh2s">${fsEsc(M.d)} Pull up a stool, angler.</p>`).replace(/<i>[^<]*<\/i><\/div><\/div>\s*<button class="fshgo/,'</div></div>\n   <button class="fshgo');
  /* the sign only counts the secret spot once it has been found */
  const vis=FSLOCK.filter(k=>!FSLOCS[k].soon&&(!FSLOCS[k].secret||fsLocOpen(k))),open=vis.filter(k=>fsLocOpen(k)).length,nx=vis.find(k=>!fsLocOpen(k));
  h=h.replace(/<small>\d+ of \d+ open[^<]*<\/small>/,`<small>${open} of ${vis.length} open${nx?` · next at ${FSLOCS[nx].need} species`:''}</small>`)}catch(e){console.error(e)}return h}}
{const a0=fsU6HubAfter;fsU6HubAfter=function(){const r=a0.apply(this,arguments);try{const b=$('fsh6b');if(b)b.onclick=()=>fsBountyModal('hub')}catch(e){}return r}}
{const st=document.createElement('style');st.textContent=`
.fsh7{position:absolute;left:48px;top:612px;width:690px;height:84px;animation:fsIn .6s .28s var(--sp) both}
.fsh7b{width:100%;height:100%;display:flex;align-items:center;gap:10px;padding:0 16px 0 6px;color:#fff8e8;text-align:left;cursor:pointer;transition:transform .15s}.fsh7b:hover{transform:translateY(-3px)}
.fsh7b canvas{flex:none;width:80px;height:68px}.fsh7t{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}.fsh7t b{font:800 19px var(--ui)}.fsh7t small{font:600 14px var(--ui);color:#c4badf;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.fsh7p{display:flex;gap:6px}.fsh7p i{position:relative;width:34px;height:10px;border-radius:6px;background:#0a0620;border:1.5px solid #3a3070;overflow:hidden}
.fsh7p i::after{content:'';position:absolute;inset:0;background:var(--bc);transform-origin:left;transform:scaleX(var(--p))}.fsh7p i.ok{border-color:var(--bc)}
.fsh7s{display:flex;align-items:center;gap:2px;font:800 14px var(--ui);color:#ffb45a;font-style:normal}.fsh7s svg{width:18px;height:18px}
.fsh2s{max-width:690px}
.fsbp{position:relative;width:1240px;max-height:860px;display:flex;flex-direction:column;padding:18px 22px;animation:fsWb .35s var(--sp) both}
.fsbp-hd p{margin:0 0 12px;font:500 15px var(--ui);color:#cfc6ee;max-width:1100px}.fsbp-hd p b{color:#9affc8}
.fsbp-g{display:grid;grid-template-columns:repeat(5,1fr);gap:12px;padding-top:12px}
.fsbp-c{position:relative;display:flex;flex-direction:column;gap:6px;padding:12px 12px 12px;border-radius:18px;background:#120c34e6;border:2px solid #3a3070;min-width:0}
.fsbp-c.on{border-color:var(--bc);background:linear-gradient(180deg,color-mix(in srgb,var(--bc) 20%,#120c34),#120c34e6 55%)}.fsbp-c.rec:not(.on){border-color:#ffd45a88}.fsbp-c.lk{opacity:.55}
.fsbp-rec,.fsbp-on{position:absolute;top:-11px;left:12px;padding:2px 9px;border-radius:8px;font:800 11px var(--ui);letter-spacing:.06em;text-transform:uppercase;border:2px solid #1b1024}
.fsbp-rec{background:#ffd45a;color:#3a2006}.fsbp-on{left:auto;right:12px;background:var(--bc);color:#1b1024}
.fsbp-top{display:flex;align-items:center;gap:8px}.fsbp-top canvas{width:76px;height:76px;flex:none}.fsbp-top div{display:flex;flex-direction:column;gap:3px;min-width:0}
.fsbp-top b{font:800 16px var(--ui);color:#fff8e8}.fsbp-fx{align-self:flex-start;padding:2px 8px;border-radius:8px;background:#0a0620;border:1.5px solid var(--bc);color:var(--bc);font:800 12px var(--ui);font-style:normal;white-space:nowrap}
.fsbp-have{font:700 12px var(--ui);color:#9affc8}.fsbp-have.no{color:#8a80b0}
.fsbp-d{margin:0;font:500 13px/1.35 var(--ui);color:#e0daf8}.fsbp-for{margin:0;font:600 12px var(--ui);color:#a89ed0}
.fsbp-pv{margin:0;min-height:34px;font:600 13px var(--ui);color:#c4badf}.fsbp-pv b{color:#fff}.fsbp-pv b.up{color:#9affc8}
.fsbp-b{margin-top:auto;display:flex;flex-direction:column;gap:6px}
.fsbp-b button{width:100%;min-height:42px;padding:4px 10px;border-radius:12px;border:2px solid #1b1024;font:800 14px var(--ui);cursor:pointer;display:flex;align-items:center;justify-content:space-between;gap:6px;transition:transform .12s}
.fsbp-b button small{font:600 11px var(--ui);opacity:.85;text-align:right}.fsbp-b button span{display:flex;align-items:center;gap:4px}
.fsbp-use{justify-content:center!important;background:linear-gradient(180deg,#9affc8,#2ac87a);color:#06301a;box-shadow:0 3px 0 #1a7a4a}.fsbp-use.on{background:#2a2060;color:#fff;border-color:#5a4ca0!important;box-shadow:none}
.fsbp-buy{background:linear-gradient(180deg,#ffe27a,#f2b631);color:#3a2006;box-shadow:0 3px 0 #9a6a10}.fsbp-cr{background:linear-gradient(180deg,#8ae0ff,#3a8ad8);color:#06203a;box-shadow:0 3px 0 #1a4a8a}
.fsbp-b button:disabled{background:#2a2450;color:#8a80b0;box-shadow:none;cursor:not-allowed;border-color:#3a3070}.fsbp-b button:not(:disabled):hover{transform:translateY(-2px)}
.fsbp-f{margin:12px 0 0;font:500 13px var(--ui);color:#a89ed0}.fsbp-f b{color:#fff8e8}
.fsbq{position:absolute;left:22px;bottom:162px;z-index:4;width:300px;padding:10px;border-radius:16px;display:flex;flex-direction:column;gap:5px;animation:fsBq .22s var(--sp) both}
@keyframes fsBq{0%{opacity:0;transform:translateY(10px) scale(.96)}100%{opacity:1;transform:none}}
.fsbq-h{font:800 15px var(--ui);color:#fff8e8;padding:0 4px 2px}.fsbq-h small{font:600 12px var(--ui);color:#a89ed0}
.fsbq-i{display:flex;align-items:center;gap:8px;padding:4px 8px 4px 4px;border-radius:11px;border:2px solid transparent;background:#0b0724b8;color:#fff8e8;text-align:left;cursor:pointer}
.fsbq-i canvas{width:40px;height:40px;flex:none}.fsbq-i span{flex:1;display:flex;flex-direction:column;min-width:0}.fsbq-i b{font:800 14px var(--ui)}.fsbq-i small{font:600 12px var(--ui);color:#c4badf;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.fsbq-i.on{border-color:var(--bc,#8a7ad8)}.fsbq-i:hover,.fsbq-i:focus-visible{border-color:#ffd45a;outline:none}
.fsbq-more{margin-top:3px;height:38px;border-radius:11px;border:2px solid #1b1024;background:linear-gradient(180deg,#ffe27a,#f2b631);color:#3a2006;font:800 14px var(--ui);cursor:pointer}
.fsbc.out{border-color:#ff8a8a}.fsbc.out small{color:#ffb0b0}
@media (prefers-reduced-motion:reduce){.fsbq{animation:none}}
`;document.head.appendChild(st)}
/* ---------- why a catch is worth keeping: a rod look it helps craft comes first ---------- */
/* the unmade rod looks this fish counts toward, closest to finished first: [{k,have,n,left}] */
function fsRodNeeds(c){const F=fsP(),out=[];for(const k of FSKINK){const n=FSKIN[k].k[c.id];if(F.sk[k]||!n)continue;const have=F.cr.filter(x=>x.id===c.id).length;if(have>=n)continue;
  const left=Object.entries(FSKIN[k].k).reduce((a,[id,m])=>a+Math.max(0,m-F.cr.filter(x=>x.id===id).length),0);out.push({k,have,n,left})}
 return out.sort((a,b)=>a.left-b.left)}
/* The reason shown as "Worth keeping: …" (and used for the default Keep):
   1. a rod look it helps complete (only while "Save fish I need for rod looks" is on, unless the fish is Rare or rarer and kept anyway)
   2. its rarity (Rare / Legendary / Mythic catch), 3. a new species, 4. a giant */
function fsKeepWhy(c){if(!c||!FISH[c.id]||c.odd)return'';const F=fsP(),rare=FSR[c.rk].k>=2;
 const rods=(F.look!==0||rare)?fsRodNeeds(c):[];if(rods.length){const r=rods[0],more=rods.length-1;return`for the ${FSKIN[r.k].n} rod (${r.have}/${r.n})${more?` · +${more} more`:''}`}
 if(rare)return FSR[c.rk].n+' catch';if(c.info&&c.info.first)return'New species!';if(c.g)return'Giant!';return''}
/* 8.3 fix: the Creel tab now updates as soon as a fish is kept or sold (it used to wait for a refresh) */
function fsCrSig(){const c=fsP().cr||[];return c.length+':'+c.map(x=>x.id+(x.cm||'')).join(',')}
{const t0=fsTabs;fsTabs=function(){const r=t0.apply(this,arguments);try{if(FSU.tab==='c')FSU.crSig=fsCrSig()}catch(e){}return r}}
{const h0=fsHudRefresh;fsHudRefresh=function(){const r=h0.apply(this,arguments);try{const b=$('fsbody');if(S.view==='fish'&&FSU.tab==='c'&&b&&fsCrSig()!==FSU.crSig){const st=b.scrollTop;fsTabs();b.scrollTop=st}}catch(e){}return r}}
