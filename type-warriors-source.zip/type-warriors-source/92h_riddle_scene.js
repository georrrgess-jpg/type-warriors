/* ===== RUNESTONE RIDDLE 8.4b: the sanctum, the rune arch and today's keeper =====
   Scene: a torch-lit rune sanctum painted once per fit onto #rrbg (stone wall, arches, pillars, banners, rug, book piles,
   candles, vignette); only the two torch flames (small canvases) and CSS motes move.
   Arch: the carved stone around the board is baked once per size; every frame its eleven runes glow by heat (0..1 from
   rrHeatOf: greens count double, golds once). Runes wake from the bottom up, shift from violet to gold, pulse faster, and
   embers rise past the pillars as you get closer. A green tile flash ripples the recess. The arch tilts toward the pointer.
   Keeper: today's host (Silas Veil three days in seven, or a Dragon Lounge regular in scholar's dress, from 92f/92g) stands
   at the left on #rrhost and reacts: points at the board, thinks, cheers when you get warmer, casts on a rune power,
   celebrates a win and droops on a loss, with a speech bubble. Canvas work avoids shadowBlur and ctx.filter. */
const RRA_GLY=[[[0,-1,0,1],[0,-.4,.6,-.9],[0,.1,.6,-.4]],[[-.4,-1,-.4,1],[-.4,-1,.5,-.3],[.5,-.3,-.4,.3]],[[-.5,1,0,-1],[0,-1,.5,1],[-.3,.2,.3,.2]],
 [[-.5,-1,-.5,1],[.5,-1,.5,1],[-.5,-.4,.5,.4]],[[0,-1,0,1],[-.5,-.5,.5,.5],[.5,-.5,-.5,.5]],[[-.5,-1,.5,1],[.5,-1,-.5,1]],[[0,-1,0,1],[0,-1,.5,-.5],[0,-1,-.5,-.5]],
 [[-.4,-1,-.4,1],[-.4,0,.5,-1],[-.4,0,.5,1]],[[0,-1,0,1],[-.5,-.2,0,.3],[.5,-.2,0,.3]],[[-.5,-.6,0,-1],[0,-1,.5,-.6],[.5,-.6,-.5,.6],[-.5,.6,0,1],[0,1,.5,.6]],[[0,-1,.55,-.35],[.55,-.35,-.45,.6],[0,-1,-.55,-.35],[-.55,-.35,.45,.6],[-.45,.6,-.7,1],[.45,.6,.7,1]]];
const rrMix=(a,b,u)=>{const p=h=>[1,3,5].map(i=>parseInt(h.slice(i,i+2),16)),A=p(a),B=p(b);return'#'+A.map((v,i)=>Math.round(v+(B[i]-v)*u).toString(16).padStart(2,'0')).join('')};
const rrFr=x=>x-Math.floor(x);
/* ---------- the backdrop ---------- */
function rrBgPaint(cv){const W=cv.width,H=cv.height,g=cv.getContext('2d');const rnd=i=>rrFr(Math.sin(i*12.9898+4.1)*43758.5453);
 let q=g.createLinearGradient(0,0,0,H);q.addColorStop(0,'#1c1036');q.addColorStop(.6,'#120a26');q.addColorStop(1,'#0a0616');g.fillStyle=q;g.fillRect(0,0,W,H);
 /* stone wall blocks */
 const bh=46,fl=H*.8;for(let r=0,y=0;y<fl;r++,y+=bh){const off=(r%2)*55;for(let x=-off,i=0;x<W;i++){const w=90+rnd(r*31+i)*60;const v=rnd(r*7+i*3);g.fillStyle=rrMix('#241838','#33244e',v*.7);g.globalAlpha=.55+.25*(1-y/fl);
  g.beginPath();g.roundRect(x+2,y+2,w-4,bh-4,6);g.fill();x+=w}}g.globalAlpha=1;
 /* the great arch behind the board and two side arches */
 const arch=(cx,w,top,bot,col,rim)=>{g.beginPath();g.moveTo(cx-w/2,bot);g.lineTo(cx-w/2,top+w*.42);g.quadraticCurveTo(cx-w/2,top,cx,top-w*.08);g.quadraticCurveTo(cx+w/2,top,cx+w/2,top+w*.42);g.lineTo(cx+w/2,bot);g.closePath();
  g.fillStyle=col;g.fill();g.lineWidth=14;g.strokeStyle=rim;g.stroke();g.lineWidth=4;g.strokeStyle='#12081f';g.stroke()};
 arch(W/2,W*.5,H*.1,fl,'#0e0820','#2c2244');arch(W*.17,W*.2,H*.2,fl,'#110a24','#2a2040');arch(W*.83,W*.2,H*.2,fl,'#110a24','#2a2040');
 q=g.createRadialGradient(W/2,H*.38,20,W/2,H*.38,W*.32);q.addColorStop(0,'#5a2aa833');q.addColorStop(1,'#0000');g.fillStyle=q;g.fillRect(0,0,W,H);
 /* banners */
 const ban=(cx,top,w,h)=>{g.fillStyle='#3a2a10';g.fillRect(cx-w/2-10,top-8,w+20,8);g.fillStyle='#c98a10';g.beginPath();g.arc(cx-w/2-12,top-4,6,0,TAU);g.arc(cx+w/2+12,top-4,6,0,TAU);g.fill();
  g.beginPath();g.moveTo(cx-w/2,top);g.lineTo(cx+w/2,top);g.lineTo(cx+w/2,top+h);g.lineTo(cx,top+h+w*.32);g.lineTo(cx-w/2,top+h);g.closePath();q=g.createLinearGradient(cx-w/2,0,cx+w/2,0);q.addColorStop(0,'#5a2490');q.addColorStop(.6,'#3e1670');q.addColorStop(1,'#2a0e50');g.fillStyle=q;g.fill();
  g.lineWidth=4;g.strokeStyle='#12081f';g.stroke();g.lineWidth=3;g.strokeStyle='#d8a028';g.beginPath();g.moveTo(cx-w/2+9,top+6);g.lineTo(cx-w/2+9,top+h-4);g.lineTo(cx,top+h+w*.32-12);g.lineTo(cx+w/2-9,top+h-4);g.lineTo(cx+w/2-9,top+6);g.stroke();
  const ey=top+h*.48;g.fillStyle='#d8a028';g.beginPath();g.moveTo(cx,ey-w*.3);g.lineTo(cx+w*.22,ey);g.lineTo(cx,ey+w*.3);g.lineTo(cx-w*.22,ey);g.closePath();g.fill();g.lineWidth=3;g.strokeStyle='#12081f';g.stroke();
  g.fillStyle='#3e1670';g.beginPath();g.moveTo(cx,ey-w*.16);g.lineTo(cx+w*.11,ey);g.lineTo(cx,ey+w*.16);g.lineTo(cx-w*.11,ey);g.closePath();g.fill();g.fillStyle='#ffe48a';g.beginPath();g.arc(cx,ey,3.5,0,TAU);g.fill()};
 ban(W*.17,H*.27,W*.075,H*.3);ban(W*.83,H*.27,W*.075,H*.3);
 /* pillars at the edges */
 const pil=(x,w,lit)=>{q=g.createLinearGradient(x,0,x+w,0);q.addColorStop(0,lit<0?'#4a3a5a':'#251a36');q.addColorStop(.5,'#3a2c4c');q.addColorStop(1,lit>0?'#4a3a5a':'#1c1428');g.fillStyle=q;g.fillRect(x,0,w,fl+8);
  g.strokeStyle='#12081f55';g.lineWidth=3;for(let i=1;i<4;i++){g.beginPath();g.moveTo(x+w*i/4,H*.12);g.lineTo(x+w*i/4,fl-30);g.stroke()}
  g.fillStyle='#2e2240';g.fillRect(x-10,H*.08,w+20,26);g.fillRect(x-12,fl-36,w+24,40);g.strokeStyle='#12081f';g.lineWidth=4;g.strokeRect(x-10,H*.08,w+20,26);g.strokeRect(x-12,fl-36,w+24,40);g.strokeRect(x,0,w,fl+8)};
 pil(-10,W*.07,1);pil(W-W*.07+10,W*.07,-1);
 /* torch brackets (the flames are live canvases) */
 for(const tx of [W*.085,W*.915]){const ty=H*.43;g.fillStyle='#2a2030';g.strokeStyle='#12081f';g.lineWidth=4;g.beginPath();g.moveTo(tx-22,ty);g.lineTo(tx+22,ty);g.lineTo(tx+12,ty+18);g.lineTo(tx-12,ty+18);g.closePath();g.fill();g.stroke();
  g.fillRect(tx-5,ty+18,10,40);g.strokeRect(tx-5,ty+18,10,40);g.fillStyle='#8a5a20';g.beginPath();g.ellipse(tx,ty,22,6,0,0,TAU);g.fill();g.stroke();
  q=g.createRadialGradient(tx,ty-30,10,tx,ty-30,W*.16);q.addColorStop(0,'#ff9a3a30');q.addColorStop(1,'#0000');g.fillStyle=q;g.fillRect(0,0,W,H)}
 /* floor and rug */
 q=g.createLinearGradient(0,fl,0,H);q.addColorStop(0,'#1e1430');q.addColorStop(1,'#0e0918');g.fillStyle=q;g.fillRect(0,fl,W,H-fl);
 g.strokeStyle='#ffffff0c';g.lineWidth=2;for(let i=0;i<5;i++){const y=fl+(H-fl)*(i/5)**1.4;g.beginPath();g.moveTo(0,y);g.lineTo(W,y);g.stroke()}
 for(let i=-8;i<=8;i++){g.beginPath();g.moveTo(W/2+i*70,fl);g.lineTo(W/2+i*190,H);g.stroke()}
 g.beginPath();g.moveTo(W*.32,fl+20);g.lineTo(W*.68,fl+20);g.lineTo(W*.78,H);g.lineTo(W*.22,H);g.closePath();q=g.createLinearGradient(0,fl,0,H);q.addColorStop(0,'#3a1a5e');q.addColorStop(1,'#2a1048');g.fillStyle=q;g.fill();
 g.lineWidth=4;g.strokeStyle='#12081f';g.stroke();g.strokeStyle='#c98a10';g.lineWidth=3;g.beginPath();g.moveTo(W*.335,fl+30);g.lineTo(W*.665,fl+30);g.lineTo(W*.755,H);g.moveTo(W*.335,fl+30);g.lineTo(W*.245,H);g.stroke();
 g.fillStyle='#c98a1088';for(let i=0;i<9;i++){const x=W*.36+i*(W*.28/8);g.beginPath();g.moveTo(x,fl+44);g.lineTo(x+8,fl+52);g.lineTo(x,fl+60);g.lineTo(x-8,fl+52);g.closePath();g.fill()}
 /* book piles and candles */
 const books=(x,y,n,s)=>{const cols=['#5a2a8a','#2a4a8a','#8a2a3a','#2a6a4a','#7a5a20'];for(let i=0;i<n;i++){const w=(70+rnd(x+i)*40)*s,h=16*s,bx=x-w/2+(rnd(i+x*2)-.5)*14*s,by=y-(i+1)*h;
  g.fillStyle=cols[(i+Math.floor(x))%5];g.strokeStyle='#12081f';g.lineWidth=3;g.beginPath();g.roundRect(bx,by,w,h-2,3);g.fill();g.stroke();g.fillStyle='#ffe0a066';g.fillRect(bx+6,by+4*s,w-12,2*s)}
  return y-n*16*s};
 const candle=(x,y,h)=>{g.fillStyle='#f0e2c0';g.strokeStyle='#12081f';g.lineWidth=3;g.beginPath();g.roundRect(x-7,y-h,14,h,3);g.fill();g.stroke();
  q=g.createRadialGradient(x,y-h-10,2,x,y-h-10,60);q.addColorStop(0,'#ffcf6a66');q.addColorStop(1,'#0000');g.fillStyle=q;g.fillRect(x-60,y-h-70,120,120);
  g.fillStyle='#ffb43a';g.beginPath();g.moveTo(x,y-h-20);g.quadraticCurveTo(x+7,y-h-6,x,y-h-2);g.quadraticCurveTo(x-7,y-h-6,x,y-h-20);g.fill();g.fillStyle='#fff3c0';g.beginPath();g.arc(x,y-h-7,2.5,0,TAU);g.fill()};
 let t1=books(W*.06,H-6,5,1.1);candle(W*.06,t1,36);let t2=books(W*.94,H-6,6,1.1);candle(W*.94+6,t2,28);books(W*.13,H-4,2,.9);books(W*.87,H-4,3,.9);
 /* vignette */
 q=g.createRadialGradient(W/2,H*.45,H*.3,W/2,H*.5,W*.75);q.addColorStop(0,'#0000');q.addColorStop(1,'#000000a8');g.fillStyle=q;g.fillRect(0,0,W,H)}
/* ---------- torch flames ---------- */
function rrFlame(cv,ph){const g=cv.getContext('2d'),W2=cv.width,H2=cv.height;return t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,W2,H2);const cx=W2/2,by=H2-14;
 for(let L=0;L<3;L++){const s=[1,.72,.42][L],col=[['#ff5a1a','#ff9a2a'],['#ffb43a','#ffd45a'],['#fff6c8','#ffe48a']][L];const w=26*s,h=(82+Math.sin(t*9+ph)*8+Math.sin(t*13.7+ph*2)*5)*s;
  const sw=Math.sin(t*6+ph+L)*6*s;const q=g.createLinearGradient(0,by-h,0,by);q.addColorStop(0,col[1]);q.addColorStop(1,col[0]);g.fillStyle=q;g.globalAlpha=L?1:.92;
  g.beginPath();g.moveTo(cx-w,by);g.quadraticCurveTo(cx-w*1.1,by-h*.45,cx+sw,by-h);g.quadraticCurveTo(cx+w*1.1,by-h*.45,cx+w,by);g.quadraticCurveTo(cx,by+8*s,cx-w,by);g.fill()}
 g.globalAlpha=1;for(let i=0;i<4;i++){const u=rrFr(t*.9+i*.27+ph),x=cx+Math.sin(t*3+i*2)*12*u,y=by-30-u*90;g.globalAlpha=(1-u)*.9;g.fillStyle=i%2?'#ffd45a':'#ff8a3a';g.beginPath();g.arc(x,y,2.4*(1-u)+.6,0,TAU);g.fill()}g.globalAlpha=1}}
/* ---------- the rune arch ---------- */
function rrArchGeo(){const r=$('rr'),t=parseFloat(getComputedStyle(r).getPropertyValue('--t'))||69,gp=t*.12,gw=5*t+4*gp,gh=6*t+5*gp,side=Math.round(t*.95),top=Math.round(t*1.18),bot=Math.round(t*.42);
 return{t,gw,gh,side,top,bot,W:Math.round(gw+2*side),H:Math.round(gh+top+bot)}}
function rrArchRunes(G){const out=[],n=5;for(let i=0;i<n;i++){const y=G.top+G.gh*(i+.5)/n;out.push({x:G.side*.42,y,o:i*2},{x:G.W-G.side*.42,y,o:i*2+1})}
 out.sort((a,b)=>b.y-a.y);out.forEach((p,i)=>{p.o=i;p.gl=RRA_GLY[i%10]});out.push({x:G.W/2,y:G.top*.42,o:10,gl:RRA_GLY[10],big:1});return out}
function rrArchBake(G){const c=document.createElement('canvas');c.width=G.W;c.height=G.H;const g=c.getContext('2d'),W=G.W,H=G.H,s=G.side;
 const path=()=>{g.beginPath();g.moveTo(4,H-4);g.lineTo(4,G.top*.72);g.quadraticCurveTo(4,G.top*.36,s*.9,G.top*.3);g.lineTo(W*.36,G.top*.22);g.quadraticCurveTo(W/2,2,W*.64,G.top*.22);g.lineTo(W-s*.9,G.top*.3);g.quadraticCurveTo(W-4,G.top*.36,W-4,G.top*.72);g.lineTo(W-4,H-4);g.closePath()};
 path();let q=g.createLinearGradient(0,0,W,H);q.addColorStop(0,'#5a4e70');q.addColorStop(.45,'#3e3452');q.addColorStop(1,'#272035');g.fillStyle=q;g.fill();
 g.save();path();g.clip();const rnd=i=>rrFr(Math.sin(i*78.233+1.7)*43758.5453);g.strokeStyle='#12081f40';g.lineWidth=2;
 for(let y=G.top*.5,r=0;y<H;y+=G.t*.62,r++){g.beginPath();g.moveTo(0,y);g.lineTo(s*.84,y);g.moveTo(W-s*.84,y);g.lineTo(W,y);g.stroke();const xo=(r%2?.35:.65)*s*.84;g.beginPath();g.moveTo(xo,y);g.lineTo(xo,y+G.t*.62);g.moveTo(W-xo,y);g.lineTo(W-xo,y+G.t*.62);g.stroke()}
 for(let i=0;i<70;i++){g.fillStyle=i%2?'#ffffff10':'#00000022';g.beginPath();g.arc(rnd(i)*W,rnd(i+99)*H,1+rnd(i+7)*3,0,TAU);g.fill()}
 q=g.createLinearGradient(0,0,W,0);q.addColorStop(0,'#ffffff10');q.addColorStop(.12,'#0000');q.addColorStop(.88,'#0000');q.addColorStop(1,'#00000040');g.fillStyle=q;g.fillRect(0,0,W,H);g.restore();
 path();g.lineWidth=6;g.strokeStyle='#12081f';g.stroke();
 /* the recess where the tiles sit */
 const rx=s-G.t*.26,ry=G.top-G.t*.26,rw=G.gw+G.t*.52,rh=G.gh+G.t*.42;g.beginPath();g.roundRect(rx,ry,rw,rh,G.t*.24);q=g.createLinearGradient(0,ry,0,ry+rh);q.addColorStop(0,'#120e1c');q.addColorStop(1,'#1a1626');g.fillStyle=q;g.fill();
 g.lineWidth=4;g.strokeStyle='#12081f';g.stroke();g.beginPath();g.roundRect(rx+3,ry+3,rw-6,rh-6,G.t*.2);g.lineWidth=2;g.strokeStyle='#ffffff12';g.stroke();
 /* carved rune slots and the keystone */
 for(const p of rrArchRunes(G)){const r=p.big?G.t*.36:G.t*.22;g.fillStyle='#231c30';g.strokeStyle='#12081f';g.lineWidth=3;
  if(p.big){g.beginPath();g.moveTo(p.x,p.y-r*1.5);g.lineTo(p.x+r*1.5,p.y);g.lineTo(p.x,p.y+r*1.5);g.lineTo(p.x-r*1.5,p.y);g.closePath();g.fill();g.stroke()}
  else{g.beginPath();g.roundRect(p.x-r*1.05,p.y-r*1.35,r*2.1,r*2.7,r*.5);g.fill();g.stroke()}
  g.strokeStyle='#120c1a';g.lineWidth=p.big?5:4;g.lineCap='round';g.beginPath();for(const [a,b,c2,d] of p.gl){g.moveTo(p.x+a*r,p.y+b*r);g.lineTo(p.x+c2*r,p.y+d*r)}g.stroke()}
 return c}
function rrArchLive(cv){const G=rrArchGeo();cv.width=G.W;cv.height=G.H;const bake=rrArchBake(G),runes=rrArchRunes(G),g=cv.getContext('2d');let lt=0;
 return t=>{if(!RR){return}const dt=Math.min(.1,Math.max(0,t-lt));lt=t;RR.hv=(RR.hv||0)+((RR.heat||0)-(RR.hv||0))*Math.min(1,dt*2.2);const h=RR.hv,rm=rrRM();
  g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,G.W,G.H);g.drawImage(bake,0,0);
  const col=h<.5?rrMix('#8a5aff','#c08aff',h*2):rrMix('#c08aff','#ffd45a',Math.min(1,(h-.5)*2)),sp=2+h*4;
  /* the recess breathes light as you get closer, and flashes when a green rune lands */
  if(RR.flq){RR.fl=t;RR.flq=0}const fl=Math.max(0,1-(t-(RR.fl==null?-9:RR.fl))*2.2),rx=G.side,ry=G.top,a=.07+h*.42+fl*.3;if(a>.01){const q=g.createRadialGradient(G.W/2,ry+G.gh/2,10,G.W/2,ry+G.gh/2,G.gw*.8);q.addColorStop(0,(fl>.2?'#7af0b0':col)+'00');q.addColorStop(.6,(fl>.2?'#7af0b0':col)+Math.round(a*120).toString(16).padStart(2,'0'));q.addColorStop(1,'#0000');g.fillStyle=q;g.fillRect(rx-G.t*.3,ry-G.t*.3,G.gw+G.t*.6,G.gh+G.t*.6)}
  for(const p of runes){const lit=p.big?Math.max(0,(h-.55)/.45):Math.max(0,Math.min(1,h*11-p.o)),pu=rm?1:.78+.22*Math.sin(t*sp+p.o*1.3),I=(.34+.66*lit)*pu,r=p.big?G.t*.36:G.t*.22;
   const q=g.createRadialGradient(p.x,p.y,1,p.x,p.y,r*(2.2+lit*1.2));q.addColorStop(0,col+Math.round(I*150).toString(16).padStart(2,'0'));q.addColorStop(1,col+'00');g.fillStyle=q;g.fillRect(p.x-r*3.6,p.y-r*3.6,r*7.2,r*7.2);
   g.globalAlpha=Math.min(1,.25+I);g.strokeStyle=lit>.5?'#fff6d8':col;g.lineWidth=p.big?4:3;g.lineCap='round';g.beginPath();for(const [a2,b,c2,d] of p.gl){g.moveTo(p.x+a2*r,p.y+b*r);g.lineTo(p.x+c2*r,p.y+d*r)}g.stroke();g.globalAlpha=1}
  /* embers rising past the pillars, more and faster with heat */
  if(!rm){const n=Math.round(h*18);for(let i=0;i<n;i++){const side=i%2,u=rrFr(t*(.18+h*.25)+i*.137),x=(side?G.W-G.side*.42:G.side*.42)+Math.sin(t*2+i)*G.side*.3,y=G.H-u*G.H*1.05;
   g.globalAlpha=Math.sin(u*Math.PI)*(.5+h*.5);g.fillStyle=i%3?col:'#fff3c0';g.beginPath();g.arc(x,y,1.4+((i*7)%3)*.8,0,TAU);g.fill()}g.globalAlpha=1}}}
function rrHeatPulse(s){if(RR&&s==='c')RR.flq=1}
/* ---------- fit and start ---------- */
function rrSceneFit(){const r=$('rr'),bg=$('rrbg'),ac=$('rrarch');if(!r||!bg)return;const W=r.offsetWidth||1600,H=Math.min(2400,Math.max(r.offsetHeight,ov.clientHeight||900));
 if(bg.width!==W||bg.height!==H||!bg.dataset.ok){bg.width=W;bg.height=H;bg.dataset.ok=1;try{rrBgPaint(bg)}catch(e){}}
 const tl=r.querySelector('.rrtorch.l'),tr=r.querySelector('.rrtorch.r');if(tl){tl.style.left=(W*.085-45)+'px';tl.style.top=(H*.43-118)+'px'}if(tr){tr.style.left=(W*.915-45)+'px';tr.style.top=(H*.43-118)+'px'}
 const G=rrArchGeo();r.style.setProperty('--aw',G.W+'px');r.style.setProperty('--ah',G.H+'px');r.style.setProperty('--as',G.side+'px');r.style.setProperty('--at',G.top+'px');
 if(ac&&(ac.width!==G.W||ac.height!==G.H)){for(let i=LIVE.length-1;i>=0;i--)if(LIVE[i].cv===ac)LIVE.splice(i,1);LIVE.push({cv:ac,fn:rrArchLive(ac)})}}
function rrSceneStart(){const r=$('rr');if(!r)return;rrSceneFit();
 r.querySelectorAll('.rrtorch canvas').forEach((c,i)=>{const f=rrFlame(c,i*1.7);f(1);if(!rrRM())LIVE.push({cv:c,fn:f,slow:2,ph:i})});
 const w=$('rrarchw'),tl=$('rrtilt'),lamp=$('rrlamp');if(w&&tl&&!rrRM()&&!(typeof ovTM!=='undefined'&&ovTM)){
  w.addEventListener('pointermove',e=>{const b=w.getBoundingClientRect(),x=(e.clientX-b.left)/b.width,y=(e.clientY-b.top)/b.height;tl.style.transform=`perspective(1100px) rotateY(${((x-.5)*5).toFixed(2)}deg) rotateX(${((.5-y)*4).toFixed(2)}deg)`;
   if(lamp)lamp.style.transform=`translate(${(x*w.offsetWidth).toFixed(0)}px,${(y*w.offsetHeight).toFixed(0)}px)`});
  w.addEventListener('pointerleave',()=>{tl.style.transform=''})}}
/* ---------- today's keeper ---------- */
const RRH_ROT=['silas','gob','silas','drg','skel','silas','oct'];
const RRH_LINES={
 open:{silas:['Ah, a seeker. Today\'s rune hides in plain sight…','Five letters. Six chances. Shall we play?','The stone is cold. Wake it with a word.'],k:['Welcome to the sanctum! Carve your first word.','A fresh rune sleeps in the stone today.','Five letters, six tries. Let\'s wake it up!']},
 cold:{silas:['Not a whisper from the stone… try fresh letters.','Hmm. The runes barely stirred.'],k:['The stone barely flickered. New letters!','Cold as a crypt. Try other runes.']},
 warm:{silas:['Ooh, the runes are stirring!','Warmer… I can feel it humming.'],k:['Warmer! The runes are waking!','Now we\'re getting somewhere!']},
 hot:{silas:['So close the stone is singing!','The mask is slipping… one more push!'],k:['So close! The whole arch is glowing!','Nearly there, the runes are blazing!']},
 bad:{silas:['The stone doesn\'t know that word.','That\'s no word of power, I\'m afraid.'],k:['Hmm, that\'s not in my books.','The stone doesn\'t know that one.']},
 short:{silas:['Five runes, my friend. Five!'],k:['Five letters, please!']},
 power:{silas:['A little sleight of hand…','Let me show you a card…'],k:['Let me check my notes…','A hint from the archives!']},
 win:{silas:['Bravo! You\'ve unmasked the riddle!','Magnificent! The stone is yours!'],k:['Splendid! The runestone is yours!','You read it! Marvellous!']},
 lose:{silas:['Even phantoms keep secrets. Until tomorrow!','The rune slips away… for now.'],k:['The rune slips away… tomorrow, then.','So close. A new stone tomorrow!']},
 done:{silas:['You\'ve read today\'s stone. Fancy a practice riddle?','Come back tomorrow for a new rune.'],k:['Today\'s stone is read! Try a practice riddle.','A new rune wakes tomorrow.']}};
let RRH=null;
function rrHostKeeper(id){if(id==='silas')return{id,n:(typeof SILAS==='object'&&SILAS.n)||'Silas Veil',t:(typeof SILAS==='object'&&SILAS.t)||'Crimson Masquerade Phantom'};
 const A=typeof RRK!=='undefined'&&Array.isArray(RRK)&&RRK.find(x=>x.id===id);return A?{id,A,n:A.n,t:A.t,line:A.line}:{id:'silas',n:'Silas Veil',t:'Crimson Masquerade Phantom'}}
function rrHostPick(){if(!RR)return'silas';if(RR.mode==='p')return['silas','gob','drg','skel','oct'][(RRP().pr.pl||0)%5];const i=rrIdx(RR.key);return RRH_ROT[((i%7)+7)%7]}
function rrHostDraw(g,H,t){const e0=t-(H.m0==null?t:H.m0),st={mode:H.mode,k:Math.max(0,Math.min(1,e0/H.dur)),heat:RR?RR.hv||0:0,look:.7};
 if(H.id==='silas'){/* Silas's poses peak at k=.5 and return to idle at 1: hold sad at its peak, loop a win cheer twice */
  if(H.hold&&H.mode==='sad')st.k=Math.min(st.k,.5);else if(H.hold&&H.mode==='cheer'){st.k=(e0/H.dur)%1;if(e0>H.dur*2){H.mode='idle';H.hold=0}}
  if(typeof silasDraw==='function')silasDraw(g,t,st)}else if(typeof rrkDraw==='function'&&H.A)rrkDraw(g,H.A,t,st)}
function rrHostStart(kind){const cv=$('rrhost');if(!cv||!RR)return;const K=rrHostKeeper(rrHostPick());RRH=Object.assign({mode:'idle',m0:0,dur:1,hold:0},K);
 const n=$('rrhn');if(n)n.innerHTML=`${esc(K.n)}<small>${esc(K.t)}</small>`;const w=$('rrhostw');if(w)w.setAttribute('aria-label',`Today's keeper: ${K.n}, ${K.t}`);
 const g=cv.getContext('2d'),W2=cv.width,H2=cv.height;
 const f=t=>{if(!RRH)return;if(RRH.m0==null)RRH.m0=t;if(RRH.hold===0&&RRH.mode!=='idle'&&t-RRH.m0>RRH.dur+(RRH.lg||.25)){RRH.mode='idle';RRH.m0=t;RRH.lg=0}
  g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,W2,H2);const q=g.createRadialGradient(W2/2,H2-22,6,W2/2,H2-22,W2*.48);q.addColorStop(0,'#b88aff40');q.addColorStop(1,'#0000');g.fillStyle=q;g.fillRect(0,H2-120,W2,120);
  g.fillStyle='#00000055';g.beginPath();g.ellipse(W2/2,H2-22,W2*.3,14,0,0,TAU);g.fill();
  const sc=Math.min((H2-36)/335,W2/260)*(RRH.id==='silas'?1:.92);g.save();g.translate(W2/2,H2-22);g.scale(sc,sc);try{rrHostDraw(g,RRH,t)}catch(e){}g.restore()};
 for(let i=LIVE.length-1;i>=0;i--)if(LIVE[i].cv===cv)LIVE.splice(i,1);f(typeof S==='object'?S.t||0:0);if(!rrRM())LIVE.push({cv,fn:f});
 if(kind==='done'){rrHostMode(RRP().d[RR.key]&&RRP().d[RR.key].st==='l'?'sad':'idle',1,1);rrHostSay('done')}
 else{rrHostMode(K.id==='silas'?'ability':'point',K.id==='silas'?1.2:.7);if(K.id!=='silas')RRH.lg=2.4;rrHostSay('open',K.line)}}
function rrHostMode(m,dur,hold){if(!RRH)return;RRH.mode=m;RRH.m0=null;RRH.dur=dur||1;RRH.hold=hold?1:0}
function rrHostSay(kind,first){const b=$('rrbub');if(!b||!RRH)return;const P2=RRH_LINES[kind];if(!P2)return;const pool=RRH.id==='silas'?P2.silas:P2.k;let line=first&&Math.random()<.5?first:pool[Math.floor(Math.random()*pool.length)];
 if(line===RRH.last&&pool.length>1)line=pool[(pool.indexOf(line)+1)%pool.length];RRH.last=line;
 b.classList.remove('on');void b.offsetWidth;b.textContent=line;b.classList.add('on');try{beep(RRH.id==='silas'?740:560,.05,'sine',.05)}catch(x){}}
function rrHostReact(h,dh,s,end){if(!RRH)return;if(end==='win'){rrHostMode('cheer',1.6,1);rrHostSay('win');return}if(end==='lose'){rrHostMode('sad',1.2,1);rrHostSay('lose');return}
 if(dh>=.15){rrHostMode('cheer',1.1);rrHostSay(h>=.7?'hot':'warm')}else if(h>=.7){rrHostMode('think',2.6);rrHostSay('hot')}else{rrHostMode('think',2.6);rrHostSay(dh>0?'warm':'cold')}}
function rrHostPower(k){if(!RRH)return;rrHostMode(RRH.id==='silas'?'ability':'think',RRH.id==='silas'?1.2:2.2);rrHostSay('power')}
/* the game's "running slowly?" offer never interrupts a riddle */
{const o=pfOffer;pfOffer=function(){if(typeof S==='object'&&S.view==='riddle')return;return o.apply(this,arguments)}}
