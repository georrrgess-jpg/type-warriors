/* ---------- the bell's Updates and Calendar tabs, plus the owner-only update composer ---------- */
const UPD_SALT='c0df26146fd8dfea',UPD_HASH='98a5644f50329d1e1f2c13d54cfd08228e22ffe4948c47b0168bc51080795a39',UPD_FEED='';
/* shipped update notes. Newest last is fine, they are sorted by date. */
const UPDATES=[
 {id:'u-6.8',ts:Date.UTC(2026,9,4,22,10),tag:'New',h:'6.8 Bounties',b:'Three new contracts every day. Finish them for gold and bounty tokens, and spend the tokens on titles.'},
 {id:'u-7.0',ts:Date.UTC(2026,9,4,23,10),tag:'New',h:'7.0 Endless Mode update',b:'Endless mode has been updated.'},
 {id:'u-7.1',ts:Date.UTC(2026,9,5,1,40),tag:'New',h:'7.1 Resume Run',b:'If the game is refreshed or closed mid-run, you can now re-enter your last game or close and delete it.'},
 {id:'u-7.2',ts:Date.UTC(2026,9,5,16,10),tag:'New',h:'7.2 Halloween Update',b:'Monster Mash is here for a limited time: a cursed Endless run with new monsters, Graveyard Crates and Halloween gear.'},
 {id:'u-7.3',ts:Date.UTC(2026,9,5,19,30),tag:'New',h:'7.3 Trick-or-Treat Update',b:'LIMITED TIME: Midnight on Hollow Street is open! Knock on doors, type for candy corn, then spend it at the all-new Candy Stall on crates, the Crimson Fang and the Soulreaper.'},
 {id:'u-7.4',ts:Date.UTC(2026,9,6,14,0),tag:'New',h:'7.4 Tower Climb',b:'A new casino mode in the Special tab: climb a tower floor by floor, pick one of three doors (one hides a trap), and cash out whenever you like. Boosted payouts today only!'},
 {id:'u-7.5',ts:Date.UTC(2026,9,7,17,30),tag:'New',h:'7.5 Beginner\'s Mode',b:'A gentler way to learn Endless: short 3 to 5 letter words, fewer and slower monsters, shorter boss sentences and tips along the way. Find it in the redesigned Endless menu. It does not count toward records, trophies or bounties.'}];
/*8.0*/UPDATES.push({id:'u-8.0',ts:Date.UTC(2026,9,8,3,45),tag:'New',h:'8.0 Astral Ascendance update is OUT!',b:"Act VI, the Warden's Arena, Nebula Scratch Cards and rainbow monsters are all here!\n\n• ACT VI: ASTRAL ASCENDANCE: 3 new levels (31 to 33: Starlight Threshold, Nebula Rift and The Astral Throne), 3 huge bosses (Astraeus the Star-Forged, Nyx Queen of the Eclipse and Chronos Sovereign of Infinity) and 10 new cosmic monsters.\n• CELESTIAL CHEST: a new 5,000 gold crate with a full constellation opening scene. Rare or better weapons every time, and the only home of the Astral Cleaver (Mythic axe) and the Orbitbreaker (Legendary blade). Astral levels pay chests too.\n• WARDEN'S ARENA (limited time): a no-typing mode. Block and strike on the beat against gladiators and 3 bosses, climb the Trophy Road through Bronze, Silver and Gold brackets, and learn each new foe from its ability popup. Redesigned Bracket Spotlight menu with a Foes & Bosses gallery.\n• NEBULA SCRATCH: a brand new casino game in the Special tab. Scratch the foil with your mouse or finger, match three symbols and uncover the Lucky Star to double or triple your win, up to 100,000 coins. Claim a free ticket every day! Launch week boost: every prize pays 25% more until Oct 15!\n• RAINBOW MONSTERS: a color-shifting monster 10x rarer than a shiny (about 1 in 640). Slay one for a flat 1,000 coins."});
const SHA=(()=>{const K=[];for(let n=2,c=0;c<64;n++){let p=1;for(let d=2;d*d<=n;d++)if(n%d==0){p=0;break}if(p){K[c++]=(Math.pow(n,1/3)%1*4294967296)|0}}
 const R=(x,n)=>(x>>>n)|(x<<(32-n));
 return s=>{const b=unescape(encodeURIComponent(s)),l=b.length,w=[];for(let i=0;i<l;i++)w[i>>2]|=b.charCodeAt(i)<<(24-(i%4)*8);w[l>>2]|=128<<(24-(l%4)*8);w[(((l+8)>>6)<<4)+15]=l*8;
  let H=[1779033703,3144134277,1013904242,2773480762,1359893119,2600822924,528734635,1541459225];
  for(let o=0;o<w.length;o+=16){const a=H.slice(),x=[];for(let i=0;i<64;i++){if(i<16)x[i]=w[o+i]|0;else{const s0=R(x[i-15],7)^R(x[i-15],18)^(x[i-15]>>>3),s1=R(x[i-2],17)^R(x[i-2],19)^(x[i-2]>>>10);x[i]=(x[i-16]+s0+x[i-7]+s1)|0}
   const S1=R(a[4],6)^R(a[4],11)^R(a[4],25),ch=(a[4]&a[5])^(~a[4]&a[6]),t1=(a[7]+S1+ch+K[i]+x[i])|0,S0=R(a[0],2)^R(a[0],13)^R(a[0],22),mj=(a[0]&a[1])^(a[0]&a[2])^(a[1]&a[2]),t2=(S0+mj)|0;
   a[7]=a[6];a[6]=a[5];a[5]=a[4];a[4]=(a[3]+t1)|0;a[3]=a[2];a[2]=a[1];a[1]=a[0];a[0]=(t1+t2)|0}
   for(let i=0;i<8;i++)H[i]=(H[i]+a[i])|0}
  return H.map(v=>('00000000'+(v>>>0).toString(16)).slice(-8)).join('')}})();
const updHash=p=>{let h=SHA(UPD_SALT+':'+p);for(let i=0;i<3000;i++)h=SHA(h+UPD_SALT);return h};
function UPD(){let u=P.upd;if(!u||typeof u!=='object'||Array.isArray(u))u=P.upd={seen:[],mine:[],feed:[],dis:{}};
 for(const k of['seen','mine','feed'])if(!Array.isArray(u[k]))u[k]=[];if(!u.dis||typeof u.dis!=='object')u.dis={};return u}
const updOk=e=>e&&typeof e.id==='string'&&typeof e.h==='string'&&typeof e.b==='string'&&isFinite(e.ts);
function updAll(){const u=UPD(),m=new Map();for(const e of[...UPDATES,...u.feed,...u.mine])if(updOk(e)&&!m.has(e.id))m.set(e.id,e);return[...m.values()].sort((a,b)=>b.ts-a.ts).slice(0,40)}
const updUnread=()=>{try{const s=new Set(UPD().seen);return updAll().filter(e=>!s.has(e.id)).length}catch(e){return 0}};
function updMarkRead(){const u=UPD();const s=new Set(u.seen);let ch=0;for(const e of updAll())if(!s.has(e.id)){s.add(e.id);ch=1}if(ch){u.seen=[...s].slice(-300);save()}}
const updSig=a=>a[0]+'|'+a[2]+'|'+dlLocal(new Date());
function updFilter(a){try{const d=UPD().dis;return a.filter(x=>!d[updSig(x)])}catch(e){return a}}
function updClear(al){const u=UPD(),t=dlLocal(new Date());for(const k of Object.keys(u.dis))if(k.slice(-10)!==t)delete u.dis[k];for(const a of al)u.dis[updSig(a)]=1;updMarkRead();save()}
let UPD_OWN=0,BELL_TAB='a',BELL_AL=[],BELL_MSG='';
const updOwner=()=>UPD_OWN&&Date.now()-UPD_OWN<30*60*1000;
const UPD_TAGC={New:'#5ad88a',Fix:'#6ab8ff',Balance:'#ffc94a',Event:'#d08aff'};
const updDate=ts=>{const d=new Date(ts);return DL_MONTHS[d.getMonth()].slice(0,3)+' '+d.getDate()};
const updCalIc=(z=17)=>`<svg viewBox="0 0 24 24" width="${z}" height="${z}" aria-hidden="true"><rect x="3.5" y="5" width="17" height="15" rx="2.2" fill="none" stroke="currentColor" stroke-width="2"/><path d="M3.5 10h17M8 3v4M16 3v4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>`;
function bellInner(){const al=BELL_AL,un=updUnread(),T=BELL_TAB;
 const tabs=`<div class="bltabs" role="tablist"><button role="tab" class="${T==='a'?'on':''}" data-bt="a">Alerts${al.length?`<i>${al.length}</i>`:''}</button><button role="tab" class="${T==='u'?'on':''}" data-bt="u">Updates${un?`<i>${un}</i>`:''}</button><button role="tab" class="${T==='n'?'on':''}" data-bt="n">News</button>${updOwner()?`<button role="tab" class="${T==='s'?'on':''}" data-bt="s">Ideas${sgCount()?`<i>${sgCount()}</i>`:''}</button>`:''}</div>`;
 let body='';
 if(T==='a')body=al.length?al.map(a=>`<button class="belr" data-al="${a[0]}" id="al_${a[0]}"><span>${mico(a[1],30)}</span><span><b>${a[2]}</b><small>${a[3]}</small></span><i>›</i></button>`).join(''):'<p>You are all caught up.</p>';
 else if(T==='n')body=(BELL_MSG?`<p class="blm">${esc(BELL_MSG)}</p>`:'')+newsBody();
 else if(T==='s')body=(BELL_MSG?`<p class="blm">${esc(BELL_MSG)}</p>`:'')+sgBody();
 else if(T==='u'){const s=new Set(UPD().seen),L=updAll();
  body=(updOwner()?updComposer():'')+(L.length?L.map(e=>`<article class="blu${s.has(e.id)?'':' new'}"><div><span class="blt" style="--c:${UPD_TAGC[e.tag]||'#a98aff'}">${esc(e.tag||'News')}</span><em>${updDate(e.ts)}</em></div><b>${esc(e.h)}</b><small>${esc(e.b)}</small>${updOwner()&&e.id[0]==='o'?`<button class="blx" data-ud="${esc(e.id)}">Remove</button>`:''}</article>`).join(''):'<p>No updates yet.</p>');
  if(BELL_MSG)body=`<p class="blm">${esc(BELL_MSG)}</p>`+body}

 return tabs+`<div class="blbody">${body}</div>`+(`<button class="blclr" id="blclr" ${al.length||un?'':'disabled'}>Clear notifications</button>`)}
function updComposer(){return `<div class="blco"><b>Push an update</b><input id="uh" maxlength="60" placeholder="Title" autocomplete="off"><textarea id="ub" maxlength="260" rows="3" placeholder="What changed?"></textarea><div class="blrow"><select id="ut">${Object.keys(UPD_TAGC).map(t=>`<option>${t}</option>`).join('')}</select><button class="sm" id="upush">Push</button><button class="sm" id="ucopy">Copy feed</button><button class="sm" id="ulock">Lock</button></div></div>`}
function updUnlockForm(){return `<div class="blco"><b>Owner access</b><input id="upw" type="password" placeholder="Passphrase" autocomplete="off"><div class="blrow"><button class="sm" id="upgo">Unlock</button><button class="sm" id="upno">Cancel</button></div></div>`}
function bellRender(act){const p=$('bellp');if(!p)return;const keep=p.scrollTop;p.innerHTML=bellInner();bellWire(p,act);p.scrollTop=keep;
 const bd=$('bell'),n=BELL_AL.length+updUnread();if(bd){bd.classList.toggle('ring',n>0);let i=bd.querySelector('.bdg');if(n){if(!i){i=document.createElement('i');i.className='bdg';bd.appendChild(i)}i.textContent=n}else if(i)i.remove()}}
function bellWire(p,act){
 p.querySelectorAll('[data-bt]').forEach(b=>b.onclick=e=>{e.stopPropagation();BELL_TAB=b.dataset.bt;BELL_MSG='';if(BELL_TAB==='s')sgPull(()=>bellRender(act));if(BELL_TAB==='u'){bellRender(act);updMarkRead();const bd=$('bell');if(bd){bd.classList.toggle('ring',BELL_AL.length>0)}}else bellRender(act)});
 p.querySelectorAll('[data-al]').forEach(r=>r.onclick=()=>act[r.dataset.al]());
 const c=$('blclr');if(c)c.onclick=e=>{e.stopPropagation();updClear(BELL_AL);BELL_AL=[];BELL_MSG='';bellRender(act);beep(520,.05,'triangle',.4)};
 const stop=e=>e.stopPropagation();p.querySelectorAll('input,textarea,select').forEach(x=>{x.onkeydown=stop;x.onkeyup=stop;x.onkeypress=stop});
 const go=$('upgo');if(go){const f=$('upw');setTimeout(()=>f.focus(),30);const run=()=>{const ok=updHash(f.value.trim().toLowerCase())===UPD_HASH;f.value='';if(ok){UPD_OWN=Date.now();BELL_MSG='Owner access unlocked for 30 minutes.'}else{BELL_MSG='That passphrase is not right.';beep(140,.12,'sawtooth',.4)}bellRender(act)};go.onclick=run;f.addEventListener('keydown',e=>{if(e.key==='Enter')run();if(e.key==='Escape'){BELL_MSG='';bellRender(act)}});$('upno').onclick=()=>{BELL_MSG='';bellRender(act)}}
 const ps=$('upush');if(ps)ps.onclick=()=>{if(!updOwner()){bellRender(act);return}const h=$('uh').value.trim(),b=$('ub').value.trim();if(!h||!b){BELL_MSG='Add a title and a message first.';bellRender(act);return}
  const u=UPD();u.mine.unshift({id:'o'+Date.now().toString(36),ts:Date.now(),tag:$('ut').value,h:h.slice(0,60),b:b.slice(0,260)});u.mine=u.mine.slice(0,40);save();BELL_MSG='Update pushed.';BELL_TAB='u';bellRender(act);updMarkRead();beep(880,.08,'triangle',.5)};
 const cp=$('ucopy');if(cp)cp.onclick=()=>{const j=JSON.stringify(UPD().mine,null,1);const done=ok=>{BELL_MSG=ok?'Feed copied. Paste it into UPDATES in the game file to ship it to every player.':'Could not copy. Select it from the box below.';bellRender(act);if(!ok){const t=document.createElement('textarea');t.className='blj';t.value=j;t.readOnly=true;$('bellp').appendChild(t);t.select()}};try{navigator.clipboard.writeText(j).then(()=>done(1),()=>done(0))}catch(e){done(0)}};
 const lk=$('ulock');if(lk)lk.onclick=()=>{UPD_OWN=0;BELL_MSG='Locked.';bellRender(act)};
 p.querySelectorAll('[data-ud]').forEach(b=>b.onclick=()=>{if(!updOwner())return;const u=UPD();u.mine=u.mine.filter(e=>e.id!==b.dataset.ud);save();bellRender(act)});
 newsWire(p,act)}
/* hidden: with the bell open on the Updates tab, Shift+U asks for the owner passphrase */
window.addEventListener('keydown',e=>{const p=document.getElementById('bellp');if(!p||!p.classList.contains('open')||(BELL_TAB!=='u'&&BELL_TAB!=='n')||e.repeat)return;
 if(e.shiftKey&&(e.key==='U'||e.key==='u')&&!/INPUT|TEXTAREA|SELECT/.test((e.target&&e.target.tagName)||'')){e.preventDefault();e.stopImmediatePropagation();if(updOwner()){BELL_MSG='Already unlocked.'}else{BELL_MSG='';const b=p.querySelector('.blbody');if(b&&!$('upw')){b.insertAdjacentHTML('afterbegin',updUnlockForm());const act=window.__bellAct;bellWire(p,act)}}}},true);
/* optional hosted feed: set UPD_FEED to the address of a JSON list the owner controls */
if(UPD_FEED)setTimeout(()=>{try{fetch(UPD_FEED,{cache:'no-store'}).then(r=>r.json()).then(a=>{if(Array.isArray(a)){UPD().feed=a.filter(updOk).slice(0,30).map(e=>({id:String(e.id).slice(0,40),ts:+e.ts,tag:String(e.tag||'News').slice(0,12),h:String(e.h).slice(0,60),b:String(e.b).slice(0,260)}));save()}}).catch(()=>{})}catch(e){}},3000);
