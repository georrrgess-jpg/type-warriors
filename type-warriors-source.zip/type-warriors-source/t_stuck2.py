import asyncio,os
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append('PE '+str(e)[:300]))
        await pg.goto('file://'+os.path.abspath('out.html'));await pg.wait_for_timeout(1200);E=pg.evaluate
        for entry in ["document.getElementById('dk_pt').click()","catalog(title,'Pets')","petFromResults()"]:
            await E("()=>{RS_ASK=false;P.pets={bramble:{b:0}};P.pet='bramble';P.petSt=1;P.petPend=null;petNorm();title()}");await pg.wait_for_timeout(500)
            await E("()=>{"+entry+"}");await pg.wait_for_timeout(600)
            vis=await E("()=>{const bs=[...document.querySelectorAll('button')].filter(b=>/Back/.test(b.textContent)&&b.offsetParent);return bs.map(b=>{const r=b.getBoundingClientRect();return [b.id,b.className,Math.round(r.x),Math.round(r.y)]})}")
            print(entry[:30],'backs',vis)
            await pg.mouse.click(vis[0][2]+20,vis[0][3]+15);await pg.wait_for_timeout(600)
            print('  after top Back:',await E("()=>[!!document.querySelector('.ptstart'),ov.className,(document.querySelector('h2')||{}).textContent]"))
            await E("()=>{P.petSt=1;P.pets={bramble:{b:0}};ptStarter()}");await pg.wait_for_timeout(300)
            await pg.keyboard.press('Escape');await pg.wait_for_timeout(500)
            print('  after Esc:',await E("()=>[!!document.querySelector('.ptstart'),ov.className]"))
        print(er[:6]);await b.close()
asyncio.run(main())
