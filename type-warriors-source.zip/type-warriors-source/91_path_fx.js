/* ===== HERO PATH FINISHERS: one signature attack animation per path =====
   Knight "Final Verdict" (a leaping slam with a golden crescent and a shockwave), Archer "Verdant Volley" (a fan of
   glowing arrows), Mage "Arcane Beam" (rune circles charge a beam), Rogue "Shadow Flurry" (a blur of violet strikes).
   They play only at the big moments, so they never crowd ordinary typing:
   - Fury (Enter): the path's attack sweeps every enemy the Fury Strike hits.
   - A boss's finishing blow (Space on a beaten boss): the bigger version, in the existing slow motion, with the
     finisher's name. Finishing the boss within 2 s of it being beaten adds a small "Swift finish" gold bonus.
   Drawing: the hero is moved for the leap/blink by wrapping drawHeroGame; the effects draw on top of the world by
   wrapping drawFxList. Reduced motion: no screen shake, no leap/blink, softer effects. Only S.* run state is used. */
const PFXN={knight:'Final Verdict',archer:'Verdant Volley',mage:'Arcane Beam',rogue:'Shadow Flurry'};
const PFXC={knight:'#ffd45a',archer:'#7aff8a',mage:'#6ad8ff',rogue:'#c47aff'};
const pfxRM=()=>{try{return ccReduce()}catch(e){return false}};
function pfxStart(kind,tg){if(!tg.length)return;const path=PATHS[P.path]?P.path:'knight',big=kind==='boss';
 tg=tg.slice().sort((a,b)=>a.x-b.x).slice(0,8);S.pfx={path,big,t0:S.t,D:big?{knight:1.15,archer:1.05,mage:1.2,rogue:1.05}[path]:{knight:.9,archer:.85,mage:.95,rogue:.85}[path],tg,hit:{},pt:[],rm:pfxRM()}}
/* ---------- triggers ---------- */
{const k0=kill;kill=function(e,force){const was=!!(e&&e.boss&&S.en.includes(e)),r=k0.apply(this,arguments);
  try{if(was&&force&&S.mode==='play'&&!S.en.includes(e)&&S.pose==='victory'){pfxStart('boss',[{x:e.x,y:e.y,h:e.h||200}]);const pp=S.pfx.path;float(W/2,345,PFXN[pp]+'!',PFXC[pp],58);
   if(e.vt0!=null&&S.t-e.vt0<2){const g=Math.round(40+(e.tier||0)*20);try{gain(g)}catch(x){}float(W/2,400,`Swift finish  +${g} gold`,'#ffe27a',34)}}}catch(x){}
  return r}}
{const f0=fury;fury=function(){const ok=S.mode==='play'&&!S.cine&&S.fury>=100,tg=ok?S.en.filter(e=>!e.boss&&e.x<W+40).map(e=>({x:e.x,y:e.y,h:e.h||120})):[];const r=f0.apply(this,arguments);
  try{if(ok&&tg.length&&S.fury<100)pfxStart('fury',tg)}catch(x){}return r}}
/* remember when a boss became beatable, for the swift-finish bonus */
{const u0=update;if(typeof update==='function'){update=function(){const r=u0.apply(this,arguments);try{if(S.mode==='play')for(const e of S.en)if(e.boss){if(e.vul>0&&e.vt0==null)e.vt0=S.t;else if(!(e.vul>0))e.vt0=null}}catch(x){}return r}}}
/* ---------- helpers ---------- */
const pfxE=(u,a,b)=>{const k=Math.max(0,Math.min(1,(u-a)/(b-a)));return k};
const pfxS=k=>k*k*(3-2*k);
function pfxHero(){return{x:KX+(S.lunge||0)*90,y:GY}}
function pfxTgt(q){return{x:q.x,y:(q.y||GY)-(q.h||150)*.5}}
function pfxAdd(F,o){if(F.pt.length<260)F.pt.push(o)}
function pfxGlow(c,x,y,r,col,a){if(r<=0||a<=0)return;c.save();c.globalCompositeOperation='lighter';const q=c.createRadialGradient(x,y,0,x,y,r);q.addColorStop(0,col+Math.round(Math.min(1,a)*255).toString(16).padStart(2,'0'));q.addColorStop(1,col+'00');c.fillStyle=q;c.fillRect(x-r,y-r,r*2,r*2);c.restore()}
function pfxSpark(c,x,y,r,col,a){c.save();c.globalAlpha=a;c.fillStyle=col;c.beginPath();c.moveTo(x,y-r);c.quadraticCurveTo(x+r*.16,y-r*.16,x+r,y);c.quadraticCurveTo(x+r*.16,y+r*.16,x,y+r);c.quadraticCurveTo(x-r*.16,y+r*.16,x-r,y);c.quadraticCurveTo(x-r*.16,y-r*.16,x,y-r);c.fill();c.restore()}
/* where the hero is drawn during the attack (leap / blink), as an offset from his normal spot */
function pfxOffset(F,u){const h0=pfxHero();if(F.rm)return{dx:0,dy:0,a:1};
 if(F.path==='knight'){const T=F.tg.reduce((a,q)=>a+q.x,0)/F.tg.length,dist=Math.max(0,Math.min(F.big?720:560,T-h0.x-130));
  if(u<.18){const k=u/.18;return{dx:-10*k,dy:8*k,a:1}}/* crouch */
  if(u<.42){const k=(u-.18)/.24;return{dx:dist*pfxS(k),dy:8-Math.sin(k*Math.PI*.92)*(F.big?240:190)-(k>.85?0:0),a:1}}
  if(u<.62)return{dx:dist,dy:0,a:1};const k=pfxS((u-.62)/.38);return{dx:dist*(1-k),dy:-Math.sin(k*Math.PI)*40,a:1}}
 if(F.path==='rogue'){const n=F.tg.length,seg=.62/n;if(u<.06){return{dx:0,dy:0,a:1-u/.06*.6}}
  if(u<.68){const i=Math.min(n-1,Math.floor((u-.06)/seg)),T=F.tg[i];return{dx:Math.max(0,T.x-h0.x-110),dy:0,a:.95}}
  if(u<.78)return{dx:0,dy:0,a:.4+(u-.68)*6};return{dx:0,dy:0,a:1}}
 return{dx:0,dy:0,a:1}}
/* ---------- hero wrapper ---------- */
{const d0=drawHeroGame;drawHeroGame=function(){const F=S.pfx;if(!F||S.mode!=='play'&&S.mode!=='over')return d0.apply(this,arguments);const u=(S.t-F.t0)/F.D;if(u>=1){S.pfx=null;return d0.apply(this,arguments)}
  const o=pfxOffset(F,u);if(F.path==='knight'&&u>.12&&u<.5)S.lunge=Math.max(S.lunge,u<.36?.15:1);if(F.path==='rogue'&&u>.06&&u<.68)S.lunge=Math.max(S.lunge,.7+.3*Math.sin(u*60));if(F.path==='archer'&&u<.5)S.lunge=Math.max(S.lunge,.25);if(F.path==='mage'&&u>.2&&u<.75)S.lunge=Math.max(S.lunge,.5);
  /* rogue afterimages: violet streaks where the hero blinked from */
  if(F.path==='rogue'&&!F.rm&&o.dx>20){const c=ctx,h=pfxHero(),x1=h.x+o.dx;c.save();c.globalCompositeOperation='lighter';for(let k=0;k<7;k++){const y=GY-40-k*32-(k%2)*9,x0=x1-160-((k*53)%90),q=c.createLinearGradient(x0,0,x1,0);q.addColorStop(0,'rgba(160,90,255,0)');q.addColorStop(1,'rgba(214,170,255,.55)');c.strokeStyle=q;c.lineWidth=k%3?3:6;c.beginPath();c.moveTo(x0,y);c.lineTo(x1-10,y);c.stroke()}c.restore()}
  const c=ctx;c.save();c.translate(o.dx,o.dy);if(o.a<1)c.globalAlpha=o.a;const r=d0.apply(this,arguments);c.restore();return r}}
/* ---------- effects layer ---------- */
{const x0=drawFxList;drawFxList=function(c){const r=x0.apply(this,arguments);try{pfxDraw(c)}catch(e){}return r}}
function pfxDraw(c){const F=S.pfx;if(!F||S.mode!=='play'&&S.mode!=='over')return;const u=(S.t-F.t0)/F.D;if(u<0||u>=1)return;const now=S.t,dt=Math.min(.05,now-(F.lt||now));F.lt=now;
 c.save();c.lineCap='round';c.lineJoin='round';
 ({knight:pfxKnight,archer:pfxArcher,mage:pfxMage,rogue:pfxRogue}[F.path]||pfxKnight)(c,F,u,now);
 /* shared particles */
 for(let i=F.pt.length-1;i>=0;i--){const p=F.pt[i];p.l+=dt;if(p.l>=p.m){F.pt.splice(i,1);continue}const k=p.l/p.m;p.vy+=(p.g||0)*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;
  if(p.k==='rock'){c.save();c.translate(p.x,p.y);c.rotate(p.l*p.sp);c.globalAlpha=1-k*k;c.fillStyle=p.c;c.beginPath();c.moveTo(-p.r,-p.r*.6);c.lineTo(p.r*.8,-p.r);c.lineTo(p.r,p.r*.5);c.lineTo(-p.r*.4,p.r);c.closePath();c.fill();c.strokeStyle='#1a1026';c.lineWidth=2;c.stroke();c.restore()}
  else if(p.k==='leaf'){c.save();c.translate(p.x,p.y);c.rotate(p.l*p.sp);c.globalAlpha=1-k;c.fillStyle=p.c;c.beginPath();c.ellipse(0,0,p.r,p.r*.45,0,0,TAU);c.fill();c.restore()}
  else if(p.k==='dust'){c.globalAlpha=(1-k)*.5;c.fillStyle=p.c;c.beginPath();c.arc(p.x,p.y,p.r*(1+k*1.5),0,TAU);c.fill()}
  else pfxSpark(c,p.x,p.y,p.r*(1-k*.5),p.c,1-k)}
 c.globalAlpha=1;c.restore()}
/* KNIGHT: crouch, leap high with the blade raised, slam down in a golden crescent; shockwave, rocks and dust */
function pfxKnight(c,F,u,now){const h0=pfxHero(),o=pfxOffset(F,u),hx=h0.x+o.dx,hy=GY+o.dy,col='#ffd45a',big=F.big;
 /* gathering light while airborne */
 if(u>.15&&u<.44){const k=pfxE(u,.15,.3);pfxGlow(c,hx+40,hy-220,90+40*k,col,.35*k);for(let i=0;i<3;i++)pfxAdd(F,{k:'s',x:hx+40+(Math.random()-.5)*80,y:hy-200+(Math.random()-.5)*120,vx:0,vy:-40,l:0,m:.4,r:4,c:'#fff2b0'})}
 /* the crescent slash: a thick golden arc swept from above down to the ground */
 if(u>.3&&u<.62){const k=pfxE(u,.3,.42),fade=1-pfxE(u,.46,.62),cx=hx+70,cy=GY-150,R=big?200:165,a1=-2.5,a2=-2.5+k*3.1;
  c.save();c.globalCompositeOperation='lighter';for(const [w,cc,al] of [[46,'#ff9a20',.35],[30,col,.6],[12,'#fff8d8',.9]]){c.strokeStyle=cc;c.globalAlpha=al*fade;c.lineWidth=w;c.beginPath();c.arc(cx,cy,R,a1,a2);c.stroke()}
  c.restore();if(!F.hit.slam&&u>=.42){F.hit.slam=1;pfxImpact(F,cx+30,GY,big)}}
 /* shockwave rings on the ground */
 if(F.hit.slam){const k=pfxE(u,.42,.95),hx2=hx+100;c.save();c.globalCompositeOperation='lighter';for(let i=0;i<3;i++){const kk=Math.max(0,k-i*.12),r=40+kk*(big?520:420);c.strokeStyle=i?'#ffe6a0':'#ffffff';c.globalAlpha=(1-kk)*.7;c.lineWidth=(8-i*2)*(1-kk*.5);c.beginPath();c.ellipse(hx2,GY+4,r,r*.16,0,0,TAU);c.stroke()}
  pfxGlow(c,hx2,GY-30,(big?260:200)*(1-k*.5),col,.45*(1-k));c.restore()}}
function pfxImpact(F,x,y,big){if(!F.rm){S.shake=Math.max(S.shake||0,big?24:16);S.flash=Math.max(S.flash||0,big?.45:.25)}try{beep(70,.35,'sawtooth',.9);beep(140,.2,'square',.5)}catch(e){}
 for(let i=0;i<(big?22:14);i++){const a=-Math.PI*(.1+Math.random()*.8);pfxAdd(F,{k:'rock',x:x+(Math.random()-.5)*60,y:y-6,vx:Math.cos(a)*(160+Math.random()*260),vy:Math.sin(a)*(260+Math.random()*320),g:1100,l:0,m:.9+Math.random()*.4,r:5+Math.random()*7,sp:(Math.random()-.5)*14,c:['#6a5a7a','#8a7a9a','#4a3e5a'][i%3]})}
 for(let i=0;i<14;i++)pfxAdd(F,{k:'dust',x:x+(Math.random()-.5)*180,y:y-10,vx:(Math.random()-.5)*220,vy:-30-Math.random()*60,g:0,l:0,m:.9,r:16+Math.random()*16,c:'#b8a8c8'});
 for(let i=0;i<(big?26:16);i++){const a=Math.random()*TAU;pfxAdd(F,{k:'s',x,y:y-60,vx:Math.cos(a)*320,vy:Math.sin(a)*240-80,g:300,l:0,m:.7,r:6,c:i%2?'#fff2b0':'#ffd45a'})}}
/* ARCHER: draw, then a fan of emerald arrows arcs into the targets with leafy trails and green bursts */
function pfxArcher(c,F,u,now){const h0=pfxHero(),bx=h0.x+64,by=GY-150,col='#7aff8a',n=F.big?9:Math.min(12,F.tg.length*2+3);
 if(u<.25){const k=pfxE(u,0,.2);pfxGlow(c,bx,by,40+30*k,col,.45*k);c.save();c.globalCompositeOperation='lighter';c.strokeStyle=col;c.globalAlpha=.6*k;c.lineWidth=3;c.beginPath();c.arc(bx,by,26+14*k,0,TAU*k);c.stroke();c.restore()}
 for(let i=0;i<n;i++){const t0=.1+i*(.4/n),fl=.32,k=(u-t0)/fl;const T=pfxTgt(F.tg[i%F.tg.length]),sx=bx,sy=by,ex=T.x+(i%3-1)*14,ey=T.y+((i*7)%5-2)*12,arc=140+((i*37)%5)*30;
  const P=q=>({x:sx+(ex-sx)*q,y:sy+(ey-sy)*q-Math.sin(q*Math.PI)*arc});
  if(k>0&&k<1){const p=P(k),p2=P(Math.max(0,k-.08)),ang=Math.atan2(p.y-p2.y,p.x-p2.x);
   c.save();c.globalCompositeOperation='lighter';const tr=c.createLinearGradient(p2.x,p2.y,p.x,p.y);tr.addColorStop(0,'#7aff8a00');tr.addColorStop(1,'#7aff8acc');c.strokeStyle=tr;c.lineWidth=7;c.beginPath();for(let q=Math.max(0,k-.16);q<=k;q+=.02){const pp=P(q);q===Math.max(0,k-.16)?c.moveTo(pp.x,pp.y):c.lineTo(pp.x,pp.y)}c.stroke();c.restore();
   c.save();c.translate(p.x,p.y);c.rotate(ang);pfxGlow(c,0,0,22,col,.5);c.strokeStyle='#1a1026';c.lineWidth=5;c.beginPath();c.moveTo(-30,0);c.lineTo(8,0);c.stroke();c.strokeStyle='#d8ffd0';c.lineWidth=2.6;c.beginPath();c.moveTo(-30,0);c.lineTo(8,0);c.stroke();
   c.fillStyle='#eaffe0';c.beginPath();c.moveTo(18,0);c.lineTo(6,-6);c.lineTo(8,0);c.lineTo(6,6);c.closePath();c.fill();c.strokeStyle='#1a1026';c.lineWidth=1.6;c.stroke();c.fillStyle='#4adf6a';c.beginPath();c.moveTo(-30,0);c.lineTo(-38,-7);c.lineTo(-26,0);c.lineTo(-38,7);c.closePath();c.fill();c.restore();
   if(Math.random()<.35)pfxAdd(F,{k:'leaf',x:p.x,y:p.y,vx:(Math.random()-.5)*60,vy:20+Math.random()*40,g:60,l:0,m:.7,r:5,sp:6,c:Math.random()<.5?'#5ad86a':'#a8ff7a'})}
  if(k>=1&&!F.hit[i]){F.hit[i]=1;for(let j=0;j<8;j++){const a=Math.random()*TAU;pfxAdd(F,{k:'s',x:ex,y:ey,vx:Math.cos(a)*200,vy:Math.sin(a)*200,g:200,l:0,m:.45,r:5,c:j%2?'#eaffe0':col})}try{beep(900+i*60,.04,'triangle',.25)}catch(e){}}
  if(k>=1&&k<1.6){const kk=(k-1)/.6;c.save();c.globalCompositeOperation='lighter';c.strokeStyle=col;c.globalAlpha=1-kk;c.lineWidth=3;c.beginPath();c.arc(ex,ey,8+kk*30,0,TAU);c.stroke();c.restore()}}
 if(F.big&&u>.55&&!F.hit.fin){F.hit.fin=1;const T=pfxTgt(F.tg[0]);if(!F.rm)S.shake=Math.max(S.shake||0,12);for(let j=0;j<18;j++)pfxAdd(F,{k:'leaf',x:T.x,y:T.y,vx:(Math.random()-.5)*400,vy:-Math.random()*300,g:300,l:0,m:1,r:7,sp:8,c:j%2?'#5ad86a':'#d8ff9a'})}}
/* MAGE: two rune circles spin up at the staff, then a crackling arcane beam sweeps the targets */
function pfxMage(c,F,u,now){const h0=pfxHero(),sx=h0.x+92,sy=GY-196,col='#6ad8ff';
 const ring=(x,y,r,rot,a,dash)=>{c.save();c.translate(x,y);c.rotate(rot);c.globalCompositeOperation='lighter';c.strokeStyle=col;c.globalAlpha=a;c.lineWidth=3;c.beginPath();c.ellipse(0,0,r*.36,r,0,0,TAU);c.stroke();c.setLineDash(dash);c.lineWidth=2;c.beginPath();c.ellipse(0,0,r*.27,r*.75,0,0,TAU);c.stroke();c.setLineDash([]);
  for(let i=0;i<6;i++){const a2=i*TAU/6+now*2;c.fillStyle='#d8f6ff';c.globalAlpha=a*.9;c.fillRect(Math.cos(a2)*r*.31-2,Math.sin(a2)*r*.87-2,4,4)}c.restore()};
 const ch=pfxE(u,0,.22),off=1-pfxE(u,.78,1);
 if(u<1){ring(sx+10,sy,40+30*ch,0,.8*ch*off,[6,6]);ring(sx+40,sy,26+20*ch,0,.7*ch*off,[3,5]);pfxGlow(c,sx,sy,50+40*ch,col,.5*ch*off)}
 if(u<.25)for(let i=0;i<3;i++){const a=Math.random()*TAU,r=90;pfxAdd(F,{k:'s',x:sx+Math.cos(a)*r,y:sy+Math.sin(a)*r,vx:-Math.cos(a)*r*3.5,vy:-Math.sin(a)*r*3.5,g:0,l:0,m:.28,r:4,c:'#d8f6ff'})}
 if(u>=.22&&u<.85){const k=pfxE(u,.22,.3),fade=1-pfxE(u,.72,.85),n=F.tg.length,q=Math.min(n-1,(u-.22)/.5*n),i0=Math.floor(q),fr=q-i0,A=pfxTgt(F.tg[i0]),B=pfxTgt(F.tg[Math.min(n-1,i0+1)]),ex=A.x+(B.x-A.x)*fr,ey=A.y+(B.y-A.y)*fr,len=Math.hypot(ex-sx,ey-sy),ang=Math.atan2(ey-sy,ex-sx),w=(F.big?34:24)*k*fade;
  if(!F.hit.go){F.hit.go=1;try{beep(220,.5,'sawtooth',.5);beep(440,.4,'square',.25)}catch(e){}if(!F.rm)S.shake=Math.max(S.shake||0,F.big?14:8)}
  c.save();c.translate(sx,sy);c.rotate(ang);c.globalCompositeOperation='lighter';
  const seg=24;for(const [ww,cc,al] of [[w*2.2,'#2a7aff',.35],[w,col,.75],[w*.4,'#ffffff',1]]){c.strokeStyle=cc;c.globalAlpha=al;c.lineWidth=ww;c.beginPath();for(let s=0;s<=seg;s++){const x=len*s/seg,y=Math.sin(s*1.3+now*30)*w*.12*(s%2?1:-1);s?c.lineTo(x,y):c.moveTo(x,y)}c.stroke()}
  for(let r2=0;r2<4;r2++){const p=((now*2.2+r2/4)%1),x=len*p;c.strokeStyle='#d8f6ff';c.globalAlpha=(1-p)*.8*fade;c.lineWidth=2.4;c.beginPath();c.ellipse(x,0,6+p*8,w*.9+p*14,0,0,TAU);c.stroke()}
  c.restore();pfxGlow(c,ex,ey,(F.big?130:90)*k*fade,col,.6);pfxGlow(c,ex,ey,40*k*fade,'#ffffff',.8);
  if(Math.random()<.8)for(let j=0;j<2;j++){const a=Math.random()*TAU;pfxAdd(F,{k:'s',x:ex,y:ey,vx:Math.cos(a)*240,vy:Math.sin(a)*240,g:0,l:0,m:.35,r:4,c:j?'#ffffff':col})}}}
/* ROGUE: blink to each target and carve it with crossing violet slashes, sparks flying, then blink home */
function pfxRogue(c,F,u,now){const n=F.tg.length,seg=.62/n,col='#c47aff',per=F.big?6:3;
 for(let i=0;i<n;i++){const T=pfxTgt(F.tg[i]),s0=.06+i*seg;for(let j=0;j<per;j++){const t0=s0+j*(seg/per),k=(u-t0)/.16;if(k<0||k>1)continue;const ang=[-.7,.8,-.2,1.3,-1.2,.3][j%6],L=(F.big?240:170),a=1-k,p=Math.min(1,k*2.4);
   c.save();c.translate(T.x+(j%2?8:-8),T.y+(j%3-1)*14);c.rotate(ang);c.globalCompositeOperation='lighter';
   for(const [w,cc,al] of [[30,'#7a2aff',.4],[14,col,.85],[5,'#ffffff',1]]){c.strokeStyle=cc;c.globalAlpha=al*a;c.lineWidth=w*(1-k*.5);c.beginPath();c.moveTo(-L/2,0);c.quadraticCurveTo(0,-L*.16,-L/2+L*p,0);c.stroke()}c.restore();pfxGlow(c,T.x,T.y,60*a,col,.35);
   if(!F.hit[i+'_'+j]){F.hit[i+'_'+j]=1;try{beep(1300-j*90,.03,'square',.18)}catch(e){}for(let q=0;q<5;q++){const aa=Math.random()*TAU;pfxAdd(F,{k:'s',x:T.x,y:T.y,vx:Math.cos(aa)*260,vy:Math.sin(aa)*260,g:240,l:0,m:.35,r:4,c:q%2?'#ffffff':col})}}}}
 if(F.big&&u>.66&&!F.hit.fin){F.hit.fin=1;const T=pfxTgt(F.tg[0]);if(!F.rm)S.shake=Math.max(S.shake||0,16);for(let q=0;q<24;q++){const aa=Math.random()*TAU;pfxAdd(F,{k:'s',x:T.x,y:T.y,vx:Math.cos(aa)*420,vy:Math.sin(aa)*420,g:200,l:0,m:.6,r:6,c:q%2?'#ffffff':col})}}
 if(F.big&&u>.66&&u<.9){const T=pfxTgt(F.tg[0]),k=pfxE(u,.66,.9);c.save();c.globalCompositeOperation='lighter';c.strokeStyle='#ffffff';c.globalAlpha=1-k;c.lineWidth=6;for(const a of [.7,-.7]){c.save();c.translate(T.x,T.y);c.rotate(a);c.beginPath();c.moveTo(-180*(.4+k),0);c.lineTo(180*(.4+k),0);c.stroke();c.restore()}c.restore()}}
/* a new run never inherits an attack from the last one */
{const s0=start;start=function(){S.pfx=null;return s0.apply(this,arguments)}}
