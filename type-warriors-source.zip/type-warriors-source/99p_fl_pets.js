/* ===== 10.4 HARVEST FESTIVAL: the harvest companions, data, save and powers (99p, after 99m; prefix flp) =====
   Three companions join the existing companion system (87a-87j), one per pet rarity, all of the new Harvest family:
   - Acorn Scamp (flsquir, Rare): Acorn Toss. Every 20 correct words, Shift bonks the nearest monster with an acorn: it is knocked back
     and dazed (40% slower) for 3 seconds. Bosses are immune.
   - Emberleaf (flfox, Legendary): Maplefire Gale. Every 30 correct words, Shift sends a gale of burning maple leaves across the field:
     projectiles burn away and every monster is slowed by 40% for 4 seconds; a boss loses the attack it is winding up and waits 2 s.
   - Thunderplume, the Harvest Turkey (flturkey, Mythic): Grand Feast (99p3).
   They are never in the Runeshell / Crownheart / Starforge pools: PDEF entries carry fl:1 and petList(r) in 87a skips them (one-line
   edit there, backup 87a_pet_data.js.v8bak), so egg pools, egg caps, "N left to find" and the starter are unchanged.
   How to get them: Acorn Scamp and Emberleaf from Harvest Chests and the Harvest Market (flpGive, called by the other festival parts);
   Thunderplume from the Golden Harvest Egg (P.eggs.h): bought in the Hatchery (Companion Hall > Eggs) for FLPC.price coins while the
   festival market is open, sold for acorns in the Harvest Market, and given on Thanksgiving by the Harvest Calendar (flpEggAdd).
   A Golden Harvest Egg opened while Thunderplume is already owned pays FLPC.refund coins and FLPC.bond bond XP instead.
   Public API (each part calls these only if they exist):
     flpGive(id,opt)  grant flsquir / flfox / flturkey with the harvest reveal. opt.silent: no cinematic (a toast and the NEW badge);
                      opt.back: function to run when the reveal closes (default: the Companion Hall with the pet selected).
                      Returns {id} when granted, {dup:1,id} if already owned (nothing changes), null for an unknown id.
     flpEgg(opt)      open one Golden Harvest Egg: hatches Thunderplume ({id:'flturkey'}) or refunds ({refund:coins}); null if none held.
     flpEggAdd(n,o)   add n Golden Harvest Eggs (o.quiet: no toast); returns the new count.
     flpEggCan()      true when a Golden Harvest Egg may be sold to this player (Thunderplume not owned, no egg already in hand).
     flpEggN()        Golden Harvest Eggs held.  flpHas(id) owned?  flpEggOpen() opens the Eggs tab on the Golden Harvest Egg.
   Saved: P.eggs.h (Golden Harvest Eggs, 0..FLPC.maxEgg), P.flp {n: eggs hatched, rf: refunds, buy: bought with coins}; both repaired
   on every load. The companions themselves live in P.pets like every other companion. */
Object.assign(PDEF,{
 flsquir:{n:FL.petN.flsquir,r:'r',fam:'Harvest',fl:1,box:[-62,-118,124,120],ab:{k:'acorntoss',n:'Acorn Toss',N:20,d:'Every 20 correct words, bonk the nearest monster with an acorn: it is knocked back and dazed (30% slower) for 3 seconds.',x:'Bosses are immune. Waits for a target.'},
  bio:'A red squirrel in an acorn-cap helmet. It never goes anywhere without a satchel of acorns, and it never misses a throw.',cos:{acc:'Maple scarf',pal:'Silver Birch',cel:'Acorn shower',sig:'Golden Oak'},greet:'chitters and waves its acorn'},
 flfox:{n:FL.petN.flfox,r:'l',fam:'Harvest',fl:1,box:[-92,-118,150,120],ab:{k:'maplegale',n:'Maplefire Gale',N:30,d:'Every 30 correct words, a gale of burning maple leaves sweeps the field: projectiles burn away and every monster is slowed by 40% for 4 seconds.',x:'A boss is not slowed: the attack it is winding up is blown away and its next one waits 2 seconds.'},
  bio:'A fox whose tail is a plume of glowing maple leaves. Wherever it naps, the grass turns gold.',cos:{acc:'Acorn charm',pal:'Moonmaple',cel:'Leaf whirl',sig:'Wildfire Crown'},greet:'fans its blazing tail'}
});
for(const id of['flsquir','flfox'])if(!PIDS.includes(id))PIDS.push(id);
Object.assign(PFAM,{Harvest:'#ffa53a'});
const FLPC={ids:['flsquir','flfox','flturkey'],price:60000,refund:30000,bond:100,maxEgg:20,egg:'Golden Harvest'};
const flpIs=id=>!!(PDEF[id]&&PDEF[id].fl);
const flpHas=id=>petOwned(id);
const flpEggN=()=>(P&&P.eggs&&P.eggs.h)|0;
const flpEggCan=()=>!petOwned('flturkey')&&flpEggN()<1;
/* the egg card shows while it can be bought, or while one is held */
const flpEggShown=()=>flpEggN()>0||(typeof flShopOn==='function'&&flShopOn()&&!petOwned('flturkey'));
const flpBuyOpen=()=>typeof flShopOn==='function'&&flShopOn();

/* ---------- save: repaired on every load ---------- */
function flpNorm(){if(!P||typeof P!=='object')return;if(!P.eggs||typeof P.eggs!=='object'||Array.isArray(P.eggs))P.eggs={r:0,l:0,m:0};
 const h=Math.floor(+P.eggs.h||0);P.eggs.h=Number.isFinite(h)?Math.max(0,Math.min(FLPC.maxEgg,h)):0;
 if(!P.flp||typeof P.flp!=='object'||Array.isArray(P.flp))P.flp={};const F=P.flp;for(const k of['n','rf','buy'])F[k]=Math.max(0,Math.min(1e6,Math.floor(+F[k]||0)));
 /* a pending reveal of a harvest companion that is not owned any more is dropped */
 if(P.petPend&&P.petPend.id&&flpIs(P.petPend.id)&&!(P.pets&&P.pets[P.petPend.id]))P.petPend=null}
{const l0=load;load=function(){const r=l0.apply(this,arguments);try{flpNorm()}catch(e){}return r}}
try{flpNorm()}catch(e){}

/* ---------- granting ---------- */
function flpGive(id,opt){opt=opt||{};if(!flpIs(id))return null;try{petNorm();flpNorm()}catch(e){}if(petOwned(id))return{dup:1,id};
 P.pets[id]={b:0,nk:'',pal:0,acc:0,trim:0,cel:0,t:Date.now()};P.petNew[id]=1;if(!P.pet)P.pet=id;
 if(!opt.silent)P.petPend={id,k:PDEF[id].r};save();
 if(opt.silent){try{ccToast(`${PDEF[id].n} joined your Companion Hall!`)}catch(e){}}
 else try{ptHatchScene(id,PDEF[id].r,{back:opt.back,src:opt.src})}catch(e){console.error(e)}
 return{id}}
function flpEggAdd(n,o){o=o||{};flpNorm();n=Math.max(0,Math.min(FLPC.maxEgg,Math.floor(+n||0)));if(!n)return flpEggN();P.eggs.h=Math.min(FLPC.maxEgg,flpEggN()+n);save();
 if(!o.quiet)try{ccToast(`+${n} ${FLPC.egg} Egg${n>1?'s':''}! Hatch ${n>1?'them':'it'} in Pets › Eggs.`)}catch(e){}return P.eggs.h}
/* the result is committed and saved before any animation plays (like petHatch) */
function flpEgg(opt){opt=opt||{};flpNorm();if(flpEggN()<=0)return null;
 if(petOwned('flturkey')){P.eggs.h--;const g=FLPC.refund;const pay=()=>{P.gold+=g};typeof ukSrc==='function'?ukSrc('flegg',pay):pay();petBondAdd('flturkey',FLPC.bond);P.flp.rf++;save();
  try{if(typeof flpRefundFx==='function')flpRefundFx(g);else ccToast(`Thunderplume is already yours: +${g.toLocaleString()} coins and +${FLPC.bond} bond.`)}catch(e){}return{refund:g}}
 P.eggs.h--;P.pets.flturkey={b:0,nk:'',pal:0,acc:0,trim:0,cel:0,t:Date.now()};P.petNew.flturkey=1;if(!P.pet)P.pet='flturkey';P.petPend={id:'flturkey',k:'h'};P.flp.n++;save();
 try{ptHatchScene('flturkey','h',{back:opt.back})}catch(e){console.error(e)}return{id:'flturkey'}}
function flpEggBuy(){flpNorm();if(!flpBuyOpen()||!flpEggCan()||P.gold<FLPC.price)return false;const pay=()=>{P.gold-=FLPC.price};typeof ukSrc==='function'?ukSrc('egg',pay):pay();P.eggs.h=flpEggN()+1;P.flp.buy++;save();return true}
function flpEggOpen(){PTX.back=PTX.back||title;PTX.egg='h';petHall('Eggs')}

/* ---------- Companion Hall: roster tags, lock text, the Eggs tab badge ---------- */
const FLP_LEAF='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 1.5l1.6 3.6 2.4-1-.3 3.5 3.5-1.6-1 3 3.3.7-2.6 2.4 1.4 1.8-4.3.2.5 2.3-4.5-1.7V22h-1.2v-6.3l-4.5 1.7.5-2.3-4.3-.2 1.4-1.8L1.4 10.7l3.3-.7-1-3 3.5 1.6-.3-3.5 2.4 1z" fill="currentColor" stroke="#12081f" stroke-width="1.1" stroke-linejoin="round"/></svg>';
{const h0=ptPetsHTML;ptPetsHTML=function(){let h=h0.apply(this,arguments);try{h=h.replace(/<button class="ptc ([^"]*)" data-p="(flsquir|flfox|flturkey)"([^>]*)>/g,(m,c,id,rest)=>`<button class="ptc ${c} ptc-fl" data-p="${id}"${rest}><i class="flptg" title="Harvest Festival companion">${FLP_LEAF}</i>`)}catch(e){}return h}}
{const d0=ptDetHTML;ptDetHTML=function(id){let h=d0.apply(this,arguments);try{if(!flpIs(id)||petOwned(id))return h;const D=PDEF[id],shop=flpBuyOpen();let txt,btn='';
  if(id==='flturkey'){txt=`<b>A Mythic harvest companion.</b> Hatch a <em>${FLPC.egg} Egg</em> to meet it. ${shop?`Buy one in the Hatchery for <b>${FLPC.price.toLocaleString()} coins</b> or with acorns in the Harvest Market while the festival lasts.`:'The eggs came with the Harvest Festival.'}`;if(shop||flpEggN())btn=`<button class="ptgo b flpto" id="flpto" data-go="egg">${PTICO.egg} See the ${FLPC.egg} Egg</button>`}
  else{txt=`<b>A Harvest Festival companion.</b> Find it in a <em>Harvest Chest</em>${shop?' or buy it in the <em>Harvest Market</em> with acorns while the festival lasts':''}.`;if(shop&&typeof fleHub==='function')btn=`<button class="ptgo b flpto" id="flpto" data-go="market">${FLP_LEAF} Open the Harvest Market</button>`}
  h=h.replace(/<p class="ptlk[^"]*">[\s\S]*?<\/p>/,`<p class="ptlk ptlk-fl">${txt}</p>`).replace(/<div class="ptbt"><button class="ptgo b" id="ptto">[\s\S]*?<\/button><\/div>/,btn?`<div class="ptbt">${btn}</div>`:'')}catch(e){}return h}}
{const b0=ptPetsBind;ptPetsBind=function(){const r=b0.apply(this,arguments);try{const d=$('ptdet');if(d&&!d._flp){d._flp=1;d.addEventListener('click',e=>{const b=e.target.closest('#flpto');if(!b)return;e.stopPropagation();ptBeep(560);
  if(b.dataset.go==='egg')flpEggOpen();else if(typeof fleHub==='function')fleHub()})}}catch(e){}return r}}
/* the Eggs tab badge counts Golden Harvest Eggs too */
{const h0=petHall;petHall=function(){const r=h0.apply(this,arguments);try{const n=flpEggN();if(n){const tb=ov.querySelector('.pttab[data-pt="Eggs"] span');if(tb){const tot=petEggsN()+n;tb.innerHTML=`Eggs <i class="ptn">${tot}</i>`}}}catch(e){}return r}}

/* ---------- Eggs tab: a fourth egg, the Golden Harvest Egg ---------- */
const flpEggCard=k=>{const on=PTX.egg===k;if(k!=='h'){const E=PRAR[k],L=petList(k),o=L.filter(petOwned).length,m=P.eggs[k]|0;
  return `<button class="phx-c${on?' on':''} phx-${k}" data-egg="${k}" role="radio" aria-checked="${on}" aria-label="${E.egg} egg, ${m} owned, ${o} of ${L.length} discovered"><canvas width="96" height="110" data-et="${k}"></canvas><div class="phx-ci"><b>${E.egg}</b>${ptBadge(k,1)}<span class="phx-pg"><span class="ptbar phx-b${k}"><i style="width:${o/L.length*100}%"></i></span><small>${o}/${L.length}</small></span></div><em class="phx-cnt${m?'':' z'}">×${m}</em>${k==='m'&&!m?'<i class="phx-cnew">Coins only</i>':''}</button>`}
 const m=flpEggN(),o=petOwned('flturkey')?1:0;
 return `<button class="phx-c${on?' on':''} phx-h" data-egg="h" role="radio" aria-checked="${on}" aria-label="${FLPC.egg} egg, ${m} owned, ${o} of 1 discovered"><canvas width="96" height="110" data-et="h"></canvas><div class="phx-ci"><b>Harvest</b><span class="ptbg ptbg-h sm">FESTIVAL</span><span class="phx-pg"><span class="ptbar phx-bh"><i style="width:${o*100}%"></i></span><small>${o}/1</small></span></div><em class="phx-cnt${m?'':' z'}">×${m}</em>${!m&&flpBuyOpen()?'<i class="phx-cnew flp-new">Limited</i>':''}</button>`};
function flpEggsHTML(){const n=flpEggN(),own=petOwned('flturkey'),shop=flpBuyOpen(),pr=FLPC.price,need=pr-P.gold,can=flpEggCan();
 const act=n?`<button class="ptgo phx-hatch flp-hatch" id="phxht">${PTICO.egg} ${own?'Open for a refund':'Hatch '+FLPC.egg}</button>${own?`<p class="phx-why">Thunderplume is already yours: each egg pays <b>${FLPC.refund.toLocaleString()} coins</b> and <b>${FLPC.bond} bond</b>.</p>`:''}`
  :`<button class="ptgo off phx-hatch" disabled>${PTICO.egg} No eggs to hatch</button><p class="phx-why">${own?'Thunderplume is already in your hall.':shop?`Buy one below for ${pr.toLocaleString()} coins, or with acorns in the Harvest Market.`:'Golden Harvest Eggs came with the Harvest Festival.'}</p>`;
 const lab=!shop?'Festival over':own?'Already hatched':!can?'One egg at a time':need>0?`Need ${need.toLocaleString()} more gold`:'Buy';
 const dis=!shop||!can||need>0;
 const left=typeof flLeft==='function'?flLeft():'',save=Math.min(1,P.gold/pr);
 const info=`<div class="phx-row phx-save flp-sv${!dis?' ok':''}"><span class="phx-svi flp-svi">${FLP_LEAF}</span><div class="phx-rt"><b>${shop?'Harvest Festival only':'The festival has ended'}</b><small>${shop?`${esc(left)} · also sold for acorns in the Harvest Market`:'Eggs you still hold can be hatched any time.'}</small>${shop&&!own?`<span class="ptbar phx-svb"><i style="width:${save*100}%"></i></span>`:''}</div>${shop&&!own&&typeof fleMarket==='function'?'<button class="ptsoft flp-mk" id="flpmk" title="Buy the egg with acorns at the Harvest Market">Market ›</button>':''}</div>`;
 return `<div class="phx phx2 phx3 phx4 phx-kh"><section class="ptp phx-inv"><div class="ptph"><h3>Your Eggs</h3></div><div class="phx-cards" role="radiogroup" aria-label="Egg type">${['r','l','m','h'].map(flpEggCard).join('')}</div></section>
  <section class="phx-show"><canvas id="phxcv" aria-hidden="true"></canvas><div class="phx-tt"><h3>${FLPC.egg} Egg</h3><span class="ptbg ptbg-m">MYTHIC</span><p class="phx-tag">Laid under the harvest moon, warm as a hearth.</p></div>
   <div class="phx-pool"><p>${own?'<b>Thunderplume</b> is already in your hall':'Hatches <b>Thunderplume, the Harvest Turkey</b> <em>(guaranteed)</em>'}</p><div class="phx-pl"><span class="${own?'own':''}" title="${own?'Thunderplume (owned)':'Undiscovered'}"><canvas width="56" height="48" data-pl="flturkey"></canvas></span></div><button class="ptsoft phx-vc" id="phxvc">View companion ›</button></div></section>
  <section class="ptp phx-act"><div class="ptph"><h3>Hatchery</h3></div><div class="phx-big"><b id="phxn">${n}</b><span>${FLPC.egg} egg${n===1?'':'s'}<small>${own?'ready to open':'ready to hatch'}</small></span></div>
   ${act}
   <div class="phx-or"><i></i><span>more eggs</span><i></i></div>
   <div class="phx-row"><canvas width="64" height="72" id="phxme"></canvas><div class="phx-rt"><b>Buy one</b><small>${PTICO.coin}${pr.toLocaleString()} gold</small></div>
    <button class="ptgo b phx-buy flp-buy${dis?' off':''}" id="phxby" ${dis?'disabled':''}>${lab}</button></div>
   ${info}
   <div class="phx-about phx-ab-h"><div class="phx-abh"><i>${PTICO.egg}</i><b>About ${FLPC.egg} eggs</b></div><p>A festival treasure, wrapped in wicker and painted with autumn leaves. Inside sleeps <b>Thunderplume</b>, the Harvest Turkey, whose gobble is louder than thunder. Its Mythic power, <b>Grand Feast</b>, stuns the whole field and serves up a banquet.</p>
    <div class="phx-facts"><span>${PTICO.star}1 Mythic companion</span><span>${own?`${PTICO.chk}Found`:`${PTICO.paw}Not found yet`}</span><span title="Never in Starforge eggs">${FLP_LEAF}Festival only</span></div></div></section></div>`}
{const h0=ptEggsHTML;ptEggsHTML=function(){try{if(PTX.egg==='h'){if(flpEggShown())return flpEggsHTML();PTX.egg='r'}}catch(e){}let h=h0.apply(this,arguments);
 try{if(flpEggShown()){h=h.replace('<div class="phx phx2 phx3 ','<div class="phx phx2 phx3 phx4 ').replace(/(<div class="phx-cards"[^>]*>[\s\S]*?)(<\/div>\s*<\/section>)/,(m,a,b)=>a+flpEggCard('h')+b)}}catch(e){}return h}}
function flpEggsBind(){const cv=$('phxcv');if(cv&&typeof flpEggStage==='function')LIVE.push({cv,fn:flpEggStage(cv)});
 ov.querySelectorAll('canvas[data-et]').forEach(c=>{const kk=c.dataset.et;try{eggFit(c,kk,{t:1,noSh:1,glow:kk==='h'?.3:0})}catch(e){}if(kk==='h'||(P.eggs[kk]|0)>0)LIVE.push({cv:c,slow:3,fn:t=>{if(ptRM())return;const on=kk==='h',has=(P.eggs[kk]|0)>0,ph=(t+(kk==='l'?1.3:0))%3.4,v=ph/.9,L=has&&ph<.9?Math.sin(v*Math.PI*4)*(1-v)*.09:0;try{eggFit(c,kk,{t,noSh:1,lean:L,glow:(on?.3:.1)+(has?.2+.15*Math.sin(t*2.4):0)})}catch(e){}}})});
 try{eggFit($('phxme'),'h',{t:1,noSh:1,glow:.2})}catch(e){}
 ov.querySelectorAll('canvas[data-pl]').forEach(c=>{const id=c.dataset.pl;try{petFit(c,id,Object.assign({t:1.2,sil:petOwned(id)?0:'#3a2e5a'},petOwned(id)?petLook(id):{}))}catch(e){}});
 ov.querySelectorAll('[data-egg]').forEach(b=>b.onclick=()=>{const k=b.dataset.egg;if(k===PTX.egg)return;ptBeep(600,.04,.25);PTX.eggFrom=PTX.egg;PTX.egg=k;const sc=hlScr().scrollTop;petHall('Eggs');hlScr().scrollTop=sc});
 flpEggKeys();
 const ht=$('phxht');if(ht){ht.classList.add('phx-call');ht.onclick=()=>{if(PTX.busy)return;PTX.busy=1;ht.disabled=true;const r=flpEgg({});PTX.busy=0;if(!r||r.refund)petHall('Eggs')}}
 const by=$('phxby');if(by&&!by.disabled){let armed=0,tm=0;const lab=by.innerHTML;by.onclick=()=>{if(PTX.busy)return;if(!armed){armed=1;by.classList.add('arm');by.innerHTML=`Confirm purchase • ${PTICO.coin}${FLPC.price.toLocaleString()}`;ptBeep(520,.04,.25);tm=setTimeout(()=>{if(!by.isConnected)return;armed=0;by.classList.remove('arm');by.innerHTML=lab},3200);return}
  clearTimeout(tm);PTX.busy=1;by.disabled=true;const ok=flpEggBuy();PTX.busy=0;if(ok){ptTone(523,.3,.12);ptTone(784,.4,.1,'sine',.08);ptTone(1046,.5,.08,'sine',.16);ccToast(`${FLPC.egg} Egg added to your inventory.`);petHall('Eggs');const n=$('phxn');if(n)n.animate([{transform:'scale(1.5)',color:'#ffd45a'},{transform:'scale(1)'}],{duration:500,easing:'cubic-bezier(.3,1.6,.5,1)'});const c=ov.querySelector('.phx-c[data-egg="h"]');if(c)c.classList.add('got')}else petHall('Eggs')}}
 const vc=$('phxvc');if(vc)vc.onclick=()=>{PTX.sel='flturkey';petHall('Pets')};
 const mk=$('flpmk');if(mk)mk.onclick=()=>{ptBeep(560);fleMarket()};
 const sv=ov.querySelector('.flp-sv .phx-svb i');if(sv&&!ptRM())sv.animate([{transform:'scaleX(0)'},{transform:'scaleX(1)'}],{duration:900,easing:'cubic-bezier(.2,1,.3,1)'})}
/* arrow keys cycle through all four eggs */
function flpEggKeys(){const ord=[...ov.querySelectorAll('.phx-c[data-egg]')].map(b=>b.dataset.egg);if(!ord.includes('h'))return;
 ov.querySelectorAll('.phx-c').forEach(b=>b.onkeydown=e=>{const d=e.key==='ArrowDown'||e.key==='ArrowRight'?1:e.key==='ArrowUp'||e.key==='ArrowLeft'?-1:0;if(!d)return;e.preventDefault();const i=ord.indexOf(b.dataset.egg),o=ov.querySelector(`.phx-c[data-egg="${ord[(i+d+ord.length)%ord.length]}"]`);if(o)o.click();setTimeout(()=>{const f=ov.querySelector('.phx-c.on');if(f)f.focus()},20)})}
{const b0=ptEggsBind;ptEggsBind=function(){if(PTX.egg==='h')return flpEggsBind();const r=b0.apply(this,arguments);try{flpEggKeys()}catch(e){}return r}}

/* ---------- DEV › Cheats: a Harvest companions section ---------- */
{const h0=dvxHTML;dvxHTML=function(){let h=h0.apply(this,arguments);try{const own=FLPC.ids.filter(petOwned).map(id=>PDEF[id].n);
 h+=`<div class="dvx"><h5>Harvest companions</h5><div class="dvrow"><span>${own.length?own.join(', '):'None owned'} · ${flpEggN()} ${FLPC.egg} egg${flpEggN()===1?'':'s'}</span></div>
  <div class="dvrow">${dvBtn('x:flpS','Give Acorn Scamp')}${dvBtn('x:flpF','Give Emberleaf')}${dvBtn('x:flpT','Give Thunderplume')}</div>
  <div class="dvrow">${dvBtn('x:flpE','+1 '+FLPC.egg+' Egg')}${dvBtn('x:flpH','Hatch a '+FLPC.egg+' Egg')}${dvBtn('x:flpC','Remove the harvest companions','dg')}</div></div>`}catch(e){devLog('error','cheats harvest pets: '+e.message)}return h}}
{const a0=dvxAct;dvxAct=function(a){if(typeof a!=='string'||!/^flp[A-Z]$/.test(a))return a0.apply(this,arguments);
 const id={flpS:'flsquir',flpF:'flfox',flpT:'flturkey'}[a];
 if(id){if(petOwned(id))dvxMsg(PDEF[id].n+' is already in your hall.');else flpGive(id)}
 else if(a==='flpE'){flpEggAdd(1,{quiet:1});dvxMsg(`${FLPC.egg} Egg added (${flpEggN()} held).`)}
 else if(a==='flpH'){if(!flpEggN())flpEggAdd(1,{quiet:1});flpEgg()}
 else if(a==='flpC'){for(const k of FLPC.ids){delete P.pets[k];delete P.petNew[k]}if(FLPC.ids.includes(P.pet))P.pet='';if(P.petPend&&flpIs(P.petPend.id))P.petPend=null;petNorm();dvxMsg('The harvest companions are gone from this save.')}}}

/* ======================================================================
   POWERS: Acorn Toss (Acorn Scamp) and Maplefire Gale (Emberleaf)
   Both are unleashed with Shift (or the power icon) when READY, like every charged power since 87i. They work in Campaign and
   standard Endless only. The effects are advanced in update (dt) and drawn in drawWorld.
   ====================================================================== */
PM_MAN.add('acorntoss');PM_MAN.add('maplegale');
/* tuning (see the balance notes in the 10.4 handoff): Acorn Toss pushes 3.5% of the field and dazes 30% for 3 s; the gale slows 40% for 4 s */
const FLPG={fx:[],push:.035,daze:3,dazeK:.7,galeK:.6,gale:4};
const flpAud=(f,ms)=>{try{const A=phAudio();if(!A)return;f(A);setTimeout(()=>phStop(A),ms||1600)}catch(e){}};
const FLPS={
 throw:A=>{phNoise(A,0,.2,.12,{f:2800,f2:700,q:.8});for(let i=0;i<4;i++)phTone(A,i*.045,1500+i*240,.06,.035,{ty:'triangle',f2:1900+i*200})},
 bonk:A=>{phTone(A,0,560,.14,.28,{ty:'triangle',f2:250});phTone(A,0,1120,.06,.08,{ty:'triangle'});phNoise(A,0,.05,.22,{f:2400,q:2});phTone(A,.06,320,.3,.07,{f2:720,fd:.25})},
 gale:A=>{phNoise(A,0,1.1,.2,{f:380,f2:2400,q:.7,swell:1});phNoise(A,.25,.8,.12,{f:1800,f2:500,q:.9});for(let i=0;i<9;i++)phNoise(A,.2+i*.09+Math.random()*.05,.04,.12,{ty:'highpass',f:3800});phTone(A,0,880,.14,.06,{ty:'triangle',f2:1480});phTone(A,.12,1180,.12,.04,{ty:'triangle',f2:1760})}};
const flpSnd=k=>flpAud(FLPS[k],k==='gale'?2000:1200);
{const r0=petRunInit;petRunInit=function(){const r=r0.apply(this,arguments);FLPG.fx=[];return r}}
{const w0=pmWhyNot;pmWhyNot=function(p){const k=PDEF[p.id].ab.k;if(k==='acorntoss')return petNearest()?'':'No monster in reach yet';
 if(k==='maplegale')return S.pj.some(j=>!j.b)||S.en.some(e=>e.x<W-10&&e.x>KX)?'':'Nothing to blow away yet';return w0.apply(this,arguments)}}
/* a boss is never stunned or slowed: the attack it is winding up (telegraph and queued shots) is cancelled and its next one waits s seconds.
   (Adding time to its sentence would give it more chances to attack: bosses only attack while 2.6 s or more of the sentence remain.) */
function flpBossDaze(e,s){if(!e||!e.boss||e.state!=='fight'||e.ds)return false;e.tel=null;e.q=[];e.ak=Math.max(0,e.ak||0)+s;e.fl=Math.max(e.fl||0,.4);return true}
function flpToss(p){const e=petNearest();if(!e)return false;petSpend();petAnim('ability',1.1);FLPG.fx.push({k:'acorn',t:.0,ml:.5,e,x0:petPx()+26,y0:GY-58,tx:e.x,ty:e.y-e.h*.55,dl:.38});flpSnd('throw');return true}
function flpBonk(f){const e=f.e;if(!e||!S.en.includes(e))return;const push=(W+110-KX)*FLPG.push;e.x=Math.min(W+110,e.x+push);e.lg=1;e.fl=.3;e.fldz=FLPG.daze;
 burst(e.x,e.y-e.h*.55,'#e8a85a',16,{v:260});burst(e.x,e.y-e.h*.55,'#fff2c0',8,{v:180,s:3});FLPG.fx.push({k:'bonk',t:0,ml:.7,x:e.x,y:e.y-e.h*.55});float(e.x,e.y-e.h-40,'Bonk!','#ffd27a',34);S.shake=Math.max(S.shake,7);flpSnd('bonk')}
function flpGale(p){petSpend();petAnim('ability',1.5);let n=0;const pj=S.pj.filter(j=>!j.b);for(const j of pj)burst(j.x,j.y,'#ff8a2a',12,{v:240});S.pj=S.pj.filter(j=>j.b);
 for(const e of S.en){if(e.x>W-10)continue;if(e.boss){if(flpBossDaze(e,2))float(e.x-40,GY-e.h-40,'Attack blown away!','#ffb04a',30);continue}e.flgl=FLPG.gale;n++}
 FLPG.fx.push({k:'gale',t:0,ml:1.3,x:petPx()+30});S.shake=Math.max(S.shake,10);float(W*.45,GY-310,'Maplefire Gale!','#ffb04a',42);if(n)float(W*.55,GY-258,`Slowed ×${n}`,'#ffd0a0',28);flpSnd('gale');return true}
{const u0=update;update=function(dt){const p=S&&S.pet;if(!p||S.mode!=='play'||p.cos)return u0.apply(this,arguments);const k=PDEF[p.id].ab.k,mod=[];
 if(!S.cine&&p.ready&&p.go){if(k==='acorntoss')flpToss(p);else if(k==='maplegale')flpGale(p)}
 /* acorns in flight land, effects age */for(let i=FLPG.fx.length-1;i>=0;i--){const f=FLPG.fx[i];f.t+=dt;if(f.k==='acorn'&&!f.hit&&f.t>=f.dl){f.hit=1;flpBonk(f)}if(f.t>=f.ml)FLPG.fx.splice(i,1)}
 /* dazed and gale-slowed monsters (the strongest applies; never stacked) */
 if(!S.cine)for(const e of S.en){if(e.boss)continue;let f=1;if(e.fldz>0){e.fldz-=dt;f=FLPG.dazeK}if(e.flgl>0){e.flgl-=dt;f=Math.min(f,FLPG.galeK)}if(f<1){mod.push([e,e.sp]);e.sp*=f}}
 const r=u0.apply(this,arguments);for(let i=mod.length-1;i>=0;i--)mod[i][0].sp=mod[i][1];return r}}
{const w0=drawWorld;drawWorld=function(){const r=w0.apply(this,arguments);try{const c=ctx,t=S.t;if(!S.pet&&!FLPG.fx.length)return r;
 for(const e of S.en){const top=e.y-(e.h||80);
  if(e.fldz>0){/* dazed: stars and a little acorn cap circle its head */const a=Math.min(1,e.fldz/.4);c.save();c.globalAlpha=a;for(let i=0;i<3;i++){const an=t*5+i*TAU/3,x=e.x+Math.cos(an)*26,y=top-14+Math.sin(an)*7;if(i===0)flpAcorn(c,x,y,10,an,FLP_AC,1.4);else pStar4(c,x,y,7,'#ffe27a')}c.restore()}
  if(e.flgl>0){/* smouldering maple leaves orbit a gale-slowed monster */const a=Math.min(1,e.flgl/.5);c.save();c.globalAlpha=a;pGlow(c,e.x,e.y-8,(e.h||80)*.5,'#ff8a2a',.22);for(let i=0;i<3;i++){const an=t*2.2+i*TAU/3,x=e.x+Math.cos(an)*(e.h||80)*.42,y=e.y-(e.h||80)*.45+Math.sin(an)*(e.h||80)*.3;flpLeafD(c,x,y,12,an*2,i)}c.restore()}}
 for(const f of FLPG.fx){const u=Math.min(1,f.t/f.ml);
  if(f.k==='acorn'&&!f.hit){const v=Math.min(1,f.t/f.dl),tx=f.e&&S.en.includes(f.e)?f.e.x:f.tx,ty=f.e&&S.en.includes(f.e)?f.e.y-f.e.h*.55:f.ty,x=f.x0+(tx-f.x0)*v,y=f.y0+(ty-f.y0)*v-Math.sin(v*Math.PI)*150;
   for(let i=1;i<6;i++){const w=Math.max(0,v-i*.04),xx=f.x0+(tx-f.x0)*w,yy=f.y0+(ty-f.y0)*w-Math.sin(w*Math.PI)*150;c.globalAlpha=.4-i*.06;pC(c,xx,yy,8-i);c.fillStyle='#ffe2a0';c.fill()}c.globalAlpha=1;flpAcorn(c,x,y,26,v*16,FLP_AC,2.4)}
  else if(f.k==='bonk'){c.save();c.globalAlpha=1-u;c.globalCompositeOperation='lighter';pGlow(c,f.x,f.y,80*(1-u*.5),'#ffd27a',.6);c.restore();c.save();c.globalAlpha=1-u;pStar5(c,f.x,f.y,22+u*20,'#fff2b0',3);
   for(let i=0;i<5;i++){const an=i/5*TAU+.4,d=20+u*90;c.save();c.translate(f.x+Math.cos(an)*d,f.y+Math.sin(an)*d+u*u*60);c.rotate(an+u*8);c.beginPath();c.moveTo(-7,0);c.bezierCurveTo(-7,-7,7,-7,7,0);c.closePath();pF(c,i%2?'#8a5428':'#b47a40',1.6);c.restore()}c.restore()}
  else if(f.k==='gale'){/* a gust of burning leaves rolls across the field */const x=f.x+pS(u)*(W-f.x+220);c.save();c.globalCompositeOperation='lighter';c.globalAlpha=1-u*.7;
   for(let j=0;j<3;j++){const v=Math.max(0,Math.min(1,u*1.3-j*.12));if(v<=0||v>=1)continue;c.beginPath();c.arc(f.x+v*(W-f.x+260)-240,GY-170,260,-.9,.9);c.strokeStyle=`rgba(255,${140+j*30},60,${.7*(1-v)})`;c.lineWidth=26*(1-v)+5;c.stroke()}c.restore();
   c.save();for(let i=0;i<22;i++){const k2=(i*.137)%1,v=Math.max(0,Math.min(1,u*1.4-k2*.4)),xx=f.x+v*(W-f.x+200)+Math.sin(i*3.1)*40,yy=GY-40-((i*53)%300)-Math.sin(v*6+i)*30;if(v<=0||v>=1)continue;c.globalAlpha=Math.sin(v*Math.PI);pGlow(c,xx,yy,18,'#ff8a2a',.5);flpLeafD(c,xx,yy,14+i%3*4,v*12+i,i%4)}c.restore()}}}catch(e){}return r}}

/* ---------- styles ---------- */
{const st=document.createElement('style');st.textContent=`
.ptc-fl .flptg{position:absolute;top:5px;left:6px;width:18px;height:18px;color:#ffa53a;z-index:2;pointer-events:none;filter:none}.ptc-fl .flptg svg{width:100%;height:100%;display:block}
.ptc-fl.unk .flptg{color:#a8603a}
.ptc-fl:has(.ptnw) .flptg{top:26px}
.ptlk-fl b,.ptlk-fl em,.phx-kh .phx-why b{white-space:nowrap}
.ptlk-fl{padding:12px 14px;border-radius:14px;background:linear-gradient(180deg,#3a1e14,#1a0c10);border:1px solid #8a4a24;line-height:1.5}.ptlk-fl b{color:#fff}.ptlk-fl em{font-style:normal;font-weight:800;color:#ffc46a}
.flpto svg{width:18px;height:18px}
.ptbg-h{color:#2a1406;background:linear-gradient(90deg,#ffd45a,#ff9a2a 55%,#e8541a);border:1.5px solid #ffe6a0;text-shadow:none}
.phx3 .phx-c.phx-h{background:radial-gradient(circle at 30% 40%,#4a2414,#1a0a0e 75%);border-color:#8a4a24}
.phx3 .phx-c.phx-h.on{border-color:#ffb43a!important;box-shadow:0 0 0 1px #ffb43a66,0 0 26px #ff8a2a44}
.phx-bh i,.ptbar.phx-bh i{background:linear-gradient(90deg,#e8541a,#ff9a2a,#ffd45a)!important}
.phx4 .phx-cards{gap:8px!important}.phx4 .phx-c{padding:4px 14px!important;min-height:0!important}.phx4 .phx-c canvas{width:62px!important;height:71px!important}.phx4 .phx-ci b{font-size:22px!important}
.phx4 .phx-cnt{top:6px!important}.phx4 .phx-cnew{bottom:6px!important}
.phx-kh .phx-tt h3{color:#ffe0a0;text-shadow:0 3px 0 #3a1406,0 0 22px #ff8a2a88}
.flp-hatch{background:linear-gradient(180deg,#fff0a0,#ffb43a 55%,#d8641a)!important;color:#2a1006!important;box-shadow:0 4px 0 #7a2e0a!important}
.flp-sv .flp-svi{background:#4a2410;color:#ffb43a}.flp-sv.ok{border-color:#ffb43a!important}
.flp-mk{flex:none;margin-left:auto;align-self:center;white-space:nowrap}
/* 10.4c: at a small window the Hall switches to two columns (87c, max-width 1100px); the Pets stage then runs under the dock, so its name label sits higher */
@media (max-width:1100px){.pt-Pets .ptnm{bottom:34px}}
.phx-ab-h{border-color:#8a4a24}.phx-ab-h .phx-abh i{color:#ffb43a}.phx-ab-h .phx-facts svg{width:13px;height:13px}
.flp-new{color:#ffe0a0!important;background:#5a2410!important;border-color:#ffb43a66!important}
.phx-c.got{animation:flpgot .6s cubic-bezier(.3,1.6,.5,1)}@keyframes flpgot{40%{transform:scale(1.05)}}
@media (prefers-reduced-motion:reduce){.phx-c.got{animation:none}}
`;document.head.appendChild(st)}
