/* ===== MOONLIT FISHING: Glowcap Grotto (FSLOCART.grotto) =====
   A vast cave lagoon: stalactites frame the top, a cave mouth opens onto a starry sky with a crescent moon, giant
   glowing mushrooms and crystal clusters cling to the rocks, the water glows with bioluminescence. On the left a carved
   rock arch with hanging lanterns; the hero fishes from a rock ledge with planks and rope (same footprint as the pond dock).
   bg is painted once; back/front run every frame and only draw cached sprites and a handful of light shapes.
   The big breathing glows (moon, mushrooms, lanterns) are pre-made at their drawn size so each one is a 1:1 blit.
   Private helpers are prefixed lg_. */
let lg_S=null;
const lg_hx=a=>Math.round(Math.max(0,Math.min(1,a))*255).toString(16).padStart(2,'0');
const lg_r=s=>{const x=Math.sin(s*91.345+7.13)*43758.5453;return x-Math.floor(x)};
/* soft additive glow sprite (tinted) and a bright-cored mote sprite */
function lg_spr(col,n){const c=document.createElement('canvas');c.width=c.height=n||128;const g=c.getContext('2d'),h=c.width/2,q=g.createRadialGradient(h,h,0,h,h,h);
 q.addColorStop(0,col+'ff');q.addColorStop(.22,col+'aa');q.addColorStop(.55,col+'30');q.addColorStop(1,col+'00');g.fillStyle=q;g.fillRect(0,0,c.width,c.width);return c}
function lg_mote(col){const c=document.createElement('canvas');c.width=c.height=48;const g=c.getContext('2d'),q=g.createRadialGradient(24,24,0,24,24,24);
 q.addColorStop(0,'#ffffffff');q.addColorStop(.12,col+'ff');q.addColorStop(.4,col+'55');q.addColorStop(1,col+'00');g.fillStyle=q;g.fillRect(0,0,48,48);return c}
/* the cave mouth outline (craggy ellipse, flat bottom hidden behind the far shore) */
/* smooth carved-stone outline: low-frequency wobble plus a few chunky overhangs (negative = rock juts into the opening) */
const LG_NOTCH=[[Math.PI-.52,-.055,.10],[Math.PI-.2,.025,.07],[Math.PI+.42,-.07,.085],[Math.PI+.8,-.035,.07],[Math.PI*1.5-.3,-.045,.09],[Math.PI*1.5+.36,-.04,.08],[TAU-.52,-.05,.09],[.22,-.03,.07]];
function lg_mouthPts(){const p=[];for(let i=0;i<96;i++){const a=i/96*TAU;let n=1+Math.sin(a*3+.7)*.022+Math.sin(a*5+1)*.018+Math.sin(a*9+2.4)*.007+(lg_r(i*3.1)-.5)*.006;
  LG_NOTCH.forEach(([a0,k,w])=>{let d=a-a0;d-=Math.round(d/TAU)*TAU;n+=k*Math.exp(-(d*d)/(w*w))});
  let x=1000+Math.cos(a)*382*n,y=292+Math.sin(a)*262*n;if(y>512)y=512+lg_r(i)*6;p.push(x,y)}return p}
/* filled rock with a coloured rim light (offset dx,dy picks the lit side) and an outline */
function lg_rock(g,p,cA,cB,lw,rim,ra,dx,dy){let y0=1e9,y1=-1e9;for(let i=1;i<p.length;i+=2){y0=Math.min(y0,p[i]);y1=Math.max(y1,p[i])}
 fkPath(g,p);g.fillStyle=fkLin(g,0,y0,0,y1,[cA,cB]);g.fill();
 if(rim){g.save();fkPath(g,p);g.clip();g.translate(dx==null?5:dx,dy==null?6:dy);fkPath(g,p);g.strokeStyle=rim;g.globalAlpha=(ra||.5)*.45;g.lineWidth=9;g.stroke();g.globalAlpha=(ra||.5)*.8;g.lineWidth=3;g.translate(-(dx==null?5:dx)*.5,-(dy==null?6:dy)*.5);fkPath(g,p);g.stroke();g.restore()}
 if(lw){fkPath(g,p);g.lineWidth=lw;g.strokeStyle=FKO;g.lineJoin='round';g.stroke()}}
/* a dim lit rock facet on a wall: soft fill, moonlit top edge, dark crack below */
function lg_facet(g,p,lite){g.save();fkPath(g,p);g.fillStyle=lite;g.globalAlpha=.12;g.fill();g.lineCap='round';
 g.globalAlpha=.42;g.strokeStyle=lite;g.lineWidth=2.4;g.beginPath();g.moveTo(p[0],p[1]);g.quadraticCurveTo(p[2],p[3],p[4],p[5]);g.stroke();
 g.globalAlpha=.65;g.strokeStyle='#0a0620';g.lineWidth=2.6;g.beginPath();g.moveTo(p[4],p[5]);g.lineTo(p[6],p[7]);g.quadraticCurveTo(p[8],p[9],p[0],p[1]);g.stroke();g.restore()}
/* a small outlined rock shelf a crystal can sit on, with a soft shadow and a little drip-stone underneath */
function lg_ledge(g,p,sx,sy,rim){let x0=1e9,x1=-1e9,yt=1e9;for(let i=0;i<p.length;i+=2){x0=Math.min(x0,p[i]);x1=Math.max(x1,p[i]);yt=Math.min(yt,p[i+1])}
 const cx=(x0+x1)/2,hw=(x1-x0)/2;
 /* shadow cast down the wall */
 g.save();g.beginPath();g.moveTo(x0+6,sy-6);g.lineTo(x1-4,sy-8);g.lineTo(x1-14,sy+38);g.lineTo(x0+16,sy+40);g.closePath();g.fillStyle=fkLin(g,0,sy-6,0,sy+40,['#05021a90','#05021a00']);g.fill();g.restore();
 /* the outcrop grows out of the wall: cracks run from its ends into the rock */
 g.save();g.strokeStyle='#0a0620';g.globalAlpha=.7;g.lineWidth=2.4;g.lineCap='round';g.beginPath();g.moveTo(x0+4,sy-6);g.quadraticCurveTo(x0-14,sy-2,x0-26,sy+10);g.moveTo(x1-4,sy-8);g.quadraticCurveTo(x1+12,sy-14,x1+22,sy-4);g.moveTo(cx-6,yt+2);g.quadraticCurveTo(cx-10,yt-14,cx-4,yt-26);g.stroke();g.restore();
 /* front face (dark, chunky, jagged underside) */
 const fr=[x0,p[1]+2,x1,p[1]+4,x1-6,sy-2,x1-18,sy+4,cx+hw*.35,sy+10,cx+4,sy+16,cx-hw*.3,sy+9,x0+14,sy+4,x0+4,sy-4];
 lg_rock(g,fr,'#2a2064','#120a30',3,null);
 lg_stal(g,sx,sy+8,6,14,'#2a2064','#120a30',2.2,null);
 /* lit top face */
 lg_rock(g,p,'#5a4aa6','#2c2270',3,rim,.85,0,5)}
/* rock texture inside a path: strata cracks and soft lumps */
function lg_tex(g,p,x0,y0,x1,y1,n,seed,dark,lite){g.save();fkPath(g,p);g.clip();g.lineCap='round';
 for(let i=0;i<n;i++){const x=x0+lg_r(seed+i)*(x1-x0),y=y0+lg_r(seed+i+.5)*(y1-y0),w=20+lg_r(seed+i+.7)*60;
  g.globalAlpha=.18+lg_r(seed+i+.9)*.2;g.fillStyle=lite;g.beginPath();g.ellipse(x,y,w*.5,w*.18,(lg_r(seed+i+.3)-.5)*.5,0,TAU);g.fill();
  g.globalAlpha=.35;g.strokeStyle=dark;g.lineWidth=1.6+lg_r(seed+i+.2)*1.4;g.beginPath();g.moveTo(x-w*.5,y+w*.2);g.quadraticCurveTo(x,y+w*.2+(lg_r(seed+i+.4)-.5)*14,x+w*.5,y+w*.24);g.stroke()}
 g.restore();g.globalAlpha=1}
/* a hanging stalactite (x,y = root centre) */
function lg_stal(g,x,y,w,h,cA,cB,lw,rim){const k=lg_r(x*.37+h);const p=[x-w,y-6,x-w*.78,y+h*.28,x-w*.42,y+h*.6,x-w*.12+k*4,y+h*.9,x+w*.04,y+h,x+w*.18,y+h*.82,x+w*.46,y+h*.5,x+w*.8,y+h*.24,x+w,y-6];
 g.beginPath();g.moveTo(p[0],p[1]);for(let i=2;i<p.length-2;i+=2){const mx=(p[i]+p[i+2])/2,my=(p[i+1]+p[i+3])/2;g.quadraticCurveTo(p[i],p[i+1],mx,my)}g.lineTo(p[p.length-2],p[p.length-1]);g.closePath();
 g.fillStyle=fkLin(g,x-w,0,x+w,0,[cA,cB]);g.fill();
 g.save();g.clip();g.strokeStyle='#00000040';g.lineWidth=2;for(let i=1;i<4;i++){const yy=y+h*i*.2;g.beginPath();g.moveTo(x-w,yy);g.quadraticCurveTo(x,yy+w*.35,x+w,yy);g.stroke()}
 if(rim){g.strokeStyle=rim;g.globalAlpha=.55;g.lineWidth=3;g.beginPath();g.moveTo(x-w*.62,y+4);g.quadraticCurveTo(x-w*.48,y+h*.5,x-w*.06,y+h*.9);g.stroke()}g.restore();
 if(lw){g.lineWidth=lw;g.strokeStyle=FKO;g.lineJoin='round';g.stroke()}
 return{x:x+w*.04,y:y+h}}
/* a stalagmite growing up from (x,y) */
function lg_stalag(g,x,y,w,h,cA,cB,lw,rim){g.beginPath();g.moveTo(x-w,y);g.quadraticCurveTo(x-w*.7,y-h*.45,x-w*.1,y-h*.95);g.quadraticCurveTo(x+w*.05,y-h*1.02,x+w*.18,y-h*.9);g.quadraticCurveTo(x+w*.7,y-h*.4,x+w,y);g.closePath();
 g.fillStyle=fkLin(g,0,y-h,0,y,[cA,cB]);g.fill();if(rim){g.save();g.clip();g.strokeStyle=rim;g.globalAlpha=.5;g.lineWidth=2.4;g.beginPath();g.moveTo(x-w*.55,y-2);g.quadraticCurveTo(x-w*.45,y-h*.5,x-w*.05,y-h*.88);g.stroke();g.restore()}
 if(lw){g.lineWidth=lw;g.strokeStyle=FKO;g.stroke()}}
/* a glowing mushroom: base (x,y), stem height h, cap half-width cw, lean (dx of the cap), colours {c:[light,mid,dark], gl, st} */
function lg_mush(g,x,y,h,cw,lean,C,lw){lw=lw==null?3:lw;const tx=x+lean,ty=y-h,sw=Math.max(3,cw*.2),ch=cw*.62;
 fkGlow(g,tx,ty+ch*.1,cw*2.3,C.gl,.30);fkGlow(g,tx,ty+cw*.2,cw*1.1,C.gl,.30);
 /* stem */
 g.beginPath();g.moveTo(x-sw*1.25,y);g.quadraticCurveTo(x+lean*.2-sw*1.1,y-h*.55,tx-sw*.8,ty);g.lineTo(tx+sw*.8,ty);g.quadraticCurveTo(x+lean*.2+sw*1.15,y-h*.5,x+sw*1.35,y);g.closePath();
 g.fillStyle=fkLin(g,x-sw,0,x+sw,0,[C.st||'#efe6ff','#a89cd8','#6a5c9e']);g.fill();g.save();g.clip();g.strokeStyle=C.gl;g.globalAlpha=.35;g.lineWidth=Math.max(1.5,sw*.35);g.beginPath();g.moveTo(x-sw*.6,y);g.quadraticCurveTo(x+lean*.2-sw*.5,y-h*.55,tx-sw*.25,ty);g.stroke();g.restore();
 if(lw){g.lineWidth=lw*.85;g.strokeStyle=FKO;g.stroke()}
 /* frilly ring on the stem */
 if(h>cw*.9){g.save();g.beginPath();g.moveTo(x-sw*1.25,y);g.quadraticCurveTo(x+lean*.2-sw*1.1,y-h*.55,tx-sw*.8,ty);g.lineTo(tx+sw*.8,ty);g.quadraticCurveTo(x+lean*.2+sw*1.15,y-h*.5,x+sw*1.35,y);g.clip();g.strokeStyle='#ffffff';g.globalAlpha=.25;g.lineWidth=1.2;for(let k=-1;k<=1;k++){g.beginPath();g.moveTo(x+k*sw*.6,y);g.quadraticCurveTo(x+lean*.2+k*sw*.5,y-h*.55,tx+k*sw*.4,ty);g.stroke()}g.restore();
  if(h>cw*1.3){const rx=x+lean*.68,ry=y-h*.72,rw=sw*1.35;g.beginPath();g.moveTo(rx-sw*.85,ry-sw*.3);g.lineTo(rx+sw*.85,ry-sw*.3);g.quadraticCurveTo(rx+rw*1.05,ry+sw*.25,rx+rw,ry+sw*.6);for(let k=4;k>=0;k--){const fx=rx-rw+k*rw*.5;g.quadraticCurveTo(fx+rw*.25,ry+sw*.95,fx,ry+sw*.6)}g.closePath();g.fillStyle=fkLin(g,0,ry-sw*.3,0,ry+sw*.8,['#f2ecff','#b4a8e0',C.c[1]]);g.fill();if(lw){g.lineWidth=lw*.6;g.strokeStyle=FKO;g.stroke()}}}
 /* gills underneath */
 g.beginPath();g.ellipse(tx,ty,cw*.96,cw*.2,0,0,TAU);g.fillStyle=C.c[2];g.fill();g.save();g.clip();g.strokeStyle=C.gl;g.globalAlpha=.75;g.lineWidth=1.3;for(let i=-6;i<=6;i++){g.beginPath();g.moveTo(tx,ty-cw*.05);g.lineTo(tx+i*cw*.16,ty+cw*.22);g.stroke()}g.restore();
 /* cap dome */
 const cap=()=>{g.beginPath();g.moveTo(tx-cw,ty+cw*.05);g.bezierCurveTo(tx-cw*1.02,ty-ch*.9,tx-cw*.45,ty-ch*1.25,tx+cw*.05,ty-ch*1.2);g.bezierCurveTo(tx+cw*.6,ty-ch*1.15,tx+cw*1.04,ty-ch*.75,tx+cw,ty+cw*.05);g.quadraticCurveTo(tx,ty-cw*.12,tx-cw,ty+cw*.05);g.closePath()};
 cap();g.fillStyle=fkRad(g,tx-cw*.2,ty-ch*.7,cw*1.25,[C.c[0],C.c[1],C.c[2]]);g.fill();
 g.save();cap();g.clip();
 /* spots */
 const ns=Math.max(4,Math.round(cw/9));for(let i=0;i<ns;i++){const u=(i+.5)/ns,sx=tx-cw*.85+u*cw*1.7+(lg_r(i+cw)-.5)*cw*.2,sy=ty-ch*(.25+.75*Math.sin(u*Math.PI))*(.5+lg_r(i*2+cw)*.4),sr=cw*(.07+lg_r(i*3+cw)*.07);
  g.globalAlpha=.9;g.fillStyle='#ffffff';g.beginPath();g.ellipse(sx,sy,sr,sr*.8,0,0,TAU);g.fill();g.globalAlpha=.55;g.fillStyle=C.gl;g.beginPath();g.ellipse(sx,sy,sr*1.6,sr*1.3,0,0,TAU);g.fill()}
 g.globalAlpha=1;{const q=g.createLinearGradient(0,ty-ch*.45,0,ty+cw*.06);q.addColorStop(0,C.c[2]+'00');q.addColorStop(1,C.c[2]+'b0');g.fillStyle=q;g.fillRect(tx-cw*1.1,ty-ch*.45,cw*2.2,ch*.45+cw*.1)}
 g.strokeStyle='#ffffff';g.globalAlpha=.45;g.lineWidth=Math.max(2,cw*.07);g.beginPath();g.ellipse(tx-cw*.15,ty-ch*.25,cw*.7,ch*.75,0,Math.PI*1.12,Math.PI*1.5);g.stroke();
 g.globalAlpha=.6;g.strokeStyle=C.gl;g.lineWidth=Math.max(2,cw*.09);g.beginPath();g.moveTo(tx-cw,ty+cw*.06);g.quadraticCurveTo(tx,ty-cw*.12,tx+cw,ty+cw*.06);g.stroke();g.restore();
 cap();if(lw){g.lineWidth=lw;g.strokeStyle=FKO;g.stroke()}
 return{x:tx,y:ty}}
/* a crystal cluster at (x,y): shards [angle,len,width] */
function lg_crys(g,x,y,s,cl,cm,cd,gl,shards,lw){lw=lw==null?2.4:lw;fkGlow(g,x,y-s*20,s*70,gl,.32);
 shards.forEach(([a,l,w])=>{g.save();g.translate(x,y);g.rotate(a);l*=s;w*=s;
  g.beginPath();g.moveTo(-w,4);g.lineTo(-w,-l*.72);g.lineTo(0,-l);g.lineTo(w,-l*.72);g.lineTo(w,4);g.closePath();g.fillStyle=fkLin(g,0,0,0,-l,[cd,cm]);g.fill();
  g.beginPath();g.moveTo(-w,4);g.lineTo(-w,-l*.72);g.lineTo(0,-l);g.lineTo(-w*.1,4);g.closePath();g.fillStyle=fkLin(g,0,0,0,-l,[cm,cl]);g.fill();
  g.strokeStyle='#ffffff';g.globalAlpha=.7;g.lineWidth=1.4;g.beginPath();g.moveTo(-w*.55,-l*.15);g.lineTo(-w*.55,-l*.68);g.stroke();g.globalAlpha=.35;g.beginPath();g.moveTo(0,-l);g.lineTo(-w*.1,4);g.stroke();g.globalAlpha=1;
  g.beginPath();g.moveTo(-w,4);g.lineTo(-w,-l*.72);g.lineTo(0,-l);g.lineTo(w,-l*.72);g.lineTo(w,4);if(lw){g.lineWidth=lw;g.strokeStyle=FKO;g.stroke()}g.restore()});
 fkGlow(g,x,y-s*8,s*26,'#ffffff',.18)}
/* a hanging/standing lantern body (the glow is animated in back) */
function lg_lantern(g,x,y,s){g.save();g.translate(x,y);g.scale(s,s);
 g.fillStyle='#2a1a22';g.beginPath();g.moveTo(-15,-24);g.lineTo(0,-38);g.lineTo(15,-24);g.closePath();g.fill();g.lineWidth=2.5;g.strokeStyle=FKO;g.stroke();
 g.beginPath();g.arc(0,-40,4,0,TAU);g.strokeStyle='#4a3440';g.lineWidth=2.4;g.stroke();
 g.fillStyle=fkLin(g,0,-22,0,16,['#fff2b8','#ffc04a','#f08a2a']);g.beginPath();g.moveTo(-11,-22);g.lineTo(11,-22);g.lineTo(13,12);g.lineTo(-13,12);g.closePath();g.fill();
 g.strokeStyle='#2a1a22';g.lineWidth=3;g.stroke();g.lineWidth=2.2;g.beginPath();g.moveTo(0,-22);g.lineTo(0,12);g.moveTo(-12,-6);g.lineTo(12,-6);g.stroke();
 g.fillStyle='#fffbe8';g.beginPath();g.ellipse(0,-2,3,6,0,0,TAU);g.fill();
 g.fillStyle='#2a1a22';g.fillRect(-16,12,32,6);g.lineWidth=2.2;g.strokeStyle=FKO;g.strokeRect(-16,12,32,6);g.restore()}
/* layout of glowing things (shared by bg and the animated glows) */
const LG_MOUTH={x:1000,y:292};
const LG_MOON={x:1150,y:168,r:46};
const LG_LANT=[{x:118,y:318,s:.9},{x:214,y:318,s:.9},{x:260,y:516,s:1},{x:588,y:516,s:1}];
const LG_FALL={x:1290,y0:230,y1:540,w0:8,w1:19};
/* the tapered waterfall outline (k scales the half-width; yb overrides the bottom) */
function lg_fallPath(g,k,yb){const F=LG_FALL,x=F.x,a=F.w0*k,b=F.w1*k,y0=F.y0,y1=yb==null?F.y1:yb;
 g.beginPath();g.moveTo(x-a,y0);g.bezierCurveTo(x-a-2*k,y0+70,x-b,y0+(y1-y0)*.45,x-b,y1);g.lineTo(x+b,y1);g.bezierCurveTo(x+b,y0+(y1-y0)*.45,x+a+2*k,y0+70,x+a,y0);g.closePath()}
/* static soft body of the waterfall plus the foam pool at its foot (painted after the water so it overlaps the waterline) */
function lg_fallBody(g){const F=LG_FALL,H=F.y1-F.y0+30;
 const C=document.createElement('canvas');C.width=120;C.height=H;const c=C.getContext('2d');c.translate(60-F.x,-F.y0+4);
 [[1.9,'#4ac0ff',.10],[1.3,'#7ae4ff',.22],[.85,'#bdf6ff',.32],[.42,'#ffffff',.30]].forEach(([k,col,a])=>{lg_fallPath(c,k);c.globalAlpha=a;c.fillStyle=col;c.fill()});
 /* blur by downscale/upscale so the edges stay soft */
 const D=document.createElement('canvas');D.width=40;D.height=Math.ceil(H/3);D.getContext('2d').drawImage(C,0,0,40,D.height);
 g.save();g.drawImage(D,F.x-60,F.y0-4,120,H);g.restore();
 /* a bright glassy curl where the water tips over the lip */
 g.save();g.fillStyle='#ffffff';g.globalAlpha=.85;g.beginPath();g.moveTo(F.x-F.w0-2,F.y0+1);g.quadraticCurveTo(F.x,F.y0-7,F.x+F.w0+2,F.y0+1);g.quadraticCurveTo(F.x,F.y0+6,F.x-F.w0-2,F.y0+1);g.fill();g.restore();
 fkGlow(g,F.x,F.y1,90,'#7af4ff',.22);
 /* soft reflection of the fall and its glow in the water */
 g.save();g.globalCompositeOperation='lighter';g.translate(F.x,F.y1+30);g.scale(1,1.6);const q=g.createRadialGradient(0,0,0,0,0,26);q.addColorStop(0,'#9af6ff40');q.addColorStop(1,'#9af6ff00');g.fillStyle=q;g.beginPath();g.arc(0,0,26,0,TAU);g.fill();g.restore();
 /* foam pool: shaded puffs, no outline */
 [[-30,4,11],[-17,-2,14],[0,-5,17],[17,-1,14],[31,4,11],[-8,6,15],[11,7,13],[-40,9,7],[42,9,7]].forEach(([dx,dy,r])=>{g.globalAlpha=.55;g.fillStyle='#5ac8e8';g.beginPath();g.ellipse(F.x+dx,F.y1+dy+3,r,r*.46,0,0,TAU);g.fill()});
 [[-30,4,10],[-17,-2,13],[0,-5,16],[17,-1,13],[31,4,10],[-8,6,14],[11,7,12],[-40,9,6],[42,9,6]].forEach(([dx,dy,r])=>{g.globalAlpha=.8;g.fillStyle='#effdff';g.beginPath();g.ellipse(F.x+dx,F.y1+dy,r,r*.44,0,0,TAU);g.fill()});
 g.globalAlpha=.3;g.strokeStyle='#bff8ff';g.lineWidth=1.6;[[58,9],[82,13]].forEach(([r,dy])=>{g.beginPath();g.ellipse(F.x,F.y1+dy,r,r*.24,0,0,TAU);g.stroke()});g.globalAlpha=1}
/* ---------- the still layer ---------- */
function lg_bg(g){g.lineJoin='round';g.lineCap='round';
 const M=lg_mouthPts();
 /* night sky seen through the cave mouth */
 g.fillStyle=fkLin(g,0,0,0,FSW_Y,['#05061e','#0c1242','#1a2468','#30418e']);g.fillRect(0,0,1600,FSW_Y+4);
 fkGlow(g,1040,300,420,'#4a58c8',.28);fkGlow(g,LG_MOON.x,LG_MOON.y,260,'#7a88e8',.22);
 for(let i=0;i<200;i++){const x=600+lg_r(i+11)*800,y=20+lg_r(i+211)*470,r=lg_r(i+411)<.07?1.8:lg_r(i+411)<.35?1.15:.7;g.globalAlpha=.3+lg_r(i+611)*.65;g.fillStyle=lg_r(i+811)<.18?'#ffe8c0':lg_r(i+811)<.3?'#c8e6ff':'#f2eeff';g.beginPath();g.arc(x,y,r,0,TAU);g.fill()}g.globalAlpha=1;
 /* a faint milky band */
 g.save();g.translate(1000,260);g.rotate(-.5);for(let i=0;i<7;i++){g.globalAlpha=.05;g.fillStyle=i%2?'#a8b0ff':'#d0b8ff';g.beginPath();g.ellipse((i-3)*70,(lg_r(i)-.5)*30,120,26+lg_r(i+4)*20,0,0,TAU);g.fill()}g.restore();g.globalAlpha=1;
 /* crescent moon */
 {const m=LG_MOON;fkGlow(g,m.x,m.y,150,'#fff0c8',.32);fkGlow(g,m.x,m.y,70,'#fff6dc',.35);
  const C=document.createElement('canvas');C.width=C.height=140;const c=C.getContext('2d');c.translate(70,70);c.beginPath();c.arc(0,0,m.r,0,TAU);c.fillStyle=fkRad(c,0,0,m.r,['#fffef4','#fbf0cc','#e0cf9c']);c.fill();
  c.fillStyle='#c9b98a';[[-26,-6,7],[-18,18,9],[-30,14,4],[-12,-26,5]].forEach(([x,y,r])=>{c.globalAlpha=.4;c.beginPath();c.arc(x,y,r,0,TAU);c.fill()});c.globalAlpha=1;
  c.globalCompositeOperation='destination-out';c.beginPath();c.arc(20,-12,m.r*.9,0,TAU);c.fill();g.drawImage(C,m.x-70,m.y-70)}
 /* little clouds drifting by the moon */
 const cloud=(x,y,w,a)=>{g.save();g.globalAlpha=a;g.fillStyle='#8a90e0';for(let i=0;i<6;i++){g.beginPath();g.ellipse(x+i*w*.18-w*.45,y+Math.sin(i*1.7)*5,w*.2,8+lg_r(i+x)*7,0,0,TAU);g.fill()}g.restore()};
 cloud(1210,220,260,.12);cloud(820,150,240,.08);cloud(980,380,300,.07);
 /* distant moonlit mountains and forest through the mouth */
 g.fillStyle='#1e2a6c';g.beginPath();g.moveTo(600,520);const pk=[[600,450],[680,392],[740,430],[820,366],[900,420],[960,384],[1040,440],[1110,372],[1190,410],[1260,350],[1340,420],[1400,400]];pk.forEach(([x,y])=>g.lineTo(x,y));g.lineTo(1400,520);g.fill();
 g.fillStyle='#3e52a6';g.globalAlpha=.55;for(let i=1;i<pk.length-1;i++){const[x,y]=pk[i];if(pk[i-1][1]>y&&pk[i+1][1]>y){g.beginPath();g.moveTo(x,y);g.lineTo(x-24,y+30);g.lineTo(x-8,y+24);g.lineTo(x+2,y+34);g.lineTo(x+14,y+20);g.closePath();g.fill()}}g.globalAlpha=1;
 fkGlow(g,1000,500,360,'#5a6ad0',.16);
 g.fillStyle='#121a4c';g.beginPath();g.moveTo(600,522);for(let x=600;x<=1400;x+=14){const h=26+lg_r(x*.13)*28;g.lineTo(x,494-h*.4);g.lineTo(x+7,494-h)}g.lineTo(1400,522);g.fill();
 /* cave back wall with the mouth cut out; moonlight rims the opening */
 {const W=document.createElement('canvas');W.width=1600;W.height=900;const w=W.getContext('2d');w.lineJoin=w.lineCap='round';
  w.fillStyle=fkLin(w,0,0,0,560,['#100a2a','#1e1546','#2c2160']);w.fillRect(0,0,1600,560);
  const all=[0,0,1600,0,1600,560,0,560];lg_tex(w,all,0,0,1600,540,90,3,'#0a0620','#3a2c74');
  fkGlow(w,460,420,260,'#7a4ad0',.22);fkGlow(w,1500,420,240,'#2ab8c8',.2);
  /* dim rock facets and embedded crystal glints on the inner walls (top left / top right) */
  [[372,178,420,166,462,176,454,192,404,198],[470,238,520,226,556,236,548,252,492,254],[352,372,404,358,446,368,436,386,372,390],[486,404,540,392,572,404,560,420,500,422]].forEach(p=>lg_facet(w,p,'#7a6ad8'));
  /* the carved stone lip: soft moonlight wash, a chunky lighter rock band with a dark outer seam, then a moonlit bevel */
  fkPath(w,M);w.strokeStyle='#4a5ad0';w.globalAlpha=.14;w.lineWidth=120;w.stroke();
  w.globalAlpha=.8;w.strokeStyle='#0a0620';w.lineWidth=66;w.stroke();
  w.globalAlpha=1;w.strokeStyle=fkLin(w,0,0,0,520,['#2a2060','#3a2e7c','#433692']);w.lineWidth=60;w.stroke();
  w.strokeStyle=fkLin(w,600,0,1400,0,['#7a90f0','#5c70d8','#5466c8']);w.lineWidth=28;w.stroke();
  w.strokeStyle='#a4b6ff';w.lineWidth=13;w.stroke();w.strokeStyle='#d8e2ff';w.globalAlpha=.35;w.lineWidth=6;w.stroke();w.globalAlpha=1;
  /* notches: dark cracks cut across the lip so it reads as blocks of stone, each with a moonlit edge */
  for(let i=0;i<M.length/2;i+=4){const j=i+Math.floor(lg_r(i+77)*3),x=M[j*2],y=M[j*2+1];if(y>496)continue;let nx=(x-1000)/(382*382),ny=(y-292)/(262*262);const l=Math.hypot(nx,ny);nx/=l;ny/=l;const L=18+lg_r(j+5)*14,tx=-ny,ty=nx;
   w.strokeStyle='#0a0620';w.globalAlpha=.85;w.lineWidth=3;w.beginPath();w.moveTo(x+nx*2,y+ny*2);w.lineTo(x+nx*L+tx*(lg_r(j)-.5)*8,y+ny*L+ty*(lg_r(j)-.5)*8);w.stroke();
   w.strokeStyle='#b8c8ff';w.globalAlpha=.4;w.lineWidth=1.6;w.beginPath();w.moveTo(x+nx*3+tx*3,y+ny*3+ty*3);w.lineTo(x+nx*L*.7+tx*3,y+ny*L*.7+ty*3);w.stroke()}
  w.globalAlpha=1;w.globalCompositeOperation='destination-out';fkPath(w,M);w.fill();g.drawImage(W,0,0)}
 /* hanging roots silhouetted against the sky */
 [[700,110,120,-1],[780,62,90,1],[1090,30,70,-1],[1230,60,150,1],[1290,96,80,-1]].forEach(([x,y,L,d],i)=>{g.strokeStyle='#0c0822';g.lineWidth=3;g.beginPath();g.moveTo(x,y-10);g.bezierCurveTo(x+d*14,y+L*.3,x-d*10,y+L*.6,x+d*6,y+L);g.stroke();
  g.fillStyle='#14304a';for(let k=1;k<6;k++){const u=k/6,px=x+d*6*u+Math.sin(u*5)*d*8,py=y-10+(L+10)*u,sd=k%2?1:-1;g.save();g.translate(px,py);g.rotate(sd*.8);g.beginPath();g.ellipse(sd*6,0,7,3,0,0,TAU);g.fill();g.restore()}
  g.fillStyle='#7af4ff';g.globalAlpha=.9;g.beginPath();g.arc(x+d*6,y+L+3,2.6,0,TAU);g.fill();g.globalAlpha=1;fkGlow(g,x+d*6,y+L+3,14,'#4ae8ff',.5)});
 /* chunky dark outline where the stone lip meets the sky */
 fkPath(g,M);g.strokeStyle=FKO;g.lineWidth=7;g.stroke();
 /* an amethyst vein glowing in the back wall above the dock */
 const crev=(p,gl)=>{fkGlow(g,p[0]+(p[4]-p[0])/2,p[1],90,gl,.18);fkPath(g,p);g.fillStyle='#08041a';g.fill();g.save();fkPath(g,p);g.clip();g.translate(0,-4);fkPath(g,p);g.strokeStyle=gl;g.globalAlpha=.5;g.lineWidth=3;g.stroke();g.restore();g.globalAlpha=1};
 fkGlow(g,436,300,90,'#c07aff',.16);lg_ledge(g,[390,302,426,292,470,296,484,305,472,316,450,324,422,323,402,315],440,321,'#c8a0ff');
 lg_crys(g,432,301,.9,'#f4d8ff','#b070ff','#5a2aa0','#b070ff',[[-.5,46,9],[-.15,70,12],[.25,52,10],[.6,34,8]],2);
 fkGlow(g,562,192,70,'#4ae8ff',.16);lg_ledge(g,[528,192,556,184,590,188,600,197,588,206,562,210,538,205],566,208,'#8ae8ff');
 lg_crys(g,562,191,.6,'#d8fbff','#5ad8ff','#1a6a9a','#4ae0ff',[[-.4,40,9],[.1,60,11],[.5,36,8]],2);
 lg_crys(g,362,254,.3,'#f4d8ff','#b070ff','#5a2aa0','#b070ff',[[-.4,40,8],[.15,56,10],[.6,30,7]],1.8);lg_crys(g,516,316,.26,'#d8fff0','#3af0b8','#0e7a6a','#4affc8',[[-.3,40,8],[.2,52,10]],1.8);lg_crys(g,560,446,.3,'#d8fbff','#5ad8ff','#1a6a9a','#4ae0ff',[[-.5,36,8],[0,54,10],[.5,30,7]],1.8);
 /* far shore along the waterline */
 const FS=[300,524,300,452,342,430,380,440,412,436,470,422,505,440,540,438,600,466,650,484,720,500,820,506,920,500,1010,508,1110,502,1170,500,1210,492,1250,496,1286,476,1318,482,1352,458,1400,466,1400,524];
 lg_rock(g,FS,'#2a1f5c','#140e34',2,'#7ac8ff',.3,0,5);lg_tex(g,FS,300,420,1400,524,26,9,'#0a0620','#3a2c74');
 lg_stalag(g,384,442,16,64,'#3a2c70','#1a1240',2,'#8ab8ff');lg_stalag(g,416,446,9,34,'#3a2c70','#1a1240',2,'#8ab8ff');lg_stalag(g,596,470,12,42,'#3a2c70','#1a1240',2,'#8ab8ff');lg_stalag(g,1334,470,12,46,'#3a2c70','#1a1240',2,'#8ab8ff');
 const CY={c:['#c8fbff','#3ad8f0','#126a90'],gl:'#4ae8ff'},VI={c:['#f4dcff','#b46aff','#5a2a9e'],gl:'#c07aff'},TE={c:['#d8fff0','#3af0b8','#0e7a6a'],gl:'#4affc8'},BL={c:['#dce6ff','#5a8cff','#2a3a9e'],gl:'#6a9cff'},PK={c:['#ffe0f4','#ff6ad0','#9a2a8a'],gl:'#ff7ae0'};
 lg_mush(g,462,428,26,15,-3,CY,2);lg_mush(g,482,432,16,9,3,CY,2);lg_mush(g,664,490,18,11,-2,VI,2);lg_mush(g,1186,500,22,13,2,TE,2);lg_mush(g,1206,500,13,8,3,TE,2);lg_mush(g,1250,486,20,12,-3,BL,2);
 lg_crys(g,536,450,.55,'#f4d8ff','#b070ff','#5a2aa0','#b070ff',[[-.3,40,8],[.1,56,10],[.45,32,7]],2);lg_crys(g,1356,468,.5,'#d8fbff','#5ad8ff','#1a6a9a','#4ae0ff',[[-.35,38,8],[.05,52,10],[.4,30,7]],2);
 /* right rock column with the waterfall notch */
 const RC=[1610,-10,1610,580,1560,590,1500,572,1440,580,1390,566,1352,552,1340,512,1346,470,1332,430,1350,388,1340,346,1334,300,1346,262,1366,226,1350,190,1350,150,1372,110,1376,74,1362,-10];
 lg_rock(g,RC,'#251a52','#150e30',3.5,'#5ae0ff',.25,6,0);lg_tex(g,RC,1330,0,1610,590,30,21,'#0a0620','#3a2c74');
 /* dim facets and crystal glints on the column face */
 [[1420,152,1480,140,1530,152,1516,168,1440,172],[1530,212,1580,200,1608,212,1600,228,1546,230],[1452,286,1500,276,1534,288,1524,300,1462,302]].forEach(p=>lg_facet(g,p,'#6ac8ff'));
 lg_crys(g,1474,214,.32,'#d8fbff','#5ad8ff','#1a6a9a','#4ae0ff',[[-.4,40,8],[.1,56,10],[.5,30,7]],1.8);lg_crys(g,1580,262,.28,'#f4d8ff','#b070ff','#5a2aa0','#b070ff',[[-.3,42,8],[.25,52,10]],1.8);
 /* a chunky rock spout jutting from the column: the waterfall pours over its lip */
 {const F=LG_FALL,SP=[1390,168,1364,170,1350,182,1326,184,1310,196,1290,200,1276,212,1268,224,1278,234,1292,236,1304,246,1318,240,1334,252,1350,248,1366,262,1390,266];
  [[1312,242,7,16],[1340,250,8,22],[1362,260,6,14]].forEach(([x,y,w,h])=>lg_stal(g,x,y-4,w,h,'#3a2c70','#140c32',2.4,'#8ab8ff'));
  lg_rock(g,SP,'#3e3078','#181034',3.4,'#8ab8ff',.6,0,5);lg_tex(g,SP,1270,170,1390,262,7,27,'#0a0620','#4a3a86');
  g.save();fkPath(g,SP);g.clip();g.strokeStyle='#0a0620';g.globalAlpha=.7;g.lineWidth=2.4;g.lineCap='round';g.beginPath();g.moveTo(1300,206);g.quadraticCurveTo(1322,214,1336,232);g.moveTo(1346,190);g.quadraticCurveTo(1356,210,1352,236);g.stroke();g.restore();
  g.fillStyle='#2a8a7a';[[1296,200,7],[1312,194,6],[1328,186,8],[1350,180,6]].forEach(([x,y,r])=>{g.beginPath();g.ellipse(x,y,r,3,0,0,TAU);g.fill()});
  g.fillStyle='#9affe8';[[1300,198],[1330,184],[1352,178]].forEach(([x,y])=>{g.beginPath();g.arc(x,y,1.8,0,TAU);g.fill();fkGlow(g,x,y,10,'#4affc8',.45)});
  g.beginPath();g.ellipse(F.x,F.y0-2,13,4.5,0,0,TAU);g.fillStyle='#04020e';g.fill();g.lineWidth=2.4;g.strokeStyle=FKO;g.stroke();
  fkGlow(g,F.x,F.y0+30,80,'#4ae8ff',.22)}
 /* giant mushrooms on the right */
 lg_mush(g,1490,572,214,118,-30,TE,3.5);lg_mush(g,1404,566,112,62,-14,VI,3);lg_mush(g,1572,566,78,42,8,BL,3);lg_mush(g,1440,574,46,24,6,CY,2.6);
 lg_crys(g,1548,580,1.05,'#f4d8ff','#b070ff','#5a2aa0','#b070ff',[[-.55,44,9],[-.2,74,13],[.18,58,11],[.55,36,8]],2.6);
 /* ---- water ---- */
 g.fillStyle=fkLin(g,0,FSW_Y,0,900,['#16407a','#0c2656','#08163c','#040a22']);g.fillRect(0,FSW_Y,1600,380);
 {const R=document.createElement('canvas');R.width=1600;R.height=260;const r=R.getContext('2d');r.translate(0,260);r.scale(1,-1);r.drawImage(g.canvas,0,FSW_Y-260,1600,260,0,0,1600,260);r.setTransform(1,0,0,1,0,0);
  /* soften (downscale then upscale), fade with depth, then squash vertically and lay it down in gently wavy bands */
  const Q=document.createElement('canvas');Q.width=320;Q.height=52;Q.getContext('2d').drawImage(R,0,0,320,52);
  const B=document.createElement('canvas');B.width=1600;B.height=260;const b=B.getContext('2d');b.drawImage(Q,0,0,1600,260);
  b.globalCompositeOperation='destination-in';const m=b.createLinearGradient(0,0,0,260);m.addColorStop(0,'#000000');m.addColorStop(.45,'#00000080');m.addColorStop(1,'#00000000');b.fillStyle=m;b.fillRect(0,0,1600,260);
  const SQ=.6,DH=260*SQ;g.save();g.globalAlpha=.3;for(let y=0;y<DH;y+=3){const off=Math.sin(y*.12)*(1.2+y*.03)+Math.sin(y*.05+1)*1.5;g.drawImage(B,0,y/SQ,1600,3/SQ,off,FSW_Y+2+y,1600,3)}g.restore()}
 g.fillStyle=fkLin(g,0,FSW_Y,0,FSW_Y+260,['#0c245000','#0a1e4888','#08143ad0']);g.fillRect(0,FSW_Y,1600,260);
 /* bioluminescent bloom in the water near the glowing shores */
 fkGlow(g,1470,600,300,'#2affd0',.16);fkGlow(g,470,560,220,'#3ad8ff',.12);fkGlow(g,1000,560,380,'#3a6aff',.10);fkGlow(g,1220,540,140,'#4affc8',.12);
 /* glow streaks reflected under the mushrooms and lanterns */
 const hx=a=>Math.round(Math.max(0,Math.min(1,a))*255).toString(16).padStart(2,'0');
 const refl=(x,y,rx,ry,c,a)=>{g.save();g.translate(x,y);g.scale(1,ry/rx);const q=g.createRadialGradient(0,0,0,0,0,rx);q.addColorStop(0,c+hx(a));q.addColorStop(.45,c+hx(a*.5));q.addColorStop(1,c+'00');g.fillStyle=q;g.beginPath();g.arc(0,0,rx,0,TAU);g.fill();g.restore()};
 g.save();g.globalCompositeOperation='lighter';
 refl(1462,596,118,24,'#4affc8',.24);refl(1450,632,76,12,'#4affc8',.12);refl(1392,556,62,13,'#c07aff',.28);refl(1572,550,44,10,'#6a9cff',.24);refl(1440,536,26,6,'#4ae8ff',.26);
 refl(470,534,20,6,'#4ae8ff',.3);refl(1196,528,16,5,'#4affc8',.3);refl(1252,526,13,4,'#6a9cff',.28);refl(664,522,11,4,'#c07aff',.28);
 /* moon reflection path: a soft glowing column under the crescent, widening toward the viewer (shimmer dashes animate in back) */
 {const mx=LG_MOON.x,P=document.createElement('canvas');P.width=200;P.height=140;const m=P.getContext('2d');
  for(let y=0;y<140;y+=2){const u=y/140,hw=22+u*70,q=m.createLinearGradient(100-hw,0,100+hw,0);q.addColorStop(0,'#e8f0ff00');q.addColorStop(.35,'#e8f0ff'+hx(.16*(1-u)));q.addColorStop(.5,'#f6f8ff'+hx(.56*(1-u*.85)));q.addColorStop(.65,'#e8f0ff'+hx(.16*(1-u)));q.addColorStop(1,'#e8f0ff00');m.fillStyle=q;m.fillRect(100-hw,y,hw*2,2)}
  m.globalCompositeOperation='destination-in';const vy=m.createLinearGradient(0,0,0,140);vy.addColorStop(0,'#000');vy.addColorStop(.55,'#000c');vy.addColorStop(1,'#0000');m.fillStyle=vy;m.fillRect(0,0,200,140);
  g.drawImage(P,mx-100,FSW_Y+4);refl(mx,FSW_Y+8,54,7,'#fff6dc',.5);refl(mx,FSW_Y+30,26,30,'#f0f4ff',.16)}
 /* glowing plankton specks */
 for(let i=0;i<160;i++){const x=lg_r(i+1301)*1600,u=lg_r(i+1501),y=FSW_Y+12+u*u*370,r=.8+lg_r(i+1701)*1.6;g.globalAlpha=.25+lg_r(i+1901)*.5;g.fillStyle=lg_r(i+2101)<.6?'#5af0ff':lg_r(i+2101)<.85?'#7affd0':'#c89aff';g.beginPath();g.arc(x,y,r,0,TAU);g.fill()}
 g.globalAlpha=1;
 /* a glowing seam where the water meets the far shore */
 for(let i=0;i<64;i++){const x=300+i*17+lg_r(i+2601)*8,w=5+lg_r(i+2701)*16;g.globalAlpha=.18+lg_r(i+2801)*.35;g.fillStyle=lg_r(i+2901)<.7?'#7af4ff':'#b89aff';g.fillRect(x,FSW_Y+2+lg_r(i+3001)*5,w,1.8)}
 g.globalAlpha=1;g.restore();
 /* faint surface lines */
 g.strokeStyle='#8ad8ff';g.lineCap='round';for(let i=0;i<34;i++){const u=lg_r(i+2301),y=FSW_Y+30+u*u*330,x=lg_r(i+2401)*1600,w=30+u*90;if(x>1040&&x<1260&&y<720)continue;if(x>700&&x<1120&&y>566&&y<700)continue;g.globalAlpha=.05+u*.06;g.lineWidth=1.3;g.beginPath();g.moveTo(x-w/2,y);g.quadraticCurveTo(x,y-2-u*3,x+w/2,y);g.stroke()}g.globalAlpha=1;
 lg_fallBody(g);
 /* glowing lily pads on the right and bottom */
 LG_PADS.forEach(L=>lg_pad(g,L));
 /* ---- near frame: ceiling, stalactites, the left wall with the arch ---- */
 const CE=[-10,-10,1610,-10,1610,150,1560,118,1500,86,1430,56,1360,34,1280,22,1180,14,1080,12,980,18,880,16,790,28,700,46,630,72,560,98,480,118,400,140,330,150,-10,170];
 lg_rock(g,CE,'#0e0826','#1c1342',3.5,'#8a7cff',.45,0,-6);lg_tex(g,CE,0,0,1600,160,30,31,'#06031a','#2e2262');
 const ceil=x=>{for(let i=0;i<CE.length-2;i+=2){const ax=CE[i],ay=CE[i+1],bx=CE[i+2],by=CE[i+3];if(ax>=x&&bx<=x&&ax!==bx){const u=(x-ax)/(bx-ax);return ay+(by-ay)*u}}return 0};
 LG_STALS.forEach(([x,w,h])=>{const tip=lg_stal(g,x,ceil(x)-4,w,h,'#2a1f5c','#120a2c',3,'#9a8cff');if(h>70){fkGlow(g,tip.x,tip.y+4,14,'#7af0ff',.5);g.fillStyle='#d8fbff';g.beginPath();g.ellipse(tip.x,tip.y+3,2.4,3.4,0,0,TAU);g.fill()}});
 lg_arch(g,CY,VI,BL,PK);
 /* ---- the rock-ledge dock ---- */
 lg_dock(g,CY,VI,TE);
 /* ---- foreground rocks ---- */
 const FR=[1150,910,1190,872,1260,848,1340,836,1420,814,1500,800,1570,792,1610,786,1610,910];
 lg_rock(g,FR,'#1a1240','#0a0620',3,'#5ae0ff',.45,0,6);lg_tex(g,FR,1150,780,1610,900,12,41,'#05031a','#2a1f5c');
 lg_mush(g,1300,850,40,24,-6,PK,2.6);lg_mush(g,1328,846,24,14,4,PK,2.4);lg_crys(g,1470,812,.85,'#d8fbff','#5ad8ff','#1a6a9a','#4ae0ff',[[-.6,40,8],[-.2,66,12],[.2,50,10],[.6,30,7]],2.4);lg_mush(g,1560,800,54,30,-8,CY,2.8);
 const FL=[-10,760,90,772,170,808,214,860,240,910,-10,910];
 lg_rock(g,FL,'#1a1240','#0a0620',3,'#c07aff',.4,-4,6);lg_mush(g,60,786,36,20,4,TE,2.6);lg_mush(g,96,792,20,11,-3,TE,2.2);lg_crys(g,170,830,.6,'#f4d8ff','#b070ff','#5a2aa0','#b070ff',[[-.4,40,8],[.1,56,10],[.5,32,7]],2.2)}
const LG_STALS=[[18,30,190],[76,18,120],[150,14,70],[470,16,64],[560,22,110],[612,12,54],[700,20,96],[760,10,46],[850,16,82],[920,10,40],[990,22,118],[1052,12,52],[1180,18,90],[1236,10,44],[1300,24,140],[1372,14,70],[1450,30,180],[1520,18,110],[1580,26,150]];
const LG_PADS=[{x:1112,y:770,r:34,a:.4,f:'#4affc8'},{x:1060,y:806,r:22,a:2.2},{x:1196,y:850,r:42,a:1.6,f:'#ff7ae0'},{x:600,y:882,r:28,a:3},{x:300,y:740,r:24,a:1.1,f:'#c07aff'}];
function lg_pad(g,L){g.save();g.translate(L.x,L.y);g.scale(1,.42);g.beginPath();g.moveTo(0,0);g.arc(0,0,L.r,L.a+.32,L.a-.32+TAU);g.closePath();g.fillStyle=fkLin(g,-L.r,-L.r,L.r,L.r,['#3ac8a8','#16606a']);g.fill();g.lineWidth=3;g.strokeStyle=FKO;g.stroke();
 g.strokeStyle='#9afff040';g.lineWidth=2;for(let i=0;i<5;i++){const a=L.a+.6+i*1.1;g.beginPath();g.moveTo(0,0);g.lineTo(Math.cos(a)*L.r*.85,Math.sin(a)*L.r*.85);g.stroke()}g.restore();
 if(L.f){const s=L.r/40,x=L.x+3,y=L.y-2;fkGlow(g,x,y-8*s,44*s,L.f,.3);
  const pet=(a,l,w,c1,c2)=>{g.save();g.translate(x,y);g.rotate(a);g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(-w*s,-l*s*.55,0,-l*s);g.quadraticCurveTo(w*s,-l*s*.55,0,0);g.fillStyle=fkLin(g,0,0,0,-l*s,[c1,c2]);g.fill();g.lineWidth=2;g.strokeStyle=FKO;g.stroke();g.restore()};
  const d=shade(L.f,-.35),l=shade(L.f,.6);[-1.2,1.2,-.7,.7].forEach(a=>pet(a,20,8,d,L.f));[-.3,.3,0].forEach(a=>pet(a,26,9,L.f,l));fkGlow(g,x,y-8*s,12*s,'#ffffff',.5)}}
/* the carved rock arch on the far left */
function lg_arch(g,CY,VI,BL,PK){
 const LW=[-10,-10,250,-10,320,120,348,250,336,380,356,500,346,600,330,668,-10,690];
 lg_rock(g,LW,'#1e1546','#120a2c',3.5,'#b07aff',.32,-6,0);lg_tex(g,LW,0,0,360,680,26,51,'#06031a','#33276a');
 const cx=166,cy=300,ri=70,ro=128,top=640;
 /* the dark passage with a warm glow deep inside */
 g.save();g.beginPath();g.moveTo(cx-ri,top);g.lineTo(cx-ri,cy);g.arc(cx,cy,ri,Math.PI,0);g.lineTo(cx+ri,top);g.closePath();g.clip();
 g.fillStyle=fkLin(g,0,cy-ri,0,top,['#0a0518','#140a22','#2a1420']);g.fillRect(cx-ri,cy-ri,ri*2,top-cy+ri);
 fkGlow(g,cx,560,140,'#ff9a3a',.45);
 g.fillStyle='#ffcc70';g.beginPath();g.moveTo(cx-20,600);g.lineTo(cx-20,540);g.arc(cx,540,20,Math.PI,0);g.lineTo(cx+20,600);g.closePath();g.fill();fkGlow(g,cx,560,46,'#fff0b0',.6);
 /* steps coming down to the dock */
 for(let i=0;i<4;i++){const y=600+i*11,w=34+i*14;g.fillStyle=i%2?'#3a2a58':'#44326a';g.fillRect(cx-w,y,w*2,11);g.fillStyle='#ffb46a';g.globalAlpha=.25;g.fillRect(cx-w,y,w*2,2);g.globalAlpha=1}
 g.restore();
 /* pillars */
 const pillar=x=>{const w=58;for(let j=0;j<6;j++){const y=cy+j*57,h=57;g.fillStyle=fkLin(g,x,0,x+w,0,['#6a5a9e','#4a3c7e','#2e2458']);g.fillRect(x,y,w,h);g.lineWidth=2.5;g.strokeStyle=FKO;g.strokeRect(x,y,w,h);
   g.fillStyle='#ffffff22';g.fillRect(x+4,y+4,w*.3,3)}
  g.fillStyle='#5ae8ff';g.globalAlpha=.75;for(let j=0;j<3;j++){const y=cy+90+j*150;g.fillRect(x+w/2-2,y,4,16);g.fillRect(x+w/2-8,y+6,16,4)}g.globalAlpha=1;fkGlow(g,x+w/2,cy+200,40,'#4ae8ff',.25);
  g.fillStyle=fkLin(g,0,cy-12,0,cy+6,['#8a7abe','#4a3c7e']);g.fillRect(x-8,cy-12,w+16,16);g.lineWidth=2.5;g.strokeStyle=FKO;g.strokeRect(x-8,cy-12,w+16,16)};
 pillar(cx-ri-58);pillar(cx+ri);
 /* voussoirs */
 const n=9;for(let i=0;i<n;i++){const a0=Math.PI+i*Math.PI/n,a1=a0+Math.PI/n,key=i===4,o=key?ro+16:ro;
  g.beginPath();g.arc(cx,cy,o,a0,a1);g.arc(cx,cy,ri,a1,a0,true);g.closePath();g.fillStyle=fkLin(g,cx+Math.cos(a0)*ro,cy+Math.sin(a0)*ro,cx+Math.cos(a1)*ri,cy+Math.sin(a1)*ri,key?['#9a8ad0','#5a4a90']:['#7a6ab0','#3e3272']);g.fill();g.lineWidth=2.8;g.strokeStyle=FKO;g.stroke();
  g.save();g.clip();g.strokeStyle='#ffffff30';g.lineWidth=3;g.beginPath();g.arc(cx,cy,o-4,a0+.03,a1-.03);g.stroke();g.restore()}
 /* the keystone fish rune */
 {const kx=cx,ky=cy-ro+18;fkGlow(g,kx,ky,46,'#4ae8ff',.5);g.save();g.translate(kx,ky);g.strokeStyle='#bff8ff';g.lineWidth=3;g.beginPath();g.ellipse(0,0,13,7,0,0,TAU);g.moveTo(-12,0);g.lineTo(-21,-7);g.lineTo(-21,7);g.closePath();g.stroke();g.fillStyle='#bff8ff';g.beginPath();g.arc(6,-1,1.8,0,TAU);g.fill();g.restore()}
 /* chains and lanterns hanging inside the arch */
 g.strokeStyle='#1a1020';g.lineWidth=2.4;[[118,252],[214,252]].forEach(([x,y])=>{for(let k=0;k<5;k++){g.beginPath();g.ellipse(x,y+k*8,2.4,4.2,0,0,TAU);g.stroke()}});
 lg_lantern(g,LG_LANT[0].x,LG_LANT[0].y,LG_LANT[0].s);lg_lantern(g,LG_LANT[1].x,LG_LANT[1].y,LG_LANT[1].s);
 /* glowing moss and vines draping over the arch */
 g.strokeStyle='#1e5a52';g.lineWidth=2.6;for(let i=0;i<9;i++){const a=Math.PI*1.08+i*.11,x=cx+Math.cos(a)*(ro+6),y=cy+Math.sin(a)*(ro+6),L=30+lg_r(i+71)*70;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+6,y+L*.5,x+(lg_r(i)-.5)*10,y+L);g.stroke();
  for(let k=0;k<3;k++){const yy=y+L*(.4+k*.28);g.fillStyle=k===2?'#9affe8':'#3aa890';g.beginPath();g.arc(x+(lg_r(i)-.5)*10*(k/2),yy,k===2?3:2.2,0,TAU);g.fill()}}
 /* mushrooms crowning the arch and at its feet */
 lg_mush(g,250,196,46,28,6,BL,2.8);lg_mush(g,280,214,26,15,8,VI,2.4);lg_mush(g,214,180,22,12,-4,CY,2.2);
 lg_mush(g,26,640,62,34,-6,CY,3);lg_mush(g,62,646,32,18,4,VI,2.6);lg_mush(g,312,630,40,22,6,PK,2.6)}
/* the rock ledge with planks and rope where the hero stands (same footprint as the pond dock) */
function lg_dock(g,CY,VI,TE){const D=FSDOCK;
 /* rock ledge under the left half */
 const RL=[-10,604,90,598,200,612,320,624,392,648,416,690,378,734,300,762,180,774,60,782,-10,790];
 lg_rock(g,RL,'#3a2c6e','#140c30',3.5,'#7ae0ff',.5,0,6);lg_tex(g,RL,0,600,420,790,16,61,'#06031a','#4a3a86');
 /* glowing moss on the ledge face */
 for(let i=0;i<26;i++){const x=40+lg_r(i+81)*340,y=690+lg_r(i+82)*70;g.globalAlpha=.6;g.fillStyle=lg_r(i+83)<.5?'#4affc8':'#5ae8ff';g.beginPath();g.arc(x,y,1.4+lg_r(i+84)*2,0,TAU);g.fill()}g.globalAlpha=1;
 lg_mush(g,372,722,24,14,4,TE,2.4);lg_mush(g,352,730,14,8,-2,TE,2);
 lg_crys(g,250,770,.55,'#d8fbff','#5ad8ff','#1a6a9a','#4ae0ff',[[-.5,36,8],[0,52,10],[.45,30,7]],2.2);
 /* water lapping the rock */
 g.strokeStyle='#9af6ff';g.globalAlpha=.35;g.lineWidth=2;g.beginPath();g.moveTo(170,786);g.quadraticCurveTo(300,776,400,712);g.stroke();g.globalAlpha=1;
 /* wooden posts wrapped in rope */
 [430,512,596].forEach((x,i)=>{const h=96-(i%2)*18;g.fillStyle=fkLin(g,x-9,0,x+9,0,['#6a4a2e','#2e1c10']);g.fillRect(x-9,D.y,18,h);g.lineWidth=2.5;g.strokeStyle=FKO;g.strokeRect(x-9,D.y,18,h);
  g.strokeStyle='#c8a46a';g.lineWidth=2.4;for(let k=0;k<3;k++){g.beginPath();g.moveTo(x-9,D.y+22+k*6);g.lineTo(x+9,D.y+26+k*6);g.stroke()}
  g.save();g.globalCompositeOperation='lighter';g.strokeStyle='#7af0ff';g.globalAlpha=.35;g.lineWidth=2;g.beginPath();g.ellipse(x,D.y+h-4,18,4,0,0,TAU);g.stroke();g.restore()});
 /* deck planks */
 g.beginPath();g.moveTo(D.x0-20,D.y-30);g.lineTo(D.x1,D.y-22);g.lineTo(D.x1+8,D.y+8);g.lineTo(D.x0-20,D.y+14);g.closePath();g.fillStyle=fkLin(g,0,D.y-30,0,D.y+14,['#9a6e48','#5e3e26']);g.fill();g.lineWidth=3;g.strokeStyle=FKO;g.stroke();
 g.save();g.clip();g.strokeStyle='#2e1c12';g.lineWidth=1.6;for(let i=1;i<14;i++){const x=D.x0-20+i*(D.x1-D.x0+20)/14;g.beginPath();g.moveTo(x,D.y-30+i*.6);g.lineTo(x+2,D.y+12);g.stroke()}
 for(let i=0;i<14;i++){const x=D.x0-12+i*(D.x1-D.x0+20)/14;g.fillStyle='#ffffff18';g.fillRect(x,D.y-24+i*.6,10,2);g.fillStyle='#1a1008';g.beginPath();g.arc(x+12,D.y-20+i*.6,1.2,0,TAU);g.arc(x+12,D.y+6,1.2,0,TAU);g.fill()}
 g.fillStyle='#7af0ff';g.globalAlpha=.08;g.fillRect(D.x0-20,D.y-30,D.x1-D.x0+30,10);g.restore();g.globalAlpha=1;
 g.strokeStyle='#ffffff28';g.lineWidth=2;g.beginPath();g.moveTo(D.x0-18,D.y-27);g.lineTo(D.x1-2,D.y-19);g.stroke();
 g.fillStyle='#3a2414';g.beginPath();g.moveTo(D.x0-20,D.y+14);g.lineTo(D.x1+8,D.y+8);g.lineTo(D.x1+8,D.y+24);g.lineTo(D.x0-20,D.y+30);g.closePath();g.fill();g.lineWidth=2.5;g.strokeStyle=FKO;g.stroke();
 /* rope lashings across the deck edge */
 g.strokeStyle='#d8b878';g.lineWidth=2.4;[200,330,460].forEach(x=>{g.beginPath();g.moveTo(x,D.y+11);g.lineTo(x+6,D.y+27);g.moveTo(x+6,D.y+11);g.lineTo(x,D.y+27);g.stroke()});
 /* coiled rope and a bucket of glowing tetras */
 g.save();g.translate(176,628);g.scale(1,.42);g.lineWidth=5;[16,11,6].forEach(r=>{g.strokeStyle=FKO;g.beginPath();g.arc(0,0,r,0,TAU);g.stroke()});g.lineWidth=3;g.strokeStyle='#d8b878';[16,11,6].forEach(r=>{g.beginPath();g.arc(0,0,r,0,TAU);g.stroke()});g.restore();
 {const x=226,y=630;g.beginPath();g.moveTo(x-15,y-28);g.lineTo(x+15,y-28);g.lineTo(x+12,y);g.lineTo(x-12,y);g.closePath();g.fillStyle=fkLin(g,x-15,0,x+15,0,['#8a5a32','#4a2c16']);g.fill();g.lineWidth=2.6;g.strokeStyle=FKO;g.stroke();
  g.strokeStyle='#3a3a4a';g.lineWidth=2.4;g.beginPath();g.moveTo(x-14,y-19);g.lineTo(x+14,y-19);g.moveTo(x-12,y-6);g.lineTo(x+12,y-6);g.stroke();
  g.beginPath();g.ellipse(x,y-28,15,4.5,0,0,TAU);g.fillStyle='#0e5a7a';g.fill();g.lineWidth=2;g.strokeStyle=FKO;g.stroke();fkGlow(g,x,y-30,30,'#4ae8ff',.55);
  g.fillStyle='#bff8ff';[[-6,-29],[3,-27],[7,-30]].forEach(([dx,dy])=>{g.beginPath();g.ellipse(x+dx,y+dy,2.4,1,0,0,TAU);g.fill()});
  g.strokeStyle='#2a1a10';g.lineWidth=2;g.beginPath();g.moveTo(x-15,y-28);g.quadraticCurveTo(x,y-50,x+15,y-28);g.stroke()}
 /* lantern posts and the rope rail */
 [[D.x0+110],[D.x1-12]].forEach(([x])=>{g.fillStyle=fkLin(g,x-7,0,x+7,0,['#7a4e2c','#3a2414']);g.fillRect(x-7,D.y-120,14,110);g.lineWidth=2.5;g.strokeStyle=FKO;g.strokeRect(x-7,D.y-120,14,110);
  g.strokeStyle='#d8b878';g.lineWidth=2.2;for(let k=0;k<3;k++){g.beginPath();g.moveTo(x-7,D.y-40+k*5);g.lineTo(x+7,D.y-37+k*5);g.stroke()}});
 g.strokeStyle=FKO;g.lineWidth=5;g.beginPath();g.moveTo(D.x0+110,D.y-96);g.quadraticCurveTo((D.x0+D.x1)/2+50,D.y-60,D.x1-12,D.y-96);g.stroke();
 g.strokeStyle='#d8b878';g.lineWidth=3;g.stroke();
 lg_lantern(g,LG_LANT[2].x,LG_LANT[2].y,LG_LANT[2].s);lg_lantern(g,LG_LANT[3].x,LG_LANT[3].y,LG_LANT[3].s)}
/* ---------- cached sprites for the live layers ---------- */
function lg_init(){const S={gc:lg_spr('#4ae8ff'),mc:lg_mote('#7af4ff'),mv:lg_mote('#d29aff'),mg:lg_mote('#9affd0'),mp:lg_mote('#ff9ae6')};
 /* the big breathing glows are made at the exact size they are drawn (a 1:1 blit costs well under half of an upscaled one):
    moon, mushrooms; the lantern halos flicker in size through 5 pre-made steps */
 S.gp=[['#fff2c8',LG_MOON.x,LG_MOON.y,120],['#3affc0',1458,392,150],['#b070ff',1390,452,90],['#4ae8ff',250,150,70],['#4ae8ff',22,578,80],['#b070ff',430,264,80]].map(([c,x,y,r])=>({c:lg_spr(c,r*2),x:x-r,y:y-r}));
 S.lw=[70,95].map(R=>[0,1,2,3,4].map(q=>lg_spr('#ffa040',2*Math.round(R*(.7+.075*q)))));
 /* waterfall sheet: soft streaks, 2H tall and repeating every H so it can scroll smoothly with one draw */
 {const F=LG_FALL,H=F.y1-F.y0,W=F.w1*2+8,c=document.createElement('canvas');c.width=W;c.height=H*2;const g=c.getContext('2d');
  for(let i=0;i<9;i++){const x=6+lg_r(i+2901)*(W-12),w=5+lg_r(i+2951)*6;g.fillStyle='#bff8ff';g.globalAlpha=.08;g.fillRect(x-w/2,0,w,H*2)}g.globalAlpha=1;
  for(let i=0;i<44;i++){const x=4+lg_r(i+3001)*(W-8),y=lg_r(i+3101)*H,l=60+lg_r(i+3201)*140,w=1.2+lg_r(i+3301)*2.4,col=lg_r(i+3401)<.78?'#effeff':'#dccfff',a=.35+lg_r(i+3501)*.45;
   [-H,0,H,2*H].forEach(o=>{const q=g.createLinearGradient(0,y+o,0,y+o+l);q.addColorStop(0,col+'00');q.addColorStop(.55,col+lg_hx(a));q.addColorStop(1,col+'00');g.fillStyle=q;g.fillRect(x-w/2,y+o,w,l)})}
  g.globalCompositeOperation='destination-in';const m=g.createLinearGradient(0,0,W,0);m.addColorStop(0,'#0000');m.addColorStop(.3,'#000');m.addColorStop(.7,'#000');m.addColorStop(1,'#0000');g.fillStyle=m;g.fillRect(0,0,W,H*2);S.fall=c;S.mist=lg_spr('#dff6ff',64)}
 /* glowworm threads hanging from the ceiling */
 S.thr=[0,1].map(k=>{const c=document.createElement('canvas');c.width=260;c.height=240;const g=c.getContext('2d');
  for(let i=0;i<9;i++){const x=10+i*27+lg_r(i+k*40+3501)*14,L=36+lg_r(i+k*40+3601)*150;g.strokeStyle='#b8f0ff';g.globalAlpha=.22;g.lineWidth=1;g.beginPath();g.moveTo(x,0);g.lineTo(x,L);g.stroke();
   for(let j=0;j<4;j++){const y=L*(.35+j*.216),r=j===3?3.4:1.5;const q=g.createRadialGradient(x,y,0,x,y,r*2.4);q.addColorStop(0,'#ffffff');q.addColorStop(.3,'#7af4ff');q.addColorStop(1,'#7af4ff00');g.globalAlpha=j===3?.95:.55;g.fillStyle=q;g.beginPath();g.arc(x,y,r*2.4,0,TAU);g.fill()}}
  return c});
 /* glowbulb reeds (two clusters), drawn with a gentle skew sway */
 S.reed=[0,1].map(k=>{const c=document.createElement('canvas');c.width=170;c.height=170;const g=c.getContext('2d');g.lineCap='round';g.lineJoin='round';const n=k?6:8;
  for(let i=0;i<n;i++){const bx=30+i*(110/n)+lg_r(i+k*20+3801)*10,h=60+lg_r(i+k*20+3901)*90,lean=(lg_r(i+k*20+4001)-.5)*30,tx=bx+lean,ty=168-h;
   g.strokeStyle=FKO;g.lineWidth=5;g.beginPath();g.moveTo(bx,170);g.quadraticCurveTo(bx+lean*.2,170-h*.5,tx,ty);g.stroke();g.strokeStyle=i%2?'#1e5a5a':'#2a7068';g.lineWidth=2.6;g.stroke();
   if(i%2===0){g.fillStyle='#1e5a52';g.beginPath();g.moveTo(bx,170);g.quadraticCurveTo(bx-14,150-h*.3,bx-18+lean*.3,170-h*.55);g.quadraticCurveTo(bx-4,160-h*.25,bx+3,170);g.fill();g.lineWidth=1.6;g.strokeStyle=FKO;g.stroke()}
   if(i%3!==1){const col=i%3?'#4affc8':'#7af4ff',r=4.5+lg_r(i+k*20+4101)*2.5;const q=g.createRadialGradient(tx,ty,0,tx,ty,r*3.4);q.addColorStop(0,col+'aa');q.addColorStop(1,col+'00');g.fillStyle=q;g.beginPath();g.arc(tx,ty,r*3.4,0,TAU);g.fill();
    g.beginPath();g.ellipse(tx,ty,r*.8,r*1.15,lean*.01,0,TAU);g.fillStyle=fkRad(g,tx,ty,r*1.1,['#ffffff',col,shade(col,-.35)]);g.fill();g.lineWidth=1.8;g.strokeStyle=FKO;g.stroke()}}
  return c});
 return S}
const LG_REEDS=[[668,724,1],[1050,896,.9]];
/* a little bat silhouette */
function lg_bat(g,x,y,s,f){g.save();g.translate(x,y);g.scale(s,s);g.fillStyle='#0a0620';g.beginPath();g.moveTo(0,-2);g.quadraticCurveTo(-6,-6-f*6,-14,-3-f*9);g.quadraticCurveTo(-11,1,-9,2);g.quadraticCurveTo(-5,0,-3,3);g.lineTo(0,2);g.lineTo(3,3);g.quadraticCurveTo(5,0,9,2);g.quadraticCurveTo(11,1,14,-3-f*9);g.quadraticCurveTo(6,-6-f*6,0,-2);g.fill();g.beginPath();g.ellipse(0,0,2.4,3.4,0,0,TAU);g.fill();g.restore()}
/* twinkle positions inside the cave mouth */
const LG_TW=[[812,128],[948,96],[1060,224],[1288,300],[884,280]];
FSLOCART.grotto={
 bg:lg_bg,
 back(g,t){if(!lg_S)lg_S=lg_init();const S=lg_S;
  LG_TW.forEach(([x,y],i)=>fkSpark(g,x,y,3+lg_r(i+7)*3,'#f4f0ff',.25+.6*Math.max(0,Math.sin(t*(1.1+lg_r(i)*1.4)+i*2))));
  /* bats crossing the cave mouth */
  for(let i=0;i<2;i++){const p=((t*.045+i*.55)%1),x=1360-p*700,y=170+i*90+Math.sin(p*TAU*2+i)*30;if(p>.02&&p<.98)lg_bat(g,x,y,.8+i*.25,Math.sin(t*14+i*2)*.5+.5)}
  /* glowbulb reeds swaying */
  LG_REEDS.forEach(([x,y,sc],i)=>{g.save();g.translate(x,y);g.scale(sc,sc);g.transform(1,0,Math.sin(t*1.1+i*2)*.05,1,0,0);g.drawImage(S.reed[i],-85,-170);g.restore()});
  g.save();g.globalCompositeOperation='lighter';
  const gl=(s,x,y,r,a)=>{g.globalAlpha=Math.max(0,Math.min(1,a));g.drawImage(s,x-r,y-r,r*2,r*2)};
  const gp=(i,a)=>{const G=S.gp[i];g.globalAlpha=Math.max(0,Math.min(1,a));g.drawImage(G.c,G.x,G.y)};
  gp(0,.18+.06*Math.sin(t*.7));
  /* waterfall: two scrolling copies of the sheet */
  /* waterfall: streaks scroll smoothly down inside the tapered sheet, glints slide down, mist puffs rise and rings spread from the splash */
  {const F=LG_FALL,H=F.y1-F.y0,o=(t*165)%H,w=S.fall.width;g.save();lg_fallPath(g,1.05,F.y1-6);g.clip();g.globalAlpha=.9;g.drawImage(S.fall,0,H-o,w,H,F.x-w/2,F.y0,w,H);g.restore();
   for(let i=0;i<2;i++){const p=(t*.7+i*.5)%1,u=p,hw=F.w0+(F.w1-F.w0)*u;gl(S.mc,F.x+(i?.45:-.4)*hw,F.y0+p*(H-10),7,Math.sin(p*Math.PI)*.9)}
   for(let i=0;i<3;i++){const p=(t*.42+i/3)%1;gl(S.mist,F.x+(i-1)*15+Math.sin(t*.8+i*2)*5,F.y1-6-p*48,15+p*28,Math.sin(p*Math.PI)*.34)}
   gl(S.gc,F.x,F.y1+2,56+5*Math.sin(t*4),.4);
   g.lineWidth=1.8;for(let i=0;i<2;i++){const p=(t*.55+i*.5)%1,r=20+p*62;g.globalAlpha=(1-p)*.55;g.strokeStyle='#9af6ff';g.beginPath();g.ellipse(F.x,F.y1+9,r,r*.25,0,0,TAU);g.stroke()}
   g.globalCompositeOperation='source-over';g.fillStyle='#f4feff';for(let i=0;i<3;i++){const ph=t*2.2+i*2.1;g.globalAlpha=.75;g.beginPath();g.ellipse(F.x+(i-1)*16+Math.sin(ph)*3,F.y1-1+Math.sin(ph*1.3)*1.5,9+Math.sin(ph)*2,4.2,0,0,TAU);g.fill()}
   g.globalCompositeOperation='lighter'}
  /* mushroom glows breathing */
  gp(1,.12+.06*Math.sin(t*1.1));gp(2,.24+.1*Math.sin(t*1.4+1));gp(3,.22+.1*Math.sin(t*1.3+2));gp(4,.2+.1*Math.sin(t*1.2+3));gp(5,.16+.08*Math.sin(t*.9+4));
  /* lanterns flicker */
  LG_LANT.forEach((L,i)=>{const f=.85+.15*Math.sin(t*9+i*7)*Math.sin(t*5.3+i),h=S.lw[i<2?0:1][Math.max(0,Math.min(4,Math.round((f-.7)/.075)))],r=h.width/2;g.globalAlpha=.42*f;g.drawImage(h,L.x-r,L.y-4-r)});
  /* moonlight shimmer on the water */
  g.fillStyle='#f2f6ff';for(let i=0;i<5;i++){const u=(i+.5)/5,y=FSW_Y+12+u*112,w=(12+u*34)*(.55+.45*Math.sin(t*1.3+i*1.7)),x=LG_MOON.x+Math.sin(t*.9+i*2.3)*(3+u*12);g.globalAlpha=(.62-u*.3)*(.4+.6*Math.max(0,Math.sin(t*2+i*1.3)));g.beginPath();g.ellipse(x,y,w/2,1.2+u*.9,0,0,TAU);g.fill()}
  /* bioluminescent ripple rings */
  g.lineWidth=1.6;for(let i=0;i<4;i++){const p=(t*.2+i*.25)%1,x=640+lg_r(i+70)*640,y=600+lg_r(i+71)*210,r=10+p*64;g.globalAlpha=(1-p)*.4;g.strokeStyle=i%2?'#7af4ff':'#9affd8';g.beginPath();g.ellipse(x,y,r,r*.28,0,0,TAU);g.stroke()}
  /* light motes floating over the water */
  const ms=[S.mc,S.mg,S.mv];for(let i=0;i<6;i++){const x=200+lg_r(i+91)*1300+Math.sin(t*.4+i*1.7)*50,y=560+lg_r(i+92)*260+Math.sin(t*.7+i)*14,a=.4+.6*Math.max(0,Math.sin(t*1.3+i*2.1)),s=16+lg_r(i+93)*14;g.globalAlpha=a;g.drawImage(ms[i%3],x-s/2,y-s/2,s,s)}
  g.restore()},
 front(g,t){if(!lg_S)lg_S=lg_init();const S=lg_S;
  /* glowworm threads swaying from the ceiling */
  g.save();g.translate(560,60);g.rotate(Math.sin(t*.5)*.012);g.drawImage(S.thr[0],0,0);g.restore();
  g.save();g.translate(1205,24);g.rotate(Math.sin(t*.45+1)*.012);g.drawImage(S.thr[1],0,0,200,185);g.restore();
  g.save();g.globalCompositeOperation='lighter';
  /* drifting glowing spores */
  const ms=[S.mc,S.mg,S.mv,S.mp];for(let i=0;i<18;i++){const sp=10+lg_r(i+501)*16,yy=(lg_r(i+502)*700-t*sp)%700,y=(yy<0?yy+700:yy)+180,x=lg_r(i+503)*1600+Math.sin(t*.6+i*1.9)*30,a=.35+.55*Math.max(0,Math.sin(t*1.1+i*2.7)),s=8+lg_r(i+504)*12;g.globalAlpha=a;g.drawImage(ms[i%4],x-s/2,y-s/2,s,s)}
  g.restore();g.globalAlpha=1;
  /* water drips from stalactite tips, with a ring where they land */
  [[700,LG_STALS[6]],[990,LG_STALS[10]],[1180,[0,0,56]]].forEach(([x,st],i)=>{const per=3.4+i*.9,p=((t+i*1.3)%per)/per*per,y0=46+st[2],land=[600,640,592][i],fall=Math.sqrt(2*(land-y0)/900);
   if(p<fall){const y=y0+450*p*p;g.fillStyle='#d8fbff';g.globalAlpha=.85;g.beginPath();g.moveTo(x,y-7);g.quadraticCurveTo(x+3.4,y,x,y+3);g.quadraticCurveTo(x-3.4,y,x,y-7);g.fill()}
   else if(p<fall+1){const q=p-fall,r=4+q*30;g.strokeStyle='#bff8ff';g.globalAlpha=(1-q)*.6;g.lineWidth=1.6;g.beginPath();g.ellipse(x,land,r,r*.28,0,0,TAU);g.stroke()}});
  g.globalAlpha=1}};
