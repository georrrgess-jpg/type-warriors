/* ===== CASINO 9.8: Penalty Kings, the game (96zs) =====
   Screen: the stadium canvas (1080 x 600) with the tell chip and the kick label over it; the Golden Boot ladder on the right (ten
   rungs, ball = a kick you take, glove = a kick you face) with Cash out under it; along the bottom the three opponents (each with
   its own ladder), the bet bar, the main button and the message line.
   Flow: Kick off (takes the stake) -> kick 1 SHOOT: read the tell, pick a spot (click, or Q W E / A S D), stop the power needle
   (click or Space) -> the ball flies, the keeper dives, GOAL / SAVED / OFF THE BAR -> a win climbs a rung; then "Next kick" or
   "Cash out" -> kick 2 SAVE: the monster runs up showing its tell; dive (click a third of the goal, or arrow keys / A S D) before
   the strike -> SAVED / MISSED / GOAL ... kick 10 is the Golden Boot. A lost kick loses the stake. Payout capped at PK_CAP.
   The stake is taken (and saved) before any kick; the Lobby button is locked during a run, like every ladder game. */
ICON.pk='<svg viewBox="0 0 64 64"><rect x="6" y="14" width="52" height="30" rx="3" fill="none" stroke="#fff" stroke-width="4"/><path d="M10 18h44M10 26h44M10 34h44M18 16v26M30 16v26M42 16v26" stroke="#c8d0ff" stroke-width="1.4" opacity=".7"/><circle cx="40" cy="48" r="11" fill="#fff" stroke="#12081f" stroke-width="3"/><path d="M40 42l4 3-1.5 5h-5L36 45z" fill="#2a2460"/><path d="M14 52l12-8" stroke="#ffd45a" stroke-width="3" stroke-dasharray="3 3"/></svg>';
GAMES.splice(Math.max(0,GAMES.findIndex(g=>g.id==='pz'))+1,0,{id:'pk',n:'Penalty Kings',d:'NEW · A penalty shoot-out against monster keepers. Shoot, then save. Every kick you win climbs the Golden Boot ladder; cash out between any two kicks. Max payout 20,000 per round.',m:(e,t)=>mPK(e,t)});
const PKIC={ball:'<svg viewBox="0 0 24 24" width="18" height="18"><circle cx="12" cy="12" r="10" fill="#fff" stroke="#12081f" stroke-width="2"/><path d="M12 7l4 3-1.5 4.5h-5L8 10z" fill="#2a2460"/></svg>',glove:'<svg viewBox="0 0 24 24" width="18" height="18"><path d="M6 11V6a1.5 1.5 0 0 1 3 0v4V4.5a1.5 1.5 0 0 1 3 0V10V5a1.5 1.5 0 0 1 3 0v6l1-2a1.5 1.5 0 0 1 2.6 1.5L16 16a5 5 0 0 1-4.5 3H11a5 5 0 0 1-5-5z" fill="#ffd45a" stroke="#12081f" stroke-width="1.6"/></svg>'};
const PKYOU={id:'you',n:'You',kit:'#ffc23a',kit2:'#c0820a',num:1};
const PKFX={audio:true};
function pkNoise(dur,f0,f1,q,vol,att){try{if(!ac||!sg||ST.svol<=0)return;const s=ac.createBufferSource();s.buffer=noiseBuf();const bp=ac.createBiquadFilter();bp.type='bandpass';bp.Q.value=q||1;const n=ac.currentTime;bp.frequency.setValueAtTime(f0,n);bp.frequency.linearRampToValueAtTime(f1||f0,n+dur);
 const gn=ac.createGain();gn.gain.setValueAtTime(0,n);gn.gain.linearRampToValueAtTime(vol,n+(att||.02));gn.gain.linearRampToValueAtTime(0,n+dur);s.connect(bp);bp.connect(gn);gn.connect(sg);s.start(n);s.stop(n+dur+.05)}catch(e){}}
function pkSfx(k){try{switch(k){
 case 'whistle':beep(2700,.09,'sine',.25);setTimeout(()=>beep(2900,.22,'sine',.25),120);break;
 case 'kick':beep(80,.12,'square',.35);pkNoise(.08,900,300,1,.25);break;
 case 'net':pkNoise(.35,2600,900,.8,.3);break;
 case 'roar':pkNoise(1.6,700,1200,.5,.32,.25);setTimeout(()=>pkNoise(1.1,900,600,.6,.2,.1),500);break;
 case 'groan':pkNoise(.9,500,250,.7,.22,.15);beep(180,.4,'sawtooth',.06);break;
 case 'clang':beep(1450,.18,'triangle',.4);setTimeout(()=>beep(2180,.22,'triangle',.25),20);break;
 case 'glove':beep(220,.08,'square',.3);pkNoise(.12,1400,600,1.2,.3);break;
 case 'tick':beep(1500,.03,'square',.08);break;
 case 'step':beep(880,.06,'triangle',.3);setTimeout(()=>beep(1320,.1,'triangle',.3),70);break}}catch(e){}}
function mPK(el,tok){
 const alive=()=>CAS.tok===tok,rm=matchMedia('(prefers-reduced-motion: reduce)').matches,S0=pkStats();
 let opp=pkOpp(S0.opp),L=pkLadder(opp.id),ph='idle',bet=0,step=0,kick=1,tell=null,pick=null,needle=0,ndir=1,nsp=.9,anim=null,banner=null,conf=[],flash=0,shake=0,cheer=0,hov=null,last=performance.now(),t=0,dive=null,runT=0,firstRun=!S0.seen,rs=[],fx=[],lb=-1;
 el.innerHTML=`<div class="pkw pk2">
  <div class="pktop"><div class="pktell off" id="pktell"><i></i><span><b id="pktellb"></b><small id="pktella"></small></span><em title="A tell is right most of the time, not every time">i</em></div><div class="pkkick" id="pkkl"></div><div class="pksbd" id="pksbd"></div></div>
  <div class="pkst"><canvas id="pkc" width="${PKSW}" height="${PKSH}"></canvas><div class="pkhint" id="pkhint"></div><div class="pksteps" id="pksteps"></div></div>
  <div class="pkside">
   <div class="pkkc"><canvas id="pkkp" width="150" height="150"></canvas><div class="pkkn"><b id="pkkname"></b><i class="pkdf" id="pkkst"></i><small id="pkksub"></small></div>
    <div class="pkset" id="pkset"><div class="pkseti"><button id="pkprev" aria-label="Previous keeper">‹</button><span><b>Round setup</b><small class="u">Change keeper</small><small class="l">Locked during round</small></span><button id="pknext" aria-label="Next keeper">›</button></div><em id="pkktop"></em></div></div>
   <div class="pkbetb"><div class="pkbb"><div><small>Your bet</small><b><i class="pkcn"></i><span id="pkyb">0</span></b></div><div><small>If successful</small><b><i class="pkcn"></i><span id="pkif">0</span><u id="pkifm">×1</u></b></div></div><p class="pkcap">Max return per round: <b>${cmn(PK_CAP)}</b></p></div>
   <div class="pkstg"><div class="pkstgh"><b id="pkstgt">Next stages</b><button id="pkfull">View full ladder</button></div><div class="pklad" id="pklad"></div></div>
   <div class="pkspot"><div><small id="pksptl">Selected spot</small><b id="pkspt">–</b></div><div class="pkmini" id="pkmini">${'<i></i>'.repeat(6)}</div></div>
   <div class="pkbtns"><button class="pkco" id="pkco" disabled><b>Cashout</b><small id="pkcov">Available after a successful kick</small></button><button class="bbig pkgob" id="pkgo">Kick off</button></div>
  </div>
  <div class="pkbot"><div class="pkleft"><div class="pkstat" id="pkstat"></div><p class="cmsg" id="cm"> </p></div><div class="pkmid"><div class="ctl">${betBar()}</div></div></div>
 </div>`;
 const cv=$('pkc'),g=cv.getContext('2d');g.lineJoin=g.lineCap='round';
 const cap=()=>PK_CAP;CAS.cap=PK_BET[1];
 /* ---------- side panel ---------- */
 const gv=m=>Math.min(PK_CAP,Math.floor((ph==='idle'||ph==='over'?Math.min(PK_BET[1],CAS.bet||0):bet)*m));
 const KEYS=[['Q','W','E'],['A','S','D']],SPOTN=[['Top left','Top middle','Top right'],['Low left','Low middle','Low right']];let full=false,sph='';
 const ladder=()=>{const box=$('pklad');if(!box)return;const idle=ph==='idle'||ph==='over',b0=idle?Math.min(PK_BET[1],CAS.bet||0):bet,cur=idle?1:Math.min(PK_KICKS,step+1),capK=L.findIndex(m=>Math.floor(b0*m)>=PK_CAP)+1;
  const row=k=>{const m=L[k-1],v=gv(m),now=k===cur&&!idle,cls=k<=step?'done':now?'next':'';return `<div class="pkr ${cls}${k===PK_KICKS?' boot':''}" data-k="${k}"><i class="pki ${pkKind(k)}">${pkKind(k)==='shoot'?PKIC.ball:PKIC.glove}</i><span>${k===PK_KICKS?'Kick 10 · Golden Boot':'Kick '+k}${now?' <em>(this kick)</em>':''}${k<=step?' <em class="ok">✓</em>':''}</span><u class="${v>=PK_CAP?'mx':''}"><i class="pkcn"></i>${cmn(v)}</u><b>×${m}</b></div>`};
  let h='';if(full){for(let k=1;k<=PK_KICKS;k++)h+=row(k)}else{let k=cur,n=0;for(;k<=PK_KICKS&&n<5&&!(capK&&k>=capK);k++,n++)h+=row(k);
   if(capK&&k>=capK)h+=`<div class="pkr cap"><span>Kick ${capK}${capK<PK_KICKS?'+':''}</span><u class="mx">Capped at ${cmn(PK_CAP)}</u><b>Final ×${L[PK_KICKS-1]}</b></div>`;
   else if(k<=PK_KICKS)h+=`<div class="pkr cap"><span>Kick ${k}${k<PK_KICKS?'–10':''}</span><u>up to <i class="pkcn"></i>${cmn(gv(L[PK_KICKS-1]))}</u><b>Final ×${L[PK_KICKS-1]}</b></div>`}
  box.innerHTML=h;$('pkstgt').innerHTML=`${full?'Full ladder':'Next stages'} <small>(${cmn(b0)} bet)</small>`;$('pkfull').textContent=full?'Next stages':'View full ladder';
  const nm=L[cur-1];$('pkyb').textContent=cmn(b0);$('pkif').textContent=cmn(gv(nm));$('pkifm').textContent='×'+nm;
  const v=step?Math.min(cap(),Math.floor(bet*L[step-1])):0,co=$('pkco');$('pkcov').textContent=step?'Take '+cmn(v)+' · ×'+L[step-1]:'Available after a successful kick';co.disabled=!(ph==='between'&&step>0)};
 const stats=()=>{const s=pkStats(),e=$('pkstat');if(e)e.innerHTML=`<span><b>${s.goals}</b> goals</span><span><b>${s.saves}</b> saves</span><span><b>${s.best}</b> best run</span><span><b>${s.boots}</b> Golden Boots</span>`};
 const showTellIdle=()=>{if(!tell)showTell()};
 const opps=()=>{const o=opp,df=PK_OPP.indexOf(o)+1,c=$('pkkp').getContext('2d');c.clearRect(0,0,150,150);c.lineJoin=c.lineCap='round';const gr=c.createRadialGradient(75,70,6,75,70,78);gr.addColorStop(0,pkMix(o.col,'#ffffff',.3));gr.addColorStop(1,'rgba(0,0,0,0)');c.fillStyle=gr;c.fillRect(0,0,150,150);
  c.save();c.translate(75,262);c.scale(1.18,1.18);pkRigDraw(c,pkKeeperPose(0,0,{st:'ready'},.4),o,.4,false);c.restore();
  $('pkkname').textContent=o.n;$('pkkst').textContent='★'.repeat(df)+'☆'.repeat(3-df);$('pkksub').textContent=o.t;$('pkktop').textContent='Golden Boot ×'+L[PK_KICKS-1]};
 const pickOpp=d=>{if(ph!=='idle'&&ph!=='over')return;opp=PK_OPP[(PK_OPP.indexOf(opp)+d+PK_OPP.length)%PK_OPP.length];L=pkLadder(opp.id);pkStats().opp=opp.id;save();opps();ladder();sb();pkSfx('tick')};
 const lockOpps=v=>{const s=$('pkset');if(s)s.classList.toggle('lock',v);$('pkprev').disabled=v;$('pknext').disabled=v};
 const btn=(txt,on)=>{const b=$('pkgo');b.textContent=txt;b.disabled=!on};
 const hint=s=>{const e=$('pkhint');if(e){e.textContent=s||'';e.classList.toggle('on',!!s)}};
 const showTell=()=>{const e=$('pktell'),b=$('pktellb'),a=$('pktella');if(!e)return;if(!tell){e.classList.add('off');b.textContent=ph==='idle'||ph==='over'?'Every kick shows a tell':'A new tell comes with the next kick';a.innerHTML='It tells you which way to go';return}
  e.classList.remove('off');b.textContent=tell.txt.charAt(0).toUpperCase()+tell.txt.slice(1);const S=['◀ LEFT','the MIDDLE','RIGHT ▶'];
  a.innerHTML=pkKind(kick)==='shoot'?`He usually dives <b>${S[tell.T]}</b>: shoot <b class="go">${tell.T===0?'RIGHT ▶ (E or D)':'◀ LEFT (Q or A)'}</b>`:tell.T===1?`They usually shoot <b>down the middle</b>: <b class="go">stay (S)</b>`:`They usually shoot <b>${S[tell.T]}</b>: dive <b class="go">${tell.T===0?'◀ LEFT (A)':'RIGHT ▶ (D)'}</b>`;
  e.classList.remove('pop');void e.offsetWidth;e.classList.add('pop')};
 const sb=()=>{const d=$('pksbd');if(!d)return;d.innerHTML=Array.from({length:PK_KICKS},(_,i)=>{const k=i+1,r=rs[i],cur=k===kick&&ph!=='idle'&&ph!=='over'&&r==null;return `<i class="${pkKind(k)==='shoot'?'sh':'sv'}${r===true?' w':r===false?' l':''}${cur?' cur':''}${k===PK_KICKS?' bt':''}"><s>${r===true?'✓':r===false?'✕':pkKind(k)==='shoot'?PKIC.ball:PKIC.glove}</s><u>${k}</u></i>`}).join('')};
 const kickLabel=()=>{const e=$('pkkl');if(!e)return;sb();if(ph==='idle'){e.innerHTML='Pick a keeper <b>and kick off</b>';return}if(ph==='over'){e.innerHTML=step>=PK_KICKS?'<b>GOLDEN BOOT!</b>':'<b>FULL TIME</b>';return}
  const sv=pkKind(kick)==='save';e.innerHTML=`Kick ${kick}/${PK_KICKS} • <b class="${sv?'save':''}">${kick===PK_KICKS?'GOLDEN BOOT':sv?'YOUR SAVE':'YOUR SHOT'}</b>`;e.classList.remove('pop');void e.offsetWidth;e.classList.add('pop')};
 const steps=()=>{const e=$('pksteps');if(!e)return;const idle=ph==='idle'||ph==='over'||ph==='prep',sv=!idle&&pkKind(kick)==='save';
  const S=idle?[['Pick a keeper',0],['Set your bet',0],['Kick off',1]]:ph==='between'?[['Cash out',1],['or',2],['Next kick',1]]:sv?[['Tell',ph==='runup'?2:0],['Dive (A S D) before the strike',ph==='runup'?1:0],['Save',ph==='fly'?1:0]]:[['Tell',ph==='aim'?2:0],['Pick a spot (Q W E / A S D)',ph==='aim'?1:0],['Shoot',ph==='power'?1:0]];
  e.innerHTML=S.map(([x,on],i)=>(i&&S[i][1]!==2&&S[i-1][1]!==2?'<i>➜</i>':'')+`<span class="${on===1?'on':on===2?'seen':''}">${x}</span>`).join('')};
 const spot=()=>{const t=$('pkspt'),m=$('pkmini');if(!t)return;let c=-1,r=-1,x='–';if(pick){c=pick.c;r=pick.r;x=SPOTN[r][c]+' • '+KEYS[r][c]}else if(dive!=null){c=dive;x='Dive '+['left','middle','right'][dive]+' • '+'ASD'[dive]}else if(ph==='aim')x='Pick one of six spots';else if(ph==='runup')x='Dive left, middle or right';
  t.textContent=x;$('pksptl').textContent=ph==='runup'||(dive!=null&&!pick)?'Your dive':'Selected spot';m.classList.toggle('dv',r<0&&c>=0);m.querySelectorAll('i').forEach((e,i)=>e.classList.toggle('on',c>=0&&(r<0?i%3===c:i===r*3+c)))};
 /* ---------- flow ---------- */
 const begin=()=>{if(ph!=='idle'&&ph!=='over')return;if(CAS.lock)return;if(CAS.bet<PK_BET[0]){msg(broke()||`Place a bet first (at least ${PK_BET[0]}).`);return}if(CAS.bet>P.gold){msg('Not enough gold.');return}
  bet=Math.min(CAS.bet,PK_BET[1]);if(!cTake(bet))return;betLock(true);lockOpps(true);const s=pkStats();s.plays++;save();step=0;kick=1;rs=[];ph='prep';pkSfx('whistle');ladder();btn('Kick off',false);
  if(firstRun){firstRun=false;howTo(()=>startKick());return}startKick()};
 const startKick=()=>{if(!alive())return;banner=null;anim=null;pick=null;dive=null;hov=null;const kind=pkKind(kick);tell=pkTell(opp,kind);kickLabel();showTell();ladder();
  if(kind==='shoot'){ph='aim';nsp=.85+kick*.035;btn('Pick a spot',false);hint('Pick a spot in the goal: click it, or Q W E (top) and A S D (low)');msg(`Kick ${kick}: read the keeper's tell, then pick your spot.`)}
  else{ph='runup';runT=0;btn('Dive ← ↓ →',false);hint('Dive before the strike: click left, middle or right of the goal, or A S D / arrow keys');msg(`Kick ${kick}: ${opp.n} steps up. Watch the run-up and dive.`)}};
 const choose=(c,r)=>{if(ph!=='aim')return;pick={c,r};ph='power';needle=0;ndir=1;pkSfx('tick');btn('Shoot • '+KEYS[r][c],true);hint(r===0?'Top corners need a cleaner strike: stop the needle in the green (click or Space)':'Stop the needle in the green (click or Space)')};
 const strike=()=>{if(ph!=='power')return;const top=pick.r===0,gw=top?.075:.11,yw=.13,d=Math.abs(needle-.5),q=d<=gw?'clean':d<=gw+yw?'scuff':'wild';
  const res=pkShot(opp,tell.T,pick.c,pick.r,q);const s=pkStats();s.shots++;if(res.goal)s.goals++;
  ph='fly';btn('…',false);hint('');const kd=res.keeper===0?-1:res.keeper===2?1:0,near=res.goal&&res.keeper===pick.c;
  /* a goal past a keeper who went the right way: he dives a fraction short and lower, so the ball beats his fingertips */
  anim={kind:'shoot',t:-.75,res,q,c:pick.c,r:pick.r,kd:kd*(near?.82:1),lift:pick.r===0?(near?.62:.9):.15,tgt:aimPoint(pick.c,pick.r,res)}};
 const diveTo=d=>{if(ph!=='runup'||dive!=null)return;dive=d;pkSfx('tick');hint(d===0?'Diving left…':d===2?'Diving right…':'Staying big in the middle…')};
 const shoot2=()=>{/* the kicker strikes */const d=dive==null?1:dive,res=pkSave(opp,tell.T,d);const s=pkStats();s.faced++;if(res.win&&res.how==='saved')s.saves++;
  ph='fly';pkSfx('kick');hint('');anim={kind:'save',t:0,res,d,kd:d===0?-1:d===2?1:0,lift:res.row===0?.85:.15,tgt:savePoint(res)}};
 const aimPoint=(c,r,res)=>{const Z=pkZone(c,r),jx=(Math.random()-.5)*Z.w*.35,jy=(Math.random()-.5)*Z.h*.3;let x=Z.cx+jx,y=Z.cy+jy;if(res.goal&&res.keeper===c&&c!==1){x=c===0?Z.x+26:Z.x+Z.w-26;y=r===0?Z.y+22:y}
  if(res.how==='over')return{x:x+jx,y:PKG.y0-70,end:'over'};if(res.how==='bar')return{x,y:PKG.y0-4,end:'bar'};if(res.how==='wide')return{x:c===0?PKG.x0-40:c===2?PKG.x1+40:x+(Math.random()<.5?-1:1)*320,y,end:'wide'};
  if(res.how==='saved'||res.how==='tipped'||res.how==='weak'){const kx=PKSW/2+(res.keeper===0?-1:res.keeper===2?1:0)*190;return{x:res.keeper===1?x:kx+(c<1?-40:c>1?40:0),y:r===0?PKG.y0+70:PKG.y1-60,end:res.how}}return{x,y,end:'goal'}};
 const savePoint=res=>{const Z=pkZone(res.col,res.row);let x=Z.cx+(Math.random()-.5)*Z.w*.3,y=Z.cy+(Math.random()-.5)*Z.h*.3;if(res.how==='miss')return Math.random()<.5&&res.row===0?{x,y:PKG.y0-70,end:'over'}:{x:res.col===0?PKG.x0-50:res.col===2?PKG.x1+50:x+260,y,end:'wide'};
  if(res.how==='saved')return{x,y,end:'saved'};return{x,y,end:'goal'}};
 const finishKick=win=>{if(!alive())return;rs[kick-1]=!!win;sb();if(win){step++;const s=pkStats();if(step>s.best)s.best=step;pkSfx('step');
   if(step>=PK_KICKS){s.boots++;save();cashOut(true);return}
   const v=Math.floor(bet*L[step-1]);if(v>=cap()){save();cashOut(false,true);return}
   kick++;ph='between';anim=null;save();ladder();stats();kickLabel();btn('Next kick ▶',true);hint('');tell=null;showTell();
   msg(`Rung ${step}: ×${L[step-1]} (${cmn(v)}). Next is a ${pkKind(kick)==='shoot'?'kick you take':'kick you face'} for ×${L[step]}. Cash out, or go on?`,'w')}
  else{ph='over';tell=null;showTell();cPay(bet,0);save();ladder();stats();lockOpps(false);betLock(false);btn('Play again',true);kickLabel();hint('');
   msg(`${anim&&anim.kind==='save'?'They scored.':'No goal.'} The stake is gone. ${step?`You reached rung ${step}.`:''}${broke()?' '+broke():''}`,'l')}};
 const cashOut=(boot,capped)=>{if(!(ph==='between'||boot||capped)||!step)return;const pay=Math.min(cap(),Math.floor(bet*L[step-1]));ph='over';cPay(bet,pay);const s=pkStats();if(pay>bet)s.won++;save();
  ladder();stats();lockOpps(false);betLock(false);btn('Play again',true);kickLabel();tell=null;showTell();hint('');
  if(boot){/* the casino's big-win overlay plays first; the Golden Boot banner follows it */banner=null;burst(160);cheer=4;pkSfx('roar');setTimeout(()=>{if(!alive())return;banner={txt:'GOLDEN BOOT',col:'#ffd45a',sub:`×${L[PK_KICKS-1]} · +${cmn(pay-bet)}`,t:0,d:3.2};burst(120);cheer=3},2600)}
  msg(boot?`GOLDEN BOOT! All ten kicks won: ${cmn(pay)} gold.`:capped?`Maximum payout reached: ${cmn(pay)} gold.`:`Cashed out at ×${L[step-1]}: ${cmn(pay)} gold (+${cmn(pay-bet)}).`,'w')};
 const burst=n=>{const cols=['#ffd45a','#ff8a2a','#9fe8ff','#7dff9a','#ff6a9a','#ffffff'];for(let i=0;i<n;i++)conf.push({x:PKSW/2+(Math.random()-.5)*600,y:-20-Math.random()*200,vx:(Math.random()-.5)*160,vy:120+Math.random()*200,a:Math.random()*6,va:(Math.random()-.5)*10,s:4+Math.random()*4,c:cols[i%cols.length],l:3+Math.random()})};
 const howTo=done=>{const st=el.querySelector('.pkst'),d=document.createElement('div');d.className='pkhow';d.innerHTML=`<h3>How to be a Penalty King</h3>
  <div class="pkhg"><div><i>⚽</i><b>Odd kicks: you shoot</b><p>Read the keeper's tell, pick one of six spots, stop the power needle in the green. Top corners are hardest to save but can clip the bar.</p></div>
  <div><i>🧤</i><b>Even kicks: you save</b><p>Watch the run-up for the kicker's tell and dive left, middle or right before the strike.</p></div>
  <div><i>🏆</i><b>Climb or cash out</b><p>Every kick you win climbs the ladder. Lose one and the stake is gone. Ten in a row wins the Golden Boot.</p></div></div>
  <button class="bbig" id="pkhok">Got it, kick off</button>`;st.appendChild(d);pkStats().seen=1;save();$('pkhok').onclick=()=>{d.remove();done()}};
 /* ---------- input ---------- */
 const zoneAt=(x,y)=>{if(x<PKG.x0||x>PKG.x1||y<PKG.y0-10||y>PKG.y1)return null;return{c:Math.min(2,Math.floor((x-PKG.x0)/((PKG.x1-PKG.x0)/3))),r:y<PKG.mid?0:1}};
 const xy=e=>{const b=cv.getBoundingClientRect();return{x:(e.clientX-b.left)*PKSW/b.width,y:(e.clientY-b.top)*PKSH/b.height}};
 cv.onpointermove=e=>{const p=xy(e);hov=ph==='aim'?zoneAt(p.x,p.y):ph==='runup'&&dive==null&&p.y<PKG.y1+40&&p.y>PKG.y0-40?{c:Math.min(2,Math.max(0,Math.floor((p.x-PKG.x0)/((PKG.x1-PKG.x0)/3)))),r:-1}:null;cv.style.cursor=hov||ph==='power'?'pointer':''};
 cv.onpointerleave=()=>{hov=null};
 cv.onpointerdown=e=>{try{ensureAudio()}catch(x){}const p=xy(e);if(ph==='aim'){const z=zoneAt(p.x,p.y);if(z)choose(z.c,z.r)}else if(ph==='power')strike();else if(ph==='runup'){const c=Math.min(2,Math.max(0,Math.floor((p.x-PKG.x0)/((PKG.x1-PKG.x0)/3))));diveTo(c)}};
 $('pkgo').onclick=()=>{if(ph==='idle'||ph==='over')begin();else if(ph==='between')startKick();else if(ph==='power')strike()};
 $('pkco').onclick=()=>cashOut();$('pkprev').onclick=()=>pickOpp(-1);$('pknext').onclick=()=>pickOpp(1);$('pkfull').onclick=()=>{full=!full;ladder()};
 wireBet(()=>ladder());
 CAS.key={' ':()=>{if(ph==='power')strike();else if(ph==='between')startKick();else if(ph==='idle'||ph==='over')begin()},enter:()=>{if(ph==='idle'||ph==='over')begin();else if(ph==='between')startKick()},c:()=>cashOut(),
  q:()=>ph==='aim'?choose(0,0):0,w:()=>ph==='aim'?choose(1,0):0,e:()=>ph==='aim'?choose(2,0):0,
  a:()=>ph==='aim'?choose(0,1):diveTo(0),s:()=>ph==='aim'?choose(1,1):diveTo(1),d:()=>ph==='aim'?choose(2,1):diveTo(2),
  arrowleft:()=>diveTo(0),arrowdown:()=>diveTo(1),arrowright:()=>diveTo(2)};
 /* the stake was taken; leaving with a run in progress pays out what has been won so far (the Lobby is locked during a run anyway) */
 CAS.flush=()=>{if(step>0&&(ph==='between'))cashOut()};
 /* ---------- the loop ---------- */
 const frame=now=>{if(!alive()||!cv.isConnected)return;const dt=Math.min(.05,(now-last)/1000);last=now;t+=dt;{const sig=ph+'|'+kick+'|'+(pick?pick.c+''+pick.r:'')+'|'+dive;if(sig!==sph){sph=sig;steps();spot();showTellIdle();const co=$('pkco');if(co)co.disabled=!(ph==='between'&&step>0)}}
  if(ph==='power'){needle+=ndir*dt*nsp;if(needle>1){needle=1;ndir=-1}if(needle<0){needle=0;ndir=1}}
  if(ph==='runup'){runT+=dt;if(runT>=1.7){shoot2()}}
  if(anim){anim.t+=dt;const A=anim,d=.62;if(A.t>=0&&!A.kicked){A.kicked=1;if(A.kind==='shoot')pkSfx('kick');pkFxAdd(fx,PKSPOT.x,PKSPOT.y+18,'turf',rm?0:9);pkFxAdd(fx,PKSPOT.x,PKSPOT.y+20,'dust',rm?0:5)}
   if(A.kd&&!A.dusted&&(A.t-.02)/.75>.72){A.dusted=1;const hx=PKSW/2+Math.sign(A.kd)*150*Math.abs(A.kd);pkFxAdd(fx,hx,PKG.y1,'dust',rm?0:10)}if(A.t>=d&&!A.landed){A.landed=1;landFx(A)}if(A.t>=d+1.5&&!A.done){A.done=1;finishKick(A.kind==='shoot'?A.res.goal:A.res.win)}}
  if(banner){banner.t+=dt;if(banner.t>banner.d)banner=null}
  for(const p of conf){p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=60*dt;p.a+=p.va*dt;p.l-=dt*.6}conf=conf.filter(p=>p.l>0&&p.y<PKSH+20);
  pkFxStep(fx,dt);if((ph==='idle'||ph==='over')&&CAS.bet!==lb){lb=CAS.bet;ladder()}flash=Math.max(0,flash-dt*2.5);shake=Math.max(0,shake-dt*18);cheer=Math.max(0,cheer-dt);
  draw();requestAnimationFrame(frame)};
 const landFx=A=>{const e=A.tgt.end,win=A.kind==='shoot'?A.res.goal:A.res.win;
  if(e==='goal'){pkSfx('net');shake=rm?0:8;flash=A.kind==='shoot'?.6:.2;pkFxAdd(fx,A.tgt.x,A.tgt.y,'spark',rm?0:8)}else if(e==='bar'){pkSfx('clang');shake=rm?0:6}else if(e==='saved'||e==='tipped'||e==='weak'){pkSfx('glove');shake=rm?0:5;pkFxAdd(fx,A.tgt.x,A.tgt.y,'spark',rm?0:14)}
  setTimeout(()=>{if(!alive())return;win?(pkSfx('roar'),cheer=1.8):pkSfx('groan')},120);
  const txt=A.kind==='shoot'?(win?'GOAL!':e==='bar'?'OFF THE BAR!':e==='over'?'OVER!':e==='wide'?'WIDE!':e==='weak'?'TOO SOFT!':'SAVED!'):(A.res.how==='saved'?'SAVED!':A.res.how==='miss'?(e==='over'?'OVER THE BAR!':'WIDE!'):'GOAL…');
  const good=win;banner={txt,col:good?'#ffd45a':'#ff8a98',sub:good?`×${L[step]} next rung`:null,t:0,d:1.5};if(good)burst(A.kind==='shoot'?70:50)};
 /* ---------- drawing ---------- */
 const ballAt=(A,u)=>{const T=A.tgt,sx=PKSPOT.x,sy=PKSPOT.y,ex=T.x,ey=T.y,e=1-Math.pow(1-u,2.2);let x=sx+(ex-sx)*e,y=sy+(ey-sy)*e-Math.sin(Math.PI*u)*(A.r===0||T.end==='over'?90:40),r=22-11*e;
  if(u>=1){const v=Math.min(1,(A.t-.62)/.6);if(T.end==='goal'){x=ex;y=ey+v*v*(PKG.y1-14-ey)*.9;r=12}else if(T.end==='bar'){x=ex+v*80*(ex<PKSW/2?-1:1);y=ey-Math.sin(v*Math.PI)*90+v*60;r=12}
   else if(T.end==='over'){x=ex+(ex-sx)*.2*v;y=ey-v*80;r=12-v*6}else if(T.end==='wide'){x=ex+(ex<PKSW/2?-1:1)*v*60;y=ey+v*20;r=12}else{x=ex+(ex<PKSW/2?-1:1)*v*140;y=ey+v*v*160-Math.sin(v*Math.PI)*60;r=13}}
  return{x,y,r}};
 const kClock=()=>anim?anim.t:ph==='runup'?runT-1.7:null;
 const keeperP=()=>{const A=anim,isSave=A?A.kind==='save':ph==='runup';
  if(!A){if(isSave)return dive==null?{st:'ready',crouch:Math.min(1,runT/1.7)*.5}:{st:'ready',crouch:.75,lean:dive===0?-1:dive===2?1:0};
   const on=tell&&(ph==='aim'||ph==='power');return{st:'ready',lean:on?(tell.T===0?-1:1)*(.55+.45*Math.sin(t*2.3)):0,look:on?(tell.T===0?-1:1):0}}
  if(A.t<0)return{st:'ready',crouch:pkCl((A.t+.45)/.4),look:0};
  const s2=Math.sign(A.kd),amt=Math.abs(A.kd)||1,p=pkCl((A.t-.02)/.75);let base=s2?{st:'dive',s:s2,amt,p,lift:A.lift}:{st:A.lift>.5?'jump':'block',p};
  const won=A.kind==='shoot'?A.res.goal:A.res.win,happy=A.kind==='shoot'?!won:won;
  if(A.t>1.25){const k=pkSm((A.t-1.25)/.35),gx=s2?s2*150*amt*.85:0;base={blend:[base,happy?{st:'celebrate',x:gx}:(s2?{st:'down',s:s2,amt}:{st:'headhands'}),k]}}
  return base};
 const kickerP=(isSave,kc)=>{const E={x:468,y:592},S=isSave?{x:330,y:700}:{x:398,y:648},run=isSave?1.45:.5;
  if(kc==null)return{X:S.x,Y:S.y,P:{st:'idle'}};
  if(kc<-.25){const pr=pkCl((kc+.25+run)/run);if(pr<=0)return{X:S.x,Y:S.y,P:{st:'idle'}};const e=pkSm(pr);return{X:S.x+(E.x-S.x)*e,Y:S.y+(E.y-S.y)*e,P:{st:'run',f:(kc+.25+run)*13}}}
  const k=pkCl((kc+.25)/.6);let P={st:'kick',k};
  if(kc>.95&&anim){const won=anim.kind==='shoot'?anim.res.goal:!anim.res.win;P={blend:[P,{st:won?'celebrate':'headhands'},pkSm((kc-.95)/.3)]}}
  return{X:E.x,Y:E.y,P}};
 const draw=()=>{g.setTransform(1,0,0,1,0,0);const sh=shake?(Math.random()-.5)*shake:0;
  const A=anim,u=A?pkCl(A.t/.62):0,flying=A&&A.t>=0,b=flying?ballAt(A,u):null,inNet=A&&A.tgt.end==='goal'&&u>=1;
  /* camera: a gentle push toward the goal while the ball flies, easing back afterwards */
  let z=1;if(A&&!rm){z=1+.08*pkSm((A.t+.25)/.6)*(1-pkSm((A.t-1.3)/.6))}
  g.save();g.translate(sh,sh*.5);g.translate(540,290);g.scale(z,z);g.translate(-540,-290);
  g.drawImage(pkStadium(cheer>0?((t*7)|0)%2:0),0,0);pkFlashes(g,t,cheer);
  pkNet(g,t,inNet?{x:A.tgt.x,y:A.tgt.y,k:Math.max(0,1-(A.t-.62)*1.4)}:null);
  if(inNet)pkBall(g,b.x,b.y,b.r,.62*16);
  pkFrame(g,A&&A.tgt.end==='bar'&&u>=1?Math.max(0,1-(A.t-.62)*3)*3*Math.sin(A.t*60):0);
  /* aim zones */
  if(ph==='aim'){for(let c=0;c<3;c++)for(const r of [0,1]){const on=hov&&hov.c===c&&hov.r===r;if(on)pkZoneDraw(g,c,r,1);else{const Z=pkZone(c,r);g.save();g.globalAlpha=.3+.14*Math.sin(t*3+c+r);g.strokeStyle='#fff';g.lineWidth=2;g.setLineDash([6,8]);g.beginPath();g.roundRect(Z.x+10,Z.y+10,Z.w-20,Z.h-20,12);g.stroke();g.restore()}pkKeyChip(g,pkZone(c,r).cx,pkZone(c,r).y+30,KEYS[r][c],on)}}
  if(ph==='power'&&pick){pkZoneDraw(g,pick.c,pick.r,1);const Z=pkZone(pick.c,pick.r);g.save();g.strokeStyle='rgba(255,212,90,.9)';g.lineWidth=4;g.setLineDash([4,12]);g.lineDashOffset=-t*40;g.beginPath();g.moveTo(PKSPOT.x,PKSPOT.y-20);g.quadraticCurveTo((PKSPOT.x+Z.cx)/2,Math.min(PKSPOT.y,Z.cy)-90,Z.cx,Z.cy);g.stroke();g.restore()}
  if(ph==='runup'){for(let c=0;c<3;c++){const Z=pkZone(c,1);pkKeyChip(g,Z.cx,PKG.y1-26,'ASD'[c],dive===c||(dive==null&&hov&&hov.c===c))}}
  if(ph==='runup'&&hov&&hov.r===-1){const Z=pkZone(hov.c,0);g.save();g.globalAlpha=.22;g.fillStyle='#9fe8ff';g.beginPath();g.roundRect(Z.x+6,PKG.y0+6,Z.w-12,PKG.y1-PKG.y0-12,14);g.fill();g.restore()}
  /* the keeper */
  const isSave=A?A.kind==='save':ph==='runup'||(ph==='between'&&pkKind(kick)==='save');const K=isSave?PKYOU:opp;
  pkRigDraw(g,pkKeeperPose(PKSW/2,PKG.y1+4,keeperP(),t),K,t,false);
  /* the ball: on the spot until the strike, then in flight with a streak and a shadow */
  if(b&&!inNet){const gy=PKSPOT.y+18-(PKSPOT.y+18-(PKG.y1-4))*u;g.fillStyle='rgba(0,0,0,.28)';g.beginPath();g.ellipse(b.x,u<1?gy:PKG.y1,b.r*.95,b.r*.32,0,0,TAU);g.fill();
   if(u<1&&!rm){const q0=ballAt(A,Math.max(0,u-.16));g.save();g.lineCap='round';const gr=g.createLinearGradient(q0.x,q0.y,b.x,b.y);gr.addColorStop(0,'rgba(255,255,255,0)');gr.addColorStop(1,'rgba(255,246,210,.55)');g.strokeStyle=gr;g.lineWidth=b.r*1.4;g.beginPath();g.moveTo(q0.x,q0.y);g.lineTo(b.x,b.y);g.stroke();g.restore()}
   const sq=A.t<.06?1-.25*(1-A.t/.06):1;g.save();g.translate(b.x,b.y);g.scale(2-sq,sq);pkBall(g,0,0,b.r,Math.min(A.t,.62)*16);g.restore()}
  else if(!flying){g.fillStyle='rgba(0,0,0,.3)';g.beginPath();g.ellipse(PKSPOT.x,PKSPOT.y+18,21,7,0,0,TAU);g.fill();pkBall(g,PKSPOT.x,PKSPOT.y,22,0)}
  pkFxDraw(g,fx);
  /* the kicker, closest to the camera */
  const kc=kClock(),KK=kickerP(isSave,!A&&ph!=='runup'?null:kc);
  pkRigDraw(g,pkKickerPose(KK.X,KK.Y,KK.P,t),isSave?opp:PKYOU,t,true,1.14);
  g.restore();
  /* overlays (not zoomed) */
  if(ph==='runup'){const left=Math.max(0,1.45-runT);g.save();g.font="400 36px 'Pirata One',Georgia,serif";g.lineWidth=7;g.lineJoin='round';g.strokeStyle=PKO;g.fillStyle=dive!=null?'#7dff9a':left<.6?'#ff8a98':'#fff6c8';
   const s3=dive!=null?(dive===0?'◀ Diving left':dive===2?'Diving right ▶':'▼ Staying central'):'DIVE!';g.textAlign='left';g.strokeText(s3,PKSW-300,PKSH-118);g.fillText(s3,PKSW-300,PKSH-118);
   g.fillStyle='rgba(10,6,30,.85)';g.beginPath();g.roundRect(PKSW-300,PKSH-102,250,14,7);g.fill();g.fillStyle=left<.6?'#ff6a7a':'#ffd45a';g.beginPath();g.roundRect(PKSW-300,PKSH-102,Math.max(0,250*left/1.45),14,7);g.fill();g.restore()}
  if(ph==='power'&&pick){const top=pick.r===0;pkPower(g,PKSW-400,PKSH-104,360,needle,top?.075:.11,.13,Math.abs(needle-.5)<=(top?.075:.11))}
  if(banner)pkBanner(g,banner.txt,banner.t/banner.d,banner.col,banner.sub);
  pkConfetti(g,conf);
  if(flash>0){g.fillStyle=`rgba(255,246,200,${(flash*.35).toFixed(3)})`;g.fillRect(-20,-20,PKSW+40,PKSH+40)}
  const vg=g.createRadialGradient(540,300,300,540,300,700);vg.addColorStop(0,'rgba(0,0,0,0)');vg.addColorStop(1,'rgba(4,2,16,.45)');g.fillStyle=vg;g.fillRect(0,0,PKSW,PKSH)};
 /* a small read/poke handle for the tests (the outcome is still drawn after the player commits) */
 window.PKDBG={ph:()=>ph,step:()=>step,kick:()=>kick,tell:()=>tell,needle:v=>{needle=v;ndir=0},bet:()=>bet,L:()=>L,anim:()=>anim,opp:()=>opp.id};
 /* start */
 opps();ladder();stats();betRefresh();kickLabel();
 const sm=el.querySelector('.bv small');if(sm)sm.textContent='max '+cmn(PK_BET[1]);
 msg('Pick a keeper (‹ ›) and a stake, then Kick off. You shoot odd kicks and save even ones; cash out between kicks.');
 requestAnimationFrame(t0=>{last=t0;frame(t0)});}
{const st=document.createElement('style');st.textContent=`
.pkw{position:relative;width:1476px;height:798px;display:grid;grid-template-columns:1008px 1fr;grid-template-rows:560px 1fr;gap:12px 14px}
.pkst{position:relative;border-radius:22px;overflow:hidden;border:3px solid #c99a3a;box-shadow:0 0 0 3px #12081f,0 16px 30px #000a}
.pkst canvas{display:block;width:1008px;height:560px;touch-action:none}
.pktell{position:absolute;left:18px;top:16px;display:flex;align-items:center;gap:10px;padding:8px 16px 8px 10px;border-radius:16px;background:#12081fe8;border:2px solid #ffd45a;box-shadow:0 0 0 2px #12081f;color:#fff8e8}.pktell[hidden],.pkkl[hidden]{display:none}
.pktell i{width:30px;height:18px;border-radius:50%;background:#fff;position:relative;box-shadow:inset 0 0 0 2px #12081f}.pktell i::after{content:'';position:absolute;left:6px;top:4px;width:10px;height:10px;border-radius:50%;background:#12081f}
.pktell small{display:block;font:800 10.5px var(--ui);letter-spacing:.2em;color:#ffd45a}.pktell b{font:700 15px var(--ui)}
.pktell.pop{animation:pkpop .45s cubic-bezier(.34,1.56,.64,1)}
.pkkl{position:absolute;left:50%;top:16px;transform:translateX(-50%);padding:8px 20px;border-radius:12px;background:linear-gradient(180deg,#ffe37a,#e8a018);border:2px solid #12081f;font:800 16px var(--ui);letter-spacing:.14em;color:#3a1a04;box-shadow:0 6px 14px #0008;white-space:nowrap}
.pkkl.save{background:linear-gradient(180deg,#9fe8ff,#3a8ad8);color:#06122a}.pkkl.pop{animation:pkpop2 .5s cubic-bezier(.34,1.56,.64,1)}
.pkhint{position:absolute;left:50%;top:62px;transform:translateX(-50%) translateY(-6px);padding:6px 14px;border-radius:12px;background:#12081fd8;color:#e8e0ff;font:600 13.5px var(--ui);opacity:0;transition:opacity .2s,transform .2s;pointer-events:none;white-space:nowrap}.pkhint.on{opacity:1;transform:translateX(-50%)}
@keyframes pkpop{0%{transform:scale(.6);opacity:0}100%{transform:none;opacity:1}}@keyframes pkpop2{0%{transform:translateX(-50%) scale(.6);opacity:0}100%{transform:translateX(-50%);opacity:1}}
.pkside{grid-row:1;grid-column:2;display:flex;flex-direction:column;gap:8px;padding:10px 12px;border-radius:22px;background:linear-gradient(180deg,#1e1650,#0e0a2c);border:2px solid #6a4ab0;box-shadow:0 0 0 2px #12081f}
.pkside h3{margin:0;text-align:center;font:400 30px/1 'Pirata One',Georgia,serif;color:#ffd45a;-webkit-text-stroke:1px #12081f}
.pklad{display:flex;flex-direction:column;gap:3px;flex:1}
.pkr{position:relative;display:flex;align-items:center;gap:8px;height:36px;padding:0 12px 0 6px;border-radius:11px;background:#ffffff0d;border:2px solid #3a3070;color:#c4badf;transition:transform .2s cubic-bezier(.34,1.56,.64,1),background .2s,border-color .2s}
.pkr span{flex:1;font:600 12.5px var(--ui)}.pkr b{font:800 17px var(--ui);color:#fff8e8}.pkr em{font-style:normal;color:#7dff9a;font-weight:900;margin-left:4px}
.pki{font-style:normal;width:26px;height:26px;display:grid;place-items:center;border-radius:50%;background:#2a2260}.pki.save{background:#1a3a6a}
.pkr.done{background:linear-gradient(90deg,#1e5a3a,#163a2a);border-color:#3ad86a}.pkr.done b{color:#9affb8}
.pkr.next{background:linear-gradient(90deg,#ffe37a,#e8a018);border-color:#fff2a0;color:#3a1a04;transform:scale(1.03)}.pkr.next b,.pkr.next span{color:#3a1a04}
.pkr.boot{border-color:#ffd45a}.pkr.boot b{color:#ffd45a}.pkr.boot.next b{color:#3a1a04}
.pkbtns{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.pkco{all:unset;box-sizing:border-box;cursor:pointer;display:flex;flex-direction:column;align-items:center;justify-content:center;height:66px;border-radius:16px;background:linear-gradient(180deg,#8affa8,#22a85a);border:2px solid #12081f;box-shadow:0 5px 0 #0e5a2a,0 8px 16px #0008;color:#06301a;transition:transform .12s;text-align:center}
.pkco small{font:800 11px var(--ui);letter-spacing:.2em}.pkco b{font:800 14px var(--ui)}.pkco:hover:not(:disabled){transform:translateY(-2px)}.pkco:active:not(:disabled){transform:translateY(2px)}
.pkco:disabled{cursor:default;filter:grayscale(.85) brightness(.6)}
.pkgob{height:66px;width:100%;font-size:24px;padding:0}
.pkbot{grid-column:1/-1;display:grid;grid-template-columns:560px 1fr;gap:14px;align-items:stretch;max-width:1300px}
.pkleft{display:flex;flex-direction:column;gap:6px}
.pkstat{display:flex;justify-content:space-around;gap:4px;font:600 12px var(--ui);color:#a99be0}.pkstat b{color:#fff8e8;font-size:13.5px}
.pkopps{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;flex:1}
.pkop{all:unset;box-sizing:border-box;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:1px;padding:6px 8px;border-radius:16px;background:linear-gradient(180deg,#221a5c,#110b34);border:2px solid #3a3070;text-align:center;transition:transform .18s cubic-bezier(.34,1.56,.64,1),border-color .15s}
.pkop canvas{width:50px;height:50px}.pkop b{display:block;font:400 20px/1.05 'Pirata One',Georgia,serif;color:#fff8e8}.pkop small{display:block;font:500 10.5px/1.25 var(--ui);color:#a99be0}.pkop em{display:block;margin-top:2px;font:800 12px var(--ui);font-style:normal;color:#ffd45a}
.pkop:hover:not(:disabled){transform:translateY(-3px);border-color:var(--c)}.pkop.on{border-color:#ffd45a;background:linear-gradient(180deg,#3a2a7a,#1a1250)}.pkop:disabled{cursor:default;opacity:.55}.pkop.on:disabled{opacity:1}
.pkmid{display:flex;flex-direction:column;justify-content:flex-start;gap:6px;min-width:0}.pkmid .cmsg{margin:0;min-height:38px;font-size:15px}.pkmid .ctl{margin:0}
.pkhow{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:18px;background:#0a0620e8;animation:pkpop .4s ease}
.pkhow h3{margin:0;font:400 48px 'Pirata One',Georgia,serif;color:#ffd45a}.pkhg{display:grid;grid-template-columns:repeat(3,280px);gap:16px}
.pkhg>div{padding:18px;border-radius:18px;background:#1e1650;border:2px solid #6a4ab0;color:#e8e0ff}.pkhg i{font-style:normal;font-size:34px}.pkhg b{display:block;margin:6px 0;font:800 17px var(--ui);color:#fff8e8}.pkhg p{margin:0;font:500 14px/1.4 var(--ui)}`;document.head.appendChild(st)}
/* the lobby tile: a floodlit goal, the keeper's gloves and a ball flying to the top corner */
TA.pk=`<svg viewBox="0 0 320 176" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="pkts" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0a0828"/><stop offset=".6" stop-color="#2a1a5a"/></linearGradient><linearGradient id="pktg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2a8a3e"/><stop offset="1" stop-color="#3fae52"/></linearGradient><radialGradient id="pktl" cx=".5" cy="0" r=".9"><stop offset="0" stop-color="#fffbe0" stop-opacity=".45"/><stop offset="1" stop-color="#fffbe0" stop-opacity="0"/></radialGradient></defs>
<rect width="320" height="176" fill="url(#pkts)"/><g fill="#ffd45a" opacity=".55">${Array.from({length:40},(_,i)=>`<circle cx="${(i*41)%320}" cy="${50+(i*17)%40}" r="3"/>`).join('')}</g><rect width="320" height="176" fill="url(#pktl)"/>
<rect y="104" width="320" height="72" fill="url(#pktg)"/><path d="M70 40h180v74M70 40v74" fill="none" stroke="#fff" stroke-width="7" stroke-linejoin="round"/><path d="M70 40h180v74M70 40v74" fill="none" stroke="#12081f" stroke-width="2"/>
<g stroke="#dfe6ff" stroke-width="1" opacity=".55">${[0,1,2,3,4,5,6,7,8].map(i=>`<path d="M${80+i*20} 46v66"/>`).join('')}${[0,1,2,3].map(i=>`<path d="M74 ${56+i*16}h172"/>`).join('')}</g>
<g transform="translate(160 112)"><rect x="-16" y="-50" width="32" height="40" rx="8" fill="#ff8a2a" stroke="#12081f" stroke-width="3"/><ellipse cx="0" cy="-62" rx="15" ry="14" fill="#7ac24a" stroke="#12081f" stroke-width="3"/><circle cx="-5" cy="-63" r="3.5" fill="#fff"/><circle cx="5" cy="-63" r="3.5" fill="#fff"/><rect x="-40" y="-62" width="14" height="14" rx="4" fill="#ffd45a" stroke="#12081f" stroke-width="2.5" transform="rotate(-20)"/><rect x="26" y="-62" width="14" height="14" rx="4" fill="#ffd45a" stroke="#12081f" stroke-width="2.5" transform="rotate(20)"/></g>
<path d="M210 160 Q240 90 232 58" fill="none" stroke="#ffd45a" stroke-width="3" stroke-dasharray="5 6"/><circle cx="232" cy="56" r="11" fill="#fff" stroke="#12081f" stroke-width="3"/><path d="M232 50l5 3-2 6h-6l-2-6z" fill="#2a2460"/></svg>`;
