# python3 t_flrush104.py [game.html] [--quick] : Harvest Moon Rush, the 10.4 Harvest Festival's limited-time Endless variant
# (99r monsters, 99r2 fields, 99r3 mode, 99r4 page; prefix flr). Checks: the cast (nine monsters, three bosses, roles, traits, art at many
# times with and without the lunge, frame cost per monster and per boss, the scenes and their per-frame cost), the mode (start, labels,
# levels and fields, the twist rotation and boss rounds, harvest words and boss lines, the spawn pool, summoned and boss minions),
# each twist's mechanics (gust offsets and schedule, the next letter held still; leaf piles never on the first letter, revealed on reach
# or at halfway; crows steal the letter once, the cursor steps back, the word still completes; long words at level 4+), the pay (gold x1.35,
# XP +30%, a Harvest Chest and acorns per boss, drops, milestones once, payout through fleGive / flcAdd, pending when a part is missing),
# save repair, companions active, every weapon path / armors / boons in a bot run, resume, pause label and restart, the over screen,
# the mode page, the Choose a mode card (and not when the festival is off), the bestiary and mastery sections, DEV cheats, the cheat guard
# (window.TW_AC_TEST), HUD placement against the boss UI, UI fit at 1600x900 / 1280x720 / 1024x640 (tools/td/rpu_ovl.js) and no page errors.
# Screenshots in shots/w104_rush/. The other 10.4 parts are stubbed (tools/fl/stub_flr.js, test only) where they are missing.
import asyncio,os,sys,json
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
ARGS=[a for a in sys.argv[1:] if not a.startswith('--')];QUICK='--quick' in sys.argv
H='file://'+os.path.abspath(ARGS[0] if ARGS else os.path.join(HERE,'out.html'))
OVL=open(os.path.join(HERE,'..','tools','td','rpu_ovl.js')).read()
STUB=open(os.path.join(HERE,'..','tools','fl','stub_flr.js')).read()
SHOTS=os.path.join(HERE,'shots','w104_rush');os.makedirs(SHOTS,exist_ok=True)
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:900]),flush=True)
    if not ok:FAIL.append(name)
SETUP="()=>{RS_ASK=false;try{WCRELAYS=[]}catch(e){}ST.perfAsked=1;try{PFW.asked=true}catch(e){}ST.cine=false;window.FL_FORCE=1;P.tips=P.tips||{};for(const k of ['bomb','blink','charge','summon','shield'])P.tips[k]=1;flrB().tip={flgust:1,flleaf:1,flcrow:1};save();return 1}"
HELP=r"""()=>{const seed=s=>{let a=s>>>0;Math.random=function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}};
 window.__f={M0:Math.random,seed,
 go(lv,o){o=o||{};start(0,'flr');S.hp=S.max=o.hp||40;if(o.inv)S.inv=1e9;if(lv>1){S.wave=(lv-1)*5;S.en=[];startWave()}S.ban=null;return S},
 round(r){S.wave=(lvOf(S.wave)-1)*5+r-1;S.en=[];S.spawnLeft=0;startWave();S.ban=null},
 mob(id,w,x){const M=MON[id];const e={id,role:0,boss:false,i:0,x:x||1200,ph:.4,fl:0,lg:0,slip:0,y:GY,h:M.h,el:false,rg:false,hv:0,sp:0,w};S.en.push(e);return e},
 tick(n,dt){for(let i=0;i<n;i++){update(dt||1/60);if(S.mode!=='play')break}},
 typeW(e){S.tgt=e;let n=0;while(S.en.includes(e)&&e.i<e.w.length&&n++<80)key(e.w[e.i])},
 /* a bot: types the closest word, breaks bosses with Space, takes the first boon; runs up to n steps of dt */
 bot(n,dt,cps){dt=dt||1/30;cps=cps||9;let acc=0,err=0;for(let s=0;s<n;s++){
   if(S.mode==='boon'){try{if(S.swap&&S.swap.step===2)swapDo(0);else pickBoon(0);if(S.mode==='boon'&&S.swap)swapDo(0)}catch(e){err++}continue}
   if(S.mode!=='play')break;update(dt);acc+=cps*dt;
   while(acc>=1){acc--;const vb=S.en.find(e=>e.boss&&e.vul>0);if(vb){key(' ');continue}
    let t=S.tgt&&S.en.includes(S.tgt)&&S.tgt.w&&!(S.tgt.vul>0)?S.tgt:null;if(!t)t=S.en.filter(e=>e.w&&e.x<W-10&&!(e.vul>0)&&(!e.boss||e.state==='fight')).sort((a,b)=>(b.boss?1:0)-(a.boss?1:0)||a.x-b.x)[0];
    if(t){S.tgt=t;key(t.w[t.i])}}}return err},
 sleep(ms){return new Promise(r=>setTimeout(r,ms))}};return 1}"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        pg.on('console',lambda m:er.append('console: '+m.text[:300]) if m.type=='error' and 'WebSocket' not in m.text and 'net::' not in m.text and 'TUNNEL' not in m.text else None)
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate;await E(OVL);await E(HELP);await E(SETUP)
        shot=lambda n:pg.screenshot(path=os.path.join(SHOTS,n+'.png'))
        # ================= the cast =================
        r=await E("""()=>{const mob=flrMobIds(),bs=flrBossIds(),out={roles:mob.map(a=>a.slice()),bosses:bs.slice(),bad:[]};
          for(const id of [...mob.flat(),...bs]){const M=MON[id];if(!M||typeof M.d!=='function'||!M.n||!M.ds||!(M.h>0)||!(M.th>0)||!(M.sp>0))out.bad.push(id+': fields');if(DR[id]!==M.d)out.bad.push(id+': DR');if(bs.includes(id)!==!!M.boss)out.bad.push(id+': boss flag')}
          out.tr=mob.flat().map(id=>MON[id].tr||'').join(',');out.fly=mob.flat().filter(id=>MON[id].fly);out.pj=mob.flat().filter(id=>MON[id].pj).map(id=>MON[id].pj);out.roar=bs.map(id=>ROARK[id]);out.names=new Set([...mob.flat(),...bs].map(id=>MON[id].n)).size;
          out.reg=REG().filter(k=>/^flr/.test(k)).length;return out}""")
        chk('nine monsters in three roles and three bosses, every one registered (MON, DR, name, story, size, speed), unique names; traits: bomb, shield, blink, charge, summon; two fliers and a flying summoner; the Acorn Knight throws acorns; boss roars rumble / hollow / howl',
            len(r['bad'])==0 and [len(x) for x in r['roles']]==[3,3,3] and len(r['bosses'])==3 and r['names']==12 and set(r['tr'].split(','))>={'bomb','shield','blink','charge','summon',''} and len(r['fly'])==3 and r['pj']==['acorn'] and r['roar']==['rumble','hollow','howl'] and r['reg']==9,r)
        r=await E("""()=>{const c=document.createElement('canvas');c.width=520;c.height=520;const g=c.getContext('2d'),bad=[],ink={};
          for(const id of [...flrMobIds().flat(),...flrBossIds()]){const M=MON[id];for(const t of [0,.37,1.3,2.9,3.6,4.1,4.4,5.05,6.3,7.7,12.1,25.3])for(const lg of [0,.5,1]){try{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,520,520);g.translate(260,500);g.scale(400/Math.max(M.th,200),400/Math.max(M.th,200));M.d(g,t,{lg,el:lg===.5})}catch(e){bad.push(id+' t'+t+': '+e.message)}}
            g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,520,520);g.translate(260,500);const s=400/Math.max(M.th,200);g.scale(s,s);M.d(g,1.1,{lg:0});const d=g.getImageData(0,0,520,520).data;let n=0,top=520,L=0,R=0;for(let y=0;y<520;y+=2)for(let x=0;x<520;x+=2){if(d[(y*520+x)*4+3]>30){n++;if(y<top)top=y;if(x<260)L++;else R++}}
            ink[id]={n,top,h:Math.round((500-top)/s),bal:+(L/(L+R)).toFixed(2)}}
          return{bad,ink}}""")
        chk('every monster and boss draws at many times, mid-lunge and as an elite without errors, and puts visible ink on the canvas',not r['bad'] and all(v['n']>400 for v in r['ink'].values()),r)
        r2=await E("()=>Object.fromEntries([...flrMobIds().flat(),...flrBossIds()].map(id=>[id,MON[id].th]))")
        chk('the drawn height of each figure matches its declared native height (th) within 22% (so fitThumb, the bosses\' framing and the hit box line up)',all(abs(r['ink'][k]['h']-r2[k])<=r2[k]*.22 for k in r2),{k:(r['ink'][k]['h'],r2[k]) for k in r2})
        r=await E("""()=>{const c=document.createElement('canvas');c.width=600;c.height=600;const g=c.getContext('2d',{willReadFrequently:true});const ref=['gyshamble','gywitch','gybrute','gyvamp'],refB=['bpumpking','bhexmire','bhorse'];
          const ids=[...flrMobIds().flat(),...flrBossIds(),...ref,...refB];const T={};for(const id of ids)T[id]=[];
          for(let r=0;r<12;r++)for(const id of ids){const M=MON[id];g.save();const t0=performance.now();for(let i=0;i<10;i++){g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,600,600);g.translate(300,560);const s=(M.h/M.th);g.scale(s,s);M.d(g,i*.09+r*.7,{lg:0})}T[id].push((performance.now()-t0)/10);g.restore()}
          const med=a=>{a=a.slice().sort((x,y)=>x-y);return a[a.length>>1]};const m={};for(const id of ids)m[id]=+med(T[id]).toFixed(3);
          const avg=l=>l.reduce((x,k)=>x+m[k],0)/l.length,ra=avg(ref),rb=avg(refB);const mob=flrMobIds().flat(),bs=flrBossIds();
          return{m,ra:+ra.toFixed(3),rb:+rb.toFixed(3),mx:Math.max(...mob.map(k=>m[k]/ra)),bx:Math.max(...bs.map(k=>m[k]/rb)),mabs:Math.max(...mob.map(k=>m[k])),babs:Math.max(...bs.map(k=>m[k]))}}""")
        chk('frame cost per monster is small: each harvest monster draws in at most 2.5x the Monster Mash average (CPU canvas, median of 12 interleaved rounds) and each boss in at most 1.6x the Halloween bosses\' average',r['mx']<=2.5 and r['bx']<=1.6,r)
        # ================= the fields =================
        r=await E("""()=>{const out={lv:FLRLV.map(L=>[L.i,L.n,L.b,L.m.join('/')]),scn:[44,45,46].map(i=>!!SCN[i]&&SCN[i].far&&!!FAR[SCN[i].far])};const bad=[];
          for(const L of FLRLV){for(const k of L.m)if(!MON[k])bad.push(k);if(!MON[L.b]||!MON[L.b].boss)bad.push(L.b)}out.bad=bad;
          const LS=[...FLRLV,...GYLV];for(const L of LS)for(let i=0;i<4;i++)zoneBG(0,i*.7,L);const T=LS.map(()=>[]);
          for(let r=0;r<10;r++)LS.forEach((L,k)=>{const t0=performance.now();for(let i=0;i<5;i++)zoneBG(0,3+r*.3+i*.05,L);T[k].push((performance.now()-t0)/5)});
          const med=a=>{a=a.slice().sort((x,y)=>x-y);return a[a.length>>1]};out.t=T.slice(0,3).map(med);out.ref=Math.max(...T.slice(3).map(med));
          out.sp=Object.keys(FLRSC).length;return out}""")
        chk('three fields (Pumpkin Patch, Corn Maze, Moonlit Orchard) on SCN 44-46 with their own far layers, a featured trio and a boss each; the whole background costs no more than 1.6x a Monster Mash graveyard per frame once the sprites are baked (median of 10 interleaved rounds)',
            len(r['lv'])==3 and all(r['scn']) and not r['bad'] and max(r['t'])<=r['ref']*1.6+.5,r)
        # ================= the mode: start, labels, levels, twists =================
        r=await E("""()=>{__f.seed(3);__f.go(1);const out={gy:S.gy,flr:S.flr,lbl:modeLabel(),z:lvDef(S.wave).n,tw:S.gyc.slice(),ban:[0]};
          const seq=[];for(let lv=1;lv<=7;lv++){S.wave=(lv-1)*5;S.en=[];startWave();seq.push([lv,lvDef(S.wave).n,S.gyc[0],S.ban&&S.ban.txt])}out.seq=seq;
          __f.round(5);out.boss=[S.round,flrTw(),lvDef(S.wave).b];S.ban=null;return out}""")
        chk('start(0,"flr") runs on the Monster Mash rails (S.gy and S.flr), the HUD reads "Harvest Moon Rush Lv 1 Rd 1/5"; levels cycle Pumpkin Patch, Corn Maze, Moonlit Orchard with Gusty Wind, Thieving Crows, Leaf Piles, and each level opens with its name; boss rounds have no twist',
            r['gy']==1 and r['flr']==1 and r['lbl'].startswith('Harvest Moon Rush  Lv 1  Rd 1/5') and [x[2] for x in r['seq']]==['flgust','flcrow','flleaf','flgust','flcrow','flleaf','flgust']
            and [x[1] for x in r['seq']][:3]==['The Pumpkin Patch','The Corn Maze','The Moonlit Orchard'] and all(x[3]==f"Level {x[0]}: {x[1]}" for x in r['seq']) and r['boss'][0]==5 and r['boss'][1]=='',r)
        r=await E("""()=>{__f.seed(5);__f.go(1);const ids=new Set(),ws=[],GS=new Set(FLRW);for(let lv=1;lv<=3;lv++){S.wave=(lv-1)*5+2;S.en=[];startWave();S.ban=null;for(let i=0;i<60;i++){S.spawnLeft=5;spawn();const e=S.en[S.en.length-1];ids.add(e.id);ws.push(e.w)}S.en=[]}
          const all=new Set(flrMobIds().flat());const them=ws.filter(w=>GS.has(w)).length/ws.length;
          __f.round(5);const bl=[];for(let i=0;i<40;i++)bl.push(bossLine(lvDef(S.wave),0,[]));const hb=bl.filter(x=>FLRBL.includes(x)).length;
          return{ids:[...ids],only:[...ids].every(k=>all.has(k)),cover:[...all].every(k=>ids.has(k)),them,hb,ok:bl.every(x=>/^[a-z ]+$/.test(x))}}""")
        chk('the spawn pool is the harvest cast only (all nine appear across the three levels), at least 85% of words come from the harvest list, and about half the boss sentences are harvest lines (all lowercase letters and spaces)',
            r['only'] and r['cover'] and r['them']>=.85 and 8<=r['hb']<=32 and r['ok'],r)
        r=await E("""()=>{__f.seed(9);__f.go(2);S.ban=null;const w=__f.mob('flrwraith','scarecrow',1100);w.tr='summon';w.sm=0;trait(w,.1);const m=S.en.filter(e=>e.mn).map(e=>e.id);
          S.wave=4;__f.round(5);S.en=[];const bz={id:'bflrgourd',x:1000,y:GY,h:380,boss:true};mkMinion(bz);const bm=S.en.filter(e=>e.mn).map(e=>[e.id,!!MON[e.id],e.w]);return{m,bm}}""")
        chk('the Corn-Husk Wraith summons harvest minions and boss minions are recast from the harvest cast (never goblins or graveyard dead)',r['m'] and all(x.startswith('flr') for x in r['m']) and r['bm'] and all(x[0].startswith('flr') and x[1] for x in r['bm']),r)
        # ---- gusts
        r=await E("""()=>{__f.seed(11);__f.go(1);S.ban=null;S.en=[];const e=__f.mob('flrpie','harvest',1000);S.tgt=e;modeTick(1/60);key('h');key('a');
          const G=S.flrG;G.next=.001;modeTick(1/60);const t0=G.t0;const pos=()=>{const out=[];const ft=ctx.fillText;ctx.fillText=function(s,x,y){const m=ctx.getTransform();out.push([s,m.a*x+m.c*y+m.e,m.b*x+m.d*y+m.f]);return ft.apply(this,arguments)};ctx.save();ctx.setTransform(1,0,0,1,0,0);pill(e,true);ctx.restore();ctx.fillText=ft;return out};
          const base=(()=>{S.t=t0-5;return pos()})();const offs=[];let drawn='';for(let k=0;k<6;k++){S.t=t0+.15+k*.18;const p=pos();drawn=p.map(x=>x[0]).join('');offs.push(p.map((q,i)=>Math.round(Math.hypot(q[1]-base[i][1],q[2]-base[i][2]))))}
          S.t=t0+3;const calm=pos().every((q,i)=>Math.abs(q[1]-base[i][1])<.01&&Math.abs(q[2]-base[i][2])<.01);
          G.next=0;const ts=[];let tt=S.t;for(let i=0;i<60*24;i++){S.t+=1/60;const n0=G.n||0;flrGustStep(1/60);if((G.n||0)>n0)ts.push(+(S.t-tt).toFixed(2))}
          const gap=ts.slice(1).map((x,i)=>x-ts[i]);__f.go(4);S.ban=null;S.flrG.next=0;const ts4=[];for(let i=0;i<60*24;i++){S.t+=1/60;const n0=S.flrG.n||0;flrGustStep(1/60);if((S.flrG.n||0)>n0)ts4.push(S.t)}
          const gap4=ts4.slice(1).map((x,i)=>x-ts4[i]);return{offs,calm,drawn,gap:[Math.min(...gap),Math.max(...gap)],gap4:[Math.min(...gap4),Math.max(...gap4)],lbl:S.gyc[0]}}""")
        mx=[max(o[3:]) for o in r['offs']]
        chk('Gusty Wind: a gust tumbles the untyped letters (up to about 20 px) while the typed letters and the next letter hold still, everything is still drawn, and nothing moves between gusts; gusts every 5.4-6.6 s on level 1 and every 3.9-5.1 s from level 4',
            max(mx)>=8 and max(mx)<=26 and all(o[0]==0 and o[1]==0 and o[2]==0 for o in r['offs']) and r['calm'] and 'harvest' in r['drawn'] and 5.3<=r['gap'][0] and r['gap'][1]<=6.7 and 3.8<=r['gap4'][0] and r['gap4'][1]<=5.2,r)
        # ---- leaf piles
        r=await E("""()=>{__f.seed(13);__f.go(3);S.ban=null;S.en=[];const out={first:0,n2:0,n3:0,short:0};
          for(let i=0;i<200;i++){const e=__f.mob('flracorn',['pear','squash','cornstalk','cinnamon','oak'][i%5],1300);flrTwistWord(e);if(e.fp){if(e.fp[0]<1)out.first++;const n=e.fp[1]-e.fp[0]+1;if(n===2)out.n2++;if(n===3)out.n3++;if(e.fp[1]>=e.w.length)out.first++}else if(e.w.length>=4)out.short++;S.en=[]}
          __f.go(6);S.ban=null;S.en=[];let n3=0;for(let i=0;i<60;i++){const e=__f.mob('flracorn','cornstalk',1300);flrTwistWord(e);if(e.fp&&e.fp[1]-e.fp[0]===2)n3++;S.en=[]}out.n3l5=n3;
          __f.go(3);S.ban=null;S.en=[];const e=__f.mob('flracorn','cinnamon',1400);flrTwistWord(e);e.fp=[3,4];S.tgt=e;key('c');key('i');modeTick(1/60);out.a=[e.fpr,e.i];key('n');modeTick(1/60);out.b=[!!e.fpr,e.i];
          const drawn=[];const ft=ctx.fillText;ctx.fillText=function(s){drawn.push(s);return ft.apply(this,arguments)};const f=__f.mob('flracorn','pumpkin',1400);flrTwistWord(f);f.fp=[2,3];pill(f,false);out.hid=drawn.join('');ctx.fillText=ft;
          f.x=(W+KX)/2-5;modeTick(1/60);out.half=!!f.fpr;out.burst=(S.flrFx||[]).filter(x=>x.k==='leaf').length;__f.typeW(e);out.done=!S.en.includes(e);return out}""")
        chk('Leaf Piles: a pile covers two letters (three in long words from level 4), never the first letter and never past the end; the covered letters are not drawn; the pile blows away (with flying leaves) when its first letter is next, or once the monster is halfway; the word still completes',
            r['first']==0 and r['n2']>100 and r['n3']==0 and r['n3l5']==60 and r['a'][0] is None and r['b'][0] and r['b'][1]==3 and r['hid']=='pukin' and r['half'] and r['burst']>=6 and r['done'],r)
        # ---- thieving crows
        r=await E("""()=>{__f.seed(17);__f.go(2);S.ban=null;S.en=[];const out={bad:0,two:0};for(let i=0;i<200;i++){const e=__f.mob('flrturkey',['oak','pear','cider','squirrel','cranberry'][i%5],1300);flrTwistWord(e);for(const c of e.fcs||[])if(c<1||c>e.w.length-2)out.bad++;if(e.fcs&&e.fcs.length>1)out.two++;S.en=[]}
          const e=__f.mob('flrturkey','cider',1300);flrTwistWord(e);e.fcs=[2];e.fcD=[];const ok0=S.ok;S.tgt=e;key('c');key('i');key('d');out.after=[e.i,e.fcD.slice(),S.ok-ok0];out.fx=(S.flrFx||[]).filter(x=>x.k==='crow').map(x=>x.ch);key('d');out.again=e.i;key('d');out.dup=e.i;
          key('e');key('r');out.killed=!S.en.includes(e);
          const f=__f.mob('flrturkey','oak',1300);flrTwistWord(f);out.oak=f.fcs;__f.typeW(f);out.oakDone=!S.en.includes(f);
          __f.go(5);S.ban=null;S.en=[];let two=0;for(let i=0;i<60;i++){const g=__f.mob('flrturkey','cranberries',1300);flrTwistWord(g);if(g.fcs&&g.fcs.length===2&&Math.abs(g.fcs[0]-g.fcs[1])>=2)two++;S.en=[]}out.two6=two;
          const h=__f.mob('flrturkey','cranberries',1300);flrTwistWord(h);__f.typeW(h);out.longDone=!S.en.includes(h);out.st=S.flrSt;return out}""")
        chk('Thieving Crows: the crow sits on a letter between the first and the last; typing it lets the crow steal it (counted as a correct key, a crow flies off with that letter) and the cursor steps back onto it; typing it again moves on and it is not stolen twice; the word completes and the monster falls; short words work; from level 4 long words carry two crows apart',
            r['bad']==0 and r['two']==0 and r['after'][0]==2 and r['after'][1]==[2] and r['after'][2]==3 and r['fx']==['d'] and r['again']==3 and r['dup']==3 and r['killed'] and r['oak']==[1] and r['oakDone'] and r['two6']==60 and r['longDone'],r)
        r=await E("""()=>{__f.go(1);S.ban=null;S.en=[];const e=__f.mob('flrgourd','pumpkin',1200);e.shd=1;e.tr='shield';flrTwistWord(e);e.fp=[1,2];S.tgt=e;for(const ch of 'pumpkin')key(ch);return[S.en.includes(e),e.i,e.fd,e.fp,e.w]}""")
        chk('a shielded Gourd Golem gets a fresh word after its shield breaks and the twist is decided again for it',r[0] and r[1]==0 and not r[2] and r[3] is None,r)
        # ================= pay =================
        REAL=await E("()=>typeof fleGive==='function'&&typeof flcAdd==='function'")
        await E(STUB)
        # merged build: the real fleGive / flcAdd pay; spies call straight through to them and record each call (the stub records itself)
        SPY="()=>{if(window.__flsSpy)return;const G=fleGive,C=flcAdd;window.__flsSpy={G,C};fleGive=function(n,src){__fls.give.push([n,src]);return G.apply(this,arguments)};flcAdd=function(n,src){__fls.chest.push([n,src]);return C.apply(this,arguments)}}"
        UNSPY="()=>{const o=window.__flsSpy;if(!o)return;fleGive=o.G;flcAdd=o.C;delete window.__flsSpy}"
        r=await E("""()=>{__f.seed(21);__f.go(1);S.ban=null;const g0=S.gold;S.gm=1;gain(100);const fl=S.gold-g0;start(0);S.gm=1;const e0=S.gold;gain(100);const en=S.gold-e0;
          __f.go(1);S.ban=null;S.en=[];const out={fl,en};const b=__f.mob('bflrgourd','',1200);b.boss=true;b.phs=1;b.tier=0;gyDrop(b);out.boss=[S.flrA,S.flrC];
          S.flrA=0;let n=0;for(let i=0;i<2000;i++){const m=__f.mob('flrpie','pie',1200);gyDrop(m);S.en=[]}out.drop=S.flrA;S.flrA=0;for(let i=0;i<1000;i++){const m=__f.mob('flrpie','pie',1200);m.el=true;gyDrop(m);S.en=[]}out.dropE=S.flrA;
          const mm=__f.mob('flrcrow','oak',1200);mm.mn=1;S.flrA=0;for(let i=0;i<300;i++)gyDrop(mm);out.mn=S.flrA;out.ba=[1,2,5,11,20].map(FLRPAY.bossA);return out}""")
        chk('pay: gold x1.35 in the Rush against x0.9 in Endless (+50%); a boss pays a Harvest Chest and 30 acorns on level 1 (25 + 5 per level, at most 80); monsters drop an acorn 5% of the time, elites two acorns 30% of the time, boss minions nothing',
            r['fl']==135 and r['en']==90 and r['boss']==[30,1] and 70<=r['drop']<=130 and 480<=r['dropE']<=720 and r['mn']==0 and r['ba']==[30,35,50,80,80],r)
        if REAL:await E(SPY)
        r=await E("""async()=>{__f.seed(23);P.flrb={};flrB();__fls.give=[];__fls.chest=[];const lg0=P.fl&&P.fl.fe?P.fl.fe.lg.length:0;const fc0=P.fcr||0,ac0=(P.fl&&P.fl.ac)||0;__f.go(1);S.ban=null;
          S.flrA=12;S.flrC=2;S.wave=10;S.en=[];startWave();S.wave=20;S.en=[];startWave();S.ban=null;const ms=S.flrM.slice();const x0=P.xp;S.score=3000;const xm=xpMode;xpMode=x=>x;const xr=Math.round((3000/16+S.wave*8)*xpMulRun()*1.3*ENDXP);
          over(1);xpMode=xm;await __f.sleep(50);const out={ms,give:__fls.give.slice(),chest:__fls.chest.slice(),fcr:(P.fcr||0)-fc0,ac:((P.fl&&P.fl.ac)||0)-ac0,B:JSON.parse(JSON.stringify(flrB())),ov:!!document.querySelector('.flrov'),txt:(document.querySelector('.flrov')||{}).textContent||''};
          out.xp=P.xp-x0;out.xr=xr;
          out.ldg=P.fl&&P.fl.fe?P.fl.fe.lg.slice(lg0).filter(e=>/rush/i.test(e.src)).map(e=>e.d):null;out.toast=!!(document.querySelector('#fletoast.show')||document.querySelector('#flctoast.on'));
          __fls.give=[];__fls.chest=[];__f.go(1);S.wave=10;S.en=[];startWave();S.wave=20;S.en=[];startWave();S.ban=null;out.ms2=S.flrM.slice();over(1);out.give2=__fls.give.slice();out.chest2=__fls.chest.slice();return out}""")
        await shot('over_pay')
        chk('payout at the end of a run: milestones for levels 3 (+60) and 5 (+100 and a chest) reached in the run, so 12 + 60 + 100 = 172 acorns through fleGive and 2 + 1 = 3 Harvest Chests through flcAdd, both tagged "Harvest Moon Rush"; records saved (best, deepest level 5, runs, lifetime acorns and chests, milestones 3 and 5); XP is the Endless formula x1.3; the next run does not pay the same milestones again',
            r['ms']==[3,5] and r['give']==[[172,'Harvest Moon Rush']] and r['chest']==[[3,'Harvest Moon Rush']] and r['fcr']==3 and r['ac']==172 and r['B']['best']==3000 and r['B']['lv']==5 and r['B']['runs']==1 and r['B']['ms']==[3,5] and r['B']['ac']==172 and r['B']['ch']==3 and r['ov'] and 'The harvest is in' in r['txt'] and '172' in r['txt']
            and r['xp']==r['xr'] and r['ms2']==[] and r['give2']==[] and r['chest2']==[] and (not REAL or (r['ldg']==[172] and not r['toast'])),r)
        r=await E("""()=>{const g=window.fleGive,c=window.flcAdd;window.fleGive=undefined;window.flcAdd=undefined;P.flrb={};flrB();__f.go(1);S.flrA=40;S.flrC=1;over(1);const B1=JSON.parse(JSON.stringify(flrB()));
          window.fleGive=g;window.flcAdd=c;__fls.give=[];__fls.chest=[];const a0=fleAcorns(),c0=P.fcr|0;flrMenu(title);const paid=[fleAcorns()-a0,(P.fcr|0)-c0];const B2=JSON.parse(JSON.stringify(flrB()));flrMenu(title);const paid2=[fleAcorns()-a0,(P.fcr|0)-c0];return{B1:[B1.pa,B1.pc,B1.ac,B1.ch],B2:[B2.pa,B2.pc],give:__fls.give,chest:__fls.chest,paid,paid2}}""")
        chk('when the festival or chest part is missing, the run\'s 40 acorns and 1 chest wait in the save (P.flrb.pa / pc) and are paid when the mode page next opens with the parts present',r['B1']==[40,1,40,1] and r['B2']==[0,0] and r['give']==[[40,'Harvest Moon Rush']] and r['chest']==[[1,'Harvest Moon Rush']] and r['paid']==[40,1] and r['paid2']==[40,1],r)
        if REAL:await E(UNSPY)
        r=await E("""()=>{const out=[];const t=v=>{P.flrb=v;return JSON.stringify(flrB())};out.push(t(null),t(5),t([1,2]),t({best:-5,lv:'x',runs:2.7,ac:1e12,ch:'3',ms:[5,3,3,'8',99,-1,'z'],pa:-2,pc:4.9,tip:{flgust:1,bogus:1},junk:1}));P.flrb={};flrB();save();return out}""")
        rr=[json.loads(x) for x in r]
        chk('save repair (P.flrb): null, numbers and arrays become a clean record; negatives and text dropped, fractions floored, huge numbers capped, milestones only real levels (sorted, no duplicates), unknown keys removed',
            rr[0]['ms']==[] and rr[1]['best']==0 and rr[2]['runs']==0 and rr[3]['best']==0 and rr[3]['lv']==0 and rr[3]['runs']==2 and rr[3]['ac']==1e8 and rr[3]['ch']==3 and rr[3]['ms']==[3,5,8] and rr[3]['pa']==0 and rr[3]['pc']==4 and rr[3]['tip']=={'flgust':1} and 'junk' not in rr[3],rr)
        # ================= companions, gear, boons: a bot run =================
        r=await E("""()=>{const ids=Object.keys(PDEF||{});if(!ids.length)return null;const keep=P.pet;P.pet=ids[0];__f.go(1);const a=S.pet&&S.pet.cos;start(0,'gy');const b=S.pet&&S.pet.cos;start(0);const c=S.pet&&S.pet.cos;P.pet=keep;return[a,b,c,ids[0]]}""")
        chk('companions keep their powers in Harvest Moon Rush (cosmetic only in Monster Mash, as before; active in Endless)',r is None or (r[0]==0 and r[1]==1 and r[2]==0),r)
        paths=await E("()=>PK.map(p=>[p,Object.keys(WP).find(k=>WP[k].p===p)]).filter(x=>x[1])")
        r=await E("""(paths)=>{const keep=[P.weapon,P.armor,P.path,P.xp,P.pet];const out=[];const arms=Object.keys(AR);const pets=Object.keys(PDEF||{});
          paths.forEach(([p,w],i)=>{__f.seed(31+i);P.xp=Math.max(P.xp,1e7);P.weapon=w;P.path=p;P.armor=arms[(i*7)%arms.length];if(pets.length)P.pet=pets[i%pets.length];let err='';
           try{__f.go(1,{hp:60});for(let k=0;k<3;k++)boonApply(BOONS[(i*5+k*3)%BOONS.length]);const e=__f.bot(QUICKN,1/30,10);if(e)err='boon '+e}catch(x){err=x.message}out.push([p,w,P.armor,S.wave,S.kills,S.flrA,S.flrC,S.mode,err])});
          [P.weapon,P.armor,P.path,P.xp,P.pet]=keep;start(0);title();return out}""".replace('QUICKN','1500' if QUICK else '4200'),paths)
        chk('every weapon path (with a different armor, companion and three boons each) plays a Rush run with the typing bot: monsters fall, rounds and boons go by, no errors',
            all(not x[8] and x[4]>=8 and x[3]>=2 for x in r),r)
        # ================= a long bot run: bosses, chests, scene changes =================
        r=await E("""()=>{__f.seed(41);P.flrb={};flrB();__f.go(1,{hp:200});const lv=[],seen=new Set();let n=0;while(n++<QN&&S.mode!=='over'){__f.bot(30,1/30,12);lv.push(lvOf(S.wave));for(const e of S.en)seen.add(e.id)}
          return{wave:S.wave,lv:Math.max(...lv),A:S.flrA,C:S.flrC,seen:[...seen].filter(x=>/flr/.test(x)).length,bossSeen:[...seen].filter(x=>/^bflr/.test(x)),mode:S.mode,bg:S.bgL&&S.bgL.n}}""".replace('QN','260' if QUICK else '700'))
        chk('a long bot run reaches the second level or further: bosses fall and pay a chest each with acorns, the harvest cast and the bosses all show up, the field changes with the level',
            r['lv']>=2 and r['C']>=1 and r['A']>=30 and len(r['bossSeen'])>=1 and r['seen']>=6,r)
        await E("()=>{start(0);title()}")
        # ================= resume, pause, cheat guard =================
        r=await E("""()=>{__f.go(2);S.ban=null;rsSnap();const rr=rsRead();const lbl=rsLabel(rr);S.mode='over';reset();rsResume(rr);const out={lbl,flr:S.flr,gy:S.gy,z:lvDef(S.wave).n,ml:modeLabel()};
          S.mode='play';pause();out.p=(ov.querySelector('h2+p')||{}).textContent||'';const b=$('rs2');b.click();b.click();out.re=[S.flr,S.mode,lvOf(S.wave)];start(0);title();rsClear();return out}""")
        chk('resume: the unfinished-run offer says "Harvest Moon Rush, level 2", a resumed run is still a Rush on the Corn Maze; pause reads "Harvest Moon Rush, level 2, round 1 of 5" and Restart starts a new Rush',
            r['lbl']=='Harvest Moon Rush, level 2, round 1 of 5' and r['flr']==1 and r['gy']==1 and r['z']=='The Corn Maze' and r['ml'].startswith('Harvest Moon Rush') and r['p'].startswith('Harvest Moon Rush, level 2, round 1 of 5') and r['re']==[1,'play',1],r)
        await E("""()=>{__f.go(1,{inv:1});S.ban=null;S.en=[];S.spawnLeft=50;S.spawnT=1e9;const e=__f.mob('flrgourd','harvest',1000);e.tr=null;e.shd=0;S.tgt=null;window.__g0=P.gold;window.__x0=P.xp;window.TW_AC_TEST=1;return 1}""")
        await pg.keyboard.type('harvest',delay=25);await pg.wait_for_timeout(300)
        r=await E("()=>[P.gold-__g0,S.kills,S.mode]")
        await pg.keyboard.press('Escape');await pg.wait_for_timeout(500)
        q=await E("()=>{const b=document.getElementById('qt');if(!b)return null;const r=b.getBoundingClientRect();return[r.left+r.width/2,r.top+r.height/2]}")
        if q:
            await pg.mouse.click(q[0],q[1]);await pg.wait_for_timeout(600)
        r2=await E("()=>{const o=[P.xp-__x0,S.mode,!!document.querySelector('.flrov')];window.TW_AC_TEST=0;start(0);title();return o}")
        chk('with the cheat guard enforced (window.TW_AC_TEST), real typing in a Rush kills the monster and pays gold through the game\'s own code, and ending the run from the pause menu pays XP and shows the results',r[0]>0 and r[1]==1 and r2[0]>0 and r2[1]=='over' and r2[2],[r,r2])
        # ================= HUD and screenshots in play =================
        r=await E("""async()=>{__f.seed(51);__f.go(1,{inv:1});S.ban=null;await __f.sleep(2600);S.flrG.next=.01;await __f.sleep(700);return S.en.length}""")
        await shot('play_gust')
        r=await E("""async()=>{__f.seed(52);__f.go(3,{inv:1});S.ban=null;await __f.sleep(3600);return S.en.filter(e=>e.fp).length}""")
        await shot('play_leaves')
        r=await E("""async()=>{__f.seed(53);__f.go(2,{inv:1});S.ban=null;await __f.sleep(3600);const e=S.en.find(q=>q.fcs&&q.x<W-80);if(e){S.tgt=e;for(let i=0;i<=e.fcs[0];i++)key(e.w[i])}await __f.sleep(260);return !!e}""")
        await shot('play_crows')
        for lv in (1,2,3):
            r=await E("""async(lv)=>{__f.seed(60+lv);__f.go(lv,{inv:1});__f.round(5);S.spawnLeft=1;S.spawnT=0;S.flrA=35;S.flrC=lv;let n=0;while(n++<200&&!S.en.some(e=>e.boss&&e.state==='fight'))await __f.sleep(50);await __f.sleep(400);
              const b=S.en.find(e=>e.boss);if(!b)return null;const g=pillGeom(b),ny=b.y-b.h-176,hy=flrHudY()-16;return{id:b.id,pill:[g.x,g.y,g.w,g.h],name:ny,hud:[W-230,hy,216,32],chip:false}}""",lv)
            await shot('boss_%d'%lv)
            ok=r is not None and r['hud'][1]+r['hud'][3]<=r['name']-12
            chk('boss %d (%s): the HUD counters sit above the boss\'s name and sentence (no twist chip in boss rounds)'%(lv,r and r['id']),ok,r)
        r=await E("""()=>{__f.go(1);S.ban=null;const k=S.gyc[0];const y=ST&&ST.fps?186:162;return[k,y,flrHudY()]}""")
        chk('the twist chip and the run counters stack under the score panel without touching (chip 40 px from y=162, counters from y=210)',r[2]-16>=r[1]+40+4,r)
        # frame cost in play: a full draw with the Rush against plain Endless
        r=await E("""async()=>{const meas=async(kind)=>{__f.seed(71);if(kind==='flr')__f.go(1,{inv:1});else{start(0);S.hp=S.max=40;S.inv=1e9}S.ban=null;S.en=[];const ids=kind==='flr'?['flrpie','flrscare','flrgourd','flrcrow','flrwraith','flrbale']:['gob','gob','gob','gob','gob','gob'].map(x=>MON[x]?x:Object.keys(MON).find(k=>!MON[k].boss));
            ids.forEach((id,i)=>{const e=__f.mob(id,['pumpkin','acorn','cider','harvest','maple','squash'][i],520+i*170);flrTwistWord&&kind==='flr'&&flrTwistWord(e)});for(let i=0;i<20;i++)draw();const t0=performance.now();for(let i=0;i<60;i++){S.t+=1/60;draw()}return(performance.now()-t0)/60};
          const a=await meas('flr'),b=await meas('end');start(0);title();return[a,b]}""")
        chk('a full frame of the Rush with six monsters on screen costs no more than 1.6x a plain Endless frame with six monsters (%.2f ms vs %.2f ms)'%(r[0],r[1]),r[0]<=r[1]*1.6+.6,r)
        r=await E("""async()=>{const meas=(setup)=>{setup();S.ban=null;for(let i=0;i<20;i++){S.t+=1/60;draw()}const T=[];for(let k=0;k<8;k++){const t0=performance.now();for(let i=0;i<8;i++){S.t+=1/60;draw()}T.push((performance.now()-t0)/8)}T.sort((a,b)=>a-b);return T[4]};
          const boss=(id,mode,lv)=>()=>{if(mode==='flr')__f.go(lv,{inv:1});else{start(0,'gy');S.hp=S.max=40;S.inv=1e9;if(lv>1){S.wave=(lv-1)*5;S.en=[];startWave()}}S.wave=(lvOf(S.wave)-1)*5+4;S.en=[];startWave();S.en=[];S.spawnLeft=0;S.ban=null;
            const M=MON[id];S.en.push({id,role:0,boss:true,i:0,x:W-340,ph:.3,fl:0,lg:0,slip:0,y:GY,h:M.h,el:false,rg:false,hv:0,state:'fight',w:'the harvest moon has risen for you',tm:99,tmax:99,phs:3,used:[],q:[],pat:['volley'],pk:0,ak:9,tier:0,nm:M.n})};
          const out={};for(const [id,lv] of [['bflrgourd',1],['bflrking',2],['bflrgobble',3]])out[id]=+meas(boss(id,'flr',lv)).toFixed(2);for(const [id,lv] of [['bhorse',1],['bpumpking',2],['bhexmire',3]])out[id]=+meas(boss(id,'gy',lv)).toFixed(2);start(0);title();return out}""")
        mf=max(r['bflrgourd'],r['bflrking'],r['bflrgobble']);mg=max(r['bhorse'],r['bpumpking'],r['bhexmire'])
        chk('a full frame of each Rush boss fight costs no more than 1.5x the Monster Mash boss fights (median frame)',mf<=mg*1.5+.8,r)
        # ================= the mode page, the Choose a mode card, the over screen at three sizes =================
        for (w,h) in ((1600,900),(1280,720),(1024,640)):
            await pg.set_viewport_size({'width':w,'height':h});await pg.wait_for_timeout(250)
            r=await E("""async()=>{flrMenu(title);await __f.sleep(900);const m=document.querySelector('.flrm');const o=__rpuOvl(m);const wr=document.getElementById('wrap').getBoundingClientRect(),q=m.getBoundingClientRect();
              return{o,cards:m.querySelectorAll('.flrf').length,live:LIVE.filter(x=>x.cv.closest&&x.cv.closest('.flrm')).length,ms:m.querySelectorAll('.flrmi').length,go:!!$('flrgo')&&!$('flrgo').disabled,ch:!!$('flrch'),fe:!!$('flrfe'),low:typeof PFM==='function'&&PFM()==='low',inside:q.left>=wr.left-1&&q.right<=wr.right+1&&q.bottom<=wr.bottom+1,sw:document.documentElement.scrollWidth<=innerWidth+2}}""")
            await shot('menu_%d'%w)
            chk('mode page at %dx%d: three field cards (scene, twist, boss), the reward row, four milestones, Start / Harvest Chests / Harvest Festival / Back, live monster art; no overlaps, inside the stage, no sideways scroll'%(w,h),
                not r['o'] and r['cards']==3 and r['ms']==4 and r['go'] and r['ch'] and r['fe'] and (r['live']>=5 or r['low']) and r['inside'] and r['sw'],r)
            r=await E("""async()=>{__f.go(2);S.flrA=88;S.flrC=2;S.score=12345;over(1);await __f.sleep(700);const m=document.querySelector('.flrov');return{o:__rpuOvl(m),txt:m&&m.textContent.slice(0,400),btn:[!!$('flrgo'),!!$('flrch'),!!$('flrfe'),!!$('flrhm')]}}""")
            await shot('over_%d'%w)
            chk('results at %dx%d: "The harvest is in", the payout row (XP, gold, acorns, Harvest Chests), Rush again / Open chests / Harvest Festival / Home; no overlaps'%(w,h),not r['o'] and r['btn']==[True,True,True,True] and '88' in r['txt'],r)
            r=await E("""async()=>{title();await __f.sleep(300);modeSheet();await __f.sleep(500);const sh=document.getElementById('dkms');const b=sh.querySelector('[data-v="m"] #dmv');b.click();await __f.sleep(400);const c=sh.querySelector('#dmflr');const o=__rpuOvl(sh.querySelector('.dkpv[data-v="e"]'));
              const g=c&&c.parentElement,fe=g&&g.querySelector('#dmfl');return{c:!!c,first:fe?(g.firstElementChild===fe&&fe.nextElementSibling===c):c&&g.firstElementChild===c,rich:!!c&&c.classList.contains('flrcard')&&/LIMITED TIME/.test(c.textContent)&&/days? left|hours left/.test(c.textContent),vis:c&&c.offsetParent!==null,o,tile:(b.querySelector('small')||{}).textContent}}""")
            await shot('sheet_%d'%w)
            chk('Choose a mode › Events at %dx%d: the Harvest Moon Rush card (LIMITED TIME, days left) at the top, right after the Harvest Festival card when the festival part is there; the Events tile mentions it; no overlaps'%(w,h),r['c'] and r['first'] and r['rich'] and r['vis'] and not r['o'] and 'Harvest Moon Rush' in (r['tile'] or ''),r)
        await pg.set_viewport_size({'width':1600,'height':900});await pg.wait_for_timeout(250)
        r=await E("""async()=>{const sh=document.getElementById('dkms');sh.querySelector('#dmflr').click();await __f.sleep(500);const ok=!!document.querySelector('.flrm');$('flrgo').click();await __f.sleep(200);const run=[S.flr,S.mode];start(0);title();return[ok,run]}""")
        chk('the card opens the mode page and Start the Rush starts a Rush',r[0] and r[1]==[1,'play'],r)
        r=await E("""async()=>{window.FL_FORCE=-1;title();await __f.sleep(200);modeSheet();await __f.sleep(400);const c=!!document.getElementById('dmflr');dkClose(true);flrMenu(title);await __f.sleep(300);const dis=$('flrgo').disabled,t=$('flrgo').textContent;window.FL_FORCE=1;title();return[c,dis,t,flrOn()]}""")
        chk('after the festival (FL_FORCE=-1): no card in Choose a mode, the page says the event ended and cannot start a run',r[0] is False and r[1] is True and 'ended' in r[2],r)
        # ================= bestiary, mastery, help, DEV =================
        r=await E("""async()=>{for(const id of [...flrMobIds().flat(),...flrBossIds()])P.sn[id]=1;catalog(title,'Monsters');await __f.sleep(300);const h=[...ov.querySelectorAll('h3.sec')].find(x=>/Harvest Moon Rush/.test(x.textContent));const n=h?h.nextElementSibling.querySelectorAll('.mcd').length:0;
          const g=mbGroups().find(x=>x.n==='Harvest Moon Rush');const help=HELP.Modes.some(x=>x[0]==='Harvest Moon Rush');title();return{n,g:g&&g.ids.length,help}}""")
        chk('the Catalog lists a Harvest Moon Rush section with all twelve, Monster Mastery groups them (bosses included) and How to play explains the mode',r['n']==12 and r['g']==12 and r['help'],r)
        r=await E("""()=>{const h=dvxHTML();const has=/Harvest Moon Rush/.test(h)&&/x:flrgo/.test(h);P.flrb.ms=[3];dvxAct('flrms');const ms=flrB().ms.length;return[has,ms]}""")
        chk('DEV › Cheats has a Harvest Moon Rush section (open the page, start at a level, clear milestones, reset records)',r[0] and r[1]==0,r)
        r=await E("""async()=>{title();await __f.sleep(400);const dn=Date.now;Date.now=()=>new Date(2026,10,10,12).getTime();try{document.activeElement&&document.activeElement.blur&&document.activeElement.blur();window.dispatchEvent(new KeyboardEvent('keydown',{key:'m',bubbles:true}));await __f.sleep(300);return[hwOn(),!!document.querySelector('.flrm')]}finally{Date.now=dn;title()}}""")
        r2=await E("""()=>(HELP.Shortcuts.find(x=>x[0]==='R M')||[])[1]||''""")
        chk('after Halloween ends, M on the home screen opens Harvest Moon Rush (and How to play says so)',r[0] is False and r[1] and 'Harvest Moon Rush' in r2,[r,r2])
        await E("()=>{start(0);title()}")
        chk('no page errors',not er,er[:6])
        print('\n%d checks, %d failed'%(N[0],len(FAIL)));[print('  FAIL',f) for f in FAIL]
        await b.close()
asyncio.run(main())
