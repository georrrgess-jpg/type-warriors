# python3 t_pzb102.py [out.html] [--sheet OUT.png] : 10.2b The Crooked Cue ball sets you can read at a glance (97b5_pz_balls102.js).
# The owner's rule for every ball set, old or new (CLAUDE.md): solids coloured all over, stripes with a clearly lighter area above
# and below a coloured band, the 8 clearly the darkest ball with a high-contrast disc, the cue ball white, numbers readable.
# Every set in PZ_BALLS is painted by the real painter in 12 random orientations and measured pixel by pixel (lighting included),
# so a new set that breaks the rule fails here. Also: Ember Core's own look, paint and frame cost, the group badge and ball row in
# the HUD for both players, the turn-start pulse and the 8 marker on the table, Trick Shots and Orbit 8, the Cue Rack cards.
# Thresholds were set against Classic (the reference set): stripes' light area 0.29, solids' 0.015, 8 at 0.53 of the darkest other.
import asyncio,os,sys,base64
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
ARGS=[a for a in sys.argv[1:]]
SHEET=None
if '--sheet' in ARGS:i=ARGS.index('--sheet');SHEET=ARGS[i+1];del ARGS[i:i+2]
H='file://'+os.path.abspath(ARGS[0] if ARGS else os.path.join(HERE,'out.html'))
SCEN=os.path.join(HERE,'..','tools','pz','scen.js')
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:700]),flush=True)
    if not ok:FAIL.append(name)
PRE="()=>{RS_ASK=false;PZ_TUT_OFF=true;WCRELAYS=[];ST.perfAsked=1;PFW.asked=true;P.gold=100000;P.pz=null;save()}"
# light = bright and nearly neutral (white, ash, pearl, platinum); coloured = saturated. Disc zones (|lz|>.76) are left out of the body.
MEASURE=r"""()=>{const out={};
 const lin=c=>{c/=255;return c<=.04045?c/12.92:Math.pow((c+.055)/1.055,2.4)},relL=c=>.2126*lin(c[0])+.7152*lin(c[1])+.0722*lin(c[2]),
  CR=(a,b)=>{const x=relL(a),y=relL(b);return (Math.max(x,y)+.05)/(Math.min(x,y)+.05)},Y=(r,g,b)=>.2126*r+.7152*g+.0722*b,
  med=a=>{if(!a.length)return 0;const s=a.slice().sort((x,y)=>x-y);return s[s.length>>1]},medC=a=>[med(a.map(c=>c[0])),med(a.map(c=>c[1])),med(a.map(c=>c[2]))];
 for(const set of PZ_BALLS.map(b=>b.id)){pzbSetup(52,set);const P=PZ_BS,D=P.D;let s=12345;const rng=()=>{s=(s*16807)%2147483647;return s/2147483647};const Ms=[];for(let k=0;k<12;k++)Ms.push(pzbRandM(rng));
  const ball=[];
  for(let n=0;n<16;n++){let tot=0,light=0,col=0,cT=0,cTl=0,cB=0,cBl=0;const ys=[],sats=[];
   for(const M of Ms){pzbPaint(15,n,M);const d=P.ax.getImageData(15*D,0,D,D).data;
    for(let j=0;j<P.n;j++){if(P.al[j]<.98)continue;const wx=P.nx[j],wy=P.ny[j],wz=P.nz[j],lz=M[2]*wx+M[5]*wy+M[8]*wz,ly=M[1]*wx+M[4]*wy+M[7]*wz;if(n>0&&Math.abs(lz)>.76)continue;
     const o=P.idx[j]*4,r=d[o],g=d[o+1],b=d[o+2],y=Y(r,g,b),mx=Math.max(r,g,b),mn=Math.min(r,g,b),sat=mx?(mx-mn)/mx:0,L=y>=150&&sat<=.28;tot++;ys.push(y);sats.push(sat);if(L)light++;if(sat>=.3&&y>=35)col++;
     if(ly>.66){cT++;if(L)cTl++}else if(ly<-.66){cB++;if(L)cBl++}}}
   ball.push({light:light/tot,col:col/tot,medY:med(ys),medS:med(sats),capT:cT?cTl/cT:0,capB:cB?cBl/cB:0})}
  const num=[],disc8={};
  for(let n=1;n<16;n++){const M=pzbI();pzbPaint(15,n,M);const d=P.ax.getImageData(15*D,0,D,D).data,gl=P.gm[n],gC=[],bgC=[],bodyC=[];
   for(let j=0;j<P.n;j++){if(P.al[j]<.98)continue;const lx=P.nx[j],ly=P.ny[j],lz=P.nz[j],o=P.idx[j]*4,c=[d[o],d[o+1],d[o+2]];
    if(lz>.8){const u=lx*2,v=ly*2,q=u*u+v*v;if(q<.8){const gx=((u*.5+.5)*64)|0,gy=((v*.5+.5)*64)|0,gm=gl[gy*64+gx]/255;if(gm>.85)gC.push(c);else if(gm<.02)bgC.push(c)}}
    else if(lz<.62)bodyC.push(c)}
   const g=medC(gC),bg=medC(bgC),bo=medC(bodyC);num.push(+CR(g,bg).toFixed(2));if(n===8){disc8.cr=+CR(bg,bo).toFixed(2);disc8.num=+CR(g,bg).toFixed(2)}}
  const st=[9,10,11,12,13,14,15],so=[1,2,3,4,5,6,7],others=[...so,...st],r3=x=>+x.toFixed(3);
  const r={stripeLight:r3(Math.min(...st.map(n=>ball[n].light))),solidLight:r3(Math.max(...so.map(n=>ball[n].light))),pairGap:r3(Math.min(...so.map(n=>ball[n+8].light-ball[n].light))),
   capMin:r3(Math.min(...st.map(n=>Math.min(ball[n].capT,ball[n].capB)))),solidCol:r3(Math.min(...so.map(n=>ball[n].col))),stripeCol:r3(Math.min(...st.map(n=>ball[n].col))),
   y8:r3(ball[8].medY),yMin:r3(Math.min(...others.map(n=>ball[n].medY))),disc8:disc8.cr,num8:disc8.num,numMin:Math.min(...num),numWorst:num.indexOf(Math.min(...num))+1,
   cueY:r3(ball[0].medY),cueS:r3(ball[0].medS)};r.ratio8=r3(r.y8/Math.max(1,r.yMin));out[set]=r}
 pzbSetup(52,'classic');return out}"""
SHEETJS=r"""()=>{const sets=PZ_BALLS.map(b=>b.id),D=52,S=68,G=6,LW=170,views=[pzbRot(pzbRot(pzbI(),0,1,0,.28),1,0,0,-.22),pzbRot(pzbRot(pzbI(),1,0,0,1.05),0,1,0,.5)];
 const W=LW+16*(S+G)+G,Hh=sets.length*(views.length*(S+G)+14)+40,c=document.createElement('canvas');c.width=W;c.height=Hh;const g=c.getContext('2d');
 g.fillStyle='#14102c';g.fillRect(0,0,W,Hh);g.font='700 16px Poppins,sans-serif';g.fillStyle='#e8dcff';g.textAlign='center';for(let n=0;n<16;n++)g.fillText(String(n),LW+G+n*(S+G)+S/2,24);
 let y=36;for(const s of sets){const rows=views.length*(S+G);g.fillStyle='#1d6b45';g.fillRect(LW,y-4,W-LW,rows+4);g.fillStyle='#ffd45a';g.textAlign='left';g.font='400 26px "Pirata One",serif';g.fillText(PZ_BALLS.find(b=>b.id===s).n,10,y+rows/2+8);pzbSetup(D,s);
  views.forEach((M,vi)=>{for(let n=0;n<16;n++){pzbPaint(15,n,M);g.drawImage(PZ_BS.atlas,15*D,0,D,D,LW+G+n*(S+G),y+vi*(S+G),S,S)}});y+=rows+14}
 pzbSetup(52,'classic');return c.toDataURL('image/png')}"""
# put a match into a state with groups set: you have g ('s' or 't'); w8 = who is on the 8 (0 you, 1 them, -1 nobody)
SETUP=r"""(a)=>{const [g,w8,turn]=a;const B=PZ.B,st=PZ.st;st.brk=false;st.open=false;st.bih=false;st.turn=turn;st.grp=g==='s'?['s','t']:['t','s'];PZ.hadOpen=false;
 const pos={1:[260,120],2:[400,250],3:[540,80],4:[700,220],5:[780,90],6:[820,330],7:[460,170],8:[620,150],9:[300,300],10:[360,60],11:[700,370],12:[560,320],13:[180,220],14:[810,190],15:[200,380]};
 for(const b of B){if(b.id&&pos[b.id]){b.x=pos[b.id][0];b.y=pos[b.id][1];b.on=true;b.dirty=1;b.vx=b.vy=0}}
 const S=[1,2,3,4,5,6,7],T=[9,10,11,12,13,14,15],mg=g==='s'?S:T,og=g==='s'?T:S,off=w8===0?mg.concat(og.slice(2,4)):w8===1?og.concat(mg.slice(2,4)):[3,12,14];for(const id of off)B[id].on=false;PZ.tray=[];for(const b of B)if(!b.on&&b.id>0)pzTrayAdd(b.id,true);
 B[0].x=120;B[0].y=150;B[0].on=true;B[0].placed=false;if(PZ.ai)PZ.ai=null;pzBeginTurn(false);return true}"""
GOLD="(d,i)=>d[i+3]>40&&d[i]>200&&d[i+1]>160&&d[i+2]<150"
async def start(pg,opp,bset,venue=''):
    await pg.evaluate(PRE)
    await pg.evaluate("(a)=>{const [s,v]=a;const Z=PZS();Z.ballsets[s]=1;Z.balls=s;Z.beat.grizzle=1;Z.beat.gloop=1;Z.beat.bleep=1;if(v)Z.venue=v;save()}",[bset,venue])
    await pg.evaluate("(o)=>{casinoOpen();gameOpen('pz');pzStart({opp:o,practice:true,seed:7});setTimeout(()=>{const i=document.getElementById('pzintro');if(i)i.click()},500);0}",opp)
    await pg.wait_for_timeout(3500);await pg.evaluate("async()=>{await SC.ready()}")
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();er=[]
        pg=await b.new_page(viewport={'width':1600,'height':900})
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(H);await pg.wait_for_timeout(1500);await pg.evaluate(PRE);E=pg.evaluate
        await E("()=>document.fonts.ready");await pg.add_script_tag(path=SCEN)
        if SHEET:
            u=await E(SHEETJS);open(SHEET,'wb').write(base64.b64decode(u.split(',')[1]));print('sheet written to',SHEET)
        # ---------------------------------------------------------------- cost
        # best of five short trials per set (the machine may be busy with other work; a slow painter is slow in every trial)
        r=await E("""()=>{const R={};for(const s of PZ_BALLS.map(b=>b.id)){pzbSetup(52,s);for(let w=0;w<3;w++)for(let n=0;n<16;n++)pzbPaint(n,n,pzbRot(pzbI(),1,0,0,w));let best=1e9;for(let tr=0;tr<5;tr++){const t0=performance.now();for(let k=0;k<4;k++)for(let n=0;n<16;n++)pzbPaint(n,n,pzbRot(pzbI(),0,1,0,k*.3+n*.1+tr));best=Math.min(best,(performance.now()-t0)/4)}R[s]=+best.toFixed(2)}pzbSetup(52,'classic');return R}""")
        chk('repainting all 16 balls stays under 12 ms for every set (best of five, headless; the game repaints moving balls inside a 2.2 ms budget)',all(v<12 for v in r.values()),r)
        # ---------------------------------------------------------------- the rule, measured for every set
        R=await E(MEASURE)
        keys=['stripeLight','capMin','solidLight','pairGap','solidCol','stripeCol','y8','yMin','ratio8','disc8','num8','numMin','cueY','cueS']
        print('  %-8s'%'set'+''.join('%11s'%k for k in keys))
        for s,v in R.items():print('  %-8s'%s+''.join('%11s'%v[k] for k in keys))
        chk('every ball set has a material and a way to get it',await E("()=>PZ_BALLS.every(b=>PZ_BPAL[b.id]&&PZ_BPAL[b.id].kind&&b.n&&b.how)"))
        bad=lambda f:{s:{k:v[k] for k in ['stripeLight','capMin','solidLight','solidCol','stripeCol','pairGap','ratio8','y8','disc8','num8','numMin','numWorst','cueY','cueS']} for s,v in R.items() if not f(v)}
        x=bad(lambda v:v['stripeLight']>=.22 and v['capMin']>=.2 and v['stripeCol']>=.2)
        chk('stripes: a clearly light area above and below a coloured band (light area >= 0.22 of the ball, each cap >= 0.2, band coloured)',not x,x)
        x=bad(lambda v:v['solidLight']<=.08 and v['solidCol']>=.5)
        chk('solids: coloured all over (light area <= 0.08, coloured area >= 0.5)',not x,x)
        x=bad(lambda v:v['pairGap']>=.18 and v['stripeLight']-v['solidLight']>=.18)
        chk('solids and stripes are told apart by the light area (every stripe beats its solid and every solid by >= 0.18)',not x,x)
        x=bad(lambda v:v['ratio8']<=.62 and v['y8']<=60)
        chk('the 8 is clearly the darkest ball (median luminance <= 0.62 of the darkest other ball, and <= 60)',not x,x)
        x=bad(lambda v:v['disc8']>=4.5 and v['num8']>=4.5)
        chk('the 8 has a high-contrast disc (disc vs body and number vs disc contrast >= 4.5:1)',not x,x)
        x=bad(lambda v:v['numMin']>=4)
        chk('every number is readable on its disc (contrast >= 4:1 on every ball)',not x,x)
        x=bad(lambda v:v['cueY']>=150 and v['cueS']<=.12)
        chk('the cue ball is white in every set',not x,x)
        # ---------------------------------------------------------------- Ember Core
        r=await E("""()=>{pzbSetup(52,'lava');const P=PZ_BS,D=P.D,px=n=>{pzbPaint(15,n,pzbRot(pzbI(),1,0,0,1.2));return P.ax.getImageData(15*D,0,D,D).data};
          const cnt=(d,f)=>{let k=0,t=0;for(let i=0;i<d.length;i+=4){if(d[i+3]<250)continue;t++;if(f(d[i],d[i+1],d[i+2]))k++}return k/t};
          const glow=cnt(px(5),(r,g,b)=>r>200&&g>90),hot=[1,2,3,4,5,6,7].map(n=>cnt(px(n),(r,g,b)=>Math.max(r,g,b)>200)),seam=cnt(px(8),(r,g,b)=>r>180&&g>70&&b<120),dark8=cnt(px(8),(r,g,b)=>r+g+b<90);
          pzbSetup(52,'classic');return {glow:+glow.toFixed(2),hot:Math.min(...hot).toFixed(2),seam:+seam.toFixed(3),dark8:+dark8.toFixed(2),pal:[PZ_BPAL.lava.disc8,PZ_BPAL.lava.ring8,PZ_BPAL.lava.cap]}}""")
        chk('Ember Core: solids glow in their colour, the 8 is black obsidian with an ember seam, a bright disc and pale ash on the stripes',float(r['hot'])>=.35 and r['glow']>=.3 and r['seam']>=.01 and r['dark8']>=.5 and r['pal'][0][0]>230 and r['pal'][2][0]>200,r)
        # ---------------------------------------------------------------- the HUD and the table, tavern
        await start(pg,'grizzle','lava')
        r=await E("()=>[...['pzb2gm','pzb2go']].map(id=>{const e=document.getElementById(id);return e?e.textContent:null}).concat(getComputedStyle(document.getElementById('pzsm')).display)")
        chk('the HUD shows a group badge for both players, Open table before groups are set (the old small label is hidden)',r[0] and 'Open table' in r[0] and 'Open table' in r[1] and r[2]=='none',r)
        await E(SETUP,['s',-1,0]);await pg.wait_for_timeout(150)
        r=await E("""()=>{const q=s=>document.querySelector(s),bm=q('#pzbm'),bo=q('#pzbo');return {me:q('#pzb2gm').textContent,op:q('#pzb2go').textContent,meK:q('#pzb2gm .pzb2c').className,
          imgs:bm.querySelectorAll(':scope>img').length,out:bm.querySelectorAll(':scope>img.out').length,e8:!!bm.querySelector('.pzb2e8 img'),tgt:!!bm.querySelector('.pzb2e8.tgt'),oimgs:bo.querySelectorAll(':scope>img').length,hop:bm.classList.contains('hop')}}""")
        chk('groups set: "Solids · 6 left" for you and "Stripes · 5 left" for them, seven balls each with the potted ones faded and the 8 at the end',
            'Solids' in r['me'] and '6 left' in r['me'] and 'Stripes' in r['op'] and '5 left' in r['op'] and r['imgs']==7 and r['out']==1 and r['e8'] and not r['tgt'] and r['oimgs']==7,r)
        chk('your ball icons hop when your turn starts',r['hop'],r)
        r=await E("""()=>{const box=e=>{const b=e.getBoundingClientRect();return [b.left,b.top,b.right,b.bottom]},ov=(a,b)=>a[0]<b[2]-1&&b[0]<a[2]-1&&a[1]<b[3]-1&&b[1]<a[3]-1,bad=[];
          const nm=document.getElementById('pzno'),n0=nm.textContent,names=Object.values(PZ_REG).map(r=>r.n);
          for(const n of names){nm.textContent=n;const card=document.getElementById('pzco'),a=box(nm),t=box(card.querySelector('.pzturn')),p=box(card.querySelector('.pzpips')),g=box(card.querySelector('.pzb2g'));for(const [k,z] of [['turn chip',t],['pips',p],['badge',g]])if(ov(a,z))bad.push(n+' x '+k)}nm.textContent=n0;
          for(const c of ['pzcm','pzco']){const card=document.getElementById(c),cb=box(card),parts=[...card.querySelectorAll('.pzct b,.pzb2c,.pzb2g small,.pzballs,.pzturn,.pzpips,.pzav')].map(e=>[e.className||e.tagName,box(e)]);
           for(const [n,b] of parts){if(b[0]<cb[0]-1||b[2]>cb[2]+1||b[1]<cb[1]-1||b[3]>cb[3]+1)bad.push(c+' '+n+' outside');}
           for(let i=0;i<parts.length;i++)for(let j=i+1;j<parts.length;j++){const a=parts[i],z=parts[j];if(/pzb2c/.test(a[0])&&/pzb2g/.test(z[0]))continue;if(ov(a[1],z[1]))bad.push(c+' '+a[0]+' x '+z[0])}}return bad}""")
        chk('the HUD cards hold the name, badge, ball row, turn chip and pips without overlaps (every regular\'s name tried)',not r,r)
        # the turn-start pulse: drawn round your balls, not theirs
        r=await E("""()=>{const P=PZ.pzb2P,st=PZ.st,B=PZ.B;if(!P)return {none:1};const mine=B.filter(b=>b.on&&b.id&&b.id!==8&&pzGrp(b.id)===st.grp[0]).map(b=>b.id);
          const c=document.createElement('canvas');c.width=1600;c.height=900;const g=c.getContext('2d');PZ.pzb2P=Object.assign({},P);const sv=PZ.rk;PZ.rk=null;const ph=PZ.ph;PZ.ph='gap';pzb2Draw(g,P.t0+.3);PZ.ph=ph;PZ.rk=sv;const d=g.getImageData(0,0,1600,900).data,G=PZ_GOLD;
          const ring=id=>{const b=B[id];let k=0;for(let a=0;a<64;a++)for(const rr of [16,19,22,25]){const x=Math.round(PZ_G.x+b.x+Math.cos(a/64*6.283)*rr),y=Math.round(PZ_G.y+b.y+Math.sin(a/64*6.283)*rr),i=(y*1600+x)*4;if(G(d,i)){k++;break}}return k};
          return {ids:P.ids.slice().sort((a,b)=>a-b).join(),mine:mine.sort((a,b)=>a-b).join(),meRing:Math.min(...mine.map(ring)),themRing:Math.max(...B.filter(b=>b.on&&b.id>8).map(b=>ring(b.id)))}}""".replace('PZ_GOLD',GOLD))
        chk('when your turn starts your balls flash with a gold ring (theirs do not)',r.get('ids')==r.get('mine') and r.get('meRing',0)>=20 and r.get('themRing',99)<=4,r)
        # the opponent's turn: no pulse for you, their badge as before
        r=await E("()=>{PZ.pzb2P=null;const st=PZ.st;st.turn=1;pzBeginTurn(false);const ok=PZ.pzb2P==null;PZ.ai=null;return [ok,document.getElementById('pzcm').classList.contains('turn'),document.getElementById('pzco').classList.contains('turn')]}")
        chk('no pulse on the opponent\'s turn, and their card takes the turn highlight',r[0] and not r[1] and r[2],r)
        # on the 8
        await E(SETUP,['s',0,0]);await pg.wait_for_timeout(250)
        r=await E("""()=>{const q=s=>document.querySelector(s);return {me:q('#pzb2gm').textContent,k:q('#pzb2gm .pzb2c').className,tgt:!!q('#pzbm .pzb2e8.tgt'),ban:(q('#pzban')||{}).textContent,sub:(q('#pzsub')||{}).textContent,ids:PZ.pzb2P&&PZ.pzb2P.ids.join(),on8:pzrOn8(PZ.st)}}""")
        chk('on the 8: your badge turns to 8-BALL "your target", the 8 icon lights, a banner says so and the pulse goes to the 8',
            r['on8'] and '8-ball' in r['me'] and ' e' in r['k'] and r['tgt'] and 'On the 8' in r['ban'] and 'the 8' in r['sub'] and r['ids']=='8',r)
        r=await E("""()=>{const c=document.createElement('canvas');c.width=1600;c.height=900;const g=c.getContext('2d');PZ.pzb2P=null;PZ.ph='aim';PZ.mode='aim';pzb2Draw(g,PZ.t);const d=g.getImageData(0,0,1600,900).data,G=PZ_GOLD,e=PZ.B[8],cx=PZ_G.x+e.x,cy=PZ_G.y+e.y;
          let near=0,above=0,far=0;for(let y=0;y<900;y+=1)for(let x=0;x<1600;x+=1){const i=(y*1600+x)*4;if(!G(d,i))continue;const dd=Math.hypot(x-cx,y-cy);if(dd<26)near++;else if(Math.abs(x-cx)<12&&cy-y>18&&cy-y<44)above++;else far++}return {near,above,far}}""".replace('PZ_GOLD',GOLD))
        chk('the 8 wears a turning gold ring and a marker above it while it is your target (nothing drawn elsewhere)',r['near']>40 and r['above']>15 and r['far']==0,r)
        # the opponent on the 8
        await E(SETUP,['t',1,1]);await pg.wait_for_timeout(150)
        r=await E("()=>{PZ.ai=null;return [document.querySelector('#pzb2go').textContent,document.querySelector('#pzb2gm').textContent]}")
        chk('the opponent on the 8 shows "8-ball · on the 8" on their card',r[0].startswith('8-ball') and 'on the 8' in r[0] and 'Stripes' in r[1] and '5 left' in r[1],r)
        # frame cost while balls roll (Ember Core, the richest paint)
        await E("()=>{pzForfeit&&pzForfeit()}");await pg.wait_for_timeout(300)
        await start(pg,'gloop','lava')
        r=await E("""()=>{const t=[];PZ.speed=1;for(let i=0;i<10;i++)pzFrame(PZ.g);for(let i=0;i<60;i++){const a=performance.now();pzFrame(PZ.g);t.push(performance.now()-a)}t.sort((x,y)=>x-y);return [+t[30].toFixed(2),+t[57].toFixed(2)]}""")
        chk('aiming frame cost with Ember Core is small (median under 4 ms, p95 under 12 ms, headless)',r[0]<4 and r[1]<12,r)
        await E("()=>{PZ.aim.pow=.95;pzFireHuman()}");await pg.wait_for_timeout(700)
        r=await E("""()=>{const t=[];for(let i=0;i<3;i++)pzFrame(PZ.g);let mv=0;for(let i=0;i<40;i++){mv=Math.max(mv,PZ.B.filter(b=>b.dirty||Math.hypot(b.vx,b.vy)>1).length);const a=performance.now();pzFrame(PZ.g);t.push(performance.now()-a)}t.sort((x,y)=>x-y);return [+t[20].toFixed(2),+t[36].toFixed(2),mv]}""")
        chk('break frame cost with Ember Core while the balls roll (median under 8 ms, p90 under 18 ms, headless)',r[0]<8 and r[1]<18 and r[2]>=8,r)
        await E("()=>{PZ.speed=1;pzForfeit&&pzForfeit()}");await pg.wait_for_timeout(300)
        # ---------------------------------------------------------------- Orbit 8
        await start(pg,'bleep','galaxy','o8')
        await E(SETUP,['t',-1,0]);await pg.wait_for_timeout(200)
        r=await E("()=>[!!PZ.pzn,document.querySelector('#pzb2gm').textContent,document.querySelector('#pzb2go').textContent,!!PZ.pzb2P]")
        chk('Orbit 8: the same badges ("Stripes" for you, "Solids" for them) and the turn pulse',r[0] and 'Stripes' in r[1] and 'Solids' in r[2] and r[3],r)
        await E("()=>{pzForfeit&&pzForfeit()}");await pg.wait_for_timeout(300)
        # ---------------------------------------------------------------- Trick Shots
        await E("()=>{P.pz=null;save();casinoOpen();gameOpen('pz');pzStart({trick:0});0}");await pg.wait_for_timeout(2500)
        r=await E("()=>{const g=document.querySelector('#pzb2gm'),m=document.getElementById('pzm');return [m&&m.classList.contains('trick'),g?getComputedStyle(g).display:'none',getComputedStyle(document.getElementById('pzsm')).display,document.getElementById('pzsm').textContent]}")
        chk('Trick Shots: no group badge, the trick line (best stars) still shows',r[0] and r[1]=='none' and r[2]!='none' and 'Best' in r[3],r)
        await E("()=>{try{pzTrickLeave()}catch(e){}0}");await pg.wait_for_timeout(500)
        # ---------------------------------------------------------------- Cue Rack
        await E("()=>{if(typeof pzLeave==='function')pzLeave(true);P.pz=null;save();PZ.rackTab='balls';pzCueRack();0}");await pg.wait_for_timeout(1500)
        r=await E("""()=>{const cs=[...document.querySelectorAll('.pzkwall.balls canvas[data-sw]')];return cs.map(c=>{const d=c.getContext('2d').getImageData(0,0,300,100).data;let k=0;for(let i=3;i<d.length;i+=4)if(d[i]>200)k++;return k})}""")
        chk('the Cue Rack shows each set as a solid, its stripe and the 8 (eight cards drawn)',len(r)==8 and min(r)>6000,r)
        r=await E("()=>pzBallCard97.toString().includes('[1,9,8]')")
        chk('the set cards use 1, 9 and 8',r)
        chk('no page errors',not er,er)
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
