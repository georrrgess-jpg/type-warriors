# A minimal local Nostr relay for testing Wildcard's Nostr path (89q). It checks every event the way public relays do:
# the id must be the SHA-256 of the NIP-01 serialisation and the signature must be a valid BIP-340 Schnorr signature.
# The verifier below is written independently from the BIP-340 specification, not from the game's JavaScript.
# Run: PYTHONPATH=<dir with websockets> python3 t_nostr_relay.py [port] [--noverify] [--slow MS]   (default 18090).
# Storage like public relays (NIP-01): regular events are kept; replaceable ones (0, 3, 10000-19999) are kept per
# pubkey+kind and parameterised replaceable ones (30000-39999) per pubkey+kind+d, newest wins; ephemeral ones (20000-29999)
# are only forwarded. REQ sends the stored matches (newest first, up to limit) and then EOSE.
# --noverify stores events without checking them (a dishonest relay, for the leaderboard's forgery tests).
# --slow MS waits MS before answering a REQ (a slow relay). Test-only messages: ["TESTCLEAR"] empties the store.
import asyncio,hashlib,json,sys
import websockets
from t_nostr_relay_math import p,n,G,add,mul,lift_x,th,verify
SUBS={};ST={'ok':0,'bad':0,'fwd':0,'stored':0,'req':0};STORE={}
NOVERIFY='--noverify' in sys.argv;SLOW=0
if '--slow' in sys.argv:SLOW=int(sys.argv[sys.argv.index('--slow')+1])/1000
def skey(ev):
    k=ev['kind']
    if 20000<=k<30000:return None
    if k in (0,3) or 10000<=k<20000:return ('r',ev['pubkey'],k)
    if 30000<=k<40000:
        d=next((t[1] for t in ev.get('tags',[]) if len(t)>1 and t[0]=='d'),'')
        return ('p',ev['pubkey'],k,d)
    return ('e',ev['id'])
def store(ev):
    key=skey(ev)
    if key is None:return
    o=STORE.get(key)
    if o and (o['created_at']>ev['created_at'] or o['created_at']==ev['created_at'] and o['id']<=ev['id']):return
    STORE[key]=ev;ST['stored']=len(STORE)
def match(f,ev):
    if 'kinds' in f and ev['kind'] not in f['kinds']:return False
    if 'authors' in f and ev['pubkey'] not in f['authors']:return False
    if 'ids' in f and ev['id'] not in f['ids']:return False
    if 'since' in f and ev['created_at']<f['since']:return False
    if 'until' in f and ev['created_at']>f['until']:return False
    for k,v in f.items():
        if k.startswith('#'):
            vals=[t[1] for t in ev.get('tags',[]) if len(t)>1 and t[0]==k[1:]]
            if not any(x in v for x in vals):return False
    return True
async def handle(ws):
    SUBS[ws]={}
    try:
        async for raw in ws:
            try:a=json.loads(raw)
            except Exception:continue
            if a[0]=='TESTCLEAR':STORE.clear();ST['stored']=0;await ws.send(json.dumps(['OK','',True,'cleared']));continue
            if a[0]=='REQ':
                ST['req']+=1;SUBS[ws][a[1]]=a[2:]
                if SLOW:await asyncio.sleep(SLOW)
                sent=set()
                for f in a[2:]:
                    got=sorted((e for e in STORE.values() if match(f,e)),key=lambda e:-e['created_at'])[:min(int(f.get('limit',500)),500)]
                    for e in got:
                        if e['id']+e['sig'] in sent:continue
                        sent.add(e['id']+e['sig']);await ws.send(json.dumps(['EVENT',a[1],e]))
                await ws.send(json.dumps(['EOSE',a[1]]))
            elif a[0]=='CLOSE':SUBS[ws].pop(a[1],None)
            elif a[0]=='EVENT':
                ev=a[1];ser=json.dumps([0,ev['pubkey'],ev['created_at'],ev['kind'],ev['tags'],ev['content']],separators=(',',':'),ensure_ascii=False)
                idb=hashlib.sha256(ser.encode()).digest()
                try:ok=NOVERIFY or idb.hex()==ev['id'] and verify(bytes.fromhex(ev['pubkey']),idb,bytes.fromhex(ev['sig']))
                except Exception:ok=False
                ST['ok' if ok else 'bad']+=1;await ws.send(json.dumps(['OK',ev['id'],ok,'' if ok else 'invalid: bad id or signature']))
                if not ok:print('REJECTED',str(ev.get('id'))[:12],flush=True);continue
                store(ev)
                for c,subs in list(SUBS.items()):
                    for sid,fs in subs.items():
                        if any(match(f,ev) for f in fs):
                            ST['fwd']+=1
                            try:await c.send(json.dumps(['EVENT',sid,ev]))
                            except Exception:pass
    finally:SUBS.pop(ws,None)
async def report():
    while True:
        await asyncio.sleep(5);print('stats',ST,flush=True)
async def main():
    port=int(sys.argv[1]) if len(sys.argv)>1 and sys.argv[1].isdigit() else 18090
    async with websockets.serve(handle,'127.0.0.1',port,max_size=2**20):
        print('nostr relay on',port,flush=True);await report()
asyncio.run(main())
