/* ===== RUNESTONE RAMPARTS: the run =====
   A canvas mode like the caravan: S.mode='ramparts', S.rp=1; update/draw are wrapped to run rpUpdate/rpDraw. The map is the top 660 px
   of the stage; the DOM HUD (95f) sits over it and the dock below. Time runs at R.spd (1x or 2x) in fixed sub-steps.
   States: R.wst 'build' (between waves; a countdown after wave 1), 'run' (spawning and fighting), 'done' (finished).
   Towers stand on pads (R.pads[i].tw). Foes walk the road by distance s (air foes fly the same line, drawn higher).
   Typing fills R.cmd (0..100); 1/2/3 spend 100 on Overcharge, Slow Field and Repair (Repair once per wave). */
let RPX=null;
const rpRM=()=>{try{return ccReduce()}catch(e){return false}};
const rpClamp=(v,a,b)=>v<a?a:v>b?b:v;
const rpEase=k=>{k=rpClamp(k,0,1);return k*k*(3-2*k)};
function rpStart(id){const map=RP_MAP(id),r=RPP();try{if(ST.res==='auto')applyLayout()}catch(e){}
 reset();S.mode='ramparts';S.view='ramparts';S.rp=1;S.camp=0;
 const G=rpGeo(map),bake=rpBake(map);
 RPX={map,G,bake,tk:((RPX&&RPX.tk)||0)+1,t:0,time:0,spd:1,pause:false,over:false,result:null,rm:rpRM(),
  pads:G.pads.map((p,i)=>({x:p.x,y:p.y,i,tw:null,pop:0})),foes:[],shots:[],arcs:[],rings:[],burns:[],fields:[],fx:[],tx:[],uid:0,
  wave:0,wst:'build',wt:0,cd:0,q:[],keep:RPT.KEEP,supply:map.start,cmd:0,word:'',wi:0,bad:0,combo:0,maxCombo:0,ok:0,chars:0,words:0,
  repairUsed:false,sel:null,selPad:null,place:null,aim:null,hover:null,mx:-1,my:-1,shake:0,hitFl:0,banner:null,toast:null,
  kills:0,leaked:0,built:0,spent:0,abil:{over:0,slow:0,repair:0},free:false,fpCoins:0,fpWaves:0,seenFoe:{},bossT:0,lastFoe:null};
 rpNewWord();hide();try{ensureAudio()}catch(e){}try{inp.blur()}catch(e){}
 rpToast(`${map.n} · build towers on the stone pads, then start wave 1`,4,'#fff8e8');try{wrSfx('start')}catch(e){}
 if(typeof rpHudOn==='function')rpHudOn()}
function rpLeave(){const R=RPX;if(R&&!R.over){try{RPP().runs++;save()}catch(e){}}RPX=null;S.rp=0;if(S.mode==='ramparts'||S.mode==='over')S.mode='title';
 try{if(typeof rpHudOff==='function')rpHudOff()}catch(e){}try{pb.style.display='none';dkCorner()}catch(e){}}
function rpQuit(){rpLeave();if(typeof rampartsMenu==='function')rampartsMenu(title);else title()}
function rpRestart(){const id=RPX?RPX.map.id:'moss';rpLeave();rpStart(id)}
{const t0=title;title=function(){if(S.rp||RPX)rpLeave();return t0.apply(this,arguments)}}
{const u0=update;update=function(dt){if(S.rp&&RPX)return rpUpdate(dt);return u0.apply(this,arguments)}}
{const d0=draw;draw=function(){if(S.rp&&RPX)return rpDraw();return d0.apply(this,arguments)}}
/* ---------- helpers ---------- */
function rpToast(txt,dur,c){if(RPX)RPX.toast={txt,t:dur||2,d:dur||2,c:c||'#ffd45a'}}
function rpText(x,y,s,c,sz){const R=RPX;if(!R)return;if(R.tx.length>60)R.tx.shift();R.tx.push({x,y,s,c,sz:sz||20,t:0,d:1})}
function rpRing(x,y,c,max,w){const R=RPX;if(R.rings.length>40)R.rings.shift();R.rings.push({x,y,t:0,d:.5,max:max||80,c:c||'#ffd45a',w:w||4})}
function rpSfx(k,v){try{switch(k){
 case 'build':beep(330,.07,'triangle',.5);setTimeout(()=>beep(495,.09,'triangle',.5),70);break;
 case 'up':beep(523,.07,'triangle',.5);setTimeout(()=>beep(659,.07,'triangle',.5),70);setTimeout(()=>beep(880,.12,'triangle',.5),140);break;
 case 'sell':beep(880,.05,'triangle',.4);setTimeout(()=>beep(660,.07,'triangle',.4),60);break;
 case 'bolt':beep(1500+Math.random()*200,.025,'square',.06);break;
 case 'boom':beep(90+Math.random()*30,.12,'sawtooth',.18);break;
 case 'zap':beep(1900+Math.random()*400,.04,'sawtooth',.07);break;
 case 'frost':beep(2200,.05,'sine',.06);break;
 case 'kill':break;
 case 'leak':beep(80,.25,'sawtooth',.7);break;
 case 'word':beep(784,.06,'triangle',.4);setTimeout(()=>beep(1046,.08,'triangle',.4),60);break;
 case 'key':try{wrSfx('key',v)}catch(e){}break;
 case 'miss':try{wrSfx('miss')}catch(e){}break;
 case 'ability':beep(392,.08,'triangle',.6);setTimeout(()=>beep(784,.2,'triangle',.6),70);setTimeout(()=>beep(1568,.3,'sine',.4),150);break;
 case 'no':beep(150,.06,'triangle',.4);break;
 case 'wave':beep(440,.1,'triangle',.5);setTimeout(()=>beep(660,.14,'triangle',.5),120);break;
 case 'clear':beep(660,.08,'triangle',.5);setTimeout(()=>beep(880,.1,'triangle',.5),90);setTimeout(()=>beep(1320,.18,'triangle',.45),180);break;
 case 'boss':try{jingle('boss')}catch(e){}break;
 case 'win':try{jingle('win')}catch(e){}break;
 case 'lose':try{jingle('lose')}catch(e){}break}}catch(e){}}
const rpLive=e=>!e.dead;
function rpPos(R,e){const p=rpAt(R.G,e.s),o=e.off||0;return{x:p.x-Math.sin(p.a)*o,y:p.y+Math.cos(p.a)*o,a:p.a}}
/* ---------- words ---------- */
function rpNewWord(){const R=RPX;const L=RP_WORDS,lo=R.wave<4?3:4,hi=R.wave<4?6:R.wave<10?8:9;let w='',n=0;
 do{w=L[Math.random()*L.length|0];n++}while((w.length<lo||w.length>hi||w===R.word)&&n<40);R.word=w;R.wi=0;R.bad=0}
function rpKey(c){const R=RPX;if(!R||R.pause||R.over)return;c=String(c||'').toLowerCase();if(!/^[a-z]$/.test(c))return;R.chars++;
 if(R.word[R.wi]===c){R.wi++;R.ok++;rpSfx('key',R.combo);
  if(R.wi>=R.word.length){R.words++;R.combo++;R.maxCombo=Math.max(R.maxCombo,R.combo);const gain=Math.round((12+3*R.word.length)*(R.combo>=5?1.25:1));
   R.cmd=Math.min(RPT.CMD,R.cmd+gain);R.supply+=RPT.WORD_SUP;rpSfx('word');R.wordFx=1;if(typeof rpHudWord==='function')rpHudWord(gain);rpNewWord()}}
 else{R.bad=1;R.badT=.3;R.combo=0;rpSfx('miss')}
 if(typeof rpHudType==='function')rpHudType()}
/* ---------- building ---------- */
const rpCost=(type,tier)=>RP_TW[type].cost[tier-1];
function rpBuild(pad,type){const R=RPX;if(!R||R.over||!pad||pad.tw)return false;const c=rpCost(type,1);if(R.supply<c){rpSfx('no');rpToast('Not enough supply',1.2,'#ff8a9a');return false}
 R.supply-=c;R.spent+=c;R.built++;pad.tw={type,tier:1,skin:rpSkinOf(type),x:pad.x,y:pad.y,pad,cd:.3,aim:0,fire:0,over:0,kills:0,dmg:0,prio:'first',pop:0,spent:c,ring:0,ph:Math.random()*10};try{rpTowerWarm(type,1,pad.tw.skin)}catch(e){}
 rpRing(pad.x,pad.y,RP_TW[type]?'#ffd45a':'#fff',90,5);try{ptBurst(R.fx,pad.x,pad.y,14,['#c8b89a','#8a7a6a','#ffd45a'],{v:200,s:4,up:1,g:400})}catch(e){}
 rpSfx('build');R.sel=pad.tw;R.selPad=null;R.place=null;return true}
function rpUpgrade(tw){const R=RPX;if(!R||!tw||tw.tier>=3)return false;const c=rpCost(tw.type,tw.tier+1);if(R.supply<c){rpSfx('no');rpToast('Not enough supply',1.2,'#ff8a9a');return false}
 R.supply-=c;R.spent+=c;tw.spent+=c;tw.tier++;tw.pop=0;try{rpTowerWarm(tw.type,tw.tier,tw.skin)}catch(e){}rpRing(tw.x,tw.y-40,'#ffd45a',120,6);try{ptBurst(R.fx,tw.x,tw.y-50,22,['#ffd45a','#fff4c8',RPTW[tw.type].col],{v:260,s:4.5,k:'star'})}catch(e){}
 rpText(tw.x,tw.y-110,`Tier ${tw.tier}!`,'#ffd45a',26);rpSfx('up');return true}
function rpSell(tw){const R=RPX;if(!R||!tw)return;const v=Math.round(tw.spent*RPT.SELL);R.supply+=v;tw.pad.tw=null;if(R.sel===tw)R.sel=null;
 rpText(tw.x,tw.y-60,`+${v}`,'#ffd45a',24);try{ptBurst(R.fx,tw.x,tw.y-20,16,['#8a7a6a','#c8b89a'],{v:180,s:4,up:1,g:400})}catch(e){}rpSfx('sell')}
/* ---------- waves ---------- */
function rpWaveStart(){const R=RPX;if(!R||R.over||R.wst!=='build')return;
 if(R.wave>0&&R.cd>0){const b=Math.ceil(R.cd)*RPT.EARLY;if(b>0){R.supply+=b;rpText(800,250,`Early call +${b}`,'#ffd45a',26)}}
 R.wave++;R.wst='run';R.wt=0;R.repairUsed=false;R.q=[];const W=rpWave(R.map,R.wave);
 for(const g of W)for(let i=0;i<g.n;i++)R.q.push({id:g.id,at:g.at+i*g.gap});R.q.sort((a,b)=>a.at-b.at);
 const boss=W.some(g=>g.id==='behemoth');R.banner={txt:R.free?`Freeplay wave ${R.wave-R.map.waves}`:boss?'The Behemoth comes!':`Wave ${R.wave}`,sub:boss?'Slow it, focus it, keep Command for Repair':rpWaveSub(W),t:0,d:2.2,boss};
 rpSfx(boss?'boss':'wave');
 for(const g of W)if(!R.seenFoe[g.id]&&!RPP().hint[g.id]){R.seenFoe[g.id]=1;if(typeof rpHudFoeCard==='function')rpHudFoeCard(g.id)}}
function rpWaveSub(W){const n=W.reduce((a,g)=>a+g.n,0),ids=[...new Set(W.map(g=>g.id))];return `${n} monsters · ${ids.map(i=>RPMOB[i]?RPMOB[i].n:i).join(', ')}`}
function rpSpawn(id){const R=RPX,F=RP_FOE[id];if(!F)return null;const k0=rpHpK(R.map,R.wave),k=F.boss?1+(k0-1)*.6:k0,hp=Math.round(F.hp*k*(R.free?1+.05*(R.wave-R.map.waves):1));
 const e={id,uid:++R.uid,s:-30-Math.random()*20,hp,mx:hp,sp:F.sp*R.map.spk*(.94+Math.random()*.12),air:!!F.air,armor:F.armor||0,bounty:Math.round(F.bounty*rpBountyK(R.wave)),dmg:F.dmg,
  ph:Math.random(),fl:0,slowT:0,slowK:0,stun:0,dead:0,dk:0,off:(Math.random()-.5)*(F.boss?6:22),heal:F.heal?F.healT:0,boss:!!F.boss};
 if(e.boss){R.boss=e;R.bossT=0}R.foes.push(e);return e}
function rpWaveDone(){const R=RPX;R.wst='build';const b=rpWaveBonus(R.wave);R.supply+=b;R.cd=RPT.BUILD_T;
 if(R.free){R.fpWaves++;const c=20+R.fpWaves*6;R.fpCoins+=c;rpText(800,230,`Freeplay wave cleared · +${c} coins banked`,'#ffd45a',26)}
 else rpText(800,230,`Wave ${R.wave} cleared · +${b} supply`,'#ffd45a',28);
 rpSfx('clear');if(!R.free&&R.wave>=R.map.waves){rpVictory();return}}
function rpVictory(){const R=RPX;if(R.wst==='done')return;R.wst='done';R.won=true;R.banner={txt:'Victory!',sub:'The keep stands',t:0,d:2.6,win:1};rpSfx('win');
 try{for(let i=0;i<5;i++)setTimeout(()=>{if(RPX===R)ptBurst(R.fx,300+Math.random()*1000,200+Math.random()*250,30,['#ffd45a','#fff4c8','#5ab8ff','#ff8a3a'],{v:340,s:5,k:'star'})},i*220)}catch(e){}
 R.winKeep=R.keep;setTimeout(()=>{if(RPX===R&&!R.over){if(typeof rpHudVictory==='function')rpHudVictory();else rpFinish(true)}},2500)}
function rpDefeat(){const R=RPX;if(R.wst==='done')return;R.wst='done';R.won=false;R.banner={txt:R.free?'The keep has fallen':'The keep has fallen',sub:R.free?`Freeplay ends after ${R.fpWaves} waves`:`Wave ${R.wave} of ${R.map.waves}`,t:0,d:2.4,lose:1};
 rpSfx('lose');setTimeout(()=>{if(RPX===R&&!R.over)rpFinish(false)},2400)}
/* ---------- abilities ---------- */
function rpAbility(k,auto){const R=RPX;if(!R||R.over||R.pause||R.wst==='done')return false;
 if(R.cmd<RPT.CMD){rpSfx('no');rpToast(`Type words to charge Command (${Math.floor(R.cmd)}/${RPT.CMD})`,1.6,'#9fd0ff');return false}
 if(k==='repair'){if(R.repairUsed){rpSfx('no');rpToast('Repair is used up until the next wave',1.6,'#ff8a9a');return false}if(R.keep>=RPT.KEEP){rpSfx('no');rpToast('The keep is already whole',1.4,'#9fd0ff');return false}
  R.cmd=0;R.repairUsed=true;R.keep=Math.min(RPT.KEEP,R.keep+RPT.REPAIR);R.abil.repair++;rpRing(1468,420,'#7dffb0',200,7);rpText(1468,330,`+${RPT.REPAIR} keep`,'#7dffb0',30);rpSfx('ability');return true}
 if(k==='over'){let tw=R.sel;if(!tw||auto===undefined&&!tw){}if(!tw){if(!auto){R.aim='over';rpToast('Click a tower to Overcharge it (or press 1 again)',2.4,'#ffd45a');return false}tw=rpBusiest()}
  if(!tw){rpSfx('no');rpToast('Build a tower first',1.4,'#ff8a9a');return false}
  R.cmd=0;R.aim=null;tw.over=RPT.OVER_T;R.abil.over++;rpRing(tw.x,tw.y-40,'#ffd45a',140,7);rpText(tw.x,tw.y-120,'OVERCHARGE!','#ffd45a',30);rpSfx('ability');return true}
 if(k==='slow'){let pt=null;if(auto&&typeof auto==='object')pt=auto;else if(auto===true){const L=R.foes.filter(e=>!e.dead&&!e.air).sort((a,b)=>b.s-a.s)[0];if(L){const p=rpAt(R.G,Math.min(R.G.len-60,L.s+70));pt={x:p.x,y:p.y}}}
  if(!pt){R.aim='slow';rpToast('Click the road to place the Slow Field (or press 2 again)',2.4,'#9fe8ff');return false}
  R.cmd=0;R.aim=null;R.fields.push({x:pt.x,y:pt.y,r:RPT.SLOW_R,t:0,d:RPT.SLOW_T});R.abil.slow++;rpRing(pt.x,pt.y,'#9fe8ff',RPT.SLOW_R*1.3,6);rpSfx('ability');return true}
 return false}
function rpBusiest(){const R=RPX;let best=null,bs=-1;for(const p of R.pads){const tw=p.tw;if(!tw)continue;const rg=RP_TW[tw.type].range[tw.tier-1];let n=0;for(const e of R.foes)if(!e.dead){const q=rpPos(R,e);if(rpD2(q.x,q.y,tw.x,tw.y)<rg*rg)n++}
  const sc=n*10+tw.tier*3+(RP_TW[tw.type].dmg[tw.tier-1]/RP_TW[tw.type].cd[tw.tier-1])*.01;if(sc>bs){bs=sc;best=tw}}return best}
/* ---------- combat ---------- */
function rpHurt(e,dmg,ap,src){const R=RPX;if(e.dead)return;const arm=Math.max(0,e.armor-(ap||0));const d=Math.max(dmg*.3,dmg-arm);e.hp-=d;e.fl=.1;if(src){src.dmg+=d}
 if(e.hp<=0)rpKillFoe(e,src)}
function rpKillFoe(e,src){const R=RPX;if(e.dead)return;e.dead=1;e.dk=0;R.kills++;if(src)src.kills++;R.supply+=e.bounty;const p=rpPos(R,e);
 rpText(p.x,p.y-(e.air?70:40),`+${e.bounty}`,'#ffd45a',e.boss?34:18);
 try{ptBurst(R.fx,p.x,p.y-(e.air?40:20),e.boss?60:10,e.id==='ooze'||e.id==='oozelet'?['#7affc8','#3ad89a']:e.id==='golem'||e.id==='behemoth'?['#8a7a6a','#ffb04a']:['#ffd45a','#ffffff'],{v:e.boss?420:200,s:e.boss?6:3.5})}catch(x){}
 const F=RP_FOE[e.id];if(F.split){for(let i=0;i<F.splitN;i++){const c=rpSpawn(F.split);if(c){c.s=e.s-8-i*14;c.off=e.off+(i?10:-10);c.hp=c.mx=Math.round(RP_FOE[F.split].hp*rpHpK(R.map,R.wave));c.ph=Math.random()}}}
 if(e.boss){R.shake=Math.max(R.shake,18);rpRing(p.x,p.y-60,'#ffb04a',260,9);rpText(800,260,'The Behemoth falls!','#ffd45a',40);R.boss=null}}
const rpD2=(ax,ay,bx,by)=>{const dy=(ay-by)/RPFX.sq;return(ax-bx)*(ax-bx)+dy*dy};
function rpTarget(R,tw,rg,airOk,groundOk,prio,preferAir){let best=null,bv=-1e9;const r2=rg*rg;
 for(const e of R.foes){if(e.dead||e.s<0)continue;if(e.air?!airOk:!groundOk)continue;const p=rpPos(R,e),d2=rpD2(p.x,p.y,tw.x,tw.y);if(d2>r2)continue;
  let v=prio==='strong'?e.hp:prio==='close'?-d2:e.s;if(preferAir&&e.air)v+=1e7;if(v>bv){bv=v;best=e}}return best}
function rpFire(R,tw,dt){const T=RP_TW[tw.type],i=tw.tier-1,rg=T.range[i];tw.over=Math.max(0,tw.over-dt);tw.fire=Math.max(0,tw.fire-dt*3);
 tw.cd-=dt*(tw.over>0?RPT.OVER_K:1);if(tw.cd>0)return;
 const dmgK=tw.over>0?1.15:1;
 if(tw.type==='frost'){let n=0;for(const e of R.foes){if(e.dead||e.air||e.s<0)continue;const p=rpPos(R,e);if(rpD2(p.x,p.y,tw.x,tw.y)>rg*rg)continue;n++;
   const chill=e.slowT>0;e.slowK=Math.max(e.slowK,T.slow[i]);e.slowT=Math.max(e.slowT,T.slowT[i]);rpHurt(e,T.dmg[i]*dmgK*(i===2&&chill?2:1),0,tw)}
  if(n){tw.cd=T.cd[i];tw.fire=1;R.rings.push({x:tw.x,y:tw.y,t:0,d:.55,max:rg,c:'#9fe8ff',w:3,frost:1,skin:tw.skin});if(Math.random()<.5)rpSfx('frost')}else tw.cd=.12;return}
 const e=rpTarget(R,tw,rg,!!T.air,!!T.ground,tw.prio,tw.type==='bell');if(!e){tw.cd=.1;return}
 const p=rpPos(R,e),ty=p.y-(e.air?40:18);tw.aim=Math.atan2(ty-(tw.y-40),p.x-tw.x);tw.cd=T.cd[i];tw.fire=1;
 if(tw.type==='ballista'){R.shots.push({k:'bolt',x:tw.x+Math.cos(tw.aim)*30,y:tw.y-46+Math.sin(tw.aim)*30,e,sp:1000,dmg:T.dmg[i]*dmgK,ap:T.ap[i],pierce:i===2,tw,skin:tw.skin,life:1.2,a:tw.aim});rpSfx('bolt')}
 else if(tw.type==='brazier'){const lead=Math.min(R.G.len,e.s+e.sp*(e.slowT>0?1-e.slowK:1)*.5),lp=rpAt(R.G,lead);
  R.shots.push({k:'ember',x0:tw.x,y0:tw.y-60,x1:lp.x,y1:lp.y,t:0,d:.5,dmg:T.dmg[i]*dmgK,r:T.splash[i],burn:T.burn[i],tw,skin:tw.skin})}
 else if(tw.type==='bell'){const hit=[e];let cur=e;for(let k=1;k<T.chain[i];k++){let nb=null,nd=130*130;const cp=rpPos(R,cur);for(const f of R.foes){if(f.dead||hit.includes(f)||f.s<0)continue;const q=rpPos(R,f),d2=(q.x-cp.x)**2+(q.y-cp.y)**2;if(d2<nd){nd=d2;nb=f}}if(!nb)break;hit.push(nb);cur=nb}
  const pts=[{x:tw.x,y:tw.y-92}];for(const f of hit){const q=rpPos(R,f);pts.push({x:q.x,y:q.y-(f.air?40:20)});rpHurt(f,T.dmg[i]*dmgK*(f.air?T.airK:1),2,tw);if(i===2&&f.air)f.stun=.6}
  R.arcs.push({pts,t:0,d:.2,skin:tw.skin});rpSfx('zap')}}
function rpShots(R,dt){for(const s of R.shots){if(s.k==='bolt'){s.life-=dt;let tx,ty;if(!s.e.dead){const p=rpPos(R,s.e);tx=p.x;ty=p.y-(s.e.air?40:18);s.lx=tx;s.ly=ty}else{tx=s.lx;ty=s.ly}
   if(tx===undefined){s.done=1;continue}const dx=tx-s.x,dy=ty-s.y,d=Math.hypot(dx,dy),st=s.sp*dt;s.a=Math.atan2(dy,dx);
   if(d<=st+6||s.life<=0){s.done=1;if(!s.e.dead){rpHurt(s.e,s.dmg,s.ap,s.tw);try{ptBurst(R.fx,tx,ty,5,['#9fdcff','#ffffff'],{v:160,s:3})}catch(e){}
     if(s.pierce){let nb=null,nd=80*80;for(const f of R.foes){if(f.dead||f===s.e)continue;const q=rpPos(R,f),d2=(q.x-tx)**2+(q.y-ty)**2;if(d2<nd){nd=d2;nb=f}}if(nb)rpHurt(nb,s.dmg*.6,s.ap,s.tw)}}}
   else{s.x+=dx/d*st;s.y+=dy/d*st}}
  else if(s.k==='ember'){s.t+=dt;if(s.t>=s.d){s.done=1;for(const e of R.foes){if(e.dead||e.air)continue;const p=rpPos(R,e);if(rpD2(p.x,p.y,s.x1,s.y1)<=s.r*s.r)rpHurt(e,s.dmg,0,s.tw)}
    R.rings.push({x:s.x1,y:s.y1,t:0,d:.45,max:s.r,c:'#ff8a3a',w:4,boom:1,skin:s.skin});if(s.burn)R.burns.push({x:s.x1,y:s.y1,r:s.r*.8,t:0,d:2.6,dps:s.burn,tw:s.tw});
    try{ptBurst(R.fx,s.x1,s.y1-6,8,['#ffb04a','#ff6a1a','#ffd45a'],{v:200,s:4,up:1,g:300})}catch(e){}if(Math.random()<.6)rpSfx('boom')}}}
 R.shots=R.shots.filter(s=>!s.done)}
/* ---------- update ---------- */
function rpUpdate(dt){const R=RPX;if(!R)return;try{if(typeof rpHudTick==='function')rpHudTick()}catch(e){}if(R.pause)return;dt=Math.min(dt,.05);S.t+=dt;R.t+=dt;
 const n=R.wst==='run'?R.spd:1;for(let k=0;k<n;k++)rpStep(R,dt);
 R.shake=Math.max(0,R.shake-dt*40);R.hitFl=Math.max(0,R.hitFl-dt*2);R.badT=Math.max(0,(R.badT||0)-dt);R.wordFx=Math.max(0,(R.wordFx||0)-dt*3);
 for(const t of R.tx)t.t+=dt;R.tx=R.tx.filter(t=>t.t<t.d);if(R.toast){R.toast.t-=dt;if(R.toast.t<=0)R.toast=null}if(R.banner){R.banner.t+=dt;if(R.banner.t>R.banner.d)R.banner=null}}
function rpStep(R,dt){R.time+=dt;
 if(R.wst==='build'&&R.wave>0&&!R.over){R.cd-=dt;if(R.cd<=0)rpWaveStart()}
 if(R.wst==='run'){R.wt+=dt;while(R.q.length&&R.q[0].at<=R.wt)rpSpawn(R.q.shift().id)}
 for(const f of R.fields)f.t+=dt;R.fields=R.fields.filter(f=>f.t<f.d);
 for(const b of R.burns){b.t+=dt;for(const e of R.foes){if(e.dead||e.air)continue;const p=rpPos(R,e);if(rpD2(p.x,p.y,b.x,b.y)<b.r*b.r)rpHurt(e,b.dps*dt,99,b.tw)}}R.burns=R.burns.filter(b=>b.t<b.d);
 /* foes */
 for(const e of R.foes){if(e.dead){e.dk+=dt*2.6;continue}e.fl=Math.max(0,e.fl-dt);e.stun=Math.max(0,e.stun-dt);
  let k=1;if(e.slowT>0){e.slowT-=dt;k=1-e.slowK;if(e.slowT<=0)e.slowK=0}
  if(!e.air&&R.fields.length){const p=rpPos(R,e);for(const f of R.fields)if(rpD2(p.x,p.y,f.x,f.y)<f.r*f.r){k=Math.min(k,1-RPT.SLOW_K);e.inField=.2}}
  if(e.stun>0)k=0;e.s+=e.sp*k*dt;e.ph=(e.ph+dt*e.sp*k/(e.air?60:52)+(e.air?dt*1.6:0))%1;
  if(e.heal>0){e.heal-=dt;if(e.heal<=0){const F=RP_FOE[e.id];e.heal=F.healT;const p=rpPos(R,e);let n=0;for(const f of R.foes){if(f.dead||f===e||f.hp>=f.mx)continue;const q=rpPos(R,f);if((q.x-p.x)**2+(q.y-p.y)**2<F.healR*F.healR){f.hp=Math.min(f.mx,f.hp+f.mx*F.heal);n++}}
    if(n)R.rings.push({x:p.x,y:p.y,t:0,d:.6,max:F.healR,c:'#b47aff',w:3,heal:1})}}
  if(e.s>=R.G.len){e.dead=1;e.dk=1;e.leak=1;R.leaked++;R.keep=Math.max(0,R.keep-e.dmg);R.shake=Math.max(R.shake,e.boss?24:8);R.hitFl=1;rpSfx('leak');
   rpText(1468,400,`-${e.dmg}`,'#ff5a6a',e.boss?44:28);if(e.boss)R.boss=null;if(R.keep<=0&&R.wst!=='done')rpDefeat()}}
 R.foes=R.foes.filter(e=>!e.dead||e.dk<1);
 /* towers */
 for(const p of R.pads){if(p.tw){p.tw.pop=Math.min(1,p.tw.pop+dt*3);rpFire(R,p.tw,dt)}}
 rpShots(R,dt);for(const a of R.arcs)a.t+=dt;R.arcs=R.arcs.filter(a=>a.t<a.d);for(const r of R.rings)r.t+=dt;R.rings=R.rings.filter(r=>r.t<r.d);
 if(R.wst==='run'&&!R.q.length&&!R.foes.some(e=>!e.dead))rpWaveDone()}
/* ---------- draw ---------- */
function rpDraw(){const R=RPX,c=ctx;if(!R)return;if(NEEDRESET){NEEDRESET=false;if(c.reset)c.reset()}c.setTransform(1,0,0,1,0,0);c.globalAlpha=1;c.globalCompositeOperation='source-over';
 c.save();if(R.shake>0&&!R.rm)c.translate((Math.random()-.5)*R.shake*.6,(Math.random()-.5)*R.shake*.6);
 c.drawImage(R.bake.c,0,0);rpAmbient(c,R);
 for(const f of R.fields){const k=f.t<.3?f.t/.3:f.t>f.d-.5?(f.d-f.t)/.5:1;rpSlowField(c,f.x,f.y,f.r,R.t,k)}
 for(const b of R.burns){const k=Math.min(1,(b.d-b.t)/.6);c.save();c.globalCompositeOperation='lighter';c.globalAlpha=.55*k;glow(c,b.x,b.y,b.r,'#ff6a1a88');c.restore();if(Math.random()<.3)try{ptBurst(R.fx,b.x+(Math.random()-.5)*b.r,b.y+(Math.random()-.5)*b.r*.5,1,['#ffb04a','#ff6a1a'],{v:60,s:2.5,up:1,g:-80})}catch(e){}}
 /* pads and placement */
 const placing=!!R.place,ht=R.hover;
 for(const p of R.pads){if(p.tw)continue;c.save();c.translate(p.x,p.y);rpPadDraw(c,R.t,placing?(ht===p?'hover':'valid'):(ht===p||R.selPad===p?'hover':'idle'));c.restore()}
 /* range ring */
 const rr=(x,y,r,col)=>{c.save();c.globalAlpha=.16;c.fillStyle=col;c.beginPath();c.ellipse(x,y,r,r*RPFX.sq,0,0,TAU);c.fill();c.globalAlpha=.75;c.setLineDash([10,8]);c.lineDashOffset=-R.t*30;c.lineWidth=2.5;c.strokeStyle=col;c.stroke();c.restore()};
 if(R.sel){const T=RP_TW[R.sel.type];rr(R.sel.x,R.sel.y,T.range[R.sel.tier-1],'#ffd45a')}
 if(placing&&ht&&!ht.tw){rr(ht.x,ht.y,RP_TW[R.place].range[0],'#9fe8ff')}
 /* entities by depth */
 const L=[];for(const p of R.pads)if(p.tw)L.push({y:p.y,k:0,o:p.tw});for(const e of R.foes){if(e.air)continue;const q=rpPos(R,e);L.push({y:q.y,k:1,o:e,q})}L.sort((a,b)=>a.y-b.y);
 for(const it of L){if(it.k===0){const tw=it.o,pk=tw.pop<1?.6+.4*rpOver(tw.pop):1;c.save();c.translate(tw.x,tw.y);if(pk!==1)c.scale(pk,pk);
   rpTowerDraw(c,tw.type,tw.tier,tw.skin,R.t,{aim:tw.aim,fire:tw.fire,over:tw.over>0?Math.min(1,tw.over):0,sel:R.sel===tw,ph:tw.ph});c.restore();if(tw.over>0)rpOvercharge(c,tw.x,tw.y,R.t,Math.min(1,tw.over),rpTowerTop(tw.type,tw.tier))}
  else rpFoeDraw(c,R,it.o,it.q)}
 if(placing&&ht&&!ht.tw){c.save();c.translate(ht.x,ht.y);rpTowerDraw(c,R.place,1,rpSkinOf(R.place),R.t,{ghost:true,aim:0,fire:0,over:0});c.restore()}
 for(const e of R.foes)if(e.air)rpFoeDraw(c,R,e,rpPos(R,e));
 /* shots, arcs, rings */
 for(const s of R.shots){if(s.k==='bolt')rpBolt(c,s.x,s.y,s.a,s.skin);else{const u=s.t/s.d,x=s.x0+(s.x1-s.x0)*u,y=s.y0+(s.y1-s.y0)*u-Math.sin(u*Math.PI)*110;rpEmber(c,x,y,R.t,s.skin)}}
 for(const a of R.arcs){for(let i=0;i<a.pts.length-1;i++)rpBolt2(c,a.pts[i].x,a.pts[i].y,a.pts[i+1].x,a.pts[i+1].y,R.t+i,a.skin)}
 for(const r of R.rings){const k=r.t/r.d;if(r.boom)rpBurst(c,r.x,r.y,k,r.max,r.skin);else if(r.frost)rpFrostPulse(c,r.x,r.y,k,r.max,r.skin);
  else{c.save();c.globalAlpha=(1-k)*.85;c.strokeStyle=r.c;c.lineWidth=r.w*(1-k*.5);c.beginPath();c.ellipse(r.x,r.y,8+(r.max-8)*rpEase(k),(8+(r.max-8)*rpEase(k))*RPFX.sq,0,0,TAU);c.stroke();c.restore()}}
 try{ptFxStep(c,R.fx,R.pause?0:1/60)}catch(e){}
 /* floating text */
 c.textAlign='center';c.textBaseline='middle';for(const t of R.tx){const u=t.t/t.d,a=u<.15?u/.15:1-Math.max(0,(u-.6)/.4);c.globalAlpha=a;c.font=`800 ${t.sz}px Poppins,system-ui,sans-serif`;
  c.lineWidth=4;c.strokeStyle=RPO;c.strokeText(t.s,t.x,t.y-u*34);c.fillStyle=t.c;c.fillText(t.s,t.x,t.y-u*34)}c.globalAlpha=1;
 /* aiming an ability */
 if(R.aim==='slow'&&R.my>=0&&R.my<RPT.MAPH){c.save();c.globalAlpha=.6;rpSlowField(c,R.mx,R.my,RPT.SLOW_R,R.t,.8);c.restore()}
 c.restore();
 /* keep damage vignette */
 if(R.hitFl>0){c.save();c.globalAlpha=R.hitFl*.45;const q=c.createRadialGradient(800,330,300,800,330,900);q.addColorStop(0,'rgba(255,40,60,0)');q.addColorStop(1,'rgba(255,40,60,1)');c.fillStyle=q;c.fillRect(0,0,1600,RPT.MAPH);c.restore()}
 rpBannerDraw(c,R);
 /* the dock area behind the DOM bars */
 const q=c.createLinearGradient(0,RPT.MAPH-30,0,900);q.addColorStop(0,'rgba(10,6,28,0)');q.addColorStop(.12,'#0d0926');q.addColorStop(1,'#080518');c.fillStyle=q;c.fillRect(0,RPT.MAPH-30,1600,900-RPT.MAPH+30)}
const rpOver=k=>{const c1=1.70158,c3=c1+1,x=rpClamp(k,0,1)-1;return 1+c3*x*x*x+c1*x*x};
function rpFoeDraw(c,R,e,q){const k=e.dead?1-rpClamp(e.dk,0,1):1;if(k<=0)return;
 if(e.dead&&!e.leak&&typeof rpMobDeath==='function'){rpMobDeath(c,e.id,q.x,q.y,rpClamp(e.dk,0,1),{});return}
 const flip=Math.cos(q.a)<-.2;rpMobBlit(c,e.id,q.x,q.y,e.ph,{s:1,flip,a:k,flash:e.fl>0?e.fl/.1:0,chill:e.slowT>0||e.inField>0?.55:0});
 if(e.inField>0)e.inField-=1/60;
 if(e.slowT>0&&!R.rm&&Math.random()<.08)try{ptBurst(R.fx,q.x,q.y-20,1,['#d8f4ff'],{v:40,s:2})}catch(x){}
 if(!e.dead&&e.hp<e.mx){const h=(RPMOB[e.id]?RPMOB[e.id].h:50)*(e.air?1:1)+(e.air?44:8),w=e.boss?90:36,y=q.y-h;c.fillStyle='rgba(10,6,20,.8)';c.fillRect(q.x-w/2-1,y-1,w+2,7);
  c.fillStyle=e.boss?'#ff8a3a':e.hp/e.mx>.5?'#7dffb0':e.hp/e.mx>.25?'#ffd45a':'#ff5a6a';c.fillRect(q.x-w/2,y,w*rpClamp(e.hp/e.mx,0,1),5)}}
function rpBannerDraw(c,R){const b=R.banner;if(!b)return;const u=b.t/b.d,a=u<.12?u/.12:u>.8?(1-u)/.2:1,s=R.rm?1:.85+.15*rpOver(Math.min(1,b.t/.35));
 c.save();c.globalAlpha=a;c.translate(800,250);c.scale(s,s);c.textAlign='center';c.textBaseline='middle';
 const w=Math.max(460,c.measureText?560:560);c.fillStyle='rgba(8,5,22,.78)';c.strokeStyle=b.boss||b.lose?'#ff6a5a':'#ffd45a';c.lineWidth=3;c.beginPath();c.roundRect(-w/2,-62,w,124,24);c.fill();c.stroke();
 c.font=`400 ${b.boss?66:70}px 'Pirata One',Georgia,serif`;c.lineWidth=7;c.strokeStyle=RPO;c.strokeText(b.txt,0,-14);const g=c.createLinearGradient(0,-50,0,20);g.addColorStop(0,'#fff6c0');g.addColorStop(.5,b.boss||b.lose?'#ff9a6a':'#ffd45a');g.addColorStop(1,b.boss||b.lose?'#c8301a':'#e08a1a');c.fillStyle=g;c.fillText(b.txt,0,-14);
 if(b.sub){c.font='600 19px Poppins,system-ui,sans-serif';c.fillStyle='#e8e0ff';c.fillText(b.sub,0,36)}c.restore()}
/* ---------- input ---------- */
function rpStageXY(ev){const r=cv.getBoundingClientRect();return{x:(ev.clientX-r.left)/r.width*W,y:(ev.clientY-r.top)/r.height*H}}
function rpPick(R,x,y){for(const p of R.pads){const dx=x-p.x,dy=y-p.y;if(p.tw){if(Math.abs(dx)<52&&dy>-130&&dy<36)return p}else if(dx*dx+(dy*1.8)*(dy*1.8)<56*56)return p}return null}
function rpClick(x,y,btn){const R=RPX;if(!R||R.pause||R.over)return;if(y>=RPT.MAPH)return;
 if(btn===2){R.place=null;R.aim=null;R.selPad=null;return}
 if(R.aim==='slow'){if(R.G.dRoad(x,y)<70)rpAbility('slow',{x,y});else rpToast('Place it on the road',1.2,'#9fe8ff');return}
 const p=rpPick(R,x,y);
 if(R.aim==='over'){if(p&&p.tw){R.sel=p.tw;rpAbility('over',true)}else{R.aim=null}return}
 if(R.place){if(p&&!p.tw){if(rpBuild(p,R.place)&&R.supply<rpCost(R.place,1))R.place=null}else R.place=null;return}
 if(p&&p.tw){R.sel=R.sel===p.tw?null:p.tw;R.selPad=null;rpSfx('key',3)}
 else if(p){R.selPad=R.selPad===p?null:p;R.sel=null;rpSfx('key',1)}
 else{R.sel=null;R.selPad=null}}
if(!window.__rpk){window.__rpk=1;
 window.addEventListener('keydown',e=>{const R=RPX;if(!R||!S.rp||S.mode!=='ramparts')return;if(e.ctrlKey||e.metaKey||e.altKey)return;
  if(e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();if(R.place||R.aim||R.selPad||R.sel){R.place=null;R.aim=null;R.selPad=null;R.sel=null;return}if(!R.over)rpPause();return}
  if(R.pause||R.over)return;try{ensureAudio()}catch(x){}
  if(e.key===' '||e.key==='Enter'){e.preventDefault();e.stopImmediatePropagation();if(!e.repeat){if(R.wst==='build')rpWaveStart();}return}
  if(e.key==='Tab'){e.preventDefault();e.stopImmediatePropagation();if(!e.repeat)rpSpeed();return}
  if(e.key==='1'||e.key==='2'||e.key==='3'){e.preventDefault();e.stopImmediatePropagation();if(e.repeat)return;const k=['over','slow','repair'][+e.key-1];rpAbility(k,R.aim===k||k==='slow'?true:(R.sel?undefined:true));return}
  if(e.key.length===1){e.preventDefault();e.stopImmediatePropagation();if(!e.repeat)rpKey(e.key)}},true);
 cv.addEventListener('pointerdown',e=>{if(!RPX||!S.rp||S.mode!=='ramparts')return;const p=rpStageXY(e);try{ensureAudio()}catch(x){}rpClick(p.x,p.y,e.button)});
 cv.addEventListener('pointermove',e=>{const R=RPX;if(!R||!S.rp)return;const p=rpStageXY(e);R.mx=p.x;R.my=p.y;R.hover=p.y<RPT.MAPH?rpPick(R,p.x,p.y):null;cv.style.cursor=R.hover||R.aim?'pointer':''});
 cv.addEventListener('contextmenu',e=>{if(RPX&&S.rp){e.preventDefault();rpClick(0,0,2)}});
 window.addEventListener('blur',()=>{if(RPX&&S.rp&&S.mode==='ramparts'&&!RPX.over&&!RPX.pause)rpPause(true)});
 document.addEventListener('visibilitychange',()=>{if(document.hidden&&RPX&&S.rp&&S.mode==='ramparts'&&!RPX.over&&!RPX.pause)rpPause(true)})}
{const k0=key;key=function(c){if(S.rp&&RPX)return rpKey(c);return k0.apply(this,arguments)}}
function rpSpeed(){const R=RPX;if(!R)return;R.spd=R.spd===1?2:1;rpSfx('key',R.spd*4)}
function rpPause(on){const R=RPX;if(!R||R.over)return;on=on===undefined?!R.pause:on;if(on===R.pause)return;R.pause=on;if(on){if(typeof rpPauseMenu==='function')rpPauseMenu()}else{hide();try{inp.blur()}catch(e){}if(typeof rpHudOn==='function')rpHudOn()}}
/* ---------- the finish: pay, XP, stars, unlocks ---------- */
function rpFinish(won){const R=RPX;if(!R||R.over)return;R.over=true;const r=RPP(),map=R.map;
 const wk=R.free||won?(R.winKeep!=null?R.winKeep:R.keep):0,cleared=won||R.free?map.waves:Math.max(0,R.wave-1),stars=won||R.free?(wk>=18?3:wk>=10?2:1):0,old=r.stars[map.id]||0;
 let pay=R.free||won?Math.round(map.pay*(.7+.1*stars)):Math.round(map.pay*.35*cleared/map.waves),first=false;const day=rpDay();
 if(R.free)pay=Math.round(map.pay*(.7+.1*stars));
 if(won||R.free){if(r.day!==day){r.day=day;r.dayDone={}}if(!r.dayDone[map.id]){r.dayDone[map.id]=1;first=true;pay=Math.round(pay*RPT.FIRSTDAY)}}
 const fp=R.fpCoins,total=pay+fp;
 const frac=won||R.free?1:cleared/map.waves,l0=lvl(P.xp),xp=xpMode(Math.round(map.xp*(won||R.free?1:.5*frac)*xpMulRun()));P.xp+=xp;const lg=levelGold(l0,lvl(P.xp)),xn=xpNoteH();
 if(stars>old)r.stars[map.id]=stars;r.runs++;if(won||R.free)r.wins++;r.kills+=R.kills;r.words+=R.words;r.gold+=total;
 const b=r.best[map.id]||{};if((won||R.free)&&(!b.keep||wk>b.keep))r.best[map.id]={keep:wk,t:Math.round(R.time)};if(R.free){r.fp[map.id]=Math.max(r.fp[map.id]||0,R.fpWaves)}
 P.gold=Math.min(1e12,P.gold+total);try{stat('gold',total,'add')}catch(e){}
 const unl=rpUnlockSweep();let ttl=false;try{if(rpStarN()>=RP_TITLE_NEED&&!BTY().own['t:rampartwarden']){BTY().own['t:rampartwarden']=1;ttl=true}}catch(e){}
 if(won)try{btyAdd('ramparts',1)}catch(e){}
 save();R.result={won:won||R.free,free:R.free,stars,old,newStars:stars>old,pay,fp,total,first,xp,xn,lg,unl,ttl,cleared,keep:wk||R.keep,kills:R.kills,words:R.words,maxCombo:R.maxCombo,
  time:R.time,built:R.built,leaked:R.leaked,wave:R.wave,fpWaves:R.fpWaves,l0,l1:lvl(P.xp)};
 try{if(typeof rpHudOff==='function')rpHudOff()}catch(e){}if(typeof rpResult==='function')rpResult()}
function rpUnlockSweep(){const r=RPP(),n=rpStarN(),out=[];for(const s of RP_SKINS){const k=s.tw+':'+s.k;if(n>=s.need&&!r.own[k]){r.own[k]=1;out.push(s)}}return out}
/* freeplay: after a win the player may keep defending for banked coins */
function rpFreeplay(){const R=RPX;if(!R||R.over||!R.won)return;R.free=true;R.wst='build';R.keep=Math.max(R.keep,1);R.cd=RPT.BUILD_T;R.banner={txt:'Freeplay',sub:'Every wave you survive banks coins. How long can the keep stand?',t:0,d:2.6};if(typeof rpHudOn==='function')rpHudOn()}
