/* ===== RUNESTONE TOWER DEFENSE 10.2: tower and monster interactions with fourteen towers (99f, after 99e; overrides only, prefix rpib) =====
   An audit of all fourteen towers (the Moonblade Sentinel and the Phantom Lantern included) against every monster, every monster
   ability, every map twist and every other tower, plus selling, upgrading, wave ends, defeat, leaving, pause, speed and early calls
   (t_ia102.py: every map, a tower x monster matrix, soak battles and a randomized fuzz). Fixes:
   1. Damage meter (99e): a sold tower was booked as a snapshot of its damage at the moment of the sale, and only if it had dealt any by
      then. Everything its effects did afterwards (burning ground, Mortar craters, Still puddles, Tidecaller waves, Engine wells, stars
      and bolts in flight, Lantern haunts) was counted in the battle total but on no tower, so the results' MVP card and damage bars
      missed it. A sold tower's record now keeps reading the tower: its damage and kills stay live.
   2. Phantom Lantern: phantoms kept marching up to 8 s down an empty road after a wave was cleared, and a sold lantern's phantoms
      and wisps went on fighting (its souls already faded). Now once the road is clear (no ground monster left and none still to
      spawn) the phantoms go back: they fade where they stand, and a legion phantom still waiting at the crypt never rises. Selling
      a lantern fades its phantoms and fizzles its wisps, the way a sold Moonblade Sentinel takes its glaives along. Haunts already
      on monsters run out as before (a status, like a burn or a soak) and stay booked on the sold lantern.
   3. Slow immunity: on the step a Steam Golem starts venting (98b), the slow from the step before (Moonlit Wake, honey, Frost, Grave
      Chill, craters...) still held it for that frame. A venting golem now sheds every slow from its first venting step.
   4. World 2/3 monsters on a World 1 map (the Wonderland, DEV): 98p runs their ability step only while such a monster is alive, so an
      ink blob still in flight when its Inkling died never landed and an EMP or stomp ring froze on screen (drawn until the next such
      monster came). The ink, EMP and bolt effects now run out after their monster is gone.
   5. Moonblade Sentinel: a jam takes the edge off its glaives in flight (they fly home without cutting, 99b), but a tier-5 eclipse kept
      circling and cutting through the whole jam. The eclipse now loses its edge too: it stops cutting and fades out.
   RPIB.off = 1 switches the step hooks off (tests). Test: t_ia102.py. */
const RPIB={off:0};
/* ---------- 1. the damage meter keeps reading sold towers ---------- */
{const s0=rpSell;rpSell=function(tw){const R=RPX;let n0=-1;try{if(R&&tw&&tw.type){R.rpqSold=R.rpqSold||[];n0=R.rpqSold.length}}catch(e){}
 const r=s0.apply(this,arguments);
 try{if(n0>=0&&R===RPX&&R.rpqSold){let rec=R.rpqSold.length>n0?R.rpqSold[R.rpqSold.length-1]:null;
   if(!rec||rec._tw)R.rpqSold.push(rec={type:tw.type,tier:tw.tier,skin:tw.skin,d:tw.rpqD||0,k:tw.kills||0,t:tw.rpqT||0,sold:1});rec._tw=tw}}catch(e){console.error(e)}
 return r}}
function rpqDmList(R){const L=[];for(const p of R.pads){const tw=p.tw;if(tw&&(tw.rpqD>0||tw.kills>0))L.push({type:tw.type,tier:tw.tier,skin:tw.skin,d:tw.rpqD||0,k:tw.kills||0,t:tw.rpqT||0})}
 for(const s of R.rpqSold||[]){const tw=s._tw;if(!tw){if(s.d>0||s.k>0)L.push(s);continue}const d=Math.max(s.d||0,tw.rpqD||0),k=Math.max(s.k||0,tw.kills||0);
  if(d>0||k>0)L.push({type:s.type,tier:s.tier,skin:s.skin,d,k,t:s.t,sold:1})}return L}
/* ---------- 2. phantoms go back when the wave is cleared; a sold lantern takes its phantoms and wisps along ---------- */
function rpibPhEnd(R,ph){if(!ph||ph.done||ph.st==='fade')return;if(ph.wait>0){ph.done=1;return}ph.st='fade';ph.t=0;
 try{const G=rplnGh(ph.tier);ptBurst(R.fx,ph.x,ph.y-30-(ph.h||0),R.lite?3:9,[G.l,G.w],{v:90,s:2.6,up:1})}catch(x){}}
function rpibLnPost(R){const P=R.lnPh;if(!P||!P.length)return;const clear=!(R.q&&R.q.length)&&!R.foes.some(e=>!e.dead&&!e.air);
 for(const ph of P){const tw=ph.tw;if(clear||!tw||!tw.pad||tw.pad.tw!==tw)rpibPhEnd(R,ph)}R.lnPh=P.filter(p=>!p.done)}
{const s0=rpSell;rpSell=function(tw){try{const R=RPX;if(R&&tw&&tw.type==='lant'&&R.lnPh){for(const ph of R.lnPh)if(ph.tw===tw)rpibPhEnd(R,ph);R.lnPh=R.lnPh.filter(p=>!p.done);
  for(const w of R.lnWisps||[])if(w.tw===tw&&!(w.fade>0))w.fade=1e-3}}catch(e){console.error(e)}return s0.apply(this,arguments)}}
/* ---------- 3. a venting Steam Golem sheds every slow from its first venting step ---------- */
{const p0=rpwPre;rpwPre=function(R,dt){const r=p0.apply(this,arguments);if(!RPIB.off&&R&&R.foes)for(const e of R.foes)if(e.vent>0&&!e.dead&&!e.air&&e.slowT>0){e.slowT=0;e.slowK=0}return r}}
/* ---------- 4. ink, EMP and bolt effects run out on World 1 maps after their monster is gone ---------- */
function rpibW1Fx(R,dt){if(!R||!R.map||R.map.world>1)return;if(!((R.inks&&R.inks.length)||(R.emps&&R.emps.length)||(R.bolts&&R.bolts.length)))return;
 if(R.foes&&R.foes.some(e=>!e.dead&&RPIA_AB[e.id]))return;/* 98p steps them while such a monster is alive */
 rpwPre(R,dt)}
{const s0=rpStep;rpStep=function(R,dt){if(!RPIB.off&&R)try{rpibW1Fx(R,dt)}catch(e){console.error(e)}const r=s0.apply(this,arguments);if(!RPIB.off&&R)try{rpibLnPost(R)}catch(e){console.error(e)}return r}}
/* ---------- 5. a jammed Sentinel's eclipse stops cutting and fades ---------- */
{const e0=rpmbStepEcl;rpmbStepEcl=function(R,E,dt){const tw=E&&E.tw;if(!RPIB.off&&tw&&tw.jam>0&&E.t<E.d){E.t=Math.max(E.t+dt,E.d-.25);return}return e0.apply(this,arguments)}}
