/* ---------- Beginner's Mode: a gentle Endless run for people learning the game ----------
   It runs on the normal Endless engine (levels, rounds, bosses, boons, gear) with these changes:
   words are 3 to 5 letters, rounds hold fewer monsters that arrive more slowly, and boss sentences are short.
   It pays half (gold, XP and crate drops) and never touches records, trophies, bounties or mastery: stat(), mastKill(), the bounty hooks and the
   Bestiary all check S.bg, and bgOver() skips finishRun() and the weapon XP step, so no best WPM, best streak or kill totals are saved from it. */
const BG_GOLD=.5,BG_XP=.5,BG_DROP=.5,BG_FEW=.6,BG_SLOW=1.55;/* gold x, XP x, crate drops kept, share of normal monsters per round, spawn gap x */
const BGW=('cat dog sun sky map key box cup hat pen bed fox owl bee ant bat cow hen pig rat ram elk ape fig nut oak ice ink jam joy leg lip mud net oil pie rug sea tea toy van web zip arm ear eye hip toe fan fur gem gap hop jog kit lap mop nap pot rod sap tub wax yak yes pan pad jar jet log map sit run red big hot top wet fun sad ' +
 'moon star tree fish bird frog wolf bear lion duck goat deer rain snow wind fire rock sand wave leaf rose seed lake hill road gate bell book door desk game gold hand head home jump king lamp milk nest note park ring ship song sock tent town wall wing wood yard blue cake coin farm foot gift hero iron kite lock mask path rope sail shoe swim tale vine wish bone cave claw crow dawn dust east fern glow harp horn isle jade lava mist moss navy opal pond pine reed salt silk tide tusk vale west wick yarn zone bark beam bolt cart coat drum fork gown helm hunt keys lily mint nail oven pear quiz raft soup toad urn vest warm yawn zoom ' +
 'apple bread cloud dream eagle flame ghost heart horse jelly knife lemon magic night ocean piano queen river sword tiger water zebra beach candy dance earth field grape happy light mouse plant quick sheep smile stone sugar table train voice whale youth brave crown  giant globe honey ivory jewel  ladder maple nurse olive paint quilt radio shell tower unity viper wheat xenon yacht zesty amber blaze charm drift ember frost glory haven input jolly koala lunar mango noble orbit pearl quest rival storm trail umbra vivid wagon young robin sunny bloom flute march plumb scale spark tulip').split(/\s+/).filter((w,i,a)=>/^[a-z]{3,5}$/.test(w)&&a.indexOf(w)===i);
const BGB=['you cannot beat me','this hall is mine','turn back now brave one','the night is long','no knight can win','come and face me','your sword is slow','i will not fall','you are too late','fear the dark king','try to hit me','keep on typing','the end is near','you shall not win','bow down to me','few can pass me','this is my land','welcome to my den','run while you can','try your best','my teeth are sharp','the dark is mine','you will lose','nice try little one','the old king wakes','i am the boss here','can you type fast','you are not ready','stay out of my way','i have waited so long'];
const BG_TIPS=[
 'Type the letters of the word nearest you to slay that monster.',
 'A wrong key shrinks your streak, so slow down and stay accurate.',
 'Rest your fingers on the home row: A S D F and J K L ;',
 'Your Fury bar fills as you type. When it is full, press ENTER for a Fury Strike.',
 'Boss round: type the whole sentence, then press SPACE when the boss turns weak.',
 'Press TAB to drop your current target and pick another monster.',
 'Keep your eyes on the screen, not the keyboard. Your fingers will learn the way.',
 'Streaks multiply your score. Calm, steady typing beats rushing.',
 'SPACE also parries attacks. Press it just as a projectile reaches you.'];
let BGR=[],BGBR=[];
/* words: only 3 to 5 letters, with the same no-repeat and different-first-letter rules as the normal picker */
{const pw=pickWord;pickWord=function(role,zi,d,on){if(!S||!S.bg)return pw.apply(this,arguments);
  const lo=role===2?5:role===1?3:4,hi=role===2?5:role===1?4:5,firsts=new Set((on||[]).map(w=>w[0])),ban=new Set([...BGR,...(on||[])]),ok=(w,f,r)=>w.length>=lo&&w.length<=hi&&(!f||!firsts.has(w[0]))&&(!r||!ban.has(w));
  for(const [f,r] of [[1,1],[0,1],[0,0]]){const c=BGW.filter(w=>ok(w,f,r));if(c.length){const w=c[Math.random()*c.length|0];BGR.push(w);if(BGR.length>40)BGR.shift();return w}}
  return BGW[Math.random()*BGW.length|0]}}
/* boss sentences: short and friendly */
{const b0=bossLine;bossLine=function(L,tier,used){if(!S||!S.bg)return b0.apply(this,arguments);
  const P1=a=>a[Math.random()*a.length|0];let s,n=0;
  do{s=Math.random()<.65?P1(BGB):`${P1(['the big','the old','a dark','a cold','the last'])} ${P1(['king','wolf','ghost','giant','beast','bear'])} will ${P1(['win','rise','roar','hunt','bite','fight'])}`}while(((used||[]).includes(s)||BGBR.includes(s))&&++n<40);
  BGBR.push(s);if(BGBR.length>14)BGBR.shift();return s}}
/* crates drop half as often */
{const d1=drop;drop=function(e,kk){if(S.bg&&Math.random()>BG_DROP)return;return d1.apply(this,arguments)}}
/* a tip at the start of each round of the first two levels */
{const sw=startWave;startWave=function(){const r=sw.apply(this,arguments);
  if(S.bg){const i=(lvOf(S.wave)-1)*5+S.round-1,k=[0,1,2,3,4,5,6,7,8][i];if(k!=null&&!(S.tip&&S.tip.t>1))S.tip={t:4.2,txt:BG_TIPS[k]}}return r}}
/* ---------- the run summary: its own records, and nothing else is touched ---------- */
function bgOver(quit){if(S.mode==='over')return;S.mode='over';
 const xp=xpMode(Math.round((S.score/16+S.wave*8)*xpMulRun()*BG_XP*ENDXP)),xn=xpNoteH(),G=P.bgb||(P.bgb={best:0,lv:0,runs:0}),nb=S.score>(G.best||0),l0=lvl(P.xp),lv=lvOf(S.wave);
 for(const c of S.cr)collect(c);S.cr=[];
 P.xp+=xp;if(nb)G.best=S.score;G.lv=Math.max(G.lv||0,lv);G.runs=(G.runs||0)+1;const l1=lvl(P.xp),cr=S.runC||0,lg=levelGold(l0,l1),gold=S.gold+lg,rd=S.round,by=S.by,sc0=S.score;save();jingle('lose');
 const hint=lv>=3||G.runs>=3;
 const later=()=>{show(`<div class="bgov"><h2>Nice run!</h2>${resBlock()}<p>${nb?'<b style="color:#7affc8">New Beginner record!</b> ':''}You reached level ${lv}, round ${rd} of 5.${by&&!quit?` Slain by ${esc(by)}.`:''}<br>Earned ${xp} XP, ${gold} gold and ${cr} crate${cr===1?'':'s'}.${xn}${l1>l0?`<br><b style="color:var(--gold)">Level up! You are now level ${l1}, ${rankOf(l1)}. Bonus: ${lg} gold.</b>`:''}${pathMsg(l0,l1)}</p>
  <p class="bgnote">Beginner's Mode does not count toward records, trophies or bounties.${hint?' Feeling confident? Standard Endless awaits.':''}</p>${tipLine()}
  <div class="row"><button id="go">Play again</button>${hint?'<button class="sm gd" id="gs">Try Standard Endless</button>':''}<button class="sm" id="hm">Home</button></div></div>`);
  $('go').onclick=()=>start(0,'bg');if($('gs'))$('gs').onclick=()=>start();$('hm').onclick=title};
 S.bg=0;/* the run is finished: from here on nothing in the game should treat the state as a Beginner run */
 if(quit)later();else{S.pose='dead';S.poseT=0;S.landed=0;S.late=later;S.lateAt=2.2}}
/* ---------- the Endless menu ---------- */
const BGL=[['Home row first','Rest your fingers on A S D F and J K L ;. Every key is one short reach from there.','#7affc8'],
 ['Eyes up','Watch the screen, not the keyboard. Your fingers learn the layout faster that way.','#9fe8ff'],
 ['Accuracy before speed','A wrong key shrinks your streak. Aim for clean words and speed arrives on its own.','#ffd76a'],
 ['Build a streak','Every clean word grows your streak and your score multiplier.','#ff9a5a'],
 ['Use Fury','Typing fills the Fury bar. When it is full, press ENTER to slay everything on screen.','#ff7ac8'],
 ['Beat the boss','Type the whole sentence, then press SPACE when the boss glows weak. SPACE also parries attacks.','#c9a4ff']];
/* ---------- the Endless menu (redesigned): two scene cards with live hero + monsters, staged entrance, tips drawer ---------- */
const EMI={
 up:'<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20V14M10 20V10M16 20V12M22 20V4"/><path d="M3 9l6-5 4 3 7-5" stroke-width="0"/></svg>',
 star:'<svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"><path d="M12 2.6l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4 6.1 20.6l1.2-6.5L2.5 9.5l6.6-.9z"/></svg>',
 cup:'<svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"><path d="M7 3h10v6a5 5 0 01-10 0zM7 5H3c0 4 1.6 6 4.2 6.4M17 5h4c0 4-1.6 6-4.2 6.4M12 14v4M8 21h8M9.5 18h5v3h-5z"/></svg>',
 aa:'<b class="emaa">Aa</b>',
 snail:'<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 19h14a4 4 0 004-4V8"/><path d="M13 19a6 6 0 10-6-6M10 13a3 3 0 113 3"/><path d="M19 8l2-4M21 8l2-3" stroke-width="1.8"/></svg>',
 no:'<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M5.6 5.6l12.8 12.8"/></svg>',
 sword:'<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 4l-9 9M20 4h-5M20 4v5M8 12l4 4M6 14l-3 3M5 19l-2 2"/><path d="M4 4v3M2.5 5.5h3M19 17v3M17.5 18.5h3" stroke-width="1.6"/></svg>',
 kb:'<svg viewBox="0 0 32 24" width="38" height="28" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><rect x="1.5" y="3" width="29" height="18" rx="3.5"/><path d="M6 8h2M11 8h2M16 8h2M21 8h2M26 8h1M6 12.5h2M11 12.5h2M16 12.5h2M21 12.5h2M26 12.5h1M9 17h14" stroke-linecap="round"/></svg>',
 chev:'<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg>'};
function emDraw(cv,mons){const slashA=-.5;return t=>{const g=cv.getContext('2d'),w=cv.width,h=cv.height,gy=h-22;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,w,h);
 const cyc=(t%3.6)/3.6,lun=cyc>.74&&cyc<.96?Math.sin((cyc-.74)/.22*Math.PI):0,hit=cyc>.82&&cyc<.98?Math.sin((cyc-.82)/.16*Math.PI):0;
 const sh=(x,r)=>{g.fillStyle='#0008';g.beginPath();g.ellipse(x,gy+5,r,8,0,0,TAU);g.fill()};
 g.save();try{sh(w*.2+lun*34,58);g.translate(w*.2+lun*34,gy);g.scale(1.62,1.62);drawHero(g,{arm:P.armor,wp:P.weapon,col:P.col,t,lg:lun})}catch(e){}g.restore();
 mons.forEach(([id,fx,k],i)=>{const M=MON[id];if(!M)return;const H=M.h*k,sc=H/M.th,x=w*fx+(i===0?hit*14:0),hp=Math.max(.1,.62+.38*Math.sin(t*.9+i*2.2)-(i===0?hit*.18:0));
  g.save();try{sh(x,H*.3);g.translate(x,gy);g.scale(sc,sc);if(i===0&&hit>.05)g.filter=`brightness(${1+hit*1.6})`;M.d(g,t+i*1.3,{lg:0})}catch(e){}g.restore();
  {const wd=mons[i][3],ty=i===0?Math.min(wd.length,Math.floor(cyc/.7*(wd.length+1))):0;g.font="700 17px 'Courier New',monospace";const lw=g.measureText(wd).width/wd.length,bw=lw*wd.length+22,bx=x-bw/2,by=gy-H-34;
  g.fillStyle='#0b0718e6';g.strokeStyle=i===0?'#ffe27a':'#ffffff55';g.lineWidth=2;g.beginPath();g.roundRect(bx,by,bw,26,8);g.fill();g.stroke();g.textBaseline='middle';
  for(let k=0;k<wd.length;k++){g.fillStyle=k<ty?'#7affc8':'#f3eefc';g.fillText(wd[k],bx+11+k*lw,by+14)}}
  });
 if(lun>.4){g.save();g.globalAlpha=Math.min(1,(lun-.4)*2.2)*(1-hit*.2);g.strokeStyle='#fff';g.lineWidth=5;g.lineCap='round';g.shadowColor='#fff';g.shadowBlur=12;g.beginPath();g.arc(w*.2+120,gy-120,64,-1.2,.5);g.stroke();g.restore()}}}
function endlessMenu(back){S.mode='title';S.view='menu';const G=P.bgb||{best:0,lv:0,runs:0};let imgE='',imgB='';try{imgE=sceneShot(LEVELS[17],640,480,'e');imgB=sceneShot(LEVELS[0],640,480,'bgm')}catch(e){}
 const f=(ic,a,b,i)=>`<li style="--i:${i}"><i>${ic}</i><div><b>${a}</b><span>${b}</span></div></li>`,
 cell=(v,l)=>`<span><b>${v}</b><i>${l}</i></span>`,
 par=(n,c)=>{let s='';for(let i=0;i<n;i++)s+=`<u style="left:${(i*37+11)%96}%;--d:${(i*1.37%5).toFixed(2)}s;--s:${(5+(i*53)%40/10).toFixed(1)}s;--z:${(2+(i*17)%30/10).toFixed(1)}px"></u>`;return `<span class="empt">${s}</span>`},
 card=(cls,c,id,img,title,tag,feats,stats,cta,key,extra)=>`<article class="emc ${cls}" style="--c:${c}">${extra||''}<div class="emi"><span class="emimg"${img?` style="background-image:url(${img})"`:''}></span><canvas class="emcv" id="${id}cv" width="640" height="290"></canvas><span class="emfade"></span>${par(9)}</div>
  <div class="emb"><h3>${title}</h3><p class="emtag">${tag}</p><ul class="emf">${feats}</ul><div class="ems">${stats}</div>
  <button class="emgo" id="${id}">${cta}<i>›</i><kbd>${key}</kbd></button></div></article>`;
 const first=!G.runs,tp=BGL[2];
 show(`<div class="em"><header class="emh"><div class="emt"><span class="emd"></span><h2>Endless</h2><span class="emd r"></span></div><p>Two ways to play. One endless adventure.</p></header>
 <div class="emg">
 ${card('std','#ff8a3a','bgS',imgE,'Standard Endless','Push your speed. Chase your best.',
  f(EMI.up,'Monsters get faster and words get longer.','Increasing challenge as you go.',0)+f(EMI.star,'Full rewards.','Gold, XP and crates.',1)+f(EMI.cup,'Records &amp; trophies.','Track your best runs and earn trophies.',2),
  cell(P.bestWave||'<span class="nrec">No record yet</span>','Best round')+cell((P.best||0).toLocaleString(),'Best score'),'Play Standard','1')}
 ${card('beg','#4fe3b0','bgB',imgB,'Beginner’s Mode','Build confidence at your own pace.',
  f(EMI.aa,'Words are 3 to 5 letters.','Short and simple words.',0)+f(EMI.snail,'Fewer monsters and slower waves.','Shorter boss sentences.',1)+f(EMI.no,'Records, trophies &amp; bounties disabled.','Focus on learning without pressure.',2),
  first?`<span class="emfirst"><i>${EMI.sword}</i><div><b>Your first adventure starts here.</b><span>No records yet. Just play and learn!</span></div></span>`:cell(G.lv||1,'Deepest level')+cell((G.best||0).toLocaleString(),'Best score')+cell(G.runs,'Run'+(G.runs===1?'':'s')),'Play Beginner','2','<span class="emnew">NEW</span>')}
 </div>
 <section class="emhow" id="emhow"><button class="emhb" id="emhb" aria-expanded="false" aria-controls="emtips"><i class="emkb">${EMI.kb}</i><b class="emhw">How to play</b><span class="emsep"></span><span class="emtip" id="emtip"><b>${tp[0]}.</b> ${tp[1]}</span><i class="emch">${EMI.chev}</i></button>
  <div class="emtips" id="emtips"><div class="emtin"><div class="bgtg">${BGL.map((t,i)=>`<div class="bgtc" style="--c:${t[2]}"><i>${i+1}</i><b>${t[0]}</b><span>${t[1]}</span></div>`).join('')}</div></div></div></section>
 <div class="row"><button class="sm" id="b">Back</button></div></div>`,'m');
 S.back=back||title;$('b').onclick=S.back;$('bgS').onclick=()=>start();$('bgB').onclick=()=>start(0,'bg');
 const hb=$('emhb'),hw=$('emhow');hb.onclick=()=>{const o=hw.classList.toggle('open');hb.setAttribute('aria-expanded',o);if(o)setTimeout(()=>{try{hw.scrollIntoView({behavior:'smooth',block:'end'})}catch(e){}},260)};
 live('bgScv',()=>emDraw($('bgScv'),[['skel',.5,1.1,'ember'],['imp',.8,.92,'blaze']]));if(LIVE.length)LIVE[LIVE.length-1].slow=2;
 live('bgBcv',()=>emDraw($('bgBcv'),[['gob',.58,1.1,'moss'],['bat',.84,.92,'wing']]));if(LIVE.length)LIVE[LIVE.length-1].slow=2;
 let ti=2;const tt=setInterval(()=>{const el=$('emtip');if(!el||!el.isConnected){clearInterval(tt);return}if(hw.matches(':hover')||hw.classList.contains('open'))return;ti=(ti+1)%BGL.length;el.classList.add('out');setTimeout(()=>{el.innerHTML=`<b>${BGL[ti][0]}.</b> ${BGL[ti][1]}`;el.classList.remove('out')},260)},5200);
 if(!window.__emk){window.__emk=1;addEventListener('keydown',e=>{if(!document.querySelector('.em')||e.ctrlKey||e.metaKey||e.altKey||S.mode==='play')return;if(e.key==='1'){e.preventDefault();start()}else if(e.key==='2'){e.preventDefault();start(0,'bg')}},true)}}
/* ---------- styles ---------- */
{const st=document.createElement('style');st.textContent=`
.em{position:relative;width:100%;max-width:1120px;margin:0 auto;display:flex;flex-direction:column;align-items:center;gap:clamp(8px,1.6vh,16px);flex:none;padding-bottom:72px}.em>.row{display:none}
.emh{text-align:center;animation:emIn .55s ease both}
.emt{display:flex;align-items:center;justify-content:center;gap:16px}
.emt h2{margin:0;font:400 clamp(42px,6.6vh,64px)/1 'Pirata One',Georgia,serif;letter-spacing:.03em;background:linear-gradient(100deg,#ffb52e 0%,#ffe38a 40%,#ff9a2a 55%,#ffd36a 100%);background-size:220% 100%;-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;text-shadow:none;filter:drop-shadow(0 3px 0 #5a2a05) drop-shadow(0 0 18px #ff9a2a55);animation:emSheen 6s ease-in-out infinite}
.emd{flex:0 1 150px;height:2px;position:relative;background:linear-gradient(90deg,#0000,#ffb52e);border-radius:2px}.emd.r{background:linear-gradient(270deg,#0000,#ffb52e)}
.emd::after{content:"";position:absolute;top:50%;right:-6px;width:10px;height:10px;background:#ffb52e;transform:translateY(-50%) rotate(45deg);box-shadow:0 0 12px #ffb52e;animation:emDia 2.8s ease-in-out infinite}.emd.r::after{right:auto;left:-6px}
.emh p{margin:4px 0 0;font:clamp(16px,2.4vh,21px) Georgia,serif;opacity:.92}
.emg{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:clamp(12px,2vw,22px);width:100%}
.emc{position:relative;display:flex;flex-direction:column;overflow:hidden;border-radius:22px;border:2px solid color-mix(in srgb,var(--c) 70%,#000);background:linear-gradient(180deg,#1b1338f4,#0d0a23fa);box-shadow:0 10px 30px #0009,0 0 26px color-mix(in srgb,var(--c) 22%,transparent),inset 0 0 0 1px #ffffff0d;animation:emUp .6s cubic-bezier(.2,.8,.2,1) both;transition:transform .22s ease,box-shadow .22s ease,border-color .22s}
.emc.std{animation-delay:.12s}.emc.beg{animation-delay:.24s}
.emc:hover,.emc:focus-within{transform:translateY(-6px);border-color:var(--c);box-shadow:0 18px 40px #000b,0 0 44px color-mix(in srgb,var(--c) 45%,transparent),inset 0 0 0 1px #ffffff14}
.emi{position:relative;height:clamp(140px,24vh,225px);overflow:hidden;background:#0a0618}
.emimg{position:absolute;inset:-4%;background:center/cover no-repeat;filter:saturate(1.15) brightness(.8);transition:transform .9s ease;animation:emPan 18s ease-in-out infinite alternate}
.emc:hover .emimg{transform:scale(1.07)}
.emcv{position:absolute;left:0;bottom:0;width:100%;height:100%;object-fit:contain;object-position:center bottom}
.emfade{position:absolute;inset:0;background:linear-gradient(180deg,#0000 55%,#0d0a23 100%),radial-gradient(120% 90% at 50% 100%,#0000 55%,#0008 100%);pointer-events:none}
.empt{position:absolute;inset:0;overflow:hidden;pointer-events:none}
.empt u{position:absolute;bottom:-8px;width:var(--z);height:var(--z);border-radius:50%;background:var(--c);box-shadow:0 0 8px var(--c);opacity:0;animation:emRise var(--s) linear var(--d) infinite}
.emnew{position:absolute;z-index:3;top:12px;right:12px;padding:3px 13px;border-radius:99px;background:#4fe3b0;color:#04241a;font:700 13px 'Poppins',system-ui,sans-serif;letter-spacing:.12em;animation:emPulse 2.2s ease-in-out infinite}
.emb{display:flex;flex-direction:column;gap:clamp(5px,1vh,10px);padding:4px clamp(14px,2vw,24px) clamp(14px,2vh,20px);flex:1}
.emb h3{margin:0;font:400 clamp(34px,5.4vh,48px)/1 'Pirata One',Georgia,serif;color:var(--c);text-shadow:0 2px 0 #0008,0 0 18px color-mix(in srgb,var(--c) 40%,transparent)}
.emtag{margin:0;font:clamp(15px,2.2vh,19px) Georgia,serif}
.emf{list-style:none;margin:2px 0 0;padding:0;display:flex;flex-direction:column;gap:clamp(5px,1vh,10px)}
.emf li{text-align:left;display:flex;align-items:center;gap:13px;animation:emSlide .5s ease both;animation-delay:calc(.5s + var(--i)*.09s)}
.emc.beg .emf li{animation-delay:calc(.62s + var(--i)*.09s)}
.emf i{flex:none;display:grid;place-items:center;width:clamp(36px,5.2vh,46px);height:clamp(36px,5.2vh,46px);border-radius:12px;color:var(--c);background:color-mix(in srgb,var(--c) 16%,#0a061a);border:1.5px solid color-mix(in srgb,var(--c) 55%,#000);box-shadow:inset 0 0 12px color-mix(in srgb,var(--c) 14%,transparent);transition:transform .2s}
.emc:hover .emf i{transform:scale(1.07) rotate(-3deg)}
.emaa{font:700 18px 'Poppins',system-ui,sans-serif}
.emf b{display:block;font:700 clamp(14px,2vh,17px)/1.2 Georgia,serif}.emf span{display:block;font:clamp(12.5px,1.8vh,15px) Georgia,serif;opacity:.78;margin-top:1px}
.ems{display:flex;border-radius:14px;border:1.5px solid #ffffff1f;background:#07041280;min-height:clamp(54px,8vh,70px)}
.ems>span:not(.emfirst){flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:6px}
.ems>span+span:not(.emfirst){border-left:1.5px solid #ffffff1f}
.ems b{font:400 clamp(26px,4.2vh,38px)/1 'Pirata One',Georgia,serif;color:#ffcf5a}.ems i{font:14px Georgia,serif;font-style:normal;opacity:.82}
.emfirst{flex:1;display:flex;align-items:center;gap:14px;padding:8px 16px;color:var(--c);border-radius:13px;background:linear-gradient(90deg,color-mix(in srgb,var(--c) 14%,transparent),transparent)}
.emfirst i{display:grid;place-items:center;animation:emBob 2.4s ease-in-out infinite}
.emfirst b{display:block;font:400 clamp(20px,3vh,26px)/1.1 'Pirata One',Georgia,serif;color:var(--c)}.emfirst span{display:block;font:clamp(13px,1.9vh,16px) Georgia,serif;color:var(--fg);opacity:.85}
.emgo{position:relative;overflow:hidden;margin-top:auto;display:flex;align-items:center;justify-content:center;gap:10px;width:100%;padding:clamp(8px,1.3vh,12px) 14px;border:0;border-radius:14px;cursor:pointer;color:#150a08;font:400 clamp(26px,4vh,34px)/1.1 'Pirata One',Georgia,serif;letter-spacing:.04em;background:linear-gradient(180deg,color-mix(in srgb,var(--c) 80%,#fff),var(--c) 60%,color-mix(in srgb,var(--c) 85%,#000));box-shadow:0 5px 0 color-mix(in srgb,var(--c) 45%,#000),0 8px 20px color-mix(in srgb,var(--c) 35%,transparent);transition:transform .12s,box-shadow .12s,filter .15s}
.emgo i{font-style:normal;display:inline-block;transition:transform .2s}
.emgo kbd{position:absolute;right:14px;top:50%;transform:translateY(-50%);font:700 13px 'Poppins',system-ui,sans-serif;padding:1px 8px;border-radius:6px;background:#0003;border:1px solid #0004;color:#150a08;opacity:.7}
.emgo::after{content:"";position:absolute;top:0;bottom:0;width:36%;left:-50%;background:linear-gradient(100deg,#0000,#fff9,#0000);transform:skewX(-20deg);animation:emShine 3.8s ease-in-out infinite}
.emc.beg .emgo::after{animation-delay:1.2s}
.emgo:hover{filter:brightness(1.08);transform:translateY(-1px)}.emgo:hover i{transform:translateX(6px)}
.emgo:active{transform:translateY(4px);box-shadow:0 1px 0 color-mix(in srgb,var(--c) 45%,#000)}
.emgo:focus-visible{outline:3px solid #fff;outline-offset:3px}
.emhow{width:100%;border-radius:18px;border:2px solid #7c6bd055;background:linear-gradient(180deg,#1b1338e8,#0f0a26f0);animation:emUp .6s ease .36s both;box-shadow:0 6px 20px #0007;transition:border-color .2s}
.emhow:hover,.emhow.open{border-color:#a99cf088}
.emhb{display:flex;align-items:center;gap:clamp(10px,1.6vw,18px);width:100%;padding:clamp(8px,1.4vh,14px) clamp(12px,2vw,22px);background:none;border:0;color:var(--fg);text-align:left;cursor:pointer;font:inherit;min-height:48px}
.emkb{color:#cfc8ff;display:grid;place-items:center}
.emhw{flex:none;font:400 clamp(24px,3.6vh,32px) 'Pirata One',Georgia,serif;color:#ffc94a;letter-spacing:.03em}
.emsep{flex:none;width:2px;align-self:stretch;margin:2px 0;background:#ffffff26}
.emtip{flex:1;font:clamp(13px,1.9vh,16px)/1.35 Georgia,serif;opacity:.95;transition:opacity .26s,transform .26s}.emtip b{font-weight:700}.emtip.out{opacity:0;transform:translateY(5px)}
.emch{flex:none;display:grid;place-items:center;width:38px;height:38px;border-radius:10px;border:1.5px solid #ffffff2a;background:#ffffff0c;transition:transform .3s,background .2s}
.emhb:hover .emch{background:#ffffff1c}.emhow.open .emch{transform:rotate(180deg)}
.emtips{display:grid;grid-template-rows:0fr;transition:grid-template-rows .38s ease}.emhow.open .emtips{grid-template-rows:1fr}
.emtin{overflow:hidden;min-height:0}.emtin .bgtg{padding:4px 16px 16px}
.bgtg{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}
.bgtc{display:grid;grid-template-columns:30px 1fr;column-gap:10px;row-gap:2px;text-align:left;padding:8px 10px;border-radius:14px;border:1px solid color-mix(in srgb,var(--c) 45%,#000);background:linear-gradient(180deg,#1a1236d0,#0f0a24e8)}
.bgtc i{grid-row:1/3;align-self:start;display:grid;place-items:center;width:30px;height:30px;border-radius:50%;background:color-mix(in srgb,var(--c) 22%,#0a061a);border:1px solid var(--c);color:var(--c);font:700 14px 'Poppins',system-ui,sans-serif;font-style:normal}
.bgtc b{font:400 20px 'Pirata One',Georgia,serif;color:var(--c)}.bgtc span{font:12.5px/1.3 Georgia,serif;opacity:.85}
@keyframes emIn{from{opacity:0;transform:translateY(-14px)}to{opacity:1;transform:none}}
@keyframes emUp{from{opacity:0;transform:translateY(26px) scale(.97)}to{opacity:1;transform:none}}
@keyframes emSlide{from{opacity:0;transform:translateX(-16px)}to{opacity:1;transform:none}}
@keyframes emSheen{0%,100%{background-position:0 0}50%{background-position:100% 0}}
@keyframes emDia{50%{transform:translateY(-50%) rotate(45deg) scale(1.35);box-shadow:0 0 20px #ffb52e}}
@keyframes emPulse{50%{box-shadow:0 0 22px #4fe3b0;transform:scale(1.06)}}
@keyframes emShine{0%,55%{left:-50%}100%{left:130%}}
@keyframes emRise{0%{transform:translateY(0);opacity:0}15%{opacity:.9}100%{transform:translateY(-250px) translateX(14px);opacity:0}}
@keyframes emPan{from{transform:scale(1.02) translateX(-1.5%)}to{transform:scale(1.02) translateX(1.5%)}}
@keyframes emBob{50%{transform:translateY(-3px) rotate(8deg)}}
@media (max-width:860px){.emg{grid-template-columns:1fr}.emi{height:200px}.bgtg{grid-template-columns:repeat(2,minmax(0,1fr))}.emd{flex-basis:60px}}
@media (max-width:620px){.emsep,.emkb{display:none}.emtip{font-size:13px}.bgtg{grid-template-columns:1fr}.emgo kbd{display:none}}
.bgov h2{text-shadow:none;background:linear-gradient(#e8fff4,#4fe3b0);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent}
.bgnote{font-size:14px;opacity:.8}
@media (prefers-reduced-motion:reduce){.em *,.emc,.emhow,.emh{animation:none!important;transition:none!important}.empt{display:none}}`;document.head.appendChild(st)}
