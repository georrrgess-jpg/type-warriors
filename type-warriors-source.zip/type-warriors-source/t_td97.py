# python3 t_td97.py [game.html] : Runestone Tower Defense 9.7b (95r) - the Tidecaller in the late endless waves and with the other
# towers: aim prediction, the twin jet on a lone monster, the swept wave front, the push-back cap, Brazier/Dragon leads on swept or
# stunned monsters, frost + tide stuns that always wear off, and a late Wonderland wave with no invincible or stuck monsters.
import asyncio,os,re,sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
HELP=re.search(r'HELP=r"""(.*?)"""',open(os.path.join(HERE,'t_td96.py')).read(),re.S).group(1)
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:500]),flush=True)
    if not ok:FAIL.append(name)
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E("()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const T=RPP().tut;for(const k of['build','wave','coins','upgrade','abil','twist_frost','twist_ember','twist_wonder'])T[k]=1;RPP().stars.ember=1;RPP().dragon=1}")
        await E(HELP)
        # a lone tough monster in front of one tower; returns [R,tw,e]
        await E("""()=>{window.tdLone=(type,tier,foe)=>{const R=tdNew('wonder',6),p=[...R.pads].sort((a,b)=>a.x-b.x)[4],tw=tdBuild(R,p,type,tier);const [s0,pi]=tdNear(R,p);
          const e=rpSpawn(foe||'golem',pi);e.s=s0;e.hp=e.mx=1e7;return [R,tw,e,s0,pi]};return 1}""")
        # ---------------------------------------------------------------- prediction
        r=await E("""()=>{const [R,tw,e]=tdLone('ballista',1);const s=e.s;const a=rptPred(R,e,.5);e.kb=100;e.kbV=200;const b=rptPred(R,e,.3);e.kb=0;e.stun=1;const c=rptPred(R,e,.5);e.stun=0;e.slowK=.5;e.slowT=2;const d=rptPred(R,e,.5);
          return [+(a-s).toFixed(1),+(b-s).toFixed(1),+(c-s).toFixed(1),+(d-s).toFixed(1),+(e.sp*.5).toFixed(1)]}""")
        chk('rptPred: a walking monster ahead, a sliding one behind, a stunned one in place, a slowed one half as far',r[0]>0 and abs(r[0]-r[4])<.2 and r[1]==-60 and r[2]==0 and abs(r[3]-r[4]/2)<.2,r)
        # ---------------------------------------------------------------- aiming
        r=await E("""()=>{const [R,tw,e]=tdLone('tide',3);e.kb=150;e.kbV=200;e.stun=.05;const a=rptAim(R,tw,RP_TW.tide.range[2]);return [Math.round(a.s-e.s),Math.round(rptPred(R,e,RPTD.jet)-e.s)]}""")
        chk('the jet lands just ahead of where a sliding monster WILL be (it used to land 46 px ahead of where it was)',r[0]<0 and abs(r[0]-(r[1]+30))<=1,r)
        r=await E("""()=>{const [R,tw,e,s0,pi]=tdLone('tide',3);const f=rpSpawn('golem',pi);f.s=s0+120;f.hp=f.mx=1e7;f.kb=120;f.kbV=200;tw.prio='first';const a=rptAim(R,tw,RP_TW.tide.range[2]);return [a.e===e,a.e===f]}""")
        chk('the shrine prefers a monster that is not already sliding back from another wave',r[0],r)
        # ---------------------------------------------------------------- twin jet on a lone monster
        r=await E("""()=>{const [R,tw,e]=tdLone('tide',4);e.sp=0;tw.cd=0;let waves=0,empty=0,hits=0;const h0=rpHurt;rpHurt=function(x,d,ap,src){if(src===tw&&x===e)hits++;return h0.apply(this,arguments)};
          for(let i=0;i<60*5;i++){const wb=R.tdWaves.slice();rpStep(R,1/60);for(const w of wb)if(!R.tdWaves.includes(w)){waves++;if(!w.hit.size)empty++}}rpHurt=h0;return [waves,empty,hits]}""")
        chk('tier 4 against a lone monster: both waves of every attack hit it (the twin used to land behind it and roll away)',r[0]>=4 and r[1]==0 and r[2]>=r[0],r)
        # ---------------------------------------------------------------- swept front
        r=await E("""()=>{const [R,tw,e,s0,pi]=tdLone('tide',5);e.sp=0;const T=RP_TW.tide,w={pi,s:s0+60,v:225,left:180,tw,tier:5,hit:new Set(),car:new Map(),trail:[],t:0,tt:0};R.tdWaves.push(w);rptWaves(R,.55);return [w.hit.has(e),Math.round(s0+60-w.s),e.kb>0]}""")
        chk('the wave front is swept: a monster it passes between two frames is hit and pushed (a long frame used to skip it)',r[0] and r[1]>=110 and r[2],r)
        # ---------------------------------------------------------------- push-back cap
        r=await E("""()=>{const [R,tw,e,s0]=tdLone('ballista',1);e.sp=0;e.s=5000;const s1=e.s;for(let k=0;k<40;k++){rptKnock(e,180,600);e.tdF=0;for(let i=0;i<6;i++)rptWaves(R,1/60)}return [Math.round(s1-e.s),RPTC.cap]}""")
        chk('a monster can only be pushed back so far in a short time, even with fatigue cleared (40 sweeps in 4 s: about 2,500 px without the cap)',r[0]<=2*r[1]+180,r)
        r=await E("""()=>{const [R,tw,e]=tdLone('ballista',1);e.sp=0;e.s=3000;e.tdP=RPTC.cap;const s=e.s;rptKnock(e,180,300);const a=e.kb||0;e.tdP=0;e.tdF=0;rptKnock(e,180,300);return [a,e.kb]}""")
        chk('the cap lifts again: once the push-back has faded the monster is swept normally',r[0]==0 and r[1]>100,r)
        # ---------------------------------------------------------------- the other towers
        r=await E("""()=>{const [R,tw,e]=tdLone('brazier',3);e.kb=140;e.kbV=200;e.stun=.05;tw.cd=0;let s=null;for(let i=0;i<30&&!s;i++){rpStep(R,1/60);s=R.shots.find(x=>x.k==='ember')}if(!s)return ['no shot'];
          const left=s.d-s.t;for(let i=0;i<60*left+2;i++){const q=rpPos(R,e);if(s.t+1/60>=s.d){return [Math.round(rpD2(q.x,q.y,s.x1,s.y1)**.5),s.r]}rpStep(R,1/60)}return ['?']}""")
        chk('a Brazier ember fired at a monster being swept back lands on it (it used to lead it forward onto empty road)',isinstance(r[0],(int,float)) and r[0]<r[1],r)
        r=await E("""()=>{const [R,tw,e]=tdLone('ballista',1);const p0=rpdLead(R,e,.4);e.kb=120;e.kbV=200;const p1=rpdLead(R,e,.4);const q=rpAt(R.G,e.s-80,e.pi);return [Math.round(Math.hypot(p1.x-q.x,p1.y+18-q.y)),Math.round(Math.hypot(p0.x-p1.x,p0.y-p1.y))]}""")
        chk('Dragon fire leads a swept monster to where it will slide to',r[0]<12 and r[1]>40,r)
        r=await E("""()=>{const [R,tw,e]=tdLone('frost',5);const T2=tdBuild(R,[...R.pads].sort((a,b)=>a.x-b.x)[5],'tide',5);for(let i=0;i<60*6;i++)rpStep(R,1/60);
          for(const p of R.pads)if(p.tw)p.tw.cd=1e9;const s=e.s;let st=0;for(let i=0;i<60*3;i++){rpStep(R,1/60);if(e.stun>0)st++}return [Math.round(e.s-s),st]}""")
        chk('frost tier 5 stuns and tide slides wear off: once the towers stop the monster walks on',r[0]>40 and r[1]<40,r)
        r=await E("""()=>{const [R,tw,e]=tdLone('bell',3,'golem');e.soak=1;const d0=tw.dmg;rpHurt(e,100,99,tw);const a=tw.dmg-d0;e.soak=0;rpHurt(e,100,99,tw);return [Math.round(a),Math.round(tw.dmg-d0-a)]}""")
        chk('the Storm Bell still hits soaked monsters 25% harder',r[0]==125 and r[1]==100,r)
        # ---------------------------------------------------------------- late endless
        r=await E("""()=>{RPP().dragon=1;const R=tdNew('wonder',1);R.wst='build';const cov=p=>{let n=0;for(const q of R.G.U){if((q.x-p.x)**2+((q.y-p.y)/.75)**2<220*220)n++}return n};
          const pads=[...R.pads].sort((a,b)=>cov(b)-cov(a));['dragon','tide','tide','dragon','frost','bell','prism','ballista'].forEach((t,k)=>tdBuild(R,pads[k],t,5));R.hp=1e9;
          R.wave=59;R.cd=0;rpWaveStart();const seen=new Map();let bad=0,inCave=0,t=0;
          while(t<120&&R.wst==='run'){R.hp=1e9;rpStep(R,1/30);t+=1/30;for(const e of R.foes){if(e.dead)continue;if(!isFinite(e.hp)||e.hp>e.mx+1e-6)bad++;let m=seen.get(e);if(e.s>=0&&!m){m={in:1,hp0:e.hp,t0:t};seen.set(e,m)}if(m&&e.s<0)inCave++}}
          let untouched=0;for(const [e,m] of seen)if(!e.dead&&e.hp>=m.hp0&&t-m.t0>20)untouched++;const tide=R.pads.filter(p=>p.tw&&p.tw.type==='tide').reduce((a,p)=>a+p.tw.dmg,0);
          return [bad,inCave,untouched,Math.round(tide),R.kills,seen.size]}""")
        chk('Wonderland wave 60 with tier-5 towers: no broken health, no monster pushed back into the cave, none untouched for 20 s, and the shrines deal real damage',r[0]==0 and r[1]==0 and r[2]==0 and r[3]>0 and r[4]>0,r)
        chk('no page errors',not er,er)
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
