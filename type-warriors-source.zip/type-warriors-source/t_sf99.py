# python3 t_sf99.py [game.html] : the Starfall Observatory (97d art, 97e battle; the Tower Vote winner) and the poll switched off (97f).
# Tenth tower, key U, 450 supply, whole-map range, ground and air; stars mark (+damage from every tower), finish weakened monsters,
# hit bosses for double; the telescope swings on a spring; tier 3 shards, tier 4 comet, tier 5 meteor shower; art per tier; frame cost.
import asyncio,os,sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:500]),flush=True)
    if not ok:FAIL.append(name)
HELP=r"""()=>{
 window.tdBuild=(R,p,t,tier)=>{rpBuild(p,t);const tw=p.tw;tw.build=1;while(tw.tier<tier)rpUpgrade(tw);tw.upK=1;return tw};
 window.tdNew=(map,wave)=>{try{rpLeave()}catch(e){}rpStart(map);const R=RPX;R.tut=null;R.hold=false;R.supply=1e9;R.wst='run';R.wave=wave||1;R.q=[];R.banner=null;R.foes=[];return R};
 window.tdFoe=(R,id,s,pi)=>{const e=rpSpawn(id,pi||0);e.s=s;e.sp=0;return e};
 window.tdRun=(R,sec)=>{for(let i=0;i<Math.round(sec*30);i++)rpStep(R,1/30)};
 return 1}"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E("()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const T=RPP().tut;for(const k in T)T[k]=1;for(const k of['build','wave','coins','upgrade','abil','twist_frost','twist_ember','twist_wonder'])T[k]=1;RPP().stars.ember=1;RPP().dragon=1}")
        await E(HELP)
        r=await E("()=>[TPOLL.off,!!document.getElementById('tpbtn'),!!document.getElementById('tpoll'),typeof tpFetch,typeof tpVote]")
        chk('the Tower Vote is switched off (no VOTE button, no window) but its code is kept for a later poll',r==[1,False,False,'function','function'],r)
        r=await E("()=>[RP_TWORDER[9],RP_KEYS[9],RPTW.star.n,RP_TW.star.cost,RP_TW.star.air,RP_TW.star.ground,RPSKIN.star,[1,2,3,4,5].map(t=>rpTowerTop('star',t))]")
        chk('the Starfall Observatory is the tenth tower: key U, 450 supply, ground and air, taller every tier',r[:3]==['star','U','Starfall Observatory'] and r[3][0]==450 and r[4]==1 and r[5]==1 and r[7]==sorted(r[7]) and len(set(r[7]))==5,r)
        r=await E("""async()=>{try{rpLeave()}catch(e){}rpStart('moss');const R=RPX;R.tut=null;R.supply=1000;await new Promise(r=>setTimeout(r,700));window.dispatchEvent(new KeyboardEvent('keydown',{key:'u'}));const a=R.place;R.place=null;
          const c=document.querySelector('.rpcard[data-tw="star"]'),ok=rpBuild(R.pads[0],'star');return [a,!!c,c&&!c.classList.contains('lock'),ok!==false&&!!R.pads[0].tw,R.pads[0].tw&&R.pads[0].tw.prio,1000-R.supply,document.querySelectorAll('.rpbar .rpcard').length===(typeof rpwTwLocked==='function'?RP_TWORDER.filter(t=>!rpwTwLocked(t)):RP_TWORDER).length]}""")
        chk('key U picks it; its card is in the bar and open from the start; it builds for 450 and targets the toughest monster by default',r==['star',True,True,True,'strong',450,True],r)
        # ---- whole map, a mark, the mark bonus
        r=await E("""()=>{const R=tdNew('frost',3);const tw=tdBuild(R,R.pads[0],'star',1);let far=null,fd=-1;const L=rpLen(R,{pi:0});
          for(let s=0;s<L;s+=20){const q=rpAt(R.G,s,0),d=Math.hypot(q.x-tw.x,q.y-tw.y);if(d>fd){fd=d;far=s}}const e=tdFoe(R,'bulwark',far);e.hp=e.mx=5000;tw.cd=.01;tdRun(R,1.6);
          const mk=[+e.mk.toFixed(2)>0,e.mkK,Math.round(5000-e.hp)];const h0=e.hp;rpHurt(e,100,99,null);return [Math.round(fd),...mk,+(h0-e.hp).toFixed(1)]}""")
        chk('it reaches the whole map: a monster far across the map is hit for its damage and marked; marked monsters take +18% from anything',r[0]>500 and r[1] and r[2]==0.18 and 140<=r[3]<=160 and r[4]==118,r)
        r=await E("""()=>{const R=tdNew('frost',3);const tw=tdBuild(R,R.pads[0],'star',1);const e=tdFoe(R,'gloom',300);e.hp=e.mx=5000;tw.cd=.01;tdRun(R,1.6);return [e.air,Math.round(5000-e.hp)>0,e.mk>0]}""")
        chk('it hits flyers',r==[True,True,True],r)
        r=await E("""()=>{const R=tdNew('frost',3);const tw=tdBuild(R,R.pads[0],'star',1);const a=tdFoe(R,'scamp',200),g=tdFoe(R,'golem',350),c=tdFoe(R,'scamp',500);g.hp=g.mx*.15;tw.cd=.01;const t=rpsfPick(R,tw,80);
          const R2=R;const tw2=tdBuild(R2,R2.pads[1],'star',1);tw.cd=.01;tw2.cd=5;tdRun(R2,.1);const t2=rpsfPick(R2,tw2,80);return [t===g,t2!==g]}""")
        chk('it picks the toughest monster; a second Observatory does not waste a star on one the first star will already finish',r==[True,True],r)
        r=await E("""()=>{const R=tdNew('frost',3);const tw=tdBuild(R,R.pads[0],'star',1);const e=tdFoe(R,'golem',300);e.mx=5000;e.hp=600;tw.cd=.01;tdRun(R,1.6);const fin=e.dead;
          const R2=tdNew('frost',15);const tw2=tdBuild(R2,R2.pads[0],'star',1);const B=tdFoe(R2,'behemoth',300);B.hp=B.mx;B.armor=0;const h0=B.hp;tw2.cd=.01;tdRun(R2,1.6);const d=h0-B.hp;
          B.hp=B.mx*.05;tw2.cd=.01;tdRun(R2,1.6);return [fin,R.sfFin,Math.round(d),B.dead?'dead':'alive']}""")
        chk('a star finishes a monster it leaves below 10% health; a boss takes double (about 300) and is never finished outright',r[0]==True and r[1]==1 and 285<=r[2]<=305 and r[3]=='alive',r)
        # ---- the swing
        r=await E("""()=>{const R=tdNew('frost',3);const tw=tdBuild(R,R.pads[0],'star',1);tw.aim=0;tw.lv=0;let best=null,bx=-1;const L=rpLen(R,{pi:0});
          for(let s=0;s<L;s+=20){const q=rpAt(R.G,s,0);if(q.x-tw.x>bx){bx=q.x-tw.x;best=s}}const e=tdFoe(R,'golem',best);e.hp=e.mx=1e7;tw.cd=RPSF.charge-.01;
          const tr=[];let jump=0,prev=tw.aim;for(let i=0;i<45;i++){rpStep(R,1/30);tr.push(tw.aim);jump=Math.max(jump,Math.abs(tw.aim-prev));prev=tw.aim}
          return [+tr[3].toFixed(3),+tr[14].toFixed(3),+tr[44].toFixed(3),+jump.toFixed(3),+Math.max(...tr).toFixed(3)]}""")
        chk('the telescope swings toward a target on the right smoothly (small steps), overshoots a little and settles',0<r[0]<r[1] and r[2]>0.6 and r[3]<0.12 and r[4]>=r[2] and r[4]<1.3,r)
        # ---- tiers 3-5
        r=await E("""()=>{const R=tdNew('wonder',40);const tw=tdBuild(R,R.pads[0],'star',3);const e=tdFoe(R,'golem',400);e.hp=e.mx=1e6;const a=tdFoe(R,'bulwark',420),b2=tdFoe(R,'bulwark',380);a.hp=a.mx=1e6;b2.hp=b2.mx=1e6;tw.cd=.01;
          tdRun(R,.9);const sh=R.sfStars.filter(s=>s.kind==='shard').length;tdRun(R,.6);return [sh,a.mk>0,b2.mk>0]}""")
        chk('tier 3 Star Shards: a star bursts into two shards that hit and mark nearby monsters',r==[2,True,True],r)
        r=await E("""()=>{const R=tdNew('wonder',40);const tw=tdBuild(R,R.pads[0],'star',4);const e=tdFoe(R,'golem',400);e.hp=e.mx=1e6;const fs=[];for(let k=-3;k<=3;k++)if(k){const f=tdFoe(R,'scamp',400+k*12);f.hp=f.mx=1e6;fs.push(f)}tw.cd=.01;
          tdRun(R,.85);return [fs.filter(f=>f.mk>0).length,fs.length]}""")
        chk('tier 4 Mythic comet: the impact hits and marks everything around it',r[0]>=5,r)
        r=await E("""()=>{const R=tdNew('wonder',40);const tw=tdBuild(R,R.pads[0],'star',5);const fs=[];for(let k=0;k<8;k++){const f=tdFoe(R,k%2?'golem':'bulwark',150+k*90);f.hp=f.mx=1e7;fs.push(f)}const n=[];
          for(let c=0;c<4;c++){tw.cd=.01;rpStep(R,1/30);n.push(R.sfStars.filter(s=>s.kind==='shower').length);tdRun(R,1.2)}return [n,R.sfCasts]}""")
        chk('tier 5 meteor shower: every fourth cast drops five more stars',r[0][:3]==[0,0,0] and r[0][3]==5 and r[1]==4,r)
        r=await E("""()=>{const R=tdNew('wonder',40);const T=RP_TW.star;return [T.cost,T.dmg,T.cd,T.mark,T.exec,[1,2,3,4,5].map(t=>RPLAY.star[t].sl)]}""")
        chk('every tier is stronger and its telescope longer (balance table)',all(r[1][i]<r[1][i+1] and r[2][i]>r[2][i+1] and r[3][i]<=r[3][i+1] and r[4][i]<=r[4][i+1] and r[5][i]<r[5][i+1] for i in range(4)),r)
        # ---- art
        r=await E("""()=>{const out=[];for(let t=1;t<=5;t++){const c=document.createElement('canvas');c.width=c.height=220;const g=c.getContext('2d');g.translate(110,170);rpTowerDraw(g,'star',t,'base',1,{aim:.5});
           const d=g.getImageData(0,0,220,220).data;let n=0;for(let i=3;i<d.length;i+=4)if(d[i]>20)n++;out.push([n,c.toDataURL().length])}
          const ic=rpTowerIcon('star',1,'base',96);return [out.map(x=>x[0]),new Set(out.map(x=>x[1])).size,ic.width]}""")
        chk('each tier draws differently and fuller than the last (tier 2 richer than tier 1); the icon renders',r[1]==5 and r[0][1]>r[0][0] and r[0][4]>r[0][2] and r[2]==96,r)
        r=await E("""()=>{const draw=()=>{const c=document.createElement('canvas');c.width=c.height=200;const g=c.getContext('2d');g.translate(100,150);rpTowerDraw(g,'bell',2,'base',0,{});return c.toDataURL()};
          RPSPR.clear();const a=draw();RPSPR.clear();for(const t of ['star','mortar','still','tide'])rpTowerWarm(t,2,'base');return a===draw()}""")
        chk('warming the newer towers no longer spoils the Storm Bell art (cached by tier only)',r,r)
        # the Observatory's own art (9.9p: the 97k glow / particle layer is switched off here; t_fx99 measures that layer)
        r=await E("""()=>{if(typeof RPG!=='undefined')RPG.off=1;const c=document.createElement('canvas');c.width=1600;c.height=900;const g=c.getContext('2d');for(let t=1;t<=5;t++)rpTowerWarm('star',t,'base');
          for(let t=1;t<=5;t++){g.save();g.translate(100+t*200,400);rpTowerDraw(g,'star',t,'base',.5,{aim:.3,charge:.5});g.restore()}
          const t0=performance.now();for(let f=0;f<60;f++)for(let t=1;t<=5;t++){g.save();g.translate(100+t*200,400);rpTowerDraw(g,'star',t,'base',f/30,{aim:Math.sin(f/9),charge:(f%30)/30,fire:f%20<5?.8:0});g.restore()}
          const v=+((performance.now()-t0)/300).toFixed(3);if(typeof RPG!=='undefined')RPG.off=0;return v}""")
        chk('frame cost: one Observatory draws in well under a millisecond',r<0.5,r)
        r=await E("""async()=>{const R=tdNew('frost',3);const tw=tdBuild(R,R.pads[0],'star',2);tdFoe(R,'golem',300);R.sel=tw;await new Promise(r=>setTimeout(r,400));const el=document.getElementById('rpinfo');return el?[/whole map/.test(el.textContent),/Mark/.test(el.textContent),/Finish/.test(el.textContent)]:null}""")
        chk('its info panel shows whole-map range, the mark and the finish threshold',r==[True,True,True],r)
        r=await E("""()=>{const R=tdNew('wonder',30);R.wst='build';const tw=tdBuild(R,R.pads[0],'star',5);for(const p of R.pads.slice(1,6))tdBuild(R,p,'dragon',4);R.cd=0;rpWaveStart();let t=0;while(R.wst==='run'&&t<240){rpStep(R,1/30);t+=1/30}
          return [R.wst,R.hp>0,R.sfCasts>5,R.foes.filter(e=>!e.dead&&(!isFinite(e.hp)||e.mk<0)).length]}""")
        chk('a real Wonderland wave with a Celestial Observatory ends cleanly (no stuck or broken monsters)',r[0]=='build' and r[1] and r[2] and r[3]==0,r)
        await pg.screenshot(path=os.path.join(HERE,'shots','sf99_test.png'))
        chk('no page errors',not er,er)
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
