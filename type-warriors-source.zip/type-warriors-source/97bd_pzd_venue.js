/* ===== 10.7 THE CROOKED CUE: The Gilded Hoard, the room, the table and the match (97bd) =====
   The vault, baked once into one 1600 x 900 canvas (pzdBake): a coffered ceiling of dark carved wood with gold rosettes, carved walnut
   wall panels with gold beading and a gold frieze, a round vault door on the left (bolts, locking bars, a spoked wheel, gold light
   seeping round the seal), a mountain of coins under a carved arch on the right (goblets, a crown, a sword, inset gems), two gem
   lanterns hanging in the gaps of the HUD, a polished black marble floor with gold inlay and coin heaps in the corners.
   The table keeps the exact 96f geometry (cushions trace PZ_TBL, pockets on PZ_POCK) with its own look: ebony rails with a gold bead and
   a gold inlay, gold corner plates, ruby-and-gold sights, a crimson-and-gold felt (the 'hoard' felt: 97bg's pzf7Felt when it is there,
   else our own damask), ruby-lit pockets in gold rings, a velvet ball return and carved legs on dragon claws.
   Per frame (pzDrawLamp / pzDrawLights / pzDrawDust wrapped, only while PZ.pzd): the gold-chain chandelier with candle flames (baked
   sprite + glows), lantern pulses, glints on the coins, a coin that slides down the mountain now and then, and gold glitter.
   Lite mode / reduced motion keep only the chandelier. Shot flair per player (pzContact wrapped), the VS intro (pzIntro wrapped) and
   a slow treasure-vault waltz (note wrapped) while you are in the Gilded Hoard. */
const PZD_FELT={id:'hoard',n:'Gilded Hoard',a:'#a01e32',b:'#6e1222',c:'#460a16'};/* 97bg's PZ_FELT 'hoard' colours win when it loads (pzdFeltSync) */
function pzdFeltSync(){try{const f=PZ_FELT.find(x=>x.id==='hoard');if(f){PZD_FELT.a=f.a;PZD_FELT.b=f.b;PZD_FELT.c=f.c}}catch(e){}}
const pzdVenueNow=()=>!!((PZ.on&&PZ.pzd)||(!PZ.on&&typeof ov!=='undefined'&&ov&&ov.querySelector(':scope>.pzd8')));
/* ---------- shared bits: gold, coins, gems ---------- */
const pzdGoldG=(g,x0,y0,x1,y1)=>pzLin(g,x0,y0,x1,y1,[[0,'#fff4c0'],[.28,'#ffd45a'],[.62,'#c8901e'],[1,'#7a4a0a']]);
function pzdCoin(g,x,y,r,k,c){/* a coin seen at an angle: k = squash (1 face on, .3 edge on) */
 const ry=r*k;g.fillStyle=c||'#b07818';g.beginPath();g.ellipse(x,y+ry*.35+.6,r,ry,0,0,TAU);g.fill();
 g.fillStyle=pzLin(g,x-r,y-ry,x+r,y+ry,[[0,'#fff2b0'],[.4,'#ffd04a'],[1,'#c08a1a']]);g.beginPath();g.ellipse(x,y,r,ry,0,0,TAU);g.fill();
 g.strokeStyle='rgba(122,70,8,.9)';g.lineWidth=Math.max(.8,r*.12);g.stroke();if(r>4){g.strokeStyle='rgba(150,96,16,.55)';g.lineWidth=Math.max(.6,r*.08);g.beginPath();g.ellipse(x,y,r*.66,ry*.66,0,0,TAU);g.stroke()}
 g.fillStyle='rgba(255,255,235,.7)';g.beginPath();g.ellipse(x-r*.3,y-ry*.35,r*.28,ry*.18,-.3,0,TAU);g.fill()}
const PZD_GEMC={ruby:['#ff5a6a','#c8102e','#5a0414'],emer:['#7affb4','#18a85a','#04401e'],sapph:['#8ac8ff','#2a5ae8','#0a1450'],amet:['#e0a8ff','#8a3ad8','#2a0a50'],topaz:['#fff0a0','#ffb020','#7a3a04']};
function pzdGem(g,x,y,r,kind,lw){const C=PZD_GEMC[kind]||PZD_GEMC.ruby;g.save();g.translate(x,y);g.beginPath();for(let i=0;i<8;i++){const a=i/8*TAU+Math.PI/8;g.lineTo(Math.cos(a)*r,Math.sin(a)*r*.86)}g.closePath();
 g.fillStyle=pzLin(g,-r,-r,r,r,[[0,C[0]],[.5,C[1]],[1,C[2]]]);g.fill();g.strokeStyle=PZ_O;g.lineWidth=lw==null?Math.max(1.2,r*.22):lw;g.stroke();
 g.fillStyle=C[0];g.globalAlpha=.55;g.beginPath();for(let i=0;i<8;i++){const a=i/8*TAU+Math.PI/8;g.lineTo(Math.cos(a)*r*.5,Math.sin(a)*r*.43)}g.closePath();g.fill();g.globalAlpha=1;
 g.fillStyle='rgba(255,255,255,.85)';g.beginPath();g.ellipse(-r*.32,-r*.32,r*.22,r*.13,-.7,0,TAU);g.fill();g.restore()}
function pzdHeap(g,x0,x1,by,px,py,seed,o){o=o||{};/* a mountain of coins: a silhouette, a gold body, coins thick on the surface, gems */
 const pts=[];const N=28;for(let i=0;i<=N;i++){const u=i/N,x=x0+(x1-x0)*u,d=Math.abs(x-px)/Math.max(px-x0,x1-px),h=(by-py)*Math.pow(Math.max(0,1-d),1.35)*(1-.06*Math.sin(u*17+seed));pts.push([x,by-h-(i%2?3:0)])}
 const path=()=>{g.beginPath();g.moveTo(x0,by);for(const [x,y] of pts)g.lineTo(x,y);g.lineTo(x1,by);g.closePath()};
 path();g.fillStyle=pzLin(g,0,py,0,by,[[0,'#ffd860'],[.35,'#d8a028'],[1,'#7a4a0a']]);g.fill();
 g.save();path();g.clip();
 for(let i=0;i<(o.n||420);i++){const u=pzNoise(i*3.1+seed),v=pzNoise(i*5.7+seed+1),x=x0+u*(x1-x0),top=pts[Math.round(u*N)][1],y=top+Math.pow(v,1.7)*(by-top),r=(o.r||7)*(.7+pzNoise(i+seed*2)*.6)*(1+(y-py)/(by-py)*.5);
  pzdCoin(g,x,y,r,.38+pzNoise(i*1.3+seed)*.3)}
 g.fillStyle=pzLin(g,0,py,0,by,[[0,'rgba(0,0,0,0)'],[.7,'rgba(40,14,0,.12)'],[1,'rgba(30,8,0,.5)']]);g.fillRect(x0,py-10,x1-x0,by-py+10);g.restore();
 for(let i=0;i<(o.gems||6);i++){const u=.12+pzNoise(i*7.3+seed+4)*.76,x=x0+u*(x1-x0),top=pts[Math.round(u*N)][1],y=top+8+pzNoise(i*2.9+seed)*(by-top)*.5;pzdGem(g,x,y,(o.r||7)*1.1+pzNoise(i+seed)*4,['ruby','emer','sapph','amet','topaz'][i%5])}
 g.strokeStyle=PZ_O;g.lineWidth=4;g.lineJoin='round';g.beginPath();g.moveTo(x0,by);for(const [x,y] of pts)g.lineTo(x,y);g.lineTo(x1,by);g.stroke();
 g.strokeStyle='rgba(255,248,200,.55)';g.lineWidth=2;g.beginPath();pts.forEach(([x,y],i)=>{if(Math.abs(x-px)<(x1-x0)*.3)i&&g.lineTo(x,y+3);else g.moveTo(x,y+3)});g.stroke();return pts}
function pzdGoblet(g,x,y,s){g.save();g.translate(x,y);g.scale(s,s);g.fillStyle=pzdGoldG(g,-20,-60,20,0);g.beginPath();g.moveTo(-22,-62);g.quadraticCurveTo(-22,-30,-4,-24);g.lineTo(-3,-8);g.lineTo(-14,0);g.lineTo(14,0);g.lineTo(3,-8);g.lineTo(4,-24);g.quadraticCurveTo(22,-30,22,-62);g.closePath();g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();
 g.fillStyle='#5a0414';g.beginPath();g.ellipse(0,-62,22,5,0,0,TAU);g.fill();g.stroke();pzdGem(g,0,-42,5,'ruby');g.fillStyle='rgba(255,255,230,.6)';g.fillRect(-15,-56,3,20);g.restore()}
function pzdCrown(g,x,y,s,rot){g.save();g.translate(x,y);g.rotate(rot||0);g.scale(s,s);g.fillStyle=pzdGoldG(g,-30,-40,30,0);g.beginPath();g.moveTo(-30,0);g.lineTo(-34,-30);g.lineTo(-17,-16);g.lineTo(0,-40);g.lineTo(17,-16);g.lineTo(34,-30);g.lineTo(30,0);g.closePath();g.fill();g.strokeStyle=PZ_O;g.lineWidth=3.5;g.stroke();
 g.fillStyle='#c8901e';g.fillRect(-30,-8,60,8);g.strokeRect(-30,-8,60,8);for(const [gx,k] of[[-18,'sapph'],[0,'ruby'],[18,'emer']])pzdGem(g,gx,-4,4.5,k,1.5);for(const [px,py] of[[-34,-30],[0,-40],[34,-30]]){pzEll(g,'#fff4c0',px,py,4,4,0,2)}g.restore()}
/* ---------- the room ---------- */
function pzdPanel(g,x,y,w,h,arch){/* a carved walnut panel with gold beading */
 g.fillStyle=pzLin(g,x,y,x+w,y+h,[[0,'#3e1a0e'],[1,'#2a1008']]);const p=()=>{g.beginPath();if(arch){g.moveTo(x,y+h);g.lineTo(x,y+w/2);g.arc(x+w/2,y+w/2,w/2,Math.PI,0);g.lineTo(x+w,y+h);g.closePath()}else{g.roundRect(x,y,w,h,6)}};p();g.fill();
 g.strokeStyle='rgba(0,0,0,.55)';g.lineWidth=5;p();g.stroke();g.strokeStyle='rgba(232,176,64,.55)';g.lineWidth=1.6;g.save();g.translate(0,0);const i=7;g.beginPath();if(arch){g.moveTo(x+i,y+h-i);g.lineTo(x+i,y+w/2);g.arc(x+w/2,y+w/2,w/2-i,Math.PI,0);g.lineTo(x+w-i,y+h-i);g.closePath()}else g.roundRect(x+i,y+i,w-i*2,h-i*2,4);g.stroke();g.restore();
 g.fillStyle='rgba(255,200,120,.05)';g.fillRect(x+3,y+(arch?w/2:4),3,h-(arch?w/2:8))}
function pzdBakeRoom(g){const fy=596;
 g.fillStyle='#1a0a06';g.fillRect(0,0,1600,900);
 /* coffered ceiling with gold rosettes */
 g.fillStyle=pzLin(g,0,0,0,140,[[0,'#140604'],[1,'#2a1208']]);g.fillRect(0,0,1600,140);
 for(let x=0;x<1600;x+=100){g.fillStyle=pzLin(g,x,0,x,124,[[0,'#1e0a05'],[1,'#341609']]);g.fillRect(x+8,8,84,108);g.strokeStyle='rgba(0,0,0,.6)';g.lineWidth=4;g.strokeRect(x+8,8,84,108);g.strokeStyle='rgba(232,176,64,.35)';g.lineWidth=1.5;g.strokeRect(x+15,15,70,94);
  g.fillStyle='rgba(255,200,100,.06)';g.fillRect(x+10,10,80,3);pzEll(g,'#c8901e',x+50,62,7,7,0,2);pzEll(g,'#ffe27a',x+50,62,3,3,0,0)}
 /* the gold frieze under the ceiling: a band of coins and diamonds */
 g.fillStyle=pzdGoldG(g,0,124,0,154);g.fillRect(0,124,1600,28);g.strokeStyle=PZ_O;g.lineWidth=3;g.beginPath();g.moveTo(0,124);g.lineTo(1600,124);g.moveTo(0,152);g.lineTo(1600,152);g.stroke();
 for(let x=0;x<1600;x+=40){g.fillStyle='#7a4a0a';g.beginPath();g.moveTo(x+20,129);g.lineTo(x+28,138);g.lineTo(x+20,147);g.lineTo(x+12,138);g.closePath();g.fill();g.fillStyle='#fff2b0';g.beginPath();g.arc(x,138,2.2,0,TAU);g.fill()}
 g.fillStyle='rgba(0,0,0,.35)';g.fillRect(0,152,1600,8);
 /* carved walnut wall: pilasters and arched panels */
 g.fillStyle=pzLin(g,0,160,0,fy,[[0,'#2e1309'],[1,'#200c06']]);g.fillRect(0,160,1600,fy-160);
 for(let x=0;x<1600;x+=160){pzdPanel(g,x+22,196,116,250,true);pzdPanel(g,x+22,462,116,110,false);
  g.fillStyle=pzLin(g,x-10,0,x+10,0,[[0,'#1a0804'],[.5,'#4a220e'],[1,'#1a0804']]);g.fillRect(x-9,160,18,fy-160);g.fillStyle=pzdGoldG(g,x-12,170,x+12,186);g.fillRect(x-12,166,24,14);g.strokeStyle=PZ_O;g.lineWidth=2;g.strokeRect(x-12,166,24,14)}
 /* the dado rail */
 g.fillStyle=pzLin(g,0,fy-24,0,fy,[[0,'#5a2a10'],[1,'#2a1006']]);g.fillRect(0,fy-24,1600,24);g.fillStyle=pzdGoldG(g,0,fy-28,0,fy-22);g.fillRect(0,fy-28,1600,5);
 /* gem lanterns hanging in the gaps of the HUD (the lights pulse per frame) */
 for(const [x,k] of[[550,'ruby'],[1050,'emer']]){g.strokeStyle='#8a6018';g.lineWidth=3;g.beginPath();g.moveTo(x,0);g.lineTo(x,30);g.stroke();for(let i=0;i<4;i++){g.strokeStyle=PZ_O;g.lineWidth=1.5;g.beginPath();g.ellipse(x,6+i*7,2.4,4,0,0,TAU);g.stroke()}
  pzGlow(g,x,72,90,k==='ruby'?'rgba(255,70,90,1)':'rgba(70,255,150,1)',.3);
  g.fillStyle=pzdGoldG(g,x-26,30,x+26,40);g.beginPath();g.moveTo(x-14,30);g.lineTo(x+14,30);g.lineTo(x+26,42);g.lineTo(x-26,42);g.closePath();g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();
  g.fillStyle='rgba(20,8,4,.5)';g.beginPath();g.moveTo(x-22,42);g.lineTo(x+22,42);g.lineTo(x+18,98);g.lineTo(x-18,98);g.closePath();g.fill();pzdGem(g,x,70,17,k,3);
  g.strokeStyle=pzdGoldG(g,x-26,40,x+26,100);g.lineWidth=4;g.beginPath();g.moveTo(x-22,42);g.lineTo(x-18,98);g.moveTo(x+22,42);g.lineTo(x+18,98);g.moveTo(x,42);g.lineTo(x,50);g.moveTo(x,90);g.lineTo(x,98);g.stroke();
  g.fillStyle=pzdGoldG(g,x-22,96,x+22,106);pzRR(g,x-24,96,48,10,4);g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();g.beginPath();g.moveTo(x,106);g.lineTo(x,114);g.stroke();pzEll(g,'#ffd45a',x,116,4,4,0,2)}
 /* the round vault door on the left */
 {const cx=160,cy=372,R=148;pzGlow(g,cx,cy,R+70,'rgba(255,190,70,1)',.32);
  g.fillStyle='#120804';g.beginPath();g.arc(cx,cy,R+30,0,TAU);g.fill();
  g.lineWidth=30;g.strokeStyle=pzLin(g,cx-R,cy-R,cx+R,cy+R,[[0,'#fff0a8'],[.3,'#d8a030'],[.6,'#8a5a14'],[1,'#4a2a06']]);g.beginPath();g.arc(cx,cy,R+14,0,TAU);g.stroke();
  g.strokeStyle=PZ_O;g.lineWidth=4;g.beginPath();g.arc(cx,cy,R+30,0,TAU);g.stroke();g.beginPath();g.arc(cx,cy,R-1,0,TAU);g.stroke();
  for(let i=0;i<20;i++){const a=i/20*TAU;pzEll(g,'#ffe890',cx+Math.cos(a)*(R+14),cy+Math.sin(a)*(R+14),4.2,4.2,0,1.6)}
  /* the seal glows where the gold light seeps out */
  g.strokeStyle='rgba(255,220,120,.85)';g.lineWidth=3;g.beginPath();g.arc(cx,cy,R+1.5,Math.PI*.1,Math.PI*.9);g.stroke();
  /* the door: steel face in concentric rings */
  g.fillStyle=pzLin(g,cx-R,cy-R,cx+R,cy+R,[[0,'#a8a0a0'],[.45,'#6a6070'],[1,'#2a2430']]);g.beginPath();g.arc(cx,cy,R-2,0,TAU);g.fill();
  for(const [r,c,w] of[[R-16,'rgba(0,0,0,.4)',4],[R-20,'rgba(255,255,255,.25)',2],[R*.62,'rgba(0,0,0,.4)',4],[R*.62-4,'rgba(255,255,255,.22)',2]]){g.strokeStyle=c;g.lineWidth=w;g.beginPath();g.arc(cx,cy,r,0,TAU);g.stroke()}
  for(let i=0;i<8;i++){const a=i/8*TAU+Math.PI/8;g.save();g.translate(cx+Math.cos(a)*(R*.8),cy+Math.sin(a)*(R*.8));g.rotate(a);g.fillStyle=pzdGoldG(g,-14,-7,14,7);pzRR(g,-16,-8,32,16,5);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2.5;g.stroke();g.restore()}
  /* the wheel */
  g.strokeStyle=PZ_O;g.lineWidth=13;for(let i=0;i<3;i++){const a=i/3*Math.PI+.3;g.beginPath();g.moveTo(cx+Math.cos(a)*62,cy+Math.sin(a)*62);g.lineTo(cx-Math.cos(a)*62,cy-Math.sin(a)*62);g.stroke()}
  g.strokeStyle=pzdGoldG(g,cx-60,cy-60,cx+60,cy+60);g.lineWidth=8;for(let i=0;i<3;i++){const a=i/3*Math.PI+.3;g.beginPath();g.moveTo(cx+Math.cos(a)*62,cy+Math.sin(a)*62);g.lineTo(cx-Math.cos(a)*62,cy-Math.sin(a)*62);g.stroke()}
  for(let i=0;i<6;i++){const a=i/6*TAU+.3;pzEll(g,'#ffd45a',cx+Math.cos(a)*64,cy+Math.sin(a)*64,9,9,0,3)}
  g.lineWidth=10;g.strokeStyle=PZ_O;g.beginPath();g.arc(cx,cy,48,0,TAU);g.stroke();g.lineWidth=6;g.strokeStyle='#e8b040';g.stroke();
  pzEll(g,'#c8901e',cx,cy,24,24,0,4);g.fillStyle=pzdGoldG(g,cx-20,cy-20,cx+20,cy+20);g.beginPath();g.arc(cx,cy,18,0,TAU);g.fill();g.fillStyle='#12081f';g.font='400 26px "Pirata One",Georgia,serif';g.textAlign='center';g.textBaseline='middle';g.fillText('H',cx,cy+1);
  /* the dial */
  {const dx=cx+92,dy=cy-46;pzEll(g,'#2a2430',dx,dy,15,15,0,3);for(let i=0;i<12;i++){const a=i/12*TAU;g.strokeStyle='#e8e0d0';g.lineWidth=1.4;g.beginPath();g.moveTo(dx+Math.cos(a)*9,dy+Math.sin(a)*9);g.lineTo(dx+Math.cos(a)*13,dy+Math.sin(a)*13);g.stroke()}pzEll(g,'#c8901e',dx,dy,5,5,0,1.5)}
  g.fillStyle='rgba(255,255,255,.1)';g.beginPath();g.ellipse(cx-50,cy-60,60,26,-.7,0,TAU);g.fill()}
 /* a carved arch on the right, full of treasure */
 {const x0=1312,x1=1600,ay=176;g.fillStyle='#0e0402';g.beginPath();g.moveTo(x0,fy);g.lineTo(x0,ay+140);g.quadraticCurveTo(x0,ay,x0+144,ay);g.quadraticCurveTo(x1+10,ay,x1+20,ay+140);g.lineTo(x1+20,fy);g.closePath();g.fill();
  pzGlow(g,1462,470,240,'rgba(255,190,60,1)',.42);
  g.save();g.beginPath();g.moveTo(x0,fy+60);g.lineTo(x0,ay+140);g.quadraticCurveTo(x0,ay,x0+144,ay);g.quadraticCurveTo(x1+10,ay,x1+20,ay+140);g.lineTo(x1+20,fy+60);g.closePath();g.clip();
  pzdHeap(g,1290,1640,640,1470,330,7,{n:520,r:7,gems:9});pzdGoblet(g,1392,388,1.05);pzdCrown(g,1478,338,1.25,-.12);
  /* a sword stuck in the hoard */
  g.save();g.translate(1548,400);g.rotate(.32);g.fillStyle=pzLin(g,-6,0,6,0,[[0,'#d8dce8'],[.5,'#ffffff'],[1,'#8a90a8']]);g.beginPath();g.moveTo(-6,0);g.lineTo(6,0);g.lineTo(5,-110);g.lineTo(0,-124);g.lineTo(-5,-110);g.closePath();g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();
   g.fillStyle=pzdGoldG(g,-24,-130,24,-118);pzRR(g,-24,-130,48,10,4);g.fill();g.stroke();g.fillStyle='#5a1a10';pzRR(g,-5,-160,10,32,4);g.fill();g.stroke();pzdGem(g,0,-164,6,'sapph');g.restore();
  pzdGoblet(g,1586,452,.8);g.restore();
  /* the arch's moulding */
  g.lineWidth=22;g.strokeStyle=pzLin(g,0,ay,0,fy,[[0,'#5a2a10'],[1,'#2a1006']]);g.beginPath();g.moveTo(x0,fy);g.lineTo(x0,ay+140);g.quadraticCurveTo(x0,ay,x0+144,ay);g.quadraticCurveTo(x1+10,ay,x1+20,ay+140);g.stroke();
  g.lineWidth=4;g.strokeStyle='#d8a030';g.beginPath();g.moveTo(x0+11,fy);g.lineTo(x0+11,ay+140);g.quadraticCurveTo(x0+11,ay+11,x0+144,ay+11);g.quadraticCurveTo(x1,ay+11,x1+9,ay+140);g.stroke();
  g.lineWidth=3;g.strokeStyle=PZ_O;g.beginPath();g.moveTo(x0-11,fy);g.lineTo(x0-11,ay+140);g.quadraticCurveTo(x0-11,ay-11,x0+144,ay-11);g.quadraticCurveTo(x1+20,ay-11,x1+31,ay+140);g.stroke();
  /* the keystone: a dragon's eye in gold */
  {const kx=x0+144,ky=ay-2;g.fillStyle=pzdGoldG(g,kx-24,ky-26,kx+24,ky+26);g.beginPath();g.moveTo(kx-20,ky-26);g.lineTo(kx+20,ky-26);g.lineTo(kx+14,ky+24);g.lineTo(kx-14,ky+24);g.closePath();g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();
   g.fillStyle='#ffe27a';g.beginPath();g.ellipse(kx,ky,10,7,0,0,TAU);g.fill();g.stroke();g.fillStyle='#12081f';g.beginPath();g.ellipse(kx,ky,2.4,6,0,0,TAU);g.fill()}}
 /* floor: black marble with gold inlay in perspective */
 g.fillStyle=pzLin(g,0,fy,0,900,[[0,'#1c0e0c'],[1,'#0a0404']]);g.fillRect(0,fy,1600,900-fy);
 {const vx=800,vy=300;for(let i=-16;i<=16;i++){const bx=vx+i*130,tx=vx+(bx-vx)*((fy-vy)/(900-vy));g.strokeStyle=i%2?'rgba(232,176,64,.22)':'rgba(255,255,255,.04)';g.lineWidth=i%2?2:1;g.beginPath();g.moveTo(tx,fy);g.lineTo(bx,900);g.stroke()}
  for(let k=1;k<8;k++){const y=fy+(900-fy)*Math.pow(k/8,1.6);g.strokeStyle=`rgba(232,176,64,${.08+k*.02})`;g.lineWidth=1.5;g.beginPath();g.moveTo(0,y);g.lineTo(1600,y);g.stroke()}
  for(let i=0;i<60;i++){const x=pzNoise(i*4.1)*1600,y=fy+10+pzNoise(i*2.7)*280;g.strokeStyle='rgba(255,255,255,.035)';g.lineWidth=1;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+30,y+8,x+60,y-4);g.stroke()}}
 g.fillStyle='rgba(0,0,0,.55)';g.fillRect(0,fy-2,1600,6);g.fillStyle=pzdGoldG(g,0,fy+3,0,fy+7);g.fillRect(0,fy+3,1600,3);
 /* the glow of the hoard and the vault door on the floor */
 pzGlow(g,160,640,190,'rgba(255,190,80,1)',.14);pzGlow(g,1460,660,220,'rgba(255,190,60,1)',.22);
 /* coin heaps in the corners and a scatter of coins */
 pzdHeap(g,-40,250,920,40,770,13,{n:220,r:7,gems:4});pzdHeap(g,1260,1640,920,1520,700,19,{n:300,r:8,gems:5});
 for(let i=0;i<26;i++){const x=pzNoise(i*6.3+2)*1600,y=640+pzNoise(i*3.3)*240;if(x>300&&x<1300&&y>700)continue;pzdCoin(g,x,y,6+pzNoise(i)*3,.36)}
 const v=g.createRadialGradient(800,440,320,800,440,1000);v.addColorStop(0,'rgba(0,0,0,0)');v.addColorStop(1,'rgba(10,2,0,.7)');g.fillStyle=v;g.fillRect(0,0,1600,900)}
/* ---------- the table (exact 96f geometry, its own look) ---------- */
function pzdFeltPaint(g,w,h){/* crimson-and-gold felt: the base cloth, then 97bg's 'hoard' overlay (pzf7Felt) when it exists, else a damask of our own */
 const F=PZD_FELT;g.fillStyle=pzLin(g,0,0,0,h,[[0,F.a],[1,F.b]]);g.fillRect(-30,-30,w+60,h+60);
 if(typeof pzf7Felt==='function'){try{if(pzf7Felt(g,'hoard',{x:0,y:0,w,h}))return}catch(e){}}
 g.strokeStyle='rgba(255,210,110,.07)';g.lineWidth=1.4;for(let r=-1;r<12;r++)for(let c=-1;c<22;c++){const x=c*44+(r%2)*22,y=r*44;g.beginPath();g.moveTo(x,y-20);g.lineTo(x+20,y);g.lineTo(x,y+20);g.lineTo(x-20,y);g.closePath();g.stroke();
  g.fillStyle='rgba(255,210,110,.06)';g.beginPath();g.moveTo(x,y-7);g.quadraticCurveTo(x+6,y,x,y+7);g.quadraticCurveTo(x-6,y,x,y-7);g.fill()}
 {const tl=pzCv(96,96),tx=tl.getContext('2d'),im=tx.createImageData(96,96);for(let i=0;i<96*96;i++){const n=pzNoise(i*1.7+31),v=n>.5?255:0,a=Math.abs(n-.5)*.14;im.data[i*4]=v;im.data[i*4+1]=v;im.data[i*4+2]=v;im.data[i*4+3]=a*255}tx.putImageData(im,0,0);g.fillStyle=g.createPattern(tl,'repeat');g.fillRect(-30,-30,w+60,h+60)}}
function pzdBakeTable(g){const G=PZ_G,{W:w,H:h}=PZ_PHY,rail=G.rail;g.save();g.translate(G.x,G.y);
 /* carved legs on dragon claws (mostly behind the bottom bar) */
 g.fillStyle='rgba(0,0,0,.5)';g.beginPath();g.ellipse(w/2,h+rail+96,w*.62,40,0,0,TAU);g.fill();
 for(const lx of[-rail+20,w+rail-74]){g.fillStyle=pzLin(g,lx,0,lx+54,0,[[0,'#1a0804'],[.5,'#4a2410'],[1,'#120604']]);pzRR(g,lx,h+rail+8,54,96,10);g.fill();g.strokeStyle=PZ_O;g.lineWidth=4;g.stroke();
  g.fillStyle=pzdGoldG(g,lx,h+rail+30,lx+54,h+rail+40);g.fillRect(lx-2,h+rail+28,58,10);g.strokeRect(lx-2,h+rail+28,58,10);pzdGem(g,lx+27,h+rail+33,5,'ruby',1.5);
  for(const s of[-1,0,1]){g.fillStyle=pzdGoldG(g,lx+27+s*18-8,h+rail+96,lx+27+s*18+8,h+rail+112);g.beginPath();g.moveTo(lx+27+s*16-7,h+rail+96);g.quadraticCurveTo(lx+27+s*22,h+rail+104,lx+27+s*24,h+rail+116);g.lineTo(lx+27+s*14+4,h+rail+100);g.closePath();g.fill();g.strokeStyle=PZ_O;g.lineWidth=2.5;g.stroke()}}
 /* the apron with a gold scroll and a crest */
 g.fillStyle=pzLin(g,0,h+rail-8,0,h+rail+54,[[0,'#3a1a0a'],[.5,'#240e06'],[1,'#120604']]);pzRR(g,-rail-8,h+rail-8,w+rail*2+16,60,14);g.fill();g.strokeStyle=PZ_O;g.lineWidth=4;g.stroke();
 g.strokeStyle='rgba(232,176,64,.75)';g.lineWidth=2;g.beginPath();for(let x=-rail+10;x<w+rail-10;x+=36){g.moveTo(x,h+rail+36);g.bezierCurveTo(x+9,h+rail+20,x+18,h+rail+20,x+18,h+rail+30);g.bezierCurveTo(x+18,h+rail+40,x+27,h+rail+40,x+36,h+rail+30)}g.stroke();
 g.fillStyle=pzdGoldG(g,0,h+rail-6,0,h+rail);g.fillRect(-rail,h+rail-6,w+rail*2,3);
 {const ty=G.trayY-G.y,x0=G.trayX0-G.x,x1=G.trayX1-G.x;g.fillStyle='#0a0302';pzRR(g,x0-14,ty-15,x1-x0+28,30,15);g.fill();g.fillStyle=pzLin(g,0,ty-13,0,ty+13,[[0,'#2a0410'],[1,'#5a0c1e']]);pzRR(g,x0-10,ty-12,x1-x0+20,24,12);g.fill();
  g.strokeStyle=pzdGoldG(g,0,ty-15,0,ty+15);g.lineWidth=3.5;pzRR(g,x0-14,ty-15,x1-x0+28,30,15);g.stroke();g.strokeStyle=PZ_O;g.lineWidth=1.6;pzRR(g,x0-16,ty-17,x1-x0+32,34,17);g.stroke();
  g.fillStyle='#040102';g.beginPath();g.ellipse(x1+20,ty,11,16,0,0,TAU);g.fill();g.strokeStyle='#ffd45a';g.lineWidth=3;g.stroke()}
 /* ebony rails, a gold bead outside and a gold inlay inside */
 const wood=pzLin(g,0,-rail,0,h+rail,[[0,'#4a2410'],[.15,'#2e1408'],[.5,'#1e0c05'],[.85,'#2e1408'],[1,'#160803']]);
 g.fillStyle=wood;pzRR(g,-rail,-rail,w+rail*2,h+rail*2,28);g.fill();
 for(let i=0;i<60;i++){const y=-rail+pzNoise(i*3.3)*(h+rail*2),x=-rail+pzNoise(i*5.1)*(w+rail*2);g.strokeStyle='rgba(120,60,24,.18)';g.lineWidth=1.2;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+40,y+3,x+80,y-2);g.stroke()}
 g.strokeStyle=pzdGoldG(g,0,-rail,0,h+rail);g.lineWidth=6;pzRR(g,-rail+3,-rail+3,w+rail*2-6,h+rail*2-6,26);g.stroke();g.strokeStyle=PZ_O;g.lineWidth=5;pzRR(g,-rail,-rail,w+rail*2,h+rail*2,28);g.stroke();
 g.strokeStyle='rgba(0,0,0,.4)';g.lineWidth=2;pzRR(g,-rail+8,-rail+8,w+rail*2-16,h+rail*2-16,22);g.stroke();
 g.fillStyle=pzLin(g,0,-rail+6,0,-rail+22,[[0,'rgba(255,230,190,.2)'],[1,'rgba(255,230,190,0)']]);g.fillRect(-rail+24,-rail+7,w+rail*2-48,14);
 g.strokeStyle='rgba(255,210,110,.3)';g.lineWidth=9;pzRR(g,-31,-31,w+62,h+62,14);g.stroke();g.strokeStyle=pzdGoldG(g,0,-31,0,h+31);g.lineWidth=3.4;pzRR(g,-31,-31,w+62,h+62,14);g.stroke();
 /* gold corner plates with filigree */
 for(const [cx,cy,sx,sy] of[[-rail+4,-rail+4,1,1],[w+rail-4,-rail+4,-1,1],[-rail+4,h+rail-4,1,-1],[w+rail-4,h+rail-4,-1,-1]]){g.save();g.translate(cx,cy);g.scale(sx,sy);g.fillStyle=pzdGoldG(g,0,0,60,60);g.beginPath();g.moveTo(0,0);g.lineTo(64,0);g.quadraticCurveTo(40,8,30,30);g.quadraticCurveTo(8,40,0,64);g.closePath();g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();
  g.strokeStyle='rgba(122,74,10,.8)';g.lineWidth=1.6;g.beginPath();g.moveTo(10,44);g.quadraticCurveTo(14,14,44,10);g.stroke();g.beginPath();g.arc(20,20,5,0,TAU);g.stroke();g.restore()}
 for(const [mx,my,sy] of[[w/2,-rail+3,1],[w/2,h+rail-3,-1]]){g.save();g.translate(mx,my);g.scale(1,sy);g.fillStyle=pzdGoldG(g,-40,0,40,20);g.beginPath();g.moveTo(-46,0);g.lineTo(46,0);g.quadraticCurveTo(26,6,20,18);g.lineTo(-20,18);g.quadraticCurveTo(-26,6,-46,0);g.closePath();g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();g.restore()}
 /* ruby-and-gold sights */
 const sight=(x,y)=>{g.save();g.translate(x,y);g.fillStyle=pzdGoldG(g,-6,-6,6,6);g.beginPath();g.moveTo(0,-7);g.lineTo(6,0);g.lineTo(0,7);g.lineTo(-6,0);g.closePath();g.fill();g.strokeStyle=PZ_O;g.lineWidth=1.6;g.stroke();g.fillStyle='#e8203a';g.beginPath();g.arc(0,0,2.2,0,TAU);g.fill();g.restore()};
 for(let i=1;i<8;i++){if(i===4)continue;sight(w*i/8,-rail/2-5);sight(w*i/8,h+rail/2+5)}for(let i=1;i<4;i++){sight(-rail/2-5,h*i/4);sight(w+rail/2+5,h*i/4)}
 /* cushions and cloth, traced from the physics edges */
 const felt=PZD_FELT,L=pzLoop();g.fillStyle=pzMix(felt.c,'#000000',.2);pzRR(g,-24,-24,w+48,h+48,10);g.fill();
 const loop=()=>{g.beginPath();L.forEach(([x,y],i)=>i?g.lineTo(x,y):g.moveTo(x,y));g.closePath()};
 g.save();g.beginPath();g.rect(-24,-24,w+48,h+48);L.forEach(([x,y],i)=>i?g.lineTo(x,y):g.moveTo(x,y));g.closePath();g.clip('evenodd');g.lineJoin='round';
 for(const [lw,k] of[[56,0],[40,.1],[28,.18],[18,.26],[9,.34]]){g.strokeStyle=pzMix(pzMix(felt.c,'#000000',.2),felt.a,k);g.lineWidth=lw;loop();g.stroke()}g.restore();
 g.save();loop();g.clip();pzdFeltPaint(g,w,h);
 /* the crest in the kitchen: a gold coin with a dragon's eye and the room's name */
 g.save();g.translate(w*.115,h/2);g.rotate(-Math.PI/2);g.globalAlpha=.2;g.strokeStyle='#ffe08a';g.lineWidth=3;g.beginPath();g.arc(0,-2,30,0,TAU);g.stroke();g.lineWidth=1.6;g.beginPath();g.arc(0,-2,24,0,TAU);g.stroke();
 g.fillStyle='#ffe08a';g.beginPath();g.ellipse(0,-2,13,8,0,0,TAU);g.fill();g.fillStyle='#6e1222';g.beginPath();g.ellipse(0,-2,2.6,7,0,0,TAU);g.fill();g.fillStyle='#ffe08a';
 g.font='400 22px "Pirata One",Georgia,serif';g.textAlign='center';g.textBaseline='middle';g.fillText('THE GILDED HOARD',0,48);g.restore();
 g.strokeStyle='rgba(255,220,140,.16)';g.lineWidth=2;g.setLineDash([7,9]);g.beginPath();g.moveTo(w/4,8);g.lineTo(w/4,h-8);g.stroke();g.setLineDash([]);
 for(const sx of[w/4,w*3/4]){g.fillStyle='rgba(255,230,160,.4)';g.beginPath();g.arc(sx,h/2,3.2,0,TAU);g.fill()}
 /* the chandelier's warm light pool */
 const lp=g.createRadialGradient(w/2,h*.46,30,w/2,h*.46,w*.66);lp.addColorStop(0,'rgba(255,230,170,.2)');lp.addColorStop(.55,'rgba(255,200,120,.05)');lp.addColorStop(1,'rgba(20,0,0,.34)');g.fillStyle=lp;g.fillRect(-30,-30,w+60,h+60);
 g.lineJoin='round';for(const [lw,al] of[[30,.06],[20,.09],[11,.13],[5,.18]]){g.strokeStyle=`rgba(10,0,0,${al})`;g.lineWidth=lw;loop();g.stroke()}
 g.restore();
 g.save();g.lineCap='round';const rails=PZ_TBL.S.filter(s=>s[0]===s[2]||s[1]===s[3]);for(const [a,b,c,d] of rails){g.strokeStyle='rgba(0,0,0,.5)';g.lineWidth=3;g.beginPath();g.moveTo(a,b);g.lineTo(c,d);g.stroke();g.strokeStyle='#ffd8a0';g.globalAlpha=.35;g.lineWidth=1.3;g.beginPath();g.moveTo(a+(a===c?(a<w/2?1.5:-1.5):0),b+(b===d?(b<h/2?1.5:-1.5):0));g.lineTo(c+(a===c?(a<w/2?1.5:-1.5):0),d+(b===d?(b<h/2?1.5:-1.5):0));g.stroke();g.globalAlpha=1}g.restore();
 /* pockets: a gold ring, a ruby glow and a deep red throat */
 for(const [px,py,hr,rr] of PZ_POCK){g.fillStyle='#0a0302';g.beginPath();g.arc(px,py+3,rr+4,0,TAU);g.fill();
  g.fillStyle=pzLin(g,px-rr,py-rr,px+rr,py+rr,[[0,'#fff4c0'],[.4,'#e8b040'],[1,'#7a4a0a']]);g.beginPath();g.arc(px,py,rr,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();
  pzGlow(g,px,py,rr+18,'rgba(255,40,70,1)',.42);g.strokeStyle='#ff3a5a';g.lineWidth=2.6;g.beginPath();g.arc(px,py,hr+5,0,TAU);g.stroke();
  const q=g.createRadialGradient(px,py,2,px,py,hr+2);q.addColorStop(0,'#000');q.addColorStop(.62,'#140206');q.addColorStop(1,'#6a0a1e');g.fillStyle=q;g.beginPath();g.arc(px,py,hr+2,0,TAU);g.fill();
  for(let k=0;k<6;k++){const a=k/6*TAU+.3;pzEll(g,'#ff4a5e',px+Math.cos(a)*(rr-5),py+Math.sin(a)*(rr-5),1.8,1.8,0,0)}
  g.strokeStyle='rgba(255,255,230,.6)';g.lineWidth=1.6;g.beginPath();g.arc(px,py,rr-3,Math.PI*1.05,Math.PI*1.55);g.stroke()}
 g.restore()}
function pzdBake(){if(PZD.bk)return PZD.bk;pzdFeltSync();const c=pzCv(1600,900),g=c.getContext('2d');g.lineJoin='round';g.lineCap='round';pzdBakeRoom(g);pzdBakeTable(g);pzGlow(g,PZ_G.lampX,PZ_G.y+PZ_PHY.H*.5,470,'rgba(255,220,160,1)',.07);return PZD.bk=c}
/* ---------- per frame ---------- */
let PZD_CHAND=null;
function pzdChandBake(){if(PZD_CHAND)return PZD_CHAND;const c=pzCv(420,190),g=c.getContext('2d');g.translate(210,120);g.lineJoin='round';g.lineCap='round';
 /* chains up into the dark */
 for(const [x0,x1] of[[-120,-36],[120,36],[0,0]]){const n=12;for(let i=0;i<n;i++){const u=i/n,x=x0+(x1-x0)*(1-u),y=-120+u*110;g.strokeStyle=PZ_O;g.lineWidth=3.2;g.beginPath();g.ellipse(x,y,i%2?2.2:3.6,5,i%2?0:.0,0,TAU);g.stroke();g.strokeStyle=i%2?'#c8901e':'#ffd45a';g.lineWidth=1.8;g.stroke()}}
 /* swags of chain between the arms */
 for(const s of[-1,1]){g.strokeStyle=PZ_O;g.lineWidth=4;g.beginPath();g.moveTo(s*30,-6);g.quadraticCurveTo(s*80,30,s*150,2);g.stroke();g.strokeStyle='#e8b040';g.lineWidth=2;g.setLineDash([3,3]);g.stroke();g.setLineDash([])}
 /* the crown ring */
 g.fillStyle=pzdGoldG(g,-160,-14,160,22);g.beginPath();g.ellipse(0,4,158,24,0,0,TAU);g.ellipse(0,0,126,14,0,0,TAU);g.fill('evenodd');g.strokeStyle=PZ_O;g.lineWidth=4;g.beginPath();g.ellipse(0,4,158,24,0,0,TAU);g.stroke();g.beginPath();g.ellipse(0,0,126,14,0,0,TAU);g.stroke();
 for(let i=0;i<14;i++){const a=i/14*TAU,x=Math.cos(a)*142,y=4+Math.sin(a)*19;if(Math.sin(a)<0)continue;pzdGem(g,x,y,4.2,['ruby','emer','sapph'][i%3],1.4)}
 /* candles on the rim */
 for(const k of[-1,-.62,-.24,.24,.62,1]){const x=k*136,y=4+Math.sqrt(Math.max(0,1-k*k*.98))*-2-6;g.fillStyle=pzLin(g,x-5,0,x+5,0,[[0,'#e8dcc0'],[.5,'#fff8e8'],[1,'#c8b898']]);pzRR(g,x-5,y-16,10,16,3);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2.4;g.stroke();g.fillStyle=pzdGoldG(g,x-9,y-2,x+9,y+4);pzRR(g,x-9,y-3,18,6,3);g.fill();g.stroke()}
 /* hanging gem drops */
 for(let i=0;i<9;i++){const k=-1+i/4,x=k*120,y=22+Math.sqrt(Math.max(0,1-k*k))*10;g.strokeStyle='#c8901e';g.lineWidth=1.5;g.beginPath();g.moveTo(x,y-10);g.lineTo(x,y);g.stroke();pzdGem(g,x,y+6,i%2?4.5:6,i%2?'topaz':'ruby',1.4)}
 /* a central boss */
 pzEll(g,'#c8901e',0,-4,18,12,0,3);pzdGem(g,0,-6,8,'ruby',2);
 return PZD_CHAND=c}
const PZD_CANDLE=[-1,-.62,-.24,.24,.62,1];
function pzdDrawChand(g,t){const rm=pzRM(),sw=rm?0:Math.sin(t*.7)*2.5,x=PZ_G.lampX+sw,y=PZ_G.lampY-4;g.drawImage(pzdChandBake(),x-210,y-120);
 pzGlow(g,x,y+30,150,'rgba(255,200,110,1)',.32);
 for(let i=0;i<6;i++){const k=PZD_CANDLE[i],cx=x+k*136,cy=y+4+Math.sqrt(Math.max(0,1-k*k*.98))*-2-22,f=rm?1:.8+.2*Math.sin(t*9+i*2.3)*Math.sin(t*5.3+i);
  g.drawImage(pzGlowS('rgba(255,200,90,1)'),cx-18*f,cy-20*f,36*f,36*f);g.fillStyle='#fff4c0';g.beginPath();g.moveTo(cx,cy-9*f);g.quadraticCurveTo(cx+4,cy-1,cx,cy+3);g.quadraticCurveTo(cx-4,cy-1,cx,cy-9*f);g.fill()}}
/* glints: where the light catches the coins (x, y, phase) */
const PZD_GL=[[1400,300],[1470,330],[1530,380],[1350,420],[1440,470],[1560,520],[1500,240],[60,790],[150,830],[1330,760],[1450,730],[1560,780],[200,250],[96,470],[1386,383],[1475,318]];
function pzdDrawAmb(g,t){if(pzRM())return;
 for(let i=0;i<PZD_GL.length;i++){const [x,y]=PZD_GL[i],a=Math.max(0,Math.sin(t*1.1+i*2.4));if(a<.55)continue;const k=(a-.55)/.45;g.globalAlpha=k;g.drawImage(pzGlowS('rgba(255,240,190,1)'),x-10,y-10,20,20);g.fillStyle='#fffbe8';g.fillRect(x-.8,y-6*k,1.6,12*k);g.fillRect(x-6*k,y-.8,12*k,1.6)}g.globalAlpha=1;
 /* the gem lanterns breathe */
 {const a=.14+.08*Math.sin(t*1.7);g.globalAlpha=a;g.drawImage(pzGlowS('rgba(255,70,90,1)'),490,12,120,120);g.globalAlpha=.14+.08*Math.sin(t*1.7+2);g.drawImage(pzGlowS('rgba(70,255,150,1)'),990,12,120,120);g.globalAlpha=1}
 /* a coin slides down the mountain every 9 s */
 {const ph=(t%9)/1.6;if(ph<1&&!PZ.lite){const u=ph,x=1470+u*110,y=332+u*u*220+Math.abs(Math.sin(u*14))*-8*(1-u);g.save();g.translate(x,y);pzdCoin(g,0,0,6,.35+.3*Math.abs(Math.sin(u*20)));g.restore()}}}
function pzdDrawMotes(g,t){if(pzRM()||PZ.lite)return;g.save();g.globalCompositeOperation='lighter';for(let i=0;i<14;i++){const ph=(t*.025+i*.0714)%1,x=PZ_G.lampX-320+((i*173)%640)+Math.sin(t*.6+i)*16,y=640-ph*480,a=Math.sin(ph*Math.PI)*.3;g.fillStyle=`rgba(255,${200+(i%3)*18},120,${a})`;g.fillRect(x-1,y-1,2.2,2.2)}g.restore()}
{const f0=pzDrawLamp;pzDrawLamp=function(g,t){if(PZ.pzd)return pzdDrawChand(g,t);return f0.apply(this,arguments)}}
{const f0=pzDrawLights;pzDrawLights=function(g,t){if(PZ.pzd)return pzdDrawAmb(g,t);return f0.apply(this,arguments)}}
{const f0=pzDrawDust;pzDrawDust=function(g,t){if(PZ.pzd)return pzdDrawMotes(g,t);return f0.apply(this,arguments)}}
/* mount: the vault and its table for its players (practice included) */
{const f0=pzMount;pzMount=function(R){PZ.pzd=!!(R&&pzdIs(R.id));PZD.fx=[];const r=f0.apply(this,arguments);try{if(PZ.pzd){PZ.bk=pzdBake();const m=$('pzm');if(m)m.classList.add('pzd8m')}}catch(e){console.error(e)}return r}}
/* head-and-shoulders framing (PZ97_BUST) comes from the cast module 97bc */
{const f0=pzCastPortrait;pzCastPortrait=function(g,who,id,size,t,ex){if(who!=='hero'&&pzdIs(id)){g.save();g.clearRect(0,0,size,size);try{pz97Bust(g,id,size,ex||pzCastEx(),t||1)}catch(e){}g.restore();return}return f0.apply(this,arguments)}}
/* ---------- shot flair: each one strikes in their own way ---------- */
function pzdShotFx(){const R=PZ.reg,c=PZ.B[0],s=PZ.shot;if(!R||!c||pzRM())return;const x=PZ_G.x+c.x-Math.cos(s.ang)*12,y=PZ_G.y+c.y-Math.sin(s.ang)*12,bx=PZ_G.x+c.x-Math.cos(s.ang)*240,by=PZ_G.y+c.y-Math.sin(s.ang)*240;
 if(R.id==='clasp'){pzSpecks(x,y,8,'#ffd45a');PZD.fx.push({k:'coin',x,y,vx:-Math.cos(s.ang)*60,vy:-140,t:0,d:.8})}
 else if(R.id==='zephyra'){pzPuff(bx,by,7,'rgba(90,220,210,.55)',50);PZD.fx.push({k:'ring',x:bx,y:by,t:0,d:.9,c:'120,240,225'})}
 else if(R.id==='brass'){pzPuff(bx,by-30,8,'rgba(235,235,235,.7)',90);pzFx('key')}
 else if(R.id==='hornsby'){pzSpecks(x,y,10,'#ff9aa0');PZD.fx.push({k:'snort',x:bx,y:by,a:s.ang,t:0,d:.5})}
 else if(R.id==='aurelion'){PZD.fx.push({k:'flame',x,y,a:s.ang,t:0,d:.55});pzSpecks(x,y,12,'#ffe27a')}}
{const f0=pzContact;pzContact=function(){const r=f0.apply(this,arguments);try{if(PZ.pzd&&PZ.shotAi)pzdShotFx()}catch(e){}return r}}
{const f0=pzFxDraw;pzFxDraw=function(g){const r=f0.apply(this,arguments);try{const L=PZ.pzd&&PZD.fx;if(L&&L.length){const dt=Math.min(.05,Math.max(0,(PZ.t||0)-(PZD.fxT||0)));PZD.fxT=PZ.t;
  for(let i=L.length-1;i>=0;i--){const f=L[i];f.t+=dt;if(f.t>=f.d){L.splice(i,1);continue}const u=f.t/f.d;g.save();
   if(f.k==='coin'){const x=f.x+f.vx*f.t,y=f.y+f.vy*f.t+260*f.t*f.t;g.globalAlpha=1-u*u;pzdCoin(g,x,y,7,.25+.6*Math.abs(Math.sin(f.t*18)))}
   else if(f.k==='ring'){g.strokeStyle=`rgba(${f.c},${(1-u)*.7})`;g.lineWidth=5*(1-u)+1;g.beginPath();g.ellipse(f.x,f.y-u*40,16+u*60,6+u*22,0,0,TAU);g.stroke()}
   else if(f.k==='snort'){g.globalAlpha=(1-u)*.7;for(const s of[-1,1]){g.drawImage(pzGlowS('rgba(255,255,255,1)'),f.x+s*14-20-Math.cos(f.a)*u*30,f.y-20-Math.sin(f.a)*u*30,40,40)}}
   else if(f.k==='flame'){g.globalCompositeOperation='lighter';g.translate(f.x,f.y);g.rotate(f.a+Math.PI);g.globalAlpha=(1-u)*.85;g.drawImage(pzGlowS('rgba(255,170,50,1)'),20+u*40-30,-30,60,60);g.drawImage(pzGlowS('rgba(255,90,30,1)'),50+u*70-24,-24,48,48)}
   g.restore()}}}catch(e){}return r}}
/* they think while they line up, and a double pot or a bank from you gets a "wow" (as in Orbit 8) */
{const f0=pzAiBegin;pzAiBegin=function(){const r=f0.apply(this,arguments);try{if(PZ.pzd&&PZ.ai&&!PZ.st.brk)pzCastReact('mon','think',Math.round(PZ.ai.dur*520))}catch(e){}return r}}
{const f0=pzJudgeShot;pzJudgeShot=function(silent){let who=-1,n=0,bank=false;try{if(PZ.pzd&&!silent&&PZ.st){who=PZ.st.turn;const ev=PZ.ev||[];const pk=ev.filter(e=>e.t==='pk'&&e.a>0).map(e=>e.a);n=pk.length;bank=ev.some(e=>e.t==='cu'&&!e.j&&pk.includes(e.a))}}catch(e){}
 const r=f0.apply(this,arguments);try{if(who===0&&(n>=2||bank)&&PZ.st&&!PZ.st.over&&PZ.st.turn===0)pzCastReact('mon','wow',1500)}catch(e){}return r}}
/* ---------- the VS intro: a shower of gold, and each one makes an entrance ---------- */
let PZD_RAIN=null;
function pzdRainBake(){if(PZD_RAIN)return PZD_RAIN;const c=pzCv(1600,1100),g=c.getContext('2d');for(let i=0;i<120;i++){const x=pzNoise(i*2.3+5)*1600,y=pzNoise(i*4.1+7)*1100,r=4+pzNoise(i*7.7)*7;g.globalAlpha=.25+pzNoise(i*1.1)*.5;pzdCoin(g,x,y,r,.25+pzNoise(i*3.9)*.6)}g.globalAlpha=1;return PZD_RAIN=c}
function pzdEntrance(g,id,t,u,fit){/* u: 0..1 entrance progress; draws the figure on a 320 x 400 canvas */
 const e=1-Math.pow(1-u,3),ex=Object.assign(pzCastEx(),PZ_EXP[u<1?'wow':'smug']);let x=fit.x,y=fit.y,s=fit.s,rot=0,al=1,sy=1;
 if(id==='clasp'){y-=Math.abs(Math.sin(u*Math.PI*3))*(1-u)*70;x+=(1-e)*-240;sy=u<1?1-.12*Math.abs(Math.sin(u*Math.PI*6)):1}
 else if(id==='zephyra'){al=pzCl01(u*1.4);sy=.3+.7*e;if(u<1){g.save();g.globalAlpha=(1-u)*.8;for(let i=0;i<5;i++){g.strokeStyle='rgba(120,240,225,.9)';g.lineWidth=5;g.beginPath();g.ellipse(fit.x,fit.y-10-i*40*e,(60-i*8)*(1-e*.4),12,0,0,TAU);g.stroke()}g.restore()}}
 else if(id==='brass'){y-=(1-e)*420;if(u>.75&&u<1){const k=(u-.75)/.25;g.save();g.globalAlpha=1-k;g.fillStyle='rgba(240,240,240,.8)';for(let i=0;i<8;i++){const a=i/8*Math.PI;g.beginPath();g.arc(fit.x+Math.cos(a)*(60+k*90)*(i%2?1:-1),fit.y-10-Math.sin(a)*20,14+k*14,0,TAU);g.fill()}g.restore()}}
 else if(id==='hornsby'){x+=(1-e)*300;rot=(1-e)*.25;if(u<1){g.save();g.globalAlpha=(1-u)*.6;g.fillStyle='rgba(200,170,140,.7)';for(let i=0;i<6;i++){g.beginPath();g.arc(x+60+i*30,fit.y-10-(i%2)*14,16+i*3,0,TAU);g.fill()}g.restore()}}
 else if(id==='aurelion'){s*=.4+.6*e;y+=(1-e)*60;if(u<1){g.save();g.globalCompositeOperation='lighter';g.globalAlpha=(1-u)*.9;g.drawImage(pzGlowS('rgba(255,180,60,1)'),fit.x-200,fit.y-360,400,400);g.restore()}}
 g.save();g.globalAlpha=al;g.translate(x,y);g.rotate(rot);g.scale(s,s*sy);pzMon[id](g,t,ex,{breath:Math.sin(t*2.2)*.012,tilt:0,bob:0,hop:0});g.restore()}
const pzCl01=v=>Math.max(0,Math.min(1,v));
{const f0=pzIntro;pzIntro=function(R,cb){const r=f0.apply(this,arguments);try{if(R&&pzdIs(R.id)){const el=$('pzintro'),old=$('pzvo');if(el&&old){el.classList.add('pzdvs');
  const sk=pzCv(1600,1100);sk.className='pzdrain';sk.getContext('2d').drawImage(pzdRainBake(),0,0);el.prepend(sk);
  const cv=pzCv(320,400);cv.id='pzvo';cv.className=old.className;old.replaceWith(cv);const g=cv.getContext('2d');g.lineJoin='round';g.lineCap='round';const fit=pzMonFit(R.id,320,400,10),t0=performance.now()/1000;
  {const b=document.createElement('div');b.className='pzdvsq';b.style.setProperty('--c',R.c);b.textContent=`“${R.lines.hi[0]}”`;el.appendChild(b)}
  const f=()=>{if(!cv.isConnected)return;const t=performance.now()/1000,u=pzRM()?1:Math.min(1,(t-t0-.15)/.9);g.clearRect(0,0,320,400);pzdEntrance(g,R.id,t,Math.max(0,u),fit)};f();LIVE.push({cv,fn:f,ph:0})}}}catch(e){console.error(e)}return r}}
/* ---------- a slow treasure-vault waltz (C harmonic minor, plucked harp, low strings, a celesta on top) ---------- */
const PZD_CH=[[48,'m7'],[48,'m7'],[53,'m7'],[53,'m7'],[44,'M7'],[44,'M7'],[55,'7'],[55,'7'],[48,'m7'],[51,'M7'],[53,'m7'],[55,'7'],[56,'M7'],[53,'m7'],[55,'7'],[55,'7']];
const PZD_ARP=[0,2,3,1,2,3,0,3];
function pzdScore(t,n0){if(!PZD.ms){PZD.ms=1;PZD.n0=n0}KS.on=0;const n=n0-PZD.n0,bar=(n>>3)&15,k=n&7,sd=stepD();if(k===0)PZM.lv=pzLevel();const lv=PZM.lv,B=pzBus(lv),[root,q]=PZD_CH[bar],ch=PZ_Q[q];
 /* a waltzing bass: root on 0, fifth on 4 */
 if(k===0||k===4)wcv(t,mf(root-24+(k===4?7:0)),sd*2.6,{w:'triangle',lp:lv===2?520:700,v:lv?.09:.07,a:.01,r:.3,bus:B.pc});
 if(lv>0){if(k===0)wcKick(t,.12,B.pc);if(k===4)kns(t,.06,.035,6000,'highpass',B.pc)}
 if(k%2===1&&lv>0)kns(t,.02,.018,10000,'highpass',B.pc);
 /* the plucked harp */
 {const i=PZD_ARP[k],nt=root+12+ch[i]+(k===7&&bar%2?12:0);wcv(t,mf(nt),sd*1.4,{w:'triangle',lp:lv?2800:2200,v:lv?.024:.018,a:.003,r:.45,bus:B.st,det:4})}
 /* a celesta sparkle like coins catching the light */
 if((k===2||k===6)&&(bar+k)%3!==0){const nt=root+24+ch[(bar+k)%ch.length];wcv(t,mf(nt),sd*.8,{w:'sine',lp:5200,v:.012,a:.002,r:.6,bus:B.br})}
 /* a warm string pad on each bar */
 if(k===0)for(const i of ch.slice(1))wcv(t,mf(root+i),sd*7.6,{w:'sawtooth',lp:800,v:.008,a:.5,r:.8,bus:B.st,det:(i%3-1)*8})}
{const n0=note;note=function(t,n){if(pzMusic()&&pzdVenueNow())return pzdScore(t,n);if(PZD.ms)PZD.ms=0;return n0(t,n)}}
/* Clasp speaks in creaks and clacks (his lid) */
{const f0=pzVoice;pzVoice=function(o){const R=PZ_REG[o&&o.id];if(R&&R.voice&&R.voice.creak){try{const t0=pzT(),n=Math.min(12,Math.ceil((o.n||8)/2));for(let i=0;i<n;i++){const t=t0+i*.075;wcv(t,R.voice.f*(i%2?1.3:1)*(.9+Math.random()*.2),.06,{w:'square',v:.02,a:.003,r:.05,bus:sg,lp:1800})}}catch(e){}return}return f0.apply(this,arguments)}}
{const st=document.createElement('style');st.textContent=`
.pzintro.pzdvs{background:radial-gradient(ellipse at 50% 45%,#5a1a0cee,#140604f6 70%)}
.pzintro.pzdvs .pzdrain{position:absolute;left:0;top:-200px;width:1600px;height:1100px;opacity:.75;animation:pzdrain 2.2s linear infinite;pointer-events:none}
@keyframes pzdrain{from{transform:translateY(0)}to{transform:translateY(200px)}}
.pzintro.pzdvs .pzvr b{text-shadow:0 0 0 #000,0 3px 0 #12081f}
.pzdvsq{position:absolute;left:1060px;top:722px;margin-left:-170px;width:340px;box-sizing:border-box;padding:8px 12px;border-radius:14px;background:#fff8e6;border:3px solid #12081f;color:#3a1a0a;font:700 italic 13px/1.35 Poppins,sans-serif;text-align:center;box-shadow:0 6px 0 #0007;animation:pzpopIn .45s .9s cubic-bezier(.25,1.6,.45,1) both}
.pzintro.pzdvs.out .pzdrain{animation:none}
`;document.head.appendChild(st)}
