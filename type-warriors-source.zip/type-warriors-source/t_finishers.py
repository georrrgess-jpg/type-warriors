# Hero path finishers and signature weapons: each path's Fury plays its attack, a boss finished with Space plays the
# finisher and counts toward the signature weapon (forged free on the third), the Armory Forge card and the gold price,
# and the weapon art draws. Run from the source folder against out.html.
import asyncio,os
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append('PE '+str(e)[:300]))
        await pg.goto('file://'+os.path.abspath('out.html'));await pg.wait_for_timeout(1200);E=pg.evaluate;bad=0
        def chk(name,r,ok):
            nonlocal bad;bad+=not ok;print(name,r,'OK' if ok else 'BAD')
        await E("()=>{RS_ASK=false;P.xp=Math.max(P.xp,500000);P.gold=50000;delete P.sigf;for(const id of Object.values(SIGW))delete P.own[id];save()}")
        r=await E("()=>{const c=document.createElement('canvas');c.width=236;c.height=150;for(const id of Object.values(SIGW))for(const t of [0,1.7])art(c,'w',id,t);return Object.values(SIGW).map(id=>[WP[id].p,WP[id].t,!!WP[id].hw])}")
        chk('weapons registered, art draws',r,[x[0] for x in r]==['knight','archer','mage','rogue'] and all(x[2] for x in r))
        r=await E("()=>{const c=crateRoll?Array.from({length:400},()=>{try{return crateRoll()}catch(e){return null}}):[];return c.filter(x=>x&&String(x.id||x).startsWith('sig_')).length}")
        chk('never from crates',r,r==0)
        async def boss(path):
            await E("()=>{S.en=[];S.round=5;S.spawnLeft=1;S.spawnT=0}")
            for i in range(40):
                if await E("()=>S.en.some(e=>e.boss)"):break
                await pg.wait_for_timeout(250)
            for i in range(30):
                if await E("()=>{const b=S.en.find(e=>e.boss);return b&&b.x<W-150}"):break
                await pg.wait_for_timeout(250)
            await E("()=>{const b=S.en.find(e=>e.boss);b.phs=1;b.vul=S.vm||3;S.ban=null}");await pg.wait_for_timeout(200)
            await pg.keyboard.press('Space');await pg.wait_for_timeout(150)
            return await E("()=>[!!S.pfx&&S.pfx.big,S.pfx&&S.pfx.path,S.pose]")
        for path in ['knight','archer','mage','rogue']:
            await E("(p)=>{P.path=p;syncPaths();start(1)}",path);await pg.wait_for_timeout(3500)
            for i in range(30):
                if await E("()=>S.en.filter(e=>e.x<W-60).length>=1"):break
                await pg.wait_for_timeout(300)
            r=await E("()=>{S.fury=100;fury();return [!!S.pfx,S.pfx&&S.pfx.path,S.pfx&&S.pfx.big]}");chk(f'{path} fury attack',r,r==[True,path,False])
            for i in range(40):
                if await E("()=>!S.pfx"):break
                await pg.wait_for_timeout(200)
            r=await E("()=>!S.pfx");chk(f'{path} attack ends',r,r)
            r=await boss(path);chk(f'{path} boss finisher',r,r[0] is True and r[1]==path and r[2]=='victory')
            await pg.wait_for_timeout(1500);await E("()=>{S.mode='title';title()}");await pg.wait_for_timeout(400)
        r=await E("()=>[P.sigf,Object.values(SIGW).map(id=>!!P.own[id])]");chk('finishers counted per path',r,r[0]=={'knight':1,'archer':1,'mage':1,'rogue':1} and not any(r[1]))
        # two more knight finishers forge Dawnbreaker
        await E("()=>{P.path='knight';syncPaths();start(1)}");await pg.wait_for_timeout(3500)
        await boss('knight');await pg.wait_for_timeout(1800);await E("()=>{S.mode='title';title()}");await pg.wait_for_timeout(300)
        await E("()=>{start(1)}");await pg.wait_for_timeout(3500);await boss('knight');await pg.wait_for_timeout(600)
        r=await E("()=>[P.sigf.knight,!!P.own.sig_dawn]");chk('third finisher forges Dawnbreaker',r,r==[3,True])
        await E("()=>{S.mode='title';title()}");await pg.wait_for_timeout(300)
        # Forge card with gold (archer)
        await E("()=>{P.path='archer';syncPaths();P.gold=20000;armory('Weapons')}");await pg.wait_for_timeout(700)
        r=await E("()=>!!document.querySelector('.argrid .sigf')");chk('forge card shown',r,r)
        await E("()=>document.querySelector('.argrid .sigf').click()");await pg.wait_for_timeout(500)
        r=await E("()=>[!!P.own.sig_tempest,P.weapon,P.gold,!!document.querySelector('.argrid .sigf')]");chk('forged with gold and equipped',r,r==[True,'sig_tempest',5000,False])
        await E("()=>{P.path='mage';syncPaths();P.gold=100;armory('Weapons')}");await pg.wait_for_timeout(500)
        await E("()=>document.querySelector('.argrid .sigf').click()");r=await E("()=>[!!P.own.sig_conduit,P.gold]");chk('not enough gold refused',r,r==[False,100])
        print('bad',bad);print(er[:8])
        await b.close()
asyncio.run(main())
