/* ===== WILDCARD: same Wi-Fi rooms, with no server at all =====
   Devices talk straight to each other over WebRTC data channels on the local network (no STUN/TURN, no relay, no
   accounts). Connecting takes one exchange: the host's invite (a link or code) goes to the friend, and the friend's
   reply code comes back to the host. Codes carry only the connection keys and local addresses, packed small:
     WC1~o|a~ufrag~password~fingerprint(base64)~address*port!address*port
   The host runs the game and sends each guest the table with only that guest's own hand visible.
   Gold stays on each player's own device: everyone pays the stake from their own save and collects their own payout. */
const WCNET={guest:null,peers:{},seq:0};
const WCRTC={iceServers:[]};
const wcB64=h=>btoa(h.split(':').map(x=>String.fromCharCode(parseInt(x,16))).join('')).replace(/=+$/,''),wcHex=b=>Array.from(atob(b),ch=>ch.charCodeAt(0).toString(16).padStart(2,'0').toUpperCase()).join(':');
function wcPack(kind,sdp){const g=r=>(sdp.match(r)||[])[1]||'';const u=g(/a=ice-ufrag:(\S+)/),p=g(/a=ice-pwd:(\S+)/),f=g(/a=fingerprint:sha-256 (\S+)/);
 const c=[...sdp.matchAll(/a=candidate:\S+ 1 udp \d+ (\S+) (\d+) typ host/gi)].map(m=>m[1]+'*'+m[2]);
 return['WC1',kind,u,p,wcB64(f),[...new Set(c)].join('!')].join('~')}
function wcUnpack(code){code=String(code||'').trim();const h=code.indexOf('#wcj=');if(h>=0)code=decodeURIComponent(code.slice(h+5));code=code.replace(/\s+/g,'');
 const a=code.split('~');if(a.length<6||a[0]!=='WC1'||!/^[oa]$/.test(a[1]))return null;let fp;try{fp=wcHex(a[4])}catch(e){return null}
 const cands=a[5]?a[5].split('!').map((x,i)=>{const [ip,port]=x.split('*');return `a=candidate:${i+1} 1 udp ${2122260223-i} ${ip} ${port} typ host generation 0`}):[];
 const sdp=['v=0','o=- '+(Date.now()%1e9)+' 2 IN IP4 127.0.0.1','s=-','t=0 0','a=group:BUNDLE 0','a=msid-semantic: WMS','m=application 9 UDP/DTLS/SCTP webrtc-datachannel','c=IN IP4 0.0.0.0',...cands,
  'a=ice-ufrag:'+a[2],'a=ice-pwd:'+a[3],'a=ice-options:trickle','a=fingerprint:sha-256 '+fp,'a=setup:'+(a[1]==='o'?'actpass':'active'),'a=mid:0','a=sctp-port:5000','a=max-message-size:262144',''].join('\r\n');
 return{kind:a[1],sdp,cands:cands.length}}
function wcIce(pc,ms){return new Promise(res=>{if(pc.iceGatheringState==='complete')return res();const t=setTimeout(res,ms||2500);pc.addEventListener('icegatheringstatechange',()=>{if(pc.iceGatheringState==='complete'){clearTimeout(t);res()}})})}
const wcRtcOk=()=>typeof RTCPeerConnection==='function';
const wcLink=code=>{try{if(!/^https?:/.test(location.protocol))return'';return location.href.split('#')[0]+'#wcj='+encodeURIComponent(code)}catch(e){return''}};
function wcCopy(t,btn){const ok=()=>{if(btn){const o=btn.innerHTML;btn.classList.add('done');btn.innerHTML='✓ Copied';setTimeout(()=>{btn.innerHTML=o;btn.classList.remove('done')},1600)}wcSnd(880,.05,'triangle',.25)};
 try{navigator.clipboard.writeText(t).then(ok,()=>wcSel(btn))}catch(e){wcSel(btn)}}
function wcSel(btn){const box=btn&&btn.closest('.wcmb,.wcjs')&&btn.closest('.wcmb,.wcjs').querySelector('textarea[readonly]');if(box){box.focus();box.select()}}
/* ---------- host side ---------- */
async function wcInvite(i){const s=WCL.seats[i];if(!s)return;if(!wcRtcOk()){wcModal('<h3>Wi-Fi play is not available</h3><p class="wcp">This browser cannot make direct connections. Try Chrome, Edge, Safari or Firefox.</p>');WCL.seats[i]={k:'open'};wcLobbyRender();return}
 if(!s.pc){const pc=new RTCPeerConnection(WCRTC),dc=pc.createDataChannel('wildcard',{ordered:true});s.pc=pc;s.dc=dc;s.pid='n'+(++WCNET.seq)+Date.now().toString(36);WCNET.peers[s.pid]=s;
  dc.onopen=()=>{s.k='net';s.ready=0;wcSnd(988,.08,'triangle',.25);const m=$('wcmod');if(m&&!m.hidden&&m.dataset.inv==String(i)){m.hidden=true;m.innerHTML=''}wcLobbyRender();wcNetLobby()};
  dc.onmessage=e=>wcHostMsg(s,e.data);dc.onclose=()=>wcPeerGone(s);pc.onconnectionstatechange=()=>{if(['failed','closed'].includes(pc.connectionState))wcPeerGone(s)};
  await pc.setLocalDescription(await pc.createOffer());await wcIce(pc);s.code=wcPack('o',pc.localDescription.sdp)}
 const link=wcLink(s.code),m=wcModal(`<h3>Invite a friend on your Wi-Fi</h3><ol class="wcsteps"><li class="on"><b>1</b><span>Send this invite to your friend${link?' (or let them scan the code)':''}</span></li><li><b>2</b><span>They open it and send you back a reply code</span></li><li><b>3</b><span>Paste the reply here</span></li></ol>
 <div class="wcinv">${link?`<div class="wcqr" id="wcqr"></div>`:''}<div class="wcinvc"><textarea readonly rows="4" class="wccode" id="wcicode">${esc(link||s.code)}</textarea><div class="wcrow"><button class="wcbtn" id="wcicp">${WCI.copy}Copy ${link?'invite link':'invite code'}</button>${link?`<button class="wcbtn" id="wcicp2">Copy code only</button>`:''}</div></div></div>
 <label class="wclab">Friend's reply code</label><textarea id="wcrep" class="wccode in" rows="3" spellcheck="false" placeholder="Paste the reply code your friend sent back"></textarea><p class="wcerr" id="wcrerr"></p>
 <div class="wcrow"><button class="wcbtn gold" id="wcrgo">Connect</button></div>`,'wide wcinvm');if(!m)return;m.dataset.inv=i;
 $('wcicp').onclick=()=>wcCopy(link||s.code,$('wcicp'));if($('wcicp2'))$('wcicp2').onclick=()=>wcCopy(s.code,$('wcicp2'));
 if(link&&typeof wcQR==='function')try{$('wcqr').innerHTML=wcQR(link)}catch(e){$('wcqr').remove()}
 const rep=$('wcrep');rep.onkeydown=e=>e.stopPropagation();
 $('wcrgo').onclick=async()=>{const r=wcUnpack(rep.value),er=$('wcrerr');if(!r||r.kind!=='a'){er.textContent=r&&r.kind==='o'?'That is an invite, not a reply. Paste the code your friend sent back.':'That does not look like a reply code. Check you copied all of it.';rep.classList.add('nope');setTimeout(()=>rep.classList.remove('nope'),500);return}
  try{if(s.pc.signalingState!=='have-local-offer')throw 0;await s.pc.setRemoteDescription({type:'answer',sdp:r.sdp});er.className='wcerr ok';er.textContent='Connecting…';wcLater2(()=>{if(s.k!=='net'){er.className='wcerr';er.textContent='Could not connect. Make sure you are both on the same Wi-Fi network, then make a new invite.'}},9000)}
  catch(e){er.textContent='That reply belongs to a different invite. Make a new invite and try again.'}}}
function wcLater2(fn,ms){setTimeout(fn,ms)}
function wcPeerGone(s){if(s.gone)return;s.gone=1;delete WCNET.peers[s.pid];const G=WX.G;
 if(G&&WX.host&&WX.mode==='net'&&G.phase!=='over'){const i=G.P.findIndex(p=>p.kind==='net'&&p.id===s.pid);if(i>=0){G.P[i].kind='bot';G.P[i].diff=(WX.cfg.set&&WX.cfg.set.bot)||'m';wcChat('System',`${G.P[i].name} left. A bot takes their seat.`);wcRender();wcStep()}}
 const li=WCL.seats.indexOf(s);if(li>=0){WCL.seats[li]={k:'open'};if($('wcl'))wcLobbyRender()}}
function wcNetDrop(i){const s=WCL.seats[i];if(s&&s.pc){s.gone=1;try{s.dc&&s.dc.send(JSON.stringify({t:'kick'}))}catch(e){}try{s.pc.close()}catch(e){}delete WCNET.peers[s.pid]}}
function wcTx(s,o){try{if(s.dc&&s.dc.readyState==='open')s.dc.send(JSON.stringify(o))}catch(e){}}
function wcNetLobby(){const set=WCL.set;for(const s of WCL.seats)if(s.k==='net')wcTx(s,{t:'lobby',room:WCL.room,set,seats:WCL.seats.map(x=>({k:x.k,name:x.k==='you'?P.name||'Host':x.k==='bot'?WCT[set.bot].bots[(WCL.seats.indexOf(x)-1)%3][1]:x.name||'',ready:x.ready})),you:WCL.seats.indexOf(s)})}
function wcHostMsg(s,raw){let m;try{m=JSON.parse(raw)}catch(e){return}
 if(m.t==='hello'){s.name=String(m.name||'Friend').replace(/[<>]/g,'').slice(0,14);s.av=m.av&&m.av.t==='hero'?{t:'hero',arm:String(m.av.arm||''),wp:String(m.av.wp||''),col:+m.av.col||0}:{t:'hero'};s.gold=+m.gold||0;if($('wcl'))wcLobbyRender();wcNetLobby();return}
 if(m.t==='ready'){s.ready=m.v?1:0;if($('wcl'))wcLobbyRender();return}
 if(m.t==='pong'){s.ms=Math.max(1,Math.round(performance.now()-m.ts));const e=document.querySelector('.wcls.net .wcms');if($('wcl'))wcLobbyRender();return}
 if(m.t==='chat'){wcChat(s.name,String(m.x||'').slice(0,40));wcRelay({t:'chat',n:s.name,x:String(m.x||'').slice(0,40)},s);const G=WX.G;if(G){const i=G.P.findIndex(p=>p.id===s.pid);if(i>=0&&m.emo)wcBubble(i,String(m.x).slice(0,12))}return}
 if(m.t==='act'){const G=WX.G;if(!G)return;const i=G.P.findIndex(p=>p.id===s.pid&&p.kind==='net');if(i<0)return;const a=m.a||{};if(!['play','draw','pass','call','catch'].includes(a.t))return;
  wcApply(i,{t:a.t,id:a.id!=null?+a.id:null,col:WCS.includes(a.col)?a.col:null,p:+a.p})}}
function wcRelay(o,except){for(const k in WCNET.peers){const s=WCNET.peers[k];if(s!==except)wcTx(s,o)}}
setInterval(()=>{for(const k in WCNET.peers){const s=WCNET.peers[k];wcTx(s,{t:'ping',ts:performance.now()})}},2500);
/* the table each guest sees: their own hand, everyone else's card counts */
function wcView(G,j){const o={};for(const k in G)if(k!=='r'&&k!=='draw')o[k]=G[k];o.draw=G.draw.length;o.P=G.P.map((p,i)=>Object.assign({},p,{hand:i===j?p.hand:p.hand.map(()=>({id:-1,s:'x',v:'x'})),lack:{}}));return o}
function wcSync(){const G=WX.G;if(!G||!WX.host||WX.mode!=='net')return;G.P.forEach((p,i)=>{if(p.kind!=='net')return;const s=WCNET.peers[p.id];if(s)wcTx(s,{t:'st',G:wcView(G,i)})})}
function wcNetStart(){const G=WX.G;if(WX.mode!=='net')return;G.P.forEach((p,i)=>{if(p.kind==='net'){const s=WCNET.peers[p.id];if(s)wcTx(s,{t:'start',me:i,stake:WX.stake,room:WX.room,timer:WX.cfg.timer})}});wcSync()}
function wcLobbyBack(){wcRelay({t:'lobbyback'});for(const s of WCL.seats)if(s.k==='net')s.ready=0;wcLobby(WX.cfg)}
function wcNetClose(){const g=WCNET.guest;if(g){g.closing=1;try{g.pc.close()}catch(e){}WCNET.guest=null}
 for(const k in WCNET.peers){const s=WCNET.peers[k];s.gone=1;wcTx(s,{t:'close'});try{s.pc.close()}catch(e){}}WCNET.peers={}}
/* ---------- chat and emotes ---------- */
function wcChat(n,x){WX.chat.push([n,x]);if(WX.chat.length>5)WX.chat.shift();const l=$('wcchl');if(l)l.innerHTML=WX.chat.map(([a,b])=>`<p><b class="${a==='System'?'sys':''}">${esc(a)}:</b> ${esc(b)}</p>`).join('')}
function wcEmote(x){const G=WX.G;if(!G)return;wcBubble(WX.me,x,1800);wcChat(G.P[WX.me].name,x);wcSnd(760,.04,'triangle',.2);
 if(WX.mode!=='net')return;if(WX.host)wcRelay({t:'chat',n:G.P[WX.me].name,x,emo:1,seat:WX.me});else wcNetSend({t:'chat',x,emo:1})}
/* ---------- guest side ---------- */
function wcNetSend(o){const g=WCNET.guest;if(g&&g.dc&&g.dc.readyState==='open')try{g.dc.send(JSON.stringify(o))}catch(e){}}
async function wcJoin(code){const r=wcUnpack(code);
 if(!r||r.kind!=='o'){wcModal(`<h3>That code didn't work</h3><p class="wcp">${r&&r.kind==='a'?'That is a reply code. Paste the <b>invite</b> your friend (the host) sent you.':'Make sure you copied the whole invite. It starts with <b>WC1~o</b>, or is a link containing <b>#wcj=</b>.'}</p>`);return}
 if(!wcRtcOk()){wcModal('<h3>Wi-Fi play is not available</h3><p class="wcp">This browser cannot make direct connections.</p>');return}
 wcNetClose();const pc=new RTCPeerConnection(WCRTC),g=WCNET.guest={pc,dc:null,lobby:null,ready:0};
 pc.ondatachannel=e=>{g.dc=e.channel;g.dc.onopen=()=>{wcNetSend({t:'hello',name:P.name||'Friend',av:wcMyAv(),gold:P.gold});wcJoinView(3)};g.dc.onmessage=ev=>wcGuestMsg(ev.data);g.dc.onclose=()=>wcHostGone()};
 pc.onconnectionstatechange=()=>{if(['failed'].includes(pc.connectionState))wcHostGone()};
 try{await pc.setRemoteDescription({type:'offer',sdp:r.sdp});await pc.setLocalDescription(await pc.createAnswer());await wcIce(pc);g.reply=wcPack('a',pc.localDescription.sdp)}catch(e){wcModal('<h3>That invite has expired</h3><p class="wcp">Ask the host to make a new invite.</p>');return}
 wcJoinView(2)}
function wcJoinView(step){const g=WCNET.guest;if(!g)return;WX.tok++;wcClear();const L=g.lobby,set=L&&L.set,me=L&&L.seats[L.you];
 const stp=['Open the invite','Send your reply','Ready up'].map((t,i)=>`<li class="${i+1<step?'done':i+1===step?'on':''}"><b>${i+1<step?'✓':i+1}</b><span>${t}</span></li>`).join('');
 const body=step===2?`<h2>Send this reply to the host</h2><p>Copy it and send it back (a message works), or show it to them. They paste it into their lobby.</p><textarea readonly rows="4" class="wccode" id="wcrc">${esc(g.reply)}</textarea><div class="wcrow"><button class="wcbtn gold big" id="wcrcp">${WCI.copy}Copy reply code</button></div><p class="wcwait"><i></i>Waiting for the host to connect…</p>`
  :!L?`<h2>Connected!</h2><p class="wcwait"><i></i>Getting the table details…</p>`
  :`<h2>Room ${esc(L.room)}</h2><p>You're in. Check the table, then ready up.</p><div class="wcjset"><div><span>Players</span><b>${L.seats.filter(s=>s.k!=='open'&&s.k!=='inv').length} / 4</b></div><div><span>Gold stake</span><b>${set.stake?cmn(set.stake)+' each':'Free'}</b></div><div><span>Turn timer</span><b>${set.timer?set.timer+' s':'Off'}</b></div><div><span>Cards per hand</span><b>${set.hand}</b></div><div><span>House rules</span><b>${[set.stack&&'Stacking',set.until&&'Draw until playable',set.seven&&'Sevens swap'].filter(Boolean).join(', ')||'Standard'}</b></div></div>
   <div class="wcjpl">${L.seats.map(s=>s.k==='open'||s.k==='inv'?'':`<span class="${s.k}">${s.k==='you'?WCI.crown:s.k==='bot'?WCI.bot:WCI.users}${esc(s.name||'')}${s.ready||s.k==='you'||s.k==='bot'?' ✓':''}</span>`).join('')}</div>
   ${set.stake&&P.gold<set.stake?`<p class="wcerr">You need ${cmn(set.stake)} gold for this stake. You have ${cmn(P.gold)}.</p>`:''}
   <button class="wcbtn ${g.ready?'':'gold'} big" id="wcrdy" ${set.stake&&P.gold<set.stake?'disabled':''}>${g.ready?'✓ Ready · waiting for the host to start':'Ready up'}</button>`;
 show(`<div class="wcj" id="wcj"><div class="wcbg"></div><header class="wclh"><h1>Join a room</h1><button class="wcbtn dark" id="wcjl">Leave</button></header><ol class="wcsteps big">${stp}</ol><div class="wcjs">${body}</div><div class="wcmod" id="wcmod" hidden></div></div>`,'casbg wcx');
 S.back=()=>{wcNetClose();wcHome()};$('wcjl').onclick=S.back;
 if($('wcrcp'))$('wcrcp').onclick=()=>wcCopy(g.reply,$('wcrcp'));
 if($('wcrdy'))$('wcrdy').onclick=()=>{g.ready=g.ready?0:1;wcNetSend({t:'ready',v:g.ready});wcSnd(g.ready?880:440,.06,'triangle',.25);wcJoinView(3)}}
function wcGuestMsg(raw){let m;try{m=JSON.parse(raw)}catch(e){return}const g=WCNET.guest;if(!g)return;
 if(m.t==='ping'){wcNetSend({t:'pong',ts:m.ts});return}
 if(m.t==='lobby'){g.lobby=m;if(m.set.stake&&P.gold<m.set.stake&&g.ready){g.ready=0;wcNetSend({t:'ready',v:0})}if($('wcj'))wcJoinView(3);return}
 if(m.t==='lobbyback'){g.ready=0;WX.G=null;wcJoinView(3);return}
 if(m.t==='kick'||m.t==='close'){wcHostGone(m.t==='kick'?'The host removed you from the room.':'The host closed the room.');return}
 if(m.t==='chat'){wcChat(m.n,m.x);if(m.emo&&m.seat!=null)wcBubble(m.seat,String(m.x).slice(0,12));return}
 if(m.t==='start'){const stake=+m.stake||0;if(stake){P.gold=Math.max(0,P.gold-stake);wcSt().dayN++;save()}
  wcReset({mode:'net',host:false,me:+m.me,stake,fee:WCE.MPFEE,room:m.room,cfg:{timer:+m.timer||0}});g.paid=stake;return}
 if(m.t==='st'){const G=m.G;G.r=Math.random;G.draw=new Array(+G.draw||0);const first=!WX.G;WX.G=G;if(first||!$('wct')){wcTable()}wcPump();return}}
function wcHostGone(msg){const g=WCNET.guest;if(!g||g.closing)return;g.closing=1;WCNET.guest=null;const G=WX.G,mid=G&&G.phase!=='over'&&!WX.host;
 if(mid&&g.paid){P.gold+=g.paid;save()}WX.tok++;wcClear();WX.G=null;wcHome();
 wcModal(`<h3>${msg||'Lost the connection to the host'}</h3><p class="wcp">${mid&&g.paid?`Your stake of <b>${cmn(g.paid)}</b> gold was returned.`:'You can join again with a new invite.'}</p>`)}
/* opened from an invite link: go straight to joining */
setTimeout(()=>{try{const h=location.hash;if(h.indexOf('#wcj=')===0){const code=decodeURIComponent(h.slice(5));history.replaceState(null,'',location.href.split('#')[0]);const go=()=>{if(S.mode==='title'){CAS.on=true;wcJoin(code)}else setTimeout(go,500)};setTimeout(go,900)}}catch(e){}},0);
