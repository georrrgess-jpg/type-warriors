/* ===== 8.7 ECONOMY (94d): fair pay, honest text, no exploits =====
   Everything here wraps or redeclares from outside the older modules (a later function declaration wins; wrappers call the old one).
   E1   Lantern Caravan daily contracts: per route and local day the first 3 WON runs pay in full (as before, including the x1.5 first
        win of the day); from the 4th won run the route-pay part is 35%. Road coins and the breakdown payout never change.
        Saved in WRP().ctr = {day, mill, pines, gallows}. The hub shows "Contracts N/3 today", the result card says which contract paid.
   E1b  "Up to N coins + road coins" is the most a perfect next run can really pay for the route (no road coins counted).
   E4   Game speed scales gold per kill by 1+.25*(speed-1), not by the speed; going back to 1x restores S.gm exactly. The level-clear
        bonus uses the same dampened average speed. Score (S.sc) is untouched.
   E7   Prestige clears P.ug (gold put into the skill tree), so a respec right after it refunds nothing it did not spend afterwards.
   E8   An egg of a rarity cannot be bought while the eggs in hand already cover every companion of that rarity still to find.
        Migration P.m87 (once): eggs that were BOUGHT beyond that are refunded at the egg price (never more eggs than were ever bought).
   E9   Level-ups reached through calendar XP or duplicate-crate XP pay the same 100 gold per level as every other XP source.
   E11  Reward text says what is paid (Prospector, prestige: "gold from monsters and rounds").
   E14  P.dmax is the latest local date ever seen. While the clock reads earlier, "today" stays P.dmax: new Date() with no argument is
        held forward by whole days (Date.now() and every timestamp stay real), so the Riddle, the daily calendar, the Bounty Board,
        the Tower boost, Wildcard's daily cap, the caravan contracts and the first-run bonus cannot be reopened by turning the clock back.
        A gap of more than EC.FIXDAYS days is read as a clock that was corrected after a wrong jump forward, and P.dmax drops to today.
   The gold ledger lives in 94e. */
const EC={CONTRACTS:3,REDUCED:.35,SPD_K:.25,FIXDAYS:45,pend:null};
const ecSrc=(label,fn)=>typeof ukSrc==='function'?ukSrc(label,fn):fn();
/* ---------- E14: the calendar clock ---------- */
const EC_RD=window.Date;/* the real constructor; replaced on window only while the clock is behind P.dmax */
let ecShift=0;/* whole days "today" is held forward */
function ECDate(){if(!new.target)return EC_RD();const a=arguments;
 if(a.length===0&&ecShift>0){const n=new EC_RD();return new EC_RD(n.getFullYear(),n.getMonth(),n.getDate()+ecShift,n.getHours(),n.getMinutes(),n.getSeconds(),n.getMilliseconds())}
 return new EC_RD(...a)}
ECDate.prototype=EC_RD.prototype;Object.setPrototypeOf(ECDate,EC_RD);
const ecKey=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
const ecKeyOk=k=>typeof k==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(k);
const ecDayN=k=>{const a=k.split('-').map(Number);return Math.round(EC_RD.UTC(a[0],a[1]-1,a[2])/864e5)};
function ecClockSync(){try{const real=ecKey(new EC_RD());let d=P&&ecKeyOk(P.dmax)?P.dmax:'',gap=0;
 if(d>real){gap=ecDayN(d)-ecDayN(real);if(gap>EC.FIXDAYS){d=real;gap=0}}
 if(!d||real>d){d=real;gap=0}
 if(P&&P.dmax!==d)P.dmax=d;
 if(gap!==ecShift){ecShift=gap;if(gap>0){if(window.Date!==ECDate)window.Date=ECDate}else if(window.Date===ECDate)window.Date=EC_RD}
 return d}catch(e){return''}}
/* the day the game treats as today (the same local key the caravan always used) */
const ecDay=()=>{ecClockSync();return wrDay()};
ecClockSync();
addEventListener('focus',ecClockSync);document.addEventListener('visibilitychange',()=>{if(!document.hidden)ecClockSync()});setInterval(ecClockSync,60000);
{const l0=load;load=function(){const r=l0.apply(this,arguments);ecClockSync();try{if(typeof ldgInstall==='function')ldgInstall()}catch(e){}try{ecMigrate()}catch(e){console.error(e)}return r}}
/* ---------- E1: Lantern Caravan daily contracts ---------- */
{const w0=WRP;WRP=function(){const w=w0.apply(this,arguments);let c=w.ctr;
 if(!c||typeof c!=='object'||Array.isArray(c))c=w.ctr={day:'',mill:0,pines:0,gallows:0};
 if(!ecKeyOk(c.day))c.day='';
 for(const r of WR_ROUTES){const n=c[r.id];c[r.id]=typeof n==='number'&&isFinite(n)&&n>0?Math.min(99,Math.floor(n)):0}
 for(const k of Object.keys(c))if(k!=='day'&&!WR_ROUTES.some(r=>r.id===k))delete c[k];
 return w}}
/* today's contract counts for the player's caravan save (a new day starts them all at zero) */
function ecCtr(w){w=w||WRP();const c=w.ctr,d=ecDay();if(c.day!==d){c.day=d;for(const r of WR_ROUTES)c[r.id]=0}return c}
const ecLeft=id=>Math.max(0,EC.CONTRACTS-(ecCtr()[id]|0));
{const p0=wrPayOf;wrPayOf=function(rt,won){const v=p0.apply(this,arguments),q=EC.pend;
 if(q&&won&&q.won&&q.id===rt.id&&q.used>=EC.CONTRACTS)return Math.round(v*EC.REDUCED);return v}}
{const f0=wrFinish;wrFinish=function(won){const R=WRX;if(!R||R.over)return f0.apply(this,arguments);
 won=!!won;const w=WRP(),rt=R.rt,c=ecCtr(w),used=c[rt.id]|0;EC.pend={id:rt.id,used,won};if(won)c[rt.id]=used+1;/* counted before f0 saves */
 try{return ecSrc('caravan',()=>f0.call(this,won))}finally{EC.pend=null;const r=R.result;if(r)r.ec={n:won?used+1:used,of:EC.CONTRACTS,reduced:won&&used>=EC.CONTRACTS}}}}
/* the result card tells the truth about the route pay */
function ecPayLine(q){const p=[];if(q.first)p.push('first run today ×1.5');
 if(q.won&&q.ec)p.push(q.ec.reduced?'reduced: contracts used':`contract ${q.ec.n}/${q.ec.of}`);
 return `route pay ${q.pay.toLocaleString()}${p.length?` (${p.join(', ')})`:''} · road coins ${q.coins}${q.lg?` · level-up bonus ${q.lg}`:''}`}
{const r0=wrResult;wrResult=function(){const r=r0.apply(this,arguments);try{const q=WRX&&WRX.result,s=document.querySelector('.wrpay small');if(q&&s)s.textContent=ecPayLine(q)}catch(e){console.error(e)}return r}}
/* E1b: the most the next perfect run can pay for the route itself (4 shields, 100% accuracy, the x1.5 first win while it is still there) */
function ecUpTo(rt){const w=WRP(),d=ecDay(),full=wrPayOf(rt,true,WRT.MAXINT,1,1);
 if(ecLeft(rt.id)<=0)return Math.round(full*EC.REDUCED);
 return w.day===d&&w.dayDone[rt.id]?full:Math.round(full*WRT.FIRSTDAY)}
function ecContractTxt(id){const n=ecLeft(id);return n>0?`Contracts ${n}/${EC.CONTRACTS} today`:'Contracts used - reduced pay'}
const ecPips=id=>{const n=ecLeft(id);return `<span class="ecpips" aria-hidden="true">${Array.from({length:EC.CONTRACTS},(_,i)=>`<i class="ecpip${i<n?'':' off'}"></i>`).join('')}</span>`};
function wrReadyFill(){const r=WR_RT(wrSel),n=$('wrrn'),i=$('wrri');if(n)n.textContent=r.n;
 if(i)i.textContent=`${r.legs} legs  •  Up to ${ecUpTo(r).toLocaleString()} coins + road coins`;
 if(!i)return;let c=$('wrrc');if(!c){c=document.createElement('div');c.id='wrrc';i.after(c)}
 const used=ecLeft(r.id)<=0;c.className='wrrc'+(used?' used':'');c.innerHTML=`${ecPips(r.id)}<span>${ecContractTxt(r.id)}</span>`}
{const c0=wrRouteCard;wrRouteCard=function(r){const h=c0.apply(this,arguments);if(!wrRouteOpen(r))return h;
 const used=ecLeft(r.id)<=0,chip=`<span class="eccn${used?' used':''}">${ecPips(r.id)}<span>${ecContractTxt(r.id)}</span></span>`;
 return h.replace(/<\/button>\s*$/,chip+'</button>')}}
{const m0=wagonMenuRefresh;wagonMenuRefresh=function(){const r=m0.apply(this,arguments);try{wrReadyFill()}catch(e){}return r}}
/* ---------- E4: game speed ---------- */
{const s0=setSpeed;setSpeed=function(v){const gm0=S.gm,F0=S.gsF||1,g0=S.gs;
 const r=s0.apply(this,arguments);
 if(S.gs===v&&g0!==v){const F1=1+EC.SPD_K*(v-1),base=S.gsPost!==undefined&&gm0===S.gsPost&&S.gsBase!==undefined?S.gsBase:gm0/F0;
  S.gsBase=base;S.gm=S.gsPost=base*F1;S.gsF=F1}
 return r}}
/* the level-clear bonus multiplies by the average speed: dampen it the same way. Astral levels go through the same call. */
{const v0=victory;victory=function(){const a=S.gsA;if(a>1)S.gsA=1+EC.SPD_K*(a-1);try{return v0.apply(this,arguments)}finally{S.gsA=a}}}
/* ---------- E7: prestige clears the gold recorded as spent in the skill tree ---------- */
{const d0=doPrestige;doPrestige=function(){const was=P.pres|0,r=d0.apply(this,arguments);if((P.pres|0)>was){P.ug=0;save()}return r}}
/* ---------- E8: eggs ---------- */
const ecEggCap=k=>!!P.eggs&&(P.eggs[k]|0)>=petPool(k).length;
{const b0=petBuy;petBuy=function(k){try{petNorm();if(ecEggCap(k))return false}catch(e){}return ecSrc('egg',()=>b0.call(this,k))}}
{const h0=ptEggsHTML;ptEggsHTML=function(){let h=h0.apply(this,arguments);try{const k=PTX.egg;if(PRAR[k]&&ecEggCap(k)){const E=PRAR[k],full=!petPool(k).length;
 h=h.replace(/<button class="ptgo b phx-buy[^"]*" id="phxby"[^>]*>[\s\S]*?<\/button>/,`<button class="ptgo b phx-buy off" id="phxby" disabled title="${full?'You own every companion of this rarity.':'The eggs you hold already cover every companion still to find.'}">All ${E.n} companions found</button>`)
  .replace(/<b>Buy one<\/b><small>[\s\S]*?<\/small>/,`<b>Buy one</b><small>${full?'Nothing left to find':'Enough eggs in hand'}</small>`)}}catch(e){console.error(e)}return h}}
/* ---------- E9: level-up gold from calendar XP and crate-duplicate XP ---------- */
function ecLvPay(f,self,args){const l0=lvl(P.xp),r=f.apply(self,args);try{const l1=lvl(P.xp);if(l1>l0){const g=ecSrc('levelup',()=>levelGold(l0,l1));if(g)save()}}catch(e){console.error(e)}return r}
{const c0=calGrant;calGrant=function(){return ecLvPay(c0,this,arguments)}}
{const r0=crateRoll;crateRoll=function(){return ecLvPay(r0,this,arguments)}}
/* ---------- E11: reward text ---------- */
try{NM.prosp.e=r=>`+${4*r}% gold from monsters and rounds.`}catch(e){}
try{const h=HELP.Modes.find(x=>x[0]==='Lantern Caravan');if(h&&!/contract/i.test(h[1]))h[1]+=` Daily contracts: each route pays its full route pay for your first ${EC.CONTRACTS} wins of the day (the first win of the day pays x1.5); after that the route pay is ${Math.round(EC.REDUCED*100)}%. Road coins are never reduced and the counter resets with the new day.`}catch(e){}
/* ---------- migration P.m87 (once, after the pet normaliser; only ever refunds) ---------- */
const ecUgCap=()=>{let s=0;for(const id in(P.upg||{})){const n=NM[id];if(!n)continue;const k=Math.min(n.max,Math.max(0,P.upg[id]|0));for(let r=0;r<k;r++)s+=gCost(n,r)}return s};
function ecToast(t){setTimeout(()=>{try{ccToast(t)}catch(e){}},2600)}
function ecMigrate(){if(!P||typeof P!=='object'||P.m87)return;let changed=false,refund=0;
 try{petNorm();let left=P.petBuy|0;
  if(P.eggs&&typeof P.eggs==='object')for(const k of Object.keys(PEGG_PRICE).sort((a,b)=>PEGG_PRICE[a]-PEGG_PRICE[b])){
   const have=P.eggs[k]|0,n=Math.min(Math.max(0,have-petPool(k).length),left);
   if(n>0){P.eggs[k]=have-n;refund+=n*PEGG_PRICE[k];left-=n}}
  if(refund>0){ecSrc('migration',()=>{P.gold+=refund});changed=true}}catch(e){console.error(e)}
 /* gold recorded as spent in the tree can never exceed the cost of the ranks that are owned (prestige used to leave it behind) */
 try{const cap=ecUgCap();if((P.ug||0)>cap){P.ug=cap;changed=true}}catch(e){}
 P.m87=1;if(changed)save();
 if(refund>0)ecToast(`Surplus eggs refunded: +${refund.toLocaleString()} coins`)}
setTimeout(()=>{try{ecMigrate()}catch(e){console.error(e)}},0);/* the ledger module also runs it as soon as it is installed */
/* ---------- styles ---------- */
{const st=document.createElement('style');st.textContent=`
.ecpips{display:inline-flex;gap:4px;align-items:center}.ecpip{display:block;width:9px;height:9px;box-sizing:border-box;border-radius:50%;background:#ffd45a;border:1.5px solid #12081f}.ecpip.off{background:#3a3450}
.eccn{position:absolute;right:14px;top:14px;display:flex;align-items:center;gap:8px;padding:5px 13px 5px 10px;border-radius:999px;background:rgba(14,10,48,.9);border:1.5px solid #5a4ca0;font:800 12.5px/1.2 var(--ui);color:#ffe9a0;text-shadow:0 1px 2px #000;pointer-events:none;white-space:nowrap}
.eccn.used{color:#ffb9a8;border-color:#a0564a}
.wrready{padding-top:16px}.wrrdy{height:30px}.wrrdy .wrcomp svg{width:30px;height:30px}
.wrrc{display:flex;align-items:center;gap:8px;margin:0;font:700 13.5px/18px var(--ui);color:#ffe9a0}.wrrc.used{color:#ffb9a8}
.wrcamp.wr-narrow .eccn{right:auto;left:12px;top:10px}.wrcamp.wr-narrow .wrrc{margin-top:5px}`;document.head.appendChild(st)}
