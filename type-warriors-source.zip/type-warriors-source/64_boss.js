/* ---------- boss presence: aura, intro cutscene, roars, phase-break signatures ---------- */
const ROARK={bGob:'growl',bLich:'hollow',bQueen:'hiss',bDemon:'demon',bWyrm:'screech',bKraken:'deep',scarecrow:'hollow',warlord:'growl',hydra:'hiss',golemS:'rumble',wasp:'screech',ogre:'growl',were:'howl',scorpK:'hiss',golemI:'rumble',angler:'deep',thunder:'thunder',golemL:'rumble',marshal:'hollow',witch:'screech',crabK:'deep',tyrantK:'growl',serpent:'hiss',dragonB:'dragon',treant:'rumble',reaper:'hollow',mantis:'screech',dragonR:'dragon',djinn:'thunder',seaKing:'deep'};
const bossKind=id=>ROARK[id]||'growl';
const bossRng=id=>{let h=2166136261;for(const c of id){h^=c.charCodeAt(0);h=Math.imul(h,16777619)}return()=>{h+=0x6D2B79F5;let t=Math.imul(h^h>>>15,1|h);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}};
let NB=null;const noiseBuf=()=>{if(!NB){NB=ac.createBuffer(1,ac.sampleRate*2,ac.sampleRate);const d=NB.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1}return NB};
function vox(o){const n=ac.currentTime+(o.del||0),d=o.dur,g=ac.createGain();g.gain.setValueAtTime(.0001,n);g.gain.exponentialRampToValueAtTime(o.v,n+(o.att||.06));g.gain.exponentialRampToValueAtTime(.0001,n+d);
 let src;if(o.noise){src=ac.createBufferSource();src.buffer=noiseBuf();src.loop=true}else{src=ac.createOscillator();src.type=o.type||'sawtooth';src.frequency.setValueAtTime(o.f0,n);if(o.fm)src.frequency.exponentialRampToValueAtTime(Math.max(20,o.fm),n+d*(o.fmt||.4));src.frequency.exponentialRampToValueAtTime(Math.max(20,o.f1||o.f0),n+d)}
 const fl=ac.createBiquadFilter();fl.type=o.ft||'lowpass';fl.frequency.setValueAtTime(o.q0||1200,n);fl.frequency.exponentialRampToValueAtTime(Math.max(40,o.q1||o.q0||1200),n+d);fl.Q.value=o.Q||2;
 if(o.trem){const l=ac.createOscillator(),lg=ac.createGain();l.frequency.value=o.trem;lg.gain.value=o.v*.55;l.connect(lg);lg.connect(g.gain);l.start(n);l.stop(n+d+.05)}
 if(o.vib&&src.frequency){const l=ac.createOscillator(),lg=ac.createGain();l.frequency.value=o.vibr||6;lg.gain.value=o.vib;l.connect(lg);lg.connect(src.frequency);l.start(n);l.stop(n+d+.05)}
 src.connect(fl);fl.connect(g);g.connect(sg);src.start(n);src.stop(n+d+.05)}
function bossRoar(id,sc){if(!ac||!sg||ST.svol<=0)return;sc=sc||1;try{const r=bossRng(id),p=.82+r()*.4,k=bossKind(id),D=(1.2+r()*.5)*sc,tr=8+r()*24,V=sc<1?.22:.3;
 const gr=()=>{vox({f0:105*p,fm:130*p,f1:52*p,dur:D,v:V,q0:1400,q1:260,trem:tr,vib:9,vibr:19});vox({noise:1,dur:D*.8,v:V*.55,ft:'bandpass',q0:520*p,q1:180,Q:1.4})};
 const sc2=()=>{vox({f0:820*p,fm:1900*p,f1:640*p,dur:D*.85,v:V*.7,q0:3200,q1:1400,trem:tr*1.6,vib:60,vibr:31});vox({noise:1,dur:D*.6,v:V*.4,ft:'highpass',q0:3000,q1:5000,Q:.8})};
 if(k==='growl')gr();
 else if(k==='howl'){vox({type:'triangle',f0:220*p,fm:560*p,f1:260*p,fmt:.55,dur:D*1.25,v:V*.8,q0:1800,q1:900,vib:14,vibr:6});gr()}
 else if(k==='screech')sc2();
 else if(k==='hollow'){for(const dt of[1,1.5])vox({type:'triangle',f0:170*p*dt,fm:210*p*dt,f1:120*p*dt,dur:D*1.4,v:V*.7,att:.25,q0:900,q1:400,vib:8,vibr:5.5});vox({noise:1,dur:D,v:V*.35,ft:'bandpass',q0:900,q1:500,Q:5,att:.3})}
 else if(k==='hiss'){vox({noise:1,dur:D*1.1,v:V*.8,ft:'highpass',q0:2400*p,q1:4200,Q:.7,trem:11+r()*8});vox({f0:70*p,f1:48*p,dur:D,v:V*.5,q0:500,q1:200})}
 else if(k==='deep'){vox({type:'sine',f0:70*p,fm:58*p,f1:32*p,dur:D*1.3,v:V*1.1,q0:400,q1:150,trem:6+r()*5});vox({type:'square',f0:130*p,f1:66*p,dur:D,v:V*.35,q0:600,q1:180,trem:13,vib:12,vibr:8});vox({noise:1,dur:D,v:V*.4,ft:'lowpass',q0:500,q1:140})}
 else if(k==='rumble'){vox({noise:1,dur:D*1.5,v:V*1.1,ft:'lowpass',q0:320*p,q1:70,Q:3,att:.2,trem:5+r()*3});vox({f0:46*p,f1:34*p,dur:D*1.4,v:V*.9,q0:200,q1:80,trem:4})}
 else if(k==='thunder'){for(let i=0;i<3;i++)vox({noise:1,dur:.5+D*.6,v:V*(1-i*.2),ft:'lowpass',q0:2600-i*600,q1:120,Q:.9,att:.01,del:i*.22*(.6+r())});vox({f0:60*p,f1:38*p,dur:D*1.3,v:V*.7,q0:200,q1:80,del:.1})}
 else if(k==='dragon'){gr();sc2();vox({noise:1,dur:D*1.4,v:V*.5,ft:'bandpass',q0:1500,q1:700,Q:.6,del:.35,att:.2})}
 else if(k==='demon'){vox({f0:74*p,fm:90*p,f1:44*p,dur:D*1.3,v:V,q0:2200,q1:300,trem:tr,vib:20,vibr:13});vox({f0:74.7*p,f1:44*p,dur:D*1.3,v:V*.8,q0:1800,q1:300,trem:tr*.8});vox({f0:520*p,f1:180*p,dur:D*.7,v:V*.35,type:'square',q0:1800,q1:500,vib:40,vibr:23})}
 }catch(e){}}

/* --- aura --- */
const AURK=['spore','soul','mote','ember','snow','bubble'];
function bossAura(e,cyc,ac,pre){const c=ctx,z=zoneIdx(S.wave||1),kd=AURK[z%6],pm=e.pm||(e.pm=e.phs),rage=Math.max(0,Math.min(1,(pm-e.phs)/Math.max(1,pm-1)));
 if(pre){
  const rr=e.h*(.62+.06*Math.sin(S.t*2));c.save();c.translate(e.x,GY+8);c.scale(1,.2);c.strokeStyle=ac+'aa';c.lineWidth=6;c.shadowColor=ac;c.shadowBlur=20;
  for(const [r,sp] of[[rr,1],[rr*.72,-1.5]]){c.setLineDash([22,14]);c.lineDashOffset=-S.t*34*sp;c.beginPath();c.arc(0,0,r,0,TAU);c.stroke()}
  c.setLineDash([]);c.shadowBlur=0;c.lineWidth=3;c.strokeStyle=ac+'66';for(let i=0;i<6;i++){const a=i*TAU/6+S.t*.4;c.beginPath();c.moveTo(Math.cos(a)*rr*.72,Math.sin(a)*rr*.72);c.lineTo(Math.cos(a+2.1)*rr,Math.sin(a+2.1)*rr);c.stroke()}c.restore();
  if(rage>0){const pu=.5+.5*Math.sin(S.t*8);glow(c,e.x,cyc,e.h*(1+.15*pu),'#ff2828'+Math.round((.18+.28*rage*pu)*255).toString(16).padStart(2,'0'))}
  c.save();const g=c.createLinearGradient(0,GY-e.h*.5,0,GY+14);g.addColorStop(0,'#0000');g.addColorStop(1,ac+'44');c.fillStyle=g;c.beginPath();c.ellipse(e.x,GY,e.h*.55,e.h*.5,0,Math.PI,TAU);c.fill();c.restore()}
 else{
  const N=12+Math.round(rage*8);c.save();
  for(let i=0;i<N;i++){const sp=kd==='ember'?.6:kd==='snow'?-.16:kd==='bubble'?.32:.3,u=((S.t*sp*(.7+i%3*.2)+i/N)%1+1)%1,x=e.x+Math.sin(i*7.3+S.t*.8+u*3)*e.h*.5,y=kd==='snow'?e.y-e.h*1.15+u*e.h*1.2:e.y-u*e.h*1.25,a=Math.sin(u*Math.PI);
   c.globalAlpha=a*.85;
   if(kd==='soul'){c.fillStyle='#bff4ff';c.beginPath();c.ellipse(x,y,3,9,0,0,TAU);c.fill();c.globalAlpha=a*.4;c.fillRect(x-1,y+8,2,14)}
   else if(kd==='bubble'){c.strokeStyle='#bfe8ff';c.lineWidth=2;c.beginPath();c.arc(x,y,4+i%4*2,0,TAU);c.stroke()}
   else if(kd==='ember'){c.fillStyle=i%2?'#ffb040':'#ff5a20';c.fillRect(x,y,3.5,3.5)}
   else if(kd==='snow'){c.fillStyle='#fff';c.beginPath();c.arc(x,y,2.5+i%3,0,TAU);c.fill()}
   else{c.fillStyle=kd==='spore'?'#c8ff90':'#d8a0ff';c.beginPath();c.arc(x,y,2+i%3,0,TAU);c.fill()}}
  c.restore()}}

/* --- intro cutscene --- */
const easeO=u=>1-Math.pow(1-Math.max(0,Math.min(1,u)),3);
function cineStart(e){S.cine={e,t:0,dur:2.9,roared:0,fired:0};S.shots=[];S.pj=[]}
function cineEnd(){const c=S.cine;if(!c)return;S.cine=null;const e=c.e;e.state='fight';newBossLine(e);S.ban=null}
function cineTick(dt){const c=S.cine;c.t+=dt;S.t+=dt;
 for(const p of S.ps){p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=p.g*dt;p.l-=dt}S.ps=S.ps.filter(p=>p.l>0);
 for(const q of S.fx)q.t+=dt;S.fx=S.fx.filter(q=>q.t<q.ml);
 for(const f of S.fl){f.y-=44*dt;f.t-=dt}S.fl=S.fl.filter(f=>f.t>0);
 S.shake=Math.max(0,S.shake-dt*40);S.flash=Math.max(0,S.flash-dt*3);
 if(!c.roared&&c.t>.7){c.roared=1;const e=c.e,col=lvDef(S.wave).a;bossRoar(e.id);S.shake=34;S.flash=Math.max(S.flash,.35);
  for(const [r1,w,d] of[[420,10,0],[300,6,.08]])S.fx.push({k:'ring',x:e.x,y:GY-e.h*.4,t:0,ml:.9+d*4,c:col,w,r0:20,r1});
  S.fx.push({k:'flash',x:e.x,y:e.y-e.h*.5,t:0,ml:.5,c:col,r:e.h});
  burst(e.x,GY-4,'#d8c8a8',40,{v:520,l:1,g:500});burst(e.x,GY-e.h*.5,col,30,{v:380,l:.9,g:-40,s:6})}
 if(c.t>=c.dur||c.skip)cineEnd()}
function cineZoom(){const c=S.cine;if(!c)return null;const t=c.t,e=c.e,mz=Math.max(.15,Math.min(.5,520/e.h-1)),z=1+mz*easeO(t/.8)*(1-easeO((t-(c.dur-.4))/.4))+(c.roared&&t<c.dur?.03*Math.sin(t*46)*Math.exp(-(t-.7)*4):0);return{z,fx:e.x,fy:e.y-e.h*.55}}
function drawCine(){const c=S.cine;if(!c)return;const g=ctx,t=c.t,e=c.e,bar=easeO(t/.35)*(1-easeO((t-(c.dur-.3))/.3))*H*.115;
 g.save();g.fillStyle='#000';g.fillRect(0,0,W,bar);g.fillRect(0,H-bar,W,bar);
 const gv=g.createRadialGradient(W/2,H/2,H*.35,W/2,H/2,H*.95);gv.addColorStop(0,'#0000');gv.addColorStop(1,`rgba(0,0,0,${.6*easeO(t/.6)})`);g.fillStyle=gv;g.fillRect(0,0,W,H);
 const a=lvDef(S.wave).a,u=easeO((t-.75)/.5),fo=1-easeO((t-(c.dur-.35))/.3);
 if(u>0){g.globalAlpha=u*fo;g.textAlign='center';g.textBaseline='middle';
  const y=H-bar-120,slide=(1-u)*90;
  const w=Math.min(W-160,760+e.nm.length*10);g.fillStyle='rgba(6,3,14,.72)';g.fillRect(W/2-w/2-slide,y-70,w,150);
  g.fillStyle=a;g.fillRect(W/2-w/2-slide,y-70,6,150);g.fillRect(W/2+w/2-6-slide,y-70,6,150);
  g.font='30px Cinzel,Georgia,serif';g.fillStyle=a;g.shadowColor='#000';g.shadowBlur=6;g.fillText(`LEVEL ${lvOf(S.wave)}  -  ${lvDef(S.wave).n.toUpperCase()}`,W/2-slide,y-38);
  g.font='88px "Pirata One",Georgia,serif';g.fillStyle='#fff';g.shadowColor=a;g.shadowBlur=26;g.fillText(e.nm,W/2+slide*.3,y+22);
  g.shadowBlur=0;g.fillStyle=a;const lw=w*.86*easeO((t-.95)/.7);g.fillRect(W/2-lw/2,y+68,lw,3)}
 if(t>.5){g.globalAlpha=.55;g.font='20px Georgia,serif';g.fillStyle='#fff';g.textAlign='right';g.fillText('Press any key to skip',W-30,H-bar-18)}
 g.restore()}

/* --- phase-break signatures --- */
function phaseBreakFx(e){const k=bossKind(e.id),a=lvDef(S.wave).a,x=e.x,y=GY-e.h*.5,add=o=>{if(S.fx.length<160)S.fx.push(Object.assign({x,y,t:0,ml:.6},o))};
 const ring=(c,r1,w,d)=>add({k:'ring',c,r0:10,r1,w,t:0,ml:.7+(d||0)*3});
 const streaks=(n,c,l)=>{for(let i=0;i<n;i++){const an=i/n*TAU+Math.random()*.3;add({k:'line',a:an,v:360+Math.random()*200,l:l||110,w:3,c,ml:.55})}};
 add({k:'flash',c:a,r:e.h*.9,ml:.45});
 if(k==='growl'||k==='rumble'){ring('#e8d8b0',520,12);ring(a,380,7,.1);burst(x,GY-4,'#a89070',46,{v:560,l:1.1,g:900});for(let i=0;i<10;i++)S.ps.push({x:x+(Math.random()-.5)*e.h,y:GY-10,vx:(Math.random()-.5)*300,vy:-300-Math.random()*400,l:1,ml:1,c:'#7a6a58',s:9,g:1100});S.shake=Math.max(S.shake,26)}
 else if(k==='hollow'){for(let i=0;i<26;i++)S.ps.push({x:x+(Math.random()-.5)*e.h*.7,y:GY-Math.random()*e.h,vx:(Math.random()-.5)*60,vy:-140-Math.random()*220,l:1.6,ml:1.6,c:i%2?'#bff4ff':'#e8ffff',s:5,g:-60});ring('#bff4ff',420,5);ring('#ffffff',260,3,.12)}
 else if(k==='hiss'){burst(x,y,'#7dff5a',44,{v:380,l:1.2,g:80,s:9});burst(x,y,'#3aa030',24,{v:240,l:1.4,g:40,s:12});ring('#7dff5a',400,8)}
 else if(k==='screech'){streaks(22,'#ffffff',150);ring(a,460,4);burst(x,y,'#f4f0d8',26,{v:420,l:.9,g:120,s:3})}
 else if(k==='deep'){ring('#bfe8ff',480,9);ring('#4aa8e8',320,6,.1);burst(x,y,'#8ad0ff',48,{v:480,l:1.1,g:700,s:6});for(let i=0;i<8;i++)S.ps.push({x:x+(Math.random()-.5)*e.h*.6,y:y+Math.random()*e.h*.4,vx:(Math.random()-.5)*60,vy:-80-Math.random()*100,l:1.5,ml:1.5,c:'#dff4ff',s:7,g:-40})}
 else if(k==='thunder'){for(let i=0;i<7;i++)add({k:'line',a:-Math.PI/2+(Math.random()-.5)*2.4,v:80,l:220+Math.random()*120,w:5,c:i%2?'#fff6a0':'#8ad0ff',ml:.4});burst(x,y,'#fff6a0',40,{v:600,l:.6,g:200,s:4});S.flash=Math.max(S.flash,.4);S.shake=Math.max(S.shake,22)}
 else if(k==='howl'){for(let i=0;i<4;i++){const an=-.5+i*.34;for(let j=0;j<3;j++)add({k:'line',a:an+.9,v:200,l:260,w:7,c:'#ffe0d0',ml:.45,x:x-120+i*44,y:y-90+j*8+i*10})}burst(x,y,'#c02030',30,{v:420,l:.8})}
 else{burst(x,y,'#ff8a20',60,{v:620,l:1.1,g:200,s:7});burst(x,y,'#ffd060',30,{v:420,l:.8,g:100,s:5});ring('#ffb040',520,10);ring('#ff5020',360,7,.1);S.flash=Math.max(S.flash,.4);S.shake=Math.max(S.shake,26)}
 if(k!=='thunder')S.shake=Math.max(S.shake,16);
 bossRoar(e.id,.42)}

/* --- new boss attacks: bolt / beam strikes (parry with Space), lunge, tremor, barrage, ward, blind --- */
const SIGN={growl:['lunge','tremor'],howl:['lunge','barrage'],rumble:['tremor','lunge'],hollow:['blind','ward'],hiss:['barrage','blind'],screech:['bolt','barrage'],deep:['beam','tremor'],thunder:['bolt','beam'],dragon:['beam','bolt'],demon:['ward','beam']};
function bossSig(e,tier,id){const s=SIGN[bossKind(id)]||['lunge','tremor'];const easy=['lunge','tremor','blind','ward'];
 e.pat=e.pat.slice();e.pat.push(easy.includes(s[0])?s[0]:'ward');if(tier>=1)e.pat.push(s[1]==='bolt'&&tier<2?'blind':s[1]);if(tier>=3)e.pat.push(s[0])}
function lungeStep(e,dt){const d=e.ds;d.t+=dt;const HOME=W-340;
 if(d.ph==='in'){const u=Math.min(1,d.t/.75);e.x=HOME-(HOME-(KX+300))*(u*u);e.lg=1;if(u>=1){e.ds=null;e.x=HOME;e.lg=1;S.shake=24;float(KX,GY-260,'Crushed!','#ff5c6c',38);burst(KX+60,GY-100,'#ff8a3a',30,{v:400});S.by=e.nm;dmg(1);e.ak=Math.max(e.ak,3);e.tm=Math.max(e.tm,2.4)}}
 else{const u=Math.min(1,d.t/.8);e.x=(KX+300)+(HOME-(KX+300))*u;if(u>=1){e.ds=null;e.x=HOME;e.tm=Math.max(e.tm,2.4);e.ak=Math.max(e.ak,3)}}}
function strikeStep(dt){if(!S.bk||!S.bk.length)return;for(const q of S.bk){q.t-=dt}
 const hit=S.bk.filter(q=>q.t<=0);if(!hit.length)return;S.bk=S.bk.filter(q=>q.t>0);
 for(const q of hit){S.fx.push({k:'flash',x:KX+30,y:GY-120,t:0,ml:.35,c:q.k==='bolt'?'#fff6a0':'#ff6a6a',r:190});(S.bx=S.bx||[]).push({k:q.k,t:0});burst(KX+30,GY-100,q.k==='bolt'?'#fff6a0':'#ff6a6a',34,{v:480});S.shake=Math.max(S.shake,22);beep(q.k==='bolt'?90:70,.4,'sawtooth',1);S.by=q.k==='bolt'?'a lightning strike':'a death beam';dmg(1);if(S.mode!=='play')return}}
function drawStrikes(c){
 if(S.bk&&S.bk.length){for(const q of S.bk){const u=1-q.t/q.t0,ph=Math.floor(S.t*12)%2,win=q.t<.65;
  if(q.k==='bolt'){c.save();c.strokeStyle=win?(ph?'#fff':'#ffdf60'):'#ffdf6088';c.lineWidth=win?5:3;c.shadowColor='#ffdf60';c.shadowBlur=14;c.beginPath();c.ellipse(KX+30,GY-4,90*(1.5-u*.5),18*(1.5-u*.5),0,0,TAU);c.stroke();c.beginPath();c.moveTo(KX+30,GY-6);c.lineTo(KX+30,GY-380*u);c.stroke();c.restore()}
  else{const e=S.en.find(z=>z.boss);const bx=e?e.x-60:W-400,by=e?e.y-e.h*.5:GY-200;c.save();c.strokeStyle=win?(ph?'#fff':'#ff6a6a'):'#ff6a6a88';c.lineWidth=(win?10:3)*(.4+u);c.shadowColor='#ff3a3a';c.shadowBlur=16;c.setLineDash(win?[]:[16,12]);c.beginPath();c.moveTo(bx,by);c.lineTo(KX+30,GY-120);c.stroke();c.restore()}
  if(win){c.save();c.font='40px "Pirata One",Georgia,serif';c.textAlign='center';c.fillStyle=ph?'#ffdf60':'#fff';c.strokeStyle='#000';c.lineWidth=6;c.strokeText('SPACE!',KX+30,GY-300);c.fillText('SPACE!',KX+30,GY-300);c.restore()}}}
 if(S.bx&&S.bx.length){for(const z of S.bx){z.t+=1/60}S.bx=S.bx.filter(z=>z.t<.3);for(const z of S.bx){const a=1-z.t/.3;c.save();c.globalAlpha=a;if(z.k==='bolt'){c.strokeStyle='#fff6c0';c.lineWidth=16*a;c.shadowColor='#ffdf60';c.shadowBlur=30;c.beginPath();let x=KX+30,y=-20;c.moveTo(x,y);while(y<GY-4){y+=60;x=KX+30+(Math.random()-.5)*50;c.lineTo(x,y)}c.stroke()}else{c.fillStyle='#ff6a6a';c.shadowColor='#ff3a3a';c.shadowBlur=30;c.fillRect(KX,GY-150,W,60*a);c.fillStyle='#fff';c.fillRect(KX,GY-134,W,28*a)}c.restore()}}}
