/* ===== PENALTY KINGS 9.9c: a new casino tile with a NEW ribbon, first in the casino (96zx, after 96zw) =====
   Floodlit night stadium, crowd, striped pitch, the goal with a bulging net, Mossback at full stretch with his gold glove, the ball
   ripping into the top corner with a streak and sparks, a gold crown, and a pulsing red-and-gold NEW badge on the tile's corner (CSS). Penalty Kings moves
   to the front of the GAMES list (top left of the casino grid). */
TA.pk=`<svg viewBox="0 0 320 176" preserveAspectRatio="xMidYMid slice"><defs>
<linearGradient id="pk9s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#090726"/><stop offset=".55" stop-color="#2a1660"/><stop offset="1" stop-color="#4a2a8a"/></linearGradient>
<linearGradient id="pk9p" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4cc25a"/><stop offset="1" stop-color="#1e6a2c"/></linearGradient>
<linearGradient id="pk9b" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff6c8" stop-opacity=".55"/><stop offset="1" stop-color="#fff6c8" stop-opacity="0"/></linearGradient>
<radialGradient id="pk9g" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#fff3b0"/><stop offset=".4" stop-color="#ffd45a" stop-opacity=".7"/><stop offset="1" stop-color="#ffd45a" stop-opacity="0"/></radialGradient>
<linearGradient id="pk9t" x1="1" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset="1" stop-color="#fff6d0" stop-opacity=".95"/></linearGradient>
<pattern id="pk9c" width="12" height="10" patternUnits="userSpaceOnUse"><circle cx="3" cy="4" r="2.6" fill="#6a4ab0"/><circle cx="9" cy="8" r="2.6" fill="#8a5ac8"/><circle cx="9" cy="2" r="1.6" fill="#c8a0ff" opacity=".6"/></pattern>
<pattern id="pk9n" width="9" height="9" patternUnits="userSpaceOnUse"><path d="M0 0L9 9M9 0L0 9" stroke="#e8e4ff" stroke-width=".9" opacity=".55"/></pattern>
<linearGradient id="pk9j" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffb060"/><stop offset="1" stop-color="#d0601a"/></linearGradient>
</defs>
<rect width="320" height="176" fill="url(#pk9s)"/>
<path d="M18 0L-10 120H60Z" fill="url(#pk9b)"/><path d="M302 0L250 120H330Z" fill="url(#pk9b)"/>
<rect x="6" y="2" width="26" height="9" rx="3" fill="#fff6d8" stroke="#12081f" stroke-width="2"/><rect x="288" y="2" width="26" height="9" rx="3" fill="#fff6d8" stroke="#12081f" stroke-width="2"/>
<rect x="0" y="54" width="320" height="56" fill="url(#pk9c)"/><rect x="0" y="100" width="320" height="10" fill="#2a1a5a"/>
<path d="M0 108H320V176H0Z" fill="url(#pk9p)"/><path d="M0 120H320M0 140H320M0 160H320" stroke="#5ad26a" stroke-width="9" opacity=".35"/>
<path d="M40 176L76 126H244L280 176" fill="none" stroke="#e8ffe8" stroke-width="2.4" opacity=".75"/>
<rect x="74" y="44" width="172" height="82" fill="#1a1440" opacity=".55"/><rect x="74" y="44" width="172" height="82" fill="url(#pk9n)"/>
<path d="M214 46q14 10 28 2" fill="none" stroke="#fff" stroke-width="2" opacity=".7"/>
<path d="M70 128V40H250V128" fill="none" stroke="#12081f" stroke-width="10" stroke-linejoin="round"/><path d="M70 128V40H250V128" fill="none" stroke="#fff" stroke-width="5.5" stroke-linejoin="round"/>
<g transform="translate(232 58)"><circle r="34" fill="url(#pk9g)"/>
<path d="M14 18L66 82" stroke="url(#pk9t)" stroke-width="13" stroke-linecap="round"/>
<g stroke="#ffd45a" stroke-width="3" stroke-linecap="round"><path d="M-22 -4l-9 -2M-16 -18l-6 -7M-2 -24l0 -9M14 -20l6 -7M20 2l9 2"/></g>
<circle r="13" fill="#fff" stroke="#12081f" stroke-width="3"/><path d="M0 -5l5 3.5-2 6h-6l-2-6z" fill="#12081f"/><path d="M-12 -3l5 2M12 -3l-5 2M-6 11l2-5M6 11l-2-5M0 -12v6" stroke="#12081f" stroke-width="2"/></g>
<g transform="translate(150 86) rotate(-28)">
<path d="M-38 6q-8 10-20 14" stroke="#12081f" stroke-width="12" stroke-linecap="round" fill="none"/><path d="M-38 6q-8 10-20 14" stroke="#2a2460" stroke-width="7" stroke-linecap="round" fill="none"/>
<path d="M-34 -4q-12 0-26 -6" stroke="#12081f" stroke-width="12" stroke-linecap="round" fill="none"/><path d="M-34 -4q-12 0-26 -6" stroke="#2a2460" stroke-width="7" stroke-linecap="round" fill="none"/>
<rect x="-40" y="-14" width="50" height="28" rx="12" fill="url(#pk9j)" stroke="#12081f" stroke-width="3.5"/>
<text x="-15" y="7" font-family="Pirata One,Georgia,serif" font-size="17" fill="#fff8e0" stroke="#12081f" stroke-width="3" paint-order="stroke" text-anchor="middle">1</text>
<path d="M8 -8q30 -10 58 -14" stroke="#12081f" stroke-width="12" stroke-linecap="round" fill="none"/><path d="M8 -8q30 -10 58 -14" stroke="#ff8a2a" stroke-width="7" stroke-linecap="round" fill="none"/>
<g transform="translate(70 -23) rotate(-8)"><path d="M-8 -9h12q8 0 8 9t-8 9h-12z" fill="#ffd45a" stroke="#12081f" stroke-width="3"/><path d="M4 -9v-5m4 5v-4" stroke="#12081f" stroke-width="2.5"/></g>
<g transform="translate(22 -2)"><circle r="17" fill="#7ac24a" stroke="#12081f" stroke-width="3.5"/><path d="M-10 -18l4 6 3-8 3 8 4-7 2 7" fill="#3a8a2a" stroke="#12081f" stroke-width="2"/>
<circle cx="-5" cy="-1" r="4.6" fill="#fff" stroke="#12081f" stroke-width="2"/><circle cx="7" cy="-2" r="4.6" fill="#fff" stroke="#12081f" stroke-width="2"/><circle cx="-4" cy="-1" r="2" fill="#d02a3a"/><circle cx="8" cy="-2" r="2" fill="#d02a3a"/>
<path d="M-6 9q6 4 12 -1" fill="none" stroke="#12081f" stroke-width="2.5"/><path d="M-15 -4l-9 -6 4 10z" fill="#5a9a34" stroke="#12081f" stroke-width="2"/></g></g>
<g transform="translate(160 22)"><path d="M-16 8l-4 -16 10 8 10 -14 10 14 10 -8 -4 16z" fill="#ffd45a" stroke="#12081f" stroke-width="3" stroke-linejoin="round"/><circle cx="0" cy="-12" r="2.4" fill="#ff6a8a"/><rect x="-16" y="8" width="32" height="5" rx="2" fill="#e8a018" stroke="#12081f" stroke-width="2"/></g>

</svg>`;
{const i=GAMES.findIndex(g=>g.id==='pk');if(i>0){const [g]=GAMES.splice(i,1);GAMES.unshift(g)}}
{const st=document.createElement('style');st.textContent=`.gdt[data-g="pk"]{position:relative}.gdt[data-g="pk"]::after{content:'NEW';position:absolute;left:10px;top:10px;z-index:3;padding:3px 9px 2px;border-radius:9px;background:linear-gradient(180deg,#ff5a6e,#c8203a);border:2px solid #ffd45a;box-shadow:0 0 0 2px #12081f,0 4px 10px #0008;font:900 12px/1.1 Poppins,system-ui,sans-serif;letter-spacing:.12em;color:#fff8e0;pointer-events:none;animation:pknewb 1.6s ease-in-out infinite}
@keyframes pknewb{0%,100%{transform:scale(1) rotate(-6deg)}50%{transform:scale(1.1) rotate(-6deg)}}`;document.head.appendChild(st)}
