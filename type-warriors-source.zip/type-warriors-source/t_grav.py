# python3 t_grav.py [game.html] : the Singularity Engine (98j art, 98k battle; the twelfth tower of 10.0, TD_WORLDS_PLAN.md section 3).
# Key G, 600 supply, ground only; gravity orbs open wells that pull ground monsters along their own road and crush them (more in a crowd,
# up to x2); pull caps (life and the Tidecaller's shared budget), bosses half; tier 3 tidal lock, tier 4 event horizon, tier 5 collapse;
# Overcharge, Rune Typing, the 97k glow layer, art per tier, frame cost, info panel, the bar and the ring, a full wave, no page errors.
import asyncio,os,sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:600]),flush=True)
    if not ok:FAIL.append(name)
HELP=r"""()=>{
 window.tdBuild=(R,p,t,tier)=>{rpBuild(p,t);const tw=p.tw;tw.build=1;while(tw.tier<tier&&rpUpgrade(tw)){}tw.upK=1;return tw};
 window.tdNew=(map,wave)=>{try{rpLeave()}catch(e){}rpStart(map);const R=RPX;R.tut=null;R.hold=false;R.supply=1e9;R.wst='run';R.wave=wave||1;R.q=[];R.banner=null;R.foes=[];return R};
 window.tdFoe=(R,id,s,pi)=>{const e=rpSpawn(id,pi||0);e.s=s;e.sp=0;e.off=0;return e};
 window.tdRun=(R,sec)=>{for(let i=0;i<Math.round(sec*30);i++)rpStep(R,1/30)};
 /* a quiet Engine (it never fires on its own) and a well opened by hand at road position s of path pi */
 window.tdEng=(R,tier,pad)=>{const tw=tdBuild(R,pad||R.pads[0],'grav',tier);tw.cd=1e9;return tw};
 window.tdWell=(R,tw,s,pi,nova)=>{const p=rpAt(R.G,s,pi||0);rpgvOpen(R,{x1:p.x,y1:p.y,s,pi:pi||0,tw,tier:tw.tier,nova:!!nova,seed:1});return R.gvWells[R.gvWells.length-1]};
 window.tdMid=(R)=>Math.round(rpLen(R,{pi:0})*.45);
 /* the road position from s0 (along path pi, direction dir) whose ground distance (rpD2) from s0's point first reaches d */
 window.tdNear=(R,s0,d,dir,pi)=>{const c=rpAt(R.G,s0,pi||0);for(let s=s0;s>=0&&s<=rpLen(R,{pi:pi||0});s+=dir){const q=rpAt(R.G,s,pi||0);if(rpD2(q.x,q.y,c.x,c.y)>=d*d)return s}return s0+dir*d};
 return 1}"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        pg.on('console',lambda m:er.append('console: '+m.text[:300]) if m.type=='error' and 'WebSocket' not in m.text else None)
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E("()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const r=RPP();r.new99j=1;r.dragon=1;r.stars=Object.assign(r.stars||{},{moss:3,frost:3,ember:3,coral:3,wreck:3,abyss:3});const T=r.tut;for(const k in T)T[k]=1;for(const k of['build','wave','coins','upgrade','abil','rune','twist_frost','twist_ember','twist_wonder'])T[k]=1;save()}")
        await E(HELP)
        # ---- data
        r=await E("""()=>{const T=RP_TW.grav,i=RP_TWORDER.indexOf('grav');return [i>=10,RP_KEYS[i],RPTW.grav.n,T.cost,T.air,T.ground,RPSKIN.grav,[1,2,3,4,5].map(t=>rpTowerTop('grav',t)),
          Object.keys(T).filter(k=>k!=='up'&&Array.isArray(T[k])).every(k=>T[k].length===5),T.up.length,typeof T.desc]}""")
        chk('data: the twelfth tower (after the others), key G, 600 supply, ground only, base skin, taller every tier, five tiers, four upgrade texts',
            r[0] and r[1]=='G' and r[2]=='Singularity Engine' and r[3][0]==600 and r[4]==0 and r[5]==1 and r[6]==['base'] and r[7]==sorted(r[7]) and len(set(r[7]))==5 and r[8] and r[9]==4 and r[10]=='string',r)
        r=await E("""()=>{const T=RP_TW.grav;const up=k=>[0,1,2,3].every(i=>T[k][i]<=T[k][i+1]);return [up('range'),up('dmg'),up('well'),up('pull'),up('dur'),[0,1,2,3].every(i=>T.cd[i]>T.cd[i+1]),T.lock,T.exec,T.nova,T.dur]}""")
        chk('balance table: range, crush, well, pull and duration grow, the reload shrinks; lock from tier 3, swallow from tier 4, collapse at tier 5, wells 2.5 s then 3.2 s',
            all(r[:6]) and r[6][:2]==[0,0] and r[6][2]==0.3 and r[7][:3]==[0,0,0] and r[7][3]==0.08 and r[8]==[0,0,0,0,4] and r[9]==[2.5,2.5,2.5,3.2,3.2],r)
        # ---- build, key, bar, upgrade, sell
        r=await E("""async()=>{try{rpLeave()}catch(e){}rpStart('moss');const R=RPX;R.tut=null;R.supply=1000;await new Promise(r=>setTimeout(r,700));
          window.dispatchEvent(new KeyboardEvent('keydown',{key:'g'}));const a=R.place;R.place=null;
          const c=document.querySelector('.rpcard[data-tw="grav"]'),ok=rpBuild(R.pads[0],'grav');
          R.ty.on=true;window.dispatchEvent(new KeyboardEvent('keydown',{key:'g'}));const b2=R.place;R.ty.on=false;R.ty.buf='';R.ty.k=null;R.place=null;
          return [a,!!c,c&&!c.classList.contains('lock'),ok!==false&&!!R.pads[0].tw,1000-R.supply,document.querySelectorAll('.rpbar .rpcard').length===RP_TWORDER.length,b2]}""")
        chk('key G picks it; its card is in the bar; it builds for 600; with Rune Typing on, G types instead of picking it',r[:6]==['grav',True,True,True,600,True] and r[6]!='grav',r)
        r=await E("""()=>{const R=tdNew('wonder',10);R.supply=10000;const p=R.pads[0];rpBuild(p,'grav');const tw=p.tw;tw.build=1;const c=[];for(let k=0;k<4;k++){const s0=R.supply;rpUpgrade(tw);tw.upK=1;c.push(s0-R.supply)}
          const sp=tw.spent,s1=R.supply;rpSell(tw);return [c,sp,R.supply-s1,Math.round(sp*RPT.SELL),!p.tw,tw.tier]}""")
        chk('upgrades cost 380 / 650 / 1250 / 1950 up to tier 5 in the Wonderland; selling refunds the usual share of everything spent',r[0]==[380,650,1250,1950] and r[1]==4830 and r[2]==r[3] and r[4] and r[5]==5,r)
        # ---- ground only
        r=await E("""()=>{const R=tdNew('moss',3);const tw=tdBuild(R,R.pads[3],'grav',2);let bs=0,bd=1e9;const L=rpLen(R,{pi:0});for(let s=0;s<L;s+=10){const q=rpAt(R.G,s,0),d=rpD2(q.x,q.y,tw.x,tw.y);if(d<bd){bd=d;bs=s}}
          const f=tdFoe(R,'gloom',bs);f.hp=f.mx=1e5;tw.cd=.01;tdRun(R,3);const fired=R.gvN;const w=tdWell(R,tw,bs,0);tw.cd=1e9;tdRun(R,1);return [fired,Math.round(f.s)===bs,f.hp===1e5,w.caught.length]}""")
        chk('ground only: it never fires at a flyer, and a well neither pulls nor crushes one',r==[0,True,True,0],r)
        # ---- the pull along the road
        r=await E("""()=>{const R=tdNew('moss',3);const tw=tdEng(R,1);const s0=tdMid(R),w=tdWell(R,tw,s0,0);const a=tdFoe(R,'scamp',s0+60),b=tdFoe(R,'scamp',s0-60);a.hp=a.mx=b.hp=b.mx=1e6;
          const d0=[Math.sqrt(rpD2(rpPos(R,a).x,rpPos(R,a).y,w.x,w.y)),Math.sqrt(rpD2(rpPos(R,b).x,rpPos(R,b).y,w.x,w.y))];tdRun(R,1.2);
          const d1=[Math.sqrt(rpD2(rpPos(R,a).x,rpPos(R,a).y,w.x,w.y)),Math.sqrt(rpD2(rpPos(R,b).x,rpPos(R,b).y,w.x,w.y))];
          return [s0,Math.round(a.s),Math.round(b.s),a.pi,b.pi,d0.map(Math.round),d1.map(Math.round),Math.round(a.gvP),Math.round(b.gvP||0)]}""")
        chk('the pull moves monsters along their own road toward the well: one ahead is pulled back, one behind is pulled forward (only backward pull counts toward the cap)',
            r[1]<r[0]+60-40 and r[2]>r[0]-60+40 and abs(r[1]-r[0])<=30 and abs(r[2]-r[0])<=30 and r[3]==0 and r[4]==0 and r[6][0]<r[5][0] and r[6][1]<r[5][1] and r[7]>=30 and r[8]==0,r)
        r=await E("""()=>{const R=tdNew('wonder',3);const tw=tdEng(R,1);const P0=R.G.paths[0],P1=R.G.paths[1];if(!P1)return 'one path';
          /* a spot on path 0 that path 1 passes close to, away from where they share the road */
          let best=null;for(let i=40;i<P0.S.length;i+=5){const a=P0.S[i];let bd=1e9,bj=0;for(let j=0;j<P1.S.length;j+=2){const d=Math.hypot(P1.S[j].x-a.x,P1.S[j].y-a.y);if(d<bd){bd=d;bj=j}}if(bd>30&&bd<70){best=[i*4,bj*4,bd];break}}
          if(!best)return 'no spot';const w=tdWell(R,tw,best[0],0);const e=tdFoe(R,'scamp',tdNear(R,best[1],45,1,1),1);e.hp=e.mx=1e6;const q0=rpPos(R,e),d0=Math.sqrt(rpD2(q0.x,q0.y,w.x,w.y));tdRun(R,1);const q1=rpPos(R,e),d1=Math.sqrt(rpD2(q1.x,q1.y,w.x,w.y));
          return [e.pi,Math.round(d0),Math.round(d1),Math.round(tdNear(R,best[1],45,1,1)-e.s),Math.round(best[2])]}""")
        chk('a monster on the other road is pulled along ITS road (it stays on path 1 and gets closer to the well)',isinstance(r,list) and r[0]==1 and r[2]<r[1] and r[3]>20,r)
        r=await E("""()=>{const R=tdNew('moss',3);const tw=tdEng(R,1);const w=tdWell(R,tw,12,0);const a=tdFoe(R,'scamp',70),c=tdFoe(R,'scamp',-25);a.hp=a.mx=c.hp=c.mx=1e6;let lo=1e9;
          for(let i=0;i<75;i++){rpStep(R,1/30);lo=Math.min(lo,a.s)}return [Math.round(lo*10)/10,c.s,c.hp===c.mx]}""")
        chk('never below s = 0: a monster near the cave is pulled toward the well but never past the road start; one still in the cave is left alone',r[0]>=0 and r[1]==-25 and r[2],r)
        # ---- caps
        r=await E("""()=>{const out=[];for(const id of ['scamp','behemoth']){const R=tdNew('moss',3);const tw=tdEng(R,1);const s0=tdMid(R),s1=tdNear(R,s0,72,1);const e=tdFoe(R,id,s1);e.hp=e.mx=1e9;e.armor=0;let moved=[];
           for(let k=0;k<8;k++){e.s=s1;e.kb=0;const w=tdWell(R,tw,s0,0);const a=e.s;tdRun(R,2.6);moved.push(Math.round(a-e.s))}out.push([Math.round(e.gvP||0),moved])}return out}""")
        chk('the backward pull is capped over a monster\'s life (260 px, bosses 120): later wells crush it but no longer move it',
            r[0][0]==260 and r[1][0]==120 and abs(sum(r[0][1])-260)<=3 and abs(sum(r[1][1])-120)<=3 and r[0][1][-1]==0 and r[1][1][-1]==0,r)
        r=await E("""()=>{const res=[];for(const id of ['scamp','behemoth']){const R=tdNew('moss',3);const tw=tdEng(R,1);const s0=tdMid(R);tdWell(R,tw,s0,0);const e=tdFoe(R,id,tdNear(R,s0,78,1));e.hp=e.mx=1e9;const a=e.s;tdRun(R,.3);res.push(+(a-e.s).toFixed(1))}return [res,RP_TW.grav.pull[0]]}""")
        chk('bosses are pulled half as hard',abs(r[0][0]-r[1]*0.3)<4 and abs(r[0][1]*2-r[0][0])<3,r)
        r=await E("""()=>{const R=tdNew('moss',3);const tw=tdEng(R,1);const s0=tdMid(R);tdWell(R,tw,s0,0);const a=tdFoe(R,'scamp',tdNear(R,s0,78,1)),b=tdFoe(R,'scamp',tdNear(R,s0,78,-1));a.hp=a.mx=b.hp=b.mx=1e9;
          const a0=a.s,b0=b.s;tdRun(R,.3);return [+(a0-a.s).toFixed(1),+(b.s-b0).toFixed(1),RPGV.fwd]}""")
        chk('a well delays more than it hurries: the tail of a group is drawn forward gently (60% of the pull back on the head)',r[0]>20 and abs(r[1]-r[0]*r[2])<3,r)
        # ---- crush and the crowd
        r=await E("""()=>{const run=n=>{const R=tdNew('moss',3);const tw=tdEng(R,1);const s0=tdMid(R);tdWell(R,tw,s0,0);const fs=[];for(let k=0;k<n;k++){const e=tdFoe(R,'scamp',s0-20+k*8);e.hp=e.mx=1e6;e.armor=0;fs.push(e)}tdRun(R,1);return 1e6-fs[0].hp};
          return [run(1),run(3),run(6),run(9),RP_TW.grav.dmg[0]]}""")
        chk('crush: about 24 per second alone, x1.5 with three caught, x2 with six, never more than x2',abs(r[0]-r[4])<2 and abs(r[1]/r[0]-1.5)<.05 and abs(r[2]/r[0]-2)<.05 and abs(r[3]/r[0]-2)<.05,r)
        r=await E("""()=>{const R=tdNew('moss',3);const tw=tdEng(R,1);const s0=tdMid(R);tdWell(R,tw,s0,0);const a=tdFoe(R,'scamp',s0),b=tdFoe(R,'golem',s0+6);a.hp=a.mx=b.hp=b.mx=1e6;a.armor=0;b.armor=12;tdRun(R,1);
          return [Math.round(1e6-a.hp),Math.round(1e6-b.hp),a.fl<=0.0001]}""")
        chk('armor softens the crush (at most by half) and the crush does not flash monsters every tick',r[1]<r[0] and r[1]>=r[0]*.5-1 and r[2],r)
        # ---- tier 3, 4, 5
        r=await E("""()=>{const out=[];for(const t of [2,3]){const R=tdNew('wonder',20);const tw=tdEng(R,t);const s0=tdMid(R);tdWell(R,tw,s0,0);const a=tdFoe(R,'scamp',s0+5),b=tdFoe(R,'scamp',s0-5);a.hp=a.mx=b.hp=b.mx=1e6;
           tdRun(R,.5);b.s=s0+400;tdRun(R,.1);const left=[b.slowK,+b.slowT.toFixed(1)];tdRun(R,2.2);out.push([left,[a.slowK,+a.slowT.toFixed(1)]])}return out}""")
        chk('tier 3 tidal lock: a monster leaving a well and one caught when it closes are slowed 30% for about 2 s (not at tier 2)',
            r[0][0][0]==0 and r[0][1][0]==0 and r[1][0][0]==0.3 and r[1][0][1]>=1.8 and r[1][1][0]==0.3 and r[1][1][1]>=1.6,r)
        r=await E("""()=>{const R=tdNew('wonder',20);const tw=tdEng(R,4);const s0=tdMid(R);const w=tdWell(R,tw,s0,0);const a=tdFoe(R,'golem',s0),B=tdFoe(R,'behemoth',s0+10),c=tdFoe(R,'golem',s0-8);
          a.hp=a.mx*.07;B.hp=B.mx*.05;c.hp=c.mx*.5;tdRun(R,.1);const r1=[a.dead?1:0,B.dead?1:0,c.dead?1:0,R.gvFin,w.d];
          const R3=tdNew('wonder',20);const t3=tdEng(R3,3);const w3=tdWell(R3,t3,s0,0);const d=tdFoe(R3,'golem',s0);d.hp=d.mx*.07;tdRun(R3,.1);return [...r1,d.dead?1:0,w3.d]}""")
        chk('tier 4 event horizon: a well swallows a monster below 8% at once, never a boss (5% boss lives), and lasts 3.2 s (tier 3: no swallow, 2.5 s)',r==[1,0,0,1,3.2,0,2.5],r)
        r=await E("""()=>{const R=tdNew('wonder',30);const tw=tdEng(R,5);const s0=tdMid(R);const w=tdWell(R,tw,s0,0,true);const c=rpAt(R.G,s0,0);
          /* a flyer and ground monsters around the well, one far away */
          const fs=[];const L=rpLen(R,{pi:0});const at=d=>{let best=0,bd=1e9;for(let s=0;s<L;s+=4){const q=rpAt(R.G,s,0),dd=Math.abs(Math.sqrt(rpD2(q.x,q.y,c.x,c.y))-d);if(dd<bd&&s>s0){bd=dd;best=s}}return best};
          const g=tdFoe(R,'golem',at(125)),f=tdFoe(R,'gloom',at(90)),far=tdFoe(R,'golem',at(230));for(const e of [g,f,far]){e.hp=e.mx=1e6;e.armor=0}
          tdRun(R,w.d+.1);return [R.gvNovaN,Math.round(1e6-g.hp),Math.round(1e6-f.hp),Math.round(1e6-far.hp),RP_TW.grav.novaD[4],R.gvFx.some(x=>x.kind==='nova')]}""")
        chk('tier 5 collapse: a nova well implodes when it closes and hits everything within 140 px, flyers too (about 520), not a monster farther away',
            r[0]==1 and 500<=r[1]<=540 and 500<=r[2]<=540 and r[3]==0 and r[5],r)
        r=await E("""()=>{const R=tdNew('wonder',30);const tw=tdBuild(R,R.pads[0],'grav',5);const L=rpLen(R,{pi:0});const fl=[];
          for(let s=0;s<L;s+=30){const e=tdFoe(R,'golem',s);e.hp=e.mx=1e8}for(let k=0;k<8;k++){tw.cd=.01;rpStep(R,1/30);if(R.gvOrbs.length)fl.push(R.gvOrbs[R.gvOrbs.length-1].nova?1:0);tdRun(R,1.2)}return [fl,tw.nv]}""")
        chk('every fourth orb of a tier 5 Engine is a collapse orb',r[0][:8]==[0,0,0,1,0,0,0,1],r)
        # ---- Overcharge
        r=await E("""()=>{const R=tdNew('moss',3);const tw=tdEng(R,1);tw.cd=3;rpStep(R,.1);const n=+(3-tw.cd).toFixed(3);tw.cd=3;tw.over=5;rpStep(R,.1);const o=+(3-tw.cd).toFixed(3);
          const s0=tdMid(R);tw.cd=1e9;tw.over=0;tdWell(R,tw,s0,0);const a=tdFoe(R,'scamp',s0);a.hp=a.mx=1e6;a.armor=0;tdRun(R,1);const d0=1e6-a.hp;
          const R2=tdNew('moss',3);const t2=tdEng(R2,1);tdWell(R2,t2,s0,0);t2.over=60;const b=tdFoe(R2,'scamp',s0);b.hp=b.mx=1e6;b.armor=0;tdRun(R2,1);const d1=1e6-b.hp;return [n,o,RPT.AB.over.k,+(d1/d0).toFixed(3)]}""")
        chk('Overcharge: the reload runs 2.4x faster and the crush hits 15% harder',abs(r[1]/r[0]-r[2])<.05 and abs(r[3]-1.15)<.01,r)
        # ---- the Starfall mark and the Tidecaller
        r=await E("""()=>{const R=tdNew('moss',3);const tw=tdEng(R,1);const s0=tdMid(R);tdWell(R,tw,s0,0);const a=tdFoe(R,'scamp',s0),b=tdFoe(R,'scamp',s0+4);a.hp=a.mx=b.hp=b.mx=1e6;a.armor=b.armor=0;b.mk=99;b.mkK=.2;tdRun(R,1);return +((1e6-b.hp)/(1e6-a.hp)).toFixed(3)}""")
        chk('a Starfall mark makes the crush hit harder (rpHurt bonuses apply)',abs(r-1.2)<.01,r)
        r=await E("""()=>{const R=tdNew('moss',3);const tw=tdEng(R,1);const s0=tdMid(R);tdWell(R,tw,s0,0);const s1=tdNear(R,s0,70,1),a=tdFoe(R,'scamp',s1),b=tdFoe(R,'scamp',s1),c=tdFoe(R,'scamp',s1);for(const e of [a,b,c]){e.hp=e.mx=1e6}
          a.kb=60;a.kbV=1e-6;c.tdP=RPTC.cap;const a0=a.s,b0=b.s,c0=c.s;rpStep(R,1/30);rpStep(R,1/30);return [+(a0-a.s).toFixed(2),+(b0-b.s).toFixed(2),+(c0-c.s).toFixed(2),+(b.tdP||0).toFixed(2),+(b.gvP||0).toFixed(2)]}""")
        chk('with the Tidecaller: a monster sliding from a wave is left to the wave, well pull adds to the shared push-back budget, and a monster at the Tidecaller cap is not pulled back',
            r[0]<0.01 and r[1]>3 and r[2]==0 and abs(r[3]-r[1])<.1 and r[4]==r[1],r)
        r=await E("""()=>{const R=tdNew('wonder',30);const L=rpLen(R,{pi:0});const sc=p=>{let n=0;for(let s=0;s<L;s+=10){const q=rpAt(R.G,s,0);if(rpD2(q.x,q.y,p.x,p.y)<250*250)n++}return n};
          const pads=[...R.pads].sort((a,b)=>sc(b)-sc(a));const g1=tdBuild(R,pads[0],'grav',5),t1=tdBuild(R,pads[1],'tide',5),g2=tdBuild(R,pads[2],'grav',5),t2=tdBuild(R,pads[3],'tide',5);
          const fs=[];for(let k=0;k<8;k++){const e=rpSpawn(k%3?'golem':'bulwark',0);e.s=10+k*30;e.hp=e.mx=1e12;fs.push(e)}let t=0,nan=0,maxBack=0;const prev=new Map(fs.map(e=>[e,e.s]));let backTot=new Map(fs.map(e=>[e,0]));
          while(fs.some(e=>!e.dead)&&t<300){rpStep(R,1/30);t+=1/30;for(const e of fs){if(!isFinite(e.s))nan++;const d=prev.get(e)-e.s;if(d>0)backTot.set(e,backTot.get(e)+d);prev.set(e,e.s)}}
          return [Math.round(t),fs.filter(e=>e.leak).length,nan,Math.round(Math.max(...[...backTot.values()])),R.gvN,fs.map(e=>Math.round(e.gvP||0))]}""")
        chk('two Engines and two Tidecallers at tier 5 never hold a stream of unkillable monsters for good: all of them reach the castle, no NaN',r[1]==8 and r[2]==0 and r[0]<300 and r[4]>5 and max(r[5])<=260,r)
        # ---- 97k layer, shot origin
        r=await E("""()=>{const R=tdNew('moss',3);const tw=tdBuild(R,R.pads[3],'grav',2);const L=rpLen(R,{pi:0});let bs=0,bd=1e9;for(let s=0;s<L;s+=10){const q=rpAt(R.G,s,0),d=Math.abs(Math.sqrt(rpD2(q.x,q.y,tw.x,tw.y))-170);if(d<bd){bd=d;bs=s}}
          const e=tdFoe(R,'golem',bs);e.hp=e.mx=1e6;tw.cd=.01;rpStep(R,1/30);const o=R.gvOrbs[0],c=rpgvCore(2,0);
          return [!!o,o&&Math.round(o.x0-tw.x),o&&Math.round(o.y0-tw.y),Math.round(c.y*RPG.k),Array.isArray(RPG_SRC.grav[5]),RPG_PAR.grav.n[5],RPG_ARR.includes('gvOrbs')]}""")
        chk('97k: orbs leave from the core of the scaled art; the Engine has glow sources and particles in the 9.9p layer',r[0] and r[1]==0 and r[2]==r[3] and r[4] and r[5]>0 and r[6],r)
        # ---- art
        r=await E("""()=>{const out=[];for(let t=1;t<=5;t++){const c=document.createElement('canvas');c.width=c.height=240;const g=c.getContext('2d');g.translate(120,190);rpTowerDraw(g,'grav',t,'base',1,{aim:.5,charge:.4});
           const d=g.getImageData(0,0,240,240).data;let n=0,top=240;for(let i=3;i<d.length;i+=4)if(d[i]>20){n++;top=Math.min(top,Math.floor((i>>2)/240))}out.push([n,top,c.toDataURL().length])}
          const ic=rpTowerIcon('grav',1,'base',96),id=ic.getContext('2d').getImageData(0,0,96,96).data;let icn=0;for(let i=3;i<id.length;i+=4)if(id[i]>20)icn++;
          return [out.map(x=>x[0]),out.map(x=>x[1]),new Set(out.map(x=>x[2])).size,ic.width,icn]}""")
        chk('each tier draws differently, taller and fuller than the one before (tier 3 adds the arch, 4-5 ascend); the icon renders',r[2]==5 and r[0][1]>r[0][0] and r[0][2]>r[0][1] and r[0][4]>r[0][2] and r[1][0]>r[1][2]>r[1][4] and r[3]==96 and r[4]>1500,r)
        r=await E("""()=>{const c=document.createElement('canvas');c.width=200;c.height=200;const g=c.getContext('2d');const f=t=>{g.clearRect(0,0,200,200);g.save();g.translate(100,170);rpTowerDraw(g,'grav',3,'base',t,{aim:0,charge:0,ph:0});g.restore();return c.toDataURL()};
          const a=f(1),b=f(1.4);g.clearRect(0,0,200,200);g.save();g.translate(100,170);rpTowerDraw(g,'grav',3,'base',1,{aim:2,charge:1,ph:0});g.restore();const ch=c.toDataURL();
          g.clearRect(0,0,200,200);g.save();g.translate(100,170);rpTowerDraw(g,'grav',3,'base',1,{aim:0,charge:0,fire:1,ph:0});g.restore();return [a!==b,ch!==a,c.toDataURL()!==a]}""")
        chk('the tower is alive: rings and disk turn with time, charging changes the look (spin, glow, motes), firing flashes',r==[True,True,True],r)
        r=await E("""()=>{if(typeof RPG!=='undefined')RPG.off=1;const c=document.createElement('canvas');c.width=1600;c.height=900;const g=c.getContext('2d');for(const ty of ['grav','star'])for(let t=1;t<=5;t++)rpTowerWarm(ty,t,'base');
          RPFX.lite=false;const run=ty=>{for(let t=1;t<=5;t++){g.save();g.translate(100+t*200,400);rpTowerDraw(g,ty,t,'base',.5,{aim:.3,charge:.5});g.restore()}g.getImageData(0,0,1,1);
           const t0=performance.now();for(let f=0;f<40;f++)for(let t=1;t<=5;t++){g.save();g.translate(100+t*200,400);rpTowerDraw(g,ty,t,'base',f/30,{aim:f/20,charge:(f%30)/30,fire:f%20<5?.8:0});g.restore()}g.getImageData(0,0,1,1);return (performance.now()-t0)/200};
          const a=[],b=[];for(let k=0;k<5;k++){a.push(run('grav'));b.push(run('star'))}a.sort((x,y)=>x-y);b.sort((x,y)=>x-y);
          const cnt=ty=>{let n=0;const keep={};for(const m of ['drawImage','stroke','fill']){keep[m]=g[m];g[m]=function(){n++;return keep[m].apply(this,arguments)}}for(let t=1;t<=5;t++){g.save();g.translate(400,400);rpTowerDraw(g,ty,t,'base',1.3,{aim:.3,charge:.5,fire:.3});g.restore()}for(const m in keep)delete g[m];return n};
          const n=[cnt('grav'),cnt('star')];if(typeof RPG!=='undefined')RPG.off=0;return [+a[2].toFixed(3),+b[2].toFixed(3),n]}""")
        chk('frame cost: one Engine (any tier, charging and firing) costs about what a Starfall Observatory does: as many draw calls give or take a quarter, time (raster included, median of 5) within 2x',r[0]<=max(0.5,r[1]*2) and r[2][0]<=r[2][1]*1.25,r)
        r=await E("""()=>{const R=tdNew('wonder',30);const tw=tdEng(R,5);const L=rpLen(R,{pi:0});for(let k=0;k<3;k++)tdWell(R,tw,Math.round(L*(.25+k*.2)),0,k===2);for(let k=0;k<30;k++){const e=tdFoe(R,k%2?'scamp':'golem',Math.round(L*(.22+(k%3)*.2))+(k%10)*6);e.hp=e.mx=1e9}
          tdRun(R,.5);R.lite=0;RPFX.lite=false;/* a slow test machine may have switched the battle to lite */const c=document.createElement('canvas');c.width=1600;c.height=900;const g=c.getContext('2d');
          const lay=()=>{for(const w of R.gvWells){rpgvWell(g,w.x,w.y,w.r,w.k,R.t,w.tier,w.seed);if(!RPFX.lite){let n=0;for(const e of w.caught){if(n++>=RPGV.teth)break;const q=rpPos(R,e);rpgvTether(g,q.x,q.y-4,w.x,w.y,R.t,.75,w.tier)}}rpgvWellTop(g,w.x,w.y,w.r,w.k,R.t,w.tier,w.seed)}rpgvNova(g,800,450,140,.3,5);rpgvOrbDraw(g,700,300,5,R.t,1.25)};
          const base=()=>{for(let k=0;k<3;k++)rpMortarBoom(g,400+k*300,450,110,.3,5,0)};
          const T=f=>{f();g.getImageData(0,0,1,1);const t0=performance.now();for(let i=0;i<40;i++){R.t+=1/60;f()}g.getImageData(0,0,1,1);return (performance.now()-t0)/40};
          const A=[],B=[];for(let k=0;k<5;k++){A.push(T(lay));B.push(T(base))}[A,B].forEach(x=>x.sort((p,q)=>p-q));
          const cnt=()=>{let n=0;const keep={};for(const m of ['drawImage','stroke','fill']){keep[m]=g[m];g[m]=function(){n++;return keep[m].apply(this,arguments)}}lay();for(const m in keep)g[m]=keep[m];return n};const nF=cnt();RPFX.lite=true;const nL=cnt();RPFX.lite=false;
          return [+A[2].toFixed(3),[nF,nL],+B[2].toFixed(3),R.gvWells.length,R.gvWells.reduce((a,w)=>a+w.caught.length,0)]}""")
        chk('frame cost: three wells holding 30 monsters, a nova and an orb cost at most a little more than three Thunder Mortar blasts (raster included, a slow machine: within 2.5x); Performance mode draws a quarter fewer things or less',r[0]<=max(1.2,r[2]*2.5) and r[1][1]<r[1][0]*.75 and r[3]==3 and r[4]>=20,r)
        # ---- info panel
        r=await E("""async()=>{const R=tdNew('wonder',10);const tw=tdBuild(R,R.pads[0],'grav',5);tdFoe(R,'golem',300);R.sel=tw;await new Promise(r=>setTimeout(r,400));const el=document.getElementById('rpinfo');const t=el?el.textContent:'';
          const b=el.getBoundingClientRect();return [/Crush/.test(t),/Pull/.test(t),/pulls along the road/.test(t),/collapse every/.test(t),/swallows below/.test(t),/tidal lock/.test(t),b.top>=0&&b.bottom<=900]}""")
        chk('its info panel shows crush, pull, the well and the tier 3-5 powers, on screen',all(r),r)
        # ---- bar and ring
        r=await E("""async()=>{try{rpLeave()}catch(e){}rpStart('moss');const R=RPX;R.tut=null;await new Promise(r=>setTimeout(r,800));const cs=[...document.querySelectorAll('.rpbar .rpcard')].map(c=>c.getBoundingClientRect());
          const ov=cs.some((a,i)=>i&&a.left<cs[i-1].right-1);const bar=document.querySelector('.rpbar').getBoundingClientRect();
          /* the ring on the pad nearest the left edge */
          const p=[...R.pads].sort((a,b)=>a.x-b.x)[0];R.selPad=p;await new Promise(r=>setTimeout(r,400));const rb=[...document.querySelectorAll('#rpring .rprb')].map(b=>b.getBoundingClientRect());
          const cv=document.querySelector('canvas').getBoundingClientRect();
          return [cs.length,ov,Math.round(cs[0].left),Math.round(cs[cs.length-1].right),Math.round(bar.right),rb.length,rb.every(b=>b.left>=cv.left-2&&b.right<=cv.right+2)]}""")
        chk('twelve cards (World 3 open) fit in the tower bar without overlapping; the build ring with twelve buttons stays on the stage',r[0]==12 and not r[1] and r[3]<=r[4]+1 and r[5]==12 and r[6],r)
        r=await E("""()=>{const R=tdNew('ember',7);R.wst='build';const L=rpLen(R,{pi:0});const sc=p=>{let n=0;for(let s=0;s<L;s+=10){const q=rpAt(R.G,s,0);if(rpD2(q.x,q.y,p.x,p.y)<230*230)n++}return n};
          const pads=[...R.pads].sort((a,b)=>sc(b)-sc(a));tdBuild(R,pads[0],'grav',3);tdBuild(R,pads[1],'grav',3);tdBuild(R,pads[2],'bell',2);tdBuild(R,pads[3],'ballista',2);
          R.cd=0;rpWaveStart();const ids=[...new Set(R.q.map(x=>x.id))];let t=0;while(R.wst==='run'&&t<300){rpStep(R,1/30);t+=1/30}return [R.wave,ids.includes('shaman'),R.wst,Math.round(t),R.gvN]}""")
        chk('the Hex Shaman wave (Ember Crown 8): two Engines piling shamans up do not stall it (the wave clears in good time)',r[1] and r[2]=='build' and r[3]<150 and r[4]>3,r)
        # ---- a full wave
        r=await E("""()=>{const R=tdNew('wonder',23);R.wst='build';const L=rpLen(R,{pi:0});const sc=p=>{let n=0;for(let s=0;s<L;s+=10){const q=rpAt(R.G,s,0);if(rpD2(q.x,q.y,p.x,p.y)<250*250)n++}return n};
          const pads=[...R.pads].sort((a,b)=>sc(b)-sc(a));tdBuild(R,pads[0],'grav',5);tdBuild(R,pads[1],'mortar',4);tdBuild(R,pads[2],'brazier',4);tdBuild(R,pads[3],'bell',4);tdBuild(R,pads[4],'dragon',4);tdBuild(R,pads[5],'grav',3);tdBuild(R,pads[6],'prism',4);
          R.hp=999;R.cd=0;rpWaveStart();let t=0;while(R.wst==='run'&&t<240){rpStep(R,1/30);t+=1/30}return [R.wst,R.wave,Math.round(t),R.gvN,R.kills,R.leaked,R.foes.filter(e=>!e.dead).length,R.gvNovaN]}""")
        chk('a full Wonderland wave (24) with two Engines in a splash build plays out cleanly: wells open, a collapse goes off, the wave clears',r[0]=='build' and r[3]>3 and r[4]>10 and r[6]==0 and r[7]>=1,r)
        r=await E("""()=>{const R=RPX;R.sel=null;rpDraw();return 1}""")
        chk('no page errors',not er,er)
        await b.close()
    print(f"\n{N[0]-len(FAIL)}/{N[0]} passed");sys.exit(1 if FAIL else 0)
asyncio.run(main())
