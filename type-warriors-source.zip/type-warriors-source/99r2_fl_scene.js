/* ===== UPDATE 10.4, HARVEST MOON RUSH: the three fields (99r2, prefix flr) =====
   The Pumpkin Patch, the Corn Maze and the Moonlit Orchard, each under a great harvest moon with leaves falling. They plug into the
   shared scene system (SCN / FAR / MID / NEAR / GRD / weather, 45_scenes2.js sceneGen), but every piece of scenery is painted once into
   a sprite (at the current render scale) and only blitted per frame; the moving parts (lantern glow, geese, leaves) are a few cheap draws. */
const FLRSC={};
/* a baked sprite: w x h logical pixels, origin ox/oy inside it; repainted only when the render scale changes */
function flrSpr(key,w,h,ox,oy,draw){const s=Math.min(2,Math.max(1,typeof RS==='number'?RS:1));let o=FLRSC[key];if(o&&o.s===s)return o;
 const c=document.createElement('canvas');c.width=Math.ceil(w*s);c.height=Math.ceil(h*s);const g=c.getContext('2d');g.setTransform(s,0,0,s,0,0);g.translate(ox,oy);g.lineJoin='round';g.lineCap='round';
 try{draw(g)}catch(e){console.error('flrSpr '+key,e)}return FLRSC[key]={c,ox,oy,w,h,s}}
const flrBlit=(c,o,x,y)=>c.drawImage(o.c,x-o.ox,y-o.oy,o.w,o.h);
/* a horizontally tiling strip, scrolled by off pixels */
function flrStrip(c,o,off,y){const w=o.w,x0=-(((off%w)+w)%w);for(let x=x0;x<W;x+=w)c.drawImage(o.c,x,y-o.oy,w,o.h)}
const flrMd=(i,n)=>((i%n)+n)%n;
const flrHill=(x,k,ph,a1,a2)=>Math.sin(x/1600*TAU*k+ph)*a1+Math.sin(x/1600*TAU*(k*3+1)+ph*2)*a2;

/* ---------- the harvest moon ---------- */
function flrMoon(c,d,t){const [x,y,r,col,gl]=d.flmoon;const o=flrSpr('moon'+d.flmoon.join(),r*7,r*7,r*3.5,r*3.5,g=>{
  const q=g.createRadialGradient(0,0,r*.7,0,0,r*3.4);q.addColorStop(0,gl+'88');q.addColorStop(.35,gl+'2a');q.addColorStop(1,gl+'00');g.fillStyle=q;g.fillRect(-r*3.5,-r*3.5,r*7,r*7);
  g.beginPath();g.arc(0,0,r,0,TAU);g.fillStyle=rgr(g,-r*.3,-r*.3,r*.1,r*1.05,shade(col,.35),shade(col,-.12));g.fill();
  g.save();g.beginPath();g.arc(0,0,r,0,TAU);g.clip();g.fillStyle=shade(col,-.3)+'55';for(const [dx,dy,rr] of[[-.34,-.22,.24],[.22,.12,.32],[-.08,.44,.17],[.42,-.36,.12],[-.5,.22,.1]]){g.beginPath();g.arc(dx*r,dy*r,rr*r,0,TAU);g.fill()}
  g.fillStyle='#ffffff22';g.beginPath();g.arc(-r*.25,-r*.3,r*.55,0,TAU);g.fill();g.restore();
  g.strokeStyle='#fff6d0aa';g.lineWidth=2;g.beginPath();g.arc(0,0,r-1,Math.PI*1.05,Math.PI*1.6);g.stroke()});
 flrBlit(c,o,x,y);
 /* a thin cloud drifting across the face and a skein of geese now and then */
 /* 10.4b: the cloud fits its sprite (its ends were cut off square), thins out toward both ends, has a moonlit upper edge, and fades
    in and out at the ends of its drift instead of jumping back across the moon */
 const cl=flrSpr('mcl2',720,64,360,32,g=>{for(let i=0;i<9;i++){const u=(i-4)/4,a=.42*(1-u*u*.75),cx=u*250,rx=95-Math.abs(u)*30,ry=8+(1-Math.abs(u))*6+(i%2)*2,cy=Math.sin(i*1.7)*5;
   g.fillStyle='#24142e'+flrA(a);g.beginPath();g.ellipse(cx,cy,rx,ry,0,0,TAU);g.fill();g.fillStyle='#ffd8a0'+flrA(a*.22);g.beginPath();g.ellipse(cx,cy-ry*.55,rx*.8,ry*.35,0,0,TAU);g.fill()}});
 {const u=((t*9)%900)/900;c.globalAlpha=.9*Math.min(1,Math.sin(u*Math.PI)*2.2);flrBlit(c,cl,x+u*900-450,y+r*.35);c.globalAlpha=1}
 const gk=flrCy(t,26);if(gk<9){const gx=W+120-gk/9*(W+400),gy=y-r*.9+gk*6;c.fillStyle='#120a1c';for(let i=0;i<7;i++){const j=i-3,bx=gx+Math.abs(j)*22,by=gy+j*11,f=Math.sin(t*9+i)*4;c.beginPath();c.moveTo(bx-7,by);c.quadraticCurveTo(bx,by-3-f,bx+9,by-1-f*1.4);c.quadraticCurveTo(bx+2,by+1,bx-7,by);c.fill()}}}

/* ---------- far layers: hills, a barn and silo; corn rows and a lookout; a farmhouse and a cider mill ---------- */
/* 10.4b: the baked strip is trimmed to its painted rows once (its top 150-200 px were empty but still blended across the full width
   every frame) */
function flrTrim(o){if(o.trim)return o;o.trim=1;try{const c=o.c,g=c.getContext('2d',{willReadFrequently:true}),d=g.getImageData(0,0,c.width,c.height).data,w=c.width;let top=0;
  scan:for(;top<c.height;top++){for(let x=3;x<w*4;x+=16)if(d[top*w*4+x]>0)break scan}top=Math.max(0,top-2);if(top<8)return o;
  const n=document.createElement('canvas');n.width=w;n.height=c.height-top;n.getContext('2d').drawImage(c,0,-top);const lt=top/o.s;o.c=n;o.h-=lt;o.oy-=lt}catch(e){}return o}
function flrHills(key,d,cols,amp,base,deco){return flrTrim(flrSpr(key,1600,520,0,520,g=>{cols.forEach((col,k)=>{g.beginPath();g.moveTo(0,0);for(let x=0;x<=1600;x+=16)g.lineTo(x,-base[k]-flrHill(x,k+1,k*1.7,amp[k],amp[k]*.3));g.lineTo(1600,0);g.closePath();g.fillStyle=col;g.fill();if(deco)deco(g,k)})}))}
const flrBarn=(g,x,y,s,col,win)=>{g.save();g.translate(x,y);g.scale(s,s);
 g.beginPath();g.moveTo(-60,0);g.lineTo(-60,-62);g.lineTo(-44,-92);g.lineTo(0,-112);g.lineTo(44,-92);g.lineTo(60,-62);g.lineTo(60,0);g.closePath();g.fillStyle=col;g.fill();g.strokeStyle=FLRO;g.lineWidth=2.4;g.stroke();
 g.strokeStyle=shade(col,.25);g.lineWidth=2;for(let i=-50;i<=50;i+=10){g.beginPath();g.moveTo(i,-2);g.lineTo(i,-60);g.stroke()}
 g.strokeStyle='#e8d8c0aa';g.lineWidth=3.4;g.beginPath();g.moveTo(-60,-62);g.lineTo(-44,-92);g.lineTo(0,-112);g.lineTo(44,-92);g.lineTo(60,-62);g.stroke();g.strokeRect(-22,-50,44,50);g.beginPath();g.moveTo(-22,-50);g.lineTo(22,0);g.moveTo(22,-50);g.lineTo(-22,0);g.stroke();
 const q=g.createRadialGradient(0,-80,2,0,-80,60);q.addColorStop(0,win+'aa');q.addColorStop(1,win+'00');g.fillStyle=q;g.fillRect(-60,-140,120,120);g.fillStyle=win;g.fillRect(-11,-92,22,20);g.strokeStyle=FLRO;g.lineWidth=1.6;g.strokeRect(-11,-92,22,20);
 /* silo */
 g.fillStyle=shade(col,-.35);g.fillRect(70,-130,40,130);g.beginPath();g.ellipse(90,-130,20,16,0,Math.PI,TAU);g.fill();g.strokeStyle=FLRO;g.lineWidth=2;g.strokeRect(70,-130,40,130);g.strokeStyle='#ffffff22';for(let y=-120;y<0;y+=14){g.beginPath();g.moveTo(70,y);g.lineTo(110,y);g.stroke()}g.restore()};
FAR.flrfarm=(c,t,d)=>{flrMoon(c,d,t);
 const o=flrHills('ffarm',d,['#2a1630','#1e1022','#140a16'],[38,30,22],[150,108,70],(g,k)=>{if(k===0){flrBarn(g,420,-150-flrHill(420,1,0,38,11.4),.9,'#4a1a1e','#ffc860');flrBarn(g,1260,-150-flrHill(1260,1,0,38,11.4),.62,'#3a1622','#ffb850')}
  if(k===1)for(let i=0;i<9;i++){const x=80+i*180,y=-108-flrHill(x,2,1.7,30,9),r=16+(i%3)*5;g.fillStyle='#1a0c1c';g.fillRect(x-2.5,y-r-10,5,r+12);g.beginPath();g.arc(x,y-r-14,r,0,TAU);g.arc(x-r*.7,y-r-6,r*.7,0,TAU);g.arc(x+r*.7,y-r-6,r*.7,0,TAU);g.fill();g.fillStyle='#5a1e1a55';g.beginPath();g.arc(x-r*.3,y-r-20,r*.5,0,TAU);g.fill()}});
 flrStrip(c,o,t*4,GY+8)};
FAR.flrcornf=(c,t,d)=>{flrMoon(c,d,t);
 const o=flrHills('fcorn',d,['#241a34','#1a1226','#120c1a'],[22,18,12],[150,100,64],(g,k)=>{const n=k===2?90:k===1?70:0;for(let i=0;i<n;i++){const x=i*1600/n,y=-[150,100,64][k]-flrHill(x,k+1,k*1.7,[22,18,12][k],[22,18,12][k]*.3),h=k===2?34:24;g.strokeStyle=k===2?'#0e0a14':'#160f20';g.lineWidth=k===2?3:2;g.beginPath();g.moveTo(x,y+4);g.lineTo(x+2,y-h);g.stroke();g.beginPath();g.moveTo(x+2,y-h*.6);g.lineTo(x+10,y-h*.75);g.moveTo(x+1,y-h*.4);g.lineTo(x-8,y-h*.5);g.stroke();g.fillStyle='#3a2a1a';g.fillRect(x,y-h-5,3,6)}
  if(k===0){const x=980,y=-150-flrHill(980,1,0,22,6.6);g.strokeStyle='#120a18';g.lineWidth=5;g.beginPath();g.moveTo(x-30,y);g.lineTo(x-16,y-120);g.moveTo(x+30,y);g.lineTo(x+16,y-120);g.moveTo(x-26,y-30);g.lineTo(x+26,y-70);g.moveTo(x+26,y-30);g.lineTo(x-26,y-70);g.stroke();g.fillStyle='#160c1c';g.beginPath();g.moveTo(x-34,y-118);g.lineTo(0+x,y-150);g.lineTo(x+34,y-118);g.closePath();g.fill();g.fillRect(x-24,y-122,48,10);
   const q=g.createRadialGradient(x,y-130,2,x,y-130,40);q.addColorStop(0,'#ffd06088');q.addColorStop(1,'#ffd06000');g.fillStyle=q;g.fillRect(x-40,y-170,80,80);g.fillStyle='#ffd878';g.fillRect(x-4,y-134,8,8);
   const wx=320,wy=-150-flrHill(320,1,0,22,6.6);g.fillStyle='#140a1a';g.beginPath();g.moveTo(wx-16,wy);g.lineTo(wx-7,wy-110);g.lineTo(wx+7,wy-110);g.lineTo(wx+16,wy);g.fill();g.strokeStyle='#140a1a';g.lineWidth=5;for(let i=0;i<4;i++){const a=i*Math.PI/2+.4;g.beginPath();g.moveTo(wx,wy-108);g.lineTo(wx+Math.cos(a)*56,wy-108+Math.sin(a)*56);g.stroke()}}});
 flrStrip(c,o,t*4,GY+8)};
FAR.flrhouse=(c,t,d)=>{flrMoon(c,d,t);
 const o=flrHills('fhouse',d,['#2a1426','#1e0e1c','#140812'],[34,26,18],[150,104,66],(g,k)=>{if(k===0){const x=640,y=-150-flrHill(640,1,0,34,10.2);g.fillStyle='#24101e';g.fillRect(x-70,y-74,140,74);g.beginPath();g.moveTo(x-84,y-72);g.lineTo(x,y-130);g.lineTo(x+84,y-72);g.closePath();g.fill();g.fillRect(x+30,y-138,16,40);g.strokeStyle=FLRO;g.lineWidth=2;g.strokeRect(x-70,y-74,140,74);
   for(const [wx,wy] of[[-46,-56],[-14,-56],[30,-56],[0,-104]]){const q=g.createRadialGradient(x+wx+6,y+wy+8,1,x+wx+6,y+wy+8,30);q.addColorStop(0,'#ffc86099');q.addColorStop(1,'#ffc86000');g.fillStyle=q;g.fillRect(x+wx-24,y+wy-22,60,60);g.fillStyle='#ffd27a';g.fillRect(x+wx,y+wy,12,16);g.strokeStyle='#24101e';g.lineWidth=2;g.beginPath();g.moveTo(x+wx+6,y+wy);g.lineTo(x+wx+6,y+wy+16);g.moveTo(x+wx,y+wy+8);g.lineTo(x+wx+12,y+wy+8);g.stroke()}
   const mx=1300,my=-150-flrHill(1300,1,0,34,10.2);g.fillStyle='#200c1a';g.fillRect(mx-40,my-90,80,90);g.beginPath();g.moveTo(mx-50,my-88);g.lineTo(mx,my-126);g.lineTo(mx+50,my-88);g.closePath();g.fill();g.strokeStyle='#200c1a';g.lineWidth=6;g.beginPath();g.arc(mx+56,my-36,34,0,TAU);g.stroke();g.lineWidth=3;for(let i=0;i<8;i++){const a=i*Math.PI/4;g.beginPath();g.moveTo(mx+56,my-36);g.lineTo(mx+56+Math.cos(a)*34,my-36+Math.sin(a)*34);g.stroke()}}
  if(k===1)for(let i=0;i<12;i++){const x=60+i*134,y=-104-flrHill(x,2,1.7,26,7.8);g.fillStyle='#180a16';g.fillRect(x-3,y-26,6,28);g.beginPath();g.ellipse(x,y-40,26,22,0,0,TAU);g.fill();g.fillStyle='#4a121a';for(let j=0;j<4;j++){g.beginPath();g.arc(x-14+j*9,y-38+(j%2)*8,2.6,0,TAU);g.fill()}}});
 flrStrip(c,o,t*4,GY+8)};

/* ---------- mid scenery ---------- */
const flrPump=(g,x,y,r,col)=>{col=col||'#f08a2a';g.save();g.translate(x,y);for(const [dx,rx,k] of[[-r*.55,r*.6,-.28],[r*.55,r*.6,-.2],[-r*.25,r*.75,-.1],[r*.25,r*.75,-.05]]){g.beginPath();g.ellipse(dx,-r*.78,rx,r*.78,0,0,TAU);g.fillStyle=shade(col,k);g.fill();g.strokeStyle=FLRO;g.lineWidth=Math.max(1.2,r*.07);g.stroke()}
 g.beginPath();g.ellipse(0,-r*.78,r*.5,r*.8,0,0,TAU);g.fillStyle=rgr(g,-r*.2,-r,r*.1,r,shade(col,.3),col);g.fill();g.strokeStyle=FLRO;g.lineWidth=Math.max(1.2,r*.07);g.stroke();
 g.fillStyle='#ffffff26';g.beginPath();g.ellipse(-r*.2,-r*1.15,r*.18,r*.1,-.3,0,TAU);g.fill();
 g.strokeStyle='#4a5a1e';g.lineWidth=Math.max(2,r*.16);g.beginPath();g.moveTo(0,-r*1.48);g.quadraticCurveTo(r*.06,-r*1.8,r*.22,-r*1.86);g.stroke();g.restore()};
const flrPLeaf=(g,x,y,s,rot,col)=>{g.save();g.translate(x,y);g.rotate(rot);g.scale(s,s);g.beginPath();g.moveTo(0,0);for(let i=0;i<=8;i++){const a=-Math.PI*.95+i/8*Math.PI*.9,rr=i%2?20:13;g.lineTo(Math.cos(a)*rr,Math.sin(a)*rr+4)}g.closePath();g.fillStyle=col||'#2e5222';g.fill();g.strokeStyle=FLRO;g.lineWidth=1.4;g.stroke();g.strokeStyle='#5a8a3a88';g.lineWidth=1;g.beginPath();for(let i=0;i<3;i++){const a=-Math.PI*.8+i*Math.PI*.3;g.moveTo(0,4);g.lineTo(Math.cos(a)*14,Math.sin(a)*14+4)}g.stroke();g.restore()};
MID.flrfence=(c,x,i,d)=>{const o=flrSpr('fence',380,120,190,110,g=>{const col='#3a2418';for(const y of[-70,-38]){g.save();g.translate(0,y);g.rotate(-.02);g.fillStyle=col;g.fillRect(-190,-6,380,11);g.strokeStyle=FLRO;g.lineWidth=2;g.strokeRect(-190,-6,380,11);g.fillStyle='#ffffff14';g.fillRect(-188,-5,376,3);g.restore()}
  for(const px of[-170,-56,58,172]){g.fillStyle='#2e1c12';g.fillRect(px-7,-96,14,98);g.strokeStyle=FLRO;g.lineWidth=2;g.strokeRect(px-7,-96,14,98)}flrPump(g,-110,2,16,'#e07a26');flrPLeaf(g,-80,0,.9,-.3);flrPump(g,110,2,12,'#d86a20')});flrBlit(c,o,x,GY+4)};
MID.flrhay=(c,x,i,d)=>{const o=flrSpr('hay'+flrMd(i,2),240,170,120,160,g=>{const bale=(bx,by,w,h)=>{g.fillStyle=vgr(g,by-h,by,'#c89a3a','#8a6420');g.fillRect(bx-w/2,by-h,w,h);g.strokeStyle=FLRO;g.lineWidth=2;g.strokeRect(bx-w/2,by-h,w,h);g.strokeStyle='#e8c35a88';g.lineWidth=1.2;for(let k=0;k<8;k++){g.beginPath();g.moveTo(bx-w/2+4+k*w/8,by-h+3);g.lineTo(bx-w/2+8+k*w/8,by-3);g.stroke()}g.strokeStyle='#5a3a1a';g.lineWidth=2.4;for(const f of[.3,.7]){g.beginPath();g.moveTo(bx-w/2+w*f,by-h);g.lineTo(bx-w/2+w*f,by);g.stroke()}};
  bale(-50,0,96,46);bale(50,0,96,46);bale(0,-46,96,46);if(flrMd(i,2))flrPump(g,0,-92,22,'#f08a2a');else{flrPump(g,-12,-92,16,'#e8d8b0');flrPump(g,16,-92,12,'#f0a030')}});flrBlit(c,o,x,GY+4)};
MID.flrscarep=(c,x,i,d,t)=>{const o=flrSpr('scp',150,240,75,232,g=>{g.save();g.scale(1.25,1.25);try{FLRD.flrscare(g,0.62,{lg:0})}catch(e){}g.restore()});c.save();c.translate(x,GY+2);c.rotate(Math.sin(t*.9+i)*.02);c.globalAlpha=.92;flrBlit(c,o,0,0);c.restore()};
MID.flrcart=(c,x,i,d)=>{const o=flrSpr('cart',260,170,130,160,g=>{g.fillStyle='#4a2a16';g.fillRect(-100,-74,180,40);g.strokeStyle=FLRO;g.lineWidth=2.4;g.strokeRect(-100,-74,180,40);g.strokeStyle='#6a4226';g.lineWidth=2;for(let k=1;k<6;k++){g.beginPath();g.moveTo(-100+k*30,-74);g.lineTo(-100+k*30,-34);g.stroke()}
  for(const [px,r,col] of[[-70,22,'#f08a2a'],[-30,26,'#e87a22'],[12,20,'#f0a030'],[48,22,'#e8d8b0'],[-50,16,'#d86a20'],[30,15,'#f08a2a']])flrPump(g,px,-70-(r<18?30:0),r,col);
  for(const wx of[-60,40]){g.beginPath();g.arc(wx,-30,28,0,TAU);g.strokeStyle=FLRO;g.lineWidth=8;g.stroke();g.strokeStyle='#6a4226';g.lineWidth=5;g.stroke();g.lineWidth=3;for(let k=0;k<6;k++){const a=k*Math.PI/3;g.beginPath();g.moveTo(wx,-30);g.lineTo(wx+Math.cos(a)*26,-30+Math.sin(a)*26);g.stroke()}}
  g.strokeStyle='#4a2a16';g.lineWidth=6;g.beginPath();g.moveTo(80,-50);g.lineTo(126,-36);g.stroke()});flrBlit(c,o,x,GY+6)};
MID.flrcornwall=(c,x,i,d,t)=>{const o=flrSpr('cwall'+flrMd(i,3),440,260,220,252,g=>{for(let r=0;r<2;r++)for(let k=0;k<20;k++){if(rnd(k*13+i)<.12)continue;const sx=-200+k*21+r*10+rnd(k*7+i+r)*8,h=150+rnd(k+i*3+r)*60-r*20,col=r?'#34361a':'#2a2c14',lean=(rnd(k+r*5)-.5)*.1;g.save();g.translate(sx,0);g.rotate(lean);
   g.strokeStyle=FLRO;g.lineWidth=6;g.beginPath();g.moveTo(0,4);g.lineTo(0,-h);g.stroke();g.strokeStyle=col;g.lineWidth=4;g.stroke();
   for(let L=0;L<4;L++){const ly=-40-L*h/5,s=L%2?1:-1;g.beginPath();g.moveTo(0,ly);g.quadraticCurveTo(s*24,ly-18,s*40,ly+6);g.quadraticCurveTo(s*22,ly-6,0,ly+5);g.closePath();g.fillStyle=L%2?'#3e3e1c':'#4a4620';g.fill();g.strokeStyle=FLRO;g.lineWidth=1;g.stroke()}
   if(k%3===0){g.save();g.translate(3,-h*.55);g.rotate(.5);g.beginPath();g.ellipse(0,0,5,13,0,0,TAU);g.fillStyle='#a8883a';g.fill();g.strokeStyle=FLRO;g.lineWidth=1.2;g.stroke();g.fillStyle='#7a7448';g.beginPath();g.moveTo(-5,6);g.quadraticCurveTo(-8,-6,0,-15);g.quadraticCurveTo(-2,-2,2,8);g.fill();g.restore()}
   g.strokeStyle='#a88a44';g.lineWidth=1.6;g.beginPath();g.moveTo(0,-h);g.lineTo(-6,-h-14);g.moveTo(0,-h);g.lineTo(5,-h-16);g.moveTo(0,-h);g.lineTo(0,-h-18);g.stroke();g.restore()}});
 c.save();c.translate(x,GY+4);c.transform(1,0,Math.sin(ctxT*1.1+i)*.025,1,0,0);flrBlit(c,o,0,0);c.restore()};
MID.flrsign=(c,x,i,d)=>{const o=flrSpr('sign'+flrMd(i,2),200,190,100,182,g=>{g.fillStyle='#4a2e1a';g.fillRect(-6,-170,12,172);g.strokeStyle=FLRO;g.lineWidth=2;g.strokeRect(-6,-170,12,172);
  const arrow=(y,dir,txt,col)=>{g.save();g.translate(0,y);g.beginPath();g.moveTo(-dir*14,-14);g.lineTo(dir*58,-14);g.lineTo(dir*74,0);g.lineTo(dir*58,14);g.lineTo(-dir*14,14);g.closePath();g.fillStyle=col;g.fill();g.strokeStyle=FLRO;g.lineWidth=2;g.stroke();g.fillStyle='#2a1608';g.font='15px "Pirata One",Georgia,serif';g.textAlign='center';g.textBaseline='middle';g.fillText(txt,dir*30,1);g.restore()};
  if(flrMd(i,2)){arrow(-150,1,'MAZE','#c89a5a');arrow(-112,-1,'EXIT?','#a87a44')}else{arrow(-150,-1,'THIS WAY','#c89a5a');arrow(-112,1,'NO, THIS','#a87a44')}
  for(let k=0;k<6;k++){g.strokeStyle='#d8b04a';g.lineWidth=2;g.beginPath();g.moveTo(-14+k*5,2);g.lineTo(-18+k*7,-14-(k%3)*4);g.stroke()}flrPump(g,24,2,14,'#f08a2a')});flrBlit(c,o,x,GY+4)};
MID.flrlamp=(c,x,i,d,t)=>{const o=flrSpr('lamp',80,230,40,222,g=>{g.fillStyle='#3a2416';g.fillRect(-5,-200,10,202);g.strokeStyle=FLRO;g.lineWidth=2;g.strokeRect(-5,-200,10,202);g.fillRect(-5,-200,30,6);g.strokeRect(-5,-200,30,6);g.strokeStyle='#2a2a32';g.lineWidth=1.6;g.beginPath();g.moveTo(20,-194);g.lineTo(20,-182);g.stroke();
  g.fillStyle='#2a2a32';g.fillRect(10,-182,20,4);g.fillRect(10,-156,20,4);g.fillStyle='#ffc860';g.fillRect(12,-178,16,22);g.strokeStyle=FLRO;g.lineWidth=1.4;g.strokeRect(12,-178,16,22)});
 const f=.8+.2*Math.sin(t*7+i*2)+.06*Math.sin(t*19+i);glow(c,x+20,GY-160,70*f,'#ffb040'+flrA(.42*f));flrBlit(c,o,x,GY+4);c.fillStyle='#fff4c8';c.beginPath();c.ellipse(x+20,GY-163,3,5*f,0,0,TAU);c.fill()};
MID.flrtree=(c,x,i,d,t)=>{const o=flrSpr('tree'+flrMd(i,3),360,420,180,412,g=>{const v=flrMd(i,3);g.strokeStyle=FLRO;g.lineWidth=26;g.beginPath();g.moveTo(-4,4);g.quadraticCurveTo(8,-80,-6,-150);g.stroke();g.strokeStyle='#3a2416';g.lineWidth=20;g.stroke();
  g.lineWidth=9;g.strokeStyle='#3a2416';for(const [a,b,cx2,cy2] of[[-6,-130,-70,-200],[-4,-140,60,-210],[-6,-150,-10,-240]]){g.beginPath();g.moveTo(a,b);g.quadraticCurveTo((a+cx2)/2,(b+cy2)/2-20,cx2,cy2);g.stroke()}
  const can=[[-80,-230,82],[60,-236,86],[-10,-292,90],[-130,-190,56],[120,-196,58]];for(const [cx2,cy2,r] of can){g.beginPath();g.arc(cx2,cy2,r+3,0,TAU);g.fillStyle=FLRO;g.fill()}
  can.forEach(([cx2,cy2,r],k)=>{g.beginPath();g.arc(cx2,cy2,r,0,TAU);g.fillStyle=rgr(g,cx2-r*.3,cy2-r*.4,r*.2,r*1.1,['#5a4420','#6a3418','#4a4a1e'][v],['#1e1a0a','#260e08','#18180a'][v]);g.fill()});
  g.fillStyle='#ffe0a00c';for(const [cx2,cy2,r] of can){g.beginPath();g.arc(cx2-r*.25,cy2-r*.35,r*.45,0,TAU);g.fill()}
  for(let k=0;k<26;k++){const [cx2,cy2,r]=can[k%5],a=rnd(k*3+v)*TAU,rr=r*(.2+rnd(k+9+v)*.7),ax=cx2+Math.cos(a)*rr,ay=cy2+Math.sin(a)*rr;g.beginPath();g.arc(ax,ay,6,0,TAU);g.fillStyle=k%4?'#b8282a':'#c88a2a';g.fill();g.strokeStyle=FLRO;g.lineWidth=1.2;g.stroke();g.fillStyle='#ffffff55';g.beginPath();g.arc(ax-2,ay-2,1.8,0,TAU);g.fill()}
  for(let k=0;k<5;k++){const ax=-120+k*60,ay=-4+rnd(k+v)*4;g.beginPath();g.arc(ax,ay,6,0,TAU);g.fillStyle='#b82a24';g.fill();g.strokeStyle=FLRO;g.lineWidth=1.2;g.stroke()}});
 c.save();c.translate(x,GY+4);c.transform(.86,0,Math.sin(ctxT*.7+i)*.012,.86,0,0);flrBlit(c,o,0,0);c.restore()};
MID.flrladder=(c,x,i,d)=>{const o=flrSpr('ladder',200,240,100,232,g=>{g.save();g.rotate(-.18);g.strokeStyle=FLRO;g.lineWidth=9;g.beginPath();g.moveTo(-22,2);g.lineTo(-22,-210);g.moveTo(22,2);g.lineTo(22,-210);g.stroke();g.strokeStyle='#8a6a3a';g.lineWidth=6;g.stroke();g.lineWidth=5;for(let y=-20;y>-210;y-=26){g.strokeStyle=FLRO;g.lineWidth=7;g.beginPath();g.moveTo(-22,y);g.lineTo(22,y);g.stroke();g.strokeStyle='#a8844a';g.lineWidth=4;g.stroke()}g.restore();
  g.beginPath();g.moveTo(30,-50);g.lineTo(90,-50);g.lineTo(84,0);g.lineTo(36,0);g.closePath();g.fillStyle='#a8743a';g.fill();g.strokeStyle=FLRO;g.lineWidth=2;g.stroke();g.strokeStyle='#7a4e22';g.lineWidth=2;for(let k=0;k<4;k++){g.beginPath();g.moveTo(34,-40+k*11);g.lineTo(86,-40+k*11);g.stroke()}
  for(let k=0;k<6;k++){const ax=40+k*9,ay=-54-(k%2)*7;g.beginPath();g.arc(ax,ay,6.4,0,TAU);g.fillStyle=k%3?'#d8302a':'#e8b030';g.fill();g.strokeStyle=FLRO;g.lineWidth=1.2;g.stroke()}});flrBlit(c,o,x,GY+4)};
MID.flrbarrel=(c,x,i,d)=>{const o=flrSpr('barrel',260,150,130,142,g=>{const bar=(bx,by,s)=>{g.save();g.translate(bx,by);g.scale(s,s);g.beginPath();g.moveTo(-30,0);g.quadraticCurveTo(-38,-40,-30,-80);g.lineTo(30,-80);g.quadraticCurveTo(38,-40,30,0);g.closePath();g.fillStyle=hgr(g,-34,34,'#5a3418','#8a5a2e');g.fill();g.strokeStyle=FLRO;g.lineWidth=2.4;g.stroke();
   g.strokeStyle='#3a3a42';g.lineWidth=4;for(const y of[-14,-66]){g.beginPath();g.moveTo(-34,y);g.quadraticCurveTo(0,y+4,34,y);g.stroke()}g.strokeStyle='#2a160a';g.lineWidth=1.4;for(let k=-2;k<=2;k++){g.beginPath();g.moveTo(k*12,-78);g.quadraticCurveTo(k*15,-40,k*12,-2);g.stroke()}g.restore()};
  bar(-60,0,1);bar(10,0,1.1);bar(-26,-86,.9);g.fillStyle='#f0e0b0';g.font='14px "Pirata One",Georgia,serif';g.textAlign='center';g.fillText('CIDER',10,-44)});flrBlit(c,o,x,GY+4)};
/* ---------- foreground ---------- */
NEAR.flrpumpk=(c,x,i,d)=>{const v=flrMd(i,3),o=flrSpr('np'+v,300,150,150,130,g=>{g.strokeStyle='#2a4a1a';g.lineWidth=5;g.beginPath();g.moveTo(-140,10);g.bezierCurveTo(-80,-20,-20,20,40,-6);g.bezierCurveTo(80,-20,120,10,150,0);g.stroke();
  for(let k=0;k<4;k++){const lx=-120+k*80;g.strokeStyle='#4a7a2a';g.lineWidth=1.6;g.beginPath();for(let q=0;q<=12;q++){const a=q/12*TAU*1.3,r=8-q*.5;q?g.lineTo(lx+Math.cos(a)*r,-14-Math.sin(a)*r):g.moveTo(lx+r,-14)}g.stroke()}
  flrPLeaf(g,-100,-4,1.5,-.4);flrPLeaf(g,90,-6,1.3,.5,'#3a5a24');
  if(v===0){flrPump(g,-20,10,44,'#f08a2a');flrPump(g,50,10,26,'#e87a22')}else if(v===1){flrPump(g,10,10,36,'#e8d8b0');flrPump(g,-50,10,24,'#f0a030')}else{flrPump(g,0,10,52,'#e8741c');flrPLeaf(g,40,0,1.2,.2)}});flrBlit(c,o,x,GY+96+rnd(i)*22)};
NEAR.flrgourds=(c,x,i,d)=>{const o=flrSpr('ngd',200,110,100,96,g=>{const gd=(gx,gy,rx,ry,col,st,rot)=>{g.save();g.translate(gx,gy);g.rotate(rot);g.beginPath();g.ellipse(0,-ry,rx,ry,0,0,TAU);g.fillStyle=rgr(g,-rx*.3,-ry*1.3,1,ry*1.2,shade(col,.3),col);g.fill();g.strokeStyle=FLRO;g.lineWidth=1.6;g.stroke();if(st){g.strokeStyle=st;g.lineWidth=2.4;for(const k of[-.5,0,.5]){g.beginPath();g.moveTo(k*rx,-ry*1.9);g.quadraticCurveTo(k*rx*1.5,-ry,k*rx,-ry*.1);g.stroke()}}g.restore()};
  gd(-50,6,20,16,'#e8d070','#4a8a3a',-.2);gd(-10,6,14,26,'#f0a030',null,.1);gd(30,6,18,14,'#3a6a2a','#e8d070',.3);gd(62,6,12,20,'#e8e0c8',null,-.3);gd(5,-20,10,9,'#d8502a',null,0)});flrBlit(c,o,x,GY+100+rnd(i)*20)};
NEAR.flrstalk=(c,x,i,d,t)=>{const o=flrSpr('nst'+flrMd(i,2),200,190,100,176,g=>{const shock=(sx,h,w)=>{for(let k=0;k<13;k++){const u=k/12-.5,bx=sx+u*w,tx=sx+u*w*.18,col=k%2?'#a88a44':'#8a7034';g.strokeStyle=FLRO;g.lineWidth=5;g.beginPath();g.moveTo(bx,2);g.quadraticCurveTo((bx+tx)/2,-h*.5,tx,-h);g.stroke();g.strokeStyle=col;g.lineWidth=3;g.stroke()}
   for(let k=0;k<6;k++){const a=-Math.PI/2+(k-2.5)*.35;g.strokeStyle='#c8a050';g.lineWidth=2;g.beginPath();g.moveTo(sx,-h);g.lineTo(sx+Math.cos(a)*22,-h+Math.sin(a)*22);g.stroke()}
   g.strokeStyle='#5a3a1a';g.lineWidth=4;g.beginPath();g.ellipse(sx,-h*.55,w*.2,4,0,0,TAU);g.stroke()};
  if(flrMd(i,2)){shock(-30,150,90);flrPump(g,40,4,20,'#f08a2a')}else{shock(0,160,100);flrPump(g,-60,4,16,'#e8d8b0');flrPump(g,56,4,14,'#f0a030')}});flrBlit(c,o,x,GY+118+rnd(i)*20)};
NEAR.flrapples=(c,x,i,d)=>{const o=flrSpr('nap'+flrMd(i,2),220,110,110,96,g=>{if(flrMd(i,2)){g.beginPath();g.moveTo(-60,-50);g.lineTo(60,-50);g.lineTo(52,0);g.lineTo(-52,0);g.closePath();g.fillStyle='#b8844a';g.fill();g.strokeStyle=FLRO;g.lineWidth=2.4;g.stroke();g.strokeStyle='#8a5a2a';g.lineWidth=2;for(let k=0;k<4;k++){g.beginPath();g.moveTo(-58,-40+k*11);g.lineTo(58,-40+k*11);g.stroke()}
   for(let k=0;k<9;k++){const ax=-48+k*12,ay=-56-(k%2)*8;g.beginPath();g.arc(ax,ay,8,0,TAU);g.fillStyle=k%3?'#d8302a':'#8ab030';g.fill();g.strokeStyle=FLRO;g.lineWidth=1.3;g.stroke();g.fillStyle='#ffffff55';g.beginPath();g.arc(ax-2.4,ay-2.4,2,0,TAU);g.fill()}}
  else{for(let k=0;k<14;k++){const L=flrLeaf(k%6);g.save();g.translate(-80+k*12,-6-rnd(k)*16);g.rotate(rnd(k+3)*TAU);g.drawImage(L.c,-12,-12,24,24);g.restore()}for(let k=0;k<4;k++){const ax=-50+k*30,ay=-8;g.beginPath();g.arc(ax,ay,7,0,TAU);g.fillStyle='#c8302a';g.fill();g.strokeStyle=FLRO;g.lineWidth=1.3;g.stroke()}}});flrBlit(c,o,x,GY+100+rnd(i)*24)};
NEAR.flrleafpile=(c,x,i,d)=>{const o=flrSpr('nlp',200,80,100,70,g=>{g.fillStyle='#3a1a0e';g.beginPath();g.ellipse(0,-6,86,18,0,0,TAU);g.fill();for(let k=0;k<40;k++){const L=flrLeaf(k%6);const a=rnd(k*2)*Math.PI,r=rnd(k*5)*80;g.save();g.translate(Math.cos(a)*r,-6-Math.sin(a)*r*.32-rnd(k+1)*10);g.rotate(rnd(k+7)*TAU);g.drawImage(L.c,-12,-12,24,24);g.restore()}});flrBlit(c,o,x,GY+110+rnd(i)*20)};
/* ---------- ground strips ---------- */
function flrGround(key,draw){return flrSpr(key,1600,H-GY+20,0,0,draw)}
GRD.flrsoil=(c,t,d)=>{const o=flrGround('gsoil',g=>{for(let k=0;k<4;k++){g.fillStyle='#00000022';g.fillRect(0,22+k*30,1600,9)}
  g.strokeStyle='#2a4a1a';g.lineWidth=2.6;for(let k=0;k<26;k++){const x0=rnd(k*5)*1600,y0=14+rnd(k*9)*(H-GY-26),L=120+rnd(k+3)*200;g.beginPath();g.moveTo(x0,y0);for(let q=1;q<=6;q++){const x=x0+L*q/6;g.quadraticCurveTo(x-L/12,y0+Math.sin(q*1.9+k)*9,x,y0+Math.sin(q*1.3+k)*5)}g.stroke()}
  for(let k=0;k<70;k++){const L=flrLeaf(k%6),x=rnd(k*3)*1600,y=8+rnd(k*7)*(H-GY-10);g.save();g.translate(x,y);g.rotate(rnd(k+2)*TAU);g.globalAlpha=.75;g.drawImage(L.c,-8,-8,16,16);g.restore()}g.globalAlpha=1;
  for(let k=0;k<12;k++){const x=rnd(k*11+4)*1600,y=30+rnd(k*13)*90;flrPLeaf(g,x,y,.9,rnd(k)*2-1,'#2a4a1e')}});flrStrip(c,o,t*70,GY)};
GRD.flrpath=(c,t,d)=>{const o=flrGround('gpath',g=>{g.fillStyle='#4a361e55';g.fillRect(0,20,1600,70);for(let k=0;k<260;k++){const x=rnd(k*3)*1600,y=6+rnd(k*7)*(H-GY-10);g.strokeStyle=k%3?'#c8a050aa':'#8a6a30aa';g.lineWidth=1.4;const a=rnd(k+5)*Math.PI;g.beginPath();g.moveTo(x,y);g.lineTo(x+Math.cos(a)*9,y+Math.sin(a)*3);g.stroke()}
  for(let k=0;k<30;k++){const L=flrLeaf(k%6),x=rnd(k*9)*1600,y=10+rnd(k*5)*(H-GY-20);g.save();g.translate(x,y);g.rotate(rnd(k)*TAU);g.globalAlpha=.7;g.drawImage(L.c,-8,-8,16,16);g.restore()}g.globalAlpha=1;
  for(let k=0;k<10;k++){const x=rnd(k*17)*1600,y=20+rnd(k*19)*100;g.save();g.translate(x,y);g.rotate(rnd(k)*3);g.beginPath();g.ellipse(0,0,4,10,0,0,TAU);g.fillStyle='#d8b040';g.fill();g.restore()}});flrStrip(c,o,t*70,GY)};
GRD.flrgrass=(c,t,d)=>{const o=flrGround('ggrass',g=>{for(let k=0;k<340;k++){const x=rnd(k*3)*1600,y=4+rnd(k*7)*(H-GY-8);g.strokeStyle=k%2?'#2a3a1a':'#3a4a22';g.lineWidth=1.6;g.beginPath();g.moveTo(x,y);g.lineTo(x+(rnd(k)-.5)*6,y-6-rnd(k+1)*8);g.stroke()}
  for(let k=0;k<80;k++){const L=flrLeaf(k%6),x=rnd(k*9)*1600,y=6+rnd(k*5)*(H-GY-12);g.save();g.translate(x,y);g.rotate(rnd(k)*TAU);g.globalAlpha=.8;g.drawImage(L.c,-9,-9,18,18);g.restore()}g.globalAlpha=1;
  for(let k=0;k<14;k++){const x=rnd(k*21)*1600,y=20+rnd(k*23)*100;g.beginPath();g.arc(x,y,6,0,TAU);g.fillStyle=k%3?'#b82a24':'#d8a030';g.fill();g.strokeStyle=FLRO;g.lineWidth=1.2;g.stroke()}});flrStrip(c,o,t*70,GY)};
/* ---------- falling leaves (and the twist's gusts sweep them sideways) ---------- */
/* reduced motion (the OS setting) or Performance mode: fewer leaves and no wind streaks */
let FLRRM=null;const flrRM=()=>{if(FLRRM===null){try{const q=matchMedia('(prefers-reduced-motion: reduce)');FLRRM=q.matches;q.addEventListener&&q.addEventListener('change',e=>{FLRRM=e.matches})}catch(e){FLRRM=false}}return FLRRM};
const flrLite=()=>flrRM()||(typeof PFM==='function'&&PFM()==='low');
const flrGustAmt=()=>{try{const G=S&&S.flr&&S.flrG;if(!G||!(G.t0>=0))return 0;const u=(S.t-G.t0)/G.dur;return u>0&&u<1?Math.sin(u*Math.PI):0}catch(e){return 0}};
{const w0=weather;weather=function(type,t,a){if(type!=='flrleaves')return w0.apply(this,arguments);const c=ctx,gu=flrGustAmt(),lite=flrLite(),n=lite?14:30;
 for(let i=0;i<n;i++){const sp=.05+rnd(i)*.05,u=(t*sp+rnd(i+5))%1,dx=t*(22+rnd(i+4)*26)+gu*(t*260%W),x=W*1.25-((rnd(i+2)*W*1.3+dx+Math.sin(t*.8+i)*36)%(W*1.35)),y=-24+u*(H+48);
  flrLeafAt(c,i%6,x,y,.7+rnd(i+9)*.45,t*(1+rnd(i)*1.4)+i,Math.cos(t*2.2+i))}
 if(gu>0&&!lite){c.save();c.lineCap='round';for(let i=0;i<9;i++){const y=140+i*70+Math.sin(i*2.3)*30,len=180+rnd(i)*160,x=W*(1-((S.t-S.flrG.t0)/S.flrG.dur*1.6-rnd(i)*.4))+60;c.strokeStyle='#fff8e8'+flrA(gu*.32);c.lineWidth=2+rnd(i+3)*2;c.beginPath();c.moveTo(x,y);c.quadraticCurveTo(x+len*.5,y-10-rnd(i)*14,x+len,y+4);c.stroke()}c.restore()}}}
/* ---------- the three fields ---------- */
SCN[44]={sky:['#0d0720','#6e3424'],stars:70,flmoon:[W*.71,232,104,'#ffcf7a','#ff9a3a'],far:'flrfarm',p:'#1a0e16',a:'#ff9a3a',mid:[['flrfence',620,12,.18],['flrhay',900,14,.4],['flrscarep',1300,16,.55],['flrcart',1500,18,.62]],g:['#2a1810','#0c0604','#ff9a3a33'],gt:'flrsoil',near:[['flrpumpk',300,70,.2],['flrgourds',640,70,.55]],wx:'flrleaves',haze:'#ff8a3a1c',fog:'#ff9a5a12'};
SCN[45]={sky:['#090a22','#463656'],stars:90,flmoon:[W*.27,206,96,'#ffe2a0','#ffd060'],far:'flrcornf',p:'#141022',a:'#ffd04a',mid:[['flrcornwall',420,12,.18],['flrsign',1100,13,.5],['flrlamp',760,14,.45]],g:['#2a2414','#0a0806','#ffd04a2a'],gt:'flrpath',near:[['flrstalk',520,70,.4]],wx:'flrleaves',haze:'#c8a0ff16',fog:'#e8d0a012'};
SCN[46]={sky:['#0f0820','#7a2e3a'],stars:60,flmoon:[W*.56,214,118,'#ffb860','#ff7a3a'],far:'flrhouse',p:'#160a16',a:'#ff6a4a',mid:[['flrtree',460,12,.22],['flrladder',1300,14,.55],['flrbarrel',1500,15,.6]],g:['#1e2014','#080806','#ff6a4a2a'],gt:'flrgrass',near:[['flrapples',420,70,.35],['flrleafpile',560,70,.5]],wx:'flrleaves',haze:'#ff6a4a18',fog:'#ff8a6a10'};
const FLRLV=[
 {i:44,n:'The Pumpkin Patch',z:0,tint:'#ff9a3a',sky:SCN[44].sky,wx:'flrleaves',prop:'',m:['flrpie','flrmaple','flrgourd'],b:'bflrgourd',bn:'The Gourd Colossus',bl:'the gourd colossus',pl:'the pumpkin patch',hue:0,blurb:'Vines, carts and a hundred pumpkins under the rising moon.',a:'#ff9a3a'},
 {i:45,n:'The Corn Maze',z:0,tint:'#ffd04a',sky:SCN[45].sky,wx:'flrleaves',prop:'',m:['flrscare','flrcrow','flrwraith'],b:'bflrking',bn:'The Scarecrow King',bl:'the scarecrow king',pl:'the corn maze',hue:0,blurb:'Walls of corn, lanterns on poles and signs that lie.',a:'#ffd04a'},
 {i:46,n:'The Moonlit Orchard',z:0,tint:'#ff6a4a',sky:SCN[46].sky,wx:'flrleaves',prop:'',m:['flracorn','flrturkey','flrbale'],b:'bflrgobble',bn:'The Wild Hunt Gobbler',bl:'the wild hunt gobbler',pl:'the moonlit orchard',hue:0,blurb:'Apple trees heavy with fruit, cider barrels and the wild hunt.',a:'#ff6a4a'}];
const flrThumb=(i,w,h)=>{try{return sceneShot(FLRLV[(i||0)%3],w||640,h||480,'flr')}catch(e){return''}};

/* 10.4b: the level-change sweep without shadow blur. The Endless blend (70b bgBlend) strokes its wall of light and two shockwave rings
   with shadowBlur 40 / 18 / 24; with the rings spanning the whole screen that blur cost most of the frame on machines without a fast GPU
   (measured in software rendering: 84 ms a frame during the 5.4 s sweep, 35 ms without the blur). The Rush draws the same sweep with
   the blur replaced by wider, fainter strokes under the bright ones, and at most 300 sparks. Other modes keep 70b as it is. */
function flrBlend(L){const en=!S.camp&&!S.prac&&!S.rift&&!S.dc&&S.mode!=='title'&&S.mode!=='crate';
 if(en&&S.bgL&&S.bgL!==L){S.bgx={from:S.bgL,to:L,t0:S.t,p:[],rings:[{t:0},{t:.35}],sh:0};if(ST.shake)S.shake=Math.max(S.shake||0,12);bgxSfx()}
 if(en)S.bgL=L;
 const x=S.bgx;
 if(!x||S.t-x.t0>=BGX_DUR||S.t<x.t0){S.bgx=null;zoneBG(L.z,S.t,L);return}
 const c=ctx,u=(S.t-x.t0)/BGX_DUR,e=u<.5?2*u*u:1-Math.pow(-2*u+2,2)/2,t=S.t;
 const seam=-260+e*(W+520),F=x.to.a||'#ffd76a',O=x.from.a||'#ffffff';
 const edge=y=>seam+Math.sin(y*.011+t*2.6)*46+Math.sin(y*.029-t*4.8)*20+(y-H*.5)*.16;
 zoneBG(x.from.z,t,x.from);
 /* feathered reveal of the new world behind the wall of light */
 const clipTo=off=>{c.beginPath();c.moveTo(-60,-30);for(let y=-30;y<=H+30;y+=30)c.lineTo(edge(y)+off,y);c.lineTo(-60,H+30);c.closePath();c.clip()};
 [[-90,1],[-45,.34],[0,.4],[45,.5]].forEach(([off,a])=>{c.save();clipTo(off);c.globalAlpha=a;zoneBG(x.to.z,t,x.to);c.restore()});
 /* the wall of light */
 c.save();c.globalCompositeOperation='lighter';
 for(let y=0;y<=H;y+=60){const ex=edge(y);glow(c,ex,y,150,F+'66');glow(c,ex+40,y,90,'#ffffff55')}
 c.lineJoin='round';const path=()=>{c.beginPath();for(let y=-30;y<=H+30;y+=20){const ex=edge(y);y===-30?c.moveTo(ex,y):c.lineTo(ex,y)}};
 c.strokeStyle=F;path();c.globalAlpha=.12;c.lineWidth=96;c.stroke();c.globalAlpha=.2;c.lineWidth=58;c.stroke();c.globalAlpha=.7;c.lineWidth=26;c.stroke();
 c.strokeStyle='#fff';path();c.globalAlpha=.3;c.lineWidth=18;c.stroke();c.globalAlpha=.95;c.lineWidth=7;c.stroke();
 c.lineWidth=2.4;c.strokeStyle=O;c.globalAlpha=.8;c.save();c.translate(-34,0);path();c.stroke();c.restore();c.save();c.translate(36,0);c.strokeStyle=F;path();c.stroke();c.restore();
 /* light beams streaming off the wall */
 c.globalAlpha=.5;for(let i=0;i<9;i++){const y=(i*173+t*90*(i%2?1:-1))%(H+200)-100,ex=edge(y),len=260+Math.sin(t*3+i)*120;const g=c.createLinearGradient(ex,0,ex+len,0);g.addColorStop(0,'#ffffffaa');g.addColorStop(1,'#ffffff00');c.fillStyle=g;c.fillRect(ex,y-2.5,len,5)}
 c.restore();
 /* sparks and shockwaves */
 const dt=Math.min(.05,Math.max(0,t-(x.lt||t)));x.lt=t;
 for(let i=0;i<4+Math.sin(u*Math.PI)*8;i++){const y=Math.random()*H;x.p.push({x:edge(y),y,vx:60+Math.random()*320,vy:-120-Math.random()*200,l:.8+Math.random()*1,s:2+Math.random()*4,c:Math.random()<.5?F:Math.random()<.5?'#fff':O,a:Math.random()<.35})}
 c.save();c.globalCompositeOperation='lighter';for(const p of x.p){p.l-=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=80*dt;c.globalAlpha=Math.max(0,Math.min(1,p.l*1.3));c.fillStyle=p.c;if(p.a)mS(c,p.x,p.y,p.s*1.8,p.c);else c.fillRect(p.x,p.y,p.s,p.s)}c.restore();x.p=x.p.filter(p=>p.l>0);if(x.p.length>300)x.p.length=300;
 c.save();c.globalCompositeOperation='lighter';for(const r of x.rings){const k=(t-x.t0-r.t)/1.8;if(k<=0||k>=1)continue;const rr=k*1500;c.strokeStyle=F;c.beginPath();c.ellipse(KX+60,GY-120,rr,rr*.5,0,0,TAU);c.globalAlpha=(1-k)*.22;c.lineWidth=30+(1-k)*30;c.stroke();c.globalAlpha=(1-k)*.8;c.lineWidth=4+(1-k)*14;c.stroke()}c.restore();
 /* colour wash at the moment of crossing */
 const w=Math.max(0,1-Math.abs(u-.5)*4);if(w>0){c.save();c.globalCompositeOperation='lighter';c.globalAlpha=w*.28;c.fillStyle=F;c.fillRect(-30,-30,W+60,H+60);c.restore()}
 if(ST.shake&&Math.abs(u-.5)<.04&&!x.sh){x.sh=1;S.shake=Math.max(S.shake||0,10)}}
{const b0=bgBlend;bgBlend=function(L){if(S&&S.flr)return flrBlend(L);return b0.apply(this,arguments)}}
