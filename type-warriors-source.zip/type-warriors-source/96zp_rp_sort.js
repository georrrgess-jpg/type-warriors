/* ===== RUNESTONE TOWER DEFENSE 9.8: sort the tower bar (96zp, after 96zo) =====
   A "Sort" tab on the top-left corner of the tower bar opens a small menu: Default, Lowest price, Highest price, Can afford first
   (re-sorts live as supply changes) and Hits flyers first. The choice is saved (RPP().sort). Tiles are reordered with CSS order,
   so every tile keeps its own key (Q, W, E...), tooltip and state; the build ring keeps the default order. Key S cycles the sorts. */
const RPSORTS=[['def','Default'],['lo','Lowest price'],['hi','Highest price'],['aff','Can afford first'],['air','Hits flyers first']];
const rpSortK=()=>{const r=RPP(),k=r.sort;return RPSORTS.some(s=>s[0]===k)?k:'def'};
function rpSortApply(force){const R=RPX,h=$('rphud');if(!R||!h)return;const cards=[...h.querySelectorAll('.rpbar .rpcard')];if(!cards.length)return;const k=rpSortK();
 const cost=t=>{try{return rpCost(t,1)}catch(e){return RP_TW[t].cost[0]}},lock=t=>{try{return typeof rpLockedTw==='function'&&rpLockedTw(t)?1:0}catch(e){return 0}};
 const key=k+'|'+(k==='aff'?RP_TWORDER.map(t=>R.supply>=cost(t)?1:0).join(''):'');if(!force&&h.dataset.sk===key)return;h.dataset.sk=key;
 const ord=RP_TWORDER.slice();const base=t=>RP_TWORDER.indexOf(t);
 if(k==='lo')ord.sort((a,b)=>lock(a)-lock(b)||cost(a)-cost(b)||base(a)-base(b));
 else if(k==='hi')ord.sort((a,b)=>lock(a)-lock(b)||cost(b)-cost(a)||base(a)-base(b));
 else if(k==='aff')ord.sort((a,b)=>lock(a)-lock(b)||(R.supply>=cost(b))-(R.supply>=cost(a))||cost(a)-cost(b)||base(a)-base(b));
 else if(k==='air')ord.sort((a,b)=>lock(a)-lock(b)||(RP_TW[b].air?1:0)-(RP_TW[a].air?1:0)||base(a)-base(b));
 for(const c of cards){const i=ord.indexOf(c.dataset.tw);c.style.order=i<0?99:i}
 const lab=h.querySelector('.rpsort b');if(lab)lab.textContent=RPSORTS.find(s=>s[0]===k)[1];
 h.querySelectorAll('.rpsortm button').forEach(b=>b.classList.toggle('on',b.dataset.k===k))}
function rpSortSet(k){RPP().sort=k;try{save()}catch(e){}rpSortApply(true);const h=$('rphud');if(h){const m=h.querySelector('.rpsortm');if(m)m.classList.remove('open')}try{rpSfx('key',2)}catch(e){}}
{const h0=rpHudOn;rpHudOn=function(){const r=h0.apply(this,arguments);try{const h=$('rphud'),bar=h&&h.querySelector('.rpbar');if(bar&&!bar.querySelector('.rpsort')){
  const w=document.createElement('div');w.className='rpsortw';
  w.innerHTML=`<button class="rpsort" type="button" aria-haspopup="true" title="Sort the towers (S)"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 4v16M7 20l-3-3M7 20l3-3M17 20V4M17 4l-3 3M17 4l3 3" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>Sort: <b></b></button>
   <div class="rpsortm" role="menu">${RPSORTS.map(([k,n])=>`<button type="button" role="menuitemradio" data-k="${k}">${n}</button>`).join('')}</div>`;
  bar.appendChild(w);const m=w.querySelector('.rpsortm');
  w.querySelector('.rpsort').onclick=e=>{e.stopPropagation();m.classList.toggle('open')};
  m.querySelectorAll('button').forEach(b=>b.onclick=e=>{e.stopPropagation();rpSortSet(b.dataset.k)});
  document.addEventListener('pointerdown',e=>{if(!w.contains(e.target))m.classList.remove('open')},true)}
  rpSortApply(true)}catch(e){console.error(e)}return r}}
{const t0=rpHudTick;rpHudTick=function(){const r=t0.apply(this,arguments);try{if(rpSortK()==='aff')rpSortApply(false)}catch(e){}return r}}
{const k0=rpKeyDown;window.removeEventListener('keydown',rpKeyDown,true);rpKeyDown=function(e){const R=RPX;if(R&&S.rp&&S.mode==='ramparts'&&!R.pause&&!R.over&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&e.key.length===1&&e.key.toLowerCase()==='s'){e.preventDefault();e.stopImmediatePropagation();
  if(!e.repeat){const i=RPSORTS.findIndex(s=>s[0]===rpSortK());rpSortSet(RPSORTS[(i+1)%RPSORTS.length][0]);const s=RPSORTS.find(q=>q[0]===rpSortK());try{rpToast('Towers sorted: '+s[1],1.1,'#ffd45a')}catch(x){}}return}return k0.apply(this,arguments)};window.addEventListener('keydown',rpKeyDown,true)}
{const st=document.createElement('style');st.textContent=`
.rpsortw{position:absolute;left:18px;top:-30px;z-index:5}
.rpsort{all:unset;box-sizing:border-box;cursor:pointer;display:flex;align-items:center;gap:6px;height:28px;padding:0 12px 0 10px;border-radius:12px 12px 0 0;border:2px solid #7a5ac8;border-bottom:0;background:linear-gradient(180deg,#2c2270,#1a1350);font:700 12.5px var(--ui);color:#c8bdf0;transition:transform .15s,color .15s}
.rpsort svg{width:15px;height:15px;color:#ffd45a}.rpsort b{color:#ffd45a;font-weight:800}.rpsort:hover{color:#fff;transform:translateY(-1px)}.rpsort:focus-visible{outline:3px solid #ffd45a;outline-offset:2px}
.rpsortm{position:absolute;left:0;bottom:34px;min-width:186px;display:flex;flex-direction:column;gap:2px;padding:6px;border-radius:14px;border:2px solid #7a5ac8;background:linear-gradient(180deg,#221a5c,#110b34);box-shadow:0 0 0 2px #12081f,0 12px 24px #000b;
 opacity:0;transform:translateY(8px) scale(.96);transform-origin:bottom left;pointer-events:none;transition:opacity .16s,transform .2s cubic-bezier(.34,1.56,.64,1)}
.rpsortm.open{opacity:1;transform:none;pointer-events:auto}
.rpsortm button{all:unset;box-sizing:border-box;cursor:pointer;padding:8px 12px 8px 26px;border-radius:9px;font:600 13.5px var(--ui);color:#e8e0ff;position:relative}
.rpsortm button:hover{background:#3a2c8a}.rpsortm button.on{color:#ffd45a}.rpsortm button.on::before{content:'';position:absolute;left:10px;top:50%;width:7px;height:7px;margin-top:-4px;border-radius:50%;background:#ffd45a}`;document.head.appendChild(st)}
