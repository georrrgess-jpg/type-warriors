/* ===== MOONLIT FISHING: rod tier effects =====
   Every rod tier has its own signature animation in four moments (grander with each tier, never loud):
             idle aura (idle/wait/reveal)      cast trail (rod tip + bobber)     reeling (per letter)                 catch flourish (<=1.2 s)
   Willow    a leaf drifts off now and then    falling leaves + green wisp       leaves shake off the tip             a whirl of leaves
   Ashwood   a brass glint runs up the shaft   a hot spark streak                brass sparks, gears pop off the reel a gear-and-spark burst
   Moonreed  moon motes rise from the guides   a silver moonbeam ribbon          moonlight runs down the line, ripples a crescent moon flash
   Starwoven constellation pulses, tip orbits  a constellation trail             stars light up along the line        a constellation draws itself
   Tidecaller droplets swirl round the shaft   a curling water ribbon            a tide swirl at the bobber           a wave crest and trident flash
   Hooks: wraps fsHero (keeps the hero rod's geometry), fsMotionFx (draws the effects, replaces the generic cast trail) and
   fsType (reacts to correct letters). fsRodShowcase(g,cx,cy,w,h,t,tier,sk) plays a 4 s demo loop for the Rod Workshop.
   Reduced motion: no particles, trails or auras; the flourish becomes a soft glow. */
const FSRF={pt:[],tr:[],fp:[],fl:null,showT0:-1,T:0,swirl:0,geo:null,n:0};
const fsRfSd=p=>Math.round(p.t*60);
const FSRF_LEAF=[['#2e7a34','#8ad05a'],['#3e8a3a','#b2e070']];
/* a ribbon polygon through points {x,y,w} */
function fsRfRibbon(g,P){if(P.length<2)return false;const A=[],B=[];for(let i=0;i<P.length;i++){const a=P[Math.max(0,i-1)],b=P[Math.min(P.length-1,i+1)],dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy)||1,nx=-dy/d,ny=dx/d,w=P[i].w;A.push([P[i].x+nx*w,P[i].y+ny*w]);B.push([P[i].x-nx*w,P[i].y-ny*w])}
 g.beginPath();g.moveTo(A[0][0],A[0][1]);for(const q of A)g.lineTo(q[0],q[1]);for(let i=B.length-1;i>=0;i--)g.lineTo(B[i][0],B[i][1]);g.closePath();return A}
/* a Catmull-Rom resample through sparse trail samples {x,y,t}, so ribbons curve instead of bending at hard corners */
function fsRfSm(P){if(P.length<3)return P;const O=[],n1=P.length-1;for(let i=0;i<n1;i++){const a=P[Math.max(0,i-1)],b=P[i],c=P[i+1],d=P[Math.min(n1,i+2)],n=Math.max(1,Math.min(6,Math.ceil(Math.hypot(c.x-b.x,c.y-b.y)/8)));
  for(let j=0;j<n;j++){const s=j/n,s2=s*s,s3=s2*s,f=(A,B,C,D)=>.5*(2*B+(C-A)*s+(2*A-5*B+4*C-D)*s2+(3*B-A-3*C+D)*s3);O.push({x:f(a.x,b.x,c.x,d.x),y:f(a.y,b.y,c.y,d.y),t:b.t+(c.t-b.t)*s})}}O.push(P[n1]);return O}
const fsRfPl=(g,P)=>{g.beginPath();P.forEach((p,i)=>i?g.lineTo(p.x,p.y):g.moveTo(p.x,p.y))};
const fsRfE=k=>1-Math.pow(1-Math.max(0,Math.min(1,k)),3);
const fsRfLine=(tip,bob,s)=>({x:tip.x+(bob.x-tip.x)*s,y:tip.y+(bob.y-tip.y)*s+Math.sin(s*Math.PI)*4});
/* ---------- the five tiers ---------- */
const FSRFX=[
/* 0 Willow */{
 aura(g,G,t){for(let i=0;i<2;i++){const P=3.8,ph=t/P+i*.5,n=Math.floor(ph),f=ph-n;if(f>.72)continue;const k=f/.72,q=G.pt(.42+.5*fsRh(n*3+i*17),1),x=q.x+k*74+Math.sin(k*9+n)*10,y=q.y+k*k*64+k*26,al=Math.min(1,k*8)*(1-Math.max(0,(k-.7)/.3));
  fsLeaf(g,x,y,13*G.K,1.2+Math.sin(k*7+n)*.9+k*2.4,G.LC[(n+i)%2],al)}},
 trail(g,P,now,fl,ls){const life=(ls||1)*(fl?.5:.36),Q=fsRfSm(P.filter(p=>now-p.t<life)).map(p=>{const k=Math.max(0,1-(now-p.t)/life);return{x:p.x,y:p.y,w:(fl?1.5:3.6)*k}});
  if(fsRfRibbon(g,Q)){g.fillStyle=fl?'rgba(92,186,60,.42)':'rgba(92,186,60,.72)';g.fill();g.save();g.globalCompositeOperation='lighter';Q.forEach(q=>q.w*=.38);fsRfRibbon(g,Q);g.fillStyle=fl?'rgba(150,230,90,.25)':'rgba(170,240,110,.45)';g.fill();g.restore()}
  let c=0;for(let i=P.length-1;i>=0&&c<16;i--){const p=P[i],a=now-p.t,sd=fsRfSd(p);if(a>.95||fsRh(sd)>(fl?.1:.42))continue;c++;
   const x=p.x+(fsRh(sd+1)-.5)*90*a+Math.sin(a*9+sd)*8,y=p.y+(-20-fsRh(sd+2)*30)*a+80*a*a;fsLeaf(g,x,y,(9+fsRh(sd+4)*4)*(fl?.85:1),sd+a*(4+fsRh(sd+3)*4),FSRF_LEAF[sd%2],1-a/.95)}},
 letter(tip,bob,G){for(let i=0;i<3;i++)fsRfAdd({k:'leaf',x:tip.x,y:tip.y,vx:(Math.random()-.5)*130,vy:-60-Math.random()*60,max:1.2+Math.random()*.5,rot:Math.random()*6,vr:(Math.random()-.5)*7,L:10+Math.random()*4,c:(G&&G.LC||FSRF_LEAF)[i%2],ph:Math.random()*6});fsRfAdd({k:'arc',x:tip.x,y:tip.y,max:.3,c:'#c8f0a0'})},
 reel(g,tip,bob,now,dt){if(Math.random()<dt*.8)fsRfAdd({k:'leaf',x:tip.x,y:tip.y,vx:(Math.random()-.5)*40,vy:-10,max:1.4,rot:Math.random()*6,vr:(Math.random()-.5)*5,L:7,c:FSRF_LEAF[Math.random()*2|0],ph:Math.random()*6})},
 flourish(g,x,y,el,sc,G){const k=el/1.15;if(k>=1)return;const e=fsRfE(k*1.2),fade=k>.68?1-(k-.68)/.32:1,LC=G&&G.LC||FSRF_LEAF;fkGlow(g,x,y-e*24*sc,64*sc*(.5+e),'#c8ff9a',.32*(1-k));
  g.save();g.lineCap='round';for(let j=0;j<3;j++){const r=(16+e*(58+j*14))*sc,a0=el*5.6+j*2.1;g.strokeStyle=`rgba(210,255,170,${.5*fade})`;g.lineWidth=(2.2-j*.5)*sc;g.beginPath();g.ellipse(x,y-e*30*sc,r,r*.5,0,a0,a0+1.6);g.stroke()}g.restore();
  for(let i=0;i<14;i++){const an=i*TAU/14+el*5.6,r=(12+e*78*(.72+.28*fsRh(i)))*sc,lx=x+Math.cos(an)*r,ly=y-e*30*sc+Math.sin(an)*r*.5;fsLeaf(g,lx,ly,(12+5*fsRh(i+3))*sc,an+Math.PI/2+.5,LC[i%2],fade*Math.min(1,k*12))}
  for(let i=0;i<8;i++){const an=i*TAU/8-el*3.2,r=(8+e*52)*sc;fkSpark(g,x+Math.cos(an)*r,y-e*22*sc+Math.sin(an)*r*.5,(3+2*Math.sin(el*12+i))*sc,'#f4ffd0',fade*.9)}}},
/* 1 Ashwood */{
 aura(g,G,t){const P=3.2,f=t%P;
  if(f<.75){const u=.17+(f/.75)*.82,p=G.at(u),hw=G.wAt(u)/2;g.save();g.translate(p.x,p.y);g.rotate(Math.atan2(p.ty,p.tx));g.globalCompositeOperation='lighter';const q=g.createLinearGradient(-15*G.K,0,15*G.K,0);q.addColorStop(0,'rgba(255,240,190,0)');q.addColorStop(.5,'rgba(255,248,220,.9)');q.addColorStop(1,'rgba(255,240,190,0)');g.fillStyle=q;g.beginPath();g.ellipse(0,-hw*.15,15*G.K,hw*1.05,0,0,TAU);g.fill();g.restore();fkSpark(g,p.x-p.nx*hw*.6,p.y-p.ny*hw*.6,4.2*G.K,'#fffbe8',.95)}
  else if(f<1.2){const k=(f-.75)/.45,s=Math.sin(k*Math.PI),tp=G.tip;fkGlow(g,tp.x,tp.y,20*G.K,'#ffd890',.55*s);fkSpark(g,tp.x,tp.y,10*s*G.K,'#fff6d0',1)}
  const f2=(t+1.6)%P;if(f2<.4&&G.reel){const s=Math.sin(f2/.4*Math.PI),R=G.reel;fkSpark(g,R.x-R.r*.45,R.y-R.r*.45,7*s*G.K,'#fffbe8',1)}},
 trail(g,P,now,fl,ls){const life=(ls||1)*(fl?.42:.3),Q=fsRfSm(P.filter(p=>now-p.t<life));g.save();g.globalCompositeOperation='lighter';g.lineCap='round';
  for(let i=1;i<Q.length;i++){const k=Math.max(0,1-(now-Q[i].t)/life);g.strokeStyle=`rgba(255,140,40,${.4*k})`;g.lineWidth=(fl?1.5:3)+k*(fl?3:8);g.beginPath();g.moveTo(Q[i-1].x,Q[i-1].y);g.lineTo(Q[i].x,Q[i].y);g.stroke();g.strokeStyle=`rgba(255,244,200,${.95*k})`;g.lineWidth=1+k*(fl?1.4:3);g.stroke()}g.restore();
  let c=0;for(let i=P.length-1;i>=0&&c<18;i--){const p=P[i],a=now-p.t,sd=fsRfSd(p);if(a>.6||fsRh(sd)>(fl?.3:.55))continue;c++;const an=fsRh(sd+1)*TAU,v=60+fsRh(sd+2)*130;fkSpark(g,p.x+Math.cos(an)*v*a,p.y+Math.sin(an)*v*a+260*a*a,(fl?2:2.8)*(1-a/.6)+.6,sd%2?'#ffd45a':'#ffae40',1-a/.6)}},
 letter(tip,bob,G){fsRfAdd({k:'gl',x:tip.x,y:tip.y,max:.2,r:11,c:'#fff6d0'});for(let i=0;i<8;i++){const an=-Math.PI/2+(Math.random()-.5)*2.8,v=130+Math.random()*150;fsRfAdd({k:'spk',x:tip.x,y:tip.y,vx:Math.cos(an)*v,vy:Math.sin(an)*v,max:.4+Math.random()*.3,r:3.4+Math.random()*2,c:Math.random()<.5?'#ffd45a':'#fff2c0'})}
  const R=G&&G.reel;if(R){fsRfAdd({k:'gl',x:R.x-R.r*.4,y:R.y-R.r*.4,max:.25,r:8,c:'#fffbe8'});if(++FSRF.n%3===0)fsRfAdd({k:'gear',x:R.x,y:R.y,vx:-30-Math.random()*40,vy:-90-Math.random()*40,max:.9,r:7+Math.random()*3,rot:0,vr:(Math.random()<.5?-1:1)*8})}},
 reel(g,tip,bob,now,dt){const R=FSRF.geo&&FSRF.geo.reel;if(R)fkGlow(g,R.x,R.y,R.r*2.2,'#ffcf70',.12+.3*(FS.pull||0))},
 flourish(g,x,y,el,sc){const k=el/1.1;if(k>=1)return;const e=fsRfE(k),fade=k>.62?1-(k-.62)/.38:1;
  if(el<.25)fkSpark(g,x,y,(32*(1-el/.25)+6)*sc,'#fff6d0',1-el/.25);fkGlow(g,x,y,74*sc,'#ffc860',.45*(1-k));
  g.strokeStyle=`rgba(255,212,90,${.85*(1-k)})`;g.lineWidth=3.2*(1-k)*sc+.5;g.beginPath();g.arc(x,y,(12+e*74)*sc,0,TAU);g.stroke();
  [[-2.35,15,12],[-1.15,11,10],[-.25,9,8],[-3.05,7,7]].forEach(([an,r,n],i)=>{const d=e*(58+i*12)*sc,gx=x+Math.cos(an)*d,gy=y+Math.sin(an)*d+k*k*44*sc,rr=r*sc;g.save();g.globalAlpha=fade;fsGearP(g,gx,gy,rr,n,el*(i%2?-6:6));g.arc(gx,gy,rr*.34,0,TAU,true);g.fillStyle=fkLin(g,gx,gy-rr,gx,gy+rr,['#fff4c0','#e6b43a','#7a4e0c']);g.fill('evenodd');g.lineWidth=1.4*sc;g.strokeStyle=FKO;g.stroke();g.restore()});
  for(let i=0;i<16;i++){const an=i*TAU/16+fsRh(i)*.3,d=(8+e*(92+30*fsRh(i+5)))*sc;fkSpark(g,x+Math.cos(an)*d,y+Math.sin(an)*d+k*k*30*sc,(4.6*(1-k)+1)*sc,i%2?'#ffd45a':'#fff2c0',fade)}}},
/* 2 Moonreed */{
 aura(g,G,t){for(let j=0;j<6;j++){const P=2.9,ph=t/P+j/6,n=Math.floor(ph),f=ph-n,q=G.pt(.3+.66*fsRh(n*6+j),-1.3),x=q.x+Math.sin(f*5+j)*6,y=q.y-f*50*G.K,al=Math.sin(f*Math.PI);
  fkGlow(g,x,y,8*G.K,G.GL,.5*al);g.save();g.globalAlpha=al;g.fillStyle='#f4f6ff';g.beginPath();g.arc(x,y,1.3*G.K,0,TAU);g.fill();g.restore()}},
 trail(g,P,now,fl,ls){const life=(ls||1)*(fl?.6:.42),Q=fsRfSm(P.filter(p=>now-p.t<life)).map(p=>{const k=Math.max(0,1-(now-p.t)/life);return{x:p.x,y:p.y,w:(fl?5:10)*k}});
  g.save();g.globalCompositeOperation='lighter';if(fsRfRibbon(g,Q)){g.fillStyle=fl?'rgba(170,180,255,.2)':'rgba(180,190,255,.3)';g.fill();Q.forEach(q=>q.w*=.42);fsRfRibbon(g,Q);g.fillStyle='rgba(235,240,255,.4)';g.fill()}g.restore();
  if(Q.length>1){g.save();g.lineCap='round';fsRfPl(g,Q);g.strokeStyle='rgba(255,255,255,.75)';g.lineWidth=1.3;g.stroke();g.restore()}
  let c=0;for(let i=P.length-1;i>=0&&c<8;i--){const p=P[i],a=now-p.t,sd=fsRfSd(p);if(a>.8||fsRh(sd)>(fl?.1:.2))continue;c++;const x=p.x,y=p.y-a*22,al=1-a/.8;fkGlow(g,x,y,10,'#dfe6ff',.4*al);g.save();g.globalAlpha=al;fsCrescP(g,x,y,3.8,sd,.5);g.fillStyle='#f4f6ff';g.fill();g.restore()}},
 letter(tip,bob,G){if(bob)fsRfAdd({k:'lm',max:.42,c:G&&G.GL||'#c8d8ff'});fsRfAdd({k:'gl',x:tip.x,y:tip.y,max:.25,r:9,c:'#f4f6ff'})},
 reel(g,tip,bob,now){fkGlow(g,bob.x,bob.y+12,30,'#c8d8ff',.14+.08*Math.sin(now*3))},
 flourish(g,x,y,el,sc,G,fo){const k=el/1.2;if(k>=1)return;const pop=fsRfE(el/.3),fade=k>.6?1-(k-.6)/.4:1,cx=x+(fo?-36:26)*sc,cy=y-(fo?80:40)*sc,R=22*sc*(pop+.06*Math.sin(el*6));
  if(el<.18)fkGlow(g,x,y,100*sc,'#ffffff',.6*(1-el/.18));fkGlow(g,cx,cy,R*3.4,'#e8ecff',.5*fade);
  g.save();g.globalCompositeOperation='lighter';g.translate(cx,cy);g.rotate(el*.5);for(let i=0;i<10;i++){g.rotate(TAU/10);const L=R*3.2*(.65+.35*fsRh(i)),q=g.createLinearGradient(R,0,L,0);q.addColorStop(0,`rgba(230,236,255,${.5*fade})`);q.addColorStop(1,'rgba(230,236,255,0)');g.fillStyle=q;g.beginPath();g.moveTo(R*.9,-R*.09);g.lineTo(L,0);g.lineTo(R*.9,R*.09);g.closePath();g.fill()}g.restore();
  g.strokeStyle=`rgba(232,236,255,${.7*(1-k)})`;g.lineWidth=2*sc;g.beginPath();g.arc(cx,cy,R*(1.25+k*2.4),0,TAU);g.stroke();
  g.save();g.globalAlpha=fade;fsCrescP(g,cx,cy,R,-Math.PI*.8,.5);g.fillStyle=fkRad(g,cx,cy,R,['#ffffff','#fff4d0','#d8c070']);g.fill();g.lineWidth=2*sc;g.strokeStyle=FKO;g.stroke();g.restore();
  fkSpark(g,cx+R*.55,cy-R*.75,6*sc*pop,'#ffffff',fade);
  for(let i=0;i<9;i++){const f=Math.min(1,k*(.7+fsRh(i)*.6)),mx=x+(fsRh(i+2)-.5)*56*sc+Math.sin(el*4+i)*5,my=y-f*84*sc,al=Math.sin(f*Math.PI)*fade;fkGlow(g,mx,my,8*sc,'#c8d8ff',.5*al);g.save();g.globalAlpha=al;g.fillStyle='#f4f6ff';g.beginPath();g.arc(mx,my,1.5*sc,0,TAU);g.fill();g.restore()}}},
/* 3 Starwoven */{
 aura(g,G,t){const CP=FSCONS.map(([u,o])=>G.pt(u,o));g.save();g.globalCompositeOperation='lighter';g.lineCap='round';for(let i=1;i<CP.length;i++){const w=Math.pow(Math.max(0,Math.sin(t*2.1-i*.75)),4);if(w<.05)continue;g.strokeStyle=`rgba(255,246,220,${w*.9})`;g.lineWidth=1.8*G.K;g.beginPath();g.moveTo(CP[i-1].x,CP[i-1].y);g.lineTo(CP[i].x,CP[i].y);g.stroke();fkGlow(g,CP[i].x,CP[i].y,10*G.K,G.GL,.55*w)}g.restore();
  const tp=G.tip,ca=Math.cos(G.a),sa=Math.sin(G.a),T=(x,y)=>[tp.x+x*ca-y*sa,tp.y+x*sa+y*ca];g.save();g.globalAlpha=.18;g.strokeStyle=G.GL;g.lineWidth=.8;g.beginPath();for(let i=0;i<=24;i++){const an=i/24*TAU,[x,y]=T(6*G.K+Math.cos(an)*16*G.K,Math.sin(an)*7*G.K);i?g.lineTo(x,y):g.moveTo(x,y)}g.stroke();g.restore();
  for(let i=0;i<3;i++){const an=t*1.7+i*TAU/3,[x,y]=T(6*G.K+Math.cos(an)*16*G.K,Math.sin(an)*7*G.K),fr=Math.sin(an)>0;fkSpark(g,x,y,(fr?3.2:2.2)*G.K,'#fff6dc',fr?1:.55)}},
 trail(g,P,now,fl,ls){const life=(ls||1)*(fl?.95:.8),N=[];let last=-1;for(const p of P){const s=Math.floor(p.t/.055);if(s!==last&&now-p.t<life){N.push(p);last=s}}const M=N.slice(-14);
  if(M.length>1){g.save();g.lineCap='round';for(let i=1;i<M.length;i++){const k=1-(now-M[i].t)/life;g.strokeStyle=`rgba(220,210,255,${.65*k})`;g.lineWidth=1.2;g.beginPath();g.moveTo(M[i-1].x,M[i-1].y);g.lineTo(M[i].x,M[i].y);g.stroke()}g.restore()}
  M.forEach(p=>{const k=1-(now-p.t)/life,sd=fsRfSd(p);fkGlow(g,p.x,p.y,10,'#c8b8ff',.45*k);fkSpark(g,p.x,p.y,(3.4+1.8*Math.sin(now*10+sd))*Math.sqrt(k)*(fl?.85:1)+.5,sd%3?'#fff6dc':'#ffe27a',Math.min(1,k*1.5))})},
 letter(tip,bob,G){if(bob)fsRfAdd({k:'ls',s:.12+Math.random()*.74,max:1.1,id:++FSRF.n});fsRfAdd({k:'gl',x:tip.x,y:tip.y,max:.25,r:10,c:'#fff6dc'})},
 reel(g,tip,bob,now){fkSpark(g,tip.x,tip.y,4+2*Math.sin(now*8),'#fff6dc',.85)},
 flourish(g,x,y,el,sc,G,fo){const k=el/1.2;if(k>=1)return;const fade=k>.72?1-(k-.72)/.28:1,ox=x+(fo?-40:14)*sc,oy=y-(fo?98:58)*sc,S=1.45*sc;
  const N=[[-24,0],[-8,-14],[14,-12],[30,0],[14,12],[-8,14],[-38,-12],[-38,12]],E=[[0,1],[1,2],[2,3],[3,4],[4,5],[5,0],[0,6],[0,7]],pr=Math.min(1,el/.75)*E.length,P=N.map(([a,b])=>[ox+a*S,oy+b*S]);
  if(el<.4)for(let i=0;i<8;i++){const f=fsRfE(el/.4),q=P[i];fkSpark(g,x+(q[0]-x)*f,y+(q[1]-y)*f,2.4*sc,'#fff6dc',1-f*.6)}
  const shim=el>.75?Math.pow(Math.max(0,Math.sin((el-.75)*9)),2):0;
  fkGlow(g,ox,oy,60*S,'#c8b8ff',.25*fade+.15*shim);
  g.save();g.lineCap='round';g.strokeStyle=`rgba(230,222,255,${(.8+.2*shim)*fade})`;g.lineWidth=(1.6+shim)*sc;E.forEach(([a,b],i)=>{const f=Math.max(0,Math.min(1,pr-i));if(!f)return;g.beginPath();g.moveTo(P[a][0],P[a][1]);g.lineTo(P[a][0]+(P[b][0]-P[a][0])*f,P[a][1]+(P[b][1]-P[a][1])*f);g.stroke()});g.restore();
  const seen=[0];E.forEach(([a,b],i)=>{if(pr>=i+1)seen.push(b)});const app=n=>{if(n===0)return 0;const i=E.findIndex(e=>e[1]===n);return (i+1)/E.length*.75};
  P.forEach((q,n)=>{if(!seen.includes(n))return;const pop=Math.max(0,1-(el-app(n))/.22);fkGlow(g,q[0],q[1],12*sc,'#c8b8ff',.6*fade);fkSpark(g,q[0],q[1],(4.2+4*pop+1.5*shim)*sc,n%3?'#fff6dc':'#ffe27a',fade)});
  if(el>.75){const p2=Math.max(0,1-(el-.75)/.3);fkSpark(g,ox+20*S,oy-3*S,(3+9*p2)*sc,'#ffffff',fade);fkGlow(g,ox+20*S,oy-3*S,22*sc,'#fff6dc',.6*p2)}}},
/* 4 Tidecaller */{
 aura(g,G,t){g.save();g.lineCap='round';for(let h=0;h<2;h++){g.beginPath();for(let i=0;i<=22;i++){const u=.5+i/22*.46,q=G.pt(u,(1.9+.3*h)*Math.sin(u*38-t*3.2+h*Math.PI));i?g.lineTo(q.x,q.y):g.moveTo(q.x,q.y)}g.strokeStyle=h?'rgba(200,255,250,.16)':'rgba(122,255,224,.24)';g.lineWidth=1.2*G.K;g.stroke()}g.restore();
  for(let j=0;j<9;j++){const ph=t*1.7+j*TAU/9,u=.48+.48*((t*.08+j/9)%1),p=G.at(u),hw=G.wAt(u)/2,rr=hw+9*G.K,s=Math.sin(ph),c=Math.cos(ph),x=p.x+p.nx*rr*s+p.tx*c*4,y=p.y+p.ny*rr*s+p.ty*c*4,fr=c>0,an=Math.atan2(p.ny*c-p.ty*s*.3,p.nx*c-p.tx*s*.3)+Math.PI;
  g.save();g.globalAlpha=(fr?.85:.35)*Math.min(1,Math.sin(((t*.08+j/9)%1)*Math.PI)*3);fsDropP(g,x,y,(2.1+.8*c)*G.K,an);g.fillStyle=fr?'#c8fcff':'#7ad8e8';g.fill();if(fr){g.lineWidth=.6;g.strokeStyle='#2a6a8a';g.stroke()}g.restore()}
  const f=t%3.4;if(f<.4){const tp=G.tip,s=Math.sin(f/.4*Math.PI),ta=G.at(.999);fkSpark(g,tp.x+ta.tx*13*G.K,tp.y+ta.ty*13*G.K,8*s*G.K,'#fff6c8',1)}},
 trail(g,P,now,fl,ls){const life=(ls||1)*(fl?.6:.42),Q=fsRfSm(P.filter(p=>now-p.t<life)).map(p=>{const k=Math.max(0,1-(now-p.t)/life);return{x:p.x,y:p.y,w:(fl?4:7.5)*k,k,t:p.t}}),O=Q.map(q=>({x:q.x,y:q.y}));
  for(let i=0;i<Q.length;i++){const a=O[Math.max(0,i-1)],b=O[Math.min(Q.length-1,i+1)],dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy)||1,o=Math.sin(Q[i].t*30-now*12)*4.5*Q[i].k;Q[i].x+=-dy/d*o;Q[i].y+=dx/d*o}
  const A=fsRfRibbon(g,Q);if(A){g.fillStyle=fl?'rgba(80,210,220,.3)':'rgba(80,214,226,.45)';g.fill();g.save();g.globalCompositeOperation='lighter';g.beginPath();A.forEach((q,i)=>i?g.lineTo(q[0],q[1]):g.moveTo(q[0],q[1]));g.strokeStyle='rgba(230,255,252,.75)';g.lineWidth=1.4;g.stroke();g.restore()}
  let c=0;for(let i=P.length-1;i>=0&&c<16;i--){const p=P[i],a=now-p.t,sd=fsRfSd(p);if(a>.6||fsRh(sd)>(fl?.25:.45))continue;c++;const vx=(fsRh(sd+1)-.5)*90,vy=-40-fsRh(sd+2)*60;g.save();g.globalAlpha=1-a/.6;fsDropP(g,p.x+vx*a,p.y+vy*a+320*a*a,2.1,Math.atan2(vy+640*a,vx)+Math.PI);g.fillStyle='#dffcff';g.fill();g.restore()}},
 letter(tip,bob,G){FSRF.swirl=1;if(bob)for(let i=0;i<4;i++){const an=-Math.PI/2+(Math.random()-.5)*1.6,v=90+Math.random()*70;fsRfAdd({k:'dr',x:bob.x+(Math.random()-.5)*20,y:bob.y+12,vx:Math.cos(an)*v,vy:Math.sin(an)*v,max:.55,r:3})}
  const ta=G&&G.at?G.at(.999):{tx:0,ty:0};fsRfAdd({k:'gl',x:tip.x+ta.tx*13,y:tip.y+ta.ty*13,max:.25,r:7,c:'#fff6c8'})},
 reel(g,tip,bob,now,dt){FSRF.swirl=Math.max(0,FSRF.swirl-dt*1.6);const P=FSRF.swirl,x=bob.x,y=bob.y+14;g.save();g.lineCap='round';
  for(let i=0;i<4;i++){const rx=(16+i*13)*(1+.3*P),a0=-now*(2.6-i*.4)+i*1.7;g.strokeStyle=`rgba(122,255,224,${.3+.45*P-i*.05})`;g.lineWidth=2.6-i*.4;g.beginPath();g.ellipse(x,y,rx,rx*.3,0,a0,a0+2.4);g.stroke();g.fillStyle=`rgba(230,255,250,${.4+.4*P})`;g.beginPath();g.arc(x+Math.cos(a0+2.4)*rx,y+Math.sin(a0+2.4)*rx*.3,2,0,TAU);g.fill()}
  fkGlow(g,x,y,44,'#7affe0',.12+.22*P);g.restore()},
 flourish(g,x,y,el,sc,G){const k=el/1.2;if(k>=1)return;const fade=k>.62?1-(k-.62)/.38:1,rise=fsRfE(el/.5),H=78*rise*sc,bx=x+30*sc,by=y+56*sc,W=56*sc;
  /* the wave crest: a small back wave and a curling front wave */
  const WV=(ox,oy,w,hh,cols,al)=>{const X=u=>ox+u*w,Y=v=>oy-v*hh;g.beginPath();g.moveTo(X(-1),Y(0));g.quadraticCurveTo(X(-.55),Y(.12),X(-.32),Y(.58));g.bezierCurveTo(X(-.18),Y(.98),X(.38),Y(1.12),X(.6),Y(.82));g.bezierCurveTo(X(.72),Y(.62),X(.56),Y(.42),X(.4),Y(.5));g.bezierCurveTo(X(.3),Y(.56),X(.32),Y(.7),X(.42),Y(.68));g.bezierCurveTo(X(.28),Y(.78),X(.16),Y(.6),X(.22),Y(.44));g.quadraticCurveTo(X(.14),Y(.2),X(.3),Y(0));g.closePath();
   const q=g.createLinearGradient(0,Y(1),0,Y(0));q.addColorStop(0,cols[0]);q.addColorStop(.5,cols[1]);q.addColorStop(1,'rgba(30,110,150,0)');g.save();g.globalAlpha=al;g.fillStyle=q;g.fill();g.restore();return{X,Y}};
  WV(bx-W*.55,by+6*sc,W*.7,H*.7,['#7ae0e8','#2a8aa8'],.55*fade);const F=WV(bx,by,W,H,['#d8feff','#3ab8d0'],.8*fade);
  g.save();g.globalAlpha=fade;g.strokeStyle='#effffd';g.lineCap='round';g.lineWidth=2.6*sc;g.beginPath();g.moveTo(F.X(-.45),F.Y(.4));g.quadraticCurveTo(F.X(-.36),F.Y(.62),F.X(-.28),F.Y(.7));g.bezierCurveTo(F.X(-.12),F.Y(.98),F.X(.38),F.Y(1.1),F.X(.6),F.Y(.82));g.bezierCurveTo(F.X(.72),F.Y(.62),F.X(.56),F.Y(.42),F.X(.4),F.Y(.5));g.stroke();
  g.strokeStyle='rgba(255,255,255,.55)';g.lineWidth=1.4*sc;g.beginPath();g.moveTo(F.X(-.1),F.Y(.55));g.quadraticCurveTo(F.X(.02),F.Y(.3),F.X(-.05),F.Y(.1));g.stroke();g.restore();
  for(let i=0;i<8;i++){const u=i/7,fx=F.X(-.25+u*.85),fy=F.Y(.92+.18*Math.sin(u*Math.PI))-Math.sin(el*9+i)*1.5*sc;g.save();g.globalAlpha=fade*rise;g.fillStyle='#ffffff';g.beginPath();g.arc(fx,fy,(1.6+fsRh(i)*1.6)*sc,0,TAU);g.fill();g.restore()}
  /* the crest breaks into spray */
  if(el>.45){const e2=el-.45;for(let i=0;i<14;i++){const an=-Math.PI*.15-fsRh(i)*Math.PI*.7,v=(70+fsRh(i+9)*90)*sc,dx=Math.cos(an)*v*e2,dy=Math.sin(an)*v*e2+300*sc*e2*e2;g.save();g.globalAlpha=Math.max(0,1-e2/.75);fsDropP(g,bx+W*.1+dx,by-H+dy,2.4*sc,Math.atan2(Math.sin(an)*v+600*sc*e2,Math.cos(an)*v)+Math.PI);g.fillStyle='#dffcff';g.fill();g.restore()}}
  /* the trident flash */
  if(el<.75){const f=1-el/.75,ta=G&&G.at?Math.atan2(G.at(.999).ty,G.at(.999).tx):-Math.PI/2,s=2.6*sc*(1+.3*(1-f));fsRays(g,x,y,12,84*sc,'#ffe6a0',.34*f,el*.8);
   g.save();g.translate(x,y);g.rotate(ta);g.globalCompositeOperation='lighter';g.globalAlpha=f;g.strokeStyle='#ffe27a';g.lineWidth=2.6*s/2.6;g.lineCap='round';g.beginPath();g.moveTo(-8*s,0);g.lineTo(13*s,0);g.moveTo(-4*s,0);g.bezierCurveTo(-1*s,-1*s,-1*s,-7*s,2*s,-7*s);g.lineTo(9*s,-7*s);g.moveTo(-4*s,0);g.bezierCurveTo(-1*s,1*s,-1*s,7*s,2*s,7*s);g.lineTo(9*s,7*s);g.stroke();g.restore();
   fkGlow(g,x,y,50*sc,'#fff2c0',.6*f)}
  fkGlow(g,x,y,40*sc,'#7affe0',.3*fade)}}];
/* ---------- particles (in-game, event driven) ---------- */
function fsRfAdd(p){if(FSRF.pt.length>160)return;p.life=0;FSRF.pt.push(p)}
const fsRfBob=()=>FS.bob?{x:FS.bob.x,y:FS.bob.y+(FS.bob.dip||0)*16-14}:null;
function fsRfStep(g,dt,tip){const L=FSRF.pt,bob=fsRfBob(),G=FSRF.geo;let lsPrev=null;
 for(let i=0;i<L.length;i++){const p=L[i];p.life+=dt;if(p.life>=p.max){L.splice(i--,1);continue}const u=p.life/p.max;
  if(p.k==='leaf'){p.vy=Math.min(60,p.vy+90*dt);p.vx*=1-dt*1.5;p.x+=(p.vx+Math.sin(p.life*6+p.ph)*26)*dt;p.y+=p.vy*dt;p.rot+=p.vr*dt;fsLeaf(g,p.x,p.y,p.L,p.rot,p.c,Math.min(1,(1-u)*2.5))}
  else if(p.k==='spk'){p.vy+=420*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;fkSpark(g,p.x,p.y,p.r*(1-u*.6),p.c,1-u*.7)}
  else if(p.k==='dr'){p.vy+=520*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;g.save();g.globalAlpha=1-u;fsDropP(g,p.x,p.y,p.r,Math.atan2(p.vy,p.vx)+Math.PI);g.fillStyle='#d8fcff';g.fill();g.restore()}
  else if(p.k==='gl'){fkSpark(g,p.x,p.y,p.r*Math.sin(u*Math.PI),p.c,1)}
  else if(p.k==='arc'){g.save();g.strokeStyle=p.c;g.globalAlpha=1-u;g.lineWidth=1.6;const r=8+u*22;g.lineWidth=2.2*(1-u*.5);for(let s=0;s<3;s++){g.beginPath();g.arc(p.x,p.y,r,s*TAU/3-.9,s*TAU/3-.1);g.stroke()}g.restore()}
  else if(p.k==='gear'){p.vy+=200*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.rot+=p.vr*dt;g.save();g.globalAlpha=1-u;fsGearP(g,p.x,p.y,p.r,8,p.rot);g.arc(p.x,p.y,p.r*.35,0,TAU,true);g.fillStyle='#e6b43a';g.fill('evenodd');g.lineWidth=1;g.strokeStyle=FKO;g.stroke();g.restore()}
  else if(p.k==='mr'){g.save();g.strokeStyle='#e8ecff';g.globalAlpha=(1-u)*.8;g.lineWidth=1.8*(1-u*.5);g.lineWidth=2.4*(1-u*.5);const r=8+u*52;g.beginPath();g.ellipse(p.x,p.y,r,r*.3,0,0,TAU);g.stroke();if(u<.6){const r2=r*.55;g.beginPath();g.ellipse(p.x,p.y,r2,r2*.3,0,0,TAU);g.stroke()}g.restore()}
  else if(p.k==='lm'){if(!tip||!bob){L.splice(i--,1);continue}const q=fsRfLine(tip,bob,fsRfE(u));fkGlow(g,q.x,q.y,18,p.c,.7);fkSpark(g,q.x,q.y,5.5,'#ffffff',1);if(u>.92&&!p.done){p.done=1;fsRfAdd({k:'mr',x:bob.x,y:bob.y+14,max:.7})}}
  else if(p.k==='ls'){if(!tip||!bob){L.splice(i--,1);continue}const q=fsRfLine(tip,bob,p.s),a=Math.min(1,(1-u)*2.2);if(lsPrev){g.save();g.strokeStyle=`rgba(230,222,255,${.8*Math.min(a,lsPrev.a)})`;g.lineWidth=1.6;g.beginPath();g.moveTo(lsPrev.x,lsPrev.y-10);g.lineTo(q.x,q.y-10);g.stroke();g.restore()}
   fkGlow(g,q.x,q.y-10,16,G&&G.GL||'#c8b8ff',.6*a);fkSpark(g,q.x,q.y-10,(5+5*Math.max(0,1-p.life/.15))*a+.5,'#fff6dc',a);lsPrev={x:q.x,y:q.y,a}}}}
/* ---------- per frame ---------- */
function fsRodFx(g,now){const dt=Math.min(.05,Math.max(0,now-(FSRF.T||now)));FSRF.T=now;const tier=fsTier(),FX=FSRFX[tier],G=FSRF.geo,rm=fsRM(),st=FS.st,tip=FS.view&&FS.view.tip;
 FSRF.tr=FSRF.tr.filter(p=>now-p.t<1);if(st==='cast'&&FS.fly&&!rm)FSRF.fp.push({x:FS.fly.x,y:FS.fly.y,t:now});FSRF.fp=FSRF.fp.filter(p=>now-p.t<1);
 if(!rm){if(G&&G.tier===tier&&(st==='idle'||st==='wait'||st==='reveal'))FX.aura(g,G,now);
  if(FSRF.tr.length>1)FX.trail(g,FSRF.tr,now,0);if(FSRF.fp.length>1)FX.trail(g,FSRF.fp,now,1);
  const bob=fsRfBob();if((st==='reel'||st==='stage')&&tip&&bob)FX.reel(g,tip,bob,now,dt)}
 if(st==='show'&&FS.t0!==FSRF.showT0){FSRF.showT0=FS.t0;FSRF.fl={t0:now,tier}}
 const F=FSRF.fl;if(F){const el=now-F.t0;if(el>1.25)FSRF.fl=null;else if(tip){if(rm)fkGlow(g,tip.x,tip.y,60,G?G.GL:'#fff2c0',.4*(1-el/1.25));else FSRFX[F.tier].flourish(g,tip.x,tip.y,el,1,G,1)}}
 if(rm)FSRF.pt=[];else fsRfStep(g,dt,tip)}
function fsRfLetter(){if(fsRM())return;const tip=FS.view&&FS.view.tip;if(!tip)return;FSRFX[fsTier()].letter(tip,fsRfBob(),FSRF.geo)}
/* ---------- hooks ---------- */
{const o=fsHero;fsHero=function(g,t,V){o(g,t,V);FSRF.geo=FSRODG}}
{const o=fsMotionFx;fsMotionFx=function(g,now){const tr=FS.trail||[];if(tr.length)FSRF.tr.push(...tr);FS.trail=[];o(g,now);try{fsRodFx(g,now)}catch(e){console.error(e)}}}
{const o=fsType;fsType=function(ch){const st=FS.st,ty=FS.typed,si=FS.si;o(ch);if(st==='reel'&&(FS.typed!==ty||FS.si!==si||FS.st!==st)){try{fsRfLetter()}catch(e){console.error(e)}}}}
{const o=fsStart;fsStart=function(){FSRF.pt=[];FSRF.tr=[];FSRF.fp=[];FSRF.fl=null;FSRF.swirl=0;return o.apply(this,arguments)}}
/* ---------- the Rod Workshop showcase: a 4.4 s loop (idle shimmer, a cast flick with the trail, a bite on a taut line, the bobber
   reeled home under a splash, the catch flourish) ---------- */
const FSRS_L=4.4,FSRS_FL=3.2;
const FSRS_KF=[[0,-.2,0],[1.4,-.2,0],[1.75,-.45,0],[1.84,-.27,.36],[1.95,.03,.14],[2.3,-.14,0],[2.75,-.14,0],[2.84,-.12,.16],[2.95,-.13,.06],[3.02,-.11,.24],[3.18,-.34,.4],[3.36,-.28,.16],[3.95,-.2,0],[4.4,-.2,0]];
/* the hand also steps back and pushes forward a little, out of phase with the swing, so the tip sweeps a rounded arc */
const FSRS_DX=[[0,0],[1.4,0],[1.64,-18],[1.86,16],[2.05,8],[2.5,0],[4.4,0]];
function fsRsPose(x){const K=FSRS_KF,D=FSRS_DX;let dx=0;for(let i=1;i<D.length;i++)if(x<=D[i][0]){const k=(x-D[i-1][0])/(D[i][0]-D[i-1][0]||1);dx=D[i-1][1]+(D[i][1]-D[i-1][1])*k*k*(3-2*k);break}
 for(let i=1;i<K.length;i++)if(x<=K[i][0]){const A=K[i-1],B=K[i],k=(x-A[0])/(B[0]-A[0]||1),e=k*k*(3-2*k);return{a:A[1]+(B[1]-A[1])*e,b:A[2]+(B[2]-A[2])*e,dx}}return{a:-.2,b:0,dx:0}}
function fsRodShowcase(g,cx,cy,w,h,t,tier,sk){tier=tier==null?fsTier():tier;sk=sk||fsSkin();t=t||0;const FX=FSRFX[tier],VW=460,VH=170,s=Math.min(w/VW,h/VH),rm=fsRM(),lt=rm?.5:((t%FSRS_L)+FSRS_L)%FSRS_L;
 const HX=-188,HY=50,LEN=226,tipAt=x=>{const P=fsRsPose(x);return{x:HX+P.dx+Math.cos(P.a)*LEN+P.b*LEN*.08,y:HY+Math.sin(P.a)*LEN+P.b*LEN*.34}};
 const R0=tipAt(1.9),BT={x:176,y:72},bobAt=x=>{const k=Math.min(1,(x-1.9)/.5);return{x:R0.x+(BT.x-R0.x)*k,y:R0.y+(BT.y-R0.y)*k-Math.sin(k*Math.PI)*70}};
 g.save();g.beginPath();g.rect(cx-w/2,cy-h/2,w,h);g.clip();g.translate(cx,cy);g.scale(s,s);
 const P=fsRsPose(lt),sway=lt<1.4||lt>3.95?Math.sin(t*1.2)*.012:0,ring=(x,y,r,al,lw)=>{g.strokeStyle=`rgba(216,232,255,${al})`;g.lineWidth=lw;g.beginPath();g.ellipse(x,y,r,r*.3,0,0,TAU);g.stroke()};
 /* the water hint and the bite ripples */
 if(lt>=2.4&&lt<3.7){const k=Math.min(1,(lt-2.4)/.3,(3.7-lt)/.3);g.save();ring(BT.x,BT.y+4,16+6*Math.sin(t*2.4),.25*k,1.2);g.restore()}
 if(lt>=2.8&&lt<3.45){g.save();for(let j=0;j<2;j++){const k=(lt-2.8-j*.16)/.5;if(k>0&&k<1)ring(BT.x,BT.y+3,6+k*34,.8*(1-k),2-j*.6)}g.restore()}
 const tip=fsRod(g,HX+P.dx,HY,P.a+sway,P.b,LEN,t,sk,tier),G=FSRODG;
 /* the line and bobber: flight, rest, nibble, bite on a taut line, then reeled home */
 if(lt>=1.9&&lt<3.36){const fly=lt<2.4,home=lt>=3.18,taut=lt>=2.84;let b;
  if(fly)b=bobAt(lt);else if(home){const k=fsRfE((lt-3.18)/.18);b={x:BT.x+(tip.x-BT.x)*k,y:BT.y+(tip.y+5-BT.y)*k-Math.sin(k*Math.PI)*26}}
  else{const dip=lt<2.84?Math.sin(t*2.4)*1.4:lt<2.95?4*Math.sin((lt-2.84)/.11*Math.PI):Math.min(7,(lt-2.95)*90);b={x:BT.x-(taut?Math.min(4,(lt-2.84)*30):0),y:BT.y+dip}}
  g.save();g.strokeStyle=sk.ln;g.globalAlpha=.85;g.lineWidth=taut?1.5:1.3;g.beginPath();g.moveTo(tip.x,tip.y);g.quadraticCurveTo((tip.x+b.x)/2,(tip.y+b.y)/2+(fly?-10:taut?2:18),b.x,b.y-5);g.stroke();g.restore();
  const sq=!fly&&!home&&lt>=2.95?.82:1;g.save();g.translate(b.x,b.y-1);if(fly||home)g.rotate(t*14);g.scale(1,sq);g.beginPath();g.arc(0,0,5.5,0,TAU);g.fillStyle=sk.bob[1];g.fill();g.beginPath();g.arc(0,0,5.5,Math.PI,TAU);g.fillStyle=sk.bob[0];g.fill();g.lineWidth=1.8;g.strokeStyle=FKO;g.beginPath();g.arc(0,0,5.5,0,TAU);g.stroke();g.restore()}
 /* the splash as the bobber leaves the water */
 if(lt>=3.16&&lt<3.62){const e=lt-3.16,k=e/.46;g.save();ring(BT.x,BT.y+3,8+k*22,.7*(1-k),1.6);g.fillStyle='#e8f4ff';for(let i=0;i<7;i++){const an=-Math.PI*.5+(i-3)*.32,v=60+fsRh(i+tier*7)*50,x=BT.x+Math.cos(an)*v*e,y=BT.y+Math.sin(an)*v*e+260*e*e;g.globalAlpha=Math.max(0,1-k);g.beginPath();g.arc(x,y,2.2-k,0,TAU);g.fill()}g.restore()}
 if(!rm){
  if(lt<1.4||lt>3.95)FX.aura(g,G,t);
  const tg=Math.floor(lt*60)/60,tr=[],fp=[];for(let k=0;k<70;k++){const tk=tg-k/60;if(tk<1.4)break;if(tk<=1.98){const q=tipAt(tk);tr.push({x:q.x,y:q.y,t:tk})}if(tk>=1.9&&tk<=2.4){const q=bobAt(tk);fp.push({x:q.x,y:q.y,t:tk})}}
  tr.reverse();fp.reverse();if(tr.length>1)FX.trail(g,tr,lt,0,.55);if(fp.length>1)FX.trail(g,fp,lt,1);
  if(lt>=FSRS_FL)FX.flourish(g,tip.x,tip.y,lt-FSRS_FL,.85,G)}
 g.restore()}
