/* ---------- the vault dragon: building the layers and running the idle animation ---------- */
let CDS=null;
const VHP=[VX,VY+120];                       /* neck pivot for the head */
const VHAND=[[-42,26],[-14,30],[14,30],[42,26]];
function cdBuild(){const K={};
 K.bg=cdLayer(0,0,1600,900,g=>vBack(g));
 K.piles=cdLayer(0,380,1600,220,g=>vPiles(g));
 K.wingR=cdLayer(1180,-90,460,570,g=>cdWing(g,[VX+170,352],[VX+318,168],[VX+430,14],[[VX+500,150],[VX+476,262],[VX+400,350],[VX+290,400]],true));
 K.wingL=cdLayer(560,-90,460,570,g=>cdWing(g,[VX-170,352],[VX-318,168],[VX-424,20],[[VX-486,156],[VX-462,266],[VX-390,352],[VX-286,398]],true));
 K.body=vBodyLayer();K.armR=vArmLayer(1);K.armL=vArmLayer(-1);
 K.arch=vArchLayer();K.palmR=vPalmLayer(1);K.palmL=vPalmLayer(-1);
 K.fin=[];for(const s of[1,-1])K.fin.push(VHAND.map((h,i)=>({L:vFingerLayer(28,h[1],60+i+s*7),bx:VX+s*238+h[0],by:414+(i===1||i===2?0:3),a:-h[0]/42*.16,ph:i*1.7+(s>0?0:.9)})));
 K.hback=cdLayer(VX-380,-100,760,520,g=>vHornsBack(g));
 K.skull=cdLayer(VX-200,VY-240,400,390,g=>{vSkull(g);vSockets(g)});
 K.jaw=cdLayer(VX-150,VY+50,300,210,g=>vJaw(g));
 K.muz=cdLayer(VX-110,VY-110,220,290,g=>vMuzzle(g));
 K.brow=cdLayer(VX-170,VY-170,340,140,g=>vBrows(g));
 const sm=(c0,c1)=>{const c=cdMk(96,96),g=c.getContext('2d');g.fillStyle=rgr(g,48,48,0,48,c0,c1);g.fillRect(0,0,96,96);return c};
 K.smoke=sm('rgba(236,214,196,.7)','rgba(150,120,110,0)');K.hot=sm('rgba(255,170,70,.9)','rgba(255,60,10,0)');
 /* scale glints: head-local points (x,y,phase,size) and loose coin glints in the hoard */
 K.gl=[[-84,-60,.2,7],[72,-34,1.9,6],[-30,30,3.1,5],[104,52,4.4,6],[10,-70,5.2,5],[-110,30,2.6,5],[56,6,.9,4]];
 K.sp=[];for(let i=0;i<30;i++)K.sp.push({x:i<14?630+rnd(i*7)*190:i<24?1380+rnd(i*3)*210:900+rnd(i)*200,y:i<14?420+rnd(i*5)*80:i<24?400+rnd(i*9)*100:470+rnd(i*2)*20,p:rnd(i*11)*TAU,s:4+rnd(i*13)*8});
 return K}
const vEase=u=>u<=0?0:u>=1?1:u*u*(3-2*u);
function cdScene(c,still){const g=c.getContext('2d');if(!CDS)CDS=cdBuild();const K=CDS;
 const PT=[],mote=[];for(let i=0;i<26;i++)mote.push({x:640+rnd(i*3)*960,y:rnd(i*5)*480,v:5+rnd(i*7)*12,r:1+rnd(i*9)*2,p:rnd(i)*TAU});
 let last=0,acc=0,acc2=0;
 const dl=(L,ox,oy)=>g.drawImage(L.c,L.x+(ox||0),L.y+(oy||0));
 return t0=>{const now=still?2.35:performance.now()/1000,dt=still?0:Math.min(.1,now-last||.033);last=now;const t=now;
  const T=5.6,ph=(t%T)/T;
  /* lungs: slow fill, brief hold, long exhale */
  const bf=ph<.42?(1-Math.cos(Math.PI*ph/.42))/2:ph<.54?1:(1+Math.cos(Math.PI*(ph-.54)/.46))/2;
  const ex=ph>.54?Math.sin(Math.PI*(ph-.54)/.46):0;
  const fl=.86+.08*Math.sin(t*9.3)+.06*Math.sin(t*23.1+1);
  g.setTransform(1,0,0,1,0,0);g.globalAlpha=1;g.globalCompositeOperation='source-over';
  dl(K.bg);
  g.globalCompositeOperation='lighter';cdGlow(g,VX,220,560,'rgba(255,120,36,'+(.16+.07*bf+.04*ex)+')');g.globalCompositeOperation='source-over';
  /* wings: slow flex with an occasional stretch */
  const fx=Math.pow(Math.max(0,Math.sin(t*.53)),10)*.02,fy=Math.pow(Math.max(0,Math.sin(t*.53+2.1)),10)*.02;
  const wr=(L,px,py,a)=>{g.save();g.translate(px,py);g.rotate(a);g.translate(-px,-py);dl(L);g.restore()};
  wr(K.wingR,VX+170,352,-.008*bf+Math.sin(t*.7)*.005-fx);wr(K.wingL,VX-170,352,.008*bf+Math.sin(t*.7+1.3)*.005+fy);
  /* chest and throat swell */
  const sx=1+.011*bf,sy=1+.022*bf;
  g.save();g.translate(VX,520);g.scale(sx,sy);g.translate(-VX,-520);dl(K.body);g.restore();
  /* shoulders rise on the in-breath */
  for(const s of[1,-1]){const L=s>0?K.armR:K.armL,px=VX+s*232,py=348;g.save();g.translate(px,py-3.2*bf);g.rotate(s*(.006*bf-.003));g.translate(-px,-py);dl(L);g.restore()}
  /* head group */
  const hox=Math.sin(t*.23)*3+Math.sin(t*.61)*1.2,hoy=-3.5*bf+Math.sin(t*.37)*1.4;
  const look=vEase(Math.sin(t*.29)*2.2+.5)*2-1+Math.sin(t*.11)*.3;                 /* slow glances */
  const rot=Math.sin(t*.31)*.013+Math.sin(t*.77+1)*.005+look*.012;
  const ca=Math.cos(rot),sa=Math.sin(rot),hw=(x,y)=>{const dx=x-VHP[0],dy=y-VHP[1];return[VHP[0]+hox+dx*ca-dy*sa,VHP[1]+hoy+dx*sa+dy*ca]};
  g.save();g.translate(VHP[0]+hox,VHP[1]+hoy);g.rotate(rot);g.translate(-VHP[0],-VHP[1]);
  /* frills and horns drift slightly out of step with the skull */
  g.save();g.translate(VX,VY-20);g.rotate(Math.sin(t*.9)*.004);g.translate(-VX,-VY+20);dl(K.hback,0,Math.sin(t*.8)*.8);g.restore();
  dl(K.skull);
  /* eyes */
  const bl=(()=>{const u=(t+1.3)%5.3;return u<.22?Math.sin(u/.22*Math.PI):0})()*(1)+(()=>{const u=(t+4.1)%13.7;return u<.18?Math.sin(u/.18*Math.PI)*.8:0})();
  const blk=Math.min(1,bl);
  for(const s of[1,-1]){const ex0=66*s,ey0=-24;
   g.save();g.translate(VX,VY);g.beginPath();vEyePath(g,s);g.clip();
   g.fillStyle=rgr(g,ex0+look*5*s*0,ey0,2,50,'#fff4a8','#d8480c');g.fillRect(ex0-60,ey0-40,120,80);
   g.fillStyle=rgr(g,ex0,ey0-2,6,40,'#ffd060','#8a1c04');g.globalAlpha=.55;g.fillRect(ex0-60,ey0-40,120,80);g.globalAlpha=1;
   g.save();g.translate(ex0+look*4,ey0+1);g.rotate(.15*s);g.beginPath();g.ellipse(0,0,4.4,13.5,0,0,TAU);g.fillStyle='#0e0100';g.fill();g.restore();
   g.fillStyle='#fffbe0';g.beginPath();g.arc(ex0-6*s+look*3,ey0-5,2.6,0,TAU);g.fill();
   const yi=-27+blk*28;g.beginPath();g.moveTo(10*s,-70);g.lineTo(130*s,-70);g.lineTo(130*s,yi-19);g.lineTo(10*s,yi);g.closePath();g.fillStyle=hgr(g,0,130,'#e8b040','#c08024');g.fill();
   g.beginPath();g.moveTo(10*s,yi);g.lineTo(130*s,yi-19);g.lineWidth=3;g.strokeStyle='#190601';g.stroke();
   cdIn(g,gg=>vEyePath(gg,s),'rgba(20,2,0,.8)',0,-3,10);
   g.restore();
   g.save();g.translate(VX,VY);g.beginPath();vEyePath(g,s);g.lineWidth=3.2;g.strokeStyle='#190601';g.stroke();g.restore()}
  /* open mouth: a dark throat with fire inside, the lower jaw drops slightly on every exhale */
  const gro=Math.pow(Math.max(0,Math.sin(t*.37+.4)),14),d=9+3*(1-bf)+9*ex+7*gro;
  const jt=[];for(let i=0;i<vJawTop.length;i+=2)jt.push(VX+vJawTop[i],VY+vJawTop[i+1]+d);
  const jr=[];for(let i=jt.length-2;i>=0;i-=2)jr.push(jt[i],jt[i+1]);
  const mouth=gg=>{const tp=[-108,60,-86,80,-44,92,0,86,44,92,86,80,108,60].map((v,i)=>i&1?VY+v:VX+v);gg.moveTo(tp[0],tp[1]);cdCR(gg,tp,false,false);gg.lineTo(jt[jt.length-2],jt[jt.length-1]);cdCR(gg,jr,false,false);gg.closePath()};
  g.save();g.beginPath();mouth(g);g.fillStyle='#240308';g.fill();g.clip();
  g.fillStyle=rgr(g,VX,VY+112+d,4,110,'#ffb040','#4a0a10');g.globalAlpha=.55+.4*ex+.1*bf;g.fillRect(VX-130,VY+50,260,130);g.globalAlpha=1;
  g.beginPath();g.ellipse(VX,VY+122+d*.8,48,10,0,0,TAU);g.fillStyle='#b82840';g.fill();g.beginPath();g.ellipse(VX,VY+119+d*.8,34,4,0,0,TAU);g.fillStyle='rgba(255,170,170,.5)';g.fill();
  g.globalCompositeOperation='lighter';
  for(let i=0;i<5;i++){const fxp=VX-44+i*22,h=(12+26*ex)*(.7+.3*Math.sin(t*14+i*2));mFl(g,fxp,VY+112+d,h*1.4,6+4*ex,t,i,'rgba(255,170,40,'+(.3+.4*ex)+')','rgba(255,240,170,'+(.3+.4*ex)+')')}
  g.globalCompositeOperation='source-over';g.restore();
  dl(K.jaw,0,d);dl(K.muz);dl(K.brow);
  /* sweeping highlight and sparkles across the scales */
  const sw=((t%11)/11-.12)/.76;
  if(sw>0&&sw<1){g.save();g.translate(VX,VY);g.beginPath();vCran(g);g.clip();g.globalCompositeOperation='lighter';
   const x0=-190+sw*380,gq=g.createLinearGradient(x0-50,-60,x0+50,60);gq.addColorStop(0,'rgba(255,230,150,0)');gq.addColorStop(.5,'rgba(255,236,160,'+.2*Math.sin(sw*Math.PI)+')');gq.addColorStop(1,'rgba(255,230,150,0)');
   g.fillStyle=gq;g.fillRect(-200,-150,400,320);g.restore()}
  g.globalCompositeOperation='lighter';
  for(const p of K.gl){const v=Math.pow(Math.max(0,Math.sin(t*1.3+p[2]*2.1)),12);if(v<.05)continue;const q=hw(VX+p[0],VY+p[1]),r=p[3]*v;g.fillStyle='rgba(255,248,200,'+(.85*v)+')';
   g.beginPath();g.moveTo(q[0],q[1]-r*2);g.lineTo(q[0]+r*.3,q[1]-r*.3);g.lineTo(q[0]+r*2,q[1]);g.lineTo(q[0]+r*.3,q[1]+r*.3);g.lineTo(q[0],q[1]+r*2);g.lineTo(q[0]-r*.3,q[1]+r*.3);g.lineTo(q[0]-r*2,q[1]);g.lineTo(q[0]-r*.3,q[1]-r*.3);g.closePath();g.fill()}
  /* molten eyes, ruby and firelight on the lower face */
  for(const s of[1,-1]){const q=[VX+66*s,VY-24];cdGlow(g,q[0],q[1],62+5*Math.sin(t*2.2+s),'rgba(255,150,40,'+(.3*(1-blk*.8)+.05)+')')}
  cdGlow(g,VX,VY-100,40,'rgba(255,40,70,'+(.22+.14*Math.sin(t*2.6))+')');
  cdGlow(g,VX,VY+120,150,'rgba(255,120,30,'+(.1*fl+.08*ex)+')');
  g.globalCompositeOperation='source-over';
  g.restore();
  /* the vault arch and the claws that grip it */
  dl(K.arch);
  for(let si=0;si<2;si++){const s=si?-1:1;dl(s>0?K.palmR:K.palmL);
   const shift=vEase(Math.sin(t*.21+si*2.4)*3-1.6)*.05;
   for(const f of K.fin[si]){g.save();g.translate(f.bx,f.by);g.rotate(f.a+Math.sin(t*.45+f.ph)*.022+shift*(f.ph>2?1:-.6)*s);dl(f.L);g.restore()}}
  /* hoard */
  dl(K.piles);
  /* smoke from the nostrils on the out-breath, embers from the throat */
  if(!still){acc+=dt;acc2+=dt;
   if(ex>.12&&acc>.07){acc=0;for(const s of[1,-1]){const p=hw(VX+24*s,VY+58);PT.push({k:0,x:p[0],y:p[1],vx:s*(14+Math.random()*30),vy:-26-Math.random()*30,a:0,l:2.6+Math.random()*1.4,r0:4,r1:40+Math.random()*34})}
    if(ex>.3&&Math.random()<.5){const p=hw(VX-50+Math.random()*100,VY+100);PT.push({k:1,x:p[0],y:p[1],vx:-40+Math.random()*80,vy:-40-Math.random()*70,a:0,l:.9+Math.random()*.8,r0:2.2,r1:1})}}
   /* a thin idle wisp even between breaths, and sparse embers off the hoard and torches */
   if(acc2>.5){acc2=0;const s=Math.random()<.5?1:-1,p=hw(VX+24*s,VY+58);PT.push({k:0,x:p[0],y:p[1],vx:-10*s,vy:-12,a:0,l:2.2,r0:5,r1:26});
    if(Math.random()<.6){const q=Math.random()<.5?[VTORCH[Math.random()<.5?0:1][0],270]:[1400+Math.random()*160,430];PT.push({k:1,x:q[0],y:q[1],vx:-8+Math.random()*16,vy:-28-Math.random()*30,a:0,l:1.8+Math.random(),r0:1.8,r1:1})}}
   for(let i=PT.length-1;i>=0;i--){const p=PT[i];p.a+=dt;if(p.a>p.l){PT.splice(i,1);continue}const u=p.a/p.l;p.x+=p.vx*dt;p.y+=p.vy*dt;p.vx*=.99;p.vy-=5*dt;
    if(p.k===0){const r=p.r0+(p.r1-p.r0)*Math.sqrt(u);g.globalAlpha=Math.min(1,u*10)*(1-u)*.55;g.drawImage(K.smoke,p.x-r,p.y-r,r*2,r*2);
     if(u<.3){g.globalCompositeOperation='lighter';g.globalAlpha=(.3-u)*.9;g.drawImage(K.hot,p.x-r*.7,p.y-r*.7,r*1.4,r*1.4);g.globalCompositeOperation='source-over'}}
    else{g.globalCompositeOperation='lighter';g.globalAlpha=1-u;g.fillStyle='#ffb040';g.beginPath();g.arc(p.x,p.y,p.r0*(1-u*.6),0,TAU);g.fill();g.globalCompositeOperation='source-over'}}
   g.globalAlpha=1}
  /* torches */
  g.globalCompositeOperation='lighter';
  for(let i=0;i<VTORCH.length;i++){const q=VTORCH[i],f2=.8+.2*Math.sin(t*11+i*3)+.1*Math.sin(t*17+i);cdGlow(g,q[0],q[1]-34,120*f2,'rgba(255,140,40,.42)');
   for(let k=0;k<3;k++)mFl(g,q[0]+(k-1)*6,q[1]-18,(50-k*11)*f2,12-k*2,t,i*3+k,k===0?'rgba(255,120,20,.85)':k===1?'rgba(255,190,60,.9)':'rgba(255,245,190,.95)','rgba(255,240,170,.8)')}
  /* coin glints */
  for(const s of K.sp){const v=Math.pow(Math.max(0,Math.sin(t*1.7+s.p)),6);if(v<.05)continue;const r=s.s*v;g.fillStyle='rgba(255,246,190,'+(.9*v)+')';
   g.beginPath();g.moveTo(s.x,s.y-r*2);g.lineTo(s.x+r*.3,s.y-r*.3);g.lineTo(s.x+r*2,s.y);g.lineTo(s.x+r*.3,s.y+r*.3);g.lineTo(s.x,s.y+r*2);g.lineTo(s.x-r*.3,s.y+r*.3);g.lineTo(s.x-r*2,s.y);g.lineTo(s.x-r*.3,s.y-r*.3);g.closePath();g.fill()}
  /* drifting gold dust */
  for(const m of mote){if(!still){m.y-=m.v*dt;if(m.y<-10){m.y=490;m.x=640+Math.random()*960}}const al=.22+.2*Math.sin(t*1.3+m.p);g.fillStyle='rgba(255,210,110,'+al+')';g.beginPath();g.arc(m.x+Math.sin(t*.6+m.p)*12,m.y,m.r,0,TAU);g.fill()}
  g.globalCompositeOperation='source-over'}}

/* a dimmed still of the vault, used behind the game screens */
let CDCAVE='';
function cdCave(){if(!CDCAVE){try{const c=cdMk(1600,900);cdScene(c,true)(0);
 const s=cdMk(960,540),sg=s.getContext('2d');sg.drawImage(c,0,0,960,540);sg.fillStyle='rgba(10,2,8,.45)';sg.fillRect(0,0,960,540);CDCAVE='url('+s.toDataURL('image/jpeg',.8)+')'}catch(e){console.error(e)}}
 if(CDCAVE)ov.style.setProperty('--cavebg',CDCAVE)}
