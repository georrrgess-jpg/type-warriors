/* ===== WILDCARD: casino listing (NEW tag), Special tab feature and the look of every Wildcard screen ===== */
TCAT.wc='cards';
TA.wc=(()=>{const c=(s,v,x,y,r)=>`<g transform="translate(${x} ${y}) rotate(${r}) scale(.62)"><g transform="translate(-50 -73)">${wcSVG({s,v,id:0}).replace(/<\/?svg[^>]*>/g,'')}</g></g>`;
 return `<svg viewBox="0 0 320 176" preserveAspectRatio="xMidYMid slice"><defs><radialGradient id="wcta" cx=".5" cy=".7" r=".8"><stop offset="0" stop-color="#2c7a52"/><stop offset=".6" stop-color="#164030"/><stop offset="1" stop-color="#081a14"/></radialGradient></defs>
 <rect width="320" height="176" fill="url(#wcta)"/><ellipse cx="160" cy="190" rx="200" ry="90" fill="none" stroke="#c8963a" stroke-width="3" opacity=".6"/>
 ${c('e','7',96,96,-18)}${c('t','d2',140,84,-6)}${c('s','turn',184,84,6)}${c('w','wild',228,96,18)}
 <g fill="#ffd45a"><path d="M40 30l3 7 7 3-7 3-3 7-3-7-7-3 7-3z"/><path d="M286 40l2 5 5 2-5 2-2 5-2-5-5-2 5-2z"/></g></svg>`})();
GAMES.unshift({id:'wc',n:'Wildcard',d:'NEW · The Dragon Lounge card game. Match the element or the number and be first to empty your hand. Play the lounge regulars, or friends with a room code.',m:()=>wcHome()});
{const g0=gameOpen;gameOpen=function(id){if(id==='wc'){CAS.tok++;cFlush();wcHome();return}return g0.apply(this,arguments)}}
function wcFeat(){const W=wcSt();return `<div class="twfeat wcfeat"><button class="twfart" data-g="wc" aria-label="Play Wildcard"><span class="twfa">${TA.wc}</span><i class="co c1"></i><i class="co c2"></i><i class="co c3"></i><i class="co c4"></i><span class="twrib wcrib">UPDATE 8.2</span></button>
 <div class="twfinfo"><div class="twfk"><span class="twbadge wcbadge">CARD GAME</span><span class="twnew">NEW</span></div><h3>Wildcard</h3>
 <p>Match the element or the number, stun and hex the lounge regulars, and shout WILD! before your last card.</p>
 <ul class="twfl"><li><b>Solo</b> four tables, buy-ins from 50 to 2,500</li><li><b>Friends</b> same screen, or a 4-letter room code</li><li><b>Regulars</b> monsters in their sharpest suits</li></ul></div>
 <div class="twfside"><div class="twfs"><span>Games</span><b>${cmn(W.g)}</b></div><div class="twfs"><span>Wins</span><b>${cmn(W.w)}</b></div><div class="twfs"><span>Best streak</span><b>${W.best||'–'}</b></div><button class="twplay" data-g="wc">Play now</button></div></div>`}
{const c0=dkCorner;dkCorner=function(){const r=c0.apply(this,arguments);try{const c=$('cn');if(c&&ov.classList.contains('wcx')&&!ov.classList.contains('hide'))c.classList.add('dkhid')}catch(e){}return r}}
{const t0=twLobby;twLobby=function(){const sp=CAS.sp||'wc';if(sp!=='wc'){t0.apply(this,arguments)}else{const g=$('gdgrid');g.className='gdgrid twspecial';g.innerHTML=wcFeat()+`<div class="nssw"><button data-sp="ns">Nebula Scratch</button><button data-sp="tw">Tower Climb</button></div>`;g.querySelectorAll('[data-g]').forEach(x=>x.onclick=()=>wcHome())}
 const sw=$('gdgrid').querySelector('.nssw');if(sw){sw.querySelectorAll('em').forEach(e=>e.remove());const b=document.createElement('button');b.dataset.sp='wc';b.className=sp==='wc'?'on':'';b.innerHTML='<i class="nsdot"></i>Wildcard<em>NEW</em>';sw.prepend(b);
  sw.querySelectorAll('button').forEach(x=>{x.classList.toggle('on',x.dataset.sp===sp);x.onclick=e=>{e.stopPropagation();if(x.dataset.sp===(CAS.sp||'wc'))return;CAS.sp=x.dataset.sp;beep(620,.05,'triangle',.5);twLobby()}})}}}


/* Wildcard screens are fully opaque, so the game's background canvas is not redrawn behind them (it is invisible there) */
{const d0=draw;draw=function(){if(S.mode==='title'&&ov.classList.contains('wcx')&&!ov.classList.contains('hide'))return;return d0.apply(this,arguments)}}
