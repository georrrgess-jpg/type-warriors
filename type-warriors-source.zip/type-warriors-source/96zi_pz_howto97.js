/* ===== 9.7 THE CROOKED CUE: How to Play, restyled to the concept art (96zi) =====
   The How to Play screen (96v) rebuilt to the owner's concept art:
   - a wooden "How to Play" sign hanging over the bar, "The bar" back button, a row of five tabs with the gold
     active tab, one big indigo glass panel, two regulars peeking over a table rail in the bottom corners (a new pair
     pops up on every tab) and Replay the tutorials / Try it at the Practice Table at the foot of the panel;
   - Basics: three numbered cards (Solids or stripes, Then the 8, Win the race);
   - Shooting: a big table showing the guide (the cue pulls back and strikes on a loop, the dashes flow), an
     Aim / Power / Spin selector that switches the detail panel beside it, and three small cards;
   - Fouls: Scratch and Wrong ball first, a gold arrow to "Opponent gets ball in hand", and the other fouls;
   - Guide & extras: the 9.6 guide (Full / Short / Pro, G switches), taunts, fast-forward, shot clock, house rules;
   - Controls: a table with the six pockets numbered as the game numbers them (1-3 along the top, 4-6 along the
     bottom), Aim / Shoot / Spin / Call / Guide cards and the Essential / Advanced key lists (every binding is
     checked against the input code by t_pz97b.py).
   Art is drawn once per size into cached canvases. Every loop is a CSS transform/opacity animation (flowing guide
   dashes, the cue's pull and strike, the regulars' bob and breath); the only LIVE entries are the two regulars, which
   check their blink every 4th frame and repaint only when the eyes close or open. About 0.5-1.3 ms a frame
   unthrottled, 3-3.5 ms at 4x CPU throttling (the hub: about 22 ms).
   The pause menu shows the same tabs in a wide modal. Overrides pzHowBody, pzHowWire, pzRules and pzRulesModal
   (96v) and keeps their hooks: #pzr, #pzbk, .pzhtabs button[data-h], #pzhbody, .pzhcard canvas, .pzhowk>div,
   #pzhre, #pzhpr, and the left/right tab keys. */
const PZW={art:{},meta:{},sub:'power',fw:0};
const PZW_TABS=[['basics','Basics'],['shoot','Shooting'],['fouls','Fouls'],['extras','Guide & extras'],['keys','Controls']];
const PZW_BC=['#fbf6ea','#f6c21a','#2b5fd9','#e0262e','#7a35c0','#f27a1a','#1e9a4a','#8e2a1e','#1d1724'];
/* who peeks from the corners on each tab: [id, expression, prop] (props: a cue on the left, a mug on the right) */
const PZW_MON={basics:[['grizzle','happy','cue'],['vesper','happy','']],shoot:[['gloop','happy',''],['barnacle','wow','mug']],fouls:[['vesper','smug','cue'],['grizzle','smug','mug']],extras:[['moldwick','happy',''],['gloop','cheer','']],keys:[['vesper','happy','cue'],['barnacle','smug','mug']]};
/* the key lists of the Controls tab: [keys, what it does, probe name used by t_pz97b.py] */
const PZW_KEYS={ess:[['Mouse','Aim; press, pull back and let go to shoot','mouse'],['Space / Enter','Shoot with the power bar; hold to fast-forward <em>while balls are moving</em>','space'],['1 – 6','Call a pocket for the 8 (or click the pocket)','call'],['Esc','Menu (pause, rules, settings, forfeit)','esc']],
 adv:[['Shift / right mouse button','Fine aim (slow mouse)','fine'],['Wheel / <i class="pzw-ar">◀ ▶</i>','Nudge the aim (Shift for tiny steps)','nudge'],['<i class="pzw-ar">▲ ▼</i>','Set the power bar (Shift: finer)','power'],['W A S D / R','Set the spin / reset it','spin'],['G','Change the guide (Full, Short, Pro)','guide'],['Arrows + Space','Ball in hand: move it, then place it','place']]};
const pzwN=(x,y)=>{const l=Math.hypot(x,y)||1;return [x/l,y/l]};
const pzwCv=(k,w,h,cls,st)=>`<canvas class="${cls||''}" data-art="${k}" data-w="${w}" data-h="${h}" width="${w*2}" height="${h*2}" style="width:${w}px;height:${h}px;${st||''}"></canvas>`;
const pzwOv=(k,w,h)=>`<div class="pzw-flow" data-flow="${k}" style="width:${w}px;height:${h}px"></div>`;
const pzwA0=c=>pzRgba(c).replace(/,1\)$/,',0)');
/* ---------------------------------------------------------------- painters ---------------------------------------------------------------- */
function pzwTG(x,y,w,h,o){o=o||{};const rt=o.rt||Math.round(Math.max(9,Math.min(w,h)*.1)),fx=x+rt,fy=y+rt,fw=w-rt*2,fh=h-rt*2,pr=o.pr||Math.max(5,rt*.6);
 return {x,y,w,h,rt,fx,fy,fw,fh,pr,pk:[[fx+1,fy+1],[fx+fw/2,fy-1.5],[fx+fw-1,fy+1],[fx+1,fy+fh-1],[fx+fw/2,fy+fh+1.5],[fx+fw-1,fy+fh-1]]}}
function pzwTable(g,T,o){o=o||{};const {x,y,w,h,rt,fx,fy,fw,fh,pr}=T,R=Math.min(rt*1.1,24);g.save();g.lineJoin='round';g.lineCap='round';
 g.fillStyle='rgba(6,2,16,.45)';pzRR(g,x+2,y+5,w,h,R);g.fill();
 g.fillStyle=pzLin(g,0,y,0,y+h,[[0,'#b2692a'],[.45,'#8a481a'],[1,'#5a2a0c']]);pzRR(g,x,y,w,h,R);g.fill();
 /* wood grain along the rails */
 g.save();pzRR(g,x,y,w,h,R);g.clip();g.lineWidth=1;
 for(let i=0;i<5;i++){const a=i/5;g.strokeStyle=`rgba(255,214,150,${.06+.05*(i%2)})`;
  for(const yy of[y+rt*(.18+a*.7),y+h-rt*(.18+a*.7)]){g.beginPath();g.moveTo(x,yy);g.bezierCurveTo(x+w*.33,yy+1.4,x+w*.66,yy-1.4,x+w,yy+.4);g.stroke()}
  for(const xx of[x+rt*(.18+a*.7),x+w-rt*(.18+a*.7)]){g.beginPath();g.moveTo(xx,y);g.bezierCurveTo(xx+1.2,y+h*.4,xx-1.2,y+h*.6,xx,y+h);g.stroke()}}
 g.restore();
 g.strokeStyle='rgba(255,226,170,.4)';g.lineWidth=1.5;pzRR(g,x+3,y+3,w-6,h-6,Math.max(2,R-3));g.stroke();
 g.strokeStyle=PZ_O;g.lineWidth=o.lw||3;pzRR(g,x,y,w,h,R);g.stroke();
 /* cushions, then the cloth */
 const cb=Math.max(2.5,rt*.2);g.fillStyle='#13603a';pzRR(g,fx-cb,fy-cb,fw+cb*2,fh+cb*2,4);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2;g.stroke();
 const q=g.createRadialGradient(fx+fw*.5,fy+fh*.42,fh*.08,fx+fw*.5,fy+fh*.5,Math.max(fw,fh)*.62);q.addColorStop(0,'#38b56c');q.addColorStop(1,'#1d7c48');g.fillStyle=q;pzRR(g,fx,fy,fw,fh,3);g.fill();
 g.strokeStyle='rgba(0,30,10,.45)';g.lineWidth=1.4;pzRR(g,fx,fy,fw,fh,3);g.stroke();
 g.fillStyle='rgba(255,255,255,.05)';g.beginPath();g.ellipse(fx+fw*.5,fy+fh*.24,fw*.42,fh*.15,0,0,TAU);g.fill();
 if(o.head){g.strokeStyle='rgba(255,255,255,.2)';g.lineWidth=1.4;g.beginPath();g.moveTo(fx+fw*.25,fy+3);g.lineTo(fx+fw*.25,fy+fh-3);g.stroke()}
 /* sights on the rails */
 const dr=Math.max(1.3,rt*.085);g.fillStyle='#f8e6b0';const dot=(a,b)=>{g.beginPath();g.arc(a,b,dr,0,TAU);g.fill()};
 for(const u of[.125,.25,.375,.625,.75,.875]){dot(fx+fw*u,y+rt*.48);dot(fx+fw*u,y+h-rt*.48)}for(const u of[.25,.5,.75]){dot(x+rt*.48,fy+fh*u);dot(x+w-rt*.48,fy+fh*u)}
 /* pockets */
 T.pk.forEach(([px,py],i)=>{const r=(i===1||i===4)?pr*.88:pr;g.fillStyle='#08040e';g.beginPath();g.arc(px,py,r,0,TAU);g.fill();g.strokeStyle='#d9a63c';g.lineWidth=Math.max(1.6,r*.27);g.beginPath();g.arc(px,py,r*.98,0,TAU);g.stroke();g.strokeStyle=PZ_O;g.lineWidth=1.6;g.beginPath();g.arc(px,py,r*1.13,0,TAU);g.stroke()});
 g.restore()}
function pzwBall(g,x,y,r,n,o){o=o||{};const s=n>8,col=PZW_BC[n===0?0:s?n-8:n];g.save();
 if(!o.flat){g.fillStyle='rgba(4,10,6,.3)';g.beginPath();g.ellipse(x+r*.22,y+r*.8,r*.9,r*.34,0,0,TAU);g.fill()}
 if(o.a!=null)g.globalAlpha=o.a;
 g.beginPath();g.arc(x,y,r,0,TAU);g.fillStyle=(s||n===0)?'#fbf6ea':col;g.fill();
 g.save();g.beginPath();g.arc(x,y,r,0,TAU);g.clip();if(s){g.fillStyle=col;g.fillRect(x-r,y-r*.5,r*2,r)}
 const q=g.createRadialGradient(x-r*.35,y-r*.42,r*.12,x,y,r*1.08);q.addColorStop(0,'rgba(255,255,255,.2)');q.addColorStop(.55,'rgba(255,255,255,0)');q.addColorStop(1,'rgba(16,6,36,.42)');g.fillStyle=q;g.fillRect(x-r,y-r,r*2,r*2);g.restore();
 if(n>0){g.fillStyle='#fffdf6';g.beginPath();g.arc(x,y,r*.5,0,TAU);g.fill();if(r>=7.5){g.fillStyle='#1a1028';g.font=`800 ${(r*(n>9?.5:.62)).toFixed(1)}px Poppins,sans-serif`;g.textAlign='center';g.textBaseline='middle';g.fillText(String(n),x,y+r*.05)}}
 g.fillStyle='rgba(255,255,255,.82)';g.beginPath();g.ellipse(x-r*.4,y-r*.46,r*.24,r*.14,-.65,0,TAU);g.fill();
 g.strokeStyle=PZ_O;g.lineWidth=o.lw||Math.max(1.3,r*.16);g.beginPath();g.arc(x,y,r,0,TAU);g.stroke();g.restore()}
function pzwLine(g,pts,col,lw,dash,off,o){o=o||{};g.save();g.lineCap='round';g.lineJoin='round';
 const path=()=>{g.beginPath();g.moveTo(pts[0][0],pts[0][1]);if(o.curve&&pts.length===3)g.quadraticCurveTo(pts[1][0],pts[1][1],pts[2][0],pts[2][1]);else for(let i=1;i<pts.length;i++)g.lineTo(pts[i][0],pts[i][1])};
 g.setLineDash(dash||[]);g.lineDashOffset=off||0;if(o.under!==false){g.strokeStyle=o.uc||'rgba(8,2,20,.45)';g.lineWidth=lw+2.6;path();g.stroke()}g.strokeStyle=col;g.lineWidth=lw;path();g.stroke();g.restore()}
/* the object ball's heading, as the game draws it: solid gold that fades toward its end (with a travelling glint when t is given) */
function pzwGold(g,x0,y0,x1,y1,lw,t){const q=(a,b)=>{const z=g.createLinearGradient(x0,y0,x1,y1);z.addColorStop(0,a);z.addColorStop(.7,a);z.addColorStop(1,b);return z};
 g.save();g.lineCap='round';g.strokeStyle=q('rgba(8,2,20,.42)','rgba(8,2,20,.06)');g.lineWidth=lw+2.6;g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.stroke();
 g.strokeStyle=q('rgba(255,212,90,1)','rgba(255,212,90,.2)');g.lineWidth=lw;g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.stroke();
 if(t!=null){const p=(t*.55)%1.4;if(p<1){const a=Math.max(0,p-.16),dx=x1-x0,dy=y1-y0;g.strokeStyle=`rgba(255,250,224,${(.95*(1-p*.75)).toFixed(3)})`;g.lineWidth=lw*.62;g.beginPath();g.moveTo(x0+dx*a,y0+dy*a);g.lineTo(x0+dx*p,y0+dy*p);g.stroke()}}
 g.restore()}
function pzwGhost(g,x,y,r){g.save();g.fillStyle='rgba(255,255,255,.12)';g.beginPath();g.arc(x,y,r,0,TAU);g.fill();g.setLineDash([3.2,3.2]);g.strokeStyle='rgba(8,2,20,.45)';g.lineWidth=3.6;g.stroke();g.strokeStyle='rgba(255,255,255,.95)';g.lineWidth=1.8;g.stroke();g.restore()}
function pzwLab(g,t,x,y,col,sz,al){g.save();sz=sz||13;g.font=`800 ${sz}px Poppins,sans-serif`;g.textAlign=al||'center';g.textBaseline='middle';g.lineJoin='round';g.lineWidth=Math.max(3,sz*.38);g.strokeStyle=PZ_O;g.strokeText(t,x,y);g.fillStyle=col||'#fff';g.fillText(t,x,y);g.restore()}
function pzwLead(g,x0,y0,x1,y1){g.save();g.lineCap='round';g.strokeStyle=PZ_O;g.lineWidth=4.6;g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.stroke();g.strokeStyle='#ece6ff';g.lineWidth=1.8;g.stroke();g.restore()}
/* a chunky outlined arrow (fade: the tail fades out) */
function pzwArrow(g,x0,y0,x1,y1,col,w,hw,o){o=o||{};const a=Math.atan2(y1-y0,x1-x0),L=Math.hypot(x1-x0,y1-y0),hl=hw*.88;g.save();g.translate(x0,y0);g.rotate(a);g.lineJoin='round';
 g.beginPath();g.moveTo(0,-w/2);g.lineTo(L-hl,-w/2);g.lineTo(L-hl,-hw/2);g.lineTo(L,0);g.lineTo(L-hl,hw/2);g.lineTo(L-hl,w/2);g.lineTo(0,w/2);g.closePath();
 if(o.fade){const q=g.createLinearGradient(0,0,L,0);q.addColorStop(0,pzwA0(col));q.addColorStop(.55,col);q.addColorStop(1,col);g.fillStyle=q;g.fill();const q2=g.createLinearGradient(0,0,L,0);q2.addColorStop(0,'rgba(18,8,31,0)');q2.addColorStop(.6,PZ_O);g.strokeStyle=q2}
 else{g.fillStyle=col;g.fill();g.strokeStyle=PZ_O}
 g.lineWidth=o.lw||2.6;g.stroke();if(!o.fade){g.strokeStyle='rgba(255,255,255,.4)';g.lineWidth=1.1;g.beginPath();g.moveTo(3,-w/2+1.5);g.lineTo(L-hl-1,-w/2+1.5);g.stroke()}g.restore()}
/* a thin line with a filled head (the "aim at it" arrow) */
function pzwThin(g,x0,y0,x1,y1,col,lw,dash){const a=Math.atan2(y1-y0,x1-x0),hs=lw*3.4,bx=x1-Math.cos(a)*hs*.8,by=y1-Math.sin(a)*hs*.8;
 pzwLine(g,[[x0,y0],[bx,by]],col,lw,dash||[],0,{uc:PZ_O});
 g.save();g.lineJoin='round';g.beginPath();g.moveTo(x1,y1);g.lineTo(x1-Math.cos(a-.55)*hs,y1-Math.sin(a-.55)*hs);g.lineTo(x1-Math.cos(a+.55)*hs,y1-Math.sin(a+.55)*hs);g.closePath();g.fillStyle=col;g.fill();g.strokeStyle=PZ_O;g.lineWidth=2;g.stroke();g.restore()}
function pzwCross(g,x,y,s){g.save();g.lineCap='round';const X=()=>{g.beginPath();g.moveTo(x-s,y-s);g.lineTo(x+s,y+s);g.moveTo(x+s,y-s);g.lineTo(x-s,y+s)};
 g.strokeStyle=PZ_O;g.lineWidth=s*.8;X();g.stroke();g.strokeStyle='#ff3b55';g.lineWidth=s*.44;X();g.stroke();g.strokeStyle='rgba(255,210,214,.6)';g.lineWidth=s*.1;g.beginPath();g.moveTo(x-s*.8,y-s*.9);g.lineTo(x-s*.25,y-s*.35);g.stroke();g.restore()}
/* a cartoon hand; rot=PI holds a ball from above (fingers down, cuff up) */
function pzwHand(g,x,y,s,rot){g.save();g.translate(x,y);g.rotate(rot||0);g.scale(s,s);g.lineJoin='round';g.lineCap='round';const sk='#f6d0a2',O=PZ_O;
 const fing=(fx,fy,w,h,r)=>{g.save();g.translate(fx,fy);g.rotate(r||0);g.fillStyle=sk;pzRR(g,-w/2,-h,w,h+7,w/2);g.fill();g.strokeStyle=O;g.lineWidth=2.4;g.stroke();g.strokeStyle='rgba(170,96,44,.5)';g.lineWidth=1.1;g.beginPath();g.moveTo(-w*.22,-h*.42);g.lineTo(w*.22,-h*.42);g.stroke();g.restore()};
 fing(-12,-8,9,16,-.14);fing(-3.6,-10,9.4,20,-.04);fing(5.4,-10,9.4,19,.05);fing(13.2,-7,8.4,15,.16);
 g.fillStyle=sk;pzRR(g,-17,-12,35,29,12);g.fill();g.strokeStyle=O;g.lineWidth=2.4;g.stroke();g.fillStyle='rgba(214,140,90,.35)';pzRR(g,5,-6,10,18,7);g.fill();
 g.save();g.translate(-15,6);g.rotate(-.95);g.fillStyle=sk;pzRR(g,-5,-14,10,18,5);g.fill();g.strokeStyle=O;g.lineWidth=2.4;g.stroke();g.restore();
 g.fillStyle='#6a5cc0';pzRR(g,-14,15,30,10,4);g.fill();g.strokeStyle=O;g.lineWidth=2.2;g.stroke();g.fillStyle='rgba(255,255,255,.25)';g.fillRect(-11,17,24,2);g.restore()}
/* a hand holding a ball from above: cuff on top, fingers wrapped over the ball; (x,y) = palm centre */
function pzwGrab(g,x,y,s){g.save();g.translate(x,y);g.scale(s,s);g.lineJoin='round';g.lineCap='round';const sk='#f6d0a2',O=PZ_O;
 g.fillStyle='#6a5cc0';pzRR(g,-15,-26,30,12,4);g.fill();g.strokeStyle=O;g.lineWidth=2.4;g.stroke();g.fillStyle='rgba(255,255,255,.28)';g.fillRect(-12,-24,24,2.4);
 g.fillStyle=sk;g.beginPath();g.moveTo(-15,-15);g.lineTo(15,-15);g.bezierCurveTo(19,-10,19,2,16,6);g.lineTo(-16,6);g.bezierCurveTo(-19,2,-19,-10,-15,-15);g.closePath();g.fill();g.strokeStyle=O;g.lineWidth=2.4;g.stroke();
 g.fillStyle='rgba(214,140,90,.35)';pzRR(g,4,-12,10,14,6);g.fill();
 for(const [fx,L] of[[-11.5,15],[-3.8,18],[3.8,18],[11.2,14]]){g.fillStyle=sk;pzRR(g,fx-4.3,0,8.6,L,4.3);g.fill();g.strokeStyle=O;g.lineWidth=2.2;g.stroke();g.strokeStyle='rgba(170,96,44,.5)';g.lineWidth=1;g.beginPath();g.moveTo(fx-2,L*.55);g.lineTo(fx+2,L*.55);g.stroke()}
 g.save();g.translate(-17,-4);g.rotate(.55);g.fillStyle=sk;pzRR(g,-4.6,-2,9.2,17,4.6);g.fill();g.strokeStyle=O;g.lineWidth=2.2;g.stroke();g.restore();g.restore()}
function pzwMouse(g,x,y,s,o){o=o||{};g.save();g.translate(x,y);g.scale(s,s);g.lineJoin='round';g.lineCap='round';
 const body=()=>{g.beginPath();g.moveTo(-15,-6);g.bezierCurveTo(-15,-22,-9,-24,0,-24);g.bezierCurveTo(9,-24,15,-22,15,-6);g.lineTo(15,8);g.bezierCurveTo(15,20,8,24,0,24);g.bezierCurveTo(-8,24,-15,20,-15,8);g.closePath()};
 g.fillStyle='rgba(6,2,16,.35)';g.beginPath();g.ellipse(2,25,15,4,0,0,TAU);g.fill();
 body();g.fillStyle=pzLin(g,-15,-24,15,24,[[0,'#ffffff'],[1,'#cdc4ee']]);g.fill();
 if(o.press){g.save();body();g.clip();g.fillStyle='#ffc93a';g.fillRect(-16,-25,16,20);g.fillStyle='rgba(255,255,255,.45)';g.fillRect(-12,-21,4,8);g.restore()}
 g.strokeStyle='rgba(18,8,31,.7)';g.lineWidth=1.5;g.beginPath();g.moveTo(0,-24);g.lineTo(0,-5);g.moveTo(-15,-5);g.lineTo(15,-5);g.stroke();
 g.fillStyle='#3a3070';pzRR(g,-2.5,-19,5,9,2.5);g.fill();body();g.strokeStyle=PZ_O;g.lineWidth=2.6;g.stroke();
 if(o.press)for(const [a,l] of[[-2.45,7],[-2.0,8.5],[-1.55,7]]){const r0=25,cx=-7,cy=-12,x0=cx+Math.cos(a)*r0*.62,y0=cy+Math.sin(a)*r0*.62,x1=cx+Math.cos(a)*(r0*.62+l),y1=cy+Math.sin(a)*(r0*.62+l);
  g.strokeStyle=PZ_O;g.lineWidth=4.6;g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.stroke();g.strokeStyle='#ffd45a';g.lineWidth=2.4;g.stroke()}
 g.restore()}
function pzwKeyc(g,x,y,w,h,t,sz){g.save();g.fillStyle='#0a0620';pzRR(g,x,y+4,w,h,8);g.fill();g.fillStyle=pzLin(g,0,y,0,y+h,[[0,'#43389e'],[1,'#2b2172']]);pzRR(g,x,y,w,h,8);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2.2;pzRR(g,x,y,w,h,8);g.stroke();
 g.strokeStyle='rgba(255,255,255,.24)';g.lineWidth=1.2;g.beginPath();g.moveTo(x+7,y+3.5);g.lineTo(x+w-7,y+3.5);g.stroke();g.font=`800 ${sz||13}px Poppins,sans-serif`;g.textAlign='center';g.textBaseline='middle';g.fillStyle='#fff6dc';g.fillText(t,x+w/2,y+h/2+1);g.restore()}
/* the player's own cue (9.6 sprite) at tip (x,y) pointing along ang; k = length scale, ky = thickness scale */
function pzwCue(g,x,y,ang,gap,k,ky,sh){let s=null;try{s=pzCueSprite(PZS().cue)}catch(e){}g.save();g.translate(x,y);g.rotate(ang);g.translate(-gap,0);
 if(sh){g.save();g.globalAlpha=.22;g.strokeStyle='#05020c';g.lineCap='round';g.lineWidth=(ky||k)*16;g.beginPath();g.moveTo(-4,6);g.lineTo(-PZ_CUE.L*k,9);g.stroke();g.restore()}
 g.scale(k,(ky||k)*1.3);if(s)g.drawImage(s.c,-(PZ_CUE.L+10),-15,s.W/2,s.H/2);else{g.fillStyle='#e8c88a';g.fillRect(-PZ_CUE.L,-3,PZ_CUE.L,6);g.fillStyle='#4a2a8a';g.fillRect(-4,-3,4,6)}g.restore()}
function pzwRackTri(g,x,y,s,on,balls){g.save();g.translate(x,y);g.lineJoin='round';const tri=k=>{g.beginPath();g.moveTo(0,-s*k);g.lineTo(s*1.06*k,s*.74*k);g.lineTo(-s*1.06*k,s*.74*k);g.closePath()};
 g.fillStyle='rgba(4,2,12,.4)';g.save();g.translate(3,6);tri(1);g.fill();g.restore();
 tri(1);g.fillStyle=on?pzLin(g,0,-s,0,s*.74,[[0,'#ffe680'],[1,'#f0a426']]):pzLin(g,0,-s,0,s*.74,[[0,'#4334a8'],[1,'#2a2080']]);g.fill();g.strokeStyle=PZ_O;g.lineWidth=3.4;g.stroke();
 tri(.8);g.strokeStyle=on?'rgba(255,255,255,.45)':'rgba(170,150,255,.28)';g.lineWidth=1.6;if(!on)g.setLineDash([4,4]);g.stroke();g.setLineDash([]);
 if(on&&balls){const r=s*.27;[[0,-s*.24],[-s*.31,s*.28],[s*.31,s*.28]].forEach(([bx,by],i)=>pzwBall(g,bx,by,r,balls[i],{flat:1}))}g.restore()}
function pzwMug(g,x,y,s){g.save();g.translate(x,y);g.scale(s,s);g.lineJoin='round';
 g.fillStyle='#f6e6b8';pzRR(g,20,8,14,26,7);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2.6;g.stroke();g.fillStyle='#14082a';pzRR(g,23,13,6,16,3);g.fill();
 g.fillStyle=pzLin(g,0,0,26,0,[[0,'#ffcf4a'],[1,'#e08a14']]);pzRR(g,0,0,26,40,5);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2.6;g.stroke();
 g.fillStyle='rgba(255,255,255,.45)';g.fillRect(4,8,3.5,26);g.fillStyle='rgba(255,255,255,.7)';for(const [bx,by,br] of[[8,22,1.6],[16,30,1.3],[13,15,1.1]]){g.beginPath();g.arc(bx,by,br,0,TAU);g.fill()}
 g.fillStyle='#fffaf0';for(const [fx,fy,fr] of[[3,-1,6],[11,-4,7],[20,-1,6.5],[25,3,4.5]]){g.beginPath();g.arc(fx,fy,fr,0,TAU);g.fill()}g.beginPath();g.ellipse(3,6,3.5,6,0,0,TAU);g.fill();
 g.strokeStyle=PZ_O;g.lineWidth=2.4;g.beginPath();g.arc(3,-1,6,Math.PI*.55,Math.PI*1.6);g.arc(11,-4,7,Math.PI*1.05,Math.PI*1.95);g.arc(20,-1,6.5,Math.PI*1.25,Math.PI*2.05);g.arc(25,3,4.5,Math.PI*1.6,Math.PI*.45);g.stroke();g.restore()}
/* ---------------------------------------------------------------- the baked art ---------------------------------------------------------------- */
const PZW_ART={
 /* Basics */
 groups(g,w,h){const T=pzwTG(6,5,w-12,h-12);pzwTable(g,T);const {fx,fy,fw,fh}=T,r=Math.round(fh*.095);
  g.save();g.setLineDash([3,6]);g.strokeStyle='rgba(255,255,255,.16)';g.lineWidth=2;g.beginPath();g.moveTo(fx+fw/2,fy+10);g.lineTo(fx+fw/2,fy+fh-10);g.stroke();g.restore();
  [[.15,.3,1],[.33,.2,4],[.28,.52,2],[.13,.64,3]].forEach(([u,v,n])=>pzwBall(g,fx+fw*u,fy+fh*v,r,n));[[.67,.32,9],[.85,.19,12],[.83,.5,10],[.66,.64,11]].forEach(([u,v,n])=>pzwBall(g,fx+fw*u,fy+fh*v,r,n));
  pzwLab(g,'SOLIDS 1–7',fx+fw*.25,fy+fh*.87,'#ffd45a',14);pzwLab(g,'STRIPES 9–15',fx+fw*.75,fy+fh*.87,'#ffd45a',14)},
 eight(g,w,h,M){const T=pzwTG(6,5,w-12,h-12);pzwTable(g,T);const {fx,fy,fw,fh,pk,pr}=T,r=Math.round(fh*.095),C=[fx+fw*.25,fy+fh*.66],E=[fx+fw*.67,fy+fh*.42],P=pk[2];
  pzwLine(g,[[E[0]+r*.75,E[1]-r*.65],[P[0]-pr-3,P[1]+pr+1]],'rgba(255,212,90,.9)',2.2,[1,6],0,{under:false});
  pzwThin(g,C[0]+r+7,C[1]-r*.28,E[0]-r-7,E[1]+r*.3,'#ffffff',3.2);pzwBall(g,C[0],C[1],r,0);pzwBall(g,E[0],E[1],r,8);
  for(const [a,l] of[[-1.25,8],[-.8,9],[-.35,8]]){const x0=E[0]+Math.cos(a)*(r+5),y0=E[1]+Math.sin(a)*(r+5),x1=E[0]+Math.cos(a)*(r+5+l),y1=E[1]+Math.sin(a)*(r+5+l);g.lineCap='round';g.strokeStyle=PZ_O;g.lineWidth=4.6;g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.stroke();g.strokeStyle='#ffd45a';g.lineWidth=2.4;g.stroke()}
  g.strokeStyle=PZ_O;g.lineWidth=6.4;g.beginPath();g.arc(P[0],P[1],pr+7,0,TAU);g.stroke();g.strokeStyle='#45f0c8';g.lineWidth=3.4;g.stroke();
  pzwLab(g,'CALLED',P[0]-60,P[1]+15,'#7affd8',12);M.ring=[P[0],P[1],pr+7]},
 race(g,w,h){const s=Math.min(w*.13,h*.3);[[.19,1,[1,3,4]],[.5,1,[9,11,12]],[.81,0]].forEach(([u,on,b])=>pzwRackTri(g,w*u,h*.43,s,on,b));pzwLab(g,'FIRST TO THE RACE TARGET WINS',w/2,h*.86,'#efe8ff',14)},
 /* Shooting: the big table (static parts; the lines and the cue are the LIVE overlay) */
 shootT(g,w,h,M){const T=pzwTG(6,6,w-12,h-12,{head:1});pzwTable(g,T);const {fx,fy,fw,fh,pk}=T,r=13,P=pk[2],O=[fx+fw*.73,fy+fh*.37],d=pzwN(P[0]-O[0],P[1]-O[1]),G=[O[0]-d[0]*2*r,O[1]-d[1]*2*r],C=[fx+fw*.24,fy+fh*.66],aim=pzwN(G[0]-C[0],G[1]-C[1]);
  let tn=[-d[1],d[0]];if(aim[0]*tn[0]+aim[1]*tn[1]<0)tn=[-tn[0],-tn[1]];
  const E=[P[0]-d[0]*14,P[1]-d[1]*14];M.sh={C,O,G,d,aim,tn,r,E,ang:Math.atan2(aim[1],aim[0])};
  pzwGold(g,O[0]+d[0]*(r+1),O[1]+d[1]*(r+1),E[0],E[1],3);pzwGhost(g,G[0],G[1],r);pzwBall(g,O[0],O[1],r,3);pzwBall(g,C[0],C[1],r,0);
  const gm=[O[0]+d[0]*62,O[1]+d[1]*62];pzwLead(g,gm[0]-58,gm[1]-30,gm[0]-6,gm[1]-4);pzwLab(g,'GOLD: THE BALL',gm[0]-66,gm[1]-42,'#ffd45a',15);
  const bm=[G[0]+tn[0]*(r+44),G[1]+tn[1]*(r+44)];pzwLead(g,bm[0]+60,bm[1]+30,bm[0]+6,bm[1]+3);pzwLab(g,'BLUE: CUE BALL',bm[0]+86,bm[1]+44,'#8fe0ff',15);
  const am=[(C[0]+G[0])/2,(C[1]+G[1])/2];pzwLab(g,'WHITE: YOUR AIM',am[0]-14,am[1]+36,'#e6deff',12);pzwLab(g,'GHOST BALL',G[0]-44,G[1]-34,'#ffffff',11)},
 /* Shooting: detail panel art */
 dAim(g,w,h){const C=[118,h/2],r=15;g.fillStyle='rgba(56,181,108,.13)';g.beginPath();g.ellipse(170,h/2+8,170,48,0,0,TAU);g.fill();
  for(const a of[-.3,-.15,.15,.3]){const x1=C[0]+Math.cos(a)*150,y1=C[1]+Math.sin(a)*150;pzwLine(g,[[C[0]+Math.cos(a)*(r+4),C[1]+Math.sin(a)*(r+4)],[x1,y1]],'rgba(255,255,255,.22)',1.6,[2,6],0,{under:false});g.strokeStyle='rgba(255,255,255,.2)';g.lineWidth=1.4;g.setLineDash([2,3]);g.beginPath();g.arc(x1+Math.cos(a)*8,y1+Math.sin(a)*8,8,0,TAU);g.stroke();g.setLineDash([])}
  pzwBall(g,C[0],C[1],r,0)},
 aimRot(g,w,h){const C=[118,h/2],r=15,X=C[0]+150;pzwCue(g,C[0],C[1],0,r+6,.5,.7,1);pzwLine(g,[[C[0]+r+4,C[1]],[X-11,C[1]]],'rgba(255,255,255,.95)',2.4,[7,6],0);pzwGhost(g,X,C[1],11)},
 mouseLR(g,w,h){const s=h/72,cx=w/2,cy=h*.5;pzwArrow(g,cx-24*s,cy,cx-50*s,cy,'#ffc93a',9*s,20*s,{lw:2.2});pzwArrow(g,cx+24*s,cy,cx+50*s,cy,'#ffc93a',9*s,20*s,{lw:2.2});pzwMouse(g,cx,cy,s*.95)},
 mousePr(g,w,h){pzwMouse(g,w*.56,h*.58,h/80,{press:1})},
 dPow(g,w,h){g.fillStyle='rgba(56,181,108,.13)';g.beginPath();g.ellipse(150,h*.62,160,40,0,0,TAU);g.fill();pzwArrow(g,236,28,118,28,'#ffc93a',13,28,{fade:1});pzwBall(g,258,h*.6,17,0)},
 cueH(g,w,h){pzwCue(g,w-2,h/2,0,0,.64,.95,0)},
 cueBig(g,w,h){pzwCue(g,w-2,16,0,0,.64,1,1)},
 dSpin(g,w,h){const x=66,y=h/2,r=49;g.fillStyle='rgba(6,2,16,.35)';g.beginPath();g.ellipse(x+8,y+r*.86,r*.85,r*.22,0,0,TAU);g.fill();pzwBall(g,x,y,r,0,{flat:1,lw:3});
  g.save();g.setLineDash([3,4]);g.strokeStyle='rgba(60,40,120,.4)';g.lineWidth=1.4;g.beginPath();g.moveTo(x-r+6,y);g.lineTo(x+r-6,y);g.moveTo(x,y-r+6);g.lineTo(x,y+r-6);g.stroke();g.restore();
  g.strokeStyle='rgba(60,40,120,.35)';g.lineWidth=1.4;g.beginPath();g.arc(x,y,r*.55,0,TAU);g.stroke()},
 /* Shooting: the three little cards */
 mAim(g,w,h){const T=pzwTG(3,3,w-6,h-6,{rt:9,pr:5});pzwTable(g,T,{lw:2.4});const {fx,fy,fw,fh,pk}=T,r=6,C=[fx+fw*.18,fy+fh*.72],O=[fx+fw*.72,fy+fh*.34],d=pzwN(pk[2][0]-O[0],pk[2][1]-O[1]),G=[O[0]-d[0]*2*r,O[1]-d[1]*2*r];
  pzwLine(g,[[C[0]+5,C[1]-2],[G[0]-5,G[1]+1]],'#ffffff',1.6,[4,4],0);pzwGhost(g,G[0],G[1],r);pzwGold(g,O[0]+d[0]*r,O[1]+d[1]*r,pk[2][0]-d[0]*6,pk[2][1]-d[1]*6,2);pzwLine(g,[[G[0]+3,G[1]+5],[G[0]+12,G[1]+19]],'#9fe8ff',1.6,[3,3],0);pzwBall(g,O[0],O[1],r,3);pzwBall(g,C[0],C[1],r,0)},
 mPow(g,w,h){const T=pzwTG(3,3,w-6,h-6,{rt:9,pr:5});pzwTable(g,T,{lw:2.4});const {fx,fy,fw,fh}=T;
  g.fillStyle='#160e3e';pzRR(g,fx+8,fy+7,fw-16,9,4.5);g.fill();g.strokeStyle=PZ_O;g.lineWidth=1.6;g.stroke();g.fillStyle=pzLin(g,fx+8,0,fx+fw-8,0,[[0,'#e8364e'],[.5,'#f7a33a'],[1,'#ffd45a']]);pzRR(g,fx+9.5,fy+8.5,(fw-19)*.66,6,3);g.fill();
  g.fillStyle='#8fe0ff';g.fillRect(fx+9.5+(fw-19)*.66-1,fy+7,2,9);
  pzwArrow(g,fx+fw*.36,fy+fh*.62,fx+fw*.08,fy+fh*.62,'#ffc93a',5,12,{fade:1,lw:1.6});pzwBall(g,fx+fw*.44,fy+fh*.62,7,0);pzwBall(g,fx+fw*.84,fy+fh*.6,7,5)},
 mSpin(g,w,h){const T=pzwTG(3,3,w-6,h-6,{rt:9,pr:5});pzwTable(g,T,{lw:2.4});const {fx,fy,fw,fh}=T,x=fx+fw/2,y=fy+fh/2,r=Math.min(fh*.42,30);pzwBall(g,x,y,r,0,{flat:1,lw:2.4});
  for(const [dx,dy,c] of[[0,-.55,'#3ee89a'],[0,.55,'#ff9a3a'],[.55,0,'#b88aff']]){g.fillStyle=c;g.beginPath();g.arc(x+dx*r,y+dy*r,r*.17,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=1.6;g.stroke()}},
 /* Fouls */
 scratch(g,w,h,M){const T=pzwTG(6,5,w-12,h-12);pzwTable(g,T);const {fx,fy,fw,fh,pk}=T,r=12,P=pk[4],C=[fx+fw*.2,fy+fh*.36];
  pzwLab(g,'SCRATCH',fx+fw/2,fy+19,'#ff5a70',19);pzwBall(g,fx+fw*.5,fy+fh*.5,r,3);
  pzwBall(g,P[0],P[1]-2,r*.86,0,{flat:1,a:.85});pzwThin(g,C[0]+r*.6,C[1]+r*.8,P[0]-r*.72,P[1]-r*1.2,'#ffffff',2.4,[5,5]);pzwBall(g,C[0],C[1],r,0);M.x=[fx+fw*.82,fy+fh*.6]},
 wrong(g,w,h,M){const T=pzwTG(6,5,w-12,h-12);pzwTable(g,T);const {fx,fy,fw,fh}=T,r=12,C=[fx+fw*.16,fy+fh*.52],B=[fx+fw*.6,fy+fh*.52];
  pzwLab(g,'WRONG BALL FIRST',fx+fw/2,fy+19,'#ff5a70',18);pzwLine(g,[[C[0]+r+4,C[1]],[B[0]-r-4,B[1]]],'#ffffff',2.4,[5,5],0);pzwBall(g,C[0],C[1],r,0);pzwBall(g,B[0],B[1],r,11);pzwBall(g,fx+fw*.86,fy+fh*.76,r,2);
  pzwLab(g,'YOU: SOLIDS',fx+fw*.18,fy+fh*.86,'#ffd45a',11);M.x=[fx+fw*.83,fy+fh*.36]},
 bih(g,w,h){const T=pzwTG(6,5,w-12,h-12);pzwTable(g,T);const {fx,fy,fw,fh}=T,r=12,C=[fx+fw*.42,fy+fh*.6];
  for(const a of[Math.PI,0,Math.PI*.78,Math.PI*.5,Math.PI*.22]){const x0=C[0]+Math.cos(a)*(r+7),y0=C[1]+Math.sin(a)*(r+7),L=a===Math.PI*.5?22:32;pzwArrow(g,x0,y0,x0+Math.cos(a)*L,y0+Math.sin(a)*L,'#3ee8a0',5,13,{lw:2})}
  pzwBall(g,C[0],C[1],r,0);pzwGrab(g,C[0],C[1]-r-3,.95);pzwBall(g,fx+fw*.79,fy+fh*.32,r,6);pzwBall(g,fx+fw*.87,fy+fh*.72,r,4)},
 xmark(g,w,h){pzwCross(g,w/2,h/2,w*.28)},
 /* Guide & extras */
 guideT(g,w,h,M){const T=pzwTG(6,5,w-12,h-12);pzwTable(g,T);const {fx,fy,fw,fh}=T,r=11,C=[fx+fw*.15,fy+fh*.74],O=[fx+fw*.47,fy+fh*.53],H=[fx+fw*.61,fy+2],d=pzwN(H[0]-O[0],H[1]-O[1]),G=[O[0]-d[0]*2*r,O[1]-d[1]*2*r],aim=pzwN(G[0]-C[0],G[1]-C[1]);
  let tn=[-d[1],d[0]];if(aim[0]*tn[0]+aim[1]*tn[1]<0)tn=[-tn[0],-tn[1]];const B0=[G[0]+tn[0]*(r+2),G[1]+tn[1]*(r+2)],B1=[G[0]+tn[0]*(r+44),G[1]+tn[1]*(r+44)],B2=[G[0]+tn[0]*(r+58)+aim[0]*30,G[1]+tn[1]*(r+58)+aim[1]*30];
  M.gd={C,O,G,H,d,aim,r,B0,B1,B2};pzwGold(g,O[0]+d[0]*(r+1),O[1]+d[1]*(r+1),H[0]-d[0]*4,H[1]-d[1]*4,2.8);pzwLine(g,[B0,B1,B2],'rgba(159,232,255,.95)',2.4,[7,6],0,{curve:true});pzwGhost(g,G[0],G[1],r);
  g.save();g.translate(H[0],H[1]+3);g.strokeStyle=PZ_O;g.lineWidth=4.4;g.lineCap='round';g.beginPath();g.moveTo(-9,0);g.lineTo(9,0);g.stroke();g.strokeStyle='#ffd45a';g.lineWidth=2.2;g.stroke();g.restore();
  pzwBall(g,O[0],O[1],r,2);pzwBall(g,C[0],C[1],r,0);
  pzwLead(g,G[0]-46,G[1]-30,G[0]-8,G[1]-8);pzwLab(g,'GHOST BALL',G[0]-58,G[1]-40,'#ffffff',11);
  const gm=[(O[0]+H[0])/2,(O[1]+H[1])/2];pzwLead(g,gm[0]+58,gm[1]-2,gm[0]+6,gm[1]);pzwLab(g,'GOLD: WHERE IT HEADS,',gm[0]+136,gm[1]-9,'#ffd45a',12);pzwLab(g,'UP TO ITS FIRST CUSHION',gm[0]+136,gm[1]+8,'#ffd45a',12);
  pzwLead(g,B2[0]+44,B2[1]-6,B2[0]+6,B2[1]-2);pzwLab(g,'BLUE: THE CUE BALL,',B2[0]+118,B2[1]-14,'#8fe0ff',12);pzwLab(g,'BENT BY FOLLOW / DRAW',B2[0]+118,B2[1]+3,'#8fe0ff',12);
  pzwLab(g,'WHITE: YOUR AIM',(C[0]+G[0])/2-4,(C[1]+G[1])/2+30,'#e6deff',11)},
 gm(g,w,h,M,mode){const r=7,fx=4,fy=4,fw=w-8,fh=h-8;g.fillStyle='#13603a';pzRR(g,fx-2,fy-2,fw+4,fh+4,8);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2;g.stroke();
  const q=g.createRadialGradient(w/2,h/2,4,w/2,h/2,w*.6);q.addColorStop(0,'#38b56c');q.addColorStop(1,'#1d7c48');g.fillStyle=q;pzRR(g,fx+2,fy+2,fw-4,fh-4,6);g.fill();
  const C=[fx+fw*.14,fy+fh*.74],O=[fx+fw*.56,fy+fh*.5],H=[fx+fw*.74,fy+3],d=pzwN(H[0]-O[0],H[1]-O[1]),G=[O[0]-d[0]*2*r,O[1]-d[1]*2*r],aim=pzwN(G[0]-C[0],G[1]-C[1]);let tn=[-d[1],d[0]];if(aim[0]*tn[0]+aim[1]*tn[1]<0)tn=[-tn[0],-tn[1]];
  pzwLine(g,[[C[0]+aim[0]*(r+2),C[1]+aim[1]*(r+2)],[G[0]-aim[0]*r,G[1]-aim[1]*r]],'#ffffff',1.6,[4,4],0);pzwGhost(g,G[0],G[1],r);
  const Lg=mode==='full'?Math.hypot(H[0]-O[0],H[1]-O[1])-2:mode==='short'?14:0,Lb=mode==='full'?30:mode==='short'?12:0;
  if(Lg)pzwGold(g,O[0]+d[0]*r,O[1]+d[1]*r,O[0]+d[0]*(r+Lg),O[1]+d[1]*(r+Lg),2.2);
  if(Lb)pzwLine(g,mode==='full'?[[G[0]+tn[0]*(r+1),G[1]+tn[1]*(r+1)],[G[0]+tn[0]*(r+20),G[1]+tn[1]*(r+20)],[G[0]+tn[0]*(r+26)+aim[0]*12,G[1]+tn[1]*(r+26)+aim[1]*12]]:[[G[0]+tn[0]*(r+1),G[1]+tn[1]*(r+1)],[G[0]+tn[0]*(r+Lb),G[1]+tn[1]*(r+Lb)]],'#9fe8ff',1.7,[3.5,3.5],0,{curve:mode==='full'});
  pzwBall(g,O[0],O[1],r,2);pzwBall(g,C[0],C[1],r,0)},
 gFull(g,w,h,M){PZW_ART.gm(g,w,h,M,'full')},gShort(g,w,h,M){PZW_ART.gm(g,w,h,M,'short')},gPro(g,w,h,M){PZW_ART.gm(g,w,h,M,'pro')},
 taunt(g,w,h){g.save();g.lineJoin='round';g.fillStyle='#efe8ff';g.beginPath();g.roundRect(8,10,w-16,42,13);g.moveTo(26,51);g.lineTo(20,64);g.lineTo(40,51);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2.6;g.beginPath();g.roundRect(8,10,w-16,42,13);g.stroke();
  g.fillStyle='#efe8ff';g.beginPath();g.moveTo(25,50);g.lineTo(20,63);g.lineTo(41,50);g.closePath();g.fill();g.beginPath();g.moveTo(25,52);g.lineTo(20,63);g.lineTo(41,52);g.stroke();
  g.font='700 19px Poppins,sans-serif';g.textAlign='left';g.textBaseline='middle';g.fillStyle='#9a90cc';g.fillText('drip drip',22,32);g.fillStyle='#24124a';g.fillText('drip d',22,32);const tw=g.measureText('drip d').width;g.fillStyle='#e8364e';g.fillRect(22+tw+1,22,2.4,20);
  g.fillStyle='#12081f';pzRR(g,48,64,w-56,12,6);g.fill();g.fillStyle=pzLin(g,48,0,w-8,0,[[0,'#ff9ad0'],[1,'#ff5aa8']]);pzRR(g,50,66,(w-60)*.58,8,4);g.fill();g.restore()},
 fast(g,w,h){pzwKeyc(g,8,26,74,34,'SPACE',13);for(let k=0;k<2;k++){g.beginPath();g.moveTo(92+k*21,28);g.lineTo(114+k*21,43);g.lineTo(92+k*21,58);g.closePath();g.fillStyle='#ffd45a';g.fill();g.strokeStyle=PZ_O;g.lineWidth=2.4;g.lineJoin='round';g.stroke()}pzwLab(g,'×3',117,74,'#ffd45a',14)},
 clock(g,w,h){const x=w/2,y=h/2+1,r=33;g.fillStyle='#140c36';g.beginPath();g.arc(x,y,r+6,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2.6;g.stroke();g.strokeStyle='#2e2668';g.lineWidth=7;g.beginPath();g.arc(x,y,r-2,0,TAU);g.stroke();
  g.strokeStyle='#ffd45a';g.lineCap='round';g.beginPath();g.arc(x,y,r-2,-Math.PI/2,-Math.PI/2+TAU*.7);g.stroke();g.font='800 22px Poppins,sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillStyle='#fff6dc';g.fillText('45',x,y+1);
  g.fillStyle='#ffd45a';for(let i=0;i<4;i++){const a=i*Math.PI/2;g.beginPath();g.arc(x+Math.cos(a)*(r+12),y+Math.sin(a)*(r+12),1.6,0,TAU);g.fill()}},
 house(g,w,h){g.save();g.lineJoin='round';g.strokeStyle='#b88a52';g.lineWidth=2;g.beginPath();g.moveTo(40,20);g.lineTo(w/2-6,4);g.lineTo(w-40,20);g.stroke();
  g.fillStyle=pzLin(g,0,18,0,72,[[0,'#8e5226'],[1,'#56280c']]);pzRR(g,18,18,w-36,54,9);g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();g.strokeStyle='rgba(255,220,160,.3)';g.lineWidth=1.2;pzRR(g,23,23,w-46,44,6);g.stroke();
  g.fillStyle='#e0c88a';for(const [nx,ny] of[[26,26],[w-26,26],[26,64],[w-26,64]]){g.beginPath();g.arc(nx,ny,2.4,0,TAU);g.fill()}
  pzwLab(g,'HOUSE',w/2,37,'#ffd45a',14);pzwLab(g,'RULE',w/2,54,'#ffd45a',14);pzwBall(g,w-24,h-14,11,8);g.restore()},
 /* Controls */
 keysT(g,w,h,M){const T=pzwTG(18,20,w-36,h-42,{head:1});pzwTable(g,T);const {fx,fy,fw,fh,pk}=T,r=10,C=[fx+fw*.17,fy+fh/2],A=[fx+fw*.63,fy+fh/2];
  const rows=[[1],[10,2],[11,8,3],[4,14,7,12],[13,5,15,6,9]];
  g.save();g.beginPath();g.moveTo(C[0]+r+3,C[1]-4);g.lineTo(A[0]-44,C[1]-24);g.lineTo(A[0]-44,C[1]+24);g.lineTo(C[0]+r+3,C[1]+4);g.closePath();const q=g.createLinearGradient(C[0],0,A[0]-44,0);q.addColorStop(0,'rgba(255,255,255,.04)');q.addColorStop(1,'rgba(255,255,255,.2)');g.fillStyle=q;g.fill();
  g.beginPath();g.moveTo(A[0]-44,C[1]-15);g.lineTo(A[0]-24,C[1]);g.lineTo(A[0]-44,C[1]+15);g.closePath();g.fillStyle='rgba(255,255,255,.85)';g.fill();g.strokeStyle='rgba(18,8,31,.6)';g.lineWidth=1.6;g.stroke();g.restore();
  rows.forEach((row,i)=>row.forEach((n,j)=>pzwBall(g,A[0]+i*r*1.76,A[1]+(j-(row.length-1)/2)*r*2.04,r,n)));pzwBall(g,C[0],C[1],r+.5,0);
  const off=[[-1,-1],[0,-1],[1,-1],[-1,1],[0,1],[1,1]];M.kt={C,A,r,pk:pk.map(([x,y],i)=>[x+off[i][0]*(off[i][0]?13:0),y+off[i][1]*(off[i][0]?13:17)])}},
 sign(g,w,h){const px=22,py=24,pw=w-44,ph=h-30;g.save();g.lineJoin='round';g.lineCap='round';
  for(const x of[px+60,px+pw-60]){g.strokeStyle=PZ_O;g.lineWidth=7;g.beginPath();g.moveTo(x,-4);g.lineTo(x,py+6);g.stroke();g.strokeStyle='#c4965a';g.lineWidth=3.6;g.stroke();g.strokeStyle='rgba(90,50,20,.7)';g.lineWidth=1.2;for(let yy=2;yy<py+2;yy+=5){g.beginPath();g.moveTo(x-1.6,yy);g.lineTo(x+1.6,yy+3);g.stroke()}
   g.strokeStyle=PZ_O;g.lineWidth=5;g.beginPath();g.arc(x,py+5,5,0,TAU);g.stroke();g.strokeStyle='#cfc2a0';g.lineWidth=2.4;g.stroke()}
  g.fillStyle='rgba(0,0,0,.42)';pzRR(g,px+4,py+9,pw,ph,16);g.fill();
  g.fillStyle=pzLin(g,0,py,0,py+ph,[[0,'#99582a'],[.5,'#76401a'],[1,'#52260c']]);pzRR(g,px,py,pw,ph,16);g.fill();
  g.save();pzRR(g,px,py,pw,ph,16);g.clip();for(let i=0;i<9;i++){const yy=py+6+i*(ph-10)/8;g.strokeStyle=`rgba(255,210,150,${i%3?.07:.12})`;g.lineWidth=1.2;g.beginPath();g.moveTo(px,yy);g.bezierCurveTo(px+pw*.3,yy+3,px+pw*.62,yy-3,px+pw,yy+1);g.stroke()}
   g.strokeStyle='rgba(30,10,0,.55)';g.lineWidth=2;g.beginPath();g.moveTo(px,py+ph*.52);g.lineTo(px+pw,py+ph*.52);g.stroke();
   g.fillStyle='rgba(40,16,4,.35)';for(const [kx,ky] of[[px+pw*.17,py+ph*.3],[px+pw*.86,py+ph*.74]]){g.beginPath();g.ellipse(kx,ky,7,3.4,0,0,TAU);g.fill()}g.restore();
  g.strokeStyle='rgba(255,222,160,.42)';g.lineWidth=2;pzRR(g,px+3,py+3,pw-6,ph-6,13);g.stroke();g.strokeStyle=PZ_O;g.lineWidth=4.4;pzRR(g,px,py,pw,ph,16);g.stroke();
  g.strokeStyle='rgba(216,166,60,.55)';g.lineWidth=1.6;pzRR(g,px+10,py+10,pw-20,ph-20,9);g.stroke();
  for(const [nx,ny] of[[px+18,py+18],[px+pw-18,py+18],[px+18,py+ph-18],[px+pw-18,py+ph-18]]){g.fillStyle='#d6c08c';g.beginPath();g.arc(nx,ny,4.6,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=1.8;g.stroke();g.fillStyle='rgba(255,255,255,.7)';g.beginPath();g.arc(nx-1.3,ny-1.4,1.4,0,TAU);g.fill()}
  g.restore()},
 rail(g,w,h){g.save();const ry=10,rh=30;
  const q=g.createLinearGradient(0,ry+rh,0,h);q.addColorStop(0,'#1f7c47');q.addColorStop(1,'#2fa262');g.fillStyle=q;g.fillRect(0,ry+rh-2,w,h);g.fillStyle='rgba(0,0,0,.35)';g.fillRect(0,ry+rh-2,w,7);
  for(const [x,n,r] of[[330,13,30],[566,0,28],[1046,2,27],[1390,3,29]])pzwBall(g,x,h+r*.25,r,n);
  g.fillStyle='rgba(0,0,0,.4)';g.fillRect(0,ry-6,w,8);
  g.fillStyle=pzLin(g,0,ry,0,ry+rh,[[0,'#b2692a'],[.5,'#86461a'],[1,'#5a2a0c']]);pzRR(g,-20,ry,w+40,rh,10);g.fill();
  g.strokeStyle='rgba(255,214,150,.1)';g.lineWidth=1;for(let i=0;i<4;i++){const yy=ry+5+i*6;g.beginPath();g.moveTo(0,yy);g.bezierCurveTo(w*.3,yy+2,w*.7,yy-2,w,yy+1);g.stroke()}
  g.strokeStyle='rgba(255,226,170,.45)';g.lineWidth=2;g.beginPath();g.moveTo(0,ry+3);g.lineTo(w,ry+3);g.stroke();g.strokeStyle=PZ_O;g.lineWidth=4;pzRR(g,-20,ry,w+40,rh,10);g.stroke();
  g.fillStyle='#f8e6b0';for(let x=100;x<w;x+=200){g.beginPath();g.moveTo(x,ry+rh/2-4);g.lineTo(x+5,ry+rh/2);g.lineTo(x,ry+rh/2+4);g.lineTo(x-5,ry+rh/2);g.closePath();g.fill()}g.restore()}
};
/* bake one piece of art at 2x (cached per size; text art waits for the fonts) */
function pzwFontsOk(){try{return document.fonts.check('800 12px Poppins')}catch(e){return true}}
function pzwArt(k,w,h){const key=k+'|'+w+'|'+h+(k==='cueH'||k==='aimRot'?'|'+PZS().cue:'');if(PZW.art[key])return PZW.art[key];const c=pzCv(w*2,h*2),g=c.getContext('2d');g.scale(2,2);g.lineJoin='round';g.lineCap='round';const M={};
 try{PZW_ART[k](g,w,h,M)}catch(e){}
 PZW.meta[k]=M;if(pzwFontsOk())PZW.art[key]=c;else if(!PZW.fw){PZW.fw=1;try{document.fonts.ready.then(()=>{PZW.art={};document.querySelectorAll('canvas[data-art]').forEach(pzwPaint)})}catch(e){}}return c}
function pzwPaint(cv){const k=cv.dataset.art,w=+cv.dataset.w,h=+cv.dataset.h;if(!PZW_ART[k])return;const a=pzwArt(k,w,h),g=cv.getContext('2d');g.clearRect(0,0,cv.width,cv.height);g.drawImage(a,0,0,cv.width,cv.height)}
/* ---------------------------------------------------------------- moving parts on the felt (compositor only) ----------------------------------------------------------------
   The flowing guide lines are DOM strips rotated onto the felt: a baked dash tile repeats along a strip that slides one tile
   (16 px) per loop, so the dashes flow without repainting anything. The cue is a baked canvas that pulls back and strikes
   with a transform; the gold line's glint and the hit ring are transform/opacity loops too. */
const PZW_TILE={};
function pzwTile(kind){if(PZW_TILE[kind])return PZW_TILE[kind];const sp={white:['rgba(255,255,255,.95)',2.6,8],blue:['rgba(159,232,255,.95)',2.6,8],dots:['rgba(255,255,255,.95)',4.2,0]}[kind],[col,lw,dash]=sp,per=16,H=Math.ceil(lw+6),S=2,c=pzCv(per*S,H*S),g=c.getContext('2d');g.scale(S,S);g.lineCap='round';
 const x0=(per-dash)/2,y=H/2;if(kind!=='dots'){g.strokeStyle='rgba(8,2,20,.45)';g.lineWidth=lw+2.6;g.beginPath();g.moveTo(x0,y);g.lineTo(x0+dash,y);g.stroke()}g.strokeStyle=col;g.lineWidth=lw;g.beginPath();g.moveTo(x0,y);g.lineTo(x0+dash+.01,y);g.stroke();
 const st=document.createElement('style');st.textContent=`.pzw-ln.t-${kind}>i{background-image:url(${c.toDataURL()});background-size:${per}px ${H}px}`;document.head.appendChild(st);return PZW_TILE[kind]={per,H}}
function pzwLn(a,b,kind){const T=pzwTile(kind),L=Math.hypot(b[0]-a[0],b[1]-a[1]),ang=Math.atan2(b[1]-a[1],b[0]-a[0]);
 return `<i class="pzw-ln t-${kind}" style="left:${a[0].toFixed(1)}px;top:${(a[1]-T.H/2).toFixed(1)}px;width:${L.toFixed(1)}px;height:${T.H}px;transform:rotate(${ang.toFixed(4)}rad)"><i></i></i>`}
function pzwGlint(a,b){const L=Math.hypot(b[0]-a[0],b[1]-a[1]),ang=Math.atan2(b[1]-a[1],b[0]-a[0]);return `<i class="pzw-gl" style="left:${a[0].toFixed(1)}px;top:${(a[1]-3).toFixed(1)}px;width:${L.toFixed(1)}px;transform:rotate(${ang.toFixed(4)}rad);--L:${L.toFixed(0)}px"><i></i></i>`}
function pzwFlowHtml(k){const M=PZW.meta[k==='shoot'?'shootT':k==='guide'?'guideT':'keysT']||{};
 if(k==='shoot'&&M.sh){const {C,O,G,d,aim,tn,r,E,ang}=M.sh;
  return pzwLn([C[0]+aim[0]*(r+4),C[1]+aim[1]*(r+4)],[G[0]-aim[0]*(r+1),G[1]-aim[1]*(r+1)],'white')+pzwLn([G[0]+tn[0]*(r+2),G[1]+tn[1]*(r+2)],[G[0]+tn[0]*(r+74),G[1]+tn[1]*(r+74)],'blue')+pzwGlint([O[0]+d[0]*(r+1),O[1]+d[1]*(r+1)],E)
   +`<i class="pzw-cuew" style="left:${C[0].toFixed(1)}px;top:${C[1].toFixed(1)}px;transform:rotate(${ang.toFixed(4)}rad)">${pzwCv('cueBig',330,40,'pzw-cuec',`left:${-(r+3)-330}px;top:-16px`)}</i><i class="pzw-imp" style="left:${C[0]-r-5}px;top:${C[1]-r-5}px;width:${(r+5)*2}px;height:${(r+5)*2}px"></i>`}
 if(k==='guide'&&M.gd){const {C,O,G,H,d,aim,r}=M.gd;return pzwLn([C[0]+aim[0]*(r+3),C[1]+aim[1]*(r+3)],[G[0]-aim[0]*(r+1),G[1]-aim[1]*(r+1)],'white')+pzwGlint([O[0]+d[0]*(r+1),O[1]+d[1]*(r+1)],[H[0]-d[0]*4,H[1]-d[1]*4])}
 if(k==='keys'&&M.kt){const {C,A,r}=M.kt;return pzwLn([C[0]+r+6,C[1]],[A[0]-50,A[1]],'dots')}
 return ''}
/* ---------------------------------------------------------------- the regulars in the corners ----------------------------------------------------------------
   Each is drawn once (a fixed pose) and bobs and breathes with a CSS transform; the canvas is only repainted to blink. */
function pzwMonState(side,tab){const [id,exn,prop]=(PZW_MON[tab]||PZW_MON.basics)[side==='l'?0:1],ex=Object.assign(pzCastEx(),PZ_EXP[exn]||PZ_EXP.happy);ex.lx=side==='l'?.5:-.5;
 return {id,side,ex,prop,t0:side==='l'?1.3:3.4,nb:performance.now()/1000+1.5+Math.random()*2,bs:-9,shut:0}}
function pzwMonPaint(cv,st,shut){const g=cv.getContext('2d'),k=cv.width/270,t=st.t0;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,cv.width,cv.height);
 const fn=pzMon[st.id];if(!fn)return;g.setTransform(k,0,0,k,0,0);g.lineJoin='round';g.lineCap='round';
 if(!st.fit)st.fit=pzMonFit(st.id,220,236,0);const f=st.fit,ox=25,oy=10,ex=Object.assign({},st.ex);if(shut)ex.eo*=.1;
 g.save();g.translate(ox+f.x,oy+f.y);g.scale(f.s,f.s);try{fn(g,t,ex,{breath:0,tilt:0,bob:0,hop:0})}catch(e){}g.restore();
 if(st.prop==='cue')pzwCue(g,ox+64,oy+4,-Math.PI/2+.3,0,.5,.9,0);
 if(st.prop==='mug')pzwMug(g,ox+136,oy+128,1.15)}
/* the blink: a cheap check every 4th frame, a repaint only when the eyes close or open */
function pzwMonTick(cv){const st=cv._st;if(!st)return;const t=performance.now()/1000;if(t>st.nb){st.bs=t;st.nb=t+2.6+Math.random()*3.2}const shut=t>=st.bs&&t<st.bs+.16?1:0;if(shut!==st.shut){st.shut=shut;pzwMonPaint(cv,st,shut)}}
function pzwMonSet(root,tab,swap){['l','r'].forEach((side,i)=>{const w=root.querySelector('.pzhwm.'+side);if(!w)return;const cv=w.querySelector('canvas'),d=w.querySelector('.pzhwmd'),nst=pzwMonState(side,tab);
 if(cv._st&&cv._st.id===nst.id&&cv._st.prop===nst.prop){cv._st.ex=nst.ex;return}
 const go=()=>{cv._st=nst;pzwMonPaint(cv,nst)};
 if(!swap||PZW.still){go();return}d.classList.add('dip');setTimeout(()=>{if(!cv.isConnected)return;go();d.classList.remove('dip')},170+i*60)})}
/* ---------------------------------------------------------------- the tabs ---------------------------------------------------------------- */
const PZW_SVG={
 aim:'<svg viewBox="0 0 24 24" width="30" height="30"><circle cx="12" cy="12" r="7" fill="none" stroke="currentColor" stroke-width="2.6"/><path d="M12 2.5v5M12 16.5v5M2.5 12h5M16.5 12h5" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/><circle cx="12" cy="12" r="1.8" fill="currentColor"/></svg>',
 power:'<svg viewBox="0 0 24 24" width="30" height="30"><rect x="2.5" y="13" width="5" height="8.5" rx="1.4" fill="currentColor"/><rect x="9.5" y="8" width="5" height="13.5" rx="1.4" fill="currentColor"/><rect x="16.5" y="2.5" width="5" height="19" rx="1.4" fill="currentColor"/></svg>',
 spin:'<svg viewBox="0 0 24 24" width="30" height="30"><circle cx="12" cy="12" r="9.2" fill="#e8e0ff" stroke="#12081f" stroke-width="2"/><circle cx="12" cy="7.2" r="2.7" fill="#e8364e" stroke="#12081f" stroke-width="1.2"/></svg>',
 back:'<svg viewBox="0 0 12 20" width="12" height="19"><path d="M9 3L3 10l6 7" fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
 re:'<svg viewBox="0 0 24 24" width="24" height="24"><path d="M19 12.5a7 7 0 1 1-2.2-5.6" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><path d="M19.6 3.6v4.8h-4.8" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>',
 ball8:'<svg viewBox="0 0 32 32" width="32" height="32"><circle cx="16" cy="16" r="13.6" fill="#1d1724" stroke="#12081f" stroke-width="3"/><circle cx="16" cy="15.4" r="6.6" fill="#fffdf6"/><text x="16" y="19.2" text-anchor="middle" font-family="Poppins,sans-serif" font-weight="800" font-size="10.5" fill="#1a1028">8</text><ellipse cx="10" cy="9" rx="3.2" ry="1.8" fill="#fff" opacity=".45" transform="rotate(-35 10 9)"/></svg>',
 arrow:'<svg viewBox="0 0 64 70" width="64" height="70"><defs><linearGradient id="pzwag" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#f0a02a"/><stop offset="1" stop-color="#ffe27a"/></linearGradient></defs><path d="M5 24h29V8l26 27-26 27V46H5z" fill="url(#pzwag)" stroke="#12081f" stroke-width="4.4" stroke-linejoin="round"/><path d="M9 28.5h28" stroke="#fff6c8" stroke-width="2.4" stroke-linecap="round" opacity=".7"/></svg>',
 rays:'<svg viewBox="0 0 34 30" width="34" height="30"><g stroke-linecap="round"><path d="M17 4l3 9M5 12l9 6M28 3l-3 10" stroke="#12081f" stroke-width="6"/><path d="M17 4l3 9M5 12l9 6M28 3l-3 10" stroke="#3ee8a0" stroke-width="3"/></g></svg>'};
const pzwK=t=>`<kbd>${t}</kbd>`;
function pzwDet(s){
 if(s==='aim')return `<b class="pzw-dt">Aim</b><p class="pzw-dp"><b>Move the mouse</b>: the cue turns to follow it, and the guide shows the shot before you take it.</p>
  <div class="pzw-dart">${pzwCv('dAim',392,122)}${pzwCv('aimRot',392,122,'pzw-arot')}${pzwCv('mouseLR',104,66,'pzw-msw','left:282px;top:28px')}</div>
  <div class="pzw-drow"><span>${pzwK('Shift')} or right button: <b>fine aim</b></span><span>${pzwK('Wheel')}${pzwK('<i class="pzw-ar">◀ ▶</i>')} <b>nudge</b></span></div>`;
 if(s==='spin')return `<b class="pzw-dt">Spin</b><p class="pzw-dp">Hit the cue ball <b>off-centre</b>: click the <b>spin ball</b> at the bottom left of the table to choose where.</p>
  <div class="pzw-dart">${pzwCv('dSpin',392,122)}<i class="pzw-sdot"></i><div class="pzw-sleg"><span class="pzw-sl s0"><i style="--c:#3ee89a"></i><span><b>Top</b> = follow: it rolls on</span></span><span class="pzw-sl s1"><i style="--c:#ff9a3a"></i><span><b>Bottom</b> = draw: it comes back</span></span><span class="pzw-sl s2"><i style="--c:#b88aff"></i><span><b>Side</b> = changes the rebound</span></span></div></div>
  <div class="pzw-drow"><span>${pzwK('W')}${pzwK('A')}${pzwK('S')}${pzwK('D')} <b>set the spin</b></span><span>${pzwK('R')} <b>reset</b></span></div>`;
 return `<b class="pzw-dt">Power</b><p class="pzw-dp"><b>Press on the table, pull back</b> and let go.<br>Or set the power bar and press SHOOT (${pzwK('Space')}).</p>
  <div class="pzw-dart">${pzwCv('dPow',392,122)}${pzwCv('cueH',236,28,'pzw-pcue','left:2px;top:59px')}${pzwCv('mousePr',72,80,'pzw-pm','left:306px;top:18px')}<i class="pzw-hit"></i></div>
  <div class="pzw-drow pw"><div class="pzw-pb"><i></i></div><span class="pzw-shootb">SHOOT</span></div>`}
function pzwTab(k){
 if(k==='shoot'){const s=PZW.sub,si=['aim','power','spin'].indexOf(s);
  return `<div class="pzw-shoot"><div class="pzw-top">
   <div class="pzw-tbl pzw-c" style="--i:0">${pzwCv('shootT',672,326)}${pzwOv('shoot',672,326)}</div>
   <div class="pzw-sel pzw-c" style="--i:1;--k:${si}"><i class="pzw-slot" style="top:0"></i><i class="pzw-slot" style="top:113px"></i><i class="pzw-slot" style="top:226px"></i><i class="pzw-pill"></i>${[['aim','Aim'],['power','Power'],['spin','Spin']].map(([v,l],i)=>`<button data-s="${v}" class="${v===s?'on':''}" style="top:${i*113}px">${PZW_SVG[v]}<b>${l}</b></button>`).join('')}</div>
   <div class="pzw-det pzw-c" id="pzwdet" style="--i:2" data-s="${s}">${pzwDet(s)}</div></div>
   <div class="pzw-strip pzw-c" style="--i:3">${[['aim','mAim','Aim','<b>Move the mouse.</b> Gold guide = the ball you hit, blue guide = the cue ball.'],['power','mPow','Power',`<b>Press on the table, pull back</b> and let go. Or set the power bar and press SHOOT (${pzwK('Space')}).`],['spin','mSpin','Spin','Top = follow. Bottom = draw back. Side = changes the rebound.']].map(([v,a,t,p])=>`<div class="pzhcard pzw-mini" data-s="${v}"><div class="pzw-mf">${pzwCv(a,150,92)}</div><div class="pzw-mt"><b>${t}</b><p>${p}</p></div></div>`).join('<i class="pzw-vs"></i>')}</div></div>`}
 if(k==='fouls')return `<div class="pzw-fouls"><div class="pzw-fh pzw-c" style="--i:0"><b>Fouls</b><p>A foul is an illegal shot. Here are the common fouls and what happens next.</p></div>
  <div class="pzw-frow">
   <div class="pzhcard pzw-f pzw-c" style="--i:1"><div class="pzw-fart">${pzwCv('scratch',340,190)}${pzwCv('xmark',44,44,'pzw-xm','--d:.35s')}</div><p>The cue ball <b>enters a pocket</b>.</p></div>
   <div class="pzhcard pzw-f pzw-c" style="--i:2"><div class="pzw-fart">${pzwCv('wrong',340,190)}${pzwCv('xmark',44,44,'pzw-xm','--d:.45s')}</div><p>Your <b>first contact</b> must be one of your own balls (or any ball but the 8 while the table is open).</p></div>
   <i class="pzw-farr pzw-c" style="--i:3">${PZW_SVG.arrow}</i>
   <div class="pzhcard pzw-f hi pzw-c" style="--i:4"><div class="pzw-fhd">${PZW_SVG.rays}<b>Opponent gets<br>ball in hand</b><i class="flip">${PZW_SVG.rays}</i></div><div class="pzw-fart">${pzwCv('bih',372,150)}</div><p>After a foul, the other player gets <b>ball in hand</b> and may place the cue ball <b>anywhere</b>. Do not hand it to the monsters!</p></div></div>
  <div class="pzw-finfo pzw-c" style="--i:5"><i class="pzw-ii">i</i><b>Other fouls</b><p>Also a foul: hitting no ball at all, no ball reaching a cushion after the hit (when nothing drops), or running out of shot clock. A foul on the break gives ball in hand behind the line; potting the 8 on a foul loses the rack.</p></div></div>`;
 if(k==='extras'){const gd=(()=>{try{return PZS().guide}catch(e){return 'full'}})();
  return `<div class="pzw-extras"><div class="pzhcard pzw-gd pzw-c" style="--i:0"><div class="pzw-gh"><b>The guide</b><span>${pzwK('G')} switches Full · Short · Pro</span></div>
   <p class="pzw-gp">It shows where things head, never the whole shot: <b>judging the pocket is up to you</b>.</p>
   <div class="pzw-gtbl">${pzwCv('guideT',596,226)}${pzwOv('guide',596,226)}</div>
   <div class="pzw-gms">${[['full','gFull','Full','Ghost ball, gold to the first cushion, the blue cue-ball path'],['short','gShort','Short','Ghost ball and the first stretch of each line'],['pro','gPro','Pro','Just the aim line (a trophy against Mortimer)']].map(([v,a,t,p])=>`<div class="pzw-gm ${v===gd?'on':''}" data-g="${v}">${pzwCv(a,176,62)}<b>${t}${v===gd?'<s>yours</s>':''}</b><span>${p}</span></div>`).join('')}</div></div>
   <div class="pzw-xs">${[['taunt','Taunts',`When a monster misses you may get a taunt: <b>type it in time</b> and its next shot wobbles. ${pzwK('Esc')} skips it; Settings can switch them off.`],['fast','Fast-forward',`Hold ${pzwK('Space')} or the mouse while balls roll or a monster thinks: it all runs 3× faster.`],['clock','Shot clock','Matches run a clock on your turn (45 s; Mortimer: 25 s). Run out and it is a foul. None in practice, against Gloop or in your first match.'],['house','House rules','Every regular has one house rule, like Barnacle\'s <b>bank the 8</b>. It is shown when you pick them at the bar, and in the pause menu.']].map(([a,t,p],i)=>`<div class="pzhcard pzw-x pzw-c" style="--i:${i+1}"><div class="pzw-xf">${pzwCv(a,146,88)}</div><div><b>${t}</b><p>${p}</p></div></div>`).join('')}</div></div>`}
 if(k==='keys'){const row=([a,b,pr])=>`<div data-probe="${pr}"><kbd>${a}</kbd><span>${b}</span></div>`;
  return `<div class="pzw-keys"><div class="pzw-kl"><div class="pzw-kt">
   <div class="pzhcard pzw-kc pzw-c" style="--i:0"><b>Aim</b>${pzwCv('mouseLR',128,96,'pzw-msw2')}<p><b>Aim with the mouse.</b> Press, pull back and let go to shoot.</p></div>
   <div class="pzw-ktbl pzw-c" style="--i:1">${pzwCv('keysT',488,296)}${pzwOv('keys',488,296)}${[1,2,3,4,5,6].map(n=>`<i class="pzw-pk" data-p="${n}" style="--n:${n}">${n}</i>`).join('')}</div>
   <div class="pzhcard pzw-kc pzw-c" style="--i:2"><b>Shoot</b><div class="pzw-vbar"><i></i></div>${pzwK('Space')}<p>Shoot with the power bar; hold to fast-forward while balls are moving.</p></div></div>
   <div class="pzw-kb">
    <div class="pzhcard pzw-kx sp pzw-c" style="--i:3"><b>Spin</b><div class="pzw-kspin"><div><div class="pzw-wasd">${pzwK('W')}<br>${pzwK('A')}${pzwK('S')}${pzwK('D')}</div><span>Set the spin</span></div><i class="pzw-vsep"></i><div>${pzwK('R')}<span>Reset spin</span></div></div></div>
    <div class="pzhcard pzw-kx pzw-c" style="--i:4"><b>Call a pocket for the 8</b><div class="pzw-k16">${[1,2,3,4,5,6].map(n=>pzwK(n)).join('')}</div><span>Press 1–6 (or click a pocket) to call it.</span></div>
    <div class="pzhcard pzw-kx pzw-c" style="--i:5"><b>Guide</b>${pzwK('G')}<span>Change the guide.</span></div></div></div>
   <div class="pzw-kr pzw-c" style="--i:6"><div class="pzhowk"><h4>Essential controls</h4>${PZW_KEYS.ess.map(row).join('')}<h4>Advanced controls</h4>${PZW_KEYS.adv.map(row).join('')}</div></div></div>`}
 /* basics */
 return `<div class="pzw-row3">${[['groups',1,'Solids or stripes','After the break, the first ball you pot picks your group (<b>solids 1–7</b> or <b>stripes 9–15</b>). Your opponent gets the other one.','Open table: hit any ball but the 8'],
  ['eight',2,'Then the 8','Clear your group, <b class="gd">call a pocket</b> and sink the 8 there. Sink it early, or in another pocket, and you lose the rack.','Your aim calls the pocket; 1–6 change it'],
  ['race',3,'Win the race','A match is a race: the first to win the target number of racks (shown at the top) takes the prize.','Golden break: the 8 on the break wins the rack']]
  .map(([a,n,t,p,tip],i)=>`<div class="pzhcard pzw-bc pzw-c" style="--i:${i}"><div class="pzw-ch"><i class="pzw-num">${n}</i><b>${t}</b></div><div class="pzw-art">${pzwCv(a,374,212)}${a==='eight'?'<i class="pzw-ring"></i>':''}</div><p>${p}</p><em class="pzw-tip">${tip}</em></div>`).join('')}</div>`}
/* ---------------------------------------------------------------- 96v overrides ---------------------------------------------------------------- */
function pzHowBody(tab,full){const k=PZW_TABS.some(x=>x[0]===tab)?tab:'basics';
 return `<div class="pzhow pzhw ${full?'full':'modal'}"><div class="pzhtabs">${PZW_TABS.map(([v,l],i)=>`<button data-h="${v}" class="${v===k?'on':''}" style="--i:${i}">${l}</button>`).join('')}</div><div class="pzhbody pzw-first" id="pzhbody" data-t="${k}">${pzwTab(k)}</div></div>`}
/* draw a freshly inserted tab body (or detail panel): art, overlays, live loops and the controls inside it */
function pzwFill(box){box.querySelectorAll('canvas[data-art]').forEach(pzwPaint);
 {const r=box.querySelector('.pzw-ring'),M=PZW.meta.eight;if(r&&M&&M.ring){const [x,y,rr]=M.ring,cv=r.parentNode.querySelector('canvas'),k=cv.clientWidth/374||1;r.style.left=(x*k-rr)+'px';r.style.top=(y*k-rr)+'px';r.style.width=r.style.height=rr*2+'px'}}
 box.querySelectorAll('.pzw-fart').forEach(f=>{const cv=f.querySelector('canvas[data-art]'),x=f.querySelector('.pzw-xm');if(!x||!cv)return;const M=PZW.meta[cv.dataset.art];if(M&&M.x){x.style.left=(M.x[0]-22+2)+'px';x.style.top=(M.x[1]-22+2)+'px'}});
 {const M=PZW.meta.keysT;if(M&&M.kt)box.querySelectorAll('.pzw-pk').forEach(p=>{const q=M.kt.pk[+p.dataset.p-1];p.style.left=(q[0]-16)+'px';p.style.top=(q[1]-16)+'px'})}
 box.querySelectorAll('.pzw-flow').forEach(f=>{f.innerHTML=pzwFlowHtml(f.dataset.flow);f.querySelectorAll('canvas[data-art]').forEach(pzwPaint)});
 box.querySelectorAll('.pzw-sel button').forEach(b=>b.onclick=()=>pzwSub(b.dataset.s));
 box.querySelectorAll('.pzw-mini').forEach(b=>b.onclick=()=>pzwSub(b.dataset.s))}
function pzwSub(s){const sel=document.querySelector('#pzhbody .pzw-sel'),det=$('pzwdet');if(!sel||!det||det.dataset.s===s)return;PZW.sub=s;pzFx('tick');
 const i=['aim','power','spin'].indexOf(s);sel.style.setProperty('--k',i);sel.querySelectorAll('button').forEach(b=>b.classList.toggle('on',b.dataset.s===s));
 det.dataset.s=s;det.classList.remove('pzw-c');det.innerHTML=pzwDet(s);det.classList.remove('swap');void det.offsetWidth;det.classList.add('swap');pzwFill(det)}
function pzwTabGo(host,k,full){const body=host.querySelector('#pzhbody');if(!body)return;if(body.dataset.t===k)return;PZ.howTab=k;pzFx('tick');
 host.querySelectorAll('.pzhtabs button').forEach(b=>{const on=b.dataset.h===k;b.classList.toggle('on',on);if(on){b.classList.remove('pop');void b.offsetWidth;b.classList.add('pop')}});
 body.classList.remove('pzw-first');body.dataset.t=k;body.innerHTML=pzwTab(k);pzwFill(body);if(full){const root=host.closest('.pzhwS')||host;pzwMonSet(root,k,true)}}
function pzHowWire(host,full){PZW.still=!!(typeof pzRM==='function'&&pzRM());const box=host.querySelector('.pzhow');if(box&&PZW.still)box.classList.add('pzwrm');
 host.querySelectorAll('.pzhtabs button').forEach(b=>{b.onclick=()=>pzwTabGo(host,b.dataset.h,full);b.addEventListener('animationend',()=>b.classList.remove('pop'))});
 const body=host.querySelector('#pzhbody');if(body){pzwFill(body);setTimeout(()=>{if(body.isConnected)body.classList.remove('pzw-first')},1300)}}
function pzRules(){PZ.howTab=PZ.howTab||'basics';const tab=pzwOk(PZ.howTab),tok=PZ.tok;
 const mon=s=>`<div class="pzhwm ${s}"><div class="pzhwmd"><div class="pzhwmb"><canvas width="405" height="396" style="width:270px;height:264px"></canvas></div></div></div>`;
 show(`<div class="pzr pzhwscr" id="pzr"><canvas id="pzrbg" width="1600" height="900"></canvas><div class="pzhwS pzwin">
  <button class="pzback pzhwbk" id="pzbk">${PZW_SVG.back}<span>The bar</span></button>
  <div class="pzhwsign"><div class="pzhwsw">${pzwCv('sign',480,132)}<span>How to Play</span></div></div>
  <div class="pzhwpan">${pzHowBody(tab,true)}<div class="pzhfoot pzhwfoot"><button class="pzmb pzw-re" id="pzhre">${PZW_SVG.re}<span>Replay the tutorials</span></button><button class="pzmb gold pzw-pr" id="pzhpr">${PZW_SVG.ball8}<span>Try it at the Practice Table</span><i class="pzw-shw"><i></i></i><i class="pzw-spk"><i></i><i></i><i></i></i></button></div></div>
  ${mon('l')}${mon('r')}${pzwCv('rail',1600,64,'pzhwrail')}</div></div>`,'casbg pzx');
 $('pzrbg').getContext('2d').drawImage(pzHubBake(),0,0);
 const root=ov.querySelector('.pzhwS');pzHowWire(root,true);root.querySelectorAll(':scope>.pzhwsign canvas,:scope>canvas.pzhwrail').forEach(pzwPaint);
 if(PZW.still)root.classList.add('pzwrm');
 pzwMonSet(root,tab,false);root.querySelectorAll('.pzhwm canvas').forEach(cv=>{if(!PZW.still)LIVE.push({cv,fn:()=>pzwMonTick(cv),slow:4,ph:cv.closest('.l')?0:2})});
 $('pzbk').onclick=()=>pzHub();S.back=()=>pzHub();
 $('pzhre').onclick=()=>{pzCoachReset();pzFx('place');pzNote('Tutorials reset: they will show again as you play.');PZ.sel=null;const tk=PZ.tok;setTimeout(()=>{if(PZ.tok===tk&&$('pzhbody'))pzHub()},700)};
 $('pzhpr').onclick=()=>{pzMusicOff();pzStart({opp:'gloop',practice:true})};
 setTimeout(()=>{if(root.isConnected&&PZ.tok===tok)root.classList.remove('pzwin')},1700);
 pzFitTM()}
function pzwOk(t){return PZW_TABS.some(x=>x[0]===t)?t:'basics'}
function pzRulesModal(){PZ.howTab=pzwOk(PZ.howTab||'basics');const m=pzModal(`<div class="pzh2">How to Play</div>${pzHowBody(PZ.howTab,false)}<button class="pzmb gold pzw-back" data-a="back">Back</button>`,'pause wide how97');if(!m)return;pzHowWire(m,false);m.querySelector('[data-a=back]').onclick=()=>pzPauseMenu(true)}
/* up/down pick Aim, Power or Spin on the Shooting tab (left/right still switch tabs, 96v) */
if(!window.__pzw97Keys){window.__pzw97Keys=1;addEventListener('keydown',e=>{try{if(e.repeat||(e.key!=='ArrowUp'&&e.key!=='ArrowDown'))return;const sel=document.querySelector('#pzhbody .pzw-sel');if(!sel||pzCoachActive())return;
 const bs=[...sel.querySelectorAll('button')],i=bs.findIndex(b=>b.classList.contains('on')),n=bs[(i+(e.key==='ArrowDown'?1:-1)+bs.length)%bs.length];if(n){e.preventDefault();e.stopImmediatePropagation();n.click()}}catch(err){}},true)}
{const st=document.createElement('style');st.textContent=`
#pzr.pzhwscr.pzscrin>.pzhwS{animation:none}
.pzhwS{position:absolute;left:0;top:0;width:1600px;height:900px}
.pzhwscr .pzhwbk{left:22px;top:20px;z-index:7;display:flex;align-items:center;gap:10px;height:54px;padding:0 24px 0 18px;border-radius:17px;border:3px solid #4f43a6;box-shadow:0 0 0 3px #12081f,inset 0 2px 0 #ffffff22,0 8px 20px #0008;font:800 20px Poppins,sans-serif;color:#efe8ff;transition:transform .22s cubic-bezier(.3,1.5,.5,1)}
.pzhwscr .pzhwbk:hover{transform:translateY(-2px);border-color:#ffd45a}.pzhwscr .pzhwbk:active{transform:scale(.94)}
.pzhwsign{position:absolute;left:560px;top:0;width:480px;height:132px;z-index:6;pointer-events:none;transform-origin:50% 0}
.pzhwsw{position:absolute;inset:0;transform-origin:50% 0;animation:pzwSway 6s ease-in-out 1.3s infinite}
.pzhwsign canvas{position:absolute;left:0;top:0}
.pzhwsign span{position:absolute;left:0;right:0;top:44px;text-align:center;font:400 68px/1 "Pirata One",Georgia,serif;color:#ffd45a;letter-spacing:.5px;white-space:nowrap;
 text-shadow:0 4px 0 #12081f,3px 0 0 #12081f,-3px 0 0 #12081f,0 -3px 0 #12081f,2px 2px 0 #12081f,-2px 2px 0 #12081f,2px -2px 0 #12081f,-2px -2px 0 #12081f,0 7px 0 #3a1806}
.pzhwpan{position:absolute;left:140px;top:132px;width:1320px;height:660px;box-sizing:border-box;border-radius:30px;z-index:2;
 background:linear-gradient(180deg,#271e6c 0%,#1b1454 38%,#120b3a 100%);border:3px solid #5446ae;box-shadow:0 0 0 3px #12081f,inset 0 2px 0 #ffffff26,inset 0 -4px 0 #0000004d,0 24px 54px #000c}
.pzhwpan::before{content:'';position:absolute;left:3px;right:3px;top:3px;height:180px;border-radius:26px 26px 0 0;background:linear-gradient(180deg,#ffffff10,#ffffff00);pointer-events:none}
.pzhwpan>.pzhow{position:absolute;left:26px;right:26px;top:16px}
.pzhwm{position:absolute;top:630px;width:270px;height:264px;z-index:1;pointer-events:none}.pzhwm.l{left:-58px}.pzhwm.r{left:1388px}
.pzhwmd{width:100%;height:100%;transition:transform .5s cubic-bezier(.3,1.6,.5,1)}.pzhwmd.dip{transform:translateY(78%);transition:transform .17s cubic-bezier(.6,0,1,.6)}
.pzhwmb{width:100%;height:100%;transform-origin:50% 100%;animation:pzwBobL 3.6s ease-in-out infinite;will-change:transform}.pzhwm.r .pzhwmb{animation-name:pzwBobR;animation-duration:4.1s}
.pzhwm canvas{display:block}
.pzhwrail{position:absolute;left:0;top:836px;z-index:4;pointer-events:none}
.pzhwfoot{position:absolute;left:0;right:0;top:592px;display:flex;justify-content:center;gap:20px;margin:0}
.pzhwfoot .pzmb{position:relative;display:flex;align-items:center;gap:12px;width:auto;height:56px;margin:0;padding:0 30px;border-radius:17px;font:800 20px Poppins,sans-serif;transition:transform .22s cubic-bezier(.3,1.5,.5,1)}
.pzhwfoot .pzmb:hover{transform:translateY(-3px)}.pzhwfoot .pzmb:active{transform:translateY(2px) scale(.96)}
.pzhwfoot .pzw-re{background:linear-gradient(180deg,#4033a4,#2a1f7e);border-color:#12081f;box-shadow:inset 0 2px 0 #ffffff26,0 5px 0 #0c0828;color:#f4eeff}.pzhwfoot .pzw-re svg{color:#d8ccff}
.pzhwfoot .pzw-pr{padding:0 30px 0 14px;color:#2a1604;box-shadow:inset 0 2px 0 #ffffff80,0 5px 0 #9a6a10}
.pzw-shw{position:absolute;inset:0;border-radius:14px;overflow:hidden;pointer-events:none}.pzw-shw i{position:absolute;top:-10px;bottom:-10px;left:0;width:60px;background:linear-gradient(90deg,#fff0,#fff9,#fff0);transform:translateX(-140%) skewX(-20deg);animation:pzwShine 5s ease-in-out 1.6s infinite}
.pzw-spk{position:absolute;right:-30px;top:50%;width:24px;height:44px;margin-top:-22px;pointer-events:none}
.pzw-spk i{position:absolute;left:4px;width:15px;height:5px;border-radius:3px;background:#ffd45a;box-shadow:0 0 0 2px #12081f;transform-origin:0 50%;animation:pzwSpark 2.6s ease-out 1.4s infinite both}
.pzw-spk i:nth-child(1){top:4px;transform:rotate(-32deg)}.pzw-spk i:nth-child(2){top:20px}.pzw-spk i:nth-child(3){top:36px;transform:rotate(32deg)}
/* tabs */
.pzhw .pzhtabs{display:flex;gap:12px;justify-content:center;height:50px;margin:0 0 12px}
.pzhw .pzhtabs button{position:relative;height:46px;padding:0 26px;border-radius:15px;border:3px solid #12081f;background:linear-gradient(180deg,#3d3196,#271d72);color:#efe8ff;font:800 17px Poppins,sans-serif;cursor:pointer;
 box-shadow:inset 0 2px 0 #ffffff24,0 4px 0 #c8902c;transition:transform .2s cubic-bezier(.3,1.5,.5,1)}
.pzhw .pzhtabs button:hover{transform:translateY(-2px)}
.pzhw .pzhtabs button.on{background:linear-gradient(180deg,#ffe57e,#f4b22e);color:#2a1604;transform:translateY(-3px);box-shadow:inset 0 2px 0 #ffffffa0,0 5px 0 #9a6410}
.pzhw .pzhtabs button.pop{animation:pzwTab .38s cubic-bezier(.3,1.6,.5,1)}
.pzhw #pzhbody{position:relative;height:498px;text-align:left}
.pzhw kbd{display:inline-block;min-width:16px;padding:0 7px;border-radius:7px;border:2px solid #12081f;background:linear-gradient(180deg,#43389e,#2b2172);box-shadow:0 2px 0 #0a0620,inset 0 1px 0 #ffffff30;font:800 12px/20px Poppins,sans-serif;color:#fff6dc;text-align:center;vertical-align:1px;margin:0 1px}
.pzhw p b,.pzhw span b{font-weight:800;color:#fff2c8}.pzhw p kbd{padding:0 5px;border-radius:6px;font-size:11px;line-height:15px;vertical-align:1px}.pzhw p b.gd{color:#ffd45a}.pzhw em{font-style:normal}
.pzhw .pzhcard{animation:none;padding:0;background:none;border:0;border-radius:0}
.pzhw .pzhcard canvas,.pzhw canvas{display:block;border-radius:0;aspect-ratio:auto}
.pzhw .pzhcard>b{display:block;margin:0;font:inherit;color:inherit}
.pzhw .pzhcard p{margin:0;font:500 14px/1.45 Poppins,sans-serif;color:#ddd5f6}
.pzhw .pzhcard p b{display:inline;margin:0;font:800 14px Poppins,sans-serif;color:#fff2c8}
.pzw-card,.pzhw .pzw-bc,.pzhw .pzw-f,.pzhw .pzw-x,.pzhw .pzw-kc,.pzhw .pzw-kx,.pzhw .pzw-gd,.pzw-tbl,.pzw-det,.pzw-strip,.pzw-ktbl,.pzw-kr,.pzw-fh,.pzw-finfo{box-sizing:border-box;border-radius:20px;background:linear-gradient(180deg,#1c1450,#120b38);border:2px solid #382f7a;box-shadow:inset 0 1px 0 #ffffff1a,0 6px 16px #0006}
.pzhw .pzw-c{animation:pzwRise .44s calc(var(--i,0)*.06s) cubic-bezier(.3,1.35,.5,1) backwards}
.pzhw .pzw-first .pzw-c{animation-delay:calc(.34s + var(--i,0)*.07s)}.pzhw.modal .pzw-first .pzw-c{animation-delay:calc(.12s + var(--i,0)*.045s)}
/* basics */
.pzw-row3{display:flex;gap:18px;height:100%}
.pzhw .pzw-bc{flex:1;min-width:0;display:flex;flex-direction:column;padding:14px 16px 16px}
.pzw-ch{display:flex;align-items:center;gap:14px;height:58px;margin:0 0 10px}
.pzw-num{flex:none;width:52px;height:52px;border-radius:50%;background:radial-gradient(circle at 38% 32%,#fff1a0,#ffd04a 45%,#e89a1c);border:3px solid #12081f;box-shadow:inset 0 -3px 0 #c07810,0 3px 0 #0008;display:flex;align-items:center;justify-content:center;font:400 34px/1 "Pirata One",Georgia,serif;color:#2a1604;font-style:normal}
.pzhw .pzw-first .pzw-num{animation:pzwPop .5s calc(.5s + var(--i,0)*.08s) cubic-bezier(.3,1.7,.5,1) backwards}
.pzw-ch b{font:400 40px/1.16 "Pirata One",Georgia,serif;color:#ffd45a;text-shadow:0 3px 0 #12081f;white-space:nowrap}
.pzw-art{position:relative;flex:none;width:378px;height:216px;box-sizing:border-box;border-radius:16px;background:#0e0830;border:2px solid #2e2668;overflow:hidden;margin:0 auto}
.pzw-art canvas{position:absolute;left:0;top:0}
.pzw-ring{position:absolute;border-radius:50%;border:3px solid #7affd8;box-sizing:border-box;animation:pzwRing 1.7s ease-out infinite;pointer-events:none}
.pzhw .pzw-bc p{display:block;text-align:center;margin:auto 4px;padding-top:10px;font:500 15.5px/1.5 Poppins,sans-serif;color:#e6defc}
.pzhw .pzw-bc p b{font-size:15.5px}
.pzw-tip{display:block;align-self:center;margin-top:10px;padding:6px 14px;border-radius:12px;background:#0e0830;border:2px solid #2e2668;font:700 12.5px Poppins,sans-serif;color:#b8aee8;white-space:nowrap}
.pzw-tip::before{content:'★ ';color:#ffd45a}
/* shooting */
.pzw-shoot{display:flex;flex-direction:column;gap:14px;height:100%}
.pzw-top{display:flex;gap:14px;height:344px}
.pzw-tbl{position:relative;flex:none;width:690px;height:344px;background:#0e0830}
.pzw-tbl>canvas,.pzw-tbl>.pzw-flow{position:absolute;left:7px;top:7px}
.pzw-flow{overflow:hidden;pointer-events:none}.pzw-gtbl>.pzw-flow,.pzw-ktbl>.pzw-flow{position:absolute;left:0;top:0}
.pzw-ln{position:absolute;transform-origin:0 50%;overflow:hidden}.pzw-ln>i{position:absolute;left:-16px;top:0;right:0;height:100%;background-repeat:repeat-x;animation:pzwFlow .8s linear infinite}
.pzw-gl{position:absolute;height:6px;transform-origin:0 50%;overflow:hidden}.pzw-gl>i{position:absolute;left:0;top:1px;width:34px;height:4px;border-radius:2px;background:linear-gradient(90deg,#fffae000,#fffae0f0,#fffae000);opacity:0;animation:pzwGlint 2.6s ease-in-out infinite}
.pzw-cuew{position:absolute;width:0;height:0}.pzw-cuew canvas{position:absolute;animation:pzwCueLoop 2.8s infinite}
.pzw-imp{position:absolute;box-sizing:border-box;border-radius:50%;border:3px solid #fff6c8;opacity:0;animation:pzwImp 2.8s infinite}
.pzw-sel{position:relative;flex:none;width:118px;height:344px;border:0;background:none;box-shadow:none}
.pzw-slot,.pzw-pill{position:absolute;left:0;width:118px;height:118px;box-sizing:border-box;border-radius:18px}
.pzw-slot{background:linear-gradient(180deg,#2c2278,#1c1456);border:3px solid #12081f;box-shadow:inset 0 2px 0 #ffffff1c,0 4px 0 #0a0620}
.pzw-pill{top:0;background:linear-gradient(180deg,#ffe57e,#f4b22e);border:3px solid #12081f;box-shadow:inset 0 2px 0 #ffffffa0,0 5px 0 #9a6410;transform:translateY(calc(var(--k,1)*113px));transition:transform .42s cubic-bezier(.3,1.45,.5,1)}
.pzw-sel button{position:absolute;left:0;width:118px;height:118px;border:0;background:none;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;color:#c8bef0;cursor:pointer;transition:transform .2s cubic-bezier(.3,1.5,.5,1)}
.pzw-sel button b{font:800 17px Poppins,sans-serif}.pzw-sel button:hover{transform:translateY(-2px)}.pzw-sel button.on{color:#2a1604}.pzw-sel button:active{transform:scale(.94)}
.pzw-det{position:relative;flex:1;min-width:0;padding:14px 16px 0;overflow:hidden}
.pzw-det.swap>*{animation:pzwSlide .34s calc(var(--j,0)*.04s) cubic-bezier(.3,1.35,.5,1) backwards}.pzw-det.swap>*:nth-child(2){--j:1}.pzw-det.swap>*:nth-child(3){--j:2}.pzw-det.swap>*:nth-child(4){--j:3}
.pzw-dt{display:block;font:400 46px/1.25 "Pirata One",Georgia,serif;color:#ffd45a;text-shadow:0 3px 0 #12081f}
.pzhw .pzw-dp{margin:6px 0 0;min-height:42px;font:500 14px/1.45 Poppins,sans-serif;color:#e6defc}
.pzw-dart{position:relative;width:396px;height:126px;box-sizing:border-box;margin:10px 0 0;border-radius:16px;background:#0e0830;border:2px solid #2e2668;overflow:hidden}
.pzw-dart canvas{position:absolute;left:0;top:0}
.pzw-arot{transform-origin:118px 61px;animation:pzwAimSw 3.2s ease-in-out infinite alternate}
.pzw-msw{animation:pzwMSw 3.2s ease-in-out infinite alternate}
.pzw-pcue{animation:pzwPull 2.8s infinite}.pzw-pm{animation:pzwDrag 2.8s infinite}
.pzw-hit{position:absolute;left:236px;top:51px;width:40px;height:40px;border-radius:50%;border:3px solid #fff6c8;box-sizing:border-box;opacity:0;animation:pzwHit 2.8s infinite}
.pzw-sdot{position:absolute;left:58px;top:53px;width:16px;height:16px;border-radius:50%;background:#e8364e;border:2.5px solid #12081f;box-sizing:border-box;box-shadow:inset -2px -2px 0 #9a1430;animation:pzwDot 3.9s infinite}
.pzw-sleg{position:absolute;left:138px;top:10px;right:8px;display:flex;flex-direction:column;gap:5px}
.pzw-sl{display:flex;align-items:center;gap:9px;height:30px;padding:0 10px;border-radius:10px;background:#1c1450;font:600 13px Poppins,sans-serif;color:#d8d0f4;white-space:nowrap;opacity:.42;animation:pzwHi 3.9s infinite}
.pzw-sl i{flex:none;width:16px;height:16px;box-sizing:border-box;border-radius:50%;background:var(--c);border:2.5px solid #12081f}.pzw-sl b{color:#fff2c8}
.pzw-sl.s1{animation-delay:-2.6s}.pzw-sl.s2{animation-delay:-1.3s}
.pzw-drow{display:flex;align-items:center;gap:16px;height:44px;margin:12px 0 0;font:600 13px Poppins,sans-serif;color:#d8d0f4;white-space:nowrap}
.pzw-drow span{display:flex;align-items:center;gap:4px}
.pzw-drow.pw{gap:14px}
.pzw-pb{position:relative;width:258px;height:40px;box-sizing:border-box;border-radius:13px;border:3px solid #efe8ff;box-shadow:0 0 0 2.5px #12081f,inset 0 2px 6px #0008;background:#120a34;overflow:hidden}
.pzw-pb i{position:absolute;left:3px;top:3px;bottom:3px;width:calc(100% - 6px);border-radius:8px;background:linear-gradient(90deg,#e8364e,#f2713a 30%,#f7a33a 58%,#ffd45a);transform-origin:0 50%;transform:scaleX(.62);animation:pzwFill 2.8s infinite}
.pzw-pb::after{content:'';position:absolute;inset:3px;border-radius:8px;background:repeating-linear-gradient(90deg,#0000 0 30px,#12081f55 30px 32px)}
.pzw-shootb{display:flex;align-items:center;justify-content:center;width:110px;height:40px;box-sizing:border-box;border-radius:13px;border:3px solid #12081f;background:linear-gradient(180deg,#4a3db0,#2c2180);box-shadow:inset 0 2px 0 #ffffff2a,0 4px 0 #0a0620;font:800 16px Poppins,sans-serif;color:#efe8ff;letter-spacing:.5px}
.pzw-strip{display:flex;align-items:stretch;height:140px;padding:0 6px}
.pzhw .pzw-mini{flex:1;min-width:0;display:flex;align-items:center;gap:14px;padding:0 10px;cursor:pointer;border-radius:16px;transition:transform .22s cubic-bezier(.3,1.5,.5,1)}
.pzhw .pzw-mini:hover{transform:translateY(-3px)}
.pzw-vs{flex:none;width:2px;margin:18px 0;background:#2e2668;border-radius:2px}
.pzw-mf{flex:none;width:154px;height:96px;box-sizing:border-box;border-radius:12px;border:2px solid #2e2668;background:#0e0830;overflow:hidden}
.pzw-mt{min-width:0}.pzw-mt b{display:block;font:400 30px/1.16 "Pirata One",Georgia,serif;color:#ffd45a;text-shadow:0 2px 0 #12081f;;margin:0 0 2px}
.pzhw .pzw-mt p{font:500 13px/1.42 Poppins,sans-serif;color:#ddd5f6}.pzhw .pzw-mt p b{font-size:13px}
/* fouls */
.pzw-fouls{display:flex;flex-direction:column;gap:12px;height:100%}
.pzw-fh{display:flex;align-items:center;gap:22px;height:74px;padding:0 22px;flex:none;background:none;border:0;box-shadow:none}
.pzw-fh b{font:400 58px/1.25 "Pirata One",Georgia,serif;color:#ffd45a;text-shadow:0 4px 0 #12081f}
.pzhw .pzw-fh p{margin:6px 0 0;font:500 16px Poppins,sans-serif;color:#e6defc}
.pzw-frow{display:flex;align-items:stretch;gap:14px;height:334px;flex:none}
.pzhw .pzw-f{flex:none;width:372px;display:flex;flex-direction:column;padding:14px}
.pzhw .pzw-f.hi{width:404px;padding:10px 14px 12px;border:3px solid #3ee8a0;box-shadow:0 0 0 2.5px #12081f,0 0 26px #2ee89a59,inset 0 1px 0 #ffffff26;background:linear-gradient(180deg,#14404a,#0f2a3c 40%,#120b38)}
.pzw-fart{position:relative;flex:none;border-radius:14px;border:2px solid #2e2668;background:#0e0830;overflow:hidden}
.pzw-f .pzw-fart{width:344px;height:194px}.pzw-f.hi .pzw-fart{width:376px;height:154px;border-color:#2a8a6a}
.pzw-fart canvas{position:absolute;left:0;top:0}
.pzw-xm{animation:pzwX .55s var(--d,.4s) cubic-bezier(.3,1.7,.5,1) backwards}
.pzhw .pzw-f p{display:block;text-align:center;margin:auto 6px;padding-top:8px;font:500 16px/1.5 Poppins,sans-serif;color:#e6defc}
.pzhw .pzw-f p b{font-size:16px;color:#ffd45a}
.pzhw .pzw-f.hi p{padding-top:6px;font-size:14.5px;line-height:1.45}.pzhw .pzw-f.hi p b{font-size:14.5px}
.pzw-fhd{display:flex;align-items:center;justify-content:center;gap:8px;height:50px;margin:0 0 6px}
.pzw-fhd b{font:800 17px/1.12 Poppins,sans-serif;color:#fff;text-transform:uppercase;text-align:center;letter-spacing:.3px;text-shadow:0 2px 0 #12081f,2px 0 0 #12081f,-2px 0 0 #12081f,0 -2px 0 #12081f}
.pzw-fhd svg{display:block}.pzw-fhd .flip{display:block;transform:scaleX(-1)}
.pzw-farr{flex:none;width:64px;display:flex;align-items:center;justify-content:center;background:none;border:0;box-shadow:none}
.pzw-farr svg{animation:pzwNudge 1.6s ease-in-out 1.2s infinite}
.pzw-finfo{display:flex;align-items:center;gap:14px;flex:1;padding:0 22px;background:#140c3c}
.pzw-ii{flex:none;width:40px;height:40px;border-radius:50%;background:radial-gradient(circle at 38% 32%,#b48aff,#7a4ad8);border:3px solid #12081f;display:flex;align-items:center;justify-content:center;font:400 28px/1 "Pirata One",Georgia,serif;color:#fff;font-style:normal}
.pzw-finfo>b{flex:none;font:400 30px/1.16 "Pirata One",Georgia,serif;color:#ffd45a;text-shadow:0 2px 0 #12081f}
.pzhw .pzw-finfo p{margin:0;font:500 14px/1.45 Poppins,sans-serif;color:#ddd5f6}
/* guide & extras */
.pzw-extras{display:flex;gap:16px;height:100%}
.pzhw .pzw-gd{flex:none;width:636px;display:flex;flex-direction:column;padding:12px 18px 14px}
.pzw-gh{display:flex;align-items:center;justify-content:space-between;height:46px}
.pzw-gh b{font:400 40px/1.16 "Pirata One",Georgia,serif;color:#ffd45a;text-shadow:0 3px 0 #12081f}
.pzw-gh span{display:flex;align-items:center;gap:8px;font:700 14px Poppins,sans-serif;color:#d8d0f4}
.pzhw .pzw-gp{margin:4px 0 8px;font:500 13.5px/1.4 Poppins,sans-serif;color:#c8bef0}.pzhw .pzw-gp b{font-size:13.5px}
.pzw-gtbl{position:relative;flex:none;width:600px;height:230px;box-sizing:border-box;border-radius:14px;border:2px solid #2e2668;background:#0e0830;overflow:hidden}
.pzw-gtbl>canvas{position:absolute;left:0;top:0}
.pzw-gms{display:flex;gap:10px;margin-top:10px;flex:1;min-height:0}
.pzw-gm{position:relative;flex:1;min-width:0;display:flex;flex-direction:column;align-items:center;padding:7px 7px 6px;box-sizing:border-box;border-radius:14px;background:#140c3c;border:2px solid #2e2668;text-align:center}
.pzw-gm.on{border-color:#ffd45a;box-shadow:0 0 0 2px #12081f,inset 0 0 0 1px #ffd45a55}
.pzw-gm canvas{border-radius:8px}
.pzw-gm b{display:flex;align-items:center;gap:6px;margin:5px 0 1px;font:800 14px Poppins,sans-serif;color:#fff2c8}
.pzw-gm b s{padding:0 6px;border-radius:6px;background:#ffd45a;color:#2a1604;font:800 9.5px/16px Poppins,sans-serif;text-decoration:none;text-transform:uppercase}
.pzw-gm span{font:500 11.5px/1.3 Poppins,sans-serif;color:#c8bef0}
.pzw-xs{flex:1;min-width:0;display:flex;flex-direction:column;gap:14px}
.pzhw .pzw-x{flex:1;display:flex;align-items:center;gap:16px;padding:0 16px 0 12px}
.pzw-xf{flex:none;width:150px;height:92px;box-sizing:border-box;border-radius:14px;border:2px solid #2e2668;background:#0e0830;overflow:hidden}
.pzw-x b{display:block;font:400 28px/1.16 "Pirata One",Georgia,serif;color:#ffd45a;text-shadow:0 2px 0 #12081f;margin:0 0 3px}
.pzhw .pzw-x p{font:500 13.5px/1.42 Poppins,sans-serif;color:#ddd5f6}.pzhw .pzw-x p b{font-size:13.5px}
/* controls */
.pzw-keys{display:flex;gap:16px;height:100%}
.pzw-kl{flex:none;width:816px;display:flex;flex-direction:column;gap:14px}
.pzw-kt{display:flex;gap:12px;height:296px}
.pzhw .pzw-kc{flex:none;width:152px;display:flex;flex-direction:column;align-items:flex-start;padding:12px 12px 10px}
.pzhw .pzw-kc>b,.pzhw .pzw-kx>b{font:800 21px Poppins,sans-serif;color:#ffd45a;margin:0 0 6px;white-space:nowrap}
.pzw-kc canvas{align-self:center;margin:2px 0 6px}
.pzhw .pzw-kc p{font:500 13.5px/1.45 Poppins,sans-serif;color:#ddd5f6}.pzhw .pzw-kc p b{font-size:13.5px}
.pzw-kc>kbd{align-self:center;margin:8px 0 10px;padding:0 16px;font-size:14px;line-height:28px}
.pzw-vbar{align-self:center;position:relative;width:30px;height:82px;box-sizing:border-box;border-radius:9px;border:3px solid #efe8ff;box-shadow:0 0 0 2.5px #12081f;background:#120a34;overflow:hidden}
.pzw-vbar i{position:absolute;left:2px;right:2px;bottom:2px;height:calc(100% - 4px);border-radius:5px;background:linear-gradient(0deg,#e8364e,#f2713a 35%,#f7a33a 65%,#ffd45a);transform-origin:50% 100%;animation:pzwVFill 2.8s infinite}
.pzw-ktbl{position:relative;flex:none;width:488px;height:296px;background:none;border:0;box-shadow:none}
.pzw-ktbl>canvas{position:absolute;left:0;top:0}
.pzw-pk{position:absolute;width:32px;height:32px;box-sizing:border-box;border-radius:50%;background:radial-gradient(circle at 38% 32%,#5a3ab8,#341f86);border:3px solid #efe8ff;box-shadow:0 0 0 2.5px #12081f,0 3px 0 2px #0a0620;display:flex;align-items:center;justify-content:center;font:800 16px Poppins,sans-serif;color:#fff;font-style:normal}
.pzhw .pzw-first .pzw-pk,.pzhw .pzw-pk{animation:pzwPop .45s calc(.35s + var(--n)*.06s) cubic-bezier(.3,1.7,.5,1) backwards}
.pzw-kb{display:flex;gap:14px;flex:1;min-height:0}
.pzhw .pzw-kx{display:flex;flex-direction:column;padding:12px 16px 12px}
.pzw-kx.sp{flex:none;width:300px}.pzw-kx:nth-child(2){flex:none;width:336px}.pzw-kx:nth-child(3){flex:1;min-width:0;align-items:center;text-align:center}
.pzw-kx span{font:500 13px/1.4 Poppins,sans-serif;color:#ddd5f6}
.pzw-kx kbd,.pzw-kc>kbd{min-width:24px;font-size:16px;line-height:34px;padding:0 9px;border-radius:9px;border-width:3px;box-shadow:0 4px 0 #0a0620,inset 0 2px 0 #ffffff30}
.pzw-kspin{display:flex;align-items:center;gap:16px;flex:1}
.pzw-kspin>div{display:flex;flex-direction:column;align-items:center;gap:6px}
.pzw-wasd{text-align:center;line-height:0}.pzw-wasd kbd{margin:2px}
.pzw-vsep{width:2px;height:90px;background:#2e2668;border-radius:2px}
.pzw-k16{display:flex;gap:8px;margin:8px 0 12px}.pzw-k16 kbd{width:44px;box-sizing:border-box;padding:0}
.pzw-kx:nth-child(3) kbd{margin:8px 0 10px}
.pzw-kr{flex:1;min-width:0;padding:8px 12px}
.pzhw .pzhowk{display:flex;flex-direction:column;gap:3px;padding:0}
.pzhw .pzhowk h4{margin:0 4px 2px;font:800 18px/22px Poppins,sans-serif;color:#ffd45a}
.pzhw .pzhowk h4:nth-of-type(2){margin-top:6px}
.pzhw .pzhowk>div{display:flex;align-items:center;gap:10px;min-height:32px;padding:2px 8px 2px 4px;box-sizing:border-box;border-radius:11px;background:#140c3c;border:2px solid #2a2266;animation:none}
.pzhw .pzhowk kbd{flex:none;min-width:120px;box-sizing:border-box;padding:0 9px;border-radius:9px;background:#0a0620;border:2px solid #5a4ca0;box-shadow:none;font:800 12.5px/26px Poppins,sans-serif;color:#fff;text-align:center;white-space:nowrap}
.pzhw .pzhowk span{flex:1;min-width:0;font:600 12.5px/1.28 Poppins,sans-serif;color:#efe8ff}.pzhw .pzw-ar{font:13px/1 "Segoe UI Symbol","DejaVu Sans",sans-serif;font-style:normal;letter-spacing:1px}.pzhw .pzhowk span em{color:#ffd45a}
/* the pause-menu version */
.pzmod.how97 .pzmp{width:1330px;box-sizing:border-box;padding:16px 31px 20px}
.pzmod.how97 .pzh2{margin:0 0 8px;font-size:48px}
.pzmod.how97 .pzw-back{width:300px;margin:14px auto 0}
/* entrance */
.pzwin .pzhwsign{animation:pzwSign .8s cubic-bezier(.3,1.25,.5,1) backwards}
.pzwin .pzhwpan{animation:pzwPan .5s .05s cubic-bezier(.3,1.25,.5,1) backwards}
.pzwin .pzhtabs button{animation:pzwPop .42s calc(.16s + var(--i)*.05s) cubic-bezier(.3,1.6,.5,1) backwards}.pzwin .pzhtabs button.on{animation-name:pzwPopOn}
.pzwin .pzhwfoot .pzmb{animation:pzwPop .45s .55s cubic-bezier(.3,1.6,.5,1) backwards}.pzwin .pzhwfoot .pzw-pr{animation-delay:.62s}
.pzwin .pzhwm>.pzhwmd>.pzhwmb>canvas{animation:pzwPeek .75s .7s cubic-bezier(.3,1.45,.5,1) backwards}.pzwin .pzhwm.r>.pzhwmd>.pzhwmb>canvas{animation-delay:.84s}
.pzwin .pzhwbk{animation:pzwFromL .45s .1s cubic-bezier(.3,1.3,.5,1) backwards}
.pzwin .pzhwrail{animation:pzwUp .5s .1s cubic-bezier(.3,1.2,.5,1) backwards}
.pzwrm *,.pzwrm{animation:none!important;transition:none!important}
@keyframes pzwSign{0%{opacity:0;transform:translateY(-150px) rotate(-7deg)}50%{opacity:1;transform:translateY(8px) rotate(3deg)}72%{transform:translateY(-3px) rotate(-1.4deg)}88%{transform:rotate(.5deg)}100%{transform:none}}
@keyframes pzwSway{0%,100%{transform:rotate(0)}25%{transform:rotate(.7deg)}75%{transform:rotate(-.7deg)}}
@keyframes pzwPan{from{opacity:0;transform:translateY(36px) scale(.965)}to{opacity:1;transform:none}}
@keyframes pzwPop{0%{opacity:0;transform:scale(.55)}60%{opacity:1;transform:scale(1.08)}100%{opacity:1;transform:none}}
@keyframes pzwPopOn{0%{opacity:0;transform:translateY(-3px) scale(.55)}60%{opacity:1;transform:translateY(-3px) scale(1.08)}100%{opacity:1;transform:translateY(-3px)}}
@keyframes pzwRise{0%{opacity:0;transform:translateY(24px) scale(.97)}70%{opacity:1;transform:translateY(-3px)}100%{opacity:1;transform:none}}
@keyframes pzwSlide{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:none}}
@keyframes pzwFromL{from{opacity:0;transform:translateX(-30px)}to{opacity:1;transform:none}}
@keyframes pzwUp{from{transform:translateY(64px)}to{transform:none}}
@keyframes pzwPeek{0%{transform:translateY(105%)}62%{transform:translateY(-7%)}82%{transform:translateY(2%)}100%{transform:none}}
@keyframes pzwBobL{0%,100%{transform:translateY(0) rotate(0) scale(1,1)}50%{transform:translateY(-6px) rotate(1.4deg) scale(1.006,1.018)}}
@keyframes pzwBobR{0%,100%{transform:translateY(0) rotate(0) scale(1,1)}50%{transform:translateY(-5px) rotate(-1.4deg) scale(1.006,1.018)}}
@keyframes pzwFlow{from{transform:translateX(0)}to{transform:translateX(16px)}}
@keyframes pzwGlint{0%{opacity:0;transform:translateX(-34px)}12%{opacity:1}62%{opacity:.25;transform:translateX(var(--L))}100%{opacity:0;transform:translateX(var(--L))}}
@keyframes pzwCueLoop{0%,12%{transform:translateX(-9px);animation-timing-function:cubic-bezier(.45,0,.55,1)}48%,55%{transform:translateX(-52px);animation-timing-function:cubic-bezier(.7,0,1,1)}59%{transform:translateX(0);animation-timing-function:linear}70%{transform:translateX(0);animation-timing-function:cubic-bezier(.2,0,.3,1)}100%{transform:translateX(-9px)}}
@keyframes pzwImp{0%,58%{opacity:0;transform:scale(.8)}60%{opacity:1;transform:scale(1)}78%,100%{opacity:0;transform:scale(1.9)}}
@keyframes pzwTab{0%{transform:translateY(-3px) scale(.88)}55%{transform:translateY(-4px) scale(1.07)}100%{transform:translateY(-3px) scale(1)}}
@keyframes pzwRing{0%{opacity:.95;transform:scale(.8)}100%{opacity:0;transform:scale(1.7)}}
@keyframes pzwX{0%{opacity:0;transform:scale(.2) rotate(-40deg)}60%{opacity:1;transform:scale(1.25) rotate(8deg)}100%{opacity:1;transform:none}}
@keyframes pzwNudge{0%,100%{transform:translateX(-3px)}50%{transform:translateX(6px)}}
@keyframes pzwAimSw{from{transform:rotate(-9deg)}to{transform:rotate(9deg)}}
@keyframes pzwMSw{from{transform:translateX(-9px)}to{transform:translateX(9px)}}
@keyframes pzwPull{0%,12%{transform:translateX(0);animation-timing-function:cubic-bezier(.45,0,.55,1)}48%,55%{transform:translateX(-40px);animation-timing-function:cubic-bezier(.7,0,1,1)}59%{transform:translateX(5px);animation-timing-function:ease-out}70%{transform:translateX(5px);animation-timing-function:ease-in-out}100%{transform:translateX(0)}}
@keyframes pzwDrag{0%,12%{transform:translateX(0);animation-timing-function:cubic-bezier(.45,0,.55,1)}48%,55%{transform:translateX(-16px);animation-timing-function:ease-out}66%,100%{transform:translateX(0)}}
@keyframes pzwFill{0%,12%{transform:scaleX(.1);animation-timing-function:cubic-bezier(.45,0,.55,1)}48%,57%{transform:scaleX(.84);animation-timing-function:ease-in}62%{transform:scaleX(.1)}100%{transform:scaleX(.1)}}
@keyframes pzwVFill{0%,12%{transform:scaleY(.12);animation-timing-function:cubic-bezier(.45,0,.55,1)}48%,57%{transform:scaleY(.86);animation-timing-function:ease-in}62%,100%{transform:scaleY(.12)}}
@keyframes pzwHit{0%,57%{opacity:0;transform:scale(.6)}60%{opacity:1;transform:scale(.8)}80%,100%{opacity:0;transform:scale(1.7)}}
@keyframes pzwDot{0%,27%{transform:translate(0,-27px);animation-timing-function:cubic-bezier(.3,1.5,.5,1)}33%,60%{transform:translate(0,27px);animation-timing-function:cubic-bezier(.3,1.5,.5,1)}66%,94%{transform:translate(27px,0);animation-timing-function:cubic-bezier(.3,1.5,.5,1)}100%{transform:translate(0,-27px)}}
@keyframes pzwHi{0%,30%{opacity:1}35%,95%{opacity:.42}100%{opacity:1}}
@keyframes pzwShine{0%,72%{transform:translateX(-140%) skewX(-20deg)}100%{transform:translateX(900%) skewX(-20deg)}}
@keyframes pzwSpark{0%,62%{opacity:0;scale:.4}72%{opacity:1;scale:1}88%,100%{opacity:0;scale:1.1}}
`;document.head.appendChild(st)}
