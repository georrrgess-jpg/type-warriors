/* ---------- Bestiary Mastery screen (Mastery tab of the Catalog) ---------- */
const mbSel={id:null,flt:'By zone'};
const MBFLT=['By zone','Closest to next','Mastered','Shiny','Not started','Unseen'];
const mbPn=i=>i.done?1:(i.pk+i.pf)/2;
const mbNextUp=()=>{const l=mbIds().map(mbInfo).filter(i=>i.seen&&!i.done).sort((a,b)=>mbPn(b)-mbPn(a));return l[0]?l[0].id:mbIds()[0]};
function mbCardMini(id){const i=mbInfo(id);return `<div class="mbcw">${mbGems(id,16)}${i.sh?`<span class="mbsb" title="Shiny caught">${mbStar(15)}</span>`:''}</div>`}
function mbTile(id){const i=mbInfo(id);return `<button class="mbtl${mbSel.id===id?' sel':''}${i.seen?'':' nsn'}${i.done?' done':''}" data-sel="${id}" style="--p:${Math.round(mbPn(i)*100)}%" aria-label="${i.seen?esc(MON[id].n):'Unknown monster'}" aria-pressed="${mbSel.id===id}"><span class="mbrg">${mbPort(id,64,64)}</span><b>${i.seen?esc(MON[id].n):'???'}</b>${mbGems(id,14)}${i.sh?`<span class="mbsb" title="Shiny caught">${mbStar(14)}</span>`:''}</button>`}
function mbBody(){if(!mbSel.id||!mbIds().includes(mbSel.id))mbSel.id=mbNextUp();const F=mbSel.flt;
 const chips=`<div class="mbtool"><div class="mbch2" role="tablist">${MBFLT.map(f=>`<button class="mbfl${f===F?' on':''}" data-flt="${f}">${f}</button>`).join('')}</div><div class="mblg"><span><i class="lr"></i>Progress to next tier</span><span>${mbGem(1,true,13)}Tiers earned</span><span>${mbStar(13)}Shiny caught</span></div></div>`;
 let left;
 if(F==='By zone')left=mbGroups().map(g=>`<h3 class="sec"${g.c?` style="color:${g.c}"`:''}>${g.n}<small>${g.ids.filter(k=>mbTierOf(k)>=3).length} / ${g.ids.length} mastered</small></h3><div class="mbtg">${g.ids.map(mbTile).join('')}</div>`).join('');
 else{let l=mbIds().map(mbInfo);l=l.filter(i=>F==='Closest to next'?i.seen&&!i.done&&i.k>0:F==='Mastered'?i.done:F==='Shiny'?i.sh>0:F==='Not started'?i.seen&&i.t===0&&i.k===0:!i.seen);if(F==='Closest to next')l.sort((a,b)=>mbPn(b)-mbPn(a));
  left=l.length?`<h3 class="sec">${F}<small>${l.length} monster${l.length===1?'':'s'}</small></h3><div class="mbtg">${l.map(i=>mbTile(i.id)).join('')}</div>`:`<p class="mbhint mbemp">${F==='Mastered'?'No monster is mastered yet. Reach 300 kills on one to master it.':F==='Shiny'?'No shiny monsters caught yet. About 1 in 64 monsters is a shiny.':F==='Unseen'?'You have met every monster.':'Nothing here right now.'}</p>`}
 return `${chips}<div class="mbsplit"><div class="mbleft">${left}</div><aside class="mbright" aria-live="polite">${mbDetail(mbSel.id)}</aside></div>`}
function mbAfter(back,again){const root=ov;mbWire(root,again);
 root.querySelectorAll('[data-mm]').forEach(c=>{c.onclick=()=>{mbSel.id=c.dataset.mm;catalog.tab='Mastery';catalog(back,'Mastery')};c.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();c.click()}}});
 root.querySelectorAll('[data-sel]').forEach(b=>b.onclick=()=>{const k=ov.querySelector('.bwrap'),y=k?k.scrollTop:0;mbSel.id=b.dataset.sel;again();const k2=ov.querySelector('.bwrap');if(k2)k2.scrollTop=y});
 root.querySelectorAll('[data-flt]').forEach(b=>b.onclick=()=>{mbSel.flt=b.dataset.flt;again()})}
