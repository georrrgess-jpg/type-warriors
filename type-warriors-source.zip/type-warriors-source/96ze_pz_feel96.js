/* ===== 9.6 THE CROOKED CUE: ball speed and a fairer guide (96ze) =====
   - No more automatic double speed at the end of a shot: balls used to speed up on screen just before they
     stopped. The crawl is now ended by the table instead (PZ_PHY.MURL/VL in 96b: a little extra rolling drag
     below VL px/s), so a shot slows down smoothly and settles. Holding Space or the mouse still fast-forwards.
   - The guide no longer plays the shot for you. Full: the aim line, the ghost ball, where the ball you hit heads
     up to the first ball or cushion (at most 230 px), and the first stretch of the cue ball's path (bent by
     follow/draw). No simulated trails, no "it drops" rings or scratch crosses. Short: the first 80 / 36 px.
     Pro: the aim line only. */
function pzFF(){const ph=PZ.ph;if(PZ.slow&&PZ.slow.on)return 1;
 if(PZ.ffHeld&&(ph==='roll'||ph==='settle'||ph==='gap'||ph==='ai'||ph==='endhold'||ph==='rerack'||ph==='stroke'))return 3;return 1}
const PZ_GUIDE={full:{obj:230,tan:80,reb:90},short:{obj:80,tan:36,reb:45}};
function pzDrawGuide(g,B,ang,mode,t,spinB){const cue=B[0],R=PZ_PHY.R,G=PZ_G,dx=Math.cos(ang),dy=Math.sin(ang),h=pzRay(B,cue.x,cue.y,dx,dy,0),out={hit:h,pocket:-1};if(!h)return out;
 const K=PZ_GUIDE[mode]||null;
 g.save();g.translate(G.x,G.y);g.lineCap='round';
 const dash=(x0,y0,x1,y1,col,lw,gap)=>{g.strokeStyle=col;g.lineWidth=lw;g.setLineDash(gap?[9,9]:[]);g.lineDashOffset=-(t*26%18);g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.stroke();g.setLineDash([])};
 /* the aim line from the cue ball to the ghost ball (or the cushion) */
 const sx=cue.x+dx*(R+3),sy=cue.y+dy*(R+3);dash(sx,sy,h.gx,h.gy,'rgba(0,0,0,.3)',3.6,true);dash(sx,sy,h.gx,h.gy,PZ.aimCol||'rgba(255,255,255,.82)',PZ.aimCol?2.6:2,true);
 if(h.type==='ball'){const ob=h.b;
  g.strokeStyle='rgba(255,255,255,.9)';g.lineWidth=2;g.beginPath();g.arc(h.gx,h.gy,R,0,TAU);g.stroke();g.fillStyle='rgba(255,255,255,.1)';g.beginPath();g.arc(h.gx,h.gy,R,0,TAU);g.fill();
  const ux=ob.x-h.gx,uy=ob.y-h.gy,ul=Math.hypot(ux,uy)||1,ox=ux/ul,oy=uy/ul;
  out.pocket=pzPocketToward(ob.x,ob.y,ox,oy);
  if(K){/* the object ball's heading, stopped at the first thing it would meet; it fades toward the end */
   const r2=pzRay(B,ob.x,ob.y,ox,oy,ob.id);let L1=K.obj;if(r2&&r2.t<L1)L1=r2.t;
   const x0=ob.x+ox*R,y0=ob.y+oy*R,ex=ob.x+ox*L1,ey=ob.y+oy*L1;
   if(L1>R){const q=g.createLinearGradient(x0,y0,ex,ey);q.addColorStop(0,'rgba(255,212,90,.95)');q.addColorStop(.7,'rgba(255,212,90,.8)');q.addColorStop(1,'rgba(255,212,90,.25)');
    g.strokeStyle='rgba(0,0,0,.28)';g.lineWidth=4.4;g.beginPath();g.moveTo(x0,y0);g.lineTo(ex,ey);g.stroke();g.strokeStyle=q;g.lineWidth=2.6;g.beginPath();g.moveTo(x0,y0);g.lineTo(ex,ey);g.stroke()}
   /* the cue ball after contact: the tangent line, bent forward (follow) or back (draw) by the spin */
   const tx=-oy,ty=ox,side=(dx*tx+dy*ty)>=0?1:-1,cut=Math.abs(dx*ox+dy*oy);let ax=tx*side,ay=ty*side;const bend=(spinB||0)*.55*cut;ax=ax*(1-Math.abs(bend)*.4)+dx*bend;ay=ay*(1-Math.abs(bend)*.4)+dy*bend;const al=Math.hypot(ax,ay)||1;ax/=al;ay/=al;
   const ln=Math.max(14,K.tan*(1-cut*.85));dash(h.gx+ax*R,h.gy+ay*R,h.gx+ax*(R+ln),h.gy+ay*(R+ln),'rgba(159,232,255,.85)',2.2,true)}}
 else{/* a cushion first: show the start of the rebound */
  g.fillStyle='rgba(255,255,255,.85)';g.beginPath();g.arc(h.gx,h.gy,3,0,TAU);g.fill();
  if(K){const dd=dx*h.nx+dy*h.ny,rx=dx-2*dd*h.nx,ry=dy-2*dd*h.ny;dash(h.gx,h.gy,h.gx+rx*K.reb,h.gy+ry*K.reb,'rgba(255,255,255,.42)',2,true)}}
 g.restore();return out}
