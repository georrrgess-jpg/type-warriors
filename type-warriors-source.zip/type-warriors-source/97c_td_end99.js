/* ===== RUNESTONE TOWER DEFENSE 9.9h: healers that can be out-damaged, and an endless Wonderland that stays beatable past wave 60 (97c, after 97b) =====
   Hex Shamans (95e) pulsed 8% of max health into every hurt monster in reach every 2.4 s. Three faults made late waves unwinnable:
   - pulses stacked: a monster between three shamans got 24% back per pulse;
   - shamans healed each other, so a pack of them could out-heal a full board;
   - the heal is a share of max health, so it kept pace with the endless health curve while towers stop growing at tier 5.
   Now (RPHL): a monster takes at most one heal per pulse window, however many shamans reach it; shamans do not heal shamans; bosses
   take half; and in the endless Wonderland the pulse fades from 8% (wave RPHL.w1) to RPHL.k2 (wave RPHL.w2 and later).
   The pulse itself is moved out of rpStep: spawned healers keep their timer in e.hlT (e.heal = 0 switches the old pulse off). */
const RPHL={once:2.3,boss:.5,w1:30,w2:60,k2:.045};
function rpHealK(R){const k=RP_FOE.shaman.heal;if(!R.map.endless||R.wave<=RPHL.w1)return k;const v=Math.min(1,(R.wave-RPHL.w1)/(RPHL.w2-RPHL.w1));return k+(RPHL.k2-k)*v}
{const s0=rpSpawn;rpSpawn=function(id){const e=s0.apply(this,arguments);if(e&&e.heal>0){e.hlT=e.heal;e.heal=0}return e}}
{const t0=rpStep;rpStep=function(R,dt){t0.apply(this,arguments);if(!R.foes)return;let K=-1;
  for(const e of R.foes){if(e.dead||!(e.hlT>0))continue;e.hlT-=dt;if(e.hlT>0)continue;const F=RP_FOE[e.id];e.hlT=F.healT;if(K<0)K=rpHealK(R);
   const p=rpPos(R,e);let n=0;for(const f of R.foes){if(f.dead||f===e||f.hp>=f.mx||f.s<0||RP_FOE[f.id].heal||(f.hlAt!=null&&R.time-f.hlAt<RPHL.once))continue;
    const q=rpPos(R,f);if((q.x-p.x)**2+(q.y-p.y)**2<F.healR*F.healR){f.hp=Math.min(f.mx,f.hp+f.mx*K*(f.boss?RPHL.boss:1));f.hlAt=R.time;n++}}
   if(n)R.rings.push({x:p.x,y:p.y,t:0,d:.6,max:F.healR,c:'#b47aff',w:3,heal:1})}}}
/* The endless curve past wave 50. A full board of tier-5 towers held every ordinary wave up to 105 once the healers were fixed, but
   boss waves were a wall: 3 Behemoths at wave 60, 4 at wave 90, each with hit points still compounding. Now, in the Wonderland only:
   - after wave RPE.w2 (50) the extra climb on ordinary hit points drops from 1.4% to 1% a wave (RPE.soft 1.014 -> 1.01);
   - boss hit points after wave 50 compound at 0.6% a wave instead of 1.2% (RPHL.bsoft);
   - at most RPHL.bossN Behemoths per boss wave, a little further apart (gap 6 -> RPHL.bossGap s). */
RPE.soft=1.01;Object.assign(RPHL,{bossN:2,bossGap:8,bsoft:1.006});
{const h0=rpHpK;rpHpK=function(map,w,boss){const k=h0.apply(this,arguments);return map&&map.endless&&boss&&w>RPE.w2?k*Math.pow(RPHL.bsoft/RPE.boss,w-RPE.w2):k}}
{const w0=rpWave;rpWave=function(map,w){const W=w0.apply(this,arguments);if(!map||!map.endless)return W;
  return W.map(g=>g.id==='behemoth'&&g.n>RPHL.bossN?Object.assign({},g,{n:RPHL.bossN,gap:RPHL.bossGap}):g)}}
/* Bot results (t_ramparts bot, each tower to tier 5 in turn, waves reached): Dragon+Dragon+Frost 71 -> 100, Dragon+Dragon+Tide 70 -> 82,
   Dragon+Still+Frost 50 -> 94, Prism+Dragon+Frost 94. Healer fix alone: 90 / 76 / 80. No extra climb at all after 50 let the bots sit at
   full health past wave 115, so some climb stays. A board of 14 tier-5 towers holds every ordinary wave to 105 and the wave-80 bosses. */
