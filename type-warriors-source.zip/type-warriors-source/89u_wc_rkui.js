/* ===== WILDCARD RANKED: screens and emotes =====
   rkHub()             the Ranked hub: insignia, bar, this rank's points, next reward, recent matches, Find ranked match
   rkResults(res,rank) the match result: places with cards and card points, the bar filling, then the rank-up ceremony
   rkUp(up,done)       the rank-up ceremony: new insignia, sleeve, emote and coins
   rkRoad()            the rank-up rewards road (all six ranks and what each pays)
   Emotes (every Wildcard table): an Emote button opens the picker (8 free emotes plus the 5 ranked ones, locked ones show
   the rank that unlocks them). One emote every 3 seconds; tap a player's name to mute them. Right after a matching moment
   (for example your Turnabout), that emote glows on the button for 4 seconds so one tap sends it. */
const WCRFREE=['Haha!','Nooo','So close','Well played','Sneaky','GG','Nice!','Oops'];
const rkDays=s=>Math.max(0,Math.ceil((rkSeasonEnd(s)-Date.now())/864e5));
function rkBarHTML(R,cls){return R.r===5?`<div class="rkbar leg ${cls||''}"><i style="--w:100%"></i></div>`:`<div class="rkbar ${cls||''}"><i style="--w:${R.bar}%"></i></div>`}
const rkNextTxt=R=>R.r===5?`${cmn(R.lp)} Legend points this season`:`${100-R.bar} more to ${WCRN[R.r+1].n}`;
function rkHead(title,backTxt){const R=rkSt(),s=R.season;return `<header class="wclh rkh"><button class="wcpb back" id="rkback">${WCI.back}<span>${backTxt||'Wildcard'}</span></button><h1>${title}</h1>
 <span class="wcpb rkseason">${WCI2.flame}<span>Season ${s} · ${rkDays(s)} day${rkDays(s)===1?'':'s'} left</span></span><span class="wcpb gold"><span class="coin"></span><b>${cmn(P.gold)}</b></span></header>`}
/* ---------- the hub ---------- */
function rkHub(){WX.tok++;wcClear();try{wcScanStop()}catch(e){}CAS.on=true;rkDodge();const R=rkSt(),T=WCRN[R.r],nx=WCRN[Math.min(5,R.r+1)],W=wcSt();
 const rows=T.pts.map((d,i)=>`<div class="rkpt p${i}"><span class="wcpl p${i}">${WCPL[i]}</span><b class="${d>0?'up':d<0?'dn':''}">${d>0?'+':d<0?'−':''}${Math.abs(d)}</b></div>`).join('');
 const hist=R.hist.slice(-5).reverse();
 const next=R.r<5?`<h4>Next reward · ${nx.n}</h4><div class="rknext"><div class="rknc">${wcBack(nx.back)}</div><div class="rkne">${rkEmo(nx.emo,wcMyAv(),'sm2')}</div><div class="rknt"><b><span class="coin"></span>${cmn(nx.coins)}</b><small>${esc(WCBK[nx.back].n)} sleeve</small><small>“${WCREMO[nx.emo].n}” emote</small>${nx.title?'<small>+ the Legend title</small>':''}</div></div>`
  :`<h4>Legend standings · Season ${R.season}</h4>${rkStandings()}`;
 show(`<div class="rkx rkhub" id="rkhub"><div class="wclbg"><i class="wcspot a"></i><i class="wcspot b"></i></div>${rkHead('Ranked')}
 <section class="rkp rkcrest" style="--rc:${T.c}"><div class="rkglow"></div>${rkInsig(R.r,300,{anim:1})}<h2 style="color:${T.c}">${T.n}</h2>
  ${R.r===5?`<div class="rknum"><b>${cmn(R.lp)}</b><small>Legend points</small></div>`:`<div class="rknum"><b>${R.bar}</b><small>/ 100</small></div>`}${rkBarHTML(R)}<p class="rknx">${rkNextTxt(R)}</p>
  <button class="wcbtn gold big" id="rkfind">${WCI2.cards}Find ranked match</button><p class="rksm">4 players · usual rules · 15-second turns · no buy-in, points are the prize</p></section>
 <section class="rkp rkmid"><h4>Points at ${T.n}</h4><div class="rkpts">${rows}</div>
  <ul class="rkul"><li>The bar never drops below 0 and you never lose a rank during a season.</li><li>Fill the bar to rank up. Every rank up pays a sleeve, an emote and coins.</li><li>Leaving a match, or three timeouts in a row, places you 4th.</li><li>Seasons last 6 weeks. A new season moves you down 2 ranks.</li></ul>
  <h4>Your opponents</h4><p class="rkai"><b>${T.n} AI:</b> ${T.ai} Real players at your rank are matched first; empty seats are filled by AI.</p>
  <div class="rkrow"><button class="wcbtn" id="rkroad">${WCI.book}Rank rewards</button><button class="wcbtn" id="rksleeve">${WCI2.cards}Sleeves</button><button class="wcbtn" id="rkhow">How it works</button></div></section>
 <section class="rkp rkside">${next}<h4 class="rkhh">Recent ranked matches</h4>${hist.length?hist.map(h=>`<div class="rkhr"><span class="wcpl p${h.p}">${WCPL[h.p]}</span><span>${h.why==='left'?'Left the match':h.why==='afk'?'Timed out':WCRN[h.r].n}</span><b class="${h.d>0?'up':h.d<0?'dn':''}">${h.d>0?'+':h.d<0?'−':''}${Math.abs(h.d)}</b></div>`).join(''):'<p class="rkempty">Your ranked matches will show here.</p>'}
  <p class="rkrec">${R.n} ranked match${R.n===1?'':'es'} · ${R.w} won · best ${WCRN[R.peak].n}</p></section>
 <div class="wcmod" id="wcmod" hidden></div></div>`,'casbg wcx');
 rkEmoPaint(ov);S.back=()=>{wcFx('back');wcHome()};$('rkback').onclick=S.back;
 $('rkfind').onclick=()=>{wcFx('click');typeof rkFind==='function'?rkFind():rkStart()};$('rkroad').onclick=()=>{wcFx('click');rkRoad()};$('rksleeve').onclick=()=>{wcFx('click');WX.vtab='rk';wcVault(WCBK[W.back]&&WCBK[W.back].rk!=null?W.back:'rkcopper')};$('rkhow').onclick=rkHow;
 if(R.note){const n=R.note;R.note='';save();setTimeout(()=>wcModal(`<h3>Ranked</h3><p class="wcp">${esc(n)}</p>`),350)}wcFx('vault')}
function rkStandings(){const R=rkSt(),me={n:P.name||'You',lp:R.lp,me:1},L=[me,...Object.entries(R.met||{}).filter(([k,v])=>v&&v.s===R.season).map(([k,v])=>({n:k,lp:v.lp}))].sort((a,b)=>b.lp-a.lp).slice(0,8);
 return `<div class="rkstd">${L.map((x,i)=>`<div class="${x.me?'me':''}"><span>${i+1}</span><b>${esc(x.n)}</b><em>${cmn(x.lp)}</em></div>`).join('')}</div><p class="rkempty">Legend players you meet in ranked matches join this list.</p>`}
function rkHow(){wcModal(`<h3>How Ranked works</h3><div class="rkhow">
 <p><b>1 · Find a match.</b> Wildcard looks for players at your rank for 8 seconds, then one rank either side, up to 15 seconds. Empty seats are filled by AI players at your rank, marked AI.</p>
 <p><b>2 · Play.</b> The usual rules, with +2 stacking. Each turn has 15 seconds; running out draws a card for you. Three timeouts in a row hand your seat to an AI.</p>
 <p><b>3 · Placing.</b> The game ends as soon as someone empties their hand. Everyone else is placed by fewest cards left, then fewest card points (numbers count their value, actions 20, wilds 50), then whoever played last.</p>
 <p><b>4 · Points.</b> Your place moves your 100-point bar. Fill it to rank up. Legend has no bar: Legend points keep counting.</p>
 <p><b>5 · Rewards.</b> Every rank up gives a sleeve, a moment emote and coins. Sleeves and emotes are yours forever; coins are paid again each season you reach the rank.</p></div>`,'wide')}
/* ---------- match result ---------- */
function rkHandWords(h){const nm=c=>c.s==='w'?(c.v==='d4'?'a +4 Hex':'a Wild Rune'):wcIsNum(c)?(c.v==='8'?'an 8':'a '+c.v):c.v==='stun'?'a Stun':c.v==='turn'?'a Turnabout':'a +2 Curse';const a=h.map(nm);
 return a.length<=1?(a[0]||''):a.slice(0,-1).join(', ')+' and '+a[a.length-1]}
function rkResults(res,rank,o){o=o||{};const G=WX.G,R=rkSt(),me=WX.me,place=res.place,T0=WCRN[res.from.r];WX.rkLast=res;
 const won=place===0,wi=rank?rank[0]:-1,wname=G&&wi>=0?(wi===me?'You':G.P[wi].name):'';
 const rowsH=rank?rank.map((i,k)=>{const p=G.P[i],pts=p.hand.reduce((a,c)=>a+wcPts(c),0),d=T0.pts[k];return `<div class="rkrr${i===me?' me':''}" style="--d:${k}"><span class="rkpl p${k}">${WCPL[k]}</span><canvas width="96" height="96" data-por="${i}"></canvas>
  <span class="rkrn"><b>${esc(p.name)}${i===me?' (you)':''}${p.ai&&!(p.av&&p.av.rare)?' <i class="rkai2">AI</i>':''}${p.title==='Legend'?' <i class="rkleg2">★ Legend</i>':''}</b><small>${p.hand.length?`${p.hand.length} card${p.hand.length>1?'s':''} left · ${pts} card point${pts===1?'':'s'}`:'Emptied their hand'}</small></span><em class="${d>0?'up':d<0?'dn':''}">${d>0?'+':d<0?'−':''}${Math.abs(d)}</em></div>`}).join('')
  :`<div class="rkrr me"><span class="rkpl p3">4th</span><span class="rkrn"><b>${esc(P.name||'You')} (you)</b><small>${o.afk?'Three turns timed out, so an AI took your seat.':'You left the match.'}</small></span><em class="${res.d<0?'dn':''}">${res.d<0?'−':''}${Math.abs(res.d)}</em></div>`;
 const mine=G&&G.P[me]?G.P[me].hand:[];let handBox='';
 if(rank&&!won&&mine.length){const pts=mine.reduce((a,c)=>a+wcPts(c),0);handBox=`<section class="rkp rkhand"><h4>Your hand when ${esc(wname)} went out</h4><p>${esc(rkHandWords(mine.slice(0,6)))}${mine.length>6?' and more':''}: ${pts} card point${pts===1?'':'s'}.${mine.length<=2?` ${mine.length===1?'One more turn':'Two more turns'} and you would have gone out first.`:''}</p><div class="rkhc">${mine.slice(0,6).map((c,k)=>`<div class="rkhcc" style="--k:${k-(Math.min(6,mine.length)-1)/2}">${wcCardEl(c,'')}</div>`).join('')}</div></section>`}
 else if(rank&&won){const c=G.disc[G.disc.length-1];handBox=`<section class="rkp rkhand"><h4>Your winning card</h4><p>You emptied your hand in ${G.turns} turns. ${res.d>0?`+${res.d} points.`:''}</p><div class="rkhc"><div class="rkhcc" style="--k:0">${wcCardEl(c,'')}</div></div></section>`}
 const title=won?'You win!':`${WCPL[place]} place`,sub=!rank?(o.afk?'Your seat went to an AI after three timeouts.':'Leaving a ranked match places you 4th.'):won?'You emptied your hand first. Everyone else is placed by cards left.':`${esc(wname)} went out first. Everyone else is placed by cards left.`;
 show(`<div class="rkx rkres${won?' won':''}" id="rkres"><div class="wclbg"><i class="wcspot a"></i><i class="wcspot b"></i></div><div class="rktag"><span>RANKED</span>${esc(T0.n.toUpperCase())} · MATCH RESULT</div>
 <h1 class="rkt">${title}</h1><p class="rksub">${sub}</p>
 <section class="rklist">${rowsH}</section>
 ${rank?`<section class="rkp rktie"><h4>Tie-breaks</h4><p>Fewest cards left places higher. Same number of cards: lower card points wins (numbers count their value, action cards 20, wilds 50), then whoever played last. Leaving a match places you 4th and an AI finishes your seat.</p></section>`:''}${handBox}
 <section class="rkp rkcard" id="rkcard" style="--rc:${T0.c}"><div class="rkglow"></div><div id="rkins">${rkInsig(res.from.r,250,{anim:1})}</div><h2 id="rkrn" style="color:${T0.c}">${T0.n}</h2>
  <div class="rknum big"><b id="rkn">${res.from.r===5?cmn(res.from.lp):res.from.bar}</b><small id="rkof">${res.from.r===5?'Legend points':'/ 100'}</small><em class="${res.d>0?'up':res.d<0?'dn':'zero'}">${res.d>0?'+':res.d<0?'−':'±'}${Math.abs(res.d)}</em></div>
  <div class="rkbar big" id="rkbar"><i style="--w:${res.from.r===5?100:res.from.bar}%"></i><u></u></div><p class="rknx" id="rknx">${res.from.r===5?'Legend points set your place on the Legend standings':rkNextTxt({r:res.from.r,bar:res.from.bar})}</p>
  ${res.first?`<button class="rkfirst" id="rkfirst">${wcBack('rkcopper')}<span><b>New sleeve: Forged Copper</b><small>For playing your first ranked match · tap to equip</small></span></button>`:''}</section>
 <div class="rkbtns"><button class="wcbtn gold big" id="rkagain">Play again</button><button class="wcbtn big" id="rkhubb">Back to Ranked</button></div><div class="wcmod" id="wcmod" hidden></div></div>`,'casbg wcx');
 ov.querySelectorAll('canvas[data-por]').forEach(c=>{const av=G.P[+c.dataset.por].av;if(av&&av.t==='crew')wcLive(c,av,'por');else wcPortrait(c,av)});
 S.back=()=>rkHub();$('rkhubb').onclick=()=>{wcFx('click');rkHub()};$('rkagain').onclick=()=>{wcFx('click');typeof rkFind==='function'?rkFind():rkStart()};
 if($('rkfirst'))$('rkfirst').onclick=()=>{const W=wcSt();W.back='rkcopper';W.seen.rkcopper=1;save();wcFx('equip');$('rkfirst').classList.add('done');$('rkfirst').querySelector('small').textContent='Equipped on your cards'};
 wcFx(won?'win':res.d<0?'lose':'chip');
 /* the bar moves from where it was to where it is now; a rank up fills it to 100 first */
 const bar=$('rkbar'),fill=bar.querySelector('i'),seg=bar.querySelector('u'),n=$('rkn'),from=res.from,d=res.d;
 const count=(a,b,ms)=>{const t0=performance.now();const f=t=>{const k=Math.min(1,(t-t0)/ms);if(!n.isConnected)return;n.textContent=cmn(Math.round(a+(b-a)*(1-Math.pow(1-k,3))));if(k<1)requestAnimationFrame(f)};requestAnimationFrame(f)};
 setTimeout(()=>{if(!bar.isConnected)return;if(from.r===5){count(from.lp,res.to.lp,900);return}
  const to=res.up?100:res.to.bar;if(d>0){seg.style.left=from.bar+'%';seg.style.setProperty('--w',(to-from.bar)+'%');seg.className='g'}else if(d<0&&from.bar>0){seg.style.left=to+'%';seg.style.setProperty('--w',(from.bar-to)+'%');seg.className='r';fill.style.setProperty('--w',to+'%')}
  count(from.bar,to,900);if(res.up)setTimeout(()=>{if(bar.isConnected)rkUp(res.up,()=>rkResAfterUp(res))},1300)},650)}
function rkResAfterUp(res){const T=WCRN[res.to.r],c=$('rkcard');if(!c)return;c.style.setProperty('--rc',T.c);$('rkins').innerHTML=rkInsig(res.to.r,250,{anim:1});const h=$('rkrn');h.textContent=T.n;h.style.color=T.c;
 $('rkn').textContent=res.to.r===5?cmn(res.to.lp):'0';$('rkof').textContent=res.to.r===5?'Legend points':'/ 100';const b=$('rkbar');b.querySelector('i').style.setProperty('--w',res.to.r===5?'100%':'0%');b.querySelector('u').className='';
 $('rknx').textContent=rkNextTxt(rkSt())}
/* ---------- rank-up ceremony ---------- */
function rkUp(up,done){const host=$('rkres')||$('rkhub')||document.querySelector('.rkx');if(!host){done&&done();return}const T=WCRN[up.r],E=WCREMO[up.emo];
 const d=document.createElement('div');d.className='rkup rkbig';d.style.setProperty('--rc',T.c);
 d.innerHTML=`<div class="rkupbg"></div><svg class="rkuprays" viewBox="-100 -100 200 200">${Array.from({length:16},(_,i)=>`<path d="M0 0L${(140*Math.cos(i*Math.PI/8)).toFixed(1)} ${(140*Math.sin(i*Math.PI/8)).toFixed(1)}L${(140*Math.cos(i*Math.PI/8+.13)).toFixed(1)} ${(140*Math.sin(i*Math.PI/8+.13)).toFixed(1)}Z" fill="${T.c}" opacity=".12"/>`).join('')}</svg>
 <div class="rkupin">${rkInsig(up.r,330,{label:1,anim:1})}</div><h2>You reached <span style="color:${T.c}">${T.n}</span>!</h2><p class="rkups">Season ${rkSt().season} · ${up.r===5?'Legend points now set your place on the Legend standings':'your bar starts again at 0'}</p>
 <div class="rkupr"><div class="rkupt" style="--d:0"><div class="rkupc">${wcBack(up.back)}</div><b>${esc(WCBK[up.back].n)} sleeve</b><small>${up.newBack?'New! Yours forever':'Already in your vault'}</small><button class="rkeq" id="rkequip">Use this sleeve</button></div>
  ${E?`<div class="rkupt" style="--d:1">${rkEmo(up.emo,wcMyAv())}<b>“${E.n}” emote</b><small>Glows right after ${E.when}</small></div>`:''}
  <div class="rkupt" style="--d:2"><div class="rkupcoin"><span class="coin"></span><b id="rkupn">0</b></div><b>Coin bonus</b><small>${up.coins?'Added to your gold':'Already paid this season'}</small>${up.title?'<small class="rkupleg">+ the “Legend” title</small>':''}</div></div>
 <button class="wcbtn gold big rkupgo" id="rkupgo">Continue</button>`;
 host.appendChild(d);rkEmoPaint(d);wcFx('rare');setTimeout(()=>wcFx('win'),500);
 const nEl=d.querySelector('#rkupn'),goal=up.coins||WCRN[up.r].coins;setTimeout(()=>{const t0=performance.now();const f=t=>{const k=Math.min(1,(t-t0)/1100);if(!nEl.isConnected)return;nEl.textContent='+'+cmn(Math.round(goal*(1-Math.pow(1-k,3))));if(k<1)requestAnimationFrame(f)};requestAnimationFrame(f);if(up.coins)wcFx('chip')},1500);
 d.querySelector('#rkequip').onclick=e=>{const W=wcSt();W.back=up.back;W.seen[up.back]=1;save();wcFx('equip');e.target.textContent='✓ In use';e.target.disabled=true};
 const close=()=>{d.classList.add('out');setTimeout(()=>d.remove(),300);S.back=()=>rkHub();done&&done()};d.querySelector('#rkupgo').onclick=close;S.back=close;setTimeout(()=>{const b=d.querySelector('#rkupgo');if(b)b.focus()},200)}
/* ---------- the rank-up rewards road ---------- */
function rkRoad(){WX.tok++;wcClear();const R=rkSt(),W=wcSt();
 const pos=R.r===5?100:(R.r+R.bar/100)/5*100;
 const top=WCRN.map((T,i)=>`<div class="rkrdi${i<=R.r?' got':''}${i===R.r?' cur':''}" style="--rc:${T.c};--d:${i}">${i===R.r?`<span class="rkyou">You · ${R.r===5?cmn(R.lp)+' LP':R.bar+' / 100'}</span>`:''}${rkInsig(i,i===5?150:128,{anim:i===5||i===R.r})}<b style="color:${T.c}">${T.n}</b></div>`).join('');
 const cards=WCRN.map((T,i)=>{const st=i===0?'start':i<=R.peak?'got':i===R.r+1?'next':'lock';const lab=i===0?'':st==='got'?'✓ CLAIMED':st==='next'?'NEXT REWARD':'LOCKED';
  return `<div class="rkrc ${st}" style="--rc:${T.c};--d:${i}">${lab?`<em>${lab}</em>`:''}${i===0?`<p class="rkst"><b>Everyone starts here.</b>Bronze can't lose points, so your first games always move you forward.</p>`:''}
  <div class="rkrcb">${wcBack(T.back)}</div><b>${esc(WCBK[T.back].n)} sleeve</b>${i===0?`<small class="rkok">${W.backs.rkcopper?'✓ ':''}after your first ranked match</small>`:`${rkEmo(T.emo,wcMyAv(),'sm'+(st==='got'||R.em[T.emo]?'':' lock'))}<small>“${WCREMO[T.emo].n}” emote</small><div class="rkrcoin"><span class="coin"></span>${cmn(T.coins)}</div>${T.title?'<small class="rkupleg">+ “Legend” title</small>':''}`}</div>`}).join('');
 const tot=WCRN.reduce((a,T)=>a+T.coins,0);
 show(`<div class="rkx rkroad rkbig" id="rkroad"><div class="wclbg"><i class="wcspot a"></i><i class="wcspot b"></i></div>${rkHead('Rank-up Rewards','Ranked')}
 <p class="rkroadsub">Every rank up pays out three things: an exclusive sleeve, a moment emote and a big coin bonus.</p>
 <div class="rkline"><i style="--w:${pos}%"></i></div><div class="rkrdtop">${top}</div><div class="rkrdc">${cards}</div>
 <p class="rkfoot">Sleeves and emotes are yours forever. Coins are paid again every season you reach the rank. Total for reaching Legend: <span class="coin"></span><b>${cmn(tot)} coins</b>, 6 sleeves, 5 emotes.</p><div class="wcmod" id="wcmod" hidden></div></div>`,'casbg wcx');
 rkEmoPaint(ov);S.back=()=>{wcFx('back');rkHub()};$('rkback').onclick=S.back;wcFx('vault')}

/* ---------- the way in: a crest on the Wildcard home screen ---------- */
{const h0=wcHome;wcHome=function(){const r=h0.apply(this,arguments);try{const R=rkSt(),T=WCRN[R.r],h=$('wch');if(h&&!$('rkhome')){const b=document.createElement('button');b.className='rkhome';b.id='rkhome';b.style.setProperty('--rc',T.c);
 b.setAttribute('aria-label','Play Ranked: '+T.n+(R.r===5?'':', '+R.bar+' of 100 points'));
 b.innerHTML=`<span class="rkhi">${rkInsig(R.r,78,{anim:R.r===5})}</span><span class="rkht"><em>PLAY RANKED</em><b style="color:${T.c}">${T.n}</b><small>${R.r===5?cmn(R.lp)+' LP':R.bar+' / 100'}</small>${rkBarHTML(R,'sm')}</span><span class="rktro" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M7 3h10v3h3.5v2.2c0 2.6-1.9 4.4-4.4 4.7-.7 1.7-2 2.9-3.6 3.3V19h3.2v2H8.3v-2h3.2v-2.8c-1.6-.4-2.9-1.6-3.6-3.3C5.4 12.6 3.5 10.8 3.5 8.2V6H7zm0 5H5.5v.2c0 1.3.7 2.3 1.8 2.7C7.1 10 7 9 7 8zm10 0c0 1-.1 2-.3 2.9 1.1-.4 1.8-1.4 1.8-2.7V8z" fill="currentColor"/></svg></span><i class="rkgo" aria-hidden="true">›</i>`;
 b.onclick=()=>{wcFx('click');rkHub()};b.onmouseenter=()=>wcFx('hover');h.appendChild(b)}}catch(e){}return r}}
/* the vault gets two shelves: Lounge backs and Ranked sleeves */
{const v0=wcVault;wcVault=function(sel){const r=v0.apply(this,arguments);try{const g=ov.querySelector('.wcvgrid'),hd=ov.querySelector('#wcvault .wclh');if(!g||!hd)return r;
 const S2=sel&&WCBK[sel]?sel:wcSt().back;let tab=WX.vtab||(WCBK[S2]&&WCBK[S2].rk!=null?'rk':'lo');WX.vtab=null;
 const t=document.createElement('div');t.className='rkvt';const W=wcSt(),cnt=f=>WCBKK.filter(k=>f(k)&&W.backs[k]).length+' / '+WCBKK.filter(f).length;
 const isR=k=>WCBK[k].rk!=null;t.innerHTML=`<button data-t="lo">Lounge <small>${cnt(k=>!isR(k))}</small></button><button data-t="rk">Ranked sleeves <small>${cnt(isR)}</small></button>`;hd.querySelector('h1').after(t);
 const apply=()=>{t.querySelectorAll('button').forEach(b=>b.classList.toggle('on',b.dataset.t===tab));g.querySelectorAll('[data-vk]').forEach(b=>{b.hidden=isR(b.dataset.vk)!==(tab==='rk')});g.classList.toggle('rkg',tab==='rk')};
 t.querySelectorAll('button').forEach(b=>b.onclick=()=>{tab=b.dataset.t;wcFx('click');apply();const first=g.querySelector('[data-vk]:not([hidden])');if(first)first.click()});apply();
 g.querySelectorAll('[data-vk]').forEach(b=>{const B=WCBK[b.dataset.vk];if(B.rk!=null){const h=b.querySelector('.wcvh');if(h)h.textContent=B.rk?'Reach '+WCRN[B.rk].n:'First match'}})}catch(e){}return r}}
/* leaving a ranked table goes back to the hub; the menu says what leaving costs */
{const x0=wcExit;wcExit=function(){if(!WX.rk)return x0.apply(this,arguments);const res=WX.rkLeft;WX.tok++;wcClear();try{wcNetClose()}catch(e){}WX.G=null;const was=WX.rk;WX.rk=null;WX.rkLeft=null;rkHub()}}
{const m0=wcMenu;wcMenu=function(){const r=m0.apply(this,arguments);try{if(WX.rk){const m=$('wcmod'),R=rkSt();const s=m&&m.querySelector('.wcmnb small');if(s)s.textContent='Ranked · '+WCRN[R.r].n+' · 15-second turns';
 const p=m&&m.querySelector('.wcmnb > p');if(p&&WX.G&&WX.G.phase!=='over'){const d=rkPts(3,R.r);p.innerHTML=`Leaving now places you <b>4th</b> (${d<0?'−'+Math.abs(d):'±0'} points) and an AI finishes your seat.`}}}catch(e){}return r}}

/* ---------- emotes ---------- */
const rkOwn=k=>!!rkSt().em[k];
{const t0=wcTable;wcTable=function(){const r=t0.apply(this,arguments);try{const t=$('wct'),em=$('wcemo');if(em)em.remove();const tools=t.querySelector('.wctools');
 if(tools&&!$('rkemob')){const b=document.createElement('button');b.className='wctb rkemob';b.id='rkemob';b.innerHTML='<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9.5" fill="none" stroke="currentColor" stroke-width="2.2"/><circle cx="8.6" cy="10" r="1.5" fill="currentColor"/><circle cx="15.4" cy="10" r="1.5" fill="currentColor"/><path d="M7.5 14.2q4.5 4.6 9 0" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg><span>Emote</span>';
  tools.prepend(b);b.onclick=()=>{if(WX.rkMom&&Date.now()<WX.rkMom.until){const k=WX.rkMom.k;rkMomEnd();rkSend('@'+k);return}rkPick()}}}catch(e){}return r}}
function rkPick(){const t=$('wct');if(!t)return;let p=$('rkpick');if(p){p.remove();return}const R=rkSt();p=document.createElement('div');p.className='rkpick';p.id='rkpick';
 p.innerHTML=`<h4>Emotes</h4><div class="rkfree">${WCRFREE.map(x=>`<button data-x="${esc(x)}">${esc(x)}</button>`).join('')}</div><h4>Ranked</h4><div class="rkre">${WCREMK.map(k=>{const own=rkOwn(k),E=WCREMO[k];
  return `<button data-k="${k}" class="${own?'':'lk'}${WX.rkMom&&WX.rkMom.k===k?' mom':''}" ${own?'':'disabled'} title="${own?E.n:'Unlocks at '+WCRN[E.r].n}">${WX.rkMom&&WX.rkMom.k===k?'<em>Moment!</em>':''}${rkEmo(k,wcMyAv(),'sm'+(own?'':' lock'))}${own?'':`<i>${WCI2.lock}</i>`}<small>${own?E.n:WCRN[E.r].n}</small></button>`}).join('')}</div>
 <p class="rkpn">One emote every 3 seconds. Tap a player's name to mute them.</p>`;t.appendChild(p);rkEmoPaint(p);wcFx('pop');
 p.querySelectorAll('[data-x]').forEach(b=>b.onclick=()=>{rkSend(b.dataset.x);p.remove()});p.querySelectorAll('[data-k]').forEach(b=>b.onclick=()=>{if(!rkOwn(b.dataset.k))return;rkSend('@'+b.dataset.k);p.remove()});
 setTimeout(()=>{const off=e=>{if(!p.isConnected){document.removeEventListener('pointerdown',off,true);return}if(!p.contains(e.target)&&e.target.closest('#rkemob')==null){p.remove();document.removeEventListener('pointerdown',off,true)}};document.addEventListener('pointerdown',off,true)},0)}
function rkSend(x){const now=Date.now();if(WX.emoT&&now-WX.emoT<3000){const b=$('rkemob');if(b){b.classList.remove('cd');void b.offsetWidth;b.classList.add('cd')}wcFx('bad');return}
 if(x[0]==='@'&&!rkOwn(x.slice(1)))return;WX.emoT=now;const b=$('rkemob');if(b){b.classList.remove('cd');void b.offsetWidth;b.classList.add('cd')}wcEmote(x)}
/* show an emote above a seat: text bubbles stay as they are, ranked emotes burst out of the seat */
{const b0=wcBubble;wcBubble=function(i,txt,ms){if(WX.mute&&WX.mute[i]&&i!==WX.me)return;const t=String(txt||'');if(t[0]==='@'){const k=t.slice(1);if(WCREMO[k])rkShow(i,k);return}return b0.apply(this,arguments)}}
{const c0=wcChat;wcChat=function(n,x){const t=String(x||'');if(t[0]==='@'&&WCREMO[t.slice(1)])x='sent “'+WCREMO[t.slice(1)].n+'”';return c0.call(this,n,x)}}
function rkShow(i,k){const fx=$('wcfx'),s=wcSeatEl(i),G=WX.G;if(!fx||!s||!G||!G.P[i])return;const av=G.P[i].av||{t:'hero'},a=s.querySelector('.wcav')||s,r=wcLocal(a);if(!r)return;
 const d=document.createElement('div');d.className='rkfly'+(i===WX.me?' me':'');const x=Math.max(70,Math.min(1530,r.x+r.w/2)),y=Math.max(80,r.y-(i===WX.me?70:30));d.style.left=x+'px';d.style.top=y+'px';d.innerHTML=rkEmo(k,av);fx.appendChild(d);rkEmoPaint(d);
 wcFx({stun:'zap',rev:'swirl',stack:'chip',slam:'whoosh',over:'rare'}[k]||'pop');setTimeout(()=>d.remove(),2100)}
/* moments: the emote that matches what just happened glows for 4 seconds; the AI sends theirs now and then */
function rkMomEnd(){const b=$('rkemob');if(b){b.classList.remove('mom');const c=b.querySelector('.rkmc');if(c)c.remove()}WX.rkMom=null}
function rkMoment(i,k){const G=WX.G;if(!G||!G.P[i]||!WCREMO[k])return;
 if(i===WX.me&&G.P[i].kind!=='bot'){if(!rkOwn(k))return;WX.rkMom={k,until:Date.now()+4000};const b=$('rkemob');if(!b)return;b.classList.add('mom');let c=b.querySelector('.rkmc');if(!c){c=document.createElement('span');c.className='rkmc';b.appendChild(c)}c.textContent=WCREMO[k].n+' · tap';
  clearTimeout(WX.rkMomT);WX.rkMomT=setTimeout(rkMomEnd,4000);return}
 const p=G.P[i];if(WX.rk&&p.kind==='bot'&&p.ai&&WCREMO[k].r<=WX.rk.r&&G.r()<.3)setTimeout(()=>{if(WX.G===G)wcBubble(i,'@'+k)},500+G.r()*700)}
{const a0=wcAnim;wcAnim=function(e){try{const G=WX.G;if(G&&e){if(e.k==='play'){WX.rkLP={p:e.p,v:e.c&&e.c.v};if(e.c&&e.c.v==='stun')rkMoment(e.p,'stun');else if(e.c&&e.c.v==='turn')rkMoment(e.p,'rev')}
 else if(e.k==='stack'&&WX.rkLP){const lp=WX.rkLP,base=lp.v==='d4'?4:2;if(e.n>base)rkMoment(lp.p,'stack');else if(lp.v==='d4')rkMoment(lp.p,'slam');WX.rkLP=null}
 else if(e.k==='win')rkMoment(e.p,'over')}}catch(x){}return a0.apply(this,arguments)}}
/* mute: tap a player's name */
{const r0=wcRender;wcRender=function(){const r=r0.apply(this,arguments);try{WX.mute=WX.mute||{};document.querySelectorAll('#wcseats .wcseat').forEach(s=>{const i=+s.dataset.seat;if(i===WX.me)return;const nm=s.querySelector('.wcnm');if(!nm)return;
 nm.classList.toggle('muted',!!WX.mute[i]);nm.title=WX.mute[i]?'Tap to unmute':'Tap to mute emotes';nm.onclick=e=>{e.stopPropagation();WX.mute[i]=!WX.mute[i];nm.classList.toggle('muted',!!WX.mute[i]);wcFx('click');wcToast(WX.mute[i]?`Muted <b>${esc(WX.G.P[i].name)}</b>'s emotes.`:`<b>${esc(WX.G.P[i].name)}</b> can send emotes again.`)}})}catch(e){}return r}}

{const st=document.createElement('style');st.textContent=`
body.tv :is(.rkx,.rkpick,.rkup,.rkmmv,.rkhome) :is(b,small,p,span,em,li,h4,div,button,i,u,strong){text-shadow:none!important}
.rkx{position:relative;width:1600px;height:900px;overflow:hidden;margin:0 auto;color:var(--ink);font-family:var(--ui);text-align:left}
.rkx h4{margin:0 0 10px;font:800 13px var(--ui);letter-spacing:.16em;text-transform:uppercase;color:var(--gold)}
.rkh .rkseason{cursor:default;color:#ffb070;border-color:#ff8a3a55}.rkh .rkseason svg{width:16px;height:16px;color:#ff8a3a}.rkh .wcpb.gold{cursor:default}
.rkp{position:absolute;padding:22px 24px;border-radius:24px;background:linear-gradient(180deg,#1e1650f2,#100a30f2);border:2px solid #463a8a;box-shadow:0 0 0 3px #12081f,0 18px 40px #000a,inset 0 1px 0 #ffffff1a;box-sizing:border-box;animation:wcup .55s var(--sp) both;z-index:2}
.rkglow{position:absolute;left:50%;top:150px;width:420px;height:420px;margin:-210px 0 0 -210px;border-radius:50%;background:radial-gradient(circle,color-mix(in srgb,var(--rc) 40%,transparent),transparent 65%);pointer-events:none}
.rkcrest{left:40px;top:118px;bottom:30px;width:520px;display:flex;flex-direction:column;align-items:center;text-align:center;border-color:color-mix(in srgb,var(--rc) 60%,#463a8a)}
.rkcrest .rkins{position:relative;margin-top:-14px}
.rkcrest h2,.rkcard h2{margin:-6px 0 0;font:400 58px/1 'Pirata One',Georgia,serif;text-shadow:0 3px 0 #12081f}
.rknum{display:flex;align-items:baseline;gap:8px;margin-top:8px}.rknum b{font:900 40px var(--ui);color:#fff}.rknum small{font:800 20px var(--ui);color:#a8a0d0}.rknum em{font:900 40px var(--ui);font-style:normal;margin-left:10px}
.rknum.big b,.rknum.big em{font-size:52px}
.up{color:#7ae8a0}.dn{color:#ff8a8a}.zero{color:#c4badf}
.rkbar{position:relative;width:380px;height:16px;margin-top:10px;border-radius:99px;background:#0a0620;border:2px solid #2e2660;overflow:hidden}
.rkbar i{position:absolute;left:0;top:0;bottom:0;width:var(--w);border-radius:99px;background:linear-gradient(90deg,#c87a10,#ffd45a);transition:width .9s cubic-bezier(.3,.8,.3,1)}
.rkbar u{position:absolute;top:0;bottom:0;left:0;width:0;transition:width .9s cubic-bezier(.3,.8,.3,1)}.rkbar u.g{width:var(--w);background:#6ae8a8}.rkbar u.r{width:var(--w);background:#ff6a7a}
.rkbar.leg i{background:linear-gradient(90deg,#9a4af0,#ffd45a,#9a4af0)}.rkbar.big{width:420px;height:20px}.rkbar.sm{width:150px;height:9px;margin-top:5px;border-width:1.5px}
.rknx{margin:8px 0 0;font:700 15px var(--ui);color:#c4badf}
.rkcrest .wcbtn.big{margin-top:auto;width:100%}.rksm{margin:10px 0 0;font:600 13px var(--ui);color:#a8a0d0}
.rkmid{left:584px;top:118px;bottom:30px;width:480px;display:flex;flex-direction:column}
.rkpts{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:16px}
.rkpt{display:flex;flex-direction:column;align-items:center;gap:6px;padding:12px 6px;border-radius:16px;background:#0e0828;border:1.5px solid #2e2660}.rkpt b{font:900 30px var(--ui)}
.rkul{margin:0 0 16px;padding:0 0 0 18px;font:600 14.5px/1.5 var(--ui);color:#ddd4ff}.rkul li{margin:3px 0}
.rkai{margin:0;font:600 14.5px/1.5 var(--ui);color:#ddd4ff}.rkai b{color:#fff}
.rkrow{display:flex;gap:10px;margin-top:auto;flex-wrap:wrap}.rkrow .wcbtn{flex:1;padding:0 12px;font-size:15px}.rkrow .wcbtn svg{width:18px;height:18px}
.rkside{left:1088px;right:40px;top:118px;bottom:30px;display:flex;flex-direction:column}
.rknext{display:flex;align-items:center;gap:12px;padding:12px;border-radius:18px;background:#0e0828;border:1.5px solid #2e2660;margin-bottom:16px}
.rknc{width:84px;height:123px;flex:none}.rknc svg{width:100%;height:100%;display:block}
.rkne .rkeb.sm2{transform:scale(.72);transform-origin:center;margin:-18px -16px}
.rknt{display:flex;flex-direction:column;gap:3px}.rknt b{display:flex;align-items:center;gap:6px;font:900 24px var(--ui);color:var(--gold)}.rknt small{font:700 13px var(--ui);color:#c4badf}
.rkhh{margin-top:4px!important}.rkhr{display:flex;align-items:center;gap:12px;padding:8px 12px;margin-bottom:6px;border-radius:12px;background:#0e0828;border:1.5px solid #2e2660;font:700 15px var(--ui)}.rkhr span:nth-child(2){flex:1;color:#ddd4ff}.rkhr b{font:900 17px var(--ui)}
.rkempty{margin:4px 0 8px;font:600 14px var(--ui);color:#a8a0d0}.rkrec{margin:auto 0 0;font:700 13px var(--ui);color:#a8a0d0}
.rkstd>div{display:flex;align-items:center;gap:10px;padding:7px 12px;margin-bottom:5px;border-radius:12px;background:#0e0828;font:700 15px var(--ui)}.rkstd>div.me{border:1.5px solid var(--gold)}.rkstd span{width:22px;color:#a8a0d0}.rkstd b{flex:1}.rkstd em{font-style:normal;color:var(--gold)}
.rkhow p{margin:0 0 12px;font:600 15.5px/1.5 var(--ui);color:#ece4ff}.rkhow b{color:var(--gold)}
/* result */
.rktag{position:absolute;left:50%;top:18px;transform:translateX(-50%);display:flex;align-items:center;gap:12px;padding:6px 16px 6px 6px;border-radius:99px;background:#120a2ee6;border:1.5px solid #463a8a;font:800 13px var(--ui);letter-spacing:.12em;z-index:3}
.rktag span{padding:4px 12px;border-radius:99px;background:linear-gradient(180deg,#ffe27a,#f6b830);color:#2a1406}
.rkt{position:absolute;left:56px;top:40px;margin:0;font:400 70px/1 'Pirata One',Georgia,serif;color:#ffd45a;text-shadow:0 4px 0 #6a2a08,0 0 30px #ffb02a55;z-index:2;animation:wcdn .5s var(--eo,ease-out) both}
.rkres.won .rkt{color:#ffe27a}
.rksub{position:absolute;left:58px;top:118px;margin:0;font:600 16px var(--ui);color:#c4badf;z-index:2}
.rklist{position:absolute;left:56px;top:150px;width:780px;display:flex;flex-direction:column;gap:10px;z-index:2}
.rkrr{display:flex;align-items:center;gap:16px;height:72px;padding:0 22px;border-radius:18px;background:#0e0828e6;border:1.5px solid #2e2660;animation:wcup .45s var(--sp) both;animation-delay:calc(.15s + var(--d)*.08s)}
.rkrr.me{background:linear-gradient(90deg,#3a2a9a,#251a6a);border:2px solid var(--gold);box-shadow:0 0 22px #ffd45a33}
.rkrr canvas{width:52px;height:52px;border-radius:50%;background:#1a1240;border:2.5px solid #5ab8ff;flex:none}
.rkpl{width:64px;font:900 26px var(--ui)}.rkpl.p0{color:#ffd45a}.rkpl.p1,.rkpl.p2{color:#ddd4ff}.rkpl.p3{color:#ff8a8a}
.rkrn{flex:1;display:flex;flex-direction:column}.rkrn b{font:800 18px var(--ui);color:#fff}.rkrn small{font:700 13px var(--ui);color:#a8a0d0}
.rkai2,.rkleg2{font-style:normal;margin-left:6px;padding:1px 7px;border-radius:99px;font:800 11px var(--ui);vertical-align:2px;background:#7a5af0;color:#fff}.rkleg2{background:linear-gradient(180deg,#ffe27a,#c87a10);color:#2a1406}
.rkrr em{font:900 24px var(--ui);font-style:normal}
.rktie{left:56px;top:498px;width:780px;padding:16px 22px}.rktie p,.rkhand p{margin:0;font:600 14.5px/1.5 var(--ui);color:#ece4ff}
.rkhand{left:56px;top:636px;width:780px;height:230px;padding:16px 22px}.rkhand p{width:390px}
.rkhc{position:absolute;right:120px;top:40px;width:0;height:0}.rkhcc{position:absolute;left:0;top:0;width:86px;height:126px;transform:translateX(calc(var(--k)*62px - 43px)) rotate(calc(var(--k)*5deg))}.rkhcc .wcc{width:86px;height:126px}.rkhcc svg{width:100%;height:100%;display:block}
.rkcard{left:892px;top:150px;width:670px;height:520px;display:flex;flex-direction:column;align-items:center;text-align:center;border-color:color-mix(in srgb,var(--rc) 55%,#463a8a)}
.rkcard .rkins{position:relative;margin-top:-6px}
.rkfirst{all:unset;cursor:pointer;display:flex;align-items:center;gap:12px;margin-top:12px;padding:8px 16px 8px 8px;border-radius:14px;background:#0e0828;border:1.5px solid #ffb070;text-align:left}.rkfirst svg{width:40px;height:58px;display:block}.rkfirst b{display:block;font:800 14px var(--ui);color:#ffb070}.rkfirst small{font:600 12px var(--ui);color:#c4badf}.rkfirst.done{border-color:#7ae8a0}
.rkbtns{position:absolute;left:892px;width:670px;top:700px;display:flex;gap:14px;z-index:2}.rkbtns .wcbtn.big{flex:1;margin:0}
/* ceremony */
.rkup{position:absolute;inset:0;z-index:30;display:flex;flex-direction:column;align-items:center;animation:rkfade .3s ease-out both}.rkup.out{animation:rkfade .3s ease-in reverse both}
@keyframes rkfade{from{opacity:0}to{opacity:1}}
.rkupbg{position:absolute;inset:0;background:radial-gradient(ellipse at 50% 36%,color-mix(in srgb,var(--rc) 30%,#1a0a3a),#07030cf2 70%)}
.rkuprays{position:absolute;left:50%;top:200px;width:1500px;height:1500px;margin:-750px 0 0 -750px;-webkit-mask:radial-gradient(circle,#000 10%,transparent 60%);mask:radial-gradient(circle,#000 10%,transparent 60%);animation:rkspin 50s linear infinite;pointer-events:none}
.rkupin{position:relative;margin-top:30px;animation:rkin .9s var(--sp) both}@keyframes rkin{from{transform:scale(.2) rotate(-20deg);opacity:0}to{transform:none;opacity:1}}
.rkup h2{position:relative;margin:-6px 0 0;font:400 62px/1 'Pirata One',Georgia,serif;color:#fff;text-shadow:0 4px 0 #12081f;animation:wcup .5s .5s var(--sp) both}
.rkups{position:relative;margin:6px 0 0;font:700 16px var(--ui);color:#c4badf;animation:wcup .5s .6s var(--sp) both}
.rkupr{position:relative;display:flex;gap:22px;margin-top:22px}
.rkupt{width:250px;height:250px;padding:16px;box-sizing:border-box;border-radius:20px;background:linear-gradient(180deg,#1e1650,#100a30);border:2px solid color-mix(in srgb,var(--rc) 55%,#463a8a);box-shadow:0 0 0 3px #12081f;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;gap:4px;animation:wcup .5s var(--sp) both;animation-delay:calc(.8s + var(--d)*.18s)}
.rkupt b{font:800 16px var(--ui);color:#fff}.rkupt small{font:600 13px var(--ui);color:#c4badf;text-align:center}.rkupt .wcbtn{margin-top:6px}
.rkupc{width:80px;height:117px;margin-bottom:auto}.rkupc svg{width:100%;height:100%;display:block}
.rkupcoin{display:flex;align-items:center;gap:12px;margin:auto 0}.rkupcoin .coin{transform:scale(2.1);margin-right:10px}.rkupt .rkupcoin b{font:900 40px var(--ui);color:var(--gold)}.rkeq{all:unset;cursor:pointer;margin-top:6px;padding:7px 16px;border-radius:12px;font:800 14px var(--ui);color:#2a1406;background:linear-gradient(180deg,#ffe27a,#f6b830);border:2px solid #fff0b0;box-shadow:0 3px 0 #9a5a10}.rkeq:disabled{opacity:.8;cursor:default}
.rkupleg{color:#ffd45a!important;font-weight:800!important}
.rkupgo{position:relative;width:340px!important;margin-top:22px!important;animation:wcup .5s 1.4s var(--sp) both}
/* road */
.rkroadsub{position:absolute;left:58px;top:96px;margin:0;font:600 16px var(--ui);color:#c4badf;z-index:2}
.rkline{position:absolute;left:150px;right:150px;top:222px;height:8px;border-radius:99px;background:#2a2060;z-index:1}.rkline i{position:absolute;left:0;top:0;bottom:0;width:var(--w);border-radius:99px;background:linear-gradient(90deg,#e8904a,#ffd45a)}
.rkyou{position:absolute;top:-8px;left:50%;transform:translateX(-50%);z-index:3;padding:4px 12px;border-radius:99px;background:linear-gradient(180deg,#ffe27a,#f6b830);color:#2a1406;font:800 13px var(--ui);white-space:nowrap;box-shadow:0 0 0 2px #12081f}.rkrdi{position:relative}
.rkrdtop{position:absolute;left:30px;right:30px;top:140px;display:grid;grid-template-columns:repeat(6,1fr);z-index:2}
.rkrdi{display:flex;flex-direction:column;align-items:center;height:200px;justify-content:flex-end;animation:wcup .5s var(--sp) both;animation-delay:calc(var(--d)*.07s)}.rkrdi b{font:400 30px 'Pirata One',Georgia,serif;margin-top:2px}
.rkrdi:not(.got) .rkins{opacity:.6}
.rkrdc{position:absolute;left:30px;right:30px;top:352px;display:grid;grid-template-columns:repeat(6,1fr);gap:16px;z-index:2}
.rkrc{position:relative;height:440px;padding:30px 12px 14px;box-sizing:border-box;border-radius:20px;background:linear-gradient(180deg,#1a1248,#0e0828);border:2px solid #2e2660;display:flex;flex-direction:column;align-items:center;gap:6px;text-align:center;animation:wcup .5s var(--sp) both;animation-delay:calc(.2s + var(--d)*.07s)}
.rkrc.next{border-color:var(--gold);box-shadow:0 0 30px #ffd45a44}.rkrc.got{border-color:color-mix(in srgb,var(--rc) 50%,#2e2660)}
.rkrc em{position:absolute;top:10px;font:800 11px var(--ui);font-style:normal;letter-spacing:.14em;color:#a8a0d0}.rkrc.got em{color:#7ae8a0}.rkrc.next em{color:var(--gold)}
.rkrcb{width:96px;height:140px;flex:none}.rkrcb svg{width:100%;height:100%;display:block}.rkrc.lock .rkrcb{opacity:.6}
.rkrc>b{font:800 14px var(--ui);color:#fff}.rkrc small{font:700 13px var(--ui);color:#c4badf}.rkrc .rkok{color:#7ae8a0}
.rkrc .rkeb.sm{margin:2px -60px -66px 0}
.rkrcoin{display:flex;align-items:center;gap:8px;margin-top:auto;font:900 26px var(--ui);color:var(--gold)}
.rkst{margin:6px 0 10px;font:600 13.5px/1.45 var(--ui);color:#c4badf}.rkst b{display:block;color:#fff;margin-bottom:4px;font-size:15px}
.rkfoot{position:absolute;left:0;right:0;bottom:22px;margin:0;text-align:center;font:700 15px var(--ui);color:#c4badf;z-index:2}.rkfoot b{color:var(--gold)}.rkfoot .coin{vertical-align:-3px}
/* home crest */
.rkhome{all:unset;cursor:pointer;position:absolute;left:162px;top:10px;height:66px;display:flex;align-items:center;gap:10px;padding:0 14px 0 6px;border-radius:20px;background:linear-gradient(180deg,#221a5af2,#100a30f2);border:2px solid color-mix(in srgb,var(--rc) 70%,#463a8a);box-shadow:0 0 0 3px #12081f,0 12px 30px #000a,0 0 30px color-mix(in srgb,var(--rc) 25%,transparent);z-index:12;transition:transform .2s var(--sp);animation:wcup .55s .2s var(--sp) both}
.rktro{display:grid;place-items:center;width:42px;height:42px;border-radius:50%;background:radial-gradient(circle at 35% 30%,#fff2a0,#f6b830 55%,#a8680e);box-shadow:0 0 0 2.5px #12081f,0 0 16px #ffd45a66;color:#5a3006}.rktro svg{width:26px;height:26px}.rkhome:hover .rktro{animation:rkwob .6s var(--sp)}@keyframes rkwob{30%{transform:rotate(-12deg) scale(1.1)}60%{transform:rotate(8deg)}}
.rkgo{font:900 26px var(--ui);font-style:normal;color:var(--gold);margin-left:-2px}
.rkhome:hover{transform:translateY(-3px) scale(1.03)}.rkhome:focus-visible{outline:3px solid var(--gold);outline-offset:3px}
.rkhi{margin:-10px 0}.rkht{display:grid;grid-template-columns:auto auto;align-items:center;column-gap:10px}.rkht em{grid-column:1/3;font:800 10px/1.2 var(--ui);font-style:normal;letter-spacing:.2em;color:var(--gold)}.rkht b{font:400 24px/1 'Pirata One',Georgia,serif}.rkht small{font:700 12px var(--ui);color:#c4badf}.rkht .rkbar{grid-column:1/3;width:150px;margin-top:2px}.rkht small{justify-self:end}
/* vault shelves */
.rkvt{display:flex;gap:6px;padding:4px;border-radius:14px;background:#0e0828;border:1.5px solid #2e2660}.rkvt button{all:unset;cursor:pointer;padding:8px 14px;border-radius:10px;font:800 14px var(--ui);color:#c4badf}.rkvt button small{color:#8a80b8;margin-left:4px}.rkvt button.on{background:linear-gradient(180deg,#ffe27a,#f6b830);color:#2a1406}.rkvt button.on small{color:#6a4a10}
.wcvgrid.rkg{grid-template-columns:repeat(3,1fr)}.wcvt[hidden]{display:none!important}
/* emotes at the table */
.rkemob{position:relative}.rkemob svg{width:20px;height:20px}.rkemob.mom{border-color:var(--gold);box-shadow:0 0 0 2px #ffd45a88,0 0 20px #ffd45a88;animation:rkmom 1s ease-in-out infinite}
@keyframes rkmom{50%{transform:scale(1.06)}}.rkemob.cd::after{content:'';position:absolute;left:8px;right:8px;bottom:4px;height:3px;border-radius:2px;background:var(--gold);transform-origin:left;animation:rkcd 3s linear both}@keyframes rkcd{from{transform:scaleX(1)}to{transform:scaleX(0)}}
.rkemob .rkmc{position:absolute;font:800 13px var(--ui)!important;letter-spacing:0;text-shadow:none;left:0;bottom:calc(100% + 8px);padding:6px 12px;border-radius:10px;background:linear-gradient(180deg,#ffe27a,#f6b830);color:#2a1406;font:800 13px var(--ui);white-space:nowrap;box-shadow:0 0 0 2px #12081f}
.rkpick{position:absolute;left:28px;bottom:206px;width:430px;padding:16px 18px 12px;border-radius:20px;background:linear-gradient(180deg,#221a5af7,#100a30f7);border:2px solid var(--gold);box-shadow:0 0 0 3px #12081f,0 18px 40px #000c;z-index:20;animation:wcpop .3s var(--sp) both}
.rkpick h4{margin:0 0 9px;font:800 13px var(--ui);letter-spacing:.16em;text-transform:uppercase;color:var(--gold);text-shadow:none}.rkfree{display:flex;flex-wrap:wrap;gap:7px;margin-bottom:12px}.rkfree button{all:unset;cursor:pointer;padding:7px 13px;border-radius:99px;background:#2a2060;border:1.5px solid #463a8a;font:700 14px var(--ui);color:#fff;transition:transform .15s var(--sp)}.rkfree button:hover{transform:scale(1.06);border-color:var(--gold)}
.rkre{display:flex;gap:4px}.rkre button{all:unset;cursor:pointer;position:relative;width:76px;display:flex;flex-direction:column;align-items:center;transition:transform .15s var(--sp)}.rkre button:not(.lk):hover{transform:scale(1.08)}.rkre button.lk{cursor:default}
.rkre .rkeb.sm{margin:0 -60px -66px 0;transform:scale(.6);margin:0 -48px -53px 0}.rkre small{font:700 11.5px var(--ui);color:#c4badf;white-space:nowrap}.rkre button.lk small{color:#8a80b8}
.rkre i{position:absolute;right:6px;top:2px;width:18px;height:18px;color:#c4badf}.rkre i svg{width:100%;height:100%}.rkre em{position:absolute;top:-10px;padding:2px 7px;border-radius:99px;background:var(--gold);color:#2a1406;font:800 10px var(--ui);font-style:normal;z-index:2}
.rkre button.mom .rkeb{filter:drop-shadow(0 0 8px #ffd45a)}.rkpn{margin:10px 0 0;font:600 12px var(--ui);color:#a8a0d0}
.rkfly{position:absolute;width:0;height:0;z-index:12;pointer-events:none}.rkfly .rkeb{position:absolute;left:-60px;top:-132px;animation:rkpop 2s cubic-bezier(.3,1.4,.5,1) both}
@keyframes rkpop{0%{transform:scale(.1) rotate(-25deg);opacity:0}12%{transform:scale(1.18) rotate(6deg);opacity:1}22%{transform:scale(1) rotate(-3deg);opacity:1}30%,82%{transform:scale(1) rotate(0);opacity:1}100%{transform:scale(.9) translateY(-24px);opacity:0}}
.wcnm.muted{opacity:.6}.wcnm.muted b::after{content:' 🔇';font-size:.8em}.wcseat .wcnm{cursor:pointer}
.rkt .wcseat .d-ai,.d-ai{color:#c8b8ff}.d-ai i{font-style:normal;padding:0 5px;border-radius:5px;background:#7a5af0;color:#fff;margin-right:3px}.d-leg{color:#ffd45a}
.wcpill.rkpil{padding-left:4px;border-color:#ffd45a88}.wcpill.rkpil .rkins{width:34px;height:34px}`;document.head.appendChild(st)}
