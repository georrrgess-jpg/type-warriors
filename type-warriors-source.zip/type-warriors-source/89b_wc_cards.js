/* ===== WILDCARD: card art — faces, backs and the element orb =====
   Faces: a crisp white border around a vivid element gradient with a radiant glow, sunburst rays and the element's
   own motif; a gold-rimmed diamond medallion holds the value or action icon; element coins sit in the corners under
   the index; a glass sheen crosses the top. Wilds are obsidian with the four elements spiralling out from the centre;
   +4 Hex is a deep violet with a hex lattice. Shared gradients live once in a hidden <svg>; markup is cached per face.
   Backs: nine collectable designs (see WCBK), each drawn as its own small illustration. */
const WCK={e:['#ffb347','#ff5a1f','#c4102a'],t:['#7ae8ff','#1f8cff','#2a36c8'],g:['#b4f56a','#22c55e','#0b7a46'],s:['#fff27a','#ffc21a','#f07a00']};
const WCG={/* element glyphs, drawn around 0,0 at about 20 units */
 e:'<path d="M0-11C5-5 8-1 7 4A7 7 0 0 1-7 4C-8-1-4-3-3-8-1-4 0-3 1-2 1-5 0-8 0-11Z" fill="#fff4e0" stroke="#12081f" stroke-width="2.2" stroke-linejoin="round"/><path d="M0-2C3 1 4 3 3 5A3 3 0 0 1-3 5C-4 3-2 1 0-2Z" fill="#ff8a1f"/>',
 t:'<path d="M0-11C4-5 8-1 8 3A8 8 0 0 1-8 3C-8-1-4-5 0-11Z" fill="#eaf8ff" stroke="#12081f" stroke-width="2.2" stroke-linejoin="round"/><path d="M-4 2A4 4 0 0 0 0 6" stroke="#1f8cff" stroke-width="2" fill="none" stroke-linecap="round"/>',
 g:'<path d="M-8 8C-9-2-3-9 9-10 9 2 3 9-8 8Z" fill="#f0ffe6" stroke="#12081f" stroke-width="2.2" stroke-linejoin="round"/><path d="M-8 8L4-4" stroke="#22c55e" stroke-width="2" stroke-linecap="round"/>',
 s:'<path d="M2-11L-7 2H0L-3 11 8-3H1Z" fill="#fffbe0" stroke="#12081f" stroke-width="2.2" stroke-linejoin="round"/>',
 w:'<path d="M0-10L3-3 10 0 3 3 0 10-3 3-10 0-3-3Z" fill="#fff" stroke="#12081f" stroke-width="2" stroke-linejoin="round"/>'};
const WCDIA='M50 37L84 73 50 109 16 73Z',WCDIA2='M50 41.5L79.5 73 50 104.5 20.5 73Z';
{const d=document.createElementNS('http://www.w3.org/2000/svg','svg');d.setAttribute('width','0');d.setAttribute('height','0');d.style.position='absolute';d.setAttribute('aria-hidden','true');
 const lg=(id,stops,x2,y2)=>`<linearGradient id="${id}" x1="0" y1="0" x2="${x2==null?1:x2}" y2="${y2==null?1:y2}">${stops.map(([o,c,a])=>`<stop offset="${o}" stop-color="${c}"${a!=null?` stop-opacity="${a}"`:''}/>`).join('')}</linearGradient>`;
 const rg=(id,stops,cx,cy,r)=>`<radialGradient id="${id}" cx="${cx==null?.5:cx}" cy="${cy==null?.5:cy}" r="${r||.7}">${stops.map(([o,c,a])=>`<stop offset="${o}" stop-color="${c}"${a!=null?` stop-opacity="${a}"`:''}/>`).join('')}</radialGradient>`;
 d.innerHTML=`<defs>${Object.entries(WCK).map(([k,c])=>lg('wcf'+k,[[0,c[0]],[.5,c[1]],[1,c[2]]])+lg('wcv'+k,[[0,c[1]],[1,c[2]]],0,1)).join('')}
 ${lg('wcsh',[[0,'#ffffff'],[.6,'#fff6e4'],[1,'#f0dcb4']])}${lg('wcgd',[[0,'#fff6c8'],[.4,'#ffd45a'],[.7,'#e8a020'],[1,'#fff0a8']])}
 ${rg('wcrg',[[0,'#fff',.55],[.55,'#fff',.12],[1,'#fff',0]],.5,.45,.6)}${lg('wcgl',[[0,'#fff',.55],[.45,'#fff',.08],[.46,'#fff',0]],0,1)}
 ${rg('wcwv',[[0,'#3a2a8a'],[.6,'#140a3a'],[1,'#05031a']])}${rg('wchx',[[0,'#a83ae0'],[.55,'#4a0e7a'],[1,'#14031f']])}
 <clipPath id="wcclip"><rect x="6" y="6" width="88" height="134" rx="8"/></clipPath><clipPath id="wcdc"><path d="${WCDIA2}"/></clipPath>
 <g id="wcray">${Array.from({length:16},(_,i)=>`<path d="M50 73L${50+120*Math.cos(i*Math.PI/8-.08)} ${73+120*Math.sin(i*Math.PI/8-.08)}L${50+120*Math.cos(i*Math.PI/8+.08)} ${73+120*Math.sin(i*Math.PI/8+.08)}Z"/>`).join('')}</g>
 <pattern id="wcme" width="22" height="26" patternUnits="userSpaceOnUse" patternTransform="rotate(-8)"><path d="M11 3C15 9 17 12 16 16A5 5 0 0 1 6 16C5 12 8 11 9 7 10 10 11 10 11 3Z" fill="#fff" opacity=".14"/></pattern>
 <pattern id="wcmt" width="26" height="14" patternUnits="userSpaceOnUse"><path d="M0 9C4 3 9 3 13 9S22 15 26 9" fill="none" stroke="#fff" stroke-width="2" opacity=".17"/></pattern>
 <pattern id="wcmg" width="24" height="24" patternUnits="userSpaceOnUse" patternTransform="rotate(20)"><path d="M4 18C4 10 10 5 18 5 18 13 12 18 4 18Z" fill="#fff" opacity=".13"/></pattern>
 <pattern id="wcms" width="20" height="22" patternUnits="userSpaceOnUse" patternTransform="rotate(10)"><path d="M11 2L5 11H9L7 19 15 8H11Z" fill="#fff" opacity=".15"/></pattern>
 <pattern id="wchex" width="12" height="20.8" patternUnits="userSpaceOnUse"><path d="M6 0L12 3.5V10.4L6 13.9 0 10.4V3.5ZM6 13.9V20.8" fill="none" stroke="#e8a8ff" stroke-width=".8" opacity=".35"/></pattern>
 ${lg('wbk1',[[0,'#e8304a'],[.5,'#8a0a24'],[1,'#3a0412']])}${lg('wbk2',[[0,'#1a0640'],[.55,'#7a1a8a'],[.62,'#ff4a9a'],[1,'#2a0650']],0,1)}${lg('wbk2s',[[0,'#ffe14a'],[.55,'#ff7a3a'],[1,'#ff2a8a']],0,1)}
 ${lg('wbk3',[[0,'#3a0e5a'],[1,'#120420']],0,1)}${rg('wbk4',[[0,'#2fd07a'],[.6,'#0e6a3a'],[1,'#03301a']])}${lg('wbk5',[[0,'#fff1b0'],[.35,'#ffc94a'],[.7,'#c8860e'],[1,'#ffe48a']])}
 ${rg('wbk6',[[0,'#3a2a9a'],[.7,'#120a40'],[1,'#05031a']])}${rg('wbk7',[[0,'#ff7a1a'],[.35,'#a8180a'],[1,'#1a0303']],.5,.5,.75)}${lg('wbk8',[[0,'#ffb8e0'],[.5,'#e8c8ff'],[1,'#9ad8ff']])}${rg('wbk9',[[0,'#1a6a5a'],[.7,'#08302a'],[1,'#031410']])}
 ${rg('wbkn1',[[0,'#ff4a9a',.75],[1,'#ff4a9a',0]])}${rg('wbkn2',[[0,'#4ad8ff',.6],[1,'#4ad8ff',0]])}${rg('wbkg',[[0,'#ffd45a',.9],[1,'#ffd45a',0]])}</defs>`;
 (document.body||document.documentElement).appendChild(d)}
/* the icon or number inside the diamond */
function wcFace(c){const W=c.s==='w',K=W?null:WCK[c.s],mid=W?'#fff':K[1];
 const num=(t,sz)=>`<text x="50" y="${73+sz*.36}" text-anchor="middle" font-family="Poppins,Segoe UI,sans-serif" font-weight="900" font-size="${sz}" fill="url(#wcv${c.s})" stroke="#12081f" stroke-width="${sz>36?4.6:4}" paint-order="stroke" stroke-linejoin="round" letter-spacing="-1.5">${t}</text>`;
 if(/^\d$/.test(c.v))return num(c.v,46);
 if(c.v==='d2')return `<g transform="translate(50 73)"><g transform="rotate(-14)"><rect x="-17" y="-20" width="20" height="28" rx="3.5" fill="${K[2]}" stroke="#12081f" stroke-width="2.2"/></g><g transform="rotate(10)"><rect x="-4" y="-17" width="20" height="28" rx="3.5" fill="${K[1]}" stroke="#12081f" stroke-width="2.2"/><path d="M6-9L9-3 6 3 3-3Z" fill="#fff" opacity=".85"/></g>
  <text y="15" text-anchor="middle" font-family="Poppins,Segoe UI,sans-serif" font-weight="900" font-size="26" fill="#fff" stroke="#12081f" stroke-width="4.4" paint-order="stroke" stroke-linejoin="round" letter-spacing="-1">+2</text></g>`;
 if(c.v==='stun')return `<g transform="translate(50 73)"><circle r="17" fill="none" stroke="#12081f" stroke-width="10"/><circle r="17" fill="none" stroke="${mid}" stroke-width="5.5"/><path d="M-12 12L12-12" stroke="#12081f" stroke-width="10" stroke-linecap="round"/><path d="M-12 12L12-12" stroke="${mid}" stroke-width="5.5" stroke-linecap="round"/>
  <path d="M3-30L-5-18H1L-3-9 7-22H1Z" fill="#fff6a0" stroke="#12081f" stroke-width="1.8" stroke-linejoin="round" transform="translate(14 4)"/></g>`;
 if(c.v==='turn')return `<g transform="translate(50 73)" stroke-linecap="round" stroke-linejoin="round"><path d="M-15-5A16 16 0 0 1 12-11" fill="none" stroke="#12081f" stroke-width="11"/><path d="M15 5A16 16 0 0 1-12 11" fill="none" stroke="#12081f" stroke-width="11"/>
  <path d="M-15-5A16 16 0 0 1 12-11" fill="none" stroke="${mid}" stroke-width="5.5"/><path d="M15 5A16 16 0 0 1-12 11" fill="none" stroke="${mid}" stroke-width="5.5"/><path d="M7-20L19-10 5-5Z" fill="${mid}" stroke="#12081f" stroke-width="2.4"/><path d="M-7 20L-19 10-5 5Z" fill="${mid}" stroke="#12081f" stroke-width="2.4"/></g>`;
 if(c.v==='d4')return `<g transform="translate(50 74)">${[['e',-21,-9],['t',-7,-3],['g',7,3],['s',21,9]].map(([k,a,x])=>`<g transform="rotate(${a})"><rect x="${x-8}" y="-21" width="16" height="23" rx="3" fill="${WCK[k][1]}" stroke="#12081f" stroke-width="2"/></g>`).join('')}
  <text y="16" text-anchor="middle" font-family="Poppins,Segoe UI,sans-serif" font-weight="900" font-size="24" fill="#fff" stroke="#12081f" stroke-width="4.4" paint-order="stroke" stroke-linejoin="round" letter-spacing="-1">+4</text></g>`;
 /* wild rune: an eight-point star over the four elements */
 return `<g clip-path="url(#wcdc)">${[['e',-135],['t',-45],['s',45],['g',135]].map(([k,a])=>`<path d="M50 73L${50+40*Math.cos((a-45)*Math.PI/180)} ${73+40*Math.sin((a-45)*Math.PI/180)}A40 40 0 0 1 ${50+40*Math.cos((a+45)*Math.PI/180)} ${73+40*Math.sin((a+45)*Math.PI/180)}Z" fill="${WCK[k][1]}"/>`).join('')}</g>
  <g transform="translate(50 73)"><path d="M0-21L5-5 21 0 5 5 0 21-5 5-21 0-5-5Z" fill="#fff" stroke="#12081f" stroke-width="2.6" stroke-linejoin="round"/><path d="M0-12L3-3 12 0 3 3 0 12-3 3-12 0-3-3Z" fill="#ffd45a" transform="rotate(45)" stroke="#12081f" stroke-width="1.4"/><circle r="3" fill="#12081f"/></g>`}
function wcCorner(c){if(c.s==='w')return c.v==='d4'?'+4':'W';return /^\d$/.test(c.v)?c.v:c.v==='d2'?'+2':c.v==='stun'?'⊘':'⇄'}
const WCSV=new Map(),WCRIB={stun:'STUN',turn:'TURN',d2:'CURSE',wild:'WILD',d4:'HEX'};
function wcSVG(c){const k=c.s+c.v;if(WCSV.has(k))return WCSV.get(k);const W=c.s==='w',H=c.v==='d4',K=W?null:WCK[c.s];
 const body=W?`<rect x="6" y="6" width="88" height="134" fill="url(#${H?'wchx':'wcwv'})"/>${H?'<rect x="6" y="6" width="88" height="134" fill="url(#wchex)"/>':''}
  ${[['e',-135],['t',-45],['s',45],['g',135]].map(([k,a])=>`<path d="M50 73L${50+110*Math.cos((a-40)*Math.PI/180)} ${73+110*Math.sin((a-40)*Math.PI/180)}L${50+110*Math.cos((a+40)*Math.PI/180)} ${73+110*Math.sin((a+40)*Math.PI/180)}Z" fill="${WCK[k][1]}" opacity="${H?.32:.5}"/>`).join('')}
  <g fill="#fff" opacity=".1"><use href="#wcray"/></g><circle cx="50" cy="73" r="46" fill="none" stroke="#fff" stroke-width="1" stroke-dasharray="1.5 4" opacity=".5"/>`
  :`<rect x="6" y="6" width="88" height="134" fill="url(#wcf${c.s})"/><g fill="#fff" opacity=".09"><use href="#wcray"/></g><rect x="6" y="6" width="88" height="134" fill="url(#wcm${c.s})"/>
  <g transform="translate(50 73) scale(3.2)" opacity=".13">${WCG[c.s].replace(/stroke="[^"]*"/g,'stroke="none"').replace(/fill="#[0-9a-f]{6}"/gi,'fill="#fff"')}</g>`;
 const coin=(x,y,r)=>`<g transform="translate(${x} ${y}) rotate(${r})"><circle r="6.6" fill="${W?'#fff':'#fffaf0'}" stroke="#12081f" stroke-width="1.8"/><g transform="scale(.42)">${W?WCG.w:WCG[c.s]}</g></g>`;
 const cor=wcCorner(c),ico=c.v==='stun'?'<g transform="translate(0 -5)"><circle r="5.6" fill="none" stroke="#12081f" stroke-width="4.6"/><path d="M-4 4L4-4" stroke="#12081f" stroke-width="4.6"/><circle r="5.6" fill="none" stroke="#fff" stroke-width="2"/><path d="M-4 4L4-4" stroke="#fff" stroke-width="2"/></g>'
  :c.v==='turn'?'<g transform="translate(0 -5)" fill="none" stroke-linecap="round"><path d="M-6-2A6 6 0 0 1 5-3M6 2A6 6 0 0 1-5 3" stroke="#12081f" stroke-width="4.6"/><path d="M-6-2A6 6 0 0 1 5-3M6 2A6 6 0 0 1-5 3" stroke="#fff" stroke-width="2"/></g>':null;
 const idx=(x,y,r)=>`<g transform="translate(${x} ${y}) rotate(${r})">${ico||`<text x="0" y="0" text-anchor="middle" font-family="Poppins,Segoe UI,sans-serif" font-weight="900" font-size="${cor.length>1?14:17}" fill="#fff" stroke="#12081f" stroke-width="3.6" paint-order="stroke" stroke-linejoin="round" letter-spacing="-.5">${cor}</text>`}</g>`;
 const svg=`<svg viewBox="0 0 100 146" class="wcsvg" aria-hidden="true"><rect x="2" y="2" width="96" height="142" rx="11" fill="#fffdf8" stroke="#12081f" stroke-width="2.6"/>
 <g clip-path="url(#wcclip)">${body}<rect x="6" y="6" width="88" height="134" fill="url(#wcrg)"/><path d="M6 6H94V52L6 92Z" fill="url(#wcgl)" opacity=".7"/></g>
 <rect x="6" y="6" width="88" height="134" rx="8" fill="none" stroke="#12081f" stroke-width="1.4"/><rect x="9" y="9" width="82" height="128" rx="6" fill="none" stroke="#fff" stroke-width=".9" opacity=".55"/>
 <path d="${WCDIA}" fill="#12081f" transform="translate(0 2.4)" opacity=".35"/><path d="${WCDIA}" fill="url(#wcgd)" stroke="#12081f" stroke-width="2.4" stroke-linejoin="round"/>
 <path d="${WCDIA2}" fill="${W?(H?'#2a0a40':'#160c3a'):'url(#wcsh)'}" stroke="#12081f" stroke-width="1.8" stroke-linejoin="round"/>
 ${W?'':`<g transform="translate(50 73) scale(2.1)" opacity=".1">${WCG[c.s].replace(/stroke="[^"]*"/g,'stroke="none"').replace(/fill="#[0-9a-f]{6}"/gi,`fill="${K[2]}"`)}</g>`}
 ${wcFace(c)}<path d="M50 41.5L79.5 73 66 73C60 62 55 55 50 41.5Z" fill="#fff" opacity="${W?.08:.35}"/>
 ${WCRIB[c.v]?`<g transform="translate(50 124)"><rect x="-19" y="-6.5" width="38" height="13" rx="6.5" fill="#12081f" opacity=".72"/><text y="3.3" text-anchor="middle" font-family="Poppins,Segoe UI,sans-serif" font-weight="900" font-size="8" letter-spacing="1.2" fill="#fff">${WCRIB[c.v]}</text></g>`:''}
 ${idx(15.5,25,0)}${coin(15.5,36,0)}${idx(84.5,121,180)}${coin(84.5,110,180)}
 <rect x="2" y="2" width="96" height="142" rx="11" fill="none" stroke="#fff" stroke-width=".8" opacity=".4"/></svg>`;
 WCSV.set(k,svg);return svg}
/* ---------- card backs: nine collectables ----------
   r: rarity (1 common, 2 rare, 3 epic, 4 legendary, 5 secret). need(W) returns [have, goal] for the progress bar. */
const WCRAR=['','Common','Rare','Epic','Legendary','Secret'],WCRARC=['','#c8bfa8','#5ab8ff','#c87aff','#ffb02a','#5affc0'];
const WCBK={
 classic:{n:'Lounge Velvet',r:1,how:'Owned from the start',fl:'Crimson velvet and gold leaf from the Dragon Lounge card room.',need:()=>[1,1]},
 neon:{n:'Neon Arcade',r:2,how:'Play 10 games',fl:'A synthwave sunset straight off the lounge\'s arcade cabinets.',need:W=>[W.g,10]},
 hallow:{n:"Hallow's Eve",r:2,how:'Win 3 games (or play one at Halloween)',fl:'Moonlight, bats and a grinning jack-o\'-lantern.',need:W=>[W.w,3]},
 emerald:{n:'Emerald Jackpot',r:2,how:'Win 10 games',fl:'Fresh felt, lucky sevens and a scatter of gold.',need:W=>[W.w,10]},
 royal:{n:'Royal Gold',r:3,how:'Win 25 games',fl:'Hammered gold and a ruby crown, for the house\'s favourite players.',need:W=>[W.w,25]},
 astral:{n:'Astral',r:3,how:'Win 10 games at the Gold Room or higher',fl:'A nebula of rose and violet, stars drawn into a W.',need:W=>[W.byd.c1k.w+W.byd.c2k5.w+W.byd.h.w,10]},
 dragon:{n:'Dragonfire',r:4,how:'Reach a 5-game win streak',fl:'Molten scales around the burning eye of the lounge\'s owner.',need:W=>[W.best,5]},
 pastel:{n:'Pastel Wyrm',r:4,how:'Beat the rare pastel dragon',fl:'Cotton-candy skies for those who outplayed the lounge\'s most dapper regular.',need:W=>[W.pbeat||0,1]},
 rune:{n:'Elder Rune',r:5,how:'A secret hidden in the 8.2 notes',fl:'Ancient stone that hums when the right word is spoken.',need:W=>[W.backs.rune?1:0,1]}};
const WCBKK=Object.keys(WCBK);
function wcBackArt(k){const f='#12081f';switch(k){
 case 'neon':return `<rect x="7" y="7" width="86" height="132" rx="8" fill="url(#wbk2)"/><g clip-path="url(#wcclip)"><circle cx="50" cy="70" r="26" fill="url(#wbk2s)"/>${[60,67,73,79,85].map((y,i)=>`<rect x="20" y="${y}" width="60" height="${1.6+i*.5}" fill="#2a0650"/>`).join('')}
  <rect x="6" y="88" width="88" height="52" fill="#14032e"/>${Array.from({length:11},(_,i)=>`<path d="M50 88L${-50+i*20} 146" stroke="#4ae8ff" stroke-width="1.1" opacity=".85"/>`).join('')}${[92,97,104,114,128].map(y=>`<path d="M6 ${y}H94" stroke="#ff4a9a" stroke-width="1.1" opacity=".85"/>`).join('')}
  <circle cx="22" cy="24" r="1.2" fill="#fff"/><circle cx="76" cy="18" r="1" fill="#fff"/><circle cx="84" cy="38" r="1.3" fill="#fff"/><circle cx="16" cy="48" r=".9" fill="#fff"/></g>
  <rect x="7" y="7" width="86" height="132" rx="8" fill="none" stroke="#4ae8ff" stroke-width="2.2"/><rect x="11" y="11" width="78" height="124" rx="6" fill="none" stroke="#ff4a9a" stroke-width="1.2"/>
  <text x="50" y="128" text-anchor="middle" font-family="Pirata One,Georgia,serif" font-size="13" letter-spacing="2" fill="#ffe14a" stroke="#ff2a8a" stroke-width=".6">WILDCARD</text>`;
 case 'hallow':return `<rect x="7" y="7" width="86" height="132" rx="8" fill="url(#wbk3)"/><g clip-path="url(#wcclip)"><circle cx="66" cy="34" r="20" fill="#ffd88a"/><circle cx="72" cy="30" r="17" fill="#ffe8b0" opacity=".5"/>
  ${[[22,30,1],[34,22,.7],[80,62,.8]].map(([x,y,s])=>`<path d="M${x} ${y}c-3-3-7-3-9 0 2-.5 4 0 5 2 1-2 2-3 4-3 2 0 3 1 4 3 1-2 3-2.5 5-2-2-3-6-3-9 0z" fill="${f}" opacity="${s}"/>`).join('')}
  <path d="M6 116C20 106 34 112 50 106S80 104 94 112V140H6Z" fill="#1a0428"/></g>
  <g transform="translate(50 92)"><path d="M0-19C-15-19-21-9-21 1-21 13-12 19 0 19 12 19 21 13 21 1 21-9 15-19 0-19Z" fill="#ff8a1f" stroke="${f}" stroke-width="2.6"/><path d="M-8-19C-11-9-11 10-6 19M8-19C11-9 11 10 6 19" stroke="#c8520e" stroke-width="2" fill="none"/>
  <path d="M0-19C0-24 3-27 7-28" stroke="#3a7a1a" stroke-width="3.4" fill="none" stroke-linecap="round"/><path d="M-12-3L-5-7-3 0ZM12-3L5-7 3 0ZM-10 8Q0 16 10 8L6 10 2 7-2 10-6 7Z" fill="#ffe14a" stroke="${f}" stroke-width="1"/></g>
  <rect x="7" y="7" width="86" height="132" rx="8" fill="none" stroke="#ff8a1f" stroke-width="2.4"/>`;
 case 'emerald':return `<rect x="7" y="7" width="86" height="132" rx="8" fill="url(#wbk4)"/><g clip-path="url(#wcclip)">${[[18,24],[80,30],[24,112],[78,118],[14,70],[86,82]].map(([x,y],i)=>`<g transform="translate(${x} ${y}) rotate(${i*40})"><ellipse rx="7" ry="5" fill="#ffc94a" stroke="${f}" stroke-width="1.4"/><ellipse rx="4" ry="2.6" fill="none" stroke="#9a5a10" stroke-width="1"/></g>`).join('')}</g>
  ${Array.from({length:20},(_,i)=>{const t=i/20*Math.PI*2;return `<circle cx="${50+34*Math.cos(t)}" cy="${73+48*Math.sin(t)}" r="1.8" fill="#fff4b0" stroke="${f}" stroke-width=".6"/>`}).join('')}
  <rect x="24" y="58" width="52" height="30" rx="6" fill="#2a0a14" stroke="#ffd45a" stroke-width="2.4"/>${[0,1,2].map(i=>`<rect x="${28+i*16}" y="62" width="12" height="22" rx="2" fill="#fff8ec"/><text x="${34+i*16}" y="80" text-anchor="middle" font-family="Poppins,sans-serif" font-weight="900" font-size="17" fill="#e8384a">7</text>`).join('')}
  <rect x="7" y="7" width="86" height="132" rx="8" fill="none" stroke="#ffd45a" stroke-width="2.4"/>`;
 case 'royal':return `<rect x="7" y="7" width="86" height="132" rx="8" fill="url(#wbk5)"/><g clip-path="url(#wcclip)" opacity=".28">${Array.from({length:30},(_,i)=>`<path transform="translate(${8+(i%5)*21} ${12+Math.floor(i/5)*24})" d="M0-6C3-3 3 1 0 6-3 1-3-3 0-6ZM-6 0C-3-3 1-3 6 0 1 3-3 3-6 0Z" fill="#8a5a08"/>`).join('')}</g>
  <ellipse cx="50" cy="73" rx="27" ry="38" fill="#8a1028" stroke="${f}" stroke-width="2.4"/><ellipse cx="50" cy="73" rx="22" ry="32" fill="none" stroke="#ffd45a" stroke-width="1.6" stroke-dasharray="2 2.5"/>
  <g transform="translate(50 74)"><path d="M-17 9L-19-11-9-2 0-16 9-2 19-11 17 9Z" fill="url(#wbk5)" stroke="${f}" stroke-width="2.4" stroke-linejoin="round"/><path d="M-17 9H17V14H-17Z" fill="#c8860e" stroke="${f}" stroke-width="2.2"/><circle cy="-2" r="3.4" fill="#e8304a" stroke="${f}" stroke-width="1.4"/>${[-19,0,19].map(x=>`<circle cx="${x}" cy="${x?-11:-16}" r="2.2" fill="#fff" stroke="${f}" stroke-width="1"/>`).join('')}</g>
  <rect x="7" y="7" width="86" height="132" rx="8" fill="none" stroke="#fff6c8" stroke-width="2.4"/><rect x="11" y="11" width="78" height="124" rx="6" fill="none" stroke="#8a5a08" stroke-width="1"/>`;
 case 'astral':return `<rect x="7" y="7" width="86" height="132" rx="8" fill="url(#wbk6)"/><g clip-path="url(#wcclip)"><circle cx="30" cy="44" r="40" fill="url(#wbkn1)"/><circle cx="74" cy="104" r="44" fill="url(#wbkn2)"/>
  ${Array.from({length:26},(_,i)=>`<circle cx="${(i*37)%86+7}" cy="${(i*53)%132+7}" r="${.5+(i%4)*.35}" fill="#fff" opacity="${.5+(i%3)*.2}"/>`).join('')}</g>
  <path d="M28 52L38 92 50 66 62 92 72 52" fill="none" stroke="#fff" stroke-width="1.1" opacity=".75"/>${[[28,52],[38,92],[50,66],[62,92],[72,52]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.4" fill="#fff"/><circle cx="${x}" cy="${y}" r="5" fill="#fff" opacity=".2"/>`).join('')}
  <path d="M50 108L53 115 60 118 53 121 50 128 47 121 40 118 47 115Z" fill="#ffe9ff"/><rect x="7" y="7" width="86" height="132" rx="8" fill="none" stroke="#ff9ad8" stroke-width="2.4"/>`;
 case 'dragon':return `<rect x="7" y="7" width="86" height="132" rx="8" fill="url(#wbk7)"/><g clip-path="url(#wcclip)" opacity=".55">${Array.from({length:42},(_,i)=>`<path transform="translate(${8+(i%6)*17+(Math.floor(i/6)%2)*8} ${10+Math.floor(i/6)*19})" d="M-8 0Q0 10 8 0" fill="none" stroke="#ff9a2a" stroke-width="1.6"/>`).join('')}</g>
  <path d="M8 40Q24 52 18 76T30 120M92 30Q74 48 84 70T70 128" stroke="#ffd45a" stroke-width="1.4" fill="none" opacity=".8"/>
  <g transform="translate(50 73)"><circle r="26" fill="#1a0303" stroke="#ff9a2a" stroke-width="2.4"/>${Array.from({length:12},(_,i)=>`<path transform="rotate(${i*30})" d="M0-26L4-34 0-31-4-34Z" fill="#ff7a1a"/>`).join('')}
  <ellipse rx="19" ry="12" fill="#ffd45a" stroke="${f}" stroke-width="2"/><ellipse rx="19" ry="12" fill="url(#wbkg)" opacity=".8"/><ellipse rx="3.6" ry="11" fill="${f}"/><ellipse cx="-6" cy="-4" rx="3" ry="2" fill="#fff" opacity=".8"/></g>
  <rect x="7" y="7" width="86" height="132" rx="8" fill="none" stroke="#ff9a2a" stroke-width="2.4"/>`;
 case 'pastel':return `<rect x="7" y="7" width="86" height="132" rx="8" fill="url(#wbk8)"/><g clip-path="url(#wcclip)">${[[20,30,10],[78,22,8],[70,120,12],[18,112,9]].map(([x,y,r])=>`<g fill="#fff" opacity=".8"><circle cx="${x}" cy="${y}" r="${r}"/><circle cx="${x+r*.9}" cy="${y+2}" r="${r*.75}"/><circle cx="${x-r*.9}" cy="${y+3}" r="${r*.65}"/></g>`).join('')}
  ${[[30,58],[74,52],[26,92],[80,96],[50,24]].map(([x,y])=>`<path d="M${x} ${y-4}L${x+1.2} ${y-1.2} ${x+4} ${y} ${x+1.2} ${y+1.2} ${x} ${y+4} ${x-1.2} ${y+1.2} ${x-4} ${y} ${x-1.2} ${y-1.2}Z" fill="#fff"/>`).join('')}</g>
  <g transform="translate(50 78)"><path d="M-12-16C-20-26-26-30-30-26-24-24-20-20-17-12ZM12-16C20-26 26-30 30-26 24-24 20-20 17-12Z" fill="#fff4e6" stroke="${f}" stroke-width="1.8" stroke-linejoin="round"/>
  <path d="M-19-4L-31-10-27 2-33 6-20 6ZM19-4L31-10 27 2 33 6 20 6Z" fill="#9ad8ff" stroke="${f}" stroke-width="1.6" stroke-linejoin="round"/>
  <path d="M0-24C14-24 21-14 21-3 21 8 14 13 0 13-14 13-21 8-21-3-21-14-14-24 0-24Z" fill="#ff9ad0" stroke="${f}" stroke-width="2.2"/>${[-6,0,6].map(x=>`<path d="M${x-3} ${-22+Math.abs(x)*.3}L${x} ${-28+Math.abs(x)*.4} ${x+3} ${-22+Math.abs(x)*.3}Z" fill="#9ad8ff" stroke="${f}" stroke-width="1.2"/>`).join('')}
  <path d="M-11 4C-11 0-6-1 0-1S11 0 11 4C11 11 6 15 0 15S-11 11-11 4Z" fill="#ffd8ec" stroke="${f}" stroke-width="1.8"/><ellipse cx="-4" cy="4" rx="1.4" ry="1.1" fill="${f}"/><ellipse cx="4" cy="4" rx="1.4" ry="1.1" fill="${f}"/>
  <path d="M-5 10Q0 13 5 10" fill="none" stroke="${f}" stroke-width="1.4" stroke-linecap="round"/><path d="M3 10.6L4.2 13.4 5.2 10.2Z" fill="#fff"/>
  <ellipse cx="-8.5" cy="-8" rx="4.2" ry="5" fill="#fff" stroke="${f}" stroke-width="1.6"/><ellipse cx="8.5" cy="-8" rx="4.2" ry="5" fill="#fff" stroke="${f}" stroke-width="1.6"/><ellipse cx="-8" cy="-7.4" rx="2.6" ry="3.4" fill="#3a8ae8"/><ellipse cx="9" cy="-7.4" rx="2.6" ry="3.4" fill="#3a8ae8"/><circle cx="-9" cy="-9" r="1.1" fill="#fff"/><circle cx="8" cy="-9" r="1.1" fill="#fff"/>
  <ellipse cx="-14" cy="1" rx="3" ry="1.8" fill="#ff5a9a" opacity=".55"/><ellipse cx="14" cy="1" rx="3" ry="1.8" fill="#ff5a9a" opacity=".55"/>
  <g transform="translate(0 18)"><path d="M0 0L-8-4-8 4ZM0 0L8-4 8 4Z" fill="#5ab8ff" stroke="${f}" stroke-width="1.4" stroke-linejoin="round"/><circle r="2" fill="#5ab8ff" stroke="${f}" stroke-width="1.2"/></g></g>
  <rect x="7" y="7" width="86" height="132" rx="8" fill="none" stroke="#fff" stroke-width="2.4"/><rect x="11" y="11" width="78" height="124" rx="6" fill="none" stroke="#ff9ad0" stroke-width="1.2"/>`;
 case 'rune':return `<rect x="7" y="7" width="86" height="132" rx="8" fill="url(#wbk9)"/><g clip-path="url(#wcclip)" opacity=".35">${Array.from({length:8},(_,i)=>`<path d="M${10+i*12} 7V140" stroke="#0a1a16" stroke-width="5"/>`).join('')}</g>
  <circle cx="50" cy="73" r="30" fill="none" stroke="#8affc8" stroke-width="2.2" stroke-dasharray="4 3"/><circle cx="50" cy="73" r="36" fill="none" stroke="#8affc8" stroke-width=".8" opacity=".6"/>
  ${Array.from({length:8},(_,i)=>`<text transform="rotate(${i*45} 50 73)" x="50" y="34" text-anchor="middle" font-family="serif" font-size="8" fill="#8affc8" opacity=".85">${'ᚠᚢᚦᚨᚱᚲᚷᚹ'[i]}</text>`).join('')}
  <g transform="translate(50 73)" stroke-linecap="round" stroke-linejoin="round"><path d="M0-17V17M-10-9L10 9M10-9L-10 9M-6 17H6" stroke="${f}" stroke-width="7"/><path d="M0-17V17M-10-9L10 9M10-9L-10 9M-6 17H6" stroke="#bfffe0" stroke-width="3.2"/></g>
  <rect x="7" y="7" width="86" height="132" rx="8" fill="none" stroke="#8affc8" stroke-width="2.4"/>`;
 default:return `<rect x="7" y="7" width="86" height="132" rx="8" fill="url(#wbk1)"/><g clip-path="url(#wcclip)"><g fill="#ffd45a" opacity=".1"><use href="#wcray"/></g>${Array.from({length:7},(_,i)=>`<path d="M7 ${20+i*18}Q30 ${14+i*18} 50 ${20+i*18}T93 ${20+i*18}" stroke="#ff8aa0" stroke-width=".6" fill="none" opacity=".25"/>`).join('')}</g>
  ${[[13,13,0],[87,13,90],[87,133,180],[13,133,270]].map(([x,y,r])=>`<g transform="translate(${x} ${y}) rotate(${r})"><path d="M0 0L14 0A14 14 0 0 1 0 14Z" fill="none" stroke="#ffd45a" stroke-width="1.4"/><path d="M0 0L9 0A9 9 0 0 1 0 9Z" fill="#ffd45a" opacity=".5"/></g>`).join('')}
  <path d="M50 37L77 73 50 109 23 73Z" fill="#5a0618" stroke="#ffd45a" stroke-width="2.6" stroke-linejoin="round"/><path d="M50 45L71 73 50 101 29 73Z" fill="none" stroke="#ffd45a" stroke-width="1" opacity=".7"/>
  <g transform="translate(50 73)"><ellipse rx="15" ry="9" fill="#ffd45a" stroke="${f}" stroke-width="2"/><ellipse rx="3" ry="8.4" fill="${f}"/><ellipse cx="-5" cy="-3" rx="2.4" ry="1.6" fill="#fff" opacity=".85"/></g>
  <rect x="7" y="7" width="86" height="132" rx="8" fill="none" stroke="#ffd45a" stroke-width="2.4"/>`}}
function wcBack(k){k=WCBK[k]?k:'classic';const key='back:'+k;if(WCSV.has(key))return WCSV.get(key);
 const svg=`<svg viewBox="0 0 100 146" class="wcsvg" aria-hidden="true"><rect x="2" y="2" width="96" height="142" rx="11" fill="#fffdf8" stroke="#12081f" stroke-width="2.6"/>${wcBackArt(k)}
 <path d="M7 7H93V48L7 86Z" fill="url(#wcgl)" opacity=".45" clip-path="url(#wcclip)"/><rect x="2" y="2" width="96" height="142" rx="11" fill="none" stroke="#fff" stroke-width=".8" opacity=".4"/></svg>`;WCSV.set(key,svg);return svg}
const wcCardEl=(c,cls,extra)=>`<div class="wcc${cls?' '+cls:''}" ${c?`data-id="${c.id}"`:''} ${extra||''}>${c?wcSVG(c):wcBack(wcBackSel())}</div>`;
function wcBackSel(){try{const W=wcSt();return WCBK[W.back]&&W.backs[W.back]?W.back:'classic'}catch(e){return'classic'}}
/* the element orb: a glossy gem used by the picker, menus and pop-ups */
const wcOrb=(s,sz)=>`<svg viewBox="-16 -16 32 32" width="${sz||40}" height="${sz||40}" aria-hidden="true"><circle r="14" fill="url(#wcf${s})" stroke="#12081f" stroke-width="2.4"/><circle r="10.5" fill="none" stroke="#fff" stroke-width="1" opacity=".45"/><path d="M-10-4A11 11 0 0 1 4-11" stroke="#fff" stroke-width="2.4" fill="none" stroke-linecap="round" opacity=".75"/><g transform="scale(.8)">${WCG[s]}</g></svg>`;
