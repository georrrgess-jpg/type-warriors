# Wildcard on school-style networks: direct WebRTC links blocked, so the game must run over the relay (89r).
# Needs the local MQTT broker (ws 127.0.0.1:18083) and the local Nostr relay (t_nostr_relay.py on 18090).
import asyncio,os,sys,time
from playwright.async_api import async_playwright
MQ='ws://127.0.0.1:18083/mqtt';NO='nostr:ws://127.0.0.1:18090';DEAD='ws://127.0.0.1:9/mqtt'
BLOCK="(()=>{const R=window.RTCPeerConnection;if(!R)return;function F(c){return new R(Object.assign({},c||{},{iceTransportPolicy:'relay'}))}F.prototype=R.prototype;window.RTCPeerConnection=F})()"
NORTC="(()=>{try{delete window.RTCPeerConnection}catch(e){}window.RTCPeerConnection=undefined})()"
html=os.path.abspath(sys.argv[1] if len(sys.argv)>1 else 'out.html');bad=0;er=[]
def chk(name,r,ok):
    global bad;bad+=not ok;print(name,r,'OK' if ok else 'BAD',flush=True)
async def pair(b,relays,initA,initB,gold=(3000,900)):
    pages=[]
    for init,nm,g in ((initA,'Seth',gold[0]),(initB,'Mia',gold[1])):
        c=await b.new_context(viewport={'width':1600,'height':900})
        if init:await c.add_init_script(init)
        pg=await c.new_page();pg.on('pageerror',lambda e,nm=nm:er.append(nm+' PE '+str(e)[:300]));await pg.goto('file://'+html);pages.append((pg,nm,g))
    await pages[0][0].wait_for_timeout(1200)
    for pg,nm,g in pages:await pg.evaluate(f"()=>{{RS_ASK=false;WCRELAYS={relays};P.name='{nm}';P.gold={g};save();wcHome()}}")
    return pages[0][0],pages[1][0]
async def host(A):
    await A.click('#wchost');t0=time.time()
    while time.time()-t0<12 and await A.evaluate("()=>WCL.net")!='online':await A.wait_for_timeout(100)
    return await A.evaluate("()=>WCL.room")
async def join(B,code):
    await B.click('#wcotp input[data-o="0"]');await B.keyboard.type(code.lower(),delay=40);await B.click('#wcjoin');t1=time.time()
    while time.time()-t1<30 and not await B.evaluate("()=>!!document.getElementById('wcrdy')"):await B.wait_for_timeout(100)
    return round(time.time()-t1,1)
async def play(A,B,stake):
    await B.click('#wcrdy');await A.wait_for_timeout(1200);await A.click('#wcgo');await A.wait_for_timeout(2500)
    for pg in (A,B):await pg.add_script_tag(path=os.path.abspath('t_wc_agent.js'))
    t2=time.time()
    while time.time()-t2<420:
        await A.wait_for_timeout(700)
        if await A.evaluate("()=>!!document.getElementById('wcr')") and await B.evaluate("()=>!!document.getElementById('wcr')"):break
    q="()=>{const R=wcRank(WX.G);return [R.indexOf(WX.me),P.gold,__ag.errs]}"
    return round(time.time()-t2),await A.evaluate(q),await B.evaluate(q)
pay=lambda pl:[180,20,0,0][pl]+(150 if pl==0 else 0)
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch()
        # 1. direct links blocked on both sides, only a Nostr relay: join, ready, a whole staked game
        A,B=await pair(b,f"['{NO}']",BLOCK,BLOCK)
        code=await host(A);chk('host online via Nostr',code,await A.evaluate("()=>WCL.net")=='online')
        await A.click('[data-stk="50"]');t=await join(B,code)
        r=await B.evaluate("()=>[!!document.getElementById('wcrdy'),!!(WCNET.guest&&WCNET.guest.relay),WCNET.guest&&WCNET.guest.lobby&&WCNET.guest.lobby.room]");chk(f'guest joined over the relay in {t}s',r,r[0] and r[1] and r[2]==code)
        r=await A.evaluate("()=>WCL.seats.map(s=>s.k+':'+(s.name||'')+(s.relay?':relay':''))");chk('host sees Mia on the relay',r,'net:Mia:relay' in r)
        await B.screenshot(path='shots/wc_school_guest.png')
        secs,ra,rb=await play(A,B,50)
        chk(f'whole game over the relay in {secs}s, host',ra,ra[1]==3000-50+pay(ra[0]) and not ra[2]);chk('guest',rb,rb[1]==900-50+pay(rb[0]) and not rb[2])
        await B.screenshot(path='shots/wc_school_result_B.png')
        await A.context.close();await B.context.close()
        # 2. the guest's browser cannot make direct links at all (WebRTC off), MQTT relay; leaving frees the seat at once
        A,B=await pair(b,f"['{MQ}']",BLOCK,NORTC)
        code=await host(A);t=await join(B,code)
        r=await B.evaluate("()=>[typeof RTCPeerConnection,!!document.getElementById('wcrdy'),!!(WCNET.guest&&WCNET.guest.relay)]");chk(f'no WebRTC: joined over the relay in {t}s',r,r[1] and r[2])
        await A.evaluate("()=>{for(const c of WCR.conns)c.ws.close()}");await A.wait_for_timeout(4000)
        await B.click('#wcrdy');await A.wait_for_timeout(2500)
        r=await A.evaluate("()=>[WCR.conns.map(c=>c.ok),WCL.net,WCL.seats.find(s=>s.k==='net').ready]");chk('relay dropped and reconnected, messages still flow',r,all(r[0]) and r[1]=='online' and r[2]==1)
        await B.evaluate("()=>{wcNetClose();wcHome()}");await A.wait_for_timeout(2500)
        r=await A.evaluate("()=>WCL.seats.map(s=>s.k)");chk('guest left, seat free again',r,'net' not in r)
        await A.context.close();await B.context.close()
        # 3. a normal network: the direct link is still used, and a dead relay in the list does no harm
        A,B=await pair(b,f"['{DEAD}','{NO}','{MQ}']",None,None)
        code=await host(A);t=await join(B,code);await B.wait_for_timeout(7000)
        r=await B.evaluate("()=>[!!document.getElementById('wcrdy'),!!(WCNET.guest&&WCNET.guest.relay),WCNET.guest&&WCNET.guest.dc&&WCNET.guest.dc.readyState]");chk(f'normal network stays direct ({t}s)',r,r[0] and not r[1] and r[2]=='open')
        # 4. the QR invite carries the room code while online: decode it, then join with it
        await A.evaluate("()=>{const i=WCL.seats.findIndex(x=>x.k==='open');WCL.seats[i]={k:'inv',via:'scan',name:'Friend'};wcLobbyRender();wcInvite(i)}");await A.wait_for_timeout(500)
        await A.screenshot(path='shots/wc_school_qr.png')
        txt=await A.evaluate("""async()=>{const svg=document.querySelector('#wcqr svg');const s=new XMLSerializer().serializeToString(svg);const im=new Image();im.src='data:image/svg+xml;base64,'+btoa(s);await im.decode();
         const c=document.createElement('canvas');c.width=c.height=480;const g=c.getContext('2d');g.fillStyle='#fff';g.fillRect(0,0,480,480);g.drawImage(im,40,40,400,400);return wcQRDecode(g.getImageData(0,0,480,480))}""")
        chk('QR holds the room code',txt,txt=='WCR~'+code)
        r=await A.evaluate("()=>WCL.seats.filter(s=>s.k==='inv').length");chk('no seat held for the QR',r,r==0)
        await A.context.close();await B.context.close()
        A,B=await pair(b,f"['{MQ}']",BLOCK,BLOCK)
        code=await host(A);await B.evaluate(f"()=>wcJoin('WCR~{code}')");t1=time.time()
        while time.time()-t1<30 and not await B.evaluate("()=>!!document.getElementById('wcrdy')"):await B.wait_for_timeout(100)
        r=await B.evaluate("()=>[!!document.getElementById('wcrdy'),!!(WCNET.guest&&WCNET.guest.relay)]");chk(f'scanned QR joins (relay) in {time.time()-t1:.1f}s',r,r==[True,True])
        await B.evaluate("()=>{wcNetClose();wcHome()}");await A.wait_for_timeout(1500);t=await join(B,code)
        r=await B.evaluate("()=>[!!document.getElementById('wcrdy'),!!(WCNET.guest&&WCNET.guest.relay)]");chk(f'second join from the same device goes straight to the relay ({t}s)',r,r==[True,True] and t<6)
        # 5. the connection check
        await B.evaluate(f"()=>{{wcNetClose();WCRELAYS=['{MQ}','{NO}','{DEAD}'];wcHome();wcNetCheck()}}");await B.wait_for_timeout(17000)
        r=await B.evaluate("()=>[document.querySelector('#wccks').className,[...document.querySelectorAll('.wcckr')].map(e=>e.querySelector('.ic').className+' | '+e.querySelector('small').textContent),WCCK.rep.length]")
        chk('connection check (working relays)',r,'ok' in r[0] and r[2]>4)
        for x in r[1]:print('   ',x)
        await B.screenshot(path='shots/wc_school_check_ok.png')
        await B.evaluate(f"()=>{{WCRELAYS=['{DEAD}','nostr:ws://127.0.0.1:9'];wcNetCheck()}}");await B.wait_for_timeout(17000)
        r=await B.evaluate("()=>[document.querySelector('#wccks').className,document.querySelector('#wccks').textContent.slice(0,60)]");chk('connection check (all blocked)',r,'bad' in r[0])
        await B.screenshot(path='shots/wc_school_check_bad.png')
        await B.evaluate("()=>{const m=document.getElementById('wcmod');m.hidden=true;wcJoinCode('ABCD')}");await B.wait_for_timeout(3000)
        r=await B.evaluate("()=>[document.querySelector('.wcjs h2').textContent,!!document.getElementById('wcckj')]");chk('blocked network message',r,'room servers' in r[0] and r[1])
        await B.screenshot(path='shots/wc_school_nonet.png')
        print('bad',bad);print(er[:6]);await b.close()
asyncio.run(main())
