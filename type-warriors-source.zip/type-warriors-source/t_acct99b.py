# python3 t_acct99b.py [game.html] : Accounts 9.9m (97j): the simpler Create account form and the "Save your progress" pop-up for
# new players, plus edge cases of account creation. Local relays on 18153/18154 (started here, stopped by PID), never the public ones.
# Covers: two fields only (username, password) with Show/Hide, live hints (name rules, Available / Taken, password length), the
# prefilled hero name, Enter submits, a double click makes one account, unicode passwords, creating while offline leaves no account,
# the hero name only replaced when it is "Hero", "Keep me signed in" off, two people racing for one name, keys not reaching the game,
# the recovery code screen (Copy ticks the box), and the pop-up: when it shows, Later, Don't ask again, at most three times, never for
# signed-in players, never on top of another window, "I already have an account", and creating an account from it.
import asyncio,os,sys,subprocess,json,time
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
PYLIB=os.path.abspath(os.path.join(HERE,'../tools/pylib'))
A,B,DEAD=18153,18154,18159
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:600]),flush=True)
    if not ok:FAIL.append(name)
def start(port):
    os.makedirs(os.path.join(HERE,'../lbt'),exist_ok=True);log=open(os.path.join(HERE,f'../lbt/acrelay{port}.log'),'w')
    return subprocess.Popen([sys.executable,'t_nostr_relay.py',str(port)],cwd=HERE,env={**os.environ,'PYTHONPATH':PYLIB+':'+HERE},stdout=log,stderr=subprocess.STDOUT)
LIVE=[f'ws://127.0.0.1:{A}',f'ws://127.0.0.1:{B}']
async def device(br,relays=None,nudge=True):
    ctx=await br.new_context(viewport={'width':1600,'height':900})
    try:await ctx.grant_permissions(['clipboard-read','clipboard-write'])
    except Exception:pass
    await ctx.add_init_script('window.TWA_RELAYS=%s;window.TWA_ITER=2000;window.TWA_NORELOAD=1;window.TWA_NOSTART=1;%s'%(json.dumps(relays if relays is not None else LIVE),'window.TWA_NUDGE=1;' if nudge else ''))
    pg=await ctx.new_page();er=[];pg.on('pageerror',lambda e:er.append(str(e)[:300]));await pg.goto(H);await pg.wait_for_timeout(1500)
    await pg.evaluate("()=>{RS_ASK=false;WCRELAYS=[];try{ST.perfAsked=1}catch(e){}try{PFW.asked=true}catch(e){}}");return ctx,pg,er
async def idle(pg):
    for _ in range(160):
        if not await pg.evaluate("()=>TWAU.busy||!!(TWA.st.q)"):return
        await pg.wait_for_timeout(150)
async def done(pg):
    for _ in range(160):
        await pg.wait_for_timeout(150);st=await pg.evaluate("()=>[TWAU.busy,($('twamsg')||{}).textContent||'',!!$('twacode'),!!$('twasync'),($('twamsg')||{className:''}).className]")
        if not st[0] and (st[2] or st[3] or 'bad' in st[4]):return st
    return st
async def form(pg,tab='up'):
    await idle(pg);await pg.evaluate("(t)=>{twaClose();TWAU.nudge=0;TWAU.tab=t;TWAU.msg='';TWAU.bad=0;TWAU.u='';twaForm()}",tab);await pg.wait_for_timeout(100)
async def hint(pg,sel,want,tries=40):
    for _ in range(tries):
        h=await pg.evaluate("(s)=>{const e=document.querySelector(s);return e?[e.textContent,e.className]:null}",sel)
        if h and want in h[0]:return h
        await pg.wait_for_timeout(150)
    return h
async def main():
    procs=[start(A),start(B)];time.sleep(1.2)
    try:
        async with async_playwright() as p:
            br=await p.chromium.launch();allerr=[]
            c1,d1,e1=await device(br);allerr.append(e1);c2,d2,e2=await device(br);allerr.append(e2)
            # ---- the form: two fields, Show/Hide
            await d1.evaluate("()=>{P.name='Hero';save()}");await form(d1)
            r=await d1.evaluate("()=>[[...document.querySelectorAll('#twa .twaform input:not([type=checkbox])')].map(i=>i.id),!!$('twap2'),$('twarem').checked,$('twap').type]")
            await d1.click('.twaeye');r.append(await d1.evaluate("()=>[$('twap').type,document.querySelector('.twaeye').textContent]"))
            await d1.click('.twaeye');r.append(await d1.evaluate("()=>$('twap').type"))
            chk('Create account has just a username and a password (no second password), "Keep me signed in" on, and Show/Hide on the password',r==[['twau','twap'],False,True,'password',['text','Hide'],'password'],r)
            # ---- live hints
            await d1.fill('#twau','ab');h1=await hint(d1,'#twauh','3');await d1.fill('#twau','a b c');h2=await hint(d1,'#twauh','Use')
            await d1.fill('#twap','abc');h3=await d1.evaluate("()=>[$('twaph').textContent,$('twaph').className]");await d1.fill('#twap','abcdefgh');h4=await d1.evaluate("()=>[$('twaph').textContent,$('twaph').className]")
            chk('live hints: a too-short or badly formed name is flagged while typing; the password hint counts down to "✓ 8 or more characters"',h1[1]=='bad' and h2[1]=='bad' and '(5 more)' in h3[0] and h4==['✓ 8 or more characters','ok'],[h1,h2,h3,h4])
            r=await d2.evaluate("async()=>{const r=await twaSignUp('Taken_1','some password 1',true);await twaSignOut(false);return !!r.ok}")
            await d1.fill('#twau','TAKEN_1');h1=await hint(d1,'#twauh','Taken');await d1.fill('#twau','Fresh_9');h2=await hint(d1,'#twauh','Available')
            chk('live check: a taken name (any capitalisation) shows "✗ Taken", a free one "✓ Available"',r and h1==['✗ Taken','bad'] and h2==['✓ Available','ok'],[r,h1,h2])
            # ---- short password, then Enter submits; a double click makes one account
            await d1.fill('#twau','Quick_1');await d1.fill('#twap','short');await d1.press('#twap','Enter');await d1.wait_for_timeout(200)
            r=await d1.evaluate("()=>[$('twamsg').textContent,!!twaLoadSes()]")
            chk('a short password is refused with a clear message and no account',('8' in r[0]) and r[1]==False,r)
            await d1.evaluate("()=>{window.__nup=0;const f=twaSignUp;twaSignUp=async function(){__nup++;return f.apply(this,arguments)}}")
            await d1.fill('#twap','long enough 1');await d1.press('#twap','Enter');await d1.press('#twap','Enter')
            try:await d1.click('#twago',timeout=500)
            except Exception:pass
            st=await done(d1)
            r=await d1.evaluate("async()=>{const b=await twaFindBoxes('quick_1');return [__nup,b.evs.length,!!$('twacode'),$('twagood').disabled,P.name]}")
            chk('Enter submits; pressing Enter twice and clicking makes exactly one account; the code screen waits for the box; the hero takes the name',r==[1,1,True,True,'Quick_1'],[st,r])
            await d1.click('#twacp');await d1.wait_for_timeout(300)
            r=await d1.evaluate("()=>[$('twaok').checked,$('twagood').disabled]")
            chk('Copy on the recovery code screen ticks "I have saved my recovery code" and enables Continue',r==[True,False],r)
            await d1.click('#twagood');await d1.wait_for_timeout(200)
            r=await d1.evaluate("()=>[!!$('twasync'),$('twachip').className]")
            chk('Continue opens the account panel and the chip shows the account',r[0] and r[1]!='out',r)
            await idle(d1);await d1.evaluate("async()=>{await twaSignOut(false);twaClose()}")
            # ---- unicode password across devices
            r=await d1.evaluate("async()=>{const a=await twaSignUp('Uni_1','pässwörd 🐉 ключ',true);await twaSignOut(false);return !!a.ok}")
            await form(d2,'in');await d2.fill('#twau','uni_1');await d2.fill('#twap','pässwörd 🐉 ключ');await d2.click('#twago');st=await done(d2)
            r2=await d2.evaluate("()=>{const s=twaLoadSes();return s?s.d:null}")
            chk('a password with accents, emoji and other alphabets works on another device',r and r2=='Uni_1',[r,st,r2])
            await idle(d2);await d2.evaluate("async()=>{await twaSignOut(false);twaClose()}")
            # ---- hero name kept when the player already named the hero; prefilled
            await d2.evaluate("()=>{P.name='Zed_Warrior';save()}");await form(d2)
            r=[await d2.evaluate("()=>$('twau').value")]
            await d2.fill('#twau','Zed_Acct');await d2.fill('#twap','zed password 1');await d2.click('#twago');st=await done(d2)
            r.append(await d2.evaluate("()=>[P.name,twaLoadSes().d]"))
            chk('the hero name fills in the username; a hero already named keeps its name',r==['Zed_Warrior',['Zed_Warrior','Zed_Acct']],[st,r])
            await idle(d2);await d2.evaluate("async()=>{await twaSignOut(false);twaClose()}")
            # ---- Keep me signed in off
            await form(d2);await d2.fill('#twau','Temp_1');await d2.fill('#twap','temp password');await d2.uncheck('#twarem');await d2.click('#twago');st=await done(d2)
            r=await d2.evaluate("()=>[!!sessionStorage.getItem(TWA.sesK),!!localStorage.getItem(TWA.sesK),!!twaLoadSes()]")
            chk('"Keep me signed in" off keeps the session for this tab only (nothing in local storage)',r==[True,False,True],[st,r])
            await idle(d2);await d2.evaluate("async()=>{await twaSignOut(false);twaClose()}")
            # ---- offline create leaves nothing behind
            c3,d3,e3=await device(br,[f'ws://127.0.0.1:{DEAD}']);allerr.append(e3)
            await form(d3);await d3.fill('#twau','Off_1');await d3.fill('#twap','offline pass');await d3.click('#twago');st=await done(d3)
            r=await d3.evaluate("()=>[!!twaLoadSes(),!!localStorage.getItem(TWA.sesK),$('twago').disabled,$('twago').textContent,$('twachip').className]")
            chk('creating an account while the servers are out of reach says so, leaves no half account, and the button works again',('could not be reached' in st[1]) and r==[False,False,False,'Create account','out'],[st,r])
            # ---- two people racing for one name: the older key box wins, the other withdraws
            r=await d2.evaluate("async()=>{const a=await twaSignUp('Race_1','first one here',true);await twaSignOut(false);return !!a.ok}")
            await d1.wait_for_timeout(1200)
            r2=await d1.evaluate("""async()=>{const f=twaFindBoxes;let n=0;twaFindBoxes=async function(u){n++;if(n===1)return{ok:1,n:2,evs:[]};return f(u)};let x;try{x=await twaSignUp('Race_1','second one here',true)}finally{twaFindBoxes=f}
              const b=await twaFindBoxes('race_1');return [x.err||'',!!twaLoadSes(),b.evs.length,await twaNameFree('race_1')]}""")
            await idle(d2);await d2.evaluate("()=>{twaClose()}");await form(d2,'in');await d2.fill('#twau','race_1');await d2.fill('#twap','first one here');await d2.click('#twago');st=await done(d2)
            r3=await d2.evaluate("()=>{const s=twaLoadSes();return s?s.d:null}")
            chk('two people creating the same name at once: the later one is told to pick another and withdraws; the first keeps the account',r and 'moment ago' in r2[0] and r2[1:]==[False,1,False] and r3=='Race_1',[r,r2,st,r3])
            await idle(d2);await d2.evaluate("async()=>{await twaSignOut(false);twaClose()}")
            # ---- keys typed in the window never reach the game
            await form(d1);await d1.evaluate("()=>{window.__keys=0;window.addEventListener('keydown',()=>__keys++)}")
            await d1.click('#twau');await d1.keyboard.type('Abc 1 qwe');await d1.keyboard.press('Escape')
            r=await d1.evaluate("()=>[__keys,!!$('twa'),S.mode]")
            chk('keys typed in the account window never reach the game; Esc closes it',r==[0,False,'title'],r)
            # ---- the pop-up
            c4,d4,e4=await device(br);allerr.append(e4)
            await d4.evaluate("()=>{localStorage.removeItem('typeWarriorsNudge');P.runs=0;P.xp=0;title()}");await d4.wait_for_timeout(1700)
            r=[await d4.evaluate("()=>!!$('twa')")]
            await d4.evaluate("()=>{P.runs=1;save();title()}");await d4.wait_for_timeout(1700)
            r.append(await d4.evaluate("()=>[!!document.querySelector('#twa .twanudge'),!!document.querySelector('#twa .twatabs'),/Save your progress/.test($('twa').textContent),document.activeElement&&document.activeElement.id]"))
            chk('a brand-new player sees no pop-up; after the first game, back on the home screen, "Save your progress" opens with the account form and the name field focused',r==[False,[True,False,True,'twau']],r)
            await d4.screenshot(path=os.path.join(HERE,'shots','acct_nudge.png'))
            await d4.click('#twanlater');await d4.evaluate("()=>{title()}");await d4.wait_for_timeout(1700)
            r=[await d4.evaluate("()=>[!!$('twa'),JSON.parse(localStorage.getItem('typeWarriorsNudge'))]")]
            await d4.evaluate("()=>{P.runs=6;save();title()}");await d4.wait_for_timeout(1700);r.append(await d4.evaluate("()=>!!document.querySelector('#twa .twanudge')"))
            chk('"Later" closes it; it comes back after five more games',r[0][0]==False and r[0][1]['next']==6 and r[1]==True,r)
            await d4.click('.twax');await d4.evaluate("()=>{P.runs=100;save();title()}");await d4.wait_for_timeout(1700)
            r=[await d4.evaluate("()=>[!!document.querySelector('#twa .twanudge'),JSON.parse(localStorage.getItem('typeWarriorsNudge')).n]")]
            await d4.evaluate("()=>{twaClose();P.runs=1000;title()}");await d4.wait_for_timeout(1700);r.append(await d4.evaluate("()=>!!$('twa')"))
            chk('closing it counts as Later, and it shows at most three times in all',r==[[True,3],False],r)
            await d4.evaluate("()=>{localStorage.removeItem('typeWarriorsNudge');title()}");await d4.wait_for_timeout(1700);await d4.click('#twannever')
            await d4.evaluate("()=>{P.runs=5000;title()}");await d4.wait_for_timeout(1700)
            r=await d4.evaluate("()=>[!!$('twa'),JSON.parse(localStorage.getItem('typeWarriorsNudge')).never]")
            chk('"Don\'t ask again" stops it for good',r==[False,1],r)
            await d4.evaluate("()=>{localStorage.removeItem('typeWarriorsNudge');sgModal({title:'Something else',html:'<p>x</p>',buttons:[{t:'OK',v:1}]});title()}");await d4.wait_for_timeout(1700)
            r=await d4.evaluate("()=>[!!$('svm'),!!$('twa')]")
            chk('it never opens on top of another window',r==[True,False],r)
            await d4.evaluate("()=>{const m=$('svm');if(m)m.remove();localStorage.removeItem('typeWarriorsNudge');title();dkSheet('tstsheet','<p>sheet</p>')}");await d4.wait_for_timeout(1700)
            r=await d4.evaluate("()=>[!!document.querySelector('.dks'),!!$('twa')]")
            chk('nor over a menu sheet on the home screen',r==[True,False],r)
            await d4.evaluate("()=>{const s=document.querySelector('.dks');if(s&&s._close)s._close()}");await d4.wait_for_timeout(300)
            await d4.evaluate("()=>{const m=$('svm');if(m)m.remove();localStorage.removeItem('typeWarriorsNudge');title()}");await d4.wait_for_timeout(1700)
            await d4.click('#twanin');r=await d4.evaluate("()=>[!!document.querySelector('#twa .twanudge'),document.querySelector('.twatabs .on').dataset.t]")
            chk('"I already have an account" switches to Sign in',r==[False,'in'],r)
            await d4.evaluate("()=>{twaClose();localStorage.removeItem('typeWarriorsNudge');title()}");await d4.wait_for_timeout(1700)
            await d4.fill('#twau','Nudge_1');await d4.fill('#twap','from the popup');await d4.click('#twago');st=await done(d4)
            r=[await d4.evaluate("()=>[!!$('twacode'),!!twaLoadSes()]")];await d4.click('#twadl');await d4.click('#twagood')
            await idle(d4);await d4.evaluate("()=>{twaClose();localStorage.removeItem('typeWarriorsNudge');P.runs=9000;title()}");await d4.wait_for_timeout(1700)
            r.append(await d4.evaluate("()=>[!!$('twa'),$('twachip').className!=='out']"))
            chk('creating the account from the pop-up works (recovery code, signed in), and a signed-in player never sees it again',r==[[True,True],[False,True]],[st,r])
            # ---- under automation without the test flag, it stays away
            c5,d5,e5=await device(br,nudge=False);allerr.append(e5)
            await d5.evaluate("()=>{localStorage.removeItem('typeWarriorsNudge');P.runs=3;title()}");await d5.wait_for_timeout(1700)
            r=await d5.evaluate("()=>!!$('twa')")
            chk('under browser automation (other tests) the pop-up stays away unless asked for',r==False,r)
            # ---- 9.9n: the Sign in chip sits in the header row beside the profile, never on top of it
            r=await d5.evaluate("""()=>{const out=[];for(const g of [0,341,123456789]){P.gold=g;P.name=g>1e6?'Sir Longname the Brave':'Hero';title();const c=$('twachip').getBoundingClientRect(),h=ov.querySelector('.dkst0').getBoundingClientRect(),l=ov.querySelector('.dklogo').getBoundingClientRect();out.push(c.right<=h.left-6&&c.left>=l.right)}return out}""")
            chk('9.9n: the Sign in chip never overlaps the profile, whatever the gold or hero name',all(r),r)
            errs=[x for e in allerr for x in e]
            chk('no page errors on any device',not errs,errs[:4])
            await br.close()
    finally:
        for pr in procs:pr.terminate()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
