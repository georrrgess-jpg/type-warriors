/* ---------- the vault dragon: body, shoulders, arms, claws, arch and the vault itself ---------- */
const VARCH={cx:VX,cy:626,rx:520,ry:240};            /* top of the vault arch sits at y = cy - ry = 428 */
/* neck and chest with pale throat scutes */
const vBodyR=[0,140, 92,166, 124,226, 160,282, 214,312, 262,350, 262,414, 224,470, 0,520];
function vBodyPath(g){cdCR(g,vSym(vBodyR),true)}
function vBodyLayer(){return cdLayer(VX-300,100,600,460,g=>{g.translate(VX,0);
 vPaint(g,vBodyPath,[-300,100,300,560],{fill:hgr(g,-270,270,'#d8962a','#8a4c12'),s:20,seed:3,sh:46,shb:50,hl:14,hlb:24,fire:14,
  form:[[-130,260,170,'rgba(255,228,140,.28)'],[200,300,150,'rgba(30,4,0,.5)'],[0,480,160,'rgba(255,110,30,.3)']]});
 g.save();g.beginPath();vBodyPath(g);g.clip();
 for(let y=500;y>=176;y-=19){const w=40+(y-176)*.2,h=24;
  const pl=gg=>{gg.moveTo(-w,y-h);gg.quadraticCurveTo(0,y-h-5,w,y-h);gg.lineTo(w*1.02,y-4);gg.quadraticCurveTo(0,y+h*.62,-w*1.02,y-4);gg.closePath()};
  g.beginPath();pl(g);g.fillStyle=vgr(g,y-h,y+8,'#fff2b8','#d8a040');g.fill();g.lineWidth=2.4;g.strokeStyle='rgba(96,46,4,.85)';g.stroke();
  g.beginPath();g.moveTo(-w+6,y-h+5);g.quadraticCurveTo(0,y-h,w-6,y-h+5);g.lineWidth=2;g.strokeStyle='rgba(255,252,214,.7)';g.stroke()}
 vForm(g,vBodyPath,[[-30,300,120,'rgba(255,240,170,.22)'],[70,330,100,'rgba(40,6,0,.3)']]);
 g.restore();
 cdIn(g,vBodyPath,'rgba(24,4,0,.9)',0,0,26);
 g.save();g.beginPath();vBodyPath(g);g.lineJoin='round';g.lineWidth=5;g.strokeStyle='#190601';g.stroke();g.restore();
})}
/* shoulder mass and foreshortened forearm; s = +1 right, -1 left */
function vArmLayer(s){const cx=VX+s*232,cy=348;
 return cdLayer(cx-130,250,260,270,g=>{
  g.translate(cx,cy);
  const sh=gg=>cdCR(gg,vsg([0,-76, 62,-60, 100,-10, 90,52, 36,86, -30,80, -70,40, -84,-22],s),true);
  vPaint(g,sh,[-120,-100,120,110],{fill:rgr(g,-s*20,-30,6,150,'#f8cc56','#80440e'),s:17,seed:41+s,sh:32,shb:34,hl:11,hlb:18,fire:12,
   form:[[-s*30,-40,80,'rgba(255,244,180,.38)'],[s*50,50,70,'rgba(34,4,0,.4)']]});
  /* forearm reaching down to the arch */
  const arm=gg=>cdCR(gg,vsg([34,34, 54,76, 58,112, 34,142, -4,150, -34,132, -46,96, -36,50, -10,20],s),true);
  vPaint(g,arm,[-70,0,90,170],{fill:hgr(g,-50*s,60*s,'#f2c04c','#8a4c12'),s:15,seed:47+s,sh:20,shb:22,hl:8,hlb:12,fire:10,
   form:[[-s*10,60,50,'rgba(255,244,180,.3)']]});
  /* armour ridge */
  poly(g,vsg([-6,60,24,52,44,84,22,112,-12,98],s),hgr(g,-10,50,'#f6cc58','#a8641a'),'#190601',3.2);
 })}
/* a finger gripping the arch: drawn pointing down from its base at (0,0) */
function vFingerLayer(w,len,seed){return cdLayer(-40,-12,80,len+90,g=>{
 const fp=gg=>{gg.moveTo(-w/2,0);gg.lineTo(-w*.44,len);gg.quadraticCurveTo(0,len+10,w*.44,len);gg.lineTo(w/2,0);gg.closePath()};
 vPaint(g,fp,[-w,0,w,len+10],{fill:hgr(g,-w/2,w/2,'#f6c850','#a45e14'),s:9,seed:seed,sh:8,shb:9,hl:4,hlb:6,fire:5,ol:3.6});
 g.beginPath();g.arc(0,len*.42,w*.3,0,TAU);g.fillStyle='rgba(255,236,150,.4)';g.fill();
 cdHorn(g,[-w*.34,len-6,-w*.38,len+20,-w*.18,len+44,w*.26,len+60],[w*.34,len-6,w*.42,len+18,w*.36,len+40,w*.26,len+60],12,'#f6ecc8','#b09050',3.8)})}
/* palm that sits on the rim */
function vPalmLayer(s){return cdLayer(VX+s*238-80,362,160,90,g=>{g.translate(VX+s*238,406);
 const p=gg=>cdCR(gg,[-66,-6,-52,-34,0,-42,52,-34,66,-6,56,20,0,28,-56,20],true);
 vPaint(g,p,[-70,-50,70,36],{fill:hgr(g,-60,60,'#f6c850','#9a5812'),s:11,seed:57+s,sh:12,shb:14,hl:5,hlb:8,fire:6,ol:4});
})}
/* ----- the vault arch: stone, riveted gold band, ruby keystone ----- */
function vArchLayer(){const A=VARCH;return cdLayer(0,380,1600,520,g=>{
 const top=gg=>{gg.ellipse(A.cx,A.cy,A.rx,A.ry,0,Math.PI,TAU)};
 const face=gg=>{gg.moveTo(A.cx-A.rx,900);gg.lineTo(A.cx-A.rx,A.cy);top(gg);gg.lineTo(A.cx+A.rx,900);gg.closePath()};
 /* door face */
 g.beginPath();face(g);{const q=g.createLinearGradient(0,A.cy-A.ry,0,600);q.addColorStop(0,'#4a1428');q.addColorStop(1,'#0d0510');g.fillStyle=q}g.fill();
 g.save();g.beginPath();face(g);g.clip();
 for(const k of[.9,.8,.7]){g.beginPath();g.ellipse(A.cx,A.cy,A.rx*k,A.ry*k,0,Math.PI,TAU);g.lineWidth=2;g.strokeStyle='rgba(240,184,56,'+(.12+.3*(k-.7))+')';g.stroke()}
 for(let i=-14;i<=14;i++){const x=A.cx+i*36,u=(x-A.cx)/A.rx,y=A.cy-A.ry*Math.sqrt(Math.max(0,1-u*u))+60;if(Math.abs(u)>.95)continue;g.beginPath();g.arc(x,y,4.2,0,TAU);g.fillStyle=rgr(g,x-1,y-1,0,6,'#ffe9a0','#8a5010');g.fill()}
 g.restore();
 /* stone surround and gold band */
 const ring=(w,st)=>{g.beginPath();top(g);g.lineWidth=w;g.strokeStyle=st;g.lineCap='butt';g.stroke()};
 ring(76,'#1a0a14');ring(66,vgr(g,A.cy-A.ry-40,A.cy,'#6a4a52','#2a1620'));
 /* voussoir joints */
 for(let i=-18;i<=18;i++){const a=Math.PI*1.5+i*.088,x=A.cx+Math.cos(a)*A.rx,y=A.cy+Math.sin(a)*A.ry,nx=Math.cos(a)/A.rx,ny=Math.sin(a)/A.ry,L=Math.hypot(nx,ny);
  g.beginPath();g.moveTo(x-nx/L*30,y-ny/L*30);g.lineTo(x+nx/L*34,y+ny/L*34);g.lineWidth=3;g.strokeStyle='rgba(10,2,8,.7)';g.stroke()}
 ring(34,'#190601');
 g.save();g.beginPath();top(g);g.lineWidth=28;g.strokeStyle=vgr(g,A.cy-A.ry-14,A.cy-A.ry+60,'#fff0a0','#b87414');g.stroke();g.restore();
 g.beginPath();top(g);g.lineWidth=3;g.strokeStyle='rgba(255,255,230,.7)';g.save();g.translate(0,-9);g.stroke();g.restore();
 g.beginPath();top(g);g.lineWidth=2.5;g.strokeStyle='rgba(90,40,0,.8)';g.save();g.translate(0,10);g.stroke();g.restore();
 /* rivets */
 for(let i=-24;i<=24;i++){const a=Math.PI*1.5+i*.0585,x=A.cx+Math.cos(a)*A.rx,y=A.cy+Math.sin(a)*A.ry;g.beginPath();g.arc(x,y,5,0,TAU);g.fillStyle=rgr(g,x-1.5,y-1.5,0,7,'#fff6c0','#8a5010');g.fill();g.lineWidth=1.4;g.strokeStyle='#190601';g.stroke()}
 /* ruby keystone */
 const kx=A.cx,ky=A.cy-A.ry+12;
 g.beginPath();g.moveTo(kx-34,ky-24);g.lineTo(kx+34,ky-24);g.lineTo(kx+44,ky+30);g.lineTo(kx,ky+52);g.lineTo(kx-44,ky+30);g.closePath();g.fillStyle=hgr(g,kx-44,kx+44,'#fff0a0','#b87414');g.fill();g.lineWidth=4;g.strokeStyle='#190601';g.stroke();
 cdGem(g,kx,ky+10,22,'#e8142e',8);
})}
/* ----- the vault: stone hall, big centre arch, pillars, banners, torch brackets ----- */
const VTORCH=[[596,308],[1548,308]];
function vBack(g){
 g.fillStyle='#0d0510';g.fillRect(0,0,1600,900);
 /* far wall in deep plum with a warm bloom behind the dragon */
 g.fillStyle=rgr(g,VX,230,30,980,'#6a2616','#14060e');g.fillRect(0,0,1600,620);
 g.fillStyle=rgr(g,300,120,10,640,'#2e0e22','#14060e00');g.fillRect(0,0,1600,620);
 /* stone courses */
 g.save();g.globalAlpha=.6;for(let row=0;row<12;row++){const y=row*50-14,off=(row&1)*65;for(let x=-130+off;x<1700;x+=130){const r=rnd(row*31+x*.07),l=r*.12;
  g.fillStyle='rgba('+(66+l*200|0)+','+(26+l*70|0)+','+(40+l*70|0)+','+(.3+r*.2)+')';g.fillRect(x+2,y+2,126,46);
  g.strokeStyle='#08010a99';g.lineWidth=3;g.strokeRect(x+2,y+2,126,46)}}g.restore();
 /* the great central arch behind the dragon, a glowing hollow */
 const hall=gg=>{gg.moveTo(VX-430,620);gg.lineTo(VX-430,210);gg.ellipse(VX,210,430,250,0,Math.PI,TAU);gg.lineTo(VX+430,620);gg.closePath()};
 g.beginPath();hall(g);g.fillStyle=rgr(g,VX,230,20,520,'#ff8a2a','#3a0e14');g.fill();
 g.save();g.beginPath();hall(g);g.clip();
 g.fillStyle=rgr(g,VX,260,10,380,'#ffd070aa','#ff7a2000');g.fillRect(VX-440,-60,880,700);
 for(let i=0;i<7;i++){g.beginPath();g.moveTo(VX-430+i*20,620);g.lineTo(VX-300+i*40,-60);g.strokeStyle='rgba(255,170,80,.05)';g.lineWidth=14;g.stroke()}
 cdIn(g,hall,'rgba(12,2,10,.95)',0,0,60);g.restore();
 g.beginPath();hall(g);g.lineWidth=40;g.strokeStyle='#241018';g.stroke();g.lineWidth=36;g.strokeStyle=vgr(g,-40,260,'#5a3a40','#2a1620');g.stroke();
 g.save();g.beginPath();hall(g);g.lineWidth=36;g.strokeStyle='#08010a';g.setLineDash([3,56]);g.stroke();g.restore();
 g.beginPath();hall(g);g.lineWidth=3;g.strokeStyle='rgba(240,184,56,.5)';g.stroke();
 /* outer pillars carrying crimson banners */
 for(const px of[596,1548]){const w=96;
  g.fillStyle=hgr(g,px-w/2,px+w/2,'#4a2c36','#150810');g.fillRect(px-w/2,0,w,620);
  g.fillStyle=hgr(g,px-w/2,px+w/2,'#ffffff14','#00000070');g.fillRect(px-w/2,0,w,620);
  for(let y=-8;y<620;y+=64){g.fillStyle='#00000050';g.fillRect(px-w/2,y,w,4);g.fillStyle='#ffffff12';g.fillRect(px-w/2,y+4,w,2)}
  g.fillStyle='#2a1420';g.fillRect(px-w/2-8,0,w+16,24);g.fillStyle='#8a5a38';g.fillRect(px-w/2-8,22,w+16,5);
  g.fillStyle='#caa030';g.fillRect(px-36,26,72,6);
  g.beginPath();g.moveTo(px-30,32);g.lineTo(px+30,32);g.lineTo(px+30,226);g.lineTo(px,250);g.lineTo(px-30,226);g.closePath();
  g.fillStyle=hgr(g,px-30,px+30,'#9a1430','#5a0a1c');g.fill();g.lineWidth=4;g.strokeStyle='#e8b030';g.stroke();
  g.beginPath();g.moveTo(px-23,42);g.lineTo(px+23,42);g.lineTo(px+23,218);g.lineTo(px,236);g.lineTo(px-23,218);g.closePath();g.lineWidth=1.4;g.strokeStyle='#f0b83888';g.stroke();
  cdSigil(g,px,128,.82)}
 /* torch brackets */
 for(const t of VTORCH){g.fillStyle='#2a1a14';g.strokeStyle='#08010a';g.lineWidth=3;g.beginPath();g.rect(t[0]-6,t[1]-5,12,36);g.fill();g.stroke();
  g.beginPath();g.moveTo(t[0]-17,t[1]-18);g.lineTo(t[0]+17,t[1]-18);g.lineTo(t[0]+10,t[1]+26);g.lineTo(t[0]-10,t[1]+26);g.closePath();g.fillStyle=hgr(g,t[0]-17,t[0]+17,'#8a6a40','#3a2410');g.fill();g.stroke();
  g.beginPath();g.ellipse(t[0],t[1]-18,17,5,0,0,TAU);g.fillStyle='#ff9a30';g.fill();g.stroke()}
 /* floor, calm and dark under the controls */
 g.fillStyle=vgr(g,380,560,'#0d051000','#0d0510f2');g.fillRect(0,380,1600,520);
 g.fillStyle='#0d0510f2';g.fillRect(0,560,1600,340);
 g.fillStyle=rgr(g,VX,640,10,560,'#ffa04022','#ffa04000');g.fillRect(0,430,1600,470);
}
/* hoards: coin piles that spill against the arch ends, plus loose coins and gems */
function vPiles(g){g.save();
 cdPile(g,790,512,250,92,7,140,8);cdPile(g,1490,522,360,130,19,200,10);cdPile(g,1330,530,200,60,29,90,5);cdPile(g,900,540,160,36,33,50,3);
 const gl=['#e8203c','#2ad07a','#3a8ae8','#b04ae8','#ffd040','#e8203c'];
 for(let i=0;i<22;i++){const x=700+rnd(i*3.1)*820,y=466+rnd(i*5.7)*34;if(x>840&&x<1330)continue;i%3?cdCoin(g,x,y,9+rnd(i)*5,i):cdGem(g,x,y,8+rnd(i*2)*5,gl[i%gl.length],i)}
 g.restore();g.save();g.globalCompositeOperation='destination-out';{const q=g.createLinearGradient(0,486,0,560);q.addColorStop(0,'rgba(0,0,0,0)');q.addColorStop(1,'rgba(0,0,0,1)');g.fillStyle=q;g.fillRect(0,480,1600,120)}g.restore()}
