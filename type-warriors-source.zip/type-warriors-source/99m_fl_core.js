/* ===== UPDATE 10.4, THE HARVEST FESTIVAL: shared definitions (99m, prefix fl) =====
   One place for the festival's dates, ids, names and prices, so the chest (99o, flc), the gear (99n, flg), the companions (99p, flp),
   the festival hub (99q, fle) and Harvest Moon Rush (99r, flr) agree. UPDATE_10_4_PLAN.md has the full plan.
   Dates are local time like the Halloween event (84c HW_END): the festival is on from 6 November 2026 until the end of 1 December 2026;
   Thanksgiving is 26 November 2026. window.FL_FORCE = 1 / -1 forces the festival on / off (tests, DEV). */
const FL={start:new Date(2026,10,6).getTime(),end:new Date(2026,11,2).getTime(),thanks:new Date(2026,10,26).getTime(),
 grace:7*864e5,/* acorns stay spendable this long after the end */
 price:{a:100000,w:100000,b:175000},/* the two Mythic relics in the shop, like HW_PRICE */
 chest:{key:'f',cnt:'fcr',n:'Harvest Chest'},
 gear:{a:['flsmock','florch','flmaple','flcorn','flmoon','flfeast'],w:['fl_fork','fl_pin','fl_maple','fl_acorn','fl_glaive','fl_horn']},
 gearN:{flsmock:'Harvest Smock',florch:"Orchard Keeper's Vest",flmaple:'Maplewarden Mail',flcorn:'Cornstalk Sentinel',flmoon:'Harvest Moon Regalia',flfeast:"Feastlord's Aegis",
  fl_fork:'Hayfork',fl_pin:"Baker's Rolling Pin",fl_maple:'Maple Longbow',fl_acorn:'Acorn Flail',fl_glaive:'Cranberry Glaive',fl_horn:'Horn of Plenty'},
 rar:['Common','Uncommon','Rare','Epic','Legendary','Mythic'],
 pets:{r:'flsquir',l:'flfox',m:'flturkey'},
 petN:{flsquir:'Acorn Scamp',flfox:'Emberleaf',flturkey:'Thunderplume'},
 ab:{k:'bounty',n:'Bountiful Harvest'},
 cur:{k:'ac',n:'Acorns',one:'acorn'}};
const flNow=()=>Date.now();
const flOn=()=>{const f=window.FL_FORCE;if(f===1)return true;if(f===-1)return false;const n=flNow();return n>=FL.start&&n<FL.end};
/* the market stays open for leftover acorns a week after the festival */
const flShopOn=()=>{const f=window.FL_FORCE;if(f===1)return true;if(f===-1)return false;const n=flNow();return n>=FL.start&&n<FL.end+FL.grace};
function flLeft(){const ms=FL.end-flNow();if(ms<=0)return'The harvest is in';const d=Math.floor(ms/864e5),h=Math.floor(ms%864e5/36e5);
 return d>=2?d+' days left':d===1?'1 day left':h>=1?h+' hours left':'Ending soon'}
