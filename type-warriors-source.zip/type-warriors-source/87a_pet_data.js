/* ===== COMPANIONS & EGGS: data and progression =====
   Two rarities (Rare / Legendary), four art families. One companion is equipped; its power works in Campaign and standard Endless.
   Saved fields: P.pets {id:{b:bondXP,nk,pal,acc,trim,t}}, P.pet (equipped id), P.eggs {r,l}, P.trail {n,c}, P.petSt (starter: 0 none, 1 ready to choose, 2 done),
   P.petPend (a committed hatch not yet revealed), P.petNew {id:1} (unseen), P.petBuy (merchant purchases). */
const PDEF={
 bramble:{n:'Bramblekin',r:'r',fam:'Woodland',box:[-62,-84,136,88],ab:{k:'leafguard',n:'Leafguard',N:30,cap:2,d:'Every 30 correct words, prepare a leaf shield that blocks one hit.',x:'Up to 2 blocks per run. Your own shields are used first.'},
  bio:'A sturdy little tortoise who tucks in at the first sign of danger.',cos:{acc:'Blossom garland',pal:'Autumn',cel:'Leaf shower',sig:'Elder Grove'},greet:'peeks out of its shell'},
 mosskip:{n:'Mosskip',r:'r',fam:'Woodland',box:[-50,-110,96,112],ab:{k:'scholar',n:'Trail Scholar',d:'Earn 5% more XP from every run.',x:'Added once at the end of a run.'},
  bio:'A curious hare that sniffs out every lesson on the trail.',cos:{acc:'Explorer scarf',pal:'Frost',cel:'Leaf trail',sig:'Spirit Bloom'},greet:'hops up to say hello'},
 antler:{n:'Antlerlight',r:'l',fam:'Woodland',box:[-50,-120,96,124],ab:{k:'heartgrove',n:'Heartgrove',N:30,cap:2,d:'Every 30 correct words, restore one missing heart.',x:'Up to 2 heals per run. Waits until you are hurt.'},
  bio:'A gentle fawn whose golden antlers glow with forest light.',cos:{acc:'Flower crown',pal:'Dawn-Rose',cel:'Heartbloom',sig:'Starlit Antlers'},greet:'bows with a soft glow'},
 lily:{n:'Lilyhop',r:'r',fam:'Woodland',nw:1,box:[-40,-76,90,80],ab:{k:'calm',n:'Calm Pond',d:'Typos no longer drain your Fury.',x:'Accuracy still counts every typo.'},
  bio:'A pond frog in a lily-pad hat. Nothing ruffles it, not even a slip of the finger.',cos:{acc:'Dew pearls',pal:'Golden',cel:'Splash',sig:'Moonlit Lotus'},greet:'leaps and blinks happily'},
 cinder:{n:'Cindernewt',r:'r',fam:'Forge',box:[-66,-74,124,78],ab:{k:'embertag',n:'Ember Tag',N:20,d:'Every 20 correct words, slow the nearest monster by 25% for 3 seconds.',x:'Bosses are immune. Waits for a target.'},
  bio:'A warm little salamander with a candle-flame tail.',cos:{acc:'Forge goggles',pal:'Bluefire',cel:'Flame flare',sig:'Magma Veins'},greet:'puffs a happy flame'},
 beetle:{n:'Forgebeetle',r:'r',fam:'Forge',box:[-46,-70,96,74],ab:{k:'gilded',n:'Gilded Gatherer',d:'Earn 5% more gold from combat.',x:'Not casino winnings or rewards.'},
  bio:'A diligent iron beetle that polishes every coin it finds.',cos:{acc:'Tiny banner',pal:'Silverwork',cel:'Coin polish',sig:'Treasure Hoard'},greet:'rears up proudly'},
 ember:{n:'Embercrest',r:'l',fam:'Forge',box:[-62,-110,124,114],ab:{k:'sweep',n:'Cinder Sweep',N:30,d:'Every 30 correct words, burn away monster projectiles and push monsters back.',x:'Bosses are immune. Waits for a target.'},
  bio:'A gryphon hatchling with wings of living flame.',cos:{acc:'Ember circlet',pal:'Royal',cel:'Wing flourish',sig:'Phoenix Plumes'},greet:'stretches its fiery wings'},
 tick:{n:'Tickpip',r:'r',fam:'Forge',nw:1,box:[-44,-96,86,100],ab:{k:'second',n:'Second Hand',d:'Each new boss sentence gets 20% more time.',x:'Up to 3 sentences per boss.'},
  bio:'A clockwork owl that winds itself up and never misses a tick.',cos:{acc:'Top hat',pal:'Steelwork',cel:'Chime',sig:'Grand Orrery'},greet:'flaps its gear wings and hoots'},
 gloom:{n:'Gloombat',r:'r',fam:'Moonlit',hover:1,box:[-58,-106,116,100],ab:{k:'echo',n:'Echo Veil',N:25,d:'Every 25 correct words, slow monster projectiles by 30% for 3 seconds.',x:'Projectiles only. Waits until one is in the air.'},
  bio:'A friendly cousin of the Cave Bat that hums in the dark.',cos:{acc:'Moon charm',pal:'Silver Eclipse',cel:'Sonar song',sig:'Eclipse Wings'},greet:'unfurls its wings'},
 wisp:{n:'Wickwisp',r:'r',fam:'Moonlit',hover:1,box:[-30,-128,62,124],ab:{k:'lantern',n:'Last Lantern',d:'Once per run, when a hit leaves you at 1 heart, restore 1 heart.',x:'Cannot save you from a fatal hit.'},
  bio:'A shy spirit that keeps a light burning when hope runs low.',cos:{acc:'Star ribbon',pal:'Silver Lantern',cel:'Lantern glow',sig:'Stained-Glass Lantern'},greet:'lights its lantern'},
 noct:{n:'Nocturne',r:'l',fam:'Moonlit',box:[-80,-110,140,114],ab:{k:'moonbind',n:'Moonbind',N:25,d:'Every 25 correct words, bind the nearest monster in place for 2 seconds.',x:'Freezes its attack too. Bosses are immune.'},
  bio:'A tiny lynx made of midnight, with a comet for a tail.',cos:{acc:'Constellations',pal:'Dusk',cel:'Crescent pounce',sig:'Nebula Coat'},greet:'stretches and purrs'},
 crab:{n:'Pebblecrab',r:'r',fam:'Astral',box:[-42,-84,96,88],ab:{k:'catch',n:'Crystal Catch',d:'Each wave, block the first monster projectile that would hit you.',x:'Not boss attacks or melee hits.'},
  bio:'A stone hermit crab wearing a geode it found under a mountain.',cos:{acc:'Crystal crown',pal:'Rose Geode',cel:'Claw wave',sig:'Amethyst Spire'},greet:'waves both claws'},
 quill:{n:'Quillfin',r:'r',fam:'Astral',hover:1,box:[-62,-106,100,92],ab:{k:'inkflow',n:'Inkflow',d:'Earn 10% more Fury from typing.',x:'Added to your normal Fury gain.'},
  bio:'A little fish who writes flourishes in the water with its tail.',cos:{acc:"Captain's hat",pal:'Lagoon',cel:'Ink flourish',sig:'Ink Galaxy'},greet:'winks from its bubble'},
 starcoil:{n:'Starcoil',r:'l',fam:'Astral',hover:1,box:[-60,-124,112,100],ab:{k:'reservoir',n:'Astral Reservoir',N:30,d:'Every 30 correct words, gain 20 Fury.',x:'Never overflows. Waits until there is room.'},
  bio:'A miniature skywyrm carrying a fallen star on its tail.',cos:{acc:'Comet ribbon',pal:'Aurora',cel:'Star coil',sig:'Constellation Scales'},greet:'uncoils with a twinkle'},
 prism:{n:'Prismkit',r:'l',fam:'Astral',nw:1,box:[-76,-100,130,104],ab:{k:'prism',n:'Prism Sight',N:35,d:'Every 35 correct words, the next monster to appear is Shiny.',x:'Shiny monsters pay 5× gold and can drop rare loot.'},
  bio:'A crystal fox whose tail splits moonlight into rainbows.',cos:{acc:'Ribbon charm',pal:'Dusk Prism',cel:'Rainbow fan',sig:'Rainbow Facets'},greet:'fans a rainbow with its tail'}
};
const PIDS=Object.keys(PDEF),PSTART=['bramble','cinder','mosskip'];
const PRAR={r:{n:'Rare',c:'#5ab8ff',egg:'Runeshell'},l:{n:'Legendary',c:'#ffc23a',egg:'Crownheart'}};
const PFAM={Woodland:'#7ad04a',Forge:'#ff8a3a',Moonlit:'#b07aff',Astral:'#5ad8ff'};
const PEGG_PRICE={r:2000,l:10000};
const PBOND_MAX=10,PBOND_STEP=100;
/* bond thresholds: quick early unlocks, a long road to Signature. Every value is at or below the old 100-per-level curve, so no saved pet ever loses a level */
const PBOND_T=[0,30,70,120,190,280,390,520,690,900];
const PTRAIL=20,PTRAIL_EGG={5:'r',10:'r',15:'r',20:'l'};

/* ---------- save ---------- */
function petNorm(){if(!P)return;if(!P.pets||typeof P.pets!=='object'||Array.isArray(P.pets))P.pets={};
 for(const k of Object.keys(P.pets)){if(!PDEF[k])continue;/* unknown companions stay in the save untouched */const p=P.pets[k];if(!p||typeof p!=='object'){P.pets[k]={b:0};continue}p.b=Math.max(0,Math.min(PBOND_T[9],+p.b||0));p.adv=Math.max(0,p.adv|0);p.used=Math.max(0,p.used|0);if(typeof p.nk!=='string')p.nk='';p.nk=p.nk.slice(0,16);p.pal=p.pal?1:0;p.acc=p.acc?1:0;p.trim=p.trim?1:0;p.cel=p.cel?1:0}
 if(typeof P.pet!=='string'||!P.pets[P.pet])P.pet='';
 if(!P.eggs||typeof P.eggs!=='object')P.eggs={r:0,l:0,m:0};P.eggs.r=Math.max(0,P.eggs.r|0);P.eggs.l=Math.max(0,P.eggs.l|0);P.eggs.m=Math.max(0,P.eggs.m|0);
 if(!P.trail||typeof P.trail!=='object')P.trail={n:0,c:0};P.trail.n=Math.max(0,Math.min(PTRAIL-1,P.trail.n|0));P.trail.c=Math.max(0,P.trail.c|0);
 P.petSt=[0,1,2].includes(P.petSt)?P.petSt:(Object.keys(P.pets).length?2:0);
 /* a starter choice that can no longer be made (every starter already owned) is simply complete */if(P.petSt===1&&PSTART.every(id=>P.pets[id]&&typeof P.pets[id]==='object'))P.petSt=2;
 if(P.petPend&&(typeof P.petPend!=='object'||!PDEF[P.petPend.id]))P.petPend=null;if(P.petPend===undefined)P.petPend=null;
 if(!P.petNew||typeof P.petNew!=='object')P.petNew={};P.petBuy=P.petBuy|0;if(!P.petUnl||typeof P.petUnl!=='object')P.petUnl={};if(typeof P.trSeen!=='number')P.trSeen=-1}
{const l0=load;load=function(src){l0(src);petNorm()}}
petNorm();

/* ---------- queries ---------- */
const petOwned=id=>!!(P.pets&&P.pets[id]);
const petList=r=>PIDS.filter(id=>!r||(PDEF[id].r===r&&!PDEF[id].fl));/* egg pools: festival companions (fl, 99p) are never in an egg's pool */
const petPool=r=>petList(r).filter(id=>!petOwned(id));
const petLvB=b=>{let l=1;while(l<PBOND_MAX&&b>=PBOND_T[l])l++;return l};
const petLv=id=>{const p=P.pets[id];return p?petLvB(p.b||0):0};
const petXpIn=id=>{const p=P.pets[id];if(!p)return 0;const l=petLv(id);return l>=PBOND_MAX?1:(p.b||0)-PBOND_T[l-1]};
const petXpSpan=id=>{const l=petLv(id);return l>=PBOND_MAX?1:PBOND_T[l]-PBOND_T[l-1]};
const petXpPct=id=>Math.round(petXpIn(id)/petXpSpan(id)*100);
/* which style each bond level unlocks */
const PLV_UNL={3:'acc',5:'pal',7:'cel',10:'trim'};
const petName=id=>{const p=P.pets&&P.pets[id];return(p&&p.nk)||PDEF[id].n};
/* the cosmetic look a companion is wearing (only unlocked styles apply) */
function petLook(id){const p=P.pets[id]||{},lv=petLv(id);return{pal:lv>=5&&p.pal?1:0,acc:lv>=3&&p.acc?1:0,trim:lv>=10&&p.trim?1:0,cel:lv>=7&&p.cel?1:0}}
const petTotStamps=()=>P.trail.c*PTRAIL+P.trail.n;
const PUNL={acc:3,pal:5,cel:7,trim:10};
const petEggsN=()=>(P.eggs.r|0)+(P.eggs.l|0)+(P.eggs.m|0);
function petBondAdd(id,n){const p=P.pets[id];if(!p)return 0;const b0=p.b||0,l0=petLvB(b0);p.b=Math.min(PBOND_T[9],b0+n);const l1=petLvB(p.b);
 /* remember new styles so the hall can celebrate them */for(let l=l0+1;l<=l1;l++){if(PLV_UNL[l]){P.petUnl=P.petUnl||{};P.petUnl[id]=PLV_UNL[l]}P.petLvUp={id,lv:l1,k:PLV_UNL[l1]||null,t:Date.now()}}return p.b-b0}
const petMaxed=id=>petLv(id)>=PBOND_MAX;

/* ---------- Adventure Trail ---------- */
/* one stamp per finished qualifying activity; milestones award eggs once, overflow carries on */
function petStamp(kind){if(!P)return null;petNorm();const note={kind,eggs:[],starter:false,bond:0,pet:P.pet};
 if(P.petSt===0){P.petSt=1;note.starter=true}
 const n0=P.trail.n,n1=n0+1;for(let s=n0+1;s<=n1;s++){const e=PTRAIL_EGG[s];if(e){P.eggs[e]++;note.eggs.push(e)}}
 if(n1>=PTRAIL){P.trail.n=n1-PTRAIL;P.trail.c++;note.cycle=1}else P.trail.n=n1;note.n=n1>=PTRAIL?PTRAIL:n1;
 if(P.pet){const lv0=petLv(P.pet);note.bond=petBondAdd(P.pet,10);if(P.pets[P.pet])P.pets[P.pet].adv=(P.pets[P.pet].adv|0)+1;const lv1=petLv(P.pet);if(lv1>lv0)note.lvUp={id:P.pet,lv:lv1,k:PLV_UNL[lv1]||null}}
 P.petNote=note;save();return note}
const petNextEgg=()=>{const n=P.trail.n;for(let s=n+1;s<=PTRAIL;s++)if(PTRAIL_EGG[s])return{at:s,k:PTRAIL_EGG[s],left:s-n};return null};

/* ---------- hatching: the result is committed and saved before any animation plays ---------- */
function petHatch(k){petNorm();if(P.petSt===1)return null;/* the starter choice always comes first */if((P.eggs[k]|0)<=0)return null;const pool=petPool(k);if(!pool.length)return{full:true};
 const id=pool[Math.floor(Math.random()*pool.length)];P.eggs[k]--;P.pets[id]={b:0,nk:'',pal:0,acc:0,trim:0,cel:0,t:Date.now()};P.petNew[id]=1;if(!P.pet)P.pet=id;P.petPend={id,k};save();return{id}}
function petStarterPick(id){petNorm();if(P.petSt!==1||!PSTART.includes(id)||petOwned(id))return null;P.pets[id]={b:0,nk:'',pal:0,acc:0,trim:0,t:Date.now()};P.petSt=2;P.pet=id;P.petNew[id]=1;P.petPend={id,k:'r',st:1};save();return{id}}
/* once a tier is complete, an egg can become 50 bond XP for a chosen companion of that tier */
function petConvert(k,id){if((P.eggs[k]|0)<=0||!petOwned(id)||PDEF[id].r!==k||petMaxed(id)||petPool(k).length)return 0;P.eggs[k]--;const g=petBondAdd(id,50);save();return g}
function petBuy(k){const pr=PEGG_PRICE[k];if(!pr||P.gold<pr)return false;P.gold-=pr;P.eggs[k]++;P.petBuy++;save();return true}
function petEquip(id){if(!petOwned(id))return;P.pet=id;save()}
