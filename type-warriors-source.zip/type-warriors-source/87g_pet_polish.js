/* ===== PETS & EGGS POLISH: a sortable roster, and a calmer Eggs tab with one clear next step ===== */

/* ---------- roster sorting ---------- */
const PTSORT=[['col','Collection order','list','Collection'],['rec','Recommended','star','Recommended'],['rar','Rarity: highest first','cup','Rarity'],['bhi','Bond: highest first','up','Bond ↑'],['blo','Bond: lowest first','down','Bond ↓'],['az','Name A–Z','az','Name A–Z'],['new','Recently acquired','clock','Newest']];
const PTSI={list:'<svg viewBox="0 0 24 24"><path d="M8 6h13M8 12h13M8 18h13M3.5 6h.01M3.5 12h.01M3.5 18h.01" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" fill="none"/></svg>',
 star:'<svg viewBox="0 0 24 24"><path d="M12 2.5l2.9 6 6.6.8-4.9 4.6 1.3 6.6L12 17.3l-5.9 3.2 1.3-6.6L2.5 9.3l6.6-.8z" fill="currentColor"/></svg>',
 cup:'<svg viewBox="0 0 24 24"><path d="M7 3h10v5a5 5 0 0 1-10 0zM7 5H3c0 3 1.5 5 4 5.5M17 5h4c0 3-1.5 5-4 5.5M12 13v4M8 21h8M9.5 17h5" stroke="currentColor" stroke-width="2" fill="none" stroke-linejoin="round" stroke-linecap="round"/></svg>',
 up:'<svg viewBox="0 0 24 24"><path d="M12 20V5M6 11l6-6 6 6" stroke="currentColor" stroke-width="2.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>',
 down:'<svg viewBox="0 0 24 24"><path d="M12 4v15M6 13l6 6 6-6" stroke="currentColor" stroke-width="2.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>',
 az:'<svg viewBox="0 0 24 24"><path d="M4 18l3-9 3 9M5 15h4M14 9h6l-6 9h6M17 3v3" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>',
 clock:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="2.2" fill="none"/><path d="M12 7v5l3.5 2" stroke="currentColor" stroke-width="2.2" fill="none" stroke-linecap="round"/></svg>',
 sort:'<svg viewBox="0 0 24 24"><path d="M7 4v16M3.5 16.5L7 20l3.5-3.5M17 20V4M13.5 7.5L17 4l3.5 3.5" stroke="currentColor" stroke-width="2.2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>',
 chk:'<svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7" stroke="currentColor" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>'};
const ptSortKey=()=>PTSORT.some(s=>s[0]===P.petSort)?P.petSort:'col';
function ptSorted(L){const k=ptSortKey(),o=id=>petOwned(id),b=id=>(P.pets[id]&&P.pets[id].b)||0,r=id=>PDEF[id].r==='l'?1:0,ix=id=>PIDS.indexOf(id);
 const own=L.filter(o),un=L.filter(id=>!o(id));let f;
 if(k==='rec')f=(a,c)=>((P.petNew[c]?1:0)-(P.petNew[a]?1:0))||((P.pet===c)-(P.pet===a))||(b(c)-b(a))||(r(c)-r(a))||(ix(a)-ix(c));
 else if(k==='rar')f=(a,c)=>(r(c)-r(a))||(ix(a)-ix(c));
 else if(k==='bhi')f=(a,c)=>(b(c)-b(a))||(ix(a)-ix(c));
 else if(k==='blo')f=(a,c)=>(b(a)-b(c))||(ix(a)-ix(c));
 else if(k==='az')f=(a,c)=>petName(a).localeCompare(petName(c));
 else if(k==='new')f=(a,c)=>(((P.pets[c]||{}).t||0)-((P.pets[a]||{}).t||0))||(ix(a)-ix(c));
 if(k==='col')return L;
 return[...own.sort(f),...un.sort((a,c)=>(r(c)-r(a))||(ix(a)-ix(c)))]}

function ptPetsHTML(){const f=PTX.filt,L=ptSorted(PIDS.filter(id=>f==='all'||PDEF[id].r===f)),own=PIDS.filter(petOwned).length,sk=ptSortKey(),sn=PTSORT.find(s=>s[0]===sk)[3];
 const card=id=>{const o=petOwned(id),D=PDEF[id],eq=P.pet===id,nw=P.petNew[id],lv=o?petLv(id):0;return `<button class="ptc ptc-${D.r}${o?'':' unk'}${PTX.sel===id?' on':''}" data-p="${id}" aria-label="${o?esc(petName(id))+', bond level '+lv:'Undiscovered '+PRAR[D.r].n+' companion'}"><canvas width="132" height="112" data-pc="${id}"></canvas><span>${o?esc(petName(id)):'Undiscovered'}</span>${eq?`<i class="pteq">${PTICO.chk}</i>`:''}${nw&&o?'<i class="ptnw">NEW</i>':''}${o?'':'<b class="ptq">?</b>'}</button>`};
 return `<div class="ptg"><section class="ptp ptros"><div class="ptph"><h3>Companion Roster</h3><span>${own} / ${PIDS.length} owned</span></div>
  <div class="ptfl">${[['all','All'],['r','Rare'],['l','Legendary']].map(([k,l])=>`<button class="${f===k?'on':''}" data-f="${k}" aria-pressed="${f===k}">${l}</button>`).join('')}
   <div class="ptso"><button class="ptsob" id="ptsob" aria-haspopup="listbox" aria-expanded="false">${PTSI.sort}<span>Sort: <b>${sn}</b></span><i class="ptsoc">›</i></button>
    <div class="ptsom" id="ptsom" role="listbox" aria-label="Sort companions">${PTSORT.map(([k,l,ic])=>`<button role="option" class="${k===sk?'on':''}" aria-selected="${k===sk}" data-so="${k}">${PTSI[ic]}<span>${l}</span>${k===sk?`<i>${PTSI.chk}</i>`:''}</button>`).join('')}</div></div></div>
  <div class="ptrg" id="ptrg">${L.map(card).join('')}</div></section>
  <section class="ptp ptstg"><canvas width="540" height="620" id="ptcv"></canvas><div class="ptnm" id="ptnm"></div></section>
  <section class="ptp ptdet" id="ptdet"></section></div>`}
{const b0=ptPetsBind;ptPetsBind=function(){const r=b0.apply(this,arguments);try{
 const btn=$('ptsob'),menu=$('ptsom');if(!btn)return r;let open=false;
 const set=o=>{open=o;menu.classList.toggle('on',o);btn.setAttribute('aria-expanded',o);if(o){const c=menu.querySelector('.on')||menu.querySelector('button');setTimeout(()=>{try{c.focus()}catch(e){}},20)}};
 btn.onclick=e=>{e.stopPropagation();ptBeep(560,.03,.2);set(!open)};
 menu.querySelectorAll('[data-so]').forEach(b=>b.onclick=e=>{e.stopPropagation();P.petSort=b.dataset.so;save();ptBeep(680,.04,.25);const sc=$('ptrg')?$('ptrg').scrollTop:0;petHall('Pets');const g=$('ptrg');if(g){g.scrollTop=sc;g.classList.add('resort')}});
 menu.onkeydown=e=>{const bs=[...menu.querySelectorAll('button')],i=bs.indexOf(document.activeElement);if(e.key==='ArrowDown'){e.preventDefault();bs[(i+1)%bs.length].focus()}else if(e.key==='ArrowUp'){e.preventDefault();bs[(i-1+bs.length)%bs.length].focus()}else if(e.key==='Escape'){e.preventDefault();e.stopPropagation();set(false);btn.focus()}};
 const away=e=>{if(!btn.isConnected){document.removeEventListener('pointerdown',away,true);return}if(open&&!e.target.closest('.ptso'))set(false)};document.addEventListener('pointerdown',away,true);
 }catch(e){}return r}}

/* ---------- EGGS: pick an egg on the left, see it on the stage, act on the right ---------- */
function ptEggsHTML(){const k=PTX.egg=PTX.egg==='l'?'l':'r',E=PRAR[k],n=P.eggs[k]|0,pool=petPool(k),full=!pool.length,pc=pool.length?Math.round(1000/pool.length)/10:0,pr=PEGG_PRICE[k],need=pr-P.gold,nx=petNextEgg();
 const card=r=>{const L=petList(r),o=L.filter(petOwned).length,m=P.eggs[r]|0;return `<button class="phx-c${r===k?' on':''} phx-${r}" data-egg="${r}" role="radio" aria-checked="${r===k}" aria-label="${PRAR[r].egg} egg, ${m} owned, ${o} of ${L.length} discovered"><canvas width="96" height="110" data-et="${r}"></canvas><div class="phx-ci"><b>${PRAR[r].egg}</b>${ptBadge(r,1)}<span class="phx-pg"><span class="ptbar phx-b${r}"><i style="width:${o/L.length*100}%"></i></span><small>${o}/${L.length}</small></span></div><em class="phx-cnt${m?'':' z'}">×${m}</em></button>`};
 const act=full?`<div class="phx-full"><p>You own every ${E.n} companion. Each ${E.egg} egg now becomes <b>50 bond XP</b>.</p><button class="ptgo b" id="phxcv2" ${n?'':'disabled'}>${n?'Choose a companion for 50 bond XP':'No eggs to convert'}</button></div>`
  :n?`<button class="ptgo phx-hatch" id="phxht">${PTICO.egg} Hatch ${E.egg}</button>`:`<button class="ptgo off phx-hatch" disabled>${PTICO.egg} No eggs to hatch</button><p class="phx-why">Earn eggs on the Adventure Trail, or buy one below.</p>`;
 return `<div class="phx phx2"><section class="ptp phx-inv"><div class="ptph"><h3>Your Eggs</h3></div><div class="phx-cards" role="radiogroup" aria-label="Egg type">${card('r')}${card('l')}</div>
</section>
  <section class="phx-show"><canvas id="phxcv" aria-hidden="true"></canvas><div class="phx-tt"><h3>${E.egg} Egg</h3>${ptBadge(k)}</div>
   <div class="phx-pool"><p>${full?`Every ${E.n} companion discovered`:`<b>${pool.length}</b> undiscovered ${E.n} companion${pool.length===1?'':'s'} <em>(${pc}% each)</em>`}</p><div class="phx-pl">${petList(k).map(id=>`<span class="${petOwned(id)?'own':''}" title="${petOwned(id)?esc(PDEF[id].n)+' (owned)':'Undiscovered'}"><canvas width="56" height="48" data-pl="${id}"></canvas></span>`).join('')}</div><button class="ptsoft phx-vc" id="phxvc">View companions ›</button></div></section>
  <section class="ptp phx-act"><div class="ptph"><h3>Hatchery</h3></div><div class="phx-big"><b id="phxn">${n}</b><span>${E.egg} egg${n===1?'':'s'}<small>ready to hatch</small></span></div>
   ${act}
   <div class="phx-or"><i></i><span>more eggs</span><i></i></div>
   <div class="phx-row"><canvas width="64" height="72" id="phxme"></canvas><div class="phx-rt"><b>Buy one</b><small>${PTICO.coin}${pr.toLocaleString()} gold</small></div>
    <button class="ptgo b phx-buy${full||need>0?' off':''}" id="phxby" ${full||need>0?'disabled':''}>${full?'Collection complete':need>0?`Need ${need.toLocaleString()} more gold`:'Buy'}</button></div>
   <button class="phx-row phx-earn2" data-pt2="Trail">${PTICO.trail}<div class="phx-rt"><b>Earn one free</b><small>${nx?`${nx.left} adventure${nx.left===1?'':'s'} to a ${PRAR[nx.k].egg} egg`:'Play adventures to earn eggs'}</small></div><span class="phx-dots" aria-hidden="true">${nx?[0,1,2,3,4].map(i=>`<i class="${i<5-nx.left?'on':''}"></i>`).join(''):''}</span><i class="phx-chev">›</i></button>
   <p class="phx-sh2"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2l8 3v6c0 5-3.4 9.4-8 11-4.6-1.6-8-6-8-11V5z" fill="#ffd166"/><path d="M8 12l3 3 5-6" stroke="#5a3a10" stroke-width="2.4" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg><span><b>No repeats.</b> Eggs only hatch companions you don't have yet.</span></p></section></div>`}
{const b0=ptEggsBind;ptEggsBind=function(){const r=b0.apply(this,arguments);try{
 const n=$('phxn');if(n&&n.classList.contains('pop'))n.animate([{transform:'scale(1.5)',color:'#9fffb0'},{transform:'scale(1)'}],{duration:500,easing:'cubic-bezier(.3,1.6,.5,1)'});
 }catch(e){}return r}}

{const st=document.createElement('style');st.textContent=`
/* ----- roster ----- */
.ptfl{align-items:center;flex-wrap:nowrap;position:relative;z-index:6}.ptfl>button{padding:6px 13px!important}
.ptso{position:relative;margin-left:auto}
.ptsob{all:unset;cursor:pointer;display:flex;align-items:center;gap:8px;padding:6px 12px;border-radius:10px;font:600 13.5px var(--ui);color:#e8e0ff;background:#140e30;border:1.5px solid #6a58c0;transition:border-color .15s,background .15s;white-space:nowrap}
.ptsob:hover,.ptsob[aria-expanded="true"]{border-color:var(--gold);background:#1e1648}.ptsob svg{width:17px;height:17px;color:var(--gold)}.ptsob b{color:#fff;font-weight:700}.ptsob:focus-visible{outline:3px solid var(--gold);outline-offset:2px}
.ptsoc{font-style:normal;margin-left:2px;font-size:16px;transform:rotate(90deg);transition:transform .2s;color:#c4badf}.ptsob[aria-expanded="true"] .ptsoc{transform:rotate(-90deg)}
.ptsom{position:absolute;right:0;top:calc(100% + 8px);z-index:30;min-width:240px;padding:6px;border-radius:14px;background:#120c2ef8;border:1px solid #5a4ca0;box-shadow:0 18px 40px #000c;display:flex;flex-direction:column;gap:2px;opacity:0;transform:translateY(-6px) scale(.98);transform-origin:100% 0;pointer-events:none;transition:opacity .16s,transform .18s cubic-bezier(.2,1.2,.4,1)}
.ptsom.on{opacity:1;transform:none;pointer-events:auto}
.ptsom button{all:unset;box-sizing:border-box;cursor:pointer;display:flex;align-items:center;gap:12px;padding:9px 12px;border-radius:10px;font:600 14px var(--ui);color:#e8e0ff;transition:background .12s}
.ptsom button svg{width:17px;height:17px;flex:none;color:#c4badf}.ptsom button:hover,.ptsom button:focus-visible{background:#ffffff12;outline:none}
.ptsom button.on{background:linear-gradient(180deg,#6a4ad8,#4a2ea8);color:#fff}.ptsom button.on svg{color:#fff}.ptsom button i{margin-left:auto;display:grid}.ptsom button span{flex:1}
.ptrg.resort .ptc{animation:ptres .35s cubic-bezier(.2,1,.4,1) both}.ptrg.resort .ptc:nth-child(n){animation-delay:calc(var(--n,0)*1ms)}@keyframes ptres{from{opacity:0;transform:translateY(8px) scale(.96)}}
${Array.from({length:16},(_,i)=>`.ptrg.resort .ptc:nth-child(${i+1}){animation-delay:${i*22}ms}`).join('')}
.ptc-l{background:radial-gradient(circle at 50% 35%,#3a2e30,#160e1a)!important;border-color:#c8961a!important}.ptc-l:not(.unk){box-shadow:inset 0 0 18px #ffb02a22}
.ptc-r{background:radial-gradient(circle at 50% 35%,#24305a,#0e0e26)!important;border-color:#3a6ac8!important}
.ptc.on{border-color:var(--gold)!important;box-shadow:0 0 0 2px #ffd45a66,0 0 22px #ffd45a55!important}
.ptc.unk{border-color:#3a3070!important;background:radial-gradient(circle at 50% 35%,#1e1840,#0c0a1e)!important}
.ptlv{position:absolute;left:5px;bottom:24px;min-width:18px;height:18px;padding:0 4px;box-sizing:border-box;border-radius:9px;display:grid;place-items:center;font:800 10.5px var(--ui);font-style:normal;color:#fff;background:linear-gradient(180deg,#8a66e0,#5b3ea8);box-shadow:0 0 0 1.5px #0e0a22}
/* ----- eggs, decluttered ----- */
.phx2 .phx-inv{display:flex;flex-direction:column;gap:10px}
.phx2 .phx-c{display:flex;align-items:center;gap:10px;position:relative}.phx2 .phx-ci{display:flex;flex-direction:column;align-items:flex-start;gap:5px;flex:1;min-width:0}
.phx2 .phx-ci b{font:400 23px/1 'Pirata One',Georgia,serif;color:var(--gold)}
.phx-pg{display:flex;align-items:center;gap:8px;width:100%}.phx-pg .ptbar{flex:1;margin:0;height:7px}.phx-pg small{font:700 12px var(--ui);color:#c4badf}
.phx-cnt{font:800 22px var(--ui);font-style:normal;color:#fff;padding-right:4px}.phx-cnt.z{color:#6a5a9a}
.phx-sh2{margin:auto 0 0;display:flex;gap:10px;align-items:flex-start;padding:12px;border-radius:12px;background:#0a0618;border:1px solid #3a3070;font:500 13px/1.4 var(--ui);color:#c4badf}.phx-sh2 svg{width:22px;height:22px;flex:none}.phx-sh2 b{color:#ffd166}
.phx2 .phx-act{display:flex;flex-direction:column;gap:12px;justify-content:flex-start}.phx2 .phx-act .ptph{margin-bottom:0}
.phx2 .phx-cards{flex:1;display:flex;flex-direction:column;gap:12px;min-height:0}
.phx2 .phx-c{flex:1;flex-direction:column;justify-content:center;gap:8px;min-height:0;padding:14px 18px!important;text-align:center}
.phx2 .phx-c canvas{width:96px!important;height:110px!important;transition:transform .25s cubic-bezier(.3,1.5,.5,1)}.phx2 .phx-c:hover canvas,.phx2 .phx-c.on canvas{transform:translateY(-3px) scale(1.06)}
.phx2 .phx-ci{align-items:center;width:100%}.phx2 .phx-ci>*{align-self:center;margin-left:0;margin-right:0}.phx2 .phx-pg{align-self:stretch}.phx2 .phx-ci b{font-size:28px}
.phx2 .phx-cnt{position:absolute;top:10px;right:14px;font-size:20px}
.phx-big{display:flex;align-items:center;gap:14px;padding:4px 2px}.phx-big b{font:800 54px/1 var(--ui);color:#fff;text-shadow:0 0 18px #ffd45a55;transition:transform .2s}.phx-big span{display:flex;flex-direction:column;font:700 20px var(--ui);color:#fff8e8}.phx-big small{font:500 14px var(--ui);color:#c4badf}
.phx2 .phx-hatch{min-height:58px;font-size:20px}
.phx-or{display:flex;align-items:center;gap:10px;margin-top:4px;font:700 11.5px var(--ui);letter-spacing:2px;text-transform:uppercase;color:#8a80b8}.phx-or i{flex:1;height:1px;background:#ffffff1a}
.phx-row{all:unset;box-sizing:border-box;display:flex;align-items:center;gap:12px;padding:10px 12px;border-radius:14px;background:#0f0a26;border:1px solid #3a3070;width:100%}
.phx-row canvas{width:44px;height:50px;flex:none}.phx-rt{display:flex;flex-direction:column;flex:1;min-width:0}.phx-rt b{font:700 16px var(--ui);color:#fff8e8}.phx-rt small{display:flex;align-items:center;gap:5px;font:600 13px var(--ui);color:#c4badf}.phx-rt small svg{width:14px;height:14px}
.phx2 .phx-buy{flex:none;min-width:96px;padding:10px 16px;font-size:15px;box-shadow:0 3px 0 #1e1660}
.phx-earn2{cursor:pointer;transition:border-color .15s,background .15s}.phx-earn2:hover{border-color:#6ad8a0;background:#0f1e22}.phx-earn2>svg{width:30px;height:30px;flex:none;color:#7affb0;padding:7px;border-radius:12px;background:#0a2a1e}
.phx-earn2:focus-visible{outline:3px solid var(--gold);outline-offset:2px}
.phx-dots{display:flex;gap:4px}.phx-dots i{width:9px;height:9px;border-radius:50%;background:#2a2050;border:1px solid #4a3e8a}.phx-dots i.on{background:#7affb0;border-color:#7affb0;box-shadow:0 0 6px #7affb0}
.phx-chev{font-style:normal;font-size:22px;color:#c4badf}
.phx2 .phx-why{margin:-4px 0 0;font:500 13px var(--ui);color:#c4badf;text-align:center}
`;document.head.appendChild(st)}
