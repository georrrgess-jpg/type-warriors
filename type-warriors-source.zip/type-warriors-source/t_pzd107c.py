# python3 t_pzd107c.py : 10.7 The Gilded Hoard, the cast art (97bc): code hygiene and registration, each of the five drawers exists and
# paints in every mood, every mood changes the pixels, the drawing moves over time, the drawn box stays inside a sensible box against
# PZ_MONH, the medallion bust shows the face, the gradient cache is reused, the frame cost of each drawer, and no page errors.
import asyncio,os,sys,re
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:600]),flush=True)
    if not ok:FAIL.append(name)
IDS=['clasp','zephyra','brass','hornsby','aurelion']
MOODS=['neutral','cheer','sad','angry','rattled','wow']
HELP=r"""window.pzdcT={
 ex(k){const N=PZ_EXP.neutral,T=PZ_EXP[k],e={};for(const q in T)e[q]=(q==='eo'||q==='sw'||q==='bl'||k==='neutral')?T[q]:N[q]+(T[q]-N[q])*1.45;return e},
 cv(){const c=document.createElement('canvas');c.width=640;c.height=640;const g=c.getContext('2d');g.lineJoin='round';g.lineCap='round';return [c,g]},
 draw(id,k,t){const [c,g]=this.cv();g.translate(320,600);g.scale(1,1);pzMon[id](g,t==null?1.3:t,this.ex(k),{breath:0,tilt:0,bob:0,hop:0});return c},
 stats(c){const d=c.getContext('2d').getImageData(0,0,c.width,c.height).data;let n=0,h=0,x0=1e9,x1=-1,y0=1e9,y1=-1;for(let y=0;y<c.height;y+=2)for(let x=0;x<c.width;x+=2){const i=(y*c.width+x)*4;if(d[i+3]>30){n++;h=(h*31+d[i]*7+d[i+1]*3+d[i+2])|0;if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y}}return {n,h,x0:x0-320,x1:x1-320,y0:y0-600,y1:y1-600}},
 diff(a,b){const A=a.getContext('2d').getImageData(0,0,640,640).data,B=b.getContext('2d').getImageData(0,0,640,640).data;let n=0;for(let i=0;i<A.length;i+=16)if(Math.abs(A[i]-B[i])+Math.abs(A[i+1]-B[i+1])+Math.abs(A[i+2]-B[i+2])+Math.abs(A[i+3]-B[i+3])>60)n++;return n}};0"""
async def main():
    src=os.path.join(HERE,'97bc_pzd_cast.js')
    s=open(src,encoding='utf8').read();s0=re.sub(r'/\*.*?\*/','',s,flags=re.S)
    bad=[pat for pat in [r'\bbackdrop-filter\b',r'\.shadowBlur\s*=',r'ctx\.filter',r'\.filter\s*=\s*[\'"`]',r"globalCompositeOperation\s*=\s*['\"](screen|soft-light)",r'claude-|opus|sonnet'] if re.search(pat,s0,re.I)]
    chk('no shadowBlur, ctx.filter, screen / soft-light blends, backdrop-filter or model ids in 97bc',not bad,bad)
    tops=re.findall(r'^(?:const|let|var|function)\s+([A-Za-z_$][\w$]*)',s0,flags=re.M)
    chk('every top-level name in 97bc starts with pzdc / PZDC',tops and all(n.startswith(('pzdc','PZDC')) for n in tops),[n for n in tops if not n.startswith(('pzdc','PZDC'))])
    keys=re.findall(r"pzGrR?\(g,'([^']+)'",s0)
    chk('every cached gradient key in 97bc starts with pzdc_',keys and all(k.startswith('pzdc_') for k in keys),[k for k in keys if not k.startswith('pzdc_')])
    for f in ['build.sh','build_ast3.sh']:
        b=open(os.path.join(HERE,f)).read();i=[b.find(' '+m+' ') for m in ['97b2_pzn_cast.js','97ba_pz_rack106.js','97bc_pzd_cast.js']]
        chk(f'{f}: 97bc registered once, after 97ba (and 97bb when present)',all(x>0 for x in i) and i==sorted(i) and b.count(' 97bc_pzd_cast.js ')==1 and (b.find(' 97bb_pzd_data.js ')<0 or b.find(' 97bb_pzd_data.js ')<i[2]),i)
    async with async_playwright() as p:
        br=await p.chromium.launch();er=[]
        pg=await br.new_page(viewport={'width':1600,'height':900})
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        pg.on('console',lambda m:er.append('console:'+m.text[:300]) if m.type=='error' and 'ERR_' not in m.text and 'WebSocket' not in m.text else None)
        await pg.goto(H);await pg.wait_for_timeout(1500)
        await pg.evaluate("()=>{try{RS_ASK=false;PZ_TUT_OFF=true;WCRELAYS=[];ST.perfAsked=1;PFW.asked=true}catch(e){}}");await pg.evaluate(HELP);E=pg.evaluate
        r=await E("ids=>ids.map(k=>[k,typeof pzMon[k],PZ_MONH[k]||0])",IDS)
        chk('the five drawers exist (pzMon.clasp / zephyra / brass / hornsby / aurelion) with a PZ_MONH height',all(x[1]=='function' and 240<=x[2]<=480 for x in r),r)
        # every mood paints, every mood differs from neutral
        r=await E("""([ids,moods])=>{const out={};for(const id of ids){const base=pzdcT.draw(id,'neutral');out[id]={};for(const m of moods){let st,df;try{const c=pzdcT.draw(id,m);st=pzdcT.stats(c);df=m==='neutral'?0:pzdcT.diff(base,c)}catch(e){st={err:String(e)}}out[id][m]=[st.n||0,df,st.err||'']}}return out}""",[IDS,MOODS])
        chk('every drawer paints a solid figure in every mood (no exceptions)',all(r[i][m][0]>3000 and not r[i][m][2] for i in IDS for m in MOODS),r)
        chk('every mood (cheer, sad, angry, rattled, wow) visibly changes every drawer',all(r[i][m][1]>250 for i in IDS for m in MOODS if m!='neutral'),{i:{m:r[i][m][1] for m in MOODS} for i in IDS})
        # moves over time (breathing / idle quirk)
        r=await E("ids=>ids.map(id=>[id,pzdcT.diff(pzdcT.draw(id,'neutral',1.0),pzdcT.draw(id,'neutral',2.7))])",IDS)
        chk('every drawer moves over time in the neutral pose (idle quirk, breathing)',all(x[1]>150 for x in r),r)
        # bounds against PZ_MONH
        r=await E("""([ids,moods])=>ids.map(id=>{const h=PZ_MONH[id];let b={x0:1e9,x1:-1e9,y0:1e9,y1:-1e9};const nb=pzdcT.stats(pzdcT.draw(id,'neutral'));for(const m of moods)for(const t of[.4,1.3,3.1]){const s=pzdcT.stats(pzdcT.draw(id,m,t));b.x0=Math.min(b.x0,s.x0);b.x1=Math.max(b.x1,s.x1);b.y0=Math.min(b.y0,s.y0);b.y1=Math.max(b.y1,s.y1)}return [id,h,b,nb.y0,nb.x0,nb.x1]})""",[IDS,MOODS])
        chk('the neutral top sits within 18% of PZ_MONH (height matches the drawing)',all(abs(-x[3]-x[1])<=x[1]*.18 for x in r),[(x[0],x[1],-x[3]) for x in r])
        chk('in every mood the figure stays inside a sensible box (width within +-250, top within 1.4 x PZ_MONH (a cap or monocle may fly), nothing below the floor line +16)',all(x[2]['x0']>=-250 and x[2]['x1']<=250 and -x[2]['y0']<=x[1]*1.4 and x[2]['y1']<=16 for x in r),r)
        chk('the figures sit with the existing casts (neutral width 180-480 units)',all(180<=x[5]-x[4]<=480 for x in r),[(x[0],x[5]-x[4]) for x in r])
        # bust (medallion) paints, contains the face area
        r=await E("ids=>ids.map(id=>{const c=document.createElement('canvas');c.width=c.height=120;const g=c.getContext('2d');pz97Bust(g,id,120,pzdcT.ex('happy'),1.3);const d=g.getImageData(0,0,120,120).data;let n=0,top=120;for(let y=0;y<120;y++)for(let x=0;x<120;x++)if(d[(y*120+x)*4+3]>30){n++;if(y<top)top=y}return [id,n,top,!!PZ97_BUST[id]]})",IDS)
        chk('the medallion bust (pz97Bust, 120 px) is filled and the head sits near its top',all(x[1]>5000 and x[2]<24 and x[3] for x in r),r)
        # cache reuse
        r=await E("ids=>{const [c,g]=pzdcT.cv();for(const id of ids)pzMon[id](g,1,pzdcT.ex('neutral'),{breath:0,tilt:0,bob:0,hop:0});const n0=PZ_GCACHE.get(g).size;for(let i=0;i<5;i++)for(const id of ids)pzMon[id](g,1+i,pzdcT.ex(['cheer','sad','angry','rattled','wow'][i]),{breath:0,tilt:0,bob:0,hop:0});return [n0,PZ_GCACHE.get(g).size]}",IDS)
        chk('gradients are cached per context (no new cache entries after the first frame)',r[0]>5 and r[0]==r[1],r)
        # frame cost at match scale: interleaved rounds, the median per drawer, compared with the existing casts in the same run (load-proof)
        r=await E("""ids=>{const c=document.createElement('canvas');c.width=1600;c.height=900;const g=c.getContext('2d');g.lineJoin='round';g.lineCap='round';const all=ids.concat(['mortimer','vantara','bleep']),S={};for(const k of all)S[k]=[];
          const run=(id,m,n)=>{const e=pzdcT.ex(m),t0=performance.now();for(let i=0;i<n;i++){g.save();g.translate(1470,846);g.scale(.84,.84);pzMon[id](g,i*.033,e,{breath:Math.sin(i)*.01,tilt:0,bob:0,hop:0});g.restore()}g.getImageData(0,0,1,1);return (performance.now()-t0)/n};
          for(const k of all)run(k,'neutral',10);
          for(let r=0;r<7;r++)for(const k of all)for(const m of(ids.includes(k)?['neutral','cheer','angry']:['neutral']))S[k].push(run(k,m,24));
          const med=a=>{a=a.slice().sort((x,y)=>x-y);return a[a.length>>1]},mx=a=>Math.max(...a.slice().sort((x,y)=>x-y).slice(0,Math.ceil(a.length*.8)));const out={};for(const k of all)out[k]={med:+med(S[k]).toFixed(3),p80:+mx(S[k]).toFixed(3)};return out}""",IDS)
        print('  frame cost ms (median, p80 over neutral / cheer / angry):',r)
        ref=max(r['vantara']['med'],r['mortimer']['med'])
        chk(f'each drawer costs no more than the dearest existing cast (Vantara / Mortimer median {ref:.2f} ms in this run) x1.15, p80 within 1.5x of theirs',all(r[i]['med']<=ref*1.15 and r[i]['p80']<=max(r['vantara']['p80'],r['mortimer']['p80'])*1.5 for i in IDS),r)
        # a live match-like draw through pzCastDraw with each id
        r=await E("ids=>{const out=[];const c=document.createElement('canvas');c.width=1600;c.height=900;const g=c.getContext('2d');for(const id of ids){try{pzCastInit(id);pzCastReact('mon','cheer',500);for(let i=0;i<30;i++){pzCastFrame(1/60);pzCastDraw(g,i/60,{})}out.push([id,'ok'])}catch(e){out.push([id,String(e)])}}return out}",IDS)
        chk('each player draws through pzCastDraw with live springs (reaction, blink, hop)',all(x[1]=='ok' for x in r),r)
        chk('no page errors',not er,er)
        await br.close()
    print(f'\n{N[0]-len(FAIL)}/{N[0]} passed');sys.exit(1 if FAIL else 0)
asyncio.run(main())
