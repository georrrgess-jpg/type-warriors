/* ===== 9.4 THE CROOKED CUE: the cast (96g) =====
   The eight bar-goers and your hero. Each monster is a drawer pzMon[id](g,t,ex,p) in a local space whose origin is the bottom centre
   (y up is negative, about 300 units tall). `ex` is the live expression (eyes open, look, brow angle, mouth curve and openness, blush,
   sweat), `p` the pose (breath, tilt, bob, hop, lean). Expressions and poses are springs, so every change eases in and out; blinking,
   breathing, head tilt, weight shift and each monster's own idle quirk run all the time. Gradients are cached per context. */
const PZ_EXP={neutral:{eo:1,lx:0,ly:0,br:0,bh:0,mo:.18,ma:0,bl:0,sw:0},happy:{eo:.78,lx:0,ly:0,br:-.2,bh:.5,mo:.95,ma:.5,bl:.5,sw:0},smug:{eo:.55,lx:.6,ly:0,br:.35,bh:.3,mo:.65,ma:0,bl:0,sw:0},
 sad:{eo:.68,lx:0,ly:.5,br:-.95,bh:0,mo:-.85,ma:0,bl:0,sw:0},angry:{eo:.92,lx:0,ly:0,br:1,bh:0,mo:-.45,ma:.3,bl:0,sw:0},think:{eo:1,lx:-.7,ly:-.6,br:.15,bh:.3,mo:0,ma:0,bl:0,sw:0},
 rattled:{eo:1.2,lx:0,ly:0,br:-.55,bh:.9,mo:-.35,ma:.4,bl:0,sw:1},cheer:{eo:.25,lx:0,ly:0,br:-.3,bh:.7,mo:1,ma:.85,bl:.7,sw:0},wow:{eo:1.25,lx:0,ly:-.2,br:-.35,bh:1,mo:.1,ma:.7,bl:0,sw:0}};
const PZ_GCACHE=new WeakMap();
function pzGr(g,key,x0,y0,x1,y1,stops){let m=PZ_GCACHE.get(g);if(!m)PZ_GCACHE.set(g,m=new Map());let q=m.get(key);if(!q){q=g.createLinearGradient(x0,y0,x1,y1);stops.forEach(([o,c])=>q.addColorStop(o,c));m.set(key,q)}return q}
function pzGrR(g,key,x,y,r0,r1,stops){let m=PZ_GCACHE.get(g);if(!m)PZ_GCACHE.set(g,m=new Map());let q=m.get(key);if(!q){q=g.createRadialGradient(x,y,r0,x,y,r1);stops.forEach(([o,c])=>q.addColorStop(o,c));m.set(key,q)}return q}
const pzBlob=(g,fill,fn,lw)=>{g.fillStyle=fill;g.strokeStyle=PZ_O;g.lineWidth=lw||4;g.beginPath();fn();g.fill();g.stroke()};
const pzEll=(g,fill,x,y,rx,ry,rot,lw)=>{g.fillStyle=fill;g.beginPath();g.ellipse(x,y,rx,ry,rot||0,0,TAU);g.fill();if(lw!==0){g.strokeStyle=PZ_O;g.lineWidth=lw||3;g.stroke()}};
/* eye: white, iris, pupil that looks around, a catchlight, and lids that close (blink) and slant (angry / sad) */
function pzEyeD(g,x,y,r,ex,o){o=o||{};const op=Math.max(.04,Math.min(1.25,ex.eo)),ry=r*(.3+.7*Math.min(1,op))*(op>1?1+(op-1)*.5:1);
 g.save();g.beginPath();g.ellipse(x,y,r,ry,0,0,TAU);g.clip();g.fillStyle=o.white||'#fff';g.fillRect(x-r,y-ry,r*2,ry*2);
 const px=x+ex.lx*r*.42,py=y+ex.ly*ry*.4+r*.05,pr=r*(o.pr||.5);if(o.iris){g.fillStyle=o.iris;g.beginPath();g.arc(px,py,pr*1.18,0,TAU);g.fill()}
 g.fillStyle=o.pupil||PZ_O;g.beginPath();g.ellipse(px,py,pr*(o.slit?.4:.82),pr*(o.slit?1.05:.82),0,0,TAU);g.fill();g.fillStyle='rgba(255,255,255,.95)';g.beginPath();g.arc(px-pr*.32,py-pr*.34,pr*.26,0,TAU);g.fill();
 /* slanted lid: angry presses down toward the nose, sad lifts the inside corner */
 if(Math.abs(ex.br)>.05){const s=o.side||1,k=ex.br;g.fillStyle=o.lid||'rgba(0,0,0,.0)';g.fillStyle=o.skin||'#777';g.beginPath();
  if(k>0){g.moveTo(x-r*1.2,y-ry*1.2);g.lineTo(x+r*1.2,y-ry*1.2);g.lineTo(x+r*1.2,y-ry+(s>0?k*r*.75:-k*r*.0)+ (s>0?0:k*r*.75)*0);g.lineTo(x-r*1.2,y-ry+(s>0?0:k*r*.75));}
  else{const kk=-k;g.moveTo(x-r*1.2,y-ry*1.2);g.lineTo(x+r*1.2,y-ry*1.2);g.lineTo(x+r*1.2,y-ry+(s>0?0:kk*r*.55));g.lineTo(x-r*1.2,y-ry+(s>0?kk*r*.55:0))}
  g.closePath();g.fill()}
 g.restore();g.strokeStyle=PZ_O;g.lineWidth=o.lw||3;g.beginPath();g.ellipse(x,y,r,ry,0,0,TAU);g.stroke()}
function pzBrowD(g,x,y,w,ex,side,col,th){const a=side*(-ex.br)*.42,h=-ex.bh*7;g.save();g.translate(x,y+h);g.rotate(a);g.strokeStyle=col||PZ_O;g.lineWidth=th||5;g.lineCap='round';g.beginPath();g.moveTo(-w/2,0);g.quadraticCurveTo(0,-w*.12,w/2,0);g.stroke();g.restore()}
/* mouth: curve mo (-1 frown .. 1 smile), open ma (0..1) */
function pzMouthD(g,x,y,w,ex,o){o=o||{};const c=ex.mo*w*.34,op=ex.ma*w*.42;g.save();g.translate(x,y);g.lineCap='round';
 if(op>2){g.fillStyle=o.in||'#3a0e18';g.strokeStyle=PZ_O;g.lineWidth=o.lw||3;g.beginPath();g.moveTo(-w/2,0);g.quadraticCurveTo(0,c*2-0,w/2,0);g.quadraticCurveTo(0,c*2+op*1.5,-w/2,0);g.closePath();g.fill();g.stroke();
  if(o.tongue){g.fillStyle=o.tongue;g.beginPath();g.ellipse(0,op*.7+c*.8,w*.2,op*.28,0,0,Math.PI);g.fill()}}
 else{g.strokeStyle=o.line||PZ_O;g.lineWidth=o.lw||3.5;g.beginPath();g.moveTo(-w/2,0);g.quadraticCurveTo(0,c*2,w/2,0);g.stroke()}
 g.restore()}
const pzSweat=(g,x,y,t,ex)=>{if(ex.sw<.05)return;const k=ex.sw,d=((t*1.3)%1);g.save();g.globalAlpha=Math.min(1,k)*(1-d*.6);g.translate(x,y+d*14);g.fillStyle='#9fe8ff';g.strokeStyle=PZ_O;g.lineWidth=2;g.beginPath();g.moveTo(0,-9);g.quadraticCurveTo(7,0,0,7);g.quadraticCurveTo(-7,0,0,-9);g.fill();g.stroke();g.restore()};
const pzBlush=(g,x,y,r,ex,col)=>{if(ex.bl<.03)return;g.save();g.globalAlpha=ex.bl*.55;g.fillStyle=col||'#ff7a9a';g.beginPath();g.ellipse(x,y,r,r*.6,0,0,TAU);g.fill();g.restore()};
/* ---------- the monsters ---------- */
const pzMon={};
pzMon.gloop=function(g,t,ex,p){const w=Math.sin(t*3.1)*.035+p.hop*.0,sq=1+Math.sin(t*1.7)*.02+p.breath;
 g.save();g.scale(1+Math.sin(t*3.1)*.03,sq);
 pzEll(g,'rgba(0,0,0,.28)',0,2,142,16,0,0);
 /* the body: a jelly dome with a wobbling rim and drips */
 const wb=Math.sin(t*2.6)*6,wb2=Math.sin(t*3.4+1)*5;
 pzBlob(g,pzGr(g,'gl_b',0,-262,0,0,[[0,'#b6ffb0'],[.5,'#5fe07a'],[1,'#25a444']]),()=>{g.moveTo(-136,0);g.bezierCurveTo(-158+wb2,-120,-92,-252+wb*.5,0,-254);g.bezierCurveTo(92,-252-wb*.5,158-wb2,-120,136,0);g.quadraticCurveTo(100,12,60,4);g.quadraticCurveTo(30,14,0,4);g.quadraticCurveTo(-34,14,-62,4);g.quadraticCurveTo(-104,12,-136,0)},5);
 /* inner glow and bubbles drifting up */
 g.save();g.beginPath();g.moveTo(-130,-4);g.bezierCurveTo(-150,-120,-90,-246,0,-248);g.bezierCurveTo(90,-246,150,-120,130,-4);g.closePath();g.clip();
 g.fillStyle=pzGrR(g,'gl_in',10,-90,6,150,[[0,'rgba(220,255,200,.5)'],[1,'rgba(220,255,200,0)']]);g.fillRect(-160,-260,320,270);
 for(let i=0;i<7;i++){const ph=(t*.28+i*.37)%1,bx=-80+((i*53)%160)+Math.sin(t+i)*7,by=-14-ph*210,br=4+(i%3)*3;g.strokeStyle='rgba(20,100,40,.55)';g.lineWidth=2;g.beginPath();g.arc(bx,by,br,0,TAU);g.stroke();g.fillStyle='rgba(255,255,255,.35)';g.beginPath();g.arc(bx-br*.3,by-br*.3,br*.3,0,TAU);g.fill()}
 g.restore();
 g.fillStyle='rgba(255,255,255,.4)';g.beginPath();g.ellipse(-62,-196,20,38,-.5,0,TAU);g.fill();g.fillStyle='rgba(255,255,255,.22)';g.beginPath();g.ellipse(-84,-150,7,15,-.3,0,TAU);g.fill();
 /* face */
 pzBlush(g,-78,-128,20,ex,'#ff9ab0');pzBlush(g,78,-128,20,ex,'#ff9ab0');
 pzEyeD(g,-38,-168,26,ex,{skin:'#4fd070',side:1,pr:.5});pzEyeD(g,36,-172,30,ex,{skin:'#4fd070',side:-1,pr:.5});
 pzBrowD(g,-38,-208,34,ex,1,'#1a5a2a',5);pzBrowD(g,36,-214,38,ex,-1,'#1a5a2a',5);
 pzMouthD(g,0,-110,56,ex,{in:'#1a5a2a',tongue:'#ff7a9a',lw:4});pzSweat(g,92,-186,t,ex);
 /* bow tie */
 pzBlob(g,'#e0262e',()=>{g.moveTo(-34,-64);g.lineTo(0,-54);g.lineTo(-34,-40);g.closePath();g.moveTo(34,-64);g.lineTo(0,-54);g.lineTo(34,-40);g.closePath()},3);pzEll(g,'#ffd45a',0,-54,7,7,0,2.5);
 g.restore();
 /* a glowing soda in a little arm nub (does not wobble with the body) */
 g.save();g.translate(112,-86+Math.sin(t*1.6)*3);pzBlob(g,'#4fd070',()=>{g.ellipse(-8,16,30,20,.5,0,TAU)},4);
 g.fillStyle='rgba(200,255,220,.5)';g.strokeStyle=PZ_O;g.lineWidth=3;g.beginPath();g.moveTo(-4,-30);g.lineTo(32,-30);g.lineTo(28,10);g.quadraticCurveTo(14,16,0,10);g.closePath();g.fill();g.stroke();
 g.fillStyle=pzGr(g,'gl_s',0,-20,0,10,[[0,'#d8ff5a'],[1,'#5ae04a']]);g.beginPath();g.moveTo(-1,-18);g.lineTo(29,-18);g.lineTo(27,8);g.quadraticCurveTo(14,14,1,8);g.closePath();g.fill();
 for(let i=0;i<4;i++){const ph=(t*.7+i*.27)%1;g.fillStyle='rgba(255,255,255,.7)';g.beginPath();g.arc(8+i*5,6-ph*22,1.8+(i%2),0,TAU);g.fill()}
 g.strokeStyle='#ff5a8a';g.lineWidth=3;g.beginPath();g.moveTo(22,-18);g.lineTo(28,-44);g.lineTo(38,-44);g.stroke();pzGlow(g,14,-6,26,'rgba(160,255,100,1)',.4);g.restore()};
pzMon.moldwick=function(g,t,ex,p){const tw=Math.sin(t*.9)*.02;g.save();g.scale(1,1+p.breath);
 pzEll(g,'rgba(0,0,0,.28)',0,2,118,13,0,0);
 /* dress and shawl */
 pzBlob(g,pzGr(g,'mw_d',0,-170,0,0,[[0,'#8a68b0'],[1,'#5a3a82']]),()=>{g.moveTo(-112,0);g.bezierCurveTo(-116,-100,-70,-156,-46,-168);g.lineTo(46,-168);g.bezierCurveTo(70,-156,116,-100,112,0);g.closePath()},4);
 for(let i=0;i<11;i++){g.fillStyle='rgba(255,220,240,.32)';g.beginPath();g.arc(-86+i*17,-20-((i*37)%70),5.5,0,TAU);g.fill()}
 g.strokeStyle='rgba(0,0,0,.18)';g.lineWidth=3;for(let i=-3;i<=3;i++){g.beginPath();g.moveTo(i*28,-6);g.quadraticCurveTo(i*22,-70,i*14,-160);g.stroke()}
 pzBlob(g,'#d8a0c8',()=>{g.moveTo(-70,-150);g.quadraticCurveTo(0,-120,70,-150);g.lineTo(60,-100);g.quadraticCurveTo(0,-72,-60,-100);g.closePath()},4);pzEll(g,'#ffd45a',0,-118,8,8,0,2.5);
 /* arms holding a teacup */
 pzBlob(g,'#d8a0c8',()=>{g.ellipse(-88,-90,22,34,.35,0,TAU)},4);
 pzBlob(g,'#f2dcc0',()=>{g.ellipse(-62,-64+Math.sin(t*1.2)*1.5,15,13,0,0,TAU)},3.5);
 g.save();g.translate(-62,-70+Math.sin(t*1.2)*1.5);pzBlob(g,'#fdf6ee',()=>{g.moveTo(-14,-4);g.quadraticCurveTo(0,26,14,-4);g.closePath()},3);pzEll(g,'#8a4a2a',0,-4,14,4,0,2.5);
 for(let i=0;i<3;i++){const ph=(t*.5+i*.33)%1;g.strokeStyle=`rgba(255,255,255,${.5*(1-ph)})`;g.lineWidth=2.5;g.beginPath();g.moveTo(-5+i*5,-8);g.quadraticCurveTo(-8+i*5+Math.sin(t*3+i)*3,-22-ph*14,-3+i*5,-34-ph*22);g.stroke()}g.restore();
 /* head */
 g.save();g.translate(0,-172);g.rotate(p.tilt*.6+tw);
 pzBlob(g,'#f2dcc0',()=>{g.ellipse(0,-12,54,60,0,0,TAU)},4);
 /* hair bun and curls */
 pzEll(g,'#e8e4ee',-44,-24,18,26,.3,3.5);pzEll(g,'#e8e4ee',44,-24,18,26,-.3,3.5);pzBlob(g,'#e8e4ee',()=>{g.arc(0,-78,18,0,TAU)},3.5);
 pzBlush(g,-36,-4,15,ex,'#ff7a9a');pzBlush(g,36,-4,15,ex,'#ff7a9a');
 pzEyeD(g,-21,-24,13,ex,{skin:'#f2dcc0',side:1,pr:.5,iris:'#7a9ad8'});pzEyeD(g,21,-24,13,ex,{skin:'#f2dcc0',side:-1,pr:.5,iris:'#7a9ad8'});
 /* spectacles */
 g.strokeStyle='#d8a03a';g.lineWidth=3.2;for(const s of[-1,1]){g.beginPath();g.arc(s*21,-24,18,0,TAU);g.stroke();g.fillStyle='rgba(200,230,255,.22)';g.fill()}g.beginPath();g.moveTo(-3,-24);g.lineTo(3,-24);g.stroke();
 g.strokeStyle='rgba(255,255,255,.7)';g.lineWidth=2;g.beginPath();g.arc(-27,-30,9,3.7,4.6);g.stroke();
 pzBrowD(g,-21,-48,22,ex,1,'#b8b4c0',3.5);pzBrowD(g,21,-48,22,ex,-1,'#b8b4c0',3.5);
 pzEll(g,'#e8c8a8',0,-10,7,5,0,2.5);pzMouthD(g,0,10,26,ex,{in:'#8a2a3a',lw:3});pzSweat(g,50,-34,t,ex);
 /* the mushroom hat: a big red cap with spots and gills, that puffs spores */
 pzBlob(g,'#d8c0a8',()=>{g.ellipse(0,-58,92,22,0,0,TAU)},4);for(let i=-8;i<=8;i++){g.strokeStyle='rgba(120,80,60,.5)';g.lineWidth=1.6;g.beginPath();g.moveTo(i*10,-58);g.lineTo(i*11.5,-44);g.stroke()}
 pzBlob(g,pzGr(g,'mw_c',0,-150,0,-60,[[0,'#ff7a6a'],[1,'#b8222a']]),()=>{g.moveTo(-104,-62);g.bezierCurveTo(-110,-132,-50,-162,0,-162);g.bezierCurveTo(50,-162,110,-132,104,-62);g.quadraticCurveTo(0,-34,-104,-62)},4.5);
 for(const [sx,sy,sr] of[[-62,-110,16],[8,-138,14],[56,-100,18],[-20,-92,10],[84,-76,9],[-86,-80,9]]){pzEll(g,'#fff4e0',sx,sy,sr,sr*.8,0,3)}
 g.fillStyle='rgba(255,255,255,.3)';g.beginPath();g.ellipse(-44,-142,22,9,-.5,0,TAU);g.fill();
 for(let i=0;i<9;i++){const ph=(t*.22+i*.173)%1,sx=Math.sin(i*2.3)*70+Math.sin(t*.7+i)*8,sy=-150-ph*120;g.fillStyle=`rgba(230,255,200,${.55*Math.sin(ph*Math.PI)})`;g.beginPath();g.arc(sx,sy,2+(i%3),0,TAU);g.fill()}
 g.restore();g.restore()};
pzMon.grizzle=function(g,t,ex,p){const kc=Math.max(0,Math.sin(t*.55)-.9)*10;g.save();g.scale(1,1+p.breath*1.2);
 pzEll(g,'rgba(0,0,0,.3)',0,2,150,15,0,0);
 /* huge shoulders and a tank top */
 pzBlob(g,pzGr(g,'gz_b',0,-180,0,0,[[0,'#92a444'],[1,'#667428']]),()=>{g.moveTo(-158,0);g.quadraticCurveTo(-182,-124,-114,-178);g.lineTo(114,-178);g.quadraticCurveTo(182,-124,158,0);g.closePath()},4.5);
 pzBlob(g,'#e8e0d0',()=>{g.moveTo(-92,0);g.lineTo(-84,-160);g.lineTo(-40,-160);g.quadraticCurveTo(0,-110,40,-160);g.lineTo(84,-160);g.lineTo(92,0);g.closePath()},3.5);
 g.fillStyle='#c83a2a';g.fillRect(-86,-118,172,11);g.strokeStyle=PZ_O;g.lineWidth=2.5;g.strokeRect(-86,-118,172,11);
 g.strokeStyle='rgba(60,70,20,.6)';g.lineWidth=3;g.beginPath();g.moveTo(-132,-90);g.quadraticCurveTo(-120,-70,-134,-52);g.moveTo(130,-96);g.quadraticCurveTo(118,-76,132,-56);g.stroke();
 /* the left fist cracks its knuckles */
 g.save();g.translate(-142,-56+kc*.5);g.rotate(.2+kc*.04);pzBlob(g,'#92a444',()=>{g.roundRect(-26,-30,52,60,18)},4);for(let i=0;i<4;i++){g.strokeStyle=PZ_O;g.lineWidth=2.4;g.beginPath();g.moveTo(-18+i*12,-30);g.lineTo(-18+i*12,-14);g.stroke()}g.restore();
 pzBlob(g,'#92a444',()=>{g.roundRect(118,-86,52,60,18)},4);
 /* head, horn, tusks */
 g.save();g.translate(0,-178+p.bob);g.rotate(p.tilt*.5);
 pzBlob(g,pzGr(g,'gz_h',0,-130,0,-10,[[0,'#a8ba52'],[1,'#7a8c34']]),()=>{g.ellipse(0,-56,92,84,0,0,TAU)},4.5);
 pzBlob(g,'#e8dcc0',()=>{g.moveTo(-16,-130);g.lineTo(0,-188);g.lineTo(16,-130);g.closePath()},3.5);
 g.strokeStyle='rgba(60,70,20,.5)';g.lineWidth=3;g.beginPath();g.moveTo(-60,-30);g.quadraticCurveTo(-70,-8,-56,6);g.stroke();
 pzEyeD(g,0,-66,40,ex,{skin:'#a8ba52',side:1,pr:.46,iris:'#c8222a',lw:4});
 g.strokeStyle='#3a4410';g.lineWidth=7;g.lineCap='round';g.beginPath();g.moveTo(-50,-118+ -ex.br*8);g.lineTo(46,-118+ex.br*8*-1+(ex.br>0?10:-4));g.stroke();
 g.fillStyle='#5a2a14';g.beginPath();g.ellipse(0,-6,44,16+ex.ma*14,0,0,Math.PI*(ex.mo>-.2?1:1));g.fill();g.strokeStyle=PZ_O;g.lineWidth=3.5;g.stroke();
 pzBlob(g,'#f4ead2',()=>{g.moveTo(-34,-8);g.lineTo(-26,-38);g.lineTo(-14,-8);g.closePath();g.moveTo(34,-8);g.lineTo(26,-38);g.lineTo(14,-8);g.closePath()},3);pzSweat(g,86,-80,t,ex);
 g.restore();g.restore()};
pzMon.vesper=function(g,t,ex,p){const wf=Math.sin(t*1.4)*.05+Math.max(0,Math.sin(t*.4)-.85)*.4;g.save();g.scale(1,1+p.breath);
 pzEll(g,'rgba(0,0,0,.28)',0,2,128,14,0,0);
 /* wings behind, ruffling */
 for(const s of[-1,1]){g.save();g.scale(s,1);g.rotate(-wf);pzBlob(g,pzGr(g,'vs_w',0,-200,0,0,[[0,'#3a1a5a'],[1,'#1a0a2a']]),()=>{g.moveTo(40,-130);g.quadraticCurveTo(150,-250,230,-190);g.quadraticCurveTo(200,-176,196,-150);g.quadraticCurveTo(170,-156,160,-120);g.quadraticCurveTo(130,-130,120,-90);g.quadraticCurveTo(90,-100,70,-40);g.closePath()},4);
  g.strokeStyle='rgba(200,160,255,.35)';g.lineWidth=2.5;g.beginPath();g.moveTo(60,-130);g.lineTo(206,-196);g.moveTo(66,-110);g.lineTo(164,-126);g.moveTo(74,-84);g.lineTo(124,-92);g.stroke();g.restore()}
 /* cloak with a high collar and red lining */
 pzBlob(g,pzGr(g,'vs_c',0,-190,0,0,[[0,'#2e1850'],[1,'#120a26']]),()=>{g.moveTo(-124,0);g.quadraticCurveTo(-150,-100,-92,-160);g.lineTo(92,-160);g.quadraticCurveTo(150,-100,124,0);g.closePath()},4.5);
 pzBlob(g,'#c8222a',()=>{g.moveTo(-70,-160);g.lineTo(-50,-62);g.lineTo(0,-130);g.lineTo(50,-62);g.lineTo(70,-160);g.closePath()},3.5);
 pzBlob(g,'#2e1850',()=>{g.moveTo(-98,-170);g.lineTo(-74,-206);g.lineTo(-48,-150);g.closePath();g.moveTo(98,-170);g.lineTo(74,-206);g.lineTo(48,-150);g.closePath()},3.5);
 pzEll(g,'#ffd45a',0,-116,9,9,0,2.5);pzEll(g,'#ff3a5a',0,-116,4,4,0,0);
 /* a goblet of something red */
 g.save();g.translate(104,-88+Math.sin(t*1.3)*2.5);pzBlob(g,'#4a2a6a',()=>{g.ellipse(-4,10,22,30,.4,0,TAU)},3.5);g.fillStyle='rgba(220,220,255,.3)';g.strokeStyle=PZ_O;g.lineWidth=3;g.beginPath();g.moveTo(-14,-26);g.lineTo(18,-26);g.quadraticCurveTo(16,6,2,8);g.quadraticCurveTo(-12,6,-14,-26);g.fill();g.stroke();g.fillStyle='#c8222a';g.beginPath();g.moveTo(-12,-14);g.lineTo(16,-14);g.quadraticCurveTo(14,4,2,6);g.quadraticCurveTo(-10,4,-12,-14);g.fill();g.fillStyle=PZ_O;g.fillRect(0,8,4,14);g.fillRect(-10,21,24,4);g.restore();
 /* head */
 g.save();g.translate(0,-198+p.bob);g.rotate(p.tilt*.7+Math.sin(t*.8)*.02);
 for(const s of[-1,1]){pzBlob(g,'#5a3a7a',()=>{g.moveTo(s*34,-52);g.lineTo(s*88,-148);g.lineTo(s*84,-40);g.closePath()},4);g.fillStyle='#ff9ad0';g.beginPath();g.moveTo(s*46,-56);g.lineTo(s*80,-128);g.lineTo(s*76,-48);g.fill()}
 pzBlob(g,pzGr(g,'vs_h',0,-80,0,20,[[0,'#6a4a8c'],[1,'#4a2a6a']]),()=>{g.ellipse(0,-22,70,66,0,0,TAU)},4.5);
 pzBlob(g,'#2e1850',()=>{g.moveTo(-72,-40);g.quadraticCurveTo(-60,-96,0,-98);g.quadraticCurveTo(60,-96,72,-40);g.quadraticCurveTo(30,-70,0,-62);g.quadraticCurveTo(-30,-70,-72,-40)},3.5);
 pzBlush(g,-44,-4,15,ex,'#ff7ab0');pzBlush(g,44,-4,15,ex,'#ff7ab0');
 for(const s of[-1,1]){pzGlow(g,s*28,-28,34,'rgba(255,60,90,1)',.55*Math.min(1,ex.eo));pzEyeD(g,s*28,-28,20,ex,{skin:'#6a4a8c',side:s,white:'#ffe8ee',iris:'#e0102a',pupil:'#2a0008',pr:.42,slit:1})}
 pzBrowD(g,-28,-58,28,ex,1,'#1a0a2a',4.5);pzBrowD(g,28,-58,28,ex,-1,'#1a0a2a',4.5);
 pzEll(g,'#4a2a6a',0,-6,6,4,0,2.5);pzMouthD(g,0,16,34,ex,{in:'#3a0e28',lw:3.2});
 /* fangs */
 g.fillStyle='#fff';g.strokeStyle=PZ_O;g.lineWidth=2;for(const s of[-1,1]){g.beginPath();g.moveTo(s*10,15+ex.mo*-3);g.lineTo(s*6,29+ex.ma*8);g.lineTo(s*1.5,15+ex.mo*-3);g.closePath();g.fill();g.stroke()}
 const gl=Math.max(0,Math.sin(t*.6)-.92)*12;if(gl>0){g.fillStyle=`rgba(255,255,255,${gl*.9})`;pzStar(g,10,30,gl*1.6)}pzSweat(g,70,-50,t,ex);g.restore();g.restore()};
const pzStar=(g,x,y,r)=>{g.beginPath();for(let i=0;i<8;i++){const a=i/8*TAU,rr=i%2?r*.28:r;g.lineTo(x+Math.cos(a)*rr,y+Math.sin(a)*rr)}g.closePath();g.fill()};
pzMon.barnacle=function(g,t,ex,p){const cl=Math.max(0,Math.sin(t*2.2))*.22;g.save();g.scale(1,1+p.breath);
 pzEll(g,'rgba(0,0,0,.3)',0,2,152,15,0,0);
 /* the shell */
 pzBlob(g,pzGr(g,'bc_b',0,-240,0,0,[[0,'#ff7a5a'],[1,'#b8301a']]),()=>{g.ellipse(0,-104,150,108,0,0,TAU)},5);
 g.save();g.beginPath();g.ellipse(0,-104,146,104,0,0,TAU);g.clip();g.fillStyle='rgba(255,220,200,.22)';g.beginPath();g.ellipse(-52,-160,66,26,-.4,0,TAU);g.fill();g.strokeStyle='rgba(120,30,10,.4)';g.lineWidth=3;for(let i=0;i<5;i++){g.beginPath();g.arc(0,-84,40+i*26,Math.PI*1.1,Math.PI*1.9);g.stroke()}g.restore();
 for(let i=0;i<7;i++){pzEll(g,'#f4e8c8',-120+i*40,-30-Math.sin(i*1.3)*14,9,9,0,2.5)}
 /* legs */
 g.strokeStyle=PZ_O;g.lineCap='round';for(const s of[-1,1])for(let i=0;i<3;i++){const y=-26+i*-8,x=s*(120+i*10),w=Math.sin(t*2+i+s)*3;g.lineWidth=11;g.beginPath();g.moveTo(s*110,y);g.lineTo(x+s*30,y+16+w);g.lineTo(x+s*40,y+44);g.stroke();g.strokeStyle='#d8482a';g.lineWidth=6;g.stroke();g.strokeStyle=PZ_O}
 /* claws */
 for(const s of[-1,1]){g.save();g.translate(s*134,-134);g.rotate(s*(-.5+(s>0?cl:-cl*.5)));pzBlob(g,'#e85a3a',()=>{g.moveTo(-14,10);g.quadraticCurveTo(-44,-50,-8,-92);g.lineTo(10,-60);g.lineTo(26,-96);g.quadraticCurveTo(58,-44,26,10);g.closePath()},4.5);g.fillStyle='rgba(255,255,255,.22)';g.beginPath();g.ellipse(-14,-40,6,22,.1,0,TAU);g.fill();g.restore()}
 /* tricorn hat */
 g.save();g.translate(0,-300+p.bob);g.rotate(p.tilt*.4);pzBlob(g,'#1c1c2e',()=>{g.moveTo(-104,12);g.quadraticCurveTo(-110,-32,-42,-44);g.quadraticCurveTo(0,-84,42,-44);g.quadraticCurveTo(110,-32,104,12);g.quadraticCurveTo(0,-8,-104,12)},4.5);
 g.strokeStyle='#d8a03a';g.lineWidth=4;g.beginPath();g.moveTo(-98,8);g.quadraticCurveTo(0,-14,98,8);g.stroke();g.fillStyle='#f4f0e6';g.font='800 28px Poppins,sans-serif';g.textAlign='center';g.fillText('☠',0,-18);g.restore();
 /* eye stalks and eyes */
 for(const s of[-1,1]){g.strokeStyle=PZ_O;g.lineWidth=14;g.beginPath();g.moveTo(s*36,-196);g.quadraticCurveTo(s*48+Math.sin(t*1.3+s)*4,-232,s*52,-262+Math.sin(t*1.7+s*2)*5);g.stroke();g.strokeStyle='#e85a3a';g.lineWidth=8;g.stroke();pzEyeD(g,s*54,-276+Math.sin(t*1.7+s*2)*5,24,ex,{skin:'#e85a3a',side:s,pr:.5})}
 /* gold tooth grin and cheeks */
 pzBrowD(g,-54,-216,30,ex,1,'#5a1a0a',5);pzBrowD(g,54,-216,30,ex,-1,'#5a1a0a',5);pzMouthD(g,0,-120,76,ex,{in:'#3a0a0a',lw:4});pzEll(g,'#ffd45a',22,-112+ex.ma*8,6,7,0,2);pzBlush(g,-78,-140,20,ex,'#ff9a7a');pzBlush(g,78,-140,20,ex,'#ff9a7a');pzSweat(g,120,-170,t,ex);
 g.restore()};
pzMon.hootsworth=function(g,t,ex,p){const sw=Math.sin(t*.35)*Math.max(0,Math.sin(t*.35*3)+.2)*.5;g.save();g.scale(1,1+p.breath);
 pzEll(g,'rgba(0,0,0,.28)',0,2,126,14,0,0);
 pzBlob(g,pzGr(g,'ho_b',0,-290,0,0,[[0,'#b88a58'],[1,'#7a5430']]),()=>{g.moveTo(-124,0);g.bezierCurveTo(-148,-150,-110,-268,0,-272);g.bezierCurveTo(110,-268,148,-150,124,0);g.closePath()},4.5);
 /* belly feathers, a tweed waistcoat and watch chain */
 pzBlob(g,'#e8d0a8',()=>{g.ellipse(0,-76,78,84,0,0,TAU)},3.5);for(let i=0;i<15;i++){g.strokeStyle='rgba(120,80,40,.55)';g.lineWidth=2.2;g.beginPath();g.arc(-52+(i%5)*26,-118+Math.floor(i/5)*34,10,0.1,Math.PI-.1);g.stroke()}
 pzBlob(g,'#4a5a3a',()=>{g.moveTo(-60,-134);g.lineTo(-24,-142);g.lineTo(-20,-26);g.lineTo(-70,-36);g.closePath();g.moveTo(60,-134);g.lineTo(24,-142);g.lineTo(20,-26);g.lineTo(70,-36);g.closePath()},3.5);
 g.strokeStyle='rgba(255,255,255,.12)';g.lineWidth=1.6;for(let i=0;i<5;i++){g.beginPath();g.moveTo(-64,-130+i*20);g.lineTo(-24,-136+i*20);g.stroke();g.beginPath();g.moveTo(64,-130+i*20);g.lineTo(24,-136+i*20);g.stroke()}
 g.strokeStyle='#d8a03a';g.lineWidth=2.5;g.beginPath();g.moveTo(-34,-100);g.quadraticCurveTo(0,-70,34,-100);g.stroke();pzEll(g,'#ffd45a',34,-100,6,6,0,2);
 /* a notebook and a quill */
 g.save();g.translate(-108,-76);g.rotate(-.18);pzBlob(g,'#f4ead2',()=>{g.roundRect(-16,-20,32,40,3)},3);g.strokeStyle='rgba(90,60,30,.5)';g.lineWidth=1.6;for(let i=0;i<4;i++){g.beginPath();g.moveTo(-10,-12+i*8);g.lineTo(10,-12+i*8);g.stroke()}g.restore();
 g.save();g.translate(-92+Math.sin(t*3.2)*2,-62);g.rotate(.7);pzBlob(g,'#fff8e8',()=>{g.moveTo(0,0);g.quadraticCurveTo(10,-44,2,-90);g.quadraticCurveTo(-12,-48,0,0)},3);g.restore();
 pzBlob(g,'#b88a58',()=>{g.ellipse(-112,-52,20,16,0,0,TAU)},3.5);
 /* head: swivels now and then */
 g.save();g.translate(0,-236+p.bob);g.rotate(p.tilt*.5+sw);
 for(const s of[-1,1])pzBlob(g,'#7a5430',()=>{g.moveTo(s*54,-44);g.lineTo(s*82,-100);g.lineTo(s*98,-34);g.closePath()},4);
 for(const s of[-1,1]){pzBlob(g,'#f4e6c8',()=>{g.arc(s*42,-6,42,0,TAU)},4);g.strokeStyle='rgba(180,130,60,.5)';g.lineWidth=2;for(let k=0;k<3;k++){g.beginPath();g.arc(s*42,-6,32+k*4,0,TAU);g.stroke()}}
 for(const s of[-1,1]){pzEyeD(g,s*42,-6,28,ex,{skin:'#f4e6c8',side:s,iris:'#e8a020',pr:.52})}
 /* brass spectacles with a glint */
 g.strokeStyle='#d8a03a';g.lineWidth=4.5;for(const s of[-1,1]){g.beginPath();g.arc(s*42,-6,34,0,TAU);g.stroke();g.fillStyle='rgba(200,230,255,.16)';g.fill()}g.beginPath();g.moveTo(-8,-6);g.lineTo(8,-6);g.stroke();
 const gl=((t*.45)%1);g.save();g.beginPath();g.arc(-42,-6,33,0,TAU);g.clip();g.fillStyle='rgba(255,255,255,.55)';g.beginPath();g.moveTo(-86+gl*110,-44);g.lineTo(-70+gl*110,-44);g.lineTo(-86+gl*110+40,30);g.lineTo(-100+gl*110+40,30);g.fill();g.restore();
 pzBrowD(g,-42,-52,40,ex,1,'#5a3a1a',5);pzBrowD(g,42,-52,40,ex,-1,'#5a3a1a',5);
 pzBlob(g,'#ffb84a',()=>{g.moveTo(-13,26);g.lineTo(0,56+ex.ma*8);g.lineTo(13,26);g.closePath()},3.5);pzSweat(g,100,-30,t,ex);
 g.restore();pzBlob(g,'#2a3a7a',()=>{g.moveTo(-30,-170);g.lineTo(0,-156);g.lineTo(-30,-142);g.closePath();g.moveTo(30,-170);g.lineTo(0,-156);g.lineTo(30,-142);g.closePath()},3.5);pzEll(g,'#1a2a5a',0,-156,6,6,0,2);
 g.restore()};
pzMon.mortimer=function(g,t,ex,p){const fl=Math.sin(t*1.1)*5;g.save();g.translate(0,fl);
 pzGlow(g,0,-200,230,'rgba(90,220,255,1)',.28);
 pzEll(g,'rgba(0,0,0,.22)',0,2-fl,110,12,0,0);
 /* robe and cape with gold trim */
 pzBlob(g,pzGr(g,'mt_r',0,-210,0,0,[[0,'#2a1a5a'],[1,'#0e0820']]),()=>{g.moveTo(-170,0);g.quadraticCurveTo(-170,-150,-86,-196);g.lineTo(86,-196);g.quadraticCurveTo(170,-150,170,0);g.quadraticCurveTo(110,14,60,2);g.quadraticCurveTo(0,16,-60,2);g.quadraticCurveTo(-110,14,-170,0)},4.5);
 g.strokeStyle='#ffd45a';g.lineWidth=5;g.beginPath();g.moveTo(-86,-196);g.lineTo(-48,0);g.moveTo(86,-196);g.lineTo(48,0);g.stroke();
 g.strokeStyle='rgba(255,212,90,.5)';g.lineWidth=2;for(let i=0;i<5;i++){g.beginPath();g.moveTo(-150+i*8,-30-i*10);g.lineTo(-120+i*10,-34-i*10);g.stroke()}
 /* ghost-flame motes rising */
 for(let i=0;i<10;i++){const ph=(t*.3+i*.1)%1,mx=Math.sin(i*2.7)*130+Math.sin(t*.9+i)*10,my=-60-ph*250;g.globalAlpha=.7*Math.sin(ph*Math.PI);pzGlow(g,mx,my,12+(i%3)*4,'rgba(120,230,255,1)',1);g.globalAlpha=1}
 /* skeletal hands on a scepter-cue */
 g.save();g.translate(-132,-62);g.rotate(.12);g.fillStyle='#4a3a2a';g.strokeStyle=PZ_O;g.lineWidth=3.5;g.beginPath();g.roundRect(-5,-120,10,160,4);g.fill();g.stroke();pzEll(g,'#7ad8ff',0,-124,11,11,0,3);pzGlow(g,0,-124,40,'rgba(120,230,255,1)',.6);
 for(let i=0;i<4;i++)pzBlob(g,'#ece8dc',()=>{g.roundRect(-14+i*7,-10+i*1,6,30,3)},2.6);g.restore();
 /* head and crown */
 g.save();g.translate(0,-200+p.bob);g.rotate(p.tilt*.7);
 pzBlob(g,pzGr(g,'mt_s',0,-120,0,10,[[0,'#f4f0e6'],[1,'#c8c4b8']]),()=>{g.moveTo(-64,-30);g.bezierCurveTo(-84,-136,84,-136,64,-30);g.quadraticCurveTo(40,2,0,4);g.quadraticCurveTo(-40,2,-64,-30)},4.5);
 g.strokeStyle='rgba(90,80,60,.45)';g.lineWidth=2.5;g.beginPath();g.moveTo(-50,-92);g.quadraticCurveTo(-30,-110,-10,-104);g.moveTo(34,-100);g.lineTo(44,-82);g.stroke();
 for(const s of[-1,1]){pzEll(g,'#0a0618',s*26,-54,21,23,0,3.5);pzGlow(g,s*26,-54,40,'rgba(90,240,255,1)',.9*Math.min(1,ex.eo));const o=Math.max(.15,Math.min(1,ex.eo));g.fillStyle='#bff8ff';g.beginPath();g.ellipse(s*26+ex.lx*5,-52+ex.ly*4,7*o,8*o,0,0,TAU);g.fill()}
 pzBrowD(g,-26,-90,34,ex,1,'#8a8a96',4.5);pzBrowD(g,26,-90,34,ex,-1,'#8a8a96',4.5);
 g.fillStyle=PZ_O;g.beginPath();g.moveTo(0,-34);g.lineTo(-9,-16);g.lineTo(9,-16);g.closePath();g.fill();
 const mo=ex.ma*8;g.fillStyle=PZ_O;g.fillRect(-34,-8,68,6+mo);g.strokeStyle='#e8e4d8';g.lineWidth=2.6;for(let i=-3;i<=3;i++){g.beginPath();g.moveTo(i*10,-8);g.lineTo(i*10,-2+mo);g.stroke()}
 pzBlob(g,'#ffd45a',()=>{g.moveTo(-64,-100);g.lineTo(-56,-160);g.lineTo(-30,-118);g.lineTo(0,-170);g.lineTo(30,-118);g.lineTo(56,-160);g.lineTo(64,-100);g.closePath()},4);
 for(const [cx,cc] of[[-30,'#7ad8ff'],[0,'#ff6a8a'],[30,'#8affb4']]){pzEll(g,cc,cx,-122,7,7,0,2.4);pzGlow(g,cx,-122,18,'rgba(255,255,255,1)',.35)}pzSweat(g,70,-70,t,ex);
 g.restore();g.restore()};
pzMon.shade=function(g,t,ex,p){const fk=.85+.15*Math.sin(t*7)*(Math.sin(t*.4)>.8?1:0);g.save();g.globalAlpha=Math.min(1,fk);
 /* a smoky body with rippling edges */
 g.fillStyle=pzGr(g,'sh_b',0,-270,0,0,[[0,'#241838'],[1,'#080410']]);g.strokeStyle=PZ_O;g.lineWidth=4;g.beginPath();g.moveTo(-150,-8);
 for(let i=0;i<=20;i++){const x=-150+i*15,y=-30-Math.sin(i*.7)*70-Math.abs(Math.sin(i*.37+t*1.2))*60-(i<3||i>17?0:50);g.lineTo(x,y+Math.sin(t*2+i*.9)*5)}g.lineTo(150,-8);for(let i=1;i<=10;i++){const x=150-i*30;g.quadraticCurveTo(x+15,10+Math.sin(t*2+i)*3,x,-8)}g.closePath();g.fill();g.stroke();
 for(let i=0;i<16;i++){const ph=(t*.25+i*.0625)%1,sx=-140+(i*19)%280+Math.sin(t*.8+i)*10,sy=-10-ph*240;g.globalAlpha=.4*(1-ph);g.fillStyle='#4a3a6a';g.beginPath();g.arc(sx,sy,10+(i%4)*5,0,TAU);g.fill();g.globalAlpha=1}
 /* coat collar and a fedora */
 pzBlob(g,'#322244',()=>{g.moveTo(-100,-150);g.lineTo(-60,-196);g.lineTo(-28,-132);g.closePath();g.moveTo(100,-150);g.lineTo(60,-196);g.lineTo(28,-132);g.closePath()},3.5);
 g.save();g.translate(0,-214+p.bob);g.rotate(p.tilt*.6);
 pzBlob(g,'#2a2030',()=>{g.ellipse(0,0,112,24,0,0,TAU)},4);pzBlob(g,'#3a2a46',()=>{g.moveTo(-68,-6);g.quadraticCurveTo(-72,-92,0,-92);g.quadraticCurveTo(72,-92,68,-6);g.quadraticCurveTo(0,10,-68,-6)},4);g.fillStyle='#8a2a4a';g.fillRect(-68,-30,136,13);g.strokeStyle=PZ_O;g.lineWidth=2.4;g.strokeRect(-68,-30,136,13);
 g.fillStyle='#ffd45a';g.beginPath();g.moveTo(40,-34);g.lineTo(62,-48);g.lineTo(56,-24);g.closePath();g.fill();
 /* eyes: glowing yellow slits under the brim */
 for(const s of[-1,1]){pzGlow(g,s*32,40,40,'rgba(255,224,80,1)',.8*Math.min(1,ex.eo));const o=Math.max(.12,Math.min(1.1,ex.eo));g.fillStyle='#ffe066';g.beginPath();g.ellipse(s*32+ex.lx*4,40,15,7*o+ex.ly*0,s*-.26*(1+ex.br*.6),0,TAU);g.fill()}
 /* the grin keeps widening */
 const gw=48+Math.sin(t*.9)*8+ex.mo*14;g.strokeStyle='#fff8e8';g.lineWidth=6;g.lineCap='round';g.beginPath();g.moveTo(-gw,76);g.quadraticCurveTo(0,76+22+ex.mo*10+ex.ma*14,gw,76);g.stroke();g.strokeStyle='rgba(255,255,255,.65)';g.lineWidth=2;for(let i=-3;i<=3;i++){g.beginPath();g.moveTo(i*gw/3.4,78+Math.abs(i)*-1.5);g.lineTo(i*gw/3.4,86+(1-Math.abs(i)/3.4)*8);g.stroke()}
 g.restore();
 /* a coin flipping over his knuckles */
 const cp=(t*1.4)%1,cy=-96-Math.sin(cp*Math.PI)*70;g.save();g.translate(124,cy);g.scale(1,Math.abs(Math.cos(cp*TAU*2))*.9+.1);g.fillStyle='#ffd45a';g.strokeStyle=PZ_O;g.lineWidth=3;g.beginPath();g.arc(0,0,13,0,TAU);g.fill();g.stroke();g.strokeStyle='#c88a10';g.lineWidth=2;g.beginPath();g.arc(0,0,8,0,TAU);g.stroke();g.restore();
 g.restore()};
const PZ_MONH={gloop:300,moldwick:360,grizzle:380,vesper:360,barnacle:350,hootsworth:360,mortimer:380,shade:340};
/* ---------- the cast on the table ---------- */
const PZ_CAST={id:null,hero:null,mon:null,sprites:{},ready:0};
function pzCastEx(){return{eo:1,lx:0,ly:0,br:0,bh:0,mo:.18,ma:0,bl:0,sw:0}}
function pzCastNew(){return{ex:pzCastEx(),tgt:'neutral',exV:{},blink:2+Math.random()*3,bt:0,lean:0,leanT:0,hop:0,hopV:0,tilt:0,tiltT:0,bob:0,sx:1,sy:1,sq:0,sqV:0,until:0,sh:0,anim:'idle',at:0,tw:0}}
function pzCastInit(monId){PZ_CAST.id=monId;PZ_CAST.hero=pzCastNew();PZ_CAST.mon=pzCastNew();PZ_CAST.mon.tilt=0;PZ_CAST.ready=0;pzHeroBake()}
function pzCastReact(who,kind,hold){const c=PZ_CAST[who];if(!c)return;c.tgt=kind;c.until=hold?performance.now()+hold:0;
 if(kind==='happy'||kind==='cheer'||kind==='wow'){c.hopV=5.2;c.hop=Math.max(c.hop,.001)}if(kind==='sad'||kind==='angry'){c.sqV=-14}if(kind==='rattled'){c.sh=1.6}
 c.rl=kind==='wow'?-1:kind==='rattled'?-.8:kind==='angry'?.9:kind==='sad'?-.4:kind==='smug'?.35:0;if(kind==='cheer'||kind==='happy'){c.tilt=.12*(Math.random()<.5?-1:1)}}
function pzCastHop(who,s){const c=PZ_CAST[who];if(c){c.hopV=s||5;c.hop=Math.max(c.hop,.001)}}
function pzCastLean(who,v){const c=PZ_CAST[who];if(c)c.leanT=v}
/* per-frame: expression springs, blink, breathing, lean */
function pzCastFrame(dt){const now=performance.now();for(const who of['hero','mon']){const c=PZ_CAST[who];if(!c)continue;
  if(c.until&&now>c.until){c.tgt='neutral';c.until=0}
  const T=PZ_EXP[c.tgt]||PZ_EXP.neutral,ex=c.ex,k=Math.min(1,dt*9),N=PZ_EXP.neutral,AMP=c.tgt==='neutral'?1:1.45;for(const key in T){const tv=key==='eo'||key==='sw'||key==='bl'?T[key]:N[key]+(T[key]-N[key])*AMP;ex[key]+=(tv-ex[key])*k}
  if(c.rl)c.rl*=Math.pow(.04,dt);
  /* blink */
  c.blink-=dt;if(c.blink<=0&&c.bt<=0){c.bt=.14;c.blink=2+Math.random()*3.5}if(c.bt>0){c.bt-=dt;const u=1-Math.abs(c.bt/.14*2-1);ex.eo*=1-.92*u}
  /* a ballistic hop (positive = up), a critically damped squash, lean and tilt: all stable at any frame time */
  {const n=Math.max(1,Math.ceil(dt/.01)),h=dt/n;for(let i=0;i<n;i++){if(c.hop>0||c.hopV>0){c.hopV-=24*h;c.hop+=c.hopV*h;if(c.hop<=0){c.hop=0;c.hopV=0}}
   const w=16;c.sqV+=((0-c.sq)*w*w-c.sqV*2*w)*h;c.sq+=c.sqV*h}}
  c.lean+=(c.leanT-c.lean)*Math.min(1,dt*7);c.tilt+=(c.tiltT-c.tilt)*Math.min(1,dt*5);
  c.sh=Math.max(0,c.sh-dt*1.6);c.at+=dt}}
/* the hero: bake poses once (drawHero is expensive), animate with transforms */
function pzHeroBake(){const poses={idle:{pose:'idle',wp:null},victory:{pose:'victory',pu:1,wp:null},dead:{pose:'dead',pu:1,wp:null}},S=3.1,out={};
 for(const k in poses){const c=pzCv(344,430),g=c.getContext('2d');g.translate(150,418);g.scale(S,S);try{drawHero(g,Object.assign({arm:P.armor,col:P.col,t:0.4,lg:0,walk:0},poses[k]))}catch(e){}out[k]=c}
 PZ_CAST.sprites=out}
/* draw both characters (stage coordinates). who positions: hero at (176,830), monster at (1450,838) */
function pzCastDraw(g,t,o){o=o||{};const H=PZ_CAST.hero,M=PZ_CAST.mon;if(!H||!M)return;
 /* hero */
 {const sp=PZ_CAST.sprites[o.heroPose||'idle']||PZ_CAST.sprites.idle;if(sp){const br=Math.sin(t*2.1)*.008,lean=H.lean,sh=H.sh?Math.sin(t*60)*3*H.sh:0;g.save();g.translate(176+lean*34+sh+(H.rl||0)*-22,846-H.hop*30);g.rotate(lean*.07);g.scale(.7*(1-H.sq*.1),.7*(1+br+H.sq*.13));
   pzEll(g,'rgba(0,0,0,.34)',-8,2,66,12,0,0);g.drawImage(sp,-150,-418,344,430);g.restore()}}
 /* monster */
 {const id=PZ_CAST.id,fn=pzMon[id];if(fn){const s=(o.monScale||.84)*(PZ_MONH[id]?1:1),br=Math.sin(t*2.2)*.012,lean=M.lean,shift=Math.sin(t*.14*TAU)*3,sh=M.sh?Math.sin(t*60)*4*M.sh:0;
   g.save();g.translate(1470-lean*40+shift+sh+(M.rl||0)*26,846-M.hop*30);g.rotate(-lean*.05+Math.sin(t*.9)*.006);g.scale(s,s);fn(g,t,M.ex,{breath:br+M.sq*.13,tilt:M.tilt+Math.sin(t*.8)*.025,bob:Math.sin(t*1.7)*1.4+M.hop*4,hop:M.hop});g.restore()}}}
/* a portrait (head and shoulders) drawn into a small canvas context, for the HUD cards and the hub */

/* the drawn extent of each monster (neutral pose), measured once, so every screen can fit it into its frame */
const PZ_MB={};
function pzMonBox(id){if(PZ_MB[id])return PZ_MB[id];const W=480,Hh=420,k=.5,cv=document.createElement('canvas');cv.width=W;cv.height=Hh;const g=cv.getContext('2d');g.lineJoin='round';g.lineCap='round';g.translate(W/2,Hh-40);g.scale(k,k);
 try{pzMon[id](g,1,pzCastEx(),{breath:0,tilt:0,bob:0,hop:0})}catch(e){}
 const d=g.getImageData(0,0,W,Hh).data;let x0=W,x1=0,y0=Hh,y1=0;for(let y=0;y<Hh;y++)for(let x=0;x<W;x++)if(d[(y*W+x)*4+3]>24){if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y}
 if(x1<x0){x0=W/2-60;x1=W/2+60;y0=Hh-300;y1=Hh-40}
 return PZ_MB[id]={x0:(x0-W/2)/k,x1:(x1-W/2)/k,y0:(y0-(Hh-40))/k,y1:(y1-(Hh-40))/k}}
/* scale and offset that put monster id inside a w x h frame, standing on its bottom edge */
function pzMonFit(id,w,h,pad,crop){const b=pzMonBox(id),bw=Math.max(40,b.x1-b.x0),bh=Math.max(40,b.y1-b.y0),wf=(w-pad*2)/bw,hf=(h-pad)/bh;let s=crop?Math.min(hf,wf*crop):Math.min(wf,hf);return{s,x:w/2-(b.x0+b.x1)/2*s,y:h-pad*.5-b.y1*s}}
function pzCastPortrait(g,who,id,size,t,ex){g.save();g.clearRect(0,0,size,size);
 if(who==='hero'){const sp=PZ_CAST.sprites.idle;if(sp){g.drawImage(sp,0,0,300,200,0,size*.04,size,size*.66*1.0)}g.restore();return}
 const fn=pzMon[id];if(!fn){g.restore();return}const hs=PZ_MONH[id]||320,s=size/(hs*.62);g.translate(size/2,size*1.02+hs*s*.08);g.scale(s,s);g.translate(0,hs*.14*0);fn(g,t||0,ex||pzCastEx(),{breath:0,tilt:0,bob:0,hop:0});g.restore()}
