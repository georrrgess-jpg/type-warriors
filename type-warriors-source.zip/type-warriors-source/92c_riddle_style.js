/* ===== RUNESTONE RIDDLE: the look (8.4b: the Sanctum block below restyles layout, tiles, keys and panel) =====
   Indigo night backdrop, a graphite runestone with a chunky #12081f outline, serif runes on carved tiles, an indigo glass side panel,
   Pirata One title with a gold gradient, Poppins UI. Every animation moves only transform or opacity; glows are pseudo-elements faded in. */
{const st=document.createElement('style');st.textContent=`
#ov.rrx.rr-modal{overflow:hidden}#ov.rrx{display:block;padding:0;text-align:left;background:radial-gradient(120% 90% at 30% 0%,#241650 0%,#120b30 45%,#07041a 100%);overflow:auto}
.rr{--t:68px;--gap:calc(var(--t)*.17);position:relative;min-height:100%;display:flex;flex-direction:column;padding:26px 44px 30px;box-sizing:border-box;font-family:Poppins,system-ui,sans-serif;color:#efeaff;isolation:isolate;-webkit-text-size-adjust:100%;text-size-adjust:100%}
.rr *{box-sizing:border-box;max-height:1000000px}
/* header */
.rrhd{width:100%;display:grid;grid-template-columns:auto minmax(0,1fr) auto auto;align-items:center;gap:14px 22px;max-width:1320px;margin:0 auto 16px}
.rrbk{font:600 15px Poppins,sans-serif;color:#e8e2ff;background:linear-gradient(180deg,#2a2468,#1c1850);border:1.5px solid #4a42a0;border-radius:14px;padding:10px 16px;cursor:pointer;box-shadow:0 4px 0 #12081f;transition:transform .15s}
.rrbk:hover{transform:translateY(-2px)}.rrbk:active{transform:translateY(2px)}
.rrbk span{font-size:20px;line-height:0;vertical-align:-1px;margin-right:2px}
.rrti{min-width:0}
.rrti h1{margin:0;line-height:1.12!important;padding-bottom:2px;-webkit-text-fill-color:transparent;font:400 52px/1 "Pirata One",Georgia,serif;letter-spacing:1px;background:linear-gradient(180deg,#fff2b8 0%,#ffcf4a 42%,#d07a10 78%,#8a3e08 100%);-webkit-background-clip:text;background-clip:text;color:transparent;-webkit-text-stroke:1px #3a1a06;filter:none;text-shadow:none}
.rrti p{margin:6px 0 0;font:500 13.5px/1.45 Poppins,system-ui,sans-serif;color:#c8bff0;max-width:640px}
.rrtabs{display:flex;gap:4px;padding:4px;border-radius:999px;background:#140f38;border:1.5px solid #3e3790}
.rrtabs button{font:700 12.5px Poppins,sans-serif;letter-spacing:.6px;text-transform:uppercase;color:#a9a0e0;background:none;border:0;border-radius:999px;padding:9px 16px;cursor:pointer;white-space:nowrap;position:relative}
.rrtabs button{box-shadow:none}.rrtabs button[aria-selected="true"]{color:#2a1604;background:linear-gradient(180deg,#ffe48a,#f5b928);box-shadow:0 2px 0 #8a5a08}
.rrtabs button:not([aria-selected="true"]):hover{color:#fff}
.rrgold{display:flex;align-items:center;gap:8px;padding:9px 16px 9px 12px;border-radius:999px;background:#140f38;border:1.5px solid #3e3790;font:700 17px Poppins,sans-serif;color:#ffe08a;white-space:nowrap}
.rrgold.bump{animation:rrBump .45s cubic-bezier(.3,1.6,.5,1)}
.rrcn{display:inline-block;width:20px;height:20px;border-radius:50%;background:radial-gradient(circle at 35% 30%,#fff6c0 0 18%,#ffd24a 40%,#c98a10 100%);border:2px solid #7a4a06;flex:none;vertical-align:middle}
/* layout */
.rrmain{display:grid;grid-template-columns:auto minmax(0,600px);gap:52px;justify-content:center;align-items:start;width:100%;max-width:1320px;margin:auto}
.rrboard{display:flex;flex-direction:column;align-items:center;gap:14px}
.rrside{display:flex;flex-direction:column;gap:14px;min-width:0}
/* the runestone */
.rrgrid{position:relative;display:grid;gap:var(--gap)}
.rrrw{display:grid;grid-template-columns:repeat(5,var(--t));gap:var(--gap)}
.rrrw.shk{animation:rrShake .5s ease}
.rrgrid.rrin .rrrw{animation:rrRowIn .5s cubic-bezier(.3,1.3,.5,1) both;animation-delay:calc(var(--r)*.06s)}
/* tiles */
.rrleg{display:flex;flex-wrap:wrap;justify-content:center;gap:4px 16px;margin:0;width:0;min-width:100%;font:600 12.5px/1.5 Poppins,sans-serif;color:#9a92c8;text-align:center}
.rrleg span{display:inline-flex;align-items:center;gap:6px;white-space:nowrap}
.rrleg b{color:#ffe08a;white-space:nowrap}
.rrsw{display:inline-block;width:12px;height:12px;border-radius:4px;border:1.5px solid}.rrsw.c{background:#1f6b45;border-color:#7af0b0}.rrsw.p{background:#b08418;border-color:#ffd45a}
.rrlink{font:700 12.5px Poppins,sans-serif;color:#ffe08a;background:none;border:0;border-radius:0;box-shadow:none;min-width:0;border-bottom:1.5px dashed #ffe08a88;padding:0 0 1px;margin:0;cursor:pointer}.rrlink:hover{color:#fff}
/* side panel */
.rrpanel{padding:16px 18px 15px;border-radius:24px;background:linear-gradient(180deg,#1d1752f2,#130e3af2);border:1.5px solid #4a42a0;box-shadow:0 18px 40px #0008,inset 0 1px 0 #ffffff12}
.rrey{margin:0 0 10px;font:700 11.5px Poppins,sans-serif;letter-spacing:1.6px;text-transform:uppercase;color:#ffcf5a}
.rrey u{text-decoration:none;color:#7a70b8;margin:0 4px}
.rrcutn{color:#ff9a8a;letter-spacing:.6px}
.rrpanel .rrey:not(:first-child){margin-top:13px}
.rrstats{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}
.rrstats>div{padding:10px 8px 9px;border-radius:14px;background:#0b0820;border:1.5px solid #2c2668;text-align:center;min-width:0}
.rrstats b{display:block;font:800 24px/1.15 Poppins,sans-serif;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.rrstats b.m{color:#ffd45a}.rrstats b.g{color:#7af0b0}
.rrstats small{display:block;margin-top:5px;font:700 10px Poppins,sans-serif;letter-spacing:1.3px;text-transform:uppercase;color:#8a82c0}
.rrlad{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:6px}
.rrlp{display:flex;flex-direction:column;align-items:center;gap:1px;padding:7px 2px 6px;border-radius:11px;background:#0e0b28;border:1.5px solid #2c2668;min-width:0}
.rrlp small{font:700 10px Poppins,sans-serif;color:#8a82c0;letter-spacing:.5px}
.rrlp b{font:800 13.5px Poppins,sans-serif;color:#ffe08a;white-space:nowrap}
.rrlp.gone{opacity:.38}
.rrlp.nx{border-color:#ffd45a;background:linear-gradient(180deg,#3a2c0a,#1e1606);position:relative}
.rrlp.nx::after{content:"";position:absolute;inset:-4px;border-radius:14px;border:2px solid #ffd45a66;animation:rrBreath 1.6s ease-in-out infinite}
.rrlp.hit{border-color:#7af0b0;background:linear-gradient(180deg,#1f6b45,#0c2a1c)}.rrlp.hit b{color:#9dfccc}
.rrcal{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));gap:5px}
.rrcd{display:grid;place-items:center;height:30px;border-radius:9px;font:700 12.5px Poppins,sans-serif;color:#6a64a0;background:#15123a;border:1.5px solid #27225a;position:relative}
.rrcal.rrcin .rrcd{animation:rrCell .4s cubic-bezier(.3,1.5,.5,1) both;animation-delay:calc(var(--i)*12ms)}
.rrcd.w{background:linear-gradient(180deg,#22744a,#164a32);border-color:#2f8a5a;color:#e8fff2}
.rrcd.l{background:linear-gradient(180deg,#7a2430,#4e141c);border-color:#98303e;color:#ffe2e6}
.rrcd.ms{color:#5a5490;background:#100d2c}
.rrcd.pre{color:#4a4580;background:#0e0b26;border-style:dashed}
.rrcd.fu{color:#4e4888;background:#141036}
.rrcd.td{color:#2a1604;background:linear-gradient(180deg,#ffe48a,#f5b928);border-color:#fff0b0}
.rrcd.td.w{color:#e8fff2;background:linear-gradient(180deg,#22744a,#164a32);border-color:#ffd45a;outline:2px solid #ffd45a;outline-offset:1px}.rrcd.td.l{color:#ffe2e6;background:linear-gradient(180deg,#7a2430,#4e141c);border-color:#ffd45a;outline:2px solid #ffd45a;outline-offset:1px}
.rrcd.td:not(.w):not(.l)::after{content:"";position:absolute;inset:-4px;border-radius:12px;border:2px solid #ffd45a88;animation:rrBreath 1.6s ease-in-out infinite}
.rrbon{margin:11px 0 0;font:500 12.5px/1.5 Poppins,sans-serif;color:#c8bff0}.rrbon b{color:#fff}.rrbon em{font-style:normal;font-weight:700;color:#ffd45a}
.rrnote{margin:14px 0 12px;font:500 12.5px/1.5 Poppins,sans-serif;color:#c8bff0}
.rrdist{display:flex;flex-direction:column;gap:5px}
.rrdr{display:grid;grid-template-columns:16px 1fr;align-items:center;gap:8px;font:700 12px Poppins,sans-serif;color:#a9a0e0}
.rrdr i{display:block;height:20px;position:relative}
.rrdr i::before{content:"";position:absolute;inset:0;border-radius:6px;background:linear-gradient(90deg,#3a3290,#5a4ac8);transform-origin:left;transform:scaleX(max(.06,var(--w)));animation:rrBar .7s cubic-bezier(.3,1.1,.5,1) both}
.rrdr.me i::before{background:linear-gradient(90deg,#1f8a55,#4ae89a)}
.rrdr em{position:absolute;left:8px;top:50%;transform:translateY(-50%);font:800 11.5px Poppins,sans-serif;font-style:normal;color:#fff;z-index:1}
/* buttons */
.rrbtn{font:700 14.5px Poppins,sans-serif;color:#2a1604;background:linear-gradient(180deg,#ffe48a,#f5b928);border:2px solid #12081f;border-radius:14px;padding:11px 18px;cursor:pointer;box-shadow:0 4px 0 #8a5a08;transition:transform .15s;white-space:nowrap}
.rrbtn:hover{transform:translateY(-2px)}.rrbtn:active{transform:translateY(2px)}
.rrbtn i{font-style:normal;margin-left:4px}
.rrbtn.ghost{color:#efeaff;background:linear-gradient(180deg,#2a2468,#1c1850);border-color:#4a42a0;box-shadow:0 4px 0 #12081f}
.rrnew{width:100%}
/* rune powers */
.rrpow{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px 10px;width:0;min-width:100%}
.rrpb{display:grid;grid-template-columns:auto minmax(0,1fr);align-items:center;gap:10px;padding:10px 12px;border-radius:16px;cursor:pointer;text-align:left;color:#efeaff;background:linear-gradient(180deg,#241e5e,#17134a);border:1.5px solid #4a42a0;box-shadow:0 4px 0 #12081f;transition:transform .15s;position:relative;overflow:hidden}
.rrpb:hover:not(:disabled){transform:translateY(-2px)}.rrpb:active:not(:disabled){transform:translateY(2px)}
.rrpb:disabled{cursor:default;opacity:.55}
.rrpb.used{opacity:.6;border-style:dashed}
.rrpi{width:36px;height:36px;border-radius:11px;display:grid;place-items:center;border:2px solid #12081f}
.rrpi svg{width:22px;height:22px}
.rrp-r .rrpi{background:linear-gradient(180deg,#4ae89a,#1f8a55);color:#06201a}
.rrp-s .rrpi{background:linear-gradient(180deg,#b08aff,#6a3ad8);color:#ffe9a0}
.rrpt{min-width:0}.rrpt b{display:flex;align-items:center;justify-content:space-between;gap:8px;font:700 14px Poppins,sans-serif}
.rrpt small{display:block;margin-top:1px;font:500 11.5px/1.3 Poppins,sans-serif;color:#a9a0e0}
.rrpc{display:flex;align-items:center;gap:5px;font:800 13px Poppins,sans-serif;color:#ffe08a;white-space:nowrap}
.rrpc .rrcn{width:16px;height:16px;border-width:1.5px}
.rrpb.fire::after{content:"";position:absolute;inset:0;background:radial-gradient(circle at 20% 50%,#ffffffaa,#fff0 60%);animation:rrFire .5s ease both;pointer-events:none}
.rrpn{grid-column:1/-1;margin:-2px 0 0;font:500 11.5px Poppins,sans-serif;color:#8a82c0;text-align:center}
/* keyboard */
.rrkb{display:flex;flex-direction:column;align-items:center;gap:8px}.rr{--k:50px}
.rrkb.off{opacity:.55;pointer-events:none}
.rrkr{display:flex;gap:6px;justify-content:center}
.rrk{width:var(--k);height:50px;border-radius:11px;font:600 17px Poppins,sans-serif;color:#fff;background:linear-gradient(180deg,#25205e,#1a1650);border:1.5px solid #3e3790;box-shadow:0 3px 0 #0c0828;cursor:pointer;padding:0;display:grid;place-items:center;transition:transform .1s}
.rrk:hover{transform:translateY(-1px)}
.rrk.tap{animation:rrTap .18s ease}
.rrk.wide{width:calc(var(--k)*1.55);font-size:12.5px;font-weight:700;letter-spacing:.4px;text-transform:uppercase}
.rrk.wide svg{width:24px;height:24px}
.rrk.c{background:linear-gradient(180deg,#22744a,#164a32);border-color:#2f8a5a}
.rrk.p{background:linear-gradient(180deg,#d4a224,#a07812);border-color:#ffd45a;color:#2a1604}
.rrk.a{background:#100d28;border-color:#2a2458;color:#8a84bc;box-shadow:0 3px 0 #08061a;opacity:.7}
.rrk.chg{animation:rrKeyIn .4s cubic-bezier(.3,1.6,.5,1)}
.rrk.shat{animation:rrShat .6s ease}
/* toast, result, fx */
.rrtoast{position:absolute;left:50%;top:calc(var(--at,60px)*.12);z-index:30;white-space:normal;width:max-content;padding:11px 20px;border-radius:14px;background:#fff8e0;color:#2a1604;font:700 14px Poppins,sans-serif;border:2px solid #12081f;box-shadow:0 10px 24px #000a;opacity:0;transform:translate(-50%,-10px);pointer-events:none;transition:opacity .2s,transform .25s cubic-bezier(.3,1.5,.5,1);max-width:520px;text-align:center}
.rrtoast.on{opacity:1;transform:translate(-50%,0)}
.rrres{position:absolute;left:0;right:0;top:0;height:100%;z-index:40;display:grid;place-items:center;padding:20px;background:#05031299;overflow:auto}
.rrres[hidden]{display:none}
.rrres.on{animation:rrFade .25s ease both}
.rrrc{position:relative;width:min(470px,100%);padding:26px 26px 22px;border-radius:26px;background:linear-gradient(180deg,#221a5e,#130e3a);border:2px solid #5a50c0;box-shadow:0 30px 60px #000c,inset 0 1px 0 #ffffff1a;text-align:center;animation:rrCard .45s cubic-bezier(.3,1.5,.5,1) both}
.rrrc.win{border-color:#4ae89a}
.rrrc .rrey{margin-bottom:6px}
.rrrc h2{margin:0;font:400 42px/1.05 "Pirata One",Georgia,serif;letter-spacing:.5px;text-shadow:none;-webkit-text-fill-color:transparent;background:linear-gradient(180deg,#fff2b8,#ffcf4a 50%,#d07a10);-webkit-background-clip:text;background-clip:text;color:transparent}
.rrrc.lose h2{background:linear-gradient(180deg,#f2eaff,#b8a8f0);-webkit-background-clip:text;background-clip:text}
.rrsub{margin:6px 0 20px;font:500 14px Poppins,sans-serif;color:#c8bff0}
.rrword{display:flex;justify-content:center;gap:8px;margin:0 0 16px;--t:52px}
.rrword .rrt{animation:rrWin .7s cubic-bezier(.3,1.6,.5,1) both;animation-delay:calc(.25s + var(--i)*.08s)}
.rrpay{margin:0 0 14px;padding:10px 14px;border-radius:16px;background:#0b0820;border:1.5px solid #2c2668;text-align:left}
.rrpay p{display:flex;justify-content:space-between;align-items:center;gap:12px;margin:4px 0;font:600 13.5px Poppins,sans-serif;color:#c8bff0}
.rrpay p b{color:#ffe08a;white-space:nowrap}
.rrpay p.neg b{color:#ff9a8a}.rrpay p.bon b{color:#7af0b0}
.rrpay p.tot{margin-top:8px;padding-top:8px;border-top:1.5px dashed #3a3480;font-size:16px;color:#fff}
.rrpay p.tot b{font-size:22px;margin-left:auto}
.rrpay p.ttl{justify-content:center;color:#ffd45a;font-weight:700}.rrpay p.ttl em{font-style:normal;color:#fff}
.rrdist.big{margin:0 0 12px}
.rrstk{margin:0 0 16px;font:600 13px Poppins,sans-serif;color:#a9a0e0}.rrstk b{color:#fff;white-space:nowrap}.rrstk u{text-decoration:none;color:#5a5490;margin:0 3px}
.rrbts{display:flex;gap:10px;justify-content:center;flex-wrap:wrap}
.rrxb{position:absolute;top:12px;right:12px;width:36px;height:36px;min-width:0;padding:0;display:grid;place-items:center;border-radius:12px;font:600 22px/1 Poppins,sans-serif;color:#c8bff0;background:#ffffff0d;border:1.5px solid #3e3790;box-shadow:none;cursor:pointer}
.rrxb:hover{color:#fff}
.rrfx{position:absolute;left:0;top:0;width:100%;height:100%;max-height:2400px;pointer-events:none;z-index:35}
.rrfly{position:absolute;z-index:45;width:22px;height:22px;border-radius:50%;pointer-events:none;background:radial-gradient(circle at 35% 30%,#fff6c0 0 18%,#ffd24a 40%,#c98a10 100%);border:2px solid #7a4a06}
/* ===== 8.4b Sanctum look ===== */
#ov.rrx{background:#0b0616}
.rr{--t:69px;--gap:calc(var(--t)*.12);--k:56px;padding:14px 30px 18px;overflow:hidden;overflow:clip}
.rrbg{position:absolute;left:0;top:0;width:100%;height:100%;z-index:-3;pointer-events:none}
.rrtorch{position:absolute;z-index:-2;width:90px;height:130px;pointer-events:none}
.rrtorch canvas{width:100%;height:100%;display:block}
.rrtorch::before{content:"";position:absolute;left:50%;top:40%;width:420px;height:420px;margin:-210px 0 0 -210px;border-radius:50%;background:radial-gradient(circle,#ff9a3a40,#ff7a2a14 40%,#0000 70%);animation:rrGlowF 2.6s ease-in-out infinite;z-index:-1}
.rrtorch.r::before{animation-delay:-1.3s}
.rrmotes{position:absolute;inset:0;overflow:hidden;pointer-events:none;z-index:-2}
.rrmotes i{position:absolute;bottom:-12px;width:5px;height:5px;border-radius:50%;background:#c8a8ff;opacity:0;animation:rrMote 11s linear infinite}
.rrmotes i:nth-child(3n){background:#ffd45a;width:4px;height:4px}.rrmotes i:nth-child(4n){background:#ff9a5a;width:3px;height:3px}
${[...Array(14)].map((_,i)=>`.rrmotes i:nth-child(${i+1}){left:${(i*7.3+3)%100}%;animation-delay:-${(i*0.83).toFixed(2)}s;animation-duration:${9+(i%5)*1.6}s}`).join('')}
/* header: back, gold title, tabs, coins */
.rrhd{max-width:1540px;margin:0 auto 10px;grid-template-columns:auto auto minmax(0,1fr) auto auto;gap:12px 24px}
.rrhd .rrtabs{grid-column:4}.rrhd .rrgold{grid-column:5}
.rrbk{font:700 17px Poppins,sans-serif;padding:11px 20px;border-radius:16px;border:2px solid #4a42a0;background:linear-gradient(180deg,#221d5c,#16124a);box-shadow:0 4px 0 #12081f}
.rrti h1{font-size:56px;letter-spacing:1.5px;-webkit-text-stroke:1.5px #3a1a06}
.rrsr{position:absolute!important;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}
.rrtabs{padding:5px;border:2px solid #3e3790;background:#110d30e6}.rrtabs button{font-size:13.5px;padding:10px 20px;letter-spacing:.8px}
.rrgold{font-size:19px;padding:10px 20px 10px 14px;border:2px solid #3e3790;background:#110d30e6}
/* three columns: keeper, runestone and keyboard, today's riddle */
.rrmain{grid-template-columns:320px auto 470px;gap:24px;max-width:1560px;align-items:start;justify-content:center}
.rrboard{gap:0;align-items:center}
.rrside{gap:14px}
/* the keeper */
.rrhost{position:relative;display:flex;flex-direction:column;align-items:center;padding-top:6px;min-height:560px}
.rrhost canvas{width:320px;height:470px;display:block;margin-top:auto}
.rrbub{position:relative;max-width:280px;min-height:64px;margin:0 0 -6px;padding:12px 16px;border-radius:18px;background:linear-gradient(180deg,#fffaf0,#f2e6c8);border:3px solid #12081f;box-shadow:0 6px 0 #12081f55;font:600 15px/1.4 Poppins,sans-serif;color:#2a1a3a;text-align:center;opacity:0;transform:translateY(8px) scale(.9);transition:opacity .25s,transform .35s cubic-bezier(.3,1.6,.5,1);z-index:2}
.rrbub.on{opacity:1;transform:none}
.rrbub::after{content:"";position:absolute;left:58%;bottom:-14px;width:22px;height:22px;background:#f2e6c8;border:3px solid #12081f;border-top:0;border-left:0;transform:rotate(45deg);border-radius:0 0 6px 0}
.rrbub b{color:#7a3ad8}
.rrhn{margin:4px 0 0;text-align:center;font:400 24px/1.1 "Pirata One",Georgia,serif;color:#ffd45a;-webkit-text-stroke:.6px #3a1a06;letter-spacing:.5px}
.rrhn small{display:block;margin-top:3px;font:700 11.5px Poppins,sans-serif;letter-spacing:1.6px;text-transform:uppercase;color:#b8aef0;-webkit-text-stroke:0}
/* the runestone arch: canvas behind, tiles in its recess */
.rrarchw{position:relative;width:var(--aw);height:var(--ah);--heat:0}.rrarchw::before,.rrarchw::after{content:"";position:absolute;inset:6% -2% -2%;border-radius:46% 46% 24px 24px;pointer-events:none;z-index:-1;transition:opacity 1.2s ease}.rrarchw::before{box-shadow:0 0 70px 10px #8a5aff66;opacity:calc(.15 + var(--heat)*.8)}.rrarchw::after{box-shadow:0 0 90px 18px #ffc94a66;opacity:0}.rrarchw.hot::after{opacity:.55;animation:rrHotP 2.4s ease-in-out infinite}.rrarchw.blaze::after{opacity:1;animation-duration:1.3s}.rrarchw.awake::after{opacity:1;box-shadow:0 0 90px 20px #4ae89a77;animation:none}.rrarchw.dim::before{box-shadow:0 0 60px 8px #b0485a55;opacity:.8}@keyframes rrHotP{0%,100%{opacity:.45}50%{opacity:1}}
.rrtilt{position:absolute;inset:0;transition:transform .35s cubic-bezier(.2,.9,.3,1);transform-style:preserve-3d}
.rrarch{position:absolute;inset:0;width:100%;height:100%;display:block}
.rrlamp{position:absolute;left:0;top:0;width:340px;height:340px;margin:-170px 0 0 -170px;border-radius:50%;pointer-events:none;background:radial-gradient(circle,#b88aff33,#0000 65%);opacity:0;transition:opacity .3s}
.rrarchw.hot .rrlamp{background:radial-gradient(circle,#ffd45a3a,#0000 65%)}
.rrarchw:hover .rrlamp{opacity:1}
.rrslab{position:absolute;left:var(--as);top:var(--at);padding:0;border:0;background:none;box-shadow:none;border-radius:0}
.rrarchw.rrswap{animation:rrSwap .45s cubic-bezier(.3,1.4,.5,1)}
.rrarchw.rrq{animation:rrQuake .6s ease}
.rr-rm .rrarchw{animation:none!important}
/* tiles: bold, legible runes */
.rrt{position:relative;display:grid;place-items:center;transform-style:preserve-3d;width:var(--t);height:var(--t);border-radius:calc(var(--t)*.15);background:linear-gradient(180deg,#201c30,#16131f);border:2px solid #2f2a44;overflow:visible}
.rrt b{position:relative;z-index:2;font:800 calc(var(--t)*.5)/1 Poppins,system-ui,sans-serif;color:#fff;text-transform:uppercase;text-shadow:0 2px 0 #12081f88}
.rrt::after{content:"";position:absolute;inset:-2px;border-radius:inherit;pointer-events:none;opacity:0;transition:opacity .25s}.rrt.flip{animation:rrFlip .52s ease-in-out both;animation-delay:calc(var(--i)*.27s)}.rr-rm .rrt.flip{animation:none}.rrt.gh{border-color:#3fae78;border-style:dashed}.rrt.ghin::before{animation:rrGhost .7s ease both}.rrt.f{border-color:#ffcf5a;background:linear-gradient(180deg,#26203a,#1a1626)}
.rrrw.now .rrt{border-color:#6a4ad0;background:linear-gradient(180deg,#221c3c,#17132a)}
.rrrw.now .rrt.f{border-color:#ffcf5a}
.rrrw.now .rrt::after{inset:-3px;opacity:.55;box-shadow:0 0 14px #8a5aff55;animation:rrSock 2.2s ease-in-out infinite;animation-delay:calc(var(--i)*.18s)}
.rrrw.now .rrt.f::after{box-shadow:0 0 14px #ffcf5a55}
.rrring{position:absolute;inset:-3px;border-radius:calc(var(--t)*.17);overflow:hidden;opacity:0;pointer-events:none;transition:opacity .2s}
.rrring::before{content:"";position:absolute;left:50%;top:50%;width:160%;height:160%;margin:-80% 0 0 -80%;background:conic-gradient(from 0deg,#ffd45a,#ffd45a00 25%,#b88aff 50%,#b88aff00 75%,#ffd45a);animation:rrSpin 1.8s linear infinite}
.rrring::after{content:"";position:absolute;inset:3px;border-radius:calc(var(--t)*.14);background:linear-gradient(180deg,#26203e,#1a1630)}
.rrt.cur .rrring{opacity:1}
.rrt.cur b::after{content:"";position:absolute;left:50%;bottom:calc(var(--t)*-.3);width:calc(var(--t)*.36);height:4px;margin-left:calc(var(--t)*-.18);border-radius:3px;background:linear-gradient(90deg,#ffd45a,#fff3c0,#ffd45a);animation:rrChisel 1.1s ease-in-out infinite}
.rrt.cur b{position:relative;z-index:2;width:1px;height:1px}
.rrt.cur::before{content:"✦";position:absolute;right:12%;top:8%;z-index:3;font:700 calc(var(--t)*.2)/1 Poppins,sans-serif;color:#ffd45a;animation:rrTwinkle 1.4s ease-in-out infinite}
.rrt.gh::before{content:attr(data-gh);position:absolute;inset:0;display:grid;place-items:center;right:auto;top:auto;width:100%;height:100%;font:800 calc(var(--t)*.5)/1 Poppins,sans-serif;color:#7af0b0;opacity:.42;animation:none;text-transform:uppercase}
.rrt.gh.cur::before{content:attr(data-gh)}
.rrt.c{background:linear-gradient(180deg,#3cc274,#22934f);border-color:#6af0a0}.rrt.c b{color:#fff}
.rrt.c::after{box-shadow:0 0 22px #4ae89a77;opacity:1;animation:none}
.rrt.p{background:linear-gradient(180deg,#ecba3a,#c08a12);border-color:#ffe07a}.rrt.p b{color:#fff}
.rrt.p::after{box-shadow:0 0 18px #ffc94a66;opacity:1;animation:none}
.rrt.a{background:linear-gradient(180deg,#6c6779,#4e4a5c);border-color:#827d92}.rrt.a b{color:#f2eef8}
.rrt.a::after{opacity:0;animation:none}
.rrt.pop{animation:rrPop2 .2s cubic-bezier(.3,1.7,.5,1)}
.rrt.won{animation:rrWin .7s cubic-bezier(.3,1.6,.5,1) both;animation-delay:calc(var(--i)*.09s)}
.rr-rm .rrt.won,.rr-rm .rrt.pop,.rr-rm .rrgrid.rrin .rrrw,.rr-rm .rrring::before,.rr-rm .rrt::after,.rr-rm .rrt::before{animation:none!important}
/* keyboard slab */
.rrkbw{position:relative;z-index:2;margin-top:calc(var(--t)*-.28);padding:12px 14px 10px;border-radius:20px;background:linear-gradient(180deg,#14112ef2,#0e0b22f2);border:2px solid #2f2a5a;box-shadow:0 14px 30px #000a,inset 0 1px 0 #ffffff10}
.rrkb{gap:8px}.rrkr{gap:7px}
.rrk{width:var(--k);height:calc(var(--k)*.95);border-radius:12px;font:700 calc(var(--k)*.34) Poppins,sans-serif;text-transform:uppercase;color:#fff;background:linear-gradient(180deg,#2a2562,#1e1a4e);border:2px solid #3d3790;box-shadow:0 4px 0 #0a0820;transition:transform .1s,background .2s}
.rrk:hover{transform:translateY(-2px)}
.rrk.wide{width:calc(var(--k)*1.6);font-size:calc(var(--k)*.28)}
.rrk.c{background:linear-gradient(180deg,#36b86a,#22904c);border-color:#5ae08a}
.rrk.p{background:linear-gradient(180deg,#e6b434,#b8860f);border-color:#ffd96a;color:#fff}
.rrk.a{background:linear-gradient(180deg,#5c5868,#46424f);border-color:#6c687a;color:#d8d4e4;opacity:1}
.rrk.tap{animation:rrTap2 .2s ease}
.rrk.chg{animation:rrKeyIn .45s cubic-bezier(.3,1.6,.5,1)}
.rrkbw{width:max-content;max-width:100%}.rrleg{margin:10px 0 0;width:0;min-width:100%;display:flex;flex-direction:column;align-items:center;gap:6px;font:600 13.5px/1.4 Poppins,sans-serif;color:#c8c0ea}
.rrlg{display:flex;flex-wrap:wrap;justify-content:center;gap:4px 18px}
.rrlh{font:600 15px Poppins,sans-serif;color:#e8e2ff;letter-spacing:.3px}.rrlh u,.rrbon u{text-decoration:none;color:#6a62a8;margin:0 6px}
.rrsw{width:13px;height:13px;border-radius:50%;border:2px solid #12081f}.rrsw.c{background:#3cc274}.rrsw.p{background:#ecba3a}.rrsw.a{background:#6c6779}.rrsw.l{background:#9a3040}.rrsw.t{background:#ffd45a}
.rrlink{font-size:15px}
/* the right panel */
.rrpanel,.rrpowp{position:relative;padding:18px 22px 18px;border-radius:22px;background:linear-gradient(180deg,#17134af0,#0f0c30f0);border:2px solid #3a3480;box-shadow:0 18px 40px #0009,inset 0 1px 0 #ffffff14}
.rrpowp{padding:14px 16px 12px}
.rrorn{position:absolute;width:14px;height:14px;transform:rotate(45deg);background:linear-gradient(135deg,#ffe48a,#c98a10);border:2px solid #12081f}
.rrorn.o1{left:-8px;top:-8px}.rrorn.o2{right:-8px;top:-8px}.rrorn.o3{left:-8px;bottom:-8px}.rrorn.o4{right:-8px;bottom:-8px}
.rrph{margin:0 0 4px;font:800 22px/1.2 Poppins,sans-serif;letter-spacing:2.6px;text-transform:uppercase;color:#ffcf5a}
.rrph span{font-size:16px;vertical-align:2px;margin-right:4px}
.rrpanel .rrey{font-size:12px;color:#b8aef0}
.rrpanel .rrey:not(:first-child){margin-top:14px}
.rrpanel .rrph+.rrey{margin-top:0}
.rrpanel .rrey.rrline{display:flex;align-items:center;gap:10px;color:#ffcf5a}.rrpanel .rrey.rrline::after{content:"";flex:1;height:2px;background:linear-gradient(90deg,#4a42a0,#0000)}
.rrstats{grid-template-columns:minmax(0,1fr) minmax(0,1.45fr) minmax(0,1fr)}.rrstats>div{padding:12px 6px 10px;background:#0b0822;border:2px solid #2a2464}.rrstats b.up{font-size:23px;padding-top:4px}
.rrstats b{font-size:28px;line-height:1.3}
.rrstats small{font-size:11px;color:#a59ce0}
.rrlad{gap:7px}.rrlp{padding:8px 2px 7px;border:2px solid #2c2668}.rrlp small{font-size:11.5px}.rrlp b{font-size:16px}
.rrtrk{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));gap:8px;justify-items:center}
.rrtd{width:44px;height:44px;border-radius:50%;display:grid;place-items:center;font:800 16px Poppins,sans-serif;color:#8a82c0;background:#14113a;border:2px solid #3a3480;position:relative}
.rrtd svg{width:22px;height:22px}
.rrtd.on{color:#2a1604;background:radial-gradient(circle at 35% 30%,#fff3b0,#ffd45a 45%,#d89a14);border-color:#fff0b0}
.rrtd.on::after{content:"";position:absolute;inset:-5px;border-radius:50%;box-shadow:0 0 16px #ffd45a77;opacity:.8}
.rrtd.nx{border:2px dashed #ffd45a;color:#ffd45a}.rrtd.nx::after{content:"";position:absolute;inset:-6px;border-radius:50%;border:2px solid #ffd45a66;animation:rrBreath 1.6s ease-in-out infinite}
.rrtd.gift:not(.on){color:#ffcf5a;border-color:#7a5a20}
.rrtrk.rrcin .rrtd{animation:rrCell .45s cubic-bezier(.3,1.5,.5,1) both;animation-delay:calc(var(--i)*45ms)}
.rrbon{margin:12px 0 14px;font-size:13px;text-align:center}
.rrcalb{width:100%;display:flex;align-items:center;justify-content:center;gap:10px;font-size:17px;padding:12px;border-color:#ffcf5a!important;color:#fff!important;background:linear-gradient(180deg,#1e1a52,#151144)!important}
.rrcalb svg{width:24px;height:24px;color:#ffcf5a}
.rrpow{grid-template-columns:1fr;gap:10px;width:auto;min-width:0}
.rrpb{padding:12px 14px;border-radius:18px;border:2px solid #4a42a0;gap:14px}
.rrpi{width:48px;height:48px;border-radius:14px}.rrpi svg{width:28px;height:28px}
.rrpt b{font-size:18px}.rrpt small{font-size:13.5px}.rrpc{font-size:17px}.rrpc .rrcn{width:20px;height:20px}
.rrpn{margin:2px 0 0;font-size:13px;color:#c8c0ea}
/* calendar modal */
.rrcalc{width:min(500px,100%);text-align:center}
.rrcalnav{display:flex;align-items:center;justify-content:space-between;margin:2px 0 12px;padding:0 40px}
.rrcalnav h2{font-size:36px}
.rrnav{width:40px;height:40px;min-width:0;padding:0;border-radius:12px;font:700 24px/1 Poppins,sans-serif;color:#ffcf5a;background:#1a1650;border:2px solid #3e3790;box-shadow:none;cursor:pointer}
.rrnav:disabled{opacity:.3;cursor:default}
.rrwkd{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));gap:6px;margin-bottom:6px;font:700 11px Poppins,sans-serif;color:#8a82c0;letter-spacing:1px;text-transform:uppercase}
.rrcalc .rrcal{gap:6px}.rrcalc .rrcd{height:44px;font-size:14px;flex-direction:column;gap:0;line-height:1.1}
.rrcd small{font:700 10px Poppins,sans-serif;opacity:.85}
.rrcd.x{background:none;border:0}
.rrcalk{display:flex;justify-content:center;flex-wrap:wrap;gap:6px 16px;margin:12px 0;font:600 12.5px Poppins,sans-serif;color:#c8c0ea}.rrcalk span{display:inline-flex;align-items:center;gap:6px}
.rrstats.sm{grid-template-columns:repeat(4,minmax(0,1fr));margin-bottom:12px}.rrstats.sm b{font-size:22px;line-height:1.3}
.rrcalc .rrdist{text-align:left}
/* keyframes for the sanctum */
@keyframes rrSpin{to{transform:rotate(360deg)}}
@keyframes rrChisel{0%,100%{transform:translateY(0);opacity:.55}50%{transform:translateY(-5px);opacity:1}}
@keyframes rrTwinkle{0%,100%{opacity:.2;transform:scale(.7) rotate(0)}50%{opacity:1;transform:scale(1.15) rotate(30deg)}}
@keyframes rrSock{0%,100%{opacity:.25}50%{opacity:.8}}
@keyframes rrPop2{0%{transform:scale(.8)}60%{transform:scale(1.14)}100%{transform:scale(1)}}
@keyframes rrTap2{0%{transform:translateY(0) scale(1)}40%{transform:translateY(3px) scale(.92)}100%{transform:none}}
@keyframes rrGlowF{0%,100%{opacity:.75;transform:scale(1)}30%{opacity:1;transform:scale(1.05)}55%{opacity:.82;transform:scale(.98)}80%{opacity:.95;transform:scale(1.03)}}
@keyframes rrMote{0%{transform:translate(0,0);opacity:0}10%{opacity:.8}90%{opacity:.5}100%{transform:translate(40px,-900px);opacity:0}}
/* narrow screens (tablets, phones): keeper row on top, then stone, keyboard, powers, panel */
.rr.rr-narrow{padding:16px 16px 24px}
.rr.rr-narrow .rrhd{grid-template-columns:auto minmax(0,1fr) auto}.rr.rr-narrow .rrhd .rrtabs{grid-column:1/-1;grid-row:2;justify-self:center}.rr.rr-narrow .rrhd .rrgold{grid-column:3;grid-row:1}
.rr.rr-narrow .rrmain{grid-template-columns:minmax(0,1fr);justify-items:center;gap:16px}
.rr.rr-narrow .rrboard,.rr.rr-narrow .rrside{display:contents}
.rr.rr-narrow .rrhost{order:0;flex-direction:row;min-height:0;width:100%;max-width:640px;gap:12px;padding:0}
.rr.rr-narrow .rrhost canvas{order:0;width:84px;height:124px;margin:0}
.rr.rr-narrow .rrbub{order:1;flex:1;max-width:none;margin:0;align-self:center}.rr.rr-narrow .rrbub::after{left:-14px;bottom:auto;top:44%;transform:rotate(135deg)}
.rr.rr-narrow .rrhn{display:none}
.rr.rr-narrow .rrarchw{order:1}.rr.rr-narrow .rrkbw{order:2;margin-top:-10px}.rr.rr-narrow .rrpowp{order:3;width:100%;max-width:640px}.rr.rr-narrow .rrpanel{order:4;width:100%;max-width:640px}
.rr.rr-tiny .rrti h1{font-size:40px;white-space:nowrap}#rr.rr-tiny .rrbub{font-size:19px;padding:14px 18px}#rr.rr-tiny .rrwkd{font-size:15px}#rr.rr-tiny .rrcd small{font-size:13px}#rr.rr-tiny .rrcalc .rrcd{height:58px;font-size:18px}#rr.rr-tiny .rrstats.sm small{font-size:13px}#rr.rr-tiny .rrcalk{font-size:16px}#rr.rr-tiny .rrcalnav h2{font-size:42px}#rr.rr-tiny .rrnav{width:52px;height:52px}#rr.rr-tiny .rrph{font-size:26px}#rr.rr-tiny .rrtd{width:56px;height:56px;font-size:20px}#rr.rr-tiny p.rrlh,#rr.rr-tiny .rrlh{font-size:18px}#rr.rr-tiny .rrlg{font-size:16px}.rr.rr-tiny .rrhd{gap:10px 12px}.rr.rr-mid .rrhd{grid-template-columns:auto auto minmax(0,1fr) auto auto}.rr.rr-mid .rrhd .rrtabs{grid-column:4;grid-row:1}.rr.rr-mid .rrhd .rrgold{grid-column:5;grid-row:1}.rr.rr-mid .rrti h1{font-size:42px}.rr.rr-mid .rrmain{grid-template-columns:auto minmax(0,400px);justify-items:stretch;align-items:start}.rr.rr-mid .rrboard{display:flex;grid-column:1;grid-row:1/span 3}.rr.rr-mid .rrside{display:flex;grid-column:2;grid-row:2}.rr.rr-mid .rrhost{grid-column:2;grid-row:1;order:0}.rr.rr-mid .rrkbw{margin-top:-8px}.rr.rr-mid .rrpowp,.rr.rr-mid .rrpanel{width:auto}.rr.rr-mid .rrpanel{order:0}.rr.rr-mid .rrstats b{font-size:22px}.rr.rr-mid .rrstats b.up{font-size:17px}.rr.rr-mid .rrpowp{order:1}.rr.rr-short .rrhd{margin-bottom:6px}.rr.rr-short .rrti h1{font-size:44px}
/* keyframes: transform and opacity only */
@keyframes rrPop{0%{transform:scale(.86)}55%{transform:scale(1.12)}100%{transform:scale(1)}}
@keyframes rrFlip{0%{transform:perspective(500px) rotateX(0)}48%{transform:perspective(500px) rotateX(90deg)}52%{transform:perspective(500px) rotateX(90deg)}100%{transform:perspective(500px) rotateX(0)}}
@keyframes rrShake{0%,100%{transform:translateX(0)}15%{transform:translateX(-10px)}30%{transform:translateX(9px)}45%{transform:translateX(-7px)}60%{transform:translateX(5px)}75%{transform:translateX(-3px)}}
@keyframes rrWin{0%{transform:translateY(0) scale(1)}35%{transform:translateY(-26%) scale(1.08)}65%{transform:translateY(4%) scale(.97)}100%{transform:translateY(0) scale(1)}}
@keyframes rrQuake{0%,100%{transform:translate(0,0)}20%{transform:translate(-6px,2px) rotate(-.4deg)}40%{transform:translate(6px,-2px) rotate(.4deg)}60%{transform:translate(-4px,1px)}80%{transform:translate(3px,0)}}
@keyframes rrRowIn{0%{opacity:0;transform:translateY(14px) scale(.96)}100%{opacity:1;transform:none}}
@keyframes rrSwap{0%{transform:scale(.97);opacity:.6}100%{transform:none;opacity:1}}
@keyframes rrCaret{0%,100%{opacity:.25}50%{opacity:1}}
@keyframes rrGhost{0%{opacity:0;transform:scale(1.6)}60%{opacity:.6;transform:scale(.95)}100%{opacity:.32;transform:none}}
@keyframes rrBreath{0%,100%{opacity:.25;transform:scale(1)}50%{opacity:1;transform:scale(1.04)}}
@keyframes rrCell{0%{opacity:0;transform:scale(.6)}100%{opacity:1;transform:none}}
@keyframes rrBar{0%{transform:scaleX(0)}}
@keyframes rrTap{0%{transform:scale(1)}50%{transform:scale(.88)}100%{transform:scale(1)}}
@keyframes rrKeyIn{0%{transform:scale(.7)}60%{transform:scale(1.14)}100%{transform:scale(1)}}
@keyframes rrShat{0%{transform:scale(1) rotate(0)}25%{transform:scale(1.2) rotate(-8deg)}50%{transform:scale(.9) rotate(6deg)}100%{transform:scale(1) rotate(0)}}
@keyframes rrFire{0%{opacity:0;transform:scale(.6)}40%{opacity:1}100%{opacity:0;transform:scale(1.6)}}
@keyframes rrFade{0%{opacity:0}100%{opacity:1}}
@keyframes rrCard{0%{opacity:0;transform:translateY(24px) scale(.9)}100%{opacity:1;transform:none}}
@keyframes rrBump{0%{transform:scale(1)}40%{transform:scale(1.15)}100%{transform:scale(1)}}
/* touch mode sets body.tm p{font-size:20px}; keep the riddle's own sizes */
#rr p.rrleg,#rr p.rrbon,#rr p.rrnote{font-size:12.5px}#rr p.rrey,#rr p.rrpn{font-size:11.5px}#rr .rrti p{font-size:13.5px}#rr p.rrsub{font-size:14px}#rr p.rrstk{font-size:13px}#rr .rrpay p{font-size:13.5px}#rr .rrpay p.tot{font-size:16px}
/* phones (overlay under 700 wide, shown at about 0.6 scale): larger text and keys */
#rr.rr-tiny p.rrleg,#rr.rr-tiny p.rrbon,#rr.rr-tiny p.rrnote{font-size:17px}#rr.rr-tiny p.rrey,#rr.rr-tiny p.rrpn{font-size:15.5px}#rr.rr-tiny .rrsw{width:16px;height:16px}
#rr.rr-tiny .rrstats b{font-size:30px;line-height:1.3}#rr.rr-tiny .rrstats small{font-size:13px}#rr.rr-tiny .rrlp small{font-size:13px}#rr.rr-tiny .rrlp b{font-size:17px}#rr.rr-tiny .rrcd{height:40px;font-size:16px}
#rr.rr-tiny .rrpt b{font-size:19px}#rr.rr-tiny .rrpt small{font-size:15px}#rr.rr-tiny .rrpc{font-size:17px}#rr.rr-tiny .rrpi{width:46px;height:46px}#rr.rr-tiny .rrpi svg{width:28px;height:28px}
#rr.rr-tiny .rrk{height:66px;font-size:24px}#rr.rr-tiny .rrk.wide{font-size:15px}#rr.rr-tiny .rrtabs button{font-size:16px;padding:12px 20px}#rr.rr-tiny .rrbk,#rr.rr-tiny .rrgold{font-size:19px}
#rr.rr-tiny .rrrc{width:100%;padding:30px 26px 26px}#rr.rr-tiny .rrrc h2{font-size:52px}#rr.rr-tiny p.rrsub{font-size:18px}#rr.rr-tiny .rrword{--t:64px}#rr.rr-tiny .rrpay p{font-size:17px}#rr.rr-tiny .rrpay p.tot{font-size:20px}#rr.rr-tiny .rrpay p.tot b{font-size:28px}
#rr.rr-tiny .rrdr{font-size:15px;grid-template-columns:20px 1fr}#rr.rr-tiny .rrdr i{height:26px}#rr.rr-tiny .rrdr em{font-size:14px}#rr.rr-tiny p.rrstk{font-size:16px}#rr.rr-tiny .rrbtn{font-size:18px;padding:14px 20px}#rr.rr-tiny .rrtoast{font-size:18px}#rr.rr-tiny .rrlink{font-size:16px}
@media (prefers-reduced-motion:reduce){.rr *{animation-duration:.01ms!important;animation-iteration-count:1!important}}
`;document.head.appendChild(st)}
