/* ===== 8.7: menu pass =====
   - Back goes where you came from: Settings, Help, Save Center, Menu background and the calendar, opened from the More sheet or the
     calendar button, return to the screen they were opened over (NAV87 remembers how to reopen the current top-level screen).
   - Nothing important starts under the dock: on pages that still overflow after dkFit's zoom, a bottom row holding a primary action
     (Practice's "Start practice") sticks just above the dock.
   - Modal exits actually fade (the old ".out" rules reused the entrance keyframe with "reverse", which jumps straight to the end).
   - No backdrop-filter anywhere; the scrims that used it become a little more opaque.
   - The global h1 glow loop (an infinite 52px drop-shadow filter animation) is gone; titles keep their static shadow.
   - Stale NEW badges removed (Fishing, Tower, Nebula, Wildcard); the caravan and riddle keep their own seen-flags.
   - Wildcard gets a card in Choose a mode.
   - Campaign act tabs: short labels with the full name and the unlock level in a tooltip.
   - Help text brought up to date (six acts, every current mode, the real shortcuts). */
let NAV87=null;
{const W=name=>{const f=window[name];if(typeof f!=='function')return;window[name]=function(){const a=[...arguments];NAV87=()=>window[name].apply(null,a);return f.apply(this,arguments)}};
 ['armory','upgrades','loadouts','petHall','catalog','bountyBoard','shop','crateHub','campaign','endlessMenu','pracMenu','waMenu','casinoOpen','fishing','wagonMenu','gyMenu','ttMenu','dcMenu'].forEach(W);
 const t0=title;title=function(){NAV87=null;return t0.apply(this,arguments)}}
const nav87Back=()=>{const f=NAV87;return f?()=>{try{f()}catch(e){title()}}:title};
{const m0=moreSheet;moreSheet=function(){const r=m0.apply(this,arguments);try{const sh=document.querySelector('.dks#dkmo')||document.querySelector('#dkmo');if(sh){const back=nav87Back();
  const go=f=>()=>{try{dkClose()}catch(e){}setTimeout(f,0)};const B=(id,f)=>{const b=sh.querySelector('#'+id);if(b)b.onclick=go(f)};
  B('mcl',()=>dailyMenu(back));B('mst',()=>settings(back));B('mhp',()=>help(back));B('mbg',()=>hbgPick(back));B('msv',()=>saveCenter(back))}}catch(e){}return r}}
{const w0=dkWire;dkWire=function(root){const r=w0.apply(this,arguments);try{const c=root.querySelector('#dkcal');if(c)c.onclick=()=>dailyMenu(nav87Back())}catch(e){}return r}}

/* the bottom action row sticks above the dock when the page is still taller than the space left */
function uk87Stick(){try{ov.querySelectorAll('.uk87st').forEach(e=>e.classList.remove('uk87st'));const mn=ov.querySelector(':scope>.mn'),row=ov.querySelector(':scope>.dkrow');if(!mn||!row||ov.classList.contains('hide'))return;
 const z=parseFloat(mn.style.zoom)||1;if(mn.scrollHeight*z<=ov.clientHeight-row.offsetHeight+4)return;
 const last=mn.lastElementChild;if(!last)return;const ok=last.matches('.row')&&[...last.querySelectorAll('button')].some(b=>!b.classList.contains('sm'));if(!ok)return;/* only rows holding a primary action; lone or duplicate Back buttons stay where they are (every such page has a Back at the top) */
 last.classList.add('uk87st');last.style.setProperty('--ukb',Math.round((row.offsetHeight+6)/z)+'px')}catch(e){}}
{const f0=dkFit;dkFit=function(){const r=f0.apply(this,arguments);uk87Stick();return r}}

/* Choose a mode: Wildcard has its own card */
{const m0=modeSheet;modeSheet=function(){const r=m0.apply(this,arguments);try{const sh=document.querySelector('.dks .dkpv[data-v="m"]')||document.querySelector('.dkpv[data-v="m"]'),g=sh&&sh.querySelector('.dkmg');
  if(g&&!sh.querySelector('#dmwc')){const b=document.createElement('button');b.className='dkm dkmwc';b.id='dmwc';b.style.setProperty('--c','#9a7aff');
   b.innerHTML=`<span class="dkmi"><svg viewBox="0 0 60 60" width="58" height="58" aria-hidden="true"><circle cx="30" cy="30" r="27" fill="#1c1446" stroke="#5a4ca0" stroke-width="2"/><g stroke="#12081f" stroke-width="2.4" stroke-linejoin="round"><rect x="13" y="17" width="20" height="28" rx="4" fill="#5ab8ff" transform="rotate(-14 23 31)"/><rect x="26" y="14" width="20" height="28" rx="4" fill="#ffc94a" transform="rotate(10 36 28)"/></g><path d="M36 22l2.2 4.6 5 .7-3.6 3.5.9 5-4.5-2.4-4.5 2.4.9-5-3.6-3.5 5-.7z" fill="#fff8e8" stroke="#12081f" stroke-width="1.6" stroke-linejoin="round"/></svg></span><span class="dkmt"><b>Wildcard</b><small>The Dragon Lounge card game. Play the regulars, friends or Ranked.</small></span><i class="dkchv">›</i>`;
   const k=sh.querySelector('#dmk');if(k&&k.parentNode===g)k.after(b);else g.appendChild(b);
   b.onclick=()=>{try{dkClose(true)}catch(e){}setTimeout(()=>{casinoOpen();try{gameOpen('wc')}catch(e){}},0)}}}catch(e){}return r}}

/* campaign act tabs: "Act II" with the full name and the unlock level in the tooltip; the open act shows its full name */
function cmTabsHTML(act){return ACTS.map((a,i)=>{const lk=i*6+1>P.camp,nm=`Act ${CMROM[i]}: ${a}`,tip=lk?`${nm}. Clear Level ${i*6} to unlock.`:nm;
 return `<button class="cmt${i===act?' on':''}${lk?' lk':''}" data-a="${i}" ${lk?'aria-disabled="true"':''} title="${esc(tip)}" aria-label="${esc(tip)}">${lk?cmi('lock',16):''}<span>${i===act?esc(nm):`Act ${CMROM[i]}`}</span></button>`}).join('')}
function cmBindTabs(){ov.querySelectorAll('.cmt').forEach(el=>{if(el.classList.contains('ast'))return;el.onclick=()=>{const i=+el.dataset.a;if(i===CM.act)return;
 if(el.classList.contains('lk')){el.classList.remove('uk87no');void el.offsetWidth;el.classList.add('uk87no');try{beep(220,.06,'triangle',.25)}catch(e){}return}
 const cur=cmCur();cmSelect(i*6+1<=cur&&cur<=i*6+6?cur:i*6+1)}})}

/* stale NEW labels: Fishing is no longer new; the Tower, Nebula and Wildcard ribbons go too */
{const t0=title;title=function(){const r=t0.apply(this,arguments);try{const k=ov.querySelector('#dkfish .dkcl small');if(k&&/new mode/i.test(k.textContent))k.textContent='TAVERN POND';const f=ov.querySelector('#dkfish');if(f)f.setAttribute('aria-label',f.getAttribute('aria-label').replace(', new mode',''))}catch(e){}return r}}

/* Help: current modes, six acts, the real shortcuts */
try{const fix=(tab,name,txt)=>{const t=HELP[tab],r=t&&t.find(x=>x[0]===name);if(r)r[1]=txt;else if(t)t.push([name,txt])};
 fix('Basics','Esc','Pause in a run, or go back in a menu. Every menu has a Back button, and Esc does the same.');
 fix('Progress','Crates','Monsters and bosses sometimes drop crates. Open them in Shop › Owned crates. Epic and legendary gear is very rare.');
 fix('Progress','Gold','You earn gold from kills, cleared rounds, bosses, finished campaign levels, level ups, the daily riddle, bounties and the calendar. Spend it in the Shop, the Skill tree and the Companion Hall.');
 fix('Modes','Campaign','Thirty hand-built levels in six acts, plus the Astral levels after them. Clear each one to unlock the next, and earn up to three stars.');
 fix('Modes','Casino','Play tab › Choose a mode › Casino, or More › Casino. The house has a small edge, so play with gold you can spare.');
 for(const r of HELP.Modes)r[1]=r[1].replace(/^New! /,'');
 const add=(name,txt)=>{if(!HELP.Modes.some(x=>x[0]===name))HELP.Modes.push([name,txt])};
 add('Runestone Riddle','A new five-letter rune word every day. Type a guess and press Enter: gold runes are in the right place, blue runes are in the word somewhere. Fewer guesses pay more, and a streak earns a bonus. Practice mode has unlimited puzzles for no gold.');
 add('Wildcard','The Dragon Lounge card game, in the Casino. Match the element or the number, stun and hex the regulars, and call WILD! before your last card. Play the bots, friends on the same network, or Ranked.');
 add('Monster Mash','A Halloween event run (while it lasts): an Endless run with a new curse every level and its own crates.');
 add('Trick-or-Treat','Walk a haunted street, knock on doors and type fast to collect candy corn and rewards.');
 HELP.Shortcuts=[['C E P','On the main menu: Campaign, Endless, Practice Range.'],['F W G','Moonlit Fishing, Lantern Caravan, Runestone Riddle.'],['R M',"Warden's Arena (or Starfall Rift), Monster Mash while Halloween lasts."],['A K S X','Armory, Skill tree, Shop, Owned crates.'],['L B O T','Collection, Bounties, Profile, Trophies.'],['D H ,','Daily rewards, How to play, Settings.'],['Enter','Continue your campaign from the main menu.'],['Esc','Back, or pause in a run.'],['Touch','On a phone or tablet an on-screen keyboard appears in every typing mode.']];
}catch(e){}

{const st=document.createElement('style');st.textContent=`
h1{animation:none}
@keyframes uk87out{from{opacity:1}to{opacity:0}}
.hlmod.out{animation:uk87out .18s ease both}.ptmod.out{animation:uk87out .18s ease both}.pthx.out{animation:uk87out .26s ease both}
.pat-wrap.out{animation:uk87out .17s ease both}.rkup.out{animation:uk87out .3s ease-in both}
.sgm,.ar2 .armod,.nzmod,.shmod,#ccm,.pat-wrap,#tvhow,.tvpanel,button.hxc,button.hxb,.mbmod{backdrop-filter:none!important;-webkit-backdrop-filter:none!important}
.sgm,.ar2 .armod,#ccm,.pat-wrap,#tvhow{background:#05030ce8!important}.nzmod,.shmod{background:#05031aea!important}
.tvpanel{background:linear-gradient(180deg,#171038fa,#0e0a28fc)!important}
.uk87st{position:sticky;bottom:var(--ukb,130px);z-index:7}
.row.uk87st{padding:12px 24px 10px;border-radius:18px;background:linear-gradient(180deg,#0c082200,#0c0822e8 34%,#0c0822f0)}
.dkfish .dknew,#dma .dkmnew,.twnew,#ov.gdo .gdt[data-g=wc]::before{display:none!important}
.cmt.lk{cursor:not-allowed}.cmt.uk87no{animation:uk87no .36s cubic-bezier(.3,1.5,.5,1)}
@keyframes uk87no{20%{transform:translateX(-5px)}45%{transform:translateX(4px)}70%{transform:translateX(-2px)}}
.dkmwc .dkmi svg{display:block}
@media (prefers-reduced-motion:reduce){.cmt.uk87no{animation:none}}`;document.head.appendChild(st)}
