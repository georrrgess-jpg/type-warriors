/* ===== THE SHOP: choose, inspect, purchase =====
   A compact crate list on the left, the chosen crate on a torch-lit pedestal in the middle, and the purchase panel on the right.
   The Graveyard Collection has its own entry along the bottom. */
const SHX={sel:'w',swap:0,from:null,buyT:-9,hov:0,msg:''};
const SH_INFO={w:{c:'#ffc04a',r:['Common','Legendary'],em:'sword'},a:{c:'#7ab4ff',r:['Common','Legendary'],em:'shield'},s:{c:'#c08aff',r:['Common','Legendary'],em:'gem'},c:{c:'#8ad8ff',r:['Rare','Mythic'],em:'star'},p:{c:'#ffb02a',r:['Legendary','Mythic'],em:'sun'}};
const shOwned=k=>P[CN[k]]|0;
/* the real odds of a crate, worked out from the same weights the roll uses */
function shOdds(k){const R=['Common','Uncommon','Rare','Epic','Legendary','Mythic'],out={};R.forEach(r=>out[r]=0);
 if(k==='p'){out.Legendary=90;out.Mythic=10;return out}
 if(k==='c')return null;
 const T=k==='a'?AR:WP,o=k==='a'?'ownA':'own';const ks=Object.keys(T).filter(x=>!T[x].pr&&!T[x].hw).filter(x=>k==='a'||(k==='w'?!isSpecial(x):isSpecial(x)&&pathOpen(WP[x].p)));
 const wt=x=>T[x].w*(k==='w'?({Rare:1.4,Epic:2.2}[T[x].r]||1):1)*(P[o][x]&&RKM[T[x].r]>=4?.3:1);let tot=0;for(const x of ks){out[T[x].r]+=wt(x);tot+=wt(x)}for(const r of R)out[r]=tot?out[r]/tot*100:0;return out}
function shItems(k){if(k==='p'){const L=[];for(const id in WP)if(!WP[id].hw&&RKM[WP[id].r]>=4&&(isSpecial(id)?pathOpen(WP[id].p):true))L.push(['w',id]);for(const id in AR)if(!AR[id].pr&&!AR[id].hw&&RKM[AR[id].r]>=4)L.push(['a',id]);return L}
 if(k==='c'){const L=[];for(const id in WP){const w=WP[id];if(RKM[w.r]>=2&&!(w.hw&&!w.cel)&&(!isSpecial(id)||pathOpen(w.p)))L.push(['w',id])}return L}
 const T=k==='a'?AR:WP;return Object.keys(T).filter(x=>!T[x].pr&&!T[x].hw).filter(x=>k==='a'||(k==='w'?!isSpecial(x):isSpecial(x)&&pathOpen(WP[x].p))).map(x=>[k==='a'?'a':'w',x])}
const shIco={coin:'<i class="coin"></i>',check:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5" fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
 book:'<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M3 5c3-1 6-1 9 1 3-2 6-2 9-1v14c-3-1-6-1-9 1-3-2-6-2-9-1z"/><path d="M12 6v14"/></svg>',
 box:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2l9 5v10l-9 5-9-5V7z" fill="#8a94c8" stroke="#1a1430" stroke-width="1.4" stroke-linejoin="round"/><path d="M12 12l9-5M12 12L3 7M12 12v10" stroke="#1a1430" stroke-width="1.4" fill="none"/><path d="M12 2l9 5-9 5-9-5z" fill="#c8d0f0"/></svg>',
 arrow:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 5l7 7-7 7" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></svg>'};
function shop(msg){S.mode='title';S.view='menu';if(!SHOP.some(o=>o.k===SHX.sel))SHX.sel=SHOP[0].k;SHX.msg=msg||'';const hw=typeof hwOn==='function'&&hwOn();
 show(`<div class="shp" id="shp"><header class="shh"><h2>Shop</h2><div class="shgold" id="shgold">${shIco.coin}<b id="shgv">${P.gold.toLocaleString()}</b><span>gold</span></div></header>
 <nav class="shl" id="shl" aria-label="Crates">${SHOP.map((o,i)=>`<button class="shr${o.k===SHX.sel?' on':''}" data-k="${o.k}" style="--c:${(SH_INFO[o.k]||{}).c||'#ffd45a'};--i:${i}"><canvas width="168" height="120" data-sk="${o.k}"></canvas><span class="shrt"><b>${o.n.replace('SPECIAL','Special')}</b><em>${shIco.coin}${price(o.k).toLocaleString()}</em></span><i class="shro" data-own="${o.k}">${shOwned(o.k)?'×'+shOwned(o.k):''}</i><span class="shck">${shIco.check}</span></button>`).join('')}</nav>
 <section class="shs" id="shs"><canvas id="shcv" width="900" height="720"></canvas><div class="shst"><h3 id="shsn"></h3><span class="shrr" id="shrr"></span></div><div class="shown" id="shown"></div><div class="shmsg" id="shmsg"></div></section>
 <aside class="shp2" id="shp2"></aside>
 <div class="shgy${hw?'':' off'}" id="shgy"><canvas width="560" height="150" id="shgyc"></canvas><div class="shgyt"><div><span class="hwlt">LIMITED TIME</span><span class="shdays">${typeof hwLeft==='function'?hwLeft():''}</span></div><b class="hwtxt">Graveyard Collection</b><small>Mythic Halloween gear</small></div><button class="shgyb" id="shgyb">View collection ${shIco.arrow}</button></div>
 <div class="shmod" id="shmod"></div>
 <div class="row"><button class="sm" id="b">Back</button></div></div>`);
 S.back=()=>{const m=$('shmod');if(m&&m.classList.contains('on')){shClose();return}title()};$('b').onclick=S.back;
 /* list icons: every chest idles, the hovered one peeks its lid */
 ov.querySelectorAll('canvas[data-sk]').forEach(cv=>{const k=cv.dataset.sk,g=cv.getContext('2d'),row=cv.parentNode;let h=0;row.addEventListener('pointerenter',()=>{row._h=1;beep(660,.03,'triangle',.25)});row.addEventListener('pointerleave',()=>row._h=0);
  let fr=0;LIVE.push({cv,fn:t=>{h+=((row._h?1:0)-h)*.18;/* idle icons redraw every third frame; the hovered one every frame */if(h<.02&&!row.classList.contains('on')&&(fr++%3))return;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,168,120);NCX.hov=h;try{chest(g,84,104+Math.sin(t*2+k.charCodeAt(0))*1.2-h*4,k==='c'?.66:k==='p'?.6:.66,h*(.19+.02*Math.sin(t*2.2)),k,t)}catch(e){}NCX.hov=0}})});
 ov.querySelectorAll('.shr').forEach(b=>b.onclick=()=>shSelect(b.dataset.k));
 $('shgyb').onclick=shGrave;$('shgy').addEventListener('click',e=>{if(e.target.closest('button'))return;shGrave()});
 shStage();shGyArt();shPanel(false);
 if(SHX.msg)shToast(SHX.msg);
 if(!window.__shk){window.__shk=1;addEventListener('keydown',e=>{if(!document.getElementById('shp')||S.mode!=='title'||e.ctrlKey||e.metaKey||e.altKey)return;const m=$('shmod');if(m&&m.classList.contains('on'))return;
  const ks=SHOP.map(o=>o.k),i=ks.indexOf(SHX.sel);if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();shSelect(ks[(i+(e.key==='ArrowDown'?1:ks.length-1))%ks.length])}else if(e.key==='Enter'){const b=$('shbuy');if(b&&!b.disabled){e.preventDefault();b.click()}}},true)}}
function shSelect(k){if(k===SHX.sel)return;SHX.from=SHX.sel;SHX.sel=k;SHX.swap=performance.now();ov.querySelectorAll('.shr').forEach(b=>b.classList.toggle('on',b.dataset.k===k));beep(520+SHOP.findIndex(o=>o.k===k)*90,.05,'triangle',.4);shPanel(true)}
function shPanel(anim){const k=SHX.sel,o=SHOP.find(x=>x.k===k),I=SH_INFO[k]||{c:'#ffd45a',r:['Common','Legendary']},pr=price(k),after=P.gold-pr,can=after>=0,n=shOwned(k);
 const rc=r=>(typeof RC!=='undefined'&&RC[r])||'#fff';
 $('shsn').textContent=o.n.replace('SPECIAL','Special');$('shrr').innerHTML=`<span style="color:${rc(I.r[0])}">${I.r[0]}</span> – <span style="color:${rc(I.r[1])}">${I.r[1]}</span>`;
 $('shown').innerHTML=`Owned crates · <b>${n}</b>`;
 const p=$('shp2');p.style.setProperty('--c',I.c);
 p.innerHTML=`<div class="shpi${anim?' shpsw':''}"><h3>${o.n.replace('SPECIAL','Special')}</h3><p>${esc(o.d)}</p><div class="shdiv"><i></i><span>✦</span><i></i></div>
  <button class="shodds" id="shodds">${shIco.book}<span>View contents &amp; odds</span>${shIco.arrow}</button>
  <div class="shprice"><span>Price</span><b>${shIco.coin}${pr.toLocaleString()}<small>gold</small></b></div>
  <div class="shafter"><span>Balance after purchase</span><b class="${can?'':'neg'}">${can?after.toLocaleString()+' gold':'Need '+(-after).toLocaleString()+' more'}</b></div>
  <button class="shbuy" id="shbuy" ${can?'':'disabled'}>${shIco.coin}<span>${can?`Buy crate · ${pr.toLocaleString()}`:`Need ${(-after).toLocaleString()} more gold`}</span></button>
  <div class="shownd">${shIco.box}<span>Owned crates · <b id="shon">${n}</b></span>${n?`<button class="shopen" id="shopen">Open now ${shIco.arrow}</button>`:''}</div></div>`;
 $('shodds').onclick=()=>shOddsModal(k);$('shbuy').onclick=()=>shBuy(k);if($('shopen'))$('shopen').onclick=()=>{if(shOwned(k)>0)crateStart(k)}}
function shBuy(k){const pr=price(k);if(P.gold<pr)return;P.gold-=pr;P[CN[k]]=(P[CN[k]]|0)+1;save();SHX.buyT=performance.now();
 try{beep(880,.1,'triangle',.7);setTimeout(()=>beep(1320,.16,'triangle',.6),90);setTimeout(()=>beep(1760,.2,'sine',.4),180)}catch(e){}
 const gv=$('shgv');if(gv){gv.textContent=P.gold.toLocaleString();const g=$('shgold');g.classList.remove('hit');void g.offsetWidth;g.classList.add('hit')}
 ov.querySelectorAll(`[data-own="${k}"]`).forEach(x=>{x.textContent='×'+shOwned(k);x.classList.remove('pop');void x.offsetWidth;x.classList.add('pop')});
 /* coins fly from the buy button to the gold counter */
 const b=$('shbuy'),to=$('shgold');if(b&&to){const a=b.getBoundingClientRect(),z=to.getBoundingClientRect();for(let i=0;i<10;i++){const c=document.createElement('i');c.className='shfc';document.body.appendChild(c);const sx=a.left+a.width/2+(Math.random()-.5)*80,sy=a.top+a.height/2,mx=(sx+z.left)/2+(Math.random()-.5)*200,my=Math.min(sy,z.top)-80-Math.random()*80;
  c.animate([{transform:`translate(${z.left+20}px,${z.top+z.height/2}px) scale(.5)`,opacity:0},{transform:`translate(${mx}px,${my}px) scale(1)`,opacity:1,offset:.45},{transform:`translate(${sx}px,${sy}px) scale(.4)`,opacity:0}],{duration:600+i*40,easing:'cubic-bezier(.4,0,.6,1)',fill:'forwards'}).onfinish=()=>c.remove()}}
 shToast(`Bought one ${SHOP.find(o=>o.k===k).n.replace('SPECIAL','Special').toLowerCase()}. Open it here or from the Crates screen.`);shPanel(false)}
function shToast(t){const m=$('shmsg');if(!m)return;m.textContent=t;m.classList.remove('on');void m.offsetWidth;m.classList.add('on')}
function shClose(){const m=$('shmod');if(!m)return;m.classList.remove('on');m.innerHTML=''}
function shOddsModal(k){const o=SHOP.find(x=>x.k===k),od=shOdds(k),items=shItems(k),T=t2=>t2==='a'?AR:WP,R=['Common','Uncommon','Rare','Epic','Legendary','Mythic'],m=$('shmod');
 const bars=od?R.filter(r=>od[r]>0).map(r=>`<div class="shob" style="--c:${RC[r]}"><span>${r}</span><i><em style="width:${Math.max(1.5,od[r])}%"></em></i><b>${od[r]>=1?od[r].toFixed(1):od[r].toFixed(2)}%</b></div>`).join(''):`<p class="shfine">Rare or better, every time. The exact odds of this chest are a celestial secret.</p>`;
 const grp=R.map(r=>{const L=items.filter(([t2,id])=>T(t2)[id].r===r);if(!L.length)return'';return `<div class="shig"><h4 style="color:${RC[r]}">${r} <small>${L.filter(([t2,id])=>(t2==='a'?P.ownA:P.own)[id]).length} / ${L.length} owned</small></h4><div>${L.map(([t2,id])=>{const own=(t2==='a'?P.ownA:P.own)[id];return `<span class="${own?'own':''}" style="--c:${RC[r]}">${own?'✓ ':''}${esc(T(t2)[id].n)}</span>`}).join('')}</div></div>`}).join('');
 m.innerHTML=`<div class="shmc"><button class="shx" aria-label="Close">×</button><h3>${o.n.replace('SPECIAL','Special')}</h3><p class="shfine">${esc(o.d)}</p><div class="shobs">${bars}</div>${k==='w'||k==='a'||k==='s'?`<p class="shfine">An Epic or better drop is guaranteed within ${PITY()} crates. Gear you already own at Legendary or above is less likely to repeat.</p>`:k==='p'?'<p class="shfine">Favors gear you do not own yet.</p>':''}<div class="shis">${grp}</div></div>`;
 m.classList.add('on');m.querySelector('.shx').onclick=shClose;m.onclick=e=>{if(e.target===m)shClose()};beep(620,.05,'triangle',.4)}
function shGrave(){if(typeof hwShopHTML!=='function')return;const m=$('shmod');m.innerHTML=`<div class="shmc wide gy"><button class="shx" aria-label="Close">×</button>${hwShopHTML()}</div>`;m.classList.add('on');m.querySelector('.shx').onclick=shClose;m.onclick=e=>{if(e.target===m)shClose()};try{hwShopBind()}catch(e){}beep(520,.06,'triangle',.4)}

/* ---------- the stage: stone arch, banners, torches, pedestal and the chosen chest ---------- */
let SH_BG=null;
function shBuildBG(w,h){const c=document.createElement('canvas');c.width=w;c.height=h;const g=c.getContext('2d');
 let q=g.createLinearGradient(0,0,0,h);q.addColorStop(0,'#1a1030');q.addColorStop(.6,'#120a22');q.addColorStop(1,'#080512');g.fillStyle=q;g.fillRect(0,0,w,h);
 /* stone wall blocks */
 g.strokeStyle='#ffffff0d';g.lineWidth=2;for(let y=0;y<h*.7;y+=46){g.beginPath();g.moveTo(0,y);g.lineTo(w,y);g.stroke();for(let x=(y/46%2)*60;x<w;x+=120){g.beginPath();g.moveTo(x,y);g.lineTo(x,y+46);g.stroke()}}
 /* the great arch */
 const ax=w/2,ar=w*.3,ay=h*.36;g.fillStyle='#0a0616';g.beginPath();g.moveTo(ax-ar,h*.78);g.lineTo(ax-ar,ay);g.arc(ax,ay,ar,Math.PI,0);g.lineTo(ax+ar,h*.78);g.closePath();g.fill();
 q=g.createRadialGradient(ax,ay+40,10,ax,ay+40,ar*1.2);q.addColorStop(0,'#3a2458');q.addColorStop(1,'#0a061600');g.fillStyle=q;g.fill();
 g.lineWidth=26;g.strokeStyle='#2a2040';g.beginPath();g.moveTo(ax-ar,h*.78);g.lineTo(ax-ar,ay);g.arc(ax,ay,ar,Math.PI,0);g.lineTo(ax+ar,h*.78);g.stroke();
 g.lineWidth=3;g.strokeStyle='#4a3a6a';for(let i=0;i<=12;i++){const a=Math.PI+i*Math.PI/12;g.beginPath();g.moveTo(ax+Math.cos(a)*(ar-13),ay+Math.sin(a)*(ar-13));g.lineTo(ax+Math.cos(a)*(ar+13),ay+Math.sin(a)*(ar+13));g.stroke()}
 /* pillars at the sides */
 for(const x of[w*.08,w*.92]){q=g.createLinearGradient(x-34,0,x+34,0);q.addColorStop(0,'#1a1228');q.addColorStop(.5,'#3a2c52');q.addColorStop(1,'#140e22');g.fillStyle=q;g.fillRect(x-34,0,68,h*.82);g.fillStyle='#ffffff12';g.fillRect(x-20,0,6,h*.82)}
 /* floor and steps */
 q=g.createLinearGradient(0,h*.72,0,h);q.addColorStop(0,'#1e1430');q.addColorStop(1,'#0a0614');g.fillStyle=q;g.fillRect(0,h*.72,w,h*.28);
 g.strokeStyle='#ffffff10';g.lineWidth=2;for(let i=0;i<5;i++){const y=h*.76+i*i*7;g.beginPath();g.moveTo(0,y);g.lineTo(w,y);g.stroke()}
 /* pedestal */
 const py=h*.79;for(const [rx,ry,dy,c0,c1] of[[w*.34,40,30,'#2a2238','#14101e'],[w*.3,34,8,'#4a3e5e','#2a2238'],[w*.26,28,-12,'#6a5a82','#3a2e50']]){g.fillStyle=c1;g.beginPath();g.ellipse(ax,py+dy+14,rx,ry,0,0,Math.PI*2);g.fill();q=g.createLinearGradient(0,py+dy-ry,0,py+dy+ry);q.addColorStop(0,c0);q.addColorStop(1,c1);g.fillStyle=q;g.beginPath();g.ellipse(ax,py+dy,rx,ry,0,0,Math.PI*2);g.fill();g.strokeStyle='#ffffff22';g.lineWidth=2;g.stroke()}
 g.strokeStyle='#e8c36a55';g.lineWidth=2;g.setLineDash([6,10]);g.beginPath();g.ellipse(ax,py-12,w*.22,22,0,0,Math.PI*2);g.stroke();g.setLineDash([]);
 /* red carpet down the steps */
 g.fillStyle='#5a0e1e';g.beginPath();g.moveTo(ax-w*.09,py+30);g.lineTo(ax+w*.09,py+30);g.lineTo(ax+w*.14,h);g.lineTo(ax-w*.14,h);g.closePath();g.fill();g.strokeStyle='#c8963a';g.lineWidth=3;g.stroke();
 g.strokeStyle='#c8963a88';g.lineWidth=3;g.beginPath();g.moveTo(ax,py+58);g.lineTo(ax,py+120);g.moveTo(ax-14,py+72);g.lineTo(ax+14,py+72);g.stroke();for(const s of[-1,1]){g.beginPath();g.moveTo(ax+s*8,py+122);g.quadraticCurveTo(ax+s*34,py+108,ax+s*30,py+70);g.stroke()}
 return c}
function shBanner(g,x,y,w,h,c,em,t){const sw=Math.sin(t*1.3+x)*3;g.save();g.translate(x,y);g.fillStyle='#3a2a18';g.fillRect(-w/2-6,-6,w+12,8);
 g.beginPath();g.moveTo(-w/2,0);g.lineTo(w/2,0);g.lineTo(w/2+sw*.3,h);g.lineTo(sw,h-22);g.lineTo(-w/2+sw*.3,h);g.closePath();const q=g.createLinearGradient(0,0,0,h);q.addColorStop(0,'#6a1a2a');q.addColorStop(1,'#3a0a16');g.fillStyle=q;g.fill();g.strokeStyle='#c8963a';g.lineWidth=3;g.stroke();
 g.translate(sw*.5,h*.42);g.strokeStyle=c;g.fillStyle=c;g.lineWidth=4;g.lineCap='round';g.globalAlpha=.85;
 if(em==='sword'){g.beginPath();g.moveTo(0,-34);g.lineTo(0,26);g.moveTo(-12,14);g.lineTo(12,14);g.stroke()}
 else if(em==='shield'){g.beginPath();g.moveTo(0,-26);g.lineTo(18,-18);g.lineTo(16,6);g.quadraticCurveTo(10,22,0,28);g.quadraticCurveTo(-10,22,-16,6);g.lineTo(-18,-18);g.closePath();g.stroke()}
 else if(em==='gem'){g.beginPath();g.moveTo(0,-26);g.lineTo(18,0);g.lineTo(0,26);g.lineTo(-18,0);g.closePath();g.stroke();g.beginPath();g.moveTo(-18,0);g.lineTo(18,0);g.stroke()}
 else if(em==='star'){g.beginPath();for(let i=0;i<8;i++){const a=-Math.PI/2+i*Math.PI/4,r=i%2?8:26;g.lineTo(Math.cos(a)*r,Math.sin(a)*r)}g.closePath();g.stroke()}
 else{g.beginPath();g.arc(0,0,16,0,Math.PI*2);g.stroke();for(let i=0;i<8;i++){const a=i*Math.PI/4;g.beginPath();g.moveTo(Math.cos(a)*22,Math.sin(a)*22);g.lineTo(Math.cos(a)*30,Math.sin(a)*30);g.stroke()}}
 g.restore()}
function shTorch(g,x,y,t,s){g.save();g.translate(x,y);g.scale(s,s);g.fillStyle='#2a1e14';g.beginPath();g.moveTo(-14,0);g.lineTo(14,0);g.lineTo(6,40);g.lineTo(-6,40);g.closePath();g.fill();g.fillStyle='#5a4a3a';g.fillRect(-16,-6,32,8);
 const f=Math.sin(t*11+x)*2+Math.sin(t*7.3)*1.5;g.globalCompositeOperation='lighter';ncGlow(g,0,-24,110+f*4,'#ff8a2a40');
 g.fillStyle='#ff6a1a';g.beginPath();g.moveTo(-12,-2);g.quadraticCurveTo(-16,-26,f*.6,-52-f*2);g.quadraticCurveTo(16,-26,12,-2);g.closePath();g.fill();
 g.fillStyle='#ffd45a';g.beginPath();g.moveTo(-7,-2);g.quadraticCurveTo(-9,-18,f*.4,-34-f);g.quadraticCurveTo(9,-18,7,-2);g.closePath();g.fill();
 g.fillStyle='#fff6d0';g.beginPath();g.ellipse(0,-10,4,8,0,0,Math.PI*2);g.fill();
 for(let i=0;i<3;i++){const v=(t*.8+i/3+x*.01)%1;g.globalAlpha=1-v;g.fillStyle='#ffb04a';g.fillRect(Math.sin(t*3+i*2)*8-1.5,-30-v*60,3,3)}g.restore()}
function shStage(){const cv=$('shcv');if(!cv)return;const g=cv.getContext('2d'),w=cv.width,h=cv.height;SH_BG=shBuildBG(w,h);let hov=0,hv=0;
 cv.addEventListener('pointerenter',()=>hov=1);cv.addEventListener('pointerleave',()=>hov=0);
 cv.addEventListener('click',()=>{SHX.buyT=performance.now()-400;beep(740,.05,'triangle',.4)});
 const motes=Array.from({length:26},(_,i)=>[Math.random(),Math.random(),Math.random()]);
 LIVE.push({cv,fn:t=>{const k=SHX.sel,I=SH_INFO[k]||{c:'#ffd45a',em:'sword'},now=performance.now();hv+=(hov-hv)*.12;
  g.setTransform(1,0,0,1,0,0);g.drawImage(SH_BG,0,0);
  shBanner(g,w*.22,h*.08,84,200,I.c,I.em,t);shBanner(g,w*.78,h*.08,84,200,I.c,I.em,t);
  shTorch(g,w*.16,h*.5,t,1.15);shTorch(g,w*.84,h*.5,t+1.7,1.15);
  /* a column of light in the chest's colour */
  g.save();g.globalCompositeOperation='lighter';const lq=g.createLinearGradient(0,0,0,h*.8);lq.addColorStop(0,I.c+'00');lq.addColorStop(1,I.c+'30');g.fillStyle=lq;g.beginPath();g.moveTo(w/2-70,0);g.lineTo(w/2+70,0);g.lineTo(w/2+200,h*.8);g.lineTo(w/2-200,h*.8);g.closePath();g.fill();ncGlow(g,w/2,h*.62,260,I.c+'38');g.restore();
  /* dust motes in the light */
  g.save();g.globalCompositeOperation='lighter';for(const m of motes){const y=((m[1]-t*.02*(.5+m[2]))%1+1)%1,x=w/2+(m[0]-.5)*300*(.4+y);g.globalAlpha=.25+.35*Math.sin(t*2+m[2]*9)**2;g.fillStyle=I.c;g.fillRect(x,y*h*.8,2,2)}g.restore();
  /* the chest: drops onto the pedestal when chosen, hops when bought, peeks when hovered */
  const se=Math.min(1,(now-SHX.swap)/650),drop=se<1?Math.pow(1-se,2)*-260:0,bo=se<1&&se>.55?Math.sin((se-.55)/.45*Math.PI)*-14:0,be=(now-SHX.buyT)/700,hop=be>=0&&be<1?-Math.sin(be*Math.PI)*46:0,sq=be>=0&&be<.18?1-be*.6:1;
  const by=h*.77+Math.sin(t*1.6)*4+drop+bo+hop,sc=(k==='c'?2.05:k==='p'?1.9:2.1)*(1+hv*.03),lid=Math.max(hv*(.2+.025*Math.sin(t*2.2)),be>=0&&be<1?Math.sin(be*Math.PI)*.32:0);
  g.save();g.globalAlpha=Math.min(1,se*2.5);NCX.hov=Math.max(hv,be>=0&&be<1?1-be:0);try{g.translate(w/2,by);g.scale(1,sq);chest(g,0,0,sc,lid,k,t)}catch(e){}NCX.hov=0;g.restore();
  if(se<1&&se>.5&&se<.62){/* landing dust */g.save();g.globalAlpha=.6;g.fillStyle='#c8b8e0';for(let i=0;i<14;i++){const a=i/14*Math.PI*2;g.fillRect(w/2+Math.cos(a)*150*(se-.4)*4,h*.78+Math.sin(a)*14,3,3)}g.restore()}
  if(be>=0&&be<1){/* sparkle burst on purchase */g.save();g.globalCompositeOperation='lighter';for(let i=0;i<18;i++){const a=i/18*Math.PI*2+be,r=60+be*220;g.globalAlpha=1-be;ncStar(g,w/2+Math.cos(a)*r,h*.6+Math.sin(a)*r*.6,6*(1-be)+2,i%2?'#fff6d0':I.c)}g.restore()}}});}
function shGyArt(){const cv=$('shgyc');if(!cv)return;const g=cv.getContext('2d'),w=cv.width,h=cv.height;
 LIVE.push({cv,fn:t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,w,h);
  g.save();g.globalCompositeOperation='lighter';ncGlow(g,w*.42,h*.22,70,'#c8d8ff55');g.restore();g.fillStyle='#d8e0f0';g.beginPath();g.arc(w*.42,h*.24,22,0,Math.PI*2);g.fill();g.fillStyle='#b8c4dc';g.beginPath();g.arc(w*.42-6,h*.24-4,5,0,Math.PI*2);g.arc(w*.42+8,h*.24+6,4,0,Math.PI*2);g.fill();
  g.fillStyle='#1a0e2a';g.beginPath();g.moveTo(0,h);g.quadraticCurveTo(w*.3,h*.62,w*.6,h*.78);g.quadraticCurveTo(w*.8,h*.86,w,h*.7);g.lineTo(w,h);g.closePath();g.fill();
  for(const [x,s] of[[.54,1],[.66,.8],[.76,.9],[.88,.7]]){g.save();g.translate(w*x,h*.82);g.scale(s,s);g.fillStyle='#3a2e4e';g.beginPath();g.moveTo(-14,10);g.lineTo(-14,-22);g.arc(0,-22,14,Math.PI,0);g.lineTo(14,10);g.closePath();g.fill();g.strokeStyle='#5a4a72';g.lineWidth=2;g.stroke();g.restore()}
  g.strokeStyle='#2a1e3a';g.lineWidth=3;for(let x=w*.05;x<w*.5;x+=16){g.beginPath();g.moveTo(x,h*.95);g.lineTo(x,h*.72);g.stroke()}g.beginPath();g.moveTo(w*.04,h*.78);g.lineTo(w*.5,h*.78);g.stroke();
  /* the jack-o-lantern */
  const px=w*.22,py=h*.66,fl=.8+.2*Math.sin(t*9)+.1*Math.sin(t*23);g.save();g.globalCompositeOperation='lighter';ncGlow(g,px,py,70*fl,'#ff8a2a66');g.restore();
  for(const [dx,rw] of[[-18,22],[18,22],[0,26]]){g.fillStyle=dx?'#d8641a':'#f07a22';g.beginPath();g.ellipse(px+dx,py,rw,30,0,0,Math.PI*2);g.fill();g.strokeStyle='#5a1e08';g.lineWidth=2;g.stroke()}
  g.fillStyle='#4a6a1a';g.fillRect(px-3,py-38,7,12);g.fillStyle=`rgba(255,${200+fl*40|0},80,1)`;for(const s of[-1,1]){g.beginPath();g.moveTo(px+s*8,py-14);g.lineTo(px+s*20,py-12);g.lineTo(px+s*13,py-2);g.closePath();g.fill()}
  g.beginPath();g.moveTo(px-22,py+6);g.lineTo(px-12,py+12);g.lineTo(px-6,py+6);g.lineTo(px,py+14);g.lineTo(px+6,py+6);g.lineTo(px+12,py+12);g.lineTo(px+22,py+6);g.quadraticCurveTo(px,py+30,px-22,py+6);g.fill();
  /* bats */
  for(let i=0;i<3;i++){const bx=w*(.6+i*.12)+Math.sin(t*.7+i)*20,by=h*(.22+i*.06)+Math.sin(t*3+i)*5,wv=Math.sin(t*12+i)*6;g.fillStyle='#0a0614';g.beginPath();g.moveTo(bx,by);g.quadraticCurveTo(bx-8,by-6-wv,bx-16,by+wv*.4);g.quadraticCurveTo(bx-8,by+1,bx,by+3);g.quadraticCurveTo(bx+8,by+1,bx+16,by+wv*.4);g.quadraticCurveTo(bx+8,by-6-wv,bx,by);g.fill()}},slow:1})}

/* the Crates screen: chests lift and glow when hovered */
{const ch0=crateHub;crateHub=function(){ch0.apply(this,arguments);try{ov.querySelectorAll('.chub .cc').forEach(cc=>{cc.addEventListener('pointerenter',()=>cc._h=1);cc.addEventListener('pointerleave',()=>cc._h=0)});
  for(const L of LIVE){const cv=L.cv,k=cv&&cv.dataset&&cv.dataset.c;if(!k||!NC_DRAW[k])continue;const cc=cv.closest('.cc');if(!cc)continue;const g=cv.getContext('2d');let h=0;
   L.fn=t=>{h+=((cc._h?1:0)-h)*.25;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,cv.width,cv.height);NCX.hov=h;try{chest(g,cv.width/2,cv.height-14-h*6,1.08,h*(.19+.02*Math.sin(t*2.2)),k,t)}catch(e){}NCX.hov=0};L.slow=0;let fr=0;const f0=L.fn;L.fn=t=>{if(!cc._h&&(fr++%2))return;f0(t)}}}catch(e){}}}

/* ---------- styles ---------- */
{const st=document.createElement('style');st.textContent=`
.shp{--gd:#e8c36a;position:relative;display:grid;grid-template-columns:minmax(250px,330px) minmax(0,1fr) minmax(290px,380px);grid-template-rows:auto minmax(0,1fr) auto;gap:14px 16px;width:100%;max-width:1500px;margin:0 auto;padding-bottom:70px;text-align:left}
.shp>.row{display:none}
.shh{grid-column:1/-1;display:flex;align-items:center;gap:20px;padding-right:170px;min-height:58px}
.shh h2{margin:0;font:400 58px/1 'Pirata One',Georgia,serif;color:#ffd45a;text-shadow:0 3px 0 #3a1a00,0 0 22px #ffb02a55}
.shgold{margin-left:auto;display:flex;align-items:center;gap:10px;padding:8px 22px 8px 12px;border-radius:30px;background:linear-gradient(180deg,#1e1640,#120c2a);border:2px solid #4a3e7a;box-shadow:0 6px 16px #000a}
.shgold .coin{width:34px;height:34px}.shgold b{font:800 30px var(--ui);color:#ffd45a}.shgold span{font:600 24px var(--ui);color:#ffe9a0}
.shgold.hit{animation:shhit .5s cubic-bezier(.3,1.8,.5,1)}@keyframes shhit{40%{transform:scale(1.1);box-shadow:0 0 30px #ffd45a}}
/* crate list */
.shl{grid-column:1;grid-row:2;display:flex;flex-direction:column;gap:10px;min-height:0}
.shr{all:unset;box-sizing:border-box;position:relative;display:flex;align-items:center;gap:12px;padding:8px 14px 8px 8px;border-radius:16px;cursor:pointer;background:linear-gradient(180deg,#1a1438f2,#0e0a24f6);border:2px solid #3a3070;box-shadow:0 6px 14px #0009;transition:transform .18s,border-color .2s,box-shadow .2s,background .2s;animation:shin .45s cubic-bezier(.2,1.2,.4,1) calc(var(--i)*.05s) both}
@keyframes shin{from{opacity:0;transform:translateX(-24px)}}
.shr:hover{transform:translateX(4px);border-color:color-mix(in srgb,var(--c) 60%,#3a3070)}
.shr.on{border-color:#ffd45a;background:linear-gradient(180deg,#2a2050,#16103a);box-shadow:0 0 0 2px #ffd45a55,0 0 24px #ffd45a55,0 8px 18px #000a}
.shr canvas{flex:none;width:96px;height:69px;border-radius:12px;background:radial-gradient(circle at 50% 70%,color-mix(in srgb,var(--c) 26%,#140e2a),#0a0618);border:1px solid #ffffff14}
.shrt{display:flex;flex-direction:column;line-height:1.05;min-width:0}.shrt b{font:400 27px 'Pirata One',Georgia,serif;color:#fff0d0;white-space:nowrap}.shrt em{display:flex;align-items:center;gap:6px;font:800 19px var(--ui);font-style:normal;color:#ffd45a}.shrt .coin{width:20px;height:20px}
.shro{position:absolute;right:52px;top:8px;font:800 12px var(--ui);font-style:normal;color:#9ff0c8}.shro.pop{animation:shhit .5s cubic-bezier(.3,1.8,.5,1)}
.shck{margin-left:auto;flex:none;display:grid;place-items:center;width:34px;height:34px;border-radius:50%;background:linear-gradient(180deg,#fff0a0,#e0a020);color:#2a1406;box-shadow:0 0 14px #ffd45a88;opacity:0;transform:scale(.4);transition:opacity .2s,transform .3s cubic-bezier(.3,1.8,.5,1)}.shck svg{width:22px;height:22px}
.shr.on .shck{opacity:1;transform:none}
/* stage */
.shs{grid-column:2;grid-row:2;min-height:440px;position:relative;border-radius:22px;overflow:hidden;border:2px solid #3a3070;box-shadow:0 12px 30px #000c;min-height:0;background:#0a0616}
.shs canvas{position:absolute;inset:0;display:block;width:100%;height:100%;object-fit:cover;cursor:pointer}
.shst{position:absolute;left:0;right:0;top:16px;display:flex;flex-direction:column;align-items:center;gap:8px;pointer-events:none}
.shst h3{margin:0;font:400 56px/1 'Pirata One',Georgia,serif;color:#ffd45a;background:linear-gradient(180deg,#fff0a0,#ffc040 55%,#d88a1a);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;filter:drop-shadow(0 3px 0 #2a1000) drop-shadow(0 0 20px #000)}
.shrr{padding:4px 16px;border-radius:20px;background:#0a0618cc;border:1.5px solid #c8b8e088;font:700 16px var(--ui);color:#e8e0ff}
.shown{position:absolute;left:50%;bottom:16px;transform:translateX(-50%);padding:7px 26px;border-radius:20px;background:#0a0618d8;border:1.5px solid #8a7cd888;font:600 16px var(--ui);color:#e8e0ff;white-space:nowrap}.shown b{color:#fff}
.shmsg{position:absolute;left:50%;top:118px;transform:translateX(-50%);max-width:90%;padding:8px 18px;border-radius:14px;background:#0f2a1ae6;border:1.5px solid #5affa0aa;font:600 15px var(--ui);color:#c8ffd8;opacity:0;pointer-events:none;text-align:center}
.shmsg.on{animation:shmsg 3.6s ease forwards}@keyframes shmsg{0%{opacity:0;transform:translate(-50%,-10px)}8%,80%{opacity:1;transform:translate(-50%,0)}100%{opacity:0}}
/* purchase panel */
.shp2{--c:#ffd45a;grid-column:3;grid-row:2;position:relative;padding:22px 22px 18px;border-radius:20px;background:linear-gradient(180deg,#1a1438f4,#0c0820f8);border:2px solid #3a3070;box-shadow:0 12px 30px #000c;min-height:0}
.shpi{display:flex;flex-direction:column;gap:14px;height:100%}.shpi.shpsw{animation:shsw .35s ease}@keyframes shsw{from{opacity:0;transform:translateY(10px)}}
.shpi h3{margin:0;font:400 46px/1 'Pirata One',Georgia,serif;color:#fff4dc}
.shpi p{margin:0;font:500 16px/1.45 var(--ui);color:#d4cef0}
.shdiv{display:flex;align-items:center;gap:10px;color:#ffd45a}.shdiv i{flex:1;height:1px;background:linear-gradient(90deg,transparent,#ffffff33,transparent)}
.shodds{all:unset;box-sizing:border-box;cursor:pointer;display:flex;align-items:center;gap:12px;padding:13px 16px;border-radius:14px;font:700 17px var(--ui);color:#fff;background:linear-gradient(180deg,#262066,#18144a);border:1.5px solid #5a50a8;transition:transform .15s,border-color .15s}
.shodds svg{width:24px;height:24px}.shodds svg:last-child{margin-left:auto;color:#c8c2f0}.shodds:hover{transform:translateX(3px);border-color:var(--gd)}
.shprice{display:flex;align-items:center;justify-content:space-between;margin-top:6px}.shprice span{font:700 18px var(--ui);color:#c8c2f0}
.shprice b{display:flex;align-items:center;gap:8px;font:800 34px var(--ui);color:#ffd45a}.shprice b small{font:600 22px var(--ui);color:#ffe9a0}.shprice .coin{width:32px;height:32px}
.shafter{display:flex;justify-content:space-between;align-items:center;padding-top:10px;border-top:1px solid #ffffff22;font:600 15px var(--ui);color:#c8c2f0}.shafter b{color:#ffe9a0}.shafter b.neg{color:#ff9aa8}
.shbuy{all:unset;box-sizing:border-box;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:12px;padding:14px 18px;margin-top:4px;border-radius:16px;font:800 25px var(--ui);color:#2a1406;background:linear-gradient(180deg,#fff0a0,#f4b020 55%,#d88a10);border:2px solid #fff4b8;box-shadow:0 6px 0 #7a4a08,0 10px 22px #000a,0 0 24px #ffc94a55,inset 0 2px 0 #fffbe0;transition:transform .12s,filter .15s;animation:shbuy 2.4s ease-in-out infinite}
.shbuy .coin{width:30px;height:30px}.shbuy:hover:not(:disabled){transform:translateY(-2px);filter:brightness(1.08)}.shbuy:active:not(:disabled){transform:translateY(4px);box-shadow:0 2px 0 #7a4a08}
@keyframes shbuy{50%{box-shadow:0 6px 0 #7a4a08,0 10px 22px #000a,0 0 38px #ffc94aaa,inset 0 2px 0 #fffbe0}}
.shbuy:disabled{cursor:default;animation:none;font-size:19px;color:#e8e8f4;background:linear-gradient(180deg,#5a5a74,#34344c);border-color:#8a8aa8;box-shadow:0 5px 0 #1a1a2a}
.shownd{display:flex;align-items:center;gap:10px;padding:10px 14px;border-radius:14px;background:#0a0618aa;border:1.5px solid #3a3070;font:600 15px var(--ui);color:#d4cef0}.shownd svg{width:22px;height:22px}.shownd b{color:#fff}
.shopen{all:unset;cursor:pointer;margin-left:auto;display:flex;align-items:center;gap:4px;padding:6px 12px;border-radius:10px;font:800 14px var(--ui);color:#2a1406;background:linear-gradient(180deg,#9fffc8,#3ad88a);box-shadow:0 3px 0 #0a5a2a}.shopen svg{width:16px;height:16px}.shopen:hover{filter:brightness(1.1)}
/* graveyard entry */
.shgy{grid-column:1/-1;grid-row:3;position:relative;display:flex;align-items:center;gap:20px;height:132px;padding:0 26px 0 0;border-radius:18px;overflow:hidden;cursor:pointer;background:radial-gradient(ellipse at 30% 30%,#3a1a5a,#170a2a 60%,#0c0618);border:2px solid #ff4d94aa;box-shadow:0 0 26px #ff4d9433,0 10px 24px #000a;transition:transform .2s,box-shadow .2s}
.shgy:hover{transform:translateY(-2px);box-shadow:0 0 40px #ff4d9466,0 12px 26px #000a}.shgy.off{filter:saturate(.4);border-color:#6a5a8a}
.shgy canvas{flex:none;height:100%;width:auto;aspect-ratio:560/150}
.shgyt{flex:1;display:flex;flex-direction:column;align-items:center;gap:2px;text-align:center}.shgyt>div{display:flex;gap:8px;align-items:center}.shdays{padding:3px 10px;border-radius:12px;background:#0a0618aa;font:700 13px var(--ui);color:#7affc8}
.shgyt b{font:400 44px/1.05 'Pirata One',Georgia,serif}.shgyt small{font:500 17px var(--ui);color:#d4cef0}
.shgyb{all:unset;box-sizing:border-box;cursor:pointer;display:flex;align-items:center;gap:10px;padding:14px 26px;border-radius:14px;font:700 19px var(--ui);color:#fff;background:linear-gradient(180deg,#4a3aa8,#2a1e78);border:1.5px solid #8a7cf0;box-shadow:0 5px 0 #140c40}.shgyb svg{width:20px;height:20px}.shgyb:hover{filter:brightness(1.15)}
/* modals */
.shmod{position:absolute;inset:-8px -8px 50px;border-radius:20px;z-index:60;display:none;align-items:center;justify-content:center;background:#05031ad0;backdrop-filter:blur(3px)}.shmod.on{display:flex;animation:shfade .2s ease}@keyframes shfade{from{opacity:0}}
.shmc{position:relative;width:min(640px,92%);max-height:calc(100% - 24px);overflow:auto;padding:20px 24px;border-radius:18px;background:linear-gradient(180deg,#1a1440,#0a0822);border:2px solid var(--gd);box-shadow:0 20px 50px #000d;animation:shpop .3s cubic-bezier(.3,1.5,.5,1)}.shmc.wide{width:min(1100px,96%)}
@keyframes shpop{from{transform:scale(.88);opacity:0}}
.shmc h3{margin:0 0 4px;font:400 40px 'Pirata One',Georgia,serif;color:#ffd45a}
.shx{all:unset;cursor:pointer;position:absolute;right:14px;top:6px;font:400 34px Georgia,serif;color:#e8c36a;z-index:2}.shx:hover{color:#fff}
.shfine{margin:6px 0;font:500 14px/1.45 var(--ui);color:#c8c2f0}
.shobs{display:flex;flex-direction:column;gap:6px;margin:10px 0}.shob{display:grid;grid-template-columns:100px 1fr 64px;align-items:center;gap:10px;font:700 14px var(--ui);color:var(--c)}.shob i{height:12px;border-radius:6px;background:#ffffff14;overflow:hidden}.shob em{display:block;height:100%;border-radius:6px;background:var(--c);box-shadow:0 0 10px var(--c)}.shob b{text-align:right;color:#fff}
.shis{display:flex;flex-direction:column;gap:10px;margin-top:10px}.shig h4{margin:0 0 6px;font:400 22px 'Pirata One',Georgia,serif}.shig h4 small{font:600 12px var(--ui);color:#a8a2d8;margin-left:6px}
.shig>div{display:flex;flex-wrap:wrap;gap:5px}.shig span{padding:3px 9px;border-radius:9px;font:600 12.5px var(--ui);color:#d4cef0;background:#0006;border:1px solid color-mix(in srgb,var(--c) 35%,transparent)}.shig span.own{color:#fff;border-color:var(--c);background:color-mix(in srgb,var(--c) 18%,#0006)}
.shmc.gy .hwsec{margin:0}
.shfc{position:fixed;left:0;top:0;z-index:9999;width:20px;height:20px;margin:-10px 0 0 -10px;border-radius:50%;pointer-events:none;background:radial-gradient(circle at 35% 30%,#fff3a0,#d8961c 70%);box-shadow:0 0 0 1.5px #8a5a10,0 0 10px #ffd76a}
@media (max-width:1180px){.shp{grid-template-columns:minmax(0,1fr) minmax(290px,340px)}.shl{grid-column:1/-1;grid-row:2;flex-direction:row;overflow-x:auto;padding-bottom:6px}.shr{flex:none;min-width:240px}.shs{grid-column:1;grid-row:3;min-height:400px}.shp2{grid-column:2;grid-row:3}.shgy{grid-row:4}}
@media (max-width:760px){.shp{grid-template-columns:minmax(0,1fr)}.shl,.shs,.shp2,.shgy{grid-column:1}.shs{grid-row:3;min-height:360px}.shp2{grid-row:4}.shgy{grid-row:5;height:auto;flex-wrap:wrap;padding:0 0 14px}.shgy canvas{width:100%;height:auto}.shh{padding-right:110px}.shh h2{font-size:44px}.shgold b{font-size:22px}}
@media (prefers-reduced-motion:reduce){.shbuy,.shr{animation:none}}
`;document.head.appendChild(st)}
