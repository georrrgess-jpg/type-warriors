/* ===== RUNESTONE TOWER DEFENSE 9.9i: the Starfall Observatory, art (97d, after 97c) =====
   From the owner's concept (the Tower Vote card): a round stone observatory on a low plinth, an arched door under a star roundel, a
   ribbed blue dome on a gold rim, a brass telescope poking out of the dome slit and a gold armillary sphere on the left.
   Live: the dome slit and the telescope swing side to side toward the target (the battle module drives o.aim = lean in radians on a
   damped spring, so the swing eases in and settles with a small overshoot); the armillary rings turn; the lens glows while a star is
   being charged (star motes spiral into it), flashes and kicks back on firing and sends a shaft of light up into the sky.
   Tiers: 1 grey stone, blue dome, brass scope, two-ring armillary; 2 taller, gold-ribbed dome, gold bands, lit windows, a gold balcony
   rail, a longer scope, three rings; 3 Star Chart: a midnight dome painted with gold constellations, a gold scope with a crystal lens,
   a star finial and brass lanterns on the plinth; 4 Mythic (violet stone, violet dome with gold ribs, dark-iron scope, gems, orbiting
   runes); 5 Celestial (marble, white-gold dome, a winged white-gold scope with a star lens, wings and halo).
   Plugs into the shared pipeline of 95c (RPPAL/RPLAY/RPPULSE/RPWING/RPHALO + wrapped rpBodyArt, rpGlowList, rpTowerParts), so the
   build and upgrade animations, the tier 4-5 ascension, icons and warming are the shared ones. No shadowBlur, no ctx.filter.
   API
     rpsfLens(tier,lean,fire)            the lens (scope tip) relative to the pad centre {x,y}
     rpStarBolt(g,x,y,tier,rot,sc)       a falling star
     rpStarReticle(g,x,y,r,u,a)          the red target ring (ground layer), u = 0..1 flight progress, a = alpha
     rpStarImpact(g,x,y,u,tier,big)      the impact burst (top layer), u = 0..1
     rpStarMark(g,x,y,t,a)               the gold mark badge over a marked monster
     rpStarMarkRing(g,x,y,r,t,a)         the small red reticle under a marked monster's feet */
RPTW.star={n:'Starfall Observatory',role:'Global support',col:'#ffc83a'};
RPSKIN.star=['base'];
RPPAL.star={base:{stone:RPSTONE.base,trim:'#ffd45a',trimL:'#fff0a8',trimD:'#b07a1a',door:'#2a2470',doorD:'#140f3a',win:'#ffd27a',
 glow:'#ffd45a',glow2:'#7ad8ff',lamp:'#ffd27a'}};
/* per tier: plinth radius/height pr ph, tower radius/height tr th, dome radius/height dr dh, scope length/width sl sw, armillary
   [x offset from the dome edge, rings, radius], windows, balcony, lanterns, top, tier 4-5 gems */
RPLAY.star=[0,
 {pr:34,ph:8,tr:20,th:34,dr:24,dh:22,sl:30,sw:6.2,arm:[3,2,11],win:0,bal:0,lan:0,top:94,runes:[]},
 {pr:36,ph:9,tr:22,th:42,dr:26,dh:24,sl:34,sw:6.8,arm:[3,3,13],win:1,bal:1,lan:0,top:108,runes:[]},
 {pr:38,ph:10,tr:23,th:48,dr:28,dh:26,sl:38,sw:7.4,arm:[3,3,14],win:1,bal:1,lan:1,top:122,runes:[]},
 {pr:39,ph:10,tr:24,th:52,dr:29,dh:27,sl:40,sw:7.8,arm:[3,3,15],win:1,bal:1,lan:1,top:130,runes:[],inl:[[0,10,4.4],[-30,4,3.6],[30,4,3.6]]},
 {pr:40,ph:11,tr:25,th:55,dr:30,dh:28,sl:42,sw:8.2,arm:[3,3,16],win:1,bal:1,lan:1,top:138,runes:[],inl:[[0,10,4.6],[-30,4,3.8],[30,4,3.8]]}];
RPPULSE.star=[1.8,.22];RPWING.star=[36,-58];RPHALO.star=[-132,26];
const rpsfT=t=>Math.max(1,Math.min(5,t|0||1));
/* vertical anchors of a tier: plinth top, tower top, dome base, dome top */
function rpsfY(L){const y0=2-L.ph,yt=y0-L.th,db=yt-3;return{y0,yt,db,dt:db-L.dh}}
/* colours per tier: dome [light, mid, dark], rib, scope metal [light, mid, dark, deep], band, lens */
const rpsfDome=tier=>tier>=5?{d:['#ffffff','#f6ead0','#d4b06a'],rib:'#e0b44a',ribL:'#fff6c8',slit:'#2a2060'}
 :tier===4?{d:['#b48af0','#7a48c8','#40207e'],rib:'#ffd45a',ribL:'#fff0a8',slit:'#140a30'}
 :tier===3?{d:['#4a4aae','#26247a','#121044'],rib:'#ffd45a',ribL:'#fff0a8',slit:'#07051a'}
 :tier===2?{d:['#6e9cff','#3366e0','#1c3696'],rib:'#ffd45a',ribL:'#fff0a8',slit:'#0e0a2e'}
 :{d:['#6e9cff','#3366e0','#1c3696'],rib:'#9ec0ff',ribL:'#d8e6ff',slit:'#0e0a2e'};
const rpsfMet=tier=>tier>=5?{m:['#fffdf2','#f4e2a8','#d0a24a','#7a5a1a'],band:'#ffffff',bandD:'#c99a2a',lens:'#fff2b0',lensL:'#ffffff',cap:'#f4e2a8'}
 :tier===4?{m:['#8e86b8','#4e4672','#2a2244','#14102a'],band:'#ffd45a',bandD:'#a8741a',lens:'#c08aff',lensL:'#f0e0ff',cap:'#6a3ab8'}
 :tier===3?{m:['#fff6c8','#ffd45a','#c98a1c','#6a4410'],band:'#fff6c8',bandD:'#b07a1a',lens:'#7ae8ff',lensL:'#ffffff',cap:'#3a8ae0'}
 :{m:['#fff0a8','#e2b84a','#a8741a','#5a3a10'],band:'#8a5a14',bandD:'#4a2c08',lens:'#7ad8ff',lensL:'#e8fbff',cap:'#3a6ad8'};
/* a five-point star path */
function rpsfStarPath(g,x,y,r,ri,rot){g.beginPath();for(let i=0;i<10;i++){const a=rot-Math.PI/2+i*Math.PI/5,q=i%2?ri:r;i?g.lineTo(x+Math.cos(a)*q,y+Math.sin(a)*q):g.moveTo(x+Math.cos(a)*q,y+Math.sin(a)*q)}g.closePath()}
function rpsfStarArt(g,x,y,r,cA,cB,cC,lw){rpsfStarPath(g,x,y,r,r*.48,0);g.fillStyle=rpVG(g,y-r,y+r,cA,cB);g.fill();rpOut(g,lw||2.2);
 rpsfStarPath(g,x-r*.06,y-r*.08,r*.55,r*.26,0);g.fillStyle=cC;g.globalAlpha=.75;g.fill();g.globalAlpha=1}

/* ---------- static body ---------- */
function rpsfDomeShape(g,L,db){g.beginPath();g.ellipse(0,db,L.dr,L.dh,0,Math.PI,0);g.ellipse(0,db,L.dr,L.dr*RPSQ,0,0,Math.PI);g.closePath()}
/* a point on the dome: latitude th (0 base .. PI/2 top), longitude ph (0 = facing the viewer) */
const rpsfDP=(L,db,th,ph)=>({x:L.dr*Math.cos(th)*Math.sin(ph),y:db+L.dr*RPSQ*Math.cos(th)*Math.cos(ph)-L.dh*Math.sin(th)});
function rpsfBodyArt(g,tier,P){const L=RPLAY.star[tier],S=P.stone,Y=rpsfY(L),D=rpsfDome(tier),M=rpsfMet(tier);
 rpPadArt(g);
 /* plinth: a low masonry drum with a flagstone top */
 rpMason(g,0,2,L.pr,L.pr-1,L.ph,S,1,8,7);rpTopStone(g,0,Y.y0,L.pr-1,S,11,tier>=3?P.trim:null);
 /* lanterns on the plinth (tier 3+) */
 if(L.lan)for(const k of [-1,1]){const x=k*(L.pr-9),y=Y.y0+5;g.strokeStyle=RPTO;g.lineWidth=3.6;g.beginPath();g.moveTo(x,y);g.lineTo(x,y-14);g.stroke();g.strokeStyle=P.trimD;g.lineWidth=1.8;g.stroke();
  g.beginPath();g.roundRect(x-4,y-24,8,10,2);g.fillStyle=rpVG(g,y-24,y-14,'#fff6c8',P.lamp);g.fill();rpOut(g,1.6);g.beginPath();g.moveTo(x-5,y-24);g.lineTo(x,y-29);g.lineTo(x+5,y-24);g.closePath();g.fillStyle=P.trim;g.fill();rpOut(g,1.4)}
 /* the tower: a masonry cylinder */
 rpMason(g,0,Y.y0,L.tr,L.tr-1.5,L.th,S,tier>=2?4:3,6,tier+2);
 if(tier>=2)for(const z of [L.th*.36,L.th*.74]){g.beginPath();g.ellipse(0,Y.y0-z,L.tr-.6,(L.tr-.6)*RPSQ,0,.05,Math.PI-.05);g.lineWidth=4;g.strokeStyle=RPTO;g.stroke();g.lineWidth=2;g.strokeStyle=P.trim;g.stroke()}
 /* arched door and the star roundel above it */
 const fy=Y.y0+L.tr*RPSQ,dw=6+tier*.4,dhh=13+tier*1.2;g.beginPath();g.moveTo(-dw,fy-1);g.lineTo(-dw,fy-dhh+dw);g.arc(0,fy-dhh+dw,dw,Math.PI,0);g.lineTo(dw,fy-1);g.closePath();
 g.fillStyle=rpVG(g,fy-dhh,fy,P.door,P.doorD);g.fill();rpOut(g,2.2);if(tier>=2){g.lineWidth=1.3;g.strokeStyle=P.trim;g.beginPath();g.moveTo(-dw+2,fy-1);g.lineTo(-dw+2,fy-dhh+dw);g.arc(0,fy-dhh+dw,dw-2,Math.PI,0);g.lineTo(dw-2,fy-1);g.stroke()}
 const ey=fy-dhh-8.5,er=6.4+tier*.3;g.beginPath();g.arc(0,ey,er,0,TAU);g.fillStyle=rpVG(g,ey-er,ey+er,'#3a3290',P.doorD);g.fill();rpOut(g,2);
 g.beginPath();g.arc(0,ey,er-1.6,0,TAU);g.lineWidth=1;g.strokeStyle=P.trim;g.stroke();rpsfStarArt(g,0,ey+.4,er*.7,P.trimL,P.trim,'#ffffff',1.2);
 /* lit windows (tier 2+) */
 if(L.win)for(const k of [-1,1]){const x=k*L.tr*.58,y=Y.yt+L.th*.6,w=3.2;g.beginPath();g.moveTo(x-w,y+5);g.lineTo(x-w,y-2);g.arc(x,y-2,w,Math.PI,0);g.lineTo(x+w,y+5);g.closePath();g.fillStyle=rpVG(g,y-5,y+5,'#fff6c8',P.win);g.fill();rpOut(g,1.6)}
 /* gold rim the dome sits on, and the balcony rail (tier 2+) */
 g.beginPath();g.ellipse(0,Y.yt,L.tr+2.5,(L.tr+2.5)*RPSQ,0,0,TAU);g.fillStyle=rpVG(g,Y.yt-6,Y.yt+6,P.trimL,P.trimD);g.fill();rpOut(g,2.2);
 /* the dome */
 rpsfDomeShape(g,L,Y.db);g.fillStyle=rpHG(g,-L.dr,L.dr,D.d[0],D.d[1],D.d[2]);g.fill();
 g.save();rpsfDomeShape(g,L,Y.db);g.clip();
 /* ribs (meridians) */
 for(let i=-3;i<=3;i++){const ph=i*.42;g.beginPath();for(let k=0;k<=12;k++){const p=rpsfDP(L,Y.db,k/12*Math.PI/2,ph);k?g.lineTo(p.x,p.y):g.moveTo(p.x,p.y)}g.lineWidth=tier>=2?3.2:2.2;g.strokeStyle=tier>=2?'rgba(18,8,31,.55)':'rgba(18,8,31,.25)';g.stroke();g.lineWidth=tier>=2?1.6:1.3;g.strokeStyle=i<0?D.ribL:D.rib;g.stroke()}
 /* painted constellations (tier 3 star chart) and dots of starlight (tier 4-5) */
 if(tier>=3){const pts=[[-.9,.5],[-.6,.85],[-.25,.6],[.1,.95],[.45,.55],[.8,.8],[.65,.3],[-.5,.25]];g.strokeStyle=tier>=5?'rgba(200,150,60,.75)':'rgba(255,224,140,.7)';g.lineWidth=1;g.beginPath();
  pts.forEach(([u,v],j)=>{const p=rpsfDP(L,Y.db,v*1.2,u*1.2);j?g.lineTo(p.x,p.y):g.moveTo(p.x,p.y)});g.stroke();
  for(const [u,v] of pts){const p=rpsfDP(L,Y.db,v*1.2,u*1.2);g.fillStyle=tier>=5?'#c99a2a':'#fff0a8';g.beginPath();g.arc(p.x,p.y,1.5,0,TAU);g.fill()}}
 /* shading: a highlight on the upper left, a shadow on the right */
 g.fillStyle='rgba(255,255,255,.22)';g.beginPath();g.ellipse(-L.dr*.42,Y.dt+L.dh*.42,L.dr*.22,L.dh*.32,-.5,0,TAU);g.fill();
 const q=g.createLinearGradient(-L.dr,0,L.dr,0);q.addColorStop(0,'rgba(18,8,31,0)');q.addColorStop(.62,'rgba(18,8,31,0)');q.addColorStop(1,'rgba(18,8,31,.35)');g.fillStyle=q;g.fillRect(-L.dr,Y.dt-2,L.dr*2,L.dh+L.dr);
 g.restore();rpsfDomeShape(g,L,Y.db);rpOut(g,2.6);
 g.beginPath();g.ellipse(0,Y.db,L.dr,L.dr*RPSQ,0,.04,Math.PI-.04);g.lineWidth=2.6;g.strokeStyle=P.trimD;g.stroke();g.lineWidth=1.2;g.strokeStyle=P.trimL;g.stroke();
 /* the balcony rail in front of the dome foot (tier 2+): a gold rail on short posts */
 if(L.bal){const r=L.tr+6,y=Y.yt+8,ph=5;for(let i=1;i<8;i++){const a=i/8*Math.PI,x=Math.cos(a)*r,yy=y+Math.sin(a)*r*RPSQ;g.strokeStyle=RPTO;g.lineWidth=3;g.beginPath();g.moveTo(x,yy);g.lineTo(x,yy-ph);g.stroke();g.strokeStyle=P.trim;g.lineWidth=1.3;g.stroke()}
  for(const [lw,c] of [[4.2,RPTO],[2.2,P.trim],[.9,P.trimL]]){g.beginPath();g.ellipse(0,y-ph,r,r*RPSQ,0,.08,Math.PI-.08);g.lineWidth=lw;g.strokeStyle=c;g.stroke()}}
 /* finial on the dome top */
 const fy2=Y.dt+1;if(tier===1){g.beginPath();g.arc(0,fy2-2,2.6,0,TAU);g.fillStyle=P.trim;g.fill();rpOut(g,1.4)}
 else if(tier===2){g.beginPath();g.moveTo(-2.4,fy2);g.lineTo(0,fy2-9);g.lineTo(2.4,fy2);g.closePath();g.fillStyle=rpHG(g,-2.4,2.4,P.trimL,P.trim,P.trimD);g.fill();rpOut(g,1.4)}
 else{g.strokeStyle=RPTO;g.lineWidth=3.2;g.beginPath();g.moveTo(0,fy2);g.lineTo(0,fy2-6);g.stroke();g.strokeStyle=P.trim;g.lineWidth=1.4;g.stroke();
  rpsfStarArt(g,0,fy2-11,tier>=5?7:6,tier>=5?'#ffffff':'#fff6c8',tier===4?'#c08aff':P.trim,'#ffffff',1.6)}
 /* the armillary's brass post (the rings turn live) */
 {const A=rpsfArm(L,Y);g.strokeStyle=RPTO;g.lineWidth=4;g.beginPath();g.moveTo(A.x+2,Y.yt+1);g.quadraticCurveTo(A.x-2,A.y+A.r+6,A.x,A.y+A.r);g.stroke();g.strokeStyle=M.m[1];g.lineWidth=2;g.stroke();
  g.beginPath();g.ellipse(A.x,A.y+A.r+1,4,1.8,0,0,TAU);g.fillStyle=P.trim;g.fill();rpOut(g,1.2)}
 if(tier>=4)rpAscArt(g,'star',tier,P,L)}
const rpsfArm=(L,Y)=>({x:-(L.dr+L.arm[0]+L.arm[2]*.6),y:Y.db-L.dh*.42,r:L.arm[2]});
{const b0=rpBodyArt;rpBodyArt=function(g,type,tier,P){if(type==='star')return rpsfBodyArt(g,tier,P);return b0.apply(this,arguments)}}
{const l0=rpGlowList;rpGlowList=function(type,tier,P,L){if(type!=='star')return l0.apply(this,arguments);const G=[],A=(x,y,rx,ry,c,a)=>G.push([x,y,rx,ry,c,a]),Y=rpsfY(L),fy=Y.y0+L.tr*RPSQ;
 A(0,fy-13-tier*1.2-8.5,13,13,P.glow,.55);if(L.win)for(const k of [-1,1])A(k*L.tr*.58,Y.yt+L.th*.6,10,12,P.win,.6);
 if(L.lan)for(const k of [-1,1])A(k*(L.pr-9),Y.y0-14,12,12,P.lamp,.75);if(tier>=3)A(0,Y.dt-10,16,16,tier===4?'#c08aff':P.glow,.7);
 A(0,Y.db-L.dh*.5,L.dr*1.1,L.dh*.9,tier===4?'#9a5cff':tier>=3?'#7a8aff':'#5a8cff',.18);
 if(tier>=4){const A4=RPASC[tier];for(const [x,y,z] of L.inl)A(x,y,z*3.4,z*3.4,A4.glow,.85);A(0,-L.top*.5,46,L.top*.5,A4.glow,.16)}return G}}

/* ---------- the telescope (pointing up; pivot at 0,0; the eyepiece end hangs below it, inside the dome) ---------- */
function rpsfScopeArt(g,tier){const L=RPLAY.star[tier],M=rpsfMet(tier),m=M.m,l=L.sl,w=L.sw,wt=w*1.22;
 /* eyepiece */
 g.beginPath();g.rect(-w*.42,4,w*.84,7);g.fillStyle=rpHG(g,-w*.42,w*.42,m[0],m[1],m[2]);g.fill();rpOut(g,1.6);
 /* tube, tapering out to the objective */
 g.beginPath();g.moveTo(-w*.82,6);g.lineTo(-wt,-l+6);g.lineTo(wt,-l+6);g.lineTo(w*.82,6);g.closePath();g.fillStyle=rpHG(g,-wt,wt,m[0],m[1],m[2]);g.fill();rpOut(g,2.2);
 g.fillStyle='rgba(255,255,255,.4)';g.beginPath();g.moveTo(-w*.5,4);g.lineTo(-wt*.62,-l+8);g.lineTo(-wt*.32,-l+8);g.lineTo(-w*.24,4);g.closePath();g.fill();
 /* bands */
 const bands=tier>=2?[-l*.18,-l*.55]:[-l*.3];for(const y of bands){const k=(y-6)/(-l),hw=w*.82+(wt-w*.82)*k+1.2;g.beginPath();g.rect(-hw,y-2.2,hw*2,4.4);g.fillStyle=rpHG(g,-hw,hw,M.band,M.band,M.bandD);g.fill();rpOut(g,1.4)}
 /* wing fins (tier 5) */
 if(tier>=5)for(const k of [-1,1]){g.beginPath();g.moveTo(k*wt*.9,-l*.62);g.quadraticCurveTo(k*(wt+12),-l*.75,k*(wt+9),-l*.98);g.quadraticCurveTo(k*(wt+4),-l*.86,k*wt,-l*.82);g.closePath();g.fillStyle=rpHG(g,k*wt,k*(wt+12),'#ffffff','#ffe9b0','#d8b060');g.fill();rpOut(g,1.4)}
 /* objective: a coloured cap ring and the glass */
 const cy=-l+4;g.beginPath();g.rect(-wt-1.6,cy-6,wt*2+3.2,7);g.fillStyle=rpHG(g,-wt,wt,rpMix(M.cap,'#ffffff',.35),M.cap,rpMix(M.cap,'#12081f',.4));g.fill();rpOut(g,1.8);
 g.beginPath();g.ellipse(0,cy-6,wt+1.6,(wt+1.6)*.42,0,0,TAU);g.fillStyle=rpHG(g,-wt,wt,M.lensL,M.lens,rpMix(M.lens,'#12081f',.35));g.fill();rpOut(g,1.6);
 g.fillStyle='rgba(255,255,255,.85)';g.beginPath();g.ellipse(-wt*.35,cy-6.6,wt*.32,wt*.13,0,0,TAU);g.fill()}
const rpsfScopeS=tier=>{const L=RPLAY.star[tier];return rpSpr('sf|sc|'+tier,-L.sw*1.22-22,-L.sl-8,L.sw*2.44+44,L.sl+22,g=>rpsfScopeArt(g,tier))};
/* pose: the slit longitude follows the lean; the pivot sits on that meridian a little below the top */
function rpsfPose(tier,lean,fire){const L=RPLAY.star[rpsfT(tier)],Y=rpsfY(L),ln=Math.max(-1.15,Math.min(1.15,lean||0)),ph=ln*.78,p=rpsfDP(L,Y.db,.62,ph),f=fire||0;
 return{L,Y,ln,ph,px:p.x,py:p.y,kick:3.5*f*f}}
function rpsfLens(tier,lean,fire){const p=rpsfPose(tier,lean,fire),d=p.L.sl-2-p.kick;return{x:p.px+Math.sin(p.ln)*d,y:p.py-Math.cos(p.ln)*d}}

/* ---------- live parts ---------- */
function rpsfArmLive(g,tier,P,t,ph,L,Y,spin){const A=rpsfArm(L,Y),n=L.arm[1],r=A.r,M=rpsfMet(tier),lt=RPFX.lite;
 /* core: a glowing orb (a star from tier 3) */
 g.globalCompositeOperation='lighter';rpGlow(g,A.x,A.y,r*.9,r*.9,M.lens,.55+.25*Math.sin(t*3+ph));g.globalCompositeOperation='source-over';g.globalAlpha=RPGA;
 if(tier>=3)rpsfStarArt(g,A.x,A.y,r*.42,'#ffffff',M.lens,'#ffffff',1.2);else{g.beginPath();g.arc(A.x,A.y,r*.3,0,TAU);g.fillStyle=rpHG(g,A.x-r*.3,A.x+r*.3,'#ffffff',M.lens,rpMix(M.lens,'#12081f',.4));g.fill();rpOut(g,1.2)}
 /* rings: each a tilted ellipse whose width breathes as it turns */
 for(let i=0;i<n;i++){const a=t*(.9+i*.35)*(i%2?-1:1)*(1+spin*2.5)+ph+i*1.3,rw=r*(.96-i*.06),rh=Math.max(r*.12,Math.abs(Math.sin(a))*rw),tilt=i*Math.PI/n+.35;
  g.beginPath();g.ellipse(A.x,A.y,rw,rh,tilt,0,TAU);g.lineWidth=lt?3:3.6;g.strokeStyle=RPTO;g.stroke();g.lineWidth=1.8;g.strokeStyle=i===1?P.trimL:P.trim;g.stroke()}
 /* the outer meridian ring stays still */
 g.beginPath();g.arc(A.x,A.y,r,0,TAU);g.lineWidth=3.4;g.strokeStyle=RPTO;g.stroke();g.lineWidth=1.6;g.strokeStyle=P.trimD;g.stroke()}
function rpsfLive(g,tier,P,t,o,L,ph){const Y=rpsfY(L),D=rpsfDome(tier),M=rpsfMet(tier),f=Math.max(0,Math.min(1,o.fire||0)),ch=Math.max(0,Math.min(1,o.charge||0)),lt=RPFX.lite,
  lean=o.aim==null?.55:o.aim,p=rpsfPose(tier,lean,f);
 rpsfArmLive(g,tier,P,t,ph,L,Y,f);
 /* the dome slit: a dark gore along the scope's meridian, with a few stars inside */
 {const w=.2;g.beginPath();for(let k=0;k<=10;k++){const q=rpsfDP(L,Y.db,k/10*Math.PI/2,p.ph-w);k?g.lineTo(q.x,q.y):g.moveTo(q.x,q.y)}for(let k=10;k>=0;k--){const q=rpsfDP(L,Y.db,k/10*Math.PI/2,p.ph+w);g.lineTo(q.x,q.y)}g.closePath();
  g.fillStyle=D.slit;g.globalAlpha=RPGA*Math.max(.25,Math.cos(p.ph));g.fill();g.globalAlpha=RPGA;g.lineWidth=1.6;g.strokeStyle=RPTO;g.stroke();
  if(!lt)for(let i=0;i<3;i++){const q=rpsfDP(L,Y.db,.25+i*.4,p.ph+(i-1)*.08);g.fillStyle=`rgba(255,246,200,${(.5+.5*Math.sin(t*4+i*2+ph)).toFixed(3)})`;g.beginPath();g.arc(q.x,q.y,.9,0,TAU);g.fill()}}
 /* the telescope */
 g.save();g.translate(p.px,p.py);g.rotate(p.ln);g.translate(0,p.kick);g.globalAlpha=RPGA;rpPut(g,rpsfScopeS(tier));g.restore();
 /* collar where it leaves the dome */
 g.beginPath();g.ellipse(p.px,p.py+2,L.sw*.95,L.sw*.42,p.ln,0,TAU);g.fillStyle=rpHG(g,p.px-L.sw,p.px+L.sw,P.trimL,P.trim,P.trimD);g.fill();rpOut(g,1.6);
 /* the lens: a soft glow that swells while charging, a white flash on firing */
 const lz=rpsfLens(tier,lean,f);g.globalCompositeOperation='lighter';
 rpGlow(g,lz.x,lz.y,9+7*ch+tier,9+7*ch+tier,M.lens,.35+.15*Math.sin(t*3+ph)+.55*ch);
 if(f>.02){const fl=f*f;rpGlow(g,lz.x,lz.y,22+24*fl,22+24*fl,'#ffffff',fl);rpGlow(g,lz.x,lz.y,34+30*fl,34+30*fl,M.lens,.7*fl);
  /* a shaft of light up into the sky along the scope */
  const dx=Math.sin(p.ln),dy=-Math.cos(p.ln),len=110+60*(1-f);g.globalAlpha=RPGA*fl*.85;g.strokeStyle=M.lensL;g.lineWidth=6*fl+1.5;g.beginPath();g.moveTo(lz.x,lz.y);g.lineTo(lz.x+dx*len,lz.y+dy*len);g.stroke();
  g.lineWidth=2;g.strokeStyle='#ffffff';g.stroke()}
 /* charging: star motes spiral into the lens */
 if(ch>.05&&!lt){const st=rpStarS().c;for(let i=0;i<4;i++){const a=i/4*TAU+t*3+ph,d=(1-((ch*1.6+i*.25)%1))*26,z=2.5+3*ch;g.globalAlpha=RPGA*Math.min(1,ch*2)*(.4+.6*(1-d/26));g.drawImage(st,lz.x+Math.cos(a)*d-z,lz.y+Math.sin(a)*d*.8-z,z*2,z*2)}}
 g.globalCompositeOperation='source-over';g.globalAlpha=RPGA;
 /* twinkles around the dome */
 if(!lt){const st=rpStarS().c;g.globalCompositeOperation='lighter';for(let i=0;i<2;i++){const q=t*.55+i*.5+ph,u=q%1,n=Math.floor(q),x=(rpR(i*17+n)-.5)*L.dr*2.6,y=Y.dt-6-rpR(i*5+n+2)*26,z=(3+4*rpR(i+n))*Math.sin(Math.PI*u);if(z>.4){g.globalAlpha=RPGA*.9;g.drawImage(st,x-z,y-z,z*2,z*2)}}
  g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}}
{const p0=rpTowerParts;rpTowerParts=function(g,type,tier,skin,t,o,nopad){if(type!=='star')return p0.apply(this,arguments);
 const P=rpPalT(type,skin,tier),L=RPLAY[type][tier],ph=o.ph||0;
 if(tier>=4){if(!nopad)rpAscGround(g,tier,t,ph,1);rpAscLive(g,type,tier,t,ph,L,0)}
 g.globalAlpha=RPGA;rpPut(g,nopad?rpBody(type,tier,skin):rpBack(type,tier,skin));
 {const q=RPPULSE[type];g.globalCompositeOperation='lighter';g.globalAlpha=RPGA*(1-q[1]+q[1]*Math.sin(t*q[0]+ph*7));rpPut(g,rpGlowLayer(type,tier,skin));g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}
 if(!nopad){const u=((t+ph*2.3)*.28)%1;if(u<.12){const v=u/.12*tier,i=Math.min(tier-1,v|0);g.globalCompositeOperation='lighter';rpGlow(g,(i-(tier-1)/2)*10,RPPIPY-1,8,8,'#fff6c8',Math.sin(Math.PI*(v-i))*.95);g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}}
 rpsfLive(g,tier,P,t,o,L,ph);
 if(tier>=4)rpAscLive(g,type,tier,t,ph,L,1);
 g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}}
{const w0=rpTowerWarm;rpTowerWarm=function(type,tier,skin){const r=w0.apply(this,arguments);if(type==='star'){tier=rpsfT(tier);try{rpsfScopeS(tier);rpsfBoltS(tier)}catch(e){}}return r}}

/* ---------- the falling star, the reticle, the impact and the mark ---------- */
const rpsfBoltC=tier=>tier>=5?['#ffffff','#fff2b0','#ffffff']:tier===4?['#f4e8ff','#c08aff','#ffffff']:['#fff6c8','#ffc83a','#ffffff'];
const rpsfBoltS=tier=>rpSpr('sf|bolt|'+rpsfT(tier),-20,-20,40,40,g=>{const C=rpsfBoltC(rpsfT(tier));g.drawImage(rpGlowC(C[1]),-20,-20,40,40);rpsfStarArt(g,0,0,13,C[0],C[1],C[2],2.6);
 g.fillStyle='rgba(18,8,31,.85)';g.beginPath();g.arc(-3.2,-.5,1.3,0,TAU);g.arc(3.2,-.5,1.3,0,TAU);g.fill()});
function rpStarBolt(g,x,y,tier,rot,sc){g.save();g.translate(x,y);g.rotate(rot||0);const k=sc||1;g.scale(k,k);rpPut(g,rpsfBoltS(tier));g.restore()}
const rpsfRetS=()=>rpSpr('sf|ret',-54,-54,108,108,g=>{g.lineCap='round';for(const [lw,c] of [[9,'rgba(18,8,31,.55)'],[4,'#ff4a5a'],[1.4,'#ffd0d4']]){g.lineWidth=lw;g.strokeStyle=c;g.beginPath();g.arc(0,0,44,0,TAU);g.stroke();
  g.beginPath();g.arc(0,0,24,0,TAU);g.stroke();g.beginPath();for(let i=0;i<4;i++){const a=i*Math.PI/2;g.moveTo(Math.cos(a)*30,Math.sin(a)*30);g.lineTo(Math.cos(a)*52,Math.sin(a)*52)}g.stroke()}},1);
function rpStarReticle(g,x,y,r,u,a){if(a<=.01)return;const k=r/44*(1.35-.35*u);g.save();g.translate(x,y);g.scale(k,k*RPFX.sq);g.rotate(u*1.6);g.globalAlpha=Math.min(1,a);rpPut(g,rpsfRetS());g.restore();g.globalAlpha=1}
function rpStarImpact(g,x,y,u,tier,big){if(u<=0||u>=1)return;const C=rpsfBoltC(tier),e=1-Math.pow(1-u,3),s=big?1.35:1;g.save();g.globalCompositeOperation='lighter';
 rpGlow(g,x,y-14,(46+40*e)*s,(40+30*e)*s,C[1],(1-u)*1.1);rpGlow(g,x,y-14,22*s,22*s,'#ffffff',Math.max(0,1-u*2.5));
 g.globalAlpha=(1-u)*.85;g.translate(x,y-14);g.rotate(u*.8);const z=(30+70*e)*s;g.drawImage(rpRaysS().c,-z,-z,z*2,z*2);g.restore();
 g.save();const rr=(16+60*e)*s;g.globalAlpha=(1-u)*.9;g.beginPath();g.ellipse(x,y,rr,rr*RPFX.sq,0,0,TAU);g.lineWidth=5*(1-u)+3;g.strokeStyle='rgba(18,8,31,.5)';g.stroke();g.lineWidth=3.4*(1-u)+1.2;g.strokeStyle=C[1];g.stroke();
 /* the star itself flares and pops before fading */
 if(u<.45){const k=u/.45,z=(1.4+1.6*rpEO(k))*s;g.globalAlpha=1-k;g.translate(x,y-16);g.rotate(k*1.2);g.scale(z,z);rpPut(g,rpsfBoltS(tier))}
 g.restore();g.save();
 if(!RPFX.lite){const st=rpStarS().c;for(let i=0;i<6;i++){const a=i/6*TAU+rpR(i+(x|0))*.6,d=(10+46*e)*s,zz=(6+5*rpR(i))*(1-u);g.globalAlpha=1-u;g.drawImage(st,x+Math.cos(a)*d-zz,y-14+Math.sin(a)*d*.7-zz-10*e,zz*2,zz*2)}}
 g.restore();g.globalAlpha=1}
const rpsfMarkS=()=>rpSpr('sf|mk',-11,-11,22,22,g=>{g.drawImage(rpGlowC('#ffc83a'),-11,-11,22,22);rpsfStarArt(g,0,.5,7.5,'#fff6c8','#ffc83a','#ffffff',1.8)});
function rpStarMark(g,x,y,t,a){if(a<=.01)return;const s=1+.12*Math.sin(t*6);g.save();g.translate(x,y);g.rotate(Math.sin(t*2.2)*.25);g.scale(s,s);g.globalAlpha=Math.min(1,a);rpPut(g,rpsfMarkS());g.restore();g.globalAlpha=1}
function rpStarMarkRing(g,x,y,r,t,a){if(a<=.01)return;const k=r/44;g.save();g.translate(x,y);g.scale(k,k*RPFX.sq);g.rotate(t*1.2);g.globalAlpha=Math.min(1,a)*.6;rpPut(g,rpsfRetS());g.restore();g.globalAlpha=1}
