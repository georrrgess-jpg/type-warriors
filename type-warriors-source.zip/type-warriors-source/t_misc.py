import asyncio,os
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900},reduced_motion='reduce');er=[]
        pg.on('pageerror',lambda e:er.append('PE '+str(e)[:300]))
        await pg.goto('file://'+os.path.abspath('out.html'));await pg.wait_for_timeout(900);E=pg.evaluate
        print(await E("()=>{RS_ASK=false;title();const d=JSON.parse(JSON.stringify(P));d.pets={zzgone:{b:40},bramble:{b:300,acc:1}};d.pet='bramble';d.gold=777;d.trail={n:11,c:2};d.eggs={r:2,l:1};delete d.trSeen;load(d);return JSON.stringify([P.pets,P.gold,P.trail,P.eggs,P.trSeen,petLook('bramble')])}"))
        for i in range(6):
            await E("()=>{petHall(['Pets','Eggs','Trail'][%d%%3]);ptCustom('bramble')}"%i);await pg.wait_for_timeout(150);await pg.keyboard.press('Escape');await pg.wait_for_timeout(250)
        print('live entries',await E("()=>[LIVE.length,document.querySelectorAll('#ptat').length,ov.style.overflow]"))
        await E("()=>petHall('Trail')");await pg.wait_for_timeout(500);print('trSeen set w/o anim',await E("()=>P.trSeen"))
        await pg.screenshot(path='shots/misc_rm.png')
        print(er[:5]);await b.close()
asyncio.run(main())
