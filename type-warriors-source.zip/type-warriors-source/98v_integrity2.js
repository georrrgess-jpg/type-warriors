/* ===== 10.1g: save integrity, second layer (98v, after 98u; needs 98t and 00a) =====
   Owner report: an updated cheat tool copied 98t's checksum key and formula out of the page source, wrote forged coins / level into
   browser storage together with a matching signature, locked the game's own saving (SGS.lock) and reloaded. A secret shipped inside
   a browser game can always be read, so this layer adds checks the tool cannot satisfy by copying code:
   1. Watchdog: the save and its signature can only change through the game (sgPut). A write made behind its back in the same tab
      (localStorage.setItem from a script) is undone at once: every 0.7 s (after a second look, so a write from another game tab that
      arrives by the 'storage' event is accepted), and on pagehide / beforeunload / visibilitychange, i.e. before a reload. The real
      Storage functions are taken in 00a before any other script can patch them.
   2. A per-device key: 16 random bytes kept in IndexedDB (never in the source, never in localStorage). The signature record gains
      m2 / a2 made with that key on every save, and a device-signed copy of the last real coins / XP / prestige is kept in IndexedDB. On start the record is checked against it; a record without m2 (like the one the tool
      writes), with a wrong m2, or a save whose key was deleted counts as edited, and coins / XP / prestige go back to that IndexedDB copy (or the values the
      device key last signed in the record) (or, without them, to the gold ledger's last balance and at most level 8). Saves from 10.1f and older get
      the key on their first start; their coins are checked against the ledger then.
   3. Gold ledger cross-check (94e records every legitimate change of P.gold with its balance): coins above the ledger's last balance
      are put back to it.
   Under automation the reverts are off unless window.TW_AC_TEST is set (as in 98t). Prefix twac2. */
const TWAC2=(()=>{
 const W=window,LS=TWAC0.ls,IDB=TWAC0.idb,SIGK='typeWarriorsAux',enforce=()=>!TWAC0.wd||!!W.TW_AC_TEST;
 const ST={restored:0,edited:0,ledger:0,key:0,migrated:0,lost:0,ck:0,capped:0,ready:0};
 const lsGet=k=>{try{return LS?LS.get.call(localStorage,k):localStorage.getItem(k)}catch(e){return null}};
 const lsSet=(k,v)=>{try{LS?LS.set.call(localStorage,k,v):localStorage.setItem(k,v);return true}catch(e){return false}};
 /* ---- a second private checksum, keyed with the device key ---- */
 function mac2(key,s){s=key+'#'+s+'#'+key.length;let a=0x2545f491^s.length,b=0x6c8e9cf5,c=0x7fb5d329,d=0x1b873593;
  for(let i=0;i<s.length;i++){const k=s.charCodeAt(i);a=Math.imul(a^k,0x85ebca6b);b=Math.imul(b+k,0xc2b2ae35)^(a>>>13);c=Math.imul(c^b,0x27d4eb2f)+k;d=Math.imul(d^(c>>>11),0x165667b1)}
  for(const r of [16,13,16]){a=Math.imul(a^(a>>>r),0x85ebca6b)^d;b=Math.imul(b^(b>>>r),0xc2b2ae35)^a;c=Math.imul(c^(c>>>r),0x27d4eb2f)^b;d=Math.imul(d^(d>>>r),0x165667b1)^c}
  return [a,b,c,d].map(v=>(v>>>0).toString(16).padStart(8,'0')).join('')}
 let DK=null;
 const vals=raw=>{let o=null;try{o=JSON.parse(raw)}catch(e){}if(!o||typeof o!=='object')o={};return{g:Math.round(+o.gold||0),x:Math.round(+o.xp||0),p:o.pres|0}};
 /* add the device-key fields to the signature record that 98t just wrote for this save string */
 function sign2(raw){if(!DK||typeof raw!=='string')return;let r=null;try{r=JSON.parse(lsGet(SIGK)||'null')}catch(e){}if(!r||typeof r!=='object')r={};
  const v=vals(raw);r.m2=mac2(DK,'s|'+raw);r.a2=mac2(DK,'a|'+v.g+'|'+v.x+'|'+v.p);r.g2=v.g;r.x2=v.x;r.p2=v.p;lsSet(SIGK,JSON.stringify(r));
  if(!AN||AN.g!==v.g||AN.x!==v.x||AN.p!==v.p){AN={g:v.g,x:v.x,p:v.p,m:mac2(DK,'an|'+v.g+'|'+v.x+'|'+v.p)};anPut(AN)}}
 /* ---- 1. the watchdog ---- */
 let lastK=lsGet(KEY),lastA=lsGet(SIGK),other=0,pend=0;
 {const p0=sgPut;sgPut=function(k,v){const r=p0.apply(this,arguments);if(k===KEY){if(r!==false)sign2(v);lastK=lsGet(KEY);lastA=lsGet(SIGK)}else if(k===SIGK){lastA=lsGet(SIGK)}return r}}
 W.addEventListener('storage',e=>{try{if(!e.isTrusted||e.storageArea!==localStorage)return;if(e.key===KEY||e.key===SIGK||e.key===null){other=Date.now();lastK=lsGet(KEY);lastA=lsGet(SIGK)}}catch(x){}});
 function watch(now){if(!enforce()||(typeof SGS!=='undefined'&&SGS.mem))return;const k=lsGet(KEY),a=lsGet(SIGK);
  if(k===lastK&&a===lastA){pend=0;return}
  if(Date.now()-other<2000){lastK=k;lastA=a;pend=0;return}
  if(!now&&!pend){pend=1;return}
  pend=0;ST.restored++;if(lastK!==null)lsSet(KEY,lastK);if(lastA!==null)lsSet(SIGK,lastA)}
 setInterval(()=>watch(0),700);W.addEventListener('pagehide',()=>watch(1),true);W.addEventListener('beforeunload',()=>watch(1),true);
 document.addEventListener('visibilitychange',()=>watch(1),true);
 /* ---- 2 + 3. the device key, then the start-up check ---- */
 function idb(fn){return new Promise(res=>{try{if(!IDB){res(null);return}const q=IDB.open('typeWarriorsK',1);q.onupgradeneeded=()=>{try{q.result.createObjectStore('k')}catch(e){}};
  q.onerror=()=>res(null);q.onsuccess=()=>{const db=q.result;try{fn(db,v=>{try{db.close()}catch(e){}res(v)})}catch(e){try{db.close()}catch(x){}res(null)}}}catch(e){res(null)}})}
 const keyGet=()=>idb((db,done)=>{const t=db.transaction('k','readonly'),g=t.objectStore('k').get('dk');g.onsuccess=()=>done(typeof g.result==='string'?g.result:null);g.onerror=()=>done(null)});
 const keyPut=k=>idb((db,done)=>{const t=db.transaction('k','readwrite');t.objectStore('k').put(k,'dk');t.oncomplete=()=>done(true);t.onerror=()=>done(false)});
 const anGet=()=>idb((db,done)=>{const t=db.transaction('k','readonly'),g=t.objectStore('k').get('an');g.onsuccess=()=>done(g.result&&typeof g.result==='object'?g.result:null);g.onerror=()=>done(null)});
 const keyDel=()=>idb((db,done)=>{const t=db.transaction('k','readwrite');t.objectStore('k').delete('dk');t.oncomplete=()=>done(true);t.onerror=()=>done(false)});
 /* 10.1h: the device key is a WebCrypto key object made non-extractable: the page can use it, but its bytes can never be read out of IndexedDB */
 const SUB=TWAC0.sub,HX=b=>[...new Uint8Array(b)].map(v=>v.toString(16).padStart(2,'0')).join('');
 const ckGet=()=>idb((db,done)=>{const t=db.transaction('k','readonly'),g=t.objectStore('k').get('dk3');g.onsuccess=()=>done(g.result&&typeof g.result==='object'&&g.result.type==='secret'?g.result:null);g.onerror=()=>done(null)});
 const ckPut=k=>idb((db,done)=>{const t=db.transaction('k','readwrite');t.objectStore('k').put(k,'dk3');t.oncomplete=()=>done(true);t.onerror=()=>done(false)});
 async function ckBits(ck){if(!SUB||!ck)return null;try{return HX(await SUB.der({name:'HKDF',hash:'SHA-256',salt:new Uint8Array(16),info:new TextEncoder().encode('tw-dk3')},ck,256))}catch(e){return null}}
 async function ckNew(){if(!SUB)return null;try{const a=new Uint8Array(32);TWAC0.rnd(a);return await SUB.imp('raw',a,'HKDF',false,['deriveBits'])}catch(e){return null}}
 const anPut=o=>idb((db,done)=>{const t=db.transaction('k','readwrite');t.objectStore('k').put(o,'an');t.oncomplete=()=>done(true);t.onerror=()=>done(false)});
 let AN=null;
 function ledgerBal(){try{const L=P.ldg;if(Array.isArray(L)&&L.length){const b=+L[L.length-1].bal;if(isFinite(b))return b}}catch(e){}return null}
 function revert(g,x,p,why){let ch=false;if((+P.gold||0)>g){P.gold=g;ch=true}if((+P.xp||0)>x){P.xp=x;ch=true}if((P.pres|0)>p){P.pres=p;ch=true}
  if(ch){try{syncPaths()}catch(e){}try{SGS.lock=false}catch(e){}save();ST.edited++;
   try{if(typeof sgNote==='function'&&typeof S!=='undefined')setTimeout(()=>sgNote('Your save was changed outside the game, so your coins and level were put back to their last real values.'),1200)}catch(e){}}
  return ch}
 {const k0=sgPack;sgPack=function(){const r=k0.apply(this,arguments);try{if(DK)r.dm=mac2(DK,'x|'+r.payload)}catch(e){}return r}}
 {const r0=sgRead;sgRead=function(txt,lenient){const r=r0.apply(this,arguments);if(!r||!r.ok||lenient||!r.keyed||!enforce())return r;
  try{if(TWAC.stat().tr>0)return r}catch(e){}
  let mine=false;try{let s=String(txt).replace(/^\uFEFF/,'').trim();const m=s.match(/^TWSAVE(\d+):/);if(m)s=sgUnb64(s.slice(m[0].length).replace(/\s+/g,''));
   const o=JSON.parse(s);mine=!!(DK&&o&&typeof o.payload==='string'&&typeof o.dm==='string'&&o.dm===mac2(DK,'x|'+o.payload))}catch(e){}
  if(mine)return r;
  const q=r.P,cg=Math.max(+P.gold||0,25000),cx=Math.max(+P.xp||0,lvx(8)),cp=P.pres|0;let capped=false;
  if((+q.gold||0)>cg){q.gold=cg;capped=true}if((+q.xp||0)>cx){q.xp=cx;capped=true}if((q.pres|0)>cp){q.pres=cp;capped=true}
  r.keyed=false;r.verified=false;r.capped=capped;
  if(capped){ST.capped++;try{const m=sgMeta();m.acNote='That save file was made on another device (or edited), so its coins and level were capped. To move your progress between devices, sign in to your account.';sgMetaSave()}catch(e){}}
  return r}}
 (async function boot(){try{
  const ck=await ckGet();let k=ck?await ckBits(ck):null;const legacy=k?null:await keyGet();if(!k)k=legacy;const raw=lsGet(KEY);let r=null;try{r=JSON.parse(lsGet(SIGK)||'null')}catch(e){}
  const on=enforce(),lb=ledgerBal();let an=k?await anGet():null;if(an&&an.m!==mac2(k,'an|'+an.g+'|'+an.x+'|'+an.p))an=null;AN=an;
  /* the last real values: the device-signed copy in IndexedDB, else the ledger and level 8 at most */
  const back=()=>an?revert(an.g,an.x,an.p):revert(lb!=null?lb:Math.min(+P.gold||0,25000),Math.min(+P.xp||0,lvx(8)),0);
  if(raw!==null&&on){
   if(k&&r&&typeof r.m2==='string'){
    if(r.m2!==mac2(k,'s|'+raw)){if(an)back();else if(r.a2===mac2(k,'a|'+r.g2+'|'+r.x2+'|'+r.p2))revert(r.g2,r.x2,r.p2);else back()}}
   else if(k){/* a key exists but the record has no device signature: written by something else */
    back()}
   else if(r&&typeof r.m2==='string'){/* the device key was deleted: nothing can be verified */
    revert(lb!=null?lb:Math.min(+P.gold||0,25000),Math.min(+P.xp||0,lvx(8)),0)}
   else if(P.ac3===1||sgMeta().v3k){/* this save had a device key on this browser before and it is gone now: nothing can be verified */
    ST.lost=1;revert(lb!=null?lb:Math.min(+P.gold||0,25000),Math.min(+P.xp||0,lvx(8)),0)}
   else{/* first start with this layer: coins must match the ledger */
    ST.migrated=1;if(lb!=null&&(+P.gold||0)>lb+1){ST.ledger++;revert(lb,+P.xp||0,P.pres|0)}}}
  /* every start: coins above the ledger's last balance go back to it */
  if(on){const b=ledgerBal();if(b!=null&&(+P.gold||0)>b+1){ST.ledger++;revert(b,+P.xp||0,P.pres|0)}}
  /* a new device key object (or, the first time after 10.1g, the readable key replaced by one); the old readable key is deleted */
  if(!ck){const nk=await ckNew(),nb=nk?await ckBits(nk):null;
   if(nb&&await ckPut(nk)){k=nb;AN=null;ST.key=1;ST.ck=1;if(legacy)await keyDel()}
   else if(!k){const a=new Uint8Array(16);try{TWAC0.rnd(a)}catch(e){for(let i=0;i<16;i++)a[i]=Math.random()*256|0}k=HX(a);if(await keyPut(k))ST.key=1;else k=null}}
  else ST.ck=1;
  DK=k;if(DK){try{const m=sgMeta();if(!m.v3k){m.v3k=1;sgMetaSave()}if(P.ac3!==1){P.ac3=1;save()}}catch(e){}const cur=lsGet(KEY);if(cur!==null){sign2(cur);lastK=lsGet(KEY);lastA=lsGet(SIGK)}}
 }catch(e){console.error(e)}finally{ST.ready=1}})();
 return Object.freeze({stat:()=>Object.assign({},ST,{dk:!!DK,enforced:enforce()})})})();
