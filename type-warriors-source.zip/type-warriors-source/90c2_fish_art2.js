/* ===== MOONLIT FISHING: fish art 2 — bramble, willow (commons) and frost, thorn, bog, twilight, rose, cinder, glass (uncommons) =====
   Each FISHART.<id>(g,t,o) draws one fish facing right, centred on the origin, ~200 units long. Helpers prefixed fa2_. */
/* path from a command list: 'M',x,y 'L',x,y 'Q',cx,cy,x,y 'C',c1x,c1y,c2x,c2y,x,y 'Z' */
function fa2_path(g,c){g.beginPath();let i=0;while(i<c.length){const k=c[i++];
 if(k==='M'){g.moveTo(c[i],c[i+1]);i+=2}else if(k==='L'){g.lineTo(c[i],c[i+1]);i+=2}
 else if(k==='Q'){g.quadraticCurveTo(c[i],c[i+1],c[i+2],c[i+3]);i+=4}
 else if(k==='C'){g.bezierCurveTo(c[i],c[i+1],c[i+2],c[i+3],c[i+4],c[i+5]);i+=6}else if(k==='Z')g.closePath()}}
/* crisp closed polygon */
function fa2_poly(g,p){g.beginPath();g.moveTo(p[0],p[1]);for(let i=2;i<p.length;i+=2)g.lineTo(p[i],p[i+1]);g.closePath()}
/* gradient with explicit stops [[pos,colour],...] */
function fa2_grad(g,x0,y0,x1,y1,s){const q=g.createLinearGradient(x0,y0,x1,y1);for(const e of s)q.addColorStop(e[0],e[1]);return q}
function fa2_rgrad(g,x,y,r0,r1,s){const q=g.createRadialGradient(x,y,r0,x,y,r1);for(const e of s)q.addColorStop(e[0],e[1]);return q}
/* run fn in a translated + rotated frame */
function fa2_at(g,x,y,a,fn){g.save();g.translate(x,y);g.rotate(a);fn();g.restore()}
/* twinkle 0..1 */
const fa2_tw=(t,i,sp)=>.5+.5*Math.sin(t*(sp||3)+i*1.91);
/* glossy highlight: a soft white curve inside the clip path */
function fa2_gloss(g,clip,x0,y0,cx,cy,x1,y1,w,a){g.save();clip();g.clip();g.lineCap='round';g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo(cx,cy,x1,y1);
 g.strokeStyle=`rgba(255,255,255,${a*.4})`;g.lineWidth=w*2.2;g.stroke();g.strokeStyle=`rgba(255,255,255,${a})`;g.lineWidth=w;g.stroke();g.restore()}
/* gill arc (clipped to the body) */
function fa2_gill(g,clip,x,y,r,a0,a1,c,a){g.save();clip();g.clip();g.beginPath();g.arc(x,y,r,a0,a1);g.strokeStyle=c||FKO;g.globalAlpha=a==null?.6:a;g.lineWidth=2.4;g.lineCap='round';g.stroke();g.restore()}
/* rib lines from a root point to each listed point, clipped to the clip path */
function fa2_ribs(g,clip,x0,y0,pts,a,c,lw){g.save();clip();g.clip();g.strokeStyle=c||FKO;g.globalAlpha=a==null?.25:a;g.lineWidth=lw||1.3;g.lineCap='round';
 for(let i=0;i<pts.length;i+=2){g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo((x0+pts[i])/2,(y0+pts[i+1])/2*1.04,pts[i],pts[i+1]);g.stroke()}g.restore()}
/* tapered strand along a chain of cubic beziers b=[x0,y0, c1x,c1y,c2x,c2y,x1,y1, ...] */
function fa2_strand(g,b,w0,w1,col,lw){const P=[[b[0],b[1]]];let x=b[0],y=b[1];
 for(let i=2;i+5<b.length;i+=6){const c1x=b[i],c1y=b[i+1],c2x=b[i+2],c2y=b[i+3],ex=b[i+4],ey=b[i+5];
  for(let s=1;s<=12;s++){const u=s/12,v=1-u;P.push([v*v*v*x+3*v*v*u*c1x+3*v*u*u*c2x+u*u*u*ex,v*v*v*y+3*v*v*u*c1y+3*v*u*u*c2y+u*u*u*ey])}x=ex;y=ey}
 const n=P.length,L=[],R=[];for(let i=0;i<n;i++){const a=P[Math.max(0,i-1)],c=P[Math.min(n-1,i+1)],dx=c[0]-a[0],dy=c[1]-a[1],d=Math.hypot(dx,dy)||1,w=(w0+(w1-w0)*i/(n-1))/2;
  L.push([P[i][0]-dy/d*w,P[i][1]+dx/d*w]);R.push([P[i][0]+dy/d*w,P[i][1]-dx/d*w])}
 g.beginPath();g.moveTo(L[0][0],L[0][1]);for(const p of L)g.lineTo(p[0],p[1]);for(let i=n-1;i>=0;i--)g.lineTo(R[i][0],R[i][1]);g.closePath();
 g.lineJoin='round';g.lineWidth=lw||2.2;g.strokeStyle=FKO;g.stroke();g.fillStyle=col;g.fill()}
/* eyelid: amt 0 open .. 1 shut */
function fa2_lid(g,x,y,r,amt,col){if(amt<=0)return;const ly=y-r+2*r*Math.min(1,amt);g.save();g.beginPath();g.arc(x,y,r,0,TAU);g.clip();
 g.beginPath();g.moveTo(x-r-3,y-r-3);g.lineTo(x+r+3,y-r-3);g.lineTo(x+r+3,ly);g.quadraticCurveTo(x,ly+r*.2,x-r-3,ly);g.closePath();g.fillStyle=col;g.fill();
 g.beginPath();g.moveTo(x+r+3,ly);g.quadraticCurveTo(x,ly+r*.2,x-r-3,ly);g.strokeStyle=FKO;g.lineWidth=Math.max(2,r*.26);g.stroke();g.restore();
 g.beginPath();g.arc(x,y,r,0,TAU);g.lineWidth=Math.max(2,r*.24);g.strokeStyle=FKO;g.stroke()}
/* blink: 0 open, rising to 1 for a quick blink every few seconds */
function fa2_blink(t,s){const p=((t+s)%5.1+5.1)%5.1;return p>4.9?1-Math.abs(p-5)/.1:0}
/* small cartoon smile */
function fa2_smile(g,x0,y0,cx,cy,x1,y1,w){g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo(cx,cy,x1,y1);g.strokeStyle=FKO;g.lineWidth=w||2.4;g.lineCap='round';g.stroke()}
/* rosy cheek blush */
function fa2_blush(g,x,y,r,c,a){g.save();g.globalAlpha=a==null?.45:a;g.fillStyle=fa2_rgrad(g,x,y,0,r,[[0,c||'#ff7aa0'],[1,(c||'#ff7aa0')+'00']]);g.beginPath();g.ellipse(x,y,r,r*.62,0,0,TAU);g.fill();g.restore()}
/* pectoral fin: a fan hinged at (x,y), sweeping back; a = tilt */
function fa2_pec(g,x,y,a,L,c1,c2,al,rim){fa2_at(g,x,y,a,()=>{const P=()=>fa2_path(g,['M',3,-3.5,'C',-L*.3,-L*.34,-L*.78,-L*.3,-L,-L*.08,'Q',-L*1.02,L*.08,-L*.9,L*.18,'Q',-L*.8,L*.3,-L*.62,L*.3,'C',-L*.36,L*.28,-L*.1,L*.12,3,3.5,'Z']);
 g.globalAlpha=al||1;P();fkFill(g,fkLin(g,0,0,-L,L*.1,[c1,c2]),2.2);g.globalAlpha=1;fa2_ribs(g,P,2,0,[-L,-L*.12,-L,L*.04,-L*.9,L*.2,-L*.7,L*.3],.3);
 g.save();P();g.clip();g.beginPath();g.moveTo(2,-3);g.bezierCurveTo(-L*.3,-L*.3,-L*.78,-L*.26,-L*.98,-L*.06);g.strokeStyle=rim||'rgba(255,255,255,.55)';g.lineWidth=2;g.stroke();g.restore()})}
/* 6-armed snowflake crystal */
function fa2_snow(g,x,y,r,rot,c,a){g.save();g.translate(x,y);g.rotate(rot);g.globalAlpha=a==null?1:a;g.strokeStyle=c||'#fff';g.lineCap='round';g.lineWidth=Math.max(1,r*.26);
 for(let i=0;i<6;i++){g.rotate(TAU/6);g.beginPath();g.moveTo(0,0);g.lineTo(r,0);g.moveTo(r*.55,0);g.lineTo(r*.8,-r*.24);g.moveTo(r*.55,0);g.lineTo(r*.8,r*.24);g.stroke()}
 g.beginPath();g.arc(0,0,r*.2,0,TAU);g.fillStyle=c||'#fff';g.fill();g.restore()}
/* catch-spectacle wash */
function fa2_catch(g,o,c,k){const v=(o.glow||0)*(k||1);if(v>0)fkGlow(g,10,0,115,c||'#fff2c8',.24*v)}
/* ribbon outline from a centre line fn(s)->[x,y,halfWidth]; returns flat points (left side then right side reversed) */
function fa2_rib(n,fn){const c=[];for(let i=0;i<=n;i++)c.push(fn(i/n));const L=[],R=[];
 for(let i=0;i<=n;i++){const a=c[Math.max(0,i-1)],b=c[Math.min(n,i+1)],dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy)||1,nx=-dy/d,ny=dx/d,w=c[i][2];
  L.push(c[i][0]+nx*w,c[i][1]+ny*w);R.unshift(c[i][0]-nx*w,c[i][1]-ny*w)}return L.concat(R)}
/* closed smooth spline (same curve as fkPath) appended to the current path when cont is true */
function fa2_blob(g,p,cont){const n=p.length/2,mx=i=>(p[(i%n)*2]+p[((i+1)%n)*2])/2,my=i=>(p[(i%n)*2+1]+p[((i+1)%n)*2+1])/2;if(!cont)g.beginPath();g.moveTo(mx(n-1),my(n-1));for(let i=0;i<n;i++)g.quadraticCurveTo(p[i*2],p[i*2+1],mx(i),my(i));g.closePath()}
/* clip to everything OUTSIDE a spline outline (so see-through bodies do not show the fin roots behind them) */
function fa2_outside(g,p){g.beginPath();g.rect(-400,-400,800,800);fa2_blob(g,p,1);g.clip('evenodd')}
/* crystal fin polygon: pre points, then an outer edge with a sharp ice shard between every pair of edge points, then post points */
function fa2_crys(pre,edge,post,len){const out=pre.slice();let cx=0,cy=0;const all=pre.concat(edge,post);for(let i=0;i<all.length;i+=2){cx+=all[i];cy+=all[i+1]}cx/=all.length/2;cy/=all.length/2;
 for(let i=0;i<edge.length;i+=2){out.push(edge[i],edge[i+1]);if(i+3<edge.length){const ax=edge[i],ay=edge[i+1],bx=edge[i+2],by=edge[i+3],mx=(ax+bx)/2,my=(ay+by)/2;let nx=-(by-ay),ny=bx-ax;const d=Math.hypot(nx,ny)||1;nx/=d;ny/=d;
  if(nx*(mx-cx)+ny*(my-cy)<0){nx=-nx;ny=-ny}const L=len*(i/2%2?.72:1);out.push(mx+nx*L,my+ny*L)}}
 return out.concat(post)}
/* ---------------- 9. Bramble Pike: long duck-billed hunter with a cream bramble-chain pattern ---------------- */
FISHART.bramble=(g,t,o)=>{const sw=fkSway(o,3.6,.14),fin=Math.sin(t*5)*.1;g.save();g.rotate(-sw*.18);
 const B=()=>fkPath(g,[117,1,112,-4,94,-7,78,-11,58,-18,20,-20,-20,-19,-50,-15,-70,-9,-82,-3,-82,3,-70,9,-50,15,-20,19,20,20,58,18,80,13,96,9,112,5]);
 const T=()=>fa2_path(g,['M',16,-7,'Q',-4,-8,-17,-19,'Q',-27,-29,-37,-38,'Q',-37,-16,-26,0,'Q',-37,16,-37,38,'Q',-27,29,-17,19,'Q',-4,8,16,7,'Z']);
 const fc1='#ff9a4a',fc2='#c0381e';
 // tail
 fa2_at(g,-76,0,sw,()=>{T();fkFill(g,fkLin(g,12,0,-40,0,['#4f8a2a',fc1,fc2]),2.6);
  fa2_ribs(g,T,8,0,[-37,-34,-33,-22,-28,-10,-28,10,-33,22,-37,34],.3);
  g.save();T();g.clip();g.fillStyle='#5a1a10';g.globalAlpha=.5;for(const p of [[-18,-13],[-27,-24],[-14,11],[-26,22],[-30,-5],[-21,4]]){g.beginPath();g.arc(p[0],p[1],2.1,0,TAU);g.fill()}
  g.globalAlpha=.5;g.strokeStyle='#ffe0a0';g.lineWidth=2;fa2_path(g,['M',4,-6,'Q',-14,-14,-34,-35]);g.stroke();g.restore()});
 // dorsal + anal fins set far back near the tail (swept, pike-style)
 const fs=(pts,rb,dots)=>{fkFin(g,pts,fc1,fc2,rb,2.4);g.save();fkPath(g,pts);g.clip();g.fillStyle='#5a1a10';g.globalAlpha=.45;for(const d of dots){g.beginPath();g.arc(d[0],d[1],1.9,0,TAU);g.fill()}g.restore()};
 fa2_at(g,-44,-15,fin*.5,()=>fs([12,4,4,-6,-6,-17,-18,-27,-24,-23,-27,-9,-24,4],[[6,0,-6,-18],[-4,0,-15,-22],[-14,0,-22,-18]],[[-8,-8],[-16,-14],[-20,-4]]));
 fa2_at(g,-50,14,-fin*.5,()=>fs([12,-4,4,6,-6,17,-18,26,-24,22,-27,9,-24,-4],[[6,0,-6,17],[-4,0,-15,21],[-14,0,-22,17]],[[-8,8],[-16,14],[-20,4]]));
 fa2_at(g,6,18,-fin,()=>fkFin(g,[6,-3,0,8,-12,12,-14,-2],fc1,fc2,[[0,0,-10,9]],2.4));
 // body
 B();fkFill(g,fa2_grad(g,0,-20,0,20,[[0,'#1a4a24'],[.28,'#2f7c2c'],[.52,'#7cb83a'],[.76,'#dfe8a2'],[1,'#fcf8dc']]),3);
 fkShade(g,B,-6,-21,'#0c3016',.45);
 // bramble chain: rows of cream beads linked by thin vine strokes
 g.save();B();g.clip();
 const rows=[[-8,9,0],[2.5,7.6,5],[-15.5,5.6,4]];
 rows.forEach((r,ri)=>{const y=r[0],st=r[1]*2.3;let px=null,py=null;
  for(let x=-74+r[2];x<84;x+=st){const k=Math.max(.2,Math.min(1,(88-x)/50)),yy=y+Math.sin(x*.12+ri)*1.4,rw=r[1]*.56*(.6+.4*k),rh=r[1]*.3*(.6+.4*k);
   if(px!==null){g.beginPath();g.moveTo(px,py);g.quadraticCurveTo((px+x)/2,(py+yy)/2-2.6,x,yy);g.strokeStyle='#eef0b0';g.globalAlpha=.5;g.lineWidth=1.2;g.stroke()}
   g.globalAlpha=.94;g.fillStyle='#f6f2c0';g.beginPath();g.ellipse(x,yy,rw,rh,-.15,0,TAU);g.fill();
   g.globalAlpha=.3;g.fillStyle='#2a5a1a';g.beginPath();g.ellipse(x+rw*.22,yy+rh*.35,rw*.55,rh*.3,-.15,0,TAU);g.fill();px=x;py=yy}});
 g.restore();g.globalAlpha=1;
 fkShade(g,B,8,21,'#e8d8a0',.3);
 fa2_gloss(g,B,98,-8,52,-21,-34,-15,2.8,.6);
 fa2_gill(g,B,84,1,21,Math.PI*.68,Math.PI*1.32,'#0c3016',.6);
 // duck-bill: mouth line and needle teeth
 g.save();B();g.clip();
 fa2_path(g,['M',118,1,'Q',98,3,78,6,'Q',75,6,74,4]);g.strokeStyle=FKO;g.lineWidth=2.4;g.stroke();
 g.fillStyle='#fffdf2';g.strokeStyle=FKO;g.lineWidth=1.1;
 for(let i=0;i<6;i++){const x=108-i*5.2,y=1.7+i*.75;g.beginPath();g.moveTo(x-2,y);g.lineTo(x,y+3.6);g.lineTo(x+2,y);g.closePath();g.fill();g.stroke()}
 for(let i=0;i<4;i++){const x=104-i*6.5,y=3.5+i*.75;g.beginPath();g.moveTo(x-1.7,y+.4);g.lineTo(x+.6,y-2.6);g.lineTo(x+2,y+.6);g.closePath();g.fill();g.stroke()}
 g.restore();
 g.beginPath();g.ellipse(103,-4,1.6,1,0,0,TAU);g.fillStyle=FKO;g.fill();
 fa2_pec(g,60,9,-.32+fin,19,fc1,fc2,.95);
 // patient, half-lidded hunter's eye
 fkEye(g,72,-9,9.5,'#f0b820',.45);fa2_lid(g,72,-9,9.5,Math.max(.32,fa2_blink(t,.6)),'#2f7c2c');
 fa2_catch(g,o,'#e8ffc0');g.restore()};
/* ---------------- 10. Willow Shiner: mirror-silver minnow with a lavender sheen ---------------- */
FISHART.willow=(g,t,o)=>{const sw=fkSway(o,5.6,.17),fin=Math.sin(t*7.5)*.13;g.save();g.rotate(-sw*.22);
 const B=()=>fkPath(g,[106,2,99,-9,76,-20,36,-25,-6,-21,-42,-12,-62,-6,-72,-3,-72,3,-62,6,-42,11,-6,19,36,23,76,18,99,10]);
 const T=()=>fa2_path(g,['M',14,-5,'Q',-4,-6,-16,-15,'Q',-30,-29,-46,-42,'Q',-46,-33,-41,-24,'Q',-31,-8,-21,0,'Q',-31,8,-41,24,'Q',-46,33,-46,42,'Q',-30,29,-16,15,'Q',-4,6,14,5,'Z']);
 // tail: lilac fork with pink tips
 fa2_at(g,-66,0,sw,()=>{g.globalAlpha=.94;T();fkFill(g,fkLin(g,8,0,-46,0,['#c8c0ff','#e6c8ff','#ff9ad0']),2.6);g.globalAlpha=1;
  fa2_ribs(g,T,8,0,[-45,-39,-40,-28,-32,-14,-32,14,-40,28,-45,39],.22,'#5a3a8a');
  g.save();T();g.clip();g.globalAlpha=.65;g.strokeStyle='#fff';g.lineWidth=2.6;fa2_path(g,['M',4,-5,'Q',-18,-14,-45,-40]);g.stroke();g.restore()});
 // fins
 fa2_at(g,4,-21,fin*.6,()=>fkFin(g,[12,2,6,-7,-4,-19,-10,-21,-14,-8,-16,2],'#ece0ff','#a888e8',[[6,0,-4,-17],[-2,0,-9,-18],[-10,0,-13,-10]],2.4));
 fa2_at(g,18,18,-fin,()=>fkFin(g,[6,-2,-2,9,-13,11,-12,-2],'#ffe0f0','#e88ac0',[[0,0,-10,9]],2.2));
 fa2_at(g,-34,12,fin*.7,()=>fkFin(g,[6,-2,-1,9,-14,10,-14,-2],'#ffe0f0','#e88ac0',[[0,0,-10,9]],2.2));
 // body: mirror silver with lavender back and pink flank
 B();fkFill(g,fa2_grad(g,0,-25,0,23,[[0,'#46449e'],[.2,'#7c80d8'],[.38,'#dfe4ff'],[.5,'#ffffff'],[.62,'#f0eaff'],[.78,'#ffd2ec'],[1,'#fff4fb']]),3);
 // mirror bands + iridescent shimmer sliding with time
 g.save();B();g.clip();const sh=Math.sin(t*1.3)*30;
 g.globalAlpha=.3;g.fillStyle=fa2_grad(g,-70+sh,-20,90+sh,20,[[0,'#7ae0ff'],[.3,'#c8a0ff'],[.55,'#ffa8d8'],[.8,'#a8f0ff'],[1,'#c8a0ff']]);g.fillRect(-80,-30,200,60);
 g.globalAlpha=.32;g.fillStyle='#3a3890';fa2_path(g,['M',96,-9,'Q',30,-15,-74,-5,'L',-74,-3,'Q',30,-10,96,-6,'Z']);g.fill();
 g.globalAlpha=.45;g.fillStyle='#ff9ad0';fa2_path(g,['M',90,6,'Q',30,10,-74,4,'L',-74,7,'Q',30,15,90,10,'Z']);g.fill();
 // fine silver scale glitter
 g.globalAlpha=1;for(let r=0;r<5;r++)for(let c=0;c<16;c++){const x=82-c*9.4-(r%2?4.7:0),y=-14+r*7;const k=fa2_tw(t,c*3+r*7,1.7);if(k<.55)continue;g.globalAlpha=(k-.55)*1.4;g.fillStyle='#ffffff';g.beginPath();g.arc(x,y,1.1,0,TAU);g.fill()}
 g.restore();g.globalAlpha=1;
 fkScales(g,B,-70,90,-24,22,8,'#8a7ad8',.13);
 fkShade(g,B,-4,-26,'#24206a',.38);
 // gleaming lateral line
 g.save();B();g.clip();fa2_path(g,['M',92,-2,'Q',30,-5,-74,0]);g.strokeStyle='#c8a8ff';g.lineWidth=5.5;g.globalAlpha=.5;g.stroke();
 g.strokeStyle='#ffffff';g.lineWidth=2.2;g.globalAlpha=1;g.stroke();g.restore();
 // dark speckles along the back
 g.save();B();g.clip();g.fillStyle='#2a2670';g.globalAlpha=.5;for(let i=0;i<9;i++){g.beginPath();g.arc(60-i*14,-18+Math.abs(i-4)*.9+(i%2)*2,1.3,0,TAU);g.fill()}g.restore();g.globalAlpha=1;
 fkShade(g,B,8,24,'#f0a8d8',.25);
 fa2_gloss(g,B,84,-14,36,-24,-32,-16,3,.72);
 fa2_gill(g,B,92,0,22,Math.PI*.72,Math.PI*1.28,'#3a2a6a',.55);
 fa2_pec(g,64,7,-.35+fin,20,'#fff0f8','#e88ac0',.92);
 fkEye(g,78,-6,10.5,'#5060d8',.3);fa2_lid(g,78,-6,10.5,fa2_blink(t,1.7),'#8a8ee0');
 fa2_blush(g,87,8,6,'#ff7ab0',.5);
 fa2_smile(g,101,5,97,9,92,7,2.2);
 // glints
 fkSpark(g,28,-15,5+fa2_tw(t,0,2.4)*2.5,'#fff',.55+.45*fa2_tw(t,0,2.4));
 fkSpark(g,-34,-6,3+fa2_tw(t,2,2.1)*2,'#fff',.3+.6*fa2_tw(t,2,2.1));
 fkSpark(g,56,8,2.4+fa2_tw(t,4,2.8)*1.6,'#ffe0f4',.3+.6*fa2_tw(t,4,2.8));
 fa2_catch(g,o,'#f4e0ff');g.restore()};
/* ---------------- 11. Frostscale Trout: icy trout with snowflake spots and crystal fins ---------------- */
FISHART.frost=(g,t,o)=>{const sw=fkSway(o,3.4,.14),fin=Math.sin(t*4)*.1,gl=o.glow||0;g.save();g.rotate(-sw*.2);
 // cold aura
 fkGlow(g,10,0,105,'#5ad0ff',.13+.05*Math.sin(t*1.6)+gl*.25);
 const B=()=>fkPath(g,[105,4,99,-11,76,-26,38,-32,-4,-29,-38,-19,-58,-9,-72,-5,-72,5,-58,8,-38,16,-4,26,38,30,76,24,99,14]);
 const ice1='rgba(230,250,255,.95)',ice2='rgba(120,196,255,.78)';
 // crystal fin: icy gradient, facet lines from the root to each shard tip, white rim
 const iceFin=(pts,rx,ry)=>{const P=()=>fa2_poly(g,pts);P();fkFill(g,fkLin(g,rx,ry,rx-40,ry+30,[ice1,ice2]),2.3);
  g.save();P();g.clip();g.strokeStyle='#ffffff';g.globalAlpha=.45;g.lineWidth=1.1;for(let i=0;i<pts.length;i+=4){g.beginPath();g.moveTo(rx,ry);g.lineTo(pts[i],pts[i+1]);g.stroke()}
  g.globalAlpha=.85;g.translate(-1.3,-1.3);P();g.lineWidth=2.2;g.stroke();g.restore()};
 // tail: square trout tail with a crystal fringe
 const TP=fa2_crys([14,-8,-6,-12],[-20,-25,-34,-38,-40,-26,-42,-12,-39,0,-42,12,-40,26,-34,38,-20,25],[-6,12,14,8],8);
 fa2_at(g,-66,0,sw,()=>{iceFin(TP,8,0);g.save();fa2_poly(g,TP);g.clip();fa2_snow(g,-28,-18,4,t*.3,'#fff',.85);fa2_snow(g,-29,15,3.5,-t*.3,'#fff',.8);g.restore()});
 // dorsal crystal crown, adipose, anal, pelvic
 iceFin(fa2_crys([32,-29],[26,-40,16,-50,4,-55,-8,-52,-18,-44,-24,-34],[-26,-27],8.5),4,-28);
 fa2_at(g,-44,-16,fin*.4,()=>iceFin(fa2_crys([6,-1],[2,-9,-6,-13,-13,-9],[-12,2],4),-2,0));
 fa2_at(g,-34,18,-fin*.6,()=>iceFin(fa2_crys([10,-3],[6,8,-2,14,-12,15,-18,10],[-16,-3],5),2,0));
 fa2_at(g,8,27,-fin,()=>iceFin(fa2_crys([8,-3],[4,7,-4,11,-12,9],[-12,-2],4.5),2,0));
 // body: deep blue back to ice-white belly
 B();fkFill(g,fa2_grad(g,0,-32,0,30,[[0,'#143a8c'],[.3,'#2c74dc'],[.55,'#78c6ff'],[.78,'#d2f2ff'],[1,'#f6fcff']]),3);
 fkScales(g,B,-70,90,-30,28,8,'#1a4a9a',.2);
 fkShade(g,B,-8,-33,'#0a2666',.45);
 // lilac-ice lateral band (a frosty take on the rainbow trout's stripe)
 g.save();B();g.clip();fa2_path(g,['M',100,4,'Q',40,-6,-74,0,'L',-74,7,'Q',40,6,100,10,'Z']);g.fillStyle='#c8b0ff';g.globalAlpha=.5;g.fill();
 g.globalAlpha=.9;fa2_path(g,['M',98,3,'Q',40,-5,-74,1]);g.strokeStyle='#effcff';g.lineWidth=1.6;g.stroke();g.restore();
 // snowflake spots
 g.save();B();g.clip();
 const S=[[50,-20,5.2],[28,-25,4.4],[8,-18,5],[-14,-23,4.2],[-34,-12,4.6],[-52,-5,3.6],[36,-9,3.4],[16,-6,3.8],[-4,-8,3.2],[-24,-2,3.4],[62,-27,3],[0,-28,3.2],[20,14,2.6],[-40,10,2.6],[-60,3,2.4]];
 S.forEach((s,i)=>{fa2_snow(g,s[0],s[1],s[2],i*.5+Math.sin(t*.8+i)*.15,'#ffffff',.8+.2*fa2_tw(t,i,2))});g.restore();
 fkShade(g,B,10,30,'#bfe8ff',.3);
 // frost rime creeping along the back edge
 g.save();B();g.clip();g.translate(0,3);B();g.strokeStyle='rgba(235,252,255,.55)';g.lineWidth=3;g.setLineDash([2,5]);g.stroke();g.setLineDash([]);g.restore();
 fa2_gloss(g,B,84,-19,38,-31,-28,-26,3.2,.75);
 fa2_gill(g,B,98,2,28,Math.PI*.73,Math.PI*1.27,'#0e2a6a',.6);
 // crystal pectoral
 fa2_pec(g,66,9,-.32+fin,22,'#effcff','#7cc4ff',.9);fa2_at(g,66,9,-.32+fin,()=>{for(const p of [[-22,-6],[-23,1],[-19,7]])fa2_snow(g,p[0],p[1],1.8,.4,'#fff',.85)});
 fkEye(g,80,-10,11,'#38aef0',.3);fa2_lid(g,80,-10,11,fa2_blink(t,2.3),'#2c74dc');
 fa2_smile(g,102,7,98,11,92,9,2.3);
 fa2_blush(g,90,6,6,'#a8d8ff',.6);
 // drifting frost sparkles
 for(let i=0;i<7;i++){const p=((t*.22+i/7)%1),x=-80+i*27+Math.sin(t*1.3+i*2)*8,y=34-p*90;fkSpark(g,x,y,(2.2+i%3)*(1-Math.abs(p-.5)*1.4),'#e8fbff',(1-Math.abs(p*2-1))*.9)}
 fkGlow(g,40,-20,30,'#bff4ff',.1+.08*fa2_tw(t,1,2)+gl*.3);
 g.restore()};
/* ---------------- 12. Thornback Gar: bronze-armoured needle-snout with a ridge of thorns ---------------- */
FISHART.thorn=(g,t,o)=>{const sw=fkSway(o,3,.12),fin=Math.sin(t*4.4)*.1;g.save();g.rotate(-sw*.16);
 const B=()=>fkPath(g,[116,0,111,-3.5,84,-5,64,-9,46,-17,10,-21,-30,-19,-60,-12,-76,-4,-76,4,-60,12,-30,19,10,21,46,17,64,9,84,5,111,3.5]);
 const T=()=>fa2_path(g,['M',14,-9,'Q',-6,-11,-18,-21,'Q',-34,-31,-43,-18,'Q',-47,-4,-41,4,'Q',-35,21,-20,21,'Q',-6,12,14,9,'Z']);
 const tc1='#5ae0c0',tc2='#167a70';
 // tail (rounded spade)
 fa2_at(g,-70,0,sw,()=>{T();fkFill(g,fkLin(g,10,-10,-40,10,['#b8762a',tc1,tc2]),2.6);fa2_ribs(g,T,8,0,[-40,-21,-45,-8,-43,4,-37,17],.3);
  g.save();T();g.clip();g.fillStyle='#0e3a3a';g.globalAlpha=.5;for(const p of [[-24,-14],[-34,-8],[-30,8],[-18,10],[-38,0]]){g.beginPath();g.arc(p[0],p[1],2.2,0,TAU);g.fill()}g.restore()});
 // thorn ridge along the back: hooked bronze thorns with pale tips
 for(let i=0;i<9;i++){const x=40-i*11.6,by=-18+Math.pow((i-3)/6,2)*6,h=15-Math.abs(i-3)*1.1,k=Math.sin(t*3+i*.6)*.6;
  g.beginPath();g.moveTo(x+6,by+5);g.quadraticCurveTo(x+4,by-h*.55,x-5+k,by-h);g.quadraticCurveTo(x-2,by-h*.35,x-6,by+5);g.closePath();
  fkFill(g,fkLin(g,x,by,x-4,by-h,['#7a3c12','#d88a32','#fff2c0']),2.2)}
 // fins near the tail + pelvic
 fa2_at(g,-52,-12,fin*.5,()=>fkFin(g,[8,2,2,-10,-10,-17,-21,-11,-19,2],tc1,tc2,[[2,0,-4,-12],[-8,0,-14,-13]],2.4));
 fa2_at(g,-52,12,-fin*.5,()=>fkFin(g,[8,-2,2,10,-10,17,-21,11,-19,-2],tc1,tc2,[[2,0,-4,12],[-8,0,-14,13]],2.4));
 fa2_at(g,-8,19,-fin,()=>fkFin(g,[6,-3,0,8,-12,11,-12,-2],tc1,tc2,[[0,0,-9,8]],2.4));
 // body
 B();fkFill(g,fa2_grad(g,0,-21,0,21,[[0,'#542810'],[.28,'#9c561c'],[.52,'#dc963a'],[.78,'#f2d088'],[1,'#fff0c8']]),3);
 // diamond armour plates: light upper-left edges, dark lower-right edges
 g.save();B();g.clip();const W=15,H=11;g.lineCap='round';
 for(let r=-2;r<=2;r++)for(let c=0;c<10;c++){const x=44-c*W-(r&1?W/2:0),y=r*H*.5;if(x<-82)continue;const fade=Math.max(0,Math.min(1,(52-x)/12));
  const L=[x-W*.5,y],Tp=[x,y-H*.5],R=[x+W*.5,y],Bt=[x,y+H*.5];
  g.globalAlpha=.16*fade;g.fillStyle='#3a1a06';g.beginPath();g.moveTo(L[0],L[1]);g.lineTo(R[0],R[1]);g.lineTo(Bt[0],Bt[1]);g.closePath();g.fill();
  g.globalAlpha=.6*fade;g.strokeStyle='#4a2008';g.lineWidth=1.5;g.beginPath();g.moveTo(L[0],L[1]);g.lineTo(Bt[0],Bt[1]);g.lineTo(R[0],R[1]);g.stroke();
  g.globalAlpha=.55*fade;g.strokeStyle='#fff0c0';g.lineWidth=1.3;g.beginPath();g.moveTo(L[0]+1.5,L[1]-.3);g.lineTo(Tp[0],Tp[1]+1.2);g.lineTo(R[0]-1.5,R[1]-.3);g.stroke();
  if((r*3+c)%4===0){g.globalAlpha=.3*fade;g.fillStyle='#3ad8b8';g.beginPath();g.moveTo(x,y-H*.28);g.lineTo(x+W*.24,y);g.lineTo(x,y+H*.28);g.lineTo(x-W*.24,y);g.fill()}}
 g.restore();g.globalAlpha=1;
 fkShade(g,B,-4,-22,'#3a1a08',.4);fkShade(g,B,9,22,'#fff0c0',.3);
 fa2_gloss(g,B,106,-3,62,-12,-40,-16,2.6,.6);
 fa2_gill(g,B,60,0,18,Math.PI*.66,Math.PI*1.34,'#3a1a08',.7);
 // needle snout: mouth line and tiny teeth
 g.save();B();g.clip();fa2_path(g,['M',117,0.5,'Q',92,1,64,3,'Q',60,3,58,1]);g.strokeStyle=FKO;g.lineWidth=2;g.stroke();
 g.fillStyle='#fffdf2';g.strokeStyle=FKO;g.lineWidth=.9;
 for(let i=0;i<8;i++){const x=110-i*6;g.beginPath();g.moveTo(x-1.5,.8);g.lineTo(x,3.4);g.lineTo(x+1.5,.8);g.closePath();g.fill();g.stroke();
  if(i%2){g.beginPath();g.moveTo(x-4.2,1.9);g.lineTo(x-3,-.4);g.lineTo(x-1.8,1.9);g.closePath();g.fill();g.stroke()}}g.restore();
 g.beginPath();g.ellipse(104,-2.2,1.3,.8,0,0,TAU);g.fillStyle=FKO;g.fill();
 fa2_pec(g,54,8,-.3+fin,18,tc1,tc2,.95);
 fkEye(g,62,-7,9,'#f4a820',.5);fa2_lid(g,62,-7,9,fa2_blink(t,3.1),'#9c561c');
 // stern armoured brow plate
 g.beginPath();g.moveTo(52,-14);g.quadraticCurveTo(62,-19.5,72,-13);g.lineTo(70,-11);g.quadraticCurveTo(62,-15.5,54,-11.5);g.closePath();fkFill(g,'#c07a2a',2);
 fa2_catch(g,o,'#ffe0a0',1.2);g.restore()};
/* ---------------- 13. Bog Puffer: half-puffed spiky ball with a surprised beak ---------------- */
FISHART.bog=(g,t,o)=>{const fl=o.flex||0,sw=fkSway(o,6,.2),fin=Math.sin(t*14)*.35,br=1+.025*Math.sin(t*2.2)+fl*.07;g.save();g.rotate(-sw*.1);
 const cx=6,cy=2,rx=66*br,ry=58*br;
 const B=()=>{g.beginPath();g.ellipse(cx,cy,rx,ry,0,0,TAU)};
 const T=()=>fa2_path(g,['M',10,-9,'Q',-6,-12,-16,-20,'Q',-30,-24,-32,-12,'Q',-30,0,-32,12,'Q',-30,24,-16,20,'Q',-6,12,10,9,'Z']);
 const fc1='#ffb04a',fc2='#e8601e';
 // tiny tail
 fa2_at(g,cx-rx+8,0,sw,()=>{T();fkFill(g,fkLin(g,8,0,-32,0,[fc1,fc2]),2.4);fa2_ribs(g,T,6,0,[-30,-18,-32,-6,-32,6,-30,18],.3)});
 // spikes around the outline
 const N=26;for(let i=0;i<N;i++){const a=i/N*TAU+.06;if(Math.cos(a)<-.86&&Math.abs(Math.sin(a))<.35)continue;if(Math.cos(a)>.7&&Math.sin(a)>-.25&&Math.sin(a)<.55)continue;
  const ex=cx+Math.cos(a)*rx,ey=cy+Math.sin(a)*ry,nx=Math.cos(a),ny=Math.sin(a),tx=-ny,ty=nx,h=10+(i%2)*2,bw=4.6;
  g.beginPath();g.moveTo(ex-nx*4+tx*bw,ey-ny*4+ty*bw);g.lineTo(ex+nx*h,ey+ny*h);g.lineTo(ex-nx*4-tx*bw,ey-ny*4-ty*bw);g.closePath();
  fkFill(g,ny<0?'#8ab02a':'#f0e070',2.2)}
 // dorsal and anal stubs near the tail
 fa2_at(g,cx-rx*.62,cy-ry*.72,-.6+fin*.3,()=>fkFin(g,[6,2,2,-10,-8,-14,-14,-6,-10,4],fc1,fc2,[[0,0,-6,-10]],2.3));
 fa2_at(g,cx-rx*.62,cy+ry*.72,.6-fin*.3,()=>fkFin(g,[6,-2,2,10,-8,14,-14,6,-10,-4],fc1,fc2,[[0,0,-6,10]],2.3));
 // body
 B();fkFill(g,fa2_grad(g,0,cy-ry,0,cy+ry,[[0,'#4f7c12'],[.3,'#93be2c'],[.55,'#d8e04a'],[.78,'#fff2a6'],[1,'#fffbe0']]),3.2);
 // dark spots on the back
 g.save();B();g.clip();const SP=[[-36,-34,7],[-14,-44,6],[10,-48,5],[-48,-14,6],[-26,-18,5.5],[-2,-28,6.5],[22,-36,4.5],[-58,6,4.5],[36,-44,3.8],[-40,10,3.6]];
 SP.forEach(s=>{g.fillStyle='#2f5210';g.globalAlpha=.75;g.beginPath();g.ellipse(cx+s[0]*br,cy+s[1]*br,s[2],s[2]*.85,.3,0,TAU);g.fill();g.globalAlpha=.25;g.fillStyle='#e8f080';g.beginPath();g.arc(cx+s[0]*br-s[2]*.3,cy+s[1]*br-s[2]*.3,s[2]*.35,0,TAU);g.fill()});
 // tiny spike nubs across the skin
 g.globalAlpha=.45;g.strokeStyle='#3a5a10';g.lineWidth=1.3;
 for(let r=-3;r<=3;r++)for(let c=-4;c<=4;c++){const x=cx+c*15+(r&1?7:0),y=cy+r*15;if(((x-cx)/rx)**2+((y-cy)/ry)**2>.72||x>40&&y<10)continue;g.beginPath();g.moveTo(x-2.4,y+1.6);g.lineTo(x,y-2.2);g.lineTo(x+2.4,y+1.6);g.stroke()}
 g.restore();g.globalAlpha=1;
 fkShade(g,B,cy,cy+ry,'#ffe890',.35);fkShade(g,B,cy-10,cy-ry,'#2a4a08',.3);
 // belly stripes
 g.save();B();g.clip();g.globalAlpha=.35;g.strokeStyle='#d8b850';g.lineWidth=1.6;for(let i=0;i<3;i++){g.beginPath();g.ellipse(cx+6,cy+ry*.2+i*9,rx*.66-i*6,ry*.4,0,Math.PI*.2,Math.PI*.8);g.stroke()}g.restore();
 fa2_gloss(g,B,cx+38*br,cy-42*br,cx-6,cy-58*br,cx-46*br,cy-34*br,4,.7);
 // stubby fluttering pectoral
 fa2_pec(g,cx+30*br,cy+10*br,-.15+fin,22,fc1,fc2,.96);
 // surprised face: big eye, raised brow, round beak
 const ex=cx+38*br,ey=cy-18*br;fkEye(g,ex,ey,14,'#3a6a20',.2);fa2_lid(g,ex,ey,14,fa2_blink(t,.4),'#93be2c');
 g.beginPath();g.moveTo(ex-10,ey-21);g.quadraticCurveTo(ex+1,ey-28,ex+12,ey-21);g.strokeStyle=FKO;g.lineWidth=3;g.stroke();
 fa2_blush(g,cx+44*br,cy+8*br,9,'#ff7a8a',.55);
 // puckered beak: lips, dark mouth and two little tooth plates
 const mx=cx+rx+2,my=cy+8;
 g.beginPath();g.ellipse(mx,my,7,9,0,0,TAU);fkFill(g,fkLin(g,mx-6,my-8,mx+6,my+8,['#ffd27a','#f09a3a']),2.6);
 g.beginPath();g.ellipse(mx+1.5,my,3.6,5.6,0,0,TAU);g.fillStyle='#4a1424';g.fill();
 g.fillStyle='#fffdf2';g.strokeStyle=FKO;g.lineWidth=1.2;
 g.beginPath();g.moveTo(mx-1.5,my-5.4);g.quadraticCurveTo(mx+2,my-6.8,mx+4.8,my-4.6);g.lineTo(mx+4.2,my-2);g.quadraticCurveTo(mx+1.6,my-1.2,mx-1.2,my-2.4);g.closePath();g.fill();g.stroke();
 g.beginPath();g.moveTo(mx-1.5,my+5.4);g.quadraticCurveTo(mx+2,my+6.8,mx+4.8,my+4.6);g.lineTo(mx+4.2,my+2.2);g.quadraticCurveTo(mx+1.6,my+1.4,mx-1.2,my+2.6);g.closePath();g.fill();g.stroke();
 g.beginPath();g.arc(mx-3,my-4,1.6,0,TAU);g.fillStyle='rgba(255,255,255,.8)';g.fill();
 fa2_catch(g,o,'#f8ffb0',1.2);g.restore()};
/* ---------------- 14. Twilight Eel: S-curved indigo eel with stars that wake one by one ---------------- */
/* smoothstep */
function fa2_ss(a,b,x){x=Math.min(1,Math.max(0,(x-a)/(b-a)));return x*x*(3-2*x)}
/* ribbon outline with separate widths each side: fn(s)->[x,y,wBelow,wAbove]; s runs s0..s1 */
function fa2_rib2(n,s0,s1,fn){const c=[];for(let i=0;i<=n;i++)c.push(fn(s0+(s1-s0)*i/n));const L=[],R=[];
 for(let i=0;i<=n;i++){const a=c[Math.max(0,i-1)],b=c[Math.min(n,i+1)],dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy)||1,nx=-dy/d,ny=dx/d;
  L.push(c[i][0]+nx*c[i][2],c[i][1]+ny*c[i][2]);R.unshift(c[i][0]-nx*c[i][3],c[i][1]-ny*c[i][3])}return L.concat(R)}
FISHART.twilight=(g,t,o)=>{const fl=o.flex||0,gl=o.glow||0,sp=1.6*(1+fl*1.3),A=33,PH=.36*(1+fl*1.7),ss=fa2_ss;g.save();
 // centre line: a deep S (one full wave nose to tail), the head held level on a crest; a travelling ripple keeps it swimming
 const C=s=>{const env=(1-.42*ss(.7,1,s))*(.8+.2*ss(-.06,.3,s));return [-96+196*s,-A*env*Math.cos(TAU*(s-.87)/.74+PH*Math.sin(t*sp-s*3.4))+6]};
 const N=s=>{const a=C(s-.006),b=C(s+.006),dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy)||1;return [-dy/d,dx/d]};
 const Wd=s=>s<=0?0:s<.86?.5+19.5*Math.pow(s/.86,.8)+1.6*Math.exp(-(((s-.88)/.05)**2)):20.5*Math.pow(Math.max(0,1-((s-.86)/.14)**2),.55)+1.6*Math.exp(-(((s-.88)/.05)**2));
 // ribbon fins: thin along back and belly, swelling into a rounded paddle around the pointed tail tip
 const rip=s=>.8*Math.sin(s*34-t*4.6)*ss(0,.1,s);
 const fw=(s,e0,e1)=>s<0?8.6*Math.sqrt(Math.max(0,1-(s/.062)**2)):(5.2+3.4*(1-ss(0,.17,s))+rip(s))*(1-ss(e0,e1,s));
 const ptsFin=fa2_rib2(110,-.062,.8,s=>{const c=C(s),w=Wd(s)*.9;return [c[0],c[1],w+fw(s,.4,.67),w+fw(s,.5,.77)]});
 const ptsBody=fa2_rib(90,s=>{const c=C(s);return [c[0],c[1],Wd(s)]});
 const BD=()=>fkPath(g,ptsBody),FN=()=>fkPath(g,ptsFin);
 fkGlow(g,0,0,112,'#7a5aff',.12+.05*Math.sin(t*1.2)+gl*.3);
 // translucent silk fin: pink to violet, ribbed, dark outline
 g.save();g.globalAlpha=.74;FN();g.fillStyle=fkLin(g,74,0,-110,0,['#ffb0ee','#f47ee6','#c464f2','#8c50ea']);g.fill();g.restore();
 g.save();FN();g.clip();g.lineCap='round';
 g.strokeStyle='rgba(255,226,252,.35)';g.lineWidth=3.4;FN();g.stroke();
 g.strokeStyle='#3a0c5e';g.globalAlpha=.34;g.lineWidth=1.15;
 for(let i=0;i<=40;i++){const s=.012+i/40*.74,c=C(s),n=N(s),w=Wd(s);g.beginPath();g.moveTo(c[0]+n[0]*w*.8,c[1]+n[1]*w*.8);g.lineTo(c[0]+n[0]*(w+11),c[1]+n[1]*(w+11));
  g.moveTo(c[0]-n[0]*w*.8,c[1]-n[1]*w*.8);g.lineTo(c[0]-n[0]*(w+11),c[1]-n[1]*(w+11));g.stroke()}
 {const c=C(.03),b=C(0),ba=Math.atan2(b[1]-c[1],b[0]-c[0]);for(let k=-3;k<=3;k++){const a=ba+k*.36;g.beginPath();g.moveTo(c[0],c[1]);g.lineTo(c[0]+Math.cos(a)*16,c[1]+Math.sin(a)*16);g.stroke()}}
 g.restore();FN();g.lineJoin='round';g.lineWidth=2.4;g.strokeStyle=FKO;g.stroke();
 // body
 BD();fkFill(g,fkLin(g,-100,0,100,0,['#1e1a6a','#3a2296','#5a2aa8','#6e34b4']),3);
 // pale belly band + dark back band following the curve
 const band=(off,wf,col,a)=>{const P=fa2_rib(60,s=>{const c=C(s),n=N(s),w=Wd(s);return [c[0]+n[0]*w*off,c[1]+n[1]*w*off,w*wf]});
  g.save();BD();g.clip();fkPath(g,P);g.fillStyle=col;g.globalAlpha=a;g.fill();g.restore()};
 band(.72,.42,'#c88ae8',.45);band(-.78,.3,'#140c4a',.5);
 g.save();BD();g.clip();g.translate(-1.6,-2.2);BD();g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=2.4;g.stroke();g.restore();
 // star dots that wake one by one
 g.save();BD();g.clip();
 for(let i=0;i<20;i++){const s=.07+i*.038,row=i%2,c=C(s),n=N(s),w=Wd(s),off=row?.42:-.38;
  const x=c[0]+n[0]*w*off,y=c[1]+n[1]*w*off,wake=Math.max(0,Math.sin(t*1.1-i*.42)),k=.35+.65*wake,col=row?'#ff8ae0':'#6af0ff',r=(row?1.8:2.3)*Math.min(1,.35+w/14);
  g.globalAlpha=.3*k;g.fillStyle=col;g.beginPath();g.arc(x,y,r*2.8,0,TAU);g.fill();
  g.globalAlpha=k;g.beginPath();g.arc(x,y,r,0,TAU);g.fill();g.globalAlpha=k*.95;g.fillStyle='#fff';g.beginPath();g.arc(x,y,r*.5,0,TAU);g.fill()}
 g.restore();g.globalAlpha=1;
 for(let i=0;i<20;i+=5){const s=.07+i*.038,c=C(s),n=N(s);const k=Math.max(0,Math.sin(t*1.1-i*.42));if(k>.3)fkSpark(g,c[0]-n[0]*Wd(s)*.38,c[1]-n[1]*Wd(s)*.38,3+4*k,'#e8fbff',k)}
 // head frame
 const h=C(.87),h2=C(.9),ha=Math.atan2(h2[1]-h[1],h2[0]-h[0]);
 fa2_at(g,h[0],h[1],ha,()=>{const fin=Math.sin(t*6)*.3;
  g.beginPath();g.arc(9,2,18,Math.PI*.72,Math.PI*1.27);g.strokeStyle='#0c0630';g.globalAlpha=.7;g.lineWidth=2.4;g.lineCap='round';g.stroke();g.globalAlpha=1;
  fa2_at(g,-13,13,-.45+fin,()=>{const P=()=>fkPath(g,[3,-3,-6,-8,-16,-5,-16,4,-6,7]);P();fkFill(g,fkLin(g,0,0,-16,4,['#ffb0f0','#a84ae8']),2.2);fa2_ribs(g,P,2,0,[-15,-4,-16,0,-14,4],.3)});
  fkEye(g,9,-5,11,'#ff6ad0',.3);fa2_lid(g,9,-5,11,fa2_blink(t,3.7),'#5a2aa8');
  fa2_smile(g,24,4,20,8.5,13,7,2.3);
  fa2_blush(g,11,9,5.5,'#ff7ad0',.5)});
 fkGlow(g,h[0]-30,h[1],34,'#ff8ae0',.12+.08*fa2_tw(t,2,1.4)+gl*.3);
 g.restore()};
/* ---------------- 15. Rosefin Angelfish: tall pearl angelfish striped like a rose garden ---------------- */
FISHART.rose=(g,t,o)=>{const sw=fkSway(o,2.6,.12),fin=Math.sin(t*2.2),gl=o.glow||0;g.save();g.rotate(-sw*.15);
 const B=()=>fkPath(g,[106,0,98,-6,74,-28,46,-48,10,-52,-24,-40,-44,-20,-50,0,-44,20,-24,40,10,52,46,48,74,28,98,6]);
 const stripes=(clip)=>{g.save();clip();g.clip();
  const band=(x,w,c1,c2,ed)=>{fa2_path(g,['M',x+w,-95,'Q',x+w-16,0,x+w,95,'L',x-w,95,'Q',x-w-16,0,x-w,-95,'Z']);g.fillStyle=fa2_grad(g,x-w-8,0,x+w,0,[[0,c2],[.5,c1],[1,c2]]);g.fill();
   if(ed){g.strokeStyle=ed;g.lineWidth=2;g.globalAlpha=.9;g.stroke();g.globalAlpha=1}};
  band(66,5,'#ff8ab4','#ff6a9e');band(-24,8,'#e8407a','#ff6a9a');band(-60,6,'#a8164e','#d4306e');
  {const x=22,w=13;fa2_path(g,['M',x+w,-95,'Q',x+w-16,0,x+w,95,'L',x-w,95,'Q',x-w-16,0,x-w,-95,'Z']);g.fillStyle=fa2_grad(g,x-w-10,0,x+w,0,[[0,'#ff5a7e'],[.18,'#e0204e'],[.55,'#9a0836'],[.85,'#7a062c'],[1,'#b8143e']]);g.fill();
   g.lineCap='round';fa2_path(g,['M',x-w+2.5,-95,'Q',x-w-13.5,0,x-w+2.5,95]);g.strokeStyle='rgba(255,190,210,.75)';g.lineWidth=2.2;g.stroke();
   fa2_path(g,['M',x+w,-95,'Q',x+w-16,0,x+w,95]);g.strokeStyle='rgba(70,4,30,.55)';g.lineWidth=1.6;g.stroke()}
  g.restore()};
 // trailing dorsal and anal fins (behind body)
 const D=()=>fa2_path(g,['M',44,-40,'C',30,-62,-10,-72,-58+fin*3,-76,'Q',-82+fin*4,-78,-90+fin*5,-74,'Q',-66,-66,-50,-52,'Q',-40,-40,-36,-28,'Z']);
 const AN=()=>fa2_path(g,['M',44,40,'C',30,62,-10,72,-58-fin*3,76,'Q',-82-fin*4,78,-90-fin*5,74,'Q',-66,66,-50,52,'Q',-40,40,-36,28,'Z']);
 const finFill=(P,y0,y1)=>{g.save();g.globalAlpha=.9;P();fkFill(g,fkLin(g,40,y0,-80,y1,['#fff4f8','#ffd0e2','#ff9ac0']),2.4);stripes(P);g.restore();g.save();P();g.clip();g.translate(-1.4,-1.4);P();g.strokeStyle='rgba(255,255,255,.7)';g.lineWidth=2.2;g.stroke();g.restore();
  g.save();P();g.clip();g.globalAlpha=.25;g.strokeStyle=FKO;g.lineWidth=1.2;for(let i=0;i<6;i++){g.beginPath();g.moveTo(30-i*13,y0*.5);g.quadraticCurveTo(10-i*16,y0*.85,-30-i*10,y1);g.stroke()}g.restore()};
 const fil=(k,ph)=>{const a=Math.sin(t*2.2-ph)*4,b=Math.sin(t*2.2-ph-.9)*5;fa2_strand(g,[-74,-73*k,-84,-75*k,-94,(-75+a*.3)*k,-100+a*.4,(-72+a*.5)*k,-108+a*.6,(-69+a*.6)*k,-112+b*.3,(-60+b*.6)*k,-113+b*.3,(-47+b)*k],4.6,1,fkLin(g,-74,-73*k,-113,-47*k,['#ffd8e6','#ff8ab4','#e04a80']),2.2)};
 fil(1,0);fil(-1,1.3);
 finFill(D,-40,-76);finFill(AN,40,76);g.lineJoin='round';g.lineWidth=2.4;g.strokeStyle=FKO;D();g.stroke();AN();g.stroke();
 // tail: fan with streamer corners
 const T=()=>fa2_path(g,['M',14,-12,'Q',-10,-18,-38,-30,'L',-54,-40,'Q',-46,-16,-46,0,'Q',-46,16,-54,40,'L',-38,30,'Q',-10,18,14,12,'Z']);
 fa2_at(g,-44,0,sw,()=>{g.globalAlpha=.95;T();fkFill(g,fkLin(g,10,0,-50,0,['#ffe0ec','#ffb0cc','#ff7aa8']),2.4);g.globalAlpha=1;
  fa2_ribs(g,T,10,0,[-50,-36,-46,-20,-44,-6,-44,6,-46,20,-50,36],.22,'#8e1844');
  g.save();T();g.clip();g.strokeStyle='#8e1844';g.globalAlpha=.6;g.lineWidth=3.5;g.beginPath();g.moveTo(-36,-30);g.quadraticCurveTo(-30,0,-36,30);g.stroke();g.restore()});
 // body
 B();fkFill(g,fa2_grad(g,0,-50,0,50,[[0,'#f0dcf4'],[.35,'#fffafc'],[.7,'#fff0f6'],[1,'#f4d8ea']]),3);
 // pearly sheen (under the stripes so the wine band stays rich)
 g.save();B();g.clip();g.globalAlpha=.25;g.fillStyle=fa2_grad(g,-50,-50,90,50,[[0,'#a8e0ff'],[.4,'#ffffff'],[.7,'#ffc0e0'],[1,'#d8c0ff']]);g.fillRect(-60,-60,170,120);g.restore();
 stripes(B);
 fkScales(g,B,-50,96,-48,48,8,'#a04070',.13);
 fkShade(g,B,10,52,'#c86a9a',.3);fkShade(g,B,-10,-52,'#a080c0',.22);
 fa2_gloss(g,B,80,-18,40,-48,-24,-36,3.2,.75);
 fa2_gill(g,B,86,0,32,Math.PI*.74,Math.PI*1.26,'#6a1838',.55);
 // long pelvic streamers
 fa2_strand(g,[50,38,38,50,46,64,26+fin*5,78],6,1.4,'#ffd0e2',2);
 fa2_strand(g,[58,34,46,48,56,62,38+fin*4,76],6.6,1.6,'#ff8ab4',2);
 fa2_pec(g,62,6,-.3+fin*.12,22,'#fff4f8','#ff9ac0',.88);
 fkEye(g,72,-12,11,'#c0264a',.3);fa2_lid(g,72,-12,11,fa2_blink(t,4.4),'#fff0f6');
 g.beginPath();g.arc(72,-12,12.6,Math.PI*1.05,Math.PI*1.95);g.strokeStyle='#f4c860';g.lineWidth=1.6;g.stroke();
 // little pout
 fa2_smile(g,102.5,2.6,99,5.2,94.5,4,2);
 {const lip=(x,y,rx,ry,a)=>{g.beginPath();g.ellipse(x,y,rx,ry,a,0,TAU);g.fillStyle=fkLin(g,x-rx,y-ry,x+rx,y+ry,['#ff7a9e','#c8285a']);g.fill();g.lineWidth=1.8;g.strokeStyle=FKO;g.stroke()};
  lip(105.8,5,4,2.9,.25);lip(106.8,.4,4.6,3.1,-.2);g.beginPath();g.arc(106,-.8,1.3,0,TAU);g.fillStyle='rgba(255,255,255,.8)';g.fill()}
 fkSpark(g,24,-30,3+fa2_tw(t,1,2)*2.5,'#fff',.4+.5*fa2_tw(t,1,2));
 fa2_catch(g,o,'#ffd0e4',1.3);g.restore()};
/* ---------------- 16. Cinder Betta: charcoal betta with huge veils burning to ember-gold tips ---------------- */
FISHART.cinder=(g,t,o)=>{const sw=fkSway(o,2.4,.07),gl=o.glow||0;g.save();g.rotate(-sw*.18);
 const B=()=>fkPath(g,[100,2,94,-9,76,-16,48,-19,18,-17,-2,-11,-8,0,-2,11,18,17,48,19,76,15,94,8]);
 const fire=(x,y,r)=>fa2_rgrad(g,x,y,4,r,[[0,'#24101a'],[.28,'#7a1222'],[.55,'#e0301c'],[.8,'#ff8a1e'],[1,'#ffd860']]);
 const wav=(i,n)=>Math.sin(t*2.6+i*.9)*4;
 // veil fins built from scalloped edge points
 const veil=(cx,cy,a0,a1,R,n,base)=>{const p=base.slice();for(let i=0;i<=n;i++){const a=a0+(a1-a0)*i/n,rr=R+wav(i,n)+(i%2?-5:3);p.push(cx+Math.cos(a)*rr,cy+Math.sin(a)*rr)}return p};
 const TP=veil(0,0,Math.PI*.72,Math.PI*1.28,96,12,[]).concat([10,-14,14,0,10,14]);
 const embers=(P,x,y,r)=>{g.save();P();g.clip();g.globalCompositeOperation='lighter';g.strokeStyle='#ffb030';g.globalAlpha=.35+.15*Math.sin(t*3);g.lineWidth=7;P();g.stroke();g.restore()};
 // tail veil
 fa2_at(g,-2,0,sw,()=>{const P=()=>fkPath(g,TP);P();fkFill(g,fire(6,0,96),2.6);
  fa2_ribs(g,P,6,0,[-90,-60,-96,-36,-98,-12,-98,12,-96,36,-90,60,-80,-72,-80,72],.28,'#1a0810',1.4);
  embers(P)});
 // dorsal veil
 // dorsal + anal veils: scalloped flame edges that ripple with time
 const edge=(pts,sgn)=>{const o=[];for(let i=0;i<pts.length;i+=2){const k=i/2,w=Math.sin(t*2.6+k*.9)*3*sgn;o.push(pts[i],pts[i+1]+w+(k%2?3*sgn:-1*sgn))}return o};
 const DP=[70,-15,60,-28].concat(edge([46,-42,30,-54,12,-63,-6,-70,-24,-74,-40,-68],-1),[-36,-54,-38,-40,-14,-30,4,-16]);
 const AP=[66,16,56,32].concat(edge([42,46,26,58,8,67,-12,73,-32,76,-48,68],1),[-40,54,-40,40,-14,30,4,16]);
 const DF=()=>fkPath(g,DP),AF=()=>fkPath(g,AP);
 DF();fkFill(g,fire(40,-10,90),2.6);fa2_ribs(g,DF,40,-14,[20,-62,0,-68,-20,-72,-38,-62,-30,-44],.28,'#1a0810',1.4);embers(DF);
 AF();fkFill(g,fire(40,10,92),2.6);fa2_ribs(g,AF,40,14,[20,62,0,70,-24,74,-42,62,-30,44],.28,'#1a0810',1.4);embers(AF);
 // body: charcoal with ember iridescence
 B();fkFill(g,fa2_grad(g,0,-19,0,19,[[0,'#120c18'],[.45,'#2a2030'],[.8,'#3a2230'],[1,'#5a2a2e']]),3);
 g.save();B();g.clip();g.globalAlpha=.22;g.fillStyle=fa2_grad(g,0,0,100,0,[[0,'#ff3a1a'],[.5,'#8a2aa8'],[1,'#ff4a2a']]);g.fillRect(-10,-20,112,40);g.restore();
 fkScales(g,B,-8,92,-18,18,7,'#ff6a3a',.3);
 fkShade(g,B,-4,-20,'#0a0610',.5);
 fa2_gloss(g,B,88,-10,50,-19,4,-12,2.6,.55);
 fa2_gill(g,B,88,1,18,Math.PI*.7,Math.PI*1.3,'#ff8a3a',.55);
 // hanging ventral fins
 const vf=Math.sin(t*2.2)*3;fa2_strand(g,[64,15,66,28,52,38,46+vf,58],6,1.6,'#ff5a24',2.2);fa2_strand(g,[58,16,58,28,46,36,38+vf,50],4.6,1.4,'#c02818',2);
 fa2_pec(g,70,4,-.3+Math.sin(t*6)*.15,15,'#ff9a3a','#c02a1a',.85,'rgba(255,220,140,.6)');
 fkEye(g,80,-5,9,'#ff6a1a',.3);fa2_lid(g,80,-5,9,fa2_blink(t,2.9),'#3a2a3e');
 fa2_smile(g,99,5,95,8,90,6,2.2);
 // glowing tips and rising sparks
 fkGlow(g,-86,0,34,'#ffb040',.2+.1*Math.sin(t*2.4)+gl*.35);
 fkGlow(g,-28,-66,26,'#ffa030',.16+.08*Math.sin(t*2+1)+gl*.3);
 fkGlow(g,-34,68,26,'#ff8a20',.16+.08*Math.sin(t*2.2+2)+gl*.3);
 for(let i=0;i<8;i++){const p=((t*.3+i/8)%1),x=-90+i*20+Math.sin(t*2+i*1.7)*6,y=40-p*120;const a=(1-p)*(.6+.4*Math.sin(t*9+i*3));
  g.globalAlpha=a*.45;g.fillStyle='#ff8a20';g.beginPath();g.arc(x,y,5.5*(1-p)+2,0,TAU);g.fill();g.globalAlpha=a;g.fillStyle='#ffe8a0';g.beginPath();g.arc(x,y,1.8*(1-p)+.8,0,TAU);g.fill();g.globalAlpha=1;fkSpark(g,x,y,4*(1-p)+1.5,'#fff0c0',a)}
 g.restore()};
/* ---------------- 17. Glassfin: crystal-clear fish with a visible skeleton and a beating heart ---------------- */
FISHART.glass=(g,t,o)=>{const sw=fkSway(o,3.6,.14),fin=Math.sin(t*4.2)*.1,gl=o.glow||0;g.save();g.rotate(-sw*.2);
 const beat=(()=>{const p=(t*1.25)%1;return Math.exp(-(((p-.1)/.05)**2))+.6*Math.exp(-(((p-.28)/.05)**2))})();
 const BP=[102,4,94,-12,68,-30,30,-38,-10,-32,-40,-18,-60,-6,-60,6,-40,16,-10,28,30,34,68,26,94,14],B=()=>fkPath(g,BP);
 const glassFill=(P,a)=>{g.save();g.globalAlpha=a;P();g.fillStyle=fkLin(g,-60,-40,60,40,['#d8fdff','#8ae8f8','#b8d0ff']);g.fill();g.restore();P();g.lineWidth=2.4;g.strokeStyle=FKO;g.stroke();
  g.save();P();g.clip();g.translate(-1.4,-1.6);P();g.strokeStyle='rgba(220,255,255,.9)';g.lineWidth=2.2;g.stroke();g.translate(3,3.4);P();g.strokeStyle='rgba(255,160,220,.45)';g.lineWidth=1.6;g.stroke();g.restore()};
 const T=()=>fa2_path(g,['M',14,-8,'Q',-4,-8,-16,-18,'Q',-30,-30,-46,-38,'Q',-40,-18,-26,0,'Q',-40,18,-46,38,'Q',-30,30,-16,18,'Q',-4,8,14,8,'Z']);
 g.save();fa2_outside(g,BP);
 fa2_at(g,-56,0,sw,()=>{glassFill(T,.36);fa2_ribs(g,T,8,0,[-44,-34,-38,-22,-30,-8,-30,8,-38,22,-44,34],.55,'#e8ffff',1.1)});
 // sail dorsal + second dorsal + anal
 const D1=()=>fkPath(g,[34,-34,24,-60,12,-70,0,-62,-6,-32]);
 const D2=()=>fkPath(g,[-14,-30,-22,-46,-36,-44,-42,-20]);
 const AN=()=>fkPath(g,[20,30,8,46,-16,48,-38,36,-42,14]);
 fa2_at(g,0,0,fin*.15,()=>{glassFill(D1,.3);fa2_ribs(g,D1,14,-30,[22,-60,12,-68,2,-62,-4,-40],.55,'#e8ffff',1.1)});
 glassFill(D2,.3);fa2_ribs(g,D2,-26,-26,[-22,-44,-32,-44,-38,-30],.55,'#e8ffff',1.1);
 glassFill(AN,.3);fa2_ribs(g,AN,0,28,[8,44,-6,48,-20,46,-32,38],.55,'#e8ffff',1.1);
 g.restore();
 // body glass
 B();g.save();g.globalAlpha=.5;g.fillStyle=fa2_grad(g,0,-38,0,34,[[0,'#4ad0f0'],[.45,'#c8fcff'],[1,'#8ad8ff']]);g.fill();g.restore();
 // internal skeleton
 g.save();B();g.clip();g.lineCap='round';
 const sp=x=>-4+Math.sin((x+60)/160*Math.PI)*-4;
 g.strokeStyle='#effdff';g.globalAlpha=.85;g.lineWidth=2.4;g.beginPath();g.moveTo(66,sp(66)-2);for(let x=60;x>=-62;x-=4)g.lineTo(x,sp(x));g.stroke();
 g.lineWidth=1.3;g.globalAlpha=.6;
 for(let x=50;x>-56;x-=8){const y=sp(x),k=Math.max(.35,1-Math.abs(x-10)/80);g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x-6,y-14*k,x-12,y-26*k);g.stroke();
  g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x-4,y+(x>0?18:12)*k,x-12,y+(x>0?28:18)*k);g.stroke()}
 // skull hint
 g.globalAlpha=.5;g.lineWidth=1.4;g.beginPath();g.arc(78,-6,17,Math.PI*.9,Math.PI*1.75);g.stroke();g.beginPath();g.arc(92,4,10,Math.PI*.2,Math.PI*.9);g.stroke();
 // refraction glints
 g.globalAlpha=.4;g.strokeStyle='#ffffff';g.lineWidth=5;g.beginPath();g.moveTo(40,-34);g.lineTo(20,30);g.stroke();g.lineWidth=2.4;g.beginPath();g.moveTo(-12,-30);g.lineTo(-26,20);g.stroke();
 g.restore();g.globalAlpha=1;
 // rim
 B();g.lineWidth=3;g.strokeStyle=FKO;g.stroke();
 g.save();B();g.clip();g.translate(-1.8,-2);B();g.strokeStyle='rgba(225,255,255,.95)';g.lineWidth=2.6;g.stroke();g.translate(3.4,3.8);B();g.strokeStyle='rgba(255,150,220,.5)';g.lineWidth=2;g.stroke();g.restore();
 fa2_gill(g,B,92,2,24,Math.PI*.72,Math.PI*1.28,'#e8ffff',.8);
 // glowing heart
 const hs=1.35*(1+.22*beat),hx=32,hy=12;fkGlow(g,hx,hy,18+10*beat+gl*12,'#ff5aa0',.35+.3*beat+gl*.3);
 fa2_at(g,hx,hy,0,()=>{g.scale(hs,hs);g.beginPath();g.moveTo(0,4.5);g.bezierCurveTo(-7,0,-6,-6,-2.6,-6);g.quadraticCurveTo(-.6,-6,0,-3.6);g.quadraticCurveTo(.6,-6,2.6,-6);g.bezierCurveTo(6,-6,7,0,0,4.5);g.closePath();
  g.fillStyle=fkRad(g,0,-1,7,['#ffd0e8','#ff5aa0','#d02a6a']);g.fill();g.lineWidth=1.4;g.strokeStyle='#6a0a3a';g.stroke();g.beginPath();g.arc(-2.6,-3.2,1.2,0,TAU);g.fillStyle='#fff';g.fill()});
 fa2_at(g,64,8,-.35+fin,()=>{const P=()=>fa2_path(g,['M',3,-3,'C',-6,-10,-18,-10,-22,-4,'Q',-22,4,-14,8,'C',-6,8,-2,4,3,3,'Z']);glassFill(P,.35);fa2_ribs(g,P,2,0,[-22,-4,-20,2,-14,7],.55,'#e8ffff',1)});
 fkEye(g,80,-9,11,'#2ab8c8',.3);fa2_lid(g,80,-9,11,fa2_blink(t,1.2),'#a8e8f4');
 fa2_smile(g,100,6,96,10,91,8,2.2);
 fkSpark(g,34,-26,3.4+fa2_tw(t,0,2.2)*2.2,'#fff',.5+.5*fa2_tw(t,0,2.2));
 fkSpark(g,-30,-10,2.4+fa2_tw(t,3,2.6)*1.6,'#c8fbff',.4+.5*fa2_tw(t,3,2.6));
 fa2_catch(g,o,'#d0fbff',1.3);g.restore()};
