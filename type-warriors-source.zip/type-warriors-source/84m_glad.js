/* ---------- Warden's Arena: the gladiator roster and its three champions ----------
   One painted fighter rig drawn facing left, feet at y=0. Every fighter is a config: helmet, armour, shield, weapon and fighting style.
   lg drives the attack: 0 ready, .55 wound up, 1 full strike, below 0 staggered and open. */
const GOL='#150c1c';
const GK=(v,K)=>{if(v<=K[0][0])return K[0][1];for(let i=1;i<K.length;i++){if(v<=K[i][0]){const a=K[i-1],b=K[i],u=(v-a[0])/(b[0]-a[0]);return a[1]+(b[1]-a[1])*u}}return K[K.length-1][1]};
const GD2=Math.PI/180;
function gMet(g,x0,y0,x1,y1,c){const q=g.createLinearGradient(x0,y0,x1,y1);q.addColorStop(0,shade(c,.55));q.addColorStop(.42,c);q.addColorStop(1,shade(c,-.5));return q}
function gPath(g,p){g.beginPath();g.moveTo(p[0],p[1]);for(let i=2;i<p.length;i+=2)g.lineTo(p[i],p[i+1]);g.closePath()}
function gFill(g,f,lw){g.fillStyle=f;g.fill();if(lw!==0){g.strokeStyle=GOL;g.lineWidth=lw||1.6;g.lineJoin='round';g.stroke()}}
function gLimbs(g,segs,col,hl){g.lineCap='round';g.lineJoin='round';
 for(const s of segs){g.strokeStyle=GOL;g.lineWidth=s[4]+3.2;g.beginPath();g.moveTo(s[0],s[1]);g.lineTo(s[2],s[3]);g.stroke()}
 for(const s of segs){g.strokeStyle=col;g.lineWidth=s[4];g.beginPath();g.moveTo(s[0],s[1]);g.lineTo(s[2],s[3]);g.stroke()}
 if(hl)for(const s of segs){g.strokeStyle=hl;g.lineWidth=s[4]*.3;g.beginPath();g.moveTo(s[0]-s[4]*.18,s[1]-s[4]*.12);g.lineTo(s[2]-s[4]*.18,s[3]-s[4]*.12);g.stroke()}}
function gIK(x0,y0,x1,y1,L1,L2,dir){const dx=x1-x0,dy=y1-y0;let d=Math.hypot(dx,dy);d=Math.max(.01,Math.min(d,L1+L2-.01));const a=Math.atan2(dy,dx),b=Math.acos(Math.max(-1,Math.min(1,(L1*L1+d*d-L2*L2)/(2*L1*d)))),k=a+dir*b;return[x0+Math.cos(k)*L1,y0+Math.sin(k)*L1]}
function gDisc(g,x,y,r,f,lw){g.beginPath();g.arc(x,y,r,0,TAU);gFill(g,f,lw)}
function gRiv(g,x,y,r,c){g.beginPath();g.arc(x,y,r,0,TAU);g.fillStyle=c||'#fff3c0';g.fill()}
/* ---------- weapons: grip at the origin, pointing along +x ---------- */
function gWeap(g,k,c,t){const wc=c.wc||'#c8ccd8';g.save();
 if(k==='gladius'||k==='spatha'){const L=k==='spatha'?44:30;gDisc(g,-8,0,2.8,'#c9a545',1.2);g.beginPath();g.roundRect(-6.5,-2,7,4,1.5);gFill(g,'#5a3420',1.2);g.beginPath();g.roundRect(-.5,-5.5,3.4,11,1.4);gFill(g,c.gc||'#d8a53a',1.2);
  gPath(g,[3,-3.2,3+L*.82,-3,3+L,0,3+L*.82,3,3,3.2]);gFill(g,gMet(g,0,-4,0,4,wc),1.3);g.strokeStyle='#0004';g.lineWidth=1.1;g.beginPath();g.moveTo(5,0);g.lineTo(3+L*.75,0);g.stroke();g.strokeStyle='#ffffffa0';g.lineWidth=.9;g.beginPath();g.moveTo(5,-1.9);g.lineTo(3+L*.8,-1.8);g.stroke();
  if(c.wglow){g.globalCompositeOperation='lighter';glow(g,3+L*.6,0,L*.7,c.wglow+'66');g.globalCompositeOperation='source-over';g.strokeStyle=c.wglow;g.lineWidth=1.4;g.beginPath();g.moveTo(5,0);g.lineTo(3+L*.9,0);g.stroke()}}
 else if(k==='sica'){gDisc(g,-7,0,2.4,'#c9a545',1.1);g.beginPath();g.roundRect(-6,-1.8,6.5,3.6,1.4);gFill(g,'#3a2418',1.1);g.beginPath();g.roundRect(0,-4.5,2.8,9,1.2);gFill(g,c.gc||'#c9a545',1.1);
  g.beginPath();g.moveTo(2.8,-2.6);g.quadraticCurveTo(18,-4,30,4);g.quadraticCurveTo(33,8,31,11);g.quadraticCurveTo(26,4,16,2.6);g.quadraticCurveTo(8,2.4,2.8,2.6);g.closePath();gFill(g,gMet(g,0,-4,0,10,wc),1.3);g.strokeStyle='#ffffff99';g.lineWidth=.9;g.beginPath();g.moveTo(5,-1.4);g.quadraticCurveTo(18,-2.6,28,4);g.stroke()}
 else if(k==='trident'){g.beginPath();g.roundRect(-34,-1.6,88,3.2,1.6);gFill(g,gMet(g,0,-2,0,2,'#8a5a32'),1.2);for(const x of[-8,6])g.fillStyle='#c9a545',g.fillRect(x,-2.2,3,4.4);
  gPath(g,[52,-7,55,-7,55,7,52,7]);gFill(g,gMet(g,0,-7,0,7,wc),1.1);
  for(const dy of[-6,6]){g.beginPath();g.moveTo(54,dy-1.3);g.quadraticCurveTo(62,dy*1.15,68,dy*1.05);g.lineTo(72,dy*.9);g.lineTo(67,dy*.75);g.quadraticCurveTo(61,dy*.8,54,dy+1.3);g.closePath();gFill(g,gMet(g,0,dy-2,0,dy+2,wc),1.1)}
  gPath(g,[54,-1.5,72,-1.6,79,0,72,1.6,54,1.5]);gFill(g,gMet(g,0,-2,0,2,wc),1.1);gPath(g,[70,-1.4,67,-4.2,68,-1]);gFill(g,wc,.8)}
 else if(k==='spear'){g.beginPath();g.roundRect(-40,-1.9,100,3.8,1.8);gFill(g,gMet(g,0,-2,0,2,'#c99a2a'),1.2);for(const x of[-30,-6,20,46])g.fillStyle='#fff0a0',g.fillRect(x,-2.3,2.4,4.6);
  if(c.flame){const f=Math.sin(t*13)*1.6;g.save();g.globalCompositeOperation='lighter';glow(g,74,0,34,'#ff8a2a77');for(let i=0;i<6;i++){const u=i/5,ph=t*11+i;g.fillStyle=`rgba(255,${150+u*90|0},60,${.55-u*.06})`;g.beginPath();g.ellipse(64+u*22,Math.sin(ph)*2.4*(1-u)-u*2,9-u*5,5.2-u*2.4+f*.3,0,0,TAU);g.fill()}g.restore()}
  g.beginPath();g.moveTo(58,-1.8);g.quadraticCurveTo(68,-7.5,86,0);g.quadraticCurveTo(68,7.5,58,1.8);g.closePath();gFill(g,gMet(g,0,-7,0,7,c.wc||'#ffe27a'),1.3);g.strokeStyle='#fff8d0';g.lineWidth=1;g.beginPath();g.moveTo(61,0);g.lineTo(82,0);g.stroke()}
 else if(k==='labrys'){g.beginPath();g.roundRect(-26,-2.4,86,4.8,2.2);gFill(g,gMet(g,0,-2,0,2,'#5a3a22'),1.3);for(const x of[-18,2,24])g.fillStyle='#d8a53a',g.fillRect(x,-3,3,6);
  for(const s of[-1,1]){g.beginPath();g.moveTo(40,-s*3);g.quadraticCurveTo(26,-s*14,24,-s*30);g.quadraticCurveTo(42,-s*22,64,-s*30);g.quadraticCurveTo(60,-s*14,52,-s*3);g.closePath();gFill(g,gMet(g,24,-s*30,52,0,wc),1.6);
   g.strokeStyle=c.gc||'#ffd86a';g.lineWidth=1.8;g.beginPath();g.moveTo(25,-s*28);g.quadraticCurveTo(43,-s*21,63,-s*28);g.stroke();g.strokeStyle='#0004';g.lineWidth=1.2;g.beginPath();g.moveTo(44,-s*6);g.lineTo(44,-s*20);g.stroke()}
  gDisc(g,46,0,4.5,c.gc||'#d8a53a',1.3);gRiv(g,46,0,1.6,'#fff3c0')}
 g.restore()}
/* ---------- shields, centred on the hand ---------- */
function gShield(g,k,c,t){const sc=c.shc||'#a8323a',em=c.she||'#ffd86a',rim=c.shr||'#d8a53a';g.save();
 if(k==='parma'){g.scale(.82,1);gDisc(g,0,0,16,gMet(g,-12,-14,12,14,rim),1.8);gDisc(g,0,0,12.8,gMet(g,-10,-10,10,12,sc),1.2);g.strokeStyle=em;g.lineWidth=1.6;for(let i=0;i<8;i++){const a=i*TAU/8;g.beginPath();g.moveTo(Math.cos(a)*6,Math.sin(a)*6);g.lineTo(Math.cos(a)*11,Math.sin(a)*11);g.stroke()}gDisc(g,0,0,5,gMet(g,-4,-4,4,4,rim),1.2);gRiv(g,-1.4,-1.6,1.4)}
 else if(k==='scutum'||k==='tower'){const w=k==='tower'?34:30,h=k==='tower'?74:64;g.beginPath();g.roundRect(-w/2,-h/2,w,h,7);gFill(g,gMet(g,-w/2,0,w/2,0,rim),1.8);g.beginPath();g.roundRect(-w/2+3,-h/2+3,w-6,h-6,5);
  const q=g.createLinearGradient(-w/2,0,w/2,0);q.addColorStop(0,shade(sc,.28));q.addColorStop(.35,sc);q.addColorStop(1,shade(sc,-.5));gFill(g,q,1);
  g.save();g.clip();g.strokeStyle=em;g.lineWidth=2;g.globalAlpha=k==='tower'?.75:.95;
  /* wings and thunderbolts, the legion's mark */
  for(const s of[-1,1]){g.beginPath();g.moveTo(0,-4);g.quadraticCurveTo(s*9,-16,s*12,-24);g.moveTo(0,-2);g.quadraticCurveTo(s*10,-9,s*13,-14);g.moveTo(0,0);g.quadraticCurveTo(s*9,-2,s*12,-5);g.stroke();g.beginPath();g.moveTo(s*2,6);g.lineTo(s*7,14);g.lineTo(s*4,16);g.lineTo(s*10,26);g.stroke()}
  g.fillStyle='#ffffff26';g.fillRect(-w/2+4,-h/2+4,6,h-8);g.restore();
  gDisc(g,0,0,7,gMet(g,-6,-6,6,6,rim),1.4);gRiv(g,-2,-2,1.8);for(const [x,y] of[[-w/2+5,-h/2+5],[w/2-5,-h/2+5],[-w/2+5,h/2-5],[w/2-5,h/2-5]])gRiv(g,x,y,1.4,em)}
 else if(k==='square'){g.beginPath();g.roundRect(-12,-15,24,30,4);gFill(g,gMet(g,-12,-15,12,15,rim),1.7);g.beginPath();g.roundRect(-9.5,-12.5,19,25,3);gFill(g,gMet(g,-9,0,9,0,sc),1);g.strokeStyle=em;g.lineWidth=1.7;g.beginPath();for(let a=0;a<9;a+=.25){const r=1+a*1.1;g.lineTo(Math.cos(a)*r,Math.sin(a)*r)}g.stroke()}
 else if(k==='clipeus'){g.scale(.8,.8);const r=27;gDisc(g,0,0,r,gMet(g,-r,-r,r,r,rim),2);gDisc(g,0,0,r-4,gMet(g,-r,-r,r,r,sc),1.2);
  g.fillStyle=em;for(let i=0;i<16;i++){const a=i*TAU/16+t*.4;g.beginPath();g.moveTo(Math.cos(a-.12)*9,Math.sin(a-.12)*9);g.lineTo(Math.cos(a)*(i%2?18:21),Math.sin(a)*(i%2?18:21));g.lineTo(Math.cos(a+.12)*9,Math.sin(a+.12)*9);g.fill()}
  gDisc(g,0,0,9,gMet(g,-8,-8,8,8,'#fff0a0'),1.2);g.fillStyle='#8a5a10';g.fillRect(-4.5,-2.5,3,1.6);g.fillRect(1.5,-2.5,3,1.6);g.fillRect(-2.5,3,5,1.4)}
 else if(k==='net'){/* a gathered net with lead weights swinging from the fist */const sw=Math.sin(t*2.6)*3;g.strokeStyle='#e8dcc0';g.lineWidth=1.1;g.globalAlpha=.9;
  for(let i=-3;i<=3;i++){g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(i*4+sw*.5,16,i*5.5+sw,34);g.stroke()}for(let j=1;j<=4;j++){g.beginPath();for(let i=-3;i<=3;i++){const u=j/4,x=i*5.5*u+sw*u,y=34*u+Math.abs(i)*.8;i===-3?g.moveTo(x,y):g.lineTo(x,y)}g.stroke()}
  g.globalAlpha=1;for(let i=-3;i<=3;i+=2)gDisc(g,i*5.5+sw,35,2.2,'#7a7a88',1)}
 g.restore()}
/* ---------- heads and helmets, centred on the skull ---------- */
function gFace(g,x,y,c,r){/* the visible half of a face: brow, eye, nose and jaw, looking left */
 gDisc(g,x,y,r,gMet(g,x-r,y-r,x+r,y+r,c.sk),1.5);
 g.beginPath();g.moveTo(x-r*.86,y-r*.1);g.lineTo(x-r*1.26,y+r*.32);g.lineTo(x-r*.84,y+r*.44);g.closePath();gFill(g,shade(c.sk,-.12),1.2);
 g.fillStyle='#fff';g.beginPath();g.ellipse(x-r*.45,y-r*.1,r*.24,r*.17,0,0,TAU);g.fill();g.fillStyle=c.eye||'#2a1a10';g.beginPath();g.arc(x-r*.53,y-r*.09,r*.12,0,TAU);g.fill();
 g.strokeStyle=GOL;g.lineWidth=1.7;g.beginPath();g.moveTo(x-r*.85,y-r*.45);g.lineTo(x-r*.15,y-r*.25);g.stroke();g.lineWidth=1.3;g.beginPath();g.moveTo(x-r*.78,y+r*.62);g.lineTo(x-r*.35,y+r*.6);g.stroke()}
function gHead(g,k,x,y,c,t,lg){const hc=c.hc||'#c88a3a',cc=c.cc||'#c8323a';
 if(k==='mont'){/* Montefortino cap: bronze dome, knob plume and cheek guards */
  gFace(g,x,y+1,c,10.5);
  g.save();g.translate(x+12,y-12);g.rotate(.2+Math.sin(t*3)*.06);g.beginPath();g.moveTo(-10,-2);g.quadraticCurveTo(4,-14,24,-4+Math.sin(t*4)*2);g.quadraticCurveTo(10,-2,-8,4);g.closePath();gFill(g,gMet(g,0,-12,0,4,cc),1.3);g.strokeStyle=shade(cc,-.4);g.lineWidth=.9;for(let i=0;i<4;i++){g.beginPath();g.moveTo(-6,0);g.quadraticCurveTo(6,-8+i*2,18,-3+i*1.4);g.stroke()}g.restore();
  g.beginPath();g.moveTo(x-13,y-1);g.quadraticCurveTo(x-12,y-16,x+1,y-15);g.quadraticCurveTo(x+14,y-14,x+15,y-1);g.lineTo(x+19,y+3);g.lineTo(x+11,y+2);g.closePath();gFill(g,gMet(g,x-12,y-16,x+14,y+2,hc),1.6);
  g.strokeStyle=shade(hc,.4);g.lineWidth=1.3;g.beginPath();g.moveTo(x-12,y-2);g.lineTo(x+15,y-1);g.stroke();
  gDisc(g,x+1,y-16,3,gMet(g,x-2,y-19,x+4,y-13,hc),1.2);
  gPath(g,[x+1,y-1,x-1,y+9,x+4,y+12,x+9,y+8,x+8,y-1]);gFill(g,gMet(g,x,y,x+9,y+11,hc),1.3);gRiv(g,x+4,y+3,1.2)}
 else if(k==='bare'){/* retiarius: no helmet, a red headband and a hard beard */
  gFace(g,x,y,c,10.5);
  g.beginPath();g.moveTo(x-10,y-4);g.quadraticCurveTo(x-9,y-15,x+1,y-14);g.quadraticCurveTo(x+13,y-13,x+11,y+2);g.quadraticCurveTo(x+6,y-3,x+3,y-5);g.quadraticCurveTo(x-4,y-9,x-10,y-4);g.closePath();gFill(g,c.hair||'#2a1a12',1.3);
  g.beginPath();g.moveTo(x-9,y+3);g.quadraticCurveTo(x-9,y+13,x-1,y+13);g.quadraticCurveTo(x+6,y+12,x+7,y+4);g.quadraticCurveTo(x+2,y+7,x-3,y+5);g.closePath();gFill(g,c.hair||'#2a1a12',1.2);
  g.fillStyle=cc;g.fillRect(x-10.5,y-7.5,21,3.4);g.save();g.translate(x+10,y-6);g.rotate(.3+Math.sin(t*5)*.18);gPath(g,[0,-1.6,12,0,10,3,0,1.8]);gFill(g,cc,1);g.rotate(.3);gPath(g,[0,0,10,3,8,5.6,0,2]);gFill(g,shade(cc,-.2),1);g.restore()}
 else if(k==='attic'){/* sagittarius: an open bronze helm with a sweeping horsehair crest */
  gFace(g,x,y+1,c,10.3);
  g.beginPath();g.moveTo(x-12,y-3);g.quadraticCurveTo(x-11,y-17,x+2,y-16);g.quadraticCurveTo(x+14,y-15,x+14,y+1);g.lineTo(x+14,y+10);g.lineTo(x+8,y+11);g.lineTo(x+5,y-2);g.lineTo(x-4,y-5);g.closePath();gFill(g,gMet(g,x-10,y-16,x+14,y+10,hc),1.5);
  g.strokeStyle=shade(hc,.45);g.lineWidth=1.4;g.beginPath();g.moveTo(x-12,y-4);g.quadraticCurveTo(x-4,y-7,x+5,y-3);g.stroke();
  g.fillStyle=gMet(g,0,y-22,0,y-14,hc);g.fillRect(x-4,y-20,10,5);
  g.save();const sw=Math.sin(t*3)*1.5;g.beginPath();g.moveTo(x-9,y-19);g.bezierCurveTo(x-8,y-36,x+12,y-38,x+24+sw,y-26);g.quadraticCurveTo(x+30+sw,y-14,x+24+sw*1.5,y-4);g.quadraticCurveTo(x+16,y-20,x+6,y-19);g.closePath();gFill(g,gMet(g,x,y-36,x,y-6,cc),1.4);
  g.strokeStyle=shade(cc,-.38);g.lineWidth=.9;for(let i=0;i<6;i++){g.beginPath();g.moveTo(x-6+i*2.4,y-21);g.quadraticCurveTo(x+6+i*2,y-34+i*1.2,x+20+sw+i*.6,y-24+i*2.4);g.stroke()}g.restore()}
 else if(k==='murm'||k==='thraex'){/* full helms: brim, grille visor and a crest */
  const br2=k==='murm';
  if(k==='thraex'){/* tall side feathers */for(const [dx,ph] of[[5,0],[10,1.4]]){g.save();g.translate(x+dx,y-10);g.rotate(-.12+Math.sin(t*3+ph)*.08);g.beginPath();g.moveTo(-1.6,0);g.quadraticCurveTo(-4,-20,1,-38);g.quadraticCurveTo(5,-20,1.6,0);g.closePath();gFill(g,c.fc||'#e8e0f8',1.1);g.strokeStyle='#0003';g.lineWidth=.8;g.beginPath();g.moveTo(0,-2);g.lineTo(.6,-34);g.stroke();g.restore()}}
  g.beginPath();g.arc(x+1,y-2,13,Math.PI*.92,Math.PI*2.08);g.lineTo(x+14,y+8);g.quadraticCurveTo(x+4,y+13,x-11,y+9);g.closePath();gFill(g,gMet(g,x-12,y-15,x+14,y+10,hc),1.6);
  /* visor grille */
  g.beginPath();g.ellipse(x-6,y+2,7.5,9,0,0,TAU);gFill(g,gMet(g,x-12,y-7,x,y+11,shade(hc,.15)),1.3);g.fillStyle='#120a14';for(let i=0;i<4;i++)for(let j=0;j<4;j++){const px=x-10+i*2.8,py=y-4+j*3;if(Math.hypot(px-(x-6),py-(y+2))<6.6){g.beginPath();g.arc(px,py,.95,0,TAU);g.fill()}}
  if(c.eye){g.globalCompositeOperation='lighter';glow(g,x-8,y-1,7,c.eye+'aa');g.globalCompositeOperation='source-over'}
  /* brim */
  g.beginPath();g.ellipse(x+1,y+7.5,br2?19:16,br2?4.2:3.6,-.06,0,TAU);gFill(g,gMet(g,x-16,y+3,x+16,y+11,hc),1.4);
  if(br2){/* the murmillo's great fish-fin crest */g.beginPath();g.moveTo(x-8,y-11);g.bezierCurveTo(x-12,y-30,x+4,y-44,x+18,y-38);g.quadraticCurveTo(x+22,y-26,x+13,y-11);g.closePath();gFill(g,gMet(g,x-10,y-44,x+18,y-11,cc),1.6);
   g.strokeStyle=shade(cc,-.45);g.lineWidth=1.1;for(let i=1;i<6;i++){g.beginPath();g.moveTo(x-6+i*3.4,y-12);g.quadraticCurveTo(x-4+i*3.6,y-28+i,x+i*3.6,y-38+i*1.6);g.stroke()}g.strokeStyle=shade(cc,.5);g.lineWidth=1.3;g.beginPath();g.moveTo(x-7,y-14);g.bezierCurveTo(x-10,y-30,x+4,y-42,x+17,y-37);g.stroke()}
  else{/* the thraex's griffin crest, beak forward */g.beginPath();g.moveTo(x+4,y-13);g.quadraticCurveTo(x+10,y-24,x+3,y-32);g.quadraticCurveTo(x-4,y-38,x-12,y-33);g.lineTo(x-19,y-30);g.lineTo(x-12,y-28);g.quadraticCurveTo(x-6,y-28,x-4,y-22);g.quadraticCurveTo(x-6,y-16,x-3,y-12);g.closePath();gFill(g,gMet(g,x-14,y-36,x+8,y-12,cc),1.5);
   g.fillStyle='#120a14';g.beginPath();g.arc(x-6,y-31,1.4,0,TAU);g.fill();g.strokeStyle=shade(cc,.5);g.lineWidth=1.1;g.beginPath();g.moveTo(x+5,y-20);g.quadraticCurveTo(x+6,y-30,x-2,y-34);g.stroke()}}
 else if(k==='mask'){/* dimachaerus: a closed steel war-mask with swept horns */
  for(const s of[1,0]){g.save();g.translate(x+(s?7:2),y-9);g.beginPath();g.moveTo(-2,0);g.bezierCurveTo(6,-8,16,-10,24-s*4,-24);g.quadraticCurveTo(14,-14,4,3);g.closePath();gFill(g,gMet(g,0,-24,20,0,s?shade(c.hc2||'#e8dcc0',-.3):(c.hc2||'#e8dcc0')),1.3);g.restore()}
  g.beginPath();g.moveTo(x-12,y+1);g.quadraticCurveTo(x-13,y-15,x+1,y-15);g.quadraticCurveTo(x+14,y-14,x+13,y+3);g.quadraticCurveTo(x+11,y+12,x+2,y+13);g.lineTo(x-7,y+12);g.quadraticCurveTo(x-12,y+9,x-12,y+1);g.closePath();gFill(g,gMet(g,x-12,y-15,x+13,y+13,hc),1.6);
  g.strokeStyle=shade(hc,.5);g.lineWidth=1.2;g.beginPath();g.moveTo(x-1,y-15);g.quadraticCurveTo(x-2,y-2,x-12,y+2);g.stroke();
  gPath(g,[x-12,y-4,x-3,y-5,x-4,y-1.5,x-11,y-.5]);gFill(g,'#0a0610',1);g.globalCompositeOperation='lighter';glow(g,x-8,y-3,8,(c.eye||'#ff5a3a')+'cc');g.globalCompositeOperation='source-over';g.fillStyle=c.eye||'#ff5a3a';g.fillRect(x-10,y-3.8,4.5,1.6);
  g.fillStyle='#0a0610';g.fillRect(x-10,y+6,7,1.6);g.strokeStyle=shade(hc,-.4);g.lineWidth=1;for(let i=0;i<3;i++){g.beginPath();g.moveTo(x+3+i*3,y-12);g.lineTo(x+3+i*3,y+9);g.stroke()}}
 else if(k==='bull'){/* the Minotaur: horns, a ringed muzzle and burning eyes */
  const fur=c.sk;
  for(const s of[0,1]){/* horns: far one first */const hx2=x+(s?-3:6),hy2=y-10;g.beginPath();g.moveTo(hx2,hy2+3);g.bezierCurveTo(hx2+(s?-14:14),hy2-4,hx2+(s?-22:20),hy2-18,hx2+(s?-14:12),hy2-34);g.quadraticCurveTo(hx2+(s?-12:11),hy2-20,hx2+(s?2:-2),hy2-5);g.closePath();
   const q=g.createLinearGradient(hx2,hy2,hx2+(s?-14:12),hy2-34);q.addColorStop(0,s?'#f4ead0':'#b8ae98');q.addColorStop(.75,s?'#d8c8a0':'#8a8070');q.addColorStop(1,'#2a1a10');gFill(g,q,1.6);
   g.strokeStyle='#d8a53a';g.lineWidth=2.6;g.beginPath();const bx=hx2+(s?-12:11),by=hy2-6;g.moveTo(bx-3,by+2);g.lineTo(bx+3,by-3);g.stroke()}
  g.beginPath();g.moveTo(x+12,y+6);g.quadraticCurveTo(x+14,y-12,x,y-13);g.quadraticCurveTo(x-12,y-13,x-15,y-3);g.quadraticCurveTo(x-24,y-1,x-26,y+8);g.quadraticCurveTo(x-25,y+17,x-16,y+17);g.quadraticCurveTo(x-6,y+20,x+4,y+16);g.closePath();gFill(g,gMet(g,x-20,y-12,x+12,y+18,fur),1.7);
  g.beginPath();g.ellipse(x-20,y+10,7.5,6.5,-.2,0,TAU);gFill(g,shade(fur,-.25),1.2);g.fillStyle='#120808';g.beginPath();g.ellipse(x-24,y+9,1.6,2.2,-.3,0,TAU);g.fill();
  g.strokeStyle='#ffd24a';g.lineWidth=2.4;g.beginPath();g.arc(x-24,y+14,4.2,-.2,Math.PI*1.1);g.stroke();
  g.beginPath();g.moveTo(x+4,y-6);g.quadraticCurveTo(x+16,y-14,x+18,y-6);g.quadraticCurveTo(x+12,y-2,x+5,y-1);g.closePath();gFill(g,shade(fur,-.15),1.2);
  g.globalCompositeOperation='lighter';glow(g,x-9,y-3,12,(c.eye||'#ff3a1a')+'dd');g.globalCompositeOperation='source-over';g.fillStyle=c.eye||'#ff3a1a';g.beginPath();g.ellipse(x-9,y-3,2.6,1.7,-.3,0,TAU);g.fill();
  g.strokeStyle=GOL;g.lineWidth=2.2;g.beginPath();g.moveTo(x-15,y-8);g.lineTo(x-4,y-5);g.stroke();
  /* bronze brow plate */gPath(g,[x-7,y-12,x+6,y-14,x+9,y-8,x-4,y-7]);gFill(g,gMet(g,x-6,y-14,x+8,y-7,'#c88a3a'),1.2);gRiv(g,x+1,y-10.5,1.3)}
 else if(k==='hollow'){/* the Hollow Centurion: an empty helm with two cold lights inside */
  const fl=Math.sin(t*5)*.5+.5;g.save();g.globalAlpha=.9;
  g.globalCompositeOperation='lighter';for(let i=0;i<9;i++){const a=-Math.PI*.95+i*Math.PI*.9/8,r=22+Math.sin(t*6+i)*2.2;g.strokeStyle=`rgba(${120+i*8},${210},255,${.35+.25*fl})`;g.lineWidth=4.5;g.beginPath();g.moveTo(x+1,y-12);g.quadraticCurveTo(x+1+Math.cos(a)*r*.6,y-12+Math.sin(a)*r*.9,x+1+Math.cos(a)*r,y-14+Math.sin(a)*r)}g.globalCompositeOperation='source-over';
  for(let i=0;i<13;i++){const a=-Math.PI*.98+i*Math.PI*.96/12,r=26+Math.sin(t*7+i*.8)*2;g.strokeStyle=i%2?'#c83a4a':'#e8505a';g.lineWidth=3.2;g.beginPath();g.moveTo(x+1,y-13);g.lineTo(x+1+Math.cos(a)*r,y-13+Math.sin(a)*r*.75);g.stroke()}g.restore();
  g.fillStyle=gMet(g,x-4,y-20,x+6,y-12,hc);g.fillRect(x-4,y-19,10,6);
  g.beginPath();g.arc(x+1,y-2,13,Math.PI*.95,Math.PI*2.05);g.lineTo(x+16,y+9);g.lineTo(x+9,y+9);g.lineTo(x+7,y+15);g.lineTo(x-3,y+15);g.lineTo(x-12,y+7);g.closePath();gFill(g,gMet(g,x-12,y-15,x+16,y+15,hc),1.6);
  g.beginPath();g.moveTo(x-12,y-4);g.lineTo(x-1,y-5);g.lineTo(x-1,y+13);g.lineTo(x-9,y+11);g.closePath();gFill(g,'#05040c',1.2);
  g.globalCompositeOperation='lighter';glow(g,x-6,y,14,'#7fe0ff99');g.globalCompositeOperation='source-over';for(const [ex,ey] of[[-8,-1],[-3,-1]]){g.fillStyle='#e8fbff';g.beginPath();g.ellipse(x+ex,y+ey,1.6,1.2,0,0,TAU);g.fill()}
  g.strokeStyle=shade(hc,.5);g.lineWidth=1.3;g.beginPath();g.moveTo(x-13,y-5);g.quadraticCurveTo(x-1,y-8,x+14,y-3);g.stroke();gRiv(g,x+5,y+4,1.4,'#d8e8ff')}
 else if(k==='sun'){/* Imperator Solaris: a golden face-mask framed by a turning sun */
  g.save();g.translate(x+3,y-3);g.rotate(t*.35);g.globalCompositeOperation='lighter';glow(g,0,0,40,'#ffb84a55');g.globalCompositeOperation='source-over';
  for(let i=0;i<14;i++){const a=i*TAU/14,r1=15,r2=i%2?27:34;g.beginPath();g.moveTo(Math.cos(a-.16)*r1,Math.sin(a-.16)*r1);g.lineTo(Math.cos(a)*r2,Math.sin(a)*r2);g.lineTo(Math.cos(a+.16)*r1,Math.sin(a+.16)*r1);g.closePath();gFill(g,gMet(g,0,-r2,0,r2,i%2?'#ffb02a':'#ffd86a'),1.2)}g.restore();
  g.beginPath();g.arc(x+1,y-1,13.5,Math.PI*.9,Math.PI*2.1);g.lineTo(x+13,y+12);g.lineTo(x-4,y+15);g.lineTo(x-12,y+9);g.closePath();gFill(g,gMet(g,x-12,y-15,x+14,y+15,hc),1.6);
  /* the mask's stern features */g.beginPath();g.moveTo(x-11,y-6);g.lineTo(x-14,y+2);g.lineTo(x-11,y+4);g.lineTo(x-12,y+9);g.lineTo(x-6,y+12);g.lineTo(x-3,y-6);g.closePath();gFill(g,gMet(g,x-14,y-6,x-3,y+12,shade(hc,.18)),1.3);
  g.fillStyle='#2a1604';g.beginPath();g.ellipse(x-8,y-2.5,2.8,1.4,-.1,0,TAU);g.fill();g.globalCompositeOperation='lighter';glow(g,x-8,y-2.5,10,(c.eye||'#fff3b0')+'cc');g.globalCompositeOperation='source-over';g.fillStyle=c.eye||'#fff3b0';g.beginPath();g.ellipse(x-8,y-2.5,1.6,.9,0,0,TAU);g.fill();
  g.strokeStyle='#7a4a08';g.lineWidth=1.2;g.beginPath();g.moveTo(x-12,y+7);g.lineTo(x-7,y+7.5);g.stroke();g.strokeStyle=shade(hc,.5);g.lineWidth=1.4;g.beginPath();g.moveTo(x-12,y-7);g.quadraticCurveTo(x,y-10,x+13,y-4);g.stroke()}}
/* ---------- the fighter ---------- */
const GSTY={chop:{a1:[[-.35,95],[0,112],[.55,250],[1,172]],a2:[[-.35,105],[0,200],[.55,300],[1,166]],aw:[[-.35,140],[0,245],[.55,390],[1,168]]},
 /* thrust: the far arm lives behind the torso; on guard and on the strike the hand sits clear of the chest, so the arm never crosses the body */
 thrust:{a1:[[-.35,100],[0,152],[.55,100],[1,182]],a2:[[-.35,128],[0,182],[.55,104],[1,182]],aw:[[-.35,160],[0,190],[.55,188],[1,181]]},
 heavy:{a1:[[-.35,95],[0,128],[.55,262],[1,160]],a2:[[-.35,110],[0,215],[.55,318],[1,150]],aw:[[-.35,130],[0,300],[.55,410],[1,160]]}};
function glad(g,t,o,c){const lg=Math.max(-.4,Math.min(1.1,o.lg||0)),r0=+o.rv||0,rv=r0>.5&&lg>0&&lg<r0,/* recovering from a strike that peaked at r0: blend straight back to guard instead of passing back through the wind-up (exact at both ends, so nothing jumps) */GKr=(v,K)=>rv?GK(0,K)+(GK(r0,K)-GK(0,K))*(v/r0):GK(v,K),B=c.B||1,br=Math.sin(t*2.4),sk=c.sk||'#d8a07a',skd=shade(sk,-.3),hol=!!c.hollow;
 g.save();g.lineJoin='round';g.lineCap='round';
 if(c.aura){g.save();g.globalCompositeOperation='lighter';glow(g,0,-70,95*B,c.aura+'2a');g.restore()}
 const hx=GKr(lg,[[-.35,5],[0,0],[.55,4],[1,-7]]),hy=-47+br*.6+GKr(lg,[[0,0],[.55,-1],[1,2.5]]),lean=GKr(lg,[[-.35,.1],[0,0],[.55,.09],[1,-.15]]),f1=-20*B+GKr(lg,[[.55,0],[1,-6]]),f2=17*B;
 /* legs */
 const leg=(x0,fx,near)=>{const y0=hy,[kx,ky]=gIK(x0,y0,fx,-5,25,26,1),col=near?sk:skd;
  if(hol){/* only the armour walks */g.save();g.globalAlpha=.4;gLimbs(g,[[x0,y0,kx,ky,9*B],[kx,ky,fx,-5,7*B]],'#7fd8ff');g.restore()}
  else gLimbs(g,[[x0,y0,kx,ky,12.5*B],[kx,ky,fx,-5,10*B]],col,near?shade(sk,.28):0);
  if(c.wrap&&!hol){g.strokeStyle=c.wrap;g.lineWidth=2;for(let i=0;i<4;i++){const u=.2+i*.17,px=x0+(kx-x0)*u,py=y0+(ky-y0)*u;g.beginPath();g.moveTo(px-6*B,py-1);g.lineTo(px+6*B,py+2);g.stroke()}}
  const gv=near?c.greave:(c.greave2||0);
  if(gv){const ux=fx-kx,uy=-5-ky,L=Math.hypot(ux,uy),nx=uy/L,ny=-ux/L;/* n points forward */const p=(u,d)=>[kx+ux*u+nx*d,ky+uy*u+ny*d];const pts=[...p(-.08,7*B),...p(.5,7.5*B),...p(1.02,5*B),...p(1.02,-4*B),...p(.45,-5*B),...p(-.05,-5*B)];gPath(g,pts);gFill(g,gMet(g,kx-8,ky,kx+8,ky,near?gv:shade(gv,-.25)),1.4);
   const kp=p(-.02,1.5);gDisc(g,kp[0],kp[1],6*B,gMet(g,kp[0]-6,kp[1]-6,kp[0]+6,kp[1]+6,near?gv:shade(gv,-.25)),1.3);g.strokeStyle=shade(gv,.5);g.lineWidth=1;const a=p(.15,5*B),b=p(.9,3.5*B);g.beginPath();g.moveTo(a[0],a[1]);g.lineTo(b[0],b[1]);g.stroke()}
  /* sandal or hoof */
  if(c.hoof){g.beginPath();g.moveTo(fx-10,0);g.lineTo(fx-8,-8);g.lineTo(fx+4,-8);g.lineTo(fx+5,0);g.closePath();gFill(g,'#2a1a14',1.4);g.strokeStyle='#120a08';g.lineWidth=1.2;g.beginPath();g.moveTo(fx-3,0);g.lineTo(fx-3,-7);g.stroke()}
  else{g.beginPath();g.ellipse(fx-5,-2.6,9*B,3.8,0,0,TAU);gFill(g,hol?'#3a5a7a':(c.boot||'#6a4226'),1.4);if(!gv&&!hol){g.strokeStyle=c.boot||'#6a4226';g.lineWidth=1.8;for(let i=0;i<3;i++){g.beginPath();g.moveTo(fx-5,-6-i*4.5);g.lineTo(fx+4,-8-i*4.5);g.stroke()}}}};
 leg(hx+5*B,f2,0);
 /* cape behind everything above the waist */
 if(c.cape){const sw=Math.sin(t*2.2)*4,cx0=hx+6*B,cy0=hy-40;g.beginPath();g.moveTo(cx0-4,cy0);g.quadraticCurveTo(cx0+28*B+sw,cy0+20,cx0+30*B+sw*1.6,cy0+48);
  for(let i=0;i<5;i++){const xx=cx0+30*B+sw*1.6-i*7*B,yy=cy0+48+(i%2?-5:3)+(c.tatter?Math.sin(t*4+i)*4:0);g.lineTo(xx,yy)}g.quadraticCurveTo(cx0+4,cy0+30,cx0+2,cy0+6);g.closePath();
  if(hol){g.save();g.globalAlpha=.55;gFill(g,gMet(g,cx0,cy0,cx0+30,cy0+50,c.cape),1.2);g.restore()}else gFill(g,gMet(g,cx0,cy0,cx0+30,cy0+50,c.cape),1.4)}
 if(c.quiver){g.save();g.translate(hx+12*B,hy-30);g.rotate(.5);for(let i=0;i<4;i++){g.strokeStyle='#d8c8a0';g.lineWidth=1.4;g.beginPath();g.moveTo(-3+i*2,-14);g.lineTo(-3+i*2,-24);g.stroke();gPath(g,[-5+i*2,-24,-3+i*2,-29,-1+i*2,-24]);gFill(g,i%2?'#c8323a':'#f0e8d8',.8)}g.beginPath();g.roundRect(-6,-15,11,26,3);gFill(g,gMet(g,-6,0,5,0,'#7a4a26'),1.3);g.fillStyle='#c9a545';g.fillRect(-6,-12,11,2);g.fillRect(-6,6,11,2);g.restore()}
 leg(hx-4*B,f1,1);
 /* everything above the hips leans with the swing */
 g.save();g.translate(hx,hy);g.rotate(lean);
 const sty=GSTY[c.style]||GSTY.chop,lgA=lg,A1=GKr(lg,sty.a1)*GD2,A2=GKr(lg,sty.a2)*GD2,AW0=GKr(lg,sty.aw)*GD2;
 const S1=[9*B,-40],L1=18*(.8+.2*B),L2=17*(.8+.2*B);let E1=[S1[0]+Math.cos(A1)*L1,S1[1]+Math.sin(A1)*L1],H1=[E1[0]+Math.cos(A2)*L2,E1[1]+Math.sin(A2)*L2],AW=AW0;
 /* hand-keyed fighters (Taurox): the gripping hand follows a smooth path and the elbow is solved by IK, so the arm can never bend backwards or snap */
 if(c.hk){const K=c.hk;H1=[GKr(lg,K.x),GKr(lg,K.y)];AW=GKr(lg,K.w)*GD2;E1=gIK(S1[0],S1[1],H1[0],H1[1],L1,L2,K.dir||1)}
 /* depth: the weapon arm is the FAR arm. One-handed fighters keep it behind the hips, torso and head for the whole swing, so it never cuts across the face;
    the blade still shows past the body. Two-handed fighters hold the weapon in front of the torso but behind the head. */
 const farArm=c.style!=='bow'&&!c.two;if(farArm)drawWA();
 /* hip cloth and the wide belt */
 const tw=16.5*B;
 g.beginPath();g.moveTo(-tw+2,-2);g.lineTo(-tw*.7,16);g.quadraticCurveTo(-2,20,tw*.55,15);g.lineTo(tw-1,-2);g.closePath();gFill(g,hol?'#1a2a4a':gMet(g,-tw,0,tw,16,c.cloth||'#e8e0d0'),1.4);
 if(c.pteruges||hol){for(let i=0;i<6;i++){const x=-tw+3+i*(tw*2-6)/5;g.beginPath();g.roundRect(x-2.4,0,4.8,15+(i%2)*2,1.6);gFill(g,hol?'#2a4a6a':(c.pteruges||'#7a4a26'),1)}}
 else{g.strokeStyle='#0003';g.lineWidth=1;for(const x of[-6,1,7]){g.beginPath();g.moveTo(x,1);g.lineTo(x-1,16);g.stroke()}}
 /* torso */
 const torso=()=>{g.beginPath();g.moveTo(-tw+3,-4);g.bezierCurveTo(-tw-2,-14,-tw-5*B,-24,-tw-3*B,-33);g.quadraticCurveTo(-tw,-42,-4,-45);g.quadraticCurveTo(tw*.7,-46,tw-1,-40);g.quadraticCurveTo(tw+2,-26,tw-2,-4);g.closePath()};
 const ti=()=>{torso();g.save();g.clip()};
 if(hol){torso();g.save();g.globalAlpha=.25;gFill(g,'#0a1428',1.4);g.restore()}
 else{torso();gFill(g,gMet(g,-tw-4,-44,tw,0,c.body==='fur'?c.fur||sk:sk),1.7);
  ti();g.strokeStyle='#00000038';g.lineWidth=1.3;g.beginPath();g.moveTo(-tw-3,-30);g.quadraticCurveTo(-8,-23,1,-33);g.moveTo(-8,-20);g.lineTo(-7,-7);g.moveTo(-12,-16);g.lineTo(-3,-15);g.moveTo(-12,-10);g.lineTo(-3,-9);g.stroke();g.fillStyle='#ffffff22';g.beginPath();g.ellipse(-tw+2,-33,4,7,.3,0,TAU);g.fill();g.restore()}
 const bt=c.body;
 if(bt==='scale'){ti();for(let r=0;r<9;r++)for(let i=0;i<8;i++){const x=-tw-4+i*5+(r%2)*2.5,y=-44+r*4.8;g.beginPath();g.arc(x,y,3,0,Math.PI);gFill(g,gMet(g,x-3,y-3,x+3,y+3,c.bc||'#b8bcc8'),.8)}g.restore();torso();g.strokeStyle=GOL;g.lineWidth=1.7;g.stroke()}
 else if(bt==='seg'||hol){ti();if(hol)g.globalAlpha=.85;for(let r=0;r<6;r++){const y=-44+r*7;g.beginPath();g.roundRect(-tw-6,y,tw*2+10,6,2);gFill(g,gMet(g,0,y,0,y+6,c.bc||'#b8bcc8'),1)}g.restore();torso();g.strokeStyle=hol?'#7fd8ffaa':GOL;g.lineWidth=1.7;g.stroke();
  if(hol){g.save();g.globalCompositeOperation='lighter';glow(g,-2,-24,30,'#7fd8ff55');g.restore()}}
 else if(bt==='straps'){ti();g.strokeStyle=GOL;g.lineWidth=6;g.beginPath();g.moveTo(-tw-4,-40);g.lineTo(tw,-6);g.stroke();g.strokeStyle=c.bc||'#6a3a1e';g.lineWidth=4;g.stroke();for(let i=0;i<4;i++){const u=.15+i*.22;gRiv(g,-tw-4+(tw*2+4)*u,-40+34*u,1.2,'#e8c86a')}g.restore()}
 else if(bt==='cuirass'){ti();g.fillStyle=gMet(g,-tw-4,-44,tw,0,c.bc||'#e8b84a');g.fillRect(-40,-50,80,50);g.strokeStyle=shade(c.bc||'#e8b84a',.55);g.lineWidth=1.4;g.beginPath();g.moveTo(-tw-3,-31);g.quadraticCurveTo(-9,-24,0,-34);g.moveTo(-9,-21);g.lineTo(-8,-7);g.moveTo(-13,-16);g.lineTo(-3,-15);g.stroke();
  if(c.emb){g.save();g.translate(-5,-28);for(let i=0;i<10;i++){const a=i*TAU/10;g.strokeStyle=c.emb;g.lineWidth=1.3;g.beginPath();g.moveTo(Math.cos(a)*3,Math.sin(a)*3);g.lineTo(Math.cos(a)*6.5,Math.sin(a)*6.5);g.stroke()}gDisc(g,0,0,2.6,c.emb,.8);g.restore()}g.restore();torso();g.strokeStyle=GOL;g.lineWidth=1.7;g.stroke()}
 else if(bt==='fur'){ti();g.fillStyle=shade(c.fur||sk,-.25);for(let i=0;i<9;i++){const x=-tw+i*3.6,y=-40+(i%3)*3;g.beginPath();g.moveTo(x,y);g.lineTo(x+2,y+9);g.lineTo(x+4,y);g.fill()}g.strokeStyle='#8a8a98';g.lineWidth=2.6;g.setLineDash([3,2]);g.beginPath();g.moveTo(-tw-3,-38);g.lineTo(tw,-12);g.stroke();g.setLineDash([]);g.restore()}
 /* belt */
 g.beginPath();g.roundRect(-tw-1,-9,tw*2+1,9,2.5);gFill(g,gMet(g,0,-9,0,0,c.belt||'#c9963a'),1.5);for(let i=0;i<5;i++)gRiv(g,-tw+3+i*(tw*2-5)/4,-4.5,1.3,'#fff0b0');
 if(c.galerus){g.beginPath();g.moveTo(tw-12,-44);g.lineTo(tw-6,-62);g.quadraticCurveTo(tw+4,-60,tw+6,-48);g.lineTo(tw+4,-36);g.closePath();gFill(g,gMet(g,tw-10,-62,tw+6,-36,c.galerus),1.5);g.strokeStyle=shade(c.galerus,.5);g.lineWidth=1;g.beginPath();g.moveTo(tw-8,-46);g.lineTo(tw-4,-58);g.stroke()}
 if(c.pauld){for(const [px,s] of[[tw-3,1],[-tw+2,.9]]){g.beginPath();g.ellipse(px,-41,9*B*s,7,0,Math.PI*1.02,Math.PI*1.98);g.lineTo(px+9*B*s,-37);g.quadraticCurveTo(px,-33,px-9*B*s,-37);g.closePath();gFill(g,gMet(g,px-9,-48,px+9,-34,c.pauld),1.5);if(c.spikes)for(const dx of[-4,2])gPath(g,[px+dx-2,-46,px+dx,-54,px+dx+2,-46]),gFill(g,'#e8e0d0',1)}}
 /* two-handed: weapon and far arm sit over the torso but under the head; the near arm goes under the head too while the hands are raised */
 let naDone=false;if(c.two){drawWA();const g2=grip2([-7*B,-41]);if(c.hk||g2[1]<-50){drawNA();naDone=true}}
 /* neck and head */
 const nx=-3,ny=-44,hdx=-5+GKr(lg,[[.55,1],[1,-2]]),hdy=-57;if(!hol)gLimbs(g,[[nx,ny,hdx+1,hdy+6,9*B]],sk);
 g.save();g.translate(hdx,hdy);if(c.hs)g.scale(c.hs,c.hs);gHead(g,c.helm,0,0,c,t,lg);g.restore();
 /* the weapon arm */
 function drawWA(){if(c.style==='bow'){/* archer: the bow arm reaches forward, the near hand draws the string */return}
  const armC=hol?'#7fd8ff':sk;if(hol){g.save();g.globalAlpha=.45}
  gLimbs(g,[[S1[0],S1[1],E1[0],E1[1],9.5*B],[E1[0],E1[1],H1[0],H1[1],8.5*B]],armC,hol?0:shade(sk,.25));if(hol)g.restore();
  if(c.manica||hol){const mc=hol?(c.bc||'#9ab0d0'):c.manica;for(const [a,b,n] of[[S1,E1,3],[E1,H1,4]])for(let i=0;i<n;i++){const u0=(i+.1)/n,u1=(i+.9)/n,x0=a[0]+(b[0]-a[0])*u0,y0=a[1]+(b[1]-a[1])*u0,x1=a[0]+(b[0]-a[0])*u1,y1=a[1]+(b[1]-a[1])*u1;gLimbs(g,[[x0,y0,x1,y1,10.5*B]],mc,shade(mc,.4))}}
  g.save();g.translate(H1[0],H1[1]);g.rotate(AW);gWeap(g,c.wp,c,t);g.restore();
  gDisc(g,H1[0],H1[1],4.4*B,hol?'#bfeaff':(c.manica?shade(c.manica,-.1):shade(sk,-.08)),1.3)}
 /* where the near hand holds a two-handed haft: as close to the usual grip as the arm can reach, always on the haft */
 function grip2(S2){const ux=Math.cos(AW),uy=Math.sin(AW),wx=H1[0]-S2[0],wy=H1[1]-S2[1],ds=wx*ux+wy*uy,R=32.5,n13=Math.hypot(wx-ux*13,wy-uy*13),q=Math.max(0,Math.min(1,(n13-(R-10))/10)),s=q*q*(3-2*q);
  /* the usual grip while it is comfortably in reach, sliding smoothly toward the nearest point of the haft as the reach runs out */
  const d=Math.max(-6,Math.min(24,13+(ds-13)*s));return[H1[0]-ux*d,H1[1]-uy*d]}
 /* the near arm: shield, net, second blade, bow or a two-handed grip */
 function drawNA(){const S2=[-7*B,-41];
  if(c.style==='bow'){const bh=[-31,-30],bowA=GKr(lg,[[0,0],[.55,-.05],[1,.04]]);gLimbs(g,[[S1[0]-10,S1[1],-14,-34,9*B],[-14,-34,bh[0],bh[1],8*B]],skd);
   const pull=GKr(lg,[[-.35,0],[0,3],[.55,24],[.78,26],[.86,2],[1,0]]),sx=bh[0]+3+pull,sy=bh[1];
   g.save();g.translate(bh[0],bh[1]);g.rotate(bowA);g.strokeStyle=GOL;g.lineWidth=5.6;g.beginPath();g.moveTo(4,-30);g.quadraticCurveTo(-12,-14,-2,0);g.quadraticCurveTo(-12,14,4,30);g.stroke();g.strokeStyle=c.bowc||'#8a5a2a';g.lineWidth=3.4;g.stroke();g.strokeStyle='#e8c86a';g.lineWidth=1.4;g.beginPath();g.moveTo(-4,-4);g.lineTo(-4,4);g.stroke();g.restore();
   g.strokeStyle='#f0ead8';g.lineWidth=1.1;g.beginPath();g.moveTo(bh[0]+4,bh[1]-30);g.lineTo(sx,sy);g.lineTo(bh[0]+4,bh[1]+30);g.stroke();
   if(lg>-.1&&lg<.84){g.strokeStyle=GOL;g.lineWidth=3.4;g.beginPath();g.moveTo(sx,sy);g.lineTo(bh[0]-24,sy);g.stroke();g.strokeStyle='#e8dcc0';g.lineWidth=1.8;g.stroke();gPath(g,[bh[0]-30,sy,bh[0]-23,sy-3,bh[0]-23,sy+3]);gFill(g,'#d8e8f8',1);gPath(g,[sx,sy,sx+5,sy-3,sx+3,sy]);gFill(g,'#c8323a',.6)}
   const [ex,ey]=gIK(S2[0]+8,S2[1],sx,sy,15,14,-1);gLimbs(g,[[S2[0]+8,S2[1],ex,ey,9*B],[ex,ey,sx,sy,8*B]],sk,shade(sk,.25));gDisc(g,sx,sy,4*B,shade(sk,-.08),1.2);return}
  if(c.style==='twin'){const a1=GKr(lg,[[-.35,100],[0,124],[.55,150],[1,176]])*GD2,a2=GKr(lg,[[-.35,120],[0,206],[.55,232],[1,170]])*GD2,aw=GKr(lg,[[-.35,150],[0,236],[.55,252],[1,172]])*GD2,e=[S2[0]+Math.cos(a1)*17,S2[1]+Math.sin(a1)*17],h=[e[0]+Math.cos(a2)*16,e[1]+Math.sin(a2)*16];
   gLimbs(g,[[S2[0],S2[1],e[0],e[1],9.5*B],[e[0],e[1],h[0],h[1],8.5*B]],sk,shade(sk,.25));if(c.manica){for(const [a,b] of[[S2,e],[e,h]])gLimbs(g,[[a[0]+(b[0]-a[0])*.15,a[1]+(b[1]-a[1])*.15,a[0]+(b[0]-a[0])*.85,a[1]+(b[1]-a[1])*.85,10.5*B]],c.manica,shade(c.manica,.4))}
   g.save();g.translate(h[0],h[1]);g.rotate(aw);gWeap(g,c.wp2||c.wp,c,t);g.restore();gDisc(g,h[0],h[1],4.4*B,shade(sk,-.08),1.3);return}
  if(c.two){/* both hands on the haft */const [gx,gy]=grip2(S2),[ex,ey]=gIK(S2[0],S2[1],gx,gy,17,17,-1);gLimbs(g,[[S2[0],S2[1],ex,ey,10*B],[ex,ey,gx,gy,9*B]],sk,shade(sk,.25));gDisc(g,gx,gy,4.8*B,shade(sk,-.08),1.3);return}
  const tgt=c.sh==='net'?[GKr(lg,[[-.35,-8],[0,-14],[.55,-4],[1,-6]]),GKr(lg,[[-.35,-10],[0,-20],[.55,-28],[.8,-16],[1,-12]])]:c.style==='thrust'?[GKr(lg,[[-.35,-12],[0,-20*B],[.55,-23*B],[1,-12*B]]),GKr(lg,[[-.35,-10],[0,-24],[.55,-30],[.8,-18],[1,-12]])]:[GKr(lg,[[-.35,-12],[0,-20*B],[.55,-23*B],[1,-17*B]]),GKr(lg,[[-.35,-10],[0,-24],[.55,-30],[1,-22]])];
  const [ex,ey]=gIK(S2[0],S2[1],tgt[0],tgt[1],16,15,-1);gLimbs(g,[[S2[0],S2[1],ex,ey,9.5*B],[ex,ey,tgt[0],tgt[1],8.5*B]],hol?'#7fd8ff55':sk,hol?0:shade(sk,.25));
  g.save();g.translate(tgt[0],tgt[1]);if(c.sh!=='net')g.rotate(GKr(lg,[[-.35,.35],[0,.06],[.55,-.08],[1,.12]]));gShield(g,c.sh,c,t);g.restore();if(c.sh==='net')gDisc(g,tgt[0],tgt[1],4.4*B,shade(sk,-.08),1.3)};
 /* spear fighters keep the low thrusting arm in front (it never rises past the face): behind the net or shield while drawing back, in front of it once the thrust is moving */
 const front=false;/* no depth swap mid-thrust: the spear arm always stays behind the shield or net, which swings low and out of the way as the spear goes in */
 if(c.style==='bow')drawWA();if(!naDone)drawNA();
 g.restore();
 if(c.after)c.after(g,t,lg);
 g.restore()}
/* ---------- the roster ---------- */
const GLAD={
 gTiro:{n:'Pit Recruit',helm:'mont',hc:'#c98a3a',cc:'#c8323a',sk:'#e0a47c',body:'straps',bc:'#6a3a1e',cloth:'#e8dcc8',belt:'#b8823a',greave:'#c98a3a',sh:'parma',shc:'#2a4a9a',she:'#ffd86a',shr:'#c98a3a',wp:'gladius',style:'chop',wrap:'#d8ccb0'},
 gDima:{n:'Twin Blade',helm:'mask',hc:'#a8b0c0',hc2:'#e8dcc0',eye:'#ff5a3a',sk:'#c88a64',body:'scale',bc:'#9aa2b4',cloth:'#9a1a2a',belt:'#8a8a9a',manica:'#a8b0c0',greave:'#a8b0c0',greave2:'#a8b0c0',wp:'sica',style:'twin',wc:'#d8dce8',B:.95},
 gReti:{n:'Net Caster',helm:'bare',hair:'#1e140e',cc:'#2a7ac8',sk:'#b87a56',body:'bare',cloth:'#2a5aa8',belt:'#c9963a',galerus:'#d8a53a',manica:'#c8b898',sh:'net',wp:'trident',style:'thrust',wrap:'#c8b898',B:.98},
 gSagi:{n:'Sun Archer',helm:'attic',hc:'#d8a53a',cc:'#1a8a7a',sk:'#d8a07a',body:'scale',bc:'#a87a3a',cloth:'#e8e0c8',belt:'#8a5a2a',greave:'#d8a53a',style:'bow',quiver:1,wrap:'#c8b898',B:.92},
 gMurm:{n:'Shield Wall',helm:'murm',hc:'#c9cfdc',cc:'#e8b84a',sk:'#d49a72',body:'bare',cloth:'#f0e8d8',belt:'#d8a53a',manica:'#c9cfdc',greave:'#d8a53a',sh:'scutum',shc:'#b8202e',she:'#ffd86a',shr:'#d8a53a',wp:'gladius',style:'chop',wrap:'#e8dcc0',B:1.22},
 gThrx:{n:'Thraex Trickster',helm:'thraex',hc:'#b8bccc',cc:'#8a4ac8',fc:'#e8d8ff',eye:'#c88aff',sk:'#dca07a',body:'bare',cloth:'#6a2a9a',belt:'#b8bccc',manica:'#b8bccc',greave:'#b8bccc',greave2:'#b8bccc',sh:'square',shc:'#5a2a8a',she:'#e8d8ff',shr:'#b8bccc',wp:'sica',style:'chop',wc:'#e0e4f0'},
 gMino:{n:'Taurox',hk:{dir:1,x:[[-.35,-14],[0,-4],[.3,8],[.55,24],[.7,18],[.8,2],[.9,-22],[1,-32]],y:[[-.35,-14],[0,-24],[.3,-46],[.55,-66],[.7,-76],[.8,-76],[.9,-50],[1,-20]],w:[[-.35,150],[0,288],[.3,330],[.55,410],[.7,330],[.8,260],[.9,205],[1,165]]},helm:'bull',hs:1.35,sk:'#6a4430',fur:'#6a4430',eye:'#ff3a1a',body:'fur',cloth:'#5a1a14',belt:'#9a6a2a',pauld:'#b8823a',spikes:1,greave:'#b8823a',greave2:'#b8823a',hoof:1,wp:'labrys',two:1,style:'heavy',wc:'#b8bcc8',gc:'#ffd86a',B:1.5,cape:'#5a1a14',pteruges:'#5a3420'},
 gCent:{n:'The Hollow Centurion',helm:'hollow',hs:1.2,hollow:1,hc:'#8aa0c8',bc:'#9ab0d0',eye:'#7fe0ff',cape:'#3a6a9a',tatter:1,greave:'#8aa0c8',greave2:'#8aa0c8',sh:'tower',shc:'#1a3a6a',she:'#9fe8ff',shr:'#8aa0c8',wp:'spatha',wglow:'#7fe0ff',wc:'#cfeaff',style:'chop',aura:'#5ac8ff',B:1.3},
 gSol:{n:'Imperator Solaris',helm:'sun',hs:1.2,hc:'#f0c24a',sk:'#b8744a',body:'cuirass',bc:'#f0c24a',emb:'#fff3b0',eye:'#fff3b0',cloth:'#a81a1a',belt:'#d8a53a',greave:'#f0c24a',greave2:'#f0c24a',sh:'clipeus',shc:'#d89a2a',she:'#fff0a0',shr:'#f0c24a',wp:'spear',flame:1,style:'thrust',wc:'#ffe27a',cape:'#b81a1a',pteruges:'#a81a1a',aura:'#ffb84a',B:1.4}};
/* measured art bounds (x0,y0,x1,y1 in art units), so sprite caching never has to scan pixels mid-fight */
const GLAD_BB={gTiro:[-77,-147,57,9],gDima:[-93,-149,52,9],gReti:[-125,-128,81,9],gSagi:[-72,-147,45,9],gMurm:[-75,-152,58,10],gThrx:[-78,-161,52,9],gMino:[-116,-198,105,25],gCent:[-107,-176,106,36],gSol:[-150,-183,114,37]};
for(const id in GLAD){const C=GLAD[id],boss=id==='gMino'||id==='gCent'||id==='gSol';MON[id]={n:C.n,h:boss?(id==='gMino'?440:id==='gSol'?450:430):(id==='gMurm'?330:id==='gSagi'?300:310),sp:50,th:boss?150:140,nx:1,boss:boss?1:0,gl:1,d:(g,t,o)=>glad(g,t,o||{},C)}}
