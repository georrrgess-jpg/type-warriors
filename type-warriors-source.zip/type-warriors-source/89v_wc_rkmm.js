/* ===== WILDCARD RANKED: online matchmaking through the room-code relays (no Firebase) =====
   Everyone searching joins one encrypted relay channel ("RANKED") and says {t:'seek',id,r} every 1.5 s. For the first 8 s
   only players at your own rank count; after that, one rank either side. When compatible players are around, the one
   with the smallest id hosts: it picks a room code, tells the others ({t:'room',code,to:[ids]}) and opens a normal
   private room; the others join it by that code and are readied automatically. At 15 s, if nobody was found, the match
   starts with AI players. The host fills empty seats with AI at its rank, runs the game as a normal room game with the
   ranked flag, and at the end sends everyone the final standings and hands ({t:'rkfin'}); each player applies their own
   points on their own device. Timeouts are counted by the host: three in a row hand that seat to an AI ({t:'rkafk'}).
   There is no server, so points are not protected against cheating; that is the cost of not using Firebase. */
const RKMM={on:0,id:'',t0:0,peers:{},tm:0,role:'',room:'',to:[],tA:0};
function rkFind(){const R=rkSt();rkDodge();if(!wcRelayOk()){rkStart();return}
 rkMMStop();Object.assign(RKMM,{on:1,id:Date.now().toString(36)+Math.random().toString(36).slice(2,7),t0:Date.now(),peers:{},role:'seek',room:'',to:[],tA:0});
 WX.tok++;wcClear();rkMMView();
 wcRelayOpen('RANKED','mm',rkMMMsg,st=>{if(!RKMM.on)return;RKMM.net=st;rkMMView(true)});
 RKMM.tm=setInterval(rkMMTick,500);rkMMTick()}
function rkMMStop(keepRelay){clearInterval(RKMM.tm);RKMM.tm=0;if(!keepRelay&&RKMM.role==='seek')try{wcRelayClose()}catch(e){}RKMM.on=0}
const rkMMWin=()=>Date.now()-RKMM.t0>=8000?1:0;
const rkMMOk=p=>Math.abs(p.r-rkSt().r)<=rkMMWin()&&Math.abs(p.r-rkSt().r)<=(p.win||0)&&Date.now()-p.last<4500;
function rkMMMsg(m){if(!RKMM.on||!m||m.id===RKMM.id)return;const R=rkSt();
 if(m.t==='seek'&&RKMM.role==='seek'){RKMM.peers[m.id]={id:m.id,r:Math.max(0,Math.min(5,m.r|0)),win:m.win|0,name:String(m.name||'Player').replace(/[<>]/g,'').slice(0,14),av:m.av&&m.av.t==='hero'?m.av:{t:'hero'},lp:m.lp|0,last:Date.now()};
  if(m.r===5&&m.lp){R.met[RKMM.peers[m.id].name]={lp:m.lp|0,s:R.season};const ks=Object.keys(R.met);if(ks.length>30)delete R.met[ks[0]]}rkMMView(true)}
 if(m.t==='room'&&RKMM.role==='seek'&&Array.isArray(m.to)&&m.to.includes(RKMM.id)&&/^[A-Z2-9]{4}$/.test(m.code||'')){RKMM.role='guest';RKMM.room=m.code;rkMMStop(true);rkMMJoin(m.code)}}
function rkMMTick(){if(!RKMM.on)return;const R=rkSt(),el=Date.now()-RKMM.t0;
 if(RKMM.role==='seek'){wcRelaySend('mm',{t:'seek',id:RKMM.id,r:R.r,win:rkMMWin(),name:P.name||'Player',av:wcMyAv(),lp:R.r===5?R.lp:0});
  const ok=Object.values(RKMM.peers).filter(rkMMOk);
  if(el>=3000&&ok.length&&ok.every(p=>RKMM.id<p.id)){RKMM.role='host';RKMM.to=ok.sort((a,b)=>a.id<b.id?-1:1).slice(0,3).map(p=>p.id);RKMM.room=wcCode();RKMM.tA=Date.now();rkMMAnnounce();return}
  if(el>=15000){rkMMStop();wcToast&&0;rkStart();setTimeout(()=>{try{wcToast('No ranked players were free, so AI players at your rank took the seats.')}catch(e){}},1200);return}}
 rkMMView(true)}
function rkMMAnnounce(){let n=0;const say=()=>{if(RKMM.role!=='host')return;wcRelaySend('mm',{t:'room',id:RKMM.id,code:RKMM.room,to:RKMM.to});if(++n<4)setTimeout(say,450);else setTimeout(rkMMHost,300)};say()}
/* host: a ranked private room, readied guests, then deal */
function rkMMHost(){clearInterval(RKMM.tm);RKMM.tm=0;const R=rkSt();
 Object.assign(WCL,{room:RKMM.room,seats:[{k:'you',name:P.name||'You'},{k:'open'},{k:'open'},{k:'open'}],crew:wcCrewGen(3,null,{rare:.1}),rk:1});WCL.set=Object.assign(WCL.set||{},{stake:0,timer:15,hand:7,stack:1,until:0,seven:0});
 wcRelayClose();WX.tok++;wcClear();wcHostRelay();wcLobbyRender();RKMM.on=1;RKMM.role='hosting';
 RKMM.tm=setInterval(()=>{if(!$('wcl')||!WCL.rk){clearInterval(RKMM.tm);return}const net=WCL.seats.filter(s=>s.k==='net'),all=net.length>=RKMM.to.length&&net.every(s=>s.ready),late=Date.now()-RKMM.tA>16000;
  rkMMView(true);if((all&&net.length)||late){clearInterval(RKMM.tm);RKMM.on=0;rkNetStart()}},500)}
function rkNetStart(){const R=rkSt(),lv='r'+rkLvl(R.r);WCL.rk=0;
 const seats=WCL.seats.map((s,i)=>Object.assign({},s,{_i:i})).filter(s=>s.k!=='none');
 const players=seats.map(s=>{const i=s._i;if(s.k==='you')return{id:'host',name:P.name||'You',kind:'you',av:wcMyAv(),title:R.title};
  if(s.k==='net'){const real=WCL.seats[i];return{id:real.pid,name:real.name||'Friend',kind:'net',av:real.av||{t:'hero'}}}
  const A=WCL.crew[i-1]||wcCrewGen(1)[0];return{id:'b'+i,name:A.name,kind:'bot',diff:lv,ai:1,av:A}});
 const net=players.some(p=>p.kind==='net');wcFx('shuffle');
 wcReset({mode:net?'net':'solo',tbl:'rk',host:true,stake:0,fee:0,room:WCL.room,cfg:{timer:15,tbl:'rk',set:Object.assign({},WCL.set)},rk:{r:R.r,id:WCL.room,net:net?1:0}});
 WX.G=wcNew({players,hand:7,rules:{stack:1,until:0,seven:0},seed:(Date.now()^Math.floor(Math.random()*1e9))>>>0});R.live={t:Date.now(),r:R.r};save();
 if(net){WX.rkSendRk=1;wcNetStart()}else try{wcRelayClose()}catch(e){}wcTable();wcPump()}
/* the ranked flag goes to the guests right after 'start' and before the first table state */
{const y0=wcSync;wcSync=function(){if(WX.rkSendRk){WX.rkSendRk=0;wcRelay({t:'rk'})}return y0.apply(this,arguments)}}
/* guest: join the host's room by code, ready up, play */
function rkMMJoin(code){WX.rkmm=1;RKMM.joinT=Date.now();wcJoinCode(code);setTimeout(()=>{if(WX.rkmm&&!(WX.G&&WX.rk)){WX.rkmm=0;try{wcNetClose()}catch(e){}rkStart();setTimeout(()=>{try{wcToast('Could not reach the other player, so AI players took the seats.')}catch(e){}},1200)}},30000)}
{const v0=wcJoinView;wcJoinView=function(state){if(WX.rkmm&&['none','full','started','nonet','bad','badinv'].includes(state)){WX.rkmm=0;try{wcNetClose()}catch(e){}rkStart();return}const r=v0.apply(this,arguments);if(WX.rkmm)rkMMView(true);return r}}
{const g0=wcGuestMsg;wcGuestMsg=function(raw){let m=null;try{m=JSON.parse(raw)}catch(e){}const g=WCNET.guest;
 if(m&&m.t==='rk'){const R=rkSt();WX.rk={r:R.r,id:WX.room||'',net:1};WX.rkmm=0;WX.cfg.timer=15;R.live={t:Date.now(),r:R.r};save();if($('wct'))try{wcTable()}catch(e){}return}
 if(m&&m.t==='rkfin'&&WX.rk){WX.rkFin=m;return}
 if(m&&m.t==='rkafk'&&WX.rk&&!WX.rkDone){WX.rkDone=1;const res=rkApply(3,'afk');try{wcRecord({forfeit:1})}catch(e){}const gg=WCNET.guest;if(gg)gg.closing=1;try{wcNetClose()}catch(e){}WX.tok++;wcClear();rkResults(res,null,{afk:1});return}
 const r=g0.apply(this,arguments);if(m&&m.t==='lobby'&&WX.rkmm&&g&&!g.ready){g.ready=1;wcNetSend({t:'ready',v:1})}return r}}
/* the host sends the final standings and every hand, so guests can place everyone exactly */
{const e0=wcEnd;wcEnd=function(){if(WX.rk&&WX.rk.net){const G=WX.G;if(WX.host&&G){wcRelay({t:'rkfin',rank:wcRank(G),hands:G.P.map(p=>p.hand)})}
 else if(!WX.host&&!WX.rkFin&&(WX.rkWaitFin=(WX.rkWaitFin||0)+1)<12){wcLater(()=>wcEnd(),250);return}
 else if(!WX.host&&WX.rkFin&&G){const f=WX.rkFin;if(Array.isArray(f.hands))f.hands.forEach((h,i)=>{if(G.P[i]&&Array.isArray(h))G.P[i].hand=h});if(Array.isArray(f.rank)){WX.rkRank=f.rank}}}return e0.apply(this,arguments)}}
{const k0=wcRank;wcRank=function(G){if(WX.rkRank&&WX.G===G&&!WX.host)return WX.rkRank.slice();return k0.apply(this,arguments)}}
/* timeouts at an online seat are counted by the host */
{const h0=wcHostMsg;wcHostMsg=function(s,raw){WX.rkNet=1;try{return h0.apply(this,arguments)}finally{WX.rkNet=0}}}
{const a0=wcApply;wcApply=function(pi,a){const G=WX.G,p=G&&G.P[pi],netSeat=!!(WX.rk&&WX.host&&p&&p.kind==='net'),own=!!WX.rkNet;const r=a0.apply(this,arguments);
 if(netSeat&&r&&a&&a.t!=='call'&&a.t!=='catch'){if(own)p.rkTo=0;else if(a.t==='draw'||a.t==='pass'){p.rkTo=(p.rkTo||0)+1;if(p.rkTo>=3){const s=WCNET.peers[p.id];if(s)wcTx(s,{t:'rkafk'});p.kind='bot';p.diff='r'+rkLvl(WX.rk.r);p.ai=1;wcChat('Lounge',`${p.name} timed out three times. An AI takes their seat.`)}}}return r}}
{const p0=wcPeerGone;wcPeerGone=function(s){const r=p0.apply(this,arguments);try{if(WX.rk&&WX.G){const p=WX.G.P.find(q=>q.id===s.pid);if(p&&p.kind==='bot'){p.diff='r'+rkLvl(WX.rk.r);p.ai=1}}}catch(e){}return r}}
/* the host leaving is not the guests' fault: the match simply does not count for them */
{const x0=wcHostGone;wcHostGone=function(msg){if(WX.rk&&WX.rk.net&&!WX.host&&!WX.rkDone&&WX.G&&WX.G.phase!=='over'){WX.rkDone=1;const R=rkSt();R.live=null;save();return x0.call(this,'The host left, so this ranked match does not count')}return x0.apply(this,arguments)}}
/* the matchmaking screen (over the lobby or join screen when a match is being set up) */
function rkMMView(update){const R=rkSt(),T=WCRN[R.r],el=Math.max(0,Date.now()-RKMM.t0),sec=Math.min(15,Math.floor(el/1000)),wide=rkMMWin();
 const found=RKMM.role==='seek'?Object.values(RKMM.peers).filter(rkMMOk):[],range=wide?[R.r-1,R.r,R.r+1].filter(x=>x>=0&&x<=5).map(x=>WCRN[x].n).join(', '):T.n;
 const status=RKMM.role==='seek'?(RKMM.net==='offline'?'Can\'t reach the room servers. AI players will fill the table.':found.length?`${found.length} player${found.length>1?'s':''} found…`:'Looking for players…')
  :RKMM.role==='host'||RKMM.role==='hosting'?'Match found! Setting up the table…':'Match found! Joining the table…';
 const body=`<div class="rkmmc">${rkInsig(R.r,200,{anim:1})}<div class="rkmmr"><i></i><i></i><i></i></div></div><h2>Finding a ranked match</h2><p class="rkmms">${status}</p>
  <div class="rkmmt"><b>0:${String(sec).padStart(2,'0')}</b><span>${RKMM.role==='seek'?`Matching with ${range} players${wide?'':' · one rank either side after 8 s'}`:'Empty seats are filled by AI at your rank'}</span></div>
  <div class="rkmmp">${found.slice(0,3).map(p=>`<span><b>${esc(p.name)}</b><small style="color:${WCRN[p.r].c}">${WCRN[p.r].n}</small></span>`).join('')}</div>${RKMM.role==='seek'?'<button class="wcbtn" id="rkmmx">Cancel</button>':''}`;
 let v=document.querySelector('.rkmmv');const root=$('wcl')||$('wcj')||null;
 if(!v||!v.isConnected){if(root){v=document.createElement('div');v.className='rkmmv over';root.appendChild(v)}else{show(`<div class="rkx rkmmx" id="rkmmx0"><div class="wclbg"><i class="wcspot a"></i><i class="wcspot b"></i></div><div class="rkmmv"></div><div class="wcmod" id="wcmod" hidden></div></div>`,'casbg wcx');v=document.querySelector('.rkmmv');S.back=rkMMCancel}}
 v.innerHTML=body;const x=$('rkmmx');if(x)x.onclick=rkMMCancel}
function rkMMCancel(){rkMMStop();RKMM.role='';wcFx('back');rkHub()}
{const st=document.createElement('style');st.textContent=`
.rkmmv{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;z-index:40;text-align:center;color:var(--ink);font-family:var(--ui)}
.rkmmv.over{background:radial-gradient(ellipse at 50% 40%,#2a1a5af7,#07030cf7 75%)}
.rkmmc{position:relative;width:300px;height:300px;display:grid;place-items:center}.rkmmc .rkins{position:relative;z-index:2}
.rkmmr i{position:absolute;left:50%;top:50%;width:200px;height:200px;margin:-100px 0 0 -100px;border-radius:50%;border:3px solid #ffd45a;opacity:0;animation:rkring 2.4s ease-out infinite}.rkmmr i:nth-child(2){animation-delay:.8s}.rkmmr i:nth-child(3){animation-delay:1.6s}
@keyframes rkring{0%{transform:scale(.6);opacity:.8}100%{transform:scale(1.5);opacity:0}}
.rkmmv h2{margin:6px 0 0;font:400 52px/1 'Pirata One',Georgia,serif;color:#ffd45a;text-shadow:0 4px 0 #12081f}
.rkmms{margin:10px 0 0;font:700 18px var(--ui);color:#ece4ff}
.rkmmt{display:flex;flex-direction:column;align-items:center;gap:4px;margin-top:16px}.rkmmt b{font:900 40px var(--ui);color:#fff}.rkmmt span{font:700 14px var(--ui);color:#a8a0d0}
.rkmmp{display:flex;gap:12px;margin-top:16px;min-height:52px}.rkmmp span{display:flex;flex-direction:column;padding:8px 16px;border-radius:14px;background:#160c34;border:1.5px solid #463a8a;animation:wcpop .35s var(--sp) both}.rkmmp b{font:800 15px var(--ui)}.rkmmp small{font:800 12px var(--ui)}
.rkmmv .wcbtn{margin-top:18px;width:220px}`;document.head.appendChild(st)}
/* after an online ranked match, both sides hang up cleanly (the guest first, so the host's goodbye does not pull them off the result screen) */
{const r0=rkResults;rkResults=function(){if(WX.rk&&WX.rk.net){if(WX.host)setTimeout(()=>{try{if(!$('wct'))wcNetClose()}catch(e){}},2500);else{const g=WCNET.guest;if(g)g.closing=1;setTimeout(()=>{try{wcNetClose()}catch(e){}},300)}}return r0.apply(this,arguments)}}
