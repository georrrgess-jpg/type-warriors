/* ===== MOONLIT FISHING update 7: Lighthouse Cove (FSLOCART.cove) =====
   The secret spot from the message-in-a-bottle quest: a hidden cove beneath the old Stormreach lighthouse. Night, a thin
   new-moon crescent, a dark teal sea. A rocky headland rises behind the cove; on it stands the old striped lighthouse with
   the keeper's cottage, and his lamp still glows a ghostly warm gold, its twin beams sweeping slowly round over sky and sea.
   A wooden stair zig-zags down the cliff to the hero's rickety pier (rope rail, ship lanterns, gulls asleep on a piling).
   Out at sea: the broken bow of a shipwreck with its anchor and chain, distant sea stacks and a fog bank on the horizon.
   bg paints the still scene once (incl. the softened, wavy reflection, the lamp's golden path and the moon path on the water).
   back/front draw only cached sprites and a handful of light shapes: the beams are one cached wedge drawn rotated/scaled,
   the big breathing glows are pre-made at their drawn size (1:1 blits), the fog banks are pre-baked strips that scroll
   (whole-pixel offsets: a fractional blit costs ~4x more),
   the lantern halos flicker through 5 pre-made sizes, and the water sparkle is batched into a few single-path fills.
   Private helpers are prefixed lc_. */
let lc_S=null;
const lc_hx=a=>Math.round(Math.max(0,Math.min(1,a))*255).toString(16).padStart(2,'0');
const lc_r=s=>{const x=Math.sin(s*63.917+5.41)*43758.5453;return x-Math.floor(x)};
function lc_cv(w,h){const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d');x.lineJoin='round';x.lineCap='round';return[c,x]}
/* soft additive glow sprite (tinted), radius R, drawn 1:1 */
function lc_spr(col,R,k){const[c,g]=lc_cv(R*2,R*2),q=g.createRadialGradient(R,R,0,R,R,R);k=k||[.22,.55];
 q.addColorStop(0,col+'ff');q.addColorStop(k[0],col+'aa');q.addColorStop(k[1],col+'30');q.addColorStop(1,col+'00');g.fillStyle=q;g.fillRect(0,0,R*2,R*2);return c}
function lc_mote(col,n){n=n||48;const h=n/2,[c,g]=lc_cv(n,n),q=g.createRadialGradient(h,h,0,h,h,h);
 q.addColorStop(0,'#ffffffff');q.addColorStop(.12,col+'ff');q.addColorStop(.4,col+'55');q.addColorStop(1,col+'00');g.fillStyle=q;g.fillRect(0,0,n,n);return c}
/* layout shared by the still layer and the live glows */
const LC_LAMP={x:700,y:166};/* the lamp in the lantern room */
const LC_MOON={x:1090,y:104,r:34};
const LC_LANT=[{x:236,y:552,s:.95,hang:1},{x:588,y:516,s:1}];/* pier lanterns: hanging from an arm / sitting on the post */
const LC_GLOWS=[[616,346,'#ffb44a'],[708,354,'#ffb44a'],[556,398,'#ffb44a'],[428,452,'#ffb44a'],[318,512,'#ffb44a']];/* cottage window, tower door, stair lamps */
const LC_WRECK={x:1062,y:556};
const LC_BOTTLE={x:1128,y:652};
/* filled rock with a coloured rim light (offset dx,dy picks the lit side) and an outline */
function lc_rock(g,p,cA,cB,lw,rim,ra,dx,dy){let y0=1e9,y1=-1e9;for(let i=1;i<p.length;i+=2){y0=Math.min(y0,p[i]);y1=Math.max(y1,p[i])}
 fkPath(g,p);g.fillStyle=fkLin(g,0,y0,0,y1,[cA,cB]);g.fill();
 if(rim){g.save();fkPath(g,p);g.clip();g.translate(dx,dy);fkPath(g,p);g.strokeStyle=rim;g.globalAlpha=(ra||.5)*.45;g.lineWidth=9;g.stroke();g.globalAlpha=(ra||.5)*.8;g.lineWidth=3;g.translate(-dx*.5,-dy*.5);fkPath(g,p);g.stroke();g.restore()}
 if(lw){fkPath(g,p);g.lineWidth=lw;g.strokeStyle=FKO;g.lineJoin='round';g.stroke()}}
/* rock texture inside a path: strata cracks and soft lumps */
function lc_tex(g,p,x0,y0,x1,y1,n,seed,dark,lite){g.save();fkPath(g,p);g.clip();g.lineCap='round';
 for(let i=0;i<n;i++){const x=x0+lc_r(seed+i)*(x1-x0),y=y0+lc_r(seed+i+.5)*(y1-y0),w=20+lc_r(seed+i+.7)*60;
  g.globalAlpha=.16+lc_r(seed+i+.9)*.18;g.fillStyle=lite;g.beginPath();g.ellipse(x,y,w*.5,w*.18,(lc_r(seed+i+.3)-.5)*.5,0,TAU);g.fill();
  g.globalAlpha=.35;g.strokeStyle=dark;g.lineWidth=1.6+lc_r(seed+i+.2)*1.4;g.beginPath();g.moveTo(x-w*.5,y+w*.2);g.quadraticCurveTo(x,y+w*.2+(lc_r(seed+i+.4)-.5)*14,x+w*.5,y+w*.24);g.stroke()}
 g.restore();g.globalAlpha=1}
/* a craggy outline: walk a list of anchor points and add a little jitter between them */
function lc_crag(A,step,amp,seed){const p=[];for(let i=0;i<A.length-2;i+=2){const ax=A[i],ay=A[i+1],bx=A[i+2],by=A[i+3],n=Math.max(1,Math.round(Math.hypot(bx-ax,by-ay)/step));
  for(let k=0;k<n;k++){const u=k/n,j=k?(lc_r(seed+i*7+k)-.5)*amp:0;p.push(ax+(bx-ax)*u+j*.4,ay+(by-ay)*u+j)}}p.push(A[A.length-2],A[A.length-1]);return p}
/* moonlit facet on a cliff face: soft fill, lit top edge, dark crack below */
function lc_facet(g,p,lite,a){g.save();fkPath(g,p);g.fillStyle=lite;g.globalAlpha=(a||1)*.13;g.fill();
 g.globalAlpha=(a||1)*.45;g.strokeStyle=lite;g.lineWidth=2.4;g.beginPath();g.moveTo(p[0],p[1]);g.quadraticCurveTo(p[2],p[3],p[4],p[5]);g.stroke();
 g.globalAlpha=.6;g.strokeStyle='#070820';g.lineWidth=2.4;g.beginPath();g.moveTo(p[4],p[5]);g.lineTo(p[6],p[7]);g.quadraticCurveTo(p[8],p[9],p[0],p[1]);g.stroke();g.restore()}
/* ---------- the lighthouse ---------- */
const LC_T=198,LC_B=368;/* tower top (gallery deck) and base */
/* lantern room, gallery rail and roof; glass=false draws only the frame (laid over the beams so they seem to come through the glass) */
function lc_lampTop(g,glass){const X=LC_LAMP.x,T=LC_T;
 if(glass){g.fillStyle=fkLin(g,0,T-58,0,T-6,['#fff8dc','#ffe08a','#ffbf4a','#e8902a']);g.fillRect(X-24,T-58,48,52);
  g.fillStyle='#fffbe8';g.beginPath();g.ellipse(X,T-32,9,12,0,0,TAU);g.fill();g.fillStyle='#ffffffaa';g.fillRect(X-20,T-54,6,40);}
 /* the old keeper, still at his post: a faint silhouette with cap and pipe beside the lamp */
  g.save();g.globalAlpha=.62;g.fillStyle='#3a1608';g.beginPath();g.ellipse(X+14,T-22,9,12,0,Math.PI,TAU);g.fill();g.beginPath();g.arc(X+14,T-40,5,0,TAU);g.fill();g.fillRect(X+7,T-46,14,2.6);g.fillRect(X+9,T-50,10,5);g.fillRect(X+3,T-39,6,2);g.fillRect(X+2,T-42,2.4,4);g.restore();
 /* mullions and frame */
 g.strokeStyle='#2a1a1a';g.lineWidth=2.6;g.beginPath();[X-12,X+12].forEach(x=>{g.moveTo(x,T-58);g.lineTo(x,T-6)});g.moveTo(X-24,T-32);g.lineTo(X+24,T-32);g.stroke();
 g.lineWidth=3;g.strokeStyle=FKO;g.strokeRect(X-24,T-58,48,52);
 /* roof: a little dome with a moonlit right side, vent ball, spike and weathervane */
 g.beginPath();g.moveTo(X-32,T-56);g.quadraticCurveTo(X-28,T-84,X,T-92);g.quadraticCurveTo(X+28,T-84,X+32,T-56);g.closePath();
 g.fillStyle=fkLin(g,X-32,0,X+32,0,['#2a1424','#5a2a36','#8a4650','#c8848a']);g.fill();g.lineWidth=3;g.strokeStyle=FKO;g.stroke();
 g.save();g.clip();g.strokeStyle='#ffffff30';g.lineWidth=2;g.beginPath();g.moveTo(X+8,T-89);g.quadraticCurveTo(X+24,T-80,X+27,T-60);g.stroke();g.strokeStyle='#00000040';[X-14,X+12].forEach(x=>{g.beginPath();g.moveTo(X,T-92);g.quadraticCurveTo(x,T-80,x*1+(x-X)*.6,T-56);g.stroke()});g.restore();
 g.fillStyle=fkLin(g,0,T-62,0,T-54,['#7a3a44','#3a1824']);g.fillRect(X-36,T-62,72,7);g.lineWidth=2.4;g.strokeStyle=FKO;g.strokeRect(X-36,T-62,72,7);
 g.beginPath();g.arc(X,T-97,6,0,TAU);g.fillStyle=fkRad(g,X,T-97,6,['#ffe6a0','#c8903a','#6a4218']);g.fill();g.lineWidth=2.2;g.strokeStyle=FKO;g.stroke();
 g.strokeStyle=FKO;g.lineWidth=2.6;g.beginPath();g.moveTo(X,T-103);g.lineTo(X,T-124);g.stroke();
 g.fillStyle='#c8903a';g.beginPath();g.moveTo(X-12,T-116);g.lineTo(X+8,T-116);g.lineTo(X+8,T-121);g.lineTo(X+15,T-115);g.lineTo(X+8,T-109);g.lineTo(X+8,T-114);g.lineTo(X-12,T-114);g.closePath();g.fill();g.lineWidth=1.6;g.strokeStyle=FKO;g.stroke();
 /* gallery deck with corbels and the railing */
 g.fillStyle=fkLin(g,0,T-6,0,T+8,['#4a4a6e','#22223e']);g.fillRect(X-50,T-6,100,12);g.lineWidth=3;g.strokeStyle=FKO;g.strokeRect(X-50,T-6,100,12);
 g.fillStyle='#2a2a46';for(let i=-3;i<=3;i++){const x=X+i*12;g.beginPath();g.moveTo(x-5,T+6);g.lineTo(x+5,T+6);g.lineTo(x,T+16);g.closePath();g.fill();g.lineWidth=1.6;g.stroke()}
 g.strokeStyle=FKO;g.lineWidth=3.4;g.beginPath();g.moveTo(X-48,T-26);g.lineTo(X+48,T-26);for(let i=0;i<=8;i++){const x=X-48+i*12;g.moveTo(x,T-26);g.lineTo(x,T-6)}g.stroke();
 g.strokeStyle='#8a8ab0';g.lineWidth=1.6;g.beginPath();g.moveTo(X-48,T-26);g.lineTo(X+48,T-26);for(let i=0;i<=8;i++){const x=X-48+i*12;g.moveTo(x,T-25);g.lineTo(x,T-7)}g.stroke();
 g.strokeStyle='#e8ecff';g.globalAlpha=.5;g.beginPath();g.moveTo(X+10,T-27);g.lineTo(X+48,T-27);g.stroke();g.globalAlpha=1}
function lc_lighthouse(g){const X=LC_LAMP.x,T=LC_T,B=LC_B,wb=44,wt=30;
 /* keeper's cottage leaning on the tower */
 {const x0=592,x1=660,y=B+2,h=40;g.fillStyle=fkLin(g,x0,0,x1,0,['#3a3a62','#5a5a86']);g.fillRect(x0,y-h,x1-x0,h);g.lineWidth=3;g.strokeStyle=FKO;g.strokeRect(x0,y-h,x1-x0,h);
  g.strokeStyle='#00000030';g.lineWidth=1.4;for(let k=1;k<4;k++){g.beginPath();g.moveTo(x0,y-h+k*10);g.lineTo(x1,y-h+k*10);g.stroke()}
  g.fillStyle=fkLin(g,0,y-h-8,0,y-h,['#3a2a3a','#24182a']);g.fillRect(598,y-h-30,10,24);g.lineWidth=2.4;g.strokeStyle=FKO;g.strokeRect(598,y-h-30,10,24);
  g.beginPath();g.moveTo(x0-8,y-h+2);g.lineTo(624,y-h-28);g.lineTo(x1+6,y-h+2);g.closePath();g.fillStyle=fkLin(g,0,y-h-28,0,y-h,['#6a3440','#3a1a28']);g.fill();g.lineWidth=3;g.strokeStyle=FKO;g.stroke();
  g.strokeStyle='#ffffff26';g.lineWidth=2;g.beginPath();g.moveTo(626,y-h-25);g.lineTo(x1+3,y-h);g.stroke();
  /* a faintly lit window: someone still keeps the fire */
  fkGlow(g,616,y-22,30,'#ffb44a',.4);g.fillStyle=fkLin(g,0,y-30,0,y-14,['#ffe6a0','#e89a3a']);g.fillRect(608,y-30,16,16);g.lineWidth=2.4;g.strokeStyle='#2a1a1a';g.strokeRect(608,y-30,16,16);g.beginPath();g.moveTo(616,y-30);g.lineTo(616,y-14);g.moveTo(608,y-22);g.lineTo(624,y-22);g.stroke();
  g.fillStyle='#24182a';g.fillRect(636,y-26,14,26);g.lineWidth=2.2;g.strokeStyle=FKO;g.strokeRect(636,y-26,14,26)}
 /* tower: tapered, cream with two faded crimson bands, shaded as a cylinder lit by the moon from the right */
 const tw=y=>wt+(wb-wt)*(y-T)/(B-T),tp=()=>{g.beginPath();g.moveTo(X-wb,B);g.lineTo(X-wt,T);g.lineTo(X+wt,T);g.lineTo(X+wb,B);g.closePath()};
 tp();g.fillStyle='#d6d4e6';g.fill();g.save();tp();g.clip();
 g.fillStyle='#9a3446';[[212,236],[262,288],[316,342]].forEach(([a,b])=>{g.beginPath();g.moveTo(X-tw(a)-2,a);g.lineTo(X+tw(a)+2,a);g.lineTo(X+tw(b)+2,b);g.lineTo(X-tw(b)-2,b);g.closePath();g.fill()});
 g.strokeStyle='#00000022';g.lineWidth=1.2;for(let y=T+12;y<B;y+=11){g.beginPath();g.moveTo(X-wb,y);g.lineTo(X+wb,y);g.stroke()}
 g.fillStyle=fkLin(g,X-wb,0,X+wb,0,['#0a0a2ae0','#0a0a2a9a','#0a0a2a40','#0a0a2a08','#f0f4ff38','#0a0a2a70']);g.fillRect(X-wb,T,wb*2,B-T);
 g.fillStyle=fkLin(g,0,T,0,T+70,['#ffcf6a50','#ffcf6a00']);g.fillRect(X-wb,T,wb*2,70);
 g.fillStyle=fkLin(g,0,B-60,0,B,['#10183a00','#10183a90']);g.fillRect(X-wb,B-60,wb*2,60);
 /* weathering streaks */
 g.strokeStyle='#2a2a4a';g.globalAlpha=.25;g.lineWidth=2;[[X-14,T+14,46],[X+18,T+40,30],[X-4,262,40],[X+8,330,28]].forEach(([x,y,l])=>{g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+2,y+l*.5,x-1,y+l);g.stroke()});g.globalAlpha=1;
 g.restore();tp();g.lineWidth=3.5;g.strokeStyle=FKO;g.stroke();
 /* windows: one dark, one glowing faintly gold */
 const win=(x,y,lit)=>{if(lit)fkGlow(g,x,y,22,'#ffb44a',.45);g.beginPath();g.moveTo(x-5,y+8);g.lineTo(x-5,y-3);g.arc(x,y-3,5,Math.PI,0);g.lineTo(x+5,y+8);g.closePath();g.fillStyle=lit?fkLin(g,0,y-8,0,y+8,['#ffe6a0','#e8902a']):'#14142e';g.fill();g.lineWidth=2.2;g.strokeStyle=FKO;g.stroke()};
 win(X+6,252,0);win(X-8,306,1);
 /* door at the base */
 {const x=X+12,y=B;fkGlow(g,x,y-14,40,'#ffb44a',.35);g.beginPath();g.moveTo(x-9,y);g.lineTo(x-9,y-18);g.arc(x,y-18,9,Math.PI,0);g.lineTo(x+9,y);g.closePath();g.fillStyle=fkLin(g,0,y-27,0,y,['#ffd88a','#c8702a']);g.fill();g.lineWidth=2.6;g.strokeStyle='#2a1a1a';g.stroke();g.beginPath();g.moveTo(x,y-27);g.lineTo(x,y);g.stroke()}
 /* the lamp: warm halo around the lantern room (the beams and breathing glow are live) */
 fkGlow(g,X,LC_LAMP.y,190,'#ffb84a',.22);fkGlow(g,X,LC_LAMP.y,80,'#ffe6a0',.4);
 lc_lampTop(g,true)}
/* ---------- the shipwreck bow, anchor and chain ---------- */
function lc_wreck(g){const W=LC_WRECK,px=W.x+50,py=W.y,th=.42,z=.88,cs=Math.cos(th)*z,sn=Math.sin(th)*z,P=(x,y)=>[px+x*cs-y*sn,py+x*sn+y*cs];
 /* the bow is drawn in its own frame (pointing left) and tilted up out of the sea; everything under the waterline is cut away */
 const hull=()=>{g.beginPath();g.moveTo(14,-34);g.quadraticCurveTo(-70,-44,-178,-56);g.quadraticCurveTo(-170,-10,-142,22);g.quadraticCurveTo(-70,38,14,38);g.lineTo(22,22);g.lineTo(6,10);g.lineTo(24,-4);g.lineTo(8,-16);g.lineTo(20,-26);g.closePath()};
 g.save();g.beginPath();g.rect(W.x-280,0,460,W.y+1);g.clip();g.translate(px,py);g.rotate(th);g.scale(z,z);
 /* exposed ribs behind the hull side at the break */
 g.lineCap='round';[[4,-30],[-14,-34],[-32,-36]].forEach(([x,y],i)=>{g.strokeStyle=FKO;g.lineWidth=7;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+16,y-18,x+12-i*2,y-40+i*6);g.stroke();g.strokeStyle='#4a3a4a';g.lineWidth=3.4;g.stroke()});
 hull();g.fillStyle=fkLin(g,0,-56,0,38,['#6a5a6a','#3e3044','#1e1628']);g.fill();
 g.save();hull();g.clip();g.strokeStyle='#120c1e';g.lineWidth=2;for(let k=1;k<7;k++){const d=k*12;g.beginPath();g.moveTo(24,-34+d);g.quadraticCurveTo(-70,-44+d*1.05,-180+d*.5,-56+d*1.1);g.stroke()}
 g.strokeStyle='#b8c8f0';g.globalAlpha=.45;g.lineWidth=3;g.beginPath();g.moveTo(10,-31);g.quadraticCurveTo(-70,-41,-174,-53);g.stroke();g.globalAlpha=1;
 g.fillStyle='#8a9ab8';for(let k=0;k<18;k++){const bx=-150+lc_r(k+300)*160,by=4+lc_r(k+301)*30;g.globalAlpha=.55;g.beginPath();g.arc(bx,by,1.4+lc_r(k+302)*2,0,TAU);g.fill()}g.globalAlpha=1;
 g.fillStyle='#000000';g.globalAlpha=.25;g.fillRect(-190,6,220,40);g.globalAlpha=1;g.restore();
 hull();g.lineWidth=3;g.strokeStyle=FKO;g.stroke();
 /* gunwale rail, hawse hole, a snapped mast with a tattered scrap of sail */
 g.strokeStyle=FKO;g.lineWidth=6;g.beginPath();g.moveTo(12,-36);g.quadraticCurveTo(-70,-46,-176,-58);g.stroke();g.strokeStyle='#7a6a72';g.lineWidth=2.6;g.stroke();
 g.beginPath();g.arc(-150,-30,5,0,TAU);g.fillStyle='#0a0614';g.fill();g.lineWidth=2;g.strokeStyle='#8a7a6a';g.stroke();
 g.strokeStyle=FKO;g.lineWidth=7;g.beginPath();g.moveTo(-178,-56);g.lineTo(-226,-58);g.stroke();g.strokeStyle='#5a4a52';g.lineWidth=3.2;g.stroke();
 g.strokeStyle=FKO;g.lineWidth=9;g.beginPath();g.moveTo(-60,-44);g.lineTo(-66,-142);g.stroke();g.strokeStyle='#5a4a52';g.lineWidth=5;g.stroke();
 g.fillStyle='#5a4a52';g.beginPath();g.moveTo(-70,-140);g.lineTo(-68,-154);g.lineTo(-64,-146);g.lineTo(-60,-152);g.lineTo(-61,-138);g.closePath();g.fill();g.lineWidth=2;g.strokeStyle=FKO;g.stroke();
 g.strokeStyle='#8a7a6a';g.lineWidth=1.6;g.beginPath();g.moveTo(-66,-132);g.quadraticCurveTo(-150,-100,-224,-60);g.moveTo(-64,-120);g.quadraticCurveTo(-20,-90,6,-38);g.stroke();
 g.fillStyle='#a8a4b8';g.globalAlpha=.85;g.beginPath();g.moveTo(-64,-128);g.quadraticCurveTo(-40,-122,-30,-104);g.lineTo(-38,-100);g.lineTo(-34,-90);g.quadraticCurveTo(-52,-98,-64,-104);g.closePath();g.fill();g.globalAlpha=1;g.lineWidth=2;g.strokeStyle=FKO;g.stroke();
 g.restore();
 /* the anchor hangs from the hawse on its chain, a second length of chain trails into the sea */
 const[hx,hy]=P(-150,-30),ax=hx-2,ay=hy+50;
 g.strokeStyle=FKO;g.lineWidth=3.6;for(let k=0;k<6;k++){g.beginPath();g.ellipse(hx-k*.3,hy+6+k*6.4,2.4,3.8,0,0,TAU);g.stroke()}
 g.strokeStyle='#9a9ab0';g.lineWidth=1.6;for(let k=0;k<6;k++){g.beginPath();g.ellipse(hx-k*.3,hy+6+k*6.4,2.4,3.8,0,0,TAU);g.stroke()}
 g.strokeStyle=FKO;g.lineWidth=7;g.beginPath();g.moveTo(ax,ay-4);g.lineTo(ax,ay+30);g.moveTo(ax-11,ay+5);g.lineTo(ax+11,ay+5);g.moveTo(ax-16,ay+18);g.quadraticCurveTo(ax,ay+38,ax+16,ay+18);g.moveTo(ax-16,ay+18);g.lineTo(ax-20,ay+12);g.moveTo(ax+16,ay+18);g.lineTo(ax+20,ay+12);g.stroke();
 g.strokeStyle='#6a6a8a';g.lineWidth=3.4;g.stroke();g.strokeStyle='#c8d0f0';g.globalAlpha=.5;g.lineWidth=1.4;g.beginPath();g.moveTo(ax+1.4,ay);g.lineTo(ax+1.4,ay+26);g.stroke();g.globalAlpha=1;
 g.beginPath();g.arc(ax,ay-7,4,0,TAU);g.lineWidth=4.6;g.strokeStyle=FKO;g.stroke();g.lineWidth=2;g.strokeStyle='#6a6a8a';g.stroke();
 g.strokeStyle='#5a5a76';g.lineWidth=1.8;for(let k=0;k<5;k++){g.beginPath();g.ellipse(ax+6+k*5,ay+36+k*3.4,2.4,3.4,.8,0,TAU);g.stroke()}}
/* ---------- the pier ---------- */
function lc_pier(g){const D=FSDOCK;
 /* posts into the water, crusted with barnacles and weed */
 [214,300,430,512,596].forEach((x,i)=>{const h=100-(i%2)*18;g.fillStyle=fkLin(g,x-9,0,x+9,0,['#7a6a62','#3a2e2e']);g.fillRect(x-9,D.y,18,h);g.lineWidth=2.5;g.strokeStyle=FKO;g.strokeRect(x-9,D.y,18,h);
  g.fillStyle='#1e5a4a';g.fillRect(x-9,D.y+h-26,18,22);g.fillStyle='#b8c0d8';for(let k=0;k<5;k++){g.beginPath();g.arc(x-6+lc_r(k+i*9)*12,D.y+h-28+lc_r(k+i*9+3)*20,1.6,0,TAU);g.fill()}
  g.strokeStyle='#c8a46a';g.lineWidth=2.4;for(let k=0;k<3;k++){g.beginPath();g.moveTo(x-9,D.y+20+k*6);g.lineTo(x+9,D.y+24+k*6);g.stroke()}
  g.strokeStyle='#bfe0ff';g.globalAlpha=.3;g.lineWidth=2;g.beginPath();g.ellipse(x,D.y+h-4,18,4,0,0,TAU);g.stroke();g.globalAlpha=1});
 /* cross bracing under the deck */
 g.strokeStyle=FKO;g.lineWidth=6;g.beginPath();g.moveTo(300,D.y+10);g.lineTo(430,D.y+64);g.moveTo(430,D.y+10);g.lineTo(512,D.y+60);g.stroke();g.strokeStyle='#4a3a36';g.lineWidth=3;g.stroke();
 /* deck planks: weathered grey-brown, one plank missing, a couple warped */
 const top=()=>{g.beginPath();g.moveTo(D.x0-20,D.y-30);g.lineTo(D.x1,D.y-22);g.lineTo(D.x1+8,D.y+8);g.lineTo(D.x0-20,D.y+14);g.closePath()};
 top();g.fillStyle=fkLin(g,0,D.y-30,0,D.y+14,['#9a8678','#6a5650']);g.fill();
 g.save();top();g.clip();g.strokeStyle='#2e2420';g.lineWidth=1.6;for(let i=1;i<14;i++){const x=D.x0-20+i*(D.x1-D.x0+20)/14;g.beginPath();g.moveTo(x,D.y-30+i*.6);g.lineTo(x+2,D.y+12);g.stroke()}
 for(let i=0;i<14;i++){const x=D.x0-12+i*(D.x1-D.x0+20)/14;g.fillStyle='#ffffff16';g.fillRect(x,D.y-24+i*.6,10,2);g.fillStyle='#1a1008';g.beginPath();g.arc(x+12,D.y-20+i*.6,1.2,0,TAU);g.arc(x+12,D.y+6,1.2,0,TAU);g.fill()}
 /* the gap of a missing plank, showing the water below */
 {const i=3,x=D.x0-20+i*(D.x1-D.x0+20)/14;g.fillStyle='#0c1a34';g.beginPath();g.moveTo(x+2,D.y-28);g.lineTo(x+32,D.y-27);g.lineTo(x+34,D.y+12);g.lineTo(x+3,D.y+13);g.closePath();g.fill();g.strokeStyle='#7ab8e0';g.globalAlpha=.4;g.lineWidth=1.4;g.beginPath();g.moveTo(x+8,D.y-2);g.lineTo(x+26,D.y-2);g.stroke();g.globalAlpha=1}
 g.fillStyle='#ffcf6a';g.globalAlpha=.06;g.fillRect(D.x0-20,D.y-30,D.x1-D.x0+30,10);g.restore();g.globalAlpha=1;
 top();g.lineWidth=3;g.strokeStyle=FKO;g.stroke();
 g.strokeStyle='#ffffff26';g.lineWidth=2;g.beginPath();g.moveTo(D.x0-18,D.y-27);g.lineTo(D.x1-2,D.y-19);g.stroke();
 g.fillStyle='#3a2c28';g.beginPath();g.moveTo(D.x0-20,D.y+14);g.lineTo(D.x1+8,D.y+8);g.lineTo(D.x1+8,D.y+24);g.lineTo(D.x0-20,D.y+30);g.closePath();g.fill();g.lineWidth=2.5;g.strokeStyle=FKO;g.stroke();
 g.strokeStyle='#d8b878';g.lineWidth=2.4;[200,330,460].forEach(x=>{g.beginPath();g.moveTo(x,D.y+11);g.lineTo(x+6,D.y+27);g.moveTo(x+6,D.y+11);g.lineTo(x,D.y+27);g.stroke()});
 /* a draped fishing net hanging over the front beam */
 g.strokeStyle='#8a9a8a';g.globalAlpha=.75;g.lineWidth=1.3;g.beginPath();for(let k=0;k<9;k++){const x=372+k*10;g.moveTo(x,D.y+18);g.quadraticCurveTo(x+4,D.y+40,x+2,D.y+52-Math.abs(k-4)*3)}for(let j=0;j<3;j++){g.moveTo(372,D.y+26+j*8);g.quadraticCurveTo(412,D.y+34+j*9,454,D.y+26+j*8)}g.stroke();g.globalAlpha=1;
 g.fillStyle='#e8c070';[[384,D.y+44],[420,D.y+52],[446,D.y+40]].forEach(([x,y])=>{g.beginPath();g.arc(x,y,3.2,0,TAU);g.fill();g.lineWidth=1.4;g.strokeStyle=FKO;g.stroke()});
 /* coiled rope, a lobster pot and a crate */
 g.save();g.translate(176,628);g.scale(1,.42);g.lineWidth=5;[16,11,6].forEach(r=>{g.strokeStyle=FKO;g.beginPath();g.arc(0,0,r,0,TAU);g.stroke()});g.lineWidth=3;g.strokeStyle='#d8b878';[16,11,6].forEach(r=>{g.beginPath();g.arc(0,0,r,0,TAU);g.stroke()});g.restore();
 {const x=318,y=634;g.beginPath();g.moveTo(x-22,y);g.lineTo(x-22,y-18);g.quadraticCurveTo(x,y-36,x+22,y-18);g.lineTo(x+22,y);g.closePath();g.fillStyle='#3a2c28';g.fill();
  g.save();g.clip();g.strokeStyle='#b89a6a';g.lineWidth=1.6;for(let k=-3;k<=3;k++){g.beginPath();g.moveTo(x+k*7,y);g.quadraticCurveTo(x+k*6,y-28,x+k*2,y-30);g.stroke()}for(let k=0;k<3;k++){g.beginPath();g.moveTo(x-22,y-4-k*8);g.quadraticCurveTo(x,y-10-k*9,x+22,y-4-k*8);g.stroke()}g.restore();
  g.lineWidth=2.6;g.strokeStyle=FKO;g.stroke();g.fillStyle='#ffd45a';g.beginPath();g.arc(x+3,y-12,3,0,TAU);g.fill()}
 {const x=150,y=600;g.fillStyle=fkLin(g,x,y,x+52,y+48,['#8a6a4a','#5a4030']);g.fillRect(x,y,52,46);g.lineWidth=3;g.strokeStyle=FKO;g.strokeRect(x,y,52,46);g.strokeStyle='#3a2414';g.lineWidth=2.4;g.beginPath();g.moveTo(x,y+15);g.lineTo(x+52,y+15);g.moveTo(x,y+31);g.lineTo(x+52,y+31);g.stroke();
  g.fillStyle='#d8c8a0';g.globalAlpha=.6;g.beginPath();g.arc(x+26,y+23,6,0,TAU);g.fill();g.globalAlpha=1}
 /* lantern posts and the rope rail (the lantern bodies are drawn here; the flicker is live) */
 [D.x0+110,D.x1-12].forEach(x=>{g.fillStyle=fkLin(g,x-7,0,x+7,0,['#8a7a6e','#3a2e2a']);g.fillRect(x-7,D.y-120,14,110);g.lineWidth=2.5;g.strokeStyle=FKO;g.strokeRect(x-7,D.y-120,14,110);
  g.strokeStyle='#d8b878';g.lineWidth=2.2;for(let k=0;k<3;k++){g.beginPath();g.moveTo(x-7,D.y-40+k*5);g.lineTo(x+7,D.y-37+k*5);g.stroke()}});
 /* the hanging arm on the left post */
 {const x=D.x0+110,y=D.y-118;g.strokeStyle=FKO;g.lineWidth=6;g.beginPath();g.moveTo(x,y);g.lineTo(x-34,y);g.moveTo(x,y+18);g.lineTo(x-20,y);g.stroke();g.strokeStyle='#5a4a40';g.lineWidth=3;g.stroke();
  g.strokeStyle='#2a1a1a';g.lineWidth=2;g.beginPath();g.moveTo(x-24,y);g.lineTo(x-24,y+14);g.stroke()}
 g.strokeStyle=FKO;g.lineWidth=5;g.beginPath();g.moveTo(D.x0+110,D.y-96);g.quadraticCurveTo((D.x0+D.x1)/2+50,D.y-60,D.x1-12,D.y-96);g.stroke();g.strokeStyle='#d8b878';g.lineWidth=3;g.stroke();
 LC_LANT.forEach(L=>lc_lantern(g,L.x,L.y,L.s))}
/* a ship lantern body (the halo flickers live) */
function lc_lantern(g,x,y,s){g.save();g.translate(x,y);g.scale(s,s);
 g.beginPath();g.arc(0,-40,4,0,TAU);g.strokeStyle='#4a3440';g.lineWidth=2.4;g.stroke();
 g.fillStyle='#2a2430';g.beginPath();g.moveTo(-13,-26);g.quadraticCurveTo(-12,-36,0,-37);g.quadraticCurveTo(12,-36,13,-26);g.closePath();g.fill();g.lineWidth=2.5;g.strokeStyle=FKO;g.stroke();
 g.fillStyle=fkLin(g,0,-24,0,14,['#fff4c0','#ffc85a','#f08a2a']);g.beginPath();g.moveTo(-11,-24);g.quadraticCurveTo(-15,-6,-11,12);g.lineTo(11,12);g.quadraticCurveTo(15,-6,11,-24);g.closePath();g.fill();
 g.strokeStyle='#2a2430';g.lineWidth=3;g.stroke();g.lineWidth=2.2;g.beginPath();g.moveTo(-13,-12);g.lineTo(13,-12);g.moveTo(-13,2);g.lineTo(13,2);g.moveTo(0,-24);g.lineTo(0,12);g.stroke();
 g.fillStyle='#fffbe8';g.beginPath();g.ellipse(0,-4,3,6,0,0,TAU);g.fill();
 g.fillStyle='#2a2430';g.fillRect(-14,12,28,6);g.lineWidth=2.2;g.strokeStyle=FKO;g.strokeRect(-14,12,28,6);g.restore()}
/* two gulls asleep on a mooring piling, heads tucked in */
function lc_gulls(g){const x=652,y=604;
 g.fillStyle=fkLin(g,x-11,0,x+11,0,['#7a6a62','#3a2e2e']);g.fillRect(x-11,y,22,96);g.lineWidth=2.6;g.strokeStyle=FKO;g.strokeRect(x-11,y,22,96);
 g.beginPath();g.ellipse(x,y,11,4,0,0,TAU);g.fillStyle='#9a8a7a';g.fill();g.stroke();
 g.fillStyle='#1e5a4a';g.fillRect(x-11,y+66,22,24);g.strokeStyle='#bfe0ff';g.globalAlpha=.3;g.lineWidth=2;g.beginPath();g.ellipse(x,y+92,20,4.4,0,0,TAU);g.stroke();g.globalAlpha=1;
 g.strokeStyle='#c8a46a';g.lineWidth=2.4;for(let k=0;k<3;k++){g.beginPath();g.moveTo(x-11,y+16+k*6);g.lineTo(x+11,y+20+k*6);g.stroke()}
 const gull=(gx,gy,s,f)=>{g.save();g.translate(gx,gy);g.scale(f*s,s);
  g.fillStyle='#e8a040';g.fillRect(-4,-1,2.4,5);g.fillRect(2,-1,2.4,5);
  g.beginPath();g.ellipse(0,-12,15,11,0,0,TAU);g.fillStyle=fkRad(g,0,-12,15,['#ffffff','#e8ecf6','#a8b0c8']);g.fill();g.lineWidth=2.4;g.strokeStyle=FKO;g.stroke();
  g.beginPath();g.moveTo(-12,-15);g.quadraticCurveTo(2,-22,16,-12);g.quadraticCurveTo(22,-8,26,-10);g.quadraticCurveTo(18,-2,4,-5);g.quadraticCurveTo(-6,-6,-12,-15);g.closePath();g.fillStyle=fkLin(g,0,-20,0,-4,['#8a92aa','#5a6280']);g.fill();g.lineWidth=2;g.stroke();
  g.fillStyle='#2a2a3a';g.beginPath();g.moveTo(22,-10);g.lineTo(28,-11);g.lineTo(25,-6);g.closePath();g.fill();
  g.beginPath();g.arc(-10,-20,8,0,TAU);g.fillStyle=fkRad(g,-10,-20,8,['#ffffff','#e8ecf6','#b8c0d4']);g.fill();g.lineWidth=2.2;g.strokeStyle=FKO;g.stroke();
  g.strokeStyle='#2a2a3a';g.lineWidth=1.6;g.beginPath();g.arc(-12,-20,2.4,.2,Math.PI-.2);g.stroke();
  g.fillStyle='#f0b040';g.beginPath();g.moveTo(-4,-20);g.lineTo(3,-17);g.lineTo(-4,-15);g.closePath();g.fill();g.lineWidth=1.4;g.strokeStyle=FKO;g.stroke();g.restore()};
 gull(x-4,y-1,.78,1);gull(x+30,y+10,.62,-1)}
/* ---------- the still layer ---------- */
function lc_bg(g){g.lineJoin='round';g.lineCap='round';try{lc_crop()}catch(e){}
 /* night sky: deep indigo down to a misty sea-blue horizon */
 g.fillStyle=fkLin(g,0,0,0,FSW_Y,['#050822','#0a1238','#12225a','#1c3a6e','#2e5a82']);g.fillRect(0,0,1600,FSW_Y+4);
 fkGlow(g,LC_MOON.x,LC_MOON.y,300,'#5a78d0',.2);fkGlow(g,1200,470,460,'#4a7ab0',.16);fkGlow(g,LC_LAMP.x,LC_LAMP.y,420,'#c88a4a',.1);
 for(let i=0;i<240;i++){const x=lc_r(i+11)*1600,y=lc_r(i+211)*(FSW_Y-70),r=lc_r(i+411)<.07?1.8:lc_r(i+411)<.35?1.15:.7;g.globalAlpha=(.3+lc_r(i+611)*.65)*(y>360?.6:1);g.fillStyle=lc_r(i+811)<.15?'#ffe8c0':lc_r(i+811)<.3?'#c8e6ff':'#f2eeff';g.beginPath();g.arc(x,y,r,0,TAU);g.fill()}g.globalAlpha=1;
 /* a faint milky band across the sky */
 g.save();g.translate(1000,200);g.rotate(-.32);for(let i=0;i<8;i++){g.globalAlpha=.045;g.fillStyle=i%2?'#a8c0ff':'#c8b8ff';g.beginPath();g.ellipse((i-3.5)*90,(lc_r(i+40)-.5)*30,130,24+lc_r(i+44)*20,0,0,TAU);g.fill()}g.restore();g.globalAlpha=1;
 /* thin new-moon crescent */
 {const m=LC_MOON;fkGlow(g,m.x,m.y,120,'#e8f0ff',.22);fkGlow(g,m.x,m.y,54,'#f4f8ff',.25);
  const[C,c]=lc_cv(100,100);c.translate(50,50);c.beginPath();c.arc(0,0,m.r,0,TAU);c.fillStyle=fkRad(c,0,0,m.r,['#ffffff','#eef2ff','#c4d0f0']);c.fill();
  c.globalCompositeOperation='destination-out';c.beginPath();c.arc(-13,-6,m.r*.94,0,TAU);c.fill();g.drawImage(C,m.x-50,m.y-50)}
 /* soft cloud wisps */
 const cloud=(x,y,w,a,col)=>{g.save();g.globalAlpha=a;g.fillStyle=col||'#7a90d0';for(let i=0;i<6;i++){g.beginPath();g.ellipse(x+i*w*.18-w*.45,y+Math.sin(i*1.7)*5,w*.2,8+lc_r(i+x)*7,0,0,TAU);g.fill()}g.restore()};
 cloud(1180,160,300,.1);cloud(880,96,260,.07);cloud(380,140,340,.07);cloud(1420,300,360,.08);cloud(1000,330,280,.06,'#c8a070');
 /* distant cloud bank on the horizon */
 g.fillStyle='#24467a';g.globalAlpha=.55;g.beginPath();g.moveTo(860,FSW_Y);for(let x=860;x<=1600;x+=30)g.lineTo(x,FSW_Y-26-Math.sin(x*.012)*10-lc_r(x)*12);g.lineTo(1600,FSW_Y);g.fill();g.globalAlpha=1;
 /* sea stacks far out (pale with distance) and a natural arch */
 const stack=(x,w,h,col,rim)=>{const p=[x-w,FSW_Y+2,x-w*.8,FSW_Y-h*.5,x-w*.55,FSW_Y-h*.9,x-w*.1,FSW_Y-h,x+w*.35,FSW_Y-h*.92,x+w*.7,FSW_Y-h*.55,x+w,FSW_Y+2];g.beginPath();g.moveTo(p[0],p[1]);for(let i=2;i<p.length;i+=2)g.lineTo(p[i],p[i+1]);g.closePath();g.fillStyle=col;g.fill();
  g.save();g.clip();g.strokeStyle=rim;g.globalAlpha=.5;g.lineWidth=3;g.beginPath();g.moveTo(x-w*.1+3,FSW_Y-h+2);g.lineTo(x+w*.35+2,FSW_Y-h*.92+3);g.lineTo(x+w*.7,FSW_Y-h*.55+3);g.stroke();g.restore();g.globalAlpha=1};
 stack(990,16,40,'#2a4672','#8ab0e0');stack(1022,10,24,'#2a4672','#8ab0e0');stack(1290,30,78,'#22406c','#8ab0e0');stack(1520,40,96,'#22406c','#8ab0e0');
 {const x=1390,y=FSW_Y;g.fillStyle='#22406c';g.beginPath();g.moveTo(x-60,y+2);g.lineTo(x-56,y-50);g.quadraticCurveTo(x-30,y-82,x+20,y-74);g.quadraticCurveTo(x+52,y-68,x+60,y-30);g.lineTo(x+64,y+2);g.lineTo(x+34,y+2);g.lineTo(x+32,y-26);g.quadraticCurveTo(x+6,y-52,x-22,y-30);g.lineTo(x-26,y+2);g.closePath();g.fill();
  g.strokeStyle='#8ab0e0';g.globalAlpha=.4;g.lineWidth=3;g.beginPath();g.moveTo(x-28,y-76);g.quadraticCurveTo(x+20,y-80,x+52,y-60);g.stroke();g.globalAlpha=1}
 /* horizon haze */
 g.fillStyle=fkLin(g,0,FSW_Y-70,0,FSW_Y,['#5a88b000','#5a88b030']);g.fillRect(0,FSW_Y-70,1600,70);
 /* ---- the headland: a cliff rising from the left, the lighthouse on its shoulder, dropping to the sea at the right ---- */
 const CL=lc_crag([-10,150,80,170,170,200,250,236,330,268,410,298,480,320,550,340,610,356,660,366,760,366,792,378,816,402,836,436,856,466,880,494,906,514,936,526,960,534,960,560,-10,560],26,9,5);
 lc_rock(g,CL,'#2c3466','#0c1030',3.5,'#9ab8ff',.55,-6,6);lc_tex(g,CL,0,150,960,560,60,7,'#06081e','#3a4a86');
 {let n=0;while(n<CL.length&&!(CL[n]>=796))n+=2;const top=CL.slice(0,n+2);g.save();fkPath(g,CL);g.clip();const tl=(w,c,a,dy)=>{g.globalAlpha=a;g.strokeStyle=c;g.lineWidth=w;g.beginPath();g.moveTo(top[0],top[1]+dy);for(let i=2;i<top.length;i+=2)g.lineTo(top[i],top[i+1]+dy);g.stroke()};
  tl(26,'#14302e',.85,4);tl(10,'#1e4a40',.9,0);tl(3,'#5a9a7a',.55,-3);g.restore();g.globalAlpha=1}
 /* moonlit facets on the cliff's sea face and strata on the slope */
 [[812,404,836,398,850,420,842,438,816,436],[842,452,866,448,880,474,870,490,846,484],[870,494,896,494,912,512,900,524,876,518],[760,384,792,380,806,402,796,420,764,414]].forEach(p=>lc_facet(g,p,'#a8c4ff'));
 [[440,352,488,344,520,356,510,370,452,370],[300,318,352,306,390,320,380,334,316,334],[560,408,616,398,650,412,640,428,570,426],[180,268,230,258,262,272,252,286,190,286],[680,430,730,424,760,438,750,452,690,452]].forEach(p=>lc_facet(g,p,'#7a90d8',.8));
 /* a little sea cave under the lighthouse, faintly lit from within */
 {const x=822,y=528;g.save();g.beginPath();g.moveTo(x-34,y);g.quadraticCurveTo(x-36,y-44,x-6,y-56);g.quadraticCurveTo(x+26,y-58,x+34,y-30);g.lineTo(x+36,y);g.closePath();g.fillStyle=fkLin(g,0,y-56,0,y,['#04050f','#0a1222','#14304a']);g.fill();g.clip();fkGlow(g,x,y-6,60,'#4ad8c8',.22);fkGlow(g,x+4,y-10,26,'#ffcf6a',.25);g.restore();
  g.beginPath();g.moveTo(x-34,y);g.quadraticCurveTo(x-36,y-44,x-6,y-56);g.quadraticCurveTo(x+26,y-58,x+34,y-30);g.lineTo(x+36,y);g.lineWidth=3;g.strokeStyle=FKO;g.stroke();
  g.strokeStyle='#a8c4ff';g.globalAlpha=.4;g.lineWidth=2;g.beginPath();g.moveTo(x-6,y-60);g.quadraticCurveTo(x+28,y-62,x+38,y-30);g.stroke();g.globalAlpha=1;
  [[x-20,y-52,5,12],[x+4,y-55,4,9],[x+22,y-44,4,10]].forEach(([sx,sy,w,h])=>{g.beginPath();g.moveTo(sx-w,sy);g.quadraticCurveTo(sx-w*.3,sy+h*.6,sx,sy+h);g.quadraticCurveTo(sx+w*.3,sy+h*.6,sx+w,sy);g.closePath();g.fillStyle='#1e2450';g.fill();g.lineWidth=1.8;g.strokeStyle=FKO;g.stroke()})}
 /* deep vertical cracks */
 g.save();fkPath(g,CL);g.clip();g.strokeStyle='#05061a';g.globalAlpha=.4;g.lineWidth=2.2;[[786,400,22,96],[720,380,-10,120],[606,372,12,150],[470,346,-14,170],[350,300,8,200],[848,470,-6,60]].forEach(([x,y,dx,l])=>{g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+dx,y+l*.5,x+dx*.4,y+l);g.stroke()});
 /* warm lamplight spilling over the clifftop around the lighthouse */
 g.globalAlpha=1;g.restore();fkGlow(g,LC_LAMP.x,LC_B,200,'#ffb44a',.14);
 /* grass along the clifftop */
 g.lineCap='round';for(let i=0;i<70;i++){const u=i/70,x=-10+u*900,y=x<660?150+(366-150)*Math.pow(Math.max(0,x+10)/670,.9):x<760?366:366+(x-760)*.5,h=8+lc_r(i+90)*14;if(x>800)break;g.strokeStyle=i%3?'#1a3a3a':'#24504a';g.lineWidth=2.4;g.beginPath();g.moveTo(x,y+3);g.quadraticCurveTo(x+3,y-h*.6,x+(lc_r(i+91)-.5)*10,y-h);g.stroke()}
 /* the old fence along the clifftop path */
 g.strokeStyle=FKO;g.lineWidth=3.6;g.beginPath();for(let k=0;k<5;k++){const x=520+k*26,y=338+k*6.5;g.moveTo(x,y);g.lineTo(x,y-18)}g.moveTo(520,326);g.lineTo(624,352);g.moveTo(520,334);g.lineTo(624,360);g.stroke();
 g.strokeStyle='#6a6a86';g.lineWidth=1.6;g.beginPath();for(let k=0;k<5;k++){const x=520+k*26,y=338+k*6.5;g.moveTo(x,y-1);g.lineTo(x,y-17)}g.moveTo(520,326);g.lineTo(624,352);g.stroke();
 /* the keeper's stair: wooden flights zig-zagging down the cliff to the cove, with little lamps */
 {const fl=[[630,370,520,410],[520,410,560,440],[560,440,420,470],[420,470,452,494],[452,494,300,540]];
  fl.forEach(([x0,y0,x1,y1])=>{const n=Math.max(3,Math.round(Math.hypot(x1-x0,y1-y0)/10));g.strokeStyle=FKO;g.lineWidth=8;g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.stroke();g.strokeStyle='#6a5650';g.lineWidth=4.6;g.stroke();
   g.strokeStyle='#9a8678';g.lineWidth=1.4;g.beginPath();for(let k=1;k<n;k++){const u=k/n,x=x0+(x1-x0)*u,y=y0+(y1-y0)*u;g.moveTo(x,y-3);g.lineTo(x,y+3)}g.stroke();
   /* handrail */
   g.strokeStyle=FKO;g.lineWidth=3;g.beginPath();g.moveTo(x0,y0-16);g.lineTo(x1,y1-16);for(let k=0;k<=2;k++){const u=k/2,x=x0+(x1-x0)*u,y=y0+(y1-y0)*u;g.moveTo(x,y);g.lineTo(x,y-16)}g.stroke();g.strokeStyle='#8a7a6e';g.lineWidth=1.4;g.beginPath();g.moveTo(x0,y0-16);g.lineTo(x1,y1-16);g.stroke()});
  LC_GLOWS.slice(2).forEach(([x,y])=>{fkGlow(g,x,y,26,'#ffb44a',.45);g.fillStyle='#2a1a1a';g.fillRect(x-1.5,y,3,14);g.fillStyle='#ffe08a';g.beginPath();g.arc(x,y-1,3.4,0,TAU);g.fill();g.lineWidth=1.4;g.strokeStyle=FKO;g.stroke()})}
 lc_lighthouse(g);
 /* the near-left cliff wall (dark, close) with a boathouse door */
 const NW=lc_crag([-10,-10,70,-10,120,120,150,260,140,380,170,470,150,560,120,600,-10,620],30,10,21);
 lc_rock(g,NW,'#1a1e46','#0a0c26',3.5,'#6a88d8',.35,-6,4);lc_tex(g,NW,0,0,170,620,22,31,'#05061a','#2a3470');
 {const x=70,y=560;fkGlow(g,x,y-30,70,'#ffb44a',.3);g.fillStyle='#120a14';g.beginPath();g.moveTo(x-28,y);g.lineTo(x-28,y-40);g.arc(x,y-40,28,Math.PI,0);g.lineTo(x+28,y);g.closePath();g.fill();g.lineWidth=3;g.strokeStyle=FKO;g.stroke();
  g.fillStyle=fkLin(g,0,y-60,0,y,['#6a4a32','#3a2418']);g.beginPath();g.moveTo(x-22,y);g.lineTo(x-22,y-40);g.arc(x,y-40,22,Math.PI,0);g.lineTo(x+22,y);g.closePath();g.fill();g.lineWidth=2.4;g.stroke();
  g.strokeStyle='#2a1810';g.lineWidth=1.6;for(let k=-1;k<=1;k++){g.beginPath();g.moveTo(x+k*8,y-58);g.lineTo(x+k*8,y);g.stroke()}
  g.fillStyle=fkLin(g,0,y-52,0,y-38,['#ffe6a0','#e89a3a']);g.beginPath();g.arc(x,y-44,7,0,TAU);g.fill();g.lineWidth=2;g.strokeStyle='#2a1810';g.stroke();g.beginPath();g.moveTo(x-7,y-44);g.lineTo(x+7,y-44);g.moveTo(x,y-51);g.lineTo(x,y-37);g.stroke()}
 /* ---- the sea ---- */
 g.fillStyle=fkLin(g,0,FSW_Y,0,900,['#1e5478','#143e66','#0c2a50','#071834']);g.fillRect(0,FSW_Y,1600,380);
 {const R=document.createElement('canvas');R.width=1600;R.height=260;const r=R.getContext('2d');r.translate(0,260);r.scale(1,-1);r.drawImage(g.canvas,0,FSW_Y-260,1600,260,0,0,1600,260);r.setTransform(1,0,0,1,0,0);
  /* soften (downscale then upscale), fade with depth, then squash vertically and lay it down in gently wavy bands */
  const Q=document.createElement('canvas');Q.width=320;Q.height=52;Q.getContext('2d').drawImage(R,0,0,320,52);
  const B=document.createElement('canvas');B.width=1600;B.height=260;const b=B.getContext('2d');b.drawImage(Q,0,0,1600,260);
  b.globalCompositeOperation='destination-in';const m=b.createLinearGradient(0,0,0,260);m.addColorStop(0,'#000000');m.addColorStop(.45,'#00000080');m.addColorStop(1,'#00000000');b.fillStyle=m;b.fillRect(0,0,1600,260);
  const SQ=.62,DH=260*SQ;g.save();g.globalAlpha=.4;for(let y=0;y<DH;y+=3){const off=Math.sin(y*.12)*(1.2+y*.03)+Math.sin(y*.05+1)*1.5;g.drawImage(B,0,y/SQ,1600,3/SQ,off,FSW_Y+2+y,1600,3)}g.restore()}
 g.fillStyle=fkLin(g,0,FSW_Y,0,FSW_Y+280,['#10305800','#0e2a5080','#0a2046c8']);g.fillRect(0,FSW_Y,1600,280);
 /* broad gentle swells: soft light and dark bands */
 for(let i=0;i<9;i++){const y=FSW_Y+20+Math.pow(i/9,1.4)*330,h=6+i*3.4;g.globalAlpha=.07;g.fillStyle=i%2?'#7ab0e0':'#040a20';g.beginPath();g.moveTo(0,y);for(let x=0;x<=1600;x+=80)g.quadraticCurveTo(x+40,y-h*.5+Math.sin(x*.01+i)*h*.4,x+80,y);g.lineTo(1600,y+h);for(let x=1600;x>=0;x-=80)g.quadraticCurveTo(x-40,y+h*.6+Math.sin(x*.013+i*2)*h*.3,x-80,y+h);g.closePath();g.fill()}g.globalAlpha=1;
 g.save();g.globalCompositeOperation='lighter';
 const refl=(x,y,rx,ry,c,a)=>{g.save();g.translate(x,y);g.scale(1,ry/rx);const q=g.createRadialGradient(0,0,0,0,0,rx);q.addColorStop(0,c+lc_hx(a));q.addColorStop(.45,c+lc_hx(a*.5));q.addColorStop(1,c+'00');g.fillStyle=q;g.beginPath();g.arc(0,0,rx,0,TAU);g.fill();g.restore()};
 /* the lamp's golden path: a soft column under the lighthouse, widening toward the viewer */
 const col=(cx,hw0,hw1,H,c0,c1,a0,y0)=>{const[P,m]=lc_cv(400,H);for(let y=0;y<H;y+=2){const u=y/H,hw=hw0+u*(hw1-hw0),q=m.createLinearGradient(200-hw,0,200+hw,0);q.addColorStop(0,c1+'00');q.addColorStop(.35,c1+lc_hx(a0*.3*(1-u)));q.addColorStop(.5,c0+lc_hx(a0*(1-u*.8)));q.addColorStop(.65,c1+lc_hx(a0*.3*(1-u)));q.addColorStop(1,c1+'00');m.fillStyle=q;m.fillRect(200-hw,y,hw*2,2)}
  m.globalCompositeOperation='destination-in';const vy=m.createLinearGradient(0,0,0,H);vy.addColorStop(0,'#000');vy.addColorStop(.6,'#000b');vy.addColorStop(1,'#0000');m.fillStyle=vy;m.fillRect(0,0,400,H);g.drawImage(P,cx-200,y0)};
 col(LC_LAMP.x,26,120,300,'#ffe6a0','#ffb44a',.55,FSW_Y+6);refl(LC_LAMP.x,FSW_Y+14,70,9,'#ffcf6a',.4);refl(LC_LAMP.x,FSW_Y+60,46,40,'#ffb44a',.12);
 col(LC_MOON.x,16,64,170,'#f4f8ff','#c8dcff',.32,FSW_Y+4);refl(LC_MOON.x,FSW_Y+8,36,5,'#f4f8ff',.32);
 /* lantern and window glints on the water */
 refl(236,700,50,8,'#ffb44a',.22);refl(588,704,54,9,'#ffb44a',.24);refl(318,548,22,5,'#ffb44a',.25);refl(708,544,18,4,'#ffb44a',.3);refl(70,640,40,8,'#ffb44a',.2);
 /* moonlit sparkle specks across the sea */
 for(let i=0;i<150;i++){const x=lc_r(i+1301)*1600,u=lc_r(i+1501),y=FSW_Y+10+u*u*370,r=.7+lc_r(i+1701)*1.3;g.globalAlpha=(.14+lc_r(i+1901)*.32)*(1-u*.5);g.fillStyle=lc_r(i+2101)<.7?'#bfe0ff':'#ffe6b0';g.beginPath();g.ellipse(x,y,r*2.2,r*.6,0,0,TAU);g.fill()}
 g.globalAlpha=1;
 /* a bright seam along the horizon */
 for(let i=0;i<46;i++){const x=900+i*15+lc_r(i+2601)*8,w=6+lc_r(i+2701)*18;g.globalAlpha=.14+lc_r(i+2801)*.3;g.fillStyle='#bfe0ff';g.fillRect(x,FSW_Y+1+lc_r(i+3001)*4,w,1.6)}
 g.globalAlpha=1;g.restore();
 /* surf at the cliff foot: a tumble of boulders with foam round them */
 g.fillStyle='#0c1030';g.globalAlpha=.6;g.beginPath();g.moveTo(-10,522);for(let x=0;x<=980;x+=20)g.lineTo(x,526+Math.sin(x*.05)*3+lc_r(x)*4);g.lineTo(980,534);g.lineTo(-10,534);g.fill();g.globalAlpha=1;
 [[330,532,30,18],[372,536,20,12],[470,530,36,22],[520,536,22,14],[610,532,40,20],[662,537,18,10],[760,534,34,18],[812,538,22,12],[880,536,40,22],[936,540,26,14],[968,544,16,8],[200,536,26,14],[120,532,34,18]].forEach(([x,y,w,h],i)=>{
  const p=[];for(let k=0;k<9;k++){const a=Math.PI+k/8*Math.PI,r=.78+lc_r(i*9+k+150)*.28;p.push(x+Math.cos(a)*w*r,y+Math.sin(a)*h*r)}p.push(x+w,y+6,x-w,y+6);
  lc_rock(g,p,'#3a4478','#141838',2.6,'#a8c4ff',.55,-4,5)});
 g.fillStyle='#e8f4ff';for(let i=0;i<46;i++){const x=lc_r(i+3101)*990,y=540+lc_r(i+3201)*8,w=5+lc_r(i+3301)*16;g.globalAlpha=.22+lc_r(i+3401)*.3;g.beginPath();g.ellipse(x,y,w,1.6+lc_r(i+3501)*1.6,0,0,TAU);g.fill()}g.globalAlpha=1;
 lc_wreck(g);
 /* the wreck's reflection: a short dark smear */
 g.save();g.globalAlpha=.25;g.fillStyle='#050a1e';g.beginPath();g.ellipse(LC_WRECK.x-6,LC_WRECK.y+14,82,10,0,0,TAU);g.fill();g.restore();
 g.fillStyle='#e8f4ff';[[-60,4,14],[-30,6,10],[0,5,12],[40,6,14],[70,4,8]].forEach(([dx,dy,w])=>{g.globalAlpha=.45;g.beginPath();g.ellipse(LC_WRECK.x+dx,LC_WRECK.y+dy,w,2.4,0,0,TAU);g.fill()});g.globalAlpha=1;
 /* faint surface lines (kept off the fishing water) */
 g.strokeStyle='#9ac8f0';g.lineCap='round';for(let i=0;i<30;i++){const u=lc_r(i+2301),y=FSW_Y+26+u*u*330,x=lc_r(i+2401)*1600,w=30+u*90;if(x>700&&x<1130&&y>570&&y<720)continue;g.globalAlpha=.05+u*.06;g.lineWidth=1.3;g.beginPath();g.moveTo(x-w/2,y);g.quadraticCurveTo(x,y-2-u*3,x+w/2,y);g.stroke()}g.globalAlpha=1;
 /* rock landing under the left of the pier where the stair comes down */
 const RL=lc_crag([-10,560,100,554,200,548,290,544,350,556,372,590,356,640,300,680,180,700,60,712,-10,716],22,6,51);
 lc_rock(g,RL,'#2e3466','#10122e',3.5,'#9ab8ff',.45,-4,6);lc_tex(g,RL,0,540,380,716,14,61,'#06081e','#4a5a96');
 g.fillStyle='#1e5a4a';for(let i=0;i<16;i++){const x=20+lc_r(i+81)*330,y=640+lc_r(i+82)*60;g.globalAlpha=.7;g.beginPath();g.ellipse(x,y,5+lc_r(i+83)*6,2.4,0,0,TAU);g.fill()}g.globalAlpha=1;
 g.strokeStyle='#bfe0ff';g.globalAlpha=.35;g.lineWidth=2;g.beginPath();g.moveTo(180,712);g.quadraticCurveTo(320,690,372,620);g.stroke();g.globalAlpha=1;
 lc_gulls(g);
 lc_pier(g);
 /* ---- foreground rocks with kelp, a starfish and shells ---- */
 const kelp=(x,y,h,lean,c)=>{g.strokeStyle=FKO;g.lineWidth=7;g.beginPath();g.moveTo(x,y);g.bezierCurveTo(x+lean,y-h*.3,x-lean,y-h*.6,x+lean*.5,y-h);g.stroke();g.strokeStyle=c;g.lineWidth=4;g.stroke()};
 const FR=lc_crag([1140,910,1190,874,1260,850,1340,840,1420,818,1500,806,1570,798,1610,790,1610,910],26,8,71);
 kelp(1200,880,70,12,'#2a6a4a');kelp(1228,872,50,-10,'#1e5a3e');
 lc_rock(g,FR,'#232a5a','#0a0c26',3,'#8ab0f0',.45,-4,6);lc_tex(g,FR,1140,790,1610,900,12,81,'#05061a','#34407a');
 const star=(x,y,r,a,c)=>{g.save();g.translate(x,y);g.rotate(a);g.beginPath();for(let i=0;i<10;i++){const rr=i%2?r*.42:r,aa=i/10*TAU-Math.PI/2;g.lineTo(Math.cos(aa)*rr,Math.sin(aa)*rr)}g.closePath();g.fillStyle=fkRad(g,0,0,r,[shade(c,.4),c,shade(c,-.3)]);g.fill();g.lineWidth=2.2;g.strokeStyle=FKO;g.stroke();g.fillStyle='#ffffff66';for(let i=0;i<5;i++){const aa=i/5*TAU-Math.PI/2;g.beginPath();g.arc(Math.cos(aa)*r*.5,Math.sin(aa)*r*.5,1.4,0,TAU);g.fill()}g.restore()};
 star(1330,846,15,.3,'#ff8a5a');star(130,808,12,-.2,'#e86aa0');
 const shell=(x,y,s)=>{g.save();g.translate(x,y);g.scale(s,s);g.beginPath();g.moveTo(-10,2);g.quadraticCurveTo(-12,-12,0,-14);g.quadraticCurveTo(12,-12,10,2);g.closePath();g.fillStyle=fkLin(g,0,-14,0,2,['#fff0e0','#e8b8a0']);g.fill();g.lineWidth=2;g.strokeStyle=FKO;g.stroke();g.strokeStyle='#c8907a';g.lineWidth=1.2;g.beginPath();for(let k=-2;k<=2;k++){g.moveTo(0,1);g.lineTo(k*4.4,-12)}g.stroke();g.restore()};
 shell(1460,816,1);shell(1392,834,.8);
 const FL=lc_crag([-10,760,90,772,170,808,214,860,240,910,-10,910],24,7,91);
 kelp(196,880,60,-10,'#2a6a4a');
 lc_rock(g,FL,'#232a5a','#0a0c26',3,'#8ab0f0',.4,-4,6);lc_tex(g,FL,0,760,240,910,8,95,'#05061a','#34407a');shell(60,800,.9)}
/* ---------- cached sprites for the live layers ---------- */
function lc_init(){const S={mg:lc_mote('#ffe08a'),mt:lc_mote('#9affe8'),mb:lc_mote('#bfe0ff')};
 /* breathing glows at the exact size they are drawn: lamp halo, lamp core, flare, cottage window, tower door, stair lamps */
 S.gp=[['#ffb84a',LC_LAMP.x,LC_LAMP.y,150],['#ffd27a',LC_LAMP.x,LC_LAMP.y,46],['#e8f0ff',LC_MOON.x,LC_MOON.y,90]].map(([c,x,y,r])=>({c:lc_spr(c,r),x:x-r,y:y-r}));
 S.flare=lc_spr('#ffe6a0',110,[.1,.4]);
 S.wg=LC_GLOWS.map(([x,y,c],i)=>{const r=i<2?36:24;return{c:lc_spr(c,r),x:x-r,y:y-r}});
 S.lw=[0,1,2,3,4].map(q=>lc_spr('#ffa040',Math.round(80*(.7+.075*q))));
 /* the beam: a long soft wedge of warm light with a smooth cross-profile. Its slight downward tilt is baked in
    (so it is drawn with an axis-aligned scale only), and it is cut into slices that hug the wedge, skipping the empty corners */
 {const L=760,Y0=72,HH=240,SL=.06,h1=94,hk=x=>3+(h1-3)*x/L,[c,x]=lc_cv(L,HH);
  /* one smooth cross-profile strip, stretched into every column of the wedge */
  const[pc,px]=lc_cv(1,256),q=px.createLinearGradient(0,0,0,256);[[0,'#ffe2a000'],[.14,'#ffe2a026'],[.28,'#ffe2a070'],[.4,'#ffe6aab8'],[.5,'#fff2d0f0'],[.6,'#ffe6aab8'],[.72,'#ffe2a070'],[.86,'#ffe2a026'],[1,'#ffe2a000']].forEach(([o,c])=>q.addColorStop(o,c));px.fillStyle=q;px.fillRect(0,0,1,256);
  for(let X=0;X<L;X+=2){const h=hk(X)*1.25+2,cy=Y0+SL*X;x.drawImage(pc,X,cy-h,2,h*2)}
  x.globalAlpha=1;x.globalCompositeOperation='destination-in';const m=x.createLinearGradient(0,0,L,0);m.addColorStop(0,'#000');m.addColorStop(.3,'#000e');m.addColorStop(.65,'#0007');m.addColorStop(1,'#0000');x.fillStyle=m;x.fillRect(0,0,L,HH);
  S.beam=c;S.bY0=Y0;S.bsl=[];for(let a=0;a<760;a+=152){const b=a+152,y0=Math.max(0,Math.floor(Y0+SL*a-hk(b)*1.25-3)),y1=Math.min(HH,Math.ceil(Y0+SL*b+hk(b)*1.25+3));S.bsl.push([a,y0,152,y1-y0])}}
 /* the lantern-room frame laid back over the beams */
 {const[c,x]=lc_cv(120,150);x.translate(-(LC_LAMP.x-60),-(LC_T-128));lc_lampTop(x,false);S.cap=c;S.capX=LC_LAMP.x-60;S.capY=LC_T-128}
 /* fog banks: tileable strips of soft misty puffs (two copies scroll side by side) */
 const fog=(H,n,seed,col,a0)=>{const[c,x]=lc_cv(1600,H),P=lc_spr(col,64);for(let i=0;i<n;i++){const px=lc_r(seed+i)*1600,py=H*.25+lc_r(seed+i+.5)*H*.5,w=120+lc_r(seed+i+.7)*260,h=H*(.35+lc_r(seed+i+.9)*.4),dens=.5+.5*Math.sin(px*.006+seed);x.globalAlpha=a0*(.4+.6*dens);[-1600,0,1600].forEach(o=>x.drawImage(P,px+o-w/2,py-h/2,w,h))}return c};
 S.fogH=fog(104,46,401,'#9ab8e0',.34);S.fogF=fog(86,30,501,'#a8c4e8',.24);
 /* the message bottle */
 {const[c,x]=lc_cv(60,40);x.translate(30,20);x.rotate(-.18);x.beginPath();x.moveTo(-20,-8);x.quadraticCurveTo(-24,0,-20,8);x.lineTo(6,8);x.quadraticCurveTo(12,8,14,4);x.lineTo(22,3);x.lineTo(22,-3);x.lineTo(14,-4);x.quadraticCurveTo(12,-8,6,-8);x.closePath();
  x.fillStyle=fkLin(x,0,-8,0,8,['#9affd0','#3aa880','#1a6a50']);x.globalAlpha=.85;x.fill();x.globalAlpha=1;x.lineWidth=2.2;x.strokeStyle=FKO;x.stroke();
  x.fillStyle='#f4e2b8';x.beginPath();x.roundRect(-15,-4,20,8,3);x.fill();x.strokeStyle='#b8946a';x.lineWidth=1;x.stroke();x.fillStyle='#c8282a';x.fillRect(-6,-4,2.4,8);
  x.fillStyle='#a8784a';x.fillRect(22,-3.4,5,6.8);x.lineWidth=1.6;x.strokeStyle=FKO;x.strokeRect(22,-3.4,5,6.8);x.fillStyle='#ffffffb0';x.fillRect(-16,-6,14,2);S.bot=c}
 return S}
/* twinkle positions in the sky */
const LC_TW=[[540,70],[880,170],[1000,52],[1180,250],[420,210],[1330,96],[790,300]];
FSLOCART.cove={
 bg:lc_bg,
 back(g,t){if(!lc_S)lc_S=lc_init();const S=lc_S,L=LC_LAMP;
  /* twinkling stars (two batches, one path each) */
  g.fillStyle='#f4f0ff';for(let b=0;b<2;b++){g.globalAlpha=.25+.55*Math.max(0,Math.sin(t*(1.2+b*.7)+b*2.2));g.beginPath();for(let i=b;i<LC_TW.length;i+=2){const[x,y]=LC_TW[i],r=3+lc_r(i+7)*3;g.moveTo(x,y-r);g.quadraticCurveTo(x+r*.16,y-r*.16,x+r,y);g.quadraticCurveTo(x+r*.16,y+r*.16,x,y+r);g.quadraticCurveTo(x-r*.16,y+r*.16,x-r,y);g.quadraticCurveTo(x-r*.16,y-r*.16,x,y-r)}g.fill()}g.globalAlpha=1;
  /* a shooting star now and then */
  {const p=(t%13)/13;if(p<.07){const u=p/.07,x=1240-u*360,y=60+u*90;g.strokeStyle='#ffffff';g.lineWidth=2;g.globalAlpha=Math.sin(u*Math.PI)*.75;g.beginPath();g.moveTo(x,y);g.lineTo(x+64,y-16);g.stroke();g.globalAlpha=1}}
  g.save();g.globalCompositeOperation='lighter';
  const gp=(G,a)=>{g.globalAlpha=Math.max(0,Math.min(1,a));g.drawImage(G.c,G.x,G.y)};
  gp(S.gp[2],.14+.05*Math.sin(t*.7));
  /* the keeper's lamp: twin beams sweeping round (foreshortened as they turn), brighter when they face us */
  const ph=t*.42+.5,cx=Math.cos(ph),fa=Math.sin(ph);
  /* (nearest sampling: the beam is a smooth gradient, and a filtered scaled blit costs about twice as much) */
  g.imageSmoothingEnabled=false;for(let k=0;k<2;k++){const sx=k?-cx:cx,f=k?-fa:fa;if(Math.abs(sx)<.02)continue;const sy=1+.25*Math.max(0,f);g.save();g.translate(L.x,L.y-S.bY0*sy);g.scale(sx,sy);g.globalAlpha=Math.min(1,.62+.38*f);S.bsl.forEach(([a,y,w,h])=>g.drawImage(S.beam,a,y,w,h,a,y,w,h));g.restore()}g.imageSmoothingEnabled=true;
  const fl=Math.pow(Math.abs(fa),8);
  gp(S.gp[0],.24+.06*Math.sin(t*1.3)+fl*.25);gp(S.gp[1],.38+.12*Math.sin(t*2.1)+fl*.3);
  if(fl>.02){g.globalAlpha=fl*.85;g.drawImage(S.flare,L.x-110,L.y-110)}
  g.restore();g.globalAlpha=1;
  /* the lantern-room frame over the beams */
  g.drawImage(S.cap,S.capX,S.capY);
  g.save();g.globalCompositeOperation='lighter';
  /* cottage window, tower door and stair lamps breathe softly */
  S.wg.forEach((G,i)=>gp(G,.3+.12*Math.sin(t*(1.5+i*.3)+i*2)));
  /* horizon fog bank drifting slowly */
  {const o=Math.round((t*7)%1600);g.globalCompositeOperation='source-over';g.globalAlpha=.8;g.drawImage(S.fogH,o-1600,458);g.drawImage(S.fogH,o,458);g.globalCompositeOperation='lighter'}
  /* lamp path and moon path shimmer on the water */
  g.fillStyle='#ffcf6a';g.globalAlpha=.5+fl*.4;g.beginPath();for(let i=0;i<12;i++){const u=(i+.5)/12,y=FSW_Y+14+u*u*260,w=(10+u*60)*(.4+.6*Math.max(0,Math.sin(t*1.3+i*1.7))),x=L.x+Math.sin(t*.9+i*2.3)*(4+u*24),h=1+u*1.4;g.moveTo(x+w/2,y);g.ellipse(x,y,w/2,h,0,0,TAU)}g.fill();
  g.fillStyle='#eef4ff';g.globalAlpha=.45;g.beginPath();for(let i=0;i<5;i++){const u=(i+.5)/5,y=FSW_Y+8+u*90,w=(10+u*30)*(.45+.55*Math.max(0,Math.sin(t*1.5+i*1.9))),x=LC_MOON.x+Math.sin(t*.8+i*2.1)*(3+u*10),h=.9+u*.8;g.moveTo(x+w/2,y);g.ellipse(x,y,w/2,h,0,0,TAU)}g.fill();
  /* moonlit crests on the swells, drifting (two twinkling batches) */
  for(let b=0;b<2;b++){g.globalAlpha=.16+.1*Math.sin(t*(.9+b*.5)+b*2);g.strokeStyle=b?'#bfe0ff':'#9ad0ff';g.lineWidth=1.5;g.beginPath();
   for(let i=b;i<36;i+=2){const u=lc_r(i+601),y=FSW_Y+18+Math.pow(u,1.5)*350,w=18+u*80,x=((lc_r(i+602)*1800+t*(5+u*9))%1800)-100,h=2+u*3;if(x>720&&x<1110&&y>575&&y<700)continue;g.moveTo(x-w/2,y);g.quadraticCurveTo(x,y-h,x+w/2,y)}g.stroke()}
  /* surf breathing at the cliff foot, round the wreck and the piling */
  g.globalCompositeOperation='source-over';g.fillStyle='#eaf6ff';
  for(let b=0;b<2;b++){g.globalAlpha=.32+.22*Math.sin(t*1.1+b*Math.PI);g.beginPath();for(let i=b;i<22;i+=2){const x=i*45+lc_r(i+701)*20,y=546+lc_r(i+702)*6,w=10+lc_r(i+703)*14+3*Math.sin(t*1.1+i);g.moveTo(x+w,y);g.ellipse(x,y,w,2.2,0,0,TAU)}
   const W=LC_WRECK;for(let i=b;i<6;i+=2){const x=W.x-64+i*26,y=W.y+4+(i%2)*2,w=8+3*Math.sin(t*1.3+i);g.moveTo(x+w,y);g.ellipse(x,y,w,2,0,0,TAU)}g.fill()}
  g.globalAlpha=1;
  /* slow ripple rings */
  g.strokeStyle='#bfe0ff';g.lineWidth=1.4;for(let i=0;i<3;i++){const p=(t*.17+i/3)%1,x=760+lc_r(i+70)*380,y=620+lc_r(i+71)*200,r=10+p*56;g.globalAlpha=(1-p)*.22;g.beginPath();g.ellipse(x,y,r,r*.28,0,0,TAU);g.stroke()}
  {const p=(t*.4)%1,r=12+p*20;g.globalAlpha=(1-p)*.35;g.beginPath();g.ellipse(652,700,r,r*.26,0,0,TAU);g.stroke()}
  /* the message bottle bobbing on the swell, with a glint */
  {const B=LC_BOTTLE,y=B.y+Math.sin(t*1.4)*2.2;g.globalAlpha=1;g.save();g.translate(B.x,y);g.rotate(Math.sin(t*1.1)*.12);g.drawImage(S.bot,-30,-20);g.restore();
   g.globalAlpha=.4;g.beginPath();g.ellipse(B.x,B.y+8,22+Math.sin(t*1.4)*2,3,0,0,TAU);g.stroke();
   const gl=Math.max(0,Math.sin(t*.9));if(gl>.6)fkSpark(g,B.x-8,y-6,3+5*(gl-.6),'#ffffff',(gl-.6)*2)}
  /* pier lanterns flicker */
  g.globalCompositeOperation='lighter';
  LC_LANT.forEach((P,i)=>{const f=.85+.15*Math.sin(t*9+i*7)*Math.sin(t*5.3+i),h=S.lw[Math.max(0,Math.min(4,Math.round((f-.7)/.075)))],r=h.width/2;g.globalAlpha=.42*f;g.drawImage(h,P.x-r,P.y-4-r)});
  /* ghostly will-o-wisps drifting round the cliff foot and the wreck */
  const ms=[S.mg,S.mt,S.mg,S.mb,S.mt];for(let i=0;i<5;i++){const x=[860,1010,760,1170,560][i]+Math.sin(t*.35+i*1.7)*40,y=[470,500,560,470,510][i]+Math.sin(t*.6+i)*14,a=.35+.6*Math.max(0,Math.sin(t*1.1+i*2.1)),s=14+lc_r(i+93)*12;g.globalAlpha=a;g.drawImage(ms[i],x-s/2,y-s/2,s,s)}
  g.restore();g.globalAlpha=1},
 front(g,t){if(!lc_S)lc_S=lc_init();const S=lc_S;
  /* fog wisps drifting across the cliff face, below the lighthouse */
  {const o=Math.round(1600-(t*4)%1600);g.globalAlpha=.7;g.drawImage(S.fogF,o-1600,330);g.drawImage(S.fogF,o,330);g.globalAlpha=1}
  /* a few golden motes drifting up from the cove */
  g.save();g.globalCompositeOperation='lighter';const ms=[S.mg,S.mt,S.mb];
  for(let i=0;i<9;i++){const sp=6+lc_r(i+501)*10,yy=(lc_r(i+502)*600-t*sp)%600,y=(yy<0?yy+600:yy)+240,x=lc_r(i+503)*1600+Math.sin(t*.5+i*1.9)*30,a=.3+.5*Math.max(0,Math.sin(t*1.1+i*2.7)),s=8+lc_r(i+504)*10;g.globalAlpha=a;g.drawImage(ms[i%3],x-s/2,y-s/2,s,s)}
  g.restore();g.globalAlpha=1}};
/* ---------- Fishing Spots gallery: card crop and light ambient touches ---------- */
/* FSDGCROP lives in 90l3 (loaded after this file), so the crop is set once the whole script has run (and again by bg) */
function lc_crop(){if(typeof FSDGCROP!=='undefined'&&!FSDGCROP.cove)FSDGCROP.cove=[370,40,660,715]}
setTimeout(()=>{try{lc_crop()}catch(e){}},0);
{const o=fsdgFx;fsdgFx=function(g,k,W,H,t){if(k!=='cove')return o.apply(this,arguments);const s=W/369,[lx,ly]=fsdgPt(k,LC_LAMP.x,LC_LAMP.y,W,H);
 if(!lc_S)lc_S=lc_init();const S=lc_S;g.save();g.globalCompositeOperation='lighter';g.globalAlpha=.25+.1*Math.sin(t*1.3);g.drawImage(S.gp[0].c,lx-150*s*.6,ly-150*s*.6,300*s*.6,300*s*.6);
 const fa=Math.sin(t*.42+.5);g.globalAlpha=Math.pow(Math.max(0,fa),8)*.8;g.drawImage(S.flare,lx-110*s*.6,ly-110*s*.6,220*s*.6,220*s*.6);
 for(let i=0;i<6;i++){const u=((t*.05+fsRnd(i+40))%1),x=fsRnd(i+50)*W+Math.sin(t+i)*8*s,y=H*(.95-u*.6),a=Math.sin(u*Math.PI);g.globalAlpha=.7*a;const m=i%2?S.mt:S.mg,z=14*s;g.drawImage(m,x-z/2,y-z/2,z,z)}
 g.restore();g.globalAlpha=1}}
