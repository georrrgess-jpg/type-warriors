# Wildcard Ranked: the launch checklist from the Ranked plan, offline (AI opponents).
import asyncio,os,sys,time,json
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[];bad=0
        pg.on('pageerror',lambda e:er.append('PE '+str(e)[:300]))
        await pg.goto('file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else 'out.html'));await pg.wait_for_timeout(1200);E=pg.evaluate
        def chk(n,v,ok):
            nonlocal bad;bad+=0 if ok else 1;print(n,v,'OK' if ok else 'BAD',flush=True)
        await E("()=>{RS_ASK=false;P.gold=1000;delete P.rk;const W=wcSt();delete W.backs.rkcopper;save()}")
        # old saves
        r=await E("()=>{const R=rkSt();return [R.r,R.bar,R.lp,wcBackSel(),Object.keys(R.em).length]}");chk('old save loads as Bronze 0, default back',r,r==[0,0,0,'classic',0])
        # the points table at every rank, the bar never below 0
        tbl=await E("()=>WCRN.map(T=>T.pts)");chk('points table',tbl,tbl==[[30,20,10,0],[30,15,5,-5],[30,10,0,-10],[25,10,-5,-15],[25,5,-10,-20],[25,5,-10,-20]])
        r=await E("()=>{const R=rkSt();const out=[];for(let r=0;r<5;r++){Object.assign(R,{r,bar:3,peak:r});const o=rkApply(3);out.push([r,R.r,R.bar])}return out}")
        chk('4th never drops below 0 or loses a rank',r,all(x[0]==x[1] and x[2]==(3 if x[0]==0 else 0) for x in r))
        r=await E("()=>{const R=rkSt();Object.assign(R,{r:2,bar:40});const a=[];for(const pl of [0,1,2,3]){R.bar=40;rkApply(pl);a.push(R.bar)}return a}");chk('Gold: 1st..4th from 40',r,r==[70,50,40,30])
        # rank up: once, bar resets, rewards once; Forged Copper after the first ranked match
        r=await E("""()=>{delete P.rk;const W=wcSt();for(const k of WCBKK)if(WCBK[k].rk!=null)delete W.backs[k];save();const R=rkSt();const g0=P.gold;
          const first=rkApply(2);Object.assign(R,{bar:95});const up=rkApply(0);const g1=P.gold;
          return [first.first,!!W.backs.rkcopper,up.up&&up.up.r,R.r,R.bar,!!W.backs.rkmoon,R.em.stun,g1-g0,up.up&&up.up.coins]}""")
        chk('first match copper, rank up to Silver with rewards',r,r==[True,True,1,1,0,True,1,1500,1500])
        r=await E("()=>{const R=rkSt();Object.assign(R,{r:0,bar:95});const g0=P.gold;const up=rkApply(0);return [R.r,P.gold-g0,up.up.coins,up.up.newBack,up.up.newEmo]}")
        chk('same season again: no second coin bonus, nothing duplicated',r,r==[1,0,0,False,False])
        r=await E("()=>{const R=rkSt();R.season=rkSeason()-1;R.r=4;R.bar=50;const W=wcSt();W.backs.rkprism=1;R.em.slam=1;const R2=rkSt();return [R2.r,R2.bar,R2.season===rkSeason(),!!W.backs.rkprism,R2.em.slam,R2.note.length>0]}")
        chk('season end: down 2 ranks, bar 0, cosmetics kept',r,r==[2,0,True,True,1,True])
        r=await E("()=>{const R=rkSt();R.paid={[R.season-1]:[1]};R.r=0;R.bar=95;R.note='';const g0=P.gold;rkApply(0);return [R.r,P.gold-g0]}");chk('coins paid again in a new season',r,r==[1,1500])
        r=await E("()=>{const R=rkSt();Object.assign(R,{r:4,bar:99});const o=rkApply(1);return [R.r,R.title,o.up&&o.up.coins,R.lp,R.bar];}")
        chk('Legend: title and 12,000 coins',r,r==[5,'Legend',12000,0,0])
        r=await E("()=>{const R=rkSt();R.lp=10;rkApply(3);const a=R.lp;rkApply(0);return [a,R.lp,R.r,R.bar]}");chk('Legend points count, never below 0, rank kept',r,r==[0,25,5,0])
        # placing tie-breaks: cards, then card points, then last to play
        r=await E("""()=>{const G=wcNew({players:[0,1,2,3].map(i=>({id:'p'+i,name:'P'+i,kind:'bot'})),seed:5});const C=(s,v)=>({id:Math.random(),s,v});
          G.win=2;G.P[2].hand=[];G.P[0].hand=[C('e','9'),C('t','1')];G.P[1].hand=[C('e','3'),C('t','2')];G.P[3].hand=[C('e','3'),C('t','2')];G.P[0].lp=50;G.P[1].lp=10;G.P[3].lp=40;
          const a=wcRank(G);G.P[1].hand.push(C('w','wild'));return [a,wcRank(G)]}""")
        chk('tie-breaks',r,r==[[2,3,1,0],[2,3,0,1]])
        # AI levels: each level beats the one below it over many AI-only games
        sim=await E("""()=>{const res={};const play=(lv,opp,seed)=>{const ps=[0,1,2,3].map(i=>({id:'b'+i,name:'B'+i,kind:'bot',diff:'r'+(i===0?lv:opp)}));const G=wcNew({players:ps,hand:7,rules:{stack:1},seed});let k=0;
           while(G.phase!=='over'&&k++<2000){const pi=G.turn,p=G.P[pi],a=wcBot(G,pi),B=WCB[p.diff];if(a.t==='play'&&p.hand.length===2&&G.r()>=B.forget)wcDo(G,pi,{t:'call'});wcDo(G,pi,a);
            if(G.one){const t=G.one.p;for(let i=0;i<4;i++)if(i!==t&&G.r()<WCB[G.P[i].diff].catch*.5){wcCatch(G,i,t);break}G.one=null}}return wcRank(G).indexOf(0)};
          for(const [lv,opp] of [[1,0],[2,1],[3,2],[4,3],[4,0],[0,4]]){let pts=0,w=0;const N=400;for(let s=0;s<N;s++){const pl=play(lv,opp,1000+s*7);w+=pl===0;pts+=[3,2,1,0][pl]}res[lv+'v'+opp]=[Math.round(w/N*100),Math.round(pts/N*100)/100]}return res}""")
        print('   AI level vs 3 of another level: [win %, average place score 0-3 (1.5 = even)]',sim)
        chk('AI levels: clearly stronger from Bronze up, never weaker as ranks rise',sim,sim['1v0'][1]>1.6 and sim['4v0'][1]>1.65 and sim['0v4'][1]<1.35 and all(sim[k][1]>=1.45 for k in ['2v1','3v2','4v3']))
        # a full ranked match with the agent, timeouts and leaving
        await E("()=>{delete P.rk;save();rkHub()}");await pg.wait_for_timeout(600);await pg.screenshot(path='shots/rk_hub.png')
        await E("()=>rkStart()");await pg.wait_for_timeout(1500)
        r=await E("()=>[WX.rk&&WX.rk.r,WX.cfg.timer,WX.stake,WX.G.P.filter(p=>p.kind==='bot'&&p.diff==='r0'&&p.ai).length,!!document.querySelector('.rkpil'),!!rkSt().live,WX.G.rules.stack]")
        chk('ranked table: 15 s turns, no stake, 3 AI at your rank, live marker',r,r==[0,15,0,3,True,True,1])
        await pg.add_script_tag(path=os.path.abspath('t_wc_agent.js'));t0=time.time()
        while time.time()-t0<300 and not await E("()=>!!document.getElementById('rkres')"):await pg.wait_for_timeout(500)
        await pg.wait_for_timeout(2500);r=await E("()=>{const R=rkSt();const h=R.hist[R.hist.length-1];return [!!document.getElementById('rkres'),R.n,h&&h.p,h&&h.d,R.bar,R.live,wcSt().backs.rkcopper,wcSt().byd.rk.g]}")
        chk(f'full ranked match {time.time()-t0:.0f}s, result applied',r,r[0] and r[1]==1 and r[3]==[30,20,10,0][r[2]] and r[4]==r[3] and r[5] is None and r[6]==1 and r[7]==1)
        await pg.screenshot(path='shots/rk_result.png');await E("()=>{clearInterval(window.__agT)}")
        # three timeouts hand the seat to an AI and count as 4th
        await E("()=>{const R=rkSt();R.r=2;R.bar=50;save();rkStart();WX.cfg.timer=1}");t0=time.time()
        while time.time()-t0<60 and not await E("()=>!!document.getElementById('rkres')"):await pg.wait_for_timeout(300)
        r=await E("()=>{const R=rkSt(),h=R.hist[R.hist.length-1];return [!!document.getElementById('rkres'),h.p,h.why,R.bar,document.querySelector('.rksub').textContent]}")
        chk('three timeouts: AI takes the seat, 4th',r,r[0] and r[1]==3 and r[2]=='afk' and r[3]==40)
        # leaving through the menu
        await E("()=>{const R=rkSt();R.bar=50;save();rkStart()}");await pg.wait_for_timeout(3000)
        await E("()=>{wcMenu()}");await pg.wait_for_timeout(300);txt=await E("()=>document.querySelector('.wcmnb > p').textContent")
        await pg.click('#wcquit');await pg.wait_for_timeout(600)
        r=await E("()=>{const R=rkSt(),h=R.hist[R.hist.length-1];return [h.p,h.why,R.bar,!!document.getElementById('rkhub'),R.live]}")
        chk('leaving via the menu: 4th, back to the hub',[txt,r],'4th' in txt and r[:4]==[3,'left',40,True] and r[4] is None)
        # closing the page mid-match counts as 4th next time
        await E("()=>{const R=rkSt();R.bar=50;save();rkStart()}");await pg.wait_for_timeout(1500)
        await E("()=>{WX.tok++;wcClear();WX.G=null;WX.rk=null;wcHome()}");r=await E("()=>{rkHub();const R=rkSt(),h=R.hist[R.hist.length-1];return [h.p,h.why,R.bar,R.live]}")
        chk('a ranked match left behind counts as 4th',r,r==[3,'left',40,None])
        # emotes: locked ones show their rank, the cooldown, moments and mute
        await E("()=>{const m=document.getElementById('wcmod');if(m){m.hidden=true;m.innerHTML=''}const R=rkSt();R.r=2;R.em={stun:1,rev:1};save();rkStart()}");await pg.wait_for_timeout(4500)
        await E("()=>rkPick()");await pg.wait_for_timeout(300)
        r=await E("()=>[...document.querySelectorAll('.rkre button')].map(b=>(b.disabled?'lock:':'own:')+b.querySelector('small').textContent)")
        chk('picker: owned and locked ranked emotes',r,r==['own:Stunned!','own:Reversed!','lock:Platinum','lock:Diamond','lock:Legend'])
        await pg.screenshot(path='shots/rk_picker.png')
        r=await E("async()=>{document.querySelector('.rkre button[data-k=\"rev\"]').click();await new Promise(r=>setTimeout(r,200));const a=document.querySelectorAll('.rkfly').length;rkSend('GG');await new Promise(r=>setTimeout(r,100));const bub=(document.getElementById('wcbub'+WX.me)||{}).textContent;await new Promise(r=>setTimeout(r,3100));rkSend('Nice!');await new Promise(r=>setTimeout(r,100));return [a,bub,(document.getElementById('wcbub'+WX.me)||{}).textContent]}")
        chk('ranked emote shows; a second emote within 3 s is blocked; after 3 s it works',r,r[0]==1 and r[1]!='GG' and r[2]=='Nice!')
        r=await E("()=>{rkMoment(WX.me,'rev');const b=document.getElementById('rkemob');const a=b.classList.contains('mom');WX.emoT=0;b.click();return [a,document.querySelectorAll('.rkfly').length>0,!!WX.rkMom]}")
        chk('moment prompt glows and one tap sends it',r,r==[True,True,False])
        r=await E("async()=>{const nm=document.querySelector('.wcseat[data-seat=\"1\"] .wcnm');nm.click();await new Promise(r=>setTimeout(r,50));document.querySelectorAll('.rkfly').forEach(e=>e.remove());wcBubble(1,'@stun');const muted=document.querySelectorAll('.rkfly').length;WX.mute[1]=false;wcBubble(1,'@stun');return [!!WX.mute&&nm.classList.contains('muted'),muted,document.querySelectorAll('.rkfly').length]}")
        chk('tap a name to mute their emotes',r,r==[True,0,1])
        # screens at other sizes
        await E("()=>{WX.tok++;wcClear();WX.G=null;rkHub()}")
        for w,h in ((1280,720),(412,915)):
            await pg.set_viewport_size({'width':w,'height':h});await pg.wait_for_timeout(500);await pg.screenshot(path=f'shots/rk_hub_{w}.png')
        await pg.set_viewport_size({'width':1600,'height':900})
        print('bad',bad);print(er[:6]);await b.close()
asyncio.run(main())
