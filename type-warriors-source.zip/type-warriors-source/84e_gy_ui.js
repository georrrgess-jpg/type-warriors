/* ---------- Monster Mash: menus (mode page, crate hub, shop section) ---------- */
const HW_PRICE={a:100000,w:100000,b:175000};
const hwItems=()=>HWG_ID.a.map(id=>({kind:'a',id})).concat(HWG_ID.w.map(id=>({kind:'w',id})));
const hwOwn=it=>it.kind==='a'?!!P.ownA[it.id]:!!P.own[it.id];
const hwCount=()=>hwItems().filter(hwOwn).length;
const hwRar=['Common','Uncommon','Rare','Epic','Legendary','Mythic'];
const hwPct=n=>(n*100).toFixed(n*100%1?(n*1000%1?2:1):0).replace(/\.0+$/,'')+'%';
function hwThumbs(root){(root||ov).querySelectorAll('canvas[data-hw]').forEach(c=>{const [k,id]=c.dataset.hw.split(':');try{art(c,k,id,0)}catch(e){}})}
/* collection strip: all twelve relics, dark until owned */
function hwStrip(){return `<div class="hwst">${hwItems().map(it=>{const d=(it.kind==='a'?AR:WP)[it.id],o=hwOwn(it);return `<span class="hwi${o?' own':''}" style="--c:${d.col}" title="${esc(d.n)} (${d.r})${o?'':' - not found yet'}"><canvas width="68" height="84" data-hw="${it.kind}:${it.id}"></canvas><i>${d.r[0]==='U'?'UN':d.r.slice(0,3).toUpperCase()}</i></span>`}).join('')}</div>`}
/* odds pie: every rarity has its slice; Legendary and Mythic keep their numbers secret */
const HW_HIDE=[0,0,0,0,1,1];
function hwOddsChips(){const R=60,cx=70,cy=70;let a0=-Math.PI/2,sl='';
 HW_ODDS.forEach((p,i)=>{const a1=a0+p*Math.PI*2,big=a1-a0>Math.PI?1:0,x0=cx+R*Math.cos(a0),y0=cy+R*Math.sin(a0),x1=cx+R*Math.cos(a1),y1=cy+R*Math.sin(a1),c=RC[hwRar[i]];
  sl+=`<path d="M${cx} ${cy}L${x0.toFixed(2)} ${y0.toFixed(2)}A${R} ${R} 0 ${big} 1 ${x1.toFixed(2)} ${y1.toFixed(2)}Z" fill="${c}" stroke="#0b0719" stroke-width="1.5"${HW_HIDE[i]?' class="hwpz"':''}><title>${hwRar[i]}: ${HW_HIDE[i]?'???':hwPct(p)}</title></path>`;a0=a1});
 return `<div class="hwpie"><svg viewBox="0 0 140 140" width="140" height="140" role="img" aria-label="Graveyard crate odds">${sl}<circle cx="${cx}" cy="${cy}" r="27" fill="#120c26" stroke="#ffffff22"/><text x="${cx}" y="${cy-3}" text-anchor="middle" class="hwpt1">ODDS</text><text x="${cx}" y="${cy+12}" text-anchor="middle" class="hwpt2">per crate</text></svg>
 <div class="hwlg">${HW_ODDS.map((p,i)=>`<span style="--c:${RC[hwRar[i]]}"><i></i>${hwRar[i]}<b${HW_HIDE[i]?' class="hq"':''}>${HW_HIDE[i]?'???':hwPct(p)}</b></span>`).join('')}</div></div>`}
/* ----- crate hub ----- */
function crateHub(){S.mode='title';S.view='menu';
 const C=[['w','Weapon crate','Swords and daggers','#b8b8b8','crates'],['a','Armor crate','Any armor set','#5fb4ff','acr'],['s','Special crate','Path weapons','#e08aff','scr'],['p','Eclipse Chest','Guaranteed Legendary','#ffd76a','pcr']];
 const tot=C.reduce((a,c)=>a+(P[c[4]]||0),0)+(P.hcr||0)+(P.ccr||0),nh=P.hcr||0,showH=hwOn()||nh>0||hwCount()>0,left=Math.max(0,HW_PITY-(P.hpity||0));
 show(`<h2>Crates</h2><p>${tot?`You have <b style="color:var(--gold)">${tot}</b> crate${tot>1?'s':''} waiting. Open them here. Crates also drop from runs, and the Shop sells more.`:'You have no crates right now. They drop from runs and bosses, and the Shop sells them.'}</p>
 ${showH?`<div class="hwb${nh?'':' e'}"><div class="hwbl"><canvas width="320" height="250" data-c="h"></canvas></div>
  <div class="hwbm"><div class="hwtop"><span class="hwlt">LIMITED TIME</span><small>${hwOn()?hwLeft():'The graveyard is quiet again'}</small></div><b class="hwn">Graveyard Crate</b>
   <p>Twelve Halloween relics: a full armor set and a weapon for every rarity. Earn them in Monster Mash or buy them with candy corn in the Hollow Street Candy Stall.</p>
   ${hwOddsChips()}<div class="hwpt"><span>Epic or better guaranteed in <b>${left}</b> crate${left===1?'':'s'}</span><i style="--w:${Math.min(100,(HW_PITY-left)/HW_PITY*100)}%"></i></div></div>
  <div class="hwbr"><span class="ccn">You own ${nh}</span><button data-o="h" ${nh?'':'disabled'}>Open</button>${nh>=10?'<button class="sm gd" data-o10="h">Open 10</button>':''}${nh?'':hwOn()?'<small>Find them in Monster Mash or the Candy Stall</small>':''}</div>
  <div class="hwcl"><span>Collection <b>${hwCount()} / 12</b></span>${hwStrip()}</div></div>`:''}
 <div class="chub">${C.map(c=>{const n=P[c[4]]||0;return `<div class="cc${n?'':' e'}" style="--c:${c[3]}"><canvas width="220" height="170" data-c="${c[0]}"></canvas><b>${c[1]}</b><small>${c[2]}</small><span class="ccn">You own ${n}</span><span class="ccb"><button class="sm" data-o="${c[0]}" ${n?'':'disabled'}>Open</button>${n>=10?`<button class="sm gd" data-o10="${c[0]}" title="Open ten at once">Open 10</button>`:''}</span></div>`}).join('')}</div>
 <div class="row"><button class="sm gd" id="sh2">Go to the Shop</button><button class="sm" id="b">Back</button></div>`,'m');
 S.back=title;$('b').onclick=title;$('sh2').onclick=()=>shop();ov.querySelectorAll('[data-o]').forEach(b=>b.onclick=()=>crateStart(b.dataset.o));ov.querySelectorAll('[data-o10]').forEach(b=>b.onclick=()=>crateBatch(b.dataset.o10,10));
 hwThumbs();
 ov.querySelectorAll('canvas[data-c]').forEach(c=>{const g=c.getContext('2d'),ty=c.dataset.c,big=ty==='h';LIVE.push({cv:c,fn:t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,c.width,c.height);try{chest(g,c.width/2,c.height-(big?26:14),big?1.35:1.15,0,ty,t)}catch(e){}},slow:1})})}
/* ----- shop: limited-time Graveyard collection ----- */
function hwShopHTML(){
 const ar=AR.hwreap,wp=WP.hw_scythe,oa=!!P.ownA.hwreap,ow=!!P.own.hw_scythe,ok=hwOn(),g=P.gold;
 const btn=(w,pr,dis,label)=>`<button data-hb="${w}" ${dis||!ok||g<pr?'disabled':''}>${dis?label:ok?`<span class="coin"></span> ${pr.toLocaleString()}`:'Ended'}</button>`;
 const card=(w,nm,sub,desc,cvh,pr,dis,label,wide)=>`<div class="hwc${wide?' bun':''}" style="--c:#ff4d94"><span class="hwlt">LIMITED TIME</span>${cvh}<b>${nm}</b><em>${sub}</em><small>${desc}</small>${w==='b'?`<div class="gab sm" style="--c:#5affb0"><b><i>✦</i>Soul Harvest set</b><span>${GAB.harvest.set.replace('Set bonus: ','')}</span></div>`:gabHTML(w==='a'?AR.hwreap:WP.hw_scythe)}${btn(w,pr,dis,label)}</div>`;
 const bundleDis=oa||ow;
 return `<div class="hwsec"><div class="hwh"><b>Graveyard Collection</b><span class="hwlt">LIMITED TIME</span><small>${ok?hwLeft()+'. Mythic gear only returns if the graveyard wakes again.':'The graveyard has gone quiet. These relics are no longer sold.'}</small></div>
 <div class="hwg">${card('a',ar.n,'Mythic armor set',ar.d,`<canvas width="150" height="190" data-hw="a:hwreap"></canvas>`,HW_PRICE.a,oa,'Owned')}
 ${card('w',wp.n,'Mythic weapon',wp.d,`<canvas width="150" height="190" data-hw="w:hw_scythe"></canvas>`,HW_PRICE.w,ow,'Owned')}
 ${card('b','Reaper Bundle','Armor and weapon together',`Save ${(HW_PRICE.a+HW_PRICE.w-HW_PRICE.b).toLocaleString()} gold over buying both.`,`<span class="hwbc"><canvas width="110" height="140" data-hw="a:hwreap"></canvas><canvas width="110" height="140" data-hw="w:hw_scythe"></canvas></span>`,HW_PRICE.b,bundleDis,oa&&ow?'Owned':'Part owned',1)}</div>
 <div class="hwn2"><b class="hwtxt">Graveyard Crate</b> <span class="hwlt s">LIMITED TIME</span> can be bought with candy corn in Hollow Street. Also win them in Monster Mash: every boss drops one. You own ${P.hcr||0}.</div></div>`}
function hwShopBind(){hwThumbs();ov.querySelectorAll('[data-hb]').forEach(el=>el.onclick=()=>{const w=el.dataset.hb;if(!hwOn())return;const pr=HW_PRICE[w];if(P.gold<pr)return;
  if(w==='a'&&P.ownA.hwreap||w==='w'&&P.own.hw_scythe||w==='b'&&(P.ownA.hwreap||P.own.hw_scythe))return;
  P.gold-=pr;if(w!=='w')P.ownA.hwreap=1;if(w!=='a')P.own.hw_scythe=1;save();beep(880,.12,'triangle',.8);try{beep(1320,.2,'triangle',.7)}catch(e){}
  shop(w==='a'?`Bought ${AR.hwreap.n}. Equip it in the Armory.`:w==='w'?`Bought ${WP.hw_scythe.n}. Equip it in the Armory.`:`Bought the Reaper Bundle: ${AR.hwreap.n} and ${WP.hw_scythe.n}. Equip them in the Armory.`)})}
/* ----- the Monster Mash page ----- */
function gyMenu(back){S.mode='title';S.view='menu';const G=P.gyb||{best:0,lv:0,runs:0,h:0},on=hwOn(),nh=P.hcr||0;
 show(`<div class="gym"><div class="gyhd"><span class="hwlt">LIMITED TIME</span><small>${on?hwLeft():'The graveyard is quiet again'}</small></div><h2 class="hwtxt">Monster Mash</h2>
 <p class="gysub">An Endless run through a haunted cemetery. Each level the graveyard wakes a new curse. Boons, swaps and gear all work as normal, and the dead pay well.</p>
 <div class="gyg">${GY_SEQ.map(k=>{const q=GYC[k];return `<div class="gyk" style="--c:${q.c}"><i>${q.ic}</i><b>${q.n}</b><span>${q.d}</span></div>`}).join('')}</div>
 <p class="gynote">The curses rotate every level: Ghost Letters, Hexed Letter, Vanishing Ink, then round again. Boss rounds are curse-free.</p>
 <div class="gyr"><div><b>+35%</b><span>gold</span></div><div><b>+30%</b><span>XP</span></div><div><b>1 per boss</b><span>Graveyard crate</span></div><div><b>${G.lv||'<span class="nrec">No record yet</span>'}</b><span>deepest level</span></div><div><b>${(G.best||0).toLocaleString()}</b><span>best score</span></div></div>
 <div class="row"><button id="gyg" ${on?'':'disabled'}>${on?'Enter the Mash':'Event ended'}</button><button class="sm gd" id="gyc">Crates${nh?` (${nh})`:''}</button><button class="sm" id="b">Back</button></div></div>`,'m');
 S.back=back||title;$('b').onclick=S.back;$('gyg').onclick=()=>{if(hwOn())start(0,'gy')};$('gyc').onclick=()=>crateHub()}
/* thumbnails for the home cards */
const gyThumb=()=>sceneShot(GYLV[0],640,480,'g');
const GY_HOME=['gyjack','bhorse','bpumpking','gywitch','gyvamp','bhexmire'];
const gyHomeMon=()=>GY_HOME[(Date.now()/9e4|0)%GY_HOME.length];
