/* ---------- casino: Nebula Scratch (the Act VI launch special) ----------
   Buy a ticket, scratch one big foil sheet with the mouse or a finger and match three symbols to win.
   Each ticket also hides a Lucky Star medallion that can double or triple a win.
   Every ticket is decided the moment it is bought (an honest prize table, no "pity" tricks).
   Odds: the eight symbols share one base table, scaled per card so every card returns exactly 96%:
     Stardust  50: 1,2,3,5,10,25,100,1000x   Nebula 250: 1,2,3,5,10,25,100,400x   Supernova 1,000: 1,2,3,5,10,20,50,100x
   Lucky Star: x2 on 8% of tickets, x3 on 3%. No single ticket ever pays more than 100,000 coins.
   Daily gift: one free Stardust ticket per day. Constellation: every 25 paid tickets gives a free one.
   Act VI launch week (until the end of Oct 15, 2026): every prize pays x1.25, about a 120% return. */
const NS={T:[{id:'sd',n:'Stardust',p:50,c:'#6ac8ff',c2:'#2a5cd0',c3:'#0c1a4a',m:[1,2,3,5,10,25,100,1000]},{id:'nb',n:'Nebula',p:250,c:'#d08aff',c2:'#7a2ad8',c3:'#24083e',m:[1,2,3,5,10,25,100,400]},{id:'sn',n:'Supernova',p:1000,c:'#ffc04a',c2:'#e0581a',c3:'#3a1004',m:[1,2,3,5,10,20,50,100]}],
 SY:[{k:'dust',pl:'Stardusts',n:'Stardust',p:.19,c:'#9ff0ff'},{k:'moon',pl:'Moons',n:'Moon',p:.09,c:'#b8c8ff'},{k:'comet',pl:'Comets',n:'Comet',p:.04,c:'#5ae8d8'},{k:'planet',pl:'Ringed Planets',n:'Ringed Planet',p:.027,c:'#d08aff'},
  {k:'sun',pl:'Suns',n:'Sun',p:.0115,c:'#ffb02a'},{k:'galaxy',pl:'Galaxies',n:'Galaxy',p:.004,c:'#ff6ac8'},{k:'hole',pl:'Black Holes',n:'Black Hole',p:.0006,c:'#ff8a3a'},{k:'nova',pl:'Supernovas',n:'Supernova',p:.00006,c:'#fff2a0'}],
 LUCK:[[3,.03],[2,.08]],CAP:100000,RTP:.96,
 BOOST:1.25,BOOST_END:new Date(2026,9,15,23,59,59).getTime(),METER:25,CELLS:6};
const nsNow=()=>window.__nsNow||Date.now();
const nsBoost=()=>nsNow()<=NS.BOOST_END;
const nsMul=(m,b)=>b?Math.round(m*NS.BOOST*100)/100:m;
/* the coins one ticket pays: symbol multiplier, launch boost, Lucky Star, then the cap */
const nsPay=(price,m,b,ls)=>Math.min(NS.CAP,Math.floor(price*nsMul(m,b)*(ls||1)+1e-6));
/* scale each card's odds so it returns exactly NS.RTP (the cap and the Lucky Star are included) */
{const L1=1-NS.LUCK.reduce((a,l)=>a+l[1],0);for(const T of NS.T){let r=0;NS.SY.forEach((y,i)=>{let e=L1*Math.min(NS.CAP,T.p*T.m[i]);for(const [l,q] of NS.LUCK)e+=q*Math.min(NS.CAP,T.p*T.m[i]*l);r+=y.p*e/T.p});T.k=NS.RTP/r;T.win=T.k*NS.SY.reduce((a,y)=>a+y.p,0)}}
const nsFm=m=>(+(+m).toFixed(2)).toLocaleString();
if(typeof CanvasRenderingContext2D!=='undefined'&&!CanvasRenderingContext2D.prototype.roundRect)CanvasRenderingContext2D.prototype.roundRect=function(x,y,w,h,r){r=Math.min(r,w/2,h/2);this.moveTo(x+r,y);this.arcTo(x+w,y,x+w,y+h,r);this.arcTo(x+w,y+h,x,y+h,r);this.arcTo(x,y+h,x,y,r);this.arcTo(x,y,x+w,y,r);this.closePath();return this};
const nsOdds=p=>{const n=1/p;return '1 in '+(n<10?n.toFixed(1):cmn(Math.round(n)))};
const nsSt=()=>{const c=cst(),s=c.ns=c.ns&&typeof c.ns==='object'?c.ns:{};for(const k of['cards','wins','won','spent','best','bestM','meter','free','big','stars'])s[k]=+s[k]||0;if(!Array.isArray(s.hist))s.hist=[];return s};
const nsLeft=()=>{const ms=Math.max(0,NS.BOOST_END-nsNow()),d=Math.floor(ms/864e5),h=Math.floor(ms%864e5/36e5),m=Math.floor(ms%36e5/6e4);return d>0?`${d}d ${h}h`:`${h}h ${String(m).padStart(2,'0')}m`};
const nsToday=()=>{const d=new Date(nsNow());return d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate()};
const nsGiftLeft=()=>{const n=new Date(nsNow()),e=new Date(n.getFullYear(),n.getMonth(),n.getDate()+1),ms=e-n;return Math.floor(ms/36e5)+'h '+String(Math.floor(ms%36e5/6e4)).padStart(2,'0')+'m'};
const nsShuf=a=>{for(let i=a.length-1;i>0;i--){const j=Math.random()*(i+1)|0;[a[i],a[j]]=[a[j],a[i]]}return a};
/* roll one ticket: the winning symbol index, or -1 */
function nsRoll(t){if(window.__nsForce!=null)return window.__nsForce;const k=NS.T[t].k;let q=Math.random();for(let i=NS.SY.length-1;i>=0;i--){q-=NS.SY[i].p*k;if(q<0)return i}return -1}
function nsLuck(){if(window.__nsLuck!=null)return window.__nsLuck;let q=Math.random();for(const [l,p] of NS.LUCK){q-=p;if(q<0)return l}return 1}
/* lay out six symbols for a result. Never two triples, and losing tickets often carry a pair of something big */
function nsLayout(w){const N=NS.SY.length,all=[...Array(N).keys()],pick=a=>a[Math.random()*a.length|0];
 const lead=ex=>{const hi=all.filter(i=>i>=4&&!ex.includes(i)),rest=all.filter(i=>!ex.includes(i));return Math.random()<.5&&hi.length?pick(hi):pick(rest)};
 let c=[];if(w>=0){c=[w,w,w];const a=lead([w]);if(Math.random()<.6){const b=pick(all.filter(i=>i!==w&&i!==a));c.push(a,a,b)}else c.push(a,...nsShuf(all.filter(i=>i!==w&&i!==a)).slice(0,2))}
 else{const a=lead([]),o=nsShuf(all.filter(i=>i!==a));c=Math.random()<.6?[a,a,o[0],o[0],o[1],o[1]]:[a,a,o[0],o[0],o[1],o[2]]}
 return nsShuf(c)}
const nsCard=(t,free)=>{const w=nsRoll(t);return{t,w,ls:nsLuck(),b:nsBoost()?1:0,f:free||0,c:nsLayout(w)}};
/* what a finished ticket pays, and its multiple of the card price */
const nsResult=c=>{const T=NS.T[c.t];if(!(c.w>=0))return{pay:0,m:0,x:0};const pay=nsPay(T.p,T.m[c.w],c.b,c.ls);return{pay,m:T.m[c.w],x:pay/T.p}};

let NSU=0;
/* the eight symbols: painted like the rest of the game, a dark ink outline, layered gradients, a rim light and a few sparkles */
function nsSym(k,sz){const u='nsg'+(NSU++),s=sz||100,O='#150c1c';const W=b=>`<svg viewBox="-50 -50 100 100" width="${s}" height="${s}" aria-hidden="true">${b}</svg>`;
 const sp=(x,y,r,f,o)=>`<path d="M${x} ${y-r}Q${x+r*.16} ${y-r*.16} ${x+r} ${y}Q${x+r*.16} ${y+r*.16} ${x} ${y+r}Q${x-r*.16} ${y+r*.16} ${x-r} ${y}Q${x-r*.16} ${y-r*.16} ${x} ${y-r}z" fill="${f}"${o?` stroke="${O}" stroke-width="${o}" stroke-linejoin="round"`:''}/>`;
 const halo=(c,r,o)=>`<radialGradient id="${u}h"><stop offset="0" stop-color="${c}" stop-opacity="${o||.55}"/><stop offset="1" stop-color="${c}" stop-opacity="0"/></radialGradient>`;
 switch(k){
 case'dust':return W(`<defs>${halo('#5ad8ff',48,.6)}<radialGradient id="${u}a" cx=".4" cy=".35"><stop offset="0" stop-color="#ffffff"/><stop offset=".55" stop-color="#bff4ff"/><stop offset="1" stop-color="#3aa8e8"/></radialGradient></defs>
  <circle r="46" fill="url(#${u}h)"/>${[[24,-26],[-30,18],[30,24],[-22,-30],[6,34]].map(([x,y],i)=>`<circle cx="${x}" cy="${y}" r="${1.4+(i%2)}" fill="#e8fbff"/>`).join('')}
  ${sp(-4,-2,32,`url(#${u}a)`,3)}${sp(20,-22,13,'#9ff0ff',2.4)}${sp(22,20,10,'#d8f6ff',2.2)}${sp(-26,22,8,'#ffffff',2)}${sp(-4,-2,12,'#ffffff')}<path d="M-4 -26Q-2 -6 8 -4" fill="none" stroke="#fff" stroke-width="2" opacity=".7" stroke-linecap="round"/>`);
 case'moon':return W(`<defs>${halo('#9fb2ff',48)}<radialGradient id="${u}a" cx=".32" cy=".3"><stop offset="0" stop-color="#ffffff"/><stop offset=".5" stop-color="#d4dcff"/><stop offset="1" stop-color="#6a78c8"/></radialGradient><mask id="${u}m"><rect x="-50" y="-50" width="100" height="100" fill="#fff"/><circle cx="17" cy="-11" r="27" fill="#000"/></mask><mask id="${u}o"><rect x="-50" y="-50" width="100" height="100" fill="#fff"/><circle cx="17" cy="-11" r="24" fill="#000"/></mask></defs>
  <circle r="47" fill="url(#${u}h)"/><g mask="url(#${u}o)"><circle r="37" fill="${O}"/></g><g mask="url(#${u}m)"><circle r="34" fill="url(#${u}a)"/><circle cx="-18" cy="8" r="7" fill="#8a98e0" opacity=".75" stroke="#5a66b0" stroke-width="1.5"/><circle cx="-6" cy="24" r="4.5" fill="#8a98e0" opacity=".7"/><circle cx="-24" cy="-10" r="4" fill="#8a98e0" opacity=".7"/><path d="M-14 -28Q-32 -16 -30 6" fill="none" stroke="#fff" stroke-width="3" opacity=".75" stroke-linecap="round"/></g>
  ${sp(26,8,8,'#fff2b0',1.6)}${sp(36,-26,5,'#ffffff')}`);
 case'comet':return W(`<defs>${halo('#5ae8d8',46)}<linearGradient id="${u}t" x1="1" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#5ae8d8" stop-opacity="0"/><stop offset=".7" stop-color="#7ff6e8" stop-opacity=".85"/><stop offset="1" stop-color="#e8fffb"/></linearGradient><radialGradient id="${u}n" cx=".38" cy=".35"><stop offset="0" stop-color="#ffffff"/><stop offset=".5" stop-color="#8ff8ea"/><stop offset="1" stop-color="#138a9a"/></radialGradient></defs>
  <circle cx="-14" cy="14" r="40" fill="url(#${u}h)"/><path d="M46 -46L0 2L-14 -12z" fill="url(#${u}t)"/><path d="M46 -26L6 12L-4 -2z" fill="url(#${u}t)" opacity=".75"/><path d="M26 -46L-10 -8L-20 -16z" fill="url(#${u}t)" opacity=".65"/>
  ${[[30,-30],[20,-38],[38,-14]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="1.8" fill="#e8fffb"/>`).join('')}
  <circle cx="-16" cy="16" r="21" fill="url(#${u}n)" stroke="${O}" stroke-width="3.2"/><path d="M-30 8Q-28 -2 -18 -4" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity=".85"/><circle cx="-10" cy="22" r="3.5" fill="#138a9a" opacity=".5"/>`);
 case'planet':return W(`<defs>${halo('#c86bff',48,.45)}<radialGradient id="${u}a" cx=".34" cy=".3"><stop offset="0" stop-color="#ffe0ff"/><stop offset=".45" stop-color="#c070f8"/><stop offset="1" stop-color="#3a0e80"/></radialGradient><linearGradient id="${u}r" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#a8742c"/><stop offset=".5" stop-color="#fff0a0"/><stop offset="1" stop-color="#a8742c"/></linearGradient><clipPath id="${u}c"><circle r="27"/></clipPath></defs>
  <circle r="48" fill="url(#${u}h)"/><path d="M-46 7.5A47 13 0 0 1 46 -7.5" transform="rotate(-16)" fill="none" stroke="${O}" stroke-width="8.5"/><path d="M-46 7.5A47 13 0 0 1 46 -7.5" transform="rotate(-16)" fill="none" stroke="url(#${u}r)" stroke-width="5"/>
  <circle r="27" fill="url(#${u}a)" stroke="${O}" stroke-width="3.2"/><g clip-path="url(#${u}c)" fill="none" stroke-width="4" opacity=".55"><path d="M-30 -8c16 7 40 7 60 -2" stroke="#f0c0ff"/><path d="M-30 6c16 6 40 6 60 -1" stroke="#7a2ad8"/><path d="M-30 16c16 5 40 5 60 0" stroke="#e8a0ff"/></g><path d="M-18 -16Q-10 -24 2 -24" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity=".8"/>
  <path d="M-46 7.5A47 13 0 0 0 46 -7.5" transform="rotate(-16)" fill="none" stroke="${O}" stroke-width="8.5"/><path d="M-46 7.5A47 13 0 0 0 46 -7.5" transform="rotate(-16)" fill="none" stroke="url(#${u}r)" stroke-width="5"/><path d="M-40 9A47 13 0 0 0 10 4" transform="rotate(-16)" fill="none" stroke="#fffbe0" stroke-width="1.5"/>${sp(34,-30,6,'#fff')}`);
 case'sun':return W(`<defs>${halo('#ffb02a',49,.7)}<radialGradient id="${u}a" cx=".38" cy=".34"><stop offset="0" stop-color="#fffbe0"/><stop offset=".45" stop-color="#ffd040"/><stop offset="1" stop-color="#e0560e"/></radialGradient><linearGradient id="${u}r" x1="0" y1="-1" x2="0" y2="0"><stop offset="0" stop-color="#ffe27a"/><stop offset="1" stop-color="#ff8a1a"/></linearGradient></defs>
  <circle r="49" fill="url(#${u}h)"/>${Array.from({length:12},(_,i)=>`<path d="M0 -46L6.5 -27L-6.5 -27z" fill="url(#${u}r)" stroke="${O}" stroke-width="2.2" stroke-linejoin="round" transform="rotate(${i*30})"/>`).join('')}
  ${Array.from({length:12},(_,i)=>`<path d="M0 -36L4 -26L-4 -26z" fill="#fff2b0" transform="rotate(${i*30+15})"/>`).join('')}<circle r="25" fill="url(#${u}a)" stroke="${O}" stroke-width="3.2"/><circle r="18" fill="none" stroke="#fff2b0" stroke-width="1.5" opacity=".6"/><path d="M-14 -10Q-8 -18 2 -18" fill="none" stroke="#fff" stroke-width="3.2" stroke-linecap="round" opacity=".85"/>`);
 case'galaxy':return W(`<defs>${halo('#ff6ac8',48,.5)}<radialGradient id="${u}a"><stop offset="0" stop-color="#ffffff"/><stop offset=".3" stop-color="#ffe0f4"/><stop offset="1" stop-color="#ff3ab0" stop-opacity="0"/></radialGradient><linearGradient id="${u}p" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffb0e8"/><stop offset="1" stop-color="#c040b0"/></linearGradient><linearGradient id="${u}v" x1="1" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#c8b0ff"/><stop offset="1" stop-color="#5a3ad8"/></linearGradient></defs>
  <circle r="48" fill="url(#${u}h)"/><g transform="rotate(-20)" fill="none" stroke-linecap="round"><path d="M0 0C10 -20 36 -16 40 4C44 24 22 38 2 36" stroke="${O}" stroke-width="12"/><path d="M0 0C-10 20 -36 16 -40 -4C-44 -24 -22 -38 -2 -36" stroke="${O}" stroke-width="12"/>
  <path d="M0 0C10 -20 36 -16 40 4C44 24 22 38 2 36" stroke="url(#${u}p)" stroke-width="7.5"/><path d="M0 0C-10 20 -36 16 -40 -4C-44 -24 -22 -38 -2 -36" stroke="url(#${u}v)" stroke-width="7.5"/><path d="M4 -6C14 -18 30 -14 34 0" stroke="#fff" stroke-width="2" opacity=".75"/><path d="M-4 6C-14 18 -30 14 -34 0" stroke="#fff" stroke-width="2" opacity=".75"/></g>
  ${[[22,-10],[-18,12],[10,22],[-12,-20],[30,18],[-30,-14]].map(([x,y],i)=>`<circle cx="${x}" cy="${y}" r="${1.2+(i%3)*.6}" fill="#fff"/>`).join('')}<circle r="17" fill="url(#${u}a)"/><circle r="6" fill="#fff"/>${sp(36,-34,5,'#fff')}${sp(-38,32,4,'#fff')}`);
 case'hole':return W(`<defs><radialGradient id="${u}g"><stop offset=".42" stop-color="#ff8a2a" stop-opacity=".0"/><stop offset=".55" stop-color="#ff8a2a" stop-opacity=".9"/><stop offset=".66" stop-color="#ffe08a"/><stop offset=".78" stop-color="#ff5a1a" stop-opacity=".6"/><stop offset="1" stop-color="#7a0a4a" stop-opacity="0"/></radialGradient><linearGradient id="${u}d" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ff5a1a"/><stop offset=".5" stop-color="#fff0b0"/><stop offset="1" stop-color="#ff7a2a"/></linearGradient></defs>
  <circle r="49" fill="url(#${u}g)"/><ellipse rx="46" ry="10" transform="rotate(-12)" fill="none" stroke="${O}" stroke-width="9"/><ellipse rx="46" ry="10" transform="rotate(-12)" fill="none" stroke="url(#${u}d)" stroke-width="5.5"/>
  <circle r="21" fill="#000" stroke="${O}" stroke-width="3"/><circle r="22.5" fill="none" stroke="#ffd27a" stroke-width="2.2"/><circle r="25" fill="none" stroke="#ffb04a" stroke-width="1" opacity=".6"/>
  <path d="M-46 4A46 10 0 0 0 46 -4" transform="rotate(-12)" fill="none" stroke="${O}" stroke-width="9"/><path d="M-46 4A46 10 0 0 0 46 -4" transform="rotate(-12)" fill="none" stroke="url(#${u}d)" stroke-width="5.5"/><path d="M-40 5A46 10 0 0 0 6 6" transform="rotate(-12)" fill="none" stroke="#fffbe0" stroke-width="1.6"/>${sp(32,-30,5,'#ffe0b0')}`);
 case'nova':return W(`<defs><radialGradient id="${u}a"><stop offset="0" stop-color="#fff"/><stop offset=".28" stop-color="#fff6c0"/><stop offset=".55" stop-color="#ffb04a" stop-opacity=".7"/><stop offset=".8" stop-color="#ff3ab0" stop-opacity=".3"/><stop offset="1" stop-color="#5a2ad8" stop-opacity="0"/></radialGradient></defs>
  <circle r="49" fill="url(#${u}a)"/><circle r="40" fill="none" stroke="#9ff0ff" stroke-width="1.5" stroke-dasharray="2 6" opacity=".8"/>
  ${Array.from({length:16},(_,i)=>`<path d="M0 -${i%2?31:47}L4 -12L-4 -12z" fill="${['#ffffff','#ffe27a','#9ff0ff','#ff9ad8'][i%4]}" stroke="${O}" stroke-width="1.6" stroke-linejoin="round" transform="rotate(${i*22.5})"/>`).join('')}
  ${sp(0,0,22,'#ffffff',2.6)}<circle r="9" fill="#fffbe0"/><circle r="9" fill="none" stroke="#ffd24a" stroke-width="1.5"/>`)}
 return W('')}

/* ---------- lobby: tile art, the feature card and the Special tab switch ---------- */
TCAT.ns='special';
TA.ns=(()=>{const st=Array.from({length:26},(_,i)=>`<circle cx="${(i*73)%320}" cy="${(i*47)%176}" r="${1+(i%3)*.6}" fill="#fff" opacity="${.35+(i%4)*.15}"/>`).join('');
 const cell=(x,y,k,foil)=>foil?`<g transform="translate(${x} ${y})"><rect x="-24" y="-24" width="48" height="48" rx="8" fill="url(#nsxf)" stroke="#ffffff88" stroke-width="1.5"/><path d="M-10 -2l6 0 0 -6" stroke="#ffffff99" stroke-width="2" fill="none"/></g>`:`<g transform="translate(${x} ${y})"><rect x="-24" y="-24" width="48" height="48" rx="8" fill="#140a34" stroke="${k==='sun'?'#ffd24a':'#ffffff33'}" stroke-width="${k==='sun'?3:1.5}"/><g transform="scale(.42)">${nsSym(k,100).replace(/<\/?svg[^>]*>/g,'')}</g></g>`;
 return `<svg viewBox="0 0 320 176" preserveAspectRatio="xMidYMid slice"><defs><radialGradient id="nsxb" cx=".3" cy=".3" r="1"><stop offset="0" stop-color="#7a2ad8"/><stop offset=".5" stop-color="#2a0a5a"/><stop offset="1" stop-color="#08031a"/></radialGradient><radialGradient id="nsxn" cx=".8" cy=".7" r=".6"><stop offset="0" stop-color="#ff5ab8" stop-opacity=".55"/><stop offset="1" stop-color="#ff5ab8" stop-opacity="0"/></radialGradient><linearGradient id="nsxf" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#9aa4c8"/><stop offset=".5" stop-color="#eef0ff"/><stop offset="1" stop-color="#7c86ac"/></linearGradient><linearGradient id="nsxc" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#5a2ab0"/><stop offset="1" stop-color="#1a0a48"/></linearGradient></defs>
 <rect width="320" height="176" fill="url(#nsxb)"/><rect width="320" height="176" fill="url(#nsxn)"/>${st}
 <g transform="translate(160 92) rotate(-6)"><rect x="-96" y="-74" width="192" height="148" rx="14" fill="url(#nsxc)" stroke="#d08aff" stroke-width="3"/><text y="-52" text-anchor="middle" font-family="Georgia" font-size="15" fill="#ffd24a" letter-spacing="2">NEBULA CARD</text>
 ${cell(-56,-14,'sun')}${cell(0,-14,'moon')}${cell(56,-14,'sun')}${cell(-56,40,'',1)}${cell(0,40,'sun')}${cell(56,40,'',1)}</g>
 <g transform="translate(262 40) rotate(18)"><circle r="15" fill="#ffc94a" stroke="#8a5a08" stroke-width="3"/><circle r="9" fill="none" stroke="#b8780c" stroke-width="2"/></g></svg>`})();
GAMES.unshift({id:'ns',n:'Nebula Scratch',d:'Buy a scratch ticket, scratch the foil and match three symbols to win. A hidden Lucky Star can double or triple your prize. Tickets from 50 to 1,000 gold, prizes up to 100,000.',m:(e,t)=>mNS(e,t)});
A('ns1','Casino',1,'Stargazer','Scratch 25 tickets in Nebula Scratch.',25,()=>AS('nsc'),200);
A('ns2','Casino',2,'Galactic Luck','Win 25 times your ticket or more in Nebula Scratch.',25,()=>AS('nsm'),800,1);
A('ns3','Casino',3,'Event Horizon','Match three Black Holes or Supernovas.',1,()=>AS('nsbh'),3000,2);
A('ns4','Casino',2,'Wish Upon a Star','Win with a Lucky Star on your ticket.',1,()=>AS('nsls'),600,1);

function nsFeat(){const b=nsBoost(),S2=nsSt(),gift=S2.day!==nsToday();
 return `<div class="twfeat nsfeat${b?' boost':''}"><button class="twfart" data-g="ns" aria-label="Play Nebula Scratch"><span class="twfa">${TA.ns}</span><i class="co c1"></i><i class="co c2"></i><i class="co c3"></i><i class="co c4"></i>${b?'<span class="twrib nsrib">LAUNCH WEEK</span>':''}</button>
 <div class="twfinfo"><div class="twfk">${b?'<span class="twbadge nsbadge">ACT VI BOOST · PRIZES +25%</span>':'<span class="twbadge dim">NOW OPEN</span>'}<span class="twnew">NEW</span>${gift?'<span class="twnew nsgiftb">FREE TICKET TODAY</span>':''}</div>
 <h3>Nebula Scratch</h3>
 <p>Scratch the foil, match three symbols and hope the Lucky Star doubles or triples your prize.</p>
 <ul class="twfl"><li><b>Tickets</b> Stardust 50, Nebula 250, Supernova 1,000</li><li><b>Prizes</b> up to ${cmn(NS.CAP)} coins · about 1 in 3 tickets wins</li><li><b>Free tickets</b> one every day, plus one for every 25 you scratch</li></ul>
 ${b?`<div class="twboost nsboost"><span class="twsp"></span><div><b>Act VI launch week: every prize pays 25% more</b><small>Boost ends in <span id="nscd">${nsLeft()}</span>.</small></div></div>`:''}</div>
 <div class="twfside"><div class="twfs"><span>Tickets scratched</span><b>${cmn(S2.cards)}</b></div><div class="twfs"><span>Best win</span><b>${S2.best?cmn(S2.best):'None yet'}</b></div><div class="twfs"><span>Constellation</span><b>${S2.meter} / ${NS.METER}</b></div><button class="twplay" data-g="ns">Play now</button></div></div>`}
/* the Special tab now holds two features: a switch picks which one is shown, Nebula first while it is new */
{const tw0=twLobby;twLobby=function(){const sp=CAS.sp||'ns';if(sp==='tw')tw0();else{const g=$('gdgrid'),tok=CAS.tok;g.className='gdgrid twspecial';g.innerHTML=nsFeat();g.querySelectorAll('[data-g]').forEach(x=>x.onclick=()=>gameOpen('ns'));
   if(nsBoost()){const iv=setInterval(()=>{const e=$('nscd');if(!e||CAS.tok!==tok){clearInterval(iv);return}e.textContent=nsLeft()},20000)}}
  const g=$('gdgrid'),sw=document.createElement('div');sw.className='nssw';sw.innerHTML=`<button data-sp="ns" class="${sp==='ns'?'on':''}"><i class="nsdot"></i>Nebula Scratch<em>NEW</em></button><button data-sp="tw" class="${sp==='tw'?'on':''}">Tower Climb</button>`;g.appendChild(sw);
  sw.querySelectorAll('button').forEach(b=>b.onclick=e=>{e.stopPropagation();if(b.dataset.sp===(CAS.sp||'ns'))return;CAS.sp=b.dataset.sp;beep(620,.05,'triangle',.5);twLobby()})}}

/* ---------- Nebula Scratch score: "Starlight Lullaby", a dreamy D minor waltz of music box, pads and bells ----------
   16 bars, loops. Idle: pads, a music-box arpeggio and twinkling bells. A ticket in play adds a soft bass, brushed percussion and the melody.
   Two big matching symbols lift it into a tense, pulsing variation until the ticket is settled. */
var NZM={on:0,tok:-1,lv:0,s:0,n0:0};
function nzMusic(){return NZM.on&&CAS.on&&NZM.tok===CAS.tok}
function nzBpm(){return [86,96,106][NZM.lv]||96}
const NZR=[0,-4,5,7,0,3,-2,7,-4,3,5,0,-4,-2,7,7],NZQ='mMmMmMMMMMmmMMMM';
const NZMEL=[[[0,31,3],[3,29,1],[4,27,2],[6,26,2]],[[0,26,3],[3,27,1],[4,29,4]],[[0,34,3],[3,32,1],[4,31,2],[6,29,2]],[[0,31,2],[2,35,2],[4,38,4]],
 [[0,36,3],[3,34,1],[4,31,4]],[[0,27,2],[2,31,2],[4,36,4]],[[0,34,3],[3,31,1],[4,29,4]],[[0,31,4],[4,28,4]],
 [[0,26,2],[2,29,2],[4,32,4]],[[0,36,3],[3,34,1],[4,31,4]],[[0,29,2],[2,32,2],[4,34,2],[6,36,2]],[[0,38,6],[6,36,2]],
 [[0,34,3],[3,32,1],[4,29,4]],[[0,31,3],[3,34,1],[4,36,4]],[[0,37,4],[4,40,4]],[[0,31,8]]];
function nzScore(t,n0){if(!NZM.s){NZM.s=1;NZM.n0=n0}KS.on=0;const n=n0-NZM.n0,B=kInit(),bar=(n>>3)&15,k=n&7,sd=stepD(),bl=sd*8,r=NZR[bar],th=NZQ[bar]==='m'?3:4,F=m=>fq(m),lv=NZM.lv;
 /* pad: soft detuned sines and triangles on every chord */
 if(k===0)for(const iv of [r+12,r+12+th,r+19,r+24])kv(t,F(iv),bl*.98,{ty:['sine','triangle'],det:[-7,7],lp:1300+lv*300,a:.5,r:.7,v:lv===2?.016:.013,bus:B.st});
 /* the music box: a rolling arpeggio two octaves up */
 const fig=[0,7,12,th+12,19,12,7,th+12][k];if(lv>0||k%2===0)kv(t,F(r+24+fig+(bar%4===3&&k>4?12:0)),sd*1.6,{ty:['triangle','sine'],mul:[1,2],lp:5200,a:.004,r:.35,v:lv?.02:.016,bus:B.st,f0:.8});
 /* twinkling bells */
 if(k===7&&bar%2===1)kv(t,F(r+36+[0,th,7][(bar>>1)%3]),sd*3,{ty:['sine'],lp:8000,a:.005,r:.9,v:.016,vib:9,bus:B.ch});
 if(lv===0)return;
 /* soft bass and brushed percussion */
 if(k===0||k===5)kv(t,F(r),sd*(k?2.4:3.6),{ty:['sine','triangle'],mul:[1,2],lp:420,a:.01,r:.2,v:.06,bus:B.br});
 if(k===0||k===4)ktaiko(t,lv===2?.55:.38,F(r)*1.1);
 if(k===2||k===6)kns(t,.06,.03,4200,'bandpass',B.pc,.9);
 if(k%2===1)kns(t,.03,.018,8000,'highpass',B.pc);
 /* the melody: a celesta lead, doubled an octave up when the tension rises */
 for(const [st,p,len] of NZMEL[bar]){if(st!==k)continue;const d=len*sd*.95;kv(t,F(p),d,{ty:['sine','triangle'],mul:[1,2],det:[0,4],lp:3800,a:.012,r:.3,v:.034,vib:6,bus:B.ch});if(lv===2)kv(t,F(p+12),d,{ty:['triangle'],lp:5200,a:.01,r:.25,v:.014,bus:B.st})}
 /* tension: a pulsing low string and a high shimmer while two big symbols wait for a third */
 if(lv===2){kv(t,F(r+12),sd*.8,{ty:['sawtooth'],lp:700,a:.01,r:.08,v:.022,bus:B.br});if(k%2===0)kv(t,F(r+31+(k%4?th:0)),sd*.9,{ty:['sine'],lp:9000,a:.005,r:.2,v:.01,bus:B.st})}}
{const n0=note;note=function(t,n){if(nzMusic())return nzScore(t,n);if(NZM.s)NZM.s=0;return n0(t,n)}}
/* ---------- the game ---------- */
/* ticket icons: a little scalloped ticket in the tier's colours with its own emblem */
const nsTk=i=>{const T=NS.T[i],em=[`<path d="M0 -8.5l2.3 6.2 6.2 2.3-6.2 2.3L0 8.5l-2.3-6.2-6.2-2.3 6.2-2.3z" fill="#fff6d0" stroke="#150c1c" stroke-width="1.1" stroke-linejoin="round"/>`,`<path d="M0 0c3-5 9-4 9 1s-5 8-9 6M0 0c-3 5-9 4-9-1s5-8 9-6" fill="none" stroke="#150c1c" stroke-width="4" stroke-linecap="round"/><path d="M0 0c3-5 9-4 9 1s-5 8-9 6M0 0c-3 5-9 4-9-1s5-8 9-6" fill="none" stroke="#ffd8ff" stroke-width="2.2" stroke-linecap="round"/><circle r="2.4" fill="#fff"/>`,`${Array.from({length:8},(_,k)=>`<path d="M0 -${k%2?6:10}L1.8 -2.5L-1.8 -2.5z" fill="${k%2?'#ffe27a':'#fff6d0'}" stroke="#150c1c" stroke-width=".9" transform="rotate(${k*45})"/>`).join('')}<circle r="3.4" fill="#fff" stroke="#150c1c" stroke-width="1"/>`][i];
 return `<svg viewBox="0 0 44 30" aria-hidden="true"><defs><linearGradient id="nstk${i}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${T.c}"/><stop offset=".55" stop-color="${T.c2}"/><stop offset="1" stop-color="${T.c3}"/></linearGradient></defs><path d="M3 2h38a2 2 0 0 1 2 2v5a3.2 3.2 0 0 0 0 6.4v1.2a3.2 3.2 0 0 0 0 6.4V26a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2v-3a3.2 3.2 0 0 0 0-6.4v-1.2a3.2 3.2 0 0 0 0-6.4V4a2 2 0 0 1 2-2z" fill="url(#nstk${i})" stroke="#150c1c" stroke-width="1.6" stroke-linejoin="round"/><rect x="5" y="5.5" width="34" height="19" rx="3" fill="none" stroke="#ffe7a0" stroke-width="1" stroke-dasharray="2 2" opacity=".8"/><path d="M6 5.5h12" stroke="#ffffff" stroke-width="1.4" opacity=".55" stroke-linecap="round"/><g transform="translate(22 15)">${em}</g></svg>`};
{const b0=bigWin;bigWin=function(){if(window.__nzbw)return;return b0.apply(this,arguments)}}
const NS_ICON={grid:'<svg viewBox="0 0 30 22" aria-hidden="true"><rect x=".5" y=".5" width="29" height="21" rx="4" fill="var(--c2)" stroke="var(--c)"/>'+[0,1,2].map(i=>[0,1].map(j=>`<rect x="${4+i*8}" y="${3.5+j*8}" width="6" height="6" rx="1.4" fill="#eef0ff"/>`).join('')).join('')+'</svg>',
 coin:'<i class="coin"></i>',
 cup:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 3h10v5a5 5 0 0 1-10 0z" fill="#ffd24a" stroke="#6a4208" stroke-width="1.3"/><path d="M7 5H3c0 4 2 5 4.6 5.4M17 5h4c0 4-2 5-4.6 5.4" fill="none" stroke="#ffd24a" stroke-width="1.8"/><path d="M10.5 13h3v4h-3zM8 17h8v3H8z" fill="#ffd24a" stroke="#6a4208" stroke-width="1.2"/></svg>',
 book:'<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M3 5c3-1 6-1 9 1 3-2 6-2 9-1v14c-3-1-6-1-9 1-3-2-6-2-9-1z"/><path d="M12 6v14"/></svg>',
 bars:'<svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor"><rect x="3" y="12" width="4" height="9" rx="1"/><rect x="10" y="7" width="4" height="14" rx="1"/><rect x="17" y="3" width="4" height="18" rx="1"/></svg>',
 gift:'<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="9" width="18" height="12" rx="2" fill="#c86bff" stroke="#3a0a5a" stroke-width="1.4"/><rect x="2" y="6" width="20" height="5" rx="1.5" fill="#e0a0ff" stroke="#3a0a5a" stroke-width="1.4"/><path d="M12 6v15" stroke="#ffd24a" stroke-width="3"/><path d="M12 6c-2-4-7-4-6-1 1 2 4 1 6 1zM12 6c2-4 7-4 6-1-1 2-4 1-6 1z" fill="#ffd24a" stroke="#6a4208" stroke-width="1.2"/></svg>',
 star:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 1l2.2 8.8L23 12l-8.8 2.2L12 23l-2.2-8.8L1 12l8.8-2.2z" fill="#ffd24a" stroke="#7a4a08" stroke-width="1"/></svg>',
 moon:'<svg viewBox="-50 -50 100 100" aria-hidden="true"><defs><radialGradient id="nzmg" cx=".35" cy=".35"><stop offset="0" stop-color="#fff8d8"/><stop offset="1" stop-color="#d8a83a"/></radialGradient></defs><circle r="44" fill="none" stroke="#e8c36a" stroke-width="3"/><circle r="36" fill="none" stroke="#e8c36a88" stroke-width="1.5" stroke-dasharray="3 5"/><path d="M8 -26A26 26 0 1 0 8 26A20 20 0 1 1 8 -26z" fill="url(#nzmg)" stroke="#6a4208" stroke-width="2"/><path d="M22 -8l2 6 6 2-6 2-2 6-2-6-6-2 6-2z" fill="#fff2b0"/></svg>'};
function mNS(el,tok){
 const alive=()=>CAS.tok===tok,rm=matchMedia('(prefers-reduced-motion: reduce)').matches,K=rm?.35:1,wait=ms=>csleep(ms*K);
 const st=nsSt();let tier=Math.max(0,Math.min(2,st.tier|0)),boost=nsBoost(),cur=null,rev=[],starRev=false,settled=true,busy=false,scratching=false,sess=0,pairHint={},modal=null;
 const queue=[];
 NZM.on=1;NZM.tok=tok;NZM.lv=0;NZM.s=0;
 const persist=()=>{const c=cst(),L=[];if(cur&&!settled)L.push(cur);L.push(...queue);if(L.length)c.nsq=L;else delete c.nsq;save()};
 const stars=Array.from({length:60},(_,i)=>`<i class="nzst" style="left:${(i*37.3)%100}%;top:${(i*61.7)%100}%;--d:${(i%7)*.45}s;--s:${1+(i%3)}px"></i>`).join('');
 const tierBtn=(T,i)=>`<button class="nztier${i===tier?' on':''}" data-t="${i}" style="--c:${T.c};--c2:${T.c2};--c3:${T.c3}"><span class="nzti">${nsTk(i)}</span><span class="nztx"><b>${T.n}</b><em>${NS_ICON.coin}${cmn(T.p)}</em></span><kbd>${i+1}</kbd></button>`;
 el.innerHTML=`<div class="nz" id="nz">
  <div class="nztiers" id="nztiers">${NS.T.map(tierBtn).join('')}</div>
  <aside class="nzl"><div class="nzbox nzgift" id="nzgift"></div>
   <div class="nzbox nzsess"><span class="nzlab">This session</span><b class="nzbig" id="nzsv">0</b><small id="nzsc">No tickets yet</small><div class="nzstats" id="nzstats"></div><span class="nzlab sm">Recent tickets</span><div class="nzhist" id="nzhist"></div></div></aside>
  <div class="nzstage" id="nzstage"><div class="nzneb"><i class="b1"></i><i class="b2"></i><i class="b3"></i></div><div class="nzstars">${stars}</div><svg class="nzastro" viewBox="-100 -100 200 200" aria-hidden="true"><circle r="96" fill="none" stroke="#e8c36a22" stroke-width="1"/><circle r="80" fill="none" stroke="#e8c36a18" stroke-width="6" stroke-dasharray="1 9"/><ellipse rx="96" ry="34" fill="none" stroke="#e8c36a1c" transform="rotate(24)"/><ellipse rx="96" ry="34" fill="none" stroke="#e8c36a1c" transform="rotate(-36)"/></svg>
   <div class="nzdeck" id="nzdeck"></div><div class="nzslot" id="nzslot"></div><div class="nzfx" id="nzfx"></div><div class="nzflash" id="nzflash"></div><div class="nzbanner" id="nzbanner"></div><div class="nzprog" id="nzprog"></div><p class="cmsg nzmsg" id="cm"> </p><div class="nzmod" id="nzmod"></div></div>
  <aside class="nzr"><div class="nzbox nzsel" id="nzsel"></div></aside>
  <div class="nzbtns"><button class="nzbuy" id="nsb"></button><button class="nzb5" id="ns5"></button></div>
  <div class="nzbar"><div class="nzcon"><span class="nzci">${NS_ICON.star}</span><div class="nzcm"><b>Constellation Bonus</b><svg id="nzmsvg" viewBox="0 0 400 30" preserveAspectRatio="none" aria-hidden="true"></svg><div class="nzcl"><span id="nzmc"></span><span>Free ticket at ${NS.METER}</span></div></div></div>
   <div class="nzrem"><span class="nzci">${NS_ICON.star}</span><b id="nzrem"></b><small>tickets to<br>next free</small></div>
   <div class="nzlast"><span class="nzlab">Last ticket</span><div id="nzlast" class="nzlc"></div></div>
   ${boost?`<div class="nzboost"><span class="nzci sm">${NS_ICON.star}</span><span>+25% prizes · <b id="nztc">${nsLeft()}</b></span></div>`:''}</div></div>`;
 const stage=$('nzstage'),slot=$('nzslot'),fx=$('nzfx');
 /* ---- helpers ---- */
 const pos=node=>{const a=node.getBoundingClientRect(),b=stage.getBoundingClientRect(),s=b.width/stage.offsetWidth||1;return[(a.left+a.width/2-b.left)/s,(a.top+a.height/2-b.top)/s]};
 const burst=(x,y,n,cols,pw,up,cls)=>{if(rm)n=Math.ceil(n/3);for(let i=0;i<n;i++){const p=document.createElement('i');p.className=cls||'nzpt';const a=up?-Math.PI/2+(Math.random()-.5)*2.6:Math.random()*Math.PI*2,v=(pw||90)*(.35+Math.random());p.style.cssText=`left:${x}px;top:${y}px;--dx:${Math.cos(a)*v}px;--dy:${Math.sin(a)*v}px;--s:${3+Math.random()*5}px;background:${cols[i%cols.length]};animation-duration:${(.55+Math.random()*.7)*K+.05}s`;fx.appendChild(p);setTimeout(()=>p.remove(),1500)}};
 const coinRain=n=>{if(rm)n=Math.ceil(n/3);for(let i=0;i<n;i++){const c=document.createElement('i');c.className='nzrain';c.style.cssText=`left:${4+Math.random()*92}%;animation-delay:${Math.random()*1.2}s;animation-duration:${1+Math.random()*.9}s;--sz:${14+Math.random()*16}px`;fx.appendChild(c);setTimeout(()=>c.remove(),3400)}};
 const banner=(t,cl)=>{const b=$('nzbanner');b.className='nzbanner';b.innerHTML=t;void b.offsetWidth;b.className='nzbanner show '+(cl||'')};
 const flash=c=>{const f=$('nzflash');f.className='nzflash';f.style.setProperty('--c',c);void f.offsetWidth;f.className='nzflash on'};
 const shake=()=>{stage.classList.remove('nzshk');void stage.offsetWidth;stage.classList.add('nzshk')};
 const countUp=(node,from,to,ms)=>new Promise(res=>{if(!node){res();return}const t0=performance.now(),d=rm?1:ms;const f=t=>{if(!alive()){res();return}const u=Math.min(1,(t-t0)/d),k=1-Math.pow(1-u,3);node.textContent=cmn(from+(to-from)*k);if(u<1)requestAnimationFrame(f);else res()};requestAnimationFrame(f)});
 let lastScr=0;
 const sfx={scr:v=>{const n=performance.now();if(n-lastScr<42)return;lastScr=n;const f=1800+Math.min(1,v)*2600;beep(f+Math.random()*700,.02,'sawtooth',.06);beep(4800+Math.random()*2400,.012,'square',.028)},
  pop:i=>{const b=72+i*2;beep(nf(b),.09,'triangle',.45);setTimeout(()=>beep(nf(b+7),.11,'sine',.35),55)},
  pair:i=>{const b=76+i;[0,4,7].forEach((s,j)=>setTimeout(()=>beep(nf(b+s),.12,'sine',.4),j*60));setTimeout(()=>beep(nf(b+12),.3,'triangle',.3),200)},
  beat:()=>{beep(62,.16,'sine',.7);setTimeout(()=>beep(58,.18,'sine',.55),170)},
  deal:()=>{beep(520,.05,'triangle',.25);setTimeout(()=>beep(780,.06,'triangle',.22),70)},
  buy:()=>{beep(988,.06,'triangle',.4);setTimeout(()=>beep(1318,.08,'triangle',.35),60)},
  line:()=>{[0,4,7,12].forEach((s,i)=>setTimeout(()=>beep(nf(79+s),.1,'sine',.4),i*55))},
  win:m=>{const s=m>=50?[0,4,7,12,16,19,24]:m>=10?[0,4,7,12,16]:[0,4,7,12];s.forEach((x,i)=>setTimeout(()=>beep(nf(72+x),.16,'triangle',.55),i*75));if(m>=10)setTimeout(()=>{for(let i=0;i<9;i++)setTimeout(()=>beep(1200+Math.random()*1100,.07,'triangle',.45),i*60)},420)},
  lose:()=>{beep(330,.12,'triangle',.3);setTimeout(()=>beep(247,.2,'triangle',.28),120)},
  star:()=>{[0,7,12,19,24].forEach((s,i)=>setTimeout(()=>beep(nf(84+s),.18,'sine',.42),i*80))},
  slam:()=>{beep(110,.25,'square',.5);setTimeout(()=>[0,4,7,12,16,19].forEach((s,i)=>setTimeout(()=>beep(nf(84+s),.14,'triangle',.5),i*45)),90)}};
 /* ---- side panels ---- */
 const selPanel=()=>{const T=NS.T[tier];$('nzsel').style.cssText=`--c:${T.c};--c2:${T.c2};--c3:${T.c3}`;
  $('nzsel').innerHTML=`<span class="nzlab c">Selected ticket</span><div class="nzsh"><span class="nzti lg">${nsTk(tier)}</span><b>${T.n}</b></div>
  <div class="nzrows"><div>${NS_ICON.coin}<span>Cost</span><b>${cmn(T.p)}</b></div><div><span class="nzcup">${NS_ICON.cup}</span><span>Top prize</span><b>${cmn(Math.min(NS.CAP,nsPay(T.p,T.m[7],boost,3)))}</b></div><div><span class="nzcup">${NS_ICON.star}</span><span>Win chance</span><b>${Math.round(T.win*100)}%</b></div></div>
  <p>Match 3 of the same symbol anywhere on the ticket to win. A Lucky Star can double or triple it.</p>
  <button class="nzlink" data-m="how">${NS_ICON.book}<span>How to play</span><i>›</i></button><button class="nzlink" data-m="odds">${NS_ICON.bars}<span>Prize odds</span><i>›</i></button>`;
  $('nzsel').querySelectorAll('[data-m]').forEach(b=>b.onclick=()=>openModal(b.dataset.m))};
 const giftPanel=()=>{const s=nsSt(),ready=s.day!==nsToday();$('nzgift').innerHTML=`<span class="nzlab">Daily gift</span><span class="nzgi${ready?' rdy':''}">${NS_ICON.gift}</span>${ready?`<b>A free ticket is waiting!</b><button class="nzclaim" id="nzclaim">Claim free ticket</button>`:`<b>Gift claimed</b><small>Next free ticket in <span id="nzgl">${nsGiftLeft()}</span></small>`}`;
  const c=$('nzclaim');if(c)c.onclick=claimGift};
 const meter=()=>{const s=nsSt(),n=s.meter,P2=[];for(let i=0;i<NS.METER;i++)P2.push([8+i*(384/(NS.METER-1)),15]);
  $('nzmsvg').innerHTML=`<line x1="8" y1="15" x2="392" y2="15" stroke="#e8c36a44" stroke-width="2" stroke-dasharray="4 5"/>`+(n>1?`<line x1="8" y1="15" x2="${P2[n-1][0]}" y2="15" stroke="#ffd24a" stroke-width="3"/>`:'')+P2.map((p,i)=>i<n?`<path d="M${p[0]} ${p[1]-7}l2 5 5 2-5 2-2 5-2-5-5-2 5-2z" fill="#fff2b0" ${i===n-1?'class="nzlast2"':''}/>`:`<circle cx="${p[0]}" cy="${p[1]}" r="4" fill="#0a0d2c" stroke="#8a7cd8" stroke-width="1.5"/>`).join('');
  $('nzmc').innerHTML=`<b>${n}</b> / ${NS.METER} tickets`;$('nzrem').textContent=NS.METER-n};
 const hist=()=>{const s=nsSt();$('nzhist').innerHTML=s.hist.length?s.hist.slice(0,8).map(h=>`<span class="nzh${h.m?' w':''}${h.m>=10?' big':''}" title="${NS.T[h.t]?NS.T[h.t].n:''} ticket">${h.m?'×'+nsFm(h.m):'–'}</span>`).join(''):'<em>None yet</em>';
  $('nzstats').innerHTML=[['Tickets',cmn(s.cards)],['Wins',s.cards?Math.round(s.wins/s.cards*100)+'%':'–'],['Lucky Stars',cmn(s.stars||0)],['Free tickets',cmn(s.free||0)],['Best win',s.best?cmn(s.best):'–'],['Biggest',s.bestM?'×'+nsFm(Math.round(s.bestM*100)/100):'–']].map(r=>`<div><span>${r[0]}</span><b>${r[1]}</b></div>`).join('');
  const l=s.hist[0];$('nzlast').innerHTML=l?`<span class="nzlsym">${l.s>=0?nsSym(NS.SY[l.s].k,34):'<i class="nzq">?</i>'}</span><span>${l.m?`<b>Won ${cmn(l.p||0)}</b><small>×${nsFm(l.m)} · ${NS.T[l.t].n}</small>`:`<b class="ls">No match</b><small>${NS.T[l.t].n} ticket</small>`}</span>`:`<span class="nzlsym"><i class="nzq">?</i></span><span><small>No ticket opened yet</small></span>`;
  $('nzsv').textContent=(sess>=0?'+':'−')+cmn(Math.abs(sess));$('nzsc').textContent=s.cards?`${cmn(s.cards)} tickets scratched · best ${s.best?cmn(s.best):'–'}`:'No tickets yet';$('nzsv').className='nzbig'+(sess>0?' up':sess<0?' dn':'')};
 const deck=()=>{const n=queue.length,d=$('nzdeck');d.innerHTML=n?Array.from({length:Math.min(4,n)},(_,i)=>`<i class="nzbk" style="--i:${i};--c:${NS.T[queue[i].t].c2}"></i>`).join('')+`<b class="nzleft">+${n} ticket${n>1?'s':''}</b>`:''};
 const U=()=>{const T=NS.T[tier],active=cur&&!settled,b=$('nsb'),b5=$('ns5'),need=T.p-P.gold;
  if(active){b.className='nzbuy rev';b.innerHTML=`<span><b>Reveal all</b><small>or keep scratching</small></span>`;b.disabled=busy}
  else if(queue.length){b.className='nzbuy';b.innerHTML=`<span><b>Next ticket</b><small>${queue.length} waiting</small></span>`;b.disabled=busy}
  else if(need>0){b.className='nzbuy dis';b.innerHTML=`${NS_ICON.coin}<span><b>Need ${cmn(need)} more coins</b><small>Get ${cmn(need)} more coins to buy this ticket</small></span>`;b.disabled=true}
  else{b.className='nzbuy';b.innerHTML=`${NS_ICON.coin}<span><b>Buy ticket · ${cmn(T.p)}</b><small>${T.n} ticket · press Space</small></span>`;b.disabled=busy}
  b5.innerHTML=`${NS_ICON.coin}<span><b>Buy 5 · ${cmn(T.p*5)}</b></span>`;b5.disabled=busy||active||queue.length>0||P.gold<T.p*5;
  ov.querySelectorAll('.nztier').forEach(x=>{x.classList.toggle('on',+x.dataset.t===tier);x.disabled=active||queue.length>0||busy});
  deck();meter();hist();giftPanel()};
 /* ---- modals: how to play and prize odds ---- */
 const openModal=k=>{const T=NS.T[tier],m=$('nzmod');modal=k;
  m.innerHTML=`<div class="nzmc"><button class="nzx" aria-label="Close">×</button>${k==='how'?`<h3>How to play</h3><ol class="nzhow"><li><b>1</b><span>Pick a ticket at the top: Stardust, Nebula or Supernova.</span></li><li><b>2</b><span>Buy it, then <em>drag across the foil</em> with your mouse or finger. Panels pop open as you uncover them.</span></li><li><b>3</b><span>Match <em>three of the same symbol</em> to win that symbol's prize.</span></li><li><b>4</b><span>Scratch the <em>Lucky Star</em> medallion: a gold star doubles or triples any win.</span></li><li><b>5</b><span>Claim a free ticket every day, and earn another every ${NS.METER} tickets.</span></li></ol><p class="nzkeys"><kbd>Space</kbd> buy or reveal · <kbd>F</kbd> buy 5 · <kbd>1</kbd><kbd>2</kbd><kbd>3</kbd> pick a ticket</p>`
  :`<h3>${T.n} ticket odds</h3><div class="nzodds">${[...NS.SY].map((y,i)=>[y,i]).reverse().map(([y,i])=>`<div style="--c:${y.c}"><span class="nzoi">${nsSym(y.k,30)}</span><span class="nzon">${y.n}</span><span class="nzom">×${nsFm(nsMul(T.m[i],boost))}</span><span class="nzog">${NS_ICON.coin}${cmn(nsPay(T.p,T.m[i],boost))}</span><span class="nzoo">${nsOdds(y.p*T.k)}</span></div>`).join('')}
   <div class="nzol" style="--c:#ffd24a"><span class="nzoi">${NS_ICON.star}</span><span class="nzon">Lucky Star</span><span class="nzom">×2 · ×3</span><span class="nzog">on any win</span><span class="nzoo">1 in ${Math.round(1/NS.LUCK[1][1])} · 1 in ${Math.round(1/NS.LUCK[0][1])}</span></div></div>
   <p class="nzfine">About ${Math.round(T.win*100)}% of ${T.n} tickets win something. Returns ${boost?`about ${Math.round(NS.RTP*NS.BOOST*100)}% during the launch week (96% normally)`:'96%'}. One ticket pays at most ${cmn(NS.CAP)} coins.</p>`}</div>`;
  m.className='nzmod on';m.querySelector('.nzx').onclick=closeModal;m.onclick=e=>{if(e.target===m)closeModal()};beep(620,.05,'triangle',.4)};
 const closeModal=()=>{const m=$('nzmod');if(m)m.className='nzmod';modal=null};
 /* ---- the ticket ---- */
 let cv=null,cx=null,play=null,cells=[],cover=[],star=null,scov=null,G=12,brush=30,sc=1,lx=0,ly=0,lt=0;
 const ticketHTML=(c,demo)=>{const T=NS.T[c.t];return `<div class="nzt${demo?' demo':''}${c.f?' free':''}" style="--c:${T.c};--c2:${T.c2};--c3:${T.c3}"><i class="nzglint"></i><div class="nztin">
  <div class="nzth"><span class="nztt">✦ ${c.f===2?'DAILY GIFT':c.f?'FREE TICKET':'NEBULA SCRATCH'} ✦</span><small>${T.n.toUpperCase()} · MATCH 3 SYMBOLS TO WIN${c.b?' · <b>+25%</b>':''}</small></div>
  <div class="nzplay"><div class="nzmed l">${NS_ICON.moon}</div>
   <div class="nzgrid">${(demo?[7,4,6,5,3,1]:c.c).map((s,i)=>`<div class="nzcell${demo?' rev':''}" data-i="${i}" style="--c:${NS.SY[s].c}"><span class="nzsy">${nsSym(NS.SY[s].k,92)}</span><em>${NS.SY[s].n}</em></div>`).join('')}</div>
   <div class="nzmed r" id="nzstar"><span class="nzsv${demo?' on':''}">${demo?NS_ICON.star:c.ls>1?`${NS_ICON.star}<b>×${c.ls}</b>`:`<i class="nznone">✧</i>`}</span><small>LUCKY STAR</small></div>
   ${demo?'':'<svg class="nzline" id="nzline" aria-hidden="true"></svg><canvas class="nzfoil" id="nzfoil"></canvas>'}</div>
  <div class="nzfoot" id="nsplate">${demo?'<span>✦ Card preview ✦</span><b>Pick a ticket and press Buy</b>':`<span>Scratch the foil</span><b>Top prize ${NS_ICON.coin}${cmn(Math.min(NS.CAP,nsPay(T.p,T.m[7],c.b,3)))}</b>`}</div></div></div>`};
 const rr=(g,x,y,w,h,r)=>{g.beginPath();g.roundRect(x,y,w,h,r)};
 const foilFill=(g,x,y,w,h,T,seed)=>{const lg=g.createLinearGradient(x,y,x+w,y+h);lg.addColorStop(0,'#8e98c4');lg.addColorStop(.3,'#e9ecff');lg.addColorStop(.5,'#b6bedf');lg.addColorStop(.75,'#f4f6ff');lg.addColorStop(1,'#7a84ae');g.fillStyle=lg;g.fillRect(x,y,w,h);
  const hg=g.createLinearGradient(x,y+h,x+w,y);hg.addColorStop(0,T.c+'00');hg.addColorStop(.45,T.c+'66');hg.addColorStop(.7,'#ff9ad855');hg.addColorStop(1,'#9ff0ff44');g.fillStyle=hg;g.fillRect(x,y,w,h);
  g.globalAlpha=.22;g.strokeStyle='#fff';g.lineWidth=1.2*sc;for(let k=-h;k<w;k+=8*sc){g.beginPath();g.moveTo(x+k,y+h);g.lineTo(x+k+h,y);g.stroke()}g.globalAlpha=1;
  for(let k=0;k<40;k++){const px=x+((k*53+seed*31)%100)/100*w,py=y+((k*37+seed*17)%100)/100*h,s=(1+(k%3))*sc;g.fillStyle='#ffffffcc';g.beginPath();g.moveTo(px,py-s*2);g.quadraticCurveTo(px,py,px+s*2,py);g.quadraticCurveTo(px,py,px,py+s*2);g.quadraticCurveTo(px,py,px-s*2,py);g.quadraticCurveTo(px,py,px,py-s*2);g.fill()}};
 const emblem=(g,x,y,r)=>{g.save();g.translate(x,y);g.strokeStyle='#5a6490aa';g.lineWidth=2*sc;g.beginPath();g.arc(0,0,r,0,TAU);g.stroke();g.fillStyle='#5a6490b0';g.beginPath();for(let i=0;i<8;i++){const a=-Math.PI/2+i*Math.PI/4,rr2=i%2?r*.28:r*.8;g.lineTo(Math.cos(a)*rr2,Math.sin(a)*rr2)}g.closePath();g.fill();g.restore()};
 const drawFoil=()=>{const g=cx,W=cv.width,H=cv.height,T=NS.T[cur.t];g.globalCompositeOperation='source-over';g.clearRect(0,0,W,H);
  /* one continuous sheet over the six panels */
  const x0=Math.min(...cells.map(r=>r.x))-4*sc,y0=Math.min(...cells.map(r=>r.y))-4*sc,x1=Math.max(...cells.map(r=>r.x+r.w))+4*sc,y1=Math.max(...cells.map(r=>r.y+r.h))+4*sc;
  g.save();rr(g,x0,y0,x1-x0,y1-y0,14*sc);g.clip();foilFill(g,x0,y0,x1-x0,y1-y0,T,3);cells.forEach(r=>emblem(g,r.x+r.w/2,r.y+r.h/2,Math.min(r.w,r.h)*.3));
  g.fillStyle='#4a548099';g.font=`800 ${12*sc}px Poppins,system-ui,sans-serif`;g.textAlign='center';g.fillText('✦  SCRATCH HERE  ✦',(x0+x1)/2,(y0+y1)/2+4*sc);g.restore();
  g.save();rr(g,x0+1,y0+1,x1-x0-2,y1-y0-2,14*sc);g.strokeStyle='#ffffffaa';g.lineWidth=2*sc;g.stroke();g.restore();
  /* and a round foil seal over the Lucky Star */
  if(star){g.save();g.beginPath();g.arc(star.x,star.y,star.r,0,TAU);g.clip();foilFill(g,star.x-star.r,star.y-star.r,star.r*2,star.r*2,{c:'#ffd24a'},7);g.fillStyle='#6a5a2acc';g.font=`700 ${20*sc}px Georgia,serif`;g.textAlign='center';g.textBaseline='middle';g.fillText('?',star.x,star.y);g.restore();
   g.beginPath();g.arc(star.x,star.y,star.r-1,0,TAU);g.strokeStyle='#fff6c0';g.lineWidth=2*sc;g.stroke()}};
 const layout=()=>{const w=play.offsetWidth,h=play.offsetHeight,dpr=Math.min(2,(window.devicePixelRatio||1)*1.25);sc=dpr;cv.width=Math.round(w*dpr);cv.height=Math.round(h*dpr);
  cells=[...play.querySelectorAll('.nzcell')].map(c=>({x:c.offsetLeft*dpr,y:c.offsetTop*dpr,w:c.offsetWidth*dpr,h:c.offsetHeight*dpr}));cover=cells.map(()=>new Uint8Array(G*G));
  const m=play.querySelector('.nzmed.r .nzsv');star=m?{x:(m.offsetLeft+m.parentNode.offsetLeft+m.offsetWidth/2)*dpr,y:(m.offsetTop+m.parentNode.offsetTop+m.offsetHeight/2)*dpr,r:m.offsetWidth/2*dpr+3*dpr}:null;scov=new Uint8Array(64);brush=26*dpr};
 const toCv=e=>{const r=cv.getBoundingClientRect();return[(e.clientX-r.left)*cv.width/r.width,(e.clientY-r.top)*cv.height/r.height]};
 const progress=()=>{let n=0;for(const c of cover)for(const v of c)n+=v;return n/(cells.length*G*G)};
 const showProg=()=>{const p=$('nzprog');if(!p||!cur||settled)return;const v=Math.round(progress()*100),k=rev.filter(Boolean).length;p.innerHTML=`<i style="width:${v}%"></i><span>${k} / 6 panels${starRev?' · ★ revealed':''}</span>`;p.className='nzprog on'};
 const mark=(x,y)=>{const b2=brush*brush;cells.forEach((r,i)=>{if(rev[i])return;if(x<r.x-brush||x>r.x+r.w+brush||y<r.y-brush||y>r.y+r.h+brush)return;const c2=cover[i];let hit=0;
   for(let gy=0;gy<G;gy++)for(let gx=0;gx<G;gx++){const k=gy*G+gx;if(c2[k])continue;const px=r.x+(gx+.5)*r.w/G,py=r.y+(gy+.5)*r.h/G;if((px-x)**2+(py-y)**2<b2){c2[k]=1;hit=1}}
   if(hit){let n=0;for(const v of c2)n+=v;if(n>=G*G*.42)revealCell(i)}});
  if(star&&!starRev){const d=Math.hypot(x-star.x,y-star.y);if(d<star.r+brush){for(let gy=0;gy<8;gy++)for(let gx=0;gx<8;gx++){const px=star.x-star.r+(gx+.5)*star.r/4,py=star.y-star.r+(gy+.5)*star.r/4;if((px-x)**2+(py-y)**2<b2)scov[gy*8+gx]=1}let n=0;for(const v of scov)n+=v;if(n>=30)revealStar()}}};
 const erase=(x0,y0,x1,y1)=>{const g=cx;g.save();g.globalCompositeOperation='destination-out';g.lineCap='round';g.lineJoin='round';g.globalAlpha=.35;g.lineWidth=brush*2.5;g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.stroke();g.globalAlpha=1;g.lineWidth=brush*2;g.stroke();g.restore()};
 const stroke=(x0,y0,x1,y1)=>{erase(x0,y0,x1,y1);const d=Math.hypot(x1-x0,y1-y0),n=Math.max(1,Math.ceil(d/(brush*.5)));for(let k=0;k<=n;k++)mark(x0+(x1-x0)*k/n,y0+(y1-y0)*k/n);showProg()};
 const flake=(x,y,n)=>{const r=play.getBoundingClientRect(),b=stage.getBoundingClientRect(),s=b.width/stage.offsetWidth||1,ox=(r.left-b.left)/s,oy=(r.top-b.top)/s;for(let i=0;i<(n||1);i++){if(Math.random()>.7)continue;const f=document.createElement('i');f.className='nzflake';f.style.cssText=`left:${ox+x/sc}px;top:${oy+y/sc}px;--dx:${(Math.random()-.5)*80}px;--dy:${30+Math.random()*70}px;--r:${Math.random()*540}deg;background:${Math.random()<.5?'#e9ecff':Math.random()<.5?NS.T[cur.t].c:'#ffd24a'}`;fx.appendChild(f);setTimeout(()=>f.remove(),900)}};
 const onDown=e=>{if(!cur||settled||busy)return;e.preventDefault();scratching=true;closeHand();try{cv.setPointerCapture(e.pointerId)}catch(x){}const [x,y]=toCv(e);lx=x;ly=y;lt=performance.now();stroke(x,y,x+.1,y);sfx.scr(.3);flake(x,y,2)};
 const onMove=e=>{if(!scratching||!cur||settled)return;e.preventDefault();const [x,y]=toCv(e),d=Math.hypot(x-lx,y-ly);if(d<2)return;const now=performance.now(),v=d/sc/Math.max(8,now-lt);stroke(lx,ly,x,y);lx=x;ly=y;lt=now;sfx.scr(v);flake(x,y,Math.min(4,1+v*2))};
 const onUp=()=>{scratching=false};
 const clearRegion=(fn,dd)=>{const t0=performance.now();const step=t=>{if(!cv||!alive())return;const u=Math.min(1,(t-t0)/dd);cx.save();cx.globalCompositeOperation='destination-out';cx.globalAlpha=.25+u*.75;fn(cx);cx.fill();cx.restore();if(u<1)requestAnimationFrame(step)};requestAnimationFrame(step)};
 /* shrink the ticket to fit the stage height (the canvas maths reads real screen rects, so scaling is safe) */
 const fit=w=>{if(!w||!w.firstElementChild)return;w.style.transform='';const sh=slot.clientHeight,th=w.firstElementChild.offsetHeight;w.style.transform=th>sh-4?`scale(${Math.max(.55,(sh-4)/th)})`:''};
 if(!window.__nzfit){window.__nzfit=1;addEventListener('resize',()=>{const s=document.getElementById('nzslot');if(s&&window.__nzfitf)window.__nzfitf()})}window.__nzfitf=()=>slot.querySelectorAll('.nzcw').forEach(fit);
 const tcard=()=>slot.querySelector('.nzt:not(.out):not(.demo)');
 const revealCell=(i,quiet)=>{if(rev[i]||!cur)return;rev[i]=1;const r=cells[i],node=tcard().querySelectorAll('.nzcell')[i];
  clearRegion(g=>{g.beginPath();g.roundRect(r.x-6*sc,r.y-6*sc,r.w+12*sc,r.h+12*sc,12*sc)},rm?60:260);
  if(node){node.classList.add('rev');const [x,y]=pos(node);burst(x,y,quiet?5:12,['#fff',NS.SY[cur.c[i]].c,'#fff6c0'],70)}
  if(!quiet)sfx.pop(cur.c[i]);
  const cnt={};cur.c.forEach((s,j)=>{if(rev[j])cnt[s]=(cnt[s]||0)+1});
  for(const s in cnt){if(cnt[s]===2&&!pairHint[s]){pairHint[s]=1;tcard().querySelectorAll('.nzcell').forEach((n2,j)=>{if(rev[j]&&cur.c[j]==s)n2.classList.add('pair')});
    if(!quiet&&!settled){sfx.pair(+s);const y=NS.SY[s],T=NS.T[cur.t];msg(`Two ${y.pl}! One more pays ${cmn(nsPay(T.p,T.m[s],cur.b,starRev?cur.ls:1))}.`,'w');if(s>=4){stage.classList.add('nzhot');NZM.lv=2;sfx.beat();banner(`<small>So close…</small>${y.n.toUpperCase()}`,'tease')}}}}
  showProg();
  const n=rev.filter(Boolean).length;if(!settled&&n>=NS.CELLS)finish()};
 const revealStar=quiet=>{if(starRev||!cur||!star)return;starRev=true;const s=star;clearRegion(g=>{g.beginPath();g.arc(s.x,s.y,s.r+4*sc,0,TAU)},rm?60:300);
  const m=tcard().querySelector('#nzstar');if(m){m.classList.add('rev');if(cur.ls>1){m.classList.add('lucky');const [x,y]=pos(m);burst(x,y,26,['#ffd24a','#fff2b0','#fff'],120);if(!quiet){sfx.star();msg(`Lucky Star ×${cur.ls}! Any win on this ticket is multiplied.`,'w')}}else if(!quiet)beep(520,.06,'triangle',.3)}showProg()};
 /* reveal whatever is still covered with a quick sweep */
 const revealAll=async()=>{if(!cur||settled||busy)return;busy=true;U();closeHand();
  for(let i=0;i<NS.CELLS;i++){if(settled||!alive())break;if(rev[i])continue;const r=cells[i],steps=rm?2:6;
   for(let k=0;k<steps;k++){if(rev[i]||!alive())break;const y0=r.y+r.h*(k/steps),y1=r.y+r.h*((k+1)/steps),xa=k%2?r.x+r.w:r.x,xb=k%2?r.x:r.x+r.w;erase(xa,y0,xb,y1);sfx.scr(.6);if(k%2)flake(xb,y1,2);await csleep(rm?8:16)}
   if(!rev[i])revealCell(i)}
  if(!settled){busy=false;U()}};
 /* settle the ticket */
 /* ---- win celebrations: five tiers, from money back to a cosmic jackpot ---- */
 const nzPay=(pr,pay)=>{window.__nzbw=1;try{cPay(pr,pay)}finally{window.__nzbw=0}};
 const tierOf=x=>x>=50?4:x>=10?3:x>=3?2:x>=1.5?1:0;
 const layer=()=>{let L=document.getElementById('nzfly');if(!L){L=document.createElement('div');L.id='nzfly';document.body.appendChild(L)}return L};
 /* coins arc from the prize plate into the coin counter at the top of the screen */
 const coinFly=(from,n)=>new Promise(res=>{const to=document.getElementById('cbal'),L=layer();if(!from||!to||rm){res();return}const a=from.getBoundingClientRect(),b=to.getBoundingClientRect(),ax=a.left+a.width/2,ay=a.top+a.height/2,bx=b.left+b.width*.25,by=b.top+b.height/2;let done=0;
  for(let i=0;i<n;i++){const c=document.createElement('i');c.className='nzfc';L.appendChild(c);const sx=ax+(Math.random()-.5)*a.width*.6,sy=ay+(Math.random()-.5)*20,mx=(sx+bx)/2+(Math.random()-.5)*260,my=Math.min(sy,by)-120-Math.random()*140,d=650+Math.random()*350,dl=i*45;
   const an=c.animate([{transform:`translate(${sx}px,${sy}px) scale(.3)`,opacity:0},{transform:`translate(${sx}px,${sy-30}px) scale(1.1)`,opacity:1,offset:.12},{transform:`translate(${mx}px,${my}px) scale(1) rotate(200deg)`,offset:.55},{transform:`translate(${bx}px,${by}px) scale(.55) rotate(420deg)`,opacity:.9}],{duration:d,delay:dl,easing:'cubic-bezier(.45,0,.6,1)',fill:'forwards'});
   an.onfinish=()=>{c.remove();if(alive()&&i%2===0)beep(1500+Math.random()*900,.05,'triangle',.3);if(++done===1){const g=to.parentNode;if(g&&g.classList){g.classList.remove('nzgot');void g.offsetWidth;g.classList.add('nzgot')}}if(done===n)res()}}});
 const rays=k=>{const r=document.createElement('div');r.className='nzrays t'+k;stage.insertBefore(r,slot);setTimeout(()=>r.remove(),k>=4?4200:3000)};
 const ring=(x,y,col,dl)=>{const r=document.createElement('i');r.className='nzring';r.style.cssText=`left:${x}px;top:${y}px;--c:${col};animation-delay:${dl||0}s`;fx.appendChild(r);setTimeout(()=>r.remove(),1600+(dl||0)*1000)};
 const ticker=(node,from,to,ms)=>{let last=0;const t0=performance.now(),d=rm?1:ms;return new Promise(res=>{if(!node){res();return}const f=t=>{if(!alive()){res();return}const u=Math.min(1,(t-t0)/d),k=1-Math.pow(1-u,3);node.textContent=cmn(from+(to-from)*k);if(t-last>70&&u<1){last=t;beep(900+u*900,.025,'triangle',.18)}if(u<1)requestAnimationFrame(f);else res()};requestAnimationFrame(f)})};
 const celebrate=async(c,card,pl,R,base,pay,T,y,pr)=>{const k=tierOf(R.x),cn=[...card.querySelectorAll('.nzcell')],wins=cn.filter((n2,j)=>c.c[j]===c.w);
  card.classList.add('won','w'+k);
  wins.forEach((n2,i)=>setTimeout(()=>{if(!alive())return;const [x,y2]=pos(n2);burst(x,y2,6+k*4,['#fff',y.c,'#ffe27a'],60+k*20);if(k>=2)ring(x,y2,y.c)},i*110));
  pl.className='nzfoot win t'+k;pl.innerHTML=`<span>Three ${y.pl}${R.m===1&&c.ls<2?' · money back':''}</span><b>WIN ${NS_ICON.coin}<em id="nzpv">0</em> <small>×${nsFm(base/T.p)}</small></b>`;
  msg(`Three ${y.pl}!${c.ls>1?' And the Lucky Star…':''}`,'w');sfx.win(R.x);if(k>=1)rays(k);
  if(k===4){stage.classList.add('nzcosmic');setTimeout(()=>stage.classList.remove('nzcosmic'),3600);flash('#ffffff');shake();beep(55,.8,'sine',.9);
   const [cx2,cy2]=pos(card);for(let i=0;i<3;i++)ring(cx2,cy2,['#fff2a0','#ff9ad8','#9ff0ff'][i],i*.18);
   const big=document.createElement('div');big.className='nzbigsym';big.innerHTML=nsSym(y.k,260);fx.appendChild(big);setTimeout(()=>big.remove(),2300);
   banner('<small>✦ ✦ ✦</small>COSMIC WIN','jack');coinRain(70)}
  else if(k===3){const [cx2,cy2]=pos(card);ring(cx2,cy2,'#ffe27a');flash('#ffd24a');shake();banner(`<small>×${nsFm(base/T.p)}</small>BIG WIN`,'big');coinRain(40);stage.classList.add('nzwarp');setTimeout(()=>stage.classList.remove('nzwarp'),2600)}
  else if(k===2){banner('GREAT WIN','');flash('#ffe27a66');coinRain(14)}
  else if(k===1){banner('WIN!','soft');coinRain(6)}
  else banner('MONEY BACK','soft');
  const [x,y3]=pos(card);burst(x,y3,[10,24,36,60,90][k],['#ffe27a','#fff6c0',y.c,'#fff'],[90,130,170,220,260][k],true);
  await ticker($('nzpv'),0,base,[450,700,950,1300,1800][k]);if(!alive())return;
  if(c.ls>1){await wait(250);if(!alive())return;const m=card.querySelector('#nzstar');if(m){m.classList.remove('slam');void m.offsetWidth;m.classList.add('slam')}sfx.slam();shake();flash('#ffd24a');banner(`<small>Lucky Star</small>×${c.ls}!`,'big');
   const [sx,sy]=pos(m||card);ring(sx,sy,'#ffd24a');burst(sx,sy,30,['#ffd24a','#fff2b0','#fff'],150);
   pl.querySelector('small').textContent='×'+nsFm(R.x);pl.className='nzfoot win t'+Math.max(k,tierOf(R.x));await ticker($('nzpv'),base,pay,900);if(!alive())return;if(pay>=NS.CAP)pl.querySelector('span').textContent='Maximum prize!';if(tierOf(R.x)>=3&&k<3)coinRain(40)}
  pl.classList.add('done');
  msg(R.x<1.5&&c.ls<2?`Three ${y.pl}: your ${cmn(T.p)} back. Try again!`:`Three ${y.pl}${c.ls>1?` and a Lucky Star ×${c.ls}`:''}! You win ${cmn(pay)}.`,'w');
  const fly=coinFly(pl,Math.min(26,4+Math.round(Math.sqrt(R.x)*3)));setTimeout(()=>{if(alive())nzPay(pr,pay)},rm?0:550);await fly;if(!alive())return;await wait([200,300,500,900,1300][tierOf(R.x)])};
 const finish=async()=>{if(settled)return;settled=true;busy=true;const c=cur,T=NS.T[c.t],pr=c.f?0:T.p,win=c.w>=0,base=win?nsPay(T.p,T.m[c.w],c.b,1):0,R=nsResult(c),pay=R.pay,card=tcard();
  closeHand();U();stage.classList.remove('nzhot');NZM.lv=queue.length?1:0;$('nzprog').className='nzprog';
  for(let i=0;i<NS.CELLS;i++)if(!rev[i]){revealCell(i,true);await csleep(rm?10:60)}
  card.querySelectorAll('.nzcell').forEach(n2=>n2.classList.remove('pair'));
  const cn=card.querySelectorAll('.nzcell'),pl=card.querySelector('#nsplate');
  const s=nsSt();s.cards++;s.spent+=pr;s.won+=pay;if(pay>s.best)s.best=pay;if(win){s.wins++;if(R.x>s.bestM)s.bestM=R.x;if(c.ls>1)s.stars++}if(win&&R.x>=10)s.big++;
  s.hist.unshift({t:c.t,m:win?Math.round(R.x*100)/100:0,p:pay,s:win?c.w:-1});s.hist=s.hist.slice(0,12);
  stat('nsc',1,'add');if(win){stat('nsm',Math.floor(R.x),'max');if(c.w>=6)stat('nsbh',1,'add');if(c.ls>1)stat('nsls',1,'add')}
  let freeNow=false;if(!c.f){s.meter++;if(s.meter>=NS.METER){s.meter=0;s.free++;freeNow=true;queue.push(nsCard(0,1))}}
  if(win){cn.forEach((n2,j)=>n2.classList.add(c.c[j]===c.w?'win':'dim'));
   /* draw the winning line through the three matching panels */
   const ln=card.querySelector('#nzline'),pts=[...cn].filter((n2,j)=>c.c[j]===c.w).map(n2=>[n2.offsetLeft+n2.offsetWidth/2,n2.offsetTop+n2.offsetHeight/2]).sort((a,b)=>a[0]-b[0]||a[1]-b[1]);
   if(ln){ln.setAttribute('viewBox',`0 0 ${play.offsetWidth} ${play.offsetHeight}`);ln.innerHTML=`<polyline points="${pts.map(p=>p.join(',')).join(' ')}" class="g"/><polyline points="${pts.map(p=>p.join(',')).join(' ')}" class="l"/>${pts.map(p=>`<circle cx="${p[0]}" cy="${p[1]}" r="9" class="d"/>`).join('')}`;ln.classList.add('on')}
   sfx.line();await wait(450);if(!alive())return}
  else cn.forEach(n2=>n2.classList.add('dim'));
  /* the Lucky Star always shows itself at the end */
  if(!starRev){await wait(160);if(!alive())return;revealStar(true)}
  const y=win?NS.SY[c.w]:null;
  if(win){await celebrate(c,card,pl,R,base,pay,T,y,pr);if(!alive())return}
  else{const cnt={};c.c.forEach(s2=>cnt[s2]=(cnt[s2]||0)+1);const best=Object.keys(cnt).filter(k=>cnt[k]===2).map(Number).sort((a,b)=>b-a)[0];
   if(best!==undefined)cn.forEach((n2,j)=>{if(c.c[j]===best)n2.classList.add('near')});
   const tease=c.ls>1?` The Lucky Star ×${c.ls} was waiting!`:'';
   pl.className='nzfoot lose';pl.innerHTML=best!==undefined&&best>=4?`<span>So close! Two ${NS.SY[best].pl}</span><b>One more would have paid ${cmn(nsPay(T.p,T.m[best],c.b,c.ls))}</b>`:`<span>No match this time</span><b>${c.ls>1?`Lucky Star ×${c.ls} was waiting`:'Your next ticket could be the one'}</b>`;
   sfx.lose();msg((best!==undefined&&best>=4?`So close! Two ${NS.SY[best].pl}.`:'No match.')+tease+' Next ticket?','')}
  if(!win)nzPay(pr,pay);sess+=pay-pr;persist();
  U();await wait(win?300:800);if(!alive())return;
  if(freeNow){const [x,y3]=pos($('nzstage'));burst(x,y3,30,['#fff2b0','#ffd24a','#9ff0ff'],140,true);sfx.star();banner('<small>Constellation complete!</small>FREE TICKET','soft');msg('Constellation complete! A free Stardust ticket is waiting.','w');await wait(900);if(!alive())return}
  busy=false;U();
  if(queue.length){await wait(rm?200:650);if(!alive()||busy||(cur&&!settled))return;deal()}};
 let handT=0;const closeHand=()=>{clearTimeout(handT);slot.querySelectorAll('.nzhand').forEach(h=>h.remove())};
 /* bring the next ticket in */
 const deal=()=>{if(!queue.length)return;closeModal();slot.querySelectorAll('.nzt').forEach(o=>{o.classList.add('out');setTimeout(()=>o.parentNode&&o.parentNode.remove(),700)});
  cur=queue.shift();settled=false;rev=Array(NS.CELLS).fill(0);starRev=false;pairHint={};stage.classList.remove('nzhot');$('nzline')&&0;
  const w=document.createElement('div');w.className='nzcw';w.innerHTML=ticketHTML(cur);slot.appendChild(w);fit(w);const card=w.firstElementChild;
  play=card.querySelector('.nzplay');cv=card.querySelector('canvas');cx=cv.getContext('2d');layout();drawFoil();
  cv.addEventListener('pointerdown',onDown);cv.addEventListener('pointermove',onMove);cv.addEventListener('pointerup',onUp);cv.addEventListener('pointercancel',onUp);cv.addEventListener('lostpointercapture',onUp);
  NZM.lv=1;sfx.deal();persist();msg(cur.f===2?'Your daily gift! Scratch the foil.':cur.f?'Free ticket! Scratch the foil.':'Drag across the foil to scratch it, or press Reveal all.','');showProg();
  const dc=cur;clearTimeout(handT);handT=setTimeout(()=>{if(!alive()||cur!==dc||settled||rev.some(Boolean)||scratching)return;const h=document.createElement('i');h.className='nzhand';play.appendChild(h);setTimeout(()=>h.remove(),4400)},1300);
  U()};
 const buy=n=>{closeModal();if(busy||(cur&&!settled))return;if(queue.length){deal();return}const T=NS.T[tier],cost=T.p*n;
  if(P.gold<cost){msg(P.gold<T.p?(broke()||'Not enough coins for this ticket.'):`Not enough coins for ${n} tickets. Try fewer.`,'l');return}
  if(!cTake(cost))return;for(let i=0;i<n;i++)queue.push(nsCard(tier,0));persist();sfx.buy();
  if(n>1){const [x,y]=pos($('nzdeck'));burst(x,y,18,[T.c,'#fff'],90,true);banner(`<small>${n} tickets</small>${T.n.toUpperCase()} PACK`,'soft')}
  deal()};
 const claimGift=()=>{const s=nsSt();if(s.day===nsToday()||busy)return;s.day=nsToday();s.free++;queue.push(nsCard(0,2));save();persist();sfx.star();
  const g=$('nzgift');if(g){const [x,y]=pos(g.querySelector('.nzgi')||g);burst(x,y,0,['#fff'])}banner('<small>Daily gift</small>FREE TICKET','soft');
  if(!(cur&&!settled))deal();else{msg('Your free ticket is next in line.','w');U()}};
 const setTier=t=>{if(busy||(cur&&!settled)||queue.length||t===tier||t<0||t>2)return;tier=t;const s=nsSt();s.tier=t;save();beep(520+t*140,.05,'triangle',.4);selPanel();U();
  const d=slot.querySelector('.nzt.demo');if(d){const w=d.parentNode;w.innerHTML=ticketHTML({t,c:[],b:boost},true);fit(w)}};
 /* Esc closes a modal before it leaves the game */
 {const b0=S.back;S.back=()=>{if(modal){closeModal();return}if(cur&&!settled){msg('Finish scratching this ticket first, or press Reveal all.','l');return}b0&&b0()};const cb=$('cb');if(cb)cb.onclick=S.back}
 /* input */
 $('nztiers').addEventListener('click',e=>{const b=e.target.closest('.nztier');if(b&&!b.disabled)setTier(+b.dataset.t)});
 $('nsb').onclick=()=>{cur&&!settled?revealAll():buy(1)};$('ns5').onclick=()=>buy(5);
 CAS.key={' ':()=>{if(modal)return closeModal();cur&&!settled?revealAll():buy(1)},enter:()=>{if(modal)return closeModal();cur&&!settled?revealAll():buy(1)},r:revealAll,f:()=>buy(5),'1':()=>setTier(0),'2':()=>setTier(1),'3':()=>setTier(2)};
 {const iv=setInterval(()=>{if(!alive()){clearInterval(iv);return}const e=$('nztc');if(e)e.textContent=nsLeft();const g=$('nzgl');if(g)g.textContent=nsGiftLeft();if(g&&nsSt().day!==nsToday())giftPanel()},30000)}
 /* restore: tickets bought before a refresh are revealed and paid */
 const c0=cst(),rs=Array.isArray(c0.nsq)?c0.nsq:null;
 if(rs&&rs.length){delete c0.nsq;let tot=0;const s=nsSt();for(const c of rs){if(!c||!NS.T[c.t])continue;const T=NS.T[c.t],R=nsResult(c),pr=c.f?0:T.p;tot+=R.pay;s.cards++;s.spent+=pr;s.won+=R.pay;if(R.pay>s.best)s.best=R.pay;if(R.pay)s.wins++;s.hist.unshift({t:c.t,m:R.pay?Math.round(R.x*100)/100:0,p:R.pay,s:R.pay?c.w:-1});cPay(pr,R.pay)}
  s.hist=s.hist.slice(0,12);save();msg(`Your ${rs.length} unscratched ticket${rs.length>1?'s were':' was'} revealed: you won ${cmn(tot)}.`,'w')}
 else msg(nsSt().day!==nsToday()?'A free ticket is waiting in your Daily gift!':boost?'Act VI launch week: every prize pays 25% more! Pick a ticket and press Buy.':'Pick a ticket and press Buy.');
 slot.innerHTML=`<div class="nzcw idle">${ticketHTML({t:tier,c:[],b:boost},true)}</div>`;fit(slot.firstElementChild);
 selPanel();U()}

/* ---------- styles ---------- */
{const st=document.createElement('style');st.textContent=`
#ov.gdo .nssw{position:absolute;right:0;top:-50px;display:flex;gap:6px;padding:4px;border-radius:14px;background:#12060fcc;border:1.5px solid #b8861a88}
#ov.gdo .nssw button{all:unset;cursor:pointer;display:flex;align-items:center;gap:8px;padding:7px 14px;border-radius:10px;font:700 14px var(--ui);color:#e8c878;letter-spacing:.3px;transition:background .2s,color .2s}
#ov.gdo .nssw button:hover{background:#ffffff12;color:#fff}
#ov.gdo .nssw button.on{background:linear-gradient(180deg,#fff0a0,#e8a020);color:#2a1002}
#ov.gdo .nssw em{font:800 10px var(--ui);font-style:normal;padding:2px 6px;border-radius:8px;background:#d01c38;color:#fff;letter-spacing:1px}
#ov.gdo .nssw .nsdot{width:9px;height:9px;border-radius:50%;background:#c86bff;box-shadow:0 0 8px #c86bff;animation:nsdot 1.6s ease-in-out infinite}
@keyframes nsdot{50%{transform:scale(1.5);opacity:.6}}
#ov.gdo .nsfeat{background:linear-gradient(110deg,#1e0a3e,#0c0420) padding-box,linear-gradient(160deg,#ffe8a0,#c86bff 40%,#5a2ab0 70%,#ffd24a) border-box}
#ov.gdo .nsfeat.boost{box-shadow:0 14px 34px #000c,0 0 44px #c86bff77}
#ov.gdo .nsfeat .twfart::after{background:linear-gradient(90deg,transparent 60%,#0c0420)}
#ov.gdo .nsfeat .twfinfo h3{color:#f4e2ff;text-shadow:0 3px 0 #2a0a50,0 0 22px #c86bffaa}
#ov.gdo .nsfeat .twfinfo p,#ov.gdo .nsfeat .twfl li{color:#e4d8ff}
#ov.gdo .nsfeat .twfl b{color:#ffd24a}
#ov.gdo .nsfeat .twfs{border-color:#8a5ad888}
#ov.gdo .nsfeat .twfs span{color:#c8a8ff}
#ov.gdo .nsbadge{background:linear-gradient(90deg,#ffe27a,#ff9ad8);box-shadow:0 0 14px #ff9ad888}
#ov.gdo .nsboost{background:linear-gradient(90deg,#7a2ad866,#ff5ab830);border-color:#d08aff99}
#ov.gdo .nsrib{background:linear-gradient(180deg,#b06aff,#5a1ab0)}
#ov.gdo .nsgiftb{background:linear-gradient(90deg,#7a2ad8,#c86bff)}
.nz{--gd:#e8c36a;--gd2:#a8742c;--nv:#0b0f34;display:grid;grid-template-columns:236px minmax(0,1fr) 268px;grid-template-rows:auto minmax(0,1fr) auto auto;gap:10px 16px;width:100%;max-width:1440px;height:min(100%,708px);flex:none;min-height:0;margin:0 auto;color:#e8e4ff}
.nzbox{position:relative;border-radius:16px;padding:12px 14px;background:linear-gradient(180deg,#151a4cf2,#090c2af6);border:2px solid var(--gd);box-shadow:0 8px 20px #000b,inset 0 0 0 1px #ffe7a022,inset 0 0 22px #6a7aff1a}
.nzbox::before,.nzbox::after{content:'';position:absolute;width:16px;height:16px;border:2px solid #fff2b0;pointer-events:none;opacity:.7}
.nzbox::before{left:5px;top:5px;border-right:0;border-bottom:0;border-radius:6px 0 0 0}.nzbox::after{right:5px;bottom:5px;border-left:0;border-top:0;border-radius:0 0 6px 0}
.nzlab{display:block;font:800 12px var(--ui);letter-spacing:1.6px;text-transform:uppercase;color:var(--gd);text-align:center}.nzlab.sm{margin-top:8px;font-size:11px;opacity:.85}.nzlab.c{margin-bottom:8px}
/* ticket tabs */
.nztiers{grid-column:2;display:flex;justify-content:center;gap:12px;padding:6px 10px;border-radius:18px;background:linear-gradient(180deg,#1a1450e6,#0b0a2ae6);border:2px solid var(--gd);box-shadow:0 8px 20px #000a;align-self:center;justify-self:center}
.nztier{all:unset;box-sizing:border-box;position:relative;display:flex;align-items:center;gap:12px;padding:8px 18px 8px 12px;min-width:198px;border-radius:12px;cursor:pointer;background:linear-gradient(115deg,color-mix(in srgb,var(--c2) 45%,#0b0a2a),#0b0a2a);border:2px solid color-mix(in srgb,var(--c) 35%,transparent);transition:transform .18s,box-shadow .2s,border-color .2s,filter .2s}
.nztier:hover:not(:disabled){transform:translateY(-2px);filter:brightness(1.12)}
.nztier.on{border-color:var(--c);box-shadow:0 0 0 2px color-mix(in srgb,var(--c) 40%,transparent),0 0 26px color-mix(in srgb,var(--c) 60%,transparent),inset 0 0 18px color-mix(in srgb,var(--c) 25%,transparent)}
.nztier:disabled{cursor:default;filter:saturate(.5) brightness(.75)}.nztier.on:disabled{filter:none}
.nzti{display:block;width:44px;height:32px;filter:drop-shadow(0 3px 5px #0009)}.nzti svg{width:100%;height:100%;display:block}.nzti.lg{width:58px;height:42px}
.nztier.on .nzti{animation:nzti 2.4s ease-in-out infinite}@keyframes nzti{50%{transform:rotate(-6deg) scale(1.08)}}
.nztx{display:flex;flex-direction:column;line-height:1.05}.nztx b{font:400 28px 'Pirata One',Georgia,serif;color:var(--c);text-shadow:0 2px 0 #0008}.nztx em{display:flex;align-items:center;gap:6px;font:800 16px var(--ui);font-style:normal;color:#fff0c0}.nztx .coin{width:15px;height:15px}
.nztier kbd{position:absolute;right:7px;top:6px;font:700 10px var(--ui);padding:0 5px;border-radius:4px;border:1px solid #ffffff33;color:#ffffff88}
/* left column */
.nzl{grid-column:1;grid-row:1/4;display:flex;flex-direction:column;gap:12px;min-height:0}
.nzgift{text-align:center;display:flex;flex-direction:column;align-items:center;gap:6px}.nzgift b{font:400 22px 'Pirata One',Georgia,serif;color:#fff0c0;line-height:1.1}.nzgift small{font:600 12.5px var(--ui);color:#c8c2f0}
.nzgi{display:block;width:62px;height:62px;filter:drop-shadow(0 4px 8px #000a)}.nzgi svg{width:100%;height:100%}.nzgi.rdy{animation:nzgift 1.4s ease-in-out infinite}
@keyframes nzgift{0%,100%{transform:rotate(0) scale(1)}20%{transform:rotate(-9deg) scale(1.08)}40%{transform:rotate(8deg) scale(1.08)}60%{transform:rotate(0) scale(1)}}
.nzclaim{all:unset;box-sizing:border-box;cursor:pointer;padding:9px 16px;border-radius:12px;font:400 22px 'Pirata One',Georgia,serif;color:#fff;text-shadow:0 2px 0 #2a0a50;background:linear-gradient(180deg,#e4c8ff,#9a5ae8 55%,#5a2ab0);border:2px solid #f4e8ff;box-shadow:0 5px 0 #2a0a50,0 8px 18px #000a,0 0 22px #c86bff88;animation:nzclaim 1.6s ease-in-out infinite}
.nzclaim:hover{filter:brightness(1.12)}.nzclaim:active{transform:translateY(3px);box-shadow:0 2px 0 #2a0a50}@keyframes nzclaim{50%{box-shadow:0 5px 0 #2a0a50,0 8px 18px #000a,0 0 36px #e0a0ffcc}}
.nzsess{flex:1;min-height:0;text-align:center;display:flex;flex-direction:column;align-items:center;gap:2px}
.nzbig{font:400 40px/1.05 'Pirata One',Georgia,serif;color:#fff0c0}.nzbig.up{color:#7dffb0;text-shadow:0 0 14px #2aff8a66}.nzbig.dn{color:#ff9aa8}
.nzstats{width:100%;display:grid;grid-template-columns:1fr 1fr;gap:5px;margin-top:8px}.nzstats div{display:flex;flex-direction:column;align-items:center;padding:4px 2px;border-radius:9px;background:#0006;border:1px solid #ffffff14}.nzstats span{font:700 10.5px var(--ui);letter-spacing:.6px;text-transform:uppercase;color:#a8a2d8}.nzstats b{font:400 20px 'Pirata One',Georgia,serif;color:#ffe9a8}
.nzsess small{font:600 12.5px var(--ui);color:#c8c2f0}
.nzhist{display:flex;flex-wrap:wrap;gap:5px;justify-content:center;margin-top:4px}.nzhist em{font:italic 13px Georgia,serif;opacity:.6}
.nzh{min-width:34px;padding:2px 6px;border-radius:9px;text-align:center;font:700 12px var(--ui);color:#ffffff77;background:#0006;border:1px solid #ffffff1c}
.nzh.w{color:#7dffb0;border-color:#7dffb066}.nzh.big{color:#2a1002;background:linear-gradient(180deg,#fff0a0,#f0a820);border-color:#fff4b8}
/* right column */
.nzr{grid-column:3;grid-row:1/4;display:flex;flex-direction:column;min-height:0}
.nzsel{flex:1;display:flex;flex-direction:column;gap:10px}
.nzsh{display:flex;align-items:center;gap:12px;padding:8px 10px;border-radius:12px;background:linear-gradient(110deg,color-mix(in srgb,var(--c2) 40%,#0b0a2a),#0b0a2a);border:1.5px solid color-mix(in srgb,var(--c) 50%,transparent)}
.nzsh b{font:400 34px 'Pirata One',Georgia,serif;color:var(--c);text-shadow:0 0 18px color-mix(in srgb,var(--c) 50%,transparent)}
.nzrows{display:flex;flex-direction:column;border-radius:12px;background:#0007;border:1px solid #ffffff1a;overflow:hidden}
.nzrows>div{display:flex;align-items:center;gap:10px;padding:8px 12px;font:600 15px var(--ui);color:#e8e4ff}.nzrows>div+div{border-top:1px solid #ffffff12}
.nzrows b{margin-left:auto;font:400 26px 'Pirata One',Georgia,serif;color:#ffe27a}.nzrows .coin{width:22px;height:22px}.nzcup{display:block;width:22px;height:22px}.nzcup svg{width:100%;height:100%}
.nzsel p{margin:0;font:500 13.5px/1.45 var(--ui);color:#d4cef4}
.nzlink{all:unset;box-sizing:border-box;display:flex;align-items:center;gap:10px;padding:10px 14px;border-radius:12px;cursor:pointer;font:700 15px var(--ui);color:#fff;background:linear-gradient(180deg,#232a6a,#141848);border:1.5px solid #8a94e0aa;transition:transform .15s,border-color .15s,background .15s}
.nzlink svg{width:22px;height:22px;color:#e8e4ff}.nzlink i{margin-left:auto;font:800 20px var(--ui);font-style:normal;color:var(--gd)}.nzlink:hover{transform:translateX(3px);border-color:var(--gd);background:linear-gradient(180deg,#2c347c,#181c54)}
/* the stage */
.nzstage{grid-column:2;grid-row:2;position:relative;border-radius:20px;overflow:hidden;border:2.5px solid var(--gd);box-shadow:0 12px 30px #000c,inset 0 0 50px #000c,inset 0 0 0 1px #fff2b033;background:radial-gradient(ellipse at 30% 20%,#2a1874,#110a3a 55%,#05031a);min-height:0}
.nzneb{position:absolute;inset:-20%;pointer-events:none}.nzneb i{position:absolute;border-radius:50%;filter:blur(44px);opacity:.5;animation:nzneb 18s ease-in-out infinite alternate}
.nzneb .b1{left:5%;top:10%;width:55%;height:50%;background:#5a2ad8}.nzneb .b2{right:0;bottom:5%;width:50%;height:55%;background:#ff3ab0;opacity:.26;animation-duration:23s}.nzneb .b3{left:35%;top:40%;width:40%;height:40%;background:#2a8aff;opacity:.3;animation-duration:15s}
@keyframes nzneb{to{transform:translate(8%,-6%) scale(1.15) rotate(12deg)}}
.nzstars{position:absolute;inset:0;pointer-events:none}.nzst{position:absolute;width:var(--s);height:var(--s);border-radius:50%;background:#fff;box-shadow:0 0 6px #fff;animation:nztw 3.2s ease-in-out var(--d) infinite}@keyframes nztw{50%{opacity:.2;transform:scale(.6)}}
.nzastro{position:absolute;left:50%;top:50%;width:min(96%,720px);height:auto;transform:translate(-50%,-50%);pointer-events:none;animation:nzastro 90s linear infinite}@keyframes nzastro{to{transform:translate(-50%,-50%) rotate(360deg)}}
.nzslot{position:absolute;inset:26px 0 34px;display:flex;align-items:center;justify-content:center}
.nzcw{position:absolute;left:0;right:0;transform-origin:50% 50%;display:flex;align-items:center;justify-content:center}
/* the ticket: scalloped edges, gold inner frame */
.nzt{position:relative;width:min(700px,94%);padding:10px;filter:drop-shadow(0 18px 30px #000c) drop-shadow(0 0 22px color-mix(in srgb,var(--c) 40%,transparent));animation:nzin .7s cubic-bezier(.2,1.25,.35,1) both;user-select:none;-webkit-user-select:none}
.nzt::before{content:'';position:absolute;inset:0;border-radius:18px;background:radial-gradient(circle at 20% 0%,color-mix(in srgb,var(--c) 35%,transparent),transparent 50%),radial-gradient(circle at 90% 100%,#ff5ab833,transparent 45%),linear-gradient(160deg,var(--c2),var(--c3) 75%);
 -webkit-mask:radial-gradient(circle at 0 50%,transparent 9px,#000 10px) left/51% 26px repeat-y,radial-gradient(circle at 100% 50%,transparent 9px,#000 10px) right/51% 26px repeat-y;mask:radial-gradient(circle at 0 50%,transparent 9px,#000 10px) left/51% 26px repeat-y,radial-gradient(circle at 100% 50%,transparent 9px,#000 10px) right/51% 26px repeat-y}
.nztin{position:relative;margin:0 14px;padding:10px 14px 10px;border-radius:12px;border:2px solid var(--gd);box-shadow:inset 0 0 0 4px #00000033,inset 0 0 0 5px #fff2b044;background:radial-gradient(circle,#ffffff14 1px,transparent 1.6px) 0 0/18px 18px}
.nztin::before,.nztin::after{content:'✦';position:absolute;top:-2px;font:16px Georgia,serif;color:#fff2b0;text-shadow:0 0 8px #ffd24a}.nztin::before{left:6px}.nztin::after{right:6px}
.nzt.free .nztin{border-style:double;border-width:5px}
.nzt.demo{animation:nzfloat 5s ease-in-out infinite}.nzt.demo .nzcell{filter:saturate(.75) brightness(.85)}
@keyframes nzfloat{50%{transform:translateY(-8px)}}
@keyframes nzin{from{transform:translateX(120%) rotate(12deg) scale(.85);opacity:0}to{transform:none;opacity:1}}
.nzt.out{animation:nzout .65s cubic-bezier(.6,0,.8,.4) forwards}@keyframes nzout{to{transform:translate(-130%,40px) rotate(-16deg) scale(.8);opacity:0}}
.nzt.won{animation:nzwon .8s cubic-bezier(.3,1.6,.5,1) both}@keyframes nzwon{40%{transform:scale(1.04)}}
.nzglint{position:absolute;inset:10px 24px;border-radius:12px;pointer-events:none;background:linear-gradient(115deg,transparent 30%,#ffffff26 45%,transparent 60%);background-size:250% 100%;animation:nzglint 4.5s ease-in-out infinite;z-index:4;mix-blend-mode:screen}@keyframes nzglint{0%,30%{background-position:120% 0}70%,100%{background-position:-60% 0}}
.nzth{text-align:center;line-height:1.1}.nztt{display:block;font:400 34px 'Pirata One',Georgia,serif;letter-spacing:2px;color:#ffe27a;text-shadow:0 2px 0 #0009,0 0 18px #ffb04088}.nzth small{font:800 11px var(--ui);letter-spacing:2.2px;color:#ece6ff}.nzth small b{color:#ffd24a}
.nzplay{position:relative;display:flex;align-items:center;gap:12px;margin:8px 0}
.nzmed{position:relative;flex:none;width:66px;display:flex;flex-direction:column;align-items:center;gap:3px}
.nzmed.l svg{width:62px;height:62px;filter:drop-shadow(0 0 8px #ffd24a66)}
.nzsv{position:relative;display:grid;place-items:center;width:60px;height:60px;border-radius:50%;background:radial-gradient(circle at 40% 35%,#2a2468,#0b0a2a);border:2.5px solid var(--gd);box-shadow:inset 0 0 12px #000a}
.nzsv svg{width:40px;height:40px}.nzsv b{position:absolute;bottom:-4px;right:-8px;padding:1px 7px;border-radius:10px;font:800 15px var(--ui);color:#2a1002;background:linear-gradient(180deg,#fff0a0,#f0a820);border:1.5px solid #fff4b8;box-shadow:0 2px 6px #000a}
.nznone{font:400 30px Georgia,serif;font-style:normal;color:#8a84c0}
.nzmed small{font:800 9.5px var(--ui);letter-spacing:1.2px;color:var(--gd);white-space:nowrap}
.nzmed.r .nzsv{opacity:.35;transform:scale(.85);transition:opacity .3s,transform .5s cubic-bezier(.3,1.7,.5,1)}.nzmed.r.rev .nzsv,.nzt.demo .nzmed.r .nzsv{opacity:1;transform:none}
.nzmed.r.lucky .nzsv{border-color:#fff2b0;box-shadow:0 0 0 3px #ffd24a,0 0 26px #ffd24a,inset 0 0 12px #000a;animation:nzlucky 1.2s ease-in-out infinite}@keyframes nzlucky{50%{box-shadow:0 0 0 3px #fff2b0,0 0 44px #ffd24a,inset 0 0 12px #000a}}
.nzmed.r.slam .nzsv{animation:nzslam .7s cubic-bezier(.2,1.8,.4,1)}@keyframes nzslam{0%{transform:scale(2.6) rotate(-30deg)}60%{transform:scale(.9)}100%{transform:none}}
.nzgrid{flex:1;display:grid;grid-template-columns:repeat(3,1fr);gap:10px}
.nzcell{position:relative;aspect-ratio:1.3/1;border-radius:12px;background:radial-gradient(circle at 50% 42%,color-mix(in srgb,var(--c) 26%,#141048),#080624);border:1.5px solid #e8c36a55;display:flex;flex-direction:column;align-items:center;justify-content:center;overflow:hidden;transition:filter .4s,opacity .4s}
.nzcell .nzsy{display:block;width:62%;height:74%;transform:scale(.55);opacity:.0;transition:transform .5s cubic-bezier(.3,1.7,.5,1),opacity .25s}
.nzcell .nzsy svg{width:100%;height:100%;display:block;filter:drop-shadow(0 3px 6px #000a)}
.nzcell em{position:absolute;bottom:3px;font:800 10px var(--ui);font-style:normal;letter-spacing:.8px;color:#ffffffb0;text-transform:uppercase;opacity:0;transition:opacity .3s .15s}
.nzcell.rev .nzsy{transform:none;opacity:1}.nzcell.rev em{opacity:1}
.nzcell.pair{border-color:var(--c);box-shadow:0 0 0 2px var(--c),0 0 18px var(--c);animation:nzpair 1s ease-in-out infinite}@keyframes nzpair{50%{box-shadow:0 0 0 2px var(--c),0 0 32px var(--c)}}
.nzcell.win{border-color:#ffd24a;box-shadow:0 0 0 3px #ffd24a,0 0 30px #ffb02a;animation:nzwin .9s cubic-bezier(.3,1.6,.5,1) both,nzwin2 1.2s ease-in-out .9s infinite;z-index:2}
.nzcell.win .nzsy{animation:nzspin 1.2s ease-out}@keyframes nzwin{40%{transform:scale(1.1)}}@keyframes nzwin2{50%{box-shadow:0 0 0 3px #fff2b0,0 0 44px #ffd24a}}@keyframes nzspin{from{transform:rotate(-25deg) scale(1.3)}}
.nzcell.dim{filter:saturate(.35) brightness(.5)}.nzcell.near{filter:none;border-color:#ff8a98aa;box-shadow:0 0 0 2px #ff8a9866}
.nzline{position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:3;overflow:visible}
.nzline polyline{fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:900;stroke-dashoffset:900}.nzline .g{stroke:#ffb02a;stroke-width:14;opacity:.45;filter:blur(4px)}.nzline .l{stroke:#fff2b0;stroke-width:4}.nzline .d{fill:#fff2b0;opacity:0}
.nzline.on polyline{animation:nzdraw .55s ease-out forwards}.nzline.on .d{animation:nzdot .3s .5s forwards}@keyframes nzdraw{to{stroke-dashoffset:0}}@keyframes nzdot{to{opacity:1}}
.nzfoil{position:absolute;inset:0;width:100%;height:100%;touch-action:none;z-index:2;cursor:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='44' height='44' viewBox='0 0 44 44'%3E%3Ccircle cx='22' cy='22' r='17' fill='%23ffc94a' stroke='%238a5a08' stroke-width='3'/%3E%3Ccircle cx='22' cy='22' r='11' fill='none' stroke='%23b8780c' stroke-width='2.5'/%3E%3Cpath d='M22 15l2 5 5 2-5 2-2 5-2-5-5-2 5-2z' fill='%23fff2b0'/%3E%3C/svg%3E") 22 22,crosshair}
.nzhand{position:absolute;left:18%;top:12%;width:48px;height:48px;z-index:5;pointer-events:none;border-radius:50%;background:radial-gradient(circle at 35% 30%,#fff3a0,#d8961c 70%);box-shadow:0 0 0 2.5px #8a5a08,0 0 18px #ffd76a,0 0 0 10px #ffffff22;animation:nzhand 2s ease-in-out infinite}
.nzhand::after{content:'DRAG TO SCRATCH';position:absolute;left:50%;top:58px;transform:translateX(-50%);white-space:nowrap;padding:3px 10px;border-radius:10px;font:800 11px var(--ui);letter-spacing:1.4px;color:#2a1002;background:linear-gradient(180deg,#fff0a0,#f0a820);box-shadow:0 3px 8px #0009}
@keyframes nzhand{0%{transform:translate(0,0);opacity:0}10%{opacity:1}35%{transform:translate(260px,10px)}60%{transform:translate(20px,90px)}85%{transform:translate(280px,110px);opacity:1}100%{transform:translate(280px,110px);opacity:0}}
.nzfoot{display:flex;flex-direction:column;align-items:center;padding:6px 10px;border-radius:12px;background:#0009;border:1.5px solid #e8c36a55;text-align:center;min-height:56px;justify-content:center}
.nzfoot span{font:800 11.5px var(--ui);letter-spacing:1.8px;text-transform:uppercase;color:#9ff0ff}
.nzfoot b{font:400 24px 'Pirata One',Georgia,serif;color:#ffe9a8;display:flex;align-items:center;gap:7px}.nzfoot b small{font:800 14px var(--ui);color:#ffd24a}.nzfoot b em{font-style:normal}.nzfoot .coin{width:.75em;height:.75em}
.nzfoot.win{border-color:#ffd24a;background:linear-gradient(180deg,#ffb02a33,#0009);animation:nzplate .6s cubic-bezier(.3,1.6,.5,1) both}.nzfoot.win b{font-size:32px;color:#ffe27a;text-shadow:0 0 18px #ffb02a}.nzfoot.big b{font-size:38px}
@keyframes nzplate{from{transform:scale(.6);opacity:0}}.nzfoot.lose span{color:#ff9aa8}
/* stage overlays */
.nzprog{position:absolute;left:50%;top:10px;transform:translateX(-50%);z-index:6;width:240px;height:22px;border-radius:12px;background:#0a0828cc;border:1.5px solid #e8c36a88;overflow:hidden;opacity:0;transition:opacity .3s}
.nzprog.on{opacity:1}.nzprog i{position:absolute;left:0;top:0;bottom:0;background:linear-gradient(90deg,#7a2ad8,#ffd24a);transition:width .15s}.nzprog span{position:relative;display:block;text-align:center;font:800 11.5px/19px var(--ui);letter-spacing:.6px;color:#fff;text-shadow:0 1px 3px #000}
.nzmsg.cmsg{position:absolute;left:50%;bottom:8px;transform:translateX(-50%);z-index:6;margin:0;white-space:nowrap;max-width:94%;overflow:hidden;text-overflow:ellipsis;padding:3px 20px!important;font:600 16px Georgia,serif!important;min-height:0!important;border-radius:14px!important;background:#0a0828d9!important;border:1.5px solid #e8c36a77!important}
.nzdeck{position:absolute;right:calc(50% - 360px);top:calc(50% - 18px);width:0;height:0;pointer-events:none}
.nzbk{position:absolute;left:0;top:-150px;width:120px;height:300px;margin-left:-40px;border-radius:16px;background:radial-gradient(circle at 70% 50%,#fff2b0 0 5px,transparent 6px),radial-gradient(circle,#ffffff55 1px,transparent 1.6px) 0 0/14px 14px,linear-gradient(165deg,var(--c),#0a0420 80%);border:2.5px solid #ffd24aaa;box-shadow:0 10px 26px #000a;transform:translateX(calc(var(--i)*10px)) rotate(calc(5deg + var(--i)*2deg));opacity:.92}
.nzleft{position:absolute;left:10px;top:-182px;white-space:nowrap;padding:4px 12px;border-radius:12px;font:800 13px var(--ui);color:#2a1002;background:linear-gradient(180deg,#fff0a0,#f0a820);box-shadow:0 0 14px #ffc94a88}
.nzfx{position:absolute;inset:0;pointer-events:none;z-index:7;overflow:hidden}
.nzpt{position:absolute;width:var(--s);height:var(--s);border-radius:50%;animation:nzpt 1s ease-out forwards;box-shadow:0 0 6px currentColor}@keyframes nzpt{to{transform:translate(var(--dx),var(--dy)) scale(.2);opacity:0}}
.nzflake{position:absolute;width:7px;height:4px;border-radius:1px;animation:nzflake .85s ease-in forwards}@keyframes nzflake{to{transform:translate(var(--dx),var(--dy)) rotate(var(--r));opacity:0}}
.nzrain{position:absolute;top:-30px;width:var(--sz);height:var(--sz);border-radius:50%;background:radial-gradient(circle at 35% 30%,#fff3a0,#d8961c 70%);box-shadow:0 0 0 1.5px #8a5a10,0 0 10px #ffd76a;animation:nzrain 1.4s cubic-bezier(.5,0,.8,.6) forwards}@keyframes nzrain{to{transform:translateY(600px) rotate(720deg)}}
.nzflash{position:absolute;inset:0;pointer-events:none;z-index:6;opacity:0;background:radial-gradient(circle,var(--c,#fff),transparent 70%)}.nzflash.on{animation:nzflash .7s ease-out}@keyframes nzflash{20%{opacity:.75}to{opacity:0}}
.nzbanner{position:absolute;left:0;right:0;margin:0 auto;width:fit-content;max-width:94%;padding:8px 40px;top:34px;z-index:8;text-align:center;pointer-events:none;opacity:0;background:radial-gradient(ellipse at center,#0a0420e6 30%,#0a042000 72%);font:400 50px/1 'Pirata One',Georgia,serif;color:#ffe27a;text-shadow:0 4px 0 #3a0c00,0 0 24px #ffb040}
.nzbanner small{display:block;font:800 14px var(--ui);letter-spacing:2px;color:#fff;text-shadow:0 2px 6px #000}
.nzbanner.show{animation:nzban 1.9s cubic-bezier(.2,1.2,.3,1) forwards}.nzbanner.big{font-size:66px}
.nzbanner.jack{font-size:72px;background:linear-gradient(90deg,#fff2a0,#ff9ad8,#9ff0ff,#fff2a0);background-size:300% 100%;-webkit-background-clip:text;background-clip:text;color:transparent;animation:nzban 2.6s cubic-bezier(.2,1.2,.3,1) forwards,nzrbw 1.2s linear infinite}
.nzbanner.soft{font-size:40px;color:#e8e0ff}.nzbanner.tease{font-size:34px;color:#ff9ad8;text-shadow:0 3px 0 #2a0a30,0 0 20px #ff5ab8}
@keyframes nzban{0%{opacity:0;transform:scale(.4)}15%{opacity:1;transform:scale(1.08)}25%{transform:scale(1)}80%{opacity:1}100%{opacity:0;transform:translateY(-14px)}}@keyframes nzrbw{to{background-position:300% 0}}
.nzstage.nzhot{animation:nzhot 1s ease-in-out infinite}@keyframes nzhot{50%{box-shadow:0 12px 30px #000c,inset 0 0 80px #ff5ab877}}
.nzstage.nzshk{animation:nzshk .5s}@keyframes nzshk{20%{transform:translate(-6px,3px)}40%{transform:translate(5px,-3px)}60%{transform:translate(-3px,2px)}80%{transform:translate(2px,-1px)}}
/* modals */
.nzmod{position:absolute;inset:0;z-index:9;display:none;align-items:center;justify-content:center;background:#05031ad0;backdrop-filter:blur(3px)}.nzmod.on{display:flex;animation:nzfade .25s ease}
@keyframes nzfade{from{opacity:0}}
.nzmc{position:relative;width:min(560px,92%);max-height:92%;overflow:auto;padding:18px 22px;border-radius:18px;background:linear-gradient(180deg,#171c50,#090c2a);border:2px solid var(--gd);box-shadow:0 20px 50px #000d;animation:nzpop .35s cubic-bezier(.3,1.5,.5,1)}
@keyframes nzpop{from{transform:scale(.85);opacity:0}}
.nzmc h3{margin:0 0 6px;text-align:center;font:400 34px 'Pirata One',Georgia,serif;color:#ffe27a}
.nzx{all:unset;cursor:pointer;position:absolute;right:12px;top:8px;font:400 30px Georgia,serif;color:#e8c36a}.nzx:hover{color:#fff}
.nzhow{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:8px}.nzhow li{display:flex;gap:12px;align-items:flex-start;font:500 15px/1.4 var(--ui);color:#e8e4ff}
.nzhow b{flex:none;display:grid;place-items:center;width:26px;height:26px;border-radius:50%;font:800 14px var(--ui);color:#2a1002;background:linear-gradient(180deg,#fff0a0,#f0a820)}.nzhow em{font-style:normal;color:#ffd24a;font-weight:700}
.nzkeys{margin:12px 0 0;text-align:center;font:600 13px var(--ui);color:#c8c2f0}.nzkeys kbd{font:700 11px var(--ui);padding:1px 6px;border-radius:5px;background:#2a2150;border:1px solid #a9b8ff;color:#e8e4ff;margin:0 2px}
.nzodds{display:flex;flex-direction:column;gap:4px}.nzodds{gap:3px!important}.nzodds>div{display:grid;grid-template-columns:28px 1fr auto 90px 86px;align-items:center;gap:10px;padding:2px 10px;border-radius:10px;background:#00000055}
.nzodds>div.nzol{background:linear-gradient(90deg,#ffd24a22,#0005);border:1px solid #ffd24a55}
.nzoi{width:26px;height:26px;display:block}.nzoi svg{width:26px;height:26px;display:block}.nzon{font:700 14px var(--ui)}.nzom{font:400 20px 'Pirata One',Georgia,serif;color:var(--c)}.nzog{display:flex;align-items:center;gap:4px;font:700 13px var(--ui);color:#ffe9a8}.nzog .coin{width:11px;height:11px}.nzoo{font:600 12px var(--ui);color:#ffffff99;text-align:right}
.nzfine{margin:10px 0 0;text-align:center;font:500 13px/1.45 var(--ui);color:#c8c2f0}
/* buttons under the stage */
.nzbtns{grid-column:2;grid-row:3;display:flex;justify-content:center;gap:14px}
.nzbuy,.nzb5{all:unset;box-sizing:border-box;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:12px;border-radius:16px;transition:transform .12s,filter .15s,box-shadow .2s}
.nzbuy{min-width:420px;padding:8px 28px;background:linear-gradient(180deg,#fff0a0,#f4b020 55%,#d88a10);border:2.5px solid #fff4b8;box-shadow:0 6px 0 #7a4a08,0 10px 22px #000a,0 0 26px #ffc94a66,inset 0 2px 0 #fffbe0;color:#2a1002}
.nzbuy span,.nzb5 span{display:flex;flex-direction:column;align-items:center;line-height:1.05}.nzbuy b{font:400 34px 'Pirata One',Georgia,serif;text-shadow:0 1px 0 #fff6c8}.nzbuy small{font:700 12.5px var(--ui);opacity:.75}.nzbuy .coin{width:30px;height:30px}
.nzbuy:hover:not(:disabled),.nzb5:hover:not(:disabled){transform:translateY(-2px);filter:brightness(1.08)}.nzbuy:active:not(:disabled){transform:translateY(4px);box-shadow:0 2px 0 #7a4a08,0 4px 10px #000a}
.nzbuy:not(:disabled):not(.rev){animation:nzbuy 2.2s ease-in-out infinite}@keyframes nzbuy{50%{box-shadow:0 6px 0 #7a4a08,0 10px 22px #000a,0 0 40px #ffc94aaa,inset 0 2px 0 #fffbe0}}
.nzbuy.rev{background:linear-gradient(180deg,#e4c8ff,#9a5ae8 55%,#5a2ab0);border-color:#f4e8ff;color:#fff;box-shadow:0 6px 0 #2a0a50,0 10px 22px #000a,0 0 24px #c86bff66}.nzbuy.rev b{text-shadow:0 2px 0 #2a0a50}
.nzbuy.dis,.nzbuy:disabled{cursor:default;background:linear-gradient(180deg,#6a6a80,#3a3a52);border-color:#9a9ab8;color:#e8e8f4;box-shadow:0 5px 0 #1a1a2a,0 8px 18px #000a}.nzbuy.dis b,.nzbuy:disabled b{text-shadow:none}
.nzb5{padding:8px 22px;background:linear-gradient(180deg,#2a3278,#141848);border:2px solid var(--gd);box-shadow:0 5px 0 #070a24,0 8px 18px #000a;color:#ffe9a8}.nzb5 b{font:400 28px 'Pirata One',Georgia,serif}.nzb5 .coin{width:24px;height:24px}
.nzb5:disabled{cursor:default;filter:grayscale(.7) brightness(.6)}
/* bottom bar */
.nzbar{grid-column:1/4;grid-row:4;position:relative;display:flex;align-items:center;gap:18px;padding:7px 20px;border-radius:18px;background:linear-gradient(180deg,#151a4cf2,#090c2af6);border:2px solid var(--gd);box-shadow:0 8px 20px #000b,inset 0 0 0 1px #ffe7a022}
.nzbar>div{display:flex;align-items:center;gap:10px}.nzbar>div+div{padding-left:18px;border-left:1px solid #e8c36a44}
.nzci{display:block;width:38px;height:38px;flex:none;filter:drop-shadow(0 0 8px #ffd24a88)}.nzci svg{width:100%;height:100%}.nzci.sm{width:20px;height:20px}
.nzcon{flex:1;min-width:0}.nzcm{flex:1;min-width:0;display:flex;flex-direction:column}.nzcm>b{font:400 22px 'Pirata One',Georgia,serif;color:#ffe9a8;line-height:1}
.nzcm svg{width:100%;height:24px}.nzcl{display:flex;justify-content:space-between;font:600 12.5px var(--ui);color:#c8c2f0}.nzcl b{font:400 20px 'Pirata One',Georgia,serif;color:#ffe27a}
.nzlast2{animation:nzl2 1.4s ease-in-out infinite;transform-box:fill-box;transform-origin:center}@keyframes nzl2{50%{transform:scale(1.6)}}
.nzrem b{font:400 40px 'Pirata One',Georgia,serif;color:#ffe27a;line-height:1}.nzrem small{font:600 12px/1.15 var(--ui);color:#c8c2f0}
.nzlast{flex-direction:column;align-items:flex-start!important;gap:3px!important}.nzlast .nzlab{text-align:left}
.nzlc{display:flex;align-items:center;gap:10px;min-width:220px;padding:5px 12px;border-radius:12px;background:#0007;border:1px solid #ffffff1a}
.nzlsym{display:grid;place-items:center;width:36px;height:36px}.nzq{font:400 26px Georgia,serif;font-style:normal;color:#8a84c0;display:grid;place-items:center;width:30px;height:34px;border:1.5px dashed #8a84c0;border-radius:6px}
.nzlc>span:last-child{display:flex;flex-direction:column;line-height:1.15}.nzlc b{font:700 14px var(--ui);color:#7dffb0}.nzlc b.ls{color:#ffb0b8}.nzlc small{font:600 12px var(--ui);color:#c8c2f0}
.nzboost{flex-direction:column;align-items:flex-end!important;gap:6px!important}
.nzboost>span:last-child{display:flex;align-items:center;gap:6px;padding:5px 14px;border-radius:14px;font:700 13px var(--ui);color:#fff;background:linear-gradient(90deg,#7a2ad8cc,#ff3ab0aa);border:1.5px solid #ffd2f4aa;box-shadow:0 0 16px #ff5ab855}
.nzboost{display:flex}.nzboost .nzci{display:none}
/* win celebrations */
.nzrays{position:absolute;left:50%;top:50%;width:1400px;height:1400px;margin:-700px 0 0 -700px;pointer-events:none;border-radius:50%;opacity:0;background:repeating-conic-gradient(from 0deg,#ffe27a55 0deg 6deg,transparent 6deg 18deg);-webkit-mask:radial-gradient(circle,#000 0,#000 18%,transparent 62%);mask:radial-gradient(circle,#000 0,#000 18%,transparent 62%);animation:nzrays 3s ease-out forwards}
.nzrays.t1{background:repeating-conic-gradient(from 0deg,#ffe27a30 0deg 5deg,transparent 5deg 20deg)}
.nzrays.t3{background:repeating-conic-gradient(from 0deg,#ffe27a77 0deg 7deg,transparent 7deg 16deg)}
.nzrays.t4{background:repeating-conic-gradient(from 0deg,#fff6c088 0deg 6deg,#ff9ad833 6deg 11deg,transparent 11deg 15deg);animation:nzrays 4.2s ease-out forwards}
@keyframes nzrays{0%{opacity:0;transform:rotate(0) scale(.6)}15%{opacity:1}70%{opacity:.85}100%{opacity:0;transform:rotate(70deg) scale(1.1)}}
.nzring{position:absolute;width:20px;height:20px;margin:-10px 0 0 -10px;border-radius:50%;border:4px solid var(--c);box-shadow:0 0 18px var(--c),inset 0 0 12px var(--c);opacity:0;animation:nzring 1.1s cubic-bezier(.2,.7,.3,1) forwards}
@keyframes nzring{0%{opacity:1;transform:scale(.3)}100%{opacity:0;transform:scale(28)}}
.nzbigsym{position:absolute;left:50%;top:46%;width:260px;height:260px;margin:-130px 0 0 -130px;z-index:9;pointer-events:none;filter:drop-shadow(0 0 40px #fff6c0);animation:nzbigsym 2.2s cubic-bezier(.2,1.2,.3,1) forwards}
@keyframes nzbigsym{0%{opacity:0;transform:scale(.2) rotate(-40deg)}20%{opacity:1;transform:scale(1.15) rotate(6deg)}35%{transform:scale(1) rotate(0)}75%{opacity:1;transform:scale(1.05)}100%{opacity:0;transform:translateY(150px) scale(.2)}}
.nzstage.nzcosmic{animation:nzcos 3.4s ease-out}@keyframes nzcos{0%{filter:none}10%{filter:brightness(1.7) saturate(1.4)}40%{filter:brightness(1.2) saturate(1.25)}100%{filter:none}}
.nzstage.nzcosmic .nzneb i{animation-duration:2.5s!important;opacity:.9}
.nzstage.nzwarp .nzst{animation:nzwarp .6s linear infinite}@keyframes nzwarp{0%{transform:scale(1)}50%{transform:scaleX(5) translateX(8px);opacity:.6}100%{transform:scale(1)}}
.nzt.w2,.nzt.w3,.nzt.w4{animation:nzhero 1.2s cubic-bezier(.3,1.5,.5,1) both}@keyframes nzhero{0%{transform:scale(1)}30%{transform:scale(1.07) rotate(-1deg)}60%{transform:scale(1.02) rotate(.5deg)}100%{transform:none}}
.nzt.w3::after,.nzt.w4::after{content:'';position:absolute;inset:-6px;border-radius:22px;pointer-events:none;box-shadow:0 0 0 3px #ffe27a,0 0 50px #ffb02a,0 0 110px #ffb02a88;animation:nzhalo 1.4s ease-in-out infinite}
.nzt.w4::after{box-shadow:0 0 0 3px #fff6c0,0 0 60px #ff9ad8,0 0 130px #9ff0ffaa}
@keyframes nzhalo{50%{opacity:.55}}
.nzcell.win::after{content:'';position:absolute;inset:-40%;pointer-events:none;background:conic-gradient(from 0deg,transparent 0 70%,#fff6c0cc 80%,transparent 90%);animation:nzsweep 1.6s linear infinite;mix-blend-mode:screen;opacity:.8}
@keyframes nzsweep{to{transform:rotate(360deg)}}
.nzcell.win .nzsy{animation:nzspin2 .9s cubic-bezier(.3,1.6,.5,1)}@keyframes nzspin2{0%{transform:rotateY(0) scale(1)}50%{transform:rotateY(180deg) scale(1.25)}100%{transform:rotateY(360deg) scale(1)}}
.nzfoot.win em{display:inline-block;min-width:2ch}
.nzfoot.t1 b{font-size:30px}.nzfoot.t2 b{font-size:34px}.nzfoot.t3 b,.nzfoot.t4 b{font-size:40px}
.nzfoot.t4{border-color:#fff6c0;background:linear-gradient(90deg,#ff9ad844,#ffd24a44,#9ff0ff44);background-size:200% 100%;animation:nzplate .6s cubic-bezier(.3,1.6,.5,1) both,nzrbw 2s linear infinite}
.nzfoot.done b{animation:nzthump .45s cubic-bezier(.3,1.8,.5,1)}@keyframes nzthump{40%{transform:scale(1.18)}}
#nzfly{position:fixed;inset:0;pointer-events:none;z-index:9999}
.nzfc{position:absolute;left:0;top:0;width:22px;height:22px;margin:-11px 0 0 -11px;border-radius:50%;background:radial-gradient(circle at 35% 30%,#fff3a0,#d8961c 70%);box-shadow:0 0 0 1.5px #8a5a10,0 0 12px #ffd76a}
.nzgot{animation:nzgot .5s cubic-bezier(.3,1.8,.5,1)}@keyframes nzgot{40%{transform:scale(1.14);box-shadow:0 0 30px #ffd24a}}
@media (prefers-reduced-motion:reduce){.nzneb i,.nzst,.nzglint,.nzt.demo,.nzastro,.nzbuy{animation:none!important}}
`;document.head.appendChild(st)}
