# python3 t_ramparts.py [--quick] : Runestone Ramparts 8.8b (95a-95h) - maps, placement, building, cooldown abilities, health, coins,
# tutorials, rewards, menus and hooks, plus a bot (no typing: it builds, upgrades and uses abilities) that plays every map to check the
# balance (a sensible build wins every map; a lazy one wins map 1 but not map 3).
import asyncio,os,sys
from playwright.async_api import async_playwright
QUICK='--quick' in sys.argv
BOT=r"""
window.rpBot=function(id,opt){opt=opt||{};rpStart(id);const R=RPX;R.spd=3;const T=RPP().tut;for(const k of['build','wave','coins','upgrade','abil','twist_frost','twist_ember'])T[k]=1;R.tut=null;R.hold=false;
 const order=opt.order||['ballista','brazier','frost','bell'];let bi=0,steps=0;
 const cov=p=>{let n=0;for(const q of R.G.U){if((q.x-p.x)**2+((q.y-p.y)/.75)**2<210*210)n++}return n};
 const pads=[...R.pads].sort((a,b)=>cov(b)-cov(a));
 const act=()=>{for(let k=0;k<6;k++){const free=pads.find(p=>!p.tw);const t=order[bi%order.length];
   if(free&&R.supply>=rpCost(t,1)&&(!opt.maxT||R.pads.filter(p=>p.tw).length<opt.maxT)){rpBuild(free,t);bi++;continue}
   if(!free||opt.up){const tw=R.pads.filter(p=>p.tw&&p.tw.tier<3).map(p=>p.tw).sort((a,b)=>a.tier-b.tier)[0];if(tw&&R.supply>=rpCost(tw.type,tw.tier+1)+(free?rpCost(order[bi%order.length],1):0)){rpUpgrade(tw);continue}}
   break}R.sel=null};
 while(!R.over&&steps<30*60*40){steps++;
  if(R.wst==='build'){act();rpWaveStart()}
  if(R.wst==='done'){if(!R.over){rpFinish(R.won)}break}
  if(!opt.noAbil&&R.wst==='run'){const live=R.foes.filter(e=>!e.dead&&e.s>0).length;
   if(R.abCd.repair<=0&&R.hp<=RPT.HP-4)rpAbility('repair',true);
   if(R.abCd.slow<=0&&live>6)rpAbility('slow',true);
   if(R.abCd.over<=0&&live>3)rpAbility('over',true)}
  if(R.wst==='run'&&steps%30===0)act();
  rpUpdate(1/30)}
 return{id,won:!!R.won,hp:R.hp,wave:R.wave,stars:R.result?R.result.stars:0,kills:R.kills,leaked:R.leaked,towers:R.pads.filter(p=>p.tw).map(p=>p.tw.type.slice(0,2)+p.tw.tier).join(' '),time:Math.round(R.time),coins:R.result?R.result.total:0,run:R.result?R.result.run:0,abil:R.abil}};
"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        pg.on('console',lambda m:er.append('CE '+m.text[:300]) if m.type=='error' and 'ERR_' not in m.text else None)
        await pg.goto('file://'+os.path.abspath('out.html'));await pg.wait_for_timeout(1200);E=pg.evaluate;bad=0
        def chk(n,v,ok):
            nonlocal bad
            if not ok:bad+=1
            print(n,v,'OK' if ok else 'BAD')
        await E("()=>{RS_ASK=false;P.gold=1000;delete P.rp;save();title()}");await pg.wait_for_timeout(400)
        await E("()=>{"+BOT+"}")
        # menus and hooks
        r=await E("async()=>{const sl=ms=>new Promise(r=>setTimeout(r,ms));title();await sl(400);const card=!!document.querySelector('#dkrp');modeSheet();await sl(400);const ms=!!document.querySelector('#dmrp');dkClose(true);await sl(200);"
          "title();await sl(300);document.dispatchEvent(new KeyboardEvent('keydown',{key:'u'}));window.dispatchEvent(new KeyboardEvent('keydown',{key:'u'}));await sl(500);const hub=!!document.querySelector('.rphub');"
          "return [card,ms,hub,ov.querySelectorAll('.rpnode').length,ov.querySelectorAll('.rpnode.lock').length,ov.querySelectorAll('.rptk').length,!!$('rpprev'),!!document.querySelector('#rpnri canvas')]}")
        chk('home card, Choose-mode card, U key opens the world hub: 3 regions (2 locked), armory track, preview, next region',r,r[:3]==[True,True,True] and r[3]==3 and r[4]==2 and r[5]==5 and r[6] and r[7])
        r=await E("()=>{$('rphow').click();const a=!$('rpmod').hidden&&/How to play/.test($('rpmod').textContent)&&!/[Tt]ype the word/.test($('rpmod').textContent);$('rpmx').click();$('rpvr').click();const b=ov.querySelectorAll('#rpmod .rpsk.lock').length;$('rpmx').click();return [a,b,$('rpmod').hidden]}")
        chk('How to play (no typing) and View rewards (5 locked rewards) open and close',r,r==[True,5,True])
        r=await E("()=>{const L=[...ov.querySelectorAll('.rphub button')].map(e=>e.getBoundingClientRect()).filter(r=>r.width>0);let n=0;for(let i=0;i<L.length;i++)for(let j=i+1;j<L.length;j++){const a=L[i],c=L[j];if(a.left<c.right-1&&c.left<a.right-1&&a.top<c.bottom-1&&c.top<a.bottom-1)n++}return [ov.querySelectorAll('.fback').length,n,!!$('rphback')]}")
        chk('hub: one Back button (no shell duplicate), no overlapping buttons',r,r==[0,0,True])
        r=await E("async()=>{const r0=RS;rpStart('moss');RPX.tut=null;RS=1.5;cv.width=2400;cv.height=1350;await new Promise(r=>setTimeout(r,300));const g=cv.getContext('2d'),a=[g.getImageData(2396,1346,1,1).data[3],g.getImageData(2396,4,1,1).data[3]];rpLeave();RS=r0;applyLayout();return a}")
        chk('the battle fills the whole canvas at a render scale above 1 (no menu background showing through)',r,r==[255,255])
        await E("()=>{title();rampartsMenu(title)}")
        # maps
        for m in ['moss','frost','ember']:
            r=await E(f"""()=>{{const map=RP_MAP('{m}'),G=rpGeo(map),B=rpBake(map),c=B.cast,BX=RP_PADBOX;let worst=1e9,sp=1e9,box=true,wet=false,vent=false,cast=false;
              for(const p of G.pads){{worst=Math.min(worst,G.dRoad(p.x,p.y));if(p.x<BX.x0||p.x>BX.x1||p.y<BX.y0||p.y>BX.y1)box=false;if(G.dRiver(p.x,p.y)<70||G.inLake(p.x,p.y,30))wet=true;if((map.vents||[]).some(v=>Math.hypot(v[0]-p.x,v[1]-p.y)<80))vent=true;if(p.x+50>c.x)cast=true;
               for(const q of G.pads)if(q!==p)sp=Math.min(sp,Math.hypot(q.x-p.x,(q.y-p.y)*1.15))}}
              const g=G.paths[0].S[G.paths[0].S.length-1];return [G.pads.length,Math.round(worst),Math.round(sp),box,wet,vent,cast,G.paths.length,G.ent.length,B.c.width+'x'+B.c.height,Math.round(g.x)+','+Math.round(g.y),c.w>0]}}""")
            want={'moss':(1,1),'frost':(2,2),'ember':(2,1)}[m]
            chk(f'{m}: 12+ pads off the roads, inside the safe box, clear of water/lava/vents/castle, spaced; {want[0]} road(s), {want[1]} cave(s); full 1600x900 bake; gate at the road end',r,
                r[0]>=12 and r[1]>=78 and r[2]>=138 and r[3] and not r[4] and not r[5] and not r[6] and r[7]==want[0] and r[8]==want[1] and r[9]=='1600x900' and abs(int(r[10].split(',')[0])-1450)<=6 and abs(int(r[10].split(',')[1])-628)<=6 and r[11])
        r=await E("()=>{const G=rpGeo(RP_MAP('moss'));let n=0;for(const q of G.U)if(G.dRiver(q.x,q.y)<40)n++;const F=rpGeo(RP_MAP('frost'));let ice=0;for(const P of F.paths)for(const v of P.ice)ice+=v;return [n>0,ice>0,RP_MAP('ember').vents.length,typeof rpCastleArt,typeof rpWorldArt]}")
        chk('Mossgate road crosses the river (bridge), Frostfang has ice on the road, Ember Crown has 3 vents; castle and world art present',r,r==[True,True,True,3,'function','function'] or (r[0] and r[1] and r[2]==3 and r[3]=='function' and r[4]=='function'))
        # no typing; keys
        r=await E("()=>{rpStart('moss');const R=RPX;R.tut=null;R.hold=false;const s0=R.supply;for(const k of 'asdfghjklzxcvbnm')window.dispatchEvent(new KeyboardEvent('keydown',{key:k}));const a=[R.supply===s0,R.word===undefined,R.cmd===undefined];window.dispatchEvent(new KeyboardEvent('keydown',{key:'q'}));const b=R.place;window.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape'}));return [...a,b,R.place]}")
        chk('letters do nothing (no typing, no Command); Q picks the Rune Ballista, Esc cancels',r,r==[True,True,True,'ballista',None])
        # building
        r=await E("()=>{const R=RPX;const s0=R.supply,p=R.pads[0];const ok=rpBuild(p,'ballista');const s1=R.supply;const b0=p.tw.build;R.supply+=400;const up=rpUpgrade(p.tw);const s2=R.supply;const spent=p.tw.spent;const anim=[p.tw.upK,p.tw.from];rpSell(p.tw);return [ok,s0-s1,b0,s1+400-s2,R.supply-s2,Math.round(spent*.7),!p.tw,anim[0],anim[1]]}")
        chk('build costs 100 and starts its build animation; upgrade 150 plays the upgrade animation; selling refunds 70%',r,r[0] and r[1]==100 and r[2]==0 and r[3]==150 and r[4]==r[5] and r[6] and r[7]==0 and r[8]==1)
        r=await E("()=>{const R=RPX;R.supply=50;const ok=rpBuild(R.pads[1],'frost');return [ok,R.supply,!!R.pads[1].tw]}")
        chk('cannot build without supply',r,r==[False,50,False])
        r=await E("()=>{const R=RPX;R.supply=1000;const p=R.pads[2];rpBuild(p,'ballista');const tw=p.tw;let fired=false;const e=rpSpawn('scamp');const q=rpAt(R.G,0);e.s=40;R.wst='run';R.wave=1;tw.cd=0;for(let i=0;i<20;i++){rpStep(R,1/60);if(tw.fire>0)fired=true}const b1=tw.build;for(let i=0;i<70;i++)rpUpdate(1/60);return [fired,b1<1,tw.build]}")
        chk('a tower under construction does not fire; the build finishes in about a second',r,r==[False,True,1])
        await E("()=>{rpLeave();rpStart('moss');RPX.tut=null}")
        # placement and picking
        r=await E("()=>{const R=RPX;R.supply=1000;const p=R.pads[3];rpPlace('frost');const g=rpSnap(R,p.x+30,p.y-20);rpClick(p.x+30,p.y-20,0);const built=!!p.tw&&p.tw.type==='frost';const after=R.place;rpPlace('bell');const far=rpSnap(R,5,5);rpClick(5,5,0);return [g===p,built,after,far,R.place]}")
        chk('placing snaps to the nearest free pad, one click builds once and ends placing; a click away from pads cancels',r,r==[True,True,None,None,None])
        r=await E("()=>{const R=RPX;const p=R.pads[3];const a=rpPick(R,p.x,p.y-60)===p,bb=rpPick(R,p.x+200,p.y+200);const fr=R.pads.find(q=>!q.tw&&R.pads.every(o=>o===q||Math.hypot(o.x-q.x,o.y-q.y)>150));const c=rpPick(R,fr.x+5,fr.y+4)===fr,d=rpPick(R,fr.x,fr.y-70);return [a,bb===null||bb!==p,c,d]}")
        chk('the tower body picks its tower; an empty pad picks only on its stone top (no stray hits above it)',r,r[0] and r[1] and r[2] and r[3] is None)
        r=await E("async()=>{const R=RPX;const p=R.pads[3];p.tw.build=1;rpClick(p.x,p.y-50,0);await new Promise(r=>setTimeout(r,150));const el=$('rpinfo'),btn=$('rpup');p.tw.kills+=3;R.supply+=500;await new Promise(r=>setTimeout(r,200));return [R.sel===p.tw,!el.hidden,btn===$('rpup'),/3 defeated/.test(el.textContent),$('rpup').classList.contains('no')]}")
        chk('clicking a tower opens its panel; kills and supply patch it in place (no re-render under the pointer)',r,r==[True,True,True,True,False])
        r=await E("async()=>{const R=RPX;R.sel=null;const p=R.pads.find(q=>!q.tw);rpClick(p.x,p.y,0);await new Promise(r=>setTimeout(r,150));const n=document.querySelectorAll('#rpring .rprb').length;document.querySelector('#rpring .rprb[data-tw=\"brazier\"]').click();await new Promise(r=>setTimeout(r,100));return [n,p.tw&&p.tw.type,R.selPad,$('rpring').hidden]}")
        chk('clicking an empty pad opens the build ring; a ring button builds there',r,r==[4,'brazier',None,True])
        # abilities on cooldowns
        r=await E("()=>{const R=RPX;R.wave=1;R.cd=1e9;R.q=[];const a=rpAbility('repair',true);R.hp=12;const b=rpAbility('repair',true);const h1=R.hp,cd=R.abCd.repair;const c=rpAbility('repair',true);R.hp=10;for(let i=0;i<60*71;i++)rpStep(R,1/60);const d=rpAbility('repair',true);return [a,b,h1,cd,c,d,R.hp]}")
        chk('Repair: refused at full health, heals 4, recharges in 70 s',r,r==[False,True,16,70,False,True,14])
        r=await E("()=>{const R=RPX;const tw=R.pads[3].tw;R.sel=tw;const a=rpAbPress('over');const o=tw.over,cd=R.abCd.over;const b=rpAbility('over',tw);R.sel=null;return [a,o,cd,b]}")
        chk('Overcharge powers the selected tower for 10 s, then recharges (45 s)',r,r==[True,10,45,False])
        r=await E("()=>{const R=RPX;R.abCd.over=0;R.sel=null;const a=rpAbPress('over');const aim=R.aim;const p=R.pads[3];rpClick(p.x,p.y-50,0);return [a,aim,R.aim,p.tw.over>0]}")
        chk('without a selection Overcharge asks for a tower, a click on one applies it',r,r==[False,'over',None,True])
        r=await E("()=>{const R=RPX;const a=rpAbPress('slow');const aim=R.aim;rpClick(5,5,0);const n0=R.fields.length;const q=R.G.S[200];rpClick(q.x,q.y,0);return [a,aim,n0,R.fields.length,R.abCd.slow]}")
        chk('Slow Field: aim, refuses off the road, placed on the road, 40 s recharge',r,r==[False,'slow',0,1,40])
        # waves, paths, twists
        await E("()=>{rpLeave();const T=RPP().tut;for(const k of['build','wave','coins','upgrade','abil','twist_frost','twist_ember'])T[k]=1;rpStart('frost');RPX.tut=null}")
        r=await E("()=>{const R=RPX;R.pads.forEach(p=>{});rpWaveStart();const seen={};let ice=0,fast=0;for(let i=0;i<60*14;i++){rpUpdate(1/60);for(const e of R.foes){seen[e.pi]=1;if(e.ice)ice++}}return [R.wave,R.wst,Object.keys(seen).sort().join(''),ice>0]}")
        chk('Frostfang: monsters come from both caves and hit the icy patches',r,r[0]==1 and r[2]=='01' and r[3])
        r=await E("()=>{const R=RPX;const e=rpSpawn('scamp',0);const i=R.G.paths[0].ice.findIndex(v=>v);e.s=i*4;e.slowT=0;const s0=e.s;R.fields=[];rpStep(R,.1);const on=e.s-s0;const f=rpSpawn('scamp',0);f.sp=e.sp;f.s=20;rpStep(R,.1);const off=f.s-20;return [on>off*1.3]}")
        chk('ice makes monsters faster',r,r==[True])
        await E("()=>{rpLeave();rpStart('ember');RPX.tut=null}")
        r=await E("()=>{const R=RPX;rpWaveStart();const v=R.vents[0];const p=rpAt(R.G,0,0);const e=rpSpawn('golem',0);let best=0,bd=1e9;for(let s=0;s<R.G.paths[0].len;s+=4){const q=rpAt(R.G,s,0);const d=Math.hypot(q.x-v.x,q.y-v.y);if(d<bd){bd=d;best=s}}e.s=best;e.sp=0;e.off=0;const h0=e.hp;v.t=0;for(let i=0;i<60;i++)rpStep(R,1/60);return [Math.round(bd),h0-e.hp>0,e.pi]}")
        chk('Ember Crown: a lava vent erupts and scorches a monster on the road beside it',r,r[1])
        r=await E("()=>{const R=RPX;const seen={};for(let i=0;i<60*8;i++){rpUpdate(1/60);for(const e of R.foes)seen[e.pi]=1}return Object.keys(seen).sort().join('')}")
        chk('Ember Crown: monsters split between both forks',r,r=='01')
        # health, coins, defeat
        await E("()=>{rpLeave();delete P.rp;const T=RPP().tut;for(const k of['build','wave','coins','upgrade','abil','twist_frost','twist_ember'])T[k]=1;rpStart('moss');RPX.tut=null}")
        r=await E("()=>{const R=RPX;rpWaveStart();const c0=R.coins,s0=R.supply;const e=R.foes[0]||rpSpawn('scamp');e.s=10;rpHurt(e,9999,99,null);return [R.coins-c0,R.supply-s0>0,R.kills]}")
        chk('a kill pays supply and coins',r,r[0]==2 and r[1] and r[2]==1)
        r=await E("()=>{const R=RPX;R.q=[];for(const e of R.foes)e.dead=1;R.foes=[];const c0=R.coins;rpStep(R,1/60);return [R.wst,R.coins-c0,rpWaveCoins(R.map,1)]}")
        chk('clearing a wave pays wave coins',r,r[0]=='build' and r[1]==r[2] and r[1]>0)
        r=await E("()=>{const R=RPX;rpWaveStart();R.pads.forEach(p=>{if(p.tw)p.tw.cd=99});const h0=R.hp;for(let i=0;i<60*40;i++)rpUpdate(1/60);return [h0-R.hp,R.leaked]}")
        chk('monsters that reach the castle cost health',r,r[0]>0 and r[1]>0)
        r=await E("()=>{const R=RPX;R.hp=1;const e=rpSpawn('golem');e.s=R.G.len-1;for(let i=0;i<60*2;i++)rpUpdate(1/60);return [R.hp,R.wst]}")
        chk('the castle falls at 0 health and the run ends',r,r==[0,'done'])
        await pg.wait_for_timeout(2800)
        r=await E("()=>{const r=RPX&&RPX.result;return r?[r.won,r.stars,r.total===r.run,r.run>0,!!document.querySelector('.rpres')]:null}")
        chk('a loss pays the coins earned so far, no stars, shows the result',r,r==[False,0,True,True,True])
        r=await E("()=>{rpLeave();title();return [S.rp,RPX===null,S.mode,$('rphud')?$('rphud').hidden:true]}")
        chk('leaving clears the run and the HUD',r,r==[0,True,'title',True])
        # rewards
        r=await E("()=>{const g0=P.gold;rpStart('moss');const R=RPX;R.coins=100;R.wave=10;R.hp=19;rpVictory();rpFinish(true);const r=R.result;return [r.won,r.stars,r.first,r.win===Math.round(rpWinCoins(R.map,3)*1.5),P.gold-g0===r.total,r.total===100+r.win,RPP().stars.moss,RP_MAPOPEN(RP_MAPS[1])]}")
        chk('victory at 19 health: 3 stars, run coins + victory bonus x1.5 first win today, opens map 2',r,r==[True,3,True,True,True,True,3,True])
        r=await E("()=>{rpLeave();rpStart('moss');const R=RPX;R.wave=10;R.hp=9;rpVictory();rpFinish(true);return [R.result.stars,R.result.first,RPP().stars.moss,R.result.win===rpWinCoins(R.map,1)]}")
        chk('a second win the same day: 1 star does not lower the best, no daily bonus',r,r==[1,False,3,True])
        r=await E("()=>{const r=RPP();r.stars={moss:3,frost:3,ember:3};const u=rpUnlockSweep();return [u.map(s=>s.k),rpStarN()>=RP_TITLE_NEED]}")
        r2=await E("()=>RP_SKINS.every(s=>RPP().own[s.tw+':'+s.k])")
        chk('stars unlock the four tower skins (only here) and reach the title',[r,r2],r2 and 'thunderking' in r[0] and r[1])
        r=await E("()=>{const r=RPP();r.skin.ballista='gilded';save();const a=rpSkinOf('ballista');r.own['ballista:gilded']=0;const b=rpSkinOf('ballista');r.own['ballista:gilded']=1;return [a,b]}")
        chk('equipped skin needs ownership',r,r==['gilded','base'])
        r=await E("()=>{rpLeave();rpStart('moss');const R=RPX;R.tut=null;R.wave=10;R.hp=20;rpVictory();rpFreeplay();R.supply=99999;R.spd=3;for(const p of R.pads)if(!p.tw)rpBuild(p,'ballista');for(const p of R.pads){p.tw.build=1;rpUpgrade(p.tw);rpUpgrade(p.tw)}const c0=R.coins;for(let i=0;i<30*60*8;i++){if(R.wst==='build')rpWaveStart();rpUpdate(1/30);if(R.fpWaves>=3)break}const c1=R.coins;R.hp=0;rpDefeat();rpFinish(true);return [R.free,R.fpWaves>=3,c1-c0>100,R.result.won,R.result.run===Math.floor(c1),R.result.stars]}")
        chk('freeplay after a win keeps paying coins per kill and wave with no cap, keeps the win and its stars',r,r[0] and r[1] and r[2] and r[3] and r[4] and r[5]==3)
        # tutorials
        r=await E("async()=>{rpLeave();RPP().tut={};rpStart('moss');await new Promise(r=>setTimeout(r,1000));const R=RPX;const a=R.tut,v=!$('rptut').hidden;R.supply=500;rpBuild(R.pads[0],'ballista');await new Promise(r=>setTimeout(r,120));const b=RPP().tut.build;await new Promise(r=>setTimeout(r,1100));const c=R.tut;rpWaveStart();await new Promise(r=>setTimeout(r,120));return [a,v,b,c,RPP().tut.wave]}")
        chk('first-time tutorials: build tip shows, closes when a tower is built, then the start-wave tip',r,r==['build',True,1,'wave',1])
        r=await E("async()=>{const R=RPX;R.pads[0].tw.build=1;const e=rpSpawn('scamp');e.s=20;rpHurt(e,9999,99,null);const a=R.tut,h=R.hold;const t0=R.time;rpUpdate(1/60);const frozen=R.time===t0;$('rptok').click();return [a,h,frozen,R.hold,RPP().tut.coins]}")
        chk('the coins tip pauses the battle until Got it',r,r==['coins',True,True,False,1])
        # pause
        r=await E("async()=>{rpLeave();rpStart('moss');const R=RPX;R.tut=null;rpPause(true);const a=R.pause,b=!!document.querySelector('.rppause');const t0=R.t;rpUpdate(1/60);const c=R.t===t0;rpPause(false);await new Promise(r=>setTimeout(r,100));return [a,b,c,R.pause,$('rphud').hidden]}")
        chk('pause stops time and shows the menu; resume restores the HUD',r,r==[True,True,True,False,False])
        r=await E("()=>{P.rp={stars:{moss:9},skin:'x',own:5,tut:3};const q=RPP();return [q.stars.moss===undefined,typeof q.skin,typeof q.own,typeof q.tut]}")
        chk('save normaliser drops bad values',r,r==[True,'object','object','object'])
        # balance: a bot with a mixed build that upgrades and uses abilities
        await E("()=>{rpLeave();delete P.rp;RPP()}")
        maps=['moss'] if QUICK else ['moss','frost','ember']
        for m in maps:
            r=await E(f"()=>rpBot('{m}',{{up:1}})")
            chk(f'bot (mixed build, upgrades, abilities) wins {m}',r,r['won'])
        r=await E("()=>rpBot('moss',{noAbil:1,order:['ballista']})")
        chk('even a bot that only builds ballistas and never uses abilities wins map 1 (easy start)',r,r['won'])
        if not QUICK:
            r=await E("()=>rpBot('ember',{noAbil:1,order:['ballista'],maxT:4})")
            chk('four ballistas and no abilities are not enough for map 3 (it still needs thought)',r,not r['won'])
        print('bad',bad);print(er[:6]);await b.close()
asyncio.run(main())
