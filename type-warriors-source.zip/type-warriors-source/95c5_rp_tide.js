/* ===== RUNESTONE TOWER DEFENSE 9.2: the Tidecaller Shrine, a seventh tower (95c5, art only; loads after 95c4) =====
   A sea-stone fountain shrine: a carved plinth with wave friezes, shells and coral; a basin of living water; a fluted stem with two
   fish spouts pouring arcs of water back into the basin; from tier 3 an upper basin and a serpent statue coiled round the stem; on top
   the Tide Orb, a floating sphere of swirling water with a pearl at its heart and droplets orbiting it. Tier 4 "Abyssal" (indigo stone,
   violet water, glowing runes, drifting jellies); tier 5 "Leviathan" (marble and gold, a gold serpent, a pearl-white rainbow orb and a
   ring of water round it).
   Baked once per tier: the body (pad, plinth, basin with its water), the stem (spouts, upper basin, statue), 16 orb frames (the swirl
   turns a full circle), 8 wave frames, the whirlpool spiral, the leviathan head and body segment. Live: ripples, spout drops, the orb,
   orbiting droplets, sparkles, the charge (water spirals up into the orb) and the release (flash and squash).
   No shadowBlur, no ctx.filter. Glows are the shared radial sprites stamped with 'lighter'.
   API (wrapping 95c..95c4; other towers pass straight through)
     RPTW.tide, RPSKIN.tide                 'Tidecaller Shrine' (only 'base')
     rpTowerDraw(g,'tide',tier,skin,t,o)      o = {charge 0..1, rel 0..1 (release flash), over, sel, ghost, ph}
     rpTowerBuild(g,'tide',tier,skin,k,t,o)   the shrine rises from a spring, the orb gathers from spray; upgrades and ascensions
     rpTowerTop, rpTowerWarm, rpTowerIcon
     rpTideOrb(tier)                        the orb centre relative to the pad {x,y}
     rpTideWave(g,x,y,dir,h,t,tier,k)        a curling wave (dir +-1 = travel direction on screen, h = height scale, k = alpha)
     rpTideFoam(g,pts,t,tier)               the foam trail behind a wave (ground layer)
     rpTideWhirl(g,x,y,r,t,tier,k)           a whirlpool (ground layer)
     rpTideJet(g,x0,y0,x1,y1,u,tier)         the water jet from the orb to the impact point (u = 0..1 progress)
     rpTideSplash(g,x,y,u,r,tier)            the splash rings where the jet lands
     rpTideLeviathan(g,x,y,u,dir,tier)       the tier-5 sea serpent bursting from the road (u = 0..1) */
RPTW.tide={n:'Tidecaller Shrine',role:'Waves and knockback',col:'#4ad8ff'};
RPSKIN.tide=['base'];
const rptT=t=>Math.max(1,Math.min(5,t|0||1)),RPTN=16,RPTWN=8;
/* layout per tier: b = lower basin {y, rx, depth}, st = stem top, u = upper basin (0 = none), o = orb {y, r}, statue, spouts */
const RPTL=[0,
 {pl:9,b:{y:-24,rx:30,d:13},st:-50,u:0,o:{y:-70,r:12},sp:0,ser:0},
 {pl:10,b:{y:-26,rx:32,d:14},st:-58,u:0,o:{y:-80,r:13},sp:1,ser:0},
 {pl:11,b:{y:-27,rx:34,d:15},st:-58,u:{y:-60,rx:19,d:8},o:{y:-96,r:15},sp:1,ser:1},
 {pl:11,b:{y:-27,rx:35,d:15},st:-60,u:{y:-62,rx:20,d:8},o:{y:-102,r:16},sp:1,ser:1,rune:1},
 {pl:12,b:{y:-28,rx:36,d:16},st:-62,u:{y:-64,rx:21,d:8},o:{y:-106,r:17},sp:1,ser:1,halo:1}];
for(let i=1;i<6;i++){const L=RPTL[i];L.top=Math.round(-(L.o.y-L.o.r)+6)}
const RPTP={
 base:{st:{l:'#8adccf',m:'#4fa9a1',d:'#2c7275',k:'#173c46',top:'#a6ebdf',topD:'#62b8ae'},tr:'#ffd45a',trL:'#fff0a8',trD:'#b07a1a',
  w:['#bff6ff','#5ad6ff','#1f8fd8','#0c4a8a'],foam:'#f2feff',glow:'#4ad8ff',glow2:'#bff6ff',coral:'#ff7a8a',coralD:'#b03a5a',shell:'#ffe8d0',shellD:'#c89a7a',ser:['#6ad8b8','#2f9a8a','#155a5a'],rune:'#9ff6ff',pearl:'#fffaf0'},
 myth:{st:{l:'#a898e2',m:'#6e5cbc',d:'#463690',k:'#1e1450',top:'#c0b2f0',topD:'#8a78cc'},tr:'#ffd45a',trL:'#fff0a8',trD:'#b07a1a',
  w:['#ece0ff','#a888ff','#6a40e0','#2a1280'],foam:'#f6efff',glow:'#a070ff',glow2:'#e0ccff',coral:'#ff8ad8',coralD:'#a03a8a',shell:'#f0e0ff',shellD:'#a88ad0',ser:['#b89aff','#6e4ad0','#3a1a7a'],rune:'#e0c4ff',pearl:'#fff4ff'},
 cel:{st:RPSTONE.marble,tr:'#ffd45a',trL:'#fff6c8',trD:'#c08a24',
  w:['#ffffff','#a8f0ff','#4ab8f0','#1a6ab0'],foam:'#ffffff',glow:'#8ae8ff',glow2:'#fff6d8',coral:'#ffb0c0',coralD:'#c06a7a',shell:'#fffaf0',shellD:'#d8c49a',ser:['#ffe8a0','#e8b23a','#9a6a10'],rune:'#fff2b0',pearl:'#ffffff'}};
const rptP=t=>t>=5?RPTP.cel:t===4?RPTP.myth:RPTP.base;
const rptK=t=>t>=5?'c':t===4?'m':'b';

/* ---------- small painters ---------- */
function rptShell(g,x,y,s,P,a){g.save();g.translate(x,y);g.rotate(a||0);g.scale(s,s);g.beginPath();g.moveTo(0,4);g.lineTo(-6,-2);g.quadraticCurveTo(0,-8,6,-2);g.closePath();g.fillStyle=P.shell;g.fill();g.lineWidth=1.4;g.strokeStyle=RPTO;g.stroke();
 g.strokeStyle=P.shellD;g.lineWidth=.9;for(const k of[-3,0,3]){g.beginPath();g.moveTo(0,3);g.lineTo(k,-4.5);g.stroke()}g.restore()}
function rptStar(g,x,y,s,col){g.save();g.translate(x,y);g.scale(s,s);g.beginPath();for(let i=0;i<10;i++){const a=i/10*TAU-Math.PI/2,r=i%2?2.4:6;g.lineTo(Math.cos(a)*r,Math.sin(a)*r)}g.closePath();g.fillStyle=col;g.fill();g.lineWidth=1.3;g.strokeStyle=RPTO;g.stroke();g.restore()}
function rptCoral(g,x,y,s,P){g.save();g.translate(x,y);g.scale(s,s);g.lineCap='round';const br=(w,c)=>{g.strokeStyle=c;g.lineWidth=w;g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(-1,-6,-5,-11);g.moveTo(0,-3);g.quadraticCurveTo(3,-8,6,-13);g.moveTo(-1,-6);g.lineTo(1,-14);g.stroke()};
 br(5.2,RPTO);br(3,P.coral);g.strokeStyle='rgba(255,255,255,.5)';g.lineWidth=1;g.beginPath();g.moveTo(-.6,-1);g.quadraticCurveTo(-1.4,-6,-4.6,-10);g.stroke();g.restore()}
/* the wave frieze round the plinth: a band of scallops */
function rptFrieze(g,y,rx,h,P){g.save();rpSide(g,0,y,rx,rx,h);g.clip();g.strokeStyle=P.w[1];g.lineWidth=2.2;for(let i=-6;i<=6;i++){const a=i*.28,x=Math.sin(a)*rx,yy=y-h/2+Math.cos(a)*rx*RPSQ;g.beginPath();g.arc(x,yy,4.2,Math.PI*1.05,Math.PI*2.05);g.stroke()}
 g.strokeStyle='rgba(255,255,255,.55)';g.lineWidth=1;for(let i=-6;i<=6;i++){const a=i*.28,x=Math.sin(a)*rx,yy=y-h/2+Math.cos(a)*rx*RPSQ;g.beginPath();g.arc(x-1,yy-1,2.4,Math.PI*1.1,Math.PI*1.7);g.stroke()}g.restore()}

/* ---------- the body: pad, plinth, the basin and its water ---------- */
function rptBodyArt(g,tier){const L=RPTL[tier],P=rptP(tier),S=P.st,b=L.b;RPPADT=tier;try{rpPadArt(g)}finally{RPPADT=0}
 /* plinth: a low drum with a gold band and the wave frieze */
 rpTube(g,0,10,40,38,L.pl,S.l,S.m,S.d);rpCap(g,0,10-L.pl,38,S.top,S.topD);
 rpTube(g,0,10-L.pl,30,b.rx-2,(10-L.pl)-(b.y+b.d*.15),S.l,S.m,S.d);
 rptFrieze(g,10-L.pl-1,30,7,P);
 /* the basin: a wide bowl (outside), its rim and the water inside */
 const by=b.y,rx=b.rx,ry=rx*RPSQ;
 g.beginPath();g.ellipse(0,by,rx,ry,0,0,Math.PI);g.quadraticCurveTo(-rx*.7,by+b.d*1.6,0,by+b.d*1.25);g.closePath();
 g.beginPath();g.moveTo(-rx,by);g.bezierCurveTo(-rx,by+b.d*1.2,-rx*.45,by+b.d*1.6,0,by+b.d*1.6);g.bezierCurveTo(rx*.45,by+b.d*1.6,rx,by+b.d*1.2,rx,by);g.ellipse(0,by,rx,ry,0,0,Math.PI);g.closePath();
 g.fillStyle=rpHG(g,-rx,rx,S.l,S.m,S.d);g.fill();rpOut(g,2.6);
 /* basin carving: a gold band and a row of scallop shells */
 g.save();g.beginPath();g.moveTo(-rx,by);g.bezierCurveTo(-rx,by+b.d*1.2,-rx*.45,by+b.d*1.6,0,by+b.d*1.6);g.bezierCurveTo(rx*.45,by+b.d*1.6,rx,by+b.d*1.2,rx,by);g.ellipse(0,by,rx,ry,0,0,Math.PI);g.closePath();g.clip();
 g.strokeStyle=P.tr;g.lineWidth=3;g.beginPath();g.ellipse(0,by+b.d*.55,rx*.96,ry*.96,0,0,Math.PI);g.stroke();g.strokeStyle=P.trD;g.lineWidth=1;g.beginPath();g.ellipse(0,by+b.d*.55+1.6,rx*.96,ry*.96,0,0,Math.PI);g.stroke();g.restore();
 for(let i=-2;i<=2;i++){const a=i*.42,x=Math.sin(a)*rx*.86,y=by+b.d*.95+Math.cos(a)*ry*.7;rptShell(g,x,y,.8,P,a*.4)}
 /* the rim (back half), the water, the rim (front half) */
 g.beginPath();g.ellipse(0,by,rx+3,ry+2,0,0,TAU);g.fillStyle=S.top;g.fill();rpOut(g,2.4);
 const wq=g.createRadialGradient(-rx*.25,by-ry*.3,2,0,by,rx);wq.addColorStop(0,P.w[1]);wq.addColorStop(.7,P.w[2]);wq.addColorStop(1,P.w[3]);
 g.beginPath();g.ellipse(0,by+.6,rx-3,ry-2.2,0,0,TAU);g.fillStyle=wq;g.fill();g.lineWidth=1.4;g.strokeStyle=rpA(P.w[3],.8);g.stroke();
 g.fillStyle='rgba(255,255,255,.35)';g.beginPath();g.ellipse(-rx*.35,by-ry*.25,rx*.3,ry*.18,-.2,0,TAU);g.fill();
 g.beginPath();g.ellipse(0,by,rx+3,ry+2,0,0,Math.PI);g.lineWidth=3.4;g.strokeStyle=S.topD;g.stroke();g.lineWidth=1.2;g.strokeStyle='rgba(255,255,255,.6)';g.beginPath();g.ellipse(0,by-.8,rx+1.6,ry+.8,0,Math.PI*1.08,Math.PI*1.92);g.stroke();
 /* gold studs on the rim */
 for(let i=0;i<8;i++){const a=i/8*TAU+.2,x=Math.cos(a)*(rx+1.5),y=by+Math.sin(a)*(ry+1);if(Math.sin(a)<-.2)continue;g.beginPath();g.arc(x,y,1.7,0,TAU);g.fillStyle=P.tr;g.fill();g.lineWidth=.8;g.strokeStyle=RPTO;g.stroke()}
 /* coral, a starfish and shells round the plinth */
 rptCoral(g,-32,12,.9,P);rptCoral(g,34,10,.75,P);rptStar(g,22,16,.85,P.coral);rptShell(g,-16,18,.9,P,-.3);
 if(L.rune){g.strokeStyle=P.rune;g.lineWidth=1.6;for(let i=0;i<3;i++){const x=(i-1)*14,y=10-L.pl+4;g.beginPath();g.moveTo(x-3,y-3);g.lineTo(x,y+3);g.lineTo(x+3,y-3);g.stroke()}}
 g.save();g.translate(0,RPPIPY);rpPipArt(g,tier);g.restore()}
const rptBodyS=tier=>{const L=RPTL[tier];return rpSpr('td|b|'+tier,-66,L.b.y-30,132,96-L.b.y,g=>rptBodyArt(g,tier))};

/* ---------- the stem: fluted column, fish spouts, upper basin, the serpent statue ---------- */
function rptFish(g,x,y,dir,P,S){g.save();g.translate(x,y);g.scale(dir,1);
 g.beginPath();g.moveTo(-6,-5);g.quadraticCurveTo(4,-9,10,-3);g.quadraticCurveTo(12,0,10,3);g.quadraticCurveTo(3,6,-6,4);g.lineTo(-11,8);g.lineTo(-10,0);g.lineTo(-11,-8);g.closePath();
 g.fillStyle=rpHG(g,-11,12,S.top,S.m,S.d);g.fill();rpOut(g,1.8);g.beginPath();g.arc(5,-2.6,1.5,0,TAU);g.fillStyle=RPTO;g.fill();
 g.beginPath();g.ellipse(11,1,2,2.6,0,0,TAU);g.fillStyle=P.w[3];g.fill();g.lineWidth=1;g.strokeStyle=RPTO;g.stroke();
 g.strokeStyle=P.tr;g.lineWidth=1.4;g.beginPath();g.moveTo(-1,-6);g.quadraticCurveTo(1,0,-1,5);g.stroke();g.restore()}
function rptSerpent(g,L,P,front){/* a statue coiled round the stem: back loops first, then the front loops and the head */
 const S=P.ser,y0=L.b.y-4,y1=(L.u?L.u.y:L.st)+4,n=2.2;
 g.lineCap='round';
 const seg=(a0,a1)=>{const pts=[];for(let k=0;k<=24;k++){const u=a0+(a1-a0)*k/24,y=y0+(y1-y0)*(u/n),x=Math.sin(u*TAU)*13;pts.push([x,y,Math.cos(u*TAU)])}return pts};
 for(let q=0;q<n*2;q++){const a0=q/2,a1=Math.min(n,(q+1)/2),pts=seg(a0,a1);const fr=pts[12][2]>0;if(fr!==!!front)continue;
  const path=()=>{g.beginPath();g.moveTo(pts[0][0],pts[0][1]);for(const p of pts)g.lineTo(p[0],p[1])};
  g.lineWidth=9;g.strokeStyle=RPTO;path();g.stroke();g.lineWidth=6;g.strokeStyle=fr?S[0]:S[1];path();g.stroke();
  if(fr){g.lineWidth=1.6;g.strokeStyle='rgba(255,255,255,.5)';g.beginPath();g.moveTo(pts[2][0],pts[2][1]-1.6);for(let k=3;k<22;k++)g.lineTo(pts[k][0],pts[k][1]-1.6);g.stroke();
   for(let k=3;k<22;k+=4){g.beginPath();g.arc(pts[k][0],pts[k][1]+1,1.3,0,TAU);g.fillStyle=S[2];g.fill()}}}
 if(front){/* the head rising at the top, looking out over the basin */
  const hx=10,hy=y1-8;g.save();g.translate(hx,hy);g.rotate(-.35);
  g.beginPath();g.moveTo(-5,4);g.quadraticCurveTo(-6,-6,2,-8);g.quadraticCurveTo(12,-8,16,-3);g.quadraticCurveTo(17,1,12,2);g.lineTo(2,4);g.closePath();g.fillStyle=rpHG(g,-6,17,S[0],S[1],S[2]);g.fill();rpOut(g,2);
  g.beginPath();g.moveTo(-2,-7);g.lineTo(-6,-14);g.lineTo(2,-8);g.closePath();g.fillStyle=P.tr;g.fill();rpOut(g,1.3);
  g.beginPath();g.moveTo(4,-8);g.lineTo(3,-15);g.lineTo(8,-8);g.closePath();g.fillStyle=P.tr;g.fill();rpOut(g,1.3);
  g.beginPath();g.ellipse(7,-4,2.2,1.6,0,0,TAU);g.fillStyle=P.tr;g.fill();g.lineWidth=.9;g.strokeStyle=RPTO;g.stroke();g.restore()}}
function rptStemArt(g,tier){const L=RPTL[tier],P=rptP(tier),S=P.st,b=L.b;
 if(L.ser)rptSerpent(g,L,P,0);
 /* fluted column from the water to the top (or to the upper basin) */
 const y0=b.y+2,y1=L.u?L.u.y+4:L.st,w0=9,w1=7;
 g.beginPath();g.moveTo(-w0,y0);g.lineTo(-w1,y1);g.lineTo(w1,y1);g.lineTo(w0,y0);g.closePath();g.fillStyle=rpHG(g,-w0,w0,S.l,S.m,S.d);g.fill();rpOut(g,2.2);
 g.strokeStyle=rpA(S.k,.5);g.lineWidth=1.2;for(const x of[-4,0,4]){g.beginPath();g.moveTo(x*1.1,y0-2);g.lineTo(x*.85,y1+2);g.stroke()}
 g.beginPath();g.ellipse(0,y0,w0+2,(w0+2)*RPSQ,0,0,TAU);g.fillStyle=P.tr;g.fill();rpOut(g,1.6);
 /* the ring band and the two fish spouts */
 const ym=(y0+y1)/2;g.beginPath();g.roundRect(-w0-1,ym-3,2*w0+2,6,2);g.fillStyle=rpHG(g,-w0,w0,P.trL,P.tr,P.trD);g.fill();rpOut(g,1.4);
 if(L.sp){rptFish(g,-12,ym-6,-1,P,S);rptFish(g,12,ym-6,1,P,S)}
 if(L.u){/* the upper basin, a smaller bowl with its own water */
  const u=L.u,rx=u.rx,ry=rx*RPSQ;g.beginPath();g.moveTo(-rx,u.y);g.bezierCurveTo(-rx,u.y+u.d,-rx*.4,u.y+u.d*1.5,0,u.y+u.d*1.5);g.bezierCurveTo(rx*.4,u.y+u.d*1.5,rx,u.y+u.d,rx,u.y);g.ellipse(0,u.y,rx,ry,0,0,Math.PI);g.closePath();
  g.fillStyle=rpHG(g,-rx,rx,S.l,S.m,S.d);g.fill();rpOut(g,2.2);g.strokeStyle=P.tr;g.lineWidth=2;g.beginPath();g.ellipse(0,u.y+u.d*.5,rx*.92,ry*.9,0,0,Math.PI);g.stroke();
  g.beginPath();g.ellipse(0,u.y,rx+2,ry+1.6,0,0,TAU);g.fillStyle=S.top;g.fill();rpOut(g,2);
  g.beginPath();g.ellipse(0,u.y+.5,rx-2.4,ry-1.8,0,0,TAU);g.fillStyle=P.w[1];g.fill();g.fillStyle='rgba(255,255,255,.4)';g.beginPath();g.ellipse(-rx*.3,u.y-ry*.2,rx*.28,ry*.18,0,0,TAU);g.fill();
  /* a slim upper stem and the cradle that holds the orb */
  g.beginPath();g.moveTo(-5,u.y);g.lineTo(-3.5,L.st-2);g.lineTo(3.5,L.st-2);g.lineTo(5,u.y);g.closePath();g.fillStyle=rpHG(g,-5,5,S.l,S.m,S.d);g.fill();rpOut(g,1.8)}
 /* the cradle: three gold prongs that hold the orb */
 const cy=L.st;for(const a of[-.9,0,.9]){g.beginPath();g.moveTo(Math.sin(a)*4,cy);g.quadraticCurveTo(Math.sin(a)*14,cy-6,Math.sin(a)*12,cy-14);g.lineWidth=4.2;g.strokeStyle=RPTO;g.stroke();g.lineWidth=2.4;g.strokeStyle=P.tr;g.stroke()}
 g.beginPath();g.ellipse(0,cy,7,3,0,0,TAU);g.fillStyle=P.tr;g.fill();rpOut(g,1.4);
 if(L.ser)rptSerpent(g,L,P,1)}
const rptStemS=tier=>{const L=RPTL[tier];return rpSpr('td|s|'+tier,-50,L.st-30,100,(L.b.y+10)-(L.st-30),g=>rptStemArt(g,tier))};

/* ---------- the Tide Orb: 16 frames of swirling water ---------- */
function rptOrbArt(g,r,f,P,tier){const a0=f/RPTN*TAU;
 const q=g.createRadialGradient(-r*.35,-r*.4,r*.1,0,0,r);q.addColorStop(0,P.w[0]);q.addColorStop(.45,P.w[1]);q.addColorStop(1,P.w[2]);
 g.beginPath();g.arc(0,0,r,0,TAU);g.fillStyle=q;g.fill();
 g.save();g.beginPath();g.arc(0,0,r-1,0,TAU);g.clip();
 /* currents: three spiral bands turning */
 for(let k=0;k<3;k++){const a=a0+k*TAU/3;g.beginPath();for(let s=0;s<=20;s++){const u=s/20,ang=a+u*3.2,rr=r*(.15+.85*u);g.lineTo(Math.cos(ang)*rr,Math.sin(ang)*rr*.7)}
  g.lineWidth=r*.16;g.strokeStyle=rpA(P.w[0],.55);g.stroke();g.lineWidth=r*.06;g.strokeStyle='rgba(255,255,255,.75)';g.stroke()}
 if(tier>=5){for(let k=0;k<5;k++){const a=a0*.5+k*TAU/5;g.fillStyle=rpA(['#ff9ad8','#ffd45a','#8affb4','#7ad8ff','#c8a0ff'][k],.35);g.beginPath();g.ellipse(Math.cos(a)*r*.5,Math.sin(a)*r*.35,r*.42,r*.16,a,0,TAU);g.fill()}}
 g.fillStyle=rpA(P.w[3],.35);g.beginPath();g.ellipse(r*.25,r*.45,r*.85,r*.4,0,0,TAU);g.fill();g.restore();
 g.beginPath();g.arc(0,0,r,0,TAU);rpOut(g,2.4);
 g.fillStyle='rgba(255,255,255,.85)';g.beginPath();g.ellipse(-r*.38,-r*.45,r*.3,r*.16,-.6,0,TAU);g.fill();g.beginPath();g.arc(r*.35,-r*.55,r*.08,0,TAU);g.fill()}
const rptOrbS=(tier,f)=>{const r=RPTL[tier].o.r;return rpSpr('td|o|'+tier+'|'+f,-r-3,-r-3,2*r+6,2*r+6,g=>rptOrbArt(g,r,f,rptP(tier),tier))};
function rptHaloArt(g,P){g.lineWidth=3;g.strokeStyle=rpA(P.w[1],.9);g.beginPath();g.ellipse(0,0,30,10,0,0,TAU);g.stroke();g.lineWidth=1.2;g.strokeStyle='#ffffff';g.stroke();
 for(let i=0;i<12;i++){const a=i/12*TAU;g.beginPath();g.arc(Math.cos(a)*30,Math.sin(a)*10,1.8,0,TAU);g.fillStyle='#ffffff';g.fill()}}
const rptHaloS=tier=>rpSpr('td|h|'+tier,-34,-14,68,28,g=>rptHaloArt(g,rptP(tier)));
function rptJellyArt(g,P){g.beginPath();g.moveTo(-7,0);g.quadraticCurveTo(-7,-9,0,-9);g.quadraticCurveTo(7,-9,7,0);g.closePath();g.fillStyle=rpA(P.glow2,.85);g.fill();g.lineWidth=1.4;g.strokeStyle=rpA(P.glow,1);g.stroke();
 g.strokeStyle=rpA(P.glow2,.8);g.lineWidth=1.2;for(const x of[-4,0,4]){g.beginPath();g.moveTo(x,0);g.quadraticCurveTo(x+2,5,x,10);g.stroke()}}
const rptJellyS=tier=>rpSpr('td|j|'+tier,-9,-11,18,23,g=>rptJellyArt(g,rptP(tier)));

/* ---------- drawing the shrine ---------- */
function rpTideOrb(tier){const L=RPTL[rptT(tier)];return{x:0,y:L.o.y}}
function rptDraw(g,tier,t,o){const L=RPTL[tier],P=rptP(tier),ph=o.ph||0,ch=o.charge||0,rel=o.rel||0,ga=o.ghost?.5:1,lt=RPFX.lite;
 g.save();RPGA=ga;g.globalAlpha=ga;g.lineJoin='round';g.lineCap='round';
 if(o.sel){g.globalCompositeOperation='lighter';g.lineWidth=7;g.strokeStyle='rgba(255,201,74,.25)';g.beginPath();g.ellipse(0,15,64,26,0,0,TAU);g.stroke();g.globalCompositeOperation='source-over'}
 rpPut(g,rptBodyS(tier));
 /* ripples on the basin: rings that spread from where the spouts fall */
 const b=L.b,rx=b.rx-5,ry=rx*RPSQ;g.globalCompositeOperation='lighter';
 for(let i=0;i<(lt?2:3);i++){const u=((t*.55+i/3+ph)%1),sx=i%2?-rx*.5:rx*.5,r2=3+u*rx*.5;g.globalAlpha=ga*(1-u)*.7;g.lineWidth=1.4;g.strokeStyle=P.w[0];g.beginPath();g.ellipse(sx*.9,b.y+1,r2,r2*RPSQ,0,0,TAU);g.stroke()}
 rpGlow(g,0,b.y,rx*1.1,ry*1.2,P.glow,(.25+.12*Math.sin(t*2+ph)+ch*.35)*ga);
 g.globalCompositeOperation='source-over';g.globalAlpha=ga;
 /* the charge: water spirals up from the basin into the orb */
 const oy=L.o.y-ch*6+Math.sin(t*1.6+ph)*2*(1-ch),or=L.o.r;
 if(ch>.02&&!lt){g.globalCompositeOperation='lighter';for(let i=0;i<10;i++){const u=((t*1.8+i/10)%1),ang=u*TAU*1.6+i,y=b.y+(oy-b.y)*u,rr=(rx*.9)*(1-u)+or*.6*u;rpGlow(g,Math.cos(ang)*rr,y+Math.sin(ang)*rr*RPSQ,3+2*(1-u),3+2*(1-u),P.w[0],ch*(1-u*.4))}g.globalCompositeOperation='source-over';g.globalAlpha=ga}
 rpPut(g,rptStemS(tier));
 /* spout arcs: drops leaving the fish mouths and falling into the basin */
 if(L.sp){const ym=((b.y+2)+(L.u?L.u.y+4:L.st))/2-6;g.globalCompositeOperation='lighter';
  for(const d of[-1,1])for(let i=0;i<(lt?3:5);i++){const u=((t*1.3+i/5+(d>0?.5:0)+ph)%1),x=d*(23+u*8),y=ym-1+u*u*(b.y-ym+2)-Math.sin(u*Math.PI)*5;rpGlow(g,x,y,2.6,3.2,P.w[0],.95);if(i===0&&!lt)rpGlow(g,x,y,5,5,P.glow,.4)}
  g.globalCompositeOperation='source-over';g.globalAlpha=ga}
 if(L.u&&!lt){g.globalCompositeOperation='lighter';const u=((t*.7+ph)%1),r2=2+u*L.u.rx*.6;g.globalAlpha=ga*(1-u)*.7;g.lineWidth=1.2;g.strokeStyle=P.w[0];g.beginPath();g.ellipse(0,L.u.y+.5,r2,r2*RPSQ,0,0,TAU);g.stroke();g.globalCompositeOperation='source-over';g.globalAlpha=ga}
 /* tier 4: jellies drift up round the shrine; tier 5: a ring of water round the orb */
 if(L.rune){for(let i=0;i<3;i++){const u=((t*.18+i/3+ph)%1),x=Math.sin(i*2.1+t*.7)*30,y=-10-u*90;g.globalAlpha=ga*Math.sin(Math.PI*u)*.9;rpPut(g,rptJellyS(tier),x,y)}g.globalAlpha=ga}
 if(L.halo){g.save();g.translate(0,oy+2);g.rotate(Math.sin(t*.8)*.08);const k=1+.06*Math.sin(t*2+ph);g.scale(k,k);g.globalCompositeOperation='lighter';g.globalAlpha=ga*.8;rpPut(g,rptHaloS(tier));g.restore();g.globalCompositeOperation='source-over';g.globalAlpha=ga}
 /* orbiting droplets behind the orb */
 const nd=tier>=3?4:3,drop=(front)=>{g.globalCompositeOperation='lighter';for(let i=0;i<nd;i++){const a=t*(1.4+ch*3)+i/nd*TAU+ph,sn=Math.sin(a);if(front?sn<0:sn>=0)continue;const R=or+8+ch*4,s=2.4+sn*.8;rpGlow(g,Math.cos(a)*R,oy+sn*R*.35,s+1.5,s+1.5,P.w[0],.9);rpGlow(g,Math.cos(a)*R,oy+sn*R*.35,s*2.6,s*2.6,P.glow,.3)}g.globalCompositeOperation='source-over';g.globalAlpha=ga};
 drop(0);
 /* the orb: swells as it charges, squashes on release */
 g.save();g.translate(0,oy);const sw=1+ch*.22-rel*.25*Math.sin(Math.min(1,rel)*Math.PI),sq=1+rel*.18*Math.sin(Math.min(1,rel)*Math.PI);g.scale(sw*sq,sw/sq);
 g.globalCompositeOperation='lighter';rpGlow(g,0,0,or*2.4,or*2.4,P.glow,(.35+.2*Math.sin(t*2.2+ph)+ch*.5+rel)*ga);g.globalCompositeOperation='source-over';g.globalAlpha=ga;
 const f=((t*(4+ch*10)+ph*7)|0)%RPTN;rpPut(g,rptOrbS(tier,(f+RPTN)%RPTN));
 g.globalCompositeOperation='lighter';rpGlow(g,0,0,or*.45,or*.45,P.pearl,.9);rpGlow(g,0,0,or*.9,or*.9,P.glow2,.35+ch*.5);if(rel>0)rpGlow(g,0,0,or*3,or*3,'#ffffff',rel*.8);g.globalCompositeOperation='source-over';g.globalAlpha=ga;
 g.restore();
 drop(1);
 /* glints on the water */
 if(!lt){g.globalCompositeOperation='lighter';for(let i=0;i<3;i++){const tw=Math.sin(t*3.1+i*2.3+ph*5);if(tw<.4)continue;const x=Math.cos(i*2.1+ph)*rx*.6,y=b.y+Math.sin(i*1.7)*ry*.4,r=2+tw*3;g.globalAlpha=ga*tw;g.fillStyle='#ffffff';g.fillRect(x-r,y-.6,r*2,1.2);g.fillRect(x-.6,y-r,1.2,r*2)}g.globalCompositeOperation='source-over';g.globalAlpha=ga}
 g.restore();RPGA=1;g.globalAlpha=1}

/* ---------- waves, foam, whirlpools, jets, splashes, the leviathan ---------- */
/* a curling wave, side view, travelling to +x; 8 frames make the crest boil */
function rptWaveArt(g,P,f){const ph=f/RPTWN*TAU,w=Math.sin(ph)*2.5;
 const body=()=>{g.beginPath();g.moveTo(-58,0);g.bezierCurveTo(-46,-6,-24,-30+w,-2,-56);g.bezierCurveTo(10,-70,34,-66,44,-50+w*.6);g.bezierCurveTo(48,-42,42,-34,34,-36);g.bezierCurveTo(26,-40,22,-30,26,-20);g.bezierCurveTo(30,-10,40,-4,52,0);g.closePath()};
 body();const q=g.createLinearGradient(-40,0,20,-66);q.addColorStop(0,rpA(P.w[3],.92));q.addColorStop(.45,rpA(P.w[2],.92));q.addColorStop(.85,rpA(P.w[1],.95));q.addColorStop(1,rpA(P.w[0],1));g.fillStyle=q;g.fill();
 g.save();body();g.clip();
 /* the tube under the curl, darker */
 g.fillStyle=rpA(P.w[3],.55);g.beginPath();g.ellipse(30,-26,10,14,-.3,0,TAU);g.fill();
 /* streaks along the face */
 g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=2;for(let k=0;k<4;k++){g.beginPath();g.moveTo(-44+k*10,-4-k*2);g.quadraticCurveTo(-24+k*8,-24-k*6+w,-4+k*6,-44-k*3);g.stroke()}
 g.restore();body();g.lineWidth=2.4;g.strokeStyle=RPTO;g.stroke();
 /* foam on the crest */
 g.fillStyle=P.foam;for(let k=0;k<9;k++){const u=k/8,x=-8+u*52+Math.sin(ph*2+k)*1.5,y=-56-Math.sin(u*Math.PI)*12+u*14+Math.cos(ph+k*1.7)*1.5,r=4.5+Math.sin(ph+k*2.3)*1.5;g.beginPath();g.arc(x,y,r,0,TAU);g.fill()}
 g.strokeStyle=RPTO;g.lineWidth=1.2;g.beginPath();for(let k=0;k<9;k++){const u=k/8,x=-8+u*52,y=-56-Math.sin(u*Math.PI)*12+u*14;g.moveTo(x+5,y);g.arc(x,y,5,0,Math.PI,true)}g.stroke();
 /* spray off the lip */
 g.fillStyle=rpA(P.foam,.9);for(let k=0;k<6;k++){const a=-1.2+k*.3+Math.sin(ph+k)*.1,d=10+((f*3+k*5)%9)*1.5;g.beginPath();g.arc(44+Math.cos(a)*d,-50+Math.sin(a)*d,1.6+(k%2),0,TAU);g.fill()}
 /* foam at the foot */
 g.fillStyle=rpA(P.foam,.85);for(let k=0;k<7;k++){g.beginPath();g.ellipse(-50+k*16+Math.sin(ph+k)*2,-1,7,3,0,0,TAU);g.fill()}}
const rptWaveS=(tier,f)=>rpSpr('td|w|'+rptK(tier)+'|'+f,-62,-82,126,88,g=>rptWaveArt(g,rptP(tier),f),1.5);
function rpTideWave(g,x,y,dir,h,t,tier,k){if(k<=.01)return;const f=((t*14)|0)%RPTWN,s=rptWaveS(tier,f);g.save();g.translate(x,y);g.scale(dir<0?-1:1,1);g.scale(.62+.38*h,.4+.6*h);g.globalAlpha=k;rpPut(g,s);g.restore();g.globalAlpha=1}
function rpTideFoam(g,pts,t,tier){const P=rptP(tier);g.save();for(const q of pts){const f=Math.max(0,1-q.t/1.1);if(f<=0)continue;const w=(26+q.w*14)*(.6+.4*f);g.globalAlpha=f*.5;g.drawImage(rpGlowC(P.w[1]),q.x-w,q.y-w*.45,w*2,w*.9);g.globalAlpha=f*.75;g.drawImage(rpGlowC(P.foam),q.x-w*.5,q.y-w*.22,w,w*.44)}g.restore();g.globalAlpha=1}
function rptSpiralArt(g,P){for(let k=0;k<4;k++){const a0=k*TAU/4;g.beginPath();for(let s=0;s<=40;s++){const u=s/40,ang=a0+u*5,r=4+u*52;g.lineTo(Math.cos(ang)*r,Math.sin(ang)*r)}g.lineWidth=7;g.strokeStyle=rpA(P.w[2],.75);g.stroke();g.lineWidth=2.6;g.strokeStyle=rpA(P.w[0],.9);g.stroke()}
 const q=g.createRadialGradient(0,0,2,0,0,60);q.addColorStop(0,rpA(P.w[3],.9));q.addColorStop(.5,rpA(P.w[2],.4));q.addColorStop(1,rpA(P.w[1],0));g.fillStyle=q;g.beginPath();g.arc(0,0,60,0,TAU);g.fill()}
const rptSpiralS=tier=>rpSpr('td|sp|'+rptK(tier),-62,-62,124,124,g=>rptSpiralArt(g,rptP(tier)),1.5);
function rpTideWhirl(g,x,y,r,t,tier,k){if(k<=.01)return;const P=rptP(tier);g.save();g.translate(x,y);g.scale(1,RPFX.sq);g.rotate(-t*4.2);const s=r/56;g.scale(s,s);g.globalAlpha=k*.9;rpPut(g,rptSpiralS(tier));g.restore();
 g.save();g.globalCompositeOperation='lighter';g.globalAlpha=k*.6;g.lineWidth=2;g.strokeStyle=P.w[0];g.beginPath();g.ellipse(x,y,r,r*RPFX.sq,0,0,TAU);g.stroke();g.restore();g.globalAlpha=1}
function rpTideJet(g,x0,y0,x1,y1,u,tier){if(u<=0||u>=1)return;const P=rptP(tier),cx=(x0+x1)/2,cy=Math.min(y0,y1)-60-Math.hypot(x1-x0,y1-y0)*.15,at=v=>{const a=1-v;return[a*a*x0+2*a*v*cx+v*v*x1,a*a*y0+2*a*v*cy+v*v*y1]};
 const h=Math.min(1,u*2.2),tl=Math.max(0,u*2.2-1.2);g.save();g.lineCap='round';
 const line=(w,c,al)=>{g.globalAlpha=al;g.lineWidth=w;g.strokeStyle=c;g.beginPath();for(let i=0;i<=12;i++){const v=tl+(h-tl)*i/12,[x,y]=at(v);i?g.lineTo(x,y):g.moveTo(x,y)}g.stroke()};
 line(11,P.w[2],.85);line(6,P.w[1],.95);line(2.4,'#ffffff',.9);
 g.globalCompositeOperation='lighter';const [hx,hy]=at(h);rpGlow(g,hx,hy,14,14,P.w[0],.9);for(let i=0;i<5;i++){const v=Math.max(0,h-i*.06),[x,y]=at(v);rpGlow(g,x+Math.sin(i*3)*6,y+Math.cos(i*2)*6,3,3,P.foam,.8)}g.restore();g.globalAlpha=1}
function rpTideSplash(g,x,y,u,r,tier){if(u<=0||u>=1)return;const P=rptP(tier),sq=RPFX.sq;g.save();
 for(let i=0;i<3;i++){const v=Math.max(0,u*1.3-i*.15);if(v<=0||v>=1)continue;const R=r*(.3+.7*rpEO(v));g.globalAlpha=(1-v)*.85;g.lineWidth=4*(1-v)+1.2;g.strokeStyle=i?P.w[1]:P.foam;g.beginPath();g.ellipse(x,y,R,R*sq,0,0,TAU);g.stroke()}
 /* a crown of water rising and falling */
 const c=Math.sin(Math.min(1,u*1.6)*Math.PI);if(c>0){g.globalAlpha=c*.9;for(let i=0;i<9;i++){const a=i/9*TAU,px=x+Math.cos(a)*r*.32,py=y+Math.sin(a)*r*.32*sq,hgt=(16+10*((i*7)%3))*c;g.lineWidth=4;g.strokeStyle=P.w[1];g.beginPath();g.moveTo(px,py);g.lineTo(px+Math.cos(a)*6,py-hgt);g.stroke();g.fillStyle=P.foam;g.beginPath();g.arc(px+Math.cos(a)*6,py-hgt,2.6,0,TAU);g.fill()}}
 g.restore();g.globalAlpha=1}
/* the leviathan: a sea serpent arcs out of the road and dives back */
function rptLevHeadArt(g,P){const S=P.ser;
 g.beginPath();g.moveTo(-10,8);g.quadraticCurveTo(-14,-10,4,-16);g.quadraticCurveTo(26,-18,36,-8);g.quadraticCurveTo(40,-2,34,2);g.lineTo(16,4);g.lineTo(30,10);g.quadraticCurveTo(20,16,4,12);g.closePath();
 g.fillStyle=rpHG(g,-12,40,S[0],S[1],S[2]);g.fill();rpOut(g,2.6);
 for(let x=14;x<=32;x+=5){g.beginPath();g.moveTo(x-1.6,2.4);g.lineTo(x,7);g.lineTo(x+1.6,2.4);g.closePath();g.fillStyle='#fffaf0';g.fill();g.lineWidth=1;g.strokeStyle=RPTO;g.stroke()}
 g.beginPath();g.moveTo(-4,-12);g.lineTo(-16,-28);g.lineTo(4,-15);g.closePath();g.fillStyle=P.tr;g.fill();rpOut(g,1.6);g.beginPath();g.moveTo(6,-16);g.lineTo(2,-30);g.lineTo(14,-16);g.closePath();g.fillStyle=P.tr;g.fill();rpOut(g,1.6);
 g.beginPath();g.ellipse(14,-8,4,3,-.2,0,TAU);g.fillStyle='#fff6a0';g.fill();g.lineWidth=1.2;g.strokeStyle=RPTO;g.stroke();g.beginPath();g.ellipse(15,-8,1.4,2.4,0,0,TAU);g.fillStyle=RPTO;g.fill();
 g.strokeStyle=rpA(S[2],.8);g.lineWidth=1.4;g.beginPath();g.moveTo(-6,0);g.quadraticCurveTo(0,-6,8,-6);g.stroke()}
const rptLevHeadS=tier=>rpSpr('td|lh|'+rptK(tier),-20,-34,64,54,g=>rptLevHeadArt(g,rptP(tier)));
function rptLevSegArt(g,P){const S=P.ser;g.beginPath();g.ellipse(0,0,12,10,0,0,TAU);g.fillStyle=rpHG(g,-12,12,S[0],S[1],S[2]);g.fill();rpOut(g,2.2);
 g.beginPath();g.moveTo(-4,-9);g.lineTo(0,-17);g.lineTo(4,-9);g.closePath();g.fillStyle=P.tr;g.fill();rpOut(g,1.3);g.fillStyle=rpA(S[2],.6);g.beginPath();g.ellipse(2,4,6,3,0,0,TAU);g.fill()}
const rptLevSegS=tier=>rpSpr('td|ls|'+rptK(tier),-15,-20,30,33,g=>rptLevSegArt(g,rptP(tier)));
function rpTideLeviathan(g,x,y,u,dir,tier){if(u<=0||u>=1)return;const P=rptP(tier),h=Math.sin(u*Math.PI),n=10;g.save();g.translate(x,y);g.scale(dir<0?-1:1,1);
 /* the body rises out of the water behind and arcs forward; the head leads, high, then everything dives */
 const sl=u*70-35,pts=[];for(let i=0;i<n;i++){const v=i/(n-1),px=-70+v*120+sl,py=-Math.sin(Math.PI*.62*v)*110*h;pts.push([px,py])}
 rpTideSplash(g,pts[0][0],0,Math.min(.99,(u*1.8)%1),50,tier);
 for(let i=0;i<n-1;i++){const [px,py]=pts[i];if(py>-3)continue;const k=1.15+.35*Math.sin(Math.PI*i/(n-1));g.save();g.translate(px,py);g.scale(k,k);rpPut(g,rptLevSegS(tier));g.restore()}
 const [hx,hy]=pts[n-1],[bx,by]=pts[n-2];if(hy<-3){g.save();g.translate(hx,hy);g.rotate(Math.atan2(hy-by,hx-bx)*.5+(u>.6?(u-.6)*1.6:0));g.scale(1.5,1.5);rpPut(g,rptLevHeadS(tier));g.restore()}
 g.globalCompositeOperation='lighter';for(let i=0;i<10;i++){const v=((u*2+i/10)%1);rpGlow(g,(i-5)*12+sl,-v*80*h,3,3,P.foam,(1-v)*h)}g.restore();g.globalAlpha=1}

/* ---------- build, upgrade and ascension ---------- */
function rptBuild(g,tier,k,t,o){const from=o.from>=1&&o.from<tier?o.from|0:0,L=RPTL[tier],P=rptP(tier),S=(a,b)=>rpSeg(k,a,b),ph=o.ph||0;
 g.save();RPGA=1;g.globalAlpha=1;g.lineJoin='round';g.lineCap='round';
 if(!from){/* a spring bursts from the pad, the shrine rises through it, the orb gathers from the spray */
  rpPut(g,rpPadS());const sp=S(0,.35)*(1-S(.7,.95));
  if(sp>0){g.globalCompositeOperation='lighter';rpGlow(g,0,-20,30*sp+10,60*sp+10,P.w[1],sp*.9);for(let i=0;i<10;i++){const u=((t*2+i/10)%1),a=i*2.4;rpGlow(g,Math.cos(a)*16*u,-u*90*sp,3,3,P.foam,(1-u)*sp)}g.globalCompositeOperation='source-over';g.globalAlpha=1}
  const r=S(.15,.6),e=rpEB(r);if(r>0){g.save();g.beginPath();g.rect(-80,-L.top-30,160,L.top+60);g.clip();g.translate(0,(1-Math.min(1,e))*(L.top*.8));g.scale(1,.75+.25*Math.min(1.15,e));
   rpPut(g,rptBodyS(tier));rpPut(g,rptStemS(tier));g.restore();if(r<1)rpDust(g,0,10,r,1.2)}
  const ob=S(.55,.9);if(ob>0){const P2=P;g.globalCompositeOperation='lighter';for(let i=0;i<12;i++){const a=i/12*TAU+t,d=(1-ob)*60;rpGlow(g,Math.cos(a)*d,L.o.y+Math.sin(a)*d*.6,3,3,P2.w[0],ob)}g.globalCompositeOperation='source-over';
   g.save();g.translate(0,L.o.y);g.scale(rpEB(ob),rpEB(ob));rpPut(g,rptOrbS(tier,((t*6)|0)%RPTN));g.restore()}
  const fl=S(.88,1);if(fl>0&&fl<1){g.globalCompositeOperation='lighter';rpGlow(g,0,L.o.y,50*fl+10,50*fl+10,P.glow2,1-fl);g.globalCompositeOperation='source-over'}
  if(k>.95){g.globalAlpha=(k-.95)/.05;rptDraw(g,tier,t,{ph})}}
 else{/* upgrade: the orb drinks the basin dry, flashes, and the shrine is reborn in a burst of spray; ascension adds a pillar of water */
  const asc=tier>=4,sw=S(.4,.52),cur=sw<1?from:tier,ch=S(0,.42)*(1-S(.5,.6));
  if(asc){const pl=S(.05,.45)*(1-S(.7,1));g.globalCompositeOperation='lighter';rpGlow(g,0,-110,40+30*pl,170,tier>=5?'#fff6d8':P.glow,pl*.85);g.globalCompositeOperation='source-over'}
  const sc=sw>0&&sw<1?1+.14*Math.sin(sw*Math.PI):1;g.save();g.scale(1/sc,sc);rptDraw(g,cur,t,{ph,charge:ch,rel:sw>0&&sw<1?Math.sin(sw*Math.PI):0});g.restore();
  const sp=S(.48,.9);if(sp>0&&sp<1){g.globalCompositeOperation='lighter';for(let i=0;i<14;i++){const a=i/14*TAU,d=20+sp*60;rpGlow(g,Math.cos(a)*d,RPTL[tier].o.y+30+Math.sin(a)*d*.5-sp*30,4,4,P.foam,(1-sp))}g.globalCompositeOperation='source-over'}}
 g.restore();RPGA=1;g.globalAlpha=1}

/* ---------- warm, icon and the wrappers ---------- */
function rptWarm(tier){rpPadS();rptBodyS(tier);rptStemS(tier);for(let f=0;f<RPTN;f++)rptOrbS(tier,f);for(let f=0;f<RPTWN;f++)rptWaveS(tier,f);rptSpiralS(tier);if(tier>=5){rptHaloS(tier);rptLevHeadS(tier);rptLevSegS(tier)}if(tier===4)rptJellyS(tier)}
{const f0=rpTowerDraw;rpTowerDraw=function(g,type,tier,skin,t,o){if(type!=='tide')return f0.apply(this,arguments);rptDraw(g,rptT(tier),t||0,o||{})}}
{const f0=rpTowerBuild;rpTowerBuild=function(g,type,tier,skin,k,t,o){if(type!=='tide')return f0.apply(this,arguments);o=o||{};t=t||0;tier=rptT(tier);if(!(k<1)){rptDraw(g,tier,t,o);return}rptBuild(g,tier,Math.max(0,k||0),t,o)}}
{const f0=rpTowerTop;rpTowerTop=function(type,tier){return type==='tide'?RPTL[rptT(tier)].top:f0.apply(this,arguments)}}
{const f0=rpTowerWarm;rpTowerWarm=function(type,tier,skin){if(type!=='tide')return f0.apply(this,arguments);rptWarm(rptT(tier))}}
{const f0=rpTowerIcon;rpTowerIcon=function(type,tier,skin,size){if(type!=='tide')return f0.apply(this,arguments);tier=rptT(tier);size=Math.max(16,size|0||96);const key='td|ic|'+tier+'|'+size;let s=RPSPR.get(key);if(s)return s.c;
 const c=document.createElement('canvas');c.width=c.height=size;const top=RPTL[tier].top+6,h=top+46,k=Math.min(size*.95/h,size*.95/134),g=c.getContext('2d');g.translate(size/2,size/2+(top-46)/2*k);g.scale(k,k);
 try{rptDraw(g,tier,.42,{ph:.3})}catch(e){console.error(e)}RPSPR.set(key,{c});return c}}
