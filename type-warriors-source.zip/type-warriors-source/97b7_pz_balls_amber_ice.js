/* ===== 10.6 THE CROOKED CUE: Harvest Amber and Glacier Crystal (97b7, prefix pzb7, after 97b6) =====
   Two premium ball sets (15,000 and 25,000 coins) made with 97b6's shared painter (pzb3Reg). Both look INTO the ball: the inclusions are
   sampled a little below the surface along the view ray (parallax), so they slide against the surface as the ball rolls.
   - Harvest Amber: warm resin tinted in each ball's colour all the way through, bright in the middle and deep toward the rim, with slow flow
     lines, tiny bubbles and dark-gold autumn leaves trapped in it. Stripes: pale cream-honey resin caps. The 8: smoked black amber with a
     warm edge glow and an ivory disc. Number discs: cream with deep brown numbers.
   - Glacier Crystal: tinted ice with a milky core, two layers of fracture planes (a near bright one and a deep blue one), frosted patches near
     the rim and cold star glints that flash as the ball turns. Stripes: opaque frosted white caps with tiny crystals. The 8: black ice with pale
     cracks, a frost-white disc and an icy ring. Number discs: frosty white with deep navy numbers.
   pzbPaint is wrapped once, only to hand the ball's orientation to the materials (the view and the half vector in ball-local space). */
const PZB7={vx:0,vy:0,vz:1,hx:0,hy:0,hz:1,Hw:null};
{const L=[-.42,-.58,.7],ll=Math.hypot(L[0],L[1],L[2]),H=[L[0]/ll,L[1]/ll,L[2]/ll+1],hl=Math.hypot(H[0],H[1],H[2]);PZB7.Hw=[H[0]/hl,H[1]/hl,H[2]/hl];
 const f0=pzbPaint;pzbPaint=function(slot,n,M){const P=PZ_BS,K=P&&P.pal&&P.pal.kind;
  if(K==='amber'||K==='glacier'){const H=PZB7.Hw;PZB7.vx=M[6];PZB7.vy=M[7];PZB7.vz=M[8];PZB7.hx=M[0]*H[0]+M[3]*H[1]+M[6]*H[2];PZB7.hy=M[1]*H[0]+M[4]*H[1]+M[7]*H[2];PZB7.hz=M[2]*H[0]+M[5]*H[1]+M[8]*H[2]}
  return f0.apply(this,arguments)}}
const pzb7Fr=x=>x-Math.floor(x);
/* trig-free waves for the glacier (period 1): pzb7U is the signed distance to the nearest whole number (-.5...5), pzb7T a triangle wave (-1..1) */
const pzb7U=x=>x-(((x+64.5)|0)-64),pzb7T=x=>{const u=pzb7U(x-.25);return 1-(u<0?-u:u)*4};

/* ---------------------------------------------------------------- Harvest Amber */
function pzb7Amber(o){const C=o.C,lx=o.lx,ly=o.ly,lz=o.lz,wx=o.wx,wy=o.wy,wz=o.wz,band=o.band,ab=o.ab,is8=o.is8,vx=PZB7.vx,vy=PZB7.vy,vz=PZB7.vz,k2=wz*wz;
 /* slow flow: warped ridges and a broad density that makes the resin thicker and thinner */
 const wp=pzb2Sin(ly*2.3+lz*1.7+1.1)*1.5,sA=pzb2Sin(lx*3.4+wp+ly*1.3),rd=1-(sA<0?-sA:sA),fl=rd*rd*rd,bl=.5+.5*pzb2Sin(lz*2.6+lx*1.9+pzb2Sin(ly*3.3)*1.2);
 let r=0,g=0,b=0,er=0,eg=0,eb=0;
 /* bubbles (sampled .3 under the surface) and leaves (.55 under it) */
 const bx=(lx-vx*.3)*5,by=(ly-vy*.3)*5,bz=(lz-vz*.3)*5,ix=Math.floor(bx),iy=Math.floor(by),iz=Math.floor(bz),hb=pzb2Hash(ix,iy,iz);let bub=0,rin=0;
 if(hb>.7){const cx=bx-ix-.25-.5*pzb7Fr(hb*7.31),cy=by-iy-.25-.5*pzb7Fr(hb*13.7),cz=bz-iz-.25-.5*pzb7Fr(hb*5.9),dd=cx*cx+cy*cy+cz*cz,r2=.03+.034*pzb7Fr(hb*3.7),dl=dd-r2;
  rin=Math.max(0,1-(dl<0?-dl:dl)/(r2*.7));bub=dd<r2?(1-dd/r2)*.3:0}
 const lx2=(lx-vx*.55)*2.1,ly2=(ly-vy*.55)*2.1,lz2=(lz-vz*.55)*2.1,jx=Math.floor(lx2),jy=Math.floor(ly2),jz=Math.floor(lz2),hl=pzb2Hash(jx+91,jy-37,jz+11);let lf=0,lr=0;
 if(hl>.7){const cx=lx2-jx-.35-.3*pzb7Fr(hl*7.31),cy=ly2-jy-.35-.3*pzb7Fr(hl*13.7),cz=lz2-jz-.35-.3*pzb7Fr(hl*5.9),ax=pzb7Fr(hl*5.3)-.5,ay=pzb7Fr(hl*8.1)-.5,az=pzb7Fr(hl*2.9)-.5,aa=ax*ax+ay*ay+az*az+.001,
   al=ax*cx+ay*cy+az*cz,along=al*al/aa,perp=cx*cx+cy*cy+cz*cz-along,e=along/.12+perp/.017;if(e<1){lf=e<.7?1:1-(e-.7)*3.3;lr=e>.55?(e-.55)*2.2:0}}
 /* a caustic: the lamp's light gathers again on the far side of the resin */
 const qx=wx-.4,qy=wy-.46,cs=1-(qx*qx+qy*qy)*7,ca=cs>0?cs*cs:0;
 if(band>0){/* resin tinted all the way through: a darker lit body + light that scatters through the middle */
  const wr=C[0]*.94+26,wg=C[1]*.9+10,wb=C[2]*.86,sc=(.1+.5*k2*k2+.18*k2)*(.8+.4*bl)*(1+.55*fl);
  let dr=wr*.4,dg=wg*.4,db=wb*.4,ur=wr*sc,ug=wg*sc,ub=wb*sc;
  if(is8){dr=C[0];dg=C[1];db=C[2];ur=(3+9*k2)*(.8+.4*bl);ug=ur*.4;ub=ur*.05}
  /* leaves: dark gold silhouettes with a warm glow in the rim; bubbles: a bright ring and a faint filled core */
  const lk=lf*(is8?.6:.9);dr+=((is8?70:92)-dr)*lk;dg+=((is8?36:50)-dg)*lk;db+=((is8?6:4)-db)*lk;ur*=1-lk*.9;ug*=1-lk*.9;ub*=1-lk*.9;
  const gl=lr*lf*(is8?80:60);ur+=gl*1.2;ug+=gl*.62;ub+=gl*.1;
  const bw=(rin*.8+bub)*(is8?.5:1);ur+=255*bw*.62;ug+=238*bw*.6;ub+=190*bw*.5;
  if(!is8){const cc=ca*.75;ur+=(wr*.6+70)*cc;ug+=(wg*.6+50)*cc;ub+=(wb*.5+10)*cc;const dk=(1-k2)*(1-k2);dr*=1-dk*.5;dg*=1-dk*.55;db*=1-dk*.5}
  r=dr*band;g=dg*band;b=db*band;er=ur*band;eg=ug*band;eb=ub*band;
  if(is8){const w=o.RA*o.RA*.8+ca*.08;er+=190*w;eg+=80*w;eb+=8*w}}
 if(ab>0){/* cream-honey resin: light like beeswax with a faint swirl, a few bubbles and a deeper line where it meets the band */
  const CP=o.CP,s=(.93+.07*bl-.05*fl)*ab,e=o.edge,gold=(fl*.25+e*.7)*ab;
  r+=CP[0]*s;g+=CP[1]*s;b+=CP[2]*s;g-=gold*16;b-=gold*50;
  const cb=(rin*.5+bub*.8)*ab,gk=(.16+.2*k2)*ab;er+=255*cb*.35+CP[0]*gk;eg+=244*cb*.35+CP[1]*gk*.95;eb+=220*cb*.3+CP[2]*gk*.8;
  if(e>0){const ge=e*e*ab;er+=60*ge;eg+=26*ge}}
 o.r=r;o.g=g;o.b=b;o.er=er;o.eg=eg;o.eb=eb}

/* ---------------------------------------------------------------- Glacier Crystal */
function pzb7Glacier(o){const C=o.C,lx=o.lx,ly=o.ly,lz=o.lz,wx=o.wx,wy=o.wy,wz=o.wz,band=o.band,ab=o.ab,is8=o.is8,vx=PZB7.vx,vy=PZB7.vy,vz=PZB7.vz,k2=wz*wz,RA=o.RA;
 /* fracture planes: a near layer (bright, sharp) and a deep layer (blue, dim); each family only exists where its slow mask is high */
 const nx=lx-vx*.2,ny=ly-vy*.2,nz=lz-vz*.2,mx=lx-vx*.6,my=ly-vy*.6,mz=lz-vz*.6;
 const K=.15915,w1=pzb7T((ny*10+nz*8)*K)*.035+pzb7T((nx*3.1+nz*2.4)*K)*.08,a1=(nx*.62+ny*.55+nz*.56)*1.75+w1,i1=((a1+64.5)|0)-64,u1=a1-i1,m1=pzb7T((nx*2.6-nz*3.1+ny*1.8)*K)*2.6+.2,
  w2=pzb7T((mx*9+mz*7)*K)*.03+pzb7T((my*2.7+mz*3.3)*K)*.08,u2=pzb7U((mx*-.5+my*.7-mz*.51)*1.3+w2),m2=pzb7T((my*2.8+mx*2.6+mz*1.1)*K)*2.6+.3,
  u3=pzb7U((nx*.2-ny*.6+nz*.77)*1.9+w1),m3=pzb7T((nz*2.9+nx*2.2-ny*1.9+1.7)*K)*2.6+.1;
 let c1=0,c2=0,c3=0;if(m1>0){c1=1-(u1<0?-u1:u1)*30;if(c1>0)c1*=m1>1?1:m1;else c1=0}if(m3>0){c3=1-(u3<0?-u3:u3)*30;if(c3>0)c3*=m3>1?1:m3;else c3=0}if(m2>0){c2=1-(u2<0?-u2:u2)*24;if(c2>0)c2*=m2>1?1:m2;else c2=0}
 const cn=c1>c3?c1:c3,sh=m1*3,shard=1+(pzb2Hash(i1,5,2)-.5)*.42*(sh>1?1:sh<0?0:sh);
 /* frost near the rim, patchy and grainy */
 const fm0=pzb7T((lx*4.3+pzb7T((ly*3.1+lz*2.2)*K)*1.4+ly*1.1)*K),fp=(1-k2)*(fm0*.5+.62),fr0=fp>0?(fp>1?1:fp):0;let fr=0;if(fr0>.02){const gh=pzb2Hash(Math.floor(lx*21),Math.floor(ly*21),Math.floor(lz*21));fr=fr0*(.7+.6*gh)}
 /* a caustic on the side away from the lamp */
 const qx=wx-.4,qy=wy-.46,cs=1-(qx*qx+qy*qy)*7,ca=cs>0?cs*cs:0;
 /* glints: a few cold four-point stars whose flash depends on how the cell faces the light */
 const qx2=(lx-vx*.1)*7,qy2=(ly-vy*.1)*7,qz2=(lz-vz*.1)*7,kx=Math.floor(qx2),ky=Math.floor(qy2),kz=Math.floor(qz2),hs=pzb2Hash(kx,ky,kz);let st=0;
 if(hs>.9){const dx=qx2-kx-.5,dy=qy2-ky-.5,dz=qz2-kz-.5,dn=(pzb7Fr(hs*7.7)*2-1)*PZB7.hx+(pzb7Fr(hs*3.3)*2-1)*PZB7.hy+(pzb7Fr(hs*5.9)*2-1)*PZB7.hz,ff=(dn<0?-dn:dn)-.45;
  if(ff>0){const dd=dx*dx+dy*dy+dz*dz,ax=dx<0?-dx:dx,ay=dy<0?-dy:dy,az=dz<0?-dz:dz,mn=ax<ay?(ax<az?ax:az):(ay<az?ay:az),
   core=1-dd*7,spike=1-(ax+ay+az-mn)*2.6*(dd<.16?1:3);st=((core>0?core:0)+(spike>0?spike*.6:0))*ff*2.4;if(st>1.4)st=1.4}}
 let r=0,g=0,b=0,er=0,eg=0,eb=0;
 if(band>0){
  if(is8){/* black ice: deep blue-black, glossy, pale cracks */
   r=C[0];g=C[1];b=C[2];const cc=cn*.6+c2*.15;er=130*cc+10*k2;eg=170*cc+16*k2;eb=230*cc+34*k2;const rm=RA*.3;er+=60*rm;eg+=110*rm;eb+=190*rm;er+=190*st*.35;eg+=220*st*.35;eb+=255*st*.35}
  else{/* ice tinted with the ball's colour, a milky heart, a deep blue second layer of cracks, frosted patches near the rim */
   const mk=k2*k2*(.5+.5*(fm0*.5+.5)),sc=(.2+.46*k2*k2+.1*k2)*shard;
   r=C[0]*.5*shard;g=C[1]*.5*shard;b=C[2]*.52*shard;
   er=C[0]*sc+mk*(C[0]*.3+22)+fr*(C[0]*.2+22)+ca*(C[0]*.3+34);eg=C[1]*sc+mk*(C[1]*.3+36)+fr*(C[1]*.2+30)+ca*(C[1]*.3+44);eb=C[2]*sc+mk*(C[2]*.3+58)+fr*(C[2]*.2+42)+ca*(C[2]*.3+64);
   const d2=c2*.85;er+=d2*(C[0]*.35+50);eg+=d2*(C[1]*.35+90);eb+=d2*(C[2]*.3+140);
   er+=cn*(C[0]*.2+175)*.8;eg+=cn*(C[1]*.2+205)*.8;eb+=cn*(C[2]*.1+235)*.8;er+=215*st;eg+=235*st;eb+=255*st}
  r*=band;g*=band;b*=band;er*=band;eg*=band;eb*=band}
 if(ab>0){/* opaque frosted white, tiny crystals, a bright icy edge where it meets the tinted band */
  const CP=o.CP,mx2=(lx+vx*.05)*15,my2=(ly+vy*.05)*15,mz2=(lz+vz*.05)*15,ht=pzb2Hash(Math.floor(mx2),Math.floor(my2),Math.floor(mz2)),sp=ht>.86?(ht-.86)*6:0,
   fl2=(.9+.1*fm0)*(1-cn*.1)*ab,gk=(.2+.14*k2)*ab;r+=CP[0]*fl2;g+=CP[1]*fl2;b+=CP[2]*fl2;
   er+=(sp*70+st*210)*ab+CP[0]*gk+cn*30*ab;eg+=(sp*80+st*230)*ab+CP[1]*gk+cn*50*ab;eb+=(sp*90+st*255)*ab+CP[2]*gk+cn*70*ab;const e=o.edge;if(e>0){const ge=e*e*ab;er+=60*ge;eg+=120*ge;eb+=160*ge}}
 o.r=r;o.g=g;o.b=b;o.er=er;o.eg=eg;o.eb=eb}

pzb3Reg({id:'amber',n:'Harvest Amber',price:15000,tag:'Autumn light trapped in resin.',
 pal:{col:{1:[250,194,36],2:[48,92,204],3:[204,38,60],4:[126,58,176],5:[238,108,28],6:[40,148,84],7:[142,34,42],8:[20,13,9]},
  white:[250,243,228],cap:[255,239,200],disc:[255,246,220],num:[72,36,6],disc8:[252,244,222],num8:[34,18,6],ring8:[255,170,56],spec:1.25,win:.14,rim:.2},
 mat:pzb7Amber});
pzb3Reg({id:'glacier',n:'Glacier Crystal',price:25000,tag:'Ice from the heart of a glacier.',
 pal:{col:{1:[255,212,52],2:[40,106,240],3:[228,34,70],4:[136,66,236],5:[255,128,36],6:[22,184,140],7:[150,24,60],8:[6,12,30]},
  white:[238,246,255],cap:[238,246,255],disc:[246,250,255],num:[14,30,92],disc8:[240,248,255],num8:[8,18,56],ring8:[150,212,255],spec:1.5,win:.18,rim:.34},
 mat:pzb7Glacier});
