/* ---------- daily rewards: a calendar that lasts one calendar month, then resets ---------- */
const CAL_MIN=20; /* claims needed in a month to win the grand prize */
const dlLocal=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
const dlYM=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0');
const DL_MONTHS=['January','February','March','April','May','June','July','August','September','October','November','December'];
function calSync(){const now=new Date(),m=dlYM(now);if(!P.cal||P.cal.m!==m){const old=P.cal;P.cal={m,c:{},rs:old&&old.m?1:0};if(old&&old.m)P.calPrev={m:old.m,n:Object.keys(old.c||{}).length};save()}return P.cal}
const calInfo=()=>{const now=new Date(),y=now.getFullYear(),mo=now.getMonth(),D=new Date(y,mo+1,0).getDate(),c=calSync();return{now,y,mo,D,td:now.getDate(),off:new Date(y,mo,1).getDay(),c:c.c,n:Object.keys(c.c).length}};
const calReady=()=>{const i=calInfo();return !i.c[i.td]};
/* what each day pays. Plain days are gold; every fifth day adds a crate; the 7th, 14th and 21st are milestones; the last day is the grand prize */
const dlStreakBefore=()=>{const t=dlLocal(new Date());return P.dlast===t||P.dlast===dlStreak()?(P.dstreak||0):0};
const dlBonus=()=>Math.min(.5,.05*(P.dlast===dlStreak()?(P.dstreak||0):0));
const dlR=(v,s)=>Math.round(v/s)*s;
function calReward(d,D,nBefore,b){b=b||0;const r={k:'w',b};let g=dlR(70+7*d,10);
 if(d===D){r.grand=1;r.k='p';g=1000;r.sp=1;r.scr=1;if(nBefore+1>=CAL_MIN)r.pcr=1;else r.scr=2;if(nBefore+1>=D){r.perfect=1;r.sp++;r.pcr=(r.pcr||0)+1;g+=1000}}
 else if(d===7){r.ms=1;r.k='s';r.scr=1;g+=150;r.xp=250}
 else if(d===14){r.ms=1;r.k='a';r.acr=1;r.sp=1;g+=150}
 else if(d===21){r.ms=1;r.k='s';r.scr=1;g+=200;r.xp=300}
 else if(d===28){r.ms=1;r.k='s';r.scr=1;g+=250;r.xp=400}
 else if(d%5===0){if((d/5)%2){r.crates=1;r.k='w'}else{r.acr=1;r.k='a'}}
 else if(d%3===0)r.xp=dlR(100+8*d,25);
 r.gold=dlR(g*(1+b),5);return r}
const dlParts=r=>{const p=[];p.push(['coin',r.gold+' gold'+(r.b>0?'  (+'+Math.round(r.b*100)+'% streak)':'')]);if(r.crates)p.push(['chest','Weapon crate']);if(r.acr)p.push(['chesta','Armor crate']);if(r.scr)p.push(['chests',(r.scr>1?r.scr+'x ':'')+'Special crate']);if(r.pcr)p.push(['relic',(r.pcr>1?r.pcr+'x ':'')+'Eclipse Chest']);if(r.sp)p.push(['star','+'+r.sp+' skill point'+(r.sp>1?'s':'')]);if(r.xp)p.push(['xp','+'+r.xp+' player XP']);return p};
const DLI={coin:'<circle cx="12" cy="12" r="8.5" fill="#ffc94a" stroke="#a8701a" stroke-width="1.6"/><circle cx="12" cy="12" r="5.6" fill="none" stroke="#b8821e" stroke-width="1.2"/><path d="M12 8.6v6.8M10.2 10.4h2.6a1.2 1.2 0 010 2.4h-1.6a1.2 1.2 0 000 2.4h2.6" stroke="#8a5a10" stroke-width="1.3" fill="none" stroke-linecap="round"/>',
 chest:'<path d="M3.5 11V8.4C3.5 6 7.2 4 12 4s8.5 2 8.5 4.4V11z" fill="#9a6230" stroke="#4e2e14" stroke-width="1.4"/><rect x="3.5" y="11" width="17" height="8.5" rx="1.4" fill="#7a4a24" stroke="#4e2e14" stroke-width="1.4"/><rect x="10.3" y="10" width="3.4" height="4.4" rx=".8" fill="#ffc94a" stroke="#8a6218"/>',
 chesta:'<path d="M3.5 11V8.4C3.5 6 7.2 4 12 4s8.5 2 8.5 4.4V11z" fill="#6a7690" stroke="#2c3444" stroke-width="1.4"/><rect x="3.5" y="11" width="17" height="8.5" rx="1.4" fill="#4a5468" stroke="#2c3444" stroke-width="1.4"/><rect x="10.3" y="10" width="3.4" height="4.4" rx=".8" fill="#9fc4ff" stroke="#4a5a78"/>',
 chests:'<path d="M3.5 11V8.4C3.5 6 7.2 4 12 4s8.5 2 8.5 4.4V11z" fill="#7a3aa0" stroke="#2e1244" stroke-width="1.4"/><rect x="3.5" y="11" width="17" height="8.5" rx="1.4" fill="#5a2a7a" stroke="#2e1244" stroke-width="1.4"/><rect x="10.3" y="10" width="3.4" height="4.4" rx=".8" fill="#ffd76a" stroke="#a8701a"/>',
 relic:'<path d="M12 2.5l2.6 5.6 6 .8-4.4 4.2 1.1 6-5.3-2.9-5.3 2.9 1.1-6-4.4-4.2 6-.8z" fill="#ffd76a" stroke="#a8701a" stroke-width="1.3"/><circle cx="12" cy="11.6" r="2.4" fill="#e04aff" stroke="#6a1a8a"/>',
 xp:'<path d="M6 3.5h10a2 2 0 012 2V19a1.5 1.5 0 01-1.5 1.5H8A2.5 2.5 0 015.5 18V4z" fill="#e8dcff" stroke="#6a58a8" stroke-width="1.4"/><path d="M9 8h6M9 11h6M9 14h3.5" stroke="#6a58a8" stroke-width="1.3" stroke-linecap="round"/><circle cx="17" cy="17" r="4" fill="#8ae0ff" stroke="#2a78a8" stroke-width="1.3"/><path d="M17 15v4M15 17h4" stroke="#0a3a58" stroke-width="1.3" stroke-linecap="round"/>',
 star:'<path d="M12 3l2.2 5.4 5.8.5-4.4 3.8 1.4 5.7L12 15.3 7 18.4l1.4-5.7L4 8.9l5.8-.5z" fill="#8ae0ff" stroke="#2a78a8" stroke-width="1.4" stroke-linejoin="round"/>',
 gift:'<rect x="3.5" y="9" width="17" height="11" rx="1.6"/><path d="M3 9h18v3.4H3zM12 9v11M12 9c-1.2-4-5.5-4-5.5-1.6S10.6 9 12 9zm0 0c1.2-4 5.5-4 5.5-1.6S13.4 9 12 9z"/>'};
const dlSvg=(k,s)=>`<svg viewBox="0 0 24 24" width="${s}" height="${s}" aria-hidden="true">${DLI[k]}</svg>`;
HIC.gift=DLI.gift;
const dly={sel:0,fx:null,t0:0};
function dlStreak(){const y=new Date(Date.now()-864e5);return dlLocal(y)}
function calGrant(r){P.gold+=r.gold;if(r.xp)P.xp+=r.xp;if(r.crates)P.crates=(P.crates||0)+r.crates;if(r.acr)P.acr=(P.acr||0)+r.acr;if(r.scr)P.scr=(P.scr||0)+r.scr;if(r.pcr)P.pcr=(P.pcr||0)+r.pcr;if(r.sp)P.spb=(P.spb||0)+r.sp}
function calClaim(){const i=calInfo();if(i.c[i.td])return;const r=calReward(i.td,i.D,i.n,dlBonus());
 P.dstreak=P.dlast===dlStreak()?Math.min(99,(P.dstreak||0)+1):1;P.dlast=dlLocal(i.now);P.daily=today();
 P.cal.c[i.td]=r.gold;P.cal.rs=0;calGrant(r);save();setTimeout(achCheck,60);
 dly.fx={d:i.td,r};dly.t0=performance.now();jingle(r.grand?'win':r.ms?'win':'boon');return r}
function dlDayLabel(d,i){if(i.c[d])return'Claimed';if(d===i.td)return'Today';if(d>i.td){const n=d-i.td;return n===1?'Tomorrow':'In '+n+' days'}return'Missed'}
const DL_SEA=[['Frostfall',205],['Deepwinter',215],['The Thaw',160],['Bloom',130],['Greenwatch',100],['Highsun',45],['Emberdays',25],['Harvestgold',38],['The Reaping',20],['Hunter’s Moon',275],['Longnight',250],['Yuletide',350]];
const dlRew=(d,i)=>{const cl=!!i.c[d],r=calReward(d,i.D,cl?i.n-1:i.n,d===i.td&&!cl?dlBonus():0);if(cl&&i.c[d]>1)r.gold=i.c[d];return r};
const dlIcon=r=>r.grand||r.pcr?'relic':r.scr?'chests':r.acr?'chesta':r.crates?'chest':r.xp?'xp':'coin';
function dlTile(d,i){const st=i.c[d]?'got':d===i.td?'now':d>i.td?'soon':'miss',r=dlRew(d,i),big=r.grand?'grand':r.ms?'ms':'',ic=dlIcon(r),lb=r.grand?'Grand prize':r.ms?'Milestone':(r.crates||r.acr)?'Crate':r.xp?'Gold + XP':r.gold;
 return `<button class="dt ${st} ${big}${dly.sel===d?' sel':''}" data-d="${d}" style="--i:${d}" ${st==='now'?'':'tabindex="-1"'}><span class="dn">${d}</span><span class="dmd"></span><span class="di">${dlSvg(ic,r.grand?48:38)}</span><span class="dl">${lb}</span>${r.ms||r.grand?`<i class="drb">${r.grand?'GRAND':'BONUS'}</i>`:''}${st==='got'?'<i class="dk"><svg viewBox="0 0 24 24" width="22" height="22"><path d="M5 12.5l4.5 4.5L19 7.5" fill="none" stroke="#06281a" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"/></svg></i>':''}${st==='now'?'<i class="dp"></i><i class="dcn">CLAIM</i>':''}<i class="dsh"></i></button>`}
function dlPanel(i){const d=dly.sel,r=dlRew(d,i),parts=dlParts(r),can=d===i.td&&!i.c[d],lab=dlDayLabel(d,i),why=i.c[d]?'You collected this one.':d===i.td?'Ready to collect.':d>i.td?'Come back on the day to collect it.':'Missed. Rewards only pay out on their own day.',cls=r.grand?'grand':r.ms?'ms':'';
 const need=d===i.D&&!r.perfect&&!r.pcr?`<p class="dw">The Eclipse Chest needs ${CAL_MIN} claims this month. You have ${i.n}${d===i.td&&!i.c[d]?` (${i.n+1} with today)`:''}. Until then this day pays two Special crates.</p>`:d===i.D?`<p class="dw">${r.perfect?'Perfect month! Every single day claimed.':`Claim every day of the month for a Perfect Month bonus: +1 skill point, a second Eclipse Chest and +1000 gold. You have ${i.n} of ${i.D}.`}</p>`:'';
 const sb=d===i.td&&!i.c[d]?(r.b>0?`<p class="dw ok">Streak bonus active: +${Math.round(r.b*100)}% gold</p>`:'<p class="dw">Claim on consecutive days to build a streak bonus, up to +50% gold.</p>'):'';
 return `<div class="dpt ${cls}"><div class="dsc"><canvas id="dsh" width="360" height="190"></canvas><small>${DL_MONTHS[i.mo]} ${d}</small></div><h3>${r.grand?'Grand prize':r.ms?'Milestone reward':'Day '+d}</h3><em class="dst ${i.c[d]?'got':d===i.td?'now':d>i.td?'soon':'miss'}">${lab}</em>
 <ul>${parts.map(([k,t])=>`<li class="r-${k}">${dlSvg(k,30)}<span>${t}</span></li>`).join('')}</ul>${sb}${need}
 ${can?'<button id="dcl" class="dclaim"><span>Claim reward</span></button>':`<p class="dwhy">${why}</p>`}</div>`}
/* the animated showcase above the reward list: a chest for crate days, spinning coins for the rest */
function dlCoin(g,x,y,r,sx){g.save();g.translate(x,y);g.scale(Math.max(.1,Math.abs(sx)),1);const q=g.createLinearGradient(-r,-r,r,r);q.addColorStop(0,'#fff0a8');q.addColorStop(.5,'#ffc94a');q.addColorStop(1,'#c88a1a');g.fillStyle=q;g.strokeStyle='#8a5a10';g.lineWidth=3;g.beginPath();g.arc(0,0,r,0,TAU);g.fill();g.stroke();g.strokeStyle='#b8821e';g.lineWidth=2;g.beginPath();g.arc(0,0,r*.68,0,TAU);g.stroke();if(Math.abs(sx)>.45){g.fillStyle='#8a5a10';g.font='bold '+Math.round(r*.9)+'px Georgia,serif';g.textAlign='center';g.textBaseline='middle';g.fillText('$',0,2)}g.restore()}
function dlSpark(g,x,y,r,c){g.save();g.translate(x,y);g.fillStyle=c;g.beginPath();for(let k=0;k<8;k++){const a=k*TAU/8,rr=k%2?r*.28:r;g.lineTo(Math.cos(a)*rr,Math.sin(a)*rr)}g.closePath();g.fill();g.restore()}
function dlShow(r){const cv=$('dsh');if(!cv)return;const g=cv.getContext('2d'),box=!!(r.crates||r.acr||r.scr||r.pcr),ac=dlAccent(),t0=performance.now();
 LIVE.push({cv,fn:()=>{const t=(performance.now()-t0)/1000;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,360,190);try{
  glow(g,180,105,120+Math.sin(t*2)*10,(r.grand?'#ff9aff':ac)+'55');
  if(box){const u=.12+.1*Math.sin(t*2.2);chest(g,180,166+Math.sin(t*1.6)*3,1.05,u,r.k,t)}
  else{for(let k=0;k<3;k++){const ph=t*2.4+k*1.1;dlCoin(g,180+(k-1)*58,100+Math.sin(t*1.7+k)*8-(k===1?18:0),30,Math.cos(ph))}}
  for(let k=0;k<5;k++){const a=t*.9+k*TAU/5,rx=150,ry=62;dlSpark(g,180+Math.cos(a)*rx,100+Math.sin(a)*ry,4+3*Math.abs(Math.sin(t*3+k)),k%2?'#fff3c4':ac)}
  }catch(e){}}})}
const dlAccent=()=>`hsl(${DL_SEA[new Date().getMonth()][1]},90%,68%)`.replace(/hsl\((\d+),90%,68%\)/,(m,h)=>{const c=document.createElement('canvas').getContext('2d');c.fillStyle=m;return c.fillStyle});
/* the animated vault behind the calendar: aurora, god rays, falling coins and gems, a glittering treasure hoard */
function dlScene(){const cv=document.createElement('canvas'),W2=960,H2=540;cv.width=W2;cv.height=H2;cv.className='dbg';ov.prepend(cv);const g=cv.getContext('2d'),hue=DL_SEA[new Date().getMonth()][1];
 const R=(a,b)=>a+Math.random()*(b-a);
 const pile=document.createElement('canvas');pile.width=W2;pile.height=H2;{const p=pile.getContext('2d');const hf=x=>26+34*Math.sin(x*.006+1)+22*Math.sin(x*.017+2)+16*Math.sin(x*.043);
  for(let n=0;n<900;n++){const x=Math.random()*W2,top=H2-30-hf(x)-Math.random()*40,y=top+Math.random()*(H2-top),sh=.45+.55*(y-top)/(H2-top+1);p.save();p.translate(x,y);p.rotate(R(-.5,.5));const q=p.createLinearGradient(-14,-5,14,5);q.addColorStop(0,`hsl(42,90%,${Math.round(34+22*sh)}%)`);q.addColorStop(1,`hsl(32,85%,${Math.round(18+16*sh)}%)`);p.fillStyle=q;p.strokeStyle='#4a2a08';p.lineWidth=1.2;p.beginPath();p.ellipse(0,0,R(11,17),R(4.5,6.5),0,0,TAU);p.fill();p.stroke();p.restore()}
  for(let n=0;n<26;n++){const x=Math.random()*W2,y=H2-R(8,40)-hf(x)*.8,c=['#ff4a6a','#4ad8ff','#7dffb0','#c88aff','#ffe27a'][n%5];p.save();p.translate(x,y);p.fillStyle=c;p.strokeStyle='#fff8';p.lineWidth=1;p.beginPath();p.moveTo(0,-9);p.lineTo(8,-2);p.lineTo(0,10);p.lineTo(-8,-2);p.closePath();p.fill();p.stroke();p.restore()}}
 const spots=Array.from({length:34},()=>{const x=Math.random()*W2;return{x,y:H2-R(10,70),p:R(0,6.3),v:R(.8,2)}});
 const coins=Array.from({length:30},()=>({x:R(0,W2),y:R(-20,H2),v:R(14,40),r:R(5,10),p:R(0,6.3),w:R(.8,2.4),sw:R(10,36),gem:Math.random()<.2?Math.floor(R(0,5)):-1}));
 const stars=Array.from({length:60},()=>({x:R(0,W2),y:R(0,260),s:R(.5,1.6),p:R(0,6.3)}));
 const GC=['#ff4a6a','#4ad8ff','#7dffb0','#c88aff','#ffe27a'];
 LIVE.push({cv,fn:()=>{const t=performance.now()/1000;g.setTransform(1,0,0,1,0,0);g.globalCompositeOperation='source-over';g.globalAlpha=1;
  const bg=g.createLinearGradient(0,0,0,H2);bg.addColorStop(0,'#150a34');bg.addColorStop(.55,'#2a1248');bg.addColorStop(1,'#3a1a22');g.fillStyle=bg;g.fillRect(0,0,W2,H2);
  for(const s of stars){g.globalAlpha=.25+.6*Math.abs(Math.sin(t*1.1+s.p));g.fillStyle='#fff';g.fillRect(s.x,s.y,s.s,s.s)}g.globalAlpha=1;
  g.globalCompositeOperation='lighter';
  for(let k=0;k<3;k++){const h=hue+(k-1)*38,top=70+k*34;g.beginPath();for(let x=0;x<=W2;x+=10){const y=top+Math.sin(x*.007+t*.35+k*2.1)*46+Math.sin(x*.019+t*.7+k)*12;x?g.lineTo(x,y):g.moveTo(x,y)}for(let x=W2;x>=0;x-=10){const y=top+130+Math.sin(x*.005+t*.3+k)*30;g.lineTo(x,y)}g.closePath();const q=g.createLinearGradient(0,top-40,0,top+170);q.addColorStop(0,`hsla(${h},90%,62%,0)`);q.addColorStop(.35,`hsla(${h},90%,62%,.2)`);q.addColorStop(1,`hsla(${h},90%,62%,0)`);g.fillStyle=q;g.fill()}
  for(let r=0;r<9;r++){const a=Math.PI/2+(r-4)*.2+Math.sin(t*.22+r*1.7)*.07,w=.06+.02*Math.sin(t*.5+r),L=900,cx=W2/2,cy=-30;g.beginPath();g.moveTo(cx,cy);g.lineTo(cx+Math.cos(a-w)*L,cy+Math.sin(a-w)*L);g.lineTo(cx+Math.cos(a+w)*L,cy+Math.sin(a+w)*L);g.closePath();const q=g.createRadialGradient(cx,cy,10,cx,cy,L);q.addColorStop(0,'rgba(255,226,140,.2)');q.addColorStop(1,'rgba(255,226,140,0)');g.fillStyle=q;g.fill()}
  const gl=g.createRadialGradient(W2/2,H2+20,10,W2/2,H2+20,420+Math.sin(t*1.3)*20);gl.addColorStop(0,'rgba(255,190,70,.45)');gl.addColorStop(1,'rgba(255,190,70,0)');g.fillStyle=gl;g.fillRect(0,0,W2,H2);
  g.globalCompositeOperation='source-over';g.globalAlpha=.8;g.drawImage(pile,0,0);g.globalAlpha=1;
  g.globalCompositeOperation='lighter';for(const s of spots){const a=Math.max(0,Math.sin(t*s.v+s.p));if(a<.3)continue;g.globalAlpha=a;g.fillStyle='#fff3c4';g.beginPath();for(let k=0;k<8;k++){const an=k*TAU/8,rr=k%2?1.5:7*a;g.lineTo(s.x+Math.cos(an)*rr,s.y+Math.sin(an)*rr)}g.closePath();g.fill()}g.globalAlpha=1;
  g.globalCompositeOperation='source-over';
  for(const c of coins){c.y+=c.v*.016;if(c.y>H2+20){c.y=-20;c.x=R(0,W2)}const x=c.x+Math.sin(t*.8+c.p)*c.sw,y=c.y,sx=Math.cos(t*c.w+c.p);g.save();g.translate(x,y);
   if(c.gem>=0){g.rotate(Math.sin(t+c.p)*.4);g.fillStyle=GC[c.gem];g.globalAlpha=.8;g.beginPath();g.moveTo(0,-c.r);g.lineTo(c.r*.8*Math.abs(sx)+1,-c.r*.2);g.lineTo(0,c.r*1.1);g.lineTo(-c.r*.8*Math.abs(sx)-1,-c.r*.2);g.closePath();g.fill();g.strokeStyle='#fffa';g.lineWidth=1;g.stroke()}
   else{g.scale(Math.max(.12,Math.abs(sx)),1);g.globalAlpha=.75;const q=g.createLinearGradient(-c.r,-c.r,c.r,c.r);q.addColorStop(0,'#fff0a8');q.addColorStop(1,'#d89a22');g.fillStyle=q;g.strokeStyle='#8a5a10';g.lineWidth=1.4;g.beginPath();g.arc(0,0,c.r,0,TAU);g.fill();g.stroke()}g.restore()}
  g.globalAlpha=1;const vg=g.createRadialGradient(W2/2,H2*.45,H2*.25,W2/2,H2*.5,H2*.85);vg.addColorStop(0,'rgba(8,4,20,0)');vg.addColorStop(1,'rgba(8,4,20,.62)');g.fillStyle=vg;g.fillRect(0,0,W2,H2)}})}
function dailyMenu(back){dly.rt=performance.now();S.mode='title';S.view='menu';dly.back=back||title;const i=calInfo();if(dly.m!==P.cal.m){dly.m=P.cal.m;dly.sel=0}
 if(dly.fx&&dly.fx.d!==i.td)dly.fx=null;
 if(!dly.sel||dly.sel>i.D)dly.sel=i.c[i.td]&&i.td<i.D?i.td+1:i.td;
 const left=i.D-i.td,reset=left===0?'tomorrow':'in '+(left+1)+' days',streak=dlStreakBefore(),sb=Math.round(dlBonus()*100),sea=DL_SEA[i.mo];
 const marks=[7,14,21,i.D].filter((v,k,a)=>a.indexOf(v)===k),pct=Math.min(100,i.n/i.D*100);
 const wk=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];let cells='';for(let k=0;k<i.off;k++)cells+='<span class="de"></span>';for(let d=1;d<=i.D;d++)cells+=dlTile(d,i);
 const prev=P.calPrev&&P.cal.rs?`<div class="dbn"><b>A new month begins.</b> Every reward has reset. Last month you claimed ${P.calPrev.n} day${P.calPrev.n===1?'':'s'}.</div>`:'';
 show(`<div class="dm" style="--ac:hsl(${sea[1]},90%,68%);--ac2:hsl(${sea[1]},70%,32%)"><div class="dh"><div class="dtt"><small>Daily rewards</small><h2>${DL_MONTHS[i.mo]} <span>${i.y}</span></h2><div class="dfl"><i></i><em>${sea[0]}</em><i></i></div></div><div class="dstat"><span><b>${i.n}<u> / ${i.D}</u></b><small>claimed</small></span><span class="dfs"><b>${streak}</b><small>day streak${sb?' · +'+sb+'% gold':''}</small></span><span><b>${reset}</b><small>calendar resets</small></span></div></div>
 ${prev}<div class="dtr"><div class="dtk"></div><div class="df" style="width:${pct}%"></div>${marks.map(v=>`<span class="dmk${i.c[v]?' on':''}${v===i.D?' last':''}" style="left:${v/i.D*100}%">${dlSvg(v===i.D?'relic':v===14?'chesta':'chests',26)}<i>${v===i.D?'Grand prize':'Day '+v}</i></span>`).join('')}</div>
 <div class="dcols"><div class="dgrid"><div class="dwk">${wk.map(w=>`<b>${w}</b>`).join('')}</div><div class="dcl">${cells}</div></div><div class="dpn" id="dpn">${dlPanel(i)}</div></div>
 <div class="row"><button class="sm" id="b">Back</button></div></div>`,'m top drw');
 dlScene();S.back=()=>dly.back();$('b').onclick=()=>dly.back();dlWire();dlShow(dlRew(dly.sel,i));if(dly.fx)dlCelebrate();ov.scrollTop=0}
function dlWire(){const i=calInfo();
 ov.querySelectorAll('.dt').forEach(el=>{const d=+el.dataset.d;el.onclick=()=>{if(d===i.td&&!i.c[d]){doClaim();return}dlSelect(d)};
  el.onmouseenter=()=>{if(performance.now()-dly.rt>600&&dly.sel!==d)dlSelect(d,1)};
  el.onmousemove=e=>{const r=el.getBoundingClientRect(),x=(e.clientX-r.left)/r.width,y=(e.clientY-r.top)/r.height;el.style.setProperty('--rx',((.5-y)*16).toFixed(1)+'deg');el.style.setProperty('--ry',((x-.5)*18).toFixed(1)+'deg');el.style.setProperty('--mx',(x*100).toFixed(0)+'%');el.style.setProperty('--my',(y*100).toFixed(0)+'%')};
  el.onmouseleave=()=>{el.style.setProperty('--rx','0deg');el.style.setProperty('--ry','0deg')}});
 if($('dcl'))$('dcl').onclick=doClaim}
function dlSelect(d,soft){dly.sel=d;const i=calInfo();ov.querySelectorAll('.dt').forEach(e=>e.classList.toggle('sel',+e.dataset.d===d));$('dpn').innerHTML=dlPanel(i);dlShow(dlRew(d,i));if($('dcl'))$('dcl').onclick=doClaim;if(!soft)beep(520,.04,'triangle',.3)}
function doClaim(){const r=calClaim();if(!r)return;dailyMenu(dly.back)}
function dlCelebrate(){const f=dly.fx;if(!f)return;const r=f.r,parts=dlParts(r),box=document.createElement('div');box.className='dcb';
 box.innerHTML=`<div class="dray"></div><div class="dcard ${r.perfect?'grand':r.grand?'grand':r.ms?'ms':''}"><canvas id="dcv" width="360" height="230"></canvas><h3>${r.perfect?'Perfect month!':r.grand?'Grand prize!':r.ms?'Milestone reached!':'Reward claimed'}</h3><small>${DL_MONTHS[calInfo().mo]} ${f.d}</small><div class="dch">${parts.map(([k,t],n)=>`<span style="--n:${n}">${dlSvg(k,30)}<b>${t}</b></span>`).join('')}</div><button class="sm gd" id="dok">Nice</button></div>`;
 const sp=document.createElement('div');sp.className='dsp';const cc=['#ffc94a','#ffe9a0','#8ae0ff','#ff8aa0','#c88aff','#7dffb0'];for(let n=0;n<(r.perfect?110:r.grand?80:r.ms?52:34);n++){const s=document.createElement('i'),a=Math.random()*6.283,v=160+Math.random()*(r.grand?560:380);s.style.cssText=`--x:${Math.cos(a)*v}px;--y:${Math.sin(a)*v-140}px;--r:${Math.random()*720-360}deg;--d:${Math.random()*.25}s;background:${cc[n%6]}`;sp.appendChild(s)}
 box.appendChild(sp);ov.appendChild(box);const cvs=$('dcv'),g=cvs.getContext('2d'),k=r.k;
 LIVE.push({cv:cvs,fn:()=>{const t=(performance.now()-dly.t0)/1000,u=Math.min(1,Math.max(0,(t-.35)/.6));g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,360,230);try{if(u>.2)glow(g,180,120,70+u*120,(r.grand?'#ff9aff':'#ffd76a')+Math.round(40*u).toString(16).padStart(2,'0'));chest(g,180,208,1.35,u,k,t)}catch(e){}}});
 const ok=()=>{{const i=calInfo();if(i.td<i.D)dly.sel=i.td+1}dly.fx=null;box.remove();dailyMenu(dly.back)};$('dok').onclick=ok;setTimeout(()=>{if(box.isConnected)box.classList.add('go')},30);
 setTimeout(()=>{beep(880,.08,'triangle',.5)},650)}
addEventListener('keydown',e=>{if(!ov.querySelector('.dm')||ov.className.indexOf('hide')>=0||e.ctrlKey||e.metaKey||e.altKey)return;const i=calInfo(),k=e.key;
 if(ov.querySelector('.dcb')){if(k==='Enter'||k===' '){e.preventDefault();$('dok').click()}return}
 const mv={ArrowLeft:-1,ArrowRight:1,ArrowUp:-7,ArrowDown:7}[k];if(mv){e.preventDefault();const d=Math.max(1,Math.min(i.D,dly.sel+mv));if(d!==dly.sel)dlSelect(d)}
 else if((k==='Enter'||k===' ')&&dly.sel===i.td&&!i.c[i.td]){e.preventDefault();doClaim()}});
