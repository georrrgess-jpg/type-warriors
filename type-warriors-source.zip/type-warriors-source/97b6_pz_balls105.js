/* ===== 10.6 THE CROOKED CUE: premium ball sets, a shared material painter (97b6, prefix pzb3, after 97b5) =====
   The premium sets (15,000 to 75,000 coins in the Cue Rack) each have their own material. 97b5's painter is one big function with a
   branch per material; this module copies it once (pzb3Paint) with the material pulled out into a callback, so a new set is one
   `pzb3Reg({...})` call with a small `mat(o)` function and its palette. pzbPaint hands any set registered here to pzb3Paint and
   leaves every older set to 97b5, so classic, gem, moonstone, marble, neon, lava, galaxy and royal paint exactly as before.
   The owner's rule for every ball set (CLAUDE.md) still holds and t_pzb102.py measures it for each set in PZ_BALLS: solids coloured
   all over, stripes with clearly lighter caps above and below a coloured band, the 8 clearly the darkest ball with a high-contrast
   disc, a white cue ball, readable numbers.
   Registration: pzb3Reg({id, n, price, tag, kind (default id), pal:{col:{1..8:[r,g,b]}, white, cap, disc, num, disc8, num8, ring8,
     spec, win, rim, gn (glowing number colour [r,g,b]; omit for dark numbers), gnd (1: keep the disc colour under glowing numbers),
     mk, prep(P,pal,n,C,is8,stripe) (called once per ball before its pixels)}, mat(o)}).
   mat(o) runs for every pixel of every non-cue ball (keep it cheap: no allocation, no Math.pow in the common path; pzb2Sin / pzb2Hash
   from 97b5 are fast). Inputs on o: j (pixel index), wx,wy,wz (view-space normal; wz toward the viewer), lx,ly,lz (ball-local normal, so
   the pattern rolls with the ball), ay = |ly|, band (1 on the coloured part, 0 on the light caps of a stripe; solids are always 1),
   ab = 1-band, edge (1 on the band's border, stripes only), stripe, is8, C (the ball's colour [r,g,b]), W (white), CP (cap colour),
   RA (rim amount 0..1, strongest at the silhouette), dif, spe (the shared light), hr,hg,hb (a brighter version of C). Outputs: r,g,b
   (diffuse colour, 0-255, multiplied by the shared lighting), er,eg,eb (added light that ignores the lighting: glow, sparkle,
   reflections), metal (1: skip the diffuse lighting), lit (diffuse lighting weight, default 1). Number discs, their rings, the 8's
   disc and the felt bounce are done by this module for every set. */
const PZB3={mat:{},o:{},defs:[]};
function pzb3Paint(slot,n,M){const P=PZ_BS,pal=P.pal,K=pal.kind||'classic',d=P.img.data,stripe=n>8,is8=n===8,cue=n===0,C=cue?pal.white:pal.col[stripe?n-8:n],W=pal.white,CP=pal.cap||W,
 DS=(is8&&pal.disc8)||pal.disc,NM=(is8&&pal.num8)||pal.num,R8=is8?(pal.ring8||null):null,RB=R8||[240,240,255],gl=n>0?P.gm[n]:null,
 m0=M[0],m1=M[1],m2=M[2],m3=M[3],m4=M[4],m5=M[5],m6=M[6],m7=M[7],m8=M[8],sk=pal.spec,wk=pal.win,rk=pal.rim||.25,mk=pal.mk==null?.18:pal.mk;
 if(!P.rimA||P.rimA.length!==P.n){P.rimA=new Float32Array(P.n);for(let j=0;j<P.n;j++)P.rimA[j]=Math.pow(1-P.nz[j],2.6)}const RA=P.rimA;
 /* hot vein colour (same hue, brighter) and the stripe seam colour */
 const MAT=PZB3.mat[K],O=PZB3.o;if(pal.prep)pal.prep(P,pal,n,C,is8,stripe);const hr=Math.min(255,C[0]*1.2+70),hg=Math.min(255,C[1]*1.2+52),hb=Math.min(255,C[2]*1.2+24);
 for(let j=0;j<P.n;j++){const wx=P.nx[j],wy=P.ny[j],wz=P.nz[j];
  const lx=m0*wx+m3*wy+m6*wz,ly=m1*wx+m4*wy+m7*wz,lz=m2*wx+m5*wy+m8*wz,ay=ly<0?-ly:ly;
  /* band: 1 inside the coloured part (whole ball for solids), 0 on the light caps of a stripe; edge: 1 on the band's border */
  let band=1,edge=0;if(stripe){band=1-Math.max(0,Math.min(1,(ay-.56)/.035+.5));const de=ay-.56;edge=Math.max(0,1-(de<0?-de:de)/.05)}
  let r,g,b,er=0,eg=0,eb=0,lit=1,metal=0;
  if(cue){r=W[0];g=W[1];b=W[2]}
  else{O.j=j;O.wx=wx;O.wy=wy;O.wz=wz;O.lx=lx;O.ly=ly;O.lz=lz;O.ay=ay;O.band=band;O.edge=edge;O.ab=1-band;O.stripe=stripe;O.is8=is8;O.C=C;O.W=W;O.CP=CP;O.RA=RA[j];O.rim=rk;O.dif=P.dif[j];O.spe=P.spe[j];O.hr=hr;O.hg=hg;O.hb=hb;
   O.r=0;O.g=0;O.b=0;O.er=0;O.eg=0;O.eb=0;O.metal=0;O.lit=1;MAT(O);r=O.r;g=O.g;b=O.b;er=O.er;eg=O.eg;eb=O.eb;metal=O.metal;lit=O.lit}
  /* number discs on both poles, with a crisp ring round each */
  const az=lz<0?-lz:lz;
  if(n>0){if(az>.8){const u=lx*2,v=ly*2,q=u*u+v*v;if(q<1.3){const dk=Math.max(0,Math.min(1,(1-q)/.1+.2)),fade=Math.min(1,(az-.8)/.03);
    const s=lz>0?1:-1,gx=((u*s*.5+.5)*64)|0,gy=((v*.5+.5)*64)|0;let gm=0;if(gx>=0&&gx<64&&gy>=0&&gy<64)gm=gl[gy*64+gx]/255;
    const t=dk*fade;let dr=DS[0]+(NM[0]-DS[0])*gm,dg=DS[1]+(NM[1]-DS[1])*gm,db=DS[2]+(NM[2]-DS[2])*gm;
    if(is8&&pal.disc8){er*=1-t;eg*=1-t;eb*=1-t}
    else if(pal.gn){er*=1-t;eg*=1-t;eb*=1-t;const e=gm*t,GN=pal.gn;er+=GN[0]*e;eg+=GN[1]*e;eb+=GN[2]*e;if(pal.gnd){dr=DS[0];dg=DS[1];db=DS[2]}}
    else{er*=1-t;eg*=1-t;eb*=1-t}
    r+=(dr-r)*t;g+=(dg-g)*t;b+=(db-b)*t;
    /* the ring: a dark line, or a glowing one round the 8's bright disc */
    const rg=Math.max(0,1-Math.abs(q-1.02)/.09)*fade*.5;if(R8){const e=rg*1.6;er+=R8[0]*e;eg+=R8[1]*e;eb+=R8[2]*e;r*=1-rg;g*=1-rg;b*=1-rg}else{r*=1-rg;g*=1-rg;b*=1-rg}}}}
  else{let dm=0;if(az>.93){const q=lx*lx+ly*ly;if(q<.026)dm=Math.min(1,(.026-q)/.006)}
   else{const ax=lx<0?-lx:lx;if(ax>.95){const q=ly*ly+lz*lz;if(q<.018)dm=Math.min(1,(.018-q)/.005)}else if(ay>.95){const q=lx*lx+lz*lz;if(q<.018)dm=Math.min(1,(.018-q)/.005)}}
   if(dm>0){r+=(210-r)*dm;g+=(48-g)*dm;b+=(52-b)*dm}}
  const f=metal?1:(P.dif[j]*lit+(1-lit)*.55),sp=P.spe[j]*255*sk,o=P.idx[j]*4,bo=P.bou[j]*38,wn=P.win[j]*255*wk,rim=RA[j]*255*rk;
  let rr=r*f+sp+wn+rim*.86+er,gg=g*f+sp+wn+bo+rim*.9+eg,bb=b*f+sp+wn+bo*.4+rim+eb;d[o]=rr>255?255:rr<0?0:rr;d[o+1]=gg>255?255:gg<0?0:gg;d[o+2]=bb>255?255:bb<0?0:bb;d[o+3]=P.al[j]*255}
 P.ax.putImageData(P.img,slot*P.D,0)}

/* pzbPaint: sets registered here use pzb3Paint, everything else the 97b5 painter */
{const f0=pzbPaint;pzbPaint=function(slot,n,M){const P=PZ_BS,K=P&&P.pal&&P.pal.kind;if(K&&PZB3.mat[K])return pzb3Paint(slot,n,M);return f0.apply(this,arguments)}}
/* register one premium set: palette, material, the shop entry (a price puts it in the Cue Rack shop) and the line under its name */
function pzb3Reg(def){const kind=def.kind||def.id;PZB3.mat[kind]=def.mat;PZB3.defs.push(def);
 PZ_BPAL[def.id]=Object.assign({kind},def.pal);
 if(!PZ_BALLS.some(b=>b.id===def.id))PZ_BALLS.push({id:def.id,n:def.n,how:'Cue Rack: '+def.price.toLocaleString(),price:def.price,prem:1});
 try{PZ_TAG97[def.id]=def.tag||''}catch(e){}}
