/* ===== UPDATE 10.4, THE HARVEST FESTIVAL: harvest gear, data and armor art (99n, prefix flg) =====
   Six armors and six weapons, one per rarity (ids and names in FL.gear / FL.gearN, 99m). Stats sit in the same bands as the
   Halloween relics of each rarity (83_hw_gear.js). Like those relics they carry hw:1, so the everyday crates, the shop lists and the
   Celestial Chest never hand them out, and the Mythic weapon keeps its own golden palette instead of the rainbow; fl:1 marks them
   as harvest gear. They come from the Harvest Chest (99o) and the two Mythics are sold for coins (FL.price, flgBuy / flgBuyBoth).
   Armor art plugs into the kit renderer through the HWH / HWC / HWFX / HWA / HWG tables (30c_head.js) plus two small hooks of
   our own: a torso overlay (K.flt: an apron, a plaid shirt under a vest, husk wraps, a velvet baldric) and custom pauldrons
   (maple leaves, corn husks, the Feastlord's feathered plates). The turkey-feather mantle of Feastlord's Aegis is painted once
   into a sprite and only placed each frame.
   Save repair: load() (50_game) runs before this module exists, so it would quietly swap an equipped harvest piece (and any
   other gear registered after 50_game, like the Astral Cleaver) for the starter set. save() therefore keeps a copy of the
   equipped ids in P.eqK, and on start the equipped piece is put back if it is owned (flgEqFix). */
const FLG_A=FL.gear.a,FLG_W=FL.gear.w,FLG_COL='#ffcf4a';
Object.assign(AR,{
 flsmock:{n:FL.gearN.flsmock,r:'Common',d:'+2% score, foes 2% slower',sc:1.02,sl:.98,m:'#b89a64',dk:'#5a4428',tr:'#e2c278',acc:'#d8442a',w:1,hw:1,fl:1},
 florch:{n:FL.gearN.florch,r:'Uncommon',d:'+1 max HP, +3% score',hp:1,sc:1.03,m:'#6e4628',dk:'#3a2414',tr:'#d8a54a',acc:'#e8402a',tier:1,w:1,hw:1,fl:1},
 flmaple:{n:FL.gearN.flmaple,r:'Rare',d:'+1 max HP, a starting shield, foes 4% slower',hp:1,sh:1,sl:.96,m:'#c4522a',dk:'#4a1a0c',tr:'#e8b04a',acc:'#ff8a2a',tier:2,w:1,hw:1,fl:1},
 flcorn:{n:FL.gearN.flcorn,r:'Epic',d:'+2 max HP, foes 6% slower, +6% score',hp:2,sl:.94,sc:1.06,m:'#d8ae3a',dk:'#5a4a14',tr:'#8ab04a',acc:'#ffd84a',tier:3,w:1,hw:1,fl:1},
 flmoon:{n:FL.gearN.flmoon,r:'Legendary',d:'+3 max HP, 2 starting shields, +8% score',hp:3,sh:2,sc:1.08,m:'#c8682a',dk:'#3a1608',tr:'#ffd27a',acc:'#ffb43a',base:'plate',tier:4,w:1,hw:1,fl:1},
 flfeast:{n:FL.gearN.flfeast,r:'Mythic',d:'+4 max HP, 3 shields, foes 10% slower, +22% score',hp:4,sh:3,sl:.9,sc:1.22,m:'#e3ae34',dk:'#6a3e0e',tr:'#fff0b0',acc:'#ffa23a',mythic:2,tier:4,w:1,hw:1,fl:1}});
Object.assign(WP,{
 fl_fork:{n:FL.gearN.fl_fork,r:'Common',d:'+5% score, +5% gold',sc:1.05,gm:.05,t:'staff',c:'#8a6a3a',p:'mage',nw:1,hw:1,fl:1,w:1},
 fl_pin:{n:FL.gearN.fl_pin,r:'Uncommon',d:'+5% crit chance, +5% gold',cr:.05,gm:.05,t:'mace',c:'#c89a5a',p:'knight',nw:1,hw:1,fl:1,w:1},
 fl_maple:{n:FL.gearN.fl_maple,r:'Rare',d:'+6% crit chance, +5% score',cr:.06,sc:1.05,t:'bow',c:'#c8502a',p:'archer',nw:1,hw:1,fl:1,w:1},
 fl_acorn:{n:FL.gearN.fl_acorn,r:'Epic',d:'Enemies 6% slower, fury +10%, +7% crit chance',sl:.94,fu:1.1,cr:.07,t:'mace',c:'#8a5a2a',p:'knight',nw:1,hw:1,fl:1,w:1},
 fl_glaive:{n:FL.gearN.fl_glaive,r:'Legendary',d:'Faster combos, fury +20%, +22% score',cq:1,fu:1.2,sc:1.22,t:'katana',c:'#d02040',p:'rogue',nw:1,hw:1,fl:1,w:1},
 fl_horn:{n:FL.gearN.fl_horn,r:'Mythic',d:'Slower foes, +45% score, fury +45%, faster combos, +8% crit',sl:.88,sc:1.45,fu:1.45,cq:1,cr:.08,t:'mace',c:'#e8b53a',h:40,p:'knight',nw:1,hw:1,fl:1,w:1}});
for(const id of FLG_A)AR[id].col=RC[AR[id].r];for(const id of FLG_W)WP[id].col=RC[WP[id].r];
AR.flfeast.col=FLG_COL;WP.fl_horn.col=FLG_COL;
Object.assign(AK,{
 flsmock:{mat:'cloth',leg:'cloth',helm:'flstraw',pauld:'soft',skirt:'kilt',cape:'',pat:'plain',flt:'smock',fx:'flchaff',tier:0},
 florch:{mat:'cloth',leg:'leather',helm:'florch',pauld:'strap',skirt:'kilt',cape:'',pat:'plain',flt:'orch',under:'#a8322a',aura:'florch',fx:'florch',tier:1},
 flmaple:{mat:'scale',leg:'leather',helm:'flmaple',pauld:'flmaple',skirt:'kilt',cape:'tatter',cc:'#7a1e10',emb:'flmaple',embc:'#ffd27a',fx:'flleaves',tier:2},
 flcorn:{mat:'plate',leg:'plate',helm:'flcob',pauld:'flhusk',skirt:'tassets',cape:'tatter',cc:'#4a6a22',emb:'flcorn',flt:'corn',fx:'flpollen',aura:'flcorn',tier:3},
 flmoon:{mat:'plate',leg:'plate',helm:'flmoon',crest:'flmoon',pauld:'lames',skirt:'tabard',tab:'#2a1f4a',cape:'galaxy',cc:'#22184a',emb:'flsheaf',fx:'flember',aura:'flmoon',tier:4},
 flfeast:{mat:'plate',leg:'plate',helm:'flfeast',crest:'flfeast',pauld:'flfeast',skirt:'tassets',cape:'royal',cc:'#8a1426',emb:'flcornu',embc:'#fff2b8',flt:'feast',fx:'flfeast',aura:'flfeast',tier:4}});

/* ---------- shared harvest drawing bits (also used by the weapons and the ability) ---------- */
const flgA=n=>Math.round(Math.max(0,Math.min(1,n))*255).toString(16).padStart(2,'0');
/* a maple leaf, tip up, about 2s tall, centred on (x,y) */
const FLG_MAPLE=[0,.55,.18,.42,.62,.52,.5,.3,.96,.05,.72,-.04,.84,-.4,.5,-.24,.42,-.52,.22,-.34,0,-1,-.22,-.34,-.42,-.52,-.5,-.24,-.84,-.4,-.72,-.04,-.96,.05,-.5,.3,-.62,.52,-.18,.42];
function flgMaple(g,x,y,s,rot,col,o){o=o||{};g.save();g.translate(x,y);g.rotate(rot||0);g.scale(s,s);
 g.beginPath();for(let i=0;i<FLG_MAPLE.length;i+=2)i?g.lineTo(FLG_MAPLE[i],FLG_MAPLE[i+1]):g.moveTo(FLG_MAPLE[i],FLG_MAPLE[i+1]);g.closePath();
 g.fillStyle=col;g.fill();if(!o.noOl){g.strokeStyle='#12081fcc';g.lineWidth=(o.ow||1.1)/s;g.stroke()}
 if(!o.flat){g.strokeStyle=o.vein||'#ffffff55';g.lineWidth=.7/s;g.beginPath();g.moveTo(0,.5);g.lineTo(0,-.78);g.moveTo(0,.3);g.lineTo(.7,-.26);g.moveTo(0,.3);g.lineTo(-.7,-.26);g.moveTo(0,.42);g.lineTo(.5,.36);g.moveTo(0,.42);g.lineTo(-.5,.36);g.stroke();
  g.strokeStyle=shade(col,-.45);g.lineWidth=1/s;g.beginPath();g.moveTo(0,.5);g.lineTo(0,.98);g.stroke()}
 g.restore()}
/* an apple (r = radius) */
function flgApple(g,x,y,r,col,o){o=o||{};col=col||'#d8322a';g.save();g.translate(x,y);
 g.beginPath();g.moveTo(0,-r*.62);g.bezierCurveTo(r*.5,-r*1.1,r*1.12,-r*.6,r*.98,r*.1);g.bezierCurveTo(r*.86,r*.86,r*.3,r*1.02,0,r*.84);g.bezierCurveTo(-r*.3,r*1.02,-r*.86,r*.86,-r*.98,r*.1);g.bezierCurveTo(-r*1.12,-r*.6,-r*.5,-r*1.1,0,-r*.62);g.closePath();
 g.fillStyle=rgr(g,-r*.35,-r*.3,r*.1,r*1.2,shade(col,.32),shade(col,-.28));g.fill();if(!o.noOl){g.strokeStyle='#12081fcc';g.lineWidth=o.ow||1;g.stroke()}
 g.fillStyle='#ffffff99';g.beginPath();g.ellipse(-r*.42,-r*.22,r*.16,r*.3,-.5,0,TAU);g.fill();
 g.strokeStyle='#4a2a10';g.lineWidth=Math.max(.8,r*.16);g.beginPath();g.moveTo(0,-r*.56);g.quadraticCurveTo(r*.06,-r*.9,r*.22,-r*1.08);g.stroke();
 if(!o.noLeaf){g.fillStyle='#5a9a2a';g.beginPath();g.moveTo(r*.1,-r*.82);g.quadraticCurveTo(r*.5,-r*1.3,r*.86,-r*1);g.quadraticCurveTo(r*.46,-r*.7,r*.1,-r*.82);g.fill();if(!o.noOl){g.strokeStyle='#12081f99';g.lineWidth=.7;g.stroke()}}
 g.restore()}
/* an acorn, cap up, r = half width */
function flgAcorn(g,x,y,r,rot,o){o=o||{};g.save();g.translate(x,y);g.rotate(rot||0);
 g.beginPath();g.moveTo(-r*.92,-r*.2);g.bezierCurveTo(-r*.98,r*.9,-r*.3,r*1.5,0,r*1.62);g.bezierCurveTo(r*.3,r*1.5,r*.98,r*.9,r*.92,-r*.2);g.closePath();
 g.fillStyle=rgr(g,-r*.3,r*.2,r*.1,r*1.5,o.nut2||'#e09a48',o.nut||'#8a4a1a');g.fill();g.strokeStyle='#12081fcc';g.lineWidth=o.ow||1;g.stroke();
 g.fillStyle='#ffffff66';g.beginPath();g.ellipse(-r*.4,r*.5,r*.14,r*.4,.2,0,TAU);g.fill();
 g.beginPath();g.moveTo(-r*1.08,-r*.1);g.quadraticCurveTo(-r*1.1,-r*.92,0,-r*.98);g.quadraticCurveTo(r*1.1,-r*.92,r*1.08,-r*.1);g.quadraticCurveTo(0,r*.18,-r*1.08,-r*.1);g.closePath();
 g.fillStyle=o.cap||'#7a5a34';g.fill();g.save();g.clip();g.strokeStyle='#3a2410aa';g.lineWidth=Math.max(.5,r*.1);for(let i=-3;i<=3;i++){g.beginPath();g.moveTo(i*r*.36-r*.5,-r);g.lineTo(i*r*.36+r*.5,r*.2);g.moveTo(i*r*.36+r*.5,-r);g.lineTo(i*r*.36-r*.5,r*.2);g.stroke()}g.restore();
 g.strokeStyle='#12081fcc';g.lineWidth=o.ow||1;g.stroke();
 g.strokeStyle='#4a3018';g.lineWidth=Math.max(.8,r*.22);g.beginPath();g.moveTo(0,-r*.9);g.lineTo(r*.18,-r*1.4);g.stroke();g.restore()}
/* an ear of wheat from (x0,y0) to the tip (x1,y1) */
function flgWheat(g,x0,y0,x1,y1,col,w){w=w||1;const dx=x1-x0,dy=y1-y0,L=Math.hypot(dx,dy)||1,ux=dx/L,uy=dy/L,nx=-uy,ny=ux;
 g.strokeStyle=shade(col,-.3);g.lineWidth=1.1*w;g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.stroke();
 const n=6,hl=L*.42;for(let i=0;i<n;i++){const u=1-hl/L+(i/n)*(hl/L)*.94,px=x0+dx*u,py=y0+dy*u,s=i%2?1:-1,gx=px+nx*s*1.5*w,gy=py+ny*s*1.5*w;
  g.save();g.translate(gx,gy);g.rotate(Math.atan2(uy,ux)+s*.42);g.fillStyle=i%2?col:shade(col,-.12);g.beginPath();g.ellipse(0,0,2.4*w,1.15*w,0,0,TAU);g.fill();g.strokeStyle='#12081f88';g.lineWidth=.5;g.stroke();
  g.strokeStyle=shade(col,.25);g.lineWidth=.45;g.beginPath();g.moveTo(2*w,0);g.lineTo(6*w,s*-.6*w);g.stroke();g.restore()}
 g.fillStyle=col;g.beginPath();g.ellipse(x1,y1,1.6*w,1*w,Math.atan2(uy,ux),0,TAU);g.fill()}
/* a pear */
function flgPear(g,x,y,r,col){col=col||'#c8c83a';g.save();g.translate(x,y);g.beginPath();g.moveTo(0,-r*1.2);g.bezierCurveTo(r*.5,-r*1.2,r*.42,-r*.36,r*.84,r*.2);g.bezierCurveTo(r*1.1,r*.9,r*.5,r*1.2,0,r*1.18);g.bezierCurveTo(-r*.5,r*1.2,-r*1.1,r*.9,-r*.84,r*.2);g.bezierCurveTo(-r*.42,-r*.36,-r*.5,-r*1.2,0,-r*1.2);g.closePath();
 g.fillStyle=rgr(g,-r*.3,r*.1,r*.1,r*1.3,shade(col,.35),shade(col,-.3));g.fill();g.strokeStyle='#12081fcc';g.lineWidth=1;g.stroke();g.fillStyle='#ffffff88';g.beginPath();g.ellipse(-r*.38,r*.2,r*.14,r*.34,.2,0,TAU);g.fill();
 g.strokeStyle='#4a2a10';g.lineWidth=Math.max(.8,r*.16);g.beginPath();g.moveTo(0,-r*1.14);g.lineTo(r*.16,-r*1.5);g.stroke();g.restore()}
/* a bunch of grapes, hanging down from (x,y) */
function flgGrapes(g,x,y,r,col){col=col||'#7a3aa8';g.save();g.translate(x,y);const B=[[0,0],[-1.6,.2],[1.6,.2],[-.8,1.4],[.8,1.4],[0,2.6],[-2.4,1.3],[2.4,1.3],[-1.5,2.6],[1.5,2.6],[0,3.8],[-.7,4.9],[.7,4.9]];
 for(let i=B.length-1;i>=0;i--){const [bx,by]=B[i];g.beginPath();g.arc(bx*r,by*r+r,r*.92,0,TAU);g.fillStyle=rgr(g,bx*r-r*.3,by*r+r*.7,r*.05,r,shade(col,.4),shade(col,-.25));g.fill();g.strokeStyle='#12081faa';g.lineWidth=.7;g.stroke()}
 g.fillStyle='#ffffffaa';for(const [bx,by] of B.slice(0,6))g.fillRect(bx*r-r*.45,by*r+r*.55,r*.3,r*.3);
 g.strokeStyle='#4a2a10';g.lineWidth=Math.max(.8,r*.3);g.beginPath();g.moveTo(0,0);g.lineTo(r*.4,-r*1.2);g.stroke();g.fillStyle='#5a9a2a';g.beginPath();g.moveTo(r*.3,-r*.8);g.quadraticCurveTo(r*1.8,-r*1.9,r*2.6,-r*.7);g.quadraticCurveTo(r*1.4,-r*.2,r*.3,-r*.8);g.fill();g.restore()}
/* a turkey tail feather along +x, length L, half width w: chestnut with black bars, a dark sub-tip band and a gold tip */
function flgFeather(g,L,w,o){o=o||{};const P=[0,-w*.3,L*.3,-w*.86,L*.72,-w,L*.95,-w*.66,L*1.03,0,L*.95,w*.66,L*.72,w,L*.3,w*.86,0,w*.3];
 const path=()=>arPP(g,P,1);path();g.fillStyle=hgr(g,0,L,o.base||'#3a200e',o.mid||'#a8642a');g.fill();
 g.save();path();g.clip();
 g.fillStyle=o.bar||'#1e100866';for(const u of[.5,.64])g.fillRect(L*u,-w-1,L*.03,w*2+2);
 g.fillStyle=o.dark||'#1a0c06';g.fillRect(L*.78,-w-1,L*.1,w*2+2);
 g.fillStyle=o.tip||'#ffd86a';g.fillRect(L*.88,-w-1,L*.2,w*2+2);g.fillStyle='#fff6d0aa';g.fillRect(L*.88,-w-1,L*.025,w*2+2);
 g.restore();
 path();g.strokeStyle='#12081fdd';g.lineWidth=o.ow||1.1;g.stroke();
 g.strokeStyle=o.shaft||'#f8e6b055';g.lineWidth=.7;g.beginPath();g.moveTo(1,0);g.lineTo(L*.76,0);g.stroke()}
/* fruit for the cornucopia (s = size, about 1 on the hero); flgFruitImg draws a sprite painted once, much cheaper each frame */
const FLG_FRUIT=['apple','pear','grapes','pumpkin','wheat','apple2'];
function flgFruit(g,k,x,y,s,t,rot){g.save();g.translate(x,y);g.rotate(rot||0);
 if(k==='apple')flgApple(g,0,0,3.2*s,'#e8322a',{ow:.8});else if(k==='apple2')flgApple(g,0,0,3*s,'#f0b030',{ow:.8,noLeaf:1});else if(k==='pear')flgPear(g,0,0,2.8*s,'#d0d84a');
 else if(k==='grapes')flgGrapes(g,0,-3*s,1.3*s,'#8a3ac8');else if(k==='pumpkin')hwPumpkin(g,0,0,3.6*s,t,{lit:false});else flgWheat(g,0,6*s,0,-7*s,'#f0c860',.8*s);
 g.restore()}
const FLG_FSPR={};
function flgFruitSpr(k){if(FLG_FSPR[k])return FLG_FSPR[k];const c=document.createElement('canvas');c.width=c.height=72;const g=c.getContext('2d');g.translate(36,36);g.lineJoin='round';g.lineCap='round';
 const OL0=OL;OL=0;try{flgFruit(g,k,0,0,6.4,1.3,0)}catch(e){}OL=OL0;return FLG_FSPR[k]=c}
/* the sprite holds a fruit of size 6.4 in 72 px: draw it at size s */
function flgFruitImg(g,k,x,y,s,rot){const z=72*s/6.4;g.save();g.translate(x,y);if(rot)g.rotate(rot);g.drawImage(flgFruitSpr(k),-z/2,-z/2,z,z);g.restore()}
/* a little crow: body at (x,y), s = scale, fl = wing phase -1..1, dir 1 = facing right */
function flgCrow(g,x,y,s,fl,dir){g.save();g.translate(x,y);g.scale(s*(dir||1),s);const u=fl*7;
 poly(g,[-1,-1,-7,-5-u,-14,-3-u*1.3,-9,-1,-5,1],'#1c1624','#000000aa',.8);
 poly(g,[-9,1,-15,-1,-14,3,-8,3],'#141018');ell(g,0,0,7,4.4,'#1e1828');ell(g,-2,-1.2,4.4,2,'#3a3448');
 poly(g,[1,-1,-3,-6-u*.8,-10,-6-u,-6,-1],'#2a2434','#000000aa',.8);
 ell(g,6,-2.6,3.3,3.1,'#1e1828');poly(g,[8.6,-3.4,13,-2.4,8.6,-1.4],'#e8a030','#000a',.6);ell(g,6.8,-3.4,.9,.9,'#ffe08a');ell(g,7,-3.4,.42,.42,'#000');g.restore()}

/* ---------- small hooks: torso overlays (K.flt) and custom pauldrons ---------- */
const FLT={},FLPD={},FLG_TORSO=[-17,-94,19,-94,18,-76,16,-46,-14,-46,-16,-76];
{const t0=arTorso;arTorso=function(g,K,c){t0.apply(this,arguments);const f=K&&FLT[K.flt];if(!f)return;
  g.save();arPP(g,FLG_TORSO);g.clip();try{f(g,K,c)}catch(e){}g.restore();g.strokeStyle='#000000b8';g.lineWidth=1.3;arPP(g,FLG_TORSO);g.stroke()}}
{const p0=arPauld;arPauld=function(g,K,c,x,y,front){const f=K&&FLPD[K.pauld];if(!f)return p0.apply(this,arguments);try{f(g,K,c,x,y,front,p0)}catch(e){}}}
const flgPlaid=(g,b,base,dk,ln,sz)=>{sz=sz||6;g.fillStyle=base;g.fillRect(b[0]-2,b[1]-2,b[2]-b[0]+4,b[3]-b[1]+4);g.fillStyle=dk;
 for(let x=b[0]-sz*2;x<b[2]+sz;x+=sz*2)g.fillRect(x,b[1]-2,sz,b[3]-b[1]+4);for(let y=b[1]-sz*2;y<b[3]+sz;y+=sz*2)g.fillRect(b[0]-2,y,b[2]-b[0]+4,sz);
 g.strokeStyle=ln;g.lineWidth=.6;g.beginPath();for(let x=b[0]-sz;x<b[2]+sz;x+=sz*2){g.moveTo(x+sz*.5,b[1]-2);g.lineTo(x+sz*.5,b[3]+2)}for(let y=b[1]-sz;y<b[3]+sz;y+=sz*2){g.moveTo(b[0]-2,y+sz*.5);g.lineTo(b[2]+2,y+sz*.5)}g.stroke()};
/* Common: burlap weave and a canvas apron with a carrot in its pocket */
FLT.smock=(g,K,c)=>{g.strokeStyle='#00000022';g.lineWidth=.7;g.beginPath();for(let x=-18;x<22;x+=2.4){g.moveTo(x,-95);g.lineTo(x,-45)}for(let y=-94;y<-45;y+=2.4){g.moveTo(-18,y);g.lineTo(22,y)}g.stroke();
 const ap='#efe2c0';arBev(g,[-6,-92,10,-92,11,-78,15,-76,16,-46,-13,-46,-12,-76,-7,-78],ap,{ow:1.1,edge:'#c8b48a',ew:1.4});
 g.save();g.setLineDash([1.8,1.6]);g.strokeStyle='#a08a5a';g.lineWidth=.8;g.strokeRect(-9.6,-73,18,10);g.restore();
 arBev(g,[-10,-74,9.6,-74,9.2,-62,-9.6,-62],shade(ap,-.08),{ow:1});
 poly(g,[3,-74,6.4,-74,4.8,-84],'#e8761c','#12081fbb',.9);g.strokeStyle='#c8540e';g.lineWidth=.6;g.beginPath();g.moveTo(3.8,-77);g.lineTo(5.6,-77.4);g.moveTo(4.2,-80);g.lineTo(5.4,-80.2);g.stroke();
 for(const a of[-.5,0,.5])limb(g,4.7,-84,4.7+Math.sin(a)*3.4,-88-Math.cos(a)*1.6,1.3,'#5aa02a');
 limb(g,-6,-92,-10,-95,1.6,'#c8b48a');limb(g,10,-92,14,-95,1.6,'#c8b48a');
 g.fillStyle='#a8322a';g.fillRect(-13,-50,29,2.2);g.fillStyle='#ffffff88';for(let x=-12;x<16;x+=3)g.fillRect(x,-50,1.2,1.1)};
/* Uncommon: a red buffalo-plaid flannel under a leather vest with brass buttons, an apple in the pocket */
FLT.orch=(g,K,c)=>{const {M,T}=c;flgPlaid(g,[-18,-95,22,-45],'#b0302a','#2a0c0ccc','#ffffff22',5.2);
 g.fillStyle=hgr(g,-17,19,'#ffffff18','#00000040');g.fillRect(-18,-95,40,50);
 arBev(g,[-17,-94,-5,-94,-1.6,-70,-4,-46,-14,-46,-16,-76],M,{ow:1.2,edge:shade(M,.25),ew:1.4});
 arBev(g,[19,-94,7.6,-94,5.6,-70,8,-46,16,-46,18,-76],shade(M,.06),{ow:1.2,edge:shade(M,.25),ew:1.4});
 for(const y of[-84,-74,-64,-54])rivet(g,7,y,1.3,T);
 arBev(g,[-14.4,-82,-6,-82,-6.4,-75,-14,-75],shade(M,-.12),{ow:.9});flgApple(g,-10,-84.4,3.6,'#e8402a',{ow:.8});
 g.save();g.setLineDash([1.4,1.4]);g.strokeStyle='#e8c890aa';g.lineWidth=.7;g.beginPath();g.moveTo(-15,-92);g.lineTo(-6.4,-92);g.lineTo(-2.8,-70);g.lineTo(-5.4,-48);g.moveTo(17,-92);g.lineTo(9,-92);g.lineTo(7,-70);g.lineTo(9.4,-48);g.stroke();g.restore()};
/* Epic: green-gold husk leaves wrap the golden cuirass */
FLT.corn=(g,K,c)=>{const H='#8ab04a',H2='#c8c868';
 const leaf=(pts,col)=>{arBev(g,hwTube(pts,u=>Math.sin(Math.PI*Math.min(1,u*1.05))*4.6+.4),col,{sm:1,ow:1.1});g.strokeStyle='#ffffff40';g.lineWidth=.7;g.beginPath();pts.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.stroke()};
 leaf([[-18,-92],[-10,-84],[-2,-72],[6,-60],[14,-48]],H);leaf([[22,-90],[14,-80],[8,-70],[2,-58],[-2,-46]],H2);
 g.fillStyle='#ffe07a';for(let i=0;i<5;i++){ell(g,-12+i*2.4,-60+i*.6,1,1.2,'#ffe07a')}};
/* Mythic: a cranberry velvet baldric with gold studs and fringe */
FLT.feast=(g,K,c)=>{const {T}=c;arBev(g,[13,-95,20,-95,-7,-46,-15,-46],'#8a1426',{ow:1.1,edge:'#ffd86a',ew:1.6});
 for(let i=0;i<5;i++){const u=.12+i*.19;rivet(g,16-u*29,-94+u*48,1.15,'#ffe08a')}
 g.strokeStyle='#fff2b855';g.lineWidth=.8;g.beginPath();for(const s of[-1,1]){g.moveTo(1+s*6,-90);g.quadraticCurveTo(1+s*10,-80,1+s*7,-68)}g.stroke()};

/* Rare: three maple leaves over a small leather cap */
FLPD.flmaple=(g,K,c,x,y,front)=>{const dm=v=>front?v:shade(v,-.26);arBevE(g,x,y+4.4,10.6,7,dm(shade(c.D,.2)),{ow:1.1});
 const L=[[x-6,y+3.4,7.6,-1.1,'#b8301a'],[x+6,y+3,7.6,1.05,'#e89a2a'],[x,y+.6,9.2,Math.sin(c.t*1.7)*.05,'#d8541e']];
 for(const [lx,ly,s,r,col] of L)flgMaple(g,lx,ly,s,r,dm(col),{ow:1.1});rivet(g,x,y+5,1.3,c.T)};
/* Epic: drooping husk leaves under a kernel cap */
FLPD.flhusk=(g,K,c,x,y,front)=>{const dm=v=>front?v:shade(v,-.26),sw=Math.sin(c.t*1.4)*.04;
 for(let i=0;i<4;i++){const a=-2.3+i*.48+sw,L=17-Math.abs(i-1.5)*2.2;g.save();g.translate(x,y+2);g.rotate(a+Math.PI);
  arBev(g,[0,-2.6,L*.4,-4.2,L,-.4,L*.4,3.6,0,2.6],dm(i%2?'#a8c05a':'#7aa040'),{sm:1,ow:1.1});g.strokeStyle='#ffffff40';g.lineWidth=.7;g.beginPath();g.moveTo(1,0);g.lineTo(L*.85,-.2);g.stroke();g.restore()}
 arBevE(g,x,y+1.6,9.6,7,dm('#e8c048'),{ow:1.1,tex:(g2,b)=>{g2.fillStyle='#a07818aa';for(let r=0;r<5;r++)for(let k=0;k<7;k++)g2.fillRect(b[0]+k*3+(r%2)*1.5,b[1]+r*2.9,1.2,.9)}});
 const gy=y-4;glow(g,x,gy,6,c.acc+'88');poly(g,[x,gy-3,x+2.3,gy,x,gy+3,x-2.3,gy],c.acc,'#000000a0',.9)};
/* Mythic: golden lames with three small feathers fanned behind */
let FLG_PF=null;
function flgPfSpr(){if(FLG_PF)return FLG_PF;const k=4,c=document.createElement('canvas');c.width=26*k;c.height=26*k;const g=c.getContext('2d');g.scale(k,k);g.translate(22,22);g.lineJoin='round';
 for(let i=0;i<3;i++){g.save();g.rotate(-2.2+i*.42);flgFeather(g,17-i*1.6,3.2,{mid:'#b8742a',base:'#5a3014',tip:'#ffe08a',ow:.9});g.restore()}return FLG_PF=c}
FLPD.flfeast=(g,K,c,x,y,front,p0)=>{g.save();if(!front)g.globalAlpha=.8;g.translate(x-1,y+2);g.rotate(Math.sin(c.t*1.3)*.03);g.drawImage(flgPfSpr(),-22,-22,26,26);g.restore();
 p0(g,Object.assign({},K,{pauld:'lames'}),c,x,y,front)};

/* ---------- HELMS ---------- */
/* Common: a farmhand under a frayed straw hat, a wheat straw in his teeth and a gingham bandana */
HWH.flstraw=(g,K,c,hx,hy,face)=>{const {t,acc}=c,hair='#6a3a1a',S0='#e8c870';
 arBevE(g,hx-6,hy+1,10.4,11.8,shade(hair,-.08),{ow:1.1});
 face(hx+3,hy+1.6,12.4,13.4);
 g.fillStyle='#e0806a55';g.beginPath();g.ellipse(hx+9.4,hy+6.4,3.2,2,0,0,TAU);g.fill();g.fillStyle='#9a503a';for(const [dx,dy] of[[7.4,4.4],[9.6,3.6],[11.4,5],[8.6,6.4]])g.fillRect(hx+dx,hy+dy,.9,.9);
 poly(g,[hx-4,hy-6,hx+3.6,hy-7,hx+1,hy-2.4,hx-2,hy+5],hair,'#000000a0',1);
 {const a=-.34+Math.sin(t*1.6)*.07;g.save();g.translate(hx+11.4,hy+8.6);g.rotate(a);g.strokeStyle='#b8862e';g.lineWidth=1.3;g.beginPath();g.moveTo(-1.6,0);g.lineTo(12,0);g.stroke();for(let i=0;i<4;i++)ell(g,12.4+i*1.7,(i%2?1:-1)*1,1.4,.75,'#ecc458');g.restore()}
 arBev(g,[hx-9.4,hy+11.6,hx+13,hy+11,hx+12.4,hy+15.6,hx+4,hy+20.4,hx-8.6,hy+16],acc,{sm:1,ow:1.1});
 g.fillStyle='#ffffffcc';for(const [dx,dy] of[[-5,14],[0,13.2],[5,14],[9,13.4],[2,17.4],[-2,16.4]])g.fillRect(hx+dx,hy+dy,1.1,1.1);
 poly(g,[hx-8,hy+14,hx-13,hy+17+Math.sin(t*3)*.8,hx-11,hy+20,hx-7,hy+17],shade(acc,-.12),'#000000a0',.9);
 /* the hat */
 arBevE(g,hx+1,hy-9.4,24.4,5.4,S0,{ow:1.2,edge:shade(S0,-.28),ew:1,tex:(g2,b)=>{g2.strokeStyle='#8a6a2a55';g2.lineWidth=.7;g2.beginPath();for(let a=0;a<TAU;a+=.22){g2.moveTo(hx+1+Math.cos(a)*9,hy-9.4+Math.sin(a)*2);g2.lineTo(hx+1+Math.cos(a)*25,hy-9.4+Math.sin(a)*5.6)}g2.stroke()}});
 g.strokeStyle='#d8b050';g.lineWidth=1;for(let i=0;i<11;i++){const a=Math.PI*(.05+i*.09),x=hx+1+Math.cos(a)*24,y=hy-9.4+Math.sin(a)*5.2;g.beginPath();g.moveTo(x,y);g.lineTo(x+Math.cos(a)*2.6+Math.sin(t*2+i)*.4,y+Math.sin(a)*2.2+1);g.stroke()}
 arBev(g,[hx-11,hy-10,hx-10,hy-19.4,hx-5.4,hy-23.6,hx+6,hy-23.8,hx+10.6,hy-19.4,hx+12.2,hy-10],shade(S0,.05),{sm:1,ow:1.2,tex:(g2,b)=>{g2.strokeStyle='#8a6a2a44';g2.lineWidth=.7;g2.beginPath();for(let y=b[1];y<b[3];y+=2.2){g2.moveTo(b[0],y);g2.lineTo(b[2],y+.6)}g2.stroke()}});
 g.strokeStyle='#8a6a2a88';g.lineWidth=1;g.beginPath();g.moveTo(hx-4,hy-22.4);g.quadraticCurveTo(hx+1,hy-19.6,hx+5,hy-22.6);g.stroke();
 arBev(g,[hx-11.2,hy-11,hx+12.4,hy-11,hx+12,hy-15.2,hx-10.8,hy-15.2],'#c8382a',{ow:1,tex:(g2,b)=>{g2.fillStyle='#ffffff66';for(let x=b[0];x<b[2];x+=2.4)for(let y=b[1];y<b[3];y+=2.4)if(((x-b[0])/2.4+(y-b[1])/2.4|0)%2)g2.fillRect(x,y,1.2,1.2)}});
 for(let i=0;i<3;i++)flgWheat(g,hx-8+i*1.4,hy-13,hx-17+i*2.6+Math.sin(t*1.8+i)*.8,hy-27-i*1.6,'#e8c058',.8)};

/* Uncommon: the orchard keeper, a bushy beard and a plaid flat cap with an apple sprig */
HWH.florch=(g,K,c,hx,hy,face)=>{const {t}=c,hair='#5a3418',bd='#6a3c1c';
 arBevE(g,hx-6,hy+1,10.6,11.8,hair,{ow:1.1});
 face(hx+3.4,hy+1.6,12.4,13.4);
 ell(g,hx-2.6,hy+2,2.6,3.4,'#e4b490');
 arBev(g,[hx-1.4,hy+1,hx+1.6,hy+9,hx+7,hy+13.4,hx+13,hy+12.6,hx+16.4,hy+8.6,hx+15.4,hy+5,hx+12,hy+8.4,hx+7,hy+7.4,hx+4,hy+3,hx+2.6,hy-1],bd,{sm:1,ow:1.1,tex:(g2,b)=>{g2.strokeStyle='#00000030';g2.lineWidth=.7;g2.beginPath();for(let x=b[0];x<b[2];x+=2)g2.moveTo(x,b[1]),g2.lineTo(x+1,b[3]);g2.stroke()}});
 arBev(g,[hx+8,hy+5.6,hx+12,hy+4,hx+16.8,hy+5.6,hx+16,hy+7.2,hx+12.2,hy+6.4,hx+9,hy+7.2],shade(bd,.12),{sm:1,ow:.9});
 ell(g,hx+15.4,hy+2.4,2.3,1.9,'#e89a80');g.fillStyle='#e0806a55';g.beginPath();g.ellipse(hx+10,hy+3.6,2.6,1.6,0,0,TAU);g.fill();
 /* the cap: puffy crown leaning forward, plaid, with a short brim */
 arBev(g,[hx-12.4,hy-5,hx-13.4,hy-13,hx-7.4,hy-20.6,hx+4,hy-22,hx+12.4,hy-18.6,hx+17,hy-12,hx+14,hy-8.6,hx+2,hy-7.6],'#5a4a30',{sm:1,ow:1.2,tex:(g2,b)=>{flgPlaid(g2,b,'#6a5236','#2a1e10aa','#e8c87a44',3);g2.fillStyle=vgr(g2,b[1],b[3],'#ffffff20','#00000040');g2.fillRect(b[0],b[1],b[2]-b[0],b[3]-b[1])}});
 arBev(g,[hx+7,hy-9.6,hx+20.6,hy-8.6,hx+22.4,hy-6,hx+18,hy-4.8,hx+8,hy-6.2],'#2a2016',{sm:1,ow:1.1});
 ell(g,hx+1,hy-21.4,2,1.3,'#2a2016');
 flgApple(g,hx-9,hy-15.6,3.6,'#e8402a',{ow:.9});
 {const s=Math.sin(t*2.2)*.12;g.save();g.translate(hx-7,hy-19);g.rotate(-.9+s);leafG(g,0,0,0,8,2.6,'#5a9a2a');g.restore()}};

/* Rare: a russet ranger hood crowned with a circlet of maple leaves */
HWH.flmaple=(g,K,c,hx,hy,face)=>{const {t,T}=c,hd='#6a2414';
 arBev(g,[hx-16,hy+21,hx-22,hy+2,hx-17,hy-15,hx-4,hy-23,hx+10,hy-20,hx+17.4,hy-8,hx+14.6,hy+4,hx+10,hy+12,hx+12,hy+22],hd,{sm:1,ow:1.3,tex:(g2,b)=>{g2.strokeStyle='#00000026';g2.lineWidth=1;for(let i=0;i<4;i++){g2.beginPath();g2.moveTo(hx-14+i*3,hy+20);g2.quadraticCurveTo(hx-19+i*3,hy,hx-12+i*5,hy-18);g2.stroke()}}});
 g.save();g.lineCap='round';g.strokeStyle='#ffb07a88';g.lineWidth=1.3;g.beginPath();g.moveTo(hx-19.4,hy+1);g.quadraticCurveTo(hx-19.6,hy-12,hx-8,hy-20.4);g.stroke();g.strokeStyle='#ffd8a044';g.lineWidth=.8;g.beginPath();g.moveTo(hx-16,hy+12);g.quadraticCurveTo(hx-19,hy+8,hx-19.6,hy+3);g.stroke();g.restore();
 face(hx+5,hy+2.2,11,12.6);
 g.save();g.beginPath();g.ellipse(hx+5,hy+2.2,11,12.6,0,0,TAU);g.clip();g.fillStyle='#1a060488';g.fillRect(hx-8,hy-12,28,9);g.restore();
 {const p=.7+.3*Math.sin(t*2.4);g.save();g.globalCompositeOperation='lighter';glow(g,hx+9.6,hy+1,6,'#ffa04a'+flgA(.3*p));g.restore()}
 arBev(g,[hx-19,hy-2,hx-16,hy-16,hx-3,hy-23,hx+10,hy-20,hx+18.4,hy-7.4,hx+15.6,hy-4,hx+10,hy-10.6,hx+2,hy-12.6,hx-6,hy-10,hx-12.4,hy-3],shade(hd,.12),{sm:1,ow:1.2});
 g.strokeStyle=T;g.lineWidth=1.5;g.beginPath();g.ellipse(hx+.6,hy-11.4,15.4,5.2,-.1,Math.PI*.98,Math.PI*2.02);g.stroke();
 const L=[[hx-13,hy-12.6,4.4,-.8,'#b8301a'],[hx-6.6,hy-17,5.4,-.36,'#e86a1e'],[hx+1.6,hy-19,6.4,.02,'#d8441a'],[hx+9.4,hy-16.8,5.4,.4,'#f0a030'],[hx+15,hy-12,4.2,.8,'#c8341a']];
 L.forEach(([x,y,s,r,col],i)=>flgMaple(g,x,y,s,r+Math.sin(t*1.9+i*1.3)*.05,col,{ow:1}));
 ell(g,hx+1.6,hy-14,1.5,1.5,T)};

/* Epic: a golden corn-cob helm, husk leaves swept back, silk tassels and an amber gaze */
HWH.flcob=(g,K,c,hx,hy)=>{const {t,acc}=c,sw=Math.sin(t*1.6)*.06;
 for(const [ox,a,L,w,col] of[[-4,-2.55,30,5.4,'#6a9a3a'],[0,-2.25,36,6,'#a8c058'],[3,-2.85,24,4.6,'#8ab04a']]){const pts=[];for(let i=0;i<=8;i++){const u=i/8,aa=a+sw+u*.55;pts.push([hx+ox+Math.cos(aa)*L*u,hy-12+Math.sin(aa)*L*u*.9])}
  arBev(g,hwTube(pts,u=>w*Math.sin(Math.PI*Math.min(1,u*.98+.06))+.3),col,{sm:1,ow:1.2});g.strokeStyle='#ffffff44';g.lineWidth=.7;g.beginPath();pts.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.stroke()}
 g.strokeStyle='#e8a868';g.lineWidth=.8;for(let i=0;i<7;i++){const a0=-1.9+i*.12;g.beginPath();g.moveTo(hx+3,hy-23);g.quadraticCurveTo(hx+3+Math.cos(a0)*10,hy-30,hx-6+Math.cos(a0)*16+Math.sin(t*2+i)*1.4,hy-24+i*1.4);g.stroke()}
 arBevE(g,hx+3,hy-4,14.4,20,'#ecc244',{ow:1.3,tex:(g2,b)=>{let r=0;for(let y=b[1];y<b[3]+3;y+=3.3,r++)for(let x=b[0]+(r%2)*1.6;x<b[2]+3;x+=3.2){g2.fillStyle=(r+x|0)%5?'#f6d058':'#d8a830';g2.beginPath();g2.ellipse(x,y,1.4,1.5,0,0,TAU);g2.fill();g2.fillStyle='#ffffffaa';g2.fillRect(x-.8,y-1,.7,.6)}g2.fillStyle=hgr(g2,b[0],b[2],'#ffffff26','#00000048');g2.fillRect(b[0],b[1],b[2]-b[0],b[3]-b[1])}});
 g.save();g.lineCap='round';g.strokeStyle='#fff6c8bb';g.lineWidth=1.5;g.beginPath();g.ellipse(hx+3,hy-4,12.4,18.2,0,Math.PI*1.05,Math.PI*1.45);g.stroke();g.strokeStyle='#7a5a1055';g.lineWidth=2.2;g.beginPath();g.ellipse(hx+3,hy-4,12.6,18.4,0,Math.PI*.05,Math.PI*.6);g.stroke();g.restore();
 /* the visor: a dark slit and a nasal bar, two amber eyes */
 arBev(g,[hx+3,hy-4,hx+18,hy-5.4,hx+17.6,hy-1,hx+3,hy-.4],'#1a1206',{ow:1.1});arBev(g,[hx+9.4,hy-5,hx+12.6,hy-5,hx+12.4,hy+9,hx+9.6,hy+9],'#3a2a0c',{ow:1});
 {const p=.75+.25*Math.sin(t*3);g.globalAlpha=p;eye(g,hx+15.4,hy-2.8,1.6,acc);eye(g,hx+6.6,hy-2.6,1.3,acc);g.globalAlpha=1}
 for(const [ox,a,L,col] of[[-10,-.4,26,'#7aa040'],[16,-2.6,22,'#a8c058']]){const pts=[];for(let i=0;i<=6;i++){const u=i/6;pts.push([hx+ox*(1-u*.4)+Math.cos(a)*2*u,hy+18-u*L*.9])}arBev(g,hwTube(pts,u=>3.6*Math.sin(Math.PI*Math.min(1,u+.1))+.4),col,{sm:1,ow:1.1})}
 arBev(g,[hx-12,hy+12,hx+17,hy+12,hx+15,hy+22,hx-10,hy+22],'#7a9a3a',{ow:1.2,edge:'#c8d878',ew:1})};

/* Legendary: a burnt-gold harvest helm with a crescent visor, wheat fanned behind like a halo */
HWH.flmoon=(g,K,c,hx,hy)=>{const {t,T,M,D,acc}=c;
 arBevE(g,hx+2,hy-1,15.8,17,M,{edge:T,ew:1.6});
 g.save();g.lineCap='round';g.strokeStyle='#fff0c8cc';g.lineWidth=1.6;g.beginPath();g.ellipse(hx+2,hy-1,13.4,15,0,Math.PI*1.08,Math.PI*1.5);g.stroke();g.strokeStyle='#fff0c866';g.lineWidth=.9;g.beginPath();g.ellipse(hx+2,hy-1,13.4,15,0,Math.PI*1.56,Math.PI*1.66);g.stroke();
 g.strokeStyle='#2a0e0466';g.lineWidth=2;g.beginPath();g.ellipse(hx+2,hy-1,13.6,15.2,0,Math.PI*.12,Math.PI*.72);g.stroke();g.fillStyle='#00000018';for(const [x,y,r] of[[-6,2,2.4],[-1,-5,1.6],[-9,-3,1.4]]){g.beginPath();g.arc(hx+x,hy+y,r,0,TAU);g.fill()}g.restore();
 arBev(g,[hx-14,hy-6,hx+17,hy-8,hx+17.6,hy-12.4,hx-13.4,hy-11],T,{ow:1.1,tex:(g2,b)=>{g2.strokeStyle='#8a5a1a99';g2.lineWidth=.7;g2.beginPath();for(let x=b[0]+2;x<b[2];x+=3.4){g2.moveTo(x,b[3]);g2.lineTo(x+1.6,b[1])}g2.stroke()}});
 arBev(g,[hx+5,hy-7,hx+15,hy-8.4,hx+19.6,hy-3.6,hx+20.4,hy+5,hx+16.6,hy+13.4,hx+10,hy+16.6,hx+5,hy+12.6],shade(M,.1),{sm:1,edge:T,ew:1.5});
 {const p=.7+.3*Math.sin(t*2.6);g.save();g.globalCompositeOperation='lighter';glow(g,hx+13,hy-1,10,acc+flgA(.5*p));g.restore();
  g.fillStyle=p>.85?'#fff4c0':'#ffd060';g.beginPath();g.arc(hx+13,hy-1.4,4.4,Math.PI*.15,Math.PI*1.1);g.arc(hx+14.6,hy-2.6,3.6,Math.PI*1.05,Math.PI*.2,true);g.closePath();g.fill()}
 g.fillStyle='#1a0a04';for(let i=0;i<3;i++){g.beginPath();g.roundRect(hx+12.6+i*2.2,hy+5.6,1.1,5.4-Math.abs(i-1)*1.2,.5);g.fill()}
 for(const [x,y] of[[hx+8,hy-3],[hx+8,hy+12],[hx-10,hy-8.6],[hx-2,hy-9.4]])rivet(g,x,y,1.2,T);
 g.strokeStyle=T;g.lineWidth=1.3;g.beginPath();g.moveTo(hx-6,hy+2);g.quadraticCurveTo(hx-3,hy+10,hx+4,hy+14);g.stroke();
 /* a gold crescent finial */
 {const cx=hx+1,cy=hy-21;glow(g,cx,cy,10,acc+'66');g.fillStyle=T;g.beginPath();g.arc(cx,cy,4.8,Math.PI*.3,Math.PI*1.7);g.arc(cx+2.4,cy,3.8,Math.PI*1.6,Math.PI*.4,true);g.closePath();g.fill();g.strokeStyle='#4a2a08';g.lineWidth=.9;g.stroke()}
 arBev(g,[hx-12,hy+11,hx+14,hy+12,hx+15,hy+22,hx-10,hy+22],shade(M,-.2),{ow:1.2,edge:T,ew:1.2})};
let FLG_WH=null;
function flgWheatHalo(){if(FLG_WH)return FLG_WH;const k=3,w=80,h=56,c=document.createElement('canvas');c.width=w*k;c.height=h*k;const g=c.getContext('2d');g.scale(k,k);g.translate(40,50);g.lineCap='round';
 for(let i=0;i<9;i++){const a=-Math.PI*.5+(i-4)*.2,L=26+(4-Math.abs(i-4))*2.4,x0=Math.cos(a)*10,y0=Math.sin(a)*10+2;flgWheat(g,x0,y0,x0+Math.cos(a)*L,y0+Math.sin(a)*L,i%2?'#f0c860':'#e0a840',1)}return FLG_WH=c}
HWC.flmoon=(g,K,c,hx,hy)=>{const {t,acc}=c;g.save();g.globalCompositeOperation='lighter';glow(g,hx-2,hy-14,36,acc+'30');g.restore();
 g.save();g.translate(hx-2,hy-10);g.rotate(Math.sin(t*1.3)*.025);g.drawImage(flgWheatHalo(),-40,-50,80,56);g.restore()};

/* the Feastlord's harvest crown, painted once: a gold band, gilded leaves, two acorns and a cranberry gem (36 x 24 units, head at 16,34) */
let FLG_CR=null;
function flgCrownSpr(){if(FLG_CR)return FLG_CR;const k=4,c=document.createElement('canvas');c.width=36*k;c.height=24*k;const g=c.getContext('2d');g.scale(k,k);g.translate(16,34);g.lineJoin='round';g.lineCap='round';
 const OL0=OL;OL=1.3;const G='#f2c24a',yb=-13.4,x0=-12,x1=15;
 arBev(g,[x0,yb+3.4,x1,yb+2.6,x1+.4,yb-2,x0-.4,yb-1.2],G,{ow:1.1,edge:'#fff6c8',ew:1});
 const pts=[[0,'leaf',10],[1,'acorn',0],[2,'leaf',14],[3,'gem',0],[4,'leaf',14],[5,'acorn',0],[6,'leaf',10]];
 for(const [i,kd,h] of pts){const x=x0+(x1-x0)*(i+.5)/7,y=yb-1;
  if(kd==='leaf'){g.save();g.translate(x,y);g.rotate((i-3)*.08);arBev(g,[-3.4,0,-2.4,-h*.55,0,-h,2.4,-h*.55,3.4,0],i%2?'#ffe07a':G,{sm:0,ow:1});g.strokeStyle='#a8741a';g.lineWidth=.6;g.beginPath();g.moveTo(0,-1);g.lineTo(0,-h*.8);g.stroke();g.restore()}
  else if(kd==='acorn')flgAcorn(g,x,y-4,2.4,0,{nut:'#c88a2a',nut2:'#ffe08a',cap:'#8a5a1a',ow:.8});
  else{arBev(g,[x-3.6,y,x,y-15,x+3.6,y],'#ffe07a',{ow:1});gem(g,x,y-7,3.2,'#e81e3a')}}
 OL=OL0;return FLG_CR=c}
/* Mythic: the Feastlord's golden great helm under a harvest crown of gilded leaves, acorns and a cranberry gem */
HWH.flfeast=(g,K,c,hx,hy)=>{const {t,T,M,acc}=c,G='#f2c24a';
 arBevE(g,hx+2,hy-.6,15.8,17,M,{edge:'#fff0b0',ew:1.6,tex:(g2,b)=>{g2.strokeStyle='#8a5a1a66';g2.lineWidth=.7;g2.beginPath();g2.moveTo(hx-12,hy+4);g2.quadraticCurveTo(hx-6,hy-2,hx-9,hy-10);g2.moveTo(hx-9,hy+8);g2.quadraticCurveTo(hx-2,hy+2,hx-4,hy-8);g2.stroke()}});
 g.save();g.lineCap='round';g.strokeStyle='#fff8d8dd';g.lineWidth=1.8;g.beginPath();g.ellipse(hx+2,hy-.6,13.4,15,0,Math.PI*1.06,Math.PI*1.5);g.stroke();g.strokeStyle='#8a5a1a88';g.lineWidth=2;g.beginPath();g.ellipse(hx+2,hy-.6,13.6,15.2,0,Math.PI*.1,Math.PI*.7);g.stroke();
 g.strokeStyle='#fff0b0aa';g.lineWidth=1;g.beginPath();g.moveTo(hx-3,hy-15);g.quadraticCurveTo(hx-5,hy,hx-3,hy+14);g.stroke();g.restore();
 arBev(g,[hx+3.6,hy-9.6,hx+13.6,hy-10.8,hx+19.4,hy-5.6,hx+20.8,hy+3.6,hx+17.6,hy+12.6,hx+10.6,hy+17,hx+4.4,hy+13.4],shade(M,.12),{sm:1,edge:'#fff0b0',ew:1.5});
 g.strokeStyle='#fff6d0aa';g.lineWidth=1;g.beginPath();g.moveTo(hx+14.4,hy-9.6);g.quadraticCurveTo(hx+17.4,hy+2,hx+14.6,hy+14);g.stroke();
 {const p=.75+.25*Math.sin(t*3.1);g.save();g.globalCompositeOperation='lighter';glow(g,hx+13,hy-2,11,'#ffb040'+flgA(.55*p));g.restore();
  g.fillStyle='#2a1004';g.beginPath();g.moveTo(hx+5.6,hy-4.2);g.quadraticCurveTo(hx+13,hy-6.6,hx+20.4,hy-4.8);g.lineTo(hx+20.6,hy-1.4);g.quadraticCurveTo(hx+13,hy-3.2,hx+5.8,hy-.8);g.closePath();g.fill();g.strokeStyle='#12081fcc';g.lineWidth=.9;g.stroke();
  g.globalAlpha=p;eye(g,hx+16.4,hy-3.2,1.6,'#ffcf5a');eye(g,hx+10,hy-2.6,1.3,'#ffcf5a');g.globalAlpha=1}
 g.fillStyle='#4a2a08';for(let i=0;i<4;i++){g.beginPath();g.roundRect(hx+9.2+i*2.5,hy+3.4,1.2,6.6-Math.abs(i-1.5)*1.2,.6);g.fill()}
 for(const [x,y] of[[hx+7,hy+14],[hx+18,hy+3]])rivet(g,x,y,1.2,'#fff0b0');
 /* gorget */
 arBev(g,[hx-12,hy+11,hx+14,hy+12,hx+15,hy+22,hx-10,hy+22],shade(M,-.18),{ow:1.2,edge:'#fff0b0',ew:1.2});
 /* the harvest crown: painted once (flgCrownSpr), the gem's glow pulses live */
 const yb=hy-13.4,x0=hx-12,x1=hx+15,gx=x0+(x1-x0)*3.5/7;
 g.save();g.globalCompositeOperation='lighter';glow(g,gx,yb-10,10,'#ff4a5a'+flgA(.45+.25*Math.sin(t*2.6)));g.restore();
 g.drawImage(flgCrownSpr(),hx-16,hy-34,36,24);
 for(let i=0;i<3;i++){const u=(t*.35+i/3)%1,x=x0+(x1-x0)*(.2+.3*i);g.globalAlpha=Math.sin(u*Math.PI);g.fillStyle='#fff6c8';g.fillRect(x-.5,yb-14-u*10,1.1,3.2);g.fillRect(x-1.6,yb-12.4-u*10,3.2,1.1)}g.globalAlpha=1};
HWC.flfeast=(g,K,c,hx,hy)=>{const {t}=c;g.save();g.translate(hx+1,hy-14);g.globalCompositeOperation='lighter';glow(g,0,0,40,'#ffc84a33');g.rotate(t*.15);g.fillStyle='#fff0b01c';
 for(let i=0;i<12;i++){g.rotate(TAU/12);g.beginPath();g.moveTo(-2.6,-14);g.lineTo(0,-38-(i%2)*8);g.lineTo(2.6,-14);g.closePath();g.fill()}g.restore()};

/* ---------- FX (rise(n,fn) gives each particle a looping 0..1 phase) ---------- */
HWFX.flchaff=(g,K,c,rise)=>{const {t}=c;rise(5,(i,u)=>{const x=Math.sin(i*5.3+t*.6)*26,y=-128+u*104;g.save();g.translate(x,y);g.rotate(t*1.4+i);g.globalAlpha=Math.sin(u*Math.PI)*.85;g.strokeStyle=i%2?'#ecc858':'#c8a030';g.lineWidth=1.3;g.beginPath();g.moveTo(-3,0);g.lineTo(3,0);g.stroke();g.restore()});g.globalAlpha=1};
HWFX.florch=(g,K,c,rise)=>{const {t}=c;rise(3,(i,u)=>{const x=Math.sin(i*4.1+t*.7)*30+u*8,y=-132+u*112;g.save();g.translate(x,y);g.rotate(Math.sin(t*2+i)*1.2);g.globalAlpha=Math.sin(u*Math.PI)*.9;leafG(g,-3,0,0,6.4,2.2,['#8ab040','#e8b030','#d8642a'][i%3]);g.restore()});g.globalAlpha=1};
HWFX.flleaves=(g,K,c,rise)=>{const {t}=c;rise(5,(i,u)=>{const x=Math.sin(i*3.7+t*.6)*32+Math.sin(u*9+i)*5,y=-136+u*124;g.globalAlpha=Math.sin(u*Math.PI)*.95;flgMaple(g,x,y,2.6+i%2,t*1.6+i*1.3,['#d8441a','#f0a030','#b8301a','#e86a1e','#ffc040'][i],{ow:.7,flat:1})});g.globalAlpha=1};
HWFX.flpollen=(g,K,c,rise)=>{const {t,acc}=c;rise(8,(i,u)=>{const x=Math.sin(i*4.4+t*.9)*28,y=-40-u*100;g.globalAlpha=Math.sin(u*Math.PI)*.9;if(i%4===0){g.save();g.translate(x,y);g.rotate(t+i);leafG(g,-2.6,0,0,5.4,1.6,'#c8c868');g.restore()}else{glow(g,x,y,5,acc+'88');ell(g,x,y,1.1,1.1,'#fff6c0')}});g.globalAlpha=1};
HWFX.flember=(g,K,c,rise)=>{const {t}=c;rise(8,(i,u)=>{const x=Math.sin(i*4.1+t*1.1)*22+4,y=-104-u*60;g.globalAlpha=Math.sin(u*Math.PI)*.95;ell(g,x,y,1.5*(1-u)+.5,1.5*(1-u)+.5,i%2?'#ffd060':'#ff8a2a')});
 rise(3,(i,u)=>{const x=Math.sin(i*5.9+t*.5)*36,y=-140+u*130;g.globalAlpha=Math.sin(u*Math.PI)*.9;flgMaple(g,x,y,2.8,t*1.4+i*2,['#e86a1e','#ffc040','#c8341a'][i],{ow:.7,flat:1})});g.globalAlpha=1};
HWFX.flfeast=(g,K,c,rise)=>{const {t}=c;rise(5,(i,u)=>{const x=Math.sin(i*3.3+t*.5)*38+Math.sin(u*8+i)*4,y=-150+u*140;g.globalAlpha=Math.sin(u*Math.PI)*.95;flgMaple(g,x,y,2.8+(i%2)*.6,t*1.3+i*1.7,i%2?'#ffd86a':'#f0a030',{ow:.7,flat:1})});
 rise(6,(i,u)=>{const x=Math.sin(i*5.7+t)*26,y=-60-u*90,s=(1-u)*2.4+.6;g.globalAlpha=Math.sin(u*Math.PI);g.fillStyle='#fff6c8';g.fillRect(x-.5,y-s*1.6,1,s*3.2);g.fillRect(x-s*1.6,y-.5,s*3.2,1)});g.globalAlpha=1};

/* ---------- AURAS (post=0 behind the hero, post=1 in front) ---------- */
/* Uncommon: a wicker basket of apples on the back (not a glow: a prop) */
HWA.florch=(g,K,c,post)=>{if(post)return;const {t}=c;g.save();g.translate(-17,-80);g.rotate(-.12);
 for(const [x,y,col] of[[-6,-17,'#e8402a'],[1,-18.4,'#d8322a'],[7,-16.6,'#f0602a'],[-2,-14,'#c82a24'],[4.6,-13.6,'#e8b030']])flgApple(g,x,y,4,col,{ow:.9,noLeaf:col==='#e8b030'});
 arBev(g,[-12,-14,12,-14,10,12,-10,12],'#a8783a',{ow:1.2,tex:(g2,b)=>{g2.strokeStyle='#5a3a14aa';g2.lineWidth=.8;g2.beginPath();for(let y=b[1]+2;y<b[3];y+=3.2){g2.moveTo(b[0],y);g2.lineTo(b[2],y)}for(let x=b[0]+2;x<b[2];x+=3){g2.moveTo(x,b[1]);g2.lineTo(x,b[3])}g2.stroke()}});
 arBev(g,[-13,-16,13,-16,13,-12,-13,-12],'#c8944a',{ow:1.1});g.restore()};
/* Epic: two cornstalks sway behind the sentinel; crows circle */
function flgStalk(g,bx,h,t,ph,ear){const sw=Math.sin(t*1.2+ph)*4,X=u=>bx+sw*u*u,Y=u=>-h*u,pts=[];for(let i=0;i<=8;i++){const u=i/8;pts.push([X(u),Y(u)])}
 for(let i=0;i<5;i++){const u=.16+i*.15,s=i%2?1:-1,x0=X(u),y0=Y(u),L=30-i*3.4,dr=Math.sin(t*1.5+i+ph)*.06,lp=[];for(let k=0;k<=6;k++){const v=k/6,a=-Math.PI/2+s*(.5+v*1.25+dr);lp.push([x0+s*Math.sin(v*1.4)*L*.75,y0-Math.sin(v*2.2)*L*.34+v*v*L*.42])}
  arBev(g,hwTube(lp,v=>3.2*Math.sin(Math.PI*Math.min(1,v*.92+.08))+.3),['#b8a848','#8aa040','#d0b860'][i%3],{sm:1,ow:1});g.strokeStyle='#ffffff38';g.lineWidth=.6;g.beginPath();lp.forEach((p,k)=>k?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.stroke()}
 arBev(g,hwTube(pts,u=>2.8*(1-u*.5)+.4),'#a89a3a',{sm:0,ow:1.1});
 g.strokeStyle='#5a4a14';g.lineWidth=1;for(const u of[.24,.46,.68,.86]){g.beginPath();g.moveTo(X(u)-2.6,Y(u));g.lineTo(X(u)+2.6,Y(u)-.6);g.stroke()}
 if(ear){const u=.5,ex=X(u)+3.4,ey=Y(u)+2;g.save();g.translate(ex,ey);g.rotate(.42);arBevE(g,0,-6,3.4,8.6,'#f2c848',{ow:1,tex:(g2,b)=>{g2.fillStyle='#b8861c';for(let r=0;r<7;r++)for(let k=0;k<3;k++)g2.fillRect(b[0]+1+k*2.2+(r%2),b[1]+1.4+r*2.2,1,1)}});
  arBev(g,[-4,4,-6,-6,-2.4,-10,-1,2],'#8ab04a',{sm:1,ow:.9});arBev(g,[4,4,6.4,-4,2.4,-11,1,2],'#a8c058',{sm:1,ow:.9});g.restore()}
 const tx=X(1),ty=Y(1);g.strokeStyle='#d8b060';g.lineWidth=1.1;for(let i=0;i<7;i++){const a=-Math.PI/2+(i-3)*.3,L=8+(i%2)*3;g.beginPath();g.moveTo(tx,ty);g.quadraticCurveTo(tx+Math.cos(a)*L*.6,ty+Math.sin(a)*L*.6,tx+Math.cos(a)*L+Math.sin(t*2+i)*.6,ty+Math.sin(a)*L+L*.5);g.stroke()}
 g.fillStyle='#f0d070';for(let i=0;i<5;i++)ell(g,tx+(i-2)*2.2,ty-2-Math.abs(i-2)*-.8,.9,1.4,'#f0d070')}
const FLG_ST={};
function flgStalkSpr(h,ear){const key=h+':'+ear;if(FLG_ST[key])return FLG_ST[key];const k=3,w=96,c=document.createElement('canvas');c.width=w*k;c.height=(h+24)*k;const g=c.getContext('2d');g.scale(k,k);g.translate(w/2,h+8);g.lineJoin='round';g.lineCap='round';
 flgStalk(g,0,h,0,-Math.PI/2.4,ear);return FLG_ST[key]={c,w,h:h+24,oy:h+8}}
HWA.flcorn=(g,K,c,post,hx,hy,orb)=>{const {t,acc}=c;
 if(!post){glow(g,-4,-90,86,acc+'24');for(const [bx,h,ph,ear] of[[-40,152,0,1],[34,138,2,0]]){const S2=flgStalkSpr(h,ear);g.save();g.translate(bx,0);g.rotate(Math.sin(t*1.2+ph)*.022);g.drawImage(S2.c,-S2.w/2,-S2.oy,S2.w,S2.h);g.restore()}}
 orb(2,-2,-104,54,16,.9,(x,y,i,a,z)=>{flgCrow(g,x,y,.85+z*.15,Math.sin(t*12+i*2.4),Math.cos(a)<0?1:-1)})};
/* Legendary: the harvest moon rises behind, geese cross it, harvest lanterns circle */
HWA.flmoon=(g,K,c,post,hx,hy,orb)=>{const {t,acc}=c;
 if(!post){glow(g,-6,-104,104,'#ff9a2a38');
  ell(g,-6,-106,36,36,rgr(g,-16,-118,3,44,'#fff2c0','#e07a24'));g.globalAlpha=.26;for(const [x,y,r] of[[-17,-115,6],[4,-96,7.6],[-14,-92,4],[8,-114,3.2]])ell(g,x,y,r,r,'#a8461a');g.globalAlpha=1;
  g.strokeStyle='#ffd27a88';g.lineWidth=1.6;g.beginPath();g.arc(-6,-106,36,0,TAU);g.stroke();
  {const u=(t*.07)%1,gx=-70+u*140,gy=-146+u*10;g.globalAlpha=Math.sin(u*Math.PI);g.strokeStyle='#1a0c1c';g.lineWidth=1.3;for(const [dx,dy] of[[0,0],[-6,4],[-12,8],[-6,-4],[-12,-8]]){const f=Math.sin(t*8+dx)*1.6;g.beginPath();g.moveTo(gx+dx-3,gy+dy-f);g.lineTo(gx+dx,gy+dy);g.lineTo(gx+dx+3,gy+dy-f);g.stroke()}g.globalAlpha=1}}
 orb(3,-2,-82,48,15,.8,(x,y,i,a,z)=>{const s=.85+z*.18,sw=Math.sin(t*2+i)*.1;g.save();g.translate(x,y);g.rotate(sw);g.scale(s,s);glow(g,0,0,16,'#ffa03a77');
  arBev(g,[-4.4,-5,4.4,-5,5.4,0,4.4,5,-4.4,5,-5.4,0],'#ff8a2a',{sm:1,ow:1});g.strokeStyle='#a83a0a88';g.lineWidth=.7;g.beginPath();g.moveTo(0,-5);g.lineTo(0,5);g.moveTo(-3,-4.6);g.quadraticCurveTo(-4.4,0,-3,4.6);g.moveTo(3,-4.6);g.quadraticCurveTo(4.4,0,3,4.6);g.stroke();
  ell(g,0,0,2,3,'#fff0a0');g.fillStyle='#3a2410';g.fillRect(-2.6,-6.6,5.2,1.8);g.fillRect(-2.6,4.8,5.2,1.8);g.strokeStyle='#3a2410';g.lineWidth=.7;g.beginPath();g.moveTo(0,-6.6);g.lineTo(0,-10);g.stroke();g.restore()})};
/* Mythic: a fanned turkey-feather mantle (painted once into a sprite), a golden radiance and orbiting fruit-light */
const FLG_FAN={c:null,k:3,w:172,h:100,ox:86,oy:86,N:11};
const flgFanA=i=>-Math.PI*(1.02-i/(FLG_FAN.N-1)*1.04),flgFanL=i=>70-Math.abs(i/(FLG_FAN.N-1)-.5)*26;
function flgFanSprite(){if(FLG_FAN.c)return FLG_FAN.c;const F=FLG_FAN,c=document.createElement('canvas');c.width=F.w*F.k;c.height=F.h*F.k;const g=c.getContext('2d');g.scale(F.k,F.k);g.translate(F.ox,F.oy);g.lineJoin='round';g.lineCap='round';
 for(let i=0;i<F.N;i++){g.save();g.rotate(flgFanA(i));flgFeather(g,flgFanL(i),9.6,{ow:1.3});g.restore()}
 for(let i=0;i<8;i++){const u=i/7;g.save();g.rotate(-Math.PI*(.96-u*.92));flgFeather(g,42-Math.abs(u-.5)*8,7.4,{base:'#24160a',mid:'#6a4a1e',bar:'#00000000',dark:'#3a2a10',tip:'#c8862a',ow:1.2});g.restore()}
 return FLG_FAN.c=c}
HWA.flfeast=(g,K,c,post,hx,hy,orb)=>{const {t}=c;
 if(!post){g.save();g.globalCompositeOperation='lighter';glow(g,-6,-98,100,'#ffb43a38');g.restore();
  const F=FLG_FAN,sp=flgFanSprite(),br=Math.sin(t*1.6);g.save();g.translate(-7,-90);g.scale(1+.025*br,1+.04*br);g.rotate(Math.sin(t*.9)*.02);g.drawImage(sp,-F.ox,-F.oy,F.w,F.h);
   for(let k=0;k<3;k++){const i=(Math.floor(t*.8)*5+k*4)%F.N,u=(t*.8)%1,a=flgFanA(i),L=flgFanL(i)*1.0,x=Math.cos(a)*L,y=Math.sin(a)*L,s=Math.sin(u*Math.PI)*3.4+.4;g.fillStyle='#fffbe0';g.globalAlpha=Math.sin(u*Math.PI);g.fillRect(x-.6,y-s*1.6,1.2,s*3.2);g.fillRect(x-s*1.6,y-.6,s*3.2,1.2)}g.globalAlpha=1;g.restore()}
 orb(4,-2,-90,62,18,.7,(x,y,i,a,z)=>{const s=.9+z*.2;g.save();g.globalCompositeOperation='lighter';glow(g,x,y,14*s,['#ff5a3a','#c8e04a','#b06aff','#ff9a2a'][i]+'88');g.restore();
  flgFruitImg(g,['apple','pear','grapes','pumpkin'][i],x,y,1.3*s,Math.sin(t+i)*.2)})};

/* ---------- emblem glyphs (about 18 units, centred) ---------- */
const flgGl=(g,col,fill,fn)=>{g.beginPath();fn();g.strokeStyle='#000000b0';g.lineWidth=3.6;g.stroke();if(fill){g.fillStyle=col;g.fill()}g.strokeStyle=col;g.lineWidth=fill?1:1.9;g.stroke()};
HWG.flmaple=(g,col)=>{flgGl(g,col,1,()=>{for(let i=0;i<FLG_MAPLE.length;i+=2){const x=FLG_MAPLE[i]*9,y=FLG_MAPLE[i+1]*9-1;i?g.lineTo(x,y):g.moveTo(x,y)}g.closePath()});g.strokeStyle='#5a1a08';g.lineWidth=1;g.beginPath();g.moveTo(0,4);g.lineTo(0,-6);g.moveTo(0,2);g.lineTo(5,-3);g.moveTo(0,2);g.lineTo(-5,-3);g.moveTo(0,4);g.lineTo(0,9);g.stroke()};
HWG.flcorn=(g,col)=>{flgGl(g,col,1,()=>{g.ellipse(0,-1,4.6,9,0,0,TAU)});g.fillStyle='#8a5a10';for(let y=-7;y<7;y+=2.6)for(let x=-3;x<4;x+=2.4)g.fillRect(x-.5,y,1,1);
 flgGl(g,'#8ab04a',1,()=>{g.moveTo(-2,9);g.quadraticCurveTo(-9,4,-8,-6);g.quadraticCurveTo(-5,2,-.4,5);g.closePath()});flgGl(g,'#8ab04a',1,()=>{g.moveTo(2,9);g.quadraticCurveTo(9,4,8,-6);g.quadraticCurveTo(5,2,.4,5);g.closePath()})};
HWG.flsheaf=(g,col)=>{g.save();for(const a of[-.5,-.25,0,.25,.5]){g.save();g.rotate(a);flgGl(g,col,1,()=>{g.ellipse(0,-6.4,1.8,4,0,0,TAU)});g.strokeStyle='#000000b0';g.lineWidth=2.6;g.beginPath();g.moveTo(0,-2.4);g.lineTo(0,9);g.stroke();g.strokeStyle=col;g.lineWidth=1;g.stroke();g.restore()}
 flgGl(g,'#a83a1a',1,()=>{g.rect(-4.6,1.4,9.2,3)});g.restore()};
HWG.flcornu=(g,col)=>{flgGl(g,col,1,()=>{g.moveTo(-9,-6);g.quadraticCurveTo(-6,6,6,5.4);g.lineTo(8,-2);g.quadraticCurveTo(-1,0,-9,-6);g.closePath()});
 g.fillStyle='#e8322a';g.beginPath();g.arc(7.6,-.4,2.4,0,TAU);g.fill();g.fillStyle='#8a3ac8';g.beginPath();g.arc(5.6,3.6,1.6,0,TAU);g.arc(7.6,4.4,1.6,0,TAU);g.fill();g.fillStyle='#c8d84a';g.beginPath();g.arc(9.6,2.2,1.7,0,TAU);g.fill();
 g.strokeStyle='#8a5a1a';g.lineWidth=.8;g.beginPath();for(const x of[-4,-.5,3]){g.moveTo(x,-3+x*.2);g.lineTo(x+1,4.4)}g.stroke()};

/* ---------- ownership, granting and the shop purchase ---------- */
const flgItems=()=>FLG_A.map(id=>({kind:'a',id})).concat(FLG_W.map(id=>({kind:'w',id})));
const flgOwn=(kind,id)=>kind==='a'?!!(P.ownA&&P.ownA[id]):!!(P.own&&P.own[id]);
const flgCount=()=>flgItems().filter(it=>flgOwn(it.kind,it.id)).length;
/* grants one harvest relic (kind 'a' or 'w'); returns true if it was new */
function flgGive(kind,id){const T=kind==='a'?AR:WP,o=kind==='a'?'ownA':'own';if(!T[id]||!T[id].fl)return false;if(!P[o])P[o]={};if(P[o][id])return false;P[o][id]=1;try{save()}catch(e){}return true}
const flgPriceOf=k=>(FL.price||{})[k]||0;
/* why a purchase cannot happen right now ('' = it can) */
function flgWhyNot(k){if(!flShopOn())return'ended';const oa=flgOwn('a','flfeast'),ow=flgOwn('w','fl_horn');
 if(k==='a'&&oa||k==='w'&&ow||k==='b'&&oa&&ow)return'owned';if(k==='b'&&(oa||ow))return'part';if(!(+P.gold>=flgPriceOf(k)))return'gold';return''}
/* buys a Mythic for coins: kind 'a' (Feastlord's Aegis), 'w' (Horn of Plenty) or 'b' (both, the bundle). Returns true on success. */
function flgBuy(kind){const k=kind==='b'||kind==='both'?'b':kind;if(k!=='a'&&k!=='w'&&k!=='b')return false;if(flgWhyNot(k))return false;const pr=flgPriceOf(k);
 const pay=()=>{P.gold-=pr;if(k!=='w')P.ownA.flfeast=1;if(k!=='a')P.own.fl_horn=1};
 try{if(typeof ukSrc==='function')ukSrc('harvest relic',pay);else pay()}catch(e){return false}
 save();return true}
function flgBuyBoth(){return flgBuy('b')}

/* ---------- save repair: keep the equipped piece through a reload ---------- */
{const s0=save;save=function(){try{if(P&&typeof P==='object')P.eqK={a:String(P.armor||''),w:String(P.weapon||''),p:String(P.path||'')}}catch(e){}return s0.apply(this,arguments)}}
function flgEqFix(){try{const q=P&&P.eqK;if(!q||typeof q!=='object'){if(P)P.eqK=null;return 0}let n=0;
  if(typeof q.a==='string'&&AR[q.a]&&P.ownA&&P.ownA[q.a]&&P.armor!==q.a){P.armor=q.a;n++}
  if(typeof q.w==='string'&&WP[q.w]&&P.own&&P.own[q.w]&&P.weapon!==q.w){const p=WP[q.w].p||'knight';if(PATHS[p]&&pathOpen(p)){P.weapon=q.w;P.path=p;if(P.wsel)P.wsel[p]=q.w;n++}}
  return n}catch(e){return 0}}
{const l0=load;load=function(){const r=l0.apply(this,arguments);flgEqFix();return r}}
flgEqFix();

/* ---------- Hall: the Bountiful Harvest set joins the "Almost complete" goals ---------- */
{const h0=hlGoals;hlGoals=function(){const G=h0.apply(this,arguments);try{const items=[['a','flfeast'],['w','fl_horn']],h=items.filter(([k,id])=>flgOwn(k,id)).length;if(h===1)G.push({key:'s:bounty',kind:'s',n:'Bountiful Harvest set',have:h,tot:2,items,r:.5})}catch(e){}return G}}
