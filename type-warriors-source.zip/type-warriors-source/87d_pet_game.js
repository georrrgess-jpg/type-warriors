/* ===== COMPANIONS IN BATTLE =====
   The equipped companion follows the knight in every run. Its power works only in Campaign and standard Endless;
   other modes (Daily, Rift, Practice, Monster Mash, Beginner) show it as a cosmetic friend.
   Charge counts validated completed words once each, starts at zero every run, and stores at most one use. */
RS_SKIP.add('petfx');
const petPowerMode=()=>S.mode==='play'&&!S.rift&&!S.prac&&!S.dc&&!S.gy&&!S.bg&&!S.wa;
const PP=()=>S&&S.pet&&!S.pet.cos?S.pet:null;
function petRunInit(){S.petfx=[];const id=P&&P.pet;if(!id||!PDEF[id]){S.pet=null;return}
 const on=petPowerMode();S.pet={id,cos:on?0:1,w:0,ready:false,uses:0,cw:1,lant:0,lantT:0,veil:0,gb:0,xs:0,anim:null,calmT:0,x:-90,mv:0,hop:-9,fl:-9,stamps:[],look:petLook(id)};
 if(on){const k=PDEF[id].ab.k;if(k==='scholar')S.xpm=(S.xpm||0)+.05;if(k==='gilded')S.gm=(S.gm||1)+.05}}
const petAnim=(pose,dur)=>{const p=S.pet;if(p)p.anim={pose,t:S.t,dur:dur||1.4}};
/* one validated word (or several for a boss sentence) */
function petWord(n){const p=PP();if(!p)return;const A=PDEF[p.id].ab;if(!A.N||p.ready)return;if(A.cap&&p.uses>=A.cap)return;
 p.w=Math.min(A.N,p.w+n);if(p.w>=A.N){p.ready=true;p.pingT=S.t;try{beep(880,.06,'sine',.25);setTimeout(()=>beep(1175,.08,'sine',.2),70)}catch(e){}petAnim('greet',1)}}
function petSpend(){const p=PP();if(!p)return;p.ready=false;p.w=0;p.uses++}
const petNearest=()=>S.en.filter(e=>!e.boss&&!e.dead&&e.x<W-10&&e.x>KX+40).sort((a,b)=>a.x-b.x||String(a.id).localeCompare(String(b.id)))[0];
const petPx=()=>{const p=S.pet;return p?p.x:KX-120},petPy=()=>GY-(PDEF[S.pet.id].hover?70:40);
function pfx(o){if(!S.petfx)S.petfx=[];o.t=0;S.petfx.push(o)}

/* ---------- run lifecycle ---------- */
{const s0=start;start=function(){const r=s0.apply(this,arguments);try{petRunInit()}catch(e){S.pet=null}return r}}
{const w0=startWave;startWave=function(){const r=w0.apply(this,arguments);try{const p=S.pet;if(p)p.cw=1;
  /* Adventure Trail: each block of five Endless rounds cleared is one stamp */
  if(S.mode==='play'&&!S.camp&&!S.rift&&!S.prac&&!S.dc&&S.wave>1&&(S.wave-1)%5===0&&S.petStW!==S.wave){S.petStW=S.wave;petRunStamp('endless')}}catch(e){}return r}}
function petRunStamp(kind){const n=petStamp(kind);if(!n)return;if(S.pet)S.pet.stamps.push(n);else{S.petStamps=S.petStamps||[];S.petStamps.push(n)}
 if(S.mode==='play'){float(W/2,210,`Trail stamp! ${n.n} / ${PTRAIL}`,'#9fffb0',34);if(n.eggs.length)float(W/2,256,`${PRAR[n.eggs[0]].egg} egg found!`,PRAR[n.eggs[0]].c,40);try{[523,659,784].forEach((f,i)=>setTimeout(()=>beep(f,.1,'sine',.25),i*80))}catch(e){}}
 return n}
function petLogUses(){const p=S.pet;if(!p||p._lg||!p.uses||!P.pets[p.id])return;p._lg=1;P.pets[p.id].used=(P.pets[p.id].used|0)+p.uses;try{save()}catch(e){}}
{const v0=victory;victory=function(){const st=S.mode,x0=P.xp;const r=v0.apply(this,arguments);try{petLogUses()}catch(e){}try{if(st!=='over'&&S.camp&&!S.prac&&!S.dc&&!S.rift)petRunStamp('camp');if(st!=='over')petResultXp(x0)}catch(e){}return r}}
{const o0=over;over=function(quit){const st=S.mode,x0=P.xp;const r=o0.apply(this,arguments);try{petLogUses()}catch(e){}try{if(st!=='over')petResultXp(x0)}catch(e){}return r}}
function petResultXp(x0){const p=PP();if(!p||PDEF[p.id].ab.k!=='scholar')return;if(x0==null)return;const dx=P.xp-x0,den=1+.1*U('scholar')+.1*(P.pres||0)+(S.xpm||0);p.xs=Math.round(dx*.05/Math.max(1,den))}
try{const wf0=waFinish;waFinish=function(won){const A=S.wa,first=A&&!A._pst;if(A)A._pst=1;const r=wf0.apply(this,arguments);try{if(first){const n=petStamp('arena');if(n)setTimeout(()=>petStampToast(n),900)}}catch(e){}return r}}catch(e){}
try{const tf0=ttFinish;ttFinish=function(complete=false){const r=tf0.apply(this,arguments);try{if(complete===true){const n=petStamp('treat');if(n)setTimeout(()=>petStampToast(n),700)}}catch(e){}return r}}catch(e){}
function petStampToast(n){ccToast(n.starter?'Adventure complete! Choose your first companion in the Pets menu.':n.eggs.length?`Trail stamp ${n.n}/${PTRAIL}: a ${PRAR[n.eggs[0]].egg} egg is waiting in Pets!`:`Adventure Trail stamp ${n.n} / ${PTRAIL}`)}
function petFromStyle(id){PTX.back=title;PTX.sel=id;PTX.tab='Pets';petHall('Pets');setTimeout(()=>{try{if(P.petUnl&&P.petUnl[id]){delete P.petUnl[id];save()}ptCustom(id)}catch(e){}},260)}
function petFromResults(){PTX.back=title;petHall(P.petSt===1?'':'Eggs')}
/* the result screens list trail stamps, eggs and the companion's contribution */
{const rb0=resBlock;resBlock=function(){let h=rb0.apply(this,arguments);try{const p=S.pet,st=(p&&p.stamps)||S.petStamps||[];const bits=[];
  if(st.length){const eg=st.flatMap(n=>n.eggs),star=st.some(n=>n.starter),last=st[st.length-1];bits.push(`<b class="ptrs-st">🐾 Adventure Trail +${st.length} stamp${st.length>1?'s':''} (${last.n}/${PTRAIL})</b>`);
   if(eg.length)bits.push(`<b style="color:${PRAR[eg[0]].c}">${eg.map(k=>PRAR[k].egg).join(' + ')} egg${eg.length>1?'s':''} earned!</b>`);
   const lu=st.map(n=>n.lvUp).filter(Boolean).pop();if(lu&&PDEF[lu.id]){const C=PDEF[lu.id].cos,nm=lu.k?{acc:C.acc,pal:C.pal,cel:C.cel,trim:C.sig}[lu.k]:null;bits.push(`<b class="ptrs-lv">★ ${esc(petName(lu.id))} reached Bond ${lu.lv}${nm?` · <i>${esc(nm)}</i> unlocked!`:'!'}</b>`);if(nm&&!eg.length&&!star)bits.push(`<button class="ptrs-go" onclick="petFromStyle('${lu.id}')">Try the new style ›</button>`)}
   if(star)bits.push(`<button class="ptrs-go" onclick="petFromResults()">Choose your first companion ›</button>`);else if(eg.length)bits.push(`<button class="ptrs-go" onclick="petFromResults()">Hatch in Pets ›</button>`)}
  if(p&&!p.cos){const k=PDEF[p.id].ab.k;if(k==='gilded'&&p.gb>0)bits.push(`${esc(petName(p.id))} +${Math.round(p.gb)} gold`);if(k==='scholar'&&p.xs>0)bits.push(`${esc(petName(p.id))} +${p.xs} XP`);if(PDEF[p.id].ab.N&&p.uses)bits.push(`${PDEF[p.id].ab.n} ×${p.uses}`)}
  if(st.length&&p&&p.stamps.length&&P.pets[p.id])bits.push(`${esc(petName(p.id))} +${10*st.length} bond`);
  if(bits.length)h+=`<div class="ptrs">${bits.join('<i>·</i>')}</div>`}catch(e){}return h}}

/* ---------- word charge ---------- */
{const k0=kill;kill=function(e,force){const had=S.en.includes(e),boss=e&&e.boss,vul0=e&&e.vul,typed=!force&&e&&e.i>=(e.w||'').length;const r=k0.apply(this,arguments);
  try{if(S.pet&&had&&!S.en.includes(e)&&!boss&&S.t-S.pet.hop>.5)S.pet.hop=S.t;if(typed&&PP()){if(boss){if(e.vul>0&&!(vul0>0))petWord(Math.max(1,(e.w||'').trim().split(/\s+/).length))}else if(had&&!S.en.includes(e))petWord(1)}}catch(x){}return r}}
{const sb0=shieldBreak;shieldBreak=function(t){const r=sb0.apply(this,arguments);try{petWord(1)}catch(e){}return r}}
/* Quillfin adds 10% of the base Fury gain; Lilyhop stops typos draining Fury */
{const ky0=key;key=function(c){const f0=S.fury,live=S.mode==='play';const r=ky0.apply(this,arguments);try{const p=PP();if(p&&live&&S.mode==='play'){const k=PDEF[p.id].ab.k,df=S.fury-f0;
  if(k==='inkflow'&&df>0)S.fury=Math.min(S.fm,S.fury+.07);
  if(k==='calm'&&df<0&&df>-6){S.fury=f0;if(S.t-p.calmT>.8){p.calmT=S.t;petAnim('ability',.9)}}}}catch(e){}return r}}
/* Tickpip: each new boss sentence gets 20% more time, three times per boss */
{const nb0=newBossLine;newBossLine=function(e){const r=nb0.apply(this,arguments);try{const p=PP();if(p&&PDEF[p.id].ab.k==='second'&&e&&e.boss){e._ptk=e._ptk||0;if(e._ptk<3){e._ptk++;const add=Math.max(2,e.tmax*.2);e.tm+=add;e.tmax+=add;p.uses++;petAnim('ability',1.2);float(e.x-60,GY-e.h-40,'+'+add.toFixed(1)+'s','#ffd45a',30)}}}catch(x){}return r}}
/* Prismkit: the next ordinary monster to arrive is Shiny */
{const sp0=spawn;spawn=function(){const n0=S.en.length;const r=sp0.apply(this,arguments);try{const p=PP();if(p&&p.ready&&PDEF[p.id].ab.k==='prism'){const e=S.en.slice(n0).find(q=>!q.boss&&!q.mn&&!q.sh);if(e){shinyMake(e,MON[e.id]);petSpend();petAnim('ability',1.3);pfx({k:'rainbow',ml:1,tx:e.x,ty:e.y-e.h*.5})}}}catch(x){}return r}}
/* Forgebeetle's share of combat gold */
{const g0=gain;gain=function(n){const a=S.gold;const r=g0.apply(this,arguments);try{const p=PP();if(p&&PDEF[p.id].ab.k==='gilded'){const d=S.gold-a;if(d>0)p.gb+=d*.05/Math.max(1,S.gm||1)}}catch(e){}return r}}

/* ---------- damage: Leafguard absorbs after your own shields; Last Lantern answers a near miss ---------- */
{const d0=dmg;dmg=function(d){try{const p=PP();if(p&&S.mode==='play'&&!(S.inv>0)&&!(S.shield>0)&&p.ready&&PDEF[p.id].ab.k==='leafguard'){
   petSpend();S.inv=S.invT;S.shake=8;float(KX,GY-260,'Leafguard!','#9aff7a',36);burst(KX,GY-130,'#9aff7a',26,{v:360});pfx({k:'dome',ml:.9});petAnim('ability',1.3);try{beep(392,.12,'sine',.35);beep(587,.16,'sine',.25)}catch(e){}return}}catch(e){}
  const hp0=S.hp;const r=d0.apply(this,arguments);try{if(S.pet&&S.hp<hp0)S.pet.fl=S.t}catch(e){}
  try{const p=PP();if(p&&PDEF[p.id].ab.k==='lantern'&&!p.lant&&hp0>1&&S.hp===1&&S.mode==='play'){p.lant=1;p.lantT=.55;petAnim('ability',1.4)}}catch(e){}return r}}

/* ---------- per-frame: triggers, slows and binds, interception ---------- */
{const u0=update;update=function(dt){const p=S&&S.pet;if(!p||S.mode!=='play'){return u0.apply(this,arguments)}
 const on=!p.cos,k=PDEF[p.id].ab.k;
 /* follow: settle behind the knight, never crossing the typing lane */
 {const tx=KX-118+(S.lunge||0)*24,dx=tx-p.x,st=Math.min(Math.abs(dx),(Math.abs(dx)>40?300:120)*dt);p.x+=Math.sign(dx)*st;p.mv=Math.abs(dx)>3?1:0}
 const mod=[],pjm=[];
 if(on){
  /* ready powers fire as soon as they have a valid use */
  if(p.ready){
   if(k==='heartgrove'&&S.hp>0&&S.hp<S.max){heal(S,1);petSpend();petAnim('ability',1.6);float(KX,GY-270,'+1 ♥','#5aff9a',38);pfx({k:'heart',ml:1.2});try{[523,659,784].forEach((f,i)=>setTimeout(()=>beep(f,.12,'sine',.2),i*90))}catch(e){}}
   else if(k==='embertag'){const e=petNearest();if(e){e.pslow=3;e.pslowF=.75;petSpend();petAnim('ability',1);pfx({k:'ember',ml:.45,e,tx:e.x,ty:e.y-e.h*.5});try{beep(330,.1,'triangle',.3)}catch(x){}}}
   else if(k==='moonbind'){const e=petNearest();if(e){e.pbind=2;petSpend();petAnim('ability',1.2);pfx({k:'bind',ml:2,e});float(e.x,e.y-e.h-30,'Bound!','#d0a0ff',30);try{beep(660,.12,'sine',.3);beep(440,.18,'sine',.2)}catch(x){}}}
   else if(k==='echo'){if(S.pj.some(j=>!j.b)){p.veil=3;petSpend();petAnim('ability',1.2);pfx({k:'sonar',ml:1});try{beep(520,.08,'sine',.25);setTimeout(()=>beep(620,.08,'sine',.2),90)}catch(x){}}}
   else if(k==='sweep'){const pj=S.pj.filter(j=>!j.b),en=S.en.filter(e=>!e.boss&&e.x<W-10);if(pj.length||en.length){for(const j of pj)burst(j.x,j.y,'#ff8a2a',10,{v:220});S.pj=S.pj.filter(j=>j.b);const push=(W+110-KX)*.1;for(const e of en){e.x=Math.min(W+110,e.x+push);e.lg=1}
     petSpend();petAnim('ability',1.3);pfx({k:'sweep',ml:.7});S.shake=10;float(W*.45,GY-300,'Cinder Sweep!','#ffb04a',38);try{beep(220,.18,'sawtooth',.2);beep(330,.2,'triangle',.25)}catch(x){}}}
   else if(k==='reservoir'&&S.fm-S.fury>=20){S.fury=Math.min(S.fm,S.fury+20);petSpend();petAnim('ability',1.3);pfx({k:'star',ml:.9});float(W/2,H-110,'+20 Fury','#c08aff',30);try{beep(784,.1,'sine',.25);setTimeout(()=>beep(1046,.12,'sine',.2),80)}catch(x){}}}
  if(p.lantT>0){p.lantT-=dt;if(p.lantT<=0&&S.hp>0){heal(S,1);float(KX,GY-270,'Last Lantern! +1 ♥','#7affc8',34);pfx({k:'heart',ml:1.2,c:'#7affc8'});try{beep(587,.2,'sine',.3);beep(880,.25,'sine',.2)}catch(x){}}}
  if(p.veil>0)p.veil-=dt;
  /* Pebblecrab catches the first ordinary projectile per wave that would really hit */
  if(k==='catch'&&p.cw&&!(S.inv>0)&&!(S.shield>0)){const j=S.pj.find(j=>!j.b&&j.x-j.v*dt*1.6<KX+70);if(j){S.pj.splice(S.pj.indexOf(j),1);p.cw=0;p.uses++;petAnim('ability',1);pfx({k:'catch',ml:.8,x:j.x,y:j.y});float(KX+60,GY-230,'Caught!','#5ad8ff',32);burst(j.x,j.y,'#9ff0ff',16,{v:260});try{beep(1046,.08,'triangle',.25)}catch(x){}}}
  /* temporary per-enemy slows and binds (strongest slow wins over the global slow) */
  for(const e of S.en){if(e.boss)continue;if(e.pbind>0){e.pbind-=dt;mod.push([e,e.sp,e.at]);e.sp=0}else if(e.pslow>0){e.pslow-=dt;const f=Math.min(1,e.pslowF/Math.max(.01,S.slow||1));mod.push([e,e.sp,null]);e.sp*=f}}
  if(p.veil>0)for(const j of S.pj){if(j.b)continue;pjm.push([j,j.v]);j.v*=.7}}
 const r=u0.apply(this,arguments);
 for(const [e,sp,at] of mod){e.sp=sp;if(at!=null&&e.at!=null)e.at=at}
 for(const [j,v] of pjm)j.v=v;
 return r}}

/* ---------- drawing ---------- */
function petPoseNow(){const p=S.pet;if(!p)return{pose:'idle',u:0};if(p.anim){const k=(S.t-p.anim.t)/p.anim.dur;if(k>=0&&k<1)return{pose:p.anim.pose,u:k};p.anim=null}
 if(p.mv&&S.mode==='play')return{pose:'walk',u:0};
 if(S.pose==='victory')return{pose:'greet',u:((S.poseT||0)%2.2)/2.2};return{pose:'idle',u:0}}
/* the companion is drawn after the knight (see petDrawGame callers) so it always sits in front of his cape and armour */
function petDrawGame(){try{const p=S.pet;if(p&&PDEF[p.id]&&(S.mode==='play'||S.mode==='over'||S.mode==='boon'||S.mode==='pause')){const c=ctx,o=petPoseNow(),hv=PDEF[p.id].hover,s=hv?.98:1.02;
   /* a happy hop after a kill, a flinch when the knight is hit */const hk=(S.t-p.hop)/.38,fk=(S.t-p.fl)/.34,hop=hk>=0&&hk<1?-Math.sin(hk*Math.PI)*13:0,fl=fk>=0&&fk<1?Math.sin(fk*Math.PI*3)*(1-fk)*7:0;
   if(p.ready&&!p.cos){const pu=.5+.5*Math.sin(S.t*5);c.save();c.globalCompositeOperation='lighter';c.translate(p.x,GY+3);c.scale(1,.26);c.strokeStyle='#9fffb0'+Math.round((.35+.4*pu)*255).toString(16).padStart(2,'0');c.lineWidth=7;c.beginPath();c.arc(0,0,44+pu*6,0,TAU);c.stroke();c.restore()}
   if(hv){const q=c.createRadialGradient(p.x,GY+2,0,p.x,GY+2,30);q.addColorStop(0,'#00000066');q.addColorStop(1,'#00000000');c.fillStyle=q;c.beginPath();c.ellipse(p.x,GY+2,30,6,0,0,TAU);c.fill()}
   c.save();c.translate(p.x-fl,GY+2-(hv?34:0)+hop);c.rotate(-fl*.012);c.scale(s,s);petDraw(c,p.id,Object.assign({t:S.t,pose:o.pose,u:o.u,noSh:hv||hop?1:0},p.look));
   if(S.pose==='victory'&&p.look&&p.look.cel)petCelFx(c,p.id,((S.poseT||0)%2.2)/2.2,S.t,-50,80);c.restore();
   petEmoteTick(p,c,s,hv,hop);
   if(hop&&!hv){c.save();c.globalAlpha=.5;c.fillStyle='#000';c.beginPath();c.ellipse(p.x,GY+3,30+hop*.8,6,0,0,TAU);c.fill();c.restore()}}}catch(e){}}

{const w0=drawWorld;drawWorld=function(){const r=w0.apply(this,arguments);try{const c=ctx,p=S.pet;
  /* marks on slowed and bound monsters */
  for(const e of S.en){if(e.pbind>0){const cy=e.y-e.h*.5;c.save();c.globalCompositeOperation='lighter';c.translate(e.x,e.y-6);c.scale(1,.3);c.rotate(S.t*2);c.strokeStyle='#c08aff';c.lineWidth=6;c.setLineDash([18,12]);c.beginPath();c.arc(0,0,e.h*.55,0,TAU);c.stroke();c.restore();pGlow(c,e.x,cy,e.h*.6,'#a85aff',.25)}
   else if(e.pslow>0){pGlow(c,e.x,e.y-10,40,'#ff8a2a',.35);for(let i=0;i<3;i++){const v=(S.t*1.4+i/3)%1;c.globalAlpha=1-v;c.fillStyle='#ffb04a';c.fillRect(e.x-20+i*18,e.y-10-v*50,4,4);c.globalAlpha=1}}}
  if(p&&p.veil>0)for(const j of S.pj){if(j.b)continue;c.save();c.globalCompositeOperation='lighter';c.strokeStyle='#b07aff88';c.lineWidth=3;c.beginPath();c.arc(j.x,j.y,22+Math.sin(S.t*10)*3,0,TAU);c.stroke();c.restore()}
  /* ability effects */
  const L=S.petfx||[];for(let i=L.length-1;i>=0;i--){const f=L[i];f.t+=1/60;const u=f.t/f.ml;if(u>=1){L.splice(i,1);continue}const px=p?p.x:KX-120,py=p?petPy():GY-40;
   if(f.k==='ember'){const tx=f.e&&S.en.includes(f.e)?f.e.x:f.tx,ty=f.e&&S.en.includes(f.e)?f.e.y-f.e.h*.5:f.ty,x=px+40+(tx-px-40)*u,y=py+(ty-py)*u-Math.sin(u*Math.PI)*120;pGlow(c,x,y,40,'#ff8a2a',.8);c.fillStyle='#fff2a0';c.beginPath();c.arc(x,y,8,0,TAU);c.fill();if(u>.9)burst(tx,ty,'#ff8a2a',10,{v:200})}
   else if(f.k==='bind'&&f.e){/* crescent ribbon from the companion */if(u<.25){const v=u/.25,tx=f.e.x,ty=f.e.y-f.e.h*.5;c.save();c.globalCompositeOperation='lighter';c.strokeStyle='#c08aff';c.lineWidth=6*(1-v)+2;c.beginPath();c.moveTo(px+30,py);c.quadraticCurveTo((px+tx)/2,py-160,px+30+(tx-px-30)*v,py+(ty-py)*v);c.stroke();c.restore()}}
   else if(f.k==='sonar'){for(let k2=0;k2<3;k2++){const v=Math.max(0,Math.min(1,u*1.5-k2*.2));if(v<=0||v>=1)continue;c.save();c.globalCompositeOperation='lighter';c.globalAlpha=1-v;c.strokeStyle='#b07aff';c.lineWidth=8;c.beginPath();c.arc(px,py,40+v*900,-.5,.5);c.stroke();c.restore()}}
   else if(f.k==='sweep'){const x=KX+u*(W-KX);c.save();c.globalCompositeOperation='lighter';c.globalAlpha=1-u*.6;c.strokeStyle='#ff8a2a';c.lineWidth=30*(1-u)+6;c.beginPath();c.arc(x-200,GY-180,260,-.9,.9);c.stroke();c.strokeStyle='#fff2a0';c.lineWidth=8;c.stroke();c.restore()}
   else if(f.k==='dome'){c.save();c.globalCompositeOperation='lighter';c.globalAlpha=1-u;c.strokeStyle='#9aff7a';c.lineWidth=10;c.beginPath();c.ellipse(KX,GY-130,150+u*40,170+u*40,0,0,TAU);c.stroke();c.restore();for(let k2=0;k2<6;k2++){const a=S.t*3+k2;pLeaf(c,KX+Math.cos(a)*170,GY-130+Math.sin(a)*190,22,8,a+1.6,'#a6ff6a','#3a9a2a',2)}}
   else if(f.k==='heart'){const x=KX,y=GY-180-u*140;c.globalAlpha=1-u*u;pGlow(c,x,y,50,'#5aff9a',.6);pHeart(c,x,y,22,f.c||'#5aff9a',3);c.globalAlpha=1}
   else if(f.k==='catch'){c.save();c.translate(f.x,f.y);c.globalAlpha=1-u;pGlow(c,0,0,60,'#5ad8ff',.7);pP(c,[0,-46,18,-14,12,36,-8,46,-16,0]);pF(c,'#9ff0ffcc',3,'#2a98d8');c.restore()}
   else if(f.k==='star'){const x=px+(W/2-px)*u,y=py+((H-64)-py)*u-Math.sin(u*Math.PI)*200;pGlow(c,x,y,40,'#c08aff',.8);pStar5(c,x,y,14,'#ffd45a',2)}
   else if(f.k==='rainbow'){c.save();c.globalCompositeOperation='lighter';c.globalAlpha=1-u;['#ff6a6a','#ffb04a','#fff06a','#7aff8a','#6ad8ff','#b07aff'].forEach((col,k2)=>{c.strokeStyle=col;c.lineWidth=6;c.beginPath();c.moveTo(px+20,py-k2*6);c.quadraticCurveTo((px+f.tx)/2,py-260-k2*6,f.tx,f.ty-k2*6);c.stroke()});c.restore()}}}catch(e){}return r}}
/* a small power icon beside the Fury bar: a charge ring, READY glow and uses left */
{const hd0=drawHUD;drawHUD=function(){const r=hd0.apply(this,arguments);try{const p=S.pet;if(!p||S.mode==='title')return r;const c=ctx,D=PDEF[p.id],A=D.ab,x=W/2+220+52,y=H-56,R=28;
  c.save();c.fillStyle='#0a0618cc';c.beginPath();c.arc(x,y,R+6,0,TAU);c.fill();c.strokeStyle=PRAR[D.r].c+'88';c.lineWidth=2;c.stroke();
  let fr=1,lit=!p.cos;if(p.cos){lit=false}else if(A.N){fr=p.ready?1:p.w/A.N;if(A.cap&&p.uses>=A.cap&&!p.ready){fr=0;lit=false}}else if(A.k==='catch'){lit=!!p.cw}else if(A.k==='lantern'){lit=!p.lant}
  if(A.N&&!p.cos){c.strokeStyle='#ffffff18';c.lineWidth=5;c.beginPath();c.arc(x,y,R+2,0,TAU);c.stroke();c.strokeStyle=p.ready?'#9fffb0':'#c08aff';c.beginPath();c.arc(x,y,R+2,-Math.PI/2,-Math.PI/2+TAU*fr);c.stroke()}
  if(p.ready){const pu=.5+.5*Math.sin(S.t*6);pGlow(c,x,y,56,'#9fffb0',.35+.25*pu)}
  c.globalAlpha=lit||p.ready?1:.45;petIcon(c,A.k,x,y,R*1.55);c.globalAlpha=1;
  c.textAlign='left';c.font='600 16px Poppins,system-ui';c.fillStyle=p.cos?'#a8a2d8':p.ready?'#9fffb0':'#e8e0ff';
  const lab=p.cos?`${petName(p.id)} (companion only)`:p.ready?`${A.n}: READY`:A.N?`${A.n} ${Math.floor(p.w)}/${A.N}`:A.n;c.fillText(lab,x+R+14,y-4);
  if(!p.cos&&A.cap){for(let i=0;i<A.cap;i++){c.beginPath();c.arc(x+R+20+i*16,y+14,5,0,TAU);c.fillStyle=i<A.cap-p.uses?'#9fffb0':'#3a3460';c.fill()}}
  else if(!p.cos&&(A.k==='catch'||A.k==='lantern')){c.font='500 13px Poppins,system-ui';c.fillStyle='#c8c2f0';c.fillText(A.k==='catch'?(p.cw?'Ready this wave':'Used this wave'):(p.lant?'Used this run':'Ready'),x+R+14,y+16)}
  c.restore()}catch(e){}return r}}
{const st=document.createElement('style');st.textContent=`.ptrs{display:flex;flex-wrap:wrap;justify-content:center;align-items:center;gap:8px;margin:4px auto 0;padding:8px 14px;border-radius:14px;background:#0a0618b0;border:1px solid #3a3070;font:600 15px var(--ui);color:#e8e0ff}.ptrs i{font-style:normal;color:#6a5a9a}.ptrs-st{color:#9fffb0}.ptrs-lv{color:#ffd45a}.ptrs .ptrs-lv i{color:#fff;font-style:italic}
.ptrs-go{all:unset;cursor:pointer;padding:6px 14px;border-radius:10px;font:800 14px var(--ui);color:#2a1406;background:linear-gradient(180deg,#fff0a0,#f0b030);border:1.5px solid #fff4b8}.ptrs-go:hover{filter:brightness(1.08)}`;document.head.appendChild(st)}

/* ---------- little emote bubbles: "!" when a power is ready, a heart on big combos, a note on a new round ---------- */
function petEmoteTick(p,c,s,hv,hop){if(S.mode!=='play'&&S.mode!=='over')return;
 if(p.ready&&!p.cos&&p.pingT!=null&&p._pe!==p.pingT){p._pe=p.pingT;p.emo={k:'!',t:S.t}}
 const cb=Math.floor((S.combo||0)/25);if(p._cb==null)p._cb=cb;if(cb>p._cb&&cb>0){p.emo={k:'heart',t:S.t};p.hop=S.t}p._cb=cb;
 if(p._wv!==S.wave){if(p._wv!=null&&S.wave>1)p.emo={k:'note',t:S.t};p._wv=S.wave}
 if(S.mode==='over'&&S.pose==='victory'&&!p._vic){p._vic=1;p.emo={k:'heart',t:S.t}}
 const e=p.emo;if(!e)return;const k=(S.t-e.t)/1.7;if(k<0||k>=1){p.emo=null;return}
 const bx=(PDEF[p.id].box||[-60,-110,120,115]),top=GY+2-(hv?34:0)+hop+bx[1]*s;petEmote(c,p.x+bx[2]*s*.28,top-6,e.k,k)}
function petEmote(c,x,y,kind,k){const pop=k<.18?(1-Math.pow(1-k/.18,3)):1,a=k>.8?1-(k-.8)/.2:1,sc=k<.18?.4+.75*pop-.15*Math.sin(pop*Math.PI):1,bob=Math.sin(k*9)*1.5;
 c.save();c.globalAlpha=a;c.translate(x,y-k*8+bob);c.scale(sc*1.25,sc*1.25);
 c.shadowColor='#0008';c.shadowBlur=8;c.shadowOffsetY=2;c.fillStyle='#fffaf0';c.beginPath();c.roundRect?c.roundRect(-17,-30,34,28,12):c.rect(-17,-30,34,28);c.fill();c.beginPath();c.moveTo(-6,-4);c.lineTo(-10,6);c.lineTo(3,-3);c.closePath();c.fill();c.shadowColor='transparent';
 c.strokeStyle=kind==='!'?'#3ad87a':kind==='heart'?'#ff6aa8':'#8a7cf0';c.lineWidth=2.5;c.beginPath();c.roundRect?c.roundRect(-17,-30,34,28,12):c.rect(-17,-30,34,28);c.stroke();
 if(kind==='!'){c.fillStyle='#1e9a50';c.font='900 22px Poppins,system-ui';c.textAlign='center';c.textBaseline='middle';c.fillText('!',0,-15)}
 else if(kind==='heart'){pHeart(c,0,-16,8.5,'#ff4a8a',1)}
 else{c.fillStyle='#5a4ae0';c.beginPath();c.ellipse(-4,-10,4.5,3.5,-.4,0,TAU);c.fill();c.fillRect(-.5,-25,2.6,15);c.beginPath();c.moveTo(2,-25);c.quadraticCurveTo(10,-22,8,-14);c.quadraticCurveTo(7,-19,2,-19);c.fill()}
 c.restore()}
