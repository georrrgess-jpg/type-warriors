/* ===== COLLECTION HALL: the Overview tab of the Collection =====
   Three living exhibits (Monsters, Weapons, Armor) painted with the game's own monster, weapon and hero art, a next-step goal panel,
   weapon mastery, "New" badges for discoveries since the last visit, and personal display choices.
   Reads the same data as the Catalog, Armory and Mastery screens. New saved fields only: P.colv (what was seen at the last visit),
   P.colp (pinned exhibit items) and P.colg (the pinned goal). */
CTABS.splice(0,CTABS.length,'Overview','Monsters','Weapons','Armor','Bosses','Mastery','Crates');
/* the element that actually scrolls on the current screen (the catalog grid, the shell main column, or the overlay) */
function hlScr(){for(const e of[ov.querySelector('.bwrap'),ov.querySelector('main.mn'),ov])if(e&&e.scrollHeight>e.clientHeight+4&&/auto|scroll/.test(getComputedStyle(e).overflowY))return e;return ov}
const HL={sc:{},rm:()=>matchMedia('(prefers-reduced-motion: reduce)').matches};
/* ---------- collection data, always computed from the game's own tables ---------- */
const hlZoneIds=z=>[...new Set(ZR[z].flat())].filter(k=>MON[k]);
function hlMonIds(){return REG().filter(k=>MON[k])}
const hlSeen=k=>!!(P.sn[k]||P.bs[k]);
function hlStats(){const m=hlMonIds(),wk=Object.keys(WP),ak=Object.keys(AR);
 return{mon:m,monSeen:m.filter(hlSeen),monDef:m.filter(k=>P.bs[k]),kills:Object.values(P.bs||{}).reduce((a,b)=>a+(+b||0),0),
  wpn:wk,wOwn:wk.filter(k=>P.own[k]),arm:ak,aOwn:ak.filter(k=>P.ownA[k])}}
/* what was already seen at the last visit; on a fresh profile everything present counts as seen */
function hlViewed(){const S2=hlStats();let v=P.colv;if(!v||typeof v!=='object'){v=P.colv={m:S2.monSeen.slice(),w:S2.wOwn.slice(),a:S2.aOwn.slice()};save()}for(const k of'mwa')if(!Array.isArray(v[k]))v[k]=[];return v}
function hlNew(){const v=hlViewed(),S2=hlStats();return{m:S2.monSeen.filter(k=>!v.m.includes(k)),w:S2.wOwn.filter(k=>!v.w.includes(k)),a:S2.aOwn.filter(k=>!v.a.includes(k))}}
function hlClear(cat){const v=hlViewed(),S2=hlStats();v[cat]=cat==='m'?S2.monSeen.slice():cat==='w'?S2.wOwn.slice():S2.aOwn.slice();save()}
const hlPins=()=>{let p=P.colp;if(!p||typeof p!=='object')p=P.colp={};if(!Array.isArray(p.m))p.m=[];if(!Array.isArray(p.w))p.w=[];p.m=p.m.filter(k=>MON[k]&&hlSeen(k));p.w=p.w.filter(k=>WP[k]&&P.own[k]);return p};
/* which monsters stand in the diorama: pinned first, then new ones, then a varied mix (flyer, caster, brute) */
function hlMonShow(){const S2=hlStats(),pin=hlPins().m,nw=hlNew().m,out=[];const add=k=>{if(k&&!out.includes(k)&&out.length<4)out.push(k)};
 pin.forEach(add);nw.forEach(add);const seen=S2.monSeen.slice().reverse();
 add(seen.find(k=>MON[k].fly&&!out.includes(k)));add(seen.find(k=>MON[k].pj&&!out.includes(k)));add(seen.find(k=>MON[k].tr&&!out.includes(k)));seen.forEach(add);return out}
function hlWpnShow(){const own=Object.keys(WP).filter(k=>P.own[k]),pin=hlPins().w,nw=hlNew().w,out=[];const add=k=>{if(k&&P.own[k]&&!out.includes(k)&&out.length<3)out.push(k)};
 add(P.weapon);pin.forEach(add);nw.forEach(add);own.sort((a,b)=>RKM[WP[b].r]-RKM[WP[a].r]).forEach(add);
 /* the equipped weapon takes the centre */
 const i=out.indexOf(P.weapon);if(i>=0&&out.length>1){out.splice(i,1);out.splice(1,0,P.weapon)}return out}
const hlArmOwned=()=>Object.keys(AR).filter(k=>P.ownA[k]).sort((a,b)=>RKM[AR[a].r]-RKM[AR[b].r]);


/* ---------- goals for the "Almost Complete" panel ---------- */
const hlMastW=()=>{const w=P.colmw;return WP[w]&&P.own[w]?w:P.weapon};
function hlZoneGoal(z){const ids=hlZoneIds(z),s=ids.filter(hlSeen).length;return{key:'z:'+z,kind:'z',z,n:ZN2[z],have:s,tot:ids.length,ids,r:s/ids.length}}
function hlGoals(){const G=[];
 ZN2.forEach((n,z)=>{const g=hlZoneGoal(z);if(g.have>0&&g.have<g.tot)G.push(g)});
 if(typeof GAB!=='undefined'){const sets=[['harvest','Soul Harvest set',[['a','hwreap'],['w','hw_scythe']]],['pcurse','Pumpkin Curse set',[['a','hwpreap'],['w','hw_scythe']]]];
  for(const [k,n,items] of sets){const ok=items.filter(([t,id])=>(t==='a'?AR:WP)[id]);if(ok.length<2)continue;const h=ok.filter(([t,id])=>(t==='a'?P.ownA:P.own)[id]).length;if(h>0&&h<ok.length)G.push({key:'s:'+k,kind:'s',n,have:h,tot:ok.length,items:ok,r:h/ok.length})}}
 for(const id of[hlMastW(),P.weapon,...((P.colp&&P.colp.w)||[])]){if(!WP[id]||G.some(g=>g.key==='m:'+id))continue;const t=wTier(id);if(t<5)G.push({key:'m:'+id,kind:'m',id,n:WP[id].n,have:wxp(id),tot:WT[t],t,r:wProg(id)*.95})}
 return G}
function hlGoal(){const G=hlGoals(),pk=P.colg&&P.colg.k;if(pk){let g=G.find(x=>x.key===pk);if(!g&&/^z:\d+$/.test(pk)&&ZN2[+pk.slice(2)]!=null){const x=hlZoneGoal(+pk.slice(2));if(x.have<x.tot)g=x}if(g){g.pinned=1;return g}P.colg=null;save()}
 /* a region the player chose to look at from the plaques (this visit only) */
 if(HL.gv!=null){const g=hlZoneGoal(HL.gv);g.peek=1;return g}
 return G.sort((a,b)=>b.r-a.r)[0]||null}

/* ---------- exhibit painting ---------- */
const HLB={},HLBB={},HLK=()=>Math.min(2,Math.max(1,window.devicePixelRatio||1));
/* a monster's real drawn bounds in its own units, read from the catalog's thumbnail cache, so every creature fits its slot */
function hlBox(id){if(HLBB[id])return HLBB[id];const M=MON[id];if(!FT.get(id)){const c=document.createElement('canvas');c.width=c.height=8;try{fitThumb(c,id)}catch(e){}}
 const im=FT.get(id);if(!im)return HLBB[id]={u0:-40,u1:40,v0:-(M.th||90),v1:0};const s0=Math.min(2.2,470/M.th),cx=M.cx||0;
 return HLBB[id]={u0:(im.x0-450)/s0+cx,u1:(im.x0+im.w-450)/s0+cx,v0:(im.y0-620)/s0,v1:(im.y0+im.h-620)/s0}}
const hlArch=(g,ax,ay,ar,h)=>{g.beginPath();g.moveTo(ax-ar,h);g.lineTo(ax-ar,ay);g.arc(ax,ay,ar,Math.PI,0);g.lineTo(ax+ar,h);g.closePath()};
const HLGEO=(w,h)=>({ax:w/2,ar:w*.355,ay:h*.6,py:h*.865});
function hlPine(g,x,y,s,c){g.fillStyle=c;for(let i=0;i<3;i++){const yy=y-i*s*.32,ww=s*(.46-i*.11);g.beginPath();g.moveTo(x,yy-s*.5);g.lineTo(x-ww,yy);g.lineTo(x+ww,yy);g.closePath();g.fill()}g.fillRect(x-s*.04,y,s*.08,s*.14)}
function hlBG(kind,w,h){const k=HLK(),key=kind+w+'x'+h+'@'+k;if(HLB[key])return HLB[key];const c=document.createElement('canvas');c.width=w*k;c.height=h*k;const g=c.getContext('2d');g.scale(k,k);
 const TH={m:['#1e5a3a','#7affc8','#2a7a4a'],w:['#26388a','#9fb8ff','#3a4aa0'],a:['#7a2a1e','#ffb06a','#9a3a24']}[kind],{ax,ar,ay,py}=HLGEO(w,h);
 let q=g.createLinearGradient(0,0,0,h);q.addColorStop(0,'#1e1636');q.addColorStop(1,'#0b0816');g.fillStyle=q;g.fillRect(0,0,w,h);
 /* dressed stone wall, each block slightly different */
 for(let y=0,r=0;y<h;y+=30,r++)for(let x=-(r%2)*30;x<w;x+=60){const n=Math.sin(x*12.9898+y*78.233)*43758.5453%1;g.fillStyle=`rgba(255,255,255,${.015+Math.abs(n)*.03})`;g.fillRect(x+1.5,y+1.5,57,27)}
 g.save();hlArch(g,ax,ay,ar,h);g.clip();
 if(kind==='m'){q=g.createLinearGradient(0,ay-ar,0,h);q.addColorStop(0,'#0c1830');q.addColorStop(.55,'#14283a');q.addColorStop(1,'#16301f');g.fillStyle=q;g.fillRect(0,0,w,h);
  for(let i=0;i<22;i++){const x=ax-ar+((i*97)%331)/331*ar*2,y=ay-ar+((i*53)%140);g.fillStyle=`rgba(230,240,255,${.25+(i%3)*.2})`;g.fillRect(x,y,1.4,1.4)}
  const mx=ax+ar*.42,my=ay-ar*.58;q=g.createRadialGradient(mx,my,0,mx,my,70);q.addColorStop(0,'#cfe8ff40');q.addColorStop(1,'#cfe8ff00');g.fillStyle=q;g.fillRect(mx-70,my-70,140,140);
  g.fillStyle='#e8f2ff';g.beginPath();g.arc(mx,my,17,0,7);g.fill();g.fillStyle='#c8d8ee';g.beginPath();g.arc(mx-5,my-3,4,0,7);g.arc(mx+6,my+5,3,0,7);g.fill();
  g.fillStyle='#132a28';g.beginPath();g.moveTo(ax-ar,h*.6);g.quadraticCurveTo(ax-ar*.3,h*.42,ax+ar*.2,h*.55);g.quadraticCurveTo(ax+ar*.6,h*.45,ax+ar,h*.52);g.lineTo(ax+ar,h);g.lineTo(ax-ar,h);g.fill();
  for(const [col,y0,s0,n] of[['#122a22',h*.62,54,8],['#16362a',h*.7,66,7],['#1b4430',h*.78,80,6]])for(let i=0;i<n;i++){const x=ax-ar+(i+.5+(Math.sin(i*7.1+y0)*.3))*ar*2/n;hlPine(g,x,y0+Math.sin(i*3.3)*6,s0*(.85+((i*37)%10)/40),col)}
  q=g.createLinearGradient(0,h*.6,0,h*.8);q.addColorStop(0,'#bfe8ff00');q.addColorStop(.5,'#bfe8ff14');q.addColorStop(1,'#bfe8ff00');g.fillStyle=q;g.fillRect(0,h*.6,w,h*.2)}
 else if(kind==='w'){q=g.createLinearGradient(0,ay-ar,0,h);q.addColorStop(0,'#141a40');q.addColorStop(1,'#1a1632');g.fillStyle=q;g.fillRect(0,0,w,h);
  /* tall window with moonlight */
  const wx=ax,wy=ay-ar*.62,ww=46,wh=96;g.save();g.beginPath();g.moveTo(wx-ww/2,wy+wh);g.lineTo(wx-ww/2,wy);g.arc(wx,wy,ww/2,Math.PI,0);g.lineTo(wx+ww/2,wy+wh);g.closePath();q=g.createLinearGradient(0,wy-ww/2,0,wy+wh);q.addColorStop(0,'#5a78c8');q.addColorStop(1,'#26346e');g.fillStyle=q;g.fill();g.strokeStyle='#0e1230';g.lineWidth=3;g.stroke();g.beginPath();g.moveTo(wx,wy-ww/2);g.lineTo(wx,wy+wh);g.moveTo(wx-ww/2,wy+wh*.45);g.lineTo(wx+ww/2,wy+wh*.45);g.stroke();g.restore();
  q=g.createLinearGradient(0,wy,0,h);q.addColorStop(0,'#9fb8ff26');q.addColorStop(1,'#9fb8ff00');g.fillStyle=q;g.beginPath();g.moveTo(wx-ww/2,wy+wh*.2);g.lineTo(wx+ww/2,wy+wh*.2);g.lineTo(wx+ar*.55,h);g.lineTo(wx-ar*.15,h);g.closePath();g.fill();
  /* weapon rack */
  const ry=h*.3;for(const x of[ax-ar*.86,ax+ar*.86]){q=g.createLinearGradient(x-6,0,x+6,0);q.addColorStop(0,'#6a4426');q.addColorStop(1,'#3a2414');g.fillStyle=q;g.fillRect(x-6,ry-6,12,py-ry)}
  q=g.createLinearGradient(0,ry-7,0,ry+7);q.addColorStop(0,'#7a5030');q.addColorStop(1,'#3a2414');g.fillStyle=q;g.fillRect(ax-ar*.9,ry-7,ar*1.8,14);g.fillStyle='#c8963a';for(const x of[ax-ar*.86,ax+ar*.86]){g.beginPath();g.arc(x,ry,5,0,7);g.fill()}
  g.fillStyle='#ffffff08';for(let i=-1;i<=1;i++)g.fillRect(ax+i*ar*.6-ar*.2,ry+12,ar*.4,py-ry-22)}
 else{q=g.createLinearGradient(0,ay-ar,0,h);q.addColorStop(0,'#2a1414');q.addColorStop(1,'#1c1010');g.fillStyle=q;g.fillRect(0,0,w,h);
  /* hearth at the back */
  const hx=ax,hy=py-8,hw=70,hh=58;g.fillStyle='#3a2418';g.beginPath();g.moveTo(hx-hw-10,hy);g.lineTo(hx-hw-10,hy-hh);g.arc(hx,hy-hh,hw+10,Math.PI,0);g.lineTo(hx+hw+10,hy);g.fill();
  q=g.createRadialGradient(hx,hy-10,4,hx,hy-20,hw*1.2);q.addColorStop(0,'#ff9a3a');q.addColorStop(.35,'#a8401a');q.addColorStop(1,'#1a0a06');g.fillStyle=q;g.beginPath();g.moveTo(hx-hw,hy);g.lineTo(hx-hw,hy-hh);g.arc(hx,hy-hh,hw,Math.PI,0);g.lineTo(hx+hw,hy);g.fill();
  /* shields and crossed spears on the wall */
  for(const [x,col] of[[ax-ar*.66,'#5a6a8a'],[ax+ar*.66,'#8a4a3a']]){const y=h*.32;g.strokeStyle='#6a5a4a';g.lineWidth=3;g.beginPath();g.moveTo(x-26,y-26);g.lineTo(x+26,y+26);g.moveTo(x+26,y-26);g.lineTo(x-26,y+26);g.stroke();
   q=g.createRadialGradient(x-6,y-6,2,x,y,22);q.addColorStop(0,col);q.addColorStop(1,'#1a1418');g.fillStyle=q;g.beginPath();g.arc(x,y,20,0,7);g.fill();g.strokeStyle='#c8963a';g.lineWidth=2.5;g.stroke();g.fillStyle='#c8963a';g.beginPath();g.arc(x,y,5,0,7);g.fill()}}
 g.restore();
 /* the stone arch, keystone and pillars */
 g.lineWidth=20;g.strokeStyle='#33294a';hlArch(g,ax,ay,ar+10,h+20);g.stroke();g.lineWidth=2;g.strokeStyle='#5a4a72';hlArch(g,ax,ay,ar+1,h+20);g.stroke();g.strokeStyle='#1a1428';hlArch(g,ax,ay,ar+20,h+20);g.stroke();
 g.strokeStyle='#4a3e62';for(let i=1;i<12;i++){const a=Math.PI+i*Math.PI/12;g.beginPath();g.moveTo(ax+Math.cos(a)*(ar+1),ay+Math.sin(a)*(ar+1));g.lineTo(ax+Math.cos(a)*(ar+19),ay+Math.sin(a)*(ar+19));g.stroke()}
 g.fillStyle='#4a3e62';g.beginPath();g.moveTo(ax-11,ay-ar-21);g.lineTo(ax+11,ay-ar-21);g.lineTo(ax+8,ay-ar+3);g.lineTo(ax-8,ay-ar+3);g.closePath();g.fill();g.strokeStyle='#c8963a';g.lineWidth=1.5;g.stroke();
 g.fillStyle=TH[1];g.beginPath();g.arc(ax,ay-ar-9,3.5,0,7);g.fill();
 /* hanging banners */
 for(const x of[w*.075,w*.925]){g.fillStyle='#8a6a3a';g.fillRect(x-20,h*.08,40,3);q=g.createLinearGradient(0,h*.09,0,h*.5);q.addColorStop(0,TH[2]);q.addColorStop(1,TH[0]);g.fillStyle=q;g.beginPath();g.moveTo(x-15,h*.09);g.lineTo(x+15,h*.09);g.lineTo(x+15,h*.5);g.lineTo(x,h*.44);g.lineTo(x-15,h*.5);g.closePath();g.fill();g.strokeStyle='#c8963a';g.lineWidth=1.5;g.stroke();
  g.strokeStyle=TH[1]+'aa';g.beginPath();g.arc(x,h*.24,7,0,7);g.stroke();g.fillStyle=TH[1]+'aa';g.beginPath();g.arc(x,h*.24,2.5,0,7);g.fill()}
 /* the display platform with a pool of light */
 for(const [rx,ry,dy,c0,c1] of[[w*.43,22,10,'#2a2238','#120e1c'],[w*.39,18,0,'#5e4e3e','#2a2018']]){g.fillStyle=c1;g.beginPath();g.ellipse(ax,py+dy+7,rx,ry,0,0,7);g.fill();q=g.createLinearGradient(0,py+dy-ry,0,py+dy+ry);q.addColorStop(0,c0);q.addColorStop(1,c1);g.fillStyle=q;g.beginPath();g.ellipse(ax,py+dy,rx,ry,0,0,7);g.fill()}
 g.strokeStyle='#c8963a88';g.lineWidth=1.5;g.beginPath();g.ellipse(ax,py,w*.39,18,0,0,7);g.stroke();
 q=g.createRadialGradient(ax,py,4,ax,py,w*.36);q.addColorStop(0,TH[1]+'30');q.addColorStop(1,TH[1]+'00');g.fillStyle=q;g.beginPath();g.ellipse(ax,py,w*.36,16,0,0,7);g.fill();
 if(kind==='m'){g.fillStyle='#2e5a26';g.beginPath();g.ellipse(ax,py-3,w*.35,13,0,0,7);g.fill();g.fillStyle='#3e7a32';g.beginPath();g.ellipse(ax,py-5,w*.31,10,0,0,7);g.fill();
  for(let i=0;i<26;i++){const x=ax-w*.3+i*w*.6/25,y=py-5+Math.sin(i*2.1)*4;g.strokeStyle=i%2?'#5aa040':'#4a8a36';g.lineWidth=1.4;g.beginPath();g.moveTo(x,y);g.lineTo(x+Math.sin(i)*2,y-5-(i%3)*2);g.stroke()}
  g.fillStyle='#5e5e6e';g.beginPath();g.ellipse(ax+w*.24,py-8,14,7,0,0,7);g.fill();g.fillStyle='#7a7a8a';g.beginPath();g.ellipse(ax+w*.235,py-10,9,4,0,0,7);g.fill();
  for(const [x,c] of[[-.31,'#c83a2a'],[.31,'#e8b04a'],[-.18,'#c83a2a']]){g.fillStyle='#e8dcc0';g.fillRect(ax+w*x-1.5,py-14,3,8);g.fillStyle=c;g.beginPath();g.ellipse(ax+w*x,py-14,6,4,0,Math.PI,0);g.fill()}}
 else{g.strokeStyle=TH[1]+'55';g.lineWidth=1.5;g.setLineDash([4,7]);g.beginPath();g.ellipse(ax,py-1,w*.32,12,0,0,7);g.stroke();g.setLineDash([])}
 return HLB[key]=c}
/* a soft vignette laid over the finished scene */
function hlVig(w,h){const key='v'+w+'x'+h+'@'+HLK();if(HLB[key])return HLB[key];const k=HLK(),c=document.createElement('canvas');c.width=w*k;c.height=h*k;const g=c.getContext('2d');g.scale(k,k);
 const q=g.createRadialGradient(w/2,h*.55,h*.3,w/2,h*.55,w*.68);q.addColorStop(0,'#00000000');q.addColorStop(1,'#000000a0');g.fillStyle=q;g.fillRect(0,0,w,h);return HLB[key]=c}
function hlTorch(g,x,y,t){const f=Math.sin(t*9+x)*1.6+Math.sin(t*5.3)*1.2;g.save();g.translate(x,y);g.fillStyle='#2a1e14';g.fillRect(-3,0,6,18);g.fillStyle='#6a5a44';g.fillRect(-7,-3,14,4);
 g.globalCompositeOperation='lighter';ncGlow(g,0,-10,52+f*2,'#ff8a2a30');g.fillStyle='#ff6a1a';g.beginPath();g.moveTo(-6,-1);g.quadraticCurveTo(-7,-13,f*.4,-26-f);g.quadraticCurveTo(7,-13,6,-1);g.closePath();g.fill();g.fillStyle='#ffd45a';g.beginPath();g.moveTo(-3,-1);g.quadraticCurveTo(-4,-8,f*.25,-16);g.quadraticCurveTo(4,-8,3,-1);g.closePath();g.fill();g.restore()}
/* a few drifting motes per room: fireflies, dust in the moonlight, embers from the hearth */
function hlMotes(g,kind,w,h,t){g.save();g.globalCompositeOperation='lighter';const n=kind==='w'?10:8;
 for(let i=0;i<n;i++){const ph=i*2.399,fx=(i*.618)%1,fy=(i*.382)%1;
  if(kind==='m'){const x=w*(.2+.6*fx)+Math.sin(t*.45+ph)*14,y=h*(.34+.36*fy)+Math.sin(t*.6+ph*1.3)*9,a=Math.max(0,Math.sin(t*1.1+ph));if(a<.02)continue;ncGlow(g,x,y,7,'#d8ff7a'+ncA(a*.5));g.fillStyle='#f4ffc0'+ncA(a*.9);g.fillRect(x-1,y-1,2,2)}
  else if(kind==='w'){const r=(t*.02+i*.11)%1,x=w*(.42+.24*fx)+r*w*.08+Math.sin(t*.35+ph)*5,y=h*(.86-r*.62),a=Math.sin(r*Math.PI)*.55;g.fillStyle='#d8e4ff'+ncA(a);g.beginPath();g.arc(x,y,1.2,0,7);g.fill()}
  else{const r=(t*.09+i*.137)%1,x=w*(.5+(fx-.5)*.32)+Math.sin(t*1.1+ph)*7*r,y=h*(.8-r*.42),a=(1-r)*.75;ncGlow(g,x,y,4,'#ffb04a'+ncA(a*.55));g.fillStyle='#ffd08a'+ncA(a);g.fillRect(x-1,y-1,2,2)}}
 g.restore()}
/* where each creature stands: three ground places and one in the air, each sized to the creature's real outline */
function hlStage(ids,w,h){const gy=HLGEO(w,h).py-2,G=[[.5,gy,170,124,2],[.27,gy-8,124,98,1],[.73,gy-8,124,98,1]],A=[[.65,h*.3,112,66,3]],out=[];let gi=0,ai=0;
 for(const id of ids){const M=MON[id];if(!M)continue;let sl,air=0;if(M.fly&&ai<A.length){sl=A[ai++];air=1}else if(gi<G.length)sl=G[gi++];else continue;
  const b=hlBox(id),bw=b.u1-b.u0,bh=b.v1-b.v0,s=Math.min(sl[3]/bh,sl[2]/bw,1.8),X=w*sl[0];
  out.push({id,air,s,X,Y:sl[1],ox:X+(b.u0+b.u1)/2*s,oy:air?sl[1]-(b.v0+b.v1)/2*s:sl[1]-b.v1*s,bw:bw*s,bh:bh*s,z:sl[4]})}
 return out.sort((a,b)=>a.z-b.z)}
const hlEase=u=>u<0?0:u>1?1:u*u*(3-2*u);
function hlPaint(kind,cv,o){const w=460,h=300,k=HLK(),g=cv.getContext('2d'),bg=hlBG(kind,w,h),vg=hlVig(w,h),{ax,ar,ay,py}=HLGEO(w,h),rm=HL.rm();
 cv.width=w*k;cv.height=h*k;o.hv=o.hv||{};o.hits=[];
 const stage=kind==='m'?hlStage(o.ids,w,h):null;
 const xs=kind==='w'?(o.ids.length===1?[.5]:o.ids.length===2?[.36,.64]:[.28,.5,.72]):null;
 const tip=cv.parentNode.querySelector('.hltip');let tipId=null;
 const ease=(id,on)=>{const v=o.hv[id]||0,z=on?1:0;return o.hv[id]=rm?z:v+(z-v)*.28};
 return t0=>{const t=rm?1.3:t0;o.lastT=t;g.setTransform(k,0,0,k,0,0);g.drawImage(bg,0,0,w,h);hlTorch(g,ax-ar-1,h*.5,t);hlTorch(g,ax+ar+1,h*.5,t+1.7);const hits=[];
  if(kind==='m'){if(!stage.length){g.fillStyle='#0a0618b0';g.beginPath();g.roundRect(w/2-120,h*.55-24,240,52,12);g.fill();g.fillStyle='#ffffffaa';g.font='600 16px Poppins,system-ui';g.textAlign='center';g.fillText('No creatures discovered yet',w/2,h*.55);g.font='500 12px Poppins,system-ui';g.fillStyle='#ffffff77';g.fillText('Play a run to fill this hall',w/2,h*.55+20)}
   hlMotes(g,'m',w,h,t);
   stage.forEach((m,i)=>{const M=MON[m.id],hov=o.hit===m.id,e=ease(m.id,hov),nw=o.nw.includes(m.id);
    /* drifting flyers, breathing ground creatures; a hovered creature comes fully alive */
    const dx=m.air?Math.sin(t*.38+i)*16:0,dy=m.air?Math.sin(t*1.25+i)*4:-e*3;
    const top=m.air?m.Y-m.bh/2+dy:m.Y-m.bh+dy;hits.push({id:m.id,x:m.X+dx-m.bw/2,y:top,w:m.bw,h:m.bh});
    if(!m.air){g.fillStyle='#00000055';g.beginPath();g.ellipse(m.X,m.Y+1,m.bw*.42,5,0,0,7);g.fill()}
    else{g.fillStyle='#00000030';g.beginPath();g.ellipse(m.X+dx,py-2,m.bw*.25,3.5,0,0,7);g.fill()}
    if(e>.01||nw){g.save();g.globalCompositeOperation='lighter';ncGlow(g,m.X+dx,top+m.bh*.55,m.bh*.75,(nw&&e<.5?'#fff2a0':'#ffd45a')+ncA((nw?.18+.1*Math.sin(t*3):0)+e*.32));g.restore()}
    const live=m.air||hov||rm,tt=live?t+i*.7:1.2,br=live?1:1+Math.sin(t*1.6+i*1.9)*.012;
    g.save();g.translate(m.ox+dx,m.oy+dy+(m.air?0:m.bh*(1-br)));g.scale(-m.s,m.s*br);try{M.d(g,tt,{lg:0})}catch(err){}g.restore();
    /* the shaman's staff (and other summoners) give off a slow pulse */
    if(m.id==='shaman'||M.tr==='summon'){const p=.5+.5*Math.sin(t*2.1+i),sx=m.X+dx+m.bw*.36,sy=top+m.bh*.1;g.save();g.globalCompositeOperation='lighter';ncGlow(g,sx,sy,10+p*10,(m.id==='shaman'?'#c8ff5a':'#b89aff')+ncA(.2+p*.3));g.restore()}
    if(nw)for(let j=0;j<3;j++){const a=t*1.4+j*2.09,r=m.bw*.42;const tw=Math.max(0,Math.sin(t*3+j*2));ncStar(g,m.X+dx+Math.cos(a)*r,top+m.bh*.45+Math.sin(a)*m.bh*.32,3+tw*3,'#fff6c0'+ncA(.4+tw*.6))}})}
  else if(kind==='w'){const L=o.ids;
   L.forEach((id,i)=>{const it=WP[id],eq=id===P.weapon,x=w*xs[i],base=py-6,hov=o.hit===id,e=ease(id,hov),len=h*(eq?.56:.45),lift=e*7,col=it.col||'#9fb8ff';
    hits.push({id,x:x-26,y:base-len-lift,w:52,h:len+18});
    /* peg on the rack, stand on the floor */
    g.fillStyle='#c8963a';g.beginPath();g.arc(x,h*.3,3,0,7);g.fill();
    g.fillStyle=eq?'#4a3268':'#2e2a40';g.beginPath();g.ellipse(x,base+2,eq?30:24,7,0,0,7);g.fill();g.strokeStyle=col+'aa';g.lineWidth=1.5;g.stroke();
    g.save();g.globalCompositeOperation='lighter';ncGlow(g,x,base-len*.5-lift,len*.55,col+ncA((eq?.18:.1)+e*.22));if(eq){const q=g.createLinearGradient(0,0,0,base);q.addColorStop(0,col+'00');q.addColorStop(1,col+'22');g.fillStyle=q;g.beginPath();g.moveTo(x-12,0);g.lineTo(x+12,0);g.lineTo(x+34,base);g.lineTo(x-34,base);g.closePath();g.fill()}g.restore();
    g.save();g.translate(x,base-lift);g.rotate(-Math.PI/2+.08);try{drawW(g,id,len,rm?1:t)}catch(err){}g.restore();
    /* now and then a highlight runs up the blade (violet on the Moonblade) */
    const per=eq?4.2:6.5,u=((t+i*2.3)%per)/1.1;if(u<1&&!rm){const yy=base-lift-len*(.15+u*.8),xx=x+Math.sin(.08)*len*(.15+u*.8);g.save();g.globalCompositeOperation='lighter';ncGlow(g,xx,yy,13,(id==='moon'?'#c79bff':col)+'cc');ncStar(g,xx,yy,5+Math.sin(u*Math.PI)*3,'#ffffffdd');g.restore()}
    if(o.nw.includes(id)){g.save();g.globalCompositeOperation='lighter';ncGlow(g,x,base-len*.5,52,'#fff2a0'+ncA(.16+.1*Math.sin(t*3)));g.restore()}
    /* brass nameplate; an "Equipped" ribbon over the weapon you carry */
    g.font='600 10.5px Poppins,system-ui';g.textAlign='center';g.textBaseline='middle';let nm=it.n;while(g.measureText(nm).width>84&&nm.length>3)nm=nm.slice(0,-2)+'…';
    const pw=Math.min(96,g.measureText(nm).width+18),pyy=h-14;let q=g.createLinearGradient(0,pyy-8,0,pyy+8);q.addColorStop(0,eq?'#ffe08a':'#c8a060');q.addColorStop(1,eq?'#c88a2a':'#8a6436');g.fillStyle=q;g.beginPath();g.roundRect(x-pw/2,pyy-8,pw,16,4);g.fill();g.fillStyle='#2a1406';g.fillText(nm,x,pyy+.5);
    if(eq){const ry=Math.max(12,base-len-lift-16);g.fillStyle='#7a3ab8';g.beginPath();g.moveTo(x-40,ry-8);g.lineTo(x+40,ry-8);g.lineTo(x+34,ry);g.lineTo(x+40,ry+8);g.lineTo(x-40,ry+8);g.lineTo(x-34,ry);g.closePath();g.fill();g.strokeStyle='#e8c36a';g.lineWidth=1.2;g.stroke();g.fillStyle='#fff';g.font='800 9.5px Poppins,system-ui';g.fillText('EQUIPPED',x,ry+.5)}
    g.textBaseline='alphabetic'});
   hlMotes(g,'w',w,h,t)}
  else{hlMotes(g,'a',w,h,t);
   /* the hearth breathes */
   g.save();g.globalCompositeOperation='lighter';ncGlow(g,ax,py-26,70+Math.sin(t*2.3)*6,'#ff8a2a'+ncA(.14+.05*Math.sin(t*3.1)));g.restore();
   const s=h*.48/150,hero=(id,x,a)=>{if(!id)return;g.save();g.globalAlpha=a;g.translate(x,py-3);g.scale(s,s);
    /* every so often the mannequin shifts its stance */
    const ph=(t+2)%9,pu=rm?0:ph<1.6?Math.sin(ph/1.6*Math.PI)*.55:0;try{drawHero(g,{arm:id,wp:P.weapon,col:P.col,t,pose:pu>0?'victory':'',pu})}catch(err){}g.restore()};
   g.fillStyle='#00000055';g.beginPath();g.ellipse(ax,py,36,6,0,0,7);g.fill();
   const sw=o.sw,u=sw&&!rm?hlEase((t-sw.t0)/.42):1;
   if(u<1){hero(sw.from,ax-sw.d*44*u,1-u);hero(o.cur(),ax+sw.d*44*(1-u),u);g.save();g.globalCompositeOperation='lighter';const r=30+u*60;ncGlow(g,ax,py-60,r,'#ffb06a'+ncA((1-u)*.35));g.restore()}
   else hero(o.cur(),ax,1);
   hits.push({id:o.cur(),x:ax-44,y:py-h*.5,w:88,h:h*.5})}
  g.drawImage(vg,0,0,w,h);o.hits=hits;
  /* name tag that follows the hovered object */
  if(tip){const hi=hits.find(z=>z.id===o.hit);const nid=hi?o.hit:null;if(nid!==tipId){tipId=nid;if(nid){const nm=(kind==='m'?MON:kind==='w'?WP:AR)[nid].n;tip.innerHTML=`<b>${esc(nm)}</b><span>${kind==='a'?'Open in Armor':'Open entry'} ›</span>`}tip.classList.toggle('on',!!nid)}
   if(hi){tip.style.left=(hi.x+hi.w/2)/w*100+'%';tip.style.top=Math.max(4,hi.y-6)/h*100+'%'}}}}

/* ---------- the hall ---------- */
function hlBar(a,b){return `<span class="hlbar"><i style="width:${b?Math.round(a/b*100):0}%"></i></span>`}
const HLIC={m:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 4l4 5h8l4-5v8a8 8 0 0 1-16 0z" fill="currentColor"/><circle cx="9" cy="13" r="1.6" fill="#1a1028"/><circle cx="15" cy="13" r="1.6" fill="#1a1028"/></svg>',
 w:'<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M20 4L9 15M20 4h-4M20 4v4M7 13l4 4M5 19l3-3"/></svg>',
 a:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2l8 3v6c0 5-3.4 9.4-8 11-4.6-1.6-8-6-8-11V5z" fill="currentColor"/></svg>',
 z:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2l5 8h-3l4 6h-4l2 4h-8l2-4H6l4-6H7z" fill="currentColor"/></svg>',
 s:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2l2.6 6.6L21 9l-5 4.4L17.6 21 12 17l-5.6 4L8 13.4 3 9l6.4-.4z" fill="currentColor"/></svg>',
 pin:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 3l6 6-3 1-4 4 1 5-2 1-4-4-5 5-1-1 5-5-4-4 1-2 5 1 4-4z" fill="currentColor"/></svg>'};
function catHall(back){S.mode='title';S.view='menu';const S2=hlStats(),nw=hlNew(),goal=hlGoal(),eqw=P.weapon,arms=hlArmOwned();let ai=Math.max(0,arms.indexOf(P.armor));
 const ex=(k,t,col,cnt,tot,word,btn,extra)=>{const n=nw[k].length,prev=Math.max(0,cnt-n);return `<div class="hlx" data-x="${k}" tabindex="0" role="button" aria-label="${btn}" style="--c:${col}">
  <div class="hlban"><span class="hlbi">${HLIC[k]}</span></div><h3>${t}</h3><p class="hlct"><b data-cu="${cnt}" data-from="${prev}">${n?prev:cnt}</b> of ${tot} ${word}</p>${hlBar(cnt,tot)}
  <div class="hlsc"><canvas width="460" height="300" data-hx="${k}"></canvas><span class="hlact">${btn} ›</span><span class="hltip"></span>${extra||''}${tot&&cnt>=tot?'<span class="hldone">★ Complete</span>':''}</div>
  ${n?`<button class="hlnew" data-nw="${k}" title="Open the newest find">NEW · ${n}</button>`:''}
  <div class="hlbt"><button class="hlgo" data-go="${k}">${HLIC[k]}<span>${btn}</span><i>›</i></button>${k!=='a'?`<button class="hlpin" data-pk="${k}" title="Choose what is on display" aria-label="Choose what is on display">✎</button>`:''}</div></div>`};
 const armCard=()=>{const id=arms[ai];if(!id)return'';const A=AR[id],worn=P.armor===id;return `<div class="hlac" data-ak="${id}"><canvas width="72" height="96" data-ac="${id}"></canvas><span><b style="color:${A.col}">${esc(A.n)}</b><em>${A.r} · ${worn?'<i class="hlwn">Worn</i>':'Preview'}</em><small>${esc(A.d||'No bonus')}</small></span><span class="hlai">${ai+1} / ${arms.length}</span></div>`};
 /* the goal panel */
 let gp='',gkind=goal?goal.kind:'x';
 if(goal&&goal.kind==='z'){const left=goal.tot-goal.have,lv=LEVELS.findIndex(l=>l.z===goal.z)+1,open=lv&&lv<=cmCur();
  gp=`<div class="hlgh"><span class="hlgi">${HLIC.z}</span><div><b>${goal.n}</b><span>${goal.have} of ${goal.tot} discovered</span></div>${hlBar(goal.have,goal.tot)}</div>
  <div class="hlgs">${goal.ids.map((id,i)=>hlSeen(id)?`<button class="hlpt" data-pm="${id}" title="${esc(MON[id].n)}" style="--d:${i*45}ms"><canvas width="128" height="128" data-gm="${id}"></canvas></button>`:`<span class="hlpt hlnf" title="Not discovered yet" style="--d:${i*45}ms"><canvas width="128" height="128" data-gm="${id}"></canvas><i>?</i></span>`).join('')}</div>
  <p class="hlgt">${left===0?`Every creature in ${goal.n} has been discovered.`:goal.have===0?`${goal.tot} creatures wait in ${goal.n}. Play this region to meet them.`:left===1?`One creature remains undiscovered in ${goal.n}.`:`${left} creatures remain undiscovered in ${goal.n}.`}</p>
  <div class="hlga"><button class="hlgo b" data-gz="${goal.z}"><span>${open||!lv?'View campaign':'Continue campaign'}</span><i>›</i></button>${goal.peek?'<button class="hlsoft" id="hlgx">Back to suggestion</button>':''}</div>`}
 else if(goal&&goal.kind==='s'){gp=`<div class="hlgh"><span class="hlgi">${HLIC.s}</span><div><b>${goal.n}</b><span>${goal.have} of ${goal.tot} pieces owned</span></div>${hlBar(goal.have,goal.tot)}</div><div class="hlgs">${goal.items.map(([t,id],i)=>{const own=(t==='a'?P.ownA:P.own)[id];return `<span class="hlpt${own?'':' hlnf'}" title="${esc((t==='a'?AR:WP)[id].n)}" style="--d:${i*45}ms"><canvas width="128" height="128" data-gi="${t}:${id}"></canvas>${own?'':'<i>?</i>'}</span>`}).join('')}</div><p class="hlgt">Own every piece to unlock the set bonus.</p><div class="hlga"><button class="hlgo b" data-gs="1"><span>Find it in the Shop</span><i>›</i></button></div>`}
 else if(goal&&goal.kind==='m'){gp=`<div class="hlgh"><span class="hlgi">${HLIC.w}</span><div><b>${esc(goal.n)}</b><span>${goal.have.toLocaleString()} / ${goal.tot.toLocaleString()} XP to ${WTN[goal.t+1]}</span></div>${hlBar(goal.have,goal.tot)}</div><p class="hlgt">Win runs with this weapon equipped to reach the next mastery tier.</p><div class="hlga"><button class="hlgo b" data-gw="1"><span>Open the Armory</span><i>›</i></button></div>`}
 else{const last=S2.monSeen[S2.monSeen.length-1];gp=last?`<div class="hlgh"><span class="hlgi">${HLIC.s}</span><div><b>Recent discovery</b><span>${esc(MON[last].n)}</span></div></div><div class="hlgs"><button class="hlpt" data-pm="${last}"><canvas width="128" height="128" data-gm="${last}"></canvas></button></div><p class="hlgt">Nothing is close to complete right now. Head out to find something new.</p>`:`<p class="hlgt">Play a run to start your collection.</p>`}
 const plaques=ZN2.map((n,z)=>{const ids=hlZoneIds(z),s=ids.filter(hlSeen).length,done=s===ids.length,cur=goal&&goal.kind==='z'&&goal.z===z;return `<button class="hlpq${done?' done':''}${cur?' hlcur':''}" data-pz="${z}" title="${n}: ${s} / ${ids.length}${done?' · complete':''}">${done?'★ ':''}${n}<small>${s}/${ids.length}</small></button>`}).join('');
 /* weapon mastery, for any weapon you own */
 const mw=()=>Object.keys(WP).filter(k=>P.own[k]).sort((a,b)=>(b===P.weapon)-(a===P.weapon)||wTier(b)-wTier(a)||RKM[WP[b].r]-RKM[WP[a].r]);
 const mastHTML=()=>{const id=hlMastW(),W=WP[id]||{},wt=wTier(id),nx=wt>=5?null:WT[wt],n=mw().length;return `<div class="hlmr">${n>1?'<button class="hlmar" data-mw="-1" aria-label="Previous weapon">‹</button>':''}<canvas width="192" height="192" id="hlmw"></canvas>${n>1?'<button class="hlmar" data-mw="1" aria-label="Next weapon">›</button>':''}<div><b style="color:${W.col}">${esc(W.n||'')}</b><em>${W.r||''}${id===P.weapon?' · Equipped':''}</em><small>${esc(W.d||'')}</small></div></div>
   <div class="hltp">${[1,2,3,4,5].map(i=>`<i class="${i<=wt?'on':''}${i===wt+1?' nx':''}" title="${WTN[i]}">${WROM[i]}</i>`).join('')}</div>
   <div class="hlmt"><span>Mastery <b>${WTN[wt]}</b></span><span>${nx?`${wxp(id).toLocaleString()} / ${nx.toLocaleString()} XP`:'Fully mastered'}</span></div>${hlBar(nx?wxp(id):1,nx||1)}`};
 show(`<div class="chl" id="chl"><header class="hlh"><h2>Collection</h2><div class="tabs ctabs hltabs" role="tablist">${ctabs().map(c=>`<button class="tab${c==='Overview'?' on':''}" data-ct="${c}" role="tab" aria-selected="${c==='Overview'}">${c}</button>`).join('')}</div></header>
 <div class="hlgrid">${ex('m','Monsters','#7affc8',S2.monSeen.length,S2.mon.length,'discovered','View monsters',`<span class="hlsub">${S2.monDef.length} defeated · ${S2.kills.toLocaleString()} kills</span>`)}
 ${ex('w','Weapons','#9fb8ff',S2.wOwn.length,S2.wpn.length,'owned','View weapons')}
 ${ex('a','Armor','#ffb06a',S2.aOwn.length,S2.arm.length,'owned','Browse armor',`<div class="hlarm">${arms.length>1?`<button class="hlarw l" data-aw="-1" aria-label="Previous outfit">‹</button><button class="hlarw r" data-aw="1" aria-label="Next outfit">›</button>`:''}<div class="hlacw">${armCard()}</div></div>`)}</div>
 <div class="hlbot"><section class="hlgoal hl-${gkind}"><div class="hlgtop"><h3>${goal?(goal.peek?'Region':goal.r>=.5?'Almost Complete':'Next Goal'):'Collection'}</h3>${goal&&!(goal.kind==='z'&&goal.have>=goal.tot)?`<button class="hlpinb${goal.pinned?' on':''}" id="hlpg" title="${goal.pinned?'Unpin this goal':'Keep this goal here until it is done'}">${HLIC.pin}<span>${goal.pinned?'Pinned':'Pin goal'}</span></button>`:''}</div><div class="hlgb">${gp}</div><div class="hlpqs">${plaques}</div></section>
  <section class="hlmast"><h3>Weapon Mastery</h3><div id="hlmp">${mastHTML()}</div><button class="hlgo b" id="hlmv"><span>View mastery</span><i>›</i></button></section></div>
 <div class="hlmod" id="hlmod"></div><div class="row"><button class="sm" id="b">Back</button></div></div>`,'m');
 const sc=()=>hlScr();
 S.back=()=>{const m=$('hlmod');if(m&&m.classList.contains('on')){hlModClose();return}HL.gv=null;back()};$('b').onclick=S.back;
 const keep=()=>{HL.sc.Overview=sc().scrollTop},redraw=()=>{keep();catHall(back)};
 sc().scrollTop=HL.sc.Overview||0;
 ov.querySelectorAll('[data-ct]').forEach(el=>el.onclick=()=>{keep();catalog(back,el.dataset.ct)});
 const go={m:'Monsters',w:'Weapons',a:'Armor'};
 const open=(k,focus)=>{keep();hlClear(k);beep(560,.04,'triangle',.25);catalog(back,go[k]);if(focus)setTimeout(()=>hlFocus(k,focus),40)};
 ov.querySelectorAll('.hlx').forEach(x=>{x.onclick=e=>{if(e.target.closest('button'))return;open(x.dataset.x)};
  x.onkeydown=e=>{if(e.target!==x)return;if(e.key==='Enter'||e.key===' '){e.preventDefault();open(x.dataset.x)}else if(x.dataset.x==='a'&&(e.key==='ArrowLeft'||e.key==='ArrowRight')){e.preventDefault();cycle(e.key==='ArrowLeft'?-1:1)}}});
 ov.querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>open(b.dataset.go));
 ov.querySelectorAll('[data-nw]').forEach(b=>b.onclick=()=>{const k=b.dataset.nw;open(k,nw[k][0])});
 ov.querySelectorAll('[data-pk]').forEach(b=>b.onclick=()=>hlPick(b.dataset.pk,back));
 const pg=$('hlpg');if(pg)pg.onclick=()=>{P.colg=goal.pinned?null:{k:goal.key};if(!goal.pinned)HL.gv=null;save();beep(goal.pinned?440:700,.05,'triangle',.3);redraw()};
 const gx=$('hlgx');if(gx)gx.onclick=()=>{HL.gv=null;redraw()};
 ov.querySelectorAll('[data-pz]').forEach(b=>b.onclick=()=>{const z=+b.dataset.pz;if(P.colg&&P.colg.k!=='z:'+z){b.classList.add('hlno');setTimeout(()=>b.classList.remove('hlno'),420);const p=$('hlpg');if(p){p.classList.add('hlno');setTimeout(()=>p.classList.remove('hlno'),420)}return}HL.gv=z;redraw()});
 ov.querySelectorAll('[data-pm]').forEach(b=>b.onclick=()=>open('m',b.dataset.pm));
 ov.querySelectorAll('[data-gz]').forEach(b=>b.onclick=()=>{const z=+b.dataset.gz,cur=cmCur(),lv=LEVELS.findIndex(l=>l.z===z)+1;keep();campaign(Math.max(1,Math.min(cur,lv||cur)))});
 ov.querySelectorAll('[data-gs]').forEach(b=>b.onclick=()=>{keep();shop()});ov.querySelectorAll('[data-gw]').forEach(b=>b.onclick=()=>{keep();armory()});$('hlmv').onclick=()=>{keep();armory()};
 /* exhibit paintings: three live canvases at half rate; they pause off screen and stop once the menu is gone */
 const cvs=k=>ov.querySelector(`canvas[data-hx="${k}"]`),O={m:{ids:hlMonShow(),nw:nw.m},w:{ids:hlWpnShow(),nw:nw.w},a:{cur:()=>arms[ai]}};
 for(const k of'mwa'){const c=cvs(k),o=O[k];LIVE.push({cv:c,fn:hlPaint(k,c,o),slow:2,ph:k==='w'?1:0});
  const pos=e=>{const r=c.getBoundingClientRect();return[(e.clientX-r.left)/r.width*460,(e.clientY-r.top)/r.height*300]};
  c.onpointermove=e=>{if(e.pointerType==='touch')return;const [x,y]=pos(e),h=[...(o.hits||[])].reverse().find(z=>x>=z.x&&x<=z.x+z.w&&y>=z.y&&y<=z.y+z.h);o.hit=h?h.id:null;c.style.cursor=h?'pointer':''};
  c.onpointerleave=()=>{o.hit=null};
  c.onclick=e=>{const [x,y]=pos(e),h=[...(o.hits||[])].reverse().find(z=>x>=z.x&&x<=z.x+z.w&&y>=z.y&&y<=z.y+z.h);if(h){e.stopPropagation();open(k,h.id)}}}
 if(window.IntersectionObserver){const L3=LIVE.slice(-3),io=new IntersectionObserver(es=>es.forEach(e=>{const L=L3.find(x=>x.cv===e.target);if(L)L.vis=e.isIntersecting}));L3.forEach(L=>{L.fn(S.t||0);io.observe(L.cv)})}
 /* armor: look through owned outfits without changing what you wear */
 const ac=()=>{const c=ov.querySelector('canvas[data-ac]');if(c)try{art(c,'a',c.dataset.ac,0)}catch(e){}};ac();
 const cycle=d=>{if(arms.length<2)return;const from=arms[ai];ai=(ai+d+arms.length)%arms.length;O.a.sw={from,t0:O.a.lastT||S.t||0,d};const w=ov.querySelector('.hlacw');w.innerHTML=armCard();w.firstChild&&w.firstChild.classList&&w.firstChild.classList.add(d>0?'hlinr':'hlinl');ac();beep(620,.04,'triangle',.3)};
 ov.querySelectorAll('[data-aw]').forEach(b=>b.onclick=e=>{e.stopPropagation();cycle(+b.dataset.aw)});
 const acw=ov.querySelector('.hlacw');if(acw)acw.onclick=e=>{e.stopPropagation();open('a',arms[ai])};
 /* mastery weapon selector */
 const mbind=()=>{try{art($('hlmw'),'w',hlMastW(),0)}catch(e){}ov.querySelectorAll('[data-mw]').forEach(b=>b.onclick=()=>{const L=mw();let i=L.indexOf(hlMastW());i=(i+ +b.dataset.mw+L.length)%L.length;P.colmw=L[i];save();beep(660,.04,'triangle',.25);
  if(goal&&goal.kind==='m'&&!goal.pinned)return redraw();const p=$('hlmp');p.innerHTML=mastHTML();p.classList.remove('hlsw');void p.offsetWidth;p.classList.add('hlsw');mbind()})};mbind();
 ov.querySelectorAll('canvas[data-gm]').forEach(c=>{try{fitThumb(c,c.dataset.gm)}catch(e){}});
 ov.querySelectorAll('canvas[data-gi]').forEach(c=>{const [k,id]=c.dataset.gi.split(':');try{art(c,k,id,0)}catch(e){}});
 /* counters roll up from the last visit to now */
 ov.querySelectorAll('[data-cu]').forEach(b=>{const a=+b.dataset.from,z=+b.dataset.cu;if(a===z)return;const t0=performance.now()+450,d=HL.rm()?1:900;const f=t=>{if(!b.isConnected)return;const u=Math.max(0,Math.min(1,(t-t0)/d));b.textContent=Math.round(a+(z-a)*hlEase(u));if(u<1)requestAnimationFrame(f);else{b.classList.add('pop');beep(880,.05,'triangle',.2)}};requestAnimationFrame(f)})}
/* after opening a category from a "New" badge or a scene: scroll to the item and flash it */
function hlFocus(k,id){const sel=k==='m'?`canvas[data-m="${id}"]`:`canvas[data-a="${k}:${id}"]`,c=ov.querySelector(sel);if(!c)return;const card=c.closest('.mcd,.gcd')||c;card.scrollIntoView({behavior:HL.rm()?'auto':'smooth',block:'center'});card.classList.add('hlflash');setTimeout(()=>card.classList.remove('hlflash'),2600)}
function hlModClose(){const m=$('hlmod');if(!m||!m.classList.contains('on'))return;m.classList.add('out');setTimeout(()=>{m.classList.remove('on','out');m.innerHTML=''},180)}
/* choose what stands in an exhibit */
function hlPick(k,back){const m=$('hlmod'),pins=hlPins(),max=k==='m'?4:3,L=k==='m'?hlStats().monSeen:Object.keys(WP).filter(x=>P.own[x]);let sel=pins[k].slice();
 m.innerHTML=`<div class="hlmc" role="dialog" aria-modal="true"><button class="hlx2" aria-label="Close">×</button><h3>${k==='m'?'Choose the creatures on display':'Choose the weapons on display'}</h3><p>Pick up to ${max}. ${k==='w'?'Your equipped weapon always takes the centre.':'Empty places are filled from your newest discoveries.'}</p>
  <div class="hlpk">${L.length?L.map(id=>`<button data-p="${id}"><canvas width="128" height="128" data-pc="${id}"></canvas><span>${esc((k==='m'?MON:WP)[id].n)}</span><em></em></button>`).join(''):'<em class="hlnone">Nothing to show yet.</em>'}</div>
  <div class="hlpkb"><span id="hlpn"></span><button class="hlsoft" id="hlpc">Clear</button><button class="hlgo b" id="hlps"><span>Save display</span></button></div></div>`;
 m.querySelectorAll('canvas[data-pc]').forEach(c=>{try{k==='m'?fitThumb(c,c.dataset.pc):art(c,'w',c.dataset.pc,0)}catch(e){}});
 /* update selection in place so the grid never jumps */
 const sync=()=>{m.querySelectorAll('[data-p]').forEach(b=>{const i=sel.indexOf(b.dataset.p);b.classList.toggle('on',i>=0);b.querySelector('em').textContent=i>=0?i+1:''});$('hlpn').textContent=`${sel.length} / ${max} chosen`};
 m.querySelectorAll('[data-p]').forEach(b=>b.onclick=()=>{const id=b.dataset.p,i=sel.indexOf(id);if(i>=0)sel.splice(i,1);else if(sel.length<max)sel.push(id);else{sel.shift();sel.push(id)}beep(i>=0?480:640,.03,'triangle',.25);sync()});
 m.querySelector('.hlx2').onclick=hlModClose;$('hlpc').onclick=()=>{sel=[];sync()};$('hlps').onclick=()=>{pins[k]=sel;save();HL.sc.Overview=hlScr().scrollTop;catHall(back)};
 sync();m.classList.add('on');m.onclick=e=>{if(e.target===m)hlModClose()};setTimeout(()=>{const f=m.querySelector('[data-p]');if(f)f.focus()},50)}
/* the Collection opens on the hall; the other tabs keep their scroll position and share the hall's header */
{const c0=catalog;catalog=function(back,tab){back=back||title;tab=tab||'Overview';if(catalog.tab&&catalog.tab!==tab&&ov.querySelector('.ctabs'))HL.sc[catalog.tab]=hlScr().scrollTop;catalog.tab=tab;
  if(tab==='Overview')return catHall(back);c0(back,tab);try{const h=ov.querySelector('h2'),tb=ov.querySelector('.ctabs');if(h&&h.textContent==='Catalog')h.textContent='Collection';ov.classList.add('hlcat');
   if(h&&tb&&!h.closest('.hlh')){const hd=document.createElement('header');hd.className='hlh';h.before(hd);hd.append(h,tb)}
   if(HL.sc[tab]!=null&&!ov.querySelector('.hlflash'))hlScr().scrollTop=HL.sc[tab];
   const k={Monsters:'m',Weapons:'w',Armor:'a'}[tab];if(k)hlClear(k);
   /* Back takes you to the hall first */
   const b=$('b');if(b){const ov0=()=>catalog(back,'Overview');b.onclick=ov0;S.back=ov0}}catch(e){}}}

/* ---------- styles: one easing, three durations (fast .18s, base .32s, enter .55s) ---------- */
{const st=document.createElement('style');st.textContent=`
.chl,.hlcat{--ez:cubic-bezier(.2,.9,.3,1);--gold:#ffd45a;--ink:#e8e0ff;--card:linear-gradient(180deg,#1a1236f2,#0c0820f6)}
.chl{position:relative;display:flex;flex-direction:column;gap:14px;width:100%;max-width:1500px;margin:0 auto;padding-bottom:76px;text-align:left}.chl>.row{display:none}
.hlh{display:flex;align-items:center;gap:24px;padding-right:170px;flex-wrap:wrap;animation:hldn .45s var(--ez) both}
@keyframes hldn{from{opacity:0;transform:translateY(-10px)}}
.chl .hlh h2,#ov.hlcat .hlh h2{margin:0;font:400 58px/1 'Pirata One',Georgia,serif;color:var(--gold);text-shadow:0 3px 0 #3a1a00,0 0 22px #ffb02a55;text-align:left}
.hltabs,.hlcat .hlh .ctabs{display:flex;gap:8px;flex-wrap:wrap;margin:0;justify-content:flex-start}
.hltabs .tab,.hlcat .hlh .ctabs .tab{padding:8px 18px;border-radius:12px;font:700 15px var(--ui);background:linear-gradient(180deg,#1e1640,#120c2a);border:1.5px solid #3a3070;color:var(--ink);transition:background .18s,border-color .18s,transform .18s var(--ez),color .18s}
.hltabs .tab:hover,.hlcat .hlh .ctabs .tab:hover{border-color:#8a7cf0;transform:translateY(-1px)}
.hltabs .tab.on,.hlcat .hlh .ctabs .tab.on{background:linear-gradient(180deg,#fff0a0,#f0b030);color:#2a1406;border-color:#fff4b8;box-shadow:0 0 16px #ffb02a55}
.hltabs .tab:nth-child(5),.hlcat .hlh .ctabs .tab:nth-child(5){margin-left:18px}
.hlcat .csum{animation:hlin .4s var(--ez) .05s both}.hlcat .bwrap{animation:hlin .45s var(--ez) .1s both}
.chl button:focus-visible,.hlcat .hlh .tab:focus-visible{outline:2px solid var(--gold);outline-offset:2px}
.hlgrid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}
.hlx{position:relative;display:flex;flex-direction:column;align-items:center;gap:4px;padding:12px 14px 14px;border-radius:20px;cursor:pointer;background:var(--card);border:2px solid color-mix(in srgb,var(--c) 28%,#2a2050);box-shadow:0 10px 24px #000b,inset 0 1px 0 #ffffff10;transition:transform .32s var(--ez),border-color .32s,box-shadow .32s;animation:hlin .55s var(--ez) both;outline:none}
.hlx:nth-child(2){animation-delay:.06s}.hlx:nth-child(3){animation-delay:.12s}
@keyframes hlin{from{opacity:0;transform:translateY(22px)}}
.hlx:hover,.hlx:focus-visible{transform:translateY(-4px);border-color:var(--c);box-shadow:0 0 30px color-mix(in srgb,var(--c) 34%,transparent),0 14px 30px #000c,inset 0 1px 0 #ffffff18}
.hlx:active{transform:translateY(-2px) scale(.995)}
.hlban{position:absolute;top:-6px;left:50%;transform:translateX(-50%);width:62px;height:70px;clip-path:polygon(0 0,100% 0,100% 78%,50% 100%,0 78%);background:linear-gradient(180deg,color-mix(in srgb,var(--c) 45%,#1a1236),#120c28);display:grid;place-items:center;padding-bottom:12px;box-sizing:border-box;transition:height .32s var(--ez)}
.hlx:hover .hlban,.hlx:focus-visible .hlban{height:76px}
.hlbi{display:block;width:32px;height:32px;color:var(--c);filter:drop-shadow(0 0 8px var(--c))}.hlbi svg{width:100%;height:100%}
.hlx h3{margin:58px 0 0;font:400 42px/1 'Pirata One',Georgia,serif;color:var(--gold);text-shadow:0 3px 0 #2a1000}
.hlct{margin:0;font:600 17px var(--ui);color:var(--ink)}.hlct b{display:inline-block;color:#fff;font:800 19px var(--ui);min-width:1ch;text-align:right}.hlct b.pop{animation:hlpop .5s var(--ez)}@keyframes hlpop{40%{transform:scale(1.35);color:var(--gold)}}
.hlbar{display:block;width:78%;height:10px;border-radius:6px;background:#0a0618;border:1px solid #ffffff1c;overflow:hidden}.hlbar i{display:block;height:100%;border-radius:6px;background:linear-gradient(90deg,#ffd45a,#ffb02a);box-shadow:0 0 10px #ffb02a88}
.hlsc{position:relative;width:100%;margin-top:8px;border-radius:14px;overflow:hidden;border:1.5px solid #ffffff14;box-shadow:inset 0 0 0 1px #00000060;transition:border-color .32s}
.hlx:hover .hlsc,.hlx:focus-visible .hlsc{border-color:color-mix(in srgb,var(--c) 55%,transparent)}
.hlsc canvas{display:block;width:100%;height:auto;aspect-ratio:460/300;transition:filter .32s}
.hlx:hover .hlsc canvas,.hlx:focus-visible .hlsc canvas{filter:brightness(1.14) saturate(1.08)}
.hlact{position:absolute;left:50%;top:10px;transform:translate(-50%,-6px);padding:5px 14px;border-radius:12px;font:700 13.5px var(--ui);color:#fff;background:#0a0618d8;border:1.5px solid var(--c);opacity:0;transition:opacity .18s,transform .32s var(--ez);pointer-events:none;white-space:nowrap}
.hlx:hover .hlact,.hlx:focus-visible .hlact{opacity:1;transform:translate(-50%,0)}
.hlx:has(.hltip.on) .hlact{opacity:0}
.hltip{position:absolute;transform:translate(-50%,-100%) translateY(4px);display:flex;flex-direction:column;align-items:center;padding:4px 10px;border-radius:10px;background:#0a0618e8;border:1.5px solid var(--gold);pointer-events:none;opacity:0;transition:opacity .18s,transform .18s var(--ez);white-space:nowrap;z-index:2}
.hltip.on{opacity:1;transform:translate(-50%,-100%)}.hltip b{font:400 17px/1.1 'Pirata One',Georgia,serif;color:var(--gold)}.hltip span{font:700 10.5px var(--ui);color:#c8c2f0}
.hlsub{position:absolute;left:10px;bottom:8px;padding:3px 10px;border-radius:10px;font:600 12.5px var(--ui);color:#d4cef0;background:#0a0618cc}
.hldone{position:absolute;right:10px;bottom:8px;padding:3px 12px;border-radius:10px;font:800 12.5px var(--ui);letter-spacing:.5px;color:#2a1406;background:linear-gradient(180deg,#fff0a0,#e0a020);border:1.5px solid #fff4b8;box-shadow:0 0 14px #ffd45a88}
.hlx[data-x=a] .hlact{top:auto;bottom:10px;transform:translate(-50%,6px)}.hlx[data-x=a]:hover .hlact,.hlx[data-x=a]:focus-visible .hlact{transform:translate(-50%,0)}
.hlx:not([data-x=a]) .hldone{top:10px;left:10px;right:auto;bottom:auto}
.hlnew{all:unset;cursor:pointer;position:absolute;top:12px;right:12px;padding:4px 11px;border-radius:12px;font:800 12px var(--ui);letter-spacing:1px;color:#2a1406;background:linear-gradient(180deg,#fff0a0,#f0a820);box-shadow:0 0 10px #ffd45a77;animation:hlnw 2.4s ease-in-out infinite;transition:transform .18s var(--ez)}
.hlnew:hover{transform:scale(1.06)}@keyframes hlnw{50%{box-shadow:0 0 22px #ffd45add}}
.hlbt{display:flex;gap:8px;width:100%;margin-top:10px}
.hlgo{all:unset;box-sizing:border-box;cursor:pointer;flex:1;display:flex;align-items:center;justify-content:center;gap:10px;padding:11px 16px;border-radius:14px;font:800 18px var(--ui);color:#fff;background:linear-gradient(180deg,color-mix(in srgb,var(--c) 30%,#2a2060),color-mix(in srgb,var(--c) 14%,#140e34));border:2px solid color-mix(in srgb,var(--c) 70%,#fff);transition:transform .18s var(--ez),filter .18s,box-shadow .18s}
.hlgo svg{width:22px;height:22px;color:var(--c)}.hlgo i{font-style:normal;font-size:22px;transition:transform .18s var(--ez)}.hlgo:hover{filter:brightness(1.15);box-shadow:0 0 18px color-mix(in srgb,var(--c) 40%,transparent)}.hlgo:hover i{transform:translateX(3px)}.hlgo:active{transform:scale(.97)}
.hlgo.b{--c:#8a7cf0;flex:none;padding:10px 22px}
.hlsoft{all:unset;cursor:pointer;padding:8px 14px;border-radius:12px;font:700 13px var(--ui);color:#c8c2f0;border:1.5px solid #3a3070;background:#140e30;transition:border-color .18s,color .18s}.hlsoft:hover{border-color:#8a7cf0;color:#fff}
.hlpin{all:unset;cursor:pointer;display:grid;place-items:center;width:46px;border-radius:14px;font-size:18px;color:var(--ink);background:#1a1438;border:1.5px solid #3a3070;transition:border-color .18s,transform .18s var(--ez)}.hlpin:hover{border-color:var(--c);transform:rotate(-8deg)}
.hlarm{position:absolute;inset:0;pointer-events:none}
.hlacw{position:absolute;left:50%;top:8px;transform:translateX(-50%);width:min(86%,300px)}
.hlac{display:flex;gap:8px;align-items:center;padding:5px 10px 5px 6px;border-radius:12px;background:#0a0618e0;border:1.5px solid #ffb06a55;pointer-events:auto;cursor:pointer;transition:border-color .18s}.hlac:hover{border-color:#ffb06a}
.hlac.hlinr{animation:hlacr .32s var(--ez)}.hlac.hlinl{animation:hlacl .32s var(--ez)}@keyframes hlacr{from{opacity:0;transform:translateX(18px)}}@keyframes hlacl{from{opacity:0;transform:translateX(-18px)}}
.hlac canvas{width:30px;height:40px;flex:none}.hlac>span:first-of-type{display:flex;flex-direction:column;line-height:1.12;min-width:0;flex:1}.hlac b{font:400 17px 'Pirata One',Georgia,serif;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.hlac em{font:700 10.5px var(--ui);font-style:normal;color:#c8c2f0}.hlac em i{font-style:normal;color:#9fffb0}.hlac small{font:500 10px var(--ui);color:#a8a2d8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.hlai{flex:none;font:700 11px var(--ui);color:#ffb06a}
.hlarw{all:unset;cursor:pointer;pointer-events:auto;position:absolute;top:44%;width:34px;height:34px;border-radius:50%;display:grid;place-items:center;font:700 24px/1 var(--ui);color:#fff;background:#0a0618cc;border:1.5px solid #ffb06a88;transition:background .18s,transform .18s var(--ez),border-color .18s}.hlarw.l{left:10px}.hlarw.r{right:10px}.hlarw:hover{background:#3a2010;border-color:#ffb06a;transform:scale(1.1)}.hlarw:active{transform:scale(.94)}
.hlbot{display:grid;grid-template-columns:1.7fr 1fr;gap:16px}
.hlgoal,.hlmast{position:relative;padding:16px 20px;border-radius:20px;background:radial-gradient(ellipse at 80% 0%,#2a1650,#120a26 70%);border:2px solid #3a3070;box-shadow:0 10px 24px #000b,inset 0 1px 0 #ffffff10;animation:hlin .55s var(--ez) .18s both}
.hlmast{animation-delay:.24s}
.hlgoal h3,.hlmast h3{margin:0 0 8px;font:400 36px/1 'Pirata One',Georgia,serif;color:var(--gold)}
.hlgtop{display:flex;justify-content:space-between;align-items:center;gap:10px}
.hlgb{animation:hlin .4s var(--ez) both}
.hlpinb{all:unset;cursor:pointer;display:flex;align-items:center;gap:6px;padding:5px 12px;border-radius:10px;font:700 13px var(--ui);color:var(--ink);background:#1a1438;border:1.5px solid #3a3070;transition:border-color .18s,color .18s}.hlpinb svg{width:14px;height:14px}.hlpinb:hover{border-color:var(--gold)}.hlpinb.on{border-color:var(--gold);color:var(--gold);background:#2a2010}
.hlno{animation:hlno .4s}@keyframes hlno{25%{transform:translateX(-4px)}75%{transform:translateX(4px)}}
.hlgh{display:flex;align-items:center;gap:14px}.hlgh>div{display:flex;flex-direction:column}.hlgh b{font:400 28px/1 'Pirata One',Georgia,serif;color:#9fffb0}.hlgh span{font:600 14px var(--ui);color:#d4cef0}.hlgh .hlbar{flex:1;width:auto}
.hlgi{display:grid;place-items:center;width:40px;height:40px;flex:none;border-radius:12px;background:#0a0618;border:1.5px solid #3a3070;color:#9fffb0}.hlgi svg{width:22px;height:22px}
.hl-s .hlgh b,.hl-s .hlgi{color:#ffb06a}.hl-m .hlgh b,.hl-m .hlgi{color:#9fb8ff}
.hlgs{display:flex;gap:8px;flex-wrap:wrap;margin:12px 0 6px}
.hlpt{all:unset;position:relative;display:block;width:64px;height:64px;border-radius:12px;background:radial-gradient(circle at 50% 35%,#2a2050,#0a0618);border:1.5px solid #3a3070;animation:hlpt .45s var(--ez) both;animation-delay:calc(.3s + var(--d,0ms));transition:transform .18s var(--ez),border-color .18s}
button.hlpt{cursor:pointer}button.hlpt:hover{transform:translateY(-3px);border-color:#9fffb0}
@keyframes hlpt{from{opacity:0;transform:scale(.6)}}
.hlpt canvas{width:100%;height:100%;display:block}.hlpt.hlnf canvas{filter:brightness(0) drop-shadow(0 0 1.5px #8a7ab8);opacity:.65}.hlpt.hlnf{border-style:dashed}
.hlpt i{position:absolute;right:4px;bottom:2px;font:800 13px var(--ui);font-style:normal;color:#8a7ab8}
.hlgt{margin:6px 0 10px;font:500 15px var(--ui);color:var(--ink)}
.hlga{display:flex;gap:10px;align-items:center}
.hlpqs{display:flex;flex-wrap:wrap;gap:6px;margin-top:14px;padding-top:12px;border-top:1px solid #ffffff12}
.hlpq{all:unset;cursor:pointer;display:flex;align-items:center;gap:6px;padding:3px 10px;border-radius:10px;font:600 12px var(--ui);color:#a8a2d8;background:#0a0618aa;border:1px solid #ffffff18;transition:border-color .18s,color .18s,transform .18s var(--ez)}.hlpq small{font-size:10.5px;opacity:.7}
.hlpq:hover{border-color:#9fffb0;color:#fff;transform:translateY(-1px)}.hlpq.hlcur{border-color:#9fffb0;color:#9fffb0}
.hlpq.done{color:#2a1406;background:linear-gradient(180deg,#fff0a0,#e0a020);border-color:#fff4b8}.hlpq.done.hlcur{box-shadow:0 0 0 2px #9fffb0}
.hlmr{display:flex;gap:10px;align-items:center}.hlmr canvas{width:90px;height:90px;flex:none;border-radius:12px;background:radial-gradient(circle at 50% 40%,#2a2050,#0a0618);border:1.5px solid #3a3070}.hlmr div{display:flex;flex-direction:column;gap:2px;min-width:0}.hlmr b{font:400 30px/1 'Pirata One',Georgia,serif}.hlmr em{font:italic 14px Georgia,serif;color:#c8c2f0}.hlmr small{font:500 13px var(--ui);color:#d4cef0}
.hlmar{all:unset;cursor:pointer;flex:none;width:26px;height:44px;border-radius:9px;display:grid;place-items:center;font:700 22px var(--ui);color:#c8c2f0;background:#140e30;border:1.5px solid #3a3070;transition:border-color .18s,color .18s}.hlmar:hover{border-color:#9fb8ff;color:#fff}
#hlmp.hlsw{animation:hlfade .32s var(--ez)}@keyframes hlfade{from{opacity:0;transform:translateY(6px)}}
.hltp{display:flex;gap:6px;margin:12px 0 0}.hltp i{flex:1;text-align:center;padding:3px 0;border-radius:8px;font:400 15px 'Pirata One',Georgia,serif;font-style:normal;color:#6a5a9a;background:#0a0618;border:1px solid #2a2050}.hltp i.on{color:#2a1406;background:linear-gradient(180deg,#cfe0ff,#7a9aff);border-color:#e0ecff}.hltp i.nx{color:#9fb8ff;border-color:#9fb8ff;border-style:dashed}
.hlmt{display:flex;justify-content:space-between;align-items:baseline;margin:10px 0 6px;font:600 14px var(--ui);color:#d4cef0}.hlmt b{color:#9fb8ff;font:400 22px 'Pirata One',Georgia,serif}.hlmast .hlbar{width:100%}.hlmast .hlgo{margin-top:14px}
.hlmod{position:absolute;inset:0;z-index:40;display:none;align-items:flex-start;justify-content:center;padding-top:40px;background:#05031ad0;border-radius:20px;animation:hlfo .18s ease both}.hlmod.on{display:flex}.hlmod.out{animation:hlfo .18s ease reverse both}@keyframes hlfo{from{opacity:0}}
.hlmc{position:relative;width:min(760px,94%);padding:18px 22px;border-radius:18px;background:linear-gradient(180deg,#1a1440,#0a0822);border:2px solid #e8c36a;box-shadow:0 20px 50px #000d;animation:hlin .32s var(--ez)}
.hlmc h3{margin:0;font:400 34px 'Pirata One',Georgia,serif;color:var(--gold)}.hlmc p{margin:4px 0 10px;font:500 14px var(--ui);color:#c8c2f0}
.hlx2{all:unset;cursor:pointer;position:absolute;right:14px;top:6px;font:400 32px Georgia,serif;color:#e8c36a;transition:transform .18s var(--ez)}.hlx2:hover{transform:rotate(90deg)}
.hlpk{display:grid;grid-template-columns:repeat(auto-fill,minmax(110px,1fr));gap:8px;max-height:46vh;overflow:auto;padding:4px}
.hlpk button{all:unset;position:relative;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:2px;padding:6px;border-radius:12px;background:#0a0618;border:2px solid #2a2050;transition:border-color .18s,box-shadow .18s,transform .18s var(--ez)}.hlpk button:hover{transform:translateY(-2px);border-color:#5a4a90}.hlpk button.on{border-color:var(--gold);box-shadow:0 0 14px #ffd45a55}
.hlpk canvas{width:72px;height:72px}.hlpk span{font:600 12px var(--ui);color:var(--ink);text-align:center}
.hlpk em{position:absolute;top:4px;left:6px;font:800 13px var(--ui);font-style:normal;color:#2a1406}.hlpk button.on em{display:grid;place-items:center;width:20px;height:20px;border-radius:50%;background:var(--gold)}.hlnone{font:500 14px var(--ui);color:#a8a2d8}
.hlpkb{display:flex;justify-content:flex-end;align-items:center;gap:10px;margin-top:12px}#hlpn{margin-right:auto;font:600 13px var(--ui);color:#c8c2f0}
.hlflash{animation:hlfl 2.4s ease}@keyframes hlfl{0%,60%{box-shadow:0 0 0 3px #ffd45a,0 0 34px #ffd45a}100%{box-shadow:none}}
@media (max-width:1100px){.hlbot{grid-template-columns:1fr}}
@media (max-width:820px){.hlgrid{grid-template-columns:1fr}.hlh{padding-right:110px}.chl .hlh h2,#ov.hlcat .hlh h2{font-size:44px}.hltabs .tab:nth-child(5),.hlcat .hlh .ctabs .tab:nth-child(5){margin-left:0}}
@media (prefers-reduced-motion:reduce){.chl *,.hlcat .bwrap,.hlcat .csum,.hlh{animation:none!important;transition:none!important}}
`;document.head.appendChild(st)}
