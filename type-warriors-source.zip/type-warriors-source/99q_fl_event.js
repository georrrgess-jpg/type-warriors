/* ===== UPDATE 10.4, THE HARVEST FESTIVAL: the festival itself (99q, prefix fle; art 99q2, screens 99q3) =====
   Acorns, the festival's currency (P.fl.ac), are gathered by playing every main mode through the game's own finish functions, by
   three daily Gratitude tasks and by the Harvest Calendar; they are spent in the Harvest Market. Dates come from 99m (flOn,
   flShopOn: the market stays open seven days after the festival for leftover acorns; window.FL_FORCE = 1 / -1 for tests).
   Save: P.fl.ac (balance, shared interface) and P.fl.fe (everything else of this module), repaired on every load. Other parts may
   keep their own keys in P.fl; they are left alone.
     fe.tot / fe.sp      acorns ever gathered / spent           fe.lg   the last 40 changes {t,d,bal,src} (a ledger like 94e's)
     fe.dy               today: {d, inc:{src:n}, play, fr}      play counts full-rate play acorns toward the daily bag (FLE.bag)
     fe.gt               today's Gratitude tasks {d, k:[ids], p:[progress], c:[claimed], b:bonus paid}; fe.gtN tasks completed
     fe.cal              Calendar {day: time claimed} for days 6..26 of November; fe.cu catch-ups bought; fe.feast egg won
     fe.buy              market purchases {item: count}; fe.mk acorns spent at the market
     fe.lv               falling leaves on the home screen (1 on, 0 off); fe.seen festival opened; fe.note a message for the hub
   Interfaces for the other parts: fleAcorns(), fleGive(n,src), fleSpend(n,src), fleHub(), and fleTask(kind,n) for progress
   (Harvest Moon Rush may call fleTask('rush',1) when a run ends; acorns it pays with a source containing "rush" count too). */
const FLE={bag:150,late:.25,catchUp:40,gtRw:[20,30,45],gtBonus:25,
 price:{chest:150,chest5:650,squir:1000,fox:2500,egg:5000,trail:600,title:400,keep:350},
 /* acorns per finished activity (play sources share the daily bag; past it they pay a quarter) */
 pay:{camp:[10,12,14],campLoss:3,dc:15,dcLoss:6,endless5:8,rift:6,arena:8,arenaLoss:4,td:16,td3:6,tdLoss:5,tdEnd5:3,rr:12,rrLoss:4,rrPrac:3,wr:14,wrLoss:5,fish:2,pool:10,poolLoss:4,wc:8,wcLoss:3,treat:8}};
const FLE_PLAY=new Set(['campaign','daily','endless','rift','arena','towers','riddle','caravan','fishing','pool','wildcard','treat']);
const FLE_SRC={campaign:'Campaign',daily:'Daily challenge',endless:'Endless',rift:'Starfall Rift',arena:"Warden's Arena",towers:'Tower Defense',riddle:'Runestone Riddle',
 caravan:'Lantern Caravan',fishing:'Moonlit Fishing',pool:'The Crooked Cue',wildcard:'Wildcard',treat:'Trick-or-Treat',task:'Gratitude task',bonus:'Gratitude bonus',calendar:'Harvest Calendar',
 rush:'Harvest Moon Rush',chest:'Harvest Chest',market:'Harvest Market',catchup:'Calendar catch-up',dev:'DEV'};
const fleInt=(v,mx)=>{v=Math.floor(+v);return isFinite(v)&&v>0?Math.min(mx||1e9,v):0};
const fleObj=o=>o&&typeof o==='object'&&!Array.isArray(o);
const fleDay=(t)=>{const d=new Date(t==null?flNow():t);return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
const fleWritable=()=>{try{return !(typeof SGS!=='undefined'&&SGS&&(SGS.stale||SGS.lock))}catch(e){return true}};
const fleRM=()=>{try{return matchMedia('(prefers-reduced-motion: reduce)').matches}catch(e){return false}};
const fleLite=()=>{try{return fleRM()||document.body.classList.contains('pf-low')}catch(e){return false}};

/* ---------- the save ---------- */
/* FLP() is the cheap accessor; the full repair runs once per festival object (and on every load / import) */
const FLE_OK=new WeakSet();
function FLP(p){p=p||P;if(!p)return null;const f=p.fl;if(fleObj(f)&&fleObj(f.fe)&&FLE_OK.has(f.fe))return f;return fleRepair(p)}
function fleRepair(p){let f=p.fl;if(!fleObj(f))f=p.fl={};f.ac=fleInt(f.ac);
 let e=f.fe;if(!fleObj(e))e=f.fe={};
 e.tot=Math.max(fleInt(e.tot),f.ac);e.sp=fleInt(e.sp);e.gtN=fleInt(e.gtN,1e5);e.mk=fleInt(e.mk);e.cu=fleInt(e.cu,100);
 e.lv=e.lv===0?0:1;e.seen=e.seen?1:0;e.feast=e.feast?1:0;e.note=typeof e.note==='string'?e.note.slice(0,200):'';
 const lg=Array.isArray(e.lg)?e.lg:[],ok=[];for(const x of lg){if(!fleObj(x)||typeof x.src!=='string')continue;const d=Math.round(+x.d),b=Math.round(+x.bal);if(!isFinite(d)||!isFinite(b)||!d)continue;ok.push({t:isFinite(+x.t)?+x.t:0,d,bal:b,src:x.src.slice(0,24)})}e.lg=ok.slice(-40);
 let D=e.dy;if(!fleObj(D)||typeof D.d!=='string')D={d:'',inc:{},play:0,fr:0};const inc={};let c=0;if(fleObj(D.inc))for(const k of Object.keys(D.inc)){const v=fleInt(D.inc[k]);if(v&&c<30){inc[k.slice(0,24)]=v;c++}}
 e.dy={d:D.d.slice(0,10),inc,play:fleInt(D.play,1e6),fr:Math.max(0,Math.min(.999,+D.fr||0))};
 const cal={};if(fleObj(e.cal))for(const k of Object.keys(e.cal)){const d=+k;if(Number.isInteger(d)&&d>=6&&d<=26&&e.cal[k])cal[d]=+e.cal[k]>1?+e.cal[k]:1}e.cal=cal;
 const buy={};if(fleObj(e.buy))for(const k of Object.keys(e.buy))if(FLE_MKK.has(k)){const v=fleInt(e.buy[k],1e4);if(v)buy[k]=v}e.buy=buy;
 let G=e.gt;if(!fleObj(G)||typeof G.d!=='string'||!Array.isArray(G.k)||G.k.length!==3||!G.k.every(k=>FLE_TK[k]))G={d:'',k:[],p:[],c:[],b:0};
 else{G={d:G.d.slice(0,10),k:G.k.slice(0,3),p:[0,1,2].map(i=>Math.min(FLE_TK[G.k[i]].n,fleInt(Array.isArray(G.p)?G.p[i]:0,1e6))),c:[0,1,2].map(i=>Array.isArray(G.c)&&G.c[i]?1:0),b:G.b?1:0}}
 e.gt=G;FLE_OK.add(e);return f}
const fleAcorns=()=>{try{return P?FLP().ac:0}catch(e){return 0}};
function fleLedger(d,src){const f=FLP(),a=f.fe.lg;a.push({t:Date.now(),d:Math.round(d),bal:f.ac,src:String(src||'other').slice(0,24)});if(a.length>40)a.splice(0,a.length-40)}
function fleToday(){const e=FLP().fe,d=fleDay();if(e.dy.d!==d)e.dy={d,inc:{},play:0,fr:0};return e.dy}

/* ---------- acorns in and out ---------- */
/* fleGive(n, src): adds acorns while the market is open. Play sources fill today's bag at full rate, then pay a quarter (the rest
   carries as a fraction). Returns the acorns actually added. o.quiet skips the toast. */
function fleGive(n,src,o){o=o||{};if(!P||!flShopOn()||!fleWritable())return 0;n=Math.floor(+n);if(!(n>0))return 0;n=Math.min(n,1e5);
 const f=FLP(),e=f.fe,s=String(src||'other').slice(0,24),play=FLE_PLAY.has(s);if(play&&!flOn())return 0;const D=fleToday();
 if(play){const room=Math.max(0,FLE.bag-D.play),full=Math.min(n,room),late=(n-full)*FLE.late+D.fr,lw=Math.floor(late);D.fr=late-lw;D.play+=full;n=full+lw;if(!n){save();return 0}}
 f.ac=Math.min(1e9,f.ac+n);e.tot+=n;D.inc[s]=(D.inc[s]||0)+n;fleLedger(n,s);
 try{if(typeof S==='object'&&S&&(S.mode==='play'||S.mode==='over'))S.fleRun=(S.fleRun||0)+n}catch(x){}
 if(play)fleTask('acp',D.play,1);
 /* Harvest Moon Rush pays with a source naming the rush: count one finished run per run for the Gratitude tasks */
 try{if(/rush/i.test(s)&&typeof S==='object'&&S&&S.fleRushRid!==(S.fleRid||-1)){S.fleRushRid=S.fleRid||-1;fleTask('rush',1)}}catch(x){}
 save();try{achCheck()}catch(x){}if(!o.quiet)fleToast(n,FLE_SRC[s]||s);return n}
function fleSpend(n,src){if(!P||!flShopOn()||!fleWritable())return false;n=Math.floor(+n);if(!(n>0))return false;const f=FLP();if(f.ac<n)return false;
 f.ac-=n;f.fe.sp+=n;fleLedger(-n,src||'market');save();return true}
let FLE_RID=0;

/* ---------- the toast: one at a time, quick ones stack into one number ---------- */
const FLTQ={el:null,n:0,lab:'',h:0,t:0};
function fleToast(n,lab,kind){try{
 if(typeof S==='object'&&S&&S.mode==='play'&&typeof float==='function'){if(kind==='task')float(W/2,128,'Gratitude task done!','#9fffb0',32);else float(W/2,168,`+${n} acorn${n===1?'':'s'}`,'#ffc46a',30);return}
 let el=document.getElementById('fletoast');if(!el){el=document.createElement('div');el.id='fletoast';el.setAttribute('role','status');el.setAttribute('aria-live','polite');(document.getElementById('wrap')||document.body).appendChild(el)}
 const now=performance.now(),join=!kind&&FLTQ.kind!=='task'&&el.classList.contains('show')&&now-FLTQ.t<2200;FLTQ.n=join?FLTQ.n+n:n;FLTQ.lab=join&&FLTQ.lab!==lab?'Harvest Festival':lab;FLTQ.t=now;FLTQ.kind=kind||'';
 el.className=kind==='task'?'task':'';el.innerHTML=kind==='task'?`<span class="fltic">${fleIco('leaf',34)}</span><div><i>Gratitude task done</i><b>${esc(lab)}</b><span>Claim +${n} acorns in the Harvest Festival</span></div>`
  :`<span class="fltic">${fleIco('acorn',38)}</span><div><i>${esc(FLTQ.lab)}</i><b>+${FLTQ.n.toLocaleString()} acorn${FLTQ.n===1?'':'s'}</b></div>`;
 void el.offsetWidth;el.classList.add('show');clearTimeout(FLTQ.h);FLTQ.h=setTimeout(()=>{el.classList.remove('show')},kind==='task'?3400:2600);
 try{beep(kind==='task'?880:740,.07,'triangle',.25);setTimeout(()=>beep(kind==='task'?1175:988,.09,'triangle',.22),70)}catch(x){}}catch(e){}}

/* ---------- Gratitude tasks: three a day (easy, medium, hard), each from a different mode ---------- */
const FLE_TKL=[
 {k:'e_camp',t:0,ev:'camp',n:1,m:'camp',ic:'camp',x:'Clear a campaign level'},
 {k:'e_end',t:0,ev:'endr',n:5,m:'end',ic:'endless',x:'Clear 5 Endless rounds'},
 {k:'e_kill',t:0,ev:'kill',n:40,m:'any',ic:'sword',x:'Slay 40 monsters in battle'},
 {k:'e_fish',t:0,ev:'fish',n:3,m:'fish',ic:'fish',x:'Catch 3 fish in Moonlit Fishing'},
 {k:'e_rr',t:0,ev:'rr',n:1,m:'rr',ic:'rune',x:"Finish today's Runestone Riddle"},
 {k:'m_td',t:1,ev:'td',n:1,m:'td',ic:'tower',x:'Win a Tower Defense map'},
 {k:'m_wr',t:1,ev:'wr',n:1,m:'wr',ic:'lantern',x:'Finish a Lantern Caravan route'},
 {k:'m_dc',t:1,ev:'dc',n:1,m:'dc',ic:'gift',x:"Finish today's Daily Challenge"},
 {k:'m_c3',t:1,ev:'camp3',n:1,m:'camp',ic:'star',x:'Earn 3 stars on a campaign level'},
 {k:'m_pool',t:1,ev:'pool',n:1,m:'pool',ic:'ball',x:'Play a match of The Crooked Cue'},
 {k:'m_rush',t:1,ev:'rush',n:1,m:'rush',ic:'moon',x:'Finish a Harvest Moon Rush run',ok:()=>typeof flrMenu==='function'&&(typeof flrOn!=='function'||flrOn())},
 {k:'h_end',t:2,ev:'endw',n:15,m:'end',ic:'endless',run:1,x:'Reach round 15 in one Endless run'},
 {k:'h_flaw',t:2,ev:'flaw',n:40,m:'any',ic:'quill',run:1,x:'Type 40 words in a row without a slip'},
 {k:'h_camp',t:2,ev:'camp',n:3,m:'camp',ic:'camp',x:'Clear 3 campaign levels'},
 {k:'h_td3',t:2,ev:'td3',n:1,m:'td',ic:'tower',x:'Win a Tower Defense map with 3 stars'},
 {k:'h_ac',t:2,ev:'acp',n:100,m:'any',ic:'acorn',run:1,x:'Gather 100 acorns by playing today'},
 {k:'h_rush',t:2,ev:'rush',n:2,m:'rush',ic:'moon',x:'Finish 2 Harvest Moon Rush runs',ok:()=>typeof flrMenu==='function'&&(typeof flrOn!=='function'||flrOn())}];
const FLE_TK={};for(const t of FLE_TKL)FLE_TK[t.k]=t;
function fleTasksFor(day){const r=dcRng(dcHash('fle-gratitude:'+day)),out=[],used=new Set();
 for(let tier=0;tier<3;tier++){const pool=FLE_TKL.filter(t=>t.t===tier&&(!t.ok||t.ok())&&!(t.m!=='any'&&used.has(t.m))&&!out.some(k=>FLE_TK[k].ev===t.ev));
  const t=pool[Math.floor(r()*pool.length)]||FLE_TKL.find(x=>x.t===tier);out.push(t.k);if(t.m!=='any')used.add(t.m)}return out}
/* today's tasks; a new day pays yesterday's finished but unclaimed tasks, like the Bounty Board */
function fleGT(){const e=FLP().fe,d=fleDay();let G=e.gt;if(G.d===d)return G;
 if(G.d&&G.k.length===3&&flShopOn()){let n=0,paid=0;G.k.forEach((k,i)=>{if(!G.c[i]&&G.p[i]>=FLE_TK[k].n){G.c[i]=1;n+=FLE.gtRw[FLE_TK[k].t];e.gtN++;paid++}});
  if(paid&&!G.b&&G.c.every(x=>x)){G.b=1;n+=FLE.gtBonus}if(n){fleGive(n,'task',{quiet:1});e.note=`Yesterday's finished Gratitude task${paid>1?'s were':' was'} paid: +${n} acorns.`}}
 G=e.gt={d,k:fleTasksFor(d),p:[0,0,0],c:[0,0,0],b:0};return G}
/* progress from anywhere in the game: fleTask(kind, value, isRunMax) */
function fleTask(ev,v,run){try{if(!P||!flOn()||(typeof S==='object'&&S&&(S.bg||S.prac)))return;v=+v||0;if(v<=0)return;const G=fleGT();
 G.k.forEach((k,i)=>{const T=FLE_TK[k];if(!T||T.ev!==ev||G.p[i]>=T.n)return;G.p[i]=Math.min(T.n,(run||T.run)&&ev!=='endr'?Math.max(G.p[i],Math.floor(v)):G.p[i]+Math.floor(v));
  if(G.p[i]>=T.n){save();fleToast(FLE.gtRw[T.t],T.x,'task')}})}catch(e){}}
const fleTaskReady=()=>{try{if(!flOn())return 0;const G=fleGT();return G.k.filter((k,i)=>!G.c[i]&&G.p[i]>=FLE_TK[k].n).length}catch(e){return 0}};
function fleClaimTask(i){if(!flOn()||!fleWritable())return 0;const G=fleGT(),k=G.k[i],T=FLE_TK[k];if(!T||G.c[i]||G.p[i]<T.n)return 0;
 G.c[i]=1;const e=FLP().fe;e.gtN++;let n=fleGive(FLE.gtRw[T.t],'task',{quiet:1});if(!G.b&&G.c.every(x=>x)){G.b=1;n+=fleGive(FLE.gtBonus,'bonus',{quiet:1})}save();try{achCheck()}catch(x){}return n}
function fleTaskLeft(){const n=new Date(flNow()),e=new Date(n.getFullYear(),n.getMonth(),n.getDate()+1),s=Math.max(0,(e-n)/1000|0);return Math.floor(s/3600)+'h '+String(Math.floor(s%3600/60)).padStart(2,'0')+'m'}

/* ---------- the Harvest Calendar: 6 to 26 November, bigger weekends, the Thanksgiving feast ---------- */
const FLE_CAL={6:{n:'Welcome basket',g:[['ac',40]]},7:{n:'Weekend crate',g:[['ch',1]]},8:{n:'Sunday basket',g:[['ac',80]]},9:{n:'Coin pouch',g:[['co',1500]]},
 10:{n:'Acorn sack',g:[['ac',40]]},11:{n:'Coin pouch',g:[['co',2000]]},12:{n:'Acorn sack',g:[['ac',45]]},13:{n:'Acorn sack',g:[['ac',50]]},
 14:{n:'Weekend crate',g:[['ch',1],['ac',50]]},15:{n:'Companion egg',g:[['eg',1],['co',1500]]},16:{n:'Coin pouch',g:[['co',2500]]},17:{n:'Acorn sack',g:[['ac',50]]},
 18:{n:'Coin pouch',g:[['co',2500]]},19:{n:'Acorn sack',g:[['ac',55]]},20:{n:'Acorn sack',g:[['ac',60]]},21:{n:'Double crate',g:[['ch',2]]},
 22:{n:'Sunday feast basket',g:[['ac',120],['co',3000]]},23:{n:'Coin pouch',g:[['co',3000]]},24:{n:'Acorn sack',g:[['ac',60]]},25:{n:"Feast eve",g:[['ch',1],['ac',60]]},
 26:{n:'The Thanksgiving Feast',g:[['ac',200],['ch',2]],feast:1}};
const FLE_DAYS=Object.keys(FLE_CAL).map(Number);
const fleWknd=d=>{const w=new Date(2026,10,d).getDay();return w===0||w===6};
/* the calendar day of "now": 0 before the festival, 6..26 inside, 27 after Thanksgiving */
function fleCalNow(){const n=flNow(),d=new Date(n);if(n<FL.start)return 0;if(d.getFullYear()===2026&&d.getMonth()===10)return Math.min(27,Math.max(6,d.getDate()));return n<FL.start?0:27}
function fleCalSt(day){const e=FLP().fe,now=fleCalNow();if(e.cal[day])return'got';if(day===now)return'today';if(day<now)return'miss';return'lock'}
const fleCalN=()=>Object.keys(FLP().fe.cal).length;
const fleFeastEarned=()=>{const c=FLP().fe.cal;return FLE_DAYS.filter(d=>d<26).every(d=>c[d])};
const fleCalReady=()=>{try{return flOn()&&fleCalSt(fleCalNow())==='today'}catch(e){return false}};
/* the presents of a day as the player will get them (the feast adds the Golden Harvest Egg and a title when every earlier day is open) */
function fleCalGifts(day){const C=FLE_CAL[day];if(!C)return[];const g=C.g.slice();if(C.feast&&fleFeastEarned())g.push(['gold',1],['ti','thankful']);return g}
function fleCalClaim(day){if(!flOn()||!fleWritable())return null;const st=fleCalSt(day);if(st!=='today'&&st!=='miss')return null;
 if(st==='miss'){if(!fleSpend(FLE.catchUp,'catchup'))return null;FLP().fe.cu++}
 const e=FLP().fe,gifts=fleCalGifts(day);e.cal[day]=Date.now();if(FLE_CAL[day].feast&&gifts.some(g=>g[0]==='gold'))e.feast=1;
 const got=[];for(const [k,v] of gifts)got.push(fleGift(k,v));save();try{achCheck()}catch(x){}return{day,st,gifts:got}}
/* hand one present over through the game's own paths; returns {k,v,txt} */
function fleGift(k,v){const lab='harvest calendar';
 if(k==='ac'){const n=fleGive(v,'calendar',{quiet:1});return{k,v:n,txt:`${n} acorns`}}
 if(k==='co'){ukSrc(lab,()=>{P.gold+=v});return{k,v,txt:`${v.toLocaleString()} coins`}}
 if(k==='ch'){if(typeof flcAdd==='function'){try{flcAdd(v,'calendar')}catch(x){console.error(x)}return{k,v,txt:`${v} Harvest Chest${v>1?'s':''}`}}const n=fleGive(FLE.price.chest*v,'calendar',{quiet:1});return{k:'ac',v:n,txt:`${n} acorns`}}
 if(k==='eg'){try{petNorm()}catch(x){}P.eggs.r=(P.eggs.r|0)+v;return{k,v,txt:`${v} Runeshell egg`}}
 if(k==='gold'){if(typeof flpEggAdd==='function'){try{flpEggAdd(v)}catch(x){console.error(x)}return{k,v,txt:'The Golden Harvest Egg'}}const n=fleGive(FLE.price.egg,'calendar',{quiet:1});return{k:'ac',v:n,txt:`${n} acorns`}}
 if(k==='ti'){try{const B=BTY();B.own['t:'+v]=1}catch(x){}return{k,v,txt:'The title Thankful Heart'}}
 return{k,v,txt:''}}

/* ---------- the Harvest Market ---------- */
const FLE_MK=[
 {k:'egg',n:'Golden Harvest Egg',d:'Hatches Thunderplume, the Mythic harvest turkey, with its Grand Feast ability.',r:'Mythic',c:'#ff9a3a',
  own:()=>typeof petOwned==='function'&&petOwned(FL.pets.m),av:()=>typeof flpEggAdd==='function',give:()=>flpEggAdd(1)},
 {k:'chest',n:'Harvest Chest',d:'One harvest relic, coins or acorns, and a small chance of a companion.',r:'Chest',c:'#e8a23a',
  av:()=>typeof flcAdd==='function',give:()=>flcAdd(1,'market')},
 {k:'chest5',n:'Harvest Chest ×5',d:'Five chests for the price of four and a bit.',r:'Best value',c:'#ffc94a',
  av:()=>typeof flcAdd==='function',give:()=>flcAdd(5,'market')},
 {k:'squir',n:'Acorn Scamp',d:'A red squirrel in an acorn-cap helmet. Rare companion.',r:'Rare',c:'#5ab8ff',
  own:()=>typeof petOwned==='function'&&petOwned(FL.pets.r),av:()=>typeof flpGive==='function'&&typeof PDEF!=='undefined'&&!!PDEF[FL.pets.r],give:()=>flpGive(FL.pets.r)},
 {k:'fox',n:'Emberleaf',d:'A fox whose tail is a plume of glowing maple leaves. Legendary companion.',r:'Legendary',c:'#ffc23a',
  own:()=>typeof petOwned==='function'&&petOwned(FL.pets.l),av:()=>typeof flpGive==='function'&&typeof PDEF!=='undefined'&&!!PDEF[FL.pets.l],give:()=>flpGive(FL.pets.l)},
 {k:'trail',n:'Falling Leaves',d:'Letter trail: every correct letter flies to the monster as a maple leaf.',r:'Letter trail',c:'#ff8a3a',
  own:()=>!!fleBty().own['r:flleaf'],av:()=>true,give:()=>{const B=fleBty();B.own['r:flleaf']=1;B.trail='flleaf'}},
 {k:'title',n:'Harvest Hero',d:'A festival title under your name on the home screen.',r:'Title',c:'#ffd45a',
  own:()=>!!fleBty().own['t:harvesthero'],av:()=>true,give:()=>{const B=fleBty();B.own['t:harvesthero']=1;B.title='harvesthero';P.ttl=''}},
 {k:'keep',n:'Autumn Keepsake',d:'Falling leaves stay on your home screen after the festival.',r:'Keepsake',c:'#c8783a',
  own:()=>!!FLP().fe.buy.keep,av:()=>true,give:()=>{}}];
const FLE_MKK=new Set(FLE_MK.map(i=>i.k));
const fleItem=k=>FLE_MK.find(i=>i.k===k);
const fleBty=()=>{try{return BTY()}catch(e){if(!fleObj(P.bty))P.bty={own:{}};if(!fleObj(P.bty.own))P.bty.own={};return P.bty}};
/* 'ok' can buy, 'own' already owned, 'soon' not available, 'poor' not enough acorns, 'closed' market closed */
function fleMkSt(k){const it=fleItem(k);if(!it)return'soon';if(it.own&&it.own())return'own';if(!it.av())return'soon';if(!flShopOn())return'closed';return FLP().ac>=FLE.price[k]?'ok':'poor'}
function fleBuy(k){const it=fleItem(k);if(!it||fleMkSt(k)!=='ok'||!fleWritable())return false;const pr=FLE.price[k];if(!fleSpend(pr,'market'))return false;
 try{it.give()}catch(x){console.error(x);const f=FLP();f.ac+=pr;f.fe.sp=Math.max(0,f.fe.sp-pr);fleLedger(pr,'refund');save();return false}
 const e=FLP().fe;e.buy[k]=(e.buy[k]|0)+1;e.mk+=pr;save();try{achCheck()}catch(x){}return true}

/* ---------- cosmetics: a title and a letter trail in the existing systems ---------- */
try{if(!BT_TITLES.some(x=>x[0]==='harvesthero'))BT_TITLES.push(['harvesthero','Harvest Hero',1e9],['thankful','Thankful Heart',1e9]);
 if(!BT_TRAILS.some(x=>x[0]==='flleaf'))BT_TRAILS.push(['flleaf','Falling Leaves',1e9,'#ffd27a','#e0622a'])}catch(e){}
{const a0=btyTrailArt;btyTrailArt=function(g,k,x,y,u,ch,s,big){if(k!=='flleaf')return a0.apply(this,arguments);
 glow(g,x,y,big?24:22,'#ff8a3a99');g.save();g.translate(x,y);g.rotate(Math.sin(s+u*7)*.6+u*2.4);const c=['#e8562a','#f0902a','#ffc23a','#c8402a'][Math.floor(s*1.7)%4];fleLeafPath(g,0,0,big?12:10.5,c);g.restore();
 g.font=`800 ${big?15:14}px ui-monospace,Menlo,Consolas,monospace`;g.textAlign='center';g.textBaseline='middle';g.fillStyle='#fff8e8';g.fillText(ch,x,y+1)}}
/* a canvas maple leaf (also used by the art module): centre x,y, radius r */
const FLE_MAPLE=(()=>{const R=[[.06,.6],[.4,.74],[.33,.5],[.86,.4],[.72,.2],[1,-.12],[.6,-.04],[.64,-.36],[.36,-.18],[.42,-.66],[.17,-.5],[0,-1]];return R.concat(R.slice(0,-1).reverse().map(([a,b])=>[-a,b]))})();
function fleLeafPath(g,x,y,r,col,ol){g.beginPath();FLE_MAPLE.forEach(([a,b],i)=>{const px=x+a*r,py=y+b*r;i?g.lineTo(px,py):g.moveTo(px,py)});g.closePath();g.fillStyle=col;g.fill();
 if(ol!==0){g.strokeStyle=ol||'#12081f';g.lineWidth=Math.max(1,r*.13);g.lineJoin='round';g.stroke()}
 g.strokeStyle='#00000045';g.lineWidth=Math.max(.8,r*.08);g.lineCap='round';g.beginPath();g.moveTo(x,y+r);g.lineTo(x,y-r*.7);g.moveTo(x,y+r*.25);g.lineTo(x+r*.7,y-r*.08);g.moveTo(x,y+r*.25);g.lineTo(x-r*.7,y-r*.08);g.stroke()}
/* the Bounty Board shows the festival titles as "earned at the Harvest Market / Calendar", not for tokens */
{const b0=bountyBoard;bountyBoard=function(){const r=b0.apply(this,arguments);try{for(const [id,t] of [['harvesthero','Earn: Harvest Market'],['thankful','Earn: every Harvest Calendar present']]){const x=ov.querySelector(`[data-buy="t:${id}"]`);if(x){const s=document.createElement('span');s.className='rrlock';s.textContent=t;x.replaceWith(s)}}}catch(e){}return r}}

/* ---------- festival trophies (category Harvest); unearned ones leave the case once the market has closed ---------- */
const FLE_TRO=[['flt_a1',0,'First Acorns','Gather 100 acorns in the Harvest Festival.',100,()=>FLP().fe.tot,100,0],
 ['flt_a2',1,"Squirrel's Hoard",'Gather 1,500 acorns in the Harvest Festival.',1500,()=>FLP().fe.tot,300,0],
 ['flt_a3',2,'Acorn Baron','Gather 5,000 acorns in the Harvest Festival.',5000,()=>FLP().fe.tot,800,1],
 ['flt_c7',1,'Seven Presents','Open 7 Harvest Calendar presents.',7,()=>fleCalN(),300,0],
 ['flt_cA',3,'Thankful Heart','Open all 21 Harvest Calendar presents.',21,()=>fleCalN(),1500,2],
 ['flt_g10',1,'Grateful','Complete 10 Gratitude tasks.',10,()=>FLP().fe.gtN,300,0],
 ['flt_g40',2,'Overflowing Gratitude','Complete 40 Gratitude tasks.',40,()=>FLP().fe.gtN,800,1],
 ['flt_m1',0,'Market Day','Buy something at the Harvest Market.',1,()=>Object.keys(FLP().fe.buy).length,100,0],
 ['flt_m3',2,'Big Spender','Spend 3,000 acorns at the Harvest Market.',3000,()=>FLP().fe.mk,600,1]];
const FLE_ACH=[];try{for(const [id,t,n,d,tg,v,g,sp] of FLE_TRO){A(id,'Harvest',t,n,d,tg,()=>{try{return v()}catch(e){return 0}},g,sp);FLE_ACH.push(ACH[ACH.length-1])}if(!ACAT.includes('Harvest'))ACAT.push('Harvest')}catch(e){console.error(e)}
function fleTroSync(){try{const open=flShopOn();for(const a of FLE_ACH){const i=ACH.indexOf(a),keep=open||!!(P&&P.ach&&P.ach[a.id]);if(keep&&i<0)ACH.push(a);else if(!keep&&i>=0)ACH.splice(i,1)}
 const any=FLE_ACH.some(a=>ACH.includes(a)),j=ACAT.indexOf('Harvest');if(any&&j<0)ACAT.push('Harvest');else if(!any&&j>=0)ACAT.splice(j,1)}catch(e){}}

/* ---------- repair on load ---------- */
{const l0=load;load=function(){const r=l0.apply(this,arguments);try{if(P)fleRepair(P);fleTroSync()}catch(e){console.error(e)}return r}}
try{const f0=sgShape;sgShape=function(o){const r=f0.apply(this,arguments);try{if(r&&typeof r==='object')fleRepair(r)}catch(e){}return r}}catch(e){}

/* ---------- earning: the game's own finish functions ---------- */
const fleLive=()=>{try{return !!P&&flOn()&&!(S&&(S.bg||S.prac))}catch(e){return false}};
{const s0=start;start=function(){const r=s0.apply(this,arguments);try{S.fleRun=0;S.fleEnd=0;S.fleRid=++FLE_RID}catch(e){}return r}}
/* campaign: a won level pays by stars; a lost one (played, not quit) a little */
{const v0=victory;victory=function(){const st=S.mode,camp=S.camp,dc=S.dc,rift=S.rift,dmg=S.dmgTaken;const r=v0.apply(this,arguments);
 try{if(st!=='over'&&camp&&!dc&&!rift&&fleLive()){const stars=1+(dmg<=2?1:0)+(dmg===0?1:0);fleGive(FLE.pay.camp[stars-1],'campaign');fleTask('camp',1);if(stars===3)fleTask('camp3',1)}}catch(e){console.error(e)}return r}}
{const o0=over;over=function(quit){const st=S.mode,camp=S.camp,plain=!S.dc&&!S.rift&&!S.prac&&!S.gy&&!S.bg,ok=S.ok|0;const r=o0.apply(this,arguments);
 try{if(st!=='over'&&plain&&camp&&!quit&&ok>=40&&fleLive())fleGive(FLE.pay.campLoss,'campaign')}catch(e){}return r}}
/* Endless (and Monster Mash): every five rounds cleared, also counted for the tasks. Harvest Moon Rush runs on the same engine (S.gy and S.flr)
   and pays its own acorns at the run end, so its rounds are skipped here. */
{const w0=startWave;startWave=function(){const r=w0.apply(this,arguments);try{if(S.mode==='play'&&!S.camp&&!S.rift&&!S.prac&&!S.dc&&!S.bg&&!S.flr&&S.wave>1&&S.fleEnd!==S.wave&&fleLive()){S.fleEnd=S.wave;fleTask('endr',1);fleTask('endw',S.wave,1);if((S.wave-1)%5===0)fleGive(FLE.pay.endless5,'endless')}}catch(e){}return r}}
/* the Daily Challenge (one result a day; forfeits pay nothing) */
{const d0=dcRecord;dcRecord=function(key,res){const r=d0.apply(this,arguments);try{if(res&&!res.forfeit&&key===dcKey()&&fleLive()){fleGive(res.win?FLE.pay.dc:FLE.pay.dcLoss,'daily');fleTask('dc',1)}}catch(e){}return r}}
try{const r0=riftOver;riftOver=function(quit){const st=S.mode,k=S.kills|0;const r=r0.apply(this,arguments);try{if(st!=='over'&&k>=20&&fleLive())fleGive(FLE.pay.rift,'rift')}catch(e){}return r}}catch(e){}
/* battle progress the bounties already count: kills and flawless chains */
{const b0=btyAdd;btyAdd=function(k,v,run){const r=b0.apply(this,arguments);try{if(k==='kill')fleTask('kill',v);else if(k==='chainw')fleTask('flaw',v,1)}catch(e){}return r}}
try{const wf0=waFinish;waFinish=function(won){const A=S.wa,first=A&&!A.over;const r=wf0.apply(this,arguments);try{if(first&&fleLive()){fleGive(won?FLE.pay.arena:FLE.pay.arenaLoss,'arena');fleTask('arena',1)}}catch(e){}return r}}catch(e){}
/* Tower Defense: a map win (more for three stars), a loss that held three waves, the endless Wonderland by waves held */
try{const f0=rpFinish;rpFinish=function(won){const R=RPX,was=R&&R.over;const r=f0.apply(this,arguments);
 try{const res=R&&R.result;if(R&&!was&&R.over&&res&&!R._fle&&fleLive()){R._fle=1;
  if(res.endless){const n=Math.min(10,Math.floor((res.held|0)/5))*FLE.pay.tdEnd5;if(n)fleGive(n,'towers')}
  else if(res.won){fleGive(FLE.pay.td+(res.stars>=3?FLE.pay.td3:0),'towers');fleTask('td',1);if(res.stars>=3)fleTask('td3',1)}
  else if((res.cleared|0)>=3)fleGive(FLE.pay.tdLoss,'towers')}}catch(e){console.error(e)}return r}}catch(e){}
/* Runestone Riddle: today's riddle, or a practice riddle solved */
try{const f0=rrFinish;rrFinish=function(win){const daily=typeof RR==='object'&&RR&&RR.mode==='d';const r=f0.apply(this,arguments);
 try{if(fleLive()){if(daily){fleGive(win?FLE.pay.rr:FLE.pay.rrLoss,'riddle');fleTask('rr',1)}else if(win)fleGive(FLE.pay.rrPrac,'riddle')}}catch(e){}return r}}catch(e){}
/* Lantern Caravan */
try{const f0=wrFinish;wrFinish=function(won){const R=WRX,was=R&&R.over;const r=f0.apply(this,arguments);try{if(R&&!was&&R.over&&fleLive()){const res=R.result||{};if(won){fleGive(FLE.pay.wr,'caravan');fleTask('wr',1)}else if((res.prog||0)>=.3)fleGive(FLE.pay.wrLoss,'caravan')}}catch(e){}return r}}catch(e){}
/* Moonlit Fishing: every fish landed */
try{const f0=fsLand;fsLand=function(){const r=f0.apply(this,arguments);try{if(fleLive()){fleGive(FLE.pay.fish,'fishing');fleTask('fish',1)}}catch(e){}return r}}catch(e){}
/* The Crooked Cue: a paid match played to the end */
try{const f0=pzMatchEnd;pzMatchEnd=function(){const M=typeof PZ==='object'&&PZ?PZ.M:null,real=M&&M.over&&!M.practice&&!M.trick&&!M.forfeit&&PZ.ph!=='over',win=real&&M.over.winner===0;const r=f0.apply(this,arguments);
 try{if(real&&fleLive()){fleGive(win?FLE.pay.pool:FLE.pay.poolLoss,'pool');fleTask('pool',1)}}catch(e){}return r}}catch(e){}
/* Wildcard: a game played to the end (not pass-and-play, not a forfeit) */
try{const f0=wcRecord;wcRecord=function(o){const pp=typeof WX==='object'&&WX&&WX.mode==='pp',forf=!!(o&&o.forfeit);const r=f0.apply(this,arguments);try{if(r&&!pp&&!forf&&fleLive())fleGive(r.place===0?FLE.pay.wc:FLE.pay.wcLoss,'wildcard')}catch(e){}return r}}catch(e){}
/* Trick-or-Treat (while Halloween lasts): a finished street */
try{const f0=ttFinish;ttFinish=function(complete){const run=typeof TRT==='object'&&TRT?TRT.run:null,was=run&&run.phase==='done';const r=f0.apply(this,arguments);try{if(complete===true&&run&&!was&&fleLive())fleGive(FLE.pay.treat,'treat')}catch(e){}return r}}catch(e){}
/* the run's results list the acorns, like the Adventure Trail stamps */
{const rb0=resBlock;resBlock=function(){let h=rb0.apply(this,arguments);try{const n=S&&S.fleRun|0;if(n>0)h+=`<p class="flres">${fleIco('acorn',22)}<b>+${n} acorn${n===1?'':'s'}</b><span>for the Harvest Festival</span></p>`}catch(e){}return h}}

/* ---------- DEV › Cheats ---------- */
try{const h0=dvxHTML;dvxHTML=function(){let h=h0.apply(this,arguments);try{h+=`<div class="dvx"><h5>Harvest Festival</h5><div class="dvrow"><span>${fleAcorns().toLocaleString()} acorns${flOn()?'':' · festival off'}</span>${dvBtn('x:fle_ac','+1,000 acorns')}${dvBtn('x:fle_gt','Finish today\'s tasks')}${dvBtn('x:fle_cal','Open every past present')}${dvBtn('x:fle_hub','Open the festival')}${dvBtn('x:fle_reset','Reset the festival')}</div></div>`}catch(e){}return h};
 const a0=dvxAct;dvxAct=function(a){if(!/^fle_/.test(a))return a0.apply(this,arguments);const f=FLP(),e=f.fe;
  if(a==='fle_ac'){f.ac+=1000;e.tot+=1000;fleLedger(1000,'dev');dvxMsg('1,000 acorns added.')}
  else if(a==='fle_gt'){const G=fleGT();G.k.forEach((k,i)=>G.p[i]=FLE_TK[k].n);dvxMsg("Today's Gratitude tasks are ready to claim.")}
  else if(a==='fle_cal'){const now=fleCalNow();for(const d of FLE_DAYS)if(d<now&&!e.cal[d])e.cal[d]=1;dvxMsg('Every past present is open (no rewards paid).')}
  else if(a==='fle_hub'){setTimeout(()=>fleHub(),0);dvxMsg('Opening the Harvest Festival.')}
  else if(a==='fle_reset'){f.ac=0;delete f.fe;fleRepair(P);dvxMsg('The festival save was reset.')}
  save()}}catch(e){}
