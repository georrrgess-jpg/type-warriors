/* ===== WILDCARD: sound — "Neon Wildcard", an arcade lounge theme, and the card table's own sound effects =====
   Music: 16 bars in A minor at the casino's 116 bpm, synthesised live (25% pulse lead, chiptune arpeggios, a driving
   bass, a four-on-the-floor kick, claps and hats) through the casino's music bus, so the game's Music setting applies.
     menu  (lobby, menus, results): laid-back — soft kick, Rhodes-like chords, a gentle arpeggio, the lead in the B half
     game  (at the table): the full band and the lead hook all the way through
     tense (someone is down to one card, or a +4 or bigger stack is live): a faster arpeggio an octave up and an open filter
   Sound effects go through the game's sound-effects volume. wcFx(name, value) plays one. */
const WCM={lv:0,s:0,n0:0,pw:null,ac:null};
const wcMusic=()=>{try{return CAS.on&&ov.classList.contains('wcx')&&!ov.classList.contains('hide')}catch(e){return false}};
const mf=m=>440*Math.pow(2,(m-69)/12);
function wcPW(){if(WCM.pw&&WCM.ac===ac)return WCM.pw;WCM.ac=ac;/* a 25% pulse: real = sin(2πkd)/πk, imag = (1-cos 2πkd)/πk */
 const N=32,re=new Float32Array(N),im=new Float32Array(N),d=.25;for(let k=1;k<N;k++){re[k]=Math.sin(2*k*Math.PI*d)/(k*Math.PI);im[k]=(1-Math.cos(2*k*Math.PI*d))/(k*Math.PI)}return WCM.pw=ac.createPeriodicWave(re,im)}
/* one chip voice: pulse / square / triangle / saw with a low-pass and a quick envelope */
function wcv(t,f,d,o){const os=ac.createOscillator(),g=ac.createGain(),fl=ac.createBiquadFilter(),v=o.v||.05,a=o.a||.005,r=o.r||.08;
 if(o.w==='pulse')os.setPeriodicWave(wcPW());else os.type=o.w||'square';os.frequency.setValueAtTime(f,t);if(o.to)os.frequency.exponentialRampToValueAtTime(o.to,t+(o.tt||d));if(o.det)os.detune.value=o.det;
 fl.type='lowpass';fl.frequency.value=o.lp||6000;fl.Q.value=o.q||.5;g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(v,t+a);g.gain.setValueAtTime(v,t+Math.max(a,d-.01));g.gain.exponentialRampToValueAtTime(.0001,t+d+r);
 os.connect(fl);fl.connect(g);g.connect(o.bus);os.start(t);os.stop(t+d+r+.05)}
function wcKick(t,v,bus){const o=ac.createOscillator(),g=ac.createGain();o.type='sine';o.frequency.setValueAtTime(160,t);o.frequency.exponentialRampToValueAtTime(42,t+.12);g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.0001,t+.32);o.connect(g);g.connect(bus);o.start(t);o.stop(t+.35)}
/* chords per bar: [root midi, minor?] — A minor, with an E major lift */
const WCCH=[[57,1],[53,0],[48,0],[55,0],[57,1],[53,0],[55,0],[52,0],[53,0],[55,0],[52,1],[57,1],[50,1],[52,0],[57,1],[57,1]];
const WCMEL=(()=>{const _=null;return [[69,_,72,76,_,74,72,_],[69,_,_,72,69,_,67,_],[67,_,76,_,74,72,_,67],[71,_,74,_,79,_,76,74],[69,72,76,81,_,79,76,_],[77,_,76,72,_,69,72,_],[74,_,71,67,_,71,74,_],[76,_,68,71,76,_,_,_],
 [84,_,81,77,_,81,84,_],[83,_,79,74,_,79,83,_],[79,_,76,71,_,76,79,_],[81,_,_,76,_,72,_,69],[74,77,81,_,77,74,_,77],[76,80,83,_,80,76,_,71],[81,_,76,_,72,_,69,_],[69,_,_,_,_,_,_,_]]})();
function wcLevel(){try{if(!$('wct'))return 0;const G=WX.G;if(!G||G.phase==='over')return 0;return G.P.some(p=>p.hand.length===1)||G.stack>=4?2:1}catch(e){return 0}}
/* Wildcard's own trim on the casino music busses, so it sits at the same loudness as the casino theme */
function wcBus(lv){const K=kInit();if(!WCM.B||WCM.bk!==K){WCM.bk=K;WCM.B={};for(const k of ['pc','st','br']){const g=ac.createGain();g.connect(K[k]);WCM.B[k]=g}}
 const m=lv?1.2:1.6;for(const k in WCM.B)WCM.B[k].gain.value=m;return WCM.B}
function wcScore(t,n0){if(!WCM.s){WCM.s=1;WCM.n0=n0}KS.on=0;const n=n0-WCM.n0,bar=(n>>3)&15,k=n&7,sd=stepD(),h=sd/2;
 if(k===0)WCM.lv=wcLevel();const lv=WCM.lv,B=wcBus(lv),[root,mi]=WCCH[bar],third=mi?3:4,tones=[root,root+third,root+7,root+12],B2=bar>=8;
 /* drums */
 if(lv>0){if(k%2===0)wcKick(t,.5,B.pc);if(k===2||k===6){kns(t,.12,.16,1600,'bandpass',B.pc,.7);kns(t+.012,.08,.1,2400,'bandpass',B.pc,.9)}
  kns(t,.03,k%2?.07:.045,9000,'highpass',B.pc);kns(t+h,.025,.035,9500,'highpass',B.pc);if(bar===15&&k>=4)kns(t,.08,.12,1200+k*300,'bandpass',B.pc)}
 else{if(k===0||k===4)wcKick(t,.3,B.pc);if(k===4)kns(t,.1,.07,1800,'bandpass',B.pc,.6);if(k%2)kns(t,.03,.035,9000,'highpass',B.pc)}
 /* bass */
 if(lv>0){const f=k%2?root-12:root-24;wcv(t,mf(f+(k===7&&bar%2?7:0)),sd*.8,{w:'sawtooth',lp:lv===2?1400:900,v:.06,a:.004,r:.05,bus:B.pc,q:4})}
 else if(k===0||k===4||k===6)wcv(t,mf(k===4?root-17:root-24),sd*(k===0?2.6:1),{w:'triangle',lp:900,v:.08,a:.01,r:.15,bus:B.pc})
 /* chords: Rhodes-like on the menu, short stabs in game */
 if(lv===0&&k===0)for(const m of [root+12,root+12+third,root+19])wcv(t,mf(m),sd*7.4,{w:'triangle',lp:2200,v:.02,a:.03,r:.5,bus:B.st,det:(m%3-1)*6});
 if(lv>0&&(k===1||k===4))for(const m of [root+12,root+12+third,root+19])wcv(t,mf(m),sd*.5,{w:'square',lp:2400,v:.012,a:.004,r:.06,bus:B.st});
 /* arpeggio */
 const up=lv===2?24:12;for(const [dt,j] of [[0,k*2],[h,k*2+1]]){if(lv===0&&j%2)continue;const m=tones[j%4]+up;wcv(t+dt,mf(m),h*.85,{w:'pulse',lp:lv===2?7000:lv?4200:2600,v:lv===2?.022:lv?.018:.014,a:.002,r:.04,bus:B.st})}
 /* the lead hook */
 const note=WCMEL[bar][k];if(note!=null&&(lv>0||B2)){let len=1;while(k+len<8&&WCMEL[bar][k+len]===null&&len<3)len++;
  wcv(t,mf(note),sd*len*.92,{w:lv?'pulse':'triangle',lp:lv?5200:3200,v:lv?.045:.032,a:.006,r:.12,bus:B.br});if(lv)wcv(t,mf(note+12),sd*len*.5,{w:'triangle',lp:6000,v:.012,a:.006,r:.08,bus:B.br})}
 if(bar===0&&k===0&&lv>0)for(let i=0;i<4;i++)wcv(t+i*h*.5,mf(88+i*3),h*.4,{w:'square',lp:8000,v:.012,bus:B.st})}
{const n0=note;note=function(t,n){if(wcMusic())return wcScore(t,n);if(WCM.s)WCM.s=0;return n0(t,n)}}
/* ---------- sound effects ---------- */
function wcNz(t,d,v,fc,ty,q,to){if(!KS.nb)kInit();const s=ac.createBufferSource(),f=ac.createBiquadFilter(),g=ac.createGain();s.buffer=KS.nb;f.type=ty||'bandpass';f.frequency.setValueAtTime(fc,t);if(to)f.frequency.exponentialRampToValueAtTime(to,t+d);f.Q.value=q||1;
 g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(v,t+.004);g.gain.exponentialRampToValueAtTime(.0001,t+d);s.connect(f);f.connect(g);g.connect(sg);s.start(t,Math.random()*.4);s.stop(t+d+.05)}
const wcTone=(t,f,d,w,v,o)=>wcv(t,f,d,Object.assign({w:w||'square',v:v||.05,bus:sg,a:.003,r:.06},o||{}));
const WCFX={
 hover:t=>wcTone(t,1800,.015,'triangle',.02),
 click:t=>{wcTone(t,700,.03,'square',.03,{to:1100});wcNz(t,.03,.05,4000,'highpass')},
 back:t=>wcTone(t,900,.05,'square',.03,{to:500}),
 swish:t=>wcNz(t,.14,.16,1800,'bandpass',.8,6000),
 deal:t=>{wcNz(t,.07,.1,3000,'bandpass',.9,7000);wcTone(t+.05,2200,.02,'triangle',.02)},
 slap:t=>{wcNz(t,.07,.32,1300,'lowpass',.7);wcTone(t,150,.07,'sine',.16,{to:60})},
 flip:t=>wcNz(t,.05,.12,5000,'bandpass',2),
 draw:t=>{wcNz(t,.12,.14,2200,'bandpass',.8,5000);wcTone(t+.08,1320,.04,'triangle',.03)},
 chip:t=>{for(const [f,dt] of [[2600,0],[3400,.05],[2900,.11]])wcTone(t+dt,f,.06,'sine',.06,{r:.12})},
 coin:t=>{wcTone(t,988,.06,'square',.04);wcTone(t+.07,1319,.22,'square',.04,{r:.18})},
 turn:t=>{wcTone(t,660,.07,'pulse',.05);wcTone(t+.09,990,.12,'pulse',.05)},
 wild:t=>{[523,659,784,1047,1319].forEach((f,i)=>wcTone(t+i*.05,f,.07,'pulse',.045));wcNz(t+.2,.3,.06,9000,'highpass')},
 call:t=>{[784,988,1175,1568].forEach((f,i)=>wcTone(t+i*.06,f,.09,'square',.05));wcTone(t+.26,2093,.25,'triangle',.04,{r:.25})},
 catch:t=>{wcTone(t,140,.32,'sawtooth',.07,{lp:1200});wcTone(t,147,.32,'sawtooth',.05,{lp:1200});wcTone(t+.35,600,.12,'square',.04,{to:200})},
 stun:t=>{wcTone(t,1400,.2,'square',.05,{to:180});wcNz(t,.18,.12,3000,'bandpass',2,600)},
 rev:t=>{wcNz(t,.25,.12,600,'bandpass',1.5,4000);[523,659,784,659,523].forEach((f,i)=>wcTone(t+i*.05,f,.05,'pulse',.035))},
 d2:t=>{wcTone(t,1200,.16,'square',.05,{to:300});wcTone(t+.12,1000,.16,'square',.045,{to:250})},
 d4:t=>{wcTone(t,1500,.22,'sawtooth',.05,{to:200,lp:4000});wcTone(t+.1,1200,.24,'square',.045,{to:150});wcTone(t,90,.4,'sine',.18,{to:40});wcNz(t,.4,.12,400,'lowpass')},
 elem:(t,s)=>{const r={e:57,t:62,g:60,s:64}[s]||60;[0,4,7,12].forEach((i,j)=>wcTone(t+j*.045,mf(r+12+i),.1,'triangle',.05,{r:.2}))},
 shuffle:t=>{for(let i=0;i<16;i++)wcNz(t+i*.028,.02,.09,2500+Math.random()*2500,'bandpass',3)},
 bad:t=>{wcTone(t,220,.09,'square',.04,{lp:1400});wcTone(t+.1,180,.12,'square',.04,{lp:1200})},
 tick:t=>{wcTone(t,1600,.02,'square',.025);wcNz(t,.02,.05,6000,'highpass')},
 join:t=>{[659,880,1319].forEach((f,i)=>wcTone(t+i*.09,f,.12,'pulse',.045,{r:.15}));wcNz(t+.27,.2,.05,9000,'highpass')},
 leave:t=>{[880,659,440].forEach((f,i)=>wcTone(t+i*.09,f,.1,'pulse',.035))},
 pop:t=>wcTone(t,600,.05,'sine',.06,{to:1400}),
 ready:t=>{wcTone(t,784,.06,'square',.04);wcTone(t+.08,1175,.14,'square',.045)},
 win:t=>{const L=[[523,0,.12],[659,.12,.12],[784,.24,.12],[1047,.36,.2],[784,.6,.1],[1047,.72,.5]];for(const [f,dt,d] of L){wcTone(t+dt,f,d,'pulse',.055);wcTone(t+dt,f/2,d,'triangle',.05)}
  [1319,1568,2093].forEach((f,i)=>wcTone(t+1.25+i*.07,f,.2,'square',.03,{r:.3}));wcNz(t+1.2,.6,.06,9000,'highpass')},
 lose:t=>{[[392,0],[370,.2],[349,.4],[330,.6]].forEach(([f,dt])=>wcTone(t+dt,f,.18,'square',.045,{lp:2200}));wcTone(t+.8,311,.5,'square',.045,{lp:1800,to:200})},
 big:t=>{wcTone(t,80,.5,'sine',.2,{to:35});wcNz(t,.5,.15,500,'lowpass')},
 count:(t,v)=>wcTone(t,v?1320:880,.08,'square',.04)};
function wcFx(k,a){try{if(!ac||!sg||ST.svol<=0)return;const f=WCFX[k];if(f)f(ac.currentTime+.005,a)}catch(e){}}
