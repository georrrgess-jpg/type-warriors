/* ===== THE TOWER VOTE, switched off (97f, after 97e) =====
   The vote is over: Starfall Observatory won (now the tenth tower, 97d/97e). The poll is hidden but all its code stays in 96zz, so a
   new poll can be run later: set TPOLL.off = 0 (and give TPOLL a new id, tag, end, reward and opts in 96zz, with new art).
   Tests switch it back on with window.TPOLL_ON = 1 (set before the page loads). While off: no first-open window, no VOTE button by the bell, and tpShow does nothing. Saved votes (P.poll) are kept. */
TPOLL.off=window.TPOLL_ON?0:1;
{const b0=tpBtn;tpBtn=function(){if(TPOLL.off){const b=$('tpbtn');if(b)b.remove();return}return b0.apply(this,arguments)}}
{const s0=tpShow;tpShow=function(){if(TPOLL.off)return;return s0.apply(this,arguments)}}
