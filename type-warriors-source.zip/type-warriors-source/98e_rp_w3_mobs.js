/* ===== RUNESTONE TOWER DEFENSE 10.0: World 3 (Skyforge Heights) monsters (98e) =====
   Eight clockwork constructs, each drawn in its map's variant (o.v):
   - meadow  = verdigris copper with moss, vines, flowers and little birds (Cloudspire Meadows)
   - foundry = soot-black iron with furnace glow, hazard stripes and smoke (Gearworks Foundry)
   - storm   = polished silver-blue with crackling arcs and lightning glow (Storm Citadel)
   ids: cog (Cogling), knight (Brass Knight), steam (Steam Golem), gyro (Gyrocopter, flies), tinker (Chronotinker),
   spring (Springjack), jammer (Sparkjammer), titan (Titan Automaton, boss) and the boss's shed poses titan_p2 (after the
   first plates fall, 66% HP) and titan_p3 (after the second, 33%: exposed gears, glowing core). The core swaps e.id.
   Same contract as 95b / 95b2: RPMD[id](g,ph,o) draws facing right with the feet at (0,0); ph 0..1 is one walk cycle, baked
   into 8 frames, so every moving part (keys, rotors, gears, pistons, clock hands) turns a whole number of steps per cycle.
   RPMB / RPMK / RPVX size the frames. rpvDraw is wrapped so these ids draw their variant directly (no recolouring proxy);
   rpMobDeath is wrapped so they burst into gears, springs, bolts and plates in their variant's colours.
   Everything is baked once (rpvBake, graded by 97l like every monster); the battle only blits.
   Private helpers and globals are prefixed rpw3m. */
const RPW3M_V={
 meadow:{m:'#5ab49a',md:'#2f7c6c',ml:'#bdeed6',t:'#d4894e',td:'#93522c',b:'#e0ba5a',rv:'#f2d88c',gl:'#ffe45a',g2:'#ffa83a',dk:'#163832',ey:'#fff07a',dl:'#f6f0d2'},
 foundry:{m:'#58515f',md:'#332e3a',ml:'#a29aac',t:'#7c6656',td:'#46362c',b:'#c4903e',rv:'#e0b060',gl:'#ff7a1a',g2:'#ffd24a',dk:'#120a0e',ey:'#ffc23a',dl:'#d2c4b0'},
 storm:{m:'#9cb4dc',md:'#5e78ae',ml:'#f6faff',t:'#4a62a6',td:'#2a3a72',b:'#ffd66a',rv:'#fff2bc',gl:'#6af4ff',g2:'#c49aff',dk:'#141c3a',ey:'#a8fbff',dl:'#eaf4ff'}};
const rpw3mV=v=>RPW3M_V[v]?v:'meadow';
/* ---------- paths (Path2D, so one shape can be filled, textured inside a clip and outlined) ---------- */
function rpw3mPo(p){const P=new Path2D();P.moveTo(p[0],p[1]);for(let i=2;i<p.length;i+=2)P.lineTo(p[i],p[i+1]);P.closePath();return P}
function rpw3mPb(p){const P=new Path2D(),n=p.length>>1,X=i=>p[(i%n)*2],Y=i=>p[(i%n)*2+1];P.moveTo((X(n-1)+X(0))/2,(Y(n-1)+Y(0))/2);
 for(let i=0;i<n;i++)P.quadraticCurveTo(X(i),Y(i),(X(i)+X(i+1))/2,(Y(i)+Y(i+1))/2);P.closePath();return P}
function rpw3mPe(x,y,rx,ry,r){const P=new Path2D();P.ellipse(x,y,Math.max(.1,rx),Math.max(.1,ry),r||0,0,RPMT);return P}
function rpw3mPr(x,y,w,h,r){const P=new Path2D();P.roundRect(x,y,w,h,r);return P}
/* metal fill: cel shading (verdigris, soot iron) or a polished specular band (storm) */
function rpw3mMF(g,x0,y0,x1,y1,b,v,k){if(v==='storm')return rpmLG(g,x0,y0,x1,y1,[0,rpmSh(b,.55),.2,rpmSh(b,.18),.4,b,.47,rpmSh(b,.42),.53,rpmSh(b,.1),.7,rpmSh(b,-.2),1,rpmSh(b,-.45)]);return rpmCel(g,x0,y0,x1,y1,b,k)}
/* surface texture inside a shape: patina blotches, soot and rust, or polished gleam stripes */
function rpw3mTx(g,P,v,x0,y0,x1,y1,sd){const w=x1-x0,h=y1-y0;g.save();g.clip(P);
 if(v==='meadow'){for(let i=0;i<7;i++){const x=x0+w*rpmRn(sd+i*2.3),y=y0+h*rpmRn(sd+i*3.7),r=Math.min(w,h)*(.1+rpmRn(sd+i)*.16);g.fillStyle=i%3?'rgba(178,244,214,.34)':'rgba(24,90,78,.3)';g.beginPath();g.ellipse(x,y,r,r*.68,i,0,RPMT);g.fill()}}
 else if(v==='foundry'){g.fillStyle=rpmLG(g,0,y0,0,y1,[0,'rgba(10,6,12,0)',.5,'rgba(10,6,12,.1)',1,'rgba(10,6,12,.46)']);g.fillRect(x0,y0,w,h);
  for(let i=0;i<3;i++){const x=x0+w*rpmRn(sd+i*4.1),y=y0+h*(.3+rpmRn(sd+i*1.9)*.6),r=Math.min(w,h)*(.08+rpmRn(sd+i+3)*.1);g.fillStyle='rgba(150,74,34,.32)';g.beginPath();g.ellipse(x,y,r,r*.6,i,0,RPMT);g.fill()}}
 else{g.strokeStyle='rgba(255,255,255,.42)';g.lineWidth=Math.max(1.2,w*.09);g.beginPath();g.moveTo(x0+w*.62,y0-2);g.lineTo(x0+w*.12,y1+2);g.stroke();
  g.strokeStyle='rgba(255,255,255,.2)';g.lineWidth=Math.max(.8,w*.04);g.beginPath();g.moveTo(x0+w*.8,y0-2);g.lineTo(x0+w*.3,y1+2);g.stroke()}
 g.restore()}
/* fill a path, texture it, outline it */
function rpw3mDo(g,P,f,lw,v,bx,sd){g.fillStyle=f;g.fill(P);if(v&&bx)rpw3mTx(g,P,v,bx[0],bx[1],bx[2],bx[3],sd||1);if(lw!==0){g.lineWidth=lw||2.4;g.strokeStyle=RPMO;g.stroke(P)}}
/* a metal part in one call: path, box [x0,y0,x1,y1], base colour */
function rpw3mPart(g,P,bx,b,v,lw,sd,k){rpw3mDo(g,P,rpw3mMF(g,bx[0],bx[1],bx[2],bx[3],b,v,k),lw,v,bx,sd)}
/* ---------- clockwork pieces ---------- */
function rpw3mGearP(x,y,r,n,rot,th){const P=new Path2D(),ri=r-th,s=RPMT/n;
 for(let i=0;i<n;i++){const a=rot+i*s,A=[[ri,a-s*.27],[r,a-s*.16],[r,a+s*.16],[ri,a+s*.27]];
  for(let j=0;j<4;j++){const px=x+Math.cos(A[j][1])*A[j][0],py=y+Math.sin(A[j][1])*A[j][0];if(!i&&!j)P.moveTo(px,py);else P.lineTo(px,py)}
  P.arc(x,y,ri,a+s*.27,a+s*.73)}P.closePath();return P}
/* a toothed gear with spoke holes and a hub; o = {th tooth depth, holes (0 = none), hub colour, lw} */
function rpw3mGear(g,x,y,r,n,rot,b,v,o){o=o||{};const th=o.th||Math.max(1.3,r*.22),P=rpw3mGearP(x,y,r,n,rot,th),lw=o.lw||Math.max(1.2,Math.min(2.4,r*.16));
 g.fillStyle=v==='storm'?rpmRG(g,x,y,r,[0,rpmSh(b,.6),.45,rpmSh(b,.1),.8,b,1,rpmSh(b,-.4)],x-r*.35,y-r*.45):rpmRG(g,x,y,r,[0,rpmSh(b,.32),.55,b,.85,rpmSh(b,-.2),1,rpmSh(b,-.4)],x-r*.4,y-r*.45);g.fill(P);
 g.lineWidth=lw;g.strokeStyle=RPMO;g.stroke(P);const ri=r-th;
 g.beginPath();g.arc(x,y,ri*.84,0,RPMT);g.lineWidth=Math.max(.7,r*.06);g.strokeStyle=rpmA(RPMO,.4);g.stroke();
 const nh=o.holes==null?(r>7?5:0):o.holes;for(let k=0;k<nh;k++){const a=rot+k*RPMT/nh+.3;rpmEl(g,x+Math.cos(a)*ri*.52,y+Math.sin(a)*ri*.52,ri*.2,ri*.2,o.hole||'#1a1024',Math.max(.6,lw*.5))}
 rpmEl(g,x,y,Math.max(1.2,ri*.26),Math.max(1.2,ri*.26),rpmRG(g,x,y,ri*.26,[0,rpmSh(o.hub||b,.4),1,rpmSh(o.hub||b,-.25)],x-ri*.1,y-ri*.1),Math.max(.6,lw*.6));
 rpmEl(g,x,y,Math.max(.5,ri*.09),Math.max(.5,ri*.09),RPMO,0);
 rpmAH(g,x,y,ri*.92,ri*.92,3.6,4.5,.5,Math.max(.7,r*.08))}
/* a domed rivet */
function rpw3mRv(g,x,y,r,c){rpmEl(g,x,y,r,r,rpmRG(g,x,y,r,[0,'#fffdf0',.35,c,1,rpmSh(c,-.45)],x-r*.4,y-r*.45),Math.max(.5,r*.45))}
/* a lens eye in a brass bezel: glowing iris, slit pupil, angry lid (ang>0 lowers the front corner) */
function rpw3mEye(g,x,y,r,V,ang,lid){rpmGlow(g,x,y,r*3.2,V.gl,.5);
 rpmEl(g,x,y,r*1.32,r*1.32,rpmLG(g,x-r,y-r,x+r,y+r,[0,rpmSh(V.b,.45),.5,V.b,1,rpmSh(V.b,-.45)]),Math.max(1,r*.4));
 g.save();g.beginPath();g.arc(x,y,r,0,RPMT);g.clip();g.fillStyle=rpmRG(g,x+r*.15,y+r*.05,r*1.1,[0,'#fffef0',.25,V.ey,.7,V.gl,1,rpmSh(V.gl,-.45)]);g.fillRect(x-r,y-r,r*2,r*2);
 rpmEl(g,x+r*.28,y+r*.08,r*.24,r*.42,'#1a0c18',0);
 if(lid!==0){g.fillStyle=lid||V.md;g.beginPath();g.moveTo(x-r*1.5,y-r*1.6);g.lineTo(x+r*1.5,y-r*1.6);g.lineTo(x+r*1.5,y-r*(.3-ang));g.lineTo(x-r*1.5,y-r*(.3+ang));g.closePath();g.fill();
  g.beginPath();g.moveTo(x-r*1.5,y-r*(.3+ang));g.lineTo(x+r*1.5,y-r*(.3-ang));g.lineWidth=Math.max(.9,r*.34);g.strokeStyle=RPMO;g.stroke()}
 g.restore();rpmEl(g,x-r*.3,y+r*.2,r*.2,r*.16,'rgba(255,255,255,.85)',0)}
/* a toothy grin between (x0,y0) and (x1,y1); glow fills it with furnace light */
function rpw3mGrin(g,x0,y0,x1,y1,dip,n,V,glow){const mx=(x0+x1)/2;g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo(mx,(y0+y1)/2+dip*2.2,x1,y1);g.quadraticCurveTo(mx,(y0+y1)/2+dip*.4,x0,y0);g.closePath();
 g.fillStyle=glow?rpmLG(g,0,y0-1,0,y0+dip*2,[0,V.g2,1,V.gl]):'#1a0c18';g.fill();g.lineWidth=1.4;g.strokeStyle=RPMO;g.stroke();
 for(let i=1;i<n;i++){const u=i/n,x=x0+(x1-x0)*u,yt=y0+(y1-y0)*u+dip*.4*Math.sin(u*Math.PI)*.9,yb=y0+(y1-y0)*u+dip*2.2*Math.sin(u*Math.PI)*.5;
  rpmP(g,[x-1,yt,x+1,yt,x,yt+(yb-yt)*.75]);g.fillStyle='#fffbe8';g.fill()}}
/* a coil spring along the y axis from yb (bottom) to yt (top): back halves dark, front halves bright */
function rpw3mCoil(g,x,yb,yt,r,n,w,c,v){const d=(yb-yt)/n,tilt=r*.34,pt=t=>[x+Math.cos(t)*r,yb-d*(t/RPMT)+Math.sin(t)*tilt-d*.25];
 const run=(t0,t1,col)=>{g.beginPath();for(let k=0;k<=8;k++){const p=pt(t0+(t1-t0)*k/8);k?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1])}g.lineCap='round';g.lineJoin='round';g.lineWidth=w+2.4;g.strokeStyle=RPMO;g.stroke();g.lineWidth=w;g.strokeStyle=col;g.stroke()};
 for(let i=0;i<n;i++)run(i*RPMT+Math.PI,i*RPMT+RPMT,rpmSh(c,-.42));
 for(let i=0;i<n;i++){run(i*RPMT,i*RPMT+Math.PI,c);const p0=pt(i*RPMT+.6),p1=pt(i*RPMT+1.7);g.beginPath();g.moveTo(p0[0],p0[1]-w*.2);g.lineTo(p1[0],p1[1]-w*.2);rpmHi(g,v==='storm'?.85:.55,Math.max(.6,w*.3))}}
/* a wind-up key on a horizontal shaft (dir -1 points left); its bow turns by spin radians about the shaft */
function rpw3mKey(g,x,y,len,R,spin,V,v,dir){dir=dir||-1;const cs=Math.cos(spin),sy=Math.max(.14,Math.abs(cs)),bx=x+dir*(len+R*.6),col=cs>0?V.b:rpmSh(V.b,-.22);
 rpmLimb(g,[x,y,bx,y],R*.46,rpmSh(V.b,-.1),1.6);g.beginPath();g.moveTo(x,y-R*.1);g.lineTo(bx,y-R*.1);rpmHi(g,.6,.8);
 for(const s of[-1,1]){rpmEl(g,bx,y+s*R*.92*sy,R*.6,R*.88*sy+.5,rpw3mMF(g,bx-R,y-R*1.8*sy,bx+R,y+R*1.8*sy,col,v),1.5);rpmEl(g,bx,y+s*R*1.02*sy,R*.22,R*.34*sy+.2,'#1a1024',0)}
 rpmEl(g,bx,y,R*.4,R*.4*Math.max(.55,sy),rpw3mMF(g,bx-R*.4,y-R*.4,bx+R*.4,y+R*.4,rpmSh(col,.15),v),1.3);
 rpmEl(g,x+dir*len*.12,y,R*.34,R*.5,rpw3mMF(g,x-R,y-R,x+R,y+R,V.b,v),1.3)}
/* hazard stripes clipped to a path */
function rpw3mHaz(g,P,x0,y0,x1,y1,sw,lw){g.save();g.clip(P);g.fillStyle='#ffc426';g.fillRect(x0,y0,x1-x0,y1-y0);g.fillStyle='#1c1418';const h=y1-y0;
 for(let x=x0-h;x<x1+h;x+=sw*2){g.beginPath();g.moveTo(x,y1);g.lineTo(x+sw,y1);g.lineTo(x+sw+h,y0);g.lineTo(x+h,y0);g.closePath();g.fill()}
 g.fillStyle=rpmLG(g,0,y0,0,y1,[0,'rgba(255,255,255,.25)',.5,'rgba(255,255,255,0)',1,'rgba(10,6,12,.35)']);g.fillRect(x0,y0,x1-x0,y1-y0);g.restore();
 if(lw!==0){g.lineWidth=lw||1.8;g.strokeStyle=RPMO;g.stroke(P)}}
/* an electric arc between two points (seeded jitter), glow plus white core */
function rpw3mArc(g,x0,y0,x1,y1,sd,amp,col,w){const n=6,dx=x1-x0,dy=y1-y0,L=Math.hypot(dx,dy)||1,nx=-dy/L,ny=dx/L,p=[x0,y0];w=w||1.4;
 for(let i=1;i<n;i++){const u=i/n,o=(rpmRn(sd+i*7.3)-.5)*2*amp*Math.sin(u*Math.PI);p.push(x0+dx*u+nx*o,y0+dy*u+ny*o)}p.push(x1,y1);
 const P=()=>{g.beginPath();g.moveTo(p[0],p[1]);for(let i=2;i<p.length;i+=2)g.lineTo(p[i],p[i+1])};
 g.save();g.lineCap='round';g.lineJoin='round';g.globalCompositeOperation='lighter';P();g.lineWidth=w*3.4;g.strokeStyle=rpmA(col,.32);g.stroke();
 P();g.lineWidth=w*1.5;g.strokeStyle=rpmA(col,.9);g.stroke();P();g.lineWidth=w*.6;g.strokeStyle='#ffffff';g.stroke();g.restore()}
/* smoke (dark) or steam puffs drifting from (x,y): n puffs along (dx,dy), looped on ph */
function rpw3mPuff(g,x,y,ph,sc,dark,n,dx,dy){n=n||3;dx=dx==null?-8:dx;dy=dy==null?-16:dy;
 for(let i=0;i<n;i++){const u=(ph+i/n)%1,px=x+dx*u*sc+Math.sin(u*6.3+i*2)*1.2*sc,py=y+dy*u*sc,r=(1.6+u*3.6)*sc;g.globalAlpha=Math.min(1,(1-u)*1.6)*.92;
  g.fillStyle=dark?rpmRG(g,px,py,r,[0,'#aaa2b0',.6,'#6c6474',1,'#4a4452'],px-r*.4,py-r*.4):rpmRG(g,px,py,r,[0,'#ffffff',.6,'#eef4fa',1,'#c4d4e4'],px-r*.4,py-r*.4);
  g.beginPath();g.arc(px,py,r,0,RPMT);g.fill();g.lineWidth=.9;g.strokeStyle=dark?'rgba(18,8,31,.55)':'rgba(90,120,160,.6)';g.stroke()}g.globalAlpha=1}
/* a small cartoon bird (meadow): round body, wing flick, beak, eye */
function rpw3mBird(g,x,y,sc,ph,col){col=col||'#4aa8f0';const t=ph*RPMT,fl=Math.sin(t*2);g.save();g.translate(x,y);g.scale(sc,sc);
 rpmP(g,[-5,-2,-10,-4.4,-9,-.6]);rpmFS(g,rpmSh(col,-.25),1.2);
 rpmEl(g,0,-3,5.6,4.6,rpmRG(g,0,-3,6,[0,rpmSh(col,.35),.6,col,1,rpmSh(col,-.3)],-2,-5),1.5);rpmEl(g,1.6,-1.4,3,2.6,'#ffb46a',0);
 g.save();g.translate(-1,-3.4);g.rotate(-.3-fl*.35);rpmEl(g,-2,0,3.6,2,rpmSh(col,-.2),1.2);g.restore();
 rpmEl(g,3.2,-6.4,3.4,3.2,rpmRG(g,3.2,-6.4,3.6,[0,rpmSh(col,.4),1,col],2,-8),1.5);rpmP(g,[6,-7,9,-6,6,-5]);rpmFS(g,'#ffc23a',.9);
 rpmEl(g,4.4,-7,1,1.1,RPMO,0);rpmEl(g,4.1,-7.4,.35,.35,'#fff',0);g.restore()}
/* a twig nest bowl, w wide, rim at y */
function rpw3mNest(g,x,y,w){const h=w*.42;g.beginPath();g.moveTo(x-w/2,y-h*.7);g.quadraticCurveTo(x,y+h*.9,x+w/2,y-h*.7);g.quadraticCurveTo(x,y-h*.1,x-w/2,y-h*.7);g.closePath();rpmFS(g,rpmLG(g,0,y-h,0,y+h*.4,[0,'#c89a5a',1,'#7a5228']),1.6);
 g.beginPath();for(let i=0;i<7;i++){const u=i/6;g.moveTo(x-w/2+u*w*.9,y-h*.6+Math.sin(u*Math.PI)*h*.5);g.lineTo(x-w/2+u*w*.9+w*.16,y-h*.4+Math.sin(u*Math.PI+.4)*h*.4)}g.lineWidth=.8;g.strokeStyle='#5a3a1a';g.stroke();
 for(const k of[-1,1]){g.beginPath();g.moveTo(x+k*w*.5,y-h*.66);g.lineTo(x+k*w*.62,y-h*.95);g.lineWidth=2.4;g.strokeStyle=RPMO;g.stroke();g.lineWidth=1;g.strokeStyle='#a87a42';g.stroke()}}
/* a vine with leaves along a polyline */
function rpw3mVine(g,p,sd,lf){g.beginPath();g.moveTo(p[0],p[1]);for(let i=2;i<p.length;i+=2)g.lineTo(p[i],p[i+1]);g.lineCap='round';g.lineJoin='round';g.lineWidth=3.6;g.strokeStyle=RPMO;g.stroke();g.lineWidth=1.6;g.strokeStyle='#4a9a34';g.stroke();
 for(let i=2;i<p.length;i+=2){if(lf===0)break;const a=rpmRn(sd+i)*RPMT,s=lf||1;g.save();g.translate(p[i],p[i+1]);g.rotate(a);g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(2.4*s,-2.6*s,5*s,0);g.quadraticCurveTo(2.4*s,2.6*s,0,0);rpmFS(g,i%4?'#6cc444':'#8ad85a',1);g.restore()}}
/* a small daisy */
function rpw3mDaisy(g,x,y,r,c,cc){for(let i=0;i<6;i++){const t=i/6*RPMT;rpmEl(g,x+Math.cos(t)*r*.9,y+Math.sin(t)*r*.9,r*.62,r*.42,c||'#ffffff',.9,t)}rpmEl(g,x,y,r*.46,r*.46,cc||'#ffd84a',.9)}
/* a jagged lightning bolt */
function rpw3mBoltP(x,y,s){return rpw3mPo([x-.5*s,y-4*s,x+2.2*s,y-4*s,x+.6*s,y-.8*s,x+2.4*s,y-.8*s,x-1.8*s,y+4.4*s,x-.4*s,y+.4*s,x-2*s,y+.4*s])}

/* ========== 1. Cogling: a living gear on little boots, a wind-up key turning in its back ========== */
RPMD.cog=function(g,ph,o){const v=rpw3mV(o&&o.v),V=RPW3M_V[v],a=ph*RPMT,s=Math.sin(a),by=-Math.abs(s)*2.2,cx=0,cy=-25+by,R=14.6;
 /* legs and boots: a quick trot (two steps per cycle) */
 const leg=(p,col,hx,dk)=>{const fx=hx+6*Math.sin(p),fy=-Math.max(0,Math.cos(p))*4,k=rpmKnee(hx,-11+by,fx,fy-2.4,12,-1);
  rpmLimb(g,[hx,-11+by,k[0],k[1],fx,fy-2.4],2.8,col,1.8);rpw3mRv(g,k[0],k[1],1.6,V.b);
  g.save();g.translate(fx,fy);g.rotate(Math.cos(p)*-.18);const P=new Path2D();P.moveTo(-3.6,0);P.lineTo(-3.4,-4.2);P.quadraticCurveTo(1,-5.2,3.4,-3.6);P.quadraticCurveTo(7,-3,6.6,0);P.closePath();
  rpw3mPart(g,P,[-4,-5,7,0],dk?rpmSh(V.t,-.25):V.t,v,1.6,5);g.beginPath();g.moveTo(-3.6,-1.2);g.lineTo(6.6,-1.2);g.lineWidth=.9;g.strokeStyle=rpmA(RPMO,.6);g.stroke();g.restore()};
 const sw=s*3.2;
 /* far arm and leg */
 rpmLimb(g,[cx-9,cy+7,cx-13-sw*.5,cy+11,cx-15-sw,cy+14],2.6,V.md,1.8);rpmEl(g,cx-15-sw,cy+14,2.4,2.4,rpw3mMF(g,cx-18,cy+11,cx-12,cy+17,rpmSh(V.t,-.25),v),1.4);
 leg(a+Math.PI,V.md,-2,1);
 /* the wind-up key in its back: one full turn per cycle */
 rpw3mKey(g,cx-R+2,cy,6,4.6,a,V,v,-1);
 /* the gear body: the rim rolls two teeth per cycle */
 rpw3mGear(g,cx,cy,R,10,a*2/10+.1,V.m,v,{th:3.6,holes:0,lw:2.2});
 /* the enamel face dial with ticks */
 const fx0=cx+1,FP=rpw3mPe(fx0,cy,9.6,9.6);rpw3mDo(g,FP,rpmRG(g,fx0,cy,10,[0,'#fffdf4',.6,V.dl,1,rpmSh(V.dl,-.22)],fx0-3,cy-4),0);
 g.beginPath();for(let i=0;i<12;i++){const t=i/12*RPMT;g.moveTo(fx0+Math.cos(t)*7.4,cy+Math.sin(t)*7.4);g.lineTo(fx0+Math.cos(t)*(i%3?8.2:8.8),cy+Math.sin(t)*(i%3?8.2:8.8))}g.lineWidth=.9;g.strokeStyle=rpmA(RPMO,.55);g.stroke();
 g.beginPath();g.arc(fx0,cy,9.6,0,RPMT);g.lineWidth=3.8;g.strokeStyle=RPMO;g.stroke();g.lineWidth=2.1;g.strokeStyle=v==='storm'?V.t:V.b;g.stroke();
 g.beginPath();g.arc(fx0,cy,9.6,3.5,4.6);rpmHi(g,.55,.9);
 for(let i=0;i<8;i++){const t=i/8*RPMT+.2;rpw3mRv(g,fx0+Math.cos(t)*9.6,cy+Math.sin(t)*9.6,.8,V.rv)}
 /* face: two lens eyes and a toothy grin */
 rpw3mEye(g,cx+3.4,cy-2,3.6,V,.34);rpw3mEye(g,cx+9.2,cy-2.4,2.5,V,-.25);
 rpw3mGrin(g,cx+1.2,cy+4,cx+10.4,cy+3.2,1.9,4,V,v==='foundry');
 /* the near leg and arm */
 leg(a,V.m,1,0);
 const ax=cx+17+sw,ay=cy+13;rpmLimb(g,[cx+11,cy+7,cx+14+sw*.5,cy+10,ax,ay],2.8,V.m,1.8);rpmEl(g,ax,ay,2.6,2.6,rpw3mMF(g,ax-3,ay-3,ax+3,ay+3,V.t,v),1.4);
 /* top: the variant's crest */
 const tx=1,ty=cy-R+1.6;
 if(v==='meadow'){/* a moss cap draped over the top teeth, a sprout and a daisy on a spring stalk */
  rpvMoss(g,[tx-11,ty+4.6,tx-8,ty-2,tx-2,ty-4.4,tx+5,ty-3.6,tx+10,ty-.2,tx+11.4,ty+4.4,tx+7,ty+2.4,tx+2,ty+3.4,tx-3,ty+2.2,tx-7,ty+3.6],[[tx-6,ty-1,2.2],[tx+6,ty-.4,1.9],[tx-10,ty+3.6,1.5]]);
  for(const [x,l] of[[tx-9.4,4.4],[tx+9.6,3.6]]){g.beginPath();g.moveTo(x,ty+3);g.quadraticCurveTo(x+.8,ty+3+l*.6,x+.2,ty+3+l);g.lineWidth=3;g.strokeStyle=RPMO;g.stroke();g.lineWidth=1.3;g.strokeStyle='#5ca83a';g.stroke()}
  const sx=Math.sin(a*2)*1.2;rpw3mCoil(g,tx,ty-1.6,ty-8.6,1.8,3,1.1,V.b,v);
  g.beginPath();g.moveTo(tx,ty-8.6);g.quadraticCurveTo(tx+sx*.5,ty-11.4,tx+sx,ty-13.4);g.lineWidth=3.2;g.strokeStyle=RPMO;g.stroke();g.lineWidth=1.4;g.strokeStyle='#5aac3a';g.stroke();
  rpw3mDaisy(g,tx+sx,ty-14.4,2.7,'#ffffff','#ffd84a');
  g.save();g.translate(tx-2.4,ty-3.6);g.rotate(-.5);g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(-1,-4,-5,-5.4);g.quadraticCurveTo(-2.6,-1.4,0,0);rpmFS(g,'#8ad85a',1);g.restore()}
 else if(v==='foundry'){/* a little smokestack puffing soot */
  const P=rpw3mPo([tx-2.6,ty+1,tx-2.2,ty-8,tx+2.2,ty-8,tx+2.6,ty+1]);rpw3mPart(g,P,[tx-3,ty-8,tx+3,ty+1],V.m,v,1.6,9);
  const P2=rpw3mPr(tx-3.6,ty-10,7.2,2.6,1);rpw3mHaz(g,P2,tx-4,ty-10,tx+4,ty-7.4,1.2,1.4);
  rpmGlow(g,tx,ty-10,5,V.gl,.6);rpw3mPuff(g,tx,ty-11,ph,1,1,3,-9,-10)}
 else{/* a lightning rod with a crackling orb */
  rpmLimb(g,[tx,ty+1,tx,ty-10],1.6,V.ml,1.4);for(const y of[ty-2,ty-5])rpmEl(g,tx,y,2.2,.9,V.t,1);
  rpmGlow(g,tx,ty-12,8,V.gl,.75);rpmEl(g,tx,ty-12,2.6,2.6,rpmRG(g,tx,ty-12,2.6,[0,'#ffffff',.5,V.ey,1,V.gl],tx-.8,ty-12.8),1.2);
  const f=Math.floor(ph*8);rpw3mArc(g,tx,ty-12,tx+(f%2?7:-7),ty-2+(f%3),f*13+1,2.2,V.gl,.9);if(f%2)rpw3mArc(g,tx,ty-12,tx-5,ty-17,f*7+3,1.6,V.g2,.8)}
};

/* ========== 2. Brass Knight: a bucket-helmed clockwork knight behind a big riveted shield ========== */
RPMD.knight=function(g,ph,o){const v=rpw3mV(o&&o.v),V=RPW3M_V[v],a=ph*RPMT,s=Math.sin(a),by=-Math.abs(Math.cos(a))*1.8,sb=by*.8+Math.sin(a*2+.6)*.5;
 const hip=[-1,-25+by];
 const leg=(p,col,dk)=>{const fx=-1+8*Math.sin(p),fy=-Math.max(0,Math.cos(p))*4.4,k=rpmKnee(hip[0],hip[1],fx,fy-3,27,-1);
  rpmLimb(g,[hip[0],hip[1],k[0],k[1]],5.4,col,2);rpmLimb(g,[k[0],k[1],fx,fy-3],4.6,rpmSh(col,-.08),2);
  /* knee cop and greave */
  rpmEl(g,k[0]+.6,k[1],3.6,3.2,rpw3mMF(g,k[0]-3,k[1]-3,k[0]+4,k[1]+3,dk?rpmSh(V.b,-.3):V.b,v),1.6);rpw3mRv(g,k[0]+.8,k[1],1,V.rv);
  g.save();g.translate(fx,fy);const P=new Path2D();P.moveTo(-4.4,0);P.lineTo(-4,-5.4);P.lineTo(2,-5.6);P.quadraticCurveTo(7,-4.4,10,-.4);P.lineTo(10,0);P.closePath();
  rpw3mPart(g,P,[-5,-6,10,0],col,v,1.8,7);g.beginPath();g.moveTo(1.6,-5.4);g.lineTo(2.6,0);g.moveTo(5.4,-3.8);g.lineTo(6,0);g.lineWidth=.9;g.strokeStyle=rpmA(RPMO,.6);g.stroke();g.restore()};
 /* sword arm behind: a short blade with a cog guard */
 const shx=-6,shy=-45+by,hx=-12,hy=-41+by+s*.8;rpmLimb(g,[shx,shy,-14,-38+by,hx,hy],3.4,V.md,1.8);
 g.save();g.translate(hx,hy);g.rotate(-.55+s*.04);
 const BL=rpw3mPo([-2,-3,-2.2,-25,0,-29,2.2,-25,2,-3]);g.fillStyle=rpmLG(g,-2,0,2,0,v==='foundry'?[0,'#8a8290',.5,'#5a5462',.52,'#3e3846',1,'#2c2832']:[0,'#f4f8ff',.5,'#b4c0d0',.52,'#8692a6',1,'#6a7488']);g.fill(BL);g.lineWidth=1.6;g.strokeStyle=RPMO;g.stroke(BL);
 g.beginPath();g.moveTo(-.4,-5);g.lineTo(-.6,-23);rpmHi(g,.6,.8);
 if(v==='foundry'){g.save();g.clip(BL);g.fillStyle=rpmLG(g,0,-29,0,-14,[0,'rgba(255,200,80,.95)',.5,'rgba(255,110,30,.7)',1,'rgba(255,90,20,0)']);g.fillRect(-3,-30,6,17);g.restore();rpmGlow(g,0,-24,7,V.gl,.5)}
 rpw3mGear(g,0,-2.4,4.2,8,a/8,V.b,v,{holes:0,th:1.4,lw:1.4});rpmLimb(g,[0,0,0,5],2.6,'#6a4426',1.4);rpmEl(g,0,6,1.7,1.7,V.b,1.1);
 g.restore();rpmEl(g,hx,hy,2.6,2.6,V.md,1.4);
 if(v==='storm'){const f=Math.floor(ph*8);g.save();g.translate(hx,hy);g.rotate(-.55);rpw3mArc(g,-1,-6,1.4,-27,f*11+2,2.2,V.gl,.9);g.restore()}
 leg(a+Math.PI,V.md,1);
 /* barrel torso with bands, rivets and a porthole showing a turning gear */
 const TB=[-12,-50+by,10,-22+by],TP=rpw3mPr(-12,-50+by,22,28,7);rpw3mPart(g,TP,TB,V.m,v,2.4,11);
 for(const y of[-45,-28]){const BP=rpw3mPr(-12.4,y-1.8+by,22.8,3.6,1.6);rpw3mPart(g,BP,[-12,y-2+by,10,y+2+by],v==='storm'?V.t:V.b,v,1.4,y);for(const x of[-9,-4.5,0,4.5])rpw3mRv(g,x,y+by,.8,V.rv)}
 const px=-3,py=-36.6+by;g.save();g.beginPath();g.arc(px,py,4.6,0,RPMT);g.clip();g.fillStyle=V.dk;g.fillRect(px-5,py-5,10,10);rpw3mGear(g,px-1,py+1,4.6,8,a/4,V.b,v,{holes:0,th:1.4,lw:1});rpmGlow(g,px,py,6,V.gl,.35);g.restore();
 g.beginPath();g.arc(px,py,4.6,0,RPMT);g.lineWidth=3.6;g.strokeStyle=RPMO;g.stroke();g.lineWidth=1.8;g.strokeStyle=V.b;g.stroke();
 g.beginPath();g.arc(px,py,3,3.6,4.6);rpmHi(g,.75,1);
 leg(a,V.m,0);
 /* helmet: a great helm with a glowing visor slit */
 const hb=Math.sin(a*2)*.5,HY=-49+by+hb,HP=new Path2D();HP.moveTo(-9.4,HY+1);HP.lineTo(-9.8,HY-13);HP.quadraticCurveTo(-9,HY-20,1,HY-20.4);HP.quadraticCurveTo(11.6,HY-20,12,HY-12);HP.lineTo(12.6,HY+1);HP.quadraticCurveTo(1.6,HY+3.4,-9.4,HY+1);HP.closePath();
 /* crest behind the helmet */
 if(v==='meadow'){for(const [ang,l,c] of[[-1.9,15,'#5aac3a'],[-2.35,13,'#7ccc4a'],[-1.55,12,'#4a9a34']]){g.save();g.translate(-1,HY-18);g.rotate(ang+Math.sin(a*2)*.05);const F=new Path2D();F.moveTo(0,0);F.quadraticCurveTo(l*.5,-3.6,l,0);F.quadraticCurveTo(l*.5,3.6,0,0);g.fillStyle=c;g.fill(F);g.lineWidth=1.3;g.strokeStyle=RPMO;g.stroke(F);
  g.beginPath();g.moveTo(1,0);g.lineTo(l-1,0);for(let k=1;k<5;k++){const x=l*k/5;g.moveTo(x,0);g.lineTo(x+1.6,-1.8);g.moveTo(x,0);g.lineTo(x+1.6,1.8)}g.lineWidth=.6;g.strokeStyle=rpmA(RPMO,.5);g.stroke();g.restore()}}
 else if(v==='foundry'){const F=rpw3mPo([-6,HY-18,-15,HY-22,-13,HY-15,-6,HY-12]);rpw3mHaz(g,F,-16,HY-23,-5,HY-11,1.6,1.4);
  const CP=rpw3mPr(-11.6,HY-16,4.4,8,1);rpw3mPart(g,CP,[-12,HY-16,-7,HY-8],V.m,v,1.4,3);rpw3mPuff(g,-9.4,HY-17,ph,.9,1,3,-10,-9)}
 else{const F=rpw3mPo([-3,HY-19,4,HY-19,1,HY-25,7,HY-25,-4,HY-36,-1,HY-27,-6,HY-27]);rpmGlow(g,0,HY-27,11,V.gl,.55);g.fillStyle=rpmLG(g,-6,HY-36,7,HY-19,[0,'#ffffff',.4,V.b,1,'#e8a020']);g.fill(F);g.lineWidth=1.5;g.strokeStyle=RPMO;g.stroke(F)}
 /* gorget under the helm */
 rpmEl(g,1,HY+1.4,10,3.4,rpw3mMF(g,-9,HY-2,11,HY+5,V.md,v),2);
 rpw3mPart(g,HP,[-10,HY-21,13,HY+2],V.m,v,2.4,21);
 const RB=new Path2D();RB.moveTo(-9.6,HY-2.6);RB.quadraticCurveTo(1.6,HY,12.4,HY-2.6);RB.lineTo(12.6,HY+1);RB.quadraticCurveTo(1.6,HY+3.4,-9.4,HY+1);RB.closePath();rpw3mPart(g,RB,[-10,HY-3,13,HY+3],v==='foundry'?V.b:V.t,v,1.6,23);
 /* ridge, visor slit with eyes, breathing holes */
 g.beginPath();g.moveTo(2,HY-20);g.quadraticCurveTo(9.6,HY-17,11.6,HY-9);g.lineWidth=1.2;g.strokeStyle=rpmA(RPMO,.6);g.stroke();
 const VS=rpw3mPr(-1,HY-12.6,13.6,4.4,1.6);g.fillStyle=V.dk;g.fill(VS);g.lineWidth=1.6;g.strokeStyle=RPMO;g.stroke(VS);
 rpmGEye(g,4.4,HY-10.4,1.7,V.gl,1.3);rpmGEye(g,9.4,HY-10.6,1.3,V.gl,1.1);
 g.beginPath();g.moveTo(-.6,HY-13.4);g.lineTo(12.6,HY-12.6);g.lineWidth=1.4;g.strokeStyle=rpmSh(V.m,.3);g.stroke();
 for(let i=0;i<3;i++)for(let j=0;j<2;j++)rpmEl(g,6+i*2.2,HY-4.6+j*2.2,.55,.55,V.dk,0);
 rpmAH(g,0,HY-8,9,10,3.4,4.5,.55,1.4);
 for(const x of[-6.6,-2.2,2.2])rpw3mRv(g,x,HY-.4,.85,V.rv);
 if(v==='meadow'){rpvMoss(g,[-9,HY-15,-6,HY-20,1,HY-21.6,7,HY-20.4,4,HY-18,-2,HY-18.6,-6,HY-15.4],[[-4,HY-19,1.6]]);rpw3mDaisy(g,5,HY-20.6,2.2,'#ff9ad0','#ffe46a')}
 /* layered pauldron on the near shoulder */
 for(const [k,dy] of[[1,0]]){const P=new Path2D(),x0=2,x1=13.4,y=-45+by+dy;P.moveTo(x0,y+3);P.quadraticCurveTo(x0+1,y-5*k,(x0+x1)/2,y-5.6*k);P.quadraticCurveTo(x1-1,y-5*k,x1,y+3);P.quadraticCurveTo((x0+x1)/2,y+.6,x0,y+3);P.closePath();
  rpw3mPart(g,P,[x0,y-6,x1,y+3],dy?V.m:(v==='storm'?V.t:V.b),v,1.8,40+dy);rpw3mRv(g,(x0+x1)/2,y-2.6*k,.9,V.rv)}
 if(v==='meadow'){rpvMoss(g,[3,-46+by,6,-50.4+by,10,-50.4+by,13,-46.4+by,9,-47.6+by,5,-47.4+by],[[7.6,-49.6+by,1.4]])}
 /* the shield */
 g.save();g.translate(1,sb+1);
 const SP=(k)=>{const cx=21,cy=-35,T=(x,y)=>[cx+(x-cx)*k,cy+(y-cy)*k],P=new Path2D();let q=T(8,-56);P.moveTo(q[0],q[1]);
  let c=T(20,-60),e=T(33,-56);P.quadraticCurveTo(c[0],c[1],e[0],e[1]);e=T(33,-33);P.lineTo(e[0],e[1]);c=T(32,-19);e=T(20.5,-9);P.quadraticCurveTo(c[0],c[1],e[0],e[1]);
  c=T(9,-19);e=T(8,-33);P.quadraticCurveTo(c[0],c[1],e[0],e[1]);P.closePath();return P};
 g.save();g.translate(-2.8,.8);g.fillStyle=rpmSh(V.md,-.25);g.fill(SP(1));g.lineWidth=2.2;g.strokeStyle=RPMO;g.stroke(SP(1));g.restore();
 const S0=SP(1),S1=SP(.8),SB=[8,-60,33,-9];
 if(v==='foundry'){rpw3mHaz(g,S0,8,-60,33,-9,2.6,0)}else rpw3mPart(g,S0,SB,v==='storm'?V.t:V.b,v,0,31);
 rpw3mPart(g,S1,SB,V.m,v,1.6,33);g.lineWidth=2.6;g.strokeStyle=RPMO;g.stroke(S0);
 for(const [x,y] of[[10.6,-55],[20.5,-57.6],[30.4,-55],[31,-42],[30.6,-28],[26,-17],[20.5,-11.6],[15,-17],[10.4,-28],[10,-42]])rpw3mRv(g,x,y,1.15,V.rv);
 const ex=20.6,ey=-35.4;
 if(v==='meadow'){rpw3mGear(g,ex,ey,8.6,10,a/10,V.b,v,{holes:5,th:2.2,lw:1.8});rpw3mDaisy(g,ex,ey,2.4,'#ff8ab8','#ffe46a');
  rpw3mVine(g,[9.6,-20,13,-26,11,-33,14.6,-41,12.4,-50,17,-55],4,1.1);rpw3mVine(g,[31,-24,28.4,-30,30.4,-38],8,1);rpw3mDaisy(g,12.6,-50,2,'#ffffff','#ffd84a');rpw3mDaisy(g,29.6,-37,1.7,'#ffd84a','#ff9a3a')}
 else if(v==='foundry'){const GP=rpw3mPr(ex-7,ey-8,14,16,3);g.fillStyle='#1a0e0e';g.fill(GP);rpmGlow(g,ex,ey,16,V.gl,.55+.2*Math.sin(a*2));
  for(let i=0;i<4;i++){const y=ey-6+i*3.8;const SL=rpw3mPr(ex-5.4,y,10.8,2,1);g.fillStyle=rpmLG(g,ex-5,0,ex+5,0,[0,V.gl,.5,V.g2,1,V.gl]);g.fill(SL)}
  g.lineWidth=1.8;g.strokeStyle=RPMO;g.stroke(GP);g.beginPath();for(let i=0;i<5;i++){g.moveTo(ex-7,ey-8+i*3.8);g.lineTo(ex+7,ey-8+i*3.8)}g.lineWidth=1;g.strokeStyle=rpmA(RPMO,.85);g.stroke()}
 else{const pu=.7+.3*Math.sin(a*2);rpmGlow(g,ex,ey,18,V.gl,.55*pu);const BP=rpw3mBoltP(ex,ey,2.7);g.fillStyle=rpmLG(g,ex-6,ey-12,ex+6,ey+12,[0,'#ffffff',.45,V.ey,1,V.gl]);g.fill(BP);g.lineWidth=1.6;g.strokeStyle=RPMO;g.stroke(BP);
  const f=Math.floor(ph*8);if(f%2)rpw3mArc(g,ex+3,ey-9,ex+9,ey-16,f*5+1,1.6,V.gl,.8);else rpw3mArc(g,ex-4,ey+10,ex-9,ey+15,f*3+7,1.4,V.gl,.7)}
 g.beginPath();g.moveTo(10,-53);g.quadraticCurveTo(12,-57.4,20.5,-58);rpmHi(g,.7,1.4);
 g.restore();
 /* gauntlet fingers over the shield edge */
 for(let i=0;i<3;i++)rpmEl(g,9.6,-33+i*2.6+sb,2.1,1.2,rpw3mMF(g,7,-35+sb,12,-26+sb,V.b,v),1.1)};


/* ========== 3. Steam Golem: a riveted boiler on stumpy piston legs, a furnace grin, pipe arms and a chimney ========== */
RPMD.steam=function(g,ph,o){const v=rpw3mV(o&&o.v),V=RPW3M_V[v],a=ph*RPMT,s=Math.sin(a),by=-Math.abs(s)*2.2,pu=.75+.25*Math.sin(a*2),f8=Math.floor(ph*8);
 const B=[-31,-90+by,23,-20+by];
 /* stumpy legs: thigh drum, knee ball, piston shin, big round boot */
 const leg=(bx,p,col,dk)=>{const fx=bx+7*Math.sin(p),l=Math.max(0,Math.cos(p))*5,hy=-26+by,k=rpmKnee(bx,hy,fx,-8-l,20,-1);
  rpmLimb(g,[bx,hy,k[0],k[1]],10,col,2.2);rpmLimb(g,[k[0],k[1],fx,-8-l],6.4,rpmSh(col,-.1),2.2);
  g.beginPath();g.moveTo(k[0]+1.4,k[1]+2);g.lineTo(fx+1.4,-8-l);g.lineWidth=2.2;g.strokeStyle=v==='storm'?'#ffffff':rpmSh(V.ml,.2);g.stroke();
  rpw3mRv(g,k[0],k[1],4,dk?rpmSh(V.b,-.35):V.b);
  g.save();g.translate(fx,-l);const P=new Path2D();P.moveTo(-9,0);P.lineTo(-8.6,-7);P.quadraticCurveTo(0,-11,8,-7);P.quadraticCurveTo(13,-5,12.6,0);P.closePath();rpw3mPart(g,P,[-9,-10,13,0],dk?rpmSh(V.t,-.3):V.t,v,2.2,4);
  g.beginPath();g.moveTo(-8.6,-2.4);g.lineTo(12.6,-2.4);g.lineWidth=1.1;g.strokeStyle=rpmA(RPMO,.6);g.stroke();for(const x of[-5,0,5])rpw3mRv(g,x,-5.4,.9,V.rv);g.restore()};
 /* far arm (behind the boiler) */
 const sw=6*s,arm=(sx,sy,ex,ey,hx,hy,col,dk)=>{
  /* corrugated hose upper arm */
  rpmLimb(g,[sx,sy,ex,ey],7.4,col,2.2);const n=5;for(let i=1;i<n;i++){const u=i/n,x=sx+(ex-sx)*u,y=sy+(ey-sy)*u,d=Math.atan2(ey-sy,ex-sx)+Math.PI/2;g.beginPath();g.moveTo(x+Math.cos(d)*3.7,y+Math.sin(d)*3.7);g.lineTo(x-Math.cos(d)*3.7,y-Math.sin(d)*3.7);g.lineWidth=1.1;g.strokeStyle=rpmA(RPMO,.55);g.stroke()}
  /* heavy forearm drum */
  const L=Math.hypot(hx-ex,hy-ey),an=Math.atan2(hy-ey,hx-ex);g.save();g.translate(ex,ey);g.rotate(an);
  const FP=rpw3mPr(-3,-7.4,L+3,14.8,5);if(v==='foundry'&&!dk){rpw3mPart(g,FP,[-3,-7,L,7],col,v,2.2,6);const HZ=rpw3mPr(L*.35,-7.4,L*.32,14.8,1);rpw3mHaz(g,HZ,L*.35,-8,L*.67,8,2.2,1.6)}
  else rpw3mPart(g,FP,[-3,-7,L,7],col,v,2.2,6);
  for(const u of[.2,.82]){const BP=rpw3mPr(L*u-1.6,-8.4,3.2,16.8,1.2);rpw3mPart(g,BP,[L*u-2,-8,L*u+2,8],dk?rpmSh(V.b,-.35):V.b,v,1.4,u*9)}
  g.restore();rpw3mRv(g,ex,ey,3.6,dk?rpmSh(V.b,-.35):V.b);
  /* clamp hand: two hooked jaws that snap a little each step */
  g.save();g.translate(hx,hy);g.rotate(an);const op=.18+.14*Math.sin(a*2),jc=dk?rpmSh(V.m,-.3):rpmSh(V.m,.08);
  for(const sg of[-1,1]){g.save();g.rotate(sg*op);const J=new Path2D();J.moveTo(-1,sg*-1);J.quadraticCurveTo(5,sg*7.4,13,sg*5.6);J.quadraticCurveTo(15.6,sg*4.6,14.6,sg*1.6);J.lineTo(11.6,sg*2.4);J.quadraticCurveTo(6,sg*2.6,2,sg*-1.6);J.closePath();
   rpw3mPart(g,J,[-1,-8,15,8],jc,v,1.9,sg+3);g.restore()}
  rpmEl(g,0,0,6.2,6.6,rpw3mMF(g,-6,-6,6,6,dk?rpmSh(V.b,-.35):V.b,v),2);rpw3mRv(g,0,0,2,dk?rpmSh(V.m,-.3):V.m);g.restore()};
 arm(-22,-70+by,-30,-50+by,-26-sw,-30+by,V.md,1);
 leg(-14,a+Math.PI,V.md,1);
 /* back loop pipe */
 g.beginPath();g.moveTo(-27,-70+by);g.bezierCurveTo(-42,-66+by,-42,-40+by,-28,-36+by);g.lineCap='round';g.lineWidth=7.4;g.strokeStyle=RPMO;g.stroke();g.lineWidth=4.2;g.strokeStyle=V.t;g.stroke();
 g.beginPath();g.moveTo(-29,-69+by);g.bezierCurveTo(-41,-64+by,-40.5,-44+by,-30,-39+by);g.lineWidth=1.2;g.strokeStyle=rpmA('#ffffff',.5);g.stroke();
 for(const [x,y] of[[-36.4,-62],[-36.6,-44]])rpmEl(g,x,y+by,3.4,1.8,V.b,1.3,.5);
 /* chimney (meadow: a cold mossy stack with a nest; storm: a Tesla coil) */
 const chx=-9;
 if(v==='storm'){rpmLimb(g,[chx,-86+by,chx,-104+by],3.4,V.t,1.8);for(let i=0;i<4;i++){const y=-89+by-i*4.4,r=6.4-i*.9;rpmEl(g,chx,y,r,r*.34,rpw3mMF(g,chx-r,y-2,chx+r,y+2,i%2?V.b:V.ml,v),1.6)}
  rpmGlow(g,chx,-108+by,14,V.gl,.8*pu);rpmEl(g,chx,-108+by,4.2,4.2,rpmRG(g,chx,-108+by,4.2,[0,'#ffffff',.5,V.ey,1,V.gl],chx-1.4,-109.4+by),1.6);
  rpw3mArc(g,chx,-108+by,chx-14+f8%3*3,-96+by,f8*17+3,3,V.gl,1.1);rpw3mArc(g,chx,-108+by,chx+12,-100+by-f8%2*4,f8*9+5,2.6,V.g2,.9)}
 else{const CP=rpw3mPo([chx-5.6,-80+by,chx-5,-102+by,chx+5,-102+by,chx+5.6,-80+by]);rpw3mPart(g,CP,[chx-6,-102+by,chx+6,-80+by],v==='meadow'?V.t:V.m,v,2.2,12);
  const CC=rpw3mPr(chx-8,-107+by,16,5.4,2);rpw3mPart(g,CC,[chx-8,-107+by,chx+8,-101+by],v==='foundry'?V.md:V.b,v,2,13);
  for(const y of[-94,-86])rpmEl(g,chx,y+by,5.6,1.4,v==='foundry'?V.b:V.md,1.2);
  if(v==='foundry'){rpmGlow(g,chx,-108+by,9,V.gl,.6*pu);rpw3mPuff(g,chx-1,-110+by,ph,1.5,1,4,-14,-9);rpvSparks(g,chx-6,chx+4,-108+by,22,ph,4,7,[V.g2,V.gl])}
  else{rpvMoss(g,[chx-8.4,-103+by,chx-6,-107.4+by,chx+3,-108+by,chx+8.4,-104+by,chx+6,-101.4+by,chx-4,-101.6+by],[[chx-4,-106+by,1.6]]);rpw3mVine(g,[chx-5,-101+by,chx-6,-94+by,chx-4.6,-88+by,chx-6,-82+by],3,.9);
   rpw3mNest(g,chx+.6,-107.4+by,15);rpw3mBird(g,chx+2,-108.4+by,.9,ph,'#4aa8f0')}}
 /* the boiler */
 const BP=new Path2D();BP.roundRect(-31,-88+by,54,68,[22,22,9,9]);rpw3mPart(g,BP,B,V.m,v,2.8,51);
 /* dome cap ring, bands and rivets */
 const band=(y,h)=>{const P=new Path2D();P.rect(-31,y+by,54,h);g.save();g.clip(BP);rpw3mPart(g,P,[-31,y+by,23,y+h+by],v==='storm'?V.t:V.b,v,1.6,y);g.restore()};
 band(-79,4.4);band(-42,4);band(-29,4.4);g.lineWidth=2.8;g.strokeStyle=RPMO;g.stroke(BP);
 for(const y of[-76.8,-40,-26.8])for(let x=-27;x<=19;x+=6.6)rpw3mRv(g,x,y+by,.95,V.rv);
 rpmAH(g,-6,-62+by,22,24,3.3,4.2,.5,2);
 /* side gauge with a wobbling needle */
 const gx=-21,gy=-70+by;rpmEl(g,gx,gy,6.2,6.2,rpw3mMF(g,gx-6,gy-6,gx+6,gy+6,V.b,v),1.8);rpmEl(g,gx,gy,4.6,4.6,rpmRG(g,gx,gy,4.6,[0,'#fffef4',1,V.dl],gx-1,gy-1.4),1.2);
 g.beginPath();for(let i=0;i<7;i++){const t=Math.PI*(.8+i/6*1.4);g.moveTo(gx+Math.cos(t)*3.2,gy+Math.sin(t)*3.2);g.lineTo(gx+Math.cos(t)*4.2,gy+Math.sin(t)*4.2)}g.lineWidth=.7;g.strokeStyle=RPMO;g.stroke();
 g.beginPath();g.arc(gx,gy,3.7,Math.PI*1.9,Math.PI*2.2);g.lineWidth=1.1;g.strokeStyle='#e8302a';g.stroke();
 const na=-1.2+Math.sin(a*2)*.35+(v==='foundry'?.6:0);g.beginPath();g.moveTo(gx,gy);g.lineTo(gx+Math.cos(na)*3.8,gy+Math.sin(na)*3.8);g.lineWidth=1.1;g.strokeStyle='#c81a1a';g.stroke();rpmEl(g,gx,gy,.9,.9,RPMO,0);
 /* safety valve puffing steam */
 const vx=5,vy=-88+by;rpmLimb(g,[vx,vy+4,vx,vy-4],3.2,V.b,1.6);rpmEl(g,vx,vy-5,3.4,1.6,rpw3mMF(g,vx-3,vy-6,vx+3,vy-4,V.b,v),1.3);
 if(v!=='foundry')rpw3mPuff(g,vx+1,vy-7,(ph*2)%1,1,0,3,6,-12);
 /* the face: two lens eyes under a heavy brow, a furnace grin */
 rpw3mEye(g,3,-67.6+by,5.4,V,.36);rpw3mEye(g,14,-68.6+by,4,V,-.2);
 const BW=rpw3mPo([-4.6,-75.4+by,19.6,-77.2+by,20.4,-72.4+by,9,-72.4+by,-3.6,-70.6+by]);rpw3mPart(g,BW,[-5,-78+by,21,-70+by],V.md,v,1.8,77);
 const mx0=-2,mx1=18,my=-53+by,MP=new Path2D();MP.moveTo(mx0,my-3);MP.quadraticCurveTo((mx0+mx1)/2,my-8,mx1+1,my-5);MP.lineTo(mx1+1,my+6);MP.quadraticCurveTo((mx0+mx1)/2,my+10,mx0,my+5);MP.closePath();
 rpw3mPart(g,rpw3mPr(mx0-3,my-10,mx1-mx0+5,20,5),[mx0-3,my-10,mx1+2,my+10],v==='storm'?V.t:V.b,v,2,61);
 g.fillStyle=v==='storm'?rpmLG(g,0,my-6,0,my+8,[0,'#ffffff',.4,V.ey,1,V.gl]):rpmLG(g,0,my-6,0,my+8,[0,V.g2,.5,V.gl,1,rpmSh(V.gl,-.4)]);g.fill(MP);
 g.save();g.clip(MP);if(v==='storm'){rpw3mArc(g,mx0,my+1,mx1,my-1,f8*19+2,3,'#ffffff',.9)}else{for(let i=0;i<3;i++){const fx=mx0+4+i*6,fh=5+2*Math.sin(a*2+i*2);g.fillStyle=rpmA('#fff6c0',.85);g.beginPath();g.moveTo(fx-2.4,my+8);g.quadraticCurveTo(fx-1,my+8-fh,fx,my+7-fh*1.4);g.quadraticCurveTo(fx+1,my+8-fh,fx+2.4,my+8);g.fill()}}g.restore();
 g.lineWidth=1.8;g.strokeStyle=RPMO;g.stroke(MP);
 for(let i=0;i<4;i++){const x=mx0+3.4+i*4.8;rpmP(g,[x-1.7,my-5.4+i*.2,x+1.7,my-5.6+i*.1,x,my-1.6]);rpmFS(g,'#fffbe8',1);rpmP(g,[x+.6,my+7.4,x+3.2,my+7.2,x+1.9,my+3.6]);rpmFS(g,'#fffbe8',1)}
 rpmGlow(g,(mx0+mx1)/2,my+1,20,V.gl,.45*pu);
 /* variant dressing on the boiler */
 if(v==='meadow'){rpw3mVine(g,[-31,-46+by,-24,-49+by,-16,-46+by,-8,-50+by,0,-47+by,6,-49+by],11,1.1);rpw3mVine(g,[-30,-56+by,-25,-60+by,-27,-66+by],15,1);
  rpvMoss(g,[-27,-82+by,-20,-89+by,-6,-91.6+by,6,-90+by,16,-84+by,6,-85+by,-6,-86+by,-18,-84+by],[[-14,-87+by,2],[2,-88+by,1.8]]);
  rpw3mDaisy(g,-23,-48+by,2.4,'#ff9ad0','#ffe46a');rpw3mDaisy(g,-6,-89+by,2.2,'#ffffff','#ffd84a');rpw3mDaisy(g,-1,-48+by,1.9,'#ffd84a','#ff9a3a')}
 else if(v==='foundry'){g.save();g.clip(BP);g.fillStyle=rpmLG(g,0,-88+by,0,-60+by,[0,'rgba(10,6,12,.35)',1,'rgba(10,6,12,0)']);g.fillRect(-31,-90+by,54,30);g.restore();
  rpvCrack(g,[-26,-70+by,-22,-64+by,-25,-58+by],2.6);rpvDrip(g,-12,-20+by,ph,5,.3)}
 else{rpw3mArc(g,-31,-74+by,-24,-58+by,f8*23+9,3,V.gl,.9);if(f8%2)rpw3mArc(g,23,-40+by,18,-28+by,f8*7+1,2.4,V.gl,.8)}
 /* near arm in front: hangs from the side, swings forward */
 leg(5,a,V.m,0);
 arm(-14,-58+by,-15,-40+by,-1+sw,-23+by,V.m,0);
 if(v==='meadow'){rpvMoss(g,[-20,-58+by,-17,-63.4+by,-10,-64+by,-7,-58+by,-12,-59.6+by],[[-14,-62+by,1.5]]);rpw3mDaisy(g,-12,-63.6+by,2,'#ff8ab8','#ffe46a')}
};


/* ========== 4. Gyrocopter: a round flying pod with a spinning rotor, a tail rotor and a grinning grille ========== */
RPMD.gyro=function(g,ph,o){const v=rpw3mV(o&&o.v),V=RPW3M_V[v],a=ph*RPMT,by=Math.sin(a)*2.4,f8=Math.floor(ph*8),cx=0,cy=-21+by;
 g.save();g.translate(cx,cy);g.rotate(.07+Math.cos(a)*.03);g.translate(-cx,-cy);
 /* main rotor: three blades, one full turn per cycle (45 degrees a frame) */
 const ry=cy-19,RR=27,rot=a,bl=t=>{const x=Math.cos(t)*RR,y=Math.sin(t)*3.8;return[x,y]};
 const blade=(t,front)=>{const p=bl(t),w=v==='meadow'?3.6:3.2,nx=-Math.sin(t)*w*.25,ny=Math.cos(t)*w;g.save();g.translate(0,ry);
  const P=new Path2D();if(v==='meadow'){P.moveTo(0,0);P.quadraticCurveTo(p[0]*.5-ny*.2,p[1]*.5-w*1.4,p[0],p[1]);P.quadraticCurveTo(p[0]*.5+ny*.2,p[1]*.5+w*1.4,0,0)}
  else{P.moveTo(-nx,-w*.5);P.lineTo(p[0]-nx,p[1]-w*.5);P.lineTo(p[0]+nx,p[1]+w*.5);P.lineTo(nx,w*.5)}P.closePath();
  g.fillStyle=v==='meadow'?(front?'#7ccc4a':'#4a9a34'):front?rpw3mMF(g,-RR,-2,RR,2,v==='storm'?V.ml:V.b,v):rpmSh(v==='storm'?V.md:V.b,-.3);g.fill(P);g.lineWidth=1.5;g.strokeStyle=RPMO;g.stroke(P);
  if(v==='meadow'){g.beginPath();g.moveTo(0,0);g.lineTo(p[0]*.92,p[1]*.92);g.lineWidth=.7;g.strokeStyle=rpmA('#1e5a1a',.7);g.stroke()}
  if(v==='storm'&&front){g.restore();rpw3mArc(g,p[0],ry+p[1],p[0]+Math.sign(p[0]||1)*7,ry+p[1]-4+(f8%3)*2,f8*13+t,2,V.gl,.8);return}
  g.restore()};
 /* the blur disc */
 g.save();g.globalAlpha=.42;rpmEl(g,0,ry,RR+1,4.8,v==='meadow'?'rgba(200,255,170,.7)':v==='foundry'?'rgba(200,190,210,.6)':'rgba(200,240,255,.8)',0);g.restore();
 g.beginPath();g.ellipse(0,ry,RR,4.2,0,Math.PI*.15,Math.PI*.55);g.ellipse(0,ry,RR,4.2,0,Math.PI*1.15,Math.PI*1.55);g.lineWidth=1;g.strokeStyle='rgba(255,255,255,.55)';g.stroke();
 for(let k=0;k<3;k++){const t=rot+k*RPMT/3;if(Math.sin(t)<0)blade(t,0)}
 /* tail boom, fin and tail rotor */
 const TB=rpw3mPo([-9,cy-5,-34,cy-7.6,-34,cy-3.6,-9,cy+3]);
 if(v==='foundry')rpw3mHaz(g,TB,-35,cy-8,-9,cy+3,2.2,1.8);else rpw3mPart(g,TB,[-34,cy-8,-9,cy+3],v==='storm'?V.t:V.md,v,1.8,7);
 g.beginPath();for(let x=-30;x<-11;x+=5){g.moveTo(x,cy-6.6+(x+34)*.07);g.lineTo(x+2.6,cy+1.6-(x+11)*-.04)}g.lineWidth=.9;g.strokeStyle=rpmA(RPMO,.5);g.stroke();
 const FN=rpw3mPo([-27,cy-6.6,-36,cy-17,-39,cy-16,-36,cy-5.4]);rpw3mPart(g,FN,[-39,cy-17,-27,cy-5],V.m,v,1.6,8);
 const tx=-36,ty=cy-5.6,tr=a*2;g.save();g.globalAlpha=.3;rpmEl(g,tx,ty,7,7,'rgba(255,255,255,.7)',0);g.restore();
 for(let k=0;k<2;k++){const t=tr+k*Math.PI;rpmLimb(g,[tx,ty,tx+Math.cos(t)*7,ty+Math.sin(t)*7],2,v==='storm'?V.ml:V.b,1.3)}rpw3mRv(g,tx,ty,1.5,V.rv);
 /* skids */
 for(const [x0,x1] of[[-6,-9],[5,8]])rpmLimb(g,[x0,cy+8,x1,cy+15],1.8,V.md,1.4);
 const SK=rpw3mPr(-15,cy+14,28,3,1.5);rpw3mPart(g,SK,[-15,cy+14,13,cy+17],v==='storm'?V.t:V.b,v,1.6,9);
 g.beginPath();g.moveTo(13,cy+15.5);g.quadraticCurveTo(17,cy+15.5,17.4,cy+12);g.lineWidth=4.4;g.strokeStyle=RPMO;g.stroke();g.lineWidth=2;g.strokeStyle=v==='storm'?V.t:V.b;g.stroke();
 if(v==='meadow'){rpw3mVine(g,[-14,cy+15,-8,cy+17,-2,cy+15.5,4,cy+17],6,.9);rpw3mDaisy(g,-3,cy+16.6,2,'#ff9ad0','#ffe46a')}
 /* exhaust pipe at the back */
 rpmLimb(g,[-9,cy+3,-15,cy+7],3.4,V.td,1.6);rpmEl(g,-15.6,cy+7.3,2.4,2.4,'#1a1024',1.3);
 if(v==='foundry'){rpmGlow(g,-15.6,cy+7.3,6,V.gl,.7);rpw3mPuff(g,-17,cy+8,ph,1.1,1,4,-18,3)}else if(v==='meadow'){rpw3mPuff(g,-17,cy+8,ph,.8,0,2,-12,2)}
 /* the pod */
 const PB=[-14,cy-14,15,cy+12],PP=rpw3mPe(cx,cy,14.6,12.6);rpw3mPart(g,PP,PB,V.m,v,2.4,15);
 /* rib band and rivets */
 g.save();g.clip(PP);const RB=new Path2D();RB.rect(-16,cy+3,32,3.4);rpw3mPart(g,RB,[-16,cy+3,16,cy+6.4],v==='storm'?V.t:V.b,v,1.4,4);g.restore();g.lineWidth=2.4;g.strokeStyle=RPMO;g.stroke(PP);
 for(const x of[-10,-5,0,5,10])rpw3mRv(g,x,cy+4.7,.8,V.rv);
 if(v==='foundry'){for(let i=0;i<3;i++){const x=-9+i*3.6;const L=rpw3mPr(x,cy-6,2,7,1);g.fillStyle=rpmLG(g,0,cy-6,0,cy+1,[0,V.g2,1,V.gl]);g.fill(L);g.lineWidth=1;g.strokeStyle=RPMO;g.stroke(L)}rpmGlow(g,-6,cy-2.4,10,V.gl,.5)}
 /* face: goggles and a grille grin */
 rpw3mEye(g,cx+5.4,cy-3.6,3.8,V,.3);rpw3mEye(g,cx+11.4,cy-4,2.8,V,-.22);
 g.beginPath();g.moveTo(cx+1,cy-6);g.lineTo(cx+8.6,cy-4.4);g.moveTo(cx+9.8,cy-4.6);g.lineTo(cx+14,cy-5.4);g.lineWidth=1.2;g.strokeStyle=rpmA(RPMO,.8);g.stroke();
 rpw3mGrin(g,cx+3,cy+2,cx+13.6,cy+.6,1.7,5,V,v==='foundry');
 rpmAH(g,cx-2,cy-1,11,9,3.5,4.4,.6,1.5);
 /* mast and hub */
 rpmLimb(g,[0,cy-12,0,ry],3,V.md,1.6);rpmEl(g,0,cy-12.4,5,2,rpw3mMF(g,-5,cy-14,5,cy-11,v==='storm'?V.t:V.b,v),1.4);
 if(v==='meadow'){rpvMoss(g,[-11,cy-7,-7,cy-12,0,cy-13.6,7,cy-12.4,10,cy-8.6,4,cy-10,-4,cy-10,-8,cy-7],[[-5,cy-11,1.6],[5,cy-11,1.4]])}
 for(let k=0;k<3;k++){const t=rot+k*RPMT/3;if(Math.sin(t)>=0)blade(t,1)}
 if(v==='meadow'){/* a dandelion clock on the hub, seeds drifting off */
  rpmEl(g,0,ry,2.6,1.8,'#5aa83a',1.2);g.save();for(let i=0;i<14;i++){const t=i/14*RPMT,x=Math.cos(t)*5.4,y=ry-4+Math.sin(t)*4.6;g.beginPath();g.moveTo(0,ry-3.4);g.lineTo(x,y);g.lineWidth=.6;g.strokeStyle='rgba(255,255,255,.9)';g.stroke();rpmEl(g,x,y,1,1,'#ffffff',0)}
  g.beginPath();g.arc(0,ry-4,5.8,0,RPMT);g.lineWidth=.9;g.strokeStyle='rgba(120,160,120,.6)';g.stroke();g.restore();
  for(let i=0;i<3;i++){const u=(ph+i/3)%1,x=-4-u*20,y=ry-6-u*8+Math.sin(u*9+i)*2;g.globalAlpha=Math.sin(u*Math.PI);g.beginPath();g.moveTo(x,y);g.lineTo(x+1.4,y+3);g.lineWidth=.6;g.strokeStyle='#e8f0e0';g.stroke();g.beginPath();g.arc(x,y,1.3,0,RPMT);g.fillStyle='#ffffff';g.fill();g.globalAlpha=1}}
 else{rpmEl(g,0,ry,3.6,2.4,rpw3mMF(g,-4,ry-3,4,ry+3,v==='storm'?V.ml:V.b,v),1.4);
  if(v==='storm'){rpmLimb(g,[0,ry-2,0,ry-8],1.2,V.ml,1.2);rpmGlow(g,0,ry-9,6,V.gl,.8);rpmEl(g,0,ry-9,1.8,1.8,'#ffffff',1)}}
 g.restore()};


/* ========== 5. Chronotinker: a little clockmaker with a clock-face belly, a top hat and a giant clock-key staff ========== */
RPMD.tinker=function(g,ph,o){const v=rpw3mV(o&&o.v),V=RPW3M_V[v],a=ph*RPMT,s=Math.sin(a),by=-Math.abs(Math.cos(a))*1.6,f8=Math.floor(ph*8);
 const st=s*1.4,SX0=22-st,SX1=24+st,STOP=-70+by*.5;
 /* staff bit (behind the legs), legs with curled shoes */
 const leg=(p,col,dk)=>{const fx=8*Math.sin(p)-1,fy=-Math.max(0,Math.cos(p))*3.6,k=rpmKnee(-1,-13+by,fx,fy-2,14,-1);rpmLimb(g,[-1,-13+by,k[0],k[1],fx,fy-2],2.6,col,1.8);rpmEl(g,k[0],k[1],1.6,1.6,V.b,1);
  g.save();g.translate(fx,fy);const P=new Path2D();P.moveTo(-3,0);P.lineTo(-2.6,-3.6);P.quadraticCurveTo(3,-4.6,6,-2.4);P.quadraticCurveTo(8.6,-3.6,8.4,-6);P.quadraticCurveTo(10.6,-3,7.4,0);P.closePath();rpw3mPart(g,P,[-3,-6,10,0],dk?rpmSh(V.t,-.3):V.t,v,1.5,3);g.restore()};
 /* back arm and coat tails */
 rpmLimb(g,[-6,-32+by,-11,-27+by,-12-s*2,-21+by],2.6,V.md,1.7);rpmEl(g,-12-s*2,-21+by,2.2,2.2,rpw3mMF(g,-14,-23,-10,-19,rpmSh(V.b,-.2),v),1.2);
 for(const [k,dx] of[[0,0],[1,3]]){const t=-.25-s*.12-k*.1,P=new Path2D();P.moveTo(-6+dx,-30+by);P.quadraticCurveTo(-14+dx,-24+by,-15+dx+t*8,-11+by);P.lineTo(-10+dx+t*6,-13+by);P.quadraticCurveTo(-8+dx,-22+by,-2+dx,-26+by);P.closePath();
  rpw3mPart(g,P,[-15,-30+by,-2,-11+by],k?(v==='storm'?V.t:V.td):rpmSh(v==='storm'?V.t:V.td,-.2),v,1.6,k+40)}
 leg(a+Math.PI,V.md,1);leg(a,V.m,0);
 /* the clock body: a round casing with an enamel dial; the minute hand goes round once a cycle */
 const bx=0,bY=-25+by,CP=rpw3mPe(bx,bY,12.4,12.6);rpw3mPart(g,CP,[-12,bY-12,12,bY+12],V.m,v,2.4,17);
 if(v==='foundry'){/* leather apron with a hazard hem */const AP=new Path2D();AP.moveTo(-8,bY-10);AP.lineTo(9,bY-10);AP.quadraticCurveTo(13,bY+2,11,bY+13);AP.lineTo(-10,bY+13);AP.quadraticCurveTo(-12,bY+2,-8,bY-10);AP.closePath();
  rpw3mPart(g,AP,[-12,bY-10,13,bY+13],'#6a4a36',0,1.8);const HZ=rpw3mPr(-11,bY+9,23,4,1);rpw3mHaz(g,HZ,-11,bY+9,12,bY+13,1.8,1.4)}
 const dx0=bx+1.4,dy0=bY-1,DR=8.4;rpmEl(g,dx0,dy0,DR+1.8,DR+1.8,rpw3mMF(g,dx0-DR,dy0-DR,dx0+DR,dy0+DR,v==='storm'?V.t:V.b,v),1.8);
 rpmEl(g,dx0,dy0,DR,DR,v==='storm'?rpmRG(g,dx0,dy0,DR,[0,'#ffffff',.6,'#d8fbff',1,'#8ae8ff'],dx0-2,dy0-3):rpmRG(g,dx0,dy0,DR,[0,'#fffef6',.7,V.dl,1,rpmSh(V.dl,-.2)],dx0-2,dy0-3),1.2);
 if(v==='storm')rpmGlow(g,dx0,dy0,14,V.gl,.4);
 g.beginPath();for(let k=0;k<12;k++){const t=k/12*RPMT,r0=k%3?DR-1.8:DR-3;g.moveTo(dx0+Math.cos(t)*r0,dy0+Math.sin(t)*r0);g.lineTo(dx0+Math.cos(t)*(DR-.8),dy0+Math.sin(t)*(DR-.8))}g.lineWidth=.9;g.strokeStyle=RPMO;g.stroke();
 const hand=(t,l,w,c)=>{g.beginPath();g.moveTo(dx0-Math.cos(t)*1.4,dy0-Math.sin(t)*1.4);g.lineTo(dx0+Math.cos(t)*l,dy0+Math.sin(t)*l);g.lineWidth=w+1.4;g.strokeStyle=RPMO;g.stroke();g.lineWidth=w;g.strokeStyle=c;g.stroke()};
 hand(a/12+.9,4.4,1.4,V.b);hand(a-Math.PI/2,6.6,1,v==='storm'?V.t:'#c8281e');rpmEl(g,dx0,dy0,1.2,1.2,V.b,.8);
 rpmAH(g,dx0,dy0,DR-.6,DR-.6,3.5,4.6,.75,1.2);
 /* collar */
 rpmEl(g,2,bY-12.6,7,2.4,rpw3mMF(g,-5,bY-15,9,bY-10,V.md,v),1.6);
 /* head: round, long brass nose, a loupe over one eye, spring whiskers */
 const hx=3,hy=-45.6+by+Math.sin(a*2)*.4,HP=rpw3mPe(hx,hy,9.2,8.6);rpw3mPart(g,HP,[hx-9,hy-9,hx+9,hy+9],V.m,v,2.2,19);
 rpmAH(g,hx,hy,7.2,6.8,3.6,4.6,.6,1.2);
 rpw3mEye(g,hx-.4,hy-2.2,2.3,V,.25);
 const mx=hx+6,my=hy+5.6;
 for(const sg of[-1,1]){g.beginPath();for(let k=0;k<=12;k++){const u=k/12,t=u*RPMT*1.6,r=1.5*(1-u*.35);const x=mx+sg*u*4.6+Math.cos(t)*r*sg,y=my+Math.sin(t)*r+u*1.4;k?g.lineTo(x,y):g.moveTo(x,y)}g.lineWidth=2.6;g.strokeStyle=RPMO;g.stroke();g.lineWidth=1.1;g.strokeStyle=rpmSh(V.b,.15);g.stroke()}
 g.beginPath();g.moveTo(hx+2.4,hy+7.2);g.quadraticCurveTo(hx+5.4,hy+8.6,hx+8.6,hy+7.4);g.lineWidth=1.3;g.strokeStyle=RPMO;g.stroke();
 const nose=new Path2D();nose.moveTo(hx+6.4,hy+.4);nose.quadraticCurveTo(hx+12,hy+1.4,hx+16.6,hy+3.6);nose.quadraticCurveTo(hx+11,hy+4.6,hx+6.6,hy+4.6);nose.closePath();rpw3mPart(g,nose,[hx+6,hy,hx+17,hy+5],V.b,v,1.5,6);
 g.beginPath();g.moveTo(hx+8,hy+1.4);g.lineTo(hx+14,hy+2.8);rpmHi(g,.6,.7);
 /* the loupe on its arm */
 const lx=hx+5.2,ly=hy-2.8;rpmLimb(g,[hx-3,hy-6.4,lx-2.6,ly-4.4],1.2,V.b,1.1);
 rpmGlow(g,lx,ly,10,V.gl,.55);rpmEl(g,lx,ly,4.4,4.4,rpw3mMF(g,lx-4,ly-4,lx+4,ly+4,V.b,v),1.7);
 rpmEl(g,lx,ly,3.2,3.2,rpmRG(g,lx,ly,3.3,[0,'#fffef0',.4,V.ey,1,V.gl],lx-.8,ly-1),1);rpmEl(g,lx+.7,ly+.2,1,1.5,'#1a0c18',0);rpmEl(g,lx-1.1,ly-1.3,.9,.7,'#ffffff',0);
 g.beginPath();g.moveTo(lx-4.4,ly-4.6);g.lineTo(lx+4.8,ly-2.6);g.lineWidth=1.6;g.strokeStyle=RPMO;g.stroke();
 /* the hat */
 g.save();g.translate(hx-.6,hy-7.2);g.rotate(-.12+Math.sin(a*2)*.03);
 if(v==='storm'){/* a little storm cloud over the hat */const cyy=-21+Math.sin(a)*1;rpmGlow(g,1,cyy,14,V.g2,.35);
  const CL=rpw3mPb([-9,cyy+2,-9,cyy-3,-5,cyy-6,0,cyy-7,5,cyy-6,10,cyy-4,11,cyy+1,6,cyy+3,0,cyy+3.4]);rpw3mDo(g,CL,rpmLG(g,0,cyy-7,0,cyy+3,[0,'#c8cce8',1,'#6a6e9a']),1.6);
  for(let k=0;k<3;k++){const u=(ph+k/3)%1;g.globalAlpha=1-u;g.beginPath();g.moveTo(-5+k*5,cyy+4+u*7);g.lineTo(-5.6+k*5,cyy+6+u*7);g.lineWidth=1;g.strokeStyle='#9ad8ff';g.stroke();g.globalAlpha=1}}
 const CR=new Path2D();CR.moveTo(-5.6,0);CR.lineTo(-5,-11);CR.quadraticCurveTo(1,-12.6,7,-11);CR.lineTo(7.6,0);CR.closePath();rpw3mPart(g,CR,[-6,-12,8,0],v==='meadow'?V.m:V.md,v,1.8,23);
 const HB=rpw3mPr(-5.8,-4.4,13.6,3,1);rpw3mPart(g,HB,[-6,-4.4,8,-1.4],v==='foundry'?V.b:V.t,v,1.3,24);
 rpmEl(g,1,.2,11,2.4,rpw3mMF(g,-10,-2,12,2,v==='meadow'?V.m:V.md,v),1.8);
 if(v==='meadow'){rpw3mDaisy(g,5.6,-4,2.6,'#ff8ab8','#ffe46a');rpw3mDaisy(g,1.6,-3.8,1.8,'#ffffff','#ffd84a');g.save();g.translate(-3,-4);g.rotate(-.9);g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(-1,-4,-4.4,-5.4);g.quadraticCurveTo(-2.4,-1.6,0,0);rpmFS(g,'#7ccc4a',1);g.restore()}
 else if(v==='foundry'){g.beginPath();g.moveTo(-5.4,-6.6);g.lineTo(7.4,-6.6);g.lineWidth=2.6;g.strokeStyle=RPMO;g.stroke();g.lineWidth=1.2;g.strokeStyle='#6a4a36';g.stroke();
  for(const x of[-.6,4.8]){rpmEl(g,x,-6.8,3,3,rpw3mMF(g,x-3,-10,x+3,-4,V.b,v),1.5);rpmEl(g,x,-6.8,2,2,'#1a0e10',0);rpmEl(g,x-.6,-7.6,1,.8,rpmA(V.g2,.9),0)}}
 else rpw3mGear(g,1.4,-7.4,3,8,a/8,V.b,v,{holes:0,th:1,lw:1.1});
 g.restore();
 /* the giant clock-key staff, planted with each step */
 rpmLimb(g,[SX0,1,SX1,STOP+8],2.4,rpmSh(V.b,-.12),1.7);g.beginPath();g.moveTo(SX0-.5,0);g.lineTo(SX1-.5,STOP+9);rpmHi(g,.55,.7);
 const KB=rpw3mPo([SX0+.8,-3,SX0+6.4,-3,SX0+6.4,-5,SX0+4.4,-5,SX0+4.4,-6.6,SX0+6.4,-6.6,SX0+6.4,-9,SX0+.6,-9]);rpw3mPart(g,KB,[SX0,-9,SX0+7,-3],V.b,v,1.4,30);
 if(v==='foundry'){rpmGlow(g,SX0+3.6,-6,7,V.gl,.6);g.save();g.clip(KB);g.fillStyle=rpmA(V.gl,.7);g.fillRect(SX0,-9,8,6);g.restore();g.lineWidth=1.4;g.strokeStyle=RPMO;g.stroke(KB)}
 rpmEl(g,(SX0+SX1)/2+.5,-30+by*.5,2.2,1.4,V.b,1.2);
 const kcs=Math.cos(a),ksx=Math.max(.16,Math.abs(kcs)),KX=SX1,KY=STOP,KR=5.6,kc=kcs>0?V.b:rpmSh(V.b,-.22);
 rpmEl(g,KX,KY+7,2.6,1.6,rpw3mMF(g,KX-3,KY+5,KX+3,KY+9,V.b,v),1.3);
 for(const sg of[-1,1]){rpmEl(g,KX+sg*KR*.9*ksx,KY,KR*.86*ksx+.5,KR*.62,rpw3mMF(g,KX-KR*2*ksx,KY-KR,KX+KR*2*ksx,KY+KR,kc,v),1.6);rpmEl(g,KX+sg*KR*1*ksx,KY,KR*.32*ksx+.2,KR*.24,'#1a1024',0)}
 rpmEl(g,KX,KY,2.4*Math.max(.5,ksx),2.4,rpw3mMF(g,KX-2,KY-2,KX+2,KY+2,rpmSh(kc,.2),v),1.2);
 if(v==='meadow'){rpw3mVine(g,[SX0+.6,-6,SX0+3,-14,SX0+.8,-22,SX1-1.6,-32,SX1+1,-40],21,.9);rpw3mBird(g,KX-1,KY-4.6,.78,ph,'#ff8a5a')}
 if(v==='storm'){const pu=.6+.4*((f8%2));rpmGlow(g,KX,KY,12,V.gl,.6*pu);rpw3mArc(g,hx-2.6,-66+by,KX-3,KY,f8*29+5,2.6,V.gl,1)}
 /* haste: little gears whirring around the staff top */
 for(const [ox,oy,r,n,dir] of[[7,10,3.2,8,1],[-9,-6,2.4,6,-1]]){const t=a*.5*dir;rpw3mGear(g,KX+ox+Math.cos(a+ox)*1.4,KY+oy+Math.sin(a+ox)*1.4,r,n,t*2+ox,V.b,v,{holes:0,th:1,lw:1})}
 /* the front arm gripping the staff */
 const gx=(SX0+SX1)/2,gy=-29+by*.6;rpmLimb(g,[6,-34+by,12,-26+by,gx-1,gy],2.8,V.m,1.7);
 rpmEl(g,gx,gy,2.8,2.4,rpw3mMF(g,gx-3,gy-3,gx+3,gy+3,V.b,v),1.4);g.beginPath();g.moveTo(gx-1,gy-1.4);g.lineTo(gx+2.4,gy-1.2);g.moveTo(gx-1,gy+.4);g.lineTo(gx+2.4,gy+.6);g.lineWidth=.7;g.strokeStyle=RPMO;g.stroke()};


/* ========== 6. Springjack: a grinning jester head on a big coil spring, hopping along in its crank box ========== */
RPMD.spring=function(g,ph,o){const v=rpw3mV(o&&o.v),V=RPW3M_V[v],a=ph*RPMT,sn=Math.sin(a),f8=Math.floor(ph*8);
 /* one hop per cycle: in the air while sin>0, squashed on landing */
 const L=Math.max(0,sn)*6,c=sn<0?1+.34*sn:1+.08*sn,FC=v==='foundry'?'#6a6270':v==='storm'?'#eef6ff':'#f6ecd2',HAT=v==='foundry'?['#3a3440','#ff7a1a']:v==='storm'?['#4a62a6','#dde8ff']:['#3a9a6a','#e2c060'];
 const bt=-13-L,sy0=bt-2,sy1=sy0-21*c,hy=sy1-11.6,hx=1+Math.cos(a)*.6;
 /* the lid, open behind */
 g.save();g.translate(-11,bt-1);g.rotate(-2.1+Math.sin(a*2)*.1);const LP=rpw3mPr(0,-1.5,17,3,1);rpw3mPart(g,LP,[0,-2,17,2],v==='foundry'?V.md:V.t,v,1.8,3);g.restore();
 /* back arm and glove */
 const wv=Math.sin(a+1)*3,glove=(x,y,ang,sc,col)=>{g.save();g.translate(x,y);g.rotate(ang);g.scale(sc,sc);rpmEl(g,0,0,4.2,3.6,col,1.6);for(let k=0;k<3;k++)rpmEl(g,3.4,-1.8+k*1.8,2,1.1,col,1.1);rpmEl(g,-.6,-3.4,1.2,1.9,col,1.1,-.5);rpmEl(g,-3.6,.2,1.6,2.6,rpmSh(col,-.12),1.2);g.restore()};
 rpmLimb(g,[-3,sy1+1,-9,sy1+3+wv*.4,-14,sy1+5+wv],2.2,HAT[0],1.6);glove(-15,sy1+5+wv,2.6,.9,v==='foundry'?'#8a8290':'#ffffff');
 /* the crank box */
 const FP=rpw3mPr(-11,bt,18,13+L*0,2),SP=rpw3mPo([7,bt+.6,11,bt-2.6,11,bt+10.4,7,bt+13]),TP=rpw3mPo([-11,bt+.4,7,bt+.4,11,bt-2.6,-7,bt-2.6]);
 rpw3mPart(g,SP,[7,bt-3,11,bt+13],rpmSh(V.m,-.25),v,1.8,5);rpw3mPart(g,TP,[-11,bt-3,11,bt+1],rpmSh(V.m,.2),v,1.8,6);
 if(v==='foundry'){rpw3mHaz(g,FP,-11,bt,7,bt+13,2.4,2.2)}else{rpw3mPart(g,FP,[-11,bt,7,bt+13],V.m,v,2.2,7);
  const IP=rpw3mPr(-8.6,bt+2.4,13.2,8.2,1.6);g.fillStyle=v==='storm'?rpmLG(g,0,bt,0,bt+11,[0,V.t,1,V.td]):rpmLG(g,0,bt,0,bt+11,[0,'#e8c86a',1,'#b8862e']);g.fill(IP);g.lineWidth=1.2;g.strokeStyle=RPMO;g.stroke(IP);
  if(v==='storm'){const BP=rpw3mBoltP(-2,bt+6.4,1.2);g.fillStyle=V.ey;g.fill(BP);g.lineWidth=.9;g.strokeStyle=RPMO;g.stroke(BP);rpmGlow(g,-2,bt+6.4,8,V.gl,.5)}
  else{g.font='bold 7px Georgia,serif';g.textAlign='center';g.textBaseline='middle';g.lineWidth=2;g.strokeStyle=RPMO;g.strokeText('?',-2,bt+6.8);g.fillStyle='#c8382a';g.fillText('?',-2,bt+6.8)}}
 for(const [x,y] of[[-9.6,bt+1.4],[5.6,bt+1.4],[-9.6,bt+11.6],[5.6,bt+11.6]])rpw3mRv(g,x,y,.8,V.rv);
 /* the crank on the side: one turn per cycle */
 const ckx=9,cky=bt+5,ct=a*1,hx2=ckx+Math.cos(ct)*1.2+2.6,hy2=cky+Math.sin(ct)*5;rpmEl(g,ckx,cky,1.6,1.8,V.b,1.1);rpmLimb(g,[ckx,cky,hx2,hy2],1.6,V.b,1.2);rpmLimb(g,[hx2,hy2,hx2+3.2,hy2],2.4,'#c8382a',1.2);
 if(v==='meadow'){rpvMoss(g,[-11,bt+.6,-8,bt-3,0,bt-3.6,8,bt-2.4,11,bt-1,6,bt+1,-4,bt+1.2],[[-6,bt-2,1.5],[5,bt-1.4,1.3]]);rpw3mDaisy(g,-8,bt-2.4,2,'#ff9ad0','#ffe46a');rpw3mVine(g,[-11,bt+2,-10,bt+7,-11.4,bt+11],5,.8)}
 /* the spring (foundry: a piston rod runs up its middle) */
 if(v==='foundry'){rpmLimb(g,[-1,sy0,-1,sy1],2.6,V.ml,1.6);rpmGlow(g,-1,sy0-2,6,V.gl,.4)}
 rpw3mCoil(g,-1,sy0,sy1,6,5,2.4,v==='foundry'?V.md:v==='storm'?V.ml:V.b,v);
 if(v==='storm'){rpw3mArc(g,-7,sy0-3,5,sy1+3,f8*13+5,3,V.gl,1);if(f8%2)rpw3mArc(g,6,sy0-5,-6,sy1+6,f8*7+2,2.4,V.g2,.8)}
 /* ruff collar */
 g.beginPath();for(let k=0;k<=12;k++){const t=Math.PI*(k/12),r=k%2?6:9.4,x=-1+Math.cos(t+Math.PI)*r,y=sy1+1-Math.sin(t)*r*.32+(k%2?0:1.4);k?g.lineTo(x,y):g.moveTo(x,y)}g.closePath();
 rpmFS(g,v==='meadow'?'#7ccc4a':v==='foundry'?'#ff9a3a':'#ffffff',1.6);
 g.beginPath();for(let k=0;k<=12;k++){const t=Math.PI*(k/12),r=k%2?5:9,x=-1+Math.cos(t+Math.PI)*r,y=sy1+3+Math.sin(t)*r*.3+(k%2?-.6:1);k?g.lineTo(x,y):g.moveTo(x,y)}g.closePath();
 rpmFS(g,v==='meadow'?'#4a9a34':v==='foundry'?'#c84a1a':'#b8c8ec',1.6);
 /* the hat: two floppy points with bells, lagging behind the hop */
 const lag=Math.cos(a)*.22;
 const point=(dir,col)=>{const bxp=dir<0?hx-19+lag*-5:hx+18+lag*-5,byp=hy-11+lag*7+(dir<0?2:0),P=new Path2D();
  if(dir<0){P.moveTo(hx-9.6,hy-4);P.quadraticCurveTo(hx-12,hy-23,bxp,byp);P.quadraticCurveTo(hx-8,hy-16,hx+1,hy-11)}
  else{P.moveTo(hx-2,hy-11);P.quadraticCurveTo(hx+11,hy-25,bxp,byp);P.quadraticCurveTo(hx+9,hy-13,hx+10.4,hy-3)}P.closePath();
  rpw3mDo(g,P,rpmLG(g,hx,hy-22,bxp,byp,[0,rpmSh(col,.3),.6,col,1,rpmSh(col,-.25)]),1.8);
  if(v==='meadow'){rpw3mDaisy(g,bxp,byp+2,2.6,dir<0?'#ff9ad0':'#ffffff','#ffd84a')}
  else{rpmGlow(g,bxp,byp+2.4,7,V.gl,.6);
   rpmEl(g,bxp,byp+2.4,2.7,2.7,v==='storm'?rpmRG(g,bxp,byp+2.4,2.7,[0,'#ffffff',.5,V.ey,1,V.gl]):rpmRG(g,bxp,byp+2.4,2.7,[0,'#fff3c0',.5,V.g2,1,V.gl]),1.3);
   g.beginPath();g.moveTo(bxp-1.5,byp+3);g.lineTo(bxp+1.5,byp+3);g.lineWidth=.8;g.strokeStyle=RPMO;g.stroke()}};
 point(-1,HAT[0]);point(1,HAT[1]);
 /* the head: painted tin face, wide eyes, a huge toothy grin, a ball nose */
 const HP=rpw3mPe(hx,hy,10.4,10*(1+(1-c)*.15));rpw3mDo(g,HP,rpmRG(g,hx,hy,11,[0,rpmSh(FC,.4),.6,FC,1,rpmSh(FC,-.28)],hx-3,hy-4),2.3);
 if(v==='foundry'){g.save();g.clip(HP);g.fillStyle='rgba(20,12,20,.32)';g.beginPath();g.ellipse(hx-5,hy+4,6,4,.3,0,RPMT);g.fill();g.restore()}
 const HB=new Path2D();HB.moveTo(hx-10.4,hy-2);HB.quadraticCurveTo(hx-9,hy-11.6,hx+1,hy-11.4);HB.quadraticCurveTo(hx+10,hy-11,hx+10.6,hy-3);HB.quadraticCurveTo(hx,hy-6.4,hx-10.4,hy-2);HB.closePath();
 rpmFS(g,rpmLG(g,0,hy-12,0,hy-2,[0,rpmSh(HAT[0],.2),1,rpmSh(HAT[0],-.2)]),1.8);g.fill(HB);g.stroke(HB);
 g.fillStyle=HAT[1];for(let k=0;k<4;k++){const x=hx-7.6+k*5.2;g.beginPath();g.moveTo(x-1.8,hy-4.6+Math.abs(k-1.5)*.9);g.lineTo(x,hy-2.4+Math.abs(k-1.5)*.9);g.lineTo(x+1.8,hy-4.6+Math.abs(k-1.5)*.9);g.closePath();rpmFS(g,HAT[1],1)}
 const iris=v==='foundry'?V.gl:v==='storm'?'#3ad0ff':'#ffcf2a';
 rpw3mEyeC(g,hx+2.4,hy+.4,3.6,iris,v);rpw3mEyeC(g,hx+8.2,hy,2.6,iris,v);
 rpmEl(g,hx-3.4,hy+4,2.2,1.4,'rgba(255,90,110,.45)',0);
 g.beginPath();g.moveTo(hx-4,hy+4.6);g.quadraticCurveTo(hx+3,hy+12.4,hx+10.4,hy+4);g.quadraticCurveTo(hx+3,hy+7.4,hx-4,hy+4.6);g.closePath();rpmFS(g,'#3a0e1a',1.5);
 for(let k=0;k<5;k++){const u=(k+.5)/5,x=hx-4+u*14.4,y=hy+4.6+(Math.sin(u*Math.PI)*2.4)-(u*.6);rpmP(g,[x-1.2,y,x+1.2,y,x,y+2.2]);g.fillStyle='#fffbe8';g.fill()}
 rpmEl(g,hx+10.4,hy+2,2.2,2.2,v==='storm'?rpmRG(g,hx+10.4,hy+2,2.2,[0,'#ffffff',1,V.gl]):rpmRG(g,hx+10.4,hy+2,2.2,[0,'#ff9a8a',1,'#c8202a'],hx+9.6,hy+1.2),1.3);
 /* front arm and glove */
 rpmLimb(g,[1,sy1+3,7,sy1+5-wv*.3,12,sy1+7-wv],2.2,HAT[0],1.6);glove(13.4,sy1+7-wv,-.3,.95,v==='foundry'?'#a8a0ae':'#ffffff');
 if(v==='foundry')rpw3mPuff(g,-6,bt-1,ph,.8,1,2,-10,-6)};

/* ========== 7. Sparkjammer: a strutting chicken-legged radio set with one camera eye and a crackling antenna dish ========== */
RPMD.jammer=function(g,ph,o){const v=rpw3mV(o&&o.v),V=RPW3M_V[v],a=ph*RPMT,s=Math.sin(a),by=-Math.abs(Math.cos(a))*2,f8=Math.floor(ph*8),pu=.7+.3*Math.sin(a*2);
 /* chicken-walker legs: knee forward, ankle back, three toes */
 const leg=(p,col,dk)=>{const hx=-1,hy=-24+by,fx=-1+9*Math.sin(p),fy=-Math.max(0,Math.cos(p))*4.6,ax=fx-3,ay=fy-5,k=rpmKnee(hx,hy,ax,ay,22,-1);
  if(v==='foundry'&&!dk){rpmLimb(g,[hx,hy,k[0],k[1]],4.6,col,2);g.save();g.lineCap='butt';g.setLineDash([2.2,2.2]);g.beginPath();g.moveTo(hx,hy);g.lineTo(k[0],k[1]);g.lineWidth=3.4;g.strokeStyle='#ffc426';g.stroke();g.restore()}
  else rpmLimb(g,[hx,hy,k[0],k[1]],4.6,col,2);
  rpmLimb(g,[k[0],k[1],ax,ay],3,rpmSh(col,-.1),1.8);rpw3mRv(g,k[0],k[1],2.4,dk?rpmSh(V.b,-.3):V.b);
  /* a little piston behind the shin */
  rpmLimb(g,[k[0]-2,k[1]+2,ax-2.4,ay-2],1.4,V.ml,1.2);
  g.save();g.translate(ax,ay);rpmLimb(g,[0,0,fx-ax+1,fy-ay-1],2.4,col,1.6);
  for(const [tx,ty] of[[fx-ax+6,fy-ay],[fx-ax+3,fy-ay+.4],[fx-ax-3,fy-ay+.2]])rpmLimb(g,[fx-ax+1,fy-ay-1,tx,ty],1.8,dk?rpmSh(V.b,-.3):V.b,1.3);g.restore();rpmEl(g,ax,ay,1.8,1.8,col,1.2)};
 leg(a+Math.PI,V.md,1);
 /* the dish: faces up and forward, sweeping a little */
 const mx=-2,mtop=-53+by,th=-.58+Math.sin(a)*.12,R=14,ex=Math.cos(th)*R*.95,ey=Math.sin(th)*R*.95;
 rpmLimb(g,[mx,-37+by,mx,mtop],3,V.md,1.6);rpw3mGear(g,mx,mtop+6,3.6,8,a/4,V.b,v,{holes:0,th:1.2,lw:1.2});
 g.save();g.translate(mx-Math.cos(th)*2,mtop-Math.sin(th)*2);g.rotate(th);
 const SH=new Path2D();SH.moveTo(0,-R);SH.quadraticCurveTo(-R*1.05,0,0,R);SH.closePath();rpw3mPart(g,SH,[-R,-R,0,R],v==='storm'?V.ml:V.m,v,2,3);
 const IN=rpw3mPe(0,0,R*.44,R);
 g.fillStyle=v==='foundry'?rpmRG(g,0,0,R,[0,'#fff3c0',.3,V.g2,.7,V.gl,1,'#8a2a0a']):v==='storm'?rpmRG(g,0,0,R,[0,'#ffffff',.5,'#c8f4ff',1,V.md]):rpmRG(g,0,0,R,[0,rpmSh(V.ml,.3),.7,V.ml,1,V.m]);g.fill(IN);
 g.save();g.clip(IN);g.beginPath();for(let k=1;k<4;k++){g.ellipse(0,0,R*.44*k/4,R*k/4,0,0,RPMT)}g.lineWidth=.6;g.strokeStyle=rpmA(RPMO,.35);g.stroke();g.restore();
 g.lineWidth=2.2;g.strokeStyle=RPMO;g.stroke(IN);g.beginPath();g.ellipse(0,0,R*.44,R,0,-1.6,-.4);rpmHi(g,.7,1.1);
 if(v==='meadow'){/* a nest in the dish with a bird and two eggs */g.restore();g.save();g.translate(mx-Math.cos(th)*2,mtop-Math.sin(th)*2);g.rotate(th);g.rotate(-th);
  rpmEl(g,-3.4,-2.6,2,2.5,'#bff0ff',1.1);rpmEl(g,-.4,-2.9,2,2.5,'#e8faff',1.1);rpw3mBird(g,4.6,-1.4,.8,ph,'#ffcf3a');rpw3mNest(g,0,1.6,17)}
 else{/* feed struts and the emitter */
  for(const sg of[-1,1])rpmLimb(g,[0,sg*R*.92,R*.95,0],1,V.b,1);rpmLimb(g,[-R*.1,0,R*.95,0],1.1,V.b,1);
  rpmGlow(g,R*.95,0,9*pu,v==='foundry'?V.gl:V.gl,.8);rpmEl(g,R*.95,0,2.4,2.4,rpmRG(g,R*.95,0,2.4,[0,'#ffffff',.5,V.ey,1,V.gl]),1.2)}
 g.restore();
 /* sparks and arcs off the emitter */
 const EX=mx-Math.cos(th)*2+ex,EY=mtop-Math.sin(th)*2+ey;
 if(v==='storm'){rpw3mArc(g,EX,EY,EX+10,EY-8+(f8%3)*3,f8*17+1,3.4,V.gl,1.2);rpw3mArc(g,EX,EY,EX-9,EY-10,f8*11+7,3,V.g2,1);if(f8%2)rpw3mArc(g,EX,EY,EX+12,EY+6,f8*5+3,2.6,V.gl,.9)}
 else if(v==='foundry'){rpw3mArc(g,EX,EY,EX+8,EY-7+(f8%3)*2,f8*17+1,2.4,V.g2,.9);rpvSparks(g,EX-4,EX+8,EY,14,ph,5,3,[V.g2,V.gl])}
 else{rpvSparks(g,mx-6,mx+8,mtop-8,12,ph,4,5,['#fff6a0','#ffd84a'])}
 /* the body: a squat radio set */
 const BX=[-14,-41+by,12,-21+by],BP=rpw3mPr(-14,-41+by,26,20,6);rpw3mPart(g,BP,BX,V.m,v,2.4,11);
 const BB=new Path2D();BB.rect(-14,-27+by,26,3.2);g.save();g.clip(BP);rpw3mPart(g,BB,[-14,-27+by,12,-24+by],v==='storm'?V.t:V.b,v,1.4,4);g.restore();g.lineWidth=2.4;g.strokeStyle=RPMO;g.stroke(BP);
 for(const x of[-11,-6,-1,4,9])rpw3mRv(g,x,-25.4+by,.8,V.rv);
 /* speaker grille, dials and antennae with blinking bulbs */
 const GR=rpw3mPr(-11.6,-37.6+by,10,8,2);g.fillStyle=V.dk;g.fill(GR);g.lineWidth=1.4;g.strokeStyle=RPMO;g.stroke(GR);
 g.beginPath();for(let k=0;k<4;k++){g.moveTo(-10.4,-35.8+by+k*1.9);g.lineTo(-2.8,-35.8+by+k*1.9)}g.lineWidth=.9;g.strokeStyle=rpmSh(V.m,.2);g.stroke();
 for(const [x,l,ph0] of[[-10,9,0],[-6,6,.5]]){const sw=Math.sin(a*2+ph0)*1.4;g.beginPath();g.moveTo(x,-41+by);g.quadraticCurveTo(x-1,-41-l*.5+by,x-2+sw,-41-l+by);g.lineWidth=2.6;g.strokeStyle=RPMO;g.stroke();g.lineWidth=1;g.strokeStyle=V.ml;g.stroke();
  const on=(f8+(ph0?2:0))%4<2;if(on)rpmGlow(g,x-2+sw,-41-l+by,5,ph0?V.g2:'#ff4a3a',.8);rpmEl(g,x-2+sw,-41-l+by,1.5,1.5,on?(ph0?V.g2:'#ff5a4a'):'#5a2a2a',1)}
 /* the camera eye: an aperture iris */
 const cx=5,cy=-32.6+by;rpmGlow(g,cx,cy,14,V.gl,.5*pu);rpmEl(g,cx,cy,7,7,rpw3mMF(g,cx-7,cy-7,cx+7,cy+7,v==='storm'?V.t:V.b,v),2);
 rpmEl(g,cx,cy,5.2,5.2,'#140a14',1.2);g.save();g.beginPath();g.arc(cx,cy,5.2,0,RPMT);g.clip();
 const ap=2.2+Math.sin(a*2)*.5;for(let k=0;k<6;k++){const t=k/6*RPMT+a*.25;g.beginPath();g.moveTo(cx+Math.cos(t)*ap,cy+Math.sin(t)*ap);g.lineTo(cx+Math.cos(t)*6,cy+Math.sin(t)*6);g.lineTo(cx+Math.cos(t+1.1)*6,cy+Math.sin(t+1.1)*6);g.closePath();g.fillStyle=k%2?'#2a2030':'#3a2e40';g.fill();g.lineWidth=.5;g.strokeStyle='#000';g.stroke()}
 rpmEl(g,cx,cy,ap,ap,rpmRG(g,cx,cy,ap,[0,'#ffffff',.4,V.ey,1,V.gl]),0);g.restore();rpmEl(g,cx-2,cy-2,1.2,.9,'rgba(255,255,255,.8)',0);
 /* an angry brow plate over the eye */
 const BW=rpw3mPo([cx-7.4,cy-8.6,cx+8,cy-6,cx+7.6,cy-3.6,cx-6.4,cy-5.4]);rpw3mPart(g,BW,[cx-7,cy-9,cx+8,cy-3],V.md,v,1.6,5);
 rpw3mGrin(g,cx-3,cy+7.4,cx+7.4,cy+6.4,1.2,4,V,v!=='meadow');
 /* variant dressing */
 if(v==='meadow'){rpvMoss(g,[-14,-37+by,-12,-42+by,-4,-43.6+by,4,-43+by,10,-41+by,4,-40+by,-6,-40.4+by],[[-9,-41.6+by,1.6],[2,-42.4+by,1.4]]);rpw3mDaisy(g,8,-42+by,2.2,'#ff9ad0','#ffe46a');rpw3mDaisy(g,-12,-40+by,1.7,'#ffffff','#ffd84a');rpw3mVine(g,[-14,-30+by,-12,-25+by,-14,-21+by],2,.8)}
 else if(v==='foundry'){rpvDrip(g,-8,-21+by,ph,5,0);rpvDrip(g,3,-21+by,ph,4,.5);rpw3mPuff(g,-14,-34+by,ph,.9,1,3,-8,-6)}
 leg(a,V.m,0)};


/* an armour plate: textured metal polygon with a light rim on the edges that face the upper left (like rpmRock) */
function rpw3mPlate(g,p,b,v,lw,sd,hi){const n=p.length>>1;let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9,A=0;
 for(let i=0;i<n;i++){const x=p[i*2],y=p[i*2+1],xn=p[((i+1)%n)*2],yn=p[((i+1)%n)*2+1];A+=x*yn-xn*y;x0=Math.min(x0,x);x1=Math.max(x1,x);y0=Math.min(y0,y);y1=Math.max(y1,y)}
 rpw3mPart(g,rpw3mPo(p),[x0,y0,x1,y1],b,v,lw||2.6,sd);if(hi===0)return;const sg=A>0?1:-1,d=(lw||2.6)*.5+1.4;g.beginPath();
 for(let i=0;i<n;i++){const xa=p[i*2],ya=p[i*2+1],xb=p[((i+1)%n)*2],yb=p[((i+1)%n)*2+1],dx=xb-xa,dy=yb-ya,L=Math.hypot(dx,dy)||1,nx=dy/L*sg,ny=-dx/L*sg;
  if(-.6*nx-.8*ny>.35){g.moveTo(xa-nx*d+dx*.14,ya-ny*d+dy*.14);g.lineTo(xb-nx*d-dx*.14,yb-ny*d-dy*.14)}}rpmHi(g,hi||(v==='storm'?.7:.42),1.5)}
/* a broken bolt stub where a plate tore off */
function rpw3mStub(g,x,y,V){rpmEl(g,x,y,2.2,2.2,'#2a2030',1.2);rpmP(g,[x-1.4,y-1,x+.4,y-4.2,x+1.6,y-.6]);rpmFS(g,rpmSh(V.m,.2),1)}

/* ========== 8. Titan Automaton (boss): a hunched knuckle-walking colossus, a furnace heart, armour plates it sheds ==========
   RPMD.titan_p2 / titan_p3 are the same machine after the first and second sheds (st 2 / 3). */
function rpw3mTitan(g,ph,o,st){const v=rpw3mV(o&&o.v),V=RPW3M_V[v],a=ph*RPMT,f8=Math.floor(ph*8),by=(Math.cos(a*2)-1)*1.8,pu=.75+.25*Math.sin(a*2),
 PL=V.m,FR=V.md,DK=V.dk,TR=v==='storm'?V.t:V.b,core=st===3?1.25:st===2?1.1:1;
 const plate=(p,b,sd,dy)=>rpw3mPlate(g,dy?p.map((q,i)=>i%2?q+dy:q):p,b,v,2.6,sd);
 const T=(p,dx,dy)=>p.map((q,i)=>q+(i%2?dy:dx));
 /* ---- back gear and stacks ---- */
 g.save();g.translate(0,by);
 rpw3mGear(g,-54,-104,35,16,a*2/16,rpmSh(V.b,-.08),v,{holes:6,th:6.4,lw:2.8});
 if(v==='storm'){for(const [x,h] of[[-40,36],[-22,28]]){rpmLimb(g,[x,-136,x,-136-h],4,V.t,2);for(let k=0;k<4;k++){const y=-140-k*(h-8)/4,r=7.4-k*1.2;rpmEl(g,x,y,r,r*.34,rpw3mMF(g,x-r,y-2,x+r,y+2,k%2?V.b:V.ml,v),1.8)}
   rpmGlow(g,x,-140-h,16,V.gl,.75*pu);rpmEl(g,x,-140-h,5,5,rpmRG(g,x,-140-h,5,[0,'#ffffff',.5,V.ey,1,V.gl],x-1.6,-141.6-h),1.8)}
  rpw3mArc(g,-40,-176,-22,-168,f8*13+5,5,V.gl,1.6);rpw3mArc(g,-40,-176,-60,-156+(f8%3)*4,f8*7+1,4,V.g2,1.1);if(f8%2)rpw3mArc(g,-22,-168,-4,-156,f8*5+9,4,V.gl,1.2)}
 else{for(const [x,h,w] of[[-40,40,10],[-22,30,9]]){const P=rpw3mPo([x-w/2-1,-130,x-w/2,-136-h,x+w/2,-136-h,x+w/2+1,-130]);rpw3mPart(g,P,[x-w/2,-136-h,x+w/2,-130],v==='meadow'?V.t:V.md,v,2.4,x);
   const C=rpw3mPr(x-w/2-2.6,-141-h,w+5.2,6,2);rpw3mPart(g,C,[x-w/2-3,-141-h,x+w/2+3,-135-h],TR,v,2.2,x+1);rpmEl(g,x,-141-h,w/2,1.6,'#1a1024',0);
   for(const y of[-146,-136])if(-136-h<y)rpmEl(g,x,y,w/2+.6,1.6,TR,1.4)}
  if(v==='foundry'){rpmGlow(g,-40,-180,16,V.gl,.6*pu);rpmGlow(g,-22,-170,12,V.gl,.5*pu);rpw3mPuff(g,-41,-184,ph,2.4,1,4,-16,-8);rpw3mPuff(g,-23,-174,(ph+.4)%1,1.9,1,3,-14,-8);rpvSparks(g,-48,-16,-180,22,ph,6,11,[V.g2,V.gl])}
  else{/* a sapling grows from the cold stacks */const tx=-31,ty=-136;g.beginPath();g.moveTo(tx,ty);g.quadraticCurveTo(tx-3,ty-16,tx+2,ty-30);g.lineWidth=6.4;g.strokeStyle=RPMO;g.stroke();g.lineWidth=3.4;g.strokeStyle='#8a5a32';g.stroke();
   for(const [x,y,r] of[[tx+2,ty-38,10],[tx-8,ty-32,8],[tx+11,ty-31,8],[tx+2,ty-28,7]]){rpmEl(g,x,y,r,r*.82,rpmRG(g,x,y,r,[0,'#b4ec6c',.6,'#5ab43a',1,'#2e7a2a'],x-r*.4,y-r*.4),2)}
   rpw3mDaisy(g,tx-6,ty-34,2.4,'#ff9ad0','#ffe46a');rpw3mDaisy(g,tx+8,ty-38,2.2,'#ffffff','#ffd84a');rpw3mDaisy(g,tx+12,ty-29,2,'#ffd84a','#ff9a3a')}}
 g.restore();
 /* ---- limbs ---- */
 const legL=(bx,p,col,near)=>{const fx=bx+12*Math.sin(p),l=Math.max(0,Math.cos(p))*8,hy=-64+by,k=rpmKnee(bx,hy,fx,-14-l,52,-1);
  rpmLimb(g,[bx,hy,k[0],k[1]],22,col,2.6);rpmLimb(g,[k[0],k[1],fx,-14-l],16,rpmSh(col,-.08),2.6);
  g.beginPath();g.moveTo(k[0]-4,k[1]+4);g.lineTo(fx-4,-16-l);g.lineWidth=3;g.strokeStyle=rpmA(V.ml,near?.55:.25);g.stroke();
  if(near&&st<3){const tp=[bx-14,hy-6,bx+14,hy-8,k[0]+12,k[1]-6,k[0]-8,k[1]-4];plate(tp,PL,61)}
  if(near&&st===3){rpmLimb(g,[bx+6,hy+4,k[0]+6,k[1]-4],3.4,V.ml,1.8);rpw3mGear(g,bx,hy+2,9,10,a*2/10,V.b,v,{holes:4,th:2.2})}
  rpw3mGear(g,k[0],k[1],10.4,10,-a*2/10,near?V.b:rpmSh(V.b,-.35),v,{holes:0,th:2.4,lw:2.2});rpw3mRv(g,k[0],k[1],3.6,near?V.m:FR);
  g.save();g.translate(fx,-l);const FP=new Path2D();FP.moveTo(-18,0);FP.lineTo(-17,-14);FP.quadraticCurveTo(-4,-19,10,-14);FP.quadraticCurveTo(22,-11,23,0);FP.closePath();rpw3mPart(g,FP,[-18,-18,23,0],near?PL:FR,v,2.6,7);
  for(const x of[6,13,19.4]){const TP=rpw3mPo([x-4,-1,x-3,-7,x+3,-6,x+3.6,-1]);rpw3mPart(g,TP,[x-4,-7,x+4,-1],near?TR:rpmSh(TR,-.35),v,1.6,x)}
  g.beginPath();g.moveTo(-17,-4);g.lineTo(2,-4);g.lineWidth=1.3;g.strokeStyle=rpmA(RPMO,.6);g.stroke();g.restore()};
 const sw=Math.sin(a)*9,lift=Math.max(0,Math.cos(a))*6,sw2=-sw,lift2=Math.max(0,-Math.cos(a))*6;
 const fist=(x,y,col,near,haz)=>{g.save();g.translate(x,y);const FP=new Path2D();FP.moveTo(-17,0);FP.lineTo(-18,-20);FP.quadraticCurveTo(-16,-30,-4,-31);FP.lineTo(10,-30);FP.quadraticCurveTo(21,-28,21,-16);FP.lineTo(21,0);FP.closePath();
  rpw3mPart(g,FP,[-18,-31,21,0],col,v,2.6,3);if(haz){const HZ=rpw3mPr(-18,-25,39,6,0);g.save();g.clip(FP);rpw3mHaz(g,HZ,-18,-25,21,-19,3,1.6);g.restore();g.lineWidth=2.6;g.strokeStyle=RPMO;g.stroke(FP)}
  for(let k=0;k<4;k++){const kx=-12+k*9,KP=rpw3mPr(kx-4.2,-9,8.4,10,3.4);rpw3mPart(g,KP,[kx-4,-9,kx+4,1],near?TR:rpmSh(TR,-.35),v,2,k);rpw3mRv(g,kx,-5.4,1,V.rv)}
  const TH=new Path2D();TH.moveTo(12,-24);TH.quadraticCurveTo(26,-22,24,-10);TH.lineTo(16,-10);TH.closePath();rpw3mPart(g,TH,[12,-24,26,-10],col,v,2,9);
  g.beginPath();g.moveTo(-14,-24);g.quadraticCurveTo(-4,-29,8,-27);rpmHi(g,near?.6:.25,1.6);g.restore()};
 const armL=(sx,sy,ex,ey,hx,hy,col,near)=>{rpmLimb(g,[sx,sy,ex,ey],near?24:20,col,2.6);
  if(near&&st===3){rpmLimb(g,[ex,ey,hx,hy],12,FR,2.4);rpmLimb(g,[ex+5,ey+2,hx+3,hy-6],4.4,V.ml,1.8);rpmLimb(g,[ex-6,ey+4,hx-6,hy-4],3,'#c8382a',1.4);rpmLimb(g,[ex-2,ey+6,hx-2,hy-2],2.4,'#3a7ad8',1.2)}
  else{const L=Math.hypot(hx-ex,hy-ey),an=Math.atan2(hy-ey,hx-ex);g.save();g.translate(ex,ey);g.rotate(an);const BP=rpw3mPr(-6,-15,L+4,30,10);
   if(v==='foundry'&&near){rpw3mPart(g,BP,[-6,-15,L,15],col,v,2.6,5);const HZ=rpw3mPr(L*.4,-15,L*.32,30,1);rpw3mHaz(g,HZ,L*.4,-16,L*.72,16,3.6,2)}else rpw3mPart(g,BP,[-6,-15,L,15],col,v,2.6,5);
   for(const u of[.18,.86]){const RB=rpw3mPr(L*u-2.6,-16.4,5.2,32.8,2);rpw3mPart(g,RB,[L*u-3,-16,L*u+3,16],near?TR:rpmSh(TR,-.35),v,1.8,u*7)}
   if(near)for(const u of[.3,.5,.7])rpw3mRv(g,L*u,-10,1.5,V.rv);g.restore()}
  rpw3mGear(g,ex,ey,11,10,a*2/10,near?V.b:rpmSh(V.b,-.35),v,{holes:0,th:2.6,lw:2.2});rpw3mRv(g,ex,ey,3.8,near?V.m:FR)};
 /* far arm, far leg */
 armL(10,-120+by,36,-76+by,58+sw2*.9,-26-lift2,FR,0);fist(62+sw2,-1-lift2,FR,0,0);
 legL(-34,a+Math.PI,FR,0);
 /* ---- the torso ---- */
 g.save();g.translate(0,by);
 const TP=[-60,-68,-68,-104,-58,-136,-32,-154,4,-158,32,-150,52,-132,62,-106,60,-80,46,-62,10,-56,-30,-58];plate(TP,st===1?PL:FR,71);
 /* exposed machinery shows wherever plates are gone */
 if(st>1){const CV=rpw3mPo([-38,-72,-48,-104,-32,-134,0,-144,30,-132,46,-104,40,-76,14,-64]);g.fillStyle=DK;g.fill(CV);g.save();g.clip(CV);
   rpw3mGear(g,-18,-86,16,12,-a*2/12,rpmSh(V.b,-.15),v,{holes:4,th:3.4});rpw3mGear(g,28,-124,14,10,a*2/10,rpmSh(V.b,-.15),v,{holes:4,th:3});if(st===3){rpw3mGear(g,36,-80,11,9,-a*2/9,rpmSh(V.b,-.1),v,{holes:0,th:2.6});rpw3mGear(g,-30,-122,12,10,-a*2/10,rpmSh(V.b,-.1),v,{holes:4,th:2.8})}
   for(const x of[-30,-14,2,18,34]){rpmLimb(g,[x,-140,x+4,-62],4,rpmSh(FR,-.2),1.6)}
   rpmLimb(g,[-44,-118,44,-112],3.4,rpmSh(FR,-.1),1.6);rpmLimb(g,[-40,-78,46,-82],3.4,rpmSh(FR,-.1),1.6);
   g.beginPath();g.moveTo(-30,-130);g.bezierCurveTo(-10,-110,-40,-96,-14,-78);g.lineWidth=4.6;g.strokeStyle=RPMO;g.stroke();g.lineWidth=2.6;g.strokeStyle='#c8382a';g.stroke();
   g.beginPath();g.moveTo(40,-128);g.bezierCurveTo(28,-108,46,-92,32,-70);g.lineWidth=4.6;g.strokeStyle=RPMO;g.stroke();g.lineWidth=2.6;g.strokeStyle='#3a7ad8';g.stroke();
   g.restore();g.lineWidth=2.6;g.strokeStyle=RPMO;g.stroke(CV)}
 /* the furnace heart */
 const hx=6,hy=-102,HR=15*core;rpmGlow(g,hx,hy,HR*3.4*pu,V.gl,st===3?.85:.6);
 if(st===1){/* layered chest armour around a riveted furnace porthole */
  plate([-48,-104,-34,-132,-6,-146,6,-130,-14,-120,-28,-96,-40,-80],PL,72);plate([-38,-80,-24,-90,0,-84,24,-86,44,-74,30,-62,0,-60,-30,-64],PL,73);
  plate([-4,-146,28,-140,44,-118,26,-118,10,-126],TR,74);
  rpmEl(g,hx,hy,HR+5.4,HR+5.4,rpw3mMF(g,hx-HR,hy-HR,hx+HR,hy+HR,TR,v),2.6);rpmEl(g,hx,hy,HR,HR,rpmRG(g,hx,hy,HR,[0,'#fffbe0',.35,V.g2,.75,V.gl,1,rpmSh(V.gl,-.5)]),2);
  g.save();g.beginPath();g.arc(hx,hy,HR,0,RPMT);g.clip();for(let k=-3;k<=3;k++){const y=hy+k*4.4;const B=rpw3mPr(hx-HR,y-1.2,HR*2,2.4,1);g.fillStyle=rpmSh(FR,-.3);g.fill(B);g.lineWidth=1;g.strokeStyle=RPMO;g.stroke(B)}g.restore();
  for(let k=0;k<10;k++){const t=k/10*RPMT;rpw3mRv(g,hx+Math.cos(t)*(HR+2.8),hy+Math.sin(t)*(HR+2.8),1.4,V.rv)}
  for(const [x,y] of[[-42,-100],[-30,-124],[-12,-138],[-30,-74],[0,-66],[30,-70],[14,-140],[34,-128]])rpw3mRv(g,x,y,1.8,V.rv)}
 else{/* an exposed glass core in a cage */
  if(st===3){g.save();g.globalCompositeOperation='lighter';for(let k=0;k<8;k++){const t=k/8*RPMT+a*.25;g.fillStyle=rpmA(V.gl,.22);g.beginPath();g.moveTo(hx,hy);g.lineTo(hx+Math.cos(t-.12)*HR*3.2,hy+Math.sin(t-.12)*HR*3.2);g.lineTo(hx+Math.cos(t+.12)*HR*3.2,hy+Math.sin(t+.12)*HR*3.2);g.closePath();g.fill()}g.restore()}
  rpmEl(g,hx,hy,HR,HR,rpmRG(g,hx,hy,HR,[0,'#ffffff',.3,V.ey,.7,V.gl,1,rpmSh(V.gl,-.35)],hx-3,hy-4),2.4);
  if(v==='storm')for(let k=0;k<3;k++)rpw3mArc(g,hx,hy,hx+Math.cos(k*2.1+f8)*HR*.9,hy+Math.sin(k*2.1+f8)*HR*.9,f8*7+k*3,2.4,'#ffffff',.9);
  else{g.save();g.beginPath();g.arc(hx,hy,HR,0,RPMT);g.clip();for(let k=0;k<3;k++){const fx=hx-6+k*6,fh=8+3*Math.sin(a*2+k*2);g.fillStyle='rgba(255,255,230,.8)';g.beginPath();g.moveTo(fx-3.6,hy+HR);g.quadraticCurveTo(fx-1,hy+HR-fh,fx,hy+HR-fh*1.6);g.quadraticCurveTo(fx+1,hy+HR-fh,fx+3.6,hy+HR);g.fill()}g.restore()}
  g.beginPath();for(let k=0;k<4;k++){const t=k/4*Math.PI;g.ellipse(hx,hy,HR*Math.abs(Math.cos(t+a*.25))+.5,HR,0,0,RPMT)}g.lineWidth=1.6;g.strokeStyle=rpmA(RPMO,.75);g.stroke();
  rpmEl(g,hx-4,hy-5,3.6,2.4,'rgba(255,255,255,.75)',0,-.6);
  for(const [x,y] of[[-42,-100],[-30,-124],[-12,-138],[0,-66],[14,-140],[34,-128]])rpw3mStub(g,x,y,V);
  if(st===2){plate([-38,-80,-24,-90,0,-84,24,-86,44,-74,30,-62,0,-60,-30,-64],PL,73);g.beginPath();g.moveTo(4,-84);g.lineTo(8,-74);g.lineTo(4,-64);g.lineWidth=1.8;g.strokeStyle=RPMO;g.stroke()}}
 /* back ridge plates */
 const RP=[[-62,-104,-56,-136,-36,-140,-40,-118,-50,-100],[-48,-136,-28,-154,-6,-156,-10,-140,-30,-132],[-12,-152,10,-160,28,-150,22,-140,0,-140]];
 RP.forEach((p,k)=>{if(st===1||(st===2&&k!==1)||(st===3&&k===2))plate(p,PL,90+k);else{rpw3mStub(g,p[2],p[3]+4,V);rpw3mStub(g,p[6],p[7]+3,V)}});
 /* ---- the head, sunk forward between the shoulders ---- */
 const hb=Math.sin(a*2+.6)*1.4;g.save();g.translate(64,-112+hb);g.scale(1.16,1.16);g.translate(-58,110);
 const HD=[38,-130,62,-134,76,-122,78,-100,70,-90,46,-90,36,-104];plate(HD,FR,95);
 /* jaw grille with an underbite */
 const JW=[46,-96,80,-100,84,-88,76,-80,50,-82,42,-88];plate(JW,PL,97);
 for(let k=0;k<5;k++){const x=52+k*6;rpmP(g,[x-2.4,-97,x+2.4,-97.4,x,-104]);rpmFS(g,'#fffbe8',1.2)}
 g.beginPath();for(let k=0;k<5;k++){g.moveTo(50+k*6,-92);g.lineTo(52+k*6,-84)}g.lineWidth=1.4;g.strokeStyle=rpmA(RPMO,.7);g.stroke();
 /* eyes: glowing slits under the brow */
 rpmP(g,[46,-118,76,-122,78,-106,48,-104]);g.fillStyle='#120a14';g.fill();g.lineWidth=1.6;g.strokeStyle=RPMO;g.stroke();
 const er=st===3?1.25:1;rpmGEye(g,57,-111,4.4*er,V.gl,3.4*er);rpmGEye(g,70.4,-113,3.4*er,V.gl,2.8*er);
 if(st<3){plate([38,-126,60,-130,82,-124,80,-116,64,-114,46,-110],PL,99);if(st===1){const CR=[50,-128,60,-146,66,-146,68,-126];plate(CR,TR,98)}}
 else{plate([40,-124,54,-127,58,-120,48,-114],PL,99);plate([64,-126,80,-122,80,-116,68,-118],PL,100);rpvSparks(g,56,66,-122,14,ph,3,4,['#ffffff',V.gl])}
 if(v==='meadow'){rpvMoss(g,[38,-128,46,-134,58,-136,70,-133,76,-126,66,-128,52,-129],[[48,-133,2.2],[62,-134,2]]);
  rpw3mNest(g,58,-134,20);rpw3mBird(g,61,-136,1.05,ph,'#4aa8f0');rpw3mDaisy(g,42,-130,2.4,'#ff9ad0','#ffe46a')}
 g.restore();
 /* variant dressing on the body */
 if(v==='meadow'){rpvMoss(g,[-60,-108,-58,-132,-36,-150,-8,-158,16,-156,0,-150,-20,-146,-40,-136,-52,-120],[[-46,-136,3],[-24,-150,2.6],[-4,-155,2.4]]);
  rpw3mVine(g,[-58,-110,-62,-96,-56,-84,-60,-72],31,1.3);rpw3mVine(g,[-14,-152,-22,-140,-18,-126],37,1.1);
  rpw3mDaisy(g,-40,-144,2.8,'#ff9ad0','#ffe46a');rpw3mDaisy(g,-16,-154,2.4,'#ffffff','#ffd84a');rpw3mDaisy(g,-58,-96,2.4,'#ffd84a','#ff9a3a')}
 else if(v==='foundry'){if(st===1){rpvCrack(g,[-48,-124,-40,-112,-46,-98],3.2);rpvCrack(g,[34,-120,40,-108,36,-96],2.8)}rpvDrip(g,-40,-58,ph,7,.2);rpvDrip(g,20,-58,ph,6,.7)}
 else{rpw3mArc(g,-62,-92,-48,-70,f8*29+3,4,V.gl,1.2);if(f8%2)rpw3mArc(g,44,-66,58,-84,f8*17+5,3.4,V.gl,1)}
 if(st>1){rpvSparks(g,-20,40,-120,40,ph,st===3?7:4,21,v==='storm'?['#ffffff',V.gl]:['#fff3a0',V.g2]);rpw3mPuff(g,-24,-128,(ph*2)%1,1.4,v==='foundry',3,-10,-16)}
 g.restore();
 /* ---- near leg and near arm ---- */
 legL(-6,a,PL,1);
 armL(26,-124+by,54,-78+by,80+sw*.9,-26-lift,PL,1);
 fist(86+sw,-1-lift,PL,1,v==='foundry');
 if(v==='meadow'){rpw3mVine(g,[42,-104+by,48,-92+by,46,-80+by,50,-70+by],41,1.1);rpw3mDaisy(g,48,-90+by,2.2,'#ff9ad0','#ffe46a')}
 /* the pauldron: three layers (two after the first shed, an exposed shoulder joint after the second) */
 g.save();g.translate(0,by);
 if(st===3){rpw3mGear(g,26,-124,17,12,a*2/12,V.b,v,{holes:5,th:3.6});rpw3mRv(g,26,-124,6,V.m);rpw3mStub(g,8,-134,V);rpw3mStub(g,40,-140,V);rpmLimb(g,[14,-112,40,-108],3,V.ml,1.6)}
 else{const layers=[[[0,-118,8,-140,30,-150,52,-140,56,-120,44,-112,24,-110],PL],[[4,-112,12,-130,30,-136,48,-128,52,-112,40,-104,22,-102],TR],[[8,-104,16,-118,30,-122,44,-116,48,-104,36,-96,20,-96],PL]];
  layers.forEach((L,k)=>{if(st===2&&k===0){rpw3mStub(g,10,-138,V);rpw3mStub(g,48,-134,V);return}plate(L[0],L[1],110+k);for(const t of[.3,.7]){const n=L[0].length>>1,j=Math.floor(t*(n-1));rpw3mRv(g,L[0][j*2]*.6+30*.4,L[0][j*2+1]*.6-118*.4+4,1.6,V.rv)}});
  if(st===2)g.save(),g.beginPath(),g.moveTo(26,-128),g.lineTo(31,-118),g.lineTo(27,-110),g.lineWidth=1.8,g.strokeStyle=RPMO,g.stroke(),g.restore();
  if(v==='meadow'){rpvMoss(g,st===1?[2,-126,10,-142,30,-152,50,-142,54,-128,40,-136,24,-140,12,-132]:[6,-118,14,-132,30,-138,46,-130,50,-118,38,-124,22,-126],[[24,st===1?-148:-134,2.6],[40,st===1?-144:-130,2.2]]);rpw3mDaisy(g,32,st===1?-150:-136,2.6,'#ffffff','#ffd84a')}
  if(v==='storm'){const sx=30,sy=st===1?-150:-136;rpmLimb(g,[sx,sy+4,sx,sy-8],2.6,V.ml,1.6);rpmGlow(g,sx,sy-10,10,V.gl,.7);rpmEl(g,sx,sy-10,3.2,3.2,rpmRG(g,sx,sy-10,3.2,[0,'#ffffff',1,V.gl]),1.4);rpw3mArc(g,sx,sy-10,sx+14,sy-2+(f8%2)*4,f8*3+11,3,V.gl,1)}}
 g.restore()}
RPMD.titan=function(g,ph,o){rpw3mTitan(g,ph,o,1)};
RPMD.titan_p2=function(g,ph,o){rpw3mTitan(g,ph,o,2)};
RPMD.titan_p3=function(g,ph,o){rpw3mTitan(g,ph,o,3)};

/* a cartoon eye with an angry lid for the painted faces */
function rpw3mEyeC(g,x,y,r,iris,v){rpmEye(g,x,y,r,iris,v==='foundry'?'#3a3440':v==='storm'?'#4a62a6':'#3a8a5a',.38);if(v!=='meadow')rpmGlow(g,x+r*.3,y+r*.1,r*2.2,iris,.35)}

/* ---------- registry: frame boxes (stage units around the feet), scales, extra room ---------- */
Object.assign(RPMK,{cog:.86,knight:.92,steam:.92,gyro:.88,tinker:.9,spring:.9,jammer:.9,titan:.96,titan_p2:.96,titan_p3:.96});
Object.assign(RPMB,{cog:[-24,-57,23,5,12],knight:[-30,-80,36,6,16],steam:[-44,-125,40,6,30],gyro:[-42,-53,35,6,16],tinker:[-18,-78,35,5,14],spring:[-24,-68,26,5,13],jammer:[-24,-76,30,5,14],titan:[-92,-210,121,8,84],titan_p2:[-92,-210,121,8,84],titan_p3:[-92,-210,121,8,84]});
/* the Titan's shed poses are their own ids: same stats card as the Titan, drawn in the same variants */
RPW_MOBS.titan_p2=3;RPW_MOBS.titan_p3=3;
RPMOB.titan_p2=Object.assign({},RPMOB.titan);RPMOB.titan_p3=Object.assign({},RPMOB.titan);
for(const v of RPW_VARS[3])if(RPMOBV[v]&&RPMOBV[v].titan)RPMOBV[v].titan_p2=RPMOBV[v].titan_p3={n:RPMOBV[v].titan.n};
/* RPMB already holds every accessory, smoke puff and arc, so no variant needs extra room */
for(const id in RPMK)if(RPW_MOBS[id]===3)RPVX[id]=[0,0,0,0];
/* ---------- deaths: a white pop, a burst of steam or smoke, then gears, springs, bolts and plates on arcs ----------
   Debris pieces are small sprites baked once per variant and only rotated per frame. Kinds: g brass gear, h body gear, b nut,
   s spring, p plate, k spark, f puff, l leaf / petal (meadow), e ember (foundry). */
const RPW3M_DX={cog:'gghbbspkkff',knight:'pppghbbsskkff',steam:'pppphggbbbsskkfff',gyro:'pghbbsskkff',tinker:'pgghbbsskkff',spring:'psssghbbkkff',jammer:'pphgbbbsskkff',
 titan:'ppppppphhgggbbbbsssskkkkffff'};
RPW3M_DX.titan_p2=RPW3M_DX.titan_p3=RPW3M_DX.titan;
const RPW3M_DC={};
function rpw3mDeb(v,kd){const key=v+kd;if(RPW3M_DC[key])return RPW3M_DC[key];const V=RPW3M_V[v],cv=document.createElement('canvas');cv.width=cv.height=40;const g=cv.getContext('2d');g.translate(20,20);g.scale(2,2);g.lineJoin='round';g.lineCap='round';
 if(kd==='g')rpw3mGear(g,0,0,8.4,8,0,V.b,v,{holes:4,th:2.2,lw:1.6});
 else if(kd==='h')rpw3mGear(g,0,0,7.6,7,.2,V.m,v,{holes:0,th:2.2,lw:1.6});
 else if(kd==='b'){rpmP(g,[4.4,0,2.2,3.8,-2.2,3.8,-4.4,0,-2.2,-3.8,2.2,-3.8]);rpmFS(g,rpw3mMF(g,-4,-4,4,4,V.ml,v),1.5);rpmEl(g,0,0,1.6,1.6,'#1a1024',0);rpmAH(g,0,0,3,3,3.5,4.6,.6,.8)}
 else if(kd==='s')rpw3mCoil(g,0,7,-7,3.6,3,1.5,v==='foundry'?V.ml:V.b,v);
 else if(kd==='p'){rpw3mPlate(g,[-8,-4,5,-6.4,8.6,2,-4,5.4],V.m,v,1.6,3);rpw3mRv(g,-3.6,-1.6,1,V.rv);rpw3mRv(g,4,0,1,V.rv)}
 else if(kd==='l'){g.beginPath();g.moveTo(-6,0);g.quadraticCurveTo(0,-5,6,0);g.quadraticCurveTo(0,5,-6,0);rpmFS(g,'#7ccc4a',1.3);g.beginPath();g.moveTo(-5,0);g.lineTo(5,0);g.lineWidth=.7;g.strokeStyle='#2e6a1e';g.stroke()}
 else if(kd==='q'){rpw3mDaisy(g,0,0,3.4,'#ff9ad0','#ffe46a')}
 return RPW3M_DC[key]=cv}
function rpw3mDeath(c,id,x,y,k,o){const M=RPMOB[id],D=RPW3M_DX[id];if(!M||!D||!(k<1))return;k=Math.max(0,k);o=o||{};const v=rpw3mV(rpvV(id,o.v)),V=RPW3M_V[v];
 const s=o.s>0?o.s:1,fl=o.flip?-1:1,h=M.h*s,lift=M.air?(M.lift||38)*s:0,cy=y-lift-h*.5,ga=c.globalAlpha,seed=o.seed==null?Math.round(x*7+y*3):o.seed,big=M.boss?1:0,fade=k<.6?1:1-(k-.6)/.4,
  lite=typeof RPX!=='undefined'&&RPX&&(RPX.lite||RPX.rm);
 /* flash and the white body popping (Performance mode and reduced motion: half the debris, no arcs) */
 if(k<.3){const u=k/.3;c.save();c.globalCompositeOperation='lighter';c.globalAlpha=ga*(1-u)*.75;const r=h*(.55+u*.5),q=c.createRadialGradient(x,cy,0,x,cy,r);q.addColorStop(0,'rgba(255,248,230,.9)');q.addColorStop(.5,rpmA(V.gl,.35));q.addColorStop(1,rpmA(V.gl,0));c.fillStyle=q;c.fillRect(x-r,cy-r,r*2,r*2);c.restore()}
 if(k<.22){const C=rpvSheet(id,o.v);if(C){if(!C.wh2)C.wh2=rpvTint(C,0);const u=k/.22;c.save();c.globalAlpha=ga*(1-u);c.translate(x,y-lift);c.scale(fl*(1+u*.3),1-u*.55);c.drawImage(C.wh2,0,0,C.fw/2,C.fh/2,C.B[0]*s,C.B[1]*s,C.w*s,C.h*s);c.restore()}}
 /* shock ring for the heavy ones */
 if(big||id==='steam'){const r=M.w*s*(.3+k*.9);c.globalAlpha=ga*(1-k)*.8;c.lineWidth=(big?6:4)*s*(1-k)+1;c.strokeStyle=v==='storm'?V.gl:v==='foundry'?'#ff8a3a':'#e8f4e0';c.beginPath();c.ellipse(x,y,r,r*.26,0,0,RPMT);c.stroke()}
 /* storm: arcs leap out in the first moments */
 if(v==='storm'&&k<.4&&!lite){c.globalAlpha=ga*(1-k/.4);const f=Math.floor(k*24);for(let i=0;i<3+big*3;i++){const t=rpmRn(seed+i*2.7+f)*RPMT,L=h*(.5+rpmRn(seed+i+f*3)*.5);rpw3mArc(c,x,cy,x+Math.cos(t)*L,cy+Math.sin(t)*L*.7,seed+f*11+i,L*.18,V.gl,1.4*s)}}
 /* debris */
 const G=h*3.4,T=k,kinds=D+(v==='meadow'?'lql':v==='foundry'?'eee':''),L=kinds.length;
 for(let i=0;i<L;i+=lite?2:1){const kd=kinds[i],r1=rpmRn(seed+i*3.1),r2=rpmRn(seed+i*5.7+1),r3=rpmRn(seed+i*1.3+2);
  const ang=-Math.PI/2+(r1-.5)*2.5,sp=h*(kd==='f'?.45:1)*(.9+r2*1.1)*(big?1.15:1);
  let px=x+Math.cos(ang)*sp*T*fl+(r3-.5)*M.w*s*.3,py=cy+(r2-.5)*h*.4+Math.sin(ang)*sp*T+(kd==='f'||kd==='k'||kd==='e'?-.12:.5)*G*T*T;
  const sz=(kd==='p'?(big?13:8):kd==='g'?(big?11:6.4):kd==='h'?(big?9:5.6):kd==='s'?(big?8:5.4):kd==='b'?(big?6:4):kd==='f'?7+k*12:kd==='l'||kd==='q'?5:3.2)*s*(.75+r3*.6);
  if(kd==='l'||kd==='q'){py=cy+Math.sin(ang)*sp*T*.6+h*.85*T*T+Math.sin(T*9+i)*3*s;px+=Math.sin(T*6+i)*6*s}
  if(kd!=='f'&&kd!=='k'&&kd!=='e'&&py>y-sz*.45)py=y-sz*.45;
  c.globalAlpha=ga*fade;
  if(kd==='f'){c.globalAlpha=ga*fade*(1-k)*.6;c.fillStyle=v==='foundry'?(i%2?'#5a5262':'#3a3440'):v==='storm'?(i%2?'#dfeaff':'#9ab0d8'):(i%2?'#ffffff':'#e4f0ea');c.beginPath();c.arc(px,py,sz,0,RPMT);c.fill();continue}
  if(kd==='k'||kd==='e'){c.save();c.globalCompositeOperation='lighter';c.fillStyle=kd==='e'?(i%2?V.gl:V.g2):(i%2?V.gl:'#fff6c0');c.beginPath();c.arc(px,py,sz*(1-k*.5),0,RPMT);c.fill();c.restore();continue}
  const spr=rpw3mDeb(v,kd),rot=(r1*6+T*(8+r2*12)*(kd==='g'||kd==='h'?1.6:1))*(r3>.5?1:-1);c.save();c.translate(px,py);c.rotate(rot);c.drawImage(spr,-sz,-sz,sz*2,sz*2);c.restore()}
 c.globalAlpha=ga}
{const d0=rpMobDeath;rpMobDeath=function(c,id,x,y,k,o){if(RPW_MOBS[id]!==3)return d0.apply(this,arguments);try{rpw3mDeath(c,id,x,y,k,o)}catch(e){console.error(e)}}}
/* the battle code reads RP_FOE[e.id] (kills, heals): the poses share the Titan's stats object unless the core sets its own */
if(!RP_FOE.titan_p2)RP_FOE.titan_p2=RP_FOE.titan;if(!RP_FOE.titan_p3)RP_FOE.titan_p3=RP_FOE.titan;
/* a battle start prebakes every RPMOB id in the map's variant (95e): a World 3 sprite is only baked ahead for a World 3 variant
   (elsewhere it never walks; rpMobBlit would still bake it lazily). Filters the list too, so it composes with other wrappers. */
{const p0=rpMobPrebake;rpMobPrebake=function(ids,v){if(!RPW_VARS[3].includes(v))ids=(ids||Object.keys(RPMOB)).filter(id=>RPW_MOBS[id]!==3);return p0.call(this,ids,v)}}
/* ---------- variants: these ids draw straight in their variant (98a's rpvV already maps the map to one of the three) ---------- */
{const d0=rpvDraw;rpvDraw=function(g,id,ph,v){if(RPW_MOBS[id]!==3)return d0.apply(this,arguments);const f=RPMD[id];if(!f)return;ph=+ph||0;ph-=Math.floor(ph);
 g.save();g.lineJoin='round';g.lineCap='round';const k=RPMK[id]||1;g.scale(k,k);try{f(g,ph,{v:rpw3mV(v)})}finally{g.restore()}}}
