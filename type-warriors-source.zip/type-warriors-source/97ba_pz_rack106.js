/* ===== 10.6 THE CROOKED CUE: the Cue Rack's ball tab with fourteen sets (97ba, prefix pzr6, after 97b9) =====
   96zj lays the ball sets out as one flex row of eight cards. With the six premium sets (97b7-97b9) there are fourteen, so the
   strip scrolls: cards keep their size, arrows at both ends (and the mouse wheel or a swipe) move it, the selected card is
   scrolled into view when the tab opens, and premium sets (price 15,000 and up) carry a small gold PREMIUM mark. */
/* the premium sets were registered by three modules (97b7-97b9); list them cheapest first after the older sets */
{const pr=PZ_BALLS.filter(b=>b.prem).sort((a,b)=>a.price-b.price);for(const b of pr)PZ_BALLS.splice(PZ_BALLS.indexOf(b),1);PZ_BALLS.push(...pr)}
{const st=document.createElement('style');st.textContent=`
.pzkbstrip{overflow-x:auto;overflow-y:hidden;scroll-behavior:smooth;scrollbar-width:none;padding:6px 2px 0}
.pzkbstrip::-webkit-scrollbar{display:none}
.pzrk97 .pzkbc{flex:0 0 172px;max-width:none}
.pzkbc b{overflow:hidden;text-overflow:ellipsis;max-width:100%}
.pzkbc.prem b{font-size:19px}
.pzkbc.prem::before{content:'PREMIUM';position:absolute;left:50%;top:-9px;transform:translateX(-50%);padding:2px 8px;border-radius:9px;background:linear-gradient(180deg,#ffe27a,#d69a1e);color:#3a2204;font:800 10px/1.3 Poppins,sans-serif;letter-spacing:.09em;border:2px solid #12081f;z-index:2;pointer-events:none}
.pzkbnav{position:absolute;top:50%;width:40px;height:84px;margin-top:-42px;border-radius:14px;border:3px solid #12081f;background:linear-gradient(180deg,#ffe27a,#d69a1e);color:#3a2204;font:800 38px/1 Poppins,sans-serif;cursor:pointer;z-index:5;display:none;align-items:center;justify-content:center;box-shadow:0 6px 16px #0009;transition:transform .15s}
.pzkbnav.l{left:-10px}.pzkbnav.r{right:-10px}.pzkbnav:hover{transform:scale(1.08)}.pzkbnav.on{display:flex}
`;document.head.appendChild(st)}
function pzr6Nav(){const w=$('pzkwall'),s=w&&w.querySelector('.pzkbstrip');if(!w||!s)return;
 let l=w.querySelector('.pzkbnav.l'),r=w.querySelector('.pzkbnav.r');
 if(!l){l=document.createElement('button');l.className='pzkbnav l';l.setAttribute('aria-label','Scroll left');l.textContent='‹';l.onclick=()=>{s.scrollBy({left:-(s.clientWidth-190),behavior:'smooth'});pzFx&&pzFx('tick')};w.appendChild(l);
  r=document.createElement('button');r.className='pzkbnav r';r.setAttribute('aria-label','Scroll right');r.textContent='›';r.onclick=()=>{s.scrollBy({left:s.clientWidth-190,behavior:'smooth'});pzFx&&pzFx('tick')};w.appendChild(r)}
 const upd=()=>{const max=s.scrollWidth-s.clientWidth;l.classList.toggle('on',max>4&&s.scrollLeft>4);r.classList.toggle('on',max>4&&s.scrollLeft<max-4)};
 s.onscroll=upd;s.onwheel=e=>{if(s.scrollWidth<=s.clientWidth+4)return;const dx=Math.abs(e.deltaX)>Math.abs(e.deltaY)?e.deltaX:e.deltaY;s.scrollLeft+=dx;e.preventDefault()};
 upd();return upd}
{const f0=pzRk97Wall;pzRk97Wall=function(){const r=f0.apply(this,arguments);try{if(PZ.rackTab==='balls'){const w=$('pzkwall'),s=w&&w.querySelector('.pzkbstrip');
  if(s){s.querySelectorAll('.pzkbc').forEach(b=>{const it=PZ_BALLS.find(x=>x.id===b.dataset.i);if(it&&it.prem)b.classList.add('prem')});
   /* the selected card (the equipped set when the tab opens) is brought into view without animation */
   const sel=s.querySelector('.pzkbc.sel');if(sel){const keep=s.style.scrollBehavior;s.style.scrollBehavior='auto';const a=sel.offsetLeft-s.offsetLeft,vis0=s.scrollLeft,vis1=s.scrollLeft+s.clientWidth;if(a<vis0||a+sel.offsetWidth>vis1)s.scrollLeft=Math.max(0,a-(s.clientWidth-sel.offsetWidth)/2);s.style.scrollBehavior=keep}
   const upd=pzr6Nav();if(upd)setTimeout(upd,60)}}}catch(e){console.error(e)}return r}}
