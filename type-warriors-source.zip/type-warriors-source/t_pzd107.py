# python3 t_pzd107.py : 10.7 The Gilded Hoard, the third venue of The Crooked Cue (97bb data, 97bd venue, 97be hub; cast art 97bc):
# the data and ladder, the room's own money limits (stakes to 10,000 and pay to 50,000 here only, 5,000 / 15,000 everywhere else),
# the vault key in the tavern and Orbit 8 top bars (locked, NEW, V), venue switching and memory, the hub (medallions, spotlight,
# stakes, keys, no overlaps at three sizes), the room and table, the VS intro, shot flair, the AI style and house rules, paid
# matches against every player with the money checked, wise to you, the daily limit, resume / forfeit, results and rematch, the
# NEW VENUE card, The Regulars tab, felt unlocks, the cheat guard enforced (window.TW_AC_TEST) on a 50,000 win, the save normaliser,
# frame cost and no page errors.
import asyncio,os,sys,json,re
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 and not sys.argv[1].startswith('-') else os.path.join(HERE,'out.html'))
SHOTS=os.path.join(HERE,'shots','w107_pzdv');os.makedirs(SHOTS,exist_ok=True)
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:700]),flush=True)
    if not ok:FAIL.append(name)
PRE="()=>{RS_ASK=false;PZ_TUT_OFF=true;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}P.gold=100000;P.pz=null;for(const a of ACH)P.ach[a.id]=P.ach[a.id]||1;save()}"
HELP=r"""window.pzAuto=function(o){o=o||{};const me=Object.assign({sig:.9,psig:.05,pos:.4,safe:.3,sTry:12,look:5},o.me||{});PZ.speed=o.speed||6;const log={shots:0};
 const iv=setInterval(()=>{try{if(!PZ.on||!PZ.st)return;if(PZ.ph==='aim'&&!PZ.modal){const st=PZ.st;if(PZ.mode==='place'){pzaPlace(st,me);const c=PZ.B[0];const p=pzpNearestPlace(PZ.B,c.x,c.y,st.kitchen||st.brk);pzPlaceCue(p.x,p.y);return}
   if(PZ.mode==='aim'&&!PZ.shotFired){let d;if(st.brk){d=pzaBreak(st,me,Math.random);PZ.B[0].x=d.x||PZ.B[0].x}else d=pzaDecide(st,me,Math.random,{});const n=pzaNoise(d,me,Math.random,1);PZ.aim.ang=PZ.cueAng=n.ang;PZ.aim.pow=n.pow;PZ.aim.a=n.a;PZ.aim.b=n.b;if(pzrOn8(st)&&d.id===8){PZ.call=d.k;PZ.callManual=true}pzFireHuman();log.shots++}}}catch(e){log.err=String(e)}},60);log.stop=()=>clearInterval(iv);return log};
window.pzPix=(cv,x,y)=>Array.from(cv.getContext('2d').getImageData(x,y,1,1).data);
window.pzPainted=(cv)=>{const d=cv.getContext('2d').getImageData(0,0,cv.width,cv.height).data;let n=0,h=0;for(let i=3;i<d.length;i+=16){if(d[i]>40){n++;h=(h*31+d[i-3]*7+d[i-2]*3+d[i-1])|0}}return [n,h]};
/* the game's own loop settles a match: only state is set here, the money moves inside pzEndStep -> pzMatchEnd */
window.pzdForceEnd=function(win,o){o=o||{};const M=PZ.M;M.score=win?[M.race,0]:[0,M.race];if(o.bnr!=null)M.bnr=o.bnr;if(o.golden!=null)M.golden=o.golden;M.over={winner:win?0:1};PZ.ph='endhold';PZ.pht=0;PZ.endT=0;PZ.offer=false};
/* overlap audit of the hub at any size: medallions, plates, tags vs the panels; the top bar; text inside its box */
window.pzdAudit=function(){const hit=(a,c)=>a.left<c.right-1&&c.left<a.right-1&&a.top<c.bottom-1&&c.top<a.bottom-1,inside=(a,c)=>a.left>=c.left-1&&a.right<=c.right+1&&a.top>=c.top-1&&a.bottom<=c.bottom+1;const bad=[];
 const R=s=>{const e=document.querySelector(s);return e?e.getBoundingClientRect():null};const bar=R('#pz97bar'),opp=R('#pzopp'),nav=R('.pznav');
 const ms=[...document.querySelectorAll('.pz97md')].map(b=>({k:b.dataset.k,m:b.querySelector('.pz97m').getBoundingClientRect(),n:b.querySelector('.pz97nm').getBoundingClientRect(),t:(b.querySelector('.pz97tag')||b.querySelector('.pz97nm')).getBoundingClientRect()}));
 ms.forEach((a,i)=>{for(const z of[a.m,a.n,a.t]){if(hit(z,bar)||hit(z,opp)||hit(z,nav))bad.push(['panel',a.k])}ms.forEach((c,j)=>{if(j>i&&(hit(a.n,c.n)||hit(a.m,c.n)||hit(a.n,c.m)||hit(a.m,c.m)||hit(a.t,c.m)||hit(a.m,c.t)))bad.push(['med',a.k,c.k])})});
 const top=[...document.querySelectorAll('.pzback,.pzgold,.pzd8sign span,.pzd8emb,.pzprog,.pznet,#pzd8o8,#pzd8key,#pzn8tk,.pzsign span,.pzn8sign span')].map(e=>[e.className||e.id||('in '+e.parentNode.className),e.getBoundingClientRect()]).filter(x=>x[1].width>0);
 top.forEach((a,i)=>top.forEach((c,j)=>{if(j>i&&hit(a[1],c[1]))bad.push(['top',a[0],c[0]])}));
 const vw=document.getElementById('wrap').getBoundingClientRect();for(const [n,r] of top)if(!/sign|emb/.test(n)&&!inside(r,vw))bad.push(['off-stage',n]);
 /* text stays inside its box */
 for(const [box,sel] of[['.pznav button','.pznt b,.pznt>span'],['#pzopp','.pzh3,.pzsub2,.pzrew b,.pzrew span,.pzpay9,.pzfacts small,.pz97hr span'],['#pz97bar','.pz97lab,.pz97num b,.pz97num small,#pz97pt'],['#pzd8key','b,small'],['#pzd8o8','b,small'],['.pzprog','b'],['#pzrackem','#pz97pt'],['#pzprac','b,span']])
  for(const B of document.querySelectorAll(box)){const br=B.getBoundingClientRect();for(const e of B.querySelectorAll(sel)){const r=e.getBoundingClientRect();if(r.width&&!inside(r,br))bad.push(['text out',box,e.textContent.slice(0,30)]);const cs=getComputedStyle(e);if(e.scrollWidth>e.clientWidth+2&&cs.overflow!=='visible'&&cs.textOverflow!=='ellipsis')bad.push(['clipped',box,e.textContent.slice(0,30)])}}
 return bad};0"""
IDS=['clasp','zephyra','brass','hornsby','aurelion']
PLAN={'clasp':([2500,5000],2.0,{}),'zephyra':([2500,7500],2.6,{'winnerBreaks':1}),'brass':([5000,7500],3.3,{'shortGuide':1}),'hornsby':([5000,10000],4.0,{'clock':30}),'aurelion':([5000,10000],5.0,{'proGuide':1})}
async def newpage(b,vw=1600,vh=900,init=None):
    ctx=await b.new_context(viewport={'width':vw,'height':vh})
    await ctx.add_init_script("window.TWA_RELAYS=[];")
    if init:await ctx.add_init_script(init)
    pg=await ctx.new_page();er=[]
    pg.on('pageerror',lambda e:er.append(str(e)[:300]))
    pg.on('console',lambda m:er.append('console:'+m.text[:300]) if m.type=='error' and 'ERR_' not in m.text and 'WebSocket' not in m.text else None)
    await pg.goto(H);await pg.wait_for_timeout(1500);await pg.evaluate(PRE);await pg.evaluate(HELP)
    return ctx,pg,pg.evaluate,er
async def main():
    # ------------------------------------------------------------ code hygiene and registration
    mods=['97bb_pzd_data.js','97bd_pzd_venue.js','97be_pzd_hub.js']
    chk('the three venue modules exist (97bb data, 97bd venue, 97be hub) with the cast 97bc between',all(os.path.exists(os.path.join(HERE,m)) for m in mods+['97bc_pzd_cast.js']))
    bad=[]
    for m in mods:
        s=re.sub(r'/\*.*?\*/','',open(os.path.join(HERE,m),encoding='utf8').read(),flags=re.S)
        for pat in [r'\bbackdrop-filter\b',r'\b\d+(\.\d+)?v[wh]\b',r'@media[^{]*(min|max)-(width|height)',r'soft-light',r'mix-blend-mode\s*:\s*screen',r'\.shadowBlur\s*=',r'ctx\.filter',r'\.filter\s*=\s*[\'"`]',r"globalCompositeOperation\s*=\s*['\"]screen",r'claude-|opus|sonnet',r'localStorage']:
            if re.search(pat,s,re.I if pat.startswith('claude') else 0):bad.append((m,pat))
        for t in re.findall(r'^(?:function|const|let)\s+([A-Za-z_$][\w$]*)',s,re.M):
            if not re.match(r'^(pzd|PZD)',t) and t not in('pzMultS','pzStakeOf','pzStart','pzExtend','pzMatchEnd','pzHubOpp','pzCl01'):bad.append((m,'name',t))
    chk('no backdrop-filter, vw/vh, viewport media queries, soft-light/screen blends, shadowBlur, ctx.filter, model ids or localStorage; every new top-level name starts with pzd (bar the re-declared money functions)',not bad,bad)
    for f in ['build.sh','build_ast3.sh']:
        s=open(os.path.join(HERE,f)).read();i=[s.find(' '+m+' ') for m in ['97ba_pz_rack106.js','97bb_pzd_data.js','97bc_pzd_cast.js','97bd_pzd_venue.js','97be_pzd_hub.js']]
        chk(f'{f}: 97bb, 97bc, 97bd, 97be registered once each, in order, after 97ba_pz_rack106.js',all(x>0 for x in i) and i==sorted(i) and all(s.count(' '+m+' ')==1 for m in mods),i)
    async with async_playwright() as p:
        b=await p.chromium.launch()
        ctx,pg,E,er=await newpage(b)
        # ------------------------------------------------------------ data and ladder
        r=await E("""()=>PZD_ORDER.map(k=>{const R=PZ_REG[k];return {k,venue:R.venue,st:R.stakes,m:R.mult,f:R.floor,race:R.race,house:R.house,sig:R.ai.sig,cue:!!PZD_CUES[R.cue]&&!PZ_CUES.some(c=>c.id===R.cue),think:!!PZ_THINK[k],h:PZ_MONH[k],tip:!!PZ_TIPS[k],plate:!!PZ97_PLATE[k],hs:!!PZ97_HOUSE[k],sh:!!PZ_SHORT[k],lvl:R.lvl,
          lines:['hi','pot','miss','you','foul','win','lose','taunted'].every(x=>R.lines[x]&&R.lines[x].length),taunts:R.taunts.length>=3&&R.taunts.every(t=>t.length<=24),quirk:!!R.quirk,voice:!!R.voice,draw:typeof pzMon[k]==='function'}})""")
        st={x['k']:x for x in r}
        chk('five Hoard players in ladder order (Clasp, Zephyra, Sir Brassknuckle, Baron Hornsby, Aurelion) in PZ_REG with venue hoard',[x['k'] for x in r]==IDS and all(x['venue']=='hoard' for x in r),r)
        chk('stakes and multipliers exactly as planned (2,500-5,000 x2.0; 2,500-7,500 x2.6; 5,000-7,500 x3.3; 5,000-10,000 x4.0; 5,000-10,000 x5.0), floors below, races 2-3',
            all(min(st[k]['st'])==PLAN[k][0][0] and max(st[k]['st'])==PLAN[k][0][1] and abs(st[k]['m']-PLAN[k][1])<1e-9 and 1<st[k]['f']<st[k]['m'] and 2<=st[k]['race']<=3 for k in IDS),r)
        chk('house rules reuse the existing ones: none, winner breaks, short guide, a 30 s clock, aim line only',all(st[k]['house']==PLAN[k][2] for k in IDS),[st[k]['house'] for k in IDS])
        chk('each one has lines, taunts, a quirk, a voice, a think routine, a height, a tip, a plate, house text, a short name, a match cue (not in the Cue Rack) and a drawer',all(x['lines'] and x['taunts'] and x['quirk'] and x['voice'] and x['think'] and x['h'] and x['tip'] and x['plate'] and x['hs'] and x['sh'] and x['cue'] and x['draw'] and 1<=x['lvl']<=7 for x in r),r)
        chk('the ladder gets harder: aim error falls from Clasp to Aurelion',all(r[i]['sig']>r[i+1]['sig'] for i in range(4)),[x['sig'] for x in r])
        r=await E("()=>({tav:PZ_ORDER.join(),o8:PZN_ORDER.join(),reg:Object.values(PZ_REG).filter(R=>R.venue==='hoard').length,sp:pzCueSprite('pzd_aurelion').width===pzCueSprite('house').width,inRack:PZ_CUES.some(c=>/^pzd_/.test(c.id))})")
        chk('the tavern and Orbit 8 ladders are untouched and the match cues build sprites without joining the Cue Rack',r['tav']=='gloop,moldwick,grizzle,vesper,barnacle,hootsworth,mortimer' and r['o8']=='bleep,octavia,facet,rex,vantara' and r['reg']==5 and r['sp'] and not r['inRack'],r)
        # ------------------------------------------------------------ money limits per room
        r=await E("""()=>({cap:[PZ_CAP,PZD_CAP,PZD_STAKE],cas:['pz','bj','hl','tw','sl','pl'].map(id=>casCap(id)),sc:['clasp','aurelion','mortimer','vantara','shade'].map(pzdStakeCap),
          ms:[pzMultS('aurelion',10000),pzMultS('hornsby',10000),pzMultS('mortimer',5000),pzMultS('vantara',5000),pzMultS('aurelion',12500)],
          so:['clasp','zephyra','brass','hornsby','aurelion','mortimer'].map(k=>{PZ.stk={};return pzStakeOf(k)}),maxPay:PZD_ORDER.map(k=>Math.max(...PZ_REG[k].stakes.map(s=>Math.round(s*pzMultS(k,s)))))})""")
        chk('limits: tavern / Orbit 8 keep 5,000 stakes and a 15,000 ceiling; the Hoard takes 10,000 and pays up to 50,000; other casino games keep their limits',r['cap']==[15000,50000,10000] and r['cas']==[5000,7500,7500,7500,5000,5000] and r['sc']==[10000,10000,5000,5000,5000],r)
        chk('the multiplier shrinks to fit each room\'s ceiling: 10,000 x5.0 = 50,000 pays in full, Mortimer at 5,000 still shrinks to x3, a stake above the plan shrinks Aurelion to x4',r['ms']==[5,4,3,3,4] and max(r['maxPay'])==50000,r)
        r=await E("""()=>{const out={};P.gold=100000;const Z=PZS();Z.beat={mortimer:1};Z.live=null;save();
          out.hi=pzStart({opp:'aurelion',stake:12000,seed:1});out.g1=P.gold;out.tav=pzStart({opp:'mortimer',stake:7500,seed:1});out.o8=pzStart({opp:'vantara',stake:7500,seed:1});out.g2=P.gold;
          out.ok=pzStart({opp:'hornsby',stake:10000,seed:4});const L=PZS().live;out.g3=P.gold;out.live=L&&[L.opp,L.stake,L.mult,pzLiveOk(L)];out.keep=!!PZS().live;out.dayN=PZS().dayN;return out}""")
        chk('pzStart refuses 12,000 in the Hoard and 7,500 at Mortimer / Vantara (gold untouched); 10,000 against Hornsby takes the stake and stores a valid live match',
            r['hi'] is False and r['tav'] is False and r['o8'] is False and r['g1']==100000 and r['g2']==100000 and r['ok'] and r['g3']==90000 and r['live']==['hornsby',10000,4,True] and r['keep'] and r['dayN']==1,r)
        await pg.wait_for_timeout(600);await E("()=>{const i=document.getElementById('pzintro');if(i)i.click()}");await pg.wait_for_timeout(1400)
        r=await E("""()=>{const cv=PZ.cv,G=PZ_G,P0=PZ_POCK[1];return {pzd:PZ.pzd,bk:PZ.bk===PZD.bk,cls:document.getElementById('pzm').classList.contains('pzd8m'),felt:pzPix(cv,G.x+300,G.y+330),ring:pzPix(PZD.bk,Math.round(G.x+P0[0]+P0[2]+5),Math.round(G.y+P0[1])),door:pzPix(PZD.bk,160,372-148-14),hoard:pzPix(PZD.bk,1470,420),clock:pzClockMax(),av:pzPainted(document.getElementById('pzavo'))[0]}}""")
        chk('a Hoard match uses the vault room and table (its own bake), the HUD portrait is painted',r['pzd'] and r['bk'] and r['cls'] and r['av']>500,r)
        f=r['felt'];rg=r['ring'];d=r['door'];hd=r['hoard']
        chk('table colours: a crimson felt, ruby-lit pockets, a gold vault door rim and a gold hoard',f[0]>f[1]+50 and f[0]>f[2]+30 and rg[0]>180 and rg[1]<140 and d[0]>150 and d[1]>90 and d[2]<d[1] and hd[0]>120 and hd[0]>hd[2]+60 and hd[2]<hd[1],r)
        chk('Hornsby\'s house rule: a 30-second shot clock',r['clock']==30,r)
        await pg.screenshot(path=os.path.join(SHOTS,'t_room_hornsby.png'))
        r=await E("""()=>{const t=[];for(let i=0;i<3;i++)pzFrame(PZ.g);for(let i=0;i<40;i++){const a=performance.now();pzFrame(PZ.g);t.push(performance.now()-a)}t.sort((x,y)=>x-y);return [t[20],t[36]]}""")
        chk(f'frame cost at rest on the Hoard table is small (median {r[0]:.2f} ms, p90 {r[1]:.2f} ms; under 4 / 9 ms like Orbit 8)',r[0]<4 and r[1]<9,r);rest=r
        r=await E("""()=>{const c=document.createElement('canvas');c.width=1600;c.height=900;const g=c.getContext('2d');const run=()=>{const t=[];for(let i=0;i<40;i++){const a=performance.now();pzDrawLamp(g,i*.1);pzDrawLights(g,i*.1);pzDrawDust(g,i*.1);t.push(performance.now()-a)}t.sort((x,y)=>x-y);return t[20]};run();const me=run();
          PZ.pzd=false;run();const tav=run();PZ.pzd=true;
          const cnt={n:0};const g2=new Proxy(g,{get(o,k){const v=o[k];if(typeof v==='function')return (...a)=>{cnt.n++;return v.apply(o,a)};return v},set(o,k,v){o[k]=v;return true}});document.body.classList.add('pf-low');PZ_RMC.t=-1e9;pzDrawLights(g2,1);pzDrawDust(g2,1);const low=cnt.n;document.body.classList.remove('pf-low');PZ_RMC.t=-1e9;return {med:me,tav,extra:me-tav,low}}""")
        chk(f'the vault ambience (chandelier, glints, lanterns, the sliding coin, glitter) costs {r["med"]:.2f} ms a frame ({r["extra"]:+.2f} ms against the tavern lamp, lights and dust); Performance mode draws none of it',r['med']<1.2 and r['extra']<1 and r['low']==0,r);amb=r
        await E("()=>{PZ.lite=true}");await pg.wait_for_timeout(200)
        r=await E("()=>{let n=0;const f0=pzdDrawMotes;pzdDrawMotes=function(){n++;return f0.apply(this,arguments)};let k=0;const f1=pzdCoin;window.pzdCoin=function(){k++;return f1.apply(this,arguments)};for(let i=0;i<5;i++)pzRender(PZ.g);pzdDrawMotes=f0;window.pzdCoin=f1;return [n,k]}")
        chk('lite mode skips the glitter and the sliding coin',r[1]==0,r)
        await E("()=>{PZ.lite=false}")
        g0=await E("()=>P.gold")
        await E("()=>pzForfeit()");await pg.wait_for_timeout(900)
        r=await E("()=>({gold:P.gold,live:PZS().live,loss:PZS().losses,res:!!document.querySelector('.pzres9.pzd8r'),bar:(document.getElementById('pzbb')||{}).textContent||''})")
        chk('forfeiting a 10,000 match keeps the stake, counts the loss once and shows the vault results',r['gold']==g0 and not r['live'] and r['loss']==1 and r['res'] and 'vault' in r['bar'],r)
        # ------------------------------------------------------------ shot flair, AI style, house rules
        r=await E("""()=>{const out={};for(const id of PZD_ORDER){PZ.reg=PZ_REG[id];PZ.pzd=true;PZD.fx=[];PZ.fx=[];PZ.shot={ang:0,pow:.6};pzdShotFx();out[id]=PZD.fx.length+PZ.fx.length}PZ.pzd=false;return out}""")
        chk('shot flair: every one strikes in their own way (coins, smoke rings, steam, a snort, dragon fire)',all(v>0 for v in r.values()),r)
        r=await E("""()=>{const rng=pzRng(4);const B=pzpRack(rng).sort((a,b)=>a.id-b.id);const st=pzrNew(B,0,{});st.brk=false;st.open=false;st.grp=['t','s'];st.turn=1;const g=pzGrp(9)==='t'?'t':'s';st.grp=[g==='t'?'s':'t',g];
          const m0=pzdAiK(Object.assign({},PZ_REG.aurelion.ai),st).sig;let n=0;for(const b of B)if(b.id&&b.id!==8&&pzGrp(b.id)===g&&n<6){b.on=false;n++}const m6=pzdAiK(Object.assign({},PZ_REG.aurelion.ai),st).sig;
          const hb=pzdAiK(Object.assign({},PZ_REG.hornsby.ai),st).sig;st.brk=true;const mb=pzdAiK(Object.assign({},PZ_REG.aurelion.ai),st).sig;return {m0,m6,hb,mb,base:PZ_REG.aurelion.ai.sig}}""")
        chk('Aurelion\'s gild: his aim tightens as his own balls go down (x0.76 with one left), never on the break, and nobody else has it',abs(r['m0']-r['base'])<1e-9 and abs(r['m6']/r['base']-.76)<.001 and abs(r['mb']-r['base'])<1e-9 and abs(r['hb']-PZ_REG_H)<1e-9 if (PZ_REG_H:=await E("()=>PZ_REG.hornsby.ai.sig")) is not None else False,r)
        r=await E("()=>{const Z=PZS();Z.guide='full';const o=[];for(const k of['aurelion','brass','clasp','hornsby','zephyra']){PZ.reg=PZ_REG[k];o.push(pzGuideMode())}return o}")
        chk('house rules in play: Aurelion shows the aim line only, Brassknuckle the short guide, the others the full guide',r==['pro','short','full','full','full'],r)
        # ------------------------------------------------------------ the way in: locked, then NEW, from both hubs
        await E("()=>{P.pz=null;const Z=PZS();Z.beat={gloop:1,moldwick:1,grizzle:1,vesper:1,barnacle:1,hootsworth:1};Z.o8.seen=1;save();PZ.sel=null;PZ.shadeHere=false;PZ.shadeChecked=pzDay();casinoOpen();gameOpen('pz')}");await pg.wait_for_timeout(1500)
        r=await E("()=>{const t=document.getElementById('pzd8key');return {t:!!t,lock:t&&t.classList.contains('lock'),txt:t&&t.textContent,venue:PZS().venue,aud:pzdAudit()}}")
        chk('tavern hub: a vault key sits in the top bar, locked until Mortimer or Vantara is beaten (it says so) and it overlaps nothing',r['t'] and r['lock'] and 'Mortimer' in r['txt'] and 'Vantara' in r['txt'] and r['venue']=='tavern' and not [x for x in r['aud'] if x[0] in('top','off-stage')],r)
        await pg.click('#pzd8key');await pg.wait_for_timeout(400);await pg.keyboard.press('v');await pg.wait_for_timeout(500)
        chk('a locked key and the V key stay in the tavern (with a note)',await E("()=>!!document.querySelector('#pzh:not(.pzd8)')&&PZS().venue==='tavern'&&!!document.getElementById('pznote')"))
        await E("()=>{const Z=PZS();Z.venue='o8';save();pzHub()}");await pg.wait_for_timeout(1300)
        r=await E("()=>{const t=document.getElementById('pzd8key');return {o8:!!document.querySelector('#pzh.pzn8'),t:!!t,lock:t&&t.classList.contains('lock'),aud:pzdAudit()}}")
        chk('Orbit 8 hub: the same key, locked, in its top bar, overlapping nothing',r['o8'] and r['t'] and r['lock'] and not [x for x in r['aud'] if x[0] in('top','off-stage')],r)
        await E("()=>{const Z=PZS();Z.beat={gloop:1,moldwick:1,grizzle:1,vantara:1};save();pzHub()}");await pg.wait_for_timeout(1200)
        r=await E("()=>{const t=document.getElementById('pzd8key');return {lock:t.classList.contains('lock'),nw:t.classList.contains('new'),badge:!!t.querySelector('.pzbdg'),open:pzdVenueOpen()}}")
        chk('beating Empress Vantara alone opens the key in Orbit 8, marked NEW',not r['lock'] and r['nw'] and r['badge'] and r['open'],r)
        await E("()=>{const Z=PZS();Z.beat={gloop:1,moldwick:1,grizzle:1,mortimer:1};Z.venue='tavern';save();pzHub()}");await pg.wait_for_timeout(1200)
        r=await E("()=>{const t=document.getElementById('pzd8key');return {tav:!!document.querySelector('#pzh:not(.pzn8):not(.pzd8)'),lock:t.classList.contains('lock'),nw:t.classList.contains('new')}}")
        chk('beating Mortimer opens it in the tavern too, marked NEW',r['tav'] and not r['lock'] and r['nw'],r)
        await pg.keyboard.press('v');await pg.wait_for_timeout(1700)
        M="""()=>[...document.querySelectorAll('.pz97md')].map(b=>({k:b.dataset.k,sel:b.classList.contains('sel'),next:b.classList.contains('next'),lock:b.classList.contains('lock'),dis:b.disabled,nm:b.querySelector('.pz97nm').textContent,painted:pzPainted(b.querySelector('canvas'))[0]>300}))"""
        m=await E(M);sm={x['k']:x for x in m}
        r=await E("()=>({h:!!document.querySelector('#pzh.pzd8'),venue:PZS().venue,seen:PZS().hoard.seen,title:document.querySelector('.pzd8sign').textContent,sel:PZ.sel,music:pzdVenueNow()})")
        chk('V opens the Gilded Hoard hub; the venue is remembered, the first visit counted and the vault music is on',r['h'] and r['venue']=='hoard' and r['seen']==1 and 'Gilded Hoard' in r['title'] and r['music'],r)
        chk('Hoard hub: five medallions in ladder order, every portrait painted; Clasp open, next and picked; the rest locked "? ? ?"',[x['k'] for x in m]==IDS and all(x['painted'] for x in m) and sm['clasp']['next'] and sm['clasp']['sel'] and all(sm[k]['lock'] and sm[k]['dis'] and sm[k]['nm']=='? ? ?' for k in IDS[1:]),m)
        r=await E("()=>pzdAudit()")
        chk('Hoard hub at 1600 x 900: medallions, plates and tags clear of the panels and each other, the top bar items apart, text inside its boxes',r==[],r)
        r=await E("()=>({name:document.querySelector('.pzoppi .pzh3').textContent,chips:[...document.querySelectorAll('.pz97ch')].map(x=>+x.dataset.s),play:document.getElementById('pzrackem').textContent,prac:document.getElementById('pzpracs').textContent,ret:document.getElementById('pz97ret').textContent,stake:pzStakeOf('clasp'),mult:pzMultS('clasp',pzStakeOf('clasp')),rew:(document.querySelector('.pzd8rew')||{}).textContent||'',stage:pzPainted(document.querySelector('#pzopp .pzstbg'))[0]})")
        chk('spotlight and stake bar: Clasp, his chips 2,500-5,000, Play • N coins, Practice vs Clasp, total return, the first-win line and a gold stage',r['name']=='Clasp' and r['chips']==[2500,3000,4000,5000] and f"{r['stake']:,} coins" in r['play'] and r['prac']=='free vs Clasp' and r['ret']==f"{round(r['stake']*r['mult']):,}" and '+600' in r['rew'] and r['stage']>1000,r)
        await pg.screenshot(path=os.path.join(SHOTS,'t_hub_first.png'))
        await pg.click('.pz97md[data-k=zephyra]',force=True);await pg.wait_for_timeout(300)
        chk('a locked Hoard medallion cannot be picked',await E("()=>PZ.sel")=='clasp')
        # ------------------------------------------------------------ keys, stakes to 10,000 and remembering the room
        await E("()=>{const Z=PZS();Z.beat=Object.assign(Z.beat,{clasp:1,zephyra:1,brass:1});save();pzHub()}");await pg.wait_for_timeout(1300)
        await pg.keyboard.press('2');await pg.wait_for_timeout(300);k1=await E("()=>PZ.sel")
        await pg.keyboard.press('5');await pg.wait_for_timeout(300);k2=await E("()=>PZ.sel")
        await pg.keyboard.press('4');await pg.wait_for_timeout(300);k3=await E("()=>PZ.sel")
        s0=await E("()=>pzStakeOf(PZ.sel)");await pg.keyboard.press('ArrowRight');await pg.wait_for_timeout(300);await pg.keyboard.press('ArrowRight');await pg.wait_for_timeout(400);s1=await E("()=>pzStakeOf(PZ.sel)")
        r=await E("()=>({chips:[...document.querySelectorAll('.pz97ch')].map(x=>+x.dataset.s),ret:document.getElementById('pz97ret').textContent,pay:(document.getElementById('pzpayv')||{}).textContent,play:document.getElementById('pz97p2').textContent})")
        chk('Hoard keys: 2 picks Zephyra, a locked 5 does nothing, 4 picks Hornsby, right walks his chips up to 10,000 and the bar says 40,000',[k1,k2,k3]==['zephyra','zephyra','hornsby'] and s0==5000 and s1==10000 and r['chips']==[5000,7500,10000] and r['ret']=='40,000' and '10,000' in r['play'],[k1,k2,k3,s0,s1,r])
        await pg.screenshot(path=os.path.join(SHOTS,'t_hub_hornsby10k.png'))
        await pg.keyboard.press('o');await pg.wait_for_timeout(1200)
        r=await E("()=>({o8:!!document.querySelector('#pzh.pzn8'),venue:PZS().venue,key:!!document.getElementById('pzd8key')&&!document.getElementById('pzd8key').classList.contains('new'),sel:PZ.sel})")
        chk('O in the Hoard flies to Orbit 8 (an Orbit 8 player picked; the vault key there no longer NEW)',r['o8'] and r['venue']=='o8' and r['key'] and r['sel'] in IDS+['x'] or (r['o8'] and r['venue']=='o8' and r['key'] and r['sel'] in await E("()=>PZN_ORDER")),r)
        await pg.keyboard.press('v');await pg.wait_for_timeout(1200)
        chk('V from Orbit 8 goes back into the vault with Hornsby still picked',await E("()=>!!document.querySelector('#pzh.pzd8')&&PZ.sel==='hornsby'&&PZS().venue==='hoard'"))
        await E("()=>{lobby();casinoOpen();gameOpen('pz')}");await pg.wait_for_timeout(1300)
        chk('the casino tile opens the room you were last in (the Hoard)',await E("()=>!!document.querySelector('#pzh.pzd8')"))
        await pg.click('.pznav button[data-a=cues]');await pg.wait_for_timeout(1000);await pg.keyboard.press('Escape');await pg.wait_for_timeout(1200)
        chk('a side screen (the Cue Rack) comes back to the Hoard',await E("()=>!!document.querySelector('#pzh.pzd8')"))
        await pg.keyboard.press('Escape');await pg.wait_for_timeout(1200)
        r=await E("()=>({tav:!!document.querySelector('#pzh:not(.pzd8):not(.pzn8)'),venue:PZS().venue,sel:PZ.sel,ok:PZ_ORDER.includes(PZ.sel)||PZ.sel==='shade'})")
        chk('Esc in the Hoard goes down to the tavern with a tavern player picked',r['tav'] and r['venue']=='tavern' and r['ok'],r)
        # ------------------------------------------------------------ the VS intro
        await E("()=>{const Z=PZS();Z.venue='hoard';save();pzHub()}");await pg.wait_for_timeout(900)
        await E("()=>{pzStart({opp:'aurelion',practice:true,seed:3})}");await pg.wait_for_timeout(1500)
        r=await E("()=>({cls:document.getElementById('pzintro').className,q:(document.querySelector('.pzdvsq')||{}).textContent||'',pt:pzPainted(document.getElementById('pzvo'))[0],rain:!!document.querySelector('.pzdrain')})")
        chk('VS intro: the vault version with falling gold, the entrance on its own canvas and the opening line',('pzdvs' in r['cls']) and r['rain'] and r['pt']>2000 and 'coin' in r['q'],r)
        await pg.screenshot(path=os.path.join(SHOTS,'t_vs_aurelion.png'))
        await E("()=>document.getElementById('pzintro').click()");await pg.wait_for_timeout(1300)
        await E("()=>{PZ.aim.pow=.95;pzFireHuman()}");await pg.wait_for_timeout(600)
        r=await E("""()=>{const t=[];for(let i=0;i<3;i++)pzFrame(PZ.g);for(let i=0;i<40;i++){const a=performance.now();pzFrame(PZ.g);t.push(performance.now()-a)}t.sort((x,y)=>x-y);return [t[20],t[36]]}""")
        chk(f'break frame cost on the Hoard table (median {r[0]:.2f} ms, p90 {r[1]:.2f} ms; under 8 / 18 ms like t_pool)',r[0]<8 and r[1]<18,r);brk=r
        await E("()=>{pzForfeit()}");await pg.wait_for_timeout(600)
        # ------------------------------------------------------------ a whole paid match against Clasp, played out, the money checked
        await E("()=>{P.pz=null;P.gold=60000;const Z=PZS();Z.beat={mortimer:1};Z.venue='hoard';Z.hoard.seen=1;Z.mastPaid={house:10};save();PZ.sel=null;casinoOpen();gameOpen('pz')}");await pg.wait_for_timeout(1300)
        chk('a save that has beaten Mortimer opens the Hoard with Clasp picked',await E("()=>!!document.querySelector('#pzh.pzd8')&&PZ.sel==='clasp'"))
        g0=await E("()=>P.gold")
        await E("()=>{pzHubStake(2500);document.getElementById('pzrackem').click();window.__a=pzAuto({speed:8,me:{sig:.3,psig:.03,pos:.6,look:6}});setTimeout(()=>{const i=document.getElementById('pzintro');if(i)i.click()},400)}")
        r=await E("()=>({live:!!PZS().live,gold:P.gold,opp:PZ.M&&PZ.M.opp,stake:PZ.M&&PZ.M.stake,pzd:PZ.pzd})")
        chk('Play takes the 2,500 stake at once and starts Clasp on the vault table',r['live'] and r['gold']==g0-2500 and r['opp']=='clasp' and r['stake']==2500 and r['pzd'],r)
        done=False
        for i in range(300):
            await pg.wait_for_timeout(1000)
            if await E("()=>!!document.querySelector('.pzresc')"):done=True;break
        r=await E("()=>({res:PZ.result,gold:P.gold,err:__a.err||null,live:!!PZS().live,beat:PZS().beat.clasp|0,first:(PZS().first||{}).clasp|0,vs:pzVs().clasp||null})")
        await E("()=>{try{__a.stop()}catch(e){}}")
        chk('a whole match against Clasp runs to a result with no errors',done and not r['err'],r)
        if done:
            res=r['res'];exp=g0-2500+(res['pay']+600 if res['win'] else 0)
            chk('the money matches (a win pays stake x multiplier + bonus + the 600 first-win bonus; a loss keeps the stake), nothing left live',r['gold']==exp and (not res['win'] or res['pay']>=round(2500*res['mult'])) and not r['live'],(r,exp))
            chk('the record follows the result (beaten count, first-win flag, head to head)',(r['beat']==1 and r['first']==1) if res['win'] else (r['beat']==0 and r['vs'] and r['vs'][1]>=1),r)
            q=await E("()=>({h:!!document.querySelector('.pzres9.pzd8r'),bar:document.getElementById('pzbb').textContent,goal:(document.querySelector('.pzgoal')||{}).textContent||'',opened:PZ.result.opened,card:[...document.querySelectorAll('.pzun')].map(x=>x.textContent).join('|'),stage:pzPainted(document.querySelector('.pzrstage .pzstbg'))[0]})")
            if res['win']:chk('results after a first win: the vault backdrop, a NEW TABLE card for Zephyra, The vault button',q['h'] and q['opened']=='zephyra' and 'Zephyra' in q['card'] and 'vault' in q['bar'] and q['stage']>1000,q)
            else:chk('results after a loss: the vault backdrop, The vault button, a goal that points at Clasp',q['h'] and 'vault' in q['bar'] and 'Clasp' in q['goal'],q)
            await pg.screenshot(path=os.path.join(SHOTS,'t_results_clasp.png'))
            await pg.wait_for_timeout(800);await pg.keyboard.press('Escape');await pg.wait_for_timeout(1300)
            r2=await E("()=>({h:!!document.querySelector('#pzh.pzd8'),sel:PZ.sel})")
            chk('Esc from the results goes back to the Hoard hub',r2['h'] and r2['sel']==('zephyra' if res['win'] else 'clasp'),r2)
        # ------------------------------------------------------------ a paid match against each of the others (real shots, then the game's loop settles it)
        pays={}
        for k,stake,win,bonus in [('zephyra',7500,True,(1,0)),('brass',7500,False,(0,0)),('hornsby',10000,True,(0,0)),('aurelion',10000,True,(3,1))]:
            await E("(k)=>{P.pz=null;P.gold=60000;const Z=PZS();Z.beat={mortimer:1,clasp:1,zephyra:1,brass:1,hornsby:1};delete Z.beat[k];Z.first={zephyra:1,brass:1,hornsby:1,aurelion:1};Z.venue='hoard';Z.hoard.seen=1;Z.mastPaid={house:10};save();PZ.sel=k;casinoOpen();gameOpen('pz')}",k);await pg.wait_for_timeout(1100)
            await E("(s)=>{pzHubStake(s);document.getElementById('pzrackem').click();window.__a=pzAuto({speed:8});setTimeout(()=>{const i=document.getElementById('pzintro');if(i)i.click()},300)}",stake)
            g1=await E("()=>P.gold")
            for i in range(40):
                await pg.wait_for_timeout(250)
                if await E("()=>__a.shots>=3||!PZ.on"):break
            await E("()=>__a.stop()")
            for i in range(60):
                await pg.wait_for_timeout(200)
                if await E("()=>['aim','ai'].includes(PZ.ph)"):break
            await E("(o)=>pzdForceEnd(o[0],{bnr:o[1],golden:o[2]})",[win,bonus[0],bonus[1]]);await pg.wait_for_timeout(1500)
            r=await E("()=>({res:PZ.result,gold:P.gold,live:!!PZS().live,beat:PZS().beat})")
            res=r['res'] or {};bon=min(500*max(1,bonus[0]),round(stake*.1)*bonus[0])+(min(1000,round(stake*.25)*bonus[1]) if bonus[1] else 0)
            expPay=min(50000,round(stake*PLAN[k][1])+bon) if win else 0
            pays[k]=(res.get('pay'),expPay,g1,r['gold'])
            chk(f'a paid {stake:,} match against {k}: stake taken by Play, {"won" if win else "lost"} and settled by the game\'s own loop, gold {r["gold"]:,} = 60,000 - stake + {expPay:,}',
                g1==60000-stake and res.get('opp')==k and res.get('win')==win and res.get('pay')==expPay and r['gold']==60000-stake+expPay and not r['live'] and (r['beat'].get(k,0)==(1 if win else 0)),(res,r,expPay))
        chk('the top payout: Aurelion at 10,000 with break-and-run bonuses is capped at exactly 50,000 (the tavern ceiling would have been 15,000)',pays['aurelion'][0]==50000,pays)
        # ------------------------------------------------------------ wise to you, the daily limit
        r=await E("""()=>{const Z=PZS();Z.rep={};const a=pzMult('hornsby');Z.rep.hornsby=1;const b=pzMult('hornsby');Z.rep.hornsby=40;const c=pzMult('hornsby');Z.rep={};return [a,b,c]}""")
        chk('wise to you: Hornsby pays x4.0, x3.9 after a win today, never under his floor (x2.7)',r==[4,3.9,2.7],r)
        await E("()=>{P.pz=null;P.gold=60000;const Z=PZS();Z.beat={mortimer:1};Z.venue='hoard';Z.dayN=PZ_DAILY;save();PZ.sel='clasp';casinoOpen();gameOpen('pz')}");await pg.wait_for_timeout(1100)
        r=await E("()=>({p1:document.getElementById('pz97p1').textContent,warn:(document.querySelector('.pzpay9 .warn')||{}).textContent||''})")
        await E("()=>{document.getElementById('pzrackem').click()}");await pg.wait_for_timeout(500)
        q=await E("()=>({gold:P.gold,prac:PZ.M&&PZ.M.practice,stake:PZ.M&&PZ.M.stake,live:PZS().live})")
        chk('the 20 paid matches a day count here too: after 20 the Hoard plays a friendly with nothing taken',r['p1']=='Friendly' and 'Daily' in r['warn'] and q['gold']==60000 and q['prac'] and q['stake']==0,(r,q))
        await E("()=>{pzForfeit()}");await pg.wait_for_timeout(600)
        # ------------------------------------------------------------ resume mid-match and the rematch
        await E("()=>{P.pz=null;P.gold=60000;const Z=PZS();Z.beat={mortimer:1,clasp:1,zephyra:1,brass:1};Z.venue='hoard';save();casinoOpen();gameOpen('pz');pzStart({opp:'hornsby',stake:10000,seed:9})}");await pg.wait_for_timeout(500)
        await E("()=>document.getElementById('pzintro').click()");await pg.wait_for_timeout(1500)
        snap=await E("()=>{pzSave();return {gold:P.gold,opp:PZS().live&&PZS().live.opp,ok:pzLiveOk(PZS().live),stake:PZS().live&&PZS().live.stake}}")
        await pg.reload();await pg.wait_for_timeout(1500);await E(PRE.replace('P.gold=100000;P.pz=null;','').replace('save()','0'));await E(HELP)
        await E("()=>{casinoOpen();gameOpen('pz')}");await pg.wait_for_timeout(1200)
        r=await E("()=>({h:!!document.querySelector('#pzh.pzd8'),res:!!document.getElementById('pzresume'),gold:P.gold,live:PZS().live&&PZS().live.opp,tag:!!document.querySelector('.pz97md[data-k=hornsby] .pz97tag.live'),p1:document.getElementById('pz97p1').textContent})")
        chk('reload mid-match against Hornsby at 10,000: the stake stays taken, the Hoard hub offers Resume and his medallion shows LIVE',snap['ok'] and snap['opp']=='hornsby' and snap['stake']==10000 and r['h'] and r['res'] and r['gold']==snap['gold']==50000 and r['live']=='hornsby' and r['tag'] and r['p1']=='Resume',(snap,r))
        await pg.screenshot(path=os.path.join(SHOTS,'t_hub_resume.png'))
        await pg.click('#pzrs1');await pg.wait_for_timeout(1500)
        r=await E("()=>({pzd:PZ.pzd,opp:PZ.reg.id,stake:PZ.M.stake,mult:PZ.M.mult,bk:PZ.bk===PZD.bk})")
        chk('Resume puts you back on the vault table against Hornsby with the same 10,000 stake and x4',r['pzd'] and r['opp']=='hornsby' and r['stake']==10000 and r['mult']==4 and r['bk'],r)
        await E("()=>{pzdForceEnd(false)}");await pg.wait_for_timeout(1500)
        r=await E("()=>({gold:P.gold,res:!!document.getElementById('pzre')})")
        await pg.click('#pzre');await pg.wait_for_timeout(700)
        q=await E("()=>({gold:P.gold,opp:PZ.M&&PZ.M.opp,stake:PZ.M&&PZ.M.stake,live:PZS().live&&PZS().live.stake,venue:PZS().venue})")
        chk('Rematch from the results keeps the 10,000 stake in the Hoard (the casino\'s 5,000 limit does not apply here)',r['gold']==50000 and q['gold']==40000 and q['opp']=='hornsby' and q['stake']==10000 and q['live']==10000 and q['venue']=='hoard',(r,q))
        await E("()=>{const i=document.getElementById('pzintro');if(i)i.click()}");await pg.wait_for_timeout(800);await E("()=>pzForfeit()");await pg.wait_for_timeout(800)
        # ------------------------------------------------------------ the first Mortimer / Vantara win announces the vault
        for opp,venue in [('mortimer','tavern'),('vantara','o8')]:
            await E("(o)=>{P.pz=null;P.gold=60000;const Z=PZS();Z.beat={gloop:1,moldwick:1,grizzle:1,vesper:1,barnacle:1,hootsworth:1,bleep:1,octavia:1,facet:1,rex:1};Z.venue=o[1];save();casinoOpen();gameOpen('pz');pzStart({opp:o[0],stake:2000,seed:2})}",[opp,venue]);await pg.wait_for_timeout(600)
            await E("()=>{document.getElementById('pzintro').click()}");await pg.wait_for_timeout(1400)
            await E("()=>pzdForceEnd(true)");await pg.wait_for_timeout(1500)
            r=await E("()=>({card:!!document.querySelector('.pzun.pzd8un'),txt:(document.querySelector('.pzun.pzd8un')||{}).textContent||'',goal:(document.querySelector('.pzgoal')||{}).textContent||''})")
            chk(f'beating {opp} the first time puts a NEW VENUE: The Gilded Hoard card and a pointer to the key on the results',r['card'] and 'Gilded Hoard' in r['txt'] and 'Gilded Hoard' in r['goal'],r)
            if opp=='mortimer':await pg.screenshot(path=os.path.join(SHOTS,'t_result_newvenue.png'))
            await pg.wait_for_timeout(600);await pg.keyboard.press('Escape');await pg.wait_for_timeout(1300)
            r=await E("()=>{const t=document.getElementById('pzd8key');return {hub:(document.getElementById('pzh')||{}).className||'',nw:!!t&&t.classList.contains('new')}}")
            chk(f'Esc from that result goes back to the {venue} hub, where the vault key now shows NEW',('pzn8' in r['hub'])==(venue=='o8') and 'pzd8' not in r['hub'] and r['nw'],r)
        # ------------------------------------------------------------ The Regulars
        await E("()=>{const Z=PZS();Z.beat.clasp=2;Z.venue='hoard';save();pzRegs()}");await pg.wait_for_timeout(1000)
        r=await E("()=>({tabs:[...document.querySelectorAll('.pzn8tabs button')].map(b=>b.textContent),on:(document.querySelector('.pzn8tabs button.on')||{}).dataset.v,cards:[...document.querySelectorAll('.pzrg')].map(b=>b.dataset.k+(b.disabled?'L':'')),pt:[...document.querySelectorAll('.pzrg canvas')].map(c=>pzPainted(c)[0]>500),txt:(document.querySelector('.pzrg')||{}).textContent||'',bk:document.getElementById('pzbk').textContent})")
        chk('The Regulars: a third tab, The Gilded Hoard, open from the Hoard: five cards in order, open ones painted, locked dark, Clasp\'s record, back says the Hoard',r['tabs']==['The Crooked Cue','Orbit 8','The Gilded Hoard'] and r['on']=='hoard' and r['cards']==['clasp','zephyra','brassL','hornsbyL','aurelionL'] and all(r['pt']) and '2' in r['txt'] and 'Hoard' in r['bk'],r)
        await pg.click('.pzn8tabs button[data-v=o8]');await pg.wait_for_timeout(400)
        r=await E("()=>({cards:[...document.querySelectorAll('.pzrg')].map(b=>b.dataset.k),k:document.getElementById('pzk').className})")
        chk('switching to the Orbit 8 tab shows the Orbit 8 cards and drops the vault style',r['cards'][:1]==['bleep'] and 'pzd8k' not in r['k'],r)
        await pg.click('.pzn8tabs button[data-v=hoard]');await pg.wait_for_timeout(400);await pg.click('.pzrg[data-k=zephyra]');await pg.wait_for_timeout(1300)
        chk('clicking a Hoard card goes to the Hoard hub with them picked',await E("()=>!!document.querySelector('#pzh.pzd8')&&PZ.sel==='zephyra'"))
        # ------------------------------------------------------------ felts from the new players
        r=await E("""()=>{const want={zephyra:'genie',hornsby:'velvet',aurelion:'hoard'},o={};P.pz=null;const Z=PZS();Z.beat={mortimer:1};const before=pzUnlockSweep().map(u=>u.id);
          for(const [k,f] of Object.entries(want)){const F=PZ_FELT.find(x=>x.id===f);o[k]={has:!!F,beat:F&&F.beat};Z.beat[k]=1;const got=pzUnlockSweep().filter(u=>u.t==='felt').map(u=>u.id);o[k].got=got;o[k].own=!!Z.felts[f]}return {o,before}}""")
        chk('felt unlocks: beating Zephyra, Hornsby and Aurelion gives the Genie Smoke, Crimson Velvet and Gilded Hoard felts through the normal sweep (once each)',all(r['o'][k]['has'] and r['o'][k]['beat']==k and r['o'][k]['got']==[f] and r['o'][k]['own'] for k,f in [('zephyra','genie'),('hornsby','velvet'),('aurelion','hoard')]),r)
        # ------------------------------------------------------------ save normaliser
        r=await E("""()=>{P.pz={beat:{clasp:'x',zephyra:-2,brass:2.7},rep:{hornsby:NaN},venue:'hoard',hoard:[]};const Z=PZS();const a={venue:Z.venue,hoard:JSON.stringify(Z.hoard),beat:JSON.stringify(Z.beat),rep:JSON.stringify(Z.rep)};
          P.pz.beat.vantara=1;P.pz.venue='hoard';const b=PZS().venue;
          P.pz.live={v:PZ_LIVE_V,opp:'mortimer',stake:10000,mult:3,race:3,practice:false,extended:false,score:[0,0],rack:1,breaker:0,bnr:0,golden:0,pots:0,banks:0,racks:[],bonus:0,seed:1,B:Array.from({length:16},(_,i)=>[i,0,0,1]),pre:1};const c=!!PZS().live;
          P.pz.live={v:PZ_LIVE_V,opp:'aurelion',stake:10000,mult:5,race:3,practice:false,extended:false,score:[0,0],rack:1,breaker:0,bnr:0,golden:0,pots:0,banks:0,racks:[],bonus:0,seed:1,B:Array.from({length:16},(_,i)=>[i,0,0,1]),pre:1};const d=!!PZS().live;P.pz.live=null;
          return {a,b,c,d,open:[pzdOpen('clasp'),pzdOpen('zephyra'),pzdOpen('hornsby')]}}""")
        chk('save normaliser: the Hoard before its unlock falls back to the tavern, bad counts dropped or floored, hoard rebuilt; a 10,000 live match is kept against Aurelion but dropped against Mortimer',
            r['a']['venue']=='tavern' and r['a']['hoard']=='{"seen":0}' and 'clasp' not in r['a']['beat'] and 'zephyra' not in r['a']['beat'] and '"brass":2' in r['a']['beat'] and 'hornsby' not in r['a']['rep'] and r['b']=='hoard' and r['c'] is False and r['d'] is True,r)
        chk('unlocks follow the ladder (Clasp once the vault is open, Zephyra only after Clasp, Hornsby once Brassknuckle is beaten)',r['open']==[True,False,True],r)
        # ------------------------------------------------------------ hub frame cost
        await E("()=>{P.pz=null;const Z=PZS();Z.beat={mortimer:1,clasp:1,zephyra:1,brass:1,hornsby:1};Z.venue='hoard';Z.hoard.seen=1;save();PZ.sel='aurelion';pzHub()}");await pg.wait_for_timeout(1600)
        await pg.screenshot(path=os.path.join(SHOTS,'t_hub_aurelion.png'))
        r=await E("""()=>{const L=LIVE.filter(l=>l.cv&&l.cv.isConnected);const t=[];for(let i=0;i<30;i++){const a=performance.now();for(const l of L)l.fn();t.push(performance.now()-a)}t.sort((x,y)=>x-y);return {n:L.length,med:t[15],p90:t[27]}}""")
        hubc=r
        await E("()=>{const Z=PZS();Z.venue='tavern';save();PZ.sel=null;pzHub()}");await pg.wait_for_timeout(1500)
        r2=await E("""()=>{const L=LIVE.filter(l=>l.cv&&l.cv.isConnected);const t=[];for(let i=0;i<30;i++){const a=performance.now();for(const l of L)l.fn();t.push(performance.now()-a)}t.sort((x,y)=>x-y);return {n:L.length,med:t[15]}}""")
        chk(f'Hoard hub: all its live canvases together cost {hubc["med"]:.2f} ms (tavern hub {r2["med"]:.2f} ms; under 3 ms and under 1 ms more than the tavern)',hubc['med']<3 and hubc['med']-r2['med']<1,(hubc,r2))
        chk('no page errors in the main run',not er,er)
        await ctx.close()
        # ------------------------------------------------------------ fit at three sizes
        for vw,vh in [(1280,720),(1024,640)]:
            ctx,pg,E,er=await newpage(b,vw,vh)
            await E("()=>{P.pz=null;const Z=PZS();Z.beat={mortimer:1,vantara:1,grizzle:1,clasp:1,zephyra:1,brass:1};Z.venue='hoard';Z.hoard.seen=1;save();PZ.sel='hornsby';casinoOpen();gameOpen('pz')}");await pg.wait_for_timeout(1800)
            a=await E("()=>pzdAudit()")
            await pg.screenshot(path=os.path.join(SHOTS,f't_hub_{vw}.png'))
            await E("()=>{const Z=PZS();Z.venue='tavern';save();PZ.sel=null;pzHub()}");await pg.wait_for_timeout(1300)
            t=await E("()=>pzdAudit().filter(x=>x[0]==='top'||x[0]==='off-stage'||String(x[1]).includes('key'))")
            await E("()=>{const Z=PZS();Z.venue='o8';save();PZ.sel=null;pzHub()}");await pg.wait_for_timeout(1300)
            o=await E("()=>pzdAudit().filter(x=>x[0]==='top'||x[0]==='off-stage'||String(x[1]).includes('key'))")
            chk(f'fit at {vw} x {vh}: the Hoard hub has no overlaps or text out of its box; the vault key sits clear in the tavern and Orbit 8 top bars',a==[] and t==[] and o==[] and not er,(a,t,o,er))
            await ctx.close()
        # ------------------------------------------------------------ the cheat guard enforced: a 50,000 win at 10,000
        ctx,pg,E,er=await newpage(b,init='window.TW_AC_TEST=1')
        await E("()=>{setTimeout(cPay,0,0,30000)}");await pg.wait_for_timeout(400)
        r=await E("""()=>{const Z=PZS();Z.beat={mortimer:1,clasp:1,zephyra:1,brass:1,hornsby:1};Z.first={aurelion:1};Z.mastPaid={house:10};Z.venue='hoard';Z.hoard.seen=1;save();PZ.sel='aurelion';casinoOpen();gameOpen('pz');
          return {enf:TWAC.stat().enforced,gold:P.gold,blk:TWAC.stat().blocked}}""");await pg.wait_for_timeout(1300)
        await E("()=>{pzHubStake(10000)}");await pg.wait_for_timeout(300)
        g0=await E("()=>{window.__g0=P.gold;window.__L0=Date.now();window.__B0=TWAC.stat().blocked;return P.gold}")
        await pg.click('#pzrackem',force=True);await pg.wait_for_timeout(700)
        g1=await E("()=>P.gold")
        await pg.click('#pzintro',force=True);await pg.wait_for_timeout(1500)
        await E("()=>pzdForceEnd(true,{bnr:3,golden:1})");await pg.wait_for_timeout(1800)
        q=await E("""()=>{const g2=P.gold;let refused=false;try{P.gold=9999999}catch(e){}refused=P.gold===g2;const led=ledgerRecent(40).filter(e=>e.t>=window.__L0);return {g2,pay:PZ.result&&PZ.result.pay,refused,led:led.reduce((x,e)=>x+e.d,0),src:led.map(e=>e.src),blk:TWAC.stat().blocked-window.__B0,saved:(()=>{try{return JSON.parse(localStorage.getItem('typeWarriors')||'{}').gold}catch(e){return null}})()}}""")
        await pg.wait_for_timeout(1500);g3=await E("()=>P.gold")
        chk(f'guard enforced (window.TW_AC_TEST): a real click takes the 10,000 stake and the game\'s loop pays the capped 50,000; gold {g0:,} -> {g1:,} -> {q["g2"]:,}, the ledger agrees, nothing was blocked or reverted and a console write is refused',
            r['enf'] is True and g0>=10000 and g1==g0-10000 and q['pay']==50000 and q['g2']==g0+40000 and q['led']==40000 and q['refused'] and q['blk']==1 and g3==q['g2'],(r,g0,g1,q,g3))
        await pg.screenshot(path=os.path.join(SHOTS,'t_result_50k.png'))
        chk('no page errors on the guard page',not [e for e in er if 'blocked' not in e],er)
        await ctx.close()
        await b.close()
    print(f'frame cost: rest median {rest[0]:.2f} ms p90 {rest[1]:.2f}; break median {brk[0]:.2f} p90 {brk[1]:.2f}; ambience {amb["med"]:.2f} ms ({amb["extra"]:+.2f} vs tavern); hub live {hubc["med"]:.2f} ms')
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
