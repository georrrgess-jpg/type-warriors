# python3 t_ui87.py : 8.7 menu pass (94f_ui87.js) - Back to the opener, sticky primary action above the dock, modal exits, no backdrop-filter,
# no h1 glow loop, Wildcard in Choose a mode, campaign act tabs, Help text, stale NEW labels.
import asyncio,os
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:200]))
        await pg.goto('file://'+os.path.abspath('out.html'));await pg.wait_for_timeout(1200);E=pg.evaluate;bad=0
        def chk(n,v,ok):
            nonlocal bad
            if not ok:bad+=1
            print(n,v,'OK' if ok else 'BAD')
        SL="const sl=ms=>new Promise(r=>setTimeout(r,ms));"
        await E("()=>{RS_ASK=false;P.gold=5000;P.camp=8;title()}");await pg.wait_for_timeout(400)
        # Back from More > Settings returns to the screen it was opened over
        r=await E("async()=>{"+SL+"const o=[];for(const [f,want] of [[()=>armory(),'Armory'],[()=>shop(),'Shop'],[()=>bountyBoard(),'Bount']]){f();await sl(400);const h0=(ov.querySelector('h1,h2')||{}).textContent||'';moreSheet();await sl(350);document.querySelector('#dkmo #mst').click();await sl(500);const inS=/Settings/.test((ov.querySelector('h2')||{}).textContent||'');S.back();await sl(500);const h1=(ov.querySelector('h1,h2')||{}).textContent||'';o.push([inS,h0===h1&&h1.length>0])}return o}")
        chk('More > Settings > Back returns to Armory, Shop and Bounties',r,all(a and b_ for a,b_ in r))
        r=await E("async()=>{"+SL+"shop();await sl(400);moreSheet();await sl(350);document.querySelector('#dkmo #mhp').click();await sl(500);const a=/How to play/.test(ov.textContent);S.back();await sl(400);return [a,S.view,ov.className.includes('hide')]}")
        chk('More > Help > Back returns to the Shop',r,r[0])
        r=await E("async()=>{"+SL+"shop();await sl(400);const h0=(ov.querySelector('h1,h2')||{}).textContent;document.querySelector('#dkcal').click();await sl(600);S.back();await sl(500);return [h0,(ov.querySelector('h1,h2')||{}).textContent]}")
        chk('calendar button returns to the screen it was opened from',r,r[0]==r[1])
        r=await E("async()=>{"+SL+"title();await sl(300);moreSheet();await sl(350);document.querySelector('#dkmo #mst').click();await sl(500);S.back();await sl(500);return HOME}")
        chk('from the hub it still returns to the hub',r,r is True)
        # Practice: Start practice sits above the dock
        r=await E("async()=>{"+SL+"pracMenu(title);await sl(800);const s=ov.querySelector('.uk87st'),d=ov.querySelector('.dk');if(!s)return null;const a=s.getBoundingClientRect(),k=d.getBoundingClientRect();const go=s.querySelector('button:not(.sm)');const g=go.getBoundingClientRect();return [Math.round(g.bottom),Math.round(k.top),go.textContent.trim()]}")
        chk('Practice: Start practice is visible above the dock',r,r is not None and r[0]<=r[1])
        r=await E("async()=>{"+SL+"crateHub();await sl(700);return !!ov.querySelector('.uk87st')}")
        chk('Owned crates: no floating Back row over the crate cards',r,r is False)
        # h1 glow loop gone
        r=await E("async()=>{"+SL+"title();await sl(400);const h=document.querySelector('.dklogo h1')||document.querySelector('h1');return [getComputedStyle(h).animationName,document.getAnimations().filter(a=>a.animationName==='glow').length]}")
        chk('no infinite h1 glow animation',r,r[1]==0)
        # modal exits fade instead of jumping
        r=await E("async()=>{"+SL+"const out=[];for(const c of ['hlmod','ptmod','pthx','pat-wrap','rkup']){const d=document.createElement('div');d.className=c;d.style.display='flex';const w=document.createElement('section');ov.appendChild(w);w.appendChild(d);await sl(400);d.classList.add('out');await sl(30);out.push(getComputedStyle(d).animationName);w.remove()}return out}")
        chk('modal .out exits use a real fade-out keyframe (not the entrance played in reverse)',r,all(v=='uk87out' for v in r))
        r=await E("()=>{const out=[];for(const c of ['shmod','nzmod','pat-wrap','sgm']){const d=document.createElement('div');d.className=c;document.body.appendChild(d);out.push(getComputedStyle(d).backdropFilter);d.remove()}return out}")
        chk('no backdrop-filter on the old modal scrims',r,all(v in ('none','') for v in r))
        # Choose a mode: Wildcard card
        r=await E("async()=>{"+SL+"title();await sl(300);modeSheet();await sl(500);const b=document.querySelector('#dmwc');if(!b)return null;b.click();await sl(900);return [!!b,typeof WX!=='undefined'&&!!document.querySelector('.wcx,#wch,.wch'),S.view]}")
        chk('Choose a mode has a Wildcard card that opens Wildcard',r,r is not None and r[1])
        # campaign act tabs
        r=await E("async()=>{"+SL+"title();await sl(300);P.camp=8;campaign(8);await sl(700);const t=[...ov.querySelectorAll('.cmt:not(.ast)')];const lk=t.find(x=>x.classList.contains('lk'));const a0=CM.act;if(lk)lk.click();await sl(300);return [t.map(x=>x.textContent.trim()),!!lk&&lk.title.includes('Clear Level'),CM.act===a0]}")
        chk('act tabs: short labels, open act named in full, locked tab explains and stays put',r,r[0][0]=='Act I' and r[0][1].startswith('Act II:') and r[1] and r[2])
        # Help
        r=await E("()=>{const m=HELP.Modes.map(x=>x[0]);return [m.includes('Runestone Riddle'),m.includes('Wildcard'),HELP.Modes.some(x=>/^New!/.test(x[1])),HELP.Shortcuts.some(x=>x[0].includes('F W G')),/six acts/.test(HELP.Modes.find(x=>x[0]==='Campaign')[1])]}")
        chk('Help lists the current modes, six acts and the real shortcuts',r,r==[True,True,False,True,True])
        # stale NEW labels
        r=await E("async()=>{"+SL+"title();await sl(500);const n=document.querySelector('#dkfish .dknew'),k=document.querySelector('#dkfish .dkcl small');return [n?getComputedStyle(n).display:'gone',k?k.textContent:'']}")
        chk('Fishing home card no longer says NEW',r,r[0] in ('none','gone') and 'NEW' not in r[1])
        await pg.screenshot(path='shots/ui87_home.png') if os.path.isdir('shots') else None
        print('bad',bad);print([e for e in er if 'ERR_' not in e]);await b.close()
asyncio.run(main())
