/* ===== MOONLIT FISHING: rod models =====
   Every rod tier has its own model (fsTier() 0-4, from the total upgrade level):
   0 Willow: knotted willow, cork grip, twine wraps, a little tin reel.
   1 Ashwood: pale ash, leather grip, brass ferrules and a brass reel with a crank.
   2 Moonreed: a segmented reed with silver node bands, a crescent reel and a moonstone butt cap.
   3 Starwoven: dark starwood with glowing star inlays, glowing guide rings and an ornate star reel.
   4 Tidecaller: coral-and-gold shaft, a shell reel, glowing tide runes and a little trident at the tip.
   A rod look (FSKIN) re-colours the model: c = [shaft dark, shaft light], tip, gl (glow), ln (line), rb (rainbow).
   fsRod(g,hx,hy,a,b,len,t,sk,tier) keeps the old signature (hand point, angle, bend 0..1, length) and returns the tip. */
const fsTier=lv=>{lv=lv==null?fsLv():lv;return lv>=15?4:lv>=10?3:lv>=6?2:lv>=3?1:0};
const FSTIERN=['Willow Rod','Ashwood Rod','Moonreed Rod','Starwoven Rod','Tidecaller Rod'];
function fsRod(g,hx,hy,a,b,len,t,sk,tier){sk=sk||fsSkin();tier=tier==null?fsTier():tier;t=t||0;b=b||0;
 const ca=Math.cos(a),sa=Math.sin(a),tx=hx+ca*len,ty=hy+sa*len,bx=tx+b*len*.08,by=ty+b*len*.34,cpx=hx+ca*len*.55+sa*b*len*.12,cpy=hy+sa*len*.55-ca*b*len*.12+b*len*.12;
 const bx0=hx-ca*len*.2,by0=hy-sa*len*.2;/* butt end */
 const N=26,P=[];for(let i=0;i<=N;i++){const u=i/N;let x,y;if(u<.16){const k=u/.16;x=bx0+(hx-bx0)*k;y=by0+(hy-by0)*k}else{const k=(u-.16)/.84;x=(1-k)*(1-k)*hx+2*k*(1-k)*cpx+k*k*bx;y=(1-k)*(1-k)*hy+2*k*(1-k)*cpy+k*k*by}P.push([x,y])}
 const at=u=>{const f=u*N,i=Math.min(N-1,Math.floor(f)),r=f-i,A=P[i],B=P[i+1],dx=B[0]-A[0],dy=B[1]-A[1],d=Math.hypot(dx,dy)||1;return{x:A[0]+dx*r,y:A[1]+dy*r,tx:dx/d,ty:dy/d,nx:-dy/d,ny:dx/d}};
 const W0=[6.4,7,7,7.4,8][tier],W1=[1.8,1.9,2.1,2.2,2.4][tier];const wAt=u=>u<.16?W0*1.5:W0+(W1-W0)*((u-.16)/.84);
 /* shaft: a tapered shape, dark outline, gradient body, a light streak */
 const L=[],R=[];for(let i=0;i<=N;i++){const u=i/N,p=at(Math.min(.999,u)),w=wAt(u)/2;L.push([p.x+p.nx*w,p.y+p.ny*w]);R.push([p.x-p.nx*w,p.y-p.ny*w])}
 const path=()=>{g.beginPath();g.moveTo(L[0][0],L[0][1]);for(const q of L)g.lineTo(q[0],q[1]);for(let i=R.length-1;i>=0;i--)g.lineTo(R[i][0],R[i][1]);g.closePath()};
 const TT=[null,['#c89a62','#f0d8a8'],['#3a4aa8','#c8d0ff'],['#1e1446','#6a5ac8'],['#c8505a','#ffb0a0']][tier],mx=(a,b,f)=>{const A=parseInt(a.slice(1),16),B=parseInt(b.slice(1),16),m=(s1)=>Math.round(((A>>s1)&255)*(1-f)+((B>>s1)&255)*f);return '#'+((1<<24)+(m(16)<<16)+(m(8)<<8)+m(0)).toString(16).slice(1)};
 const c0=TT&&sk===FSKIN.willow?TT[0]:TT?mx(sk.c[0],TT[0],.35):sk.c[0],c1=TT&&sk===FSKIN.willow?TT[1]:TT?mx(sk.c[1],TT[1],.3):sk.c[1];path();g.lineJoin='round';g.lineWidth=3.2;g.strokeStyle=FKO;g.stroke();
 const gr=g.createLinearGradient(bx0,by0,bx,by);gr.addColorStop(0,shade(c0,-.15));gr.addColorStop(.5,c0);gr.addColorStop(1,shade(c1,-.05));g.fillStyle=gr;path();g.fill();
 g.save();path();g.clip();g.strokeStyle=c1;g.globalAlpha=.75;g.lineWidth=1.4;g.beginPath();for(let i=0;i<=N;i++){const u=i/N,p=at(Math.min(.999,u)),w=wAt(u)*.22;i?g.lineTo(p.x+p.nx*w,p.y+p.ny*w):g.moveTo(p.x+p.nx*w,p.y+p.ny*w)}g.stroke();g.restore();
 const band=(u,w,col,o)=>{const p=at(u),hw=wAt(u)/2+(o||1.1);g.save();g.translate(p.x,p.y);g.rotate(Math.atan2(p.ty,p.tx));g.fillStyle=col;g.fillRect(-w/2,-hw,w,hw*2);g.lineWidth=1;g.strokeStyle=FKO;g.strokeRect(-w/2,-hw,w,hw*2);g.fillStyle='#ffffff55';g.fillRect(-w/2,-hw,w,hw*.6);g.restore()};
 const guide=(u,col,glow)=>{const p=at(u),r=3.2+(1-u)*1.6;const gx=p.x-p.nx*(wAt(u)/2+r),gy=p.y-p.ny*(wAt(u)/2+r);if(glow)fkGlow(g,gx,gy,8,glow,.55+.25*Math.sin(t*3+u*9));g.beginPath();g.arc(gx,gy,r,0,TAU);g.lineWidth=1.6;g.strokeStyle=FKO;g.stroke();g.lineWidth=1;g.strokeStyle=col;g.stroke()};
 /* per-tier decoration */
 if(tier===0){[.3,.55,.78].forEach(u=>{const p=at(u);g.fillStyle=shade(c0,-.35);g.beginPath();g.ellipse(p.x+p.nx*1.2,p.y+p.ny*1.2,2.2,1.4,Math.atan2(p.ty,p.tx),0,TAU);g.fill()});[.22,.42,.62,.82].forEach(u=>band(u,2.2,'#d8c08a',.6));[.36,.6,.84].forEach(u=>guide(u,'#c8c8d0'))}
 if(tier===1){[.24,.5,.74].forEach(u=>band(u,3.2,'#e6b93e'));[.34,.56,.76,.9].forEach(u=>guide(u,'#f0e0a0'))}
 if(tier===2){[.24,.36,.48,.6,.72,.84].forEach(u=>band(u,3.4,'#e8ecff',1.8));[.42,.66,.88].forEach(u=>guide(u,'#e8ecff',sk.gl));{const p=at(.9),sw=Math.sin(t*2.2)*.25;g.save();g.translate(p.x-p.nx*4,p.y-p.ny*4);g.strokeStyle='#e8ecff';g.lineWidth=1;g.beginPath();g.moveTo(0,0);g.lineTo(Math.sin(sw)*12,Math.cos(sw)*12);g.stroke();g.translate(Math.sin(sw)*12,Math.cos(sw)*12+5);g.beginPath();g.arc(0,0,5.5,0,TAU);g.arc(2.4,-1.4,4.6,0,TAU,true);g.fillStyle='#fff4d0';g.fill('evenodd');g.lineWidth=1.3;g.strokeStyle=FKO;g.stroke();fkGlow(g,0,0,10,'#fff4d0',.4);g.restore()}const p=at(.02);g.beginPath();g.arc(p.x,p.y,5,0,TAU);g.fillStyle=fkRad(g,p.x,p.y,5,['#ffffff','#c8d8ff','#7a8ad8']);g.fill();g.lineWidth=1.6;g.strokeStyle=FKO;g.stroke()}
 if(tier===3){for(let i=0;i<6;i++){const u=.28+i*.11,p=at(u);fkGlow(g,p.x,p.y,7,sk.gl||'#c8b8ff',.35);fkSpark(g,p.x,p.y,3.4+1.6*Math.abs(Math.sin(t*2.4+i)),'#fff6dc',.95)}[.4,.62,.82,.93].forEach(u=>guide(u,'#fff6dc',sk.gl||'#c8b8ff'));[.2].forEach(u=>band(u,4,'#d8dcf0'))}
 if(tier===4){for(let i=0;i<4;i++){const u=.32+i*.16,p=at(u),w=wAt(u)/2;g.beginPath();g.moveTo(p.x+p.nx*w-p.tx*3,p.y+p.ny*w-p.ty*3);g.lineTo(p.x+p.nx*(w+6)+p.tx*2,p.y+p.ny*(w+6)+p.ty*2);g.lineTo(p.x+p.nx*w+p.tx*3,p.y+p.ny*w+p.ty*3);g.closePath();g.fillStyle='#ff8a8a';g.fill();g.lineWidth=1.2;g.strokeStyle=FKO;g.stroke()}[.22,.5,.78].forEach(u=>band(u,4.2,'#ffd45a',1.8));for(let i=0;i<5;i++){const u=.3+i*.12,p=at(u),a2=.5+.5*Math.sin(t*3-i);g.save();g.translate(p.x,p.y);g.rotate(Math.atan2(p.ty,p.tx));g.strokeStyle=`rgba(127,255,224,${a2})`;g.lineWidth=1.3;g.beginPath();g.moveTo(-3,-1.4);g.lineTo(0,1.4);g.lineTo(3,-1.4);g.stroke();g.restore()}[.38,.6,.82,.93].forEach(u=>guide(u,'#ffe9a0',sk.gl||'#7affe0'))}
 if(sk.rb){for(let i=0;i<7;i++){const u=.25+i*.1,p=at(u);g.fillStyle=`hsl(${(t*80+i*50)%360},90%,70%)`;g.beginPath();g.arc(p.x+p.nx*.8,p.y+p.ny*.8,1.9,0,TAU);g.fill()}}
 /* grip */
 {const gripC=[['#c8945a','#8a5a2e'],['#6a3a1e','#3a1e0e'],['#3a3a6a','#20204a'],['#2a1a4a','#140a2a'],['#2a6a7a','#123a48']][tier];const u0=.02,u1=.17,p0=at(u0),p1=at(u1);
  g.lineCap='round';g.strokeStyle=FKO;g.lineWidth=W0*1.5+5;g.beginPath();g.moveTo(p0.x,p0.y);g.lineTo(p1.x,p1.y);g.stroke();g.strokeStyle=gripC[0];g.lineWidth=W0*1.5+1.4;g.stroke();
  g.strokeStyle=gripC[1];g.lineWidth=1.2;for(let k=0;k<6;k++){const u=u0+(u1-u0)*(k+.5)/6,p=at(u),w=W0*.75+1;g.beginPath();g.moveTo(p.x+p.nx*w-p.tx*2,p.y+p.ny*w-p.ty*2);g.lineTo(p.x-p.nx*w+p.tx*2,p.y-p.ny*w+p.ty*2);g.stroke()}
  if(tier===4){const p=at(.01);g.beginPath();g.arc(p.x,p.y,5.4,0,TAU);g.fillStyle=fkRad(g,p.x,p.y,5.4,['#fff2b0','#e6b93e','#8a5a10']);g.fill();g.lineWidth=1.6;g.strokeStyle=FKO;g.stroke()}
  if(tier===1){band(.18,3,'#e6b93e')}if(tier>=3){band(.18,3.4,tier===3?'#d8dcf0':'#ffd45a')}}
 /* reel, hanging under the rod just above the grip */
 {const p=at(.19),off=wAt(.19)/2+7,rx=p.x-p.nx*off,ry=p.y-p.ny*off,R0=[8,9,9.5,10,10.5][tier],spin=t*(b>.2?16:0);
  g.strokeStyle=FKO;g.lineWidth=3;g.beginPath();g.moveTo(p.x,p.y);g.lineTo(rx,ry);g.stroke();
  g.save();g.translate(rx,ry);
  if(tier===2){g.beginPath();g.arc(0,0,R0,0,TAU);g.arc(R0*.36,-R0*.1,R0*.78,0,TAU,true);g.fillStyle=fkRad(g,0,0,R0,['#ffffff','#c8d0f0','#6a72a0']);g.fill('evenodd');g.lineWidth=1.6;g.strokeStyle=FKO;g.stroke()}
  else{const cols=[['#e6e6ee','#a0a0b0','#5a5a6a'],['#fff2b0','#e6b93e','#8a5a10'],null,['#f4f6ff','#a8b0d0','#4a5070'],['#fff0e0','#ff9ab0','#a84a6a']][tier];g.beginPath();g.arc(0,0,R0,0,TAU);g.fillStyle=fkRad(g,0,0,R0,cols);g.fill();g.lineWidth=1.8;g.strokeStyle=FKO;g.stroke();
   if(tier===4){g.strokeStyle='#a84a6a';g.lineWidth=1;for(let k=0;k<6;k++){g.beginPath();g.moveTo(0,R0*.2);g.lineTo(Math.cos(-Math.PI*.1-k*.5)*R0*.9,Math.sin(-Math.PI*.1-k*.5)*R0*.9);g.stroke()}}
   if(tier===3){fkSpark(g,0,0,R0*.6,'#fff6dc',.95);fkGlow(g,0,0,R0*1.6,sk.gl||'#c8b8ff',.3)}}
  g.rotate(spin);g.strokeStyle=FKO;g.lineWidth=2.6;g.beginPath();g.moveTo(0,0);g.lineTo(R0+3,0);g.stroke();g.strokeStyle=tier===1?'#e6b93e':'#d8d8e8';g.lineWidth=1.4;g.stroke();g.beginPath();g.arc(R0+4,0,2.4,0,TAU);g.fillStyle='#3a2a1a';g.fill();g.restore()}
 /* tip ornament and glow */
 const tp=at(.999);
 if(tier===4){g.save();g.translate(tp.x,tp.y);g.rotate(Math.atan2(tp.ty,tp.tx));g.strokeStyle=FKO;g.lineWidth=4.4;g.beginPath();g.moveTo(-9,0);g.lineTo(8,0);g.moveTo(-3,-8);g.lineTo(-3,8);g.moveTo(-3,-8);g.lineTo(5,-8);g.moveTo(-3,8);g.lineTo(5,8);g.stroke();g.strokeStyle='#ffd45a';g.lineWidth=2.2;g.stroke();g.fillStyle='#7affe0';g.beginPath();g.arc(-3,0,2.2,0,TAU);g.fill();g.restore()}
 if(sk.gl||tier>=3)fkGlow(g,tp.x,tp.y,18+tier*2,sk.gl||'#fff2b0',.45+.2*Math.sin(t*3));g.fillStyle=sk.tip;g.beginPath();g.arc(tp.x,tp.y,2.4,0,TAU);g.fill();
 return{x:tp.x,y:tp.y}}
