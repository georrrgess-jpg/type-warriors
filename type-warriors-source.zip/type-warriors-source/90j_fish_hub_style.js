/* ===== MOONLIT FISHING: landing menu, journal and workshop styles ===== (transform/opacity animation only) */
{const st=document.createElement('style');st.textContent=`
.fshub>canvas,.fsjx>canvas,.fswx>canvas{position:absolute;inset:0;width:1600px;height:900px}
.fshvig{position:absolute;inset:0;background:linear-gradient(90deg,#07041af2 0%,#07041ad8 34%,#07041a60 56%,#07041a00 72%);pointer-events:none}
.fshl{position:absolute;left:64px;top:56px;width:700px;display:flex;flex-direction:column;align-items:flex-start}
.fshk{display:flex;align-items:center;gap:10px;font:800 13px var(--ui);letter-spacing:.3em;color:#c8beff;animation:fsIn .5s var(--sp) both}.fshkm canvas{display:block;width:44px;height:44px}
.fsht{margin:4px 0 0;font:400 104px/0.95 'Pirata One',Georgia,serif;color:#fff8e8;letter-spacing:.01em;text-shadow:0 6px 0 #1b1024,0 0 40px #6a52f055;animation:fsIn .6s .05s var(--sp) both}
.fsht em{font-style:normal;background:linear-gradient(180deg,#fff6c0,#ffd45a 50%,#ff9a20);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;filter:drop-shadow(0 6px 0 #3a1a04)}
.fshs{margin:14px 0 18px!important;max-width:560px;font:500 18px/1.5 var(--ui);color:#e0d8ff;animation:fsIn .6s .1s var(--sp) both}
.fshmoon{display:flex;align-items:center;gap:14px;width:640px;padding:10px 18px 10px 8px;animation:fsIn .6s .15s var(--sp) both}.fshmoon canvas{width:200px;height:118px;flex:none}
.fshmoon div{display:flex;flex-direction:column;gap:2px}.fshmoon small{font:800 11.5px var(--ui);letter-spacing:.18em;color:#9ff0ff}.fshmoon b{font:400 32px/1 'Pirata One',Georgia,serif;color:var(--gold)}.fshmoon span{font:600 14.5px var(--ui);color:#fff8e8}.fshmoon em{font:500 13px var(--ui);font-style:italic;color:#c4badf}
.fshgo{display:flex;align-items:center;gap:14px;width:640px;height:92px;margin-top:18px;padding:0 30px;border:none;border-radius:26px;background:linear-gradient(180deg,#ffe27a,#f2b631);color:#3a2006;font:800 32px var(--ui);box-shadow:0 6px 0 #9a6a10,0 18px 40px #000a;cursor:pointer;animation:fsIn .6s .2s var(--sp) both;transition:transform .15s}
.fshgo:hover{transform:translateY(-3px)}.fshgo:active{transform:scale(.97)}.fshgo i{font-style:normal;margin-left:auto;font-size:40px}.fshgo kbd{background:#3a200614!important;border-color:#3a200655!important;color:#3a2006!important;font-size:13px!important}.fshgoi svg{width:52px;height:32px;display:block}.fshgoi svg path{fill:#3a2006}
.fshgo:focus-visible{outline:3px solid #fff;outline-offset:4px}
.fshtl{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;width:780px;margin-top:20px}
.fsht2{position:relative;display:flex;flex-direction:column;align-items:flex-start;gap:3px;padding:10px 14px 12px;border-color:color-mix(in srgb,var(--c) 45%,#3a3070)!important;color:#fff8e8;cursor:pointer;text-align:left;animation:fsIn .6s calc(.25s + var(--i,0)*.05s) var(--sp) both;transition:transform .18s var(--sp)}
.fsht2:hover{transform:translateY(-4px)}.fsht2:active{transform:scale(.96)}.fsht2:nth-child(2){--i:1}.fsht2:nth-child(3){--i:2}.fsht2:nth-child(4){--i:3}
.fshic canvas{display:block;width:120px;height:96px;margin:-4px 0 0 -6px}.fsht2 b{font:800 16px var(--ui)}.fsht2 small{font:500 12.5px var(--ui);color:#c4badf}
.fshpr{display:block;width:100%;height:7px;margin-top:4px;border-radius:4px;background:#07041a;border:1px solid #ffffff22;overflow:hidden}.fshpr i{display:block;height:100%;background:linear-gradient(90deg,#ffd45a,#fff2b0)}
.fshdot{position:absolute;top:-8px;right:-8px;width:24px;height:24px;border-radius:50%;background:#e8364e;color:#fff;font:800 14px/24px var(--ui);font-style:normal;text-align:center;animation:fsNew 2s ease-in-out infinite}
.fspm .fsx2{top:-16px;right:-16px}.fspm{position:relative;width:560px;max-height:760px;display:flex;flex-direction:column;padding:16px 18px;animation:fsWb .35s var(--sp) both}.fspm .fsbody{max-height:700px}
/* the journal */
.fsjbook{position:absolute;left:110px;top:58px;width:1380px;height:790px;border-radius:26px;background:linear-gradient(180deg,#5a3424,#3a1e14);border:3px solid #1b1024;box-shadow:inset 0 0 0 8px #6a3e2a,inset 0 0 0 10px #e6b93e66,0 30px 70px #000d;animation:fsWb .45s var(--sp) both}
.fsjbook::before,.fsjbook::after{content:'';position:absolute;width:64px;height:64px;border:4px solid #e6b93e;opacity:.8}.fsjbook::before{left:10px;top:10px;border-right:none;border-bottom:none;border-radius:14px 0 0 0}.fsjbook::after{right:10px;bottom:10px;border-left:none;border-top:none;border-radius:0 0 14px 0}
.fsjpg{position:absolute;top:26px;bottom:26px;width:646px;background:radial-gradient(120% 90% at 50% 40%,#fbf2dc,#ecd9b0 70%,#d8bf8a);color:#3a2414;overflow:hidden}
.fsjpg.l{left:28px;border-radius:14px 4px 4px 14px;box-shadow:inset -24px 0 30px -18px #6a4a2a88}.fsjpg.r{right:28px;border-radius:4px 14px 14px 4px;box-shadow:inset 24px 0 30px -18px #6a4a2a88}
.fsjspine{position:absolute;left:50%;top:22px;bottom:22px;width:22px;margin-left:-11px;background:linear-gradient(90deg,#2a160c,#6a3e2a 50%,#2a160c);border-radius:6px}
.fsjpg header{display:flex;align-items:baseline;justify-content:space-between;padding:52px 34px 6px}.fsjpg h2{margin:0;font:400 44px/1 'Pirata One',Georgia,serif;color:#5a2a14}.fsjpg header span{font:700 13px 'Cinzel',Georgia,serif;color:#7a5a3a}
.fsjpg footer{position:absolute;left:34px;right:34px;bottom:14px;display:flex;justify-content:space-between;font:italic 13px Georgia,serif;color:#8a6a4a}
.fsjgrid{display:grid;grid-template-columns:repeat(6,1fr);gap:7px;padding:8px 28px}
.fsjprog{margin:12px 30px 0;padding:10px 16px;border-radius:14px;border:2px dashed #c8a87a;background:#f6ead080}.fsjprog h4{margin:0 0 6px;font:700 14px 'Cinzel',Georgia,serif;color:#5a2a14;letter-spacing:.08em}
.fsjpr{display:grid;grid-template-columns:100px 1fr 60px 44px;align-items:center;gap:10px;margin:3px 0}.fsjpr b{font:700 13px 'Cinzel',Georgia,serif;color:#3a2414}.fsjpb{height:12px;border-radius:6px;border:1.5px solid #8a6a4a;background:#efe0bf;overflow:hidden}.fsjpb i{display:block;height:100%;background:color-mix(in srgb,var(--rc) 70%,#5a3a24)}
.fsjpr em{font:800 13px var(--ui);font-style:normal;color:#3a2414}.fsjpr small{font:700 12px var(--ui);color:#c8901a}.fsjhint,.fsjdone{margin:6px 0 0!important;font:italic 13px Georgia,serif;color:#7a5a3a}.fsjdone{color:#c8901a;font-weight:700}
.fsjen{position:relative;display:flex;flex-direction:column;align-items:center;gap:1px;padding:4px 2px 5px;border-radius:12px;border:2px solid #c8a87a;background:#f6ead0;color:#3a2414;cursor:pointer;transition:transform .15s var(--sp)}
.fsjen:hover{transform:translateY(-2px) rotate(-1deg)}.fsjen.on{border-color:color-mix(in srgb,var(--rc) 70%,#5a2a14);background:#fff8e4;box-shadow:0 0 0 3px color-mix(in srgb,var(--rc) 45%,transparent)}
.fsjen canvas{width:100%;height:auto;aspect-ratio:132/84}.fsjen b{font:700 10px 'Cinzel',Georgia,serif;line-height:1.15;text-align:center;min-height:2.3em;display:flex;align-items:center}.fsjen.unk b{color:#9a7a5a}.fsjen.unk{background:#efe0bf}
.fsjcr{position:absolute;top:2px;right:6px;font-style:normal;color:#c8901a;font-size:15px}.fsjft{position:absolute;top:2px;left:6px;font-style:normal;color:#3a8aff;font-size:13px}
.fsjrib{position:absolute;left:58px;top:-22px;display:flex;gap:6px;z-index:2}.fsjrib button{height:46px;padding:0 14px 10px;border:2px solid #1b1024;border-bottom:none;border-radius:8px 8px 0 0;background:linear-gradient(180deg,color-mix(in srgb,var(--rc) 75%,#fff),color-mix(in srgb,var(--rc) 70%,#3a2414));color:#1b1024;font:800 12.5px var(--ui);cursor:pointer;transform:translateY(8px);transition:transform .15s var(--sp)}
.fsjrib button.on,.fsjrib button:hover{transform:translateY(0)}
.fsjent{position:absolute;inset:0;padding:40px 40px 20px;display:flex;flex-direction:column;align-items:flex-start;gap:6px}
.fsjtop{display:flex;gap:10px;align-items:center;font:700 13px 'Cinzel',Georgia,serif;color:#7a5a3a}.fsjrr{padding:2px 12px;border-radius:99px;background:color-mix(in srgb,var(--rc) 60%,#3a2414);color:#fff;font:800 12px var(--ui)}.fsjfeat{color:#2a6ad8}
.fsjart{position:relative;align-self:center;width:560px;height:280px;border-radius:18px;background:radial-gradient(60% 70% at 50% 55%,color-mix(in srgb,var(--rc) 22%,#fff8e4),#f0e2c0 70%);border:2px dashed #c8a87a}.fsjart canvas{width:560px;height:280px}
.fsjstamp{position:absolute;right:14px;top:14px;padding:4px 12px;border:3px solid;border-radius:8px;font:800 15px 'Cinzel',Georgia,serif;transform:rotate(8deg);opacity:.85}.fsjstamp.g{color:#c8901a;border-color:#c8901a}.fsjstamp.u{color:#8a6a4a;border-color:#8a6a4a;font-size:13px}
.fsjent h3{margin:6px 0 0;font:400 46px/1 'Pirata One',Georgia,serif;color:#4a1e0e}
.fsjlore{font:italic 17px/1.45 Georgia,serif;color:#5a3a24;margin:0!important;min-height:50px}
.fsjruler{width:100%;margin-top:4px}.fsjrl{display:flex;justify-content:space-between;font:700 12px 'Cinzel',Georgia,serif;color:#7a5a3a}
.fsjbar{position:relative;height:16px;margin:4px 0;border-radius:8px;border:2px solid #8a6a4a;background:repeating-linear-gradient(90deg,#f6ead0 0 18px,#e8d4a8 18px 20px)}
.fsjbar .gz{position:absolute;top:-2px;bottom:-2px;right:-2px;border-radius:0 8px 8px 0;background:linear-gradient(90deg,#ffd45a88,#ffb02acc)}.fsjbar .rec{position:absolute;top:-8px;width:4px;height:28px;margin-left:-2px;border-radius:2px;background:#c8282a;box-shadow:0 0 0 2px #fff8e4}
.fsjruler small{font:600 13px var(--ui);color:#5a3a24}.fsjruler small b{color:#c8282a}
.fsjnotes{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;width:100%;margin-top:6px}.fsjnotes span{display:flex;flex-direction:column;padding:8px 10px;border-radius:10px;background:#f6ead0;border:1.5px solid #c8a87a}
.fsjnotes small{font:700 10.5px 'Cinzel',Georgia,serif;letter-spacing:.06em;color:#8a6a4a;text-transform:uppercase}.fsjnotes b{font:800 17px var(--ui);color:#3a2414}
.fsjflip{position:absolute;right:28px;top:26px;bottom:26px;width:646px;border-radius:4px 14px 14px 4px;background:linear-gradient(90deg,#d8bf8a,#fbf2dc 30%,#ecd9b0);pointer-events:none;opacity:0;transform-origin:left center}
.fsjflip.go.fw{animation:fsFlipF .42s ease-in both}.fsjflip.go.bw{animation:fsFlipB .42s ease-in both}
@keyframes fsFlipF{0%{opacity:1;transform:perspective(1800px) rotateY(0)}100%{opacity:0;transform:perspective(1800px) rotateY(-150deg)}}
@keyframes fsFlipB{0%{opacity:0;transform:perspective(1800px) rotateY(-150deg)}20%{opacity:1}100%{opacity:0;transform:perspective(1800px) rotateY(0)}}
.fsjnav{position:absolute;bottom:22px;width:54px;height:54px;border-radius:50%;border:3px solid #1b1024;background:linear-gradient(180deg,#ffe27a,#f2b631);color:#3a2006;font:800 30px/1 var(--ui);cursor:pointer;box-shadow:0 4px 0 #9a6a10;z-index:3}.fsjnav.p{left:calc(50% + 40px)}.fsjnav.n{right:40px}.fsjnav:hover{transform:translateY(-2px)}
.fsjbk{position:absolute;right:22px;top:12px;height:50px!important;z-index:4}
/* the workshop */
.fswh{position:absolute;left:64px;top:24px;margin:0;font:400 64px/1 'Pirata One',Georgia,serif;color:var(--gold);text-shadow:0 5px 0 #1b1024}
.fswbench{position:absolute;left:64px;right:64px;top:110px;height:300px;display:grid;grid-template-columns:900px 1fr;grid-template-rows:1fr auto;padding:0 20px;background:repeating-linear-gradient(180deg,#00000000 0 58px,#00000038 58px 61px),repeating-linear-gradient(90deg,#ffffff06 0 3px,#00000008 3px 9px),linear-gradient(180deg,#6a4430f4,#3a2418f8)!important;border-color:#8a5a3a!important}
.fswbench canvas#fswrod{grid-row:1/3;width:900px;height:230px;align-self:center}.fswname{align-self:end;padding-bottom:6px}.fswname b{display:block;font:400 46px/1 'Pirata One',Georgia,serif;color:#ffe9a0}.fswname small{font:600 14px var(--ui);color:#f0dcc0}
.fswtiers{display:flex;gap:6px;padding-bottom:14px}.fswtiers span{display:flex;flex-direction:column;align-items:center;padding:4px;border-radius:10px;background:#00000030;border:1.5px solid #ffffff18}.fswtiers span.got{border-color:#ffd45a66}.fswtiers span.cur{border-color:#ffd45a;background:#ffd45a22}
.fswtiers canvas{width:96px;height:35px}.fswtiers em{font:700 11.5px var(--ui);font-style:normal;color:#fff8e8}.fswtiers small{font:600 10px var(--ui);color:#d8c8a8}
.fswcol{position:absolute;left:64px;width:700px;top:430px;bottom:24px;overflow-y:auto;scrollbar-width:thin}.fswcol.r{left:796px;width:740px}
.fswu{display:grid;grid-template-columns:64px 1fr auto;align-items:center;gap:12px;padding:10px 14px;margin-bottom:10px}.fswui svg{width:56px;height:56px}
.fswut{display:flex;flex-direction:column;gap:2px}.fswut b{font:800 19px var(--ui)}.fswut small{font:500 13px var(--ui);color:#c4badf}.fswu button,.fswu .fsmax{height:48px;padding:0 16px;border-radius:12px;border:none;background:linear-gradient(180deg,#ffe27a,#f2b631);color:#3a2006;font:800 16px var(--ui);box-shadow:0 4px 0 #9a6a10;display:flex;align-items:center;cursor:pointer}
.fswu button:disabled{filter:grayscale(.8);opacity:.55;cursor:not-allowed}.fswu .fsmax{background:#2a1f6e;color:#ffd45a;box-shadow:none}
.fswlooks{display:grid;grid-template-columns:1fr 1fr;gap:10px}.fswl{display:flex;flex-direction:column;gap:3px;padding:10px 12px;border-radius:16px;background:linear-gradient(180deg,#221a5aee,#100a30f2);border:2px solid #3a3070}.fswl.eq{border-color:var(--sc)}.fswl.lk canvas{opacity:.75}
.fswl canvas{width:100%;height:auto;aspect-ratio:220/70}.fswl b{font:800 15px var(--ui)}.fswl small{font:500 12px/1.3 var(--ui);color:#c4badf}.fswl button{align-self:flex-start;margin-top:4px;height:34px;padding:0 14px;border-radius:10px;border:2px solid #5a4ca0;background:#2a1f6e;color:#fff;font:700 13px var(--ui);cursor:pointer}.fswl button:disabled{opacity:.45;cursor:not-allowed}
@media (prefers-reduced-motion:reduce){.fsjflip{display:none}}`;document.head.appendChild(st)}
