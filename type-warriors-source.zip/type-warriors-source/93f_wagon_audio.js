/* ===== LANTERN CARAVAN: music and sound effects =====
   Built on the riddle's synth helpers (92i: rraBell, rraPizz, rraBsn, rraRec, rraWood, rraTamb, rraDrum, rraBrass, rraNz, rraSched,
   rraFanfare, rraWah ...) with its own resources, players, output chain and hooks, so the two tracks never route through each other.
   Music, "Lantern Road": D major 4/4, crotchet 104 (quaver steps, a light swing), 34 bars, about 78 s a loop:
     intro 2 (harp roll, the pizzicato bass settles) | A 8 (glockenspiel tune over pizzicato bass and the clip-clop)
     | A' 8 (recorder takes the tune, glockenspiel answers) | B 8 (G major lift: legato recorder, harp fills)
     | A'' 8 (recorder and glockenspiel together, bassoon doubles the bass), then back to A. Every other loop swaps the lead.
   Layers follow the run: the clip-clop (the wagon's rhythm) goes quiet while the wagon is stopped; a low drone and a drum come in
   while a monster is within reach of the wagon (the danger layer); a tambourine on every quaver and a bell run during a Flare.
   The hub plays "Lantern Road (camp)": the same tune at crotchet 88 with harp arpeggios and no clip-clop.
   Hand-over: like the riddle, the game's music master (mg) fades out over 1.2 s while the caravan wants music and this track plays
   on its own output (WRAM.vol mirrors the Music setting); leaving fades it back. Mute, zero Music volume or a hidden tab stops it.
   Effects go through sg (the Effects volume); wrSfx from 93c is wrapped so the old beeps are replaced; WRAX.on=0 restores them. */
const WRAM={P:[],duck:0,dt:0,vol:null,dk:null,jg:null,ac:null,pos:{},lvl:.46,W:new WeakMap(),err:0};
const WRAX={on:1,C:null,cac:null};
function wraErr(e){if(WRAM.err++<3)try{console.warn('caravan audio',e)}catch(x){}}
/* own reverb chain per context (the reed wave and noise come from rraRes) */
function wraRes(X){let Wr=WRAM.W.get(X);if(Wr)return Wr;const sr=X.sampleRate;Wr={ready:0};WRAM.W.set(X,Wr);Wr.out=X.createGain();rraRes(X);
 const hp=X.createBiquadFilter();hp.type='highpass';hp.frequency.value=200;hp.Q.value=.6;Wr.rv=hp;
 const len=sr*1.8|0,ir=X.createBuffer(1,len,sr),d=ir.getChannelData(0);let i=0,lp=0;
 const work=n=>{const e=Math.min(len,i+n);for(;i<e;i++){const u=i/len;lp+=((Math.random()*2-1)-lp)*(.6-.45*u);d[i]=lp*Math.pow(1-u,2.4)}return i>=len};
 const fin=()=>{try{const cv=X.createConvolver(),dl=X.createDelay(.05),mx=X.createChannelMerger(2);cv.buffer=ir;dl.delayTime.value=.013;cv.connect(mx,0,0);cv.connect(dl);dl.connect(mx,0,1);mx.connect(Wr.out);hp.connect(cv);Wr.ready=1}catch(e){wraErr(e)}};
 if(rraOff(X)){work(1e9);fin()}else{const go=()=>{try{if(work(16000))fin();else setTimeout(go,0)}catch(e){wraErr(e)}};setTimeout(go,0)}
 return Wr}
/* ---------- the score ---------- */
const WRA_CH=rraBars('D A7 | D G A7 D Bm G A7 A7 | D G A7 D Bm G A7 D | G D Em A7 F#m Bm E7 A7 | D G A7 D Bm G A7 D');
const WRA_M=(()=>{const A=['0:74:2 2:76:1 3:78:1 4:81:3 7:79:1','0:78:2 2:76:1 3:74:1 4:71:3 7:69:1','0:69:1 1:71:1 2:74:1 3:78:1 4:81:2 6:78:1 7:74:1','0:76:3 3:74:1 4:71:2 6:69:1 7:67:1',
  '0:74:2 2:76:1 3:78:1 4:81:3 7:83:1','0:85:2 2:83:1 3:81:1 4:78:3 7:76:1','0:79:1 1:78:1 2:76:1 3:74:1 4:76:2 6:78:1 7:79:1','0:74:4 4:74:1 5:76:1 6:78:1 7:81:1'],
 B=['0:79:3 3:78:1 4:76:2 6:79:2','0:78:4 4:74:1 5:76:1 6:78:2','0:76:3 3:74:1 4:71:2 6:76:2','0:74:2 2:71:2 4:69:4','0:81:3 3:79:1 4:78:2 6:81:2','0:83:3 3:81:1 4:79:2 6:78:2','0:76:2 2:79:2 4:83:2 6:81:1 7:79:1','0:78:2 2:76:2 4:74:1 5:71:1 6:74:1 7:76:1'];
 return rraMel(['','4:69:1 5:71:1 6:73:1 7:74:1',...A,...A,...B,...A])})();
const wraSec=b=>b<2?0:b<10?1:b<18?2:b<26?3:4;
/* D major scale moves for the harmony line */
function wraDia(m,deg){const sc=[0,2,4,5,7,9,11],rel=((m-2)%12+12)%12,i=sc.indexOf(rel);if(i<0)return m+(deg>0?3:-4);const j=i+deg;return m-rel+sc[((j%7)+7)%7]+12*Math.floor(j/7)}
function wraStep(P,t0,bar,k){const X=P.X,B=P.B,sd=P.sd,cm=P.T.calm,c=WRA_CH[bar],sec=wraSec(bar),lp=P.lp,len=(k%2?1-P.sw:1+P.sw)*sd,t=t0+(k%2?P.sw*sd:0),st=P.state(),
 root=rraUp(c.r,38),fifth=root+(root+7>50?-5:7),on=WRA_M[bar].filter(m=>m[0]===k),fill=sec&&(bar-2)%4===3;
 /* bass: pizzicato on 1 and 3 (a bassoon doubles it in A''); calm: one soft bassoon note a bar */
 if(!cm){if(k===0||k===4)rraPizz(X,B.bs,t,[rraF(k?fifth:root)],.11,.3);if(sec===4&&k===0)rraBsn(X,B.bs,t,rraF(root),sd*1.6,.07);if(k===6&&sec>=2&&bar%2)rraPizz(X,B.bs,t,[rraF(root+12)],.06,.2)}
 else{if(k===0)rraBsn(X,B.bs,t,rraF(root),sd*3.2,.06)}
 /* the clip-clop: woodblock on the off-beats, quiet while the wagon stands; calm: harp arpeggio */
 if(!cm){if(st.v>.1&&(k===1||k===3||k===5||k===7))rraWood(X,B.perc,t,k%4===1?1250:980,.075*st.v,.05);
  if(k===2||k===6)rraPizz(X,B.pz,t,rraVc(c,57).map(rraF),sec===4?.045:.036,.24)}
 else{const r=rraUp(c.r,50),th=c.q[1];rraBell(X,B.pz,t,rraF([r,r+7,r+12,r+12+th,r+19,r+12+th,r+12,r+7][k]),k===0?.05:.034,1.3,'harp')}
 /* intro: a harp roll up D major */
 if(bar===0&&k===0)for(let i=0;i<8;i++)rraBell(X,B.sp,t+i*.06,rraF(62+[0,4,7,9][i%4]+12*Math.floor(i/4)),.035,1,'harp');
 /* the tune: glockenspiel in A, recorder in A' and B, both in A''; every other loop the leads swap */
 const rec=sec===2||sec===3,both=sec===4;
 for(const [,p,l] of on){const d=l*sd;
  if((rec&&lp%2===0)||(sec===1&&lp%2===1)){rraRec(X,B.rec,t,rraF(p),d*.9,cm?.04:.052);if(sec===3&&k%4===0)rraBell(X,B.gl,t,rraF(p+12),.02,1,'gl')}
  else{rraBell(X,B.gl,t,rraF(p+12),cm?.05:.066,Math.max(.9,d*1.5),cm?'cel':'gl');if(both||(sec===3&&!cm))rraRec(X,B.rec,t,rraF(wraDia(p,-2)),d*.85,cm?.024:.03)}
  if(both&&!cm&&l>=2)rraBell(X,B.sp,t,rraF(p+24),.014,.6,'spk')}
 /* harp fills answer in B */
 if(sec===3&&k%2&&!on.length){const tn=rraVc(c,74);rraBell(X,B.pz,t,rraF(tn[((k>>1)+bar)%tn.length]),cm?.02:.028,.9,'harp')}
 /* tag: a little bell turn before the loop */
 if(bar===33&&k===6)[86,90,93].forEach((m,j)=>rraBell(X,B.gl,t+j*.07,rraF(m),.04,1.2,'gl'));
 /* percussion fills every fourth bar; a soft drum on 1 in A'' */
 if(!cm){if(fill&&k===6)for(let j=1;j<3;j++)rraWood(X,B.perc,t+j*sd*2/3,j%2?1100:1250,.05);if(sec===4&&k===0)rraDrum(X,B.perc,t,.1,80)}
 /* the danger layer: a low drone each bar and a drum on 1 and 3 while a monster is within reach */
 if(st.danger>0){const u=st.danger;if(k===0)rraBrass(X,B.dr,t,rraF(root-12),sd*7.5,.05*u,0);if(k===0||k===4)rraDrum(X,B.perc,t,.16*u,62);if(k===2||k===6)rraTamb(X,B.perc,t,.03*u,.07)}
 /* a Flare: tambourine on every quaver and a bell run */
 if(st.flare){rraTamb(X,B.perc,t,.045,.08);if(k%2===0)rraBell(X,B.sp,t,rraF(rraVc(c,86)[(k>>1)%3]),.03,.5,'spk')}}
/* tracks: sd seconds per quaver, sw swing, loop bar, section starts (for resuming), gain, buses {name:[dry, reverb send, pan]} */
const WRAT={road:{sd:60/104/2,sw:.09,spb:8,bars:34,loop:2,secs:[0,2,10,18,26],gain:3.3,step:wraStep,
  bus:{gl:[1,.32,.22],pz:[.9,.2,-.2],bs:[.85,.06],rec:[1,.35,-.28],perc:[.75,.12,.3],sp:[.7,.5,.4],dr:[.9,.25,-.1]}},
 camp:{sd:60/88/2,sw:.06,calm:1,spb:8,bars:34,loop:2,secs:[0,2,10,18,26],gain:3.1,step:wraStep,
  bus:{gl:[1,.4,.22],pz:[.9,.38,-.25],bs:[.7,.1],rec:[1,.45,-.3],perc:[.6,.15,.3],sp:[.7,.6,.4],dr:[.6,.3,-.1]}}};
/* ---------- players ---------- */
function wraState(){try{const R=WRX;if(!R||S.mode!=='wagon'||R.over||R.st!=='roll')return{v:0,danger:0,flare:0};const live=e=>e.st!=='dead'&&e.st!=='fling'&&e.st!=='kb';
 return{v:R.pause?0:Math.min(1,R.v/WRT.V),danger:R.pause?0:(R.boss&&!R.bossDone?1:R.mobs.some(e=>live(e)&&e.x<1250)?1:0),flare:!R.pause&&R.flareOn>0}}catch(e){return{v:0,danger:0,flare:0}}}
function wraStart(key,tid,at,fi,X,list,off){const T=WRAT[tid],Wr=wraRes(X),P={key,tid,T,X,list,off,dead:0,sd:T.sd,sw:T.sw,nodes:[],lp:0,state:wraState};
 P.lv=T.gain;P.g=X.createGain();P.gw=X.createGain();P.fs=at;P.fe=at+fi;for(const g of [P.g,P.gw]){g.gain.setValueAtTime(0,X.currentTime);g.gain.setValueAtTime(0,at);g.gain.linearRampToValueAtTime(P.lv,at+fi)}
 P.g.connect(Wr.out);P.gw.connect(Wr.rv);P.B={};for(const k in T.bus){const [d,w,pn]=T.bus[k];let o=P.g;if(pn){o=X.createStereoPanner();o.pan.value=pn;o.connect(P.g);P.nodes.push(o)}
  const b=rraG(X,d,o);P.nodes.push(b);if(w){const s=rraG(X,w,P.gw);b.connect(s);P.nodes.push(s)}P.B[k]=b}
 let b0=0;if(!off){const sv=WRAM.pos[tid]|0;for(const s of T.secs)if(s<=sv)b0=s}P.n=b0*T.spb;P.nt=at;list.push(P);return P}
function wraKill(P,at,fo){let v;if(P.dead){if(P.ke<=at+fo)return;v=at<=P.ka?P.kv:P.kv*Math.max(0,(P.ke-at)/(P.ke-P.ka))}
 else{P.dead=1;v=at>=P.fe?P.lv:at<=P.fs?0:P.lv*(at-P.fs)/(P.fe-P.fs);if(!P.off)WRAM.pos[P.tid]=(P.n/P.T.spb)|0}
 P.ka=at;P.kv=v;P.ke=at+fo;for(const g of [P.g,P.gw])rraFade(g.gain,at,v,0,fo);P.end=at+fo+3}
function wraWant(){try{if(typeof S==='undefined')return null;if(WRX&&S.wr&&(S.mode==='wagon'||S.mode==='over'))return 'road';if(S.mode==='title'&&S.view==='wagon'&&$('wrhub'))return 'camp';return null}catch(e){return null}}
function wraVol(){if(WRAM.vol)WRAM.vol.gain.value=(ST.mute?0:ST.mvol*.6)*WRAM.lvl}
function wraDuck(on,now){WRAM.duck=on?1:0;WRAM.dt=now;const a=mg.gain;rraFade(a,now,a.value,on?0:(ST.mute?0:ST.mvol*.6),1.2)}
function wraPump(){if(!ac||!mg)return;const X=ac,now=X.currentTime,Wr=wraRes(X);
 if(WRAM.ac!==X){WRAM.ac=X;WRAM.P=[];WRAM.vol=X.createGain();WRAM.vol.connect(X.destination);WRAM.dk=X.createGain();Wr.out.connect(WRAM.dk);WRAM.dk.connect(WRAM.vol);WRAM.jg=X.createGain();WRAM.jg.connect(WRAM.vol);wraVol()}
 const want=wraWant(),on=!!want;
 if(on!==!!WRAM.duck)wraDuck(on,now);
 else if(on&&now-WRAM.dt>1.4&&mg.gain.value>.001)mg.gain.setTargetAtTime(0,now,.2);
 const key=on&&!document.hidden&&!ST.mute&&ST.mvol>0&&Wr.ready?want:null,cur=WRAM.P.find(p=>!p.dead);
 if(key){if(!cur||cur.key!==key){for(const p of WRAM.P)wraKill(p,now,1.2);wraStart(key,key,now+.06,1,X,WRAM.P)}}
 else if(cur)for(const p of WRAM.P)wraKill(p,now,document.hidden?.3:1.2);
 for(const p of WRAM.P)if(!p.dead)rraSched(p,now+1.1,2);
 if(WRAM.P.some(p=>p.dead&&now>p.end))WRAM.P=WRAM.P.filter(p=>{if(p.dead&&now>p.end){for(const x of [p.g,p.gw,...p.nodes])try{x.disconnect()}catch(e){}return false}return true})}
function wraJing(kind){try{if(!ac||!WRAM.jg||WRAM.ac!==ac||ST.mute||ST.mvol<=0)return;const X=ac,now=X.currentTime+.03;
 const n=kind==='win'?rraFanfare(X,WRAM.jg,now+.3)+.3:rraWah(X,WRAM.jg,now+.2)+.2,d=WRAM.dk.gain;
 d.cancelScheduledValues(now);d.setValueAtTime(d.value,now);d.linearRampToValueAtTime(.18,now+.15);d.setValueAtTime(.18,now+n);d.linearRampToValueAtTime(1,now+n+1.4)}catch(e){wraErr(e)}}
function wraNow(){const p=WRAM.P.find(q=>!q.dead);return p?{track:p.tid,bar:(p.n/p.T.spb)|0,loop:p.lp}:null}
function wraStats(){return{players:WRAM.P.length,live:RRAM.st.on-RRAM.st.off,duck:WRAM.duck,want:wraWant()}}
/* offline render for level checks */
function wraRender(tid,secs,from,sr){sr=sr||48000;const X=new OfflineAudioContext(2,Math.ceil(sr*secs),sr),Wr=wraRes(X);Wr.out.connect(X.destination);const P=wraStart('off',tid,0,.02,X,[],1);P.n=(from||0)*P.T.spb;P.state=()=>({v:1,danger:0,flare:0});rraSched(P,secs);return X.startRendering()}
/* ---------- hooks ---------- */
{const n0=note;note=function(t,n){try{wraPump()}catch(e){wraErr(e)}if(WRAM.duck&&WRAM.ac===ac){try{rraPump()}catch(e){}try{if(typeof fm7Pump==='function')fm7Pump()}catch(e){}return}return n0.apply(this,arguments)}}
{const a0=applyVol;applyVol=function(){const r=a0.apply(this,arguments);try{wraVol();if(WRAM.duck&&mg&&ac){mg.gain.cancelScheduledValues(ac.currentTime);mg.gain.value=0}}catch(e){}try{wrMuSync()}catch(e){}return r}}
document.addEventListener('visibilitychange',()=>{try{wraPump()}catch(e){}});
{const s0=show;show=function(){const r=s0.apply(this,arguments);try{if(ac&&(WRAM.ac===ac||wraWant()))setTimeout(()=>{try{wraPump()}catch(e){}},0)}catch(e){}return r}}
{const h0=hide;hide=function(){const r=h0.apply(this,arguments);try{if(ac&&(WRAM.ac===ac||wraWant()))setTimeout(()=>{try{wraPump()}catch(e){}},0)}catch(e){}return r}}
/* ---------- sound effects (through sg) ---------- */
function wraFxC(){if(WRAX.cac!==ac||!WRAX.C){WRAX.cac=ac;WRAX.C=rraFxBus(ac,sg)}return WRAX.C}
const WRAFX={
 key(C,t,v){const X=C.X;rraWood(X,C.o,t,(760+Math.min(v||0,30)*14)*(1+(Math.random()-.5)*.04),.085,.045);rraNz(X,C.o,t,.012,.012,4200,'highpass',.7)},
 clink(C,t,v){const X=C.X,f=2400+(v||0)*90;rraBell(X,C.o,t,f,.03,.18,'ting');rraBell(X,C.w,t,f,.016,.2,'ting');rraNz(X,C.o,t,.02,.025,6500,'highpass',.8)},
 miss(C,t){const X=C.X;rraThud(X,C.o,t,150,60,.09,.18);rraNz(X,C.o,t,.12,.03,260,'lowpass',.8,.01)},
 slip(C,t){const X=C.X;rraWood(X,C.o,t,520,.07,.06)},
 none(C,t){const X=C.X;rraWood(X,C.o,t,300,.035,.05)},
 kill(C,t,v){const X=C.X;rraNz(X,C.o,t,.13,.07,3200,'bandpass',1.6,.004,500);rraBell(X,C.pan[3],t+.02,rraF(84+Math.min(8,v||0)),.03,.7,'cry');rraBell(X,C.w,t+.02,rraF(84+Math.min(8,v||0)),.014,.6,'cry');rraThud(X,C.o,t,220,90,.05,.1)},
 jam(C,t){const X=C.X;rraThud(X,C.o,t,160,48,.12,.32);rraNz(X,C.o,t,.3,.05,240,'lowpass',.8,.02);[0,.09].forEach((d,j)=>{rraBell(X,C.o,t+d,1850-j*300,.028,.22,'ting');rraNz(X,C.o,t+d,.03,.03,5200,'highpass',.7)})},
 free(C,t){const X=C.X;rraThud(X,C.o,t,210,90,.09,.14);rraNz(X,C.o,t+.05,.38,.035,900,'bandpass',1.2,.02,300);[86,93].forEach((m,j)=>{rraBell(X,C.pan[2],t+.1+j*.09,rraF(m),.035,.9,'gl');rraBell(X,C.w,t+.1+j*.09,rraF(m),.016,.7,'gl')})},
 hit(C,t){const X=C.X;rraNz(X,C.o,t,.16,.07,2600,'bandpass',1.4,.003,600);rraThud(X,C.o,t,95,38,.11,.4);rraBell(X,C.o,t+.02,rraF(72),.022,.5,'cry');rraBell(X,C.o,t+.02,rraF(73),.018,.45,'cry');rraNz(X,C.w,t,.25,.03,1800,'bandpass',2)},
 flare(C,t){const X=C.X;rraNz(X,C.o,t,.62,.09,380,'bandpass',2,.2,6500);rraNz(X,C.w,t+.2,.5,.04,5000,'bandpass',2,.05,900);
  const o=X.createOscillator(),g=X.createGain();o.frequency.setValueAtTime(280,t);o.frequency.exponentialRampToValueAtTime(1500,t+.5);rraEnv(g,t,.028,.2,.35,.3);o.connect(g);g.connect(C.o);o.start(t);o.stop(t+.75);rraVib(X,[o],t,t+.75,40,9,.05);rraEnd(o,[g]);
  [86,90,93,98,102].forEach((m,j)=>{rraBell(X,C.o,t+.4+j*.06,rraF(m),.026,.8,'gl');rraBell(X,C.w,t+.4+j*.06,rraF(m),.014,.6,'gl')})},
 coin(C,t){const X=C.X,f=1318+Math.random()*300;rraBell(X,C.pan[4],t,f,.014,.25,'ting')},
 milestone(C,t){const X=C.X;[91,96].forEach((m,j)=>rraBell(X,C.o,t+j*.08,rraF(m),.04,1,'gl'))},
 start(C,t){const X=C.X;[74,81].forEach((m,j)=>rraBell(X,C.o,t+j*.1,rraF(m),.035,1,'gl'))},
 leg(C,t){const X=C.X;[79,84].forEach((m,j)=>{rraBell(X,C.o,t+j*.1,rraF(m),.04,1.4,'warm');rraBell(X,C.w,t+j*.1,rraF(m),.02,1,'warm')});rraTamb(X,C.o,t,.03,.08)},
 boss(C,t){const X=C.X;[0,.22,.44].forEach(d=>{rraBsn(X,C.o,t+d,rraF(38),.16,.12);rraDrum(X,C.o,t+d,.2,58)});rraBrass(X,C.o,t+.7,rraF(35),.9,.05,0)}};
function wraFx(kind,v){try{if(!WRAX.on||!ac||!sg||ST.svol<=0)return false;const f=WRAFX[kind];if(!f)return false;if(RRAM.st.on-RRAM.st.off>160&&(kind==='key'||kind==='clink'||kind==='coin'))return true;f(wraFxC(),ac.currentTime+.005,v);return true}catch(e){wraErr(e);return false}}
{const s0=wrSfx;wrSfx=function(k,v){if(WRAX.on){if(k==='gate'){if(wraFx('milestone'))wraJing('win');else s0(k,v);return}if(k==='break'){wraJing('lose');return}if(wraFx(k,v))return}return s0(k,v)}}
/* 8.6: the conductor's whistle, his tongue and his croak */
WRAFX.toot=(C,t)=>{const X=C.X;[0,.17].forEach((d,j)=>{const g=X.createGain(),o=X.createOscillator();o.type='sine';o.frequency.value=j?2100:1760;rraEnv(g,t+d,.04,.01,.13,.05);o.connect(g);g.connect(C.o);g.connect(C.w);o.start(t+d);o.stop(t+d+.24);rraVib(X,[o],t+d,t+d+.24,70,30,.02);rraEnd(o,[g])});rraNz(X,C.o,t,.34,.018,5400,'highpass',.7,.01)};
WRAFX.lash=(C,t)=>{const X=C.X;rraNz(X,C.o,t,.1,.05,700,'bandpass',2,.002,4200);rraThud(X,C.o,t+.115,520,170,.075,.1);rraNz(X,C.o,t+.115,.05,.04,2600,'bandpass',1.4,.002);rraBell(X,C.pan[3],t+.12,rraF(88),.018,.5,'ting')};
WRAFX.croak=(C,t)=>{const X=C.X;[0,.11].forEach((d,j)=>{const o=X.createOscillator(),g=X.createGain(),fl=X.createBiquadFilter();fl.type='lowpass';fl.frequency.value=520;o.type='sawtooth';o.frequency.setValueAtTime(130-j*18,t+d);o.frequency.exponentialRampToValueAtTime(78,t+d+.1);rraEnv(g,t+d,.05,.02,.08,.05);o.connect(fl);fl.connect(g);g.connect(C.o);o.start(t+d);o.stop(t+d+.2);rraEnd(o,[fl,g])})};
