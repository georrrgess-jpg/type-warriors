# python3 t_ac101.py [game.html] : 10.1e save integrity and cheat guard (98t_integrity.js, 00a_acmark.js). Runs with window.TW_AC_TEST
# set so the guard is enforced under automation. Covers the reported extension cheat (coins and level written from a script file,
# then save()), console writes, an injected <script>, swapping P, load() from outside, DEV mode, editing the stored save (with and
# without the signature), exported files (keyed, edited and re-summed, plain JSON), cloud trust, and that the game's own code still
# pays coins and saves normally.
import asyncio,os,sys,json,tempfile
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:400]),flush=True)
    if not ok:FAIL.append(name)
# the same steps as the reported extension (a script file loaded into the page's main world)
CHEAT="""window.twCheatGold=()=>{P.gold=999999999;save();return JSON.parse(sgGet(KEY)).gold};
window.twCheatLevel=()=>{P.xp=lvx(30);P.xpv=3;syncPaths();save();return JSON.parse(sgGet(KEY)).xp};
window.twCheatLoad=()=>{load(Object.assign({},JSON.parse(sgGet(KEY)),{gold:888888888}));save();return P.gold};
window.twCheatPut=()=>{const o=JSON.parse(sgGet(KEY));o.gold=555555555;sgPut(KEY,JSON.stringify(o));return JSON.parse(sgGet(KEY)).gold};"""
SETUP="()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}}"
async def main():
    td=tempfile.mkdtemp();cf=os.path.join(td,'cheat-tool.js');open(cf,'w').write(CHEAT)
    async with async_playwright() as p:
        b=await p.chromium.launch();ctx=await b.new_context(viewport={'width':1600,'height':900})
        await ctx.add_init_script('window.TW_AC_TEST=1')
        pg=await ctx.new_page();er=[];pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate;await E(SETUP)
        r=await E("()=>TWAC.stat()");chk('the guard is on under TW_AC_TEST and knows where the game script starts',r['enforced'] and r['L0']>100,r)
        # a legit balance to start from: paid by the game's own code (rpFinish from a timer whose callback is a game function)
        await E("()=>{RPP();rpStart('moss');RPX.tut=null;RPX.won=true;RPX.free=false;RPX.wave=RPX.map.waves;window.g0=P.gold;setTimeout(rpFinish,0,true)}");await pg.wait_for_timeout(2500)
        r=await E("()=>[g0,P.gold,JSON.parse(sgGet(KEY)).gold]")
        chk('the game itself still pays coins and saves them (a map win)',r[1]>r[0] and r[2]==r[1],r)
        await E("()=>{try{rpLeave()}catch(e){}title()}");await pg.wait_for_timeout(500)
        base=await E("()=>[P.gold,P.xp,lvl(P.xp)]")
        # 1. the reported cheat, from a script file
        await pg.add_script_tag(path=cf);await pg.wait_for_timeout(200)
        r=await E("()=>[twCheatGold(),P.gold,TWAC.stat().blocked]")
        chk('the extension cheat (coins = 999,999,999 then save) is refused: the game and the stored save keep the real coins',r[0]==base[0] and r[1]==base[0] and r[2]>=1,[base,r])
        r=await E("()=>[twCheatLevel(),P.xp,lvl(P.xp)]")
        chk('the extension cheat for the level (XP of level 30) is refused',r[0]==base[1] and r[1]==base[1] and r[2]==base[2],[base,r])
        r=await E("()=>[twCheatLoad(),JSON.parse(sgGet(KEY)).gold]")
        chk('load() with a made-up save from the script is refused',r[0]==base[0] and r[1]==base[0],[base,r])
        r=await E("()=>[twCheatPut(),JSON.parse(sgGet(KEY)).gold]")
        chk('writing the save key from the script (sgPut) is refused',r[1]==base[0],[base,r])
        # 2. console and injected scripts
        r=await E("()=>{P.gold=1e9;P.xp=9e9;P.pres=9;Object.assign(P,{gold:5e8});return [P.gold,P.xp,P.pres|0]}")
        chk('console writes (direct and Object.assign) to coins, XP and prestige are refused',r[0]==base[0] and r[1]==base[1] and r[2]==0,r)
        r=await E("()=>{let a='ok',b='ok';try{Object.defineProperty(P,'gold',{value:1e9})}catch(e){a='threw'}try{delete P.gold}catch(e){b='threw'}return [a,P.gold,b,'gold' in P]}")
        chk('the coins property cannot be redefined or deleted',r[0]=='threw' and r[1]==base[0] and r[3],r)
        r=await E("()=>{const s=document.createElement('script');s.textContent='P.gold=777777777;P.xp=lvx(30)';document.body.appendChild(s);return [P.gold,P.xp]}")
        chk('an injected <script> cannot change them either',r==[base[0],base[1]],r)
        r=await E("()=>{eval('P.gold=666666666');setTimeout('P.gold=444444444',0);return P.gold}");await pg.wait_for_timeout(200)
        r2=await E("()=>P.gold")
        chk('eval and string timers are refused',r==base[0] and r2==base[0],[r,r2])
        r=await E("()=>{const old=P;P=Object.assign({},old,{gold:1e9});save();return [P===old,P.gold,JSON.parse(sgGet(KEY)).gold]}")
        chk('swapping the whole P object is undone before it can be saved',r[0] and r[1]==base[0] and r[2]==base[0],r)
        r=await E("()=>{DEV.on=true;const a=DEV.on;const g=P.gold;try{dvxAct('gold')}catch(e){}return [a,P.gold===g]}")
        chk('DEV mode cannot be switched on from outside, and DEV cheats need it',r==[False,True],r)
        # 3. editing the stored save
        await E("()=>{const o=JSON.parse(localStorage.getItem(KEY));o.gold=999999999;o.xp=lvx(30);localStorage.setItem(KEY,JSON.stringify(o))}")
        await pg.reload();await pg.wait_for_timeout(1800)
        r=await E("()=>[P.gold,P.xp,TWAC.stat().tamper,JSON.parse(sgGet(KEY)).gold]")
        chk('a save edited in browser storage goes back to its last real coins and level on the next start',r[0]==base[0] and r[1]==base[1] and r[2]>=1 and r[3]==base[0],[base,r])
        await pg.wait_for_timeout(1200)
        r=await E("()=>[...document.querySelectorAll('*')].some(e=>e.children.length===0&&/changed outside the game/.test(e.textContent||''))")
        chk('the player is told why',r,r)
        await E("()=>{const o=JSON.parse(localStorage.getItem(KEY));o.gold=999999999;o.xp=lvx(30);localStorage.setItem(KEY,JSON.stringify(o));localStorage.removeItem('typeWarriorsAux')}")
        await pg.reload();await pg.wait_for_timeout(1800)
        r=await E("()=>[P.gold,lvl(P.xp)]")
        chk('deleting the signature as well does not help: coins and level are capped (25,000 / level 8 at most; small login rewards may follow)',r[0]<=27000 and r[1]<=8,r)
        r=await E("()=>{const g=P.gold;P.gold=g;return 1}")
        # 4. exported saves
        await E("()=>{RS_ASK=false;WCRELAYS=[]}")
        r=await E("""()=>{const g=P.gold,x=P.xp;const code=sgCode(),a=sgRead(code);
          const pk=sgPack();const q=JSON.parse(pk.payload);q.gold=900000000;q.xp=lvx(30);pk.payload=JSON.stringify(q);pk.sum=sgHash(pk.payload);const b=sgRead(JSON.stringify(pk));
          const c=sgRead(JSON.stringify(Object.assign(JSON.parse(JSON.stringify(P)),{gold:800000000,xp:lvx(30)})));
          return [a.ok&&a.keyed&&a.P.gold===g&&a.P.xp===x,b.ok,b.P.gold,lvl(b.P.xp),!!b.capped,c.ok,c.P.gold,lvl(c.P.xp),!!c.capped,Math.max(25000,g)]}""")
        chk('a file exported by the game imports untouched (keyed checksum)',r[0],r)
        chk('an exported file edited and re-summed with the public hash imports with coins and level capped',r[1] and r[2]<=r[9] and r[3]<=max(8,base[2]) and r[4],r)
        chk('a hand-made plain JSON save imports with coins and level capped',r[5] and r[6]<=r[9] and r[7]<=max(8,base[2]) and r[8],r)
        chk('no page errors',not er,er)
        await ctx.close()
        # 5. without TW_AC_TEST (automation): the guard stands aside so test suites can set up saves; a first start signs an old save
        ctx2=await b.new_context();pg2=await ctx2.new_page();er2=[];pg2.on('pageerror',lambda e:er2.append(str(e)[:300]))
        await pg2.goto(H);await pg2.wait_for_timeout(1200)
        await pg2.evaluate("()=>{localStorage.setItem(KEY,JSON.stringify(Object.assign(JSON.parse(localStorage.getItem(KEY)||'{}'),{gold:12345,xp:500,own:{rusty:1},ownA:{rags:1}})));localStorage.removeItem('typeWarriorsAux');const m=JSON.parse(localStorage.getItem('typeWarriorsMeta')||'{}');delete m.v2s;localStorage.setItem('typeWarriorsMeta',JSON.stringify(m))}")
        await pg2.reload();await pg2.wait_for_timeout(1500)
        r=await pg2.evaluate("()=>[P.gold,TWAC.stat().enforced,!!localStorage.getItem('typeWarriorsAux'),(P.gold=50,P.gold)]")
        chk('a save from before this version is accepted once and signed; tests (automation) can still set coins',r==[12345,False,True,50],r)
        chk('no page errors (automation run)',not er2,er2)
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
