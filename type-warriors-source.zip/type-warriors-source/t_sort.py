import asyncio,os
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append('PE '+str(e)[:300]))
        await pg.goto('file://'+os.path.abspath('out.html'));await pg.wait_for_timeout(1500);E=pg.evaluate
        await E("()=>{RS_ASK=false;P.gold=51413;P.pets={};['antler','bramble','cinder','ember','beetle','gloom','lily','mosskip','noct','crab'].forEach((k,i)=>P.pets[k]={b:i*40,t:Date.now()-i*1e6});P.pet='ember';P.petSt=2;petNorm();PTX.sel='ember';petHall('Pets')}")
        await pg.wait_for_timeout(1200);await pg.click('#ptsob');await pg.wait_for_timeout(300);await pg.screenshot(path='shots/so_open.png')
        for k in ['rec','rar','bhi','blo','az','new','col']:
            
            if not await E("()=>document.getElementById('ptsom').classList.contains('on')"): await pg.click('#ptsob')
            await pg.wait_for_timeout(200);await pg.click(f'[data-so="{k}"]');await pg.wait_for_timeout(250)
            print(k,await E("()=>[...document.querySelectorAll('.ptc')].map(c=>c.dataset.p).join(',')"),await E("()=>document.getElementById('ptsob').textContent"))
        await pg.click('#ptsob');await pg.wait_for_timeout(150);await pg.keyboard.press('ArrowDown');await pg.keyboard.press('Escape');await pg.wait_for_timeout(200)
        print('esc closes',await E("()=>[document.getElementById('ptsom').classList.contains('on'),document.activeElement.id,!!document.getElementById('pth')]"))
        await E("()=>petHall('Eggs')");await pg.wait_for_timeout(1200);await pg.screenshot(path='shots/so_eggs.png')
        print(er[:4]);await b.close()
asyncio.run(main())
