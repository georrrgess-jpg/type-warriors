/* ===== MOONLIT FISHING: the Angler's Journal, field-guide edition =====
   Replaces the journal screen (fsJournal / fsJList / fsJGrid / fsJStep / fsJPage) with the concept layout:
   rarity tabs with counts, a "Field Guide" heading, a paged 4-column grid of big cards, a painted scene behind
   each fish, a record banner, a size ruler, four stat cards and Previous / n of m / Next paging.
   These are assignments (not declarations) so they replace the wrapped versions from 90l. */
const FSJSCN={frost:'frost',glass:'frost',twilight:'grotto',angler:'grotto',ray:'grotto'};
const fsJScnKey=id=>FISH[id].loc||FSJSCN[id]||'pond';
const FSJSC={};
/* painted underwater scenes, one per spot, cached; soft feathered edges so they melt into the page */
function fsJScene(k){if(FSJSC[k])return FSJSC[k];const W=620,H=262,c=document.createElement('canvas');c.width=W;c.height=H;const g=c.getContext('2d');g.lineJoin='round';g.lineCap='round';
 const R=fsRnd,rock=(x,y,w,h,c0,c1,snow)=>{g.beginPath();g.moveTo(x-w/2,y);g.quadraticCurveTo(x-w*.48,y-h*.7,x-w*.18,y-h);g.quadraticCurveTo(x+w*.1,y-h*1.08,x+w*.34,y-h*.8);g.quadraticCurveTo(x+w*.52,y-h*.46,x+w/2,y);g.closePath();
  g.fillStyle=fkLin(g,x,y-h,x,y,[c1,c0]);g.fill();g.lineWidth=3;g.strokeStyle=FKO;g.stroke();
  g.save();g.clip();g.fillStyle='#ffffff22';g.beginPath();g.moveTo(x-w*.18,y-h);g.quadraticCurveTo(x-w*.3,y-h*.4,x-w*.1,y);g.lineTo(x-w/2,y);g.quadraticCurveTo(x-w*.48,y-h*.7,x-w*.18,y-h);g.fill();g.restore();
  if(snow){g.beginPath();g.moveTo(x-w*.4,y-h*.62);g.quadraticCurveTo(x-w*.32,y-h*1.02,x-w*.18,y-h*1.02);g.quadraticCurveTo(x+w*.12,y-h*1.12,x+w*.36,y-h*.82);g.quadraticCurveTo(x+w*.2,y-h*.7,x+w*.08,y-h*.82);g.quadraticCurveTo(x-w*.1,y-h*.66,x-w*.22,y-h*.78);g.quadraticCurveTo(x-w*.32,y-h*.56,x-w*.4,y-h*.62);g.closePath();
   g.fillStyle=fkLin(g,x,y-h*1.1,x,y-h*.6,['#ffffff','#d8f0ff']);g.fill();g.lineWidth=2.4;g.stroke();
   for(let i=0;i<3;i++){const ix=x-w*.12+i*w*.14,iy=y-h*.78+(i%2)*4;g.beginPath();g.moveTo(ix-4,iy);g.lineTo(ix,iy+10+i*3);g.lineTo(ix+4,iy);g.closePath();g.fillStyle='#e8f8ff';g.fill();g.lineWidth=1.4;g.stroke()}}};
 const weed=(x,y,h,col,sw)=>{g.beginPath();g.moveTo(x-5,y);g.bezierCurveTo(x-5+sw,y-h*.4,x-sw,y-h*.7,x+sw*.4,y-h);g.bezierCurveTo(x-sw*.6,y-h*.66,x+4+sw,y-h*.4,x+5,y);g.closePath();g.fillStyle=col;g.fill();g.lineWidth=2.2;g.strokeStyle=FKO;g.stroke()};
 const pebbles=(y,cols)=>{for(let i=0;i<26;i++){const x=R(i*3.1+1)*W,r=6+R(i*7.7)*13;g.beginPath();g.ellipse(x,y+R(i*1.9)*30,r,r*.62,0,0,TAU);g.fillStyle=cols[i%cols.length];g.fill();g.lineWidth=2;g.strokeStyle=FKO;g.stroke();g.fillStyle='#ffffff30';g.beginPath();g.ellipse(x-r*.3,y+R(i*1.9)*30-r*.25,r*.4,r*.18,0,0,TAU);g.fill()}};
 const rays=(col)=>{g.save();g.globalCompositeOperation='lighter';for(let i=0;i<5;i++){const x=60+i*130+R(i)*40;g.fillStyle=fkLin(g,x,0,x,H,[col,'rgba(0,0,0,0)']);g.beginPath();g.moveTo(x,0);g.lineTo(x+46,0);g.lineTo(x+120,H);g.lineTo(x+40,H);g.closePath();g.fill()}g.restore()};
 const ripples=(col)=>{g.strokeStyle=col;g.lineWidth=2;for(let i=0;i<9;i++){const x=R(i*5.3)*W,y=10+R(i*2.7)*26;g.beginPath();g.moveTo(x-30,y);g.quadraticCurveTo(x,y-6,x+30,y);g.stroke()}};
 if(k==='frost'){g.fillStyle=fkLin(g,0,0,0,H,['#c8f0fa','#6ac4e0','#2a7aa8','#1a4a7a']);g.fillRect(0,0,W,H);rays('rgba(255,255,255,.16)');ripples('#ffffff70');
  g.fillStyle='#ffffff55';for(let i=0;i<40;i++){g.beginPath();g.arc(R(i*9.1)*W,R(i*3.3)*H,1+R(i)*1.6,0,TAU);g.fill()}
  rock(70,H+6,190,170,'#3a5a7e','#8ab0d0',1);rock(20,H+10,110,110,'#2e4a6a','#6a90b4',1);rock(560,H+6,200,190,'#3a5a7e','#8ab0d0',1);rock(616,H+8,110,120,'#2e4a6a','#6a90b4',1);
  weed(150,H,70,'#3a8a7a',10);weed(470,H,84,'#2e7a6a',-12);pebbles(H-26,['#7a98b8','#a8c4dc','#5a7898','#e8f6ff'])}
 else if(k==='grotto'){g.fillStyle=fkLin(g,0,0,0,H,['#3a2a7a','#22185a','#140e3a','#0a0620']);g.fillRect(0,0,W,H);ripples('#9ad8ff55');
  /* stalactite tips */
  for(let i=0;i<8;i++){const x=20+i*82+R(i)*30,h=24+R(i*3)*30;g.beginPath();g.moveTo(x-16,0);g.lineTo(x,h);g.lineTo(x+16,0);g.closePath();g.fillStyle='#1e1640';g.fill();g.lineWidth=2.4;g.strokeStyle=FKO;g.stroke()}
  const crystal=(x,y,s,c0,c1)=>{fkGlow(g,x,y-30*s,70*s,c1,.35);[[-14,-.3,40],[0,0,64],[14,.3,46],[24,.5,30]].forEach(([dx,a,h])=>{g.save();g.translate(x+dx*s,y);g.rotate(a);g.beginPath();g.moveTo(-7*s,0);g.lineTo(-7*s,-h*s*.8);g.lineTo(0,-h*s);g.lineTo(7*s,-h*s*.8);g.lineTo(7*s,0);g.closePath();g.fillStyle=fkLin(g,0,-h*s,0,0,[c1,c0]);g.fill();g.lineWidth=2.2;g.strokeStyle=FKO;g.stroke();g.fillStyle='#ffffff55';g.beginPath();g.moveTo(-5*s,-2);g.lineTo(-5*s,-h*s*.76);g.lineTo(-1*s,-h*s*.9);g.lineTo(-1*s,-2);g.fill();g.restore()})};
  const shroom=(x,y,s,col)=>{fkGlow(g,x,y-34*s,50*s,col,.4);g.fillStyle='#e8e0f8';g.beginPath();g.roundRect(x-5*s,y-34*s,10*s,34*s,4*s);g.fill();g.lineWidth=2;g.strokeStyle=FKO;g.stroke();g.beginPath();g.ellipse(x,y-34*s,26*s,15*s,0,Math.PI,TAU);g.closePath();g.fillStyle=fkLin(g,x,y-50*s,x,y-34*s,['#ffffff',col]);g.fill();g.stroke();g.fillStyle='#ffffffaa';[[-10,-40],[4,-44],[12,-38]].forEach(([a,b])=>{g.beginPath();g.arc(x+a*s,y+b*s,2.4*s,0,TAU);g.fill()})};
  rock(60,H+8,200,150,'#1e1640','#3a2e6a');rock(570,H+8,210,170,'#1e1640','#3a2e6a');crystal(70,H-80,1.2,'#5a2aa8','#d89aff');crystal(560,H-96,1.1,'#1a6a9a','#8ae8ff');shroom(150,H-30,1,'#5ad8ff');shroom(176,H-24,.7,'#9a7aff');shroom(470,H-34,.9,'#c47aff');
  pebbles(H-22,['#2e2456','#3e3270','#24204a']);g.fillStyle='#bfefff';for(let i=0;i<30;i++){g.globalAlpha=.3+R(i*4.4)*.5;g.beginPath();g.arc(R(i*6.1)*W,R(i*2.2)*H*.8+20,1+R(i)*1.5,0,TAU);g.fill()}g.globalAlpha=1}
 else{g.fillStyle=fkLin(g,0,0,0,H,['#5ab4a4','#2e8484','#1e5a62','#123a44']);g.fillRect(0,0,W,H);rays('rgba(255,255,220,.12)');ripples('#ffffff55');
  /* lily pads seen from below, along the surface */
  [[90,6,46],[230,2,34],[520,8,52]].forEach(([x,y,r])=>{g.beginPath();g.ellipse(x,y,r,r*.36,0,.2,TAU-.2);g.lineTo(x,y);g.closePath();g.fillStyle='#1e5a3a';g.fill();g.lineWidth=2.4;g.strokeStyle=FKO;g.stroke();g.strokeStyle='#2e7a4a';g.lineWidth=2;g.beginPath();g.moveTo(x,y+r*.36);g.quadraticCurveTo(x+6,y+60,x-4,H);g.stroke()});
  weed(40,H,150,'#3a8a4a',16);weed(70,H,110,'#4a9a52',-10);weed(18,H,90,'#2e7a40',8);weed(580,H,160,'#3a8a4a',-18);weed(604,H,100,'#4a9a52',10);weed(552,H,80,'#2e7a40',-8);
  rock(110,H+8,130,70,'#3a4a4a','#6a7a72');rock(520,H+8,150,80,'#3a4a4a','#6a7a72');pebbles(H-22,['#8a8a7a','#6a6a5e','#a89a7a','#5a6a62'])}
 /* soft vignette and feathered edges */
 const v=g.createRadialGradient(W/2,H*.55,40,W/2,H*.55,W*.62);v.addColorStop(0,'rgba(0,0,0,0)');v.addColorStop(1,'rgba(10,6,30,.35)');g.fillStyle=v;g.fillRect(0,0,W,H);
 g.globalCompositeOperation='destination-in';const fx=g.createLinearGradient(0,0,W,0);fx.addColorStop(0,'rgba(0,0,0,0)');fx.addColorStop(.06,'#000');fx.addColorStop(.94,'#000');fx.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=fx;g.fillRect(0,0,W,H);
 const fy=g.createLinearGradient(0,0,0,H);fy.addColorStop(0,'rgba(0,0,0,0)');fy.addColorStop(.08,'#000');fy.addColorStop(.9,'#000');fy.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=fy;g.fillRect(0,0,W,H);g.globalCompositeOperation='source-over';
 return FSJSC[k]=c}
/* sepia line-art ornaments */
const FSJO={
 sprig:`<svg viewBox="0 0 40 74" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M20 72C19 52 21 30 27 4"/><path d="M20 60q-13-3-16-15q13 1 16 15zM21 46q12-4 14-16q-12 2-14 16zM22 33q-11-4-12-15q11 3 12 15zM24 20q9-5 9-14q-9 3-9 14z"/></g></svg>`,
 plants:`<svg viewBox="0 0 230 120" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M10 118q4-30 26-34q24-3 30 18q5 16-4 16zM58 118q2-20 22-22q20 0 22 22"/><path d="M38 96q-6 6-4 14M80 104q6 3 6 10"/><path d="M118 118C116 92 120 62 132 30M132 30q-14 8-16 24M128 48q14-6 18-22M124 66q-14 2-20 16M126 80q14-2 20-16M121 96q-12 2-16 14"/><path d="M150 118c2-24 10-40 22-52M172 66q-12 2-14 14M166 76q10 0 14-10M160 90q-10 0-12 10"/><path d="M190 118c-2-16 0-30 8-42M200 118c2-12 8-22 16-28M182 118c-4-10-10-16-18-20"/><path d="M14 112h10M140 116h40"/></g></svg>`,
 corner:`<svg viewBox="0 0 60 60" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M4 56V22Q4 4 22 4h34"/><path d="M12 48V26q0-14 14-14h22"/><path d="M12 26q8 2 10 10q-8 0-10-10zM26 12q2 8 10 10q0-8-10-10z"/><circle cx="4" cy="56" r="2" fill="currentColor"/><circle cx="56" cy="4" r="2" fill="currentColor"/></g></svg>`,
 fish:`<svg viewBox="0 0 34 16" aria-hidden="true"><path d="M3 8q8-8 19-3l8-4-2 7 2 7-8-4Q11 16 3 8z" fill="currentColor"/><circle cx="8" cy="7" r="1.2" fill="#f6ead0"/></svg>`,
 flour:`<svg viewBox="0 0 56 26" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M54 13H20"/><path d="M20 13q-8-10-16-4q6 4 16 4zM20 13q-8 10-16 4q6-4 16-4z"/><path d="M34 13q4-8 10-8M34 13q4 8 10 8"/><circle cx="12" cy="13" r="2" fill="currentColor"/></g></svg>`,
 cFish:`<svg viewBox="0 0 48 32" aria-hidden="true"><path d="M5 16q12-12 28-4l9-7-2 11 2 11-9-7Q17 28 5 16z" fill="#c8a87a" stroke="#5a3a24" stroke-width="2.2" stroke-linejoin="round"/><path d="M20 9q3 7 0 14M27 10q2 6 0 12" fill="none" stroke="#5a3a24" stroke-width="1.6"/><circle cx="11" cy="14" r="2" fill="#3a2414"/></svg>`,
 cCrown:`<svg viewBox="0 0 48 32" aria-hidden="true"><path d="M7 26 4 8l11 8 9-12 9 12 11-8-3 18z" fill="#c8a87a" stroke="#5a3a24" stroke-width="2.2" stroke-linejoin="round"/><path d="M7 26h34v4H7z" fill="#a8885a" stroke="#5a3a24" stroke-width="2"/><circle cx="24" cy="18" r="2.6" fill="#f6ead0" stroke="#5a3a24" stroke-width="1.4"/></svg>`,
 cCoins:`<svg viewBox="0 0 48 32" aria-hidden="true"><g stroke="#5a3a24" stroke-width="2"><ellipse cx="18" cy="26" rx="13" ry="4.5" fill="#a8885a"/><path d="M5 22v4h26v-4" fill="#a8885a"/><ellipse cx="18" cy="22" rx="13" ry="4.5" fill="#c8a87a"/><path d="M5 17v5h26v-5" fill="#a8885a"/><ellipse cx="18" cy="17" rx="13" ry="4.5" fill="#d8bc8a"/><ellipse cx="34" cy="20" rx="9" ry="9" fill="#d8bc8a"/><ellipse cx="34" cy="20" rx="5" ry="5" fill="none" stroke-width="1.6"/></g></svg>`,
 cCal:`<svg viewBox="0 0 48 32" aria-hidden="true"><g stroke="#5a3a24" stroke-width="2.2" stroke-linejoin="round"><rect x="10" y="4" width="28" height="26" rx="4" fill="#f0e2c0"/><path d="M10 12h28" /><rect x="10" y="4" width="28" height="8" rx="3" fill="#c8a87a"/><path d="M17 2v6M31 2v6" stroke-linecap="round"/></g><g fill="#a8885a"><rect x="14" y="16" width="5" height="4"/><rect x="21.5" y="16" width="5" height="4"/><rect x="29" y="16" width="5" height="4"/><rect x="14" y="23" width="5" height="4"/><rect x="21.5" y="23" width="5" height="4"/></g></svg>`,
 moon:`<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M13 2a8 8 0 1 0 5 13A7 7 0 0 1 13 2z" fill="currentColor"/></svg>`,
 trophy:`<svg viewBox="0 0 32 32" aria-hidden="true"><path d="M9 4h14v7a7 7 0 0 1-14 0z" fill="#ffc83a" stroke="#5a3a10" stroke-width="2"/><path d="M9 7H4q0 7 6 8M23 7h5q0 7-6 8" fill="none" stroke="#5a3a10" stroke-width="2"/><path d="M14 18h4v5h-4zM10 24h12v4H10z" fill="#e6a82a" stroke="#5a3a10" stroke-width="2"/><path d="M12 6v5" stroke="#fff6c0" stroke-width="2" stroke-linecap="round"/></svg>`};
FSH.jgp=FSH.jgp||0;
fsJournal=function(id){S.mode='fish';S.view='fishjournal';FS.on=false;const F=fsP();if(id)FSH.jsel=id;if(!FSH.jsel||!FISH[FSH.jsel])FSH.jsel=FIDS.find(i=>F.b[i]&&F.b[i].n)||FIDS[0];
 if(!FSH.jflt)FSH.jflt='all';if(!FSH.jloc)FSH.jloc='all';
 const back=FSH.jback||fsHub,O=FSJO;
 show(`<div class="fsx fsjx fsj2" id="fsx"><canvas id="fsjb" width="1600" height="900" aria-hidden="true"></canvas>
 <div class="fsjbook"><div class="fj-tabs" id="fjtabs"></div><i class="fj-gem fjg-a"></i><i class="fj-gem fjg-b"></i>
  <div class="fsjpg l"><i class="fj-cn fjk-a">${O.corner}</i><i class="fj-cn fjk-b">${O.corner}</i><i class="fj-pl fjp-a">${O.plants}</i><i class="fj-pl fjp-b">${O.plants}</i>
   <header class="fj-hd"><div><h2>Angler's Journal</h2><div class="fj-fg"><i></i>Field Guide<i></i></div></div><div class="fj-cnt"><span id="fsjcount"></span><em><i></i>${O.fish}<i></i></em></div><span class="fj-sprig">${O.sprig}</span></header>
   <div class="fj-spots" id="fjspots"></div>
   <div class="fj-grid" id="fsjgrid"></div><div class="fj-pager" id="fjpager"></div>
   <div class="fj-prog" id="fsjprog"></div>
   <footer class="fj-ft"><span class="fj-orn"><i></i>${O.fish}<i></i></span><span id="fjspot"></span></footer></div>
  <div class="fsjspine"></div>
  <div class="fsjpg r"><i class="fj-cn fjk-a">${O.corner}</i><i class="fj-cn fjk-b">${O.corner}</i><i class="fj-pl fjp-a">${O.plants}</i><i class="fj-pl fjp-b">${O.plants}</i><div id="fsjr" class="fj-r"></div></div><div class="fsjflip" id="fsjflip"></div>
  <nav class="fj-nav"><button class="fj-nb" id="fsjp" aria-label="Previous fish">‹</button><span>Previous</span><i></i><b id="fjpos"></b><i></i><span>Next</span><button class="fj-nb" id="fsjn" aria-label="Next fish">›</button></nav></div>
 <button class="fsback fsg fsjbk" id="fsback"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 5l-7 7 7 7" stroke="currentColor" stroke-width="2.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>Back <kbd>Esc</kbd></button></div>`,'fshx');
 S.back=()=>{FSH.jback=null;back()};$('fsback').onclick=S.back;{const cn=$('cn');if(cn)cn.classList.add('dkhid')}
 const bd=$('fsjb');LIVE.push({cv:bd,fn:fsBackdrop(bd,'rgba(6,3,20,.62)'),slow:3});
 const sp=$('fjspots');const FJSN={pond:'Pond',frost:'Frostfall',grotto:'Grotto',cove:'Cove'};sp.innerHTML=[['all','All spots'],...FSLOCK.filter(k=>!FSLOCS[k].soon).map(k=>[k,FJSN[k]||FSLOCS[k].n.split(' ')[0]])].map(([k,n])=>`<button data-jl="${k}" class="${FSH.jloc===k?'on':''}" style="--lc:${k==='all'?'#c8a87a':FSLOCS[k].c}" title="${k==='all'?'All fishing spots':FSLOCS[k].n}" aria-label="${k==='all'?'All fishing spots':FSLOCS[k].n}${k!=='all'&&!fsLocOpen(k)?' (locked)':''}">${n}${k!=='all'&&!fsLocOpen(k)?' <small>🔒</small>':''}</button>`).join('');
 sp.querySelectorAll('[data-jl]').forEach(b=>b.onclick=()=>{FSH.jloc=b.dataset.jl;FSH.jgp=0;sp.querySelectorAll('[data-jl]').forEach(x=>x.classList.toggle('on',x===b));fsJGrid();fsJNav()});
 $('fsjp').onclick=()=>fsJStep(-1);$('fsjn').onclick=()=>fsJStep(1);
 {const L=fsJList(),k=L.indexOf(FSH.jsel);if(k>=0)FSH.jgp=Math.floor(k/12)}
 fsJGrid();fsJPage(0)};
fsJList=function(rk){rk=rk||FSH.jflt||'all';return FIDS.filter(i=>(rk==='all'||FISH[i].r===rk)&&(!FSH.jloc||FSH.jloc==='all'||FSPOOL[FSH.jloc].includes(i)))};
function fsJNav(){const L=fsJList(),k=L.indexOf(FSH.jsel),e=$('fjpos');if(e)e.textContent=k<0?`– of ${L.length}`:`${k+1} of ${L.length}`}
fsJGrid=function(){const F=fsP(),gd=$('fsjgrid');if(!gd)return;const got=i=>F.b[i]&&F.b[i].n;
 /* tabs with counts (for the current spot) */
 const tb=$('fjtabs');if(tb){tb.innerHTML=[['all','All','#b8a8e8'],...FSRK.map(k=>[k,FSR[k].n,FSR[k].c])].map(([k,l,c])=>{const L=fsJList(k);return `<button data-jf="${k}" class="${FSH.jflt===k?'on':''}" style="--rc:${c}"><b>${l}</b><small>${L.filter(got).length} / ${L.length}</small></button>`}).join('');
  tb.querySelectorAll('[data-jf]').forEach(b=>b.onclick=()=>{if(FSH.jflt===b.dataset.jf)return;FSH.jflt=b.dataset.jf;FSH.jgp=0;try{beep(700,.03,'triangle',.1)}catch(e){}fsJGrid();fsJNav()})}
 const L=fsJList(),all=fsJList('all'),n=all.filter(got).length,gi=all.filter(i=>F.b[i]&&F.b[i].g).length;$('fsjcount').textContent=`${n} / ${all.length} found · ${gi} giant${gi===1?'':'s'}`;
 const sl=$('fjspot');if(sl)sl.textContent=FSH.jloc==='all'?'All fishing spots':FSLOCS[FSH.jloc].n;
 const pages=Math.max(1,Math.ceil(L.length/12));FSH.jgp=Math.max(0,Math.min(pages-1,FSH.jgp||0));const P0=L.slice(FSH.jgp*12,FSH.jgp*12+12),rows=Math.max(2,Math.ceil(P0.length/4));
 gd.style.setProperty('--rows',rows);gd.className='fj-grid r'+rows;
 gd.innerHTML=P0.map(i=>{const b=F.b[i],g0=got(i);const my=FISH[i].r==='m',onlyAt=my&&FISH[i].loc?`Only at ${FSLOCS[FISH[i].loc].n}`:'';return `<button class="fsjen fj-c${g0?'':' unk'}${my?' fj-my':''}${i===FSH.jsel?' on':''}" data-j="${i}" style="--rc:${FSR[FISH[i].r].c}" aria-label="${g0?FISH[i].n:my?'Undiscovered mythic fish. '+onlyAt:'Undiscovered'}"><canvas width="250" height="130"></canvas>${my&&!g0?'<i class="fj-q" aria-hidden="true">?</i>':''}<b>${g0?FISH[i].n:my?onlyAt:'Undiscovered'}</b>${b&&b.g?'<i class="fj-cr">♛</i>':''}${i===fsMoon().feat?'<i class="fj-star">★</i>':''}</button>`}).join('')+Array.from({length:rows*4-P0.length},()=>`<span class="fj-c fj-empty">${FSJO.sprig}</span>`).join('');
 gd.querySelectorAll('[data-j]').forEach(x=>{const i=x.dataset.j,cv=x.querySelector('canvas'),g=cv.getContext('2d');g.clearRect(0,0,250,130);fishFit(g,i,125,66,236,124,{t:.4,sil:got(i)?0:'#6a5440'});
  x.onclick=()=>{if(FSH.jsel!==i){const d=FIDS.indexOf(i)>FIDS.indexOf(FSH.jsel)?1:-1;FSH.jsel=i;gd.querySelectorAll('.fj-c').forEach(e=>e.classList.toggle('on',e===x));fsJPage(d)}}});
 if(!fsRM()){gd.classList.remove('in');void gd.offsetWidth;gd.classList.add('in')}
 const pg=$('fjpager');if(pg){pg.innerHTML=pages>1?`<button data-gp="-1" ${FSH.jgp?'':'disabled'} aria-label="Previous page">‹</button><span>Page ${FSH.jgp+1} of ${pages}</span><button data-gp="1" ${FSH.jgp<pages-1?'':'disabled'} aria-label="Next page">›</button>`:'';pg.querySelectorAll('[data-gp]').forEach(b=>b.onclick=()=>{FSH.jgp+=+b.dataset.gp;try{beep(600,.03,'triangle',.1)}catch(e){}fsJGrid()})}
 const pr=$('fsjprog');if(pr)pr.innerHTML=`<h4>Collection Progress</h4>`+FSRK.map(k=>{const ids=all.filter(i=>FISH[i].r===k),gg=ids.filter(got).length,gz=ids.filter(i=>F.b[i]&&F.b[i].g).length;return `<div class="fj-pr" style="--rc:${FSR[k].c}"><b>${FSR[k].n}</b><span class="fj-pb"><i style="width:${ids.length?gg/ids.length*100:0}%"></i></span><em>${gg} / ${ids.length}</em><small>♛ ${gz}</small></div>`}).join('')+(n===all.length?`<p class="fj-done">Every fish ${FSH.jloc==='all'?'in every spot':'here'} is logged. A true master angler!</p>`:'<p>Undiscovered fish show as shadows. Rare and Legendary fish bite more often with a better lure.</p>')};
fsJStep=function(d){const L=fsJList();if(!L.length)return;let k=L.indexOf(FSH.jsel);k=k<0?(d>0?0:L.length-1):(k+d+L.length)%L.length;FSH.jsel=L[k];const pg=Math.floor(k/12);if(pg!==FSH.jgp){FSH.jgp=pg;fsJGrid()}else ov.querySelectorAll('.fj-c').forEach(e=>e.classList.toggle('on',e.dataset.j===FSH.jsel));fsJPage(d)};
fsJPage=function(dir){const r=$('fsjr');if(!r)return;const id=FSH.jsel,f=FISH[id],R=FSR[f.r],b=fsP().b[id],got=b&&b.n,feat=id===fsMoon().feat,O=FSJO,sk=fsJScnKey(id);
 const lo=fsValue({id,cm:f.len[0],g:0}),hi=fsValue({id,cm:f.len[1],g:0}),gz=f.len[0]+(f.len[1]-f.len[0])*.92,pc=v=>Math.max(0,Math.min(100,(v-f.len[0])/(f.len[1]-f.len[0])*100)).toFixed(1);
 const fmt=ts=>{try{return new Date(ts).toLocaleDateString(undefined,{month:'short',day:'numeric',year:'numeric'})}catch(e){return''}};
 const hint={c:'Common: bites often with any rod.',u:'Uncommon: a little rarer. A better lure helps.',r:'Rare: two words to reel in. Upgrade your lure and line.',l:'Legendary: three words and a long fight. Watch for the full moon.',m:'Mythic: four words and an epic fight.'}[f.r];
 const at=(f.at||[]).map(k=>`<i style="--lc:${FSLOCS[k].c}">${FSLOCS[k].n}${fsLocOpen(k)?'':' 🔒'}</i>`).join('');
 r.innerHTML=`<div class="fsjent fj-ent" style="--rc:${R.c}">
  <div class="fj-top"><span class="fj-no">No. ${FIDS.indexOf(id)+1}</span><span class="fj-rr${f.r==='m'?' my':''}">${R.n}</span>${feat?`<span class="fj-sep"></span><span class="fj-feat">${O.moon}Featured tonight</span>`:''}</div>
  <h3>${got?f.n:'???'}</h3>
  <div class="fj-art"><canvas id="fsjcv" width="620" height="262"></canvas><span class="fj-at"><small>Found at</small>${at}</span>${got&&b.g?'<span class="fj-stamp g">♛ Giant caught</span>':''}${!got?'<span class="fj-stamp u">Not yet caught</span>':''}</div>
  <p class="fj-lore">${got?fsEsc(f.d):f.r==='m'&&f.loc?`A mythic fish, said to live only at ${FSLOCS[f.loc].n}. `+hint:'Only its shadow has been seen. '+hint}</p>
  <div class="fj-rec"><i class="fj-fl">${O.flour}</i><div>${got?`<span>Your record:</span>${O.trophy}<b>${b.big} cm</b>${b.bigT?`<em></em><span>${fmt(b.bigT)}</span>`:''}`:'<span>Catch one to record its size.</span>'}</div><i class="fj-fl fjf-r">${O.flour}</i></div>
  <div class="fj-rule"><div class="fj-rl"><span>${f.len[0]} cm</span><span>${f.len[1]} cm</span></div><div class="fj-bar"><i class="gz" style="left:${pc(gz)}%" title="Giant size"></i>${got?`<i class="mk" style="left:${pc(b.big)}%" title="Your record"></i>`:''}</div><small>Size</small></div>
  <div class="fj-stats"><span><i>${O.cFish}</i><small>Caught</small><b>${got?b.n:0}</b></span><span><i>${O.cCrown}</i><small>Giants</small><b>${got?(b.g||0):0}</b></span><span><i>${O.cCoins}</i><small>Value</small><b>${lo} – ${hi} coins</b></span><span><i>${O.cCal}</i><small>First catch</small><b>${got&&b.t?fmt(b.t):'—'}</b></span></div></div>`;
 fsJNav();
 const scn=fsJScene(sk),bub=[0,1,2,3].map(i=>({x:200+i*70,p:i*.27}));
 live('fsjcv',cv=>{const g=cv.getContext('2d');return t=>{const tt=fsRM()?0:t;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,620,262);g.drawImage(scn,0,0);
  if(!got){g.fillStyle='rgba(40,26,16,.28)';g.fillRect(0,0,620,262)}
  g.fillStyle='rgba(10,6,30,.22)';g.beginPath();g.ellipse(310,236,150,12,0,0,TAU);g.fill();
  if(got&&R.k>=2)fkGlow(g,310,128,200,R.c,.25+.06*Math.sin(tt*2));
  fishFit(g,id,310,128+Math.sin(tt*1.6)*5,430,215,{t:tt,sil:got?0:'#2a1c12',glow:got&&R.k>=2?.5:0});
  if(!got&&f.r==='m'){/* an unknown mythic: a glowing question mark through its shadow */const pu=1+.04*Math.sin(tt*2.2);fkGlow(g,310,128,120,'#ff5ad8',.3+.08*Math.sin(tt*2.2));g.save();g.translate(310,132);g.scale(pu,pu);g.font="400 170px 'Pirata One',Georgia,serif";g.textAlign='center';g.textBaseline='middle';g.lineWidth=10;g.strokeStyle='#1b1024';g.strokeText('?',0,0);const qg=g.createLinearGradient(0,-80,0,80);qg.addColorStop(0,'#fff0ff');qg.addColorStop(.45,'#ff8ae6');qg.addColorStop(1,'#a83aff');g.fillStyle=qg;g.fillText('?',0,0);g.restore()}
  if(got){for(let i=0;i<4;i++){const a=Math.abs(Math.sin(tt*1.8+i*1.7));fkSpark(g,170+i*95+Math.sin(i*3)*20,52+((i*37)%70),3+a*6,'#ffffff',.4+a*.5)}}
  if(!fsRM()){g.strokeStyle='rgba(255,255,255,.55)';g.lineWidth=1.4;bub.forEach(q=>{const u=(tt*.25+q.p)%1;g.beginPath();g.arc(q.x+Math.sin(u*9)*6,240-u*220,2.5+u*2.5,0,TAU);g.stroke()})}}});
 if(dir){const fl=$('fsjflip');if(fl&&!fsRM()){fl.className='fsjflip '+(dir>0?'fw':'bw');void fl.offsetWidth;fl.classList.add('go')}try{beep(dir>0?620:560,.04,'triangle',.14)}catch(e){}}};
{const st=document.createElement('style');st.textContent=`
.fsj2 .fsjbook{background:linear-gradient(180deg,#6a3a22,#4a2414 60%,#3a1c10)}
.fsj2 .fsjpg{background:radial-gradient(130% 100% at 50% 35%,#fbf3de,#f1e2bf 62%,#dcc392);color:#3a2414}
.fsj2 .fsjpg::after{content:'';position:absolute;inset:0;pointer-events:none;background:radial-gradient(60% 40% at 0 100%,#c8a87a33,transparent),radial-gradient(60% 40% at 100% 0,#c8a87a2a,transparent)}
.fj-gem{position:absolute;top:50%;width:14px;height:14px;margin-top:-7px;background:#e6b93e;border:2px solid #1b1024;transform:rotate(45deg);z-index:2}.fj-gem.fjg-a{left:-8px}.fj-gem.fjg-b{right:-8px}
.fj-cn{position:absolute;width:44px;height:44px;color:#b8946a;opacity:.7;pointer-events:none}.fj-cn svg,.fj-pl svg,.fj-sprig svg{display:block;width:100%;height:100%}.fj-cn.fjk-a{left:12px;top:12px}.fj-cn.fjk-b{right:12px;top:12px;transform:scaleX(-1)}
.fj-pl{position:absolute;bottom:6px;width:170px;height:90px;color:#a8845a;opacity:.45;pointer-events:none}.fj-pl.fjp-a{left:8px}.fj-pl.fjp-b{right:8px;transform:scaleX(-1)}
/* tabs */
.fj-tabs{position:absolute;left:58px;top:-30px;display:flex;gap:6px;z-index:2}
.fj-tabs button{display:flex;flex-direction:column;align-items:center;justify-content:center;min-width:92px;height:62px;padding:0 14px 8px;border:3px solid #1b1024;border-bottom:none;border-radius:10px 10px 0 0;background:linear-gradient(180deg,color-mix(in srgb,var(--rc) 70%,#fff),color-mix(in srgb,var(--rc) 78%,#3a2414));color:#1b1024;cursor:pointer;transform:translateY(10px);transition:transform .18s var(--sp)}
.fj-tabs button b{font:800 15px/1.1 var(--ui)}.fj-tabs button small{font:800 14px/1.2 var(--ui);opacity:.85}
.fj-tabs button:hover{transform:translateY(4px)}.fj-tabs button.on{transform:translateY(0);box-shadow:inset 0 0 0 2px #fff6,0 0 0 3px #e6b93e;border-color:#1b1024}
/* left page */
.fj-hd{position:relative;display:flex;align-items:flex-start;justify-content:space-between;padding:34px 34px 0}
.fj-hd h2{margin:0;font:400 54px/1 'Pirata One',Georgia,serif;color:#4a1e0e}
.fj-fg{display:flex;align-items:center;gap:10px;margin-top:2px;font:700 17px 'Cinzel',Georgia,serif;letter-spacing:.2em;color:#5a3a24;text-transform:uppercase}
.fj-fg i{position:relative;width:70px;height:2px;background:#7a5a3a}.fj-fg i::before{content:'';position:absolute;top:-3px;width:6px;height:6px;background:#7a5a3a;transform:rotate(45deg)}.fj-fg i:first-child::before{left:-3px}.fj-fg i:last-child::before{right:-3px}
.fj-cnt{display:flex;flex-direction:column;align-items:center;gap:4px;margin:30px 34px 0 0}.fj-cnt span{font:700 14px 'Cinzel',Georgia,serif;letter-spacing:.06em;color:#5a3a24;text-transform:uppercase}
.fj-cnt em,.fj-orn{display:flex;align-items:center;gap:6px;color:#9a7a5a}.fj-cnt em i,.fj-orn i{width:56px;height:1.5px;background:currentColor}.fj-cnt svg,.fj-orn svg{width:26px;height:12px}
.fj-sprig{position:absolute;right:16px;top:30px;width:30px;height:56px;color:#a8845a;opacity:.8}
.fj-spots{display:flex;gap:6px;padding:12px 30px 0}.fj-spots button{flex:1 1 auto;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.fj-spots button{height:26px;padding:0 8px;border-radius:13px;border:1.5px solid #c8a87a;background:#f6ead0;color:#5a3a24;font:700 11.5px 'Cinzel',Georgia,serif;cursor:pointer}.fj-spots button.on{background:#5a2a14;color:#ffe9a0;border-color:#5a2a14}.fj-spots small{font-size:10px}
.fj-grid{position:absolute;left:30px;right:30px;top:184px;height:298px;display:grid;grid-template-columns:repeat(4,1fr);grid-template-rows:repeat(var(--rows),1fr);gap:10px}
.fj-grid.in .fj-c{animation:fjIn .32s var(--sp) both}.fj-grid.in .fj-c:nth-child(4n+2){animation-delay:.03s}.fj-grid.in .fj-c:nth-child(4n+3){animation-delay:.06s}.fj-grid.in .fj-c:nth-child(4n+4){animation-delay:.09s}@keyframes fjIn{from{opacity:0;transform:translateY(8px) scale(.96)}}
.fsj2 .fj-c{position:relative;min-height:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;padding:6px 6px 8px;border-radius:12px;border:2px solid #d0b088;background:linear-gradient(180deg,#f8eed6,#efdfbb);box-shadow:inset 0 0 0 3px #fbf3de,0 2px 0 #c8a87a66;color:#3a2414;cursor:pointer;transition:transform .16s var(--sp)}
.fsj2 .fj-c canvas{flex:1;min-height:0;width:100%;height:auto;aspect-ratio:auto;object-fit:contain}
.fsj2 .fj-c b{font:700 13px/1.15 'Cinzel',Georgia,serif;text-align:center;min-height:0;display:block}.fsj2 .fj-c.unk b{font:400 15px Georgia,serif;color:#7a6048}
.fj-grid.r3 .fj-c b{font-size:11.5px}.fj-grid.r3 .fj-c.unk b{font-size:13px}
.fsj2 .fj-c:hover{transform:translateY(-3px) rotate(-.6deg)}.fsj2 .fj-c.on{border-color:color-mix(in srgb,var(--rc) 75%,#2a5a2a);background:linear-gradient(180deg,#fffaea,#f6ead0);box-shadow:inset 0 0 0 3px #fffaea,0 0 0 3px color-mix(in srgb,var(--rc) 55%,transparent),0 6px 14px #6a4a2a44}
.fsj2 .fj-empty{cursor:default;background:transparent;border:2px solid #d8c09a66;box-shadow:none;color:#c8a87a;opacity:.6}.fsj2 .fj-empty svg{width:34px;height:60px}.fsj2 .fj-empty:hover{transform:none}
.fj-cr{position:absolute;top:4px;right:8px;font-style:normal;color:#c8901a;font-size:17px}.fj-star{position:absolute;top:3px;left:8px;font-style:normal;color:#2a6ad8;font-size:18px}
.fj-pager{position:absolute;left:30px;right:30px;top:486px;height:26px;display:flex;align-items:center;justify-content:center;gap:12px;font:700 13px 'Cinzel',Georgia,serif;color:#5a3a24}.fj-pager button{width:26px;height:26px;border-radius:50%;border:2px solid #5a3a24;background:#f6ead0;color:#5a3a24;font:800 16px/1 var(--ui);cursor:pointer}.fj-pager button:disabled{opacity:.3;cursor:default}
.fj-prog{position:absolute;left:30px;right:30px;top:514px;padding:7px 18px 6px;border-radius:12px;border:2px dashed #c8a87a;background:#f8eed880}
.fj-prog h4{margin:0 0 2px;font:700 16px 'Cinzel',Georgia,serif;color:#4a1e0e;letter-spacing:.06em}
.fj-pr{display:grid;grid-template-columns:110px 1fr 54px 34px;align-items:center;gap:10px;margin:1px 0}.fj-pr b{font:700 13px 'Cinzel',Georgia,serif;color:#3a2414}
.fj-pb{height:13px;border-radius:7px;border:1.5px solid #8a6a4a;background:#f3e6c8;overflow:hidden}.fj-pb i{display:block;height:100%;background:color-mix(in srgb,var(--rc) 75%,#5a3a24);transition:width .5s ease}
.fj-pr em{font:800 14px var(--ui);font-style:normal;color:#3a2414}.fj-pr small{font:800 12.5px var(--ui);color:#c8901a}
.fj-prog p{margin:3px 0 0!important;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font:italic 13px/1.3 Georgia,serif;color:#6a4a30}.fj-prog p.fj-done{color:#b8801a;font-weight:700}
.fsjpg .fj-ft{position:absolute;left:34px;right:34px;bottom:14px;display:flex;align-items:center;justify-content:center;font:italic 14px Georgia,serif;color:#7a5a3a}.fj-ft #fjspot{position:absolute;right:0}
/* right page */
.fj-ent{position:absolute;inset:0;padding:30px 40px 0;display:flex;flex-direction:column;align-items:stretch;gap:6px}
.fj-top{display:flex;align-items:center;gap:10px;min-height:30px}.fj-no{white-space:nowrap;font:700 15px 'Cinzel',Georgia,serif;color:#5a3a24}
.fj-rr{padding:3px 14px;border-radius:99px;background:color-mix(in srgb,var(--rc) 62%,#2a1a0e);border:2px solid #1b102433;color:#fff;font:800 14px var(--ui)}
.fj-sep{width:2px;height:22px;background:#c8a87a}
.fj-feat{white-space:nowrap;display:inline-flex;align-items:center;gap:6px;height:28px;padding:0 18px 0 14px;background:linear-gradient(180deg,#3a7aff,#2a5ad8);color:#fff;font:800 12.5px var(--ui);letter-spacing:.06em;text-transform:uppercase;clip-path:polygon(0 0,100% 0,94% 50%,100% 100%,0 100%,6% 50%)}.fj-feat svg{width:15px;height:15px}
.fj-at{position:absolute;left:30px;top:10px;display:flex;align-items:center;gap:4px;padding:3px 8px 3px 10px;border-radius:10px;background:#fbf3dee6;border:1.5px solid #c8a87a}.fj-at small{font:700 10px "Cinzel",Georgia,serif;color:#7a5a3a;text-transform:uppercase;margin-right:2px}.fj-at i{font:700 10.5px 'Cinzel',Georgia,serif;font-style:normal;padding:2px 8px;border-radius:8px;background:color-mix(in srgb,var(--lc) 30%,#f6ead0);color:#3a2414;white-space:nowrap}
.fj-ent h3{margin:0;font:400 58px/1 'Pirata One',Georgia,serif;color:#3a1408}
.fj-art{position:relative;height:244px;margin:0 -16px}.fj-art canvas{display:block;width:100%;height:244px;object-fit:cover}
.fj-stamp{position:absolute;right:28px;top:16px;padding:4px 12px;border:3px solid;border-radius:8px;font:800 15px 'Cinzel',Georgia,serif;transform:rotate(7deg);opacity:.9;background:#fbf3dee0}.fj-stamp.g{color:#b8801a;border-color:#b8801a}.fj-stamp.u{color:#7a5a3a;border-color:#7a5a3a;font-size:13px}
.fj-lore{margin:0!important;text-align:center;font:italic 16px/1.3 Georgia,serif;color:#4a3020;min-height:23px}
.fj-rec{display:flex;align-items:center;gap:8px}.fj-fl{width:44px;height:22px;color:#9a7a5a}.fj-fl svg{width:100%;height:100%}.fj-fl.fjf-r{transform:scaleX(-1)}
.fj-rec>div{flex:1;display:flex;align-items:center;justify-content:center;gap:10px;height:44px;border-radius:10px;border:2.5px solid #d8a83a;background:linear-gradient(180deg,#fffaea,#f8ecd0);box-shadow:inset 0 0 0 2px #fffaea}
.fj-rec span{font:700 15px var(--ui);color:#3a2414}.fj-rec svg{width:26px;height:26px}.fj-rec b{font:800 25px var(--ui);color:#1a6a8a}.fj-rec em{width:2px;height:22px;background:#c8a87a}
.fj-rule{position:relative;margin-top:2px}.fj-rl{display:flex;justify-content:space-between;font:600 14px var(--ui);color:#3a2414}
.fj-bar{position:relative;height:18px;margin:3px 0 0;border-radius:9px;border:2px solid #7a5a3a;background:repeating-linear-gradient(90deg,#f8eed6 0 20px,#d8c09a 20px 21.5px)}
.fj-bar .gz{position:absolute;top:0;bottom:0;right:0;border-radius:0 8px 8px 0;background:linear-gradient(90deg,#ffd45a88,#f2b631)}
.fj-bar .mk{position:absolute;top:-6px;width:10px;height:26px;margin-left:-5px;border-radius:4px;border:2px solid #3a2006;background:linear-gradient(180deg,#ffe27a,#c8901a)}
.fj-rule small{display:block;text-align:center;font:700 11px 'Cinzel',Georgia,serif;letter-spacing:.12em;color:#7a5a3a;text-transform:uppercase}
.fj-stats{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.fj-stats span{display:grid;grid-template-columns:52px 1fr;grid-template-rows:auto auto;align-items:center;column-gap:10px;padding:6px 12px;border-radius:10px;border:1.5px solid #d0b088;background:#f8eed8cc}
.fj-stats i{grid-row:1/3;width:48px;height:32px}.fj-stats i svg{width:100%;height:100%}.fj-stats small{font:700 11px 'Cinzel',Georgia,serif;letter-spacing:.08em;color:#5a3a24;text-transform:uppercase}.fj-stats b{font:800 19px/1.1 var(--ui);color:#2a1a0e}
.fj-nav{position:absolute;right:28px;bottom:26px;width:646px;height:72px;display:flex;align-items:center;justify-content:center;gap:16px;font:600 16px var(--ui);color:#3a2414;z-index:3}
.fj-nav i{width:1.5px;height:26px;background:#c8a87a}.fj-nav b{font:600 16px var(--ui);min-width:54px;text-align:center}
.fj-nb{width:54px;height:54px;border-radius:50%;border:3px solid #1b1024;background:linear-gradient(180deg,#ffe27a,#f2b631);color:#3a2006;font:800 30px/1 var(--ui);cursor:pointer;box-shadow:0 4px 0 #9a6a10;transition:transform .15s var(--sp)}.fj-nb:hover{transform:translateY(-2px) scale(1.04)}.fj-nb:active{transform:translateY(2px)}
.fsj2 .fsjflip{z-index:2}/* mythic */.fsj2 .fj-c.fj-my{border-color:#ff8ae6;box-shadow:inset 0 0 0 3px #fbf3de,0 0 0 2px #ff5ad855,0 2px 0 #c8a87a66}.fsj2 .fj-c.fj-my.unk{background:radial-gradient(circle at 50% 40%,#f8e2f4,#efdfbb 70%)}.fsj2 .fj-c.fj-my.unk b{font:700 12px 'Cinzel',Georgia,serif;color:#a8306a}.fj-q{position:absolute;left:50%;top:38%;transform:translate(-50%,-50%);font:400 64px/1 'Pirata One',Georgia,serif;font-style:normal;color:#ff6ad8;-webkit-text-stroke:3px #1b1024;paint-order:stroke;pointer-events:none;animation:fjQ 2.4s ease-in-out infinite}@keyframes fjQ{50%{transform:translate(-50%,-50%) scale(1.08)}}.fj-rr.my{background:linear-gradient(90deg,#ff5ad8,#a86aff,#5ad8ff)!important;border-color:#1b1024!important}`;document.head.appendChild(st)}
