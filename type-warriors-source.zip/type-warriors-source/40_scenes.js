/* ---------- backgrounds ---------- */
function tile(t,step,speed,fn){const o=t*speed,b=Math.floor(o/step);for(let i=-1;i<=Math.ceil(W/step)+1;i++)fn(i*step-(o-b*step),i+b)}
function stars(t,n,ymax){for(let i=0;i<n;i++){const x=rnd(i)*W,y=rnd(i+99)*ymax;ctx.fillStyle=`rgba(255,255,255,${.25+.6*Math.abs(Math.sin(t*(.6+rnd(i+7))+i))})`;const s=1+(i%4===0);ctx.fillRect(x,y,s,s)}}
function moon(x,y,r,c,glowC){glow(ctx,x,y,r*3.4,glowC);ctx.fillStyle=c;ctx.beginPath();ctx.arc(x,y,r,0,TAU);ctx.fill();ctx.fillStyle='#0000001a';for(const [dx,dy,rr] of[[-.3,-.2,.22],[.25,.15,.3],[-.05,.4,.16]]){ctx.beginPath();ctx.arc(x+dx*r,y+dy*r,rr*r,0,TAU);ctx.fill()}}
function fog(t,y,h,c,sp){const g=ctx.createLinearGradient(0,y-h,0,y+h),b=c.slice(0,7);g.addColorStop(0,b+'00');g.addColorStop(.5,c);g.addColorStop(1,b+'00');ctx.fillStyle=g;ctx.fillRect(0,y-h,W,h*2)}
function groundFill(top,bot,rim){const g=ctx.createLinearGradient(0,GY,0,H);g.addColorStop(0,top);g.addColorStop(1,bot);ctx.fillStyle=g;ctx.fillRect(0,GY,W,H-GY);if(rim){const r=ctx.createLinearGradient(0,GY-3,0,GY+22);r.addColorStop(0,rim);r.addColorStop(1,rim.slice(0,7)+'00');ctx.fillStyle=r;ctx.fillRect(0,GY-3,W,25)}}
function pine(x,base,h,w,c,snow){ctx.fillStyle=c;for(let j=0;j<4;j++){const y0=base-h*(.18+j*.24),hw=w*(1-j*.2);ctx.beginPath();ctx.moveTo(x-hw,y0);ctx.lineTo(x,y0-h*.4);ctx.lineTo(x+hw,y0);ctx.closePath();ctx.fill();if(snow){ctx.fillStyle='#e8f4ffcc';ctx.beginPath();ctx.moveTo(x-hw*.55,y0-h*.17);ctx.lineTo(x,y0-h*.4);ctx.lineTo(x+hw*.55,y0-h*.17);ctx.closePath();ctx.fill();ctx.fillStyle=c}}ctx.fillRect(x-w*.09,base-h*.2,w*.18,h*.2)}

function zoneBase(zi,t,sk){const z=ZN[zi],c=ctx;sk=sk||z.sky;
 let g=c.createLinearGradient(0,0,0,GY);g.addColorStop(0,sk[0]);g.addColorStop(1,sk[1]);c.fillStyle=g;c.fillRect(0,0,W,H);
 if(zi===0){stars(t,60,300);moon(W*.78,150,52,'#f2eec0','#f2eec055');
  tile(t,90,5,(x,i)=>pine(x,GY-30,230+rnd(i)*110,52,'#0a2a1e'));
  fog(t,GY-70,90,'#3fbf8a18');
  tile(t,230,13,(x,i)=>{const h=300+rnd(i+3)*140;c.fillStyle='#04140d';c.fillRect(x-12,GY-h*.4,24,h*.4);for(let j=0;j<4;j++){c.beginPath();c.moveTo(x-92+j*10,GY-h*.28-j*h*.19);c.lineTo(x,GY-h*.7-j*h*.19-24);c.lineTo(x+92-j*10,GY-h*.28-j*h*.19);c.fill()}
   if(rnd(i+9)>.55){eye(c,x-8,GY-h*.34,3,'#ffcf3a');eye(c,x+8,GY-h*.34,3,'#ffcf3a')}});
  groundFill('#123a26','#050f0a','#5fe08a55');
  tile(t,22,70,(x,i)=>{c.fillStyle=i%3?'#1f6a3a':'#2a8a4a';const h=10+rnd(i)*16;c.beginPath();c.moveTo(x-5,GY+4);c.lineTo(x+rnd(i+1)*6-3,GY-h+4);c.lineTo(x+5,GY+4);c.fill()});
  tile(t,250,70,(x,i)=>{const y=GY+60+rnd(i)*50;c.fillStyle='#e8e0c8';c.fillRect(x-3,y,6,14);glow(c,x,y,34,'#7dffb055');ell(c,x,y,15,9,'#5fe0a0')});
  for(let i=0;i<34;i++){const x=(rnd(i)*W+t*10*(1+rnd(i+4)))%W,y=GY-30-rnd(i+8)*330+Math.sin(t*1.3+i)*22;c.globalAlpha=.4+.6*Math.abs(Math.sin(t*2+i));glow(c,x,y,10,'#fff08a');c.globalAlpha=1;ell(c,x,y,2,2,'#fff8b0')}}
 else if(zi===1){stars(t,40,260);moon(W*.28,170,86,'#d8e6ff','#a8c4ff55');
  c.fillStyle='#0a1020';c.beginPath();c.moveTo(0,GY-40);for(let x=0;x<=W;x+=80)c.lineTo(x,GY-90-Math.sin(x*.006)*40-rnd(x)*18);c.lineTo(W,GY);c.lineTo(0,GY);c.fill();
  tile(t,300,5,(x,i)=>{c.strokeStyle='#050912';c.lineWidth=9;c.lineCap='round';c.beginPath();c.moveTo(x,GY-30);c.quadraticCurveTo(x-10,GY-150,x+4,GY-260-rnd(i)*80);c.stroke();c.lineWidth=5;for(const [dx,dy,ex,ey] of[[0,-150,-70,-210],[2,-190,60,-260],[-4,-110,50,-160]]){c.beginPath();c.moveTo(x+dx,GY+dy+30);c.quadraticCurveTo(x+dx*.5+ex*.5,GY+dy-10,x+ex,GY+ey+30);c.stroke()}});
  fog(t,GY-30,70,'#9fc0ff14');
  tile(t,150,16,(x,i)=>{const h=70+rnd(i)*70,w=40+rnd(i+2)*14;c.fillStyle='#0c1428';c.beginPath();c.roundRect(x-w/2,GY-h,w,h+8,[w/2,w/2,0,0]);c.fill();c.fillStyle='#ffffff10';c.fillRect(x-w/2,GY-h,5,h);if(i%3===0){c.fillStyle='#070c1a';c.fillRect(x-4,GY-h+12,8,h*.5);c.fillRect(x-14,GY-h+24,28,7)}else{c.strokeStyle='#050912';c.lineWidth=2;c.beginPath();c.moveTo(x-9,GY-h*.5);c.lineTo(x+8,GY-h*.5+8);c.stroke()}});
  tile(t,26,16,(x,i)=>{c.fillStyle='#03060e';c.fillRect(x-2,GY-58,4,60);poly(c,[x-5,GY-58,x,GY-72,x+5,GY-58],'#03060e')});c.fillRect(0,GY-40,W,4);
  groundFill('#141c34','#060912','#9fc0ff44');
  tile(t,240,70,(x,i)=>{const y=GY+50+rnd(i)*60;ell(c,x,y,13,10,'#d8d0b8');ell(c,x,y+9,8,5,'#b8b098');c.fillStyle='#120e0a';c.beginPath();c.arc(x-4,y-1,2.6,0,TAU);c.arc(x+4,y-1,2.6,0,TAU);c.fill()});
  for(let i=0;i<3;i++){const x=((t*(60+i*20)+i*500)%(W+200))-100;ctx.fillStyle='#030610';const y=120+i*60+Math.sin(t*2+i)*14;poly(c,[x-16,y,x-4,y-6,x,y,x+4,y-6,x+16,y,x+6,y+5,x,y+9,x-6,y+5],'#030610')}}
 else if(zi===2){c.fillStyle='#07030f';c.fillRect(0,0,W,60);
  tile(t,240,9,(x,i)=>{const h=130+rnd(i)*170;const cc=i%2?'#c86bff':'#4ae0ff';glow(c,x,GY-h*.45,h*.8+Math.sin(t*2+i)*8,cc+'33');for(let j=0;j<4;j++){const w=14+rnd(i+j)*12,hh=h*(.35+rnd(i+j+5)*.65),xx=x+(j-1.5)*26;poly(c,[xx-w/2,GY-16,xx-w*.3,GY-hh,xx+w*.1,GY-hh-22,xx+w/2,GY-16],shade(cc,-.45),cc,1.6)}});
  fog(t,GY-40,80,'#8a4aff14');
  tile(t,74,8,(x,i)=>{const h=70+rnd(i)*150;c.fillStyle='#0d0618';c.beginPath();c.moveTo(x-22,0);c.lineTo(x+rnd(i+1)*10,h);c.lineTo(x+22,0);c.fill();c.strokeStyle='#ffffff10';c.lineWidth=1.4;c.stroke()});
  tile(t,130,22,(x,i)=>{const h=90+rnd(i+4)*170;c.fillStyle='#120820';c.beginPath();c.moveTo(x-34,GY);c.lineTo(x+rnd(i+2)*14,GY-h);c.lineTo(x+34,GY);c.fill();c.fillStyle='#c86bff14';c.beginPath();c.moveTo(x-8,GY);c.lineTo(x+rnd(i+2)*14,GY-h);c.lineTo(x+8,GY);c.fill()});
  c.strokeStyle='#ffffff18';c.lineWidth=1.2;for(const sx of[0,W]){for(let i=0;i<9;i++){c.beginPath();c.moveTo(sx,0);c.lineTo(Math.abs(sx-W*.24),GY*(.15+i*.09));c.stroke()}for(let r=1;r<5;r++){c.beginPath();for(let i=0;i<=9;i++){const yy=GY*(.15+i*.09),xx=Math.abs(sx-W*.24*(r/4.5));c.lineTo(xx+Math.sin(i+r)*8,yy*(r/4.5))}c.stroke()}}
  groundFill('#1c1030','#08040f','#c86bff44');
  tile(t,200,70,(x,i)=>{const y=GY+56+rnd(i)*54;for(let j=0;j<3;j++)ell(c,x+j*12-12,y+j%2*6,5,7,'#4ae0ff');glow(c,x,y,30,'#4ae0ff44')});
  for(let i=0;i<40;i++){const x=(rnd(i)*W)%W,u=(t*.08*(1+rnd(i+3))+rnd(i+9))%1;c.globalAlpha=.5*(1-u);ell(c,x+Math.sin(t+i)*12,GY-u*560,2.2,2.2,'#e8c8ff');c.globalAlpha=1}}
 else if(zi===3){moon(W*.72,200,110,'#ff9a5a','#ff5a2a66');
  glow(c,W*.72,GY-60,500,'#ff3a0a33');
  c.fillStyle='#1a0606';c.beginPath();c.moveTo(W*.5,GY);c.lineTo(W*.66,GY-250);c.lineTo(W*.74,GY-280);c.lineTo(W*.82,GY-250);c.lineTo(W,GY);c.closePath();c.fill();
  c.strokeStyle='#ff6a1a';c.shadowColor='#ff5a1a';c.shadowBlur=16;c.lineWidth=4;c.beginPath();c.moveTo(W*.74,GY-280);c.quadraticCurveTo(W*.76+Math.sin(t)*6,GY-180,W*.7,GY-90);c.stroke();c.beginPath();c.moveTo(W*.76,GY-270);c.quadraticCurveTo(W*.8,GY-170,W*.86,GY-70);c.stroke();c.shadowBlur=0;
  for(let i=0;i<6;i++){const u=(t*.15+i/6)%1;c.globalAlpha=.35*(1-u);ell(c,W*.74+Math.sin(t+i)*30+u*90,GY-290-u*280,30+u*90,22+u*60,'#2a1210');c.globalAlpha=1}
  tile(t,400,10,(x,i)=>{const w=120+rnd(i)*80,h=180+rnd(i+1)*140;c.fillStyle='#120404';c.fillRect(x,GY-h*.45,w,h*.45);c.fillRect(x+w*.12,GY-h,w*.26,h);for(let k=0;k<4;k++)c.fillRect(x+w*.12+k*w*.09-1,GY-h-12,w*.06,12);c.fillRect(x+w*.7,GY-h*.7,w*.22,h*.7);poly(c,[x+w*.66,GY-h*.7,x+w*.81,GY-h*.7-46,x+w*.96,GY-h*.7],'#120404');
   for(const [wx,wy] of[[x+w*.2,GY-h*.85],[x+w*.2,GY-h*.6],[x+w*.78,GY-h*.5]]){const fl=.6+.4*Math.sin(t*9+wx);c.fillStyle=`rgba(255,${150+fl*60|0},40,${fl})`;c.fillRect(wx,wy,8,16)}});
  fog(t,GY-50,90,'#ff4a1a22');
  groundFill('#2e1410','#0a0404','#ff7a2a77');
  tile(t,140,50,(x,i)=>{const p=.6+.4*Math.sin(t*3+i);c.strokeStyle=`rgba(255,${100+p*80|0},30,${p})`;c.lineWidth=3;c.shadowColor='#ff5a1a';c.shadowBlur=10;c.beginPath();c.moveTo(x,GY+40+rnd(i)*40);c.lineTo(x+30,GY+58+rnd(i+1)*40);c.lineTo(x+52,GY+44+rnd(i+2)*50);c.lineTo(x+96,GY+70+rnd(i+3)*40);c.stroke();c.shadowBlur=0});
  for(let i=0;i<70;i++){const x=(rnd(i)*W+Math.sin(t+i)*20)%W,u=(t*.15*(1+rnd(i+2))+rnd(i+6))%1;c.globalAlpha=1-u;ell(c,x,GY-u*720+40,2.2,2.2,i%2?'#ffb84a':'#ff5a2a');c.globalAlpha=1}}
 else if(zi===4){
  for(let k=0;k<3;k++){const cc=['#4affb0','#4ac8ff','#b06bff'][k];c.beginPath();c.moveTo(0,90+k*40);for(let x=0;x<=W;x+=40)c.lineTo(x,90+k*40+Math.sin(x*.005+t*(.5+k*.2)+k)*46);c.lineTo(W,300+k*30);for(let x=W;x>=0;x-=40)c.lineTo(x,240+k*40+Math.sin(x*.007+t*.6+k)*38);c.closePath();const q=c.createLinearGradient(0,60,0,340);q.addColorStop(0,cc+'55');q.addColorStop(1,cc+'00');c.fillStyle=q;c.fill()}
  stars(t,80,300);
  tile(t,340,4,(x,i)=>{const h=300+rnd(i)*180;poly(c,[x-190,GY,x,GY-h,x+190,GY],'#1a2c4a');poly(c,[x-56,GY-h*.72,x,GY-h,x+62,GY-h*.7,x+20,GY-h*.78,x-8,GY-h*.66],'#dcecff')});
  tile(t,260,9,(x,i)=>{const h=200+rnd(i+2)*120;poly(c,[x-140,GY,x+rnd(i)*40,GY-h,x+150,GY],'#2a4468');poly(c,[x-38+rnd(i)*40,GY-h*.7,x+rnd(i)*40,GY-h,x+40+rnd(i)*40,GY-h*.68],'#eef8ff')});
  fog(t,GY-40,80,'#bfe4ff22');
  tile(t,120,20,(x,i)=>pine(x,GY+6,150+rnd(i)*90,40,'#0e2038',1));
  groundFill('#8fb0d0','#2a3a5a','#ffffff99');
  tile(t,90,70,(x,i)=>{c.fillStyle='#ffffff30';c.beginPath();c.ellipse(x,GY+30+rnd(i)*80,40,7,0,0,TAU);c.fill()});
  tile(t,200,70,(x,i)=>{const y=GY+70+rnd(i)*40;poly(c,[x-8,y,x-2,y-30-rnd(i)*20,x+5,y],'#bfeaff','#fff',1.4);poly(c,[x+4,y,x+12,y-20,x+18,y],'#8fd0f0')});
  for(let i=0;i<160;i++){const x=(rnd(i)*W+Math.sin(t*.8+i)*30-t*16*(1+rnd(i+1)))%W,y=(rnd(i+5)*H+t*(50+rnd(i+2)*70))%H;c.fillStyle=`rgba(255,255,255,${.4+rnd(i+3)*.5})`;c.fillRect((x+W)%W,y,2+(i%3===0),2+(i%3===0))}}
 else{
  for(let i=0;i<7;i++){const x=(i*280+Math.sin(t*.4+i)*50)%W;c.fillStyle='#9ff8e00d';c.beginPath();c.moveTo(x,0);c.lineTo(x+130,0);c.lineTo(x+260+Math.sin(t*.5+i)*40,GY);c.lineTo(x+40,GY);c.closePath();c.fill()}
  tile(t,300,6,(x,i)=>{const h=240+rnd(i)*160,w=40;c.fillStyle='#04262c';c.fillRect(x-w/2,GY-h,w,h);poly(c,[x-w/2-4,GY-h,x-w/2+8,GY-h-16,x+w/2+4,GY-h-6,x+w/2+4,GY-h],'#04262c');c.fillStyle='#063a44';c.fillRect(x-w/2,GY-h,6,h);if(i%2){c.strokeStyle='#04262c';c.lineWidth=36;c.beginPath();c.arc(x+150,GY-h+20,150,Math.PI,Math.PI*1.5);c.stroke()}});
  for(let k=0;k<3;k++){const y=140+k*70,x=((t*(30+k*14)+k*400)%(W+300))-150;c.fillStyle='#04262ccc';for(let f=0;f<7;f++){const fx=x+f*34,fy=y+Math.sin(t+f+k)*14;poly(c,[fx-12,fy,fx,fy-5,fx+12,fy,fx,fy+5],'#04262c');poly(c,[fx+10,fy,fx+18,fy-5,fx+18,fy+5],'#04262c')}}
  fog(t,GY-50,90,'#5fffe018');
  tile(t,170,17,(x,i)=>{c.strokeStyle=i%2?'#0a4048':'#0c5a5e';c.lineWidth=12;c.lineCap='round';const h=90+rnd(i)*100;c.beginPath();c.moveTo(x,GY+4);c.lineTo(x+Math.sin(t+i)*4,GY-h*.5);c.stroke();for(const s of[-1,1]){c.lineWidth=8;c.beginPath();c.moveTo(x,GY-h*.4);c.quadraticCurveTo(x+s*24,GY-h*.7,x+s*36+Math.sin(t*1.5+i)*4,GY-h);c.stroke()}});
  groundFill('#1a5a5c','#082a30','#7fffe044');
  tile(t,60,70,(x,i)=>{c.strokeStyle=i%2?'#1f8a4a':'#2aa860';c.lineWidth=4;c.lineCap='round';const h=40+rnd(i)*50;c.beginPath();c.moveTo(x,GY+30+rnd(i+1)*80);c.quadraticCurveTo(x+Math.sin(t*1.6+i)*14,GY-h*.1+50,x+Math.sin(t*1.6+i+1)*18,GY+70-h);c.stroke()});
  tile(t,300,70,(x,i)=>{const y=GY+90+rnd(i)*30;ell(c,x,y,14,10,'#f0d8c0');c.strokeStyle='#c0a890';c.lineWidth=1.4;c.beginPath();c.moveTo(x,y-9);c.lineTo(x,y+9);c.moveTo(x-8,y-6);c.lineTo(x-8,y+6);c.moveTo(x+8,y-6);c.lineTo(x+8,y+6);c.stroke()});
  for(let i=0;i<50;i++){const x=rnd(i)*W+Math.sin(t+i)*14,u=(t*.12*(1+rnd(i+2))+rnd(i+6))%1;c.strokeStyle=`rgba(200,255,250,${.5*(1-u)})`;c.lineWidth=1.4;c.beginPath();c.arc(x,H-u*(H+20),2+rnd(i+4)*5,0,TAU);c.stroke()}}
}

/* ---------- per-level scenery: props, weather and tint on top of a base scene ---------- */
const PROPS={
scarecrow:(c,x,i,a)=>{c.fillStyle='#0a0612';c.fillRect(x-4,GY-210,8,210);c.fillRect(x-58,GY-160,116,7);c.beginPath();c.moveTo(x-34,GY-215);c.lineTo(x,GY-262);c.lineTo(x+34,GY-215);c.fill();c.fillRect(x-40,GY-216,80,6);c.beginPath();c.arc(x,GY-190,17,0,TAU);c.fill();for(const dx of[-52,-44,44,52]){c.fillRect(x+dx,GY-156,3,32)}eye(c,x-6,GY-192,2.6,a);eye(c,x+6,GY-192,2.6,a)},
columns:(c,x,i,a)=>{const h=180+rnd(i)*120,w=44;c.fillStyle='#0c0a14';c.fillRect(x-w/2,GY-h,w,h);c.fillRect(x-w/2-8,GY-h-12,w+16,14);c.fillRect(x-w/2-10,GY-14,w+20,14);c.strokeStyle='#ffffff14';c.lineWidth=2;for(let k=-1;k<=1;k++){c.beginPath();c.moveTo(x+k*12,GY-h);c.lineTo(x+k*12,GY-16);c.stroke()}c.fillStyle='#04030a';c.beginPath();c.moveTo(x-w/2-8,GY-h-12);c.lineTo(x-4+rnd(i+4)*14,GY-h-40);c.lineTo(x+w/2+8,GY-h-12);c.fill();glow(c,x,GY-h*.5,90,a+'18')},
gallows:(c,x,i,a)=>{c.fillStyle='#08050e';c.fillRect(x-70,GY-230,10,230);c.fillRect(x-70,GY-230,130,9);poly(c,[x-60,GY-190,x-30,GY-230,x-60,GY-222],'#08050e');c.strokeStyle='#08050e';c.lineWidth=3;const sw=Math.sin(ctxT*1.4+i)*6;c.beginPath();c.moveTo(x+40,GY-222);c.lineTo(x+40+sw,GY-160);c.stroke();c.beginPath();c.ellipse(x+40+sw,GY-152,10,12,0,0,TAU);c.stroke();glow(c,x+40,GY-100,70,a+'14')},
banners:(c,x,i,a)=>{const h=250+rnd(i)*80,sw=Math.sin(ctxT*2.2+i)*10;c.fillStyle='#08060c';c.fillRect(x-3,GY-h,6,h);c.beginPath();c.moveTo(x+3,GY-h+8);c.quadraticCurveTo(x+40+sw,GY-h+30,x+70+sw*1.5,GY-h+22);c.lineTo(x+62+sw*1.5,GY-h+70);c.lineTo(x+70+sw*1.5,GY-h+112);c.quadraticCurveTo(x+40+sw,GY-h+90,x+3,GY-h+110);c.fill();c.fillStyle=a+'44';c.beginPath();c.arc(x+30+sw*.6,GY-h+62,12,0,TAU);c.fill()},
bones:(c,x,i,a)=>{c.strokeStyle='#d8d0c0';c.globalAlpha=.16;c.lineWidth=13;c.lineCap='round';for(let k=0;k<6;k++){c.beginPath();c.moveTo(x-90+k*36,GY);c.quadraticCurveTo(x-90+k*36+10,GY-170-k%2*30,x-58+k*36,GY-26);c.stroke()}c.lineWidth=16;c.beginPath();c.moveTo(x-110,GY-4);c.lineTo(x+130,GY-4);c.stroke();c.globalAlpha=1},
crystals:(c,x,i,a)=>{for(let k=0;k<4;k++){const h=80+rnd(i+k)*170,w=18+rnd(i+k+9)*16,xx=x+(k-1.5)*30;poly(c,[xx-w/2,GY,xx-w*.3,GY-h*.85,xx,GY-h,xx+w*.4,GY-h*.8,xx+w/2,GY],a+'33',a+'99',1.4)}glow(c,x,GY-90,150,a+'33')},
masts:(c,x,i,a)=>{c.fillStyle='#08070c';c.save();c.translate(x,GY);c.rotate(-.07+rnd(i)*.14);c.fillRect(-4,-320,8,330);c.fillRect(-70,-280,140,6);c.fillRect(-52,-190,104,5);c.beginPath();c.moveTo(-64,-276);c.quadraticCurveTo(-30,-240+Math.sin(ctxT*2+i)*8,-56,-196);c.lineTo(56,-196);c.quadraticCurveTo(30,-240,64,-276);c.fill();c.restore()},
obelisk:(c,x,i,a)=>{const h=240+rnd(i)*100;poly(c,[x-30,GY,x-22,GY-h,x,GY-h-34,x+22,GY-h,x+30,GY],'#0a0810');c.strokeStyle=a;c.globalAlpha=.5+.4*Math.sin(ctxT*2+i);c.lineWidth=2.4;for(let k=0;k<4;k++){c.beginPath();c.moveTo(x-8,GY-h*.2-k*46);c.lineTo(x+8,GY-h*.2-k*46-10);c.lineTo(x-4,GY-h*.2-k*46-26);c.stroke()}c.globalAlpha=1;glow(c,x,GY-h*.5,120,a+'22')},
statues:(c,x,i,a)=>{c.fillStyle='#0a0912';c.fillRect(x-30,GY-40,60,40);c.fillRect(x-20,GY-150,40,112);c.beginPath();c.arc(x,GY-166,16,0,TAU);c.fill();c.fillRect(x-42,GY-140,84,10);c.fillRect(x+30,GY-190,5,120);poly(c,[x+28,GY-190,x+33,GY-212,x+38,GY-190],'#0a0912');eye(c,x-5,GY-168,1.8,a);eye(c,x+6,GY-168,1.8,a)},
lanterns:(c,x,i,a)=>{c.fillStyle='#08060a';c.fillRect(x-3,GY-230,6,230);c.fillRect(x-3,GY-230,58,5);c.strokeStyle='#08060a';c.lineWidth=2;c.beginPath();c.moveTo(x+50,GY-226);c.lineTo(x+50,GY-204);c.stroke();const fl=.8+.2*Math.sin(ctxT*8+i*3);glow(c,x+50,GY-190,110*fl,'#ffb84a66');c.fillStyle='#ffd88a';c.fillRect(x+42,GY-204,16,22);c.strokeStyle='#08060a';c.strokeRect(x+42,GY-204,16,22)},
arch:(c,x,i,a)=>{const w=190,h=310;c.fillStyle='#090711';c.fillRect(x-w/2-26,GY-h,26,h);c.fillRect(x+w/2,GY-h,26,h);c.beginPath();c.moveTo(x-w/2-26,GY-h);c.quadraticCurveTo(x,GY-h-150,x+w/2+26,GY-h);c.lineTo(x+w/2+26,GY-h+34);c.quadraticCurveTo(x,GY-h-104,x-w/2-26,GY-h+34);c.fill();glow(c,x,GY-h*.4,150,a+'2a');c.fillStyle=a+'12';c.fillRect(x-w/2,GY-h+30,w,h-30)}};
let ctxT=0;
function weather(type,t,a){const c=ctx;c.save();
 if(type==='rain'){c.strokeStyle='#b8d0ff55';c.lineWidth=1.4;for(let i=0;i<110;i++){const x=(rnd(i)*W*1.2+t*260*(.5+rnd(i+3)))%(W*1.2)-100,y=(rnd(i+9)*H+t*900*(.7+rnd(i+5)))%H;c.beginPath();c.moveTo(x,y);c.lineTo(x-10,y+24);c.stroke()}}
 else if(type==='snow'){c.fillStyle='#ffffffcc';for(let i=0;i<90;i++){const x=(rnd(i)*W+t*(24+rnd(i+2)*30)+Math.sin(t+i)*20)%W,y=(rnd(i+7)*H+t*(50+rnd(i+4)*60))%H,r=1.4+rnd(i+3)*2.4;c.globalAlpha=.4+rnd(i+1)*.5;c.beginPath();c.arc(x,y,r,0,TAU);c.fill()}}
 else if(type==='ash'){for(let i=0;i<70;i++){const x=(rnd(i)*W+t*(20+rnd(i+2)*28))%W,y=(rnd(i+7)*H+t*(26+rnd(i+4)*40))%H;c.globalAlpha=.25+rnd(i+1)*.4;c.fillStyle=i%5?'#a8a8b0':'#ff8a4a';c.fillRect(x,y,2+rnd(i+3)*3,2+rnd(i+5)*2)}}
 else if(type==='sand'||type==='wind'){c.strokeStyle=type==='sand'?'#e8c88a55':'#ffffff44';c.lineWidth=1.6;for(let i=0;i<60;i++){const y=rnd(i)*H,x=((rnd(i+3)*W*1.5-t*(500+rnd(i+6)*400))%(W*1.5)+W*1.5)%(W*1.5)-100,l=60+rnd(i+8)*120;c.globalAlpha=.4+rnd(i+1)*.4;c.beginPath();c.moveTo(x,y);c.lineTo(x+l,y-4);c.stroke()}}
 else if(type==='embers'){for(let i=0;i<60;i++){const u=(t*(.12+rnd(i)*.16)+rnd(i+5))%1,x=rnd(i+2)*W+Math.sin(t*1.4+i)*24,y=H-u*(H+60);c.globalAlpha=(1-u)*.9;glow(c,x,y,9,'#ff8a3a');ell(c,x,y,2,2,'#ffe08a')}}
 else if(type==='spores'||type==='motes'){const col=type==='spores'?a:'#dfe8ff';for(let i=0;i<46;i++){const x=(rnd(i)*W+t*12*(1+rnd(i+4)))%W,y=GY-20-rnd(i+8)*430+Math.sin(t*1.1+i)*26;c.globalAlpha=.25+.6*Math.abs(Math.sin(t*1.6+i));glow(c,x,y,14,col+'88');c.globalAlpha=.9;ell(c,x,y,1.8,1.8,col)}}
 c.restore()}
function zoneBG(zi,t,L){ctxT=t;if(L&&typeof SCN!=='undefined'&&SCN[L.i]){sceneGen(SCN[L.i],t);return}zoneBase(zi,t,L&&L.sky||null);if(!L)return;const c=ctx;
 if(L.tint){c.save();c.globalCompositeOperation='overlay';c.globalAlpha=.42;c.fillStyle=L.tint;c.fillRect(0,0,W,H);c.restore();c.save();c.globalCompositeOperation='soft-light';c.globalAlpha=.25;c.fillStyle=L.tint;c.fillRect(0,0,W,H);c.restore()}
 if(L.prop&&PROPS[L.prop]){c.save();c.globalAlpha=.92;const sp=L.prop==='lanterns'||L.prop==='banners'?26:18;tile(t,L.prop==='arch'?760:L.prop==='bones'||L.prop==='gallows'?640:460,sp,(x,i)=>{if(rnd(i+41)>.24)PROPS[L.prop](c,x,i,L.a)});c.restore()}
 if(L.wx)weather(L.wx,t,L.a)}
function menuBG(t){const c=ctx,g=c.createLinearGradient(0,0,0,GY);g.addColorStop(0,'#08051c');g.addColorStop(.55,'#36154a');g.addColorStop(1,'#b8503a');c.fillStyle=g;c.fillRect(0,0,W,H);
 stars(t,90,420);moon(W*.76,150,112,'#ff8f8a','#ff3a5a66');
 for(let i=0;i<5;i++){const x=((i*420+t*10)%(W+500))-250;c.fillStyle='#ffffff09';c.beginPath();c.ellipse(x,150+i*46,240,26,0,0,TAU);c.fill()}
 c.fillStyle='#1c0c2c';c.beginPath();c.moveTo(0,GY);for(let x=0;x<=W;x+=60)c.lineTo(x,GY-160-Math.sin(x*.004+1)*90-rnd(x)*40);c.lineTo(W,GY);c.fill();
 const cx=W*.68+Math.sin(t*.1)*6,cyy=GY-270;c.fillStyle='#10061c';c.beginPath();c.moveTo(cx-260,GY);c.lineTo(cx-200,cyy+120);c.lineTo(cx+220,cyy+90);c.lineTo(cx+300,GY);c.fill();
 for(const [dx,h,w] of[[-150,250,66],[-40,330,84],[90,280,70],[190,200,54],[-220,150,44]]){c.fillRect(cx+dx-w/2,cyy+150-h+100,w,h);for(let k=0;k<4;k++)c.fillRect(cx+dx-w/2+k*w/4,cyy+150-h+88,w/6,14);poly(c,[cx+dx-w/2-6,cyy+150-h+100,cx+dx,cyy+150-h+100-w*1.1,cx+dx+w/2+6,cyy+150-h+100],'#10061c')}
 for(let i=0;i<14;i++){const wx=cx-220+rnd(i)*440,wy=cyy+120+rnd(i+3)*210,fl=Math.sin(t*3+i*2)>-.35;c.fillStyle=fl?'#ffc94a':'#8a5a20';c.fillRect(wx,wy,7,13);if(fl)glow(c,wx+3,wy+6,20,'#ffb04a44')}
 const fy=cyy-70;limb(c,cx-40,fy+40,cx-40,fy-50,3,'#10061c');poly(c,[cx-40,fy-50,cx-40+60+Math.sin(t*3)*8,fy-38,cx-40,fy-24],'#8a1a2a');
 const dxp=((t*90)%(W+500))-250,dy=190+Math.sin(t*.9)*30+Math.sin(t*3)*4,fw=Math.sin(t*5);c.save();c.translate(dxp,dy);c.scale(.9,.9);c.fillStyle='#0a0414';c.beginPath();c.ellipse(0,0,46,14,0,0,TAU);c.fill();poly(c,[40,0,90,6,40,8],'#0a0414');poly(c,[-40,-4,-70,-10,-62,4,-44,6],'#0a0414');
 for(const k of[0,1]){c.save();c.translate(-6,-6);c.scale(1,fw*(k?.7:1));c.fillStyle=k?'#1a0a28':'#0a0414';c.beginPath();c.moveTo(0,0);c.quadraticCurveTo(-50,-70,-92,-60);c.quadraticCurveTo(-64,-40,-74,-20);c.quadraticCurveTo(-40,-24,0,0);c.fill();c.restore()}c.restore();
 fog(t,GY-20,110,'#ff8a5a22');
 c.fillStyle='#0a0414';c.beginPath();c.moveTo(0,GY+10);for(let x=0;x<=W;x+=50)c.lineTo(x,GY-24-Math.sin(x*.01)*16-rnd(x+3)*20);c.lineTo(W,H);c.lineTo(0,H);c.fill();
 tile(t,180,0,(x,i)=>pine(x+40,GY+24,120+rnd(i)*80,36,'#08030f'));
 groundFill('#0e0618','#04020a','#ff8a5a55');
 for(const x of[W*.36,W*.9]){const f=8+Math.sin(t*14+x)*2.4;c.fillStyle='#2a1608';c.fillRect(x-3,GY-14,6,50);glow(c,x,GY-30,60,'#ff9a2a55');ell(c,x,GY-24,f*.8,f*1.5,'#ffb04a');ell(c,x,GY-22,f*.45,f,'#fff0a0')}
 for(let i=0;i<70;i++){const x=(rnd(i)*W+Math.sin(t*.8+i)*30)%W,u=(t*.12*(1+rnd(i+2))+rnd(i+5))%1;c.globalAlpha=1-u;ell(c,x,GY-u*760+80,2,2,i%3?'#ffb04a':'#ff6a2a');c.globalAlpha=1}}
function vignette(){const g=ctx.createRadialGradient(W/2,H/2,H*.55,W/2,H/2,H*1.08);g.addColorStop(0,'#0000');g.addColorStop(1,'#00000088');ctx.fillStyle=g;ctx.fillRect(0,0,W,H)}
