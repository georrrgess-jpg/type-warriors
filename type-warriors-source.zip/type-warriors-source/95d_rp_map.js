/* ===== RUNESTONE RAMPARTS: the maps =====
   rpGeo(map): the road as a smooth curve sampled every 4 px ({x,y,a} with a = heading), its length, and the build pads (chosen once:
   off the road, spread out, each covering as much road as possible). rpBake(map): the painted map (1600x660) baked once - ground,
   scatter, the cobbled road with its chevrons, the cave the monsters come from and the keep they march on. Live bits (water shimmer,
   torch flames, motes) are drawn by rpAmbient each frame. */
const RPGEO={},RPBAKE={};
RPFX.sq=.75;/* ground squash shared by the range rings, splash and frost effects and the targeting metric (dy/sq) */
const RPO='#12081f';
function rpSpline(pts){const o=[];const p=i=>pts[Math.max(0,Math.min(pts.length-1,i))];
 for(let i=0;i<pts.length-1;i++){const p0=p(i-1),p1=p(i),p2=p(i+1),p3=p(i+2),n=Math.max(4,Math.ceil(Math.hypot(p2[0]-p1[0],p2[1]-p1[1])/6));
  for(let k=0;k<n;k++){const t=k/n,t2=t*t,t3=t2*t;o.push([.5*((2*p1[0])+(-p0[0]+p2[0])*t+(2*p0[0]-5*p1[0]+4*p2[0]-p3[0])*t2+(-p0[0]+3*p1[0]-3*p2[0]+p3[0])*t3),
   .5*((2*p1[1])+(-p0[1]+p2[1])*t+(2*p0[1]-5*p1[1]+4*p2[1]-p3[1])*t2+(-p0[1]+3*p1[1]-3*p2[1]+p3[1])*t3)])}}
 o.push(pts[pts.length-1]);return o}
function rpGeo(map){if(RPGEO[map.id])return RPGEO[map.id];const sp=rpSpline(map.path),S=[];let acc=0,prev=sp[0];
 S.push({x:prev[0],y:prev[1],a:0});
 for(let i=1;i<sp.length;i++){const c=sp[i];let d=Math.hypot(c[0]-prev[0],c[1]-prev[1]);while(d>0&&acc+d>=4){const u=(4-acc)/d,x=prev[0]+(c[0]-prev[0])*u,y=prev[1]+(c[1]-prev[1])*u;
   S.push({x,y,a:Math.atan2(c[1]-prev[1],c[0]-prev[0])});prev=[x,y];d=Math.hypot(c[0]-prev[0],c[1]-prev[1]);acc=0}acc+=d;prev=c}
 for(let i=0;i<S.length;i++){const a=S[Math.max(0,i-3)],b=S[Math.min(S.length-1,i+3)];S[i].a=Math.atan2(b.y-a.y,b.x-a.x)}
 const len=(S.length-1)*4;
 const dRoad=(x,y)=>{let m=1e9;for(let i=0;i<S.length;i+=2){const q=S[i],d=(q.x-x)*(q.x-x)+(q.y-y)*(q.y-y);if(d<m)m=d}return Math.sqrt(m)};
 /* pads */
 const cand=[];for(let i=20;i<S.length-20;i+=7)for(const sd of[-1,1])for(const off of[84,104]){const q=S[i],x=q.x-Math.sin(q.a)*off*sd,y=q.y+Math.cos(q.a)*off*sd;
  if(x<70||x>1340||y<100||y>612)continue;if(dRoad(x,y)<78)continue;let cov=0;for(let j=0;j<S.length;j+=3){const p=S[j];if((p.x-x)**2+(p.y-y)**2<200*200)cov++}cand.push({x:Math.round(x),y:Math.round(y),cov})}
 cand.sort((a,b)=>b.cov-a.cov);const pads=[];for(const c of cand){if(pads.length>=(map.pads||11))break;if(pads.every(p=>Math.hypot(p.x-c.x,p.y-c.y)>=132))pads.push({x:c.x,y:c.y})}
 pads.sort((a,b)=>a.x-b.x);
 return RPGEO[map.id]={S,len,pads,dRoad}}
function rpAt(G,s){const S=G.S,f=Math.max(0,Math.min(S.length-1.001,s/4)),i=f|0,u=f-i,a=S[i],b=S[Math.min(S.length-1,i+1)];return{x:a.x+(b.x-a.x)*u,y:a.y+(b.y-a.y)*u,a:a.a}}
/* palettes */
const RP_PAL={
 moss:{g0:'#1d4a2c',g1:'#2a6236',g2:'#163b24',blot:['#2f6b3a','#245a30','#1a4527','#357841'],tree:['#1b4d2e','#256b3a','#123821'],treeHi:'#4f9a55',trunk:'#5a3a22',
  rock:'#6a6478',rockHi:'#9a94a8',edge:'#2a2236',curb:'#8a8070',dirt:'#7c6b56',dirt2:'#6a5a48',cob:['#9a8e7c','#8a7e6c','#a89c88'],chev:'rgba(255,255,255,.34)',water:'#2a6a9a',waterHi:'#7ad0ff',mote:'#c8ff8a',sky:'#0c1830'},
 frost:{g0:'#c9d9ea',g1:'#e2edf7',g2:'#a9bfd6',blot:['#d6e4f2','#bccfe2','#eaf2fa','#b2c6dc'],tree:['#1f4a4a','#2a5e5a','#163a3c'],treeHi:'#eaf6ff',trunk:'#4a3a32',
  rock:'#5a6a82',rockHi:'#a8bcd4',edge:'#3a4a66',curb:'#8a9ab2',dirt:'#9aaac0',dirt2:'#8494ac',cob:['#b2c2d6','#a2b2c8','#c4d2e2'],chev:'rgba(40,60,100,.3)',water:'#4a8ac0',waterHi:'#d8f2ff',mote:'#ffffff',sky:'#1a2a4a'},
 ember:{g0:'#2a1a20',g1:'#3a2228',g2:'#1c1016',blot:['#3a2026','#2e1a20','#4a2a2a','#24141a'],tree:['#2a1a18','#3a2420','#1a100e'],treeHi:'#ff8a3a',trunk:'#2a1810',
  rock:'#4a3a42',rockHi:'#7a6070',edge:'#1a0e12',curb:'#5a4248',dirt:'#5a3e3a',dirt2:'#4a3230',cob:['#6a5050','#5a4444','#7a5a56'],chev:'rgba(255,190,120,.3)',water:'#ff6a1a',waterHi:'#ffd27a',mote:'#ffb84a',sky:'#1a0a10'}};
function rpBlob(g,x,y,rx,ry,col,a){g.globalAlpha=a==null?1:a;g.fillStyle=col;g.beginPath();g.ellipse(x,y,rx,ry,0,0,TAU);g.fill();g.globalAlpha=1}
function rpTree(g,x,y,h,pal,i,kind){const C=pal.tree[i%3];g.save();g.translate(x,y);
 rpBlob(g,h*.12,4,h*.42,h*.13,'#000',.28);
 if(kind==='ember'){/* charred dead tree with glowing cracks */
  g.strokeStyle=RPO;g.lineWidth=h*.11+3;g.lineCap='round';g.beginPath();g.moveTo(0,0);g.lineTo(0,-h*.8);g.moveTo(0,-h*.45);g.lineTo(-h*.28,-h*.75);g.moveTo(0,-h*.6);g.lineTo(h*.26,-h*.9);g.moveTo(0,-h*.3);g.lineTo(h*.2,-h*.45);g.stroke();
  g.strokeStyle=C;g.lineWidth=h*.11;g.stroke();g.strokeStyle='#ff7a2a';g.lineWidth=1.6;g.globalAlpha=.7;g.beginPath();g.moveTo(-1,-h*.15);g.lineTo(1,-h*.35);g.lineTo(-1,-h*.55);g.stroke();g.globalAlpha=1;g.restore();return}
 g.fillStyle=pal.trunk;g.strokeStyle=RPO;g.lineWidth=2.4;g.beginPath();g.rect(-h*.05,-h*.16,h*.1,h*.18);g.fill();g.stroke();
 for(let k=0;k<3;k++){const ty=-h*(1-k*.22),by=-h*(.22+(2-k)*.17),w=h*(.24+k*.09);
  g.beginPath();g.moveTo(0,ty);g.quadraticCurveTo(w*.35,ty+(by-ty)*.45,w,by);g.quadraticCurveTo(0,by+h*.08,-w,by);g.quadraticCurveTo(-w*.35,ty+(by-ty)*.45,0,ty);g.closePath();
  g.fillStyle=C;g.fill();g.lineWidth=2.6;g.strokeStyle=RPO;g.stroke();
  g.save();g.clip();g.fillStyle='rgba(0,0,0,.22)';g.fillRect(0,ty,w,by-ty+10);g.fillStyle=pal.treeHi;g.globalAlpha=kind==='frost'?.95:.35;
  g.beginPath();g.moveTo(0,ty);g.quadraticCurveTo(-w*.25,ty+(by-ty)*.4,-w*.7,by-2);g.quadraticCurveTo(-w*.3,by-(by-ty)*.25,0,ty+(by-ty)*.2);g.fill();g.restore()}
 g.restore()}
function rpRock(g,x,y,s,pal){g.save();g.translate(x,y);rpBlob(g,s*.15,s*.18,s*.62,s*.2,'#000',.3);
 g.beginPath();g.moveTo(-s*.55,s*.12);g.lineTo(-s*.42,-s*.32);g.lineTo(-s*.05,-s*.5);g.lineTo(s*.38,-s*.38);g.lineTo(s*.58,s*.05);g.lineTo(s*.3,s*.22);g.lineTo(-s*.3,s*.24);g.closePath();
 g.fillStyle=pal.rock;g.fill();g.lineWidth=2.4;g.strokeStyle=RPO;g.stroke();g.save();g.clip();g.fillStyle='rgba(0,0,0,.25)';g.fillRect(0,-s,s,s*2);
 g.fillStyle=pal.rockHi;g.globalAlpha=.55;g.beginPath();g.moveTo(-s*.42,-s*.3);g.lineTo(-s*.05,-s*.48);g.lineTo(-s*.12,-s*.18);g.closePath();g.fill();g.restore();g.restore()}
function rpBake(map){if(RPBAKE[map.id])return RPBAKE[map.id];const G=rpGeo(map),pal=RP_PAL[map.pal],S=G.S,H=RPT.MAPH;
 const c=document.createElement('canvas');c.width=1600;c.height=H;const g=c.getContext('2d');g.lineJoin='round';g.lineCap='round';
 /* ground */
 let q=g.createLinearGradient(0,0,0,H);q.addColorStop(0,pal.g1);q.addColorStop(1,pal.g0);g.fillStyle=q;g.fillRect(0,0,1600,H);
 for(let i=0;i<220;i++){const x=rnd(i*3+map.id.length)*1600,y=rnd(i*3+7)*H,r=30+rnd(i*5+1)*90;rpBlob(g,x,y,r,r*.55,pal.blot[i%4],.45)}
 if(map.pal==='ember'){g.globalCompositeOperation='lighter';for(let i=0;i<26;i++){const x=rnd(i+400)*1600,y=rnd(i+430)*H;if(G.dRoad(x,y)<90)continue;
   g.strokeStyle='rgba(255,110,30,.45)';g.lineWidth=2.4;g.beginPath();g.moveTo(x,y);let px=x,py=y;for(let k=0;k<5;k++){px+=(rnd(i*9+k)-.5)*60;py+=(rnd(i*7+k+3)-.5)*30;g.lineTo(px,py)}g.stroke();
   glow(g,x,y,40,'#ff6a1a33')}g.globalCompositeOperation='source-over'}
 for(let i=0;i<500;i++){const x=rnd(i*2+90)*1600,y=rnd(i*2+91)*H;if(G.dRoad(x,y)<44)continue;g.strokeStyle=pal.blot[(i+1)%4];g.lineWidth=1.6;g.globalAlpha=.8;
  g.beginPath();g.moveTo(x,y);g.lineTo(x-2,y-6-rnd(i)*5);g.moveTo(x+3,y);g.lineTo(x+4,y-5-rnd(i+3)*5);g.stroke()}g.globalAlpha=1;
 /* water (moss, frost) or lava (ember) in the top right corner behind the keep, with a stony shore and ripples */
 {g.save();const shore=()=>{g.beginPath();g.moveTo(1240,0);g.bezierCurveTo(1290,96,1226,150,1322,214);g.lineTo(1600,224);g.lineTo(1600,0);g.closePath()};
  shore();g.fillStyle=pal.edge;g.fill();
  g.beginPath();g.moveTo(1262,0);g.bezierCurveTo(1310,88,1250,140,1342,198);g.lineTo(1600,206);g.lineTo(1600,0);g.closePath();
  q=g.createLinearGradient(1290,0,1560,200);q.addColorStop(0,pal.water);q.addColorStop(1,map.pal==='ember'?'#ffb84a':pal.waterHi);g.fillStyle=q;g.fill();g.save();g.clip();
  if(map.pal==='ember'){for(let i=0;i<40;i++){const x=1260+rnd(i+600)*360,y=rnd(i+640)*210;g.fillStyle=i%3?'#7a2a10':'#4a1a0a';g.globalAlpha=.75;g.beginPath();g.ellipse(x,y,18+rnd(i)*26,6+rnd(i+1)*8,rnd(i+2),0,TAU);g.fill()}g.globalAlpha=1}
  else{g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=2;for(let i=0;i<26;i++){const x=1290+rnd(i+600)*300,y=12+rnd(i+640)*180;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+12,y-4,x+26,y);g.stroke()}
   if(map.pal==='frost'){g.fillStyle='rgba(235,248,255,.7)';for(let i=0;i<9;i++){const x=1300+rnd(i+700)*280,y=20+rnd(i+720)*160;g.beginPath();g.ellipse(x,y,26+rnd(i)*20,9,rnd(i+3)*.6,0,TAU);g.fill()}}}
  g.restore();for(let i=0;i<34;i++){const u=i/34,x=1250+u*40+Math.sin(u*9)*14+u*u*70,y=u*214;rpRock(g,x+(i%2)*12,y,12+rnd(i+800)*12,pal)}g.restore()}
 /* ground detail: clearings, flowers or snow drifts or embers, small bushes (none in the water) */
 const wet=(x,y)=>x>1225&&y<235;
 for(let i=0;i<46;i++){const x=rnd(i+900)*1600,y=rnd(i+930)*H;if(G.dRoad(x,y)<70||wet(x,y))continue;rpBlob(g,x,y,40+rnd(i)*50,18+rnd(i+1)*20,map.pal==='frost'?'#f2f8ff':map.pal==='ember'?'#4a2a2a':'#3a7a40',.55)}
 for(let i=0;i<320;i++){const x=rnd(i+1000)*1600,y=rnd(i+1300)*H;if(G.dRoad(x,y)<46||wet(x,y))continue;const col=map.pal==='frost'?(i%3?'#ffffff':'#bfe6ff'):map.pal==='ember'?(i%3?'#ff7a2a':'#ffb84a'):['#ffe46a','#ffffff','#ff9ad8','#b4a0ff'][i%4];
  g.fillStyle=col;g.globalAlpha=map.pal==='ember'?.55:.9;g.beginPath();g.arc(x,y,map.pal==='frost'?1.6:2.2,0,TAU);g.fill()}g.globalAlpha=1;
 if(map.pal==='moss')for(let i=0;i<36;i++){const x=rnd(i+1600)*1600,y=rnd(i+1650)*H;if(G.dRoad(x,y)<62||wet(x,y)||G.pads.some(p=>Math.hypot(p.x-x,p.y-y)<70))continue;g.save();g.translate(x,y);
  for(const [dx,dy,r] of[[-9,0,9],[7,-2,10],[0,-8,9]]){g.fillStyle=pal.tree[1];g.strokeStyle=RPO;g.lineWidth=2;g.beginPath();g.arc(dx,dy,r,0,TAU);g.fill();g.stroke()}g.fillStyle=pal.treeHi;g.globalAlpha=.45;g.beginPath();g.arc(-4,-10,5,0,TAU);g.fill();g.globalAlpha=1;g.restore()}
 /* the road */
 const stroke=(w,col)=>{g.beginPath();g.moveTo(S[0].x,S[0].y);for(let i=1;i<S.length;i++)g.lineTo(S[i].x,S[i].y);g.lineWidth=w;g.strokeStyle=col;g.stroke()};
 stroke(84,'rgba(0,0,0,.25)');stroke(78,pal.edge);stroke(72,pal.curb);stroke(60,pal.dirt);
 for(let i=0;i<S.length;i+=3){const p=S[i];for(let k=0;k<3;k++){const off=(rnd(i*3+k)-.5)*44,x=p.x-Math.sin(p.a)*off+(rnd(i+k*7)-.5)*4,y=p.y+Math.cos(p.a)*off;
  g.fillStyle=pal.cob[(i+k)%3];g.strokeStyle='rgba(0,0,0,.22)';g.lineWidth=1.2;g.beginPath();g.ellipse(x,y,4+rnd(i*5+k)*3,3+rnd(i*7+k)*2,p.a,0,TAU);g.fill();g.stroke()}}
 /* curb stones along both edges */
 for(let i=0;i<S.length;i+=5)for(const sd of[-1,1]){const p=S[i],x=p.x-Math.sin(p.a)*35*sd,y=p.y+Math.cos(p.a)*35*sd;g.fillStyle=pal.curb;g.strokeStyle=RPO;g.lineWidth=1.6;
  g.beginPath();g.ellipse(x,y,7,4.5,p.a,0,TAU);g.fill();g.stroke();g.fillStyle='rgba(255,255,255,.18)';g.beginPath();g.ellipse(x-1,y-1.5,4,1.6,p.a,0,TAU);g.fill()}
 /* chevrons pointing the way */
 g.strokeStyle=pal.chev;g.lineWidth=4;for(let i=40;i<S.length-30;i+=34){const p=S[i];g.save();g.translate(p.x,p.y);g.rotate(p.a);g.beginPath();g.moveTo(-6,-9);g.lineTo(4,0);g.lineTo(-6,9);g.stroke();g.restore()}
 /* scatter: trees and rocks away from the road and the pads */
 const items=[];for(let i=0;i<900&&items.length<170;i++){const x=rnd(i*4+11)*1640-20,y=rnd(i*4+12)*(H+30)-10,d=G.dRoad(x,y);if(d<70)continue;if(x>1360&&y>170)continue;
  if(G.pads.some(p=>Math.hypot(p.x-x,(p.y-y)*1.4)<80))continue;if(x>1250&&y<200)continue;const dense=d>190||x<40||y<30||y>H-30;if(rnd(i+5)<(dense?.25:.7))continue;
  items.push({x,y,k:rnd(i*4+13)<.82?'t':'r',h:46+rnd(i*4+14)*38,i})}
 items.sort((a,b)=>a.y-b.y);for(const it of items){if(it.k==='t')rpTree(g,it.x,it.y,it.h,pal,it.i,map.pal);else rpRock(g,it.x,it.y,it.h*.45,pal)}
 /* the cave mouth where monsters come from */
 {const p=S[6];g.save();g.translate(Math.max(28,p.x),p.y);g.fillStyle=pal.rock;g.strokeStyle=RPO;g.lineWidth=3;g.beginPath();g.moveTo(-60,52);g.lineTo(-52,-30);g.quadraticCurveTo(-30,-82,10,-72);g.quadraticCurveTo(52,-62,58,-10);g.lineTo(62,52);g.closePath();g.fill();g.stroke();
  g.fillStyle='rgba(0,0,0,.25)';g.fillRect(0,-80,70,140);g.fillStyle='#0a0612';g.beginPath();g.moveTo(-34,46);g.lineTo(-30,-12);g.quadraticCurveTo(-8,-46,18,-30);g.quadraticCurveTo(36,-16,36,46);g.closePath();g.fill();
  glow(g,0,10,60,map.pal==='ember'?'#ff5a1a40':'#7a5aff30');g.restore()}
 const k=rpKeepArt(map,pal);g.drawImage(k,1330,170);
 return RPBAKE[map.id]={c,pal,G,trees:items}}
/* the keep: a stone fortress at the end of the road, gate facing the road's end at about (1450,468) */
function rpKeepArt(map,pal){const c=document.createElement('canvas');c.width=270;c.height=490;const g=c.getContext('2d');g.lineJoin='round';g.translate(0,0);
 const ox=-1330,oy=-170;g.translate(ox,oy);
 const st=map.pal==='frost'?['#8a9ab4','#6a7a94','#b4c4da']:map.pal==='ember'?['#5a4448','#463438','#7a5e60']:['#7a7488','#5e586c','#a49eb2'];
 const block=(x,y,w,h)=>{g.fillStyle=st[0];g.fillRect(x,y,w,h);g.strokeStyle='rgba(0,0,0,.28)';g.lineWidth=1.2;for(let yy=y+14;yy<y+h;yy+=14){g.beginPath();g.moveTo(x,yy);g.lineTo(x+w,yy);g.stroke();for(let xx=x+((yy/14)%2?10:24);xx<x+w;xx+=28){g.beginPath();g.moveTo(xx,yy-14);g.lineTo(xx,yy);g.stroke()}}
  g.fillStyle='rgba(0,0,0,.2)';g.fillRect(x+w*.62,y,w*.38,h);g.fillStyle='rgba(255,255,255,.14)';g.fillRect(x,y,w*.12,h);g.strokeStyle=RPO;g.lineWidth=3;g.strokeRect(x,y,w,h)};
 const crenel=(x,y,w)=>{for(let xx=x;xx<x+w-4;xx+=16){g.fillStyle=st[2];g.fillRect(xx,y-12,10,12);g.strokeStyle=RPO;g.lineWidth=2.4;g.strokeRect(xx,y-12,10,12)}};
 rpBlob(g,1470,640,150,26,'#000',.3);
 block(1400,330,180,300);crenel(1400,330,180);
 block(1365,260,70,330);crenel(1365,260,70);block(1525,240,72,360);crenel(1525,240,72);
 /* roofs */
 for(const [x,w,y] of[[1365,70,248],[1525,72,228]]){g.fillStyle=map.pal==='ember'?'#5a1a1a':'#2a3a7a';g.strokeStyle=RPO;g.lineWidth=3;g.beginPath();g.moveTo(x-8,y);g.lineTo(x+w/2,y-74);g.lineTo(x+w+8,y);g.closePath();g.fill();g.stroke();
  g.fillStyle='rgba(255,255,255,.16)';g.beginPath();g.moveTo(x-2,y-4);g.lineTo(x+w/2,y-70);g.lineTo(x+w*.36,y-4);g.closePath();g.fill();
  g.strokeStyle=RPO;g.lineWidth=2;g.beginPath();g.moveTo(x+w/2,y-74);g.lineTo(x+w/2,y-104);g.stroke();g.fillStyle='#ffd45a';g.beginPath();g.moveTo(x+w/2,y-104);g.lineTo(x+w/2+24,y-96);g.lineTo(x+w/2,y-88);g.closePath();g.fill();g.stroke()}
 /* windows */
 for(const [x,y] of[[1390,320],[1390,400],[1552,300],[1552,380],[1470,380]]){g.fillStyle='#ffd27a';g.strokeStyle=RPO;g.lineWidth=2.4;g.beginPath();g.roundRect(x,y,16,26,[8,8,2,2]);g.fill();g.stroke();glow(g,x+8,y+13,26,'#ffc86a44')}
 /* gate */
 g.fillStyle='#3a2414';g.strokeStyle=RPO;g.lineWidth=3;g.beginPath();g.moveTo(1432,532);g.lineTo(1432,470);g.quadraticCurveTo(1468,424,1504,470);g.lineTo(1504,532);g.closePath();g.fill();g.stroke();
 g.strokeStyle='#5a3a20';g.lineWidth=2;for(let x=1442;x<1500;x+=12){g.beginPath();g.moveTo(x,462);g.lineTo(x,530);g.stroke()}
 g.fillStyle='#ffd45a';g.beginPath();g.arc(1468,500,4,0,TAU);g.fill();
 /* banners */
 for(const x of[1410,1555]){g.fillStyle='#2a3a8a';g.strokeStyle=RPO;g.lineWidth=2.4;g.beginPath();g.moveTo(x,420);g.lineTo(x+26,420);g.lineTo(x+26,486);g.lineTo(x+13,474);g.lineTo(x,486);g.closePath();g.fill();g.stroke();
  g.fillStyle='#ffd45a';g.beginPath();g.moveTo(x+13,432);g.lineTo(x+19,446);g.lineTo(x+13,460);g.lineTo(x+7,446);g.closePath();g.fill()}
 /* the bridge down to the road */
 g.fillStyle='#6a4a2a';g.strokeStyle=RPO;g.lineWidth=2.6;g.beginPath();g.moveTo(1424,532);g.lineTo(1512,532);g.lineTo(1500,560);g.lineTo(1436,560);g.closePath();g.fill();g.stroke();
 return c}
/* live ambience: water shimmer, torch flames on the keep, motes */
function rpAmbient(c,R){const pal=R.bake.pal,t=R.t,rm=R.rm;
 c.save();c.globalCompositeOperation='lighter';
 for(let i=0;i<10;i++){const u=((t*.12+i/10)%1),x=1290+u*300,y=40+i*16+Math.sin(t+i)*4;c.globalAlpha=.25*(1-Math.abs(u-.5)*2);c.fillStyle=pal.waterHi;c.fillRect(x,y,22,2)}
 c.globalAlpha=1;for(const [x,y] of[[1398,333],[1580,333]]){const f=.8+.2*Math.sin(t*9+x);glow(c,x,y-10,30*f,'#ffb04a66');c.fillStyle='#ffd27a';c.beginPath();c.ellipse(x,y-12,4,7*f,0,0,TAU);c.fill()}
 if(!rm){const n=map_motes(R);for(let i=0;i<n;i++){const ph=t*.2+i*1.7,x=(rnd(i+3)*1600+Math.sin(ph)*40)%1600,y=(rnd(i+9)*620+(R.bake.pal===RP_PAL.frost?t*30:-t*14)+i*40)%620;
  c.globalAlpha=.35+.35*Math.sin(t*2+i);c.fillStyle=pal.mote;c.beginPath();c.arc(x<0?x+1600:x,y<0?y+620:y,R.bake.pal===RP_PAL.frost?2.2:1.8,0,TAU);c.fill()}}
 c.restore()}
const map_motes=R=>R.bake.pal===RP_PAL.frost?60:28;
