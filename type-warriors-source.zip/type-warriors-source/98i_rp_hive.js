/* ===== RUNESTONE TOWER DEFENSE 10.0: the Clockwork Hive in battle (98i, after 98h) =====
   The eleventh tower (key H, 350 supply, ground and air; TD_WORLDS_PLAN.md section 3; the core 98b decides when it is available).
   The hive keeps a swarm of mechanical bees (RP_TW.hive.bees by tier). They leave through the door one by one when a monster comes in
   range, fly to it in swarming curves, circle it in a figure eight at body height and sting it every cd seconds (dmg, armor-piercing
   ap). Bees spread over the monsters in range (the fewest bees first, then the Target setting: First, Strong, Close) and seek the next
   one when theirs dies or leaves range; with nothing left they patrol the hive for a moment and go home. Every sting coats the monster
   in honey: RPHVB.honeyK slower for RPHVB.honeyT s (never on top of a stronger slow, and not while slow-immune).
   Tier 3 Honeycomb: stings on ground monsters leave honey puddles on the road (RPHVB.poolK slower while in them, RPHVB.poolT s; one per
   bee every poolCd s). Tier 4 Royal Jelly: other towers within RPHVB.polR px (straight distance between the pads) are pollinated: +RPHVB.polK damage (tw.pol, does not stack;
   a courier bee flies the pollen over). Tier 5 Queen's Court: the Queen Bee takes off from her crown, hovers over the thickest crowd in
   range and every RPHVB.qT s releases a sting burst (RP_TW.hive.queen damage) on everything within RPHVB.qR px.
   Overcharge: stings and bursts come RPT.AB.over.k times faster, bees fly faster, +15% damage, like every tower. Jammed (tw.jam, 98b/98z
   skip rpFire): the bees fly home and do not sting. Damage goes through rpHurt (the Starfall mark, pollen and every other bonus apply).
   Range: rphvRange(R,tw) = RP_TW.hive.range by tier x tw.rangeK (if the core sets it). Targets: rphvCan(e) skips monsters that cannot be hit now (e.dive, e.glim, e.leap; or window.rpwCanHit(e) if the core defines it);
   rphvSeen(R,tw,e) hides monsters inside a fog bank (R.fog) from hives further than map.fogNear (150) px away.
   Drawing: R.lite / Performance mode draw half the bees (the damage is the same) and no trails, shadows or sparks; reduced motion
   (R.rm) drops the trails, sparks, pollen motes and honey drips.
   State on the tower: tw.bees [{x,y,h,vx,vy,vh,m:'in'|'out'|'home',e,st,dk,pc,ph,dir,tr}], tw.door (flap 0..1), tw.qn (the Queen:
   {x,y,h,vx,vy,vh,m:'perch'|'fly',e,cd,ch,to,idle}), tw.qHome, tw.cr (the courier), tw.pol (pollinated: seconds left).
   Monster state: e.hnS (honey from stings, s), e.hnP (honey puddle, s), e._hk (the honey slow applied this step).
   On RPX: hvPools [{x,y,r,t,d,tier,seed}], hvFx [{x,y,t,d,tier}], hvBursts [{x,y,r,t,d,tier}], hvStings, hvPoolN, hvBurstN. */
RP_TW.hive={cost:[350,260,480,950,1600],range:[250,262,275,288,300],dmg:[24,30,38,48,64],cd:[.6,.54,.5,.47,.44],bees:[2,3,4,5,6],ap:[2,2,2,2,2],
 queen:[0,0,0,0,320],air:1,ground:1,
 desc:'Sends out mechanical bees that swarm monsters, ground or air, and sting them again and again (armor-piercing 2). Each sting coats the monster in honey: 15% slower.',
 up:['A bigger swarm: three bees with sharper stings.','Honeycomb: stings leave honey puddles on the road that slow monsters 25%.','Royal Jelly: the bees pollinate towers within 150 px: +10% damage (does not stack).','Queen\'s Court: the Queen Bee joins the swarm; every 6 s her sting burst hits everything around her.']};
RP_TWORDER.push('hive');RP_KEYS.push('H');
const RPHVB={spd:[300,315,330,345,360],steer:6,engage:60,leash:1.18,launch:.16,patrol:2.4,honeyK:.15,honeyT:1.5,poolK:.25,poolT:3,poolR:30,poolCd:2.4,
 polR:150,polK:.1,qT:6,qR:90,qCh:.9,qSpd:240,scout:[4,7],lite:.5,f:0};
const RPHVK=()=>{try{return RPG.k||1}catch(e){return 1}};
const rphvMs=()=>{try{return RPC.mob||1}catch(e){return 1}};
/* the hive's reach: its tier's range, times tw.rangeK if the core sets one (Kraken's Maw Glowcaps: +15%) */
function rphvRange(R,tw){return RP_TW.hive.range[tw.tier-1]*(tw.rangeK||1)}
/* can a monster be hit right now, and can this hive see it (fog) */
function rphvCan(e){if(!e||e.dead||e.s<0)return false;try{if(typeof rpwCanHit==='function')return !!rpwCanHit(e)}catch(x){}return !(e.dive>0||e.glim>0||e.leap>0)}
function rphvSeen(R,tw,e){const F=R.fog;if(!F||!F.length)return true;const q=rpPos(R,e);for(const f of F){if(!f||!f.rx)continue;const a=(q.x-f.x)/f.rx,b=(q.y-f.y)/(f.ry||f.rx);if(a*a+b*b<1)return Math.hypot(q.x-tw.x,q.y-tw.y)<=((R.map&&R.map.fogNear)||150)}return true}
/* the point bees aim at on a monster: its ground point and the height of the middle of its body */
function rphvBody(R,e){const q=rpPos(R,e),M=RPMOB[e.id]||{h:50,w:40},s=rphvMs(),l=e.air?(M.lift||38)*s:0;return{x:q.x,y:q.y,h:l+M.h*s*.5,top:l+M.h*s,w:(M.w||40)*s}}
/* the hive's door and the Queen's perch in world space (the art is scaled by RPG.k about the pad centre) */
function rphvHome(tw){const K=RPHVK(),d=rphvDoor(tw.tier);return{x:tw.x+d.x*K,y:tw.y+6,h:6-d.y*K}}
function rphvPerchW(tw){const K=RPHVK(),d=rphvPerch(5);return{x:tw.x,y:tw.y+6,h:6-d.y*K}}
function rphvSfx(k){try{const n=performance.now();if(k==='sting'){if(n-(RPHVB.f||0)<90||Math.random()<.35)return;RPHVB.f=n;beep(1500+Math.random()*500,.025,'square',.035)}
 else if(k==='launch'){beep(180+Math.random()*30,.09,'sawtooth',.035);setTimeout(()=>beep(240,.07,'triangle',.04),40)}
 else if(k==='pool'){beep(260,.06,'sine',.08);setTimeout(()=>beep(170,.08,'sine',.07),45)}
 else if(k==='queen'){[523,659,784,1047].forEach((f,j)=>setTimeout(()=>beep(f,.08,'triangle',.09),j*55));setTimeout(()=>beep(200,.25,'sawtooth',.05),60)}
 else if(k==='charge'){beep(880,.05,'sine',.05)}
 else if(k==='burst'){beep(140,.16,'sawtooth',.12);[1568,2093,2637].forEach((f,j)=>setTimeout(()=>beep(f,.05,'square',.05),20+j*35))}
 else if(k==='pollen'){beep(1760+Math.random()*200,.05,'sine',.04)}}catch(e){}}
{const s0=rpSfx;rpSfx=function(k,v){if(typeof k==='string'&&k.slice(0,2)==='hv')return rphvSfx(k.slice(2).toLowerCase());return s0.apply(this,arguments)}}
/* choose a target for one bee: the monsters in range with the fewest bees on them, then the tower's Target setting */
function rphvPick(R,tw,bee){const rg=rphvRange(R,tw),r2=rg*rg,cnt=new Map();for(const b of tw.bees)if(b!==bee&&b.e&&b.m==='out')cnt.set(b.e,(cnt.get(b.e)||0)+1);
 let best=null,bv=-1e18;for(const e of R.foes){if(!rphvCan(e))continue;const q=rpPos(R,e),d2=rpD2(q.x,q.y,tw.x,tw.y);if(d2>r2||!rphvSeen(R,tw,e))continue;
  let v=-(cnt.get(e)||0)*1e6;v+=tw.prio==='strong'?e.hp/1e3:tw.prio==='close'?-d2/1e3:e.s/rpLen(R,e)*100;if(bee&&bee.e===e)v+=1e3;if(v>bv){bv=v;best=e}}return best}
function rphvAny(R,tw){const rg=rphvRange(R,tw),r2=rg*rg;for(const e of R.foes){if(!rphvCan(e))continue;const q=rpPos(R,e);if(rpD2(q.x,q.y,tw.x,tw.y)<=r2&&rphvSeen(R,tw,e))return true}return false}
/* steer a flyer (bee or Queen) toward a goal: a damped velocity with a sideways wobble that makes the swarming curves */
function rphvSteer(b,gx,gy,gh,spd,dt,steer,wob,t){const dx=gx-b.x,dy=gy-b.y,dh=gh-b.h,dg=Math.hypot(dx,dy),d=Math.hypot(dg,dh)||1e-6,sp=spd*Math.min(1,d/38);
 let vx=dx/d*sp,vy=dy/d*sp,vh=dh/d*sp;if(wob&&dg>50){const w=Math.sin(t*6.2+b.ph*9)*spd*wob,nx=-dy/dg,ny=dx/dg;vx+=nx*w;vy+=ny*w*.7;vh+=Math.cos(t*4.3+b.ph*5)*spd*wob*.25}
 const k=Math.min(1,dt*steer);b.vx+=(vx-b.vx)*k;b.vy+=(vy-b.vy)*k;b.vh+=(vh-b.vh)*k;b.x+=b.vx*dt;b.y+=b.vy*dt;b.h+=b.vh*dt;if(b.h<4){b.h=4;if(b.vh<0)b.vh=0}
 if(Math.abs(b.vx)>12)b.dir=b.vx>0?1:-1;return d}
/* make sure the swarm matches the tier (an upgrade adds bees at the door; tier 5 adds the Queen on her crown) */
function rphvSync(R,tw){const T=RP_TW.hive,i=tw.tier-1,n=T.bees[i];if(!tw.bees)tw.bees=[];const H=rphvHome(tw);
 while(tw.bees.length<n)tw.bees.push({x:H.x,y:H.y,h:H.h,vx:0,vy:0,vh:0,m:'in',e:null,st:Math.random()*.3,dk:0,pc:0,ph:Math.random(),dir:Math.random()<.5?-1:1,tr:[],tt:0,pt:0});
 if(tw.bees.length>n)tw.bees.length=n;
 if(T.queen[i]&&!tw.qn){const P=rphvPerchW(tw);tw.qn={x:P.x,y:P.y,h:P.h,vx:0,vy:0,vh:0,m:'perch',e:null,cd:RPHVB.qT*.5,ch:0,to:0,idle:0,ph:Math.random(),dir:1,rt:0};tw.qHome=1}
 if(!T.queen[i]&&tw.qn){tw.qn=null;tw.qHome=1}}
/* one sting: damage, honey, a puddle (tier 3+), a spark */
function rphvHit(R,tw,b,e,dmg){const T=RP_TW.hive,i=tw.tier-1,fl=e.fl;rpHurt(e,dmg,T.ap[i],tw);if(!e.dead)e.fl=Math.max(fl,0);/* stings land often: no white flash */R.hvStings=(R.hvStings||0)+1;tw.nv=(tw.nv||0)+1;
 if(!e.dead){e.hnS=Math.max(e.hnS||0,RPHVB.honeyT)}
 const B=rphvBody(R,e);if(!R.lite){R.hvFx.push({x:B.x+(b.x-B.x)*.35,y:B.y-B.h+((b.y-b.h)-(B.y-B.h))*.35,t:0,d:.28,tier:tw.tier});if(R.hvFx.length>60)R.hvFx.shift()}
 if(tw.tier>=3&&!e.air&&b.pc<=0){b.pc=RPHVB.poolCd;rphvPool(R,B.x,B.y,tw.tier)}
 rphvSfx('sting')}
function rphvPool(R,x,y,tier){for(const p of R.hvPools)if(Math.hypot(p.x-x,(p.y-y)*1.4)<22){p.t=Math.min(p.t,.2);p.d=Math.max(p.d,RPHVB.poolT);p.x=(p.x+x)/2;p.y=(p.y+y)/2;p.tier=Math.max(p.tier,tier);return}
 R.hvPools.push({x,y,r:RPHVB.poolR,t:0,d:RPHVB.poolT,tier,seed:Math.random()});if(R.hvPools.length>16)R.hvPools.shift();R.hvPoolN=(R.hvPoolN||0)+1;rphvSfx('pool')}
/* the swarm, one step; act = false while the hive cannot fire (jammed): the bees go home */
function rphvRun(R,tw,dt,act){const T=RP_TW.hive,i=tw.tier-1;rphvSync(R,tw);const ov=act&&tw.over>0,sk=ov?RPT.AB.over.k:1,dmg=T.dmg[i]*(ov?1.15:1),spd=RPHVB.spd[i]*(ov?1.3:1),rg=rphvRange(R,tw),H=rphvHome(tw),t=R.t;
 tw.door=Math.max(0,(tw.door||0)-dt*2.6);tw.fire=Math.max(0,(tw.fire||0)-dt*3);
 const any=act&&rphvAny(R,tw);tw.lq=(tw.lq||0)-dt;tw.scout=(tw.scout==null?RPHVB.scout[0]:tw.scout)-dt;
 for(const b of tw.bees){b.pc=Math.max(0,b.pc-dt);b.dk=Math.max(0,b.dk-dt*7);
  if(b.m==='in'){b.x=H.x;b.y=H.y;b.h=H.h;b.vx=b.vy=b.vh=0;b.e=null;b.tr.length=0;
   if(tw.lq<=0&&(any||(act&&tw.scout<=0&&!tw.bees.some(o=>o.m!=='in')))){b.m='out';b.pt=any?0:-2.2;tw.lq=RPHVB.launch;tw.door=1;tw.fire=Math.max(tw.fire||0,.45);b.vy=spd*.45;b.vh=spd*.25;b.vx=(Math.random()-.5)*spd*.6;if(!any)tw.scout=RPHVB.scout[0]+Math.random()*(RPHVB.scout[1]-RPHVB.scout[0]);rphvSfx('launch')}
   continue}
  /* keep or find a target */
  let e=b.e;if(e&&(!act||!rphvCan(e)||!rphvSeen(R,tw,e)||(()=>{const q=rpPos(R,e);return rpD2(q.x,q.y,tw.x,tw.y)>rg*rg*RPHVB.leash*RPHVB.leash})()))e=b.e=null;
  if(!e&&act&&any){e=b.e=rphvPick(R,tw,b);if(e){b.m='out';b.st=Math.max(b.st,.12)}}
  if(e){/* fly to it and circle it in a figure eight at body height; dart in to sting */
   const B=rphvBody(R,e),a=t*3.4*(1+b.ph*.3)+b.ph*TAU,A=Math.max(16,B.w*.42)+6,gx=B.x+Math.sin(a)*A,gy=B.y+Math.sin(2*a)*A*.34,gh=B.h+Math.sin(a*2+1)*5;
   const far=Math.hypot(b.x-B.x,b.y-B.y);const d=rphvSteer(b,gx,gy,far>90?Math.max(gh,40+Math.min(40,far*.12)):gh,spd,dt,far>90?RPHVB.steer:RPHVB.steer*1.8,far>90?.38:0,t+b.ph*7);
   b.bk=gy<B.y-1;b.fe=e;
   if(far<A+RPHVB.engage*.45){b.st-=dt*sk;if(b.st<=.12)b.dk=Math.min(1,b.dk+dt*14);if(b.st<=0){b.st=T.cd[i]*(.92+Math.random()*.16);b.dk=1;rphvHit(R,tw,b,e,dmg)}}
   else b.st=Math.max(b.st,.12)}
  else{/* nothing to sting: patrol the hive in a figure eight for a moment, then go home */
   b.pt+=dt;const a=t*2.2+b.ph*TAU,gx=tw.x+Math.sin(a)*58,gy=tw.y+Math.sin(2*a)*20-4,gh=58+Math.sin(a*3)*8;b.fe=null;b.bk=gy<tw.y-2&&Math.abs(gx-tw.x)<44;
   if(b.pt<RPHVB.patrol||!act&&b.pt<.6){rphvSteer(b,gx,gy,gh,spd*.7,dt,RPHVB.steer,0,t)}
   else{const d=rphvSteer(b,H.x,H.y,H.h,spd*.8,dt,RPHVB.steer*1.6,0,t);if(d<9){b.m='in';b.pt=0;tw.door=1}}}
  if(b.m!=='in'&&!R.lite){b.tt-=dt;if(b.tt<=0){b.tt=.045;b.tr.unshift(b.x,b.y-b.h);if(b.tr.length>(tw.tier>=4?10:8))b.tr.length=tw.tier>=4?10:8}}}
 /* the Queen */
 const Q=tw.qn;if(Q){const P=rphvPerchW(tw);Q.to=Math.max(0,Q.to-dt);
  if(Q.m==='perch'){Q.x=P.x;Q.y=P.y;Q.h=P.h;tw.qHome=1;Q.ch=Math.max(0,Q.ch-dt*2);
   if(any){Q.m='fly';Q.to=.6;tw.qHome=0;Q.vh=150;Q.vx=0;Q.vy=0;Q.idle=0;rpRing(P.x,P.y-P.h,'#ffe27a',70,5);try{ptBurst(R.fx,P.x,P.y-P.h,R.lite?6:16,['#fff6c8','#ffe27a','#ffffff','#c08aff'],{v:200,s:3.4,k:'star'})}catch(x){}rphvSfx('queen')}}
  else{tw.qHome=0;Q.rt-=dt;if(!Q.e||!rphvCan(Q.e)||Q.rt<=0||!act){Q.rt=.5;Q.e=act?rphvCrowd(R,tw):null}
   if(Q.e){Q.idle=0;const B=rphvBody(R,Q.e),a=t*1.6+Q.ph*TAU,gx=B.x+Math.cos(a)*14,gy=B.y+Math.sin(a)*6,gh=B.h+34;
    if(Q.to>0)rphvSteer(Q,Q.x,Q.y,P.h+46,RPHVB.qSpd,dt,RPHVB.steer,0,t);else rphvSteer(Q,gx,gy,gh,RPHVB.qSpd*(ov?1.3:1),dt,RPHVB.steer*.8,.18,t+Q.ph*5);
    if(Math.hypot(Q.x-B.x,Q.y-B.y)<70){const c0=Q.cd;Q.cd-=dt*sk;if(c0>RPHVB.qCh&&Q.cd<=RPHVB.qCh)rphvSfx('charge');Q.ch=Q.cd<RPHVB.qCh?1-Math.max(0,Q.cd)/RPHVB.qCh:Math.max(0,Q.ch-dt*3);
     if(Q.cd<=0){Q.cd=RPHVB.qT;Q.ch=0;rphvQBurst(R,tw,Q,T.queen[i]*(ov?1.15:1))}}}
   else{Q.idle+=dt;Q.ch=Math.max(0,Q.ch-dt*3);if(Q.idle<1.2&&act)rphvSteer(Q,tw.x+Math.sin(t)*40,tw.y-10,90,RPHVB.qSpd*.6,dt,RPHVB.steer,0,t);
    else{const d=rphvSteer(Q,P.x,P.y,P.h,RPHVB.qSpd*.8,dt,RPHVB.steer*1.5,0,t);if(d<6){Q.m='perch';tw.qHome=1;Q.cd=Math.max(Q.cd,RPHVB.qT*.5)}}}}}
 /* the courier bee: carries pollen to the towers this hive buffs (tier 4+, looks only) */
 if(tw.tier>=4&&act&&!R.lite){const C=tw.cr||(tw.cr={t:0,d:2.6,to:null,k:0});C.t+=dt;if(C.t>=C.d||!C.to||!C.to.pad||!C.to.pad.tw||C.to.pad.tw!==C.to){const L=tw._pl||[];C.t=0;C.to=L.length?L[C.k++%L.length]:null;if(!C.to)C.t=-1.5}}
 else if(tw.cr)tw.cr.to=null}
/* the Queen's target: the monster with the most others within her burst radius (bosses count double) */
function rphvCrowd(R,tw){const rg=rphvRange(R,tw),r2=rg*rg,qr=RPHVB.qR*RPHVB.qR,L=[];for(const e of R.foes){if(!rphvCan(e))continue;const q=rpPos(R,e);if(rpD2(q.x,q.y,tw.x,tw.y)<=r2&&rphvSeen(R,tw,e))L.push([e,q])}
 let best=null,bv=-1;for(const [e,q] of L){let v=e.boss?2:1;for(const [f,p] of L)if(f!==e&&rpD2(p.x,p.y,q.x,q.y)<qr)v+=f.boss?2:1;v+=e.hp/1e6;if(v>bv){bv=v;best=e}}return best}
function rphvQBurst(R,tw,Q,dmg){const x=Q.x,y=Q.y,r2=RPHVB.qR*RPHVB.qR;let n=0;for(const e of R.foes){if(!rphvCan(e))continue;const q=rpPos(R,e);if(rpD2(q.x,q.y,x,y)<r2){rpHurt(e,dmg,RP_TW.hive.ap[4],tw);if(!e.dead)e.hnS=Math.max(e.hnS||0,RPHVB.honeyT);n++}}
 R.hvBursts.push({x,y,h:Q.h,r:RPHVB.qR,t:0,d:.75,tier:tw.tier});if(R.hvBursts.length>12)R.hvBursts.shift();R.hvBurstN=(R.hvBurstN||0)+1;R.shake=Math.max(R.shake||0,2.5);
 try{ptBurst(R.fx,x,y-Q.h,R.lite?6:16,['#fff6c8','#ffe27a','#ffffff'],{v:260,s:3.2,g:240})}catch(e){}rphvSfx('burst');return n}
function rpHiveFire(R,tw,dt){tw.over=Math.max(0,(tw.over||0)-dt);tw._hvS=R.time;rphvRun(R,tw,dt,true)}
/* honey slows (never on top of a stronger slow, never while slow-immune); pollen; the passive swarm of hives that did not fire */
function rphvPre(R,dt){for(const e of R.foes){e._hk=0;if(e.dead)continue;const k=Math.max(e.hnS>0?RPHVB.honeyK:0,e.hnP>0?RPHVB.poolK:0);if(!k||e.vent>0)continue;
  if(!(e.slowT>0)||e.slowK<=k){e.slowK=k;e.slowT=Math.max(e.slowT||0,dt*1.5);e._hk=k}}}
function rphvPost(R,dt){if(!R.hvPools)return;
 for(const e of R.foes){if(e.hnS>0)e.hnS=Math.max(0,e.hnS-dt);if(e.hnP>0)e.hnP=Math.max(0,e.hnP-dt)}
 for(const p of R.hvPools){p.t+=dt;if(p.t<p.d-.3)for(const e of R.foes){if(e.dead||e.air||e.s<0)continue;const q=rpPos(R,e);if(rpD2(q.x,q.y,p.x,p.y)<p.r*p.r)e.hnP=Math.max(e.hnP||0,.15)}}
 R.hvPools=R.hvPools.filter(p=>p.t<p.d);for(const f of R.hvFx)f.t+=dt;R.hvFx=R.hvFx.filter(f=>f.t<f.d);for(const b of R.hvBursts)b.t+=dt;R.hvBursts=R.hvBursts.filter(b=>b.t<b.d);
 for(const p of R.pads){const tw=p.tw;if(!tw)continue;if(tw.pol>0)tw.pol=Math.max(0,tw.pol-dt)}
 for(const p of R.pads){const tw=p.tw;if(!tw||tw.type!=='hive')continue;if(tw.build<1){tw.bees=tw.bees||[];continue}
  const act=tw._hvS===R.time;if(!act)rphvRun(R,tw,dt,false);
  if(tw.tier>=4&&act){const L=[];for(const q of R.pads){const o=q.tw;if(!o||o===tw||o.build<1)continue;if(Math.hypot(o.x-tw.x,o.y-tw.y)<=RPHVB.polR){if(!(o.pol>0)&&!R.rm&&Math.random()<.5)rphvSfx('pollen');o.pol=Math.max(o.pol||0,.35);o.polK=RPHVB.polK;L.push(o)}}tw._pl=L}else tw._pl=[]}}
/* pollinated towers hit harder (one bonus, however many hives) */
{const h0=rpHurt;rpHurt=function(e,dmg,ap,src){if(src&&src.pol>0)dmg*=1+(src.polK||RPHVB.polK);return h0.call(this,e,dmg,ap,src)}}
/* hooks: fire routine, battle state, step, upgrade, sell */
{const f0=rpFire;rpFire=function(R,tw,dt){if(tw.type==='hive')return rpHiveFire(R,tw,dt);return f0.apply(this,arguments)}}
{const s0=rpStart;rpStart=function(){const r=s0.apply(this,arguments);if(RPX)Object.assign(RPX,{hvPools:[],hvFx:[],hvBursts:[],hvStings:0,hvPoolN:0,hvBurstN:0});return r}}
{const s0=rpStep;rpStep=function(R,dt){if(R&&R.hvPools)try{rphvPre(R,dt)}catch(e){console.error(e)}const r=s0.apply(this,arguments);try{rphvPost(R,dt)}catch(e){console.error(e)}return r}}
{const b0=rpBuild;rpBuild=function(pad,type){const r=b0.apply(this,arguments);try{if(r!==false&&type==='hive'&&pad&&pad.tw&&pad.tw.type==='hive'){const tw=pad.tw;tw.bees=[];tw.door=0;tw.qHome=1}}catch(e){}return r}}
{const u0=rpUpgrade;rpUpgrade=function(tw){const r=u0.apply(this,arguments);if(r&&tw&&tw.type==='hive'&&RPX){try{rphvSync(RPX,tw);tw.door=1}catch(e){}}return r}}
{const s0=rpSell;rpSell=function(tw){try{const R=RPX;if(R&&tw&&tw.type==='hive'){const L=(tw.bees||[]).filter(b=>b.m!=='in');if(tw.qn&&tw.qn.m!=='perch')L.push(tw.qn);for(const b of L)ptBurst(R.fx,b.x,b.y-b.h,R.lite?2:5,['#ffe27a','#ffb52a','#ffffff'],{v:120,s:2.6})}}catch(e){}return s0.apply(this,arguments)}}
/* ---------- drawing ---------- */
let RPHV_FR=0;
const rphvTrC=tier=>tier>=5?'#fff0c0':tier===4?'#d8a8ff':'#ffe27a';
function rphvDrawBee(c,R,tw,b,sc){if(b.m==='in'||b._f===RPHV_FR)return;b._f=RPHV_FR;const tier=tw.tier;let x=b.x,y=b.y-b.h;
 if(b.dk>0&&b.fe&&!b.fe.dead){const B=rphvBody(R,b.fe),k=b.dk*b.dk*.55;x+=(B.x-x)*k;y+=(B.y-B.h-y)*k}
 rphvBee(c,x,y,b.dir,tier,R.t+b.ph*3,(sc||1)*(tier>=5?1.5:tier===4?1.45:1.4)*(b.bk?.9:1),1)}
/* pollen trails behind the bees: all of them in one pass (one blend switch per frame) */
function rphvTrails(c,R){if(R.lite||R.rm)return;c.globalCompositeOperation='lighter';for(const p of R.pads){const tw=p.tw;if(!tw||tw.type!=='hive'||!tw.bees)continue;const tier=tw.tier,d=rphvDot(rphvTrC(tier)).c,big=tier>=4;
  for(const b of tw.bees){if(b.m==='in'||b.tr.length<=2)continue;const n=b.tr.length/2;for(let k=1;k<n;k++){const a=(1-k/n)*(big?.8:.5),z=(big?4.4:3.4)*(1-k/n*.5);c.globalAlpha=a;c.drawImage(d,b.tr[k*2]-z,b.tr[k*2+1]-z,z*2,z*2)}}}
 c.globalCompositeOperation='source-over';c.globalAlpha=1}
function rphvDrawQueen(c,R,tw){const Q=tw.qn;if(!Q||Q.m==='perch'||Q._f===RPHV_FR)return;Q._f=RPHV_FR;const y=Q.y-Q.h;
 /* the take-off: a streak of light from the crown, a glow and a ring of sparkles around her */
 if(Q.to>0){const P=rphvPerchW(tw),k=Q.to/.6;c.save();c.globalCompositeOperation='lighter';c.lineCap='round';c.globalAlpha=k*.8;c.strokeStyle='#fff0a0';c.lineWidth=12*k+2;c.beginPath();c.moveTo(P.x,P.y-P.h);c.lineTo(Q.x,y);c.stroke();
  c.lineWidth=3;c.strokeStyle='#ffffff';c.stroke();rpGlow(c,Q.x,y,50,46,'#fff6c8',k*1.1);rpGlow(c,P.x,P.y-P.h,40,30,'#ffe27a',k);
  if(!R.lite&&!R.rm){const st=rpStarS().c;for(let i=0;i<7;i++){const a=i/7*TAU+R.t*3,d=24+26*(1-k),z=5+4*k;c.globalAlpha=Math.min(1,k*1.4);c.drawImage(st,Q.x+Math.cos(a)*d-z,y+Math.sin(a)*d*.7-z,z*2,z*2)}}c.restore();c.globalAlpha=1}
 rphvQueen(c,Q.x,y,Q.dir||1,5,R.t+Q.ph,1.3,1,Q.ch,0)}
function rphvCourier(c,R,tw){const C=tw.cr;if(!C||!C.to||C.t<0||R.lite)return;const o=C.to,H=rphvHome(tw),top=rpTowerTop(o.type,o.tier)*.85,u=C.t/C.d;
 const go=u<.36?u/.36:u<.6?1:1-(u-.6)/.4,e=go*go*(3-2*go),x0=H.x,y0=H.y-H.h,x1=o.x+Math.sin(R.t*5)*10,y1=o.y-top+Math.cos(R.t*5)*4,mx=(x0+x1)/2,my=Math.min(y0,y1)-50,a=1-e;
 const x=a*a*x0+2*a*e*mx+e*e*x1,y=a*a*y0+2*a*e*my+e*e*y1,dir=(u<.6?x1>=x0:x0>=x1)?1:-1;
 /* the pollen ball it carries, and the dust it sprinkles over the tower */
 if(u<.6){c.save();c.globalCompositeOperation='lighter';c.globalAlpha=.9;c.drawImage(rpGlowC('#ffd23a'),x-9,y+2,18,18);c.restore();c.fillStyle='#ffd23a';c.beginPath();c.arc(x,y+10,3.6,0,TAU);c.fill();c.lineWidth=1.2;c.strokeStyle=RPTO;c.stroke();c.fillStyle='#fff6c8';c.beginPath();c.arc(x-1,y+9,1.3,0,TAU);c.fill()}
 if(u>.3&&u<.66){const d=rphvGrainS().c;c.save();for(let k=0;k<5;k++){const q=(R.t*1.7+k*.2)%1;c.globalAlpha=(1-q);c.drawImage(d,x-4+Math.sin(k*2+R.t*3)*9,y+6+q*34-4,8,8)}c.restore();c.globalAlpha=1}
 rphvBee(c,x,y,dir,tw.tier,R.t*1.3,1.4,1)}
function rphvLiteSkip(tw,j){return RPX&&RPX.lite&&j>=Math.ceil(tw.bees.length*RPHVB.lite)}
/* before the frame: which bees are behind their target monster or behind their own hive (drawn before those, so they are hidden by them) */
{const d0=rpDraw;rpDraw=function(){const R=RPX;RPHV_FR++;try{if(R&&R.hvPools){const F=new Map();for(const p of R.pads){const tw=p.tw;if(!tw||tw.type!=='hive'||!tw.bees)continue;tw._hb=null;
   tw.bees.forEach((b,j)=>{if(b.m==='in'||rphvLiteSkip(tw,j))return;if(b.fe&&b.bk&&!b.fe.dead){let L=F.get(b.fe);if(!L)F.set(b.fe,L=[]);L.push([tw,b])}else if(!b.fe&&b.bk){(tw._hb=tw._hb||[]).push(b)}})}R._hvF=F}}catch(e){console.error(e)}
 return d0.apply(this,arguments)}}
{const t0=rpTowerAt;rpTowerAt=function(c,R,tw){const hv=tw&&tw.type==='hive';if(hv){RPHV.cur=tw;if(tw._hb)for(const b of tw._hb)rphvDrawBee(c,R,tw,b)}
 let r;try{r=t0.apply(this,arguments)}finally{RPHV.cur=null}
 if(tw&&tw.pol>0&&tw.build>=1&&!R.rm)try{rphvPollen(c,tw.x,tw.y,R.t,Math.min(1,tw.pol*4)*(R.lite?.6:1),rpTowerTop(tw.type,tw.tier),tw.ph||0)}catch(e){}
 return r}}
{const f0=rpFoeDraw;rpFoeDraw=function(c,R,e,q){let hide=false,st=0;try{const L=R._hvF&&R._hvF.get(e);if(L)for(const [tw,b] of L)rphvDrawBee(c,R,tw,b);
  /* honey slows show as honey, not as frost */
  if(e._hk>0&&e.slowT>0&&e.slowK<=e._hk+1e-6&&!(e.inField>0)){hide=true;st=e.slowT;e.slowT=0}}catch(x){}
 let r;try{r=f0.apply(this,arguments)}finally{if(hide)e.slowT=st}
 if(!e.dead&&(e.hnS>0||e.hnP>0))try{const B=rphvBody(R,e),k=Math.min(1,Math.max(e.hnS||0,e.hnP||0)*2);rphvGlaze(c,q.x,q.y-B.top*.86,B.w,k,R.t+e.ph*7);
  if(!R.rm&&!R.lite&&Math.random()<.05)ptBurst(R.fx,q.x+(Math.random()-.5)*B.w*.5,q.y-B.h,1,['#ffb52a','#ffe27a'],{v:20,s:2.4,g:260})}catch(x){}
 return r}}
/* a honey glaze over a sticky monster: a few drips under a honey cap */
const rphvGlzS=()=>rpSpr('hv|glz',-22,-8,44,22,g=>{const C=rphvHoney(1);g.beginPath();g.moveTo(-18,0);g.quadraticCurveTo(-10,-6,0,-5);g.quadraticCurveTo(10,-6,18,0);
 for(const [x,l] of [[12,5],[5,9],[-3,6],[-11,10]]){g.lineTo(x+2.4,0);g.lineTo(x+1.6,l-1.6);g.arc(x,l-1.6,1.8,0,Math.PI);g.lineTo(x-2.4,0)}g.quadraticCurveTo(-16,2,-18,0);g.closePath();
 g.fillStyle=rpVG(g,-6,10,C[0],C[1]);g.fill();g.lineWidth=1.4;g.strokeStyle=RPTO;g.stroke();g.fillStyle='rgba(255,255,255,.7)';g.beginPath();g.ellipse(-6,-3,5,1.3,-.1,0,TAU);g.fill()});
function rphvGlaze(c,x,y,w,k,t){if(k<=.02)return;const s=Math.max(.5,Math.min(1.2,w/46));c.save();c.globalAlpha=Math.min(1,k)*.95;c.translate(x,y+Math.sin(t*2)*.6);c.scale(s,s);rpPut(c,rphvGlzS());c.restore();c.globalAlpha=1}
/* ground layer: honey puddles, the ground part of the Queen's bursts, bee shadows, the pollen reach of a selected Royal Jelly hive */
{const a0=rpAmbient;rpAmbient=function(c,R){const r=a0.apply(this,arguments);try{if(R&&R.hvPools){
 for(const p of R.hvPools){const k=Math.min(1,p.t*6,(p.d-p.t)/.6);rphvPuddle(c,p.x,p.y,p.r,k,R.t,p.tier,p.seed)}
 for(const b of R.hvBursts)rphvBurst(c,b.x,b.y,b.r,b.t/b.d,b.tier,b.h,0);
 if(!R.lite)for(const pd of R.pads){const tw=pd.tw;if(!tw||tw.type!=='hive'||!tw.bees)continue;tw.bees.forEach((b,j)=>{if(b.m!=='in'&&!rphvLiteSkip(tw,j))rphvShadow(c,b.x,b.y,.8,Math.max(.25,1-b.h/140))});
  const Q=tw.qn;if(Q&&Q.m!=='perch')rphvShadow(c,Q.x,Q.y,1.7,Math.max(.3,1-Q.h/180))}
 const s=R.sel;if(s&&s.type==='hive'&&s.tier>=4&&s.build>=1){c.save();c.globalAlpha=.7;c.setLineDash([4,9]);c.lineDashOffset=R.t*20;c.lineWidth=2.4;c.strokeStyle='#ffe27a';c.beginPath();c.arc(s.x,s.y-20,RPHVB.polR,0,TAU);c.stroke();c.restore()}}}catch(e){console.error(e)}return r}}
/* top layer: the swarm, the Queen, the courier, sting sparks and the Queen's bursts */
{const b0=rpBeamsDraw;rpBeamsDraw=function(c,R){b0.apply(this,arguments);if(!R.hvPools)return;try{
 for(const b of R.hvBursts)rphvBurst(c,b.x,b.y,b.r,b.t/b.d,b.tier,b.h,1);
 rphvTrails(c,R);
 for(const p of R.pads){const tw=p.tw;if(!tw||tw.type!=='hive'||!tw.bees)continue;tw.bees.forEach((b,j)=>{if(!rphvLiteSkip(tw,j))rphvDrawBee(c,R,tw,b)});rphvDrawQueen(c,R,tw);rphvCourier(c,R,tw)}
 if(!R.lite&&!R.rm)for(const f of R.hvFx)rphvSting(c,f.x,f.y,f.t/f.d,f.tier)}catch(e){console.error(e)}}}
/* the info panel: range, sting damage, bees, sting rate, and the tier's extras */
{const i0=rpInfoBuild;rpInfoBuild=function(R,tw,el){const r=i0.apply(this,arguments);if(tw.type!=='hive')return r;try{const T=RP_TW.hive,i=tw.tier-1,top=RP_MAXT(R.map),nx=tw.tier<top?tw.tier:null;
  const seg=(v,max)=>Math.max(0,Math.min(6,Math.round(v/max*6))),bar=(lab,v,max,nv)=>`<div class="rpst"><span>${lab}</span><i>${[0,1,2,3,4,5].map(k=>`<s class="${k<seg(v,max)?'on':nv!=null&&k<seg(nv,max)?'up':''}"></s>`).join('')}</i></div>`;
  const sw=j=>Math.sqrt(T.bees[j]*T.dmg[j]/T.cd[j]);
  const st=el.querySelector('.rpsts');if(st)st.innerHTML=bar('Range',T.range[i],300,nx!=null?T.range[nx]:null)+bar('Swarm damage',sw(i),sw(4),nx!=null?sw(nx):null)+bar('Bees',T.bees[i],6,nx!=null?T.bees[nx]:null)+bar('Sting rate',1/T.cd[i],1/.45,nx!=null?1/T.cd[nx]:null);
  const ex=[`<b>${T.bees[i]}</b> bees · ground and air`,`armor-piercing <b>${T.ap[i]}</b>`,`honey <b>${Math.round(RPHVB.honeyK*100)}%</b> slow`];
  if(tw.tier>=3)ex.push(`honey puddles <b>${Math.round(RPHVB.poolK*100)}%</b>`);if(tw.tier>=4)ex.push(`pollen <b>+${Math.round(RPHVB.polK*100)}%</b> damage to towers within ${RPHVB.polR}`);if(T.queen[i])ex.push(`Queen's burst every <b>${RPHVB.qT} s</b>`);
  if(st)st.insertAdjacentHTML('afterend',`<div class="rphvx">${ex.join(' · ')}</div>`);
  const hgt=el.offsetHeight||420;el.style.top=rpClamp(tw.y-hgt*.62,76,770-hgt)+'px'}catch(e){console.error(e)}return r}}
/* key H picks it (letters belong to Rune Typing while it is on) */
{const k0=rpKeyDown;window.removeEventListener('keydown',rpKeyDown,true);rpKeyDown=function(e){const R=RPX;if(R&&S.rp&&S.mode==='ramparts'&&!R.pause&&!R.over&&!(R.ty&&R.ty.on)&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&e.key.length===1&&e.key.toLowerCase()==='h'){e.preventDefault();e.stopImmediatePropagation();if(!e.repeat)rpPlace('hive');return}return k0.apply(this,arguments)};window.addEventListener('keydown',rpKeyDown,true)}
/* eleven buttons in the build ring: a wider arc again (the same spacing as ten), kept on the stage */
{const g0=rpHudRing;rpHudRing=function(R,C){const was=C.rg;const r=g0.apply(this,arguments);try{if(C.rg!==was&&C.rg){const bs=[...$('rpring').querySelectorAll('.rprb')],p=R.selPad;if(bs.length>=11){bs.forEach(b=>{for(const v of ['--x','--y']){const n=parseFloat(b.style.getPropertyValue(v));if(isFinite(n))b.style.setProperty(v,(n*1.11).toFixed(1)+'px')}});
   if(p){const xs=bs.map(b=>p.x+(parseFloat(b.style.getPropertyValue('--x'))||0)),lo=Math.min(...xs)-46,hi=Math.max(...xs)+46,dx=lo<0?-lo:hi>1600?1600-hi:0;
    if(dx)bs.forEach(b=>b.style.setProperty('--x',((parseFloat(b.style.getPropertyValue('--x'))||0)+dx).toFixed(1)+'px'))}}}}catch(e){console.error(e)}return r}}
/* eleven tiles in the bar; the hub's Ascended Towers grid (97g) takes six a row so eleven still fit in two rows */
{const st=document.createElement('style');st.textContent=`.rph.rp7.rp8.rp9.rp10.rp11 .rpbar{gap:2px}.rph.rp7.rp8.rp9.rp10.rp11 .rpcard{width:76px}.rph.rp7.rp8.rp9.rp10.rp11 .rpct>b{max-width:74px;font-size:11px}.rph.rp7.rp8.rp9.rp10.rp11 .rpcard img{width:62px;height:62px;margin-left:-31px;top:-17px}
.rphvx{margin:6px 0 2px;font:600 12px Poppins,system-ui,sans-serif;color:#fff0c8;line-height:1.35}.rphvx b{color:#ffc83a}
.rpasc>div{grid-template-columns:repeat(6,minmax(0,1fr))}`;document.head.appendChild(st)}
{const h0=rpHudOn;rpHudOn=function(){const r=h0.apply(this,arguments);try{const h=$('rphud');if(h&&RP_TWORDER.length>=11)h.classList.add('rp11')}catch(e){}return r}}
try{const h=HELP.Modes.find(x=>x[0]==='Runestone Tower Defense');if(h)h[1]+=" The Clockwork Hive (H, 350 supply) sends out mechanical bees that swarm monsters on the ground and in the air, sting them again and again and slow them with honey."}catch(e){}
{const h0=rpHowTo;rpHowTo=function(){const r=h0.apply(this,arguments);try{const w=ov.querySelector('#rpmod .rphw');if(w)w.insertAdjacentHTML('beforeend',`<p><b>Clockwork Hive.</b> A swarm tower (350 supply, key H), ground and air. Its mechanical bees fly out, circle monsters and sting them again and again (armor-piercing 2); each sting coats the monster in honey, slowing it 15%. The bees spread over the monsters in range and find the next one when theirs falls. Tier 3 stings leave honey puddles on the road, tier 4 bees pollinate nearby towers for +10% damage, and at tier 5 the Queen Bee joins the swarm with a sting burst every 6 seconds.</p>`)}catch(e){}return r}}
{const w0=rpTowerWarm;rpTowerWarm=function(type,tier,skin){const r=w0.apply(this,arguments);if(type==='hive')try{rphvGlzS();rphvGrainS();rphvSpkS(tier);rphvDot(rphvTrC(rphvT(tier)));rphvDot('#ffe27a')}catch(e){}return r}}
/* the 9.9p glow and particle layer (97k): honey light at the door and the comb, gold motes circling the skep */
try{RPG_SRC.hive=[null,...[1,2,3,4,5].map(t=>{const L=RPLAY.hive[t],D=rphvDoor(t),a=[[0,D.y,[0,20,22,24,26,28][t],t===4?'#e08aff':t===5?'#fff0a0':'#ffb84a']];if(t>=2)a.push([0,L.db-L.H*.45,[0,0,26,30,32,34][t],t===4?'#c890ff':'#ffd45a']);if(t>=5)a.push([0,L.db-L.H-12,22,'#fff0c0']);return a})];
 RPG_PAR.hive={k:'orbit',n:[0,2,3,4,5,6],c:['#ffe27a','#ffb84a'],s:'dot',y:[0,-46,-52,-58,-60,-62],r:[0,34,37,40,42,44],z:2.4}}catch(e){}
