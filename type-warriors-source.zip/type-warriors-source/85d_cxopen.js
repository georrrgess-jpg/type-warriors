/* ===== CELESTIAL CHEST: the roll, the opening scene and its sound =====
   THE STARS ARE LISTENING (0-1.3s)  ->  CONSTELLATION ALIGNMENT (1.3-3.0s: the star key lifts out of its latch, six sky stars light one by one and each
   connection answers in the chest)  ->  CONSTELLATION UNSEALED (3.0-3.9s: the key turns a quarter turn, a thin pulse of light runs into the lock, the key
   dissolves into stars)  ->  the lid swings up on its rear hinge (3.9s)  ->  A NEW STAR IS BORN (the weapon rises out of the chest, overshoots, settles and
   floats; the information panel arrives 0.5s later).  The sequence is identical for every rarity until the star appears. */
const CXO={O:3.9,RISE:.5,SET:1.7,INFO:.5};
const CX_CAP=['THE STARS ARE LISTENING','CONSTELLATION ALIGNMENT','CONSTELLATION UNSEALED','A NEW STAR IS BORN'];
const CX_TCOL=[0,0,'#6fb4ff','#c986ff','#ffc84a'];
const CX_NEU='#9fdcff';
const cl01=x=>Math.max(0,Math.min(1,x)),cxU=(t,a,b)=>cl01((t-a)/(b-a)),eio=u=>u<.5?4*u*u*u:1-Math.pow(-2*u+2,3)/2;
function cxMix(a,b,u){const p=h=>[1,3,5].map(i=>parseInt(h.slice(i,i+2),16)),x=p(a),y=p(b);return'#'+x.map((v,i)=>Math.round(v+(y[i]-v)*u).toString(16).padStart(2,'0')).join('')}
/* the colour of the reward: neutral cyan until the star is shown, then the tier colour */
const cxTier=(q,t)=>q.tier>=5?hsx(268+Math.sin((t||0)*1.1)*70,88,70):CX_TCOL[q.tier]||CX_NEU;
const cxTint=(q,t)=>cxMix(CX_NEU,cxTier(q,t),eio(cxU(t,q.tp,q.tp+.5)));

/* the roll: Rare 51%, Epic 36%, Legendary 10%, Mythic 3%. The odds are never shown to the player. The Astral pieces are favoured while you do not own them. */
function cxRoll(){const r=Math.random()*100,want=r<51?2:r<87?3:r<97?4:5,pool=[];
 for(const id in WP){const w=WP[id];if(RKM[w.r]!==want||(w.hw&&!w.cel))continue;if(isSpecial(id)&&!pathOpen(w.p))continue;pool.push({kind:'w',id,own:!!P.own[id],cel:!!w.cel})}
 const cel=pool.filter(x=>x.cel);
 if(want===5)return cel[Math.random()*cel.length|0];/* the only Mythic in this chest is the Astral Cleaver */
 if(cel.length){const un=cel.filter(x=>!x.own);if(un.length&&Math.random()<.6)return un[Math.random()*un.length|0];if(!un.length&&Math.random()<.12)return cel[Math.random()*cel.length|0]}
 const base=pool.filter(x=>!x.cel),nw=base.filter(x=>!x.own),use=nw.length&&Math.random()<.88?nw:base;return use[Math.random()*use.length|0]}
{const cr0=crateRoll;crateRoll=function(k){if(k!=='c')return cr0(k);P.ccr=P.ccr|0;if(!(P.ccr>=1))return null;P.ccr--;
 const r=cxRoll(),kind=r.kind,id=r.id,T=kind==='a'?AR:WP,o=kind==='a'?'ownA':'own',it=T[id],dup=!!P[o][id];window.__pf=0;
 stat('crates',1,'add');stat('ccr',1,'add');if(RKM[it.r]>=3)stat('epic',RKM[it.r],'max');P[o][id]=1;if(dup){P.xp+=40;P.gold+=GOLDDUP[it.r]}save();
 return{kind,id,it,dup,pf:0,T,o}}}
/* a second click on Open, or Open another, while a Celestial scene is running can never consume another chest */
{const cs0=crateStart;crateStart=function(k){if(k==='c'&&S.cr2&&S.mode==='crate')return;return cs0.apply(this,arguments)}}

/* ---------- preparing a scene ---------- */
function cxPrep(q){q.cx=1;const T=q.tier;q.O=CXO.O;q.tp=q.O+CXO.RISE;q.ts=q.O+CXO.SET;q.E=q.ts+CXO.INFO;q.rm=ccReduce();q.fx=[];q.rings=[];q.shk=0;q.fl=0;q.last=performance.now();q.fired={};q.done=false;q.skipped=0;q.sparks=[];q.trails=[];q.acc=0;
 q.stars=[];for(let i=0;i<170;i++)q.stars.push({x:Math.random()*W,y:Math.random()*H*.94,r:.5+Math.random()*1.8,ph:Math.random()*6,sp:.6+Math.random()*1.8});
 q.itemC=document.createElement('canvas');q.itemC.width=q.itemC.height=320;q.gx=0;q.gy=0}
const CXS=3.3,cxK=.8*CXS,ITEMY=395;/* chest scale */
const cxBy=()=>GY-6,cxGemY=()=>cxBy()-62*cxK,cxHover=()=>cxBy()-455,cxMouthY=()=>cxBy()-62*cxK;
/* the star key: it lifts out of the latch and above the chest, hovers while the constellation aligns, turns a quarter turn, sends its pulse into the lock, then dissolves */
const CXK={r:30,L:64};
function cxKeyPos(t){const gy=cxGemY(),hy=cxHover(),cx=W/2;let y,lift;
 if(t<1.3){y=gy;lift=0}else if(t<2.0){const u=eio(cxU(t,1.3,2.0));y=gy+(hy-gy)*u;lift=u}else{lift=1;y=hy+Math.sin((t-2)*2.2)*4*sstep(2,2.4,t)*(1-sstep(3,3.4,t))}
 const turn=eio(cxU(t,3,3.4)),d=cxU(t,3.65,4.1),a=1-eio(d);
 return{x:cx,y,lift,turn,d,a,tip:y+CXK.r*1.3+CXK.L+4}}
/* the sky constellation: stars light in ring order, every connection runs from the previous star */
const CX_NODES=[[-1,.15],[1,.15],[-1.35,.95],[1.35,.95],[-.7,1.6],[.7,1.6]],CX_LO=[0,2,4,5,3,1],cxTN=k=>1.75+.2*k;
function cxNodePos(i){const cx=W/2,hy=cxHover(),n=CX_NODES[i];return[cx+n[0]*185,hy-120+n[1]*105]}
/* what the chest does as each star lights: a front dot, a side crystal, a small hop */
const CX_DOTT=[1.75,2.15,2.55,2.75,2.8];
const cxLit=t=>CX_DOTT.reduce((a,d)=>a+sstep(d,d+.18,t),0);
function cxChestOpts(q,t){const O=q.O,lv=a=>cxU(t,a,a+.25),sett=1-.2*sstep(O,O+1,t);
 return{lit:cxLit(t),pw:.3+.7*sstep(.3,O,t),gem:t<1.3?1:t<1.45?Math.max(0,1-(t-1.3)/.15):0,tc:cxMix('#8ad8ff',cxTint(q,t),.5*sstep(q.tp,q.tp+.5,t)),
  crL:Math.min(1,lv(1.95)*.6+lv(3)*.4)*sett,crR:Math.min(1,lv(2.35)*.6+lv(3)*.4)*sett,lift:q.rm?0:7*Math.sin(Math.PI*cxU(t,2.75,3.1)),
  bm:1-eio(cxU(t,q.tp+.1,q.tp+.9)),lock:sstep(3.65,3.72,t)*(1-sstep(O,O+.8,t)),lid:cxLid(q,t)}}
/* the lid: hinged at the rear, slow start, fast middle, small overshoot, rests standing behind the chest */
const CXLID=1.72;
function cxLid(q,t){const u=cxU(t,q.O,q.O+1.15);if(u<=0)return 0;const b=eio(u),ov=q.rm?0:.085*Math.sin(Math.PI*sstep(.45,1,u));return CXLID*(b+ov)}
function cxSpark(q,x,y,col,n,v,l,up){if(q.rm)n=Math.ceil(n*.3);for(let i=0;i<n;i++){const a=Math.random()*TAU,s=v*(.25+Math.random());q.fx.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s-(up||0),l:l*(.6+Math.random()*.6),g:260,dr:.7,s:2+Math.random()*3.4,c:Math.random()<.35?'#fff':col,ty:Math.random()<.4?'star':'dot'})}}
function cxRing(q,x,y,col,max,dur,lw){q.rings.push({t0:q.t,x,y,c:col,max,dur,lw:lw||5})}
/* where the reward is: it climbs out of the mouth, overshoots a little, settles, then floats */
function cxPrize(q,t){const by=cxBy(),p=cxU(t,q.tp,q.tp+1.15),c1=q.rm?0:1.5,e=1+(c1+1)*Math.pow(p-1,3)+c1*(p-1)*(p-1),y0=by-35,y=y0+(ITEMY-y0)*e,fl=q.rm?0:5*Math.sin((t-q.ts)*1.4)*sstep(q.ts,q.ts+.7,t);
 return{y:y+fl,sc:.72+.28*easeO(p),a:sstep(q.tp,q.tp+.25,t),p}}

/* ---------- the clock ---------- */
function cxUpdate(){const q=S.cr2;if(!q)return;const now=performance.now(),dt=Math.min(.1,Math.max(0,(now-q.last)/1000));q.last=now;q.t+=dt;const t=q.t,O=q.O,T=q.tier,cx=W/2,by=cxBy(),live=!q.skipped,tcol=cxTier(q,t),shk=a=>{if(!q.rm)q.shk=Math.max(q.shk,a)};
 q.shk=Math.max(0,q.shk-dt*44);q.fl=Math.max(0,q.fl-dt*2);
 if(live){
 for(let k=0;k<6;k++)if(t>=cxTN(k)&&!q.fired['n'+k]){q.fired['n'+k]=1;const p=cxNodePos(CX_LO[k]);cxSpark(q,p[0],p[1],'#8ad8ff',10,150,.7);cxRing(q,p[0],p[1],'#8ad8ff',54,.6,2.2)}
 if(t>=1.3&&!q.fired.lift){q.fired.lift=1;const kp=cxKeyPos(t);cxSpark(q,cx,cxGemY(),'#9ae6ff',22,260,.9,100);cxRing(q,cx,cxGemY(),'#9ae6ff',130,.7,3)}
 if(t>1.3&&t<2.0&&Math.random()<dt*50){const k=cxKeyPos(t);q.fx.push({x:k.x+(Math.random()-.5)*24,y:k.y+24,vx:(Math.random()-.5)*40,vy:30+Math.random()*50,l:.6,g:0,dr:1,s:2+Math.random()*2.4,c:'#9ae6ff',ty:Math.random()<.4?'star':'dot'})}
 if(t>=3&&!q.fired.cmp){q.fired.cmp=1;cxRing(q,cx,cxHover(),'#8ad8ff',340,.8,3);cxSpark(q,cx,cxHover(),'#bfe8ff',16,200,.8)}
 if(t>=3.4&&!q.fired.turn){q.fired.turn=1;const k=cxKeyPos(t);cxSpark(q,k.x+16,k.tip-14,'#ffe2a0',10,120,.5)}
 if(t>=3.65&&!q.fired.lock){q.fired.lock=1;shk(5);cxSpark(q,cx,cxGemY(),'#9ae6ff',26,360,.8);cxRing(q,cx,cxGemY(),'#9ae6ff',150,.6,4);cxRing(q,cx,cxGemY(),'#c9a8ff',92,.5,2.5)}
 /* the key dissolves into small particles */
 if(t>3.65&&t<4.1){const k=cxKeyPos(t),n=(q.rm?60:200)*dt;q.acc+=n;while(q.acc>=1){q.acc--;const hd=Math.random()<.55,x=k.x+(hd?(Math.random()-.5)*CXK.r*2.2:(Math.random()-.5)*14+(Math.random()<.4?16:0)),y=hd?k.y+(Math.random()-.5)*CXK.r*2.6:k.y+CXK.r*1.3+Math.random()*CXK.L;
  q.fx.push({x,y,vx:(x-k.x)*2.4+(Math.random()-.5)*60,vy:-30-Math.random()*90,l:.7+Math.random()*.5,g:-20,dr:.8,s:1.8+Math.random()*3,c:Math.random()<.4?'#fff':Math.random()<.5?'#9ae6ff':'#ffe2a0',ty:Math.random()<.4?'star':'dot'})}}
 if(t>2.2&&t<O&&Math.random()<dt*(8+(t-2.2)*6))q.fx.push({x:cx+(Math.random()-.5)*340,y:by-20-Math.random()*40,vx:(Math.random()-.5)*40,vy:-70-Math.random()*130,l:1,g:0,dr:.5,s:2+Math.random()*2.4,c:Math.random()<.5?'#8ad8ff':'#c9a8ff',ty:Math.random()<.5?'star':'dot'})
 /* the lid breaks: a neutral cyan and violet plume, the same for every rarity */
 if(t>=O&&!q.fired.open){q.fired.open=1;shk(6);const my=cxMouthY();cxRing(q,cx,my,'#8ad8ff',520,.9,4);const n=q.rm?14:46;
  for(let i=0;i<n;i++){const a=-Math.PI/2+(Math.random()-.5)*Math.PI*.9,v=200+Math.random()*520;q.fx.push({x:cx+(Math.random()-.5)*100,y:my,vx:Math.cos(a)*v,vy:Math.sin(a)*v,l:.8+Math.random()*.8,g:300,dr:.6,s:2+Math.random()*3.4,c:Math.random()<.5?'#8ad8ff':'#c9a8ff',ty:Math.random()<.35?'star':'dot'})}}
 if(t>O+.15&&t<q.ts&&Math.random()<dt*(q.rm?5:16)){q.fx.push({x:cx+(Math.random()-.5)*130,y:cxMouthY(),vx:(Math.random()-.5)*90,vy:-200-Math.random()*240,l:1.2,g:-20,dr:.3,s:2+Math.random()*2.6,c:Math.random()<.5?'#8ad8ff':'#c9a8ff',ty:Math.random()<.5?'star':'dot'})}
 /* the star appears: the tier burst, one low flash, rings */
 if(t>=q.tp&&!q.fired.rise){q.fired.rise=1;if(ST.flash!==false&&!q.rm)q.fl=1;const n=[0,0,60,100,150,230][T]*(q.rm?.3:1),my=cxMouthY()-60;
  for(let i=0;i<n;i++){const a=-Math.PI/2+(Math.random()-.5)*Math.PI*1.6,v=180+Math.random()*(T>=4?900:560);q.fx.push({x:cx,y:my,vx:Math.cos(a)*v,vy:Math.sin(a)*v,l:.9+Math.random()*(T>=4?1.6:.9),g:340,dr:.55,s:2+Math.random()*(T>=4?5:3.4),c:Math.random()<.5?tcol:Math.random()<.5?'#fff':'#8ad8ff',ty:Math.random()<.35?'star':'dot'})}
  const nr=[0,0,1,2,2,3][T];for(let i=0;i<nr;i++)q.rings.push({t0:t+i*.12,x:cx,y:my,c:i%2?'#fff':tcol,max:[0,0,560,720,900,1200][T]*(1+i*.1),dur:[0,0,1,1.2,1.4,1.7][T],lw:5})}
 if(t>=q.ts&&!q.fired.set){q.fired.set=1;cxSpark(q,cx,ITEMY,tcol,[0,0,10,16,22,34][T],200,.9);cxRing(q,cx,ITEMY,tcol,300,.9,3)}
 /* afterwards only a sparse glitter of stars drifts around the halo */
 if(t>q.tp+.5){const r=[0,0,4,7,11,16][T]*(q.rm?.4:1);if(Math.random()<dt*r){const a=Math.random()*TAU,rr=170+Math.random()*80;q.fx.push({x:cx+Math.cos(a)*rr,y:ITEMY+Math.sin(a)*rr*.8,vx:(Math.random()-.5)*16,vy:-18-Math.random()*26,l:1.3+Math.random()*.8,g:0,dr:0,s:2+Math.random()*2.4,c:Math.random()<.4?'#fff':tcol,ty:Math.random()<.6?'star':'dot'})}}
 }
 for(const p of q.fx){p.l-=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=(p.g||0)*dt;if(p.dr){const k=Math.max(0,1-p.dr*dt);p.vx*=k;p.vy*=k}}q.fx=q.fx.filter(p=>p.l>0);if(q.fx.length>900)q.fx.splice(0,q.fx.length-900);
 if(t>=q.E&&!q.done){q.done=true;crateResult()}}

/* ---------- the picture ---------- */
function cxCap(c,txt,x,y,size,col,sp){c.font='600 '+size+'px "Cinzel",Georgia,serif';c.textAlign='center';c.textBaseline='middle';const w=[...txt].map(ch=>c.measureText(ch).width+sp),tot=w.reduce((a,b)=>a+b,0)-sp;let px=x-tot/2;c.textAlign='left';c.fillStyle=col;[...txt].forEach((ch,i)=>{c.fillText(ch,px,y);px+=w[i]})}
/* the item picture carries its own glow, which would end in a hard square edge; fade the outer rim so only the weapon and a soft glow remain */
function cxFeather(cv){const g=cv.getContext('2d'),w=cv.width,h=cv.height;g.save();g.globalCompositeOperation='destination-in';let l=g.createLinearGradient(0,0,w,0);l.addColorStop(0,'#0000');l.addColorStop(.12,'#000');l.addColorStop(.88,'#000');l.addColorStop(1,'#0000');g.fillStyle=l;g.fillRect(0,0,w,h);l=g.createLinearGradient(0,0,0,h);l.addColorStop(0,'#0000');l.addColorStop(.12,'#000');l.addColorStop(.88,'#000');l.addColorStop(1,'#0000');g.fillStyle=l;g.fillRect(0,0,w,h);g.restore()}
function cxFrame(c,x,y,r,a,t,tc){/* the dashed diamond frame with three crystals, as in the storyboard */
 c.save();c.globalAlpha=a;c.setLineDash([7,9]);c.lineDashOffset=-t*12;c.strokeStyle=tc+'cc';c.lineWidth=2.4;c.beginPath();c.moveTo(x,y-r);c.lineTo(x+r*.8,y);c.lineTo(x,y+r);c.lineTo(x-r*.8,y);c.closePath();c.stroke();c.setLineDash([]);
 for(const [px,py,s] of[[x-r*.8,y,1],[x+r*.8,y,1],[x,y+r,1.15]])cxCrystal(c,px,py,20*s,44*s,t,px,1);c.restore()}
/* the star key: a four pointed star on a gold shaft with two teeth; a quarter turn swings the teeth out and turns the star edge-on */
function cxKey(c,k,t){const r=CXK.r,ph=k.turn*Math.PI/2,cs=Math.cos(ph),sn=Math.sin(ph),L=CXK.L*cl01(k.lift*2.5),sy0=r*1.3;
 c.save();c.translate(k.x,k.y);c.scale(1-.08*k.d,1-.08*k.d);c.globalAlpha=k.a;
 c.globalCompositeOperation='lighter';glow(c,0,30,150,'#7fe0ff'+hxA(.3*(1+.2*Math.sin(t*5))));c.globalCompositeOperation='source-over';
 if(L>2){c.beginPath();c.roundRect(-5.5,sy0-4,11,L+4,3);c.fillStyle=cxGold(c,-5.5,0,5.5,0);c.fill();c.strokeStyle=CXC.ink;c.lineWidth=2.2;c.stroke();
  for(const [dy,len] of[[L-4,26],[L-21,18]]){if(dy<sy0)continue;const x0=-7+12.5*sn,w=14+(len-14)*sn;c.beginPath();c.roundRect(x0,sy0+dy-9,w,9,2);c.fillStyle=cxGold(c,x0,0,x0+w,0);c.fill();c.strokeStyle=CXC.ink;c.lineWidth=2;c.stroke()}}
 c.save();c.scale(Math.max(.1,cs),1);cxGemStar(c,0,0,r,1,t);c.restore();
 c.beginPath();c.roundRect(-9,sy0-8,18,8,3);c.fillStyle=cxGold(c,-9,0,9,0);c.fill();c.strokeStyle=CXC.ink;c.lineWidth=2;c.stroke();
 c.restore()}
/* a quarter-turn arc around the key while it turns */
function cxTurnArc(c,k,t){const u=cxU(t,3,3.4);if(u<=0||u>=1.001)return;const a=sstep(3,3.08,t)*(1-sstep(3.4,3.6,t));if(a<=0)return;c.save();c.globalAlpha=a*.9;c.translate(k.x,k.y+CXK.r*1.3+30);c.strokeStyle='#bfeaff';c.lineWidth=2.4;c.shadowColor='#6ad4ff';c.shadowBlur=10;c.beginPath();c.ellipse(0,0,62,16,0,Math.PI*.15,Math.PI*.15+eio(u)*Math.PI*.5);c.stroke();c.restore()}
/* the narrow pulse that runs from the key's tip into the lock */
function cxPulse(c,k,t){const a0=3.4,a1=3.65;if(t<a0||t>3.9)return;const gy=cxGemY()-14,x=W/2;c.save();c.globalCompositeOperation='lighter';
 if(t<a1){const u=Math.pow(cxU(t,a0,a1),1.5),hy=k.tip+(gy-k.tip)*u,ty=Math.max(k.tip,hy-110);const g=c.createLinearGradient(0,ty,0,hy);g.addColorStop(0,'#8ee8ff00');g.addColorStop(1,'#e8fbff');c.strokeStyle=g;c.lineWidth=5;c.lineCap='round';c.shadowColor='#6ad4ff';c.shadowBlur=14;c.beginPath();c.moveTo(x,ty);c.lineTo(x,hy);c.stroke();glow(c,x,hy,26,'#9ae6ffcc')}
 else{const f=1-cxU(t,a1,a1+.22);c.globalAlpha=f;c.strokeStyle='#bfeaff';c.lineWidth=3;c.shadowColor='#6ad4ff';c.shadowBlur=10;c.beginPath();c.moveTo(x,k.tip);c.lineTo(x,gy);c.stroke();glow(c,x,gy,44*f+8,'#9ae6ffaa')}
 c.restore()}
/* the constellation that circles the finished weapon: gold for Legendary, gold and violet for Mythic */
const CX_CP=[[-250,-20],[-205,-122],[-100,-188],[55,-198],[185,-132],[255,-30]],CX_CP2=[[-232,62],[-150,152],[0,198],[150,152],[232,62]];
function cxPCon(c,cx,iy,pts,col,a,t,off){if(a<=0)return;c.save();c.globalAlpha=a;c.strokeStyle=col;c.lineWidth=2;c.shadowColor=col;c.shadowBlur=8;c.beginPath();pts.forEach((p,i)=>i?c.lineTo(cx+p[0],iy+p[1]):c.moveTo(cx+p[0],iy+p[1]));c.stroke();c.shadowBlur=0;pts.forEach((p,i)=>cxStar(c,cx+p[0],iy+p[1],9+2*Math.sin(t*2+i+off),col,t,i+off));c.restore()}
function cxDraw(){const q=S.cr2,t=Math.max(0,q.t),c=ctx,cx=W/2,by=cxBy(),T=q.tier,O=q.O,tc=cxTint(q,t),tcol=cxTier(q,t),E=q.E,my=cxMouthY(),kp=cxKeyPos(t),pz=cxPrize(q,t);
 c.save();if(q.shk>0&&ST.shake)c.translate((Math.random()-.5)*q.shk,(Math.random()-.5)*q.shk);
 /* deep violet night (screen space) */
 let g=c.createLinearGradient(0,0,0,H);g.addColorStop(0,'#05061c');g.addColorStop(.55,'#0f0f36');g.addColorStop(1,'#1d1650');c.fillStyle=g;c.fillRect(-80,-80,W+160,H+160);
 c.save();for(const s of q.stars){c.globalAlpha=(.25+.75*Math.abs(Math.sin(t*s.sp+s.ph)))*(s.r>1.6?1:.8);c.fillStyle=s.r>1.9?'#bfe8ff':'#fff';c.fillRect(s.x,s.y,s.r,s.r)}c.restore();
 /* the camera: once the star has settled the scene eases back and up to leave room for the information panel */
 const cam=eio(cxU(t,q.ts-.05,q.ts+.55)),sc=1-.26*cam;c.save();c.translate(0,8*cam);c.translate(cx,0);c.scale(sc,sc);c.translate(-cx,0);
 c.fillStyle='#14123a';for(const [x,w,h,pk] of[[190,90,420,1],[330,60,300,0],[1330,90,460,1],[1210,64,320,0],[70,70,250,0],[1500,70,280,1]]){c.fillRect(x-w/2,GY-h+30,w,h);if(pk){c.beginPath();c.moveTo(x-w*.72,GY-h+30);c.lineTo(x,GY-h-w*.85);c.lineTo(x+w*.72,GY-h+30);c.closePath();c.fill()}}
 c.fillStyle='#0d0c2c';c.fillRect(-W,GY+18,W*3,H*2);
 g=c.createRadialGradient(cx,by,40,cx,by,700);g.addColorStop(0,'#3a2a8a55');g.addColorStop(1,'#3a2a8a00');c.fillStyle=g;c.fillRect(-W,0,W*3,H*1.5);
 c.save();c.strokeStyle='#5a48b822';c.lineWidth=1.4;for(let i=0;i<9;i++){const yy=GY+22+i*i*2.2;c.beginPath();c.moveTo(-W,yy);c.lineTo(W*2,yy);c.stroke()}for(let i=-10;i<=10;i++){c.beginPath();c.moveTo(cx+i*60,GY+18);c.lineTo(cx+i*190,H*1.4);c.stroke()}c.restore();
 /* the reward's light behind the chest: a brief burst of rays that fades inside 0.8s, then a restrained halo and the tier's constellation */
 const rs=eio(cxU(t,q.tp,q.tp+.5)),iy=pz.y;
 if(rs>0){c.save();c.globalCompositeOperation='lighter';
  const ra=1-eio(cxU(t,q.tp+.1,q.tp+.9));
  if(ra>0&&!q.rm){const rays=[0,0,10,14,18,24][T];c.save();c.translate(cx,iy);c.rotate(t*.1);for(let i=0;i<rays;i++){c.rotate(TAU/rays);const L=640+90*Math.sin(t*1.3+i),w=T>=5?.1:.065;c.globalAlpha=rs*ra*(T>=4?.34:.26)*(.75+.25*Math.sin(t*2+i*1.7));{const rc=i%2&&T>=5?hsx(260+i*14+t*60,90,70):tcol,gr=c.createLinearGradient(0,0,L,0);gr.addColorStop(0,rc+'ff');gr.addColorStop(1,rc+'00');c.fillStyle=gr}c.beginPath();c.moveTo(0,0);c.lineTo(Math.cos(-w)*L,Math.sin(-w)*L);c.lineTo(Math.cos(w)*L,Math.sin(w)*L);c.closePath();c.fill()}c.restore()}
  const hp=[0,0,.85,.95,1.15,1.2][T];glow(c,cx,iy,300,tcol+hxA(.3*rs*hp*(.92+.08*Math.sin(t*1.6))));glow(c,cx,iy,170,tcol+hxA(.22*rs*hp));c.restore();
  /* a soft dark core keeps the weapon's outline readable against the glow */
  c.save();g=c.createRadialGradient(cx,iy,40,cx,iy,190);g.addColorStop(0,'rgba(6,6,30,'+(.4*rs).toFixed(3)+')');g.addColorStop(1,'rgba(6,6,30,0)');c.fillStyle=g;c.fillRect(cx-200,iy-200,400,400);c.restore();
  const ca=eio(cxU(t,q.tp+.2,q.tp+1.1));
  if(T===3){c.save();c.globalAlpha=ca*.75;for(let i=0;i<6;i++){const a=i/6*TAU+t*.12,sx=cx+Math.cos(a)*236,sy=iy+Math.sin(a)*190;cxStar(c,sx,sy,6+3*Math.sin(t*2.2+i*1.9),'#d9b0ff',t,i)}c.restore()}
  else if(T===4){c.save();c.globalAlpha=ca*.8;c.strokeStyle='#ffd86a';c.lineWidth=2.4;c.setLineDash([3,12]);c.lineDashOffset=-t*18;c.beginPath();c.ellipse(cx,iy,250,200,0,0,TAU);c.stroke();c.restore();cxPCon(c,cx,iy,CX_CP,'#ffd86a',ca*.85,t,0)}
  else if(T>=5){const ea=eio(cxU(t,q.tp+.3,q.tp+1.5));c.save();c.globalAlpha=ea*.6;c.globalCompositeOperation='lighter';g=c.createRadialGradient(cx,iy,100,cx,iy,380);g.addColorStop(0,'#ffe8a066');g.addColorStop(.4,'#b070ff33');g.addColorStop(1,'#b070ff00');c.fillStyle=g;c.fillRect(cx-400,iy-400,800,800);c.globalCompositeOperation='source-over';c.globalAlpha=ea*.55;cxMoon(c,cx+30,iy,225,-.25+Math.sin(t*.8)*.04);c.restore();
   cxPCon(c,cx,iy,CX_CP,'#ffd86a',ca*.85,t,0);cxPCon(c,cx,iy,CX_CP2,'#c9a0ff',ca*.8,t,3);c.save();c.globalAlpha=ca*.9;for(let i=0;i<3;i++){const a=t*.5+i*TAU/3;cxStar(c,cx+Math.cos(a)*270,iy+Math.sin(a)*215,8,i?'#ffd86a':'#c9a0ff',t,i*2)}c.restore()}}
 /* the constellation in the sky: a dashed ellipse around the key and six stars that light in turn, each joined to the one before */
 const ca=sstep(1.4,2.0,t)*(1-sstep(3.7,4.1,t));
 if(ca>0){const hy=cxHover(),pts=CX_NODES.map((_,i)=>cxNodePos(i)),cmp=sstep(3,3.12,t)*(1-sstep(3.3,3.6,t));c.save();c.globalAlpha=ca;c.setLineDash([6,10]);c.lineDashOffset=q.rm?0:-t*14;c.strokeStyle='#8ad8ffaa';c.lineWidth=2;c.beginPath();c.ellipse(cx,hy,300,150,0,0,TAU);c.stroke();c.setLineDash([]);
  const seg=(a,b,u)=>{if(u<=0)return;const pa=pts[CX_LO[a]],pb=pts[CX_LO[b]];c.globalAlpha=ca;c.strokeStyle=cmp>0?cxMix('#9ae6ff','#ffffff',cmp):'#9ae6ff';c.lineWidth=2+cmp*1.5;c.shadowColor='#6ad4ff';c.shadowBlur=8+cmp*8;c.beginPath();c.moveTo(pa[0],pa[1]);c.lineTo(pa[0]+(pb[0]-pa[0])*u,pa[1]+(pb[1]-pa[1])*u);c.stroke()};
  for(let k=1;k<6;k++)seg(k-1,k,eio(cxU(t,cxTN(k)-.2,cxTN(k))));seg(5,0,eio(cxU(t,cxTN(5),cxTN(5)+.2)));
  c.shadowBlur=0;for(let k=0;k<6;k++){const p=pts[CX_LO[k]],l=eio(cxU(t,cxTN(k),cxTN(k)+.25));c.globalAlpha=ca;ell(c,p[0],p[1],6,6,l>0?'#e8fbff':'#2a3478');if(l>0)cxStar(c,p[0],p[1],(16+cmp*6)*l+4,'#8ad8ff',t,k)}c.restore()}
 /* the key's guide line down to the lock */
 if(t>1.9&&t<3.65){c.save();c.globalAlpha=Math.min(1,(t-1.9)*2)*.5*(1-sstep(3.3,3.65,t));c.setLineDash([6,9]);c.lineDashOffset=q.rm?0:-t*18;c.strokeStyle='#9ae6ff';c.lineWidth=2;c.beginPath();c.moveTo(cx,kp.tip+6);c.lineTo(cx,cxGemY()-30);c.stroke();c.restore()}
 /* the chest: its lid hinged at the back */
 cxChest(c,cx,by,CXS,0,t,cxChestOpts(q,t));
 /* once the star settles the chest and lid dim a little so the weapon is the focus */
 const dim=sstep(q.ts-.25,q.ts+.35,t)*.42;if(dim>0){c.save();g=c.createRadialGradient(cx,by-110,60,cx,by-110,340);g.addColorStop(0,'rgba(5,5,26,'+dim.toFixed(3)+')');g.addColorStop(.7,'rgba(5,5,26,'+(dim*.7).toFixed(3)+')');g.addColorStop(1,'rgba(5,5,26,0)');c.fillStyle=g;c.fillRect(cx-360,by-460,720,520);c.restore()}
 /* light pours out of the mouth in a narrow cyan-violet column that quiets once the star has settled */
 const op=eio(cxU(t,O,O+.55)),cq=op*(1-.65*eio(cxU(t,q.ts,q.ts+.7)));
 if(cq>0){c.save();c.globalCompositeOperation='lighter';for(let k=0;k<6;k++){const gy=my-14-k*62,rr=135-k*10;glow(c,cx,gy,rr,tc+hxA(.2*cq*(1-k*.13)))}glow(c,cx,my-20,120,'#c9e8ff'+hxA(.18*cq));c.restore()}
 /* particles that belong to the opening, behind the reward */
 c.save();c.globalCompositeOperation='lighter';for(const p of q.fx){c.globalAlpha=Math.max(0,Math.min(1,p.l*1.4))*.9;c.fillStyle=p.c;if(p.ty==='star')cxS4(c,p.x,p.y,p.s*2.3,p.c,.25);else c.fillRect(p.x-p.s/2,p.y-p.s/2,p.s,p.s)}c.restore();
 /* the reward climbs out of the chest: clipped at the mouth until it has risen clear */
 if(pz.a>0){const ic=q.itemC;try{art(ic,q.k==='a'?'a':'w',q.id,t);cxFeather(ic)}catch(e){}
  c.save();c.beginPath();c.rect(-W,-H,W*3,my+H);c.clip();c.globalAlpha=pz.a;c.translate(cx,pz.y);c.scale(pz.sc,pz.sc);c.drawImage(ic,-175,-175,350,350);c.restore();
  const fa=sstep(q.ts-.6,q.ts,t)*.75;if(fa>0)cxFrame(c,cx,pz.y,196,fa,t,tcol)}
 /* the star key (hovering above the chest) and its pulse */
 if(t>=1.3&&kp.a>.01){cxTurnArc(c,kp,t);cxPulse(c,kp,t);cxKey(c,kp,t)}
 /* shockwave rings */
 for(const r of q.rings){const uu=(t-r.t0)/r.dur;if(uu<=0||uu>=1)continue;const e=1-Math.pow(1-uu,2.3);c.save();c.globalCompositeOperation='lighter';c.globalAlpha=(1-uu)*.7;c.strokeStyle=r.c;c.lineWidth=r.lw*(1-uu)+1;c.beginPath();c.ellipse(r.x,r.y,r.max*e,r.max*e*.62,0,0,TAU);c.stroke();c.restore()}
 c.restore();/* camera */
 /* vignette and the single, low, brief flash */
 g=c.createRadialGradient(W/2,H/2,H*.45,W/2,H/2,H*1.05);g.addColorStop(0,'#00000000');g.addColorStop(1,'#000000aa');c.fillStyle=g;c.fillRect(-80,-80,W+160,H+160);
 if(q.fl>0&&ST.flash!==false&&!q.rm){c.fillStyle='rgba(190,225,255,'+(.12*Math.min(1,q.fl)).toFixed(3)+')';c.fillRect(-80,-80,W+160,H+160)}
 c.restore();
 /* title, captions and the rarity word (screen space, above all effects) */
 if(!q.done){c.save();const ta=1-sstep(O+.1,O+.5,t);c.globalAlpha=ta;c.font='700 50px "Cinzel",Georgia,serif';c.textAlign='center';c.textBaseline='middle';c.fillStyle='#e0d0ff';c.shadowColor='#9a7aff';c.shadowBlur=16;c.fillText('CELESTIAL CHEST',cx,58);c.shadowBlur=0;c.fillStyle='#a98aff';c.fillRect(cx-250,92,190,2);c.fillRect(cx+60,92,190,2);cxS4(c,cx,93,10,'#c9a8ff',.2);c.restore()}
 {const st=[0,1.3,3.1,O+.7],ph=t<st[1]?0:t<st[2]?1:t<st[3]?2:3,cp=CX_CAP[ph],ca2=Math.min(1,(t-st[ph])*3+.001)*(q.done||q.skipped?0:1)*(ph===3?1-sstep(q.ts-.3,q.ts+.1,t):1);if(ca2>0){c.save();c.globalAlpha=ca2*.95;cxCap(c,cp,cx,134,24,'#f0e6ff',7);c.restore()}}
 if(t>q.ts-.1){const a=sstep(q.ts-.1,q.ts+.35,t),size=[0,0,66,76,88,100][T],txt=q.it.r.toUpperCase();c.save();c.globalAlpha=a;c.font='800 '+size*(1.2-.2*a)+'px "Cinzel",Georgia,serif';c.textAlign='center';c.textBaseline='middle';c.shadowColor=tcol;c.shadowBlur=18;c.fillStyle=T>=5?hsx(t*60,80,78):T===4?'#ffe9a0':T===3?'#ecd2ff':'#cfe6ff';const sp=T>=4?10:7;const w=[...txt].map(ch=>c.measureText(ch).width+sp),tot=w.reduce((x,y)=>x+y,0)-sp;let px=cx-tot/2;c.textAlign='left';[...txt].forEach((ch,i)=>{c.fillText(ch,px,96);px+=w[i]});c.restore()}}

/* ---------- the sound ---------- */
let CX_BUF=null,CX_LOAD=null;
function cxLoad(){if(CX_BUF!==null||CX_LOAD||!ac)return CX_LOAD;try{const bin=atob(CX_B64),u=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);
 CX_LOAD=new Promise((res,rej)=>{const p=ac.decodeAudioData(u.buffer,res,rej);if(p&&p.then)p.then(res,rej)}).then(b=>{CX_BUF=b;return b}).catch(()=>{CX_BUF=0;return 0})}catch(e){CX_BUF=0}return CX_LOAD}
function cxPlaySample(q,o,T0){const live=()=>S.cr2===q&&!q.skipped&&!q.dead;const go=b=>{if(!b||!live())return;try{const el=ac.currentTime-T0;if(el>6.9)return;const s=ac.createBufferSource(),gn=ac.createGain();s.buffer=b;gn.gain.value=1.55;s.connect(gn);gn.connect(o);s.start(Math.max(ac.currentTime,T0),Math.max(0,el));q.src=s}catch(e){}};
 const fb=()=>{if(live())cxFallback(o,Math.max(T0,ac.currentTime))};
 if(CX_BUF)go(CX_BUF);else if(CX_BUF===0)fb();else{const p=cxLoad();if(p)p.then(b=>b?go(b):fb())}}
/* if the recording cannot be decoded, a synthesised drone and chord stand in for it */
function cxFallback(o,T0){cTone(o,T0,55,3.9,'sine',.2,{f2:110,a:.4,swell:1});cTone(o,T0+.05,110,3.9,'triangle',.07,{f2:220,a:.5,swell:1});cNoise(o,T0,3.9,.05,{rev:1,type:'bandpass',f1:300,f2:1800,q:1.2});[57,64,69,76].forEach(m=>cChoir(o,T0+CXO.O,nf(m),3,.03))}
const CXN=[88,91,93,95,98,100];
function cxAudio(q){if(!axOn())return;const T0=ac.currentTime+.05,o=ac.createGain();o.gain.value=1;o.connect(sg);q.aud=o;q.aT=T0;const T=q.tier,O=q.O;
 try{if(mg&&!ST.mute)mg.gain.setTargetAtTime(ST.mvol*.6*.1,ac.currentTime,.25)}catch(e){}
 cxPlaySample(q,o,T0);
 /* the sky chimes: one rising glint, then a bell for each constellation star as it lights */
 cBell(o,T0+1.0,nf(84),.04,1.8);cBell(o,T0+1.07,nf(91),.025,1.4);
 CXN.forEach((m,i)=>{cBell(o,T0+cxTN(i),nf(m),.05,1.6);cTone(o,T0+cxTN(i),nf(m)*2,.5,'sine',.012,{a:.003})});
 cNoise(o,T0+1.2,.5,.05,{type:'highpass',f1:5000,f2:9000,a:.2});
 /* the key lifts out, the constellation completes, the key turns, the pulse runs in, the lock gives */
 cTone(o,T0+1.3,nf(60),.7,'sine',.05,{f2:nf(84),a:.05,lp:3000});cNoise(o,T0+1.3,.7,.05,{type:'bandpass',f1:1200,f2:5200,q:1.5,a:.25});
 cBell(o,T0+3.0,nf(105),.04,1.4);
 cTone(o,T0+3.1,nf(88),.3,'sine',.03,{f2:nf(94),a:.02});cNoise(o,T0+3.38,.05,.07,{type:'highpass',f1:4000,f2:4000,a:.001});cTone(o,T0+3.4,nf(110),.12,'square',.02,{a:.002});
 cTone(o,T0+3.4,nf(84),.25,'sine',.04,{f2:nf(112),a:.02});cNoise(o,T0+3.4,.25,.04,{type:'bandpass',f1:900,f2:5200,q:1.4,a:.2});
 cKick(o,T0+3.65,.5,110,32,.6);cBell(o,T0+3.65,nf(96),.1,1.2);cNoise(o,T0+3.65,.09,.1,{type:'highpass',f1:3000,f2:3000,a:.001});
 cSpark(o,T0+3.7,14,.5,95,.025);
 cNoise(o,T0+2.65,1.25,.1,{rev:1,type:'bandpass',f1:300,f2:6000,q:1,a:.9});
 cxReveal(o,T0+O,T,true);cxTierSfx(o,T0+q.tp,T,true)}
/* the lid breaking is the same for every rarity; the tier only shows in the sound when the star appears */
function cxReveal(o,t,T,full){
 cKick(o,t,.65,95,28,1.2);cNoise(o,t,1.2,.2,{f1:5200,f2:200});cNoise(o,t,.12,.25,{type:'bandpass',f1:1200,f2:500,q:1.4});
 [76,79,83,88].forEach((m,i)=>cHarp(o,t+.03+i*.07,nf(m),.07));cSpark(o,t+.1,14,2.8,88,.03)}
function cxTierSfx(o,t,T,full){
 cKick(o,t,.18+T*.07,100,30,.5+T*.12);[91,95].slice(0,Math.max(0,T-2)).forEach((m,i)=>cHarp(o,t+.03+i*.07,nf(m),.06));cSpark(o,t+.05,6+T*5,2.2+T*.2,90,.03);
 if(T>=3){[57,64,69,73].forEach(m=>cChoir(o,t+.05,nf(m),2.8,.022))}
 if(T>=4){cTimp(o,t+.04,6,.06,.16);[69,76,81,85,88].forEach((m,i)=>cBell(o,t+.3+i*.16,nf(m),.06,2.2));cTone(o,t,nf(33),3.4,'sine',.2,{a:.04,hold:1,r:1})}
 if(T>=5){cTone(o,t,nf(26),5,'sine',.26,{a:.06,hold:1,r:1.6});[45,52,57,64,69,73,76].forEach(m=>cChoir(o,t+.05,nf(m),3.4,.02));cNoise(o,t+.3,3,.06,{rev:0,type:'bandpass',f1:6000,f2:900,q:1,a:.4});[93,95,98,100,102,105].forEach((m,i)=>cBell(o,t+.9+i*.28,nf(m),.05,2.4));if(full)cSpark(o,t+.6,30,3.2,90,.025)}}
/* fade the opening's audio (the recording and every layered cue run through q.aud) */
function cxFade(q,d){try{const g=q&&q.aud&&q.aud.gain;if(g){const n=ac.currentTime;g.cancelScheduledValues(n);g.setValueAtTime(g.value,n);g.linearRampToValueAtTime(0,n+d)}}catch(e){}try{if(q&&q.src)q.src.stop(ac.currentTime+d+.05)}catch(e){}}

/* ---------- the information panel ---------- */
{const st=document.createElement('style');st.textContent=`
#ov.clear.cxov{background:linear-gradient(#0000 66%,rgba(4,2,14,.55))}
#ov .cxres{width:min(780px,100%);margin:0 auto;padding:14px 26px 18px;border-radius:18px;background:linear-gradient(180deg,#15133cf0,#0a0826f5);border:2px solid var(--c);box-shadow:0 0 28px color-mix(in srgb,var(--c) 38%,transparent),0 12px 30px #000b;animation:cxrin .45s cubic-bezier(.2,.8,.25,1) both;display:flex;flex-direction:column;align-items:center;gap:6px;max-height:100%;overflow:auto}
#ov .cxres h2{font:700 clamp(26px,3.6vw,40px)/1.1 Cinzel,Georgia,serif;margin:0;color:var(--c);text-shadow:0 2px 10px #000}
#ov .cxres .cxkind{font:600 13px Poppins,system-ui,sans-serif;letter-spacing:.18em;text-transform:uppercase;color:#aeb4e6}
#ov .cxres p{margin:0;max-width:none;opacity:1}
#ov .cxres .cxd{font:500 clamp(16px,1.9vw,20px)/1.45 Georgia,serif;color:#eef1ff}
#ov .cxres .cxo{font:400 16px/1.4 Georgia,serif;color:#c3c8ee}
#ov .cxres .row{display:flex;flex-wrap:wrap;justify-content:center;gap:12px;margin-top:6px}
@media (max-height:520px){#ov.clear.cxov{padding:6px 14px 8px}#ov .cxres{padding:8px 16px 10px;gap:3px;width:min(560px,100%)}#ov .cxres h2{font-size:22px}#ov .cxres .cxkind{display:none}#ov .cxres .cxd{font-size:14px;line-height:1.3}#ov .cxres .cxo{font-size:12.5px}#ov .cxres .row{margin-top:2px;gap:8px}#ov .cxres button{font-size:18px;padding:5px 18px;min-height:40px}#ov .cxres button.sm{font-size:16px;padding:5px 14px;min-height:40px}}
@keyframes cxrin{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:none}}
@media (prefers-reduced-motion:reduce){#ov .cxres{animation:cxrfade .25s ease-out both}@keyframes cxrfade{from{opacity:0}to{opacity:1}}}`;
 document.head.appendChild(st)}
{const cr=crateResult;crateResult=function(){const q=S.cr2;if(!q||!q.cx)return cr.apply(this,arguments);const it=q.it,tier=q.tier;
 if(tier<4&&axOn()){const o=ac.createGain();o.gain.value=1;o.connect(sg);altFinale(o,ac.currentTime+.02,0)}
 const more=P[CN[q.ck||q.k]]>0,col=RC[it.r]||'#fff';
 show(`<div class="cxres" style="--c:${col}"><h2>${it.n}</h2><div class="cxkind">${q.k==='a'?'Armor':'Weapon'}${q.k!=='a'&&it.p!=='knight'?` &middot; ${PATHS[it.p].n} path`:''}</div><p class="cxd">${it.d}</p><p class="cxo">${q.dup?`Duplicate, converted into 40 XP and ${GOLDDUP[it.r]} gold.`:'<b style="color:var(--gold)">New!</b> Added to your armory.'}</p><div class="row"><button id="a">Equip</button>${more?'<button class="sm" id="m">Open another</button>':''}<button class="sm" id="b">Back</button></div></div>`,'clear');
 ov.classList.add('cxov');achCheck();
 $('a').onclick=()=>{if(q.k==='a'){P.armor=q.id;save()}else setWeapon(q.id);crateEnd();title()};if(more)$('m').onclick=()=>{crateEnd();crateStart(q.ck||q.k)};$('b').onclick=()=>{crateEnd();title()}}}

/* ---------- hooks: the Celestial Chest takes this path, everything else passes through ---------- */
{const ca=crateAudio;crateAudio=function(q){if(q&&q.ck==='c'){cxPrep(q);try{ov.classList.add('cxov')}catch(e){}return cxAudio(q)}return ca(q)}}
{const cu=crateUpdate;crateUpdate=function(dt){if(S.cr2&&S.cr2.cx)return cxUpdate();return cu(dt)}}
{const dc=drawCrateScene;drawCrateScene=function(){if(S.cr2&&S.cr2.cx){cxDraw();return}return dc()}}
/* Skip: straight to the finished reward screen, with every unfinished effect and sound stopped; it can only ever run once */
{const sk=crateSkip;crateSkip=function(){const q=S.cr2;if(!q||!q.cx)return sk();if(q.done||q.skipped)return;
  q.skipped=1;cxFade(q,.2);
  for(const k of['n0','n1','n2','n3','n4','n5','lift','cmp','turn','lock','open','rise','set'])q.fired[k]=1;
  q.fx=[];q.rings=[];q.fl=0;q.shk=0;q.t=q.E+.05;
  if(axOn()){const o=ac.createGain();o.gain.value=1;o.connect(sg);q.aud=o;const t0=ac.currentTime+.22;cxReveal(o,t0,q.tier,false);cxTierSfx(o,t0+.05,q.tier,false)}}}
{const ce=crateEnd;crateEnd=function(){const q=S.cr2,w=q&&q.cx;ce();if(w){q.dead=1;cxFade(q,.2);try{ov.classList.remove('cxov');if(mg)mg.gain.setTargetAtTime(ST.mute?0:ST.mvol*.6,ac.currentTime,.4)}catch(e){}}}}
