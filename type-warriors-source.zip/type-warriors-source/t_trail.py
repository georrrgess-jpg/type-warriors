import asyncio,os
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append('PE '+str(e)[:300]))
        await pg.goto('file://'+os.path.abspath('out.html'));await pg.wait_for_timeout(900);E=pg.evaluate
        # tickpip vs boss
        await E("()=>{RS_ASK=false;title();P.petSt=2;P.pets={tick:{b:0}};P.pet='tick';petNorm();start(1);S.wave=4;S.round=4;startWave()}")
        await pg.wait_for_timeout(5500)
        print('tick boss',await E("()=>{const b=S.en.find(e=>e.boss);return b?JSON.stringify({tk:b._ptk,tm:+b.tm.toFixed(1),tmax:+b.tmax.toFixed(1),uses:S.pet.uses}):'no boss '+S.round}"))
        # campaign victory stamp: fresh trail, starter state
        await E("()=>{title();P.pets={};P.pet='';P.petSt=0;P.trail={n:4,c:0};P.eggs={r:0,l:0};petNorm();start(2);setTimeout(()=>victory(),800)}")
        await pg.wait_for_timeout(4500);await pg.screenshot(path='shots/tr_victory.png')
        print('after victory',await E("()=>JSON.stringify({trail:P.trail,eggs:P.eggs,st:P.petSt,notice:(document.querySelector('.ptrs')||{}).textContent})"))
        # endless block of 5
        await E("()=>{title();P.petSt=2;P.pets={bramble:{b:0}};P.pet='bramble';petNorm();start(0);S.wave=5;startWave()}");await pg.wait_for_timeout(600)
        print('endless',await E("()=>JSON.stringify({trail:P.trail,eggs:P.eggs,bond:P.pets.bramble.b,stamps:S.pet.stamps.length})"))
        await E("()=>{S.wave=6;startWave();S.wave=10;startWave()}");print('endless2',await E("()=>JSON.stringify({trail:P.trail,stamps:S.pet.stamps.length})"))
        await E("()=>over(true)");await pg.wait_for_timeout(800);await pg.screenshot(path='shots/tr_over.png');print('over notice',await E("()=>(document.querySelector('.ptrs')||{}).textContent"))
        # daily / practice do not stamp
        n0=await E("()=>P.trail.n")
        await E("()=>{title();start(0,'prac');S.wave=5;startWave()}");await pg.wait_for_timeout(300)
        print('prac stamp?',n0,await E("()=>P.trail.n"),await E("()=>JSON.stringify(S.pet&&{cos:S.pet.cos})"))
        print(er[:6]);await b.close()
asyncio.run(main())
