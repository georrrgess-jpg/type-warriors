/* ===== 10.4 HARVEST FESTIVAL: the Harvest Chest, roll and opening (99o2, prefix flc; after 99o art) =====
   THE ROLL (flcOdds() gives the table the shop and the crates menu show):
     a rarity tier like the Graveyard Crate (Common 40, Uncommon 29, Rare 20, Epic 8.25, Legendary 2, Mythic 0.75 %), Epic or better
     guaranteed by the 15th chest (P.fcpity). Inside a tier: Common is a relic 55 % of the time, else coins / XP / acorns; Uncommon a
     relic 75 %, else a bigger purse or acorns; Rare a relic, with a 7.5 % share for the Acorn Scamp; Legendary a relic, with a 20 %
     share for Emberleaf. A companion you own (or one the game cannot grant) becomes a relic of its tier. Relics you do not own are
     three times as likely; duplicates convert into 40 XP and the usual duplicate gold, like every crate.
     Acorns and companions are granted when the reveal ends (P.flcPend keeps them safe across a reload): fleGive / flpGive when those
     parts are loaded, otherwise coins.
   THE OPENING (all timed on one clock, picture and sound together):
     0-0.5 s   night falls over a moonlit pumpkin patch and corn field; wind and crickets.
     0.45 s    a gust sweeps in from the left: the corn bends and the heap of leaves over the chest whirls away.
     1.5 s     the scarecrow turns its head to watch (a wooden creak).
     2.0 s ->  one harvest lantern lights per rarity tier with a deep wooden chime, the harvest moon rises, the leaves circle the chest
               faster and faster over a frame-drum heartbeat; the pumpkin lock blazes.
     Epic      crows burst from the corn with a chorus of caws.   Legendary  the moon turns gold.
     Mythic    the turkey's feathered silhouette fans across the moon, the cornucopia appears and spills gold, letterbox bars.
     open      the lid bursts, the prize rises in a column of warm light, the rarity name drops in letter by letter.
   Skippable (click, Space, Enter, Esc) like the other chests; reduced motion (no shake, no flash, fewer leaves) and Performance mode
   (fewer particles; 10.4 merge: no mist, no lantern pools of light, a smaller glow behind the chest and no Mythic bloom over the
   whole screen, the costly full-screen layers) have their own versions. The Graveyard and Celestial openings are untouched: only key 'f' takes this path. */
const FLC={ret:null,keep:0};
const FLC_TIERP=[.40,.29,.20,.0825,.02,.0075],FLC_PITY=15,FLC_HIDE=[0,0,0,0,1,1];
const FLC_SPLIT=[{coin:.20,xp:.125,ac:.125},{coin:.12,ac:.13},{pet:.075},{},{pet:.2},{}];
const FLCT={O:[3.8,3.8,4.3,5.2,7.0,10.6],D:[1.8,1.8,2.0,2.4,3.2,6.6]};
const FLC_FIRE=['#ffc070','#ffc070','#7ac8ff','#d68cff','#ffd45a','#ff6a4a'];
const FLC_LP=[[-500,46],[-352,66],[-205,80],[205,80],[352,66],[500,46]],FLC_ORD=[2,3,1,4,0,5];
const flcTC=q=>q.tier>=5?'#ff8a3a':q.tier===4?'#ffd45a':(RC[FL.rar[q.tier]]||'#ffc070');
const flcRar=t=>FL.rar[Math.max(0,Math.min(5,t|0))];
const flcPetName=id=>(FL.petN&&FL.petN[id])||(typeof PDEF!=='undefined'&&PDEF[id]&&PDEF[id].n)||'a harvest companion';

/* ---------- the drop table ---------- */
function flcOdds(){const rows=[];FLC_TIERP.forEach((p,t)=>{const sp=FLC_SPLIT[t];let rest=1;
  for(const k in sp){rest-=sp[k];rows.push({k,tier:t,p:p*sp[k],id:k==='pet'?(t===2?FL.pets.r:FL.pets.l):null})}
  rows.unshift({k:'relic',tier:t,p:p*rest})});
 rows.sort((a,b)=>a.tier-b.tier||(a.k==='relic'?-1:b.k==='relic'?1:0));
 return{tiers:FLC_TIERP.slice(),rows,pity:FLC_PITY,hide:FLC_HIDE.slice(),rar:FL.rar.slice(),
  gear:FL.gear.a.map((a,i)=>({tier:i,a,w:FL.gear.w[i]})),pets:[{id:FL.pets.r,tier:2},{id:FL.pets.l,tier:4}]}}
const flcPend=()=>{if(!Array.isArray(P.flcPend))P.flcPend=[];return P.flcPend};
function flcPetOk(id){try{return typeof flpGive==='function'&&typeof PDEF!=='undefined'&&!!PDEF[id]&&!(typeof petOwned==='function'&&petOwned(id))&&!flcPend().some(x=>x.k==='pet'&&x.id===id)}catch(e){return false}}
function flcRelic(tier){const pool=[],a=FL.gear.a[tier],w=FL.gear.w[tier];
 if(a&&AR[a])pool.push({kind:'a',id:a,own:!!P.ownA[a]});
 if(w&&WP[w]&&(!WP[w].p||typeof pathOpen!=='function'||pathOpen(WP[w].p)))pool.push({kind:'w',id:w,own:!!P.own[w]});
 if(!pool.length)return null;const wt=x=>x.own?1:3;let r=Math.random()*pool.reduce((s,x)=>s+wt(x),0);for(const x of pool){r-=wt(x);if(r<=0)return x}return pool[0]}
const FLC_AMT={coin:[[150,250],[350,550]],xp:[[100,150],[160,220]],ac:[[20,30],[45,60]]};
const flcAmt=(k,t)=>{const a=FLC_AMT[k][Math.min(1,t)],step=k==='ac'?1:10;return a[0]+Math.round(Math.random()*(a[1]-a[0])/step)*step};
/* the pick, before anything is granted */
function flcRoll(){let tier=0;const forced=(P.fcpity|0)+1>=FLC_PITY;
 if(forced){const w=FLC_TIERP.slice(3),s=w.reduce((a,b)=>a+b,0);let r=Math.random()*s;tier=3;for(let i=0;i<w.length;i++){r-=w[i];if(r<=0){tier=3+i;break}}}
 else{let r=Math.random();for(let i=0;i<FLC_TIERP.length;i++){tier=i;r-=FLC_TIERP[i];if(r<=0)break}}
 const sp=FLC_SPLIT[tier];let k='relic',r=Math.random();for(const kk in sp){r-=sp[kk];if(r<0){k=kk;break}}
 if(k==='pet'){const id=tier===2?FL.pets.r:FL.pets.l;if(flcPetOk(id))return{k,tier,id};k='relic'}
 if(k==='relic'){const x=flcRelic(tier);if(x)return{k,tier,kind:x.kind,id:x.id};k='coin'}
 return{k,tier:Math.min(1,tier),n:flcAmt(k,tier)}}
/* a synthetic item for rewards that are not gear (name, rarity, colour, description) */
function flcItem(r){const rn=flcRar(r.tier),col=RC[rn]||'#ffc070';
 if(r.k==='coin')return{n:r.n.toLocaleString()+' gold',r:rn,col,d:'A purse of harvest coins.'};
 if(r.k==='xp')return{n:r.n+' XP',r:rn,col,d:'The wisdom of a long harvest.'};
 if(r.k==='ac')return{n:r.n+' acorns',r:rn,col,d:'Festival acorns for the Harvest Market.'};
 if(r.k==='pet')return{n:flcPetName(r.id),r:rn,col,d:`A ${rn} harvest companion joins you.`};
 return{n:'?',r:rn,col,d:''}}
/* spend one chest and grant what it holds (gear, coins and XP at once; acorns and companions when the reveal ends) */
function flcRollF(){P.fcr=Math.max(0,P.fcr|0);if(!(P.fcr>=1))return null;P.fcr--;const r=flcRoll();let kind=r.k,id=r.id||null,it,dup=false,T=null,o=null;
 if(r.k==='relic'){kind=r.kind;T=kind==='a'?AR:WP;o=kind==='a'?'ownA':'own';it=T[id];dup=!!P[o][id];
  if(typeof flgGive==='function'){try{flgGive(kind,id)}catch(e){}}P[o][id]=1;if(dup){P.xp+=40;P.gold+=GOLDDUP[it.r]}}
 else{it=flcItem(r);
  if(r.k==='coin')P.gold+=r.n;else if(r.k==='xp')P.xp+=r.n;
  else if(r.k==='ac'){if(typeof fleGive==='function')flcPend().push({k:'ac',n:r.n});else{r.k=kind='coin';r.n=r.n*8;it=flcItem(r);P.gold+=r.n}}
  else if(r.k==='pet')flcPend().push({k:'pet',id:r.id})}
 P.fcpity=r.tier>=3?0:(P.fcpity|0)+1;
 try{stat('crates',1,'add');stat('fcr',1,'add');if(r.tier>=3)stat('epic',r.tier,'max')}catch(e){}
 window.__pf=0;save();return{kind,id,it,dup,pf:0,T,o,fl:r}}
/* hand over acorns and companions that are waiting (after a reveal, a batch, or a reload in the middle of one) */
function flcPendRun(){if(!P||!Array.isArray(P.flcPend)||!P.flcPend.length)return 0;const L=P.flcPend.splice(0);save();let n=0;
 for(const x of L){try{
  if(x.k==='ac'){if(typeof fleGive==='function')fleGive(x.n,'Harvest Chest');else P.gold+=x.n*8;n++}
  else if(x.k==='pet'){let ok=false;if(typeof flpGive==='function'){try{flpGive(x.id);ok=true}catch(e){}}if(!ok)P.gold+=x.id===FL.pets.l?5000:1500;n++}}catch(e){}}
 save();return n}

/* ---------- sound ---------- */
/* a deep wooden chime: a struck wooden bar with a soft knock and a slap of echo */
function flcChime(o,t,f,v){cTone(o,t,f,1.9,'sine',v,{a:.004});cTone(o,t,f*2,.7,'sine',v*.28,{a:.003});cTone(o,t,f*3.92,.24,'sine',v*.22,{a:.002});cTone(o,t,f*.5,.5,'triangle',v*.35,{a:.004,lp:600});
 cNoise(o,t,.05,v*.7,{type:'bandpass',f1:1700,q:3,a:.002});cTone(o,t+.13,f,1.2,'sine',v*.22,{a:.01});cTone(o,t+.26,f,.9,'sine',v*.1,{a:.01})}
function flcWood(o,t,v){cKick(o,t,v,150,70,.18);cNoise(o,t,.06,v*.6,{type:'bandpass',f1:900,q:2.5,a:.002})}
function flcDrum(o,t,v){cKick(o,t,v,88,46,.32);cNoise(o,t,.12,v*.35,{f1:420,f2:160,a:.003})}
function flcRustle(o,t,d,v){const n=Math.min(40,d*30|0);for(let k=0;k<n;k++)cNoise(o,t+Math.random()*d,.03+Math.random()*.03,v*(.4+Math.random()*.6),{type:'bandpass',f1:2400+Math.random()*4200,q:2.2,a:.002})}
function flcGust(o,t,v){cNoise(o,t,1.5,v,{type:'bandpass',f1:280,f2:1900,q:1.4,a:.55});cNoise(o,t+.2,1.3,v*.6,{type:'bandpass',f1:1400,f2:500,q:1.2,a:.4});flcRustle(o,t+.25,1.2,v*.5)}
function flcCrickets(o,t,d,v){for(let tt=t+.3;tt<t+d;tt+=.62+Math.random()*.4){const f=4100+Math.random()*500;for(let i=0;i<2;i++)cTone(o,tt+i*.034,f,.024,'sine',v,{a:.003})}}
function flcCaw(o,t,v,f){f=f||560;hxVoice(o,t,.26,f*1.25,f*.78,v,[[1250,3,1],[2500,5,.55]],28);cNoise(o,t+.02,.22,v*.45,{type:'bandpass',f1:1600,f2:1100,q:1.4,a:.03})}
function flcFlutter(o,t,d,v){for(let k=0;k<d*22;k++)cNoise(o,t+k/22+Math.random()*.01,.035,v*(.5+Math.random()*.5),{f1:900,f2:300,a:.003})}
function flcFiddle(o,t,f,d,v){hxVoice(o,t,d,f,f*1.002,v,[[880,2.5,1],[2300,4,.45],[3600,6,.2]],5.4)}
function flcReed(o,t,f,d,v){for(const det of[-5,5])cTone(o,t,f,d,'sawtooth',v,{det,a:.12,hold:1,r:.4,lp:1500,lp2:900});cTone(o,t,f*2,d,'square',v*.18,{a:.12,hold:1,r:.4,lp:1800})}
const flcChord=(o,t,ms,d,v)=>ms.forEach(m=>flcReed(o,t,nf(m),d,v));
function flcCoins(o,t,d,n,v){for(let i=0;i<n;i++){const tt=t+Math.random()*d,f=2400+Math.random()*2600;cTone(o,tt,f,.09,'triangle',v,{a:.001});cTone(o,tt,f*1.5,.05,'sine',v*.5,{a:.001});cNoise(o,tt,.02,v*.6,{type:'highpass',f1:6000,a:.001})}}
function flcFwip(o,t,v){cNoise(o,t,.11,v,{type:'bandpass',f1:2600,f2:700,q:1.3,a:.006})}
function flcGobble(o,t,v){try{const os=ac.createOscillator(),lf=ac.createOscillator(),lg=ac.createGain(),am=ac.createOscillator(),ag=ac.createGain(),g=ac.createGain(),b=ac.createBiquadFilter(),b2=ac.createBiquadFilter();
  os.type='sawtooth';os.frequency.setValueAtTime(330,t);os.frequency.exponentialRampToValueAtTime(220,t+.75);lf.frequency.value=17;lg.gain.value=70;lf.connect(lg);lg.connect(os.frequency);
  am.frequency.value=17;ag.gain.value=.5;am.connect(ag);b.type='bandpass';b.frequency.value=900;b.Q.value=2.4;b2.type='bandpass';b2.frequency.value=2100;b2.Q.value=4;
  const mix=ac.createGain();mix.gain.value=1;ag.connect(mix.gain);g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(v,t+.06);g.gain.setValueAtTime(v,t+.55);g.gain.exponentialRampToValueAtTime(.0001,t+.8);
  os.connect(b);os.connect(b2);b.connect(mix);b2.connect(mix);mix.connect(g);g.connect(o);[os,lf,am].forEach(x=>{x.start(t);x.stop(t+.85)})}catch(e){}
 cTone(o,t,52,1.4,'sine',v*1.4,{f2:34,a:.02});cNoise(o,t,1.3,v*.6,{f1:600,f2:80,a:.05})}
function flcShimmer(o,t,v){cSpark(o,t,14,1.2,88,v*.6);[74,78,81,86].forEach((m,i)=>cChoir(o,t+i*.06,nf(m),1.8,v*.32));cPad(o,t,[nf(62),nf(69),nf(74)],1.8,v*.3,2400)}
function flcReveal(o,t,tier,full){
 cKick(o,t,.45+tier*.07,110,34,.9+tier*.12);cNoise(o,t,.9+tier*.3,.18+tier*.02,{f1:4400+tier*700,f2:180});cNoise(o,t,.12,.22,{type:'bandpass',f1:800,f2:420,q:1.5});hxWhoomph(o,t+.02,.22+tier*.03);flcRustle(o,t+.02,.9,.08);
 const pen=[0,2,4,7,9];
 if(tier<=1){[67,69,71,74,76,79].slice(0,tier?6:4).forEach((m,i)=>flcChime(o,t+.05+i*.075,nf(m),.06));flcWood(o,t+.5,.2);if(tier)[79,81,83].forEach((m,i)=>flcFiddle(o,t+.55+i*.16,nf(m),.3,.05))}
 else if(tier===2){flcChord(o,t+.05,[55,62,67,71],1.8,.022);[67,71,74,79,83].forEach((m,i)=>flcChime(o,t+.08+i*.07,nf(m),.055));flcFiddle(o,t+.45,nf(83),.9,.05)}
 else if(tier===3){flcChord(o,t+.05,[52,59,64,67,71],2.4,.022);cTimp(o,t+.05,6,.07,.16);[0,1,2,3].forEach(i=>flcCaw(o,t+.25+i*.22+Math.random()*.08,.05,520+i*40));[64,67,71,76].forEach(m=>cChoir(o,t+.25,nf(m),2,.018))}
 else if(tier===4){const P=[[[50,57,62,66],.6],[[47,55,62,67],.6],[[50,57,62,66,69],2.2]];let tt=t+.05;for(const [ms,d] of P){flcChord(o,tt,ms,d+.1,.02);tt+=d}
  cTimp(o,t+.05,8,.07,.17);for(let i=0;i<16;i++)cBell(o,t+.06+i*.045,nf(62+pen[i%5]+12*((i/5)|0)),.07,1.4);cTone(o,t,nf(26),2.6,'sine',.2,{a:.05,hold:1,r:1});
  if(full){let tt2=t+1.0;for(const [n,d] of[[74,.24],[78,.24],[81,.48],[79,.24],[78,.24],[74,.9]]){cBrass(o,tt2,nf(n),d+.12,.05);flcFiddle(o,tt2,nf(n+12),d+.1,.03);tt2+=d}flcShimmer(o,t+2.4,.06)}
  else{cBrass(o,t+.35,nf(81),1.1,.06);cBrass(o,t+.35,nf(74),1.1,.04)}}
 else{flcGobble(o,t+.05,.07);cTone(o,t,nf(26),6,'sine',.24,{a:.08,hold:1,r:2});cKick(o,t+.12,.5,58,28,1.6);
  const P=full?[[[50,57,62,66],.9],[[47,55,62,67],.9],[[43,55,59,62,67],.9],[[45,57,61,64,69],.9],[[50,57,62,66,69,74],3.4]]:[[[50,57,62,66,69,74],2.8]];let tt=t+.1;
  for(const [ms,d] of P){flcChord(o,tt,ms,d+.12,.018);ms.slice(-3).forEach(m=>cChoir(o,tt,nf(m+12),d+.3,.013));tt+=d}
  cTimp(o,t+.1,10,.08,.16);flcCoins(o,t+.1,full?4.5:2,full?44:24,.04);for(let i=0;i<20;i++)cBell(o,t+.3+i*.06,nf(74+pen[i%5]+12*(((i/5)|0)%2)),.05,1.4);
  if(full){let tt2=t+1.0;for(const [n,d] of[[74,.3],[78,.3],[81,.3],[86,.6],[83,.3],[81,.3],[78,.3],[81,1.2]]){cBrass(o,tt2,nf(n),d+.12,.045);flcFiddle(o,tt2,nf(n),d+.1,.035);tt2+=d}cSpark(o,t+1.5,30,5,86,.025)}}}
function flcAudio(q){if(!axOn())return;const T0=ac.currentTime+.06,o=ac.createGain();o.gain.value=1;o.connect(sg);q.aud=o;q.aT=T0;const tier=q.tier,O=q.O;
 try{if(mg&&!ST.mute)mg.gain.setTargetAtTime(ST.mvol*.6*.12,ac.currentTime,.25)}catch(e){}
 cNoise(o,T0,O+3,.04,{type:'bandpass',f1:380,f2:900,q:2.6,a:1.2});flcCrickets(o,T0,O+2,.018);
 flcGust(o,T0+.42,.17);flcWood(o,T0+1.3,.22);
 if(typeof hxCreak==='function')hxCreak(o,T0+1.48,.55,.05);flcRustle(o,T0+1.5,.4,.04);
 q.pt.forEach((tt,i)=>flcChime(o,T0+tt,nf([50,53,55,57,60,62][i]),.11));
 if(tier>=1){let tb=T0+2.05,k=0;while(tb<T0+O-.2&&k<40){const u=(tb-T0-2)/Math.max(.5,O-2);flcDrum(o,tb,.16+.3*u);tb+=.85-.48*Math.min(1,u);k++}}
 if(tier>=2){for(let tt=2.4;tt<O-.4;tt+=1.25)flcRustle(o,T0+tt,.9,.03+.01*tier);cNoise(o,T0+2,O-2,.07+tier*.012,{rev:1,type:'bandpass',f1:300,f2:3600,q:1.3})}
 if(tier>=3){const tc=q.crowT;for(let i=0;i<7+tier*2;i++)flcCaw(o,T0+tc+Math.random()*1.6,.045,480+Math.random()*180);flcFlutter(o,T0+tc,1.6,.06)}
 if(tier>=4)flcShimmer(o,T0+q.goldT,.07);
 if(tier>=5){for(let i=0;i<13;i++)flcFwip(o,T0+4.6+i*.2,.09);cTimp(o,T0+4.6,14,.2,.08);flcGobble(o,T0+O-1.0,.06);flcCoins(o,T0+O-3.4,3.2,24,.024);
  [50,57,62,66].forEach(m=>cChoir(o,T0+O-4.4,nf(m),4.4,.016))}
 if(typeof hxCreak==='function')hxCreak(o,T0+O-.9,.85,.08)}
/* the reveal's music is scheduled 1.2 s ahead of the lid, so the start does not do all the work at once */

/* ---------- preparing a scene ---------- */
function flcTimes(q){const T=q.tier,O=q.O,L=T+1,pt=[];for(let i=0;i<L;i++)pt.push(L===1?2.1+(O-2.9)*.5:2.1+(O-2.9)*(i/(L-1)));return pt}
function flcPrep(q){const T=q.tier,rm=flcRM(),lo=flcLow(),k=lo?.45:rm?.5:1;q.fc=1;q.rm=rm;q.lo=lo;q.O=FLCT.O[T];q.E=q.O+FLCT.D[T];q.pt=flcTimes(q);q.lit=[0,0,0,0,0,0];q.litT=[0,0,0,0,0,0];
 q.crowT=q.O-1.8;q.goldT=q.O-2.7;q.fade=0;q.leaves=[];q.crows=[];q.coins=[];q.cf=[];q.rel=[];q.fx=[];q.rings=[];q.k=k;q.last=performance.now();
 try{flcBake(lo?1:Math.min(1.5,Math.max(1,RS||1)))}catch(e){}
 /* the heap of leaves over the chest */
 const cx=W/2,by=GY-30,N=Math.round(150*k)+24;q.heapN=N;for(let i=0;i<N;i++){const a=Math.random()*Math.PI,r=Math.sqrt(Math.random());q.leaves.push({x:cx+Math.cos(a)*r*250,y:by+6-Math.sin(a)*r*260*.9,vx:0,vy:0,r:Math.random()*TAU,vr:0,s:26+Math.random()*20,i:Math.random()*12|0,f:1,st:0,h:1})}
 /* the leaves that will circle the chest */
 const NV=Math.round([10,14,20,28,38,52][T]*k);q.vort=[];for(let i=0;i<NV;i++)q.vort.push({a:Math.random()*TAU,r:200+Math.random()*120,y:-60-Math.random()*260,sp:.7+Math.random()*.6,s:24+Math.random()*16,i:Math.random()*12|0,t0:2.1+(q.O-2.6)*(i/NV)*.75,ph:Math.random()*6});
 /* two crows rest on the scarecrow's arms */
 q.crows.push({x:cx-430-76,y:GY-140-148,p:1,dir:1,s:1.45,ph:0},{x:cx-430+80,y:GY-140-148,p:1,dir:-1,s:1.35,ph:2});
 q.img=null}
const flcWind=(q,t)=>{const g1=sstep(.45,.85,t)*(1-sstep(1.0,2.2,t));const ch=sstep(2.0,q.O,t);return g1*1+ch*.25*(.6+.4*Math.sin(t*2.3))+(q.tier>=3?sstep(q.crowT-.2,q.crowT+.2,t)*(1-sstep(q.crowT+.4,q.crowT+1.6,t))*.6:0)+(t>q.O?.6*Math.exp(-(t-q.O)*2.5):0)};

/* ---------- update ---------- */
function flcUpdate(){const q=S.cr2;if(!q)return;const now=performance.now(),dt=Math.min(.1,Math.max(0,(now-q.last)/1000));q.last=now;q.t+=dt;const t=q.t,O=q.O,T=q.tier,cx=W/2,by=GY-30,k=q.k,tc=flcTC(q);
 q.shk=Math.max(0,q.shk-dt*46);q.fl=Math.max(0,q.fl-dt*(T>=5?.9:1.6));
 if(!q.fired.rv&&q.aud&&!q.skipped&&t>=O-1.2){q.fired.rv=1;try{flcReveal(q.aud,q.aT+O,T,true)}catch(e){}}
 /* the gust: leaves stream across, the heap is blown away as the front passes */
 const front=-300+(t-.45)*2100;
 if(t>.45&&t<1.5&&Math.random()<dt*70*k){q.cf.push({x:-40,y:200+Math.random()*560,vx:900+Math.random()*700,vy:(Math.random()-.5)*160,r:Math.random()*TAU,vr:(Math.random()-.5)*14,s:16+Math.random()*16,i:Math.random()*12|0,l:2.4,g:30})}
 for(const L of q.leaves){if(!L.st&&t>.45&&L.x<front){L.st=1;L.vx=700+Math.random()*700;L.vy=-200-Math.random()*420;L.vr=(Math.random()-.5)*16}
  if(L.st){L.x+=L.vx*dt;L.y+=L.vy*dt;L.vy+=260*dt;L.vx*=1-dt*.25;L.r+=L.vr*dt;L.h-=dt*.45}}
 q.leaves=q.leaves.filter(L=>L.h>0&&L.x<W+80);
 if(t>1.25&&!q.fired.land){q.fired.land=1;if(!q.rm)q.shk=Math.max(q.shk,6)}
 /* the lanterns light, centre-out */
 q.pt.forEach((pt,i)=>{if(t>=pt&&!q.lit[i]){q.lit[i]=1;q.litT[i]=t;const p=FLC_LP[FLC_ORD[i]],x=cx+p[0]*1+32*1.05,y=by+p[1]-118*1.05+40;for(let j=0;j<Math.round(22*k)+4;j++){const a=-Math.PI/2+(Math.random()-.5)*1.6,v=100+Math.random()*260;fxAdd(q,{x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v,l:.5+Math.random()*.6,g:-40,s:2+Math.random()*3,c:FLC_FIRE[T],ty:'dot'})}if(!q.rm)q.shk=Math.max(q.shk,3)}});
 /* crows burst from the corn at Epic and up */
 if(T>=3&&t>=q.crowT&&!q.fired.crow){q.fired.crow=1;for(const c of q.crows){c.p=0;c.vx=c.dir*(160+Math.random()*120);c.vy=-260-Math.random()*120}
  const n=Math.round([0,0,0,9,13,18][T]*(q.rm?.6:1));for(let i=0;i<n;i++){const L=i%2?1:-1;q.crows.push({x:L<0?80+Math.random()*420:W-80-Math.random()*420,y:560+Math.random()*120,vx:(L<0?1:-1)*(120+Math.random()*240),vy:-320-Math.random()*260,p:0,dir:L<0?1:-1,s:1+Math.random()*.7,ph:Math.random()*6,orb:Math.random()<.6})}
  if(!q.rm)q.shk=Math.max(q.shk,8)}
 for(const c of q.crows){if(c.p)continue;c.ph+=dt;if(c.orb&&t<O){const mx=W*.72,my=q.my||300;c.vx+=((mx+Math.cos(c.ph*1.4)*380)-c.x)*dt*1.2;c.vy+=((my-40+Math.sin(c.ph*1.7)*140)-c.y)*dt*1.2;c.vx*=1-dt*.6;c.vy*=1-dt*.6}else{c.vy-=40*dt}
  c.x+=c.vx*dt;c.y+=c.vy*dt;c.dir=c.vx>=0?1:-1}
 q.crows=q.crows.filter(c=>c.p||(c.y>-120&&c.x>-160&&c.x<W+160));
 /* Mythic: the cornucopia pours gold before the lid gives */
 if(T>=5&&t>O-3.4&&t<O+3&&Math.random()<dt*(t<O?16:34)*k){const hx=cx+330,hy=by-250;q.coins.push({x:hx-62,y:hy+18,vx:-80-Math.random()*240,vy:-40+Math.random()*120,r:Math.random()*6,vs:6+Math.random()*8,s:9+Math.random()*6,l:3.4})}
 for(const c of q.coins){c.l-=dt;c.x+=c.vx*dt;c.y+=c.vy*dt;c.vy+=900*dt;c.r+=c.vs*dt;if(c.y>by+20){c.y=by+20;c.vy*=-.35;c.vx*=.6;c.vs*=.6}}q.coins=q.coins.filter(c=>c.l>0);
 if(t>1.9&&t<O&&T>=3&&!q.rm){const ch=sstep(1.9,O,t);q.shk=Math.max(q.shk,ch*(2+T*1.4))}
 /* the lid gives way */
 if(t>=O&&!q.fired.open){q.fired.open=1;q.fl=q.rm?.25:1;if(!q.rm)q.shk=[12,12,16,22,32,46][T];
  const n=Math.round([60,80,110,160,260,420][T]*k);for(let i=0;i<n;i++){const a=-Math.PI/2+(Math.random()-.5)*Math.PI*1.6,v=200+Math.random()*(T>=4?1050:700);fxAdd(q,{x:cx,y:by-170,vx:Math.cos(a)*v,vy:Math.sin(a)*v,l:1+Math.random()*(T>=4?2:1.1),g:420,dr:.5,s:2+Math.random()*(T>=4?6:4),c:Math.random()<.55?tc:Math.random()<.5?'#fff4d0':FLC_FIRE[T],ty:Math.random()<.3?'star':'dot'})}
  for(let i=0;i<Math.round([24,30,40,56,80,120][T]*k);i++){const a=-Math.PI/2+(Math.random()-.5)*2.2,v=300+Math.random()*760;q.cf.push({x:cx+(Math.random()-.5)*90,y:by-180,vx:Math.cos(a)*v,vy:Math.sin(a)*v,r:Math.random()*TAU,vr:(Math.random()-.5)*14,s:16+Math.random()*18,i:Math.random()*12|0,l:3+Math.random()*2,g:520})}
  if(T>=4)for(let i=0;i<Math.round((T>=5?90:40)*k);i++){const a=-Math.PI/2+(Math.random()-.5)*2,v=300+Math.random()*700;q.coins.push({x:cx,y:by-180,vx:Math.cos(a)*v,vy:Math.sin(a)*v,r:Math.random()*6,vs:6+Math.random()*10,s:8+Math.random()*7,l:3+Math.random()*2})}
  const nr=[1,1,2,3,4,6][T];for(let i=0;i<nr;i++)q.rings.push({t0:t+i*.1,x:cx,y:by-150,c:i%2?'#fff4d0':tc,max:[480,480,580,720,940,1300][T]*(1+i*.12),dur:[1,1,1.1,1.3,1.6,2][T]})}
 /* leaves keep falling after a big pull */
 if(t>O&&T>=4&&t<O+(T>=5?6:2.5)&&Math.random()<dt*24*k)q.cf.push({x:Math.random()*W,y:-30,vx:(Math.random()-.5)*80+60,vy:60+Math.random()*80,r:Math.random()*TAU,vr:(Math.random()-.5)*4,s:16+Math.random()*14,i:Math.random()*12|0,l:9,g:20,fall:1});
 for(const p of q.cf){p.l-=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=p.g*dt;if(p.fall){p.vx+=Math.sin(t*2+p.r)*30*dt}else p.vx*=1-dt*.5;p.r+=p.vr*dt;if(p.y>GY+80){p.y=GY+80;p.vy*=-.2;p.vx*=.5;p.vr*=.4;p.g=0}}
 q.cf=q.cf.filter(p=>p.l>0&&p.x<W+120&&p.x>-120);
 fxStep(q,dt);
 if(t>=q.E&&!q.done){q.done=true;crateResult()}}

/* ---------- draw ---------- */
function flcBG(){const q=S.cr2,c=ctx,B=FLC_BK;if(!B){c.fillStyle='#0a0820';c.fillRect(0,0,W,H);return}const t=Math.max(0,q.t),O=q.O,T=q.tier;
 c.drawImage(B.bg,0,0,W,600);
 /* the harvest moon rises behind the hills (and turns gold at Legendary) */
 const mEnd=T>=5?4.6:O-.5,mu=sstep(0,mEnd,t)*.85+sstep(mEnd-1,mEnd+.6,t)*.15,mx=lerp(1220,1150,mu),my=lerp(640,T>=5?250:268,mu),sc=T>=5?.72+.18*sstep(4,6,t):.72;q.my=my;q.mx=mx;
 const gold=T>=4?sstep(q.goldT,q.goldT+1,t):0;
 if(gold<1)flcMoon(c,mx,my,'orange',1,sc);if(gold>0)flcMoon(c,mx,my,'gold',gold,sc*(1+.04*gold*Math.sin(t*3)));
 if(T>=5){const u=sstep(4.6,7.4,t),al=t<O?1:Math.max(0,1-(t-O)/3);flcTurkey(c,mx,my+44*sc,232*sc,u,al,t)}
 c.drawImage(B.low,0,430,W,470)}
function flcDraw(){const q=S.cr2,t=Math.max(0,q.t),c=ctx,cx=W/2,by=GY-30,T=q.tier,O=q.O,tc=flcTC(q),ch=sstep(1.9,O,t),post=Math.max(0,t-O),fire=FLC_FIRE[T],B=FLC_BK,wind=flcWind(q,t),rm=q.rm;
 c.save();if(q.shk>0&&ST.shake&&!rm)c.translate((Math.random()-.5)*q.shk,(Math.random()-.5)*q.shk);
 /* the scarecrow, its crows, and the moonlight on the patch */
 const look=lerp(-.25,1,sstep(1.5,2.1,t)),gl=T>=4?sstep(q.goldT,q.goldT+.8,t)*(t<O+2?1:Math.max(0,1-(t-O-2)/2)):0;
 flcScarecrow(c,cx-430,GY-140,.9,look,t,{gust:wind,glint:gl});
 for(const cr of q.crows)if(cr.p){const hop=T<3&&q.lit.some((l,i)=>l&&t-q.litT[i]<.3)?-Math.abs(Math.sin((t)*20))*4:0;flcCrow(c,cr.x,cr.y+hop,cr.s,0,cr.dir,1)}
 /* lanterns */
 for(let i=0;i<6;i++){const p=FLC_LP[i],oi=FLC_ORD.indexOf(i),lit=q.lit[oi]?Math.min(1,(t-q.litT[oi])*3):0,sw=Math.sin(t*1.7+i)*.06+wind*.12;
  if(lit>0&&!q.lo){c.save();c.globalCompositeOperation='lighter';c.translate(cx+p[0]+30,by+p[1]+4);c.scale(1,.28);flcGlow(c,0,0,130,fire,.45*lit);c.restore()}
  flcLantern(c,cx+p[0],by+p[1],1.05,lit,fire,t,sw);
  if(lit>0&&lit<1){c.save();c.globalCompositeOperation='lighter';flcGlow(c,cx+p[0]+33,by+p[1]-95,160*(1-lit)+30,fire,(1-lit)*.8);c.restore()}}
 /* a warm glow and a pool of light under the chest */
 if(t>1.9){c.save();c.globalCompositeOperation='lighter';flcGlow(c,cx,by-110,Math.min(q.lo?380:560,(240+ch*260)*(post>0?1.3:1)),tc,.32+ch*.3);c.restore()}
 /* the leaves circling the chest: the far half behind it */
 const vort=(front)=>{for(const v of q.vort){if(t<v.t0||t>=O)continue;const ap=Math.min(1,(t-v.t0)*2),a=v.a+(t-v.t0)*v.sp*(1+ch*(rm?1:3.2)),sa=Math.sin(a);if((sa>0)!==front)continue;
  const x=cx+Math.cos(a)*v.r*1.2,y=by+v.y*(1-.25*ch)+sa*v.r*.18+Math.sin(t*2+v.ph)*12;c.globalAlpha=ap*(front?1:.7);flcLeaf(c,x,y,v.s*(front?1.1:.85),a*2+v.ph,v.i,Math.cos(a*3+v.ph))}c.globalAlpha=1};
 vort(false);
 /* the chest */
 const shx=t>1.9&&t<O&&!rm?Math.sin(t*70)*(1+ch*(2+T*2)):0,open=sstep(O,O+.5,t),os=open>0?1+Math.sin(open*Math.PI)*.07:1,lev=T>=4?ch*(T>=5?24:12)*(t<O?1:Math.max(0,1-post*3)):0;
 if(typeof NCX==='object'){NCX.ch=t<O?ch:Math.max(0,1-post*2)}try{flcChest(c,cx+shx,by-lev,2.1*os,open,t)}finally{if(typeof NCX==='object')NCX.ch=0}
 /* the heap of leaves (until the gust takes it) */
 {const ha=1-sstep(.7,1.25,t);if(ha>0){c.save();c.globalAlpha=ha;const hq=c.createLinearGradient(0,by-240,0,by+10);hq.addColorStop(0,'#a8461a');hq.addColorStop(1,'#4a1e0e');c.fillStyle=hq;c.beginPath();c.ellipse(cx,by+8,250*(1-(1-ha)*.3),236*ha+10,0,Math.PI,0);c.fill();c.restore()}}
 for(const L of q.leaves){c.globalAlpha=Math.max(0,Math.min(1,L.h*1.6));flcLeaf(c,L.x,L.y,L.s,L.r,L.i,L.st?Math.cos(L.r*2):1)}c.globalAlpha=1;
 vort(true);
 /* Mythic: the cornucopia over the chest pours gold */
 if(T>=5&&t>O-3.6){const u=sstep(O-3.6,O-2.8,t),al=t<O+2.5?1:Math.max(0,1-(t-O-2.5)/1.5);if(al>0){c.save();c.globalAlpha=al;c.translate(cx+330,by-250+(1-u)*-120);c.scale(-1,1);c.save();c.globalCompositeOperation='lighter';flcGlow(c,-40,0,200,'#ffd45a',.5*u);c.restore();flcHorn(c,0,0,.95*(.6+.4*u),t,u);c.restore()}}
 for(const p of q.coins){c.globalAlpha=Math.min(1,p.l);flcCoin(c,p.x,p.y,p.s,p.r)}c.globalAlpha=1;
 /* the column of light when it opens */
 if(open>0){const dur=T>=5?3.4:T>=4?2.4:1.6,u=post/dur;if(u<1){const e=sstep(0,.15,u)*(1-sstep(.6,1,u)),w=(60+T*28)*e*(1+.06*Math.sin(t*30));c.save();c.globalCompositeOperation='lighter';const gq=c.createLinearGradient(cx-w,0,cx+w,0);gq.addColorStop(0,tc+'00');gq.addColorStop(.35,tc+'99');gq.addColorStop(.5,'#fff8e0ee');gq.addColorStop(.65,tc+'99');gq.addColorStop(1,tc+'00');c.fillStyle=gq;c.fillRect(cx-w,-20,w*2,by-150);c.restore()}}
 /* shockwave rings */
 for(const r of q.rings){const u=(t-r.t0)/r.dur;if(u<=0||u>=1)continue;const e=1-Math.pow(1-u,2.4);c.save();c.globalCompositeOperation='lighter';c.globalAlpha=(1-u)*.8;c.strokeStyle=r.c;c.lineWidth=2+(1-u)*(T>=5?18:11);c.beginPath();c.ellipse(r.x,r.y,e*r.max,e*r.max*.4,0,0,TAU);c.stroke();c.restore()}
 /* sparks */
 c.save();c.globalCompositeOperation='lighter';for(const p of q.fx){c.globalAlpha=Math.max(0,Math.min(1,p.l*1.3));c.fillStyle=p.c;if(p.ty==='star')cStar(c,p.x,p.y,p.s*2.2,p.l*3);else c.fillRect(p.x-p.s/2,p.y-p.s/2,p.s,p.s)}c.restore();
 /* the prize rises out of the light */
 if(t>O+.25)flcPrize(c,q,t,cx,by,tc,fire);
 /* crows in flight */
 for(const cr of q.crows)if(!cr.p)flcCrow(c,cr.x,cr.y,cr.s,Math.sin(t*16+cr.ph),cr.dir,0);
 /* gusting leaves */
 for(const p of q.cf){c.globalAlpha=Math.min(1,p.l*1.2);flcLeaf(c,p.x,p.y,p.s,p.r,p.i,Math.cos(p.r*2.2))}c.globalAlpha=1;
 /* tall corn at the edges sways over everything */
 if(B){const sk=wind*.12+Math.sin(t*1.1+1)*.018;flcSkew(c,B.cornL,0,B.cornFy,340,520,sk);flcSkew(c,B.cornR,1260,B.cornFy,340,520,sk)}
 /* low mist over the patch (not in Performance mode) */
 if(!q.lo){c.save();c.globalCompositeOperation='lighter';for(let i=0;i<4;i++){const xx=((i*470+t*(i%2?-22:26))%(W+600)+W+600)%(W+600)-300;c.save();c.translate(xx,GY+40+(i%2)*26);c.scale(1,.45);flcGlow(c,0,0,260,'#b8a8d8',.12+ch*.04);c.restore()}c.restore()}
 c.restore();
 /* fade in from the menu */
 if(t<.5){c.fillStyle=`rgba(6,4,16,${(1-t/.5).toFixed(3)})`;c.fillRect(0,0,W,H)}
 /* letterbox for the big pulls */
 if(T>=4){const bu=sstep(2.2,O-.6,t)*(1-sstep(O+1.4,O+2.6,t)),bar=72*bu;if(bar>.5){c.fillStyle='#000';c.fillRect(0,0,W,bar);c.fillRect(0,H-bar,W,bar)}}
 if(post>0)flcTitle(c,q,post,cx);
 if(q.fl>0){c.fillStyle=(T>=4?'rgba(255,240,200,':'rgba(255,250,235,')+Math.min(1,q.fl*.85).toFixed(3)+')';c.fillRect(0,0,W,H)}
 if(T>=5&&post>0&&post<4.5&&!rm&&!q.lo){c.save();c.globalCompositeOperation='lighter';c.globalAlpha=(1-post/4.5)*.3;const g=c.createRadialGradient(cx,CCY-40,0,cx,CCY-40,1100);g.addColorStop(0,'#ffd45a');g.addColorStop(.5,'#ff7a3a');g.addColorStop(1,'#c8302a00');c.fillStyle=g;c.fillRect(0,0,W,H);c.restore()}
 /* once the result text is up, darken the lower half so it reads */
 if(q.done){const a=Math.min(1,(q.t-q.E)/.6),g=c.createLinearGradient(0,590,0,780);g.addColorStop(0,'rgba(4,2,12,0)');g.addColorStop(.55,'rgba(4,2,12,'+(.82*a).toFixed(3)+')');g.addColorStop(1,'rgba(4,2,12,'+(.92*a).toFixed(3)+')');c.save();c.fillStyle=g;c.fillRect(0,590,W,H-590);c.restore()}}
/* the prize: gear art, a purse, acorns, an XP star or a companion's glowing shape */
/* 10.4b: the item's kind ('a' armor / 'w' weapon). flcPrep reuses q.k for the lighting scale, so the kind lives in q.kd
   (before this, every armor prize drew nothing and its Equip button called the weapon setter) */
function flcKd(q){const r=q.res||{};if(q.kd==='a'||q.kd==='w')return q.kd;if(r.kind==='a'||r.kind==='w')return r.kind;return AR[q.id]&&!WP[q.id]?'a':'w'}
function flcPrizeImg(q){if(q.img)return q.img;const cv=flcCv(260,260),g=cv.getContext('2d'),r=q.res;
 try{if(r.k==='relic')art(cv,flcKd(q),q.id,0);
  else if(r.k==='coin')flcCoinPile(g,130,190,1.7,0);
  else if(r.k==='xp')flcXpStar(g,130,130,1.6,0);
  else if(r.k==='ac'){flcAcorn(g,96,150,1.9,-.3);flcAcorn(g,164,150,1.9,.3);flcAcorn(g,130,118,2.1,0)}
  else if(r.k==='pet'){let ok=false;if(typeof petDraw==='function'&&typeof PDEF!=='undefined'&&PDEF[r.id]){try{const tmp=flcCv(260,260),tg=tmp.getContext('2d');tg.translate(130,200);tg.scale(1.3,1.3);petDraw(tg,r.id,{t:0,pose:'idle'});
     tg.setTransform(1,0,0,1,0,0);tg.globalCompositeOperation='source-in';tg.fillStyle='#1a0c08';tg.fillRect(0,0,260,260);g.drawImage(tmp,0,0);ok=true}catch(e){}}
   if(!ok){g.save();g.translate(130,130);g.scale(4,4);flcMaplePath(g,24);g.fillStyle='#1a0c08';g.fill();g.restore()}
   g.globalCompositeOperation='source-atop';const rq=g.createRadialGradient(130,90,10,130,130,150);rq.addColorStop(0,'#ffe9a8');rq.addColorStop(.35,'#3a1a0a');rq.addColorStop(1,'#1a0c08');g.fillStyle=rq;g.fillRect(0,0,260,260);g.globalCompositeOperation='source-over'}}catch(e){}
 return q.img=cv}
function flcPrize(c,q,t,cx,by,tc,fire){const T=q.tier,O=q.O,hot=T>=4,u=sstep(O+.3,O+.3+(hot?1.6:1.1),t),y=lerp(by-170,by-398,u)+Math.sin(S.t*2)*(u>.98?6:0),sc=lerp(.4,1.15,u);/* 10.4b: lower and a little smaller so the rarity word clears the wreath */
 if(T>=3&&q.res.k==='relic'){try{art(flcPrizeImg(q),flcKd(q),q.id,S.t)}catch(e){}}
 c.save();c.translate(cx,y);c.scale(sc,sc);c.save();c.globalCompositeOperation='lighter';flcGlow(c,0,0,hot?320:240,tc,.5);c.restore();
 /* a wreath of leaves turns round the prize */
 const nw=T>=4?34:28;c.save();c.rotate(S.t*.2);c.strokeStyle='#ffd27a';c.globalAlpha=.7;c.lineWidth=4;c.beginPath();c.arc(0,0,156,0,TAU);c.stroke();c.globalAlpha=1;for(let i=0;i<nw;i++){const a=i/nw*TAU,rr=i%2?150:164;flcLeaf(c,Math.cos(a)*rr,Math.sin(a)*rr,i%2?40:48,a+Math.PI/2+(i%3-1)*.35,(i*5+T)%12,1)}c.restore();
 c.save();c.rotate(-S.t*.5);c.strokeStyle=tc;c.lineWidth=3;c.globalAlpha=.8;c.setLineDash([12,14]);c.beginPath();c.arc(0,0,184,0,TAU);c.stroke();c.restore();
 c.drawImage(flcPrizeImg(q),-130,-130,260,260);
 if(T>=4){const n=T>=5?8:5;for(let i=0;i<n;i++){const a=S.t*(T>=5?1.1:.8)+i*TAU/n,ox=Math.cos(a)*232,oy=Math.sin(a)*72;if(T>=5&&i%2)flcCoin(c,ox,oy,16,S.t*3+i);else flcPumpkin(c,ox,oy,15,{c:'#ec7a1e'})}}
 c.restore()}
/* the rarity name: letters drop in with a bounce, each landing shakes loose a little leaf */
function flcTitle(c,q,post,cx){const T=q.tier,word=flcRar(T).toUpperCase(),size=[54,60,74,90,114,138][T],start=T>=5?1.0:T>=4?.7:.45,col=flcTC(q);
 c.save();c.font='400 '+size+'px "Pirata One",Georgia,serif';c.textAlign='center';c.textBaseline='middle';const sp=size*.16,ws=[...word].map(ch=>c.measureText(ch).width+sp),tot=ws.reduce((a,b)=>a+b,0);let x=cx-tot/2;const ty=Math.round(22+size*.5);
 for(let i=0;i<word.length;i++){const u=Math.max(0,Math.min(1,(post-start-i*.08)/.42));if(u>0){const e=u<.6?Math.pow(u/.6,2):1+Math.sin((u-.6)/.4*Math.PI)*-.08*(1-u),yy=ty-(1-Math.min(1,u/.6))*140;
   const fc=T>=5?hsx(20+Math.sin(S.t*2+i*.6)*22,100,58+Math.sin(S.t*3+i)*8):col;c.save();c.translate(x+ws[i]/2,yy);c.scale(1,u<.6?1:e);c.lineJoin='round';c.lineWidth=T>=4?10:6;c.strokeStyle=FLO;c.strokeText(word[i],0,0);c.fillStyle=fc;c.fillText(word[i],0,0);
   c.fillStyle='#ffffff55';c.fillText(word[i],-1,-2);c.fillStyle=fc;c.globalAlpha=.85;c.fillText(word[i],0,0);c.restore();
   if(u>=.6&&u<1&&!q.rm){const k=(u-.6)/.4;c.globalAlpha=1-k;flcLeaf(c,x+ws[i]/2+(i%2?1:-1)*k*30,ty+size*.42+k*40,16,k*4+i,(i*3+T)%12,Math.cos(k*8));c.globalAlpha=1}}x+=ws[i]}
 c.restore()}

/* ---------- start, skip, result, end ---------- */
function flcStart(){if(S.cr2&&S.mode==='crate')return;const r0=crateRoll('f');if(!r0)return;const{kind,id,it,dup}=r0,tier=r0.fl.tier;
 S.mode='crate';S.cr2={k:kind,kd:kind,ck:'f',id,it,dup,pf:0,t:-.06,fired:{},done:false,tier,O:FLCT.O[tier],E:FLCT.O[tier]+FLCT.D[tier],fx:[],rings:[],fl:0,shk:0,bolts:[],acc:0,acc2:0,acc3:0,last:performance.now(),res:r0.fl,stars:[]};
 flcPrep(S.cr2);show('<button class="sm" id="sk">Skip</button>','clear');$('sk').onclick=crateSkip;try{flcAudio(S.cr2)}catch(e){}
 try{dkRefreshBadges()}catch(e){}}
function flcSkip(){const q=S.cr2;if(!q||q.done)return;
 if(q.t<q.O-.05){crateFade(q,.05);if(axOn()){const o=ac.createGain();o.gain.value=1;o.connect(sg);q.aud=o;flcReveal(o,ac.currentTime+.05,q.tier,false)}const tm=q.O-.05;
  q.pt.forEach((pt,i)=>{if(!q.lit[i]){q.lit[i]=1;q.litT[i]=tm-.4}});q.leaves=[];q.fired.land=1;if(q.tier>=3&&!q.fired.crow){q.fired.crow=1;for(const c of q.crows)c.p=0}q.t=tm;q.skipped=1}
 else if(q.t<q.E)q.t=q.E}
function flcBack(){const f=FLC.ret;FLC.ret=null;if(typeof f==='function')f();else crateHub()}
function flcResult(){const q=S.cr2,it=q.it,r=q.res,T=q.tier;if(T<4&&axOn()){const o=ac.createGain();o.gain.value=1;o.connect(sg);altFinale(o,ac.currentTime+.02,0)}
 if(r.k==='pet'&&flcPend().some(x=>x.k==='pet')){const ret=FLC.ret,t0=SHOWT;crateEnd();flcPendRun();FLC.ret=ret;if(SHOWT!==t0)return;/* the companion's own reveal took over */
  if(S.mode==='crate'){S.mode='title';S.view='menu'}const more2=(P.fcr|0)>0;
  show(`<div class="flcres flcpet" style="--c:${flcTC(q)}"><canvas width="260" height="260" id="flcpetc" aria-hidden="true"></canvas><h2 class="${T>=4?'flctxt':''}" style="${T>=4?'':`color:${it.col}`}">${it.r} companion: ${esc(it.n)}</h2><p>${esc(it.n)} joins your companions. Meet them in the Companion Hall.</p>
  <div class="row"><button id="flcpg">Companion Hall</button>${more2?'<button class="sm gd" id="m">Open another</button>':''}<button class="sm" id="b">Back</button></div></div>`,'m');
  try{const c=$('flcpetc'),g=c.getContext('2d');if(typeof petDraw==='function'&&typeof PDEF!=='undefined'&&PDEF[r.id]){g.translate(130,220);g.scale(1.25,1.25);petDraw(g,r.id,{t:0,pose:'idle'})}else g.drawImage(flcPrizeImg(q),0,0)}catch(e){}
  $('flcpg').onclick=()=>{try{PTX.back=title;petHall('Pets')}catch(e){title()}};if(more2)$('m').onclick=()=>flcStart();$('b').onclick=()=>flcBack();S.back=flcBack;return}
 const more=(P.fcr|0)>0,cls=T>=4?'flctxt':'',n=(typeof flcCount==='function')?flcCount():0;let line='';
 if(r.k==='relic')line=q.dup?`Duplicate, converted into 40 XP and ${GOLDDUP[it.r]} gold.`:`<b style="color:var(--gold)">New!</b> Added to your armory. Harvest relics ${n} / 12.`;
 else if(r.k==='coin')line=`<b style="color:var(--gold)">+${r.n.toLocaleString()} gold</b> added to your purse.`;
 else if(r.k==='xp')line=`<b style="color:#8ad8ff">+${r.n} XP</b>.`;
 else if(r.k==='ac')line=`<b style="color:#ffb46a">+${r.n} acorns</b> for the Harvest Market.`;
 else if(r.k==='pet')line=`${esc(it.n)} joins your companions.`;
 show(`<div class="flcres" style="--c:${flcTC(q)}"><div style="margin-top:auto"></div><h2 class="${cls}" style="${cls?'':`color:${it.col}`}">${it.r}: ${esc(it.n)}</h2><p>${esc(it.d)}${r.k==='relic'&&flcKd(q)!=='a'&&it.p&&it.p!=='knight'&&PATHS[it.p]?` &middot; ${PATHS[it.p].n} path`:''}</p><p>${line}</p>
 <div class="row">${r.k==='relic'?'<button id="a">Equip</button>':''}${more?`<button class="sm${r.k==='relic'?'':' gd'}" id="m">Open another</button>`:''}${(P.fcr|0)>=10?'<button class="sm gd" id="m10">Open 10</button>':''}<button class="sm" id="b">Back</button></div></div>`,'clear');
 try{achCheck()}catch(e){}flcPendRun();
 if($('a'))$('a').onclick=()=>{if(flcKd(q)==='a'){P.armor=q.id;save()}else setWeapon(q.id);crateEnd();FLC.ret=null;title()};
 if(more)$('m').onclick=()=>{crateEnd();flcStart()};if($('m10'))$('m10').onclick=()=>{crateEnd();flcBatch(10)};$('b').onclick=()=>{crateEnd();flcBack()}}
/* open several at once: roll them all, then show every pull */
function flcIcon(r,res){const cv=flcCv(200,200),g=cv.getContext('2d');try{
  if(res.k==='relic')art(cv,r.kind==='a'?'a':'w',r.id,0);else if(res.k==='coin')flcCoinPile(g,100,150,1.25,0);else if(res.k==='xp')flcXpStar(g,100,100,1.2,0);
  else if(res.k==='ac'){flcAcorn(g,74,116,1.45,-.3);flcAcorn(g,126,116,1.45,.3);flcAcorn(g,100,92,1.6,0)}
  else if(res.k==='pet'){const q={res,img:null,k:'p'};g.drawImage(flcPrizeImg(q),0,0,200,200)}
  return cv.toDataURL()}catch(e){return''}}
function flcBatch(n){n=Math.min(n,P.fcr|0);if(n<1)return;const R=[];let xp=0,gd=0;for(let i=0;i<n;i++){const r=crateRoll('f');if(!r)break;if(r.dup){xp+=40;gd+=GOLDDUP[r.it.r]}R.push(r)}
 R.forEach(r=>{r.url=flcIcon(r,r.fl);r.tier=r.fl.tier});R.sort((a,b)=>b.tier-a.tier||(a.dup-b.dup));
 const rel=R.filter(r=>r.fl.k==='relic'),nw=rel.filter(r=>!r.dup).length,best=R[0],left=P.fcr|0,coins=R.filter(r=>r.fl.k==='coin').reduce((s,r)=>s+r.fl.n,0),acs=R.filter(r=>r.fl.k==='ac').reduce((s,r)=>s+r.fl.n,0),pets=R.filter(r=>r.fl.k==='pet');
 S.mode='title';S.view='menu';
 show(`<div class="flcbat"><h2>${R.length} Harvest Chest${R.length>1?'s':''} opened</h2><div class="cbs"><span><b>${nw}</b><small>new relics</small></span><span><b>${rel.length-nw}</b><small>duplicates</small></span>${gd+coins?`<span><b>+${(gd+coins).toLocaleString()}</b><small>gold</small></span>`:''}${xp+R.filter(r=>r.fl.k==='xp').reduce((s,r)=>s+r.fl.n,0)?`<span><b>+${xp+R.filter(r=>r.fl.k==='xp').reduce((s,r)=>s+r.fl.n,0)}</b><small>XP</small></span>`:''}${acs?`<span><b>+${acs}</b><small>acorns</small></span>`:''}<span style="--c:${best.it.col}"><b class="cbb">${best.it.r}</b><small>best pull</small></span></div>
 <div class="cbg">${R.map((r,i)=>`<div class="cbk${r.tier>=4?' hi':''}" style="--c:${r.it.col};--n:${i}"><img src="${r.url}" alt=""><b>${esc(r.it.n)}</b><em>${r.it.r}</em><i class="${r.fl.k==='relic'?(r.dup?'dp':'nw'):'nw'}">${r.fl.k==='relic'?(r.dup?'Duplicate':'NEW'):r.fl.k==='pet'?'COMPANION':'BONUS'}</i></div>`).join('')}</div>
 <div class="row">${left>=10?'<button class="gd" id="m10">Open 10 more</button>':''}${left>0&&left<10?'<button class="sm" id="m1">Open another</button>':''}<button class="sm" id="b">Back</button></div></div>`,'m top');
 save();try{achCheck()}catch(e){}S.back=flcBack;$('b').onclick=flcBack;if($('m10'))$('m10').onclick=()=>flcBatch(10);if($('m1'))$('m1').onclick=()=>flcStart();
 try{jingle(best.tier>=4?'win':best.tier>=2?'boon':'wave');if(best.tier>=4)for(let k=0;k<3;k++)setTimeout(()=>beep(880+k*220,.12,'triangle',.5),k*140)}catch(e){}
 try{dkRefreshBadges()}catch(e){}
 if(pets.length)setTimeout(()=>{flcPendRun()},900);else flcPendRun()}

/* ---------- hooks: only key 'f' takes this path ---------- */
/* everyday crates, the Eclipse and the Celestial Chest never hand out harvest relics: they are hidden from those rolls */
function flcHideFL(fn){const L=[];try{for(const T of[AR,WP])for(const id in T){const o=T[id];if(o&&o.fl&&!o.hw){o.hw=1;L.push(o)}}}catch(e){}try{return fn()}finally{for(const o of L)delete o.hw}}
{const r0=crateRoll;crateRoll=function(k){if(k!=='f')return flcHideFL(()=>r0.apply(this,arguments));const self=this,go=()=>typeof ecLvPay==='function'?ecLvPay(flcRollF,self,[]):flcRollF();return typeof ukSrc==='function'?ukSrc('harvest chest',go):go()}}
{const s0=crateStart;crateStart=function(k){if(k==='f')return flcStart();return s0.apply(this,arguments)}}
{const b0=crateBatch;crateBatch=function(k,n){if(k==='f')return flcBatch(n);return b0.apply(this,arguments)}}
{const ca=crateAudio;crateAudio=function(q){if(q&&q.fc)return;return ca(q)}}
{const cu=crateUpdate;crateUpdate=function(dt){if(S.cr2&&S.cr2.fc)return flcUpdate();return cu(dt)}}
{const dc=drawCrateScene;drawCrateScene=function(){if(S.cr2&&S.cr2.fc)return flcDraw();return dc()}}
{const sk=crateSkip;crateSkip=function(){const q=S.cr2;if(q&&q.fc)return flcSkip();return sk()}}
{const cr=crateResult;crateResult=function(){const q=S.cr2;if(q&&q.fc)return flcResult();return cr.apply(this,arguments)}}
{const ce=crateEnd;crateEnd=function(){const f=S.cr2&&S.cr2.fc;ce();if(f)try{FLC_BK=null;if(mg)mg.gain.setTargetAtTime(ST.mute?0:ST.mvol*.6,ac.currentTime,.4)}catch(e){}}}
{const b0=drawBG;drawBG=function(){if(S.mode==='crate'&&S.cr2&&S.cr2.fc)return flcBG();return b0.apply(this,arguments)}}
/* the shop's odds and contents for the other crates leave the harvest relics out too */
if(typeof shOdds==='function'){const o0=shOdds;shOdds=function(k){return flcHideFL(()=>o0.apply(this,arguments))}}
if(typeof shItems==='function'){const i0=shItems;shItems=function(k){return flcHideFL(()=>i0.apply(this,arguments))}}
