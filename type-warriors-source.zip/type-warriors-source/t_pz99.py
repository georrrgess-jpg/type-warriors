# python3 t_pz99.py [game.html] : The Crooked Cue 9.9g (97b): potting the 8 last wins against every regular (Barnacle's old "bank the 8"
# house rule spotted the 8 and gave ball in hand, which looked like a wrong-ball foul), the guide hides on an opponent's ball, gold rings.
import asyncio,os,re,sys,json
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
src=open(os.path.join(HERE,'t_pool.py')).read();PRE=re.search(r'PRE="(.*?)"\n',src).group(1);HELP=re.search(r'HELP=r"""(.*?)"""',src,re.S).group(1)
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:500]),flush=True)
    if not ok:FAIL.append(name)
async def pot8(b,opp,er):
    pg=await b.new_page(viewport={'width':1600,'height':900});pg.on('pageerror',lambda e:er.append(str(e)[:200]));await pg.goto(H);await pg.wait_for_timeout(1200);E=pg.evaluate
    await E(PRE);await E(HELP)
    await E("([o])=>{casinoOpen();gameOpen('pz');pzStart({opp:o,stake:200,seed:7})}",[opp]);await pg.wait_for_timeout(400);await E("()=>SC.skip()");await E("()=>SC.ready()")
    await E("()=>SC.on8()");await pg.wait_for_timeout(300)
    await E("""()=>{const B=PZ.B;B[0].x=440;B[0].y=300;B[8].x=560;B[8].y=190;B[15].x=200;B[15].y=380;const k=2;const e=B[8],px=PZ_AIM[k][0],py=PZ_AIM[k][1],ux=px-e.x,uy=py-e.y,l=Math.hypot(ux,uy),gx=e.x-ux/l*24,gy=e.y-uy/l*24;
       PZ.aim.ang=PZ.cueAng=Math.atan2(gy-B[0].y,gx-B[0].x);PZ.aim.pow=.5;PZ.aim.a=0;PZ.aim.b=0;PZ.cueAv=0;PZ.speed=4;pzFireHuman()}""")
    r=None
    for i in range(80):
        await pg.wait_for_timeout(200)
        r=await E("()=>PZ.rep&&PZ.ph!=='shot'&&PZ.ph!=='roll'?{ph:PZ.ph,foul:PZ.rep.foul,spot8:!!PZ.rep.spot8,over:PZ.st.over}:null")
        if r and (r['over'] or r['foul'] or r['ph'] in ('gap','aim','ai')):break
    await pg.close();return r
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();er=[]
        pg=await b.new_page(viewport={'width':1600,'height':900});E=pg.evaluate;pg.on('pageerror',lambda e:er.append(str(e)[:200]))
        await pg.goto(H);await pg.wait_for_timeout(1200);await E(PRE);await E(HELP)
        r=await E("()=>[Object.keys(PZ_REG),Object.keys(PZ_REG).filter(k=>PZ_REG[k].house&&PZ_REG[k].house.bank8),PZ_REG.barnacle.houseTxt,PZ97_HOUSE.barnacle]")
        chk('no regular keeps the "bank the 8" house rule (Barnacle plays plain 8-ball, and his texts say so)',r[1]==[] and 'No house rule' in r[2] and 'None' in r[3],r[1:])
        opps=r[0]
        await E("()=>{casinoOpen();gameOpen('pz');pzStart({opp:'gloop',stake:200,seed:7})}");await pg.wait_for_timeout(400);await E("()=>SC.skip()");await E("()=>SC.ready()")
        await E("()=>{const st=PZ.st;const W=PZ_PHY.W,H=PZ_PHY.H;let k=0;for(const b of PZ.B){if(!b.id)continue;const i=k++;b.x=W*(.42+.17*(i%4))+((i>>2)%2)*30;b.y=H*(.16+.17*Math.floor(i/4));b.vx=b.vy=0}PZ.B[0].x=W*.2;PZ.B[0].y=H*.5;st.brk=false;st.open=false;st.grp=['s','t'];pzHudAll();const B=PZ.B;const s=B.find(b=>b.id===12&&b.on)||B.find(b=>b.id>8&&b.on);PZ.cueAng=PZ.aim.ang=Math.atan2(s.y-B[0].y,s.x-B[0].x)}")
        await pg.wait_for_timeout(500);r=await E("()=>[!!(PZ.guideHit&&PZ.guideHit.blocked),PZ.guideHit&&PZ.guideHit.hit&&PZ.guideHit.hit.id]")
        chk('aiming straight at an opponent\'s ball: no guide line (marked blocked, red ring)',r[0] and r[1]>8,r)
        await pg.screenshot(path=os.path.join(HERE,'shots','pz99_wrong.png'),clip={'x':0,'y':100,'width':1600,'height':700})
        await E("()=>{const B=PZ.B;const s=B.find(b=>b.id>=1&&b.id<=7&&b.on);PZ.cueAng=PZ.aim.ang=Math.atan2(s.y-B[0].y,s.x-B[0].x)}")
        await pg.wait_for_timeout(500);r=await E("()=>[!!(PZ.guideHit&&PZ.guideHit.blocked),PZ.guideHit&&PZ.guideHit.hit&&PZ.guideHit.hit.id]")
        chk('aiming at one of your own balls: the normal guide',not r[0] and 1<=(r[1] or 0)<=7,r)
        r=await E("()=>{const st=PZ.st;st.open=true;st.grp=[null,null];PZ.cueAng+=.0001;return new Promise(res=>setTimeout(()=>res(!(PZ.guideHit&&PZ.guideHit.blocked)),400))}")
        chk('open table (no groups yet): the guide shows on any ball',r,r)
        await pg.close()
        res=[]
        for o in opps:
            x=None
            for k in range(3):
                try:x=await pot8(b,o,er)
                except Exception as e:x='ERR '+str(e)[:120]
                if not(isinstance(x,dict) and not x['over'] and not x['foul']):break  # a clean miss (heavy load) is retried
            res.append(x)
        bad=[(o,x) for o,x in zip(opps,res) if not(isinstance(x,dict) and x['over'] and x['over'].get('winner')==0 and not x['foul'] and not x['spot8'])]
        chk(f'potting the 8 last (clean shot) wins the frame against all {len(opps)} regulars, no foul screen and no re-spot',not bad,bad)
        chk('no page errors',not er,er)
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
