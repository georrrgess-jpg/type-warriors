# python3 t_w2mobs.py [game.html] : Runestone Tower Defense 10.0 (98d) - the World 2 (Tidebreak Isles) monster art: the registries
# (RPMD / RPMB / RPMK / RPMOB / RPW_MOBS, the shell_in and puffer_big pose sprites, variant names), every id x variant bakes 8 sane,
# animated frames that fit their frame box, the variants carry real accessories (different silhouettes, not just a recolour), icons,
# the sea-debris deaths, World 1 and World 3 drawing untouched, battles on coral, wreck and abyss with every monster spawned, and the
# frame cost of ~60 monsters on the road.
import asyncio,os,sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:600]),flush=True)
    if not ok:FAIL.append(name)
IDS=['crab','shell','puffer','jelly','brute','siren','squid','leviathan','shell_in','puffer_big']
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E("()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const r=RPP();r.new99j=1;r.dragon=1;r.stars=Object.assign(r.stars||{},{moss:3,frost:3,ember:3});for(const k in r.tut)r.tut[k]=1}")
        # ---------------------------------------------------------------- registries
        r=await E("""(ids)=>ids.map(id=>[id,!!RPMD[id],!!RPMB[id]&&RPMB[id].length===5,RPMK[id]>.5&&RPMK[id]<1.2,!!RPMOB[id],RPW_MOBS[id]])""",IDS)
        chk('all ten sprites are registered (RPMD, RPMB [x0,y0,x1,y1,shadow], RPMK, RPMOB) and belong to World 2',all(x[1] and x[2] and x[3] and x[4] and x[5]==2 for x in r),r)
        r=await E("""()=>{const a=RPMOB.shell_in,b=RPMOB.shell,c=RPMOB.puffer_big,d=RPMOB.puffer;return [a.n===b.n&&a.air===b.air&&a.h===b.h&&a.w===b.w,c.n===d.n&&c.air===d.air&&c.h>d.h,RPMOB.jelly.air&&RPMOB.jelly.lift===40,RPMOB.leviathan.boss,
          ['coral','wreck','abyss'].every(v=>RPMOBV[v].shell_in&&RPMOBV[v].shell_in.n===RPMOBV[v].shell.n&&RPMOBV[v].puffer_big.n===RPMOBV[v].puffer.n),rpMobName('leviathan','wreck'),rpMobName('puffer_big','abyss')]}""")
        chk('the pose sprites copy their parent (puffer_big is taller) and share its variant names; the jelly flies, the leviathan is the boss',all(r[:5]) and r[5]=='Dreadnought Leviathan' and r[6]=='Lure Puffer',r)
        r=await E("""(ids)=>{rpStart('moss');const a=Object.keys(RPVC).filter(k=>ids.includes(k.split('|')[1]));rpLeave();rpStart('coral');const b=ids.filter(id=>RPVC['coral|'+id]);rpLeave();return [a,b.length]}""",IDS)
        chk('a World 1 battle start does not bake the World 2 sheets; a World 2 battle start prebakes all ten in its variant',r[0]==[] and r[1]==10,r)
        # ---------------------------------------------------------------- bakes
        r=await E("""(ids)=>{const out=[];for(const id of ids)for(const v of ['coral','wreck','abyss']){const C=rpvSheet(id,v);if(!C){out.push([id,v,'none']);continue}
          /* read a copy: reading the sheet itself would move it off the GPU and skew the frame cost below */const cp=document.createElement('canvas');cp.width=C.cv.width;cp.height=C.cv.height;const g=cp.getContext('2d');g.drawImage(C.cv,0,0);const fr=[];for(let i=0;i<8;i++){const d=g.getImageData(i*C.fw,0,C.fw,C.fh).data;let n=0,h=0;for(let j=3;j<d.length;j+=16){if(d[j]>40){n++;h=(h*31+d[j-3]+d[j-2]*7+d[j-1]*13)%1000003}}fr.push([n,h])}
          out.push([id,v,C.cv.width===C.fw*8,C.fw,C.fh,Math.min(...fr.map(f=>f[0])),new Set(fr.map(f=>f[1])).size])}return out}""",IDS)
        bad=[x for x in r if not(x[2] is True and 20<x[3]<700 and 20<x[4]<400 and x[5]>150 and x[6]>=4)]
        chk('every id x variant bakes an 8-frame 2x sheet of a sane size, each frame drawn, the frames animated',not bad and len(r)==30,bad or r[:3])
        r=await E("""(ids)=>{const out=[];for(const id of ids){const B=RPMB[id];let T=[1e9,1e9,-1e9,-1e9];for(const v of ['coral','wreck','abyss'])for(let f=0;f<8;f++){const P=50,w=Math.ceil(B[2]-B[0])+P*2,h=Math.ceil(B[3]-B[1])+P*2,cv=document.createElement('canvas');cv.width=w;cv.height=h;const g=cv.getContext('2d');g.translate(P-B[0],P-B[1]);rpvDraw(g,id,f/8,v);
           const d=g.getImageData(0,0,w,h).data;for(let y=0;y<h;y++)for(let x=0;x<w;x++)if(d[(y*w+x)*4+3]>24){const X=x-P+B[0],Y=y-P+B[1];if(X<T[0])T[0]=X;if(X>T[2])T[2]=X;if(Y<T[1])T[1]=Y;if(Y>T[3])T[3]=Y}}
          out.push([id,B.slice(0,4),T,RPMOB[id].h])}return out}""",IDS)
        bad=[x for x in r if x[2][0]<x[1][0]-1 or x[2][1]<x[1][1]-1 or x[2][2]>x[1][2]+1 or x[2][3]>x[1][3]+1]
        chk('no sprite is clipped: every frame of every variant (abyss halo included) fits its RPMB box',not bad,bad)
        bad=[x for x in r if not(.8<=-x[2][1]/x[3]<=(1.6 if x[0]=='jelly' else 1.5))]
        chk('drawn heights match RPMOB.h (0.8-1.5x; accessories and song notes may poke above, the flying jelly trails its tentacles: 1.6x)',not bad,[(x[0],-x[2][1],x[3]) for x in r])
        # ---------------------------------------------------------------- variants are dressed differently, not just recoloured
        r=await E("""(ids)=>ids.map(id=>{const M={};for(const v of ['coral','wreck','abyss']){const B=RPMB[id],w=Math.ceil(B[2]-B[0]),h=Math.ceil(B[3]-B[1]),cv=document.createElement('canvas');cv.width=w;cv.height=h;const g=cv.getContext('2d');g.translate(-B[0],-B[1]);RPW2M.noHalo=1;try{rpvDraw(g,id,.12,v)}finally{RPW2M.noHalo=0}
           const d=g.getImageData(0,0,w,h).data,m=new Uint8Array(w*h);for(let i=0;i<w*h;i++)m[i]=d[i*4+3]>100?1:0;M[v]=m}
          const io=(a,b)=>{let i=0,u=0;for(let k=0;k<a.length;k++){if(a[k]&b[k])i++;if(a[k]|b[k])u++}return +(i/u).toFixed(3)};return [id,io(M.coral,M.wreck),io(M.coral,M.abyss),io(M.wreck,M.abyss)]})""",IDS)
        bad=[x for x in r if max(x[1:])>.97]
        chk('each variant changes the silhouette with its own accessories (mask overlap between variants under 97%)',not bad,r)
        # ---------------------------------------------------------------- icons
        r=await E("""(ids)=>{const out=[];for(const id of ids){const H=[];for(const v of ['coral','wreck','abyss']){const c=rpMobIcon(id,64,v),d=c.getContext('2d').getImageData(0,0,64,64).data;let n=0,h=0;for(let j=3;j<d.length;j+=4)if(d[j]>40){n++;h=(h*31+d[j-3]+d[j-2]*3)%1000003}H.push([c.width,n,h])}
          out.push([id,H.every(x=>x[0]===64&&x[1]>500),new Set(H.map(x=>x[2])).size])}return out}""",IDS)
        chk('icons: a 64 px portrait per id and variant, filled and different per variant',all(x[1] and x[2]==3 for x in r),r)
        # ---------------------------------------------------------------- deaths
        r=await E("""(ids)=>{const cv=document.createElement('canvas');cv.width=cv.height=260;const c=cv.getContext('2d'),out=[];let calls=0;const f0=rpw2mDeath;rpw2mDeath=function(){calls++;return f0.apply(this,arguments)};
          try{for(const id of ids)for(const v of ['coral','wreck','abyss']){const n=[];for(const k of [0,.08,.2,.4,.65,.9,1]){c.clearRect(0,0,260,260);const s=id==='leviathan'?.5:1;rpMobDeath(c,id,130,200,k,{v,s,seed:3});const d=c.getImageData(0,0,260,260).data;let m=0;for(let j=3;j<d.length;j+=8)if(d[j]>20)m++;n.push(m)}out.push([id,v,n])}}finally{rpw2mDeath=f0}
          return [calls,out]}""",IDS)
        bad=[x for x in r[1] if not(all(m>0 for m in x[2][:6]) and x[2][6]==0)]
        chk('deaths: every id and variant pops, splashes and scatters sea debris through the whole animation (nothing left at k=1), via the World 2 death',r[0]==len(IDS)*3*7 and not bad,bad or r[0])
        r=await E("""()=>{const c=document.createElement('canvas').getContext('2d');let n=0;const f0=rpw2mDeath;rpw2mDeath=function(){n++;return f0.apply(this,arguments)};try{rpMobDeath(c,'golem',50,50,.3,{v:'frost'});rpMobDeath(c,'scamp',50,50,.3,{})}finally{rpw2mDeath=f0}return n}""")
        chk('World 1 deaths still use their own effect',r==0,r)
        # ---------------------------------------------------------------- World 1 and World 3 untouched
        r=await E("""()=>{const g=document.createElement('canvas').getContext('2d');let n=0;const f0=rpw2mHalo;rpw2mHalo=function(){n++;return f0.apply(this,arguments)};const D={};for(const id in RPMD)D[id]=RPMD[id];let hit=[];
          for(const id of ['crab','scamp']){const o=RPMD[id];RPMD[id]=function(gg,ph,oo){hit.push([id,oo&&oo.v]);return o.apply(this,arguments)}}
          try{rpvDraw(g,'scamp',.2,'frost');rpvDraw(g,'golem',.2,'wonder');rpvDraw(g,'cog',.2,'meadow');rpvDraw(g,'crab',.2,'moss');rpvDraw(g,'crab',.2,'abyss')}finally{for(const id in D)RPMD[id]=D[id];rpw2mHalo=f0}return [hit,n]}""")
        chk('rpvDraw: World 1 ids keep the 95b2 recolour path, World 3 ids fall through, World 2 ids draw their variant (an unknown variant falls back to coral)',
            r[0]==[['scamp',None],['crab','coral'],['crab','abyss']],r)
        # ---------------------------------------------------------------- battles
        for mp in ['coral','wreck','abyss']:
            r=await E("""(mp)=>{try{rpLeave()}catch(e){}rpStart(mp);const R=RPX;R.tut=null;R.hold=false;R.pause=true;R.foes.length=0;const ids=['crab','shell','puffer','jelly','brute','siren','squid'];const np=R.G.paths.length;let i=0;
              for(let k=0;k<3;k++)for(const id of ids){rpSpawn(id,i%np);i++}const L=R.G.paths.map(p=>p.len);R.foes.forEach((e,j)=>{e.s=40+((j*.618)%1)*(L[e.pi]-120);if(e.id==='shell'&&j%2)e.id='shell_in';if(e.id==='puffer'&&j%2)e.id='puffer_big'});
              const b=rpSpawn('leviathan',0);b.s=L[0]*.4;for(let t=0;t<5;t++)rpDraw();const seen=new Set(R.foes.map(e=>e.id));
              /* a few kills: the death effect plays in the real draw */R.foes.slice(0,4).forEach(e=>{e.dead=1;e.dk=.3});rpDraw();return [R.map.pal,[...seen].sort(),R.foes.length]}""",mp)
            chk(f'battle on {mp}: every monster (and both pose sprites) spawns and draws in its variant, deaths included, no errors',r[0]==mp and len(r[1])==10 and not er,[r,er[:2]])
        # ---------------------------------------------------------------- frame cost
        # Headless Chromium rasterises canvases in software, so absolute blit times say little; the cast is measured against World 1's
        # in the same harness (60 monsters each, the boss included, a few flashing and chilled), interleaved and taken as medians.
        await E("""()=>{window.w2Scene=(mp,ids,boss)=>{try{rpLeave()}catch(e){}rpStart(mp);const R=RPX;R.tut=null;R.pause=true;R.foes.length=0;const np=R.G.paths.length,L=R.G.paths.map(p=>p.len);
           for(let i=0;i<59;i++){const id=ids[i%ids.length],e=rpSpawn(id==='shell_in'?'shell':id==='puffer_big'?'puffer':id,i%np);e.id=id;e.s=30+((i*.618)%1)*(L[e.pi]-80);e.fl=i%7?0:.05;e.slowT=i%5?0:1}
           const b=rpSpawn(boss,0);b.s=L[0]*.5;return R};
          window.w2Time=(R,c,n)=>{const draw=()=>{for(const e of R.foes){e.ph=(e.ph+.013)%1;rpFoeDraw(c,R,e,rpPos(R,e))}};for(let i=0;i<10;i++)draw();const t0=performance.now();for(let i=0;i<n;i++)draw();return (performance.now()-t0)/n};return 1}""")
        r=await E("""()=>{const cv=document.createElement('canvas');cv.width=1600;cv.height=900;const c=cv.getContext('2d'),A=[],B=[];
          for(let k=0;k<3;k++){let R=w2Scene('ember',['scamp','bulwark','golem','gloom','ooze','shaman'],'behemoth');A.push(w2Time(R,c,40));
           R=w2Scene('wreck',['crab','shell','puffer','jelly','brute','siren','squid','shell_in','puffer_big'],'leviathan');B.push(w2Time(R,c,40))}
          const med=x=>x.sort((a,b)=>a-b)[1];return [RPX.foes.length,+med(A).toFixed(2),+med(B).toFixed(2)]}""")
        chk('frame cost: 60 World 2 monsters (the boss, flashes and chills included) blit no slower than 60 World 1 monsters (+30%), same harness',r[0]==60 and r[2]<=r[1]*1.3+.3,r)
        print('   frame cost (headless, software canvas): World 1',r[1],'ms, World 2',r[2],'ms for',r[0],'monsters')
        chk('no page errors',not er,er[:3])
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');sys.exit(1 if FAIL else 0)
asyncio.run(main())
