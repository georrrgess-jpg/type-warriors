import asyncio,os,sys
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append('PE '+str(e)[:300]))
        await pg.goto('file://'+os.path.abspath('out.html'));await pg.wait_for_timeout(1200);E=pg.evaluate
        await E("()=>{RS_ASK=false;P.pets={};P.pet='';P.petSt=0;P.petPend=null;P.trail={n:0,c:0};petNorm();title();PTX.back=title;petHall('Trail')}")
        await pg.wait_for_timeout(1500);await E("()=>{P.petSt=1;P.trail.n=1;title()}");await pg.wait_for_timeout(800)
        await pg.click('#dk_pt');await pg.wait_for_timeout(1200);await pg.screenshot(path='shots/s6_a.png')
        print('after Pets:',await E("()=>[PTX.tab,!!document.querySelector('.ptstart'),!!document.querySelector('.pat')]"))
        b2=await E("()=>!!document.getElementById('ptstb')");print('starter btn',b2)
        if b2:
            await pg.click('#ptstb')
            hs=[]
            for k in range(12):
                await pg.wait_for_timeout(150)
                hs.append(await E("()=>{const c=document.querySelector('canvas[data-sv]');if(!c)return 'none';const d=c.toDataURL();let h=0;for(let i=0;i<d.length;i+=7)h=(h*31+d.charCodeAt(i))|0;return h}"))
            print(hs);await pg.screenshot(path='shots/s6_b.png')
            print(await E("()=>[document.querySelectorAll('#pth').length,LIVE.length,LIVE.map(l=>l.cv.isConnected)]"))
        print(er[:8]);await b.close()
asyncio.run(main())
