/* ===== LANTERN CARAVAN: styles ===== (transform and opacity animation only; no backdrop-filter, no animated shadows) */
{const st=document.createElement('style');st.textContent=`
#ov.wrhx{background:#07041a}
.wrhub .fshvig{background:linear-gradient(90deg,#07041af4 0%,#07041ae0 36%,#07041a70 56%,#07041a00 72%)}
.wrhl{width:720px;top:44px}
.wrhub .fsht em{background:linear-gradient(180deg,#fff6c0,#ffd45a 50%,#ff9a20);-webkit-background-clip:text;background-clip:text}
.wrhub .fsht{margin:12px 0 0;line-height:1.06}.wrhub .fshs{margin:14px 0 14px!important}
.wrmu{display:flex;align-items:center;gap:8px;height:58px;padding:0 18px;color:#fff8e8;font:700 17px var(--ui);cursor:pointer}.wrmu[aria-pressed="false"]{color:#c4badf}
.wrroutes{display:flex;flex-direction:column;gap:8px;width:640px;animation:fsIn .6s .15s var(--sp) both}
.wrrt{position:relative;display:flex;align-items:center;gap:14px;padding:8px 44px 8px 10px;border-radius:18px!important;text-align:left;color:#fff8e8;cursor:pointer;border-color:#3a3070!important;transition:transform .18s var(--sp),border-color .18s}
.wrrt:hover{transform:translateX(4px)}.wrrt.on{border-color:color-mix(in srgb,var(--c) 70%,#ffd45a)!important;background:linear-gradient(180deg,#2c2270f2,#160e40f6)}.wrrt.on::after{content:'';position:absolute;inset:-1px;border-radius:18px;box-shadow:0 0 0 2px #ffd45a55;pointer-events:none}
.wrrt.lock{opacity:.72}.wrrt.lock:hover{transform:none}.wrrt .dkchv{position:absolute;right:16px;top:50%;transform:translateY(-50%)}
.wrrm{flex:none;width:54px;height:54px}.wrrm svg{display:block}.wrrtt{display:flex;flex-direction:column;gap:1px;min-width:0}.wrrtt b{font:800 19px var(--ui)}.wrrtt small{font:500 12.5px var(--ui);color:#c4badf}.wrrtt em{font:700 12.5px var(--ui);font-style:normal;color:#ffd45a}.wrrtt em.wrlk{color:#9f96c4}.wrlk svg{vertical-align:-1px}
.wrgo{margin-top:14px;width:640px}.wrgo .fshgoi svg{width:52px;height:32px}.wrgo .fshgoi svg *{fill:#3a2006}
.wrtl{grid-template-columns:repeat(3,1fr);width:640px;margin-top:16px}
.wrhub .fsmod{z-index:6}
/* workshop */
.wrws{position:relative;display:flex;gap:22px;width:1360px;max-height:820px;padding:22px 26px;animation:fsWb .4s var(--sp) both}.wrws h3,.wrlog h3,.wrhow h3{margin:0 0 4px;font:400 44px/1 'Pirata One',Georgia,serif;color:var(--gold)}
.wrws .fsx2{top:-16px;right:-16px}.wrws h3{margin-bottom:8px}.wrws p{margin:0 0 10px;font:500 15px/1.45 var(--ui);color:#e8e0ff}.wrwsl{width:640px;flex:none}.wrwsl canvas{display:block;width:640px;height:360px;border-radius:16px;border:2px solid #3a3070;background:#0c0824}.wrwsd{min-height:22px;margin-top:8px!important;color:#ffd45a!important;font-style:italic}
.wrwsr{display:flex;flex-direction:column;gap:10px;flex:1;min-width:0;overflow:auto}.wrwrow h4{margin:0 0 6px;font:800 12px var(--ui);letter-spacing:.2em;text-transform:uppercase;color:#c8beff}
.wrchips{display:flex;flex-wrap:wrap;gap:8px}
.wrchip{all:unset;position:relative;box-sizing:border-box;display:flex;flex-direction:column;align-items:center;gap:2px;width:122px;padding:8px 6px 8px;border-radius:14px;border:2px solid #3a3070;background:#15103ae6;color:#fff8e8;cursor:pointer;text-align:center;transition:transform .18s var(--sp),border-color .18s}
.wrchip:hover,.wrchip:focus-visible{transform:translateY(-3px);border-color:#8a7ad0}.wrchip:focus-visible{outline:2px solid #fff}.wrchip.on{border-color:#ffd45a;background:#2a2060}.wrchip.lock{opacity:.6}.wrchip.lock:hover{transform:none}
.wrchip b{font:800 13px/1.1 var(--ui)}.wrchip small{font:600 11px var(--ui);color:#c4badf}.wrchip small.wreq{color:#ffd45a}.wrchip small.wrlk{color:#9f96c4;font-size:10px;line-height:1.2}.wrchpv canvas{display:block;width:84px;height:84px}
.wrnew{position:absolute;top:-7px;right:-6px;padding:2px 7px;border-radius:7px;font:800 10px var(--ui);font-style:normal;letter-spacing:.08em;color:#1a0a04;background:linear-gradient(90deg,#7affd8,#ffd45a)}
/* route log */
.wrlog{position:relative;width:860px;padding:22px 26px 20px;animation:fsWb .4s var(--sp) both;display:flex;flex-direction:column;gap:10px}
.wrlrs{display:flex;flex-direction:column;gap:8px}.wrlr{display:grid;grid-template-columns:46px 1fr 110px 110px 110px;align-items:center;gap:14px;padding:8px 14px;border-radius:14px;background:#15103ae6;border:1.5px solid color-mix(in srgb,var(--c) 40%,#3a3070)}
.wrlr b{font:800 16px var(--ui);color:#fff8e8}.wrlr small{display:block;font:600 11px var(--ui);letter-spacing:.08em;text-transform:uppercase;color:#b8aee0}.wrlr div{display:flex;flex-direction:column}.wrlr span{display:flex;flex-direction:column}.wrlr span b{color:var(--c)}
.wrlst{display:grid;grid-template-columns:repeat(6,1fr);gap:8px}.wrlst span{display:flex;flex-direction:column;padding:8px 10px;border-radius:12px;background:#0c0824;border:1px solid #3a3070}.wrlst small{font:700 10.5px var(--ui);letter-spacing:.08em;text-transform:uppercase;color:#b8aee0}.wrlst b{font:800 20px var(--ui);color:#fff8e8}
.wrlm{margin:0;font:500 14px var(--ui);color:#c4badf}.wrlm.on{color:#ffd45a}.wrlm b{color:#ffd45a}
/* how to play */
.wrhow{position:relative;width:1060px;padding:22px 26px 20px;animation:fsWb .4s var(--sp) both;display:flex;flex-direction:column;gap:12px}
.wrsteps{display:flex;align-items:center;gap:8px}.wrsteps>i{font-style:normal;font:800 34px var(--ui);color:#8a7ad0}.wrstep{display:flex;flex-direction:column;gap:4px;width:300px}.wrstep canvas{display:block;width:300px;height:150px;border-radius:14px;border:2px solid #3a3070}.wrstep b{font:800 15px var(--ui);color:#fff8e8;margin-top:4px}.wrstep small{font:500 12.5px/1.4 var(--ui);color:#c4badf}
.wrhrow{display:flex;gap:14px}.wrhrow span{flex:1;display:flex;align-items:flex-start;gap:8px;padding:10px 12px;border-radius:12px;background:#0c0824;border:1px solid #3a3070;font:500 13px/1.4 var(--ui);color:#e0d8ff}.wrhrow svg{flex:none;margin-top:1px}.wrhrow kbd,.wrph kbd{font:700 12px var(--ui);color:#ffd45a;border:1px solid #5a4ca0;border-radius:6px;padding:1px 6px;background:#1c1446}
.wrhow .row{margin-top:4px}
/* result card */
#ov.wrpx{background:rgba(9,5,22,.82)}
.wrres{position:relative;display:flex;flex-direction:column;align-items:center;gap:10px;width:960px;padding:88px 30px 26px;border-radius:26px;background:linear-gradient(180deg,#221a5af4,#100a30fa);border:2px solid color-mix(in srgb,var(--c) 55%,#3a3070);box-shadow:0 30px 80px #000c;animation:fsWb .45s var(--sp) both}
.wrres h2{font-size:62px}.wrres.lose h2{color:#ff8a9a;text-shadow:0 3px 0 #3a0c18}.wrsub{margin:0;font:600 17px var(--ui);color:#e8e0ff}.wrsub b{font-weight:800}.wrnb{color:#7dffb0}
.wrmed{position:absolute;top:-72px;left:50%;width:150px;height:150px;margin-left:-75px}.wrmed svg{display:block;filter:drop-shadow(0 10px 18px #000a)}
.wrmed.slam{animation:wrSlam .7s .25s cubic-bezier(.3,1.5,.5,1) both}@keyframes wrSlam{0%{transform:scale(2.4) rotate(-14deg);opacity:0}55%{transform:scale(.94);opacity:1}100%{transform:scale(1) rotate(0)}}
.wrres .res{gap:8px 28px;font-size:18px}.wrres .res>div{display:flex;flex-direction:column;align-items:center}.wrres .res b{font:800 26px var(--ui);color:#fff8e8}
.wrpay{display:flex;flex-direction:column;align-items:center;gap:2px;padding:10px 26px;border-radius:16px;background:#0c0824;border:1px solid #3a3070}.wrpayc{display:flex;align-items:center;gap:10px;font:700 20px var(--ui);color:#fff8e8}.wrpayc b{font:800 34px var(--ui);color:#ffd45a;min-width:120px;text-align:right}.wrpay small{font:500 12.5px var(--ui);color:#c4badf}
.wrcoinb{display:inline-block;width:30px;height:30px;border-radius:50%;background:radial-gradient(circle at 35% 30%,#fff6c0 0 18%,#ffd24a 40%,#c98a10 100%);border:2px solid #7a4a06}.wrcoinb.bump{animation:wrBump .3s var(--sp)}@keyframes wrBump{40%{transform:scale(1.35)}}
.wrfly{position:absolute;z-index:45;width:22px;height:22px;border-radius:50%;pointer-events:none;background:radial-gradient(circle at 35% 30%,#fff6c0 0 18%,#ffd24a 40%,#c98a10 100%);border:2px solid #7a4a06}
.wrxp{margin:0;font:500 16px/1.5 var(--ui);color:#e8e0ff}.wrxp b{color:#fff8e8}
.wrunls{display:flex;gap:10px;flex-wrap:wrap;justify-content:center}.wrunl{display:flex;align-items:center;gap:10px;padding:6px 14px 6px 6px;border-radius:14px;background:#15103a;border:1.5px solid var(--c);animation:fsWb .5s .6s var(--sp) both}.wrunl canvas{width:56px;height:56px}.wrunl b{display:block;font:800 14px var(--ui);color:#fff8e8}.wrunl small{font:600 11px var(--ui);letter-spacing:.08em;text-transform:uppercase;color:var(--c)}
/* pause menu over the run */
#ov.wrpx .wrpause{gap:14px}
/* the touch keyboard over the run */
#ov.wrkbx{background:none;padding:0 0 6px;justify-content:flex-end;pointer-events:none;overflow:hidden}
#wrkb{pointer-events:auto;display:flex;flex-direction:column;gap:6px;width:min(100%,980px);padding:8px 8px 6px;border-radius:18px 18px 0 0;background:#0a0620ee;border:1.5px solid #3a3070;border-bottom:none}
.wrkr{display:flex;justify-content:center;gap:5px}.wrkr button{all:unset;box-sizing:border-box;width:9.2%;height:50px;border-radius:10px;background:linear-gradient(#3c2e6c,#241a48);border:1px solid #6a58a8;color:#fff8e8;font:700 22px var(--ui);text-align:center;text-transform:uppercase;cursor:pointer}
.wrkr button.hit{animation:wrHit .18s}@keyframes wrHit{30%{transform:scale(.9);background:#5a4ca0}}
.wrka button{width:22%;text-transform:none;font-size:18px}.wrka .wrkf{background:linear-gradient(#ffe490,#f0a820);color:#2a1608;border-color:#8a5610}
/* home card and the mode sheet */
.dksc.dks4{grid-template-columns:1fr 1fr!important}
.dkwagon{border-color:#ffb04aaa!important}.dkwagon:hover{border-color:#ffd48a!important}.dkwagon .dkcl b{color:#fff8e8}.dkwagon .dkcl small:first-child{color:#ffd45a;letter-spacing:.18em}
.dkmwr{grid-column:1/-1}.dkmwr .dkmt{max-width:none}.dkmwr .dkmt b{width:auto;white-space:nowrap}
.dksc.dks4 .dkcard{min-height:118px}
.wrgo #wrgot{display:flex;flex-direction:column;align-items:flex-start;line-height:1}.wrgo #wrgot small{font:700 14px var(--ui);opacity:.78;margin-top:5px}
.wrhrow em{font-style:normal}
.wrres{width:min(960px,100%)}
/* narrow (touch) layout: the column stacks over the scene */
.wrhub.wr-narrow{width:100%;height:auto;min-height:100%;overflow:visible}
.wrhub.wr-narrow>canvas{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
.wrhub.wr-narrow .fshvig{background:linear-gradient(180deg,#07041aee 0%,#07041ac0 55%,#07041a60 100%)}
.wrhub.wr-narrow .wrhl{position:relative;left:0;top:0;width:100%;padding:74px 16px 18px;box-sizing:border-box}
.wrhub.wr-narrow .fsht{font-size:66px}.wrhub.wr-narrow .fshs{max-width:none}
.wrhub.wr-narrow .wrroutes,.wrhub.wr-narrow .wrgo,.wrhub.wr-narrow .wrtl{width:100%}
.wrhub.wr-narrow .fstr{right:12px;top:12px}
.wrhub.wr-narrow .fsmod{position:fixed!important;inset:0;width:auto!important;height:auto!important;overflow:auto;padding:10px;box-sizing:border-box}
.wrhub.wr-narrow .wrws,.wrhub.wr-narrow .wrlog,.wrhub.wr-narrow .wrhow{width:100%;max-height:none;box-sizing:border-box}
.wrhub.wr-narrow .wrws{flex-direction:column}.wrhub.wr-narrow .wrwsl{width:100%}.wrhub.wr-narrow .wrwsl canvas{width:100%;height:auto}.wrhub.wr-narrow .wrwsr{overflow:visible}
.wrhub.wr-narrow .wrsteps{flex-direction:column}.wrhub.wr-narrow .wrsteps>i{transform:rotate(90deg)}.wrhub.wr-narrow .wrstep{width:100%}.wrhub.wr-narrow .wrstep canvas{width:100%;height:auto}.wrhub.wr-narrow .wrhrow{flex-direction:column}
.wrhub.wr-narrow .wrlr{grid-template-columns:46px 1fr;gap:8px 14px}.wrhub.wr-narrow .wrlr span{flex-direction:row;gap:8px;align-items:baseline}.wrhub.wr-narrow .wrlst{grid-template-columns:repeat(3,1fr)}
.wrhub.wr-narrow .wrws .fsx2,.wrhub.wr-narrow .wrlog .fsx2,.wrhub.wr-narrow .wrhow .fsx2{top:10px;right:10px}
@media (prefers-reduced-motion:reduce){.wrmed.slam,.wrunl,.wrroutes,.wrres{animation:none!important}}`;document.head.appendChild(st)}
