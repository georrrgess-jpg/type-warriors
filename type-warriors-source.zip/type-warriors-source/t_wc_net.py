import asyncio,os,sys,time
from playwright.async_api import async_playwright
async def main():
    html=os.path.abspath((sys.argv[1] if len(sys.argv)>1 else 'out.html'))
    async with async_playwright() as p:
        b=await p.chromium.launch(args=sys.argv[2:]);er=[]
        ca=await b.new_context(viewport={'width':1600,'height':900});cb=await b.new_context(viewport={'width':1600,'height':900})
        A=await ca.new_page();B=await cb.new_page()
        for nm,pg in (('A',A),('B',B)):pg.on('pageerror',lambda e,nm=nm:er.append(nm+' PE '+str(e)[:300]))
        await A.goto('file://'+html);await B.goto('file://'+html);await A.wait_for_timeout(1200)
        await A.evaluate("()=>{RS_ASK=false;P.name='Seth';P.gold=3000;save();wcHome();wcLobby();WCL.set.stake=50}")
        await B.evaluate("()=>{RS_ASK=false;P.name='Mia';P.gold=900;save();wcHome()}")
        await A.click('[data-add="inv"][data-i="3"]');await A.wait_for_selector('#wcicode',timeout=8000)
        code=await A.eval_on_selector('#wcicode','e=>e.value');print('invite',len(code))
        await B.fill('#wcjin',code);await B.click('#wcjoin');await B.wait_for_selector('#wcrc',timeout=8000)
        reply=await B.eval_on_selector('#wcrc','e=>e.value');print('reply',len(reply))
        await B.screenshot(path='shots/wc_join2.png')
        await A.fill('#wcrep',reply);await A.click('#wcrgo')
        t0=time.time()
        while time.time()-t0<15:
            st=await A.evaluate("()=>WCL.seats.map(s=>s.k+(s.ready?'R':''))")
            if 'net' in st:break
            await A.wait_for_timeout(300)
        print('host seats',st,f'{time.time()-t0:.1f}s');await B.wait_for_timeout(800)
        await B.screenshot(path='shots/wc_join3.png')
        await B.click('#wcrdy');await A.wait_for_timeout(600)
        print('after ready',await A.evaluate("()=>WCL.seats.map(s=>s.k+(s.ready?'R':'')+(s.name?':'+s.name:''))"))
        await A.screenshot(path='shots/wc_lobby_net.png')
        await A.click('#wcgo');await A.wait_for_timeout(3000)
        print('B table',await B.evaluate("()=>[!!document.getElementById('wct'),WX.me,WX.mode,WX.host,WX.G&&WX.G.P.map(p=>p.name+':'+p.hand.length),P.gold]"))
        for pg in (A,B):await pg.add_script_tag(path=os.path.abspath('t_wc_agent.js'))
        t0=time.time()
        while time.time()-t0<420:
            await A.wait_for_timeout(1000)
            if await A.evaluate("()=>!!document.getElementById('wcr')") and await B.evaluate("()=>!!document.getElementById('wcr')"):break
            if int(time.time()-t0)==40:await B.screenshot(path='shots/wc_net_mid_B.png');await A.screenshot(path='shots/wc_net_mid_A.png')
        print('done in',round(time.time()-t0),'s')
        for nm,pg in (('A',A),('B',B)):print(nm,await pg.evaluate("()=>{const W=wcSt();return [document.querySelector('.wcrh')&&document.querySelector('.wcrh').textContent,P.gold,W.g,W.w,W.byd.net,__ag]}"))
        await B.screenshot(path='shots/wc_net_res_B.png')
        print(er[:8]);await b.close()
asyncio.run(main())
