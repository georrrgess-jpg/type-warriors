/* ===== RUNESTONE TOWER DEFENSE 10.2: battle UI and features (99e, after 98v; prefix rpq, config RPQX) =====
   1. Damage meter. Every point of monster health a tower takes away is booked on that tower (tw.rpqD). The hook is the one damage
      gate every effect already goes through: rpHurt(e,dmg,ap,src) (bolts, splash, burning ground, puddles, chains, bees, stars,
      wells, Tide waves, novas, honey bursts... all pass their tower as src). The outermost wrapper reads the health before and after
      (so armor, shields, marks, pollen and every other multiplier are already applied and overkill is not counted); executes that
      kill outright (Starfall "finished", Engine "swallowed", Midas gold) book the health that was left through rpKillFoe. A src
      that is not a tower, or a projectile that carries one in .tw, is resolved by rpqDmOf. Not attributed (R.rpqUn): map hazards
      (lava vents, the wreck cannon, storm bolts) and anything that passes no tower. Time in battle (tw.rpqT, game seconds while a
      wave runs) gives the DPS. The info panel shows "damage · DPS" under the defeated count; sold towers are remembered
      (R.rpqSold) for the results, which get an MVP card (the single best tower) and damage bars for the top tower types.
   2. Call the next wave early. While a wave runs, the wave panel (and Space / Enter) sends the next wave now. Bonus supply =
      EARLY (3) per second of the skipped 15 s countdown plus half that per second of the current wave's spawning still to come
      (at most 15 s), times (1 + 3% per wave), halved for every wave already called on top (at most two on top), in steps of 5:
      about 60 on wave 1, 90 on wave 10, 150 on Wonderland wave 40 (a wave's own clear bonus is 30 + 6 per wave).
      Each queue entry and monster carries its wave (q.w, e.rpqW); a wave counts as cleared (its supply, coins, mastery, fanfare,
      freeplay count) only when its own monsters are gone, through the normal rpWaveDone chain with R.wave set to that wave. A
      defeat or a quit while called waves are open counts the waves held up to the oldest open one (R.wave is set back to it), so
      the Championship, XP and freeplay counts never get more than normal play. Monsters of an older wave spawn with that wave's
      health and bounty. Auto-start next wave (TD Settings, P.rp.opt.auto, off): the next wave starts 2 s after a wave is cleared
      (the early-call supply for the rest of the countdown is paid, as if Space had been pressed).
   3. Next Wave preview: up to three monster types of the coming wave with counts and badges (flying, armored, boss, ability), a
      header with what is still on the road, and a hover / tap card listing every type of that wave. It sits on top of the wave
      button as one panel at the right of the bottom row.
   4. Any number of towers: the bottom row is laid out from the tower count (cards share the space between the abilities and the
      wave panel; below 76 px the names go to the hover tooltip and the icon and cost grow), the build ring uses two arcs above
      twelve buttons, the How to Play / help texts count the towers, and How to Play, Tower Skins and results were checked with 14.
   5. Fixes found on the way: the wave preview said "Next wave" while it showed the wave already running; the tower info panel
      could open over the toast line (now placed from y 128); the Tower Skins list already ran past its panel with twelve towers
      (rows now shrink to fit every tower); help / How to Play said "twelve" (now counts RP_TWORDER); with 13+ towers the Wonderland's
      Ascended Towers grid grew a third row under the Armory bar (now two rows of ceil(n/2)), the bar ran
      under the abilities and the wave panel and the ring buttons overlapped (the 10.1 audit with two dummy towers). */
const RPQX={stack:2,gap:.8,waveK:.03,spawnMax:15,spawnK:.5,auto:2,cmp:76,abR:304,colW:276,colR:14};
const rpqNum=n=>['zero','one','two','three','four','five','six','seven','eight','nine','ten','eleven','twelve','thirteen','fourteen','fifteen','sixteen','seventeen','eighteen','nineteen','twenty'][n]||String(n);
function rpqFmt(v){v=Math.max(0,v||0);if(v<1000)return String(Math.round(v));if(v<1e5)return (Math.floor(v/100)/10).toFixed(1).replace(/\.0$/,'')+'k';if(v<1e6)return Math.round(v/1000)+'k';if(v<1e7)return (Math.floor(v/1e5)/10).toFixed(1).replace(/\.0$/,'')+'M';return Math.round(v/1e6)+'M'}
/* ---------- 1. damage meter ---------- */
function rpqDmOf(src){if(!src||typeof src!=='object')return null;if(src.pad&&src.type&&RP_TW[src.type])return src;const t=src.tw||src.src||src.owner;return t&&typeof t==='object'&&t.pad&&t.type&&RP_TW[t.type]?t:null}
function rpqDmAdd(src,v){const R=RPX;if(!R||!(v>0))return;R.rpqTot=(R.rpqTot||0)+v;const tw=rpqDmOf(src);if(tw)tw.rpqD=(tw.rpqD||0)+v;else R.rpqUn=(R.rpqUn||0)+v}
{const h0=rpHurt;rpHurt=function(e,dmg,ap,src){if(!e||e.dead)return h0.apply(this,arguments);const hp0=e.hp;const r=h0.apply(this,arguments);
 try{const lost=hp0-Math.max(0,e.hp);if(lost>0)rpqDmAdd(src,lost)}catch(x){}return r}}
{const k0=rpKillFoe;rpKillFoe=function(e,src){const R=RPX;if(!e||e.dead)return k0.apply(this,arguments);const hp0=e.hp,w0=R?R.wave:0;
 /* a monster of an older (called-over) wave splits into children of its own wave */
 const old=R&&e.rpqW!=null&&e.rpqW<R.wave;if(old){R.wave=e.rpqW;R.rpqCtx=e.rpqW}
 try{const r=k0.apply(this,arguments);try{if(e.dead&&!e.leak&&hp0>0)rpqDmAdd(src,hp0)}catch(x){}return r}finally{if(old&&R){R.wave=w0;R.rpqCtx=null}}}}
{const s0=rpSell;rpSell=function(tw){const R=RPX;try{if(R&&tw&&tw.rpqD>0){(R.rpqSold=R.rpqSold||[]).push({type:tw.type,tier:tw.tier,skin:tw.skin,d:tw.rpqD,k:tw.kills||0,t:tw.rpqT||0,sold:1})}}catch(e){}return s0.apply(this,arguments)}}
/* every tower on the field plus the sold ones */
function rpqDmList(R){const L=[];for(const p of R.pads){const tw=p.tw;if(tw&&(tw.rpqD>0||tw.kills>0))L.push({type:tw.type,tier:tw.tier,skin:tw.skin,d:tw.rpqD||0,k:tw.kills||0,t:tw.rpqT||0})}for(const s of R.rpqSold||[])L.push(s);return L}
function rpqDmStats(R){const L=rpqDmList(R),by={};let tot=0;for(const x of L){tot+=x.d;const b=by[x.type]||(by[x.type]={t:x.type,d:0,n:0,k:0});b.d+=x.d;b.n++;b.k+=x.k}
 const mvp=L.slice().sort((a,b)=>b.d-a.d||b.k-a.k)[0]||null;return{tot,un:R.rpqUn||0,mvp:mvp&&mvp.d>0?mvp:null,types:Object.values(by).filter(b=>b.d>0).sort((a,b)=>b.d-a.d)}}
/* ---------- 2. waves: tags, call early, per-wave clearing ---------- */
/* P.rp.opt.auto: 1 when on; absent when off (97h's options object stays as it was) */
function rpqOpt(){const r=RPP();let o=r.opt;if(!o||typeof o!=='object'||Array.isArray(o))o=r.opt={};if('auto' in o&&o.auto!==1)delete o.auto;return{auto:o.auto===1?1:0}}
function rpqAutoSet(on){const r=RPP();rpqOpt();if(on)r.opt.auto=1;else delete r.opt.auto;try{save()}catch(e){}}
{const s0=rpStart;rpStart=function(){const r=s0.apply(this,arguments);try{const R=RPX;if(R){R.rpqDue=[];R.rpqSold=[];R.rpqUn=0;R.rpqTot=0;R.rpqEarly=0;R.rpqCalls=0;R.rpqLast=-9}}catch(e){}return r}}
{const w0=rpWaveStart;rpWaveStart=function(){const R=RPX,n0=R?R.wave:0;const r=w0.apply(this,arguments);try{if(R&&R.wave!==n0&&R.q){for(const q of R.q)if(q.w==null)q.w=R.wave;
  /* the "Wave N cleared" ribbon (98o) steps aside for the new wave's banner instead of overlapping it (early calls, Auto-start) */
  const f=$('rpuwave');if(f&&!f.classList.contains('out')){f.classList.add('out');setTimeout(()=>{try{f.remove()}catch(e){}},rpRM()?0:320)}}}catch(e){}return r}}
/* which queue entry a spawn came from: the queue as it was at the start of the step, shifted from the front by the engine */
{const s0=rpSpawn;rpSpawn=function(id,pi){const R=RPX;if(!R)return s0.apply(this,arguments);let w=null;
 try{const Q=R.rpqQ0;if(Q&&R.q&&Q.length-R.q.length>(R.rpqSpN||0)){const q=Q[R.rpqSpN||0];if(q&&q.id===id){R.rpqSpN=(R.rpqSpN||0)+1;w=q.w}}}catch(e){}
 if(w==null)w=R.rpqCtx!=null?R.rpqCtx:R.wave;const W0=R.wave,old=w!=null&&w<W0;if(old)R.wave=w;
 try{const e=s0.apply(this,arguments);if(e)e.rpqW=w;return e}finally{if(old)R.wave=W0}}}
/* can the next wave be called right now: {ok, b (bonus supply), n (its number), why} */
function rpqWvCan(R){if(!R||R.over||R.wst!=='run'||R.wave<1)return{ok:false,why:''};const n=R.wave+1;
 if(!R.free&&!R.map.endless&&n>R.map.waves)return{ok:false,n,why:'Final wave'};
 const due=(R.rpqDue||[]).length;if(due>=RPQX.stack)return{ok:false,n,why:`${due+1} waves on the road`};
 if(R.time-(R.rpqLast||-9)<RPQX.gap)return{ok:false,n,why:''};
 let mx=0;for(const q of R.q||[])if(q.w===R.wave||q.w==null)mx=Math.max(mx,q.at);const left=Math.min(RPQX.spawnMax,Math.max(0,mx-R.wt));
 const b=Math.max(5,Math.round(RPT.EARLY*(RPT.BUILD_T+RPQX.spawnK*left)*(1+RPQX.waveK*R.wave)*Math.pow(.5,due)/5)*5);return{ok:true,n,b,why:''}}
function rpqWvCall(loud){const R=RPX;if(!R||R.pause||R.over)return false;const c=rpqWvCan(R);
 if(!c.ok){if(loud&&c.why){rpSfx('no');rpToast(c.why==='Final wave'?'This is the final wave: nothing left to call':`${c.why}: clear one before calling another`,1.6,'#9fd0ff')}return false}
 const left=(R.q||[]).map(q=>Object.assign({},q,{at:Math.max(0,q.at-R.wt),w:q.w==null?R.wave:q.w}));
 const n0=R.wave,wt0=R.wt;R.wst='build';R.cd=0;rpWaveStart();
 if(R.wst!=='run'||R.wave!==n0+1){R.wst='run';R.wt=wt0;return false}
 R.rpqDue=(R.rpqDue||[]).concat([n0]);R.supply+=c.b;R.rpqEarly=(R.rpqEarly||0)+c.b;R.rpqCalls=(R.rpqCalls||0)+1;R.rpqLast=R.time;
 R.q=(R.q||[]).concat(left).sort((a,b)=>a.at-b.at);
 rpText(800,236,`Wave ${c.n} called early · +${c.b} supply`,'#ffd45a',26);
 try{const g=$('rpgo');if(g){const s=document.createElement('span');s.className='rpqpop';s.textContent='+'+c.b;g.appendChild(s);setTimeout(()=>s.remove(),1100)}}catch(e){}
 return true}
/* a called-over wave is cleared: run the wave-done chain for it (R.wave set to that wave), then carry on with the run */
function rpqWvFlush(R,w,dy){const W0=R.wave,cd=R.cd,st=R.wst,n0=R.tx.length;R.wave=w;R.rpqFl=1;
 try{RPQX.done.call(null)}catch(e){console.error(e)}finally{R.rpqFl=0;R.wave=W0;if(st==='run'&&R.wst==='build')R.wst='run';R.cd=cd}
 if(dy)for(let i=n0;i<R.tx.length;i++)R.tx[i].y-=dy}
{const w0=rpWaveDone;RPQX.done=w0;rpWaveDone=function(){const R=RPX;if(R&&!R.rpqFl&&R.rpqDue&&R.rpqDue.length){const d=R.rpqDue.slice().sort((a,b)=>a-b);R.rpqDue=[];d.forEach((w,i)=>rpqWvFlush(R,w,(d.length-i)*38))}return RPQX.done.apply(this,arguments)}}
/* a defeat or a quit with called waves still open counts the waves held up to the oldest open one */
const rpqWvBack=R=>{if(R&&!R.over&&R.wst!=='build'&&R.rpqDue&&R.rpqDue.length){R.wave=Math.min(...R.rpqDue)}};
{const d0=rpDefeat;rpDefeat=function(){try{const R=RPX;if(R&&R.wst==='run')rpqWvBack(R)}catch(e){}return d0.apply(this,arguments)}}
{const f0=rpFinish;rpFinish=function(){try{rpqWvBack(RPX)}catch(e){}return f0.apply(this,arguments)}}
{const f0=rpFinishEndless;rpFinishEndless=function(){try{rpqWvBack(RPX)}catch(e){}return f0.apply(this,arguments)}}
{const s0=rpStep;rpStep=function(R,dt){if(!R)return s0.apply(this,arguments);R.rpqQ0=R.wst==='run'&&R.q&&R.q.length?R.q.slice():null;R.rpqSpN=0;
 const r=s0.apply(this,arguments);R.rpqQ0=null;
 try{if(R.wst==='run'&&!R.over){for(const p of R.pads){const tw=p.tw;if(tw&&tw.build>=1)tw.rpqT=(tw.rpqT||0)+dt}
   /* called-over waves whose own monsters are all gone */
   if(R.rpqDue&&R.rpqDue.length){const open=new Set();for(const e of R.foes)if(!e.dead)open.add(e.rpqW==null?R.wave:e.rpqW);for(const q of R.q)open.add(q.w==null?R.wave:q.w);
    const done=R.rpqDue.filter(w=>!open.has(w)).sort((a,b)=>a-b);if(done.length){R.rpqDue=R.rpqDue.filter(w=>open.has(w));for(const w of done)if(R.wst==='run')rpqWvFlush(R,w,0)}}}
  /* auto-start: the next wave goes RPQX.auto seconds after a wave is cleared */
  if(R.wst==='build'&&R.wave>0&&!R.over&&!R.tut&&!R.pause&&R.cd>0&&R.cd<=RPT.BUILD_T-RPQX.auto&&rpqOpt().auto)rpWaveStart()}catch(e){console.error(e)}
 return r}}
/* Space / Enter during a wave: call the next one */
{const k0=rpKeyDown;window.removeEventListener('keydown',rpKeyDown,true);rpKeyDown=function(e){const R=RPX;
 if(R&&S.rp&&S.mode==='ramparts'&&!R.pause&&!R.over&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&(e.key===' '||e.key==='Enter')&&R.wst==='run'){e.preventDefault();e.stopImmediatePropagation();if(!e.repeat)rpqWvCall(true);return}
 return k0.apply(this,arguments)};window.addEventListener('keydown',rpKeyDown,true)}
/* ---------- 3. the wave panel: preview + button ---------- */
const RPQB={fly:['Flying','#9fe8ff','<path d="M2 13c4.5-.5 7.5-3.5 10-9 2.5 5.5 5.5 8.5 10 9-4.5 1-7.5 3.5-10 7-2.5-3.5-5.5-6-10-7z"/>'],
 arm:['Armored','#d8d4f0','<path d="M12 2l8 3v6c0 5-3.4 9-8 11-4.6-2-8-6-8-11V5z"/>'],
 boss:['Boss','#ffd45a','<path d="M3 19l1.6-11 5 4.6L12 4l2.4 8.6 5-4.6L21 19z"/>'],
 ab:['Ability','#d89aff','<path d="M12 2l2.6 7.4L22 12l-7.4 2.6L12 22l-2.6-7.4L2 12l7.4-2.6z"/>']};
const rpqBadge=(k,s)=>`<svg class="rpqbg rpqbg-${k}" viewBox="0 0 24 24" width="${s||13}" height="${s||13}" aria-hidden="true"><g fill="${RPQB[k][1]}" stroke="#12081f" stroke-width="2" stroke-linejoin="round">${RPQB[k][2]}</g></svg>`;
const RPQ_ABN={heal:'Heals others',split:'Splits',scut:'Scuttles',shellT:'Shells up',puffAt:'Puffs up',glimT:'Glimmers out of reach',shed:'Sheds armor',songT:'Shields friends',inkAt:'Inks towers',
 dive:'Dives',guardR:'Guards friends',ventAt:'Vents steam',hasteR:'Hastes friends',leapT:'Leaps',empR:'Jams towers',stompT:'Stomps towers'};
const RPQ_PLAIN={hp:1,sp:1,bounty:1,coin:1,dmg:1,armor:1,air:1,boss:1,splitN:1,healR:1,healT:1};
function rpqFoeAb(F){if(!F)return'';for(const k in RPQ_ABN)if(F[k])return RPQ_ABN[k];for(const k in F)if(!RPQ_PLAIN[k]&&F[k]&&!/^(n|h|w|col|pal|lift|sz|s)$/.test(k))return'Special ability';return''}
function rpqFoeBadges(id){const F=RP_FOE[id]||{},b=[];if(F.boss)b.push('boss');if(F.air)b.push('fly');if((F.armor||0)>=4)b.push('arm');if(rpqFoeAb(F))b.push('ab');return b}
function rpqWvData(R,n){let W=[];try{W=rpWave(R.map,n)||[]}catch(e){W=[]}const agg={},ord=[];for(const g of W){if(!agg[g.id]){agg[g.id]=0;ord.push(g.id)}agg[g.id]+=g.n}
 const ids=ord.slice().sort((a,b)=>(RP_FOE[b]&&RP_FOE[b].boss?1:0)-(RP_FOE[a]&&RP_FOE[a].boss?1:0)||agg[b]-agg[a]);return{ids,agg,tot:ids.reduce((s,i)=>s+agg[i],0),boss:ids.some(i=>RP_FOE[i]&&RP_FOE[i].boss)}}
function rpqWvLabel(R,n){return R.map.endless?`Wave ${n}`:n>R.map.waves?`Freeplay ${n-R.map.waves}`:`Wave ${n} / ${R.map.waves}`}
function rpqWvBuild(R,el,n){const D=rpqWvData(R,n),pal=R.map.pal,show=D.ids.slice(0,3),more=D.ids.length-show.length;
 const chip=id=>`<span class="rpqm"><img alt="" src="${rpMobURL(id,56,pal)}"><b>×${D.agg[id]}</b><i>${rpqFoeBadges(id).slice(0,2).map(k=>rpqBadge(k,14)).join('')}</i></span>`;
 const row=id=>{const F=RP_FOE[id]||{},ab=rpqFoeAb(F),tags=[];if(F.boss)tags.push(rpqBadge('boss',13)+'Boss');if(F.air)tags.push(rpqBadge('fly',13)+'Flying');if((F.armor||0)>=4)tags.push(rpqBadge('arm',13)+`Armor ${F.armor}`);if(ab)tags.push(rpqBadge('ab',13)+esc(ab));
  return `<li><img alt="" src="${rpMobURL(id,56,pal)}"><span><b>${esc(rpName(id,R))}</b>${tags.length?`<em>${tags.map(t=>`<s>${t}</s>`).join('')}</em>`:''}</span><i>×${D.agg[id]}</i></li>`};
 el.innerHTML=`<div class="rpqnh"><small>Next · ${rpqWvLabel(R,n)}</small>${D.boss?`<em class="rpqboss">${rpqBadge('boss',12)}Boss</em>`:''}<i id="rpqroad"></i></div>
  <div class="rpqms">${show.map(chip).join('')}${more>0?`<span class="rpqmore">+${more}</span>`:''}</div>
  <div class="rpqnc" role="tooltip"><p><b>${esc(rpqWvLabel(R,n))}</b><span>${D.tot} monsters</span></p><ul>${D.ids.map(row).join('')}</ul><small>${R.wst==='run'?'Space or the button below calls it now for bonus supply.':'Space or the button below starts it now.'}</small></div>`;
 el.setAttribute('aria-label',`Next: ${rpqWvLabel(R,n)}, ${D.ids.map(i=>D.agg[i]+' '+rpName(i,R)).join(', ')}`)}
function rpqWvTick(R,h,C){const el=$('rpnext'),g=$('rpgo');if(!el||!g)return;const done=R.wst==='done',n=R.wave+1,has=!done&&(R.free||R.map.endless||n<=R.map.waves);
 const key=has?`${R.map.id}|${n}|${R.wst==='run'}`:'';if(C.rpqNk!==key){C.rpqNk=key;if(!has){el.hidden=true;el.innerHTML=''}else{el.hidden=false;rpqWvBuild(R,el,n)}}
 if(has){const rd=R.wst==='run'?R.q.length+R.foes.filter(e=>!e.dead).length:0,t=rd?`${rd} on the road`:'';if(C.rpqRd!==t){C.rpqRd=t;rpSetText($('rpqroad'),t)}}
 /* the button */
 let go,gos,bn='',mode;if(done){mode='done'}else if(R.wst==='build'){if(R.wave===0){go='Start wave 1';gos='Space';mode='go'}else{const s=Math.ceil(Math.max(0,R.cd));go=`Wave ${n} in ${s}`;gos='Call it now · Space';bn=s*RPT.EARLY>0?'+'+s*RPT.EARLY:'';mode='go'}}
 else{const c=rpqWvCan(R);if(c.ok){go=`Call wave ${R.free&&!R.map.endless?'':c.n}`.trim();if(R.free&&!R.map.endless)go='Call the next wave';gos='Now · Space';bn='+'+c.b;mode='call'}
  else{const rd=R.q.length+R.foes.filter(e=>!e.dead).length;go=`${rd} monster${rd===1?'':'s'} left`;gos=c.why||`Wave ${R.free&&!R.map.endless?R.wave-R.map.waves:R.wave} in progress`;mode='run'}}
 if(mode==='done')return;rpSetText($('rpgob'),go);rpSetText($('rpgos'),gos);const b=$('rpqb');if(b){rpSetText(b,bn);b.hidden=!bn}
 if(C.rpqMd!==mode||g.disabled!==(mode==='run')||g.classList.contains('run')!==(mode==='run')){C.rpqMd=mode;g.classList.toggle('run',mode==='run');g.classList.toggle('rpqc',mode==='call');g.disabled=mode==='run';g.setAttribute('aria-label',`${go}. ${gos}${bn?', '+bn+' supply':''}`)}}
function rpqGo(){const R=RPX;if(!R||R.pause||R.over)return;if(R.wst==='build')rpWaveStart();else if(R.wst==='run')rpqWvCall(true)}
/* ---------- 4. the bottom row for any number of towers ---------- */
function rpqBarFit(h){const bar=h&&h.querySelector('.rpbar');if(!bar)return;const cards=[...bar.querySelectorAll('.rpcard')],n=cards.length;if(!n)return;
 const L=RPQX.abR,Rt=1600-RPQX.colR-RPQX.colW-10,av=Rt-L,gap=n>10?2:n>7?4:7,pad=22;
 const cw=Math.max(54,Math.min(110,Math.floor((av-pad-gap*(n-1))/n))),iw=Math.round(Math.min(80,cw<RPQX.cmp?cw-6:cw*.8)),bw=n*cw+gap*(n-1)+pad;
 h.style.setProperty('--rpqcw',cw+'px');h.style.setProperty('--rpqiw',iw+'px');h.style.setProperty('--rpqgap',gap+'px');h.classList.toggle('rpqcmp',cw<RPQX.cmp);
 bar.style.left=Math.round(L+Math.max(0,(av-bw)/2))+'px';h.dataset.rpqn=n}
{const h0=rpHudOn;rpHudOn=function(){const r=h0.apply(this,arguments);try{const R=RPX,h=$('rphud');if(R&&h){h.classList.add('rpq');rpqBarFit(h);
  const g=$('rpgo');if(g){g.onclick=()=>rpqGo();if(!$('rpqb'))g.insertAdjacentHTML('beforeend','<em class="rpqb" id="rpqb" hidden></em>')}
  const nx=$('rpnext');if(nx){nx.tabIndex=0;nx.onclick=e=>{e.stopPropagation();nx.classList.toggle('open')};nx.onmouseleave=()=>nx.classList.remove('open')}
  if(RPH){RPH.nw=R.wst==='done'?-1:R.wave+(R.wst==='build'?1:0);RPH.rpqNk=null;RPH.rpqMd=null;RPH.rpqDm=null}rpqWvTick(R,h,RPH||{})}}catch(e){console.error(e)}return r}}
document.addEventListener('pointerdown',e=>{try{const nx=$('rpnext');if(nx&&nx.classList.contains('open')&&!nx.contains(e.target))nx.classList.remove('open')}catch(x){}},true);
{const t0=rpHudTick;rpHudTick=function(force){const R=RPX,C=RPH;/* the engine's own preview stays out of the way: 99e owns #rpnext */
 if(R&&C)C.nw=R.wst==='done'?-1:R.wave+(R.wst==='build'?1:0);const r=t0.apply(this,arguments);
 try{const h=$('rphud');if(R&&C&&h&&!h.hidden){rpqWvTick(R,h,C);if(R.sel)rpqDmTick(R,C)}}catch(e){console.error(e)}return r}}
/* ---------- the info panel: damage and DPS under the defeated count; clear of the toast ---------- */
function rpqDmTxt(tw){const d=tw.rpqD||0,t=tw.rpqT||0;return `${rpqFmt(d)} damage · ${t>=1?rpqFmt(d/t):'0'} DPS`}
function rpqDmTick(R,C){const tw=R.sel,el=$('rpqdm');if(!tw||!el)return;const s=rpqDmTxt(tw);if(C.rpqDm!==s){C.rpqDm=s;rpSetText(el,s)}}
{const i0=rpInfoBuild;rpInfoBuild=function(R,tw,el){const r=i0.apply(this,arguments);try{const f=el&&el.querySelector('.rpif>span');if(f&&!f.querySelector('#rpqdm')){f.classList.add('rpqif');f.insertAdjacentHTML('beforeend',`<em class="rpqdm" id="rpqdm" title="Damage this tower has dealt in this battle, and its damage per second while waves run">${rpqDmTxt(tw)}</em>`);if(RPH)RPH.rpqDm=null}
  /* placed again now that it is taller, below the toast row (y 128) and above the bottom row (y 770) */
  const hgt=el.offsetHeight||380,lo=hgt>620?76:128,top=rpClamp(tw.y-hgt*.62,lo,766-hgt);el.style.top=Math.round(top)+'px'}catch(e){console.error(e)}return r}}
/* ---------- the build ring: two arcs above twelve buttons ---------- */
{const r0=rpnRing;rpnRing=function(p,n){if(!(n>12))return r0.apply(this,arguments);const S=typeof RPSAFE==='object'?RPSAFE:{x0:96,x1:1504,y0:128,y1:724},h=40,nO=Math.ceil(n/2)+1,nI=n-nO,K=.6;let best=null;
 for(const dir of [90,270,0,180,45,135,315,225]){const o=rpnArc(nO,dir),inn=rpnArc(nI,dir).map(q=>[q[0]*K,q[1]*K]),pts=o.concat(inn),xs=pts.map(q=>p.x+q[0]),ys=pts.map(q=>p.y+q[1]);
  const lo=Math.min(...xs)-h,hi=Math.max(...xs)+h,top=Math.min(...ys)-h,bot=Math.max(...ys)+h;
  const dx=lo<S.x0?S.x0-lo:hi>S.x1?S.x1-hi:0,dy=top<S.y0?S.y0-top:bot>S.y1?S.y1-bot:0;
  const sh=pts.map(q=>[q[0]+dx,q[1]+dy]),near=Math.min(...sh.map(q=>Math.hypot(q[0],q[1])));
  const cost=Math.hypot(dx,dy)+(near<RPN_RING.pad+36?1e4:0)+(dir%90?40:0)+(dir===0||dir===180?20:0);if(!best||cost<best.cost)best={cost,pts:sh,dir}}
 return best}}
/* ---------- texts that count the towers ---------- */
const rpqTwN=()=>rpqNum(RP_TWORDER.length);
{const h0=rpHowTo;rpHowTo=function(){const r=h0.apply(this,arguments);try{const g=ov.querySelector('#rpmod .rpuhg>p');if(g)g.innerHTML=g.innerHTML.replace(/All \w+ are open/,`All ${rpqTwN()} are open`);
  const w=ov.querySelector('#rpmod .rphw');if(w&&!w.querySelector('.rpqhw'))w.insertAdjacentHTML('beforeend',`<p class="rpqhw"><b>Calling waves early.</b> While a wave is running, press Space or the wave button to send the next one at once for bonus supply (more for the time it saves; at most three waves on the road). A wave pays its supply and coins when its own monsters are gone. Turn on Auto-start in Settings to start each wave as soon as the last one is cleared.</p><p class="rpqhw"><b>Damage.</b> Click a tower to see the damage it has dealt and its damage per second; the results name your most valuable tower.</p>`)}catch(e){console.error(e)}return r}}
/* the help text counts the towers when it is read (a later module may still add towers, or append to the text: the setter keeps that) */
try{const h=HELP.Modes.find(x=>x[0]==='Runestone Tower Defense');if(h){let base=h[1]+' While a wave runs, Space calls the next one early for bonus supply; Auto-start (Settings) starts each wave as soon as the last is cleared.';
 Object.defineProperty(h,1,{configurable:true,enumerable:true,get(){return base.replace(/\btwelve\b/g,rpqTwN())},set(v){base=String(v)}})}}catch(e){}
try{RP_TUT.upgrade.p='Click a tower to see its range, its damage so far, upgrade it (it grows grander at every tier) or sell it. The next wave starts by itself; calling it early, even while a wave is still running, pays bonus supply.'}catch(e){}
/* ---------- Settings: Auto-start next wave ---------- */
{const s0=rptySettingsHTML;rptySettingsHTML=function(){const html=s0.apply(this,arguments),o=rpqOpt();
 const row=`<div class="rpsetrow rpqset"><div><b>Auto-start next wave</b><p>The next wave starts ${RPQX.auto} s after a wave is cleared (with the early-call supply). Off: you get the ${RPT.BUILD_T} s countdown to build.</p></div>
  <button class="rpsw${o.auto?' on':''}" id="rpqasw" role="switch" aria-checked="${o.auto?'true':'false'}"><i></i><span>${o.auto?'On':'Off'}</span></button></div>`;
 const i=html.lastIndexOf('</div>');return i>0?html.slice(0,i)+row+html.slice(i):html+row}}
{const w0=rptyWire;rptyWire=function(root,after){const r=w0.apply(this,arguments);try{/* in the hub Settings the Rune Typing preview belongs under its own row */const pv=root.querySelector('.rptyprev'),row=root.querySelector('.rpqset');if(pv&&row){const box=document.createElement('div');box.className='rpset2 rpqsetw';box.appendChild(row);pv.after(box)}
 const sw=root.querySelector('#rpqasw');if(sw)sw.onclick=()=>{rpqAutoSet(!rpqOpt().auto);try{rpSfx('key',2)}catch(e){}after()}}catch(e){console.error(e)}return r}}
/* ---------- Tower Skins: the tower list fits every tower without scrolling (12 already ran past the panel) ---------- */
function rpqSkinFit(){const L=ov.querySelector('.rpcsl');if(!L)return;const n=L.querySelectorAll('.rpcsn').length;if(!n)return;const cs=getComputedStyle(L),pad=parseFloat(cs.paddingTop)+parseFloat(cs.paddingBottom),gap=parseFloat(cs.rowGap||cs.gap)||4;
 const av=L.clientHeight-pad,h=Math.max(40,Math.min(62,Math.floor((av-gap*(n-1))/n)));L.style.setProperty('--rpqsn',h+'px');L.classList.toggle('rpqsfit',h<62)}
{const s0=rpSkins;rpSkins=function(){const r=s0.apply(this,arguments);try{rpqSkinFit()}catch(e){console.error(e)}return r}}
/* ---------- the Wonderland's Ascended Towers grid: always two rows (a third row ran under the Rampart Armory bar with 13+ towers) ---------- */
{const m0=rampartsMenu;rampartsMenu=function(){const r=m0.apply(this,arguments);try{const g=ov.querySelector('.rpasc>div');if(g){const n=g.querySelectorAll('.rpai').length;g.style.gridTemplateColumns=`repeat(${Math.max(6,Math.ceil(n/2))},minmax(0,1fr))`}}catch(e){console.error(e)}return r}}
/* ---------- results: MVP and damage bars ---------- */
function rpqDmRes(){const R=RPX,res=R&&R.result,box=ov.querySelector('.rpres');if(!R||!res||!box||box.querySelector('.rpqmvp'))return;const D=res.rpq||(res.rpq=rpqDmStats(R));if(!D.mvp||!(D.tot>0))return;
 const M=D.mvp,TW=RPTW[M.type]||{n:M.type,col:'#ffd45a'},top=D.types.slice(0,4),mx=top[0].d||1,rm=rpRM();
 const bars=top.map((b,i)=>`<li style="--c:${(RPTW[b.t]||{}).col||'#ffd45a'}"><img alt="" src="${rpIconCanvas(b.t,1,rpSkinOf(b.t),48)}"><b title="${esc((RPTW[b.t]||{}).n||b.t)}">${esc((RPTW[b.t]||{}).n||b.t)}${b.n>1?` <small>×${b.n}</small>`:''}</b><i><s style="--f:${(b.d/mx).toFixed(3)};--d:${(.9+i*.12).toFixed(2)}s"></s></i><em>${rpqFmt(b.d)}</em></li>`).join('');
 const d=document.createElement('div');d.className='rpqmvp'+(rm?' rpqrm':'');
 d.innerHTML=`<div class="rpqmv" style="--c:${TW.col||'#ffd45a'}"><span class="rpqmvi"><img alt="" src="${rpIconCanvas(M.type,M.tier,M.skin||'base',96)}"></span><span class="rpqmvt"><small>MVP</small><b>${esc(TW.n)}</b><em>Tier ${['','I','II','III','IV','V'][M.tier]||M.tier} · ${rpqFmt(M.d)} damage · ${M.k} defeated${M.sold?' · sold':''}</em></span></div>
  <div class="rpqbars"><small>Damage by tower <b>${rpqFmt(D.tot)}</b></small><ul>${bars}</ul></div>`;
 try{const nb=d.querySelector('.rpqmvt b'),lb=[...d.querySelectorAll('.rpqbars li b')];requestAnimationFrame(()=>{try{rpuFit(nb,13);lb.forEach(x=>rpuFit(x,9))}catch(e){}})}catch(e){}
 const pay=box.querySelector('.wrpay');if(pay){const row=document.createElement('div');row.className='rpqrow';pay.replaceWith(row);row.appendChild(pay);row.appendChild(d)}else{const xp=box.querySelector('.wrxp');if(xp)xp.before(d);else box.appendChild(d)}}
{const r0=rpResult;rpResult=function(){const R=RPX;try{if(R&&R.result&&!R.result.rpq)R.result.rpq=rpqDmStats(R)}catch(e){}const out=r0.apply(this,arguments);try{rpqDmRes()}catch(e){console.error(e)}return out}}
{const r0=rpResultEndless;rpResultEndless=function(){const out=r0.apply(this,arguments);try{rpqDmRes()}catch(e){console.error(e)}return out}}
/* ---------- styles ---------- */
{const st=document.createElement('style');st.textContent=`
#rphud.rpq .rpbar{transform:none;gap:var(--rpqgap,2px);padding-left:9px;padding-right:9px}
#rphud.rpq .rpcard{width:var(--rpqcw,68px)}
#rphud.rpq .rpcard img{width:var(--rpqiw,56px);height:var(--rpqiw,56px);margin-left:calc(var(--rpqiw,56px) / -2);top:calc(var(--rpqiw,56px) * -.3)}
#rphud.rpq .rpct>b{max-width:calc(var(--rpqcw,68px) - 4px)}
#rphud.rpq.rpqcmp .rpct>b{display:none}
#rphud.rpq.rpqcmp .rpcard img{top:-12px}
#rphud.rpq.rpqcmp .rpct{bottom:7px}
#rphud.rpq.rpqcmp .rpcost{padding:2px 8px 2px 5px;font-size:14px}#rphud.rpq.rpqcmp .rpcost b{font-size:14px}#rphud.rpq.rpqcmp .rpcost svg{width:15px;height:15px}
#rphud.rpq .rpnext{right:${RPQX.colR}px;bottom:82px;width:${RPQX.colW}px;height:56px;box-sizing:border-box;padding:5px 10px 4px 12px;border-radius:18px 18px 8px 8px;border:2px solid #5a4ca0;
 background:linear-gradient(180deg,#221a5cf2,#110b34f4);box-shadow:0 0 0 2px #12081f,0 8px 18px #0008;pointer-events:auto;cursor:help;outline:none;z-index:4}
#rphud.rpq .rpnext:focus-visible{border-color:#ffd45a}
#rphud.rpq .rpnext .rpqnh{display:flex;align-items:center;gap:6px;height:14px;white-space:nowrap}
#rphud.rpq .rpnext .rpqnh small{font:800 10px var(--ui);letter-spacing:.12em;text-transform:uppercase;color:#c4badf}
#rphud.rpq .rpnext .rpqnh i{margin-left:auto;font:700 10.5px var(--ui);font-style:normal;color:#9f93c8}
#rphud.rpq .rpqboss{display:flex;align-items:center;gap:2px;padding:0 6px 0 3px;border-radius:7px;background:#4a1a1a;font:800 9.5px var(--ui);font-style:normal;color:#ffd45a;letter-spacing:.06em;text-transform:uppercase}
#rphud.rpq .rpnext .rpqms{display:flex;gap:4px;margin-top:2px;flex-wrap:nowrap;align-items:center}
#rphud.rpq .rpqm{display:flex;align-items:center;flex:0 0 auto;width:78px;height:32px;position:relative}
#rphud.rpq .rpqm img{width:32px;height:32px;flex:0 0 32px}
#rphud.rpq .rpqm b{font:800 13px var(--ui);color:#fff8e8;margin-left:1px}
#rphud.rpq .rpqm>i{display:flex;flex-direction:column;gap:0;margin-left:auto;margin-right:2px}
#rphud.rpq .rpqmore{font:800 12px var(--ui);color:#c4badf;margin-left:2px}
#rphud.rpq .rpqnc{position:absolute;right:-2px;bottom:calc(100% + 12px);width:330px;box-sizing:border-box;padding:10px 12px 10px;border-radius:16px;border:2px solid #7a5ac8;background:linear-gradient(180deg,#1e1650fc,#0c0824fd);
 box-shadow:0 0 0 2px #12081f,0 14px 28px #000b;opacity:0;transform:translateY(8px) scale(.97);transform-origin:90% 100%;pointer-events:none;transition:opacity .16s,transform .22s cubic-bezier(.34,1.56,.64,1);cursor:default}
#rphud.rpq .rpnext:hover .rpqnc,#rphud.rpq .rpnext.open .rpqnc,#rphud.rpq .rpnext:focus-visible .rpqnc{opacity:1;transform:none}
#rphud.rpq .rpqnc,#rphud.rpq .rpqnc *{letter-spacing:normal;text-transform:none;margin-left:0}
#rphud.rpq .rpqnc{display:block}
#rphud.rpq .rpqnc p b{font:inherit;color:inherit;margin:0}
#rphud.rpq .rpqnc p{display:flex;align-items:baseline;justify-content:space-between;margin:0 0 6px;font:400 22px/1 'Pirata One',Georgia,serif;color:#ffd45a}
#rphud.rpq .rpqnc p span{font:700 12px var(--ui);color:#c4badf}
#rphud.rpq .rpqnc ul{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:4px}
#rphud.rpq .rpqnc li{display:flex;align-items:center;gap:8px;padding:3px 8px 3px 3px;border-radius:11px;background:#ffffff0a}
#rphud.rpq .rpqnc li img{width:40px;height:40px;flex:0 0 40px}
#rphud.rpq .rpqnc li span{display:flex;flex-direction:column;align-items:flex-start;min-width:0;flex:1}
#rphud.rpq .rpqnc li b{font:800 13.5px var(--ui);color:#fff8e8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#rphud.rpq .rpqnc li em{display:flex;flex-wrap:wrap;gap:2px 8px;font-style:normal}
#rphud.rpq .rpqnc li em{margin-top:1px}#rphud.rpq .rpqnc li s{display:flex;align-items:center;gap:3px;text-decoration:none;font:700 11px var(--ui);color:#c4badf}
#rphud.rpq .rpqnc li>i{font:800 15px var(--ui);font-style:normal;color:#ffd45a}
#rphud.rpq .rpqnc>small{display:block;margin-top:7px;font:600 11.5px var(--ui);color:#9f93c8}
#rphud.rpq .rpgo{right:${RPQX.colR}px;bottom:14px;width:${RPQX.colW}px;height:62px;border-radius:8px 8px 20px 20px;padding:0 14px 0 9px;gap:10px}
#rphud.rpq .rpgo .rpgoi{width:44px;height:44px;flex:0 0 44px}
#rphud.rpq .rpgot b{font-size:20px;white-space:nowrap}#rphud.rpq .rpgo.run .rpgot b{font-size:18px}#rphud.rpq .rpgot small{white-space:nowrap}
#rphud.rpq .rpqb{margin-left:auto;padding:3px 9px 3px 8px;border-radius:11px;background:#3a1a04;color:#ffd45a;font:800 15px var(--ui);font-style:normal;white-space:nowrap;box-shadow:inset 0 0 0 2px #ffd45a55}
#rphud.rpq .rpqb[hidden]{display:none}
#rphud.rpq .rpgo.rpqc{background:linear-gradient(180deg,#3a2a8a,#1e1452);color:#fff8e8;box-shadow:0 0 0 3px #12081f,inset 0 0 0 2px #ffd45a,0 5px 0 #0a0620,0 12px 24px #0009}
#rphud.rpq .rpgo.rpqc .rpgoi{background:linear-gradient(180deg,#fff0a8,#ffd45a 45%,#e8a426)}
#rphud.rpq .rpgo.rpqc .rpqb{background:#ffd45a;color:#3a1a04;box-shadow:none}
#rphud.rpq .rpgo.rpqc:hover{transform:translateY(-3px)}
.rpqpop{position:absolute;right:18px;top:-6px;font:800 22px var(--ui);color:#ffd45a;-webkit-text-stroke:5px #12081f;paint-order:stroke fill;pointer-events:none;animation:rpqPop 1.05s cubic-bezier(.2,.8,.3,1) forwards}
@keyframes rpqPop{0%{opacity:0;transform:translateY(8px) scale(.7)}18%{opacity:1;transform:translateY(-10px) scale(1.12)}100%{opacity:0;transform:translateY(-58px) scale(1)}}
.rph .rpif .rpqif{display:flex;flex-direction:column;align-items:flex-start;gap:1px;line-height:1.2}
.rph .rpif .rpqdm{font:700 11.5px var(--ui);font-style:normal;color:#ffd45a;white-space:nowrap}
.rpres .rpqrow{display:flex;align-items:stretch;justify-content:center;gap:14px;max-width:100%}
.rpres .rpqrow .wrpay{margin:0!important;flex:1 1 auto;min-width:0}
.rpqmvp{flex:0 0 auto;text-align:left;display:flex;gap:10px;align-items:stretch;padding:6px 10px 6px 8px;border-radius:16px;border:2px solid #3a3070;background:linear-gradient(180deg,#1c1446,#0c0822);box-shadow:inset 0 1px 0 #ffffff14;min-width:0}
.rpqmv{display:flex;align-items:center;gap:6px;width:196px;flex:0 0 196px;min-width:0}
.rpqmvi{position:relative;width:64px;height:64px;flex:0 0 64px;border-radius:14px;background:radial-gradient(70% 60% at 50% 80%,var(--c),transparent 72%),#160f3e;box-shadow:0 0 0 2px #12081f,inset 0 0 0 2px #ffd45a}
.rpqmvi img{position:absolute;left:-2px;top:-10px;width:68px;height:68px}
.rpqmvt{display:flex;flex-direction:column;min-width:0;line-height:1.15}
.rpqmvt small{align-self:flex-start;padding:1px 7px;border-radius:7px;background:#ffd45a;color:#3a1a04;font:800 10px var(--ui);letter-spacing:.14em}
.rpqmvt b{font:400 20px/1.05 'Pirata One',Georgia,serif;color:#ffd45a;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:2px}
.rpqmvt em{font:600 11px var(--ui);font-style:normal;color:#c4badf}
.rpqbars{display:flex;flex-direction:column;flex:0 0 340px;width:340px}
.rpqbars>small{font:800 10px var(--ui);letter-spacing:.14em;text-transform:uppercase;color:#c4badf}.rpqbars>small b{color:#ffd45a;letter-spacing:.04em;margin-left:4px;text-transform:none}
.rpqbars ul{list-style:none;margin:2px 0 0;padding:0;display:flex;flex-direction:column;gap:1px}
.rpqbars li{display:grid;grid-template-columns:20px 146px 1fr 42px;align-items:center;gap:6px;height:17px}
.rpqbars li img{width:20px;height:20px}
.rpqbars li b{font:700 11.5px var(--ui);color:#fff8e8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.rpqbars li b small{color:#a99be0;font-size:10.5px}
.rpqbars li i{height:7px;border-radius:4px;background:#2a1f6a;overflow:hidden}
.rpqbars li s{display:block;height:100%;border-radius:4px;background:linear-gradient(90deg,var(--c),#ffd45a);transform-origin:left center;transform:scaleX(var(--f));animation:rpqBar .9s cubic-bezier(.2,.8,.2,1) var(--d,1s) backwards}
.rpqrm .rpqbars li s{animation:none}
@keyframes rpqBar{from{transform:scaleX(0)}}
.rpqbars li em{font:800 12px var(--ui);font-style:normal;color:#ffd45a;text-align:right}
.rpset2 .rpqset{margin-top:10px}.rpqsetw .rpqset{margin-top:0}.rpqsetw{margin-top:14px}
#rphud.rpq .rptut.at-go{bottom:150px}
#ov .rpcsl.rpqsfit .rpcsn{min-height:var(--rpqsn,62px);height:var(--rpqsn,62px);padding-top:1px;padding-bottom:1px;gap:10px}
#ov .rpcsl.rpqsfit .rpcsn img{width:calc(var(--rpqsn,62px) - 4px);height:calc(var(--rpqsn,62px) - 4px)}
#ov .rpcsl.rpqsfit .rpcsn b{font-size:14.5px;line-height:1.1}#ov .rpcsl.rpqsfit .rpcsn i{font-size:19px}
@media (prefers-reduced-motion:reduce){.rpqpop{animation:none;opacity:0}.rpqbars li s{animation:none}}`;document.head.appendChild(st)}
