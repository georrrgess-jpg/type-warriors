# python3 t_gtt105a.py [game.html] : The Great Turkey Trot art (99u3_gtt_art.js, prefix gttart): the twelve turkeys with jockeys at three sizes and
# in every pose, the baked run cycles, bake time, frame cost of gttDrawRace (normal and Performance mode) in a real gttRun replay with six runners,
# no shadowBlur / ctx.filter, nothing created per frame, the camera keeps the leader and the first three in shot, podium, photo finish, the tile SVG;
# and screenshots into shots/w105_gtt/ (contact sheet, race frames per going and weather, events, photo finish, podium, tile).
import asyncio,os,re,sys,json
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 and sys.argv[1].endswith('.html') else os.path.join(HERE,'out.html'))
SH=os.path.join(HERE,'shots','w105_gtt');os.makedirs(SH,exist_ok=True)
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:500]),flush=True)
    if not ok:FAIL.append(name)
IDS=['gravy','comet','gobbles','spice','willie','butter','maple','drum','annie','stuff','hank','duchess']
POSES=['run','fast','strut','stumble','pie','celeb','sad']
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.add_init_script("window.WCRELAYS=[];window.TWA_RELAYS=[]")
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E("()=>{RS_ASK=false;WCRELAYS=[];try{ST.perfAsked=1}catch(e){}try{PFW.asked=true}catch(e){}}")
        have=await E("()=>[typeof gttBake,typeof gttPortrait,typeof gttDrawTurkey,typeof gttDrawRace,typeof gttCam,typeof gttDrawPodium,typeof gttPhoto,typeof gttTile,typeof gttRun,typeof GTT_RUN]")
        chk('the art API and the sim/data it needs exist',have==['function']*8+['function','object'] or have[:8]==['function']*8 and have[8]=='function',have)
        # the harness page canvas (1600x900 logical)
        await E("()=>{const c=document.createElement('canvas');c.id='gtc';c.width=1600;c.height=900;c.style.cssText='position:fixed;left:0;top:0;z-index:99999';document.body.appendChild(c);window.GC=c.getContext('2d')}")
        # ---------------------------------------------------------------- bake
        r=await E("()=>{const t=performance.now();gttBake();const a=performance.now()-t;const t2=performance.now();gttBake();return [a,performance.now()-t2,GTTART.env.ms]}")
        print('  bake all (environment + 12 runners): %.0f ms, again %.1f ms, environment alone %.0f ms'%tuple(r))
        chk('gttBake bakes the environment and all twelve runners in well under a second, and again is free',r[0]<900 and r[1]<2,r)
        r=await E("()=>{const o=[];for(const id of ['gravy','duchess']){const t=performance.now();gttartRunner(id);o.push(performance.now()-t)}return o}")
        chk('a baked runner is cached (second request is free)',max(r)<2,r)
        # ---------------------------------------------------------------- portraits and run cycles
        r=await E("""()=>{const ids=%s,out={bad:[],hash:{}};const sizes=[[96,77],[120,96],[180,144]];
          for(const id of ids)for(const [w,h] of sizes){const cv=document.createElement('canvas');cv.width=w;cv.height=h;gttPortrait(cv,id,.4);const d=cv.getContext('2d').getImageData(0,0,w,h).data;let n=0,hh=0;
            for(let i=3;i<d.length;i+=4){if(d[i]>40)n++}for(let i=0;i<d.length;i+=97)hh=(hh*31+d[i])|0;
            if(n<w*h*.12||n>w*h*.9)out.bad.push([id,w,h,n]);(out.hash[w]=out.hash[w]||new Set()).add(hh)}
          return {bad:out.bad,distinct:Object.values(out.hash).map(s=>s.size)}}"""%json.dumps(IDS))
        chk('all 12 portraits draw (non-empty, not a solid fill) at 3 sizes and are all different from each other',not r['bad'] and r['distinct']==[12,12,12],r)
        r=await E("""()=>{const ids=%s,out=[],sc=[.5,1,1.6];for(const id of ids){const hs=new Set();for(const s of sc){for(let k=0;k<8;k++){const cv=document.createElement('canvas');cv.width=320;cv.height=260;const g=cv.getContext('2d');gttDrawTurkey(g,id,170,230,s,k/8,{lane:2});
            const d=g.getImageData(0,0,320,260).data;let n=0,hh=0;for(let i=3;i<d.length;i+=4)if(d[i]>40)n++;for(let i=0;i<d.length;i+=61)hh=(hh*31+d[i])|0;if(n<500)out.push([id,s,k,n]);if(s===1)hs.add(hh)}}
            if(hs.size<7)out.push([id,'cycle frames look the same',hs.size])}return out}"""%json.dumps(IDS))
        chk('every run cycle (8 frames per turkey, 3 scales) draws and the frames differ',r==[],r)
        r=await E("""()=>{const ids=%s,P=%s,out=[];for(const id of ids)for(const p of P){const cv=document.createElement('canvas');cv.width=320;cv.height=260;const g=cv.getContext('2d');gttDrawTurkey(g,id,170,230,1,.3,{pose:p});const d=g.getImageData(0,0,320,260).data;let n=0;for(let i=3;i<d.length;i+=4)if(d[i]>40)n++;if(n<3000)out.push([id,p,n])}return out}"""%(json.dumps(IDS),json.dumps(POSES)))
        chk('every pose (run, fast, strut, stumble, pie, celebrate, sad) of every turkey draws',r==[],r)
        r=await E("""()=>{const o={};for(const [k,ev] of [['stumble','stumble'],['burst','burst'],['pie','pie'],['kick','kick'],['mine',null]]){const cv=document.createElement('canvas');cv.width=320;cv.height=260;const g=cv.getContext('2d');gttDrawTurkey(g,'gravy',170,230,1,.3,{ev,mine:k==='mine',lane:0});const d=g.getImageData(0,0,320,260).data;let n=0,h=0;for(let i=3;i<d.length;i+=4)if(d[i]>40)n++;for(let i=0;i<d.length;i+=53)h=(h*31+d[i])|0;o[k]=[n,h]}
          return [new Set(Object.values(o).map(v=>v[1])).size,Object.values(o).every(v=>v[0]>3000)]}""")
        chk('the event poses (stumble, burst, pie, kick) and the gold ring each look different',r==[5,True],r)
        # ---------------------------------------------------------------- race frames over a real replay
        await E("""()=>{window.RUN=gttRun(gttCard(31),777);window.ST1=gttSimNew(RUN.card,777);return RUN.n}""")
        r=await E("""()=>{const st=RUN,ms=[],js=[],g=GC;const t0=st.t;const sim=gttSimNew(st.card,777);let cam=null;const fr=[];
          for(let n=0;n<st.n;n++){gttStep(sim);cam=gttCam(sim,cam);if(n>=150&&n<150+160){const a=performance.now();gttDrawRace(g,sim,cam,{t:n/30,mine:[0,3],going:sim.card.going,weather:sim.card.weather});const b=performance.now();g.getImageData(0,0,1,1);ms.push(performance.now()-a);js.push(b-a)}else if(n<150)gttDrawRace(g,sim,cam,{t:n/30,mine:[0],low:true})}
          const med=a=>{const s=a.slice().sort((x,y)=>x-y);return s[s.length>>1]};return [med(js),med(ms),Math.max(...ms),sim.n,sim.run.length]}""")
        print('  gttDrawRace, normal, six runners mid-race: JS %.2f ms, with raster %.2f ms (max %.1f)'%tuple(r[:3]))
        chk('gttDrawRace normal costs under 2 ms of script and under 14 ms with the (noisy, shared) software raster included',r[0]<2 and r[1]<14 and r[4]==6,r)
        r=await E("""()=>{const st=RUN,ms=[],js=[],g=GC;const sim=gttSimNew(st.card,777);let cam=null;
          for(let n=0;n<310;n++){gttStep(sim);cam=gttCam(sim,cam);if(n>=150){const a=performance.now();gttDrawRace(g,sim,cam,{t:n/30,mine:[0,3],low:true,going:sim.card.going,weather:sim.card.weather});const b=performance.now();g.getImageData(0,0,1,1);ms.push(performance.now()-a);js.push(b-a)}}
          const med=a=>{const s=a.slice().sort((x,y)=>x-y);return s[s.length>>1]};return [med(js),med(ms),Math.max(...ms)]}""")
        print('  gttDrawRace, Performance mode (low): JS %.2f ms, with raster %.2f ms (max %.1f)'%tuple(r))
        chk('gttDrawRace in Performance mode costs under 1 ms of script and under 10 ms with the raster',r[0]<1 and r[1]<10,r)
        r=await E("""()=>{const st=RUN,g=GC,sim=gttSimNew(st.card,777);let cam=null,cnt=0;const o=document.createElement.bind(document);document.createElement=function(t){if(String(t).toLowerCase()==='canvas')cnt++;return o(t)};
          const oc=window.OffscreenCanvas;let oc2=0;if(oc){window.OffscreenCanvas=function(){oc2++;return new oc(...arguments)}}
          for(let n=0;n<160;n++){gttStep(sim);cam=gttCam(sim,cam);gttDrawRace(g,sim,cam,{t:n/30,mine:[1],low:false})}
          const c0=cnt;for(let n=160;n<460;n++){gttStep(sim);cam=gttCam(sim,cam);gttDrawRace(g,sim,cam,{t:n/30,mine:[1],low:n%2==0})}
          const c1=cnt-c0;document.createElement=o;if(oc)window.OffscreenCanvas=oc;return [c1,oc2,sim.n]}""")
        chk('no canvas is created per frame (300 frames of a real race, zoom changes included)',r[0]==0 and r[1]==0,r)
        src=open(os.path.join(HERE,'99u3_gtt_art.js')).read()
        code=re.sub(r'/\*.*?\*/','',src,flags=re.S)
        chk('the module has no shadowBlur, no ctx.filter, no backdrop-filter and no soft-light / screen blend',not re.search(r'shadowBlur|\.filter\s*=|backdrop-filter|[\'"](soft-light|screen)[\'"]',code),re.findall(r'shadowBlur|\.filter\s*=|backdrop-filter',code))
        chk('no model ids in the module',not re.search(r'claude-|opus|sonnet|haiku',code,re.I),'')
        names=re.findall(r'^(?:const|let|class|function)\s+([A-Za-z0-9_$]+)',src,re.M)
        pub={'gttBake','gttPortrait','gttDrawTurkey','gttDrawRace','gttCam','gttDrawPodium','gttPhoto','gttTile'}
        bad=[n for n in names if not (n.startswith('gttart') or n.startswith('GTTART') or n in pub)]
        chk('top-level names are gttart* / GTTART* or the public API',not bad,bad)
        # name clashes with the rest of the build
        allsrc=''
        for f in os.listdir(HERE):
            if f.endswith('.js') and f not in('99u3_gtt_art.js',) and re.match(r'^\d',f):allsrc+=open(os.path.join(HERE,f)).read()
        clash=[n for n in names if re.search(r'^(?:const|let|class|function)\s+'+re.escape(n)+r'\b',allsrc,re.M)]
        chk('no top-level name clashes with any other module',not clash,clash)
        # camera
        r=await E("""()=>{const st=RUN,sim=gttSimNew(st.card,777);let cam=null,worst=0,lost=0,lost3=0,zmin=9,zEarly=0;const len=1000;
          for(let n=0;n<st.n+40;n++){gttStep(sim);cam=gttCam(sim,cam);const sx=m=>800+(m-cam.x)*GTTART.PXM*cam.zoom;const xs=sim.run.map(r=>gttartXd(sim,r)).sort((a,b)=>b-a);
            if(sx(xs[0])<40||sx(xs[0])>1560)lost++;const last=xs[0]/len>.85;if(last&&(sx(xs[2])<20||sx(xs[0])>1580))lost3++;zmin=Math.min(zmin,cam.zoom);if(xs[0]/len<.5)zEarly=Math.max(zEarly,1-cam.zoom)}
          return [lost,lost3,+zmin.toFixed(3),+zEarly.toFixed(3),sim.n]}""")
        chk('the camera never loses the leader, keeps the first three in shot in the last 15%, and zooms out only a little',r[0]==0 and r[1]==0 and r[2]>=.69,r)
        r=await E("""()=>{let a=gttCam(RUN,null),b=gttCam(RUN,{x:a.x-50,zoom:1,t:RUN.t-.5});return [a.zoom>=.69&&a.zoom<=1,Math.abs(b.x-a.x)<50&&b.x<a.x+1e-6===false||b.x>a.x-50]}""")
        chk('camera easing returns a number camera ({x,zoom})',r[0],r)
        # podium and photo
        r=await E("""()=>{const g=GC;g.clearRect(0,0,1600,900);g.fillStyle='#3a2a68';g.fillRect(0,0,1600,900);const s=RUN;gttDrawPodium(g,s,3);const d=g.getImageData(300,300,1000,480).data;let n=0;for(let i=0;i<d.length;i+=4)if(d[i]!==0x3a||d[i+1]!==0x2a)n++;
          const c1=g.getImageData(0,0,1600,900).data.slice(0);g.fillRect(0,0,1600,900);gttDrawPodium(g,s,.1);const c2=g.getImageData(0,0,1600,900).data;let df=0;for(let i=0;i<c1.length;i+=40)if(c1[i]!==c2[i])df++;return [n,df]}""")
        chk('the podium draws top three turkeys with jockeys and animates in',r[0]>30000 and r[1]>3000,r)
        r=await E("""()=>{const g=GC,s=Object.assign({},RUN);s.photo={a:RUN.order[0],b:RUN.order[1],gap:.2};const px=t=>{g.fillStyle='#1a1030';g.fillRect(0,0,1600,900);gttPhoto(g,t,s);const d=g.getImageData(300,210,1000,470).data;let sum=0,sat=0;for(let i=0;i<d.length;i+=4){sum+=d[i]+d[i+1]+d[i+2]}return sum/(d.length/4)/3};
          const a=px(.05),b=px(1.2),c=px(2.6);const t0=performance.now();for(let i=0;i<30;i++)gttPhoto(g,2.6,s);return [a,b,c,(performance.now()-t0)/30]}""")
        chk('the photo finish develops over 2.5 s (the picture fades in) and a frame is cheap',abs(r[0]-r[1])>1 and abs(r[1]-r[2])>1 and r[3]<3,r)
        r=await E("""()=>{const t=gttTile();const d=new DOMParser().parseFromString(TA.gtt,'image/svg+xml');return [t===TA.gtt,d.querySelector('parsererror')===null,d.documentElement.tagName,(TA.gtt.match(/<path/g)||[]).length>20,TA.gtt.length]}""")
        chk('TA.gtt is a valid SVG string (viewBox 320x176 like TA.pk)',r[0] and r[1] and r[2]=='svg' and r[3] and 'viewBox="0 0 320 176"' in await E("()=>TA.gtt"),r)
        # all goings and weathers draw
        r=await E("""()=>{const g=GC,out=[];for(const going of['firm','good','muddy'])for(const w of['clear','wind','drizzle']){const sim=gttSimNew(Object.assign({},RUN.card,{going,weather:w}),5);let cam=null;for(let n=0;n<60;n++){gttStep(sim);cam=gttCam(sim,cam);gttDrawRace(g,sim,cam,{t:n/30,mine:[2]})}
            const d=g.getImageData(0,0,1600,900).data;let h=0;for(let i=0;i<d.length;i+=997)h=(h*31+d[i])|0;out.push(h)}return [new Set(out).size,out.length]}""")
        chk('firm / good / muddy and clear / wind / drizzle all render and look different',r==[9,9],r)
        await E("""()=>{window.FINDEV=(kind,over,seed0,maxSeeds)=>{for(let sd=seed0;sd<seed0+(maxSeeds||60);sd++){const card=Object.assign({},gttCard(31),over||{}),sim=gttSimNew(card,sd);let hit=-1,lane=-1;
            for(let n=0;n<900&&!sim.done;n++){gttStep(sim);for(const r of sim.run){if(r.ev&&r.ev.k===kind&&r.ev.t0>=sim.t-.04&&sim.t>2.5&&sim.t<16){hit=n;lane=r.lane;break}}if(hit>=0)break}
            if(hit>=0)return {seed:sd,card,hit,lane}}return null};
          window.EVFRAME=(f,after)=>{const sim=gttSimNew(f.card,f.seed);let cam=null;GTTART.lt=-1;for(let n=0;n<f.hit+after;n++){gttStep(sim);cam=gttCam(sim,cam);if(n>f.hit+after-70)gttDrawRace(GC,sim,cam,{t:n/30,mine:[f.lane===1?2:1,4],going:f.card.going,weather:f.card.weather})}return sim}}""")
        # events draw without errors and change the picture
        r=await E("""()=>{const out={},found={};for(const k of['stumble','burst','pie','kick','gust']){const f=FINDEV(k,{going:'good',weather:'clear'},3,80);if(!f){found[k]=false;continue}found[k]=[f.seed,f.hit,f.lane];
            EVFRAME(f,14);const d=GC.getImageData(0,0,1600,900).data;let h=0;for(let i=0;i<d.length;i+=991)h=(h*31+d[i])|0;
            const g2=EVFRAME(Object.assign({},f,{hit:f.hit-60}),0);const d2=GC.getImageData(0,0,1600,900).data;let h2=0;for(let i=0;i<d2.length;i+=991)h2=(h2*31+d2[i])|0;out[k]=h!==h2}
          return [found,out]}""")
        chk('every race event (stumble, burst, pie, kick, gust) draws and changes the frame',all(r[0].values()) and all(r[1].values()) and len(r[1])==5,r)
        chk('no page errors',not er,er)
        # ---------------------------------------------------------------- screenshots
        # contact sheet 1x and 2x
        await E("""()=>{const g=GC;g.fillStyle='#2d1b57';g.fillRect(0,0,1600,900);const ids=@IDS@;ids.forEach((id,i)=>{const x=140+(i%6)*260,y=250+Math.floor(i/6)*330;g.fillStyle='#ffffff12';g.beginPath();g.roundRect(x-122,y-190,246,230,14);g.fill();gttDrawTurkey(g,id,x,y,1,i*.11,{lane:i%6});g.fillStyle='#ffd45a';g.font='600 15px Poppins';g.textAlign='center';g.fillText(GTT_RUN.find(r=>r.id===id).n,x,y+24)})}""".replace("@IDS@",json.dumps(IDS)))
        await pg.screenshot(path=os.path.join(SH,'contact_1x.png'))
        await E("""()=>{const g=GC;g.fillStyle='#2d1b57';g.fillRect(0,0,1600,900);const ids=@IDS@.slice(0,8);ids.forEach((id,i)=>{const x=210+(i%4)*390,y=330+Math.floor(i/4)*420;gttDrawTurkey(g,id,x,y,1.85,i*.11,{lane:i%6})})}""".replace("@IDS@",json.dumps(IDS)))
        await pg.screenshot(path=os.path.join(SH,'contact_2x_a.png'))
        await E("""()=>{const g=GC;g.fillStyle='#2d1b57';g.fillRect(0,0,1600,900);const ids=@IDS@.slice(8);ids.forEach((id,i)=>{const x=210+(i%4)*390,y=330+Math.floor(i/4)*420;gttDrawTurkey(g,id,x,y,1.85,i*.11,{lane:i%6})})}""".replace("@IDS@",json.dumps(IDS)))
        await pg.screenshot(path=os.path.join(SH,'contact_2x_b.png'))
        # poses sheet
        await E("""()=>{const g=GC;g.fillStyle='#2d1b57';g.fillRect(0,0,1600,900);let n=0;for(const [p,k] of [['run',8],['fast',6],['strut',4],['stumble',2],['pie',2],['celeb',4],['sad',2]])for(let i=0;i<k;i++){const x=110+(n%8)*195,y=170+Math.floor(n/8)*170;gttDrawTurkey(g,'comet',x,y,.95,i/k+.001,{pose:p,lane:1});n++}}""")
        await pg.screenshot(path=os.path.join(SH,'poses.png'))
        # race frames
        scen=[('gate','good','clear',2),('mid_clear_firm','firm','clear',420),('mid_muddy_drizzle','muddy','drizzle',420),('last_stretch','good','clear',640)]
        for name,going,wx,steps in scen:
            await E("""([going,wx,steps])=>{const g=GC,card=Object.assign({},gttCard(31),{going,weather:wx}),sim=gttSimNew(card,4242);let cam=null;GTTART.lt=-1;
              for(let n=0;n<steps;n++){gttStep(sim);cam=gttCam(sim,cam);if(n>steps-60)gttDrawRace(g,sim,cam,{t:n/30,mine:[1,4],going,weather:wx})}}""",[going,wx,steps])
            await pg.screenshot(path=os.path.join(SH,'race_'+name+'.png'))
        for k,going,wx in [('stumble','good','clear'),('burst','firm','clear'),('pie','good','wind'),('kick','muddy','drizzle'),('gust','good','wind')]:
            f=await E("([k,g,w])=>{const f=FINDEV(k,{going:g,weather:w},3,120);window.FF=f;if(f)EVFRAME(f,%d);return f&&[f.seed,f.hit,f.lane]}"%(12 if k!='gust' else 24),[k,going,wx])
            await pg.screenshot(path=os.path.join(SH,'race_event_'+k+'.png'))
        # photo finish and podium
        await E("""()=>{const g=GC;const s=Object.assign({},RUN);s.photo={a:RUN.order[0],b:RUN.order[1],gap:.2};g.fillStyle='#2a1850';g.fillRect(0,0,1600,900);gttPhoto(g,3,s)}""")
        await pg.screenshot(path=os.path.join(SH,'photo_finish.png'))
        await E("""()=>{const g=GC;const s=Object.assign({},RUN);s.photo={a:RUN.order[0],b:RUN.order[1],gap:.2};g.fillStyle='#2a1850';g.fillRect(0,0,1600,900);gttPhoto(g,1.1,s)}""")
        await pg.screenshot(path=os.path.join(SH,'photo_developing.png'))
        await E("""()=>{const g=GC;g.fillStyle='#3a2a68';g.fillRect(0,0,1600,900);gttDrawPodium(g,RUN,3)}""")
        await pg.screenshot(path=os.path.join(SH,'podium.png'))
        await E("""()=>{document.getElementById('gtc').remove();const d=document.createElement('div');d.id='gtt';d.style.cssText='position:fixed;left:0;top:0;width:1600px;height:900px;z-index:100000;background:#241638;padding:24px';d.innerHTML='<div style="width:960px;height:528px;overflow:hidden;border-radius:16px;border:3px solid #12081f">'+TA.gtt+'</div><div style="width:320px;height:176px;margin-top:24px;overflow:hidden;border-radius:12px;border:2px solid #12081f">'+TA.gtt+'</div>';document.body.appendChild(d)}""")
        await pg.screenshot(path=os.path.join(SH,'tile.png'))
        await b.close()
    print('\n%d checks, %d failed'%(N[0],len(FAIL)));
    if FAIL:print('FAILED:',FAIL);sys.exit(1)
asyncio.run(main())
