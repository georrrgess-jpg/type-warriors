/* ---------- gear abilities ----------
   Abilities are special powers carried by a piece of gear, on top of its stats. The first is Soul Harvest, on the Reaper's Shroud
   (Mythic armor) and the Soulreaper (Mythic weapon). Wearing one gives the ability; wearing both is a set and makes it stronger. */
const GAB={harvest:{n:'Soul Harvest',c:'#5affb0',
 d:"Every flawless kill (no slips) reaps a soul. At 13 souls the Reaper's Toll rings: a spectral scythe sweeps the field and reaps every monster on it. Bosses are spared but lose their minions and projectiles, and their sentence timer refills. Each Toll also grants 1 shield.",
 set:"Set bonus: wear the Reaper's Shroud and the Soulreaper together and the Toll needs only 9 souls and also restores 1 health."},
 pcurse:{n:'Pumpkin Curse',c:'#ff8a22',
 d:"Soul Harvest, but haunted. Every flawless kill (no slips) feeds the pumpkin a soul with an ominous toll. At 10 souls the Pumpkin's Curse is unleashed: a giant blazing jack-o'-lantern rampages across the field and eviscerates every monster on it. Bosses are spared but lose their minions and projectiles, and their sentence timer refills. Each Curse also grants 1 shield.",
 set:"Set bonus: wear the Pumpkin Reaper and the Soulreaper together and the Curse needs only 8 souls and also restores 1 health."}};
AR.hwreap.ab='harvest';WP.hw_scythe.ab='harvest';
AR.hwpreap.ab='pcurse';AR.hwpreap.d=AR.hwpreap.d.replace('Ability: Soul Harvest','Ability: Pumpkin Curse');
AR.hwreap.d+='. Ability: Soul Harvest';WP.hw_scythe.d+='. Ability: Soul Harvest';
const gabCount=(k,arm,wp)=>(AR[arm]&&AR[arm].ab===k?1:0)+(WP[wp]&&WP[wp].ab===k?1:0);
function gabHTML(it){const a=it&&GAB[it.ab];if(!a)return'';const both=it.ab==='pcurse'?(AR[P.armor]&&AR[P.armor].ab==='pcurse'&&WP[P.weapon]&&WP[P.weapon].ab==='harvest'):gabCount(it.ab,P.armor,P.weapon)===2;
 return `<div class="gab" style="--c:${a.c}"><b><i>✦</i>Ability: ${a.n}</b><span>${a.d}</span><em class="${both?'on':''}">${a.set}${both?' <u>Active</u>':''}</em></div>`}
const SOUL=()=>S.pkc?(S.hvN>=2?8:10):(S.hvN>=2?9:13);
const PKC=()=>S.pkc?'#ff8a22':'#5affb0',PKL=()=>S.pkc?'#ffa040':'#c8fff0',PKW=()=>S.pkc?'#ffcf8a':'#e8fff4';
/* run start: count the equipped pieces once (the snapshot keeps it for resumed runs) */
{const st0=start;start=function(){const r=st0.apply(this,arguments);/* the Pumpkin Reaper armor always brings the Pumpkin Curse, even paired with the Soulreaper; every other harvest gear swings the scythe */S.pkc=!S.prac&&!!(AR[P.armor]&&AR[P.armor].ab==='pcurse');S.hvN=S.prac?0:gabCount('harvest',P.armor,S.wpn||P.weapon)+(AR[P.armor]&&AR[P.armor].ab==='pcurse'?1:0);S.soul=0;S.toll=null;S.sorb=[];return r}}
/* the soul-filling sound, ominous edition: a cracked funeral bell with a tritone beating against it, a low coffin-lid groan, a dead heartbeat
   and a hollow moan. Each soul climbs a dark diminished-flavoured scale; the last few swell with a low choir and a double heartbeat. */
const SOUL_SCALE=[0,1,3,6,7,8,11,12,13,15,18,19,20];
function soulTone(n){if(S.pkc)return pkTone(n);if(!axOn())return;try{const t=ac.currentTime+.01,k=Math.min(SOUL_SCALE.length-1,Math.max(0,n-1)),deg=SOUL_SCALE[k],full=n>=SOUL()-3,f=nf(36+Math.min(deg,12));
 cBell(sg,t,f,.07,3.4);cBell(sg,t+.02,f*1.4142,.034,2.6);cTone(sg,t,f*.5,2.2,'sine',.07,{a:.03});
 cTone(sg,t,78,.42,'sine',.1,{f2:34,a:.004});
 cNoise(sg,t+.04,.8,.05,{type:'bandpass',f1:420,f2:150,q:9,a:.1});
 hxGhost(sg,t+.08,1.1,nf(47+deg%12),.04+n*.0016);
 cNoise(sg,t+.2,.6,.018,{type:'bandpass',f1:3200,f2:1300,q:4,a:.2});
 if(full){cTone(sg,t+.3,70,.4,'sine',.09,{f2:32,a:.004});cChoir(sg,t+.1,nf(41+deg%12),1.5,.014)}}catch(e){}}
/* the Pumpkin Curse sound: a creaking coffin-door glide, a hollow wooden knock, a tritone organ moan and a far-off owl; the last souls add a low witchy choir */
const PK_SCALE=[0,1,3,6,8,11,13,15,18,20];
function pkTone(n){if(!axOn())return;try{const t=ac.currentTime+.01,k=Math.min(PK_SCALE.length-1,Math.max(0,n-1)),deg=PK_SCALE[k],full=n>=SOUL()-2,f=nf(40+Math.min(deg,12));
 cTone(sg,t,f*.5,1.9,'sawtooth',.045,{a:.12});cTone(sg,t,f*.5*1.4142,1.6,'triangle',.04,{a:.18});
 cTone(sg,t,210+deg*6,.5,'sawtooth',.05,{f2:96+deg*2,a:.05});cTone(sg,t+.04,214+deg*6,.5,'square',.018,{f2:90+deg*2,a:.05});
 cTone(sg,t,150,.18,'sine',.16,{f2:52,a:.004});cNoise(sg,t,.12,.06,{type:'bandpass',f1:900,f2:300,q:5,a:.004});
 cTone(sg,t+.32,nf(76+deg%7),.9,'sine',.05,{f2:nf(72+deg%7),a:.12});
 cBell(sg,t+.05,f*1.5,.03,2.6);
 if(full){cChoir(sg,t+.08,nf(38+deg%12),1.6,.016);cTone(sg,t+.3,68,.4,'sine',.1,{f2:30,a:.004})}}catch(e){}}
function soulAdd(e){S.sp=1;S.soul=(S.soul||0)+1;(S.sorb||(S.sorb=[])).push({x:e.x,y:e.y-e.h*.6,t:0});soulTone(S.soul);if(S.soul>=SOUL()){S.soul=0;reaperToll()}}
function reaperToll(){S.toll={t:0,x:KX+40,done:new Set()};S.shield=Math.min(8,S.shield+1);if(S.hvN>=2&&S.hp<S.max)S.hp++;
 float(W/2,250,S.pkc?"PUMPKIN'S CURSE":"REAPER'S TOLL",PKC(),64);float(KX+60,GY-300,S.hvN>=2&&S.hp<=S.max?'+1 shield  +1 HP':'+1 shield','#7fd8ff',32);S.flash=Math.max(S.flash,.3);S.shake=Math.max(S.shake,14);S.pj=[];
 for(const e of S.en)if(e.boss&&e.tmax){e.tm=e.tmax;float(e.x-40,GY-e.h-60,'Timer restored',PKC(),30)}
if(S.pkc&&axOn()){try{const t=ac.currentTime+.02;hxToll(sg,t,nf(39),.14);cTone(sg,t,330,1.4,'sawtooth',.07,{f2:70,a:.02});cTone(sg,t+.05,340,1.3,'square',.03,{f2:66,a:.02});cNoise(sg,t+.02,1.1,.1,{type:'bandpass',f1:3000,f2:300,q:3,a:.05});hxSwish(sg,t+.12,.2);cChoir(sg,t+.1,nf(51),1.8,.022);cChoir(sg,t+.1,nf(58),1.8,.016);cTone(sg,t+.6,nf(84),.7,'sine',.05,{f2:nf(78),a:.1})}catch(e){}}
 else if(axOn()){try{const t=ac.currentTime+.02;hxToll(sg,t,nf(45),.12);hxSwish(sg,t+.1,.2);hxGhost(sg,t+.15,1.2,460,.04);cChoir(sg,t+.1,nf(62),1.6,.02);cChoir(sg,t+.1,nf(69),1.6,.016)}catch(e){}}}
/* flawless kills feed the harvest */
{const k0=kill;kill=function(e,force){const ok=S.hvN>0&&!force&&!e.boss&&!e.bad&&S.mode==='play',inList=S.en.includes(e);const r=k0(e,force);if(ok&&inList&&!S.en.includes(e))soulAdd(e);return r}}
/* the sweep: reaps each monster as the blade passes it */
{const u0=update;update=function(dt){u0(dt);if(S.mode!=='play')return;
  S.sp=Math.max(0,(S.sp||0)-dt*1.2);for(const o of S.sorb||[])o.t+=dt*.84;if(S.sorb)S.sorb=S.sorb.filter(o=>o.t<1);
  const T=S.toll;if(!T)return;T.t+=dt*.525;T.x=lerp(KX+40,W+120,sstep(0,1,Math.min(1,T.t/.75)));
  S.inChain=1;try{for(const e of [...S.en]){if(e.boss||T.done.has(e)||e.x>T.x||e.x>W-10)continue;T.done.add(e);burst(e.x,e.y-e.h*.5,PKC(),22,{v:380});if(S.pkc){burst(e.x,e.y-e.h*.5,'#ffd070',12,{v:300});burst(e.x,e.y-e.h*.4,'#ff4a10',10,{v:240})}kill(e,true)}}finally{S.inChain=0}
  if(T.t>1.3)S.toll=null}}
{const dw0=drawWorld;drawWorld=function(){dw0();const T=S.toll;if(!T)return;const c=ctx,a=Math.min(1,T.t*6)*(T.t>.9?Math.max(0,1-(T.t-.9)/.4):1);
  c.save();c.globalCompositeOperation='lighter';const g=c.createLinearGradient(T.x-300,0,T.x+110,0);g.addColorStop(0,PKC()+'00');g.addColorStop(.7,PKC()+hxA(.3*a));g.addColorStop(.86,PKW()+hxA(.55*a));g.addColorStop(1,PKW()+'00');c.fillStyle=g;c.fillRect(T.x-300,0,410,H);
  if(S.pkc){c.restore();const k=sstep(0,1,Math.min(1,T.t/.75)),cx=T.x-30,cy=GY-215+Math.sin(T.t*16)*12,r=128+14*Math.sin(T.t*20);
   c.save();c.globalAlpha=a;c.globalCompositeOperation='lighter';glow(c,cx,cy,r*3.3,'#ff7a10'+hxA(.55));glow(c,cx,cy,r*2,'#ffc050'+hxA(.45));c.restore();
   c.save();c.globalAlpha=a;c.translate(cx,cy);c.rotate(Math.sin(T.t*12)*.1+k*.35);c.translate(-cx,-cy);hwPumpkin(c,cx,cy,r,S.t,{});
   c.globalCompositeOperation='lighter';glow(c,cx,cy+r*.12,r*1.1,'#ffb030'+hxA(.5));c.restore();
   c.save();c.globalCompositeOperation='lighter';c.globalAlpha=a;for(let i=0;i<14;i++){const u=(S.t*1.6+i*.37)%1,ex=cx-r*.6-u*320,ey=cy+(Math.sin(i*5.1+S.t*6))*r*.8;glow(c,ex,ey,26*(1-u)+6,'#ff7a1a'+hxA(.7*(1-u)))}c.restore();return}
  c.translate(T.x,GY-260);c.rotate(-.35+sstep(0,1,Math.min(1,T.t/.75))*.7);c.globalAlpha=a;c.fillStyle=PKL();c.shadowColor=PKC();c.shadowBlur=40;c.beginPath();c.moveTo(0,-330);c.quadraticCurveTo(-240,-200,-200,240);c.quadraticCurveTo(-130,-120,30,-320);c.closePath();c.fill();
  c.strokeStyle='#2a1c12';c.lineWidth=12;c.shadowBlur=0;c.globalCompositeOperation='source-over';c.globalAlpha=a*.85;c.beginPath();c.moveTo(14,-330);c.lineTo(110,420);c.stroke();c.restore()}}
/* HUD gauge, bottom left above the Pause button */
{const dh0=drawHUD;drawHUD=function(){dh0();if(!S.hvN||S.mode==='title')return;const c=ctx,n=SOUL(),x0=20,y0=772,full=S.soul/n;c.save();
  c.fillStyle='rgba(6,4,16,.62)';c.beginPath();c.roundRect(x0-6,y0-22,Math.max(250,n*22+20),56,12);c.fill();c.strokeStyle=PKC()+hxA(.35+full*.5);c.lineWidth=1.5;c.stroke();
  c.font='18px "Pirata One",Georgia,serif';c.textAlign='left';c.textBaseline='middle';c.fillStyle=PKC();c.fillText((S.pkc?(S.hvN>=2?'Pumpkin Curse (set)':'Pumpkin Curse'):(S.hvN>=2?"Soul Harvest (set)":'Soul Harvest'))+'  '+S.soul+' / '+n,x0+4,y0-6);
  for(let i=0;i<n;i++){const px=x0+12+i*22,py=y0+16,on=i<S.soul,pop=on&&i===S.soul-1?(S.sp||0):0,rr=6+3.5*pop;if(on){glow(c,px,py,14+10*pop,PKC()+'aa')}c.fillStyle=on?PKL():'#ffffff22';c.beginPath();c.arc(px,py-1,rr,0,TAU);c.fill();c.fillRect(px-4,py+2,8,4);if(on){c.fillStyle=S.pkc?'#2a0c00':'#062018';c.fillRect(px-3,py-2,2,2);c.fillRect(px+1,py-2,2,2)}}
  c.globalCompositeOperation='lighter';for(const o of S.sorb||[]){const tx=x0+12+Math.min(n-1,S.soul)*22,ty=y0+16;for(let k=4;k>=0;k--){const uu=sstep(0,1,Math.max(0,o.t-k*.05)),x=lerp(o.x,tx,uu),y=lerp(o.y,ty,uu)-Math.sin(uu*Math.PI)*120,f=1-k*.18;glow(c,x,y,22*f,PKC()+hxA(.8*f*Math.sin(Math.min(1,o.t*1.5)*Math.PI*.5)));if(!k){c.fillStyle=PKW();c.beginPath();c.arc(x,y,4,0,TAU);c.fill()}}}
  c.restore()}}
RS_SKIP.add('toll');RS_SKIP.add('sorb');
