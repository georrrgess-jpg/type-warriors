/* ===== 10.6 THE CROOKED CUE: Cathedral Glass and Aurora Opal (97b8, prefix pzb8, after 97b6) =====
   Two premium ball sets for the shared painter of 97b6 (pzb3Reg: a palette and a small per-pixel material).
   - Cathedral Glass (20,000): stained glass. Solids are a leaded mosaic of glass cells (a fixed Voronoi on the sphere, looked up through a
     24x24x24 voxel table (only the shell the sphere passes through is filled) built on first use, so a pixel only tests the 4 or 5 seeds that can be its nearest) in the ball's colour: each
     cell has its own shade, tint and glow, brighter in the middle and lit from behind, dark thin lead lines between the cells and a
     bright bevel on one edge of each cell. Stripes: frosted white glass caps (pale cells, soft pewter lead lines) and the coloured
     mosaic band between them, a lead line on the band's border. The 8: black smoked glass in a gold-leaded diamond lattice with a white
     disc in a gold ring. Number discs: cream glass with dark numbers.
   - Aurora Opal (50,000): precious opal. A milky body strongly tinted in the ball's colour (the body colour always wins) with play-of-colour
     flashes: broad patches of green / magenta / orange / blue fire whose hue depends on the ball-local position AND the view normal, so
     they slide as the ball rolls, and in places a harlequin patchwork of small angular fire cells. Stripes: white opal caps with faint
     pastel flashes and the coloured opal band with a fire line on its border. The 8: black opal with small vivid flashes of fire, a white
     disc in a rainbow-tinted ring. Number discs: pale opal with dark numbers.
   The pattern lives in the ball-local normal, so it rolls with the ball. No allocation in mat(); a sine table, a fire-hue table, packed seed data and per-ball values hoisted into pal.prep keep it cheap. */
/* the tables live in one object; each material is built by a factory that captures them in closure constants (fastest to read per pixel) */
/* built on first use (the first paint of a Cathedral Glass ball), not at load, so players who never open the set pay nothing */
let PZB8=null,pzb8CathF=null;
const pzb8Build=()=>{
/* ---------- a fixed Voronoi of PZB8.N seeds on the unit sphere, with a voxel lookup of the candidate seeds ---------- */
const N=120,sx=new Float32Array(N),sy=new Float32Array(N),sz=new Float32Array(N);let s0=20261112;const rnd=()=>{s0=(Math.imul(s0,1664525)+1013904223)|0;return ((s0>>>8)&0xffff)/65536};
 /* Fibonacci sphere with a jitter, then a few repulsion passes so the cells come out even (no slivers, no giants) */
 for(let i=0;i<N;i++){const y=1-2*(i+.5)/N,r=Math.sqrt(1-y*y),a=i*2.399963+rnd()*.5;sx[i]=Math.cos(a)*r;sy[i]=y;sz[i]=Math.sin(a)*r}
 for(let it=0;it<14;it++){for(let i=0;i<N;i++){let fx=0,fy=0,fz=0;for(let j=0;j<N;j++){if(j===i)continue;const dx=sx[i]-sx[j],dy=sy[i]-sy[j],dz=sz[i]-sz[j],d2=dx*dx+dy*dy+dz*dz;if(d2<.16){const w=(.16-d2)/(d2+.02);fx+=dx*w;fy+=dy*w;fz+=dz*w}}
   let x=sx[i]+fx*.03,y=sy[i]+fy*.03,z=sz[i]+fz*.03;const l=1/Math.sqrt(x*x+y*y+z*z);sx[i]=x*l;sy[i]=y*l;sz[i]=z*l}}
 const ux=new Float32Array(N),uy=new Float32Array(N),uz=new Float32Array(N),us=new Float32Array(N);
 for(let i=0;i<N;i++){let a=rnd()*2-1,b=rnd()*2-1,c=rnd()*2-1;const l=1/Math.sqrt(a*a+b*b+c*c+1e-6);a*=l;b*=l;c*=l;ux[i]=a;uy[i]=b;uz[i]=c;us[i]=a*sx[i]+b*sy[i]+c*sz[i]}
 const GN=24,vs=2/GN,r2=vs*.8660254*2,off=new Int32Array(GN*GN*GN+1),tmp=[],DS=new Float64Array(N);
 for(let ix=0;ix<GN;ix++)for(let iy=0;iy<GN;iy++)for(let iz=0;iz<GN;iz++){const cx=-1+(ix+.5)*vs,cy=-1+(iy+.5)*vs,cz=-1+(iz+.5)*vs,g=(ix*GN+iy)*GN+iz;off[g]=tmp.length;
  const cr=Math.sqrt(cx*cx+cy*cy+cz*cz);if(cr<1-vs*.8660254-.03||cr>1+vs*.8660254+.03)continue;/* only the shell of voxels the sphere passes through */
  let d1=9,d2=9;for(let i=0;i<N;i++){const dx=cx-sx[i],dy=cy-sy[i],dz=cz-sz[i],d=dx*dx+dy*dy+dz*dz;DS[i]=d;if(d<d1){d2=d1;d1=d}else if(d<d2)d2=d}
  const th=Math.sqrt(d2)+r2,th2=th*th;for(let i=0;i<N;i++)if(DS[i]<=th2)tmp.push(i)}
 off[GN*GN*GN]=tmp.length;
 const SP=new Float32Array(N*4),UP=new Float32Array(N*4);for(let i=0;i<N;i++){SP[i*4]=sx[i];SP[i*4+1]=sy[i];SP[i*4+2]=sz[i];UP[i*4]=ux[i];UP[i*4+1]=uy[i];UP[i*4+2]=uz[i];UP[i*4+3]=us[i]}
 return {N,SP,UP,off,lst:Int16Array.from(tmp),n:1,V:new Float64Array(8),K:new Float32Array(N),T:new Float32Array(N),G:new Float32Array(N),CR:new Float32Array(N),CG:new Float32Array(N),CB:new Float32Array(N),GK:new Float32Array(N),EM:new Float32Array(N),HOT:new Float32Array(N)}};
const pzb8Ready=()=>{if(!PZB8){PZB8=pzb8Build();pzb8CathF=pzb8MakeCath(PZB8);PZB3.mat.cathedral=pzb8CathF}return PZB8};
/* per-ball cell values (shade, tint, glow) from the integer hash, so every ball has its own mosaic colouring */
const pzb8Cells=(n,spread,C,CP)=>{const P=pzb8Ready();P.n=n;const V=P.V;V[0]=CP[0]*.88+C[0]*.12;V[1]=CP[1]*.88+C[1]*.12;V[2]=CP[2]*.88+C[2]*.12;V[3]=C[0]*.14+4;V[4]=C[1]*.14+3;V[5]=C[2]*.16+6;for(let i=0;i<P.N;i++){const h=pzb2Hash(i,n*7+3,11),h2=pzb2Hash(i,n*5+1,29),h3=pzb2Hash(i,n*3+2,53),kc=1+(h-.5)*spread,tn=h2*2-1;P.K[i]=kc;P.T[i]=tn;P.G[i]=h3;
  /* per-cell glass colour, brightness factor, backlight bonus and hot-cell amount, hoisted out of the pixel loop */
  P.CR[i]=C[0]*kc*(1+.2*tn);P.CG[i]=C[1]*kc*(1+.03*tn);P.CB[i]=C[2]*kc*(1-.2*tn);P.GK[i]=.84+.3*h3*h3;P.EM[i]=.4+.18*h3;P.HOT[i]=h3>.86?(h3-.86)*5:0}};
/* a sine table (4096 steps, error under 0.0008) and the opal's fire hue table: sine, +2.09 and +4.19, normalised so the brightest channel is 1 */
const pzb8PS=new Float32Array(4096),pzb8NR=new Float32Array(4096),pzb8NG=new Float32Array(4096),pzb8NB=new Float32Array(4096);
for(let i=0;i<4096;i++){const p=i/4096*6.283185307;pzb8PS[i]=Math.sin(p);const r=.5+.5*Math.sin(p),g=.5+.5*Math.sin(p+2.09),b=.5+.5*Math.sin(p+4.19),k=1/(Math.max(r,g,b)+.01);pzb8NR[i]=r*k;pzb8NG[i]=g*k;pzb8NB[i]=b*k}
const pzb8Sn=x=>pzb8PS[((x*651.8986+65536.5)|0)&4095];
const pzb8Sm=(a,b,x)=>{x=(x-a)/(b-a);x=x<0?0:x>1?1:x;return x*x*(3-2*x)};

/* ---------- Cathedral Glass ---------- */
const pzb8MakeCath=T=>{const {SP,UP,off:OFF,lst:LST,CR,CG,CB,GK,EM,HOT,K:KK,V}=T,PS=pzb8PS,hash=pzb2Hash,Sm=(a,b,x)=>{x=(x-a)/(b-a);x=x<0?0:x>1?1:x;return x*x*(3-2*x)},Sn=x=>PS[((x*651.8986+65536.5)|0)&4095];
return function(o){const lx=o.lx,ly=o.ly,lz=o.lz,C=o.C,band=o.band,ab=o.ab;
 if(o.is8){/* black smoked glass in a gold-leaded diamond lattice */
  const u1=(lx+ly)*3.3,u2=(lx-ly)*3.3,f1=u1-Math.floor(u1+.5),f2=u2-Math.floor(u2+.5),af=Math.min(f1<0?-f1:f1,f2<0?-f2:f2),
   ln=1-Sm(.05,.105,af),h=hash(Math.floor(u1+.5)+40,Math.floor(u2+.5)+40,5),sm=.5+.5*Sn(lx*3+ly*2.2+lz*3.4+h*6);
  o.r=C[0];o.g=C[1];o.b=C[2];
  /* smoke inside each pane: a deep violet-grey that stays dark; the lead is gold with a lighter edge on one side */
  const sk=(7+9*h)*(.6+.4*sm);o.er=sk*.9;o.eg=sk*.8;o.eb=sk*1.35;
  const hi=ln*(.75+.25*Sn((lx*2-ly*1.3)*5+lz*3));o.er+=255*hi*.92;o.eg+=196*hi*.92;o.eb+=74*hi*.92;o.r+=ln*30;o.g+=ln*22;o.b+=ln*4;return}
 let ix=((lx+1)*12)|0,iy=((ly+1)*12)|0,iz=((lz+1)*12)|0;ix=ix>23?23:ix<0?0:ix;iy=iy>23?23:iy<0?0:iy;iz=iz>23?23:iz<0?0:iz;
 const g=(ix*24+iy)*24+iz,a=OFF[g],b=OFF[g+1];let d1=-9,d2=-9,i1=0,e=1;
 for(let k=a;k<b;k++){const s=LST[k],s4=s<<2,d=lx*SP[s4]+ly*SP[s4+1]+lz*SP[s4+2];if(d>d1){d2=d1;d1=d;i1=s}else if(d>d2)d2=d}e=(d1-d2)*2;
 /* the glass of one cell: a shade and a tint of the ball's colour, lit from behind and brighter in the middle */
 const u4=i1<<2,q=lx*UP[u4]+ly*UP[u4+1]+lz*UP[u4+2]-UP[u4+3],cen=1-(1-d1)*24,ce=cen<0?0:cen,gr=1+q*1.5,cr=CR[i1],cg=CG[i1],cb=CB[i1];
 /* lead: thin and dark, tinted with the ball's colour; the band's border on a stripe gets one too */
 let ld=e<.02?1-Sm(.007,.02,e):0;if(o.stripe){const ed=(o.edge-.5)*3.2;const el=ed<0?0:ed>1?1:ed;if(el>ld)ld=el}
 const bev=e<.085&&q>0?(1-Sm(.02,.085,e))*Sm(.0,.12,q)*(1-ld):0;
 let r=0,g2=0,b2=0,er=0,eg=0,eb=0;
 if(band>.01){const gk=gr*(.8+.35*ce)*GK[i1],em=(.4+.3*ce+EM[i1]-.4)*(.7+.3*gk),hot=HOT[i1];
  r=cr*.5*gr;g2=cg*.5*gr;b2=cb*.5*gr;er=cr*em;eg=cg*em;eb=cb*em;
  /* a hot cell now and then, and the bevel highlight */
  er+=(255-er)*hot*.35+255*bev*.34;eg+=(255-eg)*hot*.3+255*bev*.32;eb+=(255-eb)*hot*.3+255*bev*.3;
  r*=band;g2*=band;b2*=band;er*=band;eg*=band;eb*=band}
 if(ab>.01){/* frosted white glass: pale panes, soft pewter lead, a ripple of frost */
  const CP=o.CP,fr=.5+.5*Sn(lx*17+ly*9+Sn(lz*13+ly*7)*2),pk=.935+.05*KK[i1],fl=e<.04?1-Sm(.012,.04,e):0,ps=.97+.03*ce,cw=pk*(.93+.07*fr),
   pr=V[0]*cw*(1-fl*.1),pg=V[1]*cw*(1-fl*.1),pb=V[2]*cw*(1-fl*.08),ef=.1+.18*ce,k5=1-fl*.5,bv=255*bev*.1;
  r+=pr*ab*ps;g2+=pg*ab*ps;b2+=pb*ab*ps;er+=ab*(CP[0]*ef*k5+bv);eg+=ab*(CP[1]*ef*k5+bv);eb+=ab*(CP[2]*ef*k5+bv)}
 /* lead lines over the band only (the frosted caps carry their own soft ones) */
 if(ld>0){const lk=ld*band;r=r*(1-lk)+V[3]*lk;g2=g2*(1-lk)+V[4]*lk;b2=b2*(1-lk)+V[5]*lk;const l2=1-lk*.95;er*=l2;eg*=l2;eb*=l2}
 o.r=r;o.g=g2;o.b=b2;o.er=er;o.eg=eg;o.eb=eb}};

/* ---------- Aurora Opal ---------- */
const pzb8Opal=(()=>{const PS=pzb8PS,NR=pzb8NR,NG=pzb8NG,NB=pzb8NB,hash=pzb2Hash,Sm=(a,b,x)=>{x=(x-a)/(b-a);x=x<0?0:x>1?1:x;return x*x*(3-2*x)},Sn=x=>PS[((x*651.8986+65536.5)|0)&4095];
return function(o){const lx=o.lx,ly=o.ly,lz=o.lz,wx=o.wx,wy=o.wy,wz=o.wz,C=o.C,band=o.band,ab=o.ab;
 /* broad patches of fire (slide with the roll through lx,ly,lz and with the view through wx,wy) and a patchwork of angular cells */
 const nb=Sn(lx*3.3+ly*2.1+Sn(lz*3.9+ly*2.6)*1.5),pm=.5+.5*Sn(lx*2.6-ly*3.4+lz*2.2+nb*1.9),mk=Sm(.28,.8,pm);
 if(o.is8){/* black opal: small vivid soft flashes of fire */
  const u=lx*7+ly*1.9,v=ly*7-lx*1.9,w=lz*7,fu=u-Math.floor(u)-.5,fv=v-Math.floor(v)-.5,fw=w-Math.floor(w)-.5,h=hash(Math.floor(u),Math.floor(v),Math.floor(w)),
   dd=1-(fu*fu+fv*fv+fw*fw)*3.3,sp=dd<0?0:dd,al=sp*sp*Sm(.38,.75,h)*(.5+.5*mk)+.2*mk*mk,
   i0=((nb*3+(lx*2.4+ly*1.8+lz*2.1)*2.2+wx*4.2+wy*3.1+h*4)*651.8986+65536.5)|0;
  o.r=C[0];o.g=C[1];o.b=C[2];const fr=.5+.5*PS[i0&4095],fg=.5+.5*PS[(i0+1362)&4095],fb=.5+.5*PS[(i0+2732)&4095],k=al*225;
  o.er=fr*fr*k+5;o.eg=fg*fg*k+4;o.eb=fb*fb*k+8;
  /* the ring of the 8's disc is rainbow (the disc itself is painted by the shared painter) */
  const q=lx*lx+ly*ly,az=lz<0?-lz:lz;if(az>.8&&q>.2&&q<.3){const dq=q>.255?q-.255:.255-q,rr=1-Sm(.0,.03,dq),j0=((Math.atan2(ly,lx)*2+lz*3)*651.8986+65536.5)|0;
   o.er+=rr*(.35+.65*(.5+.5*PS[j0&4095]))*255;o.eg+=rr*(.35+.65*(.5+.5*PS[(j0+1362)&4095]))*255;o.eb+=rr*(.35+.65*(.5+.5*PS[(j0+2732)&4095]))*255}
  return}
 const gx=Math.floor(lx*4.4+ly*1.2),gy=Math.floor(ly*4.4-lx*1.2),gz=Math.floor(lz*4.4),h=hash(gx,gy,gz),
  hq=Sm(.3,.62,.5+.5*Sn(lz*3.1-lx*2.2+ly*1.3+nb)),
  i0=((nb*2.4+(lx*2.3+ly*1.6+lz*1.9)*1.6+wx*3.4+wy*2.5+wz*1.4+hq*(h-.5)*8)*651.8986+65536.5)&4095,
  sr=NR[i0],sg=NG[i0],sb=NB[i0],m=mk*(.72+.28*h)+hq*(.16+.3*h)*(1-mk*.5);
 /* the milky body: tinted strongly, a little paler in the middle where the light scatters, deeper at the edge */
 const wz2=wz*wz,mi=.02+.06*wz2;
 let r=0,g=0,b=0,er=0,eg=0,eb=0;
 if(band>.01){const fa=m*.42,dk=.9-.1*wz2,dr=C[0]*dk,dg=C[1]*dk,db=C[2]*dk;/* the fire tints the colour (at most about half) and the body keeps the rest */
  r=dr*.72;g=dg*.72;b=db*.72;
  er=dr*.24+235*mi+(sr*225-dr*.24)*fa;eg=dg*.24+232*mi+(sg*225-dg*.24)*fa;eb=db*.24+250*mi+(sb*225-db*.24)*fa;
  r*=band;g*=band;b*=band;er*=band;eg*=band;eb*=band}
 if(ab>.01){/* white opal caps: milky with faint pastel flashes */
  const CP=o.CP,pa=m*.15+.02,sh=.94+.06*wz2;
  r+=CP[0]*.72*sh*ab;g+=CP[1]*.72*sh*ab;b+=CP[2]*.72*sh*ab;er+=(CP[0]*.18+(sr*255-CP[0]*.18)*pa)*ab;eg+=(CP[1]*.18+(sg*255-CP[1]*.18)*pa)*ab;eb+=(CP[2]*.18+(sb*255-CP[2]*.18)*pa)*ab}
 /* a bright line of fire on a stripe's band border */
 if(o.stripe&&o.edge>.4){const ed=(o.edge-.4)*1.67,e2=ed*ed*.55;er+=sr*210*e2;eg+=sg*210*e2;eb+=sb*210*e2}
 o.r=r;o.g=g;o.b=b;o.er=er;o.eg=eg;o.eb=eb}})();

pzb3Reg({id:'cathedral',n:'Cathedral Glass',price:20000,tag:'Light through a cathedral window.',
 pal:{col:{1:[250,194,52],2:[58,122,236],3:[236,64,92],4:[150,84,226],5:[250,128,40],6:[34,176,128],7:[178,44,76],8:[16,14,22]},
  white:[244,244,250],cap:[236,240,248],disc:[250,240,212],num:[44,24,16],disc8:[250,250,255],num8:[22,14,26],ring8:[255,196,60],spec:1.2,win:.12,rim:.34,
  prep(P,pal,n,C){pzb8Cells(n,.62,C,pal.cap)}},
 mat:o=>{pzb8Ready();pzb8CathF(o)}});
pzb3Reg({id:'opal',n:'Aurora Opal',price:50000,tag:'Every turn flashes a new colour.',
 pal:{col:{1:[248,196,52],2:[60,126,240],3:[238,66,104],4:[156,88,230],5:[250,134,44],6:[36,180,132],7:[186,48,84],8:[11,9,16]},
  white:[246,244,250],cap:[242,240,246],disc:[246,242,250],num:[40,26,64],disc8:[252,250,255],num8:[24,14,40],ring8:[70,60,90],spec:.95,win:.08,rim:.3},
 mat:pzb8Opal});
