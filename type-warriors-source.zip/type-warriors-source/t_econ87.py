# 8.7 economy checks (94d_econ.js and 94e_ledger.js): Lantern Caravan daily contracts (E1) and the "Up to" text (E1b), game speed gold (E4),
# prestige and the skill-tree gold (E7), the egg cap and its migration (E8), level-up gold from calendar and crate XP (E9), reward text (E11),
# the backwards-clock guard (E14), the gold ledger and save safety (accessor, round trips, bounded arrays, nothing recorded by loading).
# Run from the source folder against out.html. Nothing waits for real time: caravan runs are stepped with wrUpdate(1/60).
import asyncio,os,json
from playwright.async_api import async_playwright
OVL=open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'t_riddle_ovl.js')).read()
URL='file://'+os.path.abspath('out.html')
RUN="""(id,o)=>{o=o||{};wrLeave();wrStart(id);WRX.int=o.int==null?4:o.int;WRX.ok=o.ok==null?100:o.ok;WRX.chars=100;WRX.time=40;WRX.coins=o.coins==null?20:o.coins;WRX.kills=3;
 if(id==='gallows')WRX.bossDone=1;const g0=P.gold;
 if(o.lose){WRX.x=WRX.rt.len*.5;WRX.int=1;wrHit(null,'axle')}else WRX.x=WRX.rt.len;
 for(let i=0;i<400;i++)wrUpdate(1/60);const r=WRX.result;if(!r)return null;
 return {won:r.won,pay:r.pay,coins:r.coins,total:r.total,first:r.first,ec:r.ec,dg:P.gold-g0,prog:r.prog,int:WRX.int,rtpay:WRX.rt.pay,line:(document.querySelector('.wrpay small')||{}).textContent||''}}"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append('PE '+str(e)[:300]));pg.on('console',lambda m:er.append('CE '+m.text[:200]) if m.type=='error' and 'ERR_' not in m.text else None)
        await pg.goto(URL);await pg.wait_for_timeout(1400);E=pg.evaluate;bad=0
        def chk(name,r,ok):
            nonlocal bad;bad+=not ok;print(name,r,'OK' if ok else 'BAD')
        async def fresh(js=''):
            await E("()=>{RS_ASK=false;load({});P.gold=5000;"+js+"save();title()}");await pg.wait_for_timeout(250)
        await E("()=>{RS_ASK=false;P.pet='bramble'}")
        # ---------------- modules are in ----------------
        r=await E("()=>[typeof ecClockSync,typeof ldgInstall,typeof ledgerToday,typeof ledgerRecent,typeof ukSrc,typeof WRP().ctr,P.m87]")
        chk('modules are loaded and the migration flag is set',r,r==['function','function','function','function','function','object',1])

        # ---------------- E1: Lantern Caravan daily contracts ----------------
        await fresh("delete P.wr;WRP().intro=1;")
        r=await E("()=>{P.wr={ctr:{day:5,mill:'x',pines:-3,gallows:1e9,zzz:1}};const c=WRP().ctr;const a=[c.day,c.mill,c.pines,c.gallows,'zzz' in c];P.wr={lan:'brass'};const d=WRP().ctr;return [a,d.day,d.mill,d.pines,d.gallows]}")
        chk('save normaliser: old saves without ctr and junk ctr are tolerated',r,r==[['',0,0,99,False],'',0,0,0])
        await fresh("delete P.wr;WRP().intro=1;P.xp=lvx(30);")
        runs=[]
        for i in range(5):runs.append(await E("()=>("+RUN+")('mill')"))
        full=await E("()=>Math.round(WR_RT('mill').pay*(.55+.15*4)*wrAccF(1))")
        exp=[round(full*1.5+1e-9),full,full,round(full*.35),round(full*.35)]
        chk('five perfect Millbrook wins pay 1.5x, full, full, 35%, 35%',[r['pay'] for r in runs],[r['pay'] for r in runs]==exp and all(r['won'] for r in runs))
        chk('road coins are never reduced, total = route pay + road coins, gold paid matches',[(r['coins'],r['total'],r['dg']) for r in runs],all(r['coins']==20 and r['total']==r['pay']+20 and r['dg']==r['total'] for r in runs))
        chk('first-run x1.5 only on the first win; contract numbers 1,2,3 then reduced',[(r['first'],r['ec']['n'],r['ec']['reduced']) for r in runs],[(r['first'],r['ec']['n'],r['ec']['reduced']) for r in runs]==[(True,1,False),(False,2,False),(False,3,False),(False,4,True),(False,5,True)])
        chk('result card pay line is honest about the contract',[r['line'] for r in runs],
            runs[0]['line'].startswith('route pay %d (first run today ×1.5, contract 1/3)'%exp[0]) and runs[1]['line'].startswith('route pay %d (contract 2/3)'%exp[1]) and runs[2]['line'].startswith('route pay %d (contract 3/3)'%exp[2]) and runs[3]['line'].startswith('route pay %d (reduced: contracts used)'%exp[3]) and runs[4]['line'].startswith('route pay %d (reduced: contracts used)'%exp[4]))
        r=await E("()=>{const w=WRP();return [w.ctr.mill,w.ctr.pines,w.ctr.gallows,w.ctr.day===wrDay(),w.dayDone.mill,w.clears]}")
        chk('the save counts only wins: mill 5, other routes untouched, today key kept',r,r==[5,0,0,True,1,5])
        lose=await E("()=>("+RUN+")('mill',{lose:true})")
        r=await E("()=>[WRP().ctr.mill,Math.round(WR_RT('mill').pay*.25*"+str(lose['prog'])+")]")
        chk('a breakdown after the contracts are used pays the old quarter-by-progress, coins unchanged, no contract used',[lose['won'],lose['pay'],lose['coins'],r],lose['won']==False and lose['pay']==r[1] and lose['coins']==20 and r[0]==5)
        await E("()=>{WRP().med.mill=3;WRP().med.pines=3}")
        pg1=await E("()=>("+RUN+")('pines')");pgx=await E("()=>("+RUN+")('gallows')")
        fp=await E("()=>Math.round(WR_RT('pines').pay*(.55+.15*4)*wrAccF(1))");fg=await E("()=>Math.round(WR_RT('gallows').pay*(.55+.15*4)*wrAccF(1))")
        chk('another route has its own contracts and its own first-win bonus',[pg1['pay'],pgx['pay'],fp,fg],pg1['pay']==round(fp*1.5+1e-9) and pgx['pay']==round(fg*1.5+1e-9) and pg1['ec']['n']==1 and pgx['ec']['n']==1)
        # day rollover
        await E("()=>{const w=WRP();w.day='2000-01-01';w.dayDone={mill:1,pines:1};w.ctr.day='2000-01-01'}")
        nd=await E("()=>("+RUN+")('mill')")
        r=await E("()=>[WRP().ctr.mill,WRP().ctr.day===wrDay(),WRP().ctr.pines]")
        chk('a new day resets every contract and brings the first-win bonus back',[nd['pay'],nd['first'],nd['ec'],r],nd['pay']==exp[0] and nd['first'] and nd['ec']['n']==1 and r==[1,True,0])
        # hub text
        await fresh("delete P.wr;WRP().intro=1;P.xp=lvx(30);WRP().med.mill=3;WRP().med.pines=3;")
        await E("()=>{wrSel='mill';wagonMenu(title)}");await pg.wait_for_timeout(500)
        r=await E("()=>[document.getElementById('wrrc').textContent.trim(),document.getElementById('wrri').textContent,[...document.querySelectorAll('.eccn')].map(e=>e.textContent.trim()),document.querySelectorAll('.wrcd.lock .eccn').length]")
        chk('hub: Ready panel and every open route card show Contracts 3/3 today',r,r[0]=='Contracts 3/3 today' and r[2]==['Contracts 3/3 today']*3 and r[3]==0)
        mx={}
        for id in ['mill','pines','gallows']:
            await E("(id)=>{wrSelect(id)}",id);mx[id]=await E("()=>document.getElementById('wrri').textContent")
        want={i:await E("(i)=>{const rt=WR_RT(i);return Math.round(Math.round(rt.pay*(.55+.15*4)*1.1)*1.5)}",i) for i in ['mill','pines','gallows']}
        chk('E1b: Up to N coins + road coins is the real first-run maximum (route pay x (.55+.15x4) x 1.1 x 1.5)',[mx,want],all(('Up to %s coins + road coins'%format(want[i],',')) in mx[i] for i in want))
        # a perfect first run pays exactly what the hub promised
        pf=await E("()=>("+RUN+")('gallows',{coins:0})")
        chk('E1b: a perfect first run pays exactly the promised maximum, never more',[pf['pay'],want['gallows']],pf['pay']==want['gallows'] and pf['first'])
        await E("()=>{wagonMenu(title);wrSelect('gallows')}");await pg.wait_for_timeout(300)
        r=await E("()=>document.getElementById('wrri').textContent")
        w2=await E("()=>Math.round(WR_RT('gallows').pay*(.55+.15*4)*1.1)")
        chk('E1b: after the first win the shown maximum drops the x1.5',r,('Up to %s coins'%format(w2,',')) in r)
        for i in range(2):await E("()=>("+RUN+")('gallows')")
        await E("()=>{wagonMenu(title);wrSelect('gallows')}");await pg.wait_for_timeout(300)
        r=await E("()=>[document.getElementById('wrrc').textContent.trim(),document.getElementById('wrri').textContent,[...document.querySelectorAll('.wrcd')].map(e=>(e.querySelector('.eccn')||{}).textContent||'')]")
        w3=await E("()=>Math.round(Math.round(WR_RT('gallows').pay*(.55+.15*4)*1.1)*.35)")
        chk('hub after 3 wins on Gallows: "Contracts used - reduced pay", reduced maximum, other cards unchanged',r,r[0]=='Contracts used - reduced pay' and ('Up to %s coins'%format(w3,',')) in r[1] and r[2][0].strip()=='Contracts 3/3 today' and r[2][2].strip()=='Contracts used - reduced pay')
        await E("()=>{"+OVL+"}")
        r=await E("()=>__ovl(document.getElementById('wrhub')).filter(x=>!/fsht|fshk/.test(x))")
        chk('hub overlap sweep with the contract text',r,r==[])

        # ---------------- E4: game speed ----------------
        await fresh()
        await E("()=>{start(1)}");await pg.wait_for_timeout(300)
        r=await E("()=>{S.gm=1;S.gold=0;const o=[];const g=()=>{const a=P.gold;gain(100);return P.gold-a};o.push(g());setSpeed(2);o.push(g(),S.gm,S.gs);setSpeed(1);o.push(g(),S.gm===1,S.gs);return o}")
        chk('2x speed gives 1.25x gold per kill and 1x restores exactly 1x',r,r==[100,125,1.25,2,100,True,1])
        r=await E("()=>{S.gm=1.37;const sc0=S.sc;delete S.gsF;delete S.gsPost;delete S.gsBase;const o=[];for(const v of[1.5,2,1.25,1.75,1]){setSpeed(v);o.push(Math.abs(S.gm-1.37*(1+.25*(v-1)))<1e-12)}o.push(S.gm===1.37,Math.abs(S.sc-sc0)<1e-9);return o}")
        chk('repeated speed changes do not drift (strict equality at 1x), score multiplier still follows the speed',r,all(r))
        r=await E("()=>{S.gm=1.2;delete S.gsF;delete S.gsPost;delete S.gsBase;setSpeed(2);S.gm+=.05;const mid=S.gm;setSpeed(1);return [Math.abs(S.gm-(mid/1.25))<1e-12,Math.abs(S.gm-1.2-.04)<1e-12]}")
        chk('a bonus added while fast is kept (dampened) when going back',r,r==[True,True])
        r=await E("()=>{start(1);S.camp=1;S.gm=1;S.gold=0;setSpeed(2);setSpeed(1.25);const a=P.gold;gain(1000);return [P.gold-a,S.gs]}")
        chk('1.25x speed pays 1.0625x',r,r==[1062,1.25] or r==[1063,1.25])
        # level clear bonus
        async def victory_gold(gsa):
            await fresh("P.xp=1;P.stars={};")
            await E("()=>{start(1)}");await pg.wait_for_timeout(200)
            return await E("(a)=>{S.camp=1;S.dmgTaken=0;S.gsA=a;S.gsT=1;S.gsW=a;const g0=P.gold,x0=P.xp;victory();return [P.gold-g0,P.xp-x0,S.gsA,lvl(P.xp)-lvl(x0)]}",gsa)
        v1=await victory_gold(1);v2=await victory_gold(2)
        chk('level-clear bonus uses the dampened average speed: 180 at 1x, 225 at 2x (was 360); result still shows the real average',[v1,v2],v1[0]-v1[3]*100==180 and v2[0]-v2[3]*100==225 and v2[2]==2)

        # ---------------- E7: prestige resets P.ug ----------------
        await fresh("P.gold=100000;P.xp=lvx(30);P.stars[30]=3;")
        r=await E("()=>{buyNode('prosp','g');buyNode('prosp','g');const ug=P.ug;const g1=P.gold;doPrestige({w:{},a:{}},()=>{});const after=[P.pres,P.ug,P.us,Object.keys(P.upg).length];const rb=respec();return [ug,after,rb,P.gold===g1]}")
        chk('prestige clears P.ug; a respec right after refunds nothing; no gold taken',r,r[0]==520 and r[1]==[1,0,0,0] and r[2]==0 and r[3])
        r=await E("()=>{buyNode('prosp','g');const ug=P.ug,g=P.gold;const back=respec();return [ug,back,P.gold-g]}")
        chk('gold spent after the prestige is still refunded at 75%',r,r==[200,150,150])
        r=await E("()=>{P.ug=123;const ug=P.ug,pres=P.pres;doPrestige({w:{},a:{}},()=>{});return [pres,P.pres,ug,P.ug]}")
        chk('a prestige that is not allowed changes nothing',r,r[0]==r[1] and r[3]==123)
        r=await E("()=>{P.upg={};P.ug=999;P.m87=0;ecMigrate();const a=P.ug;P.upg={prosp:1};P.ug=999;P.m87=0;ecMigrate();const b=P.ug;P.upg={prosp:2};P.ug=300;P.m87=0;ecMigrate();return [a,b,P.ug]}")
        chk('migration clamps a stale P.ug to the cost of the ranks owned and never raises it',r,r==[0,200,300])

        # ---------------- E8: eggs ----------------
        await fresh("P.gold=1e6;P.pets={};P.petSt=2;")
        r=await E("()=>{const o={};for(const k of Object.keys(PEGG_PRICE)){const n=petPool(k).length;P.eggs={r:0,l:0,m:0};P.eggs[k]=Math.max(0,n-1);const g0=P.gold;const a=n>0?petBuy(k):null;const b=petBuy(k);o[k]=[n,a,b,P.eggs[k],P.gold===g0-(a?PEGG_PRICE[k]:0)]}return o}")
        chk('petBuy: allowed while eggs < unowned companions, refused once they cover them, gold untouched when refused',r,all(v[0]>0 and v[1]==True and v[2]==False and v[3]==v[0] and v[4] for v in r.values()))
        r=await E("()=>{P.pets={};const n=petPool('r').length;P.eggs={r:n-2,l:0,m:0};const before=ecEggCap('r');['bramble','cinder'].forEach(id=>P.pets[id]={b:0});const pool=petPool('r').length;const after=ecEggCap('r');const g=P.gold,a=petBuy('r');return [n,pool,before,after,a,P.gold===g,P.eggs.r]}")
        chk('owning companions lowers the cap: the same eggs now cover everything and buying is refused',r,r[1]==r[0]-2 and r[2]==False and r[3]==True and r[4]==False and r[5] and r[6]==r[0]-2)
        await E("()=>{P.pets={};P.eggs={r:0,l:0,m:0};PTX.egg='r'}")
        await E("()=>{petHall('Eggs')}")
        try:await pg.wait_for_function("()=>!!document.getElementById('phxby')",timeout=4000)
        except Exception:pass
        r=await E("()=>{const b=document.getElementById('phxby');return b&&[b.disabled,b.textContent.trim()]}")
        chk('Hatchery shows Buy while the cap is open',r,r and r[0]==False and r[1]=='Buy')
        await E("()=>{P.eggs.r=petPool('r').length;petHall('Eggs')}")
        try:await pg.wait_for_function("()=>{const b=document.getElementById('phxby');return !!b&&b.disabled}",timeout=4000)
        except Exception:pass
        r=await E("()=>{const b=document.getElementById('phxby');return b&&[b.disabled,b.textContent.trim(),document.querySelector('.phx-row small')&&document.querySelector('.phx-row small').textContent]}")
        chk('Hatchery shows "All Rare companions found" instead of Buy when the eggs in hand cover the rest',r,r and r[0]==True and r[1]=='All Rare companions found')
        # migration
        async def mig(js):
            await fresh("P.gold=1000;P.pets={};P.petSt=2;"+js)
            return await E("()=>{P.m87=0;const n={r:petPool('r').length,l:petPool('l').length,m:petPool('m').length};const g0=P.gold,e0=Object.assign({},P.eggs);ecMigrate();const g1=P.gold,e1=Object.assign({},P.eggs);ecMigrate();return [n,g0,g1,e0,e1,P.gold,P.m87]}")
        n=await E("()=>({r:petPool('r').length,l:petPool('l').length,m:petPool('m').length})")
        r=await mig("P.petBuy=4;P.eggs={r:%d,l:0,m:0};"%(n['r']+3))
        chk('migration refunds bought surplus eggs at the egg price, once',r,r[2]-r[1]==6000 and r[4]['r']==n['r'] and r[5]==r[2] and r[6]==1)
        r=await mig("P.petBuy=0;P.eggs={r:%d,l:%d,m:0};"%(n['r']+2,n['l']+1))
        chk('free (trail) eggs are never refunded: no purchases, nothing refunded',r,r[2]==r[1] and r[4]==r[3])
        r=await mig("P.petBuy=2;P.eggs={r:%d,l:%d,m:0};"%(n['r']+3,n['l']+1))
        chk('refund is capped by the number of eggs ever bought, cheapest first',r,r[2]-r[1]==4000 and r[4]['r']==n['r']+1 and r[4]['l']==n['l']+1)
        # boot: reload runs it once, toast shown once, gold never goes down
        await fresh("P.gold=1000;P.pets={};P.petSt=2;P.petBuy=3;P.eggs={r:%d,l:0,m:0};delete P.m87;"%(n['r']+2))
        await pg.reload();await pg.wait_for_timeout(1500)
        r=await E("()=>[P.gold,P.eggs.r,P.m87]")
        try:
            await pg.wait_for_function("()=>{const e=document.getElementById('cctoast');return !!e&&e.textContent.includes('Surplus')}",timeout=7000);t=await E("()=>document.getElementById('cctoast').textContent")
        except Exception as e:t=None
        chk('reload: the migration runs after the pet normaliser, refunds 4,000 and shows one toast',[r,t],r[0]==5000 and r[1]==n['r'] and r[2]==1 and t=='Surplus eggs refunded: +4,000 coins')
        await pg.reload();await pg.wait_for_timeout(1500)
        r=await E("()=>[P.gold,P.eggs.r,P.m87]");await pg.wait_for_timeout(4500)
        t=await E("()=>!!document.getElementById('cctoast')")
        chk('second reload: nothing more is refunded and no toast',[r,t],r[0]==5000 and r[1]==n['r'] and not t)
        import re
        src=open('94d_econ.js',encoding='utf-8').read()+open('94e_ledger.js',encoding='utf-8').read()
        chk('no bell/Updates notice is created by the economy modules',re.findall(r'UPDATES|updAdd|updNote|bellAdd',src),not re.search(r'UPDATES|updAdd|updNote|bellAdd',src))

        # ---------------- E9: level-up gold ----------------
        await fresh("P.xp=lvx(5)-10;")
        r=await E("()=>{const g=P.gold,l=lvl(P.xp);calGrant({gold:0,xp:250});return [P.gold-g,lvl(P.xp)-l]}")
        chk('calendar XP that crosses a level pays 100 gold',r,r==[100,1])
        r=await E("()=>{const g=P.gold;calGrant({gold:70,xp:5});return P.gold-g}")
        chk('calendar XP without a level-up pays only the reward',r,r==70)
        r=await E("()=>{P.xp=lvx(5)-10;const g=P.gold,l=lvl(P.xp);calGrant({gold:0,xp:6000});return [P.gold-g,lvl(P.xp)-l]}")
        chk('crossing several levels pays 100 for each',r,r[0]==100*r[1] and r[1]>=2)
        r=await E("()=>{for(const k in WP)P.own[k]=1;P.crates=1;P.xp=lvx(5)-10;const g=P.gold,l=lvl(P.xp);const q=crateRoll('w');return [q.dup,P.gold-g-GOLDDUP[q.it.r],lvl(P.xp)-l]}")
        chk('crate duplicate XP that crosses a level pays 100 gold on top of the duplicate gold',r,r==[True,100,1])
        r=await E("()=>{P.crates=1;P.xp=lvx(7)+10;const g=P.gold;const q=crateRoll('w');return P.gold-g-GOLDDUP[q.it.r]}")
        chk('duplicate crate without a level-up pays only the duplicate gold',r,r==0)
        r=await E("()=>{start(1);S.camp=1;S.dmgTaken=0;P.stars={};P.xp=lvx(5)-1;const g0=P.gold,l0=lvl(P.xp);victory();const l1=lvl(P.xp);return [P.gold-g0,180+100*(l1-l0),l1-l0]}")
        chk('campaign XP still pays its level bonus exactly once (no double pay)',r,r[0]==r[1] and r[2]>=1)

        # ---------------- E11: reward text ----------------
        await fresh("P.pres=1;")
        r=await E("()=>[NM.prosp.e(1),NM.prosp.e(4),perkLines(1).find(x=>/gold/.test(x)),presBlock().includes('gold from monsters and rounds')]")
        chk('Prospector and prestige text say what is paid',r,r==['+4% gold from monsters and rounds.','+16% gold from monsters and rounds.','+5% gold from monsters and rounds',True])
        r=await E("()=>{const t=HELP.Modes.find(x=>x[0]==='Lantern Caravan')[1];return [t.includes('Daily contracts'),t.split('Daily contracts').length]}")
        chk('Help explains the daily contracts (once)',r,r==[True,2])

        # ---------------- E14: the clock cannot go backwards ----------------
        await fresh("delete P.wr;WRP().intro=1;")
        r=await E("()=>[window.Date===EC_RD,Date.toString().includes('native code'),P.dmax===ecKey(new EC_RD()),ecShift]")
        chk('normal clock: no patch, P.dmax is today',r,r==[True,True,True,0])
        r=await E("""()=>{const t=new EC_RD();t.setDate(t.getDate()+1);const K=ecKey(t);P.dmax=K;ecClockSync();const now=Date.now(),real=EC_RD.now();
          const o=[window.Date!==EC_RD,wrDay()===K,new Date().getDate()===t.getDate(),Math.abs(now-real)<50,rrKey()===K,BTY().d===K,calInfo().td===t.getDate(),TW.day()===K,dlLocal(new Date())===K,dcKey()===K,wcDay().split('-')[2]==String(t.getDate()),typeof Date()==='string',new Date(2020,1,2).getFullYear()===2020,new Date(0)instanceof Date,Date.UTC(2020,0,1)===1577836800000,new Date('2021-03-04T00:00:00Z').getTime()===1614816000000];
          window.__K=K;return o}""")
        chk('clock held behind P.dmax: the calendar day stays at dmax everywhere (riddle, bounty, calendar, tower, daily challenge, wildcard, caravan); Date.now and explicit dates stay real',r,all(r))
        r=await E("()=>{window.__twDay='2026-10-06';const a=[TW.day(),twBoost()];window.__twDay=null;return [a,twBoost()]}")
        chk('the Tower boost test hook still works, and the boost is not reachable by turning the clock back',r,r==[['2026-10-06',True],False])
        await E("()=>{P.dmax='';ecClockSync();load({});P.gold=5000;delete P.wr;WRP().intro=1;save()}")
        r=await E("""()=>{const t=new EC_RD();t.setDate(t.getDate()+1);const K=ecKey(t);const w=WRP();w.med.mill=3;w.ctr={day:K,mill:3,pines:0,gallows:0};w.day=K;w.dayDone={mill:1};
          P.dmax=K;ecClockSync();const held=[ecLeft('mill'),WRP().ctr.mill];P.dmax='';ecClockSync();const open=ecLeft('mill');return [held,open,window.Date===EC_RD]}""")
        chk('caravan contracts do not reopen when the clock reads earlier (control: they do without the guard)',r,r==[[0,3],3,True])
        r=await E("()=>{const t=new EC_RD();t.setDate(t.getDate()+1);const K=ecKey(t);const w=WRP();w.ctr={day:K,mill:3,pines:0,gallows:0};w.day=K;w.dayDone={mill:1};P.dmax=K;ecClockSync();const q=("+RUN+")('mill');P.dmax='';ecClockSync();return [q.pay,q.first,q.ec.reduced,Math.round(Math.round(175*1.15*1.1)*.35)]}")
        chk('with the clock back, the next win is still reduced and the first-win bonus does not return',r,r[0]==r[3] and r[1]==False and r[2]==True)
        r=await E("()=>{const t=new EC_RD();t.setDate(t.getDate()+60);P.dmax=ecKey(t);ecClockSync();const o=[P.dmax===ecKey(new EC_RD()),ecShift,window.Date===EC_RD];P.dmax='bogus';ecClockSync();o.push(P.dmax===ecKey(new EC_RD()));return o}")
        chk('a gap wider than 45 days (a clock fixed after a wrong jump forward) drops P.dmax; bad values are repaired',r,r==[True,0,True,True])
        r=await E("()=>{const t=new EC_RD();t.setDate(t.getDate()-3);P.dmax=ecKey(t);ecClockSync();return [P.dmax===ecKey(new EC_RD()),ecShift]}")
        chk('an older P.dmax moves forward to today',r,r==[True,0])

        # ---------------- the ledger ----------------
        async def fresh2(js=''):
            await E("()=>{RS_ASK=false;load({gold:5000});"+js+"save();title()}");await pg.wait_for_timeout(250)
        await fresh2()
        r=await E("()=>{const d=Object.getOwnPropertyDescriptor(P,'gold');return [!!(d.get&&d.set),d.enumerable,typeof JSON.parse(JSON.stringify(P)).gold,/\"gold\":\\d+/.test(JSON.stringify(P)),Object.getOwnPropertyDescriptor(Object.assign({},P),'gold').value===P.gold,structuredClone(P).gold===P.gold,Array.isArray(P.ldg),typeof P.ldgDay]}")
        chk('P.gold is an accessor that JSON, Object.assign and structuredClone still see as one plain number',r,r==[True,True,'number',True,True,True,True,'object'])
        r=await E("()=>{const n0=P.ldg.length;P.gold+=50;P.gold-=20;const a=ledgerRecent(2),t=ledgerToday();return [n0,a.length,a[0].d,a[1].d,a[0].bal===P.gold,a[0].src.split(':')[0],typeof a[0].t,t.earned[a[1].src],t.spent[a[0].src],t.day===wrDay()]}")
        chk('every change is recorded {t,d,bal,src}, newest first, with today\'s totals per source',r,r==[0,2,-20,50,True,'title','number',50,20,True])
        r=await E("()=>{ukSrc('crate',()=>{P.gold+=7});const a=ledgerRecent(1)[0];ukSrc('x',()=>ukSrc('y',()=>{P.gold+=1}));const b=ledgerRecent(1)[0];P.gold+=1;const c=ledgerRecent(1)[0];return [a.src,b.src,c.src]}")
        chk('ukSrc labels a grant (nested labels restore)',r,r==['title:crate','title:y','title'])
        r=await E("()=>new Promise(res=>{ukSrc('sticky');P.gold+=2;const a=ledgerRecent(1)[0].src;Promise.resolve().then(()=>Promise.resolve()).then(()=>{P.gold+=2;res([a,ledgerRecent(1)[0].src])})})")
        chk('ukSrc(label) without a function lasts only for the current task',r,r==['title:sticky','title'])
        r=await E("()=>{const n=P.ldg.length;P.gold=P.gold;P.gold+=0;return P.ldg.length===n}")
        chk('setting gold to the same value records nothing',r,r)
        r=await E("()=>{for(let i=0;i<250;i++)P.gold+=1;for(let i=0;i<60;i++)ukSrc('s'+i,()=>{P.gold+=1});return [P.ldg.length,ledgerRecent(500).length,Object.keys(ledgerToday().earned).length<=41,Object.keys(P.ldgDay.inc).length<=41,JSON.stringify(P.ldg).length<12000]}")
        chk('the ring stays at 100 entries and the per-source totals are bounded',r,r==[100,100,True,True,True])
        await E("()=>{start(1)}");await pg.wait_for_timeout(200)
        r=await E("()=>{S.gm=1;S.camp=1;gain(100);const a=ledgerRecent(1)[0];return [a.src.split(':')[0],a.d]}")
        chk('run gold is recorded under the game mode',r,r==['play',100])
        await fresh("delete P.wr;WRP().intro=1;P.xp=lvx(30);")
        rr=await E("()=>("+RUN+")('mill')")
        r=await E("()=>{const a=ledgerRecent(3);return [a[0].src,a[0].d]}")
        chk('a caravan payout is recorded with its label',[r,rr['total']],r[0]=='wagon:caravan' and r[1]==rr['total'])
        await fresh("P.xp=lvx(5)-10;")
        r=await E("()=>{calGrant({gold:80,xp:250});const a=ledgerRecent(2);return [a[0].src,a[0].d,a[1].src,a[1].d]}")
        chk('calendar grants are labelled calendar and the level-up gold levelup',r,r==['title:levelup',100,'title:calendar',80])

        # ---------------- save safety ----------------
        await fresh("P.gold=12345;")
        await E("()=>{for(let i=0;i<30;i++){P.gold+=3;P.gold-=1}save()}")
        r=await E("()=>{const s=JSON.parse(localStorage.getItem(KEY));return [typeof s.gold,s.gold===P.gold,Array.isArray(s.ldg)&&s.ldg.length<=100,s.ldg.length,typeof s.ldgDay]}")
        chk('stored save: gold is a plain number, the ledger arrays are bounded',r,r[0]=='number' and r[1] and r[2] and r[4]=='object')
        g=await E("()=>P.gold");n=await E("()=>P.ldg.length")
        await pg.reload();await pg.wait_for_timeout(1500)
        r=await E("()=>{const d=Object.getOwnPropertyDescriptor(P,'gold');return [P.gold,P.ldg.length,!!(d.get&&d.set),typeof JSON.parse(localStorage.getItem(KEY)).gold]}")
        chk('reload: gold and ledger come back, the accessor is back, nothing was recorded by loading',r,r==[g,n,True,'number'])
        r=await E("()=>{P.gold+=5;save();const s=JSON.parse(localStorage.getItem(KEY));return [s.gold===P.gold,s.ldg.length===Math.min(100,"+str(n)+"+1),s.ldg[s.ldg.length-1].d]}")
        chk('save -> reload -> save: new changes are recorded and stored',r,r==[True,True,5])
        r=await E("()=>{const o=[];for(const v of[NaN,undefined,'abc',null,-5,'12']){load({gold:v});const d=Object.getOwnPropertyDescriptor(P,'gold');o.push([P.gold,typeof P.gold,!!d.get,P.ldg.length])}return o}")
        chk('NaN, undefined, text, null and negative gold are clamped by the existing loader; the accessor is on the new P; no entry is recorded',r,r==[[0,'number',True,0],[0,'number',True,0],[0,'number',True,0],[0,'number',True,0],[0,'number',True,0],[12,'number',True,0]])
        r=await E("()=>{load({gold:500,ldg:[{t:1,d:5,bal:505,src:'a'},{t:2,d:-1,bal:504,src:'b'},{t:3,d:'x',bal:1,src:'c'},null,7,{t:4,d:1,bal:2,src:5}],ldgDay:{day:'2026-10-22',inc:{a:5,b:-2,c:'z'},out:{b:1}}});return [P.gold,P.ldg.map(e=>e.src),JSON.stringify(P.ldgDay)]}")
        chk('a saved ledger loads without gaining entries; invalid entries and totals are dropped',r,r[0]==500 and r[1]==['a','b'] and r[2]=='{"day":"2026-10-22","inc":{"a":5},"out":{"b":1}}')
        r=await E("()=>{load(JSON.parse('{\"gold\":3,\"ldg\":\"zzz\",\"ldgDay\":{\"day\":\"2026-10-22\",\"inc\":{\"__proto__\":5,\"a\":3},\"out\":[]}}'));return [P.ldg.length,Object.keys(P.ldgDay.inc),Object.keys(P.ldgDay.out),({}).a===undefined,Object.getPrototypeOf(P.ldgDay.inc)===Object.prototype]}")
        chk('hostile ledger data in a save is repaired (no prototype tricks)',r,r==[0,['a'],[],True,True])
        r=await E("()=>{const big=[];for(let i=0;i<500;i++)big.push({t:i,d:1,bal:i,src:'s'+i});load({gold:1,ldg:big});return [P.ldg.length,P.ldg[0].src,P.ldg[99].src]}")
        chk('an oversized ledger in a save is cut to the newest 100',r,r==[100,'s400','s499'])
        r=await E("()=>{load({});P.gold=777;P.gold+=1;const f=sgFileText();const rd=sgRead(f);return [rd.ok,rd.P&&rd.P.gold,typeof (rd.P||{}).gold]}")
        chk('export file and code: gold is a plain number and the import reads it back',r,r[0]==True and r[1]==778 and r[2]=='number')
        r=await E("()=>{load({gold:50});const old=P;load({gold:60});const p=P;const d1=Object.getOwnPropertyDescriptor(old,'gold'),d2=Object.getOwnPropertyDescriptor(p,'gold');const n=p.ldg.length;p.gold+=1;return [old!==p,!!d2.get,p.ldg.length-n,old.gold,p.gold]}")
        chk('load() replaces P: the new P gets its own accessor and records its own changes',r,r==[True,True,1,50,61])
        r=await E("()=>{load({gold:10});const P1=P;P.ldg=undefined;P.gold+=1;return [Array.isArray(P.ldg),P.ldg.length]}")
        chk('a missing ring is rebuilt on the next change',r,r==[True,1])
        r=await E("()=>{const f=fresh();P=f;P.gold=9;const had=!!Object.getOwnPropertyDescriptor(P,'gold').get;save();return [had,!!Object.getOwnPropertyDescriptor(P,'gold').get,P.gold]}")
        chk('if some code swaps P without load(), the next save() puts the accessor back',r,r==[False,True,9])
        await fresh()

        print('bad',bad);print(er)
        await b.close()
asyncio.run(main())
