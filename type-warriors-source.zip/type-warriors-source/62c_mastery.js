/* ---------- Bestiary Mastery and Shiny monsters ---------- */
const SHINY_RATE=1/64,RAINBOW_DIV=10,RAINBOW_COINS=1000;/* rainbow = 10x rarer than shiny (1 in 640), flat coin payout */
const rbHex=h=>{const f=n=>{const k=(n+h/30)%12,a=.5;return Math.round(255*(.5-a*Math.max(-1,Math.min(k-3,9-k,1))))};return '#'+[0,8,4].map(n=>f(n).toString(16).padStart(2,'0')).join('')};
const rbHue=e=>Math.round(((S.t||0)*160+(e.ph||0)*57)%360);
const MTIER=[{n:'Initiate',c:'#e8a062',c2:'#8a4a1a',g:150,r:'Trophy'},{n:'Adept',c:'#e8eef6',c2:'#7a8896',g:500,r:'Title'},{n:'Master',c:'#ffe07a',c2:'#c88a10',g:1500,r:'Tint'}];
const MKILL=[25,100,300],MFLAW=[0,0,0],BKILL=[3,10,25];
const MTINT=[['Frost',190],['Ember',335],['Verdant',90],['Royal',265],['Rose',305],['Gilded',42]];
const MRANK=[['Novice',0,0],['Tracker',.05,1],['Hunter',.15,1],['Stalker',.3,2],['Warden',.5,2],['Lorekeeper',.75,3],['Legend',1,4]];
const MBR=()=>P.bm||(P.bm={});
const mbRec=id=>{const b=MBR();return b[id]||(b[id]={f:0,sh:0,tn:0,t:0})};
const mbHash=id=>[...id].reduce((a,c)=>(a*31+c.charCodeAt(0))>>>0,7);
const mbBoss=id=>!!MON[id]&&!!MON[id].boss;
const mbIds=()=>{const s=new Set([...REG(),...BOSSES(),...RIFT_IDS,...GY_MOBS.flat(),...GY_BOSS]);return[...s].filter(k=>MON[k]&&!MON[k].nx)};
const mbKillT=id=>mbBoss(id)?BKILL:MKILL;
const mbTierOf=(id,k0,f0)=>{const r=(P.bm||{})[id]||{},k=k0!=null?k0:(P.bs[id]||0),f=f0!=null?f0:(r.f||0),K=mbKillT(id),F=mbBoss(id)?[0,0,0]:MFLAW;let t=0;for(let i=0;i<3;i++)if(k>=K[i]&&f>=F[i])t=i+1;else break;return t};
function mbInfo(id){const r=(P.bm||{})[id]||{},k=P.bs[id]||0,f=r.f||0,boss=mbBoss(id),K=mbKillT(id),F=boss?[0,0,0]:MFLAW,t=mbTierOf(id),nx=t<3?t:2;
 return{id,boss,k,f,sh:r.sh||0,tn:r.tn||0,t,K,F,nk:K[nx],nf:F[nx],pk:Math.min(1,k/K[nx]),pf:F[nx]?Math.min(1,f/F[nx]):1,seen:!!(P.sn[id]||P.bs[id]),done:t>=3,pct:t>=3?1:((t+Math.min(1,(Math.min(k/K[nx],1)+(F[nx]?Math.min(f/F[nx],1):1))/2))/3)}}
const mbTitleOf=id=>{const M=MON[id];return M?(M.boss?'Slayer of '+M.n:M.n+' Bane'):''};
const mbShHue=id=>150+mbHash(id)%170;
const mbTintHue=id=>{const r=(P.bm||{})[id];return r&&r.tn&&mbTierOf(id)>=3?MTINT[r.tn-1][1]:null};
const mbPoints=()=>mbIds().reduce((a,id)=>a+mbTierOf(id),0),mbMax=()=>mbIds().length*3;
function mbRankInfo(){const p=mbPoints(),m=mbMax(),fr=m?p/m:0;let i=0;for(let q=0;q<MRANK.length;q++)if(fr>=MRANK[q][1])i=q;const nx=MRANK[i+1];return{i,n:MRANK[i][0],p,m,fr,nxt:nx?nx[0]:'',need:nx?Math.ceil(nx[1]*m):m,prevN:Math.ceil(MRANK[i][1]*m)}}
/* filter used when a monster is drawn */
function monFilter(e,M){const h=e.hue||M.hue,s=[];if(h)s.push(`hue-rotate(${h}deg)`);const tn=e.sh?null:mbTintHue(e.id);if(e.rb)s.push(`hue-rotate(${rbHue(e)}deg) saturate(2) brightness(1.2)`);else if(e.sh)s.push(`hue-rotate(${mbShHue(e.id)}deg) saturate(1.5) brightness(1.12)`);else if(tn!=null)s.push(`hue-rotate(${tn}deg) saturate(1.12)`);return s.join(' ')}
function shinyChime(){try{[[1318,0],[1568,90],[2093,180],[2637,300],[3136,430]].forEach(([f,d])=>setTimeout(()=>{beep(f,.22,'sine',.5);beep(f*2,.12,'triangle',.18)},d))}catch(e){}}
function rainbowCaught(e){P.gold+=RAINBOW_COINS;S.gold+=RAINBOW_COINS;stat('gold',RAINBOW_COINS,'add');P.rbc=(P.rbc||0)+1;S.gp=.5;const cx=e.x,cy=e.y-e.h*.5;for(let i=0;i<6;i++)burst(cx,cy,`hsl(${i*60},100%,60%)`,22,{v:480+i*40,s:4});for(let i=0;i<3;i++)S.fx.push({k:'ring',x:cx,y:cy,t:0,ml:.7+i*.15,c:`hsl(${i*120},100%,65%)`,w:7,r0:20,r1:300+i*80});float(cx,e.y-e.h-170,'RAINBOW! +'+RAINBOW_COINS+' coins','#fff',46);S.shake=Math.max(S.shake,18);S.flash=Math.max(S.flash||0,.4);try{toast({t:3,n:'Rainbow monster slain!',d:'A 1 in 640 catch.',g:RAINBOW_COINS,lb:'Rare catch'})}catch(x){}}
function shinyCaught(e){if(e.rb)return rainbowCaught(e);const M=MON[e.id];burst(e.x,e.y-e.h*.5,'#fff1a0',60,{v:560,s:4});burst(e.x,e.y-e.h*.5,'#ffd24a',40,{v:420});S.fx.push({k:'ring',x:e.x,y:e.y-e.h*.5,t:0,ml:.7,c:'#ffe27a',w:7,r0:20,r1:300});float(e.x,e.y-e.h-170,'SHINY! x5 gold','#ffe27a',42);S.shake=Math.max(S.shake,12);try{[[988,0],[1318,90],[1568,180],[1976,270],[2637,380]].forEach(([f,d])=>setTimeout(()=>beep(f,.2,'triangle',.6),d))}catch(x){}}
/* kill bookkeeping, called from kill() for ordinary kills */
function mastKill(e,flawless){if(e.mn||S.prac||S.dc||S.bg)return;const id=e.id,r=mbRec(id),was=mbTierOf(id,(P.bs[id]||1)-1,r.f||0);if(flawless&&!e.boss)r.f=(r.f||0)+1;
 if(e.sh){r.sh=(r.sh||0)+1;P.shc=(P.shc||0)+1;shinyCaught(e)}
 const now=mbTierOf(id);if(now>was){for(let t=was;t<now;t++){P.gold+=MTIER[t].g;stat('gold',MTIER[t].g,'add');toast({t:t+1>3?3:t,n:MON[id].n+': '+MTIER[t].n,d:t===0?'Trophy earned for this monster.':t===1?'Title unlocked: '+mbTitleOf(id)+'.':'Master tint unlocked. Choose it in the Bestiary.',g:MTIER[t].g,lb:'Bestiary mastery'})}
  const ri=mbRankInfo();if((P.mrk||0)<ri.i){for(let q=(P.mrk||0)+1;q<=ri.i;q++){const rw=MRANK[q][2];if(rw===1)P.acr=(P.acr||0)+1;else if(rw===2)P.scr=(P.scr||0)+1;else if(rw===3)P.scr=(P.scr||0)+2;else if(rw===4)P.pcr=(P.pcr||0)+1;toast({t:3,n:'Bestiary rank: '+MRANK[q][0],d:rw===4?'An Eclipse Chest awaits in your collection.':'A crate was added to your collection.',g:0,lb:'Rank up'})}P.mrk=ri.i}save();try{achCheck()}catch(x){}}}
const mbShinyDrop=(e,flawless)=>{const q=Math.random();return flawless?(q<.5?'s':'a'):(q<.4?'a':q<.8?'w':'s')};
/* ---------- shared UI pieces ---------- */
const mbCn=n=>Math.floor(n).toLocaleString();
function mbGem(t,on,sz){sz=sz||22;const c=MTIER[t];return `<svg class="mbg${on?' on':''}" viewBox="0 0 24 24" width="${sz}" height="${sz}" aria-hidden="true"><defs><linearGradient id="mg${t}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${c.c}"/><stop offset="1" stop-color="${c.c2}"/></linearGradient></defs><path d="M12 1.5l9 6.2v8.6l-9 6.2-9-6.2V7.7z" fill="${on?`url(#mg${t})`:'#2a2248'}" stroke="${on?c.c:'#4a3e80'}" stroke-width="1.4" stroke-linejoin="round"/>${on?`<path d="M12 4.5l5.8 4v6.6L12 19.2 6.2 15.1V8.5z" fill="none" stroke="#ffffff66" stroke-width=".9"/><path d="M8 9l4-3 2 2" stroke="#fff" stroke-opacity=".7" stroke-width="1.2" fill="none" stroke-linecap="round"/>`:`<circle cx="12" cy="12" r="2.2" fill="#4a3e80"/>`}</svg>`}
const mbGems=(id,sz)=>{const t=mbTierOf(id);return `<span class="mbgems" title="${t} of 3 mastery tiers">${[0,1,2].map(i=>mbGem(i,i<t,sz)).join('')}</span>`};
const mbBar=(p,cls)=>`<span class="mbbar ${cls||''}"><i style="width:${Math.round(p*100)}%"></i></span>`;
const mbStar=(sz)=>`<svg class="mbst" viewBox="0 0 24 24" width="${sz||16}" height="${sz||16}" aria-hidden="true"><path d="M12 1l2.6 8.4L23 12l-8.4 2.6L12 23l-2.6-8.4L1 12l8.4-2.6z" fill="#ffe27a" stroke="#c88a10" stroke-width="1"/></svg>`;
function mbPort(id,w,h,sh){const i=mbInfo(id),hue=sh?mbShHue(id):mbTintHue(id);return `<canvas class="mbpt${i.seen?'':' nsn'}${sh?' shn':''}" width="${w*2}" height="${h*2}" style="width:${w}px;height:${h}px${hue!=null?`;filter:hue-rotate(${hue}deg) saturate(${sh?1.5:1.12})`:''}" data-mb="${id}"></canvas>`}
function mbRoles(id){return MROLE(id).map(r=>`<u>${r}</u>`).join('')}
function mbReq(id,t){const K=mbKillT(id),F=mbBoss(id)?0:MFLAW[t];return `${K[t]} slain${F?` and ${F} flawless`:''}`}
function mbRewardTxt(id,t){return t===0?'Trophy · +'+MTIER[0].g+' gold':t===1?'Title · +'+MTIER[1].g+' gold':'Six tints · +'+MTIER[2].g.toLocaleString()+' gold'}
function mbLadder(id){const i=mbInfo(id);return `<div class="mbld">${[0,1,2].map(t=>{const on=i.t>t,cur=i.t===t;return `<div class="mbrw${on?' on':''}${cur?' cur':''}">${mbGem(t,on,30)}<div><b>${MTIER[t].n}<i>${mbReq(id,t)}</i></b><small>Reward: ${mbRewardTxt(id,t)}</small></div>${on?'<em>Done</em>':cur?'<em class="nx">Next</em>':'<em class="lk">Locked</em>'}</div>`}).join('')}</div>`}
function mbProg(id){const i=mbInfo(id);if(i.done)return `<p class="mbdone"><b>${mbCn(i.k)}</b> slain</p>`;return `<div class="mbpg"><div><span>Slain</span>${mbBar(i.pk)}<b>${mbCn(Math.min(i.k,i.nk))} / ${i.nk}</b></div>${i.boss||!i.nf?'':`<div><span>Flawless words</span>${mbBar(i.pf,'fw')}<b>${mbCn(Math.min(i.f,i.nf))} / ${i.nf}</b></div>`}</div>`}
function mbCtl(id){const i=mbInfo(id),r=(P.bm||{})[id]||{},eq=P.ttl===id;let h='';
 if(i.t>=2)h+=`<div class="mbctl"><span>Title</span><button class="mbeq${eq?' on':''}" data-eq="${id}">${eq?'Equipped: ':'Equip: '}${esc(mbTitleOf(id))}</button></div>`;
 if(i.t>=3)h+=`<div class="mbctl"><span>Tint</span><span class="mbsw"><button class="mbs0${r.tn?'':' on'}" data-tn="${id}:0" title="Original colors" aria-label="Original colors">Off</button>${MTINT.map((q,n)=>`<button style="--h:${q[1]}" class="${r.tn===n+1?'on':''}" data-tn="${id}:${n+1}" title="${q[0]}" aria-label="${q[0]} tint"></button>`).join('')}</span></div>`;
 if(!h)h=`<p class="mbhint">${i.t===0?'Slay it '+(i.K[0]-Math.min(i.k,i.K[0]))+' more time'+((i.K[0]-i.k)===1?'':'s')+' to earn its trophy.':'Reach Adept to unlock a title, then Master for tints.'}</p>`;return h}
const mbShiny=id=>{const i=mbInfo(id);return `<div class="mbsh${i.sh?' got':''}" title="${i.sh?'Shiny caught':'About 1 in 64 monsters is a shiny'}">${mbStar(15)}<span>${i.sh?`Shiny <b>x${i.sh}</b>`:'No shiny yet'}</span></div>`};
function mbDetail(id){const M=MON[id],i=mbInfo(id);if(!i.seen)return `<div class="mbdt"><div class="mbdh">${mbPort(id,100,100)}<div><h3>???</h3><p class="mbhint">Meet this monster in a run to start its mastery.</p></div></div></div>`;
 return `<div class="mbdt"><div class="mbdh">${mbPort(id,100,100)}<div><h3>${esc(M.n)}${i.done?'<span class="mbmast">Mastered</span>':''}</h3><em class="mbro">${mbRoles(id)}</em><p>${esc(M.ds||(M.tr?TRN[M.tr]:M.boss?'A zone boss.':M.fly?'Flies straight at you.':M.pj?'Hurls projectiles.':'Marches on the hero.'))}</p><div class="mbbd">${mbGems(id,24)}${mbShiny(id)}</div></div></div>${mbProg(id)}${mbLadder(id)}${mbCtl(id)}</div>`}
function mbWire(root,again){root.querySelectorAll('[data-eq]').forEach(b=>b.onclick=e=>{e.stopPropagation();const id=b.dataset.eq;P.ttl=P.ttl===id?'':id;if(P.ttl&&P.bty)P.bty.title='';save();again()});
 root.querySelectorAll('[data-tn]').forEach(b=>b.onclick=e=>{e.stopPropagation();const [id,n]=b.dataset.tn.split(':');mbRec(id).tn=+n;save();again()});
 root.querySelectorAll('canvas[data-mb]').forEach(cv=>{try{fitThumb(cv,cv.dataset.mb)}catch(e){}})}
function mbGroups(){const R=new Set(REG()),all=new Set(mbIds()),used=new Set(),G=[];const add=(n,ids,c)=>{ids=ids.filter(k=>all.has(k)&&!used.has(k));ids.forEach(k=>used.add(k));if(ids.length)G.push({n,ids,c})};
 ZN2.forEach((n,z)=>add(n,[...new Set(ZR[z].flat())],''));add('Starfall Rift',RIFT_IDS,'#c88aff');add('Monster Mash',[...GY_MOBS.flat(),...GY_BOSS],'#7affc8');add('Bosses',BOSSES(),'#ff8a6a');add('Other',[...all],'');return G}
function mbSummary(){const r=mbRankInfo(),sh=mbIds().filter(k=>((P.bm||{})[k]||{}).sh).length,ms=mbIds().filter(k=>mbTierOf(k)>=3).length,pr=r.nxt?(r.p-r.prevN)/Math.max(1,r.need-r.prevN):1;
 return `<div class="mbsum"><div class="mbrk"><i>Bestiary rank</i><b>${r.n}</b></div><div class="mbrb"><span>${r.p} of ${r.m} gems${r.nxt?` · next rank <b>${r.nxt}</b> at ${r.need}`:' · maximum rank'}</span>${mbBar(Math.max(0,Math.min(1,pr)))}</div><div class="mbmini"><div><b>${ms}</b><span>Mastered</span></div><div><b>${sh}</b><span>Shinies</span></div><div><b>${mbCn(P.shc||0)}</b><span>Shiny kills</span></div></div></div>`}

function rbRoll(e,M){const sr=window.__shr!=null?window.__shr:SHINY_RATE,rr=window.__rbr!=null?window.__rbr:sr/RAINBOW_DIV,q=Math.random();if(q<rr)rainbowMake(e,M);else if(q<sr)shinyMake(e,M)}
function rainbowMake(e,M){e.sh=1;e.rb=1;try{[[1046,0],[1318,70],[1568,140],[1976,210],[2349,280],[2637,360],[3136,460],[3951,580]].forEach(([f,d])=>setTimeout(()=>{beep(f,.24,'sine',.5);beep(f*1.5,.12,'triangle',.2)},d))}catch(x){}S.tip={t:4.2,txt:'A RAINBOW '+M.n+' appeared! Slay it for '+RAINBOW_COINS+' coins!'}}
function shinyMake(e,M){e.sh=1;shinyChime();if(!S.tip||S.tip.t<=0)S.tip={t:3.2,txt:'A shiny '+M.n+' appeared! Type its word flawlessly for a rare drop.'}}
function shinyFx(e,cy){const g=ctx,t=S.t,h=e.h;g.save();for(let i=0;i<7;i++){const u=(t*.7+i*.37+e.ph)%1,a=Math.sin(u*Math.PI),ang=i*2.4+e.ph,rx=h*.34*(.5+((i*7)%5)/5),x=e.x+Math.cos(ang+t*.6)*rx,y=cy+Math.sin(ang*1.3+t*.5)*h*.42,r=(4+(i%3)*2.4)*a*(h>150?1.5:1);if(r<.6)continue;g.globalAlpha=.9*a;g.fillStyle=e.rb?`hsl(${(rbHue(e)+i*50)%360},100%,70%)`:i%2?'#fff6c0':'#ffffff';g.beginPath();g.moveTo(x,y-r*2);g.quadraticCurveTo(x,y,x+r*2,y);g.quadraticCurveTo(x,y,x,y+r*2);g.quadraticCurveTo(x,y,x-r*2,y);g.quadraticCurveTo(x,y,x,y-r*2);g.fill()}
 g.globalAlpha=.9;const by=e.y-h-26+Math.sin(t*4+e.ph)*4;g.translate(e.x,by);g.rotate(Math.sin(t*2+e.ph)*.12);g.fillStyle=e.rb?`hsl(${rbHue(e)},100%,62%)`:'#ffe27a';g.strokeStyle=e.rb?'#fff':'#8a5a08';g.lineWidth=2;if(e.rb)g.scale(1.4,1.4);g.beginPath();for(let i=0;i<8;i++){const a=i*Math.PI/4-Math.PI/2,r=i%2?5:12;g.lineTo(Math.cos(a)*r,Math.sin(a)*r)}g.closePath();g.fill();g.stroke();g.restore()}
