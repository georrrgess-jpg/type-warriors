/* ---------- the vault dragon: a front-facing golden dragon painted as separate layers ---------- */
const VX=1080,VY=164;                       /* head origin (the eye line) in scene space */
function vSym(R){const n=R.length/2,o=R.slice();for(let i=n-2;i>=1;i--)o.push(-R[i*2],R[i*2+1]);return o}
const vsg=(a,s)=>a.map((v,i)=>i&1?v:v*s);
/* soft volume lights painted inside a shape */
function vForm(g,pf,L){g.save();g.beginPath();pf(g);g.clip();for(const s of L){const q=g.createRadialGradient(s[0],s[1],0,s[0],s[1],s[2]);q.addColorStop(0,s[3]);q.addColorStop(1,s[3].replace(/[\d.]+\)$/,'0)'));g.fillStyle=q;g.fillRect(s[0]-s[2],s[1]-s[2],s[2]*2,s[2]*2)}g.restore()}
/* metal-scale skin: fill, scale texture, form lights, edge shade, key light, reflected firelight, outline */
function vPaint(g,pf,bb,o){o=o||{};
 g.save();g.beginPath();pf(g);g.fillStyle=o.fill||'#d89a2a';g.fill();g.restore();
 cdScales(g,pf,bb[0],bb[1],bb[2],bb[3],o.s||12,'rgba(84,28,0,.58)','rgba(255,232,140,.5)',o.seed||0);
 if(o.form)vForm(g,pf,o.form);
 cdIn(g,pf,'rgba(24,4,0,.92)',-(o.sh||0),-(o.sh||0)*.3,o.shb||26);
 cdIn(g,pf,'rgba(255,226,130,.9)',o.hl||8,(o.hl||8)*.6,o.hlb||14);
 if(o.fire)cdIn(g,pf,'rgba(255,110,24,.7)',0,-(o.fire),o.fire*1.4);
 if(o.rim!==0)cdIn(g,pf,'rgba(255,182,86,.8)',0,0,4);
 g.save();g.beginPath();pf(g);g.lineJoin='round';g.lineWidth=o.ol||4.5;g.strokeStyle='#190601';g.stroke();g.restore()}
function vGrade(g,x,y,r,a){g.save();g.globalCompositeOperation='source-atop';const q=g.createRadialGradient(x,y,r*.25,x,y,r);q.addColorStop(0,'rgba(18,4,8,0)');q.addColorStop(1,'rgba(18,4,8,'+a+')');g.fillStyle=q;g.fillRect(x-r*2,y-r*2,r*4,r*4);g.restore()}
const vBoth=fn=>{fn(1);fn(-1)};
const vPoly=(g,p,s,f,ol)=>poly(g,vsg(p,s),f,'#190601',ol||3.4);
/* ----- the frill fins behind the cheeks ----- */
function vFin(g,s){
 const O=[118*s,-24],T=[[262,-104],[300,-40],[290,34],[252,96]].map(p=>[p[0]*s,p[1]]),B=[130*s,70];
 const mem=gg=>{gg.moveTo(O[0],O[1]);gg.lineTo(T[0][0],T[0][1]);for(let i=1;i<T.length;i++){const a=T[i-1],b=T[i];gg.quadraticCurveTo((a[0]+b[0])/2-22*s,(a[1]+b[1])/2,b[0],b[1])}gg.lineTo(B[0],B[1]);gg.closePath()};
 g.save();g.beginPath();mem(g);g.fillStyle=rgr(g,150*s,10,10,170,'#d8402a','#3a0612');g.fill();g.clip();
 g.strokeStyle='rgba(255,190,110,.3)';g.lineWidth=2;for(const t of T){g.beginPath();g.moveTo(O[0],O[1]+30);g.lineTo(t[0],t[1]);g.stroke()}
 cdIn(g,mem,'rgba(18,0,6,.95)',0,0,26);g.restore();
 g.save();g.beginPath();mem(g);g.lineJoin='round';g.lineWidth=4;g.strokeStyle='#190601';g.stroke();g.restore();
 for(const t of T){const dx=t[0]-O[0],dy=t[1]-O[1],L=Math.hypot(dx,dy),nx=-dy/L*7,ny=dx/L*7;
  g.beginPath();g.moveTo(O[0]+nx*.8,O[1]+30+ny*.8);g.lineTo(t[0]+dx/L*14,t[1]+dy/L*14);g.lineTo(O[0]-nx*.8,O[1]+30-ny*.8);g.closePath();
  g.fillStyle=hgr(g,Math.min(O[0],t[0]),Math.max(O[0],t[0])+1,'#f8d060','#9a5a14');g.fill();g.lineWidth=3;g.strokeStyle='#190601';g.stroke()}}
/* ----- horns, crest and cheek spikes that sit behind the skull ----- */
function vHornsBack(g){g.save();g.translate(VX,VY);
 vBoth(s=>{
  const H=(u,l,w,c0,c1)=>cdHorn(g,vsg(u,s),vsg(l,s),w,c0||'#f2e4be','#a88850',4.6);
  /* great swept horn */
  H([96,-96,140,-136,206,-156,268,-150,318,-118],[134,-62,176,-96,226,-114,276,-112,318,-118],40);
  /* shorter upward horn */
  H([60,-104,66,-150,92,-200,126,-232],[98,-98,98,-146,112,-196,126,-232],26);
  /* cheek spikes */
  H([138,0,184,18,228,52,250,98],[142,48,176,56,214,78,250,98],24);
  H([128,44,160,74,184,116,190,156],[124,80,150,100,172,130,190,156],18);
  H([148,-12,168,-16,190,-12],[150,10,172,6,190,-12],14);H([146,70,166,84,184,104],[132,96,156,98,184,104],14);H([112,100,126,122,134,146],[96,118,114,134,134,146],12);
 });
 for(const s of[1,-1]){g.save();vFin(g,s);g.restore()}
 g.restore()}
/* ----- cranium and cheeks ----- */
const vCran=g=>cdCR(g,vSym([0,-116, 56,-112, 106,-94, 138,-62, 152,-14, 148,40, 128,86, 84,118, 0,130]),true);
function vSkull(g){g.save();g.translate(VX,VY);
 vPaint(g,vCran,[-170,-130,170,150],{fill:rgr(g,-26,-70,10,230,'#ffd058','#7a3808'),s:11,seed:5,sh:30,shb:34,hl:11,hlb:18,fire:10,
  form:[[-70,-76,120,'rgba(255,244,180,.4)'],[-58,-92,34,'rgba(255,255,230,.5)'],[58,-100,28,'rgba(255,255,230,.3)'],[120,30,130,'rgba(36,6,0,.45)'],[-100,40,70,'rgba(255,230,140,.12)'],[0,128,90,'rgba(255,120,30,.28)']]});
 /* bony cheek plates */
 vBoth(s=>{for(let i=0;i<4;i++){const y=-34+i*26,w=i===3?-6:0;
   vPoly(g,[110,y,140,y+2,152,y+14,142,y+28,112,y+22+w],s,hgr(g,104*s,152*s,'#f4c04c','#9a5412'),3);
   g.beginPath();g.moveTo(s*118,y+5);g.lineTo(s*142,y+8);g.lineWidth=2;g.strokeStyle='rgba(255,246,200,.7)';g.stroke()}
  vPoly(g,[96,66,120,76,124,100,96,106,84,86],s,hgr(g,86*s,130*s,'#f0b840','#9a561a'))});
 /* crest between the brows */
 vBoth(s=>{cdHorn(g,vsg([20,-110,26,-150,40,-190],s),vsg([40,-108,42,-148,40,-190],s),18,'#f2e4be','#a88850',4);});
 cdHorn(g,[-14,-112,-10,-170,0,-224],[14,-112,10,-170,0,-224],26,'#f6ecc8','#b09050',4.4);
 /* ruby set in the forehead */
 g.beginPath();g.moveTo(0,-122);g.lineTo(18,-100);g.lineTo(0,-78);g.lineTo(-18,-100);g.closePath();g.fillStyle=vgr(g,-122,-78,'#fbd860','#8a4c10');g.fill();g.lineWidth=3.4;g.strokeStyle='#190601';g.stroke();
 cdGem(g,0,-100,12,'#e8142e',3);
 vGrade(g,-40,-70,300,.55);
 g.restore()}
/* ----- muzzle with ridge, nostrils and upper fangs ----- */
const vMuz=g=>cdCR(g,vSym([0,-90, 22,-84, 36,-62, 44,-26, 56,16, 70,52, 86,84, 68,100, 36,96, 0,88]),true);
function vMuzzle(g){g.save();g.translate(VX,VY);
 /* upper fangs sit behind the lip */
 for(const t of[[84,86,26,12,.2],[62,94,56,22,.1],[36,92,36,16,.04],[12,88,24,12,0]]){cdTooth(g,t[0],t[1],t[2],t[3],t[4]);cdTooth(g,-t[0],t[1],t[2],t[3],-t[4])}
 vPaint(g,vMuz,[-90,-100,90,110],{fill:rgr(g,-10,-30,8,180,'#ffe07c','#8c4c10'),s:10,seed:21,sh:22,shb:24,hl:9,hlb:14,fire:8,
  form:[[-14,-46,40,'rgba(255,255,230,.5)'],[-20,-40,70,'rgba(255,246,190,.34)'],[60,40,60,'rgba(34,6,0,.55)'],[-62,40,40,'rgba(34,6,0,.3)'],[0,96,40,'rgba(34,6,0,.4)']]});
 /* nasal ridge */
 g.save();g.beginPath();vMuz(g);g.clip();
 const rg=g.createLinearGradient(-14,0,14,0);rg.addColorStop(0,'rgba(255,250,200,0)');rg.addColorStop(.35,'rgba(255,246,190,.55)');rg.addColorStop(.7,'rgba(90,40,0,.35)');rg.addColorStop(1,'rgba(90,40,0,0)');
 g.fillStyle=rg;g.beginPath();g.moveTo(-10,-88);g.lineTo(10,-88);g.lineTo(18,60);g.lineTo(-18,60);g.closePath();g.fill();g.restore();
 vBoth(s=>{g.beginPath();g.moveTo(s*18,-74);g.quadraticCurveTo(s*34,-20,s*44,44);g.lineWidth=3;g.strokeStyle='rgba(60,20,0,.55)';g.stroke();g.beginPath();g.moveTo(s*16,-74);g.quadraticCurveTo(s*32,-20,s*42,44);g.lineWidth=1.6;g.strokeStyle='rgba(255,240,170,.5)';g.stroke()});
 /* nostrils */
 vBoth(s=>{g.save();g.translate(24*s,56);g.rotate(-.55*s);g.beginPath();g.ellipse(0,0,12,5.6,0,0,TAU);g.fillStyle='#160401';g.fill();g.lineWidth=2.6;g.strokeStyle='#6a3208';g.stroke();
  g.beginPath();g.ellipse(0,-5,13,4,0,Math.PI,TAU);g.strokeStyle='rgba(255,226,130,.7)';g.lineWidth=2;g.stroke();g.restore()});
 /* lip line */
 g.beginPath();cdCR(g,[-86,84,-68,100,-36,96,0,88,36,96,68,100,86,84],false);g.lineWidth=3.4;g.strokeStyle='#190601';g.stroke();
 g.restore()}
/* ----- lower jaw: drawn lowered by the animation, lower fangs on top ----- */
const vJawTop=[-102,70,-76,102,-40,120,0,128,40,120,76,102,102,70];
function vJawPath(g){g.moveTo(-102,70);cdCR(g,vJawTop,false,false);cdCR(g,[102,70,114,86,114,114,90,146,46,172,0,184,-46,172,-90,146,-114,114,-114,86,-102,70],false,false);g.closePath()}
function vJaw(g){g.save();g.translate(VX,VY);
 vBoth(s=>{cdHorn(g,vsg([108,92,136,104,160,128],s),vsg([112,116,136,124,160,128],s),16,'#f2e4be','#a88850',3.6);cdHorn(g,vsg([92,130,116,148,130,176],s),vsg([96,152,114,164,130,176],s),14,'#f2e4be','#a88850',3.4)});
 vPaint(g,vJawPath,[-140,60,140,200],{fill:vgr(g,70,190,'#e8a030','#a8601a'),s:11,seed:11,sh:20,shb:22,hl:8,hlb:12,fire:8,
  form:[[-40,100,90,'rgba(255,240,170,.3)'],[70,150,80,'rgba(36,6,0,.4)']]});
 /* throat plates under the chin */
 for(let i=0;i<3;i++){const y=140+i*13;g.beginPath();g.moveTo(-60+i*14,y);g.quadraticCurveTo(0,y+12,60-i*14,y);g.lineWidth=2.4;g.strokeStyle='rgba(90,40,0,.55)';g.stroke()}
 /* chin horn */
 cdHorn(g,[-12,170,-8,196,0,214],[12,170,8,196,0,214],24,'#f2e4be','#a88850',4);
 /* lower fangs */
 for(const t of[[88,92,22,11,.08],[66,106,40,17,.04],[38,118,26,13,.02],[14,124,17,10,0]]){cdTooth(g,t[0],t[1],-t[2],t[3],-t[4]);cdTooth(g,-t[0],t[1],-t[2],t[3],t[4])}
 g.restore()}
/* ----- brow ridges (drawn over the eyes) ----- */
function vBrows(g){g.save();g.translate(VX,VY);
 vBoth(s=>{
  const bp=gg=>{const p=vsg([8,-26,44,-42,84,-52,118,-46,140,-58,134,-88,100,-102,58,-92,18,-66],s);cdCR(gg,p,true)};
  vPaint(g,bp,[-150,-110,150,-20],{fill:hgr(g,10*s,140*s,'#f6cc58','#a8641a'),s:9,seed:31+s,sh:14,shb:14,hl:7,hlb:9,fire:0,ol:4.2,
   form:[[40*s,-80,50,'rgba(255,246,190,.35)']]});
  /* brow spikes */
  cdHorn(g,vsg([66,-92,66,-120,76,-142],s),vsg([88,-94,84,-120,76,-142],s),14,'#f2e4be','#a88850',3.4);
  cdHorn(g,vsg([100,-98,106,-126,124,-148],s),vsg([122,-92,122,-122,124,-148],s),14,'#f2e4be','#a88850',3.4)});
 g.restore()}
/* ----- an eye socket's static base (dark pit) ----- */
const vEyeP=[30,-12,50,-28,80,-36,110,-30,90,-12,58,-7];
function vEyePath(g,s){cdCR(g,vsg(vEyeP,s),true)}
function vSockets(g){g.save();g.translate(VX,VY);
 vBoth(s=>{g.beginPath();cdCR(g,vsg([22,-10,48,-34,82,-44,118,-34,94,-4,54,6],s),true);g.fillStyle='#220802';g.fill();g.lineWidth=3;g.strokeStyle='#190601';g.stroke()});
 g.restore()}
