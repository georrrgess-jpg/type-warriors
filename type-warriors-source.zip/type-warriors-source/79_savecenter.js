/* ---------- Save Center: the screen, the dialogs and the warning chip ---------- */
HIC.save='<path d="M5 3h11l3 3v15H5z"/><path d="M8 3v5h7V3M8 21v-7h8v7"/>';
const sgAgo=t=>{const s=Math.max(0,(Date.now()-t)/1000);return s<45?'just now':s<3300?Math.round(s/60)+' min ago':s<82800?Math.round(s/3600)+' h ago':Math.round(s/86400)+' day'+(Math.round(s/86400)===1?'':'s')+' ago'};
const sgDate=t=>{try{return new Date(t).toLocaleString(undefined,{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'})}catch(e){return''}};
const sgKB=n=>n<1024?n+' B':(n/1024).toFixed(n<10240?1:0)+' KB';
const sgNum=n=>Math.round(+n||0).toLocaleString();

/* a dialog that cannot be missed and cannot be triggered by game keys; resolves with the chosen value */
function sgModal(o){return new Promise(res=>{
 const old=document.getElementById('svm');if(old)old.remove();const prev=document.activeElement;
 const el=document.createElement('div');el.id='svm';el.setAttribute('role','dialog');el.setAttribute('aria-modal','true');el.setAttribute('aria-label',o.title);
 el.innerHTML=`<div class="svb"><h3>${o.title}</h3><div class="svx">${o.html||''}</div><div class="svr">${o.buttons.map((b,i)=>`<button class="sm ${b.cls||''}" data-i="${i}">${b.t}</button>`).join('')}</div></div>`;
 wrap.appendChild(el);
 const done=v=>{window.removeEventListener('keydown',kd,true);el.remove();try{prev&&prev.focus&&prev.focus()}catch(e){}res(v)};
 const kd=e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();if(o.esc!==undefined)done(o.esc);return}
  if(e.key==='Tab'){const f=[...el.querySelectorAll('button,textarea,input')].filter(x=>!x.disabled);if(!f.length)return;const i=f.indexOf(document.activeElement);e.preventDefault();e.stopPropagation();f[(i+(e.shiftKey?-1:1)+f.length)%f.length].focus();return}
  e.stopPropagation()};
 window.addEventListener('keydown',kd,true);
 el.querySelectorAll('.svr button').forEach(b=>b.onclick=()=>done(o.buttons[+b.dataset.i].v));
 const bs=el.querySelectorAll('.svr button');(bs[o.focus==null?0:o.focus]||bs[0]).focus();
 if(o.init)o.init(el)})}

/* ----- a short notice at the bottom of the screen ----- */
let sgNT=0;
function sgNote(msg){let el=document.getElementById('svt');if(!el){el=document.createElement('div');el.id='svt';el.setAttribute('role','status');el.onclick=()=>el.classList.remove('on');wrap.appendChild(el)}
 el.textContent=msg;void el.offsetWidth;el.classList.add('on');clearTimeout(sgNT);sgNT=setTimeout(()=>el.classList.remove('on'),8000)}

/* ----- the warning chip: only exists while something is wrong ----- */
function sgProblem(){if(SGS.stale)return{k:'stale',t:'Save changed in another window'};if(SGS.mem)return{k:'mem',t:'Progress is not being saved'};if(SGS.fail)return{k:'fail',t:'Could not save. Storage may be full'};return null}
function sgChipUpd(){const pr=sgProblem();let el=document.getElementById('svw');
 if(!pr){if(el)el.remove();return}
 if(!el){el=document.createElement('button');el.id='svw';el.onclick=()=>{if(SGS.stale)sgStaleUI();else if(S.mode==='play')pause();else saveCenter(S.mode==='pause'?(()=>settings(S.back)):title)};wrap.appendChild(el)}
 if(el.dataset.k!==pr.k){el.dataset.k=pr.k;el.innerHTML=`${hico('save',18)}<span>${pr.t}</span><u>Tap to fix</u>`}}
let sgStaleOpen=0;
async function sgStaleUI(){if(sgStaleOpen)return;sgStaleOpen=1;sgChipUpd();try{if(S.mode==='play')pause()}catch(e){}
 const v=await sgModal({title:'Your save changed in another window',html:'<p>Type Warriors is open somewhere else and saved newer progress. If you keep playing here, that progress could be overwritten.</p><p><b>Reload</b> continues from the newest progress. Choose <b>Keep this window</b> only if this is the one you want. The other version is kept as a backup either way.</p>',buttons:[{t:'Keep this window',v:'keep'},{t:'Reload (recommended)',v:'reload',cls:'hgd'}],focus:1});
 sgStaleOpen=0;
 if(v==='keep'){const raw=sgGet(KEY);if(raw)sgSnapStr(raw,'From another window','safe');SGS.stale=false;save();sgChipUpd();sgNote('This window now owns your save. The other version is in your backups.')}
 else{try{location.reload()}catch(e){}}}

/* ----- comparing a save with the current one ----- */
function sgCompare(inc,cur,notes){const rows=[['Hero','name'],['Level','lvl'],['Prestige','pres'],['Campaign levels cleared','cl'],['Stars','st'],['Gold','gold'],['Weapons owned','w'],['Armor owned','a'],['Trophies','t']];
 const f=(k,v)=>k==='gold'?sgNum(v):k==='name'?esc(v):k==='cl'?v+' / 30':v;
 return `<table class="svcmp"><thead><tr><th></th><th>Now</th><th></th><th>Incoming</th></tr></thead><tbody>${rows.map(([l,k])=>{const a=cur[k],b=inc[k],c=k==='name'||a===b?'':b>a?'up':'dn';return `<tr><td>${l}</td><td>${f(k,a)}</td><td>${a===b?'':'›'}</td><td class="${c}">${f(k,b)}</td></tr>`}).join('')}</tbody></table>${notes||''}`}

/* ----- replacing the save, with a preview and an undo ----- */
async function sgConfirmInstall(np,o){
 const inc=sgInfo(np),cur=sgInfo(P),behind=inc.prog<cur.prog*.9&&!sgTrivial();
 const meta=o.verified?`Verified save file${o.exported?' from '+esc(sgDate(o.exported)):''}.`:o.backup?`Backup from ${esc(sgDate(o.backup.t))}.`:'Older save file without an integrity check. It passed the structure checks, and your current progress is backed up first.';
 const html=`<p class="svl">${meta}</p>${sgCompare(inc,cur,`${behind?'<p class="svw">This save is behind your current progress. Importing it replaces what you have now.</p>':''}<p class="svl">Your current progress is saved as a safety copy first, so you can undo this from the Save Center.</p>`)}`;
 const v=await sgModal({title:o.title,html,buttons:[{t:'Cancel',v:0},{t:o.confirm,v:1,cls:behind?'dg':'hgd'}],focus:0,esc:0});
 if(!v)return false;
 const r=sgInstall(np,o.why,!!o.risky);
 if(!r.ok){await sgModal({title:'Nothing was changed',html:`<p>${esc(r.msg)}</p>`,buttons:[{t:'OK',v:1}],esc:1});return false}
 const inplace=()=>{SGS.lock=false;load(r.P);SGS.last=JSON.stringify(P);sgChipUpd();title()};
 if(SGS.mem){inplace();sgNote('Loaded. Your progress is not stored by this browser, so export it to keep it.');return true}
 sgNote('Save loaded. Restarting the game…');setTimeout(()=>{try{location.reload()}catch(e){inplace()}},700);setTimeout(inplace,2600);return true}

/* ----- the screen ----- */
function sgStatus(){const pr=sgProblem();
 if(pr&&pr.k==='mem')return{c:'bad',h:'Progress is not being saved',p:'This browser is blocking storage for the game (private browsing or an embedded page can do this). Everything works, but closing the page loses it. Export your save regularly to keep it.'};
 if(pr&&pr.k==='fail')return{c:'warn',h:'The last save did not go through',p:'The browser refused the write, most likely because storage is full. Export your save now and clear some browser data.'};
 if(pr&&pr.k==='stale')return{c:'warn',h:'Your save changed in another window',p:'Reload this page to continue from the newest progress.'};
 return{c:'ok',h:'Your progress is saved in this browser',p:'The game saves after every important moment and keeps rolling backups below.'}}
function saveCenter(back){S.mode=S.mode==='pause'?'pause':'title';back=back||title;const keep=ov.scrollTop;
 const m=sgMeta(),L=sgList(),pk=sgPeak(L),st=sgStatus(),due=sgExportDue(),bytes=L.reduce((a,r)=>a+(r.size||0),0);
 const lab=(r)=>r===pk?'★ Best progress':r.kind==='manual'?'Manual':r.kind==='safe'?'Safety copy':'Automatic';
 const rows=L.length?L.map(r=>{const i=r.info;return `<div class="svk${r===pk?' pk':''}${r.ok?'':' bad'}"><div class="svkt"><span class="tg ${r===pk?'pk':r.kind}">${lab(r)}</span><b>${esc(r.why||'Backup')}</b><small>${esc(sgDate(r.t))} &middot; ${sgAgo(r.t)}</small></div>
  <div class="svks">${r.ok&&i?`${esc(i.name)} &middot; Level ${i.lvl}${i.pres?' &middot; Prestige '+i.pres:''} &middot; ${i.cl}/30 cleared &middot; ${sgNum(i.gold)} gold &middot; ${i.w} weapons`:'This backup is damaged.'}</div>
  <div class="svka">${r.ok?`<button class="sm" data-r="${r.id}">Restore</button><button class="sm" data-x="${r.id}">Export</button>`:''}<button class="sm dg" data-d="${r.id}" aria-label="Delete this backup">Delete</button></div></div>`}).join(''):'<p class="svl">No backups yet. They are made automatically while you play, or press Back up now.</p>';
 show(`<h2>Save Center</h2><div class="svc">
${SGS.offer?`<div class="svo"><div><b>A much better save was found</b><small>Your current progress is far behind a backup from ${esc(sgDate(SGS.offer.t))} (level ${SGS.offer.info.lvl}${SGS.offer.info.pres?', prestige '+SGS.offer.info.pres:''}).</small></div><div class="svka"><button class="sm hgd" data-r="${SGS.offer.id}">Restore it</button><button class="sm" id="svdis">Dismiss</button></div></div>`:''}
<div class="svs0 ${st.c}"><i class="dot"></i><div><b>${st.h}</b><small>${st.p}</small><small id="svinfo">Last export: ${m.lastExport?esc(sgDate(m.lastExport))+' ('+sgAgo(m.lastExport)+')':'never'} &middot; Backups kept: ${L.length} (${sgKB(bytes)}) <span id="svpers"></span></small></div>
 <div class="svka"><button class="sm hgd" id="svnow">Back up now</button>${due?'<button class="sm" id="svlat">Remind me later</button>':''}</div></div>
${due?`<div class="svw0">You have not exported this save ${m.lastExport?'recently':'yet'}. Clearing browser data erases the backups below too, so keep a file somewhere else.</div>`:''}
<div class="svg2"><div class="svk2"><h3>Export</h3><p>Save your progress to a file to keep, email to yourself or load on another device.</p><div class="svka"><button class="sm hgd" id="svex">Download save file</button><button class="sm" id="svcp">Copy save code</button></div><small>If nothing downloads (some embedded pages block downloads), use Copy save code instead.</small></div>
<div class="svk2"><h3>Import</h3><p>Load a save file or a save code. You see what is inside before anything changes.</p><div class="svka"><button class="sm hgd" id="svim">Choose file…</button><input type="file" id="svf" accept=".json,application/json,text/plain" style="display:none"></div><textarea id="svta" rows="2" spellcheck="false" aria-label="Paste a save code" placeholder="Or paste a save code here"></textarea><div class="svka"><button class="sm" id="svck">Check pasted code</button></div></div></div>
<div class="svmsg" id="svmsg" role="alert" aria-live="polite"></div>
<div class="svk2 svbk"><h3>Backups <small>${L.length} kept. The best-progress backup is never removed automatically.</small></h3>${rows}</div>
<p class="svl">Backups live in this browser, so clearing site data deletes them as well. An exported file is the one copy that survives that.</p></div><button class="sm" id="b">Back</button>`,'m top');
 S.back=back;$('b').onclick=back;ov.scrollTop=keep;
 const msg=t=>{const e=$('svmsg');e.textContent=t||'';e.classList.toggle('on',!!t)};
 const again=()=>saveCenter(back);
 try{if(navigator.storage&&navigator.storage.persisted){navigator.storage.persisted().then(p=>{const e=$('svpers');if(e)e.textContent=p?'· Browser protection: on':'· Browser protection: standard';if(!p&&navigator.storage.persist)navigator.storage.persist().then(q=>{const e2=$('svpers');if(e2&&q)e2.textContent='· Browser protection: on'}).catch(()=>{})}).catch(()=>{})}}catch(e){}
 $('svnow').onclick=()=>{const id=sgSnap('Backup you made','manual');if(id){sgNote('Backup created.');again()}else msg('Could not create a backup. Storage may be full. Export your save instead.')};
 if($('svlat'))$('svlat').onclick=()=>{sgSnooze();again()};
 if($('svdis'))$('svdis').onclick=()=>{sgMuteOffer();again()};
 const dl=(text,name)=>{const a=document.createElement('a'),u=URL.createObjectURL(new Blob([text],{type:'application/json'}));a.href=u;a.download=name;a.style.display='none';document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(u);a.remove()},1500)};
 $('svex').onclick=()=>{try{dl(sgFileText(),sgFileName());sgMarkExport();msg('');sgNote('Save file downloaded: '+sgFileName());setTimeout(again,50)}catch(e){msg('The download could not start. Use Copy save code instead.')}};
 $('svcp').onclick=async()=>{let code;try{code=sgCode()}catch(e){msg('Could not create a code.');return}
  let ok=false;try{await navigator.clipboard.writeText(code);ok=true}catch(e){}
  if(!ok){try{const t=document.createElement('textarea');t.value=code;t.style.cssText='position:fixed;left:-9999px;top:0';document.body.appendChild(t);t.select();ok=document.execCommand('copy');t.remove()}catch(e){}}
  if(ok){sgMarkExport();sgNote('Save code copied. Paste it somewhere safe.');setTimeout(again,50)}
  else{await sgModal({title:'Copy your save code',html:'<p>Your browser would not copy it automatically. Select all the text below and copy it yourself (Ctrl+C or Cmd+C), then keep it somewhere safe.</p><textarea class="svbig" readonly id="svcode"></textarea>',buttons:[{t:'Done',v:1,cls:'hgd'}],esc:1,init:el=>{const t=el.querySelector('#svcode');t.value=code;t.focus();t.select()}});sgMarkExport();again()}};
 const imp=async(text,why)=>{const r=sgRead(text);if(!r.ok){msg(SGMSG[r.code]||SGMSG.json);return}msg('');
  const ok=await sgConfirmInstall(r.P,{title:'Import this save?',why:'importing a save',confirm:'Import and replace',verified:r.verified,exported:r.exported,risky:!r.verified});if(!ok)again()};
 $('svim').onclick=()=>$('svf').click();
 $('svf').onchange=e=>{const f=e.target.files[0];e.target.value='';if(!f)return;if(f.size>12e6){msg(SGMSG.big);return}
  const fr=new FileReader();fr.onerror=()=>msg('That file could not be read.');fr.onload=()=>imp(String(fr.result||''));fr.readAsText(f)};
 $('svck').onclick=()=>{const t=$('svta').value;if(!t.trim()){msg('Paste a save code into the box first.');return}imp(t)};
 ov.querySelectorAll('[data-r]').forEach(b=>b.onclick=async()=>{const r=sgRec(b.dataset.r);if(!r||!r.ok){msg('That backup is damaged and cannot be restored.');return}
  const q=sgRead(r.data,1);if(!q.ok){msg('That backup could not be read.');return}
  const ok=await sgConfirmInstall(q.P,{title:'Restore this backup?',why:'restoring a backup',confirm:'Restore',backup:r});if(!ok)again()});
 ov.querySelectorAll('[data-x]').forEach(b=>b.onclick=()=>{const r=sgRec(b.dataset.x);if(!r||!r.ok)return;const q=sgRead(r.data,1);if(!q.ok)return;try{const pk2=JSON.stringify({game:'Type Warriors',format:SGV,exported:new Date(r.t).toISOString(),summary:r.info,sum:r.sum,payload:r.data},null,1);dl(pk2,sgFileName(q.P,r.t));sgNote('Backup downloaded.')}catch(e){msg('The download could not start.')}});
 ov.querySelectorAll('[data-d]').forEach(b=>b.onclick=async()=>{const r=sgRec(b.dataset.d),isPk=r&&r===pk||(r&&pk&&r.id===pk.id);
  const v=await sgModal({title:'Delete this backup?',html:`<p>${esc(r&&r.why||'This backup')} from ${esc(sgDate(r&&r.t))} will be removed for good.${isPk?'</p><p class="svw">This is your best-progress backup, the one the game protects most.':''}</p>`,buttons:[{t:'Keep it',v:0},{t:'Delete',v:1,cls:'dg'}],focus:0,esc:0});
  if(v){sgDelete(b.dataset.d);again()}})}

/* ----- startup tasks, once the rest of the game is up ----- */
setTimeout(()=>{sgBoot();SGS.notes.splice(0).forEach((m,i)=>setTimeout(()=>sgNote(m),i*600));sgChipUpd()},900);
