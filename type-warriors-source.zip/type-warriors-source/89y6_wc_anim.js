/* ===== WILDCARD MOTION: game feel for every moment at the table =====
   Upgrades the card animations of 89c/89p without touching their rules or pacing. It replaces the shared helpers the
   event code already calls (wcFly, wcBurst, wcPop, wcShake, wcDeal2, wcWild2, wcRev2, wcSkip2) and wraps wcAnim only to
   add to events (the 89u ranked hooks further down the chain still run for every event).
   - Flights: a card lifts out of your hand, travels a sampled arc with a little spin and a 3D lean into the turn, drags a
     streak of light in its element's colour (turned along the path, stretched with the speed) and casts a soft shadow that
     stays on the felt (it drifts and fades as the card rises), so the height reads. Draws slide off the deck first and
     flip face up in the air if yours.
   - Landing: the pile card squashes and settles with its bottom edge grounded, a shock ring and dust run over the felt
     under the pile (a ground layer below the cards) and element particles fly (embers rise, droplets splash, leaves
     flutter, sparks crackle). +2/+4 come down harder and shake the pile; the stack badge takes a counter punch.
   - Moments: ribbon banners that stamp in with rays for action cards, a rubber stamp for WILD! and CAUGHT!, an element
     wheel that spins and locks onto the chosen colour for wilds, a lightning strike with shock rings and a cracked felt
     for Stun, a sweeping spin of the direction track with two light comets for Turnabout, a riffle and bridge for the deal
     and reshuffle, a light that travels to whoever is next, and a win with a spotlight, confetti, a coin shower and a
     glowing nameplate.
   Performance: only transform and opacity are animated (Web Animations, so they run on the compositor), shadows, gradients
   and the one blur (the win beam) are static, ray discs bake their fade into an SVG gradient instead of a mask layer,
   particles come from two small pools of elements that are dropped when the table goes quiet, and every temporary element
   removes itself. Awaited times match the old ones (long sequences wait a fixed time instead of chaining many short
   awaits, so a slow machine does not stretch a bot's turn); decorations finish in the background.
   Reduced motion (wcRM, also the lowest performance mode) falls back to the old short versions. */
const Y6={pl:null,pool:[],pi:0,gl:null,gp:[],gi:0,it:0,cur:null,src:null,lt:-1,rid:0};
const y6r=(a,b)=>a+Math.random()*(b-a),y6f=n=>(+n).toFixed(1);
const Y6PAL={e:['#ffd27a','#ff7a2f','#ff4a1f'],t:['#d6f0ff','#5ab4ff','#1f8cff'],g:['#d8ffb0','#5ee08a','#22c55e'],s:['#fff6b0','#ffe04a','#ffc21a'],w:['#ff7a4a','#5ab4ff','#5ee08a','#ffe04a','#c9a0ff']};
const y6Pal=s=>Y6PAL[s]||Y6PAL.w;
/* ---------- particles: two small pools of plain elements, each particle driven by a single compositor animation.
   The ground pool sits in the table under the piles and seats (shock rings and dust run over the felt, not over the
   cards); the main pool sits in #wcfx above everything. ---------- */
function y6Pool(){const fx=$('wcfx');if(!fx)return null;if(Y6.pl&&Y6.pl.parentNode===fx)return Y6.pl;
 const d=document.createElement('div');d.className='y6pl';d.innerHTML='<i></i>'.repeat(72);fx.appendChild(d);Y6.pl=d;Y6.pool=[...d.children];Y6.pi=0;return d}
function y6Gnd(){const t=$('wct');if(!t)return null;if(Y6.gl&&Y6.gl.parentNode===t)return Y6.gl;
 const d=document.createElement('div');d.className='y6pl y6gnd';d.innerHTML='<i></i>'.repeat(20);t.insertBefore(d,t.querySelector('.wcpiles'));Y6.gl=d;Y6.gp=[...d.children];Y6.gi=0;return d}
/* a free-standing element on the ground layer (win halo) */
function y6GEl(cls,html,ms){const g=y6Gnd();if(!g)return null;const e=document.createElement('b');e.className=cls;e.innerHTML=html;g.appendChild(e);setTimeout(()=>e.remove(),ms||1500);y6Drop(ms);return e}
/* the pools leave the DOM a while after the last particle */
function y6Drop(ms){clearTimeout(Y6.it);Y6.it=setTimeout(()=>{if(Y6.pl){Y6.pl.remove();Y6.pl=null;Y6.pool=[]}if(Y6.gl){Y6.gl.remove();Y6.gl=null;Y6.gp=[]}},Math.max(4000,(ms||0)+600))}
function y6P(cls,c,kf,dur,o){o=o||{};let el;if(o.gnd){if(!y6Gnd())return null;el=Y6.gp[Y6.gi++%Y6.gp.length]}else{if(!y6Pool())return null;el=Y6.pool[Y6.pi++%Y6.pool.length]}if(el._a)el._a.cancel();
 el.className=cls;if(c)el.style.setProperty('--c',c);el._a=el.animate(kf,{duration:dur,delay:o.delay||0,easing:o.ease||'linear',fill:'none'});
 if(!(Y6.gl&&Y6.gl.querySelector('b')))y6Drop();return el}
/* a particle thrown from x,y with velocity vx,vy (px/s) under gravity g; al = turn along the path; fl = coin flips */
function y6Ball(cls,c,x,y,vx,vy,g,dur,o){o=o||{};const N=6,kf=[],s0=o.s0||1,s1=o.s1==null?s0:o.s1,fo=o.fo==null?.55:o.fo;
 for(let k=0;k<=N;k++){const t=k/N,T=t*dur/1000,px=x+vx*T,py=y+vy*T+.5*g*T*T,a=o.al?Math.atan2(vy+g*T,vx)*57.3+(o.ao||0):(o.r0||0)+(o.vr||0)*t*dur/1000;
  const sc=s0+(s1-s0)*t,sx=o.fl?Math.max(.08,Math.abs(Math.cos(t*o.fl*Math.PI)))*sc:sc;
  kf.push({transform:`translate(${y6f(px)}px,${y6f(py)}px) rotate(${y6f(a)}deg)${o.rx?` rotateX(${y6f(o.rx*t)}deg)`:''} scale(${sx.toFixed(3)},${sc.toFixed(3)})`,opacity:t<fo?(o.a||1):(o.a||1)*Math.max(0,1-(t-fo)/(1-fo))})}
 return y6P(cls,c,kf,dur,o)}
function y6Ring(x,y,c,o){o=o||{};const sy=o.sy||1,s0=o.s0||.3,s1=o.s1||2.2;
 return y6P('p6rg'+(o.th?' p6th':''),c,[{transform:`translate(${x}px,${y}px) scale(${s0},${s0*sy})`,opacity:o.a||1},{transform:`translate(${x}px,${y}px) scale(${s1},${s1*sy})`,opacity:0}],o.dur||520,{delay:o.delay,ease:'cubic-bezier(.15,.75,.3,1)',gnd:o.gnd})}
function y6Dust(x,y,n,rx,ry){for(let k=0;k<n;k++){const a=k/n*6.283+y6r(-.3,.3),c=Math.cos(a),s=Math.sin(a);
 y6P('p6du',null,[{transform:`translate(${y6f(x+c*rx*.55)}px,${y6f(y+s*ry*.55)}px) scale(.45)`,opacity:.95},{transform:`translate(${y6f(x+c*rx*1.6)}px,${y6f(y+s*ry*1.6)}px) scale(1.5)`,opacity:0}],y6r(560,760),{ease:'cubic-bezier(.12,.75,.3,1)',gnd:1})}}
function y6Sparks(x,y,n,pal,o){o=o||{};for(let k=0;k<n;k++){const a=(o.a0==null?-Math.PI/2:o.a0)+y6r(-1,1)*(o.sp||Math.PI),v=y6r(o.v0||260,o.v1||560);
 y6Ball('p6sk',pal[k%pal.length],x,y,Math.cos(a)*v,Math.sin(a)*v,o.g==null?900:o.g,y6r(420,640),{al:1,s0:y6r(.8,1.3),s1:.3,fo:.4,delay:o.delay})}}
function y6Stars(x,y,n,r,pal,o){o=o||{};for(let k=0;k<n;k++){const a=y6r(0,6.283),d=y6r(r*.4,r);
 y6P('p6st',pal[k%pal.length],[{transform:`translate(${y6f(x+Math.cos(a)*d*.3)}px,${y6f(y+Math.sin(a)*d*.3)}px) scale(.2) rotate(0deg)`,opacity:0},{transform:`translate(${y6f(x+Math.cos(a)*d*.8)}px,${y6f(y+Math.sin(a)*d*.8)}px) scale(1.1) rotate(45deg)`,opacity:1,offset:.35},{transform:`translate(${y6f(x+Math.cos(a)*d)}px,${y6f(y+Math.sin(a)*d)}px) scale(.3) rotate(90deg)`,opacity:0}],y6r(600,900),{delay:(o.delay||0)+y6r(0,o.spread||200),ease:'ease-out'})}}
/* element particles for a landing: embers drift up, droplets splash, leaves flutter down, sparks crackle */
function y6Elem(x,y,s,big){const P=y6Pal(s),n=big?8:6;
 if(s==='e')for(let k=0;k<n+1;k++)y6Ball('p6dt',P[k%2],x+y6r(-60,60),y+y6r(-30,40),y6r(-50,50),y6r(-160,-270),-90,y6r(850,1150),{s0:y6r(1.15,2.1),s1:.25,fo:.3,delay:y6r(0,250)});
 else if(s==='t')for(let k=0;k<n+2;k++){const a=-Math.PI/2+y6r(-1.2,1.2),v=y6r(300,480);y6Ball('p6dr',P[k%3],x+Math.cos(a)*40,y+50,Math.cos(a)*v,Math.sin(a)*v,1500,y6r(560,720),{al:1,ao:-90,s0:y6r(.9,1.4),fo:.6,delay:y6r(0,90)})}
 else if(s==='g')for(let k=0;k<n;k++){const a=-Math.PI/2+y6r(-1.3,1.3),v=y6r(220,360);y6Ball('p6lf',P[k%3],x,y,Math.cos(a)*v,Math.sin(a)*v,520,y6r(950,1250),{vr:y6r(-500,500),r0:y6r(0,360),s0:y6r(1.25,1.95),fo:.5,delay:y6r(0,250)})}
 else if(s==='s')y6Sparks(x,y,n+3,['#fff',P[0],P[1]],{v0:420,v1:760,g:500});
 else{y6Stars(x,y,6,170,P);y6Sparks(x,y,6,P,{v0:300,v1:600})}}
/* ---------- the card flight ---------- */
/* to/from are boxes {x,y,w,h}; the card is to-sized and placed by its centre. o: dur, arc (peak lift, negative = up), r0,
   r1, spin, pk (scale at the top), s0 (start scale), lift (rise out of the hand first), slide (slide off the deck first),
   flip + fa (flip window [start,end] as fractions; rev flips face to back), trail (colour), nosh (no shadow), ease, keep */
function y6Fly(face,from,to,o){o=o||{};const fx=$('wcfx');if(!fx||!from||!to)return wcSleep(0);
 const W=to.w,H=to.h,c0={x:from.x+from.w/2,y:from.y+from.h/2},c1={x:to.x+W/2,y:to.y+H/2},dur=o.dur||360;
 const s0=o.s0||from.w/W,r0=o.r0||0,r1=o.r1||0,arc=o.arc==null?-40:o.arc,spin=o.spin||0,pk=o.pk||1.1,dx=c1.x-c0.x,dy=c1.y-c0.y,len=Math.hypot(dx,dy)||1,tw=dx>=0?1:-1;
 const d=document.createElement('div');d.className='wcfly y6fly'+(o.flip?' flip':'');d.style.width=W+'px';d.style.height=H+'px';
 d.innerHTML=o.flip?`<div class="fi"${o.rev?'':' style="transform:rotateY(180deg)"'}><div class="ff">${face}</div><div class="fb">${wcBack(wcBackSel())}</div></div>`:face;
 const sh=o.nosh?null:document.createElement('div');if(sh){sh.className='y6fsh';sh.style.width=W+'px';sh.style.height=H+'px';fx.appendChild(sh)}
 /* the trail: one streak of light in the element's colour, turned along the path and stretched with the speed; its head
    hides under the card, so only the tail shows */
 const TW=Math.round(W*1.7),TH=Math.round(H*.56),tr=o.trail?document.createElement('div'):null;
 if(tr){tr.className='y6tr';tr.style.cssText=`width:${TW}px;height:${TH}px;--c:${o.trail}`;fx.appendChild(tr)}
 fx.appendChild(d);
 /* phase A (optional): rise out of the hand or slide off the deck; phase B: the arc */
 const A=o.lift||o.slide?.22:0,p1=o.lift?{x:c0.x,y:c0.y-o.lift}:o.slide?{x:c0.x+dx/len*o.slide,y:c0.y+dy/len*o.slide-4}:c0,sA=o.lift?s0*1.1:o.slide?s0*1.04:s0,rA=o.lift?r0*.35:r0,g0=o.lift?c0:p1;
 const qx=(p1.x+c1.x)/2,qy=(p1.y+c1.y)/2+arc*2,N=14,kc=[],ks=[],P=[];
 for(let k=0;k<=N;k++){const t=k/N;let x,y,s,r,gx,gy,lx=0,ly=0;
  if(t<A){const u=t/A,e=1-(1-u)*(1-u);x=c0.x+(p1.x-c0.x)*e;y=c0.y+(p1.y-c0.y)*e;s=s0+(sA-s0)*e;r=r0+(rA-r0)*e;gx=c0.x+(g0.x-c0.x)*e;gy=c0.y+(g0.y-c0.y)*e}
  else{const u=A<1?(t-A)/(1-A):1,v=1-u,b=Math.sin(Math.PI*u);x=v*v*p1.x+2*v*u*qx+u*u*c1.x;y=v*v*p1.y+2*v*u*qy+u*u*c1.y;s=(sA+(1-sA)*u)*(1+(pk-1)*b);r=rA+(r1-rA)*u+spin*b;gx=g0.x+(c1.x-g0.x)*u;gy=g0.y+(c1.y-g0.y)*u;lx=10*b;ly=-tw*15*b}
  const ht=Math.max(0,gy-y);P.push([x,y]);
  kc.push({transform:`translate(${y6f(x-W/2)}px,${y6f(y-H/2)}px) perspective(900px) rotateX(${y6f(lx)}deg) rotateY(${y6f(ly)}deg) rotate(${y6f(r)}deg) scale(${s.toFixed(3)})`});
  /* the shadow stays on the felt: it drifts a little from the card as it rises (capped), and is gone by the landing */
  if(sh)ks.push({transform:`translate(${y6f(gx-W/2+Math.min(14,ht*.16))}px,${y6f(gy-H/2+8+Math.min(40,ht*.36))}px) rotate(${y6f(r)}deg) scale(${(s*(1+Math.min(.35,ht/520))).toFixed(3)})`,opacity:(.46*(1-Math.min(.62,ht/280))*Math.min(1,(1-t)/.18)).toFixed(3)})}
 const ease=o.ease||'cubic-bezier(.33,.6,.3,1)',dl=o.delay||0,an=d.animate(kc,{duration:dur,delay:dl,easing:ease,fill:dl?'both':'forwards'});
 if(sh)sh.animate(ks,{duration:dur,delay:dl,easing:ease,fill:dl?'both':'forwards'});
 if(tr){const t0=o.flip?(o.fa||[.1,.6])[0]+.08:A+.06,kt=P.map((q,k)=>{const pr=P[Math.max(0,k-1)],nx=P[Math.min(N,k+1)],vx=nx[0]-pr[0],vy=nx[1]-pr[1],sp=Math.hypot(vx,vy),t=k/N;
   return {transform:`translate(${y6f(q[0]-TW)}px,${y6f(q[1]-TH/2)}px) rotate(${y6f(Math.atan2(vy,vx)*57.2958)}deg) scaleX(${Math.max(.05,Math.min(1,sp/(TW*.55))).toFixed(3)})`,opacity:t<t0||k===N?0:t>.84?.25:.75}});
  tr.animate(kt,{duration:dur,delay:dl,easing:ease,fill:'none'}).finished.then(()=>tr.remove(),()=>tr.remove())}
 if(o.flip){const fi=d.querySelector('.fi'),fa=o.fa||[.1,.6],a0=o.rev?0:180,a1=180-a0;fi.animate([{transform:`rotateY(${a0}deg)`},{transform:`rotateY(${a0}deg)`,offset:fa[0]},{transform:`rotateY(${a1}deg)`,offset:fa[1]},{transform:`rotateY(${a1}deg)`}],{duration:dur,delay:dl,easing:'ease-in-out',fill:'both'})}
 return an.finished.then(()=>{if(sh)sh.remove();if(o.keep)return d;d.remove()},()=>{if(sh)sh.remove();d.remove()})}
/* ---------- replacing the shared helpers ---------- */
{const f0=wcFly;wcFly=function(face,from,to,o){o=o||{};if(wcRM()||!from||!to)return f0.apply(this,arguments);
 const pl=wcPileSpot(),dk=$('wcdeck')?wcDeckSpot():null,near=(a,b)=>a&&b&&Math.abs(a.x-b.x)<3&&Math.abs(a.y-b.y)<3;
 if(near(to,pl)){/* a play onto the pile */const c=Y6.cur,src=Y6.src,slam=c&&(c.v==='d2'||c.v==='d4');
  return y6Fly(face,from,to,{...o,dur:o.dur||360,lift:src?30:0,s0:src?src.s/to.w:0,r0:src?src.a:o.r0,arc:slam?-118:-72,pk:slam?1.3:1.18,fa:[.06,.55],
   trail:c?WCC[c.s]||WCC.w:null,ease:slam?'cubic-bezier(.45,.15,.75,.75)':'cubic-bezier(.3,.6,.55,.88)'})}
 if(near(from,dk))return y6Fly(face,from,to,{...o,slide:26,arc:o.arc==null?-50:o.arc-14,fa:[.3,.85]});
 return y6Fly(face,from,to,{...o,fa:[.2,.8]})}}
/* the landing: the pile card squashes and settles (CSS .land; kept grounded: the squash is offset so the bottom edge stays
   put, harder for +2/+4), a shock ring and dust run over the felt under the pile, sparks and element particles fly. Action
   cards get their banner instead of the element burst, which keeps the busiest moments light. */
function y6Land(at,s,n){const c=Y6.cur,slam=c&&(c.v==='d2'||c.v==='d4'),act=c&&WCACT[c.v],big=n>=12||slam,col=WCC[s]||WCC.w;
 const top=document.querySelector('#wcdisc .top');if(top&&slam)top.classList.add('y6sl');
 y6Ring(at.x,at.y+30,col,{sy:.5,s0:.6,s1:big?3.3:2.8,dur:580,gnd:1});y6Ring(at.x,at.y+30,'#fff',{sy:.5,s0:.5,s1:big?2.5:2,dur:460,delay:60,th:1,a:.8,gnd:1});
 y6Dust(at.x,at.y+82,big?8:6,big?124:104,big?40:34);y6Sparks(at.x,at.y,act?5:big?9:7,y6Pal(s),{sp:1.3});if(!act)y6Elem(at.x,at.y,s,big)}
{const b0=wcBurst;wcBurst=function(at,s,n){if(wcRM()||!at)return b0.apply(this,arguments);try{y6Land(at,s,n||10)}catch(e){}}}
function y6Pile(k){const d=$('wcdisc');if(!d||wcRM())return;const m=k>1?8:5;d.animate([{transform:'none'},{transform:`translate(${-m}px,${m*.4}px) rotate(-1.2deg)`,offset:.2},{transform:`translate(${m*.8}px,${-m*.3}px) rotate(1deg)`,offset:.45},{transform:`translate(${-m*.4}px,0) rotate(-.4deg)`,offset:.7},{transform:'none'}],{duration:k>1?420:340,easing:'ease-out'})}
/* the hard table shake (+4) also knocks the pile */
{const s0=wcShake;wcShake=function(k){s0.apply(this,arguments);if(k>1)y6Pile(k)}}
/* banners and stamps */
const Y6AC={stun:['#ffd45a','#fff1b0'],turn:['#5ab8ff','#d6f0ff'],d2:['#ff6a4a','#ffd0c0'],d4:['#a86aff','#ecd6ff'],wild:['#c9a0ff','#fff']};
function y6El(cls,html,at,ms){const fx=$('wcfx');if(!fx)return null;const e=document.createElement('div');e.className=cls;e.innerHTML=html;if(at){e.style.left=at.x+'px';e.style.top=at.y+'px'}fx.appendChild(e);setTimeout(()=>e.remove(),ms||1500);return e}
/* n light rays from radius ri to R that fade outward; the fade is baked into a radial gradient fill (no mask layer) */
function y6Rays(n,cols,R,ri,a){const id='y6rg'+(++Y6.rid),P=(g,r)=>`${y6f(Math.sin(g*Math.PI/180)*r)} ${y6f(-Math.cos(g*Math.PI/180)*r)}`,w=360/n*.34;let s='';
 for(let k=0;k<n;k++){const g=k*360/n;s+=`<path d="M${P(g-w*.2,ri)}L${P(g-w/2,R)}L${P(g+w/2,R)}L${P(g+w*.2,ri)}Z" fill="url(#${id}${k%cols.length})"/>`}
 return `<svg viewBox="${-R} ${-R} ${2*R} ${2*R}"><defs>${cols.map((c,j)=>`<radialGradient id="${id}${j}" gradientUnits="userSpaceOnUse" cx="0" cy="0" r="${R}"><stop offset="${(ri/R).toFixed(3)}" stop-color="${c}" stop-opacity="0"/><stop offset="${Math.min(.9,ri/R+.1).toFixed(3)}" stop-color="${c}" stop-opacity="${a||.8}"/><stop offset="1" stop-color="${c}" stop-opacity="0"/></radialGradient>`).join('')}</defs>${s}</svg>`}
/* where a seat's label goes: above the avatar for the side seats, beside it for the top seat (above it is off the stage) */
function y6Tag(i,dy,side){const av=y6Av(i);if(!av)return null;if(av.y<200)return{x:av.x+av.r+(side||110),y:av.y+6};return{x:av.x,y:av.y-av.r+dy}}
{const p0=wcPop;wcPop=function(txt,cls,at){cls=cls||'';if(!at)return p0.apply(this,arguments);const k=cls.split(' ');
 /* labels the old code aimed above the top seat would sit off the stage: put them beside its avatar */
 if(at.y<70){const i=WX.G?WX.G.P.findIndex((_,j)=>{const a=y6Av(j);return a&&a.y<200&&Math.abs(a.x-at.x)<4}):-1;at=i>=0?y6Tag(i,0,k[0]==='caught'?200:k[0]==='call'?120:110):{x:at.x,y:270}}
 if(wcRM())return p0.call(this,txt,cls,at);
 if(k[0]==='act'){/* the open felt between the piles and your status bar */at={x:at.x,y:556};const v=(k.find(x=>x.startsWith('a-'))||'').slice(2),A=Y6AC[v]||['#ffd45a','#fff4c8'],lg=v==='wild'||v==='d4';
  /* a wild's banner stays up through the wheel's lock */
  const e=y6El(`wcpop ${cls} y6pop y6ban${lg?' y6lg':''}`,`<i class="y6ry">${y6Rays(16,v==='wild'?WCS.map(x=>WCC[x]):[A[0]],160,30)}</i><div class="y6bw"><div class="y6bp"><b>${txt}</b><span class="y6clip"><i class="y6sn"></i></span></div></div>`,at,lg?2050:1400);
  if(e){e.style.setProperty('--ac',A[0]);e.style.setProperty('--tc',A[1])}y6Stars(at.x,at.y,6,190,[A[1],'#fff','#ffd45a'],{delay:80});return}
 if(k[0]==='call'||k[0]==='caught'){const m=txt.split(/(?=<small)/),t=m[0].replace(/<[^>]+>/g,'').trim();
  y6El(`wcpop ${cls} y6pop y6stp`,`<div class="y6sp"><b>${t}</b>${m[1]||''}</div>`,at,1500);
  setTimeout(()=>{y6Ring(at.x,at.y,k[0]==='call'?'#ffd45a':'#ff5a6a',{s0:.6,s1:2.2,dur:480});y6Dust(at.x,at.y+24,6,90,30);y6Stars(at.x,at.y,5,130,['#fff','#ffd45a'])},150);return}
 if(k[0]==='stk'){/* the +N punch sits by the victim's card count, on the side towards the table */const i=WX.G?WX.G.P.findIndex((_,j)=>{const a=y6Av(j);return a&&Math.abs(a.x-at.x)<4}):-1,av=i>=0&&y6Av(i);
  if(av)at=av.y<200?{x:av.x+av.r+90,y:av.y-8}:av.y>600?{x:av.x+av.r+70,y:av.y-av.r-24}:{x:av.x+(av.x>800?-1:1)*(av.r*.5+44),y:av.y-av.r-34};
  y6El(`wcpop ${cls} y6pop y6pun`,`<i class="y6pg"></i><b>${txt}</b>`,at,1400);setTimeout(()=>{y6Ring(at.x,at.y,'#ff5a6a',{s0:.5,s1:2.2,dur:480});y6Sparks(at.x,at.y,8,['#ff8a8a','#fff','#ffd45a'],{v0:280,v1:500,g:400})},110);return}
 if(k[0]==='stn'||k[0]==='sm'){y6El(`wcpop ${cls} y6pop y6tag`,`<span>${txt}</span>`,at,1400);return}
 if(k[0]==='win'){at={x:800,y:470};/* over the open felt, clear of every seat */
  y6El(`wcpop ${cls} y6pop y6ban y6wn`,`<i class="y6ry">${y6Rays(20,['#ffd45a','#fff2b8'],300,60)}</i><div class="y6bw"><div class="y6bp"><b>${txt}</b><span class="y6clip"><i class="y6sn"></i></span></div></div>`,at,3200);return}
 return p0.apply(this,arguments)}}
/* ---------- the deal: deck drop, riffle and bridge, arcs into every seat, your cards flip on the way in ---------- */
/* the riffle: each card gets one animation holding its whole path (fan out, cascade back in turn, bridge squeeze), so the
   awaited time is a fixed sum and does not stretch when timers run late on a slow machine */
async function y6Riffle(dk,B,n,f){f=f||1;const deck=$('wcdeck');if(deck)deck.style.visibility='hidden';const C=[];
 for(let i=0;i<n;i++)C.push([wcTmp(B,null,dk,0),i,-1],[wcTmp(B,null,dk,0),i,1]);wcFx('riffle');
 /* one soft shadow for the whole packet: stacked copies each casting the card shadow read as a black halo */
 C.forEach(([d],k)=>d.classList.add(k?'y6rc':'y6rc0'));
 const D=`translate(${dk.x}px,${dk.y}px)`,at=(i,s)=>`translate(${y6f(dk.x+s*(70+i*3.5))}px,${y6f(dk.y-14-i*2.5)}px) rotate(${s*(13+i*2.2)}deg)`;
 const Ts=(250+(n-1)*8)*f,Tb=Ts+((2*n-1)*26+190+170)*f,T=Tb+200*f,o=t=>Math.min(1,Math.max(0,t/T));
 C.forEach(([d,i,s])=>{const j=2*(n-1-i)+(s>0?1:0),t1=i*8*f,tc=Ts+j*26*f,h=2*n-1-j,E='cubic-bezier(.2,.8,.3,1)',Q='cubic-bezier(.4,0,.6,1)';
  d.animate([{transform:D,offset:0},{transform:D,offset:o(t1),easing:E},{transform:`translate(${y6f(dk.x+s*(70+i*3.5)*.6)}px,${y6f(dk.y-30-i*2)}px) rotate(${s*(8+i*2)}deg) scale(1.03)`,offset:o(t1+150*f),easing:E},
   {transform:at(i,s),offset:o(t1+250*f)},{transform:at(i,s),offset:o(tc),easing:Q},{transform:`translate(${y6f(dk.x+s*26)}px,${y6f(dk.y-46-i*2)}px) rotate(${s*4}deg) scale(1.04,.96)`,offset:o(tc+95*f),easing:Q},
   {transform:`translate(${dk.x}px,${y6f(dk.y-h*.9)}px) rotate(${s*1.5}deg)`,offset:o(tc+190*f)},{transform:`translate(${dk.x}px,${y6f(dk.y-h*.9)}px) rotate(${s*1.5}deg)`,offset:o(Tb),easing:'ease-in-out'},
   {transform:`translate(${dk.x}px,${dk.y-8}px) scale(1.03,.94)`,offset:o(Tb+90*f),easing:'ease-in-out'},{transform:D,offset:1}],{duration:T,fill:'forwards'})});
 setTimeout(()=>wcFx('bridge'),Tb);await wcSleep(T);C.forEach(([d])=>d.remove());if(deck)deck.style.visibility=''}
{const D0=wcDeal2;wcDeal2=async function(e){if(wcRM())return D0.apply(this,arguments);
 const G=WX.G,n=e.hand,dk=wcDeckSpot(),fx=$('wcfx'),deck=$('wcdeck'),disc=$('wcdisc'),hand=$('wchand');if(!dk||!fx)return;Y6.lt=-1;
 WX.vc=G.P.map(()=>0);for(const i of G.P.keys())wcCount(i,0);if(hand)hand.innerHTML='';const stt=$('wcstat');if(stt)stt.style.visibility='hidden';const top=disc?disc.innerHTML:'';if(disc)disc.innerHTML='';
 const B=wcBack(wcBackSel());
 /* 1. the deck drops onto the felt */
 deck.style.visibility='hidden';wcFx('bridge');
 await y6Fly(B,{x:dk.x+150,y:-260,w:dk.w,h:dk.h},dk,{dur:520,arc:-30,r0:-38,r1:0,spin:-14,pk:1.15,ease:'cubic-bezier(.3,.75,.35,1.08)'});
 deck.style.visibility='';deck.classList.remove('land');void deck.offsetWidth;deck.classList.add('land');y6Dust(dk.x+dk.w/2,dk.y+dk.h-6,9,110,30);y6Ring(dk.x+dk.w/2,dk.y+dk.h/2+30,'#fff',{sy:.45,s0:.8,s1:2.4,th:1,a:.6,dur:500});await wcSleep(170);
 /* 2. riffle and bridge */
 await y6Riffle(dk,B,7);
 /* 3. round-robin deal: cards arc to every seat; yours flip face up as they fly into their slots */
 const slots=wcHandSlots(G),mine=[],T=[];let k2=0;
 for(let k=0;k<n;k++)for(let j=0;j<G.P.length;j++){const i=(G.turn+j)%G.P.length,me=i===WX.me;
  if(me){const s=slots[k];if(!s)continue;const cov=!!WX.cover;T.push(y6Fly(cov?B:wcSVG(s.c),dk,{x:s.x,y:s.y,w:112,h:164},{flip:!cov,fa:[.35,.92],dur:400,arc:-80,r1:s.r,spin:-10,pk:1.12,keep:true}).then(d=>{if(d)mine.push(d)}))}
  else{const to=wcSeatSpot(i);if(!to)continue;T.push(y6Fly(B,dk,to,{dur:330,arc:-50,spin:-24,r1:-8,nosh:true}).then(()=>wcCount(i,1)))}
  if(k2++%2===0)wcFx('deal2');await wcSleep(58)}
 await Promise.all(T);
 /* 4. your fan settles with a little wave */
 if(!WX.cover&&mine.length){wcFx('flipall');mine.sort((a,b)=>a.getBoundingClientRect().left-b.getBoundingClientRect().left);
  mine.forEach((d,i)=>{const fi=d.querySelector('.fi');if(fi)fi.animate([{transform:'rotateY(0deg)'},{transform:'rotateY(0deg) translateY(-18px) scale(1.04)',offset:.4},{transform:'rotateY(0deg)'}],{duration:300,delay:i*45,easing:'cubic-bezier(.3,.7,.4,1)'})});
  await wcSleep(mine.length*45+300)}
 WX.fresh=null;wcRenderHand();mine.forEach(d=>d.remove());
 /* 5. the first card turns over onto the pile */
 const fc=G.disc[0],to=wcPileSpot();if(fc&&to){wcFx('swish');await y6Fly(wcSVG(fc),dk,to,{flip:true,fa:[.05,.7],dur:440,arc:-90,r1:wcRot(fc.id),spin:20,pk:1.25,slide:20})}
 if(disc){disc.innerHTML=top;const t=disc.querySelector('.top');if(t)t.classList.add('land')}wcTint(G.color);wcFx('slap');
 const pl=wcPileSpot();if(pl)wcBurst({x:pl.x+pl.w/2,y:pl.y+pl.h/2},G.color,10);if(stt)stt.style.visibility='';await wcSleep(260)}}
/* ---------- Wild Rune / +4 Hex: the element wheel spins and locks onto the chosen colour ---------- */
function y6Wheel(){const seg=(i,R)=>{const a0=(i*90-45)*Math.PI/180,a1=(i*90+45)*Math.PI/180;return `M0 0L${y6f(Math.sin(a0)*R)} ${y6f(-Math.cos(a0)*R)}A${R} ${R} 0 0 1 ${y6f(Math.sin(a1)*R)} ${y6f(-Math.cos(a1)*R)}Z`};
 return `<svg viewBox="-112 -112 224 224"><defs><radialGradient id="y6wl" cx="40%" cy="35%" r="70%"><stop offset="0" stop-color="#fff" stop-opacity=".5"/><stop offset=".55" stop-color="#fff" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".35"/></radialGradient></defs>
  <circle r="108" fill="#12081f"/><circle r="103" fill="#ffd45a"/><circle r="97" fill="#12081f"/>
  ${WCS.map((s,i)=>`<path d="${seg(i,93)}" fill="${WCC[s]}" stroke="#12081f" stroke-width="4" stroke-linejoin="round"/>`).join('')}<circle r="93" fill="url(#y6wl)"/>
  ${WCS.map((s,i)=>{const a=i*90*Math.PI/180;return `<g transform="translate(${y6f(Math.sin(a)*58)} ${y6f(-Math.cos(a)*58)}) rotate(${i*90}) scale(1.9)">${WCG[s]}</g>`}).join('')}
  ${Array.from({length:16},(_,i)=>{const a=i*22.5*Math.PI/180;return `<circle cx="${y6f(Math.sin(a)*100)}" cy="${y6f(-Math.cos(a)*100)}" r="2.6" fill="#fff6d0" stroke="#12081f" stroke-width="1.2"/>`}).join('')}
  <circle r="24" fill="#1e1650" stroke="#12081f" stroke-width="7"/><circle r="24" fill="none" stroke="#ffd45a" stroke-width="3.5"/><g transform="scale(1.35)">${WCG.w}</g></svg>`}
{const W0=wcWild2;wcWild2=async function(col,mid){const fx=$('wcfx');if(!fx||wcRM()||!mid)return W0.apply(this,arguments);
 const i=Math.max(0,WCS.indexOf(col)),c=WCC[col]||WCC.w,w=document.createElement('div');w.className='y6wh';w.style.left=mid.x+'px';w.style.top=(mid.y-20)+'px';w.style.setProperty('--c',c);mid={x:mid.x,y:mid.y-20};
 w.innerHTML=`<i class="y6ry">${y6Rays(16,[c,'#fff6d0'],180,64,.9)}</i><i class="y6wsh"></i><div class="y6wd">${y6Wheel()}</div><svg class="y6wg" viewBox="-112 -112 224 224"><path d="M0 0L-65.8 -65.8A93 93 0 0 1 65.8 -65.8Z" fill="#fff" fill-opacity=".28" stroke="#fff" stroke-width="5" stroke-linejoin="round"/></svg><svg class="y6wp" viewBox="-20 -20 40 40"><path d="M-13-14H13L0 12Z" fill="#ffd45a" stroke="#12081f" stroke-width="4.5" stroke-linejoin="round"/><path d="M-6-9H5" stroke="#fff6d0" stroke-width="2.4" stroke-linecap="round"/></svg>`;fx.appendChild(w);
 const wd=w.querySelector('.y6wd'),wp=w.querySelector('.y6wp'),rot=1080+((-i*90)%360+360)%360;wcFx('swirl');
 /* fully opaque within ~80 ms, so it never sits half-transparent over the landing card's face */
 w.animate([{transform:'scale(.3)',opacity:0},{transform:'scale(.8)',opacity:1,offset:.3},{transform:'scale(1.08)',opacity:1,offset:.65},{transform:'scale(1)',opacity:1}],{duration:260,easing:'ease-out',fill:'forwards'});
 const sp=wd.animate([{transform:'rotate(0deg)'},{transform:`rotate(${rot+9}deg)`,offset:.86},{transform:`rotate(${rot}deg)`}],{duration:780,easing:'cubic-bezier(.16,.62,.2,1)',fill:'forwards'});
 [50,125,215,335,480,640].forEach(t=>setTimeout(()=>{wcFx('tick');wp.animate([{transform:'rotate(0deg)'},{transform:'rotate(-16deg)',offset:.3},{transform:'rotate(0deg)'}],{duration:140})},t));
 await wcSleep(780);
 /* lock: the chosen element flares, rays and a colour burst */
 w.classList.add('y6lk');w.querySelector('.y6wg').animate([{opacity:0},{opacity:1,offset:.3},{opacity:.7}],{duration:420,fill:'forwards'});wcFx('elem',col);/* no wcWave here: its 9x ring washed the whole table; the rays and rings are the burst */y6Ring(mid.x,mid.y,c,{s0:.9,s1:2.9,dur:600});y6Ring(mid.x,mid.y,'#fff',{s0:.8,s1:2.2,dur:480,delay:70,th:1});
 y6Sparks(mid.x,mid.y-76,10,y6Pal(col),{sp:Math.PI,v0:320,v1:620,g:500});y6Stars(mid.x,mid.y,6,170,['#fff',c]);
 wp.animate([{transform:'translateY(0) scale(1)'},{transform:'translateY(-10px) scale(1.25)',offset:.35},{transform:'translateY(0) scale(1)'}],{duration:320,easing:'ease-out'});
 await wcSleep(250);w.animate([{transform:'scale(1)',opacity:1},{transform:'scale(.6)',opacity:0}],{duration:220,easing:'ease-in',fill:'forwards'}).finished.then(()=>w.remove(),()=>w.remove());await wcSleep(80)}}
/* ---------- Turnabout: the direction track spins round with two light comets ---------- */
{const R0=wcRev2;wcRev2=async function(e){const r=$('wcring'),fx=$('wcfx');if(wcRM()||!fx)return R0.apply(this,arguments);
 const dir=e.dir<0?-1:1;wcFx('whoosh');
 if(r){r.classList.toggle('rev',e.dir<0);r.classList.remove('flip');const b=getComputedStyle(r).transform,base=b&&b!=='none'?b:'';
  r.animate([{transform:`${base} rotate(0deg)`},{transform:`${base} rotate(${dir*390}deg)`,offset:.72},{transform:`${base} rotate(${dir*360}deg)`}],{duration:760,easing:'cubic-bezier(.3,.55,.25,1)'});
  const q=wcLocal(r);if(q){const cm=document.createElement('div');cm.className='y6cm';const S=q.w,cx=q.x+q.w/2,cy=q.y+q.h/2,sy=q.h/q.w;
   cm.style.cssText=`left:${y6f(cx-S/2)}px;top:${y6f(cy-S/2)}px;width:${S}px;height:${S}px`;
   const arc=(a0,a1,R)=>{const p=a=>`${y6f(Math.sin(a*Math.PI/180)*R)} ${y6f(-Math.cos(a*Math.PI/180)*R)}`;return `M${p(a0)}A${R} ${R} 0 0 1 ${p(a1)}`};
   const one=k=>`<g transform="rotate(${k*180})"><path d="${arc(-100,-2,100)}" stroke="url(#y6cg${k})" stroke-width="30" stroke-linecap="round" fill="none" opacity=".3"/><path d="${arc(-120,-2,100)}" stroke="url(#y6cg${k})" stroke-width="13" stroke-linecap="round" fill="none"/><path d="${arc(-60,-2,100)}" stroke="#fff" stroke-width="4" stroke-linecap="round" fill="none" opacity=".85"/><circle cx="0" cy="-100" r="22" fill="#8ad8ff" opacity=".22"/><circle cx="0" cy="-100" r="13" fill="#bfe9ff" opacity=".5"/><circle cx="0" cy="-100" r="7" fill="#fff"/></g>`;
   const gd=k=>{const a=(k*180-120)*Math.PI/180,b=(k*180-2)*Math.PI/180;return `<linearGradient id="y6cg${k}" gradientUnits="userSpaceOnUse" x1="${y6f(Math.sin(a)*100)}" y1="${y6f(-Math.cos(a)*100)}" x2="${y6f(Math.sin(b)*100)}" y2="${y6f(-Math.cos(b)*100)}"><stop offset="0" stop-color="#8ad8ff" stop-opacity="0"/><stop offset=".7" stop-color="#8ad8ff" stop-opacity=".7"/><stop offset="1" stop-color="#e8f8ff"/></linearGradient>`};
   cm.innerHTML=`<div><svg viewBox="-120 -120 240 240" style="${dir<0?'transform:scaleX(-1)':''}"><defs>${gd(0)}${gd(1)}</defs>${one(0)}${one(1)}</svg></div>`;fx.appendChild(cm);
   cm.firstChild.animate([{transform:`scaleY(${sy.toFixed(3)}) rotate(0deg)`,opacity:0},{opacity:1,offset:.15},{opacity:1,offset:.7},{transform:`scaleY(${sy.toFixed(3)}) rotate(${dir*560}deg)`,opacity:0}],{duration:900,easing:'cubic-bezier(.25,.6,.3,1)',fill:'forwards'}).finished.then(()=>cm.remove(),()=>cm.remove());
   y6Ring(cx,cy,'#8ad8ff',{sy,s0:2,s1:3.6,dur:700,th:1,a:.7})}}
 const G=WX.G,n=G.P.length;for(let k=0;k<n;k++){const i=((G.turn-e.dir*k)%n+n)%n,s=wcSeatEl(i);if(s)setTimeout(()=>{s.classList.remove('hop');void s.offsetWidth;s.classList.add('hop')},120+k*110)}
 await wcSleep(620)}}
/* ---------- Stun: lightning strikes the seat, the felt cracks, shock rings roll out ---------- */
function y6Av(i){const s=wcSeatEl(i),a=s&&s.querySelector('.wcav'),r=a&&wcLocal(a);return r?{x:r.x+r.w/2,y:r.y+r.h/2,r:r.w/2}:null}
/* a jagged bolt from (tx,-H) down to 0,0 with a fork; tx leans it in from the table side */
function y6Bolt(H,tx){tx=tx||0;let x=tx,p=[[tx,-H]];const n=Math.max(4,Math.round(H/48));for(let k=1;k<n;k++){const b=tx*(1-k/n);x=Math.max(b-24,Math.min(b+24,x-tx/n+y6r(-20,20)));p.push([x,-H+H*k/n])}p.push([0,0]);
 const d='M'+p.map(q=>y6f(q[0])+' '+y6f(q[1])).join('L'),m=p[Math.floor(n/2)],fd=tx>0?-1:1,f=`M${y6f(m[0])} ${y6f(m[1])}L${y6f(m[0]+26*fd)} ${y6f(m[1]+H*.08)}L${y6f(m[0]+20*fd)} ${y6f(m[1]+H*.16)}L${y6f(m[0]+40*fd)} ${y6f(m[1]+H*.24)}`,L=Math.min(tx,0)-60,W=Math.abs(tx)+120;
 return `<svg viewBox="${L} ${-H} ${W} ${H+10}" style="left:${L}px;width:${W}px;height:${H+10}px;top:${-H}px"><g fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="${d}" stroke="#ffe27a" stroke-width="24" opacity=".28"/><path d="${f}" stroke="#ffe27a" stroke-width="14" opacity=".25"/><path d="${d}" stroke="#12081f" stroke-width="12"/><path d="${f}" stroke="#12081f" stroke-width="8"/><path d="${d}" stroke="#fff8c8" stroke-width="7"/><path d="${f}" stroke="#fff8c8" stroke-width="3.6"/><path d="${d}" stroke="#fff" stroke-width="2.4"/></g></svg><i class="y6bc" style="top:${-H}px;left:${y6f(tx-46)}px"></i>`}
function y6Crack(){let s='';for(let k=0;k<7;k++){const a=k/7*6.283+y6r(-.25,.25);let r=60,pts=[];while(r<=104){const j=y6r(-.12,.12);pts.push(y6f(Math.cos(a+j)*r)+' '+y6f(Math.sin(a+j)*r));r+=y6r(12,18)}s+=`<path d="M${pts.join('L')}"/>`}
 return `<svg viewBox="-110 -110 220 220"><g fill="none" stroke-linecap="round" stroke-linejoin="round"><g stroke="#12081f" stroke-width="6">${s}</g><g stroke="#fff4b0" stroke-width="2.6">${s}</g></g></svg>`}
{const K0=wcSkip2;wcSkip2=async function(e){const fx=$('wcfx'),s=wcSeatEl(e.p),av=y6Av(e.p);if(wcRM()||!fx||!av)return K0.apply(this,arguments);wcFx('zap');
 /* the bolt starts below the top bar (Menu stays clear), from a small flash of cloud; the top seat is struck from the stage edge */
 const H=av.y<200?av.y+10:Math.min(330,av.y-84);y6El('y6bolt',y6Bolt(H,av.y<200?0:Math.round((800-av.x)*.16))+'<i class="y6if"></i>',av,900);
 setTimeout(()=>{wcFx('stun');y6El('y6crk',y6Crack(),av,1100);y6Ring(av.x,av.y,'#ffe27a',{s0:.55,s1:2.5,dur:560});y6Ring(av.x,av.y,'#fff',{s0:.5,s1:2,dur:460,delay:90,th:1});
  y6Sparks(av.x,av.y,8,['#fff','#fff1a0','#ffd45a','#8ad8ff'],{v0:320,v1:600,g:500});y6El('wczap','<i></i><i></i><i></i><i></i><i></i>',{x:av.x,y:av.y-av.r-4},1300)},110);
 if(s){s.classList.remove('stun','frz');void s.offsetWidth;s.classList.add('stun','frz');setTimeout(()=>s&&s.classList.remove('frz'),1300)}
 /* the label goes under the nameplate (beside the avatar for the top seat and for you), away from the bolt */
 const nm=s&&s.querySelector('.wcnm'),q=nm&&wcLocal(nm),lab=av.y<200||e.p===WX.me?{x:av.x+av.r+100,y:av.y+(e.p===WX.me?-av.r+4:6)}:q?{x:av.x,y:q.y+q.h+24}:wcCen(e.p,-74);
 wcShake(1);wcPop('Stunned!','stn',lab);await wcSleep(560)}}
/* ---------- the turn handoff: a light runs to whoever is next ---------- */
function y6Hand(a,b){if(wcRM())return;const B=y6Av(b);if(!B)return;const A=a>=0&&a!==b?y6Av(a):null;let dl=0;
 if(A){const cx=(A.x+B.x)/2*.4+800*.6,cy=(A.y+B.y)/2*.4+430*.6,kf=[],N=10;for(let k=0;k<=N;k++){const t=k/N,v=1-t;kf.push({transform:`translate(${y6f(v*v*A.x+2*v*t*cx+t*t*B.x)}px,${y6f(v*v*A.y+2*v*t*cy+t*t*B.y)}px) scale(${(1.6-.5*Math.sin(Math.PI*t)).toFixed(2)})`,opacity:k===0?0:k===N?.4:1})}
  for(let k=0;k<4;k++)y6P(k?'p6dt':'p6dt p6hd',k?'#ffe9a0':'#fff4c0',kf.map(f=>({...f,transform:f.transform.replace(/scale\(([\d.]+)\)/,(m,s)=>`scale(${(s*(1-k*.17)).toFixed(2)})`)})),440,{delay:k*26,ease:'cubic-bezier(.4,0,.3,1)'});dl=420}
 y6Ring(B.x,B.y,'#ffd45a',{s0:.9,s1:1.9,dur:560,delay:dl});y6Stars(B.x,B.y,3,B.r*1.7,['#fff4c0','#ffd45a'],{delay:dl,spread:120})}
/* ---------- the reshuffle: the old pile cards flip face down as they are gathered into the deck, then a quick riffle ---------- */
async function y6Shuffle(){const dk=wcDeckSpot(),pl=wcPileSpot(),B=wcBack(wcBackSel());if(!dk||!pl)return;wcFx('shuffle');
 wcPop('Pile reshuffled','sm',{x:dk.x+dk.w/2,y:dk.y-34});
 const und=[...document.querySelectorAll('#wcdisc .wcc:not(.top)')].reverse(),F=und.map(x=>{const v=x.querySelector('svg');return v?v.outerHTML:null});
 for(let k=0;k<4;k++){const f=F[k],u=und[k];if(u)u.style.visibility='hidden';
  y6Fly(f||B,{x:pl.x,y:pl.y,w:pl.w,h:pl.h},dk,{dur:240,delay:k*30,arc:-56,r0:u?parseFloat(u.style.getPropertyValue('--r'))||0:y6r(-12,12),spin:-40,pk:1.12,nosh:true,flip:!!f,rev:1,fa:[.1,.6]})}
 await wcSleep(300);await y6Riffle(dk,B,4,.4)}
/* ---------- the win: spotlight and a soft beam on the winner, a slow halo behind them, confetti cannons and a coin shower ---------- */
function y6Win(p){const fx=$('wcfx'),av=y6Av(p);if(!fx||!av||wcRM())return;
 /* clear colour labels, banners and a wheel still showing from the last card, so nothing stacks on the win plate */
 fx.querySelectorAll('.wcpop,.y6wh').forEach(e=>{e.animate([{opacity:getComputedStyle(e).opacity},{opacity:0}],{duration:150,fill:'forwards'});setTimeout(()=>e.remove(),160)});
 const sp=y6El('y6spot','',null,4200);if(sp){sp.style.background=`radial-gradient(circle at ${y6f(av.x)}px ${y6f(av.y)}px,#0a041800 0 ${y6f(av.r+46)}px,#0a04188c ${y6f(av.r+150)}px,#0a0418b0 ${y6f(av.r+320)}px)`;sp.animate([{opacity:0},{opacity:1}],{duration:450,fill:'forwards'})}
 /* the beam: a soft cone (static blur) that fades out at the top of the avatar, so the portrait and buttons stay clear */
 if(av.y>200){const H=Math.round(av.y-av.r+6),bm=y6El('y6beam',`<svg viewBox="0 0 360 ${H}" width="360" height="${H}"><defs><linearGradient id="y6bmg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff2c0" stop-opacity=".05"/><stop offset=".6" stop-color="#ffe9a0" stop-opacity=".26"/><stop offset=".9" stop-color="#ffd45a" stop-opacity=".22"/><stop offset="1" stop-color="#ffd45a" stop-opacity="0"/></linearGradient><filter id="y6bmb" x="-30%" y="-5%" width="160%" height="110%"><feGaussianBlur stdDeviation="14"/></filter></defs><path d="M150 -20H210L${y6f(180+av.r+40)} ${H}H${y6f(180-av.r-40)}Z" fill="url(#y6bmg)" filter="url(#y6bmb)"/></svg>`,null,4200);
  if(bm){bm.style.cssText=`left:${y6f(av.x-180)}px;height:${H}px`;bm.animate([{opacity:0,transform:'scaleX(.4)'},{opacity:1,transform:'scaleX(1)'}],{duration:520,easing:'ease-out',fill:'forwards'})}}
 /* the halo turns behind the seat (ground layer), with a hole for the portrait; a warm rim lights the avatar's edge */
 const R=Math.round(av.r+130),ha=y6GEl('y6halo',y6Rays(18,['#ffd45a','#fff0b0'],R,av.r+4,.75),4200);
 if(ha){ha.style.cssText=`left:${y6f(av.x-R)}px;top:${y6f(av.y-R)}px;width:${2*R}px;height:${2*R}px`;ha.animate([{transform:'scale(.4) rotate(0deg)',opacity:0},{transform:'scale(1) rotate(30deg)',opacity:1,offset:.12},{transform:'scale(1.04) rotate(200deg)',opacity:.9}],{duration:4000,easing:'linear',fill:'forwards'})}
 const rm=y6El('y6rim','',av,4200);if(rm){rm.style.cssText+=`;width:${y6f(av.r*2+40)}px;height:${y6f(av.r*2+40)}px;margin:${y6f(-av.r-20)}px`;rm.animate([{opacity:0,transform:'scale(.8)'},{opacity:1,transform:'scale(1)'}],{duration:600,easing:'cubic-bezier(.2,.9,.3,1.2)',fill:'forwards'})}
 const s=wcSeatEl(p),nm=s&&s.querySelector('.wcnm'),q=nm&&wcLocal(nm);if(q){const g=y6El('y6npg','',null,4200);if(g){g.style.cssText=`left:${y6f(q.x-6)}px;top:${y6f(q.y-6)}px;width:${y6f(q.w+12)}px;height:${y6f(q.h+12)}px`;g.animate([{opacity:0},{opacity:1}],{duration:700,iterations:5,direction:'alternate',easing:'ease-in-out',fill:'forwards'})}}
 const C=['#ff4a1f','#1f8cff','#22c55e','#ffc21a','#ffd45a','#fff','#c9a0ff'];
 for(let k=0;k<32;k++){const L=k%2===0,x=L?40:1560,a=L?y6r(-1.35,-.75):Math.PI-y6r(-1.35,-.75),v=y6r(820,1250);
  y6Ball('p6cf',C[k%C.length],x,890,Math.cos(a)*v,Math.sin(a)*v,980,y6r(1900,2500),{vr:y6r(-540,540),rx:y6r(500,1100),s0:y6r(.8,1.3),fo:.75,delay:k*14+y6r(0,60)})}
 for(let k=0;k<14;k++)y6Ball('p6cn',null,av.x+y6r(-240,240),y6r(-160,-40),y6r(-40,40),y6r(150,320),1150,y6r(1300,1700),{fl:y6r(4,7),s0:y6r(.8,1.1),fo:.8,delay:200+k*60});
 y6Stars(av.x,av.y,10,av.r*2.4,['#fff4c0','#ffd45a','#fff'],{delay:150,spread:700});y6Ring(av.x,av.y,'#ffd45a',{s0:.9,s1:2.6,dur:700});
 [500,900,1300].forEach(t=>setTimeout(()=>wcFx('coin'),t))}
/* ---------- events: the wrapper only adds to the chain below it ---------- */
{const a0=wcAnim;wcAnim=async function(e){if(!e||!WX.G||wcRM())return a0.apply(this,arguments);
 if(e.k==='play'){Y6.cur=e.c;Y6.src=null;if(e.p===WX.me){const el=document.querySelector(`.wchc[data-id="${e.c.id}"]`);
   if(el)try{const m=new DOMMatrix(getComputedStyle(el).transform);Y6.src={a:Math.atan2(m.b,m.a)*57.2958,s:Math.hypot(m.a,m.b)*(el.offsetWidth||112)}}catch(x){}}
  try{return await a0.apply(this,arguments)}finally{Y6.cur=null;Y6.src=null}}
 if(e.k==='turn'){const r=a0.apply(this,arguments);try{y6Hand(Y6.lt,e.p)}catch(x){}Y6.lt=e.p;return r}
 if(e.k==='stack'){const r=await a0.apply(this,arguments);const s=$('wcstack');if(s&&s.classList.contains('on')){const q=wcLocal(s);
   s.animate([{transform:'scale(2.6) rotate(-14deg)',opacity:0},{transform:'scale(.84) rotate(3deg)',opacity:1,offset:.42},{transform:'scale(1.12) rotate(-2deg)',offset:.64},{transform:'scale(.97)',offset:.82},{transform:'none'}],{duration:540,easing:'ease-out'});
   if(q)setTimeout(()=>{const x=q.x+q.w/2,y=q.y+q.h/2;y6Ring(x,y,'#ff5a6a',{s0:.5,s1:2,dur:460});y6Sparks(x,y,8,['#ff8a8a','#fff','#ffd45a'],{v0:260,v1:480,g:500})},200);y6Pile(2)}return r}
 if(e.k==='catch'){const av=y6Av(e.p);if(av){y6Ring(av.x,av.y,'#ff5a6a',{s0:.7,s1:2.2,dur:520});y6Ring(av.x,av.y,'#fff',{s0:.7,s1:1.8,dur:440,delay:90,th:1})}return a0.apply(this,arguments)}
 if(e.k==='shuffle'){const d=$('wcdeck');if(!d)return a0.apply(this,arguments);await y6Shuffle();return}
 if(e.k==='win'){try{y6Win(e.p)}catch(x){}return a0.apply(this,arguments)}
 return a0.apply(this,arguments)}}
{const st=document.createElement('style');st.textContent=`
.wcfx .y6pl,.wct>.y6gnd{position:absolute;left:0;top:0;width:0;height:0;pointer-events:none}
.y6pl>i{position:absolute;left:0;top:0;opacity:0;pointer-events:none;border:0;box-shadow:none;padding:0;--c:#fff}
.y6pl>i.p6sk{width:24px;height:4px;margin:-2px -12px;border-radius:3px;background:linear-gradient(90deg,#fff0,var(--c) 50%,#fff)}
.y6pl>i.p6dt{width:15px;height:15px;margin:-7.5px;border-radius:50%;background:radial-gradient(circle,#fff 0 20%,var(--c) 42%,#fff0 70%)}
.y6pl>i.p6dt.p6hd{width:40px;height:40px;margin:-20px;background:radial-gradient(circle,#fff 0 18%,var(--c) 34%,#ffd45a66 50%,#fff0 70%)}
.y6pl>i.p6du{width:50px;height:30px;margin:-15px -25px;border-radius:50%;background:radial-gradient(closest-side,#f6ead8a8,#f6ead840 55%,#f6ead800)}
.y6pl>i.p6rg{width:120px;height:120px;margin:-60px;border-radius:50%;border:6px solid var(--c);box-sizing:border-box;background:radial-gradient(closest-side,#fff0 72%,color-mix(in srgb,var(--c) 40%,#fff0) 96%)}
.y6pl>i.p6rg.p6th{border-width:3px;background:none}
.y6pl>i.p6cf{width:11px;height:17px;margin:-8.5px -5.5px;border-radius:2px;background:linear-gradient(180deg,var(--c) 60%,color-mix(in srgb,var(--c) 70%,#000));box-shadow:inset 0 0 0 1.5px #12081f40}
.y6pl>i.p6cn{width:30px;height:30px;margin:-15px;border-radius:50%;background:radial-gradient(circle at 36% 30%,#fffbe0 0 10%,#ffd45a 32%,#e8a020 66%,#9a5a08);box-shadow:0 0 0 2.5px #12081f,inset 0 0 0 4px #ffe9a080}
.y6pl>i.p6lf{width:20px;height:12px;margin:-6px -10px;border-radius:0 100% 0 100%;background:linear-gradient(135deg,#e0ffc0,var(--c) 70%);box-shadow:inset 0 0 0 1.2px #12081f60}
.y6pl>i.p6dr{width:12px;height:17px;margin:-8.5px -6px;border-radius:50% 50% 50% 50%/64% 64% 36% 36%;background:radial-gradient(circle at 40% 62%,#f4fbff,var(--c) 64%)}
.y6pl>i.p6st{width:18px;height:18px;margin:-9px;background:radial-gradient(circle,#fff 0 16%,var(--c) 34%,#fff0 60%);clip-path:polygon(50% 0,60% 40%,100% 50%,60% 60%,50% 100%,40% 60%,0 50%,40% 40%)}
.wcfx .y6fly,.wcfx .wcfly.y6rc{box-shadow:none;border-radius:12px}.wcfx .wcfly.y6rc0{box-shadow:0 8px 16px #0006}
.wcfx .y6fly.flip .ff,.wcfx .y6fly.flip .fb{box-shadow:0 0 0 1.5px #12081f55}
.wcfx .y6fsh{position:absolute;left:0;top:0;opacity:0;border-radius:18px;background:radial-gradient(closest-side,#05020cc0 45%,#05020c00);pointer-events:none}
/* the motion streak: a soft colour smear with a bright core line, head under the card */
.wcfx .y6tr{position:absolute;left:0;top:0;opacity:0;pointer-events:none;transform-origin:100% 50%;border-radius:50% 40% 40% 50%/50%;
 background:linear-gradient(90deg,#fff0 25%,#ffffffa0) 0 50%/100% 16% no-repeat,linear-gradient(90deg,#fff0,color-mix(in srgb,var(--c) 22%,#fff0) 35%,color-mix(in srgb,var(--c) 62%,#fff0) 75%,color-mix(in srgb,var(--c) 70%,#fff8))}
.wct .wcdisc .wcc.land{animation:y6land .44s cubic-bezier(.2,.8,.3,1)}
/* +2/+4 come down harder */
.wct .wcdisc .wcc.land.y6sl{animation:y6slm .52s cubic-bezier(.2,.8,.3,1)}
@keyframes y6slm{0%{transform:rotate(var(--r)) translateY(-12px) scale(1.12)}30%{transform:rotate(var(--r)) translateY(10px) scale(1.08,.88)}60%{transform:rotate(var(--r)) translateY(-2px) scale(.98,1.03)}100%{transform:rotate(var(--r))}}
@keyframes y6land{0%{transform:rotate(var(--r)) translateY(-8px) scale(1.08)}30%{transform:rotate(var(--r)) translateY(7px) scale(1.06,.91)}60%{transform:rotate(var(--r)) translateY(-1.5px) scale(.985,1.02)}100%{transform:rotate(var(--r))}}
/* banners */
.wcfx .wcpop.y6pop{animation:y6out 1.35s linear forwards;text-shadow:none;-webkit-text-stroke:0;z-index:2}
.wcfx .wcpop.y6lg{animation-duration:2s}
@keyframes y6out{0%,82%{opacity:1;transform:translate(-50%,-50%)}100%{opacity:0;transform:translate(-50%,-64%)}}
.y6ry svg{display:block;width:100%;height:100%}
.y6ban .y6ry{position:absolute;left:50%;top:50%;width:320px;height:320px;margin:-160px;z-index:-1;opacity:0;animation:y6ray 1.3s ease-out forwards}
.y6lg .y6ry{animation-duration:1.9s}
@keyframes y6ray{0%{opacity:0;transform:scale(.4) rotate(0deg)}16%{opacity:1}70%{opacity:.8}100%{opacity:0;transform:scale(1.2) rotate(50deg)}}
.y6bw{position:relative;animation:y6plate .42s cubic-bezier(.2,.9,.3,1.3) both}
.y6bw::before,.y6bw::after{content:'';position:absolute;top:14px;bottom:-6px;width:42px;z-index:-1;background:linear-gradient(180deg,color-mix(in srgb,var(--ac) 55%,#12081f),#12081f);border-radius:4px}
.y6bw::before{left:-28px;clip-path:polygon(0 0,100% 0,100% 100%,0 100%,30% 50%)}
.y6bw::after{right:-28px;clip-path:polygon(0 0,100% 0,70% 50%,100% 100%,0 100%)}
.y6bp{position:relative;padding:3px 32px 8px;border-radius:15px;background:linear-gradient(180deg,color-mix(in srgb,var(--ac) 50%,#2a1866),#150a36 85%);border:3px solid #ffd45a;box-shadow:0 0 0 4px #12081f,0 14px 30px #000b,inset 0 2px 0 #ffffff40,inset 0 -6px 12px #0006}
.y6bp b{position:relative;z-index:1;display:block;font:400 46px/1.05 'Pirata One',Georgia,serif;letter-spacing:.02em;color:var(--tc);-webkit-text-stroke:2.5px #12081f;paint-order:stroke fill;text-shadow:0 4px 0 #12081f,0 0 22px color-mix(in srgb,var(--ac) 70%,#fff0);animation:y6stamp .42s cubic-bezier(.2,.9,.3,1.35) both}
.y6bp .y6clip{position:absolute;inset:0;overflow:hidden;border-radius:12px;pointer-events:none}
.y6bp .y6sn{position:absolute;top:-10px;bottom:-10px;left:0;width:34%;background:linear-gradient(100deg,#fff0,#ffffff55,#fff0);transform:translateX(-140%) skewX(-18deg);animation:y6sheen .8s ease-in-out .3s forwards}
@keyframes y6plate{0%{opacity:0;transform:scale(.55,.4)}35%{opacity:1}100%{opacity:1;transform:scale(1)}}
@keyframes y6stamp{0%{opacity:0;transform:scale(1.6)}40%{opacity:1}100%{opacity:1;transform:scale(1)}}
@keyframes y6sheen{to{transform:translateX(420%) skewX(-18deg)}}
.wcfx .wcpop.y6wn{animation-duration:3.1s}
.y6wn .y6ry{width:600px;height:600px;margin:-300px;animation-duration:3s}
.y6wn .y6bp{padding:6px 54px 14px;background:linear-gradient(180deg,#6a3aa8,#24105a 80%)}
.y6wn .y6bp b{font-size:96px;color:#ffe9a0}
.y6wn{--ac:#ffd45a;--tc:#ffe9a0}
/* small seat labels (Stunned!, Keeps it, Pile reshuffled) */
.wcfx .wcpop.y6tag{animation:y6tag 1.35s cubic-bezier(.2,.9,.3,1.3) forwards}
.y6tag span{display:block;padding:2px 16px 4px;border-radius:999px;background:linear-gradient(180deg,#2c1c66,#150a36);border:2.5px solid #ffd45a;box-shadow:0 0 0 3px #12081f,0 8px 18px #0009;font:800 15px/1.4 var(--ui);color:#fff;letter-spacing:.02em}
.y6tag.stn span{font:400 30px/1.1 'Pirata One',Georgia,serif;color:#ffe27a;padding:1px 18px 4px;background:linear-gradient(180deg,#3a2a10,#1a0e06);-webkit-text-stroke:1.5px #12081f;paint-order:stroke fill}
@keyframes y6tag{0%{opacity:0;transform:translate(-50%,-30%) scale(.6)}18%{opacity:1;transform:translate(-50%,-50%) scale(1.06)}28%{transform:translate(-50%,-50%) scale(1)}82%{opacity:1;transform:translate(-50%,-50%)}100%{opacity:0;transform:translate(-50%,-70%)}}
/* WILD! and CAUGHT! stamps, the stack punch */
.y6stp .y6sp{display:flex;flex-direction:column;align-items:center;padding:2px 24px 6px;border-radius:16px;transform:rotate(-8deg);background:linear-gradient(180deg,#ff6070,#c8283a);border:4px solid #fff4f0;box-shadow:0 0 0 4px #12081f,0 0 0 8px #ffd45a,0 0 0 11px #12081f,0 14px 30px #000b;animation:y6slap .52s cubic-bezier(.3,.9,.35,1.2) both}
.y6stp .y6sp b{font:400 50px/1.05 'Pirata One',Georgia,serif;color:#fff;-webkit-text-stroke:2px #6a0a14;paint-order:stroke fill;text-shadow:0 3px 0 #6a0a14}
.y6stp.caught .y6sp{background:linear-gradient(180deg,#3a1a40,#1a0820);border-color:#ff7a8a}.y6stp.caught .y6sp b{color:#ff8a9a;-webkit-text-stroke-color:#12081f;text-shadow:0 3px 0 #12081f}
.y6stp .y6sp small{font:800 14px var(--ui);color:#fff;letter-spacing:.02em;-webkit-text-stroke:0;margin-top:-2px}
@keyframes y6slap{0%{opacity:0;transform:scale(3.2) rotate(-26deg)}40%{opacity:1;transform:scale(.88) rotate(-7deg)}62%{transform:scale(1.06) rotate(-9deg)}82%{transform:scale(.98) rotate(-8deg)}100%{opacity:1;transform:scale(1) rotate(-8deg)}}
.y6pun b{position:relative;display:block;padding:0 16px 3px;border-radius:999px;background:linear-gradient(180deg,#3a0a1a,#12081f);border:3px solid #ff5a6a;box-shadow:0 0 0 3.5px #12081f,0 10px 22px #000a,inset 0 2px 0 #ffffff26;font:900 46px/1.1 var(--ui);color:#fff;-webkit-text-stroke:0;text-shadow:0 3px 0 #a0182c;animation:y6punch .5s cubic-bezier(.3,.9,.35,1.25) both}
.y6pun .y6pg{position:absolute;left:50%;top:50%;width:200px;height:200px;margin:-100px;border-radius:50%;background:radial-gradient(closest-side,#ff3a5ab0,#ff3a5a40 55%,#ff3a5a00);animation:y6ray 1.1s ease-out forwards}
@keyframes y6punch{0%{opacity:0;transform:scale(2.6)}45%{opacity:1;transform:scale(.86)}70%{transform:scale(1.08)}100%{opacity:1;transform:scale(1)}}
/* the wheel */
.wcfx .y6wh{position:absolute;width:0;height:0;z-index:3;opacity:0}
.y6wh .y6wsh{position:absolute;left:-112px;top:-80px;width:224px;height:224px;border-radius:50%;background:radial-gradient(closest-side,#000a 55%,#0000)}
.y6wh .y6wd{position:absolute;left:-105px;top:-105px;width:210px;height:210px}
.y6wh .y6wd svg{display:block;width:100%;height:100%}
.y6wh .y6wg{position:absolute;left:-105px;top:-105px;width:210px;height:210px;opacity:0;overflow:visible}
.y6wh .y6wp{position:absolute;left:-20px;top:-136px;width:40px;height:40px;transform-origin:50% 20%}
.y6wh .y6ry{position:absolute;left:-180px;top:-180px;width:360px;height:360px;opacity:0}
.y6wh.y6lk .y6ry{animation:y6ray .7s ease-out forwards}
/* turnabout comets, stun bolt and cracks */
.wcfx .y6cm{position:absolute;pointer-events:none}.y6cm>div{width:100%;height:100%;opacity:0}.y6cm svg{width:100%;height:100%;display:block;overflow:visible}
.wcfx .y6bolt{position:absolute;width:0;height:0;z-index:2}
.y6bolt svg{position:absolute;transform-origin:50% 0;animation:y6bolt .7s linear forwards}
@keyframes y6bolt{0%{transform:scaleY(0);opacity:1}14%{transform:scaleY(1);opacity:1}24%{opacity:.3}32%{opacity:1}46%{opacity:.5}56%{opacity:1}100%{transform:scaleY(1);opacity:0}}
.y6bolt .y6bc{position:absolute;width:92px;height:52px;margin-top:-26px;border-radius:50%;background:radial-gradient(closest-side,#fffbe0,#ffe27a90 40%,#ffd45a00);opacity:0;animation:y6if .6s ease-out forwards}
.y6bolt .y6if{position:absolute;left:-110px;top:-110px;width:220px;height:220px;border-radius:50%;background:radial-gradient(closest-side,#fffbe0,#ffe27aa0 35%,#ffd45a30 60%,#fff0);opacity:0;animation:y6if .5s ease-out .08s forwards}
@keyframes y6if{0%{opacity:1;transform:scale(.3)}100%{opacity:0;transform:scale(1.5)}}
.wcfx .y6crk{position:absolute;width:220px;height:220px;margin:-110px;animation:y6crk 1.05s ease-out forwards}.y6crk svg{width:100%;height:100%;display:block}
@keyframes y6crk{0%{opacity:0;transform:scale(.55)}12%{opacity:1;transform:scale(1.04)}22%{transform:scale(1)}70%{opacity:1}100%{opacity:0;transform:scale(1.06)}}
/* the win */
.wcfx .y6spot{position:absolute;inset:0;opacity:0}
.wcfx .y6beam{position:absolute;top:0;width:360px;opacity:0;transform-origin:50% 0}.y6beam svg{display:block;overflow:visible}
.y6gnd>.y6halo{position:absolute;opacity:0}.y6halo svg{display:block;width:100%;height:100%}
.wcfx .y6rim{position:absolute;opacity:0;border-radius:50%;background:radial-gradient(closest-side,#ffd45a00 70%,#ffd45acc 82%,#ffe9a066 90%,#ffd45a00)}
.wcfx .y6npg{position:absolute;border-radius:16px;opacity:0;box-shadow:0 0 0 3px #ffd45a,0 0 26px 6px #ffd45ab0,inset 0 0 14px #ffd45a80}
`;document.head.appendChild(st)}
