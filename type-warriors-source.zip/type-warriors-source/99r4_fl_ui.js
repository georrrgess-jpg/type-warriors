/* ===== UPDATE 10.4, HARVEST MOON RUSH: the mode page and the ways in (99r4, prefix flr) =====
   flrMenu(back) opens the page, in the style of the Monster Mash page (84e) but with the three fields as cards (scene, twist, boss),
   the payout, the milestone track and the run records. Reached from Play › Choose a mode › Events (a card at the top while the festival
   is on), from flrMenu() (the festival hub, agent D, links to it) and from DEV › Cheats. Pending acorns or chests are paid when it opens. */
function flrMenu(back){S.mode='title';S.view='menu';try{flrPayPending()}catch(e){}const bgL=FLRLV[((Date.now()/864e5)|0)%3];const B=flrB(),on=flrOn(),nch=P.fcr||0;
 const lvs=n=>[n,n+3,n+6].join(', ')+'...';
 const field=(L,i)=>{const k=FLR_SEQ[i],q=FLRT[k],M=MON[L.b];return `<div class="flrf" style="--c:${L.a};--tc:${q.c};--di:${(.08+i*.07).toFixed(2)}s"><div class="flrfi" style="background-image:url(${flrThumb(i,520,220)})"><span class="flrfl">Levels ${lvs(i+1)}</span><canvas width="150" height="150" data-flrb="${L.b}" aria-hidden="true"></canvas></div>
  <div class="flrfb"><b class="flrfn">${esc(L.n)}</b><div class="flrtw"><span class="flrti"><canvas width="36" height="36" data-flrt="${k}" aria-hidden="true"></canvas></span><span><em>${q.n}</em><small>${q.d}</small></span></div><span class="flrfo">Boss: <b>${esc(M.n)}</b></span></div></div>`};
 const ms=FLRPAY.ms.map(m=>{const got=B.ms.includes(m.lv);return `<span class="flrmi${got?' got':''}"><i>${got?'✓':m.lv}</i><span><b>Level ${m.lv}</b><small>+${m.a} acorns${m.c?` · ${m.c} chest${m.c>1?'s':''}`:''}</small></span></span>`}).join('');
 show(`<div class="flrm"><div class="flrhd"><span class="flrlt">LIMITED TIME</span><small>${on?esc(flrLeft()):'The harvest is in. The fields rest until next year.'}</small></div>
 <div class="flrtt"><canvas class="flrside" width="150" height="150" data-flrm="flrscare" aria-hidden="true"></canvas><h2>Harvest Moon Rush</h2><canvas class="flrside r" width="150" height="150" data-flrm="flrpie" aria-hidden="true"></canvas></div>
 <p class="flrsub">An Endless run through the harvest fields under a great orange moon. Every level the season plays a new trick on the words. Boons, swaps, gear and companions all work as usual, and the harvest pays well.</p>
 <div class="flrfg">${FLRLV.map(field).join('')}</div>
 <div class="flrrw"><span><b>+50%</b><i>gold</i></span><span><b>+30%</b><i>XP</i></span><span class="fc">${flrSvgChest(30)}<b>1 per boss</b><i>Harvest Chest</i></span><span class="fa">${flrSvgAcorn(24)}<b>30 to 80</b><i>acorns per boss</i></span><span><b>${B.lv||'<em>none yet</em>'}</b><i>deepest level</i></span><span><b>${(B.best||0).toLocaleString()}</b><i>best score</i></span></div>
 <div class="flrms"><span class="flrmh">Milestones<small>once per festival</small></span>${ms}</div>
 <div class="row flrbt"><button id="flrgo" ${on?'':'disabled'}>${on?'Start the Rush':'Event ended'}</button>${typeof flcOpenUI==='function'?`<button class="sm gd" id="flrch">Harvest Chests${nch?` (${nch})`:''}</button>`:''}${typeof fleHub==='function'?'<button class="sm" id="flrfe">Harvest Festival</button>':''}<button class="sm" id="b">Back</button></div></div>`,'m');
 /* the day's field behind the page (the Daily Challenge view draws S.dcv), dimmed by the drawBG hook below */
 S.view='dc';S.dcv=bgL;FLR_BGD=bgL;
 S.back=back||title;$('b').onclick=S.back;$('flrgo').onclick=()=>{if(flrOn())start(0,'flr')};if($('flrch'))$('flrch').onclick=()=>flcOpenUI();if($('flrfe'))$('flrfe').onclick=()=>fleHub();
 ov.querySelectorAll('canvas[data-flrt]').forEach(c=>{const g=c.getContext('2d');g.scale(1,1);flrBlit(g,flrTwIco(c.dataset.flrt),18,18)});
 const rm=matchMedia('(prefers-reduced-motion: reduce)').matches||(typeof PFM==='function'&&PFM()==='low');
 ov.querySelectorAll('canvas[data-flrb],canvas[data-flrm]').forEach(c=>{const id=c.dataset.flrb||c.dataset.flrm,M=MON[id],g=c.getContext('2d'),big=!!c.dataset.flrb;const s=Math.min(c.height*(big?.86:.8)/M.th,c.width*.86/(M.tw||M.th*.9));
  const fn=t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,c.width,c.height);g.save();g.translate(c.width/2-(M.cx||0)*s,c.height-6);g.fillStyle='#0006';g.beginPath();g.ellipse(0,0,M.th*s*.3,6,0,0,TAU);g.fill();g.scale(s,s);try{M.d(g,t,{lg:0})}catch(e){}g.restore()};
  fn(1.2);if(!rm)LIVE.push({cv:c,fn,slow:1})})}
let FLR_BGD=null;
{const d0=drawBG;drawBG=function(){const r=d0.apply(this,arguments);try{if(S.mode==='title'&&S.view==='dc'&&S.dcv&&S.dcv===FLR_BGD){ctx.fillStyle='rgba(10,6,24,.22)';ctx.fillRect(-30,-30,W+60,H+60)}}catch(e){}return r}}
/* the Choose a mode sheet: a Harvest Moon Rush card at the top of Events while the festival is on */
const FLR_ICO=`<svg viewBox="0 0 64 64" width="58" height="58" aria-hidden="true"><circle cx="40" cy="22" r="15" fill="#ffcf7a" stroke="#12081f" stroke-width="3"/><circle cx="35" cy="18" r="3.4" fill="#e8a850"/><circle cx="45" cy="27" r="4.4" fill="#e8a850"/><path d="M6 54c8-10 18-14 28-12s18 6 24 12z" fill="#2a1630" stroke="#12081f" stroke-width="3" stroke-linejoin="round"/><ellipse cx="22" cy="50" rx="11" ry="9" fill="#f08a2a" stroke="#12081f" stroke-width="3"/><path d="M16 43q6 8 0 14M28 43q-6 8 0 14" stroke="#b8501a" stroke-width="2" fill="none"/><path d="M22 41l2-5" stroke="#4a5a1e" stroke-width="3" stroke-linecap="round"/><path d="M48 40l3-4 2 3 3-1-1 3 3 2-4 1 1 3-3-1-2 3-1-3z" fill="#d8401c" stroke="#12081f" stroke-width="1.5" stroke-linejoin="round"/></svg>`;
{const m0=modeSheet;modeSheet=function(){const r=m0.apply(this,arguments);try{flrSheetCard()}catch(e){console.error(e)}return r}}
function flrSheetCard(){if(!flrOn())return;const sh=document.getElementById('dkms');if(!sh)return;
 const ev=sh.querySelector('.dkpv[data-v="e"] .dkmg');if(ev&&!sh.querySelector('#dmflr')){const b=document.createElement('button');b.className='dkm flrcard';b.id='dmflr';b.style.setProperty('--c','#ffb648');const im=flrThumb(0,640,480);if(im)b.style.setProperty('--img',`url(${im})`);
  b.innerHTML=`<span class="dkmi">${FLR_ICO}</span><span class="dkmt"><b>Harvest Moon Rush <i class="flrlt s">LIMITED TIME</i></b><small>A harvest Endless run. A new twist on the words every level. ${esc(flrLeft())}.</small></span><i class="dkchv">›</i>`;
  b.onclick=()=>{try{sh._close&&sh._close()}catch(e){}setTimeout(()=>flrMenu(title),0)};ev.insertBefore(b,ev.firstChild);b.setAttribute('data-first','');const old=ev.querySelector('[data-first]:not(#dmflr)');if(old)old.removeAttribute('data-first')}
 const dv=sh.querySelector('#dmv');if(dv){const sm=dv.querySelector('.dkmt small');if(sm&&!/Harvest/.test(sm.textContent))sm.textContent='Harvest Moon Rush · '+sm.textContent;if(!dv.style.getPropertyValue('--img')){const im=flrThumb(0,640,480);if(im)dv.style.setProperty('--img',`url(${im})`)}}
 /* the events view was written for Halloween alone: name both festivals while they overlap */
 const hh=sh.querySelector('.dkpv[data-v="e"] #dkmsh');if(hh&&/^(Halloween events|Events)$/.test(hh.textContent))hh.textContent='Events';
 const pn=sh.querySelector('.dkpv[data-v="e"] .dkpn');if(pn&&/^(Two separate limited-time modes|The event has closed)/.test(pn.textContent))pn.textContent=`Limited-time modes. Harvest Festival: ${flrLeft()}.`+(typeof hwOn==='function'&&hwOn()?` Halloween: ${hwLeft()}.`:'')}
/* M on the home screen opens Monster Mash while Halloween lasts; after that it opens Harvest Moon Rush while the festival is on */
{const hk0=homeKey;homeKey=function(e){if(HOME&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&(e.key==='m'||e.key==='M')&&!document.querySelector('.dks.on')&&!(typeof hwOn==='function'&&hwOn())&&flrOn()){const ae=document.activeElement;if(!(ae&&ae!==inp&&/INPUT|TEXTAREA|SELECT/.test(ae.tagName))){e.preventDefault();flrMenu(title);return true}}return hk0.apply(this,arguments)}}
/* How to play */
try{const r=HELP&&HELP.Shortcuts&&HELP.Shortcuts.find(x=>x[0]==='R M');if(r&&!/Harvest/.test(r[1]))r[1]=r[1].replace(/\.$/,', then Harvest Moon Rush while the Harvest Festival lasts.')}catch(e){}
try{if(HELP&&HELP.Modes&&!HELP.Modes.some(x=>x[0]==='Harvest Moon Rush'))HELP.Modes.push(['Harvest Moon Rush','A Harvest Festival run (while it lasts): an Endless run through a pumpkin patch, a corn maze and an orchard, with a new twist on the words every level. Every boss pays a Harvest Chest and acorns. Play › Choose a mode › Events.'])}catch(e){}
/* DEV › Cheats: open the page, start at any level, records and milestones */
if(typeof dvxHTML==='function'){const h0=dvxHTML;dvxHTML=function(){let h=h0.apply(this,arguments);try{const B=flrB();
  h+=`<div class="dvx"><h5>Harvest Moon Rush</h5><div class="dvrow"><span>Best level ${B.lv||0} · best score ${(B.best||0).toLocaleString()} · ${B.runs} runs · milestones ${B.ms.join(', ')||'none'} · pending ${B.pa} acorns, ${B.pc} chests · festival ${flrOn()?'on':'off'}</span></div>
   <div class="dvrow">${dvBtn('x:flrmenu','Open the mode page')}<span>Start at level</span>${dvxNum('dvflrlv',1,1,60)}${dvBtn('x:flrgo','Start')}${dvBtn('x:flrms','Clear milestones')}${dvBtn('x:flrreset','Reset records','dg')}</div>`}catch(e){devLog('error','cheats flr: '+e.message)}return h}
 const a0=dvxAct;dvxAct=function(a){if(a==='flrmenu'){flrMenu(title);return}
  if(a==='flrgo'){const lv=dvxVal('dvflrlv',1,60);start(0,'flr');if(lv>1){S.wave=(lv-1)*5;S.en=[];startWave()}return}
  if(a==='flrms'){flrB().ms=[];save();dvxMsg('Harvest Moon Rush milestones cleared.');return}
  if(a==='flrreset'){P.flrb={};flrB();save();dvxMsg('Harvest Moon Rush records reset.');return}
  return a0.apply(this,arguments)}}
{const st=document.createElement('style');st.textContent=`
.flrm{max-width:1180px;margin:0 auto;display:flex;flex-direction:column;align-items:center;gap:10px;flex:none}
.flrhd{display:flex;gap:12px;align-items:center;animation:flrin .5s cubic-bezier(.3,1.5,.5,1) both}.flrhd small{font:700 14px var(--ui,Poppins,system-ui);color:#ffd9a8}
.flrlt{display:inline-block;font:800 11.5px var(--ui,Poppins,system-ui);letter-spacing:1.6px;padding:4px 10px;border-radius:20px;background:linear-gradient(90deg,#ff8a1a,#d8402a);color:#fff;border:1.5px solid #12081f;font-style:normal}.flrlt.s{font-size:9.5px;padding:2px 7px;vertical-align:2px;letter-spacing:1.2px}
.flrtt{display:flex;align-items:center;gap:18px;margin:-6px 0 -10px}.flrtt h2{font:400 66px/1 'Pirata One',Georgia,serif;margin:0;color:#ffcf7a;background:linear-gradient(180deg,#fff0c0 0%,#ffcf7a 45%,#ff8a3a 100%);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;text-shadow:none;animation:flrin .6s cubic-bezier(.3,1.5,.5,1) .04s both}
.flrside{width:96px;height:96px;animation:flrin .6s cubic-bezier(.3,1.5,.5,1) .1s both}.flrside.r{transform:scaleX(-1)}
.flrsub{max-width:820px;text-align:center;margin:0;font:15.5px/1.45 Georgia,serif;opacity:.9}
.flrfg{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px;width:100%}
.flrf{position:relative;border-radius:16px;border:2px solid #12081f;box-shadow:0 0 0 1.5px color-mix(in srgb,var(--c) 70%,transparent),0 10px 22px #000a;background:linear-gradient(180deg,#1c1238f2,#0f0a24f5);overflow:hidden;text-align:left;animation:flrin .55s cubic-bezier(.3,1.5,.5,1) var(--di,0s) both}
.flrfi{position:relative;height:118px;background-size:cover;background-position:center 64%;border-bottom:2px solid #12081f}
.flrfi::after{content:'';position:absolute;inset:0;background:linear-gradient(180deg,#0000 45%,#0f0a24dd)}
.flrfl{position:absolute;z-index:2;left:10px;top:9px;font:800 11px var(--ui,Poppins,system-ui);letter-spacing:1.2px;text-transform:uppercase;color:#fff;background:#12081fcc;border:1px solid color-mix(in srgb,var(--c) 70%,#000);padding:3px 9px;border-radius:12px}
.flrfi canvas{position:absolute;z-index:1;right:4px;bottom:-4px;width:118px;height:118px}
.flrfb{padding:8px 14px 12px;display:flex;flex-direction:column;gap:6px}
.flrfn{font:400 26px/1 'Pirata One',Georgia,serif;color:var(--c)}
.flrtw{display:grid;grid-template-columns:36px 1fr;gap:10px;align-items:start}.flrti canvas{width:36px;height:36px;display:block}
.flrtw em{display:block;font:400 19px/1.05 'Pirata One',Georgia,serif;color:var(--tc);font-style:normal}.flrtw small{display:block;font:13px/1.32 Georgia,serif;opacity:.86}
.flrfo{font:600 12.5px var(--ui,Poppins,system-ui);color:#cdbfe8}.flrfo b{color:#ffd9a8}
.flrrw{display:flex;gap:10px;flex-wrap:wrap;justify-content:center;animation:flrin .5s cubic-bezier(.3,1.5,.5,1) .3s both}
.flrrw>span{min-width:118px;padding:8px 14px;border-radius:12px;background:#120a26e6;border:1.5px solid #12081f;box-shadow:0 0 0 1px #ffb64833;display:flex;flex-direction:column;align-items:center;gap:1px;position:relative}
.flrrw b{font:400 24px/1.25 'Pirata One',Georgia,serif;color:var(--gold,#ffd76a)}.flrrw b em{font:600 13px var(--ui,Poppins,system-ui);color:#bfb4dc;font-style:normal}.flrrw i{font:12.5px Georgia,serif;opacity:.78;font-style:normal}
.flrrw .flric{position:absolute;left:8px;top:8px}.flrrw .fa,.flrrw .fc{padding-left:40px}
.flrms{display:flex;gap:8px;align-items:center;flex-wrap:wrap;justify-content:center;animation:flrin .5s cubic-bezier(.3,1.5,.5,1) .36s both}
.flrmh{display:flex;flex-direction:column;font:400 21px/1 'Pirata One',Georgia,serif;color:#ffcf7a;margin-right:4px}.flrmh small{font:11.5px var(--ui,Poppins,system-ui);color:#bfb4dc;letter-spacing:.4px}
.flrmi{display:flex;align-items:center;gap:8px;padding:5px 12px 5px 6px;border-radius:24px;background:#120a26e6;border:1.5px solid #12081f;box-shadow:0 0 0 1px #ffffff1c}
.flrmi i{width:28px;height:28px;border-radius:50%;display:grid;place-items:center;font:800 13px var(--ui,Poppins,system-ui);font-style:normal;color:#2a1608;background:linear-gradient(180deg,#ffe08a,#e8a030);border:1.5px solid #12081f}
.flrmi b{display:block;font:700 13px var(--ui,Poppins,system-ui);color:#fff}.flrmi small{display:block;font:11.5px var(--ui,Poppins,system-ui);color:#d8c8f0}
.flrmi.got{box-shadow:0 0 0 1.5px #7dffb0aa}.flrmi.got i{background:linear-gradient(180deg,#b8ffd8,#4ad890)}
.flrbt{margin-top:2px}.flrbt #flrgo{font-size:28px;padding:10px 34px}
.flrov h2{font:400 58px/1 'Pirata One',Georgia,serif;margin:0 0 8px;background:linear-gradient(180deg,#fff0c0,#ff9a3a);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;text-shadow:none}
.flrpay{display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin:12px 0 4px}.flrpay>span{position:relative;min-width:104px;padding:8px 14px;border-radius:12px;background:#120a26e6;border:1.5px solid #12081f;box-shadow:0 0 0 1px #ffb64844;display:flex;flex-direction:column;align-items:center;animation:flrin .5s cubic-bezier(.3,1.5,.5,1) both}
.flrpay>span:nth-child(2){animation-delay:.06s}.flrpay>span:nth-child(3){animation-delay:.12s}.flrpay>span:nth-child(4){animation-delay:.18s}.flrpay>span:nth-child(5){animation-delay:.24s}
.flrpay b{font:400 26px/1.3 'Pirata One',Georgia,serif;color:var(--gold,#ffd76a)}.flrpay i{font:12.5px Georgia,serif;opacity:.8;font-style:normal}.flrpay .fa,.flrpay .fc{padding-left:44px}.flrpay .flric{position:absolute;left:10px;top:10px}
.flrnb{color:#ffcf7a}
@keyframes flrin{from{opacity:0;transform:translateY(14px) scale(.96)}to{opacity:1;transform:none}}
.dkm.flrcard{border-color:#ffb648aa}.dkm.flrcard .dkmt b{display:flex;align-items:center;gap:8px;white-space:nowrap}
#ov.dknar .flrfg{grid-template-columns:1fr}
@media (prefers-reduced-motion: reduce){.flrm *,.flrov *,.flrpay>span{animation:none!important}}`;document.head.appendChild(st)}
