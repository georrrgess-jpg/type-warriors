/* ===== MOONLIT FISHING update 7: art for the five Lighthouse Cove fish (sprat, blenny, wreckfin, seahorse, wraith) =====
   Same contract as every fish: FISHART.<id>=(g,t,o), centred, facing right, ~200 units long, inside x -115..115 /
   y -80..80. o.flex thrashes, o.glow lights the catch spectacle. fishDraw renders silhouettes with o.sil===0, so
   ambient glows, beams, fog and loose motes are skipped there and the shadow keeps a crisp outline.
   Private helpers are prefixed fa10_ (this file never depends on another art file's internals). */
function fa10_path(g,c){g.beginPath();let i=0;while(i<c.length){const k=c[i++];
 if(k==='M'){g.moveTo(c[i],c[i+1]);i+=2}else if(k==='L'){g.lineTo(c[i],c[i+1]);i+=2}
 else if(k==='Q'){g.quadraticCurveTo(c[i],c[i+1],c[i+2],c[i+3]);i+=4}else if(k==='C'){g.bezierCurveTo(c[i],c[i+1],c[i+2],c[i+3],c[i+4],c[i+5]);i+=6}
 else if(k==='Z')g.closePath()}}
function fa10_poly(g,p){g.beginPath();g.moveTo(p[0],p[1]);for(let i=2;i<p.length;i+=2)g.lineTo(p[i],p[i+1]);g.closePath()}
function fa10_grad(g,x0,y0,x1,y1,s){const q=g.createLinearGradient(x0,y0,x1,y1);for(const e of s)q.addColorStop(e[0],e[1]);return q}
function fa10_rgrad(g,x,y,r0,r1,s){const q=g.createRadialGradient(x,y,r0,x,y,r1);for(const e of s)q.addColorStop(e[0],e[1]);return q}
function fa10_at(g,x,y,a,fn){g.save();g.translate(x,y);g.rotate(a);fn();g.restore()}
const fa10_tw=(t,i,sp)=>.5+.5*Math.sin(t*(sp||3)+i*1.91);
function fa10_rgba(h,a){const n=parseInt(h.slice(1,7),16);return `rgba(${n>>16},${n>>8&255},${n&255},${a})`}
const fa10_hsl=(h,a,l,s)=>`hsla(${h|0},${s==null?92:s}%,${l||66}%,${a==null?1:a})`;
/* closed smooth spline through points (same curve as fkPath), optionally appended to the current path */
function fa10_blob(g,p,cont){const n=p.length/2,mx=i=>(p[(i%n)*2]+p[((i+1)%n)*2])/2,my=i=>(p[(i%n)*2+1]+p[((i+1)%n)*2+1])/2;if(!cont)g.beginPath();g.moveTo(mx(n-1),my(n-1));for(let i=0;i<n;i++)g.quadraticCurveTo(p[i*2],p[i*2+1],mx(i),my(i));g.closePath()}
/* ribbon outline around a spine P=[[x,y],..] with half widths W; returns a path builder */
function fa10_ribbon(g,P,W){const L=[],R=[],n=P.length;
 for(let i=0;i<n;i++){const a=P[Math.max(0,i-1)],b=P[Math.min(n-1,i+1)];let dx=b[0]-a[0],dy=b[1]-a[1];const d=Math.hypot(dx,dy)||1;dx/=d;dy/=d;
  L.push([P[i][0]-dy*W[i],P[i][1]+dx*W[i]]);R.push([P[i][0]+dy*W[i],P[i][1]-dx*W[i]])}
 const f=()=>{g.beginPath();g.moveTo(L[0][0],L[0][1]);for(let i=1;i<n;i++){const m=[(L[i-1][0]+L[i][0])/2,(L[i-1][1]+L[i][1])/2];g.quadraticCurveTo(L[i-1][0],L[i-1][1],m[0],m[1])}
  g.lineTo(L[n-1][0],L[n-1][1]);g.lineTo(R[n-1][0],R[n-1][1]);for(let i=n-2;i>=0;i--){const m=[(R[i+1][0]+R[i][0])/2,(R[i+1][1]+R[i][1])/2];g.quadraticCurveTo(R[i+1][0],R[i+1][1],m[0],m[1])}
  g.lineTo(R[0][0],R[0][1]);g.closePath()};f.L=L;f.R=R;return f}
/* stroke an open polyline through points (smoothed) */
function fa10_line(g,P){g.beginPath();g.moveTo(P[0][0],P[0][1]);for(let i=1;i<P.length-1;i++){g.quadraticCurveTo(P[i][0],P[i][1],(P[i][0]+P[i+1][0])/2,(P[i][1]+P[i+1][1])/2)}const e=P[P.length-1];g.lineTo(e[0],e[1])}
/* rib lines fanning from a root, clipped to a path */
function fa10_ribs(g,clip,x0,y0,pts,a,c,lw){g.save();clip();g.clip();g.strokeStyle=c||FKO;g.globalAlpha=a==null?.25:a;g.lineWidth=lw||1.2;g.lineCap='round';
 for(let i=0;i<pts.length;i+=2){g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo((x0+pts[i])/2,(y0+pts[i+1])/2*1.03,pts[i],pts[i+1]);g.stroke()}g.restore()}
/* glossy highlight curve inside a clip */
function fa10_gloss(g,clip,x0,y0,cx,cy,x1,y1,w,a){g.save();clip();g.clip();g.lineCap='round';g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo(cx,cy,x1,y1);
 g.strokeStyle=`rgba(255,255,255,${a*.35})`;g.lineWidth=w*2.4;g.stroke();g.strokeStyle=`rgba(255,255,255,${a})`;g.lineWidth=w;g.stroke();g.restore()}
/* rich cartoon eye: shaded sclera, gradient iris with striations, pupil, two catch-lights */
function fa10_eye(g,x,y,r,iris,look,lookY){look=look||0;lookY=lookY||0;const ix=x+r*.16+look*r*.14,iy=y+r*.05+lookY*r*.14,ir=r*.64;
 g.beginPath();g.arc(x,y,r,0,TAU);g.fillStyle=fa10_rgrad(g,x-r*.25,y-r*.3,r*.1,r*1.05,[[0,'#ffffff'],[.62,'#fbf7f0'],[1,'#d6cde6']]);g.fill();
 g.save();g.beginPath();g.arc(x,y,r,0,TAU);g.clip();
 g.beginPath();g.arc(ix,iy,ir,0,TAU);g.fillStyle=fa10_rgrad(g,ix-ir*.1,iy+ir*.3,ir*.06,ir,[[0,shade(iris,.55)],[.45,iris],[.86,shade(iris,-.38)],[1,shade(iris,-.62)]]);g.fill();
 g.strokeStyle=fa10_rgba(shade(iris,.6),.32);g.lineWidth=Math.max(.6,r*.055);g.beginPath();for(let i=0;i<10;i++){const a=i/10*TAU+.3;g.moveTo(ix+Math.cos(a)*ir*.45,iy+Math.sin(a)*ir*.45);g.lineTo(ix+Math.cos(a)*ir*.92,iy+Math.sin(a)*ir*.92)}g.stroke();
 g.beginPath();g.arc(ix+r*.03,iy+r*.03,ir*.5,0,TAU);g.fillStyle='#0c0612';g.fill();
 g.beginPath();g.arc(x,y-r*.1,r,Math.PI*1.05,Math.PI*1.95);g.strokeStyle='rgba(60,30,80,.18)';g.lineWidth=r*.3;g.stroke();g.restore();
 g.beginPath();g.arc(x,y,r,0,TAU);g.lineWidth=Math.max(2,r*.22);g.strokeStyle=FKO;g.stroke();
 g.beginPath();g.ellipse(ix+r*.2,iy-r*.3,r*.27,r*.22,-.5,0,TAU);g.fillStyle='#fff';g.fill();
 g.beginPath();g.arc(ix-r*.24,iy+r*.3,r*.11,0,TAU);g.fillStyle='rgba(255,255,255,.85)';g.fill()}
/* eyelid: amt 0 open .. 1 shut, drawn across the top of an eye */
function fa10_lid(g,x,y,r,amt,col,tilt){if(amt<=0)return;tilt=tilt||0;const ly=y-r+2*r*Math.min(1,amt);g.save();g.beginPath();g.arc(x,y,r,0,TAU);g.clip();
 g.beginPath();g.moveTo(x-r-3,y-r-3);g.lineTo(x+r+3,y-r-3);g.lineTo(x+r+3,ly+tilt);g.quadraticCurveTo(x,ly+r*.2,x-r-3,ly-tilt);g.closePath();g.fillStyle=col;g.fill();
 g.beginPath();g.moveTo(x+r+3,ly+tilt);g.quadraticCurveTo(x,ly+r*.2,x-r-3,ly-tilt);g.strokeStyle=FKO;g.lineWidth=Math.max(2,r*.24);g.stroke();g.restore();
 g.beginPath();g.arc(x,y,r,0,TAU);g.lineWidth=Math.max(2,r*.22);g.strokeStyle=FKO;g.stroke()}
function fa10_blink(t,s){const p=((t+s)%5.3+5.3)%5.3;return p>5.1?1-Math.abs(p-5.2)/.1:0}
function fa10_blush(g,x,y,r,c,a){g.save();g.globalAlpha=a==null?.45:a;g.fillStyle=fa10_rgrad(g,x,y,0,r,[[0,c],[1,c+'00']]);g.beginPath();g.ellipse(x,y,r,r*.62,0,0,TAU);g.fill();g.restore()}
/* small barnacle cone (side view): base width w, height h, rot */
function fa10_barn(g,x,y,w,h,rot,open){g.save();g.translate(x,y);g.rotate(rot||0);
 const P=()=>fa10_path(g,['M',-w/2,0,'Q',-w*.46,-h*.55,-w*.24,-h,'L',w*.24,-h,'Q',w*.46,-h*.55,w/2,0,'Z']);
 P();fkFill(g,fa10_grad(g,-w/2,-h,w/2,0,[[0,'#fffaf0'],[.5,'#e2d9c6'],[1,'#a89c8c']]),1.6);
 g.save();P();g.clip();g.strokeStyle='rgba(90,70,70,.45)';g.lineWidth=.9;g.beginPath();for(const f of [-.3,0,.3]){g.moveTo(w*f*1.4,0);g.lineTo(w*f*.62,-h)}g.stroke();g.restore();
 g.beginPath();g.ellipse(0,-h,w*.24,Math.max(1,h*.14),0,0,TAU);g.fillStyle='#3a2a3a';g.fill();g.lineWidth=1.2;g.strokeStyle=FKO;g.stroke();
 if(open>0){g.strokeStyle='#ffe6c8';g.lineWidth=.9;g.lineCap='round';for(let i=-2;i<=2;i++){const a=-Math.PI/2+i*.32,L=h*1.1*open;g.beginPath();g.moveTo(0,-h);g.quadraticCurveTo(Math.cos(a)*L*.6,-h+Math.sin(a)*L*.6,Math.cos(a+.5)*L*.9,-h+Math.sin(a+.5)*L*.9+L*.15);g.stroke()}}
 g.restore()}

/* ---------- 1. Lamplight Sprat: a tiny silver-gold sprat with a lamp-spark on its brow ---------- */
FISHART.sprat=(g,t,o)=>{const fx=o.flex||0,gl=o.glow||0,SIL=o.sil===0,sw=fkSway(o,4.6,.15),bend=Math.sin(t*6)*fx*.05,fl=Math.sin(t*5.2);
 const fk=.5+.5*Math.sin(t*7.3)*Math.sin(t*3.1+1),pu=.5+.5*Math.sin(t*2);
 g.save();g.translate(4,Math.sin(t*2.1)*1.6);g.rotate(bend);
 if(!SIL){g.save();g.scale(1,.75);fkGlow(g,30,-20,110,'#ffd27a',.08+.04*pu+gl*.16);g.restore()}
 const BP=[100,5,96,-8,86,-20,66,-29,40,-30,14,-25,-14,-17,-38,-10,-56,-5,-62,0,-56,5,-38,10,-14,17,14,24,40,29,66,29,86,23,96,14],B=()=>fkPath(g,BP);
 // forked tail
 g.save();g.translate(-56,0);g.rotate(sw);g.translate(56,0);
 {const T=()=>fa10_path(g,['M',-52,-5,'C',-66,-10,-86,-24,-106,-37,'Q',-104,-30,-99,-20,'Q',-92,-6,-84,0,'Q',-92,7,-99,20,'Q',-104,30,-106,38,'C',-86,25,-66,11,-52,6,'Z']);
  T();g.globalAlpha=.92;fkFill(g,fa10_grad(g,-52,0,-106,0,[[0,'#f0b840'],[.55,'#f6d888'],[1,'#ffc850']]),2.4);g.globalAlpha=1;
  fa10_ribs(g,T,-54,0,[-104,-34,-100,-24,-94,-12,-88,-3,-88,4,-94,13,-100,25,-104,35],.22);
  g.save();T();g.clip();g.fillStyle='rgba(255,180,60,.35)';g.fillRect(-110,-40,22,80);g.restore();
  fa10_gloss(g,T,-58,-6,-80,-16,-102,-34,1.4,.7)}
 g.restore();
 // dorsal, anal and pelvic fins (translucent gold)
 const fin=(pts,ribs,root)=>{const P=()=>fkPath(g,pts);g.globalAlpha=.9;P();fkFill(g,fa10_grad(g,0,root[1]-14,0,root[1]+14,[[0,'#ffe29a'],[1,'#e8a832']]),2.2);g.globalAlpha=1;fa10_ribs(g,P,root[0],root[1],ribs,.22)};
 fin([-8,-20,2,-36+fl,10,-41+fl,16,-34,24,-24,10,-25],[2,-36,8,-38,15,-32],[8,-22]);
 fin([-38,9,-36,20+fl*.6,-26,24,-16,16],[-34,19,-27,22],[-30,10]);
 fin([10,24,6,36-fl,14,38-fl,22,27],[8,35,14,36],[16,24]);
 // body
 B();fkFill(g,fa10_grad(g,0,-30,0,29,[[0,'#8e5e10'],[.2,'#e4ae36'],[.4,'#f8e4ac'],[.6,'#e4ecf8'],[.82,'#c6d0ee'],[1,'#fff4e0']]),3);
 g.save();B();g.clip();
 // pearly rose-lilac sheen band under the gold back
 g.fillStyle=fa10_grad(g,0,-12,0,6,[[0,'rgba(255,170,210,0)'],[.5,'rgba(230,160,255,.32)'],[1,'rgba(150,220,255,0)']]);g.fillRect(-70,-12,170,18);
 // lamplight warming the head
 g.fillStyle=fa10_rgrad(g,74,-30,2,70,[[0,`rgba(255,214,120,${.55+.2*fk})`],[.5,'rgba(255,190,90,.18)'],[1,'rgba(255,190,90,0)']]);g.fillRect(4,-40,100,80);
 // a mirror glint sweeping along the flank
 {const p=((t*.42)%1)*240-80;g.fillStyle=fa10_grad(g,p-22,-30,p+10,30,[[0,'rgba(255,255,255,0)'],[.5,'rgba(255,255,255,.55)'],[1,'rgba(255,255,255,0)']]);g.fillRect(-70,-34,180,68)}
 g.restore();
 fkScales(g,B,-54,52,-22,22,9,'#8a7aa8',.28);
 // glowing gold lateral line
 g.save();B();g.clip();g.lineCap='round';g.beginPath();g.moveTo(-56,0);g.quadraticCurveTo(0,-7,52,-5);g.strokeStyle='rgba(160,110,30,.5)';g.lineWidth=2.6;g.stroke();
 g.setLineDash([3,4]);g.strokeStyle=`rgba(255,236,160,${.75+.25*pu})`;g.lineWidth=1.6;g.stroke();g.setLineDash([]);g.restore();
 g.save();B();g.clip();for(let i=0;i<7;i++){const x=-34+i*13,y=-13-i*1.7+Math.min(0,(x-40)*-.0);g.beginPath();g.arc(x,y-(x>30?4:0),1.5,0,TAU);g.fillStyle=`rgba(255,240,180,${.55+.35*fa10_tw(t,i,2.6)})`;g.fill()}g.restore();
 // saw-tooth belly keel
 g.save();B();g.clip();g.beginPath();for(let x=-40;x<=56;x+=7){const yb=12+(x+40)*.17;g.moveTo(x,yb+8);g.lineTo(x+3.5,yb+3);g.lineTo(x+7,yb+8)}g.strokeStyle='rgba(130,140,190,.45)';g.lineWidth=1.2;g.stroke();g.restore();
 fkShade(g,B,10,30,'#7a86c8',.28);
 fkHi(g,B,.75,3);
 // gill arc
 g.save();B();g.clip();g.beginPath();g.arc(84,1,30,Math.PI*.7,Math.PI*1.27);g.strokeStyle='rgba(120,80,40,.55)';g.lineWidth=2.4;g.lineCap='round';g.stroke();
 g.beginPath();g.arc(86,1,30,Math.PI*.74,Math.PI*1.22);g.strokeStyle='rgba(255,250,230,.75)';g.lineWidth=1;g.stroke();g.restore();
 // pectoral fin
 fa10_at(g,58,10,.35+Math.sin(t*4.4)*.14*(1+fx),()=>{const P=()=>fa10_path(g,['M',2,-3,'C',-8,-9,-20,-8,-26,-2,'Q',-24,6,-16,8,'C',-8,8,-2,5,2,3,'Z']);g.globalAlpha=.88;P();fkFill(g,fa10_grad(g,0,0,-26,0,[[0,'#ffeec0'],[1,'#f0b64e']]),2);g.globalAlpha=1;fa10_ribs(g,P,1,0,[-25,-3,-22,4,-14,8],.25)});
 // big shiny eye
 {const ex=70,ey=-6,er=14.5;fa10_eye(g,ex,ey,er,'#d48a1a',.25,-.1);fa10_lid(g,ex,ey,er,fa10_blink(t,.7),'#e0b24e');
  g.save();g.globalCompositeOperation='lighter';g.beginPath();g.arc(ex+5,ey-6,2.2+fk*.8,0,TAU);g.fillStyle='rgba(255,230,160,.6)';g.fill();g.restore()}
 fa10_blush(g,84,10,7,'#ff8aa8',.5);
 // tiny smile
 g.beginPath();g.moveTo(99,6);g.quadraticCurveTo(96,11,91,10);g.strokeStyle=FKO;g.lineWidth=2.2;g.lineCap='round';g.stroke();
 // the lamp-spark on the brow: a little teardrop flame in a brass cup
 {const x=76,y=-30,h=14.5+fk*2.5+gl*2;
  if(!SIL){fkGlow(g,x,y-6,30+gl*6,'#ffcf6a',.36+.16*fk+gl*.24);
   g.save();g.globalCompositeOperation='lighter';g.translate(x,y-6);g.rotate(t*.6);for(let i=0;i<6;i++){g.rotate(TAU/6);g.beginPath();g.moveTo(0,-2);g.lineTo(12+(i%2?0:6)+fk*3,0);g.lineTo(0,2);g.closePath();g.fillStyle=`rgba(255,220,140,${.18+.12*fk})`;g.fill()}g.restore()}
  fa10_path(g,['M',x-5,y+2,'Q',x-5.5,y-2,x-3.5,y-3,'L',x+3.5,y-3,'Q',x+5.5,y-2,x+5,y+2,'Q',x,y+4,x-5,y+2,'Z']);fkFill(g,fa10_grad(g,x-5,y,x+5,y,[[0,'#8a5a1a'],[.45,'#ffd36a'],[1,'#a06a20']]),1.6);
  const sx=Math.sin(t*5.7)*1.1;fa10_path(g,['M',x,y-3,'C',x-6,y-5,x-4,y-h*.6,x+sx,y-h,'C',x+4,y-h*.6,x+6,y-5,x,y-3,'Z']);
  fkFill(g,fa10_grad(g,0,y-h,0,y-3,[[0,'#ffffff'],[.4,'#fff1b0'],[1,'#ffb43a']]),1.8);
  fa10_path(g,['M',x,y-4,'C',x-2.6,y-5,x-1.6,y-h*.5,x+sx*.6,y-h*.7,'C',x+1.6,y-h*.5,x+2.6,y-5,x,y-4,'Z']);g.fillStyle='#fffdf2';g.fill();
  if(!SIL)fkSpark(g,x+sx,y-h-2,3+fk*3+gl*2,'#ffffff',.7+.3*fk)}
 if(!SIL){for(let i=0;i<3;i++){const k=fa10_tw(t,i*2.1,2.4);fkSpark(g,[-20,20,48][i],[-14,-20,14][i],1.6+2*k,'#fff6d8',.3+.6*k)}
  if(gl>0)fkGlow(g,30,0,110,'#fff0c0',.22*gl)}
 g.restore()};

/* ---------- 2. Barnacle Blenny: a grumpy whiskery blenny crusted in barnacles ---------- */
/* a barnacle seen from above (crusted on a flank): ring of plates around a dark diamond slit */
function fa10_barnTop(g,x,y,r,rot){g.save();g.translate(x,y);g.rotate(rot||0);g.scale(1,.82);
 fa10_blob(g,[r,0,r*.7,-r*.75,0,-r*1.02,-r*.75,-r*.7,-r,0,-r*.7,r*.72,0,r,r*.72,r*.7]);fkFill(g,fa10_rgrad(g,-r*.3,-r*.45,r*.1,r*1.15,[[0,'#fffbf2'],[.55,'#e2d8c4'],[1,'#a49682']]),1.5);
 g.strokeStyle='rgba(120,96,90,.45)';g.lineWidth=.9;g.beginPath();for(let i=0;i<5;i++){const a=i/5*TAU+.4;g.moveTo(Math.cos(a)*r*.36,Math.sin(a)*r*.36);g.lineTo(Math.cos(a)*r*.86,Math.sin(a)*r*.86)}g.stroke();
 fa10_poly(g,[-r*.34,0,0,-r*.2,r*.34,0,0,r*.2]);g.fillStyle='#3a2632';g.fill();g.strokeStyle='rgba(255,255,255,.5)';g.lineWidth=.8;g.beginPath();g.moveTo(-r*.34,-.6);g.lineTo(0,-r*.2-.6);g.stroke();g.restore()}
FISHART.blenny=(g,t,o)=>{const fx=o.flex||0,gl=o.glow||0,SIL=o.sil===0,sw=fkSway(o,3.1,.14),bend=Math.sin(t*4.6)*fx*.06;
 g.save();g.translate(-1,6+Math.sin(t*1.5)*1.2);g.rotate(-.05+bend);
 const BP=[101,4,100,-16,93,-31,77,-39,54,-36,28,-28,0,-21,-30,-14,-56,-8,-70,-5,-75,1,-70,7,-56,10,-30,15,0,21,30,28,58,33,82,32,97,22],B=()=>fkPath(g,BP);
 const back=x=>-21+(x<0?(-x)*.24:-(x*.27));
 // frilly cirri: little branching tufts like bushy eyebrows
 const cirri=(x,y,s,ph,c)=>{g.save();g.translate(x,y);g.rotate(Math.sin(t*2.2+ph)*.07*(1+fx));g.lineCap='round';
  const fr=[[-8,-2,-14,-12,-19,-15],[-4,-4,-6,-16,-10,-23],[1,-4,2,-18,0,-26],[5,-4,9,-16,10,-23],[8,-2,15,-10,19,-13]];
  const st=(a,b,c2,w,col)=>{g.beginPath();g.moveTo(a[0],a[1]);g.quadraticCurveTo(b[0],b[1],c2[0],c2[1]);g.strokeStyle=col;g.lineWidth=w;g.stroke()};
  for(let pass=0;pass<2;pass++)for(const f of fr){const a=Math.sin(t*3+ph+f[0])*1.3,p0=[f[0]*s,f[1]*s],p1=[f[2]*s+a*.5,f[3]*s],p2=[f[4]*s+a*1.5,f[5]*s];
   const m=[(p0[0]+p1[0]*2)/3,(p0[1]+p1[1]*2)/3],m2=[(p1[0]+p2[0])/2,(p1[1]+p2[1])/2];
   const br=[[m,[m[0]-4.5*s,m[1]-3.5*s]],[m,[m[0]+4*s,m[1]-4*s]],[m2,[m2[0]-3.5*s,m2[1]-2.5*s]],[m2,[m2[0]+3.2*s,m2[1]-3*s]]];
   if(!pass){st(p0,p1,p2,5*s,FKO);for(const b of br)st(b[0],b[0],b[1],3.6*s,FKO)}
   else{st(p0,p1,p2,2.8*s,c);for(const b of br){st(b[0],b[0],b[1],1.7*s,c);g.beginPath();g.arc(b[1][0],b[1][1],1.15*s,0,TAU);g.fillStyle=shade(c,.4);g.fill()}
    g.beginPath();g.arc(p2[0],p2[1],1.9*s,0,TAU);g.fillStyle=shade(c,.45);g.fill()}}
  g.restore()};
 // a strand of seaweed caught on the dorsal fin, streaming back above the body
 const weed=(P0,w,ph)=>{const P=[],W=[],n=P0.length;for(let i=0;i<n;i++){const s=i/(n-1);P.push([P0[i][0]+Math.sin(t*2.1+ph+s*3)*2*s*(1+fx),P0[i][1]+Math.sin(t*2.4+ph-s*4)*4*s*(1+fx)]);W.push(w*(.55+.45*Math.sin(Math.min(1,s*1.4)*Math.PI*.9))*(1-.3*s)+.6)}
  const R=fa10_ribbon(g,P,W);R();fkFill(g,fa10_grad(g,P[0][0],P[0][1],P[n-1][0],P[n-1][1],[[0,'#2a8a40'],[.5,'#56c860'],[1,'#b0f080']]),1.8);
  g.save();R();g.clip();fa10_line(g,P);g.strokeStyle='rgba(20,90,40,.5)';g.lineWidth=1.2;g.stroke();
  g.strokeStyle='rgba(220,255,190,.5)';g.lineWidth=.9;for(let i=1;i<n-1;i++){const p=P[i];g.beginPath();g.moveTo(p[0],p[1]);g.lineTo(p[0]+3,p[1]-W[i]*.8);g.stroke()}g.restore()};
 weed([[-22,-30],[-34,-42],[-48,-47],[-62,-47],[-76,-52],[-88,-57]],4.4,0);
 // far eye bulge (behind the head) with its cirri
 cirri(63,-49,.7,1.3,'#ff7a8a');
 {const ex=64,ey=-41,er=9.5;g.beginPath();g.arc(ex,ey,er+3.4,0,TAU);fkFill(g,fa10_grad(g,0,ey-er,0,ey+er,[[0,'#6a98a0'],[1,'#3a6070']]),2.6);fa10_eye(g,ex,ey,er,'#d0702a',.6,.3);fa10_lid(g,ex,ey,er,.52+fa10_blink(t,1.3)*.48,'#5f8e98',-2)}
 // long spiny dorsal fin: tall frilly front, lower soft rear, turquoise rim
 const dTop=(x,i)=>{const yb=back(x),h=(x>8?22:15)-(x>8?(58-x)*.03:0)+Math.sin(t*3+x*.08)*1.6*(1+fx)+(i%2?-1:1);return [x,yb-h]};
 {const xs=[];for(let x=56;x>=-70;x-=6)xs.push(x);const D=()=>{g.beginPath();g.moveTo(58,back(58)+6);let q=null;xs.forEach((x,i)=>{const p=dTop(x,i);if(!q)g.lineTo(p[0],p[1]);else g.quadraticCurveTo((q[0]+p[0])/2,Math.max(q[1],p[1])+4,p[0],p[1]);q=p});g.lineTo(-74,-2);g.lineTo(-40,back(-40)+6);g.lineTo(10,back(10)+6);g.closePath()};
  g.globalAlpha=.95;D();fkFill(g,fa10_grad(g,0,-62,0,-16,[[0,'#ffd27a'],[.55,'#ff9a4a'],[1,'#e0582e']]),2.4);g.globalAlpha=1;
  g.save();D();g.clip();g.strokeStyle='rgba(70,20,30,.32)';g.lineWidth=1.3;g.beginPath();xs.forEach((x,i)=>{if(i%2)return;const p=dTop(x,i);g.moveTo(x,back(x)+4);g.lineTo(p[0],p[1])});g.stroke();
  g.beginPath();{let q=null;xs.forEach((x,i)=>{const p=dTop(x,i);if(!q)g.moveTo(p[0],p[1]+1.6);else g.quadraticCurveTo((q[0]+p[0])/2,Math.max(q[1],p[1])+5.6,p[0],p[1]+1.6);q=p})}g.strokeStyle='#ffe08a';g.lineWidth=2.4;g.stroke();
  g.fillStyle='rgba(255,240,200,.6)';xs.forEach((x,i)=>{if(i%3)return;g.beginPath();g.arc(x-2,back(x)-6,1.8,0,TAU);g.fill()});g.restore()}
 // anal fin
 {const A=()=>{g.beginPath();g.moveTo(30,24);for(let x=28,i=0;x>=-68;x-=7,i++){const yb=27-(28-x)*.18,h=13+Math.sin(t*3.2+x*.09)*1.3*(1+fx)+(i%2?-2.4:1);g.lineTo(x,yb+h)}g.lineTo(-72,5);g.closePath()};
  g.globalAlpha=.95;A();fkFill(g,fa10_grad(g,0,12,0,44,[[0,'#e0582e'],[1,'#ffc06a']]),2.2);g.globalAlpha=1;
  g.save();A();g.clip();g.beginPath();for(let x=28,i=0;x>=-68;x-=7,i++){const yb=27-(28-x)*.18,h=13+Math.sin(t*3.2+x*.09)*1.3*(1+fx)+(i%2?-2.4:1);x===28?g.moveTo(x,yb+h-1.2):g.lineTo(x,yb+h-1.2)}g.strokeStyle='#ffe08a';g.lineWidth=2.2;g.stroke();g.restore()}
 // fan tail on a slim stalk
 g.save();g.translate(-70,1);g.rotate(sw);g.translate(70,-1);
 {const T=()=>fkPath(g,[-68,-4,-84,-9,-100,-19,-112,-10,-113,1,-112,12,-100,21,-84,11,-68,6]);g.globalAlpha=.95;T();fkFill(g,fa10_grad(g,-70,0,-112,0,[[0,'#e0582e'],[.6,'#ff9a4a'],[1,'#ffd27a']]),2.4);g.globalAlpha=1;
  fa10_ribs(g,T,-70,1,[-100,-17,-108,-10,-111,-2,-111,5,-108,12,-100,19],.3);
  g.save();T();g.clip();g.beginPath();g.arc(-68,1,41,-.75,.75);g.strokeStyle='#ffe08a';g.lineWidth=2.6;g.stroke();
  g.fillStyle='rgba(110,30,30,.35)';for(const s of [[-90,-6],[-96,4],[-88,10],[-102,-6]]){g.beginPath();g.arc(s[0],s[1],1.8,0,TAU);g.fill()}g.restore()}
 g.restore();
 // body
 B();fkFill(g,fa10_grad(g,0,-39,0,33,[[0,'#2c4a5a'],[.3,'#4f7f88'],[.62,'#8fb8b0'],[1,'#f2ead2']]),3);
 g.save();B();g.clip();
 g.fillStyle='rgba(120,70,30,.42)';for(const sx of [44,16,-12,-38,-60]){fa10_blob(g,[sx-8,-44,sx+9,-44,sx+6,-8,sx,2,sx-7,-8]);g.fill()}
 g.fillStyle='rgba(255,236,200,.55)';fa10_blob(g,[96,20,60,22,20,19,-30,12,-40,26,40,42,98,36]);g.fill();
 g.fillStyle='#ffc070';for(let i=0;i<22;i++){const x=-64+((i*47)%150),y=-14+((i*29)%28)-(x>40?6:0);g.beginPath();g.arc(x,y,1.3+(i%3)*.55,0,TAU);g.fill()}
 g.restore();
 fkShade(g,B,8,33,'#2a3a5a',.22);
 fkHi(g,B,.55,3);
 g.save();B();g.clip();g.beginPath();g.arc(86,2,27,Math.PI*.72,Math.PI*1.22);g.strokeStyle='rgba(20,40,50,.6)';g.lineWidth=2.4;g.lineCap='round';g.stroke();g.restore();
 // the barnacle crust: cones along the back and head, flat ones on the flank; the big one on the crown feeds now and then
 g.save();B();g.clip();for(const b of [[12,4,5.6,.3],[-24,-1,4.8,0],[-50,1,3.8,.5],[44,8,4.6,1],[0,12,3.4,.8]])fa10_barnTop(g,b[0],b[1],b[2],b[3]);g.restore();
 fa10_barn(g,28,-27,13,10,-.22,0);fa10_barn(g,38,-31,8,6,-.3,0);fa10_barn(g,-34,-12,10,7,-.15,0);fa10_barn(g,-56,-6,7,5,-.1,0);
 {const op=Math.max(0,Math.sin(t*1.9))**3;fa10_barn(g,48,-34,14,11,-.4,op)}
 // little throat "legs" (pelvic fins) it props itself on
 for(const k of [0,1]){fa10_at(g,72-k*7,30,.25+k*.15+Math.sin(t*2.6+k)*.06,()=>{const P=()=>fa10_path(g,['M',-3,0,'Q',-5,9,-2,15,'Q',1,17,3,14,'Q',4,8,3,0,'Z']);P();fkFill(g,fa10_grad(g,0,0,0,16,[[0,'#e0702e'],[1,'#ffc070']]),2)})}
 // big round pectoral fan with spots
 fa10_at(g,54,12,.55+Math.sin(t*2.8)*.12*(1+fx),()=>{const P=()=>fa10_path(g,['M',3,-5,'C',-8,-17,-30,-17,-36,-2,'C',-36,11,-23,19,-8,15,'Q',0,10,3,5,'Z']);g.globalAlpha=.93;P();fkFill(g,fa10_grad(g,0,0,-36,0,[[0,'#ff9a4a'],[1,'#ffd27a']]),2.2);g.globalAlpha=1;
  fa10_ribs(g,P,2,0,[-34,-9,-36,0,-32,9,-21,15],.3);g.save();P();g.clip();g.fillStyle='rgba(120,40,30,.35)';for(const s of [[-14,-6],[-24,2],[-12,6],[-28,-6]]){g.beginPath();g.arc(s[0],s[1],1.9,0,TAU);g.fill()}
  g.beginPath();g.arc(2,0,36,-2.6,2.6,false);g.strokeStyle='#ffe08a';g.lineWidth=2;g.stroke();g.restore()});
 // near bulging eye: a fleshy socket with a heavy, unimpressed lid
 {const ex=80,ey=-36,er=12.5;g.beginPath();g.arc(ex-1,ey+1,er+4.5,Math.PI*.62,Math.PI*2.38);fkFill(g,fa10_grad(g,0,ey-er,0,ey+er,[[0,'#78a6aa'],[1,'#3a6070']]),2.6);
  fa10_eye(g,ex,ey,er,'#d0702a',.6,.35);fa10_lid(g,ex,ey,er,.5+fa10_blink(t,0)*.5,'#6a98a0',-3.4);
  g.beginPath();g.moveTo(ex-11,ey-16);g.quadraticCurveTo(ex,ey-21,ex+12,ey-13);g.strokeStyle=FKO;g.lineWidth=2.4;g.lineCap='round';g.stroke()}
 cirri(82,-52,.92,0,'#ff8a98');
 // whiskery beard: frilly cirri under the chin
 for(const w of [[96,26,.25,9,0],[90,27,.05,11,1.3],[84,26,-.2,8,2.6]])fa10_at(g,w[0],w[1],w[2]+Math.sin(t*2.3+w[4])*.14*(1+fx),()=>{const L=w[3];g.lineCap='round';
  g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(1.5,L*.5,0,L);g.moveTo(.6,L*.45);g.lineTo(3.4,L*.6);g.moveTo(.4,L*.7);g.lineTo(-2.6,L*.86);g.strokeStyle=FKO;g.lineWidth=3.8;g.stroke();g.strokeStyle='#ff9aa6';g.lineWidth=2;g.stroke();
  g.beginPath();g.arc(0,L,1.8,0,TAU);g.fillStyle='#ffc8d0';g.fill()});
 // big pouty lips
 {fa10_path(g,['M',85,10,'Q',96,3,104,8,'Q',107,13,102,15,'Q',94,12,87,15,'Z']);fkFill(g,fa10_grad(g,0,3,0,15,[[0,'#ff9eaa'],[1,'#e0566a']]),2.3);
  fa10_path(g,['M',87,16,'Q',96,13,104,16,'Q',110,23,101,27,'Q',91,27,86,21,'Z']);fkFill(g,fa10_grad(g,0,13,0,27,[[0,'#ff8a98'],[1,'#c43e58']]),2.3);
  g.lineCap='round';g.beginPath();g.moveTo(93,20);g.quadraticCurveTo(99,18.5,103,21);g.strokeStyle='rgba(255,255,255,.75)';g.lineWidth=1.5;g.stroke();
  g.beginPath();g.moveTo(90,8.5);g.quadraticCurveTo(95,6,99,7);g.stroke()}
 fa10_blush(g,74,8,7,'#ff6a7a',.5);
 if(gl>0&&!SIL)fkGlow(g,20,0,110,'#ffe2c0',.2*gl);
 g.restore()};

/* ---------- 3. Wreckfin Scorpionfish: frilled fins ragged like torn sails, spines like broken masts ---------- */
FISHART.wreckfin=(g,t,o)=>{const fx=o.flex||0,gl=o.glow||0,SIL=o.sil===0,sw=fkSway(o,2.6,.1),bend=Math.sin(t*4.2)*fx*.05,fl=Math.sin(t*2.7);
 g.save();g.translate(-2,7+Math.sin(t*1.4)*1.3);g.rotate(bend);
 const BP=[102,10,98,-8,86,-25,64,-37,36,-40,8,-35,-20,-25,-44,-13,-58,-6,-62,1,-58,8,-44,14,-20,23,8,31,36,36,64,35,86,28,98,20],B=()=>fkPath(g,BP);
 const cloth=(pts,c0,c1)=>{fa10_poly(g,pts);let y0=1e9,y1=-1e9;for(let i=1;i<pts.length;i+=2){y0=Math.min(y0,pts[i]);y1=Math.max(y1,pts[i])}g.globalAlpha=.92;fkFill(g,fa10_grad(g,0,y0,0,y1,[[0,c0],[1,c1]]),2.2);g.globalAlpha=1};
 // soft rear dorsal and anal fin: ragged sail cloth
 {const P=[-18,-24];for(let i=0;i<=7;i++){const x=-20-i*5.4,y=-25+i*2.6,h=(i%2?12:18)-i*.7+Math.sin(t*2.4+i)*1.2*(1+fx);P.push(x,y-h)}P.push(-60,-6,-44,-13);cloth(P,'#f6e2b6','#b5462e')}
 {const P=[-4,30];for(let i=0;i<=6;i++){const x=-6-i*6,y=30-i*3.2,h=(i%2?11:17)-i+Math.sin(t*2.6+i)*1.2*(1+fx);P.push(x,y+h)}P.push(-56,9,-44,14);cloth(P,'#b5462e','#f6e2b6')}
 // fan tail with torn notches
 g.save();g.translate(-58,1);g.rotate(sw);g.translate(58,-1);
 {const T=()=>{g.beginPath();g.moveTo(-56,-6);[[-80,-27],[-94,-30],[-100,-19],[-96,-15],[-107,-9],[-104,1],[-111,8],[-101,14],[-103,23],[-90,29],[-80,25]].forEach(p=>g.lineTo(p[0],p[1]));g.lineTo(-56,8);g.closePath()};
  g.globalAlpha=.93;T();fkFill(g,fa10_grad(g,-56,0,-108,0,[[0,'#c24a2c'],[.6,'#e8a066'],[1,'#f8e2b4']]),2.3);g.globalAlpha=1;
  fa10_ribs(g,T,-56,1,[-92,-29,-102,-15,-107,-2,-107,10,-99,23,-86,27],.32,'#5a1a14');
  g.save();T();g.clip();g.fillStyle='rgba(120,30,20,.4)';for(const s of [[-80,-12],[-90,4],[-84,16],[-96,-6]]){g.beginPath();g.arc(s[0],s[1],2.4,0,TAU);g.fill()}g.restore()}
 g.restore();
 // MASTS and torn sails: the spiny dorsal is three broken masts carrying ragged sail-cloth membranes
 const M=[[52,-36,-80,0],[18,-39,-72,1],[-14,-28,-58,1]];
 const mt=M.map((m,i)=>[m[0]-17+i*2+Math.sin(t*1.8+i)*1.1*(1+fx),m[2]]);
 for(let i=0;i<M.length;i++){const a=mt[i],b=i<M.length-1?mt[i+1]:[-34,-38],a0=[M[i][0],M[i][1]+4],b0=i<M.length-1?[M[i+1][0],M[i+1][1]+4]:[-30,-16];
  // upper edge: hangs from a little below the mast tip, sags, and is torn into ragged tongues
  const E=[];const n=8;for(let k=0;k<=n;k++){const s=k/n,x=a[0]+(b[0]-a[0])*s,y=a[1]+4+(b[1]-a[1])*s+Math.sin(s*Math.PI)*(4+2*fl)+(k%2?4.5:0)+(k===5?7:0);E.push([x+(k%2?2.4:-1),y+(k>0&&k<n?Math.sin(t*3+k+i)*1.1*(1+fx):0)])}
  const hx=(a[0]+b[0])/2+2,hy=(a[1]+b[1])/2+24;
  const P=(hole)=>{g.beginPath();g.moveTo(a0[0],a0[1]);E.forEach(p=>g.lineTo(p[0],p[1]));g.lineTo(b0[0],b0[1]);g.closePath();if(hole&&i===0){g.moveTo(hx+3.6,hy);g.ellipse(hx,hy,3.6,2.6,.3,0,TAU)}};
  g.globalAlpha=.94;P(1);g.fillStyle=fa10_grad(g,0,a[1]+6,0,a0[1],[[0,'#fdf0cc'],[.5,'#ecbc84'],[1,'#b8462c']]);g.fill('evenodd');g.globalAlpha=1;g.lineWidth=2.2;g.strokeStyle=FKO;g.lineJoin='round';g.stroke();
  g.save();P();g.clip();
  g.strokeStyle='rgba(120,60,40,.22)';g.lineWidth=.9;g.beginPath();for(let y=-84;y<-20;y+=4.5){g.moveTo(-40,y);g.lineTo(70,y+4)}g.stroke();
  g.strokeStyle='rgba(120,60,40,.3)';g.beginPath();g.moveTo((a[0]+b[0])/2,a[1]);g.lineTo((a0[0]+b0[0])/2,a0[1]);g.stroke();
  if(i===1){const cx=(a[0]+b[0])/2+1,cy=(a[1]+b[1])/2+24;fa10_poly(g,[cx-6,cy-6,cx+6,cy-7,cx+7,cy+5,cx-5,cy+6]);g.fillStyle='#c98a4a';g.fill();g.strokeStyle='#5a2a1a';g.lineWidth=1.1;g.setLineDash([2,2]);g.stroke();g.setLineDash([])}
  g.restore()}
 // the masts: dark timber with brass bands, splintered stumps; the tallest flies a tattered pennant and carries a yard
 M.forEach((m,i)=>{const tp=mt[i];g.lineCap='round';g.beginPath();g.moveTo(m[0],m[1]+3);g.lineTo(tp[0],tp[1]);g.strokeStyle=FKO;g.lineWidth=7.4;g.stroke();
  g.strokeStyle=fa10_grad(g,tp[0]-3,0,tp[0]+3,0,[[0,'#6a3a1c'],[.5,'#a8703c'],[1,'#5a2e16']]);g.lineWidth=4.4;g.stroke();
  g.beginPath();g.moveTo(m[0]-1.4,m[1]);g.lineTo(tp[0]-1.2,tp[1]+3);g.strokeStyle='rgba(255,220,170,.45)';g.lineWidth=1.1;g.stroke();
  for(const f of [.5]){const bx=m[0]+(tp[0]-m[0])*f,by=m[1]+(tp[1]-m[1])*f;g.beginPath();g.moveTo(bx-3.6,by+.6);g.lineTo(bx+3.6,by-.4);g.strokeStyle=FKO;g.lineWidth=3.6;g.stroke();g.strokeStyle='#ffcf5a';g.lineWidth=1.9;g.stroke()}
  if(m[3]){fa10_poly(g,[tp[0]-3.4,tp[1]+4,tp[0]-2.4,tp[1]-3,tp[0]-.6,tp[1]+.6,tp[0]+.6,tp[1]-5,tp[0]+2,tp[1]-.4,tp[0]+3.4,tp[1]+4]);fkFill(g,'#d8a466',1.5)}
  else{g.beginPath();g.arc(tp[0],tp[1],2.8,0,TAU);fkFill(g,'#ffcf5a',1.5)}});
 {const tp=mt[0];const wv=k=>Math.sin(t*4-k*1.6)*(1.6+k*.8)*(1+fx*.6);
  fa10_path(g,['M',tp[0]-1,tp[1]+3,'Q',tp[0]-10,tp[1]+wv(1),tp[0]-19,tp[1]+3+wv(2),'L',tp[0]-15,tp[1]+6+wv(2),'L',tp[0]-21,tp[1]+9+wv(2.4),'Q',tp[0]-10,tp[1]+10+wv(1),tp[0]-1,tp[1]+9,'Z']);fkFill(g,fa10_grad(g,tp[0],0,tp[0]-20,0,[[0,'#e8483a'],[1,'#a82a2a']]),1.6);
}
 // body
 B();fkFill(g,fa10_grad(g,0,-40,0,36,[[0,'#7a2216'],[.35,'#b8442a'],[.7,'#d8744a'],[1,'#f6caa0']]),3);
 g.save();B();g.clip();
 const blot=(x,y,r,c)=>{fa10_blob(g,[x-r,y,x-r*.4,y-r*.8,x+r*.6,y-r*.7,x+r,y+r*.1,x+r*.3,y+r*.8,x-r*.6,y+r*.6]);g.fillStyle=c;g.fill()};
 [[60,-22,8],[34,-24,9],[8,-18,7],[-18,-12,7],[-40,-6,5],[48,4,6],[20,10,7],[-8,8,6],[-30,10,5],[70,14,5]].forEach((b,i)=>{blot(b[0]+1,b[1]+1,b[2]+1.6,'rgba(80,20,14,.45)');blot(b[0],b[1],b[2],i%3===2?'rgba(255,236,200,.55)':'rgba(226,170,70,.78)');if(i%3!==2){blot(b[0]-b[2]*.25,b[1]-b[2]*.3,b[2]*.35,'rgba(255,240,180,.55)')}});
 g.fillStyle='rgba(70,16,12,.5)';for(let i=0;i<14;i++){g.beginPath();g.arc(-50+((i*41)%140),-20+((i*23)%44),1.4,0,TAU);g.fill()}
 g.restore();
 fkShade(g,B,10,36,'#7a2a3a',.25);
 fkHi(g,B,.5,3);
 g.save();B();g.clip();g.beginPath();g.arc(90,6,30,Math.PI*.7,Math.PI*1.2);g.strokeStyle='rgba(70,14,10,.6)';g.lineWidth=2.6;g.lineCap='round';g.stroke();g.restore();
 for(const s of [[63,10,-.5],[61,20,-.2],[65,0,-.8]]){fa10_at(g,s[0],s[1],Math.PI+s[2],()=>{fa10_poly(g,[0,-2.6,11,0,0,2.6]);fkFill(g,'#f4d4a4',1.5)})}
 const tass=(x,y,a,L,ph)=>fa10_at(g,x,y,a+Math.sin(t*2.4+ph)*.12,()=>{fa10_path(g,['M',-3,0,'Q',-4.5,-L*.5,-1.5,-L,'L',.5,-L*.72,'L',2,-L*.9,'Q',3.5,-L*.4,4,0,'Z']);fkFill(g,fa10_grad(g,0,0,0,-L,[[0,'#c24a2c'],[1,'#f6cc94']]),1.6)});
 tass(94,30,Math.PI-.3,9,2);tass(86,32,Math.PI+.1,7,3);
 // big ragged pectoral fan with the stuck gold coin
 fa10_at(g,38,8,.18+Math.sin(t*2.2)*.08*(1+fx),()=>{const E=[[-10,-14],[-26,-17],[-38,-9],[-41,-4],[-47,4],[-45,10],[-49,16],[-41,25],[-36,22],[-28,33],[-16,30],[-6,22]];
  const P=()=>{g.beginPath();g.moveTo(2,-5);E.forEach(p=>g.lineTo(p[0],p[1]));g.lineTo(3,5);g.closePath()};
  g.globalAlpha=.93;P();fkFill(g,fa10_grad(g,0,0,-44,14,[[0,'#c8502e'],[.55,'#ea9c64'],[1,'#f8e2b6']]),2.3);g.globalAlpha=1;
  fa10_ribs(g,P,2,0,[-26,-17,-40,-6,-47,6,-47,16,-37,25,-25,33,-10,26],.35,'#5a1a14',1.4);
  g.save();P();g.clip();g.fillStyle='rgba(120,30,20,.45)';for(const s of [[-30,-6],[-36,8],[-22,18],[-14,4]]){g.beginPath();g.arc(s[0],s[1],2.2,0,TAU);g.fill()}g.restore();
  const cx=-30,cy=14;if(!SIL)fkGlow(g,cx,cy,16,'#ffd860',.25+.15*fa10_tw(t,0,2.3)+gl*.3);
  g.beginPath();g.arc(cx,cy,7.4,0,TAU);fkFill(g,fa10_rgrad(g,cx-2,cy-2,1,8.4,[[0,'#fff6c8'],[.45,'#ffd04a'],[1,'#b87a14']]),1.8);
  g.beginPath();g.arc(cx,cy,5,0,TAU);g.strokeStyle='rgba(140,90,10,.7)';g.lineWidth=1;g.stroke();
  fa10_poly(g,[cx,cy-3.2,cx+1,cy-.9,cx+3.2,cy-.7,cx+1.5,cy+.8,cx+2.1,cy+3.2,cx,cy+1.7,cx-2.1,cy+3.2,cx-1.5,cy+.8,cx-3.2,cy-.7,cx-1,cy-.9]);g.fillStyle='rgba(150,95,10,.85)';g.fill();
  if(!SIL){const k=fa10_tw(t,0,2.3);fkSpark(g,cx+3,cy-4,2.6+3.6*k+gl*2,'#fffbe0',.5+.5*k)}});
 fa10_at(g,56,30,.5+fl*.05,()=>{const P=()=>fa10_poly(g,[0,-3,-6,14,-12,10,-16,16,-20,6,-2,-2]);P();fkFill(g,fa10_grad(g,0,0,0,16,[[0,'#c24a2c'],[1,'#f2c08a']]),2)});
 // the eye under a heavy spiny brow, with a frilly skin tassel
 tass(62,-30,-.25,13,0);tass(70,-29,.2,10,1);
 {const ex=69,ey=-14,er=11.5;fa10_eye(g,ex,ey,er,'#e0a020',.45,-.05);fa10_lid(g,ex,ey,er,.32+fa10_blink(t,2)*.68,'#b8442a',-2.6);
  fa10_poly(g,[ex-15,ey-8,ex-9,ey-21,ex-4.5,ey-13,ex+1,ey-25,ex+5,ey-13,ex+10.5,ey-21,ex+15,ey-9,ex+6,ey-12.5,ex-6,ey-11.5]);fkFill(g,fa10_grad(g,0,ey-25,0,ey-8,[[0,'#f8dca8'],[1,'#a83a24']]),1.8)}
 // wide downturned mouth with an underbite and one gold tooth
 {fa10_path(g,['M',74,15,'Q',90,9,104,14,'Q',106,23,99,29,'Q',86,31,77,22,'Z']);fkFill(g,fa10_grad(g,0,11,0,31,[[0,'#d8644a'],[1,'#a83a2a']]),2.4);
  g.beginPath();g.moveTo(78,17.5);g.quadraticCurveTo(90,12,102,16);g.strokeStyle=FKO;g.lineWidth=2.5;g.lineCap='round';g.stroke();
  for(const x of [85,91]){fa10_poly(g,[x-1.9,15.4,x,11.2,x+1.9,14.8]);fkFill(g,'#fff4dc',1.1)}
  fa10_poly(g,[95.8,15,97.8,10.4,99.8,15.4]);fkFill(g,'#ffd04a',1.1);if(!SIL){const k=fa10_tw(t,3,3.1);fkSpark(g,98.2,11.6,1.4+2.4*k,'#fff',.4+.6*k)}}
 if(gl>0&&!SIL)fkGlow(g,20,-10,115,'#ffd8a0',.22*gl);
 g.restore()};

/* ---------- 4. Lighthouse Seahorse: brass-and-cream striped, its crown a glowing lamp with a sweeping beam ---------- */
FISHART.seahorse=(g,t,o)=>{const fx=o.flex||0,gl=o.glow||0,SIL=o.sil===0,sw=fkSway(o,1.6,.034),pu=.5+.5*Math.sin(t*2.2);
 g.save();g.translate(-10,2+Math.sin(t*1.2)*1.8);g.scale(.93,.93);g.rotate(sw+.03);
 const lx=17,ly=-64,ph=t*1.1,dir=Math.cos(ph),face=Math.sin(ph);
 // the beam: a lighthouse sweep seen from the side. It shortens as it swings toward or away from us and flares when it faces us.
 const beam=front=>{if(SIL||(face<0)!==front)return;const L=(100+gl*10)*Math.abs(dir)+6,a=dir>=0?.1:Math.PI-.1,sp=.2;
  g.save();g.globalCompositeOperation='lighter';g.translate(lx,ly);g.rotate(a);
  g.beginPath();g.moveTo(0,-3);g.lineTo(L,-L*sp);g.quadraticCurveTo(L*1.06,0,L,L*sp);g.lineTo(0,3);g.closePath();
  g.fillStyle=fa10_grad(g,0,0,L,0,[[0,`rgba(255,236,170,${.5+gl*.2})`],[.35,`rgba(255,214,120,${.22+gl*.12})`],[1,'rgba(255,200,100,0)']]);g.fill();
  g.beginPath();g.moveTo(0,-1.2);g.lineTo(L*.8,-L*.05);g.lineTo(L*.8,L*.05);g.lineTo(0,1.2);g.closePath();g.fillStyle=fa10_grad(g,0,0,L*.8,0,[[0,'rgba(255,255,240,.5)'],[1,'rgba(255,255,240,0)']]);g.fill();
  for(let i=0;i<6;i++){const s=((t*.12+i*.17)%1),x=s*L*.9,y=Math.sin(i*2.3+t)*x*sp*.7;g.beginPath();g.arc(x,y,1+.6*(i%2),0,TAU);g.fillStyle=`rgba(255,250,220,${.6*Math.sin(s*Math.PI)})`;g.fill()}
  g.restore()};
 if(!SIL){fkGlow(g,lx,ly,27+gl*4,'#ffd77a',.26+.1*pu+gl*.22);fkGlow(g,12,0,92,'#ffcf6a',.05+gl*.16)}
 beam(false);
 // dorsal fin on the back: a fast-fluttering translucent fan with a frilled edge
 {const fr=k=>Math.sin(t*13-k*.9)*1.5*(1+fx);const E=[[-14,-8],[-27,-6],[-33,0],[-35,7],[-33,14],[-27,20],[-14,22]];
  const P=()=>{g.beginPath();g.moveTo(-10,-10);E.forEach((p,k)=>{const q=k?E[k-1]:null;if(!q)g.lineTo(p[0]+fr(k),p[1]);else g.quadraticCurveTo((q[0]+p[0])/2-3+fr(k),(q[1]+p[1])/2,p[0]+fr(k),p[1])});g.lineTo(-10,24);g.closePath()};
  g.globalAlpha=.84;P();fkFill(g,fa10_grad(g,-10,0,-35,0,[[0,'#ffd27a'],[1,'#fff6dc']]),2.2);g.globalAlpha=1;
  fa10_ribs(g,P,-10,7,E.slice(1,6).flatMap((p,k)=>[p[0]+fr(k+1),p[1]]),.32,'#a86a1a');
  g.save();P();g.clip();g.fillStyle=fa10_grad(g,-36,0,-26,0,[[0,'rgba(255,190,90,.55)'],[1,'rgba(255,190,90,0)']]);g.fillRect(-38,-10,14,36);g.restore()}
 // the curled tail: a tapering spiral, banded like a lighthouse, behind the body
 const cu=1+fx*.14*Math.sin(t*5);
 {const pts=[[0,26],[-6,38],[-9,50],[-6,61],[3,69],[15,72],[26,67],[31,57],[28,48],[21,45],[15,49],[15,56],[20,58]],P=[],W=[];
  for(let i=0;i<pts.length;i++){const s=i/(pts.length-1);P.push([pts[i][0]+(pts[i][0]-17)*(cu-1)*s,pts[i][1]+(pts[i][1]-56)*(cu-1)*s]);W.push(10*(1-s)**1.15+1)}
  const R=fa10_ribbon(g,P,W);R();fkFill(g,fa10_grad(g,-10,30,30,70,[[0,'#c8801c'],[.5,'#eaa83a'],[1,'#c8801c']]),2.6);
  g.save();R();g.clip();
  for(let i=1;i<P.length-1;i+=2){const a=P[i],b=P[i+1],dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy)||1,nx=-dy/d,ny=dx/d,w=W[i]+3,m=.18;
   const A=[a[0]+dx*m,a[1]+dy*m],Bq=[b[0]-dx*m,b[1]-dy*m];g.beginPath();g.moveTo(A[0]+nx*w,A[1]+ny*w);g.lineTo(Bq[0]+nx*w,Bq[1]+ny*w);g.lineTo(Bq[0]-nx*w,Bq[1]-ny*w);g.lineTo(A[0]-nx*w,A[1]-ny*w);g.closePath();g.fillStyle='rgba(255,247,226,.9)';g.fill()}
  fa10_line(g,R.L.map((p,i)=>[p[0]*.55+P[i][0]*.45,p[1]*.55+P[i][1]*.45]));g.strokeStyle='rgba(255,255,255,.6)';g.lineWidth=1.4;g.stroke();
  fa10_line(g,R.R.map((p,i)=>[p[0]*.7+P[i][0]*.3,p[1]*.7+P[i][1]*.3]));g.strokeStyle='rgba(140,80,20,.3)';g.lineWidth=2;g.stroke();
  g.restore();
  for(let i=1;i<8;i++){const p=R.L[i];g.beginPath();g.arc(p[0],p[1],1.7,0,TAU);fkFill(g,'#ffe6a8',1.1)}}
 // one continuous outline for head, neck and torso (snout tip -> crown -> back -> tail root -> belly -> throat -> chin)
 const HP=[78,-37,68,-42,54,-46,44,-55,30,-61,16,-61,4,-55,-2,-44,-3,-34,-9,-22,-13,-6,-13,10,-9,22,-4,32,4,36,14,30,24,18,29,2,28,-14,22,-26,24,-32,32,-31,46,-29,60,-30,70,-30,78,-31],H=()=>fkPath(g,HP);
 H();fkFill(g,fa10_grad(g,-13,0,30,0,[[0,'#b06a14'],[.5,'#e8a838'],[1,'#ffd27a']]),3);
 g.save();H();g.clip();
 // brass and cream lighthouse rings around the trunk, gently curved like the plates of a real seahorse
 for(let i=0;i<7;i++){const y=-26+i*9;const c=k=>y+k;
  if(i%2){g.beginPath();g.moveTo(-16,c(-4));g.quadraticCurveTo(8,c(1),34,c(-5));g.lineTo(34,c(3));g.quadraticCurveTo(8,c(9),-16,c(4));g.closePath();g.fillStyle='rgba(255,246,222,.94)';g.fill()}
  g.beginPath();g.moveTo(-16,c(-4));g.quadraticCurveTo(8,c(1),34,c(-5));g.strokeStyle='rgba(140,80,20,.42)';g.lineWidth=1.2;g.stroke()}
 // the snout in cream with brass rings
 g.beginPath();g.moveTo(54,-50);g.lineTo(55.6,-26);g.lineTo(61,-26);g.lineTo(59.4,-50);g.closePath();g.fillStyle='rgba(255,246,222,.85)';g.fill();
 // lamplight pooling on the head and shoulders
 g.fillStyle=fa10_rgrad(g,lx,ly,3,70,[[0,`rgba(255,236,160,${.5+.2*pu})`],[1,'rgba(255,236,160,0)']]);g.fillRect(-20,-70,90,80);
 // shade down the back edge
 g.fillStyle=fa10_grad(g,-14,0,6,0,[[0,'rgba(130,60,20,.42)'],[1,'rgba(130,60,20,0)']]);g.fillRect(-20,-60,28,100);
 g.restore();
 fkHi(g,H,.62,3);
 // knobbly back ridge and the cheek plate
 for(const k of [[-4,-32],[-10,-18],[-13,-3],[-12,12],[-7,25]]){g.beginPath();g.arc(k[0],k[1],2.3,0,TAU);fkFill(g,'#ffe2a0',1.3)}
 g.save();H();g.clip();g.beginPath();g.arc(8,-40,13,-.7,1.3);g.strokeStyle='rgba(140,80,20,.55)';g.lineWidth=2.2;g.lineCap='round';g.stroke();g.restore();
 // small pectoral fin behind the cheek
 fa10_at(g,10,-30,.5+Math.sin(t*9)*.2,()=>{const P=()=>fa10_path(g,['M',0,0,'Q',-11,-5,-13,3,'Q',-9,10,0,4,'Z']);g.globalAlpha=.86;P();fkFill(g,'#fff1c8',1.8);g.globalAlpha=1;fa10_ribs(g,P,0,2,[-12,0,-11,5],.3,'#a86a1a')});
 // a tiny flared mouth at the snout tip
 fa10_path(g,['M',76,-40,'Q',84,-42,84,-34.5,'Q',84,-28,76,-29,'Z']);fkFill(g,fa10_grad(g,0,-42,0,-28,[[0,'#f6c056'],[1,'#c8801c']]),2.2);
 g.beginPath();g.moveTo(84,-34.6);g.lineTo(80,-34);g.strokeStyle=FKO;g.lineWidth=1.8;g.lineCap='round';g.stroke();
 // elegant eye with lashes
 {const ex=26,ey=-46,er=10;g.save();g.lineCap='round';g.strokeStyle=FKO;g.lineWidth=2;for(const a of [-2,-1.62,-1.24]){g.beginPath();g.moveTo(ex+Math.cos(a)*er,ey+Math.sin(a)*er);g.quadraticCurveTo(ex+Math.cos(a)*(er+3),ey+Math.sin(a)*(er+3)-1,ex+Math.cos(a+.25)*(er+5.5),ey+Math.sin(a+.25)*(er+5.5)-1);g.stroke()}g.restore();
  fa10_eye(g,ex,ey,er,'#2a9aa8',.4,0);fa10_lid(g,ex,ey,er,.14+fa10_blink(t,3)*.86,'#f0c25a')}
 fa10_blush(g,38,-35,5.5,'#ff8a7a',.5);
 // the lighthouse lamp crown: brass gallery and railing, glowing lantern room, rust-red dome with a finial
 {const x=lx,y=ly;
  fa10_path(g,['M',x-7,y+9,'L',x-5,y+4,'L',x+5,y+4,'L',x+7,y+9,'Z']);fkFill(g,fa10_grad(g,x-7,0,x+7,0,[[0,'#8a5a1a'],[.5,'#ffd36a'],[1,'#8a5a1a']]),1.7);
  g.beginPath();g.rect(x-8.5,y+2,17,2.6);fkFill(g,'#d89a2a',1.5);
  g.beginPath();g.rect(x-5,y-5,10,7.4);fkFill(g,fa10_grad(g,0,y-5,0,y+2.4,[[0,'#fffbe8'],[.5,'#ffe48c'],[1,'#ffc04a']]),1.5);
  g.beginPath();g.moveTo(x-1.6,y-5);g.lineTo(x-1.6,y+2.4);g.moveTo(x+1.6,y-5);g.lineTo(x+1.6,y+2.4);g.strokeStyle='rgba(120,70,20,.55)';g.lineWidth=.8;g.stroke();
  g.beginPath();g.arc(x,y-1.2,2+pu*.6,0,TAU);g.fillStyle='#ffffff';g.fill();
  fa10_path(g,['M',x-6.4,y-5,'Q',x-5.6,y-11,x,y-12,'Q',x+5.6,y-11,x+6.4,y-5,'Z']);fkFill(g,fa10_grad(g,0,y-12,0,y-5,[[0,'#ff9a6a'],[1,'#b84a2a']]),1.5);
  g.beginPath();g.moveTo(x,y-12);g.lineTo(x,y-15);g.strokeStyle=FKO;g.lineWidth=2.2;g.stroke();g.beginPath();g.arc(x,y-15.4,1.5,0,TAU);fkFill(g,'#ffd36a',1.1);
  if(!SIL){fkGlow(g,x,y-1.2,15+Math.max(0,face)*7+gl*8,'#fff2c0',.5+.3*Math.max(0,face)+gl*.3);if(face>.86){const k=(face-.86)/.14;fkSpark(g,x,y-1.2,5+11*k,'#ffffff',.55+.35*k)}}}
 beam(true);
 if(!SIL){for(let i=0;i<4;i++){const k=fa10_tw(t,i*1.7,2.2);fkSpark(g,[44,-28,42,-30][i],[-4,-48,26,44][i],1.6+2.4*k+gl*1.5,'#fff3c8',.3+.6*k)}}
 g.restore()};

/* ---------- 5. Lanternwraith (MYTHIC): the keeper's ghost-light, carrying his old brass lantern through the fog ---------- */
/* one fog puff: three soft overlapping lobes that drift (skipped for silhouettes) */
function fa10_fog(g,t,x,y,s,ph,a){a=a||.24;const d=Math.sin(t*.6+ph)*4*s,e=Math.cos(t*.45+ph)*3*s;
 g.fillStyle=fa10_rgrad(g,x,y,0,16*s,[[0,`rgba(205,255,244,${a*.7})`],[1,'rgba(205,255,244,0)']]);g.beginPath();g.arc(x,y,16*s,0,TAU);g.fill();
 g.save();g.lineCap='round';g.lineJoin='round';const P=()=>{g.beginPath();g.moveTo(x+8*s,y+d*.3);g.bezierCurveTo(x-4*s,y-7*s+d,x-15*s,y+5*s+e,x-25*s,y-3*s+d*.6);g.quadraticCurveTo(x-33*s,y-9*s+e*.5,x-29*s,y-15*s+d*.4)};
 for(const q of [[15,.13],[9,.18],[5,.18]]){P();g.strokeStyle=`rgba(210,255,246,${a*q[1]})`;g.lineWidth=q[0]*s;g.stroke()}
 g.beginPath();g.moveTo(x+2*s,y+6*s+e*.4);g.quadraticCurveTo(x-10*s,y+11*s+d*.5,x-20*s,y+7*s+e*.3);g.strokeStyle=`rgba(210,255,246,${a*.3})`;g.lineWidth=6*s;g.stroke();g.restore()}
FISHART.wraith=(g,t,o)=>{const fx=o.flex||0,gl=o.glow||0,SIL=o.sil===0,sw=fkSway(o,1.7,.06),bend=Math.sin(t*3.4)*fx*.05,pu=.5+.5*Math.sin(t*1.6);
 const prism=(k,a,l)=>fa10_hsl((t*46+k*58)%360,a,l||74,96);
 g.save();g.translate(-6,3+Math.sin(t*1.1)*1.6);g.scale(.95,.95);g.rotate(bend-.02);
 // the lantern hangs from the lure tip and swings gently; the beam sweeps round like a lighthouse lamp
 const sa=Math.sin(t*1.5)*.13*(1+fx),tipx=97,tipy=-73,lnx=tipx+Math.sin(sa)*10,lny=tipy+Math.cos(sa)*10+12,ph=t*.85,dir=Math.cos(ph),face=Math.sin(ph);
 const beam=front=>{if(SIL||(face<0)!==front)return;const a=dir>=0?1.02:Math.PI-.22,sp=dir>=0?.34:.26,L=dir>=0?Math.min((30+gl*4)*Math.abs(dir)+8,(121-lnx)/.84):(112+gl*8)*Math.abs(dir)+8;
  g.save();g.globalCompositeOperation='lighter';g.translate(lnx,lny+3);g.rotate(a);
  g.beginPath();g.moveTo(0,-5);g.lineTo(L,-L*sp);g.quadraticCurveTo(L*1.08,0,L,L*sp);g.lineTo(0,5);g.closePath();
  g.fillStyle=fa10_grad(g,0,0,L,0,[[0,`rgba(255,226,140,${.62+gl*.2})`],[.45,`rgba(255,200,100,${.3+gl*.1})`],[1,'rgba(255,190,90,0)']]);g.fill();
  g.beginPath();g.moveTo(0,-2);g.lineTo(L*.86,-L*.07);g.lineTo(L*.86,L*.07);g.lineTo(0,2);g.closePath();g.fillStyle=fa10_grad(g,0,0,L*.86,0,[[0,'rgba(255,255,235,.5)'],[1,'rgba(255,255,235,0)']]);g.fill();
  for(let i=0;i<7;i++){const s=((t*.1+i*.143)%1),x=s*L*.9,y=Math.sin(i*2.1+t*.8)*x*sp*.7;g.beginPath();g.arc(x,y,1+.7*(i%2),0,TAU);g.fillStyle=`rgba(255,248,215,${.65*Math.sin(s*Math.PI)})`;g.fill()}
  g.restore()};
 if(!SIL){
  // spectral aura, a drifting prismatic shimmer and a bank of sea fog behind everything
  g.save();g.scale(1,.66);fkGlow(g,4,0,112,'#4affd0',.13+.05*pu+gl*.22);g.restore();
  g.save();g.globalCompositeOperation='lighter';for(let i=0;i<4;i++){const a=t*.18+i*1.57;g.beginPath();g.ellipse(Math.cos(a)*28,Math.sin(a)*10,74,22,a*.25,0,TAU);g.fillStyle=prism(i*1.5,.045+gl*.03,70);g.fill()}g.restore();
  fa10_fog(g,t,-48,34,1.2,0,.16);fa10_fog(g,t,-4,44,1.1,2,.13);fa10_fog(g,t,-62,-22,1,4,.14)}
 beam(false);
 // tattered ribbon streamers for a tail, dissolving into fog wisps
 const streamer=(sp,hw,ph,len,root)=>{const P=[],W=[],n=15;for(let k=0;k<n;k++){const s=k/(n-1);P.push([root[0]-s*len,root[1]+sp*s*1.15+Math.sin(t*2*(1+fx*.6)-s*4+ph)*(2+8*s)*(1+fx*1.2)]);W.push(1.4+hw*Math.sin(Math.min(1,s*1.3)*Math.PI*.85)*(1-.38*s))}
  const R=fa10_ribbon(g,P,W),x1=root[0]-len,L=R.L,Rr=R.R;
  // the trailing edge is torn: notches every few segments
  const path=()=>{g.beginPath();g.moveTo(L[0][0],L[0][1]);for(let i=1;i<n;i++){const p=L[i];if(i>3&&i%3===0){const q=P[i];g.lineTo((p[0]+q[0])/2+2,(p[1]+q[1])/2)}g.lineTo(p[0],p[1])}
   for(let i=n-1;i>=0;i--){const p=Rr[i];if(i>4&&i%3===1){const q=P[i];g.lineTo((p[0]+q[0])/2+2,(p[1]+q[1])/2)}g.lineTo(p[0],p[1])}g.closePath()};
  path();g.fillStyle=fa10_grad(g,root[0],0,x1,0,[[0,'rgba(210,255,244,.8)'],[.3,'rgba(110,240,214,.56)'],[.7,'rgba(80,190,226,.3)'],[1,'rgba(160,220,255,0)']]);if(SIL)g.fillStyle=fa10_grad(g,root[0],0,x1,0,[[0,'#000'],[.7,'rgba(0,0,0,.85)'],[1,'rgba(0,0,0,0)']]);g.fill();
  g.save();path();g.clip();fa10_line(g,P.map((p,i)=>[p[0],p[1]-W[i]*.4]));g.strokeStyle=prism(ph*1.3,.6,80);g.lineWidth=1.8;g.stroke();
  fa10_line(g,P);g.strokeStyle='rgba(255,255,255,.25)';g.lineWidth=.8;g.stroke();g.restore();
  path();g.lineWidth=1.8;g.lineJoin='round';g.strokeStyle=fa10_grad(g,root[0],0,x1,0,[[0,'rgba(14,40,52,.9)'],[.55,'rgba(14,40,52,.45)'],[1,'rgba(14,40,52,0)']]);g.stroke();
  return P[n-2]};
 g.save();g.translate(-44,1);g.rotate(sw);g.translate(44,-1);
 const ends=[streamer(-32,7,0,58,[-42,-3]),streamer(-13,9.5,1.1,62,[-42,-1]),streamer(5,8.5,2.2,60,[-42,1]),streamer(20,7.5,3.3,56,[-42,3]),streamer(32,5.5,4.4,46,[-40,5])];
 if(!SIL)ends.forEach((e,i)=>fa10_fog(g,t,e[0]+12,e[1],.46+.1*(i%2),i*1.7,.26));
 g.restore();
 // lower tattered fins (pelvic and anal ribbons) trailing down into the fog
 const lowfin=(x,y,dx,dy,w,ph)=>{const P=[],W=[],n=10;for(let k=0;k<n;k++){const s=k/(n-1);P.push([x+dx*s+Math.sin(t*2.3+ph-s*3)*4*s*(1+fx),y+dy*s+Math.sin(t*1.7+ph-s*2)*2*s]);W.push(w*(1-s*.75))}
  const R=fa10_ribbon(g,P,W);R();g.fillStyle=fa10_grad(g,x,y,x+dx,y+dy,[[0,'rgba(180,255,238,.66)'],[.6,'rgba(110,210,230,.3)'],[1,'rgba(120,220,230,0)']]);if(SIL)g.fillStyle=fa10_grad(g,x,y,x+dx,y+dy,[[0,'#000'],[.7,'rgba(0,0,0,.8)'],[1,'rgba(0,0,0,0)']]);g.fill();
  g.save();R();g.clip();fa10_line(g,P.map((p,i)=>[p[0]+W[i]*.3,p[1]]));g.strokeStyle=prism(ph+2,.5,80);g.lineWidth=1.4;g.stroke();g.restore();
  R();g.lineWidth=1.6;g.strokeStyle=fa10_grad(g,x,y,x+dx,y+dy,[[0,'rgba(14,40,52,.7)'],[1,'rgba(14,40,52,0)']]);g.stroke();return P[n-2]};
 {const e1=lowfin(40,27,-38,36,7.5,0),e2=lowfin(-2,24,-48,32,6.5,1.4);if(!SIL){fa10_fog(g,t,e1[0]+6,e1[1]-2,.6,2,.24);fa10_fog(g,t,e2[0]+6,e2[1]-2,.6,3,.24)}}
 // the great torn dorsal sail: canvas panels and seams, battens, holes, and ragged strips streaming back
 {const fl=Math.sin(t*1.9);const top=[[48,-35],[36,-60],[20,-73+fl*.5],[2,-74+fl],[-18,-68+fl*1.6],[-40,-61+fl*2.2],[-62,-57+fl*2.8],[-82,-56+fl*3.4]];
  const rag=[[-78,-47],[-70,-51],[-65,-43],[-58,-46],[-49,-36],[-43,-41],[-37,-30],[-27,-33],[-22,-24],[-14,-20]].map(p=>[p[0]+Math.sin(t*2.2+p[0]*.1)*1.6,p[1]+Math.sin(t*2+p[0]*.05)*1.4*(1+fx)]);
  const holes=[[8,-58,4.6,2.6],[-28,-52,3.4,2]];
  const S=h=>{g.beginPath();g.moveTo(56,-31);top.forEach(p=>g.lineTo(p[0],p[1]));rag.forEach(p=>g.lineTo(p[0],p[1]));g.closePath();if(h)for(const q of holes){g.moveTo(q[0]+q[2],q[1]);g.ellipse(q[0],q[1],q[2],q[3],.4,0,TAU)}};
  S(1);g.fillStyle=fa10_grad(g,0,-74,0,-20,[[0,'rgba(170,255,236,.66)'],[.45,'rgba(60,196,190,.5)'],[1,'rgba(36,96,160,.5)']]);if(SIL)g.fillStyle='#000';g.fill('evenodd');
  g.save();S(0);g.clip();
  // sail panels: seams running along the sail, battens fanning from the root
  g.strokeStyle='rgba(230,255,248,.32)';g.lineWidth=1;g.setLineDash([3,2.4]);for(let k=1;k<4;k++){g.beginPath();g.moveTo(54,-31-k*.5);for(let i=0;i<top.length;i++){const p=top[i],b=i<rag.length?rag[Math.min(rag.length-1,8-i)]:rag[0];g.lineTo(p[0]+(b[0]-p[0])*k*.25,p[1]+(b[1]-p[1])*k*.25)}g.stroke()}g.setLineDash([]);
  {const q=((t*.12)%1)*200-120;g.fillStyle=fa10_grad(g,q,-80,q+90,-20,[[0,prism(0,0,70)],[.25,prism(1.5,.22,70)],[.5,prism(3,.22,74)],[.75,prism(4.5,.22,70)],[1,prism(6,0,70)]]);g.fillRect(-90,-80,150,64)}
  for(let i=0;i<7;i++){const k=fa10_tw(t,i*2.2,2.6);fkSpark(g,[24,0,-24,-44,10,-14,-60][i],[-64,-62,-58,-52,-46,-42,-50][i],1.4+2.2*k,'#ffffff',.3+.6*k)}
  g.lineCap='round';for(let i=0;i<7;i++){const p=top[i+1];g.beginPath();g.moveTo(46-i*8.5,-30+i*1.5);g.lineTo(p[0],p[1]);g.strokeStyle='rgba(225,255,246,.5)';g.lineWidth=1.4;g.stroke()}
  if(!SIL){g.globalCompositeOperation='lighter';g.fillStyle=fa10_rgrad(g,lnx,lny,4,120,[[0,`rgba(255,210,120,${.32+.2*Math.max(0,face)})`],[1,'rgba(255,210,120,0)']]);g.fillRect(-90,-80,150,60);g.globalCompositeOperation='source-over'}
  g.beginPath();g.moveTo(56,-31);top.forEach(p=>g.lineTo(p[0],p[1]+1.6));g.strokeStyle=fa10_grad(g,56,0,-82,0,[[0,prism(0,.95,82)],[.33,prism(2,.95,82)],[.66,prism(4,.85,82)],[1,prism(6,.1,82)]]);g.lineWidth=3.2;g.stroke();
  g.restore();
  S(1);g.lineWidth=2;g.lineJoin='round';g.strokeStyle='rgba(14,38,50,.78)';g.stroke();
  // the leading spar: a bone mast with a little brass ring
  g.lineCap='round';g.beginPath();g.moveTo(56,-30);g.lineTo(top[1][0],top[1][1]);g.lineTo(top[2][0],top[2][1]);g.strokeStyle='rgba(14,38,50,.8)';g.lineWidth=4.6;g.stroke();g.strokeStyle='rgba(225,255,246,.9)';g.lineWidth=2.2;g.stroke();
  if(!SIL)fa10_fog(g,t,top[7][0]-2,top[7][1]+5,.85,5,.26)}
 // the spectral body
 const BP=[108,8,104,-8,95,-22,80,-33,58,-39,34,-38,10,-31,-14,-20,-34,-10,-46,-4,-50,1,-46,6,-34,11,-14,18,10,26,34,32,58,35,80,32,96,25,104,18],B=()=>fkPath(g,BP);
 if(!SIL){g.save();g.globalCompositeOperation='lighter';B();g.strokeStyle=`rgba(90,255,214,${.16+.08*pu+gl*.12})`;g.lineWidth=14;g.stroke();B();g.strokeStyle=`rgba(150,255,230,${.2+.08*pu})`;g.lineWidth=7;g.stroke();g.restore()}
 B();g.fillStyle=fa10_grad(g,0,-39,0,35,[[0,'rgba(120,252,218,.6)'],[.42,'rgba(24,128,150,.7)'],[1,'rgba(52,36,140,.8)']]);if(SIL)g.fillStyle='#000';g.fill();
 g.save();B();g.clip();
 // cosmic depth inside the ghost: drifting teal, violet and mythic-pink nebula, and tiny stars
 const neb=[['rgba(130,120,255,.42)',0],['rgba(255,90,216,.34)',2.4],['rgba(90,255,210,.34)',4.4]];
 neb.forEach((n,k)=>{const x=22+34*Math.sin(t*.38+n[1]),y=2+9*Math.sin(t*.55+k),r=34+4*k;g.fillStyle=fa10_rgrad(g,x,y,0,r,[[0,n[0]],[1,'rgba(120,150,255,0)']]);g.fillRect(x-r,y-r,r*2,r*2)});
 for(let i=0;i<16;i++){const k=fa10_tw(t,i*1.3,2.4),x=-38+((i*53)%140),y=-27+((i*31)%54);g.fillStyle=`rgba(255,255,255,${.35+.6*k})`;g.beginPath();g.arc(x,y,.8+.9*k,0,TAU);g.fill();if(i%5===0)fkSpark(g,x,y,2+2.4*k,'#ffffff',.5+.5*k)}
 // warm lantern light washing over the head
 g.fillStyle=fa10_rgrad(g,lnx-6,lny+16,4,100,[[0,`rgba(255,186,90,${.5+.15*Math.max(0,face)+gl*.12})`],[.45,'rgba(255,170,80,.24)'],[1,'rgba(255,170,80,0)']]);g.fillRect(-50,-40,160,80);
 // the faint glowing skeleton (additive)
 const sk=.5+.25*pu+gl*.3;g.globalCompositeOperation='lighter';g.lineCap='round';g.lineJoin='round';
 const spine=[[-48,1],[-26,-1],[-2,-3],[24,-5],[48,-6],[66,-7]];
 fa10_line(g,spine);g.strokeStyle=`rgba(150,255,230,${sk*.3})`;g.lineWidth=6;g.stroke();g.strokeStyle=`rgba(235,255,250,${sk*.85})`;g.lineWidth=1.9;g.stroke();
 g.beginPath();for(let i=0;i<10;i++){const x=-34+i*10,y=-2-i*.45,h=12+Math.sin(i/9*Math.PI*.85+.25)*16;g.moveTo(x,y);g.quadraticCurveTo(x-5,y-h*.6,x-9,y-h);g.moveTo(x,y);g.quadraticCurveTo(x-5,y+h*.6,x-8,y+h*.92)}
 g.strokeStyle=`rgba(210,255,246,${sk*.55})`;g.lineWidth=1.3;g.stroke();
 for(let i=0;i<10;i++){g.beginPath();g.arc(-34+i*10,-2-i*.45,1.6,0,TAU);g.fillStyle=`rgba(240,255,252,${sk*.8})`;g.fill()}
 g.beginPath();g.arc(84,-4,21,Math.PI*.62,Math.PI*1.42);g.moveTo(66,-20);g.quadraticCurveTo(82,-27,98,-14);g.moveTo(70,16);g.quadraticCurveTo(86,22,100,13);
 g.strokeStyle=`rgba(225,255,250,${sk*.7})`;g.lineWidth=1.6;g.stroke();
 g.globalCompositeOperation='source-over';
 g.restore();
 // spectral rim: a crisp dark edge, a bright inner glow and a prismatic sheen along the back
 B();g.lineWidth=2.8;g.lineJoin='round';g.strokeStyle='rgba(12,34,46,.9)';g.stroke();
 g.save();B();g.clip();B();g.strokeStyle=`rgba(190,255,236,${.8+.2*pu})`;g.lineWidth=5;g.stroke();B();g.strokeStyle='rgba(255,255,255,.5)';g.lineWidth=1.6;g.stroke();
 if(!SIL){g.globalCompositeOperation='lighter';B();g.strokeStyle=fa10_rgrad(g,lnx,lny,10,90,[[0,'rgba(255,214,120,.95)'],[.6,'rgba(255,190,90,.35)'],[1,'rgba(255,190,90,0)']]);g.lineWidth=6;g.stroke();g.globalCompositeOperation='source-over'}
 g.beginPath();g.moveTo(-38,-9);g.quadraticCurveTo(30,-46,102,-13);g.strokeStyle=fa10_grad(g,-38,0,102,0,[[0,prism(1,0,82)],[.3,prism(2,.6,84)],[.6,prism(3.5,.65,84)],[1,prism(5,.25,84)]]);g.lineWidth=3.4;g.stroke();
 fkShade(g,B,10,34,'#1a3a8a',.25);g.restore();
 // ghostly barbels: the old keeper's whiskers, curling back into fog
 {g.lineCap='round';const ends=[];for(const b of [[100,20,0,40],[94,24,1.3,46]]){const P=[],n=8;for(let k=0;k<n;k++){const s2=k/(n-1);P.push([b[0]-s2*b[3]*.85+Math.sin(t*1.8+b[2]-s2*3)*3*s2,b[1]+s2*b[3]*.5+Math.sin(t*1.5+b[2]-s2*2.6)*4*s2*(1+fx)-s2*s2*10])}
   fa10_line(g,P);g.strokeStyle='rgba(12,34,46,.55)';g.lineWidth=4;g.stroke();fa10_line(g,P);g.strokeStyle=fa10_grad(g,P[0][0],P[0][1],P[n-1][0],P[n-1][1],[[0,'rgba(235,255,250,.95)'],[1,'rgba(160,240,230,.1)']]);g.lineWidth=2.2;g.stroke();ends.push(P[n-1])}
  if(!SIL)fa10_fog(g,t,ends[1][0],ends[1][1],.5,6,.24)}
 // tattered translucent pectoral fin
 fa10_at(g,62,14,.62+Math.sin(t*2.6)*.14*(1+fx),()=>{const P=()=>fa10_path(g,['M',2,-4,'C',-12,-12,-34,-10,-48,-2,'L',-40,1,'L',-46,7,'L',-33,8,'L',-34,14,'L',-24,12,'C',-13,13,-2,6,2,4,'Z']);P();g.fillStyle=SIL?'#000':fa10_grad(g,0,0,-40,0,[[0,'rgba(200,255,240,.7)'],[1,'rgba(120,230,226,.35)']]);g.fill();
  g.save();P();g.clip();g.beginPath();g.moveTo(2,-4);g.bezierCurveTo(-10,-12,-30,-10,-40,-1);g.strokeStyle=prism(3,.6,82);g.lineWidth=2.2;g.stroke();g.restore();
  P();g.lineWidth=1.7;g.lineJoin='round';g.strokeStyle='rgba(12,34,46,.75)';g.stroke();fa10_ribs(g,P,1,0,[-46,-1,-42,6,-32,11],.65,'#e8fff8',1)});
 // the lure stalk: a ghostly antenna from the brow, beaded with light, curving up and forward
 {const S=[[78,-32],[78,-54],[84,-70],[tipx,tipy]];g.lineCap='round';fa10_line(g,S);g.strokeStyle='rgba(12,34,46,.85)';g.lineWidth=5.6;g.stroke();g.strokeStyle='rgba(180,255,238,.92)';g.lineWidth=2.8;g.stroke();
  g.strokeStyle='rgba(255,255,255,.7)';g.lineWidth=1;g.stroke();
  for(const b of [[78,-46],[80,-60]]){g.beginPath();g.arc(b[0],b[1],2,0,TAU);fkFill(g,'#e8fff8',1.2)}
  // chain links down to the lantern's bail
  g.beginPath();g.moveTo(tipx,tipy);g.lineTo(lnx,lny-14);g.strokeStyle='rgba(50,30,16,.95)';g.lineWidth=2.2;g.stroke();g.strokeStyle='#e0a83a';g.lineWidth=1;g.stroke();
  g.beginPath();g.arc(tipx,tipy,2.4,0,TAU);fkFill(g,'#e0a83a',1.3)}
 // the eye: a warm, kindly lamplit glow
 {const ex=83,ey=-9,er=11.5;if(!SIL)fkGlow(g,ex,ey,24,'#ffe7a0',.34+.14*pu+gl*.3);
  g.beginPath();g.arc(ex,ey,er,0,TAU);g.fillStyle=fa10_rgrad(g,ex+2,ey,0,er,[[0,'#ffffff'],[.3,'#fff2b0'],[.68,'#ffc048'],[1,'#b0601a']]);g.fill();g.lineWidth=2.5;g.strokeStyle=FKO;g.stroke();
  g.beginPath();g.ellipse(ex+2.6,ey+.6,3.4,5.6,0,0,TAU);g.fillStyle='rgba(70,30,20,.82)';g.fill();g.beginPath();g.arc(ex+4.4,ey-3.8,2.5,0,TAU);g.fillStyle='#fff';g.fill();
  g.beginPath();g.arc(ex-3,ey+4,1.1,0,TAU);g.fill();
  g.beginPath();g.moveTo(ex-10,ey-13);g.quadraticCurveTo(ex,ey-17,ex+10,ey-12.5);g.strokeStyle='rgba(12,34,46,.85)';g.lineWidth=2;g.stroke()}
 g.beginPath();g.moveTo(105,9);g.quadraticCurveTo(100,14,93,12);g.strokeStyle='rgba(12,34,46,.9)';g.lineWidth=2.2;g.lineCap='round';g.stroke();
 // the old brass ship's lantern
 {const x=lnx,y=lny;
  if(!SIL){fkGlow(g,x,y+2,25+gl*5,'#ffc860',.55+.2*pu+gl*.3);
   // ripples of lamplight (like the rings of a lighthouse lens) expanding from the lamp
   // a lighthouse-lens corona: Fresnel rings, slow turning rays and an expanding ripple of lamplight
   g.save();g.globalCompositeOperation='lighter';g.translate(x,y+2);
   g.save();g.rotate(t*.25);for(let i=0;i<12;i++){g.rotate(TAU/12);const L=(i%2?17:23)+gl*2;g.beginPath();g.moveTo(9,-1.6);g.lineTo(L,0);g.lineTo(9,1.6);g.closePath();g.fillStyle=fa10_grad(g,9,0,L,0,[[0,`rgba(255,226,150,${.42+gl*.2})`],[1,'rgba(255,226,150,0)']]);g.fill()}g.restore();
   for(const r of [[13,.42],[17,.3],[21,.18]]){g.beginPath();g.arc(0,0,r[0],0,TAU);g.strokeStyle=`rgba(255,222,140,${r[1]+gl*.15})`;g.lineWidth=1.4;g.stroke()}
   g.beginPath();g.arc(0,0,19,t*.6,t*.6+2.2);g.strokeStyle=prism(2,.55,80);g.lineWidth=1.6;g.stroke();g.beginPath();g.arc(0,0,19,t*.6+3.14,t*.6+5.3);g.strokeStyle=prism(5,.5,80);g.stroke();
   {const s=(t*.42)%1;g.beginPath();g.arc(0,0,11+s*14,0,TAU);g.strokeStyle=`rgba(255,220,140,${.32*(1-s)})`;g.lineWidth=1.6;g.stroke()}
   g.restore()}
  g.save();g.translate(x,y);g.rotate(-sa*.7);
  g.beginPath();g.arc(0,-14,3.6,Math.PI*1.05,Math.PI*1.95+.01,false);g.strokeStyle=FKO;g.lineWidth=3.4;g.stroke();g.strokeStyle='#e8b04a';g.lineWidth=1.6;g.stroke();
  // cap: a little pagoda roof with a vent
  fa10_path(g,['M',-8,-6,'Q',-7,-11,-3,-12,'L',3,-12,'Q',7,-11,8,-6,'Z']);fkFill(g,fa10_grad(g,-8,0,8,0,[[0,'#6a3a10'],[.45,'#ffd46a'],[1,'#6a3a10']]),1.6);
  g.beginPath();g.rect(-3,-15,6,3.4);fkFill(g,'#c88a28',1.3);
  g.beginPath();g.rect(-9.5,-7,19,3);fkFill(g,'#d8982c',1.5);
  // glass with a warm flame and brass cage bars
  g.beginPath();g.rect(-7,-4,14,16);fkFill(g,fa10_grad(g,0,-4,0,12,[[0,'#fff8dc'],[.45,'#ffdc80'],[1,'#ffa838']]),1.5);
  const fk=.5+.5*Math.sin(t*9)*Math.sin(t*4.3);
  g.fillStyle=fa10_rgrad(g,0,5,0,8,[[0,'rgba(255,255,255,.9)'],[1,'rgba(255,255,255,0)']]);g.fillRect(-7,-4,14,16);
  fa10_path(g,['M',0,10,'C',-3.6,9,-3,4,0,-1-fk*1.6,'C',3,4,3.6,9,0,10,'Z']);g.fillStyle='#fff6d6';g.fill();
  fa10_path(g,['M',0,9.5,'C',-1.8,9,-1.4,6,0,3-fk,'C',1.4,6,1.8,9,0,9.5,'Z']);g.fillStyle='#ffffff';g.fill();
  g.beginPath();g.moveTo(-2.6,-4);g.lineTo(-2.6,12);g.moveTo(2.6,-4);g.lineTo(2.6,12);g.moveTo(-7,4);g.lineTo(7,4);g.strokeStyle='rgba(110,60,10,.6)';g.lineWidth=1.1;g.stroke();
  g.beginPath();g.moveTo(-5.4,-2);g.lineTo(-5.4,9);g.strokeStyle='rgba(255,255,255,.75)';g.lineWidth=1.2;g.stroke();
  g.beginPath();g.rect(-9.5,12,19,3);fkFill(g,'#d8982c',1.5);fa10_path(g,['M',-6,15,'L',6,15,'L',4,19,'L',-4,19,'Z']);fkFill(g,fa10_grad(g,0,15,0,19,[[0,'#c88a28'],[1,'#7a4a14']]),1.4);
  g.restore();
  if(!SIL&&face>.8){const k=(face-.8)/.2;fkGlow(g,x,y+3,18+4*k,'#fff4d0',.4*k);fkSpark(g,x,y+3,6+13*k+gl*3,'#fffaf0',.55+.35*k)}}
 beam(true);
 // spectral motes drifting up and back, prismatic sparkles among them
 if(!SIL){for(let i=0;i<14;i++){const s=((t*.075+i*.0714)%1),x=104-s*214+Math.sin(i*1.7)*10,y=44-((i*29)%84)-s*22+Math.sin(t+i)*4,a=Math.sin(s*Math.PI);
   if(i%3===0)fkSpark(g,x,y,2.6+2.4*fa10_tw(t,i,3)+gl*1.5,prism(i,1,86),a*.95);else{g.fillStyle=`rgba(200,255,242,${a*.75})`;g.beginPath();g.arc(x,y,1.2+(i%2)*.9,0,TAU);g.fill()}}
  if(gl>0)fkGlow(g,8,-4,104,'#c8fff0',.22*gl)}
 g.restore()};

/* update 7 review: when drawn as an undiscovered silhouette (fishDraw renders into FKSIL), the cove fish skip every
   additive light (beams, lamp coronas, auras, glows) and draw translucent fins and ghost parts at full opacity, so the
   journal shows a crisp solid outline. Normal drawing is untouched. */
(()=>{const P=new WeakMap(),wrap=c=>{let p=P.get(c);if(!p){const F=new Map();p=new Proxy(c,{get(t,k){const v=t[k];if(typeof v!=='function')return v;let f=F.get(k);
  if(!f){f=(k==='fill'||k==='fillRect'||k==='stroke'||k==='strokeRect'||k==='drawImage')?function(){if(t.globalCompositeOperation==='lighter')return;return v.apply(t,arguments)}:v.bind(t);F.set(k,f)}return f},
  set(t,k,v){t[k]=(k==='globalAlpha'&&v>0)?1:v;return true}});P.set(c,p)}return p};
 ['sprat','blenny','wreckfin','seahorse','wraith'].forEach(id=>{const f=FISHART[id];if(f)FISHART[id]=(g,t,o)=>{if(typeof FKSIL!=='undefined'&&FKSIL&&g.canvas===FKSIL){g.globalAlpha=1;return f(wrap(g),t,Object.assign({},o,{sil:0}))}return f(g,t,o)}})})();
