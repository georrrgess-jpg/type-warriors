/* ===== 10.6 THE CROOKED CUE: Cathedral Glass and Aurora Opal (97b8, prefix pzb8, after 97b6) =====
   Two premium ball sets for the shared painter of 97b6 (pzb3Reg: a palette and a small per-pixel material).
   - Cathedral Glass (20,000): stained glass. Solids are a leaded mosaic of glass cells (a fixed Voronoi on the sphere, looked up through a
     16x16x16 voxel table built once at load, so a pixel only tests the 6 to 10 seeds that can be its nearest) in the ball's colour: each
     cell has its own shade, tint and glow, brighter in the middle and lit from behind, dark thin lead lines between the cells and a
     bright bevel on one edge of each cell. Stripes: frosted white glass caps (pale cells, soft pewter lead lines) and the coloured
     mosaic band between them, a lead line on the band's border. The 8: black smoked glass in a gold-leaded diamond lattice with a white
     disc in a gold ring. Number discs: cream glass with dark numbers.
   - Aurora Opal (50,000): precious opal. A milky body strongly tinted in the ball's colour (the body colour always wins) with play-of-colour
     flashes: broad patches of green / magenta / orange / blue fire whose hue depends on the ball-local position AND the view normal, so
     they slide as the ball rolls, and in places a harlequin patchwork of small angular fire cells. Stripes: white opal caps with faint
     pastel flashes and the coloured opal band with a fire line on its border. The 8: black opal with small vivid flashes of fire, a white
     disc in a rainbow-tinted ring. Number discs: pale opal with dark numbers.
   The pattern lives in the ball-local normal, so it rolls with the ball. No allocation in mat(); only fast sines / hashes. */
const PZB8={N:0,SX:null,SY:null,SZ:null,UX:null,UY:null,UZ:null,US:null,off:null,lst:null,K:null,T:null,G:null,n:1};
/* ---------- a fixed Voronoi of PZB8.N seeds on the unit sphere, with a voxel lookup of the candidate seeds ---------- */
{const N=120,sx=new Float32Array(N),sy=new Float32Array(N),sz=new Float32Array(N);let s0=20261112;const rnd=()=>{s0=(Math.imul(s0,1664525)+1013904223)|0;return ((s0>>>8)&0xffff)/65536};
 /* Fibonacci sphere with a jitter, then a few repulsion passes so the cells come out even (no slivers, no giants) */
 for(let i=0;i<N;i++){const y=1-2*(i+.5)/N,r=Math.sqrt(1-y*y),a=i*2.399963+rnd()*.5;sx[i]=Math.cos(a)*r;sy[i]=y;sz[i]=Math.sin(a)*r}
 for(let it=0;it<14;it++){for(let i=0;i<N;i++){let fx=0,fy=0,fz=0;for(let j=0;j<N;j++){if(j===i)continue;const dx=sx[i]-sx[j],dy=sy[i]-sy[j],dz=sz[i]-sz[j],d2=dx*dx+dy*dy+dz*dz;if(d2<.16){const w=(.16-d2)/(d2+.02);fx+=dx*w;fy+=dy*w;fz+=dz*w}}
   let x=sx[i]+fx*.03,y=sy[i]+fy*.03,z=sz[i]+fz*.03;const l=1/Math.sqrt(x*x+y*y+z*z);sx[i]=x*l;sy[i]=y*l;sz[i]=z*l}}
 const ux=new Float32Array(N),uy=new Float32Array(N),uz=new Float32Array(N),us=new Float32Array(N);
 for(let i=0;i<N;i++){let a=rnd()*2-1,b=rnd()*2-1,c=rnd()*2-1;const l=1/Math.sqrt(a*a+b*b+c*c+1e-6);a*=l;b*=l;c*=l;ux[i]=a;uy[i]=b;uz[i]=c;us[i]=a*sx[i]+b*sy[i]+c*sz[i]}
 const GN=16,vs=2/GN,r2=vs*.8660254*2,off=new Int32Array(GN*GN*GN+1),tmp=[];
 for(let ix=0;ix<GN;ix++)for(let iy=0;iy<GN;iy++)for(let iz=0;iz<GN;iz++){const cx=-1+(ix+.5)*vs,cy=-1+(iy+.5)*vs,cz=-1+(iz+.5)*vs,g=(ix*GN+iy)*GN+iz;off[g]=tmp.length;
  if(cx*cx+cy*cy+cz*cz>1.5)continue;
  let d1=9,d2=9;const ds=new Array(N);for(let i=0;i<N;i++){const dx=cx-sx[i],dy=cy-sy[i],dz=cz-sz[i],d=Math.sqrt(dx*dx+dy*dy+dz*dz);ds[i]=d;if(d<d1){d2=d1;d1=d}else if(d<d2)d2=d}
  for(let i=0;i<N;i++)if(ds[i]<=d2+r2)tmp.push(i)}
 off[GN*GN*GN]=tmp.length;
 Object.assign(PZB8,{N,SX:sx,SY:sy,SZ:sz,UX:ux,UY:uy,UZ:uz,US:us,off,lst:Int16Array.from(tmp),K:new Float32Array(N),T:new Float32Array(N),G:new Float32Array(N)})}
/* per-ball cell values (shade, tint, glow) from the integer hash, so every ball has its own mosaic colouring */
const pzb8Cells=(n,spread)=>{const P=PZB8;P.n=n;for(let i=0;i<P.N;i++){const h=pzb2Hash(i,n*7+3,11),h2=pzb2Hash(i,n*5+1,29),h3=pzb2Hash(i,n*3+2,53);P.K[i]=1+(h-.5)*spread;P.T[i]=h2*2-1;P.G[i]=h3}};
const pzb8Sm=(a,b,x)=>{x=(x-a)/(b-a);x=x<0?0:x>1?1:x;return x*x*(3-2*x)};

/* ---------- Cathedral Glass ---------- */
function pzb8Cath(o){const P=PZB8,lx=o.lx,ly=o.ly,lz=o.lz,C=o.C,band=o.band,ab=o.ab;
 let ix=((lx+1)*8)|0,iy=((ly+1)*8)|0,iz=((lz+1)*8)|0;ix=ix>15?15:ix<0?0:ix;iy=iy>15?15:iy<0?0:iy;iz=iz>15?15:iz<0?0:iz;
 const g=(ix*16+iy)*16+iz,a=P.off[g],b=P.off[g+1],SX=P.SX,SY=P.SY,SZ=P.SZ;let d1=-9,d2=-9,i1=0;
 for(let k=a;k<b;k++){const s=P.lst[k],d=lx*SX[s]+ly*SY[s]+lz*SZ[s];if(d>d1){d2=d1;d1=d;i1=s}else if(d>d2)d2=d}
 const e=(d1-d2)*2,kc=P.K[i1],tn=P.T[i1],gl=P.G[i1];
 if(o.is8){/* black smoked glass in a gold-leaded diamond lattice */
  const u1=(lx+ly)*3.3,u2=(lx-ly)*3.3,f1=u1-Math.floor(u1+.5),f2=u2-Math.floor(u2+.5),af=Math.min(f1<0?-f1:f1,f2<0?-f2:f2),
   ln=1-pzb8Sm(.05,.105,af),h=pzb2Hash(Math.floor(u1+.5)+40,Math.floor(u2+.5)+40,5),sm=.5+.5*pzb2Sin(lx*3+ly*2.2+lz*3.4+h*6);
  o.r=C[0];o.g=C[1];o.b=C[2];
  /* smoke inside each pane: a deep violet-grey that stays dark; the lead is gold with a lighter edge on one side */
  const sk=(7+9*h)*(.6+.4*sm);o.er=sk*.9;o.eg=sk*.8;o.eb=sk*1.35;
  const hi=ln*(.75+.25*pzb2Sin((lx*2-ly*1.3)*5+lz*3));o.er+=255*hi*.92;o.eg+=196*hi*.92;o.eb+=74*hi*.92;o.r+=ln*30;o.g+=ln*22;o.b+=ln*4;return}
 /* the glass of one cell: a shade and a tint of the ball's colour, lit from behind and brighter in the middle */
 const q=lx*P.UX[i1]+ly*P.UY[i1]+lz*P.UZ[i1]-P.US[i1],cen=1-(1-d1)*24,ce=cen<0?0:cen,gr=1+q*1.5,
  cr=C[0]*kc*(1+.2*tn),cg=C[1]*kc*(1+.03*tn),cb=C[2]*kc*(1-.2*tn);
 /* lead: thin and dark, tinted with the ball's colour; the band's border on a stripe gets one too */
 let ld=1-pzb8Sm(.007,.02,e);if(o.stripe){const ed=(o.edge-.5)*3.2;const el=ed<0?0:ed>1?1:ed;if(el>ld)ld=el}
 const bev=(1-pzb8Sm(.02,.085,e))*pzb8Sm(.0,.12,q)*(1-ld);
 let r=0,g2=0,b2=0,er=0,eg=0,eb=0;
 if(band>.01){const gk=gr*(.8+.35*ce)*(.84+.3*gl*gl),em=.4+.3*ce+.18*gl;
  r=cr*.5*gr;g2=cg*.5*gr;b2=cb*.5*gr;er=cr*em*(.7+.3*gk);eg=cg*em*(.7+.3*gk);eb=cb*em*(.7+.3*gk);
  /* a hot cell now and then, and the bevel highlight */
  const hot=gl>.86?(gl-.86)*5:0;er+=(255-er)*hot*.35+255*bev*.34;eg+=(255-eg)*hot*.3+255*bev*.32;eb+=(255-eb)*hot*.3+255*bev*.3;
  r*=band;g2*=band;b2*=band;er*=band;eg*=band;eb*=band}
 if(ab>.01){/* frosted white glass: pale panes, soft pewter lead, a ripple of frost */
  const CP=o.CP,fr=.5+.5*pzb2Sin(lx*17+ly*9+pzb2Sin(lz*13+ly*7)*2),pk=.955+.05*kc-.02,fl=1-pzb8Sm(.012,.04,e),ps=.97+.03*ce,ti=.12;
  const cw=pk*(.93+.07*fr),tr=C[0]*ti,tg=C[1]*ti,tb=C[2]*ti,rf=1-ti;
  const pr=(CP[0]*rf+tr)*cw*(1-fl*.1),pg=(CP[1]*rf+tg)*cw*(1-fl*.1),pb=(CP[2]*rf+tb)*cw*(1-fl*.08);
  r+=pr*ab*ps;g2+=pg*ab*ps;b2+=pb*ab*ps;er+=ab*(CP[0]*(.1+.18*ce)*(1-fl*.5)+255*bev*.1);eg+=ab*(CP[1]*(.1+.18*ce)*(1-fl*.5)+255*bev*.1);eb+=ab*(CP[2]*(.1+.18*ce)*(1-fl*.5)+255*bev*.1)}
 /* lead lines over the band only (the frosted caps carry their own soft ones) */
 const lk=ld*band;r=r*(1-lk)+(C[0]*.14+4)*lk;g2=g2*(1-lk)+(C[1]*.14+3)*lk;b2=b2*(1-lk)+(C[2]*.16+6)*lk;er*=1-lk*.95;eg*=1-lk*.95;eb*=1-lk*.95;
 o.r=r;o.g=g2;o.b=b2;o.er=er;o.eg=eg;o.eb=eb}

/* ---------- Aurora Opal ---------- */
function pzb8Opal(o){const lx=o.lx,ly=o.ly,lz=o.lz,wx=o.wx,wy=o.wy,wz=o.wz,C=o.C,band=o.band,ab=o.ab;
 /* broad patches of fire (slide with the roll through lx,ly,lz and with the view through wx,wy) and a patchwork of angular cells */
 const nb=pzb2Sin(lx*3.3+ly*2.1+pzb2Sin(lz*3.9+ly*2.6)*1.5),pm=.5+.5*pzb2Sin(lx*2.6-ly*3.4+lz*2.2+nb*1.9),mk=pzb8Sm(.28,.8,pm);
 if(o.is8){/* black opal: small vivid soft flashes of fire */
  const u=lx*7+ly*1.9,v=ly*7-lx*1.9,w=lz*7,fu=u-Math.floor(u)-.5,fv=v-Math.floor(v)-.5,fw=w-Math.floor(w)-.5,h=pzb2Hash(Math.floor(u),Math.floor(v),Math.floor(w)),
   dd=1-(fu*fu+fv*fv+fw*fw)*3.3,sp=dd<0?0:dd,al=sp*sp*pzb8Sm(.38,.75,h)*(.5+.5*mk)+.2*mk*mk,
   ph=nb*3+(lx*2.4+ly*1.8+lz*2.1)*2.2+wx*4.2+wy*3.1+h*4;
  o.r=C[0];o.g=C[1];o.b=C[2];const fr=.5+.5*pzb2Sin(ph),fg=.5+.5*pzb2Sin(ph+2.09),fb=.5+.5*pzb2Sin(ph+4.19),k=al*225;
  o.er=fr*fr*k+5;o.eg=fg*fg*k+4;o.eb=fb*fb*k+8;
  /* the ring of the 8's disc is rainbow (the disc itself is painted by the shared painter) */
  const q=lx*lx+ly*ly,az=lz<0?-lz:lz;if(az>.8&&q>.2&&q<.3){const dq=q>.255?q-.255:.255-q,rr=1-pzb8Sm(.0,.03,dq),hp=Math.atan2(ly,lx)*2+lz*3;o.er+=rr*(.35+.65*(.5+.5*pzb2Sin(hp)))*255;o.eg+=rr*(.35+.65*(.5+.5*pzb2Sin(hp+2.09)))*255;o.eb+=rr*(.35+.65*(.5+.5*pzb2Sin(hp+4.19)))*255}
  return}
 const gx=Math.floor(lx*4.4+ly*1.2),gy=Math.floor(ly*4.4-lx*1.2),gz=Math.floor(lz*4.4),h=pzb2Hash(gx,gy,gz),
  hq=pzb8Sm(.3,.62,.5+.5*pzb2Sin(lz*3.1-lx*2.2+ly*1.3+nb)),
  ph=nb*2.4+(lx*2.3+ly*1.6+lz*1.9)*1.6+wx*3.4+wy*2.5+wz*1.4+hq*(h-.5)*8;
 const fr=.5+.5*pzb2Sin(ph),fg=.5+.5*pzb2Sin(ph+2.09),fb=.5+.5*pzb2Sin(ph+4.19),
  fi=Math.max(fr,fg,fb),fn=1/(fi+.01),sr=fr*fn,sg=fg*fn,sb=fb*fn,
  m=mk*(.72+.28*h)+hq*(.16+.3*h)*(1-mk*.5);
 /* the milky body: tinted strongly, a little paler in the middle where the light scatters, deeper at the edge */
 const wz2=wz*wz,mi=.02+.06*wz2;
 let r=0,g=0,b=0,er=0,eg=0,eb=0;
 if(band>.01){const fa=m*.42,dk=.9-.1*wz2,dr=C[0]*dk,dg=C[1]*dk,db=C[2]*dk;/* the fire tints the colour (at most about half) and the body keeps the rest */
  r=dr*.72;g=dg*.72;b=db*.72;
  er=dr*.24+235*mi+(sr*225-dr*.24)*fa;eg=dg*.24+232*mi+(sg*225-dg*.24)*fa;eb=db*.24+250*mi+(sb*225-db*.24)*fa;
  r*=band;g*=band;b*=band;er*=band;eg*=band;eb*=band}
 if(ab>.01){/* white opal caps: milky with faint pastel flashes */
  const CP=o.CP,pa=m*.15+.02,sh=.94+.06*wz2;
  r+=CP[0]*.72*sh*ab;g+=CP[1]*.72*sh*ab;b+=CP[2]*.72*sh*ab;er+=(CP[0]*.18+(sr*255-CP[0]*.18)*pa)*ab;eg+=(CP[1]*.18+(sg*255-CP[1]*.18)*pa)*ab;eb+=(CP[2]*.18+(sb*255-CP[2]*.18)*pa)*ab}
 /* a bright line of fire on a stripe's band border */
 if(o.stripe&&o.edge>.4){const ed=(o.edge-.4)*1.67,e2=ed*ed*.55;er+=sr*210*e2;eg+=sg*210*e2;eb+=sb*210*e2}
 o.r=r;o.g=g;o.b=b;o.er=er;o.eg=eg;o.eb=eb}

pzb3Reg({id:'cathedral',n:'Cathedral Glass',price:20000,tag:'Light through a cathedral window.',
 pal:{col:{1:[250,194,52],2:[58,122,236],3:[236,64,92],4:[150,84,226],5:[250,128,40],6:[34,176,128],7:[178,44,76],8:[16,14,22]},
  white:[244,244,250],cap:[236,240,248],disc:[250,240,212],num:[44,24,16],disc8:[250,250,255],num8:[22,14,26],ring8:[255,196,60],spec:1.2,win:.12,rim:.34,
  prep(P,pal,n){pzb8Cells(n,.62)}},
 mat:pzb8Cath});
pzb3Reg({id:'opal',n:'Aurora Opal',price:50000,tag:'Every turn flashes a new colour.',
 pal:{col:{1:[248,196,52],2:[60,126,240],3:[238,66,104],4:[156,88,230],5:[250,134,44],6:[36,180,132],7:[186,48,84],8:[11,9,16]},
  white:[246,244,250],cap:[242,240,246],disc:[246,242,250],num:[40,26,64],disc8:[252,250,255],num8:[24,14,40],ring8:[70,60,90],spec:.95,win:.08,rim:.3},
 mat:pzb8Opal});
