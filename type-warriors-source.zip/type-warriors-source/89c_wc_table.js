/* ===== WILDCARD: the table — seats, hand, piles, the turn driver and every card animation =====
   One renderer serves Solo, Pass & play and Wi-Fi rooms. The host (or Solo) owns WX.G and runs bots; a Wi-Fi guest
   only receives the host's state and sends its own moves. New engine events are replayed one by one as animations,
   then the table is rebuilt from the final state. Seat kinds: you, local (pass & play), bot, net (Wi-Fi guest). */
const WX={G:null,me:0,mode:'solo',host:true,tbl:'e',stake:0,fee:0,seen:0,busy:false,tok:0,tm:[],sort:0,sel:-1,vc:[],hint:-2,chat:[],cfg:null,ended:false};
const wcSnd=(f,d,t,v,dl)=>{try{if(dl)setTimeout(()=>beep(f,d,t,v),dl);else beep(f,d,t,v)}catch(e){}};
const wcRM=()=>{try{return matchMedia('(prefers-reduced-motion: reduce)').matches||document.body.classList.contains('pf-low')}catch(e){return false}};
const wcSleep=ms=>new Promise(r=>setTimeout(r,wcRM()?Math.min(ms,60):ms));
function wcClear(){for(const t of WX.tm)clearTimeout(t);WX.tm=[]}
function wcLater(fn,ms){const tok=WX.tok,t=setTimeout(()=>{if(tok===WX.tok&&$('wct'))fn()},ms);WX.tm.push(t);return t}
/* portraits: bosses from the bestiary, heroes from the armory */
function wcPortrait(cv,av){const g=cv.getContext('2d'),w=cv.width,h=cv.height;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,w,h);
 try{if(av&&av.t==='mon'&&MON[av.id]){const M=MON[av.id],s=(h*1.18)/M.th;g.save();g.translate(w/2-(M.cx||0)*s,h*1.12);g.scale(s,s);M.d(g,1.2,{lg:0});g.restore()}
  else{const a=av||{};g.save();g.translate(w*.45,h*1.04);const s=w/60;g.scale(s,s);g.translate(0,58);drawHero(g,{arm:AR[a.arm]?a.arm:P.armor,wp:null,col:a.col!=null?a.col:P.col,t:1.2});g.restore()}}catch(e){}}
/* the real drawn size of a monster (glow and weapons included), measured once, so big ones are never cut off */
const WCBOX={};
function wcBox(id){if(WCBOX[id])return WCBOX[id];const M=MON[id];let B={w:M.tw||M.th*.9,h:M.th,cx:M.cx||0,b:0};
 try{const c=document.createElement('canvas');c.width=c.height=640;const g=c.getContext('2d');g.translate(320,600);M.d(g,1.2,{lg:0});
  const d=g.getImageData(0,0,640,640).data;let x0=640,x1=-1,y0=640,y1=-1;for(let y=0;y<640;y+=2)for(let x=0;x<640;x+=2)if(d[(y*640+x)*4+3]>10){if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y}
  if(x1>x0&&y1>y0)B={w:x1-x0+2,h:y1-y0+2,cx:(x0+x1)/2-320,b:y1+2-600}}catch(e){}
 return WCBOX[id]=B}
function wcFigure(cv,av){const g=cv.getContext('2d'),w=cv.width,h=cv.height;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,w,h);
 try{if(av&&av.t==='mon'&&MON[av.id]){const M=MON[av.id],B=wcBox(av.id),s=Math.min((h*.94)/B.h,(w*.94)/B.w,2.4);g.save();g.translate(w/2-B.cx*s,h*.98-B.b*s);g.scale(s,s);M.d(g,1.2,{lg:0});g.restore()}
  else{const a=av||{};g.save();g.translate(w/2,h*.97);const s=h/190;g.scale(s,s);drawHero(g,{arm:AR[a.arm]?a.arm:P.armor,wp:WP[a.wp]?a.wp:P.weapon,col:a.col!=null?a.col:P.col,t:1.2});g.restore()}}catch(e){}}
const wcMyAv=()=>({t:'hero',arm:P.armor,wp:P.weapon,col:P.col});
/* where each seat sits, counted from the player looking at the table */
const WCPOS={2:['b','t'],3:['b','l','r'],4:['b','l','t','r']};
const wcPos=(i)=>{const G=WX.G,n=G.P.length;return WCPOS[n][(i-WX.me+n)%n]};
const wcRot=id=>((id*37)%23)-11;
function wcDisp(){const h=WX.G.P[WX.me].hand.slice();if(WX.sort===1)h.sort((a,b)=>(WCS.indexOf(a.s)+1||9)-(WCS.indexOf(b.s)+1||9)||wcPts(a)-wcPts(b));else if(WX.sort===2)h.sort((a,b)=>wcPts(a)-wcPts(b)||(WCS.indexOf(a.s)+1||9)-(WCS.indexOf(b.s)+1||9));return h}
const wcMine=()=>WX.G&&WX.G.turn===WX.me&&WX.G.phase!=='over'&&(WX.G.P[WX.me].kind==='you'||WX.G.P[WX.me].kind==='local'||WX.mode==='net');

/* ---------- the screen ---------- */
function wcTable(){const G=WX.G,felt=WX.mode==='solo'?'green':'blue';
 const top=WX.mode==='solo'?`<span class="wcpill"><i class="wcpd" style="background:${WCC.s}"></i>${WCT[WX.tbl].lab} table</span>${WX.stake?`<span class="wcpill">Pot <b>${cmn(WX.stake*G.P.length)}</b></span>`:'<span class="wcpill">Friendly game</span>'}`
  :`<span class="wcpill">Room <b>${esc(WX.room||'')}</b></span>${WX.stake?`<span class="wcpill">Pot <b>${cmn(WX.stake*G.P.length)}</b></span>`:''}<span class="wcpill ok" id="wcnet"><i class="wcpd"></i>${WX.mode==='pp'?'Pass &amp; play':'Connected'}</span>`;
 show(`<div class="wct ${felt}" id="wct"><div class="wcbg"></div><div class="wcfelt"><i></i></div>
 <div class="wctop">${top}</div><div class="wcttl"><b>WILDCARD</b></div>
 <button class="wcleave" id="wcleave" aria-label="Leave the table"><svg viewBox="0 0 24 24" width="18" height="18"><path d="M15 5l-7 7 7 7" stroke="currentColor" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg><span>Leave</span></button>
 <div class="wcring" id="wcring" aria-hidden="true"><svg viewBox="-120 -120 240 240"><g class="wcrg"><path d="M-96 -30A100 100 0 0 1 60-80" /><path d="M96 30A100 100 0 0 1 -60 80"/><path class="ah" d="M56-90L70-79 52-72Z"/><path class="ah" d="M-56 90L-70 79-52 72Z"/></g></svg></div>
 <div id="wcseats"></div>
 <div class="wcpiles"><button class="wcdeck" id="wcdeck" aria-label="Draw a card">${wcCardEl(null,'d3')}${wcCardEl(null,'d2')}${wcCardEl(null,'d1')}<span class="wcdn" id="wcdn"></span></button><div class="wcglow" id="wcglow"></div><div class="wcdisc" id="wcdisc"></div></div>
 <div class="wcstack" id="wcstack"></div>
 <div class="wcstat" id="wcstat" aria-live="polite"></div>
 <div class="wchand" id="wchand" role="listbox" aria-label="Your hand"></div>
 <div class="wcdrawn" id="wcdrawn"></div>
 <div class="wctools"><button class="wctb" id="wchint"><svg viewBox="0 0 24 24"><path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.6 10.8c.6.5 1 1.2 1 2V16h5.2v-.2c0-.8.4-1.5 1-2A6 6 0 0 0 12 3z" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>Hint</button><button class="wctb" id="wcsort"><svg viewBox="0 0 24 24"><path d="M7 4v16M3.5 16.5L7 20l3.5-3.5M17 20V4M13.5 7.5L17 4l3.5 3.5" stroke="currentColor" stroke-width="2.2" fill="none" stroke-linecap="round"/></svg><span>Sort</span></button></div>
 ${WX.mode==='net'||WX.mode==='pp'?`<div class="wcemo" id="wcemo">${['😂','😭','🔥','👏','😈','GG','Nice!','Oops'].map(x=>`<button data-emo="${x}">${x}</button>`).join('')}</div><div class="wcchat" id="wcchat"><b>Table chat</b><div id="wcchl"></div></div>`:''}
 <button class="wcone" id="wcone" aria-label="Call WILD"><span>WILD!</span></button>
 <div class="wcfx" id="wcfx"></div><div class="wcmod" id="wcmod" hidden></div></div>`,'casbg wcx');
 S.back=wcLeaveAsk;$('wcleave').onclick=wcLeaveAsk;
 $('wcdeck').onclick=()=>{if(!wcMine()||WX.busy)return;const G=WX.G;if(G.phase==='drawn')return;wcSend({t:'draw'})};
 $('wcone').onclick=()=>wcSend({t:'call'});
 $('wchint').onclick=wcHint;$('wcsort').onclick=()=>{WX.sort=(WX.sort+1)%3;wcSnd(600,.04,'triangle',.25);wcRenderHand(true);const b=$('wcsort');if(b)b.querySelector('span').textContent=['Sort','By element','By value'][WX.sort]};
 const em=$('wcemo');if(em)em.querySelectorAll('[data-emo]').forEach(b=>b.onclick=()=>wcEmote(b.dataset.emo));
 WX.vc=G.P.map(p=>p.hand.length);wcRender()}
function wcSeatHTML(i){const G=WX.G,p=G.P[i],pos=wcPos(i),n=p.hand.length,act=G.turn===i&&G.phase!=='over';
 const fan=Math.min(n,9),backs=Array.from({length:fan},(_,k)=>`<i class="wcmbk" style="--k:${k-(fan-1)/2}">${wcBack(wcBackSel())}</i>`).join('');
 return `<div class="wcseat p-${pos}${act?' on':''}${G.one&&G.one.p===i&&i!==WX.me?' catch':''}" data-seat="${i}" style="--tm:${WX.cfg&&WX.cfg.timer||0}s">
  <button class="wcav" data-catch="${i}" aria-label="${esc(p.name)}, ${n} cards"><canvas width="120" height="120"></canvas><svg class="wctr" viewBox="0 0 100 100"><circle cx="50" cy="50" r="47"/></svg></button>
  <div class="wcnm"><b>${esc(p.name)}</b><span class="wcn">${n}</span>${p.kind==='bot'?`<small class="d-${p.diff}">${WCT[p.diff]?WCT[p.diff].lab:''}</small>`:p.kind==='net'?'<small class="d-net">Wi-Fi</small>':p.kind==='local'?'<small class="d-pp">Player</small>':''}</div>
  ${n===1?'<span class="wcw1">WILD!</span>':''}
  ${pos==='b'?'':`<div class="wcbacks">${backs}</div>`}<div class="wcbub" id="wcbub${i}"></div></div>`}
function wcRender(){const G=WX.G;if(!G||!$('wct'))return;WX.vc=G.P.map(p=>p.hand.length);
 const st=$('wcseats');st.innerHTML=G.P.map((p,i)=>i===WX.me?'':wcSeatHTML(i)).join('')+wcSeatHTML(WX.me).replace('class="wcseat p-b','class="wcseat me p-b');
 st.querySelectorAll('.wcseat').forEach(s=>{const i=+s.dataset.seat,c=s.querySelector('canvas');wcPortrait(c,G.P[i].av)});
 st.querySelectorAll('[data-catch]').forEach(b=>b.onclick=()=>{const t=+b.dataset.catch;if(WX.G.one&&WX.G.one.p===t&&t!==WX.me)wcSend({t:'catch',p:t})});
 const d=$('wcdisc');d.innerHTML=G.disc.slice(-4).map((c,k,a)=>wcCardEl(c,k===a.length-1?'top':'',`style="--r:${wcRot(c.id)}deg"`)).join('');
 $('wcglow').style.setProperty('--gc',WCC[G.color]);$('wcglow').dataset.c=G.color;
 $('wcdn').textContent=G.draw.length;$('wcring').classList.toggle('rev',G.dir<0);
 wcStack();wcStatus();wcRenderHand();wcButtons()}
function wcStack(){const e=$('wcstack'),G=WX.G;if(!e)return;e.className='wcstack'+(G.stack>0?' on':'');e.innerHTML=G.stack>0?`<b>+${G.stack}</b><small>stack</small>`:''}
function wcStatus(t){const e=$('wcstat'),G=WX.G;if(!e)return;if(t){e.innerHTML=t;return}
 if(G.phase==='over'){e.innerHTML='';return}const p=G.P[G.turn],col=`<i class="wcpd" style="background:${WCC[G.color]}"></i>${WCN[G.color]}`;
 if(G.turn===WX.me&&wcMine()){const L=wcLegal(G,WX.me);e.innerHTML=G.phase==='drawn'?'You drew a card you can play. Play it or keep it.':G.stack>0?`<b class="hot">+${G.stack} incoming!</b> Stack a +2 or +4, or take the cards.`:L.length?`<b>Your turn</b> · match ${col} or a <b>${wcCorner(wcTop(G))}</b>`:`<b>Your turn</b> · no match, draw from the deck`}
 else e.innerHTML=`<b>${esc(p.name)}</b> is choosing…${G.stack>0?` <span class="hot">+${G.stack} stack</span>`:''} · ${col}`}
function wcRenderHand(resort){const G=WX.G,h=$('wchand');if(!h)return;const me=G.P[WX.me],cards=wcDisp(),n=cards.length,mine=wcMine();
 const L=mine?new Set(wcLegal(G,WX.me).map(i=>me.hand[i].id)):new Set(),hidden=WX.cover;
 const w=112,maxW=n>12?1000:880,step=n>1?Math.min(78,(maxW-w)/(n-1)):0,tot=w+(n-1)*step;
 h.innerHTML=cards.map((c,i)=>{const m=(n-1)/2,x=800-tot/2+i*step,r=n>1?(i-m)*Math.min(3.2,26/n):0,y=Math.pow(i-m,2)*Math.min(2.2,30/(n*n)+.5);
  return `<button class="wcc wchc${L.has(c.id)?' ok':''}${mine&&!L.has(c.id)?' no':''}${G.pend===c.id&&G.turn===WX.me?' pend':''}${WX.fresh&&WX.fresh.has(c.id)?' fresh':''}" data-id="${c.id}" role="option" aria-label="${wcName(c)}${L.has(c.id)?', playable':''}" style="--x:${x}px;--y:${y}px;--r:${r}deg;--z:${i};--d:${i*.025}s" tabindex="${mine?0:-1}">${hidden?wcBack(wcBackSel()):wcSVG(c)}</button>`}).join('');
 WX.fresh=null;if(resort)h.classList.add('resort'),setTimeout(()=>h&&h.classList.remove('resort'),400);
 h.querySelectorAll('.wchc').forEach(b=>{b.onclick=()=>wcTapCard(+b.dataset.id);b.onkeydown=e=>{const all=[...h.querySelectorAll('.wchc')],i=all.indexOf(b);if(e.key==='ArrowRight'&&all[i+1]){e.preventDefault();all[i+1].focus()}else if(e.key==='ArrowLeft'&&all[i-1]){e.preventDefault();all[i-1].focus()}}});
 const dr=$('wcdrawn');if(dr){if(G.phase==='drawn'&&G.turn===WX.me&&mine){dr.innerHTML=`<button class="wcbtn gold" id="wcplayd">Play it</button><button class="wcbtn" id="wckeep">Keep</button>`;dr.classList.add('on');
  $('wcplayd').onclick=()=>wcTapCard(G.pend);$('wckeep').onclick=()=>wcSend({t:'pass'})}else{dr.innerHTML='';dr.classList.remove('on')}}}
function wcButtons(){const G=WX.G,me=G.P[WX.me],o=$('wcone');if(!o)return;const mine=wcMine();
 const can=(mine&&me.hand.length===2&&!me.called&&wcLegal(G,WX.me).length)||(G.one&&G.one.p===WX.me);
 o.classList.toggle('can',!!can);o.classList.toggle('urgent',!!(G.one&&G.one.p===WX.me));o.disabled=!can;
 const dk=$('wcdeck');dk.classList.toggle('can',mine&&G.phase==='play');dk.classList.toggle('need',mine&&G.phase==='play'&&!wcLegal(G,WX.me).length);
 const hb=$('wchint');if(hb)hb.disabled=!mine}
function wcTapCard(id){const G=WX.G;if(!wcMine()||WX.busy)return;const me=G.P[WX.me],c=me.hand.find(x=>x.id===id);if(!c)return;
 if(!wcCan(G,c)||(G.phase==='drawn'&&G.pend!==id)){const el=document.querySelector(`.wchc[data-id="${id}"]`);if(el){el.classList.remove('nope');void el.offsetWidth;el.classList.add('nope')}wcSnd(180,.08,'sawtooth',.2);return}
 if(c.s==='w')return wcPickCol(col=>wcSend({t:'play',id,col}));wcSend({t:'play',id})}
/* the element picker for Wild Rune and +4 Hex */
function wcPickCol(cb){const m=$('wcmod');if(!m)return;const me=WX.G.P[WX.me],cnt={};for(const c of me.hand)cnt[c.s]=(cnt[c.s]||0)+1;
 m.hidden=false;m.className='wcmod wcpk';m.innerHTML=`<div class="wcpkb"><b>Choose an element</b><div class="wcpkr">${WCS.map((s,i)=>`<button data-col="${s}" style="--c:${WCC[s]};--i:${i}">${wcOrb(s,64)}<span>${WCN[s]}</span><small>${cnt[s]||0} in hand</small></button>`).join('')}</div><button class="wcpkx" id="wcpkx">Cancel</button></div>`;
 const close=()=>{m.hidden=true;m.innerHTML=''};m.querySelectorAll('[data-col]').forEach(b=>b.onclick=()=>{close();cb(b.dataset.col)});$('wcpkx').onclick=close;
 setTimeout(()=>{const b=m.querySelector('[data-col]');if(b)b.focus()},40);wcSnd(700,.05,'triangle',.25)}
function wcHint(){const G=WX.G;if(!wcMine())return;const me=G.P[WX.me],sv=me.diff;me.diff='m';const a=wcBot(G,WX.me);me.diff=sv;
 document.querySelectorAll('.wchint').forEach(x=>x.classList.remove('wchint'));
 if(a.t==='play'||a.i!=null){const c=me.hand[a.i],el=c&&document.querySelector(`.wchc[data-id="${c.id}"]`);if(el)el.classList.add('wchint')}else{const d=$('wcdeck');if(d)d.classList.add('wchint')}
 wcSnd(880,.05,'triangle',.2)}

/* ---------- moves: Solo and the host apply them; a Wi-Fi guest sends them to the host ---------- */
function wcSend(a){if(WX.busy&&a.t!=='call'&&a.t!=='catch')return;const G=WX.G;if(!G||G.phase==='over')return;
 if(WX.mode==='net'&&!WX.host){wcNetSend({t:'act',a});if(a.t==='play'){const el=document.querySelector(`.wchc[data-id="${a.id}"]`);if(el)el.classList.add('sent')}return}
 wcApply(WX.me,a)}
function wcApply(pi,a){const G=WX.G;if(!G||G.phase==='over')return false;const ok=wcDo(G,pi,a);if(!ok)return false;
 if(a.t==='call')wcSnd(880,.08,'square',.3);wcSync();wcPump();return true}
/* replay new events, then rebuild the table and decide who moves next */
async function wcPump(){if(WX.busy||!WX.G)return;WX.busy=true;const tok=WX.tok;
 try{while(WX.G){const e=WX.G.ev.find(x=>x.n>WX.seen);if(!e)break;WX.seen=e.n;await wcAnim(e);if(tok!==WX.tok||!$('wct'))return}}catch(err){console.error(err)}
 WX.busy=false;if(tok!==WX.tok||!$('wct'))return;wcRender();wcStep()}
function wcStep(){const G=WX.G;if(!G||!$('wct'))return;wcClear();
 if(G.phase==='over'){if(!WX.ended){WX.ended=true;wcLater(()=>wcEnd(),1500)}return}
 if(!WX.host)return;
 const cur=G.P[G.turn],win=G.one&&G.one.p!=null;
 /* a forgotten WILD! call: bots may catch it; the window stays open for a moment */
 if(win){const t=G.one.p,seq=G.one.n;G.P.forEach((p,i)=>{if(i===t||p.kind!=='bot')return;const B=WCB[p.diff]||WCB.m;if(G.r()<B.catch){const d=B.react[0]+G.r()*(B.react[1]-B.react[0]);wcLater(()=>{if(WX.G.one&&WX.G.one.n===seq&&!WX.busy)wcApply(i,{t:'catch',p:t})},d)}});
  wcLater(()=>{if(WX.G.one&&WX.G.one.n===seq){WX.G.one=null;wcSync();wcRender();wcStep()}},3200);
  if(G.P[t].kind==='bot'||t===WX.me)wcBubble(t===WX.me?WX.me:t,t===WX.me?'Call WILD!':'',0)}
 if(cur.kind==='bot'){const B=cur.diff==='h'?[650,1100]:cur.diff==='e'?[1000,1700]:[800,1400],d=B[0]+G.r()*(B[1]-B[0])+(win?2600:0);
  wcLater(()=>wcBotMove(G.turn),d)}
 else if(WX.mode==='pp'&&cur.kind!=='bot'&&G.turn!==WX.me)wcCurtain(G.turn);
 else if(WX.cfg&&WX.cfg.timer&&(cur.kind==='you'||cur.kind==='local'||cur.kind==='net')){const seat=G.turn,turns=G.turns;wcLater(()=>{const g=WX.G;if(g.turn===seat&&g.turns===turns&&g.phase!=='over'){wcApply(seat,g.phase==='drawn'?{t:'pass'}:{t:'draw'});if(seat===WX.me)wcToast('Time ran out, so you drew a card.')}},WX.cfg.timer*1000)}
 if(G.one&&G.one.p!==WX.me&&G.P[G.one.p].kind==='bot')wcTip(`<b>${esc(G.P[G.one.p].name)}</b> forgot to call WILD! Tap them to catch it!`)}
function wcBotMove(pi){const G=WX.G;if(!G||G.turn!==pi||G.phase==='over'||WX.busy)return;const p=G.P[pi],a=wcBot(G,pi);
 if(a.t==='play'&&p.hand.length===2&&G.r()>=(WCB[p.diff]||WCB.m).forget)wcDo(G,pi,{t:'call'});
 if(a.t==='play')a.id=p.hand[a.i].id;wcApply(pi,a);wcTaunt(pi,a)}
/* ---------- animations ---------- */
function wcLocal(el){const st=$('wct');if(!st||!el)return null;const R=st.getBoundingClientRect(),k=R.width/1600,r=el.getBoundingClientRect();return{x:(r.left-R.left)/k,y:(r.top-R.top)/k,w:r.width/k,h:r.height/k}}
function wcFly(face,from,to,o){o=o||{};const fx=$('wcfx');if(!fx||!from||!to)return wcSleep(0);const d=document.createElement('div');d.className='wcfly'+(o.flip?' flip':'');
 d.style.width=to.w+'px';d.style.height=to.h+'px';d.innerHTML=o.flip?`<div class="fi"><div class="ff">${face}</div><div class="fb">${wcBack(wcBackSel())}</div></div>`:face;fx.appendChild(d);
 const sx=from.w/to.w,dur=wcRM()?60:(o.dur||360),mid=o.arc==null?-40:o.arc;
 const k=[{transform:`translate(${from.x}px,${from.y}px) rotate(${o.r0||0}deg) scale(${sx})`},{transform:`translate(${(from.x+to.x)/2}px,${(from.y+to.y)/2+mid}px) rotate(${((o.r0||0)+(o.r1||0))/2}deg) scale(${(sx+1)/2*1.08})`,offset:.5},{transform:`translate(${to.x}px,${to.y}px) rotate(${o.r1||0}deg) scale(1)`}];
 const an=d.animate(k,{duration:dur,easing:'cubic-bezier(.3,.7,.3,1)',fill:'forwards'});
 if(o.flip){const fi=d.querySelector('.fi');fi.animate([{transform:'rotateY(180deg)'},{transform:'rotateY(0deg)'}],{duration:dur,easing:'ease-in-out',fill:'forwards'})}
 return an.finished.then(()=>{if(o.keep)return d;d.remove()}).catch(()=>{d.remove()})}
function wcSeatEl(i){return document.querySelector(`.wcseat[data-seat="${i}"]`)}
function wcSeatSpot(i){const s=wcSeatEl(i);if(!s)return null;const b=s.querySelector(i===WX.me?'.wcav':'.wcbacks')||s.querySelector('.wcav');const r=wcLocal(b);return r&&{x:r.x+r.w/2-28,y:r.y+r.h/2-41,w:56,h:82}}
function wcHandSpot(){return{x:800-56,y:715,w:112,h:164}}
function wcPileSpot(){const d=$('wcdisc');const r=wcLocal(d);return r&&{x:r.x,y:r.y,w:r.w,h:r.h}}
function wcDeckSpot(){return wcLocal($('wcdeck').querySelector('.d1'))}
function wcPop(txt,cls,at){const fx=$('wcfx');if(!fx)return;const e=document.createElement('div');e.className='wcpop '+(cls||'');e.innerHTML=txt;if(at){e.style.left=at.x+'px';e.style.top=at.y+'px'}fx.appendChild(e);setTimeout(()=>e.remove(),1500)}
function wcBurst(at,col,n){const fx=$('wcfx');if(!fx||wcRM())return;const b=document.createElement('div');b.className='wcburst';b.style.left=at.x+'px';b.style.top=at.y+'px';b.style.setProperty('--c',col);
 b.innerHTML=Array.from({length:n||10},(_,i)=>`<i style="--a:${i*360/(n||10)+(i%2)*14}deg;--r:${70+(i%3)*28}px;--s:${.7+(i%3)*.3}"></i>`).join('')+'<b></b>';fx.appendChild(b);setTimeout(()=>b.remove(),900)}
function wcCount(i,d){WX.vc[i]=(WX.vc[i]||0)+d;const s=wcSeatEl(i);if(!s)return;const n=s.querySelector('.wcn');if(n){n.textContent=Math.max(0,WX.vc[i]);n.classList.remove('bump');void n.offsetWidth;n.classList.add('bump')}
 const bk=s.querySelector('.wcbacks');if(bk){const c=Math.min(9,Math.max(0,WX.vc[i]));bk.innerHTML=Array.from({length:c},(_,k)=>`<i class="wcmbk" style="--k:${k-(c-1)/2}">${wcBack(wcBackSel())}</i>`).join('')}}
const WCACT={stun:['STUN!','#ffd45a'],turn:['TURNABOUT!','#8ad8ff'],d2:['+2 CURSE!','#ff8a6a'],d4:['+4 HEX!','#d08aff'],wild:['WILD RUNE!','#fff']};
async function wcAnim(e){const G=WX.G;
 if(e.k==='deal'){const n=e.hand,dk=wcDeckSpot();if(!dk)return;const T=[];WX.vc=G.P.map(()=>0);for(const i of G.P.keys())wcCount(i,0);
  wcSnd(300,.05,'triangle',.15);for(let k=0;k<n;k++)for(let i=0;i<G.P.length;i++){const me=i===WX.me;T.push(wcFly(wcBack(wcBackSel()),dk,me?wcHandSpot():wcSeatSpot(i),{dur:300,arc:-30}).then(()=>{if(!me)wcCount(i,1)}));if(k%2===0&&i===0)wcSnd(500+k*30,.03,'triangle',.12);await wcSleep(38)}
  await Promise.all(T);WX.fresh=new Set(G.P[WX.me].hand.map(c=>c.id));wcRenderHand();await wcSleep(250);return}
 if(e.k==='turn'){document.querySelectorAll('.wcseat').forEach(s=>s.classList.toggle('on',+s.dataset.seat===e.p));if(e.p===WX.me&&wcMine())wcSnd(660,.06,'triangle',.2);return}
 if(e.k==='play'){const c=e.c,me=e.p===WX.me;let from;const el=me?document.querySelector(`.wchc[data-id="${c.id}"]`):null;
  if(el){from=wcLocal(el);el.style.visibility='hidden'}else from=wcSeatSpot(e.p);const to=wcPileSpot();if(!to)return;
  if(!me)wcCount(e.p,-1);wcSnd(420,.05,'triangle',.3);
  await wcFly(wcSVG(c),from,to,{flip:!me,dur:me?320:400,r0:me?0:-20,r1:wcRot(c.id),arc:-50});
  const d=$('wcdisc');d.querySelectorAll('.top').forEach(x=>x.classList.remove('top'));d.insertAdjacentHTML('beforeend',wcCardEl(c,'top land',`style="--r:${wcRot(c.id)}deg"`));while(d.children.length>4)d.firstElementChild.remove();
  if(el)el.remove();const gl=$('wcglow');gl.style.setProperty('--gc',WCC[e.col]);gl.dataset.c=e.col;gl.classList.remove('pulse');void gl.offsetWidth;gl.classList.add('pulse');
  const mid={x:to.x+to.w/2,y:to.y+to.h/2};wcBurst(mid,WCC[e.col],c.s==='w'||!wcIsNum(c)?14:8);wcSnd(c.s==='w'?520:330,.07,'triangle',.3);
  if(WCACT[c.v]){wcPop(WCACT[c.v][0],'act',{x:800,y:300});wcSnd(c.v==='d4'?180:740,.12,c.v==='d4'?'sawtooth':'square',.25)}
  if(c.s==='w'){wcPop(`${wcOrb(e.col,46)}<span>${WCN[e.col]}!</span>`,'col',{x:800,y:362});wcSnd(990,.1,'triangle',.25,120)}
  await wcSleep(WCACT[c.v]?380:140);return}
 if(e.k==='draw'){const me=e.p===WX.me,dk=wcDeckSpot();const n=e.c.length;if(e.stack){wcPop(`+${e.stack}`,'stk',wcCen(e.p));wcSnd(160,.18,'sawtooth',.3)}
  for(let k=0;k<n;k++){const card=me?G.P[WX.me].hand.find(x=>x.id===e.c[k]):null;const to=me?{x:800+Math.min(380,G.P[WX.me].hand.length*30)-56,y:715,w:112,h:164}:wcSeatSpot(e.p);
   wcFly(card?wcSVG(card):wcBack(wcBackSel()),dk,to,{flip:!!card,dur:330,arc:-36}).then(()=>{if(!me)wcCount(e.p,1)});wcSnd(560+k*40,.03,'triangle',.15);await wcSleep(n>4?70:110)}
  await wcSleep(330);if(me){WX.fresh=new Set(e.c);wcRenderHand()}const dn=$('wcdn');if(dn)dn.textContent=Math.max(0,+dn.textContent-n);return}
 if(e.k==='skip'){const s=wcSeatEl(e.p);if(s){s.classList.remove('stun');void s.offsetWidth;s.classList.add('stun')}wcPop('Stunned!','stn',wcCen(e.p,-70));wcSnd(240,.1,'square',.2);await wcSleep(420);return}
 if(e.k==='rev'){const r=$('wcring');r.classList.toggle('rev',e.dir<0);r.classList.remove('flip');void r.offsetWidth;r.classList.add('flip');wcSnd(500,.06,'triangle',.25);wcSnd(700,.06,'triangle',.25,90);await wcSleep(420);return}
 if(e.k==='stack'){wcStack();const s=$('wcstack');s.classList.remove('pop');void s.offsetWidth;s.classList.add('pop');return}
 if(e.k==='call'){wcPop('WILD!','call',wcCen(e.p,-80));wcSnd(988,.08,'square',.25);wcSnd(1319,.12,'square',.22,90);const s=wcSeatEl(e.p);if(s&&!s.querySelector('.wcw1'))s.insertAdjacentHTML('beforeend','<span class="wcw1">WILD!</span>');await wcSleep(300);return}
 if(e.k==='catch'){wcPop(`Caught! <small>${esc(G.P[e.by].name)} spotted it</small>`,'caught',wcCen(e.p,-80));wcSnd(200,.15,'sawtooth',.3);const dk=wcDeckSpot(),me=e.p===WX.me;
  for(const id of e.c){const card=me?G.P[WX.me].hand.find(x=>x.id===id):null;wcFly(card?wcSVG(card):wcBack(wcBackSel()),dk,me?wcHandSpot():wcSeatSpot(e.p),{flip:!!card,dur:330}).then(()=>{if(!me)wcCount(e.p,1)});await wcSleep(120)}
  await wcSleep(350);wcTip('');return}
 if(e.k==='swap'){wcPop('Hands swapped!','act',{x:800,y:300});const a=wcSeatSpot(e.a)||wcHandSpot(),b=wcSeatSpot(e.b)||wcHandSpot();for(let k=0;k<4;k++){wcFly(wcBack(wcBackSel()),a,b,{dur:420});wcFly(wcBack(wcBackSel()),b,a,{dur:420});await wcSleep(70)}
  await wcSleep(420);const t=WX.vc[e.a];WX.vc[e.a]=WX.vc[e.b];WX.vc[e.b]=t;return}
 if(e.k==='pass'){wcPop('Keeps it','sm',wcCen(e.p,-70));await wcSleep(200);return}
 if(e.k==='shuffle'){const d=$('wcdeck');d.classList.remove('shuf');void d.offsetWidth;d.classList.add('shuf');wcPop('Shuffled the pile','sm',{x:680,y:340});await wcSleep(420);return}
 if(e.k==='win'){const s=wcSeatEl(e.p);if(s)s.classList.add('won');wcPop(`${esc(G.P[e.p].name)} wins!`,'win',{x:800,y:300});if(e.p===WX.me){jingle&&jingle('win')}else wcSnd(220,.3,'triangle',.3);await wcSleep(400)}}
function wcCen(i,dy){const s=wcSeatEl(i);const r=s&&wcLocal(s.querySelector('.wcav'));return r?{x:r.x+r.w/2,y:r.y+(dy||0)}:{x:800,y:600}}
function wcTip(h){let t=$('wctip');if(!h){if(t)t.remove();return}if(!t){t=document.createElement('div');t.id='wctip';t.className='wctip';const w=$('wct');if(!w)return;w.appendChild(t)}t.innerHTML=h}
function wcToast(h){const w=$('wct');if(!w)return;const t=document.createElement('div');t.className='wctoast';t.innerHTML=h;w.appendChild(t);setTimeout(()=>t.remove(),2600)}
function wcBubble(i,txt,ms){const b=$('wcbub'+i);if(!b||!txt)return;b.textContent=txt;b.classList.remove('on');void b.offsetWidth;b.classList.add('on');clearTimeout(b._t);b._t=setTimeout(()=>b.classList.remove('on'),ms||2200)}
const WCTAUNT={d4:['Hex on you!','Draw, little hero!','Four for you!'],d2:['Take two!','Curse you!'],stun:['Sit this one out.','Stunned!'],turn:['Other way!','Turn about!'],one:['Ha! One left.','Almost there…'],win:['Too easy.','Better luck next time!']};
function wcTaunt(pi,a){const G=WX.G,p=G.P[pi];if(p.kind!=='bot'||G.r()>.42)return;const c=G.disc[G.disc.length-1];const k=G.phase==='over'?'win':p.hand.length===1?'one':c&&WCTAUNT[c.v]?c.v:null;if(!k)return;const L=WCTAUNT[k];wcLater(()=>wcBubble(pi,L[Math.floor(Math.random()*L.length)]),420)}
/* pass & play: hide the hand until the next player taps in */
function wcCurtain(seat){const G=WX.G,m=$('wcmod');if(!m)return;WX.cover=true;wcRenderHand();m.hidden=false;m.className='wcmod wccur';
 m.innerHTML=`<div class="wccb"><canvas width="180" height="180"></canvas><small>Pass the device to</small><b>${esc(G.P[seat].name)}</b><p>Everyone else, look away! Your cards stay hidden until you tap.</p><button class="wcbtn gold" id="wcimr">I'm ${esc(G.P[seat].name)}, show my cards</button></div>`;
 wcPortrait(m.querySelector('canvas'),G.P[seat].av);wcSnd(520,.06,'triangle',.2);
 $('wcimr').onclick=()=>{m.hidden=true;m.innerHTML='';WX.cover=false;WX.me=seat;wcRender();wcStep()};setTimeout(()=>{const b=$('wcimr');if(b)b.focus()},40)}
/* leaving mid-game forfeits the buy-in */
function wcLeaveAsk(){const m=$('wcmod');if(!m)return wcHome();if(!m.hidden&&m.classList.contains('wclv')){m.hidden=true;m.innerHTML='';return}if(!m.hidden&&m.classList.contains('wcpk')){m.hidden=true;m.innerHTML='';return}
 if(!WX.G||WX.G.phase==='over')return wcExit();m.hidden=false;m.className='wcmod wclv';
 m.innerHTML=`<div class="wccb"><b>Leave the table?</b><p>${WX.stake?`Your buy-in of <b>${cmn(WX.stake)}</b> gold stays in the pot and the game counts as a loss.`:'The game will count as a loss.'}</p><div class="wcrow"><button class="wcbtn" id="wcstay">Keep playing</button><button class="wcbtn red" id="wcgo">Leave</button></div></div>`;
 $('wcstay').onclick=()=>{m.hidden=true;m.innerHTML=''};$('wcgo').onclick=()=>{wcRecord({forfeit:1});wcExit()};setTimeout(()=>{const b=$('wcstay');if(b)b.focus()},40)}
function wcExit(){WX.tok++;wcClear();try{wcNetClose()}catch(e){}WX.G=null;wcHome()}
addEventListener('keydown',e=>{if(!$('wct')||ov.className.indexOf('hide')>=0||e.ctrlKey||e.metaKey||e.altKey)return;const m=$('wcmod');if(m&&!m.hidden)return;const ae=document.activeElement;if(ae&&/INPUT|TEXTAREA/.test(ae.tagName))return;
 const k=e.key.toLowerCase();if(k==='d'){e.preventDefault();$('wcdeck').click()}else if(k==='w'){e.preventDefault();$('wcone').click()}else if(k==='h'){e.preventDefault();wcHint()}else if(k==='k'&&$('wckeep')){e.preventDefault();$('wckeep').click()}
 else if((k==='arrowleft'||k==='arrowright')&&!(ae&&ae.classList&&ae.classList.contains('wchc'))){const c=document.querySelector('.wchc.ok')||document.querySelector('.wchc');if(c){e.preventDefault();c.focus()}}});
