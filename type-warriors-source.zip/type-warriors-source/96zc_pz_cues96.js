/* ===== 9.6 THE CROOKED CUE: the cues, redrawn (96zc) =====
   Same sprite size and anchor as 96h (tip at the right, butt at -L), so every user (table, rack, upright wall,
   hand slot) picks it up. Built in slices so the round shading follows the taper: chalked leather tip, ivory ferrule,
   grained maple shaft, a metal joint collar, a forearm with inlaid points, a stitched wrap, a butt sleeve with each
   cue's own motif, gold rings and a rubber bumper. Baked once per cue. */
function pzCueSprite(id){if(PZ_CUE.cache[id])return PZ_CUE.cache[id];const sk=PZ_CUES.find(c=>c.id===id)||PZ_CUES[0],L=PZ_CUE.L,S=2,W=(L+22)*S,H=30*S,c=pzCv(W,H),g=c.getContext('2d');
 g.scale(S,S);g.translate(L+10,15);g.lineJoin='round';g.lineCap='round';
 const J=-L*.58,FA=J-80,WR=FA-54,BT=-L+7;
 const wd=x=>x<J?(3.0+(-x+J)/(L+J)*4.6):(2.45+(-x)/(-J)*.75);
 const path=(x0,x1)=>{g.beginPath();g.moveTo(x0,-wd(x0));g.lineTo(x1,-wd(x1));g.lineTo(x1,wd(x1));g.lineTo(x0,wd(x0));g.closePath()};
 const fill=(x0,x1,f)=>{g.fillStyle=f;path(x0,x1);g.fill()};
 /* round shading in short slices so the light band follows the taper */
 const shade=(x0,x1,k)=>{const lo=Math.min(x0,x1),hi=Math.max(x0,x1),r5=v=>Math.round(v*2)/2,n=Math.max(1,Math.ceil((hi-lo)/10));g.save();path(x0,x1);g.clip();
  for(let i=0;i<n;i++){const a=r5(lo+(hi-lo)*i/n),b=r5(lo+(hi-lo)*(i+1)/n),w=wd((a+b)/2);
   const q=g.createLinearGradient(0,-w,0,w);q.addColorStop(0,`rgba(255,255,255,${.30*k})`);q.addColorStop(.22,`rgba(255,255,255,${.42*k})`);q.addColorStop(.36,'rgba(255,255,255,0)');q.addColorStop(.7,`rgba(0,0,0,${.12*k})`);q.addColorStop(1,`rgba(0,0,0,${.42*k})`);
   g.fillStyle=q;g.fillRect(a,-9,b-a,18)}g.restore()};
 const ring=(x,w,col)=>{const h=wd(x)+.5;g.fillStyle=col;g.fillRect(x-w/2,-h,w,h*2);g.fillStyle='rgba(255,250,220,.75)';g.fillRect(x-w/2,-h,w,h*.45);g.fillStyle='rgba(0,0,0,.35)';g.fillRect(x-w/2,h*.5,w,h*.5)};
 const gold='#e0aa3e',silver='#d8dce8';
 /* soft shadow under the cue */
 g.fillStyle='rgba(0,0,0,.2)';g.beginPath();g.moveTo(0,0);g.lineTo(-L,-4);g.lineTo(-L,10);g.lineTo(0,5);g.fill();
 /* shaft: maple, light at the ferrule, the cue's own tint toward the joint, with wavy grain */
 fill(-24,J,pzLin(g,-24,0,J,0,[[0,sk.a],[1,sk.b]]));
 g.save();path(-24,J);g.clip();
 for(let i=0;i<9;i++){g.strokeStyle=i%3?'rgba(110,64,16,.13)':'rgba(110,64,16,.22)';g.lineWidth=.45;g.beginPath();const y=(i-4)*.62;for(let x=-24;x>=J;x-=6){const yy=y*(wd(x)/2.9)+Math.sin(x*.045+i*1.7)*.35;x===-24?g.moveTo(x,yy):g.lineTo(x,yy)}g.stroke()}
 g.restore();shade(-24,J,1);
 /* ferrule (ivory) and the chalked leather tip */
 g.fillStyle='#f6f0e0';g.beginPath();g.roundRect(-24,-2.55,17.5,5.1,1.2);g.fill();shade(-24,-6.5,.8);
 g.fillStyle='rgba(120,100,70,.35)';g.fillRect(-23.4,-2.55,.7,5.1);
 g.fillStyle='#2f6fd0';g.beginPath();g.roundRect(-7.2,-2.45,7.2,4.9,[0,2.4,2.4,0]);g.fill();
 g.fillStyle='rgba(150,200,255,.75)';for(let i=0;i<6;i++)g.fillRect(-2.2+((i*37)%3)*.6,-1.8+i*.62,.9,.5);
 g.fillStyle='rgba(255,255,255,.45)';g.fillRect(-6.4,-1.9,4.6,.9);
 /* forearm (joint to wrap): the cue's dark wood with four inlaid points */
 fill(J,FA,pzLin(g,J,0,FA,0,[[0,pzMix(sk.c,sk.b,.18)],[1,sk.c]]));
 g.save();path(J,FA);g.clip();
 for(let k=-1;k<=1;k+=2){/* each visible point: veneer outline in gold, body in the accent colour */
  const base=FA,tip=J-6,mid=k*0;g.fillStyle=gold;g.beginPath();g.moveTo(base,mid-wd(base)*1.1*k);g.lineTo(tip,mid);g.lineTo(base,mid+wd(base)*.2*k);g.closePath();g.fill();
  g.fillStyle=sk.d;g.beginPath();g.moveTo(base,mid-wd(base)*.9*k);g.lineTo(tip+6,mid-.15*k);g.lineTo(base,mid+wd(base)*.05*k);g.closePath();g.fill()}
 g.fillStyle=sk.d;g.globalAlpha=.55;g.beginPath();g.moveTo(FA,-1.4);g.lineTo(J-14,0);g.lineTo(FA,1.4);g.fill();g.globalAlpha=1;
 g.restore();shade(J,FA,1);
 /* the joint collar */
 const jc=sk.glow?silver:gold;fill(J+4,J-4,jc);shade(J+4,J-4,1.1);g.fillStyle='rgba(0,0,0,.45)';g.fillRect(J-.4,-wd(J)-.2,.8,wd(J)*2+.4);ring(J+4.4,1.2,'#14101a');
 ring(FA-1,2.2,gold);ring(FA-4,1.2,sk.d);
 /* the wrap: leather or linen, stitched in a crosshatch */
 const w0=FA-6,w1=WR;fill(w0,w1,sk.wrap);
 g.save();path(w0,w1);g.clip();
 for(let x=w0;x>w1-6;x-=3.6){g.strokeStyle='rgba(255,255,255,.11)';g.lineWidth=.7;g.beginPath();g.moveTo(x,-wd(x));g.lineTo(x-4.2,wd(x));g.stroke();g.strokeStyle='rgba(0,0,0,.32)';g.beginPath();g.moveTo(x-1.4,-wd(x));g.lineTo(x+2.8,wd(x));g.stroke()}
 for(let x=w0-2;x>w1;x-=7.2){g.fillStyle='rgba(255,255,255,.10)';g.fillRect(x,-.4,1.6,.8)}
 g.restore();shade(w0,w1,1.2);ring(w0,2,gold);ring(w1,2,gold);
 /* butt sleeve: dark, with the accent band and a motif per cue */
 fill(w1-1,BT,pzLin(g,w1,0,BT,0,[[0,sk.c],[.5,pzMix(sk.c,sk.d,.22)],[1,sk.c]]));
 g.save();path(w1-1,BT);g.clip();pzCueMotif(g,sk,w1-7,BT+11,wd);g.restore();shade(w1-1,BT,1.1);
 ring(w1-5,1.1,sk.d);ring(BT+9,2.4,gold);ring(BT+5,1,silver);
 /* rubber bumper */
 const bw=wd(BT);g.fillStyle='#16121e';g.beginPath();g.roundRect(-L,-bw-.6,BT+L+.5,(bw+.6)*2,[3,0,0,3]);g.fill();g.fillStyle='rgba(255,255,255,.14)';g.fillRect(-L+1.5,-bw+.4,BT+L-2,1.1);
 /* outline */
 g.strokeStyle=PZ_O;g.lineWidth=1.4;g.beginPath();g.moveTo(-.3,-2.45);g.lineTo(-24,-2.55);g.lineTo(J,-wd(J));g.lineTo(BT,-wd(BT));g.lineTo(BT,-bw-.6);g.lineTo(-L+2,-bw-.6);g.quadraticCurveTo(-L,-bw-.6,-L,-bw+2);g.lineTo(-L,bw-2);g.quadraticCurveTo(-L,bw+.6,-L+2,bw+.6);g.lineTo(BT,bw+.6);g.lineTo(BT,wd(BT));g.lineTo(J,wd(J));g.lineTo(-24,2.55);g.lineTo(-.3,2.45);g.quadraticCurveTo(.8,0,-.3,-2.45);g.stroke();
 /* the long gloss line along the top */
 g.strokeStyle='rgba(255,255,255,.5)';g.lineWidth=.6;g.beginPath();g.moveTo(-26,-1.75);g.lineTo(J,-wd(J)+.9);g.stroke();
 g.strokeStyle='rgba(255,255,255,.28)';g.beginPath();g.moveTo(FA-8,-wd(FA-8)+1.1);g.lineTo(BT+12,-wd(BT+12)+1.4);g.stroke();
 return PZ_CUE.cache[id]={c,W,H,L,sk}}
/* the butt-sleeve motif, between x0 (near the wrap) and x1 (near the bumper); clipped to the sleeve */
function pzCueMotif(g,sk,x0,x1,wd){const d=sk.d,a=sk.a,n=x0-x1,id=sk.id,gold='#e0aa3e';
 const dia=(x,s,f,o)=>{const w=wd(x)*s;g.fillStyle=f;g.beginPath();g.moveTo(x+w*1.6,0);g.lineTo(x,-w);g.lineTo(x-w*1.6,0);g.lineTo(x,w);g.closePath();g.fill();if(o){g.strokeStyle=o;g.lineWidth=.6;g.stroke()}};
 const dot=(x,y,r,f)=>{g.fillStyle=f;g.beginPath();g.arc(x,y,r,0,TAU);g.fill()};
 const step=n/4;
 if(id==='ember'){/* flames licking up from the bumper */
  const w=wd(x1);for(let i=0;i<5;i++){const yc=(i-2)*w*.42,len=n*(.42+.28*((i*3)%5)/4),s2=i%2?-1:1;g.fillStyle=i%2?'#ffd070':d;g.beginPath();g.moveTo(x1-1,yc-w*.5);g.quadraticCurveTo(x1+len*.55,yc-w*.55,x1+len,yc+s2*w*.25);g.quadraticCurveTo(x1+len*.45,yc+w*.45,x1-1,yc+w*.5);g.closePath();g.fill()}}
 else if(id==='frost'){for(let i=0;i<4;i++){const x=x1+step*(i+.5),w=wd(x)*.8;g.strokeStyle=d;g.lineWidth=.9;for(let k=0;k<3;k++){const an=k*Math.PI/3;g.beginPath();g.moveTo(x-Math.cos(an)*w,-Math.sin(an)*w);g.lineTo(x+Math.cos(an)*w,Math.sin(an)*w);g.stroke()}dot(x,0,.9,'#ffffff')}}
 else if(id==='dragonbone'){for(let x=x1+2;x<x0;x+=7){const w=wd(x);for(let r=-1;r<=1;r++){g.fillStyle=r?pzMix(sk.c,d,.45):d;g.beginPath();g.arc(x,r*w*.62,w*.38,-Math.PI/2,Math.PI/2);g.fill()}}}
 else if(id==='slime'){for(let i=0;i<7;i++){const x=x1+6+i*n/7,w=wd(x);dot(x,-w*.2+Math.sin(i*2.1)*w*.4,w*(.28+.12*(i%3)),i%2?d:a)}g.fillStyle=d;g.fillRect(x0-6,-wd(x0),6,wd(x0)*2)}
 else if(id==='mycelium'){for(let i=0;i<9;i++){const x=x1+5+i*n/9,w=wd(x);dot(x,(i%3-1)*w*.55,w*(.18+.1*(i%2)),i%2?d:'#fff4f8')}}
 else if(id==='smasher'){for(let i=0;i<5;i++){const x=x1+6+i*n/5,w=wd(x);g.fillStyle='rgba(0,0,0,.4)';g.fillRect(x-1.2,-w,2.4,w*2);dot(x+4,-w*.5,.9,'#e8e8f0');dot(x+4,w*.5,.9,'#e8e8f0')}g.fillStyle=d;g.fillRect(x1,-wd(x1),4,wd(x1)*2)}
 else if(id==='nightwing'){for(let i=0;i<4;i++){const x=x1+step*(i+.3),w=wd(x);g.fillStyle=d;g.beginPath();g.moveTo(x+10,0);g.lineTo(x,-w);g.lineTo(x+3,0);g.lineTo(x,w);g.closePath();g.fill()}}
 else if(id==='harpoon'){/* rope wound round the butt */for(let x=x1+4;x<x1+n*.45;x+=3){const w=wd(x);g.strokeStyle=(x|0)%2?'#c8a878':'#a8885a';g.lineWidth=1.6;g.beginPath();g.moveTo(x,-w);g.lineTo(x+2.4,w);g.stroke()}dia(x1+n*.72,.7,d,gold)}
 else if(id==='quill'){for(let x=x1+4;x<x0-2;x+=3.2){const w=wd(x);g.strokeStyle=pzMix(a,d,.4);g.lineWidth=.6;g.beginPath();g.moveTo(x,0);g.lineTo(x+4,-w);g.moveTo(x,0);g.lineTo(x+4,w);g.stroke()}g.strokeStyle=d;g.lineWidth=.8;g.beginPath();g.moveTo(x1,0);g.lineTo(x0,0);g.stroke()}
 else if(id==='scepter'){for(let i=0;i<4;i++){const x=x1+step*(i+.5),w=wd(x);dot(x-3,-w*.35,w*.28,'#f4f0e6');dot(x-3,w*.35,w*.28,'#f4f0e6');g.fillStyle='#f4f0e6';g.fillRect(x-3,-w*.18,7,w*.36);dot(x+4,-w*.35,w*.28,'#f4f0e6');dot(x+4,w*.35,w*.28,'#f4f0e6')}dia(x0-4,.55,d)}
 else if(id==='shadow'){for(let i=0;i<4;i++)dia(x1+step*(i+.5),.62,d,'#fff4b0');g.fillStyle=d;g.fillRect(x1+2,-.35,n-4,.7)}
 else if(id==='maple'){for(let i=0;i<3;i++)dia(x1+n*(i+.5)/3,.55,a,gold)}
 else{/* house cue: a plain pair of diamonds and a band */for(let i=0;i<2;i++)dia(x1+n*(i+.5)/2,.55,d,'#f0d8a0');g.fillStyle=d;g.fillRect(x1+n*.5-1,-wd(x1+n*.5),2,wd(x1+n*.5)*2)}}
/* the old wall pictures and the upright rack art are cached per cue: start fresh */
try{PZ_CUE.cache={};if(typeof PZ_UPRIGHT==='object')for(const k in PZ_UPRIGHT)delete PZ_UPRIGHT[k]}catch(e){}
/* the player's portrait (HUD, VS, pause): a square head-and-shoulders crop centred on the face, not a squashed
   wide strip of the whole sprite */
{const f0=pzCastPortrait;pzCastPortrait=function(g,who,id,size,t,ex){if(who!=='hero')return f0.apply(this,arguments);
 g.save();g.clearRect(0,0,size,size);const sp=PZ_CAST.sprites.idle;if(sp){const k=sp.width/344,cw=196*k;g.imageSmoothingQuality='high';g.drawImage(sp,60*k,6*k,cw,cw,0,size*.04,size,size)}g.restore()}}
