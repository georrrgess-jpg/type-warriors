/* ===== MOONLIT FISHING: Fishing Spots destination gallery =====
   Replaces the painted world map (fsMap in 90l). Same entry point: fsMap(back), view 'fishmap'.
   Header (title, species logged, "Currently fishing", coins, Back), four destination cards (painted scenery cropped from
   each spot's real scene, Stormreach from 90l2), and one bottom panel with the selected spot and its single action.
   Clicking a card only previews it (FSDG.sel, temporary); the action button travels with fsTravel() and enters fsPond().
   The current spot stays P.fish.loc. Layout adapts to how large the 1600x900 stage is actually shown (fsdgFit). */
const FSDG={sel:null,busy:false,art:{},nav:null};
/* crop of each painted scene used for its card (scene px, aspect 369:400) */
const FSDGCROP={pond:[360,70,660,715],frost:[430,90,660,715],grotto:[920,100,660,715],cove:[370,40,660,715]};
function fsdgArt(k){if(FSDG.art[k])return FSDG.art[k];const W=738,H=800,c=document.createElement('canvas');c.width=W;c.height=H;const g=c.getContext('2d');
 if(k==='storm'){try{fsStormArt(g,W,H)}catch(e){g.fillStyle='#1a2a4a';g.fillRect(0,0,W,H)}}
 else{const s=document.createElement('canvas');s.width=1600;s.height=900;const sg=s.getContext('2d');try{fsScene(sg,2.3,{noHero:1,shadows:[],loc:k,rm:true})}catch(e){}const r=FSDGCROP[k];g.drawImage(s,r[0],r[1],r[2],r[3],0,0,W,H)}
 return FSDG.art[k]=c}
/* map a scene point into card-art space */
const fsdgPt=(k,x,y,W,H)=>{const r=FSDGCROP[k];return[(x-r[0])/r[2]*W,(y-r[1])/r[3]*H]};
/* light ambient touches per spot, drawn over the cached art (no filters, a few shapes) */
function fsdgFx(g,k,W,H,t){const s=W/369;
 if(k==='pond'){const[lx,ly]=fsdgPt(k,587,512,W,H),fl=.5+.18*Math.sin(t*7.3)+.1*Math.sin(t*13.1);fkGlow(g,lx,ly,60*s,'#ffcf6a',.32*fl);
  const[mx]=fsdgPt(k,930,0,W,H);for(let i=0;i<5;i++){const y=H*(.68+i*.045),a=.25+.25*Math.sin(t*1.6+i*1.7);g.fillStyle=`rgba(255,244,214,${Math.max(0,a)})`;g.fillRect(mx-(18-i*2)*s+Math.sin(t*.9+i)*6*s,y,(36-i*4)*s,2*s)}
  for(let i=0;i<4;i++){const x=W*(.2+.2*i)+Math.sin(t*.7+i*2)*18*s,y=H*(.55+.08*Math.sin(t*.5+i))-i*10*s,a=.5+.5*Math.sin(t*2.2+i*1.3);fkGlow(g,x,y,9*s,'#fff2a8',.5*a);g.fillStyle=`rgba(255,248,200,${.8*a})`;g.beginPath();g.arc(x,y,1.6*s,0,TAU);g.fill()}}
 else if(k==='frost'){fkGlow(g,W*.55,H*.2,W*.5,'#5affd0',.06+.05*Math.sin(t*.6));fkGlow(g,W*.25,H*.18,W*.3,'#a87aff',.05+.04*Math.sin(t*.5+1.4));
  g.fillStyle='#ffffff';for(let i=0;i<14;i++){const u=((t*.06+fsRnd(i)*1)%1),x=(fsRnd(i+20)*W+Math.sin(t*.8+i)*10*s+W)%W,y=u*H*.95;g.globalAlpha=.35+.4*fsRnd(i+5);g.beginPath();g.arc(x,y,(1+fsRnd(i+9)*1.4)*s,0,TAU);g.fill()}g.globalAlpha=1}
 else if(k==='grotto'){const[wx,wy]=fsdgPt(k,1290,380,W,H);g.strokeStyle='rgba(220,250,255,.35)';g.lineWidth=1.4*s;for(let i=0;i<3;i++){const y=wy-60*s+((t*90+i*40)%120)*s;g.beginPath();g.moveTo(wx-4*s+i*4*s,y);g.lineTo(wx-4*s+i*4*s,y+16*s);g.stroke()}
  const[mx,my]=fsdgPt(k,1460,330,W,H);fkGlow(g,mx,my,90*s,'#5affc8',.12+.06*Math.sin(t*1.3));
  for(let i=0;i<9;i++){const u=((t*.05+fsRnd(i+40))%1),x=fsRnd(i+50)*W+Math.sin(t+i)*8*s,y=H*(.95-u*.8),a=Math.sin(u*Math.PI);fkGlow(g,x,y,7*s,i%2?'#9a7aff':'#5ae8ff',.55*a);g.fillStyle=`rgba(230,250,255,${.9*a})`;g.beginPath();g.arc(x,y,1.5*s,0,TAU);g.fill()}}
 else{try{fsStormFx(g,W,H,t)}catch(e){}}}
/* spot state: current / open / soon / locked, with counts */
function fsdgState(k){const L=FSLOCS[k],cur=fsLoc(),tot=FSPOOL[k].length,got=fsLocFound(k),n=fsFound(),soon=!!L.soon,open=!soon&&fsLocOpen(k);
 return{k,L,here:k===cur,soon,open,locked:!soon&&!open,tot,got,pct:tot?got/tot*100:0,need:L.need||0,n}}
const FSDGPIN='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2a7 7 0 0 0-7 7c0 5 7 13 7 13s7-8 7-13a7 7 0 0 0-7-7z" fill="currentColor"/><circle cx="12" cy="9" r="2.6" fill="#0a1a3a"/></svg>';
const FSDGSTAR='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.5l2.9 6.1 6.6.8-4.9 4.6 1.3 6.6L12 17.3 6.1 20.6l1.3-6.6L2.5 9.4l6.6-.8z" fill="currentColor" stroke="#1b1024" stroke-width="1.4" stroke-linejoin="round"/></svg>';
const FSDGGLASS='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 3h12M6 21h12M7 3c0 5 5 6 5 9s-5 4-5 9M17 3c0 5-5 6-5 9s5 4 5 9" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M9 19c1-2 2-2.5 3-2.5s2 .5 3 2.5z" fill="currentColor"/></svg>';
const FSDGLOCK='<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="10" width="14" height="11" rx="2.5" fill="currentColor"/><path d="M8 10V7a4 4 0 0 1 8 0v3" fill="none" stroke="currentColor" stroke-width="2.4"/></svg>';
function fsdgCard(k,i){const s=fsdgState(k),L=s.L,sel=FSDG.sel===k;
 const label=`${L.n}. ${s.here?'Current location. ':''}${s.soon?'Coming soon. ':s.locked?`Locked: discover ${s.need} species to unlock. `:`${s.got} of ${s.tot} fish found. `}`;
 return `<button class="fsdg-card${sel?' sel':''}${s.here?' here':''}${s.soon?' soon':''}${s.locked?' lock':''}" data-k="${k}" style="--lc:${L.c};--i:${i}" aria-pressed="${sel}" aria-label="${fsEsc(label)}">
  <canvas class="fsdg-art" width="738" height="800" aria-hidden="true"></canvas><span class="fsdg-shade" aria-hidden="true"></span>
  ${s.here?`<span class="fsdg-rib cur">${FSDGPIN}Current location</span>`:sel?`<span class="fsdg-rib sel">${FSDGSTAR}Selected</span>`:''}
  ${s.soon?`<span class="fsdg-ban">${FSDGGLASS}Coming soon</span>`:s.locked?`<span class="fsdg-ban lk">${FSDGLOCK}Locked</span>`:''}
  <span class="fsdg-info"><b>${L.n}</b><small>${L.d}</small>
   ${s.soon?'':s.locked?`<em>Discover ${s.need} species to unlock</em><i class="fsdg-bar lk" aria-hidden="true"><i style="width:${Math.min(100,s.n/s.need*100).toFixed(1)}%"></i></i><span class="fsdg-sub">${Math.min(s.n,s.need)} / ${s.need} species logged</span>`
   :`<em>${s.got} / ${s.tot} fish found</em><i class="fsdg-bar" aria-hidden="true"><i style="width:${s.pct.toFixed(1)}%"></i></i>`}</span></button>`}
function fsdgPanel(){const k=FSDG.sel,s=fsdgState(k),L=s.L;
 const act=s.soon?`<button class="fsdg-go" id="fsdggo" disabled>${FSDGGLASS}Coming soon</button>`:s.locked?`<button class="fsdg-go" id="fsdggo" disabled>${FSDGLOCK}Locked</button>`
  :`<button class="fsdg-go" id="fsdggo">${s.here?'Continue fishing':'Fish here'} <span aria-hidden="true">›</span></button>`;
 const prog=s.soon?`<p class="fsdg-pst">Coming in a future update. You can't travel here yet.</p>`
  :s.locked?`<p class="fsdg-pst">Discover <b>${s.need}</b> different species to unlock this spot.</p><div class="fsdg-prow"><span>${Math.min(s.n,s.need)} of ${s.need} species logged</span><i class="fsdg-bar lk" aria-hidden="true"><i style="width:${Math.min(100,s.n/s.need*100).toFixed(1)}%"></i></i></div>`
  :`<div class="fsdg-prow"><span>${s.got} of ${s.tot} species discovered</span><i class="fsdg-bar" aria-hidden="true"><i style="width:${s.pct.toFixed(1)}%"></i></i></div>`;
 return `<div class="fsdg-pin2" style="--lc:${L.c}"><canvas id="fsdgth" width="280" height="280" aria-hidden="true"></canvas><div class="fsdg-ptx"><h3>${L.n}${s.here?` <span class="fsdg-tag">${FSDGPIN}You are here</span>`:''}</h3><p>${L.d}</p>${prog}</div>${act}</div>`}
function fsMap(back){back=back||fsHub;S.mode='fish';S.view='fishmap';FS.on=false;FSDG.busy=false;FSDG.nav=back;
 const cur=fsLoc();FSDG.sel=FSLOCS[cur]&&fsLocOpen(cur)?cur:(FSLOCK.find(k=>fsLocOpen(k))||'pond');
 const n=fsFound();
 show(`<div class="fsx fsdg" id="fsx"><canvas id="fsdgbg" width="1600" height="900" aria-hidden="true"></canvas><i class="fsdg-dim" aria-hidden="true"></i>
 <header class="fsdg-hd"><h2>Fishing Spots</h2><p>Choose your next fishing spot</p><p class="fsdg-cnt"><b>${n} / ${FIDS.length}</b> species logged</p></header>
 <div class="fsdg-now" role="status">${FSDGPIN}<span>Currently fishing:</span><b>${FSLOCS[cur].n}</b></div>
 <div class="fstr"><span class="fsgold fsg">${fsCoin}<b id="fsgold">${P.gold.toLocaleString()}</b></span><button class="fsback fsg" id="fsback"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 5l-7 7 7 7" stroke="currentColor" stroke-width="2.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>Back <kbd>Esc</kbd></button></div>
 <div class="fsdg-scroll" id="fsdgsc"><div class="fsdg-cards" id="fsdgcards" role="group" aria-label="Fishing spots">${FSLOCK.map(fsdgCard).join('')}</div></div>
 <section class="fsdg-panel" id="fsdgpanel" aria-live="polite">${fsdgPanel()}</section></div>`,'fshx');
 S.back=()=>{FSDG.nav=null;back()};$('fsback').onclick=S.back;{const cn=$('cn');if(cn)cn.classList.add('dkhid')}
 const bd=$('fsdgbg');LIVE.push({cv:bd,fn:fsBackdrop(bd,'rgba(8,5,26,.66)'),slow:4});
 ov.querySelectorAll('.fsdg-card').forEach(b=>{const k=b.dataset.k,cv=b.querySelector('canvas'),g=cv.getContext('2d'),art=fsdgArt(k);
  LIVE.push({cv,fn:t=>{const tt=fsRM()?0:t;g.setTransform(1,0,0,1,0,0);g.drawImage(art,0,0);fsdgFx(g,k,738,800,tt)},slow:2});
  b.onclick=()=>fsdgSelect(k)});
 fsFitTM();fsdgFit();fsdgBindPanel();
 if(FSDG.kb)setTimeout(()=>{const c=ov.querySelector('.fsdg-card.sel');try{c&&c.focus({preventScroll:true})}catch(e){}},60)}
function fsdgSelect(k,focus){if(!FSLOCS[k]||S.view!=='fishmap')return;const same=FSDG.sel===k;FSDG.sel=k;
 ov.querySelectorAll('.fsdg-card').forEach(c=>{const on=c.dataset.k===k,s=fsdgState(c.dataset.k);c.classList.toggle('sel',on);c.setAttribute('aria-pressed',on);
  const r=c.querySelector('.fsdg-rib');if(!s.here){if(on&&!r)c.querySelector('.fsdg-shade').insertAdjacentHTML('afterend',`<span class="fsdg-rib sel">${FSDGSTAR}Selected</span>`);else if(!on&&r)r.remove()}});
 if(focus){const c=ov.querySelector(`.fsdg-card[data-k="${k}"]`);try{c&&c.focus({preventScroll:false})}catch(e){}}
 if(same)return;const p=$('fsdgpanel');if(!p)return;p.innerHTML=fsdgPanel();if(!fsRM()){p.classList.remove('swap');void p.offsetWidth;p.classList.add('swap')}fsdgBindPanel();try{beep(640,.03,'triangle',.08)}catch(e){}}
function fsdgBindPanel(){const k=FSDG.sel,th=$('fsdgth');if(th){const g=th.getContext('2d'),art=fsdgArt(k);g.clearRect(0,0,280,280);g.save();g.beginPath();g.arc(140,140,136,0,TAU);g.clip();g.drawImage(art,(738-560)/2,90,560,560,0,0,280,280);g.restore()}
 const b=$('fsdggo');if(b&&!b.disabled)b.onclick=()=>fsdgGo(k)}
/* the one action: travel (re-validated) and enter the pond; ignores repeated clicks */
function fsdgGo(k){if(FSDG.busy||S.view!=='fishmap')return;const s=fsdgState(k);if(!s.open)return;FSDG.busy=true;const b=$('fsdggo');if(b)b.disabled=true;
 if(!s.here&&!fsTravel(k)){FSDG.busy=false;if(b)b.disabled=false;return}FSDG.nav=null;setTimeout(()=>{try{fsPond()}finally{FSDG.busy=false}},90)}
/* touch mode moves #ov out of the scaled stage and zooms it to a ~1000px-wide box (touchLayout in 63_touch);
   the 1600x900 fishing screens are scaled to fit that box instead of spilling off-screen */
function fsFitTM(){const x=ov&&ov.classList.contains('fshx')?ov.querySelector(':scope>.fsx,:scope>div>.fsx')||$('fsx'):null;if(!x)return;
 if(typeof ovTM!=='undefined'&&ovTM){const w=ov.clientWidth,h=ov.clientHeight,s=Math.min(w/1600,h/900);x.style.transformOrigin='0 0';x.style.transform=`translate(${Math.round((w-1600*s)/2)}px,${Math.round((h-900*s)/2)}px) scale(${s})`}
 else if(x.style.transform){x.style.transform='';x.style.transformOrigin=''}}
{const s0=show;show=function(){const r=s0.apply(this,arguments);try{fsFitTM()}catch(e){}return r}}
{const a0=applyLayout;applyLayout=function(){const r=a0.apply(this,arguments);try{fsFitTM();if(S.view==='fishmap')fsdgFit()}catch(e){}return r}}
/* fit the layout to the stage's real on-screen size: 4 across, 2x2 or one column with larger type */
function fsdgFit(){const x=$('fsx');if(!x||!x.classList.contains('fsdg'))return;let k=1;try{k=x.getBoundingClientRect().width/1600||1}catch(e){}
 x.classList.toggle('fsdg-m',k<.62&&k>=.4);x.classList.toggle('fsdg-s',k<.4)}
addEventListener('resize',()=>{if(S.view==='fishmap')fsdgFit()});
/* remember whether the player is using the keyboard, so the menu only moves focus for keyboard players */
addEventListener('keydown',()=>{FSDG.kb=1},true);addEventListener('pointerdown',()=>{FSDG.kb=0},true);
/* keys: arrows move between cards (preview only), Enter/Space on a card previews it (native button), Esc is Back */
document.addEventListener('keydown',e=>{if(S.mode!=='fish'||S.view!=='fishmap'||e.ctrlKey||e.metaKey||e.altKey)return;const a=document.activeElement;
 if(e.key==='ArrowRight'||e.key==='ArrowLeft'||e.key==='ArrowDown'||e.key==='ArrowUp'){const i=FSLOCK.indexOf(FSDG.sel),d=e.key==='ArrowRight'||e.key==='ArrowDown'?1:-1;e.preventDefault();e.stopImmediatePropagation();fsdgSelect(FSLOCK[(i+d+FSLOCK.length)%FSLOCK.length],true);return}
 if((e.key===' '||e.key==='Enter')&&a&&a.classList&&(a.classList.contains('fsdg-card')||a.id==='fsdggo'||a.id==='fsback')){e.stopImmediatePropagation();return}},true);
{const st=document.createElement('style');st.textContent=`
.fsdg>canvas#fsdgbg{position:absolute;inset:0;width:1600px;height:900px}.fsdg-dim{position:absolute;inset:0;background:linear-gradient(180deg,#07041acc,#07041a66 30%,#07041a88 70%,#07041aee);pointer-events:none}
.fsdg-hd{position:absolute;left:40px;top:20px;animation:fsdgIn .3s ease-out backwards}.fsdg-hd h2{margin:0;font:400 68px/1 'Pirata One',Georgia,serif;color:#ffd45a;text-shadow:0 4px 0 #3a1a04,0 0 24px #ffb02a44}
.fsdg-hd p{margin:4px 0 0!important;font:500 20px var(--ui);color:#e8e0ff}.fsdg-hd .fsdg-cnt{margin-top:6px!important;font:600 19px var(--ui);color:#d8d0f4}.fsdg-cnt b{color:#fff;font-weight:800}
.fsdg-now{position:absolute;left:50%;top:92px;transform:translateX(-50%);display:flex;align-items:center;gap:14px;height:58px;padding:0 30px 0 22px;border-radius:18px;border:2px solid #5a4cb0;background:linear-gradient(180deg,#1e1a5aee,#120e3cf2);box-shadow:0 8px 20px #0007,inset 0 0 0 1px #ffffff10;white-space:nowrap;animation:fsdgIn .3s .05s ease-out backwards}
.fsdg-now svg{width:26px;height:26px;color:#5ad8ff}.fsdg-now span{font:500 19px var(--ui);color:#e8e0ff}.fsdg-now b{font:400 32px/1 'Pirata One',Georgia,serif;color:#9ff0ff;letter-spacing:.01em}
.fsdg-scroll{position:absolute;left:0;right:0;top:172px;height:548px;overflow:visible}
.fsdg-cards{position:absolute;left:32px;right:32px;top:0;bottom:0;display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.fsdg-card{position:relative;display:block;padding:0;margin:0;border-radius:22px;border:3px solid #4a3e90;background:#0e0a2c;overflow:hidden;cursor:pointer;text-align:center;color:#fff;font:inherit;box-shadow:0 14px 30px #000a;transition:transform .18s ease-out,border-color .2s ease-out;animation:fsdgCard .32s calc(var(--i)*55ms + 60ms) ease-out backwards}
.fsdg-card::after{content:'';position:absolute;inset:-3px;border-radius:22px;pointer-events:none;box-shadow:0 0 0 2px #ffd45a,0 0 34px #ffc23a66;opacity:0;transition:opacity .2s ease-out}
.fsdg-card:hover{transform:translateY(-4px);border-color:#7a6ad8}.fsdg-card.here{border-color:#5ad8ff}.fsdg-card.sel{border-color:#ffd45a}.fsdg-card.sel::after{opacity:1}
.fsdg-card:focus-visible{outline:3px solid #fff;outline-offset:4px}.fsdg-card:active{transform:translateY(-1px)}
.fsdg-art{position:absolute;left:0;top:0;width:100%;height:auto;aspect-ratio:738/800;transition:transform .35s ease-out,opacity .2s}.fsdg-card.sel .fsdg-art{transform:scale(1.03)}
.fsdg-card.lock .fsdg-art{opacity:.62}.fsdg-card.soon .fsdg-art{opacity:.84}
.fsdg-shade{position:absolute;left:0;right:0;top:0;bottom:0;background:linear-gradient(180deg,#0000 0%,#0000 52%,#0e0a2cb0 62%,#0e0a2cf0 68%,#0e0a2c 74%);pointer-events:none}
.fsdg-rib{position:absolute;left:50%;top:-3px;transform:translateX(-50%);display:flex;align-items:center;gap:8px;height:40px;padding:0 22px;border-radius:0 0 16px 16px;font:800 14.5px var(--ui);letter-spacing:.08em;text-transform:uppercase;white-space:nowrap;z-index:2}
.fsdg-rib svg{width:20px;height:20px}.fsdg-rib.cur{background:linear-gradient(180deg,#9ff0ff,#4ac8f0);color:#0a2a44;border:2px solid #1b1024;border-top:none}.fsdg-rib.cur svg{color:#0a2a44}
.fsdg-rib.sel{background:linear-gradient(180deg,#ffe27a,#f2b631);color:#3a2006;border:2px solid #1b1024;border-top:none}.fsdg-rib.sel svg{color:#3a2006}
.fsdg-ban{position:absolute;left:18px;right:18px;top:300px;display:flex;align-items:center;justify-content:center;gap:10px;height:50px;border-radius:14px;background:#0a0826d9;border:1.5px solid #ffffff26;font:700 19px var(--ui);color:#e8e8ff;z-index:1}
.fsdg-ban svg{width:24px;height:24px;color:#e8e8ff}.fsdg-ban.lk{color:#ffd8a8}.fsdg-ban.lk svg{color:#ffd8a8}
.fsdg-info{position:absolute;left:0;right:0;bottom:0;height:190px;display:flex;flex-direction:column;align-items:center;gap:6px;padding:0 20px 22px;justify-content:flex-end}
.fsdg-info b{font:400 44px/1 'Pirata One',Georgia,serif;color:#ffe08a;text-shadow:0 3px 0 #1b1024}.fsdg-card.soon .fsdg-info b,.fsdg-card.lock .fsdg-info b{color:#c8c4e8}
.fsdg-info small{font:500 15.5px/1.35 var(--ui);color:#e0daf8;max-width:300px}.fsdg-info em{margin-top:4px;font:700 18px var(--ui);font-style:normal;color:#fff}
.fsdg-sub{font:600 13px var(--ui);color:#c4badf}
.fsdg-bar{position:relative;display:block;width:82%;height:14px;border-radius:7px;background:#07041a;border:1.5px solid #ffffff22;overflow:hidden}.fsdg-bar>i{display:block;height:100%;border-radius:7px;background:linear-gradient(90deg,color-mix(in srgb,var(--lc) 75%,#fff),var(--lc))}
.fsdg-bar.lk>i{background:linear-gradient(90deg,#8a84b8,#c8c4e8)}
.fsdg-panel{position:absolute;left:32px;right:32px;top:740px;height:144px;border-radius:24px;border:2px solid #5a4cb0;background:linear-gradient(180deg,#221a5af2,#140e3cf6);box-shadow:0 12px 30px #0009,inset 0 0 0 1px #ffffff0c;animation:fsdgIn .3s .2s ease-out backwards}
.fsdg-pin2{position:absolute;inset:0;display:grid;grid-template-columns:132px 1fr auto;align-items:center;gap:26px;padding:0 30px 0 22px}
.fsdg-panel.swap .fsdg-pin2{animation:fsdgSwap .22s ease-out}
.fsdg-pin2 canvas{width:118px;height:118px;border-radius:50%;border:4px solid color-mix(in srgb,var(--lc) 70%,#1b1024);box-shadow:0 0 0 3px #1b1024,0 0 24px color-mix(in srgb,var(--lc) 35%,transparent)}
.fsdg-ptx{min-width:0;display:flex;flex-direction:column;gap:4px}.fsdg-ptx h3{margin:0;display:flex;align-items:center;gap:14px;font:400 42px/1 'Pirata One',Georgia,serif;color:#ffd45a}
.fsdg-tag{display:inline-flex;align-items:center;gap:6px;height:28px;padding:0 12px;border-radius:14px;background:#5ad8ff26;border:1.5px solid #5ad8ff;color:#9ff0ff;font:800 12.5px var(--ui);letter-spacing:.06em;text-transform:uppercase}.fsdg-tag svg{width:15px;height:15px}
.fsdg-ptx p{margin:0!important;font:500 17px var(--ui);color:#e0daf8}.fsdg-ptx .fsdg-pst{font-weight:600;color:#ffd8a8}.fsdg-pst b{color:#fff}
.fsdg-prow{display:flex;align-items:center;gap:22px;margin-top:4px}.fsdg-prow span{font:700 18px var(--ui);color:#fff;white-space:nowrap}.fsdg-prow .fsdg-bar{width:480px;flex:none}
.fsdg-go{display:flex;align-items:center;justify-content:center;gap:10px;min-width:300px;height:80px;padding:0 34px;border-radius:20px;border:3px solid #1b1024;background:linear-gradient(180deg,#ffe27a,#f2b631);color:#3a2006;font:800 28px var(--ui);box-shadow:0 6px 0 #9a6a10,0 12px 24px #0008;cursor:pointer;transition:transform .12s ease-out}
.fsdg-go span{font-size:32px;line-height:1}.fsdg-go:hover:not(:disabled){transform:translateY(-2px)}.fsdg-go:active:not(:disabled){transform:translateY(3px);box-shadow:0 2px 0 #9a6a10,0 6px 14px #0008}
.fsdg-go:focus-visible{outline:3px solid #fff;outline-offset:4px}.fsdg-go:disabled{background:#2e2860;color:#b8b0e0;box-shadow:0 6px 0 #1b1440;cursor:not-allowed}.fsdg-go svg{width:26px;height:26px}
@keyframes fsdgIn{from{opacity:0;transform:translateY(8px)}}@keyframes fsdgCard{from{opacity:0;transform:translateY(14px)}}@keyframes fsdgSwap{from{opacity:.25}}
.fsdg-now{animation-name:fsdgNow}@keyframes fsdgNow{from{opacity:0;transform:translate(-50%,8px)}}
/* medium: the stage is shown small, so 2x2 cards with larger type in a scroll area above the panel */
.fsdg-m .fsdg-hd h2{font-size:76px}.fsdg-m .fsdg-hd p{font-size:25px}.fsdg-m .fsdg-hd .fsdg-cnt{font-size:23px}
.fsdg-m .fsdg-now{left:auto;right:430px;top:30px;transform:none;height:70px}.fsdg-m .fsdg-now span{font-size:24px}.fsdg-m .fsdg-now b{font-size:38px}.fsdg-m .fsdg-now{animation-name:fsdgIn}
.fsdg-s .fsdg-scroll{top:150px;height:540px;}.fsdg-m .fsdg-scroll{top:184px;height:506px}.fsdg-m .fsdg-scroll,.fsdg-s .fsdg-scroll{overflow-y:auto;overflow-x:hidden;scrollbar-width:thin;scrollbar-color:#5a4cb0 transparent}
.fsdg-m .fsdg-cards{position:relative;left:auto;right:auto;margin:6px 32px 24px;grid-template-columns:1fr 1fr;grid-auto-rows:476px;gap:28px}.fsdg-m .fsdg-art{height:100%;object-fit:cover;aspect-ratio:auto}.fsdg-m .fsdg-shade{background:linear-gradient(180deg,#0000 0%,#0000 38%,#0e0a2cd0 52%,#0e0a2c 60%)}
.fsdg-m .fsdg-info{height:220px;gap:8px}.fsdg-m .fsdg-info b{font-size:58px}.fsdg-m .fsdg-info small{font-size:22px;max-width:600px}.fsdg-m .fsdg-info em{font-size:26px}.fsdg-m .fsdg-bar{height:20px}.fsdg-m .fsdg-rib{height:52px;font-size:20px}.fsdg-m .fsdg-ban{top:180px;height:64px;font-size:26px}
.fsdg-m .fsdg-panel,.fsdg-s .fsdg-panel{top:700px;height:186px}.fsdg-m .fsdg-ptx h3,.fsdg-s .fsdg-ptx h3{font-size:56px}.fsdg-m .fsdg-ptx p,.fsdg-s .fsdg-ptx p{font-size:23px}.fsdg-m .fsdg-prow span,.fsdg-s .fsdg-prow span{font-size:24px}.fsdg-m .fsdg-prow .fsdg-bar,.fsdg-s .fsdg-prow .fsdg-bar{width:380px;height:20px}
.fsdg-m .fsdg-go,.fsdg-s .fsdg-go{height:110px;min-width:380px;font-size:38px}.fsdg-m .fsdg-pin2 canvas,.fsdg-s .fsdg-pin2 canvas{width:150px;height:150px}.fsdg-m .fsdg-pin2,.fsdg-s .fsdg-pin2{grid-template-columns:164px 1fr auto}
/* small: one card per row, art beside the text, very large type */
.fsdg-s .fsdg-hd h2{font-size:92px}.fsdg-s .fsdg-hd p{display:none}.fsdg-s .fsdg-now{left:auto;right:430px;top:26px;transform:none;height:84px;animation-name:fsdgIn}.fsdg-s .fsdg-now span{display:none}.fsdg-s .fsdg-now b{font-size:46px}.fsdg-s .fsdg-now svg{width:34px;height:34px}
.fsdg-s .fsdg-cards{position:relative;left:auto;right:auto;margin:6px 32px 24px;grid-template-columns:1fr;grid-auto-rows:400px;gap:26px}
.fsdg-s .fsdg-art{width:46%;height:100%;object-fit:cover;aspect-ratio:auto}.fsdg-s .fsdg-shade{background:linear-gradient(90deg,#0000 0%,#0000 36%,#0e0a2c 50%)}
.fsdg-s .fsdg-info{left:46%;top:0;height:auto;justify-content:center;align-items:flex-start;text-align:left;padding:0 36px 0 20px;gap:12px}.fsdg-s .fsdg-info b{font-size:68px}.fsdg-s .fsdg-info small{font-size:28px;max-width:none}.fsdg-s .fsdg-info em{font-size:32px}.fsdg-s .fsdg-bar{width:100%;height:24px}.fsdg-s .fsdg-sub{font-size:22px}
.fsdg-s .fsdg-rib{left:23%;height:58px;font-size:22px}.fsdg-s .fsdg-ban{left:20px;right:auto;width:40%;top:auto;bottom:24px;height:70px;font-size:28px}
.fsdg-s .fsdg-ptx p:not(.fsdg-pst){display:none}
@media (prefers-reduced-motion:reduce){.fsdg *{animation:none!important;transition:none!important}}`;document.head.appendChild(st)}
