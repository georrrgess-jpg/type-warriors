/* ===== SIGNATURE WEAPONS: one per hero path =====
   Knight: Dawnbreaker (a sun-forged greatsword with a winged sunburst guard). Archer: Verdant Tempest (a living bow
   that sprouts leaves, with a wind-green string). Mage: Astral Conduit (a starwood staff holding a floating crystal
   inside two orbiting rune rings). Rogue: Nightwhisper (an obsidian kris with a glowing violet edge that trails smoke).
   They stay out of crates and the shop (hw:1). Each one appears at the top of its path's Armory list with a Forge
   button (15,000 gold), and is forged for free after 3 boss finishers with that path (counted in P.sigf).
   Art follows the weapon frame: grip at the origin, tip toward +x, L = 70 on the hero (84 in icons). */
const SIGW={knight:'sig_dawn',archer:'sig_tempest',mage:'sig_conduit',rogue:'sig_night'},SIG_COST=15000,SIG_FIN=3;
Object.assign(WP,{
 sig_dawn:{n:'Dawnbreaker',r:'Legendary',d:'Signature: +30% score, fury +30%, enemies 10% slower',sc:1.3,fu:1.3,sl:.9,w:1,t:'sword',c:'#ffd45a',col:'#ffd45a',p:'knight',hw:1,sig:1},
 sig_tempest:{n:'Verdant Tempest',r:'Legendary',d:'Signature: +25% score, fury +40%, faster combos',sc:1.25,fu:1.4,cq:1,w:1,t:'bow',c:'#4ab85a',col:'#7aff8a',p:'archer',hw:1,sig:1},
 sig_conduit:{n:'Astral Conduit',r:'Legendary',d:'Signature: +30% score, fury +25%, enemies 10% slower',sc:1.3,fu:1.25,sl:.9,w:1,t:'staff',c:'#6ad8ff',col:'#6ad8ff',p:'mage',hw:1,sig:1},
 sig_night:{n:'Nightwhisper',r:'Legendary',d:'Signature: +25% score, fury +30%, faster combos',sc:1.25,fu:1.3,cq:1,w:1,t:'dagger',c:'#c47aff',col:'#c47aff',p:'rogue',hw:1,sig:1}});
const sgO='#1a1026';
function sgGlow(g,x,y,r,c,a){if(r<=0||a<=0)return;g.save();g.globalCompositeOperation='lighter';const q=g.createRadialGradient(x,y,0,x,y,r);q.addColorStop(0,c+Math.round(Math.min(1,a)*255).toString(16).padStart(2,'0'));q.addColorStop(1,c+'00');g.fillStyle=q;g.beginPath();g.arc(x,y,r,0,TAU);g.fill();g.restore()}
function sgStar(g,x,y,r,c,a){g.save();g.globalAlpha=a;g.fillStyle=c;g.beginPath();g.moveTo(x,y-r);g.quadraticCurveTo(x+r*.16,y-r*.16,x+r,y);g.quadraticCurveTo(x+r*.16,y+r*.16,x,y+r);g.quadraticCurveTo(x-r*.16,y+r*.16,x-r,y);g.quadraticCurveTo(x-r*.16,y-r*.16,x,y-r);g.fill();g.restore()}
function sgPoly(g,p,f,lw){g.beginPath();g.moveTo(p[0],p[1]);for(let i=2;i<p.length;i+=2)g.lineTo(p[i],p[i+1]);g.closePath();g.fillStyle=f;g.fill();if(lw!==0){g.lineWidth=lw||1.4;g.strokeStyle=sgO;g.stroke()}}
const sgLin=(g,x0,y0,x1,y1,cs)=>{const q=g.createLinearGradient(x0,y0,x1,y1);cs.forEach((c,i)=>q.addColorStop(i/(cs.length-1),c));return q};
/* ---------- Dawnbreaker ---------- */
WNEW.sig_dawn=(g,L,t)=>{g.shadowBlur=0;const tip=L*1.2,b0=L*.1,hw=L*.074;
 sgGlow(g,L*.62,0,L*.62,'#ffc24a',.18+.06*Math.sin(t*2));
 /* blade */
 const bl=[b0,-hw,L*.62,-hw*1.12,L*.98,-hw*.8,tip,0,L*.98,hw*.8,L*.62,hw*1.12,b0,hw];sgPoly(g,bl,sgLin(g,0,-hw,0,hw,['#fffdf4','#f4e6b8','#c8a060']),1.5);
 g.save();g.beginPath();g.moveTo(bl[0],bl[1]);for(let i=2;i<bl.length;i+=2)g.lineTo(bl[i],bl[i+1]);g.closePath();g.clip();
 g.fillStyle='#ffffff90';g.beginPath();g.moveTo(b0,-hw);g.lineTo(L*.62,-hw*1.12);g.lineTo(L*.98,-hw*.8);g.lineTo(tip,0);g.lineTo(L*.98,-hw*.3);g.lineTo(L*.62,-hw*.45);g.lineTo(b0,-hw*.4);g.fill();
 /* fuller with glowing runes and a travelling glint */
 g.strokeStyle='#b88a2a';g.lineWidth=hw*.55;g.beginPath();g.moveTo(b0+3,0);g.lineTo(L*.9,0);g.stroke();g.strokeStyle='#ffe27a';g.lineWidth=hw*.28;g.beginPath();g.moveTo(b0+3,0);g.lineTo(L*.9,0);g.stroke();
 for(let i=0;i<6;i++){const x=L*(.22+i*.12),a=.55+.45*Math.sin(t*3-i*.9);g.fillStyle=`rgba(255,250,220,${a})`;g.beginPath();g.moveTo(x-2.4,0);g.lineTo(x,-2.2);g.lineTo(x+2.4,0);g.lineTo(x,2.2);g.closePath();g.fill()}
 const gx=b0+((t*.55)%1)*(tip-b0);const q=g.createLinearGradient(gx-14,0,gx+14,0);q.addColorStop(0,'#ffffff00');q.addColorStop(.5,'#ffffffcc');q.addColorStop(1,'#ffffff00');g.fillStyle=q;g.fillRect(gx-14,-hw*1.3,28,hw*2.6);g.restore();
 /* grip and pommel */
 wrapG(g,-L*.27,-L*.02,0,L*.046,'#6a2a14');
 g.beginPath();g.arc(-L*.31,0,L*.068,0,TAU);g.fillStyle=sgLin(g,0,-L*.07,0,L*.07,['#fff2b0','#e6b93e','#8a5a10']);g.fill();g.lineWidth=1.4;g.strokeStyle=sgO;g.stroke();g.beginPath();g.arc(-L*.31,0,L*.034,0,TAU);g.fillStyle='#ff6a2a';g.fill();g.fillStyle='#fff8';g.beginPath();g.arc(-L*.32,-L*.012,L*.011,0,TAU);g.fill();
 /* winged sunburst guard */
 for(const s of[-1,1]){const w=[L*.02,s*L*.04,L*.07,s*L*.1,L*.04,s*L*.18,-L*.02,s*L*.26,L*.0,s*L*.16,-L*.05,s*L*.12,-L*.02,s*L*.05];sgPoly(g,w,sgLin(g,0,0,0,s*L*.26,['#fff2b0','#e6b93e','#a8701a']),1.3);
  g.strokeStyle='#8a5a10';g.lineWidth=1;g.beginPath();g.moveTo(L*.01,s*L*.07);g.lineTo(-L*.01,s*L*.2);g.stroke()}
 g.save();g.translate(L*.03,0);g.rotate(t*.6);for(let i=0;i<8;i++){g.rotate(TAU/8);g.fillStyle=i%2?'#ffe27a':'#fff6d0';g.beginPath();g.moveTo(L*.05,-2.2);g.lineTo(L*.115,0);g.lineTo(L*.05,2.2);g.fill()}g.restore();
 g.beginPath();g.arc(L*.03,0,L*.06,0,TAU);g.fillStyle=sgLin(g,0,-L*.06,0,L*.06,['#fff6d0','#ffb22a','#c8701a']);g.fill();g.lineWidth=1.4;g.strokeStyle=sgO;g.stroke();g.beginPath();g.arc(L*.03,0,L*.028,0,TAU);g.fillStyle='#e8364e';g.fill();g.fillStyle='#fff9';g.beginPath();g.arc(L*.022,-L*.01,L*.009,0,TAU);g.fill();
 sgStar(g,tip-L*.04+Math.sin(t*2)*2,-hw*1.6,3+2*Math.abs(Math.sin(t*2.6)),'#fff6d0',.9)};
/* ---------- Verdant Tempest ---------- */
WNEW.sig_tempest=(g,L,t,X)=>{g.shadowBlur=0;wBow(g,L,t,{c:'#3e8a3a',lw:3.4,grip:'#5a3418',str:'#d8ffc0',sw:1.2,nock:'#7aff8a',head:'#eaffe0',
 back:(g,G,h,bw)=>{sgGlow(g,0,bw*.3,L*.5,'#5aff7a',.16+.06*Math.sin(t*2));g.save();g.globalCompositeOperation='lighter';g.strokeStyle='#8aff9a55';g.lineWidth=1.6;for(let i=0;i<3;i++){const r=L*(.18+i*.08),a0=t*1.5+i*2;g.beginPath();g.arc(-bw*.2,bw*.3,r,a0,a0+1.6);g.stroke()}g.restore()},
 limb:(g,G,h,bw,gy)=>{for(const s of[-1,1]){for(let i=0;i<5;i++){const u=.18+i*.16,p=G.at(u,s),sw=Math.sin(t*2.4+i+s)*.18,a=Math.atan2(p.ny,p.nx)+sw+(i%2?.5:-.5),len=L*(.075+(i%2)*.02);
    g.save();g.translate(p.x,p.y);g.rotate(a);g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(len*.4,-len*.32,len,0);g.quadraticCurveTo(len*.4,len*.32,0,0);g.fillStyle=i%2?'#6ad85a':'#9aff6a';g.fill();g.lineWidth=1;g.strokeStyle=sgO;g.stroke();g.strokeStyle='#2a7a2a';g.lineWidth=.7;g.beginPath();g.moveTo(len*.1,0);g.lineTo(len*.85,0);g.stroke();g.restore()}
   const tp=G.at(.02,s);sgGlow(g,tp.x,tp.y,7,'#aaff8a',.6);g.beginPath();g.arc(tp.x,tp.y,2.4,0,TAU);g.fillStyle='#eaffd8';g.fill()}
  /* emerald set in the grip */
  g.beginPath();g.moveTo(-3.4,gy-7);g.lineTo(0,gy-11);g.lineTo(3.4,gy-7);g.lineTo(0,gy-3);g.closePath();g.fillStyle=sgLin(g,0,gy-11,0,gy-3,['#d8ffe0','#2adf6a','#0a7a3a']);g.fill();g.lineWidth=1;g.strokeStyle=sgO;g.stroke();sgGlow(g,0,gy-7,10,'#5aff8a',.4+.2*Math.sin(t*3))}})};
/* ---------- Astral Conduit ---------- */
WNEW.sig_conduit=(g,L,t)=>{g.shadowBlur=0;const x0=-L*.36,x1=L*1.0,hx=L*1.17;
 /* shaft: twisted starwood with silver bands */
 g.lineCap='round';g.strokeStyle=sgO;g.lineWidth=7.4;g.beginPath();g.moveTo(x0,0);g.lineTo(x1,0);g.stroke();g.strokeStyle=sgLin(g,0,-3,0,3,['#5a4a9a','#2a1e5a']);g.lineWidth=5;g.beginPath();g.moveTo(x0,0);g.lineTo(x1,0);g.stroke();
 g.strokeStyle='#8a7ad8';g.lineWidth=1.2;for(let x=x0+4;x<x1-4;x+=7){g.beginPath();g.moveTo(x,-2.4);g.lineTo(x+4,2.4);g.stroke()}
 for(const x of[x0+3,-L*.02,L*.4,x1-6]){g.fillStyle=sgLin(g,0,-4,0,4,['#ffffff','#b8c0d8','#6a708a']);g.fillRect(x-2.2,-4.2,4.4,8.4);g.lineWidth=1;g.strokeStyle=sgO;g.strokeRect(x-2.2,-4.2,4.4,8.4)}
 /* two slim silver prongs cradle the crystal */
 for(const sd of[-1,1]){g.beginPath();g.moveTo(x1-4,sd*2);g.quadraticCurveTo(x1+L*.02,sd*L*.2,hx+L*.03,sd*L*.21);g.strokeStyle=sgO;g.lineWidth=5.2;g.stroke();g.strokeStyle=sgLin(g,x1,-L*.2,x1,L*.2,['#f4f6ff','#a8b0d0','#5a6080']);g.lineWidth=3;g.stroke();g.beginPath();g.arc(hx+L*.03,sd*L*.21,2.6,0,TAU);g.fillStyle='#e8fbff';g.fill();g.lineWidth=1;g.strokeStyle=sgO;g.stroke()}
 /* the floating crystal */
 const bob=Math.sin(t*2)*1.6,cx=hx,cy=bob;sgGlow(g,cx,cy,L*.36,'#4ab8ff',.32+.1*Math.sin(t*3));
 const cr=[cx-L*.11,cy,cx,cy-L*.19,cx+L*.11,cy,cx,cy+L*.19];sgPoly(g,cr,sgLin(g,cx,cy-L*.15,cx,cy+L*.15,['#f0fcff','#6ad8ff','#2a6aff']),1.4);
 g.fillStyle='#ffffffb0';g.beginPath();g.moveTo(cx-L*.08,cy);g.lineTo(cx,cy-L*.15);g.lineTo(cx-L*.01,cy);g.closePath();g.fill();
 /* two orbiting rune rings */
 for(const [rx,ry,sp,c] of [[L*.17,L*.06,1.4,'#9ff0ff'],[L*.06,L*.19,-1.1,'#c8b8ff']]){g.save();g.translate(cx,cy);g.rotate(t*sp*.3);g.strokeStyle=c;g.lineWidth=1.3;g.globalAlpha=.85;g.beginPath();g.ellipse(0,0,rx,ry,0,0,TAU);g.stroke();
  for(let i=0;i<4;i++){const a=t*sp+i*TAU/4;g.fillStyle='#ffffff';g.fillRect(Math.cos(a)*rx-1.3,Math.sin(a)*ry-1.3,2.6,2.6)}g.restore()}
 for(let i=0;i<3;i++){const a=t*1.8+i*2.1;sgStar(g,cx+Math.cos(a)*L*.24,cy+Math.sin(a)*L*.12,2+1.6*Math.abs(Math.sin(t*3+i)),'#e8fbff',.9)}};
/* ---------- Nightwhisper ---------- */
WNEW.sig_night=(g,L,t)=>{g.shadowBlur=0;const b0=L*.09,len=L*.56,hw=L*.07;
 /* smoke wisps along the blade */
 g.save();g.globalCompositeOperation='lighter';for(let i=0;i<5;i++){const u=((t*.5+i*.2)%1),x=b0+len*(.2+u*.75),y=-hw*1.4-u*L*.12+Math.sin(t*3+i)*2;g.fillStyle=`rgba(170,110,255,${(1-u)*.22})`;g.beginPath();g.arc(x,y,2+u*5,0,TAU);g.fill()}g.restore();
 sgGlow(g,b0+len*.5,0,L*.36,'#a85aff',.18+.08*Math.sin(t*2.6));
 /* wavy kris blade */
 const P=[];const N=10;for(let i=0;i<=N;i++){const u=i/N,x=b0+u*len,w=hw*(1-u*.88),wav=Math.sin(u*Math.PI*3)*hw*.35;P.push([x,-w+wav])}const Q=[];for(let i=N;i>=0;i--){const u=i/N,x=b0+u*len,w=hw*(1-u*.88),wav=Math.sin(u*Math.PI*3)*hw*.35;Q.push([x,w+wav])}
 const pts=[...P,[b0+len+L*.05,Math.sin(Math.PI*3)*hw*.35],...Q];g.beginPath();g.moveTo(pts[0][0],pts[0][1]);for(const p of pts)g.lineTo(p[0],p[1]);g.closePath();g.fillStyle=sgLin(g,0,-hw,0,hw,['#4a3a6a','#1e1636','#0e0a1e']);g.fill();g.lineWidth=1.4;g.strokeStyle=sgO;g.stroke();
 /* glowing violet edge */
 g.save();g.globalCompositeOperation='lighter';g.strokeStyle='#d8a8ff';g.lineWidth=1.6;g.globalAlpha=.75+.25*Math.sin(t*4);g.beginPath();P.forEach((p,i)=>i?g.lineTo(p[0],p[1]+.8):g.moveTo(p[0],p[1]+.8));g.lineTo(b0+len+L*.05,Math.sin(Math.PI*3)*hw*.35);g.stroke();g.restore();
 g.fillStyle='#ffffff30';g.beginPath();g.moveTo(b0,-hw*.6);for(let i=1;i<=N;i++){const u=i/N;g.lineTo(b0+u*len,(-hw*(1-u*.88)+Math.sin(u*Math.PI*3)*hw*.35)*.4)}g.lineTo(b0,0);g.closePath();g.fill();
 /* grip and crescent pommel */
 wrapG(g,-L*.2,-L*.01,0,L*.042,'#2a1a40');
 g.beginPath();g.arc(-L*.235,0,L*.06,Math.PI*.35,Math.PI*1.65);g.arc(-L*.205,0,L*.045,Math.PI*1.6,Math.PI*.4,true);g.closePath();g.fillStyle=sgLin(g,0,-L*.06,0,L*.06,['#e8e0ff','#9a90c0','#4a4068']);g.fill();g.lineWidth=1.2;g.strokeStyle=sgO;g.stroke();
 /* thorned guard with an amethyst */
 for(const s of[-1,1])sgPoly(g,[L*.01,s*L*.03,L*.06,s*L*.06,L*.03,s*L*.15,L*.0,s*L*.1,-L*.03,s*L*.12,-L*.01,s*L*.04],sgLin(g,0,0,0,s*L*.15,['#cfc8e8','#7a7098','#3a3458']),1.2);
 g.beginPath();g.ellipse(L*.025,0,L*.034,L*.042,0,0,TAU);g.fillStyle=sgLin(g,0,-L*.04,0,L*.04,['#f0d8ff','#b46aff','#5a1aa8']);g.fill();g.lineWidth=1.2;g.strokeStyle=sgO;g.stroke();sgGlow(g,L*.025,0,L*.08,'#c47aff',.4+.2*Math.sin(t*3));
 sgStar(g,b0+len*.8+Math.sin(t*2)*3,-hw*1.2,2+1.5*Math.abs(Math.sin(t*3.3)),'#f0e0ff',.85)};
/* ---------- earning them ---------- */
function sigCount(p){return (P.sigf&&P.sigf[p])||0}
function sigGrant(p,why){const id=SIGW[p];if(!id||P.own[id])return false;P.own[id]=1;save();return true}
/* count boss finishers per path (called by the finisher in 91_path_fx) and forge the weapon on the third */
{const k0=kill;kill=function(e,force){const was=!!(e&&e.boss&&S.en.includes(e)),r=k0.apply(this,arguments);
  try{if(was&&force&&S.mode==='play'&&!S.en.includes(e)&&S.pose==='victory'){const p=PATHS[P.path]?P.path:'knight';P.sigf=P.sigf||{};P.sigf[p]=(P.sigf[p]||0)+1;
   if(P.sigf[p]>=SIG_FIN&&sigGrant(p,'fin'))float(W/2,450,`${WP[SIGW[p]].n} forged! Find it in the Armory.`,PFXC[p]||'#ffd45a',34);else if(!P.own[SIGW[p]])float(W/2,450,`Finishers ${Math.min(SIG_FIN,P.sigf[p])}/${SIG_FIN} toward ${WP[SIGW[p]].n}`,'#e8e0ff',28);save()}}catch(x){}return r}}
/* the Forge card at the top of the Armory's weapon list */
{const a0=armory;armory=function(tab){const r=a0.apply(this,arguments);try{sigCard()}catch(e){console.error(e)}return r}}
function sigCard(){const tb=armory.tab||'Weapons';if(tb==='Armor')return;const p=P.path,id=SIGW[p];if(!id||P.own[id])return;const grid=ov.querySelector('.argrid');if(!grid||grid.querySelector('.sigf'))return;
 const w=WP[id],n=sigCount(p),can=P.gold>=SIG_COST;const b=document.createElement('button');b.className='ac2 sigf leg';b.style.setProperty('--c',w.col);b.title=w.d;
 b.innerHTML=`<canvas width="236" height="150"></canvas><span class="wn${w.n.length>13?' lg':''}">${esc(w.n)}</span><small>Signature · or ${SIG_FIN} boss finishers (${Math.min(n,SIG_FIN)}/${SIG_FIN})</small><span class="sigbtn${can?'':' off'}">Forge · ${SIG_COST.toLocaleString()}</span>`;
 grid.insertBefore(b,grid.firstChild);const cv=b.querySelector('canvas');LIVE.push({cv,fn:t=>{try{art(cv,'w',id,t)}catch(e){}},slow:2});
 b.onclick=e=>{e.stopPropagation();if(P.gold<SIG_COST){const s=b.querySelector('.sigbtn');s.textContent=`Need ${(SIG_COST-P.gold).toLocaleString()} more gold`;setTimeout(()=>{if(s.isConnected)s.textContent=`Forge · ${SIG_COST.toLocaleString()}`},1800);try{beep(180,.08,'sawtooth',.3)}catch(x){}return}
  P.gold-=SIG_COST;sigGrant(p,'gold');try{setWeapon(id)}catch(x){P.weapon=id}save();try{beep(784,.08,'triangle',.4);beep(1047,.1,'triangle',.4);beep(1568,.16,'triangle',.4)}catch(x){}armory()}}
{const st=document.createElement('style');st.textContent=`
.ac2.sigf{position:relative;outline:2px dashed color-mix(in srgb,var(--c) 70%,transparent);outline-offset:-6px}
.ac2.sigf .sigbtn{display:block;margin:6px auto 0;padding:4px 12px;border-radius:10px;background:linear-gradient(180deg,#ffe27a,#f2b631);color:#3a2006;font:800 13px var(--ui,Poppins),sans-serif;box-shadow:0 3px 0 #9a6a10;width:max-content}
.ac2.sigf .sigbtn.off{filter:grayscale(.6);opacity:.75}.ac2.sigf .sigfin{display:block;margin-top:4px;font:600 11px var(--ui,Poppins),sans-serif;color:#d8d0f4;opacity:.85}`;document.head.appendChild(st)}
/* How to play */
try{HELP.Bosses.push(['Finishers','Finish a beaten boss with Space and your path plays its finisher: the Knight\'s Final Verdict slam, the Archer\'s Verdant Volley, the Mage\'s Arcane Beam or the Rogue\'s Shadow Flurry. Finish within 2 seconds for a Swift finish gold bonus. Fury Strike uses the same attacks.']);HELP.Progress.push(['Signature weapons','Each path has a signature weapon: Dawnbreaker, Verdant Tempest, Astral Conduit and Nightwhisper. Forge one in the Armory for 15,000 gold, or land 3 boss finishers with that path to forge it for free.'])}catch(e){}
