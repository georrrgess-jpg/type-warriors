/* ===== 9.4 THE CROOKED CUE: first-time tips (96p) =====
   Small coach-mark cards, shown once each (P.pz.tut), never blocking: aim and power, spin, ball in hand, calling the 8. */
const PZ_TIPS_TXT={
 aim:['AIM AND SHOOT','<b>Move the mouse</b> to aim. <b>Pull back</b> from the table (or use the power bar) to set the power, then <b>let go</b> to shoot.'],
 spin:['ADD SPIN','Click the <b>cue-ball diagram</b> bottom left: top = follow, bottom = draw (backspin), sides = english. Double-click to reset.'],
 bih:['BALL IN HAND','Your opponent fouled. <b>Click anywhere</b> on the table to place the cue ball, then aim as usual.'],
 call8:['CALL THE 8','Only the 8 is left. <b>Click a pocket</b> (or press 1-6) to call it, then sink the 8 there to win the rack.']};
function pzTip(key,ms){const Z=PZS();if(Z.tut[key]||!PZ.on||!$('pzm')||(PZ.M&&PZ.M.trick&&key!=='aim'))return;if($('pztaunt')&&!$('pztaunt').hidden)return;
 const t=PZ_TIPS_TXT[key];if(!t)return;Z.tut[key]=1;save();let el=$('pztip');if(!el){el=document.createElement('div');el.id='pztip';el.className='pztipc';$('pzm').appendChild(el)}
 const tok=PZ.tok;el.innerHTML=`<small>TIP · ${t[0]}</small><p>${t[1]}</p>`;el.classList.remove('on');void el.offsetWidth;el.classList.add('on');PZ.tipKey=key;clearTimeout(PZ.tipT);PZ.tipT=setTimeout(()=>{if(PZ.tok===tok)pzTipHide()},ms||9000)}
function pzTipHide(){const el=$('pztip');if(el)el.classList.remove('on');PZ.tipKey=null;clearTimeout(PZ.tipT)}
function pzTipsTurn(){if(!PZ.on||PZ.ph!=='aim'||!PZ.st||PZ.st.turn!==0)return;const st=PZ.st,Z=PZS();
 if(st.bih&&PZ.mode==='place'){if(!st.brk)pzTip('bih');return}
 if(pzrOn8(st)){pzTip('call8');return}
 if(!Z.tut.aim){pzTip('aim',12000);return}
 if(!Z.tut.spin&&(PZ.M&&PZ.M.rack>=1)&&(st.shots||0)>=2)pzTip('spin',9000)}
{const f0=pzBeginTurn;pzBeginTurn=function(){const r=f0.apply(this,arguments);try{if(!(PZ.M&&PZ.M.trick&&PZ.M.trick.n>0))pzTipsTurn()}catch(e){}return r}}
{const f0=pzFireHuman;pzFireHuman=function(){try{pzTipHide()}catch(e){}return f0.apply(this,arguments)}}
{const f0=pzPlaceCue;pzPlaceCue=function(){try{if(PZ.tipKey==='bih')pzTipHide()}catch(e){}return f0.apply(this,arguments)}}
