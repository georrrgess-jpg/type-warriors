# python3 t_potui103.py [game.html] : 10.3b, the potion belt and the Witch's Cauldron never overlap or poke out of other boxes.
# On all ten maps at 1600x900, 1280x720 and 1024x640, in many states (build phase, a wave with three buffs and the shared cooldown,
# aiming a throw, each bottle's tooltip, Rune Typing words, a tower's info panel, the Sort menu, a first-time tip, a combo, a wave
# called early), it checks: the HUD overlap audit (tools/td/rpu_ovl.js); no box of the belt / buff chips / tooltip touches a box
# outside it; every part of the belt stays inside the belt and on the stage; the belt covers no build pad or tower; and the Witch's
# Cauldron screen and the hub button the same way. Screenshots in shots/w103b_pot/.
import asyncio,json,os,re,sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__));TD=os.path.join(HERE,'..','tools','td')
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 and not sys.argv[1].startswith('-') else os.path.join(HERE,'out.html'))
SHOTS=os.path.join(HERE,'shots','w103b_pot');os.makedirs(SHOTS,exist_ok=True)
OVL=open(os.path.join(TD,'rpu_ovl.js')).read()
SRC=open(os.path.join(HERE,'t_pot103.py')).read()
SETUP=re.search(r'^SETUP="(.*)"$',SRC,re.M).group(1).encode().decode('unicode_escape') if False else re.search(r'^SETUP="(.*)"$',SRC,re.M).group(1)
ALL=re.search(r'^ALL="(.*)"$',SRC,re.M).group(1)
HELP=re.search(r'^HELP=r"""(.*?)"""',SRC,re.M|re.S).group(1)
MAPS=['moss','frost','ember','coral','wreck','abyss','meadow','foundry','storm','wonder']
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+json.dumps(info)[:1500]),flush=True)
    if not ok:FAIL.append(name)
# the belt audit, run in the page: returns a list of problems in the current state
AUDIT=r"""(tag)=>{const out=[];const h=document.getElementById('rphud'),pb=document.getElementById('rpptb');if(!h)return['no hud'];
 const vis=e=>{for(let x=e;x&&x!==document.body;x=x.parentElement){const c=getComputedStyle(x);if(c.display==='none'||c.visibility==='hidden'||+c.opacity<0.05||x.hidden)return false}const r=e.getBoundingClientRect();return r.width>1&&r.height>1};
 const W=document.getElementById('wrap').getBoundingClientRect(),cv=document.querySelector('canvas').getBoundingClientRect(),k=cv.width/1600;
 const hit=(a,b,m)=>a.left<b.right-m&&a.right>b.left+m&&a.top<b.bottom-m&&a.bottom>b.top+m;
 const nm=e=>(e.id?'#'+e.id:'')+'.'+String(e.className&&e.className.baseVal!==undefined?e.className.baseVal:e.className||e.tagName).split(' ')[0];
 /* 1. the HUD audit */
 for(const x of __rpuOvl(h))if(!/NEW MONSTER|rpfoe|rpqpop/.test(x))out.push('hud: '+x);
 if(!pb||!vis(pb))return out;
 /* 2. potion boxes against every other HUD box (leaf-ish boxes: buttons, text holders, panels with a background) */
 const mine=[...pb.querySelectorAll('*')].filter(e=>vis(e)&&!e.closest('[aria-hidden="true"]'));const tip=document.querySelector('.rppttip,#rppttip');if(tip&&vis(tip))mine.push(tip);
 const solid=e=>{const c=getComputedStyle(e);return c.backgroundImage!=='none'||(c.backgroundColor&&!/rgba\(0, 0, 0, 0\)|transparent/.test(c.backgroundColor))||/^(BUTTON|KBD|B|SPAN|EM|SMALL|I)$/.test(e.tagName)&&e.textContent.trim()};
 const others=[...document.querySelectorAll('#rphud *, .rptip, #rpinfo, #rpring, .rpsortm, .rptyw, #rptoast, .rptoast, .rpuban, .rpwv, .rpcombo')].filter(e=>!pb.contains(e)&&!(tip&&tip.contains(e))&&vis(e)&&solid(e)&&!e.contains(pb)&&!e.closest('[aria-hidden="true"]'));
 const mr=mine.filter(solid).map(e=>[e,e.getBoundingClientRect()]),orr=others.map(e=>[e,e.getBoundingClientRect()]);
 for(const [a,ra] of mr)for(const [b,rb] of orr)if(hit(ra,rb,1.5))out.push('touch: '+nm(a)+'['+(a.textContent||'').trim().slice(0,14)+'] x '+nm(b)+'['+(b.textContent||'').trim().slice(0,14)+']');
 /* 3. nothing of the belt pokes out of the belt / the chips row, and all on the stage */
 const belt=pb.querySelector('.rpptbelt'),bb=belt.getBoundingClientRect();
 for(const e of belt.querySelectorAll('*')){if(!vis(e)||e.closest('[aria-hidden="true"]'))continue;const r=e.getBoundingClientRect();if(r.left<bb.left-1||r.right>bb.right+1)out.push('pokes out sideways: '+nm(e)+' '+[r.left-bb.left,r.right-bb.right].map(Math.round))}
 for(const e of mine){const r=e.getBoundingClientRect();if(r.left<W.left-1||r.right>W.right+1||r.top<W.top-1||r.bottom>W.bottom+1)out.push('off stage: '+nm(e))}
 /* 4. no build pad or tower under the belt or the chips (they would be hard to click) */
 const R=RPX;if(R)for(const p of R.pads){const x=cv.left+p.x*k,y=cv.top+p.y*k,rr=44*k,pr={left:x-rr,right:x+rr,top:y-rr*.6,bottom:y+rr*.6};for(const [e,r] of mr.filter(q=>q[0].matches('.rpptbelt,.rppts,.rpptchip')))if(hit(pr,r,2)){out.push('covers pad '+p.i+(p.tw?' ('+p.tw.type+')':'')+' with '+nm(e));break}}
 return [...new Set(out)]}"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();er=[];allbad={};shot=0
        for vw,vh in [(1600,900),(1280,720),(1024,640)]:
            pg=await b.new_page(viewport={'width':vw,'height':vh});pg.on('pageerror',lambda e:er.append(str(e)[:300]));E=pg.evaluate
            await pg.goto(H);await pg.wait_for_timeout(1500);await E(OVL);await E(HELP);await E(SETUP%ALL)
            tag=f'{vw}x{vh}';bad={}
            for m in MAPS:
                st=await E("""async([m,A])=>{const res={};const sl=async()=>{await __p.sleep(260)};const aud=t=>{res[t]=(%s)(t)};
                  const R=__p.start(m,{fury:2,quick:1,hour:1,frost:2,fire:1,mend:1,gild:1,seer:1},['fury','frost','hour']);R.supply=1e6;
                  for(const p of R.pads.slice(0,R.pads.length))__p.build(R,p,['ballista','frost','prism','bell','moon','lant'][p.i%%6],2);R.supply=4000;await sl();aud('build');
                  R.sel=null;rpWaveStart();__p.run(R,11);await sl();aud('wave');
                  R.pt.cd=0;rpptUse(0);R.pt.cd=0;rpptUse(2);await sl();aud('buffs');
                  R.pt.cd=0;rpptPress(1);await sl();aud('aim');if(R.aim)rpClick(0,0,2);
                  for(const el of [...document.querySelectorAll('#rpptb .rppts')]){el.dispatchEvent(new PointerEvent('pointerover',{bubbles:true}));el.dispatchEvent(new MouseEvent('mouseover',{bubbles:true}));el.dispatchEvent(new MouseEvent('mouseenter',{bubbles:false}));await __p.sleep(160);aud('tip'+el.dataset.i);el.dispatchEvent(new MouseEvent('mouseleave',{bubbles:false}));el.dispatchEvent(new MouseEvent('mouseout',{bubbles:true}))}
                  const lt=R.pads.filter(p=>p.tw).sort((a,c)=>(a.x-c.x)+(c.y-a.y)*.3)[0];if(lt){R.sel=lt.tw;await sl();aud('info');R.sel=null}
                  try{rptySet(true);await __p.sleep(400);aud('rune');rptySet(false)}catch(e){}
                  const so=document.querySelector('.rpsort');if(so){so.click();await sl();aud('sort');so.click()}
                  const nx=document.querySelector('.rpnext');if(nx){nx.classList.add('open');await sl();aud('nextcard');nx.classList.remove('open')}
                  try{rpqWvCall(true);await sl();aud('called')}catch(e){}
                  return res}""" % AUDIT,[m,ALL])
                for s,v in st.items():
                    if v:bad[m+':'+s]=v
                if m in ('moss','storm','wonder','coral') and vw in (1600,1024):
                    await pg.screenshot(path=os.path.join(SHOTS,f'battle_{m}_{tag}.png'))
                await E("()=>{try{rpLeave()}catch(e){}}")
            # the Witch's Cauldron and its hub button
            r=await E("""async()=>{const out={};try{rpLeave()}catch(e){}rampartsMenu(title);await __p.sleep(500);const btn=document.getElementById('rphpt');out.btn=!!btn&&/Witch/.test(btn.textContent);
               const top=btn&&btn.parentElement;out.top=top?__rpuOvl(top):['no top'];if(btn){const br=btn.getBoundingClientRect();for(const o of [...top.children].filter(x=>x!==btn&&x.getBoundingClientRect().width>1)){const r=o.getBoundingClientRect();if(br.left<r.right-1&&br.right>r.left+1&&br.top<r.bottom-1&&br.bottom>r.top+1)out.top.push('button x '+(o.id||o.className))}}
               rpptShop();await __p.sleep(600);const x=document.getElementById('rpptx');out.shop=__rpuOvl(x);out.title=(x.querySelector('.rppttl b')||{}).textContent;
               /* every card's parts inside the card, satchel slots inside the satchel */const pk=[];for(const c of x.querySelectorAll('.rpptcard,.rpptc')){const cr=c.getBoundingClientRect();for(const e of c.querySelectorAll('*')){const r=e.getBoundingClientRect();if(r.width<2)continue;if(r.left<cr.left-1||r.right>cr.right+1||r.top<cr.top-1||r.bottom>cr.bottom+1)pk.push((c.dataset.k||'card')+':'+(e.className||e.tagName))}}out.poke=[...new Set(pk)];
               return out}""")
            await pg.screenshot(path=os.path.join(SHOTS,f'cauldron_{tag}.png'))
            if not r['btn'] or r['top'] or r['shop'] or r['poke'] or not re.search('Witch',r['title'] or ''):bad['cauldron']=r
            allbad[tag]=bad;await pg.close()
        for tag,bad in allbad.items():
            chk(f'{tag}: the potion belt, buff chips and tooltips touch nothing else, stay inside the belt and on the stage and cover no pad, on all ten maps in every state; the HUD audit is clean; the Witch\'s Cauldron and its hub button have no overlaps',not bad,bad)
        chk('no page errors',not er,er[:5])
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK');sys.exit(1 if FAIL else 0)
asyncio.run(main())
