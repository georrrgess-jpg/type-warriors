# python3 t_w10b.py [game.html] : Runestone Tower Defense 10.0 - Tower Mastery (98m): XP from waves, kills and wins, levels I-V unlocking a
# skin each, 60 skins drawn by recolouring + effects for every tower, cost per frame, Performance mode, the Tower Skins screen (grid,
# mastery track, equip, locks), the results card, the DEV cheats and help text.
import asyncio,os,sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:500]),flush=True)
    if not ok:FAIL.append(name)
SETUP="()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const r=RPP();r.new99j=1;r.dragon=1;r.stars={moss:3,frost:3,ember:3};for(const k in r.tut)r.tut[k]=1;r.mast={};save()}"
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E(SETUP)
        r=await E("()=>[RPY_LV.join(','),RP_TWORDER.every(t=>rpySet(t).length===5),new Set(RP_TWORDER.flatMap(t=>rpySet(t).map(x=>x[1]))).size,RP_TWORDER.every(t=>rpySet(t).every(x=>RPY_TH[x[0]]))]")
        chk('five mastery levels (300 to 14,000 XP); every tower has five named skins, all names different',r[0]=='0,300,1200,3200,7000,14000' and r[1] and r[2]==5*len(await E("()=>RP_TWORDER"))and r[3],r)
        # XP in battle
        r=await E("""()=>{RPP().mast={ballista:290};rpStart('moss');const R=RPX;R.tut=null;R.supply=5000;rpBuild(R.pads[3],'ballista');R.pads[3].tw.build=1;R.wave=0;rpWaveStart();let n=0;while(R.wst!=='build'&&n<30*120){rpStep(R,1/30);n++}
          const a=[rpyXP('ballista')>290,rpyLevel('ballista'),RPP().own['ballista:m1']||0,(R.mastUp||[]).map(x=>x.join(':')).join(),/mastery I!/.test(R.toast&&R.toast.txt||'')];rpLeave();return a}""")
        chk('clearing a wave gives XP (6 x tier plus kills); crossing 300 XP reaches mastery I, unlocks the skin and says so',r==[True,1,1,'ballista:1',True],r)
        r=await E("""()=>{RPP().mast={};rpStart('moss');const R=RPX;R.tut=null;rpBuild(R.pads[0],'frost');R.pads[0].tw.build=1;R.won=true;R.free=false;rpFinish(true);return [rpyXP('frost')>=50]}""")
        chk('winning a map gives every tower type used 50 XP',r==[True],r)
        await E("()=>{try{rpLeave()}catch(e){}title()}")
        # every skin of every tower draws, and differs from the classic
        r=await E("""()=>{const out=[];const c=document.createElement('canvas');c.width=300;c.height=320;const g=c.getContext('2d');const px=k=>{g.clearRect(0,0,300,320);g.save();g.translate(150,280);rpTowerDraw(g,t,3,k,1.3,{ph:.3,aim:-.4});g.restore();return g.getImageData(0,0,300,320).data};let t;
          for(t of RP_TWORDER){const b0=px('base');for(let i=1;i<=5;i++){const d=px('m'+i);let diff=0;for(let j=0;j<d.length;j+=40)if(Math.abs(d[j]-b0[j])+Math.abs(d[j+1]-b0[j+1])+Math.abs(d[j+2]-b0[j+2])>60)diff++;out.push([t,i,diff])}}return out}""")
        bad=[x for x in r if x[2]<150]
        chk('all mastery skins of every tower draw and look clearly different from the classic',not bad,bad[:6])
        r=await E("""()=>{const c=document.createElement('canvas');c.width=1600;c.height=900;const g=c.getContext('2d');const run=k=>{for(let i=0;i<6;i++){g.save();g.translate(800,500);rpTowerDraw(g,'bell',3,k,i/9,{ph:.3});g.restore()}const t0=performance.now();for(let i=0;i<150;i++){g.save();g.translate(800,500);rpTowerDraw(g,'bell',3,k,i/30,{ph:.3});g.restore()}g.getImageData(0,0,1,1);return (performance.now()-t0)/150};
          const b=run('base'),m1=run('m1'),m5=run('m5');return [+b.toFixed(3),+m1.toFixed(3),+m5.toFixed(3)]}""")
        chk('cost: a recoloured tower costs about the same as the classic; a mythic (V) one stays under 1.5 ms more here',r[1]<r[0]*1.5+.2 and r[2]-r[0]<1.5,r)
        r=await E("""()=>{const old=ST.perf;ST.perf='low';RPG_QT=0;const c=document.createElement('canvas');c.width=400;c.height=420;const g=c.getContext('2d');let n=0;const d0=g.drawImage;g.drawImage=function(){n++;return d0.apply(this,arguments)};
          g.translate(200,380);rpTowerDraw(g,'frost',3,'m5',1,{ph:.2});const low=n;n=0;ST.perf=old;RPG_QT=0;rpTowerDraw(g,'frost',3,'m5',1,{ph:.2});return [low,n]}""")
        chk('Performance mode keeps the recolour and the adornments but drops the light pillar, sigil and motes',r[0]<r[1],r)
        # Tower Skins
        await E("()=>{RPP().mast={frost:7500};rpySync();RPSKSEL={tw:'frost',k:'m4'};rpSkins()}");await pg.wait_for_timeout(800)
        r=await E("()=>[ov.querySelectorAll('.rpcsn').length,ov.querySelector('.rpcsn.on .rpylv').textContent,ov.querySelectorAll('.rpycard').length,ov.querySelectorAll('.rpycard.lock').length,ov.querySelector('.rpcst h3').textContent,ov.querySelector('.rpcstat').textContent,ov.querySelectorAll('.rpylvs span.got').length]")
        chk('Tower Skins: every tower with its mastery badge; the Frost Spire shows Classic, its star skin and five mastery skins (IV reached: V locked)',r[0]==len(await E("()=>RP_TWORDER")) and r[1]=='IV' and r[2]==7 and r[3]>=1 and r[4]=='Amethyst Spire' and r[5]=='Owned' and r[6]==4,r)
        await pg.screenshot(path=os.path.join(HERE,'shots','w10b_skins.png'))
        await E("()=>ov.querySelector('.rpskt[data-k=\"m4\"]').click()");await pg.wait_for_timeout(300)
        r=await E("()=>[RPP().skin.frost,rpSkinOf('frost')]")
        chk('clicking an owned mastery skin equips it',r==['m4','m4'],r)
        await E("()=>ov.querySelector('.rpskt[data-k=\"m5\"]').click()");await pg.wait_for_timeout(300)
        r=await E("()=>[RPP().skin.frost,ov.querySelector('.rpskbt button').disabled,/Mastery V/.test(ov.querySelector('.rpskbt').textContent)]")
        chk('a locked mastery skin cannot be equipped and says which level unlocks it',r==['m4',True,True],r)
        await pg.screenshot(path=os.path.join(HERE,'shots','w10b_skins_v.png'))
        # in battle the equipped skin is used
        r=await E("()=>{rpStart('moss');const R=RPX;R.tut=null;rpBuild(R.pads[0],'frost');const s=R.pads[0].tw.skin;for(let i=0;i<5;i++)rpDraw();rpLeave();return s}")
        chk('a tower built in battle wears the equipped mastery skin',r=='m4',r)
        # results card
        r=await E("""()=>{RPP().mast={};rpStart('moss');const R=RPX;R.tut=null;R.supply=5000;for(const i of [2,4,6]){rpBuild(R.pads[i],'ballista');R.pads[i].tw.build=1}R.wave=0;rpWaveStart();let n=0;while(R.wst!=='build'&&n<30*120){rpStep(R,1/30);n++}
          R.won=true;R.free=false;rpFinish(true);return 1}""");await pg.wait_for_timeout(2500)
        r=await E("()=>{const m=ov.querySelector('.rpyres');return m?[m.querySelectorAll('.rpyr').length,/XP/.test(m.textContent)]:null}")
        chk('the results card lists the mastery XP gained',r is not None and r[0]>=1 and r[1],r)
        await pg.screenshot(path=os.path.join(HERE,'shots','w10b_results.png'))
        # cheats and help
        r=await E("()=>{dvxAct('tdm5');const a=[RP_TWORDER.every(t=>rpyLevel(t)===5),RP_TWORDER.every(t=>RPP().own[t+':m5'])];dvxAct('tdm0');a.push(RP_TWORDER.every(t=>rpyLevel(t)===0),!Object.keys(RPP().own).some(k=>/:m[1-5]$/.test(k)));return a}")
        chk('DEV cheats: max mastery owns every mastery skin; clear removes them',r==[True,True,True,True],r)
        r=await E("()=>{const h=HELP.Modes.find(x=>x[0]==='Runestone Tower Defense');return [/Tower Mastery/.test(h[1]),/Tidebreak Isles/.test(h[1])]}")
        chk('the help text explains the worlds and mastery',r==[True,True],r)
        chk('no page errors',not er,er)
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
