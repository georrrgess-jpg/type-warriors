/* ===== 9.5 THE CROOKED CUE: pause, settings and the Trick Shots list (96za) =====
   - Pause shows the match: both faces, the score and race, what the stake pays, the house rule, and the main keys.
   - Settings: the aim guide with a line on what each mode shows, typing taunts, tutorial tips on/off and a replay.
   - Trick Shots: the next unsolved puzzle is marked and focused, unclaimed 200-gold bounties wear a badge, and the
     hint stays hidden until you have tried the puzzle (Granny still says it at the table). Puzzles that need the cue
     ball to finish in an area draw that area on the felt. */
function pzPauseMenu(again){if(!PZ.on||(PZ.modal&&!again)||PZ.ph==='over'||PZ.ph==='intro')return;PZ.paused=true;const Z=PZS(),M=PZ.M,R=PZ.reg,trick=!!M.trick;
 const fm=x=>x.toFixed(2).replace(/0$/,'').replace(/\.0$/,'');
 const info=trick?`Trick shot ${M.trick.n+1} · ${PZ_TRICK[M.trick.n].n} · try ${M.trick.tries+1}`:M.practice?`Practice table · race to ${M.race}`:`Stake ${cmn(M.stake)} · a win pays ${cmn(Math.round(M.stake*M.mult))} (×${fm(M.mult)})`;
 const m=pzModal(`<div class="pzh2">Paused</div>
  <div class="pzpvs"><canvas width="88" height="88" id="pzpvh"></canvas><div><b>${trick?'Trick Shots':`${M.score[0]} <i>-</i> ${M.score[1]}`}</b><small>${trick?'with Granny Moldwick':`You vs ${R.n} · race to ${M.race} · rack ${M.rack}`}</small></div><canvas width="88" height="88" id="pzpvo"></canvas></div>
  <p class="pzpinf">${info}</p>${!trick&&R.houseTxt?`<p class="pzpinf hr"><b>House rule</b> ${R.houseTxt}</p>`:''}
  <button class="pzmb gold" data-a="resume">Resume <kbd>Esc</kbd></button><div class="pzprow"><button class="pzmb" data-a="rules">How to play</button><button class="pzmb" data-a="set">Settings</button></div>${trick?`<button class="pzmb" data-a="list">Puzzle list</button>`:''}<button class="pzmb red" data-a="forfeit">${trick?'Leave Trick Shots':M.practice?'Leave the table':'Forfeit match'}</button>
  <div class="pzpkeys"><span><kbd>Mouse</kbd> aim, press + pull back to shoot</span><span><kbd>Space</kbd> shoot / speed up</span><span><kbd>W A S D</kbd> spin</span><span><kbd>G</kbd> guide</span></div>`,'pause p9');
 try{const ex=Object.assign(pzCastEx(),PZ_EXP.neutral);pzCastPortrait($('pzpvh').getContext('2d'),'hero',null,88,1,ex);pzCastPortrait($('pzpvo').getContext('2d'),'mon',R.id,88,1,Object.assign(pzCastEx(),PZ_EXP.smug))}catch(e){}
 S.back=()=>{const b=document.querySelector('#pzmod [data-a=resume]');if(b)b.click();else if(PZ.modal)pzPauseMenu(true)};
 m.querySelector('[data-a=resume]').onclick=()=>{pzModalClose();S.back=()=>pzPauseMenu()};
 m.querySelector('[data-a=rules]').onclick=()=>{pzRulesModal()};
 m.querySelector('[data-a=set]').onclick=()=>{pzSettingsModal()};
 {const l=m.querySelector('[data-a=list]');if(l)l.onclick=()=>{pzModalClose();pzTrick()}}
 m.querySelector('[data-a=forfeit]').onclick=()=>{if(trick){pzModalClose();pzTrick();return}pzModal(`<div class="pzh2">${M.practice?'Leave the table?':'Forfeit?'}</div><p class="pzmm">${M.practice?'It is only practice, so nothing is lost.':`You will lose your stake of <b>${cmn(M.stake)}</b>.`}</p><button class="pzmb red" data-a="yes">${M.practice?'Leave':'Forfeit'}</button><button class="pzmb gold" data-a="no">Keep playing</button>`,'pause');
  const mm=$('pzmod');mm.querySelector('[data-a=yes]').onclick=()=>{pzModalClose();pzForfeit()};mm.querySelector('[data-a=no]').onclick=()=>pzPauseMenu(true)}}
function pzSettingsModal(){const Z=PZS();const gd={full:'Full: the whole shot, where every ball goes and which pockets take them.',short:'Short: the ghost ball and the start of each line.',pro:'Pro: only the aim line to the first ball (and it counts for a trophy against Mortimer).'};
 const seg=(k,opts,cur)=>`<div class="pzseg" data-k="${k}">${opts.map(([v,l])=>`<button class="${cur===v?'on':''}" data-v="${v}">${l}</button>`).join('')}</div>`;
 const m=pzModal(`<div class="pzh2">Settings</div>
 <div class="pzset"><span>Aim guide</span>${seg('guide',[['full','Full'],['short','Short'],['pro','Pro']],Z.guide)}</div><p class="pzmm small pzgdtxt">${gd[Z.guide]||''}</p>
 <div class="pzset"><span>Typing taunts</span>${seg('tauntsOn',[[true,'On'],[false,'Off']],Z.tauntsOn)}</div>
 <div class="pzset"><span>Tutorial tips</span>${seg('tutOff',[[false,'On'],[true,'Off']],!!Z.tutOff)}</div>
 <button class="pzmb" data-a="replay">Replay every tutorial</button><button class="pzmb gold" data-a="back">Back</button>`,'pause p9');
 m.querySelectorAll('.pzseg').forEach(sg=>sg.querySelectorAll('button').forEach(b=>b.onclick=()=>{const k=sg.dataset.k,v=b.dataset.v==='true'?true:b.dataset.v==='false'?false:b.dataset.v;Z[k]=v;save();pzGuideNote();sg.querySelectorAll('button').forEach(x=>x.classList.toggle('on',x===b));pzFx('tick');try{pzHudAll()}catch(e){}if(k==='guide'){const t=m.querySelector('.pzgdtxt');if(t)t.textContent=gd[v]||''}}));
 m.querySelector('[data-a=replay]').onclick=function(){pzCoachReset();Z.tutOff=false;save();this.textContent='Tutorials reset: they show again as you play';pzFx('place')};
 m.querySelector('[data-a=back]').onclick=()=>pzPauseMenu(true)}
/* the puzzle pause (96o) keeps Hint, Restart and the list, and gains How to play and Settings */
{const f0=pzTrickPause;pzTrickPause=function(){const r=f0.apply(this,arguments);try{const m=$('pzmod'),l=m&&m.querySelector('[data-a=list]');if(l&&!m.querySelector('[data-a=set]')){l.insertAdjacentHTML('beforebegin','<div class="pzprow"><button class="pzmb" data-a="rules">How to play</button><button class="pzmb" data-a="set">Settings</button></div>');m.querySelector('[data-a=rules]').onclick=()=>pzRulesModal();m.querySelector('[data-a=set]').onclick=()=>pzSettingsModal()}}catch(e){}return r}}
/* the tips switch */
{const f0=pzCoach;pzCoach=function(id,steps,o){if(PZS().tutOff&&!(o&&o.force))return false;return f0.apply(this,arguments)}}
/* a modal hides any free tutorial card (it would sit on top of the menu) */
{const f0=pzModal;pzModal=function(){const r=f0.apply(this,arguments);try{if(pzCoachActive()&&PZC.cur.steps[PZC.cur.i]&&PZC.cur.steps[PZC.cur.i].free)pzCoachEnd(false,true)}catch(e){}return r}}
/* ---------- the Trick Shots list ---------- */
{const f0=pzTrick;pzTrick=function(){const r=f0.apply(this,arguments);try{const Z=PZS(),cards=[...ov.querySelectorAll('.pzti')];const next=PZ_TRICK.findIndex((t,i)=>pzTrickStars(i)<3);
 cards.forEach((c,i)=>{c.style.setProperty('--i',i);const st=pzTrickStars(i);if(!Z.trick['$'+i])c.insertAdjacentHTML('beforeend','<s class="pztbty">+200</s>');if(i===next){c.classList.add('next');c.insertAdjacentHTML('beforeend','<s class="pztnext">NEXT</s>')}
  const p=c.querySelector('p');if(p&&!st&&!(Z.trick['t'+i]))p.innerHTML='<i class="pzthid">Granny gives you a hint at the table.</i>'});
 const root=ov.querySelector('.pzt');if(root)root.classList.add('pzt9');if(next>=0&&cards[next])try{cards[next].focus({preventScroll:true})}catch(e){}}catch(e){}return r}}
{const f0=pzTrickJudge;pzTrickJudge=function(){try{const Z=PZS(),M=PZ.M;if(M&&M.trick){Z.trick['t'+M.trick.n]=1}}catch(e){}return f0.apply(this,arguments)}}
/* the finish area for cue-ball goals, drawn on the felt under the balls */
{const f0=pzDrawTray;pzDrawTray=function(g){const r=f0.apply(this,arguments);try{const M=PZ.M;if(M&&M.trick){const goal=PZ_TRICK[M.trick.n].goal;if(goal.cueIn){const [x0,y0,x1,y1]=goal.cueIn,G=PZ_G,t=performance.now()/1000,a=.16+.06*Math.sin(t*3);
 g.save();g.fillStyle=`rgba(138,255,180,${a})`;g.fillRect(G.x+x0,G.y+y0,x1-x0,y1-y0);g.setLineDash([10,8]);g.lineDashOffset=-t*20;g.strokeStyle='rgba(138,255,180,.75)';g.lineWidth=3;g.strokeRect(G.x+x0+2,G.y+y0+2,x1-x0-4,y1-y0-4);g.setLineDash([]);
 g.font='800 15px Poppins,sans-serif';g.textAlign='center';g.textBaseline='middle';g.lineWidth=5;g.strokeStyle='#12081f';const tx=G.x+(x0+x1)/2,ty=G.y+y1-24;g.strokeText('CUE BALL ENDS HERE',tx,ty);g.fillStyle='#a8ffcc';g.fillText('CUE BALL ENDS HERE',tx,ty);g.restore()}}}catch(e){}return r}}
{const st=document.createElement('style');st.textContent=`
.pzmod.p9 .pzmp{width:520px}
.pzpvs{display:flex;align-items:center;justify-content:center;gap:18px;margin:6px 0 4px}.pzpvs canvas{width:70px;height:70px;border-radius:50%;background:radial-gradient(circle at 50% 40%,#4a3a8a,#140c36);border:3px solid #c99a3a}
.pzpvs b{display:block;font:400 44px/1 "Pirata One",serif;color:#efe8ff}.pzpvs b i{font-style:normal;color:#8a80c8;margin:0 6px}.pzpvs small{font:700 12px Poppins,sans-serif;color:#c4badf}
.pzpinf{margin:6px 0 0!important;font:700 13.5px Poppins,sans-serif!important;color:#ffd45a!important}.pzpinf.hr{color:#c4badf!important;font-weight:600!important}.pzpinf.hr b{color:#ffd45a}
.pzmod.p9 .pzmb{display:flex;align-items:center;justify-content:center;gap:10px}.pzmod.p9 .pzmb kbd{padding:0 6px;border-radius:7px;background:#12081f33;border:1px solid #12081f55;font:800 11px/20px Poppins,sans-serif}
.pzprow{display:flex;gap:10px}.pzprow .pzmb{flex:1}
.pzpkeys{display:flex;flex-wrap:wrap;gap:6px 12px;justify-content:center;margin-top:14px;font:600 11.5px Poppins,sans-serif;color:#9a90c8}.pzpkeys kbd{padding:0 5px;border-radius:6px;background:#12081f;border:1px solid #4a3e90;font:800 10.5px/18px Poppins,sans-serif;color:#efe8ff}
.pzgdtxt{min-height:34px;margin:2px 0 8px!important}
.pzt9 .pzti{transition:transform .22s cubic-bezier(.3,1.5,.5,1);animation:pzrise .4s calc(var(--i,0)*.04s) cubic-bezier(.25,1.3,.45,1) both}.pzt9 .pzti:hover,.pzt9 .pzti:focus-visible{transform:translateY(-6px);border-color:#ffd45a;outline:none}
.pzt9 .pzti.next{border-color:#ffd45a;box-shadow:inset 0 1px 0 #ffffff1f,0 0 0 3px #ffd45a55,0 10px 28px #0009}
.pztbty{position:absolute;right:10px;top:-10px;padding:2px 8px;border-radius:9px;background:#ffd45a;color:#2a1a04;font:800 11px Poppins,sans-serif;text-decoration:none;border:2px solid #12081f}
.pztnext{position:absolute;left:10px;top:-10px;padding:2px 9px;border-radius:9px;background:#8affb4;color:#06200f;font:800 11px Poppins,sans-serif;text-decoration:none;border:2px solid #12081f;animation:pznewb 1.6s ease-in-out infinite}
.pzti .pzthid{font-style:italic;color:#8a80b8;letter-spacing:normal;font-size:inherit}
.pzt9 .pztsub{display:inline-block;left:50%;right:auto;white-space:nowrap;transform:translateX(-50%);padding:5px 16px;border-radius:14px;background:#100a30e0;border:2px solid #4a3e90}
`;document.head.appendChild(st)}
