/* ---------- the campaign screen: a painted map per act, level nodes, and a boss panel ---------- */
const CMIC={back:'<path d="M15 5l-7 7 7 7"/>',
 skull:'<path d="M12 3.2a8 8 0 00-8 8c0 2.6 1.2 4.3 3 5.4V20h3v-2h4v2h3v-3.4c1.8-1.1 3-2.8 3-5.4a8 8 0 00-8-8z"/><circle cx="9" cy="11.4" r="1.7"/><circle cx="15" cy="11.4" r="1.7"/><path d="M12 14l-1 2h2z"/>',
 shield:'<path d="M12 3l7 3v5.5c0 4.2-2.9 7.6-7 9.5-4.1-1.9-7-5.3-7-9.5V6z"/><path d="M12 8v8M8.6 11.6h6.8"/>',
 trophy:'<path d="M8 4h8v5a4 4 0 01-8 0zM8 6H5v1.5A3 3 0 008 10.5M16 6h3v1.5a3 3 0 01-3 3M12 13v4M8.5 20h7M10 17h4"/>',
 scroll:'<path d="M7 4h11a2 2 0 012 2v1.5h-3V18a2 2 0 01-2 2H7a2 2 0 01-2-2V8H4V6a2 2 0 013-2z"/><path d="M9 9h5M9 12.5h5M9 16h3"/>',
 star:'<path d="M12 3.5l2.6 5.4 5.9.8-4.3 4.1 1 5.9L12 17l-5.2 2.7 1-5.9L3.5 9.7l5.9-.8z"/>',
 swords:'<path d="M5 19L18.5 5.5M18.5 5.5H14M18.5 5.5V10M19 19L5.5 5.5M5.5 5.5H10M5.5 5.5V10M3.5 20.5l3-3M20.5 20.5l-3-3"/>',
 lock:'<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/>',
 check:'<path d="M5 12.5l4.5 4.5L19 7.5"/>',
 locate:'<circle cx="12" cy="12" r="6.5"/><circle cx="12" cy="12" r="1.8"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3"/>'};
const cmi=(k,s)=>hsvg(CMIC[k],s);
/* a different winding road for every act */
const CMPOS=[
 [[150,690],[370,540],[590,680],[740,450],[930,600],[1010,340]],
 [[140,430],[330,630],[530,440],[720,660],[870,430],[1020,620]],
 [[160,640],[300,430],[520,570],[700,370],[860,570],[1030,430]],
 [[150,440],[330,650],[540,480],[760,670],[900,440],[1030,650]],
 [[150,700],[330,510],[560,650],[690,410],[880,570],[1020,340]]];
const CMROM=['I','II','III','IV','V'],CM={act:0,prev:-1,t0:0,keys:0};
const cmCur=()=>Math.min(30,P.camp);
function cmSegs(pts){const o=[];for(let i=0;i<pts.length-1;i++){const p0=pts[Math.max(0,i-1)],p1=pts[i],p2=pts[i+1],p3=pts[Math.min(pts.length-1,i+2)];
 o.push(`M${p1[0]} ${p1[1]} C${p1[0]+(p2[0]-p0[0])/6} ${p1[1]+(p2[1]-p0[1])/6} ${p2[0]-(p3[0]-p1[0])/6} ${p2[1]-(p3[1]-p1[1])/6} ${p2[0]} ${p2[1]}`)}return o}
function cmMapHTML(act){const n0=act*6,pts=CMPOS[act],segs=cmSegs(pts);let svg='<svg class="cmsv" viewBox="0 0 1130 900">',last='';
 segs.forEach((d,i)=>{const n=n0+i+2,open=n<=P.camp;svg+=`<path class="cmrd" d="${d}"/>`;
  if(open){last=d;svg+=`<path class="cmgg" d="${d}"/><path class="cmgl" pathLength="1" style="--i:${i}" d="${d}"/>`}else svg+=`<path class="cmdl" d="${d}"/>`});
 if(last)svg+=`<circle class="cmsp" r="5"><animateMotion dur="2.4s" repeatCount="indefinite" path="${last}"/></circle>`;svg+='</svg>';
 const nodes=pts.map(([x,y],i)=>{const n=n0+i+1,Z=lvN(n),lk=n>P.camp,cr=n===P.camp&&!cleared(n),dn=!lk&&cleared(n),st=P.stars[n]||0;
  return `<button class="cn${lk?' lk':''}${cr?' cur':''}${dn?' dn':''}${n===campSel?' sel':''}${i===5?' bs':''}" data-n="${n}" style="left:${x}px;top:${y}px;--c:${Z.a};--i:${i}" aria-label="Level ${n}, ${esc(Z.n)}${lk?', locked':''}">`+
   (dn?`<span class="cst">${[1,2,3].map(k=>`<i class="${k<=st?'on':''}">★</i>`).join('')}</span>`:'')+
   `<span class="crg"></span><span class="cds"><img alt="" src="${bossMedal(Z)}"></span><span class="cnm">${n}</span>`+
   (dn?`<span class="cck">${cmi('check',17)}</span>`:'')+(lk?`<span class="clk">${cmi('lock',30)}</span>`:'')+(GR[n]&&!lk?`<span class="cgr">#${GR[n][0]} gold</span>`:'')+
   `<span class="clb">${esc(Z.n)}</span>${cr?'<span class="cpl">Next Battle</span>':''}</button>`}).join('');
 return svg+nodes}
function cmPanelHTML(){const n=campSel,Z=lvN(n),lk=n>P.camp,act=((n-1)/6)|0,st=P.stars[n]||0,dn=!lk&&cleared(n),sk=Math.min(5,1+act),M=Z.mod?MODS[Z.mod]:null,fin=n%6===0;
 return `<div class="cmpt">Level ${n}: ${esc(Z.n)}</div>
 <div class="cmart" style="--c:${Z.a}"><canvas id="cmhero" width="640" height="396"></canvas><span class="cmac">Act ${CMROM[act]}${fin?' · Final boss':''}</span>${GR[n]?`<span class="cmgr" title="About ${GR[n][1].toLocaleString()} gold per clear">#${GR[n][0]} gold level</span>`:''}</div>
 <div class="cmrows">
  <div class="cmr"><span class="cmi">${cmi('skull',24)}</span><span class="cmx"><small>Boss</small><b>${esc(Z.bn)}</b></span><span class="cmsk" title="Danger">${'☠'.repeat(sk)}</span></div>
  <div class="cmr"><span class="cmi">${cmi('shield',24)}</span><span class="cmx"><small>Rule</small>${M?`<b class="g">${M.n}</b><em>${M.d}</em>`:`<b class="g">No special rule</b><em>A gentle start.</em>`}</span></div>
  <div class="cmr"><span class="cmi">${cmi('trophy',24)}</span><span class="cmx"><small>Best score</small><b>${P.cbest[n]?P.cbest[n].toLocaleString():'Not set yet'}</b></span>${dn?`<span class="cmrt" title="Your rating">${'★'.repeat(st)}${'☆'.repeat(3-st)}</span>`:''}</div>
  <div class="cmr"><span class="cmi">${cmi('scroll',24)}</span><span class="cmx"><small>Level briefing</small><em>${lk?'Defeat the boss of the previous level to unlock this one.':esc(Z.blurb)+' Five rounds, then the boss.'}</em></span></div>
  <div class="cmr three"><span class="cmi">${cmi('star',24)}</span><span class="cmx"><em><b>Three Stars:</b> Finish the level without losing a heart.</em></span></div>
 </div>
 <button class="cmgo" id="go" ${lk?'disabled':''}>${lk?cmi('lock',26)+'<span>Locked</span>':cmi('swords',28)+`<span>${dn?'Replay Level':'Begin Level'}</span>`}</button>`}
function cmBGFn(c){const g=c.getContext('2d'),o=document.createElement('canvas');o.width=ABW;o.height=ABH;const og=o.getContext('2d');
 return t=>{if(CM.prev<0){actBG(g,CM.act,t);return}const f=Math.min(1,(performance.now()-CM.t0)/700);
  if(f>=1){CM.prev=-1;actBG(g,CM.act,t);return}actBG(g,CM.prev,t);og.clearRect(0,0,ABW,ABH);actBG(og,CM.act,t);g.globalAlpha=f*f*(3-2*f);g.drawImage(o,0,0);g.globalAlpha=1}}
function cmFit(){const t=document.querySelector('#cmp .cmpt');if(!t)return;let f=40;t.style.fontSize='';while(t.scrollWidth>t.clientWidth&&f>20){f-=2;t.style.fontSize=f+'px'}}
if(document.fonts&&document.fonts.ready)document.fonts.ready.then(()=>{try{cmFit()}catch(e){}});
function cmHero(){const c=$('cmhero');if(c)LIVE.push({cv:c,fn:bossHero(c,lvN(campSel)),slow:2,ph:1,vis:true})}
function cmTabsHTML(act){return ACTS.map((a,i)=>{const lk=i*6+1>P.camp;return `<button class="cmt${i===act?' on':''}${lk?' lk':''}" data-a="${i}" ${lk?'disabled':''}>${lk?cmi('lock',16):''}<span>Act ${CMROM[i]}: ${a}</span></button>`}).join('')}
function cmSelect(n){const was=CM.act,act=((n-1)/6)|0,same=n===campSel;campSel=n;S.bgz=n;
 if(act!==was){CM.prev=was;CM.act=act;CM.t0=performance.now();$('cmmap').innerHTML=cmMapHTML(act);cmBindMap();$('cmtabs').innerHTML=cmTabsHTML(act);cmBindTabs()}
 else{ov.querySelectorAll('.cn').forEach(e=>e.classList.toggle('sel',+e.dataset.n===n))}
 if(same&&act===was)return;
 const p=$('cmp');p.innerHTML=cmPanelHTML();p.classList.remove('sw');void p.offsetWidth;p.classList.add('sw');cmBindPanel();cmHero();cmFit()}
function cmBindPanel(){const g=$('go');if(g)g.onclick=()=>{if(campSel<=P.camp)start(campSel)}}
function cmBindMap(){ov.querySelectorAll('.cn').forEach(el=>el.onclick=()=>{const n=+el.dataset.n;
 if(n>P.camp){el.classList.remove('shk');void el.offsetWidth;el.classList.add('shk');return}
 if(n===campSel)start(n);else cmSelect(n)})}
function cmBindTabs(){ov.querySelectorAll('.cmt').forEach(el=>el.onclick=()=>{const i=+el.dataset.a;if(i===CM.act||el.disabled)return;const cur=cmCur();cmSelect(i*6+1<=cur&&cur<=i*6+6?cur:i*6+1)})}
function cmLocate(){const cur=cmCur();cmSelect(cur);const el=ov.querySelector(`.cn[data-n="${cur}"]`);if(el){el.classList.remove('ping');void el.offsetWidth;el.classList.add('ping')}}
function campaign(sel){S.mode='title';S.view='camp';const cur=cmCur();
 if(sel)campSel=sel;else if(!campSel||campSel>cur)campSel=cur;
 const act=((campSel-1)/6)|0;CM.act=act;CM.prev=-1;S.bgz=campSel;
 const total=Object.values(P.stars).reduce((a,b)=>a+b,0),done=Object.keys(P.stars).length;
 show(`<div class="cm" id="cm"><canvas class="cmbg" id="cmbg" width="1600" height="900"></canvas><div class="cmvg"></div>
  <button class="cmback" id="cmBack">${cmi('back',20)}<span>Back</span></button>
  <div class="cmh"><div class="cmht">Campaign</div><div class="cmsub">${total} of 90 stars<i>·</i>${done} of 30 levels cleared</div></div>
  <div class="cmtabs" id="cmtabs">${cmTabsHTML(act)}</div>
  <div class="cmmap" id="cmmap">${cmMapHTML(act)}</div>
  <button class="cmloc" id="cmloc">${cmi('locate',22)}<span>Locate current stage</span></button>
  <aside class="cmp" id="cmp">${cmPanelHTML()}</aside></div>`,'cmo nosb');
 S.back=title;
 const bg=$('cmbg');LIVE.push({cv:bg,fn:cmBGFn(bg),slow:2,ph:0,vis:true});
 cmBindMap();cmBindTabs();cmBindPanel();cmHero();cmFit();$('cmBack').onclick=title;$('cmloc').onclick=cmLocate;
 for(let i=0;i<5;i++)if(i!==act&&i*6+1<=P.camp)setTimeout(()=>{try{abStatic(i)}catch(e){}},500+i*220);
 if(!CM.keys){CM.keys=1;addEventListener('keydown',e=>{if(S.mode!=='title'||S.view!=='camp'||!$('cm')||ov.className.indexOf('hide')>=0||e.ctrlKey||e.metaKey||e.altKey)return;
  const ae=document.activeElement,free=!ae||ae===document.body||ae===inp,k=e.key,c=cmCur();
  if(k==='ArrowRight'||k==='ArrowDown'){e.preventDefault();cmSelect(Math.min(c,campSel+1))}
  else if(k==='ArrowLeft'||k==='ArrowUp'){e.preventDefault();cmSelect(Math.max(1,campSel-1))}
  else if((k==='l'||k==='L')&&free){e.preventDefault();cmLocate()}
  else if(k==='Enter'&&free&&!e.repeat&&campSel<=P.camp){e.preventDefault();start(campSel)}})}}
