/* ===== MOONLIT FISHING: the Mythic catch spectacle (7.6 s) =====
   Beats: 0-0.9 s the world holds its breath (dark, a rune portal opens on the water, light is drawn in) -> 0.9-1.75 s
   eruption (flash, prismatic pillar, shockwaves, the fish spins up out of the portal) -> 1.75-5.5 s the reveal (halo,
   god rays, orbiting stars and runes, themed particles, "MYTHIC CATCH" and the name) -> 5.5-7.6 s settle (everything
   fades and the fish glides into the catch preview).
   Drawing: fsShowFx is wrapped, but the scene dims itself after the fx pass, so the spectacle is painted in a pass
   wrapped around fsScene (only for the fishing view during a Mythic show) so it glows over the darkened world.
   All per-show state lives on FS.show.my (gone when the show ends or is skipped); sprites and gradients are cached in
   my_S. No filters, no shadowBlur, no per-frame canvases. Reduced motion: no flash or shake, slow calm motion. */
const my_S={};
const my_PR=['#ff5ad8','#b46aff','#6a8cff','#5ae2ff','#6affc4','#fff07a','#ffa85a'];
const my_TH={
 seraph:{k:'seraph',a:'#9ff4ff',b:'#7affd8',c:'#c4a8ff',w:'#eefeff',ray:'#c8f4ff',rune:'#a8f2ff',drop:'#dff6ff'},
 eclipse:{k:'eclipse',a:'#ffcf6a',b:'#ff8a4a',c:'#b07aff',w:'#fff4dc',ray:'#ffd890',rune:'#ffd27a',drop:'#e8dcff'},
 def:{k:'def',a:'#ff9ae8',b:'#b48aff',c:'#7ad8ff',w:'#fff0fb',ray:'#ffc8f0',rune:'#ffb0ee',drop:'#e8f2ff'}};
const my_th=id=>my_TH[id]||my_TH.def;
const my_r=i=>{const s=Math.sin(i*127.1+311.7)*43758.5453;return s-Math.floor(s)};
const my_cl=(v,a,b)=>v<a?a:v>b?b:v;
const my_ss=(a,b,v)=>{const k=my_cl((v-a)/(b-a),0,1);return k*k*(3-2*k)};
const my_eo=k=>1-Math.pow(1-my_cl(k,0,1),3);
const my_back=k=>{k=my_cl(k,0,1);const c=1.7;return 1+(c+1)*Math.pow(k-1,3)+c*Math.pow(k-1,2)};
function my_cv(w,h){const c=document.createElement('canvas');c.width=w;c.height=h;const g=c.getContext('2d');g.lineCap='round';g.lineJoin='round';return [c,g]}
function my_hex(c,a){return c+Math.round(my_cl(a,0,1)*255).toString(16).padStart(2,'0')}
/* ---------- cached sprites ---------- */
function my_glow(col,soft){const k='g'+col+(soft?'s':'');if(my_S[k])return my_S[k];const [c,g]=my_cv(256,256),q=g.createRadialGradient(128,128,0,128,128,128);
 q.addColorStop(0,soft?my_hex(col,.8):'#ffffff');q.addColorStop(.12,my_hex(col,soft?.7:.95));q.addColorStop(.4,my_hex(col,.38));q.addColorStop(.7,my_hex(col,.1));q.addColorStop(1,my_hex(col,0));g.fillStyle=q;g.fillRect(0,0,256,256);return my_S[k]=c}
function my_halo(col){const k='h'+col;if(my_S[k])return my_S[k];const [c,g]=my_cv(256,256),q=g.createRadialGradient(128,128,0,128,128,128);
 q.addColorStop(0,my_hex(col,0));q.addColorStop(.45,my_hex(col,.06));q.addColorStop(.66,my_hex(col,.5));q.addColorStop(.74,'#ffffff90');q.addColorStop(.8,my_hex(col,.4));q.addColorStop(1,my_hex(col,0));g.fillStyle=q;g.fillRect(0,0,256,256);return my_S[k]=c}
function my_void(){if(my_S.vd)return my_S.vd;const [c,g]=my_cv(256,256),q=g.createRadialGradient(128,128,0,128,128,128);q.addColorStop(0,'#0a0722e6');q.addColorStop(.5,'#0c0826b0');q.addColorStop(.8,'#100a2c40');q.addColorStop(1,'#100a2c00');g.fillStyle=q;g.fillRect(0,0,256,256);return my_S.vd=c}
function my_spark(col){const k='s'+col;if(my_S[k])return my_S[k];const [c,g]=my_cv(48,48);g.drawImage(my_glow(col),4,4,40,40);g.fillStyle='#ffffff';g.beginPath();
 const r=21,m=24;g.moveTo(m,m-r);g.quadraticCurveTo(m+2.6,m-2.6,m+r,m);g.quadraticCurveTo(m+2.6,m+2.6,m,m+r);g.quadraticCurveTo(m-2.6,m+2.6,m-r,m);g.quadraticCurveTo(m-2.6,m-2.6,m,m-r);g.fill();return my_S[k]=c}
/* glow strokes: a wide soft pass, the colour, then a white core */
function my_gs(g,col,w,fn){g.strokeStyle=my_hex(col,.22);g.lineWidth=w*4;fn();g.strokeStyle=col;g.lineWidth=w*1.6;fn();g.strokeStyle='#ffffffd0';g.lineWidth=Math.max(.8,w*.55);fn()}
function my_glyph(g,i,s){/* a little rune: stem plus two seeded strokes */const R=k=>my_r(i*7.3+k);g.beginPath();g.moveTo(0,-s);g.lineTo(0,s);
 const a=R(1)<.5?1:-1;g.moveTo(0,-s*.5+R(2)*s*.4);g.lineTo(a*s*.6,-s*.95+R(3)*s*.5);
 if(R(4)<.5){g.moveTo(0,s*.1);g.lineTo(-a*s*.62,s*.55)}else{g.moveTo(-s*.55,R(5)*s*.6-s*.1);g.lineTo(s*.55,R(6)*s*.6-s*.2)}g.stroke()}
function my_rune(th){const k='r'+th.k;if(my_S[k])return my_S[k];const [c,g]=my_cv(512,512);g.translate(256,256);const col=th.rune;
 const ring=r=>()=>{g.beginPath();g.arc(0,0,r,0,TAU);g.stroke()};
 my_gs(g,col,2.4,ring(238));my_gs(g,col,1.2,ring(224));my_gs(g,col,2,ring(166));my_gs(g,col,1.4,ring(98));
 my_gs(g,col,1.6,()=>{g.beginPath();for(let t=0;t<2;t++){for(let i=0;i<=3;i++){const a=-Math.PI/2+i*TAU/3+t*Math.PI,x=Math.cos(a)*166,y=Math.sin(a)*166;i?g.lineTo(x,y):g.moveTo(x,y)}}g.stroke()});
 for(let i=0;i<24;i++){g.save();g.rotate(i*TAU/24);g.translate(0,-195);my_gs(g,col,1.1,()=>my_glyph(g,i,11));g.restore()}
 for(let i=0;i<36;i++){g.save();g.rotate(i*TAU/36);my_gs(g,col,.9,()=>{g.beginPath();g.moveTo(0,-238);g.lineTo(0,-(i%3?232:226));g.stroke()});g.restore()}
 for(let i=0;i<6;i++){const a=-Math.PI/2+i*TAU/6;g.save();g.translate(Math.cos(a)*166,Math.sin(a)*166);my_gs(g,col,1.3,()=>{g.beginPath();g.arc(0,0,9,0,TAU);g.stroke()});g.restore()}
 for(let i=0;i<8;i++){g.save();g.rotate(i*TAU/8+.2);g.translate(0,-62);my_gs(g,col,1,()=>my_glyph(g,i+40,9));g.restore()}
 return my_S[k]=c}
function my_conic(g){if(my_S.cg)return my_S.cg;let q;try{q=g.createConicGradient(0,0,0);my_PR.concat(my_PR[0]).forEach((s,i,a)=>q.addColorStop(i/(a.length-1),s))}catch(e){q=my_PR[0]}return my_S.cg=q}
function my_ring(){if(my_S.ring)return my_S.ring;const [c,g]=my_cv(512,512);let q;
 try{q=g.createConicGradient(0,256,256);my_PR.concat(my_PR[0]).forEach((s,i,a)=>q.addColorStop(i/(a.length-1),s))}catch(e){q=g.createLinearGradient(0,0,512,512);my_PR.forEach((s,i)=>q.addColorStop(i/(my_PR.length-1),s))}
 g.strokeStyle=q;[[44,.12],[26,.22],[13,.5],[6,1]].forEach(([w,a])=>{g.globalAlpha=a;g.lineWidth=w;g.beginPath();g.arc(256,256,210,0,TAU);g.stroke()});
 g.globalAlpha=.85;g.strokeStyle='#ffffff';g.lineWidth=1.6;g.beginPath();g.arc(256,256,210,0,TAU);g.stroke();return my_S.ring=c}
function my_rayG(g,col){const k='rg'+col;if(my_S[k])return my_S[k];const q=g.createRadialGradient(0,0,24,0,0,512);q.addColorStop(0,my_hex(col,.9));q.addColorStop(.35,my_hex(col,.42));q.addColorStop(.75,my_hex(col,.09));q.addColorStop(1,my_hex(col,0));return my_S[k]=q}
/* god rays: a path fill with one cached radial gradient (on a software canvas this is a third of the cost of a big rotated sprite) */
function my_rays(g,x,y,R,col,a,rot,n,sd){if(a<=0)return;g.save();g.translate(x,y);g.rotate(rot);g.scale(R/512,R/512);g.globalAlpha=a;g.fillStyle=my_rayG(g,col);g.beginPath();
 for(let i=0;i<n;i++){const an=i*TAU/n+my_r(i+sd)*.12,w=.03+my_r(i+sd+9)*.055,L=360+my_r(i+sd+3)*150;g.moveTo(Math.cos(an-w*.2)*24,Math.sin(an-w*.2)*24);g.lineTo(Math.cos(an-w)*L,Math.sin(an-w)*L);g.lineTo(Math.cos(an+w)*L,Math.sin(an+w)*L);g.lineTo(Math.cos(an+w*.2)*24,Math.sin(an+w*.2)*24);g.closePath()}
 g.fill();g.restore()}
function my_pillar(th){const k='p'+th.k;if(my_S[k])return my_S[k];const [c,g]=my_cv(128,512),q=g.createLinearGradient(0,0,128,0);
 [[0,'#ff5ad800'],[.16,'#ff5ad855'],[.3,my_hex(th.c,.7)],[.42,my_hex(th.a,.95)],[.5,'#ffffff'],[.58,my_hex(th.a,.95)],[.7,my_hex(th.b,.7)],[.84,'#5ae2ff55'],[1,'#5ae2ff00']].forEach(([o,s])=>q.addColorStop(o,s));
 g.fillStyle=q;g.fillRect(0,0,128,512);g.globalCompositeOperation='destination-in';const v=g.createLinearGradient(0,0,0,512);v.addColorStop(0,'#fff0');v.addColorStop(.3,'#fff9');v.addColorStop(.85,'#fffd');v.addColorStop(1,'#fff');g.fillStyle=v;g.fillRect(0,0,128,512);return my_S[k]=c}
function my_flare(){if(my_S.fl)return my_S.fl;const [c,g]=my_cv(512,48);g.translate(256,24);g.scale(1,24/256);const q=g.createRadialGradient(0,0,0,0,0,256);q.addColorStop(0,'#ffffff');q.addColorStop(.18,'#ffffff90');q.addColorStop(.5,'#ffffff28');q.addColorStop(1,'#ffffff00');g.fillStyle=q;g.beginPath();g.arc(0,0,256,0,TAU);g.fill();return my_S.fl=c}
function my_mandala(th){const k='m'+th.k;if(my_S[k])return my_S[k];const [c,g]=my_cv(512,512);g.translate(256,256);const col=th.a;
 for(let i=0;i<6;i++){g.save();g.rotate(i*TAU/6);my_gs(g,col,2,()=>{g.beginPath();g.moveTo(0,-30);g.lineTo(0,-236);for(let j=1;j<=4;j++){const y=-60-j*40,L=26+(4-j)*10+(j===2?12:0);g.moveTo(0,y);g.lineTo(-L*.8,y-L);g.moveTo(0,y);g.lineTo(L*.8,y-L)}g.stroke()});
  my_gs(g,col,1.4,()=>{g.beginPath();g.moveTo(0,-236);g.lineTo(-9,-222);g.lineTo(0,-208);g.lineTo(9,-222);g.closePath();g.stroke()});g.restore()}
 my_gs(g,col,1.5,()=>{g.beginPath();for(let i=0;i<=6;i++){const a=i*TAU/6;i?g.lineTo(Math.cos(a)*60,Math.sin(a)*60):g.moveTo(Math.cos(a)*60,Math.sin(a)*60)}g.stroke()});
 my_gs(g,th.b,1,()=>{g.beginPath();g.arc(0,0,120,0,TAU);g.stroke()});return my_S[k]=c}
function my_corona(th){const k='c'+th.k;if(my_S[k])return my_S[k];const [c,g]=my_cv(512,512);g.translate(256,256);g.globalCompositeOperation='lighter';
 for(let i=0;i<56;i++){const a=i*TAU/56+my_r(i+20)*.08,L=150+30+my_r(i+60)*(i%4?70:105),w=.03+my_r(i+90)*.05,q=g.createRadialGradient(0,0,140,0,0,L);q.addColorStop(0,my_hex(th.w,.75));q.addColorStop(.35,my_hex(th.a,.45));q.addColorStop(1,my_hex(th.b,0));g.fillStyle=q;
  g.beginPath();g.moveTo(Math.cos(a-w)*146,Math.sin(a-w)*146);g.quadraticCurveTo(Math.cos(a)*L*.7,Math.sin(a)*L*.7,Math.cos(a+w*.2)*L,Math.sin(a+w*.2)*L);g.lineTo(Math.cos(a+w)*146,Math.sin(a+w)*146);g.fill()}
 const q=g.createRadialGradient(0,0,128,0,0,250);q.addColorStop(0,my_hex(th.w,0));q.addColorStop(.09,my_hex(th.w,.95));q.addColorStop(.2,my_hex(th.a,.55));q.addColorStop(.5,my_hex(th.b,.16));q.addColorStop(1,my_hex(th.b,0));g.fillStyle=q;g.beginPath();g.arc(0,0,250,0,TAU);g.fill();
 return my_S[k]=c}
/* the crown of light behind the fish: the halo with the ice mandala (Seraph) or the corona (Eclipse) baked into one
   sprite, so one rotating drawImage replaces two; 512 px across = 1.76 fish px */
function my_crown(th){const k='k'+th.k;if(my_S[k])return my_S[k];const [c,g]=my_cv(512,512);g.globalCompositeOperation='lighter';g.globalAlpha=.85;g.drawImage(my_halo(th.a),0,0,512,512);
 if(th.k==='eclipse'){g.globalAlpha=1;const s=512*1.6/1.76;g.drawImage(my_corona(th),256-s/2,256-s/2,s,s)}else{g.globalAlpha=.55;const s=512*1.72/1.76;g.drawImage(my_mandala(th),256-s/2,256-s/2,s,s)}return my_S[k]=c}
function my_disc(){if(my_S.disc)return my_S.disc;const [c,g]=my_cv(300,300),q=g.createRadialGradient(150,135,10,150,150,140);q.addColorStop(0,'#2c1856');q.addColorStop(.7,'#160c32');q.addColorStop(1,'#07040f');
 g.fillStyle=q;g.beginPath();g.arc(150,150,140,0,TAU);g.fill();for(let i=0;i<60;i++){const a=my_r(i+1500)*TAU,r=Math.sqrt(my_r(i+1600))*128,s=my_r(i+1700)<.12?2.2:1.1;g.globalAlpha=.25+my_r(i+1800)*.55;g.fillStyle=i%6?'#ffffff':'#ffd27a';g.fillRect(150+Math.cos(a)*r,150+Math.sin(a)*r,s,s)}
 g.globalAlpha=1;g.strokeStyle='#fff3cc';g.lineWidth=3;g.beginPath();g.arc(150,150,140,0,TAU);g.stroke();return my_S.disc=c}
function my_shard(){if(my_S.sh)return my_S.sh;const [c,g]=my_cv(64,64);g.translate(32,32);const P=[[0,-28],[8,-12],[7,16],[0,28],[-7,16],[-8,-12]];g.beginPath();P.forEach(([x,y],i)=>i?g.lineTo(x,y):g.moveTo(x,y));g.closePath();
 const q=g.createLinearGradient(-8,-28,8,28);q.addColorStop(0,'#ffffff');q.addColorStop(.45,'#bff4ff');q.addColorStop(1,'#6ab8ff');g.fillStyle=q;g.fill();g.lineWidth=2.4;g.strokeStyle=FKO;g.stroke();
 g.strokeStyle='#ffffffcc';g.lineWidth=1.4;g.beginPath();g.moveTo(0,-24);g.lineTo(0,24);g.moveTo(-5,-10);g.lineTo(-4,12);g.stroke();return my_S.sh=c}
function my_neb(i){const k='n'+i;if(my_S[k])return my_S[k];const [c,g]=my_cv(512,256);g.globalCompositeOperation='lighter';const C=[['#7a3aff','#ff4ab8','#3a6aff','#b46aff'],['#ff4ab8','#8a5aff','#ff9a5a','#5a3aff'],['#3a8aff','#b46aff','#5ae2ff','#ff5ad8']][i%3];
 /* a wisp: soft puffs strung along a curve, then a sprinkle of stars */
 for(let j=0;j<16;j++){const u=j/15,x=40+u*432,y=128+Math.sin(u*Math.PI*1.6+i*2)*46+(my_r(i*31+j)-.5)*30,r=(18+my_r(i*7+j+3)*44)*Math.sin(.15+u*.85*Math.PI),q=g.createRadialGradient(x,y,0,x,y,r),col=C[j%4];q.addColorStop(0,my_hex(col,.3));q.addColorStop(.6,my_hex(col,.12));q.addColorStop(1,my_hex(col,0));g.fillStyle=q;g.beginPath();g.arc(x,y,r,0,TAU);g.fill()}
 g.globalCompositeOperation='source-over';for(let j=0;j<46;j++){const u=my_r(i*53+j),x=40+u*432,y=128+Math.sin(u*Math.PI*1.6+i*2)*46+(my_r(i*59+j)-.5)*70,s=my_r(j+i*3)<.15?2.4:1.3;g.globalAlpha=.4+my_r(j*3+i)*.6;g.fillStyle=j%7?'#ffffff':'#ffe2a8';g.fillRect(x-s/2,y-s/2,s,s)}
 return my_S[k]=c}
function my_drop(){if(my_S.dr)return my_S.dr;const [c,g]=my_cv(16,16),q=g.createRadialGradient(8,8,0,8,8,8);q.addColorStop(0,'#ffffff');q.addColorStop(.5,'#dff4ffcc');q.addColorStop(1,'#dff4ff00');g.fillStyle=q;g.fillRect(0,0,16,16);return my_S.dr=c}
function my_glyphs(th){const k='q'+th.k;if(my_S[k])return my_S[k];const [c,g]=my_cv(48*8,48);for(let i=0;i<8;i++){g.save();g.translate(24+i*48,24);my_gs(g,th.rune,1.5,()=>my_glyph(g,i+70,11));g.restore()}return my_S[k]=c}
const my_FT="400 108px 'Pirata One',Georgia,serif",my_FN="400 60px 'Pirata One',Georgia,serif",my_FS="700 22px Poppins,system-ui,sans-serif";
const my_fontOK=f=>{try{return document.fonts.check(f)}catch(e){return true}};
function my_title(){if(my_S.tt)return my_S.tt;const ok=my_fontOK(my_FT),T='MYTHIC CATCH';let [c,g]=my_cv(10,10);g.font=my_FT;const w=Math.ceil(g.measureText(T).width)+80,h=170;[c,g]=my_cv(w,h);const [c2,g2]=my_cv(w,h);
 [g,g2].forEach(x=>{x.font=my_FT;x.textAlign='center';x.textBaseline='middle'});const X=w/2,Y=h/2+6;
 g.strokeStyle='#ff5ad838';g.lineWidth=30;g.strokeText(T,X,Y);g.strokeStyle='#ff9ae860';g.lineWidth=20;g.strokeText(T,X,Y);g.strokeStyle=FKO;g.lineWidth=13;g.strokeText(T,X,Y);
 const q=g.createLinearGradient(40,0,w-40,0);['#7ae8ff','#a98cff','#ff5ad8','#ff8aa8','#ffd27a','#fff6a8'].forEach((s,i,a)=>q.addColorStop(i/(a.length-1),s));g.fillStyle=q;g.fillText(T,X,Y);
 g.globalCompositeOperation='source-atop';const v=g.createLinearGradient(0,Y-50,0,Y+46);v.addColorStop(0,'#ffffffd8');v.addColorStop(.42,'#ffffff30');v.addColorStop(.5,'#ffffff00');v.addColorStop(.85,'#3a106000');v.addColorStop(1,'#3a106070');g.fillStyle=v;g.fillRect(0,0,w,h);
 g2.fillStyle='#ffffff';g2.fillText(T,X,Y);const r={c,w2:c2,w,h};if(ok)my_S.tt=r;return r}
/* ---------- the show's own particles (live on FS.show.my) ---------- */
function my_add(M,o){if(M.pt.length<200)M.pt.push(o)}
function my_burst(M,x,y,n,k,o){for(let i=0;i<n;i++){const a=o.a!=null?o.a+(Math.random()-.5)*o.sp:Math.random()*TAU,v=o.v*(.35+Math.random()*.9);
 my_add(M,{x:x+(Math.random()-.5)*(o.w||0),y,vx:Math.cos(a)*v,vy:Math.sin(a)*v,g:o.g||0,dr:o.dr||0,life:0,max:o.life*(.6+Math.random()*.7),k,c:o.c||my_PR[i%my_PR.length],r:o.r*(.6+Math.random()*.8),ro:Math.random()*TAU,vr:(Math.random()-.5)*8})}}
function my_ptDraw(g,M,dt,rm){const L=M.pt;g.save();g.globalCompositeOperation='lighter';
 for(let i=L.length-1;i>=0;i--){const p=L[i];p.life+=dt;if(p.life>=p.max){L.splice(i,1);continue}const u=p.life/p.max,dk=Math.pow(1-p.dr,dt*60);p.vx*=dk;p.vy=p.vy*dk+p.g*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.ro+=p.vr*dt*(rm?.2:1);
  const a=Math.min(1,(1-u)*1.8);g.globalAlpha=a;
  if(p.k==='drop'){const s=p.r*2.4;g.drawImage(my_drop(),p.x-s/2,p.y-s/2,s,s)}
  else if(p.k==='spark'){const s=p.r*4*(1-u*.4);g.drawImage(my_spark(p.c),p.x-s/2,p.y-s/2,s,s)}}
 g.globalCompositeOperation='source-over';
 for(const p of L){if(p.k!=='shard')continue;const u=p.life/p.max;g.globalAlpha=Math.min(1,(1-u)*2);const s=p.r*6;g.save();g.translate(p.x,p.y);g.rotate(p.ro);g.drawImage(my_shard(),-s/2,-s/2,s,s);g.restore()}
 g.restore()}
/* ---------- timeline ---------- */
const my_HX=760,my_HY=392,my_T={erupt:.92,arrive:1.75,title:1.85,name:2.2,fadeA:5.5,fadeB:6.6,glideA:5.75,glideB:7.45};
function my_fishPos(el,S,px,t,rm){const T=my_T,x0=S.x0,y0=S.y0;let x,y,s,rot=0,sx=1,al=1,wh=0;
 if(el<T.erupt){return null}
 if(el<T.arrive){const u=(el-T.erupt)/(T.arrive-T.erupt),e=my_eo(u),ey=1-Math.pow(1-u,2.4);x=x0+(my_HX-x0)*my_ss(.22,1,u);y=y0+14+(my_HY-y0-14)*ey;s=.22+.78*my_back(u*1.02);
  const sp=rm?0:(1-my_eo(u*1.05))*TAU*1.5;sx=Math.cos(sp);if(Math.abs(sx)<.06)sx=sx<0?-.06:.06;rot=rm?0:-.35*(1-e);wh=1-my_ss(.15,.85,u);al=my_ss(0,.12,u)}
 else if(el<T.glideA){const b=rm?.4:1;x=my_HX+Math.sin(t*.9)*6*b;y=my_HY+Math.sin(t*1.7)*9*b;s=1+Math.sin(t*2.1)*.012*b;rot=Math.sin(t*1.2)*.035*b;
  const k=el-T.arrive;if(k<.5){/* settle overshoot */s*=1+.06*Math.sin(k/.5*Math.PI)*(1-k/.5)}}
 else{const u=my_cl((el-T.glideA)/(T.glideB-T.glideA),0,1),e=u*u*(3-2*u),hx=my_HX+Math.sin(t*.9)*6,hy=my_HY;x=hx+(FSPV.x-hx)*e;y=hy+(FSPV.y-hy)*e-Math.sin(u*Math.PI)*80;s=1-.7*e;rot=Math.sin(u*Math.PI)*.22;al=1-my_ss(.86,1,u)}
 return {x,y,s,rot,sx,al,wh,sc:px/210*s}}
/* ---------- the spectacle ---------- */
function my_show(g,el){/* the fx pass sits under the scene's dim, so the spectacle is painted in the pass after fsScene (below) */}
function my_draw(g,el){const S=FS.show;if(!S||!S.c)return;const c=S.c,th=my_th(c.id),rm=!!(FS.view&&FS.view.rm),t=fsNow(),T=my_T,px=fsFishPx(c),x0=S.x0,y0=S.y0;
 const M=S.my||(S.my={pt:[],le:el,b:{}});const dt=my_cl(el-M.le,0,.05);M.le=el;const id=FISHART[c.id]?c.id:'aurora',rs=rm?.15:1;
 const F=1-my_ss(T.fadeA,T.fadeB,el),rev=my_ss(1.0,1.9,el)*F,P=my_fishPos(el,S,px,t,rm);
 /* one-time bursts (skips land after these) */
 if(!M.b.e&&el>=T.erupt&&el<T.erupt+.3){M.b.e=1;const n=rm?.5:1;my_burst(M,x0,y0,32*n|0,'drop',{a:-Math.PI/2,sp:1.1,v:820,g:1100,life:1.3,r:3.4,w:40});my_burst(M,x0,y0,22*n|0,'spark',{a:-Math.PI/2,sp:.5,v:760,g:-60,dr:.04,life:1.4,r:3.2,w:60})}
 if(!M.b.a&&el>=T.arrive&&el<T.arrive+.3&&P){M.b.a=1;const n=rm?.5:1;my_burst(M,P.x,P.y,28*n|0,'spark',{v:520,dr:.05,g:30,life:1.5,r:3.6});if(th.k==='seraph')my_burst(M,P.x,P.y,10*n|0,'shard',{v:420,dr:.045,g:90,life:1.9,r:2.6});else my_burst(M,P.x,P.y,16*n|0,'spark',{v:300,dr:.03,g:0,life:2,r:2.4,c:th.a})}
 g.save();g.globalAlpha=1;g.globalCompositeOperation='lighter';
 /* sky layer: aurora curtains (Seraph) or nebula clouds (Eclipse) */
 if(rev>.01){if(th.k==='eclipse')my_nebula(g,t*rs,P,px,rev);else my_aurora(g,t*rs,rev,th)}
 /* falling prismatic glitter over the whole field */
 if(rev>.01){for(let i=0;i<18;i++){const sp=.05+my_r(i+300)*.07,yy=((el*sp*(rm?.4:1)+my_r(i+200))%1)*960-40,xx=40+my_r(i+100)*1120+Math.sin(t*rs*.8+i)*18,tw=.5+.5*Math.sin(t*3*rs+i*1.7),s=6+my_r(i+400)*9;g.globalAlpha=rev*.75*tw;g.drawImage(my_spark(my_PR[i%7]),xx-s/2,yy-s/2,s,s)}}
 /* the water at the bobber: glow, rune portal, reflection of the pillar */
 const po=my_ss(.08,.8,el)*(1-my_ss(1.9,2.9,el));
 if(po>0){const gr=110+150*my_ss(0,.9,el)+(el>T.erupt?120*(1-my_ss(T.erupt,T.erupt+.8,el)):0),pul=1+.06*Math.sin(t*9*rs);g.globalAlpha=po;g.save();g.translate(x0,y0);g.scale(1,.32);g.drawImage(my_glow(th.a),-gr*pul,-gr*pul,gr*2*pul,gr*2*pul);
  const rr=200*my_back(my_ss(.05,.75,el)*1)*(1+.12*my_ss(T.erupt,T.erupt+.4,el));g.rotate(t*.9*rs);g.globalAlpha=po*.95;g.drawImage(my_rune(th),-rr,-rr,rr*2,rr*2);g.rotate(-t*2.1*rs);g.globalAlpha=po*.8;g.drawImage(my_ring(),-rr*.62,-rr*.62,rr*1.24,rr*1.24);g.restore();
  g.globalAlpha=po*.7;g.drawImage(my_glow('#ffffff'),x0-34,y0-12,68,24)}
 /* motes drawn into the portal */
 if(el<T.erupt+.15){const n=rm?12:26,ma=my_ss(.05,.35,el)*(1-my_ss(T.erupt,T.erupt+.15,el));for(let i=0;i<n;i++){const u=((el*(rm?.6:1.35))+my_r(i+500))%1,R0=230+my_r(i+520)*260,r=R0*Math.pow(1-u,1.6),a=my_r(i+540)*TAU+u*2.4*(rm?.4:1),x=x0+Math.cos(a)*r,y=y0-20+Math.sin(a)*r*.5,s=4+u*9;g.globalAlpha=ma*Math.min(1,u*4);g.drawImage(my_spark(my_PR[i%7]),x-s/2,y-s/2,s,s)}}
 /* the pillar of light */
 if(el>=T.erupt-.12){const k=el-T.erupt,pa=k<0?my_ss(-.12,0,k)*.5:1-my_ss(.7,1.7,k),w=k<0?10+k*-40:(k<.12?30+k/.12*190:220-110*my_ss(.12,.6,k))*(1+.06*Math.sin(t*30*rs));
  if(pa>0){const P2=my_pillar(th);g.globalAlpha=pa;g.drawImage(P2,x0-w/2,-30,w,y0+36);g.globalAlpha=pa*.9;g.drawImage(P2,x0-w*.18,-30,w*.36,y0+36);g.globalAlpha=pa*.35;g.save();g.translate(x0,y0+4);g.scale(1,-.42);g.drawImage(P2,-w/2,0,w,(900-y0)/.42);g.restore();
   g.globalAlpha=pa;g.drawImage(my_glow(th.w),x0-w*1.6,y0-w*.5,w*3.2,w);g.drawImage(my_flare(),x0-w*3,y0-14,w*6,28)}}
 /* shockwaves on the water */
 for(const [t0,r1,du] of [[T.erupt,560,1.1],[T.erupt+.12,380,.9]]){const u=(el-t0)/du;if(u<0||u>=1)continue;const r=20+(r1-20)*my_eo(u);g.globalAlpha=(1-u)*.9;g.strokeStyle=th.w;g.lineWidth=7*(1-u)+1;g.beginPath();g.ellipse(x0,y0,r,r*.3,0,0,TAU);g.stroke();g.strokeStyle=my_hex(th.a,.4);g.lineWidth=18*(1-u)+2;g.stroke()}
 /* behind the fish: god rays, halo, the themed crown of light and the prismatic ring */
 if(P&&rev>.01){const hx=P.x,hy=P.y,R=px*1.25*(.9+.1*my_ss(1,2,el));
  my_rays(g,hx,hy,R*1.4,th.ray,rev*(th.k==='eclipse'?.5:.42),t*.12*rs,16,0);my_rays(g,hx,hy,R*1.0,'#ffa8ec',rev*.34,1-t*.31*rs,10,50);
  {const cx=th.k==='eclipse'?hx+px*.02:hx,cy=th.k==='eclipse'?hy-px*.06:hy,cr=px*.88;g.globalAlpha=rev;g.save();g.translate(cx,cy);g.rotate((th.k==='eclipse'?.05:-.08)*t*rs);g.drawImage(my_crown(th),-cr,-cr,cr*2,cr*2);g.restore()}
  if(th.k==='eclipse'){const cx=hx+px*.02,cy=hy-px*.06,cr=px*.5;
   g.globalCompositeOperation='source-over';g.globalAlpha=rev*.92;g.drawImage(my_disc(),cx-cr*1.07,cy-cr*1.07,cr*2.14,cr*2.14);g.globalCompositeOperation='lighter';
   const fa=-.75+Math.sin(t*.4*rs)*.06,fx=cx+Math.cos(fa)*cr,fy=cy+Math.sin(fa)*cr,fl=.75+.25*Math.sin(t*5*rs);g.globalAlpha=rev*fl;g.drawImage(my_glow(th.w),fx-46,fy-46,92,92);g.drawImage(my_flare(),fx-px*.9,fy-12,px*1.8,24);g.save();g.translate(fx,fy);g.rotate(Math.PI/2);g.globalAlpha=rev*fl*.5;g.drawImage(my_flare(),-px*.35,-8,px*.7,16);g.restore()}
  else{/* a deep night pool right behind the fish so its pale crystal art reads against the light */g.globalCompositeOperation='source-over';g.globalAlpha=rev*.9;g.drawImage(my_void(),hx-px*.72,hy-px*.6,px*1.44,px*1.2);g.globalCompositeOperation='lighter'}
  const rr=px*.78*(1+.02*Math.sin(t*2));g.globalAlpha=rev*.85;g.save();g.translate(hx,hy);g.rotate(t*.5*rs);g.drawImage(my_ring(),-rr,-rr,rr*2,rr*2);g.restore();
  if(th.k==='eclipse')my_dust(g,t*rs,hx,hy,px,rev);
  my_orbit(g,t*rs,hx,hy,px,rev,th,0)}
 /* arrival shockwave ring around the fish */
 {const u=(el-T.arrive)/.8;if(P&&u>=0&&u<1){const r=px*(.35+1.1*my_eo(u));g.save();g.translate(P.x,P.y);g.strokeStyle=my_conic(g);g.beginPath();g.arc(0,0,r,0,TAU);g.globalAlpha=(1-u)*.25;g.lineWidth=26*(1-u)+4;g.stroke();g.globalAlpha=(1-u)*.95;g.lineWidth=7*(1-u)+1.5;g.stroke();g.strokeStyle='#ffffff';g.lineWidth=1.5;g.stroke();g.restore();
  if(u<.4){const k=1-u/.4,w=px*.7;g.globalAlpha=k*.5;g.drawImage(my_glow(th.w),P.x-w,P.y-w,w*2,w*2)}}}
 /* the fish */
 if(P){const ga=P.al*(1-rev*.85)*.5;if(ga>.06){g.globalAlpha=ga;g.drawImage(my_glow(th.a,1),P.x-px*.62*P.s,P.y-px*.5*P.s,px*1.24*P.s,px*P.s)}g.globalCompositeOperation='source-over';
  if(el<T.arrive){/* a pool of night behind the rising fish so it reads inside the white pillar */const va=my_ss(T.erupt+.08,T.erupt+.4,el)*.85,w=px*P.s;if(va>0){g.globalAlpha=va;g.drawImage(my_void(),P.x-w*.72,P.y-w*.6,w*1.44,w*1.2)}}
  g.save();g.globalAlpha=P.al;g.translate(P.x,P.y);g.rotate(P.rot);g.scale(P.sc*P.sx,P.sc);my_fish(g,M,id,px,t,el<T.arrive?.9:.3,th.k==='seraph'&&el>=T.arrive?.45:1);g.restore();
  g.globalCompositeOperation='lighter';if(P.wh>.01){/* born of light: a white bloom over the fish fades away */const w=px*P.s;g.globalAlpha=P.wh;g.drawImage(my_glow('#ffffff'),P.x-w*.55,P.y-w*.4,w*1.1,w*.8);g.globalAlpha=P.wh*.6;g.drawImage(my_glow(th.w),P.x-w*.8,P.y-w*.55,w*1.6,w*1.1)}
  if(el>T.glideA&&el<T.glideB){for(let k=1;k<7;k++){const Q=my_fishPos(el-k*.055,S,px,t,rm);if(!Q)break;const s=12-k;g.globalAlpha=(1-k/7)*.8*P.al;g.drawImage(my_spark(my_PR[k%7]),Q.x-s/2+(my_r(k)-.5)*30*Q.s,Q.y-s/2+(my_r(k+5)-.5)*20*Q.s,s,s)}}}
 if(P&&rev>.01){my_orbit(g,t*rs,P.x,P.y,px,rev,th,1);if(th.k==='seraph')my_shards(g,t*rs,P.x,P.y,px,rev)}
 my_ptDraw(g,M,dt,rm);
 /* the eruption flash */
 g.globalCompositeOperation='source-over';
 if(!rm){const u=(el-T.erupt)/.32;if(u>=0&&u<1){g.globalAlpha=.62*(1-u)*(1-u);g.fillStyle=u<.25?'#ffffff':'#ffd8f6';g.fillRect(-20,-20,1640,940)}}
 else{const u=(el-T.erupt)/.6;if(u>=0&&u<1){g.globalAlpha=.18*Math.sin(u*Math.PI);g.fillStyle='#ffe8fa';g.fillRect(-20,-20,1640,940)}}
 g.restore();
 my_text(g,el,c,px,th,t,rm);}
/* the fish is big, so its art is painted into one reused bitmap about 20 times a second and placed every frame (smooth motion, lighter frames) */
function my_fish(g,M,id,px,t,flex,gl){if(!my_S.fc)my_S.fc=my_cv(720,600);const [c,fg]=my_S.fc,S=Math.min(1.12*px/210,720/320,600/260);
 if(M.fcT==null||t-M.fcT>(flex>.5?.033:.05)||t<M.fcT||M.fcS!==S){fg.setTransform(1,0,0,1,0,0);fg.clearRect(0,0,720,600);fg.setTransform(S,0,0,S,160*S,130*S);fishDraw(fg,id,{t,flex,glow:gl==null?1:gl});M.fcT=t;M.fcS=S}
 g.drawImage(c,0,0,320*S,260*S,-160,-130,320,260)}
/* aurora curtains across the sky */
/* aurora curtains across the sky (polygon fills with cached gradients; cheaper than sliding strip sprites) */
function my_aurora(g,t,a,th){if(!my_S.ag){my_S.ag=[['#7affd8','#5ae2ff','#b48aff','#ff7ae0','#7affd8'],['#b48aff','#7affd8','#ff9ae8','#5ae2ff','#b48aff']].map(cs=>{const q=g.createLinearGradient(0,0,1300,0);cs.forEach((s,i)=>q.addColorStop(i/4,s));return q})}
 for(let b=0;b<3;b++){const y0=96+b*58,H=60+b*16;g.beginPath();for(let i=0;i<=32;i++){const x=-40+i*42,y=y0+Math.sin(i*.33+t*.9+b*2.1)*28+Math.sin(i*.12-t*.5+b)*18;i?g.lineTo(x,y):g.moveTo(x,y)}
  for(let i=32;i>=0;i--){const x=-40+i*42,y=y0+H+Math.sin(i*.33+t*.9+b*2.1)*28+Math.sin(i*.12-t*.5+b)*18+Math.sin(i*.6+t*1.3)*10;g.lineTo(x,y)}g.closePath();g.fillStyle=my_S.ag[b%2];g.globalAlpha=a*(.2-b*.035);g.fill()}
 for(let i=0;i<22;i++){const x=-20+i*58+Math.sin(t*.7+i)*14,y=110+Math.sin(i*.33+t*.9)*28,h=90+my_r(i+800)*80,s=.5+.5*Math.sin(t*1.6+i*1.3);g.globalAlpha=a*.1*s;g.fillStyle=my_S.ag[0];g.fillRect(x,y,7,h)}}
/* nebula clouds drifting around the leviathan */
function my_nebula(g,t,P,px,a){const hx=P?P.x:my_HX,hy=P?P.y:my_HY;for(let i=0;i<2;i++){const an=[-2.65,-.4][i]+Math.sin(t*.1+i)*.12,R=px*(1.05+my_r(i+900)*.25),x=hx+Math.cos(an)*R*1.1,y=hy+Math.sin(an)*R*.5-20,s=px*(.72+my_r(i+920)*.16);
 g.globalAlpha=a*(.75+.25*Math.sin(t*.8+i));g.save();g.translate(x,y);g.rotate(an*.35+Math.sin(t*.13+i)*.1);g.drawImage(my_neb(i),-s,-s*.5,s*2,s);g.restore()}}
/* galaxy dust swirling around the leviathan */
function my_dust(g,t,hx,hy,px,a){g.fillStyle='#ffffff';for(let i=0;i<48;i++){const R=px*(.62+my_r(i+1000)*.75),an=my_r(i+1100)*TAU+t*(.5/(.6+R/px)),ex=Math.cos(an)*R,ey=Math.sin(an)*R*.3,x=hx+ex*.97+ey*.25,y=hy-ex*.25*.97+ey*.97,s=1.4+my_r(i+1200)*2.2;
 g.globalAlpha=a*(.35+.65*Math.max(0,Math.sin(t*2+i)))*(Math.sin(an)>0?1:.55);g.fillStyle=i%5?'#ffffff':i%2?'#ffd27a':'#c4a8ff';g.fillRect(x-s/2,y-s/2,s,s)}}
/* the orbit of stars and runes (front=1 draws the near half) */
function my_orbit(g,t,hx,hy,px,a,th,front){const R=px*.86,ry=.26,tl=-.14,ct=Math.cos(tl),st=Math.sin(tl),n=12,GL=my_glyphs(th);
 g.globalAlpha=a*.35;g.strokeStyle=th.a;g.lineWidth=1.6;g.beginPath();g.ellipse(hx,hy,R,R*ry,tl,front?0:Math.PI,front?Math.PI:TAU);g.stroke();
 for(let i=0;i<n;i++){const an=t*.55+i*TAU/n,sn=Math.sin(an);if((sn>0)!==!!front)continue;const ex=Math.cos(an)*R,ey=sn*R*ry,x=hx+ex*ct-ey*st,y=hy+ex*st+ey*ct,dp=.78+.3*sn;g.globalAlpha=a*(.55+.45*(sn+1)/2);
  if(i%2){const s=18*dp*(1+.25*Math.sin(t*4+i));g.drawImage(my_spark(my_PR[i%7]),x-s/2,y-s/2,s,s)}else{const s=30*dp,gi=(i/2)%8;g.drawImage(GL,gi*48,0,48,48,x-s/2,y-s/2,s,s)}}}
/* ice crystal shards circling the seraph */
function my_shards(g,t,hx,hy,px,a){g.save();g.globalCompositeOperation='source-over';const SH=my_shard();for(let i=0;i<9;i++){const an=i*TAU/9+t*.22,R=px*(1.0+.18*Math.sin(t*.7+i*1.9)),x=hx+Math.cos(an)*R*1.08,y=hy+Math.sin(an)*R*.58+Math.sin(t*1.3+i)*8,s=(34+my_r(i+1300)*22)*(.85+.15*Math.sin(an));
 g.globalAlpha=a*.92;g.save();g.translate(x,y);g.rotate(an+Math.PI/2+Math.sin(t+i)*.4);g.drawImage(SH,-s/2,-s/2,s,s);g.restore()}g.restore()}
/* MYTHIC CATCH, the fish name letter by letter and its line */
function my_text(g,el,c,px,th,t,rm){const T=my_T;if(el<T.title)return;const out=1-my_ss(5.25,5.85,el);if(out<=0)return;const S=FS.show,M=S.my;
 const k=(el-T.title)/.5,sc=k<1?1.32-.32*my_back(k):1,a=my_ss(0,.3,el-T.title)*out,TT=my_title(),y=190-(1-out)*26;
 g.save();if(k<1&&k>=0){g.globalCompositeOperation='lighter';g.globalAlpha=(1-k)*.8;g.drawImage(my_flare(),my_HX-520,y-26,1040,52);g.drawImage(my_glow('#ff9ae8'),my_HX-240,y-80,480,160);g.globalCompositeOperation='source-over'}
 g.globalAlpha=a;g.translate(my_HX,y);g.scale(sc,sc);g.drawImage(TT.c,-TT.w/2,-TT.h/2);
 /* the shimmer sweep */
 const sw=((el-T.title-.35)%2.2)/.9;if(sw>=0&&sw<1&&!rm){const bx=-TT.w/2-120+(TT.w+240)*sw;g.save();g.beginPath();g.moveTo(bx,-TT.h/2);g.lineTo(bx+70,-TT.h/2);g.lineTo(bx+20,TT.h/2);g.lineTo(bx-50,TT.h/2);g.closePath();g.clip();g.globalCompositeOperation='lighter';g.globalAlpha=a*.75;g.drawImage(TT.w2,-TT.w/2,-TT.h/2);g.restore()}
 g.restore();
 /* name: animated letter by letter, then cached as one sprite once it has settled */
 if(el<T.name)return;const nm=FISH[c.id]?FISH[c.id].n:'Mythic fish',L=[...nm],ny=my_HY+px*.4+78-(1-out)*14,done=T.name+L.length*.045+.75;
 if(el>=done&&M.nm&&M.nm.ok){if(!M.nc){if(!my_S.ncv)my_S.ncv=my_cv(1300,160);const [nc,ng]=my_S.ncv;ng.setTransform(1,0,0,1,0,0);ng.clearRect(0,0,1300,160);my_name(ng,c,L,650,60,99,M,rm,1);M.nc=Math.min(1300,Math.ceil(Math.max(M.nm.W,(M.nm.lw||0)*2+260)+60))}
  const w=M.nc;g.save();g.globalAlpha=out;g.drawImage(my_S.ncv[0],650-w/2,0,w,160,my_HX-w/2,ny-60,w,160);g.restore();return}
 my_name(g,c,L,my_HX,ny,el,M,rm,out)}
function my_name(g,c,L,cx,ny,el,M,rm,out){const T=my_T;g.save();g.translate(cx,ny);g.font=my_FN;g.textBaseline='middle';g.textAlign='left';
 if(!M.nm||!M.nm.ok){const ws=L.map(ch=>g.measureText(ch).width);M.nm={ws,W:ws.reduce((s,v)=>s+v,0),ok:my_fontOK(my_FN)}}
 if(!my_S.nq){const q=g.createLinearGradient(0,-26,0,24);q.addColorStop(0,'#ffffff');q.addColorStop(.55,'#fff4fd');q.addColorStop(1,'#ffc4ee');my_S.nq=q}
 let x=-M.nm.W/2;g.lineWidth=10;g.strokeStyle=FKO;g.fillStyle=my_S.nq;
 for(let i=0;i<L.length;i++){const w=M.nm.ws[i],u=my_cl((el-T.name-i*.045)/.3,0,1);if(u>0&&L[i]!==' '){const e=my_back(u),s=rm?1:1.7-.7*e;g.save();g.globalAlpha=out*Math.min(1,u*2);g.translate(x+w/2,(1-e)*-14*(rm?0:1));g.scale(s,s);g.strokeText(L[i],-w/2,0);g.fillText(L[i],-w/2,0);g.restore()}x+=w}
 /* the line under the name */
 const nd=T.name+L.length*.045+.12,lu=my_ss(nd,nd+.55,el);if(lu>0){const lc=FISH[c.id]&&FISH[c.id].loc&&FSLOCS[FISH[c.id].loc],tx=`${c.cm} cm${c.g?' · GIANT':''}${lc?'  ·  only at '+lc.n:''}`,yy=44;
  g.font=my_FS;g.textAlign='center';g.globalAlpha=out*lu;g.lineWidth=6;g.strokeStyle=FKO;g.strokeText(tx,0,yy);g.fillStyle='#ffc8f2';g.fillText(tx,0,yy);
  const tw=g.measureText(tx).width/2+26,ln=90*lu;M.nm.lw=tw;g.strokeStyle='#ff9ae8';g.lineWidth=2;g.beginPath();g.moveTo(-tw,yy);g.lineTo(-tw-ln,yy);g.moveTo(tw,yy);g.lineTo(tw+ln,yy);g.stroke();
  g.globalCompositeOperation='lighter';[[-tw-ln,yy],[tw+ln,yy],[-tw+8,yy],[tw-8,yy]].forEach(([x2,y2],j)=>{const s=j<2?16:10;g.drawImage(my_spark(j<2?'#ff5ad8':'#ffffff'),x2-s/2,y2-s/2,s,s)})}
 g.restore()}
/* build the sprites a frame at a time while a Mythic is on the line, so the show starts without a hitch */
function my_warm(c){const th=my_th(c.id),W=[()=>my_glow(th.a),()=>my_glow(th.a,1),()=>my_glow(th.w),()=>my_glow('#ffffff'),()=>my_glow('#ff9ae8'),()=>my_rune(th),()=>my_ring(),()=>my_pillar(th),()=>my_flare(),()=>my_drop(),()=>my_glyphs(th),()=>my_title(),
 ()=>th.k==='eclipse'?my_corona(th):my_mandala(th),()=>th.k==='eclipse'?my_disc():my_shard(),()=>my_halo(th.a),()=>my_crown(th),()=>my_void(),()=>my_neb(0),()=>my_neb(1),()=>my_neb(2)].concat(my_PR.map(s=>()=>my_spark(s)),[()=>my_spark('#ffffff')]);
 const k='w'+th.k;my_S[k]=my_S[k]||0;if(my_S[k]<W.length){W[my_S[k]++]()}}
/* ---------- hooks ---------- */
{const o=fsShowFx;fsShowFx=function(g,el){if(FS.show&&FS.show.c&&FS.show.c.rk==='m')return my_show(g,el);return o(g,el)}}
{const o=fsScene;fsScene=function(g,t,V){o(g,t,V);if(!V||V!==FS.view)return;try{if(FS.st==='show'&&FS.show&&FS.show.c&&FS.show.c.rk==='m')my_draw(g,fsNow()-FS.t0);else if((FS.st==='reel'||FS.st==='stage')&&FS.cur&&FS.cur.rk==='m')my_warm(FS.cur)}catch(e){if(!my_S.err){my_S.err=1;console.error(e)}}}}
/* the scene: darkness, the moon, a gentle shake only at the eruption, the hero bracing on a taut line then cheering (the
   cheer eases down before the reveal) */
function fsMythicView(V,el,d){const T=my_T,rm=!!V.rm,dn=my_ss(0,.7,el)*(1-my_ss(5.9,7.3,el));V.dim=(.82-.1*my_ss(1.2,2.2,el))*dn;V.moonUp=dn;
 V.shake=0;if(!rm){if(el>.45&&el<T.erupt)V.shake=1.6*my_ss(.45,T.erupt,el);else if(el>=T.erupt&&el<T.erupt+.7)V.shake=13*Math.pow(1-(el-T.erupt)/.7,2)}
 V.cheer=el>T.erupt+.08?1:0;V.cheerU=my_cl(Math.min((el-T.erupt-.08)*2.2,(d-el)/.45),0,1);if(el<T.erupt){/* braced against a taut line into the portal (90e draws the line; the rod springs carry it in and out) */V.rodA=-.95-.06*Math.sin(el*5);V.bend=.95}}
/* sounds: a held breath and a rising shimmer, the eruption chord, then a shimmering chord (1.2 s) and a fanfare (2.6 s) */
{const o=fsSfx;fsSfx=function(k,x){if(k!=='m1')return o(k,x);const S=FS.show,ok=at=>FS.show===S&&FS.st==='show'&&fsNow()-FS.t0<at+.3,B=(f,du,ty,v,at)=>setTimeout(()=>{if(at>.05&&!ok(at))return;try{beep(f,du,ty,v)}catch(e){}},(at||0)*1000);
 B(55,1.1,'sine',.7);B(82,1,'sine',.45,.02);[262,330,392,494,587,698,880,1047].forEach((f,i)=>B(f,.3,'sine',.12+i*.03,.06+i*.1));
 B(65,.8,'sawtooth',.25,.92);B(131,.7,'triangle',.45,.92);[523,659,784,1047].forEach(f=>B(f,1,'triangle',.32,.92));B(2093,.6,'sine',.22,.95);
 [1568,1865,2093,2489,2794,3136,3729].forEach((f,i)=>B(f,.4,'sine',.2,1.2+i*.035));[784,988,1175,1568].forEach(f=>B(f,1.5,'sine',.2,1.22));
 [1047,1319,1568,2093].forEach((f,i)=>B(f,.65,'triangle',.36,2.6+i*.1));[2637,3136,3951].forEach((f,i)=>B(f,.9,'sine',.16,3.05+i*.06))}}
