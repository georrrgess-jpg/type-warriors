/* ===== UPDATE 10.4, HARVEST MOON RUSH: the mode (99r3, prefix flr) =====
   A limited-time Endless variant for the Harvest Festival, built the way Monster Mash is (84c): it runs on the normal Endless engine
   (levels, rounds, bosses, boons, boon swaps, crates) with the Monster Mash hooks (S.gy is set too, so the per-letter pill drawing, the
   HUD chip, the mode tick, the fair WPM clock and the run summary dispatch work as they do there) and S.flr picks the harvest content:
   the fields (99r2, lvDef), the cast (99r, the spawn pool), the words, the boss lines, the payout and the twists below.
   Every level brings a seasonal twist on the words; they rotate like the Monster Mash curses and boss rounds are twist-free:
     Gusty Wind      (the Pumpkin Patch) gusts sweep the field and tumble the letters out of line for a moment (the next letter holds still);
     Thieving Crows  (the Corn Maze) a crow perches on one letter; type it and the crow steals it, so that letter is typed again;
     Leaf Piles      (the Moonlit Orchard) a pile of leaves covers part of every word and blows away when you reach it (or at halfway).
   From level 4 they grow a little: gusts come more often, piles cover three letters of long words, long words carry two crows.
   Pay: gold x1.35 (normal Endless pays x0.9, so +50%), XP +30%, and the festival's own rewards: a Harvest Chest and acorns for every
   boss, acorns dropped by monsters, and one-time milestone rewards for the deepest level reached. They are banked during the run and
   paid when it ends (fleGive / flcAdd from the festival and chest parts); if a part is missing they wait in P.flrb until it is there.
   Companions keep their powers here (in Monster Mash they are cosmetic).
   Small edits in base files where a const or an inline expression had to learn about the mode (marked FLR, backups *.v12bak):
   10_data.js lvDef (the fields), 50_game.js the spawn pool and the gold multiplier in gain() and the round-gold float, 70a_modes.js
   modeLabel (the HUD line), 62b_bestiary.js the Catalog section, 62c_mastery.js the mastery ids (the bosses) and group. */
const FLRK=1.35,FLRXP=1.3;
const FLRPAY={bossA:lv=>Math.min(80,25+5*lv),chest:1,dropN:.05,dropE:.3,dropEA:2,ms:[{lv:3,a:60,c:0},{lv:5,a:100,c:1},{lv:8,a:150,c:1},{lv:12,a:250,c:2}]};
const flrOn=()=>{try{return typeof flOn==='function'&&!!flOn()}catch(e){return false}};
const flrLeft=()=>{try{return flLeft()}catch(e){return''}};
/* ---------- save (P.flrb), repaired whenever it is read ---------- */
const flrInt=(v,mx)=>{v=Math.floor(Number(v));return isFinite(v)&&v>0?Math.min(v,mx||1e9):0};
function flrB(){if(!P)return{best:0,lv:0,runs:0,ac:0,ch:0,ms:[],pa:0,pc:0,tip:{}};let b=P.flrb;if(!b||typeof b!=='object'||Array.isArray(b))b={};
 const ms=Array.isArray(b.ms)?[...new Set(b.ms.map(x=>flrInt(x,999)).filter(x=>FLRPAY.ms.some(m=>m.lv===x)))].sort((x,y)=>x-y):[];
 const tip={};if(b.tip&&typeof b.tip==='object')for(const k of FLR_SEQ)if(b.tip[k])tip[k]=1;
 const r={best:flrInt(b.best,1e10),lv:flrInt(b.lv,9999),runs:flrInt(b.runs,1e7),ac:flrInt(b.ac,1e8),ch:flrInt(b.ch,1e6),ms,pa:flrInt(b.pa,1e6),pc:flrInt(b.pc,1e4),tip};
 P.flrb=r;return r}
{const l0=load;load=function(){const r=l0.apply(this,arguments);try{if(P&&P.flrb!==undefined)flrB()}catch(e){}return r}}
/* ---------- the twists ---------- */
const FLRT={
 flgust:{n:'Gusty Wind',d:'Gusts sweep the field and tumble the letters out of line. The next letter always holds still.',c:'#a8e0ff',s:'Gusts tumble the letters. The next letter holds still.'},
 flleaf:{n:'Leaf Piles',d:'Fallen leaves cover part of every word. They blow away when you reach them, or once the monster is halfway.',c:'#ffa040',s:'Leaves hide letters until you reach them, or halfway.'},
 flcrow:{n:'Thieving Crows',d:'A crow perches on one letter. Type it and the crow steals it, so type that letter again.',c:'#c8a8ff',s:'Type a crow\'s letter and it steals it. Type it again.'}};
/* 10.4b: s is the short line for the level banner (the full sentence ran 1,050-1,200 px wide, into the twist chip as it slid in) */
const FLR_SEQ=['flgust','flcrow','flleaf'];/* Pumpkin Patch: gusts; Corn Maze: the crows; Moonlit Orchard: the leaves */
for(const k of FLR_SEQ)GYC[k]={n:FLRT[k].n,d:FLRT[k].d,c:FLRT[k].c,ic:'✦'};/* so the Monster Mash round-start hook can read them */
{const g0=gyCurseFor;gyCurseFor=function(lv){return S&&S.flr?[FLR_SEQ[(Math.max(1,lv)-1)%3]]:g0.apply(this,arguments)}}
const flrTw=()=>S&&S.flr&&S.gyc&&S.round!==5?S.gyc[0]:'';
const flrHash=(a,b)=>{let x=((a*73856093)^(b*19349663))>>>0;x^=x>>>13;x=Math.imul(x,1274126177)>>>0;return(x>>>0)/4294967296};
/* give a fresh word its twist */
function flrTwistWord(e){e.fd=1;e.fp=null;e.fpr=null;e.fcs=null;e.fcD=null;const k=flrTw(),w=e.w,L=w?w.length:0,lv=lvOf(S.wave);
 if(!k||e.boss||!w||w.includes(' ')||L<3||(e.mn&&L<4))return;
 if(k==='flleaf'&&L>=4){const n=lv>=4&&L>=7?3:2,a=1+Math.floor(Math.random()*(L-n));e.fp=[a,a+n-1]}
 else if(k==='flcrow'){const lo=1,hi=L-2;if(hi<lo)return;const a=lo+Math.floor(Math.random()*(hi-lo+1));e.fcs=[a];e.fcD=[];
  if(lv>=4&&L>=8){let b=a;for(let q=0;q<8&&Math.abs(b-a)<2;q++)b=lo+Math.floor(Math.random()*(hi-lo+1));if(Math.abs(b-a)>=2)e.fcs.push(b);e.fcs.sort((x,y)=>x-y)}}}
/* gusts: one sweeps the field every few seconds while the Gusty Wind is on */
const flrGustEvery=()=>lvOf(S.wave)>=4?3.9:5.4;
function flrGustStep(dt){const G=S.flrG||(S.flrG={t0:-99,dur:1.5,next:2.4,warn:0});if(flrTw()!=='flgust'||S.ban||S.mode!=='play'){return}
 G.next-=dt;if(G.next<=.5&&!G.warn){G.warn=1;flrSfx('whistle')}
 if(G.next<=0){G.t0=S.t;G.dur=1.5;G.next=flrGustEvery()+Math.random()*1.2;G.warn=0;G.n=(G.n||0)+1;flrSfx('gust')}}
/* how far a gust has pushed letter i of e (0 when calm) */
function flrGustOff(e,i,cx){const G=S.flrG;if(!G)return null;const u=(S.t-G.t0)/G.dur;if(!(u>0&&u<1.2))return null;const xn=Math.max(0,Math.min(1,cx/W)),q=u*1.35-(1-xn)*.35;if(q<=0||q>=1)return null;
 const env=Math.sin(q*Math.PI),k=(lvOf(S.wave)>=4?1.2:1)*(flrRM()?.6:1),h1=flrHash((e.ph*1e3)|0,i),h2=flrHash(i+7,(e.ph*517)|0);
 /* 10.4b: the letters bob up and down inside the tag and tilt, but barely drift sideways, so they never leave the tag or slide over a
    neighbour (at 3-10 px sideways and 6-14 px up or down they left the tag and two letters could read as one, "rn" as "m") */
 return{dx:-env*(1+h1*2.2)*k,dy:env*(h1<.5?-Math.min(9.5,(5.5+h2*4)*k):Math.min(7.5,(4.5+h2*3)*k)),r:flrRM()?0:env*(h2-.5)*.9*k}}
/* ---------- per-letter drawing for word pills (the pill calls gyPillChar while S.gy is set) ---------- */
let FLRPW=13.4;
{const p0=gyPillChar;gyPillChar=function(e,i,ch,cx,cy,col,tgt){if(!S.flr)return p0.apply(this,arguments);return flrPillChar(e,i,ch,cx,cy,col,tgt)}}
function flrPillChar(e,i,ch,cx,cy,col,tgt){const c=ctx,typed=i<e.i,next=tgt&&i===e.i,pw=typeof PW==='number'?PW:13.4;FLRPW=pw;
 /* leaf pile: the covered letters are not drawn; the pile is drawn once over its slots */
 if(e.fp&&!e.fpr&&i>=e.fp[0]&&i<=e.fp[1]){if(i===e.fp[0])flrPileDraw(e,cx,cy,pw);return i}
 let fill=typed?col:'#fff',sc=1,a=1;
 if(e.fcD&&e.fcD.includes(i)&&!typed){fill=next?'#ffe08a':'#ffc860'}else if(e.fcs&&e.fcs.includes(i)&&!typed)fill='#cfb2ff';
 if(e.fpr&&i>=e.fp[0]&&i<=e.fp[1]){const u=Math.min(1,(S.t-e.fpr)/.32);sc=.6+.4*flrSm(u);a=u;if(!typed&&u<1)fill='#ffe0a8'}
 /* 10.4b: the first untyped letter of every word holds still, not only on the target, so each word can still be picked out by its start */
 let off=null;if(flrTw()==='flgust'&&!typed&&i!==e.i)off=flrGustOff(e,i,cx);
 const ga=c.globalAlpha;if(a<1)c.globalAlpha=ga*a;c.fillStyle=fill;
 if(off||sc!==1){c.save();c.translate(cx+pw/2+(off?off.dx:0),cy+(off?off.dy:0));if(off)c.rotate(off.r);if(sc!==1)c.scale(sc,sc);c.fillText(ch,-pw/2,0);c.restore()}else c.fillText(ch,cx,cy);
 if(a<1)c.globalAlpha=ga;
 /* a crow perched on its letter, waiting */
 if(e.fcs&&e.fcs.includes(i)&&!(e.fcD&&e.fcD.includes(i))&&!typed){const o=flrPerchSpr(flrCy(S.t+e.ph,3.4)<.35?1:0);const bob=Math.abs(Math.sin(S.t*2+e.ph+i))*1.4;c.globalAlpha=ga;flrBlit(c,o,cx+pw/2-2,cy-19-bob)/* 10.4b: feet over the letter (they sat 7 px to its right) */}
 return i}
/* the baked perched crow (two frames: quiet and cawing) and the leaf piles */
/* 10.4b: a moonlit lavender rim around the crow (baked: the crow's silhouette tinted and stamped at eight offsets under it), so the dark
   crow reads against the dark sky and the corn instead of vanishing */
function flrPerchSpr(caw){return flrSpr('pcrow'+caw,56,44,28,38,g=>{const q=g.createRadialGradient(0,-12,2,0,-12,24);q.addColorStop(0,'#d8c0ff80');q.addColorStop(1,'#d8c0ff00');g.fillStyle=q;g.fillRect(-28,-38,56,44);
 const t=document.createElement('canvas');t.width=112;t.height=88;const h=t.getContext('2d');h.setTransform(2,0,0,2,56,76);h.lineJoin='round';flrCrow(h,1,-9,.95,null,caw,true);h.setTransform(1,0,0,1,0,0);h.globalCompositeOperation='source-in';h.fillStyle='#d6c2ff';h.fillRect(0,0,112,88);
 for(let k=0;k<8;k++){const a=k*TAU/8;g.drawImage(t,-28+Math.cos(a)*1.3,-38+Math.sin(a)*1.3,56,44)}flrCrow(g,1,-9,.95,null,caw,true)})}
/* 10.4b: the pile fits its own letter slots (n x the letter pitch) and stays inside the tag: the old pile was n*16+22 px wide and
   48 tall, so it half-covered the letters on either side (a visible letter hidden) and hung out of the tag */
function flrPileSpr(n,pw){pw=pw||13.4;const w=n*pw+2,key='pile'+n+'_'+Math.round(pw*10);return flrSpr(key,w+8,40,(w+8)/2,22,g=>{
 const mound=()=>{g.beginPath();g.moveTo(-w/2,13);g.bezierCurveTo(-w/2,-4,-w*.3,-15,0,-15);g.bezierCurveTo(w*.3,-15,w/2,-4,w/2,13);g.closePath()};
 mound();g.fillStyle=vgr(g,-15,13,'#7a3a16','#3a180a');g.fill();g.save();mound();g.clip();
 for(let k=0;k<n*7+4;k++){const L=flrLeaf(k%6),x=(flrHash(k,n)-.5)*(w-4),y=10-flrHash(n,k+3)*24*(1-Math.abs(x)/w*1.2);g.save();g.translate(x,y);g.rotate(flrHash(k+5,n)*TAU);g.drawImage(L.c,-8,-8,16,16);g.restore()}
 g.restore();mound();g.strokeStyle=FLRO;g.lineWidth=1.6;g.stroke();g.strokeStyle='#ffc86055';g.lineWidth=1;g.beginPath();g.moveTo(-w*.32,-9);g.quadraticCurveTo(0,-15.5,w*.32,-9);g.stroke()})}
function flrPileDraw(e,cx,cy,pw){const n=e.fp[1]-e.fp[0]+1,o=flrPileSpr(n,pw),c=ctx,mid=cx+n*pw/2;c.save();c.translate(mid,cy+2);c.rotate(Math.sin(S.t*3+e.ph)*.015);flrBlit(c,o,0,0);c.restore()}
/* ---------- the run's moving extras: leaves blown off piles, stolen letters, acorn and chest pickups ---------- */
function flrFx(o){const L=S.flrFx||(S.flrFx=[]);if(L.length<120)L.push(Object.assign({t:0},o))}
function flrFxStep(dt){const L=S.flrFx;if(!L||!L.length)return;for(const f of L){f.t+=dt;if(f.vx!=null){f.x+=f.vx*dt;f.y+=f.vy*dt;f.vy+=(f.gr||0)*dt;f.r=(f.r||0)+(f.vr||0)*dt}}S.flrFx=L.filter(f=>f.t<f.ml)}
function flrFxDraw(c){const L=S.flrFx;if(!L||!L.length)return;c.save();
 for(const f of L){const u=f.t/f.ml;
  if(f.k==='leaf'){c.globalAlpha=1-u*u;flrLeafAt(c,f.n,f.x,f.y,.8,f.r,Math.cos(f.t*9+f.n))}
  else if(f.k==='crow'){/* the crow flies off with the letter in its beak */const e1=flrSm(Math.min(1,u*1.3)),x=f.x+e1*240,y=f.y-e1*170-Math.sin(u*Math.PI)*30;c.globalAlpha=Math.min(1,(1-u)*3);flrCrow(c,x,y,.9,Math.sin(f.t*26),0,false);
   c.font='bold 22px ui-monospace,Menlo,Consolas,monospace';c.textAlign='center';c.textBaseline='middle';c.lineWidth=4;c.strokeStyle=FLRO;c.strokeText(f.ch,x-22,y+4);c.fillStyle='#ffc860';c.fillText(f.ch,x-22,y+4);
   if(u<.3){c.globalAlpha=(.3-u)/.3;c.strokeStyle='#ffe8a0';c.lineWidth=2;for(let i=0;i<5;i++){const a=i*TAU/5;c.beginPath();c.moveTo(f.x-22+Math.cos(a)*8,f.y+4+Math.sin(a)*8);c.lineTo(f.x-22+Math.cos(a)*(16+u*40),f.y+4+Math.sin(a)*(16+u*40));c.stroke()}}}
  else if(f.k==='acorn'||f.k==='chest'){const e1=flrSm(u),x=f.x+(f.tx-f.x)*e1,y=f.y+(f.ty-f.y)*e1-Math.sin(u*Math.PI)*(f.k==='chest'?160:90);c.globalAlpha=u>.9?(1-u)*10:1;c.save();c.translate(x,y);c.rotate(f.k==='acorn'?f.t*8:Math.sin(f.t*6)*.2);const s=f.k==='chest'?1.5-u*.5:1;c.scale(s,s);flrBlit(c,f.k==='chest'?flrChestIco():flrAcornIco(),0,0);c.restore()}
  else if(f.k==='ring'){c.globalAlpha=(1-u)*.8;c.strokeStyle=f.c;c.lineWidth=4*(1-u)+1;c.beginPath();c.arc(f.x,f.y,10+u*(f.r||80),0,TAU);c.stroke()}}
 c.restore()}
/* small icons for the HUD and the pickups */
function flrAcornIco(){return flrSpr('iacorn',30,34,15,18,g=>{g.beginPath();g.moveTo(-9,-3);g.bezierCurveTo(-10,7,-3,12,0,14);g.bezierCurveTo(3,12,10,7,9,-3);g.closePath();g.fillStyle=rgr(g,-3,0,1,14,'#e0a050','#9a5a1e');g.fill();g.strokeStyle=FLRO;g.lineWidth=1.8;g.stroke();
 g.beginPath();g.ellipse(0,-4,11,6,0,0,TAU);g.fillStyle='#6a4a26';g.fill();g.strokeStyle=FLRO;g.lineWidth=1.8;g.stroke();g.strokeStyle='#4a321a';g.lineWidth=1;for(let i=-2;i<=2;i++){g.beginPath();g.arc(i*4,-5,2.4,Math.PI*.1,Math.PI*.9);g.stroke()}limb(g,0,-9,2,-15,2.4,'#4a321a');g.fillStyle='#ffffff40';g.beginPath();g.ellipse(-4,3,2,4,0,0,TAU);g.fill()})}
function flrChestIco(){return flrSpr('ichest',44,40,22,22,g=>{g.beginPath();g.roundRect(-18,-6,36,22,4);g.fillStyle=vgr(g,-6,16,'#c8964a','#7a5228');g.fill();g.strokeStyle=FLRO;g.lineWidth=2;g.stroke();
 g.strokeStyle='#5a3a1a';g.lineWidth=1.2;for(let i=-12;i<=12;i+=6){g.beginPath();g.moveTo(i,-4);g.lineTo(i,14);g.stroke()}
 g.beginPath();g.moveTo(-19,-6);g.quadraticCurveTo(0,-20,19,-6);g.closePath();g.fillStyle=vgr(g,-18,-6,'#d8a85a','#8a5a2a');g.fill();g.strokeStyle=FLRO;g.lineWidth=2;g.stroke();
 g.strokeStyle='#3a6a2a';g.lineWidth=2.4;g.beginPath();g.moveTo(-18,-2);g.bezierCurveTo(-8,4,6,-8,18,0);g.stroke();
 g.beginPath();g.ellipse(0,-3,6,5.4,0,0,TAU);g.fillStyle='#f08a2a';g.fill();g.strokeStyle=FLRO;g.lineWidth=1.4;g.stroke();limb(g,0,-8,1,-10.5,1.8,'#4a5a1e')})}
/* the twist icons for the HUD chip and the mode page */
function flrTwIco(k){return flrSpr('itw'+k,36,36,18,18,g=>{g.beginPath();g.arc(0,0,16,0,TAU);g.fillStyle=FLRT[k].c+'40';g.fill();g.strokeStyle=FLRT[k].c+'aa';g.lineWidth=1.4;g.stroke();if(k==='flgust'){g.strokeStyle='#d8f0ff';g.lineWidth=2.6;for(const [y,l] of[[-7,22],[0,28],[7,18]]){g.beginPath();g.moveTo(-14,y);g.lineTo(-14+l*.6,y);g.arc(-14+l*.6,y-4,4,Math.PI/2,-Math.PI*.9,true);g.stroke()}flrLeafAt(g,1,10,8,.42,.6,1)}
 else if(k==='flleaf'){for(let i=0;i<5;i++)flrLeafAt(g,i,(i-2)*5,4-Math.abs(i-2)*3,.62,i*1.3,1)}
 else{/* 10.4b: a pale moon behind the crow, which was dark on dark */g.beginPath();g.arc(4,-4,10.5,0,TAU);g.fillStyle='#e6dafc';g.fill();g.strokeStyle=FLRO;g.lineWidth=1.2;g.stroke();flrCrow(g,1,3,.78,null,1,true)}})}
/* ---------- sound (synthesised, like the rest of the game) ---------- */
function flrSfx(k){try{if(!axOn())return;const n=ac.currentTime;
 if(k==='gust'){cNoise(sg,n,1.5,.07,{type:'bandpass',f1:380,f2:1500,q:.9,a:.45});cNoise(sg,n+.2,1.1,.035,{type:'highpass',f1:2400,f2:900,a:.3})}
 else if(k==='whistle'){cTone(sg,n,700,.45,'sine',.018,{f2:1100,a:.2})}
 else if(k==='caw'){cTone(sg,n,640,.13,'sawtooth',.045,{f2:390,lp:1700});cTone(sg,n+.17,600,.15,'sawtooth',.04,{f2:350,lp:1500});cNoise(sg,n,.25,.015,{type:'bandpass',f1:1200,f2:800})}
 else if(k==='rustle'){cNoise(sg,n,.4,.04,{type:'highpass',f1:2600,f2:5200,a:.03})}
 else if(k==='acorn'){cTone(sg,n,1180,.07,'triangle',.05);cTone(sg,n+.06,1580,.1,'triangle',.04)}
 else if(k==='chest'){cBell(sg,n,nf(72),.05,1.2);cBell(sg,n+.13,nf(76),.045,1.2);cBell(sg,n+.26,nf(79),.05,1.6);cKick(sg,n,.08,90,50,.25)}
 else if(k==='mile'){for(let i=0;i<4;i++)cBell(sg,n+i*.11,nf(67+[0,4,7,12][i]),.04,1.4)}}catch(e){}}
/* ---------- run flow ---------- */
{const m0=modeSetup;modeSetup=function(kind){if(kind!=='flr')return m0.apply(this,arguments);
 S.gy=1;S.flr=1;S.gyc=[];S.gyH=0;S.flrA=0;S.flrC=0;S.flrM=[];S.flrK=0;S.flrFx=[];S.flrG={t0:-99,dur:1.5,next:2.4,warn:0};S.flrLvB=0}}
{const a0=modeAfter;modeAfter=function(kind){if(kind==='flr')return;return a0.apply(this,arguments)}}
{const sw=startWave;startWave=function(){const r=sw.apply(this,arguments);
  if(S.flr){const lv=lvOf(S.wave),k=FLR_SEQ[(lv-1)%3],q=FLRT[k],L=FLRLV[(lv-1)%3];S.gyc=[k];S.gyLv=lv;S.flrG={t0:-99,dur:1.5,next:2.6,warn:0,n:(S.flrG&&S.flrG.n)||0};
   if(S.round===1){S.ban={t:4.2,txt:'Level '+lv+': '+L.n,c:L.a,sub:q.n+': '+q.s};/* 10.4b: the level title in the field's own colour (the twist colour made the Pumpkin Patch title ice blue) */
    const B=flrB(),m=FLRPAY.ms.find(x=>x.lv===lv);if(m&&!B.ms.includes(lv)&&!S.flrM.includes(lv)){S.flrM.push(lv);S.flrMT=S.t+4.4;flrSfx('mile')}
    /* 10.4b: the first time, the banner (which already carries the twist's description) stays a second longer; the tip box that
     repeated the same sentence right above it is gone */
    if(!flrB().tip[k]){flrB().tip[k]=1;S.ban.t=5.2}}
   else if(S.round===5){S.ban.sub=(S.ban.sub?S.ban.sub+'. ':'')+'No twist this round.'}}
  return r}}
{const sb=shieldBreak;shieldBreak=function(t){sb.apply(this,arguments);t.fd=0;t.fp=null;t.fpr=null;t.fcs=null;t.fcD=null}}
{const mt=modeTick;modeTick=function(dt){if(!S.flr)return mt.apply(this,arguments);
 /* a resumed run may hold a curse from another mode: keep the level's twist */
 const lv=lvOf(S.wave),k=FLR_SEQ[(lv-1)%3];if(!S.gyc||S.gyc[0]!==k)S.gyc=[k];
 for(const e of S.en){if(!e.fd&&e.w)flrTwistWord(e);
  if(e.fp&&!e.fpr&&(e.i>=e.fp[0]||e.x<=(W+KX)/2)){e.fpr=Math.max(S.t,.001);flrPileBurst(e)}}
 flrGustStep(dt);flrFxStep(dt)}}
/* the leaves fly off the word when its pile blows away */
function flrPileBurst(e){try{const g=pillGeom(e),pw=typeof PW==='number'?PW:13.4,x0=g.x+14+e.fp[0]*pw,n=e.fp[1]-e.fp[0]+1,cy=g.y+g.h/2;for(let i=0;i<n*4+2;i++)flrFx({k:'leaf',n:i%6,x:x0+Math.random()*n*pw,y:cy+4,vx:-60+Math.random()*260,vy:-180-Math.random()*160,gr:420,vr:(Math.random()-.5)*12,r:Math.random()*6,ml:.9+Math.random()*.4});if(S.t-(S.flrRs||-9)>.25){S.flrRs=S.t;flrSfx('rustle')}}catch(x){}}
/* Thieving Crows: typing the crow's letter lets the crow steal it, and the cursor steps back onto it */
{const k0=key;key=function(c){const t=S&&S.flr&&S.mode==='play'?S.tgt:null,i0=t?t.i:-1;const r=k0.apply(this,arguments);
 try{if(t&&t.fcs&&S.en.includes(t)&&t.i>i0){for(const ci of t.fcs){if(i0<=ci&&t.i>ci&&!t.fcD.includes(ci)&&ci<t.w.length-1){t.fcD.push(ci);t.i=ci;const g=pillGeom(t),pw=typeof PW==='number'?PW:13.4;flrFx({k:'crow',x:g.x+14+ci*pw+pw/2+22,y:g.y+g.h/2-4,ch:t.w[ci],ml:1.15})/* 10.4b: the stolen letter starts on its own slot (it started 22 px left, over the letter before) */;flrSfx('caw');S.flrSt=(S.flrSt||0)+1;break}}}}catch(x){}
 return r}}
/* harvest words: the themed list first, the general list only fills a length gap */
const FLRW=('acorn acorns apple apples orchard cider harvest pumpkin pumpkins gourd gourds squash maple maples leaf leaves autumn fall corn cornfield cornstalk scarecrow straw hay haystack hayride bale bales barn barnyard tractor wagon cart field fields farm farmer farmhouse plow furrow reap reaper sickle wheat grain barley oats rye sheaf sheaves mill miller flour bread loaf pie pies crust pecan pecans walnut chestnut hazelnut nuts squirrel turkey turkeys gobble gobbler feather feathers feast feasting banquet table supper dinner gravy stuffing cranberry cranberries yam yams potato potatoes carrot carrots turnip parsnip beet beets onion cabbage pear pears plum plums grape grapes vine vines vineyard basket baskets bushel crate barrel barrels jar jam jelly honey cinnamon nutmeg clove ginger spice spiced cocoa cozy sweater scarf mitten mittens quilt blanket hearth fireside ember embers candle lantern lanterns moon moonlight moonlit twilight dusk dawn frost frosty chill chilly breeze gust gusty wind windy amber golden russet crimson scarlet copper bronze rust ochre maize kernel kernels husk husks cob cobs popcorn hayloft silo stable pasture meadow hedge hedgerow thicket grove oak oaks pinecone bough branch branches twig twigs bark root roots mushroom fern moss crow crows raven owl owls goose geese flock migrate rabbit hare deer fox foxes badger hedgehog chipmunk mouse thanks thankful gratitude grateful blessing family friends gather gathering together share plenty bounty bountiful abundance cornucopia horn festival fair parade pilgrim maze sunflower sunflowers hollow fruit ripe ripen picking cellar pantry kettle oven baker baking roast roasted butter biscuit muffin cobbler crumble sauce soup stew porridge oatmeal syrup caramel toffee fudge pudding nutcracker rake raking bonfire smoke woodpile firewood axe cabin porch rocking chair').split(/\s+/).filter((w,i,a)=>w.length>=3&&w.length<=12&&/^[a-z]+$/.test(w)&&a.indexOf(w)===i);
{const pw=pickWord,GS=new Set(FLRW);pickWord=function(role,zi,d,on){if(!S||!S.flr||Array.isArray(zi))return pw.apply(this,arguments);let w;for(let i=0;i<8;i++){w=pw(role,FLRW,d,on);if(GS.has(w))return w}return w}}
/* boss sentences with a harvest flavour (half of them), the shared generator for the rest */
const FLRBL=['the harvest moon has risen for you','no field is safe when the crows are hungry','every pumpkin in the patch is watching you','tonight you will stand guard in the corn','the corn has eyes and the corn remembers','the feast begins and you are on the table','the wild hunt rides when the moon is gold','i have gathered a hundred harvests','the orchard keeps every seed it is given','run through the maze and never find the end','the leaves fall and so will you','your name is carved on the last pumpkin','the scarecrow never sleeps and never blinks','the cider is sweet but your fate is bitter','my vines will wrap you like a winter quilt','every gust of wind carries your scent to me','the crows have counted your steps','nothing leaves the patch before the frost','the moon is full and so is my larder','bring your thanks and leave your hope','the hay is dry and the night is long','you are the last apple on the bough','i will grind your courage into flour','the old oak drops one more acorn tonight'];
{const b0=bossLine;bossLine=function(L,tier,used){if(!S||!S.flr||Math.random()<.5)return b0.apply(this,arguments);const u=new Set(used||[]),pool=FLRBL.filter(x=>!u.has(x));if(!pool.length)return b0.apply(this,arguments);return pool[Math.random()*pool.length|0]}}
/* summoned minions and boss minions come from the harvest cast: summons are fast (crows, sprites, pies), a boss calls walkers that stand and fight (like the goblins it replaces) */
const FLR_MIN=['flrcrow','flrpie','flrmaple'],FLR_BMIN=['flrscare','flracorn','flrpie'];
{const a0=addMob;addMob=function(src,id,dx,short,mn){if(S&&S.flr&&!/^flr/.test(id))id=FLR_MIN[Math.random()*FLR_MIN.length|0];return a0.call(this,src,id,dx,short,mn)}}
{const m0=mkMinion;mkMinion=function(e){const n=S.en.length;const r=m0.apply(this,arguments);try{if(S.flr&&S.en.length>n){const m=S.en[S.en.length-1];if(m&&m.mn&&!/^flr/.test(m.id)){const id=FLR_BMIN[Math.random()*FLR_BMIN.length|0],M=MON[id];m.id=id;m.h=M.h;m.sp=M.sp*K;m.hv=M.fly?50+Math.random()*80:0;m.tr=null;m.shd=0;if(M.tr&&M.tr!=='summon')initTr(m,M)}}}catch(x){}return r}}
/* companions keep their powers in this mode (petPowerMode leaves out every S.gy run, so it is asked without S.gy) */
if(typeof petRunInit==='function'){const r0=petRunInit;petRunInit=function(){if(S&&S.flr&&S.gy){S.gy=0;try{return r0.apply(this,arguments)}finally{S.gy=1}}return r0.apply(this,arguments)}}
/* ---------- rewards during the run ---------- */
/* where the pickups fly to: the run's acorn and chest counters in the HUD */
const flrHudY=()=>S.round===5?(ST&&ST.fps?176:152)+14:(ST&&ST.fps?186:162)+48+16,FLR_HUDA=()=>[W-212,flrHudY()],FLR_HUDC=()=>[W-102,flrHudY()];
{const d0=gyDrop;gyDrop=function(e){if(!S.flr)return d0.apply(this,arguments);if(S.mode!=='play'&&S.mode!=='over')return;const lv=lvOf(S.wave),y0=e.y-e.h*.6;
 if(e.boss){const a=FLRPAY.bossA(lv),c=FLRPAY.chest;S.flrA+=a;S.flrC+=c;S.flrLvB=lv;flrFx({k:'chest',x:e.x,y:y0,tx:FLR_HUDC()[0],ty:FLR_HUDC()[1],ml:1.3});for(let i=0;i<5;i++)flrFx({k:'acorn',x:e.x+(i-2)*24,y:y0,tx:FLR_HUDA()[0],ty:FLR_HUDA()[1],ml:1+i*.08});
  flrFx({k:'ring',x:e.x,y:y0,c:'#ffd27a',r:200,ml:.7});float(e.x,e.y-e.h-150,'Harvest Chest!','#ffd27a',46);float(e.x,e.y-e.h-104,'+'+a+' acorns','#ffb060',32);flrSfx('chest');return}
 if(e.mn)return;const el=!!e.el,q=el?FLRPAY.dropE:FLRPAY.dropN;if(Math.random()<q){const n=el?FLRPAY.dropEA:1;S.flrA+=n;S.flrK++;flrFx({k:'acorn',x:e.x,y:y0,tx:FLR_HUDA()[0],ty:FLR_HUDA()[1],ml:.95});float(e.x,e.y-e.h-90,'+'+n+' acorn'+(n>1?'s':''),'#ffb060',26);setTimeout(()=>flrSfx('acorn'),700)}}}
/* ---------- HUD: the twist chip, the gust gauge and the run's acorns and chests ---------- */
{const h0=gyHud;gyHud=function(c){if(!S.flr)return h0.apply(this,arguments);if(S.mode==='title')return;flrHud(c)}}
function flrHud(c){const k=S.gyc&&S.gyc[0],q=FLRT[k],boss=S.round===5,y=ST&&ST.fps?186:162;c.save();
 /* the twist chip (hidden in boss rounds, where the boss's name and sentence need the room) */
 if(q&&!boss){c.fillStyle='rgba(14,8,32,.78)';c.beginPath();c.roundRect(W-300,y,286,40,11);c.fill();c.strokeStyle=q.c+'bb';c.lineWidth=1.6;c.stroke();
  flrBlit(c,flrTwIco(k),W-280,y+17);c.textAlign='right';c.textBaseline='middle';c.font='21px "Pirata One",Georgia,serif';c.fillStyle=q.c;c.fillText(q.n,W-26,y+17);
  if(k==='flgust'&&S.flrG){const G=S.flrG,gu=flrGustAmt(),f=gu>0?1:Math.max(0,Math.min(1,1-G.next/flrGustEvery()));c.fillStyle='#ffffff18';c.fillRect(W-258,y+31,236,4);c.fillStyle=gu>0?'#ffffff':G.next<.6&&Math.floor(S.t*8)%2?'#ffffff':q.c;c.fillRect(W-258,y+31,236*f,4)}}
 /* the run's harvest: acorns and chests banked so far */
 const ry=flrHudY()-16;c.fillStyle='rgba(14,8,32,.72)';c.beginPath();c.roundRect(W-230,ry,216,32,10);c.fill();c.strokeStyle='#ffb64866';c.lineWidth=1.2;c.stroke();
 c.textAlign='left';c.textBaseline='middle';c.font='bold 18px Poppins,system-ui,sans-serif';flrBlit(c,flrAcornIco(),W-212,ry+16);c.fillStyle='#ffd8a0';c.fillText(String(S.flrA||0),W-194,ry+17);
 flrBlit(c,flrChestIco(),W-102,ry+16);c.fillStyle='#ffe6b0';c.fillText(String(S.flrC||0),W-76,ry+17);
 /* milestone note */
 if(S.flrMT&&S.t<S.flrMT+3.2&&S.t>S.flrMT-.1){const m=FLRPAY.ms.find(x=>x.lv===S.flrM[S.flrM.length-1]);if(m){const u=Math.min(1,(S.t-S.flrMT)/.35),a=Math.min(1,(S.flrMT+3.2-S.t)/.4);c.globalAlpha=a;c.save();c.translate(W/2,flrMileY());c.scale(.7+.3*flrSm(u)+(u<1?.08*Math.sin(u*Math.PI):0),.7+.3*flrSm(u));
  c.fillStyle='rgba(20,10,30,.86)';c.beginPath();c.roundRect(-260,-34,520,68,18);c.fill();c.strokeStyle='#ffd27a';c.lineWidth=2;c.stroke();c.textAlign='center';c.font='28px "Pirata One",Georgia,serif';c.fillStyle='#ffd27a';c.fillText('Milestone: level '+m.lv+' reached',0,-10);
  c.font='600 16px Poppins,system-ui,sans-serif';c.fillStyle='#fff0d0';c.fillText('+'+m.a+' acorns'+(m.c?` and ${m.c} Harvest Chest${m.c>1?'s':''}`:'')+' when the run ends',0,16);c.restore();c.globalAlpha=1}}
 c.restore();flrFxDraw(c)}
{const v0=gyVignette;gyVignette=function(c){if(!S.flr)return v0.apply(this,arguments)}}
/* ---------- the end of a run ---------- */
function flrPayIt(a,ch){let pa=0,pc=0;try{if(a>0){if(typeof fleGive==='function'){fleGive(a,'Harvest Moon Rush')}else pa=a}}catch(e){pa=a}try{if(ch>0){if(typeof flcAdd==='function'){flcAdd(ch,'Harvest Moon Rush')}else pc=ch}}catch(e){pc=ch}return{pa,pc}}
/* acorns or chests that could not be handed over yet (a part missing) are paid the next time the mode page opens */
function flrPayPending(){const B=flrB();if(!(B.pa>0||B.pc>0))return;const a=B.pa,c=B.pc;B.pa=0;B.pc=0;const r=flrPayIt(a,c);B.pa+=r.pa;B.pc+=r.pc;save()}
function flrPay(){const B=flrB();let a=S.flrA||0,c=S.flrC||0;const got=[];for(const lv of S.flrM||[]){const m=FLRPAY.ms.find(x=>x.lv===lv);if(m&&!B.ms.includes(lv)){a+=m.a;c+=m.c;B.ms.push(lv);got.push(m)}}B.ms.sort((x,y)=>x-y);
 B.ac+=a;B.ch+=c;const r=flrPayIt(a,c);B.pa+=r.pa;B.pc+=r.pc;return{a,c,got}}
{const o0=gyOver;gyOver=function(quit){if(!S.flr)return o0.apply(this,arguments);return flrOver(quit)}}
function flrOver(quit){if(S.mode==='over')return;S.mode='over';const xp=xpMode(Math.round((S.score/16+S.wave*8)*xpMulRun()*FLRXP*ENDXP)),xn=xpNoteH(),B=flrB(),nb=S.score>(B.best||0),l0=finishRun(),wxm=wxpEnd(),lv=lvOf(S.wave),nl=lv>(B.lv||0);
 P.xp+=xp;if(nb)B.best=S.score;B.lv=Math.max(B.lv||0,lv);B.runs++;const pay=flrPay(),l1=lvl(P.xp),cr=S.runC||0,lg=levelGold(l0,l1);save();jingle('lose');
 const later=()=>{S.mode='over';const on=flrOn(),nch=P.fcr||0;show(`<div class="flrov"><h2>The harvest is in</h2>${resBlock()}
  <div class="flrpay"><span><b>${xp.toLocaleString()}</b><i>XP</i></span><span><b>${(S.gold+lg).toLocaleString()}</b><i>gold</i></span><span class="fa">${flrSvgAcorn(26)}<b>${pay.a.toLocaleString()}</b><i>acorns</i></span><span class="fc">${flrSvgChest(30)}<b>${pay.c}</b><i>Harvest Chest${pay.c===1?'':'s'}</i></span>${cr?`<span><b>${cr}</b><i>crate${cr===1?'':'s'}</i></span>`:''}</div>
  <p>${nb?'<b class="flrnb">New Harvest Moon Rush record!</b> ':''}Reached level ${lv}, round ${S.round} of 5.${nl&&!nb?' <b class="flrnb">Deepest level yet.</b>':''} Best: level ${B.lv}.${S.by&&!quit?` Felled by ${esc(S.by)}.`:''}${pay.got.length?`<br><b class="flrnb">Milestone${pay.got.length>1?'s':''}:</b> ${pay.got.map(m=>`level ${m.lv} (+${m.a} acorns${m.c?`, ${m.c} chest${m.c>1?'s':''}`:''})`).join(', ')}.`:''}${xn}${wxm}${l1>l0?`<br><b style="color:var(--gold)">Level up! You are now level ${l1}, ${rankOf(l1)}. Bonus: ${lg} gold.</b>`:''}${pathMsg(l0,l1)}</p>
  <div class="row"><button id="flrgo">${on?'Rush again':'Back to Home'}</button>${nch>0&&typeof flcOpenUI==='function'?`<button class="sm gd" id="flrch">Open ${nch} Harvest Chest${nch===1?'':'s'}</button>`:''}${typeof fleHub==='function'&&flShopOn()?'<button class="sm" id="flrfe">Harvest Festival</button>':''}<button class="sm" id="flrhm">Home</button></div></div>`);
  $('flrgo').onclick=()=>flrOn()?start(0,'flr'):title();$('flrhm').onclick=title;if($('flrch'))$('flrch').onclick=()=>flcOpenUI();if($('flrfe'))$('flrfe').onclick=()=>fleHub()};
 if(quit)later();else{S.pose='dead';S.poseT=0;S.landed=0;S.late=later;S.lateAt=2.2}}
/* ---------- labels in the pause menu and the resume offer, and Restart starting this mode again ---------- */
{const p0=pauseMenu;pauseMenu=function(){const r=p0.apply(this,arguments);try{if(S.flr){const p=ov.querySelector('h2+p');if(p&&p.firstChild&&p.firstChild.nodeType===3)p.firstChild.textContent=p.firstChild.textContent.replace('Monster Mash','Harvest Moon Rush');
  const b=$('rs2');if(b){const h=b.onclick;b.onclick=e=>{const t=e.target;if(t.dataset.a){S.mode='play';start(0,'flr')}else h(e)}}}}catch(e){}return r}}
{const l0=rsLabel;rsLabel=function(r){if(r&&r.S&&r.S.flr)return`Harvest Moon Rush, level ${lvOf(r.wave)}, round ${r.round} of 5`;return l0.apply(this,arguments)}}
RS_SKIP.add('flrFx');
/* ---------- small inline icons for HTML ---------- */
const flrSvgAcorn=(s)=>`<svg class="flric" viewBox="0 0 32 36" width="${s}" height="${s}" aria-hidden="true"><path d="M7 15c-1 9 6 14 9 16 3-2 10-7 9-16z" fill="#c07a34" stroke="#12081f" stroke-width="2.2" stroke-linejoin="round"/><path d="M4 14c0-6 6-9 12-9s12 3 12 9z" fill="#6a4a26" stroke="#12081f" stroke-width="2.2" stroke-linejoin="round"/><path d="M16 5c0-2 1-3 3-4" stroke="#4a321a" stroke-width="2.4" fill="none" stroke-linecap="round"/><ellipse cx="12" cy="20" rx="1.8" ry="3.6" fill="#ffffff44"/></svg>`;
const flrSvgChest=(s)=>`<svg class="flric" viewBox="0 0 44 40" width="${s}" height="${s*40/44}" aria-hidden="true"><path d="M4 17q18-15 36 0z" fill="#c8904a" stroke="#12081f" stroke-width="2.2" stroke-linejoin="round"/><rect x="5" y="16" width="34" height="20" rx="4" fill="#9a6a34" stroke="#12081f" stroke-width="2.2"/><path d="M11 18v16M17 18v16M23 18v16M29 18v16M35 18v16" stroke="#5a3a1a" stroke-width="1.3"/><path d="M5 20c8 5 22-6 34 1" stroke="#3a6a2a" stroke-width="2.6" fill="none" stroke-linecap="round"/><ellipse cx="22" cy="19" rx="6" ry="5.4" fill="#f08a2a" stroke="#12081f" stroke-width="1.6"/><path d="M22 14l1-3" stroke="#4a5a1e" stroke-width="2" stroke-linecap="round"/></svg>`;
/* 10.4 merge: the milestone note sits low in the field, above the Fury bar, so it never covers a boss sentence or a word tag
   (at y 250 it hid the start of a boss sentence) */
function flrMileY(){try{return (typeof H==='number'?H:900)-185}catch(e){return 715}}
/* 10.4b: Esc on the results goes Home, as on every other results screen (overKey looks for #hm; the Rush's Home button is #flrhm, so
   Esc did nothing there) */
{const k0=overKey;overKey=function(e){try{if(S&&S.flr&&e&&e.key==='Escape'&&!e.repeat&&ov.className.indexOf('hide')<0&&performance.now()-SHOWT>=900&&!$('hm')&&$('flrhm')&&document.querySelector('.flrov')){e.preventDefault();$('flrhm').click();return true}}catch(x){}return k0.apply(this,arguments)}}
/* 10.4b: word tags never sit on top of each other. Walkers stop within the same 80 px in front of the hero and a boss calls its minions
   in pairs from one spot, so two tags could cover each other for the rest of a fight (seen in play: two Acorn Knights a pixel apart, their
   words unreadable). Every tick the tags are laid out from the hero outward and a tag that would overlap one already placed eases up
   by one tag height (at most two steps), and back down once the way is clear. Bosses keep their place. */
const FLR_PG0=pillGeom;
{const g0=pillGeom;pillGeom=function(e){const g=g0.apply(this,arguments);if(S&&S.flr&&e&&e.flrPy>0&&!e.boss)g.y=Math.max(70,g.y-e.flrPy);return g}}
function flrTagStep(dt){const P2=[],L=[];for(const e of S.en){if(!e.w)continue;if(e.boss){P2.push(FLR_PG0(e));continue}if(e.x<W+60)L.push(e);else e.flrPy=0}
 L.sort((a,b)=>a.x-b.x);
 for(const e of L){const g=FLR_PG0(e);let off=0;for(let k=0;k<2;k++){const y=g.y-off;if(!P2.some(p=>g.x<p.x+p.w+4&&g.x+g.w+4>p.x&&y<p.y+p.h+3&&y+g.h+3>p.y))break;off+=g.h+5}
  {const y=g.y-off;if(P2.some(p=>g.x<p.x+p.w+4&&g.x+g.w+4>p.x&&y<p.y+p.h+3&&y+g.h+3>p.y))off=0}/* no clear row within two steps: stay put */
  P2.push({x:g.x,y:g.y-off,w:g.w,h:g.h});const cur=e.flrPy||0;e.flrPy=Math.abs(off-cur)<.5?off:cur+(off-cur)*Math.min(1,dt*9)}}
{const mt=modeTick;modeTick=function(dt){const r=mt.apply(this,arguments);try{if(S.flr&&S.mode==='play')flrTagStep(dt)}catch(x){}return r}}
/* 10.4b: one title per new field. The Endless scenery blend (70b) writes "THE WAR PUSHES ON" and the field's name at y 128-184 while the
   level banner slides in over the same spot with the same name, so two titles stacked on each other; in the Rush the wall of light still
   sweeps the old field away, and the banner alone names the new one */
{const b0=bgxOver;bgxOver=function(){if(S&&S.flr)return;return b0.apply(this,arguments)}}
