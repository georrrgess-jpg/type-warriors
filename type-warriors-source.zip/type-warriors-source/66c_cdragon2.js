/* ---------- casino lair: the golden dragon, painted as separate layers ---------- */

/* shared look: gold scales with a warm light from the left and a deep shadow on the right */
function cdPaint(g,pf,bb,o){o=o||{};
 g.save();g.beginPath();pf(g);g.fillStyle=o.fill;g.fill();g.restore();
 cdScales(g,pf,bb[0],bb[1],bb[2],bb[3],o.s||14,'rgba(60,20,0,.55)','rgba(255,236,150,.55)',o.seed||0);
 cdIn(g,pf,'rgba(40,10,0,.9)',-(o.sh||24),-(o.sh||24)*.35,o.shb||30);
 cdIn(g,pf,'rgba(255,224,120,.85)',o.hl||10,o.hl*.6||6,o.hlb||14);
 g.save();g.beginPath();pf(g);g.lineJoin='round';g.lineWidth=o.ol||5;g.strokeStyle='#1c0702';g.stroke();g.restore()}
/* ivory horn, claw or tooth with a taper */
function cdHorn(g,up,lo,w0,c0,c1,ol){
 const A=cdSamp(up,10),B=cdSamp(lo,10);g.beginPath();g.moveTo(A[0][0],A[0][1]);for(const p of A)g.lineTo(p[0],p[1]);for(let i=B.length-1;i>=0;i--)g.lineTo(B[i][0],B[i][1]);g.closePath();
 g.fillStyle=c0;g.fill();g.save();g.clip();
 g.strokeStyle=c1;g.lineWidth=w0;g.beginPath();g.moveTo(B[0][0],B[0][1]);for(const p of B)g.lineTo(p[0],p[1]);g.stroke();
 g.lineWidth=2;g.strokeStyle='rgba(90,50,10,.55)';for(let i=3;i<A.length-3;i+=4){g.beginPath();g.moveTo(A[i][0],A[i][1]);g.lineTo(B[i][0],B[i][1]);g.stroke()}g.restore();
 g.lineJoin='round';g.lineWidth=ol||4;g.strokeStyle='#1c0702';g.beginPath();g.moveTo(A[0][0],A[0][1]);for(const p of A)g.lineTo(p[0],p[1]);for(let i=B.length-1;i>=0;i--)g.lineTo(B[i][0],B[i][1]);g.closePath();g.stroke()}
function cdTooth(g,x,y,len,w,ang){g.save();g.translate(x,y);g.rotate(ang||0);g.beginPath();g.moveTo(-w/2,0);g.quadraticCurveTo(-w*.4,len*.6,w*.08,len);g.quadraticCurveTo(w*.5,len*.55,w/2,0);g.closePath();
 g.fillStyle=hgr(g,-w/2,w/2,'#fffaf0','#c8b58a');g.fill();g.lineWidth=2.4;g.strokeStyle='#2a1204';g.stroke();g.restore()}
/* ----- wings ----- */
function cdWing(g,S,E,Wr,tips,dark){
 const mem=()=>{g.moveTo(S[0],S[1]);g.lineTo(E[0],E[1]);g.lineTo(Wr[0],Wr[1]);g.lineTo(tips[0][0],tips[0][1]);
  for(let i=1;i<tips.length;i++){const a=tips[i-1],b=tips[i],mx=(a[0]+b[0])/2,my=(a[1]+b[1])/2;g.quadraticCurveTo(mx+(Wr[0]-mx)*.28,my+(Wr[1]-my)*.28,b[0],b[1])}
  const l=tips[tips.length-1];g.quadraticCurveTo((l[0]+S[0])/2+(Wr[0]-S[0])*.05,(l[1]+S[1])/2+(Wr[1]-S[1])*.05+16,S[0],S[1]);g.closePath()};
 g.save();g.beginPath();mem();
 g.fillStyle=rgr(g,(S[0]+Wr[0])/2,(S[1]+Wr[1])/2+60,20,520,dark?'#8a1830':'#c0381c',dark?'#2a040e':'#4a0814');g.fill();
 g.clip();
 /* veins */
 g.strokeStyle='rgba(255,170,90,.28)';g.lineWidth=2;for(let i=0;i<tips.length-1;i++){for(let k=1;k<4;k++){const a=tips[i],b=tips[i+1],t=k/4;g.beginPath();g.moveTo(Wr[0],Wr[1]);g.quadraticCurveTo((Wr[0]+a[0]*(1-t)+b[0]*t)/2+8,(Wr[1]+a[1]*(1-t)+b[1]*t)/2+8,a[0]*(1-t)+b[0]*t,a[1]*(1-t)+b[1]*t);g.stroke()}}
 cdIn(g,gg=>mem.call(null),'rgba(20,0,6,.9)',0,0,34);
 g.restore();
 g.save();g.beginPath();mem();g.lineJoin='round';g.lineWidth=4;g.strokeStyle='#1c0408';g.stroke();g.restore();
 /* bones */
 const bone=(a,b,w0,w1)=>{const dx=b[0]-a[0],dy=b[1]-a[1],L=Math.hypot(dx,dy)||1,nx=-dy/L,ny=dx/L;
  g.beginPath();g.moveTo(a[0]+nx*w0/2,a[1]+ny*w0/2);g.lineTo(b[0]+nx*w1/2,b[1]+ny*w1/2);g.lineTo(b[0]-nx*w1/2,b[1]-ny*w1/2);g.lineTo(a[0]-nx*w0/2,a[1]-ny*w0/2);g.closePath();
  g.fillStyle=hgr(g,Math.min(a[0],b[0]),Math.max(a[0],b[0])+1,dark?'#c89030':'#f4c850',dark?'#6a3a0c':'#8a4c10');g.fill();g.lineJoin='round';g.lineWidth=3;g.strokeStyle='#1c0702';g.stroke()};
 bone(S,E,34,24);bone(E,Wr,24,16);
 for(const t of tips)bone(Wr,t,12,3);
 g.beginPath();g.arc(E[0],E[1],15,0,TAU);g.fillStyle='#e0aa38';g.fill();g.lineWidth=3;g.strokeStyle='#1c0702';g.stroke();
 g.beginPath();g.arc(Wr[0],Wr[1],14,0,TAU);g.fillStyle='#e0aa38';g.fill();g.stroke();
 /* thumb claw */
 const tx=Wr[0]+(E[0]-Wr[0])*.0,ty=Wr[1];cdTooth(g,tx,ty,46,18,Math.atan2(Wr[1]-E[1],Wr[0]-E[0])-Math.PI/2+.5)}
