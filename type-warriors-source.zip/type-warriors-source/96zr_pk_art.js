/* ===== CASINO 9.8: Penalty Kings, the art (96zr) =====
   The stage is a 1080 x 600 canvas: a floodlit night stadium (two crowd frames for cheering, ad boards, floodlights), a striped
   pitch in perspective, a big goal with a net drawn per frame (it bulges where the ball hits), the keeper in goal and the ball on
   the spot. Characters are drawn from code in the house style (#12081f outlines, chunky shapes): three monster keepers in kit and
   gloves (front, with idle sway, a tell glance and a dive pose), the same monsters as kickers seen from behind (run-up and strike),
   and your keeper (a knight in a gold kit) for save kicks. The static stadium is baked once; live drawing is a few paths per frame.
   No shadowBlur, no ctx.filter. */
const PKO='#12081f',PKSW=1080,PKSH=600;
/* the goal: posts, bar, ground line; six zones */
const PKG={x0:252,x1:828,y0:146,y1:398,mid:272};
const pkZone=(c,r)=>{const w=(PKG.x1-PKG.x0)/3;return{x:PKG.x0+w*c,y:r===0?PKG.y0:PKG.mid,w,h:r===0?PKG.mid-PKG.y0:PKG.y1-PKG.mid,cx:PKG.x0+w*(c+.5),cy:r===0?(PKG.y0+PKG.mid)/2+4:(PKG.mid+PKG.y1)/2}};
const PKSPOT={x:540,y:540};
function pkRnd(i){const x=Math.sin(i*127.1+311.7)*43758.5453;return x-Math.floor(x)}
function pkMix(a,b,t){const h=s=>[1,3,5].map(i=>parseInt(s.slice(i,i+2),16)),A=h(a),B=h(b);return'#'+A.map((v,i)=>Math.round(v+(B[i]-v)*t).toString(16).padStart(2,'0')).join('')}
function pkOut(g,w){g.lineWidth=w||3;g.strokeStyle=PKO;g.stroke()}
function pkGlow(g,x,y,r,col,a){if(a<=0)return;g.save();g.globalCompositeOperation='lighter';const q=g.createRadialGradient(x,y,0,x,y,r);q.addColorStop(0,col);q.addColorStop(1,'rgba(0,0,0,0)');g.globalAlpha=Math.min(1,a);g.fillStyle=q;g.fillRect(x-r,y-r,r*2,r*2);g.restore()}
/* ---------- the stadium (baked, two crowd frames) ---------- */
const PKBK={};
function pkStadium(frame){const k='st'+frame;if(PKBK[k])return PKBK[k];const c=document.createElement('canvas');c.width=PKSW;c.height=PKSH;const g=c.getContext('2d');g.lineJoin=g.lineCap='round';
 let q=g.createLinearGradient(0,0,0,300);q.addColorStop(0,'#0a0828');q.addColorStop(1,'#2a1a5a');g.fillStyle=q;g.fillRect(0,0,PKSW,320);
 for(let i=0;i<60;i++){g.fillStyle=`rgba(255,255,255,${.25+pkRnd(i)*.5})`;g.fillRect(pkRnd(i+1)*PKSW,pkRnd(i+2)*90,1.6,1.6)}
 /* stands: three tiers of seats with a curved roof line */
 const tier=(y0,y1,col)=>{g.fillStyle=col;g.beginPath();g.moveTo(0,y1);g.lineTo(0,y0+20);g.quadraticCurveTo(PKSW/2,y0-18,PKSW,y0+20);g.lineTo(PKSW,y1);g.closePath();g.fill()};
 tier(96,320,'#1e1450');tier(150,320,'#261a62');tier(206,320,'#2e2070');
 /* the crowd: rows of heads and raised arms; frame 1 jumps */
 const cols=['#ff8a6a','#8affc0','#ffd45a','#9fe8ff','#d0a0ff','#ff6a9a','#ffffff','#ffb04a'];
 for(let row=0;row<9;row++){const y=118+row*22,n=46+row*3;for(let i=0;i<n;i++){const x=(i+.5+(row%2)*.5)*PKSW/n+(pkRnd(row*97+i)-.5)*8,j=frame&&pkRnd(row*31+i)<.55?-5-pkRnd(i)*4:0,cc=cols[(i*7+row*3)%cols.length];
   g.fillStyle=pkMix(cc,'#1a1040',.35+row*.03);g.beginPath();g.arc(x,y+j,5.2,0,TAU);g.fill();g.fillRect(x-5,y+j+4,10,9);
   if(frame&&pkRnd(row*13+i)<.25){g.strokeStyle=g.fillStyle;g.lineWidth=2.4;g.beginPath();g.moveTo(x-4,y+j+4);g.lineTo(x-8,y+j-8);g.moveTo(x+4,y+j+4);g.lineTo(x+8,y+j-8);g.stroke()}}}
 /* scarves / flags waving in the crowd */
 for(let i=0;i<9;i++){const x=60+i*120+pkRnd(i)*30,y=140+pkRnd(i+9)*110,cc=['#ff8a2a','#ffd45a','#7a3ad0'][i%3];g.fillStyle=cc;g.save();g.translate(x,y);g.rotate((frame?.25:-.15)*(i%2?1:-1));g.fillRect(-2,0,2,26);g.beginPath();g.moveTo(0,0);g.lineTo(26,6);g.lineTo(0,14);g.closePath();g.fill();g.restore()}
 /* floodlights */
 for(const fx of [90,PKSW-90]){g.fillStyle='#2a2a40';g.fillRect(fx-4,18,8,70);g.fillStyle='#fffbe0';g.beginPath();g.roundRect(fx-46,8,92,24,6);g.fill();pkOut(g,3);for(let i=0;i<4;i++){g.fillStyle='#fff';g.beginPath();g.arc(fx-33+i*22,20,6,0,TAU);g.fill()}}
 /* ad boards */
 q=g.createLinearGradient(0,300,0,334);q.addColorStop(0,'#3a2a8a');q.addColorStop(1,'#1e1450');g.fillStyle=q;g.fillRect(0,300,PKSW,34);g.fillStyle='#12081f';g.fillRect(0,298,PKSW,3);g.fillRect(0,333,PKSW,3);
 g.font="400 22px 'Pirata One',Georgia,serif";g.textAlign='center';g.textBaseline='middle';
 ['TYPE WARRIORS','PENALTY KINGS','THE DRAGON LOUNGE','GOLDEN BOOT'].forEach((s,i)=>{g.fillStyle=i%2?'#ffd45a':'#9fe8ff';g.fillText(s,135+i*270,318)});
 /* pitch: perspective stripes */
 q=g.createLinearGradient(0,334,0,PKSH);q.addColorStop(0,'#2a8a3e');q.addColorStop(1,'#3fae52');g.fillStyle=q;g.fillRect(0,334,PKSW,PKSH-334);
 for(let i=-6;i<=6;i++){if(i%2)continue;g.fillStyle='rgba(255,255,255,.06)';g.beginPath();const a=i*90,b=(i+1)*90;g.moveTo(PKSW/2+a,334);g.lineTo(PKSW/2+b,334);g.lineTo(PKSW/2+b*3.2,PKSH);g.lineTo(PKSW/2+a*3.2,PKSH);g.closePath();g.fill()}
 /* box lines and spot */
 g.strokeStyle='rgba(255,255,255,.85)';g.lineWidth=3.2;g.beginPath();g.moveTo(80,PKG.y1+60);g.lineTo(PKSW-80,PKG.y1+60);g.moveTo(80,PKG.y1+60);g.lineTo(10,PKSH);g.moveTo(PKSW-80,PKG.y1+60);g.lineTo(PKSW-10,PKSH);g.stroke();
 g.beginPath();g.moveTo(170,PKG.y1+8);g.lineTo(PKSW-170,PKG.y1+8);g.moveTo(170,PKG.y1+8);g.lineTo(150,PKG.y1+60);g.moveTo(PKSW-170,PKG.y1+8);g.lineTo(PKSW-150,PKG.y1+60);g.stroke();
 g.fillStyle='rgba(255,255,255,.9)';g.beginPath();g.ellipse(PKSPOT.x,PKSPOT.y+30,9,4,0,0,TAU);g.fill();
 /* the light cones (baked: they do not move) */
 for(const fx of [90,PKSW-90]){const lq=g.createLinearGradient(fx,30,PKSW/2,420);lq.addColorStop(0,'rgba(255,250,220,.22)');lq.addColorStop(1,'rgba(255,250,220,0)');g.fillStyle=lq;g.beginPath();g.moveTo(fx-40,30);g.lineTo(fx+40,30);g.lineTo(PKSW/2+(fx<PKSW/2?60:-60)+(fx<PKSW/2?160:-160),PKSH);g.lineTo(PKSW/2+(fx<PKSW/2?-260:260),PKSH);g.closePath();g.fill()}
 /* goal frame shadow on the grass */
 g.fillStyle='rgba(0,0,0,.25)';g.beginPath();g.ellipse(PKSW/2,PKG.y1+6,330,16,0,0,TAU);g.fill();
 PKBK[k]=c;return c}
/* ---------- the goal: back net (per frame, it bulges), posts and bar ---------- */
function pkNet(g,t,bul){/* bul = {x,y,k} a bulge where the ball hit */const bx0=PKG.x0+46,bx1=PKG.x1-46,by0=PKG.y0+34,by1=PKG.y1-10;
 g.save();g.fillStyle='rgba(10,8,30,.55)';g.beginPath();g.moveTo(PKG.x0,PKG.y0);g.lineTo(PKG.x1,PKG.y0);g.lineTo(bx1,by0);g.lineTo(bx1,by1);g.lineTo(PKG.x1,PKG.y1);g.lineTo(PKG.x0,PKG.y1);g.lineTo(bx0,by1);g.lineTo(bx0,by0);g.closePath();g.fill();
 const D=(x,y)=>{if(!bul||bul.k<=0)return[x,y];const dx=x-bul.x,dy=y-bul.y,d=Math.hypot(dx,dy),f=Math.max(0,1-d/150)*bul.k;return[x+dx*f*.18,y+dy*f*.18-f*6]};
 g.strokeStyle='rgba(235,240,255,.55)';g.lineWidth=1.3;const sw=Math.sin(t*1.3)*1.5;
 for(let i=0;i<=24;i++){const u=i/24,x=bx0+(bx1-bx0)*u;g.beginPath();for(let j=0;j<=12;j++){const v=j/12;const p=D(x+sw*v,by0+(by1-by0)*v);j?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1])}g.stroke()}
 for(let j=0;j<=12;j++){const v=j/12,y=by0+(by1-by0)*v;g.beginPath();for(let i=0;i<=24;i++){const u=i/24;const p=D(bx0+(bx1-bx0)*u+sw*v,y);i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1])}g.stroke()}
 /* side and roof nets */
 g.strokeStyle='rgba(235,240,255,.35)';for(let i=0;i<=6;i++){const v=i/6;g.beginPath();g.moveTo(PKG.x0,PKG.y0+(PKG.y1-PKG.y0)*v);g.lineTo(bx0,by0+(by1-by0)*v);g.moveTo(PKG.x1,PKG.y0+(PKG.y1-PKG.y0)*v);g.lineTo(bx1,by0+(by1-by0)*v);g.stroke()}
 for(let i=0;i<=12;i++){const u=i/12;g.beginPath();g.moveTo(PKG.x0+(PKG.x1-PKG.x0)*u,PKG.y0);g.lineTo(bx0+(bx1-bx0)*u,by0);g.stroke()}
 g.restore()}
function pkFrame(g,shake){/* posts and crossbar (white with outline), drawn over the net and behind the keeper */
 const w=14;g.save();g.fillStyle='#f8f8ff';g.strokeStyle=PKO;g.lineWidth=3.2;
 g.beginPath();g.rect(PKG.x0-w,PKG.y0-w+(shake||0),PKG.x1-PKG.x0+2*w,w);g.fill();g.stroke();
 for(const x of [PKG.x0-w,PKG.x1]){g.beginPath();g.rect(x,PKG.y0-w,w,PKG.y1-PKG.y0+w);g.fill();g.stroke()}
 g.fillStyle='rgba(120,130,180,.35)';g.fillRect(PKG.x0-w+3,PKG.y0-w+3,PKG.x1-PKG.x0+2*w-6,4);g.restore()}
/* ---------- characters ---------- */
function pkEye(g,x,y,r,dx,col){g.fillStyle='#fff';g.beginPath();g.arc(x,y,r,0,TAU);g.fill();pkOut(g,2.4);g.fillStyle=col||PKO;g.beginPath();g.arc(x+dx*r*.42,y+r*.08,r*.5,0,TAU);g.fill();g.fillStyle='#fff';g.beginPath();g.arc(x+dx*r*.42-r*.18,y-r*.12,r*.16,0,TAU);g.fill()}
function pkGlove(g,x,y,s,col){g.save();g.translate(x,y);g.scale(s,s);g.fillStyle=col||'#ffd45a';g.beginPath();g.roundRect(-16,-18,32,34,10);g.fill();pkOut(g,3);
 g.strokeStyle='rgba(18,8,31,.5)';g.lineWidth=2;for(const fx of [-8,0,8]){g.beginPath();g.moveTo(fx,-14);g.lineTo(fx,-2);g.stroke()}g.fillStyle='#3a3a6a';g.beginPath();g.roundRect(-14,10,28,9,4);g.fill();pkOut(g,2.4);g.restore()}
/* a head per character; look = -1..1 pupils, mood 0 calm / 1 shocked / 2 grin */
function pkHead(g,id,look,mood,t){if(id==='moss'){/* orc */g.fillStyle='#7ac24a';g.beginPath();g.ellipse(0,0,46,42,0,0,TAU);g.fill();pkOut(g,3.4);
  g.fillStyle='#5a9a34';for(const k of [-1,1]){g.beginPath();g.moveTo(k*40,-6);g.lineTo(k*62,-18);g.lineTo(k*44,10);g.closePath();g.fill();pkOut(g,3)}
  g.fillStyle='#3a8a2a';g.beginPath();g.moveTo(-26,-36);for(let i=0;i<7;i++){g.lineTo(-24+i*8,-52-(i%2)*8);g.lineTo(-20+i*8,-38)}g.closePath();g.fill();pkOut(g,2.4);
  g.strokeStyle=PKO;g.lineWidth=4;g.beginPath();g.moveTo(-30,-14);g.lineTo(-10,-8);g.moveTo(30,-14);g.lineTo(10,-8);g.stroke();
  pkEye(g,-18,-2,10,look,'#c02a3a');pkEye(g,18,-2,10,look,'#c02a3a');g.fillStyle='#4a7a2a';g.beginPath();g.ellipse(0,12,10,7,0,0,TAU);g.fill();pkOut(g,2);
  g.fillStyle=PKO;g.beginPath();mood===1?g.ellipse(0,28,12,9,0,0,TAU):g.ellipse(0,26,22,mood===2?10:6,0,0,Math.PI);g.fill();
  g.fillStyle='#fff8e0';for(const k of [-1,1]){g.beginPath();g.moveTo(k*14,24);g.lineTo(k*10,10);g.lineTo(k*6,24);g.closePath();g.fill();pkOut(g,1.6)}}
 else if(id==='gloop'){/* slime */const w=Math.sin(t*3)*2;g.fillStyle='rgba(90,216,160,.95)';g.beginPath();g.moveTo(-46,30);g.quadraticCurveTo(-52,-30+w,0,-50);g.quadraticCurveTo(52,-30-w,46,30);g.quadraticCurveTo(0,40,-46,30);g.fill();pkOut(g,3.4);
  g.fillStyle='rgba(255,255,255,.4)';g.beginPath();g.ellipse(-24,-26,8,14,-.5,0,TAU);g.fill();for(const [bx,by,br] of [[26,-20,5],[-30,8,4],[18,18,3]]){g.strokeStyle='rgba(20,90,60,.55)';g.lineWidth=2;g.beginPath();g.arc(bx,by,br,0,TAU);g.stroke()}
  pkEye(g,-16,-6,12,look);pkEye(g,16,-8,13,look);g.fillStyle=PKO;g.beginPath();mood===1?g.ellipse(0,20,10,8,0,0,TAU):g.ellipse(0,16,16,mood===2?9:5,0,0,Math.PI);g.fill()}
 else if(id==='grim'){/* rune golem */g.fillStyle='#8a82a8';g.beginPath();g.moveTo(-44,-40);g.lineTo(40,-46);g.lineTo(48,30);g.lineTo(-46,36);g.closePath();g.fill();pkOut(g,3.4);
  g.fillStyle='#6a628a';g.beginPath();g.moveTo(-44,-40);g.lineTo(40,-46);g.lineTo(30,-30);g.lineTo(-36,-26);g.closePath();g.fill();
  g.strokeStyle='rgba(18,8,31,.4)';g.lineWidth=2;g.beginPath();g.moveTo(-30,10);g.lineTo(-10,20);g.moveTo(20,-34);g.lineTo(30,-20);g.stroke();
  const gl=.6+.4*Math.sin(t*4);g.fillStyle=`rgba(140,220,255,${gl})`;g.font='bold 14px serif';g.textAlign='center';g.fillText('ᚱ',-30,-24);g.fillText('ᛟ',30,-26);
  for(const k of [-1,1]){g.fillStyle='#1a1430';g.beginPath();g.roundRect(k*18-12,-12,24,16,4);g.fill();g.fillStyle='#9fe8ff';g.beginPath();g.arc(k*18+look*5,-4,5,0,TAU);g.fill();pkGlow(g,k*18+look*5,-4,14,'rgba(159,232,255,1)',.6)}
  g.fillStyle=PKO;g.beginPath();g.rect(-14,mood===1?14:18,28,mood===1?12:5);g.fill()}
 else{/* you: a knight's helmet with a gold plume */g.fillStyle='#d8dcf0';g.beginPath();g.ellipse(0,0,40,42,0,0,TAU);g.fill();pkOut(g,3.4);g.fillStyle='#a8aec8';g.beginPath();g.ellipse(12,4,22,34,0,0,TAU);g.fill();
  g.fillStyle=PKO;g.beginPath();g.roundRect(-26,-8,52,10,4);g.fill();g.fillStyle='#ffd45a';g.beginPath();g.moveTo(-4,-40);g.quadraticCurveTo(30,-70,48,-36);g.quadraticCurveTo(26,-50,4,-36);g.closePath();g.fill();pkOut(g,2.6);
  g.fillStyle='#9fe8ff';g.fillRect(-20+look*3,-6,8,5);g.fillRect(12+look*3,-6,8,5)}}
/* a keeper, front view. pose: dive -1 (his right = screen left).. 1, lift 0..1 (high save), spread 0..1, sway */
function pkKeeper(g,x,y,o,P,t){const dv=P.dive||0,lift=P.lift||0,ad=Math.abs(dv);g.save();g.translate(x+dv*175,y-lift*70-ad*20);g.rotate(dv*1.2);
 const kit=o.kit,kit2=o.kit2,sp=P.spread||0;
 /* legs */g.fillStyle='#1e1a40';for(const k of [-1,1]){g.save();g.translate(k*16,-46);g.rotate(k*(.12+ad*.5));g.beginPath();g.roundRect(-11,0,22,46,8);g.fill();pkOut(g,3);g.fillStyle=kit;g.beginPath();g.roundRect(-11,26,22,14,4);g.fill();pkOut(g,2.4);
  g.fillStyle='#fff';g.beginPath();g.roundRect(-14,40,28,12,6);g.fill();pkOut(g,2.4);g.restore();g.fillStyle='#1e1a40'}
 /* shorts */g.fillStyle='#2a2460';g.beginPath();g.roundRect(-34,-72,68,32,10);g.fill();pkOut(g,3);
 /* jersey */g.fillStyle=kit;g.beginPath();g.moveTo(-44,-150);g.quadraticCurveTo(0,-162,44,-150);g.lineTo(38,-66);g.quadraticCurveTo(0,-58,-38,-66);g.closePath();g.fill();pkOut(g,3.4);
 g.fillStyle=kit2;g.beginPath();g.moveTo(-44,-150);g.lineTo(-30,-150);g.lineTo(-26,-66);g.lineTo(-38,-66);g.closePath();g.fill();g.beginPath();g.moveTo(44,-150);g.lineTo(30,-150);g.lineTo(26,-66);g.lineTo(38,-66);g.closePath();g.fill();
 g.font="700 40px 'Pirata One',Georgia,serif";g.textAlign='center';g.textBaseline='middle';g.lineWidth=5;g.strokeStyle=PKO;g.strokeText(String(o.num),0,-104);g.fillStyle='#fff8e0';g.fillText(String(o.num),0,-104);
 /* arms: idle hands at the waist, spread when diving or ready */
 const arm=(k)=>{const a=(-.5-sp*1.0-ad*.3)*k,len=56;g.save();g.translate(k*40,-140);g.rotate(a);g.fillStyle=kit;g.beginPath();g.roundRect(-11,0,22,len,10);g.fill();pkOut(g,3);pkGlove(g,0,len+10,1,'#ffd45a');g.restore()};
 arm(-1);arm(1);
 /* head */g.save();g.translate(0,-196);pkHead(g,o.id,P.look||0,P.mood||0,t);g.restore();
 g.restore()}
/* a kicker from behind (monster or you) */
function pkKicker(g,x,y,o,P,t){const run=P.run||0,kick=P.kick||0,bob=Math.abs(Math.sin(run*14))*8*(kick?0:1);g.save();g.translate(x,y-bob);const s=1.18;g.scale(s,s);
 /* legs */g.fillStyle='#1e1a40';const sw=Math.sin(run*14)*.5;
 for(const k of [-1,1]){g.save();g.translate(k*16,-46);g.rotate(k===1?(kick? -1.1+kick*1.6:sw):-sw*.8);g.beginPath();g.roundRect(-11,0,22,48,8);g.fill();pkOut(g,3);g.fillStyle='#fff';g.beginPath();g.roundRect(-13,40,26,12,6);g.fill();pkOut(g,2.4);g.restore()}
 g.fillStyle='#2a2460';g.beginPath();g.roundRect(-34,-72,68,32,10);g.fill();pkOut(g,3);
 g.fillStyle=o.kit;g.beginPath();g.moveTo(-46,-150);g.quadraticCurveTo(0,-160,46,-150);g.lineTo(40,-66);g.quadraticCurveTo(0,-60,-40,-66);g.closePath();g.fill();pkOut(g,3.4);
 g.font="700 15px Poppins,sans-serif";g.textAlign='center';g.fillStyle='#fff8e0';g.fillText(o.n.toUpperCase(),0,-128);g.font="700 40px 'Pirata One',Georgia,serif";g.lineWidth=5;g.strokeStyle=PKO;g.strokeText(String(o.num),0,-92);g.fillText(String(o.num),0,-92);
 for(const k of [-1,1]){g.save();g.translate(k*42,-142);g.rotate(k*(.25+Math.sin(run*14+(k>0?3:0))*.4));g.fillStyle=o.kit;g.beginPath();g.roundRect(-10,0,20,50,9);g.fill();pkOut(g,3);g.restore()}
 /* the back of the head */g.save();g.translate(0,-188);
 if(o.id==='moss'){g.fillStyle='#6aae3e';g.beginPath();g.ellipse(0,0,42,40,0,0,TAU);g.fill();pkOut(g,3.4);g.fillStyle='#3a8a2a';g.beginPath();g.moveTo(-6,-40);for(let i=0;i<5;i++){g.lineTo(-4,-30+i*12);g.lineTo(8,-26+i*12)}g.lineTo(6,-40);g.closePath();g.fill();pkOut(g,2);for(const k of [-1,1]){g.fillStyle='#5a9a34';g.beginPath();g.moveTo(k*36,-4);g.lineTo(k*58,-16);g.lineTo(k*40,12);g.closePath();g.fill();pkOut(g,3)}}
 else if(o.id==='gloop'){g.fillStyle='rgba(90,216,160,.95)';g.beginPath();g.moveTo(-44,30);g.quadraticCurveTo(-50,-30,0,-48);g.quadraticCurveTo(50,-30,44,30);g.quadraticCurveTo(0,38,-44,30);g.fill();pkOut(g,3.4);g.fillStyle='rgba(255,255,255,.35)';g.beginPath();g.ellipse(20,-24,8,14,.5,0,TAU);g.fill()}
 else if(o.id==='grim'){g.fillStyle='#7a7298';g.beginPath();g.moveTo(-42,-40);g.lineTo(40,-44);g.lineTo(46,30);g.lineTo(-44,34);g.closePath();g.fill();pkOut(g,3.4);g.fillStyle='rgba(140,220,255,.8)';g.font='bold 16px serif';g.fillText('ᛉ',0,0)}
 else{g.fillStyle='#c8ccdf';g.beginPath();g.ellipse(0,0,40,42,0,0,TAU);g.fill();pkOut(g,3.4);g.fillStyle='#ffd45a';g.beginPath();g.moveTo(-4,-40);g.quadraticCurveTo(26,-66,40,-30);g.quadraticCurveTo(22,-44,4,-34);g.closePath();g.fill();pkOut(g,2.4)}
 g.restore();g.restore()}
/* ---------- the ball ---------- */
function pkBall(g,x,y,r,rot){g.save();g.translate(x,y);g.rotate(rot||0);g.fillStyle='#fbfbff';g.beginPath();g.arc(0,0,r,0,TAU);g.fill();
 g.save();g.clip();g.fillStyle='#2a2460';const pent=(cx,cy,s)=>{g.beginPath();for(let i=0;i<5;i++){const a=-Math.PI/2+i*TAU/5;g.lineTo(cx+Math.cos(a)*s,cy+Math.sin(a)*s)}g.closePath();g.fill()};
 pent(0,0,r*.3);for(let i=0;i<5;i++){const a=-Math.PI/2+i*TAU/5+Math.PI/5;pent(Math.cos(a)*r*.86,Math.sin(a)*r*.86,r*.28)}
 g.strokeStyle='#2a2460';g.lineWidth=Math.max(1,r*.05);for(let i=0;i<5;i++){const a=-Math.PI/2+i*TAU/5;g.beginPath();g.moveTo(Math.cos(a)*r*.3,Math.sin(a)*r*.3);g.lineTo(Math.cos(a)*r*.62,Math.sin(a)*r*.62);g.stroke()}g.restore();
 g.fillStyle='rgba(255,255,255,.5)';g.beginPath();g.ellipse(-r*.35,-r*.4,r*.28,r*.18,-.6,0,TAU);g.fill();g.beginPath();g.arc(0,0,r,0,TAU);pkOut(g,Math.max(2,r*.1));g.restore()}
/* ---------- effects ---------- */
function pkBanner(g,txt,u,col,sub){if(u<=0||u>=1)return;const k=u<.15?u/.15:u>.8?(1-u)/.2:1,sc=u<.15?.6+.4*(1-Math.pow(1-u/.15,3))*1.08:1;g.save();g.translate(PKSW/2,250);g.scale(sc,sc);g.globalAlpha=k;
 g.font="400 110px 'Pirata One',Georgia,serif";g.textAlign='center';g.textBaseline='middle';g.lineJoin='round';g.lineWidth=18;g.strokeStyle=PKO;g.strokeText(txt,0,0);
 const q=g.createLinearGradient(0,-50,0,50);q.addColorStop(0,'#fff6c8');q.addColorStop(1,col);g.fillStyle=q;g.fillText(txt,0,0);
 if(sub){g.font="700 26px Poppins,sans-serif";g.lineWidth=7;g.strokeText(sub,0,74);g.fillStyle='#fff';g.fillText(sub,0,74)}g.restore()}
function pkConfetti(g,parts){for(const p of parts){g.save();g.translate(p.x,p.y);g.rotate(p.a);g.fillStyle=p.c;g.globalAlpha=Math.max(0,Math.min(1,p.l));g.fillRect(-p.s,-p.s*.5,p.s*2,p.s);g.restore()}}
function pkZoneDraw(g,c,r,u,col,label){const Z=pkZone(c,r);g.save();g.globalAlpha=u;g.fillStyle=col||'rgba(255,212,90,.22)';g.strokeStyle='#ffd45a';g.lineWidth=3;g.setLineDash([10,8]);g.beginPath();g.roundRect(Z.x+8,Z.y+8,Z.w-16,Z.h-16,14);g.fill();g.stroke();g.setLineDash([]);
 g.beginPath();g.arc(Z.cx,Z.cy,26,0,TAU);g.lineWidth=3;g.strokeStyle='#fff6c8';g.stroke();g.beginPath();g.moveTo(Z.cx-38,Z.cy);g.lineTo(Z.cx-14,Z.cy);g.moveTo(Z.cx+14,Z.cy);g.lineTo(Z.cx+38,Z.cy);g.moveTo(Z.cx,Z.cy-38);g.lineTo(Z.cx,Z.cy-14);g.moveTo(Z.cx,Z.cy+14);g.lineTo(Z.cx,Z.cy+38);g.stroke();
 if(label){g.font='800 15px Poppins,sans-serif';g.textAlign='center';g.fillStyle='#fff';g.fillText(label,Z.cx,Z.y+Z.h-16)}g.restore()}
/* the power meter: needle 0..1; green zone centred on .5 with half-width gw, yellow around it */
function pkPower(g,x,y,w,needle,gw,yw,hot){g.save();g.font='800 13px Poppins,sans-serif';g.fillStyle='#c4badf';g.textAlign='left';g.fillText('POWER',x,y-10);
 g.fillStyle='rgba(10,6,30,.85)';g.beginPath();g.roundRect(x-4,y-4,w+8,30,15);g.fill();pkOut(g,3);
 const seg=(a,b,c)=>{g.fillStyle=c;g.fillRect(x+w*a,y,w*(b-a),22)};seg(0,1,'#d0304a');seg(.5-gw-yw,.5+gw+yw,'#ffc23a');seg(.5-gw,.5+gw,'#3ad86a');
 g.fillStyle='rgba(255,255,255,.25)';g.fillRect(x,y,w,6);
 const nx=x+w*needle;g.fillStyle='#fff';g.beginPath();g.moveTo(nx,y-8);g.lineTo(nx+8,y-18);g.lineTo(nx-8,y-18);g.closePath();g.fill();pkOut(g,2);g.fillRect(nx-2,y-2,4,26);
 if(hot)pkGlow(g,x+w/2,y+11,w*.3,'rgba(80,255,140,1)',.5);g.restore()}
