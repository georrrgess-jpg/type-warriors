/* ---------- overlay helpers ---------- */
let SHOWT=0;
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function show(html,cls){LIVE=[];HOME=false;SHOWT=performance.now();cls=cls||'';const nv=shellNav(cls,html);
 ov.innerHTML=nv===null?html:`${sbHTML(nv)}<main class="mn">${html}</main>`;ov.className=cls+(html.indexOf('ctabs')>0?' top':'')+(nv===null?'':' sh');ov.scrollTop=0;S.back=null;if(nv!==null){sbBind();shellFit()}if(ovTM)applyLayout();queueMicrotask(menuChrome)}
function hide(){HOME=false;ov.className='hide';LIVE=[];inp.focus();if(ovTM)applyLayout()}
function live(id,fn){const el=$(id);if(el)LIVE.push({cv:el,fn:fn(el)})}
function thumb(cvs,id,hue){const g=cvs.getContext('2d'),M=MON[id];return t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,cvs.width,cvs.height);g.filter=hue?`hue-rotate(${hue}deg)`:'none';const s=Math.min((cvs.height-26)/M.th,(cvs.width-12)/(M.tw||M.th*.9));
 g.save();g.translate(cvs.width/2-(M.cx||0)*s,cvs.height-10);g.scale(s,s);M.d(g,t,{lg:0});g.restore()}}

const DYE=['Off','Trim','Full'];
function dyeUI(c){return `<div class="dye${c?' cp':''}"><div class="dl">Banner colour</div><div class="swatches">${HC.map((h,i)=>`<button class="sw${P.col===i?' on':''}" data-c="${i}" style="background:${h[1]}" title="${h[0]}" aria-label="${h[0]}"></button>`).join('')}<label class="sw cust${P.col===99?' on':''}" title="Custom colour" style="background:${P.cc||'conic-gradient(#f44,#fc4,#4f8,#4cf,#a4f,#f44)'}"><input type="color" id="cc" value="${P.cc||'#ff8800'}"></label></div><div class="dl">Armor dye <small>tints your armor with the banner colour</small></div><div class="row dyr">${DYE.map((d,i)=>`<button class="sm${(P.dye||0)===i?' on':''}" data-dye="${i}">${d}</button>`).join('')}</div></div>`}
function dyeBind(fn){ov.querySelectorAll('[data-c]').forEach(el=>el.onclick=()=>{P.col=+el.dataset.c;save();fn()});ov.querySelectorAll('[data-dye]').forEach(el=>el.onclick=()=>{P.dye=+el.dataset.dye;save();fn()});const cc=$('cc');if(cc)cc.onchange=()=>{P.cc=cc.value;P.col=99;save();fn()}}
const yesNo=v=>v?'On':'Off';
function stats(){return `<div class="st"><span>Best score <b>${P.best.toLocaleString()}</b></span><span>Deepest level <b>${P.bestLv}</b></span><span>Best round <b>${P.bestWave}</b></span><span>Monsters slain <b>${P.kills.toLocaleString()}</b></span><span>Runs <b>${P.runs}</b></span><span>Best combo <b>${P.bestCombo}</b></span><span>Best speed <b>${P.bestWpm} WPM</b></span><span>Campaign <b>${Math.min(30,Object.keys(P.stars).length)}/30</b> cleared</span></div>`}

/* ---------- title ---------- */
const newPaths=()=>PK.filter(p=>pathOpen(p)&&!P.seen[p]);
const pbw=()=>Object.values(P.pb||{}).reduce((m,x)=>Math.max(m,x.w||0),0);

/* ---------- game speed selector (Campaign and Endless) ---------- */
/* ---------- shop ---------- */
const today=()=>new Date().toISOString().slice(0,10),yest=()=>new Date(Date.now()-864e5).toISOString().slice(0,10);
const dailyReady=()=>calReady();
const SHOP=[{k:'w',n:'Weapon crate',d:'Swords and daggers of the knight. Common up to legendary.'},{k:'a',n:'Armor crate',d:'Any of the armor sets, from ragged tunics to legendary regalia.'},{k:'s',n:'SPECIAL crate',d:'Maces, axes, spears, scythes, bows, staves, wands and katanas. Path weapons need that path unlocked.'},{k:'p',n:'Eclipse Chest',d:'A guaranteed Legendary, with a 10% chance of a Mythic. Weapons and armor. Favors gear you do not own yet.'}];
function shop(msg){S.mode='title';S.view='menu';
 show(`<h2>Shop</h2><div class="gbar"><span class="coin big"></span><b>${P.gold.toLocaleString()}</b> gold</div>${hwOn()?`<button class="hwjump" id="hwj"><span class="hwlt">LIMITED TIME</span><span>Graveyard Collection: Mythic Halloween gear</span><span>${hwLeft()} ↓</span></button>`:''}<p style="margin-top:-6px">Spend gold on crates here, or on permanent perks in the Skill Tree. Earn gold from kills, cleared rounds, bosses, finished levels and level ups.</p>${msg?`<p style="color:var(--gold)">${msg}</p>`:''}
<div class="shopg">${SHOP.map(o=>`<div class="sc k${o.k}"><canvas id="sc${o.k}" width="240" height="200"></canvas><b>${o.n}</b><small>${o.d}</small><i>You own ${P[CN[o.k]]}</i><button ${P.gold>=price(o.k)?'':'disabled'} data-b="${o.k}"><span class="coin"></span> ${price(o.k)}</button></div>`).join('')}</div>${hwShopHTML()}
<div class="row"><button class="sm" id="b">Back</button></div>`);hwShopBind();if($('hwj'))$('hwj').onclick=()=>{const e=ov.querySelector('.hwsec');if(e)e.scrollIntoView({behavior:'smooth',block:'start'})};
 for(const o of SHOP)live('sc'+o.k,c=>{const g=c.getContext('2d');return t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,240,200);chest(g,120,178,1.35,(Math.sin(t*1.4)*.5+.5)*.12*0,o.k,t)}});
 S.back=title;$('b').onclick=title;
 ov.querySelectorAll('[data-b]').forEach(el=>el.onclick=()=>{const k=el.dataset.b;if(P.gold<price(k))return;P.gold-=price(k);P[CN[k]]++;save();beep(880,.12,'triangle',.8);shop('Bought one '+SHOP.find(o=>o.k===k).n.toLowerCase()+'. Open it from the main menu.')})}

/* ---------- profile ---------- */
const statTiles=()=>{const T=[['Best score',P.best.toLocaleString()],['Deepest level',P.bestLv],['Best round',P.bestWave],['Monsters slain',P.kills.toLocaleString()],['Runs played',P.runs],['Best combo',P.bestCombo],['Best speed',P.bestWpm+' WPM'],['Campaign',Math.min(30,Object.keys(P.stars).length)+' / 30'],['Rift best',P.rb&&P.rb.s?P.rb.s.toLocaleString():'none'],['Mastered weapons',wmCount(1)]];return `<div class="stt">${T.map(t=>`<div><b>${t[1]}</b><span>${t[0]}</span></div>`).join('')}</div>`};
function profile(sc){S.mode='title';S.view='menu';const l=lvl(P.xp),a=lvx(l),b=lvx(l+1);if(sc===1)profile.tab='Trophies';else if(sc&&sc!==true)profile.tab=sc;const tab=profile.tab||'Overview';profile.tab=tab;
 const nm=()=>{P.name=($('nm')&&$('nm').value.trim())||'Hero';save()},tabs=['Overview','Customize','Trophies'];
 let body='';
 if(tab==='Overview')body=`${statTiles()}<div class="pfcols">${presBlock()}<div class="lo"><h3>Your loadout</h3><p><b style="color:${PATHS[P.path].c}">${PATHS[P.path].n} path</b>: ${PATHS[P.path].d}</p><p><b style="color:${WP[P.weapon].col}">${WP[P.weapon].n}</b>: ${WP[P.weapon].d}</p><p><b style="color:${AR[P.armor].col}">${AR[P.armor].n}</b>: ${AR[P.armor].d}</p><button class="sm" id="wp2">Change in the Armory</button></div></div>`;
 else if(tab==='Customize')body=`<div class="pfcust"><p>Pick the colour of your banner. Armor dye tints your armor to match.</p>${dyeUI()}</div>`;
 else body=trophyCase(profile.cat);
 show(`<h2>Profile</h2><div class="pfhead"><canvas id="ph" width="300" height="340"></canvas><div class="pi"><input id="nm" maxlength="14" value="${esc(P.name)}" aria-label="Player name" title="Click to rename"><div class="rk">${P.pres?'Prestige '+PRN[P.pres-1]+' · ':''}${rankOf(l)}, level ${l}${l>=MAXLV?' (MAX)':''}</div><div class="xp" style="min-width:380px"><i style="width:${xpPct(P.xp)}%"></i></div><div style="font:15px Georgia,serif;opacity:.8">${(P.xp-a).toLocaleString()} / ${(b-a).toLocaleString()} XP to level ${l+1}</div><div class="row" style="justify-content:flex-start;margin-top:6px"><button class="sm" id="ut">Skill tree</button><button class="sm dg" id="rs">Reset save</button></div></div></div>
<div class="tabs ctabs">${tabs.map(t=>`<button class="tab${t===tab?' on':''}" data-pt="${t}">${t}${t==='Trophies'?` ${ACH.filter(a=>P.ach[a.id]).length}/${ACH.length}`:''}</button>`).join('')}</div><div class="pfbody">${body}</div><button class="sm" id="b">Back</button>`,'m');
 live('ph',c=>heroView(c,{scale:2.2}));S.back=title;
 $('ut').onclick=()=>{nm();upgrades()};ov.querySelectorAll('[data-pt]').forEach(el=>el.onclick=()=>{nm();profile(el.dataset.pt)});ov.querySelectorAll('[data-tc]').forEach(el=>el.onclick=()=>{nm();profile.cat=el.dataset.tc;profile('Trophies')});
 $('nm').onchange=nm;if($('wp2'))$('wp2').onclick=()=>{nm();armory()};
 dyeBind(()=>{nm();profile()});presBind();
 $('b').onclick=()=>{nm();title()};
 $('rs').onclick=e=>{const t=e.target;if(t.dataset.a){sgSnap('Before erase','safe');sgMuteOffer();P=fresh();save();title()}else{t.dataset.a=1;t.textContent='Click again to erase. A backup is kept.';setTimeout(()=>{if(t.isConnected){t.dataset.a='';t.textContent='Reset save'}},3000)}}}

/* ---------- armory ---------- */
let prevA=null,prevW=null,prevMK=null;
/* armory() lives in 76_armory.js */

/* ---------- campaign map ---------- */
let campSel=0;
const cleared=n=>n<P.camp||!!P.stars[n];
const GR={30:[1,1260],29:[2,1215],26:[3,1195],28:[4,1190],27:[5,1165]};
/* campaign() lives in 75_campaign.js */

/* ---------- settings / help ---------- */
function settings(back){S.mode=S.mode==='pause'?'pause':'title';
 const seg=(k,opts)=>`<div class="seg">${opts.map(([v,l])=>`<button class="sm${String(ST[k])===String(v)?' on':''}" data-k="${k}" data-v="${v}">${l}</button>`).join('')}</div>`;
 show(`<h2>Settings</h2><div class="opts">
<div class="opt"><div><label>Display size</label><small>Fit window fills your screen. Pick a smaller size if you want a smaller game window.</small></div>${seg('size',[['fit','Fit window'],['1','Native'],['0.8','80%'],['0.6','60%']])}</div>
<div class="opt"><div><label>Resolution</label><small>Higher settings look sharper but need a stronger computer.</small></div>${seg('res',[['auto','Auto'],['1','Standard'],['1.5','High'],['2','Ultra']])}</div>
<div class="opt"><div><label>Fullscreen</label><small>Also works with the Fullscreen button in the corner.</small></div><button class="sm" id="fsb">Toggle fullscreen</button></div>
<div class="opt"><div><label>Touch controls</label><small>On-screen keyboard and big buttons for phones and tablets. Auto turns on for touch screens.</small></div>${seg('touch',[['auto','Auto'],['on','On'],['off','Off']])}</div>
<div class="opt"><div><label>Boss cutscenes</label><small>Camera zoom, name card and roar when a boss arrives. Press any key to skip.</small></div>${seg('cine',[[true,'On'],[false,'Off']])}</div>
<div class="opt"><div><label>Music</label><small>Also works with the Music button in the corner.</small></div>${seg('mute',[[false,'On'],[true,'Off']])}</div>
<div class="opt"><div><label>Music volume</label></div><input type="range" id="mv" min="0" max="100" value="${Math.round(ST.mvol*100)}"></div>
<div class="opt"><div><label>Effects volume</label></div><input type="range" id="sv" min="0" max="100" value="${Math.round(ST.svol*100)}"></div>
<div class="opt"><div><label>Screen shake</label></div>${seg('shake',[[true,'On'],[false,'Off']])}</div>
<div class="opt"><div><label>Flash effects</label><small>Turn off to reduce bright screen flashes.</small></div>${seg('flash',[[true,'On'],[false,'Off']])}</div>
<div class="opt"><div><label>Menu background</label><small>Scenery behind the main menu. Unlocks as you clear campaign maps.</small></div><div class="pmsel"><img src="${hbgThumb(hbgCur())}" alt=""><div><b>${hbgName(hbgCur())}</b><button class="sm" id="hbgs">Change</button></div></div></div>
<div class="opt"><div><label>Show FPS</label></div>${seg('fps',[[true,'On'],[false,'Off']])}</div>
<div class="opt"><div><label>Save and backups</label><small>Export and import your progress, and restore automatic backups. <span id="bkm">${esc(sgStatus().h)}.</span></small></div><button class="sm hgd" id="svo2">Open Save Center</button></div></div></div><button class="sm" id="b">Back</button>`);
 S.back=back;settingsTabs();if($('hbgs'))$('hbgs').onclick=()=>hbgPick(()=>settings(back));
 ov.querySelectorAll('[data-k]').forEach(el=>el.onclick=()=>{const k=el.dataset.k,v=el.dataset.v;ST[k]=v==='true'?true:v==='false'?false:v;saveST();applyLayout();if(k==='mute'){mlab();applyVol();ensureAudio()}settings(back)});
 $('svo2').onclick=()=>saveCenter(()=>settings(back));
 $('fsb').onclick=toggleFS;$('mv').oninput=e=>{ST.mvol=e.target.value/100;saveST();applyVol()};$('sv').oninput=e=>{ST.svol=e.target.value/100;saveST();applyVol();beep(660,.08,'triangle',.8)};
 $('b').onclick=back}
const HELP={
'Basics':[['Type','Type the word above a monster to strike it down. Your first letter picks the target. The next letter to type is underlined.'],['Streaks','Land letters without a slip to build a streak and raise your score multiplier. Each word forgives one slip.'],['Enter','Fire a Fury Strike when the fury bar is full. It defeats every monster on screen and breaks one boss phase.'],['Tab','Drop your current target so you can pick another monster.'],['Esc','Pause, or go back in a menu. Every menu also has a Back button in the top-right corner.'],['1 2 3','Pick a boon between rounds. Boons last for the current run.']],
'Bosses':[['Space','Boss fights need the space bar. Type the boss\'s sentence, spaces included. When it says PRESS SPACE, hit it to land the blow. When it says SPACE to parry, hit it to stop the strike. Space also parries arrows and spells.'],['Attacks','Bosses hurl orbs, slam the ground, call meteors and summon minions. A warning appears first. Press SPACE to parry anything flying at you.'],['Wards','Some bosses raise a ward. Type the fresh sentence to shatter it before the weak spot opens.']],
'Progress':[['Paths','Reach player level 4 for the Archer, 7 for the Mage and 10 for the Rogue. Each path has its own weapons and a perk. Switch paths in the Armory.'],['Gold','You earn gold from kills, cleared rounds, bosses, finished campaign levels and level ups. Spend it in the Shop. A daily gift is waiting on the main menu.'],['Skill tree','Spend gold or skill points (one per player level, plus some from trophies) on permanent perks. You can respec for a 25% gold fee.'],['Mastery','Every weapon levels up as you use it. It gains a small unique bonus and a glow at two tiers.'],['Crates','Monsters and bosses sometimes drop crates. Open them from the Crates tile on the main menu. Epic and legendary gear is very rare.'],['Trophies','Every achievement pays gold and sometimes skill points. Your trophy case is in your Profile.'],['Prestige','Reach level 30 and clear the campaign to prestige. You restart with exclusive armor, a profile badge and permanent perks.']],
'Modes':[['Warden\'s Arena','Limited time, in Starfall Rift\'s spot. Gladiator duels with no typing: 5 waves and a boss. A red ! means an attack is coming and a marker slides along the bar. Press Space (or tap Block) when it reaches the green zone, gold for a PERFECT block. Too early or too late and you get hit. A purple ? is a FEINT: do not block it. When the marker freezes (…), wait. After a block the foe is EXPOSED: press Enter (or click, or tap Strike) to counter. Every new foe pauses the fight with a card that explains its trick, and Foes & Bosses shows them again. Wins climb the Trophy Road, which unlocks Silver at 150 and Gold at 450 trophies and pays coins along the way.'],['Campaign','Thirty hand-built levels in five acts. Clear each one to unlock the next, and earn up to three stars.'],['Endless','Survive round after round as monsters get faster and stranger. Chase a best round and a best score.'],['Beginner\'s Mode','Found in the Endless menu. Words are 3 to 5 letters, rounds have fewer monsters and boss sentences are short, with tips along the way. It pays half and does not count toward records, trophies or bounties.'],['Starfall Rift','Unlocks at level 5. A 60-second sprint where kills add time. Every 12 kills triggers a Starfall with triple score. Huge XP and weapon XP.'],['Practice','Drill your typing with your own words, speed and goals. It gives no XP or gold, but shows a keyboard heatmap and your weak keys.'],['Casino','Click the small red chip icon in the corner of a menu to visit the casino. The house has a small edge, so play with gold you can spare.']],
'Shortcuts':[['C E R M','On the main menu: Campaign, Endless, Warden\'s Arena (in Starfall Rift\'s spot for now), Monster Mash (while it lasts). Practice Range lives in the Play tab.'],['A K S X','Armory, Skill tree, Shop, Crates.'],['L O T','Catalog, Profile, Trophies.'],['Enter','Continue your campaign from the main menu.'],['H ,','How to play and Settings.'],['Touch','On a phone or tablet an on-screen keyboard appears with Space, Fury, Drop and Pause buttons.']]};
function help(back,tab){tab=tab||help.tab||'Basics';help.tab=tab;
 show(`<h2>How to play</h2><div class="tabs ctabs">${Object.keys(HELP).map(t=>`<button class="tab${t===tab?' on':''}" data-ht="${t}">${t}</button>`).join('')}</div><div class="help">${HELP[tab].map(r=>`<kbd class="k">${r[0]}</kbd><span>${r[1]}</span>`).join('')}</div><button class="sm" id="b">Back</button>`,'m');S.back=back;$('b').onclick=back;
 ov.querySelectorAll('[data-ht]').forEach(el=>el.onclick=()=>help(back,el.dataset.ht))}

/* ---------- in-run screens ---------- */
function boons(){S.mode='boon';const p=[];let n=0;while(p.length<3&&n++<300){const q=Math.random(),r=q<.6?0:q<.86?1:(q<.965||!S.camp||S.bl.some(x=>(BOONS.find(y=>y.n===x.n)||{}).r===3))?2:3,pl=BOONS.filter(b=>b.r===r&&!p.includes(b)&&!(b.u&&S.tk[b.u]));if(pl.length){const ws=pl.map(b=>boonW(b,S)),tt=ws.reduce((a,b)=>a+b,0);let x=Math.random()*tt,i=0;for(;i<pl.length-1;i++){x-=ws[i];if(x<=0)break}p.push(pl[i])}}
 show(`<h2>Round cleared</h2><p>Claim a boon to carry through the rest of this run.${S.camp?'':` (${S.bn} of ${BOONCAP} boons taken)`} Taking the same kind of boon again gets less likely.</p><div class="boons">${p.map((b,i)=>`<button class="bc r${b.r}" data-i="${i}" style="--c:${BC[b.r]};animation-delay:${i*.18}s"><kbd>${i+1}</kbd><span class="ic">${boonIc(b,136)}</span><b>${b.n}</b><small>${b.d}</small><em>${BR[b.r]}${S.gc['n:'+b.n]?' &middot; you own '+S.gc['n:'+b.n]:''}</em></button>`).join('')}</div>${S.rr>0?'<button class="sm" id="rr">Reroll (1 left)</button>':''}`);
 S.boonList=p;jingle('boon');
 ov.querySelectorAll('.bc').forEach(el=>el.onclick=()=>pickBoon(+el.dataset.i));if($('rr'))$('rr').onclick=()=>{S.rr--;boons()}}
const BSN_ADD=['max','rev','cq','cl','fg'],BSN_MUL=['sc','furyMul','slow'],BSN_FLAG=['vamp','chain','regen','thund','moon','revFull'];
const boonSnap=s=>{const o={};for(const k of[...BSN_ADD,...BSN_MUL,...BSN_FLAG])o[k]=s[k]||0;return o};
function boonDelta(a,s){const d={fl:{}};for(const k of BSN_ADD)d[k]=(s[k]||0)-a[k];for(const k of BSN_MUL)d[k]=a[k]?(s[k]||0)/a[k]:1;for(const k of BSN_FLAG)if((s[k]||0)!==a[k])d.fl[k]=[a[k],s[k]];return d}
function boonMerge(x,y){if(!x)return y;const d={fl:Object.assign({},x.fl,y.fl)};for(const k of BSN_ADD)d[k]=(x[k]||0)+(y[k]||0);for(const k of BSN_MUL)d[k]=(x[k]||1)*(y[k]||1);for(const k in y.fl)if(x.fl[k])d.fl[k]=[x.fl[k][0],y.fl[k][1]];return d}
function boonApply(b){const a=boonSnap(S);b.f(S);const d=boonDelta(a,S);if(b.u)S.tk[b.u]=1;S.bn++;for(const g of BG[b.n]||[b.n])S.gc[g]=(S.gc[g]||0)+1;S.gc['n:'+b.n]=(S.gc['n:'+b.n]||0)+1;const ex=S.bl.find(q=>q.n===b.n);if(ex){ex.c++;ex.fx=boonMerge(ex.fx,d)}else S.bl.push({n:b.n,r:b.r,d:b.d,i:b.i,c:1,fx:d});return ex||S.bl[S.bl.length-1]}
/* take a boon back out: undo what it changed for good (shields, HP and fury that were already spent or healed stay as they are) */
function boonRemove(e){const x=e.fx;if(x){
  for(const k of['sc','furyMul'])if(x[k])S[k]/=x[k];if(x.slow)S.slow=Math.min(1,S.slow/x.slow);
  S.max=Math.max(1,S.max-(x.max||0));S.hp=Math.min(S.hp,S.max);S.rev=Math.max(0,S.rev-(x.rev||0));S.cq=Math.max(0,S.cq-(x.cq||0));S.cl=Math.max(0,S.cl-(x.cl||0));S.fg=Math.max(0,S.fg-(x.fg||0));
  for(const k in x.fl)S[k]=x.fl[k][0]}
 const B=BOONS.find(q=>q.n===e.n);for(const g of BG[e.n]||[e.n])S.gc[g]=Math.max(0,(S.gc[g]||0)-e.c);S.gc['n:'+e.n]=0;if(B&&B.u)S.tk[B.u]=0;S.bl=S.bl.filter(q=>q!==e)}
function pickBoon(i){if(S.swap)return swapPick(i);if(S.mode!=='boon'||!S.boonList[i])return;const b=S.boonList[i];boonApply(b);S.mode='play';hide();startWave()}
/* after the boon limit, endless mode offers a swap at the end of every level: a Common or Rare replaces one boon you hold */
function swapOffers(){const own=new Set(S.bl.map(q=>q.n)),ok=b=>b.r<=1&&!own.has(b.n)&&!(b.u&&S.tk[b.u]),p=[];let n=0;
 while(p.length<3&&n++<300){const r=Math.random()<.65?0:1,pl=BOONS.filter(b=>b.r===r&&ok(b)&&!p.includes(b));if(!pl.length)continue;const ws=pl.map(b=>boonW(b,S)),tt=ws.reduce((a,b)=>a+b,0);let x=Math.random()*tt,i=0;for(;i<pl.length-1;i++){x-=ws[i];if(x<=0)break}p.push(pl[i])}
 return p}
function boonSwap(){const p=swapOffers();if(!p.length){S.hp=Math.min(S.max,S.hp+1);float(W/2,300,'Boon limit reached: +1 HP','#7dffb0',44);gain(20);startWave();return}
 S.mode='boon';S.swap={step:1,opts:p,pick:null};S.boonList=p;
 show(`<h2>Level cleared</h2><p>You hold ${S.bl.length} boons, the limit. Pick a new boon, then choose which of yours to give up. Only Common and Rare boons are offered now, and you cannot take one you already have.</p><div class="boons">${p.map((b,i)=>`<button class="bc r${b.r}" data-i="${i}" style="--c:${BC[b.r]};animation-delay:${i*.18}s"><kbd>${i+1}</kbd><span class="ic">${boonIc(b,136)}</span><b>${b.n}</b><small>${b.d}</small><em>${BR[b.r]}</em></button>`).join('')}</div><button class="sm" id="bsk">Keep my boons (+1 HP)</button>`);
 jingle('boon');ov.querySelectorAll('.bc').forEach(el=>el.onclick=()=>swapPick(+el.dataset.i));
 $('bsk').onclick=()=>{S.swap=null;S.mode='play';hide();S.hp=Math.min(S.max,S.hp+1);float(W/2,300,'Boons kept: +1 HP','#7dffb0',44);gain(20);startWave()}}
function swapPick(i){const w=S.swap;if(!w||S.mode!=='boon'||w.step!==1||!w.opts[i])return;w.pick=w.opts[i];w.step=2;const b=w.pick;
 show(`<h2>Replace which boon?</h2><p>${b.n} (${BR[b.r]}): ${b.d}.<br>Choose the boon it will replace.</p><div class="bswg">${S.bl.map((q,k)=>`<button class="bsw" data-k="${k}" style="--c:${BC[q.r]}"><span class="ic">${boonIc(q,56)}</span><b>${q.n}${q.c>1?' x'+q.c:''}</b><i>${BR[q.r]}</i><small>${q.d}</small></button>`).join('')}</div><button class="sm" id="bsb">Back</button>`);
 ov.querySelectorAll('.bsw').forEach(el=>el.onclick=()=>swapDo(+el.dataset.k));$('bsb').onclick=()=>{w.step=1;boonSwap.again()}}
boonSwap.again=()=>{const w=S.swap;if(!w)return;S.swap=null;const o=w.opts;S.mode='boon';S.swap={step:1,opts:o,pick:null};S.boonList=o;
 show(`<h2>Level cleared</h2><p>You hold ${S.bl.length} boons, the limit. Pick a new boon, then choose which of yours to give up. Only Common and Rare boons are offered now, and you cannot take one you already have.</p><div class="boons">${o.map((b,i)=>`<button class="bc r${b.r}" data-i="${i}" style="--c:${BC[b.r]}"><kbd>${i+1}</kbd><span class="ic">${boonIc(b,136)}</span><b>${b.n}</b><small>${b.d}</small><em>${BR[b.r]}</em></button>`).join('')}</div><button class="sm" id="bsk">Keep my boons (+1 HP)</button>`);
 ov.querySelectorAll('.bc').forEach(el=>el.onclick=()=>swapPick(+el.dataset.i));$('bsk').onclick=()=>{S.swap=null;S.mode='play';hide();S.hp=Math.min(S.max,S.hp+1);float(W/2,300,'Boons kept: +1 HP','#7dffb0',44);gain(20);startWave()}}
function swapDo(k){const w=S.swap;if(!w||w.step!==2)return;const old=S.bl[k],nb=w.pick;if(!old||!nb||old.n===nb.n)return;
 boonRemove(old);const keepBn=S.bn;const e=boonApply(nb);S.bn=Math.max(keepBn,BOONCAP);const at=S.bl.indexOf(e);if(at>=0&&k<=S.bl.length-1){S.bl.splice(at,1);S.bl.splice(Math.min(k,S.bl.length),0,e)}
 S.swap=null;S.mode='play';hide();float(W/2,300,old.n+' swapped for '+nb.n,'#ffd76a',40);jingle('boon');startWave()}
function pauseMenu(){show(`<h2>Paused</h2><p>${S.dc?`Daily Challenge #${S.dc.n}, round ${S.round} of 5`:S.rift?'Starfall Rift':S.prac?'Practice Range':S.gy?`Monster Mash, level ${lvOf(S.wave)}, round ${S.round} of 5`:S.bg?`Beginner's Mode, level ${lvOf(S.wave)}, round ${S.round} of 5`:S.camp?`Campaign level ${S.camp}, round ${S.round} of 5`:`Level ${lvOf(S.wave)}, round ${S.round} of 5`}   Score ${S.score.toLocaleString()}</p>${tipLine()}<div class="row"><button id="rs1">Resume</button></div><div class="row"><button class="sm" id="st">Settings</button><button class="sm" id="hp">How to play</button>${S.bl.length?'<button class="sm" id="bl">Boons</button>':''}</div><div class="row">${S.dc?'':'<button class="sm" id="rs2">Restart</button>'}<button class="sm dg" id="qt">${S.dc?'Forfeit':'End run'}</button></div>`);
 if($('rs2'))$('rs2').onclick=e=>{const t=e.target;if(t.dataset.a){S.mode='play';start(S.camp||0,S.rift?'rift':S.prac?'prac':S.bg?'bg':S.gy?'gy':undefined)}else{t.dataset.a=1;t.textContent='Click again to restart';setTimeout(()=>{if(t.isConnected){t.dataset.a='';t.textContent='Restart'}},3000)}};if($('bl'))$('bl').onclick=boonList;
 S.back=resume;$('rs1').onclick=resume;$('st').onclick=()=>settings(pauseMenu);$('hp').onclick=()=>help(pauseMenu);$('qt').onclick=()=>{S.mode='play';over(1)}}
function boonList(){S.mode='pause';show(`<h2>Your boons</h2><p>${S.camp?'':`${S.bn} of ${BOONCAP} taken this run. `}They last until the run ends.</p><div class="bl">${S.bl.map(b=>`<div style="--c:${BC[b.r]}"><span class="ic">${boonIc(b,56)}</span><b>${b.n}${b.c>1?' x'+b.c:''}</b><i>${BR[b.r]}</i><small>${b.d}</small></div>`).join('')}</div><div class="row"><button id="rs1">Resume</button></div>`);S.back=resume;$('rs1').onclick=resume}
function pause(){if(S.mode!=='play')return;S.mode='pause';pauseMenu()}
function resume(){if(S.mode!=='pause')return;S.mode='play';hide()}
function levelGold(l0,l1){const g=Math.max(0,l1-l0)*100;if(g)P.gold+=g;return g}
function finishRun(){try{btyRunEnd()}catch(x){}const l0=lvl(P.xp);for(const c of S.cr)collect(c);S.cr=[];P.kills+=S.kills;P.runs++;stat('wpm',wpmValid()?S.wpm:0,'max');stat('combo',S.maxCombo,'max');P.bestCombo=Math.max(P.bestCombo,S.maxCombo);P.bestWpm=Math.max(P.bestWpm,wpmValid()?S.wpm:0);setTimeout(achCheck,30);return l0}
const pathMsg=(l0,l1)=>PK.filter(p=>PATHS[p].lv>l0&&PATHS[p].lv<=l1).map(p=>`<br><b style="color:${PATHS[p].c}">New path unlocked: ${PATHS[p].n}! Choose it in the Armory.</b>`).join('');
function resBlock(){const acc=S.chars?Math.round(S.ok/S.chars*100):100;return `<div class="res"><div><b>${S.score.toLocaleString()}</b>Score</div><div><b>${S.wpm}</b>Words per minute</div><div><b>${acc}%</b>Accuracy</div><div><b>${S.maxCombo}</b>Best streak</div><div><b>${S.kills}</b>Monsters slain</div>${(S.gsA&&S.gsA>1.005)?`<div><b>${S.gsA.toFixed(2).replace(/0$/,'')}×</b>Avg game speed</div>`:''}</div>${btyResultNotice(S.btyWpmCompleted)}`}
const ENDXP=.5;/* Endless mode XP payout multiplier */
function over(quit){if(S.mode==='over')return;if(S.dc)return dcOver(quit,0);if(S.rift)return riftOver(quit);if(S.prac)return pracEnd(quit);if(S.gy)return gyOver(quit);if(S.bg)return bgOver(quit);S.mode='over';const cm=S.camp,xp=cm?xpCampLoss(cm):xpMode(Math.round((S.score/16+S.wave*8)*xpMulRun()*ENDXP)),xn=xpNoteH(),nb=!cm&&S.score>P.best,l0=finishRun(),wxm=wxpEnd();
 P.xp+=xp;if(!cm){if(nb)P.best=S.score;P.bestWave=Math.max(P.bestWave,S.wave);P.bestLv=Math.max(P.bestLv,lvOf(S.wave))}else P.cbest[cm]=Math.max(P.cbest[cm]||0,S.score);save();jingle('lose');
 const l1=lvl(P.xp),cr=S.runC||0,lg=levelGold(l0,l1);save();
 const later=()=>{show(`<h2>The knight has fallen</h2>${resBlock()}<p>${nb?'<b style="color:var(--gold)">New high score!</b> ':''}${cm?`Campaign level ${cm}.`:`Reached level ${lvOf(S.wave)}, round ${S.round} of 5.`}${S.by&&!quit?` Slain by ${esc(S.by)}.`:''} Earned ${xp} XP, ${S.gold+lg} gold and ${cr} crate${cr===1?'':'s'}.${xn}${wxm}${l1>l0?`<br><b style="color:var(--gold)">Level up! You are now level ${l1}, ${rankOf(l1)}. Bonus: ${lg} gold.</b>`:''}${pathMsg(l0,l1)}</p>${tipLine()}<div class="row"><button id="go">Rise again</button><button class="sm" id="hm">Home</button>${cm?'<button class="sm" id="mp">Campaign map</button>':''}</div>`);
 $('go').onclick=()=>start(cm);$('hm').onclick=title;if($('mp'))$('mp').onclick=()=>campaign()};
 if(quit)later();else{S.pose='dead';S.poseT=0;S.landed=0;S.late=later;S.lateAt=2.2}}
function victory(){S.mode='over';const n=S.camp,prevCl=!!P.stars[S.camp],stars=1+(S.dmgTaken<=2?1:0)+(S.dmgTaken===0?1:0),xp=xpCampWin(n,stars,!prevCl),l0=finishRun(),wxm=wxpEnd();
 if(S.chars>=150)stat('acc',Math.round(S.ok/S.chars*100),'max');P.xp+=xp;P.camp=Math.max(P.camp,Math.min(30,n+1));P.stars[n]=Math.max(P.stars[n]||0,stars);P.cbest[n]=Math.max(P.cbest[n]||0,S.score);save();jingle('win');
 const vg=Math.round((80+n*10+stars*30)*(prevCl?.5:1)*(S.gsA||1));P.gold+=vg;const xn=xpNoteH();const l1=lvl(P.xp),Z=lvN(n),cr=S.runC||0,lg=levelGold(l0,l1);save();
 S.pose='victory';S.poseT=0;const later=()=>{show(`<h1 style="font-size:120px">Victory</h1><div style="font-size:64px;color:var(--gold);letter-spacing:10px;text-shadow:0 0 20px #ffb02e">${'★'.repeat(stars)}<span style="opacity:.3">${'★'.repeat(3-stars)}</span></div><p>Level ${n} conquered in ${Z.n}.</p>${resBlock()}<p>Earned ${xp} XP, ${S.gold+vg+lg} gold and ${cr} crate${cr===1?'':'s'}.${xn}${wxm}${l1>l0?`<br><b style="color:var(--gold)">Level up! You are now level ${l1}, ${rankOf(l1)}. Bonus: ${lg} gold.</b>`:''}${pathMsg(l0,l1)}</p>${canPres()?'<p><b style="color:var(--gold)">You can now Prestige! Open your Profile or the title screen to ascend.</b></p>':''}<div class="row">${n<30?'<button id="nx">Next level</button>':''}<button class="sm" id="mp">Campaign map</button><button class="sm" id="hm">Home</button></div>`,'m');
 if($('nx'))$('nx').onclick=()=>start(n+1);$('mp').onclick=()=>campaign(n<30?n+1:n);$('hm').onclick=title};
 try{btyClear()}catch(e){}try{sgMilestone('Level cleared')}catch(e){}S.late=later;S.lateAt=1.6}
