/* ===== WILDCARD: Nostr relays as a second kind of room-code relay =====
   School and office networks usually allow only ordinary web traffic on port 443. The MQTT brokers in 89k mostly use
   other ports, so a second, independent family of relays helps: public Nostr relays, which all speak plain JSON over a
   secure WebSocket on port 443. Each message is a short-lived ("ephemeral", kind 2xxxx) event that relays pass on to
   anyone subscribed and never store. The content is the same AES-GCM ciphertext the MQTT path carries, so relays only
   see scrambled bytes. Nostr requires every event to be signed (BIP-340 Schnorr over secp256k1); a throwaway key is
   made for each page load. wcNostr(url, topics, onMsg, onState) has the same shape as wcMq. */
const WCNK=25051;
const WCEC={p:2n**256n-2n**32n-977n,n:0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141n,
 gx:0x79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798n,gy:0x483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8n};
const wcMd=(a,m)=>{const r=a%m;return r<0n?r+m:r};
function wcPw(b,e,m){let r=1n;b=wcMd(b,m);while(e>0n){if(e&1n)r=r*b%m;b=b*b%m;e>>=1n}return r}
/* Jacobian points [X,Y,Z]; Z=0 is the point at infinity */
function wcJd([X,Y,Z]){const p=WCEC.p;if(Y===0n||Z===0n)return[0n,1n,0n];const A=X*X%p,B=Y*Y%p,C=B*B%p,D=wcMd(2n*((X+B)*(X+B)-A-C),p),E=3n*A%p,F=E*E%p,X3=wcMd(F-2n*D,p);
 return[X3,wcMd(E*(D-X3)-8n*C,p),2n*Y*Z%p]}
function wcJa(P,Q){const p=WCEC.p;if(P[2]===0n)return Q;if(Q[2]===0n)return P;const [X1,Y1,Z1]=P,[X2,Y2,Z2]=Q,Z1s=Z1*Z1%p,Z2s=Z2*Z2%p,U1=X1*Z2s%p,U2=X2*Z1s%p,S1=Y1*Z2s%p*Z2%p,S2=Y2*Z1s%p*Z1%p;
 if(U1===U2)return S1===S2?wcJd(P):[0n,1n,0n];const H=wcMd(U2-U1,p),R=wcMd(S2-S1,p),H2=H*H%p,H3=H2*H%p,U1H2=U1*H2%p,X3=wcMd(R*R-H3-2n*U1H2,p);
 return[X3,wcMd(R*(U1H2-X3)-S1*H3,p),H*Z1%p*Z2%p]}
function wcMul(k){let R=[0n,1n,0n],A=[WCEC.gx,WCEC.gy,1n];while(k>0n){if(k&1n)R=wcJa(R,A);A=wcJd(A);k>>=1n}
 const p=WCEC.p,zi=wcPw(R[2],p-2n,p),zi2=zi*zi%p;return[R[0]*zi2%p,R[1]*zi2%p*zi%p]}
const wcB2n=b=>BigInt('0x'+(Array.from(b,x=>x.toString(16).padStart(2,'0')).join('')||'0'));
const wcN2b=n=>{const h=n.toString(16).padStart(64,'0'),b=new Uint8Array(32);for(let i=0;i<32;i++)b[i]=parseInt(h.slice(i*2,i*2+2),16);return b};
const wcHx=b=>Array.from(b,x=>x.toString(16).padStart(2,'0')).join('');
const wcCat=(...a)=>{const o=new Uint8Array(a.reduce((s,x)=>s+x.length,0));let i=0;for(const x of a){o.set(x,i);i+=x.length}return o};
async function wcSha(b){return new Uint8Array(await crypto.subtle.digest('SHA-256',b))}
async function wcTag(t,b){const h=await wcSha(wcTE.encode(t));return wcSha(wcCat(h,h,b))}
/* BIP-340: secret key d0 (bigint), message m (32 bytes), aux (32 bytes) -> 64-byte signature */
async function wcSchnorr(d0,m,aux){const n=WCEC.n,P=wcMul(d0),d=P[1]%2n===0n?d0:n-d0,px=wcN2b(P[0]);
 const t=wcN2b(d^wcB2n(await wcTag('BIP0340/aux',aux))),k0=wcB2n(await wcTag('BIP0340/nonce',wcCat(t,px,m)))%n;if(k0===0n)throw new Error('bad nonce');
 const R=wcMul(k0),k=R[1]%2n===0n?k0:n-k0,rx=wcN2b(R[0]),e=wcB2n(await wcTag('BIP0340/challenge',wcCat(rx,px,m)))%n;return wcCat(rx,wcN2b((k+e*d)%n))}
const WCNS={d:0n,pk:''};
function wcNostrKey(){if(!WCNS.pk){let d=0n;while(d===0n||d>=WCEC.n)d=wcB2n(crypto.getRandomValues(new Uint8Array(32)));WCNS.d=d;WCNS.pk=wcHx(wcN2b(wcMul(d)[0]))}return WCNS}
/* one signed event per message, shared by every relay it goes to */
const WCNEV=new WeakMap();
function wcNostrEvent(topic,bytes){let m=WCNEV.get(bytes);if(!m){m=new Map();WCNEV.set(bytes,m)}if(m.has(topic))return m.get(topic);
 const pr=(async()=>{const K=wcNostrKey(),ev={pubkey:K.pk,created_at:Math.floor(Date.now()/1000),kind:WCNK,tags:[['t',topic]],content:btoa(String.fromCharCode(...bytes))};
  const id=await wcSha(wcTE.encode(JSON.stringify([0,ev.pubkey,ev.created_at,ev.kind,ev.tags,ev.content])));ev.id=wcHx(id);ev.sig=wcHx(await wcSchnorr(K.d,id,crypto.getRandomValues(new Uint8Array(32))));return ev})();
 m.set(topic,pr);return pr}
function wcNostr(url,topics,onMsg,onState){const o={ok:false,ws:null,dead:false,sub:'tw'+Math.random().toString(36).slice(2,10),nostr:1};
 try{o.ws=new WebSocket(url)}catch(e){o.dead=true;setTimeout(()=>onState('closed',o),0);return o}
 const send=x=>{try{if(o.ws.readyState===1)o.ws.send(JSON.stringify(x))}catch(e){}};
 o.ws.onopen=()=>{send(['REQ',o.sub,{kinds:[WCNK],'#t':topics,since:Math.floor(Date.now()/1000)-30}]);o.ok=true;onState('open',o)};
 o.ws.onmessage=e=>{let a;try{a=JSON.parse(e.data)}catch(x){return}if(!Array.isArray(a))return;
  if(a[0]==='EVENT'&&a[1]===o.sub&&a[2]&&a[2].kind===WCNK){const ev=a[2],tg=(ev.tags||[]).find(t=>t[0]==='t'&&topics.includes(t[1]));if(!tg)return;
   try{const s=atob(String(ev.content||'')),b=new Uint8Array(s.length);for(let i=0;i<s.length;i++)b[i]=s.charCodeAt(i);onMsg(tg[1],b)}catch(x){}}
  else if(a[0]==='CLOSED'&&a[1]===o.sub){o.close();onState('closed',o)}};
 o.ws.onclose=o.ws.onerror=()=>{if(o.dead)return;o.dead=true;o.ok=false;onState('closed',o)};
 o.pub=(tp,bytes)=>{if(!o.ok)return;wcNostrEvent(tp,bytes).then(ev=>{o.sent=1;send(['EVENT',ev])},()=>{})};
 o.close=()=>{if(o.dead&&!o.ok)return;o.dead=true;o.ok=false;try{send(['CLOSE',o.sub]);o.ws.close()}catch(e){}};return o}
