/* ===== 10.4 HARVEST FESTIVAL: the Harvest Chest in the menus (99o3, prefix flc; after 99o2) =====
   - Crate key 'f' (CN / CT / CRN / PRICE): count P.fcr, pity P.fcpity, waiting grants P.flcPend; all repaired on load (sgShape + load).
   - flcAdd(n, src): adds chests with a toast (for the market, the calendar and Harvest Moon Rush). flcOpenUI(back): the crates menu
     with the Harvest Chest in front. flcCollection(note): the "Harvest Collection" window (needs the shop; opens it if needed).
   - Shop: the Harvest Chest is sold for coins while the festival runs (SHOP gets the entry, with a LIMITED ribbon), its odds window shows
     the rarity pie (Legendary and Mythic secret) and everything inside, and a Harvest Collection banner sits beside the Graveyard one.
   - Crates menu: a Harvest Chest banner in the seasonal section (scene, chest, odds, pity, Open / Open 10, the twelve relics); when the
     Graveyard Crate is up too, two tabs switch between them.
   - Catalog › Crates card, dock badges (Shop and Owned crates count the chests), DEV › Cheats section. */
CN.f=FL.chest.cnt;CT.f=FL.chest.n+' added!';CRN.f=FL.chest.n;PRICE.f=1500;
SH_INFO.f={c:'#ff9a3a',r:['Common','Mythic'],em:'leaf'};
const FLC_SHOP={k:'f',n:FL.chest.n,d:'Twelve harvest relics, one armor and one weapon for every rarity, plus purses of gold, acorns and two rare companions. Limited time.'};
const flcSell=()=>{try{return flOn()}catch(e){return false}};
const flcShow=()=>{try{return flOn()||(P.fcr|0)>0||flcCount()>0}catch(e){return false}};
function flcShopSync(){const i=SHOP.findIndex(o=>o.k==='f');if(flcSell()){if(i<0)SHOP.unshift(FLC_SHOP)}else if(i>=0)SHOP.splice(i,1)}
const flcItems=()=>FL.gear.a.map(id=>({kind:'a',id})).concat(FL.gear.w.map(id=>({kind:'w',id})));
const flcHas=it=>{const T=it.kind==='a'?AR:WP;return!!T[it.id]&&!!(it.kind==='a'?P.ownA:P.own)[it.id]};
function flcCount(){try{return flcItems().filter(flcHas).length}catch(e){return 0}}
const flcPct=n=>{const v=n*100;let s=v>=10?v.toFixed(v%1?1:0):v.toFixed(2);if(s.includes('.'))s=s.replace(/0+$/,'').replace(/\.$/,'');return s+'%'};

/* ---------- save repair ---------- */
function flcNorm(p){if(!p||typeof p!=='object')return p;p.fcr=Math.min(99999,Math.max(0,Math.floor(+p.fcr||0)));p.fcpity=Math.min(FLC_PITY-1,Math.max(0,Math.floor(+p.fcpity||0)));
 const ok=x=>x&&typeof x==='object'&&(x.k==='ac'&&+x.n>0&&+x.n<=1000||x.k==='pet'&&(x.id===FL.pets.r||x.id===FL.pets.l));
 p.flcPend=Array.isArray(p.flcPend)?p.flcPend.filter(ok).slice(0,20).map(x=>x.k==='ac'?{k:'ac',n:Math.floor(+x.n)}:{k:'pet',id:x.id}):[];return p}
if(typeof sgShape==='function'){const f0=sgShape;sgShape=function(o){return flcNorm(f0.apply(this,arguments))}}
{const l0=load;load=function(){const r=l0.apply(this,arguments);try{flcNorm(P);if(P.flcPend.length)setTimeout(()=>{try{if(S.mode!=='crate')flcPendRun()}catch(e){}},1500)}catch(e){}return r}}
{const sv0=save;save=function(){try{if(P&&typeof P==='object'&&(typeof P.fcr!=='number'||P.fcr<0||P.fcr%1))P.fcr=Math.max(0,Math.floor(+P.fcr||0))}catch(e){}return sv0.apply(this,arguments)}}

/* ---------- adding chests (other parts call this) ---------- */
function flcAdd(n,src){n=Math.max(0,Math.floor(+n||0));if(!n||!P)return 0;P.fcr=Math.max(0,P.fcr|0)+n;try{stat('fcg',n,'add')}catch(e){}save();flcToast(n,src);try{dkRefreshBadges()}catch(e){}return P.fcr}
function flcToast(n,src){try{const host=$('wrap')||document.body;let el=$('flctoast');const was=el&&el.classList.contains('on')?+(el.dataset.n||0):0,tot=was+n;
 if(!el){el=document.createElement('div');el.id='flctoast';el.setAttribute('role','status');el.innerHTML='<canvas width="96" height="72" aria-hidden="true"></canvas><div><b></b><small></small></div>';host.appendChild(el)}
 el.dataset.n=tot;el.querySelector('b').textContent=`+${tot} ${FL.chest.n}${tot>1?'s':''}`;el.querySelector('small').textContent=src?String(src).slice(0,60):'Open it from Shop › Owned crates';
 const cv=el.querySelector('canvas'),g=cv.getContext('2d');g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,96,72);try{flcChest(g,48,66,.36,0,1)}catch(e){}
 el.classList.remove('on');void el.offsetWidth;el.classList.add('on');clearTimeout(flcToast.tm);flcToast.tm=setTimeout(()=>{el.classList.remove('on');el.dataset.n=0},3200);
 try{beep(660,.08,'triangle',.5);setTimeout(()=>beep(990,.12,'triangle',.45),90)}catch(e){}}catch(e){}}
function flcOpenUI(back){crateHub();try{if(typeof back==='function'){S.back=back;const b=$('b');if(b)b.onclick=back}FLC.tab='f';flcTabSet('f');const el=$('flcb');if(el){el.scrollIntoView({block:'nearest'});el.classList.remove('flcping');void el.offsetWidth;el.classList.add('flcping')}}catch(e){}}

/* ---------- shared pieces: odds pie, relic strip, harvest scene ---------- */
function flcPie(){const R=60,cx=70,cy=70;let a0=-Math.PI/2,sl='';
 FLC_TIERP.forEach((p,i)=>{const a1=a0+p*TAU,big=a1-a0>Math.PI?1:0,x0=cx+R*Math.cos(a0),y0=cy+R*Math.sin(a0),x1=cx+R*Math.cos(a1),y1=cy+R*Math.sin(a1),c=RC[FL.rar[i]];
  sl+=`<path d="M${cx} ${cy}L${x0.toFixed(2)} ${y0.toFixed(2)}A${R} ${R} 0 ${big} 1 ${x1.toFixed(2)} ${y1.toFixed(2)}Z" fill="${c}" stroke="#1a0c08" stroke-width="1.5"><title>${FL.rar[i]}: ${FLC_HIDE[i]?'???':flcPct(p)}</title></path>`;a0=a1});
 return `<div class="flcpie"><svg viewBox="0 0 140 140" width="140" height="140" role="img" aria-label="Harvest Chest odds">${sl}<circle cx="${cx}" cy="${cy}" r="27" fill="#2a140a" stroke="#ffffff22"/><text x="${cx}" y="${cy-3}" text-anchor="middle" class="flcpt1">ODDS</text><text x="${cx}" y="${cy+12}" text-anchor="middle" class="flcpt2">per chest</text></svg>
 <div class="flclg">${FLC_TIERP.map((p,i)=>`<span style="--c:${RC[FL.rar[i]]}"><i></i>${FL.rar[i]}<b${FLC_HIDE[i]?' class="hq"':''}>${FLC_HIDE[i]?'???':flcPct(p)}</b></span>`).join('')}</div></div>`}
function flcStrip(){return `<div class="flcst">${flcItems().map(it=>{const d=(it.kind==='a'?AR:WP)[it.id],o=flcHas(it),r=d?d.r:FL.rar[FL.gear[it.kind].indexOf(it.id)],nm=d?d.n:FL.gearN[it.id];
 return `<span class="flci${o?' own':''}" style="--c:${RC[r]}" title="${esc(nm)} (${r})${o?'':' - not found yet'}"><canvas width="68" height="84" data-flc="${it.kind}:${it.id}"></canvas><i>${r[0]==='U'?'UN':r.slice(0,3).toUpperCase()}</i></span>`}).join('')}</div>`}
function flcThumbs(root){(root||ov).querySelectorAll('canvas[data-flc]').forEach(c=>{const [k,id]=c.dataset.flc.split(':');const g=c.getContext('2d');try{if((k==='a'?AR:WP)[id])art(c,k,id,0);else{g.clearRect(0,0,c.width,c.height);flcLeaf(g,c.width/2,c.height/2,40,0,FL.gear[k].indexOf(id)*2,1)}}catch(e){}})}
/* a small baked harvest night for banners: sky, moon, hills, corn rows; fireflies and leaves move on top */
const FLC_MINI={};
function flcMini(w,h,moonX){const key=w+'x'+h+':'+moonX;if(FLC_MINI[key])return FLC_MINI[key];const c=flcCv(w,h),g=c.getContext('2d'),R=flcRnd(w*7+h);
 let q=g.createLinearGradient(0,0,0,h);q.addColorStop(0,'#0a0a26');q.addColorStop(.55,'#2a1a48');q.addColorStop(.85,'#5a2a34');q.addColorStop(1,'#2a1218');g.fillStyle=q;g.fillRect(0,0,w,h);
 for(let i=0;i<70;i++){g.globalAlpha=.3+R()*.6;g.fillStyle='#f0e8ff';const s=R()<.1?2:1.2;g.fillRect(R()*w,R()*h*.55,s,s)}g.globalAlpha=1;
 flcMoon(g,w*moonX,h*.34,'orange',1,h/560);
 g.fillStyle='#24183e';g.beginPath();g.moveTo(0,h*.7);for(let x=0;x<=w;x+=20)g.lineTo(x,h*.66-Math.sin(x*.01+1)*h*.05);g.lineTo(w,h);g.lineTo(0,h);g.fill();
 g.fillStyle='#160e26';g.beginPath();g.moveTo(0,h*.8);for(let x=0;x<=w;x+=20)g.lineTo(x,h*.78-Math.sin(x*.016)*h*.04);g.lineTo(w,h);g.lineTo(0,h);g.fill();
 const tb={st:'#2a3420',lf:'#323e22',dr:'#5a4a28',ed:'#b8a870'};for(let x=-10;x<w+10;x+=8+R()*6){if(x>w*.3&&x<w*.7)continue;flcCorn(g,x,h+4,h*(.36+R()*.2),(R()-.5)*.1,R,tb)}
 for(let i=0;i<7;i++){const x=w*(.3+R()*.4),y=h*(.86+R()*.12),r=6+R()*8;flcPumpkin(g,x,y,r*h/240,{c:shade('#e8741c',-.25)})}
 return FLC_MINI[key]=c}
function flcMiniLive(cv,moonX){const g=cv.getContext('2d'),w=cv.width,h=cv.height,F=Array.from({length:14},(_,i)=>[Math.random(),Math.random(),Math.random()*6]);
 LIVE.push({cv,fn:t=>{if(!cv.isConnected)return;g.setTransform(1,0,0,1,0,0);g.drawImage(flcMini(w,h,moonX),0,0);const mo=!flcRM();
  g.save();g.globalCompositeOperation='lighter';for(const f of F){const x=(f[0]*w+(mo?Math.sin(t*.6+f[2])*30:0)),y=h*(.5+f[1]*.4)+(mo?Math.sin(t*1.3+f[2]*2)*10:0),a=.4+.4*Math.sin(t*2.4+f[2]*3);flcGlow(g,x,y,10,'#ffd27a',a);g.fillStyle='#fff4c0';g.fillRect(x-1,y-1,2,2)}g.restore();
  if(mo)for(let i=0;i<5;i++){const v=(t*.07+i/5)%1,x=w*(.1+i*.2)+Math.sin(t+i*2)*30+v*60,y=-20+v*(h+40);g.globalAlpha=Math.min(1,(1-v)*2);flcLeaf(g,x,y,h*.07,t*1.5+i,i*2+1,Math.cos(t*2+i));g.globalAlpha=1}},slow:2})}

/* ---------- the crates menu: a Harvest Chest banner, and tabs when the Graveyard Crate is up too ---------- */
function flcHubHTML(){const n=P.fcr|0,left=Math.max(0,FLC_PITY-(P.fcpity|0)),on=flcSell();
 return `<div class="flcb${n?' has':' e'}" id="flcb"><canvas class="flcbg" width="1060" height="500" aria-hidden="true"></canvas>
 <div class="flcbl"><canvas width="440" height="300" data-fcc="1"></canvas>${n?`<span class="flccnt">${n}</span>`:''}</div>
 <div class="flcbm"><div class="flctop"><span class="flclt${on?'':' end'}">${on?'LIMITED TIME':'FESTIVAL OVER'}</span><small>${on?flLeft():'Your chests and relics are yours to keep'}</small></div><b class="flcn">Harvest Chest</b>
  <p>Twelve harvest relics, a full armor set and a weapon for every rarity. Smaller pulls are gold, XP or acorns, and two harvest companions hide inside. Buy chests in the Shop or the Harvest Market, or win them in Harvest Moon Rush.</p>
  ${flcPie()}<div class="flcpt"><span>Epic or better guaranteed in <b>${left}</b> chest${left===1?'':'s'}</span><i style="--w:${Math.min(100,(FLC_PITY-left)/FLC_PITY*100)}%"></i></div></div>
 <div class="flcbr"><span class="flcown">You own ${n}</span><button class="flcopen" id="flcop" ${n?'':'disabled'}>Open</button>${n>=10?'<button class="sm gd" id="flcop10" title="Open ten at once">Open 10</button>':''}${n?'':`<small>${on?'Buy one in the Shop or the Harvest Market':'The harvest is in'}</small>`}${on?`<button class="sm" id="flcbuy">Buy · <i class="coin"></i>${price('f').toLocaleString()}</button>`:''}</div>
 <div class="flccl"><span>Collection <b>${flcCount()} / 12</b></span>${flcStrip()}<button class="flcview" id="flcview">Harvest Collection ›</button></div></div>`}
function flcTabSet(k){const hb=ov.querySelector('.hwb'),fb=$('flcb');if(!hb||!fb)return;FLC.tab=k;fb.classList.toggle('flcoff',k!=='f');hb.classList.toggle('flcoff',k==='f');
 ov.querySelectorAll('.flctab').forEach(b=>{const on=b.dataset.ft===k;b.classList.toggle('on',on);b.setAttribute('aria-selected',on?'true':'false')})}
{const h0=crateHub;crateHub=function(){h0.apply(this,arguments);try{flcHub()}catch(e){try{devLog('error','harvest hub: '+e)}catch(x){}}}}
function flcHub(){FLC.ret=crateHub;
 /* the count in the header includes the chests */
 const p=ov.querySelector('h2+p');if(p){const tot=(P.crates|0)+(P.acr|0)+(P.scr|0)+(P.pcr|0)+(P.hcr|0)+(P.ccr|0)+(P.fcr|0);p.innerHTML=tot?`You have <b style="color:var(--gold)">${tot}</b> crate${tot>1?'s':''} waiting. Open them here. Crates also drop from runs, and the Shop sells more.`:'You have no crates right now. They drop from runs and bosses, and the Shop sells them.'}
 if(!flcShow())return;const hb=ov.querySelector('.hwb'),hub=ov.querySelector('.chub');if(!hub)return;
 const d=document.createElement('div');d.innerHTML=flcHubHTML();const fb=d.firstElementChild;
 if(hb){hb.before(fb);/* the "Seasonal event" label now sits before the Harvest banner */
  const sec=fb.previousElementSibling&&fb.previousElementSibling.classList.contains('chsec')?fb.previousElementSibling:null;
  const tabs=document.createElement('div');tabs.className='flctabs';tabs.setAttribute('role','tablist');tabs.innerHTML=`<button class="flctab" data-ft="f" role="tab"><i class="flcti f"></i>Harvest Chest${P.fcr?`<em>${P.fcr}</em>`:''}</button><button class="flctab" data-ft="h" role="tab"><i class="flcti h"></i>Graveyard Crate${P.hcr?`<em>${P.hcr}</em>`:''}</button>`;
  if(sec)sec.after(tabs);else fb.before(tabs);tabs.querySelectorAll('.flctab').forEach(b=>b.onclick=()=>{flcTabSet(b.dataset.ft);try{beep(b.dataset.ft==='f'?620:520,.05,'triangle',.4)}catch(e){}});
  flcTabSet(FLC.tab==='h'&&(P.hcr>0||!(P.fcr>0))?'h':'f');
  /* the hidden banner's canvases rest */
  for(const L of LIVE){if(L.cv&&L.cv.closest&&(L.cv.closest('.hwb')||L.cv.closest('.flcb'))&&!L._flc){L._flc=1;const f0=L.fn,box=L.cv.closest('.hwb')||L.cv.closest('.flcb');L.fn=t=>{if(box.classList.contains('flcoff'))return;f0(t)}}}}
 else{const lab=document.createElement('div');lab.className='chsec';lab.innerHTML='<i></i><span>Seasonal event</span><i></i>';const ev=hub.previousElementSibling&&hub.previousElementSibling.classList.contains('chsec')?hub.previousElementSibling:hub;ev.before(lab,fb)}
 /* art and buttons */
 flcMiniLive(fb.querySelector('.flcbg'),.8);flcThumbs(fb);
 const cc=fb.querySelector('canvas[data-fcc]'),g=cc.getContext('2d');let hv=0,fr=0;fb.querySelector('.flcbl').addEventListener('pointerenter',()=>fb._h=1);fb.querySelector('.flcbl').addEventListener('pointerleave',()=>fb._h=0);
 LIVE.push({cv:cc,fn:t=>{if(fb.classList.contains('flcoff'))return;hv+=((fb._h?1:0)-hv)*.2;if(hv<.02&&(fr++%2))return;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,cc.width,cc.height);NCX.hov=hv;try{flcChest(g,cc.width/2+4,cc.height-22-hv*5,1.8,hv*(.19+.02*Math.sin(t*2.2)),t)}catch(e){}NCX.hov=0}});
 const op=$('flcop');if(op)op.onclick=()=>{if(P.fcr>0){fb.classList.add('opening');FLC.ret=crateHub;flcStart()}};
 if($('flcop10'))$('flcop10').onclick=()=>{FLC.ret=crateHub;flcBatch(10)};
 try{if(op&&!op.disabled&&FLC.tab==='f')op.focus({preventScroll:true})}catch(e){}
 if($('flcbuy'))$('flcbuy').onclick=()=>{SHX.sel='f';shop()};
 $('flcview').onclick=()=>{SHX.sel=flcSell()?'f':SHX.sel;shop();flcCollection()}}

/* ---------- the shop ---------- */
{const s0=shop;shop=function(msg){flcShopSync();if(!SHOP.some(o=>o.k===SHX.sel))SHX.sel=SHOP[0].k;const r=s0.apply(this,arguments);try{flcShopDeco()}catch(e){try{devLog('error','harvest shop: '+e)}catch(x){}}return r}}
function flcShopDeco(){FLC.ret=()=>shop();const shl=$('shl');if(!shl)return;
 const row=shl.querySelector('.shr[data-k="f"]');if(row){row.classList.add('flcr');const rb=document.createElement('span');rb.className='flcrib';rb.textContent='LIMITED';row.appendChild(rb)}
 if(SHOP.length>5)shl.classList.add('flc6');
 if(!flcShow()&&!(flcGearBuy()&&flShopOn()))return;const gy=$('shgy');const box=document.createElement('div');box.className='flcsh2';box.id='flcsh2';
 box.innerHTML=`<div class="flcshb${flcSell()?'':' off'}" id="flcshb"><canvas width="400" height="150" id="flcshc" aria-hidden="true"></canvas><div class="flcsht"><div><span class="flclt${flcSell()?'':' end'}">${flcSell()?'LIMITED TIME':'FESTIVAL OVER'}</span><span class="flcdays">${flcSell()?flLeft():'The harvest is in'}</span></div><b class="flctxt">Harvest Collection</b><small>Mythic harvest gear · ${flcCount()} / 12 relics found</small></div><button class="flcshbt" id="flcshbt">View ${shIco.arrow}</button></div>`;
 if(gy){gy.before(box);box.appendChild(gy);box.classList.add('two')}else{const sp=$('shp');sp.insertBefore(box,sp.querySelector('.shmod'))}
 if(getComputedStyle(shl).flexDirection==='row')box.style.gridRow='4';
 flcMiniLive($('flcshc'),.75);const cc=$('flcshc'),g=cc.getContext('2d');{const f0=LIVE[LIVE.length-1].fn;LIVE[LIVE.length-1].fn=t=>{f0(t);try{flcChest(g,cc.width*.5,cc.height-6,.72,0,t)}catch(e){}}}
 $('flcshbt').onclick=()=>flcCollection();$('flcshb').addEventListener('click',e=>{if(e.target.closest('button'))return;flcCollection()})}
/* the stage banners carry a maple leaf for the Harvest Chest */
{const b0=shBanner;shBanner=function(g,x,y,w,h,c,em,t){if(em!=='leaf')return b0.apply(this,arguments);b0.call(this,g,x,y,w,h,c,'none-',t);
 const sw=Math.sin(t*1.3+x)*3;g.save();g.translate(x+sw*.5,y+h*.42);g.fillStyle='#4a0e1a';g.beginPath();g.arc(0,0,32,0,TAU);g.fill();g.globalAlpha=.9;flcLeaf(g,0,0,58,Math.sin(t*.8)*.08,1,1);g.restore()}}
{const p0=shPanel;shPanel=function(anim){const r=p0.apply(this,arguments);try{if(SHX.sel==='f'){const p=$('shp2');p.querySelectorAll('button span,.shownd span').forEach(s=>{s.innerHTML=s.innerHTML.replace('Buy crate','Buy chest').replace('Owned crates','Owned chests')});const so=$('shopen');if(so)so.onclick=()=>{if((P.fcr|0)>0){FLC.ret=()=>shop();flcStart()}};
  const sh=$('shown');if(sh)sh.innerHTML=sh.innerHTML.replace('Owned crates','Owned chests')}}catch(e){}return r}}
{const b0=shBuy;shBuy=function(k){if(k==='f'&&!flcSell())return;const r=b0.apply(this,arguments);if(k==='f')try{const m=$('shmsg');if(m)m.textContent='Bought one Harvest Chest. Open it here or from the Crates screen.'}catch(e){}return r}}
/* contents and odds */
{const m0=shOddsModal;shOddsModal=function(k){if(k!=='f')return m0.apply(this,arguments);const m=$('shmod');if(!m)return;const T=(kd)=>kd==='a'?AR:WP;
 const grp=FL.rar.map((r,i)=>{const L=[['a',FL.gear.a[i]],['w',FL.gear.w[i]]];const own=L.filter(([kd,id])=>T(kd)[id]&&(kd==='a'?P.ownA:P.own)[id]).length;
  const extra=i===0?['Gold purse','XP','Acorns']:i===1?['Bigger gold purse','More acorns']:i===2?[flcPetName(FL.pets.r)+' (companion)']:i===4?[flcPetName(FL.pets.l)+' (companion)']:[];
  return `<div class="shig"><h4 style="color:${RC[r]}">${r} <small>${own} / 2 relics owned</small></h4><div>${L.map(([kd,id])=>{const d=T(kd)[id],o=d&&(kd==='a'?P.ownA:P.own)[id];return `<span class="${o?'own':''}" style="--c:${RC[r]}">${o?'✓ ':''}${esc(d?d.n:FL.gearN[id])}</span>`}).join('')}${extra.map(x=>`<span class="flcx" style="--c:${RC[r]}">${esc(x)}</span>`).join('')}</div></div>`}).join('');
 m.innerHTML=`<div class="shmc flcodds"><button class="shx" aria-label="Close">×</button><h3>Harvest Chest</h3><p class="shfine">${esc(FLC_SHOP.d)}</p>${flcPie()}
  <p class="shfine">An Epic or better pull is guaranteed within ${FLC_PITY} chests. Relics you do not own are three times as likely; duplicates turn into 40 XP and gold. Common and Uncommon pulls can be gold, XP or acorns; Rare and Legendary pulls can be a companion you do not have yet.</p><div class="shis">${grp}</div></div>`;
 m.classList.add('on');m.querySelector('.shx').onclick=shClose;m.onclick=e=>{if(e.target===m)shClose()};try{beep(620,.05,'triangle',.4)}catch(e){}}}

/* ---------- the Harvest Collection window ---------- */
const flcMy=()=>({a:FL.gear.a[5],w:FL.gear.w[5]});
/* 10.4 merge: with the gear part loaded, the purchase is the gear part's own (flgBuy: flgWhyNot's festival + grace rules, the gold ledger
   label "harvest relic"); the old path below only runs when the gear part is missing */
const flcGearBuy=()=>typeof flgBuy==='function'&&typeof flgWhyNot==='function'&&!!AR[FL.gear.a[5]]&&!!WP[FL.gear.w[5]];
function flcBuyM(w){const M=flcMy(),A=AR[M.a],Wp=WP[M.w];if(!A||!Wp)return;
 if(flcGearBuy()){if(!flgBuy(w))return}else{if(!flcSell())return;const pr=FL.price[w];if(!pr||P.gold<pr)return;const oa=!!P.ownA[M.a],ow=!!P.own[M.w];
 if(w==='a'&&oa||w==='w'&&ow||w==='b'&&(oa||ow))return;
 P.gold-=pr;const give=(kd,id)=>{try{if(typeof flgGive==='function')flgGive(kd,id)}catch(e){}(kd==='a'?P.ownA:P.own)[id]=1};if(w!=='w')give('a',M.a);if(w!=='a')give('w',M.w);save()}
 try{beep(880,.12,'triangle',.8);setTimeout(()=>beep(1320,.2,'triangle',.7),100);setTimeout(()=>beep(1760,.3,'sine',.5),220)}catch(e){}
 const gv=$('shgv');if(gv)gv.textContent=P.gold.toLocaleString();
 const card=ov.querySelector(`.flcc[data-w="${w}"]`);if(card){card.classList.add('bought');for(let i=0;i<24;i++){const s=document.createElement('i');s.className='flcsp';s.style.cssText=`--dx:${(Math.random()-.5)*260}px;--dy:${-60-Math.random()*200}px;--r:${(Math.random()-.5)*720}deg;animation-delay:${Math.random()*.15}s`;card.appendChild(s);setTimeout(()=>s.remove(),1300)}}
 setTimeout(()=>{if(!$('flcwin'))return;flcCollection(w==='a'?`${A.n} is yours. Equip it in the Armory.`:w==='w'?`${Wp.n} is yours. Equip it in the Armory.`:`The Feast Bundle is yours: ${A.n} and ${Wp.n}.`);try{shPanel(false)}catch(e){}},900)}
function flcCollection(note){if(typeof note!=='string')note='';let m=$('shmod');if(!m){shop();m=$('shmod')}if(!m)return;const gb=flcGearBuy(),on=gb?flShopOn():flcSell(),grace=on&&!flOn(),g=P.gold,M=flcMy(),A=AR[M.a],Wp=WP[M.w],oa=!!(A&&P.ownA[M.a]),ow=!!(Wp&&P.own[M.w]),save2=FL.price.a+FL.price.w-FL.price.b,ready=!!(A&&Wp);
 const btn=(w,pr,owned,part)=>{if(gb){const why=flgWhyNot(w);owned=why==='owned';part=why==='part'}const can=gb?!flgWhyNot(w):on&&ready&&!owned&&!part&&g>=pr;return `<button class="flcbuy${owned?' own':''}" data-fb="${w}" ${can?'':'disabled'}>${owned?'✓ Owned':part?'Part owned':!on?'Festival over':!ready?'Coming soon':g<pr?`<span><i class="coin"></i>${pr.toLocaleString()}</span><small>need ${(pr-g).toLocaleString()} more</small>`:`<span><i class="coin"></i>${pr.toLocaleString()}</span>`}</button>`};
 const card=(w,nm,sub,desc,prev,pr,owned,part)=>`<div class="flcc${owned?' own':''}${w==='b'?' bun':''}" data-w="${w}" style="--i:${'awb'.indexOf(w)}"><div class="flccp">${prev}<i class="flcglow"></i>${w==='b'?`<span class="flcsave">SAVE ${save2.toLocaleString()}</span>`:''}</div><b>${esc(nm)}</b><em>${sub}</em><small>${esc(desc)}</small>${btn(w,pr,owned,part)}</div>`;
 const AB=(typeof GAB!=='undefined'&&GAB[FL.ab.k])||{},abD=AB.d||'Every correct word fills a harvest meter. When it is full, a cornucopia bursts over the field.',abS=String(AB.set||'Set bonus: wear both Mythic relics and the meter fills faster and the burst hits harder.').replace('Set bonus: ','').replace(/^[a-z]/,c=>c.toUpperCase());
 m.innerHTML=`<div class="shmc wide flcwin" id="flcwin"><button class="shx" aria-label="Close">×</button>
  <div class="flchd"><canvas id="flcsc" width="1100" height="210" aria-hidden="true"></canvas><div class="flcht"><div><span class="flclt${on?'':' end'}">${on?'LIMITED TIME':'FESTIVAL OVER'}</span><span class="flcdays">${on?flLeft():'The harvest is in'}</span></div><h3 class="flctxt">Harvest Collection</h3><p>${grace?`The festival is over, but the Mythic relics are sold until ${new Date(FL.end+FL.grace-1).toLocaleDateString('en-GB',{day:'numeric',month:'long'})}.`:on?'Mythic harvest relics, sold until the festival ends on 1 December.':'The festival is over. These relics are no longer sold.'}</p></div></div>
  ${note?`<div class="flcnote">${esc(note)}</div>`:''}
  <div class="flcg">${card('a',A?A.n:FL.gearN[M.a],'Mythic armor set',A?A.d:'',`<canvas width="200" height="250" data-flcv="a:${M.a}"></canvas>`,FL.price.a,oa,0)}
   ${card('w',Wp?Wp.n:FL.gearN[M.w],'Mythic weapon',Wp?Wp.d:'',`<canvas width="200" height="250" data-flcv="w:${M.w}"></canvas>`,FL.price.w,ow,0)}
   ${card('b','Feast Bundle','Armor and weapon together',`Both relics for ${FL.price.b.toLocaleString()} gold.`,`<span class="flcpair"><canvas width="150" height="190" data-flcv="a:${M.a}"></canvas><canvas width="150" height="190" data-flcv="w:${M.w}"></canvas></span>`,FL.price.b,oa&&ow,oa!==ow?1:0)}</div>
  <div class="flcab"><span class="flcic"></span><div><b>Ability: ${esc(FL.ab.n)}</b><span>${esc(abD)}</span></div><div class="flcset"><b>Set bonus</b><span>${esc(abS)}</span></div></div>
  <div class="flccol"><div class="flccolh"><b>Harvest Chest relics</b><span>${flcCount()} / 12 found · open Harvest Chests from the Shop, the Harvest Market or Harvest Moon Rush · you own ${P.fcr|0}</span></div>${flcStrip()}</div></div>`;
 m.classList.add('on');m.querySelector('.shx').onclick=shClose;m.onclick=e=>{if(e.target===m)shClose()};flcThumbs(m);
 /* 10.4c: a purchase of 100,000 gold or more asks once: the first tap arms the button ("Tap again to buy"), the second buys; a double click does not */
 m.querySelectorAll('[data-fb]').forEach(b=>b.onclick=()=>{const now=performance.now();if(b.classList.contains('arm')){if(now-b._at<280)return;clearTimeout(b._t);b.classList.remove('arm');flcBuyM(b.dataset.fb);return}
  b._lab=b.innerHTML;b._at=now;b.classList.add('arm');b.innerHTML='<span>Tap again to buy</span>';try{beep(660,.05,'triangle',.4)}catch(e){}
  b._t=setTimeout(()=>{if(b.isConnected&&b.classList.contains('arm')){b.classList.remove('arm');b.innerHTML=b._lab}},3600)});
 try{const f=m.querySelector('[data-fb]:not(:disabled)')||m.querySelector('.shx');if(f)f.focus({preventScroll:true})}catch(e){}
 const sc=$('flcsc');flcMiniLive(sc,.86);{const L=LIVE[LIVE.length-1],f0=L.fn,sg2=sc.getContext('2d');L.fn=t=>{f0(t);try{flcScarecrow(sg2,sc.width*.065,sc.height+34,.6,Math.sin(t*.4)*.5,t,{});flcLantern(sg2,sc.width*.15,sc.height+12,.66,1,'#ffc070',t,Math.sin(t*1.6)*.05);flcLantern(sg2,sc.width*.93,sc.height+12,.66,1,'#ffc070',t+2,Math.sin(t*1.4)*.05)}catch(e){}}}
 m.querySelectorAll('canvas[data-flcv]').forEach((c,i)=>{const [k,id]=c.dataset.flcv.split(':'),cd=c.closest('.flcc');let fr=0;
  if(!(k==='a'?AR:WP)[id]){const gg=c.getContext('2d');gg.clearRect(0,0,c.width,c.height);k==='a'?flcPumpkin(gg,c.width/2,c.height*.6,c.width*.3,{carve:1,glow:1}):flcHorn(gg,c.width*.62,c.height*.55,c.width/300,0,1);return}
  LIVE.push({cv:c,fn:t=>{if(!cd.matches(':hover')&&(fr++%2))return;try{art(c,k,id,t+i)}catch(e){}}})});
 try{beep(392,.3,'triangle',.35);setTimeout(()=>beep(523,.4,'triangle',.3),140)}catch(e){}}

/* ---------- catalog › Crates ---------- */
{const c0=catalog;catalog=function(back,tab){const r=c0.apply(this,arguments);try{if((tab||catalog.tab)==='Crates'&&flcShow()){const grid=ov.querySelector('.bgrid.c');if(grid&&!grid.querySelector('[data-c="f"]')){const d=document.createElement('div');d.className='mcd cr';d.style.borderColor='#ff9a3a';
  d.innerHTML=`<canvas width="150" height="120" data-c="f"></canvas><b style="color:#ff9a3a">Harvest Chest</b><small>${flcSell()?'LIMITED TIME':'FESTIVAL OVER'}. Harvest Festival, 6 November to 1 December. ${flcSell()?'Bought in the Shop or the Harvest Market and won in Harvest Moon Rush.':'No longer sold, but chests you hold can still be opened.'} Holds the twelve harvest relics, gold, XP, acorns and two companions. Legendary and Mythic odds are a secret.</small><span>You own ${P.fcr|0}</span>`;
  const hc=grid.querySelector('[data-c="h"]');(hc?hc.closest('.mcd'):grid.lastElementChild).after(d);const c=d.querySelector('canvas');try{flcChest(c.getContext('2d'),c.width/2,c.height-8,.62,0,0)}catch(e){}}}}catch(e){}return r}}

/* ---------- dock badges count the chests ---------- */
const flcAllCrates=()=>{try{return dkCrates()+(P.fcr|0)}catch(e){return P.fcr|0}};
{const b0=dkBadge;dkBadge=function(k){if(k==='sh'){try{return flcAllCrates()||''}catch(e){}}return b0.apply(this,arguments)}}
{const h0=dkHTML;dkHTML=function(){let h=h0.apply(this,arguments);try{if((P.fcr|0)>0){const n=flcAllCrates();h=h.replace(/(data-dks="cr"[^>]*>[^<]*)(<i class="bdg">\d+<\/i>)?(<\/button>)/,`$1<i class="bdg">${n}</i>$3`)}}catch(e){}return h}}
if(typeof mfxBadgesNow==='function'){const m0=mfxBadgesNow;mfxBadgesNow=function(){const r=m0.apply(this,arguments);try{if(ov&&!ov.classList.contains('hide')){const b=ov.querySelector('.dkst[data-dks="cr"]');if(b)mfxSetBdg(b,flcAllCrates()||'')}}catch(e){}return r}}

/* ---------- DEV › Cheats ---------- */
if(typeof dvxHTML==='function'){const h0=dvxHTML;dvxHTML=function(){let h=h0.apply(this,arguments);try{const sec=(t,b)=>`<div class="dvx"><h5>${t}</h5>${b}</div>`;
 h+=sec('Harvest Chest',`<div class="dvrow"><span>${P.fcr|0} chests · pity ${P.fcpity|0} / ${FLC_PITY} · relics ${flcCount()} / 12${(P.flcPend||[]).length?` · ${P.flcPend.length} waiting`:''}</span></div>
 <div class="dvrow">${dvBtn('x:flc1','+1 Harvest Chest')}${dvBtn('x:flc10','+10 Harvest Chests')}${dvBtn('x:flc100','+100')}${dvBtn('x:flcpity','Next chest: pity (Epic or better)')}${dvBtn('x:flcrel','Own all 12 relics')}${dvBtn('x:flcclr','Clear relics and chests')}</div>
 <div class="dvrow">${[0,1,2,3,4,5].map(t=>dvBtn('x:flct'+t,'Open: '+FL.rar[t])).join('')}${dvBtn('x:flcopen','Open the crates menu')}</div>`)}catch(e){}return h}}
if(typeof dvxAct==='function'){const a0=dvxAct;dvxAct=function(a){
 if(a==='flc1'||a==='flc10'||a==='flc100'){const n=+a.slice(3);P.fcr=(P.fcr|0)+n;dvxMsg(`+${n} Harvest Chest${n>1?'s':''} (${P.fcr} now).`)}
 else if(a==='flcpity'){P.fcpity=FLC_PITY-1;dvxMsg('The next Harvest Chest is Epic or better.')}
 else if(a==='flcrel'){for(const it of flcItems()){if((it.kind==='a'?AR:WP)[it.id])(it.kind==='a'?P.ownA:P.own)[it.id]=1}dvxMsg('You own every harvest relic that exists in this build.')}
 else if(a==='flcclr'){for(const it of flcItems()){delete(it.kind==='a'?P.ownA:P.own)[it.id]}if(FL.gear.a.includes(P.armor))P.armor='rags';if(FL.gear.w.includes(P.weapon))setWeapon('rusty');P.fcr=0;P.fcpity=0;P.flcPend=[];dvxMsg('Harvest relics and chests cleared.')}
 else if(/^flct[0-5]$/.test(a)){const t=+a[4];FLC.force=t;P.fcr=(P.fcr|0)+1;save();try{DEV.open=false}catch(e){}flcStart();dvxMsg('Opening a '+FL.rar[t]+' Harvest Chest.')}
 else if(a==='flcopen'){flcOpenUI();dvxMsg('Crates menu.')}
 else return a0.apply(this,arguments)}}
/* a DEV "Open: <rarity>" forces the next roll's tier once */
{const r0=flcRoll;flcRoll=function(){if(FLC.force==null)return r0.apply(this,arguments);const t=FLC.force,fk=FLC.forceK;FLC.force=null;FLC.forceK=null;let k='relic';
 if(fk==='pet'&&(t===2||t===4)){const id=t===2?FL.pets.r:FL.pets.l;if(flcPetOk(id))return{k:'pet',tier:t,id}}
 if(fk==='coin'||fk==='xp'||fk==='ac')return{k:fk,tier:Math.min(1,t),n:flcAmt(fk,t)};if(fk==='relic'){const x=flcRelic(t);if(x)return{k:'relic',tier:t,kind:x.kind,id:x.id}}
 if(t===2||t===4){const id=t===2?FL.pets.r:FL.pets.l;if(Math.random()<.3&&flcPetOk(id))return{k:'pet',tier:t,id}}
 if(t<=1&&Math.random()<.4){k=['coin','xp','ac'][Math.random()*(t?2:3)|0];if(t===1&&k==='xp')k='coin';return{k,tier:t,n:flcAmt(k,t)}}
 const x=flcRelic(t);if(x)return{k:'relic',tier:t,kind:x.kind,id:x.id};return{k:'coin',tier:Math.min(1,t),n:flcAmt('coin',t)}}}

/* ---------- styles ---------- */
{const st=document.createElement('style');st.textContent=`
#flctoast{position:absolute;right:26px;top:92px;z-index:99990;display:flex;align-items:center;gap:10px;padding:6px 18px 6px 6px;border-radius:16px;background:linear-gradient(180deg,#3a1e12f2,#1e0e08f6);border:2px solid #ffb04a;box-shadow:0 10px 24px #000a;color:#fff4dc;pointer-events:none;opacity:0;transform:translateX(24px) scale(.92);transition:opacity .25s,transform .35s cubic-bezier(.3,1.6,.5,1)}
#flctoast.on{opacity:1;transform:none}#flctoast canvas{width:72px;height:54px;flex:none}#flctoast b{display:block;font:400 26px/1.2 'Pirata One',Georgia,serif;color:#ffd27a}#flctoast small{display:block;margin-top:3px;font:600 13px/1.3 var(--ui);color:#f0d8c0}
.flctxt{text-shadow:none!important;background:linear-gradient(180deg,#fffbe0,#ffd45a 42%,#ff9a3a 78%,#e8602a);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;color:#ffb04a;filter:drop-shadow(0 3px 0 #3a1406) drop-shadow(0 0 14px #ff9a3a88)}
.flclt.end{background:linear-gradient(180deg,#d8c8b8,#8a7868)}.flclt{display:inline-block;padding:3px 10px;border-radius:10px;font:800 11px var(--ui);letter-spacing:1.2px;color:#2a1006;background:linear-gradient(180deg,#ffd27a,#ff8a3a)}
/* crates menu banner */
.flctabs{display:flex;justify-content:center;gap:10px;margin:2px auto 10px}
.flctab{all:unset;box-sizing:border-box;cursor:pointer;display:flex;align-items:center;gap:8px;padding:7px 16px;border-radius:22px;font:700 15px var(--ui);color:#e8dcff;background:#1a1236;border:2px solid #3a3070;transition:transform .15s,border-color .15s,background .15s}
.flctab:hover{transform:translateY(-2px)}.flctab.on{color:#2a1006;background:linear-gradient(180deg,#ffe0a0,#ffa040);border-color:#fff0c0}.flctab[data-ft="h"].on{color:#0a2a1e;background:linear-gradient(180deg,#c8ffe8,#5affb0);border-color:#e0fff4}
.flctab em{font-style:normal;min-width:20px;padding:1px 6px;border-radius:10px;font:800 12px var(--ui);background:#e8344a;color:#fff;text-align:center}
.flcti{width:16px;height:16px;border-radius:50%;flex:none}.flcti.f{background:radial-gradient(circle at 35% 35%,#ffd27a,#e8741c 60%,#8a3a0a)}.flcti.h{background:radial-gradient(circle at 35% 35%,#c8ffe8,#3ad88a 60%,#0a5a2a)}
.flcb{position:relative;display:grid;grid-template-columns:300px minmax(0,1fr) 190px;grid-template-rows:auto auto;gap:4px 18px;width:min(1180px,96%);margin:0 auto 14px;padding:16px 18px 14px;border-radius:20px;overflow:hidden;border:2px solid #ffb04aaa;background:#140a1c;box-shadow:0 12px 30px #000c;text-align:left;animation:flcin .55s cubic-bezier(.2,1.2,.4,1) both}
.flcb.flcoff,.hwb.flcoff{display:none!important}.flcb.flcping{animation:flcping .9s cubic-bezier(.3,1.6,.5,1)}@keyframes flcping{30%{transform:scale(1.02)}}
@keyframes flcin{from{opacity:0;transform:translateY(26px) scale(.97)}}
.flcbg{position:absolute;inset:0;width:100%;height:100%;z-index:0;opacity:.95}
.flcb::after{content:"";position:absolute;inset:0;z-index:0;background:linear-gradient(90deg,#0a061400 0%,#0a0614a8 30%,#0a0614a8 72%,#0a061420 100%);pointer-events:none}
.flcb>*:not(.flcbg){position:relative;z-index:1}
.flcbl{grid-row:1;grid-column:1;display:flex;align-items:flex-end;justify-content:center;min-height:200px}.flcbl canvas{width:300px;height:205px}
.flccnt{position:absolute;left:8px;top:8px;min-width:34px;height:34px;padding:0 8px;box-sizing:border-box;border-radius:17px;display:grid;place-items:center;font:800 18px var(--ui);color:#2a1006;background:linear-gradient(180deg,#ffe0a0,#ffa040);border:2px solid #fff0c0;box-shadow:0 4px 10px #000a}
.flcbm{grid-row:1;grid-column:2;display:flex;flex-direction:column;gap:5px;min-width:0}.flctop{display:flex;align-items:center;gap:8px}.flctop small{font:700 13px var(--ui);color:#ffd27a}
.flcn{font:400 46px/1 'Pirata One',Georgia,serif;color:#ffc46a;text-shadow:0 3px 0 #3a1406}
.flcbm p{margin:0;font:500 14px/1.45 var(--ui);color:#f0e0d0;max-width:620px}
.flcpie{display:flex;align-items:center;gap:14px;margin-top:2px}.flcpie svg{flex:none;width:104px;height:104px}.flcpt1{font:800 13px var(--ui);fill:#ffe0a0}.flcpt2{font:600 9px var(--ui);fill:#e8c8a8}
.flclg{display:grid;grid-template-columns:repeat(2,minmax(0,170px));gap:3px 18px}.flclg span{display:flex;align-items:center;gap:6px;font:600 13px var(--ui);color:var(--c)}.flclg i{width:10px;height:10px;border-radius:3px;background:var(--c)}.flclg b{margin-left:auto;color:#fff}.flclg b.hq{color:var(--c);letter-spacing:1px}
.flcpt{display:flex;flex-direction:column;gap:5px;max-width:420px}.flcpt span{font:600 13px var(--ui);color:#f0e0d0}.flcpt b{color:#ffd27a}.flcpt i{display:block;height:5px;border-radius:3px;background:linear-gradient(90deg,#ffb04a var(--w),#ffffff22 var(--w))}
.flcbr{grid-row:1;grid-column:3;display:flex;flex-direction:column;align-items:stretch;justify-content:center;gap:9px}
.flcown{padding:5px 10px;border-radius:12px;text-align:center;font:700 14px var(--ui);color:#fff4dc;background:#1a0c08cc;border:1.5px solid #ffb04a88}
.flcopen{all:unset;box-sizing:border-box;cursor:pointer;text-align:center;padding:11px 10px;border-radius:14px;font:400 30px/1 'Pirata One',Georgia,serif;color:#2a1006;background:linear-gradient(180deg,#ffe9a0,#ffa040 55%,#e0641a);border:2px solid #fff0c0;box-shadow:0 5px 0 #7a3008,0 8px 18px #000a;transition:transform .12s,filter .15s}
.flcopen:hover:not(:disabled){transform:translateY(-2px);filter:brightness(1.08)}.flcopen:active:not(:disabled){transform:translateY(3px);box-shadow:0 2px 0 #7a3008}.flcopen:disabled{cursor:default;color:#d8c8b8;background:linear-gradient(180deg,#5a4a44,#3a2c28);border-color:#8a7a70;box-shadow:0 4px 0 #1a100c}
.flcbr small{font:600 12px/1.3 var(--ui);color:#e8d0b8;text-align:center}.flcbr .sm{justify-content:center}.flcbr .coin{width:16px;height:16px;vertical-align:-3px;margin:0 2px}
.flcb.opening{animation:flcopen .5s ease forwards}@keyframes flcopen{40%{transform:scale(1.02)}100%{transform:scale(1.03);opacity:.4}}
.flccl{grid-row:2;grid-column:1/-1;display:flex;align-items:center;gap:12px;padding-top:8px;border-top:1px solid #ffb04a33}.flccl>span{flex:none;font:600 13px var(--ui);color:#f0e0d0}.flccl>span b{color:#ffd27a}
.flcst{display:flex;gap:5px;flex-wrap:wrap}.flci{position:relative;display:flex;flex-direction:column;align-items:center;width:46px;padding:2px 0 3px;border-radius:9px;background:#0a0614cc;border:1.5px solid #ffffff1a}.flci canvas{width:40px;height:50px;filter:brightness(.18) saturate(0)}.flci.own{border-color:var(--c);background:color-mix(in srgb,var(--c) 14%,#0a0614)}.flci.own canvas{filter:none}
.flci i{font:800 8.5px var(--ui);font-style:normal;letter-spacing:.5px;color:var(--c)}
.flcview{all:unset;cursor:pointer;margin-left:auto;flex:none;padding:7px 14px;border-radius:12px;font:700 14px var(--ui);color:#fff4dc;background:linear-gradient(180deg,#6a3a1e,#3a1e0e);border:1.5px solid #ffb04a99}.flcview:hover{filter:brightness(1.15)}
/* shop */
.shr.flcr{border-color:#ff9a3a99}.shr.flcr:not(.on){background:linear-gradient(180deg,#2a1830f2,#140a20f6)}.shr.flcr .shro{top:auto;bottom:7px}.flcrib{position:absolute;left:10px;top:4px;padding:1px 7px;border-radius:7px;font:800 10px var(--ui);letter-spacing:1px;color:#2a1006;background:linear-gradient(180deg,#ffd27a,#ff8a3a)}
.shl.flc6{gap:7px}.shl.flc6 .shr{padding:5px 12px 5px 6px}.shl.flc6 .shr canvas{width:86px;height:60px}.shl.flc6 .shrt b{font-size:25px}
.flcsh2{grid-column:1/-1;grid-row:3;display:block}.flcsh2.two{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:14px}
.flcsh2 .shgy{grid-row:auto;grid-column:auto;height:118px;gap:12px;padding:0 14px 0 0}.flcsh2 .shgy canvas{height:100%;width:170px;object-fit:cover;object-position:18% 50%}.flcsh2 .shgyt b{font-size:34px}.flcsh2 .shgyt small{font-size:14px}.flcsh2 .shgyb{padding:10px 14px;font-size:15px;gap:6px}.flcsh2 .shgyb svg{width:16px;height:16px}
.flcshb{position:relative;display:flex;align-items:center;gap:12px;height:118px;padding:0 14px 0 0;border-radius:18px;overflow:hidden;cursor:pointer;background:radial-gradient(ellipse at 30% 30%,#4a2418,#1e0e10 60%,#100608);border:2px solid #ff9a3aaa;box-shadow:0 10px 24px #000a;transition:transform .2s}
.flcsh2:not(.two) .flcshb{height:132px}.flcshb:hover{transform:translateY(-2px)}.flcshb.off{border-color:#8a6a5a}.flcshb canvas{flex:none;height:100%;width:170px;object-fit:cover}
.flcsht{flex:1;min-width:0;display:flex;flex-direction:column;align-items:center;gap:2px;text-align:center}.flcsht>div{display:flex;gap:8px;align-items:center}.flcdays{padding:3px 10px;border-radius:12px;background:#1a0a06aa;font:700 13px var(--ui);color:#ffd27a}
.flcsht b{font:400 34px/1.05 'Pirata One',Georgia,serif}.flcsh2:not(.two) .flcsht b{font-size:44px}.flcsht small{font:500 14px var(--ui);color:#f0dccc}
.flcshbt{all:unset;box-sizing:border-box;cursor:pointer;flex:none;display:flex;align-items:center;gap:6px;padding:10px 14px;border-radius:14px;font:700 15px var(--ui);color:#fff;background:linear-gradient(180deg,#a8501e,#6a2a0e);border:1.5px solid #ffb04a;box-shadow:0 5px 0 #3a1406}.flcshbt svg{width:16px;height:16px}.flcshbt:hover{filter:brightness(1.12)}
.shmc.flcodds{border-color:#ff9a3a}.shmc.flcodds h3{color:#ffc46a}.flcodds .flcpie{margin:8px 0}.shig span.flcx{font-style:italic;border-style:dashed}
/* the Harvest Collection window */
.shmod:has(.flcwin){inset:10px -8px 14px}
.shmc.flcwin{padding:0;width:min(1120px,96%);background:linear-gradient(180deg,#1e0e10,#0e0608);border:2px solid #ff9a3a88;box-shadow:0 0 0 2px #ffd27a33,0 24px 60px #000e}
.flcwin .shx{color:#ffe9c8;text-shadow:0 2px 6px #000}
.flchd{position:relative;aspect-ratio:1100/132;overflow:hidden;border-radius:16px 16px 0 0}.flchd canvas{position:absolute;inset:0;width:100%;height:100%}
.flchd::after{content:"";position:absolute;left:0;right:0;bottom:0;height:28px;background:linear-gradient(transparent,#1e0e10)}
.flcht{position:absolute;left:0;right:0;top:8px;display:flex;flex-direction:column;align-items:center;gap:4px;z-index:1;text-align:center}.flcht>div{display:flex;gap:8px;align-items:center}
.flcht h3{margin:0 0 2px;font:400 48px/1.05 'Pirata One',Georgia,serif}.flcht p{margin:0;padding:1px 14px;border-radius:10px;background:#12081fb8;font:500 15px var(--ui);color:#fff0e0;text-shadow:0 2px 6px #000}
.flcnote{margin:8px 24px 0;padding:10px 16px;border-radius:12px;background:#2a1a08e6;border:1.5px solid #ffb04aaa;font:600 15px var(--ui);color:#ffe8c0;text-align:center;animation:flcin .4s ease both}
.flcg{display:grid;grid-template-columns:1fr 1fr 1.25fr;gap:14px;padding:8px 24px 4px}
.flcc{position:relative;display:flex;flex-direction:column;align-items:center;gap:3px;padding:8px 12px 12px;border-radius:18px;text-align:center;background:radial-gradient(ellipse at 50% 30%,#3a1e14,#160a0a 70%);border:2px solid #ff9a3a66;box-shadow:0 10px 24px #000a;transition:transform .25s,border-color .25s;animation:flcin .55s cubic-bezier(.2,1.2,.4,1) calc(.1s + var(--i)*.09s) both}
.flcc:hover{transform:translateY(-6px);border-color:#ffd27a}.flcc.bun{border-color:#ffd45a88}.flcc.own{border-color:#ffd27a}.flcc.own::before{content:'OWNED';position:absolute;top:10px;right:10px;padding:3px 9px;border-radius:10px;font:800 11px var(--ui);letter-spacing:1px;color:#2a1006;background:#ffd27a}
.flccp{position:relative;display:flex;justify-content:center;align-items:flex-end;height:116px;width:100%}.flccp canvas{height:116px;width:93px;position:relative;z-index:1;transition:transform .35s cubic-bezier(.3,1.6,.5,1)}.flcc:hover .flccp canvas{transform:scale(1.07)}
.flcpair{display:flex;gap:4px;position:relative;z-index:1}.flcpair canvas{height:104px;width:82px}
.flcglow{position:absolute;left:50%;bottom:8px;width:70%;height:40px;transform:translateX(-50%);border-radius:50%;background:radial-gradient(#ffb04a66,transparent 70%);animation:flcgl 2.6s ease-in-out infinite}@keyframes flcgl{50%{opacity:.5;transform:translateX(-50%) scale(1.15)}}
.flcsave{position:absolute;top:2px;left:50%;transform:translateX(-50%) rotate(-4deg);z-index:2;padding:4px 12px;border-radius:10px;font:800 13px var(--ui);letter-spacing:1px;color:#2a1406;background:linear-gradient(180deg,#fff0a0,#f0a820);box-shadow:0 4px 10px #000a}
.flcc b{font:400 30px/1.05 'Pirata One',Georgia,serif;color:#ffc46a}.flcc.bun b{color:#ffe27a}.flcc em{font:800 12px var(--ui);font-style:normal;letter-spacing:1.4px;text-transform:uppercase;color:#ff9a6a}
.flcc small{font:500 13.5px/1.4 var(--ui);color:#f0dccc;min-height:38px}
.flcbuy{all:unset;box-sizing:border-box;cursor:pointer;margin-top:auto;display:flex;flex-direction:column;align-items:center;justify-content:center;min-width:72%;padding:9px 18px;border-radius:14px;font:800 22px var(--ui);color:#2a1406;background:linear-gradient(180deg,#fff0a0,#f4b020 55%,#d88a10);border:2px solid #fff4b8;box-shadow:0 5px 0 #7a4a08,0 8px 18px #000a;transition:transform .12s,filter .15s}
.flcbuy .coin{width:22px;height:22px;margin-right:6px;vertical-align:-3px}.flcbuy small{font:700 11px var(--ui);color:#ffdede;min-height:0}
.flcbuy:hover:not(:disabled){transform:translateY(-2px);filter:brightness(1.08)}.flcbuy:active:not(:disabled){transform:translateY(3px);box-shadow:0 2px 0 #7a4a08}
.flcbuy:disabled{cursor:default;font-size:18px;color:#f0e8e0;background:linear-gradient(180deg,#5a4440,#3a2a26);border-color:#8a706a;box-shadow:0 4px 0 #1a0e0c}
.flcbuy.arm{font-size:17px;color:#fff;background:linear-gradient(180deg,#e8683a,#a8341a);border-color:#ffe0c0;box-shadow:0 5px 0 #4a1408,0 8px 18px #000a}.flcbuy.arm small{color:#ffe8d8}
.flcbuy.own,.flcbuy.own:disabled{font-size:20px;color:#2a1006;background:linear-gradient(180deg,#ffe9b0,#ffc04a);border-color:#fff4d0;box-shadow:0 4px 0 #7a4a08}
.flcc.bought{animation:flcbt .9s cubic-bezier(.3,1.6,.5,1)}@keyframes flcbt{30%{transform:scale(1.06)}}
.flcsp{position:absolute;left:50%;top:40%;width:14px;height:12px;z-index:3;pointer-events:none;border-radius:2px 8px;background:linear-gradient(135deg,#ffd27a,#e8402a);animation:flcsp 1.1s ease-out forwards}
@keyframes flcsp{to{transform:translate(var(--dx),var(--dy)) rotate(var(--r)) scale(.3);opacity:0}}
.flcab{display:flex;align-items:center;gap:16px;margin:8px 24px 0;padding:8px 16px;border-radius:14px;background:linear-gradient(90deg,#3a1a0a,#1e0e14);border:1.5px solid #ffb04a66;animation:flcin .5s ease .35s both}
.flcic{flex:none;width:26px;height:26px;border-radius:50%;background:radial-gradient(circle at 35% 35%,#fff4c0,#ffb04a 60%,#c8641a)}.flcab>div{display:flex;flex-direction:column;gap:2px;flex:1}.flcab b{font:400 24px 'Pirata One',Georgia,serif;color:#ffd8a0}.flcab span{font:500 12.5px/1.35 var(--ui);color:#f0dccc}
.flcab .flcset{flex:.8;padding-left:16px;border-left:1px solid #ffb04a44}.flcset b{color:#ffe27a!important}
.flccol{margin:8px 24px 12px;padding:6px 14px 8px;border-radius:14px;background:#0a0606aa;border:1px solid #ffffff1a;animation:flcin .5s ease .45s both}
.flccolh{display:flex;justify-content:space-between;align-items:baseline;gap:12px;margin-bottom:4px}.flccolh b{font:400 24px 'Pirata One',Georgia,serif;color:#ffe0c0}.flccolh span{font:600 13px var(--ui);color:#d8b8a0;text-align:right}
.flccol .flcst{justify-content:center}
/* result screens */
.flcres{display:flex;flex-direction:column;align-items:center;min-height:100%}.flcres h2{font-size:58px;line-height:1.2;margin-bottom:10px}.flcpet{justify-content:center}.flcpet canvas{width:260px;height:260px}.flcres p{max-width:820px}
.flcbat .cbs span b{color:#ffd27a}.flcbat .row{margin-top:14px}
@media (prefers-reduced-motion:reduce){.flcb,.flcc,.flcab,.flccol,.flcnote,.flcglow,#flctoast{animation:none!important;transition:none!important}}
`;document.head.appendChild(st)}
flcShopSync();
