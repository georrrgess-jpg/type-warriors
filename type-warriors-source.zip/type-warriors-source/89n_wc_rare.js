/* ===== WILDCARD: the rare guest — a pastel dragon in a pink or baby-blue suit =====
   Pearly lilac scales, swept-back gold horns, iridescent wings that slowly flap, a heart-tipped tail that sways,
   one pink and one cyan eye that glow, heart sunglasses pushed up on his brow, little smoke puffs and sparkles.
   He holds a gold champagne coupe. He turns up in about 1 game in 10 (and on the menu now and then); beating a table
   he sits at unlocks the Pastel Wyrm card back. Drawn by wrapping the crew renderer from 89i. */
WCSP.pdragon={skin:['#efe6ff','#b8a4f0'],belly:'#fff4fb',hats:[''],eyes:[''],hand:'claw',last:['Bubblegum']};
const WCRARE=[{suit:'#ff8ac8',suit2:'#c8509a',fin:'#9ad8ff',name:'Baron Bubblegum'},{suit:'#8ad4ff',suit2:'#4a94d0',fin:'#ff9ad0',name:'Duke Azurine'}];
function wcRareGuest(r){const P=WCRARE[Math.floor((r||Math.random)()*2)];return{t:'crew',sp:'pdragon',rare:1,suit:P.suit,suit2:P.suit2,fin:P.fin,tie:'#ffd45a',tk:'bow',hat:'',eye:'',hold:'coupe',chain:true,seed:Math.floor(Math.random()*1000),name:P.name}}
/* a lineup with an occasional rare guest in it */
{const g0=wcCrewGen;wcCrewGen=function(n,rnd,o){const L=g0.call(this,n,rnd);const p=o&&o.rare!=null?o.rare:0;if(L.length&&(rnd||Math.random)()<p){L[Math.floor((rnd||Math.random)()*L.length)]=wcRareGuest(rnd)}return L}}
{const t0=wcCrewTop;wcCrewTop=function(A){if(A.sp==="pdragon")return WCHY(A)+WCHS*-68;return t0.apply(this,arguments)}}
{const h0=wcHold;wcHold=function(g,A,x,y,t){if(A.hold!=='coupe')return h0.apply(this,arguments);g.save();g.translate(x,y+Math.sin(t*2.6+A.seed)*1.6);g.scale(1.3,1.3);
 g.beginPath();g.moveTo(-15,-30);g.quadraticCurveTo(0,-14,15,-30);g.closePath();g.fillStyle='#ffd45a';g.fill();wcSt2(g,2.4);g.beginPath();g.moveTo(-12,-28.5);g.quadraticCurveTo(0,-19,12,-28.5);g.closePath();g.fillStyle='#fff3c0';g.fill();
 for(let i=0;i<3;i++){const p=((t*1.4+i*.33+A.seed)%1);g.globalAlpha=1-p;wcEl(g,-6+i*6,-30-p*14,1.6,1.6,'#fff',0)}g.globalAlpha=1;
 g.beginPath();g.moveTo(0,-21);g.lineTo(0,-6);wcSt2(g,2.6);g.strokeStyle='#ffd45a';g.lineWidth=1.2;g.stroke();wcEl(g,0,-4,9,2.6,'#ffd45a',2.2);g.restore()}}
/* wings and tail behind the body, aura first */
function wcRareBack(g,A,t){const sk=WCSP.pdragon.skin,b=Math.sin(t*2.2+A.seed)*1.3;
 g.save();const au=g.createRadialGradient(0,-140,8,0,-140,96);au.addColorStop(0,'rgba(255,170,220,.32)');au.addColorStop(.6,'rgba(150,210,255,.14)');au.addColorStop(1,'rgba(150,210,255,0)');g.fillStyle=au;g.beginPath();g.arc(0,-140,96,0,Math.PI*2);g.fill();g.restore();
 const fl=Math.sin(t*2.4+A.seed)*.13;
 for(const s of [-1,1]){g.save();g.translate(s*30,-140+b);g.rotate(s*(fl-.05));const mg=g.createLinearGradient(0,-70,s*90,10);mg.addColorStop(0,'#ffb8e0');mg.addColorStop(.5,'#e0c8ff');mg.addColorStop(1,'#9ad8ff');
  g.beginPath();g.moveTo(0,0);g.lineTo(s*44,-66);g.quadraticCurveTo(s*60,-74,s*78,-62);g.quadraticCurveTo(s*72,-40,s*84,-18);g.quadraticCurveTo(s*68,-14,s*62,6);g.quadraticCurveTo(s*48,-2,s*40,20);g.quadraticCurveTo(s*24,6,s*12,26);g.closePath();g.fillStyle=mg;g.fill();wcSt2(g,3);
  g.beginPath();g.moveTo(s*4,2);g.lineTo(s*44,-66);g.moveTo(s*44,-66);g.lineTo(s*62,6);g.moveTo(s*44,-66);g.lineTo(s*40,20);g.moveTo(s*44,-66);g.lineTo(s*84,-18);g.lineWidth=2.4;g.strokeStyle='rgba(18,8,31,.55)';g.stroke();
  wcEl(g,s*44,-66,4,4,'#ffd45a',2);g.restore()}
 const sw=Math.sin(t*1.8+A.seed)*8;g.beginPath();g.moveTo(8,-60);g.bezierCurveTo(46,-48,80+sw,-40,72+sw,-82);g.lineWidth=16;g.strokeStyle=WCO;g.stroke();g.lineWidth=10;g.strokeStyle=sk[0];g.stroke();
 g.save();g.translate(72+sw,-90);g.rotate(sw*.02);g.beginPath();g.moveTo(0,8);g.bezierCurveTo(-14,-2,-10,-16,0,-9);g.bezierCurveTo(10,-16,14,-2,0,8);g.closePath();wcFS(g,'#ff5aa8',0,2.6);g.restore()}
/* sparkles in front */
function wcRareFront(g,A,t){for(const [x,y,ph] of [[-70,-210,0],[66,-226,1.3],[-58,-120,2.4],[84,-120,3.1],[0,-252,4.2]]){const a=Math.max(0,Math.sin(t*2.2+ph));if(a<.05)continue;g.save();g.translate(x,y);g.scale(.6+a*.5,.6+a*.5);g.globalAlpha=a;
 g.beginPath();g.moveTo(0,-8);g.lineTo(2,-2);g.lineTo(8,0);g.lineTo(2,2);g.lineTo(0,8);g.lineTo(-2,2);g.lineTo(-8,0);g.lineTo(-2,-2);g.closePath();g.fillStyle='#fff';g.fill();g.lineWidth=1.4;g.strokeStyle='#ff9ad0';g.stroke();g.restore()}}
{const d0=wcCrewDraw;wcCrewDraw=function(g,A,t){if(A.sp!=='pdragon')return d0.apply(this,arguments);g.save();g.lineJoin='round';g.lineCap='round';wcRareBack(g,A,t);g.restore();d0.apply(this,arguments);g.save();wcRareFront(g,A,t);g.restore()}}
/* the head */
{const h0=wcHead;wcHead=function(g,A,t){if(A.sp!=='pdragon')return h0.apply(this,arguments);const sk=WCSP.pdragon.skin,blink=((t+A.seed*.37)%4.6)<.14;
 for(const s of [-1,1]){g.beginPath();g.moveTo(s*9,-22);g.bezierCurveTo(s*26,-34,s*44,-30,s*56,-54);g.bezierCurveTo(s*46,-36,s*32,-22,s*22,-12);g.closePath();wcFS(g,'#ffd45a',s>0?0:99,2.8,'rgba(150,80,0,.25)');
  for(const k of [.3,.55,.78])g.beginPath(),g.moveTo(s*(16+k*32),-28-k*16),g.lineTo(s*(20+k*30),-20-k*18),wcSt2(g,1.4)}
 for(const s of [-1,1]){g.beginPath();g.moveTo(s*24,-10);g.lineTo(s*48,-22);g.lineTo(s*40,-8);g.lineTo(s*52,-2);g.lineTo(s*38,4);g.lineTo(s*44,12);g.lineTo(s*24,8);g.closePath();g.globalAlpha=.92;wcFS(g,A.fin||'#9ad8ff',null,2.4);g.globalAlpha=1}
 for(const s of [-1,1]){g.beginPath();g.moveTo(s*24,0);g.lineTo(s*36,4);g.lineTo(s*26,9);g.lineTo(s*34,15);g.lineTo(s*20,16);g.closePath();wcFS(g,sk[1],null,2.4)}
 g.beginPath();g.moveTo(0,-31);g.bezierCurveTo(20,-31,30,-18,29,-2);g.bezierCurveTo(28,12,18,20,0,20);g.bezierCurveTo(-18,20,-28,12,-29,-2);g.bezierCurveTo(-30,-18,-20,-31,0,-31);g.closePath();wcFS(g,sk[0],6,3.2,'rgba(120,90,200,.16)');
 for(const [x,y] of [[-6,-22],[6,-22],[0,-17],[-12,-18],[12,-18]]){g.beginPath();g.arc(x,y,3.2,Math.PI*.1,Math.PI*.9);g.lineWidth=1.3;g.strokeStyle='rgba(120,90,200,.6)';g.stroke()}
 for(const [x,h,c] of [[-8,8,'#ff9ad0'],[0,12,'#9ad8ff'],[8,8,'#ff9ad0']]){g.beginPath();g.moveTo(x-5,-27);g.lineTo(x,-27-h);g.lineTo(x+5,-27);g.closePath();g.globalAlpha=.9;wcFS(g,c,null,2);g.globalAlpha=1}
 g.beginPath();g.moveTo(-14,4);g.bezierCurveTo(-8,0,8,0,14,4);g.bezierCurveTo(20,10,16,26,0,27);g.bezierCurveTo(-16,26,-20,10,-14,4);g.closePath();wcFS(g,WCSP.pdragon.belly,6,2.8,'rgba(200,120,180,.18)');
 g.beginPath();g.moveTo(0,-12);g.lineTo(0,2);g.lineWidth=1.6;g.strokeStyle='rgba(120,90,200,.55)';g.stroke();
 for(const s of [-1,1]){g.beginPath();g.moveTo(s*3.5,9);g.quadraticCurveTo(s*7,7,s*8.5,10);wcSt2(g,2.4)}
 for(let i=0;i<2;i++){const p=((t*.45+A.seed*.01+i*.5)%1.4);if(p<1){g.globalAlpha=(1-p)*.55;wcEl(g,(i?7:-7)+(i?1:-1)*p*6,8-p*22,2.5+p*4,2.5+p*4,'#f4eeff',0)}}g.globalAlpha=1;
 g.beginPath();g.moveTo(-11,19);g.quadraticCurveTo(1,24.5,12,18);wcSt2(g,2.4);for(const x of [-8,8]){g.beginPath();g.moveTo(x-1.6,20.4);g.lineTo(x,25);g.lineTo(x+1.6,20.6);g.closePath();wcFS(g,'#fff',null,1.2)}
 for(const [s,c] of [[-1,'#ff5ab0'],[1,'#3ad0ff']]){const x=s*12,y=-6;if(blink){g.beginPath();g.moveTo(x-7,y);g.quadraticCurveTo(x,y+4,x+7,y);wcSt2(g,2.8);continue}
  g.save();g.globalAlpha=.35+Math.sin(t*3+s)*.12;wcEl(g,x,y,11,9,c,0);g.restore();g.beginPath();g.moveTo(x-8,y);g.quadraticCurveTo(x,y-9,x+8,y);g.quadraticCurveTo(x,y+7,x-8,y);g.closePath();wcFS(g,c,null,2.4);
  wcEl(g,x,y,1.8,5,WCO,0);wcEl(g,x-2.5,y-2.5,1.4,1.4,'#fff',0)}
 for(const s of [-1,1]){g.beginPath();g.moveTo(s*4,-14);g.lineTo(s*20,-17);wcSt2(g,2.8)}
 g.save();g.translate(0,-24);g.rotate(-.06);for(const s of [-1,1]){g.save();g.translate(s*10,0);g.beginPath();g.moveTo(0,5);g.bezierCurveTo(-11,-2,-7,-11,0,-5);g.bezierCurveTo(7,-11,11,-2,0,5);g.closePath();g.globalAlpha=.9;wcFS(g,'#ff5aa8',null,2.2);g.globalAlpha=1;wcHi(g,-4,-4,-3,-6,-1,-6,1.4);g.restore()}
  g.beginPath();g.moveTo(-3,-1);g.lineTo(3,-1);g.lineWidth=2.4;g.strokeStyle='#ffd45a';g.stroke();g.restore();
 wcHi(g,-20,-14,-18,-22,-11,-26)}}
