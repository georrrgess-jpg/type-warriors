/* ===== PERFORMANCE MODE LEAVES THE CASINO ALONE =====
   Balanced and Performance still lighten the rest of the game, but every Casino screen (the lobby, each game and all of Wildcard,
   i.e. any #ov screen with the casbg class) runs exactly as in Quality: full resolution, full-rate menu canvases, canvas glow,
   looping CSS animations, backdrop blur and Wildcard's full-length deal and effects. PFM() in 88k returns 'high' while pfCas() is true;
   pfCasSync() re-applies the mode the moment you step in or out. */
function pfCas(){try{return /\bcasbg\b/.test(ov.className)}catch(e){return false}}
const PFC={last:false};
function pfCasSync(){try{const c=pfCas();if(c===PFC.last)return;PFC.last=c;if(PFSET()==='high')return;PFBG.ok=false;applyLayout()}catch(e){}}
{const s0=show;show=function(){const r=s0.apply(this,arguments);pfCasSync();return r}}
{const h0=hide;hide=function(){const r=h0.apply(this,arguments);pfCasSync();return r}}
/* a cheap per-frame check catches any other way the overlay changes */
{const l0=loop;loop=function(ts){pfCasSync();return l0(ts)}}
/* Performance mode changes nothing in the Casino, so the "Running slowly?" offer waits until you are outside it */
{const o0=pfOffer;pfOffer=function(){if(pfCas())return;return o0.apply(this,arguments)}}
