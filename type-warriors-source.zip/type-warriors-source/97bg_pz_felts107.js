/* ===== 10.7 THE CROOKED CUE: patterned felts and three premium cues (97bg, prefix pzf7, after 97bf) =====
   FELTS. Nine new PZ_FELT entries carry a pattern (pat). Six are sold in the Cue Rack (price, hold-to-buy like the balls), three are
   won once from the players of The Gilded Hoard (beat:'zephyra' genie, beat:'hornsby' velvet, beat:'aurelion' hoard; the generic
   pzUnlockSweep in 96a handles beat:). The five old felts stay plain. Each felt keeps the three base colours a / b / c that every
   renderer already uses for the cloth gradient; the pattern is a separate transparent OVERLAY, baked once per felt (PZF7.tex) at
   880 x 440 table units x PZF7.S, and stamped on top of the base cloth. Zero per-frame cost: every place a felt shows is itself baked
   (match backdrop pzBake, hub table pz97Table, Trick Shot minis pz97Mini, Cue Rack cards / preview / live demo pzPersBake).
   Patterns are low contrast so balls (dark 8s, white cue balls) stay readable; t_pzf107.py measures it in a real match.

   THE SHARED DRAWER (also for the venue agent's room table):
     pzf7Felt(g, feltId, map [, o])  -> true if it drew (false for plain felts, so callers need no checks)
       Call it right after you fill the cloth with the felt's base colours, while the cloth shape is clipped, and before the lamp light
       and cushion shadows. map is either
         {x,y,w,h}          a flat table: the playfield rectangle in g's current coordinates (u along the length, v across), or
         (u,v)=>[x,y]|{x,y}  a table in perspective: u,v in 0..1 over the playfield, x linear in u, y depending only on v
                            (the 9.7 trapezoids tr(...) and pzPersp's P.p both qualify). Drawn per device pixel row, so no seams.
       o.alpha (optional) scales the overlay. pzf7Felt(g,id,x,y,w,h) is accepted too. Pass the playfield itself (0,0,W,H), not the
       bleed rectangle you fill the base colour into, or the coin border of 'hoard' slides under the cushions.
     pzf7Tex(feltId)     -> the baked overlay canvas (or null): for a CanvasPattern or your own drawImage.
     pzf7Has(feltId)     -> whether a felt has a pattern.
   Hooks (one line each, backups .v1bak): 96f pzBakeTable, 96zg pz97Table, 96zh pz97Mini, 96zj pzPersBake and pzFeltCard97.
   The Cue Rack felts tab scrolls (vertical grid, arrows, wheel, the equipped felt scrolled into view, PREMIUM on paid felts).

   CUES. Three premium cues for sale (Storm Caller 20,000, Phoenix Feather 35,000, Dragon's Hoard 60,000) with an inlay drawn
   into the forearm and a motif on the butt sleeve (wrapper of pzCueMotif in 96zc: it steps out of the sleeve clip, draws the
   forearm inlay, then re-clips; the save / restore stack stays balanced). They glow like the other glow cues (one sprite at the
   table, as before), carry a PREMIUM mark on the wall, and earn cue mastery like every cue. */
const PZF7={tex:{},S:1.2,on:1};
/* ---------- the felts ---------- */
const PZF7_FELTS=[
 {id:'sakura',n:'Sakura Bloom',a:'#92506a',b:'#763c56',c:'#4a2034',how:'Cue Rack: 5,000',price:5000,pat:'sakura',tag:'Dusky rose, petals drifting across the cloth.'},
 {id:'starlight',n:'Starlight Velvet',a:'#2c3e8a',b:'#1f2e70',c:'#111a46',how:'Cue Rack: 8,000',price:8000,pat:'star',tag:'Deep navy with tiny stars and faint constellations.'},
 {id:'abyssal',n:'Abyssal Tide',a:'#1c7e88',b:'#145f6c',c:'#0a3a48',how:'Cue Rack: 12,000',price:12000,pat:'tide',tag:'Deep teal, with sea light rippling over it.'},
 {id:'damask',n:'Royal Damask',a:'#1c8458',b:'#136444',c:'#0a412c',how:'Cue Rack: 18,000',price:18000,pat:'damask',tag:'Emerald with a tone-on-tone gold damask.'},
 {id:'aurora',n:'Aurora Frost',a:'#5468b8',b:'#414e98',c:'#29306a',how:'Cue Rack: 25,000',price:25000,pat:'aurora',tag:'Icy blue-violet under a soft aurora.'},
 {id:'forge',n:'Molten Forge',a:'#545254',b:'#3e3c42',c:'#252328',how:'Cue Rack: 40,000',price:40000,pat:'forge',tag:'Charcoal with ember cracks glowing underneath.'},
 {id:'genie',n:'Genie Smoke',a:'#2a8888',b:'#1d6a70',c:'#10464f',how:'Beat Zephyra',beat:'zephyra',pat:'smoke',tag:'Teal, with lamp smoke curling over it.'},
 {id:'velvet',n:'Crimson Velvet',a:'#962638',b:'#701828',c:'#460c18',how:'Beat Baron Hornsby',beat:'hornsby',pat:'velvet',tag:'The Baron\'s own: deep crimson with a soft pile sheen.'},
 {id:'hoard',n:'Gilded Hoard',a:'#902232',b:'#6c1626',c:'#420a16',how:'Beat Aurelion the Hoardwing',beat:'aurelion',pat:'hoard',tag:'Crimson and gold damask, ringed with coins.'}
];
for(const f of PZF7_FELTS)if(!PZ_FELT.some(x=>x.id===f.id))PZ_FELT.push(f);
try{for(const f of PZF7_FELTS)PZ_FTAG97[f.id]=f.tag}catch(e){}
function pzf7Rng(s){s=s>>>0||1;return()=>{s=(s+0x6D2B79F5)>>>0;let t=s;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296}}
function pzf7Has(id){const f=PZ_FELT.find(x=>x.id===id);return !!(PZF7.on&&f&&f.pat&&PZF7_PAT[f.pat])}
function pzf7Tex(id){if(!pzf7Has(id))return null;if(PZF7.tex[id])return PZF7.tex[id];const f=PZ_FELT.find(x=>x.id===id),S=PZF7.S,W=PZ_PHY.W,H=PZ_PHY.H,c=pzCv(Math.round(W*S),Math.round(H*S)),g=c.getContext('2d');
 g.scale(S,S);g.lineJoin='round';g.lineCap='round';try{PZF7_PAT[f.pat](g,W,H,f,pzf7Rng(id.length*7919+id.charCodeAt(0)*131+id.charCodeAt(1)))}catch(e){console.error(e)}return PZF7.tex[id]=c}
function pzf7Felt(g,id,map,o){if(typeof map==='number'){/* also pzf7Felt(g,id,x,y,w,h[,o]) */const A=arguments;map={x:A[2],y:A[3],w:A[4],h:A[5]};o=A[6]}const T=pzf7Tex(id);if(!T||!map)return false;g.save();if(o&&o.alpha!=null)g.globalAlpha*=o.alpha;g.imageSmoothingEnabled=true;g.imageSmoothingQuality='high';
 if(typeof map!=='function'){g.drawImage(T,map.x,map.y,map.w,map.h);g.restore();return true}
 /* perspective: one device-pixel row at a time (y depends only on v, x is linear in u) */
 const m=g.getTransform(),pt=(u,v)=>{const r=map(u,v);return Array.isArray(r)?r:[r.x,r.y]},K=256,vs=[],ys=[];
 for(let i=0;i<=K;i++){const v=i/K,p=pt(0,v);vs.push(v);ys.push(m.d*p[1]+m.b*p[0]+m.f)}
 const up=ys[K]>=ys[0],vAt=y=>{/* inverse of y(v) by walking the samples */let lo=0,hi=K;if(up?y<=ys[0]:y>=ys[0])return 0;if(up?y>=ys[K]:y<=ys[K])return 1;
  while(hi-lo>1){const md=(lo+hi)>>1;if(up?ys[md]<=y:ys[md]>=y)lo=md;else hi=md}return vs[lo]+(vs[hi]-vs[lo])*(y-ys[lo])/((ys[hi]-ys[lo])||1)};
 const y0=Math.floor(Math.min(ys[0],ys[K])),y1=Math.ceil(Math.max(ys[0],ys[K])),TH=T.height,TW=T.width;g.setTransform(1,0,0,1,0,0);
 for(let y=y0;y<y1;y++){const va=vAt(y),vb=vAt(y+1),v0=Math.min(va,vb),v1=Math.max(va,vb);if(v1<=v0)continue;const vm=(v0+v1)/2,a=pt(0,vm),b=pt(1,vm),xa=m.a*a[0]+m.c*a[1]+m.e,xb=m.a*b[0]+m.c*b[1]+m.e;
  const sy=v0*TH,sh=Math.max(.5,(v1-v0)*TH);g.drawImage(T,0,Math.min(sy,TH-sh),TW,sh,Math.min(xa,xb),y,Math.abs(xb-xa),1)}
 g.restore();return true}
/* ---------- the patterns (each draws on a transparent W x H canvas in table units; keep them soft and low contrast) ---------- */
const pzf7Dot=(g,x,y,r)=>{g.beginPath();g.arc(x,y,r,0,TAU);g.fill()};
/* a soft blotch layer: a tiny random grid scaled up smoothly (crushed velvet, smoke depth, basalt) */
function pzf7Blot(g,W,H,R,cells,col,amax,minA){const cw=Math.ceil(W/cells)+2,ch=Math.ceil(H/cells)+2,c=pzCv(cw,ch),x=c.getContext('2d'),im=x.createImageData(cw,ch),[r,gg,b]=col;
 for(let i=0;i<cw*ch;i++){const v=R();im.data[i*4]=r;im.data[i*4+1]=gg;im.data[i*4+2]=b;im.data[i*4+3]=Math.max(0,(v-(minA||0))/(1-(minA||0)))*amax*255}
 x.putImageData(im,0,0);g.save();g.imageSmoothingEnabled=true;g.imageSmoothingQuality='high';g.drawImage(c,1,1,cw-2,ch-2,0,0,W,H);g.restore()}
/* the damask motif, white on transparent, 120 x 156, stamped tinted at low alpha */
let PZF7_DM=null;
function pzf7Damask(){if(PZF7_DM)return PZF7_DM;const c=pzCv(120,156),g=c.getContext('2d');g.translate(60,78);g.fillStyle='#fff';g.strokeStyle='#fff';g.lineCap='round';g.lineJoin='round';
 for(const s of[1,-1]){g.save();g.scale(s,1);
  /* the ogee medallion */
  g.beginPath();g.moveTo(0,-64);g.bezierCurveTo(6,-50,30,-38,30,-10);g.bezierCurveTo(30,18,10,30,0,62);g.lineTo(0,40);g.bezierCurveTo(6,26,19,12,19,-8);g.bezierCurveTo(19,-28,6,-38,0,-46);g.closePath();g.fill();
  /* the inner flower: a leaf pair and a bud */
  g.beginPath();g.moveTo(0,22);g.bezierCurveTo(4,10,12,4,13,-6);g.bezierCurveTo(8,-4,2,4,0,12);g.closePath();g.fill();
  g.beginPath();g.moveTo(0,-4);g.bezierCurveTo(5,-12,6,-22,0,-32);g.lineTo(0,-4);g.fill();
  /* outside scrolls curling away from the waist */
  g.lineWidth=3.2;g.beginPath();g.moveTo(26,14);g.bezierCurveTo(44,16,56,2,50,-12);g.bezierCurveTo(46,-22,34,-18,38,-10);g.stroke();
  g.lineWidth=2.6;g.beginPath();g.moveTo(22,-34);g.bezierCurveTo(36,-46,52,-40,48,-28);g.bezierCurveTo(46,-22,40,-24,41,-30);g.stroke();
  g.beginPath();g.moveTo(40,-10);g.bezierCurveTo(46,-6,50,4,44,8);g.lineTo(38,0);g.closePath();g.fill();
  /* the leaf tips at the bottom */
  g.beginPath();g.moveTo(4,58);g.bezierCurveTo(16,60,26,70,24,76);g.bezierCurveTo(16,74,8,68,4,58);g.fill();
  g.restore()}
 /* the top fleur and the diamond under it */
 g.beginPath();g.moveTo(0,-76);g.bezierCurveTo(6,-70,6,-66,0,-62);g.bezierCurveTo(-6,-66,-6,-70,0,-76);g.fill();
 pzf7Dot(g,0,-56,2.6);g.beginPath();g.moveTo(0,64);g.lineTo(5,71);g.lineTo(0,78);g.lineTo(-5,71);g.closePath();g.fill();
 return PZF7_DM=c}
/* stamp a tinted motif over the table in a half-drop grid */
function pzf7DamaskFill(g,W,H,col,al,dark,sx){const m=pzf7Damask(),t=pzCv(m.width,m.height),x=t.getContext('2d');x.drawImage(m,0,0);x.globalCompositeOperation='source-in';x.fillStyle=col;x.fillRect(0,0,t.width,t.height);
 let d=null;if(dark){d=pzCv(m.width,m.height);const y=d.getContext('2d');y.drawImage(m,0,0);y.globalCompositeOperation='source-in';y.fillStyle=dark;y.fillRect(0,0,d.width,d.height)}
 const s=sx||.62,cw=118*s,chh=150*s,w=m.width*s,h=m.height*s;
 for(let i=-1,col0=0;i*cw<W+cw;i++,col0++)for(let j=-1;j*chh<H+chh;j++){const cx=i*cw,cy=j*chh+(col0%2?chh/2:0);
  if(d){g.globalAlpha=al*.95;g.drawImage(d,cx-w/2+1.4,cy-h/2+1.8,w,h)}g.globalAlpha=al;g.drawImage(t,cx-w/2,cy-h/2,w,h)}g.globalAlpha=1}
const PZF7_PAT={
 /* Sakura Bloom: single petals drifting, a few open blossoms, soft pink bokeh */
 sakura(g,W,H,f,R){for(let i=0;i<10;i++){const x=R()*W,y=R()*H,r=60+R()*90,q=g.createRadialGradient(x,y,0,x,y,r);q.addColorStop(0,'rgba(255,200,215,.06)');q.addColorStop(1,'rgba(255,200,215,0)');g.fillStyle=q;g.fillRect(x-r,y-r,r*2,r*2)}
  const petal=(x,y,s,a,al)=>{g.save();g.translate(x,y);g.rotate(a);g.beginPath();g.moveTo(0,s);g.bezierCurveTo(s*.75,s*.55,s*.62,-s*.55,s*.16,-s*.92);g.lineTo(0,-s*.66);g.lineTo(-s*.16,-s*.92);g.bezierCurveTo(-s*.62,-s*.55,-s*.75,s*.55,0,s);g.closePath();
   g.fillStyle=`rgba(255,218,230,${al})`;g.fill();g.strokeStyle=`rgba(120,40,70,${al*.55})`;g.lineWidth=.8;g.stroke();g.strokeStyle=`rgba(255,245,250,${al*.7})`;g.lineWidth=.7;g.beginPath();g.moveTo(0,s*.7);g.lineTo(0,-s*.4);g.stroke();g.restore()};
  const pts=[];for(let i=0;i<260&&pts.length<64;i++){const x=12+R()*(W-24),y=12+R()*(H-24);if(pts.every(p=>Math.hypot(p[0]-x,p[1]-y)>44))pts.push([x,y])}
  pts.forEach(([x,y],i)=>{if(i%6===0){const s=6+R()*2.5,a0=R()*TAU;for(let k=0;k<5;k++){const a=a0+k*TAU/5;petal(x+Math.cos(a-Math.PI/2)*s*.9,y+Math.sin(a-Math.PI/2)*s*.9,s,a,.19)}g.fillStyle='rgba(255,228,150,.22)';pzf7Dot(g,x,y,2);for(let k=0;k<5;k++){const a=a0+k*TAU/5+.6;g.fillStyle='rgba(255,236,170,.2)';pzf7Dot(g,x+Math.cos(a)*3.6,y+Math.sin(a)*3.6,.8)}}
   else petal(x,y,4.5+R()*3.5,R()*TAU,.13+R()*.07)})},
 /* Starlight Velvet: nebula haze, specks, a few sparkles, faint constellations, a velvet sheen */
 star(g,W,H,f,R){for(let i=0;i<7;i++){const x=R()*W,y=R()*H,r=110+R()*130,q=g.createRadialGradient(x,y,0,x,y,r),c=i%2?'150,120,255':'110,170,255';q.addColorStop(0,`rgba(${c},.075)`);q.addColorStop(1,`rgba(${c},0)`);g.fillStyle=q;g.fillRect(x-r,y-r,r*2,r*2)}
  {const q=g.createLinearGradient(0,0,W,H);q.addColorStop(0,'rgba(255,255,255,0)');q.addColorStop(.42,'rgba(200,215,255,.05)');q.addColorStop(.55,'rgba(255,255,255,0)');g.fillStyle=q;g.fillRect(0,0,W,H)}
  for(let i=0;i<760;i++){const x=R()*W,y=R()*H,b=R(),r=b>.93?1.05:b>.6?.75:.5;g.fillStyle=`rgba(${b>.8?'255,250,235':'210,225,255'},${.14+b*.3})`;pzf7Dot(g,x,y,r)}
  for(let i=0;i<16;i++){const x=20+R()*(W-40),y=20+R()*(H-40),l=3+R()*3.5;g.strokeStyle='rgba(235,240,255,.34)';g.lineWidth=.7;g.beginPath();g.moveTo(x-l,y);g.lineTo(x+l,y);g.moveTo(x,y-l);g.lineTo(x,y+l);g.stroke();g.fillStyle='rgba(255,255,255,.5)';pzf7Dot(g,x,y,1)}
  const cons=[[[0,0],[22,-14],[48,-10],[64,8],[90,2]],[[0,0],[18,16],[40,10],[52,30],[30,44]],[[0,0],[26,6],[30,30],[8,36],[0,0]],[[0,0],[14,-20],[36,-26],[50,-6],[70,-18],[86,-6]],[[0,0],[20,10],[44,4],[62,20]]];
  cons.forEach((cs,i)=>{const ox=80+((i*190+R()*60)%(W-200)),oy=60+R()*(H-140),s=1+R()*.3;g.strokeStyle='rgba(200,220,255,.11)';g.lineWidth=.8;g.beginPath();cs.forEach(([x,y],k)=>k?g.lineTo(ox+x*s,oy+y*s):g.moveTo(ox+x*s,oy+y*s));g.stroke();
   for(const [x,y] of cs){g.fillStyle='rgba(240,245,255,.42)';pzf7Dot(g,ox+x*s,oy+y*s,1.25);g.fillStyle='rgba(200,220,255,.08)';pzf7Dot(g,ox+x*s,oy+y*s,3.4)}})},
 /* Abyssal Tide: baked water caustics (a classic tileable caustic, low res, scaled up soft) and light shafts */
 tide(g,W,H,f,R){const k=.5,w=Math.round(W*k),h=Math.round(H*k),c=pzCv(w,h),x=c.getContext('2d'),im=x.createImageData(w,h),T=1.7;
  for(let py=0;py<h;py++)for(let px=0;px<w;px++){const ux=px/w*W/230,uy=py/h*H/230;let p0=(ux*TAU)%TAU-250,p1=(uy*TAU)%TAU-250,i0=p0,i1=p1,cc=1;const inten=.005;
   for(let n=0;n<5;n++){const t=T*(1-3.5/(n+1));const a=i0,b=i1;i0=p0+Math.cos(t-a)+Math.sin(t+b);i1=p1+Math.sin(t-b)+Math.cos(t+a);cc+=1/Math.hypot(p0/(Math.sin(i0+t)/inten),p1/(Math.cos(i1+t)/inten))}
   cc/=5;cc=1.17-Math.pow(cc,1.4);const v=Math.min(1,Math.pow(Math.abs(cc),8)),o=(py*w+px)*4;im.data[o]=190;im.data[o+1]=255;im.data[o+2]=245;im.data[o+3]=v*.2*255}
  x.putImageData(im,0,0);g.save();g.imageSmoothingEnabled=true;g.imageSmoothingQuality='high';g.drawImage(c,0,0,W,H);g.restore();
  for(let i=0;i<5;i++){const x0=R()*W*1.2-W*.1,wd=40+R()*70;g.save();g.translate(x0,0);g.transform(1,0,.45,1,0,0);const q=g.createLinearGradient(-wd/2,0,wd/2,0);q.addColorStop(0,'rgba(160,255,240,0)');q.addColorStop(.5,'rgba(160,255,240,.04)');q.addColorStop(1,'rgba(160,255,240,0)');g.fillStyle=q;g.fillRect(-wd/2,0,wd,H);g.restore()}
  for(let i=0;i<22;i++){const x0=R()*W,y0=R()*H,r=1.2+R()*2.2;g.strokeStyle='rgba(200,255,250,.12)';g.lineWidth=.7;g.beginPath();g.arc(x0,y0,r,0,TAU);g.stroke()}},
 /* Royal Damask: a gold motif, tone on tone, with a dark emboss */
 damask(g,W,H,f,R){pzf7DamaskFill(g,W,H,'rgb(255,214,120)',.085,'rgb(0,30,14)',.62);
  const q=g.createRadialGradient(W/2,H/2,40,W/2,H/2,W*.6);q.addColorStop(0,'rgba(255,230,160,.03)');q.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=q;g.fillRect(0,0,W,H)},
 /* Aurora Frost: curtains of light and frost ferns at the corners */
 aurora(g,W,H,f,R){const strip=(c1,c2)=>{const s=pzCv(2,200),x=s.getContext('2d'),q=x.createLinearGradient(0,0,0,200);q.addColorStop(0,`rgba(${c2},0)`);q.addColorStop(.5,`rgba(${c2},.45)`);q.addColorStop(.86,`rgba(${c1},1)`);q.addColorStop(1,`rgba(${c1},0)`);x.fillStyle=q;x.fillRect(0,0,2,200);return s};
  const C=[[strip('140,255,200','150,140,255'),H*.42,70,.0105,.6,.2],[strip('120,240,255','200,150,255'),H*.66,55,.0135,2.1,.14],[strip('160,255,210','120,170,255'),H*.24,48,.009,4.0,.11]];
  for(const [s,yb,A,kf,ph,al] of C)for(let x=-4;x<W+4;x+=2){const y=yb+A*Math.sin(x*kf+ph)+A*.35*Math.sin(x*kf*2.7+ph*1.7),hh=90+40*Math.sin(x*.021+ph),a=al*(.55+.45*Math.sin(x*.035+ph*3))*(.85+.15*Math.sin(x*.11+ph));g.globalAlpha=Math.max(0,a);g.drawImage(s,x,y-hh,2.6,hh+14)}g.globalAlpha=1;
  const fern=(x,y,a,l,d)=>{if(d>3||l<4)return;const x2=x+Math.cos(a)*l,y2=y+Math.sin(a)*l;g.beginPath();g.moveTo(x,y);g.lineTo(x2,y2);g.stroke();for(let i=1;i<=3;i++){const t=i/4,bx=x+(x2-x)*t,by=y+(y2-y)*t;fern(bx,by,a+.75,l*.38,d+1);fern(bx,by,a-.75,l*.38,d+1)}fern(x2,y2,a+(R()-.5)*.4,l*.55,d+1)};
  g.strokeStyle='rgba(235,245,255,.09)';g.lineWidth=.8;for(const [cx,cy,a0] of[[0,0,.6],[W,0,Math.PI-.6],[0,H,-.6],[W,H,Math.PI+.6],[W/2,0,Math.PI/2],[W/2,H,-Math.PI/2]])for(let i=0;i<3;i++)fern(cx,cy,a0+(i-1)*.5,46+R()*20,0);
  for(let i=0;i<180;i++){g.fillStyle=`rgba(235,245,255,${.08+R()*.18})`;pzf7Dot(g,R()*W,R()*H,.5+R()*.5)}},
 /* Molten Forge: basalt mottling, faint glowing cracks, a few embers */
 forge(g,W,H,f,R){pzf7Blot(g,W,H,R,26,[0,0,0],.12,.35);pzf7Blot(g,W,H,R,14,[255,150,110],.03,.5);
  const k=1,w=Math.round(W*k),h=Math.round(H*k),c=pzCv(w,h),x=c.getContext('2d'),im=x.createImageData(w,h),sd=[],GX=7,GY=4,cw=W/GX,ch=H/GY;
  for(let i=-1;i<=GX;i++){const col=[];for(let j=-1;j<=GY;j++)col.push([(i+.15+R()*.7)*cw,(j+.15+R()*.7)*ch,R()]);sd.push(col)}
  for(let py=0;py<h;py++)for(let px=0;px<w;px++){const X0=px/k,Y0=py/k,X=X0+5*Math.sin(Y0*.06)+2.5*Math.sin(Y0*.19+X0*.03),Y=Y0+5*Math.sin(X0*.055+1)+2.5*Math.sin(X0*.21-Y0*.02);let d1=1e9,d2=1e9,s1=null;const ci=Math.floor(X/cw)+1,cj=Math.floor(Y/ch)+1;for(let i=ci-1;i<=ci+1;i++){const col=sd[i];if(!col)continue;for(let j=cj-1;j<=cj+1;j++){const q=col[j];if(!q)continue;const dx=q[0]-X,dy=q[1]-Y,d=dx*dx+dy*dy;if(d<d1){d2=d1;d1=d;s1=q}else if(d<d2)d2=d}}
   const e=Math.sqrt(d2)-Math.sqrt(d1),h0=.5+.5*Math.sin(X*.009+Y*.014+s1[2]*6)*Math.cos(X*.004-Y*.006+1),heat=h0*h0*(3-2*h0),glow=Math.exp(-e/8)*.15*heat,core=Math.exp(-e/1.3)*.45*heat,o=(py*w+px)*4,a=Math.min(1,glow+core);
   im.data[o]=255;im.data[o+1]=Math.round(70+140*core/(a||1));im.data[o+2]=Math.round(20+70*core/(a||1));im.data[o+3]=a*255}
  x.putImageData(im,0,0);g.save();g.imageSmoothingEnabled=true;g.imageSmoothingQuality='high';g.drawImage(c,0,0,W,H);g.restore();
  for(let i=0;i<110;i++){g.fillStyle=`rgba(255,${120+R()*90|0},60,${.12+R()*.2})`;pzf7Dot(g,R()*W,R()*H,.5+R()*.7)}},
 /* Genie Smoke: wisps that drift in a soft flow and curl at the ends */
 smoke(g,W,H,f,R){pzf7Blot(g,W,H,R,40,[180,255,240],.06,.4);
  const fld=(x,y)=>Math.sin(x*.009+1.3)*1.4+Math.cos(y*.012-.4)*1.2+Math.sin((x+y)*.004)*.8;
  for(let i=0;i<26;i++){let x=R()*W,y=R()*H;const pts=[[x,y]],n=30+R()*40|0;for(let k=0;k<n;k++){const a=fld(x,y);x+=Math.cos(a)*6;y+=Math.sin(a)*6;pts.push([x,y])}
   /* the curl at the end */let a=fld(x,y),r=14+R()*10;const dir=R()<.5?1:-1;for(let k=0;k<18;k++){a+=dir*.42;r*=.9;x+=Math.cos(a)*r*.42;y+=Math.sin(a)*r*.42;pts.push([x,y])}
   const col=i%3?'200,255,245':'225,205,255';for(const [lw,al] of[[20,.022],[11,.034],[5,.042],[2.2,.04]]){g.strokeStyle=`rgba(${col},${al})`;g.lineWidth=lw;g.beginPath();pts.forEach(([px,py],k)=>k?g.lineTo(px,py):g.moveTo(px,py));g.stroke()}}
  for(let i=0;i<70;i++){g.fillStyle=`rgba(255,230,160,${.1+R()*.2})`;pzf7Dot(g,R()*W,R()*H,.5+R()*.6)}},
 /* Crimson Velvet: crushed-velvet mottling, a diagonal pile sheen, fine pile */
 velvet(g,W,H,f,R){pzf7Blot(g,W,H,R,30,[255,170,185],.085,.45);pzf7Blot(g,W,H,R,18,[0,0,0],.12,.4);
  for(const [p,al] of[[.3,.07],[.62,.05]]){const q=g.createLinearGradient(0,0,W,H*.6);q.addColorStop(Math.max(0,p-.12),'rgba(255,190,200,0)');q.addColorStop(p,`rgba(255,190,200,${al})`);q.addColorStop(Math.min(1,p+.12),'rgba(255,190,200,0)');g.fillStyle=q;g.fillRect(0,0,W,H)}
  for(let i=0;i<1600;i++){const x=R()*W,y=R()*H;g.fillStyle=R()<.5?'rgba(255,200,210,.05)':'rgba(0,0,0,.06)';g.fillRect(x,y,.7,2.4)}},
 /* Gilded Hoard: crimson, a gold damask and a ring of gold coins inside the cushions */
 hoard(g,W,H,f,R){pzf7Blot(g,W,H,R,24,[0,0,0],.08,.45);pzf7DamaskFill(g,W,H,'rgb(255,200,90)',.10,'rgb(40,0,8)',.58);
  const CM=PZ_PHY.CM||31,SM=PZ_PHY.SM||27,o1=11,o2=33;
  const seg=[[CM+14,W/2-SM-14,'h'],[W/2+SM+14,W-CM-14,'h']],segV=[[CM+14,H-CM-14]];
  g.strokeStyle='rgba(255,206,96,.30)';g.lineWidth=1.4;for(const o of[o1,o2]){for(const [a,b] of seg){g.beginPath();g.moveTo(a,o);g.lineTo(b,o);g.moveTo(a,H-o);g.lineTo(b,H-o);g.stroke()}for(const [a,b] of segV){g.beginPath();g.moveTo(o,a);g.lineTo(o,b);g.moveTo(W-o,a);g.lineTo(W-o,b);g.stroke()}}
  const coin=(x,y,r)=>{const q=g.createRadialGradient(x-r*.35,y-r*.35,0,x,y,r);q.addColorStop(0,'rgba(255,246,190,.42)');q.addColorStop(.6,'rgba(240,180,60,.34)');q.addColorStop(1,'rgba(150,90,20,.34)');g.fillStyle=q;pzf7Dot(g,x,y,r);
   g.strokeStyle='rgba(90,40,6,.35)';g.lineWidth=.8;g.stroke();g.strokeStyle='rgba(255,236,170,.35)';g.lineWidth=.6;g.beginPath();g.arc(x,y,r*.62,0,TAU);g.stroke()};
  const om=(o1+o2)/2,rc=6.2,st=19;
  for(const [a,b] of seg){const n=Math.floor((b-a)/st);for(let i=0;i<=n;i++){const x=a+(b-a)*i/n;coin(x,om,rc);coin(x,H-om,rc)}}
  for(const [a,b] of segV){const n=Math.floor((b-a)/st);for(let i=0;i<=n;i++){const y=a+(b-a)*i/n;coin(om,y,rc);coin(W-om,y,rc)}}
  const q=g.createRadialGradient(W/2,H/2,30,W/2,H/2,W*.55);q.addColorStop(0,'rgba(255,214,120,.04)');q.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=q;g.fillRect(0,0,W,H)}
};
/* the "In your hand" thumbnails and the hub's next-prize chip (96j pzRackThumb): the patterned cloth under the frame */
{const f0=pzRackThumb;pzRackThumb=function(g,tab,it,w,h){if(tab!=='felts'||!it||!pzf7Has(it.id))return f0.apply(this,arguments);g.clearRect(0,0,w,h);
 g.save();pzRR(g,6,4,w-12,h-8,9);g.fillStyle=pzLin(g,0,0,0,h,[[0,it.a],[1,it.b]]);g.fill();g.clip();const fw=w-12,fh=fw/2;pzf7Felt(g,it.id,{x:6,y:4+(h-8-fh)/2,w:fw,h:fh},{alpha:1.4});g.restore();
 pzRR(g,6,4,w-12,h-8,9);g.strokeStyle='#7a4018';g.lineWidth=6;g.stroke();g.strokeStyle=PZ_O;g.lineWidth=2;pzRR(g,3,1,w-6,h-2,11);g.stroke();g.fillStyle='rgba(255,255,255,.85)';g.beginPath();g.arc(w*.3,h/2,6,0,TAU);g.fill();g.stroke()}}
/* ---------- the Cue Rack felts tab: a scrolling grid ---------- */
{const st=document.createElement('style');st.textContent=`
.pzrk97 .pzkfg.pzf7s{inset:6px 6px 6px 16px;padding:12px 10px 12px 0;grid-auto-rows:auto;align-content:start;overflow-y:auto;overflow-x:hidden;scroll-behavior:smooth;scrollbar-width:thin;scrollbar-color:#6a5ab8 transparent}
.pzkfg.pzf7s::-webkit-scrollbar{width:8px}.pzkfg.pzf7s::-webkit-scrollbar-thumb{background:#5a4aa8;border-radius:4px}
.pzkfc.pzf7p::before{content:'PREMIUM';position:absolute;left:50%;top:-9px;transform:translateX(-50%);padding:2px 8px;border-radius:9px;background:linear-gradient(180deg,#ffe27a,#d69a1e);color:#3a2204;font:800 10px/1.3 Poppins,sans-serif;letter-spacing:.09em;border:2px solid #12081f;z-index:2;pointer-events:none}
.pzf7nav{position:absolute;left:50%;width:96px;height:30px;margin-left:-48px;border-radius:12px;border:3px solid #12081f;background:linear-gradient(180deg,#ffe27a,#d69a1e);color:#3a2204;font:800 22px/1 Poppins,sans-serif;cursor:pointer;z-index:5;display:none;align-items:center;justify-content:center;box-shadow:0 6px 16px #0009;transition:transform .15s}
.pzf7nav.u{top:-14px}.pzf7nav.d{bottom:-14px}.pzf7nav:hover{transform:scale(1.08)}.pzf7nav.on{display:flex}
.pzf7sec{grid-column:1/3;height:22px;margin:2px 0 -4px;font:800 12px/22px Poppins,sans-serif;letter-spacing:.12em;color:#ffd45a;text-align:left;padding-left:4px}
.pzkwall.cues.pzf7many .pzkc97{width:90px}.pzkwall.cues.pzf7many .pzkc97>canvas{left:13px}.pzkwall.cues.pzf7many .pzkcols97{left:26px;right:26px}
.pzkc97.pzf7p::before{content:'';position:absolute;left:50%;top:-3px;width:20px;height:20px;margin-left:-10px;transform:rotate(45deg);border-radius:4px;background:linear-gradient(135deg,#fff3b0,#e0a52a 55%,#9a5e10);border:2.5px solid #12081f;z-index:2;pointer-events:none}
.pzkc97.pzf7p.sel::before{content:'';left:6px;right:6px;top:2px;width:auto;height:340px;margin:0;transform:none;border-radius:16px;background:none;border:4px solid #ffd45a;box-shadow:0 0 0 3px #12081f,inset 0 0 0 2px #12081f}
.pzkc97 .pzf7pm{position:absolute;left:50%;top:330px;transform:translateX(-50%);padding:1px 6px;border-radius:7px;background:linear-gradient(180deg,#ffe27a,#d69a1e);color:#3a2204;font:800 8.5px/1.3 Poppins,sans-serif;letter-spacing:.08em;border:2px solid #12081f;z-index:3;pointer-events:none;white-space:nowrap}
`;document.head.appendChild(st)}
function pzf7Nav(){const w=$('pzkwall'),s=w&&w.querySelector('.pzkfg.pzf7s');if(!w||!s)return null;let u=w.querySelector('.pzf7nav.u'),d=w.querySelector('.pzf7nav.d');
 if(!u){u=document.createElement('button');u.className='pzf7nav u';u.setAttribute('aria-label','Scroll up');u.textContent='▲';u.onclick=()=>{s.scrollBy({top:-(s.clientHeight-120),behavior:'smooth'});try{pzFx('tick')}catch(e){}};w.appendChild(u);
  d=document.createElement('button');d.className='pzf7nav d';d.setAttribute('aria-label','Scroll down');d.textContent='▼';d.onclick=()=>{s.scrollBy({top:s.clientHeight-120,behavior:'smooth'});try{pzFx('tick')}catch(e){}};w.appendChild(d)}
 const upd=()=>{const max=s.scrollHeight-s.clientHeight;u.classList.toggle('on',max>4&&s.scrollTop>4);d.classList.toggle('on',max>4&&s.scrollTop<max-4)};s.onscroll=upd;upd();return upd}
{const f0=pzRk97Wall;pzRk97Wall=function(){const w0=$('pzkwall'),s0=w0&&PZ.rackTab==='felts'&&w0.querySelector('.pzkfg.pzf7s'),keep=s0?s0.scrollTop:null;const r=f0.apply(this,arguments);try{const w=$('pzkwall');
 if(PZ.rackTab==='felts'&&w){const s=w.querySelector('.pzkfg');if(s){const cards=[...s.querySelectorAll('.pzkfc')];
   cards.forEach(c=>{const it=PZ_FELT.find(x=>x.id===c.dataset.i);if(it&&it.price>0)c.classList.add('pzf7p')});
   if(cards.length>6){s.classList.add('pzf7s');
    /* section labels: the shop and the tables */
    const shop=cards.find(c=>c.classList.contains('pzf7p')),won=cards.find(c=>{const it=PZ_FELT.find(x=>x.id===c.dataset.i);return it&&it.beat&&PZF7_FELTS.includes(it)});
    const lab=(el,t)=>{if(!el)return;const h=document.createElement('div');h.className='pzf7sec';h.textContent=t;s.insertBefore(h,el)};lab(cards[0],'THE HOUSE AND THE TAVERN');lab(shop,'THE SHOP');lab(won,'WON IN THE GILDED HOARD');
    const sel=s.querySelector('.pzkfc.sel');s.style.scrollBehavior='auto';if(keep!=null&&keep>0)s.scrollTop=keep;else if(sel){const a=sel.offsetTop-12;if(a<s.scrollTop||a+sel.offsetHeight>s.scrollTop+s.clientHeight)s.scrollTop=Math.max(0,a-(s.clientHeight-sel.offsetHeight)/2)}s.style.scrollBehavior='';
    const upd=pzf7Nav();if(upd)setTimeout(upd,60)}}}
 if(PZ.rackTab==='cues'&&w){const n=w.querySelectorAll('.pzkc97').length;w.classList.toggle('pzf7many',n>13);w.querySelectorAll('.pzkc97').forEach(c=>{const it=PZ_CUES.find(x=>x.id===c.dataset.i);if(it&&it.prem){c.classList.add('pzf7p');if(!c.querySelector('.pzf7pm')){const m=document.createElement('span');m.className='pzf7pm';m.textContent='PREMIUM';c.appendChild(m)}}});
  const fs=w.querySelector('.pzkc97'),fw=w.querySelector('.pzkgap97+.pzkc97'),hs=w.querySelector('.pzkhead97.s'),hw=w.querySelector('.pzkhead97.w');if(fs&&hs)hs.style.left=(fs.offsetLeft+fs.offsetWidth/2-20)+'px';if(fw&&hw)hw.style.left=(fw.offsetLeft+fw.offsetWidth/2-20)+'px'}}catch(e){console.error(e)}return r}}
/* "Challenge" on a felt from a player of another venue opens that venue's hub (pzHub follows P.pz.venue) */
{const f0=pzRk97Detail;pzRk97Detail=function(){const r=f0.apply(this,arguments);try{const c=$('pzkch'),items=pzRkList(PZ.rackTab),it=items.find(x=>x.id===PZ.rackSel);const who=it&&pzRkWho(it),R=who&&PZ_REG[who];
 if(c&&R&&R.venue)c.onclick=()=>{PZ.sel=who;try{PZS().venue=R.venue;save()}catch(e){}pzGo(pzHub)}}catch(e){console.error(e)}return r}}
/* The Regulars: a card of a player who gives a felt names it (the Orbit 8 style cards of other venues show their own line) */
function pzf7RegFelts(root){(root||ov).querySelectorAll('.pzrg[data-k]').forEach(b=>{if(b.classList.contains('lock'))return;const k=b.dataset.k,f=PZF7_FELTS.find(x=>x.beat===k);if(!f)return;const Z=PZS(),own=!!Z.felts[f.id],txt=`${f.n} felt · ${own?'won':'win once'}`;
 /* the card's own line (if it says something else, e.g. a first-win bonus) stays; the felt gets a line of its own */
 let el=b.querySelector('.pzf7rf');if(!el){const own0=b.querySelector('.pzrgf');if(own0&&!own0.textContent.trim())el=own0;else{el=document.createElement('div');(own0?own0.after(el):b.appendChild(el))}el.classList.add('pzrgf','pzf7rf')}
 if(el.textContent!==txt)el.textContent=txt;el.classList.toggle('on',own)})}
{const f0=pzRegs;pzRegs=function(){const r=f0.apply(this,arguments);try{pzf7RegFelts();if(typeof MutationObserver==='function'){if(PZF7.mo)PZF7.mo.disconnect();
 /* other venues' tabs re-render the cards: keep the felt lines while the screen is open */
 PZF7.mo=new MutationObserver(()=>{if(!ov.querySelector('.pzrg')){PZF7.mo.disconnect();PZF7.mo=null;return}pzf7RegFelts()});PZF7.mo.observe(ov,{childList:true,subtree:true})}}catch(e){console.error(e)}return r}}
/* ---------- the premium cues ---------- */
const PZF7_CUES=[
 {id:'stormcue',n:'Storm Caller',a:'#eef4ff',b:'#a8b4dc',c:'#161c40',d:'#7ae4ff',wrap:'#0a0e26',how:'Cue Rack: 20,000',price:20000,glow:'#8ae8ff',prem:1,inl:'storm'},
 {id:'phoenixcue',n:'Phoenix Feather',a:'#fff2d4',b:'#f0b474',c:'#4a0c06',d:'#ff7a2a',wrap:'#2a0804',how:'Cue Rack: 35,000',price:35000,glow:'#ffa040',prem:1,inl:'phoenix'},
 {id:'hoardcue',n:'Dragon\'s Hoard',a:'#fff6dc',b:'#e8cc86',c:'#3a0a14',d:'#ffd45a',wrap:'#4a0c18',how:'Cue Rack: 60,000',price:60000,glow:'#ffcf5a',prem:1,inl:'hoard'}
];
for(const c of PZF7_CUES)if(!PZ_CUES.some(x=>x.id===c.id)){const i=PZ_CUES.findIndex(x=>x.beat||x.beatShade);PZ_CUES.splice(i<0?PZ_CUES.length:i,0,c)}
/* the forearm inlay and the butt-sleeve motif (96zc geometry: J joint, FA forearm end, x0 near the wrap, x1 near the bumper) */
{const f0=pzCueMotif;pzCueMotif=function(g,sk,x0,x1,wd){if(!sk||!sk.inl)return f0.apply(this,arguments);const L=PZ_CUE.L,J=-L*.58,FA=J-80,n=x0-x1,gold='#e0aa3e';
 const path=(a,b)=>{g.beginPath();g.moveTo(a,-wd(a));g.lineTo(b,-wd(b));g.lineTo(b,wd(b));g.lineTo(a,wd(a));g.closePath()};
 const shade=(a,b,k)=>{g.save();path(a,b);g.clip();for(let x=b;x<a;x+=8){const w=wd(x+4),q=g.createLinearGradient(0,-w,0,w);q.addColorStop(0,`rgba(255,255,255,${.22*k})`);q.addColorStop(.25,`rgba(255,255,255,${.3*k})`);q.addColorStop(.4,'rgba(255,255,255,0)');q.addColorStop(.75,`rgba(0,0,0,${.1*k})`);q.addColorStop(1,`rgba(0,0,0,${.36*k})`);g.fillStyle=q;g.fillRect(x,-9,8.5,18)}g.restore()};
 const dot=(x,y,r,f)=>{g.fillStyle=f;g.beginPath();g.arc(x,y,r,0,TAU);g.fill()};
 const gem=(x,r,col)=>{dot(x,0,r+.55,'#5a3a08');dot(x,0,r,col);dot(x-r*.3,-r*.35,r*.38,'rgba(255,255,255,.85)');dot(x+r*.25,r*.3,r*.22,'rgba(255,255,255,.3)')};
 /* step out of the sleeve clip (96zc saved before clipping), draw the forearm, then clip to the sleeve again for the motif */
 g.restore();g.save();const fa0=FA+.4,fa1=J-4.4;path(fa1,fa0);g.clip();
 const bg=(c0,c1,c2)=>{g.fillStyle=pzLin(g,fa1,0,fa0,0,[[0,c0],[.5,c1],[1,c2]]);g.fillRect(fa0-1,-9,fa1-fa0+2,18)};
 if(sk.inl==='storm'){bg('#22305e','#141c44','#0a0e26');
  /* a storm cloud haze, then a forked bolt with its glow, white-hot core */
  for(let i=0;i<5;i++){const x=fa1-8-i*16;g.fillStyle='rgba(140,170,230,.14)';g.beginPath();g.ellipse(x,(i%2?-1:1)*wd(x)*.55,7,wd(x)*.45,0,0,TAU);g.fill()}
  const P=[];{let x=fa1-1,k=0;while(x>fa0+1){const w=wd(x);P.push([x,(k%2?-.62:.62)*w+(k%3-1)*.25]);x-=5.5+((k*5)%4);k++}P.push([fa0,0])}
  const br=[[P[3],[P[3][0]-6,-wd(P[3][0])*.95]],[P[7],[P[7][0]-5,wd(P[7][0])*.95]],[P[10]||P[P.length-1],[(P[10]||P[P.length-1])[0]-6,-wd(fa0)*.9]]];
  for(const [lw,col] of[[3.4,'rgba(122,228,255,.22)'],[2.0,'rgba(122,228,255,.5)'],[1.1,'#8aeaff'],[.5,'#ffffff']]){g.strokeStyle=col;g.lineWidth=lw;g.beginPath();P.forEach(([x,y],i)=>i?g.lineTo(x,y):g.moveTo(x,y));for(const [a,b] of br){g.moveTo(a[0],a[1]);g.lineTo(b[0],b[1])}g.stroke()}
  for(const x of[fa1-3,fa0+4])gem(x,1.1,'#c8f8ff')}
 else if(sk.inl==='phoenix'){bg('#5a1008','#3a0804','#220402');
  /* layered flame feathers pointing at the tip, each with a gold quill */
  for(let i=7;i>=0;i--){const x=fa0+4+i*10.4,w=wd(x),q=g.createLinearGradient(x,0,x+15,0);q.addColorStop(0,'#a8160c');q.addColorStop(.5,'#ff6a1a');q.addColorStop(1,'#ffd860');g.fillStyle=q;
   g.beginPath();g.moveTo(x+15,0);g.bezierCurveTo(x+9,-w*1.1,x+1,-w*1.05,x-1,-w*.35);g.lineTo(x+3,0);g.lineTo(x-1,w*.35);g.bezierCurveTo(x+1,w*1.05,x+9,w*1.1,x+15,0);g.closePath();g.fill();
   g.strokeStyle='rgba(60,4,0,.55)';g.lineWidth=.45;g.stroke();g.strokeStyle='rgba(255,240,180,.85)';g.lineWidth=.5;g.beginPath();g.moveTo(x+1,0);g.lineTo(x+14,0);g.stroke();
   g.strokeStyle='rgba(120,10,0,.4)';g.lineWidth=.3;for(let k=1;k<4;k++){const xx=x+2+k*3;g.beginPath();g.moveTo(xx,-.3);g.lineTo(xx-2.4,-w*.7);g.moveTo(xx,.3);g.lineTo(xx-2.4,w*.7);g.stroke()}}
  gem(fa1-2,1.05,'#ffd45a')}
 else if(sk.inl==='hoard'){bg('#5a1020','#3a0814','#22040c');
  /* gold filigree: a running scroll above and below the centre line, curls, ruby cabochons */
  g.strokeStyle='#f2c24a';g.lineWidth=.8;for(const s of[1,-1]){g.beginPath();for(let x=fa1;x>=fa0;x-=1.5){const w=wd(x),y=s*(w*.45+Math.sin((fa1-x)*.32)*w*.3);x===fa1?g.moveTo(x,y):g.lineTo(x,y)}g.stroke()}
  for(let x=fa1-6;x>fa0+3;x-=9.8){const w=wd(x);g.strokeStyle='#ffe08a';g.lineWidth=.6;g.beginPath();g.arc(x,-w*.5,w*.24,0,TAU*.8);g.stroke();g.beginPath();g.arc(x-4.9,w*.5,w*.24,Math.PI,Math.PI+TAU*.8);g.stroke()}
  g.fillStyle='#f2c24a';g.fillRect(fa0,-.45,fa1-fa0,.9);for(let x=fa1-10;x>fa0+5;x-=17)gem(x,1.6,'#d01838')}
 shade(fa1,fa0,.75);g.restore();g.save();path(x0+6,x1-11);g.clip();
 /* the butt sleeve motif */
 if(sk.inl==='storm'){g.strokeStyle='#7ae4ff';g.lineWidth=1.1;for(const s of[1,-1]){g.beginPath();let x=x0-2,k=0;g.moveTo(x,s*wd(x)*.15);while(x>x1+3){x-=5;g.lineTo(x,s*wd(x)*(k%2?.75:.15));k++}g.stroke()}
  for(let i=0;i<3;i++){const x=x1+n*(i+.5)/3;gem(x,1.3,'#c8f8ff')}}
 else if(sk.inl==='phoenix'){const w=wd(x1);for(let i=0;i<6;i++){const yc=(i-2.5)*w*.36,len=n*(.5+.35*((i*5)%6)/5);const q=g.createLinearGradient(x1,0,x1+len,0);q.addColorStop(0,'#c81e10');q.addColorStop(.6,'#ff8a2a');q.addColorStop(1,'#ffe27a');g.fillStyle=q;
   g.beginPath();g.moveTo(x1-1,yc-w*.22);g.quadraticCurveTo(x1+len*.6,yc-w*.4,x1+len,yc);g.quadraticCurveTo(x1+len*.6,yc+w*.3,x1-1,yc+w*.22);g.closePath();g.fill()}gem(x0-4,1.4,'#ffd45a')}
 else if(sk.inl==='hoard'){for(let i=0;i<4;i++){const x=x1+n*(i+.5)/4,w=wd(x);dot(x,0,w*.62,'#5a3a08');const q=g.createRadialGradient(x-1,-1,0,x,0,w*.58);q.addColorStop(0,'#fff3b0');q.addColorStop(.6,'#f2b938');q.addColorStop(1,'#a8701a');dot(x,0,w*.56,q);dot(x,0,w*.2,'#d01838')}
  g.fillStyle=gold;g.fillRect(x1,-wd(x1),2,wd(x1)*2);g.fillRect(x0-2,-wd(x0),2,wd(x0)*2)}}}
/* sprites built before this module (none in a normal load) are rebuilt with the inlays */
try{for(const c of PZF7_CUES){for(const k in PZ_CUE.cache)if(k===c.id||k.startsWith(c.id+'@'))delete PZ_CUE.cache[k];if(typeof PZ_UPRIGHT==='object')delete PZ_UPRIGHT[c.id];delete PZ_UP97[c.id]}}catch(e){}
