# python3 t_lant102.py [game.html] : the Phantom Lantern (99c art, 99d battle), a tower of Runestone Tower Defense 10.2.
# Key L, 450 supply, ground and air. Soul wisps home and Haunt (damage over time that ignores armor; refreshes, the strongest lantern
# wins, no stacking); souls of monsters dying in range fill the jar; a full jar sends a phantom knight from the road point nearest the
# lantern toward the spawn, cutting each ground monster once until its will is spent (flyers and hidden monsters are passed); tier 3
# Grave Chill and wisp jumps, tier 4 Spectral Legion, tier 5 the Reaper. Target modes, Overcharge, jams, fog, Glowcaps, roads and
# bridges, the art per tier, frame cost, the info panel, mastery skins, real waves, no page errors.
import asyncio,os,sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:500]),flush=True)
    if not ok:FAIL.append(name)
HELP=r"""()=>{
 window.tdBuild=(R,p,t,tier)=>{rpBuild(p,t);const tw=p.tw;tw.build=1;while(tw.tier<(tier||1)&&rpUpgrade(tw));tw.upK=1;return tw};
 window.tdNew=(map,wave)=>{try{rpLeave()}catch(e){}rpStart(map);const R=RPX;R.tut=null;R.hold=false;R.supply=1e9;R.wst='run';R.wave=wave||1;R.q=[];R.banner=null;R.toast=null;R.foes=[];return R};
 window.tdFoe=(R,id,s,pi)=>{const e=rpSpawn(id,pi||0);e.s=s;e.sp=0;return e};
 window.tdRun=(R,sec)=>{for(let i=0;i<Math.round(sec*30);i++)rpStep(R,1/30)};
 window.tdNear=(R,pad,pi)=>{let best=0,bd=1e9;const P=R.G.paths[pi||0];for(let i=0;i<P.S.length;i++){const q=P.S[i],d=rpD2(q.x,q.y,pad.x,pad.y);if(d<bd){bd=d;best=i*4}}return best};
 window.tdDist=(R,pad,pi)=>{const q=rpAt(R.G,tdNear(R,pad,pi),pi||0);return Math.sqrt(rpD2(q.x,q.y,pad.x,pad.y))};
 window.tdPad=(R)=>{let best=null,bd=1e9;for(const p of R.pads){const d=tdDist(R,p,0);if(d>70&&d<bd&&p.x>250&&p.x<1350){bd=d;best=p}}return best};
 /* a lantern with a full jar */
 window.tdFull=(tw)=>{tw.souls=RP_TW.lant.souls[tw.tier-1];return tw};
 return 1}"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        pg.on('console',lambda m:er.append('console: '+m.text[:300]) if m.type=='error' and 'WebSocket' not in m.text and 'net::' not in m.text else None)
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E("()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const r=RPP();r.new99j=1;r.dragon=1;r.stars=Object.assign(r.stars||{},{moss:3,frost:3,ember:3,coral:3,wreck:3,abyss:3,meadow:3,foundry:3});for(const k in r.tut)r.tut[k]=1;for(const k of['build','wave','coins','upgrade','abil','rune','twist','twist_frost','twist_ember','twist_wonder'])r.tut[k]=1;save()}")
        await E(HELP)
        # ---- data
        r=await E("()=>{const T=RP_TW.lant,i=RP_TWORDER.indexOf('lant');return [i,RP_KEYS[i],RPTW.lant.n,T.cost,T.air,T.ground,T.range,T.dmg,T.cd,T.haunt,T.souls,T.ph,T.will,T.legion,T.up.length,T.desc.length>60,RPSKIN.lant,[1,2,3,4,5].map(t=>rpTowerTop('lant',t)),RP_TWORDER.length]}")
        inc=lambda a:all(a[k]<a[k+1] for k in range(4))
        T=await E("()=>RP_TW.lant")
        chk('the Phantom Lantern is registered: key L, 450 supply, ground and air; every tier hits harder, reaches further, fires faster and grows taller',
            r[0]>=12 and r[0]==r[18]-1 and r[1]=='L' and r[2]=='Phantom Lantern' and r[3]==[450,300,560,1050,1750] and r[4]==1 and r[5]==1 and inc(r[6]) and inc(r[7]) and all(r[8][k]>r[8][k+1] for k in range(4))
            and inc(r[9]) and r[10]==[6,6,6,5,5] and inc(r[11]) and inc(r[12]) and r[13]==[1,1,1,2,2] and r[14]==4 and r[15] and r[16]==['base'] and inc(r[17]),r)
        # ---- hotkey, bar, ring, build, sell
        r=await E("""async()=>{try{rpLeave()}catch(e){}rpStart('moss');const R=RPX;R.tut=null;R.supply=1000;await new Promise(r=>setTimeout(r,700));window.dispatchEvent(new KeyboardEvent('keydown',{key:'l'}));const a=R.place;R.place=null;R.ghost=null;
          const c=document.querySelector('.rpcard[data-tw="lant"]');R.selPad=R.pads[0];await new Promise(r=>setTimeout(r,400));const rb=document.querySelector('#rpring .rprb[data-tw="lant"]');let viaRing=false;
          if(rb){rb.click();viaRing=R.pads[0].tw&&R.pads[0].tw.type==='lant'}if(!R.pads[0].tw)rpBuild(R.pads[0],'lant');const tw=R.pads[0].tw;tw.build=1;const paid=1000-R.supply;
          rpUpgrade(tw);tw.upK=1;const s0=R.supply;rpSell(tw);return [a,!!c,!!rb,viaRing,paid,R.pads[0].tw,Math.round(R.supply-s0)]}""")
        chk('key L picks it, its card is in the tower bar and its button in the build ring builds it for 450; selling refunds 70%',r[:6]==['lant',True,True,True,450,None] and r[6]==round(750*.7),r)
        r=await E("""()=>{const R=RPX;R.ty=R.ty||{};const was=R.ty.on;R.ty.on=true;R.place=null;window.dispatchEvent(new KeyboardEvent('keydown',{key:'l'}));const a=R.place;R.ty.on=was;return a}""")
        chk('with Rune Typing on, L types a letter instead of picking the lantern',r!='lant',r)
        # ---- wisps and haunt
        r=await E("""()=>{const out=[];for(const id of ['golem','gloom']){const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'lant',1),e=tdFoe(R,id,tdNear(R,pad,0));e.hp=e.mx=1e5;e.armor=0;tdRun(R,3.05);
          out.push([e.air,R.lnShots,R.lnHits,Math.round(1e5-e.hp),e.lnH,+e.lnT.toFixed(2),e.lnS===tw])}return out}""")
        chk(f"wisps fly from the keeper, home on ground and air monsters, hit ({T['dmg'][0]} at tier 1) and Haunt them ({T['haunt'][0]} per s for 3 s)",
            all(x[1]>=2 and x[2]>=2 and x[4]==T['haunt'][0] and x[5]>2 and x[6] for x in r) and r[0][3]>=r[0][2]*T['dmg'][0]+T['haunt'][0] and r[1][0]==True,r)
        r=await E("""()=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'lant',3),e=tdFoe(R,'golem',tdNear(R,pad,0));e.hp=e.mx=1e5;e.armor=40;rplnHaunt(e,RP_TW.lant.haunt[2],tw);const h0=e.hp;
          tw.build=0;/* no wisps: only the haunt */tdRun(R,3.5);const hd=h0-e.hp;tw.build=1;const h1=e.hp;rpHurt(e,RP_TW.lant.dmg[2],0,tw);return [+hd.toFixed(1),+(h1-e.hp).toFixed(1)]}""")
        chk(f"the haunt ignores armor ({T['haunt'][2]}/s x 3 s on 40 armor), a wisp does not ({T['dmg'][2]} less 40 armor)",abs(r[0]-3*T['haunt'][2])<1.5 and abs(r[1]-max(T['dmg'][2]*.3,T['dmg'][2]-40))<.5,r)
        r=await E("""()=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'lant',2),e=tdFoe(R,'golem',tdNear(R,pad,0));e.hp=e.mx=1e5;e.armor=0;tw.build=0;
          const H=RP_TW.lant.haunt;rplnHaunt(e,H[1],tw);tdRun(R,1);rplnHaunt(e,H[1],tw);rplnHaunt(e,H[1],tw);const one=[e.lnH,+e.lnT.toFixed(2)];const h0=e.hp;tdRun(R,3.2);const d1=h0-e.hp;
          const R2=tdNew('moss',3),a=tdBuild(R2,R2.pads[0],'lant',1),c=tdBuild(R2,R2.pads[1],'lant',4),f=tdFoe(R2,'golem',300);f.hp=f.mx=1e5;a.build=c.build=0;
          rplnHaunt(f,H[3],c);rplnHaunt(f,H[0],a);const st=[f.lnH,f.lnS===c];tdRun(R2,3.2);rplnHaunt(f,H[0],a);return [...one,+d1.toFixed(1),...st,f.lnH]}""")
        chk('a haunt refreshes but never stacks (three hits from one lantern: still one haunt, 3 s); with two lanterns the stronger haunt stays',
            r[0]==T['haunt'][1] and r[1]==3 and abs(r[2]-3*T['haunt'][1])<1.5 and r[3]==T['haunt'][3] and r[4]==True and r[5]==T['haunt'][0],r)
        # ---- soul harvest
        r=await E("""()=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'lant',1),ba=tdBuild(R,R.pads.find(p=>p!==pad&&!p.tw),'ballista',1),s=tdNear(R,pad,0);tw.build=0;
          const rg=RP_TW.lant.range[0];let far=null;for(let x=0;x<R.G.paths[0].len;x+=8){const q=rpAt(R.G,x,0);if(Math.sqrt(rpD2(q.x,q.y,pad.x,pad.y))>rg*1.3){far=x;break}}tw.build=1;
          const a=tdFoe(R,'scamp',s);rpHurt(a,1e4,99,ba);const b=tdFoe(R,'scamp',far);rpHurt(b,1e4,99,ba);const c=tdFoe(R,'scamp',s);c.s=R.G.paths[0].len+1;tdRun(R,.05);const inc=tw.inc,n0=R.lnSouls.length;
          tdRun(R,2);return [inc,n0,tw.souls,R.lnSoulN,R.leaked]}""")
        chk('a monster killed in range by another tower sends its soul flying to the lantern (the jar fills); one killed out of range or a leak sends none',r[0]==1 and r[1]==1 and r[2]==1 and r[3]==1,r)
        r=await E("""()=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'lant',1),s=tdNear(R,pad,0);for(let k=0;k<10;k++){const f=tdFoe(R,'scamp',s);rpHurt(f,1e4,99,null)}tdRun(R,2.5);return [tw.souls,tw.inc,R.lnSouls.length,tw.ready]}""")
        chk('the jar holds 6 souls at tier 1 (extra souls do not fly in) and the lantern is ready',r==[6,0,0,True],r)
        # ---- phantoms
        r=await E("""()=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdFull(tdBuild(R,pad,'lant',1)),s=tdNear(R,pad,0);const e=tdFoe(R,'golem',Math.max(0,s-300));e.hp=e.mx=1e5;tw.cd=99;
          rpStep(R,1/30);const ph=R.lnPh[0];const a=[R.lnPhN,ph&&ph.pi,ph&&ph.s,s,tw.souls,tw.door>0||tw.dOp>0];tdRun(R,RPLNB.rise+.05);const m=ph.st,s1=ph.s;tdRun(R,1);
          return [...a,m,+(s1-ph.s).toFixed(1)]}""")
        chk('a full jar releases a phantom (the door opens) at the road point nearest the lantern; it rises, then marches toward the spawn at 70 px/s',
            r[0]==1 and r[1]==0 and abs(r[2]-r[3])<=4 and r[4]==0 and r[5] and r[6]=='march' and abs(r[7]-70)<3,r)
        r=await E("""()=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdFull(tdBuild(R,pad,'lant',1)),s=tdNear(R,pad,0);tw.cd=99;const F=[];for(let k=0;k<8;k++){const f=tdFoe(R,'scamp',Math.max(0,s-40-k*30));f.hp=f.mx=1e5;f.armor=10;F.push(f)}
          rpStep(R,1/30);const ph=R.lnPh[0];let st=null;for(let k=0;k<90;k++){rpStep(R,1/30);if(ph.will<=0&&!st)st=ph.st}const d=F.map(f=>Math.round(1e5-f.hp));tdRun(R,1);return [d,st,ph.will,R.lnPh.length,R.lnCuts]}""")
        chk(f"the phantom cuts each ground monster once ({T['ph'][0]} at tier 1, through armor) until its will (4) is spent, then fades",
            r[0]==[T['ph'][0]]*4+[0]*4 and r[1]=='fade' and r[2]==0 and r[3]==0 and r[4]==4,r)
        r=await E("""()=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdFull(tdBuild(R,pad,'lant',1)),s=tdNear(R,pad,0);tw.cd=99;const e=tdFoe(R,'golem',Math.max(0,s-30));e.hp=e.mx=1e5;
          tdRun(R,2.4);e.s=Math.max(0,s-30);/* the same monster walks into the phantom again */const n=R.lnCuts;tdRun(R,.5);return [n,R.lnCuts,Math.round(1e5-e.hp)]}""")
        chk('one monster is cut only once by the same phantom',r[0]==1 and r[1]==1 and r[2]==T['ph'][0],r)
        r=await E("""()=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdFull(tdBuild(R,pad,'lant',1)),s=tdNear(R,pad,0);tw.cd=99;const e=tdFoe(R,'golem',Math.max(0,s-30));e.hp=e.mx=1e5;rpStep(R,1/30);
          e.s=R.G.paths[0].len-1;e.dead=1;const ph=R.lnPh[0];let t=0;while(R.lnPh.length&&t<15){rpStep(R,1/30);t+=1/30}return [+t.toFixed(1),ph.life<=RPLNB.life+.05,ph.s>0]}""")
        chk('with nothing left to cut it fades after at most 8 s of marching',r[0]<=9.5 and r[1],r)
        r=await E("""()=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdFull(tdBuild(R,pad,'lant',1)),s=tdNear(R,pad,0);tw.cd=99;const a=tdFoe(R,'gloom',Math.max(0,s-80));a.hp=a.mx=1e5;tdRun(R,.5);const none=[R.lnPhN,tw.souls,tw.ready];
          const g=tdFoe(R,'golem',Math.max(0,s-200));g.hp=g.mx=1e5;const h=tdFoe(R,'golem',Math.max(0,s-60));h.hp=h.mx=1e5;h.hide=1;const f2=tdFoe(R,'gloom',Math.max(0,s-30));f2.hp=f2.mx=1e5;tdRun(R,5);
          return [...none,R.lnPhN,Math.round(1e5-a.hp)>0,Math.round(1e5-f2.hp),Math.round(1e5-h.hp),Math.round(1e5-g.hp)]}""")
        chk('no release while only flyers are coming (the jar stays full); a phantom passes under flyers and leaves hidden monsters alone',
            r[0]==0 and r[1]==6 and r[2]==True and r[3]==1 and r[6]==0 and r[7]==T['ph'][0],r)
        # ---- roads: two roads, bridges, the switch track
        r=await E("""()=>{const R=tdNew('frost',3);let best=null;for(const p of R.pads){const d0=tdDist(R,p,0),d1=tdDist(R,p,1);if(d1<200&&d0>d1+60&&(!best||d1<best[1]))best=[p,d1,d0]}if(!best)return 'no pad';const pad=best[0];
          const tw=tdFull(tdBuild(R,pad,'lant',1));tw.cd=99;const s1=tdNear(R,pad,1);const e=tdFoe(R,'golem',Math.max(0,s1-150),1);e.hp=e.mx=1e5;const o=tdFoe(R,'golem',Math.max(0,tdNear(R,pad,0)-60),0);o.hp=o.mx=1e5;
          rpStep(R,1/30);const ph=R.lnPh[0];let maxOff=0;for(let k=0;k<120;k++){rpStep(R,1/30);if(ph.st==='march'){const q=rpAt(R.G,ph.s,1);maxOff=Math.max(maxOff,Math.hypot(q.x-ph.x,q.y-ph.y))}}
          return [ph.pi,0,Math.round(1e5-e.hp),Math.round(1e5-o.hp),+maxOff.toFixed(1),Math.round(best[1]),Math.round(best[2])]}""")
        chk('on a map with two roads the phantom takes the road with monsters coming (road 2 here), stays on it and leaves the other road alone',r!='no pad' and r[0]==1 and r[2]==T['ph'][0] and r[3]==0 and r[4]<1,r)
        r=await E("""()=>{const R=tdNew('meadow',3),B=R.map.bridge;let best=null;for(const p of R.pads){if(tdDist(R,p,0)>200)continue;const s=tdNear(R,p,0);for(const z of B){/* a bridge on the road behind the pad's road point */for(let x=s-40;x>Math.max(0,s-400);x-=8){const q=rpAt(R.G,x,0);if(Math.hypot(q.x-z[0],q.y-z[1])<z[2]*.5){if(!best||s-x<best[2])best=[p,z,s-x,x];break}}}}
          if(!best)return 'no bridge';const [pad,z,gap,xs]=best;const tw=tdFull(tdBuild(R,pad,'lant',1));tw.cd=99;const e=tdFoe(R,'golem',Math.max(0,xs-40));e.hp=e.mx=1e5;rpStep(R,1/30);const ph=R.lnPh[0];
          let on=0,maxOff=0;for(let k=0;k<30*9&&ph.st!=='fade';k++){rpStep(R,1/30);if(ph.st==='march'){const q=rpAt(R.G,ph.s,0);maxOff=Math.max(maxOff,Math.hypot(q.x-ph.x,q.y-ph.y));if(Math.hypot(ph.x-z[0],ph.y-z[1])<z[2])on++}}
          return [Math.round(gap),on>0,+maxOff.toFixed(1),Math.round(1e5-e.hp)]}""")
        chk('on Cloudspire Meadows the phantom walks over a rope bridge along the road and cuts the monster beyond it',r!='no bridge' and r[1] and r[2]<1 and r[3]==T['ph'][0],r)
        r=await E("""()=>{const R=tdNew('foundry',3);R.sw=1;let best=null;for(const p of R.pads){const d1=tdDist(R,p,1),d0=tdDist(R,p,0);if(d1<200&&(!best||d1-d0<best[1]))best=[p,d1-d0]}const pad=best[0];
          const tw=tdFull(tdBuild(R,pad,'lant',1));tw.cd=99;const s1=tdNear(R,pad,1);const e=rpSpawn('golem');e.s=Math.max(0,s1-120);e.sp=0;e.hp=e.mx=1e5;rpStep(R,1/30);const ph=R.lnPh[0];tdRun(R,3);return [e.pi,ph&&ph.pi,Math.round(1e5-e.hp)]}""")
        chk('Gearworks Foundry: with the switch on the south line the phantom follows that line',r==[1,1,T['ph'][0]],r)
        # ---- tier 3, 4, 5
        r=await E("""()=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdFull(tdBuild(R,pad,'lant',3)),s=tdNear(R,pad,0);tw.cd=99;const a=tdFoe(R,'golem',Math.max(0,s-40));a.hp=a.mx=1e5;const b=tdFoe(R,'golem',Math.max(0,s-90));b.hp=b.mx=1e5;b.slowK=.6;b.slowT=5;
          const c=tdFoe(R,'golem',Math.max(0,s-140));c.hp=c.mx=1e5;c.vent=9;tdRun(R,1.05);const at=a.slowT;tdRun(R,1.55);const ch=[a.slowK,at>1.6&&at<=2,b.slowK,c.slowK||0,Math.round(1e5-c.hp)];
          const R2=tdNew('moss',3),t2=tdBuild(R2,R2.pads[pad.i],'lant',3),x=tdFoe(R2,'golem',s),y=tdFoe(R2,'golem',s+60);x.hp=x.mx=y.hp=y.mx=1e5;x.armor=y.armor=0;t2.prio='first';tdRun(R2,1.5);
          return [...ch,R2.lnJumps>0,Math.round(1e5-x.hp)>0&&Math.round(1e5-y.hp)>0]}""")
        chk('tier 3 Grave Chill: cut monsters are chilled 30% for 2 s (a stronger slow stays, a venting golem is immune) and wisps jump to a second monster',
            r[0]==.3 and r[1] and r[2]==.6 and r[3]==0 and r[4]==T['ph'][2] and r[5] and r[6],r)
        r=await E("""()=>{const R=tdNew('wonder',30),pad=tdPad(R),tw=tdFull(tdBuild(R,pad,'lant',4)),s=tdNear(R,pad,0);tw.cd=99;const F=[];for(let k=0;k<10;k++){const f=tdFoe(R,'golem',Math.max(0,s-30-k*25));f.hp=f.mx=1e6;F.push(f)}
          rpStep(R,1/30);const n=R.lnPh.length,w=R.lnPh.map(p=>p.will);tdRun(R,6);return [n,w,R.lnPhN,R.lnCuts,Math.max(...F.map(f=>Math.round((1e6-f.hp)/RP_TW.lant.ph[3])))]}""")
        chk(f"tier 4 Spectral Legion: every release sends two phantoms (7 will each, {T['ph'][3]} a cut); a monster can be cut once by each",r[0]==2 and r[1]==[7,7] and r[2]==1 and r[3]==14 and r[4]==2,r)
        r=await E("""()=>{const R=tdNew('wonder',30),pad=tdPad(R),tw=tdBuild(R,pad,'lant',5),s=tdNear(R,pad,0);tw.cd=99;const kinds=[];
          for(let k=0;k<3;k++){tdFull(tw);tw.relCd=0;const f=tdFoe(R,'golem',Math.max(0,s-150));f.hp=f.mx=1e7;rpStep(R,1/30);kinds.push(R.lnPh.filter(p=>p.wait<=0&&p.st==='rise'&&p.t<.1).map(p=>p.kind).join('+'));R.lnPh.length=0;f.dead=1;tdRun(R,.1)}
          R.foes=[];R.lnPh.length=0;tw.rel=2;tdFull(tw);tw.relCd=0;const e=tdFoe(R,'golem',Math.max(0,s-60));e.mx=2e4;e.hp=e.mx*.16;e.armor=0;const bo=tdFoe(R,'behemoth',Math.max(0,s-110));bo.hp=bo.mx=1e6;bo.armor=0;
          tdRun(R,3);return [kinds,e.dead?1:0,R.lnFin,Math.round(1e6-bo.hp)]}""")
        chk('tier 5 The Reaper: every third release is the Reaper (with a knight); it finishes a non-boss left below 15% and cuts a boss three times as hard',
            r[0][2].startswith('reaper') and 'reaper' not in r[0][0] and 'reaper' not in r[0][1] and r[1]==1 and r[2]==1 and r[3]>=round(T['ph'][4]*1.6*3)-1,r)
        # ---- target modes, Overcharge, jam, fog, Glowcap
        r=await E("""()=>{const res={};for(const pr of ['first','strong','close']){const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'lant',1),s=tdNear(R,pad,0);tw.prio=pr;tw.souls=0;
           const a=tdFoe(R,'golem',s+70),b=tdFoe(R,'golem',s-80),c=tdFoe(R,'golem',s);a.hp=a.mx=5e4;b.hp=b.mx=9e4;c.hp=c.mx=4e4;for(const e of [a,b,c])e.armor=0;tw.cd=0;rpStep(R,1/30);const w=R.lnWisps[0];
           const da=Math.sqrt(rpD2(rpPos(R,a).x,rpPos(R,a).y,pad.x,pad.y)),dc=Math.sqrt(rpD2(rpPos(R,c).x,rpPos(R,c).y,pad.x,pad.y)),db=Math.sqrt(rpD2(rpPos(R,b).x,rpPos(R,b).y,pad.x,pad.y));
           res[pr]=w?(w.e===a?'a':w.e===b?'b':'c'):null;res.close_ok=dc<=Math.min(da,db)}return res}""")
        chk('Target modes: First takes the monster furthest along, Strong the toughest, Close the nearest',r['first']=='a' and r['strong']=='b' and r['close']=='c',r)
        r=await E("""()=>{const l0=rplnLaunch;let last=0;rplnLaunch=function(R,tw,e,dmg){last=dmg;return l0.apply(this,arguments)};try{const run=(over)=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'lant',1),e=tdFoe(R,'golem',tdNear(R,pad,0));e.hp=e.mx=1e7;e.armor=0;tdRun(R,2);const n0=R.lnShots;if(over)tw.over=20;tdRun(R,8);
           return [R.lnShots-n0,last]};const a=run(0),b=run(1);return [a[0],b[0],+(b[0]/a[0]).toFixed(2),+(b[1]/RP_TW.lant.dmg[0]).toFixed(3),RPT.AB.over.k]}finally{rplnLaunch=l0}}""")
        chk('Overcharge: wisps come about RPT.AB.over.k times faster and hit 15% harder',abs(r[2]-r[4])<.45 and abs(r[3]-1.15)<1e-6,r)
        r=await E("""()=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'lant',2),s=tdNear(R,pad,0),e=tdFoe(R,'golem',s);e.hp=e.mx=1e7;tdRun(R,1.5);tw.jam=3;tw.jamBy='emp';tdFull(tw);const f=tdFoe(R,'golem',Math.max(0,s-100));f.hp=f.mx=1e7;
          const n0=R.lnShots;tdRun(R,2.8);const a=[R.lnShots-n0,R.lnPhN,tw.ready];tdRun(R,1.5);return [...a,R.lnShots-n0>0,R.lnPhN]}""")
        chk('a jam stops the wisps and the phantom release; both come back when it ends',r[0]==0 and r[1]==0 and r[2] and r[3] and r[4]==1,r)
        r=await E("""()=>{const R=tdNew('wreck',3);let pad=null,s=0;for(const p of R.pads){for(let x=60;x<R.G.paths[0].len;x+=8){const q=rpAt(R.G,x,0),d=Math.sqrt(rpD2(q.x,q.y,p.x,p.y));if(d>170&&d<200){pad=p;s=x;break}}if(pad)break}
          const tw=tdBuild(R,pad,'lant',1),e=tdFoe(R,'golem',s);e.hp=e.mx=1e7;const q=rpPos(R,e);R.fog=[{x:q.x,y:q.y,rx:60,ry:40,v:0}];R.cannon=null;tdRun(R,2);const fog=R.lnShots;R.fog=[];tdRun(R,2);
          return [Math.round(Math.sqrt(rpD2(q.x,q.y,pad.x,pad.y))),R.map.fogNear,fog,R.lnShots]}""")
        chk('fog (Shipwreck Cove): a fogged monster further than fogNear from the lantern is not targeted; out of the fog it is',r[2]==0 and r[3]>0,r)
        r=await E("""()=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'lant',1),rg=RP_TW.lant.range[0];let s1=null;for(let x=0;x<R.G.paths[0].len;x+=3){const q=rpAt(R.G,x,0),d=Math.sqrt(rpD2(q.x,q.y,pad.x,pad.y));if(d>rg*1.04&&d<rg*1.1){s1=x;break}}
          const e=tdFoe(R,'golem',s1);e.hp=e.mx=1e7;tdRun(R,2);const a=R.lnShots;tw.glowK=1.15;tdRun(R,2);const b=R.lnShots;rpHurt(e,1e8,99,null);tdRun(R,1.5);return [a,b,tw.inc+tw.souls]}""")
        chk('a Glowcap (tw.glowK 1.15) stretches its reach for wisps and for the harvest',r[0]==0 and r[1]>0 and r[2]==1,r)
        # ---- art
        r=await E("""()=>{const out=[];for(let t=1;t<=5;t++){const c=document.createElement('canvas');c.width=c.height=260;const g=c.getContext('2d');g.translate(130,200);rpTowerDraw(g,'lant',t,'base',1,{});
           const d=g.getImageData(0,0,260,260).data;let n=0;for(let i=3;i<d.length;i+=4)if(d[i]>20)n++;out.push([n,c.toDataURL().length])}
          const keys=[...RPSPR.keys()].filter(k=>k.startsWith('ln|')||k.startsWith('tw|lant|'));const ic=rpTowerIcon('lant',1,'base',96);return [out.map(x=>x[0]),new Set(out.map(x=>x[1])).size,ic.width,keys.length]}""")
        chk('every tier draws differently and grander (tier 5 fuller than tier 3, tier 3 than tier 1), baked into sprites; the icon renders',r[1]==5 and r[0][2]>r[0][0] and r[0][4]>r[0][2] and r[2]==96 and r[3]>=20,r)
        r=await E("""()=>{const out=[];for(const [t,d,j,rd] of [[0,0,.2,0],[.9,.6,.5,1],[1.8,1,1,1]]){const c=document.createElement('canvas');c.width=c.height=220;const g=c.getContext('2d');g.translate(110,180);RPLN.cur={type:'lant',door:d,jarK:j,ready:rd,swk:0};try{rpTowerDraw(g,'lant',3,'base',t,{fire:t>1?1:0})}finally{RPLN.cur=null}out.push(c.toDataURL().length)}
          const R=tdNew('moss',3);rpTowerWarm('lant',5,'base');let bad=0;for(const k of ['ln|kn|5','ln|rp|5','ln|sc|5','ln|w|5','ln|s|5','ln|lt|5|base','ln|dr|5|base'])if(!RPSPR.get(k))bad++;return [new Set(out).size,bad]}""")
        chk('the lantern is alive (sway, flicker, jar, door, glow change) and warming bakes the phantom, Reaper, wisp, soul, lantern and door sprites',r==[3,0],r)
        r=await E("""()=>{if(typeof RPG!=='undefined')RPG.off=1;const c=document.createElement('canvas');c.width=1600;c.height=900;const g=c.getContext('2d');for(let t=1;t<=5;t++){rpTowerWarm('lant',t,'base');rpTowerWarm('star',t,'base')}
          const best=f=>{let m=1e9;for(let k=0;k<7;k++){const t0=performance.now();for(let i=0;i<8;i++)f(i);m=Math.min(m,(performance.now()-t0)/8)}return m};
          const row=ty=>best(f=>{for(let t=1;t<=5;t++){g.save();g.translate(100+t*200,400);if(ty==='lant')RPLN.cur={type:'lant',door:(f%4)/4,jarK:(f%8)/8,ready:f%2,swk:.1};rpTowerDraw(g,ty,t,'base',f/30,{aim:.3,fire:f%3?0:1});RPLN.cur=null;g.restore()}})/5;
          let ln=1e9,sf=1e9;for(let k=0;k<3;k++){ln=Math.min(ln,row('lant'));sf=Math.min(sf,row('star'))}if(typeof RPG!=='undefined')RPG.off=0;return [+ln.toFixed(3),+sf.toFixed(3),!!RPG_SRC.lant&&RPG_SRC.lant.length===6,!!RPG_PAR.lant]}""")
        print('  one lantern, ms per frame [lantern, observatory]:',r[:2])
        chk('frame cost: one lantern draws in about 0.15 ms (or no more than the Starfall Observatory on a busy machine); it is in the 9.9p glow layer',(r[0]<0.16 or r[0]<=1.3*r[1]) and r[2] and r[3],r)
        r=await E("""()=>{const R=tdNew('wonder',40);const pads=R.pads.slice(0,6);for(const p of pads)tdBuild(R,p,'lant',5);for(let k=0;k<24;k++){const f=tdFoe(R,k%3?'golem':'gloom',150+k*60,k%2);f.hp=f.mx=1e7}tdRun(R,2);
          for(const p of pads){tdFull(p.tw);p.tw.rel=2}tdRun(R,1.6);for(let k=0;k<20;k++){const e=R.foes[k];if(e&&!e.dead)rpKillFoe(e,null)}tdRun(R,.3);const n=[R.lnPh.length,R.lnWisps.length,R.lnSouls.length];
          const c=document.createElement('canvas').getContext('2d');c.canvas.width=1600;c.canvas.height=900;
          const layer=()=>{R.t+=1/30;rpBeamsDraw(c,R)};const base=()=>{const a=[R.lnPh,R.lnWisps,R.lnSouls,R.lnFx];R.lnPh=[];R.lnWisps=[];R.lnSouls=[];R.lnFx=[];try{rpBeamsDraw(c,R)}finally{[R.lnPh,R.lnWisps,R.lnSouls,R.lnFx]=a}};
          const best=f=>{let m=1e9;for(let k=0;k<7;k++){const t0=performance.now();for(let i=0;i<8;i++)f();m=Math.min(m,(performance.now()-t0)/8)}return m};
          let full=1e9,ref=1e9;for(let k=0;k<4;k++){full=Math.min(full,best(layer));ref=Math.min(ref,best(base))}R.lite=1;const lite=best(layer);R.lite=0;
          return [...n,+(full-ref).toFixed(3),+lite.toFixed(3),+full.toFixed(3)]}""")
        print('  six tier 5 lanterns [phantoms, wisps, souls, extra ms, lite ms, full ms]:',r)
        chk('frame cost: six tier 5 lanterns with their phantoms (Reapers too), wisps and souls add well under a millisecond; Performance mode draws less',
            r[0]>=8 and r[1]+r[2]>=6 and r[3]<1.0 and r[4]<=r[5]*1.05,r)
        # ---- info panel, help, mastery
        r=await E("""async()=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'lant',3);tw.souls=2;tdFoe(R,'golem',300);R.sel=tw;await new Promise(r=>setTimeout(r,400));const el=document.getElementById('rpinfo');
          const t=el?el.textContent:'';const b=el.getBoundingClientRect();tw.souls=5;await new Promise(r=>setTimeout(r,300));const t2=document.getElementById('rplnsl').textContent;
          return [/Wisp damage/.test(t),/Phantom/.test(t),/haunt/.test(t),/ignores armor/.test(t),/Phantom Lantern/.test(t),/2 \\/ 6/.test(t),t2,/Grave Chill/.test(t),b.bottom<=780,b.top>=70,el.querySelectorAll('.rppri button').length]}""")
        chk('the info panel shows wisp damage, phantom, haunt, the soul count (live), Grave Chill and the target buttons, inside the stage',r[:6]==[True]*6 and r[6]=='5 / 6' and r[7] and r[8] and r[9] and r[10]==3,r)
        r=await E("""async()=>{try{rpLeave()}catch(e){}rampartsMenu(title);await new Promise(r=>setTimeout(r,500));let ok=false;try{rpHowTo();const w=ov.querySelector('#rpmod .rphw');ok=!!w&&/Phantom Lantern\\./.test(w.textContent)&&/key L/.test(w.textContent)}catch(e){}
          const h=HELP.Modes.find(x=>x[0]==='Runestone Tower Defense');return [ok,!!h&&h[1].includes('Phantom Lantern (L, 450 supply)')]}""")
        chk('How to Play and the Help text describe the Phantom Lantern',r==[True,True],r)
        r=await E("""()=>{const S=RPY_SET.lant;const ok=S&&S.length===5&&S.every(x=>RPY_TH[x[0]]);const c=document.createElement('canvas');c.width=c.height=200;const g=c.getContext('2d');g.translate(100,170);
          const urls=[];for(const k of ['base','m1','m5']){g.clearRect(-100,-170,200,200);rpTowerDraw(g,'lant',3,k,1,{});urls.push(c.toDataURL().length)}const r=RPP();rpyXP('lant');r.mast.lant=RPY_LV[5];rpySync();
          return [ok,new Set(urls).size,!!r.own['lant:m5'],rpySet('lant')[4][1]]}""")
        r2=await E("""async()=>{try{rpLeave()}catch(e){}rampartsMenu(title);await new Promise(r=>setTimeout(r,400));let n=0;try{rpSkins();await new Promise(r=>setTimeout(r,500));n=document.querySelectorAll('.rpcsn[data-tw="lant"]').length;
          const b=document.querySelector('.rpcsn[data-tw="lant"]');if(b)b.click();await new Promise(r=>setTimeout(r,400))}catch(e){return 'err '+e}return [n,/Phantom Lantern/.test(document.body.textContent)]}""")
        chk('five mastery skins (RPY_SET.lant) recolour it, unlock with mastery and show on the Tower Skins screen',r[0] and r[1]==3 and r[2] and r2==[1,True],[r,r2])
        # ---- real waves
        r=await E("""()=>{const R=tdNew('moss',6);R.wst='build';const pads=[...R.pads].sort((a,b)=>a.i-b.i);tdBuild(R,pads[2],'lant',3);tdBuild(R,pads[5],'lant',3);tdBuild(R,pads[7],'ballista',3);tdBuild(R,pads[9],'lant',2);R.cd=0;rpWaveStart();let t=0;
          while(R.wst==='run'&&t<240){rpStep(R,1/30);t+=1/30}return [R.wst,R.hp>0,R.lnHits>20,R.lnSoulN>0,R.lnPhN>0,R.foes.filter(e=>!e.dead&&!isFinite(e.hp)).length,R.lnPh.every(p=>isFinite(p.x)&&isFinite(p.s))]}""")
        chk('a real wave with three lanterns ends cleanly: wisps hit, souls fly in, phantoms march',r[0]=='build' and r[1] and r[2] and r[3] and r[4] and r[5]==0 and r[6],r)
        r=await E("""()=>{const R=tdNew('wonder',30);R.wst='build';for(const p of R.pads.slice(0,5))tdBuild(R,p,'lant',5);for(const p of R.pads.slice(5,9))tdBuild(R,p,'prism',4);R.cd=0;rpWaveStart();let t=0;
          while(R.wst==='run'&&t<300){rpStep(R,1/30);t+=1/30}rpDraw();return [R.wst,R.hp>0,R.lnPhN>0,R.lnCuts>0,R.lnHits>0]}""")
        chk('a Wonderland wave with tier 5 lanterns ends cleanly and their phantoms cut',r[0]=='build' and r[1] and r[2] and r[3] and r[4],r)
        await pg.screenshot(path=os.path.join(HERE,'shots','lant_test.png'))
        chk('no page errors',not er,er[:3])
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
