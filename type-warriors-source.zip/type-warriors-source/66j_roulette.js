/* ---------- roulette: European wheel, one zero ---------- */
const ROR=new Set([1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36]),ROW=[0,32,15,19,4,21,2,25,17,34,6,27,13,36,11,30,8,23,10,5,24,16,33,1,20,14,31,9,22,18,29,7,28,12,35,3,26];
const roCol=n=>n===0?'#1a8a4a':ROR.has(n)?'#b8202e':'#16161f';
const roChip=a=>a>=5000?'v5':a>=1000?'v4':a>=500?'v3':a>=100?'v2':a>=50?'v1':'v0';
function roWheelArt(){/* static layers painted once: back (wood, track), wheel face (rotates), front (glass shine, studs) */
 const N=440,c=N/2,a=TAU/37,back=cdMk(N,N),face=cdMk(N,N),front=cdMk(N,N);
 let g=back.getContext('2d');
 g.fillStyle='#00000066';g.beginPath();g.ellipse(c,c+10,214,206,0,0,TAU);g.fill();
 let q=g.createRadialGradient(c-60,c-70,40,c,c,218);q.addColorStop(0,'#9a6428');q.addColorStop(.6,'#5a3412');q.addColorStop(1,'#2a1606');g.fillStyle=q;g.beginPath();g.arc(c,c,216,0,TAU);g.fill();
 for(let i=0;i<60;i++){g.strokeStyle='rgba(0,0,0,'+(.05+rnd(i)*.08)+')';g.lineWidth=1;g.beginPath();g.arc(c,c,150+rnd(i+7)*64,rnd(i)*TAU,rnd(i)*TAU+.8+rnd(i+3));g.stroke()}
 g.lineWidth=5;g.strokeStyle=hgr(g,0,N,'#fff2a8','#a8700c');g.beginPath();g.arc(c,c,208,0,TAU);g.stroke();g.lineWidth=2;g.strokeStyle='#3a2006';g.beginPath();g.arc(c,c,211.5,0,TAU);g.stroke();
 q=g.createRadialGradient(c,c,164,c,c,202);q.addColorStop(0,'#1c1208');q.addColorStop(.5,'#3a2a18');q.addColorStop(1,'#120a04');g.fillStyle=q;g.beginPath();g.arc(c,c,203,0,TAU);g.fill();
 g.lineWidth=3;g.strokeStyle='#d8b868';g.beginPath();g.arc(c,c,196,0,TAU);g.stroke();g.lineWidth=1.5;g.strokeStyle='#8a6a30';g.beginPath();g.arc(c,c,171,0,TAU);g.stroke();
 g=face.getContext('2d');g.translate(c,c);
 for(let i=0;i<37;i++){const n=ROW[i],a0=i*a-a/2,a1=i*a+a/2;g.fillStyle=roCol(n);g.beginPath();g.arc(0,0,167,a0,a1);g.arc(0,0,118,a1,a0,true);g.closePath();g.fill()}
 for(let i=0;i<37;i++){const n=ROW[i];g.save();g.rotate(i*a);const sh=g.createLinearGradient(118,0,167,0);sh.addColorStop(0,'rgba(0,0,0,.45)');sh.addColorStop(.3,'rgba(255,255,255,.07)');sh.addColorStop(1,'rgba(0,0,0,.25)');g.fillStyle=sh;g.beginPath();g.moveTo(118,-a*76);g.lineTo(167,-a*76);g.arc(0,0,167,-a/2,a/2);g.arc(0,0,118,a/2,-a/2,true);g.restore()}
 for(let i=0;i<37;i++){g.save();g.rotate(i*a-a/2);const f=g.createLinearGradient(0,-1.5,0,1.5);f.addColorStop(0,'#fff6c0');f.addColorStop(1,'#a8801c');g.fillStyle=f;g.fillRect(118,-1.4,49,2.8);g.restore()}
 for(let i=0;i<37;i++){g.save();g.rotate(i*a);g.translate(147,0);g.rotate(Math.PI/2);g.fillStyle='#fff';g.shadowColor='#000';g.shadowBlur=3;g.font='700 14px Georgia,serif';g.textAlign='center';g.textBaseline='middle';g.fillText(ROW[i],0,0);g.restore()}
 g.shadowBlur=0;g.lineWidth=4;g.strokeStyle='#e8c660';g.beginPath();g.arc(0,0,168,0,TAU);g.stroke();g.lineWidth=3;g.beginPath();g.arc(0,0,117,0,TAU);g.stroke();
 q=g.createRadialGradient(-20,-24,6,0,0,118);q.addColorStop(0,'#8a5a22');q.addColorStop(.55,'#4a2c10');q.addColorStop(1,'#1e1006');g.fillStyle=q;g.beginPath();g.arc(0,0,116,0,TAU);g.fill();
 for(let i=0;i<8;i++){g.save();g.rotate(i*TAU/8);g.strokeStyle='rgba(255,220,140,.14)';g.lineWidth=2;g.beginPath();g.moveTo(26,0);g.lineTo(110,0);g.stroke();g.fillStyle='#d8b050';g.beginPath();g.arc(98,0,3.6,0,TAU);g.fill();g.restore()}
 for(let k=0;k<4;k++){g.save();g.rotate(k*TAU/4);const sp=g.createLinearGradient(0,-5,0,5);sp.addColorStop(0,'#fff2a8');sp.addColorStop(.5,'#d8a018');sp.addColorStop(1,'#7a4a08');g.fillStyle=sp;g.beginPath();g.roundRect(14,-4.5,66,9,4.5);g.fill();g.fillStyle='#ffe490';g.beginPath();g.arc(82,0,8,0,TAU);g.fill();g.fillStyle='#a8701c';g.beginPath();g.arc(82,0,4,0,TAU);g.fill();g.restore()}
 q=g.createRadialGradient(-5,-6,2,0,0,22);q.addColorStop(0,'#fffbe0');q.addColorStop(.5,'#e8b02a');q.addColorStop(1,'#7a4a08');g.fillStyle=q;g.beginPath();g.arc(0,0,20,0,TAU);g.fill();g.strokeStyle='#4a2c04';g.lineWidth=1.5;g.stroke();
 g=front.getContext('2d');
 for(let i=0;i<8;i++){const an=i*TAU/8+Math.PI/8,x=c+Math.cos(an)*183,y=c+Math.sin(an)*183;g.save();g.translate(x,y);g.rotate(an+Math.PI/4);const dg=g.createLinearGradient(-6,-6,6,6);dg.addColorStop(0,'#fff2b0');dg.addColorStop(1,'#a8701c');g.fillStyle=dg;g.fillRect(-5,-5,10,10);g.strokeStyle='#3a2006';g.lineWidth=1;g.strokeRect(-5,-5,10,10);g.restore()}
 q=g.createRadialGradient(c-70,c-90,10,c-30,c-40,210);q.addColorStop(0,'rgba(255,255,255,.2)');q.addColorStop(.35,'rgba(255,255,255,.05)');q.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=q;g.beginPath();g.arc(c,c,200,0,TAU);g.fill();
 g.strokeStyle='rgba(255,255,255,.18)';g.lineWidth=5;g.lineCap='round';g.beginPath();g.arc(c,c,190,Math.PI*1.12,Math.PI*1.42);g.stroke();
 return{back,face,front}}
let RO_ART=null;
function mRO(el,tok){
 const alive=()=>CAS.tok===tok,N=440,c=N/2,a=TAU/37;if(!RO_ART)RO_ART=roWheelArt();const ART=RO_ART;
 let bets={},stack=[],lastBets=null,st='idle',stake=0,rot=Math.random()*TAU,wv=.2,anim=null,res=[],cur=null,landT=0,hot=null,lastPay=0;
 const parts=[],trail=[];let lastTick=-1,tNow=performance.now();
 const num=(n,r,cc)=>`<button class="rc ${n===0?'gr':ROR.has(n)?'rd':'bl'}" data-k="n${n}" style="grid-row:${r};grid-column:${cc}${n===0?';grid-row:1/4':''}">${n}</button>`;
 let gh=num(0,1,1);for(let q=0;q<12;q++)for(let r=0;r<3;r++)gh+=num(3*q+(3-r),r+1,q+2);
 for(let i=0;i<3;i++)gh+=`<button class="rc ot" data-k="d${i+1}" style="grid-row:4;grid-column:${2+i*4}/${6+i*4}">${['1st 12','2nd 12','3rd 12'][i]}</button>`;
 [['lo','1 to 18'],['even','Even'],['red','Red'],['black','Black'],['odd','Odd'],['hi','19 to 36']].forEach((q,i)=>gh+=`<button class="rc ot ${q[0]==='red'?'rd':q[0]==='black'?'bl':''}" data-k="${q[0]}" style="grid-row:5;grid-column:${2+i*2}/${4+i*2}">${q[1]}</button>`);
 el.innerHTML=`<div class="felt rlw" style="flex-direction:row;gap:30px;padding:14px 24px"><div class="rwh"><canvas id="rw" width="${N}" height="${N}"></canvas></div><div style="display:flex;flex-direction:column;gap:10px;align-items:center"><div class="rgrid">${gh}</div><div class="rhist"><small>Last numbers</small><div class="rres" id="rr"></div></div></div></div>
<p class="cmsg" id="cm"> </p><div class="ctl">${betBar('Chip')}<div class="msi" style="min-width:150px;align-items:center;font-size:18px"><span>On table <b id="rs">0</b></span></div><div class="btns"><button class="sm" id="rud" title="Remove the last chip (Z)">Undo</button><button class="sm" id="rrp" title="Place your previous bets again (R)">Repeat</button><button class="sm" id="rcl" title="Clear the table (C)">Clear</button><button class="bbig" id="rsp" style="min-width:200px">Spin</button></div></div>`;
 const tot=()=>Object.values(bets).reduce((x,y)=>x+y,0);
 const refresh=()=>{$('rud').disabled=st!=='idle'||!stack.length;$('rcl').disabled=st!=='idle'||!stack.length;$('rrp').disabled=st!=='idle'||!lastBets||!!stack.length;$('rsp').disabled=st!=='idle'};
 const paint=win=>{ov.querySelectorAll('.rc').forEach(b=>{const k=b.dataset.k,v=bets[k];let cb=b.querySelector('.cb');if(v){if(!cb){cb=document.createElement('span');b.appendChild(cb)}cb.className='cb '+roChip(v);cb.textContent=cab(v)}else if(cb)cb.remove();b.classList.toggle('win',!!(win&&v&&roWin(k,win.n)));b.classList.toggle('hit',!!(win&&b.dataset.k==='n'+win.n))});$('rs').textContent=cmn(tot());refresh()};
 const place=k=>{if(st!=='idle'||CAS.lock)return;const v=CAS.bet;if(v<1){msg(broke()||'Pick a chip size first.');return}if(tot()+v>P.gold){msg('Not enough gold for another chip.');return}if(tot()+v>CAS_MAX){msg('Table limit: '+cmn(CAS_MAX)+' per spin.');return}bets[k]=(bets[k]||0)+v;stack.push([k,v]);cur=null;paint();beep(760+Math.min(300,stack.length*14),.04,'triangle',.5)};
 const hlOn=k=>{ov.querySelectorAll('.rc[data-k^="n"]').forEach(b=>b.classList.toggle('hl',k[0]!=='n'&&roWin(k,+b.dataset.k.slice(1))))};
 ov.querySelectorAll('.rc').forEach(b=>{b.onclick=()=>place(b.dataset.k);b.onmouseenter=()=>hlOn(b.dataset.k);b.onmouseleave=()=>hlOn('n0x')});
 const undo=()=>{if(st!=='idle'||!stack.length)return;const[k,v]=stack.pop();bets[k]-=v;if(bets[k]<=0)delete bets[k];paint();beep(480,.04,'triangle',.4)};
 const clear=()=>{if(st!=='idle'||!stack.length)return;bets={};stack=[];paint();beep(400,.05,'triangle',.4)};
 const repeat=()=>{if(st!=='idle'||!lastBets||stack.length)return;const t=Object.values(lastBets).reduce((x,y)=>x+y,0);if(t>P.gold){msg('Not enough gold to repeat those bets.');return}if(t>CAS_MAX){msg('Table limit: '+cmn(CAS_MAX)+' per spin.');return}for(const k in lastBets){bets[k]=lastBets[k];stack.push([k,lastBets[k]])}cur=null;paint();beep(700,.05,'triangle',.5);msg('Previous bets placed. Press Spin.')};
 $('rud').onclick=undo;$('rcl').onclick=clear;$('rrp').onclick=repeat;
 const hist=()=>{$('rr').innerHTML=res.map((v,i)=>`<span class="${i===0?'new':''}" style="background:${roCol(v)}">${v}</span>`).join('')};
 const spark=(x,y,n,cols,pw)=>{for(let i=0;i<n;i++){const an=Math.random()*TAU,v=(pw||160)*(.3+Math.random());parts.push({x,y,vx:Math.cos(an)*v,vy:Math.sin(an)*v-60,l:1,d:.7+Math.random()*.7,r:2+Math.random()*3,c:cols[i%cols.length]})}};
 const spin=()=>{if(st!=='idle'||CAS.lock)return;stake=tot();if(stake<1){msg(broke()||'Place some chips on the table first.');return}if(stake>P.gold){msg('Not enough gold for these bets. Clear the table or use smaller chips.');return}if(!cTake(stake))return;betLock(true);
  lastBets=Object.assign({},bets);const n=Math.random()*37|0,ri=ROW.indexOf(n);
  const need=(((-Math.PI/2-ri*a-rot)%TAU)+TAU)%TAU,T=6.6;anim={t0:performance.now(),T,r0:rot,r1:rot+3*TAU+need,n,ri,D:-TAU*(7+Math.random()*1.2),w0:wv};st='spin';cur=null;hot=null;lastTick=-1;trail.length=0;msg('No more bets…');paint();beep(220,.3,'sine',.3)};
 $('rsp').onclick=spin;
 const finish=()=>{const n=anim.n;st='done';cur=n;hot=anim.ri;landT=performance.now();res.unshift(n);res.length=Math.min(res.length,12);
  let pay=0;for(const k in bets)if(roWin(k,n))pay+=bets[k]*roMul(k);lastPay=pay;cPay(stake,pay);
  msg(`${n}${n===0?' green':ROR.has(n)?' red':' black'}. `+(pay>stake?`You win +${cmn(pay-stake)}`:pay===stake?'Your stake comes back.':pay>0?`You get back ${cmn(pay)}, net −${cmn(stake-pay)}`:`No win. −${cmn(stake)}`)+(broke()?' '+broke():''),pay>stake?'w':pay<stake?'l':'');
  hist();paint({n});beep(130,.16,'sine',.45);
  if(pay>0){spark(c,c,pay>stake?46:18,['#ffe490','#ffd04a','#fff6c0','#ff9a3a'],pay>=stake*10?320:200);if(pay>stake)setTimeout(()=>{if(alive()){beep(660,.1,'triangle',.4);setTimeout(()=>alive()&&beep(880,.1,'triangle',.4),90);setTimeout(()=>alive()&&beep(1180,.18,'triangle',.4),180)}},120)}
  st='idle';betLock(false);stack.length=0;/* chips stay on the table for the next spin */for(const k in bets)stack.push([k,bets[k]]);refresh()};
 live('rw',cv=>{const g=cv.getContext('2d');
  return()=>{if(!alive())return;const now=performance.now(),dt=Math.min(.05,(now-tNow)/1000);tNow=now;
   let bAng=null,bR=0,bx=0,by=0,u=0;
   if(st==='spin'){u=Math.min(1,(now-anim.t0)/1000/anim.T);const e=1-Math.pow(1-u,3),e2=1-Math.pow(1-u,2.4);rot=anim.r0+(anim.r1-anim.r0)*e;
    bAng=-Math.PI/2+anim.D*(1-e2);
    const s=Math.max(0,Math.min(1,(u-.58)/.22)),sm=s*s*(3-2*s),bu=Math.max(0,u-.78);
    bR=186-(186-150)*sm+(u>.78?15*Math.exp(-bu*26)*Math.abs(Math.sin(bu*64)):0);
    if(u>=1){finish()}
    else if(u>.7){const rel=bAng-rot,idx=Math.floor(rel/a);if(lastTick!==-1&&idx!==lastTick)beep(1500+Math.random()*300,.012,'square',.07+.05*(1-u));lastTick=idx}
    else lastTick=Math.floor((bAng-rot)/a)}
   else{wv+=(.2-wv)*Math.min(1,dt*.9);rot+=wv*dt}
   if(st==='idle'&&cur!==null){bAng=rot+anim.ri*a;bR=150}
   g.clearRect(0,0,N,N);g.drawImage(ART.back,0,0);
   g.save();g.translate(c,c);g.rotate(rot);g.translate(-c,-c);g.drawImage(ART.face,0,0);
   if(hot!==null){const gl=.5+.5*Math.sin((now-landT)/160),age=(now-landT)/1000;g.translate(c,c);g.rotate(hot*a);g.fillStyle='rgba(255,230,120,'+(.2+.22*gl)+')';g.beginPath();g.arc(0,0,167,-a/2,a/2);g.arc(0,0,118,a/2,-a/2,true);g.closePath();g.fill();g.strokeStyle='rgba(255,240,170,'+(.55+.4*gl)+')';g.lineWidth=2.5;g.stroke();if(age<1.2){g.strokeStyle='rgba(255,230,120,'+(1.2-age)/1.2*.6+')';g.lineWidth=3;g.beginPath();g.arc(0,0,167+age*60,-a*2,a*2);g.stroke()}}
   g.restore();
   if(bAng!==null){bx=c+Math.cos(bAng)*bR;by=c+Math.sin(bAng)*bR;
    if(st==='spin'){trail.push([bx,by]);if(trail.length>9)trail.shift();for(let i=0;i<trail.length-1;i++){g.fillStyle='rgba(255,255,255,'+(i/trail.length*.28)+')';g.beginPath();g.arc(trail[i][0],trail[i][1],6*(i/trail.length)+1,0,TAU);g.fill()}}
    g.fillStyle='rgba(0,0,0,.4)';g.beginPath();g.ellipse(bx+2.5,by+3.5,6.5,5.5,0,0,TAU);g.fill();
    const bg=g.createRadialGradient(bx-2.2,by-2.4,.6,bx,by,7.5);bg.addColorStop(0,'#ffffff');bg.addColorStop(.55,'#e4e8f0');bg.addColorStop(1,'#8a92a6');g.fillStyle=bg;g.beginPath();g.arc(bx,by,7,0,TAU);g.fill()}
   g.drawImage(ART.front,0,0);
   if(cur!==null&&st==='idle'){const k=Math.min(1,(now-landT)/380),pop=k<1?1+.25*Math.sin(k*Math.PI)-.25*(1-k)*(1-k):1,sc=Math.max(.05,k<1?(1-Math.pow(1-k,3))*pop*1.05:1);
    g.save();g.translate(c,c);g.scale(sc,sc);cdGlow(g,0,0,64,lastPay>stake?'rgba(255,220,100,.7)':'rgba(0,0,0,.4)');g.fillStyle=roCol(cur);g.beginPath();g.arc(0,0,44,0,TAU);g.fill();g.lineWidth=4;g.strokeStyle='#ffd76a';g.stroke();g.lineWidth=1.5;g.strokeStyle='#fff8';g.beginPath();g.arc(0,0,38,0,TAU);g.stroke();g.fillStyle='#fff';g.font="400 48px 'Pirata One',Georgia,serif";g.textAlign='center';g.textBaseline='middle';g.shadowColor='#000';g.shadowBlur=4;g.fillText(cur,0,3);g.restore()}
   if(parts.length){g.save();g.globalCompositeOperation='lighter';for(let i=parts.length-1;i>=0;i--){const p=parts[i];p.l-=dt/p.d;if(p.l<=0){parts.splice(i,1);continue}p.vy+=240*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;g.globalAlpha=Math.min(1,p.l*1.6);g.fillStyle=p.c;g.beginPath();g.arc(p.x,p.y,p.r*p.l+.6,0,TAU);g.fill()}g.restore()}
  }});
 $('rr').innerHTML='';anim=anim||{ri:0};wireBet();CAS.key={' ':spin,enter:spin,z:undo,c:clear,r:repeat};paint();msg('Click the table to place chips, then spin. Chips stay for the next spin. Keys: Space, Z undo, C clear, R repeat.')}
