/* ===== RUNESTONE TOWER DEFENSE 9.2: the Tidecaller Shrine in battle (95l, after 95k; art in 95c5) =====
   The seventh tower, open from the start (150 supply, key I). Every few seconds the Tide Orb draws the basin up into itself (charge),
   flashes, and fires a jet of water onto the road just ahead of its target. A wave rises where it lands and rolls BACK along the road:
   every ground monster it meets is soaked, hurt once and swept back with it (bosses only a little). Soaked monsters are slowed for a
   moment and take 25% more damage from the Storm Bell's lightning. Tier 3: the wave leaves a whirlpool that slows and churns.
   Tier 4: twin jets, two waves on two targets. Tier 5: every fourth attack the Leviathan bursts from the road and bites everything
   near it. It cannot hit flyers.
   State: tw.st 'idle' | 'charge'; tw.ct (charge left), tw.rel (release flash), tw.nb (attacks since the leviathan).
   Battle lists on RPX: tdJets [{x0,y0,x1,y1,t,d,tw,pi,s,lev}], tdWaves [{pi,s,v,left,tw,hit:Set,car:Map,trail,t}], tdWhirls, tdLevs. */
RP_TW.tide={cost:[150,190,320,650,1050],range:[205,220,240,260,280],dmg:[34,56,92,150,230],cd:[2.5,2.3,2.1,1.95,1.8],knock:[100,120,140,160,180],
 whirl:[0,0,22,36,56],twin:[0,0,0,1,1],lev:[0,0,0,0,650],ap:[0,0,2,6,99],air:0,ground:1,
 desc:'Calls a crashing wave onto the road that sweeps monsters back and soaks them (soaked: slowed, and the Storm Bell hits them harder). Cannot hit flyers.',
 up:['Bigger waves that sweep further.','Whirlpool: every wave ends in a churning whirlpool.','Abyssal tide: twin jets, two waves at once.','Leviathan: every fourth attack a sea serpent bursts from the road.']};
RP_TWORDER.push('tide');RP_KEYS.push('I');
const RPTD={charge:.38,jet:.3,wave:.8,whirl:2.4,soak:2.6,soakK:.18,bell:1.25,lev:1.15};
let RPTTW=null;
const rptSoak=e=>{e.soak=RPTD.soak;e.slowK=Math.max(e.slowK||0,RPTD.soakK);e.slowT=Math.max(e.slowT||0,RPTD.soak*.6)};
/* the lightning bonus on soaked monsters */
{const h0=rpHurt;rpHurt=function(e,dmg,ap,src){if(src&&src.type==='bell'&&e&&e.soak>0)dmg*=RPTD.bell;return h0.call(this,e,dmg,ap,src)}}
function rptOrbW(tw){const o=rpTideOrb(tw.tier);return{x:tw.x+o.x,y:tw.y+o.y}}
/* a ground target, and where on its road the wave should land: just ahead of it */
function rptAim(R,tw,rg,not){const e=rpTarget(R,tw,rg,false,true,tw.prio,false);if(!e)return null;let tg=e;
 if(not){let best=null,bd=-1;for(const f of R.foes){if(f.dead||f.air||f.s<0||f===not)continue;const q=rpPos(R,f);if(rpD2(q.x,q.y,tw.x,tw.y)>rg*rg)continue;const qn=rpPos(R,not),d=Math.hypot(q.x-qn.x,q.y-qn.y);if(d>bd){bd=d;best=f}}if(!best||bd<70)return null;tg=best}
 const len=rpLen(R,tg),s=Math.min(len-12,tg.s+46),p=rpAt(R.G,s,tg.pi);return{e:tg,pi:tg.pi||0,s,x:p.x,y:p.y}}
function rpTideFire(R,tw,dt){const T=RP_TW.tide,i=tw.tier-1,rg=T.range[i],sp=tw.over>0?RPT.AB.over.k:1;tw.over=Math.max(0,tw.over-dt);tw.rel=Math.max(0,(tw.rel||0)-dt*3.2);
 if(!tw.st)tw.st='idle';
 if(tw.st==='idle'){tw.charge=Math.max(0,(tw.charge||0)-dt*4);tw.cd-=dt*sp;if(tw.cd>0)return;const a=rptAim(R,tw,rg);if(!a){tw.cd=.15;return}tw.st='charge';tw.ct=RPTD.charge;tw.fire=1;return}
 /* charging: the orb drinks the basin */
 tw.ct-=dt*sp;tw.charge=Math.min(1,1-tw.ct/RPTD.charge);if(tw.ct>0)return;
 tw.st='idle';tw.cd=T.cd[i];tw.charge=0;tw.rel=1;const a=rptAim(R,tw,rg);if(!a){tw.cd=.2;return}
 const lev=T.lev[i]&&(tw.nb||0)>=3;tw.nb=lev?0:(tw.nb||0)+1;const o=rptOrbW(tw);
 R.tdJets.push({x0:o.x,y0:o.y,x1:a.x,y1:a.y,t:0,d:RPTD.jet,tw,pi:a.pi,s:a.s,lev});
 /* the twin jet: a second target well apart from the first, or else further back along the same road, to catch the next group */
 if(T.twin[i]){let b=rptAim(R,tw,rg,a.e);if(!b){const s2=Math.max(10,a.s-90),q=rpAt(R.G,s2,a.pi);b={pi:a.pi,s:s2,x:q.x,y:q.y}}R.tdJets.push({x0:o.x,y0:o.y,x1:b.x,y1:b.y,t:-.08,d:RPTD.jet,tw,pi:b.pi,s:b.s,lev:false})}
 try{beep(520,.08,'sine',.35);setTimeout(()=>beep(780,.12,'sine',.25),60)}catch(e){}}
function rptLand(R,j){const tw=j.tw,T=RP_TW.tide,i=Math.max(0,Math.min(4,tw.tier-1));
 R.rings.push({x:j.x1,y:j.y1,t:0,d:.6,max:56,c:'#bff6ff',w:4,tide:1,tier:tw.tier});
 try{ptBurst(R.fx,j.x1,j.y1-10,R.lite?6:14,['#bff6ff','#5ad6ff','#ffffff'],{v:220,s:3.5,up:1,g:520})}catch(e){}
 try{beep(180,.18,'triangle',.25);setTimeout(()=>beep(120,.25,'sine',.2),70)}catch(e){}
 const L=T.knock[i];R.tdWaves.push({pi:j.pi,s:j.s,v:L/RPTD.wave,left:L,tw,tier:tw.tier,hit:new Set(),car:new Map(),trail:[],t:0,tt:0});
 if(j.lev)R.tdLevs.push({x:j.x1,y:j.y1,t:0,tw,dir:0,hit:false})}
function rptWaves(R,dt){const T=RP_TW.tide;
 for(const j of R.tdJets){j.t+=dt;if(j.t>=j.d&&!j.done){j.done=1;rptLand(R,j)}}R.tdJets=R.tdJets.filter(j=>!j.done||j.t<j.d+.15);
 for(const w of R.tdWaves){const tw=w.tw,i=Math.max(0,Math.min(4,w.tier-1)),over=tw.over>0?1.15:1,step=Math.min(w.left,w.v*dt);w.t+=dt;w.left-=step;w.s=Math.max(0,w.s-step);
  const p=rpAt(R.G,w.s,w.pi),p2=rpAt(R.G,Math.max(0,w.s-6),w.pi);w.x=p.x;w.y=p.y;w.dx=p2.x-p.x;
  w.tt-=dt;if(w.tt<=0){w.tt=R.lite?.09:.05;w.trail.push({x:p.x,y:p.y,t:0,w:1});if(w.trail.length>22)w.trail.shift()}
  for(const f of w.trail)f.t+=dt;
  for(const e of R.foes){if(e.dead||e.air||e.s<0)continue;const q=rpPos(R,e);if(Math.hypot(q.x-p.x,(q.y-p.y)/.85)>46)continue;
   if(!w.hit.has(e)){w.hit.add(e);rpHurt(e,T.dmg[i]*over,T.ap[i],tw);rptSoak(e);w.car.set(e,0)}
   const c=w.car.get(e)||0,cap=e.boss?30:T.knock[i];if(c<cap&&!e.dead){const k=e.boss?.25:1,d=Math.min(cap-c,step*k);e.s=Math.max(0,e.s-d);w.car.set(e,c+d);if(!e.boss)e.stun=Math.max(e.stun||0,.05)}}
  if(w.left<=0||w.s<=0){w.done=1;if(T.whirl[i])R.tdWhirls.push({x:p.x,y:p.y,r:58,t:0,d:RPTD.whirl,dps:T.whirl[i],tw,tier:w.tier})}}
 R.tdWaves=R.tdWaves.filter(w=>!w.done);
 for(const h of R.tdWhirls){h.t+=dt;for(const e of R.foes){if(e.dead||e.air||e.s<0)continue;const q=rpPos(R,e);if(rpD2(q.x,q.y,h.x,h.y)<h.r*h.r){const fl=e.fl;rpHurt(e,h.dps*dt,99,h.tw);e.fl=fl;e.slowK=Math.max(e.slowK||0,.5);e.slowT=Math.max(e.slowT||0,.25);e.soak=Math.max(e.soak||0,.5)}}}
 R.tdWhirls=R.tdWhirls.filter(h=>h.t<h.d);
 for(const L of R.tdLevs){L.t+=dt;const u=L.t/RPTD.lev;if(!L.hit&&u>=.32){L.hit=true;const i=4,T5=T.lev[i]*(L.tw.over>0?1.15:1);R.shake=Math.max(R.shake||0,6);
   for(const e of R.foes){if(e.dead||e.air||e.s<0)continue;const q=rpPos(R,e);if(Math.hypot(q.x-L.x,(q.y-L.y)/.75)<100){rpHurt(e,T5,99,L.tw);rptSoak(e);if(!e.dead)e.s=Math.max(0,e.s-(e.boss?15:70))}}
   R.rings.push({x:L.x,y:L.y,t:0,d:.8,max:110,c:'#fff6d8',w:6,tide:1,tier:5});try{beep(70,.4,'sawtooth',.25)}catch(e){}}}
 R.tdLevs=R.tdLevs.filter(L=>L.t<RPTD.lev);
 for(const e of R.foes)if(e.soak>0)e.soak=Math.max(0,e.soak-dt)}
/* hooks: the fire routine, the battle state, the step */
{const f0=rpFire;rpFire=function(R,tw,dt){if(tw.type==='tide')return rpTideFire(R,tw,dt);return f0.apply(this,arguments)}}
{const s0=rpStart;rpStart=function(){const r=s0.apply(this,arguments);if(RPX)Object.assign(RPX,{tdJets:[],tdWaves:[],tdWhirls:[],tdLevs:[]});return r}}
{const s0=rpStep;rpStep=function(R,dt){const r=s0.apply(this,arguments);if(R.tdJets)rptWaves(R,dt);return r}}
{const u0=rpUpgrade;rpUpgrade=function(tw){const r=u0.apply(this,arguments);if(r&&tw&&tw.type==='tide'){tw.st='idle';tw.charge=0;tw.rel=0}return r}}
/* drawing: the shrine's charge and release, the ground layer (foam, whirlpools, waves behind towers), the top layer (jets, the leviathan) */
{const d0=rpTowerDraw;rpTowerDraw=function(g,type,tier,skin,t,o){if(type==='tide'&&RPTTW){o=Object.assign({},o,{charge:RPTTW.charge||0,rel:RPTTW.rel||0})}return d0.call(this,g,type,tier,skin,t,o)}}
function rptWaveDraw(c,R,w){const k=Math.min(1,w.t*6)*Math.min(1,w.left/30+.25),dir=w.dx<0?-1:1;rpTideWave(c,w.x,w.y+6,dir,Math.min(1,.55+w.t*2.2),R.t+w.pi,w.tier,k*.95)}
{const a0=rpTowerAt;rpTowerAt=function(c,R,tw){/* waves on the road behind this tower are drawn before it */
  if(R.tdWaves&&R.tdWaves.length){for(const w of R.tdWaves){if(w.fr!==R.t&&w.y!=null&&w.y<tw.y-4){w.fr=R.t;rptWaveDraw(c,R,w)}}}
  if(tw.type!=='tide')return a0.apply(this,arguments);RPTTW=tw;try{return a0.apply(this,arguments)}finally{RPTTW=null}}}
{const a0=rpAmbient;rpAmbient=function(c,R){const r=a0.apply(this,arguments);try{if(R&&R.tdWaves){for(const h of R.tdWhirls){const k=Math.min(1,h.t*4,(h.d-h.t)/.5);rpTideWhirl(c,h.x,h.y,h.r,R.t,h.tier,k)}
  for(const w of R.tdWaves)rpTideFoam(c,w.trail,R.t,w.tier)}}catch(e){}return r}}
{const b0=rpBeamsDraw;rpBeamsDraw=function(c,R){b0.apply(this,arguments);if(!R.tdWaves)return;
 for(const w of R.tdWaves)if(w.fr!==R.t&&w.y!=null){w.fr=R.t;rptWaveDraw(c,R,w)}
 for(const j of R.tdJets){if(j.t<0)continue;const u=j.t/j.d;if(u<1)rpTideJet(c,j.x0,j.y0,j.x1,j.y1,u,j.tw.tier);else rpTideSplash(c,j.x1,j.y1,Math.min(.99,(j.t-j.d)/.15*.3+.05),56,j.tw.tier)}
 for(const L of R.tdLevs){if(L.dir===0){let d=1;try{const q=R.foes.find(e=>!e.dead&&!e.air);if(q)d=rpPos(R,q).x<L.x?-1:1}catch(e){}L.dir=d}rpTideLeviathan(c,L.x,L.y,L.t/RPTD.lev,L.dir,5)}}}
/* rings from splashes use the tide colours */
{const d0=rpDraw;rpDraw=function(){const R=RPX;if(R&&R.rings)for(const r of R.rings)if(r.tide&&r.c)r.c=r.tier>=5?'#fff6d8':r.tier===4?'#d8c4ff':'#bff6ff';return d0.apply(this,arguments)}}
/* soaked monsters drip */
{const f0=rpFoeDraw;rpFoeDraw=function(c,R,e,q){const r=f0.apply(this,arguments);if(e.soak>0&&!e.dead&&!R.rm&&Math.random()<(R.lite?.04:.1))try{ptBurst(R.fx,q.x+(Math.random()-.5)*16,q.y-24,1,['#bff6ff','#5ad6ff'],{v:30,s:2.2,g:300})}catch(x){}return r}}
/* the panel: the right stats for a wave tower */
{const i0=rpInfoBuild;rpInfoBuild=function(R,tw,el){const r=i0.apply(this,arguments);if(tw.type!=='tide')return r;try{const T=RP_TW.tide,i=tw.tier-1,top=RP_MAXT(R.map),nx=tw.tier<top?tw.tier:null;
  const seg=(v,max)=>Math.max(0,Math.min(6,Math.round(v/max*6))),bar=(lab,v,max,nv)=>`<div class="rpst"><span>${lab}</span><i>${[0,1,2,3,4,5].map(k=>`<s class="${k<seg(v,max)?'on':nv!=null&&k<seg(nv,max)?'up':''}"></s>`).join('')}</i></div>`;
  const dmg=j=>Math.sqrt(T.dmg[j]/T.cd[j]*(T.twin[j]?2:1)*6+T.whirl[j]*8+T.lev[j]*.3);
  const st=el.querySelector('.rpsts');if(st)st.innerHTML=bar('Range',T.range[i],320,nx!=null?T.range[nx]:null)+bar('Damage',dmg(i),Math.sqrt(1400),nx!=null?dmg(nx):null)+bar('Sweep back',T.knock[i],180,nx!=null?T.knock[nx]:null)+bar('Fire rate',1/T.cd[i],.6,nx!=null?1/T.cd[nx]:null);
  const hgt=el.offsetHeight||420;el.style.top=rpClamp(tw.y-hgt*.62,76,770-hgt)+'px'}catch(e){console.error(e)}return r}}
/* key I picks it */
{const k0=rpKeyDown;window.removeEventListener('keydown',rpKeyDown,true);rpKeyDown=function(e){const R=RPX;if(R&&S.rp&&S.mode==='ramparts'&&!R.pause&&!R.over&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&e.key.length===1&&e.key.toLowerCase()==='i'){e.preventDefault();e.stopImmediatePropagation();if(!e.repeat)rpPlace('tide');return}return k0.apply(this,arguments)};window.addEventListener('keydown',rpKeyDown,true)}
try{const h=HELP.Modes.find(x=>x[0]==='Runestone Tower Defense');if(h)h[1]+=' The Tidecaller Shrine (I, 150 supply) calls crashing waves that sweep monsters back down the road and soak them; soaked monsters are slowed and the Storm Bell hits them harder.'}catch(e){}
{const h0=rpHowTo;rpHowTo=function(){const r=h0.apply(this,arguments);try{const w=ov.querySelector('#rpmod .rphw');if(w)w.insertAdjacentHTML('beforeend',`<p><b>Tidecaller Shrine.</b> A cheap water tower (150 supply, key I). Its waves sweep monsters back down the road and soak them: soaked monsters slow down and take more damage from the Storm Bell. Tier 3 adds whirlpools, tier 4 twin waves, tier 5 the Leviathan.</p>`)}catch(e){}return r}}
