/* ===== RUNESTONE TOWER DEFENSE 10.2 review: balance numbers for the two new towers (99g, after 99e; prefix rprv) =====
   Numbers only. t_bal102.py (the t_ramparts bot: slot 5 of a mixed build on the nine campaign maps, each tower alone on the same pads
   with the same budget and waves, all-of-one-tower builds, the endless Wonderland) measured the 10.2 Phantom Lantern below the towers it
   was meant to be level with: alone about 0.8 x the Prism / Dragon Roost / Hive per supply, 11% in the stressed slot test (Prism 33%,
   Dragon 56%, Hive 11%), all-Lantern builds won no map, and with eight towers the endless Wonderland fell 9 waves short of the reference.
   Wisps and their haunt hit 20% harder and phantoms cut 15% harder. The Moonblade Sentinel met its targets (value pick, about 1.2 x the
   Prism alone, lazy all-Sentinel loses most maps, Wonderland reach level with the reference) and is unchanged. */
const RPRV={lant:{dmg:[96,138,194,276,396],haunt:[22,31,46,65,94],ph:[110,160,230,320,460]}};
try{Object.assign(RP_TW.lant,RPRV.lant)}catch(e){}
/* 10.2b (lead): the owner asked for the Moonblade Sentinel to be the slightly overpowered value pick. The review measured it best per
   supply among the mid-price towers but only about +10% over the Prism, so glaive damage goes up 10% (36/54/80/122/182 -> 40/59/88/134/200);
   t_bal102 then checks it stays under 1.3 x the best mid-price tower, that lazy all-Sentinel builds still lose most maps and that the
   endless Wonderland stays within +10 waves of the reference. */
try{RP_TW.moon.dmg=[40,59,88,134,200]}catch(e){}
