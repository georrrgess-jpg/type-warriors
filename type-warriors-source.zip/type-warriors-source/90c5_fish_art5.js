/* ===== MOONLIT FISHING: fish art 5 — Glowcap Grotto: tetra (common), cavefish (uncommon), wyrm (legendary) =====
   Each FISHART.<id>(g,t,o) draws one fish facing right, centred on the origin, ~200 units long. Helpers prefixed fa5_
   (the polish kit is a private copy so this file never depends on another file's internals). */
/* path from a command list: 'M',x,y 'L',x,y 'Q',cx,cy,x,y 'C',c1x,c1y,c2x,c2y,x,y 'Z' */
function fa5_path(g,c){g.beginPath();let i=0;while(i<c.length){const k=c[i++];
 if(k==='M'){g.moveTo(c[i],c[i+1]);i+=2}else if(k==='L'){g.lineTo(c[i],c[i+1]);i+=2}
 else if(k==='Q'){g.quadraticCurveTo(c[i],c[i+1],c[i+2],c[i+3]);i+=4}
 else if(k==='C'){g.bezierCurveTo(c[i],c[i+1],c[i+2],c[i+3],c[i+4],c[i+5]);i+=6}else if(k==='Z')g.closePath()}}
/* crisp closed polygon */
function fa5_poly(g,p){g.beginPath();g.moveTo(p[0],p[1]);for(let i=2;i<p.length;i+=2)g.lineTo(p[i],p[i+1]);g.closePath()}
/* gradient with explicit stops [[pos,colour],...] */
function fa5_grad(g,x0,y0,x1,y1,s){const q=g.createLinearGradient(x0,y0,x1,y1);for(const e of s)q.addColorStop(e[0],e[1]);return q}
function fa5_rgrad(g,x,y,r0,r1,s){const q=g.createRadialGradient(x,y,r0,x,y,r1);for(const e of s)q.addColorStop(e[0],e[1]);return q}
/* run fn in a translated + rotated frame */
function fa5_at(g,x,y,a,fn){g.save();g.translate(x,y);g.rotate(a);fn();g.restore()}
/* twinkle 0..1 */
const fa5_tw=(t,i,sp)=>.5+.5*Math.sin(t*(sp||3)+i*1.91);
/* glossy highlight: a soft white curve inside the clip path */
function fa5_gloss(g,clip,x0,y0,cx,cy,x1,y1,w,a){g.save();clip();g.clip();g.lineCap='round';g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo(cx,cy,x1,y1);
 g.strokeStyle=`rgba(255,255,255,${a*.4})`;g.lineWidth=w*2.2;g.stroke();g.strokeStyle=`rgba(255,255,255,${a})`;g.lineWidth=w;g.stroke();g.restore()}
/* gill arc (clipped to the body) */
function fa5_gill(g,clip,x,y,r,a0,a1,c,a){g.save();clip();g.clip();g.beginPath();g.arc(x,y,r,a0,a1);g.strokeStyle=c||FKO;g.globalAlpha=a==null?.6:a;g.lineWidth=2.4;g.lineCap='round';g.stroke();g.restore()}
/* rib lines from a root point to each listed point, clipped to the clip path */
function fa5_ribs(g,clip,x0,y0,pts,a,c,lw){g.save();clip();g.clip();g.strokeStyle=c||FKO;g.globalAlpha=a==null?.25:a;g.lineWidth=lw||1.3;g.lineCap='round';
 for(let i=0;i<pts.length;i+=2){g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo((x0+pts[i])/2,(y0+pts[i+1])/2*1.04,pts[i],pts[i+1]);g.stroke()}g.restore()}
/* tapered strand along a chain of cubic beziers b=[x0,y0, c1x,c1y,c2x,c2y,x1,y1, ...] */
function fa5_strand(g,b,w0,w1,col,lw,rays){const P=[[b[0],b[1]]];let x=b[0],y=b[1];
 for(let i=2;i+5<b.length;i+=6){const c1x=b[i],c1y=b[i+1],c2x=b[i+2],c2y=b[i+3],ex=b[i+4],ey=b[i+5];
  for(let s=1;s<=12;s++){const u=s/12,v=1-u;P.push([v*v*v*x+3*v*v*u*c1x+3*v*u*u*c2x+u*u*u*ex,v*v*v*y+3*v*v*u*c1y+3*v*u*u*c2y+u*u*u*ey])}x=ex;y=ey}
 const n=P.length,L=[],R=[];for(let i=0;i<n;i++){const a=P[Math.max(0,i-1)],c=P[Math.min(n-1,i+1)],dx=c[0]-a[0],dy=c[1]-a[1],d=Math.hypot(dx,dy)||1,w=(w0+(w1-w0)*i/(n-1))/2;
  L.push([P[i][0]-dy/d*w,P[i][1]+dx/d*w]);R.push([P[i][0]+dy/d*w,P[i][1]-dx/d*w])}
 g.beginPath();g.moveTo(L[0][0],L[0][1]);for(const p of L)g.lineTo(p[0],p[1]);for(let i=n-1;i>=0;i--)g.lineTo(R[i][0],R[i][1]);g.closePath();
 g.lineJoin='round';g.lineWidth=lw||2.2;g.strokeStyle=FKO;g.stroke();g.fillStyle=col;g.fill();
 /* optional fin finish: fine rays along the strand and a soft highlight on one edge */
 if(rays){g.save();g.clip();g.lineCap='round';const line=(f,c,w)=>{g.beginPath();for(let i=0;i<n;i++){const px=L[i][0]+(R[i][0]-L[i][0])*f,py=L[i][1]+(R[i][1]-L[i][1])*f;i?g.lineTo(px,py):g.moveTo(px,py)}g.strokeStyle=c;g.lineWidth=w;g.stroke()};
  for(const f of [.3,.5,.7])line(f,rays,.7);line(.16,'rgba(255,255,255,.65)',1.1);g.restore()}}
/* eyelid: amt 0 open .. 1 shut */
function fa5_lid(g,x,y,r,amt,col){if(amt<=0)return;const ly=y-r+2*r*Math.min(1,amt);g.save();g.beginPath();g.arc(x,y,r,0,TAU);g.clip();
 g.beginPath();g.moveTo(x-r-3,y-r-3);g.lineTo(x+r+3,y-r-3);g.lineTo(x+r+3,ly);g.quadraticCurveTo(x,ly+r*.2,x-r-3,ly);g.closePath();g.fillStyle=col;g.fill();
 g.beginPath();g.moveTo(x+r+3,ly);g.quadraticCurveTo(x,ly+r*.2,x-r-3,ly);g.strokeStyle=FKO;g.lineWidth=Math.max(2,r*.26);g.stroke();g.restore();
 g.beginPath();g.arc(x,y,r,0,TAU);g.lineWidth=Math.max(2,r*.24);g.strokeStyle=FKO;g.stroke()}
/* blink: 0 open, rising to 1 for a quick blink every few seconds */
function fa5_blink(t,s){const p=((t+s)%5.1+5.1)%5.1;return p>4.9?1-Math.abs(p-5)/.1:0}
/* small cartoon smile */
function fa5_smile(g,x0,y0,cx,cy,x1,y1,w){g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo(cx,cy,x1,y1);g.strokeStyle=FKO;g.lineWidth=w||2.4;g.lineCap='round';g.stroke()}
/* rosy cheek blush */
function fa5_blush(g,x,y,r,c,a){g.save();g.globalAlpha=a==null?.45:a;g.fillStyle=fa5_rgrad(g,x,y,0,r,[[0,c||'#ff7aa0'],[1,(c||'#ff7aa0')+'00']]);g.beginPath();g.ellipse(x,y,r,r*.62,0,0,TAU);g.fill();g.restore()}
/* pectoral fin: a fan hinged at (x,y), sweeping back; a = tilt */
function fa5_pec(g,x,y,a,L,c1,c2,al,rim){fa5_at(g,x,y,a,()=>{const P=()=>fa5_path(g,['M',3,-3.5,'C',-L*.3,-L*.34,-L*.78,-L*.3,-L,-L*.08,'Q',-L*1.02,L*.08,-L*.9,L*.18,'Q',-L*.8,L*.3,-L*.62,L*.3,'C',-L*.36,L*.28,-L*.1,L*.12,3,3.5,'Z']);
 g.globalAlpha=al||1;P();fkFill(g,fkLin(g,0,0,-L,L*.1,[c1,c2]),2.2);g.globalAlpha=1;fa5_ribs(g,P,2,0,[-L,-L*.12,-L,L*.04,-L*.9,L*.2,-L*.7,L*.3],.3);
 fa5_finfx(g,P,0,0,shade(c1,.45),[-L*.98,-L*.03,-L*.96,L*.12,-L*.82,L*.26],.6,0);
 g.save();P();g.clip();g.beginPath();g.moveTo(2,-3);g.bezierCurveTo(-L*.3,-L*.3,-L*.78,-L*.26,-L*.98,-L*.06);g.strokeStyle=rim||'rgba(255,255,255,.55)';g.lineWidth=2;g.stroke();g.restore();P();g.lineJoin='round';g.lineWidth=2.2;g.strokeStyle=FKO;g.stroke()})}
/* 6-armed snowflake crystal */
function fa5_catch(g,o,c,k){const v=(o.glow||0)*(k||1);if(v>0)fkGlow(g,10,0,115,c||'#fff2c8',.24*v)}
/* ribbon outline from a centre line fn(s)->[x,y,halfWidth]; returns flat points (left side then right side reversed) */
function fa5_rib(n,fn){const c=[];for(let i=0;i<=n;i++)c.push(fn(i/n));const L=[],R=[];
 for(let i=0;i<=n;i++){const a=c[Math.max(0,i-1)],b=c[Math.min(n,i+1)],dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy)||1,nx=-dy/d,ny=dx/d,w=c[i][2];
  L.push(c[i][0]+nx*w,c[i][1]+ny*w);R.unshift(c[i][0]-nx*w,c[i][1]-ny*w)}return L.concat(R)}
/* closed smooth spline (same curve as fkPath) appended to the current path when cont is true */
function fa5_blob(g,p,cont){const n=p.length/2,mx=i=>(p[(i%n)*2]+p[((i+1)%n)*2])/2,my=i=>(p[(i%n)*2+1]+p[((i+1)%n)*2+1])/2;if(!cont)g.beginPath();g.moveTo(mx(n-1),my(n-1));for(let i=0;i<n;i++)g.quadraticCurveTo(p[i*2],p[i*2+1],mx(i),my(i));g.closePath()}
/* clip to everything OUTSIDE a spline outline (so see-through bodies do not show the fin roots behind them) */
function fa5_outside(g,p){g.beginPath();g.rect(-400,-400,800,800);fa5_blob(g,p,1);g.clip('evenodd')}
/* crystal fin polygon: pre points, then an outer edge with a sharp ice shard between every pair of edge points, then post points */
function fa5_rgba(h,a){const n=parseInt(h.slice(1,7),16);return `rgba(${n>>16},${n>>8&255},${n&255},${a})`}
/* rich eye: shaded sclera, gradient iris with a dark rim and fine striations, pupil, big catch-light, second glint and a soft lower reflection */
function fa5_eye(g,x,y,r,iris,look){look=look||0;const ix=x+r*.18+look*r*.12,iy=y+r*.05,ir=r*.62;
 g.beginPath();g.arc(x,y,r,0,TAU);g.fillStyle=fa5_rgrad(g,x-r*.25,y-r*.3,r*.1,r*1.05,[[0,'#ffffff'],[.62,'#fbf7f0'],[1,'#d8d0e6']]);g.fill();
 g.save();g.beginPath();g.arc(x,y,r,0,TAU);g.clip();
 g.beginPath();g.arc(ix,iy,ir,0,TAU);g.fillStyle=fa5_rgrad(g,ix-ir*.15,iy+ir*.25,ir*.08,ir,[[0,shade(iris,.5)],[.45,iris],[.85,shade(iris,-.35)],[1,shade(iris,-.6)]]);g.fill();
 g.strokeStyle=fa5_rgba(shade(iris,.55),.35);g.lineWidth=Math.max(.6,r*.06);g.beginPath();
 for(let i=0;i<10;i++){const a=i/10*TAU+.3;g.moveTo(ix+Math.cos(a)*ir*.42,iy+Math.sin(a)*ir*.42);g.lineTo(ix+Math.cos(a)*ir*.86,iy+Math.sin(a)*ir*.86)}g.stroke();
 g.beginPath();g.arc(ix,iy,ir,0,TAU);g.strokeStyle=fa5_rgba(shade(iris,-.7),.85);g.lineWidth=Math.max(.8,r*.08);g.stroke();
 g.beginPath();g.arc(x+r*.22+look*r*.12,y+r*.08,r*.34,0,TAU);g.fillStyle='#0c0612';g.fill();
 /* upper lid shadow */
 g.fillStyle=fa5_grad(g,0,y-r,0,y-r*.2,[[0,'rgba(40,20,60,.32)'],[1,'rgba(40,20,60,0)']]);g.fillRect(x-r,y-r,r*2,r*.8);
 /* lower reflection crescent */
 g.beginPath();g.arc(ix,iy,ir*.72,Math.PI*.25,Math.PI*.8);g.strokeStyle='rgba(255,255,255,.42)';g.lineWidth=Math.max(.8,r*.1);g.lineCap='round';g.stroke();
 g.restore();
 g.beginPath();g.arc(x,y,r,0,TAU);g.lineWidth=Math.max(2,r*.24);g.strokeStyle=FKO;g.stroke();
 g.beginPath();g.ellipse(x+r*.34,y-r*.24,r*.25,r*.21,-.5,0,TAU);g.fillStyle='#fff';g.fill();
 g.beginPath();g.arc(x+r*.08,y-r*.34,r*.08,0,TAU);g.fill();
 g.beginPath();g.arc(x-r*.06,y+r*.34,r*.1,0,TAU);g.fillStyle='rgba(255,255,255,.75)';g.fill()}
/* rim light: thin light just inside the top edge (moonlight) and a reflected glow inside the bottom edge */
function fa5_rim(g,clip,top,bot,a,w){a=a==null?1:a;w=w||2;g.save();clip();g.clip();
 if(top){g.save();g.translate(.6,w*1.25);clip();g.strokeStyle=top;g.globalAlpha=.55*a;g.lineWidth=w;g.stroke();g.restore()}
 if(bot){g.save();g.translate(-.6,-w*1.3);clip();g.strokeStyle=bot;g.globalAlpha=.5*a;g.lineWidth=w*1.2;g.stroke();g.restore()}
 g.restore()}
/* crisp specular glint (a bright tilted lozenge and a dot) */
function fa5_spec(g,x,y,s,a){g.save();g.globalAlpha=a==null?.95:a;g.fillStyle='#fff';g.beginPath();g.ellipse(x,y,3.4*s,1.25*s,-.42,0,TAU);g.fill();
 g.beginPath();g.arc(x+4.6*s,y-2.4*s,.9*s,0,TAU);g.fill();g.restore()}
/* fin finish: shadowed root, fine secondary rays, and a light translucent band toward the edge */
function fa5_finfx(g,P,rx,ry,edge,rays,a,lw){a=a==null?1:a;g.save();P();g.clip();
 if(rays&&rx!=null){g.strokeStyle=fa5_rgba(edge,.32*a);g.lineWidth=.8;g.lineCap='round';g.beginPath();for(let i=0;i<rays.length;i+=2){g.moveTo(rx,ry);g.lineTo(rx+(rays[i]-rx)*1.1,ry+(rays[i+1]-ry)*1.1)}g.stroke()}
 g.lineJoin='round';P();g.strokeStyle=fa5_rgba(edge,.16*a);g.lineWidth=12;g.stroke();P();g.strokeStyle=fa5_rgba(edge,.3*a);g.lineWidth=5;g.stroke();
 if(rx!=null&&ry!=null){g.fillStyle=fa5_rgrad(g,rx,ry,0,26,[[0,'rgba(20,8,30,.2)'],[1,'rgba(20,8,30,0)']]);g.fillRect(rx-28,ry-28,56,56)}
 g.restore();if(lw!==0){P();g.lineJoin='round';g.lineWidth=lw||2.4;g.strokeStyle=FKO;g.stroke()}}
/* embossed fine scales: dark scale edges with a lighter catch-light just inside */
function fa5_tex(g,clip,x0,x1,y0,y1,s,dark,light,a){fkScales(g,clip,x0,x1,y0,y1,s,dark,a);g.save();g.translate(0,-1);fkScales(g,clip,x0,x1,y0,y1,s,light,a*.75);g.restore()}
/* operculum: soft shade behind the gill, a crisp gill line, a highlight on its front lip and a faint second slit */
function fa5_gill2(g,clip,x,y,r,a0,a1,c,a){a=a==null?.6:a;g.save();clip();g.clip();g.lineCap='round';
 g.beginPath();g.arc(x,y,r,a0,a1);g.arc(x,y,r+10,a1,a0,true);g.closePath();g.fillStyle=fa5_rgrad(g,x,y,r,r+10,[[0,fa5_rgba(c,.24)],[1,fa5_rgba(c,0)]]);g.fill();
 g.beginPath();g.arc(x+7,y,r+6,a0+.08,a1-.08);g.strokeStyle=fa5_rgba(c,.28*a/.6);g.lineWidth=1.2;g.stroke();
 g.beginPath();g.arc(x,y,r,a0,a1);g.strokeStyle=c;g.globalAlpha=Math.min(1,a*1.2);g.lineWidth=1.8;g.stroke();
 g.beginPath();g.arc(x-1.6,y,r,a0+.06,a1-.06);g.strokeStyle='#ffffff';g.globalAlpha=.3;g.lineWidth=1.2;g.stroke();g.restore()}
/* mouth with a soft lower lip, a lip highlight and a curled corner */
function fa5_mouth(g,x0,y0,cx,cy,x1,y1,w,lip){g.save();g.lineCap='round';
 g.beginPath();g.moveTo(x0-.5,y0+1.8);g.quadraticCurveTo(cx,cy+2.4,x1+.5,y1+1.8);g.strokeStyle=fa5_rgba(lip||'#ff8aa8',.55);g.lineWidth=3.2;g.stroke();
 g.beginPath();g.moveTo(x0,y0-1.4);g.quadraticCurveTo(cx,cy-1.6,x1+1,y1-1.4);g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=1.1;g.stroke();
 fa5_smile(g,x0,y0,cx,cy,x1,y1,w||2);
 g.beginPath();g.arc(x1+1.6,y1,2,Math.PI*.72,Math.PI*1.28);g.strokeStyle=FKO;g.lineWidth=1.2;g.stroke();g.restore()}
/* gentle colour variation: a few soft tinted blotches inside a clip; b=[[x,y,r,colour,alpha],...] */
function fa5_mottle(g,clip,b){g.save();clip();g.clip();for(const m of b){g.fillStyle=fa5_rgrad(g,m[0],m[1],0,m[2],[[0,fa5_rgba(m[3],m[4])],[1,fa5_rgba(m[3],0)]]);g.fillRect(m[0]-m[2],m[1]-m[2],m[2]*2,m[2]*2)}g.restore()}
/* fine speckle texture (deterministic) inside a clip */
function fa5_speck(g,clip,x0,x1,y0,y1,n,col,a,r,seed){g.save();clip();g.clip();g.fillStyle=col;g.globalAlpha=a;g.beginPath();let s=seed||7;
 for(let i=0;i<n;i++){s=(s*9301+49297)%233280;const u=s/233280;s=(s*9301+49297)%233280;const v=s/233280;const x=x0+(x1-x0)*u,y=y0+(y1-y0)*v,rr=r*(.6+.8*((i*37)%10)/10);g.moveTo(x+rr,y);g.arc(x,y,rr,0,TAU)}g.fill();g.restore()}
/* frost rime: a dotted white crust just inside an outline */
/* ---- grotto helpers (fa5_) ---- */
/* dense polyline through control points (Catmull-Rom), resampled to m points evenly spaced by arc length */
function fa5_spline(cp,m){const d=[],n=cp.length/2,P=i=>{i=Math.max(0,Math.min(n-1,i));return [cp[i*2],cp[i*2+1]]};
 for(let i=0;i<n-1;i++){const p0=P(i-1),p1=P(i),p2=P(i+1),p3=P(i+2);for(let k=0;k<16;k++){const u=k/16,u2=u*u,u3=u2*u;
  d.push([.5*(2*p1[0]+(-p0[0]+p2[0])*u+(2*p0[0]-5*p1[0]+4*p2[0]-p3[0])*u2+(-p0[0]+3*p1[0]-3*p2[0]+p3[0])*u3),.5*(2*p1[1]+(-p0[1]+p2[1])*u+(2*p0[1]-5*p1[1]+4*p2[1]-p3[1])*u2+(-p0[1]+3*p1[1]-3*p2[1]+p3[1])*u3)])}}
 d.push(P(n-1));const L=[0];for(let i=1;i<d.length;i++)L.push(L[i-1]+Math.hypot(d[i][0]-d[i-1][0],d[i][1]-d[i-1][1]));const T=L[L.length-1],out=[];let j=0;
 for(let i=0;i<m;i++){const s=T*i/(m-1);while(j<d.length-2&&L[j+1]<s)j++;const f=(s-L[j])/((L[j+1]-L[j])||1);out.push([d[j][0]+(d[j+1][0]-d[j][0])*f,d[j][1]+(d[j+1][1]-d[j][1])*f])}
 out.len=T;return out}
/* normals (-dy,dx) of a polyline */
function fa5_norms(P){const n=P.length,N=[];for(let i=0;i<n;i++){const a=P[Math.max(0,i-1)],b=P[Math.min(n-1,i+1)],dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy)||1;N.push([-dy/d,dx/d])}return N}
/* hexagonal crystal prism standing at (x,y) pointing along angle a: lit and shadow facets, a ridge, a facet band and a tip glint */
function fa5_gem(g,x,y,a,L,w,lit,mid,dark,tw){fa5_at(g,x,y,a,()=>{const h=w*.5,P=()=>fa5_poly(g,[0,-h,L*.7,-h,L,0,L*.7,h,0,h]);
 P();g.fillStyle=fa5_grad(g,0,0,L,0,[[0,dark],[.55,mid],[1,lit]]);g.fill();
 g.beginPath();g.moveTo(0,-h);g.lineTo(L*.7,-h);g.lineTo(L,0);g.lineTo(0,0);g.closePath();g.fillStyle=fa5_grad(g,0,-h,L,0,[[0,fa5_rgba(lit,.55)],[1,fa5_rgba('#ffffff',.85)]]);g.fill();
 g.beginPath();g.moveTo(0,h*.5);g.lineTo(L*.7,h*.5);g.lineTo(L,0);g.strokeStyle=fa5_rgba(dark,.55);g.lineWidth=.8;g.stroke();
 g.beginPath();g.moveTo(L*.7,-h);g.lineTo(L*.7,h);g.strokeStyle=fa5_rgba('#ffffff',.5);g.lineWidth=.9;g.stroke();
 g.beginPath();g.moveTo(L*.08,-h*.55);g.lineTo(L*.62,-h*.55);g.strokeStyle='rgba(255,255,255,.75)';g.lineWidth=Math.max(.8,w*.12);g.lineCap='round';g.stroke();
 P();g.lineJoin='round';g.lineWidth=Math.max(1.5,w*.2);g.strokeStyle=FKO;g.stroke();
 if(tw>0)fkSpark(g,L*.94,-h*.2,2+w*.42*tw,'#ffffff',tw)})}

/* soft translucent pectoral fan hinged at (x,y), sweeping back; a = tilt */
function fa5_pec2(g,x,y,a,L,c1,c2,al){fa5_at(g,x,y,a,()=>{const pp=[3,-3,-4,-8,-L*.62,-L*.5,-L,-L*.3,-L*1.02,-L*.02,-L*.78,L*.2,-L*.36,L*.2,3,3],P=()=>fkPath(g,pp);
 g.globalAlpha=al||.85;P();g.fillStyle=fa5_grad(g,0,0,-L,0,[[0,c1],[1,c2]]);g.fill();g.globalAlpha=1;
 g.save();P();g.clip();g.strokeStyle='rgba(40,20,70,.3)';g.lineWidth=1;g.lineCap='round';g.beginPath();for(const r of [[-L*.9,-L*.36],[-L*1.02,-L*.16],[-L,L*.04],[-L*.78,L*.2],[-L*.5,L*.24]]){g.moveTo(1,0);g.lineTo(r[0],r[1])}g.stroke();
 P();g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=5;g.stroke();g.beginPath();g.moveTo(1,-3);g.quadraticCurveTo(-L*.5,-L*.52,-L*.98,-L*.3);g.strokeStyle='rgba(255,255,255,.85)';g.lineWidth=1.8;g.stroke();g.restore();
 P();g.lineJoin='round';g.lineWidth=2;g.strokeStyle=FKO;g.stroke()})}

/* ---------------- 4. Glowcap Tetra (Common): a tiny neon tetra with a glowing electric-cyan stripe ---------------- */
FISHART.tetra=(g,t,o)=>{const sw=fkSway(o,6.4,.17),fin=Math.sin(t*8.4)*.13,gl=o.glow||0,pu=.5+.5*Math.sin(t*2.6);g.save();g.rotate(-sw*.22);
 const BP=[109,4,105,-10,90,-25,63,-35,26,-38,-10,-33,-40,-20,-60,-9,-64,0,-60,9,-40,17,-10,26,26,33,63,30,90,21,105,12],B=()=>fkPath(g,BP);
 const stc=s=>{const x=104-170*s;return [x,-8-4*Math.sin(Math.PI*Math.min(1,s*1.6))+5*s*s]},stw=s=>(2.4+3.4*Math.pow(Math.sin(Math.PI*Math.min(1,s*1.05+.03)),.7))*(1+.06*pu);
 const ST=fa5_rib(48,s=>{const c=stc(s);return [c[0],c[1],stw(s)]}),S=()=>fkPath(g,ST);
 fkGlow(g,10,-4,96,'#2ae6ff',.1+.08*pu+gl*.3);
 // forked tail: glassy, a blush of magenta at its root, clear cyan-white lobes
 const T=()=>fa5_path(g,['M',10,-5,'Q',-4,-6,-16,-15,'Q',-30,-27,-44,-38,'Q',-44,-27,-39,-17,'Q',-32,-6,-25,0,'Q',-32,6,-39,17,'Q',-44,27,-44,38,'Q',-30,27,-16,15,'Q',-4,6,10,5,'Z']);
 fa5_at(g,-58,0,sw,()=>{g.globalAlpha=.8;T();fkFill(g,fkLin(g,8,0,-44,0,['#ff4a96','#ff9ad6','#9ae8ff','#d8faff']),0);g.globalAlpha=1;
  fa5_ribs(g,T,8,0,[-44,-36,-40,-26,-33,-13,-33,13,-40,26,-44,36],.26,'#30307a');
  fa5_finfx(g,T,9,0,'#ffffff',[-44,-31,-36,-19,-30,-6,-30,6,-36,19,-44,31],.9,0);
  g.save();T();g.clip();g.fillStyle=fa5_rgrad(g,8,0,0,24,[[0,'rgba(255,40,110,.55)'],[1,'rgba(255,40,110,0)']]);g.fillRect(-20,-30,40,60);g.restore();
  T();g.lineJoin='round';g.lineWidth=2.4;g.strokeStyle='#241640';g.stroke()});
 // see-through fins with crisp white leading edges
 const fn=(x,y,a,pp,ribs,rx,ry,le)=>fa5_at(g,x,y,a,()=>{const P=()=>fkPath(g,pp);g.globalAlpha=.82;fkFin(g,pp,'#e4fbff','#6ad4ff',ribs,0);g.globalAlpha=1;fa5_finfx(g,P,rx,ry,'#d8fbff',null,1,0);
  if(le){g.save();P();g.clip();g.beginPath();g.moveTo(le[0],le[1]);g.quadraticCurveTo(le[2],le[3],le[4],le[5]);g.strokeStyle='#ffffff';g.lineWidth=4.4;g.lineCap='round';g.stroke();g.restore()}
  P();g.lineJoin='round';g.lineWidth=2.2;g.strokeStyle='#241640';g.stroke()});
 fn(4,-33,fin*.5,[12,3,6,-8,-4,-24,-10,-25,-13,-10,-16,3],[[4,0,-6,-21],[-3,0,-10,-20],[-9,0,-13,-8]],0,0,[12,4,4,-10,-8,-26]);
 fn(-42,-17,fin*.3,[4,1,1,-6,-5,-7,-8,1],null,0,0);
 fn(-14,25,-fin*.6,[14,-2,6,10,-12,16,-26,12,-26,-3],[[6,0,-2,12],[-2,0,-12,14],[-10,0,-22,11]],0,0,[16,-2,10,6,2,16]);
 fn(28,31,-fin,[6,-3,-1,9,-11,11,-11,-3],[[0,0,-9,9]],0,0,[8,-3,2,6,-4,12]);
 // body: deep teal back over a silver belly
 B();fkFill(g,fa5_grad(g,0,-38,0,33,[[0,'#0a1a36'],[.2,'#12304e'],[.36,'#1c4a68'],[.5,'#c8dcf0'],[.72,'#f6f4ff'],[1,'#dcd6f2']]),3);
 g.save();B();g.clip();
 // magenta-red rear half (below the stripe, nose of the red fades in softly)
 fa5_path(g,['M',60,-6,'Q',20,-8,-20,-4,'L',-70,-2,'L',-70,36,'L',8,38,'Q',40,34,60,-6,'Z']);g.fillStyle=fa5_grad(g,60,0,-60,0,[[0,'rgba(255,40,110,0)'],[.2,'rgba(255,40,110,.9)'],[.5,'#ff2a6e'],[1,'#d8185c']]);g.fill();
 g.fillStyle=fa5_grad(g,0,0,0,30,[[0,'rgba(255,170,210,.35)'],[.5,'rgba(255,170,210,0)'],[1,'rgba(90,0,50,.35)']]);g.fillRect(-70,0,130,32);
 // olive-gold sheen on the very top of the back
 g.fillStyle=fa5_grad(g,0,-34,0,-18,[[0,'rgba(190,200,120,.35)'],[1,'rgba(190,200,120,0)']]);g.fillRect(-70,-34,180,16);
 // faint spine showing through
 g.strokeStyle='rgba(180,220,255,.18)';g.lineWidth=1.2;g.beginPath();g.moveTo(66,2);g.quadraticCurveTo(0,4,-62,2);g.stroke();
 g.restore();
 fa5_tex(g,B,-62,96,-38,32,5.6,'#0c2a4a','#ffffff',.1);
 fkShade(g,B,-12,-34,'#06203a',.5);
 fkShade(g,B,12,30,'#5a2a7a',.26);
 // the neon stripe: wide soft glow, bright gradient core, white-hot centre line
 g.save();B();g.clip();g.save();g.globalCompositeOperation='lighter';g.lineJoin='round';
 for(const [w,a] of [[15,.2],[9,.34]]){S();g.strokeStyle=`rgba(60,230,255,${a*(.65+.55*pu)+gl*.15})`;g.lineWidth=w;g.stroke()}g.restore();
 S();g.fillStyle=fa5_grad(g,100,0,-62,0,[[0,'#b8feff'],[.3,'#5af6ff'],[.65,'#2ee0ff'],[1,'#4aa8ff']]);g.fill();
 g.save();S();g.clip();g.globalCompositeOperation='lighter';g.fillStyle=`rgba(80,250,255,${.1+.2*pu+gl*.2})`;g.fillRect(-70,-24,180,30);g.restore();
 g.save();S();g.clip();g.fillStyle=fa5_grad(g,0,-14,0,0,[[0,'rgba(255,255,255,.55)'],[1,'rgba(255,255,255,0)']]);g.fillRect(-70,-16,180,14);g.restore();
 S();g.strokeStyle='rgba(10,60,110,.55)';g.lineWidth=1;g.stroke();
 g.beginPath();for(let i=0;i<=26;i++){const c=stc(.04+i/26*.86);i?g.lineTo(c[0],c[1]-.6):g.moveTo(c[0],c[1]-.6)}g.lineCap='round';g.strokeStyle=`rgba(220,255,255,${.35+.25*pu})`;g.lineWidth=3.6;g.stroke();g.strokeStyle=`rgba(255,255,255,${.7+.3*pu})`;g.lineWidth=1.6;g.stroke();g.restore();
 // a pulse of light travelling nose to tail
 {const s=(t*.45)%1,c=stc(s);g.save();S();g.clip();g.globalCompositeOperation='lighter';g.fillStyle=fa5_rgrad(g,c[0],c[1],0,18,[[0,'rgba(200,255,255,.85)'],[1,'rgba(80,240,255,0)']]);g.fillRect(c[0]-20,c[1]-20,40,40);g.restore()}
 fa5_rim(g,B,'#bfe8ff','#ffb0d8',1,1.7);
 fa5_gloss(g,B,90,-21,50,-34,-20,-28,1.7,.55);
 fa5_gill2(g,B,99,1,25,Math.PI*.72,Math.PI*1.28,'#20345e',.5);
 fa5_pec2(g,62,14,-.3+fin,18,'#d8faff','#38bcff',.8);
 fa5_eye(g,83,1,13.5,'#2a9cff',.35);fa5_lid(g,83,1,13.5,fa5_blink(t,1.7),'#2c6488');
 fa5_blush(g,92,13,5,'#ff7ab0',.5);
 fa5_mouth(g,108,7,104,10,98,8,2,'#ff9ac8');
 fa5_spec(g,40,-24,.75,.9);
 {const s=(t*.45)%1,c=stc(s),k=Math.sin(Math.PI*s);fkSpark(g,c[0],c[1]-1,2.5+3.5*k,'#e8ffff',.4+.6*k)}
 fkSpark(g,-30,-12,2.4+fa5_tw(t,2,2.4)*1.6,'#bffaff',.3+.6*fa5_tw(t,2,2.4));
 fa5_catch(g,o,'#9af6ff');g.restore()};

/* ---------------- 5. Crystal Cavefish (Uncommon): a sleepy blind cavefish growing amethyst crystals ---------------- */
FISHART.cavefish=(g,t,o)=>{const sw=fkSway(o,3,.13),fin=Math.sin(t*3.6)*.1,gl=o.glow||0,pu=.5+.5*Math.sin(t*1.7);g.save();g.rotate(-sw*.18);
 const BP=[109,6,104,-10,87,-28,58,-39,20,-42,-18,-36,-46,-22,-62,-10,-66,0,-62,10,-46,20,-18,31,20,36,58,32,87,22,104,14],B=()=>fkPath(g,BP);
 fkGlow(g,4,-24,84,"#b46aff",.12+.07*pu+gl*.14);
 // tail: soft pink, gently forked, translucent with lilac tips
 const T=()=>fa5_path(g,['M',12,-6,'Q',-2,-8,-14,-17,'Q',-28,-28,-42,-36,'Q',-44,-24,-38,-14,'Q',-33,-6,-27,0,'Q',-33,6,-38,14,'Q',-44,24,-42,36,'Q',-28,28,-14,17,'Q',-2,8,12,6,'Z']);
 fa5_at(g,-60,0,sw,()=>{g.globalAlpha=.88;T();fkFill(g,fkLin(g,8,0,-44,0,['#ffcce4','#ffb0d8','#c890ff']),0);g.globalAlpha=1;
  fa5_ribs(g,T,8,0,[-42,-34,-39,-24,-33,-12,-33,12,-39,24,-42,34],.24,'#7a3a8a');
  fa5_finfx(g,T,9,0,'#ffffff',[-42,-30,-36,-18,-31,-6,-31,6,-36,18,-42,30],.9,0);
  T();g.lineJoin='round';g.lineWidth=2.5;g.strokeStyle=FKO;g.stroke()});
 const pf=(x,y,a,pp,ribs)=>fa5_at(g,x,y,a,()=>{const P=()=>fkPath(g,pp);g.globalAlpha=.88;fkFin(g,pp,'#ffd8ee','#c890ff',ribs,0);g.globalAlpha=1;fa5_finfx(g,P,0,0,'#ffffff',null,.85,0);P();g.lineJoin='round';g.lineWidth=2.2;g.strokeStyle=FKO;g.stroke()});
 pf(-20,29,-fin*.6,[12,-1,4,10,-12,14,-22,10,-20,-2],[[4,0,-4,11],[-4,0,-13,12],[-11,0,-19,9]]);
 pf(26,34,-fin,[7,-2,0,10,-11,12,-12,-2],[[0,0,-9,10]]);
 // body: pale pink-white, slightly see-through
 B();fkFill(g,fa5_grad(g,0,-36,0,32,[[0,'#d8a2e8'],[.2,'#f0c6ec'],[.42,'#ffe4f2'],[.62,'#fff4f8'],[.84,'#ffe2ef'],[1,'#eab8de']]),3);
 g.save();B();g.clip();
 // blush of blood showing through at the gills and a soft rosy core
 g.fillStyle=fa5_rgrad(g,76,6,0,26,[[0,'rgba(255,110,150,.4)'],[1,'rgba(255,110,150,0)']]);g.fillRect(46,-24,60,60);
 g.fillStyle=fa5_rgrad(g,20,8,0,40,[[0,'rgba(255,150,190,.22)'],[1,'rgba(255,150,190,0)']]);g.fillRect(-24,-34,90,80);
 // delicate skeleton visible through the skin
 g.strokeStyle='rgba(170,90,170,.24)';g.lineCap='round';g.lineWidth=1.8;g.beginPath();g.moveTo(80,-2);g.quadraticCurveTo(10,-6,-64,0);g.stroke();
 g.lineWidth=1;g.beginPath();for(let i=0;i<13;i++){const x=64-i*9.6,y=-4.6+i*.36;g.moveTo(x,y);g.quadraticCurveTo(x-3,y-10,x-7,y-17+i*.6);g.moveTo(x,y);g.quadraticCurveTo(x-3,y+9,x-7,y+18-i*.5)}g.strokeStyle='rgba(180,100,180,.13)';g.stroke();
 // pearly iridescent drift
 const sh=Math.sin(t*1.1)*30;g.globalAlpha=.14;g.fillStyle=fa5_grad(g,-60+sh,-20,80+sh,20,[[0,'#a8f0ff'],[.5,'#e0b8ff'],[1,'#ffd0e8']]);g.fillRect(-70,-36,190,70);g.globalAlpha=1;
 g.restore();
 fa5_tex(g,B,-64,90,-36,30,6,'#a05aa0','#ffffff',.12);
 fkShade(g,B,-8,-36,'#a860c8',.4);
 g.save();B();g.clip();g.globalCompositeOperation='lighter';g.fillStyle=fa5_rgrad(g,8,-36,0,46,[[0,`rgba(190,120,255,${.3+.15*pu+gl*.06})`],[1,'rgba(190,120,255,0)']]);g.fillRect(-50,-40,120,60);g.restore();
 fkShade(g,B,12,32,'#c080c8',.28);
 // bioluminescent freckles: soft cyan and violet dots that breathe
 g.save();B();g.clip();
 [[58,10,1.8,0],[44,15,2.2,1],[28,18,2,0],[12,20,2.3,1],[-4,19,2,0],[-20,17,2.1,1],[-34,13,1.8,0],[-48,9,1.5,1],[36,4,1.4,1],[4,7,1.5,0],[-26,5,1.4,1],[50,-6,1.3,0]].forEach((d,i)=>{const k=.45+.55*fa5_tw(t,i*1.3,1.9),c=d[3]?'#c88aff':'#6af4ff';
  g.globalAlpha=.22*k;g.fillStyle=c;g.beginPath();g.arc(d[0],d[1],d[2]*3.6,0,TAU);g.fill();g.globalAlpha=.4*k;g.beginPath();g.arc(d[0],d[1],d[2]*2,0,TAU);g.fill();g.globalAlpha=k;g.beginPath();g.arc(d[0],d[1],d[2],0,TAU);g.fill();g.globalAlpha=k;g.fillStyle='#fff';g.beginPath();g.arc(d[0],d[1],d[2]*.45,0,TAU);g.fill()});
 g.restore();g.globalAlpha=1;
 // lateral line: a faint, gently curved row of tiny glowing pores (no seam)
 g.save();B();g.clip();g.globalCompositeOperation='lighter';
 for(let i=0;i<17;i++){const u=.06+i/16*.86,v=1-u,x=v*v*62+2*v*u*14+u*u*-58,y=v*v*-6+2*v*u*-11+u*u*-1,k=.5+.5*fa5_tw(t*.8,i*.9,1.4),f=Math.sin(Math.PI*u);
  g.fillStyle=`rgba(200,120,255,${(.05+.05*k)*f})`;g.beginPath();g.arc(x,y,2.4,0,TAU);g.fill();g.fillStyle=`rgba(230,170,255,${(.14+.18*k)*f})`;g.beginPath();g.arc(x,y,.85,0,TAU);g.fill()}
 g.restore();
 fa5_rim(g,B,'#ffffff','#e8b8ff',1,1.8);
 fa5_gloss(g,B,92,-17,48,-31,-24,-25,1.8,.6);
 fa5_gill2(g,B,106,4,42,Math.PI*.8,Math.PI*1.2,'#a04a8a',.45);
 // amethyst crystal clusters rooted in dark rocky sockets sunk into the back
 const sock=(x,y,rx,ry,ro)=>{g.save();B();g.clip();fa5_at(g,x,y,ro,()=>{
   g.fillStyle=fa5_rgrad(g,0,ry*.9,0,rx*1.5,[[0,'rgba(150,70,150,.32)'],[1,'rgba(150,70,150,0)']]);g.beginPath();g.ellipse(0,ry*.9,rx*1.5,ry*2.1,0,0,TAU);g.fill();
   g.beginPath();g.ellipse(0,0,rx,ry,0,0,TAU);g.fillStyle=fa5_rgrad(g,0,-ry*.3,0,rx,[[0,'#2a0e3a'],[.55,'#4a2054'],[1,'#7a3a74']]);g.fill();
   g.fillStyle='rgba(200,150,220,.35)';for(const [px,py,r] of [[-.55,.25,.9],[.5,.4,.7],[-.15,.55,.6],[.75,.05,.55]]){g.beginPath();g.arc(px*rx,py*ry,r,0,TAU);g.fill()}})
  ;g.restore()};
 const embed=(x,y,rx,ry,ro)=>{g.save();B();g.clip();fa5_at(g,x,y,ro,()=>{g.beginPath();g.ellipse(0,0,rx,ry,0,0,TAU);g.save();g.clip();
   g.fillStyle=fa5_grad(g,0,-ry*.7,0,ry,[[0,'rgba(42,14,58,0)'],[.55,'rgba(42,14,58,.7)'],[1,'rgba(42,14,58,.95)']]);g.fillRect(-rx,-ry,rx*2,ry*2);g.restore();
   g.lineCap='round';g.beginPath();g.ellipse(0,0,rx,ry,0,Math.PI*.06,Math.PI*.94);g.strokeStyle='rgba(70,20,80,.6)';g.lineWidth=1.3;g.stroke();
   g.beginPath();g.ellipse(0,.4,rx+1.3,ry+1.5,0,Math.PI*.1,Math.PI*.9);g.strokeStyle='rgba(255,226,242,.7)';g.lineWidth=1.5;g.stroke();
   g.beginPath();g.ellipse(0,1,rx+2.6,ry+3,0,Math.PI*.18,Math.PI*.82);g.strokeStyle='rgba(150,60,140,.3)';g.lineWidth=1.6;g.stroke()});g.restore()};
 const cl=[[40,-35,-1.92,1],[6,-36,-1.68,1.2],[-25,-27,-2.08,.9]];
 cl.forEach((c,ci)=>{const [x,y,a,s]=c;g.save();g.globalCompositeOperation='lighter';g.fillStyle=fa5_rgrad(g,x,y-12*s,0,28*s,[[0,`rgba(190,110,255,${.32+.25*fa5_tw(t,ci,1.6)+gl*.2})`],[1,'rgba(190,110,255,0)']]);g.fillRect(x-30*s,y-42*s,60*s,60*s);g.restore()});
 cl.forEach(c=>{const [x,y,,s]=c;sock(x,y+1.5,12*s,5.2*s,0)});
 // small tapering cluster running down the back toward the tail, and a tiny bud near the head
 const tro=-.6;sock(-46,-17,10.5,4.2,tro);sock(64,-32.5,6,3,-.25);
 cl.forEach((c,ci)=>{const [x,y,a,s]=c,tw=k=>Math.max(0,Math.sin(t*1.3+ci*2.1+k*1.7))**6;
  fa5_gem(g,x-7*s,y+4,a-.45,17*s,6.4*s,'#f4dcff','#b06aec','#5a26a8',tw(0));
  fa5_gem(g,x+7*s,y+4,a+.5,15*s,6*s,'#f4dcff','#a85ae4','#4e1e9a',tw(2));
  fa5_gem(g,x,y+3,a,27*s,8.6*s,'#ffeaff','#c47cff','#6a2cba',tw(1))});
 for(const [x,y,a,L,w,i] of [[-39,-20,-2.05,15,5.4,0],[-34,-22,-1.55,8,3.6,3],[-47,-15.5,-2.25,11,4.4,1],[-53.5,-12,-2.45,7,3.2,2],[63,-30,-1.45,9,4,5],[67,-29.5,-1.05,6,3,6]])
  fa5_gem(g,x,y,a,L,w,'#f4dcff','#b06aec','#5a26a8',Math.max(0,Math.sin(t*1.1+i*2.4))**8);
 cl.forEach(c=>{const [x,y,,s]=c;embed(x,y+1.5,12*s,5.2*s,0)});
 embed(-46,-17,10.5,4.2,tro);embed(64,-32.5,6,3,-.25);
 // pectoral fin
 fa5_pec2(g,66,13,-.3+fin*1.3,20,'#ffd0ea','#b07aff',.85);
 // closed, sleepy eye: a soft socket, a curved lid line and three little lashes
 g.save();B();g.clip();g.fillStyle=fa5_rgrad(g,80,-2,0,11,[[0,'rgba(190,110,165,.34)'],[.6,'rgba(210,140,185,.16)'],[1,'rgba(220,150,190,0)']]);g.beginPath();g.ellipse(80,-3,11,6.5,0,0,Math.PI);g.fill();g.restore();
 const bl=Math.sin(t*.9)*.6;
 g.beginPath();g.moveTo(71,-6+bl*.2);g.quadraticCurveTo(80,1.5+bl,89,-6+bl*.2);g.strokeStyle=FKO;g.lineWidth=2.6;g.lineCap='round';g.stroke();
 g.lineWidth=1.8;g.beginPath();g.moveTo(74.5,-2.2+bl*.6);g.lineTo(72.6,.6+bl*.6);g.moveTo(80,-1.8+bl);g.lineTo(80,1.6+bl);g.moveTo(85.5,-2.2+bl*.6);g.lineTo(87.4,.6+bl*.6);g.stroke();
 fa5_blush(g,90,9,6.5,'#ff7ab0',.6);
 fa5_mouth(g,109,8,105,12,99,10,2,'#ff9ac0');
 fa5_spec(g,30,-24,.8,.9);
 // sleepy bubbles drifting up
 for(let k=0;k<2;k++){const p=(t*.32+k*.5)%1,x=112-p*8+Math.sin(p*9+k)*2,y=-4-p*58,r=1.8+p*2.6+k;g.globalAlpha=Math.sin(Math.PI*p)*.85;g.beginPath();g.arc(x,y,r,0,TAU);g.strokeStyle='#f4e4ff';g.lineWidth=1.2;g.stroke();g.beginPath();g.arc(x-r*.35,y-r*.35,r*.28,0,TAU);g.fillStyle='#fff';g.fill();g.globalAlpha=1}
 fkSpark(g,6,-62,3+fa5_tw(t,1,2)*3,'#f4dcff',.4+.5*fa5_tw(t,1,2));
 fkSpark(g,-34,-48,2+fa5_tw(t,4,2.3)*2.4,'#e8c8ff',.3+.5*fa5_tw(t,4,2.3));
 fa5_catch(g,o,"#e8c4ff",.6);g.restore()};

/* ---------------- 6. Lumenwyrm (Legendary): a colossal bioluminescent dragon-eel coiled in an S ---------------- */
let fa5_wyC=null;
FISHART.wyrm=(g,t,o)=>{const fx=o.flex||0,gl=o.glow||0,pu=.5+.5*Math.sin(t*1.8),M=220;g.save();g.scale(.95,.95);
 if(!fa5_wyC){const cp=[58,-45,40,-55,12,-59,-18,-56,-45,-48,-65,-33,-72,-14,-63,2,-40,7,-6,11,26,16,50,23,70,32,81,46,77,61,58,71,30,73,0,72,-30,69,-58,63,-80,56];
  const P=fa5_spline(cp,M);fa5_wyC={P,N:fa5_norms(P)}}
 const BP=fa5_wyC.P,BN=fa5_wyC.N,ss=(a,b,x)=>{x=Math.min(1,Math.max(0,(x-a)/(b-a)));return x*x*(3-2*x)};
 // travelling swim ripple (bigger and quicker when thrashing), fading out toward the head so the face stays steady
 const A=(2.2+fx*2.6),sp=2.2*(1+fx*1.4),P=[];
 for(let i=0;i<M;i++){const s=i/(M-1),e=ss(.02,.25,s)*(1-.35*ss(.85,1,s)),r=A*e*Math.sin(s*15-t*sp);P.push([BP[i][0]+BN[i][0]*r,BP[i][1]+BN[i][1]*r])}
 const N=fa5_norms(P),at=s=>{const f=Math.max(0,Math.min(M-1,s*(M-1))),i=Math.min(M-2,Math.floor(f)),u=f-i;return [P[i][0]+(P[i+1][0]-P[i][0])*u,P[i][1]+(P[i+1][1]-P[i][1])*u,N[i][0],N[i][1]]};
 const K=[];for(let i=0;i<M;i++){const a=P[Math.max(0,i-4)],b=P[i],c=P[Math.min(M-1,i+4)],dx=c[0]-a[0],dy=c[1]-a[1],ddx=c[0]-2*b[0]+a[0],ddy=c[1]-2*b[1]+a[1],d=Math.hypot(dx,dy)||1;K.push(4*(dx*ddy-dy*ddx)/Math.pow(d,3))}
 const KP=K.map((v,i)=>{let a=0,b=0;for(let j=-7;j<=7;j++){const q=K[Math.max(0,Math.min(M-1,i+j))];a=Math.max(a,q);b=Math.min(b,q)}return [a,-b]});
 const W=s=>(16.5-2*ss(0,.12,s))*(1-.5*Math.pow(s,1.25))*Math.pow(1-ss(.9,1.03,s),.5)+1.4;
 // ribbon outline with separate back/belly offsets, capped on the inside of bends so nothing folds
 const rib=(fb,fu,step)=>{const L=[],R=[],B=[],U=[];step=step||1;for(let i=0;i<M;i++){const s=i/(M-1),kp=KP[i];let b=fb(s),u=fu(s);
   if(kp[0]>0&&b>0)b=Math.min(b,.72/kp[0]);if(kp[1]>0&&u>0)u=Math.min(u,.72/kp[1]);B.push(b);U.push(u)}
  const sm=(A)=>A.map((v,i)=>{let a=0,n=0;for(let j=-4;j<=4;j++){const q=A[Math.max(0,Math.min(M-1,i+j))];a+=Math.min(q,v+3);n++}return Math.min(v,a/n+.5)});
  const B2=sm(B),U2=sm(U);for(let i=0;i<M;i+=step){L.push(P[i][0]+N[i][0]*B2[i],P[i][1]+N[i][1]*B2[i]);R.unshift(P[i][0]-N[i][0]*U2[i],P[i][1]-N[i][1]*U2[i])}
  if((M-1)%step){const i=M-1;L.push(P[i][0]+N[i][0]*B2[i],P[i][1]+N[i][1]*B2[i]);R.unshift(P[i][0]-N[i][0]*U2[i],P[i][1]-N[i][1]*U2[i])}return L.concat(R)};
 const ptsB=rib(W,W),BD=()=>fa5_poly(g,ptsB);
 // head frame (steady, with a proud toss when thrashing)
 const h0=at(0),h1=at(.025),ha=Math.atan2(h0[1]-h1[1],h0[0]-h1[0])*.25-.06+Math.sin(t*1.3)*.035+fx*Math.sin(t*7)*.12;
 /* aura */
 fkGlow(g,0,4,128,'#3a2aff',.16+.06*pu+gl*.35);
 fkGlow(g,-20,-10,80,'#28d8ff',.07+.05*pu+gl*.25);
 /* ---- far wing (behind the body) ---- */
 const wing=(far)=>{const r=at(.215),wa=Math.atan2(-r[3],-r[2]),fl=Math.sin(t*2.1+(far?.6:0))*.13*(1+fx*1.5);
  fa5_at(g,r[0]-r[2]*8,r[1]-r[3]*8,wa+(far?-.12:.38)+fl,()=>{const sc=far?.84:1;g.scale(sc,sc);
   // finger rays fanning back (local +x points away from the body on the belly side, rotated so the wing sweeps toward the tail)
   const tips=[[40,-30],[50,-12],[50,8],[38,24]],F=()=>{g.beginPath();g.moveTo(0,-8);g.quadraticCurveTo(18,-30,tips[0][0],tips[0][1]);
    for(let i=1;i<tips.length;i++){const a=tips[i-1],b=tips[i];g.quadraticCurveTo((a[0]+b[0])/2-9,(a[1]+b[1])/2,b[0],b[1])}g.quadraticCurveTo(16,22,0,8);g.closePath()};
   g.globalAlpha=far?.75:.86;F();fkFill(g,far?fa5_grad(g,0,0,50,0,[[0,'#2a1a72'],[1,'#5a3ab0']]):fa5_grad(g,0,-20,50,20,[[0,'#6a3ae0'],[.5,'#9a6aff'],[1,'#5ae8ff']]),0);g.globalAlpha=1;
   g.save();F();g.clip();
   if(!far){g.globalCompositeOperation='lighter';g.lineJoin='round';F();g.strokeStyle=`rgba(110,240,255,${.35+.25*pu+gl*.2})`;g.lineWidth=7;g.stroke();g.globalCompositeOperation='source-over'}
   g.fillStyle=fa5_rgrad(g,0,0,0,30,[[0,'rgba(20,6,50,.45)'],[1,'rgba(20,6,50,0)']]);g.fillRect(-30,-40,70,80);
   if(!far){g.strokeStyle='rgba(200,240,255,.28)';g.lineWidth=.9;for(let r=18;r<48;r+=9){g.beginPath();g.arc(0,0,r,-.95,.75);g.stroke()}
    g.globalCompositeOperation='lighter';[[30,-14],[36,0],[28,12],[20,-2],[40,-22]].forEach((d,i)=>{const k=.5+.5*fa5_tw(t,i*1.9,2.2);g.fillStyle=`rgba(120,240,255,${.22*k})`;g.beginPath();g.arc(d[0],d[1],4.2,0,TAU);g.fill();g.fillStyle=`rgba(230,255,255,${.8*k})`;g.beginPath();g.arc(d[0],d[1],1.3,0,TAU);g.fill()});g.globalCompositeOperation='source-over'}
   g.restore();
   // bony finger rays, gold
   for(const p of tips){g.beginPath();g.moveTo(2,0);g.quadraticCurveTo(p[0]*.38+4,p[1]*.5-7,p[0],p[1]);g.strokeStyle=FKO;g.lineWidth=far?2.6:3.4;g.lineCap='round';g.stroke();g.strokeStyle=far?'#8a6a9a':'#ffd36a';g.lineWidth=far?1.2:1.6;g.stroke()}
   F();g.lineJoin='round';g.lineWidth=2.4;g.strokeStyle=FKO;g.stroke();
   if(!far)for(let i=0;i<tips.length;i++){const p=tips[i],k=fa5_tw(t,i*1.7,2.6);g.beginPath();g.arc(p[0],p[1],2.4,0,TAU);g.fillStyle='#fff2b0';g.fill();g.lineWidth=1.3;g.strokeStyle=FKO;g.stroke();fkSpark(g,p[0],p[1],2+3*k,'#ffffff',.3+.6*k)}})};
 wing(1);
 /* ---- the ribbon mane: a long crimson-to-gold dorsal fin flowing down the whole back ---- */
 const mw=s=>(13.5-7*s)*ss(.03,.1,s)*(1-ss(.9,.995,s))*(1+.14*Math.sin(s*58-t*4.2*(1+fx)));
 const lay=[[1,'#ffd25e'],[.82,'#ffa634'],[.64,'#ff6a2c'],[.44,'#e8283e'],[.26,'#b80e3c']];
 for(const [f,c] of lay){const Q=rib(s=>W(s)+mw(s)*f,s=>W(s)*.3,2);g.beginPath();fa5_poly(g,Q);g.fillStyle=c;g.fill()}
 {const Q=rib(s=>W(s)+mw(s),s=>W(s)*.3,2),MN=()=>fa5_poly(g,Q);
  g.save();MN();g.clip();g.lineCap='round';
  // fin rays slanting back, with fine golden glints between
  for(let i=4;i<M-6;i+=3){const s=i/(M-1),w=W(s),m=mw(s);if(m<1)continue;let tot=w+m;if(KP[i][0]>0)tot=Math.min(tot,.85/KP[i][0]);const j=Math.min(M-1,i+3),x0=P[i][0]+N[i][0]*w*.95,y0=P[i][1]+N[i][1]*w*.95,x1=P[j][0]+N[j][0]*tot,y1=P[j][1]+N[j][1]*tot;
   g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.strokeStyle='rgba(110,8,30,.42)';g.lineWidth=1.1;g.stroke()}
  g.globalCompositeOperation='lighter';MN();g.strokeStyle=`rgba(255,226,120,${.4+.2*pu})`;g.lineWidth=3.2;g.stroke();g.restore();
  MN();g.lineJoin='round';g.lineWidth=2.2;g.strokeStyle=FKO;g.stroke()}
 /* ---- body ---- */
 BD();fkFill(g,fa5_grad(g,-80,-60,80,70,[[0,'#2a2296'],[.5,'#22197a'],[1,'#2c1f8e']]),3.2);
 const band=(o0,o1,col,a)=>{const Q=rib(s=>W(s)*o1,s=>-W(s)*o0,2);g.save();BD();g.clip();g.beginPath();fa5_poly(g,Q);g.fillStyle=col;g.globalAlpha=a;g.fill();g.restore();g.globalAlpha=1};
 band(.25,1.1,'#100a4a',.55);band(.6,1.1,'#0a0634',.5);
 // dragon belly plates: pale periwinkle scutes along the underside
 {const Q=rib(s=>-W(s)*.3,s=>W(s)*1.1,2);g.save();BD();g.clip();g.beginPath();fa5_poly(g,Q);g.fillStyle='#7c70e6';g.fill();g.beginPath();fa5_poly(g,rib(s=>-W(s)*.62,s=>W(s)*1.1,2));g.fillStyle='rgba(170,160,255,.5)';g.fill();
  g.lineCap='round';for(let i=10;i<M-4;i+=4){const s=i/(M-1),w=W(s);g.beginPath();g.moveTo(P[i][0]-N[i][0]*w*.32,P[i][1]-N[i][1]*w*.32);g.lineTo(P[i][0]-N[i][0]*w*1.05,P[i][1]-N[i][1]*w*1.05);g.strokeStyle='rgba(30,16,90,.5)';g.lineWidth=1.1;g.stroke()}
  g.beginPath();for(let i=8;i<M;i+=2){const s=i/(M-1),w=W(s)*.33;i===8?g.moveTo(P[i][0]-N[i][0]*w,P[i][1]-N[i][1]*w):g.lineTo(P[i][0]-N[i][0]*w,P[i][1]-N[i][1]*w)}g.strokeStyle='rgba(20,10,70,.55)';g.lineWidth=1.3;g.stroke();g.restore()}
 // fine scale texture and stardust
 fa5_speck(g,BD,-90,80,-75,75,140,'#b8b0ff',.35,.6,11);
 // glowing chevron light bands rippling from head to tail, alternating cyan and violet
 g.save();BD();g.clip();g.lineCap='round';g.lineJoin='round';
 for(let b=0;b<22;b++){const s=.06+b*.041;if(s>.97)break;const i=Math.round(s*(M-1)),j=Math.min(M-1,i+5),w=W(s),wj=W(j/(M-1)),wave=Math.max(0,Math.sin(s*12-t*3.1*(1+fx*.6))),k=.3+.7*wave*wave,c=b%2?'#c27cff':'#4ff2ff';
  const ch=()=>{g.beginPath();g.moveTo(P[j][0]+N[j][0]*wj*1.1,P[j][1]+N[j][1]*wj*1.1);g.quadraticCurveTo(P[i][0]-N[i][0]*w*.1,P[i][1]-N[i][1]*w*.1,P[j][0]-N[j][0]*wj*.45,P[j][1]-N[j][1]*wj*.45)};
  g.globalCompositeOperation='lighter';ch();g.strokeStyle=fa5_rgba(c,.22*k+gl*.1);g.lineWidth=Math.max(3,w*.75);g.stroke();
  ch();g.strokeStyle=fa5_rgba(c,.75*k+.1);g.lineWidth=Math.max(1.2,w*.2);g.stroke();
  g.globalCompositeOperation='source-over';ch();g.strokeStyle=`rgba(255,255,255,${.55*k})`;g.lineWidth=Math.max(.6,w*.06);g.stroke()}
 // luminous lateral line of photophores
 for(let b=0;b<34;b++){const s=.05+b*.027;if(s>.95)break;const i=Math.round(s*(M-1)),w=W(s),x=P[i][0]-N[i][0]*w*.15,y=P[i][1]-N[i][1]*w*.15,k=.4+.6*Math.max(0,Math.sin(s*12-t*3.1*(1+fx*.6)+1.4)),r=Math.max(.7,w*.1);
  g.globalAlpha=.35*k;g.fillStyle='#8af8ff';g.beginPath();g.arc(x,y,r*2.6,0,TAU);g.fill();g.globalAlpha=k;g.fillStyle='#ffffff';g.beginPath();g.arc(x,y,r,0,TAU);g.fill()}
 g.restore();g.globalAlpha=1;
 // moonlight on the back, glow under the belly
 g.save();BD();g.clip();g.translate(-1.6,-2.2);BD();g.strokeStyle='rgba(200,190,255,.4)';g.lineWidth=2.4;g.stroke();g.restore();
 fa5_rim(g,BD,null,'#6ae8ff',.8,1.6);
 /* ---- tail fan: a flowing crimson-to-gold flame of ribbons ---- */
 {const e=at(1),e2=at(.95),ta=Math.atan2(e[1]-e2[1],e[0]-e2[0]),wv=Math.sin(t*2.4)*(1+fx*2),wq=Math.sin(t*2.4-1)*(1+fx*2);
  fa5_at(g,e[0]-Math.cos(ta)*7,e[1]-Math.sin(ta)*7,ta,()=>{
   const F=()=>fa5_path(g,['M',-6,-7,'C',6,-14,14,-24,22+wv*2,-33,'C',22,-21,26,-14,34+wv*3,-13,'C',29,-6,31,1,38+wq*3,2,'C',30,7,28,13,33+wq*3,22,'C',22,18,14,22,10,31-wq*2,'C',6,18,0,10,-6,7,'Z']);
   F();fkFill(g,fa5_grad(g,0,0,38,0,[[0,'#c40e3a'],[.4,'#ff5a2a'],[.75,'#ffb03a'],[1,'#ffe27a']]),2.4);
   fa5_ribs(g,F,-2,0,[22,-31,30,-20,34,-12,37,-4,37,2,33,12,32,20,20,24,11,29],.3,'#6a0820');
   fa5_finfx(g,F,-2,0,'#fff2a0',null,.9,0);
   g.save();F();g.clip();g.globalCompositeOperation='lighter';g.fillStyle=fa5_grad(g,0,0,40,0,[[0,'rgba(255,200,80,0)'],[1,`rgba(255,220,120,${.28+.22*pu+gl*.2})`]]);g.fillRect(-8,-36,52,70);g.restore();
   for(const [x,y,i] of [[22,-31,0],[37,1,1],[10,29,2]]){const k=fa5_tw(t,i*2.3,2.6);fkSpark(g,x,y,2+3*k,'#fff6c8',.3+.6*k)}})}
 /* ---- near wing ---- */
 wing(0);
 /* ---- head ---- */
 {const hb=-11,hx=h0[0]+Math.cos(ha)*hb,hy=h0[1]+Math.sin(ha)*hb;
 fa5_at(g,hx,hy,ha,()=>{const wv=Math.sin(t*2.2),fl=fx*Math.sin(t*8)*.1;g.scale(1.32,1.32);
  // mane: four distinct crimson-to-gold ribbons flowing back from the nape along the top run
  const mn=[[-12,-13,-70,-18,0,6],[-16,-9,-66,-8,1.3,6.4],[-20,-4,-60,2,2.6,5.8],[-23,1,-50,10,3.9,4.6]];
  for(const [x0,y0,x1,y1,ph,w0] of mn){const dx=x1-x0,dy=y1-y0,d=Math.hypot(dx,dy),nx=-dy/d,ny=dx/d;
   const Q=fa5_rib(28,u=>{const o=(Math.sin(u*Math.PI*1.7-t*2.6*(1+fx)+ph)*2.6*u+Math.sin(Math.PI*u)*-3)*(1+fx*.8);return [x0+dx*u+nx*o,y0+dy*u+ny*o,(w0*(1-u)+1.2*u)/2]}),R=()=>fa5_poly(g,Q);
   R();g.fillStyle=fa5_grad(g,x0,y0,x1,y1,[[0,'#d40c3a'],[.35,'#ff3a36'],[.68,'#ff8a24'],[.92,'#ffd24a'],[1,'#fff2a8']]);g.fill();
   g.save();R();g.clip();g.globalCompositeOperation='lighter';g.beginPath();for(let i=0;i<=20;i++){const u=i/20,o=(Math.sin(u*Math.PI*1.7-t*2.6*(1+fx)+ph)*2.6*u+Math.sin(Math.PI*u)*-3)*(1+fx*.8)-(w0*(1-u)+1.2*u)*.22;const px=x0+dx*u+nx*o,py=y0+dy*u+ny*o;i?g.lineTo(px,py):g.moveTo(px,py)}g.strokeStyle=`rgba(255,230,150,${.45+.2*pu})`;g.lineWidth=1.1;g.stroke();g.restore();
   R();g.lineJoin='round';g.lineWidth=1.7;g.strokeStyle=FKO;g.stroke();
   const e=Q.length/2-1,tx=(Q[e-1]+Q[e+1])/2,ty=(Q[e]+Q[e+2])/2,k=fa5_tw(t,ph*3,2.4);fkSpark(g,tx,ty,2+2.4*k,'#fff2b0',.35+.6*k)}
  // swept-back glowing horns from the skull
  const hn=[[-9,-13,-48,-19,7.4],[1,-16,-35,-27,6.8]];
  for(const [rx,ry,ex,ey,hw] of hn){const q=[rx,ry,rx-5,ry-11,ex+15,ey-3,ex,ey];
   g.save();g.globalCompositeOperation='lighter';g.lineCap='round';g.beginPath();g.moveTo(rx,ry);g.bezierCurveTo(rx-5,ry-11,ex+15,ey-3,ex,ey);g.strokeStyle=`rgba(90,230,255,${.18+.14*pu+gl*.15})`;g.lineWidth=hw*2.2;g.stroke();g.restore();
   fa5_strand(g,q,hw,1,fa5_grad(g,rx,ry,ex,ey,[[0,'#5a8ae8'],[.3,'#9ad8ff'],[.7,'#e4fdff'],[1,'#ffffff']]),1.8);
   g.save();g.globalCompositeOperation='lighter';g.beginPath();g.moveTo(rx-1,ry-1);g.bezierCurveTo(rx-5,ry-12,ex+15,ey-4,ex+1,ey-.6);g.strokeStyle=`rgba(150,250,255,${.55+.3*pu})`;g.lineWidth=1.1;g.stroke();g.restore();
   g.strokeStyle='rgba(60,40,140,.5)';g.lineWidth=.9;for(let k=1;k<5;k++){const u=k/5,v=1-u,x=v*v*v*rx+3*v*v*u*(rx-5)+3*v*u*u*(ex+15)+u*u*u*ex,y=v*v*v*ry+3*v*v*u*(ry-11)+3*v*u*u*(ey-3)+u*u*u*ey,r=hw*(1-u*.85)*.5;g.beginPath();g.moveTo(x-r*.6,y+r*.8);g.lineTo(x+r*.6,y-r*.8+1);g.stroke()}
   const k=.5+.5*Math.sin(t*2.4+rx);fkGlow(g,ex,ey,6,'#aaf8ff',.5*k+.2);fkSpark(g,ex,ey,1.6+2*k,'#ffffff',.4+.5*k)}
  // gill crest: a clean fan behind the jaw
  fa5_at(g,-19,5,wv*.08+fl,()=>{const F=()=>fkPath(g,[3,-7,-9,-15,-8,-8,-17,-8,-9,-1,-17,4,-8,6,-12,13,3,7]);F();fkFill(g,fa5_grad(g,3,0,-17,0,[[0,'#ffd25e'],[.5,'#ff7a2a'],[1,'#d8183e']]),1.8);
   fa5_ribs(g,F,3,0,[-9,-14,-16,-7,-16,4,-11,12],.38,'#6a0820');fa5_finfx(g,F,3,0,'#fff2a0',null,.8,0)});
  // skull: long dragon snout, angular brow, strong jaw
  const HP=[52,1,49,7,38,10,24,15,8,19,-10,19,-22,14,-26,1,-23,-11,-13,-17,0,-20,12,-18,24,-12,36,-8,46,-5,51,-3],H=()=>fkPath(g,HP);
  H();fkFill(g,fa5_grad(g,0,-20,0,19,[[0,'#3a2cb0'],[.4,'#2a2096'],[.7,'#4a3ac8'],[1,'#8a7cf0']]),2.6);
  g.save();H();g.clip();
  // lower jaw: lighter plated underside below a clear jaw line
  fa5_path(g,['M',52,4,'Q',30,9,6,8,'Q',-8,9,-18,14,'L',-18,24,'L',56,24,'Z']);g.fillStyle=fa5_grad(g,0,6,0,19,[[0,'#5a4ad8'],[1,'#9a8cff']]);g.fill();
  g.strokeStyle='rgba(30,16,90,.4)';g.lineWidth=.9;for(let x=-10;x<40;x+=6){g.beginPath();g.moveTo(x,10.5+(x<6?(6-x)*.2:0));g.lineTo(x-1,19);g.stroke()}
  g.fillStyle=fa5_grad(g,0,-20,0,-8,[[0,'rgba(10,6,50,.45)'],[1,'rgba(10,6,50,0)']]);g.fillRect(-26,-20,80,12);
  // glowing facial markings echo the body's light bands
  g.globalCompositeOperation='lighter';g.lineCap='round';
  g.beginPath();g.moveTo(44,-4.5);g.quadraticCurveTo(36,-7,28,-8.5);g.moveTo(-3,-4);g.quadraticCurveTo(-12,0,-17,8);g.moveTo(1,4);g.quadraticCurveTo(-6,8,-10,12);
  g.strokeStyle=`rgba(80,240,255,${.28+.25*pu+gl*.2})`;g.lineWidth=4.2;g.stroke();g.strokeStyle=`rgba(210,255,255,${.7+.2*pu})`;g.lineWidth=1.2;g.stroke();
  for(const [x,y] of [[33,-9.5],[38,-8],[-14,2]]){g.fillStyle='rgba(200,140,255,.8)';g.beginPath();g.arc(x,y,1.1,0,TAU);g.fill()}
  g.globalCompositeOperation='source-over';
  fa5_speck(g,H,-24,52,-20,18,44,'#c0b8ff',.35,.5,4);
  g.restore();
  fa5_gloss(g,H,44,-6,22,-14,-8,-15,1.5,.45);
  fa5_rim(g,H,null,'#8af0ff',.8,1.3);
  // angular brow ridge (lit, not a dark slab) sweeping back into the horn roots
  {const BR=()=>fa5_poly(g,[1,-15.5,9,-19.5,22,-15.5,30,-10.5,23,-11.6,12,-14.6,4,-12.8]);BR();g.fillStyle=fa5_grad(g,0,-19,0,-11,[[0,'#8a7cff'],[1,'#4a3ac8']]);g.fill();
   g.beginPath();g.moveTo(3,-16);g.lineTo(9,-19);g.lineTo(22,-15.3);g.strokeStyle='rgba(220,230,255,.75)';g.lineWidth=1;g.stroke();BR();g.lineJoin='round';g.strokeStyle=FKO;g.lineWidth=1.5;g.stroke()}
  // nostrils
  for(const [x,y,r] of [[47,-3.2,1.6],[42.5,-4.6,1.2]]){g.beginPath();g.ellipse(x,y,r*1.4,r*.7,-.35,0,TAU);g.fillStyle='#0c0630';g.fill();g.save();g.globalCompositeOperation='lighter';g.fillStyle=`rgba(90,230,255,${.25+.2*pu})`;g.beginPath();g.arc(x,y,r*2.2,0,TAU);g.fill();g.restore()}
  g.beginPath();g.moveTo(40,-7);g.quadraticCurveTo(45,-7.5,49.5,-5);g.strokeStyle='rgba(20,10,60,.55)';g.lineWidth=1;g.stroke();
  // jaw line and mouth with clear fangs
  g.lineCap='round';g.beginPath();g.moveTo(6,7.5);g.quadraticCurveTo(-6,9,-16,14.5);g.strokeStyle='rgba(18,8,50,.7)';g.lineWidth=1.6;g.stroke();
  g.beginPath();g.moveTo(50,5);g.quadraticCurveTo(30,10.5,14,10);g.strokeStyle='rgba(255,130,170,.45)';g.lineWidth=1.6;g.stroke();
  for(const [x,l,w] of [[41,8.4,4.2],[27.5,6.6,3.6]]){g.beginPath();g.moveTo(x,5.6);g.quadraticCurveTo(x-.6,5.6+l*.6,x-w*.45,5.6+l);g.quadraticCurveTo(x-w*.75,5.6+l*.45,x-w,5.8);g.closePath();g.fillStyle=fa5_grad(g,0,5.6,0,5.6+l,[[0,'#ffffff'],[1,'#e6e0ff']]);g.fill();g.lineWidth=1;g.strokeStyle=FKO;g.stroke()}
  g.beginPath();g.moveTo(34,9);g.lineTo(32.6,5.4);g.lineTo(31,9);g.fillStyle='#f4f0ff';g.fill();g.lineWidth=.8;g.strokeStyle=FKO;g.stroke();
  g.beginPath();g.moveTo(51.5,2.8);g.quadraticCurveTo(30,7.6,14,7);g.quadraticCurveTo(8,6.6,5,4.2);g.strokeStyle=FKO;g.lineWidth=2.1;g.stroke();
  // luminous dragon eye: cyan-to-white iris, slit pupil, pulsing halo
  {const ex=14,ey=-7.5;
   g.save();g.globalCompositeOperation='lighter';g.fillStyle=fa5_rgrad(g,ex,ey,0,19,[[0,`rgba(170,255,255,${.5+.3*pu+gl*.3})`],[.35,`rgba(60,225,255,${.24+.18*pu+gl*.2})`],[1,'rgba(40,200,255,0)']]);g.beginPath();g.arc(ex,ey,19,0,TAU);g.fill();g.restore();
   const E=()=>{g.beginPath();g.moveTo(ex-8,ey+1.4);g.quadraticCurveTo(ex-1.5,ey-9.6,ex+8.6,ey-2.4);g.quadraticCurveTo(ex+1.5,ey+7.6,ex-8,ey+1.4);g.closePath()};
   E();g.fillStyle=fa5_rgrad(g,ex+.6,ey-1,0,8.6,[[0,'#ffffff'],[.28,'#e4ffff'],[.55,'#62f2ff'],[.85,'#18a6dc'],[1,'#0a4a86']]);g.fill();
   g.save();E();g.clip();g.beginPath();g.ellipse(ex+.9,ey-1,1.35,6,.2,0,TAU);g.fillStyle='#061032';g.fill();
   g.globalCompositeOperation='lighter';g.beginPath();g.ellipse(ex+.9,ey-.9,2.5,6.2,.2,0,TAU);g.strokeStyle=`rgba(200,255,255,${.45+.35*pu})`;g.lineWidth=.9;g.stroke();
   g.strokeStyle=`rgba(255,255,255,${.25+.2*pu})`;g.lineWidth=.6;g.beginPath();for(let i=0;i<8;i++){const a=i/8*TAU;g.moveTo(ex+.9+Math.cos(a)*3,ey-.9+Math.sin(a)*3.6);g.lineTo(ex+.9+Math.cos(a)*6.5,ey-.9+Math.sin(a)*6.5)}g.stroke();g.restore();
   E();g.lineJoin='round';g.lineWidth=1.8;g.strokeStyle=FKO;g.stroke();
   g.fillStyle='#fff';g.beginPath();g.ellipse(ex+3.8,ey-3,1.5,1,-.4,0,TAU);g.fill();g.beginPath();g.arc(ex-3,ey+1.4,.6,0,TAU);g.fill()}
  // long whiskers drooping from the snout in lazy S-curls, pearl tips that glow
  for(const [b,ph,w0] of [[[44,7,47,14,43,21,35,24,26,27,18,20,6,28,-4,35,-8,43,-20,41],0,3],[[36,9,38,15,32,20,24,20,16,20,12,28,2,31],1.4,2.3]]){
   const q=b.slice(),w1=Math.sin(t*1.7+ph)*(1+fx*1.6);for(let i=2;i<q.length;i+=2){const u=i/q.length;q[i]+=w1*5*u;q[i+1]+=Math.sin(t*1.7+ph-u*2)*2.2*u*(1+fx)}
   const n=q.length,ex=q[n-2],ey=q[n-1];fa5_strand(g,q,w0,.7,fa5_grad(g,q[0],q[1],ex,ey,[[0,'#ffe8a0'],[.6,'#bff6e0'],[1,'#7af4ff']]),1.4);
   fkGlow(g,ex,ey,7,'#7af4ff',.45+.3*pu);g.beginPath();g.arc(ex,ey,1.8,0,TAU);g.fillStyle='#effeff';g.fill();g.lineWidth=1;g.strokeStyle=FKO;g.stroke()}
 })}
 /* ---- sparkles drifting around the coil ---- */
 g.save();g.globalCompositeOperation='lighter';
 for(let i=0;i<7;i++){const p=(t*.09+i/7)%1,x=-90+i*27+Math.sin(t*.8+i*2)*6,y=70-p*150,k=Math.sin(Math.PI*p),c=i%2?'200,140,255':'110,240,255';
  g.fillStyle=fa5_rgrad(g,x,y,0,7,[[0,`rgba(${c},${.55*k})`],[1,`rgba(${c},0)`]]);g.beginPath();g.arc(x,y,7,0,TAU);g.fill();g.fillStyle=`rgba(255,255,255,${.85*k})`;g.beginPath();g.arc(x,y,1.3,0,TAU);g.fill()}
 g.restore();
 for(let i=0;i<8;i++){const s=(i/8+t*.03)%1,p=at(s),k=fa5_tw(t,i*1.3,2.2),off=W(s)+14+6*Math.sin(t+i),sg=i%2?1:-1;
  fkSpark(g,p[0]+p[2]*off*sg,p[1]+p[3]*off*sg,2+3.2*k,i%3?'#d8f8ff':'#ffe8a0',.25+.65*k)}
 fa5_catch(g,o,'#a8b8ff',1.2);g.restore()};
