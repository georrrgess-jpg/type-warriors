/* ===== WILDCARD: scan-to-join with the camera, for rooms with no internet =====
   The offline invite and reply codes are shown as QR codes; the other device points its camera at the screen.
   Uses the browser's BarcodeDetector where it exists, and otherwise this small QR reader (versions 1-20, level L,
   byte mode — exactly what wcQR makes): adaptive threshold -> finder patterns -> perspective grid (with the
   alignment pattern) -> format and version bits -> unmask -> Reed-Solomon error correction -> text. */
/* --- GF(256) Reed-Solomon decoding (Berlekamp-Massey, Chien search, Forney) --- */
const wcgM=(a,b)=>a&&b?WCQ_EXP[WCQ_LOG[a]+WCQ_LOG[b]]:0,wcgI=a=>WCQ_EXP[255-WCQ_LOG[a]];
function wcRSFix(cw,nec){const n=cw.length,S=[];let bad=false;for(let i=0;i<nec;i++){let s=0;for(let j=0;j<n;j++)s=wcgM(s,WCQ_EXP[i])^cw[j];S.push(s);if(s)bad=true}if(!bad)return cw;
 let C=[1],Bp=[1],L=0,m=1,b=1;for(let r=0;r<nec;r++){let d=S[r];for(let i=1;i<=L;i++)d^=wcgM(C[i]||0,S[r-i]);if(d===0){m++;continue}
  const T=C.slice(),coef=wcgM(d,wcgI(b));for(let i=0;i<Bp.length;i++){C[i+m]=(C[i+m]||0)^wcgM(coef,Bp[i])}if(2*L<=r){L=r+1-L;Bp=T;b=d;m=1}else m++}
 const pos=[];for(let i=0;i<n;i++){const xi=WCQ_EXP[(255-(n-1-i))%255];let v=0;for(let k=C.length-1;k>=0;k--)v=wcgM(v,xi)^(C[k]||0);if(v===0)pos.push(i)}if(pos.length!==L)return null;
 const om=[];for(let i=0;i<nec;i++){let v=0;for(let k=0;k<=i;k++)v^=wcgM(C[k]||0,S[i-k]);om.push(v)}
 const out=cw.slice();for(const i of pos){const X=WCQ_EXP[(n-1-i)%255],Xi=wcgI(X);let num=0;for(let k=om.length-1;k>=0;k--)num=wcgM(num,Xi)^om[k];let den=0;for(let k=1;k<C.length;k+=2)den^=wcgM(C[k]||0,WCQ_EXP[(WCQ_LOG[Xi]*(k-1))%255]);
  if(!den)return null;out[i]^=wcgM(X,wcgM(num,wcgI(den)))}return out}
/* which modules are function patterns (same layout as wcQR) */
function wcqFn(ver){const N=17+ver*4,F=[];for(let i=0;i<N;i++)F.push(new Array(N).fill(0));const f=(r,c)=>{for(let i=-1;i<=7;i++)for(let j=-1;j<=7;j++){const y=r+i,x=c+j;if(y>=0&&x>=0&&y<N&&x<N)F[y][x]=1}};
 f(0,0);f(0,N-7);f(N-7,0);for(let i=0;i<N;i++){F[6][i]=1;F[i][6]=1}const al=WCQ_AL[ver],last=al.length-1;al.forEach((r,ii)=>al.forEach((c,jj)=>{if((ii===0&&jj===0)||(ii===0&&jj===last)||(ii===last&&jj===0))return;for(let i=-2;i<=2;i++)for(let j=-2;j<=2;j++)F[r+i][c+j]=1}));
 F[N-8][8]=1;for(let i=0;i<9;i++){F[8][i]=1;F[i][8]=1}for(let i=0;i<8;i++){F[8][N-1-i]=1;F[N-1-i][8]=1}if(ver>=7)for(let i=0;i<6;i++)for(let j=0;j<3;j++){F[i][N-11+j]=1;F[N-11+j][i]=1}return F}
const WCQ_MK=[(r,c)=>(r+c)%2===0,(r)=>r%2===0,(r,c)=>c%3===0,(r,c)=>(r+c)%3===0,(r,c)=>(Math.floor(r/2)+Math.floor(c/3))%2===0,(r,c)=>r*c%2+r*c%3===0,(r,c)=>(r*c%2+r*c%3)%2===0,(r,c)=>((r+c)%2+r*c%3)%2===0];
const wcHam=(a,b)=>{let x=a^b,n=0;while(x){n+=x&1;x>>=1}return n};
/* read the text from a sampled module grid Q (Q[r][c] = 1 for dark) */
function wcqRead(Q,ver){const N=17+ver*4,bit=(r,c)=>Q[r][c]?1:0;let f1=0,f2=0;
 for(let i=0;i<=5;i++)f1|=bit(i,8)<<i;f1|=bit(7,8)<<6;f1|=bit(8,8)<<7;f1|=bit(8,7)<<8;for(let i=9;i<15;i++)f1|=bit(8,14-i)<<i;
 for(let i=0;i<8;i++)f2|=bit(8,N-1-i)<<i;for(let i=8;i<15;i++)f2|=bit(N-15+i,8)<<i;
 let best=99,mask=-1,ec=-1;for(let e=0;e<4;e++)for(let m=0;m<8;m++){const v=wcqBCH((e<<3)|m,0x537,10)^0x5412,d=Math.min(wcHam(v,f1),wcHam(v,f2));if(d<best){best=d;mask=m;ec=e}}
 if(best>3||ec!==1)return null;const F=wcqFn(ver),bits=[];
 for(let c=N-1,up=true;c>0;c-=2,up=!up){if(c===6)c--;for(let k=0;k<N;k++){const r=up?N-1-k:k;for(const x of [c,c-1])if(!F[r][x])bits.push(bit(r,x)^(WCQ_MK[mask](r,x)?1:0))}}
 const E=WCQ_EC[ver],nb=E[1]+(E[3]||0),tot=E[1]*E[2]+(E[3]||0)*(E[4]||0)+E[0]*nb,cw=[];for(let i=0;i<tot;i++){let v=0;for(let k=0;k<8;k++)v=(v<<1)|(bits[i*8+k]||0);cw.push(v)}
 const lens=[];for(let k=0;k<E[1];k++)lens.push(E[2]);for(let k=0;k<(E[3]||0);k++)lens.push(E[4]);const blocks=lens.map(()=>[]),mx=Math.max(...lens);let p=0;
 for(let i=0;i<mx;i++)for(let b=0;b<nb;b++)if(i<lens[b])blocks[b].push(cw[p++]);for(let i=0;i<E[0];i++)for(let b=0;b<nb;b++)blocks[b].push(cw[p++]);
 const data=[];for(let b=0;b<nb;b++){const fx=wcRSFix(blocks[b],E[0]);if(!fx)return null;data.push(...fx.slice(0,lens[b]))}
 const db=[];for(const v of data)for(let k=7;k>=0;k--)db.push((v>>k)&1);let q=0;const rd=n=>{let v=0;for(let k=0;k<n;k++)v=(v<<1)|(db[q++]||0);return v};
 if(rd(4)!==4)return null;const n=rd(ver<10?8:16),out=new Uint8Array(n);for(let i=0;i<n;i++)out[i]=rd(8);try{return new TextDecoder().decode(out)}catch(e){return null}}
/* --- locating the code in a camera frame --- */
function wcqBin(px,w,h){const L=new Uint8Array(w*h);for(let i=0,j=0;i<L.length;i++,j+=4)L[i]=(px[j]*77+px[j+1]*150+px[j+2]*29)>>8;
 const I=new Uint32Array((w+1)*(h+1));for(let y=1;y<=h;y++){let s=0;for(let x=1;x<=w;x++){s+=L[(y-1)*w+x-1];I[y*(w+1)+x]=I[(y-1)*(w+1)+x]+s}}
 const r=Math.max(6,Math.round(Math.min(w,h)/18)),B=new Uint8Array(w*h);
 for(let y=0;y<h;y++){const y0=Math.max(0,y-r),y1=Math.min(h,y+r+1);for(let x=0;x<w;x++){const x0=Math.max(0,x-r),x1=Math.min(w,x+r+1),n=(y1-y0)*(x1-x0),s=I[y1*(w+1)+x1]-I[y0*(w+1)+x1]-I[y1*(w+1)+x0]+I[y0*(w+1)+x0];B[y*w+x]=L[y*w+x]*n<s*.86?1:0}}return B}
function wcqRatio(cs,loose){const t=cs[0]+cs[1]+cs[2]+cs[3]+cs[4];if(t<7)return 0;const u=t/7,v=u*(loose?.85:.65);return Math.abs(u-cs[0])<v&&Math.abs(u-cs[1])<v&&Math.abs(3*u-cs[2])<3*v&&Math.abs(u-cs[3])<v&&Math.abs(u-cs[4])<v?u:0}
function wcqCross(B,w,h,x,y,dx,dy,maxC){const at=(k)=>{const X=Math.round(x+dx*k),Y=Math.round(y+dy*k);return X<0||Y<0||X>=w||Y>=h?-1:B[Y*w+X]};const cs=[0,0,0,0,0];
 let k=0;while(at(k)===1){cs[2]++;k--}if(at(k)<0)return null;while(at(k)===0&&cs[1]<=maxC){cs[1]++;k--}if(at(k)<0||cs[1]>maxC)return null;while(at(k)===1&&cs[0]<=maxC){cs[0]++;k--}if(cs[0]>maxC)return null;
 k=1;while(at(k)===1){cs[2]++;k++}if(at(k)<0)return null;while(at(k)===0&&cs[3]<=maxC){cs[3]++;k++}if(at(k)<0||cs[3]>maxC)return null;while(at(k)===1&&cs[4]<=maxC){cs[4]++;k++}if(cs[4]>maxC)return null;
 const u=wcqRatio(cs,true);if(!u)return null;return{c:k-cs[4]-cs[3]-cs[2]/2,u}}
function wcqFinders(B,w,h){const C=[];const add=(x,y,u)=>{for(const p of C)if(Math.abs(p.x-x)<=p.u*2&&Math.abs(p.y-y)<=p.u*2&&Math.abs(p.u-u)<Math.max(p.u,u)*.6){p.x=(p.x*p.n+x)/(p.n+1);p.y=(p.y*p.n+y)/(p.n+1);p.u=(p.u*p.n+u)/(p.n+1);p.n++;return}C.push({x,y,u,n:1})};
 for(let y=0;y<h;y+=1){const cs=[0,0,0,0,0];let st=0;for(let x=0;x<=w;x++){const d=x<w?B[y*w+x]:0;
  if(d){if(st&1)st++;cs[st]++}else{if(st===0&&cs[0]===0)continue;if(!(st&1)){if(st===4){const u=wcqRatio(cs);if(u){const cx=x-cs[4]-cs[3]-cs[2]/2,v=wcqCross(B,w,h,cx,y,0,1,cs[2]*2);if(v){const cy=y+v.c,hz=wcqCross(B,w,h,cx,cy,1,0,cs[2]*2);if(hz)add(cx+hz.c,cy,(u+v.u+hz.u)/3)}}
   cs[0]=cs[2];cs[1]=cs[3];cs[2]=cs[4];cs[3]=1;cs[4]=0;st=3;continue}st++}cs[st]++}}}
 return C.filter(p=>p.n>=2).sort((a,b)=>b.n-a.n).slice(0,8)}
function wcqH(src,dst){/* homography from 4 module points to 4 image points */const A=[],b=[];for(let i=0;i<4;i++){const [x,y]=src[i],[u,v]=dst[i];A.push([x,y,1,0,0,0,-x*u,-y*u]);b.push(u);A.push([0,0,0,x,y,1,-x*v,-y*v]);b.push(v)}
 for(let c=0;c<8;c++){let p=c;for(let r=c+1;r<8;r++)if(Math.abs(A[r][c])>Math.abs(A[p][c]))p=r;[A[c],A[p]]=[A[p],A[c]];[b[c],b[p]]=[b[p],b[c]];if(Math.abs(A[c][c])<1e-9)return null;
  for(let r=0;r<8;r++)if(r!==c){const f=A[r][c]/A[c][c];for(let k=c;k<8;k++)A[r][k]-=f*A[c][k];b[r]-=f*b[c]}}const h=b.map((v,i)=>v/A[i][i]);return(x,y)=>{const z=h[6]*x+h[7]*y+1;return[(h[0]*x+h[1]*y+h[2])/z,(h[3]*x+h[4]*y+h[5])/z]}}
function wcqTry(B,w,h,TL,TR,BL){const ms=(TL.u+TR.u+BL.u)/3,d=(Math.hypot(TR.x-TL.x,TR.y-TL.y)+Math.hypot(BL.x-TL.x,BL.y-TL.y))/(2*ms);let v0=Math.round((d+7-17)/4);
 for(const ver of [v0,v0-1,v0+1]){if(ver<1||ver>20)continue;const N=17+ver*4;let BR=[TR.x+BL.x-TL.x,TR.y+BL.y-TL.y],bm=N-3.5;
  if(ver>=2){/* look for the alignment pattern near where it should be */const ex=TL.x+(TR.x-TL.x)*(N-10)/(N-7)+(BL.x-TL.x)*(N-10)/(N-7),ey=TL.y+(TR.y-TL.y)*(N-10)/(N-7)+(BL.y-TL.y)*(N-10)/(N-7);let bs=null,bd=1e9;const R=Math.round(ms*5);
   for(let y=Math.max(1,Math.round(ey-R));y<Math.min(h-1,ey+R);y++)for(let x=Math.max(1,Math.round(ex-R));x<Math.min(w-1,ex+R);x++){if(!B[y*w+x])continue;const s=Math.round(ms);
    if(B[y*w+x-s]||B[y*w+x+s]||B[(y-s)*w+x]||B[(y+s)*w+x])continue;const o=Math.round(ms*2);if(x-o<0||x+o>=w||y-o<0||y+o>=h)continue;if(!(B[y*w+x-o]&&B[y*w+x+o]&&B[(y-o)*w+x]&&B[(y+o)*w+x]))continue;const dd=(x-ex)**2+(y-ey)**2;if(dd<bd){bd=dd;bs=[x,y]}}
   if(bs){BR=bs;bm=N-6.5}}
  const H=wcqH([[3.5,3.5],[N-3.5,3.5],[3.5,N-3.5],[bm,bm]],[[TL.x,TL.y],[TR.x,TR.y],[BL.x,BL.y],BR]);if(!H)continue;
  const Q=[];for(let r=0;r<N;r++){const row=[];for(let c=0;c<N;c++){const [X,Y]=H(c+.5,r+.5),xi=Math.round(X),yi=Math.round(Y);row.push(xi>=0&&yi>=0&&xi<w&&yi<h?B[yi*w+xi]:0)}Q.push(row)}
  const t=wcqRead(Q,ver);if(t)return t}return null}
function wcQRDecode(img){const w=img.width,h=img.height,B=wcqBin(img.data,w,h),C=wcqFinders(B,w,h);if(C.length<3)return null;
 for(let a=0;a<C.length;a++)for(let b=a+1;b<C.length;b++)for(let c=b+1;c<C.length;c++){const P=[C[a],C[b],C[c]],D=[[1,2],[0,2],[0,1]].map(([i,j])=>Math.hypot(P[i].x-P[j].x,P[i].y-P[j].y));
  const k=D.indexOf(Math.max(...D)),TL=P[k];let [A,Cc]=P.filter((_,i)=>i!==k);if((A.x-TL.x)*(Cc.y-TL.y)-(A.y-TL.y)*(Cc.x-TL.x)<0)[A,Cc]=[Cc,A];
  const s1=Math.hypot(A.x-TL.x,A.y-TL.y),s2=Math.hypot(Cc.x-TL.x,Cc.y-TL.y);if(Math.min(s1,s2)/Math.max(s1,s2)<.7)continue;const t=wcqTry(B,w,h,TL,A,Cc);if(t)return t}return null}
/* --- the camera window --- */
const WCSCAN={stream:null,timer:0,busy:false};
function wcScanStop(){clearInterval(WCSCAN.timer);WCSCAN.timer=0;if(WCSCAN.stream){for(const t of WCSCAN.stream.getTracks())t.stop();WCSCAN.stream=null}}
/* opens the camera inside the element el; calls onText(text) once with the first code it reads */
async function wcScan(el,onText,onFail){wcScanStop();el.innerHTML=`<video playsinline muted></video><i class="wcscl"></i><b class="wcsc1"></b><b class="wcsc2"></b><b class="wcsc3"></b><b class="wcsc4"></b>`;const vid=el.querySelector('video');
 if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia){onFail&&onFail('This browser cannot use the camera here. Use the code instead.');return}
 try{WCSCAN.stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'environment',width:{ideal:1280},height:{ideal:720}},audio:false})}catch(e){onFail&&onFail('Camera access was blocked. Allow the camera, or use the code instead.');return}
 if(!el.isConnected){wcScanStop();return}vid.srcObject=WCSCAN.stream;try{await vid.play()}catch(e){}
 let det=null;try{if('BarcodeDetector' in window&&(await BarcodeDetector.getSupportedFormats()).includes('qr_code'))det=new BarcodeDetector({formats:['qr_code']})}catch(e){det=null}
 const cv=document.createElement('canvas'),g=cv.getContext('2d',{willReadFrequently:true});
 WCSCAN.timer=setInterval(async()=>{if(!el.isConnected){wcScanStop();return}if(WCSCAN.busy||!vid.videoWidth)return;WCSCAN.busy=true;let txt=null;
  try{if(det){const r=await det.detect(vid);if(r&&r[0])txt=r[0].rawValue}if(!txt){const s=Math.min(1,720/Math.max(vid.videoWidth,vid.videoHeight));cv.width=Math.round(vid.videoWidth*s);cv.height=Math.round(vid.videoHeight*s);g.drawImage(vid,0,0,cv.width,cv.height);txt=wcQRDecode(g.getImageData(0,0,cv.width,cv.height))}}catch(e){}
  WCSCAN.busy=false;if(txt){wcScanStop();el.classList.add('got');onText(txt)}},180)}
