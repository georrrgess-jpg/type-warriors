# python3 t_flpets104.py [game.html] [--nobal] : 10.4 Harvest Festival, the harvest companions (99p data / save / Hall / Eggs / powers,
# 99p2 squirrel + fox art, 99p3 turkey art, Golden Harvest Egg, harvest hatch cinematics, Grand Feast; prefix flp, edit in 87a petList).
# Checks: the three companions in every companion table (PDEF / PIDS / PCOL / PRIG / PSIG / PCEL / PICO / Mythic backdrop), never in a
# Runeshell / Crownheart / Starforge pool (petList, petPool, petHatch over many hatches, the egg caps), flpGive (reveal, silent, duplicate,
# unknown id, opt.back), the Golden Harvest Egg (flpEggAdd, flpEgg hatch / refund / none, buying for coins in the Hatchery: price, one at a
# time, owned, festival over, ledger labels), save repair on load, every pose and cosmetic of every rig drawn without errors, the Hall
# (roster tags, lock text and its button, Eggs tab badge), the Eggs tab (fourth card, stage, buttons, keys, hidden after the festival),
# the three hatch cinematics (reveal card, Equip, closing to the Hall, reduced motion, P.petPend cleared), the refund note, the powers in
# battle (Acorn Toss knock-back and daze, Maplefire Gale slow / projectiles / boss time, Grand Feast stun / heal cap / banquet score and
# Fury / morsels / boss time / typo penalty, HUD), cosmetic-only modes, loadouts, DEV cheats, the 98t / 98v guard enforced
# (window.TW_AC_TEST), UI fit at 1600x900, 1280x720 and 1024x640 (tools/td/rpu_ovl.js), frame cost and no page errors.
# The Mythic balance (Grand Feast vs Glacierhorn and Solmane) is measured by ../tools/fl/flp_balance.py (minutes); --nobal skips reading
# its saved result. Screenshots in shots/w104_pets/.
import asyncio,os,sys,json
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
ARGS=[a for a in sys.argv[1:] if not a.startswith('--')]
H='file://'+os.path.abspath(ARGS[0] if ARGS else os.path.join(HERE,'out.html'))
OVL=open(os.path.join(HERE,'..','tools','td','rpu_ovl.js')).read()
SHOTS=os.path.join(HERE,'shots','w104_pets');os.makedirs(SHOTS,exist_ok=True)
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:900]),flush=True)
    if not ok:FAIL.append(name)
SETUP="()=>{RS_ASK=false;try{WCRELAYS=[]}catch(e){}ST.perfAsked=1;try{PFW.asked=true}catch(e){}window.FL_FORCE=1;P.petSt=2;P.pets={bramble:{b:0}};P.pet='bramble';P.eggs={r:0,l:0,m:0,h:0};P.gold=200000;petNorm();flpNorm();save();return 1}"
HELP=r"""()=>{window.__f={sleep:ms=>new Promise(r=>setTimeout(r,ms)),
 seed(s){let a=s>>>0;Math.random=function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}},
 kill(){const x=document.getElementById("pthx");if(x){if(x._stop)x._stop();x.remove()}window.__flhT=null;window.__phT=null;P.petPend=null},
 /* a battle with the given companion; monsters parked on screen */
 fight(id,n){this.kill();P.pets[id]=P.pets[id]||{b:0};P.pet=id;petNorm();start(0);S.ban=null;S.spawnT=99;S.en=[];for(let i=0;i<(n||3);i++){spawn();const e=S.en[S.en.length-1];e.x=700+i*180}S.spawnLeft=0;return S.pet},
 step(s){for(let i=0;i<Math.round(s*60);i++)update(1/60)},
 boss(){const z=lvDef(S.wave);S.round=5;S.spawnLeft=1;spawn();const e=S.en[S.en.length-1];e.x=W-340;e.state='fight';newBossLine(e);return e},
 pix(c){const d=c.getContext('2d').getImageData(0,0,c.width,c.height).data;let n=0;for(let i=3;i<d.length;i+=4)if(d[i]>20)n++;return n}};return 1}"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        pg.on('console',lambda m:er.append('console: '+m.text[:300]) if m.type=='error' and 'WebSocket' not in m.text and 'net::' not in m.text and 'TUNNEL' not in m.text else None)
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate;await E(OVL);await E(HELP);await E(SETUP)
        shot=lambda n:pg.screenshot(path=os.path.join(SHOTS,n+'.png'))
        # ================= data: every companion table knows the three =================
        r=await E("""()=>{const ids=['flsquir','flfox','flturkey'];return {r:ids.map(i=>PDEF[i]&&PDEF[i].r),fl:ids.map(i=>PDEF[i]&&PDEF[i].fl),fam:ids.map(i=>PDEF[i].fam),n:ids.map(i=>PDEF[i].n===FL.petN[i]),
          pids:ids.map(i=>PIDS.includes(i)),tabs:ids.map(i=>!!(PCOL[i]&&PCOL[i].length===2&&PRIG[i]&&PSIG[i]&&PCEL[i]&&PICO[PDEF[i].ab.k]&&PDEF[i].cos&&PDEF[i].bio&&PDEF[i].box)),
          man:ids.map(i=>PM_MAN.has(PDEF[i].ab.k)),fam2:PFAM.Harvest,myth:!!MYPAL.flturkey,ab:ids.map(i=>[PDEF[i].ab.n,PDEF[i].ab.N]),eggPrice:FLPC.price,refund:FLPC.refund,start:PSTART.join()}}""")
        chk('the three harvest companions are in PDEF / PIDS (Rare Acorn Scamp, Legendary Emberleaf, Mythic Thunderplume, Harvest family, fl:1, names from FL.petN) with palettes, rigs, motes, greetings, icons, cosmetics and a Mythic backdrop; their powers use Shift',
            r['r']==['r','l','m'] and r['fl']==[1,1,1] and r['fam']==['Harvest']*3 and all(r['n']) and all(r['pids']) and all(r['tabs']) and all(r['man']) and r['fam2'] and r['myth']
            and r['ab']==[['Acorn Toss',20],['Maplefire Gale',30],['Grand Feast',25]] and r['start']=='bramble,cinder,mosskip',r)
        r=await E("""()=>{__f.seed(5);const out={};out.lists=['r','l','m'].map(k=>petList(k).filter(flpIs).length);out.pools=['r','l','m'].map(k=>petPool(k).filter(flpIs).length);out.m=petList('m').join();
          out.all=petList().filter(flpIs).length;const keep=JSON.stringify(P.pets);let got=new Set();
          for(let i=0;i<60;i++){for(const k of ['r','l','m']){P.pets={bramble:{b:0}};P.eggs[k]=50;for(let j=0;j<20;j++){const h=petHatch(k);if(!h||h.full)break;got.add(h.id);P.petPend=null}}}
          out.hatched=[...got].filter(flpIs);out.n=got.size;P.pets=JSON.parse(keep);P.eggs={r:0,l:0,m:0,h:0};P.petPend=null;petNorm();
          P.pets={bramble:{b:0},yeti:{b:0},sol:{b:0}};out.full=petPool('m').length;out.cap=ecEggCap('m');P.eggs.m=0;out.buy=petBuy('m');P.pets={bramble:{b:0}};Math.random=Math.random;save();return out}""")
        chk('never in a Runeshell / Crownheart / Starforge pool: petList / petPool skip them, 60 rounds of hatching every egg never give one, a hall with Glacierhorn and Solmane has an empty Starforge pool (egg cap on, no purchase)',
            r['lists']==[0,0,0] and r['pools']==[0,0,0] and r['m']=='yeti,sol' and r['all']==3 and r['hatched']==[] and r['n']==16 and r['full']==0 and r['cap'] is True and r['buy'] is False,r)
        # ================= save repair =================
        r=await E("""()=>{const out=[];const t=(f)=>{const s=JSON.parse(JSON.stringify(P));f(s);load(s);return JSON.stringify([P.eggs.h,P.flp,P.petPend,P.pets.flturkey||null,P.pet])};
          out.push(t(s=>{s.eggs.h='abc';s.flp='x'}),t(s=>{s.eggs.h=-5;s.flp={n:-2,rf:'7',buy:1e9}}),t(s=>{s.eggs.h=999.7}),t(s=>{s.eggs.h=3;s.petPend={id:'flturkey',k:'h'};delete s.pets.flturkey}),
           t(s=>{s.pets.flturkey={b:'x',nk:5,pal:7};s.pet='flturkey';s.eggs.h=1}),t(s=>{delete s.eggs;delete s.flp}));P.pets={bramble:{b:0}};P.pet='bramble';P.eggs.h=0;petNorm();save();return out}""")
        chk('save repair on load: Golden Harvest Eggs 0..20 whole numbers, P.flp counters, a pending reveal of an unowned harvest companion dropped, a harvest companion record normalised like any companion',
            r[0]=='[0,{"n":0,"rf":0,"buy":0},null,null,"bramble"]' and r[1]=='[0,{"n":0,"rf":7,"buy":1000000},null,null,"bramble"]' and r[2].startswith('[20,') and r[3].startswith('[3,') and ',null,null,' in r[3]
            and '"b":0' in r[4] and '"nk":""' in r[4] and '"pal":1' in r[4] and r[4].endswith('"flturkey"]') and r[5].startswith('[0,{"n":0'),r)
        # ================= art: every pose and cosmetic =================
        r=await E("""()=>{const c=document.createElement('canvas');c.width=360;c.height=320;const g=c.getContext('2d');const out={};
          for(const id of ['flsquir','flfox','flturkey']){const bad=[];let n=0;const P0=performance.now();
           for(const pose of ['idle','walk','greet','ability'])for(const u of [0,.15,.3,.45,.6,.8,.99])for(const t of [0,1.3,5.5,6.2,7.1])for(const lk of [{},{pal:1},{acc:1},{trim:1},{pal:1,acc:1,trim:1,cel:1}]){
            g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,360,320);g.translate(180,290);g.scale(2,2);try{petDraw(g,id,Object.assign({t,pose,u},lk));n++}catch(e){bad.push(e.message)}if(pose==='idle'&&u>0)break}
           g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,360,320);g.translate(180,290);g.scale(2,2);petDraw(g,id,{t:1});const px=__f.pix(c);
           g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,360,320);g.translate(180,200);g.scale(1.4,1.4);petCelFx(g,id,.5,1,-50,70);const cel=__f.pix(c);
           const ic=document.createElement('canvas');ic.width=ic.height=84;petIconCv(ic,PDEF[id].ab.k);out[id]={bad:[...new Set(bad)],n,px,cel,icon:__f.pix(ic),ms:Math.round((performance.now()-P0)/n*100)/100}}
          /* cost: the same 48 draws (four poses, plain and Signature) for the three and for the two Mythics of 87i, interleaved so machine load hits all alike */
          const ids=['flsquir','flfox','flturkey','yeti','sol'],T={};ids.forEach(i=>T[i]=0);for(let rep=0;rep<3;rep++)for(const id of ids){const P0=performance.now();for(let i=0;i<16;i++){g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,360,320);g.translate(180,290);g.scale(2,2);petDraw(g,id,{t:i*.3,pose:['idle','walk','greet','ability'][i%4],u:(i%5)/5,trim:i%2})}T[id]+=performance.now()-P0}
          for(const id of ids)(out[id]=out[id]||{}).ms=Math.round(T[id]/48*100)/100;
          const e=document.createElement('canvas');e.width=120;e.height=150;eggFit(e,'h',{t:1});out.egg=__f.pix(e);eggFit(e,'h',{t:1,charge:1,glow:1});out.egg2=__f.pix(e);return out}""")
        chk('every pose (idle / walk / greet / ability, scrubbed), the Bond 3 / 5 / 7 / 10 looks, the victory greeting and the power icon draw for all three without errors; the Golden Harvest Egg draws (calm and blazing)',
            all(r[i]['bad']==[] and r[i]['n']>=200 and r[i]['px']>4000 and r[i]['cel']>300 and r[i]['icon']>800 for i in ['flsquir','flfox','flturkey']) and r['egg']>3000 and r['egg2']>3000,r)
        ref=max(r['yeti']['ms'],r['sol']['ms'])
        chk('drawing cost of each harvest rig (lit layer, every pose) is no more than 1.4x the heavier of the Mythic rigs Glacierhorn / Solmane',all(r[i]['ms']<=ref*1.4 for i in ['flsquir','flfox','flturkey']),{i:r[i]['ms'] for i in ['flsquir','flfox','flturkey','yeti','sol']})
        # ================= granting =================
        r=await E("""async()=>{__f.kill();const out={};out.bad=flpGive('yeti');out.bad2=flpGive('nope');const g=flpGive('flsquir');out.g=g;await __f.sleep(200);out.pend=JSON.stringify(P.petPend);out.ov=!!document.getElementById('pthx');out.nw=!!P.petNew.flsquir;
          out.dup=JSON.stringify(flpGive('flsquir'));const k=new KeyboardEvent('keydown',{key:'Escape',bubbles:true});document.getElementById('pthx').dispatchEvent(k);await __f.sleep(700);
          const rv=document.getElementById('ptrv');out.card=rv&&rv.classList.contains('on')&&rv.textContent.includes('Acorn Scamp')&&rv.textContent.includes('HARVEST COMPANION')&&rv.textContent.includes('Acorn Toss');out.pend2=P.petPend;
          out.ovl=__rpuOvl(rv);document.getElementById('ptrve').click();await __f.sleep(500);out.eq=P.pet;out.hall=!!document.getElementById('pth')&&PTX.sel==='flsquir'&&PTX.tab==='Pets';
          let back=0;const g2=flpGive('flfox',{silent:1});out.silent=[!!document.getElementById('pthx'),!!P.petNew.flfox,P.petPend];
          delete P.pets.flfox;flpGive('flfox',{back:()=>{back=1}});document.getElementById('pthx').dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true}));await __f.sleep(700);document.getElementById('ptrvq').click();await __f.sleep(400);out.back=back;return out}""")
        chk('flpGive: unknown or non-harvest ids give null; a grant is saved before the reveal (P.petPend, NEW badge), plays the harvest reveal, a duplicate changes nothing; Esc skips to the card (name, ribbon, power, no overlaps); Equip equips and opens the Hall on it; silent grants skip the cinematic; opt.back runs on close',
            r['bad'] is None and r['bad2'] is None and r['g']=={'id':'flsquir'} and 'flsquir' in r['pend'] and r['ov'] and r['nw'] and r['dup']=='{"dup":1,"id":"flsquir"}' and r['card'] and r['pend2'] is None and r['ovl']==[]
            and r['eq']=='flsquir' and r['hall'] and r['silent']==[False,True,None] and r['back']==1,r)
        # ================= the Golden Harvest Egg =================
        r=await E("""async()=>{__f.kill();P.pets={bramble:{b:0}};P.pet='bramble';P.eggs.h=0;P.gold=100000;const out={};out.none=flpEgg();out.add=flpEggAdd(2,{quiet:1});out.can=flpEggCan();
          const g0=P.gold;out.h=JSON.stringify(flpEgg());await __f.sleep(150);out.ov=!!document.getElementById('pthx');out.own=petOwned('flturkey');out.left=P.eggs.h;out.pend=JSON.stringify(P.petPend);__f.kill();P.petPend=null;
          const b0=P.pets.flturkey.b;out.rf=JSON.stringify(flpEgg());out.gold=P.gold-g0;out.bond=P.pets.flturkey.b-b0;out.left2=P.eggs.h;out.flp=JSON.stringify(P.flp);await __f.sleep(300);const n=document.getElementById('flprf');out.note=!!n&&n.textContent.includes('30,000');out.novl=n?__rpuOvl(n):['no note'];
          out.l=(ledgerRecent(1)[0]||{}).src;out.cap=flpEggAdd(99,{quiet:1});P.eggs.h=0;out.can2=flpEggCan();return out}""")
        chk('the Golden Harvest Egg: none held gives null; flpEggAdd adds; an egg hatches Thunderplume (saved first, cinematic, egg spent); with Thunderplume owned an egg pays 30,000 coins and 100 bond (ledger "flegg", a note with no overlaps); eggs cap at 20',
            r['none'] is None and r['add']==2 and r['can'] is False and r['h']=='{"id":"flturkey"}' and r['ov'] and r['own'] and r['left']==1 and 'flturkey' in r['pend'] and r['rf']=='{"refund":30000}' and r['gold']==30000 and r['bond']==100
            and r['left2']==0 and '"rf":1' in r['flp'] and r['note'] and r['novl']==[] and 'flegg' in str(r['l']) and r['cap']==20 and r['can2'] is False,r)
        r=await E("""()=>{const out=[];delete P.pets.flturkey;P.eggs.h=0;P.gold=100000;out.push(flpEggCan(),flpEggBuy(),P.gold,P.eggs.h,(ledgerRecent(1)[0]||{}).src,flpEggBuy(),P.gold);
          P.eggs.h=0;P.gold=59999;out.push(flpEggBuy(),P.gold);P.gold=100000;window.FL_FORCE=-1;out.push(flpEggBuy(),flpEggShown());window.FL_FORCE=1;P.pets.flturkey={b:0};petNorm();out.push(flpEggBuy(),flpEggShown());delete P.pets.flturkey;petNorm();save();return out}""")
        chk('buying a Golden Harvest Egg in the Hatchery: 60,000 coins (ledger "egg"), one egg at a time, not without the coins, not after the festival market closes (FL_FORCE=-1, card hidden), not with Thunderplume owned',
            r==[True,True,40000,1,r[4],False,40000,False,59999,False,False,False,False] and 'egg' in str(r[4]),r)
        # ================= Companion Hall =================
        await E("()=>{__f.kill();P.pets={bramble:{b:0},flsquir:{b:900},flfox:{b:120}};P.pet='flfox';P.eggs={r:1,l:0,m:0,h:1};petNorm();PTX.filt='all';PTX.sel='flturkey';PTX.back=title;petHall('Pets')}");await pg.wait_for_timeout(900)
        r=await E("""()=>{const o={};o.cards=document.querySelectorAll('#ptrg .ptc').length;o.tags=[...document.querySelectorAll('.ptc-fl .flptg')].map(t=>t.closest('.ptc').dataset.p).join();const d=document.getElementById('ptdet');
          o.lock=d.textContent.includes('Golden Harvest Egg')&&d.textContent.includes('60,000');o.btn=!!document.getElementById('flpto');o.badge=(document.querySelector('.pttab[data-pt="Eggs"] .ptn')||{}).textContent;o.ovl=__rpuOvl(document.getElementById('pth'));
          o.myth=document.querySelectorAll('.ptc[data-p="flturkey"] canvas.mybg').length;return o}""")
        await shot('hall_turkey_locked_1600')
        chk('Hall: 20 roster cards, a festival leaf on the three harvest cards, the unowned Thunderplume explains the Golden Harvest Egg with a button, the Eggs tab badge counts it, no overlaps',
            r['cards']==20 and r['tags']=='flsquir,flfox,flturkey' and r['lock'] and r['btn'] and r['badge']=='2' and r['ovl']==[],r)
        await E("()=>document.getElementById('flpto').click()");await pg.wait_for_timeout(1000)
        r=await E("""()=>{const o={};o.egg=PTX.egg;o.tab=PTX.tab;o.cards=[...document.querySelectorAll('.phx-c[data-egg]')].map(c=>c.dataset.egg).join();o.on=(document.querySelector('.phx-c.on')||{}).dataset.egg;o.title=(document.querySelector('.phx-tt h3')||{}).textContent;
          o.buy=(document.getElementById('phxby')||{}).textContent;o.ht=(document.getElementById('phxht')||{}).textContent;o.stage=__f.pix(document.getElementById('phxcv'));o.ovl=__rpuOvl(document.getElementById('pth'));
          o.live=LIVE.some(L=>L.cv&&L.cv.id==='phxcv');return o}""")
        await shot('eggs_harvest_1600')
        chk('the Golden Harvest Egg page: opened from the button, four egg cards (Runeshell, Crownheart, Starforge, Harvest) with Harvest selected, the harvest stage drawn and live, Hatch, "One egg at a time" while one is held, no overlaps',
            r['egg']=='h' and r['tab']=='Eggs' and r['cards']=='r,l,m,h' and r['on']=='h' and r['title']=='Golden Harvest Egg' and 'One egg at a time' in r['buy'] and 'Hatch' in r['ht'] and r['stage']>100000 and r['ovl']==[] and r['live'],r)
        await E("()=>document.querySelector('.phx-c[data-egg=\"h\"]').focus()");await pg.keyboard.press('ArrowUp');await pg.wait_for_timeout(600)
        a=await E("()=>PTX.egg");await pg.keyboard.press('ArrowDown');await pg.wait_for_timeout(600);b2=await E("()=>[PTX.egg,document.querySelectorAll('.phx-c[data-egg]').length]")
        await E("()=>{PTX.egg='m';petHall('Eggs')}");await pg.wait_for_timeout(700)
        r=await E("()=>[document.querySelectorAll('.phx-c[data-egg]').length,!!document.querySelector('.phx4'),__rpuOvl(document.getElementById('pth'))]")
        await shot('eggs_starforge_4cards_1600')
        chk('arrow keys move through all four eggs; on the Starforge page the Harvest card is still listed and the four cards fit',a=='m' and b2==['h',4] and r[0]==4 and r[1] and r[2]==[],[a,b2,r])
        await E("()=>{P.eggs.h=0;window.FL_FORCE=-1;PTX.egg='h';petHall('Eggs')}");await pg.wait_for_timeout(500)
        r=await E("()=>[PTX.egg,document.querySelectorAll('.phx-c[data-egg]').length]");await E("()=>{window.FL_FORCE=1}")
        chk('after the festival with no egg in hand the Harvest card is gone and the page falls back to Runeshell',r==['r',3],r)
        # buy and hatch through the buttons
        await E("()=>{P.eggs.h=0;delete P.pets.flturkey;P.gold=120000;petNorm();PTX.egg='h';petHall('Eggs')}");await pg.wait_for_timeout(700)
        await pg.click('#phxby');await pg.wait_for_timeout(200);await pg.click('#phxby');await pg.wait_for_timeout(700)
        r=await E("()=>[P.gold,P.eggs.h,(document.getElementById('phxn')||{}).textContent]")
        await pg.click('#phxht');await pg.wait_for_timeout(400);ov=await E("()=>[!!document.getElementById('pthx'),petOwned('flturkey'),P.eggs.h]")
        chk('Hatchery buttons: Buy needs a second click to confirm and takes 60,000 coins; Hatch plays the Golden Harvest ceremony and Thunderplume is owned',r==[60000,1,'1'] and ov==[True,True,0],[r,ov])
        for t,n in [(1.1,'drop'),(3.6,'lanterns'),(5.62,'burst'),(6.6,'landing'),(7.4,'fan')]:
            await E(f"()=>{{window.__flhT={t}}}");await pg.wait_for_timeout(450);await shot(f'hatch_golden_{n}_1600')
        await E("()=>{window.__flhT=9}");await pg.wait_for_timeout(900)
        r=await E("()=>{const rv=document.getElementById('ptrv');return [rv&&rv.classList.contains('on'),rv&&rv.textContent.includes('Thunderplume')&&rv.textContent.includes('the Harvest Turkey')&&rv.textContent.includes('MYTHIC HARVEST'),__rpuOvl(rv),P.petPend]}")
        await shot('hatch_golden_card_1600')
        chk('the Golden Harvest ceremony ends on the Mythic harvest card (name, title, ribbon) with no overlaps and the pending reveal cleared',r[0] and r[1] and r[2]==[] and r[3] is None,r)
        await E("()=>{window.__flhT=null;document.getElementById('ptrvq').click()}");await pg.wait_for_timeout(600)
        r=await E("()=>[PTX.sel,!!document.getElementById('pth'),!document.getElementById('pthx'),document.querySelectorAll('.ptc[data-p=\"flturkey\"] canvas.mybg').length]")
        await shot('hall_turkey_owned_1600')
        chk('closing the card opens the Hall on Thunderplume, with the Mythic backdrop behind its roster card',r[0]=='flturkey' and r[1] and r[2] and r[3]==1,r)
        # reduced motion: straight to the card
        r=await E("""async()=>{const m0=window.matchMedia;window.matchMedia=q=>({matches:/reduce/.test(q),addEventListener(){},removeEventListener(){}});delete P.pets.flfox;flpGive('flfox');let ok=false;for(let i=0;i<25&&!ok;i++){await __f.sleep(100);const rv=document.getElementById('ptrv');ok=!!(rv&&rv.classList.contains('on'))}window.matchMedia=m0;__f.kill();return ok}""")
        chk('with reduced motion the harvest reveal goes straight to the card',r is True,r)
        # cinematic frame cost compared with the Starforge one
        r=await E("""async()=>{const ft=[];const r0=window.requestAnimationFrame;let rec=0;window.requestAnimationFrame=cb=>r0(ts=>{const a=performance.now();try{cb(ts)}finally{if(rec)ft.push(performance.now()-a)}});
          const med=a=>{a=a.slice().sort((x,y)=>x-y);return a[a.length>>1]||0};const run=async(f)=>{f();const v=[];for(const t of [6.1,6.8,7.6]){window.__phT=t;window.__flhT=t;await __f.sleep(150);ft.length=0;rec=1;await __f.sleep(900);rec=0;v.push(med(ft))}__f.kill();return v};
          P.pets.sol={b:0};const a=await run(()=>ptHatchScene('sol','m',{}));P.pets.flturkey={b:0};const b=await run(()=>ptHatchScene('flturkey','h',{}));window.requestAnimationFrame=r0;return [a,b]}""")
        sf=sum(r[0])/3;hv=sum(r[1])/3
        chk('frame cost: the Golden Harvest ceremony costs no more than the Starforge one (median ms per frame, game loop included, x1.5 + 2 ms margin)',hv<=sf*1.5+2,r)
        # ================= battle: the three powers =================
        r=await E("""()=>{__f.seed(3);const p=__f.fight('flsquir',3);const e=S.en[0];e.x=640;const sp0=e.sp;p.w=20;p.ready=true;p.pingT=S.t;const ok=petUnleash('key');__f.step(.05);const used=p.uses;
          let xb0=e.x,n=0;while(FLPG.fx.some(f=>f.k==="acorn"&&!f.hit)&&n<60){xb0=e.x;update(1/60);n++}
          const out={ok,used,push:Math.round(e.x-xb0),land:Math.round((n/60+.05)*100)/100,dz:e.fldz>0,boss:0};__f.step(.1);const xa=e.x;__f.step(1);out.slowMv=Math.round(xa-e.x);e.fldz=0;const xb=e.x;__f.step(1);out.normMv=Math.round(xb-e.x);out.sp=e.sp===sp0;
          S.en=[];out.why=(p.ready=true,pmWhyNot(p));p.ready=false;const B=__f.boss();p.ready=true;p.go=1;__f.step(.6);out.boss=B.fldz||0;S.mode='over';title();return out}""")
        chk('Acorn Toss: Shift throws an acorn; when it lands (about 0.4 s) the nearest monster is knocked back (3.5% of the field) and dazed (moves about 30% slower for 3 s), its speed restored after; with nothing on screen Shift explains why; bosses are never dazed',
            r['ok'] and r['used']==1 and 40<r['push']<60 and .3<=r['land']<=.5 and r['dz'] and r['normMv']*.6<r['slowMv']<r['normMv']*.8 and r['sp'] and r['why']=='No monster in reach yet' and r['boss']==0,r)
        r=await E("""()=>{__f.seed(4);const p=__f.fight('flfox',4);S.pj.push({x:600,y:GY-100,v:300,k:'rock',src:'x'});const B=__f.boss();B.tel={k:'volley',t:1,d:1};B.q=[{k:'orb',t:.5,v:400}];B.ak=0;p.w=30;p.ready=true;const ok=petUnleash('key');__f.step(.1);
          const out={ok,uses:p.uses,pj:S.pj.filter(j=>!j.b).length,gl:S.en.filter(e=>!e.boss&&e.flgl>0).length,ord:S.en.filter(e=>!e.boss&&e.x<W-10).length,boss:[B.tel,B.q.length,Math.round(B.ak*10)/10],bgl:B.flgl||0};S.mode='over';title();return out}""")
        chk('Maplefire Gale: projectiles burn away, every ordinary monster on screen is slowed for 4 s, a boss is not slowed but the attack it winds up is blown away and its next one waits 2 s',
            r['ok'] and r['uses']==1 and r['pj']==0 and r['gl']==r['ord'] and r['gl']>=3 and r['boss'][0] is None and r['boss'][1]==0 and 1.8<=r['boss'][2]<=2.0 and r['bgl']==0,r)
        r=await E("""()=>{__f.seed(6);const p=__f.fight('flturkey',4);const out={};S.hp=1;S.pj.push({x:600,y:GY-100,v:300,k:'rock',src:'x'});const B=__f.boss();B.tel={k:'slam',t:1,d:1};B.ak=0;const tm0=B.tm;const sc0=S.score,g0=S.gold;
          p.w=10;const t0=S.en[0];key(t0.w[0]);key(t0.w[1]==='q'?'z':'q');out.typo=p.w;t0.i=0;S.tgt=null;p.w=30;p.ready=true;out.ok=petUnleash('key');__f.step(.1);
          out.stun=S.en.filter(e=>!e.boss&&e.flst>0).length;out.ord=S.en.filter(e=>!e.boss&&e.x<W-10).length;out.bst=B.flst||0;out.boss=[B.tel,Math.round(B.ak*10)/10,B.tm<=tm0];out.hp=S.hp;out.heals=p.heals;out.ban=Math.round((p.banT-S.t)*10)/10;out.pj=S.pj.filter(j=>!j.b).length;out.mo=FLTK.mo.length;
          const xs=S.en.filter(e=>!e.boss).map(e=>e.x);__f.step(1.4);out.still=S.en.filter(e=>!e.boss).every((e,i)=>Math.abs(e.x-xs[i])<1);out.morselScore=S.score-sc0;out.morselGold=S.gold-g0;out.left=FLTK.mo.length;
          __f.step(2);out.moving=S.en.filter(e=>!e.boss).some((e,i)=>Math.abs(e.x-xs[i])>5);
          /* hearts are not capped; at full health a feast shield, never more than one above the starting shields */for(let i=0;i<4;i++){S.hp=1;p.ready=true;p.go=1;__f.step(.05)}out.cap=[p.heals,p.uses];
          S.hp=S.max;const sh0=S.shield,base=p.sh0;p.ready=true;p.go=1;__f.step(.05);const sh1=S.shield;p.ready=true;p.go=1;__f.step(.05);out.sh=[base,sh0,sh1,S.shield,p.shs];
          /* the Banquet: a word scores half again; Fury from typing is doubled */p.banT=S.t+6;S.en=[];spawn();const e=S.en[S.en.length-1];e.x=600;e.flst=0;const s1=S.score;S.fury=0;for(const ch of e.w)key(ch);const withB=S.score-s1,fB=S.fury;
          p.banT=-9;spawn();const e2=S.en[S.en.length-1];e2.x=600;e2.w=e.w;e2.i=0;const s2=S.score;S.fury=0;for(const ch of e2.w)key(ch);const noB=S.score-s2,fN=S.fury;out.ban2=[withB,noB,Math.round(fB*10)/10,Math.round(fN*10)/10];
          S.mode='over';title();return out}""")
        chk('Grand Feast: a typo takes a word off the charge; Shift stuns every ordinary monster on screen (they stay put for the 3 s), blows away projectiles, heals 1 heart, starts a 6 s Banquet and serves a morsel per stunned monster (score and gold when it lands); a boss is not stunned: its attack is interrupted and the next waits 3 s (its sentence is not lengthened)',
            r['typo']==9 and r['ok'] and r['stun']==r['ord'] and r['stun']>=3 and r['bst']==0 and r['boss'][0] is None and 2.8<=r['boss'][1]<=3 and r['boss'][2] and r['hp']==2 and r['heals']==1 and 5.8<=r['ban']<=6 and r['pj']==0 and r['mo']==r['stun']
            and r['still'] and r['morselScore']>0 and r['morselGold']>0 and r['left']==0 and r['moving'],r)
        chk('Grand Feast hearts and shields: every feast heals 1 heart when hurt; at full health it gives a feast shield, never more than one above the shields the run began with; during the Banquet a word scores 50% more and its Fury is doubled',
            r['cap']==[5,5] and r['sh'][2]==min(r['sh'][1]+1,r['sh'][0]+1) and r['sh'][3]==r['sh'][2] and r['sh'][2]==r['sh'][0]+1 and abs(r['ban2'][0]-round(r['ban2'][1]*1.5))<=2 and r['ban2'][3]>0 and abs(r['ban2'][2]-2*r['ban2'][3])<.3,r)
        # HUD and frame cost in battle
        r=await E("""async()=>{__f.seed(8);const p=__f.fight('flturkey',5);S.hp=2;await __f.sleep(300);p.w=30;p.ready=true;petUnleash('key');await __f.sleep(500);
          const t0=performance.now();for(let i=0;i<30;i++)draw();const ms=(performance.now()-t0)/30;return {ms:Math.round(ms*100)/100,ban:p.banT>S.t}}""")
        await shot('battle_grandfeast_1600')
        r2=await E("""async()=>{S.mode='over';title();__f.seed(8);const p=__f.fight('sol',5);S.hp=2;await __f.sleep(300);p.w=15;p.ready=true;petUnleash('key');await __f.sleep(500);const t0=performance.now();for(let i=0;i<30;i++)draw();const ms=(performance.now()-t0)/30;S.mode='over';title();return Math.round(ms*100)/100}""")
        chk('frame cost in battle during a Grand Feast stays close to a Sunburst Roar (draw() x1.5 + 2 ms margin)',r['ms']<=r2*1.5+2 and r['ban'],[r,r2])
        for id,nm in [('flsquir','acorntoss'),('flfox','gale')]:
            await E(f"""async()=>{{__f.seed(2);const p=__f.fight('{id}',3);await __f.sleep(500);p.w=40;p.ready=true;petUnleash('key');}}""");await pg.wait_for_timeout(380);await shot(f'battle_{nm}_1600')
            await E("()=>{S.mode='over';title()}")
        # cosmetic-only modes
        r=await E("""()=>{P.pets.flturkey={b:0};P.pet='flturkey';petNorm();start(0,'gy');const p=S.pet;const o=[p&&p.cos,PP()];p.ready=true;const u=petUnleash('key');__f.step(.2);S.mode='over';title();return [o[0],o[1],u]}""")
        chk('in a mode where companions are only cosmetic (Graveyard) Grand Feast is off and Shift explains it',r==[1,None,False],r)
        # ================= loadouts, DEV, other loops =================
        r=await E("""()=>{const o={};const L=loNorm();L.s[0].p='flturkey';const R=loPlan(L.s[0]);o.lo=R.p.ok;o.col=loCol('p','flturkey');o.rk=loRk('p','flturkey');
          o.dev=dvxHTML().includes('Harvest companions');P.eggs.h=0;dvxAct('flpE');o.e=P.eggs.h;dvxAct('flpC');o.gone=FLPC.ids.filter(petOwned).length;o.pet=P.pet;dvxAct('flpS');o.give=petOwned('flsquir');__f.kill();
          o.stamp=(()=>{P.pet='flsquir';const b0=P.pets.flsquir.b;petStamp('camp');return P.pets.flsquir.b-b0})();save();return o}""")
        chk('loadouts take a harvest companion (Mythic colour and rank), DEV › Cheats has a Harvest companions section (+1 egg, remove, give with reveal), and Adventure Trail stamps add bond to an equipped harvest companion',
            r['lo'] and r['col']=='#ff6fae' and r['rk']==5 and r['dev'] and r['e']==1 and r['gone']==0 and r['pet']!='flturkey' and r['give'] and r['stamp']==10,r)
        # ================= the 98t / 98v guard enforced: coins move only through the game =================
        p2=await b.new_page(viewport={'width':1280,'height':720});er2=[];p2.on('pageerror',lambda e:er2.append(str(e)[:300]))
        await p2.add_init_script("window.TW_AC_TEST=1;window.FL_FORCE=1");await p2.goto(H);await p2.wait_for_timeout(1500)
        await p2.evaluate(OVL);await p2.evaluate(HELP)
        g=await p2.evaluate("()=>{RS_ASK=false;ST.perfAsked=1;P.petSt=2;const g0=P.gold;try{P.gold=999999}catch(e){}return [g0,P.gold,TWAC.stat().enforced]}")
        await p2.evaluate("()=>{flpEggAdd(1,{quiet:1});P.pets.flturkey={b:0};petNorm();window.__g1=P.gold;PTX.egg='h';petHall('Eggs')}");await p2.wait_for_timeout(900)
        await p2.click('#phxht');await p2.wait_for_timeout(900)
        q=await p2.evaluate("()=>{save();return [window.__g1,P.gold,P.eggs.h]}")
        await p2.reload();await p2.wait_for_timeout(1500);q2=await p2.evaluate("()=>[P.gold,P.eggs.h,petOwned('flturkey')]")
        chk('with the 98t / 98v guard enforced (window.TW_AC_TEST): a console write to the coins is refused, while opening an egg for a refund with the button (game code) pays 30,000 coins that survive a reload',
            g[2] is True and g[1]==g[0] and q[1]==q[0]+30000 and q[2]==0 and q2==[q[1],0,True] and not er2,[g,q,q2,er2])
        await p2.close()
        # ================= UI fit at three sizes =================
        for (w,h) in [(1600,900),(1280,720),(1024,640)]:
            await pg.set_viewport_size({'width':w,'height':h});await pg.wait_for_timeout(300)
            res={}
            await E("()=>{__f.kill();P.pets={bramble:{b:0},flsquir:{b:900},flfox:{b:120},flturkey:{b:300}};P.pet='flturkey';P.eggs={r:1,l:0,m:1,h:1};petNorm();PTX.back=title;PTX.sel='flturkey';petHall('Pets')}");await pg.wait_for_timeout(900)
            res['pets']=await E("()=>__rpuOvl(document.getElementById('pth'))");await shot(f'hall_turkey_{w}')
            await E("()=>{PTX.sel='flfox';petHall('Pets')}");await pg.wait_for_timeout(700);res['fox']=await E("()=>__rpuOvl(document.getElementById('pth'))");await shot(f'hall_fox_{w}')
            await E("()=>{PTX.sel='flsquir';petHall('Pets')}");await pg.wait_for_timeout(700);res['squir']=await E("()=>__rpuOvl(document.getElementById('pth'))");await shot(f'hall_squirrel_{w}')
            await E("()=>{PTX.egg='h';petHall('Eggs')}");await pg.wait_for_timeout(900);res['eggs']=await E("()=>{document.getAnimations().forEach(x=>{try{x.pause()}catch(e){}});return __rpuOvl(document.getElementById('pth'))}");await shot(f'eggs_harvest_{w}')
            await E("()=>{PTX.egg='l';petHall('Eggs')}");await pg.wait_for_timeout(700);res['eggs4']=await E("()=>__rpuOvl(document.getElementById('pth'))");await shot(f'eggs_crownheart_4cards_{w}')
            await E("()=>{ptCustom('flturkey')}");await pg.wait_for_timeout(800);res['atelier']=await E("()=>__rpuOvl(document.querySelector('.pat-wrap')||document.getElementById('ptmod'))");await shot(f'atelier_turkey_{w}')
            await E("()=>{const m=document.querySelector('.pat-wrap');if(m)m.remove();P.eggs.h=1;delete P.pets.flturkey;petNorm();flpEgg();window.__flhT=9}");await pg.wait_for_timeout(1100)
            res['card']=await E("()=>__rpuOvl(document.getElementById('ptrv'))");await shot(f'hatch_golden_card_{w}')
            await E("()=>{__f.kill();P.eggs.h=1;flpEgg()}");await pg.wait_for_timeout(600);res['note']=await E("()=>__rpuOvl(document.getElementById('flprf'))");await shot(f'refund_note_{w}')
            for id in ['flsquir','flfox']:
                await E(f"()=>{{__f.kill();delete P.pets['{id}'];flpGive('{id}');window.__flhT={'4.6' if id=='flsquir' else '5.8'}}}");await pg.wait_for_timeout(1100);res['card_'+id]=await E("()=>__rpuOvl(document.getElementById('ptrv'))");await shot(f'hatch_{id}_card_{w}')
            await E("()=>__f.kill()")
            bad={k:v for k,v in res.items() if v}
            chk(f'UI fit at {w}x{h}: Hall (three harvest companions), Eggs (Golden Harvest and the four-card list), the Atelier, the three reveal cards and the refund note have no overlaps or clipped text',not bad,bad)
        await pg.set_viewport_size({'width':1600,'height':900})
        # ================= balance (measured by tools/fl/flp_balance.py) =================
        if '--nobal' not in sys.argv:
            bj=os.path.join(HERE,'..','tools','fl','flp_balance_last.json')
            if os.path.exists(bj):
                A=json.load(open(bj))['agg'];t,y,s,n=A.get('flturkey'),A.get('yeti'),A.get('sol'),A.get('none')
                best=max(y['wave'],s['wave']) if (t and y and s) else 0;ok=t and y and s and n and t['wave']>=n['wave']+1 and best*.8<=t['wave']<=best*1.15+.5 and t['score']<=max(y['score'],s['score'])*1.25
                chk('Mythic balance (last flp_balance.py run): Thunderplume clearly helps (at least a wave more than no companion) and lands between 80% and 115% of the better of Glacierhorn and Solmane in waves survived, at most 25% above in score',
                    bool(ok),{k:A[k] for k in ['none','yeti','sol','flturkey'] if k in A})
            else:print('SKIP balance: run ../tools/fl/flp_balance.py --json ../tools/fl/flp_balance_last.json first')
        # ================= 10.4c polish =================
        for (w,h) in [(1600,900),(1024,640)]:
            await pg.set_viewport_size({'width':w,'height':h});await pg.wait_for_timeout(300)
            await E("()=>{__f.kill();P.pets={bramble:{b:0},flsquir:{b:900},flfox:{b:120},flturkey:{b:300}};P.pet='flturkey';P.eggs={r:0,l:0,m:0,h:0};petNorm();PTX.back=title;PTX.sel='flturkey';petHall('Pets')}");await pg.wait_for_timeout(900)
            r=await E("()=>{const l=document.querySelector('.ptnm').getBoundingClientRect(),d=document.querySelector('.dk').getBoundingClientRect();return [Math.round(l.bottom),Math.round(d.top)]}")
            chk(f'10.4c {w}x{h}: the Companion Hall name label ends above the dock',r[0]<=r[1],r)
        await pg.set_viewport_size({'width':1600,'height':900})
        await E("()=>{__f.kill();P.pets={bramble:{b:0}};P.eggs={r:0,l:0,m:0,h:0};P.gold=1000;petNorm();PTX.back=title;PTX.egg='h';petHall('Eggs')}");await pg.wait_for_timeout(900)
        r=await E("()=>{const b=document.getElementById('flpmk');return [!!b,b&&b.title]}")
        chk('10.4c: the Golden Harvest Egg page links to the Harvest Market (acorns) from its festival row',r[0],r)
        await pg.click('#flpmk');await pg.wait_for_timeout(700)
        r=await E("()=>[!!document.querySelector('section.flemk'),!!document.getElementById('pth')]")
        chk('10.4c: that link opens the market',r==[True,False],r)
        await E("()=>{title()}")
        chk('no page errors',not er,er)
        print(f'\n{N[0]-len(FAIL)}/{N[0]} passed');await b.close()
        if FAIL:print('FAILED:',FAIL);sys.exit(1)
asyncio.run(main())
