/* ---------- game modes: Starfall Rift (timed XP frenzy) and the Practice Range ---------- */
const riftOpen=()=>lvl(P.xp)>=5||P.camp>=4||(P.pres||0)>0||!!P.riftU;
/* Starfall Rift tuning (kept gentle: the rift is a power fantasy, not a wall) */
const RFT={spd:.45,gain:1.6,gainL:.7,xpK:10.5,xpS:25,wk:2.4,wb:10,wS:6,hit:6,ovWin:10,ovHits:3,crK:.3,crMax:2,start:75,d0:4,dRate:.08,dCap:44,sp0:1.3,spSlope:.002,spMin:.95,drain:260,drCap:1.7,c0:3,cEvery:70,maxC:6};
const riftMax=()=>Math.min(RFT.maxC,RFT.c0+((S.rel||0)/RFT.cEvery|0));
const RIFTL={i:30,n:'Starfall Rift',z:0,tint:'#c88aff',sky:['#04031a','#3a1a7a'],wx:'motes',prop:'',m:['crawler','wisp','agolem'],b:'bGob',bn:'Rift Warden',bl:'the rift warden',pl:'the starfall rift',hue:0,blurb:'',a:'#c88aff'};
const PRACL={i:31,n:'Practice Range',z:0,tint:'#ffb84a',sky:['#2a1234','#e8883a'],wx:'',prop:'',m:['dummy','dummy','dummy'],b:'bGob',bn:'Sparring Partner',bl:'the sparring partner',pl:'the practice range',hue:0,blurb:'',a:'#ffb84a'};
SCN[30]={sky:['#04031a','#3a1a7a'],stars:130,aur:['#b86bff','#5ae0ff','#ff6ad8'],moon:[W*.78,190,70,'#e8d8ff','#c86bff66'],far:'peaks',p:'#1a1250',a:'#c88aff',s:'#5ae0ff',mid:[['shatter',420,10,.2],['bigcrystal',620,12,.3]],g:['#2a2060','#0a0620','#b86bff66'],gt:'dots',near:[['icecrystal',300,70,.3]],wx:'motes',haze:'#b86bff22'};
SCN[31]={sky:['#2a1234','#e8883a'],sun:[W*.5,560,100,'#ffd88a','#ffb84a77'],cl:'#3a1a3acc',far:'skyline',p:'#3a1a30',win:'#ffb84a',a:'#ffb84a',mid:[['siege',800,12,.35],['p_banners',520,20,.5]],g:['#4a3a2a','#140e08','#ffb84a44'],gt:'stone',near:[['barricade',420,70,.3]],wx:'embers'};
const modeLabel=()=>S.dc?`Daily #${S.dc.n}  Round ${S.round} of 5`:S.gy?`Monster Mash  Lv ${lvOf(S.wave)}  Rd ${S.round}/5`+(S.gs>1?`  ${S.gs}×`:''):S.bg?`Beginner's Mode  Lv ${lvOf(S.wave)}  Rd ${S.round}/5`+(S.gs>1?`  ${S.gs}×`:''):S.rift?'Starfall Rift':S.prac?'Practice Range':`Level ${lvOf(S.wave)}  Round ${S.round} of 5`+(S.gs>1?`  ${S.gs}×`:'');
/* ---------- shared hooks called from the core loop ---------- */
const RW8={0:[['crawler',4],['stalker',3.5],['nova',2.5]],1:[['wisp',4.5],['prism',2.5],['shard',3]],2:[['agolem',7],['nova',3]]};
function modeMon(role){
 if(S.prac){const m=S.prac.mon;if(m==='random'){const l=REG().filter(k=>!MON[k].nx);return l[Math.random()*l.length|0]}return MON[m]?m:'dummy'}
 if(Math.random()<.03&&S.rel>8)return'comet';const T=RW8[role]||RW8[0];let r=Math.random()*T.reduce((a,b)=>a+b[1],0);for(const [id,w] of T){r-=w;if(r<=0)return id}return T[0][0]}
function modeRole(id,role){const M=MON[id];if(M.fly)return 1;if(S.rift)return id==='agolem'?2:0;return 0}
const RLEN={wisp:[3,4],crawler:[4,6],prism:[4,6],agolem:[7,10],nova:[4,5],stalker:[5,7],shard:[3,5],comet:[8,10]};
function riftWord(role,id,onScreen){const [lo,hi]=RLEN[id]||[4,6],firsts=new Set(onScreen.map(w=>w[0])),ban=new Set([...RECENT,...onScreen]),hard=Math.min(2,((S.rel||0)/40)|0);
 for(const [f,r] of[[1,1],[0,1],[0,0]]){const pool=(Math.random()<.75?RIFTW:GEN).filter(w=>w.length>=lo&&w.length<=hi+hard&&(!f||!firsts.has(w[0]))&&(!r||!ban.has(w)));if(pool.length){const w=pool[Math.random()*pool.length|0];RECENT.push(w);if(RECENT.length>70)RECENT.shift();return w}}return'star'}
function modeWord(role,id){return S.rift?riftWord(role,id,S.en.map(q=>q.w)):pracWord()}
function modeInit(e,M){if(S.prac){e.tr=null;e.rg=false;e.el=false;e.role=M.fly?1:0;if(!S.prac.atk)e.at=1e9}}
function spawnK(){if(S.bg)return BG_SLOW;if(S.rift)return Math.max(RFT.spMin,RFT.sp0-S.rel*RFT.spSlope)*(S.surge>0?.55:1);if(S.prac)return S.prac.rate;return 1}
function modeTick(dt){
 if(S.rift){if(S.ban)return;S.rel+=dt;S.time-=dt*(1+Math.min(RFT.drCap,S.rel/RFT.drain));
  if(S.surge>0){S.surge-=dt;S.sfx=(S.sfx||0)-dt;if(S.sfx<=0){S.sfx=.035;S.ps.push({x:Math.random()*(W+500),y:-20,vx:-430,vy:640+Math.random()*300,l:1.2,ml:1.2,c:Math.random()<.5?'#ffffff':'#ffd0f8',s:3+Math.random()*3,g:0})}
   if(S.surge<=0){S.surge=0;S.sc=S.scB;float(W/2,260,'Starfall fades','#c88aff',40)}}
  S.d=Math.min(RFT.dCap,RFT.d0+S.rel*RFT.dRate);
  if(S.time<=0){S.time=0;if(S.mode==='play')over()}}
 else if(S.prac){if(S.ban)return;S.pel+=dt;const c=S.prac;
  if(c.goal==='time'&&S.pel>=c.gn)pracEnd();else if(c.goal==='words'&&S.kills>=c.gn)pracEnd()}}
function startSurge(){S.surge=8;S.surges++;S.sgK=0;S.sc=S.scB*3;S.time=Math.min(99,S.time+3);float(W/2,280,'STARFALL x3!','#ff9aff',72);float(W/2,340,'+3s','#7dffb0',34);S.flash=.5;S.shake=14;burst(KX,GY-150,'#ff9aff',60,{v:600});S.fx.push({k:'ring',x:KX+60,y:GY-120,t:0,ml:.7,c:'#ff9aff',w:10,r0:20,r1:520});jingle('fury');beep(1200,.3,'triangle',.9)}
function modeKill(e,pts){
 if(S.rift){const M=MON[e.id];let gt=RFT.gain+(e.w.length>=7?RFT.gainL:0)+(S.surge>0?.4:0);
  if(M.bonus==='time'){gt+=3;burst(e.x,e.y-e.h*.5,'#ffffff',30,{v:400})}
  if(M.bonus==='jackpot'){gt+=8;S.score+=600;S.comets++;stat('comet',1,'add');float(e.x,e.y-e.h-190,'JACKPOT! +600','#ffd24a',52);burst(e.x,e.y-e.h*.5,'#ffd24a',70,{v:560});S.flash=Math.max(S.flash,.3);beep(1400,.3,'triangle',.9)}
  S.time=Math.min(99,S.time+gt);float(e.x,e.y-e.h-140,'+'+gt.toFixed(1)+'s','#7dffb0',28);
  if(S.surge<=0){S.sgK++;if(S.sgK>=12)startSurge()}}}
function modeDmg(d){if(S.mode!=='play'||S.inv>0)return;S.inv=.5;
 if(S.prac){S.pmiss=(S.pmiss||0)+1;float(KX+60,GY-260,'Missed!','#ffb84a',34);S.combo=Math.floor(S.combo*S.keep);beep(150,.1,'triangle',.5);if(S.prac.perf)pracEnd();return}
 S.hurt=.55;S.combo=Math.floor(S.combo*S.keep);S.shake=14;burst(KX+30,GY-100,'#e8455a',16,{v:280});
 if(S.shield>0){S.shield--;float(KX,GY-260,'Blocked!','#7fd8ff');beep(300,.15,'triangle',.7);return}
 S.time=Math.max(0,S.time-RFT.hit);float(KX,GY-260,'-'+RFT.hit+'s','#ff5c6c',44);beep(70,.3,'sawtooth',1);if(S.time<=0){over();return}
 /* overwhelmed: several unblocked hits inside a short window end the run early, rewards kept */
 const hl=S.hitLog=(S.hitLog||[]).filter(x=>S.rel-x<RFT.ovWin);hl.push(S.rel);
 if(hl.length>=RFT.ovHits){S.ovw=1;S.ban=null;over(1)}
 else if(hl.length===RFT.ovHits-1)float(W/2,300,'The rift is unstable!','#ffb84a',40)}
function modeSetup(kind){
 if(kind==='daily')return dcSetup();
 if(kind==='gy'){S.gy=1;S.gyc=[];S.gyH=0;return}
 if(kind==='bg'){S.bg=1;return}
 if(kind==='rift'){S.rift=1;S.ovw=0;S.hitLog=[];S.runCd=0;S.time=RFT.start;S.rel=0;S.surge=0;S.sgK=0;S.surges=0;S.comets=0;S.scB=S.sc;S.cam0=1}
 else{const c=pracCfg();S.prac=Object.assign({},c,{spd:[.25,.55,1,1.5,2.2][c.spd],rate:[2.3,1.35,.85,.45][c.rate],max:[2,3,5,8][c.rate]});S.pel=0;S.pmiss=0;S.pw={i:0,seq:c.src==='custom'||c.src==='customL',pool:pracPool(c),gen:c.src==='letters'||c.src==='weak'?pracDrill(c):null};S.pk={};S.pt0=0;S.lk=0}}
function modeAfter(kind){if(kind==='daily'||kind==='gy'||kind==='bg')return;S.spawnLeft=1e9;S.spawnT=.6;
 if(kind==='rift'){S.ban={t:2.6,txt:'Starfall Rift',c:'#c88aff',sub:'Every kill buys time. Twelve kills call down a Starfall.'};jingle('boss')}
 else{const c=S.prac;S.ban={t:1.6,txt:'Practice Range',c:'#7dffb0',sub:c.goal==='time'?`${c.gn} seconds on the clock`:c.goal==='words'?`Slay ${c.gn} targets`:'Free practice. Press Escape when done.'}}}
/* ---------- key statistics (used by the weak keys drill and the practice report) ---------- */
function ksLog(exp,c){if(!exp||exp===' ')return;const now=performance.now(),ok=exp===c;if(!S.pt0)S.pt0=now;const dtm=S.lk?Math.min(2000,now-S.lk):0;S.lk=now;
 for(const o of[P.ks||(P.ks={}),S.pk||(S.pk={})]){const r=o[exp]||(o[exp]={n:0,e:0,ms:0,mn:0});r.n++;if(!ok)r.e++;else if(dtm){r.ms+=dtm;r.mn++}}
 if(S.prac&&S.prac.perf&&!ok)setTimeout(()=>{if(S.mode==='play')pracEnd()},0)}
function weakKeys(n,src){const a=[],o=src||P.ks||{};for(const k in o){const r=o[k];if(r.n<(src?2:6))continue;const er=r.e/r.n,sl=r.mn?r.ms/r.mn:400;a.push([k,er*100+Math.max(0,sl-320)/18])}a.sort((x,y)=>y[1]-x[1]);return a.slice(0,n||5).filter(x=>x[1]>3).map(x=>x[0])}
const pracAcc=()=>S.chars?Math.round(S.ok/S.chars*100):100;
/* ---------- shared typing speed counter (every mode) ---------- */
/* WPM = correct characters / 5 over ACTIVE real time (wall clock, so a slow frame rate cannot inflate it): time with a target on screen, or within 1.2 s of a keystroke. Pauses, banners and empty screens do not count. */
function wpmStep(dt){if(!S.pt0)return;const now=performance.now(),act=S.en.some(e=>e.w&&e.x<W-10&&!(e.vul>0))||now-(S.lk||0)<1200;const real=Math.min(.25,(now-(S.wl||now))/1000);S.wl=now;if(act)S.tt+=real;S.wpm=S.tt>=4&&S.ok>=8?Math.round(S.ok/5/(S.tt/60)):0}
const wpmValid=()=>S.tt>=12&&S.ok>=30;
/* ---------- practice scenery ---------- */
const mapDef=i=>i===31?PRACL:i===30?RIFTL:LEVELS[i];
const mapName=i=>i===31?'The Practice Range':i===30?'Starfall Rift':LEVELS[i].n;
const MAPT={};
function mapThumb(i){if(MAPT[i])return MAPT[i];const L=mapDef(i),c=ctx;let url='';try{c.save();c.setTransform(RS,0,0,RS,0,0);c.globalAlpha=1;c.filter='none';c.globalCompositeOperation='source-over';c.shadowBlur=0;c.fillStyle='#000';c.fillRect(0,0,W,H);zoneBG(L.z,3.2,L);const t=document.createElement('canvas');t.width=320;t.height=180;t.getContext('2d').drawImage(cv,0,0,cv.width,cv.height,0,0,320,180);url=t.toDataURL('image/jpeg',.9);c.restore()}catch(e){try{c.restore()}catch(_){}}return MAPT[i]=url}
function pracMaps(back){S.mode='title';S.view='menu';const c=pracCfg(),ids=[31,30,...LEVELS.map(l=>l.i)];
 show(`<h2>Choose a map</h2><p style="margin-top:-6px">Where do you want to train? This only changes the scenery.</p><div class="pmg">${ids.map(i=>`<button class="pmc${c.map===i?' on':''}" data-mp="${i}"><img src="${mapThumb(i)}" alt=""><span>${mapName(i)}</span></button>`).join('')}</div><div class="row"><button class="sm" id="b">Back</button></div>`,'m');
 const done=()=>pracMenu(back);S.back=done;$('b').onclick=done;ov.querySelectorAll('[data-mp]').forEach(el=>el.onclick=()=>{c.map=+el.dataset.mp;save();done()})}
/* ---------- practice words ---------- */
const PRD={map:31,src:'common',minL:3,maxL:7,spd:2,rate:2,mon:'dummy',goal:'free',gn:60,atk:0,perf:0,text:''};
const pracCfg=()=>(P.prac=Object.assign({},PRD,P.prac||{}));
const ALLW=()=>[...new Set([...GEN,...ZW.flat(),...RIFTW])];
const ROWS={home:'asdfghjkl',top:'qwertyuiop',bot:'zxcvbnm'};
function pracDrill(c){const letters=c.src==='weak'?(weakKeys(5).join('')||'etaoinsr'):'abcdefghijklmnopqrstuvwxyz',pad=c.src==='weak'?'aeiou':'',len=()=>c.minL+Math.random()*(c.maxL-c.minL+1)|0;
 return()=>{let w='',n=len(),prev='';for(let i=0;i<n;i++){let ch;do{ch=Math.random()<.35&&pad?pad[Math.random()*pad.length|0]:letters[Math.random()*letters.length|0]}while(ch===prev&&letters.length>1);w+=ch;prev=ch}return w}}
function pracPool(c){const f=w=>w.length>=c.minL&&w.length<=c.maxL,all=ALLW();
 if(c.src==='common')return GEN.filter(f);
 if(c.src.startsWith('zone'))return ZW[+c.src.slice(4)].filter(f);
 if(c.src==='astral')return RIFTW.filter(f);
 if(ROWS[c.src]){const re=new RegExp('^['+ROWS[c.src]+']+$'),p=all.filter(w=>re.test(w)&&f(w));if(p.length<14){const g=pracDrillFrom(ROWS[c.src],c.minL,c.maxL);for(let i=0;i<40;i++)p.push(g())}return p}
 if(c.src==='weak'){const wk=weakKeys(5);if(!wk.length)return GEN.filter(f);const p=all.filter(w=>f(w)&&wk.some(k=>w.includes(k)));return p.length>=10?p:[]}
 if(c.src==='sent')return PSENT;
 if(c.src==='custom'){const p=(c.text||'').toLowerCase().split(/[^a-z]+/).filter(Boolean);return p.length?p:['type','your','text','here']}
 if(c.src==='customL'){const p=(c.text||'').toLowerCase().split(/\n+/).map(s=>s.replace(/[^a-z ]+/g,' ').replace(/\s+/g,' ').trim()).filter(Boolean);return p.length?p:['type your text here']}
 return GEN.filter(f)}
function pracDrillFrom(letters,mn,mx){return()=>{let w='',n=mn+Math.random()*(mx-mn+1)|0,prev='';for(let i=0;i<n;i++){let ch;do{ch=letters[Math.random()*letters.length|0]}while(ch===prev&&letters.length>1);w+=ch;prev=ch}return w}}
function pracWord(){const p=S.pw;let w;
 if(p.seq){w=p.pool[p.i++%p.pool.length]}
 else if(p.gen&&(!p.pool.length||Math.random()<(S.prac.src==='letters'?1:.25))){w=p.gen()}
 else{let tries=0;do{w=p.pool[Math.random()*p.pool.length|0]}while((S.en.some(e=>e.w[0]===w[0]||e.w===w))&&++tries<14)}
 return w||'type'}
/* ---------- HUDs ---------- */
function riftHUD(c){const tm=Math.max(0,S.time),m=Math.floor(tm/60),s=Math.floor(tm%60),low=tm<10,sg=S.surge>0,pul=.5+.5*Math.sin(S.t*(low?10:3));
 if(sg){c.save();c.globalAlpha=.35+.15*Math.sin(S.t*8);const g=c.createRadialGradient(W/2,H/2,H*.38,W/2,H/2,H*.95);g.addColorStop(0,'#ff9aff00');g.addColorStop(1,'#ff9aff');c.fillStyle=g;c.fillRect(0,0,W,H);c.restore()}
 c.save();c.textAlign='center';c.fillStyle='rgba(6,4,22,.7)';c.beginPath();c.roundRect(W/2-150,12,300,70,16);c.fill();c.strokeStyle=sg?'#ff9aff':low?'#ff5c6c':'#8a7ad8';c.lineWidth=2.4;c.stroke();
 c.font='50px "Pirata One",Georgia,serif';c.fillStyle=low?`rgb(255,${90+pul*80|0},${100+pul*60|0})`:'#fff';c.fillText(`${m}:${String(s).padStart(2,'0')}`,W/2,40);
 const bw=260,bx=W/2-bw/2,by=64;c.fillStyle='#ffffff22';c.beginPath();c.roundRect(bx,by,bw,9,4);c.fill();const q=c.createLinearGradient(bx,0,bx+bw,0);q.addColorStop(0,low?'#ff5c6c':'#5ac8ff');q.addColorStop(1,low?'#ffb0a0':'#c88aff');c.fillStyle=q;c.beginPath();c.roundRect(bx,by,Math.max(6,bw*Math.min(1,tm/60)),9,4);c.fill();
 c.textAlign='left';c.fillStyle='rgba(6,4,22,.66)';c.beginPath();c.roundRect(14,14,262,58,14);c.fill();c.strokeStyle=sg?'#ff9aff':'#5a4aa8';c.lineWidth=1.6;c.stroke();
 c.font='24px "Pirata One",Georgia,serif';c.fillStyle=sg?'#ffb8ff':'#d8ccff';c.fillText(sg?`STARFALL x3   ${Math.ceil(S.surge)}s`:`Starfall in ${Math.max(0,12-S.sgK)}`,28,36);
 const n=sg?12:S.sgK;for(let i=0;i<12;i++){c.fillStyle=i<n?(sg?'#ff9aff':'#8ad8ff'):'#ffffff22';c.beginPath();c.roundRect(28+i*19.5,50,16,9,3);c.fill()}
 c.restore()}
function pracHUD(c){const p=S.prac;c.save();c.textAlign='left';c.fillStyle='rgba(6,4,22,.72)';c.beginPath();c.roundRect(14,14,420,58,14);c.fill();c.strokeStyle='#ffb84a88';c.lineWidth=1.6;c.stroke();
 c.font='23px "Pirata One",Georgia,serif';c.fillStyle='#ffe2a8';c.fillText(`Accuracy ${pracAcc()}%`,28,34);c.fillText(`${S.wpm} WPM`,200,34);c.fillText(`Streak ${S.combo}`,300,34);c.font='18px Georgia,serif';c.fillStyle='#c8c0e0';c.fillText(`Missed ${S.pmiss||0}   Slain ${S.kills}${p.perf?'   Perfect mode':''}`,28,58);
 c.textAlign='center';const g=p.goal==='time'?`${Math.max(0,Math.ceil(p.gn-S.pel))}s left`:p.goal==='words'?`${S.kills} of ${p.gn}`:'Free practice';c.fillStyle='rgba(6,4,22,.72)';c.beginPath();c.roundRect(W/2-110,14,220,44,14);c.fill();c.strokeStyle='#ffb84a88';c.stroke();c.font='28px "Pirata One",Georgia,serif';c.fillStyle='#fff';c.fillText(g,W/2,37);c.restore()}
/* ---------- results ---------- */
function riftOver(quit){if(S.mode==='over')return;S.mode='over';S.en=[];const l0=finishRun(),wxm=wxpEnd(),lvl0=lvl(P.xp);
 const xp0=Math.round((S.kills*RFT.xpK+S.surges*RFT.xpS)*(1+.1*U('scholar')+.1*(P.pres||0)+(S.xpm||0))),lv0=lvl(P.xp),xpCap=lv0>=MAXLV?0:lvx(lv0+2)-1-P.xp,xp=Math.max(0,Math.min(xp0,xpCap));
 P.xp+=xp;P.riftU=1;P.rb=P.rb||{s:0,k:0};const nb=S.score>P.rb.s;if(nb)P.rb.s=S.score;P.rb.k=Math.max(P.rb.k,S.kills);stat('rift',1,'add');stat('riftScore',S.score,'max');stat('combo',S.maxCombo,'max');save();jingle('win');
 const l1=lvl(P.xp),lg=levelGold(lvl0,l1),cr=S.runC||0;save();
 const later=()=>{show(`<h2>${S.ovw?'The rift collapses':'The rift closes'}</h2>${resBlock()}${S.ovw?'<p class="pbl">You were taking hits too fast, so the rift ended early to stop the losing streak. Your rewards are kept.</p>':''}<p>${nb?'<b style="color:var(--gold)">New rift record!</b> ':`Rift record ${P.rb.s.toLocaleString()}. `}${S.surges} Starfall${S.surges===1?'':'s'}${S.comets?`, ${S.comets} Treasure Comet${S.comets>1?'s':''}`:''}.<br>Earned <b style="color:#9ae8ff">${xp.toLocaleString()} XP</b>${xp<xp0?' <small style="opacity:.75">(the rift can raise you by one level per run)</small>':''}, ${S.gold+lg} gold and ${cr} crate${cr===1?'':'s'}.${wxm}${l1>lvl0?`<br><b style="color:var(--gold)">Level up! You are now level ${l1}, ${rankOf(l1)}. Bonus: ${lg} gold.</b>`:''}${pathMsg(lvl0,l1)}</p>${tipLine()}<div class="row"><button id="go">Enter again</button><button class="sm" id="hm">Home</button></div>`,'m');$('go').onclick=()=>start(0,'rift');$('hm').onclick=title};
 if(quit)later();else{S.pose='victory';S.poseT=0;S.late=later;S.lateAt=1.6}}
function kbHeat(o){const cell=k=>{const r=o[k],n=r?r.n:0,acc=n?1-r.e/n:null,ms=r&&r.mn?Math.round(r.ms/r.mn):0;return `<span class="kc${n?'':' z'}" style="${n?`background:hsl(${Math.max(0,(acc-.6)/.4)*120},62%,${28+(1-acc)*10}%)`:''}" title="${k}: ${n} presses, ${r?r.e:0} misses${ms?', '+ms+' ms':''}">${k}<small>${n&&ms?ms:''}</small></span>`};
 return `<div class="kbh">${['qwertyuiop','asdfghjkl','zxcvbnm'].map((row,i)=>`<div style="margin-left:${i*26}px">${[...row].map(cell).join('')}</div>`).join('')}</div><small class="kbl">Green is clean and red is often missed. The number under each key is your average time in milliseconds.</small>`}
function pracEnd(quit){if(S.mode==='over')return;S.mode='over';S.en=[];const c=S.prac,acc=pracAcc(),wpm=S.wpm;
 const key=[c.src,c.goal,c.goal==='free'?'':c.gn].join('|');P.pb=P.pb||{};const pb=P.pb[key]||{w:0,a:0},ok=S.chars>=25,nw=ok&&wpm>pb.w,na=ok&&acc>pb.a;if(nw||na)P.pb[key]={w:Math.max(wpm,pb.w),a:Math.max(acc,pb.a)};save();jingle(S.chars>=25?'win':'lose');
 const used=Object.keys(S.pk||{}).length?S.pk:P.ks||{},wk=weakKeys(5,S.pk&&Object.keys(S.pk).length?S.pk:null),sl=Object.entries(used).filter(([k,r])=>r.mn>=3).map(([k,r])=>[k,Math.round(r.ms/r.mn)]).sort((a,b)=>b[1]-a[1]).slice(0,4),ms=Object.entries(used).filter(([k,r])=>r.e>0).sort((a,b)=>b[1].e-a[1].e).slice(0,4);
 const tm=Math.round(S.pel);
 show(`<h2>Practice complete</h2><div class="res"><div><b>${wpm}</b>Words per minute</div><div><b>${acc}%</b>Accuracy</div><div><b>${S.kills}</b>Targets slain</div><div><b>${S.maxCombo}</b>Best streak</div><div><b>${S.pmiss||0}</b>Missed</div><div><b>${Math.floor(tm/60)}:${String(tm%60).padStart(2,'0')}</b>Time</div></div>
 <p>${nw?'<b style="color:var(--gold)">New personal best speed for this setup!</b> ':na?'<b style="color:var(--gold)">New best accuracy for this setup!</b> ':''}${ok?`Best for this setup: ${P.pb[key].w} WPM and ${P.pb[key].a}% accuracy.`:'Type at least 25 characters to record a personal best.'}</p>
 ${kbHeat(used)}<p class="kbs">${sl.length?'Slowest keys: '+sl.map(x=>`<b>${x[0]}</b> ${x[1]} ms`).join('   '):''}${ms.length?'<br>Most missed: '+ms.map(x=>`<b>${x[0]}</b> x${x[1].e}`).join('   '):'<br>No missed keys. Clean run!'}</p>
 <div class="row"><button id="pa">Again</button>${wk.length?`<button class="sm" id="pw">Drill weak keys (${wk.join(' ')})</button>`:''}<button class="sm" id="ps">Change setup</button><button class="sm" id="hm">Home</button></div>`,'m');
 $('pa').onclick=()=>start(0,'prac');if($('pw'))$('pw').onclick=()=>{const q=pracCfg();q.src='weak';q.goal=q.goal==='free'?'time':q.goal;q.gn=q.gn||60;P.ks=P.ks||{};save();start(0,'prac')};$('ps').onclick=()=>pracMenu(title);$('hm').onclick=title}
/* ---------- practice setup screen ---------- */
const PSRC=[['common','Common words'],['zone0','Goblin Woods words'],['zone1','Crypt words'],['zone2','Spider Cavern words'],['zone3','Ember Keep words'],['zone4','Frozen Peaks words'],['zone5','Sunken Ruins words'],['astral','Astral words'],['home','Home row only'],['top','Top row only'],['bot','Bottom row only'],['weak','My weak keys'],['letters','Random letter drills'],['sent','Short sentences'],['custom','My own text (words)'],['customL','My own text (lines)']];
const PPRE=[['Warm-up',{src:'common',minL:3,maxL:5,spd:1,rate:1,goal:'time',gn:60,atk:0,perf:0}],['Speed drill',{src:'common',minL:3,maxL:6,spd:3,rate:3,goal:'time',gn:60,atk:0,perf:0}],['Accuracy',{src:'common',minL:5,maxL:9,spd:1,rate:1,goal:'words',gn:30,atk:0,perf:1}],['Zen',{src:'common',minL:4,maxL:8,spd:0,rate:0,goal:'free',atk:0,perf:0}],['Weak keys',{src:'weak',minL:3,maxL:7,spd:1,rate:1,goal:'time',gn:60,atk:0,perf:0}],['Sentences',{src:'sent',spd:1,rate:0,goal:'words',gn:15,atk:0,perf:0}],['Home row',{src:'home',minL:3,maxL:6,spd:2,rate:2,goal:'time',gn:60,atk:0,perf:0}],['Survival',{src:'common',minL:4,maxL:8,spd:3,rate:3,goal:'free',atk:1,perf:0}]];
const PGOALS=[['free',0,'Free'],['time',30,'30s'],['time',60,'60s'],['time',120,'2 min'],['words',25,'25 words'],['words',50,'50 words'],['words',100,'100 words']];
function pracMenu(back){S.mode='title';S.view='menu';const c=pracCfg(),keep=ov.scrollTop;
 const seg=(k,opts)=>`<div class="seg">${opts.map(([v,l])=>`<button class="sm${String(c[k])===String(v)?' on':''}" data-pk="${k}" data-pv="${v}">${l}</button>`).join('')}</div>`;
 const pbk=[c.src,c.goal,c.goal==='free'?'':c.gn].join('|'),pb=(P.pb||{})[pbk],wk=weakKeys(5),mons=REG().filter(k=>!MON[k].nx&&!MON[k].boss).sort((a,b)=>MON[a].n.localeCompare(MON[b].n));
 const gi=PGOALS.findIndex(g=>g[0]===c.goal&&(g[0]==='free'||g[1]===c.gn));
 show(`<h2>Practice Range</h2><p style="margin-top:-6px">Train your typing with no risk. Nothing here costs health, and nothing earns XP or gold.</p>
<div class="pre">${PPRE.map((p,i)=>`<button class="sm" data-pre="${i}">${p[0]}</button>`).join('')}</div>
<div class="opts pr">
<div class="opt"><div><label>Scenery</label><small>Where you train. Pick any map in the game.</small></div><div class="pmsel"><img src="${mapThumb(c.map)}" alt=""><div><b>${mapName(c.map)}</b><button class="sm" id="pmap">Change map</button></div></div></div>
<div class="opt"><div><label>Words</label><small>${c.src==='weak'?(wk.length?`Your weakest keys right now: <b>${wk.join(' ')}</b>.`:'Play a few runs first so the game can learn your weak keys.'):'What you will be typing.'}</small></div><select id="psrc">${PSRC.map(([v,l])=>`<option value="${v}"${c.src===v?' selected':''}>${l}</option>`).join('')}</select></div>
${c.src.startsWith('custom')?`<div class="opt col"><div><label>Your text</label><small>${c.src==='custom'?'Words are taken in order and repeat.':'Each line becomes one target.'} Only letters a to z are used.</small></div><textarea id="ptx" rows="4" placeholder="Paste anything you want to practice...">${esc(c.text||'')}</textarea></div>`:''}
${c.src.startsWith('custom')||c.src==='sent'?'':`<div class="opt"><div><label>Word length</label><small>Shortest ${c.minL}, longest ${c.maxL} letters.</small></div><div class="rng"><input type="range" id="pmn" min="2" max="11" value="${c.minL}"><input type="range" id="pmx" min="3" max="12" value="${c.maxL}"></div></div>`}
<div class="opt"><div><label>Target</label><small>What walks out to meet you.</small></div><select id="pmon"><option value="dummy"${c.mon==='dummy'?' selected':''}>Training Dummy</option><option value="random"${c.mon==='random'?' selected':''}>Random monsters</option>${mons.filter(k=>k!=='dummy').map(k=>`<option value="${k}"${c.mon===k?' selected':''}>${MON[k].n}</option>`).join('')}</select></div>
<div class="opt"><div><label>Speed</label><small>Zen targets barely move.</small></div>${seg('spd',[[0,'Zen'],[1,'Slow'],[2,'Normal'],[3,'Fast'],[4,'Insane']])}</div>
<div class="opt"><div><label>Crowd size</label><small>How many targets at once.</small></div>${seg('rate',[[0,'Sparse'],[1,'Few'],[2,'Busy'],[3,'Flood']])}</div>
<div class="opt"><div><label>Goal</label><small>When the session ends.</small></div><div class="seg">${PGOALS.map((g,i)=>`<button class="sm${i===gi?' on':''}" data-pg="${i}">${g[2]}</button>`).join('')}</div></div>
<div class="opt"><div><label>Enemies attack</label><small>When on, targets that reach you count as misses.</small></div>${seg('atk',[[0,'Off'],[1,'On']])}</div>
<div class="opt"><div><label>Perfect mode</label><small>One wrong key ends the session.</small></div>${seg('perf',[[0,'Off'],[1,'On']])}</div></div>
<p class="pbl">${pb?`Your best for this setup: <b>${pb.w} WPM</b> at <b>${pb.a}%</b> accuracy.`:'No record for this setup yet.'}</p>
<div class="row"><button id="pgo2">Start practice</button><button class="sm" id="b">Back</button></div>`,'m');
 S.back=back;ov.scrollTop=keep;$('b').onclick=back;$('pmap').onclick=()=>pracMaps(back);const re=()=>{save();pracMenu(back)};
 const tx=$('ptx');if(tx)tx.oninput=()=>{c.text=tx.value;save()};
 ov.querySelectorAll('[data-pk]').forEach(el=>el.onclick=()=>{c[el.dataset.pk]=+el.dataset.pv;re()});
 ov.querySelectorAll('[data-pg]').forEach(el=>el.onclick=()=>{const g=PGOALS[+el.dataset.pg];c.goal=g[0];if(g[1])c.gn=g[1];re()});
 ov.querySelectorAll('[data-pre]').forEach(el=>el.onclick=()=>{Object.assign(c,PPRE[+el.dataset.pre][1]);re()});
 $('psrc').onchange=e=>{c.src=e.target.value;if(c.src==='sent'||c.src.startsWith('custom')){}re()};$('pmon').onchange=e=>{c.mon=e.target.value;save()};
 const mn=$('pmn'),mx=$('pmx');if(mn)mn.onchange=()=>{c.minL=+mn.value;if(c.maxL<c.minL)c.maxL=c.minL;re()};if(mx)mx.onchange=()=>{c.maxL=+mx.value;if(c.minL>c.maxL)c.minL=c.maxL;re()};
 $('pgo2').onclick=()=>{if(tx)c.text=tx.value;save();start(0,'prac')}}

/* ---------- main menu background: any campaign map you have cleared ---------- */
const hbgList=()=>LEVELS.filter(l=>l.i+1<P.camp||P.stars[l.i+1]).map(l=>l.i);
const hbgCur=()=>Number.isInteger(P.hbg)&&hbgList().includes(P.hbg)?P.hbg:-1;
function hbgThumb(i){if(i>=0)return mapThumb(i);if(MAPT.d)return MAPT.d;const c=ctx;let url='';try{c.save();c.setTransform(RS,0,0,RS,0,0);c.globalAlpha=1;c.filter='none';c.globalCompositeOperation='source-over';c.shadowBlur=0;c.fillStyle='#000';c.fillRect(0,0,W,H);menuBG(3.2);const t=document.createElement('canvas');t.width=320;t.height=180;t.getContext('2d').drawImage(cv,0,0,cv.width,cv.height,0,0,320,180);url=t.toDataURL('image/jpeg',.9);c.restore()}catch(e){try{c.restore()}catch(_){}}return MAPT.d=url}
const hbgName=i=>i<0?'Moonlit Keep (default)':LEVELS[i].n;
function hbgPick(back){S.mode='title';S.view='menu';const cur=hbgCur(),ids=[-1,...hbgList()],left=30-hbgList().length;
 show(`<h2>Menu background</h2><p style="margin-top:-6px">Pick the scenery behind the main menu. Every campaign map you clear unlocks here.${left>0?` <b>${left}</b> still locked.`:''}</p><div class="pmg">${ids.map(i=>`<button class="pmc${cur===i?' on':''}" data-bg="${i}"><img src="${hbgThumb(i)}" alt=""><span>${hbgName(i)}</span></button>`).join('')}</div><div class="row"><button class="sm" id="b">Back</button></div>`,'m');
 const done=()=>back();S.back=done;$('b').onclick=done;ov.querySelectorAll('[data-bg]').forEach(el=>el.onclick=()=>{const v=+el.dataset.bg;P.hbg=v<0?null:v;save();beep(560,.05,'triangle',.4);done()})}
