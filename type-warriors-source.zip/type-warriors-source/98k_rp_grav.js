/* ===== RUNESTONE TOWER DEFENSE 10.0: the Singularity Engine in battle (98k, after 98j) =====
   The twelfth tower (key G, 600 supply, ground only; TD_WORLDS_PLAN.md section 3; the core module decides when it unlocks). Crowd
   control: it charges (rings and disk spin up), then fires a gravity orb that arcs onto the road where the most ground monsters will be
   when it lands (rpqLand from 95t leads them, so Tidecaller slides, stuns and slows are read). The orb
   opens a gravity well for RP_TW.grav.dur seconds:
   - pull: every ground monster inside the well is pulled toward the well's centre ALONG ITS OWN ROAD (e.s moves toward the point of
     its path e.pi closest to the centre; a road that passes the well twice uses the nearer pass). The pull is RP_TW.grav.pull px/s,
     softened over the last RPGV.soft px so monsters settle instead of jittering, with a small per-monster offset so they bunch
     without stacking on one pixel. Monsters behind the centre are drawn forward more gently (RPGV.fwd) than those ahead of it are
     pulled back, so a well delays a group rather than hurrying its tail. Bosses are pulled half as hard (RPGV.bossK). It never moves
     a monster below s = 0.
   - caps: the backward pull a monster can ever receive is capped over its life (e.gvP; RPGV.cap px, bosses RPGV.capB); once spent the
     well still crushes it but no longer moves it. The well shares the Tidecaller's recent push-back budget (e.tdP and RPTC.cap in
     95r): backward pull adds to e.tdP, and a monster already pushed back about RPTC.cap px recently (within 24 px of it, as e.tdP
     decays every step) is not pulled back further. A monster sliding from a Tidecaller wave (e.kb > 0) is left to the wave. So stacked
     wells and waves can never hold monsters for good.
   - crush: RP_TW.grav.dmg per second, x(1 + RPGV.crowdK per extra monster caught), up to x RPGV.crowdMax; armor softens it (at most
     by half). Continuous damage (no hit flash every tick); the Starfall mark and every other rpHurt bonus apply.
   - tier 3 Tidal lock: monsters leaving a well (or caught when it closes) are slowed RP_TW.grav.lock for RPGV.lockT s.
   - tier 4 Event horizon: wells last 3.2 s and swallow monsters below RP_TW.grav.exec of their health (never bosses).
   - tier 5 Collapse: every RP_TW.grav.nova[4]th well implodes when it closes: a nova hits everything (flyers too) within RPGV.novaR px.
   Not inside a well: monsters that cannot be hit at the moment (a Leviathan's dive, a Springjack's leap) are neither pulled nor crushed.
   Overcharge speeds it up and adds 15% damage like every other tower. Rune Typing: the G hotkey is off while typing is on.
   Hooks for the core: RPGV.see(R,tw,e) may hide monsters from the aim (fog); a jam that blocks rpFire stops the orbs, not open wells.
   State on RPX: gvOrbs [{x0,y0,x1,y1,s,pi,t,d,h,tw,tier,nova,seed}], gvWells [{x,y,r,t,d,tier,tw,an,in,caught,nova,seed,k}],
   gvFx [{x,y,r,t,d,tier,kind:'land'|'nova'}], gvN (wells opened), gvFin (swallowed), gvNovaN. Monster: e.gvP (backward pull so far),
   e.gvIn (the well holding it this step), e.gvK (0..1 for the squeeze). Tower: tw.cd, tw.charge, tw.fire, tw.aim (spin phase), tw.nv. */
RP_TW.grav={cost:[600,380,650,1250,1950],range:[260,275,290,305,320],dmg:[38,60,94,143,210],cd:[4.6,4.4,4.2,4,3.8],well:[84,90,96,102,108],
 dur:[2.5,2.5,2.5,3.2,3.2],pull:[110,120,130,140,150],lock:[0,0,.3,.3,.3],exec:[0,0,0,.08,.08],nova:[0,0,0,0,4],novaD:[0,0,0,0,520],ap:[99,99,99,99,99],air:0,ground:1,
 desc:'Opens gravity wells on the road: ground monsters are pulled together along the road and crushed, harder in a crowd. Sets them up for splash towers. Cannot hit flyers.',
 up:['A stronger singularity: a wider well, a harder pull and crush.','Tidal lock: monsters leaving a well are slowed 30% for 2 seconds.','Event horizon: wells last longer and swallow monsters left below 8% health (not bosses).','Collapse: every fourth well implodes in a nova that hits everything nearby, flyers too.']};
RP_TWORDER.push('grav');RP_KEYS.push('G');
/* RPGV.see(R,tw,e) (optional, set by the core): false hides a monster from the Engine's aim (e.g. fog far from the tower) */
const RPGV={see:null,charge:.8,lead:0,fwd:.6,soft:30,spread:7,bossK:.5,cap:260,capB:120,crowdK:.25,crowdMax:2,armK:30,armMin:.5,lockT:2,novaR:140,novaAp:8,open:.25,close:.3,teth:10};
const rpgvFlight=d=>.5+d/1100;
/* can a well touch this monster now? */
const rpgvCan=e=>!e.dead&&!e.air&&e.s>=0&&!(e.dive>0)&&!(e.leap>0);
/* sounds go through rpSfx (keys gv*) */
{const s0=rpSfx;rpSfx=function(k,v){if(typeof k!=='string'||k.slice(0,2)!=='gv')return s0.apply(this,arguments);try{
 if(k==='gvCharge')beep(180,.18,'sine',.06);
 else if(k==='gvFire'){beep(90,.22,'sine',.18);setTimeout(()=>beep(520,.08,'triangle',.08),40);setTimeout(()=>beep(260,.12,'sine',.08),90)}
 else if(k==='gvOpen'){beep(60,.35,'sawtooth',.14);setTimeout(()=>beep(140,.25,'sine',.12),60)}
 else if(k==='gvFin'){[392,262,196].forEach((f,j)=>setTimeout(()=>beep(f,.09,'square',.06),j*45))}
 else if(k==='gvNova'){beep(1600,.05,'sawtooth',.06);setTimeout(()=>beep(48,.55,'sawtooth',.26),70);setTimeout(()=>beep(96,.3,'triangle',.18),120)}}catch(e){}}}
/* the closest passes of every road to a point: per path, the s of each local minimum of the distance within r */
function rpgvAnchors(R,x,y,r){const out=[],r2=(r+24)*(r+24);
 R.G.paths.forEach((P,pi)=>{const S=P.S,a=[];let best=-1,bd=1e18;
  for(let i=0;i<S.length;i++){const d=rpD2(S[i].x,S[i].y,x,y);if(d<r2){if(d<bd){bd=d;best=i}}else if(best>=0){a.push(best*4);best=-1;bd=1e18}}
  if(best>=0)a.push(best*4);out[pi]=a});return out}
/* where to drop the next well: the predicted spot (a little ahead along the road) that catches the most ground monsters, preferring
   monsters that can still be pulled and that are not already held by a well */
function rpgvAim(R,tw,T,i){const rg=T.range[i],r2=rg*rg,cand=[];
 for(const e of R.foes){if(!rpgvCan(e))continue;const q=rpPos(R,e);if(rpD2(q.x,q.y,tw.x,tw.y)>r2)continue;if(RPGV.see&&!RPGV.see(R,tw,e))continue;cand.push(e)}
 if(!cand.length)return null;
 const pr=new Map(),P=e=>{let v=pr.get(e);if(!v){const q=rpPos(R,e);v=rpqLand(R,e,rpgvFlight(Math.sqrt(rpD2(q.x,q.y,tw.x,tw.y))));pr.set(e,v)}return v};
 const wr=T.well[i]*.9,w2=wr*wr;let best=null,bv=-1e18;
 for(const e of cand){const L=P(e),s=Math.max(4,Math.min(rpLen(R,e)-20,L.s+RPGV.lead)),c=rpAt(R.G,s,e.pi);if(rpD2(c.x,c.y,tw.x,tw.y)>r2*1.1)continue;let v=0;
  for(const f of R.foes){if(!rpgvCan(f))continue;const M=P(f);if(rpD2(M.x,M.y,c.x,c.y)>w2)continue;const left=(f.boss?RPGV.capB:RPGV.cap)-(f.gvP||0);v+=10+(left>40?6:0)+(f.boss?4:0)-(f.gvIn?7:0)}
  for(const w of R.gvWells)if(w.t<w.d-.4&&rpD2(w.x,w.y,c.x,c.y)<(w.r*1.2)**2)v-=25;/* do not stack a well on a live one */
  for(const o of R.gvOrbs)if(rpD2(o.x1,o.y1,c.x,c.y)<(T.well[i]*1.2)**2)v-=25;
  v+=tw.prio==='strong'?e.hp/1e6:tw.prio==='close'?-rpD2(c.x,c.y,tw.x,tw.y)/1e6:e.s/rpLen(R,e);
  if(v>bv){bv=v;best={e,x:c.x,y:c.y,s,pi:e.pi||0}}}
 return best}
function rpgvFire(R,tw,dt){const T=RP_TW.grav,i=tw.tier-1,sp=tw.over>0?RPT.AB.over.k:1;tw.over=Math.max(0,tw.over-dt);
 tw.fire=Math.max(0,(tw.fire||0)-dt*1.4);tw.cd-=dt*sp;
 const ch0=tw.charge||0;tw.charge=tw.cd<RPGV.charge?Math.min(1,1-tw.cd/RPGV.charge):Math.max(0,ch0-dt*3);if(ch0<=0&&tw.charge>0&&tw.cd>0)rpSfx('gvCharge');
 /* the spin phase the art reads as o.aim: it runs ahead while charging and after a shot */
 tw.aim=((tw.aim||0)+dt*(tw.charge*5+tw.fire*4))%(TAU*64);
 if(tw.cd>0)return;const a=rpgvAim(R,tw,T,i);if(!a){tw.cd=.15;tw.charge=Math.max(0,tw.charge-.4);return}
 tw.cd=T.cd[i];tw.fire=1;tw.charge=0;tw.nv=(tw.nv||0)+1;
 const c=rpgvCore(tw.tier,0),k=typeof RPG!=='undefined'&&!RPG.off?RPG.k:1,x0=tw.x+c.x*k,y0=tw.y+c.y*k,d=Math.hypot(a.x-x0,a.y-y0),nn=T.nova[i];
 R.gvOrbs.push({x0,y0,x1:a.x,y1:a.y,s:a.s,pi:a.pi,t:0,d:rpgvFlight(d),h:60+d*.3,tw,tier:tw.tier,nova:!!(nn&&tw.nv%nn===0),seed:Math.random()*99,_rpg:1});
 try{ptBurst(R.fx,x0,y0,R.lite?4:10,[rpgvEn(tw.tier).b,rpgvEn(tw.tier).a,'#ffffff'],{v:170,s:3,up:1,g:120})}catch(e){}
 rpSfx('gvFire')}
/* an orb lands: the well opens */
function rpgvOpen(R,o){const T=RP_TW.grav,i=Math.max(0,Math.min(4,o.tw.tier-1)),r=T.well[i];
 const w={x:o.x1,y:o.y1,r,t:0,d:T.dur[i],tier:o.tier,tw:o.tw,an:rpgvAnchors(R,o.x1,o.y1,r),in:new Set(),caught:[],nova:o.nova,seed:o.seed%7,k:0};
 R.gvWells.push(w);if(R.gvWells.length>12)R.gvWells.shift();R.gvN=(R.gvN||0)+1;
 R.gvFx.push({x:w.x,y:w.y,r,t:0,d:.5,tier:o.tier,kind:'land'});R.shake=Math.max(R.shake||0,1.4);
 try{ptBurst(R.fx,w.x,w.y-6,R.lite?4:10,[rpgvEn(o.tier).b,rpgvEn(o.tier).a,'#3a2a5a'],{v:180,s:3,up:1,g:300})}catch(e){}
 rpSfx('gvOpen')}
/* the point of e's own road the well pulls it toward (null when its road does not pass the well near it) */
function rpgvTarget(w,e){const A=w.an[e.pi||0];if(!A||!A.length)return null;let b=null,bd=1e9;for(const s of A){const d=Math.abs(s-e.s);if(d<bd){bd=d;b=s}}
 if(bd>w.r*1.9)return null;return b+((((e.uid||0)*37)%9)-4)*RPGV.spread}
function rpgvLock(e,k){if(!k||e.dead||e.air)return;if(e.vent>0)return;/* a venting Steam Golem ignores slows */e.slowK=Math.max(e.slowK||0,k);e.slowT=Math.max(e.slowT||0,RPGV.lockT)}
function rpgvStep(R,dt){if(!R.gvOrbs)return;const T=RP_TW.grav;
 for(const o of R.gvOrbs){o.t+=dt;if(o.t>=o.d&&!o.done){o.done=1;rpgvOpen(R,o)}}R.gvOrbs=R.gvOrbs.filter(o=>!o.done);
 for(const e of R.foes){e.gvIn=null}
 const pulled=new Set();
 for(const w of R.gvWells){w.t+=dt;const i=Math.max(0,Math.min(4,w.tier-1)),tw=w.tw,over=tw.over>0?1.15:1,r2=w.r*w.r,ending=w.t>=w.d;
  w.k=w.t<RPGV.open?rpEB(w.t/RPGV.open):Math.max(0,Math.min(1,(w.d-w.t)/RPGV.close));
  const caught=[];if(!ending)for(const e of R.foes){if(!rpgvCan(e))continue;const q=rpPos(R,e);if(rpD2(q.x,q.y,w.x,w.y)<r2)caught.push(e)}
  const n=caught.length,crowd=Math.min(RPGV.crowdMax,1+RPGV.crowdK*Math.max(0,n-1));
  for(const e of caught){if(!e.gvIn)e.gvIn=w;
   /* pull along the road (one well at a time per monster) */
   if(!pulled.has(e)&&!(e.kb>0)){pulled.add(e);const tg=rpgvTarget(w,e);if(tg!=null){const u=tg-e.s,au=Math.abs(u);if(au>.5){
     const cap=e.boss?RPGV.capB:RPGV.cap,left=cap-(e.gvP||0);let v=T.pull[i]*(e.boss?RPGV.bossK:1)*(u>0?RPGV.fwd:1)*Math.min(1,au/RPGV.soft),m=Math.min(au,v*dt);
     if(left<=0)m=0;else if(u<0){if(typeof RPTC!=='undefined'&&(e.tdP||0)>=RPTC.cap-24)m=0;m=Math.min(m,left,Math.max(0,e.s));e.gvP=(e.gvP||0)+m;e.tdP=(e.tdP||0)+m;e.s-=m}
     else e.s+=m}}}
   /* crush */
   const af=Math.max(RPGV.armMin,1-Math.max(0,e.armor||0)/RPGV.armK),fl=e.fl;rpHurt(e,T.dmg[i]*crowd*over*af*dt,99,tw);if(!e.dead)e.fl=fl;
   /* event horizon */
   if(!e.dead&&!e.boss&&T.exec[i]&&e.hp<=T.exec[i]*e.mx){const q=rpPos(R,e);rpKillFoe(e,tw);R.gvFin=(R.gvFin||0)+1;rpText(q.x,q.y-50,'SWALLOWED!','#e8b0ff',17);rpSfx('gvFin');
    try{const E=rpgvEn(w.tier);for(let k=0;k<(R.lite?3:7);k++){const u=k/7;ptBurst(R.fx,q.x+(w.x-q.x)*u,q.y-18+(w.y-q.y+18)*u,1,[E.b,E.a,'#ffffff'],{v:40,s:2.6})}}catch(x){}}
   if(!e.dead)e.gvK=Math.min(1,(e.gvK||0)+dt*4)}
  /* tidal lock: whoever leaves the well, and whoever is still in it when it closes */
  const lk=T.lock[i];if(lk){const now=new Set(caught);for(const e of w.in)if(!now.has(e))rpgvLock(e,lk);if(ending)for(const e of caught)rpgvLock(e,lk)}
  w.in=new Set(caught);w.caught=caught;
  if(ending&&!w.done){w.done=1;if(lk)for(const e of w.in)rpgvLock(e,lk);
   if(w.nova){const D=(T.novaD[i]||T.novaD[4])*over,r=RPGV.novaR;for(const e of R.foes){if(e.dead||e.s<0)continue;const q=rpPos(R,e);if(rpD2(q.x,q.y,w.x,w.y)<r*r)rpHurt(e,D,RPGV.novaAp,tw)}
    R.gvFx.push({x:w.x,y:w.y,r,t:0,d:.85,tier:w.tier,kind:'nova'});R.gvNovaN=(R.gvNovaN||0)+1;R.shake=Math.max(R.shake||0,6);rpText(w.x,w.y-70,'COLLAPSE!','#ffc8f4',22);rpSfx('gvNova');
    try{ptBurst(R.fx,w.x,w.y-10,R.lite?8:22,[rpgvEn(w.tier).b,rpgvEn(w.tier).a,'#ffffff','#3a2a5a'],{v:340,s:4,up:1,g:300})}catch(x){}}}}
 R.gvWells=R.gvWells.filter(w=>!w.done);
 for(const e of R.foes)if(!e.gvIn&&e.gvK>0)e.gvK=Math.max(0,e.gvK-dt*3);
 for(const f of R.gvFx)f.t+=dt;R.gvFx=R.gvFx.filter(f=>f.t<f.d)}
/* hooks: fire routine, battle state, step, upgrade */
{const f0=rpFire;rpFire=function(R,tw,dt){if(tw.type==='grav')return rpgvFire(R,tw,dt);return f0.apply(this,arguments)}}
{const s0=rpStart;rpStart=function(){const r=s0.apply(this,arguments);if(RPX)Object.assign(RPX,{gvOrbs:[],gvWells:[],gvFx:[],gvN:0,gvFin:0,gvNovaN:0});return r}}
{const s0=rpStep;rpStep=function(R,dt){const r=s0.apply(this,arguments);try{rpgvStep(R,dt)}catch(e){console.error(e)}return r}}
{const u0=rpUpgrade;rpUpgrade=function(tw){const r=u0.apply(this,arguments);if(r&&tw&&tw.type==='grav'){tw.charge=0;tw.fire=0}return r}}
/* 97k: orbs leave from the scaled art (rpgvFire already places them; listed so a later shot-origin pass knows the array) */
try{if(typeof RPG_ARR!=='undefined'&&!RPG_ARR.includes('gvOrbs'))RPG_ARR.push('gvOrbs')}catch(e){}
/* drawing: wells, strands and orb shadows on the ground; orbs, the floating singularities, landing bursts and novas on top */
const rpgvOrbPos=o=>{const u=Math.max(0,Math.min(1,o.t/o.d));return{u,x:o.x0+(o.x1-o.x0)*u,y:o.y0+(o.y1-o.y0)*u-o.h*4*u*(1-u),gx:o.x0+(o.x1-o.x0)*u,gy:o.y0+(o.y1-o.y0)*u}};
{const a0=rpAmbient;rpAmbient=function(c,R){const r=a0.apply(this,arguments);try{if(R&&R.gvWells){
 for(const w of R.gvWells)rpgvWell(c,w.x,w.y,w.r,w.k,R.t,w.tier,w.seed);
 if(!R.lite)for(const w of R.gvWells){let n=0;for(const e of w.caught){if(e.dead||n++>=RPGV.teth)continue;const q=rpPos(R,e);rpgvTether(c,q.x,q.y-4,w.x,w.y,R.t,.75*w.k,w.tier)}}
 for(const o of R.gvOrbs){const p=rpgvOrbPos(o),k=.35+.65*p.u;c.fillStyle=`rgba(8,4,20,${(.35*k).toFixed(3)})`;c.beginPath();c.ellipse(p.gx,p.gy+2,9*k,3.6*k,0,0,TAU);c.fill();
  /* the landing ring grows where the well will open */
  if(p.u>.35){const a=(p.u-.35)/.65,rr=RP_TW.grav.well[o.tier-1]*(1.15-.15*a);c.save();c.globalAlpha=.55*a;c.setLineDash([9,7]);c.lineDashOffset=R.t*30;c.lineWidth=2;c.strokeStyle=rpgvEn(o.tier).d[1];c.beginPath();c.ellipse(o.x1,o.y1,rr,rr*RPFX.sq,0,0,TAU);c.stroke();c.setLineDash([]);c.restore()}}}}catch(e){console.error(e)}return r}}
{const b0=rpBeamsDraw;rpBeamsDraw=function(c,R){b0.apply(this,arguments);if(!R.gvWells)return;
 for(const w of R.gvWells)rpgvWellTop(c,w.x,w.y,w.r,w.k,R.t,w.tier,w.seed);
 for(const f of R.gvFx){const u=f.t/f.d;if(f.kind==='nova')rpgvNova(c,f.x,f.y,f.r,u,f.tier);else rpgvLand(c,f.x,f.y,f.r,u,f.tier)}
 for(const o of R.gvOrbs){const p=rpgvOrbPos(o),E=rpgvEn(o.tier);
  /* a trail of dark motes and violet light */
  c.save();c.globalCompositeOperation='lighter';const n=R.lite?2:5;for(let k=1;k<=n;k++){const q=rpgvOrbPos({x0:o.x0,y0:o.y0,x1:o.x1,y1:o.y1,h:o.h,t:Math.max(0,o.t-k*.03),d:o.d});rpGlow(c,q.x,q.y,13-k*1.6,13-k*1.6,k%2?E.b:E.g,.8-k*.12)}c.restore();c.globalAlpha=1;
  rpgvOrbDraw(c,p.x,p.y,o.tier,R.t+o.seed,o.nova?1.5:1.25)}}}
/* monsters held in a well squeeze in rhythm (the transform is about their feet) */
{const f0=rpFoeDraw;rpFoeDraw=function(c,R,e,q){if(!(e.gvK>.02)||e.dead||!q)return f0.apply(this,arguments);const s=e.gvK*(.5+.5*Math.sin(R.t*16+(e.uid||0)));
 c.save();c.translate(q.x,q.y);c.scale(1+.07*s,1-.09*s);c.translate(-q.x,-q.y);try{return f0.apply(this,arguments)}finally{c.restore()}}}
/* while an Engine is selected: a faint ring where its next well would open */
{const d0=rpDraw;rpDraw=function(){const r=d0.apply(this,arguments);try{const R=RPX;if(!R||!S.rp||!R.sel||R.sel.type!=='grav'||R.sel.build<1)return r;const tw=R.sel,T=RP_TW.grav;if(!tw._pvT||R.t-tw._pvT>.2||R.t<tw._pvT){tw._pvT=R.t;tw._pv=rpgvAim(R,tw,T,tw.tier-1)}const a=tw._pv;
  if(a){const c=ctx;c.save();c.setTransform(RS,0,0,RS,0,0);const rr=T.well[tw.tier-1];c.globalAlpha=.55+.2*Math.sin(R.t*4);c.setLineDash([8,8]);c.lineDashOffset=-R.t*24;c.lineWidth=2.2;c.strokeStyle='#d8a0ff';c.beginPath();c.ellipse(a.x,a.y,rr,rr*RPFX.sq,0,0,TAU);c.stroke();c.setLineDash([]);c.restore()}}catch(e){}return r}}
/* the info panel */
{const i0=rpInfoBuild;rpInfoBuild=function(R,tw,el){const r=i0.apply(this,arguments);if(tw.type!=='grav')return r;try{const T=RP_TW.grav,i=tw.tier-1,top=RP_MAXT(R.map),nx=tw.tier<top?tw.tier:null;
  const seg=(v,max)=>Math.max(0,Math.min(6,Math.round(v/max*6))),bar=(lab,v,max,nv)=>`<div class="rpst"><span>${lab}</span><i>${[0,1,2,3,4,5].map(k=>`<s class="${k<seg(v,max)?'on':nv!=null&&k<seg(nv,max)?'up':''}"></s>`).join('')}</i></div>`;
  const cr=j=>Math.sqrt(T.dmg[j]*T.dur[j]*1.5),pl=j=>T.pull[j]*T.dur[j]*T.well[j];
  const st=el.querySelector('.rpsts');if(st)st.innerHTML=bar('Range',T.range[i],320,nx!=null?T.range[nx]:null)+bar('Crush',cr(i),cr(4),nx!=null?cr(nx):null)+bar('Pull',pl(i),pl(4),nx!=null?pl(nx):null)+bar('Fire rate',1/T.cd[i],1/4.4,nx!=null?1/T.cd[nx]:null);
  const ex=[`Well <b>${T.dur[i]} s</b>`,`pulls along the road`,`crush up to <b>x${RPGV.crowdMax}</b> in a crowd`];
  if(T.lock[i])ex.push(`tidal lock <b>-${Math.round(T.lock[i]*100)}%</b> ${RPGV.lockT} s`);if(T.exec[i])ex.push(`swallows below <b>${Math.round(T.exec[i]*100)}%</b>`);if(T.nova[i])ex.push(`collapse every <b>${T.nova[i]}</b>`);
  if(st)st.insertAdjacentHTML('afterend',`<div class="rpgvx">${ex.join(' · ')}</div>`);
  {const b=el.querySelector('.rpih b');if(b){b.style.fontSize='22px';b.style.whiteSpace='nowrap'}}
  const hgt=el.offsetHeight||420;el.style.top=rpClamp(tw.y-hgt*.62,76,770-hgt)+'px'}catch(e){console.error(e)}return r}}
/* key G picks it (not while Rune Typing is on: letters type then) */
{const k0=rpKeyDown;window.removeEventListener('keydown',rpKeyDown,true);rpKeyDown=function(e){const R=RPX;if(R&&S.rp&&S.mode==='ramparts'&&!R.pause&&!R.over&&!(R.ty&&R.ty.on)&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&e.key.length===1&&e.key.toLowerCase()==='g'){e.preventDefault();e.stopImmediatePropagation();if(!e.repeat)rpPlace('grav');return}return k0.apply(this,arguments)};window.addEventListener('keydown',rpKeyDown,true)}
/* eleven buttons in the build ring: a little wider again, kept on the stage */
{const g0=rpHudRing;rpHudRing=function(R,C){const was=C.rg;const r=g0.apply(this,arguments);try{if(C.rg!==was&&C.rg){const bs=[...$('rpring').querySelectorAll('.rprb')],p=R.selPad;if(bs.length>=11){bs.forEach(b=>{for(const v of ['--x','--y']){const n=parseFloat(b.style.getPropertyValue(v));if(isFinite(n))b.style.setProperty(v,(n*1.06).toFixed(1)+'px')}});
   if(p){const xs=bs.map(b=>p.x+(parseFloat(b.style.getPropertyValue('--x'))||0)),lo=Math.min(...xs)-46,hi=Math.max(...xs)+46,dx=lo<0?-lo:hi>1600?1600-hi:0;
    if(dx)bs.forEach(b=>b.style.setProperty('--x',((parseFloat(b.style.getPropertyValue('--x'))||0)+dx).toFixed(1)+'px'))}}}}catch(e){console.error(e)}return r}}
/* eleven tiles in the bar */
{const st=document.createElement('style');st.textContent=`.rph.rp7.rp8.rp9.rp10.rp11 .rpbar{gap:2px}.rph.rp7.rp8.rp9.rp10.rp11 .rpcard{width:76px}.rph.rp7.rp8.rp9.rp10.rp11 .rpct>b{max-width:74px;font-size:11px}.rph.rp7.rp8.rp9.rp10.rp11 .rpcard img{width:62px;height:62px;margin-left:-31px;top:-16px}
.rpgvx{margin:6px 0 2px;font:600 12px Poppins,system-ui,sans-serif;color:#ead8ff;line-height:1.35}.rpgvx b{color:#e0a8ff}`;document.head.appendChild(st)}
{const h0=rpHudOn;rpHudOn=function(){const r=h0.apply(this,arguments);try{const h=$('rphud');if(h&&RP_TWORDER.length>=11)h.classList.add('rp11')}catch(e){}return r}}
try{const h=HELP.Modes.find(x=>x[0]==='Runestone Tower Defense');if(h)h[1]+=" The Singularity Engine (G, 600 supply) fires gravity orbs that open wells on the road: ground monsters are pulled together and crushed, so splash towers hit the whole pile."}catch(e){}
{const h0=rpHowTo;rpHowTo=function(){const r=h0.apply(this,arguments);try{const w=ov.querySelector('#rpmod .rphw');if(w)w.insertAdjacentHTML('beforeend',`<p><b>Singularity Engine.</b> A crowd-control tower (650 supply, key G) for ground monsters. It fires a gravity orb onto the road that opens a well for a few seconds: monsters inside are pulled together along the road and crushed, harder the bigger the crowd, which sets them up for splash towers. Bosses are pulled half as hard, and no monster can be held for ever. Tier 3 slows monsters as they leave a well, tier 4 swallows badly hurt monsters and makes wells last longer, tier 5 makes every fourth well collapse in a nova.</p>`)}catch(e){}return r}}
