/* =====================================================================
   ARMOUR RENDERER - every set is built from the same slots (helm, pauldrons,
   cuirass, belt, skirt, bracers, gauntlets, greaves, boots, cape) and uses one
   shading language: bevelled plates, dark outline, inner edge trim, rivets.
   Each armour only chooses a material, a helm, pauldrons, a skirt and a cape.
   ===================================================================== */
const arBB=p=>{let a=1e9,b=1e9,c=-1e9,d=-1e9;for(let i=0;i<p.length;i+=2){if(p[i]<a)a=p[i];if(p[i]>c)c=p[i];if(p[i+1]<b)b=p[i+1];if(p[i+1]>d)d=p[i+1]}return[a,b,c,d]};
function arPP(g,p,sm){g.beginPath();if(sm){const n=p.length/2,mx=i=>(p[(i%n)*2]+p[((i+1)%n)*2])/2,my=i=>(p[(i%n)*2+1]+p[((i+1)%n)*2+1])/2;g.moveTo(mx(n-1),my(n-1));for(let i=0;i<n;i++)g.quadraticCurveTo(p[i*2],p[i*2+1],mx(i),my(i))}else{g.moveTo(p[0],p[1]);for(let i=2;i<p.length;i+=2)g.lineTo(p[i],p[i+1])}g.closePath()}
/* bevelled plate: gradient body, light top-left bevel, dark bottom-right bevel, optional inner edge trim, outline */
function arBev(g,p,c,o){o=o||{};const b=arBB(p),gr=g.createLinearGradient(b[0],b[1],b[2],b[3]);
 gr.addColorStop(0,shade(c,.32));gr.addColorStop(.5,c);gr.addColorStop(1,shade(c,-.38));
 arPP(g,p,o.sm);g.fillStyle=o.flat?c:gr;g.fill();
 g.save();arPP(g,p,o.sm);g.clip();
 if(o.edge){g.strokeStyle=o.edge;g.lineWidth=o.ew||3;arPP(g,p,o.sm);g.stroke()}
 g.lineWidth=2.2;
 g.save();g.translate(.8,.8);g.strokeStyle=shade(c,.62)+'aa';arPP(g,p,o.sm);g.stroke();g.restore();
 g.save();g.translate(-.8,-.8);g.strokeStyle=shade(c,-.55)+'aa';arPP(g,p,o.sm);g.stroke();g.restore();
 if(o.tex)o.tex(g,b);
 g.restore();
 g.lineWidth=o.ow||1.25;g.strokeStyle='#000000b8';arPP(g,p,o.sm);g.stroke()}
function arEl(x,y,rx,ry,a0,a1,n){n=n||22;a0=a0||0;a1=a1===undefined?TAU:a1;const full=a1-a0>=TAU-.001,p=[];for(let i=0;i<n;i++){const a=a0+(a1-a0)*i/(full?n:n-1);p.push(x+Math.cos(a)*rx,y+Math.sin(a)*ry)}return p}
const arBevE=(g,x,y,rx,ry,c,o)=>arBev(g,arEl(x,y,rx,ry),c,Object.assign({sm:1},o||{}));
/* shaded tube (limbs): outline, dark body, lit core, specular streak */
function arSeg(g,x0,y0,x1,y1,w,c){const dx=x1-x0,dy=y1-y0,L=Math.hypot(dx,dy)||1;let nx=-dy/L,ny=dx/L;if(nx*-.5+ny*-.85<0){nx=-nx;ny=-ny}
 g.lineCap='round';const ln=(ox,oy,lw,col)=>{g.strokeStyle=col;g.lineWidth=lw;g.beginPath();g.moveTo(x0+ox,y0+oy);g.lineTo(x1+ox,y1+oy);g.stroke()};
 ln(0,0,w+2.5,'#000000b8');ln(0,0,w,shade(c,-.3));ln(nx*w*.1,ny*w*.1,w*.74,c);ln(nx*w*.2,ny*w*.2,w*.22,shade(c,.4)+'cc')}
/* textures drawn inside a clip, b = bounding box */
function arMail(g,b,col){g.save();g.strokeStyle=col||'#00000045';g.lineWidth=.85;g.beginPath();let r=0;for(let y=b[1];y<b[3]+4;y+=3.6,r++)for(let x=b[0]+(r%2)*1.9;x<b[2]+4;x+=3.8){g.moveTo(x+1.9,y);g.arc(x,y,1.9,.05,Math.PI-.05)}g.stroke();
 g.fillStyle='#ffffff2e';r=0;for(let y=b[1];y<b[3];y+=3.6,r++)for(let x=b[0]+(r%2)*1.9;x<b[2];x+=3.8)g.fillRect(x-.6,y-1.6,1.1,.8);g.restore()}
function arScale(g,b,M,T){g.save();let r=0;const R=3.7;for(let y=b[1]-2;y<b[3]+R;y+=4.1,r++){for(let x=b[0]-3+(r%2)*R;x<b[2]+R;x+=R*2){g.beginPath();g.arc(x,y,R,0,Math.PI);g.closePath();g.fillStyle=((r+((x/R)|0))%3)?shade(M,.08):shade(M,.2);g.fill();g.strokeStyle='#0000008a';g.lineWidth=.9;g.stroke();g.strokeStyle='#ffffff4a';g.lineWidth=.7;g.beginPath();g.arc(x,y,R-1,.35,1.4);g.stroke()}}g.restore()}
function arFacets(g,b,M,t){const [x0,y0,x1,y1]=b,cx=(x0+x1)/2,w=x1-x0,h=y1-y0,P=[[x0,y0],[cx,y0],[x1,y0],[x0+w*.12,y0+h*.4],[cx,y0+h*.38],[x1-w*.08,y0+h*.42],[x0+w*.1,y0+h*.75],[cx,y0+h*.72],[x1-w*.06,y0+h*.76],[x0+w*.2,y1],[cx,y1],[x1-w*.12,y1]];
 const T3=[[0,1,4],[0,4,3],[1,2,5],[1,5,4],[3,4,7],[3,7,6],[4,5,8],[4,8,7],[6,7,10],[6,10,9],[7,8,11],[7,11,10]];
 T3.forEach((q,i)=>{g.beginPath();g.moveTo(P[q[0]][0],P[q[0]][1]);g.lineTo(P[q[1]][0],P[q[1]][1]);g.lineTo(P[q[2]][0],P[q[2]][1]);g.closePath();g.fillStyle=['#ffffff40','#ffffff12','#00000026','#ffffff26','#0000001a','#ffffff33'][i%6];g.fill();g.strokeStyle='#ffffff77';g.lineWidth=.9;g.stroke()})}
/* emblem glyph, centred, ~18 units across; dark under-stroke then colour so it reads as an inlay */
function arGlyph(g,k,col,t){const P={
 cross:()=>{g.moveTo(-2.4,-9);g.lineTo(2.4,-9);g.lineTo(2.4,-3);g.lineTo(7.5,-3);g.lineTo(7.5,2);g.lineTo(2.4,2);g.lineTo(2.4,9);g.lineTo(-2.4,9);g.lineTo(-2.4,2);g.lineTo(-7.5,2);g.lineTo(-7.5,-3);g.lineTo(-2.4,-3);g.closePath()},
 sun:()=>{g.arc(0,0,4,0,TAU);for(let i=0;i<8;i++){const a=i*TAU/8;g.moveTo(Math.cos(a)*6.2,Math.sin(a)*6.2);g.lineTo(Math.cos(a)*10,Math.sin(a)*10)}},
 rune:()=>{g.moveTo(0,-9);g.lineTo(7,0);g.lineTo(0,9);g.lineTo(-7,0);g.closePath();g.moveTo(-3.5,0);g.lineTo(3.5,0)},
 flame:()=>{g.moveTo(0,-10);g.quadraticCurveTo(8,-2,4.5,6);g.quadraticCurveTo(0,11,-4.5,6);g.quadraticCurveTo(-8,0,-2.5,-5);g.quadraticCurveTo(-1,-8,0,-10);g.closePath()},
 snow:()=>{for(let i=0;i<3;i++){const a=i*Math.PI/3;g.moveTo(Math.cos(a)*9,Math.sin(a)*9);g.lineTo(-Math.cos(a)*9,-Math.sin(a)*9)}},
 moon:()=>{g.arc(0,0,8,Math.PI*.35,Math.PI*1.65);g.arc(3.4,0,6.4,Math.PI*1.55,Math.PI*.45,true);g.closePath()},
 star:()=>{for(let i=0;i<8;i++){const a=-Math.PI/2+i*Math.PI/4,r=i%2?3:9.5;i?g.lineTo(Math.cos(a)*r,Math.sin(a)*r):g.moveTo(Math.cos(a)*r,Math.sin(a)*r)}g.closePath()},
 leaf:()=>{g.moveTo(0,-10);g.quadraticCurveTo(9,-2,0,10);g.quadraticCurveTo(-9,-2,0,-10);g.closePath();g.moveTo(0,-6);g.lineTo(0,8)},
 bolt:()=>{g.moveTo(2,-10);g.lineTo(-6,1);g.lineTo(-1,1);g.lineTo(-3,10);g.lineTo(6,-2);g.lineTo(1,-2);g.closePath()},
 drop:()=>{g.moveTo(0,-10);g.quadraticCurveTo(8,0,5,5);g.quadraticCurveTo(0,10,-5,5);g.quadraticCurveTo(-8,0,0,-10);g.closePath()},
 wing:()=>{g.moveTo(-9,2);g.quadraticCurveTo(-4,-10,9,-8);g.quadraticCurveTo(3,-4,6,0);g.quadraticCurveTo(1,-1,3,4);g.quadraticCurveTo(-2,2,-9,2);g.closePath()}}[k];
 if(HWG[k]){g.save();g.lineJoin='round';g.lineCap='round';HWG[k](g,col,t);g.restore();return}
 g.save();g.lineJoin='round';g.lineCap='round';
 if(k==='eclipse'){g.beginPath();g.arc(0,0,7.4,0,TAU);g.fillStyle='#06030f';g.fill();g.strokeStyle='#000000b0';g.lineWidth=3.4;g.stroke();g.strokeStyle=col;g.lineWidth=1.8;g.stroke();g.lineWidth=1.1;g.beginPath();for(let i=0;i<12;i++){const a=i*TAU/12+t*.2;g.moveTo(Math.cos(a)*9.2,Math.sin(a)*9.2);g.lineTo(Math.cos(a)*(i%2?10.5:12.5),Math.sin(a)*(i%2?10.5:12.5))}g.stroke();g.restore();return}
 if(!P){g.restore();return}
 const fl={cross:1,flame:1,moon:1,star:1,bolt:1,drop:1,wing:1}[k];
 g.beginPath();P();g.strokeStyle='#000000b0';g.lineWidth=3.6;g.stroke();
 g.beginPath();P();if(fl){g.fillStyle=col;g.fill()}g.strokeStyle=col;g.lineWidth=fl?1:1.9;g.stroke();g.restore()}
/* curved tapered horn / tusk / thorn along an arc; returns the centreline so tines can branch off it */
function arTusk(g,x,y,ang,len,curve,w,col,o){o=o||{};const N=12,L=[],R=[],C=[];let px=x,py=y;for(let i=0;i<=N;i++){const u=i/N,a=ang+curve*u,ww=w*Math.pow(1-u,.85)+.25;C.push([px,py,a]);const nx=-Math.sin(a),ny=Math.cos(a);L.push(px+nx*ww/2,py+ny*ww/2);R.unshift(px-nx*ww/2,py-ny*ww/2);px+=Math.cos(a)*len/N;py+=Math.sin(a)*len/N}
 arBev(g,L.concat(R),col,Object.assign({sm:0},o));return C}
/* ------------------------------------------------------------------ kits */
const AK={
 rags:{mat:'cloth',leg:'cloth',helm:'bare',pauld:'soft',skirt:'rag',cape:'',pat:'patch',tier:0},
 leather:{mat:'leather',leg:'leather',helm:'hood',pauld:'strap',skirt:'kilt',cape:'short',cc:'hcd',tier:1},
 chain:{mat:'mail',leg:'mail',helm:'coif',pauld:'mail',skirt:'mail',cape:'long',cc:'hc',emb:'cross',tier:2},
 shadow:{mat:'cloth',leg:'cloth',helm:'cowl',pauld:'spike',skirt:'rag',cape:'tatter',cc:'#2a1a4a',emb:'rune',pat:'sash',tier:2},
 plate:{mat:'plate',leg:'plate',helm:'great',crest:'plume',pauld:'lames',skirt:'tassets',cape:'royal',cc:'hc',emb:'cross',tier:3},
 glacier:{mat:'crystal',leg:'plate',helm:'circ',crest:'crown',crown:'ice',pauld:'crystal',skirt:'tassets',cape:'long',cc:'#cfeeff',emb:'snow',fx:'snow',tier:3},
 dragon:{mat:'scale',leg:'plate',helm:'great',crest:'horns',pauld:'spike',skirt:'tassets',cape:'tatter',cc:'#6a1014',emb:'flame',fx:'embers',tier:4},
 sun:{mat:'plate',leg:'plate',helm:'great',crest:'wings',pauld:'lames',skirt:'tabard',tab:'#fff4d0',cape:'long',cc:'#fff4d0',emb:'sun',fx:'motes',tier:4},
 pelt:{fur:1,pauld:'fur',cc:'hcd'},
 bone:{pauld:'spike',crest:'bonehorn',emb:'',tier:2},
 jade:{helm:'great',crest:'blades',emb:'leaf',tier:2},
 ember:{crest:'flame',fx:'embers',emb:'flame',cape:'tatter',cc:'#2a1620'},
 tide:{helm:'great',crest:'fin',pauld:'fin',emb:'drop',fx:'bubbles',cape:'long',cc:'#1f8f98'},
 nightsong:{crest:'moon',emb:'moon',fx:'stars',cape:'galaxy',cc:'#161a4a'},
 thunder:{crest:'bolt',pauld:'spike',emb:'bolt',fx:'bolt',cape:'royal',cc:'#2a3a78'},
 blood:{emb:'drop',fx:'embers',cape:'tatter',cc:'#4a0612'},
 void:{crest:'void',emb:'rune',fx:'void',pauld:'spike',cape:'tatter',cc:'#14082a'},
 ascend:{mat:'plate',leg:'plate',helm:'great',crest:'crown',pauld:'lames',skirt:'tabard',tab:'#ffffff',cape:'wings',emb:'sun',fx:'motes',tier:4},
 /* additional sets */
 smock:{mat:'cloth',leg:'cloth',helm:'bare',pauld:'soft',skirt:'kilt',pat:'plain',hair:'#3a2a1a',band:'#c8b080',tier:0},
 traveler:{mat:'cloth',leg:'cloth',helm:'hood',pauld:'soft',skirt:'rag',cape:'short',cc:'#4a5a3a',pat:'sash',tier:0},
 gambeson:{mat:'quilt',leg:'cloth',helm:'cap',helmc:'#aab4c4',pauld:'strap',skirt:'kilt',cape:'',tier:0},
 scout:{mat:'leather',leg:'leather',helm:'hood',pauld:'strap',skirt:'kilt',cape:'short',cc:'#2e4a26',tier:1},
 druid:{mat:'cloth',wrap:'#e8dca0',leg:'cloth',helm:'circ',crest:'antler',pauld:'leaf',skirt:'rag',cape:'short',cc:'#3a6a30',pat:'vwrap',fx:'petals',emb:'leaf',tier:2},
 studded:{mat:'brig',leg:'leather',helm:'cap',helmc:'#aab4c4',pauld:'strap',skirt:'kilt',cape:'',tier:1},
 brigandine:{mat:'brig',leg:'leather',helm:'cap',helmc:'#aeb8c8',paulc:'#aeb8c8',pauld:'lames',skirt:'tassets',cape:'short',cc:'hcd',emb:'',tier:2},
 monk:{mat:'cloth',leg:'cloth',helm:'bare',pauld:'soft',skirt:'tabard',tab:'#c8382a',pat:'vwrap',wrap:'#f4e8c8',band:'#ffd76a',hair:'#1a1210',emb:'sun',tier:2},
 dwarf:{mat:'mail',leg:'mail',helm:'great',crest:'horns',pauld:'dome',skirt:'mail',cape:'short',cc:'#5a3a22',emb:'',tier:2},
 samurai:{mat:'lacq',leg:'plate',helm:'kabuto',crest:'maedate',pauld:'sode',skirt:'tassets',cape:'',emb:'sun',tier:3},
 crusader:{mat:'plate',leg:'plate',helm:'great',crest:'',pauld:'lames',skirt:'tabard',tab:'#f4f0e4',cape:'royal',cc:'#b8283a',emb:'cross',embc:'#c8283a',tier:3},
 verdant:{mat:'scale',leg:'plate',helm:'circ',crest:'antler',pauld:'leaf',skirt:'tassets',cape:'short',cc:'#2f5a28',emb:'leaf',fx:'petals',tier:3},
 phoenix:{mat:'plate',leg:'plate',helm:'great',crest:'flame',pauld:'wing',skirt:'tassets',cape:'wings',emb:'wing',fx:'embers',tier:4},
 revenant:{mat:'plate',leg:'plate',helm:'great',crest:'horns',pauld:'spike',skirt:'tassets',cape:'tatter',cc:'#0e1a14',emb:'rune',fx:'souls',tier:4},
 titan:{mat:'plate',leg:'plate',helm:'great',crest:'spikes',pauld:'dome',skirt:'tassets',cape:'royal',cc:'hcd',emb:'star',tier:4},
 eclipse:{mat:'plate',leg:'plate',helm:'great',crest:'corona',pauld:'lames',skirt:'tabard',tab:'#1a1240',cape:'galaxy',cc:'#161040',emb:'eclipse',fx:'stars',tier:4,gem:1}
};
/* prestige sets: escalating silhouettes on the shared kit */
Object.assign(AK,{
 pr1:{helm:'great',crest:'plume',pauld:'lames',skirt:'tassets',cape:'royal',cc:'hc'},
 pr2:{helm:'great',crest:'plume',pauld:'spike',skirt:'tassets',cape:'royal',cc:'hc',emb:'cross'},
 pr3:{helm:'great',crest:'crown',pauld:'dome',skirt:'tabard',tab:'#fff0b0',cape:'royal',cc:'hc',emb:'sun'},
 pr4:{helm:'circ',crest:'crown',crown:'ice',pauld:'crystal',cape:'long',cc:'#cfe4ff',emb:'snow',fx:'snow'},
 pr5:{helm:'great',crest:'horns',pauld:'spike',cape:'tatter',cc:'#5a0a18',emb:'flame',fx:'embers'},
 pr6:{mat:'plate',leg:'plate',helm:'great',crest:'blades',pauld:'leaf',skirt:'tassets',cape:'royal',cc:'#0c4a2a',emb:'leaf',fx:'petals',tier:4},
 pr7:{helm:'cowl',crest:'crown',pauld:'spike',cape:'wings',emb:'rune',fx:'void'},
 pr8:{helm:'great',crest:'horns',pauld:'spike',cape:'wings',emb:'flame',fx:'embers'},
 pr9:{helm:'great',crest:'wings',pauld:'lames',skirt:'tabard',tab:'#fff4d0',cape:'wings',emb:'sun',fx:'motes'},
 pr10:{mat:'plate',leg:'plate',helm:'great',crest:'crown',pauld:'lames',skirt:'tabard',tab:'#ffffff',cape:'wings',emb:'sun',fx:'motes',tier:4}
});
function kitOf(id,A){return Object.assign({},AK.rags,AK[A.base]||{},AK[id]||{})}
/* signature auras (see 30d_aura.js) */
for(const [k,v] of Object.entries({shadow:'smoke',glacier:'frost',dragon:'wyrm',sun:'halo',bone:'wisps',jade:'blades',ember:'inferno',tide:'tide',nightsong:'crescent',thunder:'storm',blood:'bloodmoon',void:'rift',ascend:'prism',phoenix:'pyre',revenant:'souls',titan:'forge',eclipse:'eclipse',crusader:'holy',verdant:'leaves',samurai:'blossom',pr3:'halo',pr4:'frost',pr5:'wyrm',pr6:'leaves',pr7:'rift',pr8:'smoke',pr9:'halo',pr10:'prism'}))AK[k].aura=v;
AK.blood.fx='';
