/* ===== MOONLIT FISHING: the landing menu, the Angler's Journal and the Rod Workshop =====
   fishing() now opens the landing menu (fsHub): the moonlit pond as a living backdrop, the title, tonight's moon with
   its featured fish, a big Go Fishing button and four tiles (Angler's Journal, Rod Workshop, Creel, Stats).
   Go Fishing opens the pond (fsPond, the old fishing screen); Back from the pond returns here, Back here goes home.
   fsJournal(id) is a full-screen leather-bound book: the left page indexes all 24 fish (rarity bookmarks on top),
   the right page is the selected fish's entry (painted portrait, lore, field notes, a size ruler with the record and
   the giant zone). Arrow keys or the page corners turn pages; a page-turn animation plays (transform only).
   fsWorkshop() shows the rod model large on a workbench, the five rod tiers, the upgrades and the rod looks. */
const fsPond=fishing;
fishing=function(){fsHub()};
const FSH={jsel:null,jflt:'all'};
function fsLeave(){if(FS.st==='reveal'&&FS.pend){const c=FS.pend;if(!fsDefKeep(c)||!fsKeep(c))fsSell(c);FS.pend=null}fsStop();try{fsHub()}catch(e){title()}}
/* ---------- shared backdrop ---------- */
function fsBackdrop(cv,dim){const g=cv.getContext('2d');const V={noHero:1,shadows:[],rm:fsRM()};let sh=null;
 return ()=>{const t=performance.now()/1000;if(!sh){sh=[0,1,2].map(i=>({x:700+i*160,y:650+i*40,r:20+i*6,dir:i%2?1:-1,a:.16,ph:i*3}))}sh.forEach(s=>{s.x+=s.dir*.25;if(s.x>1200)s.dir=-1;if(s.x<640)s.dir=1});V.shadows=sh;fsScene(g,t,V);if(dim){g.fillStyle=dim;g.fillRect(0,0,1600,900)}}}
/* ---------- the landing menu ---------- */
function fsHub(){S.mode='fish';S.view='fishhub';FS.on=false;fsP();const F=fsP(),M=fsMoon(),n=fsFound(),tier=fsTier(),cr=F.cr.length,crv=F.cr.reduce((a,c)=>a+fsValue(c),0),s=F.s;
 const upCan=FSUPK.some(k=>{const c=fsUpCost(k);return c!=null&&P.gold>=c}),skCan=FSKINK.some(k=>fsCanSkin(k));
 show(`<div class="fsx fshub" id="fsx"><canvas id="fshb" width="1600" height="900" aria-hidden="true"></canvas><i class="fshvig"></i>
 <div class="fstr"><span class="fsgold fsg">${fsCoin}<b id="fsgold">${P.gold.toLocaleString()}</b></span><button class="fsback fsg" id="fsback"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 5l-7 7 7 7" stroke="currentColor" stroke-width="2.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>Back <kbd>Esc</kbd></button></div>
 <section class="fshl">
  <p class="fshk"><span class="fshkm"><canvas id="fshmn" width="44" height="44"></canvas></span>THE TAVERN POND</p>
  <h1 class="fsht">Moonlit <em>Fishing</em></h1>
  <p class="fshs">Cast a line, wait for a bite and type the word before it slips away. Every fish you land fills your Angler's Journal.</p>
  <div class="fshmoon fsg"><canvas id="fshfeat" width="220" height="130"></canvas><div><small>TONIGHT · ${fsEsc(M.n.toUpperCase())}</small><b>${FISH[M.feat].n}</b><span>Bites twice as often and sells for +50% tonight.</span><em>${fsEsc(M.d)}</em></div></div>
  <button class="fshgo" id="fshgo"><span class="fshgoi" aria-hidden="true">${fsFishIc()}</span>Go Fishing<i>›</i><kbd>Space</kbd></button>
  <div class="fshtl">
   <button class="fsht2 fsg" id="fshj" style="--c:#ffd45a"><span class="fshic"><canvas id="fshjc" width="120" height="96"></canvas></span><b>Angler's Journal</b><small>${n} / ${FIDS.length} fish found</small><span class="fshpr"><i style="width:${n/FIDS.length*100}%"></i></span></button>
   <button class="fsht2 fsg" id="fshw" style="--c:#a898ff"><span class="fshic"><canvas id="fshwc" width="120" height="96"></canvas></span><b>Rod Workshop</b><small>${FSTIERN[tier]} · Lv ${fsLv()}/15</small>${upCan||skCan?'<i class="fshdot">!</i>':''}</button>
   <button class="fsht2 fsg" id="fshc" style="--c:#7ad8ff"><span class="fshic"><canvas id="fshcc" width="120" height="96"></canvas></span><b>Creel</b><small>${cr} / ${FSCREEL} kept${cr?` · ${crv.toLocaleString()} gold`:''}</small></button>
   <button class="fsht2 fsg" id="fshs" style="--c:#7affb4"><span class="fshic"><canvas id="fshsc" width="120" height="96"></canvas></span><b>Stats</b><small>${(s.caught||0).toLocaleString()} caught · best streak ${s.best||0}</small></button>
  </div></section>
 <div class="fsmod" id="fsmod" hidden></div></div>`,'fshx');
 S.back=()=>{fsModal(null);title()};{const cn=$('cn');if(cn)cn.classList.add('dkhid')}
 const bd=$('fshb');LIVE.push({cv:bd,fn:fsBackdrop(bd)});
 live('fshmn',c=>{const x=c.getContext('2d');return t=>{x.setTransform(1,0,0,1,0,0);x.clearRect(0,0,44,44);fsMoonIcon(x,22,22,16,M.ph,t)}});
 live('fshfeat',c=>{const x=c.getContext('2d');return t=>{x.setTransform(1,0,0,1,0,0);x.clearRect(0,0,220,130);fkGlow(x,110,65,90,FSR[FISH[M.feat].r].c,.22);fishFit(x,M.feat,110,66,200,118,{t})}});
 live('fshjc',c=>{const x=c.getContext('2d');return t=>{x.setTransform(1,0,0,1,0,0);x.clearRect(0,0,120,96);fsBookIcon(x,60,50,t)}});
 live('fshwc',c=>{const x=c.getContext('2d');return t=>{x.setTransform(1,0,0,1,0,0);x.clearRect(0,0,120,96);fsRod(x,16,86,-.62,0,104,t,fsSkin(),tier)}});
 {const x=$('fshcc').getContext('2d');fsCreelIcon(x,60,52)}
 {const x=$('fshsc').getContext('2d');fsStatIcon(x,60,50)}
 $('fsback').onclick=()=>title();$('fshgo').onclick=fsPond;$('fshj').onclick=()=>fsJournal();$('fshw').onclick=fsWorkshop;
 $('fshc').onclick=()=>fsPanelModal('c');$('fshs').onclick=()=>fsPanelModal('s');
 setTimeout(()=>{const b=$('fshgo');try{b&&b.focus({preventScroll:true})}catch(e){}},60)}
/* creel and stats from the landing menu reuse the panel's pages in a modal */
function fsPanelModal(tab){FSU.tab=tab;fsModal(`<div class="fspm fsg"><button class="fsx2" id="fsx2" aria-label="Close">✕</button><div class="fsbody" id="fsbody"></div></div>`);$('fsx2').onclick=()=>{fsModal(null);fsHub()};fsTabs()}
/* tile icons */
function fsBookIcon(g,x,y,t){g.save();g.translate(x,y);g.rotate(-.08);const w=70,h=56;g.fillStyle='#4a2a1a';g.beginPath();g.roundRect(-w/2-4,-h/2-3,w+8,h+6,6);g.fill();g.lineWidth=2.6;g.strokeStyle=FKO;g.stroke();
 g.fillStyle=fkLin(g,0,-h/2,0,h/2,['#f6ead0','#e2cc9e']);g.fillRect(-w/2,-h/2,w/2-1,h);g.fillRect(1,-h/2,w/2-1,h);g.strokeStyle='#8a6a3a';g.lineWidth=1;for(let i=0;i<4;i++){g.beginPath();g.moveTo(6,-14+i*9);g.lineTo(w/2-6,-14+i*9);g.stroke()}
 g.fillStyle='#00000030';g.fillRect(-3,-h/2,6,h);g.save();g.translate(-w/4,0);g.scale(.13,.13);fishDraw(g,'moonfin',{t});g.restore();g.fillStyle='#e8364e';g.fillRect(w/2-14,-h/2-6,8,20);g.restore()}
function fsCreelIcon(g,x,y){g.save();g.translate(x,y);g.fillStyle=fkLin(g,0,-24,0,30,['#c89a5a','#7a5228']);g.beginPath();g.moveTo(-34,-14);g.lineTo(34,-14);g.lineTo(28,30);g.lineTo(-28,30);g.closePath();g.fill();g.lineWidth=2.6;g.strokeStyle=FKO;g.stroke();
 g.strokeStyle='#5a3a18';g.lineWidth=1.4;for(let i=-2;i<=2;i++){g.beginPath();g.moveTo(i*12,-14);g.lineTo(i*10,30);g.stroke()}for(let j=0;j<3;j++){g.beginPath();g.moveTo(-33+j*2,-2+j*11);g.lineTo(33-j*2,-2+j*11);g.stroke()}
 g.save();g.translate(-6,-22);g.rotate(-.3);g.scale(.18,.18);fishDraw(g,'ember',{t:.5});g.restore();g.save();g.translate(12,-20);g.rotate(.35);g.scale(.15,.15);fishDraw(g,'copper',{t:.2});g.restore();
 g.strokeStyle=FKO;g.lineWidth=3;g.beginPath();g.arc(0,-14,30,Math.PI*1.1,Math.PI*1.9);g.stroke();g.strokeStyle='#8a5a2e';g.lineWidth=1.6;g.stroke();g.restore()}
function fsStatIcon(g,x,y){g.save();g.translate(x,y);const bars=[18,30,24,40];bars.forEach((h,i)=>{const bx=-30+i*16;g.fillStyle=['#5ab8ff','#7affb4','#ffd45a','#ff9ad8'][i];g.beginPath();g.roundRect(bx,26-h,12,h,3);g.fill();g.lineWidth=2.2;g.strokeStyle=FKO;g.stroke()});
 g.strokeStyle='#fff8e8';g.lineWidth=2.4;g.beginPath();g.moveTo(-28,12);g.lineTo(-12,0);g.lineTo(4,6);g.lineTo(22,-16);g.stroke();fkSpark(g,22,-18,6,'#fff6c0',1);g.restore()}
/* ---------- the Angler's Journal ---------- */
function fsJournal(id){S.mode='fish';S.view='fishjournal';FS.on=false;const F=fsP();if(id)FSH.jsel=id;if(!FSH.jsel||!FISH[FSH.jsel])FSH.jsel=FIDS.find(i=>F.b[i]&&F.b[i].n)||FIDS[0];
 const back=FSH.jback||fsHub;
 show(`<div class="fsx fsjx" id="fsx"><canvas id="fsjb" width="1600" height="900" aria-hidden="true"></canvas>
 <div class="fsjbook"><div class="fsjrib">${[['all','All','#b8a8e8'],...FSRK.map(k=>[k,FSR[k].n,FSR[k].c])].map(([k,l,c])=>`<button data-jf="${k}" class="${FSH.jflt===k?'on':''}" style="--rc:${c}">${l}</button>`).join('')}</div>
  <div class="fsjpg l"><header><h2>Angler's Journal</h2><span id="fsjcount"></span></header><div class="fsjgrid" id="fsjgrid"></div><div class="fsjprog" id="fsjprog"></div><footer><span>${fsEsc(P.name||'Hero')}'s log</span><span>Tavern Pond</span></footer></div>
  <div class="fsjspine"></div>
  <div class="fsjpg r" id="fsjr"></div><div class="fsjflip" id="fsjflip"></div>
  <button class="fsjnav p" id="fsjp" aria-label="Previous fish">‹</button><button class="fsjnav n" id="fsjn" aria-label="Next fish">›</button></div>
 <button class="fsback fsg fsjbk" id="fsback"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 5l-7 7 7 7" stroke="currentColor" stroke-width="2.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>Back <kbd>Esc</kbd></button></div>`,'fshx');
 S.back=()=>{FSH.jback=null;back()};$('fsback').onclick=S.back;{const cn=$('cn');if(cn)cn.classList.add('dkhid')}
 const bd=$('fsjb');LIVE.push({cv:bd,fn:fsBackdrop(bd,'rgba(6,3,20,.62)'),slow:3});
 ov.querySelectorAll('[data-jf]').forEach(b=>b.onclick=()=>{FSH.jflt=b.dataset.jf;ov.querySelectorAll('[data-jf]').forEach(x=>x.classList.toggle('on',x===b));fsJGrid()});
 $('fsjp').onclick=()=>fsJStep(-1);$('fsjn').onclick=()=>fsJStep(1);
 fsJGrid();fsJPage(0)}
function fsJList(){return FIDS.filter(i=>FSH.jflt==='all'||FISH[i].r===FSH.jflt)}
function fsJGrid(){const F=fsP(),L=fsJList(),gd=$('fsjgrid');if(!gd)return;const n=fsFound(),gi=FIDS.filter(i=>F.b[i]&&F.b[i].g).length;$('fsjcount').textContent=`${n} / ${FIDS.length} found · ${gi} giants`;
 gd.innerHTML=L.map(i=>{const b=F.b[i],got=b&&b.n;return `<button class="fsjen${got?'':' unk'}${i===FSH.jsel?' on':''}" data-j="${i}" style="--rc:${FSR[FISH[i].r].c}" aria-label="${got?FISH[i].n:'Undiscovered'}"><canvas width="132" height="84"></canvas><b>${got?FISH[i].n:'???'}</b>${b&&b.g?'<i class="fsjcr">♛</i>':''}${i===fsMoon().feat?'<i class="fsjft">★</i>':''}</button>`}).join('');
 const pg=$('fsjprog');if(pg)pg.innerHTML=`<h4>Collection</h4>`+FSRK.map(k=>{const ids=FIDS.filter(i=>FISH[i].r===k),got=ids.filter(i=>F.b[i]&&F.b[i].n).length,gg=ids.filter(i=>F.b[i]&&F.b[i].g).length;return `<div class="fsjpr" style="--rc:${FSR[k].c}"><b>${FSR[k].n}</b><span class="fsjpb"><i style="width:${got/ids.length*100}%"></i></span><em>${got} / ${ids.length}</em><small>♛ ${gg}</small></div>`}).join('')+(n===FIDS.length?'<p class="fsjdone">Every fish in the pond is logged. A true master angler!</p>':'<p class="fsjhint">Undiscovered fish show as shadows. Rare and Legendary fish bite more often with a better Lure.</p>');
 gd.querySelectorAll('[data-j]').forEach(x=>{const i=x.dataset.j,b=F.b[i];fsThumb(x.querySelector('canvas'),i,!(b&&b.n),.4,'#5a4a3a');x.onclick=()=>{if(FSH.jsel!==i){const d=FIDS.indexOf(i)>FIDS.indexOf(FSH.jsel)?1:-1;FSH.jsel=i;gd.querySelectorAll('.fsjen').forEach(e=>e.classList.toggle('on',e===x));fsJPage(d)}}})}
function fsJStep(d){const L=fsJList();let k=L.indexOf(FSH.jsel);k=k<0?0:(k+d+L.length)%L.length;FSH.jsel=L[k];ov.querySelectorAll('.fsjen').forEach(e=>e.classList.toggle('on',e.dataset.j===FSH.jsel));fsJPage(d)}
function fsJPage(dir){const r=$('fsjr');if(!r)return;const id=FSH.jsel,f=FISH[id],R=FSR[f.r],b=fsP().b[id],got=b&&b.n,feat=id===fsMoon().feat;
 const lo=fsValue({id,cm:f.len[0],g:0}),hi=fsValue({id,cm:f.len[1],g:0}),gz=f.len[0]+(f.len[1]-f.len[0])*.92,pc=v=>((v-f.len[0])/(f.len[1]-f.len[0])*100).toFixed(1);
 const fmt=ts=>{try{return new Date(ts).toLocaleDateString(undefined,{month:'short',day:'numeric',year:'numeric'})}catch(e){return''}};
 const hint={c:'Common: bites often with any rod.',u:'Uncommon: a little rarer. A better Lure helps.',r:'Rare: two words to reel in. Upgrade your Lure and Line.',l:'Legendary: three words and a long fight. Watch for the full moon.'}[f.r];
 r.innerHTML=`<div class="fsjent" style="--rc:${R.c}">
  <div class="fsjtop"><span class="fsjno">No. ${String(FIDS.indexOf(id)+1).padStart(2,'0')}</span><span class="fsjrr">${R.n}</span>${feat?'<span class="fsjfeat">★ Featured tonight</span>':''}</div>
  <div class="fsjart"><canvas id="fsjcv" width="600" height="300"></canvas>${got&&b.g?'<span class="fsjstamp g">♛ GIANT</span>':''}${!got?'<span class="fsjstamp u">NOT YET CAUGHT</span>':''}</div>
  <h3>${got?f.n:'???'}</h3>
  <p class="fsjlore">${got?fsEsc(f.d):'Only its shadow has been seen in the pond. '+hint}</p>
  <div class="fsjruler"><div class="fsjrl"><span>${f.len[0]} cm</span><span>Size</span><span>${f.len[1]} cm</span></div><div class="fsjbar"><i class="gz" style="left:${pc(gz)}%"></i>${got?`<i class="rec" style="left:${pc(b.big)}%" title="Your record"></i>`:''}</div>${got?`<small>Your record: <b>${b.big} cm</b>${b.bigT?` · ${fmt(b.bigT)}`:''}</small>`:'<small>Catch one to record its size.</small>'}</div>
  <div class="fsjnotes"><span><small>Caught</small><b>${got?b.n:0}</b></span><span><small>Giants</small><b>${got?(b.g||0):0}</b></span><span><small>Worth</small><b>${lo}–${hi}</b></span><span><small>First catch</small><b>${got&&b.t?fmt(b.t):'—'}</b></span></div></div>`;
 live('fsjcv',cv=>{const g=cv.getContext('2d');return t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,600,300);fkGlow(g,300,150,240,R.c,got?.2:.08);fishFit(g,id,300,152,560,280,{t,sil:got?0:'#4a3a2a',glow:got&&R.k>=2?.5:0})}});
 if(dir){const fl=$('fsjflip');if(fl&&!fsRM()){fl.className='fsjflip '+(dir>0?'fw':'bw');void fl.offsetWidth;fl.classList.add('go')}try{beep(dir>0?620:560,.04,'triangle',.14)}catch(e){}}}
/* ---------- the Rod Workshop ---------- */
function fsWorkshop(){S.mode='fish';S.view='fishwork';FS.on=false;const F=fsP(),lv=fsLv(),tier=fsTier();
 const next=[3,6,10,15].find(x=>x>lv);
 const ups=FSUPK.map(k=>{const U=FSUP[k],l=F.up[k]||0,c=fsUpCost(k);return `<div class="fswu fsg"><div class="fswui">${fsUpIcon(k)}</div><div class="fswut"><b>${U.n}</b><span class="fspips">${[0,1,2,3,4].map(i=>`<i class="${i<l?'on':''}"></i>`).join('')}</span><small>${U.d}</small><small class="fsupfx">Now: ${U.fx(l)}${c!=null?` → <b>${U.fx(l+1)}</b>`:''}</small></div>${c==null?'<span class="fsmax">MAX</span>':`<button data-up="${k}" ${P.gold<c?'disabled':''}>${fsCoin}${c.toLocaleString()}</button>`}</div>`}).join('');
 const looks=FSKINK.map(k=>{const K=FSKIN[k],own=F.sk[k],eq=F.skin===k,can=fsCanSkin(k);const req=Object.entries(K.k).map(([id,n])=>{const have=F.cr.filter(c=>c.id===id).length;return `<span class="fsreq${have>=n?' ok':''}" data-req="${id}" title="${FISH[id].n}"><canvas width="44" height="26"></canvas>${Math.min(have,n)}/${n}</span>`}).join('');
  return `<div class="fswl${eq?' eq':''}${own?'':' lk'}" data-sk="${k}" style="--sc:${K.gl||K.c[1]}"><canvas width="220" height="70"></canvas><b>${K.n}</b><small>${K.d}</small>${own?'':`<span class="fsreqs">${req}</span>`}${eq?'<span class="fseq">Equipped</span>':own?'<button>Equip</button>':`<button ${can?'':'disabled'}>Turn in fish</button>`}</div>`}).join('');
 show(`<div class="fsx fswx" id="fsx"><canvas id="fswb" width="1600" height="900" aria-hidden="true"></canvas>
 <div class="fstr"><span class="fsgold fsg">${fsCoin}<b id="fsgold">${P.gold.toLocaleString()}</b></span><button class="fsback fsg" id="fsback"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 5l-7 7 7 7" stroke="currentColor" stroke-width="2.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>Back <kbd>Esc</kbd></button></div>
 <h2 class="fswh">Rod Workshop</h2>
 <section class="fswbench fsg"><canvas id="fswrod" width="900" height="230"></canvas><div class="fswname"><b>${FSTIERN[tier]}</b><small>Level ${lv} / 15${next?` · next rod at level ${next}`:' · the finest rod there is'}</small></div>
  <div class="fswtiers">${FSTIERN.map((n,i)=>`<span class="${i<=tier?'got':''}${i===tier?' cur':''}"><canvas width="120" height="44" data-tier="${i}"></canvas><em>${n.replace(' Rod','')}</em><small>${[0,3,6,10,15][i]===0?'start':'Lv '+[0,3,6,10,15][i]}</small></span>`).join('')}</div></section>
 <section class="fswcol"><h4 class="fssub">Upgrades <small>spend gold · every level improves your rod</small></h4>${ups}</section>
 <section class="fswcol r"><h4 class="fssub">Rod looks <small>turn in kept fish from your creel</small></h4><div class="fswlooks">${looks}</div></section></div>`,'fshx');
 S.back=fsHub;$('fsback').onclick=fsHub;{const cn=$('cn');if(cn)cn.classList.add('dkhid')}
 const bd=$('fswb');LIVE.push({cv:bd,fn:fsBackdrop(bd,'rgba(6,3,20,.72)'),slow:3});
 live('fswrod',cv=>{const g=cv.getContext('2d');return t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,900,230);g.save();g.scale(1.9,1.9);fsRod(g,40,104,-.2,0,410,t,fsSkin(),tier);g.restore()}});
 ov.querySelectorAll('canvas[data-tier]').forEach(c=>{const i=+c.dataset.tier,g=c.getContext('2d');g.save();g.translate(4,0);fsRod(g,8,38,-.28,0,110,1,i<=tier?fsSkin():{c:['#3a3260','#5a5288'],tip:'#5a5288',bob:['#333','#555'],ln:'#555'},i);g.restore();if(i>tier){g.globalCompositeOperation='source-atop';g.fillStyle='#1a1440cc';g.fillRect(0,0,120,44)}});
 ov.querySelectorAll('[data-up]').forEach(x=>x.onclick=()=>{if(fsBuyUp(x.dataset.up)){fsSfx('buy');const t2=fsTier();fsWorkshop();if(t2>tier)setTimeout(()=>fsWorkToast(`New rod: the ${FSTIERN[t2]}!`),80)}});
 ov.querySelectorAll('[data-sk]').forEach(x=>{const k=x.dataset.sk,cv=x.querySelector('canvas');if(cv){const g=cv.getContext('2d');fsRod(g,14,cv.height-14,-.22,0,cv.width*.86,1,FSKIN[k],tier)}const bt=x.querySelector('button');if(bt)bt.onclick=()=>{const F2=fsP();if(F2.sk[k]){F2.skin=k;save()}else if(fsCraft(k)){fsSfx('r')}fsWorkshop()}});
 ov.querySelectorAll('[data-req]').forEach(x=>{const cv=x.querySelector('canvas');if(cv)fsThumb(cv,x.dataset.req,!(fsP().b[x.dataset.req]&&fsP().b[x.dataset.req].n),.4,'#5a4ca0')})}
function fsWorkToast(m){const d=document.createElement('div');d.className='fstoast on';d.style.cssText='left:550px;bottom:30px';d.textContent=m;$('fsx')&&$('fsx').appendChild(d);setTimeout(()=>d.remove(),2400)}
function fsUpIcon(k){return {line:`<svg viewBox="0 0 48 48"><circle cx="24" cy="24" r="15" fill="#3a3070" stroke="#1b1024" stroke-width="3"/><circle cx="24" cy="24" r="9" fill="none" stroke="#c8d0ff" stroke-width="3"/><path d="M24 9 C40 6 44 30 30 40" fill="none" stroke="#f4ecd8" stroke-width="2"/></svg>`,
 lure:`<svg viewBox="0 0 48 48"><path d="M12 22 C18 12 32 12 38 22 C32 32 18 32 12 22Z" fill="#ff7a4a" stroke="#1b1024" stroke-width="3"/><circle cx="31" cy="21" r="3" fill="#1b1024"/><path d="M12 22 L5 16 L5 28Z" fill="#ffd45a" stroke="#1b1024" stroke-width="2.4"/><path d="M38 22 L44 22" stroke="#c8c8d0" stroke-width="2"/></svg>`,
 hook:`<svg viewBox="0 0 48 48"><path d="M26 6 V30 A9 9 0 1 1 12 26" fill="none" stroke="#1b1024" stroke-width="7" stroke-linecap="round"/><path d="M26 6 V30 A9 9 0 1 1 12 26" fill="none" stroke="#e6e6f4" stroke-width="3.4" stroke-linecap="round"/><path d="M9 22 L12 26 L16 22" fill="none" stroke="#e6e6f4" stroke-width="3" stroke-linecap="round"/></svg>`}[k]}
/* keys for the hub pages */
document.addEventListener('keydown',e=>{if(S.mode!=='fish'||e.ctrlKey||e.metaKey||e.altKey)return;const v=S.view;const mod=$('fsmod');if(mod&&!mod.hidden){if(e.key==='Escape'&&v!=='fish'){e.preventDefault();e.stopImmediatePropagation();fsModal(null);if(v==='fishhub')fsHub()}return}
 if(v==='fishhub'&&(e.key===' '||e.key==='Enter')&&document.activeElement&&!/fsht2/.test(document.activeElement.className)){e.preventDefault();e.stopImmediatePropagation();fsPond()}
 else if(v==='fishjournal'&&(e.key==='ArrowRight'||e.key==='ArrowLeft')){e.preventDefault();e.stopImmediatePropagation();fsJStep(e.key==='ArrowRight'?1:-1)}},true);
