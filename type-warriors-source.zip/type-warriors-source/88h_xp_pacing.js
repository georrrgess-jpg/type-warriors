/* ===== XP PACING =====
   Player level now follows the campaign instead of the score counter.
   xpT(n) is where a player who has cleared n campaign levels should stand: it rises quickly through the early paths
   (Archer, Mage, Rogue all open by level 7) and flattens through the second half, so clearing level 30 lands at about
   level 29.8. The last sliver of level 30 comes from Act VI or any other mode, and then Prestige opens.
   - first clear of a campaign level fills the gap to xpT(n) (never less than 30% or more than 175% of that level's share)
   - defeats pay for the rounds you got through; replays pay 30% of a first clear
   - Endless, Beginner, Monster Mash, Starfall Rift and the Daily Challenge pay in full until you are half a level's
     share ahead of your campaign; past that they pay 35%, and 15% further out. Once the campaign is clear there is no limit.
   Scholar (+5% a rank, as its card says) and Prestige (+10% each) raise the targets, so they still level you faster. */
const XPB={L30:29.8,EXP:.8,FLOOR:.3,HI:1.75,REPLAY:.3,LOSS:.4,HEAD:.5,BAND:2,R1:.35,R2:.15};
const xpAtL=L=>{L=Math.max(1,Math.min(MAXLV,L));const f=Math.floor(L),a=lvx(f);return f>=MAXLV?a:a+(L-f)*(lvx(f+1)-a)};
const xpLt=n=>n<=0?1:1+(XPB.L30-1)*Math.pow(Math.min(n,30)/30,XPB.EXP);
const xpT=n=>n<=0?0:Math.round(xpAtL(xpLt(n)));
const xpBase=n=>Math.max(1,xpT(Math.min(30,n))-xpT(Math.min(30,n)-1));
const xpCleared=()=>{let c=0;const st=P&&P.stars||{};for(let i=1;i<=30;i++)if(st[i])c++;return c};
const xpMulP=()=>1+.05*U('scholar')+.1*(P.pres||0);        /* lasting bonuses: they scale the targets */
const xpMulRun=()=>xpMulP()+(S&&S.xpm||0);                  /* plus this run's companion bonus */
let XPN=null,XPR=null;                                       /* note for the result screen, and the bar animation */
const xpCeil=()=>{const c=xpCleared();return c>=30?Infinity:(xpT(c)+XPB.HEAD*xpBase(c+1))*xpMulP()};
/* pay g XP through the soft ceiling */
function xpSoft(g){g=Math.max(0,+g||0);const x=P.xp,C=xpCeil();let out=g;
 if(isFinite(C)){const band=XPB.BAND*xpBase(xpCleared()+1)*xpMulP();let rem=g,cur=x;out=0;
  if(cur<C){const t=Math.min(rem,C-cur);out+=t;rem-=t;cur+=t}
  if(rem>0&&cur<C+band){const t=Math.min(rem,(C+band-cur)/XPB.R1);out+=t*XPB.R1;rem-=t;cur+=t*XPB.R1}
  if(rem>0)out+=rem*XPB.R2}
 out=Math.round(out);if(out<g-1)XPN={k:'cut',n:xpCleared()+1,full:Math.round(g)};return xpRec(out)}
function xpRec(xp){XPR={x0:P.xp,x1:P.xp+xp,t:performance.now()};return xp}
/* winning campaign level n with the given stars */
function xpCampWin(n,stars,first){XPN=null;const m=xpMulP(),b=xpBase(n)*m,perf=[.9,.95,1][stars-1]||1,r=xpMulRun()/m;
 if(!first){XPN={k:'replay'};return xpSoft(Math.round(b*XPB.REPLAY*perf*r))}
 const want=xpT(n)*m-P.xp,a=Math.max(XPB.FLOOR*b,Math.min(XPB.HI*b,want));
 const xp=Math.max(10,Math.round(a*perf*r/5)*5);if(n===30)XPN={k:'last'};return xpRec(xp)}
/* falling in campaign level n: pay for the rounds got through */
function xpCampLoss(n){XPN=null;const m=xpMulP(),b=xpBase(n)*m,first=!P.stars[n],frac=Math.max(.1,(Math.max(1,S.round||1)-.5)/5);
 return xpSoft(Math.max(5,Math.round(b*(first?XPB.LOSS:XPB.REPLAY*.5)*frac*xpMulRun()/m)))}
/* any other mode */
function xpMode(raw){XPN=null;return xpSoft(raw)}
/* the Daily Challenge was flat; let it grow with the player so it stays worth a look later on */
const xpDcScale=xp=>Math.round(xp*(1+(lvl(P.xp)-1)/12)/5)*5;
function xpNoteH(){const z=XPN;XPN=null;if(!z)return'';
 if(z.k==='cut')return`<br><small class="xpnote">You are ahead of your campaign, so this mode paid less XP (${z.full.toLocaleString()} at full rate). Clear campaign level ${z.n} to earn full XP again.</small>`;
 if(z.k==='replay')return`<br><small class="xpnote">Replays pay ${Math.round(XPB.REPLAY*100)}% of a first clear.</small>`;
 if(z.k==='last'){const l=lvl(P.xp),need=lvx(MAXLV)-P.xp;if(l<MAXLV&&need>0)return`<br><small class="xpnote gold">Only ${need.toLocaleString()} XP to level ${MAXLV}! Act VI or any mode will get you there, and level ${MAXLV} opens Prestige.</small>`}
 return''}
/* the companion's share of the XP, now that the bonus is applied once at the end */
function petResultXp(x0){const p=PP();if(!p||PDEF[p.id].ab.k!=='scholar')return;if(x0==null)return;const dx=P.xp-x0;p.xs=Math.round(dx*.05/Math.max(1,xpMulRun()))}

/* ---- animated XP bar on the result screens ---- */
{const s0=show;show=function(h,c){let bar=null;
 try{const R=XPR;if(R&&S.mode==='over'&&typeof h==='string'&&/Earned/.test(h)&&performance.now()-R.t<15000&&h.indexOf('<div class="row">')>0){XPR=null;bar=R;
   const l=lvl(R.x0);h=h.replace('<div class="row">',`<div class="xpbar" id="xpbar"><b class="xpb-lv"><span>LEVEL</span><em id="xpbl">${l}</em></b><div class="xpb-tr"><i class="xpb-f" id="xpbf" style="width:${xpPct(R.x0)}%"></i><i class="xpb-sh"></i></div><span class="xpb-g" id="xpbg">+0 XP</span><span class="xpb-nx" id="xpbn"></span></div><div class="row">`)}}catch(e){bar=null}
 const r=s0.call(this,h,c);if(bar)try{xpBarRun(bar)}catch(e){}return r}}
function xpBarRun(R){const el=document.getElementById('xpbar');if(!el)return;const f=document.getElementById('xpbf'),lb=document.getElementById('xpbl'),g=document.getElementById('xpbg'),nx=document.getElementById('xpbn');
 const l0=lvl(R.x0),l1=lvl(R.x1),gain=R.x1-R.x0,red=matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
 const segs=[];for(let l=l0;l<=l1;l++){const a=l===l0?xpPct(R.x0):0,b=l===l1?xpPct(R.x1):100;segs.push([l,a,b])}
 const nxTxt=l=>l>=MAXLV?'Max level':`${Math.max(0,lvx(l+1)-R.x1).toLocaleString()} to level ${l+1}`;
 const end=()=>{lb.textContent=l1;f.style.width=xpPct(R.x1)+'%';g.textContent=`+${gain.toLocaleString()} XP`;nx.textContent=nxTxt(l1);el.classList.add('done')};
 if(red||gain<=0){end();return}
 const per=Math.max(.45,Math.min(1.1,1.6/segs.length)),T0=performance.now()+350,tot=per*segs.length;let si=-1;
 const ease=u=>1-Math.pow(1-u,3);
 const step=now=>{if(!el.isConnected)return;const t=(now-T0)/1000;if(t<0){requestAnimationFrame(step);return}
  if(t>=tot){end();return}
  const k=Math.min(segs.length-1,Math.floor(t/per)),u=ease((t-k*per)/per),[l,a,b]=segs[k];
  if(k!==si){if(k>0){lb.textContent=l;el.classList.remove('pop');void el.offsetWidth;el.classList.add('pop');try{beep(660+k*90,.08,'sine',.18);setTimeout(()=>beep(990+k*90,.1,'sine',.15),70)}catch(e){}}si=k}
  f.style.width=(a+(b-a)*u)+'%';g.textContent=`+${Math.round(gain*Math.min(1,t/tot)).toLocaleString()} XP`;nx.textContent=l>=MAXLV?'Max level':'';
  requestAnimationFrame(step)};
 requestAnimationFrame(step)}
{const st=document.createElement('style');st.textContent=`
.xpbar{display:flex;align-items:center;gap:12px;width:min(620px,94%);margin:2px auto 10px;padding:7px 14px;border-radius:14px;background:linear-gradient(180deg,rgba(46,34,120,.72),rgba(24,17,70,.78));border:2px solid #6a5ac8;box-shadow:0 3px 0 #120c30,inset 0 1px 0 rgba(255,255,255,.12)}
.xpb-lv{flex:none;min-width:48px;font:400 26px 'Pirata One',var(--ttl,serif);line-height:1;color:var(--gold);letter-spacing:.5px;text-shadow:0 2px 0 #3a2400;display:inline-block;transform-origin:50% 70%;text-align:left}
.xpb-lv span{display:block;font:800 9px var(--ui);letter-spacing:1.5px;color:#c8b888;text-shadow:none;margin-bottom:1px}.xpb-lv em{font-style:normal}
.xpb-g{flex:none;font:800 14px var(--ui);color:#9ae8ff;min-width:84px;text-align:right}.xpb-nx{flex:none;font:600 12px var(--ui);color:#b8aee8;min-width:118px;text-align:right}
.xpb-tr{flex:1;position:relative;height:14px;border-radius:8px;background:#120c30;border:2px solid #0a0620;overflow:hidden;box-shadow:inset 0 2px 4px rgba(0,0,0,.5)}
.xpb-f{position:absolute;left:0;top:0;bottom:0;border-radius:6px;background:linear-gradient(180deg,#ffe58a,#ffb02e 60%,#d98a10);box-shadow:inset 0 -2px 0 rgba(120,60,0,.45),0 0 10px rgba(255,190,60,.55)}
.xpb-sh{position:absolute;inset:0;background:linear-gradient(100deg,transparent 30%,rgba(255,255,255,.28) 45%,transparent 60%);background-size:220% 100%;animation:xpbsh 2.4s ease-in-out infinite;pointer-events:none}
@keyframes xpbsh{0%{background-position:120% 0}100%{background-position:-120% 0}}
@media (max-width:640px){.xpbar{flex-wrap:wrap;gap:6px 10px}.xpb-tr{order:5;flex-basis:100%}.xpb-nx{margin-left:auto}}
.xpbar.pop .xpb-lv{animation:xpbpop .55s cubic-bezier(.3,1.6,.5,1) both}
@keyframes xpbpop{0%{transform:scale(1)}35%{transform:scale(1.35);color:#fff6c0;text-shadow:0 0 16px #ffd76a,0 2px 0 #3a2400}100%{transform:scale(1)}}
.xpbar.done .xpb-g{animation:xpbdn .4s cubic-bezier(.3,1.6,.5,1) both}@keyframes xpbdn{0%{transform:scale(1)}50%{transform:scale(1.15)}100%{transform:scale(1)}}
.xpnote{display:inline-block;margin-top:4px;font:600 13px var(--ui);color:#c4badf;opacity:.95}.xpnote.gold{color:var(--gold)}
@media (prefers-reduced-motion:reduce){.xpb-sh{animation:none}}`;document.head.appendChild(st)}
/* How to play: say how levelling works now */
try{HELP.Progress.unshift(['Player XP',`You level up mostly by clearing campaign levels. Each first clear fills your XP to that level's mark, so finishing the campaign puts you just short of level ${MAXLV}; Act VI or any other mode finishes the job. Replays pay ${Math.round(XPB.REPLAY*100)}% of a first clear. Endless, the Rift and the other modes pay full XP until you get ahead of your campaign, then less, until the campaign is clear.`])}catch(e){}
