/* ===== 9.4 THE CROOKED CUE: opponent AI (96d). Pure functions. Ported from pool_plan/pzai.js, calibrated with pool_plan/aisim.js. =====
   1. Candidates: every legal target x every pocket (direct), plus one-rail banks. Ghost-ball aim; lines must be clear; cut < 80 deg.
   2. Analytic pot chance: aim tolerance over the cue-to-ghost distance against the monster's aim error sigma (erf).
   3. The best few candidates are simulated noise-free (3 spins x 2 powers): drop scratches and misses, add position value
      (best pot chance of the next shot from where the cue ball stops) weighted by the monster's `pos`.
   4. If the best chance is below `safe`, look for a safety (soft legal shot leaving the opponent the lowest chance), then a kick.
   5. The shot is executed with the monster's noise on angle, power and spin. pzaThink is a generator: it yields after every
      simulation so the game can spend a few ms per frame (a Chromebook never freezes). */
const PZ_AIM=[[-2,-2],[440,-7],[882,-2],[-2,442],[440,447],[882,442]];/* where to send the object ball (inside each pocket mouth) */
const PZ_SLACK=[9,7,9,9,7,9];/* half-width the object ball centre can miss by and still drop */
function pzErf(x){const t=1/(1+.3275911*Math.abs(x)),y=1-(((((1.061405429*t-1.453152027)*t)+1.421413741)*t-.284496736)*t+.254829592)*t*Math.exp(-x*x);return x>=0?y:-y}
function pzClear(B,ax,ay,bx,by,skip){const R=PZ_PHY.R,dx=bx-ax,dy=by-ay,L2=dx*dx+dy*dy||1;for(const b of B){if(!b.on||skip.includes(b.id))continue;let t=((b.x-ax)*dx+(b.y-ay)*dy)/L2;if(t<0||t>1)continue;const cx=ax+dx*t,cy=ay+dy*t;if((b.x-cx)**2+(b.y-cy)**2<4*R*R*.98)return false}return true}
const pzClone=B=>B.map(b=>Object.assign({},b));
/* candidates: direct pots and one-rail banks, best first. sigma in radians. */
function pzaCands(B,cue,targets,sigma,wantBank){const R=PZ_PHY.R,PW=PZ_PHY.W,PH=PZ_PHY.H,out=[];
 for(const id of targets){const t=B.find(b=>b.id===id&&b.on);if(!t)continue;
  for(let k=0;k<6;k++){const [ax,ay]=PZ_AIM[k];
   /* direct */
   {const dx=ax-t.x,dy=ay-t.y,dl=Math.hypot(dx,dy),ux=dx/dl,uy=dy/dl;
    if(!((k===1||k===4)&&Math.abs(uy)<.5)){
     const gx=t.x-ux*2*R,gy=t.y-uy*2*R,cx=gx-cue.x,cy=gy-cue.y,cl=Math.hypot(cx,cy);
     if(cl>=1){const cos=(cx*ux+cy*uy)/cl;
      if(cos>=.17&&pzClear(B,cue.x,cue.y,gx,gy,[0,id])&&pzClear(B,t.x,t.y,ax,ay,[0,id])){
       const tol=(PZ_SLACK[k]/dl)*2*R*cos/cl,p=pzErf(tol/(sigma*Math.SQRT2));out.push({id,k,ang:Math.atan2(cy,cx),p,cut:Math.acos(Math.min(1,cos)),d1:cl,d2:dl,bank:false})}}}}
   /* one-rail banks: mirror the pocket across a rail (the ball centre bounces R from the nose line) */
   if(wantBank){for(let r=0;r<4;r++){let mx,my,line;
     if(r===0){line=R;mx=ax;my=2*R-ay}else if(r===1){line=PH-R;mx=ax;my=2*(PH-R)-ay}else if(r===2){line=R;mx=2*R-ax;my=ay}else{line=PW-R;mx=2*(PW-R)-ax;my=ay}
     const dx=mx-t.x,dy=my-t.y;let s;if(r<2)s=(line-t.y)/dy;else s=(line-t.x)/dx;if(!(s>.03&&s<.97))continue;
     const bx=t.x+dx*s,by=t.y+dy*s;if(bx<R+14||bx>PW-R-14||by<R+14||by>PH-R-14)continue;
     const dl1=Math.hypot(bx-t.x,by-t.y),ux=(bx-t.x)/dl1,uy=(by-t.y)/dl1,gx=t.x-ux*2*R,gy=t.y-uy*2*R,cx=gx-cue.x,cy=gy-cue.y,cl=Math.hypot(cx,cy);if(cl<1)continue;
     const cos=(cx*ux+cy*uy)/cl;if(cos<.3)continue;
     if(!pzClear(B,cue.x,cue.y,gx,gy,[0,id])||!pzClear(B,t.x,t.y,bx,by,[0,id])||!pzClear(B,bx,by,ax,ay,[0,id]))continue;
     const dl2=Math.hypot(ax-bx,ay-by),dT=dl1+dl2,tol=.5*(PZ_SLACK[k]/dT)*2*R*cos/cl,p=pzErf(tol/(sigma*Math.SQRT2));
     out.push({id,k,ang:Math.atan2(cy,cx),p,cut:Math.acos(Math.min(1,cos)),d1:cl,d2:dT,bank:true})}}}}
 return out.sort((a,b)=>b.p-a.p)}
/* kick candidates: aim at the mirror image of a legal ball across each rail (cue ball bounces, then meets the ball) */
function pzaKicks(B,cue,targets){const R=PZ_PHY.R,PW=PZ_PHY.W,PH=PZ_PHY.H,out=[];
 for(const id of targets){const t=B.find(b=>b.id===id&&b.on);if(!t)continue;
  for(let r=0;r<4;r++){let mx,my,line;if(r===0){line=R;mx=t.x;my=2*R-t.y}else if(r===1){line=PH-R;mx=t.x;my=2*(PH-R)-t.y}else if(r===2){line=R;mx=2*R-t.x;my=t.y}else{line=PW-R;mx=2*(PW-R)-t.x;my=t.y}
   const dx=mx-cue.x,dy=my-cue.y;let s;if(r<2)s=(line-cue.y)/dy;else s=(line-cue.x)/dx;if(!(s>.03&&s<.97))continue;
   const bx=cue.x+dx*s,by=cue.y+dy*s;if(bx<R+10||bx>PW-R-10||by<R+10||by>PH-R-10)continue;
   if(!pzClear(B,cue.x,cue.y,bx,by,[0])||!pzClear(B,bx,by,t.x,t.y,[0,id]))continue;
   out.push({id,ang:Math.atan2(dy,dx),d:Math.hypot(bx-cue.x,by-cue.y)+Math.hypot(t.x-bx,t.y-by)})}}
 return out.sort((a,b)=>a.d-b.d)}
/* power for a candidate: enough to send the object ball home and leave the cue ball moving a little */
function pzaPow(c,m){return Math.min(.95,.12+(c.d1+c.d2*1.6/Math.max(.25,Math.cos(c.cut)))/2600*m)}
const pzaGauss=rng=>{let u=0;for(let i=0;i<6;i++)u+=rng();return (u-3)/Math.sqrt(.5)};
/* the decision as a generator. yields after every simulation; returns {ang,pow,a,b,id,k,p,...} */
function* pzaThink(st,me,rng,opt){rng=rng||Math.random;opt=opt||{};const B=st.B,cue=B[0],sig=me.sig*Math.PI/180*(opt.sigK||1),tg=pzrTargets(st),on8=pzrOn8(st);
 const cs=pzaCands(B,cue,tg,sig,true);let best=null,sims=0;const maxSims=me.maxSims||30;
 /* the 8 must be called: remember which pocket the candidate aims at */
 const bk=me.bank||1;
 const ranked=cs.map(c=>Object.assign(c,{rk:c.p*(c.bank?bk:1)})).sort((a,b)=>b.rk-a.rk);
 for(const c of ranked.slice(0,me.look||5)){if(sims>=maxSims)break;
  for(const b of [-.7,0,.7])for(const m of [1,1.5]){if(sims>=maxSims)break;
   for(const a of (me.spin?[0,-.5,.5]:[0])){if(sims>=maxSims)break;
    const C=pzClone(B);const pw=pzaPow(c,m);pzpStrike(C[0],c.ang,pw,a,b);const r=yield* pzpRunG(C,10);sims++;yield sims;
    const pk=r.ev.filter(e=>e.t==='pk').map(e=>e.a);if(pk.includes(0)||!pk.includes(c.id))continue;if(c.id!==8&&pk.includes(8))continue;
    if(c.id===8&&st.house.bank8&&!r.ev.some(e=>e.t==='cu'&&e.a===8))continue;
    if(c.id===8&&opt.call!=null){const e8=r.ev.find(e=>e.t==='pk'&&e.a===8);if(e8&&e8.p!==c.k)continue}
    let pos=0;if(me.pos){const nst=Object.assign({},st,{B:C});const nt=pzrTargets(nst);const nc=pzaCands(C,C[0],nt,sig,false);pos=nc.length?nc[0].p:0}
    const sc=c.rk+me.pos*pos;if(!best||sc>best.sc)best={sc,ang:c.ang,pow:pw,b,a,id:c.id,k:c.k,p:c.rk,bank:c.bank}}}}
 if(best&&best.p>=me.safe)return best;
 /* safety: soft legal shots that leave the opponent little */
 if(me.safe>0&&me.sTry){let sb=null;const og=st.grp[1-st.turn];
  for(let i=0;i<me.sTry;i++){const tid=tg[(rng()*tg.length)|0],t=B.find(b=>b.id===tid&&b.on);if(!t)continue;
   const base=Math.atan2(t.y-cue.y,t.x-cue.x),ang=base+(rng()-.5)*.5,pw=.12+rng()*.2,C=pzClone(B);pzpStrike(C[0],ang,pw,0,-.3+rng()*.2);const r=yield* pzpRunG(C,8);yield ++sims;
   let first=null,rail=false;for(const e of r.ev){if(e.t==='bb'&&first===null&&(e.a===0||e.b===0))first=e.a===0?e.b:e.a;if(e.t==='cu'&&first!==null)rail=true}
   const pk=r.ev.filter(e=>e.t==='pk').map(e=>e.a);if(first===null||!tg.includes(first)||!rail||pk.includes(0)||pk.includes(8))continue;
   const opT=[];for(const b of C)if(b.on&&b.id&&b.id!==8&&(st.open||!og?true:pzGrp(b.id)===og))opT.push(b.id);
   const ocs=pzaCands(C,C[0],opT.length?opT:[8],1.2*Math.PI/180,false),op=ocs.length?ocs[0].p:0;
   if(!sb||op<sb.op)sb={op,ang,pow:pw,b:-.3,a:0,safety:true}}
  if(sb&&(!best||sb.op<.5))return sb}
 if(best)return best;
 /* nothing pots: kick off a rail, or hit the nearest legal ball firmly */
 {const ks=pzaKicks(B,cue,tg);for(const k of ks.slice(0,3)){const C=pzClone(B);pzpStrike(C[0],k.ang,.5,0,0);const r=yield* pzpRunG(C,8);yield ++sims;
   let first=null;for(const e of r.ev)if(e.t==='bb'&&(e.a===0||e.b===0)){first=e.a===0?e.b:e.a;break}
   const pk=r.ev.filter(e=>e.t==='pk').map(e=>e.a);if(first!==null&&tg.includes(first)&&!pk.includes(0)&&!pk.includes(8))return {ang:k.ang,pow:.5,b:0,a:0,kick:true}}}
 let nb=null;for(const id of tg){const t=B.find(b=>b.id===id&&b.on);if(!t)continue;const d=Math.hypot(t.x-cue.x,t.y-cue.y);if(!nb||d<nb.d)nb={d,ang:Math.atan2(t.y-cue.y,t.x-cue.x)}}
 return {ang:nb?nb.ang:0,pow:.45,b:0,a:0,kick:true,hail:true}}
/* run a generator to the end (tests, calibration) */
function pzaDecide(st,me,rng,opt){const g=pzaThink(st,me,rng,opt);for(;;){const r=g.next();if(r.done)return r.value}}
/* ball in hand: try a grid of spots and place the cue ball where its best next shot is easiest */
function pzaPlace(st,me){const B=st.B,cue=B[0],sig=me.sig*Math.PI/180,tg=pzrTargets(st);let best=null;
 for(let x=40;x<=(st.kitchen?220:840);x+=40)for(let y=40;y<=400;y+=40){if(B.some(b=>b.on&&b.id&&Math.hypot(b.x-x,b.y-y)<2*PZ_PHY.R+2))continue;cue.x=x;cue.y=y;
  const cs=pzaCands(B,cue,tg,sig,false);const p=cs.length?cs[0].p:0;if(!best||p>best.p)best={x,y,p}}
 cue.on=true;cue.x=best?best.x:220;cue.y=best?best.y:220;cue.vx=cue.vy=cue.ux=cue.uy=cue.es=0}
/* the break: cue ball in the kitchen, aimed at the head ball */
function pzaBreak(st,me,rng){rng=rng||Math.random;const B=st.B,cue=B[0];cue.on=true;cue.x=PZ_PHY.W*.22;cue.y=PZ_PHY.H/2+(rng()-.5)*70;cue.vx=cue.vy=cue.ux=cue.uy=cue.es=0;
 const ap=B.filter(b=>b.id&&b.on).sort((a,b)=>Math.abs(a.y-PZ_PHY.H/2)-Math.abs(b.y-PZ_PHY.H/2)||a.x-b.x)[0];
 return {ang:Math.atan2(ap.y-cue.y,ap.x-cue.x),pow:me.brk&&me.brk<=.9?1:.93+rng()*.07,a:0,b:0,brk:true}}
/* the monster's execution noise; rattled (after a taunt) makes it worse. Returns the shot to strike with. */
function pzaNoise(s,me,rng,k){rng=rng||Math.random;k=k||1;const sg=(s.brk?(me.brk||me.sig):me.sig)*k,pk=me.psig*(k>1?1.5:1);
 const sty=s.safety?1:(me.over||me.soft||1);
 return {ang:s.ang+pzaGauss(rng)*sg*Math.PI/180,pow:Math.max(.05,Math.min(1,s.pow*sty*(1+pzaGauss(rng)*pk))),b:Math.max(-1,Math.min(1,(s.b||0)+pzaGauss(rng)*.12)),a:Math.max(-1,Math.min(1,(s.a||0)+pzaGauss(rng)*.12))}}
