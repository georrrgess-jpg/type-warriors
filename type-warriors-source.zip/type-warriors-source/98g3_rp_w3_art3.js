/* ===== RUNESTONE TOWER DEFENSE 10.1: World 3 art, part 3 (98g3) - life and interaction =====
   Skyforge Heights (98g, 98g2) made more alive, smoother and interactive. Globals keep the rpw3a / RPW3A prefix.
   - Bake extras (each RPW.bake[id] is wrapped): Cloudspire Meadows gets waterfalls off the island rims, hot-air balloons, perched
     flocks and butterflies; Gearworks Foundry a trip hammer, a piston engine and an overhead crane; Storm Citadel live banners, a
     rim-light layer the lightning lights up and crows round the spires. Every map gets hotspots (B.hot) for the props.
   - The live layers (RPW.amb / twist / ambTop) are rewritten here around baked sprite strips (birds, butterflies, ripples, splashes,
     waterfall frames, flags), so a frame blits small images instead of stroking many paths. Time-based and eased; R.lite and R.rm
     draw less. 98a draws RPW.amb once per frame inside the rpAmbient chain (at rpCastleLive).
   - Interaction: rpClick is wrapped. A click or tap that hits no pad, tower or monster, while nothing is being placed, aimed or
     selected, pokes the nearest prop (rpw3aPoke): birds scatter, a windmill spins up, an airship toots, the hammer slams, the lever
     wiggles, a rod sparks... The original rpClick always runs first and the reactions only draw (sparks go to the battle's own
     particle list R.fx): gameplay is never changed.
   - Battle reactions: steam bursts when monsters cross the foundry vents, wall gears speed up while towers fire near them, perched
     birds take off when a monster comes close, the stone and the puddles light up after a lightning strike.
   - rpw3aDR (98g) is replaced by a distance field on an 8 px grid (bilinear), which makes the bakes much faster. */

/* ---------- shared ---------- */
/* road distance: a field on an 8 px grid filled from the road samples once per geometry, then read bilinearly (exact outside) */
function rpw3aDR(G,cap){if(G._w3d)return G._w3d;cap=cap||200;const s=8,ox=-16,oy=-16,nx=Math.ceil(1640/s)+2,ny=Math.ceil(940/s)+2,F=new Float32Array(nx*ny).fill(cap*cap),r=Math.ceil(cap/s);
 for(const q of G.U){const ci=Math.round((q.x-ox)/s),cj=Math.round((q.y-oy)/s);for(let j=Math.max(0,cj-r);j<=Math.min(ny-1,cj+r);j++){const y=oy+j*s,dy=(y-q.y)*(y-q.y);if(dy>cap*cap)continue;const row=j*nx;
  for(let i=Math.max(0,ci-r);i<=Math.min(nx-1,ci+r);i++){const x=ox+i*s,d=(x-q.x)*(x-q.x)+dy;if(d<F[row+i])F[row+i]=d}}}
 for(let k=0;k<F.length;k++)F[k]=Math.sqrt(F[k]);
 const ex=(x,y)=>{let m=cap*cap;for(const q of G.U){const d=(q.x-x)*(q.x-x)+(q.y-y)*(q.y-y);if(d<m)m=d}return Math.sqrt(m)};
 return G._w3d=(x,y)=>{const u=(x-ox)/s,v=(y-oy)/s;if(!(u>=0&&v>=0&&u<nx-1&&v<ny-1))return ex(x,y);const i=u|0,j=v|0,fu=u-i,fv=v-j,k=j*nx+i;
  return(F[k]*(1-fu)+F[k+1]*fu)*(1-fv)+(F[k+nx]*(1-fu)+F[k+nx+1]*fu)*fv}}
/* a strip of n frames (w x h, anchor ax, ay) painted at 2x by draw(g, i); fl mirrors it */
function rpw3aStrip(k,w,h,n,ax,ay,draw,fl){const key='strip'+k+(fl?'L':'');if(RPW3A.spr[key])return RPW3A.spr[key];const c=rpw3aCv(w*n*2,h*2),g=c.getContext('2d');g.lineJoin='round';g.lineCap='round';
 for(let i=0;i<n;i++){g.save();g.beginPath();g.rect(i*w*2,0,w*2,h*2);g.clip();g.translate(i*w*2,0);g.scale(2,2);g.translate(ax,ay);if(fl)g.scale(-1,1);draw(g,i);g.restore()}
 const o=rpw3aCv(w*n,h),o2=o.getContext('2d');o2.imageSmoothingQuality='high';o2.drawImage(c,0,0,w*n,h);return RPW3A.spr[key]={c:o,w,h,n,ax,ay}}
/* blits land on whole pixels and at their own size where they can: a fractional or scaled drawImage costs many times more */
function rpw3aFr(g,S,i,x,y,s){i=(((i|0)%S.n)+S.n)%S.n;if(!s||s===1)g.drawImage(S.c,i*S.w,0,S.w,S.h,Math.round(x-S.ax),Math.round(y-S.ay),S.w,S.h);else g.drawImage(S.c,i*S.w,0,S.w,S.h,x-S.ax*s,y-S.ay*s,S.w*s,S.h*s)}
const rpw3aBl=(g,c,x,y)=>g.drawImage(c,Math.round(x),Math.round(y));
function rpw3aSpinPut(g,P,x,y,a,s){const u=((a%P.period)+P.period)%P.period,f=P.F[Math.floor(u/P.period*P.n)%P.n];if(!s||s===1)g.drawImage(f,Math.round(x-P.w/2),Math.round(y-P.h/2));else g.drawImage(f,x-P.w*s/2,y-P.h*s/2,P.w*s,P.h*s)}
/* a radial glow squashed to an ellipse (rx, rx*sq), made once */
function rpw3aGlowE(rgb,r,sq){const k='ge'+rgb+r+'_'+sq;if(RPW3A.spr[k])return RPW3A.spr[k];const c=rpw3aCv(r*2,Math.round(r*2*sq));c.getContext('2d').drawImage(rpwGlow(rgb,r),0,0,c.width,c.height);return RPW3A.spr[k]=c}
/* windmill blades at a given size, as spin frames */
function rpw3aBladeSpin(s){s=Math.round(s*20)/20;const k='bl'+s;if(RPW3A.spr['spin'+k])return RPW3A.spr['spin'+k];const B0=rpw3aBlades(),w=Math.ceil(B0.w*s),S={c:rpw3aCv(w,w),w,h:w,ax:w/2,ay:w/2};
 S.c.getContext('2d').drawImage(B0.c,0,0,w,w);return rpw3aSpin(k,S,TAU/4,20)}
/* per-battle state; a hotspot poked at R.t (its age in seconds, 99 when never poked in this battle) */
function rpw3aS(R){return R._w3||(R._w3={lt:R.t,dt:0,ev:[],seen:new Set()})}
function rpw3aTick(R){const S=rpw3aS(R);S.dt=Math.max(0,Math.min(.1,R.t-S.lt));S.lt=R.t;return S}
const rpw3aAge=(R,h)=>h&&h.R===R?R.t-h.at:99;
const rpw3aEo=u=>u<=0?0:u>=1?1:1-Math.pow(1-u,3);
/* a decaying wobble (0 at rest): amplitude a, frequency f, decay d */
const rpw3aWob=(age,a,f,d)=>age>=0&&age<6?a*Math.sin(age*f)*Math.exp(-age*(d||3)):0;
function rpw3aSnd(k){try{const b=(f,d,ty,v,w)=>w?setTimeout(()=>beep(f,d,ty,v),w):beep(f,d,ty,v);switch(k){
 case 'toot':b(196,.22,'triangle',.5);b(247,.32,'triangle',.45,190);break;
 case 'creak':b(150,.09,'sawtooth',.12);b(190,.12,'sawtooth',.1,100);break;
 case 'chirp':for(let i=0;i<4;i++)b(2300+Math.random()*900,.04,'sine',.2,i*60);break;
 case 'flap':for(let i=0;i<5;i++)b(160+Math.random()*60,.03,'triangle',.25,i*40);break;
 case 'baa':b(430,.18,'sawtooth',.1);b(380,.24,'sawtooth',.09,150);break;
 case 'buzz':b(210,.3,'sawtooth',.06);b(230,.3,'sawtooth',.05,120);break;
 case 'puff':b(95,.14,'triangle',.35);break;
 case 'clang':b(880,.07,'square',.1);b(1320,.16,'triangle',.2,25);break;
 case 'whistle':b(1250,.35,'sine',.22);b(1520,.3,'sine',.18,140);break;
 case 'zap':b(1900,.05,'sawtooth',.1);b(2700,.05,'square',.06,50);b(1500,.06,'sawtooth',.07,110);break;
 case 'chime':b(1568,.28,'sine',.22);b(2093,.4,'sine',.16,100);break;
 case 'thunk':b(110,.09,'triangle',.45);break;
 case 'splash':b(520,.05,'sine',.2);b(380,.08,'sine',.18,50);break;
 case 'lever':b(320,.05,'square',.1);b(250,.06,'square',.09,70);b(300,.04,'square',.07,140);break;
 case 'burn':b(70,.4,'sawtooth',.18);break;
 case 'bell':b(988,.5,'sine',.25);b(1480,.6,'sine',.12,10);break}}catch(e){}}
const rpw3aPt=(R,x,y,n,c,o)=>{if(!R.fx)return;if(R.lite||R.rm)n=Math.ceil(n/2);try{ptBurst(R.fx,x,y,n,c,o)}catch(e){}};
/* a monster near (x, y)? (its body, flyers higher up) */
function rpw3aFoeAt(R,x,y){for(const e of R.foes||[]){if(e.dead||e.hide)continue;const q=rpPos(R,e),top=e.air?120:70;if(Math.abs(q.x-x)<34&&y>q.y-top&&y<q.y+16)return e}return null}
/* the nearest hotspot under (x, y) on the map; RPW3A.react[id] makes it react */
function rpw3aPoke(R,x,y){const B=R.bake;if(!B||!B.hot)return null;let best=null,bd=1;for(const h of B.hot){if(h.off)continue;const d=((x-h.x)/h.r)**2+((y-h.y)/(h.ry||h.r))**2;if(d<bd){bd=d;best=h}}
 if(best){best.R=R;best.at=R.t;best.n=(best.n||0)+1}const f=RPW3A.react[B.id];if(f)f(R,best,x,y);rpw3aS(R).poke=[x,y,R.t,best&&best.k];return best}
RPW3A.react={};
/* the click hook: the original always runs; a poke only when the click hit nothing the battle uses and nothing was open */
function rpw3aFree(R,x,y,btn,touch){return!!(R&&R.map&&RPW3A.ids[R.map.id]&&R.bake&&R.bake.hot&&btn!==2&&!R.pause&&!R.over&&R.wst!=='done'&&!R.place&&!R.aim&&!R.sel&&!R.selPad
 &&!rpPick(R,x,y)&&!(touch&&rpSnap(R,x,y))&&!rpw3aFoeAt(R,x,y))}
{const c0=rpClick;rpClick=function(x,y,btn,touch){const R=RPX;let p=false;try{p=rpw3aFree(R,x,y,btn,touch)}catch(e){}const r=c0.apply(this,arguments);if(p)try{rpw3aPoke(R,x,y)}catch(e){console.error(e)}return r}}
/* hovering a prop shows the pointer cursor (only when the battle itself shows none) */
if(typeof cv!=='undefined'&&cv&&!window.__rpw3aHov){window.__rpw3aHov=1;cv.addEventListener('pointermove',()=>{const R=RPX;if(!R||!R.map||!RPW3A.ids[R.map.id]||!R.bake||!R.bake.hot||cv.style.cursor)return;
 const x=R.mx,y=R.my;if(R.place||R.aim||R.hover)return;for(const h of R.bake.hot)if(!h.off&&((x-h.x)/h.r)**2+((y-h.y)/(h.ry||h.r))**2<1){cv.style.cursor='pointer';return}})}
/* draw the parts of B.isl over rects [x, y, w, h] (things that pass behind the islands) */
function rpw3aPatch(c,B,L){for(const r of L){const sx=Math.max(0,Math.floor(r[0])),sy=Math.max(0,Math.floor(r[1])),sw=Math.min(1600,Math.ceil(r[0]+r[2]))-sx,sh=Math.min(900,Math.ceil(r[1]+r[3]))-sy;if(sw>0&&sh>0)c.drawImage(B.isl,sx,sy,sw,sh,sx,sy,sw,sh)}}
/* a free spot on the ground: on land, off the road by [d0, d1], clear of pads, props, the castle and the entrances */
function rpw3aSpot(B,seed,d0,d1,land,taken,gap){const G=B.G,dR=rpw3aDR(G),c=B.cast;for(let i=0;i<400;i++){const x=60+rpw3aR(seed+i*2)*1240,y=150+rpw3aR(seed+i*2+1)*680,d=dR(x,y);if(d<d0||d>d1)continue;
  if(land&&!land(x,y))continue;if(G.pads.some(p=>Math.abs(p.x-x)<84&&y>p.y-110&&y<p.y+50))continue;if((B.occ||[]).some(q=>Math.abs(q.x-x)<q.w+18&&y>q.y-q.h-14&&y<q.y+16))continue;
  if(x>c.x-30&&y>c.y+120)continue;if(G.ent.some(e=>Math.abs(x-e.x)<150&&Math.abs(y-e.y)<120))continue;if(taken&&taken.some(q=>Math.hypot(q[0]-x,q[1]-y)<(gap||160)))continue;return[x,y]}return null}

/* a puff that grows and fades over n frames (smoke, steam), anchor at the centre of the first puff */
function rpw3aSmk(k,w,h,cols,n,grow){n=n||8;grow=grow||1.3;const P=rpw3aPuff(200+k,w,h,cols),W=Math.ceil(w*(.5+grow)),H=Math.ceil(h*(.5+grow));
 return rpw3aStrip('smk'+k,W,H,n,W/2,H/2,(g,i)=>{const u=i/(n-1),s=.5+u*grow;g.globalAlpha=Math.min(1,(1-u)*1.15);g.drawImage(P.c,-w*s/2,-h*s/2,w*s,h*s)})}
/* live castle bits, cheaper than 98g's first version: glows at their own size on whole pixels, smoke as frames */
function rpw3aCastleLive(g,id,x,y,t,lite){const A=rpw3aCastle(id),P=A.P;g.save();g.translate(Math.round(x),Math.round(y));
 for(let i=0;i<A.flags.length;i++){const f=A.flags[i],L=f.len,n=5;g.beginPath();g.moveTo(f.x,f.y);
  for(let k=1;k<=n;k++){const u=k/n;g.lineTo(f.x+L*u,f.y+Math.sin(t*5+i*1.7-u*3)*3*u+u*2)}for(let k=n;k>=0;k--){const u=k/n;g.lineTo(f.x+L*u,f.y+9*(1-u*.85)+Math.sin(t*5+i*1.7-u*3)*3*u+u*2)}
  g.closePath();g.fillStyle=f.col;g.fill();g.strokeStyle=RPO;g.lineWidth=1.6;g.stroke();g.fillStyle=f.c2;g.fillRect(f.x,f.y+3,L*.35,1.8)}
 if(A.gear){const G=rpw3aGear('fk',28,14,['#c89a3a','#ffe08a','#6a4a14']);rpw3aSpinPut(g,rpw3aSpin('fk',G,TAU/14,10),A.gear[0],A.gear[1],t*.6)}
 if(A.ship){const S=rpw3aShip('cs',.42,['#ffffff','#3a8ae0','#2a5aa8','#ffd45a']),b=Math.round(Math.sin(t*1.3)*2.5);g.drawImage(S.c,Math.round(A.ship[0]-S.ax),Math.round(A.ship[1]-S.ay)+b);g.strokeStyle='rgba(18,8,31,.6)';g.lineWidth=1;g.beginPath();g.moveTo(A.ship[0]-14,A.ship[1]+18+b);g.lineTo(A.ship[0]-10,A.ship[1]+40);g.stroke()}
 g.globalCompositeOperation='lighter';
 for(let i=lite?1:0;i<A.wins.length;i+=lite?5:3){const w=A.wins[i],r=w[2],gw=rpwGlow(P.winG,r);g.globalAlpha=.2+.12*Math.sin(t*3.1+i*2.3)+.06*Math.sin(t*11+i);rpw3aBl(g,gw,w[0]-r,w[1]-r)}
 const tg=rpwGlow('255,170,70',22);for(let i=0;i<A.torch.length;i++){const p=A.torch[i],f=.85+.15*Math.sin(t*13+i*3)+.08*Math.sin(t*29+i);g.globalAlpha=.45+.15*f;rpw3aBl(g,tg,p[0]-22,p[1]-26);
  g.globalAlpha=1;g.fillStyle='#ff8a2a';g.beginPath();g.ellipse(p[0],p[1]-5*f,3.6,7*f,0,0,TAU);g.fill();g.fillStyle='#ffe27a';g.beginPath();g.ellipse(p[0],p[1]-3.5*f,1.8,3.8*f,0,0,TAU);g.fill()}
 if(!lite)for(let i=0;i<A.glow.length;i++){const q=A.glow[i],r=Math.round(Math.min(q[2],44));g.globalAlpha=.3+.18*Math.sin(t*2.2+i);rpw3aBl(g,rpwGlow(P.winG,r),q[0]-r,q[1]-r)}
 if(A.orb){const k=.55+.3*Math.sin(t*7)+.15*Math.sin(t*23);g.globalAlpha=k;rpw3aBl(g,rpwGlow('140,220,255',34),A.orb[0]-34,A.orb[1]-34);
  if(!lite){g.strokeStyle='#e8f8ff';g.lineWidth=1.4;g.globalAlpha=.8;g.beginPath();for(let j=0;j<3;j++){const a=t*4+j*2.1+Math.sin(t*17+j)*.6;let px=A.orb[0],py=A.orb[1];g.moveTo(px,py);for(let s=1;s<4;s++){px=A.orb[0]+Math.cos(a)*s*6+Math.sin(t*41+s*j)*3;py=A.orb[1]+Math.sin(a)*s*6+Math.cos(t*37+s)*3;g.lineTo(px,py)}}g.stroke()}}
 if(!lite&&A.spark.length){g.fillStyle='#ffffff';g.globalAlpha=.9;g.beginPath();for(let i=0;i<A.spark.length;i++){const p=A.spark[i],u=(t*.5+i*.37)%1,a=Math.max(0,Math.sin(u*Math.PI));if(a<.2)continue;const s=a*4;
  g.moveTo(p[0],p[1]-s*1.6);g.lineTo(p[0]+s*.35,p[1]-s*.35);g.lineTo(p[0]+s*1.6,p[1]);g.lineTo(p[0]+s*.35,p[1]+s*.35);g.lineTo(p[0],p[1]+s*1.6);g.lineTo(p[0]-s*.35,p[1]+s*.35);g.lineTo(p[0]-s*1.6,p[1]);g.lineTo(p[0]-s*.35,p[1]-s*.35);g.closePath()}g.fill()}
 g.globalCompositeOperation='source-over';g.globalAlpha=1;
 if(A.smoke.length&&!lite){const S=rpw3aSmk(1,40,32,['rgba(70,60,66,.55)','rgba(70,60,66,.3)','rgba(70,60,66,0)'],10);for(let i=0;i<A.smoke.length;i++){const p=A.smoke[i];for(let k=0;k<2;k++){const u=(t*.32+k/2+i*.21)%1;rpw3aFr(g,S,u*10,p[0]+u*26,p[1]-u*70)}}}
 g.restore()}

/* ---------- sprites ---------- */
/* a small bird: frames 0-1 perched (1 pecks), 2-7 flying (wing beat) */
function rpw3aBird(k,C,fl){return rpw3aStrip('bird'+k,30,26,8,15,16,(g,i)=>{const ol=()=>rpw3aO(g,1.3);
 if(i<2){const pk=i===1;g.fillStyle=C[0];g.beginPath();g.moveTo(-4,-3);g.lineTo(-11,-1);g.lineTo(-9,2);g.closePath();g.fill();ol();
  g.strokeStyle=RPO;g.lineWidth=1.1;g.beginPath();g.moveTo(-1,0);g.lineTo(-1.5,5);g.moveTo(2,0);g.lineTo(2.4,5);g.stroke();
  g.beginPath();g.ellipse(0,-3,6.4,4.8,pk?.25:0,0,TAU);g.fillStyle=C[0];g.fill();ol();g.fillStyle=C[1];g.beginPath();g.ellipse(1.6,-1.4,3.8,2.8,pk?.25:0,0,TAU);g.fill();
  g.fillStyle=C[2];g.beginPath();g.ellipse(-2,-4,3.4,2.2,-.3,0,TAU);g.fill();
  const hx=pk?6.5:4.6,hy=pk?.5:-7.6;g.beginPath();g.arc(hx,hy,3.5,0,TAU);g.fillStyle=C[0];g.fill();ol();g.fillStyle=RPO;g.beginPath();g.arc(hx+1.3,hy-.7,1,0,TAU);g.fill();
  g.fillStyle='#ffb02a';g.beginPath();g.moveTo(hx+3,hy-1);g.lineTo(hx+6.2,hy+.4);g.lineTo(hx+3,hy+1.2);g.closePath();g.fill();g.lineWidth=.8;g.stroke()}
 else{const u=(i-2)/6,w=Math.cos(u*TAU);g.beginPath();g.moveTo(-5,-1);g.lineTo(-11,-3+w);g.lineTo(-10,1);g.closePath();g.fillStyle=C[0];g.fill();ol();
  g.beginPath();g.ellipse(0,0,6.4,3.8,-.1,0,TAU);g.fill();ol();g.fillStyle=C[1];g.beginPath();g.ellipse(1,1.2,4,2,0,0,TAU);g.fill();
  g.beginPath();g.arc(5.6,-2.4,3.2,0,TAU);g.fillStyle=C[0];g.fill();ol();g.fillStyle=RPO;g.beginPath();g.arc(6.6,-3,.9,0,TAU);g.fill();g.fillStyle='#ffb02a';g.beginPath();g.moveTo(8.4,-3);g.lineTo(11,-2);g.lineTo(8.4,-1.2);g.closePath();g.fill();
  for(const [dx,s] of[[-1.5,1],[1.5,.8]]){g.beginPath();g.moveTo(dx-3,-1);g.quadraticCurveTo(dx-2,-1-10*w*s,dx+1+w*2,-2-11*w*s);g.quadraticCurveTo(dx+2,-2-5*w*s,dx+3,-1);g.closePath();g.fillStyle=s<1?C[2]:C[0];g.fill();ol()}}},fl)}
/* a butterfly: 6 frames of a wing beat */
function rpw3aBfly(k,C){return rpw3aStrip('bf'+k,18,16,6,9,8,(g,i)=>{const w=.25+.75*Math.abs(Math.cos(i/6*Math.PI));
 for(const s of[-1,1]){g.save();g.scale(s*w,1);g.beginPath();g.ellipse(4,-2.5,4.4,3.6,-.4,0,TAU);g.fillStyle=C[0];g.fill();g.strokeStyle=RPO;g.lineWidth=1.1/Math.max(.3,w);g.stroke();
  g.beginPath();g.ellipse(3.2,2.6,2.8,2.4,.4,0,TAU);g.fillStyle=C[1];g.fill();g.stroke();g.fillStyle='rgba(255,255,255,.7)';g.beginPath();g.arc(4.6,-3,1.2,0,TAU);g.fill();g.restore()}
 g.fillStyle=RPO;g.beginPath();g.ellipse(0,0,1.2,4,0,0,TAU);g.fill();g.strokeStyle=RPO;g.lineWidth=.8;g.beginPath();g.moveTo(0,-3.5);g.lineTo(-1.6,-6.5);g.moveTo(0,-3.5);g.lineTo(1.6,-6.5);g.stroke()})}
/* a far bird (a dark V) - 6 frames */
function rpw3aVee(k,col){return rpw3aStrip('vee'+k,20,12,6,10,6,(g,i)=>{const f=Math.cos(i/6*TAU)*4;g.strokeStyle=col;g.lineWidth=1.8;g.beginPath();g.moveTo(-7,-f);g.quadraticCurveTo(-3,-2,0,0);g.quadraticCurveTo(3,-2,7,-f);g.stroke()})}
/* a petal / leaf tumbling - 8 frames */
function rpw3aPetal(k,col){return rpw3aStrip('pt'+k,10,10,8,5,5,(g,i)=>{g.rotate(i/8*Math.PI);g.scale(1,.35+.65*Math.abs(Math.cos(i/8*Math.PI)));g.fillStyle=col;g.beginPath();g.ellipse(0,0,4,2,0,0,TAU);g.fill();g.strokeStyle='rgba(18,8,31,.5)';g.lineWidth=.8;g.stroke()})}
/* a hot-air balloon (anchor at the basket) */
function rpw3aBalloon(k,C){return rpw3aSpr('bal'+k,64,96,32,90,g=>{g.strokeStyle=RPO;g.lineWidth=1.2;g.beginPath();g.moveTo(-12,-34);g.lineTo(-6,-12);g.moveTo(12,-34);g.lineTo(6,-12);g.moveTo(0,-30);g.lineTo(0,-12);g.stroke();
 const env=()=>{g.beginPath();g.moveTo(-10,-30);g.bezierCurveTo(-34,-46,-30,-86,0,-86);g.bezierCurveTo(30,-86,34,-46,10,-30);g.closePath()};env();g.fillStyle=C[0];g.fill();g.save();env();g.clip();
 g.fillStyle=C[1];for(const x of[-18,-6,6,18]){g.beginPath();g.ellipse(x,-58,4.5,32,0,0,TAU);g.fill()}g.fillStyle=C[2];g.fillRect(-32,-46,64,5);g.fillStyle='rgba(18,8,31,.22)';g.beginPath();g.ellipse(10,-50,22,34,0,0,TAU);g.fill();
 g.fillStyle='rgba(255,255,255,.45)';g.beginPath();g.ellipse(-12,-72,6,10,-.4,0,TAU);g.fill();g.restore();env();rpw3aO(g,2.2);
 g.fillStyle='#a8743e';g.beginPath();g.moveTo(-8,-13);g.lineTo(8,-13);g.lineTo(6,-2);g.lineTo(-6,-2);g.closePath();g.fill();rpw3aO(g,1.6);g.strokeStyle='#6a4426';g.lineWidth=1;g.beginPath();g.moveTo(-7,-8);g.lineTo(7,-8);g.stroke()})}
/* a soft white flame (balloon burner) and a steam puff use rpw3aPuff; a little flag cloth is drawn live */

/* ======================================================================================================================
   Cloudspire Meadows
   ====================================================================================================================== */
/* waterfalls: a spring on the rim, the water down the cliff face and into the clouds (the body is baked, the streaks are 12 frames) */
function rpw3aFallSpr(f,isl){const w=30,P=48,n=12,L=f.L+50;return rpw3aStrip('fall'+f.x+'_'+f.y,w,L,n,w/2,0,(g,i)=>{const off=i/n*P;g.lineCap='round';
 for(let k=-1;k<L/P+1;k++)for(let j=0;j<6;j++){const x=-9+j*3.6+(rpw3aR(j*7+k)-.5)*1.4,y=off+k*P+rpw3aR(j*3+k*5)*P,l=10+rpw3aR(j+k*9)*16;const a=Math.max(0,1-Math.max(0,y-L*.55)/(L*.45));if(a<=0)continue;
  g.globalAlpha=a*.85;g.strokeStyle=j%2?'#ffffff':'#d8f4ff';g.lineWidth=j%2?1.6:2.4;g.beginPath();g.moveTo(x,y);g.lineTo(x,y+l);g.stroke()}g.globalAlpha=1;
 /* hidden behind the islands lower down (nearer the viewer) */if(isl){g.globalCompositeOperation='destination-out';g.beginPath();g.rect(-w/2,44,w,L);g.clip();g.drawImage(isl,f.x-w/2,f.y,w,L,-w/2,0,w,L);g.globalCompositeOperation='source-over'}})}
function rpw3aMeadowX(B,map){const M=B.M,G=B.G,dR=rpw3aDR(G),land=(x,y,m)=>M.at(x,y)>(m||0),c=B.cast;
 /* waterfalls: springs out of the cliff faces of south rims with open sky below (none under the castle or the dock) */
 const cand=[];for(let x=150;x<1250;x+=6)for(let y=180;y<640;y+=4){if(!(M.at(x,y)>0&&M.at(x,y+4)<=0))continue;
  let L=0;for(let yy=y+40;yy<y+300;yy+=8){let open=true;for(const dx of[-14,0,14])if(M.at(x+dx,yy)>-6){open=false;break}if(!open)break;L=yy-y}if(L<100||!land(x-14,y-4,0)||!land(x+14,y-4,0))continue;
  if(x>c.x-40&&y>c.y+100||x<220&&y<330)continue;cand.push({x,y:y+18,L:Math.min(230,800-y),Lv:L,sc:Math.min(L,200)-Math.abs(y-400)*.25})}
 cand.sort((a,b)=>b.sc-a.sc);const falls=[];for(const f of cand){if(falls.length>=4)break;if(falls.some(q=>Math.abs(q.x-f.x)<220&&Math.abs(q.y-f.y)<240))continue;falls.push(f)}
 /* each fall is painted into its own canvas, cut where an island lower down stands in front, then laid on B.isl and B.c */
 for(const f of falls){const{x,y,L}=f,H=L+50,W=60,fc=rpw3aCv(W,H+30),g=fc.getContext('2d'),ox=x-W/2,oy=y-24;g.translate(-ox,-oy);g.lineJoin='round';g.lineCap='round';
  let q=g.createLinearGradient(0,y,0,y+H);q.addColorStop(0,'rgba(140,210,255,.95)');q.addColorStop(.35,'rgba(170,225,255,.85)');q.addColorStop(1,'rgba(220,240,255,0)');g.fillStyle=q;
  g.beginPath();g.moveTo(x-9,y);g.lineTo(x+9,y);g.lineTo(x+14,y+H);g.lineTo(x-14,y+H);g.closePath();g.fill();
  q=g.createLinearGradient(0,y,0,y+H*.7);q.addColorStop(0,'rgba(18,8,31,.9)');q.addColorStop(1,'rgba(18,8,31,0)');g.strokeStyle=q;g.lineWidth=2;g.beginPath();g.moveTo(x-9,y);g.lineTo(x-12.5,y+H*.7);g.moveTo(x+9,y);g.lineTo(x+12.5,y+H*.7);g.stroke();
  g.save();g.globalCompositeOperation='destination-out';g.beginPath();g.rect(ox,y+44,W,H);g.clip();g.drawImage(B.isl,ox,oy,W,H+30,ox,oy,W,H+30);g.restore();
  /* the spring: a dark cleft in the rock with mossy stones round it */
  g.fillStyle='#2a1e24';g.beginPath();g.ellipse(x,y-2,12,7,0,0,TAU);g.fill();rpw3aO(g,2);g.fillStyle='#4aa8e8';g.beginPath();g.ellipse(x,y,9,4,0,0,Math.PI);g.fill();
  for(const [dx,dy,r] of[[-13,-2,4.4],[13,-3,4],[-8,-8,3.4],[8,-9,3.6],[0,-10,3]]){g.fillStyle='#8a7a6a';g.beginPath();g.ellipse(x+dx,y+dy,r*1.3,r,0,0,TAU);g.fill();rpw3aO(g,1.4);g.fillStyle='#5cc24a';g.beginPath();g.ellipse(x+dx-.5,y+dy-r*.55,r*1.05,r*.45,0,0,TAU);g.fill()}
  g.strokeStyle='#3e9a34';g.lineWidth=1.6;g.beginPath();for(const dx of[-17,-11,12,18]){g.moveTo(x+dx,y+1);g.quadraticCurveTo(x+dx+1,y+8,x+dx-1,y+14)}g.stroke();
  /* mist only where the water is still in the open at its foot */
  f.mist=M.at(x,y+L)<-6&&M.at(x,y+L-30)<-6;rpw3aFallSpr(f,B.isl);
  for(const cv of[B.isl,B.c])cv.getContext('2d').drawImage(fc,ox,oy)}
 B.falls=falls;
 /* balloons drifting behind the islands, perched flocks near the road (they take off when monsters come close), butterflies */
 const ID=B.isl.getContext('2d').getImageData(0,0,1600,900).data,op=(x,y)=>{x=x|0;y=y|0;return x<0||y<0||x>=1600||y>=900||ID[(y*1600+x)*4+3]>8};
 const sky=(x,y)=>{let n=0;for(let yy=y-100;yy<=y+12;yy+=8)for(const dx of[-30,-15,0,15,30])if(!op(x+dx,yy))n++;return n};const BC=[];
 for(let i=0;i<900;i++){const x=150+rpw3aR(i+8800)*1180,y=170+rpw3aR(i+8900)*560;if(falls.some(f=>Math.abs(f.x-x)<70&&y>f.y-40))continue;BC.push({x,y,n:sky(x,y)+sky(x-36,y)+sky(x+36,y),k:0,ph:rpw3aR(i)*TAU})}
 BC.sort((a,b)=>b.n-a.n);B.balloons=[];for(const b of BC){if(B.balloons.length>=2)break;if(B.balloons.some(q=>Math.hypot(q.x-b.x,q.y-b.y)<400))continue;b.k=B.balloons.length;B.balloons.push(b)}
 const fl=[];B.flocks=[];for(let s=0;s<3;s++){const p=rpw3aSpot(B,9100+s*977,62,150,(x,y)=>land(x,y,10)&&land(x+30,y,4)&&land(x-30,y,4)&&land(x,y+12,4),fl,260);if(!p)continue;fl.push(p);
  B.flocks.push({x:p[0],y:p[1],n:5,k:s%2,b:[...Array(5)].map((_,i)=>({dx:(rpw3aR(s*13+i)-.5)*54,dy:(rpw3aR(s*17+i)-.5)*18,ph:rpw3aR(s*5+i)*9,fl:rpw3aR(i+s)<.5})),st:0,at:-99})}
 const bp=[];B.bflies=[];for(let s=0;s<8;s++){const p=rpw3aSpot(B,9500+s*331,60,400,(x,y)=>land(x,y,10),bp,170);if(!p)continue;bp.push(p);B.bflies.push({x:p[0],y:p[1]-14,k:s%3,ph:rpw3aR(s+50)*TAU,v:.6+rpw3aR(s+60)*.6})}
 /* hotspots: windmills, the dock airship, cottages, sheep, hives, trees, wells, lamps, sunflowers, bridges, the castle, flocks */
 const H=[];for(const m of B.mills)H.push({k:'mill',x:m.x,y:m.y-60,r:46,ry:70,o:m});H.push({k:'ship',x:88,y:116,r:84,ry:44});
 for(const it of B.trees){const K={house:[0,-30,32,32],sheep:[0,-10,18,14],hive:[0,-10,14,14],tree:[0,-it.h*.62,it.h*.42,it.h*.44],blossom:[0,-it.h*.6,it.h*.4,it.h*.4],well:[0,-20,20,24],lamp:[4,-30,10,18],sunfl:[0,-24,16,16],hay:[0,-12,16,14]}[it.k];
  if(K)H.push({k:it.k,x:it.x+K[0],y:it.y+K[1],r:K[2],ry:K[3],o:it})}
 for(const b of map.bridge||[])H.push({k:'bridge',x:b[0],y:b[1],r:56,ry:40});for(const f of B.flocks)H.push({k:'flock',x:f.x,y:f.y-6,r:44,ry:24,o:f});
 for(const f of falls)H.push({k:'fall',x:f.x,y:f.y+60,r:22,ry:70,o:f});H.push({k:'castle',x:c.x+170,y:c.y+300,r:110,ry:170});
 B.balloons.forEach(b=>H.push({k:'balloon',x:-999,y:-999,r:30,ry:42,o:b,dyn:1}));B.hot=H;
 B.vees=[...Array(6)].map((_,i)=>({x0:rpw3aR(i+40)*1600,y:120+rpw3aR(i+41)*560,v:26+rpw3aR(i+42)*26,a:rpw3aR(i+43)*TAU,s:.8+rpw3aR(i+44)*.5}));
 /* light: soft sun rays from the upper right and a warm glow, laid over the finished map */
 {const g=B.c.getContext('2d');g.save();g.globalCompositeOperation='lighter';for(let i=0;i<7;i++){const a=2.2+i*.09+rpw3aR(i+70)*.05,w=30+rpw3aR(i+71)*70,x0=1480,y0=-60;
   const q=g.createLinearGradient(x0,y0,x0+Math.cos(a)*1300,y0+Math.sin(a)*1300);q.addColorStop(0,'rgba(255,248,210,.16)');q.addColorStop(1,'rgba(255,248,210,0)');g.fillStyle=q;
   g.beginPath();g.moveTo(x0,y0);g.lineTo(x0+Math.cos(a-w/2600)*1500,y0+Math.sin(a-w/2600)*1500);g.lineTo(x0+Math.cos(a+w/2600)*1500,y0+Math.sin(a+w/2600)*1500);g.closePath();g.fill()}
  g.globalAlpha=.3;g.drawImage(rpwGlow('255,240,190',160),1100,-260,700,560);g.restore()}
 /* sprites made now, so the first frames do not stall */
for(let k=0;k<2;k++){rpw3aBird('m'+k,RPW3A_BIRDC[k]);rpw3aBird('m'+k,RPW3A_BIRDC[k],1)}for(let k=0;k<3;k++)rpw3aBfly(k,RPW3A_BFC[k]);rpw3aVee(0,'#2a2a4a');
 ['#ff9ad8','#ffe46a','#ffffff','#9ae870'].forEach((col,j)=>rpw3aPetal(j,col));rpw3aBalloon(0,['#9a6ae8','#ffffff','#ffd45a']);rpw3aBalloon(1,['#ff6a5a','#ffe46a','#3a8ae0']);for(const m of B.mills)rpw3aBladeSpin(m.s);
 B.puffs=[...Array(10)].map((_,i)=>({y:110+i*78+rpw3aR(i+3)*40,v:6+rpw3aR(i+7)*16,x0:rpw3aR(i+9)*1900,k:i%3,far:i%2}))}
{const b0=RPW.bake.meadow;RPW.bake.meadow=map=>{const B=b0(map);try{rpw3aMeadowX(B,map)}catch(e){console.error(e)}return B}}
/* live: the clouds, balloons and airships below the islands, waterfalls, bridge ropes, flocks, butterflies, windmills, birds, reactions */
const RPW3A_BIRDC=[['#4a8ae0','#ffb27a','#2e5aa8'],['#ffffff','#ffe0b0','#c8d0e8']],RPW3A_BFC=[['#ffd23a','#ff8a3a'],['#ff9ad8','#c86ab8'],['#9ae8ff','#5a9ae8']];
function rpw3aAmbMeadow(c,R){const B=R.bake,t=R.t,lite=R.lite||R.rm,S=rpw3aTick(R),dt=S.dt,gk=R.gust?R.gust.k:0;c.save();
 /* below the islands: two cloud layers (the far one slower and bluer), balloons, small airships; then the islands are patched back */
 const PF=[rpw3aPuff(0,220,80,['rgba(255,255,255,.95)','rgba(245,250,255,.7)','rgba(240,248,255,0)']),rpw3aPuff(1,160,60,['rgba(255,255,255,.9)','rgba(235,245,255,.6)','rgba(235,245,255,0)']),rpw3aPuff(3,300,100,['rgba(220,236,255,.75)','rgba(220,236,255,.45)','rgba(220,236,255,0)'])];
 const PFF=[rpw3aPuff(10,154,56,['rgba(236,244,255,.62)','rgba(225,238,255,.4)','rgba(225,238,255,0)']),rpw3aPuff(11,112,42,['rgba(236,244,255,.6)','rgba(225,238,255,.38)','rgba(225,238,255,0)']),rpw3aPuff(13,210,70,['rgba(210,228,255,.5)','rgba(210,228,255,.3)','rgba(210,228,255,0)'])];
 const pat=[];for(let i=0;i<B.puffs.length;i+=lite?4:2.5){const k=B.puffs[i|0],P=(k.far?PFF:PF)[k.k],w=P.w,h=P.h,x=Math.round(((k.x0+t*k.v*(k.far?.55:1))%(1600+w))-w),y=Math.round(k.y-h/2);c.drawImage(P.c,x,y);pat.push([x,y,w,h])}
 if(!lite)for(const b of B.balloons){const BS=rpw3aBalloon(b.k,b.k?['#ff6a5a','#ffe46a','#3a8ae0']:['#9a6ae8','#ffffff','#ffd45a']),h=B.hot.find(q=>q.o===b),age=rpw3aAge(R,h),rise=age<4?Math.sin(Math.min(1,age/4)*Math.PI)*30:0;
  const x=Math.round(b.x+Math.sin(t*.13+b.ph)*36),y=Math.round(b.y+Math.sin(t*.5+b.ph*2)*8-rise);c.drawImage(BS.c,x-BS.ax,y-BS.ay);if(age<1.2){c.globalCompositeOperation='lighter';c.globalAlpha=1-age/1.2;c.drawImage(rpwGlow('255,170,60',20),x-16,y-50,32,32);c.globalCompositeOperation='source-over';c.globalAlpha=1}
  pat.push([x-BS.ax,y-BS.ay,BS.w,BS.h]);if(h){h.x=x;h.y=y-50}}
 for(let i=lite?1:0;i<2;i++){const SH=rpw3aShip('far'+i,.42,i?['#ffd45a','#ff8a3a','#c86a1a','#ffffff']:['#7ad8ff','#ffffff','#3a8ae0','#ffd45a']),x=Math.round(((t*(18+i*9)+i*900)%(1600+SH.w))-SH.w/2),y=Math.round((i?690:380)+Math.sin(t*.9+i)*4);c.drawImage(SH.c,x-SH.ax,y-SH.ay);pat.push([x-SH.ax,y-SH.ay,SH.w,SH.h])}
 rpw3aPatch(c,B,pat);
 /* waterfalls: streak frames over the baked water, mist where they meet the clouds */
 for(const f of B.falls){const FS=rpw3aFallSpr(f);rpw3aFr(c,FS,lite?0:t*24,f.x,f.y);if(!lite&&f.mist){const MS=rpw3aPuff(4,60,40,['rgba(255,255,255,.8)','rgba(240,248,255,.4)','rgba(240,248,255,0)']);
  for(let k=0;k<2;k++){const u=(t*.4+k*.5)%1;c.globalAlpha=.75*Math.sin(u*Math.PI);rpw3aBl(c,MS.c,f.x-30+(k?8+u*6:-8-u*6),f.y+f.L-10-u*12)}c.globalAlpha=1}}
 /* bridge hand ropes sway (more in a gale, and after a poke) */
 c.strokeStyle='#cdb47c';c.lineWidth=2.4;c.beginPath();for(let bi=0;bi<B.bridges.length;bi++){const b=B.bridges[bi],Sm=b.S,im=(b.i0+b.i1)>>1;if(!b.h)b.h=B.hot.find(q=>q.k==='bridge'&&Math.hypot(q.x-Sm[im].x,q.y-Sm[im].y)<70)||{};const pw=rpw3aWob(rpw3aAge(R,b.h),9,9,1.6);
  for(const sd of[-1,1]){const P=i=>{const p=Sm[i];return[p.x-Math.sin(p.a)*38*sd,p.y+Math.cos(p.a)*38*sd-16]},a=P(b.i0),e=P(b.i1),m=P(im),sw=Math.sin(t*2.2+bi+sd)*2+gk*6*Math.sin(t*9+bi)+pw;
   c.moveTo(a[0],a[1]);c.quadraticCurveTo(2*m[0]-(a[0]+e[0])/2,2*(m[1]+9+sw)-(a[1]+e[1])/2,e[0],e[1])}}c.stroke();
 /* perched flocks: peck and hop; a monster near or a poke sends them up in a wide loop, they land again after a while */
 for(const f of B.flocks){const BR=rpw3aBird('m'+f.k,RPW3A_BIRDC[f.k]),BL=rpw3aBird('m'+f.k,RPW3A_BIRDC[f.k],1);
  if(f.R!==R){f.R=R;f.st=0;f.at=-99}if(f.st===0&&!R.rm){let near=rpw3aAge(R,B.hot.find(q=>q.o===f))<.5;if(!near&&(R.t*4|0)%2===0)for(const e of R.foes){if(e.dead||e.air)continue;const q=rpPos(R,e);if(Math.abs(q.x-f.x)<120&&Math.abs(q.y-f.y)<90){near=true;break}}
   if(near){f.st=1;f.at=t;if(!lite)rpw3aSnd('flap')}}
  const age=t-f.at;if(f.st===1&&age>9)f.st=2;if(f.st===2&&age>12)f.st=0;
  for(let i=0;i<f.b.length;i++){const b=f.b[i],hx=f.x+b.dx,hy=f.y+b.dy;
   if(f.st===0){const pk=Math.sin(t*2.3+b.ph)>.55,hop=Math.max(0,Math.sin(t*1.1+b.ph*3))>.97?Math.sin((t*1.1+b.ph*3)*20)*2:0;rpw3aFr(c,b.fl?BL:BR,pk?1:0,hx,hy-Math.abs(hop))}
   else{const u=f.st===1?Math.min(1,(age-i*.06)/9):1-rpw3aEo(Math.min(1,(age-9)/3)),dir=b.fl?-1:1,a=Math.max(0,u)*Math.PI*1.4+b.ph*.2;
    const x=hx+dir*Math.sin(a)*(180+i*24)*Math.min(1,u*1.6),y=hy-Math.sin(Math.min(1,Math.max(0,u)*1.3)*Math.PI*.5)*(150+i*16)-Math.sin(a*2)*20*u;
    rpw3aFr(c,(Math.cos(a)*dir)>=0?BR:BL,2+((t*16+i*1.7)|0)%6,x,y)}}}
 /* butterflies flutter round their flowers, flee from a poke */
 if(!R.rm){const pk=S.poke;for(let i=0;i<B.bflies.length;i+=lite?2:1){const b=B.bflies[i],BF=rpw3aBfly(b.k,RPW3A_BFC[b.k]);let x=b.x+Math.sin(t*b.v+b.ph)*34+Math.sin(t*b.v*2.3+b.ph)*10,y=b.y+Math.sin(t*b.v*1.7+b.ph*2)*14-Math.abs(Math.sin(t*3+b.ph))*6;
  if(pk&&t-pk[2]<5){const dx=x-pk[0],dy=y-pk[1],d=Math.hypot(dx,dy);if(d<160){const k=Math.sin(Math.min(1,(t-pk[2])/5)*Math.PI)*(1-d/160)*120;x+=dx/(d||1)*k;y+=dy/(d||1)*k-k*.6}}
  rpw3aFr(c,BF,t*14+i,x,y)}}
 /* windmill blades: a poke spins one up, the gale turns them all faster */
 for(const m of B.mills){const BL=rpw3aBladeSpin(m.s);const h=B.hot.find(q=>q.o===m),age=rpw3aAge(R,h),boost=age<5?7*Math.exp(-age*.8):0;if(m.R!==R){m.R=R;m.a=0}m.a+=dt*m.v*(1+gk*1.5+boost);
  rpw3aSpinPut(c,BL,m.x,m.y-86,m.a)}
 /* the moored airship at the dock: bobs, its propeller turns; a poke makes it toot and puff */
 {const SH=rpw3aShip('dock',.8,['#ff6a5a','#fff4dc','#c8402a','#ffd45a']),h=B.hot.find(q=>q.k==='ship'),age=rpw3aAge(R,h),b=Math.round(Math.sin(t*1.1)*3+rpw3aWob(age,5,7,2)),x=88,y=116+b,PR=rpw3aPropSpr();c.drawImage(SH.c,Math.round(x-SH.ax),Math.round(y-SH.ay));
  c.save();c.translate(x-78,y+22);c.rotate(t*(14+(age<3?30*(1-age/3):0)));c.drawImage(PR.c,-12,-12);c.restore();c.strokeStyle='rgba(18,8,31,.7)';c.lineWidth=1.2;c.beginPath();c.moveTo(x+20,y+34);c.lineTo(96,B.dock.y-80);c.stroke();
  if(age<2.4){const ST=rpw3aPuff(5,44,36,['rgba(255,255,255,.85)','rgba(240,240,250,.45)','rgba(240,240,250,0)']);for(let k=0;k<3;k++){const u=Math.min(1,(age-k*.18)/1.8);if(u<=0)continue;const s=.5+u*1.2;c.globalAlpha=(1-u)*.9;c.drawImage(ST.c,x+40+u*40-22*s,y-30-u*40-18*s,44*s,36*s)}c.globalAlpha=1}}
 /* birds high up */
 if(!R.rm){const V=rpw3aVee(0,'#2a2a4a');for(let i=0;i<B.vees.length;i+=lite?2:1){const b=B.vees[i],x=((b.x0+t*b.v)%1700)-50,y=b.y+Math.sin(t*.8+b.a)*18;rpw3aFr(c,V,t*9+b.a*3,x,y,b.s)}}
 /* reactions: bees round a poked hive, smoke from a poked cottage, chimes over the castle */
 for(const h of B.hot){const age=rpw3aAge(R,h);if(age>4)continue;
  if(h.k==='hive'){c.fillStyle='#ffd23a';c.strokeStyle=RPO;c.lineWidth=1;for(let i=0;i<7;i++){const a=t*(5+i*.7)+i*2.1,r=10+age*12+i*2,bx=h.x+Math.cos(a)*r,by=h.y-4+Math.sin(a*1.3)*r*.5-age*4;c.globalAlpha=Math.min(1,(4-age));c.beginPath();c.arc(bx,by,2,0,TAU);c.fill();c.stroke()}c.globalAlpha=1}
  else if(h.k==='house'){const SM=rpw3aPuff(2,40,32,['rgba(240,240,250,.8)','rgba(230,230,245,.4)','rgba(230,230,245,0)']);for(let k=0;k<3;k++){const u=Math.min(1,(age-k*.3)/2.6);if(u<=0)continue;const s=.4+u*1.1;c.globalAlpha=(1-u)*.85;c.drawImage(SM.c,h.x+13+u*14-20*s,h.y-26-u*50-16*s,40*s,32*s)}c.globalAlpha=1}}
 c.restore();rpw3aCastleLive(c,'meadow',B.cast.x,B.cast.y,t,lite)}
/* the reactions to a poke (sounds and particles; the live layer draws the rest from the hotspot's age) */
RPW3A.react.meadow=(R,h,x,y)=>{const k=h&&h.k,P=(n,c,o)=>rpw3aPt(R,h?h.x:x,h?h.y:y,n,c,o);
 if(k==='mill'){rpw3aSnd('creak');P(6,['#ffffff','#fff4dc'],{v:90,s:4,k:'dust',g:-20,l:1.2})}
 else if(k==='ship'||k==='balloon'){rpw3aSnd(k==='ship'?'toot':'burn')}
 else if(k==='tree'||k==='blossom'){rpw3aSnd('chirp');P(10,k==='tree'?['#4ab854','#86dc62','#2e8a3e']:['#ffa8d0','#ffe8f4','#ff7ab8'],{v:110,s:4,g:70,l:1.4,jx:30});
  const f=R.bake.flocks&&R.bake.flocks.find(f=>Math.hypot(f.x-h.x,f.y-h.y)<260);if(f&&f.st===0){f.st=1;f.at=R.t}}
 else if(k==='sheep'){rpw3aSnd('baa');P(3,['#ff6a8a'],{k:'heart',v:40,up:1,s:6,g:-30,l:1.4})}
 else if(k==='hive')rpw3aSnd('buzz');else if(k==='house'){rpw3aSnd('puff')}
 else if(k==='well'||k==='fall'){rpw3aSnd('splash');P(8,['#9ad8ff','#ffffff','#4aa8e8'],{v:110,up:1,s:3,k:'dust',g:260,l:.9})}
 else if(k==='flock'){h.o.st=1;h.o.at=R.t;rpw3aSnd('flap')}
 else if(k==='bridge')rpw3aSnd('creak');else if(k==='castle'){rpw3aSnd('bell');P(8,['#ffe46a','#ffffff'],{v:120,up:1,s:6,g:40,l:1.2})}
 else if(k==='lamp'){rpw3aSnd('pop');P(5,['#ffe08a'],{k:'glow',v:30,s:3,g:-20,l:1.2})}
 else if(k==='sunfl'||k==='hay'){rpw3aSnd('pop');P(6,k==='hay'?['#f0c84a','#c89a2a']:['#ffd23a','#ff8a3a'],{v:80,up:1,s:3,k:'dust',g:150,l:1})}
 else{P(6,['#ffa8d0','#ffe46a','#ffffff','#9ae870'],{v:70,up:1,s:3,g:120,l:1,jx:10})}};
/* twist: the gale - fewer, longer ribbons and petal frames (cheaper than single ellipses) */
function rpw3aTwMeadow(c,R){const k=R.gust?R.gust.k:0;if(k<=0)return;const t=R.t,n=R.lite?6:12;c.save();c.lineCap='round';c.strokeStyle='#ffffff';
 for(let j=0;j<3;j++){c.globalAlpha=k*(.25+.2*j);c.lineWidth=2+j;c.beginPath();for(let i=j;i<n;i+=3){const y=60+((i*137)%780),sp=900+(i%5)*160,x=((t*sp+i*331)%2000)-200,L=140+(i%4)*60,w=Math.sin(t*3+i)*8;
  c.moveTo(x,y);c.bezierCurveTo(x+L*.3,y+w,x+L*.6,y-w,x+L,y+w*.5)}c.stroke()}
 const PT=['#ff9ad8','#ffe46a','#ffffff','#9ae870'].map((col,j)=>rpw3aPetal(j,col));c.globalAlpha=k;for(let i=0;i<(R.lite?10:26);i++){const x=((t*(520+(i%7)*60)+i*211)%1800)-100,y=80+((i*97)%740)+Math.sin(t*4+i)*20;rpw3aFr(c,PT[i%4],t*12+i,x,y)}
 c.restore()}
RPW.amb.meadow=rpw3aAmbMeadow;RPW.twist.meadow=rpw3aTwMeadow;

/* ======================================================================================================================
   Gearworks Foundry
   ====================================================================================================================== */
/* a trip hammer (frame baked; the arm and its head are live) and a piston engine (base baked; flywheel, rods and steam live) */
function rpw3aHammerBase(g,x,y){g.save();g.translate(x,y);rpBlob(g,0,2,52,10,'#000',.28);
 rpw3aBox(g,0,0,50,10,12,['#5a5868','#8a88a0','#3a3844'],'plate');
 for(const px of[-38,30]){g.fillStyle='#7a5030';g.beginPath();g.rect(px-5,-92,10,84);g.fill();rpw3aO(g,2);g.fillStyle='rgba(255,230,180,.25)';g.fillRect(px-4,-90,3,80);rpw3aRiv(g,px,-80,px,-20,3,1.6,'#c8b89a')}
 g.fillStyle='#6a4426';g.beginPath();g.rect(-46,-100,86,12);g.fill();rpw3aO(g,2.2);rpw3aRiv(g,-40,-94,34,-94,5,1.7,'#ffe08a');
 /* the anvil block and a glowing bar on it */g.fillStyle='#3a3844';g.beginPath();g.moveTo(-34,-10);g.lineTo(2,-10);g.lineTo(-2,-26);g.lineTo(-30,-26);g.closePath();g.fill();rpw3aO(g,2);
 g.fillStyle='#5a5868';g.beginPath();g.rect(-36,-32,40,7);g.fill();rpw3aO(g,1.8);g.fillStyle='#ffb84a';g.beginPath();g.rect(-28,-37,24,5);g.fill();rpw3aO(g,1.4);g.fillStyle='#fff4b0';g.fillRect(-25,-36,14,2);
 /* the cam wheel at the pivot */g.fillStyle='#c89a3a';g.beginPath();g.arc(22,-58,9,0,TAU);g.fill();rpw3aO(g,2);g.fillStyle='#6a4a14';g.beginPath();g.arc(22,-58,3,0,TAU);g.fill();g.restore()}
function rpw3aEngineBase(g,x,y){g.save();g.translate(x,y);rpBlob(g,0,2,58,11,'#000',.28);const FP=RPW3A_FP;
 g.beginPath();g.rect(-56,-18,112,18);g.fillStyle=FP.brick[0];g.fill();g.save();g.clip();g.strokeStyle='rgba(18,8,31,.35)';g.lineWidth=1;for(let yy=-12;yy<0;yy+=6){g.beginPath();g.moveTo(-60,yy);g.lineTo(60,yy);g.stroke()}g.restore();g.beginPath();g.rect(-56,-18,112,18);rpw3aO(g,2.2);
 /* the cylinder */g.beginPath();g.rect(-52,-50,48,26);let q=g.createLinearGradient(0,-50,0,-24);q.addColorStop(0,'#8a88a0');q.addColorStop(.35,'#c8c4d8');q.addColorStop(1,'#3a3844');g.fillStyle=q;g.fill();rpw3aO(g,2.2);
 for(const bx of[-48,-28,-8]){g.fillStyle='#c89a3a';g.beginPath();g.rect(bx-2,-52,4,30);g.fill();rpw3aO(g,1.4)}
 g.fillStyle='#4a4858';g.beginPath();g.rect(-56,-30,8,12);g.fill();rpw3aO(g,1.6);
 /* the exhaust stack and a gauge */g.fillStyle='#3a3440';g.beginPath();g.rect(-40,-72,9,22);g.fill();rpw3aO(g,1.8);g.fillStyle='#2a2428';g.fillRect(-42,-75,13,4);rpw3aGauge(g,-16,-50);
 /* the flywheel stand and crosshead guide */g.fillStyle='#5a5868';g.beginPath();g.moveTo(16,-18);g.lineTo(26,-48);g.lineTo(34,-48);g.lineTo(44,-18);g.closePath();g.fill();rpw3aO(g,2);
 g.strokeStyle=RPO;g.lineWidth=5;g.beginPath();g.moveTo(-4,-41);g.lineTo(14,-41);g.moveTo(-4,-33);g.lineTo(14,-33);g.stroke();g.strokeStyle='#8a88a0';g.lineWidth=2.4;g.stroke();g.restore()}
function rpw3aFlywheel(){return rpw3aSpr('fly',64,64,32,32,g=>{g.beginPath();g.arc(0,0,28,0,TAU);g.moveTo(22,0);g.arc(0,0,22,0,TAU,true);g.fillStyle='#4a4858';g.fill('evenodd');rpw3aO(g,2.4);
 g.strokeStyle='rgba(255,255,255,.3)';g.lineWidth=2;g.beginPath();g.arc(0,0,25,Math.PI*1.1,Math.PI*1.6);g.stroke();
 for(let i=0;i<6;i++){const a=i/6*TAU;g.strokeStyle=RPO;g.lineWidth=5;g.beginPath();g.moveTo(Math.cos(a)*5,Math.sin(a)*5);g.lineTo(Math.cos(a)*23,Math.sin(a)*23);g.stroke();g.strokeStyle='#6a6878';g.lineWidth=2.6;g.stroke()}
 g.fillStyle='#c89a3a';g.beginPath();g.arc(0,0,6,0,TAU);g.fill();rpw3aO(g,1.8);g.fillStyle='#c8402a';g.beginPath();g.arc(14,0,3.4,0,TAU);g.fill();rpw3aO(g,1.4)})}
function rpw3aFoundryX(B,map){const G=B.G,A=B.A,CX=B.CX,CY=B.CY,lever=B.lever,cast=B.cast,g=B.c.getContext('2d');g.lineJoin='round';g.lineCap='round';
 const O=rpw3aOcc(G,cast,{rw:40,ok:(x,y,w,h)=>y-h>160&&y>200&&y<(x>290&&x<1320?735:770)&&!(Math.abs(x-CX)<120+w&&Math.abs(y-CY)<96+h*.5)&&!(map.vents||[]).some(v=>Math.hypot(x-v[0],(y-v[1])*1.4)<64+w)&&!(lever&&Math.abs(x-lever.x)<50+w&&Math.abs(y-lever.y)<70)
  &&!A.chan.some(L=>L.some(p=>Math.abs(p[0]-x)<w+16&&p[1]>y-h-10&&p[1]<y+12))});for(const q of B.occ)O.L.push(q);
 const fit=(w,h,seed)=>{const C=[];for(let y=230;y<=790;y+=10)for(let x=40;x<=1310;x+=10)if(O.ok(x,y,w,h,10))C.push([x,y]);if(!C.length)return null;const c=C[(rpw3aR(seed)*C.length)|0];O.add(c[0],c[1],w,h);return c};
 const hm=fit(50,104,3),en=fit(58,80,11);B.ham=hm&&{x:hm[0],y:hm[1]};B.eng=en&&{x:en[0],y:en[1],a:0};
 if(hm)rpw3aHammerBase(g,hm[0],hm[1]);if(en)rpw3aEngineBase(g,en[0],en[1]);B.occ=O.L.slice();
 /* hotspots */
 const H=[],K={crate:[0,-16,22,20],barrel:[0,-16,14,18],tanks:[0,-22,22,24],ingots:[0,-8,22,12],coal:[0,-6,18,10],anvil:[0,-14,22,16],gauge:[0,-28,12,16],cart:[0,-16,30,18],gears:[0,-6,16,10],lamp:[6,-40,12,18],
  boiler:[0,-34,30,34],forge:[0,-40,40,40],sphere:[0,-50,36,46],quench:[0,-14,14,16],pipe:[0,-6,40,12]};
 for(const it of B.trees){const k=K[it.k];if(k)H.push({k:it.k,x:it.x+k[0],y:it.y+k[1],r:k[2],ry:k[3],o:it})}
 for(let i=0;i<A.gears.length;i++){const [x,y,r]=A.gears[i];H.push({k:'gear',x,y,r:r*.9,ry:r*.9,i})}
 if(lever)H.push({k:'lever',x:lever.x,y:lever.y-40,r:30,ry:46});H.push({k:'pool',x:CX,y:CY,r:100,ry:72},{k:'blast',x:370,y:180,r:56,ry:90},{k:'castle',x:cast.x+170,y:cast.y+300,r:110,ry:170});
 for(const e of G.ent)H.push({k:'portal',x:Math.max(30,e.x-14),y:e.y-40,r:70,ry:70});if(B.ham)H.push({k:'hammer',x:B.ham.x,y:B.ham.y-50,r:50,ry:56});if(B.eng)H.push({k:'engine',x:B.eng.x,y:B.eng.y-40,r:58,ry:40});
 B.hot=H;B.gst=A.gears.map(()=>({a:0,b:0}));B.vst=(map.vents||[]).map(v=>({x:v[0],y:v[1],at:-99}));
 /* sprites made now */for(const b of B.belts)rpw3aBeltF(b);rpw3aFlywheel();rpw3aSpin('fly',rpw3aFlywheel(),TAU/6,18);rpw3aSmk(2,44,36,['rgba(255,255,255,.78)','rgba(240,240,250,.42)','rgba(240,240,250,0)'],10);rpw3aSmk(3,40,32,['rgba(70,60,66,.55)','rgba(70,60,66,.3)','rgba(70,60,66,0)'],10,1.6)}
{const b0=RPW.bake.foundry;RPW.bake.foundry=map=>{const B=b0(map);try{rpw3aFoundryX(B,map)}catch(e){console.error(e)}return B}}
/* the moving belt surface of a conveyor as 14 frames (2 px apart) over its 28 px period, drawn once per belt */
function rpw3aBeltF(b){if(b.F)return b.F;const Sm=b.S,n=b.i1-b.i0;let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;for(let i=b.i0;i<=b.i1;i++){const p=Sm[i];x0=Math.min(x0,p.x);y0=Math.min(y0,p.y);x1=Math.max(x1,p.x);y1=Math.max(y1,p.y)}
 x0=Math.floor(x0-34);y0=Math.floor(y0-34);x1=Math.ceil(x1+34);y1=Math.ceil(y1+34);const w=x1-x0,h=y1-y0;
 b.F=rpw3aStrip('belt'+b.i0+'_'+Sm[b.i0].x+'_'+Sm[b.i0].y,w,h,14,0,0,(g,f)=>{g.translate(-x0,-y0);const off=f*2;g.lineCap='butt';g.strokeStyle='#2e2a30';g.lineWidth=3;g.beginPath();
  for(let s=off;s<n*4;s+=14){const i=b.i0+Math.floor(s/4);if(i>b.i1)break;const p=Sm[i],nx=-Math.sin(p.a),ny=Math.cos(p.a);g.moveTo(p.x+nx*24,p.y+ny*24);g.lineTo(p.x-nx*24,p.y-ny*24)}g.stroke();
  g.strokeStyle='rgba(255,200,74,.55)';g.beginPath();for(let s=(off*2)%56;s<n*4-8;s+=56){const i=b.i0+Math.floor(s/4);if(i+2>b.i1)break;const p=Sm[i],tx=Math.cos(p.a),ty=Math.sin(p.a),nx=-ty,ny=tx;g.moveTo(p.x-tx*6+nx*10,p.y-ty*6+ny*10);g.lineTo(p.x+tx*4,p.y+ty*4);g.lineTo(p.x-tx*6-nx*10,p.y-ty*6-ny*10)}g.stroke()},0);b.F.px=x0;b.F.py=y0;return b.F}
const RPW3A_STEAMK={boiler:1,sphere:1,quench:1,engine:1,gauge:1,pipe:1};
/* live: wall gears (faster while towers fire near them), the crucible ring, belts, molten glow and flow, the hammer, the engine,
   sparks, lamps, steam (from valves, boilers, vents crossed by monsters, poked machines), smoke, the gate lamps */
function rpw3aAmbFoundry(c,R){const B=R.bake,A=B.A,t=R.t,lite=R.lite||R.rm,S=rpw3aTick(R),dt=S.dt;c.save();
 /* wall gears: neighbours turn the other way; a tower firing within reach or a poke winds them up */
 const fire=[];for(const p of R.pads)if(p.tw&&(p.tw.fire||0)>.5)fire.push(p);
 for(let i=0;i<A.gears.length;i++){const [x,y,r]=A.gears[i],st=B.gst[i],n=Math.max(8,Math.round(r/5)),G=rpw3aGear('w'+r+(i%2),r,n,i%2?['#8a88a0','#c8c4d8','#3a3844']:RPW3A_FP.brass);
  if(st.R!==R){st.R=R;st.b=0}const age=rpw3aAge(R,B.hot.find(h=>h.k==='gear'&&h.i===i));let tg=age<2?6:0;if(!tg)for(const p of fire)if(Math.abs(p.x-x)<260&&Math.abs(p.y-y)<220){tg=3;break}
  st.b+=(tg-st.b)*Math.min(1,dt*(tg>st.b?6:1.2));st.a+=dt*24/r*(1+st.b);rpw3aSpinPut(c,rpw3aSpin('w'+r+(i%2),G,TAU/n,12),x,y,(i%2?-1:1)*st.a)}
 /* the gear ring round the crucible */
 {const GR=rpw3aSpr('ring',230,230,115,115,g=>{const n=36,R1=108,R0=92;g.beginPath();for(let i=0;i<n;i++){const a=i/n*TAU,w=TAU/n;g.lineTo(Math.cos(a-w*.3)*R0,Math.sin(a-w*.3)*R0);g.lineTo(Math.cos(a-w*.18)*R1,Math.sin(a-w*.18)*R1);g.lineTo(Math.cos(a+w*.18)*R1,Math.sin(a+w*.18)*R1);g.lineTo(Math.cos(a+w*.3)*R0,Math.sin(a+w*.3)*R0)}g.closePath();
  g.moveTo(84,0);g.arc(0,0,84,0,TAU,true);g.fillStyle='#c89a3a';g.fill('evenodd');rpw3aO(g,2.4);g.strokeStyle='rgba(255,240,180,.5)';g.lineWidth=2;g.beginPath();g.arc(0,0,88,Math.PI*1.1,Math.PI*1.6);g.stroke();for(let i=0;i<12;i++){const a=i/12*TAU;g.fillStyle='#6a4a14';g.beginPath();g.arc(Math.cos(a)*88,Math.sin(a)*88,2.4,0,TAU);g.fill()}});
  rpw3aSpinPut(c,rpw3aSpin('ring',GR,TAU/36,8,.72),B.CX,B.CY,t*.25)}
 /* conveyor belts: slats and arrows run along the road */
 for(const b of B.belts){const F=rpw3aBeltF(b);rpw3aFr(c,F,(t*38%28)/2,F.px,F.py)}
 /* molten glow: the pool breathes (a poke makes it surge), hot blobs flow down the channels */
 const pAge=rpw3aAge(R,B.hot.find(h=>h.k==='pool')),surge=pAge<2?1-pAge/2:0;
 c.globalCompositeOperation='lighter';
 for(let i=0;i<A.glows.length;i++){const [x,y,r]=A.glows[i];if(r<120)continue;const rr=Math.min(r,90),gl=rpw3aGlowE('255,120,30',rr,.6);c.globalAlpha=Math.min(1,.14+.1*Math.sin(t*2.1+i*1.7)+surge*.4*(r>=150));rpw3aBl(c,gl,x-rr,y-rr*.6)}
 {const bl=rpwGlow('255,200,90',7);c.globalAlpha=.9;for(const L of A.chan)for(let k=0;k<(lite?3:6);k++){const u=(t*.3+k/(lite?3:6))%1,p=L[Math.min(L.length-1,(u*L.length)|0)];rpw3aBl(c,bl,p[0]-7,p[1]-7)}}
 c.fillStyle='#fff4b0';c.globalAlpha=.8;c.beginPath();for(const L of A.chan)for(let k=0;k<5;k++){const u=(t*.35+k/5+.1)%1,p=L[Math.min(L.length-1,(u*L.length)|0)];c.rect(p[0]-2,p[1]-1.5,4,3)}c.fill();
 if(A.pool&&!lite){const [x,y,rx,ry]=A.pool;c.globalAlpha=.7;c.fillStyle='#fff8d0';c.beginPath();const nb=surge?12:6;for(let k=0;k<nb;k++){const u=(t*(.6+surge)+k/nb)%1,a=k*1.9,px=x+Math.cos(a)*rx*.55,py=y+Math.sin(a)*ry*.5;c.moveTo(px+3*(1-u)+1,py-u*6);c.arc(px,py-u*6,3*(1-u)+1,0,TAU)}c.fill()}
 /* sparks off the anvils */
 if(!lite){c.strokeStyle='#ffd27a';c.lineWidth=1.6;c.globalAlpha=.9;c.beginPath();for(let i=0;i<A.sparks.length;i++){const [x,y]=A.sparks[i],ph=(t*1.3+i*.37)%1;if(ph>.35)continue;const u=ph/.35;for(let k=0;k<6;k++){const a=-Math.PI*(.15+rpw3aR(k+i*7)*.7),v=10+rpw3aR(k+i)*26,px=x+Math.cos(a)*v*u,py=y+Math.sin(a)*v*u+18*u*u;c.moveTo(px,py);c.lineTo(px-Math.cos(a)*4,py-Math.sin(a)*4)}}c.stroke()}
 /* lamps (a poked one flares) */{const lg=rpwGlow('255,200,110',16);for(let i=lite?1:0;i<A.lamps.length;i+=lite?2:1){const [x,y]=A.lamps[i];c.globalAlpha=.4+.08*Math.sin(t*9+i);rpw3aBl(c,lg,x-16,y-16)}}
 c.globalCompositeOperation='source-over';c.globalAlpha=1;
 /* the trip hammer: lifts slowly, slams down with sparks; a poke makes it slam at once */
 if(B.ham){const h=B.ham,hh=B.hot.find(q=>q.k==='hammer'),age=rpw3aAge(R,hh);let u,P=2.6;if(age<.7){u=age<.35?rpw3aEo(age/.35):age<.42?1-Math.pow((age-.35)/.07,2):0}
  else{const ph=(t/P+h.x*.001)%1;u=ph<.68?(1-Math.cos(ph/.68*Math.PI))/2:ph<.8?1:ph<.86?1-Math.pow((ph-.8)/.06,2):Math.max(0,Math.sin((ph-.86)/.14*Math.PI)*.06)}
  if(R.rm)u=.3;const hit=u<=.001&&(h.u||0)>.2;h.u=u;if(hit&&h.R===R&&!lite){rpw3aPt(R,h.x-16,h.y-38,9,['#ffd27a','#ffb84a','#ffffff'],{v:150,up:1,s:3,sp:2.6,g:300,l:.6});if(age<1)rpw3aSnd('clang')}h.R=R;
  const px=h.x+22,py=h.y-58,a=2.58+u*.62,ex=px+Math.cos(a)*44,ey=py+Math.sin(a)*44;c.strokeStyle=RPO;c.lineWidth=9;c.beginPath();c.moveTo(px+Math.cos(a)*-12,py+Math.sin(a)*-12);c.lineTo(ex,ey);c.stroke();c.strokeStyle='#8a5a32';c.lineWidth=5.4;c.stroke();
  c.save();c.translate(ex,ey);c.rotate(a-Math.PI);c.fillStyle='#4a4858';c.beginPath();c.rect(-12,-11,22,22);c.fill();rpw3aO(c,2.2);c.fillStyle='#8a88a0';c.fillRect(-10,-9,18,5);c.restore();
  c.fillStyle='#c89a3a';c.beginPath();c.arc(px,py,4.5,0,TAU);c.fill();rpw3aO(c,1.6);
  if(u<.06&&!lite){c.globalCompositeOperation='lighter';c.globalAlpha=.6*(1-u/.06);rpw3aBl(c,rpwGlow('255,170,60',26),h.x-42,h.y-62);c.globalCompositeOperation='source-over';c.globalAlpha=1}}
 /* the piston engine: flywheel, crank, connecting rod, puffs from the stack (a poke runs it fast and whistles) */
 if(B.eng){const e=B.eng,age=rpw3aAge(R,B.hot.find(q=>q.k==='engine')),sp=2.2*(1+(age<4?4*Math.exp(-age*.7):0))*(R.rm?.3:1);if(e.R!==R){e.R=R;e.a=0}e.a+=dt*sp;
  const cx=e.x+30,cy=e.y-44,pin=[cx+Math.cos(e.a)*14,cy+Math.sin(e.a)*14],xh=e.x+2+Math.cos(e.a)*14;rpw3aSpinPut(c,rpw3aSpin('fly',rpw3aFlywheel(),TAU/6,18),cx,cy,e.a);
  c.strokeStyle=RPO;c.lineWidth=7;c.beginPath();c.moveTo(e.x-6,cy+7);c.lineTo(xh,cy+7);c.moveTo(xh,cy+7);c.lineTo(pin[0],pin[1]);c.stroke();c.strokeStyle='#c8c4d8';c.lineWidth=3.6;c.stroke();
  c.fillStyle='#c89a3a';c.beginPath();c.rect(xh-5,cy+2,10,10);c.fill();rpw3aO(c,1.6);
  if(!lite){const SM=rpw3aSmk(2,44,36,['rgba(255,255,255,.78)','rgba(240,240,250,.42)','rgba(240,240,250,0)'],10);for(let k=0;k<2;k++){const u=((e.a/Math.PI)+k*.5)%1;rpw3aFr(c,SM,u*10,e.x-36+u*10,e.y-80-u*40)}}}
 /* steam: valves and boilers, vents a monster is crossing, poked machines; smoke from the furnace stack */
 if(!lite){const ST=rpw3aSmk(2,44,36,['rgba(255,255,255,.78)','rgba(240,240,250,.42)','rgba(240,240,250,0)'],10),SM=rpw3aSmk(3,40,32,['rgba(70,60,66,.55)','rgba(70,60,66,.3)','rgba(70,60,66,0)'],10,1.6);
  for(let i=0;i<A.steam.length;i++){const [x,y]=A.steam[i];for(let k=0;k<2;k++){const u=(t*.5+k/2+i*.27)%1;rpw3aFr(c,ST,u*10,x+Math.sin(t+k+i)*4,y-u*46)}}
  for(let i=0;i<A.smoke.length;i++){const [x,y]=A.smoke[i];for(let k=0;k<3;k++){const u=(t*.25+k/3+i*.31)%1;rpw3aFr(c,SM,u*10,x+u*30,y-u*80)}}
  if(!(S.vk=(S.vk||0)+1)||S.vk%3===0)for(const v of B.vst){if(v.R!==R){v.R=R;v.at=-99}if(t-v.at<1.6)continue;for(const e of R.foes){if(e.dead||e.air)continue;const q=rpPos(R,e);if(Math.abs(q.x-v.x)<38&&Math.abs(q.y-v.y)<26){v.at=t;break}}}
  for(const v of B.vst){const age=t-v.at;if(v.R!==R||age>1.6||age<0)continue;for(let k=0;k<4;k++){const u=(age-k*.12)/1.3;if(u<0||u>=1)continue;rpw3aFr(c,ST,u*10,v.x+(k-1.5)*12+Math.sin(k*2.3)*6,v.y-6-u*70)}}
  for(const h of B.hot){if(!RPW3A_STEAMK[h.k])continue;const age=rpw3aAge(R,h);if(age>2.2)continue;for(let k=0;k<4;k++){const u=(age-k*.15)/1.6;if(u<0||u>=1)continue;rpw3aFr(c,ST,u*10,h.x+(k%2?10:-10)*u,h.y-h.ry*.6-u*60)}}}
 /* poked furnace and forge: a burst of flame light */
 for(const h of B.hot){if(h.k!=='blast'&&h.k!=='forge'&&h.k!=='pool')continue;const age=rpw3aAge(R,h);if(age>1.2)continue;c.globalCompositeOperation='lighter';c.globalAlpha=(1-age/1.2)*.8;rpw3aBl(c,rpwGlow('255,140,40',50),h.x-50,h.y+(h.k==='blast'?50:0)-50);c.globalCompositeOperation='source-over';c.globalAlpha=1}
 /* the blinking lamps on the factory gate */
 for(const e of B.G.ent){const x=Math.max(30,e.x-14),y=e.y+24,pa=rpw3aAge(R,B.hot.find(h=>h.k==='portal')),on=Math.sin(t*(pa<2?20:5))>0,gl=rpwGlow('255,150,40',18);c.globalCompositeOperation='lighter';for(const dx of[-68,44]){c.globalAlpha=(dx<0)===on?.75:.15;rpw3aBl(c,gl,x+dx-18,y-107)}c.globalCompositeOperation='source-over';c.globalAlpha=1}
 c.restore();rpw3aCastleLive(c,'foundry',B.cast.x,B.cast.y,t,lite)}
RPW3A.react.foundry=(R,h,x,y)=>{const k=h&&h.k,P=(n,c,o)=>rpw3aPt(R,h?h.x:x,h?h.y:y,n,c,o);
 if(k==='crate'||k==='barrel'||k==='coal'||k==='ingots'||k==='cart'||k==='gears'||k==='tanks'){rpw3aSnd('thunk');P(6,['#8a7a6a','#5a5048','#c8b89a'],{k:'dust',v:60,up:1,s:4,g:60,l:.9})}
 else if(k==='anvil'||k==='hammer'){if(k==='anvil'){rpw3aSnd('clang');P(10,['#ffd27a','#ffb84a','#ffffff'],{v:160,up:1,s:3,g:300,l:.6})}}
 else if(RPW3A_STEAMK[k]){rpw3aSnd(k==='engine'||k==='boiler'?'whistle':'puff')}
 else if(k==='lamp'){rpw3aSnd('pop');P(4,['#ffe08a'],{k:'glow',v:30,s:3,g:-20,l:1})}
 else if(k==='forge'||k==='blast'||k==='pool'){rpw3aSnd('burn');P(12,['#ffd27a','#ff8a2a','#fff4b0'],{v:120,up:1,s:3,g:120,l:1,jx:30})}
 else if(k==='lever'){rpw3aSnd('lever');P(5,['#ffd27a','#ffffff'],{v:90,up:1,s:2.6,g:200,l:.5})}
 else if(k==='gear'){rpw3aSnd('creak')}else if(k==='portal'){rpw3aSnd('clang')}else if(k==='castle'){rpw3aSnd('bell');P(8,['#ffe46a','#ffffff'],{v:120,up:1,s:6,g:40,l:1.2})}
 else P(5,['#ffd27a','#ffb84a'],{v:90,up:1,s:2.4,g:260,l:.5})};
RPW.amb.foundry=rpw3aAmbFoundry;

/* ======================================================================================================================
   Storm Citadel
   ====================================================================================================================== */
/* a rain splash (6 frames) and a puddle ripple ring (8 frames) */
function rpw3aSplash(){return rpw3aStrip('splash',16,12,6,8,9,(g,i)=>{const u=i/5;g.strokeStyle='rgba(210,230,255,'+(.85*(1-u*.8))+')';g.lineWidth=1.1;g.beginPath();g.ellipse(0,0,2+u*6,(2+u*6)*.38,0,0,TAU);g.stroke();
 if(i<4){g.fillStyle='rgba(220,238,255,.85)';for(const s of[-1,0,1]){const x=s*(1.5+u*5),y=-2-Math.sin(Math.min(1,u*1.6)*Math.PI)*5+(s?1:-1);g.beginPath();g.arc(x,y,.9,0,TAU);g.fill()}}})}
function rpw3aRipple(w){return rpw3aStrip('rip'+w,w*2+4,Math.ceil(w*.8)+4,8,w+2,Math.ceil(w*.4)+2,(g,i)=>{const u=(i+1)/8;g.strokeStyle='rgba(200,225,255,'+(.7*(1-u))+')';g.lineWidth=1.2;g.beginPath();g.ellipse(0,0,w*u,w*u*.38,0,0,TAU);g.stroke()})}
/* a storm banner's cloth flapping: 12 frames over one wave, amp 0 calm / 1 wild (anchor at the top of the pole) */
function rpw3aFlag(w){const amp=w?7:2.8;return rpw3aStrip('flag'+w,34,40,12,2,6,(g,i)=>{const ph=i/12*TAU,y=u=>Math.sin(ph-u*2.6)*amp*u,T=[],Bm=[];for(let k=0;k<=6;k++){const u=k/6;T.push([u*22,u*2+y(u)]);Bm.push([u*21,(k===6?20:28-(k>=5?(k-4)*4:0))+y(u)])}
 g.beginPath();g.moveTo(0,0);for(const p of T)g.lineTo(p[0],p[1]);g.lineTo(Bm[6][0],Bm[6][1]);g.lineTo(16,22+y(.75)*.8);for(let k=5;k>=0;k--)g.lineTo(Bm[k][0],Bm[k][1]);g.closePath();
 g.fillStyle='#3a4ac8';g.fill();g.save();g.clip();const q=g.createLinearGradient(0,0,23,0);for(let k=0;k<=8;k++){const u=k/8,c=Math.cos(ph-u*2.6);q.addColorStop(u,c>0?'rgba(18,8,31,'+(c*.32).toFixed(3)+')':'rgba(160,190,255,'+(-c*.22).toFixed(3)+')')}g.fillStyle=q;g.fillRect(-2,-6,28,44);g.fillStyle='rgba(255,255,255,.12)';g.fillRect(0,0,24,5);g.restore();g.strokeStyle=RPO;g.lineWidth=1.8;g.stroke();
 const dx=12,dy=6+y(.55);g.fillStyle='#ffe46a';g.beginPath();g.moveTo(dx+2,dy);g.lineTo(dx-4,dy+9);g.lineTo(dx,dy+9);g.lineTo(dx-2,dy+17);g.lineTo(dx+5,dy+6);g.lineTo(dx+1,dy+6);g.closePath();g.fill();g.strokeStyle='rgba(18,8,31,.6)';g.lineWidth=.8;g.stroke()})}
const RPW3A_CROW=['#3a3a56','#6a6a8a','#262638'];
function rpw3aStormX(B,map){const G=B.G,M=B.M;
 B.flags=B.trees.filter(it=>it.k==='banner').map(it=>({x:it.x+1,y:it.y-58,i:it.i}));
 /* splash spots on the ground (not on the void) */
 B.spl=[];for(let i=0;i<600&&B.spl.length<90;i++){const x=rpw3aR(i+7000)*1600,y=130+rpw3aR(i+7100)*690;if(M.at(x,y)>4)B.spl.push([x|0,y|0])}
 /* crows wheel over the two spires furthest apart (or the castle) */
 const sp=B.spires.slice(0,2);B.crows=(sp.length?sp:[{x:B.cast.x+170,y:B.cast.y+200}]).map((s,j)=>({x:s.x,y:Math.max(90,s.y-170),rx:70+j*16,ry:22,n:4,ph:j*2.1,at:-99}));
 /* hotspots */
 const H=[];(map.rods||[]).forEach((r,i)=>H.push({k:'rod',x:r[0],y:r[1]-40,r:26,ry:52,i}));for(const s of B.spires)H.push({k:'spire',x:s.x,y:s.y-80,r:30,ry:80,o:s});
 const K={crys:[0,-16,18,20],vcrys:[0,-14,18,18],brazier:[0,-16,14,18],banner:[10,-46,20,26],dead:[0,-30,22,30],pillar:[0,-26,14,28],boulder:[0,-12,22,14]};
 for(const it of B.trees){const k=K[it.k];if(k)H.push({k:it.k,x:it.x+k[0],y:it.y+k[1],r:k[2],ry:k[3],o:it})}for(const p of B.pud)H.push({k:'pud',x:p[0],y:p[1],r:p[2]*1.6,ry:p[2]*.8,o:p});
 for(const c of B.crows)H.push({k:'crows',x:c.x,y:c.y,r:c.rx+20,ry:40,o:c});H.push({k:'castle',x:B.cast.x+170,y:B.cast.y+300,r:110,ry:170});for(const e of G.ent)H.push({k:'gate',x:Math.max(30,e.x-14),y:e.y-40,r:70,ry:70});
 B.hot=H;rpw3aSplash();rpw3aRipple(14);rpw3aRipple(24);rpw3aBird('crow',RPW3A_CROW);rpw3aBird('crow',RPW3A_CROW,1);rpwGlow('150,200,255',230);rpw3aFlag(0);rpw3aFlag(1)}
{const b0=RPW.bake.storm;RPW.bake.storm=map=>{const B=b0(map);try{rpw3aStormX(B,map)}catch(e){console.error(e)}return B}}
/* live: storm clouds and lightning in the void (patched back by B.isl), cloud shadows, puddle ripples and rain splashes, crackling
   spires, flapping banners, braziers, crows, poke reactions, the light of a strike on the wet stone */
function rpw3aAmbStorm(c,R){const B=R.bake,t=R.t,lite=R.lite||R.rm,S=rpw3aTick(R);c.save();
 const PF=rpw3aPuff(7,260,90,['rgba(70,82,124,.8)','rgba(50,60,96,.5)','rgba(40,48,80,0)']),pat=[];
 for(let i=0;i<B.clouds.length;i+=lite?2:1){if(i===4&&!lite)continue;const k=B.clouds[i],x=Math.round(((k.x0+t*k.v)%(1600+PF.w))-PF.w),y=Math.round(k.y-PF.h/2);c.drawImage(PF.c,x,y);pat.push([x,y,PF.w,PF.h])}
 {const ph=t%5.3,k=Math.floor(t/5.3);if(ph<.35&&!R.rm){const x=200+rpw3aR(k+11)*1200,y=120+rpw3aR(k+12)*640,a=(ph<.08||ph>.16&&ph<.22)?1:.35;c.globalCompositeOperation='lighter';c.globalAlpha=.45*a;c.drawImage(rpwGlow('140,190,255',90),Math.round(x-160),Math.round(y-100),320,200);
   c.strokeStyle='#cfe8ff';c.lineWidth=2;c.globalAlpha=.6*a;c.beginPath();let px=x-30,py=y-80;c.moveTo(px,py);for(let j=0;j<6;j++){px+=(rpw3aR(k*9+j)-.4)*30;py+=26;c.lineTo(px,py)}c.stroke();c.globalCompositeOperation='source-over';c.globalAlpha=1;pat.push([x-160,y-100,320,200])}}
 rpw3aPatch(c,B,pat);
 /* shadows of the storm clouds drifting over the citadel */
 if(!lite){const SH=rpw3aPuff(8,360,170,['rgba(6,8,20,.34)','rgba(6,8,20,.2)','rgba(6,8,20,0)']);for(let i=0;i<2;i++){const x=((t*(16+i*5)+i*900)%2100)-250,y=260+i*300+Math.sin(t*.1+i)*30;rpw3aBl(c,SH.c,x-SH.ax,y-SH.ay)}}
 /* rain rings in the puddles and splashes on the stone */
 if(!R.rm){const RP=[rpw3aRipple(14),rpw3aRipple(24)];for(let i=lite?1:0;i<B.pud.length;i+=lite?3:1){const [x,y,r]=B.pud[i];for(let k=0;k<(lite||r<=16?1:2);k++){const u=(t*1.1+i*.37+k*.5)%1;rpw3aFr(c,RP[r>16?1:0],u*8,x+(k?r*.4:-r*.3),y+(k?1:-1))}}
  const SP=rpw3aSplash(),n=lite?10:26;for(let i=0;i<n;i++){const v=t*2.4+i*.618,cy=Math.floor(v),u=v-cy,p=B.spl[(cy*37+i*13)%B.spl.length];rpw3aFr(c,SP,u*6,p[0],p[1])}}
 /* crackling arcs between the spires (a poked spire throws an arc to where you clicked) */
 c.globalCompositeOperation='lighter';const SPI=B.spires,sg=rpwGlow('140,210,255',30);
 for(let i=0;i<SPI.length;i++){const a=SPI[i],ax=a.x,ay=a.y-136;c.globalAlpha=.5+.25*Math.sin(t*9+i);rpw3aBl(c,sg,ax-30,ay-30);if(lite)continue;
  const h=B.hot.find(q=>q.o===a),pa=rpw3aAge(R,h),pk=S.poke,toPk=pa<.6&&pk;
  const b=SPI[(i+1)%SPI.length],near=SPI.length>1&&Math.hypot(b.x-a.x,b.y-a.y)<520,on=toPk||(t*1.7+i*.53)%1<.7;if(!on)continue;const k=Math.floor(t*14+i*7),bx=toPk?pk[0]:near?b.x:a.x+(rpw3aR(k)-.5)*90,by=toPk?pk[1]:near?b.y-136:a.y-60-rpw3aR(k+1)*40;
  c.strokeStyle='rgba(150,210,255,.35)';c.lineWidth=6;c.beginPath();let px=ax,py=ay;c.moveTo(px,py);const n=near||toPk?9:5,pts=[];for(let j=1;j<=n;j++){const u=j/n;px=ax+(bx-ax)*u+(j<n?(rpw3aR(k*13+j)-.5)*34:0);py=ay+(by-ay)*u-(near&&!toPk?Math.sin(u*Math.PI)*30:0)+(j<n?(rpw3aR(k*7+j)-.5)*22:0);pts.push([px,py]);c.lineTo(px,py)}c.stroke();
  c.strokeStyle='#e8f8ff';c.lineWidth=1.8;c.beginPath();c.moveTo(ax,ay);for(const p of pts)c.lineTo(p[0],p[1]);c.stroke()}
 /* blue braziers and lamps (a poked brazier flares up) */
 {const bg=rpwGlow('90,170,255',16),lg=rpwGlow('255,190,100',13);for(let i=0;i<B.fl.length;i++){const [x,y,w]=B.fl[i],f=.85+.15*Math.sin(t*13+i*3)+.08*Math.sin(t*29+i);if(w){if(lite||i%2)continue;c.globalAlpha=.45+.1*Math.sin(t*7+i);rpw3aBl(c,lg,x-13,y-13);continue}
  const h=B.hot.find(q=>q.k==='brazier'&&Math.abs(q.x-x)<2&&Math.abs(q.y-y+10)<4),pa=rpw3aAge(R,h),fl=pa<1.5?1+1.2*(1-pa/1.5):1;c.globalAlpha=Math.min(1,.5*fl);rpw3aBl(c,bg,x-16,y-24);c.globalAlpha=1;c.fillStyle='#5ab8ff';c.beginPath();c.ellipse(x,y-6*f*fl,5*Math.min(1.4,fl),9*f*fl,0,0,TAU);c.fill();c.fillStyle='#e8f8ff';c.beginPath();c.ellipse(x,y-4*f*fl,2.4,4.6*f*fl,0,0,TAU);c.fill()}}
 /* a poked crystal glows and rings */
 for(const h of B.hot){if(h.k!=='crys'&&h.k!=='vcrys'&&h.k!=='rod')continue;const pa=rpw3aAge(R,h);if(pa>1.4)continue;c.globalAlpha=(1-pa/1.4)*.9;rpw3aBl(c,rpwGlow(h.k==='vcrys'?'200,160,255':'150,220,255',34),h.x-34,h.y-34)}
 /* the light of a strike: a big cold glow round the bolt, glints in the puddles near it, the stone lit up */
 for(const b of R.bolts||[])if(!S.seen.has(b)){S.seen.add(b);S.strike=[b.x,b.y,t]}
 if(S.strike&&t-S.strike[2]<.8&&t>=S.strike[2]){const u=(t-S.strike[2])/.8,a=(1-u)*(1-u),[sx,sy]=S.strike;c.globalAlpha=.6*a;rpw3aBl(c,rpwGlow('150,200,255',230),sx-230,sy-230);
  if(!lite){const pg=rpwGlow('220,240,255',22);for(const p of B.pud){const d=Math.hypot(p[0]-sx,p[1]-sy);if(d>520)continue;c.globalAlpha=a*(1-d/520);rpw3aBl(c,pg,p[0]-22,p[1]-22)}}}
 c.globalCompositeOperation='source-over';c.globalAlpha=1;
 /* banners flap in the wind (12 frames; faster and wilder after a poke) */
 for(const f of B.flags){if(!f.h)f.h=B.hot.find(q=>q.o&&q.o.i===f.i&&q.k==='banner')||{};const pa=rpw3aAge(R,f.h),hard=pa<2;rpw3aFr(c,rpw3aFlag(hard?1:0),(t*(hard?2.2:1.1)+f.i*.37)*12,f.x,f.y)}
 /* crows wheel over the spires; a poke scatters them and they come back */
 if(!R.rm){const CR=rpw3aBird('crow',RPW3A_CROW),CL=rpw3aBird('crow',RPW3A_CROW,1);for(const cw of B.crows){const h=B.hot.find(q=>q.o===cw),pa=rpw3aAge(R,h),sc=pa<7?Math.sin(Math.min(1,pa/7)*Math.PI):0;
  for(let i=0;i<(lite?2:cw.n);i++){const a=t*.7+i/cw.n*TAU+cw.ph,dir=Math.cos(a+Math.PI/2)>0,ex=1+sc*(2.6+i*.5),x=cw.x+Math.cos(a)*cw.rx*ex,y=cw.y+Math.sin(a)*cw.ry*ex-sc*(60+i*20)+Math.sin(t*2+i)*4;rpw3aFr(c,dir?CR:CL,2+((t*(sc?18:10)+i*1.3)|0)%6,x,y)}}}
 /* a poke on bare stone: a little splash */
 {const pk=S.poke;if(pk&&!pk[3]&&t-pk[2]<.6){rpw3aFr(c,rpw3aRipple(24),(t-pk[2])/.6*8,pk[0],pk[1]);rpw3aFr(c,rpw3aSplash(),(t-pk[2])/.6*6,pk[0],pk[1])}}
 c.restore();rpw3aCastleLive(c,'storm',B.cast.x,B.cast.y,t,lite)}
RPW3A.react.storm=(R,h,x,y)=>{const k=h&&h.k,P=(n,c,o)=>rpw3aPt(R,h?h.x:x,h?h.y:y,n,c,o);
 if(k==='rod'){rpw3aSnd('zap');rpw3aPt(R,h.x,h.y-30,10,['#e8f8ff','#9ae8ff','#ffffff'],{v:160,s:3,g:120,l:.6});const i=h.i;if(R.rodK&&R.rodK.length>i){const o=R._w3rodK||(R._w3rodK={});o[i]=R.t}}
 else if(k==='spire'){rpw3aSnd('zap');P(6,['#e8f8ff','#9ae8ff'],{v:120,s:3,g:60,l:.6})}
 else if(k==='crys'||k==='vcrys'){rpw3aSnd('chime');P(8,k==='crys'?['#e8fbff','#9ae8ff']:['#f4e8ff','#c8a8ff'],{k:'glow',v:60,s:3,g:-30,l:1.2})}
 else if(k==='brazier'){rpw3aSnd('burn');P(8,['#9ae8ff','#5ab8ff','#ffffff'],{v:90,up:1,s:3,g:-40,l:.9})}
 else if(k==='banner'){rpw3aSnd('flap')}else if(k==='crows'||k==='dead'){rpw3aSnd('flap');if(k==='dead'){const cw=R.bake.crows.reduce((a,b)=>Math.hypot(b.x-h.x,b.y-h.y)<Math.hypot(a.x-h.x,a.y-h.y)?b:a);const hh=R.bake.hot.find(q=>q.o===cw);if(hh){hh.R=R;hh.at=R.t}}}
 else if(k==='pud'){rpw3aSnd('splash');P(8,['#c8e0ff','#ffffff'],{k:'dust',v:90,up:1,s:2.4,g:300,l:.7})}
 else if(k==='castle'){rpw3aSnd('bell');P(8,['#9ae8ff','#ffffff'],{v:120,up:1,s:6,g:40,l:1.2})}else if(k==='gate'){rpw3aSnd('zap')}
 else if(k==='pillar'||k==='boulder'){rpw3aSnd('thunk');P(5,['#6a7494','#9aa8c8'],{k:'dust',v:60,up:1,s:3,g:200,l:.7})}
 else rpw3aSnd('splash')};
RPW.amb.storm=rpw3aAmbStorm;

/* above everything: the rod masts (a poked rod crackles), two layers of rain, the bolts and the flash */
function rpw3aTopStorm(c,R){const B=R.bake,t=R.t,lite=R.lite||R.rm,m=R.map,RS=rpw3aRodSpr(),rg=rpwGlow('140,210,255',30),rg2=rpwGlow('160,220,255',60),pk=R._w3rodK||{};
 (m.rods||[]).forEach((r,i)=>{const pa=pk[i]!=null&&R.t>=pk[i]?R.t-pk[i]:99,k=Math.max(R.rodK?R.rodK[i]||0:0,pa<.8?1-pa/.8:0);rpw3aBl(c,RS.c,r[0]-RS.ax,r[1]+2-RS.ay);c.globalCompositeOperation='lighter';
  c.globalAlpha=Math.min(1,.35+.15*Math.sin(t*4+i)+k*.65);rpw3aBl(c,rg,r[0]-30,r[1]-100);
  if(k>0){c.globalAlpha=k;c.drawImage(rg2,Math.round(r[0]-120),Math.round(r[1]-60),240,120);c.strokeStyle='#e8f8ff';c.lineWidth=1.6;c.beginPath();const s=Math.floor(t*20);for(let j=0;j<3;j++){let px=r[0],py=r[1]-70;c.moveTo(px,py);for(let q=0;q<4;q++){px=r[0]+(rpw3aR(s+j*5+q)-.5)*18;py+=16;c.lineTo(px,py)}}c.stroke()}
  c.globalCompositeOperation='source-over';c.globalAlpha=1});
 /* rain: a far layer (short, faint) and a near one (long, brighter), slanted by the wind */
 if(!R.rm){const n=lite?30:80;c.lineWidth=1;c.strokeStyle='rgba(170,200,255,.28)';c.beginPath();for(let i=0;i<n;i+=2){const d=B.rain[i],x=((d[0]+t*110*d[2])%1700)-50,y=((d[1]+t*700*d[2])%960)-30;c.moveTo(x,y);c.lineTo(x-3*d[2],y-12*d[2])}c.stroke();
  c.lineWidth=1.5;c.strokeStyle='rgba(200,225,255,.45)';c.beginPath();for(let i=1;i<n;i+=2){const d=B.rain[i],x=((d[0]+t*160*d[2])%1700)-50,y=((d[1]+t*1050*d[2])%960)-30;c.moveTo(x,y);c.lineTo(x-5*d[2],y-24*d[2])}c.stroke()}
 /* bolts: a jagged main stroke from the clouds with forks, a glow and sparks where it lands */
 for(const b of R.bolts||[]){const u=b.t/b.d,a=u<.15?1:Math.max(0,1-(u-.15)/.85),k=Math.floor(b.x*3+b.y*7)+Math.floor(t*18),x1=b.x,y1=b.y,x0=x1+(rpw3aR(k%97+3)-.5)*160,y0=-20;
  const pts=[[x0,y0]];const n=9;for(let j=1;j<n;j++){const v=j/n;pts.push([x0+(x1-x0)*v+(rpw3aR(k+j*3)-.5)*46*(1-v*.6),y0+(y1-y0)*v])}pts.push([x1,y1]);
  c.save();c.globalCompositeOperation='lighter';c.lineJoin='round';c.lineCap='round';
  const line=(P)=>{c.beginPath();c.moveTo(P[0][0],P[0][1]);for(let j=1;j<P.length;j++)c.lineTo(P[j][0],P[j][1])};
  const forks=[];for(let f=0;f<(lite?1:3);f++){const j=2+((rpw3aR(k+f*11)*(n-3))|0),p=pts[j],P=[p];let px=p[0],py=p[1];for(let q=0;q<3;q++){px+=(rpw3aR(k+f*7+q)-.5)*50+(f%2?16:-16);py+=22+rpw3aR(k+q)*14;P.push([px,py])}forks.push(P)}
  for(const [w,col,al,f] of[[12,'rgba(110,170,255,.32)',.8,0],[5.5,'rgba(170,215,255,.85)',1,1],[2.4,'#ffffff',1,1]]){c.globalAlpha=a*al;c.strokeStyle=col;c.lineWidth=w;line(pts);c.stroke();if(f){c.lineWidth=w*.6;for(const P of forks){line(P);c.stroke()}}}
  c.globalAlpha=a;rpw3aBl(c,rpwGlow('170,215,255',56),x1-56,y1-56);c.globalAlpha=a*.8;rpw3aBl(c,rpwGlow('255,255,255',20),x1-20,y1-20);
  if(u<.6){c.strokeStyle='#e8f8ff';c.lineWidth=1.6;c.beginPath();for(let s=0;s<8;s++){const an=-Math.PI*(.1+rpw3aR(s+k%13)*.8),v=20+u*90*rpw3aR(s+3),px=x1+Math.cos(an)*v,py=y1+Math.sin(an)*v*.6+u*u*60;c.moveTo(px,py);c.lineTo(px-Math.cos(an)*5,py-Math.sin(an)*5)}c.stroke()}
  c.globalAlpha=(1-u)*.9;c.strokeStyle='#cfe8ff';c.lineWidth=3*(1-u);c.beginPath();c.ellipse(x1,y1+8,14+u*60,(14+u*60)*.4,0,0,TAU);c.stroke();c.restore()}
 /* the flash: everything lights up for a moment; sheet lightning far away now and then */
 if(R.flash>0){c.save();c.globalAlpha=Math.min(1,R.flash)*(R.rm?.1:.2);c.fillStyle='#e4eeff';c.fillRect(0,0,1600,900);c.restore()}
 else if(!R.rm){const ph=t%7.7;if(ph<.18){c.save();c.globalAlpha=(ph<.06||ph>.11&&ph<.15)?.08:.03;c.fillStyle='#c8d8ff';c.fillRect(0,0,1600,900);c.restore()}}}
RPW.ambTop.storm=rpw3aTopStorm;

/* ======================================================================================================================
   The world painting's live layer (RPW.world[3].anim): windmills and gears, chimney smoke, airships on the routes, plus (10.1)
   waterfalls off the meadow islands, hot-air balloons, drifting clouds, a flock of birds, embers over the foundry, rain, lightning
   that lights the storm clouds and twinkling crystals. Everything is a blit on whole pixels or a short path.
   ====================================================================================================================== */
function rpw3aWorldLive(g,t){const W=RPW3A_W;if(!W)return;g.save();
 if(!W.x3){const isl=[[150,498,96],[468,500,104],[196,622,120],[408,628,110]];W.x3={falls:isl.map(([x,y,L],i)=>({x,y,L,F:rpw3aStrip('wfall'+i,30,L,12,15,0,(h,f)=>{const P=40,off=f/12*P;h.lineCap='round';
   let q=h.createLinearGradient(0,0,0,L);q.addColorStop(0,'rgba(150,215,255,.9)');q.addColorStop(1,'rgba(220,240,255,0)');h.fillStyle=q;h.beginPath();h.moveTo(-6,0);h.lineTo(6,0);h.lineTo(9,L);h.lineTo(-9,L);h.closePath();h.fill();
   for(let k=-1;k<L/P+1;k++)for(let j=0;j<4;j++){const x=-5+j*3.4,y=off+k*P+rpw3aR(j*3+k*5+i)*P,l=8+rpw3aR(j+k*9)*12,a=Math.max(0,1-y/L);if(a<=0)continue;h.globalAlpha=a;h.strokeStyle=j%2?'#ffffff':'#d8f4ff';h.lineWidth=1.6;h.beginPath();h.moveTo(x,y);h.lineTo(x,y+l);h.stroke()}h.globalAlpha=1;
   h.fillStyle='#2a1e24';h.beginPath();h.ellipse(0,1,8,4,0,0,TAU);h.fill();h.strokeStyle=RPO;h.lineWidth=1.6;h.stroke();h.fillStyle='#7ac8f0';h.beginPath();h.ellipse(0,2,6,2.4,0,0,Math.PI);h.fill()})})),
   bal:[0,1].map(k=>{const B0=rpw3aBalloon(k,k?['#ff6a5a','#ffe46a','#3a8ae0']:['#9a6ae8','#ffffff','#ffd45a']),c=rpw3aCv(B0.w*.6,B0.h*.6);c.getContext('2d').drawImage(B0.c,0,0,c.width,c.height);return c}),
   crys:[[-110,-46],[100,-30],[-70,-8],[124,-6]].map(([dx,dy])=>[W.storm[0]+dx,W.storm[1]+dy]),rain:[...Array(46)].map((_,i)=>[rpw3aR(i+500),rpw3aR(i+540),.8+rpw3aR(i+580)*.5])}}
 const X=W.x3;
 /* waterfalls off the meadow islands */for(const f of X.falls)rpw3aFr(g,f.F,t*20,f.x,f.y);
 /* windmills and gears */
 for(const m of W.mills){if(m.gear){const n=Math.round(m.r/3),G=rpw3aGear('wg'+m.r,m.r,n,RPW3A_FP.brass);rpw3aSpinPut(g,rpw3aSpin('wg'+m.r,G,TAU/n,10),m.x,m.y,t*(m.r>20?.5:-.8))}else rpw3aSpinPut(g,rpw3aBladeSpin(.55),m.x,m.y,t*.8)}
 /* chimney smoke and steam; embers rising off the molten pool */
 {const SM=rpw3aSmk(4,40,32,['rgba(60,50,60,.6)','rgba(60,50,60,.3)','rgba(60,50,60,0)'],10,1.6);for(let i=0;i<W.smoke.length;i++){const [x,y]=W.smoke[i];for(let k=0;k<3;k++){const u=(t*.22+k/3+i*.3)%1;rpw3aFr(g,SM,u*10,x+u*24,y-u*70)}}
  g.fillStyle='#ffd27a';g.beginPath();for(let k=0;k<8;k++){const u=(t*.35+k/8)%1,x=W.glow[0]+(rpw3aR(k)-.5)*60+Math.sin(t*2+k)*6,y=W.glow[1]-u*70;g.moveTo(x+1.6*(1-u)+.4,y);g.arc(x,y,1.6*(1-u)+.4,0,TAU)}g.globalAlpha=.85;g.fill();g.globalAlpha=1}
 /* hot-air balloons drifting up and down over the meadows */
 for(let i=0;i<2;i++){const c=X.bal[i],x=(i?560:60)+Math.sin(t*.07+i*2)*40,y=(i?250:300)+Math.sin(t*.19+i)*22;rpw3aBl(g,c,x,y)}
 /* airships along the routes */
 for(let i=0;i<W.routes.length;i++){const L=W.routes[i],u=((t*.05+i*.37)%1),p=L[Math.min(L.length-1,(u*L.length)|0)],S=rpw3aShip('wm'+i,.38,i===1?['#ffd45a','#c8402a','#8a2a1a','#ffffff']:['#ffffff','#3a8ae0','#2a5aa8','#ffd45a']);rpw3aBl(g,S.c,p[0]-S.ax,p[1]-S.ay-14+Math.sin(t*1.4+i)*3)}
 /* a flock of birds crosses now and then */
 {const u=(t/26)%1;if(u<.55){const V=rpw3aVee(0,'#2a1e3e'),x=-60+u/.55*1300,y=200+Math.sin(u*7)*30;for(let k=0;k<5;k++)rpw3aFr(g,V,t*9+k*1.7,x-(k%2?1:-1)*k*14-k*10,y+k*9)}}
 /* rain round the storm peak, lightning that lights the clouds, twinkling crystals */
 {const [sx,sy]=W.storm;g.strokeStyle='rgba(170,200,255,.4)';g.lineWidth=1.2;g.beginPath();for(const d of X.rain){const x=sx-230+((d[0]*460+t*40*d[2])%460),y=sy-60+((d[1]*360+t*300*d[2])%360);g.moveTo(x,y);g.lineTo(x-3,y-14*d[2])}g.stroke()}
 g.globalCompositeOperation='lighter';g.globalAlpha=.25+.12*Math.sin(t*2.2);rpw3aBl(g,rpw3aGlowE('255,120,30',70,.57),W.glow[0]-70,W.glow[1]-40);
 if(W.bolt){const ph=t%3.1,k=Math.floor(t/3.1);if(ph<.3){const [x,y]=W.bolt,bx=x+(rpw3aR(k)-.5)*240,a=ph<.1||ph>.18&&ph<.24?1:.3;g.globalAlpha=.5*a;rpw3aBl(g,rpw3aGlowE('150,200,255',120,.9),bx-120,y-200);
   g.globalAlpha=.3*a;rpw3aBl(g,rpw3aGlowE('150,200,255',200,.7),x-200,y-80);
   g.strokeStyle='#e8f8ff';g.lineWidth=2.4;g.globalAlpha=a;g.beginPath();let px=bx+(rpw3aR(k+3)-.5)*40,py=y-190;g.moveTo(px,py);for(let j=0;j<7;j++){px+=(rpw3aR(k*7+j)-.5)*30;py+=26;g.lineTo(px,py)}g.stroke()}}
 g.fillStyle='#ffffff';g.beginPath();for(let i=0;i<X.crys.length;i++){const [x,y]=X.crys[i],u=(t*.6+i*.29)%1,s=Math.max(0,Math.sin(u*Math.PI*2))*4;if(s<.5)continue;g.moveTo(x,y-s*1.6);g.lineTo(x+s*.35,y-s*.35);g.lineTo(x+s*1.6,y);g.lineTo(x+s*.35,y+s*.35);g.lineTo(x,y+s*1.6);g.lineTo(x-s*.35,y+s*.35);g.lineTo(x-s*1.6,y);g.lineTo(x-s*.35,y-s*.35);g.closePath()}g.globalAlpha=.9;g.fill();
 g.globalCompositeOperation='source-over';g.globalAlpha=1;
 /* soft clouds drifting in front, low over the sea of clouds */
 {const PF=rpw3aPuff(12,200,70,['rgba(255,220,200,.5)','rgba(255,200,190,.3)','rgba(255,200,190,0)']);for(let i=0;i<3;i++){const x=((t*(6+i*3)+i*700)%1900)-250,y=[690,170,720][i];rpw3aBl(g,PF.c,x,y)}}
 for(const it of W.cast){g.save();g.translate(it.x0,it.y0);g.scale(W.scale,W.scale);rpw3aCastleLive(g,it.id,0,0,t,1);g.restore()}
 g.restore()}
