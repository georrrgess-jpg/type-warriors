/* ===== 9.5 THE CROOKED CUE: the hub, redone (96t) =====
   The same tavern as the approved concept art, rebuilt around one decision: who to play and for how much.
   - Header: a progress pill under the sign (regulars beaten, paid matches today), gold, and your pool net and streak.
   - Rail: four tiles with baked icons and live data (Trick Shots stars and bounty, Cue Rack collection and NEW items,
     The Regulars record and trophies, How to Play). Granny's table opens Trick Shots too.
   - Chalkboard ladder: rank, portrait, title and stake range, difficulty, status, signature-cue pips; the footer names
     the next prize and shows the seven regulars as a rack of balls.
   - Spotlight: the regular on a lamp-lit stage with their line in a bubble, race / pays / your record, the house rule
     and a tip, scouting meters, poker-chip stakes, the payout (it rolls to the new number) and the cue they give.
   - Rack 'em up! carries stake and pay; Practice (against the selected regular) sits beside it.
   - Regulars you have beaten drink at the bar. Every screen change fades out and builds in.
   Keys: up/down or 1-7 pick, N next up, left/right stake, Enter play, P practice, T C R H screens, Esc back. */
const PZ_SHORT={gloop:'Gloop',moldwick:'Moldwick',grizzle:'Grizzle',vesper:'Vesper',barnacle:'Barnacle',hootsworth:'Hootsworth',mortimer:'Mortimer',shade:'Shade'};
const pzShort=k=>PZ_SHORT[k]||(PZ_REG[k]?PZ_REG[k].n:k);
function pzVs(){const Z=PZS();if(!Z.vs||typeof Z.vs!=='object'||Array.isArray(Z.vs))Z.vs={};return Z.vs}
{const f0=pzMatchEnd;pzMatchEnd=function(){try{const M=PZ.M;if(M&&!M.practice&&M.over){const v=pzVs(),k=M.opp;v[k]=v[k]||[0,0];v[k][M.over.winner===0?0:1]++}}catch(e){}return f0.apply(this,arguments)}}
/* what you own, and whether anything is new since you last opened the Cue Rack */
function pzOwnCount(){const Z=PZS();let n=0,t=0,nw=0;const seen=Z.seen||{};for(const [list,own] of[[PZ_CUES,Z.cues],[PZ_FELT,Z.felts],[PZ_BALLS,Z.ballsets]])for(const x of list){t++;if(own[x.id]){n++;if(!seen[x.id]&&x.price!==0&&x.how!=='Free')nw++}}return {n,t,nw}}
function pzMarkSeen(){const Z=PZS();Z.seen=Z.seen||{};for(const [list,own] of[[PZ_CUES,Z.cues],[PZ_FELT,Z.felts],[PZ_BALLS,Z.ballsets]])for(const x of list)if(own[x.id])Z.seen[x.id]=1;save()}
{const f0=pzCueRack;pzCueRack=function(){const r=f0.apply(this,arguments);try{pzMarkSeen()}catch(e){}return r}}
/* the pool trophies (the game's achievement list, the ones that start with pz) */
function pzTrophies(){try{return ACH.filter(a=>/^pz/.test(a.id))}catch(e){return []}}
/* what a regular still gives you: their felt (one win) and their cue (three wins) */
function pzPrizeOf(id){const Z=PZS(),out=[];if(id==='shade'){const c=PZ_CUES.find(x=>x.beatShade);if(c&&!Z.cues[c.id])out.push({t:'cue',it:c,need:3-(Z.shade.beat||0)});return out}
 const f=PZ_FELT.find(x=>x.beat===id);if(f&&!Z.felts[f.id])out.push({t:'felt',it:f,need:1});const c=PZ_CUES.find(x=>x.beat===id);if(c&&!Z.cues[c.id])out.push({t:'cue',it:c,need:Math.max(1,3-(Z.beat[id]||0))});return out}
function pzNextPrize(){const ids=[PZ.sel,...PZ_ORDER.filter(k=>pzOpen(k))];for(const id of ids){if(!id||(id!=='shade'&&!pzOpen(id)))continue;const p=pzPrizeOf(id);if(p.length)return {id,...p[0]}}return null}
/* screen changes: the current pool screen fades away, then the next one builds itself in */
function pzGo(fn){const r=ov.querySelector(':scope>.pzh,:scope>.pzr,:scope>.pzk');if(!r||pzRM()){fn();return}if(r.classList.contains('pzgone'))return;r.classList.add('pzgone');setTimeout(()=>{if(r.isConnected)fn()},150)}
const PZ_CHIPC={50:'#e8e4f4',100:'#3a7af0',200:'#3ab06a',250:'#2a9a8a',300:'#e86a2a',500:'#d83a5a',1000:'#1a1a2a',2000:'#9a4ae8',3000:'#e8b02a',4000:'#2ab0b0',5000:'#c8a060'};
function pzChip(s,on,dis){const c=PZ_CHIPC[s]||'#6a5ab0',t=s===50?'#2a1a3a':s===1000?'#ffd45a':'#fff';return `<button class="pzchip2 ${on?'on':''}" data-s="${s}" ${dis?'disabled':''} style="--cc:${c};--ct:${t}" aria-label="Stake ${s}"><i></i><b>${s>=1000?(s/1000)+'K':s}</b></button>`}
/* the lamp over the spotlight stage, baked once per colour */
const PZ_STAGE={};
function pzStageBake(col){if(PZ_STAGE[col])return PZ_STAGE[col];const c=pzCv(300,424),g=c.getContext('2d');
 g.fillStyle=pzLin(g,0,0,0,424,[[0,'#1a1046'],[1,'#0a0620']]);g.fillRect(0,0,300,424);
 const q=g.createRadialGradient(150,380,10,150,380,170);q.addColorStop(0,pzRgba(col).replace(',1)',',.32)'));q.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=q;g.fillRect(0,200,300,224);
 g.save();g.globalCompositeOperation='lighter';const cone=g.createLinearGradient(0,0,0,400);cone.addColorStop(0,'rgba(255,236,170,.30)');cone.addColorStop(1,'rgba(255,236,170,0)');g.fillStyle=cone;g.beginPath();g.moveTo(118,0);g.lineTo(182,0);g.lineTo(290,400);g.lineTo(10,400);g.closePath();g.fill();g.restore();
 g.fillStyle='rgba(255,236,170,.10)';g.beginPath();g.ellipse(150,392,120,18,0,0,TAU);g.fill();
 g.fillStyle='#1d6a45';pzRR(g,112,-8,76,22,8);g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();g.fillStyle='#ffe9a0';g.beginPath();g.ellipse(150,14,24,6,0,0,TAU);g.fill();
 return PZ_STAGE[col]=c}
function pzHub(){const Z=PZS(),tokH=++PZ.tok;PZ.on=false;PZ.hub=true;CAS.on=true;CAS.key=null;CAS.tok++;pzCastInit(PZ_ORDER[0]);try{pzMusicOn()}catch(e){}
 const pick=()=>PZ_ORDER.slice().reverse().find(k=>pzOpen(k)&&!(Z.beat[k]>0))||PZ_ORDER.filter(pzOpen).pop()||'gloop';
 if(PZ.sel==null||(PZ.sel!=='shade'&&!pzOpen(PZ.sel)))PZ.sel=pick();
 /* Slick Shade sometimes slides into the booth once a day, after you have beaten Grizzle and carry some gold */
 if(!PZ.shadeChecked||PZ.shadeChecked!==pzDay()){PZ.shadeChecked=pzDay();PZ.shadeHere=false;if((Z.beat.grizzle||0)>0&&P.gold>=2000&&Z.shade.day!==pzDay()&&Math.random()<.12){PZ.shadeHere=true;Z.shade.day=pzDay();Z.shade.seen=(Z.shade.seen||0)+1;save()}}
 if(PZ.sel==='shade'&&!PZ.shadeHere)PZ.sel=pick();
 try{pzbSetup(52,Z.balls)}catch(e){}
 const beatN=PZ_ORDER.filter(k=>(Z.beat[k]||0)>0).length,cap=casCap('pz');
 const rng=R=>{const l=R.stakes.filter(s=>s<=cap);return l.length?`${cmn(l[0])}-${cmn(l[l.length-1])}`:''};
 const rows=PZ_ORDER.map((k,i)=>{const R=PZ_REG[k],open=pzOpen(k),n=Z.beat[k]||0,next=open&&!n,prev=i?PZ_REG[PZ_ORDER[i-1]]:null,cue=PZ_CUES.find(c=>c.beat===k),cn=Math.min(3,n),cueOwn=cue&&Z.cues[cue.id];
  const lv=Z.live&&Z.live.opp===k,st=lv?`<span class="pzst live"><i></i>LIVE ${Z.live.score[0]}-${Z.live.score[1]}</span>`:!open?`<span class="pzst lock"><i></i>locked</span>`:k==='mortimer'&&n?`<span class="pzst champ">♛ CHAMPION</span>`:n?`<span class="pzst won">✓ beaten ×${n}</span>`:`<span class="pzst next">NEXT UP</span>`;
  return `<button class="pzrow ${PZ.sel===k?'sel':''} ${open?'':'lock'} ${next?'next':''}" data-k="${k}" ${open?'':'disabled'} style="--i:${i+1};--c:${R.c}"><em class="pzrk">${i+1}</em><canvas width="88" height="88" data-p="${k}"></canvas><span class="pzrn"><b>${open?R.n:'? ? ?'}</b><small>${open?`${R.k} · ${rng(R)}`:`Beat ${prev.n} to open this table`}</small></span><span class="pzrr"><em class="pzlv">${'★'.repeat(R.lvl)}<u>${'★'.repeat(7-R.lvl)}</u></em>${st}</span><span class="pzpips" title="${cue?cue.n:''}">${[0,1,2].map(j=>`<i class="${cueOwn||j<cn?'on':''}"></i>`).join('')}</span></button>`}).join('');
 const shade=PZ.shadeHere?`<button class="pzrow shade ${PZ.sel==='shade'?'sel':''}" data-k="shade" style="--i:0;--c:#ffe066"><em class="pzrk">?</em><canvas width="88" height="88" data-p="shade"></canvas><span class="pzrn"><b>Slick Shade</b><small>The Hustler · 500-5,000</small></span><span class="pzrr"><span class="pzst shd">TONIGHT ONLY</span></span><span class="pzpips"></span></button>`:'';
 const live=Z.live?`<div class="pzresume2" id="pzresume"><canvas width="88" height="88" data-p="${Z.live.opp}"></canvas><div><b>Match in progress</b><span>vs ${PZ_REG[Z.live.opp].n} · ${Z.live.score[0]} - ${Z.live.score[1]}${Z.live.stake&&!Z.live.practice?` · stake ${cmn(Z.live.stake)}`:' · practice'}</span></div><button id="pzrs1">Resume</button><button id="pzrs2" class="ghost">Forfeit</button></div>`:'';
 const tr=typeof pzTrickTotal==='function'?pzTrickTotal():0,trT=typeof PZ_TRICK!=='undefined'?PZ_TRICK.length*3:30,own=pzOwnCount(),W=Z.wins||0,L=Z.losses||0,tro=pzTrophies(),troN=tro.filter(a=>P.ach&&P.ach[a.id]).length;
 const trNext=typeof PZ_TRICK!=='undefined'?PZ_TRICK.findIndex((t,i)=>pzTrickStars(i)<3):-1,bounty=typeof PZ_TRICK!=='undefined'?PZ_TRICK.filter((t,i)=>pzTrickStars(i)<3).length:0;
 const nav=[['trick','#7ad8ff','Trick Shots',`${tr} / ${trT} ★${trNext>=0?` · next: #${trNext+1}`:' · all done'}`,'T',tr/trT,bounty?'<s class="pzbdg g">+200</s>':''],
  ['cues','#ffd45a','Cue Rack',`${own.n} / ${own.t} owned${own.nw?` · ${own.nw} new`:''}`,'C',own.n/own.t,own.nw?`<s class="pzbdg">${own.nw} NEW</s>`:''],
  ['regs','#ff9ab0','The Regulars',`${W}W · ${L}L · ${troN} / ${tro.length} trophies`,'R',tro.length?troN/tro.length:0,''],
  ['rules','#c8a0ff','How to Play','rules, controls, tutorials','H',-1,'']];
 const np=pzNextPrize(),nets=Z.net||0;
 show(`<div class="pzh pzh9 pzin" id="pzh"><canvas id="pzhbg" width="1600" height="900"></canvas><canvas id="pzhfg" width="1600" height="900"></canvas>
  <button class="pzback" id="pzbk">‹&nbsp; Casino <kbd>Esc</kbd></button>
  <div class="pzgold"><i></i><b id="pzgold">${cmn(P.gold)}</b></div>
  <div class="pznet">Pool net <b class="${nets<0?'neg':''}">${nets<0?'−':'+'}${cmn(Math.abs(nets))}</b>${(Z.streak||0)>1?` · streak <b class="hot">${Z.streak}</b>`:''}</div>
  <div class="pztitle pzsign"><span>The Crooked Cue</span></div><div class="pzprog"><b>${beatN}</b> of 7 regulars beaten · <b>${Z.dayN}</b> / ${PZ_DAILY} paid matches today</div>
  <nav class="pznav">${nav.map(([a,c,t,s,k,p,x],i)=>`<button data-a="${a}" style="--c:${c};--i:${i}"><span class="pzni"><canvas width="72" height="72" data-ico="${a==='regs'?'trophy':a}"></canvas></span><span class="pznt"><b>${t}</b><span>${s}</span>${p>=0?`<em class="pznb"><i style="transform:scaleX(${Math.min(1,p)})"></i></em>`:''}</span><kbd>${k}</kbd>${x}</button>`).join('')}</nav>
  <button class="pzgran" id="pzgran">★ Trick Shots with Granny</button>
  <div class="pzboard pzboard9"><div class="pzh2">Tonight's Tables</div><div class="pzrows${PZ.shadeHere?' s8':''}" id="pzrows">${shade}${rows}</div>
   <div class="pzbft">${np?`<canvas id="pznpc" width="96" height="40"></canvas><div class="pznp"><b>Next prize: ${np.it.n}${np.t==='felt'?' felt':''}</b><span>${np.need>1?`win ${np.need} more against`:'win one match against'} ${pzShort(np.id)}</span></div>`:`<div class="pznp"><b>Every prize collected</b><span>The bar salutes you.</span></div>`}<div class="pzrack7" title="Regulars beaten">${PZ_ORDER.map((k,i)=>`<img src="${pzbIcon(i+1,26)}" class="${(Z.beat[k]||0)>0?'on':''}" alt="">`).join('')}</div></div></div>
  <div class="pzopp pzopp9" id="pzopp"></div>
  <button class="pzrackem pzrack9" id="pzrackem"><span class="pzrk1">Rack 'em up!</span><span class="pzrkx"><small id="pzrkl">STAKE → PAYS</small><b id="pzrk2"></b><kbd>Enter</kbd></span><i class="pzshine"></i></button>
  <button class="pzprac" id="pzprac"><b>Practice</b><span id="pzpracs">free</span><kbd>P</kbd></button>${live}</div>`,'casbg pzx');
 const bg=$('pzhbg').getContext('2d');bg.drawImage(pzHubBake(),0,0);
 /* the bar: regulars you have beaten (not the one you picked) come for a drink; the trio fills in until you have */
 const fg=$('pzhfg').getContext('2d');fg.lineJoin='round';fg.lineCap='round';
 const beaten=PZ_ORDER.filter(k=>(Z.beat[k]||0)>0&&k!==PZ.sel&&k!=='moldwick').reverse(),fill=['grizzle','gloop','barnacle'].filter(k=>k!==PZ.sel&&!beaten.includes(k)),bar=[...beaten,...fill].slice(0,3);
 const slots=[[1100,846],[1278,846],[1462,846]].map(([x,y],i)=>{const id=bar[i];if(!id)return null;const f=pzMonFit(id,170,236,0);return {id,x:x-85+f.x,y:y-236+f.y,s:f.s,ex:Object.assign(pzCastEx(),PZ_EXP[['happy','smug','happy'][i]]),ph:i*2}}).filter(Boolean);
 const granF=pzMonFit('moldwick',150,190,0),granEx=Object.assign(pzCastEx(),PZ_EXP.happy);
 const drawFg=()=>{if(PZ.tok!==tokH)return;const t=performance.now()/1000;fg.clearRect(980,560,620,340);fg.clearRect(40,640,300,260);
  for(const s of slots){fg.save();fg.translate(s.x,s.y);fg.scale(s.s,s.s);pzMon[s.id](fg,t+s.ph,s.ex,{breath:Math.sin(t*2.2+s.ph)*.012,tilt:0,bob:0,hop:0});fg.restore()}
  fg.save();fg.translate(75+granF.x,898-190+granF.y);fg.scale(granF.s,granF.s);pzMon.moldwick(fg,t+1,granEx,{breath:Math.sin(t*2)*.012,tilt:0,bob:0,hop:0});fg.restore();
  for(const [mx,my] of[[1150,770],[1320,770],[1500,770]].slice(0,slots.length)){fg.fillStyle='#f4e0a0';fg.beginPath();fg.roundRect(mx,my-34,26,34,5);fg.fill();fg.strokeStyle=PZ_O;fg.lineWidth=2;fg.stroke();fg.fillStyle='#fff';fg.beginPath();fg.ellipse(mx+13,my-34,15,6,0,0,TAU);fg.fill();fg.stroke()}
  pzGlow(fg,250,790,40,'rgba(255,200,120,1)',.35+.1*Math.sin(t*5))};
 LIVE.push({cv:$('pzhfg'),fn:drawFg,slow:2,ph:0});drawFg();
 ov.querySelectorAll('#pzh canvas[data-p]').forEach(cv=>{const k=cv.dataset.p,g=cv.getContext('2d'),lock=cv.closest('.lock');const f=()=>pzCastPortrait(g,'mon',k,88,performance.now()/1000,Object.assign(pzCastEx(),PZ_EXP.neutral));f();
  if(lock){g.globalCompositeOperation='source-in';g.fillStyle='#0c0818';g.fillRect(0,0,88,88);g.globalCompositeOperation='source-over'}});
 ov.querySelectorAll('#pzh canvas[data-ico]').forEach(cv=>cv.getContext('2d').drawImage(pzIco(cv.dataset.ico,72),0,0));
 {const c=$('pznpc');if(c&&np){try{pzRackThumb(c.getContext('2d'),np.t==='felt'?'felts':'cues',np.it,96,40)}catch(e){}}}
 PZ.oppSwap=0;PZ.payShown=null;PZ.oppFace=null;pzHubOpp();
 ov.querySelectorAll('.pzrow').forEach(b=>b.onclick=()=>{if(b.disabled)return;pzHubSel(b.dataset.k)});
 const go=a=>{pzFx('tick');if(a==='practice'){pzMusicOff();pzStart({opp:PZ.sel==='shade'?'gloop':PZ.sel,practice:true})}else if(a==='cues')pzGo(pzCueRack);else if(a==='rules')pzGo(pzRules);else if(a==='regs')pzGo(pzRegs);else if(a==='trick'&&typeof pzTrick==='function')pzGo(pzTrick)};
 ov.querySelectorAll('.pznav button').forEach(b=>b.onclick=()=>go(b.dataset.a));$('pzprac').onclick=()=>go('practice');$('pzgran').onclick=()=>go('trick');
 $('pzbk').onclick=()=>{pzMusicOff();try{lobby()}catch(e){title()}};S.back=()=>$('pzbk').click();
 $('pzrackem').onclick=()=>{if(Z.live){$('pzrs1').click();return}const sel=PZ.sel,R=PZ_REG[sel],lo=sel==='shade'?500:Math.min(...R.stakes.filter(s=>s<=casCap('pz')));if(P.gold<lo){pzMusicOff();pzNote('Not enough gold for stakes, so this one is a free practice game.');pzStart({opp:sel==='shade'?'gloop':sel,practice:true});return}const stake=sel==='shade'?PZ.shadeStake:pzStakeOf(sel);pzMusicOff();pzStart({opp:sel,stake})};
 if(Z.live){$('pzrs1').onclick=()=>{pzStart({opp:Z.live.opp,resume:Z.live,race:Z.live.race})};$('pzrs2').onclick=function(){if(!this.dataset.sure){this.dataset.sure=1;const t=this.textContent;this.textContent=Z.live&&Z.live.stake&&!Z.live.practice?'Sure? You lose the stake':'Sure? Drop this match';setTimeout(()=>{if(this.isConnected){delete this.dataset.sure;this.textContent=t}},3200);return}const L=Z.live;Z.live=null;if(L.stake&&!L.practice){Z.losses++;Z.streak=0;ecSrc('pool',()=>cPay(L.stake,0));Z.net-=L.stake;const v=pzVs();v[L.opp]=v[L.opp]||[0,0];v[L.opp][1]++}save();const el=$('pzresume');el.classList.add('out');setTimeout(()=>{el.remove();pzHubOpp()},260)}}
 setTimeout(()=>{const h=$('pzh');if(h&&PZ.tok===tokH)h.classList.remove('pzin')},1100);
 pzFitTM();try{pzHubTour()}catch(e){}}
/* pick a regular: the spotlight slides over to the new face, who hops and says hello */
function pzHubSel(k){if(k===PZ.sel)return;const rows=[...ov.querySelectorAll('.pzrow')],b=rows.find(r=>r.dataset.k===k);if(!b||b.disabled)return;
 const i0=rows.findIndex(r=>r.dataset.k===PZ.sel),i1=rows.indexOf(b);PZ.oppSwap=i1>i0?1:-1;PZ.sel=k;pzFx('tick');rows.forEach(x=>x.classList.toggle('sel',x===b));pzHubOpp()}
function pzHubOpp(){const id=PZ.sel,R=PZ_REG[id],Z=PZS(),el=$('pzopp');if(!el)return;const hustler=id==='shade',cap=casCap('pz');
 if(hustler&&!PZ.shadeStake)PZ.shadeStake=Math.min(cap,Math.max(500,Math.min(P.gold,1000)));
 const stake=hustler?PZ.shadeStake:pzStakeOf(id),mult=pzMultS(id,stake),wise=Z.rep[id]||0,paid=Z.dayN<PZ_DAILY;
 const list=hustler?[500,1000,2000,3000,5000].filter(s=>s<=cap):R.stakes.filter(s=>s<=cap),lo=list.length?Math.min(...list):0,poor=P.gold<lo;
 const cue=hustler?PZ_CUES.find(c=>c.beatShade):PZ_CUES.find(c=>c.beat===id),cn=hustler?(Z.shade.beat||0):(Z.beat[id]||0),have=cue&&Z.cues[cue.id];
 const vs=pzVs()[id]||[0,0],win=Math.round(stake*mult),fm=x=>x.toFixed(2).replace(/0$/,'').replace(/\.0$/,'');
 const sw=PZ.oppSwap,newFace=sw!==0||PZ.oppFace!==id;PZ.oppSwap=0;PZ.oppFace=id;
 const wiseShow=wise&&paid&&!poor,full=Math.min(R.mult,Math.floor(PZ_CAP/Math.max(1,stake)*100)/100);
 const a=R.ai,mtr=hustler?null:[['Aim',1+(3-a.sig)/2.1*4],['Position',1+a.pos*5],['Safety',1+a.safe*9],['Planning',a.look*.62]];
 el.innerHTML=`<div class="pzo9 ${sw?(sw>0?'swd':'swu'):''}"><div class="pzstage"><canvas class="pzstbg" width="300" height="424"></canvas><canvas id="pzoppc" width="300" height="360"></canvas><div class="pzbub ${newFace?'pop':''}">“${R.lines.hi[0]}”</div><div class="pzplate">${R.lvl?`LEVEL ${R.lvl} OF 7`:'RANDOM VISITOR'}</div></div>
  <div class="pzoppi"><div class="pzh3" style="color:${R.c}">${R.n}</div><div class="pzsub2">${R.k}${R.lvl?` <span class="pzstars">${pzStars(R.lvl)}</span>`:''}</div>
   <div class="pzfacts"><div><b>${R.race}</b><small>${R.race>1?'RACKS TO WIN':'RACK WINS IT'}</small></div><div class="g"><b>${wiseShow&&full>mult?`<s>×${fm(full)}</s>`:''}×${fm(mult)}</b><small>${wiseShow?'WISE TO YOU':'PAYS'}</small></div><div><b>${vs[0]||vs[1]||!cn?`${vs[0]}-${vs[1]}`:`${cn}W`}</b><small>YOUR RECORD</small></div></div>
   <div class="pzhrc"><canvas width="44" height="44" data-ico="rules"></canvas><div><b>House rule</b><span>${R.houseTxt}</span><em>${PZ_TIPS[id]||''}</em></div></div>
   ${mtr?`<div class="pzmtr">${mtr.map(([n,x])=>{const k=Math.max(1,Math.min(5,Math.round(x)));return `<div><span>${n}</span><i>${'<u class="on"></u>'.repeat(k)}${'<u></u>'.repeat(5-k)}</i></div>`}).join('')}</div>`:'<div class="pzmtr shd">Bets small, wins big, shows up when he likes. Beat him three times for the Shadow Cue.</div>'}
   <div class="pzstk"><small>STAKE <kbd>←</kbd><kbd>→</kbd></small><div class="pzchips2 ${list.length>4?'many':''}">${list.map(s=>pzChip(s,s===stake,s>P.gold)).join('')}</div></div>
   <div class="pzpay9">${poor?`<span class="warn">You need ${cmn(lo)} gold to play for stakes. Practice is free.</span>`:paid?`Win pays <b id="pzpayv">${cmn(PZ.payShown!=null&&!newFace?PZ.payShown:win)}</b><em>+${cmn(win-stake)} profit</em>`:`<span class="warn">Daily paid matches used: this one is a friendly.</span>`}</div>
   ${cue?`<div class="pzrew ${have?'have':''}"><canvas id="pzrewc" width="180" height="30"></canvas><div><b>${cue.n}</b><span>${have?'Yours':`${Math.min(cn,3)} / 3 wins`}</span></div><em><i style="transform:scaleX(${have?1:Math.min(cn,3)/3})"></i></em></div>`:''}</div></div>`;
 el.style.setProperty('--c',R.c);
 el.querySelector('.pzstbg').getContext('2d').drawImage(pzStageBake(R.c),0,0);el.querySelectorAll('canvas[data-ico]').forEach(cv=>cv.getContext('2d').drawImage(pzIco(cv.dataset.ico,44),0,0));
 const cv=$('pzoppc'),g=cv.getContext('2d');g.lineJoin='round';g.lineCap='round';const ex=Object.assign(pzCastEx(),PZ_EXP[newFace?'happy':'neutral']),fit=pzMonFit(id,300,340,14,1.15),t0=performance.now()/1000;let calm=!newFace;
 const f=()=>{if(!cv.isConnected)return;const t=performance.now()/1000,ht=t-t0,hy=newFace&&ht<.55?-Math.sin(ht/.55*Math.PI)*22:0;if(ht>1.2&&!calm){Object.assign(ex,PZ_EXP.neutral);calm=true}
  g.clearRect(0,0,300,360);g.save();g.translate(fit.x,fit.y+hy+12);g.scale(fit.s,fit.s);pzMon[id](g,t,ex,{breath:Math.sin(t*2.2)*.012,tilt:Math.sin(t*.8)*.025,bob:Math.sin(t*1.7)*1.4,hop:0});g.restore()};f();LIVE.push({cv,fn:f,slow:1,ph:1});
 {const rc=$('pzrewc');if(rc&&cue){try{pzRackThumb(rc.getContext('2d'),'cues',cue,180,30)}catch(e){}}}
 el.querySelectorAll('.pzchip2').forEach(b=>b.onclick=()=>{if(b.disabled)return;pzHubStake(+b.dataset.s)});
 /* the payout rolls to its new value */
 {const pv=$('pzpayv');if(pv&&PZ.payShown!=null&&PZ.payShown!==win&&!newFace){const from=PZ.payShown,t1=performance.now(),stp=()=>{if(!pv.isConnected)return;const u=Math.min(1,(performance.now()-t1)/300),e=1-Math.pow(1-u,3);pv.textContent=cmn(Math.round(from+(win-from)*e));if(u<1)requestAnimationFrame(stp)};requestAnimationFrame(stp)}PZ.payShown=paid&&!poor?win:null}
 const rb=$('pzrackem');if(rb){rb.querySelector('.pzrk1').textContent=Z.live?'Resume match':poor?'Free game':(!paid?'Friendly game':"Rack 'em up!");
  $('pzrkl').textContent=Z.live?'IN PROGRESS':poor||!paid?'NO STAKE':'STAKE → PAYS';$('pzrk2').textContent=Z.live?`vs ${pzShort(Z.live.opp)} ${Z.live.score[0]}-${Z.live.score[1]}`:poor||!paid?`vs ${pzShort(id)}`:`${cmn(stake)} → ${cmn(win)}`;rb.style.setProperty('--c',R.c)}
 const ps=$('pzpracs');if(ps)ps.textContent=`free · vs ${pzShort(hustler?'gloop':id)}`}
function pzHubStake(s){const id=PZ.sel;if(id==='shade')PZ.shadeStake=s;else{PZ.stk=PZ.stk||{};PZ.stk[id]=s}pzFx('tick');pzHubOpp();const b=ov.querySelector(`.pzchip2[data-s="${s}"]`);if(b)b.classList.add('pop')}
/* keys on the hub (Enter and up/down come from 96j) */
if(!window.__pzKeys9){window.__pzKeys9=1;addEventListener('keydown',e=>{try{if(e.repeat||!$('pzh')||PZ.modal||pzCoachActive())return;if(document.activeElement&&/INPUT|TEXTAREA/.test(document.activeElement.tagName))return;if(e.ctrlKey||e.metaKey||e.altKey)return;
 const k=e.key;if(k==='ArrowLeft'||k==='ArrowRight'){const cs=[...ov.querySelectorAll('.pzchip2:not(:disabled)')];if(!cs.length)return;const i=cs.findIndex(c=>c.classList.contains('on')),n=cs[Math.max(0,Math.min(cs.length-1,(i<0?0:i)+(k==='ArrowRight'?1:-1)))];e.preventDefault();if(n&&!n.classList.contains('on'))pzHubStake(+n.dataset.s);return}
 if(/^[1-7]$/.test(k)){const b=ov.querySelector(`.pzrow[data-k="${PZ_ORDER[+k-1]}"]`);if(b&&!b.disabled){e.preventDefault();pzHubSel(b.dataset.k)}return}
 if(k==='n'||k==='N'){const b=ov.querySelector('.pzrow.next')||ov.querySelector('.pzrow.shade');if(b){e.preventDefault();pzHubSel(b.dataset.k)}return}
 if(k==='p'||k==='P'){e.preventDefault();$('pzprac').click();return}
 const m={t:'trick',c:'cues',h:'rules',r:'regs'}[k.toLowerCase()];if(m){const b=ov.querySelector(`.pznav button[data-a="${m}"]`);if(b){e.preventDefault();b.click()}}}catch(err){}})}
function pzHubTour(){}
/* the side screens fade back out to the hub and build themselves in */
{for(const nm of['pzCueRack','pzRules','pzTrick']){const f0=window[nm];if(typeof f0!=='function')continue;window[nm]=function(){const r=f0.apply(this,arguments);try{const b=$('pzbk');if(b&&!$('pzh')){b.onclick=()=>pzGo(pzHub);S.back=()=>pzGo(pzHub)}const root=ov.querySelector(':scope>.pzr,:scope>.pzk');if(root&&!root.dataset.in){root.dataset.in=1;root.classList.add('pzscrin');setTimeout(()=>root.classList.remove('pzscrin'),900)}}catch(e){}return r}}}
{const st=document.createElement('style');st.textContent=`
.pzh9 .pzback{z-index:5;display:flex;align-items:center;gap:10px}.pzback kbd,.pzh9 kbd{display:inline-block;min-width:18px;padding:0 6px;border-radius:7px;background:#12081f;border:1px solid #4a3e90;font:800 11px/20px Poppins,sans-serif;color:#9a90c8;text-align:center}
.pzgone{transition:opacity .15s,transform .15s;opacity:0!important;transform:translateY(10px)}
.pzscrin>*:not(canvas):not(.pzktabs9):not(.pztsub){animation:pzrise .42s cubic-bezier(.25,1.25,.45,1) both}.pzscrin>.pzktabs9,.pzscrin>.pztsub{animation:pzfade .42s both}.pzscrin>*:nth-child(3){animation-delay:.04s}.pzscrin>*:nth-child(4){animation-delay:.08s}.pzscrin>*:nth-child(5){animation-delay:.12s}.pzscrin>*:nth-child(6){animation-delay:.16s}.pzscrin>*:nth-child(n+7){animation-delay:.2s}
.pzh9 .pzgold{right:24px;width:220px;box-sizing:border-box}
.pznet{position:absolute;right:24px;top:80px;padding:4px 12px;border-radius:12px;background:#100a30d0;border:2px solid #2a2468;font:700 12.5px Poppins,sans-serif;color:#c4badf;z-index:3}.pznet b{color:#8affb4}.pznet b.neg{color:#ff9a9a}.pznet b.hot{color:#ff9a4a}
.pzh9 .pzsign{top:8px}
.pzprog{position:absolute;left:50%;top:84px;transform:translateX(-50%);padding:4px 16px;border-radius:14px;background:#100a30e0;border:2px solid #4a3e90;font:600 13px Poppins,sans-serif;color:#c4badf;white-space:nowrap;z-index:3}.pzprog b{color:#ffd45a;font-weight:800}
.pznav{position:absolute;left:24px;top:128px;width:274px;display:flex;flex-direction:column;gap:14px;z-index:3}
.pznav button{position:relative;display:flex;align-items:center;gap:12px;height:100px;padding:0 14px 0 10px;border-radius:20px;text-align:left;color:#efe8ff;cursor:pointer;background:linear-gradient(180deg,#241c60,#110a32);border:3px solid #4a3e90;box-shadow:inset 0 1px 0 #ffffff24,0 10px 26px #0009;transition:transform .2s cubic-bezier(.3,1.5,.5,1)}
.pznav button:hover,.pznav button:focus-visible{transform:translateX(8px);border-color:#ffd45a;outline:none}.pznav button:active{transform:translateX(5px) scale(.97)}
.pzni{flex:none;width:72px;height:72px;border-radius:50%;background:radial-gradient(circle at 50% 40%,#3a2f8a,#130b38 72%);border:3px solid #12081f;box-shadow:inset 0 0 0 2px #ffffff14;display:block;transition:transform .3s cubic-bezier(.3,1.7,.5,1)}
.pzni canvas{width:72px;height:72px;display:block}.pznav button:hover .pzni{transform:rotate(-8deg) scale(1.1)}
.pznt{flex:1;min-width:0}.pznt b{display:block;font:800 18px/1.2 Poppins,sans-serif;color:#fff}.pznt>span{display:block;margin-top:2px;font-size:12.5px;font-weight:600;color:#c4badf;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.pznb{display:block;margin-top:8px;margin-right:30px;height:7px;border-radius:5px;background:#12081f;overflow:hidden}.pznb i{display:block;height:100%;background:linear-gradient(90deg,var(--c),#ffd45a);transform-origin:0 50%}
.pzbdg{position:absolute;right:10px;top:-11px;padding:2px 9px;border-radius:10px;background:#ff4a6a;color:#fff;font:800 11px Poppins,sans-serif;text-decoration:none;letter-spacing:.05em;border:2px solid #12081f;animation:pznewb 1.6s ease-in-out infinite}.pzbdg.g{background:#ffd45a;color:#2a1a04;animation:none}
.pznav kbd{position:absolute;right:10px;bottom:9px;opacity:.8}
.pzgran{position:absolute;left:52px;top:618px;padding:7px 14px;border-radius:13px;background:#100a30e8;border:2px solid #8affb4;color:#a8ffcc;font:800 13px Poppins,sans-serif;cursor:pointer;z-index:3;transition:transform .2s cubic-bezier(.3,1.6,.5,1)}.pzgran:hover{transform:translateY(-3px)}
.pzboard9{left:314px;top:116px;width:588px;height:614px;box-sizing:border-box;padding:12px 18px}
.pzboard9 .pzh2{margin:0 0 4px;font-size:44px}
.pzboard9 .pzrows{gap:4px}
.pzh9 .pzrow{position:relative;height:58px;padding:2px 10px 2px 4px;gap:10px;border-radius:14px}
.pzrk{flex:none;width:18px;font:400 24px/1 "Pirata One",serif;font-style:normal;color:#f4f4e655;text-align:center}
.pzh9 .pzrow canvas{width:46px;height:46px;flex:none}
.pzrn{flex:1;min-width:0;display:flex;flex-direction:column;justify-content:center}.pzh9 .pzrow .pzrn b{font:400 26px/1.05 "Pirata One",serif;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:var(--c)}.pzh9 .pzrow.lock .pzrn b{color:#8a86a0}
.pzh9 .pzrow .pzrn small{position:static;text-align:left;margin-top:1px;font:600 11.5px Poppins,sans-serif;color:#b8d0c0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.pzh9 .pzrow.lock .pzrn small{color:#7a7690}
.pzrr{flex:none;display:flex;flex-direction:column;align-items:flex-end;gap:3px}
.pzlv{font-style:normal;font-size:10px;letter-spacing:1px;color:#ffd45a}.pzlv u{text-decoration:none;color:#ffffff22}
.pzst{padding:3px 9px;border-radius:10px;font:800 11.5px Poppins,sans-serif;letter-spacing:.03em;border:2px solid #12081f}
.pzh9 .pzrow .pzst.won{background:#1d4a32;color:#a8ffcc}.pzh9 .pzrow .pzst.next{background:#ffd45a;color:#2a1a04;animation:pznext 1.4s ease-in-out infinite}.pzh9 .pzrow .pzst.shd{background:#ffe066;color:#2a1a04}
.pzh9 .pzrow .pzst.live{background:#5a1428;color:#ffb0c0;display:flex;align-items:center;gap:6px}.pzh9 .pzrow .pzst.live i{width:8px;height:8px;border-radius:50%;background:#ff4a6a;animation:pznext 1s ease-in-out infinite}.pzh9 .pzrow .pzst.champ{background:linear-gradient(180deg,#ffe27a,#f2b631);color:#2a1a04}
.pzh9 .pzrow .pzst.lock{background:#241e32;color:#8a86a0;display:flex;align-items:center;gap:6px}.pzst.lock i{width:9px;height:8px;border-radius:2px;background:#8a86a0;position:relative;top:2px}.pzst.lock i::before{content:'';position:absolute;left:1px;top:-6px;width:3px;height:4px;border:2px solid #8a86a0;border-bottom:0;border-radius:4px 4px 0 0}
.pzh9 .pzpips{position:static;flex:none;display:flex;gap:4px;width:44px;justify-content:flex-end}.pzh9 .pzpips i{width:10px;height:10px;border-radius:50%;background:#1a2a22;border:2px solid #4a6a58;box-sizing:border-box;transform:none}.pzh9 .pzpips i.on{background:var(--c);border-color:#12081f}
.pzh9 .pzrows.s8 .pzrow{height:52px}.pzh9 .pzrows.s8 .pzrow canvas{width:40px;height:40px}
.pzh9 .pzrow.sel{background:linear-gradient(90deg,#ffffff26,#ffffff0a);border-color:var(--c);transform:translateX(6px)}
.pzh9 .pzrow.sel::before{content:'';position:absolute;left:-15px;top:50%;width:0;height:0;margin-top:-9px;border:9px solid transparent;border-left:11px solid #f4f4e6}
.pzh9 .pzrow:hover:not(:disabled):not(.sel){transform:translateX(4px)}
.pzbft{position:absolute;left:18px;right:18px;bottom:10px;height:48px;display:flex;align-items:center;gap:12px;border-top:2px dashed #ffffff22;padding-top:8px}
.pzbft canvas{width:96px;height:40px;flex:none;border-radius:8px}.pznp{flex:1;min-width:0}.pznp b{display:block;font:400 21px/1.1 "Pirata One",serif;color:#f4f4e6;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.pznp span{font:600 12px Poppins,sans-serif;color:#b8d0c0}
.pzrack7{display:flex;gap:3px}.pzrack7 img{width:22px;height:22px;opacity:.22}.pzrack7 img.on{opacity:1}
.pzopp9{left:916px;top:104px;width:660px;height:452px;box-sizing:border-box;overflow:hidden;border-width:3px}
.pzo9{position:absolute;inset:0}
.pzo9.swd{animation:pzswd .34s cubic-bezier(.25,1.2,.4,1) both}.pzo9.swu{animation:pzswu .34s cubic-bezier(.25,1.2,.4,1) both}
.pzstage{position:absolute;left:12px;top:12px;width:300px;height:424px;border-radius:18px;overflow:hidden;border:2px solid #12081f}
.pzstage canvas{position:absolute;left:0}.pzstbg{top:0;width:300px;height:424px}#pzoppc{top:44px;width:300px;height:360px}
.pzstage .pzbub{position:absolute;left:14px;right:14px;top:22px;margin:0}
.pzbub{padding:9px 13px;border-radius:14px;background:#fff8ec;color:#24124a;font:600 italic 13.5px/1.35 Poppins,sans-serif;border:3px solid #12081f;text-align:center;transform-origin:50% 100%}
.pzbub.pop{animation:pzbub .45s .1s cubic-bezier(.3,1.6,.5,1) both}
.pzbub::after{content:'';position:absolute;left:50%;bottom:-12px;margin-left:-9px;border:9px solid transparent;border-top:10px solid #12081f;border-bottom:0}
.pzplate{position:absolute;left:50%;bottom:12px;transform:translateX(-50%);padding:3px 12px;border-radius:9px;background:#12081f;border:2px solid var(--c);font:800 11px Poppins,sans-serif;letter-spacing:.12em;color:var(--c);white-space:nowrap}
.pzopp9 .pzoppi{position:absolute;left:326px;top:12px;right:14px;text-align:left}
.pzopp9 .pzoppi .pzh3{font-size:40px;line-height:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.pzsub2{margin-top:2px;font:700 13px Poppins,sans-serif;color:#c4badf}.pzsub2 .pzstars{font-size:12px;letter-spacing:1px}
.pzfacts{display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin:8px 0 7px}.pzfacts div{padding:6px 4px 5px;border-radius:12px;background:#140c36;border:2px solid #3a3070;text-align:center}
.pzfacts b{display:block;font:400 26px/1 "Pirata One",serif;color:#efe8ff}.pzfacts b s{font-size:16px;color:#ff9a9a;margin-right:4px}.pzfacts .g b{color:#ffd45a}.pzfacts small{display:block;margin-top:2px;font:800 9.5px Poppins,sans-serif;letter-spacing:.12em;color:#9a90c8}
.pzhrc{display:flex;gap:10px;align-items:flex-start;padding:8px 10px;border-radius:12px;background:#1a1046;border:2px solid var(--c)}.pzhrc canvas{width:36px;height:36px;flex:none}
.pzhrc b{display:block;font:800 12.5px Poppins,sans-serif;color:#ffd45a}.pzhrc span{display:block;font:500 12px/1.35 Poppins,sans-serif;color:#e2dafc}.pzhrc em{display:block;margin-top:2px;font:600 11.5px/1.35 Poppins,sans-serif;font-style:normal;color:#9ad8b0}
.pzmtr{display:grid;grid-template-columns:1fr 1fr;gap:3px 16px;margin:7px 2px 0}.pzmtr div{display:flex;align-items:center;justify-content:space-between}.pzmtr span{font:800 10px Poppins,sans-serif;letter-spacing:.08em;color:#c4badf;text-transform:uppercase}
.pzmtr i{display:flex;gap:3px}.pzmtr u{width:16px;height:7px;border-radius:3px;background:#2a2468}.pzmtr u.on{background:var(--c)}.pzmtr.shd{display:block;font:600 12px/1.4 Poppins,sans-serif;color:#ffe9a0}
.pzstk{display:flex;align-items:center;gap:10px;margin-top:6px}.pzstk small{flex:none;width:44px;font:800 10px/1.6 Poppins,sans-serif;letter-spacing:.1em;color:#c4badf}.pzstk small kbd{margin:2px 2px 0 0;min-width:12px;padding:0 3px;font-size:10px;line-height:16px}
.pzchips2{display:flex;gap:7px}.pzchips2.many{gap:5px}.pzchips2.many .pzchip2{width:44px;height:44px}.pzchips2.many .pzchip2 b{font-size:12px}
.pzchip2{position:relative;width:50px;height:50px;padding:0;border-radius:50%;border:3px solid #12081f;cursor:pointer;background:repeating-conic-gradient(var(--cc) 0 22.5deg,#fff 22.5deg 30deg,var(--cc) 30deg 45deg);transition:transform .22s cubic-bezier(.3,1.7,.5,1);box-shadow:0 4px 0 #0008}
.pzchip2 i{position:absolute;inset:6px;border-radius:50%;background:var(--cc);border:2px dashed #ffffffa0}
.pzchip2 b{position:relative;font:800 14px/1 Poppins,sans-serif;color:var(--ct)}
.pzchip2:hover:not(:disabled){transform:translateY(-4px)}.pzchip2.on{transform:translateY(-7px);box-shadow:0 0 0 3px #ffd45a,0 10px 0 #0006}.pzchip2.pop{animation:pzchipspin .5s cubic-bezier(.3,1.4,.5,1)}
.pzchip2:disabled{opacity:.28;cursor:default}
.pzpay9{margin-top:4px;font:700 14px Poppins,sans-serif;color:#efe8ff;min-height:34px;display:flex;align-items:baseline;flex-wrap:wrap;gap:0 8px}.pzpay9 b{font:400 34px/1 "Pirata One",serif;color:#ffd45a}.pzpay9 em{font-style:normal;color:#8affb4;font-size:13px;font-weight:800}.pzpay9 .warn{font-size:13px;color:#ffc89a}
.pzrew{display:flex;align-items:center;gap:10px;margin-top:6px;padding:6px 10px 8px;border-radius:12px;background:#0c0824;border:2px solid #2a2468;position:relative}
.pzrew canvas{width:150px;height:25px;flex:none}.pzrew div{flex:1;min-width:0;text-align:right}.pzrew b{display:block;font:800 12px Poppins,sans-serif;color:#efe8ff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.pzrew span{font:700 11.5px Poppins,sans-serif;color:#ffd45a}
.pzrew em{position:absolute;left:10px;right:10px;bottom:3px;height:3px;border-radius:2px;background:#2a2468;overflow:hidden}.pzrew em i{display:block;height:100%;background:#ffd45a;transform-origin:0 50%}.pzrew.have span{color:#8affb4}.pzrew.have em i{background:#8affb4}
.pzrack9{left:916px;top:572px;width:500px;height:92px;display:flex;align-items:center;justify-content:space-between;padding:0 22px 0 28px;box-sizing:border-box;overflow:hidden;animation:pzrkb 2.6s ease-in-out 1.4s infinite}
.pzrk1{font:400 52px/1 "Pirata One",Georgia,serif;white-space:nowrap}.pzrkx{display:flex;flex-direction:column;align-items:flex-end;gap:2px;color:#5a3a06}.pzrkx small{font:800 10px Poppins,sans-serif;letter-spacing:.12em}.pzrkx b{font:800 17px Poppins,sans-serif;color:#2a1a04;white-space:nowrap}
.pzrack9 kbd{background:#2a1a04;color:#ffe27a;border-color:#2a1a04}
.pzshine{position:absolute;top:-20px;bottom:-20px;left:0;width:90px;background:linear-gradient(100deg,transparent,#ffffffa0,transparent);transform:translateX(-160px) skewX(-18deg);animation:pzshine 3.6s ease-in-out 1.6s infinite;pointer-events:none}
.pzrack9:hover{animation:none;transform:translateY(-3px) scale(1.01)}
.pzprac{position:absolute;left:1428px;top:572px;width:148px;height:92px;border-radius:22px;background:linear-gradient(180deg,#241c60,#110a32);border:3px solid #8affb4;color:#efe8ff;cursor:pointer;z-index:2;box-shadow:0 8px 0 #0a0620,0 12px 26px #000a;transition:transform .15s cubic-bezier(.3,1.6,.5,1)}
.pzprac b{display:block;font:800 18px Poppins,sans-serif;margin-top:6px}.pzprac span{display:block;margin-top:2px;font:600 11.5px Poppins,sans-serif;color:#a8ffcc}.pzprac kbd{position:absolute;right:8px;top:8px}.pzprac:hover{transform:translateY(-3px)}.pzprac:active{transform:translateY(4px)}
.pzresume2{position:absolute;left:314px;top:744px;width:588px;box-sizing:border-box;padding:10px 14px;border-radius:18px;background:linear-gradient(180deg,#3a1e70,#1e0f48);border:3px solid #ffd45a;display:flex;align-items:center;gap:12px;z-index:4;box-shadow:0 10px 26px #000a;animation:pzbIn .5s .5s cubic-bezier(.2,1.4,.4,1) both}
.pzresume2.out{animation:pzbOut .26s both}.pzresume2 canvas{width:52px;height:52px;border-radius:50%;background:#2a1a4a;border:2px solid #c99a3a;flex:none}
.pzresume2 div{flex:1}.pzresume2 b{display:block;font:800 15px Poppins,sans-serif;color:#ffd45a}.pzresume2 span{font:600 13px Poppins,sans-serif;color:#e2dafc}
.pzresume2 button{padding:10px 16px;border-radius:12px;border:2px solid #12081f;background:#ffd45a;color:#2a1a04;font:800 14px Poppins,sans-serif;cursor:pointer}.pzresume2 button.ghost{background:#3a2f8a;color:#efe8ff}
/* the entrance: sign drops, tiles slide in, the board rises and its rows cascade, the spotlight slides in, the buttons pop */
.pzh9.pzin .pzsign{animation:pzsign .65s cubic-bezier(.25,1.5,.45,1) both}
.pzh9.pzin .pzprog{animation:pzfadeY .5s .2s both}
.pzh9.pzin .pznav button{animation:pzfromL .42s calc(.05s + var(--i)*.05s) cubic-bezier(.25,1.3,.45,1) both}
.pzh9.pzin .pzboard9{animation:pzrise .45s .05s cubic-bezier(.25,1.25,.45,1) both}
.pzh9.pzin .pzrow{animation:pzrowIn .34s calc(.16s + var(--i)*.035s) cubic-bezier(.25,1.3,.45,1) both}
.pzh9.pzin .pzopp9{animation:pzfromR .45s .1s cubic-bezier(.25,1.25,.45,1) both}
.pzh9.pzin .pzrack9{animation:pzpopIn .45s .3s cubic-bezier(.25,1.6,.45,1) both,pzrkb 2.6s ease-in-out 1.4s infinite}
.pzh9.pzin .pzprac{animation:pzpopIn .45s .36s cubic-bezier(.25,1.6,.45,1) both}
.pzh9.pzin .pzgold,.pzh9.pzin .pznet,.pzh9.pzin .pzback,.pzh9.pzin .pzgran{animation:pzfade .5s .2s both}
.pzh9.pzin #pzhfg{animation:pzfade .7s .2s both}
@keyframes pzsign{0%{opacity:0;transform:translateY(-60px) rotate(-3deg)}60%{opacity:1;transform:translateY(6px) rotate(1deg)}100%{transform:none}}
@keyframes pzfromL{from{opacity:0;transform:translateX(-80px)}to{opacity:1;transform:none}}
@keyframes pzfromR{from{opacity:0;transform:translateX(90px)}to{opacity:1;transform:none}}
@keyframes pzrise{from{opacity:0;transform:translateY(40px) scale(.97)}to{opacity:1;transform:none}}
@keyframes pzrowIn{from{opacity:0;transform:translateX(-24px)}to{opacity:1;transform:none}}
@keyframes pzpopIn{0%{opacity:0;transform:scale(.7)}100%{opacity:1;transform:none}}
@keyframes pzfade{from{opacity:0}to{opacity:1}}@keyframes pzfadeY{from{opacity:0;transform:translate(-50%,-10px)}to{opacity:1;transform:translateX(-50%)}}
@keyframes pzswd{from{opacity:0;transform:translateY(26px)}to{opacity:1;transform:none}}@keyframes pzswu{from{opacity:0;transform:translateY(-26px)}to{opacity:1;transform:none}}
@keyframes pzbub{from{opacity:0;transform:scale(.5) translateY(14px)}to{opacity:1;transform:none}}
@keyframes pznext{0%,100%{transform:none}50%{transform:scale(1.07)}}
@keyframes pznewb{0%,100%{transform:none}50%{transform:translateY(-3px)}}
@keyframes pzchipspin{0%{transform:translateY(-7px) rotate(0)}100%{transform:translateY(-7px) rotate(360deg)}}
@keyframes pzrkb{0%,100%{transform:none}50%{transform:scale(1.015)}}
@keyframes pzshine{0%{transform:translateX(-160px) skewX(-18deg)}45%,100%{transform:translateX(660px) skewX(-18deg)}}
`;document.head.appendChild(st)}
