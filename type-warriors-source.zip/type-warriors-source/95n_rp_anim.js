/* ===== RUNESTONE TOWER DEFENSE 9.2: smoother tower animation (95n, after 95m) =====
   - Turning: the Rune Ballista's turret (and the Celestial Prism's flare) used to snap to each new target the instant it fired. Now
     the turret tracks its target continuously and turns at most RPA.turn rad/s; it only looses a bolt once it points within RPA.tol of
     the target (the bolt leaves along the turret). tw.aimD is the drawn angle.
   - Recoil: every tower's fire value (1 on a shot, falling to 0) is drawn through a smoothstep, so recoils, flares and bell swings
     settle gently instead of stopping dead.
   - Hover and selection: a built tower lifts slightly (a spring, tw.hv) when the pointer is over it or it is selected.
   Only the drawing and the ballista's shot timing change; damage and ranges do not. */
const RPA={turn:9,tol:.2};
const rpaD=(a,b)=>{let d=a-b;while(d>Math.PI)d-=TAU;while(d<-Math.PI)d+=TAU;return d};
{const f0=rpFire;rpFire=function(R,tw,dt){if(tw.type!=='ballista')return f0.apply(this,arguments);
  const T=RP_TW.ballista,i=tw.tier-1,e=rpTarget(R,tw,T.range[i],!!T.air,!!T.ground,tw.prio,false);if(tw.aimD==null)tw.aimD=tw.aim||0;
  let ta=null;if(e){const p=rpPos(R,e),ty=p.y-(e.air?40:18);ta=Math.atan2(ty-(tw.y-40),p.x-tw.x)}
  const goal=ta!=null?ta:tw.aim||tw.aimD,d=rpaD(goal,tw.aimD),st=RPA.turn*dt*(tw.over>0?1.6:1);tw.aimD+=Math.max(-st,Math.min(st,d));
  /* hold the shot until the turret faces the target */
  if(ta!=null&&Math.abs(rpaD(ta,tw.aimD))>RPA.tol&&tw.cd-dt*(tw.over>0?RPT.AB.over.k:1)<=0){tw.over=Math.max(0,tw.over-dt);tw.fire=Math.max(0,tw.fire-dt*3);tw.cd=Math.max(tw.cd,.001);return}
  return f0.apply(this,arguments)}}
/* the drawn state: smoothed fire, the turret's drawn angle, the hover lift */
let RPATW=null;
{const d0=rpTowerDraw;rpTowerDraw=function(g,type,tier,skin,t,o){const tw=RPATW;if(tw&&o&&type!=='dragon'&&type!=='tide'){const f=Math.max(0,Math.min(1,o.fire||0));o=Object.assign({},o,{fire:f*f*(3-2*f)});if(tw.aimD!=null&&type==='ballista')o.aim=tw.aimD}return d0.call(this,g,type,tier,skin,t,o)}}
{const a0=rpTowerAt;rpTowerAt=function(c,R,tw){const now=R.t,dt=tw.alt==null?0:Math.max(0,Math.min(.1,now-tw.alt));tw.alt=now;
  const want=(R.hover===tw.pad||R.sel===tw)&&tw.build>=1?1:0;if(tw.hv==null)tw.hv=0;if(tw.hvv==null)tw.hvv=0;
  tw.hvv+=((want-tw.hv)*220-tw.hvv*22)*dt;tw.hv+=tw.hvv*dt;if(Math.abs(tw.hv)<.001&&!want){tw.hv=0;tw.hvv=0}
  RPATW=tw;try{if(tw.hv>.002){const k=1+.045*tw.hv;c.save();c.translate(tw.x,tw.y+14);c.scale(k,k);c.translate(-tw.x,-tw.y-14);a0.apply(this,arguments);c.restore();return}return a0.apply(this,arguments)}finally{RPATW=null}}}
