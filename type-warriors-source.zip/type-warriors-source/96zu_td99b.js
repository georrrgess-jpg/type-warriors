/* ===== RUNESTONE TOWER DEFENSE 9.9b: small fixes (96zu, after 96zt) =====
   - The selected tower tile in the bar: the tower icon now sits above the tile's gold outline (it used to be cut by it while it bobbed).
   - The build ring: a button's name label no longer catches clicks meant for its neighbour, and the whole ring is kept inside a safe
     area of the stage (clear of the edges, the top HUD and the tower bar) so no button is ever cut off.
   - The Alchemist's Still badge over soaked monsters shows only the potion symbol (no "-N").
   (The Thunder Mortar now costs 550 to build: the cost table is in 95t.) */
{const st=document.createElement('style');st.textContent=`.rph.rp7 .rpcard::after{z-index:1}.rph.rp7 .rpcard img{z-index:3}.rph.rp7 .rpcard .rpglo{z-index:0}
.rph.rp7 .rprb em,.rph.rp7 .rprb b,.rph.rp7 .rprb small,.rph.rp7 .rprb span{pointer-events:none}`;document.head.appendChild(st)}
const RPSAFE={x0:96,x1:1504,y0:128,y1:724};
{const g0=rpHudRing;rpHudRing=function(R,C){const was=C.rg;const r=g0.apply(this,arguments);try{if(C.rg!==was&&C.rg){const bs=[...$('rpring').querySelectorAll('.rprb')],p=R.selPad;if(p&&bs.length){
  const V=(b,v)=>parseFloat(b.style.getPropertyValue(v))||0,xs=bs.map(b=>p.x+V(b,'--x')),ys=bs.map(b=>p.y+V(b,'--y')),h=40;
  const lo=Math.min(...xs)-h,hi=Math.max(...xs)+h,top=Math.min(...ys)-h,bot=Math.max(...ys)+h;
  const dx=lo<RPSAFE.x0?RPSAFE.x0-lo:hi>RPSAFE.x1?RPSAFE.x1-hi:0,dy=top<RPSAFE.y0?RPSAFE.y0-top:bot>RPSAFE.y1?RPSAFE.y1-bot:0;
  if(dx||dy)bs.forEach(b=>{b.style.setProperty('--x',(V(b,'--x')+dx).toFixed(1)+'px');b.style.setProperty('--y',(V(b,'--y')+dy).toFixed(1)+'px')})}}}catch(e){console.error(e)}return r}}
/* the soaked badge: a round chip with the brew's potion symbol */
const rplBadge2=tier=>rpSpr('st|bd2|'+(tier>=5?5:tier===4?4:1),-12,-12,24,24,g=>{const B=rplBrew(tier);
 g.beginPath();g.arc(0,0,10.5,0,TAU);g.fillStyle='rgba(18,8,31,.92)';g.fill();g.lineWidth=1.8;g.strokeStyle=B.c;g.stroke();
 /* a little round flask: bulb, neck, cork, brew */
 g.beginPath();g.arc(0,2.6,5.2,0,TAU);g.fillStyle='rgba(220,250,240,.55)';g.fill();g.save();g.beginPath();g.arc(0,2.6,4.6,0,TAU);g.clip();g.fillStyle=B.c;g.fillRect(-6,1.6,12,8);g.restore();
 g.beginPath();g.arc(0,2.6,5.2,0,TAU);g.lineWidth=1.3;g.strokeStyle=RPTO;g.stroke();
 g.beginPath();g.rect(-1.9,-5.2,3.8,3.4);g.fillStyle='rgba(220,250,240,.7)';g.fill();g.stroke();g.fillStyle='#c98a4a';g.fillRect(-1.9,-7,3.8,2);
 g.fillStyle='rgba(255,255,255,.8)';g.beginPath();g.arc(-1.8,1.2,1.1,0,TAU);g.fill()});
rpStillBadge=function(g,x,y,melt,tier,a){if(a<=.01)return;g.globalAlpha=Math.min(1,a);rpPut(g,rplBadge2(tier),x,y);g.globalAlpha=1};
