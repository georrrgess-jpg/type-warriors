/* ===== MOONLIT FISHING: the screen, side panel and menus =====
   fishing() opens the pond: a full 1600x900 canvas (90d/90e) with HTML on top. Top left: the pond and tonight's moon.
   Top right: gold and Back. Bottom: the word box (cast prompt / word to type / timer ring) and the rod strip.
   The side panel has four tabs: Bestiary (filters, cards, a detail view per fish), Creel (kept fish, sell), Rod
   (upgrades for gold and rod looks crafted from kept fish) and Stats. A catch shows in the panel's Catch preview with
   Sell / Keep. It also adds Moonlit Fishing to the main menu (a NEW card) and takes Starfall Rift's spot in Choose a
   mode (Warden's Arena moves to a row under the cards). Press F on the main menu to go fishing. */
const FSU={tab:'b',flt:'all'};
const fsEsc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const fsCoin='<span class="fscoin" aria-hidden="true"></span>';
const fsPill=rk=>`<span class="fspill" style="--rc:${FSR[rk].c}">${FSR[rk].n}</span>`;
function fishing(){if(typeof ttLeave==='function'){}S.mode='fish';S.view='fish';fsP();const M=fsMoon();
 show(`<div class="fsx" id="fsx"><canvas id="fscv" width="1600" height="900" aria-label="The moonlit pond"></canvas>
 <div class="fstop fsg"><span class="fsmoonic" aria-hidden="true"><canvas id="fsmic" width="68" height="68"></canvas></span><div><h2>Moonlit Pond</h2><p><span class="fsfi" aria-hidden="true">${fsFishIc()}</span>Fish discovered <b id="fsfound">${fsFound()} / ${FIDS.length}</b></p>
  <p class="fsmn" title="${fsEsc(M.d)}"><b>${M.n}</b> · Featured: <span style="color:${FSR[FISH[M.feat].r].c}">${FISH[M.feat].n}</span> <em>×2 bites, +50% gold</em></p></div></div>
 <div class="fstr"><span class="fsgold fsg">${fsCoin}<b id="fsgold">${P.gold.toLocaleString()}</b></span><button class="fsback fsg" id="fsback"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 5l-7 7 7 7" stroke="currentColor" stroke-width="2.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>Back <kbd>Esc</kbd></button></div>
 <aside class="fsside fsg" id="fsside"><nav class="fstabs" role="tablist">${[['b','Bestiary'],['c','Creel'],['r','Rod'],['s','Stats']].map(([k,n])=>`<button role="tab" data-tab="${k}" aria-selected="${FSU.tab===k}">${n}${k==='c'?'<i id="fscrn"></i>':''}</button>`).join('')}</nav>
  <div class="fsbody" id="fsbody"></div><section class="fspv" id="fspv" hidden></section></aside>
 <div class="fsword" id="fsword"></div>
 <button class="fsrodp fsg" id="fsrodp" title="Upgrade your rod"><span class="fsrodic"><canvas id="fsric" width="120" height="70"></canvas></span><span class="fsrodt"><b id="fsrodn">${fsRodName()}</b><span class="fsbar"><i id="fsbari" style="width:${fsFound()/FIDS.length*100}%"></i></span></span><span class="fsrodc" id="fsrodc">${fsFound()} / ${FIDS.length} species</span><i class="fschev">›</i></button>
 <div class="fsban" id="fsban" aria-live="polite"></div><div class="fstoast" id="fstoast" aria-live="polite"></div>
 <div class="fsmod" id="fsmod" hidden></div></div>`,'fshx');
 S.back=fsLeave;fsStart();{const cn=$('cn');if(cn)cn.classList.add('dkhid')}
 const cv=$('fscv'),g=cv.getContext('2d');LIVE.push({cv,fn:()=>{try{fsFrame(g)}catch(e){console.error(e)}}});
 live('fsmic',c=>{const x=c.getContext('2d');return t=>{x.setTransform(1,0,0,1,0,0);x.clearRect(0,0,68,68);fsMoonIcon(x,34,34,24,fsMoon().ph,t)}});
 fsRodIcon();
 ov.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>{FSU.tab=b.dataset.tab;fsTabs()});
 $('fsback').onclick=fsLeave;$('fsrodp').onclick=()=>{FSU.tab='r';fsTabs()};
 cv.addEventListener('pointerdown',e=>{if(FS.st==='idle')fsCast();else if(FS.st==='show')fsSkip();else if(FS.st==='reel'){try{inp.focus()}catch(x){}}});
 fsTabs();fsHudState();
 const F=fsP();if(!F.seen){F.seen=1;save();setTimeout(()=>fsToast('Welcome to the pond! Press Space (or tap the water) to cast.'),600)}}
function fsLeave(){if(FS.st==='reveal'&&FS.pend){const c=FS.pend;if(!fsDefKeep(c)||!fsKeep(c))fsSell(c);FS.pend=null}fsStop();try{title()}catch(e){}}
/* ---------- small art ---------- */
function fsFishIc(){return `<svg viewBox="0 0 40 24" width="30" height="18"><path d="M4 12C10 3 22 2 30 9L37 4V20L30 15C22 22 10 21 4 12Z" fill="#ffd45a" stroke="#1b1024" stroke-width="2.2" stroke-linejoin="round"/><circle cx="12" cy="10" r="2.2" fill="#1b1024"/></svg>`}
function fsMoonIcon(g,x,y,r,ph,t){fkGlow(g,x,y,r*1.5,'#c8b8ff',.35+.1*Math.sin(t*1.5));g.save();g.beginPath();g.arc(x,y,r,0,TAU);g.fillStyle='#262060';g.fill();g.clip();
 const k=ph/8;/* lit part: 0 new .. .5 full .. 1 new */const lit=k<=.5?k*2:2-k*2,dir=k<=.5?1:-1;g.fillStyle=fkRad(g,x,y,r,['#fffdf0','#f6eccc','#d8ccaa']);
 if(lit>.98){g.beginPath();g.arc(x,y,r,0,TAU);g.fill()}else if(lit>.02){g.beginPath();g.arc(x,y,r,-Math.PI/2,Math.PI/2,dir<0);const w=r*(1-2*lit);g.ellipse(x,y,Math.abs(w),r,0,Math.PI/2,-Math.PI/2,(w>0)===(dir>0));g.fill()}
 g.restore();g.lineWidth=2.4;g.strokeStyle='#1b1024';g.beginPath();g.arc(x,y,r,0,TAU);g.stroke()}
function fsRodIcon(){const c=$('fsric');if(!c)return;const g=c.getContext('2d');g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,120,70);fsRod(g,24,58,-.42,0,96,0,fsSkin());}
function fsThumb(cv,id,sil,t,sc){const g=cv.getContext('2d');g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,cv.width,cv.height);fishFit(g,id,cv.width/2,cv.height/2,cv.width*.94,cv.height*.94,{t:t||.4,sil:sil?(sc||'#0a0620'):0})}
/* ---------- HUD ---------- */
function fsHudRefresh(){const gd=$('fsgold');if(gd)gd.textContent=P.gold.toLocaleString();const n=fsFound();const fo=$('fsfound');if(fo)fo.textContent=`${n} / ${FIDS.length}`;
 const rc=$('fsrodc');if(rc)rc.textContent=`${n} / ${FIDS.length} species`;const bi=$('fsbari');if(bi)bi.style.width=(n/FIDS.length*100)+'%';const rn=$('fsrodn');if(rn)rn.textContent=fsRodName();
 const cn=$('fscrn');if(cn)cn.textContent=fsP().cr.length?fsP().cr.length:'';fsRodIcon()}
function fsHudState(){const w=$('fsword');if(!w)return;const st=FS.st;
 if(st==='idle')w.innerHTML=`<button class="fscast" id="fscast"><span class="fscasti" aria-hidden="true">${fsFishIc()}</span>Cast your line <kbd>Space</kbd></button>`,$('fscast').onclick=fsCast;
 else if(st==='cast'||st==='wait')w.innerHTML=`<p class="fswait"><span class="fsdots"><i></i><i></i><i></i></span>Waiting for a bite…</p>`;
 else if(st==='reel'||st==='stage')fsHudWord();
 else if(st==='show'||st==='escape')w.innerHTML='';
 else if(st==='reveal')w.innerHTML=`<p class="fswait fsdec">Sell or keep your catch</p>`}
function fsHudWord(miss){const w=$('fsword');if(!w||!FS.cur)return;if(FS.st!=='reel'&&FS.st!=='stage'){if(FS.st==='show')w.innerHTML='';return}
 const rk=FS.cur.rk,R=FSR[rk],word=FS.word,done=word.slice(0,FS.typed),left=word.slice(FS.typed),stg=R.st>1?`<span class="fsstg">${FS.words.map((x,i)=>`<i class="${i<FS.si?'ok':i===FS.si?'on':''}"></i>`).join('')}</span>`:'';
 const hearts=R.hp>1?`<span class="fshp">${Array.from({length:R.hp},(_,i)=>`<i class="${i<FS.hp?'':'lost'}">♥</i>`).join('')}</span>`:'';
 if(!w.querySelector('.fswb')||w.dataset.k!==FS.si+':'+word){w.dataset.k=FS.si+':'+word;w.innerHTML=`<p class="fsprm">${rk==='l'?'<b style="color:#ffd45a">A LEGENDARY FISH!</b> ':rk==='r'?'<b style="color:#5ab8ff">A rare fish!</b> ':''}Type the word before it escapes!${stg}${hearts}</p>
  <div class="fswb fsg" style="--rc:${R.c}"><i class="fsdia l"></i><span class="fswt" id="fswt"></span><i class="fsdia r"></i></div>
  <div class="fsring" id="fsring"><svg viewBox="0 0 100 100" aria-hidden="true"><circle cx="50" cy="50" r="42" class="bg"/><circle cx="50" cy="50" r="42" class="fg" id="fsrfg" pathLength="100"/></svg><b id="fsrt"></b></div>`;
  w.querySelector('.fswb').onclick=()=>{try{inp.focus()}catch(e){}};w.querySelector('.fswb').classList.add('in')}
 const wt=$('fswt');if(wt)wt.innerHTML=`<span class="d">${fsEsc(done)}</span><span class="n">${fsEsc(left)}</span>`;
 if(miss){const b=w.querySelector('.fswb');b.classList.remove('miss');void b.offsetWidth;b.classList.add('miss')}fsHudTimer()}
function fsHudTimer(){const fg=$('fsrfg'),tt=$('fsrt'),r=$('fsring');if(!fg)return;const k=Math.max(0,FS.tLeft/FS.tMax);fg.style.strokeDashoffset=(100-k*100).toFixed(1);if(tt)tt.textContent=Math.ceil(FS.tLeft)+'s';if(r)r.classList.toggle('low',FS.tLeft<1.6)}
/* big banner (catch, the line holds, escape) */
function fsBanner(t,sub,col,dur,rk){const b=$('fsban');if(!b)return;b.className='fsban '+(rk?'r'+rk:'');b.style.setProperty('--rc',col||'#ffd45a');b.innerHTML=`${t?`<b>${fsEsc(t)}</b>`:''}${sub?`<span>${fsEsc(sub)}</span>`:''}`;void b.offsetWidth;b.classList.add('on');clearTimeout(b._t);b._t=setTimeout(()=>b.classList.remove('on'),(dur||1.3)*1000)}
function fsToast(m,gold){const b=$('fstoast');if(!b)return;b.innerHTML=(gold?fsCoin:'')+fsEsc(m);b.classList.remove('on');void b.offsetWidth;b.classList.add('on');clearTimeout(b._t);b._t=setTimeout(()=>b.classList.remove('on'),2400)}
/* ---------- the catch preview ---------- */
function fsPreview(c){const p=$('fspv');if(!p)return;if(!c){p.hidden=true;p.innerHTML='';fsHudState();return}
 const f=FISH[c.id],R=FSR[c.rk],I=c.info||{},dk=fsDefKeep(c),full=fsP().cr.length>=FSCREEL,mid=(f.len[0]+f.len[1])/2;
 const tags=[I.first?'<span class="fstag new">NEW!</span>':'',I.record?'<span class="fstag rec">NEW RECORD</span>':'',c.g?'<span class="fstag gi">GIANT</span>':'',c.id===fsMoon().feat?'<span class="fstag ft">FEATURED +50%</span>':''].join('');
 p.hidden=false;p.style.setProperty('--rc',R.c);p.className='fspv r'+c.rk;
 p.innerHTML=`<h4>Catch preview</h4><div class="fspvc"><canvas id="fspvcv" width="300" height="190"></canvas><div class="fspvt"><b>${f.n}</b>${fsPill(c.rk)}<span class="fscm">${c.cm} cm <small>${c.cm>mid*1.15?'· big one!':c.cm<mid*.8?'· a little one':''}</small></span><span class="fstags">${tags}</span></div></div>
  <div class="fspvb"><button class="fssell${dk?'':' def'}" id="fssell">${fsCoin}Sell · ${c.val.toLocaleString()}${dk?'':' <kbd>Space</kbd>'}</button><button class="fskeep${dk?' def':''}" id="fskeep" ${full?'disabled title="Your creel is full"':''}><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8h16l-2 11H6z" fill="currentColor" opacity=".85"/><path d="M8 8V6a4 4 0 0 1 8 0v2" stroke="currentColor" stroke-width="2" fill="none"/></svg>Keep${dk?' <kbd>Space</kbd>':''}</button></div>
  <button class="fsrecl" id="fsrecl">View in the Fish Bestiary ›</button>`;
 $('fssell').onclick=()=>fsDecide(false);$('fskeep').onclick=()=>fsDecide(true);$('fsrecl').onclick=()=>fsDetail(c.id);
 live('fspvcv',cv=>{const g=cv.getContext('2d');return t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,300,190);fkGlow(g,150,95,110,R.c,.18+.06*Math.sin(t*2));fishFit(g,c.id,150,95,280,170,{t,glow:R.k>=2?.6:0})}});
 fsHudRefresh();fsHudState();if(FSU.tab==='b')fsTabs()}
/* ---------- side panel tabs ---------- */
function fsTabs(){const b=$('fsbody');if(!b)return;ov.querySelectorAll('[data-tab]').forEach(x=>x.setAttribute('aria-selected',x.dataset.tab===FSU.tab));
 b.innerHTML=FSU.tab==='b'?fsBestHTML():FSU.tab==='c'?fsCreelHTML():FSU.tab==='r'?fsRodHTML():fsStatsHTML();b.scrollTop=0;
 if(FSU.tab==='b'){b.querySelectorAll('[data-flt]').forEach(x=>x.onclick=()=>{FSU.flt=x.dataset.flt;fsTabs()});b.querySelectorAll('[data-fish]').forEach(x=>{const id=x.dataset.fish,F=fsP().b[id],cv=x.querySelector('canvas');fsThumb(cv,id,!(F&&F.n));x.onclick=()=>fsDetail(id)})}
 if(FSU.tab==='c'){b.querySelectorAll('[data-ci]').forEach(x=>{const c=fsP().cr[+x.dataset.ci];const cv=x.querySelector('canvas');if(c&&cv)fsThumb(cv,c.id)});
  b.querySelectorAll('[data-sell]').forEach(x=>x.onclick=()=>{const v=fsSellCreel(+x.dataset.sell);fsSfx('sell');fsToast(`Sold for ${v.toLocaleString()} gold.`,1);fsHudRefresh();fsTabs()});
  const sa=$('fssa');if(sa)sa.onclick=()=>{if(!sa.dataset.ok){sa.dataset.ok=1;sa.textContent='Tap again to sell all';setTimeout(()=>{if(sa.isConnected){delete sa.dataset.ok;fsTabs()}},2600);return}const F=fsP();let v=0;const keep=[];F.cr.forEach(c=>{if(FSR[FISH[c.id].r].k>=3)keep.push(c);else v+=fsSell(c)});F.cr=keep;save();fsSfx('sell');fsToast(`Sold your catch for ${v.toLocaleString()} gold${keep.length?' (legendary fish kept)':''}.`,1);fsHudRefresh();fsTabs()}}
 if(FSU.tab==='r'){b.querySelectorAll('[data-up]').forEach(x=>x.onclick=()=>{if(fsBuyUp(x.dataset.up)){fsSfx('buy');fsToast(`${FSUP[x.dataset.up].n} upgraded! Your rod is now the ${fsRodName()}.`);fsHudRefresh();fsTabs()}});
  b.querySelectorAll('[data-sk]').forEach(x=>{const k=x.dataset.sk,cv=x.querySelector('canvas');if(cv){const g=cv.getContext('2d');g.clearRect(0,0,cv.width,cv.height);fsRod(g,14,cv.height-12,-.38,0,cv.width*.86,0,FSKIN[k])}
   const bt=x.querySelector('button');if(bt)bt.onclick=()=>{const F=fsP();if(F.sk[k]){F.skin=k;save();fsToast(`${FSKIN[k].n} rod equipped.`)}else if(fsCraft(k)){fsSfx('r');fsToast(`You crafted the ${FSKIN[k].n} rod!`)}fsHudRefresh();fsTabs()}});
  b.querySelectorAll('[data-req]').forEach(x=>{const cv=x.querySelector('canvas');if(cv)fsThumb(cv,x.dataset.req,!(fsP().b[x.dataset.req]&&fsP().b[x.dataset.req].n),.4,'#5a4ca0')});
  const rv=$('fsrv');if(rv){const g=rv.getContext('2d');g.clearRect(0,0,rv.width,rv.height);fsRod(g,30,rv.height-20,-.3,0,rv.width*.8,0,fsSkin())}}}
function fsBestHTML(){const F=fsP(),ids=FIDS.filter(id=>FSU.flt==='all'||FISH[id].r===FSU.flt),n=fsFound();
 return `<div class="fsbh"><h3>Fish Bestiary</h3><span>${n} / ${FIDS.length} discovered</span></div>
 <div class="fsflt">${[['all','All'],...FSRK.map(k=>[k,FSR[k].n])].map(([k,l])=>`<button data-flt="${k}" class="${FSU.flt===k?'on':''}" style="--rc:${k==='all'?'#8a7ad8':FSR[k].c}">${l}</button>`).join('')}</div>
 <div class="fsgrid">${ids.map(id=>{const f=FISH[id],b=F.b[id],got=b&&b.n;return `<button class="fscard${got?'':' unk'}${FS.pend&&FS.pend.id===id?' cur':''}" data-fish="${id}" style="--rc:${FSR[f.r].c}" aria-label="${got?f.n:'Undiscovered fish'}, ${FSR[f.r].n}"><canvas width="180" height="96"></canvas><b>${got?f.n:'???'}</b>${fsPill(f.r)}${got?`<small>×${b.n} · best ${b.big} cm${b.g?' · <span class="fscrown">♛</span>':''}</small>`:'<small>Not caught yet</small>'}</button>`}).join('')}</div>`}
function fsCreelHTML(){const F=fsP(),L=F.cr.map((c,i)=>({c,i})).sort((a,b)=>FSR[FISH[b.c.id].r].k-FSR[FISH[a.c.id].r].k||fsValue(b.c)-fsValue(a.c)),tot=F.cr.reduce((a,c)=>a+fsValue(c),0);
 return `<div class="fsbh"><h3>Your Creel</h3><span>${F.cr.length} / ${FSCREEL} fish</span></div>
 <p class="fsnote">Kept fish wait here. Sell them any time, or turn them in for rod looks in the Rod tab.</p>
 ${F.cr.length?`<button class="fssa" id="fssa">${fsCoin}Sell all · ${tot.toLocaleString()}</button>`:''}
 <div class="fslist">${L.length?L.map(({c,i})=>{const f=FISH[c.id];return `<div class="fsrow" data-ci="${i}" style="--rc:${FSR[f.r].c}"><canvas width="96" height="56"></canvas><span><b>${f.n}${c.g?' <span class="fscrown">♛</span>':''}</b><small>${FSR[f.r].n} · ${c.cm} cm</small></span><button data-sell="${i}">${fsCoin}${fsValue(c).toLocaleString()}</button></div>`}).join(''):'<p class="fsempty">Your creel is empty. Choose <b>Keep</b> after a catch to store a fish here.</p>'}</div>`}
function fsRodHTML(){const F=fsP(),l=fsLv();
 const ups=FSUPK.map(k=>{const U=FSUP[k],lv=F.up[k]||0,c=fsUpCost(k);return `<div class="fsup"><div class="fsupt"><b>${U.n}</b><span class="fspips">${[0,1,2,3,4].map(i=>`<i class="${i<lv?'on':''}"></i>`).join('')}</span></div><small>${U.d}</small><small class="fsupfx">Now: ${U.fx(lv)}${c!=null?` → <b>${U.fx(lv+1)}</b>`:''}</small>
  ${c==null?'<span class="fsmax">MAX</span>':`<button data-up="${k}" ${P.gold<c?'disabled':''}>${fsCoin}${c.toLocaleString()}</button>`}</div>`}).join('');
 const skins=FSKINK.map(k=>{const K=FSKIN[k],own=F.sk[k],eq=F.skin===k,can=fsCanSkin(k);const req=Object.entries(K.k).map(([id,n])=>{const have=F.cr.filter(c=>c.id===id).length;return `<span class="fsreq${have>=n?' ok':''}" data-req="${id}" title="${FISH[id].n}"><canvas width="44" height="26"></canvas>${Math.min(have,n)}/${n}</span>`}).join('');
  return `<div class="fssk${eq?' eq':''}" data-sk="${k}" style="--sc:${K.gl||K.c[1]}"><canvas width="150" height="60"></canvas><div><b>${K.n}</b><small>${K.d}</small>${own?'':`<span class="fsreqs">${req}</span>`}</div>${eq?'<span class="fseq">Equipped</span>':own?'<button>Equip</button>':`<button ${can?'':'disabled'}>Turn in</button>`}</div>`}).join('');
 return `<div class="fsrodh"><canvas id="fsrv" width="360" height="90"></canvas><div><h3>${fsRodName()}</h3><span>Level ${l} / 15</span></div></div>
 <h4 class="fssub">Upgrades</h4>${ups}<h4 class="fssub">Rod looks <small>turn in kept fish</small></h4><div class="fsskins">${skins}</div>`}
function fsStatsHTML(){const s=fsP().s,cast=s.cast||0,cau=s.caught||0,rate=cast?Math.round(cau/Math.max(1,cau+(s.esc||0))*100):0,big=s.bigId?`${FISH[s.bigId].n}`:'—';
 const T=[['Fish caught',cau.toLocaleString(),`${cast.toLocaleString()} casts`],['Catch rate',cau?rate+'%':'—',`${(s.esc||0).toLocaleString()} got away`],['Species found',`${fsFound()} / ${FIDS.length}`,'in the Bestiary'],
  ['Legendary catches',(s.leg||0).toLocaleString(),'Aurora Koi, Moonmaw, Tidecrown'],['Giants caught',(s.giant||0).toLocaleString(),'the biggest 4%'],['Best streak',(s.best||0).toLocaleString(),'catches in a row'],
  ['Fastest reel',s.fast?Math.round(s.fast*12)+' WPM':'—','typing speed on one catch'],['Biggest catch',big,s.bigId?`${s.bigCm} cm`:'catch something big!'],['Gold from fishing',(s.gold||0).toLocaleString(),'from selling fish']];
 return `<div class="fsbh"><h3>Fishing Stats</h3></div><div class="fsstats">${T.map(([a,b,c])=>`<div><small>${a}</small><b>${fsEsc(b)}</b><em>${fsEsc(c)}</em></div>`).join('')}</div>`}
/* ---------- fish detail ---------- */
function fsDetail(id){const f=FISH[id],b=fsP().b[id],got=b&&b.n,R=FSR[f.r],mid=(f.len[0]+f.len[1])/2,lo=fsValue({id,cm:f.len[0],g:0}),hi=fsValue({id,cm:f.len[1],g:0});
 fsModal(`<div class="fsdet" style="--rc:${R.c}"><button class="fsx2" id="fsx2" aria-label="Close">✕</button><canvas id="fsdcv" width="560" height="330"></canvas>
  <div class="fsdt"><h3>${got?f.n:'???'}</h3>${fsPill(f.r)}${id===fsMoon().feat?'<span class="fstag ft">FEATURED TONIGHT</span>':''}<p>${got?fsEsc(f.d):'You have not caught this fish yet. Its shape is all anyone has seen.'}</p>
  <div class="fsdst"><span><small>Caught</small><b>${got?b.n:0}</b></span><span><small>Record</small><b>${got?b.big+' cm':'—'}</b></span><span><small>Giants</small><b>${got?(b.g||0):0}</b></span><span><small>Size</small><b>${f.len[0]}–${f.len[1]} cm</b></span><span><small>Worth</small><b>${lo}–${hi}</b></span></div></div></div>`);
 $('fsx2').onclick=()=>fsModal(null);live('fsdcv',cv=>{const g=cv.getContext('2d');return t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,560,330);fkGlow(g,280,165,230,R.c,got?.2:.08);fishFit(g,id,280,165,520,300,{t,sil:got?0:'#0a0620',glow:R.k>=2?.5:0})}})}
function fsModal(h){const m=$('fsmod');if(!m)return;if(!h){m.hidden=true;m.innerHTML='';LIVE=LIVE.filter(l=>l.cv&&l.cv.isConnected);return}m.innerHTML=h;m.hidden=false;m.onclick=e=>{if(e.target===m)fsModal(null)}}
/* ---------- main menu, mode picker and the F key ---------- */
{const t0=title;title=function(){const r=t0.apply(this,arguments);try{fsHomeCard()}catch(e){console.error(e)}return r}}
function fsHomeCard(){const sc=ov.querySelector('.dksc');if(!sc||sc.querySelector('#dkfish'))return;const F=fsP(),n=fsFound();
 sc.classList.add('dks3');const d=document.createElement('div');d.innerHTML=`<button class="dkcard dkfish dklive dkg dktilt" id="dkfish" title="Moonlit Fishing (F)" aria-label="Moonlit Fishing, new mode. ${n} of ${FIDS.length} fish discovered"><canvas class="dkcv" width="560" height="320" aria-hidden="true"></canvas><i class="dkgl"></i><em class="dknew">NEW</em><span class="dkcl"><small>NEW MODE</small><b>Moonlit Fishing</b><small class="dkevv">${n?`${n} / ${FIDS.length} fish`:'Cast a line'} <i>›</i></small></span></button>`;
 const card=d.firstChild;sc.insertBefore(card,sc.children[1]||null);card.onclick=fishing;
 const cv=card.querySelector('canvas'),g=cv.getContext('2d');const draw=t=>{try{fsCardScene(g,560,320,t)}catch(e){}};draw(2);if(!(typeof dkRM==='function'&&dkRM()))LIVE.push({cv,fn:draw,slow:2})}
/* the home card's little scene: the pond crop with a fish leaping every few seconds */
let FSCARD=null;
function fsCardScene(g,w,h,t){if(!FSBG)FSBG=fsBGBuild();if(!FSCARD||FSCARD.width!==w){FSCARD=document.createElement('canvas');FSCARD.width=w;FSCARD.height=h;const c=FSCARD.getContext('2d');c.filter='brightness(1.9) saturate(1.3)';c.drawImage(FSBG,600,110,800,457,0,0,w,h);c.filter='none';fkGlow(c,w*.41,h*.11,w*.3,'#fff2c8',.25)}
 g.setTransform(1,0,0,1,0,0);g.drawImage(FSCARD,0,0);
 const k=w/800;g.save();g.globalCompositeOperation='lighter';for(let i=0;i<14;i++){const u=i/14,y=(FSW_Y-110+10+u*u*330)*k,ww=(14+u*80)*(.6+.4*Math.sin(t*1.3+i*1.7))*k,x=(930-600+u*40+Math.sin(t*.9+i*2.3)*(8+u*30))*k;g.globalAlpha=(.5-u*.3)*(.5+.5*Math.sin(t*2+i));g.fillStyle='#fff4d0';g.fillRect(x-ww/2,y,ww,2)}g.restore();g.globalAlpha=1;
 const cyc=(t%4.2)/4.2,ids=['moonfin','aurora','ember','cinder'],id=ids[Math.floor(t/4.2)%4];if(FISHART[id]&&cyc<.42){const u=cyc/.42,x=w*.56+u*w*.32,y=h*.8-Math.sin(u*Math.PI)*h*.46;g.save();g.translate(x,y);g.rotate((u-.5)*1.1);g.scale(.42,.42);fishDraw(g,id,{t,flex:.6});g.restore();if(u>.9||u<.1)fkGlow(g,u<.5?w*.56:w*.88,h*.82,30,'#ffffff',.3)}
 const q=g.createLinearGradient(0,0,w,0);q.addColorStop(0,'#0c0822c0');q.addColorStop(.45,'#0c082230');q.addColorStop(1,'#0c082200');g.fillStyle=q;g.fillRect(0,0,w,h)}
{const m0=modeSheet;modeSheet=function(view){const r=m0.apply(this,arguments);try{const sh=document.querySelector('.dks .dkpv[data-v="m"]')||document.querySelector('.dkpv[data-v="m"]');const b=sh&&sh.querySelector('#dma');
  if(b&&!b.dataset.fish){b.dataset.fish=1;b.style.setProperty('--c','#7ad8ff');b.style.removeProperty('--img');b.removeAttribute('disabled');const ic=b.querySelector('.dkmi');if(ic)ic.innerHTML=`<svg viewBox="0 0 60 60" width="58" height="58"><circle cx="30" cy="30" r="27" fill="#1c1446" stroke="#5a4ca0" stroke-width="2"/><circle cx="40" cy="18" r="7" fill="#fff4d0"/><path d="M10 34C18 24 32 23 41 31L50 25V43L41 37C32 45 18 44 10 34Z" fill="#5ad8e8" stroke="#1b1024" stroke-width="2.4" stroke-linejoin="round"/><circle cx="18" cy="32" r="2.6" fill="#1b1024"/><path d="M8 48Q30 42 52 48" stroke="#8ab0ff" stroke-width="2" fill="none" opacity=".7"/></svg>`;
   const tt=b.querySelector('.dkmt');if(tt)tt.innerHTML=`<b>Moonlit Fishing <em class="dkmnew">NEW</em></b><small>Cast, wait, type the word. Catch all ${FIDS.length} fish.</small>`;
   const nb=b.cloneNode(true);b.replaceWith(nb);nb.onclick=()=>{dkClose(true);setTimeout(fishing,0)};
   const pr=sh.querySelector('#dmp');if(pr&&ARENA_ON&&!sh.querySelector('#dmwa')){const wa=document.createElement('button');wa.className='dkpr2';wa.id='dmwa';wa.innerHTML=`${mico('dplay',34)}<span><b>Warden's Arena</b><small>Block, counter, survive. No typing needed.</small></span><i class="dkchv">›</i>`;pr.after(wa);wa.onclick=()=>{dkClose(true);setTimeout(()=>waMenu(title),0)}}}}catch(e){console.error(e)}return r}}
{const hk0=homeKey;homeKey=function(e){if(HOME&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&(e.key==='f'||e.key==='F')&&!document.querySelector('.dks.on')){const ae=document.activeElement;if(!(ae&&ae!==inp&&/INPUT|TEXTAREA|SELECT/.test(ae.tagName))){e.preventDefault();fishing();return true}}return hk0.apply(this,arguments)}}
/* How to play */
try{HELP.Modes.unshift(['Moonlit Fishing','New! A calm break at the tavern pond. Press Space to cast, wait for a bite, then type the word before the fish slips away. Rare fish bring longer words and more reeling stages. Sell catches for gold or keep them to turn in for rod looks, and spend gold on Line, Lure and Hook upgrades. Tonight\'s moon changes daily.']);HELP.Shortcuts.push(['F','Moonlit Fishing from the main menu.'])}catch(e){}
