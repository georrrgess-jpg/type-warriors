/* ===== CELESTIAL CHEST: economy and menus =====
   - Shop: 5,000 gold.  - Astral levels: the first clear of each level on each prestige pays one chest; the last level (33) pays three.
   - Crates hub: a feature card with Open / Open 10. */
CN.c='ccr';CT.c='Celestial Chest added!';CRN.c='Celestial Chest';PRICE.c=5000;
SHOP.splice(Math.max(0,SHOP.findIndex(o=>o.k==='p')),0,{k:'c',n:'Celestial Chest',d:'Rare or better weapons, every time. The only home of the Astral Cleaver and the Orbitbreaker.'});
/* P.ccr is the owned count; keep it a clean integer on every screen and every save */
{const sh0=show;show=function(){try{if(P&&typeof P==='object')P.ccr=P.ccr|0}catch(e){}return sh0.apply(this,arguments)}}
{const sv0=save;save=function(){try{if(P&&typeof P==='object')P.ccr=Math.max(0,P.ccr|0)}catch(e){}return sv0.apply(this,arguments)}}

/* ---------- first clear rewards ---------- */
const cxReward=n=>n===33?3:1;
{const av=astVictory;astVictory=function(){const n=S.camp,A=AP(),key=n+':'+(P.pres||0);A.cxg=A.cxg||{};let gain=0;
  if(!A.cxg[key]){A.cxg[key]=1;gain=cxReward(n);P.ccr=(P.ccr|0)+gain;try{stat('ccg',gain,'add')}catch(e){}save()}
  const r=av.apply(this,arguments);
  if(gain){const l0=S.late;S.late=function(){l0();cxVictoryBanner(gain)}}
  return r}}
function cxVictoryBanner(n){try{const row=ov.querySelector('.row');if(!row)return;const d=document.createElement('div');d.className='cxwin';
 d.innerHTML=`<canvas width="170" height="130"></canvas><div><b>+${n} Celestial Chest${n>1?'s':''}</b><span>${n>1?'The summit of the heavens pays three.':'Your first clear of this level on this prestige.'}</span></div><button class="gd" id="cxo">Open now</button>`;
 row.parentNode.insertBefore(d,row);const cv=d.querySelector('canvas'),g=cv.getContext('2d');LIVE.push({cv,fn:t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,170,130);try{cxChest(g,85,118,1.05,0,t)}catch(e){}},slow:1});
 cxLoad();$('cxo').onclick=()=>{if(P.ccr>0)crateStart('c')}}catch(e){}}

/* ---------- the Crates hub tile (sits between the Special crate and the Eclipse Chest) ---------- */
{const h0=crateHub;crateHub=function(){h0.apply(this,arguments);try{cxLoad();const nc=P.ccr|0,host=ov.querySelector('.chub');if(!host)return;const cc=host.querySelectorAll('.cc'),d=document.createElement('div');d.className='cc cxt'+(nc?'':' e');d.style.setProperty('--c','#8a7aff');
  d.innerHTML=`<canvas width="220" height="170"></canvas><b>Celestial Chest</b><small>Rare or better weapons</small><span class="ccn">You own ${nc}</span><span class="ccb"><button class="sm" id="cxop" ${nc?'':'disabled'}>Open</button>${nc>=10?'<button class="sm gd" id="cxop10" title="Open ten at once">Open 10</button>':''}</span>`;
  d.title='Win one the first time you clear each Astral level on every prestige (the last level pays three), or buy one in the Shop.';
  host.insertBefore(d,cc[3]||null);host.classList.add('c5');const cv=d.querySelector('canvas'),g=cv.getContext('2d');LIVE.push({cv,fn:t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,220,170);try{cxChest(g,110,160,1.02,0,t)}catch(e){}},slow:1});
  $('cxop').onclick=()=>crateStart('c');if($('cxop10'))$('cxop10').onclick=()=>crateBatch('c',10)}catch(e){try{devLog('error','celestial hub: '+e)}catch(x){}}}}

/* ---------- styles ---------- */
{const st=document.createElement('style');st.textContent=`
.shopg{flex-wrap:wrap}#ov.sh .shopg .sc{flex:1 1 214px;width:auto;max-width:292px;min-width:200px;box-sizing:border-box}.shopg .sc canvas{max-width:100%;height:auto}.sc.kc{height:auto;font:400 34px 'Pirata One',Georgia,serif;color:inherit;opacity:1;justify-content:flex-start}.sc.kc small{font:15px/1.4 Georgia,serif;opacity:.9;min-height:64px;text-align:center;color:inherit;display:block}.sc.kc:hover{box-shadow:0 8px 0 #0009,0 0 26px #7a6ae055}
.sc.kc{--c:#8a7aff;border-color:#6a5ac8;background:linear-gradient(180deg,#1a1a4a,#0d0d30)}

.chub.c5{grid-template-columns:repeat(5,minmax(0,236px));gap:14px}.chub .cc.cxt{box-shadow:0 0 22px #6a5ae044}.chub .cc.cxt:not(.e):hover{box-shadow:0 0 34px #8a7aff99,0 16px 26px #000a}
.cxwin{display:flex;align-items:center;justify-content:center;gap:14px;margin:12px auto 6px;padding:8px 22px 8px 8px;max-width:640px;border-radius:18px;border:2px solid #8a7aff;background:radial-gradient(120% 160% at 0% 50%,#2a2a7a,#0f1038);box-shadow:0 0 28px #6a5ae066;text-align:left;animation:cxpop .5s cubic-bezier(.2,1.4,.4,1) both}
.cxwin canvas{width:120px;height:92px;flex:none}.cxwin b{display:block;font:700 24px Cinzel,Georgia,serif;color:#f0e6ff;text-shadow:0 0 16px #9a7aff}.cxwin span{display:block;color:#bfc4f2;font:400 14px Georgia,serif;margin-top:2px}.cxwin button{margin-left:auto;font-size:17px;padding:9px 20px}
@keyframes cxpop{from{opacity:0;transform:translateY(14px) scale(.92)}to{opacity:1;transform:none}}
`;
 document.head.appendChild(st)}
