/* ===== WILDCARD: the Dragon Lounge regulars — monsters in their sharpest suits =====
   Every opponent is drawn live on a canvas in the game's chunky storybook style (dark #12081f outlines, a darker right
   half, small upper-left highlights). Eight species (dragon, goblin, orc, skeleton, lizard, wolf, frog, octopus) wear
   randomised suits, ties, hats and eyewear, and hold a fan of cards, a chip, a martini or dice. Names are drawn at random
   for every game, so each table is a new crowd. wcCrewGen(n) makes a lineup; wcCrewDraw(g, A, t) paints one figure with
   its feet at 0,0 (about 230 units tall), animated by t (breathing, blinking, a flipping chip). */
const WCO='#12081f';
const WCSP={
 dragon:{skin:['#e8452e','#9a1e14'],belly:'#ffd9a0',hats:['','','top'],eyes:['','','mono'],hand:'claw',last:['Scales','Emberjaw','Goldhoard','Flametooth','Wyrmsley']},
 goblin:{skin:['#7ac04a','#3e7a22'],hats:['bowler','fedora',''],eyes:['','shades',''],hand:'mitt',last:['Nickels','Grinbag','Pockets','Sticky','Jackpot']},
 orc:{skin:['#8aa86a','#4a6a32'],hats:['','fedora'],eyes:['shades','shades',''],hand:'mitt',last:['Tusk','Knuckles','Brick','Grimtooth','Bulldog']},
 skel:{skin:['#f4ead2','#c8b896'],hats:['top','top',''],eyes:['mono','',''],hand:'bone',last:['Bones','Marrow','Rattles','Skully','Femur']},
 lizard:{skin:['#2fb8a0','#14685a'],frill:['#ff8a3a','#ffd45a','#ff5a9a'],hats:['visor','visor',''],eyes:['',''],hand:'claw',last:['Vex','Hiss','Slithers','Scaleway','Croupier']},
 wolf:{skin:['#9a8aa8','#5a4a6a'],muzzle:'#efe6f4',hats:['','fedora',''],eyes:['','shades'],hand:'claw',last:['Howl','Moonfang','Lupo','Silvermane','Growler']},
 frog:{skin:['#5ac85a','#2a7a2a'],hats:['top','',''],eyes:['','mono'],hand:'frog',last:['Ribbit','Croaker','Lilypad','Bullfrog','Hopwell']},
 octo:{skin:['#b05ad8','#5a2a8a'],hats:['','bowler'],eyes:['mono',''],hand:'tent',last:['Inkwell','Eightfold','Tentaclé','Squidley','Suckerpunch']}};
const WCSPK=Object.keys(WCSP);
const WCSUIT=[['#2c2c3e','#16161f','Charcoal'],['#6a1a34','#300814','Burgundy'],['#1e3a72','#0e1c3a','Navy'],['#4a2a86','#22124a','Velvet'],['#f2eee4','#bcb4a2','White'],['#1a5a3a','#0a2a1a','Emerald'],['#c8962a','#7a5410','Gold'],['#8a1c1c','#3e0808','Crimson']];
const WCTIE=['#ffd45a','#e8384a','#12081f','#2fb8a0','#9a5cff','#ff8a3a'];
const WCFIRST=['Lucky','Slick','Big','Velvet','Diamond','Ace','Baron','Madame','Count','Fancy','Smooth','Sly','Dapper','Jolly','Golden','Midnight','Duke','Lady','Snake-Eyes','High-Roller','Dealer','Sir','Two-Card','Chips'];
/* a fresh lineup of n regulars: different species, random outfits and names */
function wcCrewGen(n,rnd){const r=rnd||Math.random,pick=a=>a[Math.floor(r()*a.length)],sp=WCSPK.slice().sort(()=>r()-.5).slice(0,n),used=new Set();
 return sp.map((k,i)=>{const D=WCSP[k];let suit=pick(WCSUIT);if(k==='skel'&&suit[2]==='White')suit=WCSUIT[0];
  let first;do first=pick(WCFIRST);while(used.has(first)&&used.size<WCFIRST.length);used.add(first);
  const A={t:'crew',sp:k,suit:suit[0],suit2:suit[1],tie:pick(WCTIE),tk:pick(['tie','bow','bow','tie']),hat:pick(D.hats),eye:pick(D.eyes),hold:pick(['cards','chip','glass','dice','cards']),chain:r()<.35,seed:Math.floor(r()*1000),frill:D.frill?pick(D.frill):null};
  if(A.hat==='visor'&&k!=='lizard')A.hat='';A.name=first+' '+pick(D.last);return A})}
/* --- tiny drawing helpers --- */
function wcSt2(g,lw){g.lineWidth=lw||3;g.strokeStyle=WCO;g.lineJoin='round';g.lineCap='round';g.stroke()}
function wcFS(g,fill,sx,lw,dk){g.fillStyle=fill;g.fill();if(sx!=null){g.save();g.clip();g.fillStyle=dk||'rgba(0,0,0,.17)';g.fillRect(sx,-400,500,800);g.restore()}if(lw!==0)wcSt2(g,lw)}
function wcEl(g,x,y,rx,ry,fill,lw,sx,rot){g.beginPath();g.ellipse(x,y,rx,ry,rot||0,0,Math.PI*2);wcFS(g,fill,sx,lw)}
function wcHi(g,x1,y1,cx,cy,x2,y2,w){g.beginPath();g.moveTo(x1,y1);g.quadraticCurveTo(cx,cy,x2,y2);g.lineWidth=w||2.4;g.strokeStyle='rgba(255,255,255,.75)';g.lineCap='round';g.stroke()}
function wcPoly(g,pts){g.beginPath();g.moveTo(pts[0],pts[1]);for(let i=2;i<pts.length;i+=2)g.lineTo(pts[i],pts[i+1]);g.closePath()}
/* --- the held item, centred on x,y --- */
function wcHold(g,A,x,y,t){g.save();g.translate(x,y+Math.sin(t*2.6+A.seed)*1.6);g.scale(1.3,1.3);
 if(A.hold==='cards'){[['e',-22],['s',0],['t',22]].forEach(([s,a])=>{g.save();g.rotate(a*Math.PI/180);g.beginPath();g.roundRect(-9,-30,18,26,3);wcFS(g,'#fff8ec',null,2.2);g.beginPath();g.roundRect(-6.5,-27.5,13,21,2);g.fillStyle=WCK[s][1];g.fill();
  g.beginPath();g.moveTo(0,-23);g.lineTo(4,-17);g.lineTo(0,-11);g.lineTo(-4,-17);g.closePath();g.fillStyle='#fff8ec';g.fill();g.restore()})}
 else if(A.hold==='chip'){const sx=Math.cos(t*3.2+A.seed);g.translate(0,-22-Math.abs(Math.sin(t*1.6+A.seed))*10);g.scale(Math.max(.12,Math.abs(sx)),1);
  wcEl(g,0,0,12,12,sx>0?'#e8384a':'#b81e30',2.4);g.fillStyle='#fff8ec';for(let k=0;k<6;k++){g.save();g.rotate(k*Math.PI/3);g.fillRect(-2,-11.5,4,4);g.restore()}wcEl(g,0,0,6,6,'#fff8ec',1.6)}
 else if(A.hold==='glass'){g.beginPath();g.moveTo(-14,-34);g.lineTo(14,-34);g.lineTo(0,-16);g.closePath();g.fillStyle='rgba(220,240,255,.55)';g.fill();wcSt2(g,2.4);
  g.beginPath();g.moveTo(-10,-30);g.lineTo(10,-30);g.lineTo(0,-19);g.closePath();g.fillStyle='#ffb0d0';g.fill();wcEl(g,5,-30,3.4,3.4,'#7ac04a',1.6);
  g.beginPath();g.moveTo(0,-16);g.lineTo(0,-4);wcSt2(g,2.4);wcEl(g,0,-3,8,2.4,'rgba(220,240,255,.8)',2)}
 else{[[-7,-20,-.3],[8,-24,.35]].forEach(([dx,dy,a])=>{g.save();g.translate(dx,dy);g.rotate(a+Math.sin(t*2+A.seed)*.08);g.beginPath();g.roundRect(-8,-8,16,16,3.5);wcFS(g,'#fff8ec',2,2.2,'rgba(0,0,0,.12)');
  g.fillStyle=WCO;for(const [px,py] of [[-3.5,-3.5],[3.5,3.5],[0,0]])g.fillRect(px-1.4,py-1.4,2.8,2.8);g.restore()})}
 g.restore()}
/* --- hands --- */
function wcHand(g,A,x,y,up){const D=WCSP[A.sp],sk=D.skin;g.save();g.translate(x,y);
 if(D.hand==='bone'){g.strokeStyle=WCO;for(const dx of [-5,0,5]){g.beginPath();g.moveTo(dx*.6,0);g.lineTo(dx,up?-10:10);g.lineWidth=6;g.stroke();g.strokeStyle=sk[0];g.lineWidth=3;g.stroke();g.strokeStyle=WCO}wcEl(g,0,0,7,6,sk[0],2.4)}
 else if(D.hand==='frog'){wcEl(g,0,0,8,7,sk[0],2.6,2);for(const dx of [-6,0,6])wcEl(g,dx,up?-8:8,3.2,3.2,'#ffd06a',2)}
 else{wcEl(g,0,0,9,8,sk[0],2.8,2);g.beginPath();g.moveTo(-8,up?-3:3);g.lineTo(-11,up?-8:8);g.lineTo(-4,up?-6:6);wcFS(g,sk[0],null,2.2);
  if(D.hand==='claw')for(const dx of [-5,0,5]){g.beginPath();g.moveTo(dx-2,up?-7:7);g.lineTo(dx,up?-13:13);g.lineTo(dx+2,up?-7:7);g.closePath();wcFS(g,'#fff4dc',null,1.6)}}
 g.restore()}
/* --- headwear and eyewear (head coordinates: centre 0,0, crown near y -28) --- */
function wcHat(g,A,top){const k=A.hat;if(!k||k==='visor')return;g.save();g.translate(0,top);
 if(k==='top'){g.rotate(-.08);g.beginPath();g.moveTo(-18,0);g.lineTo(-16,-42);g.lineTo(16,-42);g.lineTo(18,0);g.closePath();wcFS(g,'#1a1626',4,3);g.beginPath();g.rect(-17.5,-10,35,8);wcFS(g,A.tie,4,2.4);
  wcEl(g,0,-42,16,4.5,'#2a2438',2.4);wcEl(g,0,0,30,6.5,'#1a1626',3,6);wcHi(g,-11,-36,-12,-24,-11,-14,2.4)}
 else if(k==='fedora'){g.rotate(.06);g.beginPath();g.moveTo(-21,0);g.quadraticCurveTo(-22,-24,-12,-28);g.quadraticCurveTo(0,-22,12,-28);g.quadraticCurveTo(22,-24,21,0);g.closePath();wcFS(g,A.suit,4,3,'rgba(0,0,0,.25)');
  g.beginPath();g.rect(-21,-9,42,7);wcFS(g,A.tie,null,2.2);wcEl(g,0,0,40,7,A.suit2,3,10)}
 else if(k==='bowler'){g.beginPath();g.moveTo(-21,0);g.bezierCurveTo(-22,-32,22,-32,21,0);g.closePath();wcFS(g,'#2a2018',4,3);g.beginPath();g.rect(-21,-7,42,5);g.fillStyle=A.tie;g.fill();wcSt2(g,2);wcEl(g,0,0,30,5.5,'#1e1610',2.8,6);wcHi(g,-12,-18,-8,-24,0,-25,2.2)}
 g.restore()}
function wcEyes(g,A,y,dx,blink,kind){/* kind: round | slit | almond */
 for(const s of [-1,1]){const x=s*dx;if(blink){g.beginPath();g.moveTo(x-7,y);g.quadraticCurveTo(x,y+4,x+7,y);wcSt2(g,2.8);continue}
  if(kind==='slit'){wcEl(g,x,y,8,6.5,'#ffd45a',2.6);wcEl(g,x,y,1.8,5.4,WCO,0)}
  else if(kind==='glow'){wcEl(g,x,y,8,9,'#2a1440',2.6);wcEl(g,x+s,y+1,2.6,2.6,'#ffd45a',0);g.save();g.globalAlpha=.35;wcEl(g,x+s,y+1,5,5,'#ffd45a',0);g.restore()}
  else if(kind==='frog'){wcEl(g,x,y,9,9,'#fffaf0',2.6);wcEl(g,x,y+1,5.2,2.6,WCO,0)}
  else{wcEl(g,x,y,7,7.5,'#fffaf0',2.4);wcEl(g,x+s*1.4,y+1,3.2,3.6,WCO,0);wcEl(g,x+s*1.4-1,y-.5,1,1,'#fff',0)}}
 if(A.eye==='shades'){g.save();for(const s of [-1,1]){g.beginPath();g.roundRect(s*dx-10,y-7,20,13,5);wcFS(g,'#14101e',null,2.6);wcHi(g,s*dx-6,y-3,s*dx-4,y-5,s*dx-1,y-5,2)}g.beginPath();g.moveTo(-dx+10,y-3);g.lineTo(dx-10,y-3);wcSt2(g,2.6);g.restore()}
 if(A.eye==='mono'){g.beginPath();g.arc(dx,y,10,0,Math.PI*2);g.lineWidth=5;g.strokeStyle=WCO;g.stroke();g.lineWidth=2.6;g.strokeStyle='#ffd45a';g.stroke();g.save();g.globalAlpha=.25;g.fillStyle='#cfefff';g.fill();g.restore();
  g.beginPath();g.moveTo(dx+8,y+6);g.quadraticCurveTo(dx+14,y+26,dx+6,y+44);g.lineWidth=1.6;g.strokeStyle='#ffd45a';g.stroke()}}
/* --- heads, centred on 0,0 --- */
function wcHead(g,A,t){const D=WCSP[A.sp],sk=D.skin,blink=((t+A.seed*.37)%4.1)<.14;
 switch(A.sp){
 case 'dragon':{for(const s of [-1,1]){g.beginPath();g.moveTo(s*12,-20);g.quadraticCurveTo(s*30,-30,s*40,-54);g.quadraticCurveTo(s*30,-38,s*4,-26);g.closePath();wcFS(g,'#f4e2bc',s>0?0:99,3,'rgba(0,0,0,.14)');
   g.beginPath();g.moveTo(s*30,-14);g.lineTo(s*46,-24);g.lineTo(s*40,-8);g.lineTo(s*50,-4);g.lineTo(s*30,4);g.closePath();wcFS(g,sk[1],null,2.6)}
  g.beginPath();g.ellipse(0,-4,30,27,0,0,Math.PI*2);wcFS(g,sk[0],6,3.2);
  for(const [x,y,s] of [[0,-31,7],[-10,-28,5],[10,-28,5]]){g.beginPath();g.moveTo(x-s,y+3);g.lineTo(x,y-s);g.lineTo(x+s,y+3);g.closePath();wcFS(g,'#ffd45a',null,2.2)}
  wcEl(g,0,13,24,15,D.belly,3,8);for(const s of [-1,1])wcEl(g,s*7,9,3,2,WCO,0);
  g.beginPath();g.moveTo(-13,19);g.quadraticCurveTo(0,26,13,19);wcSt2(g,2.6);g.beginPath();g.moveTo(7,21);g.lineTo(9,27);g.lineTo(11,20.5);g.closePath();wcFS(g,'#fff',null,1.8);
  wcEyes(g,A,-8,12,blink,'slit');for(const s of [-1,1]){g.beginPath();g.moveTo(s*5,-17);g.lineTo(s*20,-14);wcSt2(g,3.4)}
  wcHi(g,-20,-16,-18,-24,-10,-27);break}
 case 'goblin':{for(const s of [-1,1]){g.beginPath();g.moveTo(s*22,-8);g.quadraticCurveTo(s*48,-20,s*64,-8);g.quadraticCurveTo(s*46,4,s*22,8);g.closePath();wcFS(g,sk[0],s>0?0:99,3);
   g.beginPath();g.moveTo(s*28,-4);g.quadraticCurveTo(s*44,-10,s*54,-6);wcSt2(g,2);g.strokeStyle='#ff9ab0';g.lineWidth=2.4;g.stroke()}
  if(A.chain&&A.eye!=='shades'){g.beginPath();g.arc(-27,6,4,0,Math.PI*2);g.lineWidth=2.4;g.strokeStyle='#ffd45a';g.stroke()}
  g.beginPath();g.ellipse(0,0,28,26,0,0,Math.PI*2);wcFS(g,sk[0],6,3.2);
  g.beginPath();g.moveTo(-17,11);g.quadraticCurveTo(0,30,17,11);g.quadraticCurveTo(0,17,-17,11);g.closePath();wcFS(g,'#3a0a14',null,2.6);
  for(const x of [-10,-4,2,8]){g.fillStyle=x===2?'#ffd45a':'#fffaf0';g.fillRect(x,13.2,4.4,4)}
  wcEyes(g,A,-9,11,blink,'round');
  g.beginPath();g.moveTo(-5,-5);g.quadraticCurveTo(0,-9,5,-5);g.quadraticCurveTo(11,10,2,14);g.quadraticCurveTo(-5,13,-5,-5);g.closePath();wcFS(g,sk[0],1,2.8);
  wcHi(g,-18,-12,-16,-20,-8,-23);break}
 case 'orc':{for(const s of [-1,1]){g.beginPath();g.moveTo(s*24,-10);g.lineTo(s*38,-18);g.lineTo(s*28,4);g.closePath();wcFS(g,sk[0],null,3)}
  g.beginPath();g.moveTo(-22,-28);g.quadraticCurveTo(0,-34,22,-28);g.quadraticCurveTo(30,-6,30,10);g.quadraticCurveTo(26,28,0,30);g.quadraticCurveTo(-26,28,-30,10);g.quadraticCurveTo(-30,-6,-22,-28);g.closePath();wcFS(g,sk[0],6,3.2);
  g.beginPath();g.moveTo(-16,16);g.quadraticCurveTo(0,22,16,16);wcSt2(g,2.6);
  for(const s of [-1,1]){g.beginPath();g.moveTo(s*9,18);g.lineTo(s*13,4);g.lineTo(s*16,17);g.closePath();wcFS(g,'#fff4dc',null,2.2)}
  wcEl(g,0,4,8,5,sk[1],2.4);g.fillStyle=WCO;g.fillRect(-4.5,4,2.4,2.4);g.fillRect(2,4,2.4,2.4);
  wcEyes(g,A,-9,11,blink,'round');if(A.eye!=='shades')for(const s of [-1,1]){g.beginPath();g.moveTo(s*4,-16);g.lineTo(s*20,-19);wcSt2(g,4.2)}
  g.beginPath();g.moveTo(17,4);g.lineTo(23,12);wcSt2(g,1.8);
  g.beginPath();g.moveTo(-36,-12);g.quadraticCurveTo(-44,10,-36,36);g.lineWidth=1.6;g.strokeStyle='#d8e0e8';g.stroke();
  wcHi(g,-20,-18,-18,-26,-8,-29);break}
 case 'skel':{g.beginPath();g.arc(0,-6,27,0,Math.PI*2);wcFS(g,sk[0],6,3.2);
  g.beginPath();g.roundRect(-15,10,30,16,6);wcFS(g,sk[0],6,3);for(const x of [-7.5,0,7.5]){g.beginPath();g.moveTo(x,12);g.lineTo(x,24);wcSt2(g,1.8)}g.beginPath();g.moveTo(-14,18);g.lineTo(14,18);wcSt2(g,1.6);
  wcEyes(g,A,-6,10,false,'glow');g.beginPath();g.moveTo(0,4);g.lineTo(-4,11);g.lineTo(4,11);g.closePath();wcFS(g,'#2a1440',null,2);
  g.beginPath();g.moveTo(10,-30);g.lineTo(6,-22);g.lineTo(11,-17);wcSt2(g,1.8);wcHi(g,-18,-16,-16,-26,-6,-30);break}
 case 'lizard':{g.save();for(let k=0;k<9;k++){const a=Math.PI*(1.05+k*.1125),r=48;g.beginPath();g.moveTo(Math.cos(a-.12)*20,Math.sin(a-.12)*20+4);g.lineTo(Math.cos(a)*r,Math.sin(a)*r+4);g.lineTo(Math.cos(a+.12)*20,Math.sin(a+.12)*20+4);g.closePath();wcFS(g,A.frill||'#ff8a3a',null,2.4)}g.restore();
  g.beginPath();g.ellipse(0,-2,24,28,0,0,Math.PI*2);wcFS(g,sk[0],5,3.2);wcEl(g,0,14,16,12,'#9ae8d0',2.6,6);for(const s of [-1,1])wcEl(g,s*5,10,1.8,1.4,WCO,0);
  g.beginPath();g.moveTo(-12,20);g.quadraticCurveTo(0,25,12,20);wcSt2(g,2.4);
  for(const [x,y] of [[-12,-20],[-4,-24],[6,-22],[14,-16],[-16,4]])wcEl(g,x,y,2.4,2,sk[1],0);
  wcEyes(g,A,-6,15,blink,'slit');
  if(A.hat==='visor'){g.beginPath();g.moveTo(-26,-16);g.quadraticCurveTo(0,-30,26,-16);g.quadraticCurveTo(0,-6,-26,-16);g.closePath();g.fillStyle='rgba(60,220,140,.72)';g.fill();wcSt2(g,2.8);
   g.beginPath();g.moveTo(-23,-22);g.quadraticCurveTo(0,-34,23,-22);g.lineWidth=5;g.strokeStyle='#14685a';g.stroke()}
  wcHi(g,-16,-14,-14,-24,-6,-28);break}
 case 'wolf':{for(const s of [-1,1]){g.beginPath();g.moveTo(s*8,-22);g.lineTo(s*24,-52);g.lineTo(s*27,-14);g.closePath();wcFS(g,sk[0],null,3);g.beginPath();g.moveTo(s*14,-24);g.lineTo(s*23,-42);g.lineTo(s*23,-20);g.closePath();g.fillStyle='#ffb0c4';g.fill()}
  for(const s of [-1,1]){g.beginPath();g.moveTo(s*24,-6);g.lineTo(s*36,0);g.lineTo(s*28,4);g.lineTo(s*36,12);g.lineTo(s*22,16);g.closePath();wcFS(g,sk[0],null,2.6)}
  g.beginPath();g.ellipse(0,-2,27,26,0,0,Math.PI*2);wcFS(g,sk[0],6,3.2);
  g.beginPath();g.moveTo(0,-28);g.lineTo(-5,-8);g.lineTo(5,-8);g.closePath();g.fillStyle=sk[1];g.fill();
  wcEl(g,0,12,15,12,D.muzzle,2.6,6);g.beginPath();g.moveTo(-6,4);g.quadraticCurveTo(0,0,6,4);g.quadraticCurveTo(0,11,-6,4);g.closePath();wcFS(g,'#1a1626',null,2.2);
  g.beginPath();g.moveTo(-7,16);g.quadraticCurveTo(-3,19,0,15);g.quadraticCurveTo(3,19,7,16);wcSt2(g,2.2);g.beginPath();g.moveTo(5,17);g.lineTo(6.5,22);g.lineTo(8,17);g.closePath();wcFS(g,'#fff',null,1.4);
  wcEyes(g,A,-8,11,blink,'round');if(A.eye!=='shades')for(const s of [-1,1]){g.beginPath();g.moveTo(s*4,-14);g.lineTo(s*18,-18);wcSt2(g,3)}
  if(A.chain){g.beginPath();g.arc(-26,-2,3.4,0,Math.PI*2);g.lineWidth=2.2;g.strokeStyle='#ffd45a';g.stroke()}
  wcHi(g,-19,-14,-17,-22,-9,-25);break}
 case 'frog':{g.beginPath();g.ellipse(0,4,34,22,0,0,Math.PI*2);wcFS(g,sk[0],8,3.2);for(const s of [-1,1]){g.beginPath();g.arc(s*15,-14,12,0,Math.PI*2);wcFS(g,sk[0],s>0?s*15:99,3)}
  for(const [x,y,r] of [[-20,10,3],[22,6,2.4],[8,16,2]])wcEl(g,x,y,r,r,sk[1],0);
  wcEl(g,-20,10,5,3,'#ff8aa8',0);wcEl(g,20,10,5,3,'#ff8aa8',0);g.beginPath();g.moveTo(-22,6);g.quadraticCurveTo(0,22,22,6);wcSt2(g,2.8);
  for(const s of [-1,1])wcEl(g,s*3,-2,1.4,1,WCO,0);
  if(blink){for(const s of [-1,1]){g.beginPath();g.moveTo(s*15-7,-14);g.quadraticCurveTo(s*15,-10,s*15+7,-14);wcSt2(g,2.8)}}else wcEyes(g,A,-14,15,false,'frog');
  if(A.eye==='mono'){}wcHi(g,-26,-2,-24,-8,-16,-10);break}
 case 'octo':{g.beginPath();g.ellipse(0,-12,28,34,0,0,Math.PI*2);wcFS(g,sk[0],6,3.2);for(const [x,y,r] of [[-12,-30,4],[8,-36,3],[16,-22,3.4],[-18,-12,2.6]])wcEl(g,x,y,r,r,'#d89aff',0);
  wcEyes(g,A,-2,11,false,'frog');if(blink)for(const s of [-1,1]){g.beginPath();g.moveTo(s*11-9,-2);g.lineTo(s*11+9,-2);wcSt2(g,3)}
  g.beginPath();g.ellipse(0,14,5,4,0,0,Math.PI*2);wcFS(g,'#5a1a6a',null,2.4);wcHi(g,-20,-24,-16,-36,-6,-42);break}}}
/* --- the whole figure: feet at 0,0 --- */
function wcCrewDraw(g,A,t){const D=WCSP[A.sp]||WCSP.goblin,sk=D.skin,b=Math.sin(t*2.2+A.seed)*1.3,octo=A.sp==='octo';g.save();g.lineJoin='round';g.lineCap='round';
 g.save();g.globalAlpha=.28;wcEl(g,0,-2,44,9,'#000',0);g.restore();
 /* behind the body: dragon wings and tail, octopus legs */
 if(A.sp==='dragon'){for(const s of [-1,1]){g.beginPath();g.moveTo(s*30,-138+b);g.lineTo(s*78,-196+b);g.lineTo(s*82,-150+b);g.quadraticCurveTo(s*70,-140,s*68,-120+b);g.quadraticCurveTo(s*56,-124,s*50,-104+b);g.closePath();wcFS(g,sk[1],null,3);
   g.beginPath();g.moveTo(s*34,-136+b);g.lineTo(s*72,-180+b);g.moveTo(s*40,-132+b);g.lineTo(s*70,-134+b);g.lineWidth=2;g.strokeStyle='rgba(0,0,0,.35)';g.stroke()}
  g.beginPath();g.moveTo(8,-58);g.bezierCurveTo(48,-44,74,-30,70,-74);g.lineWidth=15;g.strokeStyle=WCO;g.stroke();g.lineWidth=9;g.strokeStyle=sk[0];g.stroke();
  g.beginPath();g.moveTo(70,-92);g.lineTo(82,-72);g.lineTo(70,-76);g.lineTo(58,-72);g.closePath();wcFS(g,sk[1],70,2.8)}
 /* legs and shoes */
 if(octo)for(const [x0,x1,cx] of [[-22,-44,-40],[-8,-18,-22],[8,18,22],[22,44,40]]){const tp=Math.sin(t*2+x0)*3;g.beginPath();g.moveTo(x0,-74);g.bezierCurveTo(cx,-40,x1-Math.sign(x1)*12,-6,x1+tp,-10);g.quadraticCurveTo(x1+Math.sign(x1)*8+tp,-18,x1+Math.sign(x1)*2+tp,-22);
  g.lineWidth=17;g.strokeStyle=WCO;g.stroke();g.lineWidth=11;g.strokeStyle=sk[0];g.stroke();for(const k of [.35,.6,.82]){const px=x0+(x1-x0)*k,py=-74+64*k;wcEl(g,px+Math.sign(x1)*3,py,2.2,2.2,'#d89aff',0)}}
 for(const s of [-1,1]){if(octo)continue;
  g.beginPath();g.moveTo(s*3,-82);g.lineTo(s*27,-82);g.lineTo(s*24,-13);g.lineTo(s*6,-13);g.closePath();wcFS(g,A.suit2,null,3);
  g.beginPath();g.moveTo(s*5,-12);g.quadraticCurveTo(s*6,-20,s*16,-20);g.quadraticCurveTo(s*30,-20,s*31,-6);g.quadraticCurveTo(s*18,-1,s*5,-3);g.closePath();wcFS(g,'#1a1420',null,2.8);wcHi(g,s*12,-14,s*16,-17,s*22,-15,2)}
 g.save();g.translate(0,b);
 /* jacket */
 g.beginPath();g.moveTo(-16,-154);g.quadraticCurveTo(-40,-152,-46,-138);g.quadraticCurveTo(-46,-108,-36,-80);g.lineTo(-33,-68);g.quadraticCurveTo(0,-62,33,-68);g.lineTo(36,-80);g.quadraticCurveTo(46,-108,46,-138);g.quadraticCurveTo(40,-152,16,-154);g.closePath();wcFS(g,A.suit,4,3.2,'rgba(0,0,0,.2)');
 g.beginPath();g.moveTo(-15,-155);g.lineTo(15,-155);g.lineTo(0,-104);g.closePath();wcFS(g,A.suit===WCSUIT[4][0]?'#1a1626':'#fffaf0',null,2.6);
 if(A.chain){g.beginPath();g.moveTo(-12,-153);g.quadraticCurveTo(-4,-128,0,-126);g.quadraticCurveTo(4,-128,12,-153);g.lineWidth=4.4;g.strokeStyle=WCO;g.stroke();g.lineWidth=2.2;g.strokeStyle='#ffd45a';g.setLineDash([3,2]);g.stroke();g.setLineDash([]);wcEl(g,0,-123,5.4,5.4,'#ffd45a',2.2)}
 if(A.tk==='tie'){g.beginPath();g.moveTo(-5,-152);g.lineTo(5,-152);g.lineTo(3,-145);g.lineTo(-3,-145);g.closePath();wcFS(g,A.tie,null,2.2);g.beginPath();g.moveTo(-3,-145);g.lineTo(3,-145);g.lineTo(6,-116);g.lineTo(0,-109);g.lineTo(-6,-116);g.closePath();wcFS(g,A.tie,0,2.4)}
 else{g.beginPath();g.moveTo(0,-148);g.lineTo(-12,-155);g.lineTo(-12,-141);g.closePath();wcFS(g,A.tie,null,2.4);g.beginPath();g.moveTo(0,-148);g.lineTo(12,-155);g.lineTo(12,-141);g.closePath();wcFS(g,A.tie,null,2.4);wcEl(g,0,-148,3.4,3.4,A.tie,2)}
 for(const s of [-1,1]){g.beginPath();g.moveTo(s*15,-155);g.lineTo(s*3,-106);g.lineTo(s*15,-122);g.lineTo(s*25,-126);g.lineTo(s*21,-150);g.closePath();wcFS(g,A.suit2,null,2.6)}
 for(const y of [-96,-84])wcEl(g,0,y,2.6,2.6,'#ffd45a',1.6);
 g.beginPath();g.moveTo(20,-133);g.lineTo(24,-140);g.lineTo(28,-134);g.lineTo(32,-139);g.lineTo(33,-131);g.closePath();wcFS(g,A.tie,null,1.8);g.beginPath();g.moveTo(18,-131);g.lineTo(35,-131);wcSt2(g,2);
 g.beginPath();g.moveTo(-30,-84);g.lineTo(-14,-84);g.moveTo(14,-84);g.lineTo(30,-84);wcSt2(g,2);
 /* arms: one relaxed, one raised with the held item */
 if(octo){const tw=(pts)=>{g.beginPath();g.moveTo(pts[0],pts[1]);g.bezierCurveTo(pts[2],pts[3],pts[4],pts[5],pts[6],pts[7]);g.quadraticCurveTo(pts[8],pts[9],pts[10],pts[11]);g.lineWidth=17;g.strokeStyle=WCO;g.stroke();g.lineWidth=11;g.strokeStyle=sk[0];g.stroke()};
  const w=Math.sin(t*2.4+A.seed)*3;tw([-40,-138,-64,-124,-48,-90,-60,-78+w,-70,-70+w,-62,-64+w]);tw([40,-138,64,-130,58,-112,68,-128,76,-140,68,-146]);
  for(const [x,y] of [[-56,-112],[-54,-96],[62,-124]])wcEl(g,x,y,2.2,2.2,'#d89aff',0);wcHold(g,A,70,-152,t)}
 else{g.beginPath();g.moveTo(-42,-144);g.quadraticCurveTo(-56,-126,-56,-90);g.lineTo(-42,-88);g.quadraticCurveTo(-40,-116,-34,-124);g.closePath();wcFS(g,A.suit,-50,3,'rgba(0,0,0,.12)');
  g.beginPath();g.rect(-57,-92,16,6);wcFS(g,'#fffaf0',null,2.2);wcHand(g,A,-49,-80,false);
  g.beginPath();g.moveTo(42,-144);g.quadraticCurveTo(58,-130,60,-104);g.lineTo(48,-100);g.quadraticCurveTo(44,-118,36,-124);g.closePath();wcFS(g,A.suit,52,3,'rgba(0,0,0,.2)');
  g.beginPath();g.moveTo(50,-106);g.lineTo(62,-102);g.lineTo(74,-128);g.lineTo(62,-133);g.closePath();wcFS(g,A.suit,66,3,'rgba(0,0,0,.2)');
  g.save();g.translate(68,-131);g.rotate(-1.15);g.beginPath();g.rect(-3,-8,7,16);wcFS(g,'#fffaf0',null,2.2);g.restore();wcHold(g,A,71,-146,t);wcHand(g,A,71,-139,true)}
 /* neck and head */
 if(!octo){g.beginPath();g.rect(-8,-166,16,14);wcFS(g,sk[0],2,2.6)}
 g.save();const hy=WCHY(A);g.translate(0,hy);g.rotate(Math.sin(t*1.3+A.seed)*.035);g.scale(WCHS,WCHS);wcHead(g,A,t);
 wcHat(g,A,A.sp==='frog'?-24:A.sp==='octo'?-42:A.sp==='orc'?-28:-25);g.restore();
 g.restore();g.restore()}
/* heads are drawn a size up for a chunky, friendly silhouette; this is where each one sits and how tall it all is */
const WCHS=1.24,WCHY=A=>A.sp==='frog'?-178:A.sp==='octo'?-186:-188;
function wcCrewTop(A){const hat={top:-72,fedora:-50,bowler:-48}[A.hat]||0,ht=A.sp==='frog'?-24:A.sp==='octo'?-42:A.sp==='orc'?-28:-25,
 base={dragon:-54,goblin:-26,orc:-34,skel:-33,lizard:-46,wolf:-52,frog:-26,octo:-46}[A.sp]||-30;return WCHY(A)+WCHS*Math.min(base,hat?ht+hat:base)}
/* portrait: head and shoulders inside a round frame */
function wcCrewPortrait(cv,A,t){const g=cv.getContext('2d'),w=cv.width,h=cv.height;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,w,h);
 const top=Math.max(wcCrewTop(A),-250),bot=-112,s=h/(bot-top+10);g.save();g.translate(w/2-(A.hold?8*s:0),h+(-bot)*s);g.scale(s,s);wcCrewDraw(g,A,t||1.2);g.restore()}
function wcCrewFigure(cv,A,t){const g=cv.getContext('2d'),w=cv.width,h=cv.height;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,w,h);
 const top=wcCrewTop(A),s=Math.min(h*.96/(-top+6),w*.96/190);g.save();g.translate(w/2-4*s,h*.985);g.scale(s,s);wcCrewDraw(g,A,t||1.2);g.restore()}
/* the table and podium hand crew members to these; everything else keeps the old artwork */
{const p0=wcPortrait;wcPortrait=function(cv,av){if(av&&av.t==='crew')return wcCrewPortrait(cv,av);return p0.apply(this,arguments)}}
{const f0=wcFigure;wcFigure=function(cv,av){if(av&&av.t==='crew')return wcCrewFigure(cv,av);return f0.apply(this,arguments)}}
