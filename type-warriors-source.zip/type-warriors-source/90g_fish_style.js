/* ===== MOONLIT FISHING: styles ===== (transform/opacity animations only; no backdrop-filter, no animated shadows) */
{const st=document.createElement('style');st.textContent=`
#ov.fshx{display:block;padding:0;overflow:hidden;background:#07041a;text-align:left}#ov.fshx>div{position:absolute;left:0;top:0;margin:0}#ov.fshx p{max-width:none;margin:0}
:where(.fsx) button{min-width:0;padding:0;letter-spacing:normal;box-shadow:none;font-family:var(--ui,Poppins),system-ui,sans-serif;text-transform:none}
.dks3 .dkleft{top:auto;bottom:12px;right:12px}
.fsx{--gold:#ffd45a;--ink:#fff8e8;--mut:#c4badf;--sp:cubic-bezier(.3,1.5,.5,1);position:absolute;left:0;top:0;width:1600px;height:900px;overflow:hidden;font-family:var(--ui,Poppins),system-ui,sans-serif;color:var(--ink);user-select:none}
.fsx>canvas#fscv{position:absolute;inset:0;width:1600px;height:900px;cursor:pointer}
.fsg{background:linear-gradient(180deg,#221a5aee,#100a30f2);border:2px solid #4a3e90;box-shadow:inset 0 1px 0 #ffffff1f,0 10px 28px #0009;border-radius:20px}
.fsx kbd{font:700 11.5px var(--ui,Poppins);padding:2px 7px;border-radius:6px;background:#ffffff14;border:1px solid #ffffff3a;color:#e8e0ff;margin-left:8px;vertical-align:1px}
.fscoin{display:inline-block;width:20px;height:20px;border-radius:50%;background:radial-gradient(circle at 35% 35%,#fff3b0,#ffc94a 45%,#b8801a);border:2px solid #7a4a08;vertical-align:-4px;margin-right:7px;flex:none}
/* top left */
.fstop{position:absolute;left:22px;top:18px;display:flex;align-items:center;gap:14px;padding:10px 22px 10px 12px;animation:fsIn .5s var(--sp) both}
.fsmoonic canvas{display:block;width:68px;height:68px}
.fstop h2{margin:0;font:400 36px/1 'Pirata One',Georgia,serif;color:var(--gold);letter-spacing:.01em}
.fstop p{font:600 15.5px var(--ui);color:#e8e0ff;display:flex;align-items:center;gap:8px;margin-top:4px!important}.fstop p b{color:#fff;font-weight:800}
.fsfi svg{display:block}.fsmn{font:500 13px var(--ui)!important;color:var(--mut)!important}.fsmn b{color:#fff8e8!important;font-weight:700!important}.fsmn em{font-style:normal;opacity:.75}
/* top right */
.fstr{position:absolute;right:22px;top:18px;display:flex;gap:12px;align-items:center;animation:fsIn .5s .05s var(--sp) both}
.fsgold{display:flex;align-items:center;height:58px;padding:0 22px;font:800 22px var(--ui);color:#ffe9a0}
.fsback{display:flex;align-items:center;gap:8px;height:58px;padding:0 18px;color:#fff8e8;font:700 19px var(--ui);cursor:pointer}.fsback svg{width:20px;height:20px}.fsback:hover{transform:translateY(-2px)}.fsback:active{transform:scale(.95)}
/* side panel */
.fsside{position:absolute;right:22px;top:92px;width:396px;bottom:20px;display:flex;flex-direction:column;padding:12px 14px 12px;animation:fsSide .55s .08s var(--sp) both}
.fstabs{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-bottom:10px}
.fstabs button{position:relative;height:38px;border-radius:12px;border:2px solid #3a3070;background:#140e36;color:#c4badf;font:700 14px var(--ui);cursor:pointer;transition:transform .15s}
.fstabs button:hover{transform:translateY(-2px);color:#fff}.fstabs button[aria-selected=true]{background:linear-gradient(180deg,#6a52f0,#4a34c8);border-color:#a898ff;color:#fff}
.fstabs i{position:absolute;top:-7px;right:-5px;min-width:20px;height:20px;padding:0 5px;border-radius:10px;background:#e8364e;color:#fff;font:800 11px/20px var(--ui);font-style:normal}.fstabs i:empty{display:none}
.fsbody{flex:1;min-height:0;overflow-y:auto;overflow-x:hidden;padding-right:4px;scrollbar-width:thin;scrollbar-color:#4a3e90 transparent}
.fsbh{display:flex;align-items:baseline;justify-content:space-between;margin:2px 2px 8px}.fsbh h3{margin:0;font:400 32px/1 'Pirata One',Georgia,serif;color:var(--gold)}.fsbh span{font:600 13.5px var(--ui);color:#e8e0ff}
.fsflt{display:flex;gap:5px;margin-bottom:10px}.fsflt button{flex:1;height:32px;border-radius:10px;border:2px solid #3a3070;background:#140e36;color:#d8d0f4;font:700 12px var(--ui);cursor:pointer;padding:0}
.fsflt button.on{background:color-mix(in srgb,var(--rc) 30%,#2a1f6e);border-color:var(--rc);color:#fff}
.fsgrid{display:grid;grid-template-columns:1fr 1fr;gap:9px}
.fscard{display:flex;flex-direction:column;align-items:center;gap:3px;padding:8px 6px 9px;border-radius:16px;border:2px solid color-mix(in srgb,var(--rc) 45%,#2a2060);background:radial-gradient(circle at 50% 35%,color-mix(in srgb,var(--rc) 16%,#1e1650),#0f0a2c 75%);color:#fff8e8;cursor:pointer;transition:transform .18s var(--sp)}
.fscard:hover{transform:translateY(-3px)}.fscard:active{transform:scale(.96)}.fscard.cur{border-color:#ffd45a;box-shadow:0 0 0 2px #ffd45a55}
.fscard canvas{width:100%;height:auto;aspect-ratio:180/96}.fscard b{font:700 14.5px var(--ui);line-height:1.15;text-align:center}.fscard small{font:500 11.5px var(--ui);color:var(--mut)}.fscard.unk b{color:#8a80b0}.fscard.unk{border-color:#2a2060}
.fspill{display:inline-block;padding:1px 10px;border-radius:99px;border:1.5px solid var(--rc);background:color-mix(in srgb,var(--rc) 22%,#120c30);color:#fff;font:700 11px/1.5 var(--ui);letter-spacing:.02em}
.fscrown{color:#ffd45a}
/* catch preview */
.fspv{margin-top:10px;padding:10px 12px 8px;border-radius:16px;border:2px solid color-mix(in srgb,var(--rc) 60%,#2a2060);background:radial-gradient(120% 90% at 20% 30%,color-mix(in srgb,var(--rc) 18%,transparent),transparent 60%),#100a2ef0;animation:fsPv .45s var(--sp) both}
.fspv h4{margin:0 0 4px;font:800 11.5px var(--ui);letter-spacing:.22em;text-transform:uppercase;color:#b8aee0}
.fspvc{display:flex;align-items:center;gap:6px}.fspvc canvas{width:150px;height:95px;flex:none}
.fspvt{display:flex;flex-direction:column;gap:3px;min-width:0}.fspvt b{font:400 26px/1 'Pirata One',Georgia,serif;color:var(--rc)}.fspvt .fspill{align-self:flex-start}.fscm{font:700 17px var(--ui)}.fscm small{font:500 12px var(--ui);color:var(--mut)}
.fstags{display:flex;flex-wrap:wrap;gap:4px}.fstag{padding:1px 8px;border-radius:7px;font:800 10.5px/1.6 var(--ui);letter-spacing:.06em;color:#1a0a04;animation:fsTag .5s .3s var(--sp) both}.fstag.new{background:#7affb4}.fstag.rec{background:#ffd45a}.fstag.gi{background:#ff9a5a}.fstag.ft{background:#9ad8ff}
.fspvb{display:grid;grid-template-columns:1.25fr 1fr;gap:8px;margin-top:8px}
.fspvb button{white-space:nowrap;padding:0 8px;height:46px;border-radius:13px;font:800 16px var(--ui);cursor:pointer;display:flex;align-items:center;justify-content:center;gap:6px;transition:transform .15s}.fspvb button:hover{transform:translateY(-2px)}.fspvb button:active{transform:scale(.95)}
.fssell{background:linear-gradient(180deg,#ffe27a,#f2b631);border:none;color:#3a2006;box-shadow:0 4px 0 #9a6a10}.fskeep{background:#1c1446;border:2px solid #5a4ca0;color:#fff8e8}.fskeep svg{width:20px;height:20px}
.fspvb button.def{outline:3px solid #ffffffcc;outline-offset:2px}.fspvb button:disabled{opacity:.45;cursor:not-allowed}.fspvb kbd{margin-left:4px!important}
.fsrecl{display:block;margin:6px auto 0;background:none;border:none;color:#c8beff;font:600 13px var(--ui);cursor:pointer}.fsrecl:hover{color:#fff}
/* word box */
.fsword{position:absolute;left:150px;width:880px;top:700px;height:130px;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;pointer-events:none}
.fsword>*{pointer-events:auto}
.fsprm{font:700 18px var(--ui);color:#fff8e8;text-shadow:0 2px 0 #000a,0 0 12px #000;margin-bottom:8px!important;display:flex;align-items:center;gap:10px}
.fsstg{display:inline-flex;gap:5px}.fsstg i{width:26px;height:7px;border-radius:4px;background:#ffffff30}.fsstg i.ok{background:#7affb4}.fsstg i.on{background:#ffd45a}
.fshp{display:inline-flex;gap:3px;font-style:normal}.fshp i{font-style:normal;color:#ff5a7a;font-size:18px}.fshp i.lost{color:#ffffff30}
.fswb{position:relative;display:flex;align-items:center;justify-content:center;min-width:420px;height:84px;padding:0 54px;border-radius:44px;border:3px solid color-mix(in srgb,var(--rc) 70%,#ffd45a);background:linear-gradient(180deg,#1a1240f4,#0b0724f8);cursor:text}
.fswb.in{animation:fsWb .38s var(--sp) both}.fswb.miss{animation:fsMiss .3s ease both}
.fsdia{position:absolute;top:50%;width:14px;height:14px;margin-top:-7px;transform:rotate(45deg);border:2.5px solid color-mix(in srgb,var(--rc) 70%,#ffd45a);background:#120a30}.fsdia.l{left:-9px}.fsdia.r{right:-9px}
.fswt{font:800 56px/1 var(--ui);letter-spacing:.05em;text-transform:uppercase;white-space:nowrap}.fswt .d{color:#4ff0d8}.fswt .n{color:#fff8e8}
.fsring{position:absolute;right:28px;bottom:2px;width:92px;height:92px;border-radius:50%;background:#0b0724f2;border:2px solid #3a3070}
.fsring svg{position:absolute;inset:4px;width:80px;height:80px;transform:rotate(-90deg)}.fsring circle{fill:none;stroke-width:9}.fsring .bg{stroke:#ffffff18}.fsring .fg{stroke:#4ff0d8;stroke-linecap:round;stroke-dasharray:100}
.fsring b{position:absolute;inset:0;display:grid;place-items:center;font:800 26px var(--ui)}.fsring.low .fg{stroke:#ff5a6a}.fsring.low b{color:#ff9aa6;animation:fsPulse .5s ease-in-out infinite alternate}
.fscast{display:flex;align-items:center;gap:12px;height:72px;padding:0 34px;border-radius:40px;border:none;background:linear-gradient(180deg,#ffe27a,#f2b631);color:#3a2006;font:800 24px var(--ui);box-shadow:0 5px 0 #9a6a10,0 14px 30px #0008;cursor:pointer;animation:fsWb .4s var(--sp) both;transition:transform .15s}
.fscast:hover{transform:translateY(-3px)}.fscast:active{transform:scale(.95)}.fscast kbd{background:#3a200614;border-color:#3a200655;color:#3a2006}.fscasti svg{width:38px;height:24px;display:block}.fscasti svg path{fill:#3a2006}
.fswait{font:700 20px var(--ui);color:#e8e0ff;padding:12px 28px;border-radius:30px;background:#0b0724c8;border:2px solid #3a3070;display:flex;align-items:center;gap:12px;animation:fsWb .35s var(--sp) both}
.fsdots{display:inline-flex;gap:5px}.fsdots i{width:8px;height:8px;border-radius:50%;background:#c8beff;animation:fsDot 1.2s ease-in-out infinite}.fsdots i:nth-child(2){animation-delay:.2s}.fsdots i:nth-child(3){animation-delay:.4s}
/* rod strip */
.fsrodp{position:absolute;left:22px;bottom:20px;width:300px;height:66px;display:flex;align-items:center;gap:10px;padding:0 14px 0 8px;color:#fff8e8;cursor:pointer;animation:fsIn .5s .1s var(--sp) both;transition:transform .15s}
.fsrodp:hover{transform:translateY(-2px)}.fsrodic canvas{display:block;width:84px;height:49px}.fsrodt{flex:1;display:flex;flex-direction:column;gap:5px;min-width:0;text-align:left}.fsrodt b{font:400 22px/1 'Pirata One',Georgia,serif;color:var(--gold);white-space:nowrap}
.fsbar{height:9px;border-radius:5px;background:#07041a;border:1px solid #ffffff22;overflow:hidden}.fsbar i{display:block;height:100%;background:linear-gradient(90deg,#6a52f0,#a898ff);border-radius:5px}
.fsrodc{display:none}.fschev{font:800 22px var(--ui);font-style:normal;color:#c8beff}
/* banner and toast */
.fsban{position:absolute;left:150px;width:880px;top:120px;text-align:center;pointer-events:none;opacity:0;transform:translateY(-10px) scale(.9)}
.fsban.on{animation:fsBan 1.2s var(--sp) both}.fsban b{display:block;font:400 64px/1 'Pirata One',Georgia,serif;color:var(--rc);-webkit-text-stroke:2px #1b1024;paint-order:stroke fill;text-shadow:0 4px 0 #1b1024,0 0 30px color-mix(in srgb,var(--rc) 60%,transparent)}
.fsban span{display:table;margin:8px auto 0;padding:4px 16px;border-radius:14px;background:#0b0724d0;font:700 19px var(--ui);color:#fff8e8}
.fsban.rl.on{animation:fsBanL 2.6s var(--sp) both}.fsban.rl b{font-size:88px;background:linear-gradient(180deg,#fff6c0,#ffd45a 45%,#ff9a20);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;-webkit-text-stroke:0;text-shadow:none;filter:drop-shadow(0 4px 0 #3a1a04)}
.fsban.rl span{display:none}
.fstoast{position:absolute;left:340px;width:500px;bottom:24px;display:flex;align-items:center;justify-content:center;padding:10px 18px;border-radius:16px;background:#0b0724e8;border:2px solid #4a3e90;font:600 15px var(--ui);color:#fff8e8;opacity:0;transform:translateY(10px);pointer-events:none}
.fstoast.on{animation:fsToast 2.4s ease both}
/* lists */
.fsnote{font:500 12.5px/1.4 var(--ui);color:var(--mut);margin:0 2px 8px!important}
.fssa{width:100%;height:40px;margin-bottom:8px;border-radius:12px;border:none;background:linear-gradient(180deg,#ffe27a,#f2b631);color:#3a2006;font:800 15px var(--ui);box-shadow:0 3px 0 #9a6a10;cursor:pointer;display:flex;align-items:center;justify-content:center}
.fslist{display:flex;flex-direction:column;gap:6px}.fsrow{display:flex;align-items:center;gap:8px;padding:4px 8px 4px 4px;border-radius:12px;border:1.5px solid color-mix(in srgb,var(--rc) 40%,#2a2060);background:#140e36}
.fsrow canvas{width:72px;height:42px;flex:none}.fsrow span{flex:1;min-width:0;display:flex;flex-direction:column}.fsrow b{font:700 14px var(--ui);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.fsrow small{font:500 11.5px var(--ui);color:var(--mut)}
.fsrow button{height:32px;padding:0 10px;border-radius:9px;border:2px solid #5a4ca0;background:#1c1446;color:#ffe9a0;font:800 13px var(--ui);display:flex;align-items:center;cursor:pointer}.fsrow button .fscoin{width:15px;height:15px;margin-right:5px}
.fsempty{font:500 14px/1.5 var(--ui);color:var(--mut);text-align:center;padding:30px 10px!important}
/* rod tab */
.fsrodh{display:flex;align-items:center;gap:10px;padding:6px 8px;border-radius:14px;background:#140e36;border:1.5px solid #3a3070;margin-bottom:6px}.fsrodh canvas{width:180px;height:45px}.fsrodh h3{margin:0;font:400 26px/1 'Pirata One',Georgia,serif;color:var(--gold)}.fsrodh span{font:600 12.5px var(--ui);color:var(--mut)}
.fssub{margin:10px 2px 6px;font:800 11.5px var(--ui);letter-spacing:.2em;text-transform:uppercase;color:#b8aee0}.fssub small{letter-spacing:0;text-transform:none;font-weight:600;opacity:.8}
.fsup{display:grid;grid-template-columns:1fr auto;grid-template-rows:auto auto auto;column-gap:10px;padding:8px 10px;border-radius:12px;background:#140e36;border:1.5px solid #3a3070;margin-bottom:6px}
.fsupt{display:flex;align-items:center;gap:10px}.fsupt b{font:800 16px var(--ui)}.fspips{display:inline-flex;gap:3px}.fspips i{width:14px;height:8px;border-radius:3px;background:#ffffff1c}.fspips i.on{background:linear-gradient(90deg,#a898ff,#6ad8ff)}
.fsup small{grid-column:1;font:500 12px/1.35 var(--ui);color:var(--mut)}.fsupfx b{color:#9affc8}.fsup button,.fsup .fsmax{grid-column:2;grid-row:1/4;align-self:center;height:40px;padding:0 12px;border-radius:11px;border:none;background:linear-gradient(180deg,#ffe27a,#f2b631);color:#3a2006;font:800 14px var(--ui);box-shadow:0 3px 0 #9a6a10;display:flex;align-items:center;cursor:pointer}
.fsup button:disabled{filter:grayscale(.8);opacity:.55;cursor:not-allowed}.fsup .fsmax{background:#2a1f6e;color:#ffd45a;box-shadow:none}.fsup button .fscoin{width:16px;height:16px;margin-right:5px}
.fsskins{display:flex;flex-direction:column;gap:6px}.fssk{display:grid;grid-template-columns:96px 1fr auto;align-items:center;gap:8px;padding:6px 8px;border-radius:12px;background:#140e36;border:1.5px solid #3a3070}.fssk.eq{border-color:var(--sc)}
.fssk canvas{width:96px;height:38px}.fssk b{font:800 14px var(--ui)}.fssk small{display:block;font:500 11.5px/1.3 var(--ui);color:var(--mut)}.fsreqs{display:flex;flex-wrap:wrap;gap:4px;margin-top:3px}
.fsreq{display:inline-flex;align-items:center;gap:2px;padding:1px 6px 1px 1px;border-radius:8px;background:#0b0724;border:1px solid #3a3070;font:700 11px var(--ui);color:#ff9aa6}.fsreq.ok{color:#9affc8;border-color:#3a8a5a}.fsreq canvas{width:30px;height:18px}
.fssk button{height:32px;padding:0 10px;border-radius:9px;border:2px solid #5a4ca0;background:#2a1f6e;color:#fff;font:700 12.5px var(--ui);cursor:pointer}.fssk button:disabled{opacity:.45;cursor:not-allowed}.fseq{font:800 11.5px var(--ui);color:#9affc8}
/* stats */
.fsstats{display:grid;grid-template-columns:1fr 1fr;gap:8px}.fsstats div{display:flex;flex-direction:column;padding:10px 12px;border-radius:14px;background:#140e36;border:1.5px solid #3a3070}
.fsstats small{font:700 11px var(--ui);letter-spacing:.08em;text-transform:uppercase;color:#b8aee0}.fsstats b{font:400 28px/1.1 'Pirata One',Georgia,serif;color:var(--gold);margin:2px 0}.fsstats em{font:500 11.5px var(--ui);font-style:normal;color:var(--mut)}
/* modal */
.fsmod{position:absolute!important;inset:0;width:1600px;height:900px;display:grid;place-items:center;background:#04021099;z-index:5;animation:fsFade .25s ease both}.fsmod[hidden]{display:none}
.fsdet{position:relative;display:flex;gap:20px;align-items:center;width:1020px;padding:22px 26px;border-radius:24px;border:2px solid color-mix(in srgb,var(--rc) 60%,#3a3070);background:radial-gradient(90% 120% at 25% 50%,color-mix(in srgb,var(--rc) 16%,transparent),transparent 60%),linear-gradient(180deg,#221a5af6,#100a30fa);box-shadow:0 20px 60px #000c;animation:fsWb .4s var(--sp) both}
.fsdet canvas{width:520px;height:306px;flex:none}.fsdt{display:flex;flex-direction:column;gap:8px;align-items:flex-start}.fsdt h3{margin:0;font:400 46px/1 'Pirata One',Georgia,serif;color:var(--rc)}.fsdt p{font:500 16px/1.45 var(--ui);color:#e8e0ff}
.fsdst{display:grid;grid-template-columns:repeat(3,auto);gap:8px 18px}.fsdst span{display:flex;flex-direction:column}.fsdst small{font:700 11px var(--ui);letter-spacing:.1em;text-transform:uppercase;color:#b8aee0}.fsdst b{font:800 18px var(--ui)}
.fsx2{position:absolute;top:12px;right:14px;width:40px;height:40px;border-radius:12px;border:2px solid #5a4ca0;background:#1c1446;color:#fff;font:700 18px var(--ui);cursor:pointer}
/* main menu card and mode picker */
.dksc.dks3{grid-template-columns:1fr 1fr 1fr!important}
.dkfish{border-color:#7ad8ffaa!important}.dkfish:hover{border-color:#aaf0ff!important}.dkfish .dkcl b{color:#fff8e8}.dkfish .dkcl small:first-child{color:#9ff0ff;letter-spacing:.18em}
.dknew{position:absolute;z-index:3;top:10px;right:10px;padding:3px 10px;border-radius:9px;font:800 12px var(--ui);font-style:normal;letter-spacing:.1em;color:#1a0a04;background:linear-gradient(90deg,#7affd8,#ffd45a);animation:fsNew 2.4s ease-in-out infinite}
.dkmnew{display:inline-block;margin-left:6px;padding:1px 7px;border-radius:7px;font:800 10.5px var(--ui);font-style:normal;letter-spacing:.08em;color:#1a0a04;background:linear-gradient(90deg,#7affd8,#ffd45a);vertical-align:2px}
@keyframes fsIn{from{opacity:0;transform:translateY(-12px)}}
@keyframes fsSide{from{opacity:0;transform:translateX(40px)}}
@keyframes fsPv{from{opacity:0;transform:translateY(24px) scale(.94)}}
@keyframes fsTag{from{opacity:0;transform:scale(.4)}}
@keyframes fsWb{from{opacity:0;transform:translateY(16px) scale(.9)}}
@keyframes fsMiss{20%{transform:translateX(-10px)}40%{transform:translateX(9px)}60%{transform:translateX(-6px)}80%{transform:translateX(4px)}}
@keyframes fsPulse{to{transform:scale(1.18)}}
@keyframes fsDot{0%,100%{opacity:.3;transform:translateY(0)}50%{opacity:1;transform:translateY(-4px)}}
@keyframes fsBan{0%{opacity:0;transform:translateY(16px) scale(.7)}18%{opacity:1;transform:none}80%{opacity:1;transform:none}100%{opacity:0;transform:translateY(-12px)}}
@keyframes fsBanL{0%{opacity:0;transform:scale(1.8)}12%{opacity:1;transform:scale(1)}85%{opacity:1;transform:scale(1.04)}100%{opacity:0;transform:scale(1.1)}}
@keyframes fsToast{0%{opacity:0;transform:translateY(10px)}10%,85%{opacity:1;transform:none}100%{opacity:0}}
@keyframes fsFade{from{opacity:0}}
@keyframes fsNew{0%,100%{transform:scale(1)}50%{transform:scale(1.08)}}
@media (prefers-reduced-motion:reduce){.fsx *,.dknew{animation-duration:.01s!important;animation-iteration-count:1!important}}`;document.head.appendChild(st)}
