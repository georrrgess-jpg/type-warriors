/* ===== CONSOLE DOCK: the main menu rebuilt around six permanent destinations =====
   Play · Gear · Pets · Progress · Shop · More. Every old sidebar entry, header tool and corner button keeps its
   real handler; only where it lives has changed. Function declarations here replace the old shell's (title,
   sbHTML, sbBind, shellNav, homeKey, homeScene, drawBG, playHub), so later wrappers still wrap them. */

/* ---------- icons in the game's own illustrated style ---------- */
MG.dplay=bR('M22 22L78 78','#cfd8ea',8)+bR('M78 22L22 78','#cfd8ea',8)+bF('M24 24L76 76','#fff',0)+bL(16,84,30,70,'#7a4a24',7)+bL(84,84,70,70,'#7a4a24',7)
 +bL(26,64,36,74,'#d8a830',6)+bL(74,64,64,74,'#d8a830',6)+bC(14,86,5,'#d8a830',1.6)+bC(86,86,5,'#d8a830',1.6)+bS(50,50,8,'#fff6c0')+bH('M30 26L46 42','#ffffffaa',2.4);
MG.dmore=bC(22,50,10,'#c8b8ff')+bC(50,50,10,'#ffd45a')+bC(78,50,10,'#c8b8ff')+bS(50,50,4,'#fff6c0');
MG.dbell=bP('M50 16C36 16 28 28 28 42V58L20 68H80L72 58V42C72 28 64 16 50 16Z','#ffd24a')+bF('M50 16C64 16 72 28 72 42V58L80 68H50Z','#000',.18)+bP('M40 72C40 80 46 84 50 84C54 84 60 80 60 72Z','#e0a020',2)+bC(50,14,5,'#ffd24a',2)+bH('M34 40C35 30 40 24 46 22','#fff',2.6);
MG.dcal=bP('M18 26H82V84H18Z','#f4ecd8')+bP('M18 26H82V42H18Z','#e0344a')+bL(34,18,34,32,'#6a4a28',6)+bL(66,18,66,32,'#6a4a28',6)+bP('M30 52H42V62H30ZM46 52H58V62H46ZM62 52H74V62H62ZM30 66H42V76H30ZM46 66H58V76H46Z','#c8b8d8',1.2)+bS(68,71,7,'#ffd45a');

const DKSKULL='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.5c-4.9 0-8.5 3.4-8.5 8 0 2.6 1.2 4.5 3 5.6V19a1.5 1.5 0 0 0 1.5 1.5h8A1.5 1.5 0 0 0 17.5 19v-2.9c1.8-1.1 3-3 3-5.6 0-4.6-3.6-8-8.5-8z" fill="#e8e0ff"/><circle cx="8.6" cy="11" r="2.3" fill="#1a1030"/><circle cx="15.4" cy="11" r="2.3" fill="#1a1030"/><path d="M12 13.6l-1.3 2.2h2.6z" fill="#1a1030"/><path d="M9.5 18v2.4M12 18v2.4M14.5 18v2.4" stroke="#1a1030" stroke-width="1.2"/></svg>';
const DKPUMP='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 6.4c-.8-2.4.5-3.6 2.4-4" fill="none" stroke="#5a8a2a" stroke-width="2" stroke-linecap="round"/><ellipse cx="12" cy="14.2" rx="9.4" ry="7.6" fill="#f0821e"/><path d="M8.4 7.2c-2.6 2-2.6 12 0 14M15.6 7.2c2.6 2 2.6 12 0 14M12 6.8v14.8" stroke="#b8520e" stroke-width="1.2" fill="none"/><path d="M7.6 12.2l2.2 2H5.6zM16.4 12.2l2.2 2h-4.4zM7.4 16.8q4.6 3 9.2 0l-1.6 1.6-1.6-.8-1.4 1-1.4-1-1.6.8z" fill="#ffe27a"/></svg>';
/* ---------- where everything lives ---------- */
const DKN=[['pl','Play','dplay'],['gr','Gear','arm'],['pt','Pets','paw'],['pg','Progress','cat'],['sh','Shop','shop'],['mo','More','dmore']];
const DKG={wp:'gr',ut:'gr',pt:'pt',bt:'pg',bb:'pg',tr:'pg',sh:'sh',cr:'sh',st:'mo',hp:'mo',hb:'mo',sv:'mo',pf:'',pl:'pl',tt:'pl'};
const DKSUB={gr:[['wp','Armory',()=>armory()],['ut','Skill Tree',()=>upgrades()]],
 pg:[['bt','Collection',()=>catalog(title)],['bb','Bounties',()=>bountyBoard()],['tr','Trophies',()=>profile(1)]],
 sh:[['sh','Store',()=>shop()],['cr','Owned crates',()=>crateHub()]]};
const DKLAST={};/* the last sub-screen used in each group */
const DKGO={pl:()=>title(),gr:()=>(DKLAST.gr==='ut'?upgrades():armory()),pt:()=>{PTX.back=title;petHall()},pg:()=>(DKLAST.pg==='bb'?bountyBoard():DKLAST.pg==='tr'?profile(1):catalog(title)),sh:()=>(DKLAST.sh==='cr'?crateHub():shop()),mo:()=>moreSheet()};
/* the old sidebar keys still work for anything that calls NAVGO directly */
Object.assign(NAVGO,{hm:()=>title(),pl:()=>title(),bt:()=>catalog(title),pt:()=>{PTX.back=title;petHall()}});
function dkDetect(html){
 if(/class="pth/.test(html))return'pt';if(/class="ttroot/.test(html))return'tt';
 if(/class="ar2|<h2[^>]*>\s*Armory/.test(html))return'wp';if(/class="uhd|<h2[^>]*>\s*Skill Tree/.test(html))return'ut';
 if(/class="chh|<h2[^>]*>\s*Crates/.test(html))return'cr';if(/class="chl|<h2[^>]*>\s*(Catalog|Collection)/.test(html))return'bt';
 if(/class="shp|<h2[^>]*>\s*Shop/.test(html))return'sh';if(/<h2[^>]*>\s*Bounty Board/.test(html))return'bb';
 if(/<h2[^>]*>\s*(Profile|Prestige)|class="pfhead/.test(html))return profile.tab==='Trophies'?'tr':'pf';
 if(/<h2[^>]*>\s*Settings/.test(html))return'st';if(/class="help"/.test(html))return'hp';if(/<h2[^>]*>\s*Menu background/.test(html))return'hb';if(/class="svc"/.test(html))return'sv';
 if(/class="(phg|em|wam|gym|dcx|cm)\b|<h2[^>]*>\s*(Campaign|Choose a map|Practice Range|Play\s*<)/.test(html))return'pl';
 for(const [re,k] of NAVDET)if(re.test(html))return k==='hm'?'hb':k;return''}
function shellNav(cls,html){if(S.mode!=='title'||!(S.view==='menu'||S.view==='camp'||S.view==='dc'))return null;if(/\b(casbg|clear|home|drw|nosb)\b/.test(cls))return null;return dkDetect(html)}

/* ---------- badges: only for something you can actually do ---------- */
const dkCrates=()=>(P.crates||0)+(P.acr||0)+(P.scr||0)+(P.pcr||0)+(P.hcr||0)+(P.ccr||0);
function dkBadge(k){try{
 if(k==='gr'){const sp=spNote();return newPaths().length?'!':sp>0?sp:''}
 if(k==='pt')return P.petSt===1||P.petPend?'!':(petEggsN()||'');
 if(k==='pg')return btyReady()||'';
 if(k==='sh')return dkCrates()||'';
 if(k==='mo')return dailyReady()||canPres()?'!':'';
 }catch(e){}return''}
const dkBdg=v=>v?`<i class="bdg">${v}</i>`:'';
function dkAlerts(){try{const key=dcKey(),run=dcBuild(key),dd=dcDone(key);return alertList(run,dd)}catch(e){return[]}}

/* the dock row: an optional sub-tab strip, the six destinations, and the corner tray (notifications and the daily calendar) */
let DKPI=-1;
function dkHTML(fine){const grp=fine==null?'':(DKG[fine]!==undefined?DKG[fine]:'');const sub=DKSUB[grp];const al=dkAlerts(),nb=al.length+updUnread();
 return `<div class="dkrow">${sub?`<nav class="dksub" aria-label="${DKN.find(d=>d[0]===grp)[1]} sections">${sub.map(([k,l])=>`<button class="dkst${k===fine?' on':''}" data-dks="${k}" ${k===fine?'aria-current="page"':''}>${l}${k==='cr'&&dkCrates()?`<i class="bdg">${dkCrates()}</i>`:k==='bb'&&btyReady()?`<i class="bdg">${btyReady()}</i>`:k==='ut'&&spNote()>0?`<i class="bdg">${spNote()}</i>`:''}</button>`).join('')}</nav>`:''}
 <nav class="dk" aria-label="Main menu" style="--i:${Math.max(0,DKN.findIndex(d=>d[0]===grp))};--p:${DKPI<0?Math.max(0,DKN.findIndex(d=>d[0]===grp)):DKPI}">${grp&&DKN.some(d=>d[0]===grp)?'<i class="dkpill" aria-hidden="true"></i>':''}${DKN.map(([k,l,ic])=>`<button class="dki${grp===k?' on':''}" data-dk="${k}" id="dk_${k}" ${grp===k?'aria-current="page"':''} ${k==='mo'?'aria-haspopup="dialog"':''}><span class="dkic">${mico(ic,42)}</span><b>${l}</b>${dkBdg(dkBadge(k))}</button>`).join('')}</nav>
 <div class="dkc hxn"><button class="dkcb${nb?' ring':''}" id="bell" data-tip="Notifications" title="Notifications" aria-label="Notifications${nb?` (${nb} new)`:''}" aria-haspopup="true" aria-expanded="false">${mico('dbell',30)}${nb?`<i class="bdg">${nb}</i>`:''}</button><div class="bellp" id="bellp" role="menu"></div>
  <button class="dkcb" id="dkcal" data-tip="Daily rewards" title="Daily rewards calendar (D)" aria-label="Daily rewards calendar">${mico('dcal',30)}${dailyReady()?'<i class="bdg">!</i>':''}</button></div></div>`}
function sbHTML(nav){return dkHTML(nav)}
function sbBind(){dkWire(ov)}
function dkWire(root){root.querySelectorAll('[data-dk]').forEach(b=>b.onclick=()=>{const k=b.dataset.dk;if(k!=='mo'&&b.classList.contains('on')&&k!=='pl'&&!root.querySelector('.dksub'))return;try{beep(520,.04,'triangle',.22)}catch(e){}DKGO[k]()});
 root.querySelectorAll('[data-dks]').forEach(b=>b.onclick=()=>{if(b.classList.contains('on'))return;try{beep(600,.04,'triangle',.2)}catch(e){}const g=Object.keys(DKSUB).find(g=>DKSUB[g].some(s=>s[0]===b.dataset.dks));const it=DKSUB[g].find(s=>s[0]===b.dataset.dks);it[2]()});
 const c=root.querySelector('#dkcal');if(c)c.onclick=()=>dailyMenu(title);
 try{bellBind(dkAlerts())}catch(e){}}
/* after every menu render: the dock sits at the end of the page, the old corner buttons step aside */
{const s0=show;show=function(h,c){const r=s0.apply(this,arguments);try{dkAfter()}catch(e){}return r}}
{const h0=hide;hide=function(){const r=h0.apply(this,arguments);try{dkCorner()}catch(e){}return r}}
function dkAfter(){dkNarrow();{const d=ov.querySelector('.dk'),pl=d&&d.querySelector('.dkpill');if(pl){const cs=getComputedStyle(d),i=+cs.getPropertyValue('--i')||0,p=+cs.getPropertyValue('--p')||0,bs=d.querySelectorAll('.dki');DKPI=i;if(p!==i&&bs[p]&&bs[i]&&!dkRM()){pl.style.transform=`translateX(${bs[p].offsetLeft-bs[i].offsetLeft}px)`;requestAnimationFrame(()=>requestAnimationFrame(()=>pl.classList.add('go')))}}}const row=ov.querySelector(':scope>.dkrow');if(row&&ov.lastElementChild!==row)ov.appendChild(row);
 const f=ov.querySelector('.dkst.on');if(f){const g=Object.keys(DKSUB).find(g=>DKSUB[g].some(s=>s[0]===f.dataset.dks));if(g)DKLAST[g]=f.dataset.dks}
 dkCorner();dkFit();requestAnimationFrame(dkFit);setTimeout(dkFit,350)}
/* pages were laid out for the full 900px height; with the dock taking room at the bottom, scale a tall page down just enough to fit */
function dkFit(){const mn=ov.querySelector(':scope>.mn'),row=ov.querySelector(':scope>.dkrow');if(!mn||!row||ov.classList.contains('dkmod'))return;
 const keep=ov.scrollTop;mn.style.zoom='';const av=ov.clientHeight-row.offsetHeight,need=mn.scrollHeight;if(need>av+4){const z=Math.max(.74,av/need);mn.style.zoom=z.toFixed(3)}ov.scrollTop=keep}
function dkCorner(){const on=!!ov.querySelector('.dkrow')&&!ov.classList.contains('hide');const c=$('cn');if(c)c.classList.toggle('dkhid',on)}

/* ---------- PLAY: the hub ---------- */
function title(){S.rift=0;S.prac=null;S.dc=null;dcSync();syncPaths();S.mode='title';S.view='menu';S.cr2=null;
 const l=lvl(P.xp),cur=Math.min(30,P.camp),LV=LEVELS[cur-1],done=Object.keys(P.stars).length,stars=Object.values(P.stars).reduce((x,y)=>x+(y||0),0);
 const key=dcKey(),run=dcBuild(key),dd=dcDone(key),st=dcStreak();dcApply(run);
 const imgD=sceneShot(run.L,640,320,'dd'+key,'brightness(1.45) contrast(1.06) saturate(1.3)'),tro=ACH.filter(a=>P.ach[a.id]).length,pth=PATHS[P.path]||{n:'Hero',c:'#ffd45a'};
 const allDone=!!P.stars[30],nm=allDone?'Every land conquered':LV.n,ws=nm.split(' '),last=ws.pop();
 const cta=allDone?'Replay campaign':done?'Continue campaign':'Begin campaign',ev=hwOn();
 show(`<div class="dkh" id="dkh">
 <header class="dkhd"><button class="dklogo" id="dklogo" title="Type Warriors home" aria-label="Type Warriors, home"><svg class="sbsw" viewBox="0 0 40 130" aria-hidden="true"><path d="M20 2L27 16V84H13V16Z" fill="#cfd8ea"/><path d="M20 2L27 16V84H20Z" fill="#8fa0bf"/><path d="M4 84H36V94H4Z" fill="#d8a830"/><path d="M16 94H24V122H16Z" fill="#7a4a24"/><circle cx="20" cy="126" r="5" fill="#d8a830"/></svg><h1><span>Type</span><span>Warriors</span></h1></button>
  <div class="dkst0"><button class="dkme dkg" id="np" title="Profile (O)"><span class="dkav"><canvas id="hxav" width="112" height="112"></canvas></span><span class="dkmt"><b>${esc(P.name)}</b><small>${pth.n} · Lv. ${l}</small></span><i class="dkchev">›</i>${canPres()?'<i class="bdg">!</i>':''}</button>
   <span class="dkgold" title="Your gold" aria-label="${P.gold.toLocaleString()} gold"><span class="coin"></span><b id="dkgold">${P.gold.toLocaleString()}</b></span>
   <button class="dktro" id="tr" title="Trophies (T)" aria-label="Trophies, ${tro} of ${ACH.length}">${mico('cup',30)}<b>${tro}</b><small>/ ${ACH.length}</small></button></div></header>
 <section class="dkcp dkg" aria-label="Campaign"><i class="dkgl"></i>
  <p class="dkey">Campaign <u>·</u> Level ${cur}</p>
  <h2 class="dkttl">${ws.length?esc(ws.join(' '))+' ':''}<em>${esc(last)}</em></h2>
  ${allDone?'':`<p class="dkbl">${esc(LV.blurb||'')}</p>`}
  <div class="dkst1"><span>${mico('cat',30)}<b>${done} / 30</b> stages</span><i></i><span><span class="dkstar">★</span><b>${stars} / 90</b> stars</span>${allDone?'':`<i></i><span class="dkbs" title="The boss of this land">${DKSKULL}<small>Region boss:</small><b>${esc(LV.bn)}</b></span>`}</div>
  <div class="dkpr"><span class="dkbar" style="--w:${(done/30*100).toFixed(1)}%" role="progressbar" aria-label="Campaign stages cleared" aria-valuemin="0" aria-valuemax="30" aria-valuenow="${done}"><i></i>${done?'<u></u>':''}</span><button class="dkvs" id="cp" title="View stages (C)">View stages <i>›</i></button></div>
  <div class="dkbt"><button class="dkgo dkg" id="dkcont"><i class="dkgl"></i>${cta} <i>›</i></button><button class="dkmode dkg" id="dkmode" aria-haspopup="dialog"><i class="dkgl"></i><span class="dkgrid" aria-hidden="true"><i></i><i></i><i></i><i></i></span>Choose mode <i>›</i></button></div>
  <div class="dksc">
   <button class="dkcard dkdaily dklive dkg dktilt${dd?' done':''}" id="dcb" title="Daily challenge (G)" style="--dac:${run.R.a||'#5ad8e8'}" aria-label="Daily challenge ${run.n}: ${esc(run.R.n)}, ${esc(run.M.n)}${dd?', completed':''}"><canvas class="dkcv" width="560" height="260" data-dkd="1" aria-hidden="true"></canvas><i class="dkgl"></i><span class="dkcl"><small>DAILY CHALLENGE #${run.n}${st?` · <span class="dkstk">🔥${st}</span>`:''}</small><b>${esc(run.R.n)}</b><span class="dkchip">${dd?`✓ Rank ${esc(dd.grade||'')}`:esc(run.M.n)}</span></span><i class="dkchv">›</i></button>
   ${ev?`<button class="dkcard dkev dklive dkg dktilt" id="dkev" aria-haspopup="dialog"><canvas class="dkcv" width="560" height="320" data-dkcv="treat" aria-hidden="true"></canvas><i class="dkgl"></i><span class="dkcl"><b>Halloween events</b><span class="dkevl"><span>${DKPUMP}Trick-or-Treat</span><span>${DKPUMP}Monster Mash</span></span><small class="dkevv">View events <i>›</i></small></span><em class="dkleft">${hwLeft()}</em></button>`
   :`<button class="dkcard dkend dklive dkg dktilt" id="go" title="Endless (E)"><canvas class="dkcv" width="560" height="320" data-dkcv="endless" aria-hidden="true"></canvas><i class="dkgl"></i><span class="dkcl"><small>ENDLESS</small><b>Survive round after round</b><small class="dkevv">${P.best?`Best round ${P.bestWave}`:'Set your first record'} <i>›</i></small></span></button>`}
  </div></section>
 <div class="dkhot" id="dkhot" aria-hidden="true" title="Cheer!"></div>
 <div class="dkhs"><button class="dkhb dkg" id="dkmp"><i class="dkgl"></i>${mico('paw',30)}Manage pet${P.petSt===1||P.petPend?'<i class="bdg">!</i>':petEggsN()?`<i class="bdg">${petEggsN()}</i>`:''}</button><button class="dkhb dkg" id="dkmg"><i class="dkgl"></i>${dkIco('pl',30)}Manage gear${newPaths().length?'<i class="bdg">!</i>':''}</button></div>
 <div class="dkstage" aria-hidden="true"><div class="dkvig" style="--img:url(${sceneShot(LV,640,340,'hv')})"><canvas id="dkhero" width="640" height="340"></canvas></div></div>
 ${dkHTML('pl')}</div>`,'m home dkhome');HOME=true;
 DKE.t0=S.t;dkWire(ov);live('hxav',portraitView);dkNarrow();dkVignette();
 ov.querySelectorAll('canvas[data-dkd]').forEach(c=>{try{dkDailyLive(c,run,imgD,dd)}catch(e){}});
 ov.querySelectorAll('canvas[data-dkcv]').forEach((c,i)=>{const k=c.dataset.dkcv,g=c.getContext('2d');const d=t=>{try{ptActScene(k,g,c.width,c.height,dkRM()?2.5:t)}catch(e){}};d(2.5);if(!dkRM())LIVE.push({cv:c,fn:d,slow:2,ph:i})});
 $('dklogo').onclick=()=>{ov.scrollTop=0;try{beep(520,.04,'triangle',.2)}catch(e){}};
 $('np').onclick=()=>{profile.tab='Overview';profile()};$('tr').onclick=()=>profile(1);
 $('cp').onclick=()=>campaign(cmCur());
 $('dkcont').onclick=()=>{if(allDone)return campaign(cmCur());start(cmCur())};
 $('dkmode').onclick=()=>modeSheet();
 $('dkmp').onclick=()=>{PTX.back=title;petHall()};$('dkmg').onclick=()=>armory();
 $('dkhot').onclick=()=>{if(typeof dkFlourish==='function')dkFlourish()};
 $('dcb').onclick=()=>dcMenu(title);
 const evb=$('dkev');if(evb)evb.onclick=()=>modeSheet('ev');const gob=$('go');if(gob)gob.onclick=()=>endlessMenu(title);
 dkCorner()}
/* the old Play hub now means: open the hub with the mode picker up */
function playHub(){title();modeSheet()}

/* keyboard shortcuts on the hub keep their old letters */
function homeKey(e){if(!HOME||e.ctrlKey||e.metaKey||e.altKey||document.querySelector('.dks'))return false;const ae=document.activeElement,t=ae&&ae.tagName;if(ae!==inp&&(t==='INPUT'||t==='TEXTAREA'||t==='SELECT'))return false;
 const k=e.key.length===1?e.key.toLowerCase():'';const A={c:()=>campaign(cmCur()),e:()=>endlessMenu(title),r:()=>ARENA_ON?waMenu(title):(riftOpen()&&start(0,'rift')),p:()=>pracMenu(title),g:()=>dcMenu(title),m:()=>hwOn()?gyMenu(title):modeSheet(),
  a:()=>armory(),k:()=>upgrades(),l:()=>catalog(title),b:()=>bountyBoard(),s:()=>shop(),x:()=>crateHub(),o:()=>{profile.tab='Overview';profile()},t:()=>profile(1),h:()=>help(title),d:()=>dailyMenu(title),',':()=>settings(title)};
 let f=A[k];if(e.key==='Enter'&&!e.repeat&&(ae===document.body||ae===inp))f=A.c;if(f){e.preventDefault();f();return true}return false}

/* ---------- the scenery behind the hub: your current campaign land, with your hero and companion standing in it ---------- */
const dkRM=()=>{try{return matchMedia('(prefers-reduced-motion: reduce)').matches}catch(e){return false}};
const dkHomeL=()=>{const h=hbgCur();if(h>=0)return LEVELS[h];if(P.hbg===-1)return null;return LEVELS[Math.min(30,P.camp)-1]};
function drawBG(){if(S.mode==='title'){if(S.view==='dc'&&S.dcv)zoneBG(0,S.t,S.dcv);else if(S.view==='camp'){ctx.fillStyle='#05030c';ctx.fillRect(0,0,W,H)}
  else{const L=HOME?dkHomeL():(hbgCur()>=0?LEVELS[hbgCur()]:null);if(L)zoneBG(L.z,S.t,L);else menuBG(S.t);if(HOME)homeScene(S.t)}}
 else if(S.mode==='crate')(S.cr2&&S.cr2.ck==='h'?sceneGen(SCN[32],S.t):menuBG(S.t));else{const L=(S.prac&&S.prac.map!=null&&S.prac.map!==31)?mapDef(S.prac.map):lvDef(S.wave||1);bgBlend(L)}}
/* the hub scenery: light from above, drifting mist, and your hero and companion arriving into the land */
const DKE={t0:-9,first:true};
const dkMix=(a,b,k)=>{const p=s=>[1,3,5].map(i=>parseInt(s.slice(i,i+2),16));const A=p(a),B=p(b);return'#'+A.map((v,i)=>Math.round(v+(B[i]-v)*k).toString(16).padStart(2,'0')).join('')};
function homeScene(t){if(ov.classList.contains('dknar'))return homeEmbers(t);const c=ctx,rm=dkRM(),tt=rm?2:t,pc=(PATHS[P.path]||{}).c||'#ffd45a',hx=1190,hy=GY-6;
 const L=dkHomeL(),ac=(L&&L.a&&/^#[0-9a-f]{6}$/i.test(L.a))?L.a:'#b49cff',warm=dkMix(ac,'#ffe6b0',.55);
 /* arrival: the first hub of a session gets a short entrance, later visits a quick fade */
 const ed=DKE.first?1.1:.35,ek=rm?1:Math.max(0,Math.min(1,(S.t-DKE.t0)/ed)),ee=1-Math.pow(1-ek,3);if(ek>=1)DKE.first=false;
 c.save();
 /* soft god-rays falling from the upper right */
 c.globalCompositeOperation='lighter';for(let i=0;i<5;i++){const sw=Math.sin(tt*.18+i*1.7)*.05,a=.035+.02*Math.sin(tt*.5+i*2.1);c.save();c.translate(1380+i*28,-40);c.rotate(.42+i*.07+sw);const q=c.createLinearGradient(0,0,0,880);q.addColorStop(0,warm+Math.round(a*255*ee).toString(16).padStart(2,'0'));q.addColorStop(1,warm+'00');c.fillStyle=q;c.beginPath();c.moveTo(-14-i*4,0);c.lineTo(14+i*4,0);c.lineTo(90+i*26,880);c.lineTo(-90-i*26,880);c.closePath();c.fill();c.restore()}
 c.globalCompositeOperation='source-over';
 /* embers drifting up through the scene, tinted to the land */
 for(const e of EMB){const y=((e.y-tt*e.v*.6)%H+H)%H,x=e.x+Math.sin(tt*.7+e.p)*24;if(x<760)continue;c.globalAlpha=(.2+.4*Math.abs(Math.sin(tt*1.3+e.p)))*ee;c.fillStyle=e.s>1.6?warm:'#ffc88a';c.beginPath();c.arc(x,y,e.s,0,TAU);c.fill()}c.globalAlpha=1;
 /* a pool of light and a contact shadow ground the hero */
 let q=c.createRadialGradient(hx,hy-160,10,hx,hy-160,340);q.addColorStop(0,pc+Math.round(46*ee).toString(16).padStart(2,'0'));q.addColorStop(.6,ac+Math.round(14*ee).toString(16).padStart(2,'0'));q.addColorStop(1,pc+'00');c.fillStyle=q;c.fillRect(hx-360,hy-500,720,540);
 q=c.createRadialGradient(hx,hy+4,4,hx,hy+4,160);q.addColorStop(0,'#000000a8');q.addColorStop(1,'#00000000');c.fillStyle=q;c.beginPath();c.ellipse(hx-60,hy+4,230,26,0,0,TAU);c.fill();
 /* the turning rune ring under their feet, and a pulse every few seconds */
 c.save();c.translate(hx,hy+2);c.scale(1,.22);c.globalAlpha=ee;c.strokeStyle=pc+'70';c.lineWidth=5;c.setLineDash([16,12]);c.lineDashOffset=-tt*20;c.beginPath();c.arc(0,0,128,0,TAU);c.stroke();c.setLineDash([]);
 c.strokeStyle=pc+'30';c.lineWidth=2;c.beginPath();c.arc(0,0,150,0,TAU);c.stroke();
 for(let i=0;i<8;i++){const a=i*TAU/8+tt*.25;c.fillStyle=pc+'aa';c.beginPath();c.arc(Math.cos(a)*150,Math.sin(a)*150,4,0,TAU);c.fill()}
 const pk=rm?1:((tt%5.5)/1.6);if(pk<1){c.strokeStyle=pc+Math.round((1-pk)*160).toString(16).padStart(2,'0');c.lineWidth=6*(1-pk)+1;c.beginPath();c.arc(0,0,128+pk*120,0,TAU);c.stroke()}
 /* the arrival flash */if(ek<1&&DKE.first!==null){const fk=Math.min(1,ek*1.3);c.strokeStyle=warm+Math.round((1-fk)*230).toString(16).padStart(2,'0');c.lineWidth=14*(1-fk)+2;c.beginPath();c.arc(0,0,60+fk*260,0,TAU);c.stroke()}
 c.restore();
 /* the hero, in the current equipment, idling (rises into place on arrival) */
 const dy=(1-ee)*26;c.save();c.globalAlpha=ee;c.translate(hx,hy+dy);c.scale(2.15,2.15);try{drawHero(c,{arm:P.armor,wp:P.weapon,col:P.col,t:tt,lg:0})}catch(e){}c.restore();
 if(ek<1){const fk=ek;q=c.createRadialGradient(hx,hy-170,10,hx,hy-170,260);q.addColorStop(0,'#ffffff'+Math.round(Math.max(0,1-fk*1.6)*120).toString(16).padStart(2,'0'));q.addColorStop(1,'#ffffff00');c.globalCompositeOperation='lighter';c.fillStyle=q;c.fillRect(hx-280,hy-440,560,480);c.globalCompositeOperation='source-over'}
 /* the equipped companion sits beside them, arriving a moment later */
 if(P.pet&&typeof PDEF!=='undefined'&&PDEF[P.pet]){const pe=rm?1:Math.max(0,Math.min(1,(S.t-DKE.t0-(ed*.35))/ed)),pee=1-Math.pow(1-pe,3);c.save();const hv=PDEF[P.pet].hover;c.globalAlpha=pee;c.translate(hx-215-(1-pee)*40,hy-(hv?40:0));c.scale(1.45,1.45);try{petDraw(c,P.pet,Object.assign({t:tt+3,pose:'idle',u:0},petLook(P.pet)))}catch(e){}c.restore()}
 /* ground mist drifting across the stage */
 for(let i=0;i<4;i++){const x=((tt*(9+i*4)+i*420)%1500)+500,y=hy-10+i*8;q=c.createRadialGradient(x,y,4,x,y,220);q.addColorStop(0,dkMix(ac,'#ffffff',.6)+'1c');q.addColorStop(1,'#ffffff00');c.globalAlpha=ee;c.fillStyle=q;c.beginPath();c.ellipse(x,y,260,46,0,0,TAU);c.fill()}c.globalAlpha=1;
 c.restore();
 /* fireflies in the light */for(let i=0;i<14;i++){const u=((tt*.12+i*.137)%1),x=hx-260+((i*97)%520)+Math.sin(tt*.9+i)*14,y=hy-u*400;c.globalAlpha=Math.sin(u*Math.PI)*.8*ee;const col=i%3?'#ffe9a0':i%2?pc:warm;q=c.createRadialGradient(x,y,0,x,y,7);q.addColorStop(0,col+'aa');q.addColorStop(1,col+'00');c.fillStyle=q;c.beginPath();c.arc(x,y,7,0,TAU);c.fill();c.fillStyle=col;c.beginPath();c.arc(x,y,1.2+(i%3)*.7,0,TAU);c.fill()}c.globalAlpha=1;
 /* a darker foreground edge keeps the eye on the stage */
 q=c.createLinearGradient(0,H-120,0,H);q.addColorStop(0,'#05030c00');q.addColorStop(1,'#05030c99');c.fillStyle=q;c.fillRect(760,H-120,W-760,120)}

function homeEmbers(t){const c=ctx,tt=dkRM()?2:t;for(const e of EMB){const y=((e.y-tt*e.v*.6)%H+H)%H,x=e.x+Math.sin(tt*.7+e.p)*24;c.globalAlpha=.2+.4*Math.abs(Math.sin(tt*1.3+e.p));c.fillStyle='#ffc88a';c.beginPath();c.arc(x,y,e.s,0,TAU);c.fill()}c.globalAlpha=1}
/* on narrow screens (phones, small windows) the hero stands in a small vignette below the campaign panel instead */
function dkNarrow(){const n=ov.clientWidth>0&&ov.clientWidth<1100;ov.classList.toggle('dknar',n);ov.classList.toggle('dkshort',ov.clientHeight>0&&ov.clientHeight<640);return n}
function dkVignette(){const c=$('dkhero');if(!c)return;const g=c.getContext('2d');LIVE.push({cv:c,fn:t=>{if(!ov.classList.contains('dknar'))return;const tt=dkRM()?2:t,pc=(PATHS[P.path]||{}).c||'#ffd45a';g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,640,340);
  const hx=400,hy=316;let q=g.createRadialGradient(hx,hy-120,6,hx,hy-120,220);q.addColorStop(0,pc+'38');q.addColorStop(1,pc+'00');g.fillStyle=q;g.fillRect(0,0,640,340);
  q=g.createRadialGradient(hx,hy+2,2,hx,hy+2,110);q.addColorStop(0,'#000a');q.addColorStop(1,'#0000');g.fillStyle=q;g.beginPath();g.ellipse(hx,hy+2,110,16,0,0,TAU);g.fill();
  g.save();g.translate(hx,hy+2);g.scale(1,.22);g.strokeStyle=pc+'70';g.lineWidth=4;g.setLineDash([12,9]);g.lineDashOffset=-tt*20;g.beginPath();g.arc(0,0,92,0,TAU);g.stroke();g.setLineDash([]);const pk=dkRM()?1:((tt%5.5)/1.6);if(pk<1){g.strokeStyle=pc+Math.round((1-pk)*150).toString(16).padStart(2,'0');g.lineWidth=5*(1-pk)+1;g.beginPath();g.arc(0,0,92+pk*90,0,TAU);g.stroke()}g.restore();
  for(let i=0;i<9;i++){const u=((tt*.12+i*.137)%1),x=hx-200+((i*97)%400)+Math.sin(tt*.9+i)*10,y=hy-u*280;g.globalAlpha=Math.sin(u*Math.PI)*.8;g.fillStyle=i%3?'#ffe9a0':pc;g.beginPath();g.arc(x,y,1.2+(i%3)*.7,0,TAU);g.fill()}g.globalAlpha=1;
  g.save();g.translate(hx,hy);g.scale(1.55,1.55);try{drawHero(g,{arm:P.armor,wp:P.weapon,col:P.col,t:tt,lg:0})}catch(e){}g.restore();
  if(P.pet&&PDEF[P.pet]){g.save();g.translate(hx-170,hy-(PDEF[P.pet].hover?30:0));g.scale(1.1,1.1);try{petDraw(g,P.pet,Object.assign({t:tt+3,pose:'idle',u:0},petLook(P.pet)))}catch(e){}g.restore()}},slow:2})}
{const a0=applyLayout;applyLayout=function(){const r=a0.apply(this,arguments);try{if(ov.querySelector('.dkh,.dkrow'))dkNarrow();dkFit()}catch(e){}return r}}
/* ---------- sheets: one at a time, Escape closes, focus stays inside ---------- */
function dkSheet(id,html,opener,onReady){dkClose(true);const sh=document.createElement('div');sh.className='dks';sh.id=id;sh.innerHTML=`<div class="dksb" data-x></div><div class="dkp" role="dialog" aria-modal="true" aria-labelledby="${id}h">${html}</div>`;
 const kids=[...ov.children];kids.forEach(k=>{k.inert=true});ov.appendChild(sh);ov.classList.add('dkmod');
 const op=opener||document.activeElement;const close=()=>{document.removeEventListener('keydown',key,true);kids.forEach(k=>{k.inert=false});ov.classList.remove('dkmod');sh.classList.add('out');setTimeout(()=>sh.remove(),180);try{op&&op.isConnected&&op.focus({preventScroll:true})}catch(e){}};
 const key=e=>{if(!sh.isConnected){document.removeEventListener('keydown',key,true);return}if(e.key==='Escape'){e.preventDefault();e.stopPropagation();const bk=sh.querySelector('[data-back]');if(bk&&bk.offsetParent)bk.click();else close();return}
  if(e.key==='Tab'){const f=[...sh.querySelectorAll('button:not([disabled]),[href],input,select,[tabindex]:not([tabindex="-1"])')].filter(x=>x.offsetParent);if(!f.length)return;const a=f[0],z=f[f.length-1];if(e.shiftKey&&document.activeElement===a){e.preventDefault();z.focus()}else if(!e.shiftKey&&document.activeElement===z){e.preventDefault();a.focus()}}
  e.stopPropagation()};
 document.addEventListener('keydown',key,true);sh._close=close;sh.querySelectorAll('[data-x]').forEach(b=>b.onclick=close);if(onReady)onReady(sh,close);
 requestAnimationFrame(()=>{sh.classList.add('on');const f=sh.querySelector('[data-first]')||sh.querySelector('.dkp button');try{f&&f.focus({preventScroll:true})}catch(e){}});return sh}
function dkClose(now){const s=ov.querySelector('.dks');if(s&&s._close){if(now){document.querySelectorAll('.dks').forEach(x=>{if(x._close)x._close()})}else s._close()}}

/* ---------- Choose a mode ---------- */
function modeSheet(view){const op=$('dkmode')||document.activeElement;const cur=cmCur(),LV=LEVELS[cur-1];let run=null;try{run=dcBuild(dcKey())}catch(e){}
 const ro=riftOpen(),ev=hwOn(),img=(L,k)=>{try{return sceneShot(L,640,480,k)}catch(e){return''}};
 const card=(id,t,d,ic,c,im,extra)=>`<button class="dkm" id="${id}" style="--c:${c}${im?`;--img:url(${im})`:''}" ${extra||''}><span class="dkmi">${ic}</span><span class="dkmt"><b>${t}</b><small>${d}</small></span><i class="dkchv">›</i></button>`;
 const casIc=(()=>{const z=$('cz');return z&&z.querySelector('svg')?z.querySelector('svg').outerHTML:mico('gift',54)})();
 const main=`<header class="dkph"><h3 id="dkmsh">Choose a mode</h3><button class="dkx" data-x aria-label="Close"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" fill="none"/></svg><span>Close</span></button></header>
  <div class="dkmg">
   ${card('dmc','Campaign',P.stars[30]?'All 30 lands conquered':`Continue your adventure · Level ${cur}`,mico('camp',58),'#ffc94a',img(LV,'c2'),'data-first')}
   ${card('dme','Endless','Survive round after round',mico('endless',58),'#ff8a3a',img(LEVELS[17],'e'))}
   ${ARENA_ON?card('dma',"Warden's Arena",'Block, counter, survive. No typing needed.',mico('dplay',58),'#ffb04a',img(mapDef(30),'r'))
     :card('dma','Starfall Rift',ro?'A timed frenzy. Kills add time.':'Unlocks at level 5',mico('rift',58),'#b07aff',img(mapDef(30),'r'),ro?'':'disabled')}
   ${card('dmd','Daily challenge',run?`${esc(run.R.n)} · ${esc(run.M.n)}`:'Today\'s challenge',mico('gift',58),'#5ad3e8',run?img(run.L,'dm'):'')}
   ${card('dmv','Events',ev?'Trick-or-Treat · Monster Mash':'Halloween has ended · Trick-or-Treat stays open',DKPUMP,'#ff9a2a',ev?gyThumb():'','aria-haspopup="true"')}
   ${card('dmk','Casino','Play the casino games',casIc,'#e0344a','')}
  </div>
  <button class="dkpr2" id="dmp">${mico('prac',34)}<span><b>Practice Range</b><small>Drill your keys, no pressure</small></span><i class="dkchv">›</i></button>`;
 const evs=`<header class="dkph"><button class="dkx dkbk" data-back aria-label="Back to modes">${hico('back',20)}<span>Modes</span></button><h3 id="dkmsh">${ev?'Halloween events':'Events'}</h3><button class="dkx" data-x aria-label="Close"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" fill="none"/></svg><span>Close</span></button></header>
  <p class="dkpn">${ev?`Two separate limited-time modes. ${esc(hwLeft())}.`:'The event has closed. Trick-or-Treat stays open so you can look over your candy corn and rewards.'}</p>
  <div class="dkmg dkmg1">
   ${card('dmt','Trick-or-Treat','Walk a haunted street, knock on doors and collect candy corn.',DKPUMP,'#ff9a2a','','data-first')}
   ${ev?card('dmg','Monster Mash','A cursed Endless run. New curse every level.',mico('endless',58).replace(/#ff7a4a/g,'#7affc8'),'#7affc8',gyThumb()):''}
  </div>`;
 dkSheet('dkms',`<div class="dkpv" data-v="m">${main}</div><div class="dkpv" data-v="e" hidden>${evs}</div>`,op,(sh,close)=>{
  const go=f=>()=>{close();setTimeout(f,0)};
  const set=v=>{sh.querySelectorAll('.dkpv').forEach(p=>p.hidden=p.dataset.v!==v);const f=sh.querySelector(`.dkpv[data-v="${v}"] [data-first]`)||sh.querySelector(`.dkpv[data-v="${v}"] button`);try{f&&f.focus()}catch(e){}};
  const B=(id,f)=>{const b=sh.querySelector('#'+id);if(b)b.onclick=f};
  B('dmc',go(()=>campaign(cmCur())));B('dme',go(()=>endlessMenu(title)));B('dma',go(()=>ARENA_ON?waMenu(title):(riftOpen()&&start(0,'rift'))));B('dmd',go(()=>dcMenu(title)));
  B('dmv',()=>set('e'));B('dmk',go(()=>casinoOpen()));B('dmp',go(()=>pracMenu(title)));
  B('dmt',go(()=>ttMenu()));B('dmg',go(()=>gyMenu(title)));const bk=sh.querySelector('[data-back]');if(bk)bk.onclick=()=>set('m');
  if(view==='ev')set('e')})}

/* ---------- More: every utility, labelled ---------- */
function moreSheet(){const op=$('dk_mo')||document.activeElement,al=dkAlerts(),nb=al.length+updUnread(),fs=(()=>{try{return!!fsOn()}catch(e){return false}})();
 const it=(id,ic,t,d,b)=>`<button class="dku" id="${id}"><span class="dkui">${ic}</span><span class="dkut"><b>${t}</b><small>${d}</small></span>${b?`<i class="bdg">${b}</i>`:''}</button>`;
 dkSheet('dkmo',`<header class="dkph"><h3 id="dkmoh">More</h3><button class="dkx" data-x aria-label="Close"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" fill="none"/></svg><span>Close</span></button></header>
  <div class="dkug">
   ${it('mpf',mico('user',40),'Profile','Your hero, stats and prestige',canPres()?'!':'')}
   ${it('mnt',mico('dbell',40),'Notifications','Alerts, updates and news',nb||'')}
   ${it('mcl',mico('dcal',40),'Daily rewards','Claim your calendar reward',dailyReady()?'!':'')}
   ${it('mst',mico('gear',40),'Settings','Display, sound, effects and data')}
   ${it('mhp',mico('help',40),'How to play','Basics, modes and tips')}
   ${it('mbg',mico('bg',40),'Menu background','Scenery behind the main menu')}
   ${it('msv',hico('lock',34),'Save &amp; backups','Export, import and restore progress')}
   ${it('mcz',(()=>{const z=$('cz');return z&&z.querySelector('svg')?z.querySelector('svg').outerHTML:''})(),'Casino','Play the casino games')}
  </div>
  <div class="dktg"><button class="dkt" id="mmu" aria-pressed="${!ST.mute}"><span>Music</span><b>${ST.mute?'Off':'On'}</b></button><button class="dkt" id="mfs" aria-pressed="${fs}"><span>Fullscreen</span><b>${fs?'On':'Off'}</b></button></div>`,op,(sh,close)=>{
  const go=f=>()=>{close();setTimeout(f,0)};const B=(id,f)=>{const b=sh.querySelector('#'+id);if(b)b.onclick=f};
  B('mpf',go(()=>{profile.tab='Overview';profile()}));B('mcl',go(()=>dailyMenu(title)));B('mst',go(()=>settings(title)));B('mhp',go(()=>help(title)));B('mbg',go(()=>hbgPick(title)));B('msv',go(()=>saveCenter(title)));B('mcz',go(()=>casinoOpen()));
  B('mnt',go(()=>{const b=$('bell');if(b){b.click();}}));
  B('mmu',()=>{const m=$('mt');if(m)m.click();const t=sh.querySelector('#mmu');t.setAttribute('aria-pressed',!ST.mute);t.querySelector('b').textContent=ST.mute?'Off':'On'});
  B('mfs',()=>{const f=$('fs');if(f)f.click();setTimeout(()=>{const on=(()=>{try{return!!fsOn()}catch(e){return false}})(),t=sh.querySelector('#mfs');if(t){t.setAttribute('aria-pressed',on);t.querySelector('b').textContent=on?'On':'Off'}},250)})})}

/* gold shown on the hub follows every purchase and reward */
{let shown=-1,raf=0;setInterval(()=>{try{const e=$('dkgold');if(!e||!P){shown=-1;return}const tgt=P.gold;const cur=+(e.dataset.v||tgt);if(shown<0||!e.dataset.v){e.dataset.v=tgt;shown=tgt;return}if(tgt===shown)return;
 cancelAnimationFrame(raf);const a=cur,t0=performance.now(),dur=dkRM()?0:650;const box=e.closest('.dkgold');if(box){box.classList.remove(tgt>a?'up':'dn','up','dn');void box.offsetWidth;box.classList.add(tgt>a?'up':'dn')}
 const st=()=>{const k=dur?Math.min(1,(performance.now()-t0)/dur):1,v=Math.round(a+(tgt-a)*(1-Math.pow(1-k,3)));e.textContent=v.toLocaleString();e.dataset.v=v;if(k<1&&e.isConnected)raf=requestAnimationFrame(st)};st();shown=tgt}catch(x){}},300)}

{const st=document.createElement('style');st.textContent=`
/* ----- the shell: page content, then the dock row (it takes real space and stays on screen) ----- */
#ov.sh:not(.clear){flex-direction:column;align-items:stretch;background:radial-gradient(ellipse at 50% 40%,rgba(7,4,18,.62),rgba(7,4,18,.86))}
#ov.sh .mn{flex:1 0 auto;min-height:0;padding-bottom:24px}
#cn.dkhid{display:none!important}
.dkrow{position:sticky;bottom:0;z-index:20;display:flex;flex-direction:column;align-items:center;gap:8px;padding:10px 0 14px;margin-top:auto;pointer-events:none;background:linear-gradient(180deg,#0000,#07041299 40%,#070412e6)}
.dkrow>*{pointer-events:auto}
.dk{display:flex;gap:4px;padding:7px;border-radius:24px;background:linear-gradient(180deg,#1b1442f2,#0f0a28f5);border:1px solid #4a3e8a;box-shadow:0 12px 34px #000c,inset 0 1px 0 #ffffff14}
.dki{all:unset;box-sizing:border-box;position:relative;cursor:pointer;width:122px;min-height:66px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;padding:6px 4px 7px;border-radius:17px;color:#c4badf;transition:background .15s,color .15s}
.dki .dkic{display:grid;place-items:center;height:40px;transition:transform .16s}.dki .dkic svg{filter:drop-shadow(0 3px 4px #0008)}
.dki b{font:700 15px/1.1 var(--ui);letter-spacing:.2px}
.dki:hover{background:#ffffff0d;color:#fff8e8}.dki:hover .dkic{transform:translateY(-2px)}
.dki.on{background:linear-gradient(180deg,#8a66e0,#5b3ea8);color:#fff;box-shadow:0 0 0 1px #b49cff88,0 6px 16px #2a106088,inset 0 1px 0 #ffffff33}
.dki.on::after{content:'';position:absolute;bottom:-11px;left:50%;width:0;height:0;border:7px solid transparent;border-top-color:#b49cff;transform:translateX(-50%)}
.dki:focus-visible,.dkst:focus-visible,.dkcb:focus-visible{outline:3px solid #ffd45a;outline-offset:2px}
.dki .bdg,.dkcb .bdg,.dkst .bdg,.dkme .bdg,.dku .bdg{position:absolute;top:4px;right:22px;min-width:20px;height:20px;padding:0 6px;box-sizing:border-box;border-radius:10px;display:grid;place-items:center;font:800 11.5px/1 var(--ui);font-style:normal;color:#fff;background:#e8364e;box-shadow:0 0 0 2px #0f0a28}
.dksub{display:flex;gap:4px;padding:4px;border-radius:14px;background:#120c2ef2;border:1px solid #3e3478;box-shadow:0 8px 22px #000a;animation:dkup .2s ease-out}
.dkst{all:unset;position:relative;cursor:pointer;padding:9px 18px;border-radius:10px;font:700 14.5px var(--ui);color:#c4badf;transition:background .15s,color .15s}.dkst:hover{color:#fff8e8;background:#ffffff0f}
.dkst.on{color:#fff;background:#7151be}.dkst .bdg{position:static;display:inline-grid;margin-left:6px;vertical-align:1px;box-shadow:none}
@keyframes dkup{from{opacity:0;transform:translateY(6px)}}
/* the corner tray */
.dkc{position:absolute;right:22px;bottom:18px;display:flex;gap:8px}
.dkcb{all:unset;position:relative;cursor:pointer;width:52px;height:52px;border-radius:16px;display:grid;place-items:center;background:linear-gradient(180deg,#1f174cf0,#120c30f2);border:1px solid #4a3e8a;box-shadow:0 8px 20px #000a;transition:background .15s,transform .15s}
.dkcb:hover{background:linear-gradient(180deg,#2c2266,#181040)}.dkcb .bdg{top:-5px;right:-5px}
.dkcb.ring svg{animation:dkring 2.4s ease-in-out infinite;transform-origin:50% 15%}@keyframes dkring{0%,80%,100%{transform:rotate(0)}84%{transform:rotate(14deg)}88%{transform:rotate(-12deg)}92%{transform:rotate(8deg)}96%{transform:rotate(-4deg)}}
.dkc .bellp{position:absolute;top:auto;bottom:calc(100% + 12px);right:0;left:auto;transform-origin:100% 100%}
/* ----- the hub ----- */
#ov.dkhome{padding:0;justify-content:flex-start;align-items:stretch;background:linear-gradient(90deg,rgba(6,3,16,.82),rgba(6,3,16,.5) 46%,rgba(6,3,16,.04) 64%,rgba(6,3,16,.12)),linear-gradient(0deg,rgba(6,3,16,.75),rgba(6,3,16,0) 24%)}
.dkh{position:relative;flex:1;display:grid;grid-template-columns:minmax(0,800px) 1fr;grid-template-rows:auto 1fr auto;min-height:100%;text-align:left}
.dkhd{grid-column:1/-1;display:flex;justify-content:space-between;align-items:flex-start;padding:22px 34px 0 40px}
.dklogo{all:unset;position:relative;cursor:pointer;display:flex;align-items:center;padding:4px 6px;animation:dkfade .5s ease-out both}.dklogo .sbsw{left:50%;top:-16px;width:28px;height:auto;margin-left:-14px}.dklogo h1{position:relative;z-index:1}
.dklogo h1{margin:0;display:flex;flex-direction:column;font:400 46px/.86 'Pirata One',Georgia,serif;letter-spacing:1px;background:linear-gradient(180deg,#fff6c8,#ffc83a 55%,#e07a10);-webkit-background-clip:text;background-clip:text;color:transparent;filter:drop-shadow(0 3px 0 #3a1400) drop-shadow(0 0 16px #ffb02a55)}
.dklogo:focus-visible{outline:3px solid #ffd45a;outline-offset:4px;border-radius:8px}
.dkst0{display:flex;align-items:center;gap:0;padding:6px;border-radius:22px;background:linear-gradient(180deg,#1b1442e8,#0f0a28ee);border:1px solid #4a3e8a;box-shadow:0 10px 30px #000b;animation:dkfade .5s .05s ease-out both}
.dkme{all:unset;position:relative;cursor:pointer;display:flex;align-items:center;gap:12px;padding:4px 16px 4px 4px;border-radius:17px;transition:background .15s}.dkme:hover{background:#ffffff0d}
.dkav{width:58px;height:58px;border-radius:50%;overflow:hidden;background:radial-gradient(circle at 40% 30%,#3a2e70,#120c2e);box-shadow:0 0 0 2.5px #ffd45a,0 0 14px #ffd45a55}.dkav canvas{width:100%;height:100%;display:block}
.dkmt{display:flex;flex-direction:column}.dkmt b{font:700 17px/1.2 var(--ui);color:#fff8e8;max-width:200px;overflow-wrap:anywhere}.dkmt small{font:500 13.5px var(--ui);color:#c4badf}
.dkchev{font:700 22px var(--ui);font-style:normal;color:#c4badf}.dkme .bdg{top:0;right:4px}
.dkgold{display:flex;align-items:center;gap:8px;padding:0 20px;border-left:1px solid #ffffff1a;border-right:1px solid #ffffff1a;height:44px}.dkgold b{font:800 19px var(--ui);color:#ffd45a}.dkgold .coin{width:22px;height:22px}
.dktro{all:unset;cursor:pointer;display:flex;align-items:center;gap:7px;padding:8px 16px;border-radius:16px;transition:background .15s}.dktro:hover{background:#ffffff0d}.dktro b{font:800 19px var(--ui);color:#fff8e8}.dktro small{font:600 15px var(--ui);color:#c4badf}
.dkme:focus-visible,.dktro:focus-visible{outline:3px solid #ffd45a;outline-offset:2px}
/* campaign panel */
.dkcp{grid-column:1;grid-row:2;align-self:center;margin:6px 0 0 40px;padding:30px 34px 30px;border-radius:24px;background:#111026eb;border:1px solid #3e3478;box-shadow:0 18px 48px #000c,inset 0 1px 0 #ffffff12;animation:dkin .5s .08s cubic-bezier(.2,.8,.2,1) both;max-width:760px}
@keyframes dkin{from{opacity:0;transform:translateY(14px)}}@keyframes dkfade{from{opacity:0}}
.dkey{margin:0 0 6px;font:700 14px var(--ui);letter-spacing:5px;text-transform:uppercase;color:#c4badf}.dkey u{text-decoration:none;opacity:.6;margin:0 6px}
.dkttl{margin:0;font:800 clamp(40px,4.4vw,64px)/1.02 var(--ui);letter-spacing:-1.5px;color:#fff8e8;text-shadow:0 4px 18px #000a}.dkttl em{font-style:normal;background:linear-gradient(100deg,transparent 40%,#fffbe0e0 50%,transparent 60%) 140% 0/250% 100% no-repeat,linear-gradient(180deg,#ffe98a,#ffc23a 60%,#f09a10);-webkit-background-clip:text;background-clip:text;color:transparent;animation:none}@keyframes dkshim{0%,75%{background-position:140% 0,0 0}100%{background-position:-50% 0,0 0}}
.dkst1{display:flex;align-items:center;gap:22px;margin:16px 0 12px;font:500 18px var(--ui);color:#fff8e8}.dkst1>span{display:flex;align-items:center;gap:8px}.dkst1 b{font-weight:700}.dkst1>i{width:1px;height:26px;background:#ffffff26}.dkstar{font-size:24px;color:#ffd45a;filter:drop-shadow(0 0 6px #ffb02a88)}
.dkpr{display:flex;align-items:center;gap:20px}.dkbar{flex:1;height:12px;border-radius:7px;background:#05030e;border:1px solid #ffffff14;overflow:hidden}.dkbar i{display:block;height:100%;width:var(--w);min-width:6px;border-radius:7px;background:linear-gradient(90deg,#ffc23a,#ffe27a);box-shadow:0 0 12px #ffc23a88;animation:dkbar 1s .3s cubic-bezier(.2,.8,.2,1) both}@keyframes dkbar{from{width:0}}
.dkvs{all:unset;cursor:pointer;font:600 16px var(--ui);color:#e8e0ff;padding:8px 4px;transition:color .15s}.dkvs:hover{color:#ffd45a}.dkvs i{font-style:normal;margin-left:6px}
.dkbt{display:flex;gap:16px;margin:22px 0 22px;padding-bottom:22px;border-bottom:1px solid #ffffff14}
.dkgo{all:unset;box-sizing:border-box;cursor:pointer;flex:1.35;display:flex;align-items:center;justify-content:center;gap:10px;min-height:62px;padding:0 22px;border-radius:16px;font:800 22px var(--ui);color:#2a1406;background:linear-gradient(180deg,#ffe98a,#ffc23a 55%,#f0a020);box-shadow:0 5px 0 #8a5010,0 10px 26px #ffb02a40,inset 0 1px 0 #fff8;transition:filter .14s,box-shadow .14s}
.dkgo{position:relative;overflow:hidden;isolation:isolate}.dkgo::after{content:'';position:absolute;inset:0;z-index:-1;background:linear-gradient(105deg,transparent 35%,#ffffffa0 50%,transparent 65%);background-size:260% 100%;background-position:130% 0;animation:none;pointer-events:none}@keyframes dksheen{0%,70%{background-position:130% 0}100%{background-position:-40% 0}}
.dkgo:hover{filter:brightness(1.07);box-shadow:0 5px 0 #8a5010,0 10px 30px #ffb02a70,inset 0 1px 0 #fff8}.dkgo:active{box-shadow:0 2px 0 #8a5010,0 6px 16px #ffb02a40;transform:translateY(3px)}.dkgo i{font-style:normal;font-size:26px}
.dkmode{all:unset;box-sizing:border-box;cursor:pointer;flex:1;display:flex;align-items:center;justify-content:center;gap:12px;min-height:62px;padding:0 20px;border-radius:16px;font:700 18px var(--ui);color:#fff8e8;background:#1a1440;border:1.5px solid #6a58c0;transition:background .14s,border-color .14s}
.dkmode:hover{background:#241c58;border-color:#9a86ff}.dkmode>i{font-style:normal;font-size:22px;color:#c4badf}
.dkgo:focus-visible,.dkmode:focus-visible,.dkvs:focus-visible,.dkcard:focus-visible{outline:3px solid #fff;outline-offset:3px}
.dkgrid{display:grid;grid-template-columns:repeat(2,10px);gap:3px}.dkgrid i{width:10px;height:10px;border-radius:2px;background:#e8e0ff}
.dksc{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.dkcard{all:unset;box-sizing:border-box;position:relative;cursor:pointer;min-height:156px;display:flex;align-items:flex-end;padding:16px 18px;border-radius:18px;overflow:hidden;isolation:isolate;border:1.5px solid #6a58c0;box-shadow:0 10px 24px #000a;transition:transform .16s,border-color .16s,box-shadow .16s}
.dkcard::before{content:'';position:absolute;inset:0;z-index:-2;background:var(--img) center/cover,linear-gradient(135deg,#3a1e6a,#120c2e);transition:transform .5s cubic-bezier(.2,1,.3,1)}
.dkcard::after{content:'';position:absolute;inset:0;z-index:-1;background:linear-gradient(180deg,#0000 20%,#07041299 55%,#070412ee)}
.dkcard:hover{transform:translateY(-3px);border-color:#b49cff;box-shadow:0 14px 30px #000c}.dkcard:hover::before{transform:scale(1.06)}
.dksc .dkcard{animation:dkin .5s cubic-bezier(.2,.8,.2,1) both}.dksc .dkcard:nth-child(1){animation-delay:.22s}.dksc .dkcard:nth-child(2){animation-delay:.3s}.dkevl svg{width:18px;height:18px;vertical-align:-3px;margin-right:6px}.dkmi svg{width:58px;height:58px}
.dkdaily{border-color:#5ad3e8aa}.dkev{border-color:#ff9a2aaa}.dkev:hover{border-color:#ffb85a}.dkdaily:hover{border-color:#8af0ff}
.dkcl{display:flex;flex-direction:column;gap:3px;max-width:calc(100% - 30px)}.dkcl small{font:800 12.5px var(--ui);letter-spacing:2.4px;color:#ffd45a}.dkcl b{font:800 23px/1.15 var(--ui);color:#fff8e8;text-shadow:0 2px 10px #000}
.dkchip{position:absolute;right:46px;bottom:18px;padding:5px 12px;border-radius:999px;font:700 13.5px var(--ui);color:#062e2e;background:linear-gradient(180deg,#9ff6e8,#3ac8b4)}.dkdaily.done .dkchip{color:#0a3a18;background:linear-gradient(180deg,#b8ffc8,#3ad87a)}
.dkchv{position:absolute;right:16px;bottom:18px;font:700 26px/1 var(--ui);font-style:normal;color:#fff8e8;transition:transform .15s}.dkcard:hover .dkchv,.dkm:hover .dkchv{transform:translateX(3px)}
.dkevl{display:flex;flex-direction:column;gap:2px;font:500 15px var(--ui);color:#fff8e8;margin:2px 0 4px}.dkevv{font:600 15px var(--ui)!important;letter-spacing:0!important;color:#e8e0ff!important}.dkevv i{font-style:normal;margin-left:4px}
.dkev .dkchv{display:none}.dkleft{position:absolute;right:14px;top:12px;padding:3px 10px;border-radius:9px;font:700 12px var(--ui);font-style:normal;color:#fff;background:#00000080}
.dkstage{grid-column:2;grid-row:2}
.dkhome .dkrow{grid-column:1/-1;grid-row:3;background:none;padding-top:4px}
/* ----- sheets ----- */
#ov.dkmod{overflow:hidden}
.dks{position:absolute;inset:0;z-index:40;display:grid;place-items:center;padding:30px}
.dksb{position:absolute;inset:0;background:#05030ccc;opacity:0;transition:opacity .2s}.dks.on .dksb{opacity:1}.dks.out{pointer-events:none}.dks.out .dksb{opacity:0}
.dkp{position:relative;width:min(900px,100%);max-height:calc(100% - 20px);overflow:auto;padding:24px 26px 26px;border-radius:24px;background:#111026f8;border:1px solid #4a3e8a;box-shadow:0 30px 80px #000;text-align:left;opacity:0;transform:translateY(12px) scale(.985);transition:opacity .2s,transform .2s cubic-bezier(.2,.8,.2,1)}
.dks.on .dkp{opacity:1;transform:none}.dks.out .dkp{opacity:0;transform:translateY(8px)}
.dkph{display:flex;align-items:center;gap:14px;margin-bottom:16px}.dkph h3{margin:0;flex:1;font:800 30px var(--ui);color:#fff8e8}
.dkx{all:unset;cursor:pointer;display:flex;align-items:center;gap:6px;padding:10px 16px;border-radius:12px;font:700 15px var(--ui);color:#e8e0ff;background:#1f1850;border:1px solid #4a3e8a;transition:background .15s}.dkx:hover{background:#2c2266}.dkx svg{width:18px;height:18px}.dkx:focus-visible{outline:3px solid #ffd45a;outline-offset:2px}
.dkbk{padding-left:10px}
.dkmg{display:grid;grid-template-columns:1fr 1fr;gap:14px}.dkmg1{grid-template-columns:1fr 1fr}
.dkm{all:unset;box-sizing:border-box;position:relative;cursor:pointer;min-height:112px;display:flex;align-items:center;gap:16px;padding:16px 46px 16px 16px;border-radius:18px;overflow:hidden;isolation:isolate;border:1.5px solid color-mix(in srgb,var(--c) 55%,transparent);transition:transform .15s,border-color .15s,box-shadow .15s}
.dkm::before{content:'';position:absolute;inset:0;z-index:-2;background:var(--img,none) center/cover,linear-gradient(135deg,color-mix(in srgb,var(--c) 30%,#120c2e),#0e0a24)}
.dkm::after{content:'';position:absolute;inset:0;z-index:-1;background:linear-gradient(90deg,#0b0718f2 30%,#0b0718b0 70%,#0b071880)}
.dkm:hover{transform:translateY(-2px);border-color:var(--c);box-shadow:0 10px 24px #000a,0 0 18px color-mix(in srgb,var(--c) 35%,transparent)}.dkm:focus-visible{outline:3px solid #ffd45a;outline-offset:2px}
.dkm:disabled{cursor:not-allowed;filter:grayscale(.7) brightness(.7)}.dkm:disabled:hover{transform:none;box-shadow:none}
.dkmi{flex:none;width:62px;height:62px;display:grid;place-items:center}.dkmi svg{width:58px;height:58px}.dkemo{font-size:46px;line-height:1}
.dkmt{display:flex;flex-direction:column;gap:3px}.dkm .dkmt b{font:800 21px var(--ui);color:#fff8e8}.dkm .dkmt small{font:500 14.5px/1.3 var(--ui);color:#c4badf}
.dkm .dkchv{top:50%;bottom:auto;transform:translateY(-50%)}.dkm:hover .dkchv{transform:translate(3px,-50%)}
.dkpr2{all:unset;box-sizing:border-box;position:relative;cursor:pointer;width:100%;display:flex;align-items:center;gap:12px;margin-top:14px;padding:12px 46px 12px 14px;border-radius:14px;background:#17123a;border:1px solid #3e3478;transition:background .15s}.dkpr2:hover{background:#211a50}.dkpr2 span{display:flex;flex-direction:column}.dkpr2 b{font:700 16px var(--ui);color:#fff8e8}.dkpr2 small{font:500 13.5px var(--ui);color:#c4badf}.dkpr2 .dkchv{top:50%;bottom:auto;transform:translateY(-50%)}.dkpr2:focus-visible{outline:3px solid #ffd45a;outline-offset:2px}
.dkpn{margin:-6px 0 14px;font:500 15px var(--ui);color:#c4badf}
#dkmo .dkp{width:min(760px,100%)}
.dkug{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.dku{all:unset;box-sizing:border-box;position:relative;cursor:pointer;display:flex;align-items:center;gap:14px;min-height:72px;padding:10px 14px;border-radius:16px;background:#17123a;border:1px solid #3e3478;transition:background .15s,border-color .15s}.dku:hover{background:#211a50;border-color:#6a58c0}.dku:focus-visible{outline:3px solid #ffd45a;outline-offset:2px}
.dkui{flex:none;width:46px;height:46px;display:grid;place-items:center;border-radius:13px;background:#0c0820;color:#e8e0ff}.dkui svg{width:38px;height:38px}
.dkut{display:flex;flex-direction:column}.dkut b{font:700 16.5px var(--ui);color:#fff8e8}.dkut small{font:500 13.5px var(--ui);color:#c4badf}.dku .bdg{top:50%;right:14px;transform:translateY(-50%)}
.dktg{display:flex;gap:10px;margin-top:14px}.dkt{all:unset;cursor:pointer;flex:1;display:flex;align-items:center;justify-content:space-between;min-height:52px;padding:0 18px;border-radius:14px;background:#0c0820;border:1px solid #3e3478;font:600 16px var(--ui);color:#e8e0ff}.dkt b{padding:4px 12px;border-radius:9px;font:800 13px var(--ui);color:#c4badf;background:#ffffff12}.dkt[aria-pressed="true"] b{color:#2a1406;background:#ffd45a}.dkt:focus-visible{outline:3px solid #ffd45a;outline-offset:2px}
.dkvig{display:none}
/* ----- narrow screens: campaign actions first, a small hero vignette below, compact dock ----- */
#ov.dknar .dkh{grid-template-columns:1fr;grid-template-rows:auto auto auto auto}
#ov.dknar .dkhd{padding:14px 14px 0;gap:10px;flex-wrap:wrap}#ov.dknar .dklogo h1{font-size:34px}#ov.dknar .dklogo .sbsw{width:22px;top:-12px;margin-left:-11px}
#ov.dknar .dkst0{padding:4px}#ov.dknar .dkav{width:44px;height:44px}#ov.dknar .dkmt b{font-size:15px}#ov.dknar .dkgold{padding:0 12px;height:36px}#ov.dknar .dkgold b,#ov.dknar .dktro b{font-size:16px}#ov.dknar .dktro{padding:6px 10px}
#ov.dknar .dkcp{grid-column:1;grid-row:2;margin:14px 14px 0;padding:22px 20px;max-width:none}
#ov.dknar .dkttl{font-size:40px}#ov.dknar .dkbt{flex-direction:column;gap:12px}#ov.dknar .dkgo,#ov.dknar .dkmode{flex:none;width:100%}
#ov.dknar .dksc{grid-template-columns:1fr}#ov.dknar .dkcard{min-height:120px}
#ov.dknar .dkstage{grid-column:1;grid-row:3;padding:14px 14px 0}#ov.dknar .dkvig{display:block;border-radius:20px;overflow:hidden;background:var(--img) center/cover,#120c2e;border:1px solid #3e3478;aspect-ratio:640/340}#ov.dknar .dkvig canvas{width:100%;height:100%;display:block}
#ov.dknar .dkhome .dkrow,#ov.dknar.dkhome .dkrow{grid-row:4}
#ov.dknar .dki{width:auto;flex:1;min-width:0;min-height:60px}#ov.dknar .dk{width:calc(100% - 20px);box-sizing:border-box}#ov.dknar .dki b{font-size:13px}
#ov.dknar .dkrow{padding-bottom:10px}#ov.dknar .dkc{position:static;order:-1;align-self:flex-end;margin-right:12px}#ov.dknar .dkcb{width:44px;height:44px}
#ov.dknar .dkmg,#ov.dknar .dkug{grid-template-columns:1fr}#ov.dknar .dk{max-width:760px}#ov.dknar.dkhome .dkrow{background:linear-gradient(180deg,#0000,#070412ee 45%)}
#ov.dknar.dkshort .dkh{grid-template-columns:minmax(0,1.15fr) minmax(0,.85fr);grid-template-rows:auto 1fr auto}#ov.dknar.dkshort .dkhd{grid-column:1/-1}
#ov.dknar.dkshort .dkcp{grid-column:1;grid-row:2;margin:10px 0 0 14px;padding:16px 18px}#ov.dknar.dkshort .dkttl{font-size:34px}#ov.dknar.dkshort .dkst1{margin:8px 0 6px;font-size:16px}#ov.dknar.dkshort .dkbt{flex-direction:row;margin:12px 0;padding-bottom:12px}#ov.dknar.dkshort .dkgo,#ov.dknar.dkshort .dkmode{flex:1;width:auto;min-height:52px;font-size:17px}
#ov.dknar.dkshort .dksc{grid-template-columns:1fr 1fr;gap:10px}#ov.dknar.dkshort .dkcard{min-height:96px;padding:10px 12px}#ov.dknar.dkshort .dkcl b{font-size:18px}#ov.dknar.dkshort .dkevl{display:none}
#ov.dknar.dkshort .dkstage{grid-column:2;grid-row:2;padding:10px 14px 0;align-self:center}#ov.dknar.dkshort .dkrow{grid-row:3}
#ov.dkshort .dk{max-width:620px}#ov.dkshort .dkc{position:absolute;order:0;right:10px;bottom:8px;margin:0}#ov.dkshort .dkcb{width:42px;height:42px}
#ov.dkshort .dki{min-height:46px;padding:3px 4px}#ov.dkshort .dki .dkic{height:28px}#ov.dkshort .dki .dkic svg{width:30px;height:30px}#ov.dkshort .dki b{font-size:12px}#ov.dkshort .dkrow{padding:6px 0 6px;gap:4px}#ov.dkshort .dkst{padding:6px 14px}
body.tm #ov.dkshort .dki{min-height:46px;padding:3px 4px}body.tm #ov.dkshort .dkst{min-height:36px;padding:6px 14px}#ov.dknar .dks{padding:12px}#ov.dknar .dkp{padding:18px 16px}
/* touch mode enlarges every button and heading game-wide; keep the dock's own sizes */
body.tm #ov.dkhome{padding:0!important}body.tm #ov .dklogo h1{font-size:46px}body.tm #ov.dknar .dklogo h1{font-size:34px}body.tm #ov .dkey{font-size:14px}body.tm #ov .dkpn{font-size:15px}
body.tm #ov .dkcb{min-height:0;padding:0}body.tm #ov .dkvs{min-height:44px;padding:8px 4px}body.tm #ov .dki{min-height:64px;padding:6px 4px 7px}body.tm #ov .dkst{min-height:44px;padding:9px 16px;box-sizing:border-box}
body.tm #ov .dkme{min-height:0;padding:4px 16px 4px 4px}body.tm #ov .dktro{min-height:0;padding:8px 14px}body.tm #ov .dklogo{min-height:0;padding:4px 6px}
body.tm #ov .dkgo,body.tm #ov .dkmode{min-height:62px;padding:0 20px}body.tm #ov .dkcard{padding:16px 18px}body.tm #ov .dkm{padding:16px 46px 16px 16px}body.tm #ov .dku{padding:10px 14px}
body.tm #ov .dkx{min-height:44px;padding:10px 16px}body.tm #ov .dkt{min-height:52px;padding:0 18px}body.tm #ov .dkpr2{min-height:0;padding:12px 46px 12px 14px}
@media (prefers-reduced-motion:reduce){.dkgo::after,.dkttl em{animation:none!important}.dksc .dkcard{animation:none!important}}
@media (prefers-reduced-motion:reduce){.dkcp,.dkst0,.dklogo,.dksub,.dkbar i,.dkcb.ring svg{animation:none!important}.dkp,.dksb,.dkcard::before{transition:none!important}}

/* ===== polish pass ===== */
/* dock: a violet pill glides from the last destination to the new one */
.dk{position:relative;isolation:isolate}
.dkpill{position:absolute;z-index:-1;top:7px;bottom:7px;--w:calc((100% - 14px - 20px)/6);left:calc(7px + var(--i)*(var(--w) + 4px));width:var(--w);border-radius:17px;background:linear-gradient(180deg,#8a66e0,#5b3ea8);box-shadow:0 0 0 1px #b49cff88,0 6px 18px #2a106099,inset 0 1px 0 #ffffff33;}.dkpill.go{transform:none!important;transition:transform .42s cubic-bezier(.3,1.25,.5,1)}
.dkpill::after{content:'';position:absolute;inset:0;border-radius:inherit;background:radial-gradient(ellipse at 50% 0%,#ffffff40,transparent 60%)}

.dki.on{background:transparent;box-shadow:none}
.dki.on .dkic{animation:dkbop .5s .12s cubic-bezier(.3,1.6,.5,1) both}@keyframes dkbop{40%{transform:translateY(-5px) scale(1.12)}}
.dki:active .dkic{transform:scale(.88);transition-duration:.06s}
.dki .bdg,.dkcb .bdg,.dkst .bdg{animation:dkpop .45s cubic-bezier(.3,1.8,.5,1) both}@keyframes dkpop{from{transform:scale(0)}}
.dku .bdg{animation:none}
/* corner tray labels */
.dkcb[data-tip]::after{content:attr(data-tip);position:absolute;bottom:calc(100% + 8px);right:0;padding:5px 10px;border-radius:8px;font:700 12.5px var(--ui);white-space:nowrap;color:#fff8e8;background:#0b0718f2;border:1px solid #4a3e8a;opacity:0;transform:translateY(4px);transition:opacity .15s,transform .15s;pointer-events:none}
.dkcb[data-tip]:hover::after,.dkcb[data-tip]:focus-visible::after{opacity:1;transform:none}
.dkc .bellp.open~.dkcb::after,.dkc:has(.bellp.open) .dkcb::after{opacity:0}
/* logo: a slow gleam crosses the wordmark */
.dklogo h1 span{background:linear-gradient(100deg,transparent 40%,#fffbe6 50%,transparent 60%) 160% 0/260% 100% no-repeat,linear-gradient(180deg,#fff6c8,#ffc83a 55%,#e07a10);-webkit-background-clip:text;background-clip:text;color:transparent;animation:none}
.dklogo h1 span+span{animation-delay:2.15s}
.dklogo:hover h1{filter:drop-shadow(0 3px 0 #3a1400) drop-shadow(0 0 22px #ffb02a99)}
/* status pill */
.dkav{position:relative;isolation:isolate;overflow:visible!important;box-shadow:0 0 14px #ffd45a55!important}.dkav canvas{border-radius:50%;position:relative;z-index:1;background:radial-gradient(circle at 40% 30%,#3a2e70,#120c2e)}.dkav::before{content:'';position:absolute;inset:-3px;z-index:-1;border-radius:50%;background:conic-gradient(from 0deg,#ffd45a,#fff6c8,#c8963a,#ffd45a,#fff6c8,#ffd45a)}.dkav::after{content:'';position:absolute;inset:-6px;border-radius:50%;box-shadow:0 0 14px #ffd45a;opacity:.3;animation:dkglo 3s ease-in-out infinite;pointer-events:none}@keyframes dkglo{50%{opacity:.75}}
@keyframes dkspin{to{transform:rotate(1turn)}}
.dkme:hover .dkchev{transform:translateX(3px)}.dkchev{transition:transform .15s}
.dkgold .coin{animation:dkcoin 5s ease-in-out infinite}@keyframes dkcoin{0%,86%,100%{transform:none}90%{transform:scaleX(.15)}94%{transform:scaleX(1)}}
.dkgold.up b{animation:dkgup .7s ease-out}.dkgold.dn b{animation:dkgdn .7s ease-out}@keyframes dkgup{30%{color:#9fffb0;text-shadow:0 0 12px #5aff8a}}@keyframes dkgdn{30%{color:#ffb0b8}}
.dktro:hover svg{animation:dkbop .5s cubic-bezier(.3,1.6,.5,1)}
/* campaign panel */
.dkcp{position:relative;overflow:hidden}
.dkcp::before{content:'';position:absolute;left:0;top:0;right:0;height:3px;background:linear-gradient(90deg,transparent,#ffd45a,transparent);opacity:.55}
.dkbl{margin:8px 0 0;font:500 16.5px/1.4 var(--ui);color:#c4badf;max-width:560px}
.dkbs svg{width:24px;height:24px;filter:drop-shadow(0 0 6px #c08aff88)}.dkbs b{color:#e8d8ff}
.dkst1{flex-wrap:wrap;row-gap:6px}
.dkbar{position:relative}
.dkbar::after{content:'';position:absolute;inset:0;background:repeating-linear-gradient(90deg,transparent 0 calc(100%/30 - 1px),#05030ecc calc(100%/30 - 1px) calc(100%/30));pointer-events:none}
.dkbar u{position:absolute;top:50%;left:var(--w);width:18px;height:18px;margin:-9px 0 0 -9px;border-radius:50%;background:radial-gradient(circle,#fff 0 18%,#ffe27a 30%,#ffc23a00 70%);animation:dkbar2 1s .3s cubic-bezier(.2,.8,.2,1) both,dkhead 2.2s 1.3s ease-in-out infinite;z-index:1}

.dkpr .dkbar{overflow:visible}.dkbar i{border-radius:7px}
@keyframes dkbar2{from{left:0}}@keyframes dkhead{50%{transform:scale(1.5);opacity:.75}}
/* shortcut cards */
.dkdaily::before{inset:-6%;animation:dkpan 18s ease-in-out infinite alternate}@keyframes dkpan{from{transform:translateX(-3%) scale(1.02)}to{transform:translateX(3%) scale(1.06)}}
.dkdaily:hover::before{animation-play-state:paused}
.dklive::before{display:none}.dkcv{position:absolute;inset:0;width:100%;height:100%;z-index:-2;object-fit:cover;transition:transform .5s cubic-bezier(.2,1,.3,1)}.dklive:hover .dkcv{transform:scale(1.05)}
.dkcard .dkshine{position:absolute;inset:0;pointer-events:none}
.dkcard::after{background:linear-gradient(180deg,#0000 15%,#07041288 50%,#070412f0)}
.dkcard{outline-offset:3px}
/* sheets: cards arrive one after another */
.dks.on .dkm,.dks.on .dku,.dks.on .dkpr2,.dks.on .dkt{animation:dkin .34s cubic-bezier(.2,.8,.2,1) both}
.dks.on .dkm:nth-child(2),.dks.on .dku:nth-child(2){animation-delay:.03s}.dks.on .dkm:nth-child(3),.dks.on .dku:nth-child(3){animation-delay:.06s}.dks.on .dkm:nth-child(4),.dks.on .dku:nth-child(4){animation-delay:.09s}
.dks.on .dkm:nth-child(5),.dks.on .dku:nth-child(5){animation-delay:.12s}.dks.on .dkm:nth-child(6),.dks.on .dku:nth-child(6){animation-delay:.15s}.dks.on .dku:nth-child(7){animation-delay:.18s}.dks.on .dku:nth-child(8){animation-delay:.21s}.dks.on .dkpr2,.dks.on .dkt{animation-delay:.2s}
.dkm .dkmi svg,.dku .dkui svg{transition:transform .2s cubic-bezier(.3,1.6,.5,1)}.dkm:hover .dkmi svg,.dku:hover .dkui svg{transform:scale(1.1) rotate(-4deg)}
.dkpv:not([hidden]){animation:dkfade .2s ease-out}
@media (prefers-reduced-motion:reduce){.dkpill{transform:none!important;transition:none!important}.dki.on .dkic,.bdg,.dklogo h1 span,.dkav::before,.dkgold .coin,.dkbar u,.dkdaily::before,.dks.on .dkm,.dks.on .dku,.dks.on .dkpr2,.dks.on .dkt,.dkpv{animation:none!important}}
`;document.head.appendChild(st)}
