/* ---------- main menu, shared menu chrome, crate hub ---------- */
const hsvg=(d,s)=>`<svg viewBox="0 0 24 24" width="${s||24}" height="${s||24}" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
const HIC={camp:'<path d="M5 21V4M5 4h11l-2.5 4L16 12H5"/>',endless:'<path d="M12 12c-2-3-4-4-6-4a4 4 0 000 8c2 0 4-1 6-4zm0 0c2 3 4 4 6 4a4 4 0 000-8c-2 0-4 1-6 4z"/>',rift:'<path d="M12 2l2.4 6.6L21 11l-6.6 2.4L12 20l-2.4-6.6L3 11l6.6-2.4z"/>',prac:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.3"/>',
 arm:'<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M12 7v10M8 11h8"/>',skill:'<circle cx="12" cy="5" r="2.2"/><circle cx="5" cy="18" r="2.2"/><circle cx="19" cy="18" r="2.2"/><path d="M12 7.2v4.8M12 12l-5.2 4.3M12 12l5.2 4.3"/>',
 shop:'<path d="M8.5 3h7l-2 3.5h-3zM9.5 6.5C6 9.5 5 12.5 5 15.5 5 19 8 21 12 21s7-2 7-5.5c0-3-1-6-4.5-9"/><path d="M12 11v6M10 13h3.2a1.2 1.2 0 010 2.4H10"/>',crate:'<path d="M4 11V8.5C4 6 7.6 4 12 4s8 2 8 4.5V11M3 11h18v9H3zM12 14v3.5"/>',
 cat:'<path d="M4 4.5h6.5A1.5 1.5 0 0112 6v14a1.5 1.5 0 00-1.5-1.5H4zM20 4.5h-6.5A1.5 1.5 0 0012 6v14a1.5 1.5 0 011.5-1.5H20z"/>',user:'<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
 cup:'<path d="M8 4h8v5a4 4 0 01-8 0zM8 6H4c0 3 1 5 4 5M16 6h4c0 3-1 5-4 5M12 13v4M8 21h8M10 17h4"/>',gear:'<circle cx="12" cy="12" r="3"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1"/>',
 help:'<circle cx="12" cy="12" r="9"/><path d="M9.3 9.4a2.7 2.7 0 115.2 1c0 1.8-2.5 2-2.5 4M12 17.4v.3"/>',lock:'<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/>',back:'<path d="M15 5l-7 7 7 7"/>'};
const hico=(k,s)=>hsvg(HIC[k],s);
const hmTile=(id,ic,lab,key,extra,cls)=>`<button class="tl${cls?' '+cls:''}" id="${id}"><span class="ti">${mico(ic,68)}</span><b>${lab}</b>${extra||''}<kbd>${key}</kbd></button>`;
const hmKeys={b:'sb_bb',c:'cp',e:'go',r:'rf',p:'pr',a:'sb_wp',s:'sb_sh',k:'sb_ut',x:'cx',l:'sb_bt',o:'sb_pf',t:'tr',h:'hp',d:'dr',g:'dcb',m:'gy',',':'sb_st'};
let HOME=false;
function homeKey(e){if(!HOME||e.ctrlKey||e.metaKey||e.altKey)return false;const ae=document.activeElement,t=ae&&ae.tagName;if(ae!==inp&&(t==='INPUT'||t==='TEXTAREA'||t==='SELECT'))return false;
 const k=e.key.length===1?e.key.toLowerCase():'';let id=hmKeys[k];if(e.key==='Enter'&&!e.repeat&&(ae===document.body||ae===inp))id='cp';const el=id&&$(id);if(el&&!el.disabled){e.preventDefault();el.click();return true}return false}
/* the hero stands on the hill at the left of the main menu */
const EMB=Array.from({length:34},(_,i)=>({x:rnd(i+1)*W,y:rnd(i+7)*H,s:.6+rnd(i+11)*1.8,v:10+rnd(i+13)*26,p:rnd(i+17)*6.3}));
function homeScene(t){const c=ctx;
 for(const e of EMB){const y=((e.y-t*e.v)%H+H)%H,x=e.x+Math.sin(t*.7+e.p)*24;c.globalAlpha=.25+.45*Math.abs(Math.sin(t*1.3+e.p));c.fillStyle='#ffb86a';c.beginPath();c.arc(x,y,e.s,0,TAU);c.fill()}c.globalAlpha=1;
}
function homeMon(){const L=LEVELS[Math.min(29,P.camp-1)],pool=['troll','warg','ent','bat','gob','shaman','mush'].filter(k=>MON[k]);return{camp:MON[L.b]?L.b:'troll',end:pool[(Date.now()/9e4|0)%pool.length]||'troll',rift:MON.prism?'prism':'wisp',prac:MON.dummy?'dummy':'gob'}}
function tileArt(cv,id){try{fitThumb(cv,id)}catch(e){}}
/* every sub-menu with a Back button also gets a top-left Back, so you never have to scroll to leave */
function menuChrome(){if(!S.back||ov.className.indexOf('hide')>=0||/\b(ut|casbg|clear|home|cmo)\b/.test(ov.className))return;const b=$('b');if((!b&&!ov.querySelector('.armory'))||ov.querySelector('.fback'))return;
 const f=document.createElement('button');f.className='fback';f.innerHTML=hico('back',20)+'<span>Back</span><kbd>Esc</kbd>';f.onclick=()=>{const bb=$('b');if(bb)bb.click();else if(S.back)S.back()};ov.prepend(f)}

/* settings are sorted into tabs so nothing needs scrolling */
const SETG={Display:['Display size','Resolution','Fullscreen','Touch controls','Menu background','Show FPS'],Sound:['Music','Music volume','Effects volume'],Effects:['Boss cutscenes','Screen shake','Flash effects'],Data:['Save and backups']};
function settingsTabs(){const box=ov.querySelector('.opts');if(!box)return;ov.classList.add('m','top');const opts=[...box.querySelectorAll(':scope>.opt')],names=Object.keys(SETG);let tab=settings.tab||'Display';
 const grp=o=>{const l=(o.querySelector('label')||{}).textContent||'';return names.find(n=>SETG[n].includes(l))||'Data'};
 const bar=document.createElement('div');bar.className='tabs ctabs';bar.innerHTML=names.map(n=>`<button class="tab" data-st="${n}">${n}</button>`).join('');box.before(bar);
 const apply=()=>{opts.forEach(o=>o.style.display=grp(o)===tab?'':'none');bar.querySelectorAll('.tab').forEach(b=>b.classList.toggle('on',b.dataset.st===tab))};
 bar.querySelectorAll('.tab').forEach(b=>b.onclick=()=>{tab=settings.tab=b.dataset.st;apply()});apply()}

/* results screens: Enter or Space takes the main action, Esc goes home (ignored for a moment so a last keystroke cannot trigger it) */
function overKey(e){if(ov.className.indexOf('hide')>=0||performance.now()-SHOWT<900||e.repeat)return false;
 if(e.key==='Escape'){const h=$('hm');if(h){e.preventDefault();h.click();return true}return false}
 if(e.key==='Enter'||e.key===' '){const b=[...ov.querySelectorAll('button:not(.sm):not(:disabled)')][0];if(b){e.preventDefault();b.click();return true}}return false}
