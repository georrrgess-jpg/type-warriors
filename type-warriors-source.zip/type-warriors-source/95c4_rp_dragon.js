/* ===== RUNESTONE TOWER DEFENSE 9.0: the Clockwork Dragon Roost, a sixth tower (95c4, art only; loads after 95c3) =====
   A brass clockwork dragon perches on a geared stone roost. Its parts are baked once and moved live: the far wing, tail, body,
   four neck plates, head and jaw are separate sprites, so the dragon breathes, beats its wings, turns to face its target, tracks
   it with its head and opens its jaw to breathe fire. The roost's gears turn, steam puffs from the vent, the furnace in its chest
   and the coals in its nest glow. Tiers 1-3 grow the dragon and the roost (tier 3 adds a crown of horns); tier 4 "Mythic" (violet
   stone, violet fire, a turning rune ring); tier 5 "Celestial" (marble, white-gold plates, a slowly turning sun disc behind it).
   Skins: 'base' (brass, orange fire) and 'azure' (the season champion's skin: blue steel, gold trim, blue fire).
   No shadowBlur, no ctx.filter; glows are the shared baked radial sprites stamped with 'lighter'.
   API (wrapping 95c/95c3; every other tower type passes straight through)
     RPTW.dragon, RPSKIN.dragon             'Dragon Roost'
     rpTowerDraw(g,'dragon',tier,skin,t,o)    o = {aim, face -1..1, charge 0..1 (breath), fire, over, crank 0..1, away (diving), ph, ghost}
                                         9.1: the battle passes its spring-smoothed pose instead of aim: la (head angle in the facing frame),
                                         jaw 0..1, neck -1..1 (inhale / thrust), flare 0..1 (wings), puff 0..1 (smoke after the jaw snaps shut)
     rpTowerBuild(g,'dragon',tier,skin,k,t,o) build (the roost rises, the dragon lands), upgrade (o.from) and ascension
     rpTowerTop, rpTowerWarm, rpTowerIcon     as for the other towers
     rpDragonMouth(tier,o)                  the mouth, relative to the pad centre {x,y}
     rpDragonBreath(g,x0,y0,x1,y1,t,k,tier,skin,lite)  the fire stream (k = strength 0..1)
     rpDragonFly(g,x,y,ang,tier,skin,t,flap)  the dragon in flight (the tier-5 wing dive), centred on its body */
RPTW.dragon={n:'Dragon Roost',role:'Fire breath',col:'#ffb04a'};
RPSKIN.dragon=['base','azure'];
const RPDL=[0,{h:40,s:.92},{h:46,s:1},{h:52,s:1.1,crown:1},{h:56,s:1.15,crown:1,rune:1},{h:58,s:1.2,crown:1,sun:1}];
const rpdT=t=>Math.max(1,Math.min(5,t|0||1)),rpdSk=s=>s==='azure'?'azure':'base';
const RPDP={
 base:{pl:'#e2a63a',plL:'#ffe592',plD:'#8e5a12',cu:'#c8682e',cuL:'#f6a86a',cuD:'#6a2a0e',st:'#4c4462',stL:'#857ca4',stD:'#221c30',mem:['#ffb060','#e0482a','#7a1414'],rib:'#ffd45a',eye:'#fff2a0',core:'#ff7a1a',fl:['#d6301a','#ff8a1e','#ffd54a','#fff6c8'],glow:'#ff7a2a',glow2:'#ffc860',horn:'#efe2c4',hornD:'#9a8466'},
 azure:{pl:'#8ab8ee',plL:'#eef8ff',plD:'#34528e',cu:'#2f6ad0',cuL:'#88c4ff',cuD:'#142a66',st:'#283258',stL:'#6676ae',stD:'#10142e',mem:['#7ae6ff','#2a78e8','#141e78'],rib:'#ffd45a',eye:'#e6fcff',core:'#2a9cff',fl:['#1e46d8','#2ea8ff','#8ce8ff','#f2feff'],glow:'#2a8cff',glow2:'#8adcff',horn:'#fff4d0',hornD:'#c8a860'}};
const RPDPC=new Map();
function rpdP(skin,tier){skin=rpdSk(skin);tier=rpdT(tier);const k=skin+tier;let P=RPDPC.get(k);if(P)return P;P=Object.assign({},RPDP[skin]);
 P.stone=tier>=5?RPSTONE.marble:tier>=4?RPSTONE.violet:RPSTONE.base;P.key=k;
 if(tier===4){if(skin==='azure')P.mem=['#a6b4ff','#4a52e8','#1a1270'];else{P.mem=['#ecb0ff','#a04ae8','#3a1478'];P.fl=['#6a18c8','#c048ff','#ff9af0','#fff2ff'];P.glow='#b04aff';P.glow2='#ff9af0';P.core='#d060ff'}}
 if(tier===5){if(skin==='azure'){P.pl='#d8ecff';P.plL='#ffffff';P.plD='#6a8ac8';P.mem=['#e8fbff','#8ae0ff','#2a6ad0'];P.fl=['#2a7cff','#7adcff','#dcf8ff','#ffffff'];P.glow='#5ab4ff';P.glow2='#e0f8ff'}
  else{P.pl='#fff0c0';P.plL='#ffffff';P.plD='#c08a2a';P.mem=['#fffbe8','#ffd27a','#c0761a'];P.fl=['#ff7a10','#ffc23a','#fff0a0','#ffffff'];P.glow='#ffb02a';P.glow2='#fff2b0';P.core='#ffd45a'}}
 RPDPC.set(k,P);return P}
const rpdPlate=(g,x0,x1,P)=>rpHG(g,x0,x1,P.plL,P.pl,P.plD);
function rpdRivets(g,pts,P){for(const [x,y] of pts){g.beginPath();g.arc(x,y,1.5,0,TAU);g.fillStyle=P.plD;g.fill();g.fillStyle='rgba(255,255,255,.75)';g.beginPath();g.arc(x-.4,y-.5,.6,0,TAU);g.fill()}}

/* ---------- the roost (pad, stone column, bands, pipe, nest of coals, pips) ---------- */
function rpdRoostArt(g,tier,P){const L=RPDL[tier],h=L.h,S=P.stone,rb=30,rt=26;RPPADT=tier;try{rpPadArt(g)}finally{RPPADT=0}
 rpTube(g,0,8,36,34,12,S.l,S.m,S.d);rpCap(g,0,-4,34,S.top,S.topD);
 rpTube(g,0,-4,rb,rt,h-4,S.l,S.m,S.d);
 /* stone courses */
 g.save();rpSide(g,0,-4,rb,rt,h-4);g.clip();g.strokeStyle=rpA(S.k,.45);g.lineWidth=1.6;
 for(let y=-14,i=0;y>-h+6;y-=11,i++){const r=rb+(rt-rb)*((-4-y)/(h-4));g.beginPath();g.ellipse(0,y,r,r*RPSQ,0,0,Math.PI);g.stroke();
  for(let j=-2;j<=2;j++){const a=(j+(i%2?.5:0))*.55,x=Math.sin(a)*r;g.beginPath();g.moveTo(x,y+Math.cos(a)*r*RPSQ);g.lineTo(x,y+Math.cos(a)*r*RPSQ+10);g.stroke()}}
 g.restore();
 /* brass bands */
 const band=(y,r,hh)=>{rpTube(g,0,y,r,r,hh,P.plL,P.pl,P.plD,2.2);g.beginPath();g.ellipse(0,y-hh,r,r*RPSQ,0,0,Math.PI);g.lineWidth=1.2;g.strokeStyle='rgba(255,255,255,.55)';g.stroke();
  rpdRivets(g,[-.7,-.25,.25,.7].map(a=>[Math.sin(a)*r,y-hh/2+Math.cos(a)*r*RPSQ]),P)};
 band(-2,rb+1.5,6);band(-h+12,rt+2,7);
 /* the gear recess in the front */
 const gy=-h*.5+2;g.beginPath();g.arc(0,gy,16,0,TAU);g.fillStyle=S.k;g.fill();rpOut(g,2.4);g.beginPath();g.arc(0,gy,16,0,TAU);g.lineWidth=3;g.strokeStyle=P.plD;g.stroke();g.lineWidth=1.2;g.strokeStyle=P.plL;g.beginPath();g.arc(0,gy,17.4,Math.PI*1.1,Math.PI*1.7);g.stroke();
 /* the copper pipe and its vent */
 g.lineCap='round';const pipe=w=>{g.beginPath();g.moveTo(24,-6);g.lineTo(27,-h+16);g.quadraticCurveTo(28,-h+6,36,-h+4);g.lineWidth=w;g.stroke()};g.strokeStyle=RPTO;pipe(9);g.strokeStyle=P.cu;pipe(6);g.strokeStyle=P.cuL;g.lineWidth=1.6;g.beginPath();g.moveTo(23.6,-8);g.lineTo(26.4,-h+16);g.stroke();
 g.beginPath();g.roundRect(34,-h-2,8,11,2);g.fillStyle=rpHG(g,34,42,P.cuL,P.cu,P.cuD);g.fill();rpOut(g,1.8);
 for(const y of[-12,-h*.5]){g.beginPath();g.roundRect(22,y-3,9,6,2);g.fillStyle=P.pl;g.fill();rpOut(g,1.4)}
 /* the nest: a brass dish of coals on top */
 const ny=-h;rpCap(g,0,ny+3,rt+5,P.plL,P.plD,2.6);g.beginPath();g.ellipse(0,ny+1,rt+1,(rt+1)*RPSQ,0,0,TAU);g.fillStyle='#2a0e08';g.fill();
 for(let i=0;i<16;i++){const a=rpR(i*7.3)*TAU,d=rpR(i*3.1+2)*(rt-3);g.beginPath();g.arc(Math.cos(a)*d,ny+1+Math.sin(a)*d*RPSQ,2.2+rpR(i)*2,0,TAU);g.fillStyle=i%3?P.fl[1]:P.fl[2];g.fill()}
 for(let i=0;i<7;i++){const a=Math.PI*(.05+i*.15);g.beginPath();g.moveTo(Math.cos(a)*(rt+4),ny+3+Math.sin(a)*(rt+4)*RPSQ);g.lineTo(Math.cos(a)*(rt+9),ny-6+Math.sin(a)*(rt+6)*RPSQ);g.lineWidth=4;g.strokeStyle=RPTO;g.stroke();g.lineWidth=2.2;g.strokeStyle=P.pl;g.stroke()}
 if(L.rune||L.sun){g.save();rpSide(g,0,-4,rb,rt,h-4);g.clip();g.strokeStyle=L.sun?'#e8b84a':'#d8a8ff';g.lineWidth=2;for(let i=0;i<3;i++){const x=(i-1)*15,y=-h*.5+2+(i===1?-22:-6);g.beginPath();g.moveTo(x-4,y+5);g.lineTo(x,y-5);g.lineTo(x+4,y+5);g.moveTo(x-3,y+1);g.lineTo(x+3,y+1);g.stroke()}g.restore()}
 g.save();g.translate(0,RPPIPY);rpPipArt(g,tier);g.restore()}
const rpdRoostS=(tier,P)=>{const h=RPDL[tier].h;return rpSpr('dg|r|'+P.key,-66,-(h+26),132,h+70,g=>rpdRoostArt(g,tier,P))};
function rpdGearArt(g,r,n,P){g.beginPath();for(let i=0;i<n*2;i++){const a=i/(n*2)*TAU,rr=i%2?r:r+r*.24,a2=a+TAU/(n*4);g.lineTo(Math.cos(a)*rr,Math.sin(a)*rr);g.lineTo(Math.cos(a2)*rr,Math.sin(a2)*rr)}g.closePath();
 g.fillStyle=rpHG(g,-r,r,P.plL,P.pl,P.plD);g.fill();rpOut(g,Math.max(1.4,r*.13));g.beginPath();g.arc(0,0,r*.62,0,TAU);g.fillStyle=P.plD;g.fill();
 for(let i=0;i<4;i++){g.save();g.rotate(i*Math.PI/2);g.fillStyle=P.pl;g.fillRect(-r*.1,-r*.62,r*.2,r*1.24);g.restore()}
 g.beginPath();g.arc(0,0,r*.26,0,TAU);g.fillStyle=P.cu;g.fill();rpOut(g,1.2);g.fillStyle='rgba(255,255,255,.7)';g.beginPath();g.arc(-r*.08,-r*.08,r*.08,0,TAU);g.fill()}
const rpdGearS=(r,n,P)=>rpSpr('dg|g|'+r+'|'+P.key,-r*1.3,-r*1.3,r*2.6,r*2.6,g=>rpdGearArt(g,r,n,P));

/* ---------- the dragon's parts (drawn facing +x; the perch top is (0,0)) ---------- */
function rpdBodyArt(g,P,L,far){const dk=far?.35:0,C=c=>dk?rpMix(c,'#12081f',dk):c;
 /* torso */
 const body=()=>{g.beginPath();g.moveTo(-26,-14);g.bezierCurveTo(-30,-34,-8,-46,10,-40);g.bezierCurveTo(24,-35,26,-18,17,-8);g.bezierCurveTo(8,1,-18,3,-26,-14);g.closePath()};
 body();const q=g.createLinearGradient(-20,-44,14,0);q.addColorStop(0,P.plL);q.addColorStop(.4,P.pl);q.addColorStop(1,P.plD);g.fillStyle=q;g.fill();
 g.save();body();g.clip();
 /* belly scutes */
 for(let i=0;i<6;i++){const u=i/5;g.beginPath();g.ellipse(18-u*20,-30+u*26,9,4,-.9,0,TAU);g.fillStyle=i%2?P.cuL:P.cu;g.fill();g.lineWidth=1.3;g.strokeStyle=P.cuD;g.stroke()}
 /* plate seams */
 g.strokeStyle=rpA('#12081f',.45);g.lineWidth=1.4;for(const [a,b,c,d] of[[-24,-24,-2,-42],[-20,-10,4,-38],[-12,-2,10,-34]]){g.beginPath();g.moveTo(a,b);g.quadraticCurveTo((a+c)/2-6,(b+d)/2-6,c,d);g.stroke()}
 g.fillStyle='rgba(255,255,255,.4)';g.beginPath();g.ellipse(-8,-34,10,3,-.4,0,TAU);g.fill();g.restore();
 body();rpOut(g,3);
 /* furnace grill in the chest */
 g.save();g.translate(9,-21);g.rotate(-.35);g.beginPath();g.roundRect(-7,-7,14,14,4);g.fillStyle='#2a0804';g.fill();rpOut(g,2);g.strokeStyle=P.pl;g.lineWidth=2;for(const x of[-3,0,3]){g.beginPath();g.moveTo(x,-6);g.lineTo(x,6);g.stroke()}g.beginPath();g.roundRect(-7,-7,14,14,4);rpOut(g,1.6);g.restore();
 /* back spikes */
 for(let i=0;i<5;i++){const u=i/4,x=-24+u*26,y=-26-u*14-Math.sin(u*Math.PI)*4,a=-1.9+u*.5;g.beginPath();g.moveTo(x-3.6,y+1.5);g.lineTo(x+Math.cos(a)*9,y+Math.sin(a)*9);g.lineTo(x+3.6,y-1);g.closePath();g.fillStyle=P.cu;g.fill();rpOut(g,1.6)}
 rpdRivets(g,[[-18,-26],[-10,-34],[0,-38],[-16,-12],[-6,-20]],P);
 /* near hind leg and fore leg, claws on the rim */
 g.beginPath();g.moveTo(-24,-16);g.quadraticCurveTo(-20,-28,-8,-24);g.quadraticCurveTo(-2,-14,-6,-5);g.lineTo(-18,-5);g.quadraticCurveTo(-25,-8,-24,-16);g.closePath();g.fillStyle=rpHG(g,-25,-3,P.plL,P.pl,P.plD);g.fill();rpOut(g,2.4);
 g.strokeStyle=rpA(P.plD,.8);g.lineWidth=1.3;g.beginPath();g.moveTo(-20,-18);g.quadraticCurveTo(-14,-22,-9,-19);g.stroke();
 g.beginPath();g.moveTo(-14,-6);g.lineTo(-10,1);g.lineTo(-4,1);g.lineTo(-6,-6);g.closePath();g.fillStyle=P.plD;g.fill();rpOut(g,2);
 g.beginPath();g.moveTo(9,-12);g.quadraticCurveTo(15,-8,13,0);g.lineTo(18,1);g.lineTo(16,-12);g.closePath();g.fillStyle=P.pl;g.fill();rpOut(g,2);
 for(const x of[-11,-7,-3,12,15,18]){g.beginPath();g.moveTo(x-1.4,0);g.lineTo(x+.6,4.5);g.lineTo(x+1.6,0);g.closePath();g.fillStyle=P.horn;g.fill();rpOut(g,1.1)}}
function rpdTailArt(g,P){/* root at (0,0) = (-22,-12) on the body; curls down around the perch */
 const pts=[[0,0],[-9,8],[-13,24],[-10,40],[-3,52],[6,58]];g.lineCap='round';g.lineJoin='round';
 const path=()=>{g.beginPath();g.moveTo(pts[0][0],pts[0][1]);for(let i=1;i<pts.length-1;i++){const m=[(pts[i][0]+pts[i+1][0])/2,(pts[i][1]+pts[i+1][1])/2];g.quadraticCurveTo(pts[i][0],pts[i][1],m[0],m[1])}g.lineTo(pts[pts.length-1][0],pts[pts.length-1][1])};
 g.strokeStyle=RPTO;g.lineWidth=13;path();g.stroke();g.strokeStyle=P.pl;g.lineWidth=8.4;path();g.stroke();g.strokeStyle=P.plL;g.lineWidth=2.4;g.globalAlpha=.6;g.save();g.translate(-1.5,-1.5);path();g.stroke();g.restore();g.globalAlpha=1;
 for(let i=1;i<5;i++){const [x,y]=pts[i];g.beginPath();g.arc(x,y,3.4,0,TAU);g.fillStyle=P.cu;g.fill();rpOut(g,1.3)}
 /* the spade tip */
 g.save();g.translate(6,58);g.rotate(.2);g.beginPath();g.moveTo(-2,0);g.lineTo(8,-8);g.lineTo(16,0);g.lineTo(8,8);g.closePath();g.fillStyle=rpHG(g,-2,16,P.cuL,P.cu,P.cuD);g.fill();rpOut(g,2);g.restore()}
function rpdWingArt(g,P,far,L){/* pivot (0,0) = the shoulder; the wing is raised up and back */
 const dk=far?.38:0,C=c=>dk?rpMix(c,'#12081f',dk):c,E=[-14,-22],W=[-8,-48],F=[[8,-62],[-20,-70],[-44,-56],[-52,-30]],R=[-26,-4];
 g.beginPath();g.moveTo(0,0);g.lineTo(E[0],E[1]);g.lineTo(W[0],W[1]);g.lineTo(F[0][0],F[0][1]);
 for(let i=0;i<F.length-1;i++){const a=F[i],b=F[i+1],m=[(a[0]+b[0])/2,(a[1]+b[1])/2];g.quadraticCurveTo(m[0]+(W[0]-m[0])*.32,m[1]+(W[1]-m[1])*.32,b[0],b[1])}
 {const a=F[F.length-1],m=[(a[0]+R[0])/2,(a[1]+R[1])/2];g.quadraticCurveTo(m[0]+10,m[1]-2,R[0],R[1])}g.closePath();
 const q=g.createLinearGradient(0,-72,-20,0);q.addColorStop(0,C(P.mem[0]));q.addColorStop(.5,C(P.mem[1]));q.addColorStop(1,C(P.mem[2]));g.fillStyle=q;g.fill();
 g.save();g.clip();g.globalAlpha=.25;g.strokeStyle='#ffffff';g.lineWidth=1;for(let i=0;i<4;i++){g.beginPath();g.moveTo(W[0],W[1]);g.lineTo(F[i][0]*.7+R[0]*.3,F[i][1]*.7+R[1]*.3+8);g.stroke()}g.globalAlpha=1;g.restore();
 rpOut(g,2.6);
 /* ribs (brass rods) and the arm, with a gear at the elbow */
 g.lineCap='round';for(const f of F){g.beginPath();g.moveTo(W[0],W[1]);g.lineTo(f[0],f[1]);g.lineWidth=4.6;g.strokeStyle=RPTO;g.stroke();g.lineWidth=2.4;g.strokeStyle=C(P.rib);g.stroke();
  g.beginPath();g.arc(f[0],f[1],2.2,0,TAU);g.fillStyle=C(P.pl);g.fill();rpOut(g,1.2)}
 g.beginPath();g.moveTo(0,0);g.lineTo(E[0],E[1]);g.lineTo(W[0],W[1]);g.lineWidth=8.6;g.strokeStyle=RPTO;g.stroke();g.lineWidth=5.4;g.strokeStyle=C(P.pl);g.stroke();g.lineWidth=1.6;g.strokeStyle=C(P.plL);g.beginPath();g.moveTo(-1.5,-2);g.lineTo(E[0]-1.5,E[1]);g.stroke();
 g.save();g.translate(E[0],E[1]);rpdGearArt(g,5,7,far?Object.assign({},P,{pl:C(P.pl),plL:C(P.plL),plD:C(P.plD)}):P);g.restore();
 g.beginPath();g.arc(W[0],W[1],3.6,0,TAU);g.fillStyle=C(P.cu);g.fill();rpOut(g,1.6);
 g.beginPath();g.moveTo(W[0]+1,W[1]-2);g.lineTo(W[0]+6,W[1]-11);g.lineTo(W[0]+5,W[1]-1);g.closePath();g.fillStyle=P.horn;g.fill();rpOut(g,1.2)}
function rpdNeckArt(g,P){g.beginPath();g.ellipse(0,0,7,6.4,0,0,TAU);g.fillStyle=rpHG(g,-7,7,P.plL,P.pl,P.plD);g.fill();rpOut(g,2.2);
 g.beginPath();g.ellipse(2.5,1.5,4,3.6,0,0,TAU);g.fillStyle=P.cu;g.fill();g.lineWidth=1;g.strokeStyle=P.cuD;g.stroke();
 g.beginPath();g.moveTo(-3,-5.6);g.lineTo(-1,-10);g.lineTo(2,-5.8);g.closePath();g.fillStyle=P.cu;g.fill();rpOut(g,1.2)}
function rpdHeadArt(g,P,L){/* pivot (0,0) = the back of the skull; the snout points +x */
 /* horns */
 const horn=(x,y,a,len,w)=>{g.beginPath();g.moveTo(x-w,y);g.quadraticCurveTo(x+Math.cos(a)*len*.6-w,y+Math.sin(a)*len*.4,x+Math.cos(a)*len,y+Math.sin(a)*len);g.quadraticCurveTo(x+Math.cos(a)*len*.5+w,y+Math.sin(a)*len*.6+w,x+w,y+1);g.closePath();
  g.fillStyle=rpVG(g,y+Math.sin(a)*len,y,P.horn,P.hornD);g.fill();rpOut(g,1.8)};
 horn(0,-9,-2.75,22,3.6);if(L.crown){horn(4,-11,-2.45,16,2.6);horn(-3,-4,-3.0,14,2.4)}
 /* skull */
 const sk=()=>{g.beginPath();g.moveTo(-6,-6);g.quadraticCurveTo(-4,-14,8,-14);g.quadraticCurveTo(18,-13,24,-8);g.lineTo(33,-5);g.quadraticCurveTo(37,-2,34,2);g.lineTo(8,4);g.lineTo(0,6);g.quadraticCurveTo(-7,3,-6,-6);g.closePath()};
 sk();const q=g.createLinearGradient(0,-14,4,6);q.addColorStop(0,P.plL);q.addColorStop(.5,P.pl);q.addColorStop(1,P.plD);g.fillStyle=q;g.fill();
 g.save();sk();g.clip();g.fillStyle=rpA(P.plD,.55);g.beginPath();g.ellipse(4,4,12,6,0,0,TAU);g.fill();g.fillStyle='rgba(255,255,255,.45)';g.beginPath();g.ellipse(12,-11,9,2.2,-.15,0,TAU);g.fill();
 g.strokeStyle=rpA('#12081f',.5);g.lineWidth=1.3;g.beginPath();g.moveTo(18,-12);g.quadraticCurveTo(16,-2,20,4);g.stroke();g.restore();
 /* teeth (upper) */
 for(let x=11;x<=31;x+=5){const f=x===26?1.6:1;g.beginPath();g.moveTo(x-1.8*f,3);g.lineTo(x,3+4.2*f*f);g.lineTo(x+1.8*f,3);g.closePath();g.fillStyle='#fffaf0';g.fill();g.lineWidth=1;g.strokeStyle=RPTO;g.stroke()}
 sk();rpOut(g,2.6);
 /* brow plate, eye socket, nostril, rivets */
 g.beginPath();g.moveTo(4,-11);g.quadraticCurveTo(12,-16,19,-10);g.lineTo(16,-8);g.quadraticCurveTo(10,-11,5,-8);g.closePath();g.fillStyle=P.cu;g.fill();rpOut(g,1.6);
 g.beginPath();g.ellipse(12,-5,4.6,3.4,-.1,0,TAU);g.fillStyle='#1a0a06';g.fill();rpOut(g,1.4);
 g.beginPath();g.ellipse(31,-3,1.6,1.1,0,0,TAU);g.fillStyle='#1a0a06';g.fill();
 rpdRivets(g,[[0,-2],[3,-9],[22,-6]],P)}
function rpdJawArt(g,P){/* pivot (0,0) = the jaw hinge */
 const jw=()=>{g.beginPath();g.moveTo(-2,-2);g.lineTo(28,-1);g.quadraticCurveTo(30,3,26,5);g.lineTo(6,7);g.quadraticCurveTo(-2,6,-2,-2);g.closePath()};
 for(let x=10;x<=26;x+=4){const f=x===22?1.5:1;g.beginPath();g.moveTo(x-1.6*f,-1);g.lineTo(x,-1-4.4*f*f);g.lineTo(x+1.6*f,-1);g.closePath();g.fillStyle='#fffaf0';g.fill();g.lineWidth=1;g.strokeStyle=RPTO;g.stroke()}
 jw();g.fillStyle=rpHG(g,-2,30,P.pl,P.plD,P.plD);g.fill();g.save();jw();g.clip();g.fillStyle=P.cu;g.fillRect(-4,3,36,6);g.fillStyle='rgba(255,255,255,.35)';g.fillRect(2,-1,22,1.6);g.restore();jw();rpOut(g,2.4);rpdRivets(g,[[6,2],[14,2.5],[21,2.6]],P)}
/* the open mouth: throat and tongue (drawn live between the jaws, so the inside always matches the jaw angle) */
function rpdMaw(g,P,ja,glow){const c=Math.cos(ja),s=Math.sin(ja),lx=1+c*27+s*1,ly=5+s*27-c*1;/* lower front in head frame */
 g.beginPath();g.moveTo(1,4);g.lineTo(31,2.5);g.quadraticCurveTo((31+lx)/2+3,(2.5+ly)/2,lx,ly);g.closePath();
 g.fillStyle='#6a1210';g.fill();g.beginPath();g.moveTo(1,4.5);g.lineTo(14,3.6);g.lineTo(1+Math.cos(ja)*13,5+Math.sin(ja)*13);g.closePath();g.fillStyle='#1a0204';g.fill();
 if(glow>.02){g.globalCompositeOperation='lighter';rpGlow(g,9,4+(ly-5)*.35,13,6+ly*.3,P.glow2,glow*.9);g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}
 /* tongue along the lower jaw */
 g.save();g.translate(1,5);g.rotate(ja);g.beginPath();g.moveTo(1,-1.5);g.quadraticCurveTo(10,-5.5,19,-3.2);g.quadraticCurveTo(21,-2,18.5,-1.2);g.quadraticCurveTo(10,-2.6,1,-.6);g.closePath();g.fillStyle='#d8485a';g.fill();g.lineWidth=1.2;g.strokeStyle='#5a0e14';g.stroke();g.restore()}
/* the hinge: a small gear at the joint and a piston from the skull to the jaw */
function rpdHinge(g,P,ja){const c=Math.cos(ja),s=Math.sin(ja),jx=1+c*9-s*3,jy=5+s*9+c*3;
 g.lineCap='round';g.beginPath();g.moveTo(-5,-2);g.lineTo(jx,jy);g.lineWidth=4.4;g.strokeStyle=RPTO;g.stroke();g.lineWidth=2.4;g.strokeStyle=P.plL;g.stroke();
 const mx=-5+(jx+5)*.45,my=-2+(jy+2)*.45;g.beginPath();g.moveTo(-5,-2);g.lineTo(mx,my);g.lineWidth=6.4;g.strokeStyle=RPTO;g.stroke();g.lineWidth=4.2;g.strokeStyle=P.cu;g.stroke();
 g.save();g.translate(1,5);g.rotate(ja*2.4);rpPut(g,rpdGearS(4.6,6,P));g.restore()}
function rpdSunArt(g,P){for(let i=0;i<16;i++){g.save();g.rotate(i/16*TAU);g.beginPath();g.moveTo(-4,-30);g.lineTo(0,-(i%2?50:60));g.lineTo(4,-30);g.closePath();g.fillStyle=rpA(i%2?P.glow2:'#ffffff',.55);g.fill();g.restore()}
 g.beginPath();g.arc(0,0,30,0,TAU);g.lineWidth=4;g.strokeStyle=rpA(P.glow2,.8);g.stroke();g.lineWidth=1.4;g.strokeStyle='#ffffff';g.stroke()}
function rpdRuneArt(g,col){g.lineWidth=2;g.strokeStyle=col;g.beginPath();g.arc(0,0,40,0,TAU);g.stroke();g.beginPath();g.arc(0,0,33,0,TAU);g.stroke();
 for(let i=0;i<8;i++){const a=i/8*TAU;g.save();g.rotate(a);g.beginPath();g.moveTo(-3,-36.5);g.lineTo(0,-31);g.lineTo(3,-36.5);g.moveTo(0,-39);g.lineTo(0,-34);g.stroke();g.restore()}}
const rpdPart=(P,L,n,x0,y0,w,h,fn)=>rpSpr('dg|'+n+'|'+P.key,x0,y0,w,h,fn);
const rpdBodyS=(P,L)=>rpdPart(P,L,'bd',-36,-56,66,66,g=>rpdBodyArt(g,P,L));
const rpdTailS=P=>rpdPart(P,null,'tl',-24,-10,50,84,g=>rpdTailArt(g,P));
const rpdWingS=(P,far)=>rpdPart(P,null,far?'wf':'wn',-60,-80,76,90,g=>rpdWingArt(g,P,far));
const rpdNeckS=P=>rpdPart(P,null,'nk',-10,-13,20,23,g=>rpdNeckArt(g,P));
const rpdHeadS=(P,L)=>rpSpr('dg|hd|'+P.key+'|'+(L.crown?1:0),-30,-34,72,46,g=>rpdHeadArt(g,P,L));
const rpdJawS=P=>rpdPart(P,null,'jw',-6,-8,40,18,g=>rpdJawArt(g,P));
const rpdSunS=P=>rpdPart(P,null,'sun',-64,-64,128,128,g=>rpdSunArt(g,P));
const rpdRuneS=()=>rpSpr('dg|rune',-44,-44,88,88,g=>rpdRuneArt(g,'#d8a8ff'));

/* ---------- pose: where the neck, head and mouth are (dragon frame, facing +x) ---------- */
function rpdPose(tier,o,t){const ph=o.ph||0,ch=o.charge||0;
 let la;if(o.la!=null)la=o.la;else{const aim=o.aim==null?.35:o.aim;la=Math.atan2(Math.sin(aim),Math.abs(Math.cos(aim))||.001);if(!(ch>.02||o.fire>.02))la=la*.6+.18+Math.sin(t*1.3+ph)*.06}
 la=rpClamp(la,-.9,1.25);
 const jaw=rpClamp(o.jaw!=null?o.jaw:Math.min(1,ch*1.3+(o.fire||0)*.4),0,1.15),nk=rpClamp(o.neck||0,-1.4,1.6),bob=Math.sin(t*2.1+ph)*1.2*(1-Math.min(1,jaw)*.7);
 const N0=[10-nk*1.5,-36+bob],na=-1.2+la*.62,len=24+nk*4,H=[N0[0]+Math.cos(na)*len,N0[1]+Math.sin(na)*len];
 /* the upper jaw lifts a little as the lower one drops, so the gap (and the fire) opens straight along la */
 const r=la-jaw*.34,ja=jaw*.7,cr=Math.cos(r),sr=Math.sin(r),hx=H[0]+cr-sr*5,hy=H[1]+sr+cr*5;
 return{la,r,bob,N0,H,na,open:jaw,ja,hinge:[hx,hy],M:[hx+Math.cos(la)*29,hy+Math.sin(la)*29]}}
const rpdF=o=>o.face==null?(Math.cos(o.aim==null?0:o.aim)<0?-1:1):(Math.abs(o.face)<.12?(o.face<0?-.12:.12):o.face);
/* the mouth relative to the pad centre, with exactly the flip and scale the dragon is drawn with */
function rpDragonMouth(tier,o){tier=rpdT(tier);o=o||{};const L=RPDL[tier],p=rpdPose(tier,o,o.t||0),f=rpdF(o);return{x:f*L.s*p.M[0],y:-L.h+2+L.s*p.M[1]}}
/* the dragon on its perch; g is at the perch top, scaled and flipped */
function rpdDragon(g,tier,P,L,t,o,flyK,pass){const p=rpdPose(tier,o,t),ph=o.ph||0,ch=o.charge||0,fl=flyK||0;
 if(pass!==1){g.save();g.translate(-22,-10+p.bob*.5);g.rotate(fl?1.25+Math.sin(t*6+ph)*.12:Math.sin(t*1.1+ph)*.05);rpPut(g,rpdTailS(P));g.restore();if(pass===0)return}
 const flr=o.flare!=null?o.flare:ch,flap=fl?Math.sin(t*14+ph)*.55:Math.sin(t*1.7+ph)*.07*(1-flr*.6)-flr*.26,sy=fl?1-.25*Math.max(0,Math.sin(t*14+ph)):1-.05*Math.sin(t*1.7+ph+1)+flr*.06;
 /* far wing */
 g.save();g.translate(-6,-38+p.bob);g.rotate(fl?flap*.8+.55:flap*.8-.1);g.scale(.92,sy);rpPut(g,rpdWingS(P,1));g.restore();
 const inh=Math.max(0,-(o.neck||0));g.save();g.translate(-ch*2,p.bob);if(inh>0){g.translate(-4,-20);g.scale(1+inh*.04,1+inh*.05);g.translate(4,20)}rpPut(g,rpdBodyS(P,L));
 /* chest furnace */
 g.globalCompositeOperation='lighter';const fu=.45+.25*Math.sin(t*3+ph)+ch*.6+inh*.5;rpGlow(g,9,-21,10+ch*6,10+ch*6,P.core,fu);rpGlow(g,9,-21,4,4,'#ffffff',fu*.5);g.globalCompositeOperation='source-over';g.globalAlpha=RPGA;g.restore();
 /* neck plates from the body to the head */
 const N0=[p.N0[0]-ch*2,p.N0[1]],H=p.H,C=[N0[0]+4,(N0[1]+H[1])/2-2],ns=rpdNeckS(P);
 for(let i=0;i<4;i++){const u=.08+i*.27,a=1-u,x=a*a*N0[0]+2*a*u*C[0]+u*u*H[0],y=a*a*N0[1]+2*a*u*C[1]+u*u*H[1],k=1.08-u*.25;g.save();g.translate(x,y);g.scale(k,k);rpPut(g,ns);g.restore()}
 /* head and jaw */
 g.save();g.translate(H[0],H[1]);g.rotate(p.r);
 if(p.ja>.03)rpdMaw(g,P,p.ja,Math.min(1,ch*1.2+inh*.6));
 g.save();g.translate(1,5);g.rotate(p.ja);rpPut(g,rpdJawS(P));g.restore();
 rpPut(g,rpdHeadS(P,L));rpdHinge(g,P,p.ja);
 g.globalCompositeOperation='lighter';const ey=.75+.25*Math.sin(t*2.6+ph)+ch*.4+inh*.3;rpGlow(g,12.5,-5,8,6,P.core,ey*.9);rpGlow(g,12.5,-5,3.4,2.4,P.eye,Math.min(1,ey+.2));
 if(ch<.05&&!fl&&!(o.puff>0)){const u=((t*.6+ph)%1);if(u<.4){const v=u/.4;rpGlow(g,34+v*6,-4-v*10,3+v*5,3+v*5,P.glow2,(1-v)*.5)}}
 g.globalCompositeOperation='source-over';g.globalAlpha=RPGA;
 /* a blink every few seconds (never mid-breath) */
 if(ch<.05&&((t*.23+ph*.37)%1)<.03){g.beginPath();g.ellipse(12,-5,5.2,3.9,-.1,0,TAU);g.fillStyle=P.pl;g.fill();rpOut(g,1.4);g.beginPath();g.moveTo(7.5,-4.6);g.quadraticCurveTo(12,-3,16.5,-5);g.lineWidth=1.2;g.strokeStyle=P.plD;g.stroke()}
 /* smoke from the nostril after the jaw snaps shut */
 if(o.puff>.02){for(let k=0;k<3;k++){const v=Math.min(1,(1-o.puff)*1.4+k*.18),r2=3+v*9;g.globalAlpha=RPGA*o.puff*(1-v*.5)*.55;g.drawImage(rpGlowC('#5a5068'),33+v*10-r2,-4-v*14-r2,r2*2,r2*2)}g.globalAlpha=RPGA}
 g.restore();
 /* near wing */
 g.save();g.translate(-12,-35+p.bob);g.rotate(fl?flap+.35:flap-.04);g.scale(1,sy);rpPut(g,rpdWingS(P,0));g.restore()}
function rpdDraw(g,tier,skin,t,o){const L=RPDL[tier],P=rpdP(skin,tier),ph=o.ph||0,ch=o.charge||0,ga=o.ghost?.5:1;
 const f=o.face==null?(Math.cos(o.aim==null?0:o.aim)<0?-1:1):(Math.abs(o.face)<.12?(o.face<0?-.12:.12):o.face);
 g.save();RPGA=ga;g.globalAlpha=ga;g.lineJoin='round';g.lineCap='round';
 if(o.sel){g.globalCompositeOperation='lighter';g.lineWidth=7;g.strokeStyle='rgba(255,201,74,.25)';g.beginPath();g.ellipse(0,15,64,26,0,0,TAU);g.stroke();g.globalCompositeOperation='source-over'}
 if(L.rune){g.save();g.translate(0,14);g.scale(1,RPSQ);g.rotate(t*.3+ph);g.globalAlpha=ga*(.55+.2*Math.sin(t*2));g.globalCompositeOperation='lighter';rpPut(g,rpdRuneS());g.restore();g.globalCompositeOperation='source-over';g.globalAlpha=ga}
 if(L.sun&&!o.away){g.save();g.translate(f*8*L.s,-L.h-48*L.s);g.rotate(t*.25+ph);const k=L.s*(1+.04*Math.sin(t*2));g.scale(k,k);g.globalAlpha=ga*.85;g.globalCompositeOperation='lighter';rpPut(g,rpdSunS(P));g.restore();g.globalCompositeOperation='source-over';g.globalAlpha=ga}
 if(!o.away){g.save();g.translate(0,-L.h+2);g.scale(f*L.s,L.s);rpdDragon(g,tier,P,L,t,o,0,0);g.restore()}
 rpPut(g,rpdRoostS(tier,P));
 /* nest coals and the gears */
 g.globalCompositeOperation='lighter';rpGlow(g,0,-L.h+1,30,13,P.glow,(.35+.15*Math.sin(t*2.4+ph)+ch*.3)*ga);g.globalCompositeOperation='source-over';g.globalAlpha=ga;
 const spin=o.away?5:o.crank?3+o.crank*8:.9+ch*2.4,gy=-L.h*.5+2;
 g.save();g.translate(0,gy);g.rotate(t*spin+ph);rpPut(g,rpdGearS(13,10,P));g.restore();
 g.save();g.translate(-22,-L.h*.72);g.rotate(-t*spin*1.6+ph);rpPut(g,rpdGearS(7,7,P));g.restore();
 g.save();g.translate(-19,-14);g.rotate(-t*spin*1.3+ph+1);rpPut(g,rpdGearS(6,6,P));g.restore();
 /* steam from the vent */
 if(!RPFX.lite)for(let i=0;i<2;i++){const u=((t*.5+i*.5+ph)%1),r=4+u*12;g.globalAlpha=ga*(1-u)*.38;g.drawImage(rpGlowC('#f2ecff'),38-r+u*8,-L.h-6-u*34-r,r*2,r*2)}g.globalAlpha=ga;
 if(!o.away){g.save();g.translate(0,-L.h+2);g.scale(f*L.s,L.s);rpdDragon(g,tier,P,L,t,o,0,1);g.restore()}
 if(o.crank>0){g.globalCompositeOperation='lighter';rpGlow(g,0,gy,30,30,'#ffd45a',o.crank*.8);g.globalCompositeOperation='source-over'}
 g.restore();RPGA=1;g.globalAlpha=1}
/* the dragon in flight (centred on its body), for the tier-5 wing dive */
function rpDragonFly(g,x,y,ang,tier,skin,t,flap){tier=rpdT(tier);const L=RPDL[tier],P=rpdP(skin,tier),f=Math.cos(ang)<0?-1:1,a=f>0?ang:Math.PI-ang;
 g.save();g.translate(x,y);g.scale(f*L.s*1.05,L.s*1.05);g.rotate(rpClamp(a,-.7,.7)*(1));g.translate(4,22);RPGA=1;g.globalAlpha=1;
 rpdDragon(g,tier,P,L,t,{aim:.2,charge:.6,ph:0},flap==null?1:flap);g.restore();RPGA=1}

/* ---------- the fire stream ---------- */
/* the stream is a gentle arc; the battle's hit test (95i) samples exactly this curve */
const rpdCtl=(x0,y0,x1,y1)=>[(x0+x1)/2,(y0+y1)/2-Math.hypot(x1-x0,y1-y0)*.05];
function rpDragonBreath(g,x0,y0,x1,y1,t,k,tier,skin,lite){if(k<=.01)return;const P=rpdP(skin,tier),dx=x1-x0,dy=y1-y0,d=Math.hypot(dx,dy)||1,nx=-dy/d,ny=dx/d,[cx,cy]=rpdCtl(x0,y0,x1,y1);
 const at=u=>{const a=1-u;return[a*a*x0+2*a*u*cx+u*u*x1,a*a*y0+2*a*u*cy+u*u*y1]};
 g.save();{/* a coloured underlayer, so the fire keeps its colour on snow and other bright ground */const m=lite?3:5;for(let i=0;i<m;i++){const u=(i+.5)/m,[x,y]=at(u),w=(10+44*u)*(.7+.3*k);g.globalAlpha=.32*k;g.drawImage(rpGlowC(P.fl[1]),x-w,y-w*.8,w*2,w*1.6)}g.globalAlpha=1}
 g.globalCompositeOperation='lighter';const n=Math.max(7,Math.min(lite?8:11,Math.round(d/(lite?26:18)))),sh=(t*7)%1,K=.7+.3*k;
 const line=(w,c,a,u0,u1)=>{g.globalAlpha=a;g.lineWidth=w;g.strokeStyle=c;g.beginPath();for(let i=0;i<=8;i++){const [x,y]=at(u0+(u1-u0)*i/8);i?g.lineTo(x,y):g.moveTo(x,y)}g.stroke()};g.lineCap='round';
 line(22*K,rpA(P.fl[0],1),.22*k,.1,.9);line(11*K,rpA(P.fl[1],1),.34*k,.04,.85);line(4*K,rpA(P.fl[3],1),.6*k,.02,.6);
 for(let i=0;i<n;i++){const u=(i+sh)/n,[x,y]=at(u),w=(10+44*u*u+12*u)*K,j=Math.sin(t*19+i*2.3)*w*.16,fx=x+nx*j,fy=y+ny*j-u*u*4;
  rpGlow(g,fx,fy,w*1.5,w*1.2,P.fl[0],.6*k*(1-u*.3));rpGlow(g,fx,fy,w,w*.8,P.fl[1],.75*k);rpGlow(g,fx,fy,w*.55,w*.45,P.fl[2],.75*k*(1-u*.45));if(u<.7)rpGlow(g,x,y,w*.32,w*.26,P.fl[3],.9*k*(1-u))}
 const [ex,ey]=at(1);rpGlow(g,ex,ey+6,70*K,30*K,P.glow,.55*k);rpGlow(g,ex,ey,30*K,16*K,'#ffffff',.3*k);
 if(!lite)for(let i=0;i<4;i++){const v=((t*1.6+i/4)%1),[x,y]=at(.3+v*.7);rpGlow(g,x+Math.sin(i*2.3+t*5)*18,y-v*26-Math.cos(i)*8,3,3,P.fl[3],(1-v)*k)}
 g.globalCompositeOperation='source-over';
 /* cartoon flames where it lands, like the Ember Blazer's */
 const nf=lite?2:3;for(let i=0;i<nf;i++){const a=(i-(nf-1)/2),x=ex+a*26*K+nx*a*6,y=ey+8+Math.abs(a)*4;g.globalAlpha=.92*k;rpFlame(g,x,y,(.62-Math.abs(a)*.14)*K,t,i*.37,P.fl,'dgb'+P.key)}
 if(!lite){g.globalAlpha=.2*k;for(let i=0;i<3;i++){const v=((t*.9+i/3)%1),r=10+v*26;g.drawImage(rpGlowC('#2a1a2a'),ex-r+(i-1)*16,ey-30-r-v*40,r*2,r*2)}}
 g.restore();g.globalAlpha=1;g.globalCompositeOperation='source-over'}

/* ---------- build, upgrade and ascension ---------- */
function rpdBuild(g,tier,skin,k,t,o){const from=o.from>=1&&o.from<tier?o.from|0:0,L=RPDL[tier],P=rpdP(skin,tier),S=(a,b)=>rpSeg(k,a,b),ph=o.ph||0;
 g.save();RPGA=1;g.globalAlpha=1;g.lineJoin='round';g.lineCap='round';
 if(!from){/* the roost rises out of the ground, then the dragon swoops down and lands */
  rpPut(g,rpPadS());const r=S(0,.42),e=rpEB(r),Lh=L.h+30;
  if(r>0){g.save();g.beginPath();g.rect(-80,-Lh-40,160,Lh+40+10);g.clip();g.translate(0,(1-Math.min(1,e))*(Lh+20));g.scale(1,.7+.3*Math.min(1.2,e));
   const oo={aim:o.aim,ph,away:1};rpdDraw(g,tier,skin,t,oo);g.restore();
   if(r<1)rpDust(g,0,10,r,1.4)}
  const d=S(.4,.82);if(d>0){const e2=rpEO(d),y=-L.h+2-(1-e2)*120,x=(1-e2)*-60;g.save();g.translate(x,y);const sq=d>.9?1+(1-d)*.6:1;g.scale(L.s*(o.face<0?-1:1),L.s/sq*(d>.9?1:1));
   rpdDragon(g,tier,P,L,t,{aim:.3,ph,charge:0},d<.92?1:0);g.restore()}
  const f=S(.82,1);if(f>0&&f<1){g.globalCompositeOperation='lighter';rpGlow(g,0,-L.h-30,60*f,40*f,P.glow2,(1-f));const m=rpDragonMouth(tier,{aim:-.9,ph});rpGlow(g,m.x,m.y-20*f,18+20*f,24+30*f,P.fl[2],(1-f)*.9);g.globalCompositeOperation='source-over'}
  if(d>=1&&f>0&&f<1){g.save();const m=rpDragonMouth(tier,{aim:-.9,ph,charge:1-f});g.translate(m.x,m.y);g.globalAlpha=1-f;rpFlame(g,0,0,.6+.4*f,t,0,P.fl,'dgb'+P.key);g.restore()}}
 else{/* upgrade: the dragon rears, glows white-hot, and roars a plume of fire; ascension adds a pillar of light */
  const asc=tier>=4,sw=S(.38,.5),cur=sw<1?from:tier,ch=S(0,.4)*(1-S(.5,.7)),ro=S(.55,.95);
  if(asc){const pl=S(.05,.4)*(1-S(.7,1));g.globalCompositeOperation='lighter';rpGlow(g,0,-120,40+30*pl,160,tier>=5?'#fff6d8':'#c890ff',pl*.8);g.globalCompositeOperation='source-over'}
  const sc=sw>0&&sw<1?1+.12*Math.sin(sw*Math.PI):1;g.save();g.scale(1/sc,sc);rpdDraw(g,cur,skin,t,{aim:ro>0&&ro<1?-1.1:o.aim,ph,charge:Math.max(ch,ro>0&&ro<1?Math.sin(ro*Math.PI):0),face:o.face});g.restore();
  if(ch>0||sw>0&&sw<1){g.globalCompositeOperation='lighter';rpGlow(g,0,-L.h-20,50+30*sw,60+30*sw,'#ffffff',Math.max(ch*.5,sw<1?Math.sin(sw*Math.PI):0));g.globalCompositeOperation='source-over'}
  if(ro>0&&ro<1){const m=rpDragonMouth(tier,{aim:-1.1,ph,charge:1,face:o.face});g.save();g.translate(m.x,m.y);g.globalAlpha=Math.sin(ro*Math.PI);rpFlame(g,0,4,.8+.5*ro,t,0,P.fl,'dgb'+P.key);g.restore()}}
 g.restore();RPGA=1;g.globalAlpha=1}

/* ---------- warm, icon and the wrappers ---------- */
function rpdWarm(tier,skin){const P=rpdP(skin,tier),L=RPDL[tier];rpPadS();rpdRoostS(tier,P);rpdGearS(13,10,P);rpdGearS(7,7,P);rpdGearS(6,6,P);rpdBodyS(P,L);rpdTailS(P);rpdWingS(P,0);rpdWingS(P,1);rpdNeckS(P);rpdHeadS(P,L);rpdJawS(P);rpdGearS(4.6,6,P);
 if(L.sun)rpdSunS(P);if(L.rune)rpdRuneS()}
{const f0=rpTowerDraw;rpTowerDraw=function(g,type,tier,skin,t,o){if(type!=='dragon')return f0.apply(this,arguments);rpdDraw(g,rpdT(tier),rpdSk(skin),t||0,o||{})}}
{const f0=rpTowerBuild;rpTowerBuild=function(g,type,tier,skin,k,t,o){if(type!=='dragon')return f0.apply(this,arguments);o=o||{};t=t||0;tier=rpdT(tier);skin=rpdSk(skin);if(!(k<1)){rpdDraw(g,tier,skin,t,o);return}rpdBuild(g,tier,skin,Math.max(0,k||0),t,o)}}
{const f0=rpTowerTop;rpTowerTop=function(type,tier){if(type!=='dragon')return f0.apply(this,arguments);const L=RPDL[rpdT(tier)];return Math.round(L.h+58*L.s)}}
{const f0=rpTowerWarm;rpTowerWarm=function(type,tier,skin){if(type!=='dragon')return f0.apply(this,arguments);rpdWarm(rpdT(tier),rpdSk(skin))}}
{const f0=rpTowerIcon;rpTowerIcon=function(type,tier,skin,size){if(type!=='dragon')return f0.apply(this,arguments);tier=rpdT(tier);skin=rpdSk(skin);size=Math.max(16,size|0||96);const key='dg|ic|'+tier+'|'+skin+'|'+size;let s=RPSPR.get(key);if(s)return s.c;
 const c=document.createElement('canvas');c.width=c.height=size;const L=RPDL[tier],top=L.h+84*L.s,h=top+44,k=Math.min(size*.95/h,size*.95/150),g=c.getContext('2d');g.translate(size/2+4*k,size/2+(top-44)/2*k);g.scale(k,k);
 try{rpdDraw(g,tier,skin,.4,{aim:-.25,ph:.3,face:1})}catch(e){console.error(e)}RPSPR.set(key,{c});return c}}
