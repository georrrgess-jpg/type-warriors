/* ===== 9.7 THE CROOKED CUE: the hub around a pool table (96zg) =====
   The owner's concept "1B". The seven regulars sit in portrait medallions around an illustrated pool table under a swinging lamp:
   beaten ones wear a green check, the next one has a gold frame, a NEXT tag and a little bob, locked ones are dark with a lock,
   "???" and their difficulty stars. Clicking a medallion (or 1-7, up/down, N) picks who to play; the picked one grows.
   Right: the spotlight card (stage, their line, race / pays / record, the house rule with details behind (i), scouting, stake chips,
   win pays, the signature cue). Bottom: the stake bar (chips, total return, net profit, Play • N coins = #pzrackem, Practice = #pzprac).
   Slick Shade, when he is in, leans on the far end of the table. The bar regulars and Granny sit along the bottom.
   Overrides pzHub, pzHubOpp, pzHubSel, pzHubStake and pzHubTour (later declarations win; 96zd still adds the emblem).
   Room, table, lamp, portraits and stage are baked once (per felt / ball set); per frame only the stage regular and the bar corners draw. */
const PZ97={bg:null,bgKey:'',tb:null,tbKey:'',lamp:null,tw:[],port:{},stage:{},ball:{}};
/* medallion centres on the 1600 x 900 stage (diameter 120), Slick Shade's spot at the table's far end, the table centre */
const PZ97_SLOT=[[438,262],[636,224],[926,262],[418,490],[605,552],[767,552],[930,552]],PZ97_SHADE=[990,390],PZ97_TX=722;
/* the name on a medallion's plate, and the short house rule on the spotlight card (the full text sits behind the (i)) */
const PZ97_PLATE={gloop:'Gloop',moldwick:'Granny Moldwick',grizzle:'Grizzle',vesper:'Vesper Nightwing',barnacle:"Cap'n Barnacle",hootsworth:'Hootsworth',mortimer:'Mortimer',shade:'Slick Shade'};
const PZ97_HOUSE={gloop:'None. Plain 8-ball.',moldwick:'Spore cloud (for looks).',grizzle:'Winner breaks.',vesper:'Dim table edges.',barnacle:'Bank the 8 off a cushion.',hootsworth:'Short aim guide only.',mortimer:'25-second shot clock.',shade:'He hustles rack one.'};
/* head-and-shoulders framing per regular: [top, bottom, x shift] in monster units (feet at 0, up is negative) */
const PZ97_BUST={gloop:[-280,6,0],moldwick:[-392,-120,0],grizzle:[-382,-108,0],vesper:[-352,-104,0],barnacle:[-372,-40,0],hootsworth:[-372,-128,0],mortimer:[-372,-132,0],shade:[-322,-70,0]};
function pz97Bust(g,id,S,ex,t){const b=PZ97_BUST[id]||[-300,-80,0],s=S*.94/(b[1]-b[0]);g.save();g.translate(S/2+b[2]*s,S*.06-b[0]*s);g.scale(s,s);g.lineJoin='round';g.lineCap='round';
 try{pzMon[id](g,t||1,ex||pzCastEx(),{breath:0,tilt:0,bob:0,hop:0})}catch(e){}g.restore()}
/* a ball from the player's set as a canvas (pzbIcon gives a data URL; the table bake needs pixels now) */
function pz97Ball(n,px){const key=PZ_BS.set+n+'_'+px;if(PZ97.ball[key])return PZ97.ball[key];const D=PZ_BS.D;if(!D)return null;
 const M=n===0?pzbRot(pzbI(),1,0,0,.35):pzbRot(pzbRot(pzbI(),0,1,0,.28),1,0,0,-.22);pzbPaint(15,n,M);const c=pzCv(px*2,px*2),x=c.getContext('2d');x.imageSmoothingQuality='high';x.drawImage(PZ_BS.atlas,15*D,0,D,D,0,0,px*2,px*2);PZ_BS.dirtyAll=1;return PZ97.ball[key]=c}
/* ---------- the room: the bottle shelf and string lights, a plank wall with two sconces, a floor in perspective, a rug, side tables ---------- */
function pz97Sconce(g,x,y){g.save();g.fillStyle=pzLin(g,x-10,0,x+10,0,[[0,'#3a1c0a'],[.5,'#7a4420'],[1,'#3a1c0a']]);pzRR(g,x-9,y+14,18,36,6);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2.5;g.stroke();
 g.strokeStyle='#b8862a';g.lineWidth=4;g.beginPath();g.moveTo(x,y+30);g.quadraticCurveTo(x+14,y+22,x,y+10);g.stroke();
 g.fillStyle='#d8a83a';g.beginPath();g.ellipse(x,y+10,11,4,0,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2;g.stroke();
 pzGlow(g,x,y-6,150,'rgba(255,170,90,1)',.42);pzGlow(g,x,y-6,56,'rgba(255,220,150,1)',.7);
 g.fillStyle='rgba(255,236,190,.28)';g.beginPath();g.moveTo(x-8,y+8);g.quadraticCurveTo(x-14,y-8,x-8,y-24);g.lineTo(x+8,y-24);g.quadraticCurveTo(x+14,y-8,x+8,y+8);g.closePath();g.fill();g.strokeStyle='rgba(18,8,31,.8)';g.lineWidth=2;g.stroke();
 g.fillStyle='#ffb04a';g.beginPath();g.moveTo(x,y-16);g.quadraticCurveTo(x+7,y-4,x,y+3);g.quadraticCurveTo(x-7,y-4,x,y-16);g.fill();g.fillStyle='#fff4c8';g.beginPath();g.ellipse(x,y-3,2.6,5,0,0,TAU);g.fill();g.restore()}
function pz97Plant(g,x,y,k){g.save();g.translate(x,y);g.scale(k,k);g.lineJoin='round';
 const leaf=(a,l,w,c)=>{g.save();g.rotate(a);g.fillStyle=c;g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(w,-l*.5,0,-l);g.quadraticCurveTo(-w,-l*.5,0,0);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2.6;g.stroke();g.strokeStyle='rgba(10,40,20,.55)';g.lineWidth=1.6;g.beginPath();g.moveTo(0,-4);g.lineTo(0,-l*.85);g.stroke();g.restore()};
 for(const [a,l,w,c] of[[-1.15,92,22,'#1f6a3a'],[1.1,96,22,'#1f6a3a'],[-.7,118,26,'#2a8a4a'],[.65,112,26,'#2a8a4a'],[-.25,128,26,'#3aa85a'],[.2,122,25,'#36a052'],[-.45,84,20,'#48bc68'],[.45,80,20,'#48bc68']])leaf(a,l,w,c);
 g.fillStyle=pzLin(g,-34,0,34,0,[[0,'#7a3410'],[.45,'#c0622a'],[1,'#6a2a0c']]);g.beginPath();g.moveTo(-34,-6);g.lineTo(34,-6);g.lineTo(26,48);g.lineTo(-26,48);g.closePath();g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();
 g.fillStyle='#d8743a';pzRR(g,-38,-12,76,14,5);g.fill();g.stroke();g.fillStyle='rgba(255,220,170,.3)';g.fillRect(-32,-10,60,2);g.restore()}
function pz97Candle(g,x,y,h){g.fillStyle='#f2e6c8';pzRR(g,x-5,y-h,10,h,3);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2;g.stroke();g.fillStyle='rgba(18,8,31,.25)';g.fillRect(x+1,y-h+2,3,h-4);
 pzGlow(g,x,y-h-8,70,'rgba(255,170,90,1)',.4);g.fillStyle='#ffb04a';g.beginPath();g.moveTo(x,y-h-15);g.quadraticCurveTo(x+5,y-h-6,x,y-h-1);g.quadraticCurveTo(x-5,y-h-6,x,y-h-15);g.fill();g.fillStyle='#fff4c8';g.beginPath();g.ellipse(x,y-h-5,1.6,3,0,0,TAU);g.fill()}
function pz97Mug(g,x,y,k){k=k||1;g.save();g.translate(x,y);g.scale(k,k);g.lineWidth=2.4;g.strokeStyle=PZ_O;g.fillStyle='#e8c070';g.beginPath();g.ellipse(15,-16,9,10,0,-1.4,1.4);g.lineWidth=5;g.strokeStyle=PZ_O;g.stroke();g.lineWidth=2.6;g.strokeStyle='#c89040';g.stroke();
 g.fillStyle=pzLin(g,-13,0,13,0,[[0,'#c8902a'],[.45,'#ffd77a'],[1,'#a8701a']]);pzRR(g,-13,-34,26,34,5);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2.4;g.stroke();g.fillStyle='rgba(255,255,255,.35)';g.fillRect(-8,-28,3,22);
 g.fillStyle='#fff8ea';g.beginPath();g.ellipse(0,-34,15,6,0,0,TAU);g.fill();g.beginPath();g.arc(-7,-37,5,0,TAU);g.arc(4,-38,6,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2;g.beginPath();g.ellipse(0,-34,15,6,0,0,Math.PI);g.stroke();g.restore()}
function pz97Chair(g,x,y,k,flip){g.save();g.translate(x,y);g.scale(flip?-k:k,k);g.fillStyle='#2a1508';g.strokeStyle=PZ_O;g.lineWidth=3;
 for(const px of[-34,30]){pzRR(g,px,-118,9,140,4);g.fill();g.stroke()}for(const py of[-112,-84,-56]){pzRR(g,-36,py,76,10,4);g.fill();g.stroke()}g.fillStyle='rgba(255,180,110,.16)';g.fillRect(-32,-111,70,2);g.restore()}
function pz97Bg(){const Z=PZS(),key=Z.felt;if(PZ97.bg&&PZ97.bgKey===key)return PZ97.bg;const c=pzCv(1600,900),g=c.getContext('2d');g.lineJoin='round';g.lineCap='round';
 g.drawImage(pzHubBake(),0,0);
 const fy=326;
 /* back wall, warmer and lit from the sconces */
 for(let i=0;i<40;i++){const x=i*40;g.fillStyle=pzMix('#3e2214','#56301a',pzNoise(i+3));g.fillRect(x,140,38,fy-140);g.fillStyle='rgba(0,0,0,.42)';g.fillRect(x+38,140,2,fy-140);g.fillStyle='rgba(255,210,150,.06)';g.fillRect(x+2,140,2,fy-140);
  for(let k=0;k<3;k++){g.strokeStyle='rgba(20,8,4,.25)';g.lineWidth=1.4;g.beginPath();const yy=150+pzNoise(i*7+k)*(fy-170);g.moveTo(x+6,yy);g.quadraticCurveTo(x+18,yy+24,x+32,yy+8);g.stroke()}}
 g.fillStyle=pzLin(g,0,140,0,210,[[0,'rgba(8,4,12,.75)'],[1,'rgba(8,4,12,0)']]);g.fillRect(0,140,1600,70);
 /* a framed chalk scoreboard and a wall cue rack peek out between the medallions */
 {g.save();g.translate(780,252);g.fillStyle='#4a2410';pzRR(g,-34,-30,68,58,6);g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();g.fillStyle='#1d3326';g.fillRect(-27,-23,54,44);g.strokeStyle='rgba(240,240,220,.55)';g.lineWidth=1.6;
  for(let r=0;r<3;r++){g.beginPath();g.moveTo(-22,-14+r*13);g.lineTo(-22+12+pzNoise(r)*20,-14+r*13);g.stroke();for(let k=0;k<4;k++){g.beginPath();g.moveTo(4+k*4,-19+r*13);g.lineTo(4+k*4,-9+r*13);g.stroke()}}g.restore()}
 /* skirting and floor */
 g.fillStyle=pzLin(g,0,fy-22,0,fy,[[0,'#6a3a1a'],[1,'#3a1e0c']]);g.fillRect(0,fy-22,1600,22);g.fillStyle='#8a5228';g.fillRect(0,fy-24,1600,4);g.fillStyle='rgba(0,0,0,.5)';g.fillRect(0,fy-2,1600,3);
 {const vx=PZ97_TX,vy=-340,t=(fy-vy)/(900-vy);g.fillStyle='#2e1a0c';g.fillRect(0,fy,1600,900-fy);
  for(let i=-24;i<=24;i++){const b0=vx+i*86,b1=vx+(i+1)*86,t0=vx+(b0-vx)*t,t1=vx+(b1-vx)*t;g.fillStyle=pzMix('#3a2210','#4c2c16',pzNoise(i+71));g.beginPath();g.moveTo(t0,fy);g.lineTo(t1,fy);g.lineTo(b1,900);g.lineTo(b0,900);g.closePath();g.fill();
   g.strokeStyle='rgba(0,0,0,.5)';g.lineWidth=2;g.beginPath();g.moveTo(t0,fy);g.lineTo(b0,900);g.stroke();g.strokeStyle='rgba(255,200,140,.06)';g.lineWidth=2;g.beginPath();g.moveTo(t0+2,fy);g.lineTo(b0+3,900);g.stroke();
   for(let k=0;k<3;k++){const q=.12+pzNoise(i*5+k)*.85,yy=fy+(900-fy)*q*q,u=(yy-vy)/(900-vy);g.strokeStyle='rgba(0,0,0,.45)';g.lineWidth=2;g.beginPath();g.moveTo(vx+(b0-vx)*u,yy);g.lineTo(vx+(b1-vx)*u,yy);g.stroke()}}
  g.fillStyle=pzLin(g,0,fy,0,fy+120,[[0,'rgba(6,2,10,.7)'],[1,'rgba(6,2,10,0)']]);g.fillRect(0,fy,1600,120)}
 /* the rug under the table */
 {const cx=PZ97_TX,cy=466;g.save();g.fillStyle='rgba(6,2,12,.5)';g.beginPath();g.ellipse(cx,cy+8,282,92,0,0,TAU);g.fill();
  g.fillStyle='#3a1e52';g.beginPath();g.ellipse(cx,cy,274,86,0,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();
  g.fillStyle='#24123a';g.beginPath();g.ellipse(cx,cy,252,76,0,0,TAU);g.fill();g.strokeStyle='#5a3478';g.lineWidth=3;g.setLineDash([10,7]);g.beginPath();g.ellipse(cx,cy,240,71,0,0,TAU);g.stroke();g.setLineDash([]);
  g.strokeStyle='rgba(200,150,255,.18)';g.lineWidth=2;g.beginPath();g.ellipse(cx,cy,214,60,0,0,TAU);g.stroke();
  g.strokeStyle='#c8a070';g.lineWidth=2;for(const sd of[-1,1])for(let k=-5;k<=5;k++){const yy=cy+k*9,xx=cx+sd*274*Math.sqrt(Math.max(0,1-(k*9/86)**2));g.beginPath();g.moveTo(xx,yy);g.lineTo(xx+sd*9,yy+1);g.stroke()}
  g.restore()}
 /* warm light: the lamp pool on the rug, the sconces on the wall */
 pzGlow(g,PZ97_TX,420,330,'rgba(255,200,120,1)',.22);
 pz97Sconce(g,338,206);pz97Sconce(g,1012,198);
 /* a side table with a candle under the rail, Granny's table, and chairs in the shadows along the bottom */
 {g.fillStyle='#2a1406';g.fillRect(256,628,10,60);g.fillStyle='#5a2e12';g.beginPath();g.ellipse(262,628,48,12,0,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();g.fillStyle='rgba(255,200,140,.18)';g.beginPath();g.ellipse(262,626,40,7,0,Math.PI,TAU);g.fill();pz97Candle(g,262,626,20)}
 pz97Plant(g,58,690,.95);pz97Chair(g,470,904,1,0);pz97Chair(g,640,910,1,1);pz97Chair(g,880,904,1,0);pz97Chair(g,1040,912,.9,1);
 for(const [x,y] of[[560,862],[960,866]]){g.fillStyle='#3a1c0a';g.beginPath();g.ellipse(x,y,92,20,0,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();g.fillStyle='rgba(255,190,120,.16)';g.beginPath();g.ellipse(x,y-2,80,12,0,Math.PI,TAU);g.fill();g.fillStyle='#2a1406';g.fillRect(x-7,y+16,14,40);pz97Candle(g,x+30,y-2,18)}
 pz97Mug(g,530,860,.8);
 /* the string lights: warm bulbs hang off the wire */
 PZ97.bulbs=[];for(let x=18;x<1600;x+=46){const seg=Math.floor(x/200),u=(x-seg*200)/200,y=30*(1-u)*(1-u)+2*(1-u)*u*70+30*u*u;PZ97.bulbs.push([x,y+9])}
 for(const [x,y] of PZ97.bulbs){pzGlow(g,x,y+4,34,'rgba(255,200,110,1)',.55);g.fillStyle='#2a1a0a';g.fillRect(x-3,y-6,6,6);g.fillStyle='#ffe9a8';g.beginPath();g.ellipse(x,y+4,5,7,0,0,TAU);g.fill();g.strokeStyle='rgba(18,8,31,.7)';g.lineWidth=1.5;g.stroke();g.fillStyle='#fff';g.beginPath();g.arc(x-1.5,y+2,1.6,0,TAU);g.fill()}
 /* soften the edges */
 pzGlow(g,338,206,260,'rgba(255,150,70,1)',.22);pzGlow(g,1012,198,260,'rgba(255,150,70,1)',.22);pzGlow(g,262,610,150,'rgba(255,160,80,1)',.25);for(const x of[560,960])pzGlow(g,x+30,850,170,'rgba(255,160,80,1)',.22);
 const v=g.createRadialGradient(760,470,380,760,470,1050);v.addColorStop(0,'rgba(0,0,0,0)');v.addColorStop(1,'rgba(6,2,12,.5)');g.fillStyle=v;g.fillRect(0,0,1600,900);
 PZ97.bgKey=key;return PZ97.bg=c}
/* two twinkle layers: a third of the bulbs each, their opacity pulses in CSS */
function pz97Twinkle(k){if(PZ97.tw[k])return PZ97.tw[k];pz97Bg();const c=pzCv(1600,100),g=c.getContext('2d');PZ97.bulbs.forEach(([x,y],i)=>{if(i%3!==k)return;pzGlow(g,x,y+4,40,'rgba(255,214,130,1)',.75);g.fillStyle='rgba(255,250,220,.9)';g.beginPath();g.ellipse(x,y+4,3.4,5,0,0,TAU);g.fill()});return PZ97.tw[k]=c}
/* ---------- the table in perspective (its own canvas so it can spring in): stage box x 450-994, y 320-556 ---------- */
function pz97Table(){const Z=PZS(),key=Z.felt+'|'+PZ_BS.set;if(PZ97.tb&&PZ97.tbKey===key)return PZ97.tb;
 const c=pzCv(1088,472),g=c.getContext('2d');g.scale(2,2);g.translate(-450,-320);g.lineJoin='round';g.lineCap='round';
 const F=PZ_FELT.find(f=>f.id===Z.felt)||PZ_FELT[0],cx=PZ97_TX,tr=(y0,y1,w0,w1)=>(u,v)=>[cx+(u-.5)*(w0+(w1-w0)*v),y0+(y1-y0)*v];
 const O=tr(338,482,414,462),C=tr(351,468,382,428),Fe=tr(355,463,370,414);
 const quad=(T,a0=0,a1=1,b0=0,b1=1)=>{g.beginPath();const p=[T(a0,b0),T(a1,b0),T(a1,b1),T(a0,b1)];g.moveTo(...p[0]);for(const q of p.slice(1))g.lineTo(...q);g.closePath()};
 /* shadow on the rug, legs, the front apron */
 g.fillStyle='rgba(4,1,10,.55)';g.beginPath();g.ellipse(cx,512,250,30,0,0,TAU);g.fill();
 for(const u of[.05,.95]){const [x,y]=O(u,1);g.fillStyle=pzLin(g,x-10,0,x+10,0,[[0,'#2a1206'],[.5,'#6a3816'],[1,'#2a1206']]);pzRR(g,x-10,y+16,20,30,5);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2.5;g.stroke();g.fillStyle='#c8902a';pzRR(g,x-12,y+40,24,8,3);g.fill();g.stroke()}
 {const [ax0,ay]=O(0,1),[ax1]=O(1,1);g.fillStyle=pzLin(g,0,ay,0,ay+24,[[0,'#8a4818'],[.5,'#6a3410'],[1,'#3e1c08']]);g.beginPath();g.moveTo(ax0,ay);g.lineTo(ax1,ay);g.lineTo(ax1-7,ay+24);g.lineTo(ax0+7,ay+24);g.closePath();g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();
  g.strokeStyle='rgba(255,200,140,.18)';g.lineWidth=2;g.beginPath();g.moveTo(ax0+10,ay+6);g.lineTo(ax1-10,ay+6);g.stroke();
  g.fillStyle='#c8902a';for(const x of[cx-80,cx+80]){g.beginPath();g.ellipse(x,ay+13,9,5,0,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2;g.stroke()}}
 /* the rails: wood lit from above, a highlight on the near edge, sights */
 quad(O);g.fillStyle=pzLin(g,0,338,0,482,[[0,'#6a3412'],[.6,'#a0582a'],[1,'#b86a32']]);g.fill();g.strokeStyle=PZ_O;g.lineWidth=3.4;g.stroke();
 g.strokeStyle='rgba(255,226,170,.42)';g.lineWidth=2;g.beginPath();g.moveTo(...O(.01,.985));g.lineTo(...O(.99,.985));g.stroke();
 g.strokeStyle='rgba(255,226,170,.22)';g.lineWidth=1.5;g.beginPath();g.moveTo(...O(.02,.02));g.lineTo(...O(.98,.02));g.stroke();
 g.fillStyle='#f4e6c0';for(const u of[.125,.25,.375,.625,.75,.875])for(const v of[-.045,1.045]){const [x,y]=C(u,v);g.beginPath();g.ellipse(x,y+(v>.5?2:0),2.6,1.5,0,0,TAU);g.fill()}
 for(const v of[.25,.5,.75])for(const u of[-.03,1.03]){const [x,y]=C(u,v);g.beginPath();g.ellipse(x+(u>.5?2:-2),y,1.6,1.6,0,0,TAU);g.fill()}
 /* cushions, then the felt with the lamp light on it and a little nap */
 quad(C);g.fillStyle=pzMix(F.c,'#000000',.25);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2;g.stroke();
 g.save();quad(Fe);g.clip();g.fillStyle=F.b;g.fillRect(450,320,560,240);g.translate(cx,404);g.scale(1,.42);const q=g.createRadialGradient(0,0,10,0,0,240);q.addColorStop(0,pzMix(F.a,'#ffffff',.22));q.addColorStop(.45,F.a);q.addColorStop(1,F.c);g.fillStyle=q;g.fillRect(-300,-300,600,600);g.restore();
 g.save();quad(Fe);g.clip();for(let i=0;i<500;i++){g.fillStyle=`rgba(255,255,255,${.02+pzNoise(i)*.03})`;g.fillRect(cx-210+pzNoise(i+9)*420,354+pzNoise(i+33)*110,1,1)}
  g.fillStyle='rgba(0,0,0,.22)';g.beginPath();g.moveTo(...Fe(0,0));g.lineTo(...Fe(1,0));g.lineTo(...Fe(1,.12));g.lineTo(...Fe(0,.12));g.fill();g.restore();
 quad(Fe);g.strokeStyle='rgba(0,0,0,.45)';g.lineWidth=1.5;g.stroke();
 /* pockets */
 for(const [u,v,r] of[[0,0,10],[.5,0,9],[1,0,10],[0,1,13],[.5,1,11.5],[1,1,13]]){const [x,y]=C(u,v),k=.55+.12*v;g.fillStyle='#2a1206';g.beginPath();g.ellipse(x,y,r+3,(r+3)*k,0,0,TAU);g.fill();g.fillStyle='#050208';g.beginPath();g.ellipse(x,y,r,r*k,0,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2;g.stroke();g.fillStyle='rgba(255,255,255,.08)';g.beginPath();g.ellipse(x,y-r*k*.35,r*.6,r*k*.3,0,0,TAU);g.fill()}
 /* the balls: the cue ball on the head spot, a full rack on the foot spot (back to front) */
 const balls=[[0,.25,.52]],cols=[[1],[9,2],[10,8,3],[11,7,14,4],[5,13,15,6,12]];cols.forEach((col,ci)=>col.forEach((n,ri)=>balls.push([n,.685+ci*.037,.5+(ri-(col.length-1)/2)*.095])));
 balls.sort((a,b)=>a[2]-b[2]);for(const [n,u,v] of balls){const [x,y]=Fe(u,v),d=15+v*2,im=pz97Ball(n,9);g.fillStyle='rgba(0,0,0,.35)';g.beginPath();g.ellipse(x+2,y+d*.42,d*.5,d*.2,0,0,TAU);g.fill();if(im)g.drawImage(im,x-d/2,y-d*.62,d,d)}
 PZ97.tbKey=key;return PZ97.tb=c}
/* ---------- the hanging lamp and its light (they swing together in CSS) ---------- */
function pz97Lamp(){if(PZ97.lamp)return PZ97.lamp;const L=pzCv(520,240),g=L.getContext('2d');g.scale(2,2);g.lineJoin='round';g.lineCap='round';const x=130;
 g.strokeStyle='#1a0e08';g.lineWidth=3;g.beginPath();g.moveTo(x,0);g.lineTo(x,62);g.stroke();g.fillStyle='#b8862a';pzRR(g,x-7,54,14,12,3);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2;g.stroke();
 g.fillStyle=pzLin(g,x-56,0,x+56,0,[[0,'#0e3a24'],[.35,'#2a8a56'],[.6,'#1d6a42'],[1,'#0a2a1a']]);g.beginPath();g.moveTo(x-16,64);g.lineTo(x+16,64);g.quadraticCurveTo(x+40,72,x+54,104);g.lineTo(x-54,104);g.quadraticCurveTo(x-40,72,x-16,64);g.closePath();g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();
 g.strokeStyle='rgba(200,255,220,.35)';g.lineWidth=2;g.beginPath();g.moveTo(x-12,69);g.quadraticCurveTo(x-34,76,x-44,98);g.stroke();
 g.fillStyle='#c8a03a';pzRR(g,x-56,101,112,7,3);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2;g.stroke();
 g.fillStyle='#fff2c0';g.beginPath();g.ellipse(x,109,40,6,0,0,TAU);g.fill();pzGlow(g,x,110,44,'rgba(255,240,190,1)',.8);
 const K=pzCv(320,400),k=K.getContext('2d');const q=k.createLinearGradient(0,0,0,400);q.addColorStop(0,'rgba(255,236,170,.34)');q.addColorStop(.7,'rgba(255,236,170,.10)');q.addColorStop(1,'rgba(255,236,170,0)');k.fillStyle=q;k.beginPath();k.moveTo(118,0);k.lineTo(202,0);k.lineTo(318,400);k.lineTo(2,400);k.closePath();k.fill();
 const q2=k.createLinearGradient(0,0,0,300);q2.addColorStop(0,'rgba(255,248,215,.26)');q2.addColorStop(1,'rgba(255,248,215,0)');k.fillStyle=q2;k.beginPath();k.moveTo(136,0);k.lineTo(184,0);k.lineTo(240,300);k.lineTo(80,300);k.closePath();k.fill();
 return PZ97.lamp={L,K}}
/* ---------- medallion portraits (baked: the frame is CSS, the face is a canvas) ---------- */
function pz97Port(id,lock){const key=id+(lock?'L':'');if(PZ97.port[key])return PZ97.port[key];const S=180,c=pzCv(S,S),g=c.getContext('2d'),R=PZ_REG[id];
 const q=g.createRadialGradient(S/2,S*.38,8,S/2,S*.5,S*.62);if(lock){q.addColorStop(0,'#2a2250');q.addColorStop(1,'#0c0820')}else{q.addColorStop(0,pzMix(R.c,'#3a2a8a',.42));q.addColorStop(.62,pzMix(R.c,'#1e1458',.7));q.addColorStop(1,'#120a32')}g.fillStyle=q;g.fillRect(0,0,S,S);
 if(!lock){g.fillStyle='rgba(255,240,200,.10)';g.beginPath();g.ellipse(S/2,S*.2,S*.42,S*.16,0,0,TAU);g.fill()}
 const f=pzCv(S,S),fg=f.getContext('2d');pz97Bust(fg,id,S,Object.assign(pzCastEx(),PZ_EXP[lock?'neutral':id==='shade'?'smug':'happy']),1.3);
 if(lock){const rim=pzCv(S,S),rg=rim.getContext('2d');rg.drawImage(f,0,0);rg.globalCompositeOperation='source-in';rg.fillStyle='#4a3e8a';rg.fillRect(0,0,S,S);fg.globalCompositeOperation='source-in';fg.fillStyle='#07050f';fg.fillRect(0,0,S,S);fg.globalCompositeOperation='source-over';g.drawImage(rim,0,-2.5);g.drawImage(f,0,0);
  g.fillStyle='rgba(120,100,200,.18)';g.beginPath();g.ellipse(S/2,S*.3,S*.3,S*.18,0,0,TAU);g.fill();g.drawImage(pzIco('lock',84),S/2-42,S/2-34)}
 else g.drawImage(f,0,0);
 return PZ97.port[key]=c}
/* ---------- the spotlight stage, baked per colour (narrow and tall, a lamp on top) ---------- */
function pz97Stage(col){if(PZ97.stage[col])return PZ97.stage[col];const W=214,H=496,c=pzCv(W,H),g=c.getContext('2d');
 g.fillStyle=pzLin(g,0,0,0,H,[[0,'#1c1250'],[1,'#0a0620']]);g.fillRect(0,0,W,H);
 const q=g.createRadialGradient(W/2,H-50,10,W/2,H-50,170);q.addColorStop(0,pzRgba(col).replace(',1)',',.34)'));q.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=q;g.fillRect(0,H-260,W,260);
 g.save();g.globalCompositeOperation='lighter';const cone=g.createLinearGradient(0,20,0,H-30);cone.addColorStop(0,'rgba(255,236,170,.32)');cone.addColorStop(1,'rgba(255,236,170,0)');g.fillStyle=cone;g.beginPath();g.moveTo(80,20);g.lineTo(134,20);g.lineTo(W-4,H-30);g.lineTo(4,H-30);g.closePath();g.fill();g.restore();
 g.fillStyle='rgba(255,236,170,.12)';g.beginPath();g.ellipse(W/2,H-34,92,15,0,0,TAU);g.fill();
 g.strokeStyle=pzRgba(col).replace(',1)',',.75)');g.lineWidth=3;g.beginPath();g.moveTo(14,H-14);g.lineTo(W-14,H-14);g.stroke();pzGlow(g,W/2,H-14,90,pzRgba(col),.3);
 g.fillStyle='#1d6a45';pzRR(g,W/2-40,-10,80,28,10);g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();g.fillStyle='#ffe9a0';g.beginPath();g.ellipse(W/2,18,28,6,0,0,TAU);g.fill();pzGlow(g,W/2,20,40,'rgba(255,240,190,1)',.5);
 return PZ97.stage[col]=c}
/* ---------- the hub ---------- */
function pzHub(){const Z=PZS(),tokH=++PZ.tok;PZ.on=false;PZ.hub=true;CAS.on=true;CAS.key=null;CAS.tok++;pzCastInit(PZ_ORDER[0]);try{pzMusicOn()}catch(e){}
 const pick=()=>PZ_ORDER.slice().reverse().find(k=>pzOpen(k)&&!(Z.beat[k]>0))||PZ_ORDER.filter(pzOpen).pop()||'gloop';
 if(PZ.sel==null||(PZ.sel!=='shade'&&!pzOpen(PZ.sel)))PZ.sel=pick();
 /* Slick Shade sometimes slides in once a day, after you have beaten Grizzle and carry some gold */
 if(!PZ.shadeChecked||PZ.shadeChecked!==pzDay()){PZ.shadeChecked=pzDay();PZ.shadeHere=false;if((Z.beat.grizzle||0)>0&&P.gold>=2000&&Z.shade.day!==pzDay()&&Math.random()<.12){PZ.shadeHere=true;Z.shade.day=pzDay();Z.shade.seen=(Z.shade.seen||0)+1;save()}}
 if(PZ.sel==='shade'&&!PZ.shadeHere)PZ.sel=pick();
 try{pzbSetup(52,Z.balls)}catch(e){}
 const beatN=PZ_ORDER.filter(k=>(Z.beat[k]||0)>0).length,nextK=PZ_ORDER.find(k=>pzOpen(k)&&!(Z.beat[k]>0)),rm=pzRM();
 /* the medallions, in ladder order (Shade first, like the old list, so up/down walk the ladder) */
 const med=(k,i,cx,cy,shade)=>{const R=PZ_REG[k],open=shade||pzOpen(k),n=shade?0:Z.beat[k]||0,lv=Z.live&&Z.live.opp===k,next=k===nextK,prev=i>0?PZ_REG[PZ_ORDER[i-1]]:null,d=shade?92:120;
  const tag=lv?`<em class="pz97tag live"><i></i>LIVE ${Z.live.score[0]}-${Z.live.score[1]}</em>`:!open?`<em class="pz97tag stars">${'★'.repeat(R.lvl)}<u>${'★'.repeat(7-R.lvl)}</u></em>`:k==='mortimer'&&n?'<em class="pz97tag champ">♛ CHAMPION</em>':next?'<em class="pz97tag nx">NEXT</em>':'';
  const tip=!open?`Beat ${prev.n} to open this table`:shade?'Slick Shade, the hustler: here tonight only':`${R.n}: ${R.k}${n?` · beaten ×${n}`:''}`;
  return `<button class="pzrow pz97md ${PZ.sel===k?'sel':''} ${open?'':'lock'} ${next?'next':''} ${n?'won':''} ${lv?'live':''} ${shade?'shade':''}" data-k="${k}" ${open?'':'disabled'} title="${tip.replace(/"/g,'&quot;')}" aria-label="${tip.replace(/"/g,'&quot;')}" style="left:${cx-300-d/2}px;top:${cy-116-d/2}px;--d:${d}px;--c:${R.c};--i:${i}">
   <span class="pz97in"><span class="pz97m"><i class="pz97halo"></i><canvas width="180" height="180" data-m="${k}"></canvas>${n?'<s class="pz97ck"></s>':''}</span><b class="pz97nm">${open?PZ97_PLATE[k]:'? ? ?'}</b>${tag}</span></button>`};
 const meds=(PZ.shadeHere?med('shade',-1,PZ97_SHADE[0],PZ97_SHADE[1],true):'')+PZ_ORDER.map((k,i)=>med(k,i,PZ97_SLOT[i][0],PZ97_SLOT[i][1])).join('');
 const live=Z.live?`<div class="pzresume2 pz97res" id="pzresume"><canvas width="88" height="88" data-p="${Z.live.opp}"></canvas><div><b>Match in progress</b><span>vs ${PZ_REG[Z.live.opp].n} · ${Z.live.score[0]} - ${Z.live.score[1]}${Z.live.stake&&!Z.live.practice?` · stake ${cmn(Z.live.stake)}`:' · practice'}</span></div><button id="pzrs1">Resume</button><button id="pzrs2" class="ghost">Forfeit</button></div>`:'';
 const tr=typeof pzTrickTotal==='function'?pzTrickTotal():0,trT=typeof PZ_TRICK!=='undefined'?PZ_TRICK.length*3:30,own=pzOwnCount(),W=Z.wins||0,L=Z.losses||0,tro=pzTrophies(),troN=tro.filter(a=>P.ach&&P.ach[a.id]).length;
 const bounty=typeof PZ_TRICK!=='undefined'?PZ_TRICK.filter((t,i)=>pzTrickStars(i)<3).length:0;
 const nav=[['trick','#7ad8ff','Trick Shots',`${tr} / ${trT} ★`,'T',bounty?'<s class="pzbdg g">+200</s>':''],['cues','#ffd45a','Cue Rack',`${own.n} / ${own.t} owned${own.nw?` · ${own.nw} new`:''}`,'C',own.nw?`<s class="pzbdg">${own.nw} NEW</s>`:''],
  ['regs','#ff9ab0','The Regulars',`${W}W · ${L}L · ${troN} / ${tro.length} trophies`,'R',''],['rules','#c8a0ff','How to Play','rules, controls, tutorials','H','']];
 const nets=Z.net||0;
 show(`<div class="pzh pzh9 pzh97 pzin${rm?' rm':''}" id="pzh"><canvas id="pzhbg" width="1600" height="900"></canvas><canvas class="pz97tw a" width="1600" height="100"></canvas><canvas class="pz97tw b" width="1600" height="100"></canvas>
  <div class="pzboard pz97tab" id="pz97tab"><div class="pz97lamp"><canvas class="pz97cone" width="320" height="400"></canvas><canvas class="pz97sh" width="520" height="240"></canvas></div><canvas class="pz97tbc" width="1088" height="472"></canvas>${PZ_ORDER.every(k=>(Z.beat[k]||0)>0)?'<div class="pz97champ">♛ Champion of the Crooked Cue</div>':''}${meds}</div>
  <canvas id="pzhfg" width="1600" height="900"></canvas>
  <button class="pzback" id="pzbk">‹&nbsp; Casino <kbd>Esc</kbd></button>
  <div class="pzgold"><i></i><b id="pzgold">${cmn(P.gold)}</b></div>
  <div class="pznet">Pool net <b class="${nets<0?'neg':''}">${nets<0?'−':'+'}${cmn(Math.abs(nets))}</b>${(Z.streak||0)>1?` · streak <b class="hot">${Z.streak}</b>`:''}</div>
  <div class="pztitle pzsign"><span>The Crooked Cue</span></div><div class="pzprog"><b>${beatN}</b> of 7 regulars beaten · <b>${Z.dayN}</b> / ${PZ_DAILY} paid matches today</div>
  <nav class="pznav">${nav.map(([a,c,t,s,k,x],i)=>`<button data-a="${a}" style="--c:${c};--i:${i}"><span class="pzni"><canvas width="72" height="72" data-ico="${a==='regs'?'trophy':a}"></canvas></span><span class="pznt"><b>${t}</b><span>${s}</span></span><i class="pz97chev"></i><kbd>${k}</kbd>${x}</button>`).join('')}</nav>
  <button class="pz97gran" id="pzgran" aria-label="Trick Shots with Granny"><span>★ Trick Shots with Granny</span></button>
  <div class="pzopp pzopp9 pz97opp" id="pzopp"></div>
  <div class="pz97bar" id="pz97bar"><div class="pz97lab">Choose your stake:</div><div class="pz97chips" id="pz97chips"></div><i class="pz97sep"></i>
   <div class="pz97num"><small>Total return</small><b id="pz97ret">0</b><em id="pz97mx"></em></div><i class="pz97sep"></i><div class="pz97num g"><small>Net profit</small><b id="pz97net">0</b><em id="pz97nx"></em></div>
   <button class="pzrackem pz97play" id="pzrackem"><span class="pz97pt" id="pz97pt"><span id="pz97p1">Play</span><i>•</i><span id="pz97p2"></span></span><kbd>Enter</kbd><i class="pzshine"></i></button>
   <button class="pzprac pz97prac" id="pzprac"><b>Practice</b><span id="pzpracs">free</span><kbd>P</kbd></button></div>${live}</div>`,'casbg pzx');
 const root=$('pzh');
 $('pzhbg').getContext('2d').drawImage(pz97Bg(),0,0);
 root.querySelectorAll('.pz97tw').forEach((c,i)=>c.getContext('2d').drawImage(pz97Twinkle(i),0,0));
 {const l=pz97Lamp();root.querySelector('.pz97sh').getContext('2d').drawImage(l.L,0,0);root.querySelector('.pz97cone').getContext('2d').drawImage(l.K,0,0)}
 root.querySelector('.pz97tbc').getContext('2d').drawImage(pz97Table(),0,0);
 root.querySelectorAll('canvas[data-m]').forEach(cv=>{const k=cv.dataset.m;cv.getContext('2d').drawImage(pz97Port(k,cv.closest('.lock')),0,0)});
 root.querySelectorAll('canvas[data-ico]').forEach(cv=>cv.getContext('2d').drawImage(pzIco(cv.dataset.ico,72),0,0));
 {const cv=root.querySelector('.pzresume2 canvas');if(cv)pzCastPortrait(cv.getContext('2d'),'mon',cv.dataset.p,88,1,Object.assign(pzCastEx(),PZ_EXP.neutral))}
 /* the bar: regulars you have beaten come for a drink (the default trio fills in); Granny keeps her corner table */
 const fg=$('pzhfg').getContext('2d');fg.lineJoin='round';fg.lineCap='round';
 /* whoever you pick leaves the bar for the table; the next regular in line steps up (a little rise) */
 let slots=[];const barFill=()=>{const sel=PZ.sel,beaten=PZ_ORDER.filter(k=>(Z.beat[k]||0)>0&&k!==sel&&k!=='moldwick').reverse(),fill=['grizzle','gloop','barnacle','hootsworth'].filter(k=>k!==sel&&!beaten.includes(k)),bar=[...beaten,...fill].slice(0,3),now=performance.now()/1000;
  slots=[1182,1316,1450].map((x,i)=>{const id=bar[i];if(!id)return null;const old=slots.find(o=>o&&o.i===i);if(old&&old.id===id)return old;const b=pzMonBox(id),s=Math.min(190/(b.x1-b.x0),226/(b.y1-b.y0));return {i,id,x:x-(b.x0+b.x1)/2*s,y:762-b.y0*s,s,ex:Object.assign(pzCastEx(),PZ_EXP[['happy','smug','happy'][i]]),ph:i*2,t0:old?now:0}}).filter(Boolean)};
 barFill();PZ97.barFill=barFill;
 const granB=pzMonBox('moldwick'),granS=.6,granEx=Object.assign(pzCastEx(),PZ_EXP.happy);
 const drawFg=()=>{if(PZ.tok!==tokH)return;const t=performance.now()/1000;fg.clearRect(1060,660,540,240);fg.clearRect(0,640,410,260);
  for(const s of slots){const u=s.t0?Math.min(1,(t-s.t0)/.5):1,rise=u<1?(1-u)*(1-u)*90-Math.sin(u*Math.PI)*8:0;fg.save();fg.translate(s.x,s.y+rise);fg.scale(s.s,s.s);pzMon[s.id](fg,t+s.ph,s.ex,{breath:Math.sin(t*2.2+s.ph)*.012,tilt:Math.sin(t*.9+s.ph)*.02,bob:0,hop:0});fg.restore()}
  fg.fillStyle=pzLin(fg,0,880,0,900,[[0,'#8a4a1c'],[.3,'#5a2c10'],[1,'#2a1206']]);pzRR(fg,1100,878,540,60,10);fg.fill();fg.strokeStyle=PZ_O;fg.lineWidth=3;fg.stroke();fg.fillStyle='rgba(255,210,150,.3)';fg.fillRect(1108,881,480,2);
  slots.forEach((s,i)=>pz97Mug(fg,[1244,1378,1512][i],884,1));
  fg.save();fg.translate(150-(granB.x0+granB.x1)/2*granS,748+345*granS);fg.scale(granS,granS);pzMon.moldwick(fg,t+1,granEx,{breath:Math.sin(t*2)*.012,tilt:Math.sin(t*.7)*.02,bob:0,hop:0});fg.restore();
  fg.fillStyle='#4a2410';fg.fillRect(290,870,12,30);fg.fillStyle=pzLin(fg,0,850,0,880,[[0,'#7a3e18'],[1,'#4a2410']]);fg.beginPath();fg.ellipse(296,866,74,17,0,0,TAU);fg.fill();fg.strokeStyle=PZ_O;fg.lineWidth=3;fg.stroke();fg.fillStyle='rgba(255,210,150,.2)';fg.beginPath();fg.ellipse(296,863,62,9,0,Math.PI,TAU);fg.fill();
  pz97Mug(fg,262,868,.9);fg.fillStyle='#f2e6c8';pzRR(fg,320,838,10,26,3);fg.fill();fg.strokeStyle=PZ_O;fg.lineWidth=2;fg.stroke();const fl=.85+.15*Math.sin(t*9)*Math.sin(t*5.3);pzGlow(fg,325,830,50,'rgba(255,170,90,1)',.45*fl);
  fg.fillStyle='#ffb04a';fg.beginPath();fg.moveTo(325,819-3*fl);fg.quadraticCurveTo(330,830,325,836);fg.quadraticCurveTo(320,830,325,819-3*fl);fg.fill()};
 LIVE.push({cv:$('pzhfg'),fn:drawFg,slow:2,ph:0});drawFg();
 PZ.oppSwap=0;PZ.payShown=null;PZ.oppFace=null;pzHubOpp();
 root.querySelectorAll('.pz97md').forEach(b=>b.onclick=()=>{if(b.disabled)return;pzHubSel(b.dataset.k)});
 const go=a=>{pzFx('tick');if(a==='practice'){pzMusicOff();pzStart({opp:PZ.sel==='shade'?'gloop':PZ.sel,practice:true})}else if(a==='cues')pzGo(pzCueRack);else if(a==='rules')pzGo(pzRules);else if(a==='regs')pzGo(pzRegs);else if(a==='trick'&&typeof pzTrick==='function')pzGo(pzTrick)};
 root.querySelectorAll('.pznav button').forEach(b=>b.onclick=()=>go(b.dataset.a));$('pzprac').onclick=()=>go('practice');$('pzgran').onclick=()=>go('trick');
 $('pzbk').onclick=()=>{pzMusicOff();try{lobby()}catch(e){title()}};S.back=()=>$('pzbk').click();
 $('pzrackem').onclick=()=>{if(Z.live){$('pzrs1').click();return}const sel=PZ.sel,R=PZ_REG[sel],lo=sel==='shade'?500:Math.min(...R.stakes.filter(s=>s<=casCap('pz')));if(P.gold<lo){pzMusicOff();pzNote('Not enough gold for stakes, so this one is a free practice game.');pzStart({opp:sel==='shade'?'gloop':sel,practice:true});return}const stake=sel==='shade'?PZ.shadeStake:pzStakeOf(sel);pzMusicOff();pzStart({opp:sel,stake})};
 if(Z.live){$('pzrs1').onclick=()=>{pzStart({opp:Z.live.opp,resume:Z.live,race:Z.live.race})};$('pzrs2').onclick=function(){if(!this.dataset.sure){this.dataset.sure=1;const t=this.textContent;this.textContent=Z.live&&Z.live.stake&&!Z.live.practice?'Sure? You lose the stake':'Sure? Drop this match';setTimeout(()=>{if(this.isConnected){delete this.dataset.sure;this.textContent=t}},3200);return}const L=Z.live;Z.live=null;if(L.stake&&!L.practice){Z.losses++;Z.streak=0;ecSrc('pool',()=>cPay(L.stake,0));Z.net-=L.stake;const v=pzVs();v[L.opp]=v[L.opp]||[0,0];v[L.opp][1]++}save();
   const el=$('pzresume');el.classList.add('out');const lm=root.querySelector('.pz97md.live');if(lm){lm.classList.remove('live');const tg=lm.querySelector('.pz97tag.live');if(tg)tg.remove()}setTimeout(()=>{el.remove();pzHubOpp()},260)}}
 setTimeout(()=>{const h=$('pzh');if(h&&PZ.tok===tokH)h.classList.remove('pzin')},1500);
 pzFitTM();try{pzHubTour()}catch(e){}}
/* pick a regular: the medallion grows, the spotlight slides over to the new face, who hops and says hello */
function pzHubSel(k){if(k===PZ.sel)return;const rows=[...ov.querySelectorAll('.pzrow')],b=rows.find(r=>r.dataset.k===k);if(!b||b.disabled)return;
 const i0=rows.findIndex(r=>r.dataset.k===PZ.sel),i1=rows.indexOf(b);PZ.oppSwap=i1>i0?1:-1;PZ.sel=k;pzFx('tick');rows.forEach(x=>x.classList.toggle('sel',x===b));pzHubOpp();try{if(PZ97.barFill)PZ97.barFill()}catch(e){}}
/* the spotlight card and the stake bar */
function pzHubOpp(){const id=PZ.sel,R=PZ_REG[id],Z=PZS(),el=$('pzopp');if(!el||!R)return;const hustler=id==='shade',cap=casCap('pz');
 if(hustler&&!PZ.shadeStake)PZ.shadeStake=Math.min(cap,Math.max(500,Math.min(P.gold,1000)));
 const stake=hustler?PZ.shadeStake:pzStakeOf(id),mult=pzMultS(id,stake),wise=Z.rep[id]||0,paid=Z.dayN<PZ_DAILY;
 const list=hustler?[500,1000,2000,3000,5000].filter(s=>s<=cap):R.stakes.filter(s=>s<=cap),lo=list.length?Math.min(...list):0,poor=P.gold<lo;
 const cue=hustler?PZ_CUES.find(c=>c.beatShade):PZ_CUES.find(c=>c.beat===id),cn=hustler?(Z.shade.beat||0):(Z.beat[id]||0),have=cue&&Z.cues[cue.id];
 const vs=pzVs()[id]||[0,0],win=Math.round(stake*mult),fm=x=>x.toFixed(2).replace(/0$/,'').replace(/\.0$/,'');
 const sw=PZ.oppSwap,newFace=sw!==0||PZ.oppFace!==id;PZ.oppSwap=0;PZ.oppFace=id;
 const wiseShow=wise&&paid&&!poor,full=Math.min(R.mult,Math.floor(PZ_CAP/Math.max(1,stake)*100)/100),free=poor||!paid||!!Z.live;
 const a=R.ai,mtr=hustler?null:[['Aim',1+(3-a.sig)/2.1*4],['Position',1+a.pos*5],['Safety',1+a.safe*9],['Planning',a.look*.62]];
 const kk=s=>s>=1000?(s/1000)+'K':s;
 el.innerHTML=`<div class="pzo9 ${sw?(sw>0?'swd':'swu'):''}"><div class="pzstage"><canvas class="pzstbg" width="214" height="496"></canvas><canvas id="pzoppc" width="214" height="392"></canvas><div class="pzbub ${newFace?'pop':''}">“${R.lines.hi[0]}”</div></div>
  <div class="pzoppi"><div class="pzh3" style="color:${R.c}">${R.n}</div><div class="pzsub2"${R.k.length>20?' style="font-size:12px"':''}>${R.k}${R.lvl?` <span class="pzstars">${pzStars(R.lvl)}</span>`:' <span class="pz97tn">TONIGHT ONLY</span>'}</div>
   <div class="pzfacts"><div><b>${R.race}</b><small>${R.race>1?'RACKS TO WIN':'RACK WINS IT'}</small></div><div class="g"><b>${wiseShow&&full>mult?`<s>×${fm(full)}</s>`:''}×${fm(mult)}</b><small>${wiseShow?'WISE TO YOU':'PAYS'}</small></div><div><b>${vs[0]||vs[1]||!cn?`${vs[0]}-${vs[1]}`:`${cn}W`}</b><small>YOUR RECORD</small></div></div>
   <div class="pzhrc pz97hr"><canvas width="44" height="44" data-ico="rules"></canvas><div><b>House rule</b><span>${PZ97_HOUSE[id]||R.houseTxt}</span></div><button class="pz97info" aria-label="House rule details">i</button><div class="pz97tip"><b>${R.houseTxt}</b>${PZ_TIPS[id]?`<em>${PZ_TIPS[id]}</em>`:''}</div></div>
   ${mtr?`<div class="pzmtr">${mtr.map(([n,x])=>{const k=Math.max(1,Math.min(5,Math.round(x)));return `<div><span>${n}</span><i>${'<u class="on"></u>'.repeat(k)}${'<u></u>'.repeat(5-k)}</i></div>`}).join('')}</div>`:'<div class="pzmtr shd">Bets small, wins big, shows up when he likes. Beat him three times for the Shadow Cue.</div>'}
   <div class="pz97stk"><small>STAKE</small><div class="pz97cc ${list.length>4?'many':''}">${list.map(s=>`<button class="pz97c ${s===stake&&!free?'on':''}" data-s="${s}" ${s>P.gold?'disabled':''} style="--cc:${PZ_CHIPC[s]||'#6a5ab0'};--ct:${s===50?'#2a1a3a':s===1000?'#ffd45a':'#fff'}" aria-label="Stake ${s}"><i></i><b>${kk(s)}</b></button>`).join('')}</div></div>
   <div class="pzpay9">${poor?`<span class="warn">You need ${cmn(lo)} gold to play for stakes. Practice is free.</span>`:!paid?`<span class="warn">Daily paid matches used: this one is a friendly.</span>`:`Win pays <b id="pzpayv">${cmn(PZ.payShown!=null&&!newFace?PZ.payShown:win)}</b><em>+${cmn(win-stake)} profit</em>`}</div>
   ${cue?`<div class="pzrew ${have?'have':''}"><canvas id="pzrewc" width="180" height="30"></canvas><div><b>${cue.n}</b><span>${have?'Yours':`${Math.min(cn,3)} / 3 wins`}</span></div><em><i style="transform:scaleX(${have?1:Math.min(cn,3)/3})"></i></em></div>`:''}</div></div>`;
 el.style.setProperty('--c',R.c);
 {const h=el.querySelector('.pzh3');let fs=40;h.style.fontSize=fs+'px';while(h.scrollWidth>h.clientWidth+1&&fs>26){fs-=2;h.style.fontSize=fs+'px'}}
 el.querySelector('.pzstbg').getContext('2d').drawImage(pz97Stage(R.c),0,0);el.querySelectorAll('canvas[data-ico]').forEach(cv=>cv.getContext('2d').drawImage(pzIco(cv.dataset.ico,44),0,0));
 const cv=$('pzoppc'),g=cv.getContext('2d');g.lineJoin='round';g.lineCap='round';const ex=Object.assign(pzCastEx(),PZ_EXP[newFace?'happy':'neutral']),fit=(()=>{const b=pzMonBox(id);return pzMonFit(id,214,372,10,Math.max(1.1,Math.min(1.6,(b.x1-b.x0)/300)))})(),t0=performance.now()/1000;let calm=!newFace;
 const f=()=>{if(!cv.isConnected)return;const t=performance.now()/1000,ht=t-t0,hy=newFace&&ht<.55?-Math.sin(ht/.55*Math.PI)*22:0;if(ht>1.2&&!calm){Object.assign(ex,PZ_EXP.neutral);calm=true}
  g.clearRect(0,0,214,392);g.save();g.translate(fit.x,fit.y+hy+16);g.scale(fit.s,fit.s);pzMon[id](g,t,ex,{breath:Math.sin(t*2.2)*.012,tilt:Math.sin(t*.8)*.025,bob:Math.sin(t*1.7)*1.4,hop:0});g.restore()};f();LIVE.push({cv,fn:f,slow:1,ph:1});
 {const rc=$('pzrewc');if(rc&&cue){try{pzRackThumb(rc.getContext('2d'),'cues',cue,180,30)}catch(e){}}}
 el.querySelectorAll('.pz97c').forEach(b=>b.onclick=()=>{if(b.disabled)return;pzHubStake(+b.dataset.s)});
 /* the payout rolls to its new value (card and bar) */
 const roll=(node,to,fmt)=>{if(!node)return;const from=+(node.dataset.v||to);node.dataset.v=to;if(from===to||newFace||pzRM()){node.textContent=fmt(to);return}const t1=performance.now(),stp=()=>{if(!node.isConnected)return;const u=Math.min(1,(performance.now()-t1)/320),e=1-Math.pow(1-u,3);node.textContent=fmt(Math.round(from+(to-from)*e));if(u<1)requestAnimationFrame(stp)};node.textContent=fmt(from);requestAnimationFrame(stp)};
 {const pv=$('pzpayv');if(pv){pv.dataset.v=PZ.payShown!=null&&!newFace?PZ.payShown:win;roll(pv,win,cmn)}PZ.payShown=paid&&!poor?win:null}
 /* the stake bar */
 const chips=$('pz97chips');if(chips){const prev=+(chips.dataset.s||0);chips.className='pz97chips'+(list.length>4?' many':'')+(free?' off':'');
  chips.innerHTML=list.map((s,i)=>`<button class="pzchip2 pz97ch ${s===stake&&!free?'on':''} ${s===stake&&!free&&prev&&prev!==s?'pop':''}" data-s="${s}" ${s>P.gold||Z.live?'disabled':''} style="--cc:${PZ_CHIPC[s]||'#6a5ab0'};--ct:${s===50?'#2a1a3a':s===1000?'#ffd45a':'#fff'};--j:${i}" aria-label="Stake ${s}"><s class="pz97pill"></s><u></u><i></i><b>${cmn(s)}</b></button>`).join('');chips.dataset.s=stake;
  chips.querySelectorAll('.pz97ch').forEach(b=>b.onclick=()=>{if(b.disabled)return;pzHubStake(+b.dataset.s)})}
 const ret=$('pz97ret'),net=$('pz97net'),mx=$('pz97mx'),nx=$('pz97nx');
 if(ret){if(free){ret.dataset.v='';ret.textContent='—';net.dataset.v='';net.textContent=Z.live?'—':'Free';mx.textContent=Z.live?'match in progress':poor?`need ${cmn(lo)} gold`:'daily limit reached';nx.textContent=Z.live?'':'no stake'}
  else{roll(ret,win,cmn);roll(net,win-stake,v=>(v<0?'−':'+')+cmn(Math.abs(v)));mx.textContent=`(×${fm(mult)})`;nx.textContent=''}}
 const rb=$('pzrackem');if(rb){const p1=$('pz97p1'),p2=$('pz97p2');p1.textContent=Z.live?'Resume':poor?'Free game':!paid?'Friendly':'Play';
  p2.textContent=Z.live?`vs ${pzShort(Z.live.opp)} ${Z.live.score[0]}-${Z.live.score[1]}`:poor||!paid?`vs ${pzShort(hustler?'gloop':id)}`:`${cmn(stake)} coins`;rb.classList.toggle('alt',free);
  const pt=$('pz97pt');let fs=44;pt.style.fontSize=fs+'px';while(pt.offsetWidth>300&&fs>28){fs-=2;pt.style.fontSize=fs+'px'}}
 const ps=$('pzpracs');if(ps)ps.textContent=`free vs ${pzShort(hustler?'gloop':id)}`}
function pzHubStake(s){const id=PZ.sel;if(id==='shade')PZ.shadeStake=s;else{PZ.stk=PZ.stk||{};PZ.stk[id]=s}pzFx('tick');pzHubOpp();for(const b of ov.querySelectorAll(`.pz97c[data-s="${s}"]`))b.classList.add('pop')}
/* the first-visit tour, pointed at the new layout (7 steps, as before) */
function pzHubTour(){const Z=PZS();if(Z.tut.hub||Z.live)return;const tk=PZ.tok;setTimeout(()=>{if(PZ.tok!==tk||!$('pzh')||pzCoachActive())return;
 pzCoach('hub',[
  {title:'Welcome to the Crooked Cue!',text:'Play 8-ball against the casino\'s monster regulars. Beat one to open the next table, win their gold and collect their <b>signature cues</b>.',w:440},
  {sel:()=>({x:340,y:150,w:704,h:500}),side:'right',pad:0,title:"Tonight's regulars",text:'They sit around the table, easiest first. A <b>green check</b> means beaten, <b>gold</b> is your next opponent, locked ones are still in the dark. <b>Click a face</b> (or <kbd>1</kbd>-<kbd>7</kbd>, <kbd>↑</kbd> <kbd>↓</kbd>) to pick.',w:340},
  {sel:'#pzopp',side:'left',title:'Know your opponent',text:'Every regular has a <b>house rule</b> (the <b>i</b> tells you more and how to beat them). Beat them 3 times to earn their cue.',w:330},
  {sel:'#pz97chips',side:'top',title:'Choose your stake',text:'Pick a <b>chip</b> (or <kbd>←</kbd> <kbd>→</kbd>). The bar shows what a win pays back and your <b>profit</b>.',w:340},
  {sel:'#pzrackem',side:'top',title:'Play',text:'Starts the match. Paid matches take your stake now and pay it back, with the winnings, if you win.',w:330},
  {sel:'#pzprac',side:'top',title:'New to pool?',text:'<b>Practice</b> against the selected regular is free: no stake, no pressure. It is the best place to learn the controls.',w:330},
  {sel:'.pznav',side:'right',title:'More to do',text:'<b>Trick Shots</b> are one-shot puzzles that pay gold for stars. The <b>Cue Rack</b> holds cues, felts and ball sets (looks only). <b>The Regulars</b> keeps your record, and <b>How to Play</b> has the rules. Ready?',w:360,extra:['Practice first',()=>{pzMusicOff();pzStart({opp:'gloop',practice:true})}]}
 ],{kicker:'THE CROOKED CUE',last:"Let's play"})},700)}
{const st=document.createElement('style');st.textContent=`
.pzh97>canvas.pz97tw{height:100px;opacity:.15;animation:pz97tw 2.8s ease-in-out infinite}.pzh97>canvas.pz97tw.b{animation-duration:3.7s;animation-delay:-1.2s}
.pzh97 .pz97tab{left:300px;top:116px;width:748px;height:574px;padding:0;border:0;border-radius:0;background:none;box-shadow:none;z-index:2;pointer-events:none}
.pz97tab>*{pointer-events:auto}.pz97tab>canvas,.pz97tab>.pz97lamp,.pz97tab>.pz97champ{pointer-events:none}
.pz97tbc{position:absolute;left:150px;top:204px;width:544px;height:236px}
.pz97lamp{position:absolute;left:312px;top:-20px;width:260px;height:400px;transform-origin:130px 0;animation:pz97swing 5.2s ease-in-out infinite}
.pz97lamp canvas{position:absolute;left:0}.pz97sh{top:0;width:260px;height:120px}.pz97cone{top:108px;left:-30px!important;width:320px;height:400px;animation:pz97glow 3.4s ease-in-out infinite;transform-origin:50% 0}
.pz97champ{position:absolute;left:422px;top:274px;transform:translateX(-50%);padding:4px 14px;border-radius:12px;background:linear-gradient(180deg,#ffe27a,#f2b631);border:3px solid #12081f;font:400 20px/1.1 "Pirata One",serif;color:#2a1a04;white-space:nowrap;box-shadow:0 5px 0 #0008;z-index:3}
.pzh97 .pz97md.pzrow{position:absolute;display:block;box-shadow:none;min-width:0;letter-spacing:normal;width:var(--d);height:calc(var(--d) + 16px);padding:0;gap:0;border:0;border-radius:0;background:none;opacity:1;cursor:pointer;color:inherit;font:inherit;text-align:center;z-index:2;transform:none;transition:none}
.pzh97 .pz97md.pzrow.sel{z-index:4;background:none;transform:none}.pzh97 .pz97md.pzrow:hover:not(:disabled){z-index:5;background:none;transform:none}.pzh97 .pz97md.pzrow:hover:not(:disabled):not(.sel){transform:none}
.pzh97 .pz97md.pzrow.sel::before{content:none}.pzh97 .pz97md.pzrow.lock{opacity:1;cursor:default}
.pzh97 .pz97md:focus-visible{outline:none}.pzh97 .pz97md:focus-visible .pz97nm{outline:3px solid #ffd45a;outline-offset:2px}
.pzh97 .pz97in{position:absolute;inset:0;display:block}
.pzh97 .pz97md.next .pz97in{animation:pz97bob 2.2s ease-in-out infinite}
.pzh97 .pz97m{position:absolute;left:0;top:0;display:block;width:var(--d);height:var(--d);border-radius:50%;box-sizing:border-box;border:5px solid transparent;background:linear-gradient(#0e0828,#0e0828) padding-box,linear-gradient(160deg,#a898ff,#5a4cb8 55%,#3a2f8a) border-box;box-shadow:0 0 0 3px #12081f,inset 0 0 0 2px #12081f,0 10px 0 #0007;transform-origin:50% 92%;transition:transform .4s cubic-bezier(.3,1.65,.45,1)}
.pzh97 .pz97m canvas{position:absolute;left:0;top:0;width:100%;height:100%;border:0;border-radius:50%;background:none}
.pzh97 .pz97m::after{content:'';position:absolute;inset:3px;border-radius:50%;background:radial-gradient(ellipse 70% 40% at 40% 12%,#ffffff2a,#fff0 70%);pointer-events:none}
.pzh97 .pz97md.next .pz97m{background:linear-gradient(#0e0828,#0e0828) padding-box,linear-gradient(160deg,#fff2a8,#ffd45a 40%,#c88a1a) border-box;border-width:6px}
.pzh97 .pz97md.sel .pz97m{transform:scale(1.25)}
.pzh97 .pz97md:hover:not(:disabled):not(.sel) .pz97m{transform:scale(1.08) translateY(-3px)}.pzh97 .pz97md.sel:hover .pz97m{transform:scale(1.29)}.pzh97 .pz97md:active:not(:disabled) .pz97m{transform:scale(.96)}
.pzh97 .pz97md.lock .pz97m{background:linear-gradient(#0a0618,#0a0618) padding-box,linear-gradient(160deg,#3a3270,#1e1844) border-box;box-shadow:0 0 0 3px #12081f,inset 0 0 0 2px #12081f,0 8px 0 #0006}
.pzh97 .pz97md.shade .pz97m{background:linear-gradient(#0a0618,#0a0618) padding-box,linear-gradient(160deg,#fff4a0,#ffe066 45%,#8a6a10) border-box}
.pzh97 .pz97halo{position:absolute;inset:-9px;border-radius:50%;border:3px solid var(--c);opacity:0;pointer-events:none}
.pzh97 .pz97md.sel .pz97halo{animation:pz97halo 1.9s ease-out infinite}.pzh97 .pz97md.sel.next .pz97halo{border-color:#ffd45a}
.pzh97 .pz97ck{position:absolute;right:-4px;bottom:6px;width:30px;height:30px;box-sizing:border-box;border-radius:50%;background:radial-gradient(circle at 40% 35%,#5ae08a,#1d8a4a 70%);border:3px solid #12081f;box-shadow:inset 0 0 0 2px #ffffff40;text-decoration:none;z-index:2}
.pzh97 .pz97ck::after{content:'';position:absolute;left:8px;top:3px;width:6px;height:12px;border:solid #fff;border-width:0 4px 4px 0;transform:rotate(42deg)}
.pzh97 .pz97md.sel .pz97ck{transform:scale(.82)}
.pzh97 .pz97nm{position:absolute;left:50%;top:calc(var(--d) - 14px);transform:translateX(-50%);max-width:178px;padding:1px 13px 3px;border-radius:12px;background:linear-gradient(180deg,#221a5a,#0e0828);border:2.5px solid #5a4ca0;box-shadow:0 0 0 2px #12081f,0 5px 0 #0008;font:400 21px/1.15 "Pirata One",Georgia,serif;color:#f6e8c4;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;z-index:3}
.pzh97 .pz97md.next .pz97nm{border-color:#ffd45a;color:#fff2c8}.pzh97 .pz97md.sel .pz97nm{border-color:var(--c)}.pzh97 .pz97md.sel.next .pz97nm{border-color:#ffd45a}
.pzh97 .pz97md.lock .pz97nm{color:#8a86a8;border-color:#2e2860;letter-spacing:.12em}
.pzh97 .pz97md.shade .pz97nm{font-size:18px;border-color:#ffe066;color:#ffe9a0}
.pzh97 .pz97tag{position:absolute;left:50%;top:calc(var(--d) + 16px);transform:translateX(-50%);padding:2px 12px;border-radius:9px;font:800 12.5px/1.3 Poppins,sans-serif;font-style:normal;letter-spacing:.1em;white-space:nowrap;border:2.5px solid #12081f;z-index:2}
.pzh97 .pz97tag.nx{background:linear-gradient(180deg,#ffe27a,#f2b631);color:#2a1a04;box-shadow:0 4px 0 #0007}
.pzh97 .pz97tag.live{background:#5a1428;color:#ffb0c0;display:flex;align-items:center;gap:6px}.pzh97 .pz97tag.live i{width:8px;height:8px;border-radius:50%;background:#ff4a6a;animation:pznext 1s ease-in-out infinite}
.pzh97 .pz97tag.champ{background:linear-gradient(180deg,#ffe27a,#f2b631);color:#2a1a04}.pzh97 .pz97tag.shd{background:#ffe066;color:#2a1a04;font-size:10.5px;padding:1px 8px}
.pzh97 .pz97tag.stars{top:calc(var(--d) + 19px);border:0;padding:0;background:none;font-size:11px;letter-spacing:1px;color:#8a7a4a}.pzh97 .pz97tag.stars u{text-decoration:none;color:#ffffff1c}
.pzh97 .pznav{top:132px;gap:12px}
.pzh97 .pznav button{height:92px;padding-right:34px}.pzh97 .pznt>span{font-size:12px}.pzh97 .pznav button:hover,.pzh97 .pznav button:focus-visible{background:linear-gradient(180deg,#ffe27a,#f2b631);border-color:#12081f;transform:translateX(8px)}
.pzh97 .pznav button:hover .pznt b,.pzh97 .pznav button:focus-visible .pznt b{color:#2a1a04}.pzh97 .pznav button:hover .pznt>span,.pzh97 .pznav button:focus-visible .pznt>span{color:#5a3a06}
.pzh97 .pznav kbd{right:auto;left:66px;bottom:auto;top:8px;opacity:0;transition:opacity .2s}.pzh97 .pznav button:hover kbd{opacity:.9}
.pz97chev{position:absolute;right:16px;top:50%;width:11px;height:11px;margin-top:-7px;border:solid #c4badf;border-width:3.5px 3.5px 0 0;transform:rotate(45deg);transition:transform .25s cubic-bezier(.3,1.6,.5,1)}
.pznav button:hover .pz97chev{border-color:#2a1a04;transform:translateX(4px) rotate(45deg)}
.pzh97 .pz97gran{position:absolute;left:46px;top:740px;width:196px;height:156px;min-width:0;padding:0;border:0;border-radius:40px;background:none;box-shadow:none;cursor:pointer;z-index:3}
.pzh97 .pz97gran:focus-visible{outline:none}.pz97gran span{position:absolute;left:150px;top:28px;padding:6px 12px;border-radius:12px;background:#100a30f0;border:2px solid #8affb4;color:#a8ffcc;font:800 12.5px Poppins,sans-serif;white-space:nowrap;opacity:0;transform:translateY(8px) scale(.9);transition:opacity .2s,transform .3s cubic-bezier(.3,1.6,.5,1);pointer-events:none}
.pz97gran span::before{content:'';position:absolute;left:-9px;top:50%;margin-top:-7px;border:7px solid transparent;border-left:0;border-right:9px solid #8affb4}.pz97gran:hover span,.pz97gran:focus-visible span{opacity:1;transform:none}
.pzh97 .pz97opp{left:1048px;top:116px;width:528px;height:524px;border-width:3px}
.pzh97 .pzstage{left:12px;top:12px;width:214px;height:496px}
.pzh97 .pzstbg{width:214px;height:496px}.pzh97 #pzoppc{top:104px;width:214px;height:392px}
.pzh97 .pzstage .pzbub{left:7px;right:7px;top:40px;font-size:12px;padding:7px 8px}
.pzh97 .pz97opp .pzoppi{left:240px;top:12px;right:14px}
.pzh97 .pz97opp .pzoppi .pzh3{font-size:40px;line-height:1.05}
.pzh97 .pzsub2{margin-top:3px;font-size:13.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.pzh97 .pzsub2 .pzstars{font-size:13px;letter-spacing:.5px}
.pz97tn{padding:1px 8px;border-radius:8px;background:#ffe066;color:#2a1a04;font:800 10px Poppins,sans-serif;letter-spacing:.1em}
.pzh97 .pzfacts{gap:7px;margin:12px 0 11px}.pzh97 .pzfacts div{padding:9px 2px 7px;border-radius:12px}.pzh97 .pzfacts b{font-size:30px}.pzh97 .pzfacts small{font-size:8.5px;letter-spacing:.1em}
.pz97hr{position:relative;align-items:center;padding:10px 40px 10px 10px;min-height:48px}.pz97hr span{font-size:13px}
.pzh97 .pz97info{position:absolute;right:9px;top:50%;width:24px;height:24px;min-width:0;margin-top:-12px;padding:0;box-shadow:none;letter-spacing:0;border-radius:50%;border:2.5px solid #c4badf;background:#140c36;color:#efe8ff;font:800 13px/19px Georgia,serif;font-style:italic;cursor:help;transition:transform .2s cubic-bezier(.3,1.6,.5,1)}
.pz97info:hover,.pz97info:focus-visible{transform:scale(1.15);border-color:#ffd45a;outline:none}
.pz97tip{position:absolute;right:-6px;top:calc(100% + 8px);width:300px;box-sizing:border-box;padding:10px 13px;border-radius:14px;background:linear-gradient(180deg,#2a2070,#120b38);border:2.5px solid #ffd45a;box-shadow:0 0 0 2px #12081f,0 14px 30px #000c;z-index:9;opacity:0;transform:translateY(-6px) scale(.96);transform-origin:90% 0;transition:opacity .18s,transform .3s cubic-bezier(.3,1.5,.5,1);pointer-events:none}
.pz97tip b{display:block;font:700 12.5px/1.4 Poppins,sans-serif;color:#fff2c8}.pz97tip em{display:block;margin-top:5px;font:600 12px/1.4 Poppins,sans-serif;font-style:normal;color:#9ad8b0}
.pz97hr:hover .pz97tip,.pz97info:focus-visible+.pz97tip{opacity:1;transform:none}
.pzh97 .pzmtr{margin:11px 2px 0;gap:5px 16px}.pzh97 .pzmtr span{font-size:9.5px}.pzh97 .pzmtr i{gap:2px}.pzh97 .pzmtr u{width:10px;height:7px}
.pz97stk{display:flex;align-items:center;gap:10px;margin-top:14px}.pz97stk small{flex:none;font:800 10.5px Poppins,sans-serif;letter-spacing:.12em;color:#c4badf}
.pz97cc{display:flex;gap:6px}
.pzh97 .pz97c{position:relative;width:48px;height:48px;min-width:0;padding:0;border-radius:50%;border:3px solid #12081f;cursor:pointer;background:repeating-conic-gradient(var(--cc) 0 22.5deg,#fff 22.5deg 30deg,var(--cc) 30deg 45deg);box-shadow:0 4px 0 #0008;transition:transform .25s cubic-bezier(.3,1.7,.5,1)}
.pz97c i{position:absolute;inset:6px;border-radius:50%;background:var(--cc);border:2px dashed #ffffffa0}.pz97c b{position:relative;font:800 13px/1 Poppins,sans-serif;color:var(--ct);text-shadow:0 1px 0 #12081f,0 -1px 0 #12081f,1px 0 0 #12081f,-1px 0 0 #12081f}
.pz97c:hover:not(:disabled){transform:translateY(-3px)}.pz97c.on{transform:translateY(-5px) scale(1.06);box-shadow:0 0 0 3px #ffd45a,0 0 0 5px #12081f,0 8px 0 #0006}.pz97c:disabled{opacity:.28;cursor:default}
.pz97c.pop{animation:pzchipspin .5s cubic-bezier(.3,1.4,.5,1)}
.pzh97 .pz97cc.many .pz97c{width:39px;height:39px}.pzh97 .pz97cc.many .pz97c i{inset:4px}.pzh97 .pz97cc.many .pz97c b{font-size:11px}.pz97cc.many{gap:4px}
.pzh97 .pzpay9{margin-top:12px}.pzh97 .pzpay9 b{font-size:38px}
.pzh97 .pzrew{margin-top:12px;padding:10px 10px 12px}.pzh97 .pzrew canvas{width:130px;height:22px}.pzh97 .pzrew b{font-size:13px}
.pz97bar{position:absolute;left:152px;top:654px;width:1380px;height:102px;box-sizing:border-box;padding:0 16px 0 26px;display:flex;align-items:center;gap:14px;border-radius:24px;background:linear-gradient(180deg,#241c62,#100a30);border:3px solid #4a3e90;box-shadow:0 0 0 3px #12081f,inset 0 1px 0 #ffffff24,0 14px 30px #000a;z-index:4}
.pz97lab{flex:none;font:700 16px/1.25 Poppins,sans-serif;color:#f6e8c4;white-space:nowrap}
.pz97chips{flex:1;display:flex;align-items:center;justify-content:center;gap:26px;min-width:0}
.pz97chips.many{gap:17px}
.pzh97 .pz97ch.pzchip2{position:relative;flex:none;width:62px;height:62px;min-width:0;padding:0;border:0;border-radius:50%;background:none;box-shadow:none;cursor:pointer;transition:transform .3s cubic-bezier(.3,1.7,.5,1)}
.pz97ch u{position:absolute;inset:0;border-radius:50%;border:3px solid #12081f;background:repeating-conic-gradient(var(--cc) 0 20deg,#fff 20deg 30deg,var(--cc) 30deg 45deg);box-shadow:0 5px 0 #0009;transition:opacity .2s,transform .35s cubic-bezier(.3,1.6,.5,1)}
.pz97ch i{position:absolute;inset:8px;border-radius:50%;background:radial-gradient(circle at 40% 35%,#ffffff30,#fff0 60%),var(--cc);border:2px dashed #ffffffb0;transition:opacity .2s,transform .35s cubic-bezier(.3,1.6,.5,1)}
.pz97ch b{position:relative;display:block;font:800 15px/1 Poppins,sans-serif;color:var(--ct);text-shadow:0 2px 0 #12081f,0 -1px 0 #12081f,1px 0 0 #12081f,-1px 0 0 #12081f;transition:transform .35s cubic-bezier(.3,1.6,.5,1)}
.pz97pill{position:absolute;left:50%;top:-1px;width:108px;height:64px;margin-left:-54px;border-radius:32px;box-sizing:border-box;border:3px solid #12081f;background:radial-gradient(ellipse at 40% 30%,#ffffff38,#fff0 60%),var(--cc);box-shadow:0 0 0 3px #ffd45a,0 0 0 6px #12081f,0 7px 0 #0009;opacity:0;transform:scaleX(.5) scaleY(.9);transition:opacity .18s,transform .42s cubic-bezier(.3,1.5,.45,1);text-decoration:none}
.pz97pill::after{content:'';position:absolute;inset:5px;border-radius:26px;border:2px dashed #ffffffa8}
.pz97ch.on u,.pz97ch.on i{opacity:0;transform:scale(.7)}.pz97ch.on .pz97pill{opacity:1;transform:none}.pz97ch.on b{transform:scale(1.22)}
.pz97ch.pzchip2.on{transform:none;box-shadow:none}.pz97ch.pzchip2.pop{animation:none}.pz97ch.pzchip2:hover:not(:disabled):not(.on){transform:translateY(-5px) rotate(-8deg)}.pz97ch.pzchip2.on:hover{transform:translateY(-2px)}.pz97ch:active:not(:disabled){transform:scale(.94)}
.pz97ch.pop .pz97pill{animation:pz97pillpop .5s cubic-bezier(.3,1.5,.45,1)}
.pz97ch:disabled{cursor:default;opacity:.3}.pz97chips.off .pz97ch{opacity:.35}
.pz97chips.many .pz97ch.pzchip2{width:54px;height:54px}.pz97chips.many .pz97pill{width:96px;height:56px;margin-left:-48px;border-radius:28px}.pz97chips.many .pz97ch b{font-size:13.5px}
.pz97sep{flex:none;width:2px;height:60px;background:#4a3e90;border-radius:2px}
.pz97num{flex:none;width:104px;text-align:center}.pz97num small{display:block;font:600 13px Poppins,sans-serif;color:#c4badf}.pz97num b{display:block;margin-top:1px;font:400 34px/1 "Pirata One",serif;color:#ffd45a;white-space:nowrap}.pz97num.g b{color:#8affb4}.pz97num em{display:block;min-height:15px;font:600 11.5px Poppins,sans-serif;font-style:normal;color:#9a90c8;white-space:nowrap}
.pzh97 .pz97play.pzrackem{position:relative;left:auto;top:auto;flex:none;min-width:0;letter-spacing:normal;width:340px;height:80px;padding:0 14px;border-radius:20px;display:flex;align-items:center;justify-content:center;overflow:hidden;animation:pzrkb 2.6s ease-in-out 1.6s infinite;box-shadow:0 7px 0 #9a6a10,0 12px 24px #000a}
.pz97pt{display:inline-flex;align-items:baseline;justify-content:center;gap:12px;font:400 44px/1 "Pirata One",Georgia,serif;color:#2a1a04;white-space:nowrap;overflow:hidden}.pz97pt i{font-style:normal;opacity:.7}
.pz97play kbd{position:absolute;right:9px;top:7px;background:#2a1a04!important;color:#ffe27a!important;border-color:#2a1a04!important;font-size:9.5px!important;line-height:16px!important;opacity:.75}
.pzh97 .pz97play:hover{animation:none;transform:translateY(-3px) scale(1.015)}.pzh97 .pz97play:active{transform:translateY(5px)}
.pz97play.alt{background:linear-gradient(180deg,#d8f8a8,#8ad86a)}
.pzh97 .pz97prac.pzprac{position:relative;left:auto;top:auto;flex:none;width:156px;height:70px;min-width:0;padding:0 6px;white-space:nowrap;border-radius:18px;box-shadow:0 6px 0 #0a0620,0 10px 22px #000a}
.pzh97 .pz97prac b{margin-top:0;font-size:20px}.pzh97 .pz97prac span{font-size:12.5px;font-weight:700}.pzh97 .pz97prac kbd{right:7px;top:6px;font-size:9.5px;line-height:16px;min-width:12px}
.pzh97 .pz97res{left:340px;top:770px;width:620px;z-index:5}
.pzh97.pzin .pz97tbc{animation:pz97tbIn .6s .1s cubic-bezier(.25,1.4,.45,1) both}
.pzh97.pzin .pz97lamp{animation:pz97lampIn 1.1s .05s cubic-bezier(.25,1.2,.45,1) both,pz97swing 5.2s ease-in-out 1.15s infinite}
.pzh97.pzin .pz97md.pzrow{animation:pz97mdIn .5s calc(.28s + var(--i)*.06s) cubic-bezier(.25,1.6,.45,1) both}
.pzh97.pzin .pz97champ{animation:pzpopIn .45s .8s cubic-bezier(.25,1.6,.45,1) both}
.pzh97.pzin .pz97bar{animation:pz97barIn .55s .2s cubic-bezier(.25,1.3,.45,1) both}
.pzh97.pzin .pz97ch{animation:pzpopIn .4s calc(.42s + var(--j)*.05s) cubic-bezier(.25,1.7,.45,1) both}
.pzh97.pzin .pz97play{animation:pzpopIn .45s .55s cubic-bezier(.25,1.6,.45,1) both,pzrkb 2.6s ease-in-out 1.6s infinite}
.pzh97.pzin .pz97prac{animation:pzpopIn .45s .62s cubic-bezier(.25,1.6,.45,1) both}
.pzh97.pzin .pz97opp{animation:pzfromR .5s .12s cubic-bezier(.25,1.25,.45,1) both}
.pzh97.pzin .pz97tw{animation:pzfade .8s .2s both}
.pzh97.rm *,.pzh97.rm>canvas.pz97tw{animation:none!important}
@keyframes pz97tw{0%,100%{opacity:.15}50%{opacity:1}}
@keyframes pz97swing{0%,100%{transform:rotate(1.1deg)}50%{transform:rotate(-1.1deg)}}
@keyframes pz97glow{0%,100%{opacity:.86}50%{opacity:1}}
@keyframes pz97lampIn{0%{opacity:0;transform:translateY(-140px) rotate(9deg)}45%{opacity:1;transform:translateY(8px) rotate(-5deg)}70%{transform:translateY(-3px) rotate(3deg)}88%{transform:rotate(-1.6deg)}100%{transform:rotate(1.1deg)}}
@keyframes pz97tbIn{from{opacity:0;transform:translateY(34px) scale(.9)}to{opacity:1;transform:none}}
@keyframes pz97mdIn{from{opacity:0;transform:scale(.3) translateY(20px)}to{opacity:1;transform:none}}
@keyframes pz97barIn{from{opacity:0;transform:translateY(70px)}to{opacity:1;transform:none}}
@keyframes pz97bob{0%,100%{transform:none}50%{transform:translateY(-6px)}}
@keyframes pz97halo{0%{opacity:.85;transform:scale(1)}100%{opacity:0;transform:scale(1.22)}}
@keyframes pz97pillpop{0%{transform:scaleX(.5) scaleY(.9)}60%{transform:scaleX(1.08) scaleY(1.04)}100%{transform:none}}
`;document.head.appendChild(st)}
