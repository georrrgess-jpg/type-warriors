/* ===== RUNESTONE RAMPARTS: the eight monsters =====
   Drawn in code like the rest of the game: chunky #12081f outlines, cel-shaded gradients lit from the upper left, white highlight
   strokes, glows made with 'lighter' radial gradients (never shadowBlur or ctx.filter).
   API
   - RPMOB[id] = {n, h, air, desc, w (body width in units), lift (air units: drawn this many units above the feet point), boss}
   - rpMobDraw(g,id,ph,o): live draw, feet at (0,0), facing RIGHT, ph 0..1 = one walk / flap cycle.
   - rpMobBlit(c,id,x,y,ph,o): fast per-frame draw from baked sheets (8 frames, 2x supersampled), with a ground shadow.
       o = {s:scale=1, flip:false (true faces left), a:alpha=1, flash:0..1 white overlay, chill:0..1 icy overlay, rot:radians}.
       (x,y) is the feet / ground point; air units are drawn RPMOB.lift units higher with a faint shadow at y.
       rot turns the sprite about its body centre.
   - rpMobIcon(id,size): cached size x size portrait canvas, transparent background.
   - rpMobDeath(c,id,x,y,k,o): cheap death effect for progress k 0..1 (o = {s, flip, seed}).
   - rpMobPrebake(ids): bakes sheets ahead of time (rpMobBlit also bakes lazily on first use).
   Private helpers are prefixed rpm. */
const RPMO='#12081f',RPMT=Math.PI*2;
const RPMOB={
 scamp:{n:'Moss Scamp',h:46,air:false,w:26,desc:'Tiny and quick; darts past slow towers.'},
 bulwark:{n:'Bone Bulwark',h:62,air:false,w:34,desc:'Hides behind a rune shield and marches in squads.'},
 golem:{n:'Rune Golem',h:92,air:false,w:70,desc:'Slow, huge and armored in carved stone.'},
 gloom:{n:'Gloomwing',h:44,air:true,lift:38,w:46,desc:'Flies over the path; only some towers can reach it.'},
 ooze:{n:'Bramble Ooze',h:58,air:false,w:60,desc:'A thorny slime that splits in two when it pops.'},
 oozelet:{n:'Oozelet',h:30,air:false,w:30,desc:'A small, bouncy piece of a Bramble Ooze.'},
 shaman:{n:'Hex Shaman',h:64,air:false,w:36,desc:'Its glowing totem heals nearby monsters.'},
 behemoth:{n:'Basalt Behemoth',h:150,air:false,boss:true,w:200,desc:'Boss: a lava-cracked beast hauling a siege ram.'}
};
/* ---------- drawing helpers ---------- */
function rpmRGB(h){const n=parseInt(h.slice(1,7),16);return[n>>16,n>>8&255,n&255]}
function rpmSh(h,k){const c=rpmRGB(h),t=k<0?[26,12,44]:[255,251,236],p=Math.abs(k);return'rgb('+Math.round(c[0]+(t[0]-c[0])*p)+','+Math.round(c[1]+(t[1]-c[1])*p)+','+Math.round(c[2]+(t[2]-c[2])*p)+')'}
function rpmA(h,a){const c=rpmRGB(h);return'rgba('+c[0]+','+c[1]+','+c[2]+','+a+')'}
function rpmP(g,p){g.beginPath();g.moveTo(p[0],p[1]);for(let i=2;i<p.length;i+=2)g.lineTo(p[i],p[i+1]);g.closePath()}
function rpmBl(g,p){const n=p.length>>1,X=i=>p[(i%n)*2],Y=i=>p[(i%n)*2+1];g.beginPath();g.moveTo((X(n-1)+X(0))/2,(Y(n-1)+Y(0))/2);for(let i=0;i<n;i++)g.quadraticCurveTo(X(i),Y(i),(X(i)+X(i+1))/2,(Y(i)+Y(i+1))/2);g.closePath()}
function rpmFS(g,f,lw){g.fillStyle=f;g.fill();if(lw!==0){g.lineWidth=lw||2.4;g.strokeStyle=RPMO;g.stroke()}}
function rpmLG(g,x0,y0,x1,y1,s){const q=g.createLinearGradient(x0,y0,x1,y1);for(let i=0;i<s.length;i+=2)q.addColorStop(s[i],s[i+1]);return q}
function rpmRG(g,x,y,r,s,x0,y0){const q=g.createRadialGradient(x0==null?x:x0,y0==null?y:y0,0,x,y,r);for(let i=0;i<s.length;i+=2)q.addColorStop(s[i],s[i+1]);return q}
/* cel shading: light upper left, the base colour, then a crisp darker lower-right half */
function rpmCel(g,x0,y0,x1,y1,b,k){k=k||.58;return rpmLG(g,x0,y0,x1,y1,[0,rpmSh(b,.32),.36,b,k-.03,b,k+.03,rpmSh(b,-.24),1,rpmSh(b,-.42)])}
function rpmEl(g,x,y,rx,ry,f,lw,r){g.beginPath();g.ellipse(x,y,Math.max(.1,rx),Math.max(.1,ry),r||0,0,RPMT);rpmFS(g,f,lw)}
function rpmLimb(g,p,w,col,ol){g.lineCap='round';g.lineJoin='round';g.beginPath();g.moveTo(p[0],p[1]);for(let i=2;i<p.length;i+=2)g.lineTo(p[i],p[i+1]);if(ol!==0){g.lineWidth=w+(ol||2.2)*2;g.strokeStyle=RPMO;g.stroke()}g.lineWidth=w;g.strokeStyle=col;g.stroke()}
function rpmGlow(g,x,y,r,col,a){if(r<=0)return;a=a==null?.8:a;g.save();g.globalCompositeOperation='lighter';g.fillStyle=rpmRG(g,x,y,r,[0,rpmA(col,a),.35,rpmA(col,a*.42),1,rpmA(col,0)]);g.beginPath();g.arc(x,y,r,0,RPMT);g.fill();g.restore()}
function rpmHi(g,a,w){g.lineWidth=w||1.6;g.strokeStyle='rgba(255,255,255,'+(a==null?.55:a)+')';g.lineCap='round';g.stroke()}
function rpmAH(g,x,y,rx,ry,a0,a1,a,w,rot){g.beginPath();g.ellipse(x,y,rx,ry,rot||0,a0,a1);rpmHi(g,a,w)}
/* knee from hip, foot and limb length; dir -1 bends forward (+x), 1 bends back */
function rpmKnee(hx,hy,fx,fy,l,dir){const mx=(hx+fx)/2,my=(hy+fy)/2,dx=fx-hx,dy=fy-hy,d=Math.hypot(dx,dy)||1,h=Math.sqrt(Math.max(0,l*l/4-d*d/4));return[mx-dy/d*h*dir,my+dx/d*h*dir]}
/* a big cartoon eye: sclera, iris, pupil, an angry lid (ang>0 lowers the front corner), glint */
function rpmEye(g,x,y,r,iris,lid,ang){g.save();g.beginPath();g.ellipse(x,y,r,r*1.08,0,0,RPMT);g.fillStyle='#fffcee';g.fill();g.clip();
 rpmEl(g,x+r*.3,y+r*.1,r*.64,r*.7,iris,0);rpmEl(g,x+r*.4,y+r*.14,r*.32,r*.38,RPMO,0);
 if(lid){g.fillStyle=lid;g.beginPath();g.moveTo(x-r*1.4,y-r*1.5);g.lineTo(x+r*1.4,y-r*1.5);g.lineTo(x+r*1.4,y-r*(.5-ang));g.lineTo(x-r*1.4,y-r*(.5+ang));g.closePath();g.fill()}
 g.restore();g.beginPath();g.ellipse(x,y,r,r*1.08,0,0,RPMT);g.lineWidth=Math.max(1.1,r*.36);g.strokeStyle=RPMO;g.stroke();
 if(lid){g.beginPath();g.moveTo(x-r*1.15,y-r*(.5+ang*.9));g.lineTo(x+r*1.15,y-r*(.5-ang*.9));g.lineWidth=Math.max(1.2,r*.42);g.stroke()}
 rpmEl(g,x+r*.05,y-r*.22,r*.22,r*.22,'#fff',0)}
/* a glowing eye: soft halo, hot core */
function rpmGEye(g,x,y,r,col,ry){rpmGlow(g,x,y,r*3.6,col,.75);rpmEl(g,x,y,r,ry||r,col,0);rpmEl(g,x-r*.15,y-(ry||r)*.15,r*.5,(ry||r)*.5,'#fffde8',0)}
function rpmRn(i){const x=Math.sin(i*91.7+17.3)*43758.5453;return x-Math.floor(x)}
/* an angular rock or plate: cel-shaded fill, outline, and a light rim on the edges that face the upper left */
function rpmRock(g,p,b,lw,k,hi){const n=p.length>>1;let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9,A=0;
 for(let i=0;i<n;i++){const x=p[i*2],y=p[i*2+1],xn=p[((i+1)%n)*2],yn=p[((i+1)%n)*2+1];A+=x*yn-xn*y;if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y}
 rpmP(g,p);rpmFS(g,rpmCel(g,x0,y0,x1,y1,b,k),lw);if(hi===0)return;
 const sg=A>0?1:-1,d=(lw||2.4)*.5+1.3;g.beginPath();
 for(let i=0;i<n;i++){const xa=p[i*2],ya=p[i*2+1],xb=p[((i+1)%n)*2],yb=p[((i+1)%n)*2+1],dx=xb-xa,dy=yb-ya,L=Math.hypot(dx,dy)||1,nx=dy/L*sg,ny=-dx/L*sg;
  if(-.6*nx-.8*ny>.35){g.moveTo(xa-nx*d+dx*.14,ya-ny*d+dy*.14);g.lineTo(xb-nx*d-dx*.14,yb-ny*d-dy*.14)}}
 rpmHi(g,hi||.38,1.3)}
/* a tapered glowing crack along a polyline (magma under rock) */
function rpmFiss(g,p,w,c1,c2){const n=p.length>>1,L=[],R=[];
 for(let i=0;i<n;i++){const a=Math.max(0,i-1),b=Math.min(n-1,i+1);let dx=p[b*2]-p[a*2],dy=p[b*2+1]-p[a*2+1];const d=Math.hypot(dx,dy)||1;dx/=d;dy/=d;
  const ww=w*.5*(.22+.78*Math.sin(Math.PI*i/(n-1)));L.push(p[i*2]-dy*ww,p[i*2+1]+dx*ww);R.unshift(p[i*2]+dy*ww,p[i*2+1]-dx*ww)}
 rpmP(g,L.concat(R));g.fillStyle=c1;g.fill();g.lineWidth=1.6;g.strokeStyle='#1a0610';g.stroke();
 g.beginPath();g.moveTo(p[2],p[3]);for(let i=2;i<n*2-2;i+=2)g.lineTo(p[i],p[i+1]);g.lineWidth=Math.max(.8,w*.24);g.strokeStyle=c2;g.stroke()}
const RPMD={};

/* ---------- 1. Moss Scamp: a tiny goblin runner under a toadstool cap ---------- */
RPMD.scamp=function(g,ph){const a=ph*RPMT,s=Math.sin(a),by=-Math.abs(s)*3,SK='#8fd046',SKD='#5c9a30',SKK='#3e7024';
 const leg=(p,col,dk)=>{const fx=2+10*Math.sin(p),fy=-Math.max(0,Math.cos(p))*6,hx=1,hy=-13+by,k=rpmKnee(hx,hy,fx,fy-1.5,17,-1);
  rpmLimb(g,[hx,hy,k[0],k[1],fx,fy-1.5],4,col);
  g.save();g.translate(fx,fy-1.2);g.rotate(Math.cos(p)*-.3);g.beginPath();g.moveTo(-3.4,-2.4);g.quadraticCurveTo(3,-4.4,8.6,-.6);g.quadraticCurveTo(3,1.8,-3.4,1.2);g.closePath();rpmFS(g,dk,1.8);g.restore()};
 leg(a+Math.PI,SKD,SKK);
 /* far arm */
 rpmLimb(g,[2,-21+by,-1+5*s,-16.5+by,1+8*s,-13+by],3.4,SKD);rpmEl(g,1+8*s,-13+by,2.2,2.2,SKD,1.6);
 leg(a,SK,'#4f8a2a');
 /* torso leaning into the run */
 g.save();g.translate(3,-19+by);g.rotate(.32);rpmEl(g,0,0,7,8.6,rpmCel(g,-7,-8,7,8,SK),2.2);rpmEl(g,2,2.2,3.6,4.6,'rgba(236,255,170,.45)',0);g.restore();
 /* leaf skirt */
 for(let i=0;i<4;i++){const x=-5+i*3.6,r=.55-i*.3+s*.14;g.save();g.translate(x,-13+by);g.rotate(r);g.beginPath();g.moveTo(-2.5,0);g.quadraticCurveTo(-3,5,0,8.6);g.quadraticCurveTo(3,5,2.5,0);g.closePath();rpmFS(g,i%2?'#3c7a2c':'#5aa53c',1.5);g.beginPath();g.moveTo(0,1);g.lineTo(0,6.4);g.lineWidth=.8;g.strokeStyle='rgba(18,8,31,.45)';g.stroke();g.restore()}
 g.beginPath();g.moveTo(-6,-14.5+by);g.quadraticCurveTo(2,-12+by,9,-15.5+by);g.lineWidth=4.4;g.strokeStyle=RPMO;g.stroke();g.lineWidth=2.2;g.strokeStyle='#8a5a2c';g.stroke();
 /* head */
 const hx=8,hy=-27.6+by,ew=Math.sin(a*2)*1.6;
 g.beginPath();g.moveTo(3,-33+by);g.quadraticCurveTo(-8,-39+by+ew,-15,-40+by+ew);g.quadraticCurveTo(-6,-31+by,2,-27+by);g.closePath();rpmFS(g,SKD,1.8);
 g.beginPath();g.arc(hx,hy,9,0,RPMT);rpmFS(g,rpmRG(g,hx+1,hy+1,12,[0,rpmSh(SK,.38),.45,SK,.8,SKD,1,SKK],hx-3,hy-4),2.3);
 g.beginPath();g.moveTo(2,-30.5+by);g.quadraticCurveTo(-9,-34+by-ew,-17.5,-33+by-ew);g.quadraticCurveTo(-7,-26+by,2,-24.5+by);g.closePath();rpmFS(g,rpmLG(g,2,-30,-16,-34,[0,SK,1,SKD]),1.8);
 g.beginPath();g.moveTo(0,-29+by);g.quadraticCurveTo(-7,-31.5+by-ew,-13.5,-32.4+by-ew);g.quadraticCurveTo(-6,-27.6+by,0,-26.6+by);g.closePath();g.fillStyle='#e98a7a';g.fill();
 rpmEye(g,hx+2.8,hy+.4,3.9,'#ffcf2a','#3f7a24',.36);rpmEye(g,hx+8,hy,2.7,'#ffcf2a','#3f7a24',-.3);
 g.beginPath();g.moveTo(hx+8,hy+1.8);g.quadraticCurveTo(hx+13.6,hy+2.6,hx+13.2,hy+4.6);g.quadraticCurveTo(hx+10,hy+5.2,hx+7.2,hy+4.4);g.closePath();rpmFS(g,SK,1.5);
 g.beginPath();g.moveTo(hx+1,hy+5.2);g.quadraticCurveTo(hx+5,hy+7.8,hx+9.4,hy+6.2);g.lineWidth=1.6;g.strokeStyle=RPMO;g.stroke();
 rpmP(g,[hx+3.2,hy+6.4,hx+4.8,hy+6.7,hx+4,hy+8.6]);rpmFS(g,'#fffbe8',.8);
 /* toadstool cap with moss on the rim */
 g.save();g.translate(hx-1.4,hy-8.6);g.rotate(-.2+s*.04);g.scale(.88,.88);
 g.beginPath();g.moveTo(-15,1.6);g.bezierCurveTo(-15.6,-8,-8,-14,1,-14);g.bezierCurveTo(10,-14,17,-8,16.6,1.6);g.quadraticCurveTo(1,5.6,-15,1.6);g.closePath();
 rpmFS(g,rpmRG(g,0,-4,22,[0,'#ff8a5e',.4,'#e2442e',.75,'#b02a2a',1,'#7a1626'],-6,-10),2.4);
 g.beginPath();g.moveTo(-13.5,2.2);g.quadraticCurveTo(1,6.2,15,2.2);g.quadraticCurveTo(1,3.4,-13.5,2.2);g.fillStyle='#f6e2b8';g.fill();
 for(const [x,y,r] of[[-8,-6,2.6],[0,-10.4,2],[7.4,-6.4,2.9],[13,-1.6,1.6],[-12.4,-1.2,1.5],[1.6,-3,1.4]])rpmEl(g,x,y,r,r*.8,'#fff3da',1.1);
 for(const [x,y,r] of[[-13,1.2,3.4],[-8.4,3.2,2.6],[10.6,3,3],[15,.8,2.5],[-2,4,2]]){g.beginPath();for(let j=0;j<10;j++){const t2=j/10*RPMT+x,rr=j%2?r*.55:r;j?g.lineTo(x+Math.cos(t2)*rr,y+Math.sin(t2)*rr*.8):g.moveTo(x+Math.cos(t2)*rr,y+Math.sin(t2)*rr*.8)}g.closePath();rpmFS(g,'#72c040',1.1);rpmEl(g,x-r*.25,y-r*.25,r*.38,r*.28,'#c4f27a',0)}
 rpmAH(g,0,-1,13,11.5,3.55,4.5,.6,1.7);
 /* a sprout on top */
 g.beginPath();g.moveTo(2,-13.6);g.quadraticCurveTo(1,-18,4,-19.5);g.lineWidth=3.4;g.strokeStyle=RPMO;g.stroke();g.lineWidth=1.4;g.strokeStyle='#7cc843';g.stroke();
 g.beginPath();g.moveTo(4,-19.5);g.quadraticCurveTo(9,-22,10,-18.4);g.quadraticCurveTo(6,-17,4,-19.5);rpmFS(g,'#9ad84e',1.2);
 g.restore();
 /* near arm with a thorn knife */
 const ax=7-7*s,ay=-15+by+Math.max(0,s)*2;
 rpmLimb(g,[4,-22+by,4.5-3*s,-17.5+by,ax,ay],3.6,SK);
 g.save();g.translate(ax,ay);g.rotate(-.75-s*.3);g.beginPath();g.moveTo(-1.5,.5);g.quadraticCurveTo(-1.8,-6,2.6,-11.5);g.quadraticCurveTo(1.6,-5,1.5,.5);g.closePath();rpmFS(g,rpmLG(g,-2,0,2,0,[0,'#fffbe8',1,'#c9b48a']),1.4);g.restore();
 rpmEl(g,ax,ay,2.3,2.3,SK,1.6)};

/* ---------- 2. Bone Bulwark: a skeleton behind a tall rune tower shield ---------- */
RPMD.bulwark=function(g,ph){const a=ph*RPMT,s=Math.sin(a),by=-Math.abs(Math.cos(a))*1.8,BN='#efe3c2',BND='#b8a27a',TL='#3ff2d2';
 const sb=by*.8+Math.sin(a*2+.6)*.5;
 /* sword arm, behind */
 const hx=-12,hy=-45+by+s*.8;rpmLimb(g,[-6,-41+by,-14,-36+by,hx,hy],2.8,BND);
 g.save();g.translate(hx,hy);g.rotate(-.62+s*.05);
 rpmP(g,[-1.7,-2,-2.4,-21,0,-25,2.4,-21,1.7,-2]);rpmFS(g,rpmLG(g,-2,0,2,0,[0,'#dfe6ee',.5,'#a9b3c2',.52,'#7d8798',1,'#646d7d']),1.6);
 rpmP(g,[1.2,-8,2.6,-10,2.2,-12.6,1.2,-12]);g.fillStyle=RPMO;g.fill();
 g.beginPath();g.moveTo(-.4,-4);g.lineTo(-.6,-19);rpmHi(g,.55,.8);
 rpmP(g,[-5,-1.8,5,-1.8,5,.8,-5,.8]);rpmFS(g,'#8a5a2c',1.4);rpmP(g,[-1.4,.8,1.4,.8,1.4,5,-1.4,5]);rpmFS(g,'#5a3a22',1.2);g.restore();
 rpmEl(g,hx,hy,2,2,BND,1.4);
 const hip=[-3,-25+by];
 const leg=(p,col)=>{const fx=-3+8*Math.sin(p),fy=-Math.max(0,Math.cos(p))*4.5,k=rpmKnee(hip[0],hip[1],fx,fy-2,27,-1);
  rpmLimb(g,[hip[0],hip[1],k[0],k[1],fx,fy-2],3.2,col);rpmEl(g,k[0],k[1],2.3,2.3,col,1.5);
  g.save();g.translate(fx,fy);rpmP(g,[-3,-3.6,2.6,-3.6,7,-1.4,7,0,-3.6,0]);rpmFS(g,col,1.6);g.restore()};
 leg(a+Math.PI,BND);
 /* spine, ribs, pelvis */
 rpmLimb(g,[-3,-26+by,-2.4,-36+by,-1.2,-45+by],3,BND);
 for(let i=0;i<4;i++){const y=-42.5+i*3.7+by,r=7.4-i*.9;g.beginPath();g.ellipse(-2.4,y,r,2.1,0,Math.PI*.95,Math.PI*2.05);g.lineWidth=4.2;g.strokeStyle=RPMO;g.stroke();g.lineWidth=2;g.strokeStyle=i?BN:rpmSh(BN,.2);g.stroke()}
 rpmP(g,[-8.6,-28.4+by,2.4,-28.4+by,1.6,-23.4+by,-3,-21.2+by,-7.6,-23.4+by]);rpmFS(g,rpmCel(g,-8,-29+by,2,-21+by,BN),1.8);
 leg(a,BN);
 /* iron pauldron on the far shoulder */
 rpmEl(g,-6,-43+by,5.4,3.6,rpmCel(g,-11,-47+by,-1,-39+by,'#7a8494'),1.8,-.3);
 /* skull */
 const kx=1.6,ky=-52.6+by;
 rpmP(g,[kx-1,ky+3,kx+9.6,ky+2,kx+10,ky+6.6,kx+.6,ky+7]);rpmFS(g,rpmSh(BN,-.12),1.8);
 g.fillStyle=RPMO;for(let i=0;i<4;i++)g.fillRect(kx+2+i*2.1,ky+3,.8,3.4);
 rpmEl(g,kx+1,ky-.6,8,7.2,rpmRG(g,kx+1,ky,10,[0,'#fffaea',.5,BN,1,BND],kx-3,ky-4),2.2);
 rpmEl(g,kx+4.2,ky,2.5,2.7,'#1a1024',0);rpmEl(g,kx+8.4,ky-.3,1.7,2.3,'#1a1024',0);
 rpmGEye(g,kx+4.5,ky+.2,1.1,TL);rpmGEye(g,kx+8.5,ky,.8,TL);
 rpmP(g,[kx+6.4,ky+2.2,kx+7.6,ky+2.2,kx+7,ky+3.8]);g.fillStyle='#1a1024';g.fill();
 /* kettle helmet with a teal tassel */
 const tw=Math.sin(a*2)*1.2;
 g.beginPath();g.moveTo(kx-.6,ky-9.6);g.quadraticCurveTo(kx-5,ky-14+tw,kx-9.6,ky-12+tw);g.quadraticCurveTo(kx-6,ky-10.6,kx-.6,ky-8);rpmFS(g,rpmLG(g,kx,ky-10,kx-9,ky-12,[0,'#7ffff0',1,'#1aa79a']),1.4);
 g.beginPath();g.ellipse(kx+.4,ky-3.6,8.6,7.2,0,Math.PI,RPMT);g.closePath();rpmFS(g,rpmCel(g,kx-8,ky-11,kx+8,ky-2,'#7a8494'),2);
 rpmEl(g,kx+1,ky-3.4,12.6,2.6,rpmLG(g,kx-12,0,kx+13,0,[0,'#a7b0be',.6,'#6b7484',1,'#4a5160']),1.9);
 for(const x of[-4,1,6])rpmEl(g,kx+x,ky-6.4,.9,.9,'#c9d2de',0);
 rpmAH(g,kx-1,ky-4.6,6,5,3.5,4.4,.6,1.2);
 /* tower shield */
 g.save();g.translate(2,sb+2.4);
 const SH=()=>{g.beginPath();g.moveTo(5,-44);g.quadraticCurveTo(5,-50.5,17,-51.5);g.quadraticCurveTo(29,-50.5,29,-44);g.lineTo(29,-16);g.quadraticCurveTo(28,-7,17,-2);g.quadraticCurveTo(6,-7,5,-16);g.closePath()};
 g.save();g.translate(-2.6,.6);SH();rpmFS(g,'#2c2f3c',2.2);g.restore();
 SH();rpmFS(g,rpmLG(g,5,-50,29,-4,[0,'#c9d2de',.4,'#8a94a6',.62,'#5e6778',1,'#3e4452']),2.4);
 g.save();g.translate(17,-26);g.scale(.8,.86);g.translate(-17,26);SH();g.restore();
 g.fillStyle=rpmLG(g,6,-48,28,-6,[0,'#3f6a74',.55,'#2a4652',.6,'#22394a',1,'#162636']);g.fill();g.lineWidth=1.6;g.strokeStyle=RPMO;g.stroke();
 /* scratches and rivets */
 g.beginPath();g.moveTo(9,-40);g.lineTo(13,-36);g.moveTo(22,-14);g.lineTo(25,-18);g.lineWidth=.9;g.strokeStyle='rgba(160,220,230,.35)';g.stroke();
 for(const [x,y] of[[8,-46],[17,-48.6],[26,-46],[27,-31],[27,-17],[7,-17],[7,-31],[17,-5.6]]){rpmEl(g,x,y,1.3,1.3,'#d9e0ea',.9)}
 /* the rune */
 const pu=.75+.25*Math.sin(a);rpmGlow(g,17,-27,15,TL,.5*pu);
 const R=()=>{g.beginPath();g.moveTo(17,-39);g.lineTo(17,-14);g.moveTo(17,-33);g.lineTo(11.5,-38);g.moveTo(17,-33);g.lineTo(22.5,-38);g.moveTo(17,-21);g.lineTo(11.5,-15.5);g.moveTo(17,-21);g.lineTo(22.5,-15.5);g.moveTo(13,-27);g.lineTo(21,-27)};
 R();g.lineCap='round';g.lineWidth=3.6;g.strokeStyle='#0e3a3a';g.stroke();R();g.lineWidth=2;g.strokeStyle=TL;g.stroke();R();g.lineWidth=.8;g.strokeStyle='#eafffb';g.stroke();
 g.beginPath();g.moveTo(7,-43);g.quadraticCurveTo(8,-49,17,-49.6);rpmHi(g,.7,1.4);
 g.restore();
 /* bony fingers over the shield edge */
 for(let i=0;i<3;i++)rpmEl(g,7.4,-31+i*2.5+sb,1.9,1.15,BN,1.1)};

/* ---------- 3. Rune Golem: armored stone slabs, amber chest rune, cyan eyes ---------- */
RPMD.golem=function(g,ph){const a=ph*RPMT,s=Math.sin(a),by=-Math.abs(s)*2.4,tl=s*.028,ST='#8a94ac',STD='#5a6279',IR='#5c6070',AM='#ffb02e',CY='#5ff4ff';
 const pu=.8+.2*Math.sin(a*2),UP=()=>{g.translate(0,-30);g.rotate(tl);g.translate(0,30+by)};
 const T=(p,dx,dy)=>p.map((v,i)=>v+(i%2?dy:dx));
 const leg=(bx,p,col)=>{const fx=bx+6*Math.sin(p),l=Math.max(0,Math.cos(p))*6;
  rpmRock(g,[bx-10,-38+by,bx+10,-38+by,fx+9,-13-l,fx-9,-13-l],col,2.4);
  rpmRock(g,[fx-12,-16-l,fx+7,-17-l,fx+14,-8-l,fx+14,-l,fx-12,-l],col,2.4);
  g.beginPath();g.moveTo(fx+5,-6-l);g.lineTo(fx+5,-l);g.moveTo(fx+9.6,-6.6-l);g.lineTo(fx+9.6,-l);g.lineWidth=1.3;g.strokeStyle=RPMO;g.stroke()};
 /* far arm, swinging opposite the near one */
 const fs=-7*s;
 g.save();UP();
 rpmRock(g,[-28,-74,-12,-74,-16+fs*.3,-50,-31+fs*.3,-50],STD,2.4,0,0);
 rpmRock(g,[-33+fs*.4,-54,-15+fs*.4,-54,-13+fs,-32,-37+fs,-30],STD,2.4,0,0);
 rpmRock(g,T([-12,-6,12,-6,15,6,10,15,-10,15,-15,6],-25+fs,-24),STD,2.4,0,0);
 g.restore();
 leg(-11,a+Math.PI,STD);leg(10,a,'#7d87a0');
 g.save();UP();
 /* iron waist plate */
 rpmRock(g,[-24,-44,24,-46,27,-30,14,-24,-14,-24,-26,-30],IR,2.4);
 for(const x of[-18,-6,6,18])rpmEl(g,x,-34-x*.03,1.2,1.2,'#e0a85a',.8);
 /* torso: big carved slab */
 rpmRock(g,[-30,-52,-33,-70,-22,-86,0,-92,24,-88,38,-74,40,-56,30,-40,6,-34,-22,-36],ST,2.8,.56,.5);
 g.beginPath();g.moveTo(-26,-62);g.lineTo(-18,-56);g.lineTo(-21,-46);g.moveTo(-6,-40);g.lineTo(0,-46);g.lineTo(8,-44);g.moveTo(-14,-76);g.lineTo(-6,-70);g.lineWidth=1.4;g.strokeStyle=rpmA(RPMO,.7);g.stroke();
 /* moss over the back with hanging strands */
 rpmP(g,[-31,-70,-24,-84,-8,-91,4,-92,-2,-86,-14,-82,-24,-72]);rpmFS(g,rpmLG(g,0,-92,0,-70,[0,'#a6e066',1,'#4f8a34']),1.6);
 for(const [x,l] of[[-28,8],[-23,5],[-17,7]]){g.beginPath();g.moveTo(x,-74+(x+28)*-.6);g.quadraticCurveTo(x-1+s,-70+l*.5+(x+28)*-.6,x+s*1.5,-70+l+(x+28)*-.6);g.lineWidth=3.6;g.strokeStyle=RPMO;g.stroke();g.lineWidth=1.6;g.strokeStyle='#5c9a3a';g.stroke()}
 /* iron chest plate with the amber rune */
 rpmRock(g,[10,-74,34,-72,38,-54,28,-42,12,-46],IR,2.2,.5);
 for(const [x,y] of[[13,-71],[32,-69.6],[35,-55],[14,-49],[27,-45]])rpmEl(g,x,y,1.3,1.3,'#e0a85a',.9);
 rpmGlow(g,24,-58,18,AM,.55*pu);
 const RU=()=>{g.beginPath();g.moveTo(24,-68);g.lineTo(30,-58);g.lineTo(24,-48);g.lineTo(18,-58);g.closePath();g.moveTo(24,-68);g.lineTo(24,-48);g.moveTo(18,-58);g.lineTo(14.6,-63)};
 RU();g.lineWidth=3.8;g.strokeStyle='#5a2a08';g.stroke();RU();g.lineWidth=2;g.strokeStyle=AM;g.stroke();RU();g.lineWidth=.8;g.strokeStyle='#fff3c8';g.stroke();
 /* head jutting forward between the shoulders */
 const hb=Math.sin(a*2)*.6;
 rpmRock(g,T([20,-82,24,-94,34,-99,46,-96,53,-85,51,-72,41,-65,26,-67],0,hb),ST,2.4,.55);
 rpmRock(g,T([27,-73,50,-75,47,-64,38,-61,29,-63],0,hb),STD,2,0,0);
 g.beginPath();g.moveTo(31,-68.4+hb);g.lineTo(34.6,-67+hb);g.lineTo(38,-69.2+hb);g.lineTo(41.6,-67.2+hb);g.lineTo(46,-68.6+hb);g.lineWidth=1.6;g.strokeStyle=RPMO;g.stroke();
 rpmP(g,T([29,-85,38.5,-83,37.4,-77,30,-78],0,hb));g.fillStyle='#141024';g.fill();rpmP(g,T([41.5,-83,50,-85.6,49,-78.4,42.4,-77],0,hb));g.fill();
 rpmGEye(g,34,-80+hb,2.6,CY,1.6);rpmGEye(g,45.4,-80.6+hb,2,CY,1.5);
 rpmRock(g,T([22,-87,36,-85,40,-82.6,44,-85.6,54,-89,52,-94,40,-89.6,24,-93],0,hb),'#76809a',2,.5);
 rpmGlow(g,38,-95+hb,7,AM,.5*pu);rpmP(g,T([38,-98,40,-95,38,-92,36,-95],0,hb));rpmFS(g,'#ffd27a',1);
 /* near shoulder boulder with a spiked iron pauldron */
 rpmRock(g,[-16,-74,-12,-88,4,-94,18,-86,20,-70,6,-62,-12,-64],ST,2.6,.55);
 rpmP(g,[-6,-88,-10,-100,0,-91]);rpmFS(g,'#a6aec0',1.6);rpmP(g,[4,-92,6,-104,12,-90]);rpmFS(g,'#a6aec0',1.6);
 rpmRock(g,[-16,-80,-2,-91,16,-88,22,-76,16,-72,0,-80,-14,-72],IR,2.2,.5);
 for(const [x,y] of[[-11,-78],[-2,-85],[8,-85],[17,-78]])rpmEl(g,x,y,1.2,1.2,'#e8b866',.8);
 /* near arm: thick forearm with a cyan rune and a huge fist */
 const sw=7*s;
 rpmRock(g,[-6,-72,8,-74,12+sw*.3,-58,6+sw*.3,-48,-4+sw*.3,-50,-9,-60],ST,2.4,.5);
 rpmRock(g,[-9+sw*.4,-56,6+sw*.4,-59,16+sw*.5,-53,22+sw,-35,12+sw,-28,-4+sw,-30,-9+sw*.7,-43],ST,2.4,.5);
 rpmRock(g,[-7+sw*.6,-49,15+sw*.6,-52,17.4+sw*.7,-45.6,-5+sw*.7,-43],IR,1.8,0,0);
 g.beginPath();g.moveTo(4+sw*.8,-40);g.lineTo(9+sw*.85,-37);g.lineTo(6+sw*.9,-33);g.lineWidth=1.8;g.strokeStyle=CY;g.stroke();rpmGlow(g,7+sw*.85,-37,8,CY,.5*pu);
 rpmRock(g,T([-13,-5,-4,-9,8,-8.6,15,-2,17,8,10,17,-7,17,-15,8],8+sw,-26),ST,2.6,.5);
 g.beginPath();g.moveTo(-2+sw,-33);g.lineTo(-1+sw,-26);g.moveTo(5+sw,-33);g.lineTo(6+sw,-26);g.moveTo(12+sw,-32);g.lineTo(13+sw,-25);g.lineWidth=1.3;g.strokeStyle=RPMO;g.stroke();
 g.beginPath();g.moveTo(-3+sw,-18);g.lineTo(12+sw,-17);g.lineWidth=1.8;g.strokeStyle=CY;g.stroke();rpmGlow(g,5+sw,-17.4,8,CY,.45*pu);
 g.restore()};

/* ---------- 4. Gloomwing: a hovering bat-moth with eye-spotted wings ---------- */
RPMD.gloom=function(g,ph){const a=ph*RPMT,e=Math.cos(a),by=-Math.sin(a)*2.6,cy=-20+by,P='#7b48d4',GE='#ffd84a',MG='#ff4fb8';
 const wing=(ang,sc,dk)=>{g.save();g.translate(-1,cy-4);g.rotate(ang);g.scale(sc,sc*(.78+.22*Math.abs(e)));
  const W=()=>{g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(-11,-18,-34,-22);g.quadraticCurveTo(-32,-15,-36,-9);g.quadraticCurveTo(-28,-9.4,-27,-3);g.quadraticCurveTo(-20,-4,-18.6,2.4);g.quadraticCurveTo(-22,9,-27,15);g.quadraticCurveTo(-15,13,-8,7.6);g.quadraticCurveTo(-3,6,0,4);g.closePath()};
  W();rpmFS(g,rpmRG(g,0,0,40,dk?[0,'#241048',.5,'#3d1f78',1,'#6c44b8']:[0,'#2e1460',.45,'#6a3cc4',.8,'#9c6cf0',1,'#c9a2ff']),2.2);
  g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(-11,-18,-34,-22);g.moveTo(0,0);g.lineTo(-36,-9);g.moveTo(0,0);g.lineTo(-27,-3);g.moveTo(0,1);g.lineTo(-26,14);g.lineWidth=1.3;g.strokeStyle=rpmA(RPMO,dk?.6:.75);g.stroke();
  if(!dk){g.beginPath();g.moveTo(-2,-2);g.quadraticCurveTo(-11,-17,-31,-21);rpmHi(g,.5,1.1)}
  rpmEl(g,-21,-10,4.6,3.8,dk?'#8a2a6a':MG,1.2,-.3);rpmEl(g,-21,-10,2.6,2.2,dk?'#a88a30':GE,0,-.3);rpmEl(g,-21.4,-10.2,1,1,RPMO,0);
  if(!dk)rpmGlow(g,-21,-10,9,MG,.4);
  rpmEl(g,-19,8,2.2,1.8,dk?'#6a2a5a':'#d24aa0',1);
  g.restore()};
 wing(e*.8+.3,.84,1);
 /* abdomen */
 g.save();g.translate(-8,cy+5);g.rotate(.55+e*.08);rpmEl(g,0,0,9.6,5.6,rpmCel(g,-9,-5,9,5,'#5a2a9a'),2);
 for(const x of[-4,0,4]){g.beginPath();g.moveTo(x,-5);g.quadraticCurveTo(x-1.4,0,x,5);g.lineWidth=1.5;g.strokeStyle='#2a1050';g.stroke()}g.restore();
 /* dangling legs */
 for(const [x,d] of[[-2,0],[2,.8],[5,1.6]]){const sw=Math.sin(a+d)*1.4;rpmLimb(g,[x,cy+6,x+1+sw,cy+11,x+2.4+sw,cy+13],1.4,'#3a1c60',1.2)}
 /* fluffy thorax */
 rpmBl(g,[-9,cy-2,-7,cy-8,-2,cy-10,5,cy-9,9,cy-3,8,cy+5,1,cy+8,-6,cy+6]);rpmFS(g,rpmCel(g,-8,cy-9,8,cy+7,'#6a3aa8'),2.2);
 wing(e*.8,1,0);
 /* fur collar */
 g.beginPath();for(let i=0;i<=7;i++){const t2=-1.3+i*.37,r=i%2?7.4:9.6;const x=4+Math.cos(t2)*r*.6,y=cy-1+Math.sin(t2)*r;i?g.lineTo(x,y):g.moveTo(x,y)}g.lineTo(2,cy+4);g.closePath();rpmFS(g,rpmLG(g,0,cy-8,6,cy+6,[0,'#fff1fb',1,'#cfa8e8']),1.6);
 /* head with bat ears, feathery antennae and glowing eyes */
 const hx=10,hy=cy-3;
 rpmP(g,[hx-4,hy-4,hx-6.4,hy-13,hx-.6,hy-6]);rpmFS(g,'#4a2286',1.6);
 for(const k of[0,1]){const x0=hx+1+k*2.4,y0=hy-6,cx=hx+3+k*3,cy2=hy-17,x1=hx+13+k*2.4,y1=hy-19+k*2.4,U=[],D=[],M=[];
  for(let j=0;j<=6;j++){const u=j/6,v=1-u,x=v*v*x0+2*v*u*cx+u*u*x1,y=v*v*y0+2*v*u*cy2+u*u*y1,tx=2*v*(cx-x0)+2*u*(x1-cx),ty=2*v*(cy2-y0)+2*u*(y1-cy2),d=Math.hypot(tx,ty)||1,nx=ty/d,ny=-tx/d,w=Math.pow(Math.sin(Math.PI*Math.min(.98,u*.92+.04)),.8);
   M.push(x,y);U.push(x-nx*3.2*w,y-ny*3.2*w);D.push(x+nx*1.2*w,y+ny*1.2*w)}
  const Dp=[];for(let j=6;j>=0;j--)Dp.push(D[j*2],D[j*2+1]);
  rpmP(g,U.concat(Dp));rpmFS(g,rpmLG(g,x0,y0,x1,y1,k?[0,'#c9a8f0',1,'#fff0ff']:[0,'#7a54b0',1,'#c4a2e8']),1.3);
  g.beginPath();for(let j=1;j<6;j++){g.moveTo(M[j*2],M[j*2+1]);g.lineTo((M[j*2]+U[j*2])/2+.4,(M[j*2+1]+U[j*2+1])/2-.4)}g.lineWidth=.7;g.strokeStyle=rpmA(RPMO,.5);g.stroke();
  g.beginPath();g.moveTo(M[0],M[1]);for(let j=1;j<=6;j++)g.lineTo(M[j*2],M[j*2+1]);g.lineWidth=.9;g.strokeStyle=k?'#6a3aa8':'#3a1c60';g.stroke()}
 rpmEl(g,hx,hy,7.8,7.2,rpmRG(g,hx+1,hy+1,10,[0,'#9a6ad8',.55,'#5a2a9a',1,'#36165e'],hx-2,hy-3),2.2);
 rpmP(g,[hx-1,hy-5,hx+1,hy-13.4,hx+4.4,hy-5.4]);rpmFS(g,'#6a3aa8',1.6);rpmP(g,[hx+.6,hy-6,hx+1.4,hy-10.6,hx+3,hy-6]);g.fillStyle='#e88ad0';g.fill();
 rpmEl(g,hx+3,hy-.2,3.8,3.4,'#1a0830',0);rpmEl(g,hx+7.4,hy-.6,2.4,2.9,'#1a0830',0);
 rpmGEye(g,hx+3.2,hy-.2,2.5,GE,2.3);rpmGEye(g,hx+7.5,hy-.6,1.7,GE,2)
 rpmP(g,[hx+3,hy+3,hx+4.2,hy+3,hx+3.6,hy+5.6]);rpmFS(g,'#fffbe8',.7);rpmP(g,[hx+5.4,hy+2.8,hx+6.4,hy+2.8,hx+5.9,hy+4.8]);rpmFS(g,'#fffbe8',.7)};

/* ---------- 5/6. Bramble Ooze and Oozelet ---------- */
function rpmOoze(g,ph,big){const a=ph*RPMT,q=Math.sin(a),S=big?1:.52,hop=big?0:-Math.max(0,Math.sin(a))*7,sq=big?q:(Math.cos(a)>.6?-(Math.cos(a)-.6)*1.6:Math.sin(a)*.5);
 const sx=1+.07*sq,sy=1-.08*sq,lean=Math.cos(a)*(big?2.6:1.6);
 const base=[-31,0,-33,-14,-28,-34,-13,-48,7,-50,24,-41,33,-22,33,-5,22,1.5,0,2.2,-18,1.5];
 const P=[];for(let i=0;i<base.length;i+=2){const w=Math.sin(a+i*.7)*.9,y=base[i+1];P.push((base[i]*sx+lean*(-y/50))*S+w*S*.6,(y*sy+(y<-4?w:0))*S+hop)}
 const TH=big?['#c8ffd6','#52e0aa','#1fae8e','#0f6e64']:['#d4ffe0','#62e8b0','#22b490','#127468'];
 const tx=(x,y)=>[(x*sx+lean*(-y/50))*S,y*sy*S+hop];
 /* thorns poking out of the silhouette (behind the body) */
 const thorn=(x,y,ang,l)=>{const p=tx(x,y);g.save();g.translate(p[0],p[1]);g.rotate(ang);rpmP(g,[-2.4*S,0,0,-l*S,2.4*S,0]);rpmFS(g,rpmLG(g,-2,0,2,0,[0,'#9a6a4a',1,'#4a2a20']),1.4);g.restore()};
 if(big){thorn(-20,-40,-.9,9);thorn(-4,-49,-.3,10);thorn(16,-46,.4,9);thorn(30,-28,1.1,8)}else{thorn(-6,-48,-.4,12);thorn(14,-46,.5,10)}
 rpmBl(g,P);g.save();g.globalAlpha=.94;rpmFS(g,rpmRG(g,-2*S,-20*S+hop,44*S,[0,TH[0],.28,TH[1],.62,TH[2],1,TH[3]],-12*S,-36*S+hop),0);g.restore();
 /* the trapped skull and bubbles, seen through the slime */
 if(big){g.save();g.globalAlpha=.7;g.translate(...tx(-13,-25));g.rotate(-.45+q*.08);g.scale(1.08,1.08);
  rpmEl(g,0,0,8,7.4,'#e8f0d8',1.6);rpmP(g,[-4,4,5,4,4.6,9,-3.4,9]);rpmFS(g,'#d0dcc0',1.4);
  rpmEl(g,-2.8,-.4,2.2,2.4,'#1a3a34',0);rpmEl(g,2.6,-.6,2.2,2.4,'#1a3a34',0);rpmP(g,[-.6,2,.6,2,0,3.6]);g.fillStyle='#1a3a34';g.fill();
  g.fillStyle='#1a3a34';for(let i=0;i<4;i++)g.fillRect(-2.6+i*1.7,4.3,.7,3.4);
  g.restore();
  g.save();g.globalAlpha=.55;g.translate(...tx(-22,-20));g.rotate(.8);rpmP(g,[-5,-1,5,-1,5,1,-5,1]);rpmFS(g,'#e8f0d8',1.2);g.restore()}
 for(let i=0;i<(big?4:2);i++){const u=(ph*(i%2?1:2)+i*.27)%1,bx=(big?[-20,4,18,-6]:[-8,6])[i],p=tx(bx+Math.sin(u*6+i)*2,-4-u*(big?38:20));g.globalAlpha=Math.sin(u*Math.PI)*.8;g.beginPath();g.arc(p[0],p[1],(1+((i*7)%3)*.6)*S*1.6,0,RPMT);g.lineWidth=1;g.strokeStyle='#e8fff4';g.stroke();g.globalAlpha=1}
 /* a glaze over the inside so the skull sits deep in the slime */
 if(big){rpmBl(g,P);g.fillStyle=rpmLG(g,0,-50*S+hop,0,0,[0,'rgba(120,255,200,.0)',.5,'rgba(40,190,160,.22)',1,'rgba(10,100,90,.42)']);g.fill()}
 rpmBl(g,P);g.lineWidth=2.6;g.strokeStyle=RPMO;g.stroke();
 /* brambles wrapped around the body */
 const vine=pts=>{g.beginPath();let p=tx(pts[0],pts[1]);g.moveTo(p[0],p[1]);for(let i=2;i<pts.length;i+=4){const c=tx(pts[i],pts[i+1]),d=tx(pts[i+2],pts[i+3]);g.quadraticCurveTo(c[0],c[1],d[0],d[1])}
  g.lineWidth=(big?3.4:2.8)+3.6;g.strokeStyle=RPMO;g.stroke();g.lineWidth=big?3.4:2.8;g.strokeStyle='#6a4a2e';g.stroke();g.lineWidth=1;g.strokeStyle='#a8784a';g.stroke()};
 if(big){vine([-31,-9,-16,-17,2,-12,18,-8,33,-15]);vine([-24,-36,-8,-40,4,-48]);}
 const spk=(x,y,ang)=>{const p=tx(x,y);g.save();g.translate(p[0],p[1]);g.rotate(ang);rpmP(g,[-1.6*S,0,0,-5*S,1.6*S,0]);rpmFS(g,'#c89a6a',1.1);g.restore()};
 if(big){spk(-22,-13,-1);spk(-8,-15,-.2);spk(10,-10,.3);spk(24,-10,.9);spk(-14,-39,-.5);spk(0,-44,.4);
  for(const [x,y] of[[-12,-16],[-9,-18],[-10,-14]])rpmEl(g,...tx(x,y),2*S,2*S,'#e8304a',1.1);rpmEl(g,...tx(-11.4,-17.4),.7,.7,'#ffd0d8',0)}
 /* face */
 const e1=tx(9,-31),e2=tx(22,-29.5),R=big?5.2:7.6;
 rpmEye(g,e1[0],e1[1],R*S*(big?1:1),'#ffd23a','#147a66',.42);rpmEye(g,e2[0],e2[1],R*S*.78,'#ffd23a','#147a66',-.36);
 const m0=tx(7,-20),m1=tx(16,-16),m2=tx(27,-21);
 g.beginPath();g.moveTo(m0[0],m0[1]);g.quadraticCurveTo(m1[0],m1[1]+3*S,m2[0],m2[1]);g.quadraticCurveTo(m1[0],m1[1]-1.6*S,m0[0],m0[1]);g.closePath();rpmFS(g,'#0e3a34',1.6);
 for(const u of[.25,.62]){const x=m0[0]+(m2[0]-m0[0])*u,y=m0[1]+(m2[1]-m0[1])*u+1.2*S;rpmP(g,[x-1.3*S,y-1.6*S,x+1.3*S,y-1.6*S,x,y+1.6*S]);g.fillStyle='#fffbe8';g.fill()}
 /* gloss */
 const h0=tx(-20,-34);g.beginPath();g.ellipse(h0[0],h0[1],7*S,3.4*S,-.85,0,RPMT);g.fillStyle='rgba(255,255,255,.55)';g.fill();
 const h1=tx(-25,-24);rpmEl(g,h1[0],h1[1],1.8*S,1.8*S,'rgba(255,255,255,.6)',0);
 const hb=tx(0,-46);rpmAH(g,hb[0]+2*S,hb[1]+16*S,24*S,16*S,3.7,4.5,.4,1.4);
 if(!big){/* a sprout on the oozelet */const p=tx(2,-50);g.beginPath();g.moveTo(p[0],p[1]+2);g.quadraticCurveTo(p[0]-1,p[1]-4,p[0]+2,p[1]-6);g.lineWidth=3.6;g.strokeStyle=RPMO;g.stroke();g.lineWidth=1.6;g.strokeStyle='#7cc843';g.stroke();
  g.beginPath();g.moveTo(p[0]+2,p[1]-6);g.quadraticCurveTo(p[0]+8,p[1]-9,p[0]+8,p[1]-4);g.quadraticCurveTo(p[0]+5,p[1]-3,p[0]+2,p[1]-6);rpmFS(g,'#9ad84e',1.2);
  g.beginPath();g.moveTo(p[0]+1,p[1]-4);g.quadraticCurveTo(p[0]-5,p[1]-7,p[0]-5,p[1]-2);g.quadraticCurveTo(p[0]-2,p[1]-1.6,p[0]+1,p[1]-4);rpmFS(g,'#6ab83e',1.2)}
}
RPMD.ooze=function(g,ph){rpmOoze(g,ph,1)};
RPMD.oozelet=function(g,ph){rpmOoze(g,ph,0)};

/* ---------- 7. Hex Shaman: a hunched goblin witch-doctor with a healing totem ---------- */
RPMD.shaman=function(g,ph){const a=ph*RPMT,s=Math.sin(a),by=-Math.abs(Math.cos(a))*1.6,RB='#5e2c92',OR='#ff8a2a',SK='#7fae7a',GL='#ffb43a';
 const pu=.7+.3*Math.sin(a*2);
 /* skinny legs under the robe */
 const leg=(p,col)=>{const fx=1+6*Math.sin(p),fy=-Math.max(0,Math.cos(p))*3.6;rpmLimb(g,[1,-12+by,(1+fx)/2+1.5,-6+by*.5+fy*.5,fx,fy-2],2.8,col);g.save();g.translate(fx,fy);rpmP(g,[-3,-3,3,-3.4,6.6,-.6,6,0,-3.4,0]);rpmFS(g,'#7a4a2a',1.4);g.restore()};
 leg(a+Math.PI,rpmSh(SK,-.3));leg(a,SK);
 /* feathers fanning from the back of the hood */
 const fw=Math.sin(a*2)*.05;
 for(const [ang,col,l] of[[-.95,'#ff5a2a',17],[-.55,'#ffb43a',19],[-.2,'#e8302a',15]]){g.save();g.translate(-4,-51+by);g.rotate(ang+fw);g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(-4,-l*.5,0,-l);g.quadraticCurveTo(4,-l*.5,0,0);rpmFS(g,col,1.5);g.beginPath();g.moveTo(0,-1);g.lineTo(0,-l+2);g.lineWidth=.8;g.strokeStyle=rpmA(RPMO,.6);g.stroke();g.restore()}
 /* robe with a hunched back and a ragged hem */
 g.beginPath();g.moveTo(8,-42+by);g.quadraticCurveTo(-4,-50+by,-14,-40+by);g.quadraticCurveTo(-20,-28+by,-19,-12+by);
 const hem=[-19,-9,-15,-12,-11,-7.6,-7,-11.4,-3,-7.4,1,-11,5,-7.6,9,-11,12.4,-8];for(let i=0;i<hem.length;i+=2)g.lineTo(hem[i],hem[i+1]+by+(i%4?Math.sin(a+i)*.6:0));
 g.quadraticCurveTo(15,-24+by,8,-42+by);g.closePath();rpmFS(g,rpmCel(g,-16,-48+by,14,-10+by,RB,.56),2.4);
 g.beginPath();for(let i=0;i<hem.length;i+=2){const x=hem[i],y=hem[i+1]+by-2.2;i?g.lineTo(x,y):g.moveTo(x,y)}g.lineWidth=1.8;g.strokeStyle=OR;g.stroke();
 g.beginPath();g.moveTo(-16,-34+by);g.quadraticCurveTo(-8,-46+by,4,-44+by);rpmHi(g,.35,1.4);
 /* sash and bone charms */
 g.beginPath();g.moveTo(-15,-26+by);g.quadraticCurveTo(-2,-21+by,12,-27+by);g.lineWidth=5.6;g.strokeStyle=RPMO;g.stroke();g.lineWidth=3.4;g.strokeStyle=OR;g.stroke();
 for(const [x,y] of[[-8,-21],[-3,-19.6]]){rpmLimb(g,[x,y+by,x+.6,y+4+by+s*.5],1.6,'#efe3c2',1)}
 /* hood */
 const hx=10,hy=-44+by;
 g.beginPath();g.moveTo(-6,-38+by);g.quadraticCurveTo(-6,-52+by,2,-56+by);g.quadraticCurveTo(-6,-60+by,-15,-58+by+fw*20);g.quadraticCurveTo(4,-66+by,15,-52+by);g.quadraticCurveTo(20,-44+by,16,-36+by);g.quadraticCurveTo(5,-33+by,-6,-38+by);g.closePath();
 rpmFS(g,rpmCel(g,-10,-62+by,18,-36+by,'#6a34a2',.6),2.4);
 rpmEl(g,hx+2,hy+1,6.6,7,'#1a0a2a',0,.2);
 g.beginPath();g.moveTo(hx-5,hy+7);g.quadraticCurveTo(hx-6,hy-6,hx+3,hy-7.4);g.quadraticCurveTo(hx+9,hy-6,hx+9.4,hy+4);g.lineWidth=2;g.strokeStyle=OR;g.stroke();
 /* the face inside the hood: glowing eyes and a long nose */
 rpmGEye(g,hx+1.4,hy-1.2,1.6,'#ffa03a',1.2);rpmGEye(g,hx+5.6,hy-1.4,1.3,'#ffa03a',1);
 g.beginPath();g.moveTo(hx+2,hy+.6);g.quadraticCurveTo(hx+11,hy+2,hx+14,hy+6.6);g.quadraticCurveTo(hx+8,hy+6.4,hx+3,hy+4.4);g.closePath();rpmFS(g,rpmLG(g,hx,hy,hx+14,hy+6,[0,rpmSh(SK,.2),1,rpmSh(SK,-.2)]),1.6);
 g.beginPath();g.moveTo(hx+6,hy+2.6);g.lineTo(hx+8,hy+3.6);g.moveTo(hx+8.6,hy+3.4);g.lineTo(hx+10.6,hy+4.6);g.lineWidth=1;g.strokeStyle=OR;g.stroke();
 rpmP(g,[hx+4.6,hy+5.4,hx+6,hy+5.6,hx+5.6,hy+8.6]);rpmFS(g,'#fffbe8',.8);
 /* bead necklace */
 for(let i=0;i<5;i++){const u=i/4,x=hx-4+u*10,y=hy+9.4+Math.sin(u*Math.PI)*2.6;rpmEl(g,x,y,1.4,1.4,i%2?OR:'#efe3c2',1)}
 rpmAH(g,0,-48+by,10,9,3.4,4.3,.45,1.4);
 /* totem staff in the near hand */
 const sx=21+s*1.2,top=-58+by;
 g.save();g.translate(sx,0);g.rotate(.05+s*.03);
 rpmLimb(g,[0,-1,0,top+6],3.4,'#7a4a26');
 g.beginPath();for(let y=-4;y>top+8;y-=5){g.moveTo(-1.7,y);g.lineTo(1.7,y-2.4)}g.lineWidth=.9;g.strokeStyle='#3a2210';g.stroke();
 /* ribbons and bones hanging from the totem head */
 for(const [x,col,l] of[[-2.4,'#a85ad8',13],[2.2,OR,10]]){g.beginPath();g.moveTo(x,top+9);g.quadraticCurveTo(x-3+s*1.5,top+9+l*.5,x-1.4+s*2.6,top+9+l);g.lineWidth=3.8;g.strokeStyle=RPMO;g.stroke();g.lineWidth=2;g.strokeStyle=col;g.stroke()}
 /* carved head with the glowing orb in its jaws */
 rpmP(g,[-5,top+4,5,top+4,4,top+11,-4,top+11]);rpmFS(g,rpmCel(g,-5,top+3,5,top+11,'#9a6a3a'),1.6);
 rpmEl(g,-1.8,top+6.6,.9,.9,'#ffd27a',0);rpmEl(g,1.8,top+6.6,.9,.9,'#ffd27a',0);
 g.beginPath();g.moveTo(-5,top+5);g.quadraticCurveTo(-8,top-1,-3.6,top-3);g.moveTo(5,top+5);g.quadraticCurveTo(8,top-1,3.6,top-3);g.lineWidth=4.4;g.strokeStyle=RPMO;g.stroke();g.lineWidth=2.2;g.strokeStyle='#9a6a3a';g.stroke();
 rpmGlow(g,0,top,18*pu,GL,.7);
 rpmEl(g,0,top,4.4,4.4,rpmRG(g,0,top,5,[0,'#fffbe0',.5,'#ffd27a',1,'#ff7a1a'],-1,top-1.4),1.6);
 g.save();g.globalCompositeOperation='lighter';for(let i=0;i<3;i++){const u=(ph+i/3)%1,x=Math.sin(u*9+i*2)*3.6,y=top-4-u*10;g.globalAlpha=Math.sin(u*Math.PI)*.9;g.fillStyle='#ffd27a';g.beginPath();g.arc(x,y,.9,0,RPMT);g.fill()}g.restore();
 g.restore();
 /* sleeve and hand */
 const hx2=sx-.6,hy2=-27+by;
 g.beginPath();g.moveTo(-3,-38+by);g.quadraticCurveTo(8,-38+by,hx2-2,hy2-2.4);g.lineTo(hx2-3.6,hy2+3.4);g.quadraticCurveTo(5,-27+by,-4,-29+by);g.closePath();rpmFS(g,rpmCel(g,-2,-46+by,hx2,hy2+4,'#6e38aa'),2);
 g.beginPath();g.moveTo(hx2-2,hy2-2.2);g.lineTo(hx2-3.4,hy2+3.4);g.lineWidth=2.4;g.strokeStyle=OR;g.stroke();
 rpmEl(g,hx2,hy2+.6,2.6,3,SK,1.5)};

/* ---------- 8. Basalt Behemoth (boss): lava-cracked rock beast with a spiked siege ram on its back ---------- */
RPMD.behemoth=function(g,ph){const a=ph*RPMT,by=(Math.cos(a*2)-1)*1.5,tl=Math.sin(a)*.012,B='#4e4762',BL='#8a82a2',BD='#2c2638',LV='#ff6a1a',LY='#ffd24a';
 const pu=.75+.25*Math.sin(a*2),T=(p,dx,dy)=>p.map((v,i)=>v+(i%2?dy:dx));
 const leg=(bx,p,col,near)=>{const fx=bx+10*Math.sin(p),l=Math.max(0,Math.cos(p))*9,hy=-50+by,mx=(bx+fx)/2,my=(hy-14-l)/2;
  rpmRock(g,[bx-17,hy,bx+16,hy,fx+13,-14-l,fx-12,-14-l],col,2.8,.55,near?.35:0);
  if(near)rpmFiss(g,[bx-3,hy+6,bx+2,hy+14,bx-2,hy+22,bx+1,hy+30],4.4,LV,LY);
  rpmRock(g,[mx-15,my-6,mx+10,my-9,mx+15,my+3,mx-12,my+7],col,2.2,.5,near?.4:0);
  rpmRock(g,[fx-16,-14-l,fx+8,-16-l,fx+21,-8-l,fx+21,-l,fx-16,-l],col,2.6,.55,near?.35:0);
  for(const x of[7,13,19]){rpmP(g,[fx+x-3.4,-3-l,fx+x+1,-5.4-l,fx+x+5,-l,fx+x-3.4,-l]);rpmFS(g,'#d8cfbe',1.3)}};
 leg(-48,a,BD,0);leg(46,a+Math.PI,BD,0);
 g.save();g.translate(0,-60);g.rotate(tl);g.translate(0,60+by);
 /* tail and basalt columns on the haunch */
 rpmRock(g,[-84,-64,-104,-58,-116,-42,-100,-46,-82,-50],B,2.4,.55);
 const col=(x,y,w,h,ang)=>{g.save();g.translate(x,y);g.rotate(ang);rpmP(g,[-w/2,0,-w/2,-h,0,-h-w*.35,w/2,-h,w/2,0]);rpmFS(g,rpmLG(g,-w/2,0,w/2,0,[0,BL,.45,B,.5,BD,1,'#1e1a28']),2.2);rpmP(g,[-w/2,-h,0,-h-w*.35,w/2,-h,0,-h+w*.25]);rpmFS(g,'#a49cbc',1.2);g.restore()};
 col(-90,-84,10,22,-.62);col(-82,-94,12,30,-.4);col(-68,-102,10,20,-.16);
 col(72,-112,9,18,.5);col(80,-104,10,22,.72);col(86,-94,8,14,.95);
 /* body: one angular basalt mass */
 const BP=[-90,-54,-96,-74,-88,-94,-70,-106,-44,-112,-14,-116,14,-122,40,-128,62,-126,80,-114,92,-94,96,-72,88,-52,66,-40,30,-42,-10,-40,-48,-40,-78,-44];
 rpmRock(g,BP,B,3,.5,.4);
 /* rock facets */
 for(const p of[[-86,-92,-70,-104,-44,-110,-40,-102,-64,-96,-80,-86],[-14,-114,14,-120,40,-126,42,-118,16,-110,-10,-106],[62,-124,80,-112,90,-94,82,-96,72,-110]]){rpmP(g,p);g.fillStyle='rgba(176,166,206,.42)';g.fill()}
 for(const p of[[-78,-46,-48,-42,-10,-42,30,-44,66,-42,58,-50,20,-52,-20,-50,-60,-50],[-94,-72,-88,-56,-80,-62,-86,-76]]){rpmP(g,p);g.fillStyle='rgba(18,8,31,.28)';g.fill()}
 /* magma fissures */
 const FS=[[[-78,-96,-70,-84,-74,-70,-64,-58,-67,-47],7.4],[[-70,-84,-57,-80,-50,-85],4.8],[[-90,-70,-82,-64,-84,-54],4.4],[[-30,-110,-24,-96,-33,-84,-22,-70,-27,-50],8],[[-24,-96,-10,-92,-4,-97],4.8],[[-33,-84,-44,-76,-48,-66],4.4],[[34,-122,28,-106,40,-94,33,-80,44,-64,39,-48],8.6],[[40,-94,56,-98,62,-91],5],[[33,-80,20,-74,14,-62],4.6],[[84,-102,77,-88,85,-75,78,-58],6.6],[[0,-112,6,-100,0,-90],4.4]];
 for(const f of FS)rpmGlow(g,f[0][2],f[0][3],f[1]*3.6,LV,.36*pu);
 for(const f of FS)rpmFiss(g,f[0],f[1],LV,LY);
 /* the siege ram resting on the back */
 g.save();g.translate(-86,-110);g.rotate(-.15);const L=150,R2=11.5;
 rpmP(g,[0,-R2,L,-R2,L,R2,0,R2]);rpmFS(g,rpmLG(g,0,-R2,0,R2,[0,'#c8925a',.35,'#9e6a36',.6,'#7a4a22',1,'#4a2a12']),2.6);
 g.beginPath();for(const y of[-5,1,6]){g.moveTo(10,y);g.bezierCurveTo(50,y-2,90,y+2,L-10,y)}g.lineWidth=1;g.strokeStyle='rgba(40,18,6,.55)';g.stroke();
 g.beginPath();g.moveTo(4,-R2+3);g.lineTo(L-6,-R2+3);rpmHi(g,.35,1.6);
 rpmEl(g,0,0,5,R2,rpmRG(g,0,0,R2,[0,'#eebe7e',.5,'#c8925a',1,'#8a5a2a']),2.4);
 g.beginPath();g.ellipse(0,0,2.6,6,0,0,RPMT);g.moveTo(1,0);g.ellipse(0,0,1,2.6,0,0,RPMT);g.lineWidth=.9;g.strokeStyle='rgba(60,30,10,.7)';g.stroke();
 for(const x of[16,128]){rpmP(g,[x-4,-R2-1.6,x+4,-R2-1.6,x+4,R2+1.6,x-4,R2+1.6]);rpmFS(g,rpmLG(g,0,-R2,0,R2,[0,'#b4bac8',.5,'#6a7080',1,'#3a3e4a']),2);for(const y of[-6,0,6])rpmEl(g,x,y,1.1,1.1,'#d8dde6',0)}
 /* spiked iron head */
 rpmP(g,[L-2,-R2-4,L+16,-R2-2,L+30,0,L+16,R2+2,L-2,R2+4]);rpmFS(g,rpmLG(g,0,-R2-4,0,R2+4,[0,'#a0a6b6',.45,'#5a5e6c',.55,'#3e414e',1,'#24262e']),2.6);
 for(const [x,y,ang,l] of[[L+6,-R2-3,-1.9,10],[L+18,-R2+1,-1.2,9],[L+6,R2+3,1.9,8],[L+29,0,0,12]]){g.save();g.translate(x,y);g.rotate(ang+Math.PI/2);rpmP(g,[-3.2,0,0,-l,3.2,0]);rpmFS(g,rpmLG(g,-3,0,3,0,[0,'#eef1f6',.5,'#9aa0b0',1,'#4a4e5a']),1.6);g.restore()}
 rpmEl(g,L+12,-3,2,2,'#e8ecf2',1);g.beginPath();g.moveTo(L,-R2);g.lineTo(L+16,-R2+1);rpmHi(g,.55,1.3);
 g.restore();
 /* leather straps over the ram and around the belly */
 for(const [x,y] of[[-46,-127],[22,-138]]){g.beginPath();g.moveTo(x-3,y);g.quadraticCurveTo(x+12,y+40,x+6,-40);g.lineWidth=9.6;g.strokeStyle=RPMO;g.stroke();g.lineWidth=6.4;g.strokeStyle='#7e4624';g.stroke();g.beginPath();g.moveTo(x-2,y+3);g.quadraticCurveTo(x+10,y+40,x+5,-46);g.lineWidth=1.1;g.strokeStyle='#b8744a';g.stroke();
  const bx=x+8,byk=y+44;rpmP(g,[bx-5,byk-5,bx+5,byk-5,bx+5,byk+5,bx-5,byk+5]);rpmFS(g,'#9aa0ae',1.6);rpmP(g,[bx-2.4,byk-2.4,bx+2.4,byk-2.4,bx+2.4,byk+2.4,bx-2.4,byk+2.4]);g.fillStyle='#34343e';g.fill()}
 /* head: heavy brow, glowing eyes, magma maw, tusks and curling horns */
 const hn=Math.sin(a*2+.8)*1.4;g.save();g.translate(0,hn);
 const horn=(x0,y0,c,dk)=>{g.beginPath();g.moveTo(x0-6,y0+4);g.bezierCurveTo(x0-7,y0-16,x0+8,y0-32,x0+c,y0-36);g.bezierCurveTo(x0+c-7,y0-25,x0+9,y0-14,x0+8,y0+2);g.closePath();rpmFS(g,rpmLG(g,x0-6,0,x0+c,0,dk?[0,'#6e6658',1,'#3a342c']:[0,'#f4ead4',.5,'#cdbd9c',1,'#8a7a62']),2.4);
  if(!dk){g.beginPath();for(let i=1;i<4;i++){const u=i/4;g.moveTo(x0-5+u*(c-2)*.7,y0-u*30+2);g.lineTo(x0+5+u*(c-2)*.75,y0-u*28+4)}g.lineWidth=1;g.strokeStyle=rpmA(RPMO,.45);g.stroke();g.beginPath();g.moveTo(x0-3,y0-2);g.bezierCurveTo(x0-4,y0-16,x0+8,y0-28,x0+c-4,y0-33);rpmHi(g,.5,1.3)}};
 horn(94,-96,24,1);
 /* the maw: magma inside, jaw below */
 rpmP(g,[84,-66,128,-66,140,-56,124,-44,90,-46]);g.fillStyle=rpmLG(g,0,-66,0,-44,[0,LY,.45,LV,1,'#8a1806']);g.fill();g.lineWidth=2.4;g.strokeStyle=RPMO;g.stroke();
 rpmGlow(g,116,-56,30,LV,.6*pu);
 rpmRock(g,[80,-50,112,-54,142,-52,140,-40,122,-30,92,-32,78,-40],B,2.6,.55,.35);
 for(const x of[98,107,116,125,133]){rpmP(g,[x-2.6,-51,x+2.6,-51.6,x,-58]);rpmFS(g,'#efe4cc',1)}
 /* tusks from the lower jaw */
 for(const [x,k] of[[116,1],[136,0]]){g.beginPath();g.moveTo(x-3,-46);g.quadraticCurveTo(x-2,-60,x+5,-66);g.quadraticCurveTo(x+2,-56,x+3,-46);g.closePath();rpmFS(g,rpmLG(g,x-3,0,x+5,0,[0,'#fffbec',1,'#c8b896']),1.6)}
 /* lava drool */
 const dr=(ph*2)%1;g.beginPath();g.moveTo(128,-38);g.quadraticCurveTo(129,-34+dr*4,128.4,-30+dr*8);g.lineWidth=4.4;g.strokeStyle='#1a0610';g.stroke();g.lineWidth=2.4;g.strokeStyle=LV;g.stroke();rpmEl(g,128.4,-29+dr*8,1.8,2.4,LY,0);
 /* skull */
 rpmRock(g,[70,-96,94,-106,118,-100,134,-86,142,-70,136,-62,112,-66,86,-64,72,-76],B,2.8,.55,.45);
 for(const x of[100,109,118,127]){rpmP(g,[x-2.8,-65.4,x+2.8,-65.8,x+.4,-58.6]);rpmFS(g,'#efe4cc',1)}
 rpmP(g,[84,-100,112,-104,126,-96,110,-94,90,-92]);g.fillStyle='rgba(176,166,206,.42)';g.fill();
 rpmFiss(g,[84,-92,90,-82,84,-70],4,LV,LY);
 /* brow slab and the glowing eyes */
 rpmP(g,[106,-82,132,-86,138,-74,128,-74,108,-76]);g.fillStyle='#141020';g.fill();
 rpmGEye(g,119,-77.6,3.6,LY,2.2);rpmGEye(g,131,-78.4,2.6,LY,1.8);
 rpmRock(g,[100,-86,126,-94,140,-86,138,-80,124,-84,104,-79],'#3a3448',2.2,.5,.4);
 /* nostril glow */
 rpmEl(g,138,-68,1.8,1.4,'#1a0610',0);rpmGlow(g,138,-68,5,LV,.6*pu);
 horn(106,-98,30,0);
 g.restore();
 g.restore();
 leg(-58,a+Math.PI,B,1);leg(56,a,B,1);
 /* embers drifting up from the cracks */
 g.save();g.globalCompositeOperation='lighter';for(let i=0;i<7;i++){const u=(ph+i/7)%1,x=[-70,-26,36,80,-64,-24,40][i]+Math.sin(u*8+i)*5,y=[-80,-96,-100,-90,-58,-60,-70][i]-u*46+by;g.globalAlpha=Math.sin(u*Math.PI)*.95;g.fillStyle=i%2?LY:LV;g.beginPath();g.arc(x,y,1.5+(i%3)*.5,0,RPMT);g.fill()}g.restore()};

/* ---------- live draw ---------- */
/* per-monster scale that brings each drawing to its natural height RPMOB.h (accessories such as wing tips, swords and sprouts may poke a little above it) */
const RPMK={scamp:.85,bulwark:.96,golem:.91,gloom:.86,ooze:.94,oozelet:.8,shaman:.92,behemoth:.96};
function rpMobDraw(g,id,ph,o){const f=RPMD[id];if(!f)return;ph=+ph||0;ph=ph-Math.floor(ph);g.save();g.lineJoin='round';g.lineCap='round';const k=RPMK[id]||1;g.scale(k,k);try{f(g,ph,o||{})}finally{g.restore()}}

/* ---------- baked sheets and the fast blit ---------- */
/* frame box per monster in units [left, top, right, bottom] around the feet point, and the shadow half-width */
const RPMB={scamp:[-21,-56,24,6,13],bulwark:[-33,-71,36,6,16],golem:[-50,-103,57,7,30],gloom:[-41,-62,27,11,14],ooze:[-40,-65,43,7,30],oozelet:[-20,-37,20,6,14],shaman:[-24,-73,39,6,15],behemoth:[-118,-160,143,8,92]};
const RPSS=2,RPNF=8,RPMC={};
function rpmBake(id){let C=RPMC[id];if(C)return C;const B=RPMB[id];if(!B)return null;const w=B[2]-B[0],h=B[3]-B[1],fw=Math.ceil(w*RPSS),fh=Math.ceil(h*RPSS);
 const cv=document.createElement('canvas');cv.width=fw*RPNF;cv.height=fh;const g=cv.getContext('2d');
 for(let i=0;i<RPNF;i++){g.setTransform(RPSS,0,0,RPSS,i*fw-B[0]*RPSS,-B[1]*RPSS);g.save();g.beginPath();g.rect(B[0],B[1],w,h);g.clip();rpMobDraw(g,id,i/RPNF,{bake:1});g.restore()}
 g.setTransform(1,0,0,1,0,0);C=RPMC[id]={B,w,h,fw,fh,cv,wh:null,ic:null,sw:B[4]};return C}
/* white (hit flash) and icy (chilled) silhouettes of the whole sheet, made with source-atop */
function rpmTint(C,ice){const cv=document.createElement('canvas');cv.width=C.cv.width;cv.height=C.cv.height;const g=cv.getContext('2d');g.drawImage(C.cv,0,0);g.globalCompositeOperation='source-atop';
 if(ice){g.fillStyle=rpmLG(g,0,0,0,cv.height,[0,'#f4fcff',.45,'#b4e4ff',1,'#6ab4f4']);g.fillRect(0,0,cv.width,cv.height);
  /* frost sparkles */
  g.fillStyle='#ffffff';for(let i=0;i<RPNF;i++)for(let j=0;j<6;j++){const x=i*C.fw+C.fw*(.2+rpmRn(i*7+j)*.6),y=C.fh*(.15+rpmRn(j*13+i+5)*.6),r=RPSS*(.8+rpmRn(j+i*3)*.9);g.beginPath();g.moveTo(x,y-r*2.4);g.lineTo(x+r*.6,y);g.lineTo(x,y+r*2.4);g.lineTo(x-r*.6,y);g.closePath();g.moveTo(x-r*2.4,y);g.lineTo(x,y+r*.6);g.lineTo(x+r*2.4,y);g.lineTo(x,y-r*.6);g.closePath();g.fill()}}
 else{g.fillStyle='#fffaf0';g.fillRect(0,0,cv.width,cv.height)}return cv}
const RPSHD=(()=>{const cv=document.createElement('canvas');cv.width=64;cv.height=20;const g=cv.getContext('2d');g.setTransform(1,0,0,20/64,0,0);
 const q=g.createRadialGradient(32,32,0,32,32,32);q.addColorStop(0,'rgba(12,6,24,.5)');q.addColorStop(.6,'rgba(12,6,24,.36)');q.addColorStop(1,'rgba(12,6,24,0)');g.fillStyle=q;g.fillRect(0,0,64,64);return cv})();
function rpMobPrebake(ids){for(const id of(ids||Object.keys(RPMOB)))rpmBake(id)}
function rpMobBlit(c,id,x,y,ph,o){const C=RPMC[id]||rpmBake(id);if(!C)return;const M=RPMOB[id];o=o||{};
 const s=o.s>0?o.s:1,a=o.a==null?1:Math.max(0,Math.min(1,o.a));if(a<=0)return;
 ph=+ph||0;ph-=Math.floor(ph);const fi=Math.min(RPNF-1,Math.floor(ph*RPNF)),sx=fi*C.fw,lift=M.air?(M.lift||38)*s:0,ga=c.globalAlpha;
 /* ground shadow */
 const sw=C.sw*s*(M.air?.7:1);c.globalAlpha=ga*a*(M.air?.5:1);c.drawImage(RPSHD,x-sw,y-sw*.3,sw*2,sw*.6);
 const fl=o.flash>0?Math.min(1,o.flash):0,ch=o.chill>0?Math.min(1,o.chill):0;
 if(ch&&!C.ic)C.ic=rpmTint(C,1);if(fl&&!C.wh)C.wh=rpmTint(C,0);
 const dw=C.w*s,dh=C.h*s;let dx,dy,tr=o.flip||o.rot;
 if(tr){c.save();c.translate(x,y-lift);if(o.rot){const cy=M.h*s*.5;c.translate(0,-cy);c.rotate(o.rot);c.translate(0,cy)}if(o.flip)c.scale(-1,1);dx=C.B[0]*s;dy=C.B[1]*s}
 else{dx=x+C.B[0]*s;dy=y-lift+C.B[1]*s}
 c.globalAlpha=ga*a;c.drawImage(C.cv,sx,0,C.fw,C.fh,dx,dy,dw,dh);
 if(ch){c.globalAlpha=ga*a*ch*.62;c.drawImage(C.ic,sx,0,C.fw,C.fh,dx,dy,dw,dh)}
 if(fl){c.globalAlpha=ga*a*fl;c.drawImage(C.wh,sx,0,C.fw,C.fh,dx,dy,dw,dh)}
 if(tr)c.restore();c.globalAlpha=ga}

/* ---------- portraits ---------- */
const RPMI={};
function rpMobIcon(id,size){size=Math.max(8,Math.round(size||64));const key=id+'|'+size;if(RPMI[key])return RPMI[key];
 const cv=document.createElement('canvas');cv.width=cv.height=size;const M=RPMOB[id],B=RPMB[id];if(!M||!B)return cv;const g=cv.getContext('2d');
 const ph=M.air?.02:.12,T=rpmTight(id,ph).slice(),h=T[3]-T[1];if(T[2]-T[0]>h*1.25)T[0]=T[2]-h*1.25;const w=T[2]-T[0],k=size*.9/Math.max(w,h);
 g.translate(size/2-(T[0]+w/2)*k,size/2-(T[1]+h/2)*k);g.scale(k,k);
 if(!M.air){g.drawImage(RPSHD,-B[4],-B[4]*.3,B[4]*2,B[4]*.6)}
 rpMobDraw(g,id,ph,{icon:1});RPMI[key]=cv;return cv}
/* tight bounds of one frame (measured once from a 1x render) */
const RPMTB={};
function rpmTight(id,ph){const key=id+'|'+ph;if(RPMTB[key])return RPMTB[key];const B=RPMB[id],w=Math.ceil(B[2]-B[0]),h=Math.ceil(B[3]-B[1]),cv=document.createElement('canvas');cv.width=w;cv.height=h;
 const g=cv.getContext('2d');g.translate(-B[0],-B[1]);rpMobDraw(g,id,ph,{});let d;try{d=g.getImageData(0,0,w,h).data}catch(e){return RPMTB[key]=B.slice(0,4)}
 let x0=w,y0=h,x1=0,y1=0;for(let y=0;y<h;y++)for(let x=0;x<w;x++)if(d[(y*w+x)*4+3]>40){if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y}
 if(x1<x0)return RPMTB[key]=B.slice(0,4);return RPMTB[key]=[x0+B[0],y0+B[1],x1+1+B[0],Math.max(y1+1+B[1],0)]}

/* ---------- deaths: a white pop, then cheap debris on arcs (deterministic, no state) ---------- */
const RPMDX={
 scamp:{n:9,k:['leaf','leaf','leaf','puff','puff','cap','leaf','puff','leaf'],c:['#7cc843','#5aa53c','#e2442e','#d8f5a8']},
 bulwark:{n:10,k:['bone','bone','bone','bone','bone','skull','bone','spark','spark','bone'],c:['#efe3c2','#3ff2d2']},
 golem:{n:12,k:['rock','rock','rock','rock','rock','rock','rock','spark','spark','spark','puff','puff'],c:['#8792aa','#ffb02e','#5ff4ff','#c8ccd8']},
 gloom:{n:10,k:['puff','puff','puff','scrap','scrap','scrap','spark','spark','spark','puff'],c:['#7b48d4','#ffd84a','#ff4fb8']},
 ooze:{n:12,k:['drop','drop','drop','drop','drop','drop','drop','drop','thorn','thorn','drop','drop'],c:['#52e0aa','#9a6a4a']},
 oozelet:{n:7,k:['drop','drop','drop','drop','drop','drop','drop'],c:['#62e8b0']},
 shaman:{n:11,k:['puff','puff','puff','puff','spark','spark','spark','feather','feather','feather','spark'],c:['#6a34a2','#ffb43a','#ff5a2a']},
 behemoth:{n:18,k:['rock','rock','rock','rock','rock','rock','rock','rock','rock','lava','lava','lava','lava','lava','lava','puff','puff','puff'],c:['#4c4660','#ff6a1a','#ffd24a','#7a7290']}};
function rpMobDeath(c,id,x,y,k,o){const M=RPMOB[id],D=RPMDX[id];if(!M||!D||!(k<1))return;k=Math.max(0,k);o=o||{};
 const s=o.s>0?o.s:1,fl=o.flip?-1:1,h=M.h*s,lift=M.air?(M.lift||38)*s:0,cy=y-lift-h*.5,ga=c.globalAlpha,seed=o.seed==null?Math.round(x*7+y*3):o.seed,big=M.boss?1:0;
 const fade=k<.6?1:1-(k-.6)/.4;
 /* flash and the body popping */
 if(k<.3){const u=k/.3;c.save();c.globalCompositeOperation='lighter';c.globalAlpha=ga*(1-u)*.7;const r=h*(.55+u*.5);const q=c.createRadialGradient(x,cy,0,x,cy,r);q.addColorStop(0,'rgba(255,248,230,.9)');q.addColorStop(1,'rgba(255,248,230,0)');c.fillStyle=q;c.fillRect(x-r,cy-r,r*2,r*2);c.restore()}
 if(k<.22){const C=RPMC[id]||rpmBake(id);if(C){if(!C.wh)C.wh=rpmTint(C,0);const u=k/.22;c.save();c.globalAlpha=ga*(1-u);c.translate(x,y-lift);c.scale(fl*(1+u*.3),1-u*.55);c.drawImage(C.wh,0,0,C.fw,C.fh,C.B[0]*s,C.B[1]*s,C.w*s,C.h*s);c.restore()}}
 /* ground ring for the big ones, slime puddle for oozes */
 if(id==='ooze'||id==='oozelet'){const u=Math.min(1,k/.25),r=M.w*s*.5*(.6+u*.6);c.globalAlpha=ga*fade*.75;c.fillStyle='#2fc49a';c.beginPath();c.ellipse(x,y,r,r*.22,0,0,RPMT);c.fill();c.fillStyle='rgba(200,255,220,.5)';c.beginPath();c.ellipse(x-r*.25,y-r*.05,r*.35,r*.06,0,0,RPMT);c.fill()}
 if(big||id==='golem'){const r=M.w*s*(.3+k*.9);c.globalAlpha=ga*(1-k)*.8;c.lineWidth=(big?6:4)*s*(1-k)+1;c.strokeStyle=big?'#ff8a3a':'#c8ccd8';c.beginPath();c.ellipse(x,y,r,r*.26,0,0,RPMT);c.stroke()}
 /* debris */
 const G=h*3.4,T=k;
 for(let i=0;i<D.n;i++){const kd=D.k[i],r1=rpmRn(seed+i*3.1),r2=rpmRn(seed+i*5.7+1),r3=rpmRn(seed+i*1.3+2);
  const ang=-Math.PI/2+(r1-.5)*2.4,sp=h*(kd==='puff'?.5:1)*(.9+r2*1.1)*(big?1.2:1);
  let px=x+Math.cos(ang)*sp*T*fl+(r3-.5)*M.w*s*.3,py=cy+(r2-.5)*h*.4+Math.sin(ang)*sp*T+(kd==='puff'||kd==='spark'?-.1:.5)*G*T*T;
  const sz=(kd==='rock'?(big?11:7):kd==='lava'?4:kd==='puff'?7+k*12:kd==='cap'?7:kd==='skull'?5.4:kd==='bone'?3.4:3.6)*s*(.75+r3*.6);
  if(kd==='feather'||kd==='scrap'||kd==='leaf'){py=cy+Math.sin(ang)*sp*T*.6+h*.9*T*T+Math.sin(T*9+i)*3*s;px+=Math.sin(T*6+i)*6*s}
  if(kd!=='puff'&&kd!=='spark'&&py>y-sz*.4)py=y-sz*.4;
  const rot=(r1*6+T*(8+r2*10))*(r3>.5?1:-1);c.globalAlpha=ga*fade;
  if(kd==='puff'){c.globalAlpha=ga*fade*(1-k)*.55;c.fillStyle=D.c[(i%2)?0:D.c.length-1];c.beginPath();c.arc(px,py,sz,0,RPMT);c.fill();continue}
  if(kd==='spark'||kd==='lava'){c.save();c.globalCompositeOperation='lighter';c.fillStyle=kd==='lava'?(i%2?D.c[1]:D.c[2]):D.c[1+(i%Math.max(1,D.c.length-1))];c.beginPath();c.arc(px,py,sz*(1-k*.5),0,RPMT);c.fill();c.restore();continue}
  if(kd==='drop'){c.fillStyle=D.c[0];c.beginPath();c.arc(px,py,sz*1.3,0,RPMT);c.fill();c.lineWidth=1.2*s;c.strokeStyle=RPMO;c.stroke();c.fillStyle='rgba(255,255,255,.6)';c.beginPath();c.arc(px-sz*.4,py-sz*.4,sz*.4,0,RPMT);c.fill();continue}
  c.save();c.translate(px,py);c.rotate(rot);c.lineWidth=1.4*s;c.strokeStyle=RPMO;c.beginPath();
  if(kd==='bone'){c.rect(-sz*1.6,-sz*.4,sz*3.2,sz*.8);c.fillStyle=D.c[0];c.fill();c.stroke();c.beginPath();c.arc(-sz*1.6,0,sz*.55,0,RPMT);c.arc(sz*1.6,0,sz*.55,0,RPMT);c.fill();c.stroke()}
  else if(kd==='skull'){c.arc(0,0,sz,0,RPMT);c.fillStyle=D.c[0];c.fill();c.stroke();c.fillStyle=RPMO;c.fillRect(sz*.1,-sz*.3,sz*.35,sz*.4)}
  else if(kd==='rock'){c.moveTo(-sz,-sz*.6);c.lineTo(sz*.3,-sz);c.lineTo(sz,-sz*.1);c.lineTo(sz*.4,sz*.8);c.lineTo(-sz*.8,sz*.6);c.closePath();c.fillStyle=i%3?D.c[0]:D.c[3];c.fill();c.stroke();if(big&&i%2){c.beginPath();c.moveTo(-sz*.5,-sz*.3);c.lineTo(sz*.3,sz*.3);c.strokeStyle=D.c[1];c.stroke()}}
  else if(kd==='cap'){c.arc(0,0,sz,Math.PI,RPMT);c.closePath();c.fillStyle=D.c[2];c.fill();c.stroke();c.fillStyle='#fff3da';c.beginPath();c.arc(-sz*.3,-sz*.4,sz*.2,0,RPMT);c.fill()}
  else if(kd==='thorn'){c.moveTo(-sz*.6,0);c.lineTo(0,-sz*2.2);c.lineTo(sz*.6,0);c.closePath();c.fillStyle=D.c[1];c.fill();c.stroke()}
  else{/* leaf, feather, scrap */c.ellipse(0,0,sz*1.5,sz*.6,0,0,RPMT);c.fillStyle=kd==='feather'?D.c[1+(i%2)]:kd==='scrap'?D.c[0]:D.c[i%2];c.fill();c.stroke()}
  c.restore()}
 c.globalAlpha=ga}
