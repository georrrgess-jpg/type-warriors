/* ---------- Graveyard crate art ---------- */
function hwChest(g,x,y,s,u,t){
 const wood='#3e2f48',wd2='#150e1c',band='#434a54',bd2='#1c2128',rn='#7affc8',hexA=n=>Math.round(Math.max(0,Math.min(255,n))).toString(16).padStart(2,'0');
 g.save();g.translate(x,y);g.scale(s,s);
 g.fillStyle='#0009';g.beginPath();g.ellipse(0,4,96,14,0,0,TAU);g.fill();
 glow(g,0,-46,165+Math.sin(t*2)*10,'#5affb02c');
 /* scattered bones on the ground */
 g.strokeStyle='#d9d3bd';g.lineCap='round';g.lineWidth=4;g.beginPath();g.moveTo(-84,6);g.lineTo(-60,9);g.stroke();g.beginPath();g.moveTo(66,8);g.lineTo(86,4);g.stroke();
 for(const [bx,by] of[[-84,6],[-60,9],[66,8],[86,4]])ell(g,bx,by,3.2,3.2,'#d9d3bd');
 /* candle on the left, jack-o'-lantern on the right */
 g.fillStyle='#d8d0b8';g.fillRect(-108,-24,10,24);g.fillStyle='#a89f86';g.fillRect(-103,-24,5,24);ell(g,-103,-24,5,2,'#efe8d0');glow(g,-103,-31,34,'#ffb84a77');ell(g,-103,-31,3.4,6+Math.sin(t*10)*1.3,'#ffd88a');ell(g,-103,-30,1.6,3.4,'#fff4d0');
 hwPumpkin(g,106,-17,20,t);
 /* rising wisps */
 for(let i=0;i<6;i++){const k=(t*.32+i*.17)%1,wx=-66+i*26+Math.sin(t*1.7+i*2)*10,wy=-82-k*100;g.globalAlpha=Math.sin(k*Math.PI)*.6;glow(g,wx,wy,12,'#7affc8aa');ell(g,wx,wy,2.2,3,'#e8fff4')}g.globalAlpha=1;
 const lidUp=u>0;
 if(lidUp)glow(g,0,-62,120*u+40,'#b8ffd8'+hexA(u*255));
 /* body */
 g.fillStyle=vgr(g,-70,0,wood,wd2);g.beginPath();g.roundRect(-70,-70,140,70,8);g.fill();
 g.strokeStyle=wd2;g.lineWidth=2;for(let i=1;i<4;i++){g.beginPath();g.moveTo(-70,-70+i*17.5);g.lineTo(70,-70+i*17.5);g.stroke()}
 g.strokeStyle='#ffffff10';g.lineWidth=1;for(let i=0;i<4;i++){g.beginPath();g.moveTo(-68,-69+i*17.5);g.lineTo(68,-69+i*17.5);g.stroke()}
 if(lidUp){g.fillStyle='#d8fff0';g.beginPath();g.roundRect(-62,-70,124,10,4);g.fill()}
 /* cobweb in the top-left corner */
 g.save();g.beginPath();g.roundRect(-70,-70,140,70,8);g.clip();g.strokeStyle='#ffffff55';g.lineWidth=1;
 for(let i=0;i<5;i++){const a=i*Math.PI/8;g.beginPath();g.moveTo(-70,-70);g.lineTo(-70+Math.cos(a)*46,-70+Math.sin(a)*46);g.stroke()}
 for(let r=12;r<=44;r+=11){g.beginPath();for(let i=0;i<5;i++){const a=i*Math.PI/8,px=-70+Math.cos(a)*r,py=-70+Math.sin(a)*r;i?g.quadraticCurveTo(-70+Math.cos(a-Math.PI/16)*r*.86,-70+Math.sin(a-Math.PI/16)*r*.86,px,py):g.moveTo(px,py)}g.stroke()}g.restore();
 /* iron bands with glowing runes */
 for(const bx of[-52,52]){g.fillStyle=band;g.fillRect(bx-9,-70,18,70);g.fillStyle=bd2;g.fillRect(bx-9,-70,4,70);for(const yy of[-60,-10])ell(g,bx,yy,3,3,bd2);
  const rf=.55+.45*Math.sin(t*2.6+bx);g.fillStyle=rn;g.shadowColor=rn;g.shadowBlur=8;g.globalAlpha=rf;g.fillRect(bx-1,-48,2,10);g.fillRect(bx-4,-44,8,2);g.fillRect(bx-1,-28,2,8);g.globalAlpha=1;g.shadowBlur=0}
 /* skull clasp */
 g.fillStyle='#262b33';g.beginPath();g.roundRect(-19,-58,38,44,8);g.fill();g.strokeStyle='#0c0f13';g.lineWidth=1.5;g.stroke();
 g.fillStyle='#e8e2cc';g.beginPath();g.ellipse(0,-40,13,12,0,0,TAU);g.fill();g.fillStyle='#d6cfb4';g.beginPath();g.roundRect(-8,-33,16,10,3);g.fill();
 g.fillStyle='#05100c';g.beginPath();g.ellipse(-5.2,-41,3.6,4.4,0,0,TAU);g.ellipse(5.2,-41,3.6,4.4,0,0,TAU);g.fill();g.beginPath();g.moveTo(0,-37);g.lineTo(-2.4,-32);g.lineTo(2.4,-32);g.fill();
 const ef=.7+.3*Math.sin(t*5);glow(g,-5.2,-41,11,rn+hexA(ef*210));glow(g,5.2,-41,11,rn+hexA(ef*210));ell(g,-5.2,-41,1.6,1.9,rn);ell(g,5.2,-41,1.6,1.9,rn);
 g.strokeStyle='#8a836c';g.lineWidth=1;for(let i=-6;i<=6;i+=3){g.beginPath();g.moveTo(i,-30);g.lineTo(i,-24);g.stroke()}
 /* lid */
 const ang=u*Math.PI*.58,ch=Math.cos(ang),lh=44;
 g.save();
 if(ang<Math.PI/2){const hh=Math.max(4,lh*ch);
  g.fillStyle=vgr(g,-70-hh,-70,shade(wood,.2),wood);g.beginPath();g.moveTo(-70,-70);g.lineTo(-70,-70-hh);g.quadraticCurveTo(0,-70-hh-lh*.55*(1-ch*.4),70,-70-hh);g.lineTo(70,-70);g.closePath();g.fill();
  g.strokeStyle='#ffffff12';g.lineWidth=1;g.beginPath();g.moveTo(-60,-70-hh*.55);g.quadraticCurveTo(0,-70-hh*.55-lh*.36*(1-ch*.4),60,-70-hh*.55);g.stroke();
  for(const bx of[-52,52]){g.fillStyle=band;g.beginPath();g.moveTo(bx-9,-70);g.lineTo(bx-9,-70-hh+2);g.quadraticCurveTo(bx,-70-hh-8,bx+9,-70-hh+2);g.lineTo(bx+9,-70);g.closePath();g.fill();
   /* spikes on the bands */
   g.fillStyle=bd2;g.beginPath();g.moveTo(bx-4,-70-hh+1);g.lineTo(bx,-70-hh-11);g.lineTo(bx+4,-70-hh+1);g.fill()}
  if(u<.05){g.fillStyle=band;g.beginPath();g.roundRect(-12,-86,24,30,5);g.fill();g.strokeStyle=bd2;g.lineWidth=1.4;g.stroke();
   g.fillStyle='#e8e2cc';g.beginPath();g.ellipse(0,-76,6,6.2,0,0,TAU);g.fill();g.fillStyle='#05100c';g.beginPath();g.ellipse(-2.4,-77,1.6,2,0,0,TAU);g.ellipse(2.4,-77,1.6,2,0,0,TAU);g.fill();ell(g,-2.4,-77,.9,1,rn);ell(g,2.4,-77,.9,1,rn);glow(g,0,-76,22,rn+hexA(ef*120))}}
 else{const hh=lh*(-ch)+8;g.fillStyle=vgr(g,-70-hh-30,-70,wd2,'#0e0816');g.beginPath();g.moveTo(-64,-72);g.lineTo(-58,-72-hh-20);g.lineTo(58,-72-hh-20);g.lineTo(64,-72);g.closePath();g.fill();g.strokeStyle=band;g.lineWidth=4;g.stroke()}
 g.restore();g.restore()}
/* keep the Eclipse chest, weapon crate and the rest exactly as they were */
{const c0=chest;chest=function(g,x,y,s,u,k,t){if(k==='h')return hwChest(g,x,y,s,u,t);return c0(g,x,y,s,u,k,t)}}
/* the Graveyard crate's Mythic reveal swaps the rainbow for the graveyard palette: witch-fire green, curse purple and pumpkin orange */
{const h0=hsx;hsx=function(h,s,l){if(S&&S.cr2&&S.cr2.ck==='h'&&S.cr2.tier>=5){const u=(((h%360)+360)%360)/360*3,i=Math.floor(u)%3,f=u-Math.floor(u),k=f<.72?0:(f-.72)/.28,e=k*k*(3-2*k),H=[150,275,388,510];h=H[i]+(H[i+1]-H[i])*e}return h0(h,s,l)}}
