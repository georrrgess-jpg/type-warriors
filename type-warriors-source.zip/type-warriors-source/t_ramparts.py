# python3 t_ramparts.py [--quick] : Runestone Ramparts 8.8b (95a-95h) - maps, placement, building, cooldown abilities, health, coins,
# tutorials, rewards, menus and hooks, plus a bot (no typing: it builds, upgrades and uses abilities) that plays every map to check the
# balance (a sensible build wins every map; a lazy one wins map 1 but not map 3).
import asyncio,os,sys
from playwright.async_api import async_playwright
QUICK='--quick' in sys.argv
BOT=r"""
window.rpBot=function(id,opt){opt=opt||{};rpStart(id);const R=RPX;R.spd=3;const T=RPP().tut;for(const k of['build','wave','coins','upgrade','abil','twist_frost','twist_ember','twist_wonder'])T[k]=1;R.tut=null;R.hold=false;
 const order=opt.order||['ballista','brazier','frost','bell'];let bi=0,steps=0;const top=RP_MAXT(R.map),maxW=opt.maxW||999;
 const cov=p=>{let n=0;for(const q of R.G.U){if((q.x-p.x)**2+((q.y-p.y)/.75)**2<210*210)n++}return n};
 const pads=[...R.pads].sort((a,b)=>cov(b)-cov(a));
 const act=()=>{for(let k=0;k<6;k++){const free=pads.find(p=>!p.tw);const t=order[bi%order.length];
   if(free&&R.supply>=rpCost(t,1)&&(!opt.maxT||R.pads.filter(p=>p.tw).length<opt.maxT)){rpBuild(free,t);bi++;continue}
   if(!free||opt.up){const tw=R.pads.filter(p=>p.tw&&p.tw.tier<top).map(p=>p.tw).sort((a,b)=>a.tier-b.tier)[0];if(tw&&R.supply>=rpCost(tw.type,tw.tier+1)+(free?rpCost(order[bi%order.length],1):0)){rpUpgrade(tw);continue}}
   break}R.sel=null};
 while(!R.over&&steps<30*60*90){steps++;
  if(R.wst==='build'){if(R.wave>=maxW){rpFinish(true);break}act();rpWaveStart()}
  if(R.wst==='done'){if(!R.over){rpFinish(R.won)}break}
  if(!opt.noAbil&&R.wst==='run'){const live=R.foes.filter(e=>!e.dead&&e.s>0).length;
   if(R.abCd.repair<=0&&R.hp<=RPT.HP-4)rpAbility('repair',true);
   if(R.abCd.slow<=0&&live>6)rpAbility('slow',true);
   if(R.abCd.over<=0&&live>3)rpAbility('over',true)}
  if(R.wst==='run'&&steps%30===0)act();
  rpUpdate(1/30)}
 return{id,won:!!R.won,hp:R.hp,wave:R.wave,stars:R.result?R.result.stars:0,kills:R.kills,leaked:R.leaked,towers:R.pads.filter(p=>p.tw).map(p=>p.tw.type.slice(0,2)+p.tw.tier).join(' '),time:Math.round(R.time),coins:R.result?R.result.total:0,run:R.result?R.result.run:0,held:R.result?R.result.held:null,abil:R.abil}};
"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        pg.on('console',lambda m:er.append('CE '+m.text[:300]) if m.type=='error' and 'ERR_' not in m.text else None)
        await pg.goto('file://'+os.path.abspath('out.html'));await pg.wait_for_timeout(1200);E=pg.evaluate;bad=0
        def chk(n,v,ok):
            nonlocal bad
            if not ok:bad+=1
            print(n,v,'OK' if ok else 'BAD')
        await E("()=>{RS_ASK=false;WCRELAYS=[];P.gold=1000;delete P.rp;save();title()}");await pg.wait_for_timeout(400)
        await E("()=>{"+BOT+"}")
        # menus and hooks
        r=await E("async()=>{const sl=ms=>new Promise(r=>setTimeout(r,ms));title();await sl(400);const card=!!document.querySelector('#dkrp');modeSheet();await sl(400);const ms=!!document.querySelector('#dmrp');dkClose(true);await sl(200);"
          "title();await sl(300);document.dispatchEvent(new KeyboardEvent('keydown',{key:'u'}));window.dispatchEvent(new KeyboardEvent('keydown',{key:'u'}));await sl(500);const hub=!!document.querySelector('.rphub');"
          "return [card,ms,hub,ov.querySelectorAll('.rpnode').length,ov.querySelectorAll('.rpnode.lock').length,ov.querySelectorAll('.rptk').length,!!$('rpprev'),!!document.querySelector('#rpnri canvas')]}")
        chk('home card, Choose-mode card, U key opens the world hub: 4 regions (3 locked), armory track, preview, next region',r,r[:3]==[True,True,True] and r[3]==4 and r[4]==3 and r[5]==5 and r[6] and r[7])
        r=await E("()=>[!!ov.querySelector('.rpnode.myst[data-m=wonder]'),ov.querySelector('.rpnode[data-m=wonder] b').textContent,RP_MAPOPEN(RP_MAP('wonder'))]")
        chk('the Wonderland starts as a question-marked mystery and stays locked until Ember Crown is won',r,r==[True,'? ? ?',False])
        r=await E("()=>{$('rphow').click();const a=!$('rpmod').hidden&&/How to play/.test($('rpmod').textContent)&&!/[Tt]ype the word/.test($('rpmod').textContent);$('rpmx').click();$('rpvr').click();const b=ov.querySelectorAll('#rpmod .rpsk.lock').length;$('rpmx').click();return [a,b,$('rpmod').hidden]}")
        chk('How to play (no typing) and View rewards (5 locked rewards) open and close',r,r==[True,5,True])
        r=await E("()=>{const L=[...ov.querySelectorAll('.rphub button')].map(e=>e.getBoundingClientRect()).filter(r=>r.width>0);let n=0;for(let i=0;i<L.length;i++)for(let j=i+1;j<L.length;j++){const a=L[i],c=L[j];if(a.left<c.right-1&&c.left<a.right-1&&a.top<c.bottom-1&&c.top<a.bottom-1)n++}return [ov.querySelectorAll('.fback').length,n,!!$('rphback')]}")
        chk('hub: one Back button (no shell duplicate), no overlapping buttons',r,r==[0,0,True])
        r=await E("async()=>{const r0=RS;rpStart('moss');RPX.tut=null;RS=1.5;cv.width=2400;cv.height=1350;await new Promise(r=>setTimeout(r,300));const g=cv.getContext('2d'),a=[g.getImageData(2396,1346,1,1).data[3],g.getImageData(2396,4,1,1).data[3]];rpLeave();RS=r0;applyLayout();return a}")
        chk('the battle fills the whole canvas at a render scale above 1 (no menu background showing through)',r,r==[255,255])
        await E("()=>{title();rampartsMenu(title)}")
        r=await E("()=>{const el=ov.querySelector('.rptitle'),rg=document.createRange();rg.selectNodeContents(el);return [el.textContent,rg.getBoundingClientRect().right<560]}")
        chk('the mode is called Runestone Tower Defense on its menu, and the title fits',r,r==['RunestoneTower Defense',True])
        r=await E("()=>{const T=RPP().tut;for(const k of['build','wave','coins','upgrade','abil'])T[k]=1;rpStart('moss');const R=RPX;R.tut=null;inp.focus();const a=document.activeElement===inp;const g=cv.getContext('2d');R.shake=24;R.hitFl=1;rpDraw();const p1=g.getImageData(5,5,1,1).data.join();rpDraw();const p2=g.getImageData(5,5,1,1).data.join();const p3=g.getImageData(cv.width-5,cv.height-5,1,1).data.join();R.shake=0;R.hitFl=0;rpDraw();const p4=g.getImageData(cv.width-5,cv.height-5,1,1).data.join();rpLeave();return [a,p1===p2,p3===p4]}")
        chk('in battle the hidden typing box never takes focus, and hits no longer shake or tint the whole screen (no jolt or zoom)',r,r==[False,True,True])
        await E("()=>{title();rampartsMenu(title)}")
        # maps
        for m in ['moss','frost','ember','wonder']:
            r=await E(f"""()=>{{const map=RP_MAP('{m}'),G=rpGeo(map),B=rpBake(map),c=B.cast,BX=RP_PADBOX;let worst=1e9,sp=1e9,box=true,wet=false,vent=false,cast=false;
              for(const p of G.pads){{worst=Math.min(worst,G.dRoad(p.x,p.y));if(p.x<BX.x0||p.x>BX.x1||p.y<BX.y0||p.y>BX.y1)box=false;if(G.dRiver(p.x,p.y)<70||G.inLake(p.x,p.y,30))wet=true;if((map.vents||[]).some(v=>Math.hypot(v[0]-p.x,v[1]-p.y)<80))vent=true;if(p.x+50>c.x)cast=true;
               for(const q of G.pads)if(q!==p)sp=Math.min(sp,Math.hypot(q.x-p.x,(q.y-p.y)*1.15))}}
              const g=G.paths[0].S[G.paths[0].S.length-1];return [G.pads.length,Math.round(worst),Math.round(sp),box,wet,vent,cast,G.paths.length,G.ent.length,B.c.width+'x'+B.c.height,Math.round(g.x)+','+Math.round(g.y),c.w>0]}}""")
            want={'moss':(1,1),'frost':(2,2),'ember':(2,1),'wonder':(2,2)}[m]
            chk(f'{m}: 12+ pads off the roads, inside the safe box, clear of water/lava/vents/castle, spaced; {want[0]} road(s), {want[1]} cave(s); full 1600x900 bake; gate at the road end',r,
                r[0]>=12 and r[1]>=78 and r[2]>=138 and r[3] and not r[4] and not r[5] and not r[6] and r[7]==want[0] and r[8]==want[1] and r[9]=='1600x900' and abs(int(r[10].split(',')[0])-1450)<=6 and abs(int(r[10].split(',')[1])-628)<=6 and r[11])
        r=await E("()=>{const G=rpGeo(RP_MAP('moss'));let n=0;for(const q of G.U)if(G.dRiver(q.x,q.y)<40)n++;const F=rpGeo(RP_MAP('frost'));let ice=0;for(const P of F.paths)for(const v of P.ice)ice+=v;return [n>0,ice>0,RP_MAP('ember').vents.length,typeof rpCastleArt,typeof rpWorldArt]}")
        chk('Mossgate road crosses the river (bridge), Frostfang has ice on the road, Ember Crown has 3 vents; castle and world art present',r,r==[True,True,True,3,'function','function'] or (r[0] and r[1] and r[2]==3 and r[3]=='function' and r[4]=='function'))
        # no typing; keys
        r=await E("()=>{rpStart('moss');const R=RPX;R.tut=null;R.hold=false;const s0=R.supply;for(const k of 'asdfghjklzxcvbnm')window.dispatchEvent(new KeyboardEvent('keydown',{key:k}));const a=[R.supply===s0,R.word===undefined,R.cmd===undefined];window.dispatchEvent(new KeyboardEvent('keydown',{key:'q'}));const b=R.place;window.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape'}));return [...a,b,R.place]}")
        chk('letters do nothing (no typing, no Command); Q picks the Rune Ballista, Esc cancels',r,r==[True,True,True,'ballista',None])
        r=await E("()=>{const R=RPX;R.supply=999;window.dispatchEvent(new KeyboardEvent('keydown',{key:'t'}));const a=R.place;R.place=null;return [a,RPTW.brazier.n,document.querySelectorAll('.rpbar .rpcard').length,RP_TW.prism.cost[0]===Math.max(...RP_TWORDER.filter(t=>t!=='dragon'&&t!=='tide'&&t!=='mortar'&&t!=='star').map(t=>RP_TW[t].cost[0])),RP_TW.prism.cost[4]===Math.max(...RP_TWORDER.filter(t=>t!=='dragon'&&t!=='tide'&&t!=='mortar'&&t!=='star').map(t=>RP_TW[t].cost[4]))]}")
        chk('T picks the Celestial Prism (the most expensive of the five base towers at every tier; the Dragon Roost, the 600 Tidecaller and the 550 Thunder Mortar and the 450 Starfall Observatory cost more); the Ember Blazer is renamed; ten tower cards',r,r==['prism','Ember Blazer',10,True,True])
        # building
        r=await E("()=>{const R=RPX;const s0=R.supply,p=R.pads[0];const ok=rpBuild(p,'ballista');const s1=R.supply;const b0=p.tw.build;R.supply+=400;const up=rpUpgrade(p.tw);const s2=R.supply;const spent=p.tw.spent;const anim=[p.tw.upK,p.tw.from];rpSell(p.tw);return [ok,s0-s1,b0,s1+400-s2,R.supply-s2,Math.round(spent*.7),!p.tw,anim[0],anim[1]]}")
        chk('build costs 100 and starts its build animation; upgrade 150 plays the upgrade animation; selling refunds 70%',r,r[0] and r[1]==100 and r[2]==0 and r[3]==150 and r[4]==r[5] and r[6] and r[7]==0 and r[8]==1)
        r=await E("()=>{const R=RPX;R.supply=50;const ok=rpBuild(R.pads[1],'frost');return [ok,R.supply,!!R.pads[1].tw]}")
        chk('cannot build without supply',r,r==[False,50,False])
        r=await E("()=>{const R=RPX;R.supply=1000;const p=R.pads[2];rpBuild(p,'ballista');const tw=p.tw;let fired=false;const e=rpSpawn('scamp');const q=rpAt(R.G,0);e.s=40;R.wst='run';R.wave=1;tw.cd=0;for(let i=0;i<20;i++){rpStep(R,1/60);if(tw.fire>0)fired=true}const b1=tw.build;for(let i=0;i<70;i++)rpUpdate(1/60);return [fired,b1<1,tw.build]}")
        chk('a tower under construction does not fire; the build finishes in about a second',r,r==[False,True,1])
        await E("()=>{rpLeave();rpStart('moss');RPX.tut=null}")
        # placement and picking
        r=await E("()=>{const R=RPX;R.supply=1000;const p=R.pads[3];rpPlace('frost');const g=rpSnap(R,p.x+30,p.y-20);rpClick(p.x+30,p.y-20,0);const built=!!p.tw&&p.tw.type==='frost';const after=R.place;rpPlace('bell');const far=rpSnap(R,5,5);rpClick(5,5,0);return [g===p,built,after,far,R.place]}")
        chk('placing snaps to the nearest free pad, one click builds once and ends placing; a click away from pads cancels',r,r==[True,True,None,None,None])
        r=await E("()=>{const R=RPX;const p=R.pads[3];const a=rpPick(R,p.x,p.y-60)===p,bb=rpPick(R,p.x+200,p.y+200);const fr=R.pads.find(q=>!q.tw&&R.pads.every(o=>o===q||Math.hypot(o.x-q.x,o.y-q.y)>150));const c=rpPick(R,fr.x+5,fr.y+4)===fr,d=rpPick(R,fr.x,fr.y-70);return [a,bb===null||bb!==p,c,d]}")
        chk('the tower body picks its tower; an empty pad picks only on its stone top (no stray hits above it)',r,r[0] and r[1] and r[2] and r[3] is None)
        r=await E("async()=>{const R=RPX;const p=R.pads[3];p.tw.build=1;rpClick(p.x,p.y-50,0);await new Promise(r=>setTimeout(r,150));const el=$('rpinfo'),btn=$('rpup');p.tw.kills+=3;R.supply+=500;await new Promise(r=>setTimeout(r,200));return [R.sel===p.tw,!el.hidden,btn===$('rpup'),/3 defeated/.test(el.textContent),$('rpup').classList.contains('no')]}")
        chk('clicking a tower opens its panel; kills and supply patch it in place (no re-render under the pointer)',r,r==[True,True,True,True,False])
        r=await E("async()=>{const R=RPX;R.sel=null;const p=R.pads.find(q=>!q.tw);rpClick(p.x,p.y,0);await new Promise(r=>setTimeout(r,150));const n=document.querySelectorAll('#rpring .rprb').length;document.querySelector('#rpring .rprb[data-tw=\"brazier\"]').click();await new Promise(r=>setTimeout(r,100));return [n,p.tw&&p.tw.type,R.selPad,$('rpring').hidden]}")
        chk('clicking an empty pad opens the build ring (ten towers); a ring button builds there',r,r==[10,'brazier',None,True])
        for m in ['moss','frost','ember','wonder']:
            r=await E(f"async()=>{{rpLeave();rpStart('{m}');const R=RPX;R.tut=null;R.supply=5000;const lows=[...R.pads].sort((a,b)=>b.y-a.y).slice(0,3);let worst=-1e9;for(const p of lows){{rpBuild(p,'ballista');p.tw.build=1;R.sel=p.tw;await new Promise(r=>setTimeout(r,90));const a=$('rpsell').getBoundingClientRect(),u=$('rpup').getBoundingClientRect(),b=document.querySelector('.rpbar').getBoundingClientRect(),w=$('rpinfo').getBoundingClientRect();worst=Math.max(worst,a.bottom-b.top,w.bottom-b.top)}}return Math.round(worst)}}")
            chk(f'{m}: the tower panel (with Sell) stays clear of the bottom bar for the lowest pads',r,r<0)
        await E("()=>{rpLeave();rpStart('moss');RPX.tut=null;const R=RPX;R.supply=1000;const p=R.pads[3];rpBuild(p,'frost');p.tw.build=1;R.wave=1;R.cd=1e9;R.q=[]}")
        # abilities on cooldowns
        r=await E("()=>{const R=RPX;R.wave=1;R.cd=1e9;R.q=[];const a=rpAbility('repair',true);R.hp=12;const b=rpAbility('repair',true);const h1=R.hp,cd=R.abCd.repair;const c=rpAbility('repair',true);R.hp=10;for(let i=0;i<60*71;i++)rpStep(R,1/60);const d=rpAbility('repair',true);return [a,b,h1,cd,c,d,R.hp]}")
        chk('Repair: refused at full health, heals 4, recharges in 70 s',r,r==[False,True,16,70,False,True,14])
        r=await E("()=>{const R=RPX;const tw=R.pads[3].tw;R.sel=tw;const a=rpAbPress('over');const o=tw.over,cd=R.abCd.over;const b=rpAbility('over',tw);R.sel=null;return [a,o,cd,b]}")
        chk('Overcharge powers the selected tower for 10 s, then recharges (45 s)',r,r==[True,10,45,False])
        r=await E("()=>{const R=RPX;R.abCd.over=0;R.sel=null;const a=rpAbPress('over');const aim=R.aim;const p=R.pads[3];rpClick(p.x,p.y-50,0);return [a,aim,R.aim,p.tw.over>0]}")
        chk('without a selection Overcharge asks for a tower, a click on one applies it',r,r==[False,'over',None,True])
        r=await E("()=>{const R=RPX;const a=rpAbPress('slow');const aim=R.aim;rpClick(5,5,0);const n0=R.fields.length;const q=R.G.S[200];rpClick(q.x,q.y,0);return [a,aim,n0,R.fields.length,R.abCd.slow]}")
        chk('Slow Field: aim, refuses off the road, placed on the road, 40 s recharge',r,r==[False,'slow',0,1,40])
        # waves, paths, twists
        await E("()=>{rpLeave();const T=RPP().tut;for(const k of['build','wave','coins','upgrade','abil','twist_frost','twist_ember'])T[k]=1;rpStart('frost');RPX.tut=null}")
        r=await E("()=>{const R=RPX;R.pads.forEach(p=>{});rpWaveStart();const seen={};let ice=0,fast=0;for(let i=0;i<60*14;i++){rpUpdate(1/60);for(const e of R.foes){seen[e.pi]=1;if(e.ice)ice++}}return [R.wave,R.wst,Object.keys(seen).sort().join(''),ice>0]}")
        chk('Frostfang: monsters come from both caves and hit the icy patches',r,r[0]==1 and r[2]=='01' and r[3])
        r=await E("()=>{const R=RPX;const e=rpSpawn('scamp',0);const i=R.G.paths[0].ice.findIndex(v=>v);e.s=i*4;e.slowT=0;const s0=e.s;R.fields=[];rpStep(R,.1);const on=e.s-s0;const f=rpSpawn('scamp',0);f.sp=e.sp;f.s=20;rpStep(R,.1);const off=f.s-20;return [on>off*1.3]}")
        chk('ice makes monsters faster',r,r==[True])
        await E("()=>{rpLeave();rpStart('ember');RPX.tut=null}")
        r=await E("()=>{const R=RPX;rpWaveStart();const v=R.vents[0];const p=rpAt(R.G,0,0);const e=rpSpawn('golem',0);let best=0,bd=1e9;for(let s=0;s<R.G.paths[0].len;s+=4){const q=rpAt(R.G,s,0);const d=Math.hypot(q.x-v.x,q.y-v.y);if(d<bd){bd=d;best=s}}e.s=best;e.sp=0;e.off=0;const h0=e.hp;v.t=0;for(let i=0;i<60;i++)rpStep(R,1/60);return [Math.round(bd),h0-e.hp>0,e.pi]}")
        chk('Ember Crown: a lava vent erupts and scorches a monster on the road beside it',r,r[1])
        r=await E("()=>{const R=RPX;const seen={};for(let i=0;i<60*8;i++){rpUpdate(1/60);for(const e of R.foes)seen[e.pi]=1}return Object.keys(seen).sort().join('')}")
        chk('Ember Crown: monsters split between both forks',r,r=='01')
        # tiers 4 and 5, the Celestial Prism, the endless Wonderland
        r=await E("()=>{rpLeave();rpStart('ember');const R=RPX;R.tut=null;R.supply=99999;const p=R.pads[0];rpBuild(p,'ballista');p.tw.build=1;rpUpgrade(p.tw);rpUpgrade(p.tw);const t3=p.tw.tier,more=rpUpgrade(p.tw);return [t3,more,p.tw.tier,RP_MAXT(R.map)]}")
        chk('outside the Wonderland towers stop at tier 3',r,r==[3,False,3,3])
        r=await E("()=>{rpLeave();const st=RPP().stars;st.ember=st.ember||1;RPP().asc={};rpStart('wonder');const R=RPX;R.tut=null;R.hold=false;R.supply=99999;const p=R.pads[0];rpBuild(p,'bell');p.tw.build=1;for(let k=0;k<4;k++)rpUpgrade(p.tw);return [RP_MAXT(R.map),p.tw.tier,p.tw.upD,RPP().asc.bell,!!R.banner&&R.banner.txt]}")
        chk('in the Wonderland towers ascend to tiers 4 and 5 (a longer ascension, recorded in the Ascended collection)',r,r==[5,5,1.4,5,'Ascended!'])
        r=await E("async()=>{rpLeave();rpStart('wonder');const R=RPX;R.tut=null;R.hold=false;R.supply=1e6;const g=cv.getContext('2d'),out=[];for(const [i,t] of ['ballista','brazier','frost','bell','prism'].entries()){const p=R.pads[i];rpBuild(p,t);const tw=p.tw;tw.build=1;rpUpgrade(tw);rpUpgrade(tw);tw.upK=1;rpUpgrade(tw);let mn=1e9;for(const k of [.05,.3,.6,.9]){tw.upK=k;g.setTransform(RS,0,0,RS,0,0);g.clearRect(0,0,1600,900);rpTowerAt(g,R,tw);const d=g.getImageData((tw.x-60)*RS,(tw.y-150)*RS,120*RS,190*RS).data;let n=0;for(let q=3;q<d.length;q+=16)if(d[q]>20)n++;mn=Math.min(mn,n)}out.push(mn)}return out}")
        chk('towers stay visible through the whole tier 4 and 5 ascension (no clash with the art\'s rpAscend)',r,min(r)>1000)
        r=await E("async()=>{const R=RPX;const tw=R.pads[0].tw;R.supply=1e6;R.sel=tw;await new Promise(r=>setTimeout(r,150));const a=$('rpup')&&!$('rpup').classList.contains('no');R.supply=0;await new Promise(r=>setTimeout(r,150));const b=$('rpup')&&$('rpup').classList.contains('no');R.supply=1e6;rpUpgrade(tw);await new Promise(r=>setTimeout(r,150));const c=tw.tier===5&&!$('rpup');R.sel=null;return [tw.tier,a,b,c]}")
        chk('the Upgrade button to tiers 4 and 5 is lit when affordable and greyed only when it is not',r,r==[5,True,True,True])
        await E("()=>{rpLeave();rpStart('wonder');const R=RPX;R.tut=null;R.hold=false;R.supply=99999;const p=R.pads[0];rpBuild(p,'bell');p.tw.build=1;for(let k=0;k<4;k++)rpUpgrade(p.tw)}")
        r=await E("()=>{const R=RPX;const p=R.pads[1];rpBuild(p,'prism');const tw=p.tw;tw.build=1;R.wst='run';R.wave=1;R.q=[];const tgt=[];let best=0,bd=1e9,bp=0;R.G.paths.forEach((P2,pi)=>{for(let s=0;s<P2.len;s+=8){const q=rpAt(R.G,s,pi);const d=Math.hypot(q.x-p.x,(q.y-p.y)/.75);if(d<bd){bd=d;best=s;bp=pi}}});for(let k=0;k<3;k++){const e=rpSpawn('golem',bp);e.sp=0;e.s=best+k*12;e.hp=e.mx=1e6;tgt.push(e)}for(let i=0;i<6;i++)rpStep(R,1/60);const e0=tw.beams[0].e,h0=e0.hp,r0=tw.beams[0].ramp;for(let i=0;i<120;i++)rpStep(R,1/60);const d1=h0-e0.hp,r1=tw.beams[0].ramp;const h1=e0.hp;for(let i=0;i<60;i++)rpStep(R,1/60);const d2=h1-e0.hp;const n1=tw.beams.length;rpUpgrade(tw);tw.upK=1;for(let i=0;i<4;i++)rpStep(R,1/60);return [n1,tw.beams.length,r1>r0,d2>d1/2*1.15,tw.fire]}")
        chk('the Celestial Prism holds a beam that ramps up (more damage per second over time); tier 2 adds a second beam',r,r[0]==1 and r[1]==2 and r[2] and r[3] and r[4]==1)
        r=await E("()=>{const R=RPX;const tw=R.pads[1].tw;while(tw.tier<5)rpUpgrade(tw);tw.upK=1;for(let i=0;i<3;i++)rpStep(R,1/60);tw.nova=0.01;const e=tw.beams&&tw.beams[0]&&tw.beams[0].e;const h0=e?e.hp:0;const n0=R.rings.filter(r=>r.nova).length;for(let i=0;i<3;i++)rpStep(R,1/60);return [tw.tier,R.rings.filter(r=>r.nova).length>n0,e&&h0-e.hp>200]}")
        chk('a tier-5 prism releases a supernova that hurts everything near it',r,r==[5,True,True])
        r=await E("()=>{const W=RP_MAP('wonder'),E2=RP_MAP('ember');const g=w=>rpHpK(W,w)/rpHpK(W,w-1),cnt=w=>rpWave(W,w).reduce((a,x)=>a+x.n,0);return [Math.abs(rpHpK(W,10)-rpHpK(E2,10))<1e-9,g(16)>1.03&&g(30)>1.03&&g(60)>1.02&&rpHpK(W,30)>3*rpHpK(W,15),cnt(30)>cnt(15),rpWave(W,20).some(x=>x.id==='behemoth'),rpWave(W,21).some(x=>x.id==='behemoth')]}")
        chk('endless: plays like Ember Crown up to wave 15, then every wave grows harder (more hit points and monsters); a boss every 10 waves',r,r==[True,True,True,True,False])
        r=await E("async()=>{rpLeave();rpStart('wonder');const R=RPX;R.tut=null;R.hold=false;R.wave=15;R.wst='run';R.q=[];R.foes=[];rpStep(R,1/60);const a=[R.wst,R.won===true];R.coins=321.7;const b0=RPP().ebest=7,g0=P.gold;R.hp=0;rpDefeat();await new Promise(r=>setTimeout(r,2600));const r2=R.result;return [...a,r2&&r2.endless,r2&&r2.held,RPP().ebest,r2&&r2.run,!!document.querySelector('.rpebig')]}")
        chk('endless: wave 15 is no victory; when the palace falls the waves held, the best run and the coins are recorded',r,r==['build',False,1,15,15,321,True])
        # health, coins, defeat
        await E("()=>{rpLeave();delete P.rp;const T=RPP().tut;for(const k of['build','wave','coins','upgrade','abil','twist_frost','twist_ember'])T[k]=1;rpStart('moss');RPX.tut=null}")
        r=await E("()=>{const R=RPX;rpWaveStart();const c0=R.coins,s0=R.supply;const e=R.foes[0]||rpSpawn('scamp');e.s=10;rpHurt(e,9999,99,null);return [R.coins-c0,R.supply-s0>0,R.kills]}")
        chk('a kill pays supply and coins',r,r[0]==2 and r[1] and r[2]==1)
        r=await E("()=>{const R=RPX;R.q=[];for(const e of R.foes)e.dead=1;R.foes=[];const c0=R.coins;rpStep(R,1/60);return [R.wst,R.coins-c0,rpWaveCoins(R.map,1)]}")
        chk('clearing a wave pays wave coins',r,r[0]=='build' and r[1]==r[2] and r[1]>0)
        r=await E("()=>{const R=RPX;rpWaveStart();R.pads.forEach(p=>{if(p.tw)p.tw.cd=99});const h0=R.hp;for(let i=0;i<60*40;i++)rpUpdate(1/60);return [h0-R.hp,R.leaked]}")
        chk('monsters that reach the castle cost health',r,r[0]>0 and r[1]>0)
        r=await E("()=>{const R=RPX;R.hp=1;const e=rpSpawn('golem');e.s=R.G.len-1;for(let i=0;i<60*2;i++)rpUpdate(1/60);return [R.hp,R.wst]}")
        chk('the castle falls at 0 health and the run ends',r,r==[0,'done'])
        await pg.wait_for_timeout(2800)
        r=await E("()=>{const r=RPX&&RPX.result;return r?[r.won,r.stars,r.total===r.run,r.run>0,!!document.querySelector('.rpres')]:null}")
        chk('a loss pays the coins earned so far, no stars, shows the result',r,r==[False,0,True,True,True])
        r=await E("()=>{rpLeave();title();return [S.rp,RPX===null,S.mode,$('rphud')?$('rphud').hidden:true]}")
        chk('leaving clears the run and the HUD',r,r==[0,True,'title',True])
        # rewards
        r=await E("()=>{const g0=P.gold;rpStart('moss');const R=RPX;R.coins=100;R.wave=10;R.hp=19;rpVictory();rpFinish(true);const r=R.result;return [r.won,r.stars,r.first,r.win===Math.round(rpWinCoins(R.map,3)*1.5),P.gold-g0===r.total,r.total===100+r.win,RPP().stars.moss,RP_MAPOPEN(RP_MAPS[1])]}")
        chk('victory at 19 health: 3 stars, run coins + victory bonus x1.5 first win today, opens map 2',r,r==[True,3,True,True,True,True,3,True])
        r=await E("()=>{rpLeave();rpStart('moss');const R=RPX;R.wave=10;R.hp=9;rpVictory();rpFinish(true);return [R.result.stars,R.result.first,RPP().stars.moss,R.result.win===rpWinCoins(R.map,1)]}")
        chk('a second win the same day: 1 star does not lower the best, no daily bonus',r,r==[1,False,3,True])
        r=await E("()=>{const r=RPP();r.stars={moss:3,frost:3,ember:3};const u=rpUnlockSweep();return [u.map(s=>s.k),rpStarN()>=RP_TITLE_NEED]}")
        r2=await E("()=>RP_SKINS.every(s=>RPP().own[s.tw+':'+s.k])")
        chk('stars unlock the four tower skins (only here) and reach the title',[r,r2],r2 and 'thunderking' in r[0] and r[1])
        r=await E("()=>{const r=RPP();r.skin.ballista='gilded';save();const a=rpSkinOf('ballista');r.own['ballista:gilded']=0;const b=rpSkinOf('ballista');r.own['ballista:gilded']=1;return [a,b]}")
        chk('equipped skin needs ownership',r,r==['gilded','base'])
        r=await E("()=>{rpLeave();rpStart('moss');const R=RPX;R.tut=null;R.wave=10;R.hp=20;rpVictory();rpFreeplay();R.supply=99999;R.spd=3;for(const p of R.pads)if(!p.tw)rpBuild(p,'ballista');for(const p of R.pads){p.tw.build=1;rpUpgrade(p.tw);rpUpgrade(p.tw)}const c0=R.coins;for(let i=0;i<30*60*8;i++){if(R.wst==='build')rpWaveStart();rpUpdate(1/30);if(R.fpWaves>=3)break}const c1=R.coins;R.hp=0;rpDefeat();rpFinish(true);return [R.free,R.fpWaves>=3,c1-c0>100,R.result.won,R.result.run===Math.floor(c1),R.result.stars]}")
        chk('freeplay after a win keeps paying coins per kill and wave with no cap, keeps the win and its stars',r,r[0] and r[1] and r[2] and r[3] and r[4] and r[5]==3)
        # tutorials
        r=await E("async()=>{rpLeave();RPP().tut={};rpStart('moss');await new Promise(r=>setTimeout(r,1000));const R=RPX;const a=R.tut,v=!$('rptut').hidden;R.supply=500;rpBuild(R.pads[0],'ballista');await new Promise(r=>setTimeout(r,120));const b=RPP().tut.build;await new Promise(r=>setTimeout(r,1100));const c=R.tut;rpWaveStart();await new Promise(r=>setTimeout(r,120));return [a,v,b,c,RPP().tut.wave]}")
        chk('first-time tutorials: build tip shows, closes when a tower is built, then the start-wave tip',r,r==['build',True,1,'wave',1])
        r=await E("async()=>{const R=RPX;R.pads[0].tw.build=1;const e=rpSpawn('scamp');e.s=20;rpHurt(e,9999,99,null);const a=R.tut,h=R.hold;const t0=R.time;rpUpdate(1/60);const frozen=R.time===t0;$('rptok').click();return [a,h,frozen,R.hold,RPP().tut.coins]}")
        chk('the coins tip pauses the battle until Got it',r,r==['coins',True,True,False,1])
        # pause
        r=await E("async()=>{rpLeave();rpStart('moss');const R=RPX;R.tut=null;rpPause(true);const a=R.pause,b=!!document.querySelector('.rppause');const t0=R.t;rpUpdate(1/60);const c=R.t===t0;rpPause(false);await new Promise(r=>setTimeout(r,100));return [a,b,c,R.pause,$('rphud').hidden]}")
        chk('pause stops time and shows the menu; resume restores the HUD',r,r==[True,True,True,False,False])
        r=await E("()=>{P.rp={stars:{moss:9},skin:'x',own:5,tut:3};const q=RPP();return [q.stars.moss===undefined,typeof q.skin,typeof q.own,typeof q.tut]}")
        chk('save normaliser drops bad values',r,r==[True,'object','object','object'])
        # balance: a bot with a mixed build that upgrades and uses abilities (no typing); map 1 is now a real fight
        await E("()=>{rpLeave();delete P.rp;RPP()}")
        maps=['moss'] if QUICK else ['moss','frost','ember']
        for m in maps:
            r=None
            for k in range(2 if m=='ember' else 1):
                r=await E(f"()=>{{const r=rpBot('{m}',{{up:1}});rpLeave();return r}}")
                if r['won']:break
            chk(f'bot (mixed build, upgrades, abilities) wins {m}'+(' (best of 2: map 3 is hard)' if m=='ember' else ''),r,r['won'])
        r=await E("()=>{const r=rpBot('moss',{noAbil:1,order:['ballista']});rpLeave();return r}")
        chk('a lazy build on map 1 (ballistas only, no abilities) now loses or barely holds (10 health or less)',r,(not r['won']) or r['hp']<=10)
        if not QUICK:
            r=await E("()=>{const r=rpBot('ember',{noAbil:1,order:['ballista'],maxT:4});rpLeave();return r}")
            chk('four ballistas and no abilities are not enough for map 3 (it still needs thought)',r,not r['won'])
            r=await E("()=>{RPP().stars.ember=1;const r=rpBot('wonder',{up:1,maxW:24,order:['ballista','brazier','frost','bell','prism']});rpLeave();return r}")
            chk('endless: a strong build holds past wave 15 (stopped at 24 to keep the test short)',r,(r['held'] or 0)>=16)
        print('bad',bad);print(er[:6]);await b.close()
asyncio.run(main())
