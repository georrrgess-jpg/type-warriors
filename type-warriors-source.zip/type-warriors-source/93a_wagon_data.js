/* ===== LANTERN CARAVAN (Update 8.5): routes, hazards, words, pay, cosmetics and the save =====
   A night-time escort mode. A goblin-driven wagon with a big lantern rolls along a stone bridge toward a village gate.
   The player's hero and pet walk beside it. Monsters come in from the right carrying a word on a sword tag; type it
   and the hero cuts them down. The wheel jams now and then: a wrench bubble with a repair verb appears, type it and
   the wagon rolls on. Monsters that reach the wagon knock off one of four Wagon Integrity shields.
   Prefix: wr. State: WRX (93c). Save: P.wr via WRP(). Art: 93b. UI: 93d/93e. Audio: 93f. */
const WR_VER='8.5';
/* waypoint names light the progress bar as each leg is passed; the last one is the destination */
const WR_ROUTES=[
 {id:'mill',n:'Millbrook Bridge',sub:'to the Village Gate',dest:'Village Gate',legs:3,len:1800,d:1,
  wp:['Old Mill','Weir Bridge','Village Gate'],sky:['#0b0a2a','#2a1b5c'],far:'village',
  mobs:['gob','skel','bat'],haz:['rock','branch'],pay:420,xp:60,unlock:null,
  blurb:'A gentle run over the mill bridge. Goblins and a few bats.'},
 {id:'pines',n:'Hollow Pines',sub:"to the Woodcutter's Rest",dest:"Woodcutter's Rest",legs:4,len:2600,d:2,
  wp:['Fog Hollow','Wolf Run','Old Watchtower',"Woodcutter's Rest"],sky:['#07061e','#1d1448'],far:'forest',
  mobs:['wolf','spid','weaver','gob','shaman','bat'],haz:['rock','branch','mud'],pay:700,xp:100,unlock:{route:'mill',med:1},
  blurb:'Wolves and spiders in the fog. Mud ruts slow the wheels.'},
 {id:'gallows',n:'Gallows Pass',sub:'to Hollowmere Keep',dest:'Hollowmere Keep',legs:5,len:3400,d:3,
  wp:['Hangman\'s Oak','Bone Ford','Wraith Hollow','The Crossing','Hollowmere Keep'],sky:['#060416','#2b0f3a'],far:'keep',
  mobs:['skel','dknight','ghost','hound','garg','gydigger','gywisp'],haz:['rock','branch','mud','cargo'],boss:'bhorse',pay:1050,xp:150,unlock:{route:'pines',med:1},
  blurb:'The dead walk the pass, and the Headless Horseman rides the last mile.'}];
const WR_RT=id=>WR_ROUTES.find(r=>r.id===id)||WR_ROUTES[0];
/* hazards pin to the front wheel; fuse is seconds before the axle cracks (one shield) and the hazard clears itself */
const WR_HAZ={
 rock:{n:'Jammed wheel',verbs:['mend','brace','patch','wedge','lever','pry'],fuse:8,ico:'wrench',say:'The wheel is jammed!'},
 branch:{n:'Fallen branch',verbs:['chop','clear','hack','shove','heave'],fuse:7,ico:'axe',say:'A branch blocks the road!'},
 mud:{n:'Mud rut',verbs:['heave','push','haul','grit','shove'],fuse:9,ico:'boot',say:'Stuck in the mud!'},
 cargo:{n:'Loose cargo',verbs:['lash','tie','strap','cinch','knot'],fuse:6,ico:'rope',say:'The cargo is slipping!'}};
/* word pool for the road (pickWord mixes it with GEN); 3 to 10 letters */
const WR_WORDS=['lantern','wagon','bridge','torch','night','road','gate','wheel','axle','cargo','crate','sack','barrel','rope','reins','harness','hoof','mule','pony',
 'village','mill','river','stone','arch','moon','star','fog','mist','frost','ember','flame','candle','wick','oil','brass','iron','spoke','rim','plank','timber','oak','pine','birch',
 'forest','hollow','pass','ford','ridge','cliff','gorge','marsh','moor','heath','meadow','orchard','hedge','ditch','fence','post','sign','crossroad','milestone','tollgate',
 'guard','watch','sentry','patrol','escort','convoy','caravan','trader','merchant','pedlar','tinker','smith','cooper','miller','baker','inn','tavern','stable','hearth',
 'cloak','hood','boots','gloves','satchel','pouch','purse','coin','silver','gold','copper','ledger','map','compass','whistle','bell','horn','drum','flute',
 'shadow','ghost','wraith','skull','bone','grave','crypt','tomb','howl','growl','snarl','fang','claw','wing','bat','wolf','hound','spider','web','raven','owl','crow',
 'sword','shield','spear','bow','arrow','dagger','axe','mace','helm','armor','plate','mail','buckler','banner','pennant','crest','sigil','oath','vow',
 'brave','bold','steady','swift','quick','sharp','keen','calm','quiet','silent','gentle','stout','sturdy','hardy','rugged','weary','sleepy','drowsy',
 'journey','travel','wander','roam','trek','march','ride','roll','rumble','clatter','creak','squeak','rattle','jolt','bump','lurch','sway','drift',
 'glow','gleam','glimmer','flicker','shine','spark','blaze','kindle','dusk','twilight','midnight','dawn','sunrise','evening','starlight','moonlight','firelight',
 'bramble','thorn','nettle','ivy','moss','fern','reed','rush','willow','alder','hazel','rowan','elder','yew','ash','hawthorn','holly','juniper',
 'hollow','cavern','burrow','den','nest','lair','hideout','ambush','trap','snare','bait','lure','decoy','signal','beacon','warning','alarm',
 'repair','mend','patch','brace','splint','rivet','bolt','nail','hammer','wrench','pliers','chisel','file','rasp','awl','anvil','forge','bellows'];
/* which word length a monster carries: 0 normal, 1 short and fast (flyers), 2 long and slow (tanks) */
const WR_ROLE=id=>{const M=MON[id]||{};return M.fly?1:(id==='dknight'||id==='zomb'||id==='gybrute'||id==='troll')?2:0};
/* ---------- tuning ---------- */
const WRT={
 HX:330,PX:235,WX:640,/* hero, pet and wagon (rear axle) screen x; the world scrolls under them */
 AX:930,/* monsters stop and attack here (the wagon's front) */
 SPAWNX:1690,/* monsters enter from here */
 V:60,VSURGE:132,VGATE:92,/* wagon speed in world units per second */
 FLARE:60,/* meter to fill */
 MAXINT:4,
 HITCD:2.5,/* seconds between a monster's attacks */
 NEAR:140,/* a monster within this of the front stops the wagon */
 FIRSTDAY:1.5};
const WR_MED=[{n:'No medal',c:'#6c6784'},{n:'Bronze',c:'#e0954f'},{n:'Silver',c:'#cfe0f0'},{n:'Gold',c:'#ffc94a'}];
/* bronze: reach the gate; silver: with 2+ shields; gold: 4 of 4 and 92% accuracy */
function wrMedalOf(won,int,acc){if(!won)return 0;if(int>=WRT.MAXINT&&acc>=.92)return 3;if(int>=2)return 2;return 1}
/* pay = route pay x (0.55 + 0.15 x shields) x accuracy factor (0.8 at 70% or less, 1.1 at 100%) */
function wrAccF(acc){const u=Math.max(0,Math.min(1,(acc-.7)/.3));return .8+.3*u}
function wrPayOf(rt,won,int,acc,prog){const base=rt.pay*(.55+.15*int)*wrAccF(acc);return Math.round(won?base:rt.pay*.25*Math.max(0,Math.min(1,prog)))}
/* ---------- cosmetics: lanterns (the bobber), banners (the pennant) and wagon paint ---------- */
const WR_COS={
 lan:{brass:{n:'Brass Lantern',d:'The caravan standard. Warm and steady.',cage:'#d9a441',dark:'#8a5a16',glass:'#ffd98a',glow:'255,190,90',flame:'#ffc23a',need:null},
  ironcage:{n:'Iron Cage',d:'Black iron bars, a cooler white flame.',cage:'#7a7f96',dark:'#2c2f3c',glass:'#e8f2ff',glow:'200,225,255',flame:'#dff4ff',need:{route:'mill',med:1}},
  moonglass:{n:'Moonglass',d:'Pale blue glass that hums at night.',cage:'#b8c8e8',dark:'#4a5a86',glass:'#bfe4ff',glow:'140,200,255',flame:'#9fd8ff',need:{route:'pines',med:2}},
  emberheart:{n:'Emberheart',d:'A deep red coal that never goes out.',cage:'#c66a3a',dark:'#5a2412',glass:'#ff9a6a',glow:'255,120,60',flame:'#ff6a3a',need:{route:'gallows',med:3}},
  wisp:{n:'Wisplight',d:'A bottled graveyard wisp. Green and curious.',cage:'#8ab8a8',dark:'#2a5a4a',glass:'#b8ffd8',glow:'120,255,190',flame:'#8affc8',need:{allmed:2}}},
 ban:{none:{n:'No banner',d:'A bare post.',need:null},
  lanterncaravan:{n:'Lantern Caravan',d:'The guild pennant: a gold lantern on indigo.',c0:'#3a2a7a',c1:'#5a3ab0',emb:'lantern',ec:'#ffd45a',need:{route:'mill',med:1}},
  wolfpine:{n:'Wolf of the Pines',d:'A wolf\'s head on forest green.',c0:'#1f4a3a',c1:'#2f6a4a',emb:'wolf',ec:'#dfe8e0',need:{route:'pines',med:2}},
  gallowsgold:{n:'Gallows Gold',d:'A skull on black, trimmed in gold.',c0:'#1a1020',c1:'#2a1a34',emb:'skull',ec:'#ffd45a',need:{route:'gallows',med:3}},
  royal:{n:'Royal Escort',d:'The crown of Hollowmere. For Caravan Masters.',c0:'#7a1430',c1:'#b02048',emb:'crown',ec:'#ffe08a',need:{allmed:3}}},
 paint:{oak:{n:'Oak',d:'Plain planks, well oiled.',body:'#8a5a2c',dark:'#5a3614',rim:'#4a3020',need:null},
  cherry:{n:'Cherry',d:'Red-stained boards with brass rims.',body:'#a0402c',dark:'#601e14',rim:'#d9a441',need:{route:'pines',med:1}},
  indigo:{n:'Indigo',d:'Deep blue paint, silver rims.',body:'#2e3a8a',dark:'#1a2050',rim:'#cfe0f0',need:{route:'gallows',med:2}},
  gilt:{n:'Gilt',d:'Gold leaf over black lacquer.',body:'#2a2030',dark:'#160e1c',rim:'#ffd45a',need:{allmed:3}}}};
const WR_COSK={lan:Object.keys(WR_COS.lan),ban:Object.keys(WR_COS.ban),paint:Object.keys(WR_COS.paint)};
/* unlock check against the medal table */
function wrNeedOk(need,med){if(!need)return true;med=med||WRP().med;if(need.allmed!=null)return WR_ROUTES.every(r=>(med[r.id]||0)>=need.allmed);return (med[need.route]||0)>=need.med}
function wrNeedTxt(need){if(!need)return'';if(need.allmed!=null)return need.allmed>=3?'Gold on every route':WR_MED[need.allmed].n+' on every route';return `${WR_MED[need.med].n} on ${WR_RT(need.route).n}`}
function wrRouteOpen(rt){return wrNeedOk(rt.unlock)}
/* ---------- save: P.wr ---------- */
function WRP(){let w=P.wr;const D={med:{},best:{},runs:0,clears:0,lan:'brass',ban:'none',paint:'oak',own:{},seen:{},day:'',dayDone:{},seen85:0,intro:0,kills:0,repairs:0,flares:0,gold:0};
 if(!w||typeof w!=='object'||Array.isArray(w))w=P.wr={};
 for(const k in D){const v=w[k],d=D[k];if(typeof d==='number'){if(typeof v!=='number'||!isFinite(v)||v<0)w[k]=0}else if(typeof d==='string'){if(typeof v!=='string')w[k]=d}else{if(!v||typeof v!=='object'||Array.isArray(v))w[k]={}}}
 for(const r of WR_ROUTES){const m=w.med[r.id];w.med[r.id]=typeof m==='number'&&isFinite(m)?Math.max(0,Math.min(3,Math.floor(m))):0;const b=w.best[r.id];if(b!=null&&(typeof b!=='object'||!isFinite(+b.t)))delete w.best[r.id]}
 for(const k of Object.keys(w.med))if(!WR_RT(k)||WR_RT(k).id!==k)delete w.med[k];
 for(const k of Object.keys(w.own))if(!/^(lan|ban|paint):/.test(k)||!WR_COS[k.split(':')[0]][k.split(':')[1]])delete w.own[k];
 for(const f of['lan','ban','paint'])if(!WR_COS[f][w[f]]||!wrOwn(f,w[f],w))w[f]=f==='lan'?'brass':f==='ban'?'none':'oak';
 return w}
function wrOwn(f,k,w){w=w||WRP();const c=WR_COS[f][k];if(!c)return false;return !c.need||!!w.own[f+':'+k]||wrNeedOk(c.need,w.med)}
/* grant everything the medals allow; returns the newly owned [family,key] pairs */
function wrUnlockSweep(){const w=WRP(),out=[];for(const f of['lan','ban','paint'])for(const k of WR_COSK[f]){const c=WR_COS[f][k];if(!c.need||w.own[f+':'+k])continue;if(wrNeedOk(c.need,w.med)){w.own[f+':'+k]=1;w.seen[f+':'+k]=0;out.push([f,k])}}return out}
const wrDay=()=>{const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
