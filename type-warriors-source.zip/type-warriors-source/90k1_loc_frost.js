/* ===== MOONLIT FISHING: Frostfall Lake (fishing spot 'frost') =====
   An icy mountain lake under the northern lights. bg paints the still scene once (sky, peaks, pine forests, the log cabin,
   the snowy pier, shores, snowbanks); back(t) adds the waving aurora (clipped so it stays behind the peaks, pines and the
   cabin), its shimmering reflection on the lake, chimney smoke, bobbing ice floes, lanterns and twinkling stars; front(t)
   adds gentle snowfall and a few drifting sparkles. Every moving part is a sprite cached once (no per-frame gradients). */
let lf_D=null;
const lf_r=s=>{const x=Math.sin(s*78.233+3.17)*43758.5453;return x-Math.floor(x)};
function lf_cv(w,h){const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d');x.lineJoin='round';x.lineCap='round';return[c,x]}
function lf_glow(col,R){const[c,x]=lf_cv(R*2,R*2);const q=x.createRadialGradient(R,R,0,R,R,R);q.addColorStop(0,col+'ff');q.addColorStop(.22,col+'a0');q.addColorStop(.55,col+'30');q.addColorStop(1,col+'00');x.fillStyle=q;x.fillRect(0,0,R*2,R*2);return c}
/* ---------- skyline (where the aurora may show) ---------- */
const lf_SK=new Float32Array(401);
function lf_occ(x0,x1,f){for(let i=Math.max(0,Math.floor(x0/4));i<=Math.min(400,Math.ceil(x1/4));i++){const y=f(i*4);if(y<lf_SK[i])lf_SK[i]=y}}
/* ---------- mountains ---------- */
function lf_peakF(P,base){return x=>{const u=Math.min(1,Math.abs(x-P.x)/P.w),k=x/13,i=Math.floor(k),fr=k-i,j=lf_r(i+P.s)*(1-fr)+lf_r(i+1+P.s)*fr;return P.y+Math.pow(u,.78)*(base-P.y)+(j-.5)*11*Math.min(1,u*4)}}
function lf_peak(g,P,base,C){const f=lf_peakF(P,base),x0=P.x-P.w,x1=P.x+P.w;
 const path=()=>{g.beginPath();g.moveTo(x0,base+3);for(let x=x0;x<=x1;x+=5)g.lineTo(x,f(x));g.lineTo(x1,f(x1));g.lineTo(x1,base+3);g.closePath()};
 lf_occ(x0,x1,f);
 path();g.fillStyle=fkLin(g,0,P.y,0,base,[C.top,C.base]);g.fill();
 const rd=[];for(let y=P.y;y<=base+20;y+=14)rd.push([P.x-(y-P.y)*.16+(y>P.y?(lf_r(y*.37+P.s)-.5)*16:0),y]);
 const ridge=()=>{g.beginPath();g.moveTo(P.x,P.y-30);rd.forEach(p=>g.lineTo(p[0],p[1]));g.lineTo(x0-20,base+20);g.lineTo(x0-20,P.y-30);g.closePath()};
 g.save();path();g.clip();
 ridge();g.fillStyle=C.sh;g.globalAlpha=.6;g.fill();g.globalAlpha=1;
 /* gullies */
 g.strokeStyle=C.sh;g.lineWidth=2;g.globalAlpha=.5;for(let i=0;i<5;i++){const gx=P.x+(lf_r(i+P.s*3)-.4)*P.w*.9,gy=f(gx)+10;g.beginPath();g.moveTo(gx,gy);g.lineTo(gx+(gx>P.x?14:-14),gy+40+lf_r(i+P.s)*50);g.stroke()}g.globalAlpha=1;
 /* snow cap with toothed lower edge */
 const cd=(base-P.y)*C.cap,cap=()=>{g.beginPath();g.moveTo(x0,P.y-40);let i=0;for(let x=x0;x<=x1+1;x+=P.w/9,i++){const u=Math.abs(x-P.x)/P.w;g.lineTo(x,P.y+cd*(1-u*.45)+(i%2?cd*(.45+lf_r(i+P.s)*.5):-cd*.1))}g.lineTo(x1,P.y-40);g.closePath()};
 cap();g.fillStyle=fkLin(g,P.x,P.y,P.x+P.w*.3,P.y+cd*1.4,[C.sn,shade(C.sn,-.12)]);g.fill();
 g.save();cap();g.clip();ridge();g.fillStyle=C.ss;g.fill();g.restore();
 /* snow streaks running down the gullies */
 g.strokeStyle=C.sn;g.lineWidth=2.2;g.globalAlpha=.45;for(let i=0;i<6;i++){const gx=P.x+(lf_r(i+P.s*7)-.5)*P.w*.7,gy=P.y+cd*.9;g.beginPath();g.moveTo(gx,gy);g.lineTo(gx+(gx>P.x?10:-10)*(1+lf_r(i)),gy+20+lf_r(i+3)*cd);g.stroke()}g.globalAlpha=1;
 g.restore();
 /* aurora rim light on the sunlit (right) edge */
 g.strokeStyle=C.rim;g.lineWidth=2;g.globalAlpha=.55;g.beginPath();for(let x=P.x;x<=P.x+P.w*.5;x+=5)x===P.x?g.moveTo(x,f(x)):g.lineTo(x,f(x));g.stroke();g.globalAlpha=1}
/* ---------- pines ---------- */
function lf_pine(g,x,y,h,C,ol){const N=h>140?6:h>60?5:3,w=h*.36;
 if(ol){g.fillStyle='#3a2216';g.fillRect(x-h*.035,y-h*.12,h*.07,h*.14);g.lineWidth=ol*.8;g.strokeStyle=FKO;g.strokeRect(x-h*.035,y-h*.12,h*.07,h*.14)}
 for(let i=N-1;i>=0;i--){const t0=y-h+i*h*.78/N,b0=y-h*.08-(N-1-i)*h*.86/N*.98,hw=w*(.32+.68*(i+1)/N),tw=(b0-t0);
  const tier=()=>{g.beginPath();g.moveTo(x,t0);g.quadraticCurveTo(x+hw*.35,t0+tw*.5,x+hw,b0);const n=4;for(let k=1;k<=n;k++){const xx=x+hw-2*hw*k/n;g.quadraticCurveTo(xx+hw/n,b0+tw*.16,xx,b0)}g.quadraticCurveTo(x-hw*.35,t0+tw*.5,x,t0);g.closePath()};
  tier();g.fillStyle=ol?fkLin(g,x-hw,0,x+hw,0,[C.d,C.l]):C.d;g.fill();if(ol){g.lineWidth=ol;g.strokeStyle=FKO;g.stroke()}
  /* snow drape on the tier */
  g.save();tier();g.clip();g.beginPath();g.moveTo(x,t0-4);g.quadraticCurveTo(x+hw*.4,t0+tw*.45,x+hw+4,b0-tw*.18);const n=5;for(let k=1;k<=n;k++){const xx=x+hw+4-2*(hw+4)*k/n,dy=k%2?tw*.28:tw*.08;g.quadraticCurveTo(xx+hw/n,b0-tw*.1,xx,b0-tw*.32+dy)}g.closePath();g.fillStyle=C.s;g.fill();
  if(ol){g.fillStyle='#7d8cc455';g.beginPath();g.moveTo(x,t0);g.lineTo(x-hw-4,b0);g.lineTo(x-hw*.2,b0);g.closePath();g.fill()}g.restore();
  if(ol){g.lineWidth=ol;g.strokeStyle=FKO;tier();g.stroke()}}}
/* ---------- ice floe ---------- */
function lf_floe(g,cx,cy,w,h,s,ol){const n=11,P=[];for(let i=0;i<n;i++){const a=i/n*TAU,r=.78+lf_r(i+s)*.3;P.push(cx+Math.cos(a)*w/2*r,cy+Math.sin(a)*h/2*r)}
 const d=Math.max(4,h*.32);
 /* submerged ice glow */
 g.save();g.globalAlpha=.32;g.translate(0,d*1.4);fkPath(g,P.map((v,i)=>i%2?cy+(v-cy)*1.25:cx+(v-cx)*1.12));g.fillStyle='#4aa6d8';g.fill();g.restore();
 /* side thickness */
 g.save();g.translate(0,d);fkPath(g,P);g.fillStyle=fkLin(g,0,cy-h/2,0,cy+h/2+d,['#7ac4f0','#2c6aa8']);g.fill();if(ol){g.lineWidth=ol;g.strokeStyle=FKO;g.stroke()}g.restore();
 g.fillStyle='#2c6aa8';g.fillRect(cx-w*.5,cy,0,0);
 fkPath(g,P);g.fillStyle=fkLin(g,cx-w/2,cy-h/2,cx+w/3,cy+h/2,['#f4faff','#cfe2f8','#98bce6']);g.fill();if(ol){g.lineWidth=ol;g.strokeStyle=FKO;g.stroke()}
 /* snow blob, cracks and glint */
 g.save();fkPath(g,P);g.clip();g.fillStyle='#ffffffd0';g.beginPath();g.ellipse(cx-w*.12+lf_r(s+4)*w*.1,cy-h*.12,w*.26,h*.22,0,0,TAU);g.fill();
 g.strokeStyle='#7aa8dc';g.lineWidth=1.3;g.beginPath();const c0=cx+(lf_r(s+2)-.5)*w*.4;g.moveTo(c0,cy-h/2);g.lineTo(c0+w*.06,cy-h*.05);g.lineTo(c0-w*.04,cy+h*.2);g.lineTo(c0+w*.1,cy+h/2);g.moveTo(c0+w*.06,cy-h*.05);g.lineTo(c0+w*.24,cy+h*.04);g.stroke();
 g.strokeStyle='#ffffffc0';g.lineWidth=2;g.beginPath();g.ellipse(cx-w*.06,cy-h*.06,w*.4,h*.34,0,3.4,4.6);g.stroke();g.restore()}
/* ---------- the log cabin (far left) ---------- */
function lf_cabin(g){
 const W0=0,W1=272,TOP=396,BOT=642;
 /* gable-end chimney (stone) behind the roof */
 const ch=()=>{g.beginPath();g.moveTo(196,300);g.lineTo(198,176);g.lineTo(244,176);g.lineTo(246,300);g.closePath()};
 ch();g.fillStyle=fkLin(g,196,0,246,0,['#8a90b4','#565c84']);g.fill();g.save();ch();g.clip();g.strokeStyle='#3a3e62';g.lineWidth=2;
 for(let r=0;r<9;r++){const y=180+r*15;g.beginPath();g.moveTo(190,y);g.lineTo(250,y);g.stroke();for(let k=0;k<3;k++){const x=200+((k*17+(r%2)*8))%46;g.beginPath();g.moveTo(x,y);g.lineTo(x,y+15);g.stroke()}}g.restore();ch();g.lineWidth=3;g.strokeStyle=FKO;g.stroke();
 g.fillStyle='#3a3e62';g.fillRect(192,170,60,10);g.strokeRect(192,170,60,10);
 g.fillStyle='#eef4ff';g.beginPath();g.moveTo(189,172);g.quadraticCurveTo(192,156,214,158);g.quadraticCurveTo(232,150,252,160);g.quadraticCurveTo(258,166,255,173);g.closePath();g.fill();g.lineWidth=2.5;g.stroke();
 lf_occ(190,254,()=>152);
 /* back gable wall (boards) */
 g.beginPath();g.moveTo(W0-14,TOP);g.lineTo(136,262);g.lineTo(W1+14,TOP);g.closePath();g.fillStyle=fkLin(g,0,262,0,TOP,['#7a4e32','#5a3622']);g.fill();
 g.save();g.clip();g.strokeStyle='#3a2216';g.lineWidth=2;for(let x=6;x<W1;x+=17){g.beginPath();g.moveTo(x,250);g.lineTo(x,TOP);g.stroke()}g.restore();
 /* round attic window */
 fkGlow(g,136,336,70,'#ffa040',.35);g.beginPath();g.arc(136,336,25,0,TAU);g.fillStyle=fkRad(g,136,336,25,['#fff0b8','#ffb04a','#e0741c']);g.fill();g.lineWidth=6;g.strokeStyle='#3a2216';g.stroke();g.lineWidth=3;g.beginPath();g.moveTo(111,336);g.lineTo(161,336);g.moveTo(136,311);g.lineTo(136,361);g.stroke();g.lineWidth=2.5;g.strokeStyle=FKO;g.beginPath();g.arc(136,336,28,0,TAU);g.stroke();
 g.fillStyle='#ffffff50';g.beginPath();g.arc(128,328,7,0,TAU);g.fill();
 /* log walls */
 const LH=22;for(let i=0;TOP+i*LH<BOT;i++){const y=TOP+i*LH;g.fillStyle=fkLin(g,0,y,0,y+LH,['#a06a42','#7a4a2c','#4e2e1a']);g.fillRect(W0,y,W1-W0,LH);g.strokeStyle='#2a160c';g.lineWidth=2;g.beginPath();g.moveTo(W0,y+LH);g.lineTo(W1,y+LH);g.stroke();
  g.strokeStyle='#c8905a55';g.lineWidth=1.5;g.beginPath();g.moveTo(W0+4,y+5);g.lineTo(W1-8,y+5);g.stroke();
  /* knots and grain */
  g.strokeStyle='#3a2014aa';g.lineWidth=1.2;for(let k=0;k<3;k++){const kx=20+lf_r(i*3+k)*220;g.beginPath();g.ellipse(kx,y+LH/2,5,2.4,0,0,TAU);g.stroke()}}
 /* log ends at the right corner */
 for(let i=0;TOP+i*LH<BOT;i++){const y=TOP+i*LH+LH/2,x=W1+6+(i%2)*4;g.beginPath();g.ellipse(x,y,12,11.5,0,0,TAU);g.fillStyle=fkRad(g,x,y,12,['#f0c890','#c8945a','#8a5a32']);g.fill();g.lineWidth=2.5;g.strokeStyle=FKO;g.stroke();
  g.strokeStyle='#8a5a32';g.lineWidth=1.2;g.beginPath();g.arc(x,y,7,0,TAU);g.stroke();g.beginPath();g.arc(x,y,3,0,TAU);g.stroke()}
 g.lineWidth=3;g.strokeStyle=FKO;g.beginPath();g.moveTo(W1,TOP);g.lineTo(W1,BOT);g.stroke();
 /* roof: thick bargeboards forming an inverted V, heavy snow on top */
 const rf=()=>{g.beginPath();g.moveTo(-40,TOP+18);g.lineTo(136,236);g.lineTo(312,TOP+18);g.lineTo(312,TOP+40);g.lineTo(136,262);g.lineTo(-40,TOP+40);g.closePath()};
 rf();g.fillStyle=fkLin(g,0,236,0,TOP+40,['#5a3020','#3a1c12']);g.fill();g.lineWidth=4;g.strokeStyle=FKO;g.stroke();
 g.strokeStyle='#2a120a';g.lineWidth=2;for(let k=1;k<9;k++){const u=k/9;g.beginPath();g.moveTo(136-176*u,236+(TOP+18-236)*u);g.lineTo(136-176*u,262+(TOP+40-262)*u);g.moveTo(136+176*u,236+(TOP+18-236)*u);g.lineTo(136+176*u,262+(TOP+40-262)*u);g.stroke()}
 /* icicles hanging under the bargeboards */
 const ice=(x,y,l)=>{g.beginPath();g.moveTo(x-4,y);g.quadraticCurveTo(x-1,y+l*.6,x,y+l);g.quadraticCurveTo(x+1,y+l*.6,x+4,y);g.closePath();g.fillStyle=fkLin(g,x,y,x,y+l,['#ffffff','#bfe8ff','#7ac8f0']);g.fill();g.lineWidth=1.8;g.strokeStyle=FKO;g.stroke()};
 for(let k=0;k<12;k++){const u=.12+k*.075,side=k%2?1:-1,x=136+side*176*u,y=262+(TOP+40-262)*u;ice(x,y-2,10+lf_r(k+40)*22)}
 /* snow blanket */
 const sn=()=>{g.beginPath();g.moveTo(-46,TOP+22);for(let k=0;k<=10;k++){const u=k/10,x=-46+182*u,y=TOP+22-(TOP+22-214)*u;g.quadraticCurveTo(x-9,y-14-lf_r(k)*6,x,y-8)}for(let k=1;k<=10;k++){const u=k/10,x=136+182*u,y=214+(TOP+22-214)*u;g.quadraticCurveTo(x-9,y-14-lf_r(k+20)*6,x,y-8)}
  g.lineTo(318,TOP+26);for(let k=10;k>=0;k--){const u=k/10,x=136+178*u,y=240+(TOP+22-236)*u;g.quadraticCurveTo(x+8,y+(k%3?10:22),x,y+4)}for(let k=10;k>=0;k--){const u=k/10,x=136-178*(1-u),y=240+(TOP+22-236)*(1-u);g.quadraticCurveTo(x+8,y+(k%3?10:22),x,y+4)}g.closePath()};
 sn();g.fillStyle=fkLin(g,0,200,0,TOP+30,['#ffffff','#dbe6fb','#9fb0de']);g.fill();g.lineWidth=3.5;g.strokeStyle=FKO;g.stroke();
 g.save();sn();g.clip();g.strokeStyle='#ffffff';g.lineWidth=3;g.globalAlpha=.8;g.beginPath();g.moveTo(-30,TOP+2);g.lineTo(136,212);g.lineTo(300,TOP+2);g.stroke();g.globalAlpha=1;
 g.fillStyle='#8f9fd040';g.beginPath();g.moveTo(-60,TOP+40);g.lineTo(136,236);g.lineTo(136,280);g.lineTo(-60,TOP+60);g.fill();g.restore();
 lf_occ(-46,320,x=>(x<136?TOP+8-(TOP+8-200)*(x+46)/182:200+(TOP+8-200)*(x-136)/182)-6);
 /* small porch roof over the door */
 g.beginPath();g.moveTo(4,486);g.lineTo(128,500);g.lineTo(128,512);g.lineTo(4,500);g.closePath();g.fillStyle='#4a2616';g.fill();g.lineWidth=3;g.strokeStyle=FKO;g.stroke();
 for(let k=0;k<6;k++)ice(12+k*21,503+k*2.3,8+lf_r(k+70)*16);
 g.beginPath();g.moveTo(0,488);g.quadraticCurveTo(30,470,64,482);g.quadraticCurveTo(100,476,134,498);g.quadraticCurveTo(70,494,0,490);g.closePath();g.fillStyle='#f4f8ff';g.fill();g.lineWidth=2.5;g.stroke();
 /* the door with a wreath */
 g.fillStyle=fkLin(g,0,516,0,BOT,['#6a3c22','#3a1e10']);g.beginPath();g.rect(26,520,72,BOT-520);g.fill();g.lineWidth=3;g.strokeStyle=FKO;g.stroke();
 g.strokeStyle='#2a140a';g.lineWidth=2;[44,62,80].forEach(x=>{g.beginPath();g.moveTo(x,522);g.lineTo(x,BOT);g.stroke()});
 g.fillStyle='#22222e';[[28,540],[28,606]].forEach(([x,y])=>g.fillRect(x,y,26,6));g.fillStyle='#e6b93e';g.beginPath();g.arc(88,584,4,0,TAU);g.fill();
 g.fillStyle='#ffb04a';g.globalAlpha=.7;g.fillRect(97,524,3,BOT-526);g.globalAlpha=1;
 g.save();g.translate(62,556);for(let k=0;k<14;k++){const a=k/14*TAU;g.fillStyle=k%2?'#2e7a4a':'#1e5a36';g.beginPath();g.ellipse(Math.cos(a)*14,Math.sin(a)*14,8,5,a+1.2,0,TAU);g.fill()}
 g.lineWidth=2;g.strokeStyle=FKO;g.beginPath();g.arc(0,0,20,0,TAU);g.stroke();g.beginPath();g.arc(0,0,8,0,TAU);g.stroke();
 g.fillStyle='#e8344a';[[-4,-12],[9,-6],[11,8],[-9,9],[-13,-3],[2,14]].forEach(([x,y])=>{g.beginPath();g.arc(x,y,2.4,0,TAU);g.fill()});
 g.fillStyle='#d82a3e';g.beginPath();g.moveTo(0,16);g.lineTo(-9,12);g.lineTo(-9,22);g.closePath();g.moveTo(0,16);g.lineTo(9,12);g.lineTo(9,22);g.closePath();g.fill();g.lineWidth=1.5;g.stroke();g.restore();
 /* the big warm window with a snowy flower box */
 const wx=140,wy=452,ww=92,wh=86;fkGlow(g,wx+ww/2,wy+wh/2,150,'#ff9a30',.4);
 g.fillStyle=fkLin(g,wx,wy,wx,wy+wh,['#fff2b8','#ffc05a','#e8781e']);g.fillRect(wx,wy,ww,wh);
 g.fillStyle='#c0501855';g.beginPath();g.moveTo(wx,wy+wh);g.lineTo(wx+30,wy+40);g.lineTo(wx+60,wy+52);g.lineTo(wx+ww,wy+wh);g.fill();
 g.fillStyle='#8a3a1066';g.beginPath();g.arc(wx+24,wy+wh,14,Math.PI,0);g.fill();
 g.lineWidth=7;g.strokeStyle='#3a2216';g.strokeRect(wx,wy,ww,wh);g.lineWidth=4;g.beginPath();g.moveTo(wx+ww/2,wy);g.lineTo(wx+ww/2,wy+wh);g.moveTo(wx,wy+wh*.48);g.lineTo(wx+ww,wy+wh*.48);g.stroke();
 g.lineWidth=2.5;g.strokeStyle=FKO;g.strokeRect(wx-4,wy-4,ww+8,wh+8);
 g.fillStyle='#ffffff55';g.fillRect(wx+6,wy+6,10,24);g.fillRect(wx+ww/2+6,wy+6,8,16);
 /* frost in the window corners */
 g.fillStyle='#e8f6ffcc';[[wx+3,wy+3,1,1],[wx+ww-3,wy+3,-1,1]].forEach(([x,y,sx,sy])=>{g.beginPath();g.moveTo(x,y);g.lineTo(x+18*sx,y);g.quadraticCurveTo(x+8*sx,y+6*sy,x,y+16*sy);g.closePath();g.fill()});
 /* shutters */
 [[wx-24,1],[wx+ww+6,-1]].forEach(([x])=>{g.fillStyle=fkLin(g,x,0,x+18,0,['#2e5a7a','#1e3a5a']);g.fillRect(x,wy-2,18,wh+4);g.lineWidth=2.5;g.strokeStyle=FKO;g.strokeRect(x,wy-2,18,wh+4);g.strokeStyle='#14283e';g.lineWidth=1.5;for(let k=1;k<6;k++){g.beginPath();g.moveTo(x+3,wy+k*15);g.lineTo(x+15,wy+k*15);g.stroke()}});
 g.fillStyle=fkLin(g,0,wy+wh,0,wy+wh+18,['#7a4a2c','#4e2e1a']);g.fillRect(wx-12,wy+wh+2,ww+24,16);g.lineWidth=2.5;g.strokeStyle=FKO;g.strokeRect(wx-12,wy+wh+2,ww+24,16);
 g.fillStyle='#f4f8ff';g.beginPath();g.moveTo(wx-14,wy+wh+4);g.quadraticCurveTo(wx+10,wy+wh-12,wx+40,wy+wh-4);g.quadraticCurveTo(wx+70,wy+wh-14,wx+ww+14,wy+wh+4);g.closePath();g.fill();g.stroke();
 g.fillStyle='#e8344a';[[wx+8,wy+wh-2],[wx+26,wy+wh-6],[wx+62,wy+wh-6],[wx+80,wy+wh-2]].forEach(([x,y])=>{g.beginPath();g.arc(x,y,3,0,TAU);g.fill()});
 /* skis leaning on the wall */
 [[236,-.12,'#d8384a'],[252,-.06,'#e8584a']].forEach(([x,a,c])=>{g.save();g.translate(x,BOT);g.rotate(a);g.beginPath();g.moveTo(-4,0);g.lineTo(-4,-128);g.quadraticCurveTo(0,-140,6,-134);g.lineTo(4,0);g.closePath();g.fillStyle=c;g.fill();g.lineWidth=2.4;g.strokeStyle=FKO;g.stroke();g.fillStyle='#2a2a3a';g.fillRect(-5,-62,10,7);g.restore()});
 /* hanging sign with a fish */
 g.strokeStyle='#2a160c';g.lineWidth=6;g.beginPath();g.moveTo(W1+6,418);g.lineTo(356,418);g.stroke();g.lineWidth=3;g.strokeStyle=FKO;g.beginPath();g.moveTo(W1+18,418);g.lineTo(W1+40,440);g.stroke();
 g.lineWidth=2;g.strokeStyle='#1a1008';g.beginPath();g.moveTo(304,418);g.lineTo(304,436);g.moveTo(344,418);g.lineTo(344,436);g.stroke();
 g.beginPath();g.moveTo(290,436);g.lineTo(358,436);g.lineTo(358,478);g.lineTo(324,492);g.lineTo(290,478);g.closePath();g.fillStyle=fkLin(g,0,436,0,492,['#2e4a8a','#1e2e5e']);g.fill();g.lineWidth=3;g.strokeStyle='#bfe8ff';g.stroke();
 g.save();g.translate(324,462);g.fillStyle='#9ff0ff';g.beginPath();g.ellipse(2,0,15,8,0,0,TAU);g.fill();g.beginPath();g.moveTo(-11,0);g.lineTo(-22,-8);g.lineTo(-22,8);g.closePath();g.fill();g.fillStyle='#1e2e5e';g.beginPath();g.arc(9,-2,2,0,TAU);g.fill();g.restore();
 g.fillStyle='#f4f8ff';g.beginPath();g.moveTo(288,438);g.quadraticCurveTo(300,426,320,432);g.quadraticCurveTo(342,424,360,438);g.closePath();g.fill();g.lineWidth=2;g.strokeStyle=FKO;g.stroke();
 lf_occ(270,362,()=>410);
 /* door lantern bracket */
 g.strokeStyle='#1a1008';g.lineWidth=3;g.beginPath();g.moveTo(102,476);g.lineTo(122,476);g.lineTo(122,484);g.stroke()}
/* ---------- the snowy pier (same footprint as the pond dock) ---------- */
function lf_dock(g){const X0=130,X1=608;
 /* posts into the water with ice collars */
 for(let i=0;i<6;i++){const x=190+i*80,L=110-(i%2)*20;g.fillStyle=fkLin(g,x-9,0,x+9,0,['#6a5048','#3a2a2a']);g.fillRect(x-9,648,18,L);g.lineWidth=2.5;g.strokeStyle=FKO;g.strokeRect(x-9,648,18,L);
  g.beginPath();g.ellipse(x,648+L-6,17,6,0,0,TAU);g.fillStyle='#bfe2fa';g.fill();g.lineWidth=2;g.stroke();g.fillStyle='#ffffffaa';g.beginPath();g.ellipse(x-4,648+L-8,8,2,0,0,TAU);g.fill();
  g.fillStyle='#9fd8ff22';g.fillRect(x-22,648+L+4,44,3)}
 /* deck planks */
 const top=()=>{g.beginPath();g.moveTo(X0-20,618);g.lineTo(X1-8,626);g.lineTo(X1,656);g.lineTo(X0-20,662);g.closePath()};
 top();g.fillStyle=fkLin(g,0,618,0,662,['#8a7468','#5e4a44']);g.fill();
 g.save();top();g.clip();g.strokeStyle='#3a2a2a';g.lineWidth=1.6;for(let i=1;i<14;i++){const x=X0-20+i*(X1-X0+20)/14;g.beginPath();g.moveTo(x,618+i*.6);g.lineTo(x+2,662);g.stroke()}
 /* snow blanket on the deck: drifts along the back edge, a trodden path in the middle, footprints */
 g.fillStyle='#e8f0ff';g.beginPath();g.moveTo(X0-24,612);g.lineTo(X1,620);g.lineTo(X1+4,634);for(let k=12;k>=0;k--){const x=X0-20+k*(X1-X0+24)/12;g.quadraticCurveTo(x+18,640+(k%2)*5,x,634+lf_r(k+9)*6)}g.closePath();g.fill();
 g.fillStyle='#e8f0ff';g.beginPath();g.moveTo(X0-24,666);for(let k=0;k<=12;k++){const x=X0-20+k*(X1-X0+24)/12;g.quadraticCurveTo(x-18,650-(k%2)*4,x,654+lf_r(k+30)*4)}g.lineTo(X1+4,662);g.closePath();g.fill();
 g.fillStyle='#b8c8ee';g.globalAlpha=.6;for(let k=0;k<8;k++){const x=X0+30+k*36,y=645+(k%2)*6;g.beginPath();g.ellipse(x,y,6,2.6,.1,0,TAU);g.fill()}g.globalAlpha=1;
 g.strokeStyle='#ffffff';g.lineWidth=2;g.globalAlpha=.8;g.beginPath();g.moveTo(X0-18,616);g.lineTo(X1-6,624);g.stroke();g.globalAlpha=1;g.restore();
 top();g.lineWidth=3;g.strokeStyle=FKO;g.stroke();
 /* front beam */
 g.beginPath();g.moveTo(X0-20,662);g.lineTo(X1,656);g.lineTo(X1,672);g.lineTo(X0-20,678);g.closePath();g.fillStyle=fkLin(g,0,656,0,678,['#5a4440','#3a2a2a']);g.fill();g.lineWidth=2.5;g.strokeStyle=FKO;g.stroke();
 /* snow lip over the beam edge */
 g.beginPath();g.moveTo(X0-24,658);for(let k=0;k<=16;k++){const x=X0-24+k*(X1-X0+28)/16,y=662-k*.37;g.quadraticCurveTo(x-14,y+(k%3?8:13),x,y+2)}g.lineTo(X1+4,652);g.lineTo(X0-24,652);g.closePath();g.fillStyle='#f4f8ff';g.fill();g.lineWidth=2.5;g.stroke();
 /* icicles under the beam */
 for(let k=0;k<20;k++){const x=X0-12+k*24+lf_r(k+3)*10,y=678-(x-X0)*.012,l=8+lf_r(k+11)*20;g.beginPath();g.moveTo(x-3.5,y-1);g.quadraticCurveTo(x-1,y+l*.6,x,y+l);g.quadraticCurveTo(x+1,y+l*.6,x+3.5,y-1);g.closePath();g.fillStyle=fkLin(g,x,y,x,y+l,['#ffffff','#a8dcfa']);g.fill();g.lineWidth=1.6;g.strokeStyle=FKO;g.stroke()}
 /* two lantern posts (the lanterns and the rope are drawn live) */
 [X0+130,X1-20].forEach(x=>{g.fillStyle=fkLin(g,x-7,0,x+7,0,['#8a6a5a','#4a3430']);g.fillRect(x-7,528,14,110);g.lineWidth=2.5;g.strokeStyle=FKO;g.strokeRect(x-7,528,14,110);g.fillStyle='#ffffff30';g.fillRect(x-5,532,3,100);
  g.fillStyle='#f4f8ff';g.beginPath();g.ellipse(x,626,14,5,0,0,TAU);g.fill();g.lineWidth=2;g.stroke()})}
/* ---------- a snowman on the bank ---------- */
function lf_snowman(g,x,y){const ball=(cy,r)=>{g.beginPath();g.arc(x,cy,r,0,TAU);g.fillStyle=fkRad(g,x,cy,r,['#ffffff','#dbe6fb','#9aaad8']);g.fill();g.lineWidth=3;g.strokeStyle=FKO;g.stroke()};
 g.fillStyle='#00000040';g.beginPath();g.ellipse(x,y+2,34,7,0,0,TAU);g.fill();
 g.strokeStyle='#4a2c1a';g.lineWidth=3.5;g.beginPath();g.moveTo(x-18,y-46);g.lineTo(x-44,y-66);g.lineTo(x-52,y-62);g.moveTo(x-44,y-66);g.lineTo(x-48,y-76);g.moveTo(x+18,y-46);g.lineTo(x+42,y-70);g.lineTo(x+52,y-72);g.stroke();
 ball(y-20,26);ball(y-56,19);ball(y-86,14);
 g.fillStyle='#1b1024';[[y-26],[y-40]].forEach(([yy])=>{g.beginPath();g.arc(x+2,yy,2.6,0,TAU);g.fill()});
 g.beginPath();g.arc(x-4,y-90,2.4,0,TAU);g.arc(x+6,y-90,2.4,0,TAU);g.fill();
 g.beginPath();g.moveTo(x+2,y-85);g.lineTo(x+22,y-81);g.lineTo(x+2,y-80);g.closePath();g.fillStyle='#ff8a2a';g.fill();g.lineWidth=1.6;g.strokeStyle=FKO;g.stroke();
 g.strokeStyle=FKO;g.lineWidth=1.6;g.beginPath();g.arc(x+1,y-82,6,.4,2.2);g.stroke();
 /* scarf */
 g.beginPath();g.moveTo(x-16,y-72);g.quadraticCurveTo(x,y-66,x+16,y-72);g.lineTo(x+16,y-64);g.quadraticCurveTo(x,y-58,x-16,y-64);g.closePath();g.fillStyle='#d8384a';g.fill();g.lineWidth=2;g.stroke();
 g.beginPath();g.moveTo(x+8,y-66);g.lineTo(x+16,y-44);g.lineTo(x+6,y-44);g.lineTo(x+2,y-64);g.closePath();g.fill();g.stroke();
 g.strokeStyle='#ffffff90';g.lineWidth=2;g.beginPath();g.moveTo(x+10,y-62);g.lineTo(x+14,y-50);g.stroke();
 /* bobble hat */
 g.beginPath();g.moveTo(x-13,y-96);g.quadraticCurveTo(x,y-122,x+13,y-96);g.closePath();g.fillStyle='#2e6ab8';g.fill();g.lineWidth=2.4;g.stroke();g.fillStyle='#f4f8ff';g.fillRect(x-14,y-99,28,6);g.strokeRect(x-14,y-99,28,6);g.beginPath();g.arc(x+1,y-116,5,0,TAU);g.fill();g.stroke()}
/* ---------- bg: painted once ---------- */
function lf_bg(g){lf_SK.fill(FSW_Y);const D={};
 /* sky: deep indigo to teal at the horizon */
 g.fillStyle=fkLin(g,0,0,0,FSW_Y,['#040824','#0a1240','#0f2656','#16466a','#1f6274']);g.fillRect(0,0,1600,FSW_Y+4);
 /* ambient aurora haze */
 g.save();g.translate(860,250);g.scale(1.9,.6);fkGlow(g,0,0,420,'#1ec890',.16);g.restore();g.save();g.translate(1150,170);g.scale(1.6,.5);fkGlow(g,0,0,360,'#8a4cff',.12);g.restore();
 for(let i=0;i<240;i++){const x=lf_r(i)*1600,y=lf_r(i+500)*(FSW_Y-80),r=lf_r(i+900)<.07?1.8:lf_r(i+900)<.35?1.1:.7;g.globalAlpha=.3+lf_r(i+77)*.65;g.fillStyle=lf_r(i+3)<.15?'#d8fff0':'#eef0ff';g.beginPath();g.arc(x,y,r,0,TAU);g.fill()}g.globalAlpha=1;
 /* a slim crescent moon */
 fkGlow(g,1290,104,110,'#d8f0ff',.22);{const[mc,mx]=lf_cv(80,80);mx.beginPath();mx.arc(40,40,32,0,TAU);mx.fillStyle=fkLin(mx,10,10,60,70,['#ffffff','#d8ecff','#a8c8f0']);mx.fill();mx.globalCompositeOperation='destination-out';mx.beginPath();mx.arc(55,30,29,0,TAU);mx.fill();g.drawImage(mc,1250,64)}
 /* far peaks (pale, atmospheric) */
 const far={top:'#5664a8',base:'#2a3474',sh:'#1e2660',sn:'#e8f0ff',ss:'#8e9ad8',cap:.36,rim:'#7dffc8'};
 [{x:300,y:296,w:210,s:1},{x:1530,y:286,w:230,s:2},{x:470,y:248,w:250,s:3},{x:1260,y:222,w:290,s:4},{x:990,y:262,w:250,s:5},{x:730,y:186,w:320,s:6}].forEach(P=>lf_peak(g,P,FSW_Y-40,far));
 /* thin mist band */
 g.fillStyle=fkLin(g,0,FSW_Y-120,0,FSW_Y-40,['#3a7a9000','#3a7a9040']);g.fillRect(0,FSW_Y-120,1600,80);
 /* mid peaks (darker) */
 const mid={top:'#2a3a78',base:'#16204e',sh:'#0e1640',sn:'#cfdaf6',ss:'#6e7cbc',cap:.3,rim:'#5affd0'};
 [{x:200,y:392,w:180,s:11},{x:1440,y:372,w:210,s:12},{x:600,y:362,w:200,s:13},{x:1120,y:346,w:230,s:14},{x:880,y:388,w:180,s:15},{x:380,y:410,w:150,s:16}].forEach(P=>lf_peak(g,P,FSW_Y-10,mid));
 /* forested hills along the far shore */
 const hill=x=>FSW_Y-30-Math.sin(x*.006+1)*12-Math.sin(x*.017)*6;
 g.fillStyle='#0c1a34';g.beginPath();g.moveTo(0,FSW_Y+2);for(let x=0;x<=1600;x+=10)g.lineTo(x,hill(x));g.lineTo(1600,FSW_Y+2);g.fill();
 for(let i=0;i<190;i++){const x=i*8.6+lf_r(i+300)*8,h=18+lf_r(i+301)*34*(.6+.4*Math.sin(x*.01));const b=hill(x)+10+lf_r(i+302)*16;lf_pine(g,x,b,h,{d:i%3?'#0c2036':'#10283e',s:'#9fb2e0'},0);lf_occ(x-h*.3,x+h*.3,xx=>b-h+Math.abs(xx-x)*2.6)}
 /* snowy far shore */
 g.beginPath();g.moveTo(0,FSW_Y+4);for(let x=0;x<=1600;x+=40)g.quadraticCurveTo(x+20,FSW_Y-10-lf_r(x)*6,x+40,FSW_Y-4+lf_r(x+1)*3);g.lineTo(1600,FSW_Y+6);g.closePath();g.fillStyle=fkLin(g,0,FSW_Y-12,0,FSW_Y+6,['#dbe6fb','#8fa2d6']);g.fill();
 g.fillStyle='#e8f6ff';g.globalAlpha=.55;g.fillRect(0,FSW_Y+3,1600,2);g.globalAlpha=1;
 /* a tiny lakeside hamlet on the far shore (warm windows) */
 [[1032,FSW_Y-6,26,16],[1064,FSW_Y-10,34,20],[1102,FSW_Y-5,22,14],[1188,FSW_Y-7,28,17]].forEach(([x,y,w,h],i)=>{g.fillStyle='#161a3e';g.fillRect(x-w/2,y-h,w,h);g.beginPath();g.moveTo(x-w/2-4,y-h);g.lineTo(x,y-h-h*.8);g.lineTo(x+w/2+4,y-h);g.closePath();g.fill();
  g.fillStyle='#dbe6fb';g.beginPath();g.moveTo(x-w/2-4,y-h);g.lineTo(x,y-h-h*.8);g.lineTo(x+w/2+4,y-h);g.lineTo(x+w/2,y-h+2);g.lineTo(x,y-h-h*.6);g.lineTo(x-w/2,y-h+2);g.closePath();g.fill();
  fkGlow(g,x,y-h*.45,18,'#ffb44a',.55);g.fillStyle='#ffd88a';g.fillRect(x-3,y-h*.6,5,5);if(w>30){g.fillRect(x+7,y-h*.6,5,5)}});
 g.fillStyle='#1c1838';g.fillRect(1148,FSW_Y-58,8,52);g.beginPath();g.moveTo(1142,FSW_Y-58);g.lineTo(1152,FSW_Y-76);g.lineTo(1162,FSW_Y-58);g.fill();fkGlow(g,1152,FSW_Y-50,26,'#ffb44a',.6);g.fillStyle='#ffe6a0';g.fillRect(1149,FSW_Y-53,6,6);
 /* water base */
 g.fillStyle=fkLin(g,0,FSW_Y,0,900,['#174a6e','#0f2e5a','#0a1c44','#06102c']);g.fillRect(0,FSW_Y+5,1600,400);
 /* reflections of the peaks and forest (soft, darker) */
 {const R=document.createElement('canvas');R.width=1600;R.height=300;const r=R.getContext('2d');r.translate(0,300);r.scale(1,-1);r.drawImage(g.canvas,0,FSW_Y-300,1600,300,0,0,1600,300);r.setTransform(1,0,0,1,0,0);
  r.globalCompositeOperation='destination-in';const m=r.createLinearGradient(0,0,0,300);m.addColorStop(0,'#000000');m.addColorStop(.5,'#00000070');m.addColorStop(1,'#00000000');r.fillStyle=m;r.fillRect(0,0,1600,300);
  g.save();g.globalAlpha=.32;g.drawImage(R,0,FSW_Y+5,1600,300);g.restore()}
 g.fillStyle=fkLin(g,0,FSW_Y,0,FSW_Y+260,['#0f2e5a00','#0c2450a0','#081a40e0']);g.fillRect(0,FSW_Y+5,1600,260);
 /* static aurora glow on the water */
 g.save();g.translate(860,600);g.scale(2.2,.4);fkGlow(g,0,0,300,'#2ad8a0',.12);g.restore();
 for(const lx of[1032,1064,1102,1152,1188])for(let k=0;k<5;k++){g.globalAlpha=.2-k*.035;g.fillStyle='#ffb44a';g.fillRect(lx-7+k*1.5,FSW_Y+12+k*9,14-k*3,2.4)}g.globalAlpha=1;
 /* thin ice sheets near the horizon */
 g.fillStyle='#bcd8f4';g.globalAlpha=.22;[[180,FSW_Y+12,260],[640,FSW_Y+9,180],[1180,FSW_Y+14,300]].forEach(([x,y,w])=>{g.beginPath();g.ellipse(x,y,w/2,4,0,0,TAU);g.fill()});g.globalAlpha=1;
 /* ---- right shore: snowy rocks and big pines (partly under the HUD during play) ---- */
 const rock=(x,y,w,h,s)=>{const P=[];for(let i=0;i<9;i++){const a=Math.PI+i/8*Math.PI,r=.8+lf_r(i+s)*.25;P.push(x+Math.cos(a)*w/2*r,y+Math.sin(a)*h*r)}P.push(x+w/2,y+8,x-w/2,y+8);
  fkPath(g,P);g.fillStyle=fkLin(g,x-w/2,y-h,x+w/2,y,['#5a6896','#2e3866','#1e2650']);g.fill();g.lineWidth=3;g.strokeStyle=FKO;g.stroke();
  g.save();fkPath(g,P);g.clip();g.fillStyle='#f0f6ff';g.beginPath();g.moveTo(x-w/2-10,y-h*.5);for(let k=0;k<=6;k++){const xx=x-w/2-10+k*(w+20)/6;g.quadraticCurveTo(xx-8,y-h*.45-(k%2?0:h*.2),xx,y-h*.62+(k%2?h*.12:0))}g.lineTo(x+w,y-h*1.6);g.lineTo(x-w,y-h*1.6);g.closePath();g.fill();
  g.fillStyle='#8f9fd060';g.beginPath();g.ellipse(x-w*.3,y-h*.7,w*.3,h*.5,0,0,TAU);g.fill();g.restore();fkPath(g,P);g.lineWidth=3;g.strokeStyle=FKO;g.stroke()};
 g.beginPath();g.moveTo(1600,560);g.quadraticCurveTo(1460,566,1400,620);g.quadraticCurveTo(1340,680,1360,760);g.quadraticCurveTo(1380,840,1330,900);g.lineTo(1600,900);g.closePath();g.fillStyle=fkLin(g,1350,560,1600,900,['#dbe6fb','#9aaada','#5a6aa8']);g.fill();g.lineWidth=3.5;g.strokeStyle=FKO;g.stroke();
 g.fillStyle='#bfe2fa80';g.beginPath();g.moveTo(1400,628);g.quadraticCurveTo(1330,690,1350,770);g.quadraticCurveTo(1366,840,1316,900);g.lineTo(1300,900);g.quadraticCurveTo(1346,830,1334,770);g.quadraticCurveTo(1316,680,1394,624);g.fill();
 lf_pine(g,1442,676,250,{d:'#123a4a',l:'#1e5a62',s:'#eef4ff'},3);lf_occ(1350,1534,x=>676-250+Math.abs(x-1442)*2.7);
 lf_pine(g,1556,720,470,{d:'#0f3242',l:'#1c5560',s:'#f4f8ff'},3.5);lf_occ(1380,1600,x=>720-470+Math.abs(x-1556)*2.7);
 rock(1420,720,110,56,61);rock(1500,780,150,70,62);rock(1395,860,120,60,63);
 /* ---- left: snowy bank under the cabin ---- */
 g.beginPath();g.moveTo(0,628);g.quadraticCurveTo(150,630,196,700);g.quadraticCurveTo(232,790,150,900);g.lineTo(0,900);g.closePath();g.fillStyle=fkLin(g,0,630,180,900,['#e4ecfc','#a6b6e2','#5e6ea8']);g.fill();
 g.fillStyle='#bfe2fa90';g.beginPath();g.moveTo(196,700);g.quadraticCurveTo(238,790,150,900);g.lineTo(178,900);g.quadraticCurveTo(256,790,206,700);g.closePath();g.fill();
 g.beginPath();g.moveTo(0,628);g.quadraticCurveTo(150,630,196,700);g.quadraticCurveTo(232,790,150,900);g.lineWidth=3.5;g.strokeStyle=FKO;g.stroke();
 /* the cabin and its warm light on the snow */
 lf_cabin(g);
 g.save();g.translate(186,646);g.scale(1.6,.5);fkGlow(g,0,0,110,'#ffa040',.35);g.restore();
 lf_dock(g);
 [260,588].forEach(x=>{g.save();g.translate(x,632);g.scale(2.2,.45);fkGlow(g,0,0,70,'#ffa040',.4);g.restore()});
 /* firewood stack and a bucket on the pier */
 {const fx=150,fy=642;for(let r=0;r<3;r++)for(let k=0;k<4-r;k++){const x=fx+12+k*20+r*10,y=fy-9-r*16;g.beginPath();g.arc(x,y,9.5,0,TAU);g.fillStyle=fkRad(g,x,y,9.5,['#f0c890','#c08a52','#7a4a2c']);g.fill();g.lineWidth=2.2;g.strokeStyle=FKO;g.stroke();g.strokeStyle='#8a5a32';g.lineWidth=1;g.beginPath();g.arc(x,y,4.5,0,TAU);g.stroke()}
  g.fillStyle='#f4f8ff';g.beginPath();g.moveTo(fx+10,fy-50);g.quadraticCurveTo(fx+40,fy-66,fx+64,fy-48);g.quadraticCurveTo(fx+40,fy-44,fx+10,fy-50);g.fill();g.lineWidth=2;g.strokeStyle=FKO;g.stroke();
  const bx=248,by=646;g.beginPath();g.moveTo(bx-16,by);g.lineTo(bx-19,by-30);g.lineTo(bx+19,by-30);g.lineTo(bx+16,by);g.closePath();g.fillStyle=fkLin(g,bx-19,0,bx+19,0,['#9a7a5a','#5a4030']);g.fill();g.lineWidth=2.5;g.strokeStyle=FKO;g.stroke();
  g.strokeStyle='#3a3a4a';g.lineWidth=3;[by-8,by-23].forEach(y=>{g.beginPath();g.moveTo(bx-18,y);g.lineTo(bx+18,y);g.stroke()});
  g.fillStyle='#7ad0e8';g.beginPath();g.moveTo(bx-4,by-30);g.quadraticCurveTo(bx+2,by-48,bx+12,by-52);g.lineTo(bx+16,by-42);g.lineTo(bx+8,by-30);g.closePath();g.fill();g.lineWidth=2;g.strokeStyle=FKO;g.stroke();
  g.strokeStyle=FKO;g.lineWidth=2;g.beginPath();g.moveTo(bx-18,by-30);g.quadraticCurveTo(bx,by-56,bx+18,by-30);g.stroke()}
 lf_snowman(g,72,770);
 /* small snowy bushes on the bank */
 [[34,690,16],[150,850,20],[20,860,24]].forEach(([x,y,r])=>{g.fillStyle='#1a4a46';g.beginPath();g.arc(x,y,r,Math.PI,0);g.fill();g.lineWidth=2.5;g.strokeStyle=FKO;g.stroke();g.fillStyle='#f0f6ff';g.beginPath();g.ellipse(x,y-r*.7,r*.8,r*.35,0,0,TAU);g.fill();g.stroke()});
 /* foreground snow drift along the bottom edge */
 g.fillStyle='#141e44';g.beginPath();g.moveTo(0,900);for(let x=0;x<=1600;x+=40)g.quadraticCurveTo(x+20,884-lf_r(x+11)*18-Math.max(0,Math.sin(x*.004))*10,x+40,890-lf_r(x+12)*8);g.lineTo(1600,900);g.fill();
 g.strokeStyle='#5a6aa880';g.lineWidth=2;g.beginPath();for(let x=0;x<=1600;x+=40){g.moveTo(x,890-lf_r(x-28)*8);g.quadraticCurveTo(x+20,884-lf_r(x+11)*18-Math.max(0,Math.sin(x*.004))*10,x+40,890-lf_r(x+12)*8)}g.stroke();
 lf_build(D);lf_D=D}
/* ---------- cached sprites and clip paths for the live layers ---------- */
function lf_aurSprite(curves){const[c,x]=lf_cv(1600,460);x.globalCompositeOperation='lighter';let y0=460,y1=0,X0=1600,X1=0;
 const strip=cols=>{const[sc,sx]=lf_cv(1,256);const q=sx.createLinearGradient(0,0,0,256);cols.forEach((v,i)=>q.addColorStop(v[0],v[1]));sx.fillStyle=q;sx.fillRect(0,0,1,256);return sc};
 curves.forEach(C=>{const s1=strip(C.c1),s2=strip(C.c2);
  for(let X=C.x0;X<C.x1;X+=2){const u=(X-C.x0)/(C.x1-C.x0),env=Math.pow(Math.sin(u*Math.PI),.6),yb=C.y(X),h=C.h*(.6+.3*Math.sin(X*.011+C.ph)+.18*Math.sin(X*.037)),
    ray=.5+.35*Math.pow(Math.abs(Math.sin(X*.019+C.ph)),3)+.35*Math.pow(Math.abs(Math.sin(X*.053+1.3*C.ph)),8),m=.5+.5*Math.sin(u*C.mix+C.ph),a=Math.min(1,env*ray*C.a);
   if(a>.01){y0=Math.min(y0,yb-h);y1=Math.max(y1,yb+16);X0=Math.min(X0,X);X1=Math.max(X1,X+3)}x.globalAlpha=a*(1-m);x.drawImage(s1,X,yb-h,2.4,h+3);x.globalAlpha=a*m;x.drawImage(s2,X,yb-h,2.4,h+3)}
  /* the bright lower hem */
  x.lineCap='butt';for(const[lw,al]of[[26,.07],[12,.12],[5,.16],[2,.22]]){x.lineWidth=lw;for(let X=C.x0+30;X<C.x1-30;X+=8){const u=(X-C.x0)/(C.x1-C.x0);x.globalAlpha=al*Math.pow(Math.sin(u*Math.PI),1.2)*(.7+.3*Math.sin(X*.02+C.ph));x.strokeStyle=C.edge;x.beginPath();x.moveTo(X,C.y(X)+1);x.lineTo(X+8,C.y(X+8)+1);x.stroke()}}x.globalAlpha=1});
 c.y0=Math.max(0,Math.floor(y0));c.y1=Math.min(460,Math.ceil(y1));c.x0=Math.floor(X0);c.x1=Math.ceil(X1);return c}
function lf_build(D){
 /* aurora: main green-teal curtain + a lower teal ribbon on the left, and a higher violet-rose band */
 const G1=[[0,'#5a40ff00'],[.35,'#3a90e028'],[.65,'#2ae89070'],[.86,'#4aff98c8'],[1,'#d0ffe0ff']],G2=[[0,'#8a40ff00'],[.4,'#6a6aff30'],[.7,'#30d0e080'],[.88,'#5af0e0d0'],[1,'#d8fff8ff']],
  P1=[[0,'#ff40c000'],[.4,'#c050ff28'],[.72,'#d060ff80'],[.9,'#ff8ae0d0'],[1,'#ffe0f6ff']],P2=[[0,'#5040ff00'],[.55,'#7a50ff38'],[.85,'#a070ffa0'],[1,'#e8c8ffff']];
 D.aA=lf_aurSprite([
  {x0:250,x1:1600,y:X=>352-(X-250)*.1+46*Math.sin(X*.0058+.4)+16*Math.sin(X*.015+2),h:230,ph:0,a:.85,mix:5,edge:'#e0fff0',c1:G1,c2:G2},
  {x0:560,x1:1500,y:X=>268+34*Math.sin(X*.0075+3)+10*Math.sin(X*.02),h:120,ph:2.2,a:.42,mix:3,edge:'#c0fff0',c1:G2,c2:G1}]);
 D.aB=lf_aurSprite([{x0:420,x1:1600,y:X=>176-(X-420)*.03+28*Math.sin(X*.0062+2.5)+12*Math.sin(X*.016),h:150,ph:1,a:.6,mix:4,edge:'#ffd8f4',c1:P1,c2:P2}]);
 /* aurora reflection sprite (flipped, squashed, faded) for x 300..1340 */
 {const[c,x]=lf_cv(1040,210);x.save();x.translate(-300,0);x.scale(1,-.5);x.translate(0,-FSW_Y);x.drawImage(D.aA,0,0);x.globalAlpha=.6;x.drawImage(D.aB,0,0);x.restore();
  x.globalCompositeOperation='destination-in';const m=x.createLinearGradient(0,0,0,210);m.addColorStop(0,'#000000c0');m.addColorStop(.3,'#000000ff');m.addColorStop(1,'#00000000');x.fillStyle=m;x.fillRect(0,0,1040,210);
  const h=x.createLinearGradient(0,0,1040,0);h.addColorStop(0,'#0000');h.addColorStop(.15,'#000f');h.addColorStop(.85,'#000f');h.addColorStop(1,'#0000');x.fillStyle=h;x.fillRect(0,0,1040,210);D.rf=c}
 /* skyline clip (aurora only shows above the occluders) */
 const sk=new Path2D();sk.moveTo(0,-10);sk.lineTo(1600,-10);for(let i=400;i>=0;i--)sk.lineTo(i*4,lf_SK[i]);sk.closePath();D.sk=sk;
 /* water clip: open lake, excluding the bank, cabin, pier, lantern posts and right shore */
 const wp=new Path2D();wp.moveTo(320,FSW_Y+5);wp.lineTo(1600,FSW_Y+5);wp.lineTo(1600,562);wp.quadraticCurveTo(1460,566,1400,620);wp.quadraticCurveTo(1340,680,1360,760);wp.lineTo(1360,900);wp.lineTo(160,900);wp.lineTo(214,760);
 wp.lineTo(196,700);wp.lineTo(110,678);wp.lineTo(608,672);wp.lineTo(608,626);wp.lineTo(320,621);wp.closePath();
 [253,581].forEach(x=>wp.rect(x,522,16,98));D.wp=wp;
 /* glow sprites */
 D.gw=lf_glow('#ffa040',64);{const[c,x]=lf_cv(128,128);const q=x.createRadialGradient(64,64,0,64,64,64);q.addColorStop(0,'#ffa53aff');q.addColorStop(1,'#ffa53a00');x.fillStyle=q;x.fillRect(0,0,128,128);D.gl2=c}{const[c,x]=lf_cv(96,96);const q=x.createRadialGradient(48,48,0,48,48,48);q.addColorStop(0,'#fff0b8ff');q.addColorStop(.4,'#ffd070a0');q.addColorStop(1,'#ffc06000');x.fillStyle=q;x.fillRect(0,0,96,96);D.gl3=c}D.gy=lf_glow('#ffe6a0',32);D.gc=lf_glow('#9ff0ff',32);
 /* lantern sprite with a snow cap (anchor at 30,50) */
 {const[c,x]=lf_cv(60,90);const X=30,Y=56;x.fillStyle='#2a1a10';x.fillRect(X-14,Y-26,28,6);x.beginPath();x.moveTo(X-10,Y-26);x.lineTo(X,Y-38);x.lineTo(X+10,Y-26);x.fill();
  x.fillStyle=fkLin(x,0,Y-20,0,Y+16,['#fff2b8','#ffae3a']);x.fillRect(X-10,Y-20,20,34);x.lineWidth=3;x.strokeStyle='#2a1a10';x.strokeRect(X-10,Y-20,20,34);x.beginPath();x.moveTo(X,Y-20);x.lineTo(X,Y+14);x.stroke();x.fillStyle='#2a1a10';x.fillRect(X-13,Y+14,26,5);
  x.fillStyle='#ffffff60';x.fillRect(X-7,Y-17,3,26);
  x.fillStyle='#f4f8ff';x.beginPath();x.moveTo(X-16,Y-24);x.quadraticCurveTo(X-12,Y-34,X,Y-42);x.quadraticCurveTo(X+12,Y-34,X+16,Y-24);x.quadraticCurveTo(X,Y-28,X-16,Y-24);x.fill();x.lineWidth=1.8;x.strokeStyle=FKO;x.stroke();
  x.beginPath();x.moveTo(X-6,Y+19);x.quadraticCurveTo(X-5,Y+25,X-4,Y+28);x.quadraticCurveTo(X-3,Y+24,X-2,Y+19);x.fillStyle='#bfe8ff';x.fill();D.lan=c}
 /* ice floes (bobbing live) */
 D.fl=[[1190,612,150,34,1],[1270,724,200,46,2],[1110,834,140,32,3],[272,812,150,36,4],[520,548,90,13,5],[1010,556,124,16,6],[700,544,60,10,8]].map(([x,y,w,h,s])=>{const[c,g2]=lf_cv(w+40,h*2.6+30);lf_floe(g2,w/2+20,h/2+12,w,h,s*7,h>20?2.5:1.2);return{c,x:x-w/2-20,y:y-h/2-12,s}});
 D.rd=[];for(let i=0;i<9;i++)D.rd.push({x:616+i*8+lf_r(i+500)*5,y:702+lf_r(i+501)*10,h:44+lf_r(i+502)*46,p:i*1.3,c:i%3===0});
 D.gl=[[40,330],[92,262],[170,236],[250,320],[300,392],[60,700],[120,820],[30,780],[180,644],[330,630],[470,628],[560,640],[1380,600],[1470,700],[1520,770],[1440,840],[1560,560],[1240,600],[1300,712],[1080,826],[260,800]];
 /* smoke puff */
 {const[c,x]=lf_cv(64,64);const q=x.createRadialGradient(32,32,0,32,32,32);q.addColorStop(0,'#c8d4f0aa');q.addColorStop(.6,'#a8b4e050');q.addColorStop(1,'#a8b4e000');x.fillStyle=q;x.fillRect(0,0,64,64);D.sm=c}
 /* snow tiles */
 const tile=(S,n,r0,r1,a0,seed)=>{const[c,x]=lf_cv(S,S);for(let i=0;i<n;i++){const px=lf_r(i+seed)*S,py=lf_r(i+seed+300)*S,r=r0+lf_r(i+seed+600)*(r1-r0);x.globalAlpha=a0+lf_r(i+seed+900)*(1-a0);const q=x.createRadialGradient(px,py,0,px,py,r*1.8);q.addColorStop(0,'#ffffff');q.addColorStop(.45,'#f0f6ffcc');q.addColorStop(1,'#f0f6ff00');x.fillStyle=q;x.beginPath();x.arc(px,py,r*1.8,0,TAU);x.fill()}return c};
 const fl=R=>{const S=Math.ceil(R*2.2)*2,[c,x]=lf_cv(S,S),q=x.createRadialGradient(S/2,S/2,0,S/2,S/2,S/2);q.addColorStop(0,'#ffffff');q.addColorStop(.3,'#ffffffe0');q.addColorStop(.5,'#f4f8ff60');q.addColorStop(1,'#f0f6ff00');x.fillStyle=q;x.fillRect(0,0,S,S);return c};
 D.fk=[fl(2),fl(3),fl(4.2)];D.fs=[];for(let i=0;i<170;i++){const k=i<115?0:i<158?1:2;D.fs.push({x:lf_r(i+3000)*1680,y:lf_r(i+3100)*960,k,vy:[22,36,54][k]*(.8+lf_r(i+3200)*.4),vx:[6,10,15][k],sw:10+lf_r(i+3300)*24,p:lf_r(i+3400)*TAU,a:[.75,.85,.9][k]*(.6+lf_r(i+3500)*.4)})}}
/* ---------- back: drawn every frame behind the hero ---------- */
function lf_back(g,t){const D=lf_D;if(!D)return;
 /* aurora curtains, waving (re-rendered into a cache ~16 times a second; it moves slowly), clipped behind peaks/pines/cabin */
 if(!D.ac){const[c,x]=lf_cv(1600,460);D.ac=c;D.acx=x;D.at=-99}
 if(Math.abs(t-D.at)>.06){D.at=t;const a=D.acx;a.setTransform(1,0,0,1,0,0);a.clearRect(0,0,1600,460);a.globalCompositeOperation='lighter';
  const curt=(src,sw,amp,k,sp,ph,al,drift)=>{const dx=Math.sin(t*.13+ph)*drift,Y0=src.y0,HH=src.y1-src.y0;for(let x0=Math.max(0,src.x0-40);x0<Math.min(1600,src.x1+40);x0+=sw){const x1=x0+sw,f=x=>amp*Math.sin(x*k-t*sp+ph)+amp*.5*Math.sin(x*k*2.3+t*sp*1.4+ph*2),y0=f(x0),y1=f(x1);
    a.globalAlpha=al*(.82+.18*Math.sin(x0*.0045-t*.7+ph));let s0=x0+dx,w=sw,d0=0;if(s0<0){d0=-s0;w+=s0;s0=0}if(s0+w>1600)w=1600-s0;a.setTransform(1,(y1-y0)/sw,0,1,x0,y0);
    let mh=0;for(let k2=Math.max(0,x0>>2);k2<=Math.min(400,(x1>>2)+1);k2++)mh=Math.max(mh,lf_SK[k2]);const hh=Math.min(HH,mh-Math.min(y0,y1)+3-Y0);if(hh>2&&w>1)a.drawImage(src,s0,Y0,w,hh,d0,Y0,w,hh)}a.setTransform(1,0,0,1,0,0)};
  curt(D.aB,120,10,.006,.45,1.3,.85+.15*Math.sin(t*.5+1),24);curt(D.aA,120,13,.005,.38,0,.9+.1*Math.sin(t*.6),30);a.globalAlpha=1}
 g.save();g.clip(D.sk);g.globalCompositeOperation='lighter';g.drawImage(D.ac,0,0);g.restore();g.globalAlpha=1;
 /* twinkling stars (two batches) */
 for(let b=0;b<2;b++){g.globalAlpha=.45+.45*Math.sin(t*(1.3+b*.6)+b*2);g.fillStyle=b?'#d8fff0':'#ffffff';g.beginPath();for(let i=b;i<20;i+=2){const x=lf_r(i+1300)*1600,y=lf_r(i+1600)*(FSW_Y-200),r=2+lf_r(i+1900)*2.6;g.moveTo(x,y-r);g.quadraticCurveTo(x+r*.16,y-r*.16,x+r,y);g.quadraticCurveTo(x+r*.16,y+r*.16,x,y+r);g.quadraticCurveTo(x-r*.16,y+r*.16,x-r,y);g.quadraticCurveTo(x-r*.16,y-r*.16,x,y-r)}g.fill()}g.globalAlpha=1;
 /* chimney smoke */
 for(let i=0;i<5;i++){const p=(t*.12+i/5)%1,s=18+p*70;g.globalAlpha=(1-p)*.75*Math.min(1,p*6);g.drawImage(D.sm,220+p*60+Math.sin(t*.8+i*1.7)*10*p-s/2,160-p*170-s/2,s,s)}g.globalAlpha=1;
 /* aurora reflection on the lake, broken into wobbling strips */
 g.save();g.clip(D.wp,'evenodd');g.globalCompositeOperation='lighter';const ra=.62+.12*Math.sin(t*.6);
 for(let i=0;i<10;i++){const y0=i*21,ox=Math.sin(t*1.1+i*1.3)*(3+i*.9);g.globalAlpha=ra*(.85+.15*Math.sin(t*1.7+i*2.1));g.drawImage(D.rf,0,y0,1040,21,300+ox,FSW_Y+5+y0,1040,21)}
 /* shimmer streaks */
 g.globalAlpha=.5;g.fillStyle='#9affd8';g.beginPath();for(let i=0;i<22;i++){const u=i/22,y=FSW_Y+14+u*u*230,w=(16+u*110)*(.55+.45*Math.sin(t*1.3+i*1.7)),x=420+lf_r(i+40)*820+Math.sin(t*.7+i*2.3)*(8+u*30);g.rect(x-w/2,y,w,1.6+u*1.6)}g.fill();
 g.globalAlpha=.35;g.fillStyle='#ffc8f0';g.beginPath();for(let i=0;i<8;i++){const y=FSW_Y+10+i*9,w=30+30*Math.sin(t*1.1+i),x=900+lf_r(i+80)*380+Math.sin(t*.6+i)*20;g.rect(x-w/2,y,w,1.4)}g.fill();
 g.restore();g.globalAlpha=1;
 /* slow ripple rings */
 g.strokeStyle='#bfe8ff';g.lineWidth=1.4;for(let i=0;i<4;i++){const p=(t*.16+i*.25)%1,x=700+lf_r(i+70)*560,y=600+lf_r(i+71)*220,r=10+p*56;g.globalAlpha=(1-p)*.22;g.beginPath();g.ellipse(x,y,r,r*.28,0,0,TAU);g.stroke()}g.globalAlpha=1;
 /* bobbing ice floes */
 D.fl.forEach(F=>g.drawImage(F.c,F.x,F.y+Math.sin(t*.9+F.s*1.7)*1.6));
 /* frosted reeds by the end of the pier */
 {const R=D.rd;g.strokeStyle='#2e5a5a';g.lineWidth=3;g.beginPath();R.forEach(r=>{const sw=Math.sin(t*1.1+r.p)*5;g.moveTo(r.x,r.y);g.quadraticCurveTo(r.x+sw*.3,r.y-r.h*.6,r.x+sw,r.y-r.h)});g.stroke();
  g.strokeStyle='#e8f4ff';g.lineWidth=1.4;g.globalAlpha=.8;g.beginPath();R.forEach(r=>{const sw=Math.sin(t*1.1+r.p)*5;g.moveTo(r.x+sw*.7-1,r.y-r.h*.75);g.lineTo(r.x+sw-1,r.y-r.h)});g.stroke();g.globalAlpha=1;
  g.fillStyle='#6a4228';g.strokeStyle=FKO;g.lineWidth=1.6;g.beginPath();R.forEach(r=>{if(!r.c)return;const sw=Math.sin(t*1.1+r.p)*5;g.moveTo(r.x+sw+4,r.y-r.h-8);g.ellipse(r.x+sw,r.y-r.h-8,4,11,sw*.02,0,TAU)});g.fill();g.stroke();
  g.fillStyle='#f4f8ff';g.beginPath();R.forEach(r=>{if(!r.c)return;const sw=Math.sin(t*1.1+r.p)*5;g.moveTo(r.x+sw+5,r.y-r.h-16);g.ellipse(r.x+sw,r.y-r.h-16,5,3.4,0,0,TAU)});g.fill()}
 /* a shooting star now and then */
 {const p=(t%11)/11;if(p<.09){const u=p/.09,x=380+u*420,y=70+u*120;g.strokeStyle='#ffffff';g.lineWidth=2;g.globalAlpha=Math.sin(u*Math.PI)*.8;g.beginPath();g.moveTo(x,y);g.lineTo(x-70,y-20);g.stroke();g.globalAlpha=1;fkSpark(g,x,y,6,'#ffffff',Math.sin(u*Math.PI))}}
 /* glints on the snow */
 for(let b=0;b<2;b++){g.globalAlpha=Math.max(0,Math.sin(t*(1.7+b*.9)+b*2.4))*.9;g.fillStyle='#ffffff';g.beginPath();for(let i=b;i<D.gl.length;i+=2){const[x,y]=D.gl[i],r=2.6+(i%3);g.moveTo(x,y-r);g.lineTo(x+r*.25,y-r*.25);g.lineTo(x+r,y);g.lineTo(x+r*.25,y+r*.25);g.lineTo(x,y+r);g.lineTo(x-r*.25,y+r*.25);g.lineTo(x-r,y);g.lineTo(x-r*.25,y-r*.25);g.closePath()}g.fill()}g.globalAlpha=1;
 /* rope rail between the pier lanterns, with snow */
 g.strokeStyle=FKO;g.lineWidth=5;g.beginPath();g.moveTo(260,552);g.quadraticCurveTo(424,592,588,552);g.stroke();g.strokeStyle='#c8a46a';g.lineWidth=2.6;g.stroke();
 g.fillStyle='#f4f8ff';g.beginPath();[.2,.38,.55,.74].forEach(u=>{const x=(1-u)*(1-u)*260+2*u*(1-u)*424+u*u*588,y=(1-u)*(1-u)*552+2*u*(1-u)*592+u*u*552;g.moveTo(x+9,y-1);g.ellipse(x,y-2,9,4,0,0,TAU)});g.fill();
 /* lanterns (flicker) */
 [[260,514,0],[588,514,1],[122,500,2]].forEach(([x,y,i])=>{const f=.86+.14*Math.sin(t*9+i*3)*Math.sin(t*5.3+i);g.globalCompositeOperation='lighter';g.globalAlpha=.55*f;const R=130*f;g.drawImage(D.gl2,x-R,y-R,R*2,R*2);g.globalAlpha=.6*f;g.drawImage(D.gl3,x-50,y-52,100,100);g.globalCompositeOperation='source-over';g.globalAlpha=1;g.drawImage(D.lan,x-30,y-56+2)});
 /* window light breathing */
 g.globalCompositeOperation='lighter';g.globalAlpha=.22+.08*Math.sin(t*2.3)*Math.sin(t*3.7);g.drawImage(D.gw,186-80,495-80,160,160);g.drawImage(D.gw,136-44,336-44,88,88);g.globalCompositeOperation='source-over';g.globalAlpha=1}
/* ---------- front: snowfall and sparkles over everything ---------- */
function lf_front(g,t){const D=lf_D;if(!D)return;
 D.fs.forEach(F=>{const c=D.fk[F.k],x=((F.x+t*F.vx+Math.sin(t*.8+F.p)*F.sw)%1680+1680)%1680-40,y=((F.y+t*F.vy)%960+960)%960-30;g.globalAlpha=F.a;g.drawImage(c,x-c.width/2,y-c.width/2)});g.globalAlpha=1;
 for(let i=0;i<7;i++){const x=(lf_r(i+2000)*1600+t*(10+i*3))%1600,y=(lf_r(i+2100)*900+t*(18+i*2))%900,a=Math.max(0,Math.sin(t*1.6+i*2.3));if(a>.05)fkSpark(g,x+Math.sin(t+i)*14,y,3+lf_r(i)*3,i%2?'#c8fff0':'#ffffff',a*.8)}}
FSLOCART.frost={bg:lf_bg,back:lf_back,front:lf_front};
