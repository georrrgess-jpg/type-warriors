/* ===== 9.5 THE CROOKED CUE: menu icons (96r) =====
   Chunky baked icons for the hub's menu cards and the screens behind them. Painted once into a cache (PZ_ICO). */
const PZ_ICO={};
function pzIco(kind,s){s=s||120;const key=kind+s;if(PZ_ICO[key])return PZ_ICO[key];const c=pzCv(s,s),g=c.getContext('2d');g.lineJoin='round';g.lineCap='round';g.scale(s/120,s/120);
 const O=PZ_O,ball=(x,y,r,col,stripe,n)=>{g.fillStyle=stripe?'#fff8ec':col;g.beginPath();g.arc(x,y,r,0,TAU);g.fill();if(stripe){g.save();g.beginPath();g.arc(x,y,r,0,TAU);g.clip();g.fillStyle=col;g.fillRect(x-r,y-r*.48,r*2,r*.96);g.restore()}
  g.fillStyle='rgba(255,255,255,.55)';g.beginPath();g.ellipse(x-r*.35,y-r*.42,r*.3,r*.2,-.5,0,TAU);g.fill();if(n!=null){g.fillStyle='#fff';g.beginPath();g.arc(x,y,r*.42,0,TAU);g.fill();g.fillStyle='#12081f';g.font=`800 ${Math.round(r*.55)}px Poppins,sans-serif`;g.textAlign='center';g.textBaseline='middle';g.fillText(n,x,y+1)}
  g.strokeStyle=O;g.lineWidth=3.5;g.beginPath();g.arc(x,y,r,0,TAU);g.stroke()};
 if(kind==='practice'){/* a little table seen from above, tilted, with two balls and a cue */
  g.save();g.translate(60,64);g.rotate(-.12);g.fillStyle='#7a3e18';pzRR(g,-50,-34,100,68,12);g.fill();g.strokeStyle=O;g.lineWidth=4;g.stroke();
  g.fillStyle=pzLin(g,0,-26,0,26,[[0,'#3aa874'],[1,'#1b6a45']]);pzRR(g,-41,-25,82,50,6);g.fill();g.lineWidth=2.5;g.stroke();
  for(const [x,y] of[[-41,-25],[41,-25],[-41,25],[41,25],[0,-27],[0,27]]){g.fillStyle='#07040a';g.beginPath();g.arc(x,y,5.2,0,TAU);g.fill()}
  g.fillStyle='rgba(255,255,255,.14)';g.fillRect(-36,-20,70,6);g.restore();ball(48,62,9,'#fff8ec');ball(80,52,9,'#e8332a',false);
  g.save();g.translate(37,72);g.rotate(-.5);g.fillStyle='#e8c88a';g.fillRect(-26,-3,26,6);g.fillStyle='#4a2410';g.fillRect(-38,-4,14,8);g.strokeStyle=O;g.lineWidth=2.5;g.strokeRect(-38,-4,38,8);g.restore()}
 else if(kind==='trick'){/* a ball on a curved dotted path into a pocket, with a star */
  g.fillStyle='#07040a';g.beginPath();g.arc(96,30,14,0,TAU);g.fill();g.strokeStyle='#d8a03a';g.lineWidth=4;g.stroke();
  g.setLineDash([2,9]);g.strokeStyle='#ffd45a';g.lineWidth=5;g.beginPath();g.moveTo(26,92);g.bezierCurveTo(30,40,70,70,90,38);g.stroke();g.setLineDash([]);
  ball(30,90,15,'#2a6af0',false,2);
  g.save();g.translate(84,86);g.rotate(.2);g.fillStyle='#ffd45a';g.beginPath();for(let i=0;i<10;i++){const r=i%2?7:16,a=-Math.PI/2+i*Math.PI/5;g.lineTo(Math.cos(a)*r,Math.sin(a)*r)}g.closePath();g.fill();g.strokeStyle=O;g.lineWidth=3;g.stroke();g.restore()}
 else if(kind==='cues'){/* a wall rack with three cues */
  g.fillStyle='#6a3414';pzRR(g,18,84,84,16,6);g.fill();g.strokeStyle=O;g.lineWidth=3.5;g.stroke();g.fillStyle='#8a4a1e';pzRR(g,22,22,76,12,5);g.fill();g.stroke();
  const cue=(x,a,col,tip)=>{g.save();g.translate(x,92);g.rotate(a);g.fillStyle=col;g.beginPath();g.moveTo(-6,0);g.lineTo(6,0);g.lineTo(2.6,-80);g.lineTo(-2.6,-80);g.closePath();g.fill();g.strokeStyle=O;g.lineWidth=2.5;g.stroke();
   g.fillStyle='#f4e6c8';g.fillRect(-2.6,-80,5.2,-6);g.fillStyle=tip;g.fillRect(-2.6,-86,5.2,-4);g.strokeRect(-2.6,-90,5.2,10);g.fillStyle='#12081f';g.fillRect(-5,-26,10,5);g.restore()};
  cue(40,-.08,'#c8763a','#3a70d8');cue(60,0,'#2a2070','#d84a3a');cue(80,.08,'#3a8a5a','#3a70d8')}
 else if(kind==='rules'){/* a scroll with ruled lines and an 8-ball seal */
  g.fillStyle='#f4e2b0';g.beginPath();g.moveTo(26,22);g.lineTo(90,22);g.quadraticCurveTo(84,60,92,98);g.lineTo(30,98);g.quadraticCurveTo(22,60,26,22);g.closePath();g.fill();g.strokeStyle=O;g.lineWidth=3.5;g.stroke();
  g.fillStyle='#d8bc80';pzRR(g,18,14,80,14,7);g.fill();g.stroke();pzRR(g,22,92,80,14,7);g.fill();g.stroke();
  g.strokeStyle='#a8875a';g.lineWidth=3;for(let i=0;i<5;i++){g.beginPath();g.moveTo(36,40+i*10);g.lineTo(76-(i%2)*12,40+i*10);g.stroke()}
  ball(78,80,13,'#1a1a1a',false,8)}
 else if(kind==='trophy'){g.fillStyle='#ffd45a';g.beginPath();g.moveTo(34,26);g.lineTo(86,26);g.quadraticCurveTo(86,70,60,74);g.quadraticCurveTo(34,70,34,26);g.fill();g.strokeStyle=O;g.lineWidth=3.5;g.stroke();
  g.lineWidth=5;g.strokeStyle='#ffd45a';g.beginPath();g.arc(30,40,10,Math.PI*.5,Math.PI*1.5);g.stroke();g.beginPath();g.arc(90,40,10,-Math.PI*.5,Math.PI*.5);g.stroke();
  g.fillStyle='#c99a3a';g.fillRect(52,74,16,14);g.fillStyle='#8a5a1a';pzRR(g,38,88,44,12,4);g.fill();g.strokeStyle=O;g.lineWidth=3;g.stroke();g.strokeRect(52,74,16,14);
  g.fillStyle='rgba(255,255,255,.5)';g.fillRect(42,32,6,26)}
 else if(kind==='lock'){g.strokeStyle='#8a80c8';g.lineWidth=9;g.beginPath();g.arc(60,50,18,Math.PI,0);g.stroke();g.fillStyle='#4a3e90';pzRR(g,32,50,56,44,10);g.fill();g.strokeStyle=O;g.lineWidth=3.5;g.stroke();g.fillStyle='#12081f';g.beginPath();g.arc(60,68,6,0,TAU);g.fill();g.fillRect(57,70,6,12)}
 return PZ_ICO[key]=c}
