/* ===== RUNESTONE TOWER DEFENSE 10.1: UI audit fixes and battle feedback (98o, after 98n; prefix rpu) =====
   The twelve towers are open from the start (98b), so every bar, ring, tip and help text now speaks of twelve. This module:
   - fixes what the 10.1 UI audit found (tools/td/rpu_audit.py, overlap check tools/td/rpu_ovl.js): text that named only five tower
     keys, How to Play running off the stage with no scroll, the results card running off the stage, serif fonts on the results /
     pause / victory card, "new best!" pushed onto its own line by 97h's .rpnb, long tower names clipped in the bar and the info panel,
     the tip covered by the info panel, the Tower Skins grid spilling over its panel and its title under Back, the locked-world
     shade leaving the top of the side panel bright, the How to Play / Settings modal under the locked-world card, the Singularity
     Engine's help text quoting its old price, and the monster card's title touching its line;
   - adds feedback, display only (no coins, no supply): a kill-streak combo counter with escalating names, a wave-cleared fanfare
     (flawless waves and a new endless personal best are called out), stars that burst in one by one and mastery XP bars that
     fill on the results card, a personal best time and best combo on the results, and a Next goals card on the hub (next stars,
     next chest or skin, the closest mastery level, the daily first-win bonus).
   Reduced motion: nothing moves (the pieces just appear). Performance mode (rpgQ()==0): no sparkles or rings.
   State: R.rpuC (combo), R.rpuL0 / R.rpuFl (flawless waves), P.rp.rpu = {bt:{map:seconds}, bc:best combo}. */
const RPU={win:1.6,min:5,tiers:[[5,'Combo'],[10,'Rampage!'],[20,'Unstoppable!'],[35,'Legendary!'],[60,'Godlike!']]};
const rpuQ=()=>{try{return typeof rpgQ==='function'?rpgQ():1}catch(e){return 1}};
const rpuRM=()=>{try{return rpRM()}catch(e){return false}};
function rpuSave(){const r=RPP();if(!r.rpu||typeof r.rpu!=='object'||Array.isArray(r.rpu))r.rpu={};const u=r.rpu;if(!u.bt||typeof u.bt!=='object'||Array.isArray(u.bt))u.bt={};if(!(u.bc>=0))u.bc=0;return u}
/* shrink a one-line label until it fits its box (long tower names in the bar and the info panel) */
function rpuFit(el,min){if(!el||!el.isConnected)return;let fs=parseFloat(getComputedStyle(el).fontSize)||12,n=0;while(el.scrollWidth>el.clientWidth+.5&&fs>min&&n++<12){fs-=.5;el.style.setProperty('font-size',fs+'px','important')}}
const rpuKeysTxt=()=>RP_KEYS.join(' ');
/* ---------- text that named only the first five towers ---------- */
try{RP_TUT.build.p='Pick a tower in the bar below (each card shows its key), then click a glowing stone pad. You can also click a pad first and choose from the ring. Towers fire on their own.'}catch(e){}
try{const h=HELP.Modes.find(x=>x[0]==='Runestone Tower Defense');if(h)h[1]=h[1].replace('Pick a tower (Q W E R T)','Pick a tower (each card shows its key, all twelve are open from the start)')}catch(e){}
{const p0=rpPauseMenu;rpPauseMenu=function(){const r=p0.apply(this,arguments);try{const s=ov.querySelector('.rppause .rpph span');if(s&&/pick a tower/.test(s.textContent))s.innerHTML=`${RP_KEYS.slice(0,4).map(k=>`<kbd>${k}</kbd>`).join('')}<kbd>…</kbd> pick a tower (its key is on its card), then click a pad`}catch(e){console.error(e)}return r}}
/* ---------- How to Play: scrolls inside the stage, the twelve towers as cards, current prices ---------- */
{const h0=rpHowTo;rpHowTo=function(){const r=h0.apply(this,arguments);try{const m=ov.querySelector('#rpmod .rpmc2'),w=m&&m.querySelector('.rphw');if(w&&!m.classList.contains('rpuhow')){m.classList.add('rpuhow');
  for(const p of w.querySelectorAll('p')){const t=p.textContent;
   if(/^1 · Build\./.test(t))p.innerHTML=p.innerHTML.replace('(or press Q, W, E, R, T)','(or press the key shown on its card)');
   if(/^Singularity Engine\./.test(t))p.innerHTML=p.innerHTML.replace(/\(\d+ supply, key G\)/,`(${rpCost('grav',1)} supply, key G)`);
   if(/^Clockwork Hive\./.test(t))p.innerHTML=p.innerHTML.replace(/\(\d+ supply, key H\)/,`(${rpCost('hive',1)} supply, key H)`);
   if(/^Towers\./.test(t)){const g=document.createElement('div');g.className='rpuhg';
    g.innerHTML=`<p><b>Towers.</b> All twelve are open from the start, on every map (the Dragon Roost joins once you win Ember Crown). Press a tower's key or pick its card, then click a pad.</p><div class="rputw">${RP_TWORDER.map((t,i)=>`<span style="--c:${RPTW[t].col}"><img alt="" src="${rpIconCanvas(t,1,rpSkinOf(t),64)}"><b>${esc(RPTW[t].n)}</b><small>${esc(RPTW[t].role||'')}</small><em><kbd>${RP_KEYS[i]}</kbd>${RPI.sup}${rpCost(t,1)}</em></span>`).join('')}</div>`;
    p.replaceWith(g);g.querySelectorAll('.rputw b').forEach(b=>rpuFit(b,10))}}}}catch(e){console.error(e)}return r}}
/* ---------- results: fit on the stage, fonts, stars, mastery bars, personal bests ---------- */
{const v0=rpVictory;rpVictory=function(){const R=RPX;if(R&&R.wst!=='done')R.rpuWinT=R.time;return v0.apply(this,arguments)}}
{const f0=rpFinish;rpFinish=function(won){const R=RPX;if(!R||R.over||R.map.endless)return f0.apply(this,arguments);try{const u=rpuSave(),id=R.map.id,old=u.bt[id]||0,c=R.rpuC?R.rpuC.best:0,bc0=u.bc,t=Math.round(R.rpuWinT!=null?R.rpuWinT:R.time);
  /* the results card is drawn inside rpFinish, so the bests are worked out first (R.rpuRes) */
  R.rpuRes={t:won?t:0,bt:old,newT:!!won&&!R.free&&(!old||t<old),combo:c,bc:bc0,newC:c>=RPU.min&&c>bc0};if(R.rpuRes.newT)u.bt[id]=t;if(R.rpuRes.newC)u.bc=c}catch(e){console.error(e)}
 return f0.apply(this,arguments)}}
{const f0=rpFinishEndless;rpFinishEndless=function(){const R=RPX;try{const u=rpuSave(),c=R&&R.rpuC?R.rpuC.best:0,bc0=u.bc;if(R){R.rpuRes={combo:c,bc:bc0,newC:c>=RPU.min&&c>bc0};if(R.rpuRes.newC)u.bc=c}}catch(e){console.error(e)}return f0.apply(this,arguments)}}
function rpuResPost(){const R=RPX,res=R&&R.result,box=ov.querySelector('.rpres');if(!res||!box||box.dataset.rpu)return;box.dataset.rpu=1;const rm=rpuRM(),q=rpuQ();
 /* the stars burst in one by one, each with a chime */
 const st=box.querySelectorAll('.rpvst>span');st.forEach((s,i)=>{if(i<res.stars){s.classList.add('rpuon');if(!rm&&q>0)s.insertAdjacentHTML('beforeend','<i class="rpusb" aria-hidden="true"></i>');
  if(!rm)setTimeout(()=>{try{if(box.isConnected)beep([784,988,1319][i]||1319,.16,'triangle',.45)}catch(e){}},(.35+i*.2)*1000)}});
 /* personal bests: best time on a won map, best combo anywhere */
 const u=R.rpuRes;if(u){const ch=[];if(u.t)ch.push(`<span class="rpupb${u.newT?' new':''}">${RPI.star(1,16)}${u.newT?'New best time':'Time'} <b>${rpFmtT(u.t)}</b>${!u.newT&&u.bt?` <small>best ${rpFmtT(u.bt)}</small>`:''}</span>`);
  if(u.combo>=RPU.min)ch.push(`<span class="rpupb${u.newC?' new':''}"><i>⚡</i>${u.newC?'New best combo':'Best combo'} <b>×${u.combo}</b>${!u.newC&&u.bc?` <small>record ×${u.bc}</small>`:''}</span>`);
  if(ch.length){const d=document.createElement('div');d.className='rpupbs';d.innerHTML=ch.join('');const sub=box.querySelector('.rpsub');if(sub)sub.after(d);else box.prepend(d)}}
 /* mastery bars fill from where they were before this battle */
 const rows=[...box.querySelectorAll('.rpyres .rpyr')],G=R.mastG||{},ts=Object.keys(G).sort((a,b)=>G[b]-G[a]).slice(0,6);
 rows.forEach((row,i)=>{const t=ts[i],s=row.querySelector('em s');if(!t||!s||rm)return;const x=rpyXP(t),x0=Math.max(0,x-G[t]),l=rpyLevel(t),nx=RPY_LV[l+1],lo=RPY_LV[l]||0,to=nx?(x-lo)/(nx-lo):1,from=row.classList.contains('up')?0:Math.max(0,Math.min(1,(x0-lo)/((nx||x0+1)-lo)));
  s.style.transform=`scaleX(${from.toFixed(3)})`;s.style.transition='none';setTimeout(()=>{if(!s.isConnected)return;s.style.transition='transform .9s cubic-bezier(.2,.8,.2,1)';s.style.transform=`scaleX(${Math.max(0,Math.min(1,to)).toFixed(3)})`;
   if(row.classList.contains('up'))setTimeout(()=>{if(row.isConnected){row.classList.add('rpulv');try{rpSfx('up')}catch(e){}}},900)},900+i*140)});
 box.classList.add('rpufit')}
{const r0=rpResult;rpResult=function(){const out=r0.apply(this,arguments);try{rpuResPost()}catch(e){console.error(e)}return out}}
{const r0=rpResultEndless;rpResultEndless=function(){const out=r0.apply(this,arguments);try{rpuResPost()}catch(e){console.error(e)}return out}}
/* ---------- the battle: kill-streak combo ---------- */
function rpuComboEl(){const h=$('rphud');if(!h)return null;let el=h.querySelector('#rpucombo');if(!el){el=document.createElement('div');el.id='rpucombo';el.className='rpucombo';el.hidden=true;
  el.innerHTML='<span class="rpucx"><b>×0</b><small>COMBO</small></span><em></em><i class="rpuct"><s></s></i>';h.appendChild(el)}return el}
function rpuTier(n){let t=RPU.tiers[0];for(const x of RPU.tiers)if(n>=x[0])t=x;return t}
function rpuKill(R,e){const c=R.rpuC||(R.rpuC={n:0,t:-9,best:0,shown:0});if(R.time-c.t>RPU.win)c.n=0;c.n++;c.t=R.time;if(c.n>c.best)c.best=c.n;if(c.n<RPU.min)return;
 const el=rpuComboEl();if(!el)return;const rm=rpuRM(),tier=rpuTier(c.n),up=tier!==c.tier;c.tier=tier;el.querySelector('b').textContent='×'+c.n;const em=el.querySelector('em');if(up){em.textContent=tier[0]>=10?tier[1]:'';el.dataset.t=RPU.tiers.indexOf(tier)}
 if(el.hidden){el.hidden=false;c.shown=1}el.classList.remove('out');
 if(!rm&&el.animate){try{el.querySelector('.rpucx').animate([{transform:'scale(1.35)'},{transform:'scale(1)'}],{duration:up&&tier[0]>=10?420:220,easing:'cubic-bezier(.34,1.56,.64,1)'});
  if(up&&tier[0]>=10){em.animate([{transform:'translateY(6px) scale(.6)',opacity:0},{transform:'translateY(0) scale(1.15)',opacity:1,offset:.6},{transform:'none',opacity:1}],{duration:420,easing:'ease-out'});
   if(rpuQ()>0){const p=rpPos(R,e);try{rpRing(p.x,p.y-30,['#ffd45a','#ff9a3a','#ff6ad8','#7ad8ff','#ffffff'][RPU.tiers.indexOf(tier)]||'#ffd45a',150+tier[0]*2,6)}catch(x){}}}
  const spd=Math.max(1,R.spd||1);el.querySelector('.rpuct s').animate([{transform:'scaleX(1)'},{transform:'scaleX(0)'}],{duration:RPU.win*1000/spd,fill:'forwards'})}catch(x){}}
 if(up&&tier[0]>=10)try{beep(440+RPU.tiers.indexOf(tier)*140,.12,'triangle',.4);setTimeout(()=>beep(660+RPU.tiers.indexOf(tier)*180,.16,'triangle',.4),80)}catch(x){}}
{const k0=rpKillFoe;rpKillFoe=function(e,src){const was=!!(e&&e.dead);const r=k0.apply(this,arguments);try{const R=RPX;if(R&&e&&!was&&e.dead&&R.wst!=='done')rpuKill(R,e)}catch(x){console.error(x)}return r}}
{const t0=rpHudTick;rpHudTick=function(){const r=t0.apply(this,arguments);try{const R=RPX,c=R&&R.rpuC;if(c&&c.shown&&R.time-c.t>RPU.win){c.shown=0;c.n=0;c.tier=null;const el=$('rpucombo');if(el){if(rpuRM())el.hidden=true;else{el.classList.add('out');setTimeout(()=>{if(el.classList.contains('out'))el.hidden=true},260)}}}}catch(e){}return r}}
/* ---------- the battle: wave cleared ---------- */
{const s0=rpWaveStart;rpWaveStart=function(){const R=RPX;const out=s0.apply(this,arguments);try{if(R)R.rpuL0=R.leaked||0}catch(e){}return out}}
function rpuFanfare(R,o){const h=$('rphud');if(!h)return;let el=h.querySelector('#rpuwave');if(el)el.remove();el=document.createElement('div');el.id='rpuwave';el.className='rpuwave'+(o.best?' best':'');el.setAttribute('role','status');
 const rm=rpuRM(),q=rpuQ();el.innerHTML=`<div class="rpuwr">${o.tag?`<small>${o.tag}</small>`:''}<b>${o.t}</b><span>${o.chips.map(c=>`<em>${c}</em>`).join('')}</span></div>${!rm&&q>0?'<i class="rpusp" aria-hidden="true">'+'<s></s>'.repeat(8)+'</i>':''}`;h.appendChild(el);
 /* a tutorial tip at the top keeps its place: the ribbon drops below it */
 const tip=$('rptut');if(tip&&!tip.hidden&&tip.offsetHeight&&tip.offsetTop<330)el.style.top=(tip.offsetTop+tip.offsetHeight+14)+'px';
 if(!rm){try{beep(523,.09,'triangle',.4);setTimeout(()=>beep(659,.09,'triangle',.4),90);setTimeout(()=>beep(784,.09,'triangle',.4),180);setTimeout(()=>beep(o.best?1319:1047,.22,'triangle',.45),270)}catch(e){}}
 clearTimeout(rpuFanfare.t);rpuFanfare.t=setTimeout(()=>{if(!el.isConnected)return;el.classList.add('out');setTimeout(()=>el.remove(),rm?0:320)},o.best?2600:1900)}
{const w0=rpWaveDone;rpWaveDone=function(){const R=RPX,leak0=R?R.rpuL0:0;const out=w0.apply(this,arguments);try{if(!R||R!==RPX||R.wst!=='build'||R.over)return out;
 const i=R.tx.findIndex(t=>/ cleared · \+/.test(t.s));let b=0,c=0;if(i>=0){const m=R.tx[i].s.match(/\+(\d+) supply · \+(\d+) coins/);if(m){b=+m[1];c=+m[2]}R.tx.splice(i,1)}
 const flaw=(R.leaked||0)===(leak0||0);R.rpuFl=flaw?(R.rpuFl||0)+1:0;const wn=R.free?R.wave-R.map.waves:R.wave;
 const chips=[`${RPI.sup}+${b} supply`,`${RPI.coin}+${c} coins`];let tag=flaw?(R.rpuFl>=3?`FLAWLESS ×${R.rpuFl}`:'FLAWLESS'):'',best=false;
 if(R.map.endless){const eb=RPP().ebest||0;if(eb>0&&R.wave>eb&&!R.rpuPB){R.rpuPB=1;best=true;tag='NEW PERSONAL BEST';chips.unshift(`past your best of ${eb}`)}}
 rpuFanfare(R,{t:`${R.free?'Freeplay wave':'Wave'} ${wn} cleared!`,chips,tag,best})}catch(e){console.error(e)}return out}}
/* ---------- the hub: next goals ---------- */
function rpuGoals(w){const r=RPP(),G=[];const W=w>1?RP_WORLD(w):null,maps=w>1?W.maps:RP_MAPS.filter(m=>!m.world||m.world===1).map(m=>m.id).filter(id=>!RP_MAP(id).endless);
 const open=id=>w>1?rpMapOpen2(RP_MAP(id)):RP_MAPOPEN(RP_MAP(id));
 const m=maps.find(id=>open(id)&&(r.stars[id]||0)<3);if(m){const n=r.stars[m]||0;G.push({k:'star',id:m,t:n?`Earn 3 stars on <b>${esc(RP_MAP(m).n)}</b>`:`Win <b>${esc(RP_MAP(m).n)}</b>`,s:n?`${n} / 3 stars so far`:'its first star opens the next map'})}
 const sn=maps.reduce((a,id)=>a+(r.stars[id]||0),0);
 if(w>1){const C=RPW_CHEST[w]||[],nx=C.find(([need])=>sn<need);if(nx)G.push({k:'chest',t:`${nx[0]-sn} more ${nx[0]-sn>1?'stars':'star'} for the <b>${cmn(nx[1])}-coin chest</b>`,s:`${sn} / ${nx[0]} stars in ${esc(W.n)}`})}
 else{const nx=RP_SKINS.find(s=>sn<s.need);if(nx)G.push({k:'chest',t:`${nx.need-sn} more ${nx.need-sn>1?'stars':'star'} for <b>${esc(nx.n)}</b>`,s:`${sn} / ${nx.need} stars · a tower skin`});else if(sn<RP_TITLE_NEED)G.push({k:'chest',t:`${RP_TITLE_NEED-sn} more for the <b>Rampart Warden</b> title`,s:`${sn} / ${RP_TITLE_NEED} stars`})}
 try{let best=null;for(const t of RP_TWORDER){const x=rpyXP(t),l=rpyLevel(t),nx=RPY_LV[l+1];if(!nx||!x)continue;const f=(x-(RPY_LV[l]||0))/(nx-(RPY_LV[l]||0));if(!best||f>best.f)best={t,f,l,need:nx-x}}
  if(best)G.push({k:'mast',t:`<b>${esc(RPTW[best.t].n)}</b> mastery ${RPY_ROM[best.l+1]} in ${cmn(best.need)} XP`,s:'a new skin at every level',f:best.f,tw:best.t});else G.push({k:'mast',t:'Win battles to earn <b>Tower Mastery</b> XP',s:'every level unlocks a tower skin',f:0})}catch(e){}
 return G.slice(0,3)}
function rpuHubGoals(back){const hub=ov.querySelector('.rphub');if(!hub||hub.querySelector('.rpugoal'))return;const w=typeof RPW_VIEW==='number'?RPW_VIEW:1;if(w>1&&!rpWorldOpen(w))return;
 const G=rpuGoals(w),r=RPP(),sm=RP_MAP(RPSEL),daily=sm&&!sm.endless&&(r.day!==rpDay()||!r.dayDone[sm.id]);if(!G.length&&!daily)return;
 const ic={star:RPI.star(1,18),chest:RPI.coin,mast:'<i class="rpugm">✦</i>'};const d=document.createElement('div');d.className='rpugoal';
 d.innerHTML=`<small>NEXT GOALS</small>${G.map(g=>`<p class="rpug rpug-${g.k}"${g.id?` data-m="${g.id}"`:''}><span class="rpugi">${g.tw?`<img alt="" src="${rpIconCanvas(g.tw,1,rpSkinOf(g.tw),48)}">`:ic[g.k]}</span><span><span class="rpugt">${g.t}</span><em>${g.s}</em>${g.f>0?`<i class="rpugb"><s style="transform:scaleX(${Math.max(.02,Math.min(1,g.f)).toFixed(3)})"></s></i>`:''}</span></p>`).join('')}${daily?`<p class="rpugd">${RPI.coin}First win today on ${esc(sm.n)} pays <b>×${RPT.FIRSTDAY}</b></p>`:''}`;
 hub.appendChild(d);d.querySelectorAll('.rpug[data-m]').forEach(p=>p.onclick=()=>{const id=p.dataset.m;if(RPSEL===id)return;RPSEL=id;try{rpSfx('key',2)}catch(e){}rampartsMenu(back)})}
{const m0=rampartsMenu;rampartsMenu=function(back){const out=m0.apply(this,arguments);try{rpuHubGoals(back)}catch(e){console.error(e)}return out}}
/* ---------- the tower bar and info panel: long names fit ---------- */
{const h0=rpHudOn;rpHudOn=function(){const r=h0.apply(this,arguments);try{const h=$('rphud');if(h)requestAnimationFrame(()=>h.querySelectorAll('.rpcard .rpct>b').forEach(b=>rpuFit(b,8)))}catch(e){}return r}}
{const i0=rpInfoBuild;rpInfoBuild=function(R,tw,el){const r=i0.apply(this,arguments);try{const b=el&&el.querySelector('.rpih b');if(b)rpuFit(b,16)}catch(e){}return r}}
/* ---------- styles ---------- */
{const st=document.createElement('style');st.textContent=`
.rpsub .rpnb{display:inline;margin:0;gap:0}
.rph.rp7.rp12 .rpcard{animation-delay:calc(var(--i,0)*22ms + .04s)}
.rpres .res>div,.rpres .res{font:600 13px var(--ui);color:#c4badf}.rpvic p,.rppause>p{font-family:var(--ui)}.rppause>p{font-weight:600;font-size:16px;color:#e8e0ff}
.rpres.rpufit{max-height:872px;box-sizing:border-box;overflow-y:auto;gap:6px;padding:16px 30px 18px;scrollbar-width:thin;scrollbar-color:#6a5ac8 transparent}
.rpres.rpufit h2{font-size:46px;line-height:1}.rpres.rpufit .rpvst svg{width:46px;height:46px}.rpres.rpufit .wrpay{padding:6px 18px!important}.rpres.rpufit .rpwnew{padding:6px 14px}.rpres.rpufit .rpwnew .rpwlki{width:42px;height:42px}.rpres.rpufit .res{gap:6px 10px;display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));width:100%}.rpres.rpufit .res b{font-size:22px}
.rpres.rpufit .wrpay{padding-top:8px;padding-bottom:8px}.rpres.rpufit .wrxp{margin:0;font-size:14px;line-height:1.3}.rpres.rpufit .xpbar{margin:0 auto}
.rpres.rpufit .rpunls{gap:8px;flex-wrap:wrap;justify-content:center}.rpres.rpufit .rpunl{display:grid;grid-template-columns:44px auto;grid-template-rows:auto auto;column-gap:8px;align-items:center;padding:2px 12px 2px 6px;text-align:left}
.rpres.rpufit .rpunl img{grid-row:1/3;width:44px;height:44px}.rpres.rpufit .rpunl b{font-size:13px}.rpres.rpufit .rpunl small{font-size:11px}
.rpres.rpufit>.row{position:sticky;bottom:-18px;z-index:2;margin:0 -30px -18px;padding:10px 30px 14px;align-self:stretch;justify-content:center;background:linear-gradient(180deg,#100a3000,#100a30f6 30%)}
.rpres.rpufit .rpwnew{margin:2px 0}.rpres.rpufit .rpyres{margin:2px 0;padding:6px 12px}.rpres.rpufit .rpyres>div{margin-top:2px}.rpres.rpufit .rpyres>div{grid-template-columns:1fr 1fr 1fr}.rpres.rpufit .rpebig b{font-size:80px;line-height:1.1;margin-top:6px}.rpres.rpufit .rpebig span{margin-top:4px}.rpwnew b{line-height:1.18}
.rpvst>span{position:relative;display:inline-block}.rpusb{position:absolute;left:50%;top:50%;width:84px;height:84px;margin:-42px 0 0 -42px;border-radius:50%;border:4px solid #ffd45a;pointer-events:none;opacity:0;transform:scale(.3);animation:rpuSB .7s ease-out forwards;animation-delay:calc(var(--d,0s) + .12s)}
@keyframes rpuSB{0%{opacity:.95;transform:scale(.3)}100%{opacity:0;transform:scale(1.5)}}
.rpupbs{display:flex;gap:8px;justify-content:center;flex-wrap:wrap}.rpupb{display:inline-flex;align-items:center;gap:6px;padding:4px 12px;border-radius:12px;background:#12081f90;border:2px solid #3a3070;font:600 13px var(--ui);color:#c4badf}
.rpupb b{color:#fff8e8;font-weight:800}.rpupb small{font:600 11.5px var(--ui);color:#8a7ec0}.rpupb i{font-style:normal;color:#ffd45a}.rpupb svg{width:16px;height:16px}
.rpupb.new{border-color:#7dffb0;color:#7dffb0;animation:rpuPop .5s cubic-bezier(.34,1.56,.64,1) .9s backwards}.rpupb.new b{color:#7dffb0}
@keyframes rpuPop{0%{opacity:0;transform:scale(.6)}100%{opacity:1;transform:none}}
.rpyr.rpulv{animation:rpuLv .6s cubic-bezier(.34,1.56,.64,1)}@keyframes rpuLv{0%{transform:scale(1)}40%{transform:scale(1.06)}100%{transform:none}}
.rpfoe b{line-height:1.2;margin-bottom:1px}.rpih b{line-height:1.22;margin:-2px 0 -3px}
.rph:has(#rpinfo:not([hidden])) #rptut,.rph:has(#rpring:not([hidden])) #rptut{opacity:.12!important;pointer-events:none;transition:opacity .18s}
.rpysk .rpygrid{grid-template-columns:repeat(4,minmax(0,1fr))}.rpysk .rpcsk>b{max-width:100%;overflow-wrap:anywhere;justify-content:center}
.rpc2sk .rpcskh{top:76px}#ov .rpc2sk .rpcskh h1{font-size:54px}.rpc2sk .rpcskh p{margin-top:8px}
#ov .rpysk .rpcsk>b{white-space:normal!important;text-overflow:clip!important;overflow:visible!important}
.rpwlk{inset:0!important}.rphub .rphtop,.rphub .rpwtabs{z-index:7}.rphub .rpmod{z-index:20}
.rpmc2.rpuhow{width:920px;max-height:840px;box-sizing:border-box;display:flex;flex-direction:column}.rpuhow h2{flex:none}
.rpuhow .rphw{flex:1;min-height:0;overflow-y:auto;padding-right:12px;margin-right:-12px;scrollbar-width:thin;scrollbar-color:#6a5ac8 transparent;overscroll-behavior:contain}
.rputw{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:2px 0 12px}.rputw>span{display:grid;grid-template-columns:44px 1fr;grid-template-rows:auto auto auto;column-gap:8px;align-items:center;padding:6px 8px;border-radius:14px;background:#12081f90;border:2px solid #3a3070;border-left-color:var(--c)}
.rputw img{grid-row:1/4;width:44px;height:44px}.rputw b{font:800 13px var(--ui);color:#fff8e8!important;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.rputw small{font:600 11px var(--ui);color:#a99be0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.rputw em{display:flex;align-items:center;gap:4px;font:800 12px var(--ui);font-style:normal;color:var(--rpg,#ffd45a)}.rputw em svg{width:14px;height:14px}.rputw kbd{min-width:18px;padding:0 4px;border-radius:5px;background:#2a1f6a;border:1px solid #6a5ac8;color:#e8e0ff;font:800 11px var(--ui);text-align:center;margin-right:4px}
.rpucombo{position:absolute;left:14px;top:84px;display:flex;flex-direction:column;align-items:flex-start;gap:2px;pointer-events:none;z-index:3;transition:opacity .25s}.rpucombo[hidden]{display:none}.rpucombo.out{opacity:0}
.rpucx{display:flex;align-items:baseline;gap:6px;padding:4px 14px 6px;border-radius:14px;background:linear-gradient(180deg,#2a1e5af2,#140c36f4);border:2px solid #ffd45a;box-shadow:0 0 0 2px #12081f;transform-origin:left center}
.rpucx b{font:400 34px/1 'Pirata One',Georgia,serif;color:#ffd45a;text-shadow:0 2px 0 #12081f}.rpucx small{font:800 11px var(--ui);letter-spacing:.22em;color:#e8e0ff}
.rpucombo em{font:400 22px/1 'Pirata One',Georgia,serif;font-style:normal;color:#ff9a3a;text-shadow:0 2px 0 #12081f;padding:3px 12px 4px;border-radius:12px;background:#12081fd8;border:2px solid #3a3070}.rpucombo em:empty{display:none}
.rpucombo[data-t="2"] .rpucx{border-color:#ff9a3a}.rpucombo[data-t="2"] em{color:#ffb04a}.rpucombo[data-t="3"] .rpucx{border-color:#ff6ad8}.rpucombo[data-t="3"] em{color:#ff8ae0}.rpucombo[data-t="4"] .rpucx{border-color:#7ad8ff}.rpucombo[data-t="4"] em{color:#9ae8ff}
.rpuct{display:block;width:100%;height:4px;margin-top:2px;border-radius:3px;background:#12081fa0;overflow:hidden}.rpuct s{display:block;height:100%;background:#ffd45a;transform-origin:left center}
.rpuwave{position:absolute;left:0;right:0;top:150px;display:grid;place-items:center;pointer-events:none;z-index:3}
.rpuwr{display:flex;flex-direction:column;align-items:center;gap:4px;padding:10px 34px 12px;border-radius:22px;background:linear-gradient(180deg,#2a1e5af0,#140c36f4);border:2px solid #ffd45a;box-shadow:0 0 0 3px #12081f,0 16px 36px #0009;animation:rpuWin .5s cubic-bezier(.34,1.56,.64,1)}
.rpuwave.out .rpuwr{animation:rpuWout .3s ease-in forwards}.rpuwave.best .rpuwr{border-color:#7dffb0}
.rpuwr small{font:800 12px var(--ui);letter-spacing:.24em;color:#7dffb0}.rpuwr b{font:400 44px/1 'Pirata One',Georgia,serif;color:#ffd45a;text-shadow:0 3px 0 #12081f}
.rpuwr span{display:flex;gap:8px}.rpuwr em{display:inline-flex;align-items:center;gap:5px;padding:3px 10px;border-radius:10px;background:#12081f;font:800 14px var(--ui);font-style:normal;color:#fff8e8}.rpuwr em svg{width:16px;height:16px}
@keyframes rpuWin{0%{opacity:0;transform:translateY(-14px) scale(.7)}100%{opacity:1;transform:none}}@keyframes rpuWout{to{opacity:0;transform:translateY(-10px) scale(.94)}}
.rpusp{position:absolute;left:50%;top:50%;width:0;height:0}.rpusp s{position:absolute;left:-5px;top:-5px;width:10px;height:10px;border-radius:2px;background:#ffd45a;opacity:0;animation:rpuSp .8s ease-out .1s forwards}
.rpusp s:nth-child(2n){background:#fff4c8}.rpusp s:nth-child(3n){background:#7ad8ff}
${[0,1,2,3,4,5,6,7].map(i=>{const a=i/8*Math.PI*2,x=Math.round(Math.cos(a)*230),y=Math.round(Math.sin(a)*70);return `.rpusp s:nth-child(${i+1}){--x:${x}px;--y:${y}px}`}).join('')}
@keyframes rpuSp{0%{opacity:1;transform:translate(0,0) rotate(0) scale(1)}100%{opacity:0;transform:translate(var(--x),var(--y)) rotate(200deg) scale(.4)}}
.rpugoal{position:absolute;left:26px;top:146px;width:370px;box-sizing:border-box;padding:10px 14px 10px;border-radius:18px;background:linear-gradient(180deg,#241a5cf0,#120c34f4);border:2px solid #4a3a90;box-shadow:0 0 0 2px #12081f,0 10px 24px #0008;z-index:3;animation:rpuPop .45s cubic-bezier(.34,1.56,.64,1) .15s backwards}
.rpugoal>small{display:block;font:800 11px var(--ui);letter-spacing:.24em;color:#7ad8ff;margin-bottom:4px}
.rpug{display:flex;gap:10px;align-items:center;margin:6px 0 0}.rpug-star{cursor:pointer}.rpug-star:hover .rpugt{color:#fff}
.rpugi{flex:none;display:grid;place-items:center;width:30px;height:30px;border-radius:10px;background:#12081f;border:2px solid #3a3070}.rpugi svg{width:18px;height:18px}.rpugi img{width:34px;height:34px;margin-top:-6px}.rpugm{font-style:normal;font-size:16px;color:#c89aff}
.rpug>span:last-child{display:flex;flex-direction:column;min-width:0;flex:1}.rpugt{font:600 13px/1.25 var(--ui);color:#e8e0ff}.rpugt b{color:#ffd45a}.rpug em{font:600 11px var(--ui);font-style:normal;color:#8a7ec0}
.rpugb{display:block;height:5px;margin-top:3px;border-radius:3px;background:#2a1f6a;overflow:hidden}.rpugb s{display:block;height:100%;background:linear-gradient(90deg,#c89aff,#ffd45a);transform-origin:left center}
.rpugd{display:flex;align-items:center;gap:6px;margin:8px 0 0;padding-top:7px;border-top:1px solid #3a3070;font:600 12px var(--ui);color:#c4badf}.rpugd b{color:#7dffb0}.rpugd svg{width:16px;height:16px}
@media (prefers-reduced-motion:reduce){.rpuwr,.rpugoal,.rpupb.new,.rpyr.rpulv,.rpusb{animation:none!important}.rpusb{display:none}}
.rprm .rpuwr,.rprm .rpusp{animation:none!important}.rprm .rpusp{display:none}`;document.head.appendChild(st)}
