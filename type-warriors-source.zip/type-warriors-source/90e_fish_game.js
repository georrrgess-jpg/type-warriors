/* ===== MOONLIT FISHING: the game loop =====
   States: idle -> cast -> wait -> bite/reel (one word per stage; Rare 2 stages, Legendary 3) -> show (the catch
   spectacle, scaled to rarity) -> reveal (Sell / Keep in the side panel) -> idle. A word that runs out of time costs a
   line heart (Legendary fish allow one retry); with no hearts left the fish escapes.
   Typing: physical keys (document keydown, capture) and the hidden input `inp` for touch keyboards. Space or Enter casts,
   skips a spectacle (after a moment) and takes the default choice on a catch. Esc leaves. Everything animates on one
   canvas (90d) plus a few HTML overlays (90f).
   Animation (update 7): each state sets TARGETS for the rod (angle, fish load, slack, hero lean) and a spring rig (fsRig)
   follows them, so nothing pops between states; tip flex comes from the rod's angular acceleration (cast whip, recoil).
   The bobber's dip is a spring too (plop, nibbles, bite). Splashes are crowns (fsCrown). The catch show shares one fish
   pose (fsShowPose) between the line (hooked to the mouth) and the drawing, and is painted after the scene dim. */
const FS={st:'off',T:0,t0:0,pt:[],sh:[],bob:null,view:{},on:false};
const fsNow=()=>performance.now()/1000;
const fsRM=()=>{try{return matchMedia('(prefers-reduced-motion: reduce)').matches}catch(e){return false}};
function fsSet(st){FS.st=st;FS.t0=fsNow();try{fsHudState()}catch(e){}}
/* ---------- sounds (small synth phrases on the game's beep) ---------- */
function fsSfx(k,x){const B=(f,d,ty,v,at)=>setTimeout(()=>{try{beep(f,d,ty,v)}catch(e){}},(at||0)*1000),A=(fs,step,ty,v,d)=>fs.forEach((f,i)=>B(f,d||.12,ty||'triangle',v==null?.4:v,i*(step||.08)));
 if(k==='cast'){B(700,.05,'sine',.25);B(520,.06,'sine',.25,.05);B(380,.08,'sine',.2,.1)}
 else if(k==='plop'){B(240,.09,'sine',.55);B(360,.05,'sine',.3,.03)}
 else if(k==='nib'){B(520,.03,'sine',.18)}
 else if(k==='bite'){B(880,.07,'square',.35);B(1175,.12,'square',.35,.07)}
 else if(k==='key')B(900+(x||0)*35,.025,'triangle',.16);
 else if(k==='miss')B(150,.09,'sawtooth',.22);
 else if(k==='stage')A([523,784],.07,'triangle',.35);
 else if(k==='hold')A([392,523],.1,'square',.3);
 else if(k==='esc')A([392,330,262],.12,'sine',.4,.18);
 else if(k==='c')A([523,659,784],.07);
 else if(k==='u')A([523,659,784,1047],.07,'triangle',.45);
 else if(k==='r')A([659,880,1175,1568],.09,'triangle',.5,.2);
 else if(k==='l1'){A([110,98,82],.25,'sawtooth',.25,.3)}
 else if(k==='l2'){try{jingle('win')}catch(e){}A([1047,1319,1568,2093],.11,'triangle',.4,.3)}
 else if(k==='sell')A([1319,1760],.06,'square',.25);
 else if(k==='buy')A([784,1047,1319],.06,'triangle',.35);
 else if(k==='tick')B(1200,.03,'square',.2);
 else if(k==='whip'){B(1400,.03,'sine',.18);B(900,.05,'sine',.2,.03);B(500,.07,'sine',.18,.07)}
 else if(k==='snap'){B(2200,.02,'square',.25);B(1500,.03,'square',.2,.02);B(300,.08,'triangle',.25,.05)}}
/* ---------- particles ---------- */
function fsBurst(x,y,n,k,o){o=o||{};if(FS.pt.length>420)return;for(let i=0;i<n;i++){const a=o.a!=null?o.a+(Math.random()-.5)*(o.sp||Math.PI):Math.random()*TAU,v=(o.v||160)*(.4+Math.random()*.8);
  FS.pt.push({x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v-(o.up||0),g:o.g==null?420:o.g,life:0,max:(o.life||.8)*(.6+Math.random()*.6),k,c:o.c||'#e8f4ff',r:(o.r||3)*(.6+Math.random()*.8)})}}
/* a ripple ring; dl delays its start (staggered rings) */
function fsRing(x,y,c,r0,r1,dur,w,dl){FS.pt.push({x,y,k:'ring',c,r0,r1,life:0,max:dur||.7,w:w||3,dl:dl||0})}
/* a splash crown scaled by s (0.7 a plop .. 2.2 a legendary eruption): droplets thrown up and out in a crown (they plink back
   into the water), a short crown sheet, a foam puff and three staggered ripple rings */
function fsCrown(x,y,s){s=s||1;const rm=fsRM(),n=Math.round((rm?5:10)+(rm?5:13)*s);if(FS.pt.length>380)return;
 for(let i=0;i<n;i++){const f=n>1?i/(n-1)-.5:0,a=-Math.PI/2+f*2.4+(Math.random()-.5)*.3,v=(150+95*s)*(.65+Math.random()*.6)*(1-Math.abs(f)*.4);
  FS.pt.push({x:x+f*16*s,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v,g:900,life:0,max:(.6+.25*s)*(.8+Math.random()*.4),k:'drop',c:Math.random()<.3?'#ffffff':'#d8eeff',r:(2.1+Math.random()*1.4)*(.85+.22*s),wy:y+2+Math.random()*12})}
 if(s>=.9)fsBurst(x,y,Math.round(2+3*s),'drop',{a:-Math.PI/2,sp:.3,v:230+120*s,g:900,life:.75+.2*s,c:'#ffffff',r:2.6+s});
 FS.pt.push({x,y,k:'crown',life:0,max:.3+.12*s,s,sd:Math.random()*99});FS.pt.push({x,y,k:'foam',life:0,max:.5+.2*s,s});
 fsRing(x,y,'#e4eeff',6*s,44*s,.75,2.6);fsRing(x,y,'#cfd8ff',5*s,76*s,1.05,2,.13);fsRing(x,y,'#b8c4f4',4*s,104*s,1.35,1.5,.3)}
function fsSplash(x,y,big){fsCrown(x,y,big?1.3:.75)}
function fsDrawPt(g,dt){const L=FS.pt;for(let i=L.length-1;i>=0;i--){const p=L[i];if(p.dl>0){p.dl-=dt;continue}p.life+=dt;if(p.life>=p.max){L.splice(i,1);continue}const u=p.life/p.max;
  if(p.k==='ring'){const r=p.r0+(p.r1-p.r0)*(1-Math.pow(1-u,2.4));g.strokeStyle=p.c;g.globalAlpha=Math.min(1,u*10)*(1-u)*.8;g.lineWidth=p.w*(1-u*.5);g.beginPath();g.ellipse(p.x,p.y,r,r*.3,0,0,TAU);g.stroke();continue}
  if(p.k==='foam'){const r=(9+9*p.s)*(1+u*1.1);g.fillStyle='#eef4ff';g.globalAlpha=(1-u)*(1-u)*.5;g.beginPath();g.ellipse(p.x,p.y+1,r,r*.28,0,0,TAU);g.fill();continue}
  if(p.k==='crown'){/* a thin sheet of water thrown up round the impact: blades that rise, lean out and fall back */const s=p.s,rx=(7+8*s)*(1+u*.9),ry=rx*.3,H=(13+15*s)*Math.sin(Math.PI*Math.min(1,u*1.1)),w=2.2+1.6*s;
   g.fillStyle='#e8f2ff';g.globalAlpha=(1-u*u)*.85;g.beginPath();
   for(let j=0;j<9;j++){const an=(j/9)*TAU+p.sd,ca=Math.cos(an),sa=Math.sin(an),bx=p.x+ca*rx,by=p.y+sa*ry,h=H*(.7+.5*fsRnd(p.sd+j))*(sa<0?.75:1),tx=bx+ca*h*.4,ty=by-h;
    g.moveTo(bx-w,by);g.quadraticCurveTo(bx-w*.2,by-h*.55,tx,ty);g.quadraticCurveTo(bx+w*.2,by-h*.45,bx+w,by);g.closePath()}g.fill();continue}
  p.vy+=p.g*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;
  if(p.wy&&p.vy>0&&p.y>p.wy){L.splice(i,1);if(Math.random()<.3&&L.length<400)FS.pt.push({x:p.x,y:p.wy,k:'ring',c:'#d0dcff',r0:1,r1:7+p.r,life:0,max:.4,w:1.1,dl:0});continue}
  g.globalAlpha=Math.min(1,(1-u)*1.6);
  if(p.k==='drop'){g.fillStyle=p.c;g.beginPath();g.ellipse(p.x,p.y,p.r*.75,p.r*1.15,Math.atan2(p.vy,p.vx)+Math.PI/2,0,TAU);g.fill()}
  else if(p.k==='spark'){fkSpark(g,p.x,p.y,p.r*2*(1-u*.4),p.c,1)}
  else if(p.k==='gold'){g.fillStyle=p.c;g.save();g.translate(p.x,p.y);g.rotate(p.life*6);g.fillRect(-p.r,-p.r*.5,p.r*2,p.r);g.restore()}
  else if(p.k==='bub'){g.strokeStyle=p.c;g.lineWidth=1.4;g.beginPath();g.arc(p.x,p.y,p.r,0,TAU);g.stroke()}}g.globalAlpha=1}
/* ---------- fish shadows ---------- */
function fsShadowsInit(){FS.sh=[0,1,2].map(i=>({x:700+Math.random()*400,y:640+Math.random()*180,r:18+Math.random()*16,dir:Math.random()<.5?1:-1,a:.18,ph:Math.random()*9,tx:0,ty:0,amb:1}));FS.sh.forEach(fsShadowTarget)}
function fsShadowTarget(s){s.tx=660+Math.random()*460;s.ty=620+Math.random()*220}
function fsShadowStep(dt){FS.sh.forEach(s=>{if(s.hook){const b=FS.bob;if(!b)return;s.tx=b.x-s.dir*(s.r*1.1);s.ty=b.y+16}const dx=s.tx-s.x,dy=s.ty-s.y,d=Math.hypot(dx,dy);const sp=s.hook?(s.dart?260:46):22;
  if(d<4&&!s.hook)fsShadowTarget(s);else if(d>0){s.x+=dx/d*Math.min(d,sp*dt);s.y+=dy/d*Math.min(d,sp*dt);if(Math.abs(dx)>3)s.dir=dx>0?1:-1}
  if(s.dart){s.a=Math.max(0,s.a-dt*.5)}});FS.sh=FS.sh.filter(s=>s.a>0.01)}
/* ---------- start / stop ---------- */
function fsStart(){fsP();FS.on=true;FS.pt=[];FS.trail=[];FS.snap=null;FS.breach=null;FS.fly=null;FS.rel=null;FS.whip=0;FS.bob=null;FS.cur=null;FS.pend=null;FS.T=fsNow();FS.view={};FS.rig=null;FS.prog=0;fsShadowsInit();fsSet('idle')}
function fsStop(){FS.on=false;FS.st='off';FS.pt=[];FS.tut=0;clearTimeout(FS.tm)}
/* cast the line */
function fsCast(){if(FS.st!=='idle'||FS.tut)return;const F=fsP();fsSt('cast',1,'add');save();FS.tgt={x:760+Math.random()*320,y:590+Math.random()*70};FS.flyH=100+Math.random()*45;FS.bob=null;FS.fly=null;FS.rel=null;FS.whip=0;fsSfx('cast');fsSet('cast')}
/* a fish bites */
function fsBite(){FS.biteT=fsNow();const c=fsRoll();FS.cur=c;FS.words=fsWords(c.rk);FS.si=0;FS.hp=FSR[c.rk].hp;FS.fightT=fsNow();FS.letters=FS.words.reduce((a,w)=>a+w.length,0);FS.prog=0;FS.breach=null;
 const sh=FS.sh.find(s=>s.hook);if(sh){sh.r=c.rk==='m'?62:c.rk==='l'?52:c.rk==='r'?40:c.rk==='u'?32:24}
 const B=FS.bob;B.vdip=(B.vdip||0)+9;fsCrown(B.x,B.y+4,1.15);fsRing(B.x,B.y+4,'#ffffff',4,58,.5,2.4);if(FS.rig&&!fsRM()){FS.rig.vb+=5;FS.rig.vf+=2.2}
 fsSfx('bite');FS.view.petHop=0.01;fsWord();fsSet('reel')}
function fsWord(){FS.word=FS.words[FS.si];FS.typed=0;FS.tMax=fsTime(FS.word,null,FS.cur.rk);FS.tLeft=FS.tMax;FS.grace=.35;try{fsHudWord()}catch(e){}}
/* typing during a fight */
function fsType(ch){if(FS.st!=='reel')return;ch=ch.toLowerCase();const w=FS.word,want=w[FS.typed];
 if(ch===want){FS.typed++;FS.pull=1;fsSfx('key',FS.typed);if(FS.bob){if(Math.random()<.5)fsBurst(FS.bob.x,FS.bob.y,3,'drop',{a:-Math.PI/2,sp:1.2,v:120,g:600,life:.4});const tp=FS.view.tip;if(tp){const u=.3+Math.random()*.6;fsBurst(tp.x+(FS.bob.x-tp.x)*u,tp.y+(FS.bob.y-tp.y)*u,2,'drop',{a:Math.PI/2,sp:1,v:40,g:500,life:.5,r:2})}}
  if(FS.typed>=w.length){if(FS.si<FS.words.length-1){FS.si++;fsSfx('stage');fsSplash(FS.bob.x,FS.bob.y,true);FS.thrash=1;FS.breach={t:fsNow(),x:FS.bob.x,y:FS.bob.y+6,dir:Math.random()<.72?-1:1,b2:0};if(FS.rig&&!fsRM())FS.rig.vb+=2.5;fsSet('stage')}else fsLand()}
  try{fsHudWord()}catch(e){}}
 else if(/^[a-z ]$/.test(ch)){FS.tLeft=Math.max(.05,FS.tLeft-.25);FS.miss=1;fsSfx('miss');try{fsHudWord(1)}catch(e){}}}
/* time ran out on a word */
function fsTimeout(){FS.hp--;if(FS.hp>0){fsSfx('hold');fsBanner('The line holds!','One more try','#ffd45a',1.2);FS.words[FS.si]=fsWords(FS.cur.rk)[Math.min(FS.si,FSR[FS.cur.rk].st-1)];fsWord();return}
 fsEscape()}
/* the line snaps: two recoiling ropes, a spark at the break, the rod whips up, the bobber pops up and the fish leaps away */
function fsEscape(){const F=fsP();fsSt('esc',1,'add');F.streak=0;save();fsSfx('esc');fsSfx('snap');const rm=fsRM(),B=FS.bob,tip=FS.view.tip?{x:FS.view.tip.x,y:FS.view.tip.y}:null,bt=B?{x:B.x,y:B.y+(B.dip||0)*16-20}:null,dir=B&&B.x>1040?-1:1;
 FS.snap={t:fsNow(),T:fsNow(),tip,bob:bt,wy:B?B.y:0,c:FS.cur,dir,ropes:tip&&bt&&!rm?fsSnapRopes(tip,bt):null};FS.breach=null;
 if(B){fsCrown(B.x,B.y,.75);B.vdip=-7;const s=FS.sh.find(s=>s.hook);if(s){s.hook=0;s.dart=1;s.tx=s.x+dir*420;s.ty=s.y+60}}
 if(tip&&bt){const kx=tip.x+(bt.x-tip.x)*.58,ky=tip.y+(bt.y-tip.y)*.58;fsBurst(kx,ky,rm?3:7,'spark',{v:150,g:260,life:.45,c:'#fff2c0',r:2.8});fsRing(kx,ky,'#fff6dc',2,16,.3,1.6)}
 if(FS.rig&&!rm){FS.rig.vf-=6.5;FS.rig.vl-=3}
 fsBanner('It got away…',FSR[FS.cur.rk].k>=2?`A ${FSR[FS.cur.rk].n.toLowerCase()} fish! Upgrade your Line for more time.`:'Cast again!','#c4badf',1.6);FS.cur=null;fsSet('escape')}
/* the fish is landed: record it and start the spectacle */
function fsLand(){const c=FS.cur,secs=fsNow()-FS.fightT;c.info=fsRecord(c,secs,FS.letters);c.val=fsValue(c);const B=FS.bob;FS.breach=null;
 if(B)fsCrown(B.x,B.y,c.rk==='l'||c.rk==='m'?.9:({c:1.05,u:1.25,r:1.5}[c.rk]||1.1));
 const s=FS.sh.find(s=>s.hook);if(s)FS.sh.splice(FS.sh.indexOf(s),1);
 FS.show={c,dur:{c:1.15,u:1.5,r:2.5,l:5.2,m:7.6}[c.rk],x0:FS.bob.x,y0:FS.bob.y};fsSfx(c.rk==='l'?'l1':c.rk==='m'?'m1':c.rk);if(c.rk==='l')setTimeout(()=>{if(FS.show&&FS.show.c===c)fsSfx('l2')},900);
 FS.bob=null;fsSet('show');try{fsHudWord()}catch(e){}}
/* skip the spectacle (the fish glides from where it was, see fsShowStep) */
function fsSkip(){if(FS.st!=='show')return;const el=fsNow()-FS.t0,d=FS.show.dur;if(el<Math.min(1.2,d*.4))return;FS.show.sk=fsNow();FS.t0=fsNow()-d*.86}
function fsReveal(){const c=FS.show.c;FS.show=null;FS.pend=c;fsSet('reveal');
 if(fsP().auto&&FSR[c.rk].k<2&&!fsKeepWhy(c)){const v=fsSell(c);fsSfx('sell');FS.pend=null;fsToast(`Auto-sold ${FISH[c.id].n} for ${v.toLocaleString()} gold.`,1);try{fsHudRefresh();if(FSU.tab==='b')fsTabs()}catch(e){}fsSet('idle');return}
 try{fsPreview(c)}catch(e){}}
/* sell or keep the pending catch */
function fsDecide(keep){const c=FS.pend;if(!c||FS.st!=='reveal')return false;if(keep){if(!fsKeep(c)){fsToast('Your creel is full. Sell some fish first.');return false}fsToast(`${FISH[c.id].n} kept in your creel.`)}
 else{const v=fsSell(c);fsSfx('sell');fsToast(`Sold for ${v.toLocaleString()} gold.`,1)}
 FS.pend=null;try{fsPreview(null);fsHudRefresh()}catch(e){}fsSet('idle');return true}
/* default choice: keep rare and legendary fish (and anything you have no record of), sell the rest */
/* why a catch is worth keeping ('' = sell). Rare and Legendary fish, a first catch of a species and giants are always kept;
   fish needed for a rod look you haven't made are kept while "Save fish for rod looks" is on (the default) */
function fsKeepWhy(c){if(!c)return'';const F=fsP();if(FSR[c.rk].k>=2)return FSR[c.rk].n+' catch';if(c.info&&c.info.first)return'New species!';if(c.g)return'Giant!';
 if(F.look!==0)for(const k of FSKINK){const n=FSKIN[k].k[c.id];if(!F.sk[k]&&n){const have=F.cr.filter(x=>x.id===c.id).length;if(have<n)return`For the ${FSKIN[k].n} rod (${have}/${n})`}}return''}
const fsDefKeep=c=>!!c&&fsP().cr.length<fsCreelCap()&&!!fsKeepWhy(c);
/* ---------- easing, springs and the rod rig ---------- */
const fsE={s:k=>k*k*(3-2*k),o:k=>1-Math.pow(1-k,3),i:k=>k*k*k,io:k=>k<.5?4*k*k*k:1-Math.pow(-2*k+2,3)/2,ob:(k,c)=>{c=c==null?1.4:c;return 1+(c+1)*Math.pow(k-1,3)+c*Math.pow(k-1,2)}};
const fsCl=(v,a,b)=>v<a?a:v>b?b:v,fsSs=(a,b,v)=>fsE.s(fsCl((v-a)/(b-a),0,1));
/* the art id and name of a catch (odd catches carry their own) */
const fsArt=c=>FISHART[c.id]?c.id:c.odd&&FISHART['odd'+c.odd]?'odd'+c.odd:c.id,fsNm=c=>(FISH[c.id]&&FISH[c.id].n)||c.n||'Catch';
/* a damped spring on o[k] (velocity o['v'+k]) towards T: angular frequency w, damping ratio z (1 = no overshoot) */
function fsSpr(o,k,T,w,z,dt){const vk='v'+k;let x=o[k]||0,v=o[vk]||0;const n=Math.max(1,Math.ceil(dt*w/.3)),h=dt/n;for(let i=0;i<n;i++){v+=(w*w*(T-x)-2*z*w*v)*h;x+=v*h}o[k]=x;o[vk]=v}
/* The states set TARGETS for the rod angle, the fish load (bend), the line slack and the hero lean; the rig follows them
   with springs, so nothing pops between states. Tip flex is a damped spring driven by the rod's angular acceleration:
   the tip lags on a swing and whips past the stop. The cast drives the angle directly (V.aDir). */
function fsRig(V,dt,rm){let R=FS.rig;if(!R||!isFinite(R.a+R.b+R.f+R.s+R.l))R=FS.rig={a:V.rodA,va:0,b:V.bend,vb:0,f:0,vf:0,s:V.slack,vs:0,l:V.lg,vl:0};
 if(dt>0){const va0=R.va;if(V.aDir){const a0=R.a;R.a=V.rodA;R.va=(R.a-a0)/dt}else fsSpr(R,'a',V.rodA,V.aw||15,V.az||1,dt);
  if(rm){R.f=0;R.vf=0}else{R.vf-=fsCl((R.va-va0)/dt,-420,420)*dt*.9;fsSpr(R,'f',0,24,.2,dt);R.f=fsCl(R.f,-.5,.5)}
  fsSpr(R,'b',V.bend,V.bw||13,rm?1:(V.bz||.4),dt);R.b=fsCl(R.b,-.28,1.25);fsSpr(R,'s',V.slack,9,.85,dt);fsSpr(R,'l',V.lg,V.lw||11,rm?1:.62,dt)}
 V.rodA=R.a;V.bend=R.b;V.flex=R.f;V.slack=R.s;V.lg=R.l}
/* the bobber's flight: a real parabola (apex early) with drag on x */
function fsFlyAt(k){const R=FS.rel,T=FS.tgt,H=FS.flyH||120,ex=1-Math.pow(1-k,1.7);return{x:R.x+(T.x-R.x)*ex,y:R.y-4*H*k+(T.y-R.y+4*H)*k*k}}
/* ---------- per frame ---------- */
function fsFrame(g){const now=fsNow(),dt=Math.min(.05,now-(FS.T||now));FS.T=now;const el=now-FS.t0,V=FS.view,rm=fsRM();V.rm=rm;V.skin=fsSkin();
 V.lg=0;V.bend=0;V.slack=.4;V.rodA=-.62;V.cheer=0;V.cheerU=0;V.dim=0;V.moonUp=0;V.shake=0;V.bob=null;V.lineTo=null;V.lineVia=null;V.lineA=1;V.vib=0;V.noLine=0;V.bobA=1;V.aDir=0;V.aw=0;V.az=0;V.bw=0;V.bz=0;V.lw=0;
 if(V.petHop){V.petHop+=dt*2.6;if(V.petHop>=1)V.petHop=0}
 fsShadowStep(dt);
 /* state logic: targets for the rig */
 if(FS.st==='cast')fsCastStep(V,el,now,rm);
 if(FS.bob)V.bob=FS.bob;
 if(FS.st==='wait')fsWaitStep(V,el,now,dt,rm);
 if(FS.st==='reel'||FS.st==='stage')fsReelStep(V,el,now,dt,rm);
 if(FS.st==='escape')fsEscStep(V,el,now,dt);
 if(FS.st==='show')fsShowStep(V,el,now,rm);
 if(FS.bob){const B=FS.bob;fsSpr(B,'dip',B.dt||0,15,rm?1:.3,dt);B.dip=fsCl(B.dip,-.6,1.2)}
 fsRig(V,dt,rm);
 /* draw: the catch show (and its particles) is painted after the scene, so a Legendary glows over the dimmed world */
 const post=FS.st==='show'&&FS.show&&FS.show.c.rk!=='m';
 V.fx=(gg)=>{fsMotionFx(gg,now);if(!post)fsDrawPt(gg,dt);if(FS.st==='reel'&&FS.cur&&FSR[FS.cur.rk].k>=2&&FS.bob){fkGlow(gg,FS.bob.x,FS.bob.y,60+20*Math.sin(now*6),FSR[FS.cur.rk].c,.25)}};
 V.shadows=FS.sh;fsScene(g,now,V);
 if(post){fsDrawPt(g,dt);fsShowFx(g,now-FS.t0)}
 /* the "!" when a fish bites */
 if((FS.st==='reel'&&now-FS.fightT<.9)){const u=(now-FS.fightT)/.9,y=FSHERO.y-250-Math.sin(Math.min(1,u*3)*Math.PI/2)*20;g.save();g.globalAlpha=Math.min(1,(1-u)*3);g.font="400 64px 'Pirata One',Georgia,serif";g.textAlign='center';g.lineWidth=7;g.strokeStyle=FKO;g.strokeText('!',FSHERO.x+20,y);g.fillStyle='#ffd45a';g.fillText('!',FSHERO.x+20,y);g.restore()}}
/* the cast (1 s, 0.6 s calm): settle, eased back-swing leaning back, a hang, an accelerating forward stroke leaning in
   (release at 50%), follow-through; the bobber flies a parabola and the line unspools along its path */
function fsCastStep(V,el,now,rm){const D=rm?.6:1,u=Math.min(1,el/D),E=fsE;let a,lg;
 if(u<.07){const k=E.s(u/.07);a=-.62+.08*k;lg=.08*k}
 else if(u<.34){const k=E.io((u-.07)/.27);a=-.54-1.41*k;lg=.08-.36*k}
 else if(u<.4){const k=E.s((u-.34)/.06);a=-1.95-.06*k;lg=-.28-.02*k}
 else if(u<.52){const k=(u-.4)/.12,e=Math.pow(k,2.2);a=-2.01+1.76*e;lg=-.3+1.05*e;if(!FS.whip&&k>.4){FS.whip=1;fsSfx('whip')}}
 else{const k=E.o((u-.52)/.48);a=-.25-.12*k;lg=.75-.65*k}
 V.rodA=a;V.lg=lg;V.aDir=1;V.lw=26;V.slack=.12;
 if(u<.56&&V.tip&&!rm)FS.trail.push({x:V.tip.x,y:V.tip.y,t:now});
 const RL=.5;if(u>=RL&&!FS.rel)FS.rel=V.tip?{x:V.tip.x,y:V.tip.y}:{x:640,y:380};
 if(FS.rel&&u<1){const k=Math.max(0,(u-RL)/(1-RL)),P=fsFlyAt(k);FS.fly={x:P.x,y:P.y,k,r:k*(rm?2:7.5)};V.lineTo=P;V.lineVia=Object.assign(fsFlyAt(k*.55),{w:.85*(1-fsSs(.5,1,k))})}
 if(u>=1){FS.fly=null;FS.rel=null;FS.whip=0;FS.landT=now;FS.rph=0;FS.bob={x:FS.tgt.x,y:FS.tgt.y,dip:1.05,vdip:-1,dt:0,hx:FS.tgt.x,hy:FS.tgt.y};fsCrown(FS.bob.x,FS.bob.y,.8);fsSfx('plop');
  FS.wait=fsWait();FS.nib=[];const n=Math.random()*3|0;for(let i=0;i<n;i++)FS.nib.push(FS.wait*(.45+Math.random()*.45));FS.nib.sort((a,b)=>a-b);
  const s={x:FS.bob.x+(Math.random()<.5?-1:1)*(260+Math.random()*120),y:FS.bob.y+40+Math.random()*60,r:22,dir:1,a:0,ph:Math.random()*9,hook:1};FS.sh.push(s);if(FS.rig){FS.rig.s=.12;FS.rig.vs=0}fsSet('wait')}}
/* waiting: the bobber settles from its plop (dip spring), soft idle ripples, nibbles kick the bobber and twitch the rod tip */
function fsWaitStep(V,el,now,dt,rm){const B=FS.bob,s=FS.sh.find(s=>s.hook);if(s)s.a=Math.min(.36,s.a+dt*.25);B.dt=0;V.slack=.4;
 if(FS.nib.length&&el>FS.nib[0]){FS.nib.shift();B.vdip=(B.vdip||0)+(rm?2.5:5.5);fsRing(B.x,B.y+2,'#d8e8ff',4,26,.55,1.6);fsSfx('nib');if(FS.rig&&!rm){FS.rig.vb+=1.6;FS.rig.vf+=.6}}
 const ph=Math.floor((now-(FS.landT||now))/1.9);if(ph>0&&ph!==FS.rph){FS.rph=ph;fsRing(B.x,B.y+3,'#c8d0f4',8,40,1.6,1.2)}
 if(el>=FS.wait)fsBite()}
/* the fight: the bobber is reeled towards the dock as letters are typed (each finished word jumps closer), the rod aims at
   the fish and pumps on each letter; on the bite the fish yanks the rod down, then the hero strikes up to set the hook */
function fsReelStep(V,el,now,dt,rm){const B=FS.bob,k=FSR[FS.cur.rk].k,stg=FS.st==='stage';FS.pull=Math.max(0,(FS.pull||0)-dt*4);FS.miss=Math.max(0,(FS.miss||0)-dt*3);
 let done=0;for(let i=0;i<FS.si;i++)done+=FS.words[i].length;if(!stg)done+=FS.typed;const p=FS.letters?Math.min(1,done/FS.letters):0;FS.prog=(FS.prog||0)+(p-(FS.prog||0))*(1-Math.exp(-dt*(stg?7:4)));
 const hx=B.hx==null?B.x:B.hx,hy=B.hy==null?B.y:B.hy,mx=k>=3?860:745,pr=FS.prog*.88,bx=hx+(Math.min(hx,Math.max(mx,hx-.55*(hx-mx)))-hx)*pr+Math.sin(now*(1.25+k*.3))*(12+k*7)+Math.sin(now*3.3+1.7)*(4+k*2),by=hy+(650-hy)*.35*pr+Math.sin(now*1.7+.5)*4,f=1-Math.exp(-dt*6);
 B.x=fsCl(B.x+(bx-B.x)*f,700,1120);B.y+=(by-B.y)*f;B.dt=.5+.2*Math.sin(now*9)+(stg?.3:0)+FS.pull*.12;
 V.rodA=-.5+(B.x-900)/420*.12+Math.sin(now*7)*.025*(1+k)-FS.pull*.1-(stg?.1:0);V.bend=Math.min(1,.45+k*.12+FS.pull*.3+(stg?.3:0));V.bz=.34;V.aw=stg?11:15;
 V.slack=0;V.shake=FS.miss*3;V.vib=rm?0:FS.pull*2.4+k*.5+(stg?2:0);
 const bt=now-(FS.biteT||0);if(bt<.55){if(bt<.13){V.rodA=-.36;V.bend=1.15;V.lg=.18;B.dt=1.1}else{V.rodA=-.88;V.bend=.9;V.lg=-.24;V.aw=13}if(!rm&&bt<.4)V.shake=Math.max(V.shake,4*(1-bt/.4))}
 if(Math.random()<dt*(4+k*3))fsBurst(B.x+(Math.random()-.5)*20,B.y,2,'drop',{a:-Math.PI/2,sp:1.4,v:110,g:600,life:.4});
 /* the fish breaching between words: the bobber is dragged under, the line follows the fish's mouth */
 if(FS.breach){const BR=fsBreachPose(now);if(BR){V.bob=null;V.lineTo=BR.mouth;V.vib*=.3;V.bend=Math.min(1.1,V.bend+.15);V.rodA-=.08}else{FS.breach=null;B.dip=1.1;B.vdip=0}}
 if(FS.st==='reel'){if(FS.grace>0)FS.grace-=dt;else{FS.tLeft-=dt;if(FS.tLeft<=0){FS.tLeft=0;fsTimeout()}}try{fsHudTimer()}catch(e){}}
 else if(el>.6){fsWord();fsSet('reel')}}
function fsBreachPose(now){const B=FS.breach;if(!B||!FS.cur)return null;const u=(now-B.t)/.8;if(u>=1||u<0)return null;
 const k=FSR[FS.cur.rk].k,H=92+k*12,W=66,px=fsFishPx(FS.cur)*.55,sc=px/210,x=B.x+B.dir*W*(u-.5),y=B.y-4*H*u*(1-u),vx=B.dir*W,vy=-4*H*(1-2*u)*.5,sx=B.dir,rot=sx>0?Math.atan2(vy,vx):Math.atan2(-vy,-vx);
 return{x,y,u,rot,sx,sc,wy:B.y,mouth:{x:x+Math.cos(rot)*92*sc*sx,y:y+Math.sin(rot)*92*sc*sx}}}
/* the escape: the rod recoils (bend released past zero, a flex kick), the hero rocks back, the bobber pops up and drifts off */
function fsEscStep(V,el,now,dt){const B=FS.bob;V.noLine=1;V.slack=.9;V.rodA=-.8;V.aw=12;V.az=.55;V.bend=0;V.bz=.3;V.lg=el<.2?-.3:0;
 if(B){B.dt=0;B.x+=dt*22*Math.max(0,1-el/1.2)*(FS.snap?-FS.snap.dir*.6:1);V.bobA=1-fsSs(.7,1.2,el)}if(el>1.2){FS.bob=null;fsSet('idle')}}
/* the catch show: where the rod points and where the line goes (the fish pose is shared with fsShowFx) */
function fsShowStep(V,el,now,rm){const S0=FS.show,c=S0.c,rk=c.rk,d=S0.dur,u=Math.min(1,el/d),pre=rk==='l'?.8:rk==='m'?(typeof my_T!=='undefined'?my_T.erupt:.92):0;
 const P=S0.P=fsShowPoseS(S0,el,now);
 if(el<pre){/* the struggle before the eruption: a taut, humming line into the churning water, the rod bent hard */V.rodA=-.74+.05*Math.sin(el*13);V.bend=1-.08*Math.sin(el*9);V.bz=.5;V.vib=rm?0:2.4;V.lineTo={x:S0.x0,y:S0.y0};V.slack=0;V.lg=-.16}
 else{const t1=el-pre,tl=fsShowTL(rk),hook=!pre&&P&&el<tl[0];V.rodA=t1<.32?-1.38:el<tl[0]+tl[1]?-1.08:-.82;V.aw=t1<.32?20:13;V.az=t1<.45?.5:.85;V.bend=hook?.3:0;V.bz=.28;V.lg=t1<.3?-.22:0;
  if(hook){V.lineTo=P.mouth;V.slack=.06}}
 const ce=Math.max(.5,pre+.1);V.cheer=el>ce?1:0;V.cheerU=fsCl(Math.min((el-ce)*2.2,(d-el)/.45),0,1);
 if(rk==='m'&&typeof fsMythicView==='function')fsMythicView(V,el,d);
 if(rk==='l'){const a=Math.min(1,el/.6),z=el>d-.9?Math.max(0,(d-el)/.9):1;V.dim=.62*a*z;V.moonUp=a*z;V.shake=rm?0:el<.8?el*8:el<1.2?16*(1.2-el)/.4:0}
 if(u>=1)fsReveal()}
/* where the fish flies to (the catch preview in the side panel) */
const FSPV={x:1290,y:700};
/* ---------- the catch spectacle ---------- */
function fsFishPx(c){const f=FISH[c.id],u=Math.min(1,c.cm/200);return 90+u*190+(c.rk==='m'?110:c.rk==='l'?80:c.rk==='r'?30:0)}
/* timeline per rarity: leap (a) -> hold (h) -> fly to the panel (f) */
function fsShowTL(rk){return {c:[.55,.15,.45],u:[.6,.35,.5],r:[.7,1.1,.6],l:[1.9,2.3,.8]}[rk]||[.6,.35,.5]}
const FSHOLD={c:[700,410],u:[700,405],r:[730,360],l:[780,300]};
/* the fish's pose: leaps from the water on an eased arc (apex at the hold point, a little overshoot), turning along its path
   and popping to size; settles with a wiggle and turns to face the panel; then dips back and swoops into the panel */
function fsShowPose(S0,el,t){const c=S0.c,rk=c.rk;if(rk==='m')return null;const H0=FSHOLD[rk]||FSHOLD.u,hx=H0[0],hy=H0[1],x0=S0.x0,y0=S0.y0,tl=fsShowTL(rk),aEnd=tl[0],hEnd=aEnd+tl[1],px=fsFishPx(c),L=rk==='l';
 const hY=k=>Math.sin(k*(L?2.4:2.6))*6,hR=k=>L?Math.sin(k*2)*.05:.16*Math.exp(-k*4.5)*Math.sin(k*10);
 let x,y,s=1,rot=0,sx=1,al=1,fl=.25,clip=0;const dir=L||hx>=x0?1:-1;
 if(el<aEnd){if(L){const k=fsCl((el-.8)/(aEnd-.8),0,1);x=x0+(hx-x0)*fsE.s(k);y=y0+(hy-y0)*fsE.o(k);s=.35+.65*fsE.ob(k,1.1);rot=Math.sin(t*3)*.05;al=el<.8?0:Math.min(1,k*3);fl=.8}
  else{const u=el/aEnd,c2=.9,ey=fsE.ob(u,c2),ex=1-(1-u)*(1-u),dx=(hx-x0)*2*(1-u),dy=(hy-y0)*(3*(c2+1)*(u-1)*(u-1)+2*c2*(u-1)),w=Math.pow(1-u,1.4);
   x=x0+(hx-x0)*ex;y=y0+(hy-y0)*ey;s=.55+.45*fsE.ob(Math.min(1,u*1.25),1.7);fl=.9;sx=dir;
   rot=(sx>0?Math.atan2(dy,dx):Math.atan2(-dy,-dx))*.8*w;if(rk==='r')rot-=sx*TAU*fsE.io(Math.min(1,u*1.1));clip=u<.55?y0+4:0}}
 else if(el<hEnd){const k=el-aEnd;x=hx;y=hy+hY(k);rot=hR(k)}
 else{const u=fsCl((el-hEnd)/tl[2],0,1),e=u<.18?-.07*fsE.s(u/.18):-.07+1.07*fsE.io((u-.18)/.82),ec=fsCl(e,0,1),r0=1-ec;
  x=hx+(FSPV.x-hx)*e;y=hy+(FSPV.y-hy)*e-Math.sin(Math.PI*ec)*70+hY(tl[1])*r0;s=1-.72*ec;rot=Math.sin(Math.PI*u)*.22+hR(tl[1])*r0;al=fsCl((1215-x)/90,0,1)*(1-fsSs(.9,1,u))}
 if(!L&&el>=aEnd){const tk=fsCl((el-aEnd-.04)/.38,0,1);sx=dir>0?1:-Math.cos(Math.PI*fsE.io(tk));if(Math.abs(sx)<.06)sx=sx<0?-.06:.06}
 const sc=px/210*s;return{x,y,s,rot,sx,al,fl,clip,px,sc,hx,hy,aEnd,hEnd,mouth:{x:x+Math.cos(rot)*94*sc*sx,y:y+Math.sin(rot)*94*sc*sx}}}
/* the pose with skip smoothing: after a skip the fish glides from where it was for 0.32 s */
function fsShowPoseS(S0,el,t){let P=fsShowPose(S0,el,t);if(!P)return P;
 if(S0.sk){if(S0.skA!==S0.sk){S0.skA=S0.sk;S0.skP=S0.lp}const k=(t-S0.sk)/.32,Q=S0.skP;if(k<1&&Q){const e=fsE.s(Math.max(0,k)),m=(a,b)=>a+(b-a)*e;P=Object.assign({},P,{x:m(Q.x,P.x),y:m(Q.y,P.y),s:m(Q.s,P.s),rot:m(Q.rot,P.rot),sx:m(Q.sx,P.sx),al:m(Q.al,P.al),sc:m(Q.sc,P.sc),clip:0})}}
 S0.lp=P;return P}
function fsShowFx(g,el){const S0=FS.show;if(!S0)return;const c=S0.c,d=S0.dur,rk=c.rk,col=FSR[rk].c,px=fsFishPx(c),t=fsNow(),x0=S0.x0,y0=S0.y0;
 const P=S0.P||fsShowPoseS(S0,el,t);if(!P)return;const hx=P.hx,hy=P.hy,aEnd=P.aEnd,hEnd=P.hEnd,tl=fsShowTL(rk),x=P.x,y=P.y,rm=fsRM();
 /* rarity layers behind the fish */
 if(rk==='l'){fsLegendFx(g,el,x,y,x0,y0,px,col)}
 else if(rk==='r'&&el<hEnd+.35){const k=Math.min(1,el/.4)*(el>hEnd?1-(el-hEnd)/.35:1);fsRays(g,x,y,12,px*1.4,col,k*.55,t*.6);fkGlow(g,x,y,px*.9,col,.45*k);if(el<.2&&!rm)fsFlash(g,col,.22*Math.pow(1-el/.2,2))}
 else if(rk==='u'&&el<hEnd+.3){const k=Math.min(1,el/.3)*(el>hEnd?1-(el-hEnd)/.3:1);fkGlow(g,x,y,px*.7,col,.3*k)}
 /* one-time bursts */
 if(!S0.b1&&rk==='l'&&el>.8){S0.b1=1;fsCrown(x0,y0,2.2);fsBurst(x0,y0,rm?20:50,'drop',{a:-Math.PI/2,sp:1.2,v:520,g:500,life:1.5,c:'#e8f6ff',r:5});for(let i=0;i<3;i++)fsRing(x0,y0,i?'#ffe6a0':'#ffffff',10,220+i*120,1.2+i*.3,4,i*.08)}
 if(!S0.b3&&rk!=='l'&&el>=aEnd){S0.b3=1;/* unhooked: a twinkle at the mouth as the line lets go */const m=P.mouth;fsBurst(m.x,m.y,rm?3:7,'spark',{v:90,g:60,life:.45,c:'#fff6dc',r:2.6});fsRing(m.x,m.y,'#fff6dc',2,18,.35,1.4)}
 if(!S0.b2&&el>aEnd*.9){S0.b2=1;if(rk!=='c')fsBurst(x,y,rk==='l'?60:rk==='r'?34:18,'spark',{v:rk==='l'?420:260,g:rk==='l'?40:120,life:rk==='l'?1.6:1,c:rk==='u'?'#b6ffcc':rk==='r'?'#bfe4ff':'#fff2b0',r:rk==='l'?6:4});
  if(rk==='r'||rk==='l')fsRing(x,y,col,20,px*1.2,.9,4);if(rk==='u')fsRing(x,y,col,10,px*.8,.7,3);if(rk!=='c')fsBanner(rk==='l'?'LEGENDARY CATCH':rk==='r'?'Rare catch!':'',fsNm(c),col,rk==='l'?2.6:1.3,rk)}
 if(rk==='l'&&el>aEnd&&el<hEnd&&Math.random()<.5)fsBurst(x+(Math.random()-.5)*900,-10,1,'gold',{a:Math.PI/2,sp:.4,v:90,g:120,life:2.4,c:Math.random()<.5?'#ffd45a':'#fff2b0',r:4});
 if(el<aEnd&&P.al>.1&&!rm&&Math.random()<.8)fsBurst(x,y+6,rk==='c'?1:2,'drop',{v:70,g:520,life:.55,r:2.6,c:'#e0f2ff'});if(el<aEnd&&(rk==='r'||rk==='l')&&Math.random()<.5)fsBurst(x,y,1,'spark',{v:60,g:30,life:.6,c:col,r:3});
 /* a trail as it swoops into the panel */
 if(el>hEnd&&P.al>.2&&!rm&&Math.random()<.75)fsBurst(x,y,1,rk==='c'?'drop':'spark',{v:40,g:rk==='c'?420:50,life:.5,c:rk==='c'?'#e0f2ff':rk==='u'?'#b6ffcc':col,r:rk==='c'?2.2:2.8});
 /* the fish (clipped at the waterline while it breaks the surface) */
 g.save();if(P.clip){g.beginPath();g.rect(-80,-80,1760,P.clip+80);g.clip()}g.globalAlpha=P.al;g.translate(x,y);g.rotate(P.rot);g.scale(P.sc*P.sx,P.sc);if(rk!=='c')fkGlow(g,0,0,120,col,rk==='l'?.32:.25);fishDraw(g,fsArt(c),{t,flex:P.fl,glow:rk==='l'||rk==='r'?1:0});g.restore();
 /* size stamp during the hold */
 if(rk!=='l'&&rk!=='c'&&el>aEnd&&el<hEnd+.1){const a=Math.min(1,(el-aEnd)*5)*Math.min(1,(hEnd+.1-el)*6);g.save();g.globalAlpha=a;g.textAlign='center';g.font="800 24px Poppins,system-ui,sans-serif";g.lineWidth=6;g.strokeStyle='#1b1024';const tx=`${c.cm} cm${c.g?'  ♛ GIANT':''}`,ty=hy+px*.42+30+(1-a)*8;g.strokeText(tx,hx,ty);g.fillStyle=c.g?'#ffd45a':'#fff8e8';g.fillText(tx,hx,ty);g.restore()}
 /* name plate during the legendary hold */
 if(rk==='l'&&el>aEnd+.2&&el<hEnd){const a=Math.min(1,(el-aEnd-.2)*3)*Math.min(1,(hEnd-el)*3),nm=fsNm(c);g.save();g.globalAlpha=a;g.textAlign='center';g.font="400 54px 'Pirata One',Georgia,serif";g.lineWidth=8;g.strokeStyle='#1b1024';g.strokeText(nm,hx,hy+px*.5+70);
  const q=g.createLinearGradient(0,hy+px*.5+30,0,hy+px*.5+80);q.addColorStop(0,'#fff6c0');q.addColorStop(1,'#ffb020');g.fillStyle=q;g.fillText(nm,hx,hy+px*.5+70);g.font="700 22px Poppins,system-ui,sans-serif";g.fillStyle='#fff8e8';g.strokeText(`${c.cm} cm${c.g?' · GIANT':''}`,hx,hy+px*.5+104);g.fillText(`${c.cm} cm${c.g?' · GIANT':''}`,hx,hy+px*.5+104);g.restore()}}
function fsFlash(g,c,a){g.save();g.globalAlpha=a;g.fillStyle=c;g.fillRect(-20,-20,1640,940);g.restore()}
function fsRays(g,x,y,n,r,c,a,rot){if(a<=0)return;g.save();g.globalCompositeOperation='lighter';g.translate(x,y);g.rotate(rot);for(let i=0;i<n;i++){g.rotate(TAU/n);const q=g.createLinearGradient(0,0,r,0);q.addColorStop(0,c+Math.round(a*255).toString(16).padStart(2,'0'));q.addColorStop(1,c+'00');g.fillStyle=q;g.beginPath();g.moveTo(0,0);g.lineTo(r,-r*.09);g.lineTo(r,r*.09);g.closePath();g.fill()}g.restore()}
/* the legendary spectacle: churning water, a pillar of light (it softens once the fish is up, so the fish reads), the fish
   rising in the beam, god rays, aurora ribbons and gold */
function fsLegendFx(g,el,x,y,x0,y0,px,col){const t=fsNow(),d=FS.show.dur,fade=el>d-.9?Math.max(0,(d-el)/.9):1,aEnd=fsShowTL('l')[0],rm=fsRM();
 if(el<.85){const k=el/.85;for(let i=0;i<2;i++)if(Math.random()<.6)FS.pt.push({x:x0+(Math.random()-.5)*80*k,y:y0+Math.random()*10,vx:0,vy:-60-Math.random()*60,g:0,life:0,max:.6,k:'bub',c:'#d8f0ff',r:2+Math.random()*4});
  fkGlow(g,x0,y0,60+k*80,'#ffe6a0',.3*k);if(Math.random()<.35)fsRing(x0,y0,'#ffffff',4,30+k*40,.4,1.4)}
 if(el>=.8){const k=Math.min(1,(el-.8)/.25)*fade,pk=k*(1-.6*fsSs(aEnd-.3,aEnd+.5,el)),w=90+30*Math.sin(t*8);
  /* pillar of light */
  g.save();g.globalCompositeOperation='lighter';const q=g.createLinearGradient(x0-w,0,x0+w,0);q.addColorStop(0,'#fff2c000');q.addColorStop(.5,`rgba(255,242,192,${.32*pk})`);q.addColorStop(1,'#fff2c000');g.fillStyle=q;g.fillRect(x0-w,0,w*2,y0+10);
  const q2=g.createLinearGradient(x0-w*.3,0,x0+w*.3,0);q2.addColorStop(0,'#ffffff00');q2.addColorStop(.5,`rgba(255,255,255,${.34*pk})`);q2.addColorStop(1,'#ffffff00');g.fillStyle=q2;g.fillRect(x0-w*.3,0,w*.6,y0+10);g.restore();
  if(el<1&&!rm)fsFlash(g,'#fff6dc',.35*Math.pow(1-(el-.8)/.2,2));
  /* aurora ribbons across the sky */
  g.save();g.globalCompositeOperation='lighter';for(let b=0;b<3;b++){g.beginPath();for(let i=0;i<=40;i++){const xx=i*40,yy=120+b*55+Math.sin(i*.35+t*1.2+b*2)*30;i?g.lineTo(xx,yy):g.moveTo(xx,yy)}for(let i=40;i>=0;i--){const xx=i*40,yy=120+b*55+Math.sin(i*.35+t*1.2+b*2)*30+44+Math.sin(i*.5+t+b)*14;g.lineTo(xx,yy)}g.closePath();
   const ag=g.createLinearGradient(0,0,1600,0);['#7affd8','#8a6aff','#ff7ae0','#ffd45a','#7affd8'].forEach((c,i)=>ag.addColorStop(i/4,c));g.fillStyle=ag;g.globalAlpha=.11*k;g.fill()}g.restore();
  /* god rays and halo behind the fish */
  fsRays(g,x,y,16,px*2.1,'#ffe6a0',.27*k,t*.35);fsRays(g,x,y,8,px*1.5,'#ffffff',.15*k,-t*.5);fkGlow(g,x,y,px*1.3,'#fff2c0',.34*k);
  /* a pool of night right behind the fish so it reads against the light (the Mythic's cached sprite) */
  if(typeof my_void==='function'){g.save();g.globalAlpha=.7*k;g.drawImage(my_void(),x-px*.78,y-px*.58,px*1.56,px*1.16);g.restore()}
  /* orbiting sparkles */
  for(let i=0;i<10;i++){const a=t*1.4+i*TAU/10,r=px*.75+Math.sin(t*3+i)*12;fkSpark(g,x+Math.cos(a)*r,y+Math.sin(a)*r*.55,5+3*Math.sin(t*5+i),i%2?'#ffffff':'#ffe27a',k)}}}
/* ---------- input ---------- */
function fsKeyDown(e){if(!FS.on||!$('fsx')||S.mode!=='fish'||e.ctrlKey||e.metaKey||e.altKey)return;const ae=document.activeElement;if(ae&&ae!==inp&&/INPUT|TEXTAREA|SELECT/.test(ae.tagName))return;
 const k=e.key,mod=$('fsmod');if(mod&&!mod.hidden){if(k==='Escape'){e.preventDefault();e.stopImmediatePropagation();fsModal(null)}return}
 const stop=()=>{e.preventDefault();e.stopImmediatePropagation()};
 if(FS.tut){if(k===' '||k==='Enter'||k==='Escape'){stop();fsTutClose()}return}
 /* quick sell: Enter on the catch preview asks first, a second Enter sells; Esc only closes the question */
 if(FS.st==='reveal'&&FS.qs&&k==='Escape'){stop();fsQsOff();return}
 if(FS.st==='reveal'&&k==='Enter'){stop();if(e.repeat)return;if(FS.qs){fsQsOff();fsDecide(false)}else fsQsOn();return}
 if(k==='Escape'){stop();if((FS.st==='reel'||FS.st==='stage')&&!(FS.escT&&fsNow()-FS.escT<2.2)){FS.escT=fsNow();fsToast('Press Esc again to leave. The fish will get away.');return}fsLeave();return}
 if(FS.st==='reel'){if(k.length===1){stop();if(!e.repeat)fsType(k)}else if(k==='Backspace')stop();return}
 if(k===' '||k==='Enter'){if(e.repeat){stop();return}
  if(FS.st==='idle'){stop();fsCast()}else if(FS.st==='show'){stop();fsSkip()}else if(FS.st==='reveal'){stop();fsQsOff();if(!fsDefKeep(FS.pend)&&fsKeepWhy(FS.pend))fsToast('Your creel is full. Press S to sell it, or free a slot in your Fish Basket.');else fsDecide(fsDefKeep(FS.pend))}else stop();return}
 if(FS.st==='reveal'&&(k==='s'||k==='S')){stop();fsQsOff();fsDecide(false)}else if(FS.st==='reveal'&&(k==='k'||k==='K')){stop();fsQsOff();fsDecide(true)}}
document.addEventListener('keydown',fsKeyDown,true);
/* touch keyboards: the hidden input */
inp.addEventListener('beforeinput',e=>{if(S.mode!=='fish'||!FS.on)return;if(e.inputType!=='insertText'||!e.data)return;e.preventDefault();const v=e.data;if([...v].length!==1)return;if(FS.st==='reel')fsType(v);else if(v===' '&&FS.st==='idle')fsCast()});

/* cast trail, the flying bobber, the fish breaching between words and the line snapping */
/* the snapped line: two short verlet ropes pinned at the rod tip and at the bobber; their rest length shrinks, so they
   recoil, then they curl and hang under gravity */
function fsRope(a,b,n,pi){const P=[];for(let i=0;i<=n;i++){const u=i/n,x=a.x+(b.x-a.x)*u,y=a.y+(b.y-a.y)*u,pin=pi?b:a,kick=.05*(pi?(1-u):u);P.push({x,y,px:x+(x-pin.x)*kick,py:y+(y-pin.y)*kick+(pi?0:2.5*u)})}return{P,L:Math.hypot(b.x-a.x,b.y-a.y)/n,pi:pi?n:0}}
function fsSnapRopes(tip,bob){const k={x:tip.x+(bob.x-tip.x)*.58,y:tip.y+(bob.y-tip.y)*.58};return[fsRope(tip,k,10,0),fsRope(k,bob,7,1)]}
function fsRopeStep(R,pin,el,dt){const P=R.P,n=P.length-1,g2=900*dt*dt,rest=R.L*Math.max(.3,.62-el*1.6);
 for(let i=0;i<=n;i++){const p=P[i];if(i===R.pi){if(pin){p.x=pin.x;p.y=pin.y}p.px=p.x;p.py=p.y;continue}const vx=(p.x-p.px)*.975,vy=(p.y-p.py)*.975;p.px=p.x;p.py=p.y;p.x+=vx;p.y+=vy+g2}
 for(let it=0;it<3;it++)for(let i=0;i<n;i++){const a=P[i],b=P[i+1],dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy)||1;if(d<=rest)continue;const ka=i===R.pi?0:1,kb=i+1===R.pi?0:1,s=ka+kb;if(!s)continue;const f=(d-rest)/d/s;a.x+=dx*f*ka;a.y+=dy*f*ka;b.x-=dx*f*kb;b.y-=dy*f*kb}}
function fsRopeDraw(g,R){const P=R.P,n=P.length-1;g.beginPath();g.moveTo(P[0].x,P[0].y);for(let i=1;i<n;i++)g.quadraticCurveTo(P[i].x,P[i].y,(P[i].x+P[i+1].x)/2,(P[i].y+P[i+1].y)/2);g.lineTo(P[n].x,P[n].y);g.stroke()}
function fsMotionFx(g,now){
 FS.trail=(FS.trail||[]).filter(p=>now-p.t<.2);if(FS.trail.length>1){g.save();g.lineCap='round';for(let i=1;i<FS.trail.length;i++){const a=FS.trail[i-1],b=FS.trail[i],k=1-(now-b.t)/.2;g.strokeStyle=`rgba(230,224,255,${k*.55})`;g.lineWidth=1+k*5;g.beginPath();g.moveTo(a.x,a.y);g.lineTo(b.x,b.y);g.stroke()}g.restore()}
 if(FS.st==='cast'&&FS.fly){const f=FS.fly,sk=FS.view.skin||fsSkin();g.save();g.translate(f.x,f.y);g.rotate(f.r||0);g.beginPath();g.arc(0,0,7,0,TAU);g.fillStyle=sk.bob[1];g.fill();g.beginPath();g.arc(0,0,7,Math.PI,TAU);g.fillStyle=sk.bob[0];g.fill();g.lineWidth=2.2;g.strokeStyle=FKO;g.beginPath();g.arc(0,0,7,0,TAU);g.stroke();g.fillStyle='#ffffff99';g.beginPath();g.arc(-2.5,-2.5,2,0,TAU);g.fill();g.restore()}
 /* the breach: clipped at the waterline so the fish rises out of the water and dives back in */
 const BR=FS.breach&&(FS.st==='reel'||FS.st==='stage')?fsBreachPose(now):null;if(BR){const B=FS.breach;if(BR.u>.86&&!B.b2){B.b2=1;fsCrown(BR.x,B.y-6,.9)}if(BR.y<BR.wy-10&&Math.random()<.6)fsBurst(BR.x,BR.y,1,'drop',{v:50,g:500,life:.45,r:2.4});
  g.save();g.beginPath();g.rect(-80,-80,1760,BR.wy+80);g.clip();g.translate(BR.x,BR.y);g.rotate(BR.rot);g.scale(BR.sc*BR.sx,BR.sc);if(FSR[FS.cur.rk].k>=2)fkGlow(g,0,0,110,FSR[FS.cur.rk].c,.3);fishDraw(g,fsArt(FS.cur),{t:now,flex:1});g.restore()}
 /* the snap */
 const S0=FS.snap;if(S0){const el=now-S0.t,dt=Math.min(.05,Math.max(0,now-(S0.T||now)));S0.T=now;if(el>1.3){FS.snap=null;return}
  const ln=(FS.view.skin||fsSkin()).ln,fa=1-fsSs(.75,1.15,el);
  if(S0.ropes){const tip=FS.view.tip,B=FS.bob,bp=B?{x:B.x,y:B.y+(B.dip||0)*16-20}:null;fsRopeStep(S0.ropes[0],tip,el,dt);fsRopeStep(S0.ropes[1],bp,el,dt);
   if(fa>0){g.save();g.lineCap='round';g.lineJoin='round';g.strokeStyle=ln;g.lineWidth=1.6;g.globalAlpha=.85*fa;fsRopeDraw(g,S0.ropes[0]);g.globalAlpha=.85*fa*(FS.view.bobA==null?1:FS.view.bobA);fsRopeDraw(g,S0.ropes[1]);g.restore()}}
  else if(S0.tip&&el<.6){const u=el/.6,T=S0.tip;g.save();g.lineCap='round';g.globalAlpha=1-u;g.strokeStyle=ln;g.lineWidth=1.6;g.beginPath();g.moveTo(T.x,T.y);g.quadraticCurveTo(T.x+20,T.y+30,T.x+10,T.y+50+u*20);g.stroke();g.restore()}
  /* the fish leaps away from the bobber and dives */
  const c=S0.c,u=el/.62;if(c&&S0.bob&&u<1){const wy=S0.wy||S0.bob.y+20,dir=S0.dir,px=fsFishPx(c)*.5,sc=px/210,x=S0.bob.x+dir*(24+140*fsE.o(u)),y=wy+6-4*80*u*(1-u),vx=dir*140*3*(1-u)*(1-u),vy=-4*80*(1-2*u)*.6,rot=dir>0?Math.atan2(vy,vx):Math.atan2(-vy,-vx);
   if(u>.85&&!S0.b2){S0.b2=1;fsCrown(x,wy,.8)}
   g.save();g.beginPath();g.rect(-80,-80,1760,wy+82);g.clip();g.translate(x,y);g.rotate(rot);g.scale(sc*dir,sc);if(FSR[c.rk]&&FSR[c.rk].k>=2)fkGlow(g,0,0,100,FSR[c.rk].c,.25);fishDraw(g,fsArt(c),{t:now,flex:1});g.restore()}}}
