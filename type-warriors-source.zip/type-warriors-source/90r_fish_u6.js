/* ===== MOONLIT FISHING update 6: creel tiers, daily bounties, baits, trophy hall, Mythic badges =====
   Save additions on P.fish: crl (creel tier 0-4), bty (daily bounties), bait {inv,on}, tro (8 mounted species), ach (claimed feats),
   s.ft / s.lc (fishing seconds and landings since update 6, for the bounty pace model), s.rs (landed/escaped per rarity), s.bait (bait casts used).
   Art comes from 90q (fsCreelArt, fsBaitArt, fsPlaque, fsMedal, fsIcon kinds); every call has a fallback so this module works alone. */
const FSU6={hubMod:0,q:[],qt:0};
const fsU6rnd=seed=>{let a=seed>>>0;return()=>{a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}};
const fsR5=v=>Math.max(5,Math.round(v/5)*5);
/* ---------- creel tiers: bought with gold; each tier holds more fish and adds a perk ---------- */
const FSCRT=[
 {n:'Wicker Creel',cap:30,c:0,b:0,pk:'A plain willow basket.'},
 {n:'Sturdy Creel',cap:40,c:350,b:0,pk:'Sort tools: order your fish by rarity, value, size or newest.'},
 {n:'Frostkeeper Creel',cap:55,c:1000,b:.05,pk:'Rarity filters, and ice keeps fish fresh: +5% value when sold from the basket.'},
 {n:'Enchanted Creel',cap:75,c:2500,b:.10,pk:'+10% value, and "Sell extras" sells duplicates but keeps your best of each.'},
 {n:'Moonlit Treasure Creel',cap:100,c:6000,b:.15,pk:'+15% value, and crafting bait needs one fewer fish.'}];
const fsCrT=()=>Math.max(0,Math.min(FSCRT.length-1,fsP().crl|0));
function fsCreelCap(){return FSCRT[fsCrT()].cap}
function fsCreelBuy(){const i=fsCrT()+1,T=FSCRT[i];if(!T||P.gold<T.c)return false;P.gold-=T.c;fsP().crl=i;fsSt('spent',T.c,'add');save();return true}
/* stored fish carry kp:1 so the tier's value bonus applies only when selling from the basket (old entries are marked when first valued) */
function fsKeep(c){const F=fsP();if(F.cr.length>=fsCreelCap())return false;F.cr.push({id:c.id,cm:c.cm,g:c.g?1:0,ft:c.ft!=null?c.ft:(c.id===fsMoon().feat?1:0),kp:1,t:Date.now()});save();return true}
{const v0=fsValue;fsValue=function(c){if(c&&!c.kp&&P.fish&&Array.isArray(P.fish.cr)&&P.fish.cr.indexOf(c)>=0)c.kp=1;const v=v0.apply(this,arguments);return c&&c.kp?Math.max(1,Math.round(v*(1+FSCRT[fsCrT()].b))):v}}
function fsSellCreel(i){const F=fsP(),c=F.cr[i];if(!c)return 0;c.kp=1;F.cr.splice(i,1);return fsSell(c)}
/* fish worth keeping no matter what: rare or better, and fish saved for an unmade rod look */
function fsCrNeeded(F){const need={};if(F.look!==0)for(const k of FSKINK)if(!F.sk[k])for(const [id,n] of Object.entries(FSKIN[k].k))need[id]=Math.max(need[id]||0,n);return need}
/* "Sell extras" (Enchanted Creel): keep the most valuable fish of each species, rod-look fish and anything Rare or better; sell the rest */
function fsSellExtras(){const F=fsP(),need=fsCrNeeded(F),by={};F.cr.forEach(c=>{(by[c.id]=by[c.id]||[]).push(c)});const keep=new Set();
 for(const [id,L] of Object.entries(by)){L.sort((a,b)=>fsValue(b)-fsValue(a));const n=Math.max(1,need[id]||0);L.slice(0,n).forEach(c=>keep.add(c));if(FSR[FISH[id].r].k>=2)L.forEach(c=>keep.add(c))}
 let v=0,n=0;const out=[];F.cr.forEach(c=>{if(keep.has(c))out.push(c);else{c.kp=1;v+=fsSell(c);n++}});F.cr=out;save();return{v,n}}
/* ---------- baits: one is used up per cast while equipped ---------- */
const FSBAIT={
 worm:{n:'Glow Worms',d:'Uncommon fish bite 60% more often.',m:{u:1.6},cast:10,cost:30,cr:{rk:'c',n:4},c:'#7aff9a'},
 moth:{n:'Moonmoth Lure',d:'Rare fish bite twice as often.',m:{r:2},cast:10,cost:90,cr:{rk:'u',n:3},c:'#bfe8ff'},
 roe:{n:'Starlight Roe',d:'Legendary fish bite 2.5× as often, and a Mythic twice as often.',m:{l:2.5,m:2},cast:8,cost:300,cr:{rk:'r',n:3},c:'#ffc2e0'},
 shrimp:{n:'Frost Shrimp',loc:'frost',d:'At Frostfall Lake, its own fish bite 2.5× as often as visitors from other waters.',cast:10,cost:45,cr:{loc:'frost',n:3},c:'#8ad8ff'},
 spore:{n:'Glowcap Spores',loc:'grotto',d:'At Glowcap Grotto, its own fish bite 2.5× as often as visitors from other waters.',cast:10,cost:45,cr:{loc:'grotto',n:3},c:'#5af0e0'}};
const FSBAITK=Object.keys(FSBAIT);
function fsBaitP(){const F=fsP();if(!F.bait||typeof F.bait!=='object')F.bait={inv:{},on:''};F.bait.inv=F.bait.inv||{};if(F.bait.on&&!FSBAIT[F.bait.on])F.bait.on='';return F.bait}
/* the bait that will work on the next cast here (or null) */
function fsBaitAct(){const B=fsBaitP(),k=B.on,K=FSBAIT[k];if(!K||!(B.inv[k]>0))return null;if(K.loc&&K.loc!==fsLoc())return null;return Object.assign({k},K)}
function fsBaitBuy(k){const K=FSBAIT[k];if(!K||P.gold<K.cost)return false;P.gold-=K.cost;const B=fsBaitP();B.inv[k]=(B.inv[k]||0)+K.cast;if(!B.on)B.on=k;fsSt('spent',K.cost,'add');save();return true}
/* crafting turns in the least valuable matching fish from the creel (never fish saved for rod looks) */
function fsBaitNeed(k){return Math.max(1,FSBAIT[k].cr.n-(fsCrT()>=4?1:0))}
function fsBaitFish(k){const R=FSBAIT[k].cr,F=fsP(),need=fsCrNeeded(F),cnt={};F.cr.forEach(c=>cnt[c.id]=(cnt[c.id]||0)+1);
 return F.cr.filter(c=>{const f=FISH[c.id];if(R.rk&&f.r!==R.rk)return false;if(R.loc&&(f.loc!==R.loc||FSR[f.r].k>1))return false;return true}).sort((a,b)=>fsValue(a)-fsValue(b)).filter(c=>{if(need[c.id]&&cnt[c.id]<=need[c.id])return false;return true})}
function fsBaitCraft(k){const n=fsBaitNeed(k),L=fsBaitFish(k).slice(0,n);if(L.length<n)return false;const F=fsP();F.cr=F.cr.filter(c=>!L.includes(c));const B=fsBaitP();B.inv[k]=(B.inv[k]||0)+FSBAIT[k].cast;if(!B.on)B.on=k;save();return true}
let FSBAITM=null;
{const o0=fsOdds;fsOdds=function(){const r=o0.apply(this,arguments);if(!FSBAITM)return r;const m=FSBAITM,x={};for(const k of ['u','r','l','m'])x[k]=r[k]*(m[k]||1);x.c=Math.max(5,100-x.u-x.r-x.l-x.m);const s=x.c+x.u+x.r+x.l+x.m;for(const k in x)x[k]=x[k]/s*100;return x}}
{const r0=fsRoll;fsRoll=function(rnd){const b=FS.on?fsBaitAct():null;if(!b)return r0.apply(this,arguments);FSBAITM=b.m||null;let c;try{c=r0.apply(this,arguments)}finally{FSBAITM=null}
  if(b.loc&&FSR[c.rk].k<4){/* spot bait: pick the species again inside the rolled rarity with the spot's own fish weighted x2.5, keeping the size roll */
   const rr=rnd||Math.random,M=fsMoon(),ids=(FSPOOL[fsLoc()]||[]).filter(id=>FISH[id].r===c.rk);if(ids.length>1){const ws=ids.map(id=>FISH[id].w*(id===M.feat?2:1)*(FISH[id].loc===b.loc?2.5:1)),tot=ws.reduce((a,v)=>a+v,0);let y=rr()*tot,id=ids[0];for(let i=0;i<ids.length;i++){if(y<ws[i]){id=ids[i];break}y-=ws[i]}
    if(id!==c.id){const f0=FISH[c.id],f1=FISH[id],u=(c.cm-f0.len[0])/Math.max(.1,f0.len[1]-f0.len[0]);c.id=id;c.cm=Math.round((f1.len[0]+(f1.len[1]-f1.len[0])*Math.max(0,Math.min(1,u)))*10)/10}}}
  const B=fsBaitP();B.inv[b.k]=Math.max(0,(B.inv[b.k]||0)-1);fsSt('bait',1,'add');if(!B.inv[b.k]){FSU6.baitOut=b.k}c.bait=b.k;save();return c}}
/* ---------- the pace model: how many fish this player lands per minute, and how often each rarity gets away ---------- */
const FSU6SUCC={c:.96,u:.92,r:.6,l:.35,m:.25};
function fsPace(){const s=fsP().s,ft=s.ft||0,lc=s.lc||0;const L=ft>=300&&lc>=10?lc/(ft/60):4.2;const succ={};for(const k of FSRK){const a=(s.rs&&s.rs[k])||[0,0],n=a[0]+a[1];succ[k]=n>=8?Math.max(.2,Math.min(1,a[0]/n)):FSU6SUCC[k]}const ms=s.rs&&s.rs.c&&s.rs.c[0]+s.rs.c[1]>=20;
 return{ms,L:Math.max(2.2,Math.min(7,L)),succ,lure:fsP().up.lure||0,hook:fsP().up.hook||0}}
/* share of landed fish at a spot that match pred(id,rk) -> 0..1 (neutral moon, no bait) */
function fsShareAt(loc,pred,M){const o=fsOdds(M.lure,{},loc),pl=FSPOOL[loc]||[];let num=0,den=0;for(const rk of FSRK){const ids=pl.filter(i=>FISH[i].r===rk);if(!ids.length)continue;const pr=o[rk]/100*M.succ[rk];den+=pr;const W=ids.reduce((a,i)=>a+FISH[i].w,0);for(const i of ids)num+=pr*FISH[i].w/W*pred(i,rk)}return den?num/den:0}
function fsLandRate(loc,M){const o=fsOdds(M.lure,{},loc);let s=0;for(const rk of FSRK)s+=o[rk]/100*M.succ[rk];return s}
/* ---------- daily bounties: three tavern requests a day, sized from the pace model so each takes a few real minutes ---------- */
const FSBTYD=[{n:'Easy',T:3.5,c:'#7affb4'},{n:'Medium',T:6.5,c:'#7ad8ff'},{n:'Hard',T:11,c:'#ffb45a'}];
function fsBtyOpen(){return FSLOCK.filter(k=>fsLocOpen(k)&&(FSPOOL[k]||[]).length)}
function fsBtyCands(d,M,rng,avoid){const D=FSBTYD[d],T=D.T,open=fsBtyOpen(),out=[],L=M.L;
 /* count requests ask for at least 2 so a single lucky (or unlucky) bite doesn't decide them; one-off rare events (a Giant, a lone Rare) are never asked for */
 const add=(o,sh)=>{if(!(sh>0)||!(o.n>=2))return;o.min=o.n/(L*sh);if(o.min>=T*.55&&o.min<=T*1.5){o.d=d;out.push(o)}};
 /* one species (Common, or Uncommon from Medium up); it counts at any spot, and the hint names the spot where it bites best */
 FIDS.forEach(id=>{const rk=FISH[id].r;if(rk==='l'||rk==='m'||rk==='r')return;if(rk==='u'&&d<1)return;if(avoid.ids.includes(id))return;
  let best=0,bl='';open.forEach(loc=>{if(!FSPOOL[loc].includes(id))return;const sh=fsShareAt(loc,i=>i===id?1:0,M);if(sh>best){best=sh;bl=loc}});if(!best)return;
  const n=Math.min(10,Math.round(T*L*best));if(d>0&&n<3)return;add({k:'sp',id,loc:bl,n},best)});
 /* a rarity or rarer, anywhere */
 /* Rare requests only once this player has shown they can land Rares (slow typists lose many of them) */
 const rOk=(()=>{const a=fsP().s.rs&&fsP().s.rs.r;return a&&a[0]>=3&&a[0]/(a[0]+a[1])>=.4||fsU6Rare(fsP())>=3})();
 ['u','r'].forEach(rk=>{if(rk==='u'&&d<1||rk==='r'&&(d<2||!rOk))return;let best=0,bl='pond';open.forEach(loc=>{const sh=fsShareAt(loc,(i,r)=>FSR[r].k>=FSR[rk].k?1:0,M);if(sh>best){best=sh;bl=loc}});add({k:'rk',rk,loc:bl,n:Math.round(T*L*best)},best)});
 /* any fish at a spot (Medium/Hard prefer the new spots) */
 open.forEach(loc=>{if(d>0&&loc==='pond'&&open.length>1)return;add({k:'cnt',loc,n:Math.round(T*L)},1)});
 /* big fish: top quarter of the species' size range (giants count) */
 {const pg=.04+M.hook*.006,hk=M.hook*.04;let n=0;for(let i=0;i<3000;i++){const b=(rng()+rng()+rng())/3;if(Math.min(.92,b*(1+hk))>=.75)n++}const q=pg+(1-pg)*n/3000;add({k:'big',n:Math.min(6,Math.round(T*L*q))},q)}
 /* a run of catches without one getting away (sized from this player's own catch rate) */
 if(d>0&&M.ms){/* runs are very sensitive to how often fish get away, so they are only asked for once this player's own rate is known */const loc=fsLoc(),s=Math.min(.995,fsLandRate(loc,M)),cpm=L/s;let n=5;for(let k=5;k<=12;k++){const casts=(1-Math.pow(s,k))/((1-s)*Math.pow(s,k));if(casts/cpm<=T*.7)n=k}/* one slip resets a run, so the spread is wide: aim well under the target */const casts=(1-Math.pow(s,n))/((1-s)*Math.pow(s,n)),min=casts/cpm;
  if(min>=T*.55&&min<=T*1.5)out.push({k:'run',n,min,d})}
 /* total value of fish landed (they don't have to be sold) */
 if(d>0){let best=0,bl='pond';open.forEach(loc=>{const o=fsOdds(M.lure,{},loc),pl=FSPOOL[loc];let num=0,den=0;for(const rk of FSRK){const ids=pl.filter(i=>FISH[i].r===rk);if(!ids.length)continue;const pr=o[rk]/100*M.succ[rk];den+=pr;const W=ids.reduce((a,i)=>a+FISH[i].w,0);for(const i of ids)num+=pr*FISH[i].w/W*FISH[i].v}const v=den?num/den:0;if(v>best){best=v;bl=loc}});
  const n=Math.max(20,Math.round(T*L*best*.9/10)*10);out.push({k:'val',n,loc:bl,min:n/(L*best),d})}
 return out.filter(o=>!avoid.k.includes(o.k))}
function fsBtyPick(d,M,rng,avoid){const C=fsBtyCands(d,M,rng,avoid);if(!C.length){const L=M.L,T=FSBTYD[d].T;return{k:'cnt',loc:'pond',n:Math.max(3,Math.round(T*L)),min:T,d}}
 /* choose a kind first (so species requests don't crowd everything out), then one request of that kind */
 const kinds=[...new Set(C.map(o=>o.k))],k=kinds[Math.floor(rng()*kinds.length)],L2=C.filter(o=>o.k===k);return L2[Math.floor(rng()*L2.length)]}
function fsBtyMake(o){const rw=fsR5(16*o.min+20);return{d:o.d,k:o.k,id:o.id||'',loc:o.loc||'',rk:o.rk||'',n:o.n,got:0,rw,min:Math.round(o.min*10)/10,done:0}}
function fsBtyGen(day,salt){const M=fsPace(),rng=fsU6rnd(day*7919+(salt||0)*104729+17),av={k:[],ids:[]},L=[];
 for(let d=0;d<3;d++){const o=fsBtyPick(d,M,rng,av);av.k.push(o.k);if(o.id)av.ids.push(o.id);L.push(fsBtyMake(o))}return L}
function fsBtyGet(){const F=fsP(),day=fsDayN();let B=F.bty;if(!B||typeof B!=='object')B=F.bty={st:0,sd:-9,best:0,tot:0};
 if(B.day!==day){B.day=day;B.L=fsBtyGen(day,0);B.rr=0;B.all=0;B.run=0;if(B.sd<day-1)B.st=0;save()}return B}
function fsBtyStreak(){const B=fsBtyGet();return B.sd>=fsDayN()-1?B.st:0}
const fsBtyBonus=()=>{const s=fsBtyStreak();return 100+25*Math.min(4,s)};
/* swap one unfinished request for a different one (one free swap a day) */
function fsBtySwap(i){const B=fsBtyGet(),b=B.L[i];if(!b||b.done||B.rr)return false;const M=fsPace(),rng=fsU6rnd(B.day*7919+(i+1)*31337+911),av={k:B.L.map(x=>x.k),ids:B.L.map(x=>x.id).filter(Boolean)};
 B.L[i]=fsBtyMake(fsBtyPick(b.d,M,rng,av));B.rr=1;save();return true}
function fsBtyText(b){const L=FSLOCS[b.loc],at=L?L.n:'';switch(b.k){
 case 'sp':return{t:`Catch ${b.n} ${FISH[b.id].n}`,s:`Bites best at ${at}`};
 case 'rk':return{t:`Catch ${b.n} ${FSR[b.rk].n} or rarer fish`,s:'Any spot'};
 case 'cnt':return{t:`Catch ${b.n} fish at ${at}`,s:'Any kind of fish'};
 case 'big':return{t:`Land ${b.n} big fish`,s:'Top quarter of their size range'};
 case 'gnt':return{t:b.n>1?`Land ${b.n} Giants`:'Land a Giant',s:'The biggest 4% of any fish'};
 case 'run':return{t:`Catch ${b.n} fish in a row`,s:'Without one getting away'};
 case 'val':return{t:`Land fish worth ${b.n.toLocaleString()} gold`,s:'Their total value; sold or kept'};}return{t:'',s:''}}
function fsBtyShort(b){switch(b.k){case 'sp':return `${b.n} ${FISH[b.id].n}`;case 'rk':return `${b.n} ${FSR[b.rk].n}+ fish`;case 'cnt':return `${b.n} fish · ${FSLOCS[b.loc].n.split(' ')[0]}`;case 'big':return `${b.n} big fish`;case 'gnt':return b.n>1?`${b.n} Giants`:'A Giant';case 'run':return `${b.n} in a row`;case 'val':return `${b.n.toLocaleString()} gold of fish`}return''}
function fsBtyDone(B,b){b.done=1;b.got=b.n;P.gold+=b.rw;fsSt('bgold',b.rw,'add');B.tot=(B.tot||0)+1;FSU6.q.push({t:'Bounty complete!',s:`${fsBtyText(b).t} · +${b.rw} gold`,c:FSBTYD[b.d].c});
 if(!B.all&&B.L.every(x=>x.done)){B.all=1;const bonus=fsBtyBonus(),day=B.day;B.st=B.sd===day-1?(B.st||0)+1:1;B.sd=day;B.best=Math.max(B.best||0,B.st);P.gold+=bonus;fsSt('bgold',bonus,'add');
  FSU6.q.push({t:'All bounties done!',s:`Board bonus +${bonus} gold · ${B.st}-day streak`,c:'#ffd45a',big:1})}}
function fsBtyOnCatch(c){const B=fsBtyGet(),loc=fsLoc(),f=FISH[c.id],rel=(c.cm-f.len[0])/Math.max(.1,f.len[1]-f.len[0]);B.run=(B.run||0)+1;let ch=0;
 B.L.forEach(b=>{if(b.done)return;let inc=0;
  if(b.k==='sp')inc=c.id===b.id?1:0;else if(b.k==='rk')inc=FSR[c.rk].k>=FSR[b.rk].k?1:0;else if(b.k==='cnt')inc=loc===b.loc?1:0;else if(b.k==='big')inc=rel>=.75||c.g?1:0;else if(b.k==='gnt')inc=c.g?1:0;
  else if(b.k==='val'){const k=Object.assign({},c);delete k.kp;inc=fsValue(k)}else if(b.k==='run'){if(B.run>b.got){b.got=B.run;ch=1}}
  if(inc){b.got+=inc;ch=1}if(b.got>=b.n)fsBtyDone(B,b)});return ch}
/* ---------- hooks into catching ---------- */
{const r0=fsRecord;fsRecord=function(c){const out=r0.apply(this,arguments);try{const F=fsP(),s=F.s;s.lc=(s.lc||0)+1;s.rs=s.rs||{};const a=s.rs[c.rk]||(s.rs[c.rk]=[0,0]);a[0]++;
  s.at=s.at||{};s.at[fsLoc()]=1;if(FS.on)fsBtyOnCatch(c);save();fsU6PondRefresh()}catch(e){console.error(e)}return out}}
{const e0=fsEscape;fsEscape=function(){try{const c=FS.cur,s=fsP().s;if(c){s.rs=s.rs||{};const a=s.rs[c.rk]||(s.rs[c.rk]=[0,0]);a[1]++}const B=fsBtyGet();B.run=0}catch(e){}return e0.apply(this,arguments)}}
{const c0=fsCast;fsCast=function(){if(FS.st==='idle'&&!FS.tut){const now=Date.now(),s=fsP().s;if(FSU6.lc&&now-FSU6.lc<90000)s.ft=(s.ft||0)+(now-FSU6.lc)/1000;FSU6.lc=now}return c0.apply(this,arguments)}}
{const s0=fsSet;fsSet=function(st){const r=s0.apply(this,arguments);if(st==='idle')try{fsU6Flush()}catch(e){}return r}}
{const s0=fsStart;fsStart=function(){const r=s0.apply(this,arguments);FSU6.lc=0;FSU6.q=[];try{fsBtyGet();setTimeout(fsU6PondHud,0)}catch(e){console.error(e)}return r}}
/* show finished-bounty news once the catch is dealt with */
function fsU6Flush(){if(!FS.on){FSU6.q=[];return}if(FSU6.baitOut){const k=FSU6.baitOut;FSU6.baitOut=0;FSU6.q.push({t:'Out of bait',s:`Your ${FSBAIT[k].n} ran out. Press B for more.`,c:'#c4badf',quiet:1})}
 if(!FSU6.q.length||FSU6.qt)return;const n=FSU6.q.shift();try{fsBanner(n.t,n.s,n.c,n.big?2.6:2.1)}catch(e){}if(!n.quiet){try{fsSfx('buy');if(n.big)setTimeout(()=>{try{fsSfx('r')}catch(e){}},260)}catch(e){}}
 const el=$('fsbt');if(el&&!n.quiet){el.classList.remove('pop');void el.offsetWidth;el.classList.add('pop')}try{fsHudRefresh()}catch(e){}
 FSU6.qt=setTimeout(()=>{FSU6.qt=0;if(FS.on&&FS.st==='idle')fsU6Flush()},n.big?2700:2200)}
/* ---------- art fallbacks (90q paints the real thing) ---------- */
function fsU6Creel(g,t,x,y,s,tt,fill){if(typeof fsCreelArt==='function')return fsCreelArt(g,t,x,y,s,tt,fill);g.save();g.translate(x,y);g.scale(s,s);fsIcon(g,'basket',0,0,2.2,tt);g.restore()}
function fsU6Bait(g,k,x,y,s,t){if(typeof fsBaitArt==='function')return fsBaitArt(g,k,x,y,s,t);g.save();g.translate(x,y);g.scale(s,s);g.beginPath();g.arc(0,0,34,0,TAU);g.fillStyle=(FSBAIT[k]||{c:'#5a4ca0'}).c;g.fill();g.lineWidth=4;g.strokeStyle='#1b1024';g.stroke();g.restore()}
function fsU6Medal(g,k,x,y,s,t,got){if(typeof fsMedal==='function')return fsMedal(g,k,x,y,s,t,got);g.save();g.translate(x,y);g.scale(s,s);g.beginPath();g.arc(0,0,32,0,TAU);g.fillStyle=got?'#ffc23a':'#2a2050';g.fill();g.lineWidth=4;g.strokeStyle='#1b1024';g.stroke();g.restore()}
function fsU6Plaque(g,cx,cy,w,h,rk,t,empty){if(typeof fsPlaque==='function')return fsPlaque(g,cx,cy,w,h,rk,t,empty);g.save();g.beginPath();g.ellipse(cx,cy,w*.48,h*.46,0,0,TAU);g.fillStyle='#5a3620';g.fill();g.lineWidth=5;g.strokeStyle=empty?'#3a2a20':FSR[rk||'c'].c;g.stroke();g.restore()}
const FSFLAME='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2c1 4 6 6 6 12a6 6 0 0 1-12 0c0-3 2-5 3-7 0 2 1 3 2 3 0-3-1-5 1-8z" fill="#ff9a3a" stroke="#1b1024" stroke-width="1.6" stroke-linejoin="round"/><path d="M12 12c1 2 3 3 3 5a3 3 0 0 1-6 0c0-1 1-2 1-3 1 1 2 0 2-2z" fill="#ffe27a"/></svg>';
/* ---------- the pond HUD: a small bounty tracker under the spot card and a bait chip above the rod ---------- */
function fsU6PondHud(){const x=$('fsx');if(!x||S.view!=='fish'||!FS.on)return;if(!$('fsbt')){const d=document.createElement('div');d.className='fsbt fsg';d.id='fsbt';x.appendChild(d)}
 if(!$('fsbc')){const b=document.createElement('button');b.className='fsbc fsg';b.id='fsbc';b.title='Bait pouch (B)';x.appendChild(b);b.onclick=()=>fsBaitOpen()}fsU6PondRefresh()}
function fsU6PondRefresh(){const el=$('fsbt'),bc=$('fsbc');if(!el&&!bc)return;const F=fsP();
 if(el){const B=fsBtyGet(),dn=B.L.filter(b=>b.done).length,st=fsBtyStreak();el.classList.toggle('min',!!B.hide);el.classList.toggle('all',dn===3);
  el.innerHTML=`<button class="fsbt-h" id="fsbth" aria-expanded="${!B.hide}"><b>Daily Bounties</b><span>${dn} / 3</span>${st?`<em title="${st}-day streak">${FSFLAME}${st}</em>`:''}<i>▾</i></button>
  <ol>${B.L.map(b=>{const p=Math.min(1,b.got/b.n),run=b.k==='run'&&!b.done&&B.run?` <small>(now ${B.run})</small>`:'';return `<li class="${b.done?'ok':''}" style="--bc:${FSBTYD[b.d].c}"><i class="fsbt-d" aria-hidden="true">${b.done?'✓':''}</i><span>${fsEsc(fsBtyShort(b))}${run}</span><b>${b.done?'Paid':`${(b.k==='val'?Math.min(b.got,b.n).toLocaleString():Math.min(b.got,b.n))}/${b.k==='val'?b.n.toLocaleString():b.n}`}</b><u style="width:${(p*100).toFixed(1)}%"></u></li>`}).join('')}</ol>`;
  $('fsbth').onclick=()=>{B.hide=B.hide?0:1;save();fsU6PondRefresh()};el.querySelector('ol').onclick=()=>{if(FS.st==='idle'||FS.st==='reveal')fsBountyModal('pond')}}
 if(bc){const a=fsBaitAct(),B=fsBaitP(),k=B.on,K=FSBAIT[k],n=K?B.inv[k]||0:0;
  bc.classList.toggle('on',!!a);bc.innerHTML=`<canvas width="64" height="64" aria-hidden="true"></canvas><span><b>${K?K.n:'No bait'}</b><small>${!K?'Choose a bait':!n?'None left · get more':K.loc&&K.loc!==fsLoc()?`Works at ${FSLOCS[K.loc].n}`:`${n} cast${n>1?'s':''} left`}</small></span><kbd>B</kbd>`;
  const g=bc.querySelector('canvas').getContext('2d');g.clearRect(0,0,64,64);fsU6Bait(g,K?k:'none',32,32,.56,.6)}}
{const h0=fsHudRefresh;fsHudRefresh=function(){const r=h0.apply(this,arguments);try{fsU6PondRefresh()}catch(e){}return r}}
function fsBaitOpen(){if(S.view==='fish'&&FS.on&&FS.st!=='idle'&&FS.st!=='reveal'){fsToast('Finish this catch first, then change your bait.');return}fsBaitModal(S.view==='fish'?'pond':'hub')}
document.addEventListener('keydown',e=>{if(S.mode!=='fish'||e.ctrlKey||e.metaKey||e.altKey||e.repeat)return;const m=$('fsmod');if(m&&!m.hidden)return;const k=e.key.toLowerCase();
 if(S.view==='fish'&&FS.on&&!FS.tut&&FS.st==='idle'&&k==='b'){e.preventDefault();e.stopImmediatePropagation();fsBaitOpen()}
 else if(S.view==='fishhub'){if(k==='b'){e.preventDefault();e.stopImmediatePropagation();fsBaitModal('hub')}else if(k==='t'){e.preventDefault();e.stopImmediatePropagation();fsTrophy()}else if(k==='o'){e.preventDefault();e.stopImmediatePropagation();fsBountyModal('hub')}}},true);
/* closing a modal from the hub re-renders it so the tiles show fresh numbers */
function fsU6Close(from){fsModal(null);if(from==='hub')fsHub();else if(from==='trophy')fsTrophy();else{try{fsHudRefresh()}catch(e){}}}
function fsU6Modal(h,from){fsModal(h);const m=$('fsmod');if(!m)return;m.onclick=e=>{if(e.target===m)fsU6Close(from)};const x=$('fsx2');if(x)x.onclick=()=>fsU6Close(from)}
/* ---------- the bait pouch ---------- */
function fsBaitModal(from){const B=fsBaitP(),F=fsP(),here=fsLoc();
 const rows=FSBAITK.map(k=>{const K=FSBAIT[k],have=B.inv[k]||0,on=B.on===k,need=fsBaitNeed(k),got=fsBaitFish(k).length,what=K.cr.rk?`${FSR[K.cr.rk].n} fish`:`${FSLOCS[K.cr.loc].n} fish`,lock=K.loc&&!fsLocOpen(K.loc);
  return `<div class="fsbm-r${on?' on':''}${lock?' lk':''}" style="--bc:${K.c}"><canvas width="104" height="104" data-bait="${k}" aria-hidden="true"></canvas>
   <div class="fsbm-t"><b>${K.n}${K.loc?` <em>${FSLOCS[K.loc].n} only</em>`:''}</b><small>${K.d}</small><span class="fsbm-have${have?'':' no'}">${have?`${have} cast${have>1?'s':''} in your pouch`:'None in your pouch'}${on?' · <i>equipped</i>':''}</span></div>
   <div class="fsbm-b">${lock?`<span class="fsbm-lk">Unlock ${FSLOCS[K.loc].n} first</span>`:`<button data-buy="${k}" ${P.gold<K.cost?'disabled':''}><span class="fsbm-c">${fsCoin}${K.cost}</span><small>buy ${K.cast} casts</small></button>
    <button data-craft="${k}" class="cr" ${got>=need?'':'disabled'}>Craft<small>${need} ${what} (${Math.min(got,need)}/${need})</small></button>
    <button data-eq="${k}" class="eq${on?' on':''}" ${have||on?'':'disabled'}>${on?'Unequip':'Equip'}</button>`}</div></div>`}).join('');
 fsU6Modal(`<div class="fsbm fsg"><button class="fsx2" id="fsx2" aria-label="Close">✕</button><h3 class="fsu6h">Bait Pouch</h3>
  <p class="fsbm-s">Equip one bait at a time. Each cast uses one, and it changes which fish bite. Craft bait from fish in your basket (fish saved for rod looks are never used)${fsCrT()>=4?'. Your Moonlit Treasure Creel saves one fish per craft':''}.</p>
  <div class="fsbm-l">${rows}</div><p class="fsbm-f">You are fishing at <b>${FSLOCS[here].n}</b>. Bait is used up only while it is equipped.</p></div>`,from);
 const m=$('fsmod');m.querySelectorAll('canvas[data-bait]').forEach(cv=>{const k=cv.dataset.bait,g=cv.getContext('2d');const dr=t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,104,104);fsU6Bait(g,k,52,52,.9,t)};dr(.6);if(!fsRM())LIVE.push({cv,fn:t=>dr(t),slow:3})});
 const re=()=>{fsBaitModal(from);try{fsHudRefresh()}catch(e){}};
 m.querySelectorAll('[data-buy]').forEach(b=>b.onclick=()=>{const k=b.dataset.buy;if(fsBaitBuy(k)){fsSfx('buy');try{fsToast(`Bought ${FSBAIT[k].cast} casts of ${FSBAIT[k].n}.`,1)}catch(e){}re()}});
 m.querySelectorAll('[data-craft]').forEach(b=>b.onclick=()=>{const k=b.dataset.craft;if(fsBaitCraft(k)){fsSfx('r');try{fsToast(`Crafted ${FSBAIT[k].cast} casts of ${FSBAIT[k].n}.`)}catch(e){}re()}});
 m.querySelectorAll('[data-eq]').forEach(b=>b.onclick=()=>{const k=b.dataset.eq,B2=fsBaitP();B2.on=B2.on===k?'':k;save();try{beep(760,.05,'triangle',.12)}catch(e){}re()})}
/* ---------- the bounty board ---------- */
const FSBTYMED={sp:'catch',rk:'rare',cnt:'spots',big:'giant',gnt:'giant',run:'streak',val:'gold'};
function fsBtyLeft(){const n=new Date(),m=new Date(n.getFullYear(),n.getMonth(),n.getDate()+1),s=Math.max(0,(m-n)/1000|0),h=s/3600|0,mi=(s%3600)/60|0;return h?`${h}h ${mi}m`:`${mi}m`}
function fsBountyModal(from){const B=fsBtyGet(),st=fsBtyStreak(),dn=B.L.filter(b=>b.done).length,tot=Math.round(B.L.reduce((a,b)=>a+b.min,0)),M=fsPace();
 const notes=B.L.map((b,i)=>{const D=FSBTYD[b.d],T=fsBtyText(b),p=Math.min(1,b.got/b.n);
  return `<div class="fsbb-n${b.done?' ok':''}" style="--bc:${D.c};--r:${[-1.6,.9,-.6][i]}deg"><i class="fsbb-pin" aria-hidden="true"></i><em class="fsbb-dif">${D.n}</em>
   <canvas width="150" height="96" data-bn="${i}" aria-hidden="true"></canvas><b>${fsEsc(T.t)}</b><small>${fsEsc(T.s)}</small><span class="fsbb-min">About ${Math.max(2,Math.round(b.min))} min of fishing</span>
   <div class="fsbb-bar" aria-hidden="true"><i style="width:${(p*100).toFixed(1)}%"></i></div><span class="fsbb-pr">${b.k==='run'&&!b.done?`Best ${b.got} · now ${B.run||0} / ${b.n}`:`${Math.min(b.got,b.n).toLocaleString()} / ${b.n.toLocaleString()}`}</span>
   <span class="fsbb-rw">${fsCoin}${b.rw}</span>${b.done?'<span class="fsbb-ok">PAID</span>':!B.rr?`<button class="fsbb-sw" data-swap="${i}" title="Swap this request for a different one (one free swap a day)">Swap</button>`:''}</div>`}).join('');
 fsU6Modal(`<div class="fsbb"><button class="fsx2" id="fsx2" aria-label="Close">✕</button><div class="fsbb-hd"><canvas width="104" height="88" id="fsbbic" aria-hidden="true"></canvas><div><h3 class="fsu6h">Tavern Bounty Board</h3>
  <p>Three new requests every day, sized to how fast you fish: about <b>${tot} minutes</b> for all three. Fish you catch for a bounty still sell as normal.</p></div>
  <div class="fsbb-st${st?' on':''}">${FSFLAME}<b>${st}</b><small>day streak</small></div></div>
  <div class="fsbb-ns">${notes}</div>
  <div class="fsbb-ft"><span>${B.all?`All done today! <b>+${100+25*Math.min(4,Math.max(0,st-1))} gold</b> board bonus paid.`:`Finish all three for a <b>+${fsBtyBonus()} gold</b> board bonus${st?` (streak bonus included)`:''}. Keep a daily streak for up to +200.`}</span>
  <span>${B.rr?'Swap used today · ':'One free swap a day · '}New bounties in <b>${fsBtyLeft()}</b></span></div></div>`,from);
 const m=$('fsmod');{const c=$('fsbbic');if(c){const g=c.getContext('2d');g.clearRect(0,0,104,88);fsIcon(g,'board',52,46,1,.5)}}
 m.querySelectorAll('canvas[data-bn]').forEach(cv=>{const b=B.L[+cv.dataset.bn],g=cv.getContext('2d');g.clearRect(0,0,150,96);
  if(b.k==='sp')fishFit(g,b.id,75,48,138,84,{t:.4,glow:0});else fsU6Medal(g,FSBTYMED[b.k],75,48,1.05,.4,true)});
 m.querySelectorAll('[data-swap]').forEach(x=>x.onclick=()=>{if(fsBtySwap(+x.dataset.swap)){try{beep(640,.05,'triangle',.14)}catch(e){}fsBountyModal(from);try{fsU6PondRefresh()}catch(e){}}})}
/* ---------- the creel tab (pond side panel and the hub's Fish Basket) ---------- */
const FSCRS=['—','Sort tools','Filters · +5% value','+10% value · Sell extras','+15% value · cheaper bait'];
function fsCreelHTML(){const F=fsP(),t=fsCrT(),T=FSCRT[t],nx=FSCRT[t+1],cap=fsCreelCap(),so=t>=1?FSU.cso||'rk':'rk',fl=t>=2?FSU.cfl||'all':'all';
 let L=F.cr.map((c,i)=>({c,i}));if(fl!=='all')L=L.filter(o=>FISH[o.c.id].r===fl);
 const rk=o=>FSR[FISH[o.c.id].r].k;L.sort(so==='val'?(a,b)=>fsValue(b.c)-fsValue(a.c):so==='cm'?(a,b)=>(b.c.cm-FISH[b.c.id].len[0])/(FISH[b.c.id].len[1]-FISH[b.c.id].len[0])-(a.c.cm-FISH[a.c.id].len[0])/(FISH[a.c.id].len[1]-FISH[a.c.id].len[0]):so==='new'?(a,b)=>(b.c.t||0)-(a.c.t||0)||b.i-a.i:(a,b)=>rk(b)-rk(a)||fsValue(b.c)-fsValue(a.c));
 const tot=F.cr.reduce((a,c)=>a+fsValue(c),0),full=F.cr.length>=cap;
 return `<div class="fscr6 t${t}${FSU.cjust?' just':''}"><canvas id="fscr6c" width="150" height="132" aria-hidden="true"></canvas><div class="fscr6-t"><b>${T.n}</b><span class="${full?'full':''}">${F.cr.length} / ${cap} fish${full?' · full':''}</span><i class="fscr6-bar" aria-hidden="true"><i style="width:${Math.min(100,F.cr.length/cap*100).toFixed(1)}%"></i></i><small>${t?FSCRS[t]:'Upgrade for more room and perks'}</small></div></div>
 ${nx?`<button class="fscr6-up" id="fscr6up" ${P.gold<nx.c?'disabled':''}><span><small>Upgrade to the</small><b>${nx.n}</b><small>${nx.cap} slots · ${FSCRS[t+1]}</small></span><em>${fsCoin}${nx.c.toLocaleString()}</em></button>`:'<div class="fscr6-max">♛ The finest creel there is</div>'}
 <p class="fsnote">Kept fish wait here. Sell them any time${T.b?` (<b>+${Math.round(T.b*100)}% value</b> from your ${T.n})`:''}, turn them in for rod looks, or craft them into bait.</p><label class="fsauto fsauto2"><input type="checkbox" id="fsauto2" ${F.auto?'checked':''}> Auto-sell Common &amp; Uncommon catches <small>(new species and giants are still kept)</small></label><label class="fsauto fsauto2"><input type="checkbox" id="fslook" ${F.look!==0?'checked':''}> Save fish I need for rod looks</label>
 ${F.cr.length?`<div class="fsflt fscr6-so" role="group" aria-label="Sort">${t>=1?[['rk','Rarity'],['val','Value'],['cm','Size'],['new','Newest']].map(([k,l])=>`<button data-cso="${k}" class="${so===k?'on':''}" style="--rc:#8a7ad8">${l}</button>`).join(''):'<span class="fscr6-lk">Sorting unlocks with the Sturdy Creel</span>'}</div>
 ${t>=2?`<div class="fsflt fscr6-fl" role="group" aria-label="Filter">${[['all','All'],...FSRK.map(k=>[k,FSR[k].n])].map(([k,l])=>`<button data-cfl="${k}" class="${fl===k?'on':''}" style="--rc:${k==='all'?'#8a7ad8':FSR[k].c}">${l}</button>`).join('')}</div>`:''}
 <div class="fscr6-sell"><button class="fssa" id="fssa">${fsCoin}Sell all · ${tot.toLocaleString()}</button>${t>=3?'<button class="fssa fscr6-ex" id="fscr6ex" title="Sell duplicates; keeps the most valuable of each species, rod-look fish and anything Rare or better">Sell extras</button>':''}</div>`:''}
 <div class="fslist">${L.length?L.map(({c,i})=>{const f=FISH[c.id];return `<div class="fsrow" data-ci="${i}" style="--rc:${FSR[f.r].c}"><canvas width="96" height="56"></canvas><span><b>${f.n}${c.g?' <span class="fscrown">♛</span>':''}</b><small>${FSR[f.r].n} · ${c.cm} cm</small></span><button data-sell="${i}">${fsCoin}${fsValue(c).toLocaleString()}</button></div>`}).join(''):F.cr.length?'<p class="fsempty">No fish of that rarity in your creel.</p>':'<p class="fsempty">Your creel is empty. Choose <b>Keep</b> after a catch to store a fish here.</p>'}</div>`}
{const t0=fsTabs;fsTabs=function(){const r=t0.apply(this,arguments);try{if(FSU.tab==='c')fsU6CreelBind()}catch(e){console.error(e)}return r}}
function fsU6CreelBind(){const b=$('fsbody');if(!b)return;const F=fsP(),t=fsCrT();FSU.cjust=0;
 const cv=$('fscr6c');if(cv){const g=cv.getContext('2d');const dr=tt=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,150,132);fsU6Creel(g,t,75,70,.6,tt,Math.min(1,F.cr.length/fsCreelCap()))};dr(1);if(t>=2&&!fsRM())LIVE.push({cv,fn:dr,slow:3})}
 const up=$('fscr6up');if(up)up.onclick=()=>{const t0=fsCrT();if(fsCreelBuy()){fsSfx('buy');setTimeout(()=>{try{fsSfx('r')}catch(e){}},200);FSU.cjust=1;try{fsToast(`Your basket is now the ${FSCRT[t0+1].n}: ${FSCRT[t0+1].cap} slots!`,1)}catch(e){}try{fsHudRefresh()}catch(e){}fsTabs()}};
 b.querySelectorAll('[data-cso]').forEach(x=>x.onclick=()=>{FSU.cso=x.dataset.cso;fsTabs()});b.querySelectorAll('[data-cfl]').forEach(x=>x.onclick=()=>{FSU.cfl=x.dataset.cfl;fsTabs()});
 const ex=$('fscr6ex');if(ex)ex.onclick=()=>{if(!ex.dataset.ok){ex.dataset.ok=1;ex.textContent='Tap again to sell extras';setTimeout(()=>{if(ex.isConnected){delete ex.dataset.ok;ex.textContent='Sell extras'}},2600);return}
  const r=fsSellExtras();fsSfx('sell');try{fsToast(r.n?`Sold ${r.n} extra fish for ${r.v.toLocaleString()} gold.`:'No extras to sell: you only have your best of each.',!!r.n)}catch(e){}try{fsHudRefresh()}catch(e){}fsTabs()};
 const sc=$('fscrn');if(sc)sc.textContent=F.cr.length?`${F.cr.length}`:''}
/* ---------- achievements (claimed in the Trophy Hall) ---------- */
const fsU6Rare=F=>FIDS.reduce((a,id)=>a+(FSR[FISH[id].r].k>=2&&F.b[id]?F.b[id].n||0:0),0);
const fsU6Spots=F=>['pond','frost','grotto'].filter(k=>(F.s.at&&F.s.at[k])||FIDS.some(id=>F.b[id]&&F.b[id].n&&(k==='pond'?!FISH[id].loc:FISH[id].loc===k))).length;
const FSACH=[
 {k:'c10',m:'catch',n:'First Nibbles',d:'Catch 10 fish',g:10,v:F=>F.s.caught||0,rw:50},
 {k:'c100',m:'catch',n:'Steady Hands',d:'Catch 100 fish',g:100,v:F=>F.s.caught||0,rw:150},
 {k:'c500',m:'catch',n:'Old Salt',d:'Catch 500 fish',g:500,v:F=>F.s.caught||0,rw:500},
 {k:'s15',m:'species',n:'Naturalist',d:'Discover 15 species',g:15,v:()=>fsFound(),rw:100},
 {k:'s30',m:'species',n:'Scholar of the Deep',d:'Discover 30 species',g:30,v:()=>fsFound(),rw:300},
 {k:'sall',m:'species',n:'Complete Bestiary',d:`Discover all ${FIDS.length} species`,g:FIDS.length,v:()=>fsFound(),rw:1500},
 {k:'rare',m:'rare',n:'Blue Ribbon',d:'Catch 10 Rare or rarer fish',g:10,v:fsU6Rare,rw:150},
 {k:'leg',m:'legend',n:'Legend Hunter',d:'Catch a Legendary fish',g:1,v:F=>F.s.leg||0,rw:300},
 {k:'myth',m:'myth',n:'Myth Made Real',d:'Catch a Mythic fish',g:1,v:F=>F.s.myth||0,rw:1000},
 {k:'giant',m:'giant',n:'Tall Tales',d:'Catch 5 Giants',g:5,v:F=>F.s.giant||0,rw:200},
 {k:'run',m:'streak',n:'Unbroken Line',d:'Catch 15 fish in a row',g:15,v:F=>F.s.best||0,rw:200},
 {k:'spots',m:'spots',n:'Wanderer',d:'Catch fish at all three spots',g:3,v:fsU6Spots,rw:200},
 {k:'bty',m:'bounty',n:'Odd-Jobber',d:'Complete 10 daily bounties',g:10,v:F=>(F.bty&&F.bty.tot)||0,rw:200},
 {k:'bst',m:'bounty',n:'Regular at the Board',d:'Finish every bounty 5 days in a row',g:5,v:F=>(F.bty&&F.bty.best)||0,rw:400},
 {k:'creel',m:'creel',n:'Bigger Basket',d:'Upgrade your creel 3 times (Enchanted Creel)',g:3,v:()=>fsCrT(),rw:200},
 {k:'tro',m:'trophy',n:'Hall of Fame',d:'Mount 8 trophies',g:8,v:F=>(F.tro||[]).filter(Boolean).length,rw:150},
 {k:'bait',m:'bait',n:'Tackle Box',d:'Fish 50 casts with bait',g:50,v:F=>F.s.bait||0,rw:100},
 {k:'gold',m:'gold',n:'Fishmonger',d:'Earn 10,000 gold from fish',g:10000,v:F=>F.s.gold||0,rw:400},
 {k:'fast',m:'speed',n:'Lightning Reel',d:'Reel in a fish at 70 WPM',g:70,v:F=>Math.round((F.s.fast||0)*12),rw:200}];
function fsAchP(){const F=fsP();if(!F.ach||typeof F.ach!=='object')F.ach={};return F.ach}
const fsAchCan=()=>{const F=fsP(),A=fsAchP();return FSACH.filter(a=>!A[a.k]&&a.v(F)>=a.g)};
function fsAchClaim(k){const a=FSACH.find(x=>x.k===k),F=fsP(),A=fsAchP();if(!a||A[k]||a.v(F)<a.g)return 0;A[k]=1;P.gold+=a.rw;fsSt('agold',a.rw,'add');save();return a.rw}
/* ---------- the trophy wall: eight mounts for your best catches (each shows that species' record) ---------- */
function fsTroP(){const F=fsP();if(!Array.isArray(F.tro))F.tro=[];while(F.tro.length<8)F.tro.push('');F.tro=F.tro.slice(0,8).map(id=>FISH[id]&&F.b[id]&&F.b[id].n?id:'');return F.tro}
const fsTroScore=id=>{const f=FISH[id],b=fsP().b[id];return FSR[f.r].k*10+(b.big-f.len[0])/(f.len[1]-f.len[0])+(b.g?.5:0)};
function fsTroFill(){const T=fsTroP(),F=fsP(),L=FIDS.filter(id=>F.b[id]&&F.b[id].n&&!T.includes(id)).sort((a,b)=>fsTroScore(b)-fsTroScore(a));let n=0;for(let i=0;i<8;i++)if(!T[i]&&L.length){T[i]=L.shift();n++}save();return n}
const FSTROD=d=>{try{return new Date(d).toLocaleDateString(undefined,{month:'short',day:'numeric',year:'numeric'})}catch(e){return''}};
function fsTrophy(tab){S.mode='fish';S.view='fishtrophy';FS.on=false;if(tab)FSU.ttab=tab;const tb=FSU.ttab||'wall',F=fsP(),T=fsTroP(),can=fsAchCan().length,A=fsAchP();let body='';
 if(tb==='wall')body=`<div class="ftr-wall">${T.map((id,i)=>{if(!id)return `<button class="ftr-m e" data-slot="${i}" aria-label="Empty mount ${i+1}: choose a trophy"><canvas width="300" height="230" aria-hidden="true"></canvas><span class="ftr-np"><b>Empty mount</b><small>Choose a catch to mount</small></span></button>`;
   const f=FISH[id],b=F.b[id];return `<button class="ftr-m r-${f.r}" data-slot="${i}" style="--rc:${FSR[f.r].c}" aria-label="${f.n}, record ${b.big} centimetres. Change trophy"><canvas width="300" height="230" aria-hidden="true"></canvas><span class="ftr-np"><b>${f.n}</b><small><i class="ftr-rd" style="--rc:${FSR[f.r].c}"></i>${FSR[f.r].n} · ${b.big} cm${b.g?' · ♛':''}${b.bigT?` · ${FSTROD(b.bigT)}`:''}</small></span></button>`}).join('')}</div>`;
 else if(tb==='ach')body=`<div class="ftr-al">${FSACH.map(a=>{const v=a.v(F),got=v>=a.g,cl=!!A[a.k],p=Math.min(1,v/a.g);return `<div class="ftr-a${got?' got':''}${cl?' cl':''}"><canvas width="96" height="96" data-med="${a.m}" data-got="${got?1:0}" aria-hidden="true"></canvas><div><b>${a.n}</b><small>${a.d}</small><i class="ftr-ab" aria-hidden="true"><i style="width:${(p*100).toFixed(1)}%"></i></i><span>${Math.min(v,a.g).toLocaleString()} / ${a.g.toLocaleString()}</span></div>${cl?'<em class="ftr-ok">✓ Claimed</em>':got?`<button data-claim="${a.k}">Claim ${fsCoin}${a.rw}</button>`:`<em class="ftr-rw">${fsCoin}${a.rw}</em>`}</div>`}).join('')}</div>`;
 else if(tb==='cur'&&typeof fsCurHTML==='function')body=fsCurHTML();
 else{const s=F.s,B=F.bty||{},cau=s.caught||0,rate=cau?Math.round(cau/Math.max(1,cau+(s.esc||0))*100):0;
  const R=[['Fish caught',cau.toLocaleString(),`${(s.cast||0).toLocaleString()} casts`],['Catch rate',cau?rate+'%':'—',`${(s.esc||0).toLocaleString()} got away`],['Species found',`${fsFound()} / ${FIDS.length}`,'in the Bestiary'],
   ['Legendary · Mythic',`${s.leg||0} · ${s.myth||0}`,'the rarest catches'],['Giants caught',(s.giant||0).toLocaleString(),'the biggest 4%'],['Best streak',(s.best||0).toLocaleString(),'catches in a row'],
   ['Fastest reel',s.fast?Math.round(s.fast*12)+' WPM':'—','typing speed on one catch'],['Gold from fish',(s.gold||0).toLocaleString(),'from selling fish'],['Bounties done',(B.tot||0).toLocaleString(),`best streak ${B.best||0} day${B.best===1?'':'s'}`],
   ['Bounty gold',(s.bgold||0).toLocaleString(),'rewards and board bonuses'],['Bait casts',(s.bait||0).toLocaleString(),'fished with bait'],['Your creel',FSCRT[fsCrT()].n.replace(' Creel',''),`${fsCreelCap()} slots`]];
  const best=FSRK.map(rk=>{const L=FIDS.filter(id=>FISH[id].r===rk&&F.b[id]&&F.b[id].n);if(!L.length)return{rk};const id=L.sort((a,b)=>(F.b[b].big-FISH[b].len[0])/(FISH[b].len[1]-FISH[b].len[0])-(F.b[a].big-FISH[a].len[0])/(FISH[a].len[1]-FISH[a].len[0]))[0];return{rk,id}});
  body=`<div class="ftr-rec"><div class="ftr-rs">${R.map(([a,b,c])=>`<div><small>${a}</small><b>${fsEsc(b)}</b><em>${fsEsc(c)}</em></div>`).join('')}</div>
   <div class="ftr-rb"><h4>Biggest for its kind</h4>${best.map(o=>o.id?`<div class="ftr-rbi" style="--rc:${FSR[o.rk].c}"><canvas width="120" height="64" data-rbi="${o.id}" aria-hidden="true"></canvas><span><small>${FSR[o.rk].n}</small><b>${FISH[o.id].n}</b><em>${F.b[o.id].big} cm · top ${Math.max(1,Math.round((1-(F.b[o.id].big-FISH[o.id].len[0])/(FISH[o.id].len[1]-FISH[o.id].len[0]))*100))}% of its range</em></span></div>`:`<div class="ftr-rbi no" style="--rc:${FSR[o.rk].c}"><span><small>${FSR[o.rk].n}</small><b>None yet</b></span></div>`).join('')}</div></div>`}
 show(`<div class="fsx ftr" id="fsx"><i class="ftr-lamp l" aria-hidden="true"></i><i class="ftr-lamp r" aria-hidden="true"></i>
  <div class="fstr"><span class="fsgold fsg">${fsCoin}<b id="fsgold">${P.gold.toLocaleString()}</b></span><button class="fsback fsg" id="fsback"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 5l-7 7 7 7" stroke="currentColor" stroke-width="2.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>Back <kbd>Esc</kbd></button></div>
  <h2 class="fswh ftr-h">Trophy Hall</h2><p class="ftr-sub">${tb==='wall'?'Mount your finest catches. Each trophy shows your record for that species.':tb==='ach'?'Feats of a true angler. Claim gold for each one.':tb==='cur'?'Odd things the line brought up, and the lighthouse keeper\'s lost pages.':'Every number from the water.'}</p>
  <nav class="ftr-tabs" role="tablist">${[['wall','Trophy Wall'],['ach','Achievements'],['cur','Curios'],['rec','Records']].map(([k,n])=>`<button role="tab" data-ttab="${k}" aria-selected="${tb===k}">${n}${k==='ach'?` <small>${FSACH.filter(a=>A[a.k]).length}/${FSACH.length}</small>${can?'<i class="fshdot">!</i>':''}`:''}</button>`).join('')}</nav>
  ${tb==='wall'?`<button class="ftr-fill" id="ftrfill" ${T.some(x=>!x)&&FIDS.some(id=>F.b[id]&&F.b[id].n&&!T.includes(id))?'':'disabled'}>Fill empty mounts with my best</button>`:tb==='ach'&&can?`<button class="ftr-fill" id="ftrclaim">Claim all · ${fsCoin}${fsAchCan().reduce((a,x)=>a+x.rw,0).toLocaleString()}</button>`:''}
  <section class="ftr-body">${body}</section><div class="fsmod" id="fsmod" hidden></div></div>`,'fshx');
 {const back=FSU.tback||fsHub;S.back=()=>{FSU.tback=null;back()};$('fsback').onclick=S.back}{const cn=$('cn');if(cn)cn.classList.add('dkhid')}
 ov.querySelectorAll('[data-ttab]').forEach(b=>b.onclick=()=>{try{beep(640,.04,'triangle',.12)}catch(e){}fsTrophy(b.dataset.ttab)});
 if(tb==='wall'){ov.querySelectorAll('.ftr-m').forEach(m=>{const i=+m.dataset.slot,id=T[i],cv=m.querySelector('canvas'),g=cv.getContext('2d'),rk=id?FISH[id].r:'c';
   const dr=t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,300,230);fsU6Plaque(g,150,112,280,210,rk,t,!id);if(id)fishFit(g,id,150,112-210*.08,280*.8,210*.55,{t:.4,glow:FSR[rk].k>=2?.35:0})};dr(.5);
   if(id&&FSR[rk].k>=3&&!fsRM())LIVE.push({cv,fn:dr,slow:3,ph:i});m.onclick=()=>fsTroPick(i)});
  const fb=$('ftrfill');if(fb)fb.onclick=()=>{const n=fsTroFill();if(n){fsSfx('buy');fsTrophy('wall')}}}
 else if(tb==='ach'){ov.querySelectorAll('canvas[data-med]').forEach(cv=>{const g=cv.getContext('2d');g.clearRect(0,0,96,96);fsU6Medal(g,cv.dataset.med,48,48,1.1,.4,cv.dataset.got==='1')});
  ov.querySelectorAll('[data-claim]').forEach(b=>b.onclick=()=>{const v=fsAchClaim(b.dataset.claim);if(v){fsSfx('buy');fsTrophy('ach')}});
  const ca=$('ftrclaim');if(ca)ca.onclick=()=>{let v=0;fsAchCan().forEach(a=>v+=fsAchClaim(a.k));if(v){fsSfx('buy');setTimeout(()=>{try{fsSfx('r')}catch(e){}},220);fsTrophy('ach')}}}
 else if(tb==='cur'){if(typeof fsCurBind==='function')fsCurBind()}
 else ov.querySelectorAll('canvas[data-rbi]').forEach(cv=>fsThumb(cv,cv.dataset.rbi,false));
 setTimeout(()=>{const b=ov.querySelector('[data-ttab][aria-selected="true"]');try{b&&b.focus({preventScroll:true})}catch(e){}},60)}
function fsTroPick(i){const F=fsP(),T=fsTroP(),cur=T[i],L=FIDS.filter(id=>F.b[id]&&F.b[id].n).sort((a,b)=>fsTroScore(b)-fsTroScore(a));
 fsU6Modal(`<div class="ftr-pk fsg"><button class="fsx2" id="fsx2" aria-label="Close">✕</button><h3 class="fsu6h">${cur?'Change trophy':'Mount a trophy'}</h3><p class="fsbm-s">Pick a species. The mount shows your record catch, and it updates when you beat it.</p>
  <div class="ftr-pl">${L.length?L.map(id=>{const f=FISH[id],b=F.b[id],on=T.indexOf(id);return `<button class="ftr-pi${id===cur?' cur':''}" data-pick="${id}" style="--rc:${FSR[f.r].c}"><canvas width="150" height="80" aria-hidden="true"></canvas><b>${f.n}</b><small>${b.big} cm${b.g?' · ♛':''}</small>${on>=0?`<em>${id===cur?'On this mount':'On the wall'}</em>`:''}</button>`}).join(''):'<p class="fsempty">Catch a fish first, then mount it here.</p>'}</div>
  ${cur?'<button class="ftr-down" id="ftrdown">Take this trophy down</button>':''}</div>`,'trophy');
 const m=$('fsmod');m.querySelectorAll('[data-pick]').forEach(b=>{const id=b.dataset.pick;fsThumb(b.querySelector('canvas'),id,false);b.onclick=()=>{const j=T.indexOf(id);if(j>=0&&j!==i)T[j]=T[i];T[i]=id;save();fsSfx('buy');fsModal(null);fsTrophy('wall')}});
 const d=$('ftrdown');if(d)d.onclick=()=>{T[i]='';save();fsModal(null);fsTrophy('wall')}}
document.addEventListener('keydown',e=>{if(S.mode!=='fish'||S.view!=='fishtrophy'||e.ctrlKey||e.metaKey||e.altKey)return;const m=$('fsmod');
 if(e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();if(m&&!m.hidden)fsModal(null);else if(S.back)S.back()}},true);
/* ---------- the menu: a bounty strip and bait button under Tonight; the Trophy Hall replaces the Stats tile ---------- */
function fsU6HubHTML(h){const F=fsP(),B=fsBtyGet(),t=fsCrT(),T=fsTroP(),A=fsAchP(),can=fsAchCan().length,st=fsBtyStreak(),dn=B.L.filter(b=>b.done).length;
 const bk=fsBaitP(),K=FSBAIT[bk.on],n=K?bk.inv[bk.on]||0:0;
 const strip=`<div class="fsh6"><button class="fsh6b fsg" id="fsh6b" title="Daily bounties (O)"><canvas width="104" height="88" data-ic="board" aria-hidden="true"></canvas><span class="fsh6t"><b>Daily Bounties <small>${dn} / 3 done</small>${st?`<em>${FSFLAME}${st}-day streak</em>`:''}</b>
  ${B.L.map(b=>{const p=Math.min(1,b.got/b.n);return `<span class="fsh6r${b.done?' ok':''}" style="--bc:${FSBTYD[b.d].c}"><i aria-hidden="true">${b.done?'✓':''}</i><span>${fsEsc(fsBtyShort(b))}</span><u aria-hidden="true"><u style="width:${(p*100).toFixed(1)}%"></u></u><em>${b.done?'Paid':fsCoin+b.rw}</em></span>`}).join('')}</span><i class="fsch">›</i></button>
  <button class="fsh6k fsg${K&&n?' on':''}" id="fsh6k" title="Bait pouch (B)"><canvas width="96" height="96" id="fsh6kc" aria-hidden="true"></canvas><b>Bait</b><small>${K?(n?`${K.n.split(' ')[0]} ×${n}`:'None left'):'None'}</small></button></div>`;
 h=h.replace('<nav class="fsh2tiles">',strip+'<nav class="fsh2tiles">');
 h=h.replace(/<button class="fsh2t2" id="fshs"[\s\S]*?<\/button>/,`<button class="fsh2t2" id="fshs" style="--c:#ffb45a"><canvas width="104" height="88" data-ic="trophy"></canvas><span><b>Trophy Hall</b><small>${T.filter(Boolean).length} / 8 mounted · ${FSACH.filter(a=>A[a.k]).length}/${FSACH.length} feats</small></span><i class="fsch">›</i>${can?'<i class="fshdot">!</i>':''}</button>`);
 if(typeof fsCreelArt==='function')h=h.replace('data-ic="basket"',`data-ic="creel${t}"`);
 h=h.replace(/(<b>Fish Basket<\/b><small>[^<]*<\/small>)/,`$1<small class="fsnx">${FSCRT[t+1]&&P.gold>=FSCRT[t+1].c?`${FSCRT[t].n.replace(' Creel','')} · upgrade ready`:FSCRT[t].n}</small>`);
 return h}
{const s0=show;show=function(h){if(FSU6.hubMod&&typeof h==='string'){FSU6.hubMod=0;try{arguments[0]=fsU6HubHTML(h)}catch(e){console.error(e)}}return s0.apply(this,arguments)}}
{const h0=fsHub;fsHub=function(){FSU6.hubMod=1;let r;try{r=h0.apply(this,arguments)}finally{FSU6.hubMod=0}try{fsU6HubAfter()}catch(e){console.error(e)}return r}}
function fsU6HubAfter(){const s=$('fshs');if(s)s.onclick=()=>fsTrophy();const b=$('fsh6b');if(b)b.onclick=()=>fsBountyModal('hub');const k=$('fsh6k');if(k)k.onclick=()=>fsBaitModal('hub');
 const c=$('fsh6kc');if(c){const g=c.getContext('2d'),B=fsBaitP(),bk=FSBAIT[B.on]?B.on:'none';const dr=t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,96,96);fsU6Bait(g,bk,48,48,.84,t)};dr(.6);if(!fsRM())LIVE.push({cv:c,fn:dr,slow:3,ph:2})}}
/* ---------- Fishing Spots: each new spot shows its one Mythic (a silhouette until you catch it) ---------- */
const fsSpotMyth=k=>(FSPOOL[k]||[]).find(id=>FISH[id].r==='m')||'';
{const c0=fsdgCard;fsdgCard=function(k){let h=c0.apply(this,arguments);try{const id=fsSpotMyth(k);if(id){const b=fsP().b[id],got=!!(b&&b.n);
  h=h.replace(/<\/button>\s*$/,`<span class="fsdg-my${got?' got':''}" title="Only one Mythic lives here: ${got?FISH[id].n:'not found yet'}"><span class="fsdg-myc"><canvas width="96" height="96" data-my="${id}" data-got="${got?1:0}" aria-hidden="true"></canvas>${got?'':'<i aria-hidden="true">?</i>'}</span><em>1 Mythic here</em></span></button>`);
  h=h.replace('aria-label="','aria-label="One Mythic fish lives here. ')}}catch(e){}return h}}
{const p0=fsdgPanel;fsdgPanel=function(){let h=p0.apply(this,arguments);try{const k=FSDG.sel,id=fsSpotMyth(k);if(id){const b=fsP().b[id],got=!!(b&&b.n);
  h=h.replace('class="fsdg-pin2"','class="fsdg-pin2 my"').replace('<button class="fsdg-go"',`<div class="fsdg-myp${got?' got':''}"><span class="fsdg-myc"><canvas width="96" height="96" data-my="${id}" data-got="${got?1:0}" aria-hidden="true"></canvas>${got?'':'<i aria-hidden="true">?</i>'}</span><span class="fsdg-myt"><small>Only one Mythic lives here</small><b>${got?FISH[id].n:'Unknown Mythic'}</b><em>${got?`Caught ×${b.n} · it can bite again`:'Roughly 1 in ${Math.round(100/FSR.m.o)} casts here'}</em></span></div><button class="fsdg-go"`)}}catch(e){}return h}}
function fsdgMyDraw(){ov.querySelectorAll('canvas[data-my]').forEach(cv=>{if(cv.dataset.dn)return;cv.dataset.dn=1;const g=cv.getContext('2d'),got=cv.dataset.got==='1';g.clearRect(0,0,96,96);
 fishFit(g,cv.dataset.my,48,50,90,66,{t:.4,sil:got?0:'#1c0a34',glow:got?.4:0})})}
{const m0=fsMap;fsMap=function(){const r=m0.apply(this,arguments);try{fsdgMyDraw()}catch(e){}return r}}
{const s0=fsdgSelect;fsdgSelect=function(){const r=s0.apply(this,arguments);try{fsdgMyDraw()}catch(e){}return r}}
{const b0=fsdgBindPanel;fsdgBindPanel=function(){const r=b0.apply(this,arguments);try{fsdgMyDraw()}catch(e){}return r}}
/* ---------- styles (static gradients only; animations use transform/opacity) ---------- */
{const st=document.createElement('style');st.textContent=`
.fsu6h{margin:0 0 4px;font:400 40px/1 'Pirata One',Georgia,serif;color:var(--gold);text-shadow:0 3px 0 #1b1024}
@keyframes fsBtPop{0%{transform:scale(1)}30%{transform:scale(1.05)}100%{transform:scale(1)}}
.fsh6{position:absolute;left:48px;top:606px;width:690px;height:108px;display:flex;gap:12px;animation:fsIn .6s .28s var(--sp) both}
.fsh6b{flex:1;min-width:0;display:flex;align-items:center;gap:6px;padding:6px 12px 6px 2px;color:#fff8e8;text-align:left;cursor:pointer;transition:transform .15s}
.fsh6b:hover,.fsh6k:hover{transform:translateY(-3px)}
.fsh6b canvas{flex:none;width:84px;height:71px}
.fsh6t{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}
.fsh6t>b{display:flex;align-items:center;gap:8px;font:800 17px var(--ui)}.fsh6t>b small{font:600 12px var(--ui);color:#c4badf}
.fsh6t>b em{margin-left:auto;display:flex;align-items:center;gap:3px;font:800 12px var(--ui);color:#ffb45a;font-style:normal}.fsh6t>b em svg{width:16px;height:16px}
.fsh6r{display:grid;grid-template-columns:16px 1fr 84px 58px;align-items:center;gap:8px;height:19px;font:600 13px var(--ui);color:#e8e0ff}
.fsh6r>i{width:14px;height:14px;border-radius:50%;border:2px solid var(--bc);font:900 9px/10px var(--ui);text-align:center;font-style:normal;color:#1b1024}
.fsh6r.ok>i{background:var(--bc)}.fsh6r>span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.fsh6r.ok>span{opacity:.6}
.fsh6r>u{display:block;height:7px;border-radius:4px;background:#0a0620;border:1px solid #3a3070;overflow:hidden}.fsh6r>u>u{display:block;height:100%;background:var(--bc)}
.fsh6r>em{display:flex;align-items:center;justify-content:flex-end;gap:3px;font:800 12px var(--ui);color:#ffd45a;font-style:normal;white-space:nowrap}.fsh6r>em svg,.fsh6r>em img{width:13px;height:13px}
.fsh6k{flex:none;width:118px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:0;color:#fff8e8;cursor:pointer;transition:transform .15s}
.fsh6k canvas{width:62px;height:62px}.fsh6k b{font:800 15px var(--ui)}.fsh6k small{font:600 12px var(--ui);color:#c4badf;white-space:nowrap}.fsh6k.on{border-color:#7aff9a}
.fsbt{position:absolute;left:22px;top:140px;width:330px;padding:8px 10px 10px;border-radius:16px;z-index:2;animation:fsIn .5s .2s var(--sp) both}
.fsbt.pop{animation:fsBtPop .6s var(--sp)}.fsbt.all{border-color:#ffd45a99}
.fsbt-h{display:flex;align-items:center;gap:8px;width:100%;padding:0 2px 5px;border:none;background:none;color:#fff8e8;font:800 15px var(--ui);cursor:pointer}
.fsbt-h span{font:700 13px var(--ui);color:#c4badf}.fsbt-h em{display:flex;align-items:center;gap:2px;font:800 13px var(--ui);color:#ffb45a;font-style:normal}.fsbt-h em svg{width:15px;height:15px}
.fsbt-h i{margin-left:auto;font-style:normal;transition:transform .2s}.fsbt.min .fsbt-h i{transform:rotate(-90deg)}.fsbt.min ol{display:none}.fsbt.min .fsbt-h{padding-bottom:0}
.fsbt ol{list-style:none;margin:0;padding:0;display:grid;gap:5px;cursor:pointer}
.fsbt li{position:relative;display:grid;grid-template-columns:16px 1fr auto;align-items:center;gap:7px;padding:4px 8px 6px;border-radius:9px;background:#0b0724b0;font:600 13px var(--ui);color:#e8e0ff;overflow:hidden}
.fsbt li span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.fsbt li span small{color:#a89ed0}.fsbt li b{font:800 12px var(--ui);color:var(--bc)}
.fsbt li u{position:absolute;left:0;bottom:0;height:3px;background:var(--bc)}
.fsbt-d{width:14px;height:14px;border-radius:50%;border:2px solid var(--bc);font:900 9px/10px var(--ui);text-align:center;font-style:normal;color:#1b1024}
.fsbt li.ok .fsbt-d{background:var(--bc)}.fsbt li.ok span{opacity:.6}
.fsbc{position:absolute;left:22px;bottom:96px;width:300px;height:58px;display:flex;align-items:center;gap:8px;padding:0 12px 0 6px;color:#fff8e8;cursor:pointer;text-align:left;border-radius:16px;animation:fsIn .5s .15s var(--sp) both;transition:transform .15s}
.fsbc:hover{transform:translateY(-2px)}.fsbc.on{border-color:#7aff9a}.fsbc canvas{width:48px;height:48px;flex:none}
.fsbc span{display:flex;flex-direction:column;min-width:0}.fsbc b{font:800 14px var(--ui)}.fsbc small{font:600 12px var(--ui);color:#c4badf;white-space:nowrap}.fsbc kbd{margin-left:auto}
.fsbm{position:relative;width:920px;max-height:830px;display:flex;flex-direction:column;padding:20px 22px;animation:fsWb .35s var(--sp) both}
.fsbm-s{margin:0 0 12px;font:500 14px var(--ui);color:#cfc6ee;max-width:820px}
.fsbm-l{display:flex;flex-direction:column;gap:8px;overflow:auto}
.fsbm-r{display:grid;grid-template-columns:96px 1fr auto;align-items:center;gap:14px;padding:8px 12px 8px 8px;border-radius:16px;background:#120c34cc;border:2px solid #3a3070}
.fsbm-r.on{border-color:var(--bc);background:linear-gradient(90deg,color-mix(in srgb,var(--bc) 18%,#120c34),#120c34cc 60%)}.fsbm-r.lk{opacity:.6}
.fsbm-r canvas{width:96px;height:96px}
.fsbm-t b{display:block;font:800 18px var(--ui);color:#fff8e8}.fsbm-t b em{font:700 11px var(--ui);color:var(--bc);padding:2px 7px;border-radius:8px;background:#0a0620;border:1px solid var(--bc);font-style:normal;vertical-align:middle}
.fsbm-t small{display:block;font:500 13px var(--ui);color:#c4badf;margin:2px 0 4px}
.fsbm-have{font:700 13px var(--ui);color:#9affc8}.fsbm-have.no{color:#8a80b0}.fsbm-have i{color:var(--bc);font-style:normal}
.fsbm-b{display:flex;gap:8px;align-items:stretch}
.fsbm-b button{min-width:108px;height:60px;padding:0 12px;border-radius:12px;border:2px solid #1b1024;font:800 15px var(--ui);cursor:pointer;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px;background:linear-gradient(180deg,#ffe27a,#f2b631);color:#3a2006;box-shadow:0 3px 0 #9a6a10;transition:transform .12s}
.fsbm-b button small{font:600 11px var(--ui);opacity:.85;white-space:nowrap}
.fsbm-b button.cr{max-width:170px;background:linear-gradient(180deg,#8ae0ff,#3a8ad8);color:#06203a;box-shadow:0 3px 0 #1a4a8a}.fsbm-b button.cr small{white-space:normal;text-align:center;line-height:1.15}
.fsbm-b button.eq{background:#2a2060;color:#fff;border-color:#5a4ca0;box-shadow:none}.fsbm-b button.eq.on{background:#3a2a10;border-color:#ffd45a;color:#ffd45a}
.fsbm-b button:disabled{background:#2a2450;color:#8a80b0;box-shadow:none;cursor:not-allowed;border-color:#3a3070}.fsbm-b button:not(:disabled):hover{transform:translateY(-2px)}
.fsbm-c{display:flex;align-items:center;gap:4px}.fsbm-b button.cr{min-width:150px}
.fsbm-lk{font:700 13px var(--ui);color:#8a80b0;align-self:center}.fsbm-f{margin:10px 0 0;font:500 13px var(--ui);color:#a89ed0}
.fsbb{position:relative;width:1180px;padding:22px 26px 18px;border-radius:24px;border:3px solid #1b1024;background:repeating-linear-gradient(180deg,#0000 0 62px,#00000030 62px 65px),linear-gradient(180deg,#6e4632,#3e2618);box-shadow:inset 0 0 0 3px #8a5a3a,inset 0 0 0 6px #e6b93e33,0 20px 50px #000c;animation:fsWb .35s var(--sp) both}
.fsbb-hd{display:flex;align-items:center;gap:14px;margin-bottom:14px}.fsbb-hd canvas{width:104px;height:88px;flex:none}.fsbb-hd p{margin:0;font:500 14px var(--ui);color:#f4e4c8;max-width:740px}.fsbb-hd p b{color:#ffd45a}
.fsbb-st{margin-left:auto;margin-right:34px;display:flex;flex-direction:column;align-items:center;padding:8px 18px;border-radius:14px;background:#1b1024cc;border:2px solid #5a3a20;color:#a89a8a}.fsbb-st svg{width:30px;height:30px;opacity:.35}.fsbb-st.on svg{opacity:1}.fsbb-st b{font:800 26px/1.1 var(--ui);color:#fff8e8}.fsbb-st small{font:600 12px var(--ui)}
.fsbb-ns{display:grid;grid-template-columns:repeat(3,1fr);gap:24px;padding:8px 6px 12px}
.fsbb-n{position:relative;display:flex;flex-direction:column;align-items:center;text-align:center;gap:4px;padding:28px 18px 16px;border-radius:6px;background:linear-gradient(180deg,#fbf0d4,#eedbb0);color:#3a2414;transform:rotate(var(--r));box-shadow:0 10px 18px #0008,inset 0 0 30px #c8a06a55;border:2px solid #1b1024}
.fsbb-n.ok{background:linear-gradient(180deg,#eef8e2,#d4e8bc)}
.fsbb-pin{position:absolute;top:-10px;left:50%;width:20px;height:20px;margin-left:-10px;border-radius:50%;background:radial-gradient(circle at 35% 35%,#ff8a8a,#c8203a 60%,#7a1020);border:2px solid #1b1024}
.fsbb-dif{position:absolute;top:10px;left:12px;font:800 11px var(--ui);letter-spacing:.08em;text-transform:uppercase;padding:3px 8px;border-radius:8px;background:#1b1024;color:var(--bc);font-style:normal}
.fsbb-n canvas{width:150px;height:96px}.fsbb-n b{font:400 27px/1.05 'Pirata One',Georgia,serif;color:#3a1a08}.fsbb-n small{font:600 13px var(--ui);color:#6a4a2a}.fsbb-min{font:700 12px var(--ui);color:#8a5a2a}
.fsbb-bar{width:100%;height:12px;margin-top:6px;border-radius:7px;background:#3a241433;border:2px solid #1b1024;overflow:hidden}.fsbb-bar i{display:block;height:100%;background:linear-gradient(90deg,#2ac87a,#7affb4)}
.fsbb-pr{font:800 14px var(--ui);color:#3a2414}.fsbb-rw{display:flex;align-items:center;gap:4px;font:800 18px var(--ui);color:#8a5a00}
.fsbb-ok{position:absolute;right:12px;top:44px;transform:rotate(-14deg);padding:3px 12px;border:3px solid #2a8a4a;border-radius:8px;color:#2a8a4a;font:800 20px var(--ui);letter-spacing:.1em}
.fsbb-sw{position:absolute;right:10px;top:8px;height:26px;padding:0 10px;border-radius:8px;border:2px solid #1b1024;background:#f6e2b0;color:#5a3a1a;font:800 12px var(--ui);cursor:pointer}.fsbb-sw:hover{background:#ffd45a}
.fsbb-ft{display:flex;justify-content:space-between;gap:16px;margin-top:10px;padding:10px 14px;border-radius:12px;background:#1b1024cc;font:600 14px var(--ui);color:#f4e4c8}.fsbb-ft b{color:#ffd45a}
.fscr6{display:flex;align-items:center;gap:10px;padding:6px 10px 6px 4px;margin-bottom:8px;border-radius:16px;background:#120c34cc;border:1.5px solid #3a3070}.fscr6.just{animation:fsBtPop .7s var(--sp)}
.fscr6 canvas{width:112px;height:98px;flex:none}
.fscr6-t{flex:1;display:flex;flex-direction:column;gap:3px;min-width:0}.fscr6-t b{font:400 25px/1 'Pirata One',Georgia,serif;color:var(--gold)}.fscr6-t>span{font:700 14px var(--ui);color:#e8e0ff}.fscr6-t>span.full{color:#ff8a8a}.fscr6-t small{font:600 12px var(--ui);color:#9affc8}
.fscr6-bar{display:block;height:9px;border-radius:5px;background:#0a0620;border:1px solid #3a3070;overflow:hidden}.fscr6-bar i{display:block;height:100%;background:linear-gradient(90deg,#3a8ad8,#7ad8ff)}
.fscr6-up{width:100%;display:flex;align-items:center;justify-content:space-between;gap:10px;padding:8px 12px;margin-bottom:8px;border-radius:14px;border:2px solid #1b1024;background:linear-gradient(180deg,#3a2e80,#241a5c);color:#fff8e8;text-align:left;cursor:pointer;box-shadow:0 3px 0 #120c34;transition:transform .12s}
.fscr6-up span{display:flex;flex-direction:column}.fscr6-up span small{font:600 11px var(--ui);color:#c4badf}.fscr6-up b{font:800 15px var(--ui)}
.fscr6-up em{display:flex;align-items:center;gap:4px;padding:6px 10px;border-radius:10px;background:linear-gradient(180deg,#ffe27a,#f2b631);color:#3a2006;font:800 14px var(--ui);font-style:normal;white-space:nowrap}
.fscr6-up:disabled{cursor:not-allowed;opacity:.6}.fscr6-up:not(:disabled):hover{transform:translateY(-2px)}
.fscr6-max{padding:8px;margin-bottom:8px;border-radius:12px;background:#2a1a08cc;border:1.5px solid #ffd45a66;color:#ffd45a;font:800 14px var(--ui);text-align:center}
.fscr6-lk{font:600 12px var(--ui);color:#8a80b0;padding:4px 2px}
#fsbody .fscr6-so,#fsbody .fscr6-fl{margin:6px 0}#fsbody .fscr6-so button{flex:1 1 calc(25% - 4px)}
.fscr6-sell{display:flex;gap:6px}.fscr6-sell .fssa{flex:1;min-width:0}.fscr6-sell .fscr6-ex{flex:0 0 auto;padding:0 12px;background:linear-gradient(180deg,#d08aff,#8a3ad8);color:#fff;border-color:#1b1024}
.fsx.ftr{background:radial-gradient(60% 45% at 50% 0%,#ffb45a26,#0000 70%),repeating-linear-gradient(180deg,#0000 0 88px,#0000004d 88px 92px),repeating-linear-gradient(90deg,#ffffff05 0 2px,#00000010 2px 11px),linear-gradient(180deg,#4a2c1c,#2a160c 70%,#1a0c06)}
.ftr-lamp{position:absolute;top:110px;width:440px;height:440px;border-radius:50%;background:radial-gradient(circle,#ffc87a30,#ffc87a00 70%);pointer-events:none}.ftr-lamp.l{left:-140px}.ftr-lamp.r{right:-140px}
.ftr-sub{position:absolute;left:66px;top:96px;margin:0;font:600 15px var(--ui);color:#f4e4c8}
.ftr-tabs{position:absolute;left:50%;top:28px;transform:translateX(-50%);display:flex;gap:6px;padding:6px;border-radius:16px;background:#1b1024cc;border:2px solid #5a3a20}
.ftr-tabs button{position:relative;height:44px;padding:0 18px;border-radius:11px;border:none;background:none;color:#e8d8c0;font:800 16px var(--ui);cursor:pointer}.ftr-tabs button[aria-selected=true]{background:linear-gradient(180deg,#ffe27a,#f2b631);color:#3a2006}.ftr-tabs small{font:700 12px var(--ui);opacity:.75}
.ftr-fill{position:absolute;right:48px;top:96px;height:40px;padding:0 16px;border-radius:12px;border:2px solid #1b1024;background:linear-gradient(180deg,#ffe27a,#f2b631);color:#3a2006;font:800 14px var(--ui);cursor:pointer;box-shadow:0 3px 0 #9a6a10;display:flex;align-items:center;gap:4px}.ftr-fill:disabled{background:#3a2a20;color:#a08a70;box-shadow:none;cursor:not-allowed}
.ftr-body{position:absolute;left:48px;right:48px;top:150px;bottom:28px}
.ftr-wall{display:grid;grid-template-columns:repeat(4,1fr);grid-template-rows:repeat(2,1fr);gap:14px 20px;height:100%;padding:16px 22px;border-radius:24px;background:repeating-linear-gradient(90deg,#0000 0 120px,#00000026 120px 123px),linear-gradient(180deg,#5a3624,#3a2014);border:3px solid #1b1024;box-shadow:inset 0 0 0 3px #7a4a2e,inset 0 0 60px #0008}
.ftr-m{position:relative;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:0;border:none;background:none;cursor:pointer;color:#fff8e8;transition:transform .18s}.ftr-m:hover{transform:translateY(-4px)}
.ftr-m canvas{width:300px;height:230px}
.ftr-np{position:relative;margin-top:-46px;display:flex;flex-direction:column;align-items:center;min-width:230px;padding:5px 14px;border-radius:8px;background:linear-gradient(180deg,#f2d27a,#c8962e);border:2px solid #1b1024;box-shadow:0 3px 0 #6a4a10;color:#2a1606}
.ftr-np b{font:400 22px/1.05 'Pirata One',Georgia,serif}.ftr-np small{display:flex;align-items:center;gap:5px;font:700 12px var(--ui);color:#4a2e10}.ftr-rd{width:10px;height:10px;border-radius:50%;background:var(--rc);border:1.5px solid #1b1024}
.ftr-m.e .ftr-np{background:#3a2a20;color:#c8b090;box-shadow:none;border-color:#2a1a10}.ftr-m.e .ftr-np small{color:#a08a70}
.ftr-al{display:grid;grid-template-columns:repeat(3,1fr);gap:9px;height:100%;overflow:auto;padding:2px 6px 2px 2px;align-content:start}
.ftr-a{display:grid;grid-template-columns:62px 1fr auto;align-items:center;gap:12px;padding:5px 12px 5px 8px;border-radius:16px;background:linear-gradient(180deg,#221a5aee,#100a30f4);border:2px solid #3a3070}
.ftr-a canvas{width:62px;height:62px}.ftr-a b{display:block;font:800 16px var(--ui);color:#fff8e8}.ftr-a small{display:block;font:500 12px var(--ui);color:#c4badf}.ftr-a span{font:700 11px var(--ui);color:#a89ed0}
.ftr-ab{display:block;height:7px;margin:5px 0 2px;border-radius:4px;background:#0a0620;border:1px solid #3a3070;overflow:hidden}.ftr-ab i{display:block;height:100%;background:linear-gradient(90deg,#c8803a,#ffd45a)}
.ftr-a.got{border-color:#ffd45a88}.ftr-a.cl{opacity:.8}
.ftr-a button{height:40px;padding:0 12px;border-radius:11px;border:2px solid #1b1024;background:linear-gradient(180deg,#ffe27a,#f2b631);color:#3a2006;font:800 13px var(--ui);display:flex;align-items:center;gap:3px;cursor:pointer;box-shadow:0 3px 0 #9a6a10;white-space:nowrap}
.ftr-ok{font:800 13px var(--ui);color:#7affb4;font-style:normal;white-space:nowrap}.ftr-rw{display:flex;align-items:center;gap:3px;font:700 13px var(--ui);color:#a89ed0;font-style:normal}
.ftr-rec{display:grid;grid-template-columns:1fr 520px;gap:20px;height:100%}
.ftr-rs{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;align-content:start}.ftr-rs div{padding:14px 16px;border-radius:16px;background:linear-gradient(180deg,#221a5aee,#100a30f4);border:2px solid #3a3070;display:flex;flex-direction:column;gap:2px}
.ftr-rs small{font:700 12px var(--ui);color:#c4badf;text-transform:uppercase;letter-spacing:.06em}.ftr-rs b{font:800 26px var(--ui);color:#fff8e8}.ftr-rs em{font:500 12px var(--ui);color:#a89ed0;font-style:normal}
.ftr-rb{align-self:start;padding:14px 16px;border-radius:20px;background:linear-gradient(180deg,#221a5aee,#100a30f4);border:2px solid #3a3070;display:flex;flex-direction:column;gap:8px}.ftr-rb h4{margin:0 0 4px;padding-left:4px;font:400 30px 'Pirata One',Georgia,serif;color:var(--gold)}
.ftr-rbi{display:flex;align-items:center;gap:12px;padding:6px 10px;border-radius:14px;background:#0b0724b8;border-left:4px solid var(--rc)}.ftr-rbi canvas{width:120px;height:64px}.ftr-rbi span{display:flex;flex-direction:column}
.ftr-rbi small{font:800 11px var(--ui);color:var(--rc);text-transform:uppercase;letter-spacing:.06em}.ftr-rbi b{font:800 17px var(--ui);color:#fff8e8}.ftr-rbi em{font:500 12px var(--ui);color:#c4badf;font-style:normal}.ftr-rbi.no{opacity:.55;min-height:64px}
.ftr-pk{position:relative;width:1000px;max-height:800px;display:flex;flex-direction:column;padding:20px 22px;animation:fsWb .35s var(--sp) both}
.ftr-pl{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;overflow:auto;padding:2px}
.ftr-pi{position:relative;display:flex;flex-direction:column;align-items:center;gap:2px;padding:8px 6px;border-radius:14px;border:2px solid #3a3070;background:#120c34cc;color:#fff8e8;cursor:pointer;transition:transform .12s}.ftr-pi:hover{border-color:var(--rc);transform:translateY(-2px)}.ftr-pi.cur{border-color:#ffd45a}
.ftr-pi canvas{width:150px;height:80px}.ftr-pi b{font:800 13px var(--ui)}.ftr-pi small{font:600 12px var(--ui);color:#c4badf}.ftr-pi em{position:absolute;top:6px;right:6px;font:700 10px var(--ui);padding:2px 6px;border-radius:6px;background:#2a1a08;color:#ffd45a;font-style:normal}
.ftr-down{margin-top:12px;align-self:flex-start;height:40px;padding:0 16px;border-radius:12px;border:2px solid #5a4ca0;background:#1c1446;color:#ffb0b0;font:800 14px var(--ui);cursor:pointer}
.fsdg-my{position:absolute;right:14px;top:56px;display:flex;flex-direction:column;align-items:center;gap:4px;z-index:3;pointer-events:none}
.fsdg-myc{position:relative;display:block;flex:none;width:84px;height:84px;border-radius:50%;background:radial-gradient(circle at 50% 40%,#5a1a6a,#200a34 70%);border:3px solid #1b1024;box-shadow:0 0 0 2px #ff5ad8,0 6px 14px #000a}
.fsdg-myc canvas{position:absolute;inset:0;width:100%;height:100%}
.fsdg-myc i{position:absolute;inset:0;display:grid;place-items:center;font:400 46px/1 'Pirata One',Georgia,serif;color:#ff8ae8;text-shadow:0 2px 0 #1b1024;font-style:normal;animation:fsdgMyQ 2.4s ease-in-out infinite}
@keyframes fsdgMyQ{50%{transform:scale(1.1);opacity:.75}}
.fsdg-my em{padding:3px 9px;border-radius:9px;background:linear-gradient(180deg,#ff7ae0,#c82aa8);border:2px solid #1b1024;color:#fff;font:800 11px var(--ui);letter-spacing:.06em;text-transform:uppercase;font-style:normal;white-space:nowrap;box-shadow:0 3px 0 #6a0a5a}
.fsdg-my.got .fsdg-myc,.fsdg-myp.got .fsdg-myc{box-shadow:0 0 0 2px #ffd45a,0 6px 14px #000a}
.fsdg-pin2.my{grid-template-columns:132px 1fr auto auto;gap:22px}.fsdg-pin2.my .fsdg-prow .fsdg-bar{width:300px}.fsdg-pin2 .fsdg-myc canvas{width:100%;height:100%;border:none;border-radius:0;box-shadow:none}
.fsdg-myp{display:flex;align-items:center;gap:10px;flex:none}.fsdg-myp .fsdg-myc{width:72px;height:72px}.fsdg-myp .fsdg-myc i{font-size:38px}
.fsdg-myt{display:flex;flex-direction:column;max-width:220px}.fsdg-myt small{font:800 11px var(--ui);color:#ff8ae8;letter-spacing:.06em;text-transform:uppercase}.fsdg-myt b{font:800 17px var(--ui);color:#fff8e8}.fsdg-myt em{font:500 12px var(--ui);color:#c4badf;font-style:normal}
@media (prefers-reduced-motion:reduce){.fsdg-myc i,.fsbt.pop,.fscr6.just{animation:none}}
`;document.head.appendChild(st)}
