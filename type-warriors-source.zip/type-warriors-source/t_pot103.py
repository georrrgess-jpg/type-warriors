# python3 t_pot103.py [game.html] : Runestone Tower Defense 10.3, Potions (99h data / save, 99i art, 99j battle + Witch’s Cauldron; prefix rppt).
# Every potion's effect measured (Fury on all 14 towers, Quicksilver on all 14, Frostbite, Dragonfire + burning ground, Mending, Hourglass,
# Gilded, Seer's fog / hiding / range), the limits (three slots, one use each, the shared cooldown, the first 10 s of wave 1, no stacking,
# stock spent on use, won or lost), the interaction rules (hidden, fog, bosses, slow-immune venting golems, jams, Overcharge, the Starfall
# mark), damage booked as potions (meter, results "Potions" bar, not on a tower, not unattributed), the results line and the Championship
# satchel mark, stock / brewing with coins (also with the 98t / 98v guard enforced: window.TW_AC_TEST), unlocks, the first-time gift, save
# repair, the satchel (add, remove, drag), Rune Typing words, first-time tips, How to Play, DEV cheats, reduced motion / Performance mode,
# keyboard and click, UI fit at 1600x900 / 1280x720 / 1024x640 (tools/td/rpu_ovl.js on the HUD, the Witch’s Cauldron, results, How to Play),
# frame cost and no page errors. Screenshots in shots/w103_pot/.
import asyncio,os,sys,json
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
TD=os.path.join(HERE,'..','tools','td')
OVL=open(os.path.join(TD,'rpu_ovl.js')).read()
SHOTS=os.path.join(HERE,'shots','w103_pot');os.makedirs(SHOTS,exist_ok=True)
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:900]),flush=True)
    if not ok:FAIL.append(name)
SETUP="()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const r=RPP();r.new99j=1;r.dragon=1;r.stars=%s;r.opt=r.opt||{};delete r.opt.auto;r.opt.ty=0;for(const k in r.tut)r.tut[k]=1;for(const k of ['build','wave','coins','upgrade','abil','rune','potbelt','potthrow','twist_moss','twist_wreck','twist_ember','twist_coral','twist_abyss','twist_storm','twist_foundry','twist_meadow','twist_frost','twist_wonder'])r.tut[k]=1;r.pot={gift:1,seen:1,tip:{belt:1,throw:1}};save()}"
ALL="{moss:3,frost:3,ember:3,coral:3,wreck:2,abyss:3,meadow:1,foundry:3,storm:2,wonder:0}"
HELP=r"""()=>{const seed=s=>{let a=s>>>0;Math.random=function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}};
 window.__p={M0:Math.random,seed,
 pot(st,sat){const p=rpptSave();p.st=Object.assign({},st);p.sat=sat.slice();p.gift=1;p.seen=1;p.tip={belt:1,throw:1};save();return p},
 start(m,st,sat){if(st)this.pot(st,sat||['','','']);rpStart(m);const R=RPX;R.tut=null;R.tutQ=[];return R},
 open(R){R.pt.w1=-1e9;R.pt.cd=0},
 run(R,s,dt){dt=dt||1/30;for(let i=0;i<s/dt;i++){rpStep(R,dt);if(R.wst==='done'||R.over)break}},
 near(R,n){return R.pads.slice().sort((a,b)=>R.G.dRoad(a.x,a.y)-R.G.dRoad(b.x,b.y)).slice(0,n)},
 build(R,p,t,tier){R.supply=1e9;if(p.tw)rpSell(p.tw);R.supply=1e9;rpBuild(p,t);p.tw.build=1;while(p.tw.tier<(tier||1)){R.supply=1e9;rpUpgrade(p.tw);p.tw.upK=1}return p.tw},
 roadS(R,x,y,pi){pi=pi||0;let best=0,bd=1e18;const L=rpLen(R,{pi});for(let s=0;s<L;s+=4){const q=rpAt(R.G,s,pi);const d=rpD2(q.x,q.y,x,y);if(d<bd){bd=d;best=s}}return best},
 /* a monster parked on road pi at distance s (no movement unless sp is given) */
 mob(R,id,s,pi,o){const e=rpSpawn(id,pi||0);e.s=s;e._s=-1;e.sp=o&&o.sp!=null?o.sp:0;if(o&&o.hp){e.hp=e.mx=o.hp}if(o&&o.armor!=null)e.armor=o.armor;return e},
 pos(R,e){e._s=-1;return rpPos(R,e)},
 /* a tower alone against six still dummies for 30 s: total damage booked (99e meter) */
 duel(t,fx){seed(7);const R=this.start('moss');R.supply=1e9;const p=this.near(R,1)[0];this.build(R,p,t,3);rpWaveStart();R.q=[];R.foes=[];const s0=this.roadS(R,p.x,p.y);
  for(let i=0;i<6;i++){const e=this.mob(R,i%3===2&&RP_TW[t].air&&!RP_TW[t].ground?'gloom':'golem',s0-30+i*12,0,{hp:1e7,armor:0})}
  if(fx)R.pt.fx[fx]={t:0,d:1e9,n:0};const T0=R.rpqTot||0;for(let i=0;i<30*30;i++){rpStep(R,1/30);for(const e of R.foes)e.sp=0}const d=(R.rpqTot||0)-T0;rpLeave();Math.random=this.M0;return d},
 key(k){window.dispatchEvent(new KeyboardEvent('keydown',{key:k,bubbles:true}));window.dispatchEvent(new KeyboardEvent('keyup',{key:k,bubbles:true}))},
 sleep(ms){return new Promise(r=>setTimeout(r,ms))}};return 1}"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        pg.on('console',lambda m:er.append('console: '+m.text[:300]) if m.type=='error' and 'TUNNEL' not in m.text and 'WebSocket' not in m.text and 'net::' not in m.text else None)
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate;await E(OVL);await E(HELP);await E(SETUP%ALL)
        shot=lambda n:pg.screenshot(path=os.path.join(SHOTS,n+'.png'))
        # ================= data, unlocks, save repair =================
        r=await E("""()=>{const out={};out.order=RPPT_ORDER.slice();out.kinds=RPPT_ORDER.map(k=>RPPD[k].kind);out.cost=RPPT_ORDER.map(k=>RPPD[k].cost);
          const r=RPP(),s0=JSON.stringify(r.stars);const op=()=>RPPT_ORDER.filter(rpptOpen);
          r.stars={};out.o0=op();r.stars={moss:3,frost:3};out.o6=op();r.stars={moss:3,frost:3,ember:3,wonder:0,coral:3};out.o12=op();
          r.stars={moss:3,frost:3,ember:3,coral:3,wreck:3,abyss:1};out.o16=op();r.stars={moss:3,frost:3,ember:3,coral:3,wreck:3,abyss:3};out.o18=op();
          r.stars={moss:1};out.why=[rpptLockWhy('fire'),rpptLockWhy('gild'),rpptLockWhy('seer')];r.stars=JSON.parse(s0);out.x=[RPPTX.slots,RPPTX.cap,RPPTX.cd,RPPTX.lock];return out}""")
        chk('eight potions in the plan\'s order, drinks and throws, brew costs; unlocks: Fury / Quicksilver / Frostbite from the start, Dragonfire at 6 stars, Mending at 12, Hourglass at 18, Gilded with World 2, Seer\'s with World 3; lock reasons; three slots, cap 5, 20 s cooldown, 10 s lock',
            r['order']==['fury','quick','frost','fire','mend','hour','gild','seer'] and r['kinds']==['drink','drink','throw','throw','drink','drink','drink','drink']
            and r['o0']==['fury','quick','frost'] and r['o6']==['fury','quick','frost','fire'] and r['o12']==['fury','quick','frost','fire','mend','gild'] and 'hour' not in r['o16'] and 'seer' in r['o16'] and r['o18']==r['order']
            and 'stars' in r['why'][0] and 'World 2' in r['why'][1] and 'World 3' in r['why'][2] and r['x']==[3,5,20,10],r)
        r=await E("""()=>{const r=RPP(),out=[];const t=v=>{r.pot=v;const p=rpptSave();return JSON.stringify([p.st,p.sat,p.gift,p.seen,Object.keys(p).sort()])};
          out.push(t(5),t(null),t([1,2]),t({st:{fury:7,quick:-2,frost:'x',fire:2.7,bogus:3},sat:'fury',gift:'yes',seen:2,junk:1}),t({st:{fury:2},sat:['fury','nope',3,'seer','quick'],tip:{a:1,b:'x'},n:{fury:-1,quick:4}}));
          const s0=JSON.stringify(r.stars);r.stars={moss:1};r.pot={st:{hour:2},sat:['hour','fury','']};const p=rpptSave();out.push(JSON.stringify(p.sat),p.st.hour);r.stars=JSON.parse(s0);r.pot={gift:1,seen:1,tip:{belt:1,throw:1}};save();return out}""")
        chk('save repair (P.rp.pot): a number, null or an array become a clean record; stock clamped to 0..5 (7 -> 5, negatives / text dropped, 2.7 -> 2, unknown potions dropped), a satchel that is not three known kinds becomes three slots, gift / seen only 1, unknown keys removed; a locked potion leaves the satchel but keeps its stock',
            json.loads(r[0])[1]==['','',''] and json.loads(r[3])[0]=={'fury':5,'fire':2} and json.loads(r[3])[1]==['','',''] and json.loads(r[3])[2]==0 and json.loads(r[3])[3]==0 and 'junk' not in json.loads(r[3])[4]
            and json.loads(r[4])[1]==['fury','','',] and json.loads(r[5])==['','fury',''] and r[6]==2,r)
        # ================= brewing with coins =================
        r=await E("""()=>{const out=[];P.gold=1000;const p=__p.pot({},['','','']);out.push(rpptBrew('fury'),P.gold,rpptStock('fury'),p.b.fury,p.c);
          p.st.quick=5;out.push(rpptBrew('quick'),P.gold,rpptCanBrew('quick').why);P.gold=200;out.push(rpptBrew('frost'),P.gold,rpptCanBrew('frost').why);
          const s0=JSON.stringify(RPP().stars);RPP().stars={};P.gold=5000;out.push(rpptBrew('fire'),P.gold,rpptCanBrew('fire').why);RPP().stars=JSON.parse(s0);return out}""")
        chk('brewing: 300 coins for a Fury Draught (coins 1000 -> 700, stock +1, counted as brewed and spent); refused at the cap of 5, without the coins, and while locked (coins unchanged), each with its reason',
            r[0] is True and r[1]==700 and r[2]==1 and r[3]==1 and r[4]==300 and r[5] is False and r[6]==700 and 'full' in r[7] and r[8] is False and r[9]==200 and 'coins' in r[10] and r[11] is False and r[12]==5000 and 'stars' in r[13],r)
        # ================= the Witch’s Cauldron: gift, hold-to-brew, satchel =================
        r=await E("""async()=>{const r=RPP();r.pot={};P.gold=3000;rampartsMenu(title);await __p.sleep(300);const btn=document.getElementById('rphpt');const badge=btn&&btn.querySelector('.rpptnew');btn.click();await __p.sleep(900);
          const g=document.querySelector('.rpptgift');return [!!btn,!!badge,!!g,g&&g.textContent.includes('Fury Draught')&&g.textContent.includes('Frostbite Flask'),rpptSave().seen]}""")
        await shot('apothecary_gift')
        chk('the hub has an Witch’s Cauldron button with a "Gift" badge; opening it the first time shows the gift card (Fury Draught and Frostbite Flask)',all(r[:4]) and r[4]==1,r)
        r=await E("""async()=>{document.getElementById('rpptgo').click();await __p.sleep(600);const p=rpptSave();return [p.gift,p.st.fury,p.st.frost,JSON.stringify(p.sat),!!document.querySelector('.rpptgift'),[...document.querySelectorAll('.rpptslot:not(.empty)')].length]}""")
        chk('"Take them": one Fury Draught and one Frostbite Flask in stock and in the satchel, the gift is taken once, the card closes',r[0]==1 and r[1]==1 and r[2]==1 and json.loads(r[3])[:2]==['fury','frost'] and not r[4] and r[5]==2,r)
        await shot('apothecary')
        r=await E("""async()=>{const b=document.querySelector('.rpptbrew[data-k="quick"]'),q=b.getBoundingClientRect();return [q.left+q.width/2,q.top+q.height/2,P.gold]}""")
        await pg.mouse.move(r[0],r[1]);await pg.mouse.down();await pg.wait_for_timeout(300);await pg.mouse.up();await pg.wait_for_timeout(200)
        a=await E("()=>[rpptStock('quick'),P.gold]")
        await pg.mouse.move(r[0],r[1]);await pg.mouse.down();await pg.wait_for_timeout(520)
        mid=await E("()=>[RPPTA.u,document.getElementById('rpptbl').classList.contains('on'),document.querySelector('.rpptbrew[data-k=\"quick\"]').classList.contains('hold')]")
        await shot('brewing')
        await pg.wait_for_timeout(560);await pg.mouse.up();await pg.wait_for_timeout(500)
        await shot('brewed')
        c=await E("()=>[rpptStock('quick'),P.gold,document.getElementById('rpptg').textContent]")
        await pg.wait_for_timeout(800)
        d=await E("()=>[document.querySelector('.rpptstk[data-k=\"quick\"] em').textContent]")
        chk('hold-to-brew: a 0.3 s press brews nothing; holding fills the button, lights the "Brewing" label and boils the cauldron in the potion\'s colour, and after 0.9 s a Quicksilver Tonic is brewed for 300 coins (stock 0 -> 1, the coin chip updates, the card shows 1 / 5)',
            a==[0,r[2]] and mid[0]>.3 and mid[1] and mid[2] and c[0]==1 and c[1]==r[2]-300 and c[2]==f"{r[2]-300:,}" and d[0]=='1 / 5',[a,mid,c,d,r[2]])
        r=await E("""async()=>{const b=document.querySelector('.rpptbrew[data-k="frost"]');b.focus();b.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',bubbles:true}));await __p.sleep(1150);b.dispatchEvent(new KeyboardEvent('keyup',{key:'Enter',bubbles:true}));await __p.sleep(200);return [rpptStock('frost')]}""")
        chk('keyboard: holding Enter on a focused Brew button brews (Frostbite 1 -> 2)',r[0]==2,r)
        r=await E("""async()=>{const out=[];document.querySelector('.rpptslot[data-i="0"]').click();await __p.sleep(100);out.push(JSON.stringify(rpptSave().sat));
          document.querySelector('.rpptadd[data-k="quick"]').click();await __p.sleep(100);out.push(JSON.stringify(rpptSave().sat));out.push(document.querySelector('.rpptin[data-k="quick"]').textContent);
          out.push(!document.querySelector('.rpptcard[data-k="seer"] .rpptadd')===!rpptOpen('seer'));return out}""")
        chk('the satchel: clicking a filled slot empties it, + adds a potion to the first empty slot, the card shows "In satchel"',json.loads(r[0])==['','frost',''] and json.loads(r[1])==['quick','frost',''] and r[2]=='In satchel' and r[3],r)
        # drag the Fury bottle onto slot 3
        r=await E("""()=>{const a=document.querySelector('.rpptcard[data-k="fury"] .rpptart').getBoundingClientRect(),s=document.querySelector('.rpptslot[data-i="2"]').getBoundingClientRect();return [a.left+a.width/2,a.top+a.height/2,s.left+s.width/2,s.top+s.height/2]}""")
        await pg.mouse.move(r[0],r[1]);await pg.mouse.down();await pg.mouse.move(r[0]+40,r[1]+40,steps=4);await pg.mouse.move(r[2],r[3],steps=8);await pg.wait_for_timeout(120)
        await shot('satchel_drag')
        await pg.mouse.up();await pg.wait_for_timeout(300)
        r=await E("()=>JSON.stringify(rpptSave().sat)")
        chk('dragging the Fury Draught\'s bottle onto the third slot puts it there',json.loads(r)==['quick','frost','fury'],r)
        await shot('satchel')
        # locked cards on a fresh-ish save
        r=await E("""async()=>{const s0=JSON.stringify(RPP().stars);RPP().stars={moss:3,frost:1};rpptShop();await __p.sleep(500);const L=[...document.querySelectorAll('.rpptcard.lock')].map(c=>[c.dataset.k,c.querySelector('.rpptlk').textContent.trim()]);const o=__rpuOvl(document.getElementById('rpptx'));RPP().stars=JSON.parse(s0);return [L,o]}""")
        await shot('apothecary_locked')
        chk('locked potions show their reason ("Earn 6 stars to unlock (you have 4)", World 2 / World 3) and no + or Brew button',[x[0] for x in r[0]]==['fire','mend','hour','gild','seer'] and 'you have 4' in r[0][0][1] and 'World 2' in r[0][3][1] and not r[1],r)
        # ================= battle: belt, locks, cooldown, one use =================
        r=await E("""()=>{const R=__p.start('moss',{},['','','']);const a=!!document.getElementById('rpptb');rpLeave();const R2=__p.start('moss',{fury:2,frost:1,hour:1},['fury','frost','hour']);const b=document.getElementById('rpptb');
          return [a,!!b,b?b.querySelectorAll('.rppts').length:0,b?[...b.querySelectorAll('kbd')].map(k=>k.textContent).join(''):'',R2.pt.sl.map(s=>s.k).join(',')]}""")
        chk('the belt appears only when the satchel holds potions: three bottles with the keys 4 5 6',r[0] is False and r[1] and r[2]==3 and r[3]=='456' and r[4]=='fury,frost,hour',r)
        r=await E("""()=>{const R=RPX;const out=[];out.push(rpptUse(0),rpptWhy(R,0));rpWaveStart();__p.run(R,5);out.push(rpptUse(0),rpptWhy(R,0));__p.run(R,5.2);out.push(rpptWhy(R,0),rpptUse(0),rpptSave().st.fury,R.pt.cd);
          out.push(rpptUse(2),rpptWhy(R,2));__p.run(R,10);out.push(rpptUse(2));__p.run(R,10.1);out.push(rpptWhy(R,2),rpptUse(2),rpptSave().st.hour||0);R.pt.cd=0;out.push(rpptUse(0),rpptWhy(R,0));return out}""")
        chk('rules: no potion before wave 1 or in its first 10 s ("Potions open in 5 s"), then Fury works (stock 2 -> 1, 20 s cooldown); the Hourglass is refused 10 s later ("ready in 10 s") and works after 20 s; a used slot cannot be used again',
            r[0] is False and 'wave 1' in r[1] and r[2] is False and ('open in 5' in r[3] or 'open in 6' in r[3]) and r[4]=='' and r[5] is True and r[6]==1 and r[7]==20 and r[8] is False and 'ready in 20' in r[9]
            and r[10] is False and r[11]=='' and r[12] is True and r[13]==0 and r[14] is False and 'already used' in r[15],r)
        r=await E("""()=>{const R=RPX;const u=R.pt.used.slice();rpLeave();return [u,rpptSave().st.fury,rpptSave().st.hour||0,rpptSave().n.fury,rpptSave().n.hour]}""")
        chk('potions are spent the moment they are used: after leaving the battle the stock stays down (Fury 2 -> 1, Hourglass 1 -> 0) and the use counts are kept',r[0]==['fury','hour'] and r[1]==1 and r[2]==0 and r[3]>=1 and r[4]>=1,r)
        r=await E("""()=>{const R2=__p.start('moss',{fury:1},['fury','','']);rpWaveStart();__p.run(R2,2);rpqWvCall(true);const w=R2.wave,why=rpptWhy(R2,0);__p.run(R2,8.2);const ok=rpptUse(0);rpLeave();
          /* back to the first battle's state for the next check */return [w,why,ok]}""")
        chk('calling wave 2 early does not lift the lock: still "Potions open in 8 s" on wave 2, usable 10 s after wave 1 began',r[0]==2 and 'open in 8' in r[1] and r[2] is True,r)
        r=await E("""()=>{const R=__p.start('moss',{fury:1,frost:1},['fury','fury','frost']);return [R.pt.sl.map(s=>s.empty?(s.short?'short':'empty'):s.k),document.querySelectorAll('#rpptb .rppts.short').length]}""")
        chk('two slots of one kind need two in stock: with one Fury Draught the second Fury slot shows "None left"',r[0]==['fury','short','frost'] and r[1]==1,r)
        # ================= effects =================
        r=await E("""()=>{const out={};for(const t of RP_TWORDER){const a=__p.duel(t,null),b=__p.duel(t,'fury');out[t]=+(b/a).toFixed(3)}return out}""")
        chk(f'Fury Draught: every one of the {len(r)} towers deals +25% damage (alone against still dummies for 30 s; ratios {r})',len(r)>=14 and all(1.23<=v<=1.27 for v in r.values()),r)
        r=await E("""()=>{const out={};for(const t of RP_TWORDER){if(t==='tide')continue;const a=__p.duel(t,null),b=__p.duel(t,'quick');out[t]=+(b/a).toFixed(3)}
          /* the Tidecaller pushes still targets out of its reach: count its jets against walking monsters instead */
          const jets=fx=>{__p.seed(7);const R=__p.start('moss');const p=__p.near(R,1)[0];__p.build(R,p,'tide',3);rpWaveStart();R.q=[];R.foes=[];const s0=__p.roadS(R,p.x,p.y);for(let i=0;i<6;i++)__p.mob(R,'golem',s0-200-i*40,0,{hp:1e7,sp:20});
            if(fx)R.pt.fx[fx]={t:0,d:1e9,n:0};let J=0;for(let i=0;i<30*30;i++){rpStep(R,1/30);if(p.tw.rel===1){J++;p.tw.rel=.999}}rpLeave();Math.random=__p.M0;return J};
          out.tide_jets=+(jets('quick')/Math.max(1,jets(null))).toFixed(3);return out}""")
        chk(f'Quicksilver Tonic: every tower fires about 30% faster (damage in 30 s; the Tidecaller\'s jets against walking monsters; {r})',len(r)>=14 and all(1.15<=v<=1.45 for v in r.values()),r)
        r=await E("""()=>{const R=__p.start('moss',{quick:1},['quick','','']);const p=__p.near(R,1)[0];const tw=__p.build(R,p,'ballista',2);rpWaveStart();__p.open(R);rpptUse(0);
          tw.jam=2;tw.jamBy='ink';let t=0;while(tw.jam>0&&t<5){rpStep(R,1/30);t+=1/30}const jamT=+t.toFixed(2);tw.over=6;const o0=tw.over;for(let i=0;i<60;i++)rpStep(R,1/30);const over=+(o0-tw.over).toFixed(2);rpLeave();return [jamT,over]}""")
        chk('Quicksilver and the rules: a jam runs its normal length (2 s jam ends after 2 s, not sooner) and Overcharge keeps its own length (2 s of game time take 2 s off it)',abs(r[0]-2)<.1 and abs(r[1]-2)<.05,r)
        r=await E("""()=>{const R=__p.start('moss',{frost:3},['frost','frost','frost']);rpWaveStart();R.q=[];R.foes=[];__p.open(R);const s0=600;const P0=rpAt(R.G,s0,0);
          const near=__p.mob(R,'golem',s0,0,{sp:40}),edge=__p.mob(R,'scamp',s0+60,0,{sp:40}),far=__p.mob(R,'golem',s0+260,0,{sp:40}),air=__p.mob(R,'gloom',s0-40,0,{sp:40}),boss=__p.mob(R,'behemoth',s0+20,0,{sp:40}),
           hid=__p.mob(R,'scamp',s0-20,0,{sp:40});hid.hide=1;const st=__p.mob(R,'golem',s0+10,0,{sp:40});st.vent=3;
          const q0=__p.pos(R,edge),d=Math.sqrt(rpD2(q0.x,q0.y,P0.x,P0.y));const c=__p.pos(R,near);const ok=rpptUse(0,{x:c.x,y:c.y});const S=[near,edge,far,air,boss,hid,st].map(e=>e.s);
          __p.run(R,RPPTX.fly+.02);const S1=[near,edge,far,air,boss,hid,st].map(e=>e.s);__p.run(R,RPPD.frost.dur-.2);const S2=[near,edge,far,air,boss,hid,st].map(e=>e.s);const z=[near,edge,far,air,boss,hid,st].map(e=>+(e.stun||0).toFixed(2));
          const bossK=boss.slowK;__p.run(R,.7);const S3=[near,edge,far,air,boss,hid,st].map(e=>e.s);hid.hide=0;st.vent=0;const mv=(a,b)=>a.map((v,i)=>Math.round(b[i]-v));R.pt.cd=0;rpLeave();
          return {ok,d:Math.round(d),frozen:mv(S1,S2),after:mv(S2,S3),bossK,z}}""")
        fz=r['frozen'];af=r['after']
        chk(f'Frostbite Flask: monsters within its radius (ground and flying) freeze for its time and walk again after; one beyond it keeps walking; a boss is slowed by half instead of frozen; a hidden monster and a venting (slow-immune) Steam Golem are not frozen',
            r['ok'] and fz[0]==0 and fz[1]==0 and fz[3]==0 and fz[2]>50 and 0<fz[4]<fz[2] and abs(r['bossK']-.5)<1e-6 and fz[5]>50 and fz[6]>50 and af[0]>0 and af[1]>0,r)
        r=await E("""()=>{const R=__p.start('moss',{fire:2},['fire','fire','']);const tw=__p.build(R,__p.near(R,1)[0],'ballista',1);rpWaveStart();R.q=[];R.foes=[];__p.open(R);const s0=700;
          const a=__p.mob(R,'golem',s0,0,{hp:5000,armor:10}),b=__p.mob(R,'golem',s0+30,0,{hp:5000}),c=__p.mob(R,'golem',s0+260,0,{hp:5000}),fly=__p.mob(R,'gloom',s0-10,0,{hp:5000}),hid=__p.mob(R,'golem',s0+5,0,{hp:5000});hid.hide=1;
          const P=__p.pos(R,a);const D0=tw.rpqD||0,U0=R.rpqUn||0,T0=R.rpqTot||0;rpptUse(0,{x:P.x,y:P.y});__p.run(R,RPPTX.fly+.04);const blast=[a,b,c,fly,hid].map(e=>Math.round(e.mx-e.hp));
          __p.run(R,5.2);const tot=[a,b,c,fly,hid].map(e=>Math.round(e.mx-e.hp));hid.hide=0;const sum=tot.reduce((x,y)=>x+y,0);
          const out={blast,tot,dmg:Math.round(R.pt.dmg),sum,tw:Math.round((tw.rpqD||0)-D0),un:Math.round((R.rpqUn||0)-U0),rpqTot:Math.round((R.rpqTot||0)-T0)};rpLeave();return out}""")
        chk('Dragonfire Bomb: 260 damage to every monster within 90 px (through armor, ground and flying), none beyond 90 px or to a hidden one; then the ground burns 5 s at 40 per s on ground monsters only (about 200 more); all of it is booked as potion damage, none on a tower or unattributed, and the meter\'s total includes it',
            all(260<=x<=266 for x in r['blast'][:2]) and r['blast'][2]==0 and r['blast'][3]==260 and r['blast'][4]==0 and 180<=r['tot'][0]-260<=210 and 180<=r['tot'][1]-260<=210 and r['tot'][3]==260 and r['tot'][4]==0
            and abs(r['dmg']-r['sum'])<=1 and r['tw']==0 and r['un']==0 and abs(r['rpqTot']-r['sum'])<=1,r)
        r=await E("""()=>{const R=__p.start('moss',{mend:3},['mend','mend','mend']);rpWaveStart();R.q=[];R.foes=[];__p.open(R);R.hp=10;const ok=rpptUse(0);const h=[];for(let i=0;i<6;i++){__p.run(R,1);h.push(R.hp)}
          R.pt.cd=0;R.hp=18;rpptUse(1);__p.run(R,6);const cap=R.hp;R.pt.cd=0;const full=rpptUse(2),why=rpptWhy(R,2),st=rpptSave().st.mend;rpLeave();return [ok,h,cap,full,why,st]}""")
        chk('Elixir of Mending: +1 health per second for 5 s (10 -> 15), never above the maximum (18 -> 20), refused at full health (and not spent)',r[0] and r[1]==[11,12,13,14,15,15] and r[2]==20 and r[3] is False and 'full health' in r[4] and r[5]==1,r)
        r=await E("""()=>{const R=__p.start('moss',{hour:1},['hour','','']);rpWaveStart();R.q=[];R.foes=[];__p.open(R);const mk=(id,s)=>{const e=__p.mob(R,id,s,0);e.sp=RP_FOE[id].sp;return e};
          const a=mk('scamp',200),boss=mk('behemoth',100),air=mk('gloom',300),slow=mk('scamp',400),st=mk('golem',500),hid=mk('scamp',600);hid.hide=1;
          const L=[a,boss,air,slow,st,hid];const run=s=>{const s0=L.map(e=>e.s);for(let i=0;i<s*30;i++){slow.slowK=.5;slow.slowT=1;st.vent=1;rpStep(R,1/30)}return L.map((e,i)=>(e.s-s0[i])/s)};
          const v0=run(1);rpptUse(0);const v1=run(2);__p.run(R,RPPD.hour.dur-2+.2);const v2=run(1);hid.hide=0;rpLeave();const k=v1.map((v,i)=>+(v/v0[i]).toFixed(3)),k2=v2.map((v,i)=>+(v/v0[i]).toFixed(3));return {k,k2,K:RPPD.hour.k,B:RPPD.hour.bossK}}""")
        k=r['k'];k2=r['k2']
        chk(f"Hourglass Brew: every visible monster (ground and flying) moves {round(r['K']*100)}% slower for its time, a boss half as much;"+' a stronger slow (50%) is kept; a venting golem and a hidden monster are not slowed; speed is back afterwards',
            abs(k[0]-(1-r['K']))<.03 and abs(k[1]-(1-r['K']*r['B']))<.03 and abs(k[2]-(1-r['K']))<.03 and abs(k[3]-1)<.03 and abs(k[4]-1)<.03 and abs(k[5]-1)<.03 and all(abs(x-1)<.03 for x in k2),r)
        r=await E("""()=>{const R=__p.start('moss',{gild:1},['gild','','']);rpWaveStart();R.q=[];R.foes=[];__p.open(R);const e1=__p.mob(R,'scamp',500,0),e2=__p.mob(R,'golem',520,0);
          let s0=R.supply,c0=R.coins;rpKillFoe(e1,null);const base=[R.supply-s0,R.coins-c0,e1.bounty,e1.coin];rpptUse(0);s0=R.supply;c0=R.coins;rpKillFoe(e2,null);const g=[R.supply-s0,R.coins-c0,e2.bounty,R.pt.gold,e2.coin];
          __p.run(R,RPPD.gild.dur+.1);const e3=__p.mob(R,'golem',540,0);s0=R.supply;rpKillFoe(e3,null);const after=R.supply-s0;rpLeave();return {base,g,after,b3:e3.bounty,K:RPPD.gild.k}}""")
        chk(f"Gilded Tonic: while it works a kill pays its supply bounty x{1+r['K']} (coins unchanged); afterwards back to x1",r['base'][0]==r['base'][2] and r['g'][0]==r['g'][2]+int(r['g'][2]*r['K']+.5) and abs(r['g'][1]-r['g'][4])<1e-9 and abs(r['base'][1]-r['base'][3])<1e-9 and r['after']==r['b3'] and r['g'][3]==int(r['g'][2]*r['K']+.5),r)
        r=await E("""()=>{const out={};
          /* hidden: a diving monster in range is out of reach until the Seer's Tincture */
          {const R=__p.start('moss',{seer:2},['seer','seer','']);const p=__p.near(R,1)[0];const tw=__p.build(R,p,'ballista',3);rpWaveStart();R.q=[];R.foes=[];__p.open(R);const s=__p.roadS(R,p.x,p.y);
           const e=__p.mob(R,'golem',s,0,{hp:1e6});const keep=()=>{e.hide=1;e.sp=0};const h0=e.hp;for(let i=0;i<120;i++){keep();rpStep(R,1/30)}out.hidden0=Math.round(h0-e.hp);
           rpptUse(0);const h1=e.hp;for(let i=0;i<120;i++){keep();rpStep(R,1/30)}out.hidden1=Math.round(h1-e.hp);out.marker=!!R.pt.vh&&R.pt.vh.includes(e);rpLeave()}
          /* range: a monster at 1.1x range is hit only with the tincture */
          {const R=__p.start('moss',{seer:1},['seer','','']);const p=__p.near(R,1)[0];const tw=__p.build(R,p,'ballista',1);rpWaveStart();R.q=[];R.foes=[];__p.open(R);const rg=RP_TW.ballista.range[0];let best=null;
           for(let s=0;s<rpLen(R,{pi:0});s+=3){const q=rpAt(R.G,s,0);const d=Math.sqrt(rpD2(q.x,q.y,p.x,p.y));if(d>rg*1.07&&d<rg*1.12){best=s;break}}
           const e=__p.mob(R,'golem',best,0,{hp:1e6});const h0=e.hp;__p.run(R,3);out.range0=Math.round(h0-e.hp);rpptUse(0);const h1=e.hp;__p.run(R,3);out.range1=Math.round(h1-e.hp);out.r=[rg,RP_TW.ballista.range[0]];rpLeave()}
          /* fog (Shipwreck Cove): a fogged monster far from the tower is picked only with the tincture */
          {const R=__p.start('wreck',{seer:1},['seer','','']);const p=__p.near(R,1)[0];const tw=__p.build(R,p,'prism',3);rpWaveStart();R.q=[];R.foes=[];__p.open(R);const s=__p.roadS(R,p.x,p.y);
           const e=__p.mob(R,'golem',s,0,{hp:1e6});const fn=R.map.fogNear;const keep=()=>{e.fogd=1;e.sp=0};const q=__p.pos(R,e),d=Math.sqrt(rpD2(q.x,q.y,p.x,p.y));
           const h0=e.hp;for(let i=0;i<90;i++){keep();rpStep(R,1/30)}out.fog0=Math.round(h0-e.hp);rpptUse(0);const h1=e.hp;for(let i=0;i<90;i++){keep();rpStep(R,1/30)}out.fog1=Math.round(h1-e.hp);out.fd=[Math.round(d),fn];rpLeave()}
          return out}""")
        chk('Seer\'s Tincture: towers hit a hidden (diving) monster only while it works (and it is marked); +15% range (a monster at 1.1x range is hit only with it, the range is put back); a fogged monster beyond the fog sight is picked only with it',
            r['hidden0']==0 and r['hidden1']>0 and r['marker'] and r['range0']==0 and r['range1']>0 and r['r'][0]==r['r'][1] and (r['fd'][0]<=(r['fd'][1] or 0) or r['fog0']==0) and r['fog1']>0,r)
        r=await E("""()=>{const R=__p.start('moss',{fury:2,frost:1},['fury','fury','frost']);rpWaveStart();R.q=[];R.foes=[];__p.open(R);const tw=__p.build(R,__p.near(R,1)[0],'ballista',1);const e=__p.mob(R,'golem',300,0,{hp:1e6,armor:0});
          rpptUse(0);__p.run(R,5);R.pt.cd=0;const t0=R.pt.fx.fury.t;rpptUse(1);const t1=R.pt.fx.fury.t;const h=e.hp;rpHurt(e,100,99,tw);const k=h-e.hp;
          /* the Starfall mark amplifies a potion bomb like any other damage; a potion's own damage is not raised by the Fury */
          e.mk=1;e.mkK=.3;const h2=e.hp;rpHurt(e,100,99,RPPT_SRC.fire);const k2=h2-e.hp;e.mk=0;const h3=e.hp;rpHurt(e,100,99,RPPT_SRC.fire);const k3=h3-e.hp;rpLeave();return [+t0.toFixed(1),t1,Math.round(k),Math.round(k2),Math.round(k3)]}""")
        chk('no stacking: a second Fury Draught while one works refreshes its time (5 s -> 0) and the bonus stays +25% (100 -> 125); the Starfall mark amplifies potion damage like any other damage (100 -> 130) while the Fury does not raise potion damage (100)',
            r[0]==5.0 and r[1]==0 and r[2]==125 and r[3]==130 and r[4]==100,r)
        # ================= keyboard, click, aiming, chips, tips =================
        await pg.mouse.move(4,4)
        r=await E("""async()=>{const R=__p.start('ember',{fury:1,frost:1,fire:1},['fury','frost','fire']);R.supply=1e6;for(const p of __p.near(R,4))__p.build(R,p,'ballista',2);R.wave=4;rpWaveStart();__p.run(R,14);__p.open(R);R.supply=520;R.tx=[];R.toast=null;await __p.sleep(200);
          const out=[];__p.key('4');out.push(R.pt.sl[0].used,!!R.pt.fx.fury);await __p.sleep(450);const ch=[...document.querySelectorAll('#rpptch .rpptchip')].map(c=>c.textContent);out.push(ch);R.pt.cd=0;
          __p.key('5');out.push(R.aim,R.pt.aim);__p.key('Escape');out.push(R.aim);__p.key('5');const c=rpptCrowd(R,110,false);R.mx=c.x;R.my=c.y;await __p.sleep(300);return out}""")
        await shot('aim_frost')
        r2=await E("""async()=>{const R=RPX;__p.key('5');const out=[R.pt.sl[1].used,R.pt.fly.length];await __p.sleep(260);return out}""")
        await shot('throw_frost_flight')
        await pg.wait_for_timeout(700)
        await shot('throw_frost_land')
        r3=await E("""async()=>{const R=RPX;R.pt.cd=0;const out=[R.foes.filter(e=>e.ptFz>0).length];const b=document.querySelector('#rpptb .rppts[data-i="2"]');b.click();out.push(R.aim);
          const c=rpptCrowd(R,90,true);const cv=document.querySelector('canvas');const q=cv.getBoundingClientRect();return [out,c.x/1600*q.width+q.left,c.y/900*q.height+q.top]}""")
        await pg.mouse.move(r3[1],r3[2]);await pg.wait_for_timeout(150);await pg.mouse.down();await pg.mouse.up();await pg.wait_for_timeout(900)
        await shot('throw_fire')
        r4=await E("()=>{const R=RPX;return [R.pt.sl[2].used,R.pt.burns.length,Math.round(R.pt.dmg)]}")
        chk('keyboard and click: 4 drinks the Fury Draught (a "Fury 12 s" chip appears), 5 starts aiming the Frostbite Flask and Esc puts it away, 5 again while aiming throws at the biggest crowd (it lands and freezes), clicking the third bottle and then the map throws the Dragonfire Bomb there',
            r[0]==1 and r[1] and any('Fury' in x for x in r[2]) and r[3]=='pot' and r[4]==1 and r[5] is None and r2[0]==1 and r2[1]==1 and r3[0][0]>0 and r3[0][1]=='pot' and r4[0]==1 and r4[1]==1 and r4[2]>0,[r,r2,r3[0],r4])
        await pg.wait_for_timeout(1200)
        r=await E("""async()=>{const R=RPX;__p.run(R,12);await __p.sleep(500);return [document.querySelectorAll('#rpptch .rpptchip:not(.out)').length,document.querySelectorAll('#rpptb .rppts.used').length]}""")
        chk('buff chips leave when their potion runs out; the belt shows all three as used',r[0]==0 and r[1]==3,r)
        await E("()=>rpLeave()")
        r=await E("""async()=>{const p=__p.pot({quick:1,frost:1},['quick','frost','']);p.tip={};delete RPP().tut.potbelt;delete RPP().tut.potthrow;save();const R=__p.start('moss');rpWaveStart();R.tut=null;await __p.sleep(50);const a=[R.tut];__p.run(R,10.2);R.pt.w1=R.time-10.5;
          rpptTip('belt');a.push(R.tut,document.getElementById('rptut').textContent.includes('Potions'));await __p.sleep(300);a.push(__rpuOvl(document.getElementById('rphud')));rpTutDone('potbelt');a.push(rpptSave().tip.belt);
          rpptPress(1);a.push(R.tut);rpTutDone('potthrow');R.tut=null;R.aim=null;R.pt.aim=-1;rpptPress(1);a.push(R.tut,R.aim,RPP().tut.potbelt,RPP().tut.potthrow);return a}""")
        await shot('tip_belt')
        chk('first-time tips: "Potions" after the lock lifts and "Throwing a potion" the first time a throw is aimed, each once (saved in P.rp.pot.tip); no overlaps with the tip open',r[1]=='potbelt' and r[2] and r[3]==[] and r[4]==1 and r[5]=='potthrow' and r[6] is None and r[7]=='pot' and r[8]==1 and r[9]==1,r)
        await E("()=>rpLeave()")
        # ================= Rune Typing =================
        r=await E("""async()=>{rptyOpt().ty=1;save();const R=__p.start('moss',{fury:1,hour:1,frost:1},['fury','hour','frost']);for(const p of __p.near(R,3))__p.build(R,p,'ballista',2);rpWaveStart();for(let i=0;i<6;i++)__p.mob(R,'golem',260+i*24,0,{hp:1e6});await __p.sleep(100);const out=[];
          out.push(Object.keys(R.ty.w).sort().join(','));__p.run(R,10.4);rpHudTick(true);await __p.sleep(200);const w=R.ty.w;out.push(Object.keys(w).sort().join(','));
          const first=Object.values(w).map(x=>x[0]);out.push(new Set(first).size===first.length);out.push(document.querySelectorAll('#rpptb .rpptyw').length);
          for(const ch of w.p1)rptyKey(ch);out.push(R.pt.sl[1].used,!!R.pt.fx.hour,!R.ty.w.p1);await __p.sleep(300);rpHudTick(true);out.push(Object.keys(R.ty.w).filter(k=>/^p/.test(k)).length);
          R.pt.cd=0;rpHudTick(true);const wf=R.ty.w.p2;for(const ch of wf)rptyKey(ch);out.push(R.pt.sl[2].used,R.pt.fly.length);await __p.sleep(200);return out}""")
        await shot('rune_typing')
        chk('Rune Typing: potion words only while a potion can be used (none in the first 10 s), all six words start with different letters, typing the Hourglass word drinks it, the words go away during the cooldown, typing the Frostbite word throws it at the biggest crowd',
            r[0]=='over,repair,slow' and r[1]=='over,p0,p1,p2,repair,slow' and r[2] and r[3]==3 and r[4]==1 and r[5] and r[6] and r[7]==0 and r[8]==1 and r[9]==1,r)
        await E("()=>{rpLeave();rptyOpt().ty=0;save()}")
        # ================= results: potions used, potion damage; the Championship mark =================
        r=await E("""async()=>{const R=__p.start('moss',{fire:1,fury:1},['fire','fury','']);R.supply=1e6;for(const p of __p.near(R,3))__p.build(R,p,'ballista',2);rpWaveStart();__p.run(R,3);__p.open(R);
          for(let i=0;i<5;i++)__p.mob(R,'golem',420+i*14,0,{hp:4000,sp:0});const c=rpptCrowd(R,90,true);rpptUse(0,c);__p.run(R,4);R.pt.cd=0;rpptUse(1);__p.run(R,6);R.wst='done';R.won=true;R.hp=18;rpFinish(true);await __p.sleep(2600);
          const box=document.querySelector('.rpres');const cell=box.querySelector('.rpptres');const bar=box.querySelector('.rpptbar');return [cell&&cell.textContent,cell?cell.querySelectorAll('img').length:0,bar&&bar.textContent,Math.round(R.pt.dmg),__rpuOvl(box)]}""")
        await shot('results')
        chk('results: a "Potions used" cell with the two bottles, and a "Potions" bar in the damage list with the potion damage; no overlaps on the card',r[0] and 'Potions used' in r[0] and r[0].startswith('2') and r[1]==2 and r[2] and r[2].startswith('Potions') and r[3]>0 and r[4]==[],r)
        r=await E("""async()=>{rpLeave();const L=rpLbSt();L.best=0;delete L.bp;const R=__p.start('wonder',{fury:1,quick:1},['fury','quick','']);R.supply=1e6;for(const p of __p.near(R,5))__p.build(R,p,'prism',3);rpWaveStart();__p.run(R,11);__p.open(R);rpptUse(0);R.pt.cd=0;rpptUse(1);
          R.wave=12;R.wst='build';R.kills=200;R.time=Math.max(R.time,400);R.hp=0;rpFinishEndless();await __p.sleep(1500);const box=document.querySelector('.rpres');const L2=rpLbSt();const mine=rpLbMine();
          const ev={kind:RPLBK,tags:[['d',rpLbTag(L2.s)]],created_at:Math.floor(Date.now()/1000),pubkey:'ab'.repeat(32),content:JSON.stringify(Object.assign({},mine))};const chkd=rpLbCheck(ev,L2.s);
          const ev2=Object.assign({},ev,{content:JSON.stringify(Object.assign({},mine,{p:9}))});const chk2=rpLbCheck(ev2,L2.s);const row=rpLbRow({me:0,n:'Ann',pk:'ab'.repeat(32),w:12,d:400,k:200,r:1,at:1,p:2},1);
          return [box&&box.querySelector('.rpptres')&&box.querySelector('.rpptres').textContent,L2.bp,mine.p,chkd&&chkd.p,chk2&&chk2.p,row.includes('rpptlb'),__rpuOvl(box),!!box.querySelector('.rplbrs .rpptlb')]}""")
        await shot('results_wonderland')
        chk('Championship: the Wonderland results list the potions used, the best run keeps a satchel mark (bp 2) that is posted as p 2, readers accept p 1-3 (and ignore a bad one), and a board row and the results\' Championship card show the satchel mark',
            r[0] and r[0].startswith('2') and r[1]==2 and r[2]==2 and r[3]==2 and r[4] is None and r[5] and r[6]==[] and r[7],r)
        r=await E("""async()=>{rpLeave();const L=rpLbSt();const b=L.best;const R=__p.start('wonder',{},['','','']);R.supply=1e6;rpWaveStart();R.wave=b+5;R.wst='build';R.kills=(b+5)*10;R.time=Math.max(R.time,(b+5)*RPLBWT+10);R.hp=0;rpFinishEndless();await __p.sleep(300);const L2=rpLbSt();return [L2.best>b,'bp' in L2,'p' in rpLbMine()]}""")
        chk('a later best run without potions clears the mark (no p in the posted entry, so entries of players who never use potions are unchanged)',r[0] and not r[1] and not r[2],r)
        await E("()=>rpLeave()")
        # ================= cheat guard: brewing is paid by the game's own code =================
        p2=await b.new_page(viewport={'width':1280,'height':720});er2=[];p2.on('pageerror',lambda e:er2.append(str(e)[:300]))
        await p2.add_init_script("window.TW_AC_TEST=1");await p2.goto(H);await p2.wait_for_timeout(1500)
        await p2.evaluate("()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}RPP();rpStart('moss');RPX.tut=null;RPX.won=true;RPX.free=false;RPX.wave=RPX.map.waves;window.g0=P.gold;setTimeout(rpFinish,0,true)}");await p2.wait_for_timeout(2500)
        g=await p2.evaluate("()=>{try{P.gold=999999}catch(e){}return [window.g0,P.gold]}")
        await p2.evaluate("()=>{rpLeave();rpptShop()}");await p2.wait_for_timeout(900)
        q=await p2.evaluate("()=>{const b=document.getElementById('rpptgo');const r=b.getBoundingClientRect();return [r.left+r.width/2,r.top+r.height/2]}")
        await p2.mouse.click(q[0],q[1]);await p2.wait_for_timeout(700)
        q=await p2.evaluate("()=>{const b=document.querySelector('.rpptbrew[data-k=\"quick\"]');const r=b.getBoundingClientRect();return [r.left+r.width/2,r.top+r.height/2,P.gold,rpptStock('quick')]}")
        await p2.mouse.move(q[0],q[1]);await p2.mouse.down();await p2.wait_for_timeout(1150);await p2.mouse.up();await p2.wait_for_timeout(400)
        r=await p2.evaluate("()=>[P.gold,rpptStock('quick'),rpptStock('fury'),TWAC.stat().enforced]")
        chk('with the 98t / 98v guard enforced (window.TW_AC_TEST): the game pays a map win, a console write to the coins is refused, and brewing by holding the button (game code) takes 300 coins and adds the potion; the gift is taken by a click',
            g[1]>g[0] and g[1]!=999999 and q[2]==g[1] and r[0]==q[2]-300 and r[1]==1 and r[2]==1 and r[3] is True and not er2,[g,q,r,er2])
        await p2.close()
        # ================= How to Play, DEV cheats =================
        r=await E("""async()=>{rampartsMenu(title);await __p.sleep(200);rpHowTo();await __p.sleep(300);const m=document.getElementById('rpmod');const h=m.querySelector('.rppthow');return [!!h,h&&h.textContent.includes('4, 5 or 6'),h?h.querySelectorAll('.rpptht span').length:0,__rpuOvl(m)]}""")
        await shot('howto')
        chk('How to Play: a "Potions" section (keys 4, 5, 6, the rules) with all eight potions; no overlaps',r[0] and r[1] and r[2]==8 and r[3]==[],r)
        r=await E("""async()=>{const R=__p.start('moss',{fury:1,frost:1},['fury','frost','']);rpWaveStart();rpPause(true);await __p.sleep(400);const p=document.querySelector('.rppause');const t=p.querySelector('.rpptph');const o=__rpuOvl(p);rpPause(false);rpLeave();return [t&&t.textContent,o]}""")
        chk('the pause menu lists the potion keys (4 5 6, potions left) without overlaps',r[0] and '2 left' in r[0] and r[1]==[],r)
        r=await E("""()=>{DEV.on=true;DEV.open=true;DEV.tab='Cheats';devPanelEl();devRender();const h=dvxHTML();const out=[h.includes('x:pt5'),h.includes('x:pt0')];dvxAct('pt5');out.push(RPPT_ORDER.every(k=>rpptStock(k)===5));dvxAct('ptsat');out.push(JSON.stringify(rpptSave().sat));
          const R=__p.start('moss');rpWaveStart();dvxAct('ptcd');out.push(rpptWhy(R,0));rpLeave();dvxAct('pt0');out.push(JSON.stringify(rpptSave().st),rpptSave().gift);DEV.on=false;DEV.open=false;try{devRender()}catch(e){}return out}""")
        chk('DEV › Cheats: fill every potion, a ready satchel, potions ready now in battle, clear potions and the gift',r[0] and r[1] and r[2] and json.loads(r[3])[:2]==['fury','frost'] and r[4]=='' and r[5]=='{}' and r[6]==0,r)
        await E("()=>{const p=rpptSave();p.gift=1;p.tip={belt:1,throw:1};save()}")
        # ================= reduced motion / Performance mode, frame cost =================
        r=await E("""()=>{const R=__p.start('moss',{fury:1,frost:1,fire:1},['fury','frost','fire']);rpWaveStart();R.q=[];R.foes=[];for(let i=0;i<6;i++)__p.mob(R,'golem',400+i*20,0,{hp:1e6});__p.open(R);R.rm=true;R.fx.length=0;
          rpptUse(0);R.pt.cd=0;const c=rpptCrowd(R,110,false)||{x:500,y:500};rpptUse(1,c);__p.run(R,1);const n=R.fx.length;let err=null;try{rpDraw()}catch(e){err=String(e)}rpLeave();return [n,err]}""")
        chk('reduced motion (and Performance mode, the same flag path): no potion particles, the effects still draw without errors',r[0]==0 and r[1] is None,r)
        r=await E("""async()=>{const R=__p.start('wonder',{fury:1,quick:1,seer:1},['fury','quick','seer']);R.supply=1e7;for(const p of R.pads.slice(0,12))__p.build(R,p,RP_TWORDER[p.i%RP_TWORDER.length],2);R.wave=20;rpWaveStart();__p.run(R,14);
          const c=ctx;c.setTransform(RS,0,0,RS,0,0);const T=(f,n)=>{let m=1e9;for(let k=0;k<4;k++){f();c.getImageData(0,0,1,1);const a=performance.now();for(let i=0;i<n;i++)f();c.getImageData(0,0,1,1);m=Math.min(m,(performance.now()-a)/n)}return m};
          const towers=T(()=>{for(const p of R.pads)if(p.tw)rpTowerAt(c,R,p.tw)},10);__p.open(R);rpptUse(0);R.pt.cd=0;rpptUse(1);R.pt.cd=0;rpptUse(2);R.pt.waves=[];R.pt.pops=[];
          R.pt.gr.push({k:'frost',x:700,y:420,t:.5,d:3.3},{k:'fire',x:900,y:520,t:.5,d:5.6},{k:'fire',x:500,y:520,t:.5,d:5.6});const L=R.foes.filter(e=>!e.dead).slice(0,20);
          const steady=T(()=>{rpptGround(c,R);for(const e of L){e.ptFz=2;rpFoeDraw(c,R,e,rpPos(R,e))}},10)-T(()=>{for(const e of L){e.ptFz=0;rpFoeDraw(c,R,e,rpPos(R,e))}},10);
          R.pt.waves.push({k:'fury',x:1400,y:500,t:.3,d:1.15});R.pt.pops.push({k:'fury',x:1400,y:400,t:.4,d:1.1});R.pt.fly.push({k:'fire',x0:1400,y0:400,x1:600,y1:500,t:.2,d:.55,h:200});const top=T(()=>rpptTop(c,R),10);
          R.lite=1;R.pt.waves=[];const lite=T(()=>rpptGround(c,R),10);R.lite=0;const full=T(()=>rpptGround(c,R),10);rpLeave();return [+towers.toFixed(2),+steady.toFixed(2),+top.toFixed(2),+lite.toFixed(2),+full.toFixed(2),L.length]}""")
        print('   frame cost ms [12 towers, potion ground + auras + ice, waves / pops / flights, lite ground, full ground, monsters]:',r,flush=True)
        chk(f'frame cost: three tower buffs on 12 towers, frost and two burning grounds and frozen monsters add about a millisecond or less (or under a quarter of drawing the 12 towers on a busy machine); the drink wave, pop and a flight about as much; Performance mode draws less ({r})',
            (r[1]<=1.2 or r[1]<=.25*r[0]) and (r[2]<=1.5 or r[2]<=.25*r[0]) and r[3]<=r[4]*1.05,r)
        # ================= UI fit at three sizes =================
        fits={}
        for vw,vh in [(1600,900),(1280,720),(1024,640)]:
            await pg.set_viewport_size({'width':vw,'height':vh});await pg.wait_for_timeout(300)
            r=await E("""async()=>{const out={};const R=__p.start('moss',{fury:1,quick:1,hour:1},['fury','quick','hour']);R.supply=1e6;for(const p of __p.near(R,4))__p.build(R,p,'ballista',2);rpWaveStart();__p.run(R,11);__p.open(R);
              rpptUse(0);R.pt.cd=0;rpptUse(1);R.pt.cd=0;rpptUse(2);await __p.sleep(600);const h=document.getElementById('rphud');out.hud=__rpuOvl(h);
              const b=document.getElementById('rpptb').getBoundingClientRect(),ab=document.querySelector('.rpabs').getBoundingClientRect(),bar=document.querySelector('.rpbar').getBoundingClientRect(),go=document.getElementById('rpgo').getBoundingClientRect();
              const nxr=document.querySelector('.rpnext').getBoundingClientRect();/* 10.3b: the belt sits above the Next Wave panel, right of the tower bar (clear of every build pad) */out.sep=b.bottom<=nxr.top+2&&b.left>=bar.right-2&&b.right<=nxr.right+2;
              /* a tower near the belt selected: the info panel stays clear of it */const tw=R.pads.filter(p=>p.tw).sort((a,c)=>a.x-c.x)[0].tw;R.sel=tw;await __p.sleep(400);const inf=document.getElementById('rpinfo').getBoundingClientRect(),bb=document.querySelector('#rpptb .rpptbelt').getBoundingClientRect();
              out.info=!(inf.left<bb.right&&inf.right>bb.left&&inf.top<bb.bottom&&inf.bottom>bb.top-36);R.sel=null;
              rptySet(true);await __p.sleep(400);out.rune=__rpuOvl(h);rptySet(false);rpLeave();
              rpptShop();await __p.sleep(500);out.shop=__rpuOvl(document.getElementById('rpptx'));return out}""")
            fits[f'{vw}x{vh}']=r
            await pg.screenshot(path=os.path.join(SHOTS,f'fit_apothecary_{vw}.png'))
        bad={k:v for k,v in fits.items() if v['hud'] or v['rune'] or v['shop'] or not v['sep'] or not v['info']}
        chk('UI fit at 1600x900, 1280x720 and 1024x640: the belt, three buff chips, the abilities, the 14-card tower bar and the wave panel without overlaps (also with Rune Typing words), the belt above the Next Wave panel (10.3b), the info panel clear of the belt, the Witch’s Cauldron without overlaps',not bad,bad or fits)
        await pg.set_viewport_size({'width':1600,'height':900})
        # the drink effects, one screenshot each
        for k in ['fury','quick','mend','hour','gild','seer']:
            await pg.mouse.move(4,4)
            await E(f"""async()=>{{const R=__p.start('{'wreck' if k=='seer' else 'moss'}',{{{k}:2,frost:1,fire:1}},['frost','{k}','fire']);R.supply=1e6;for(const p of __p.near(R,5))__p.build(R,p,RP_TWORDER[p.i%8],2);R.wave=3;rpWaveStart();__p.run(R,12);__p.open(R);R.supply=385;R.tx=[];R.toast=null;R.hp=12;rpptUse(1);R.pt.cd=14;return 1}}""")
            await pg.wait_for_timeout(420);await shot(f'drink_{k}_wave');await pg.wait_for_timeout(900);await shot(f'drink_{k}')
            await E("()=>rpLeave()")
        chk('no page errors',not er,er[:6])
        await b.close()
    print(f'\n{N[0]-len(FAIL)}/{N[0]} passed'+('' if not FAIL else '  FAILED: '+'; '.join(FAIL)))
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
