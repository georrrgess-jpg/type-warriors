# Wildcard (update 8.2) regression: casino listing, payouts, the secret code, a full staked solo game,
# leaving mid-game, the daily cap, stats, and Esc navigation. Run from the source folder against out.html.
import asyncio,os,time
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append('PE '+str(e)[:300]))
        await pg.goto('file://'+os.path.abspath('out.html'));await pg.wait_for_timeout(1000);E=pg.evaluate;bad=0
        def chk(name,r,ok):
            nonlocal bad;bad+=not ok;print(name,r,'OK' if ok else 'BAD')
        await E("()=>{RS_ASK=false;P.gold=5000;P.ccUsed={};delete P.wc;save()}")
        # casino listing: first game, Cards tab, NEW badge, opens the Wildcard home
        r=await E("()=>{lobby();return [GAMES[0].id,TCAT.wc,typeof wcFeat]}");await pg.wait_for_timeout(300)
        chk('listed',r,r[0]=='wc' and r[1]=='cards')
        r=await E("()=>{gameOpen('wc');return [document.getElementById('ov').classList.contains('wcx'),!!document.getElementById('wcsolo'),!!document.getElementById('wchost'),!!document.getElementById('wcjoin')]}")
        chk('home opens',r,all(r))
        # payouts: winner gets the pot less the fee, second gets 40% back, the rest nothing
        r=await E("()=>[WCTK.map(k=>WCT[k].stake),WCTK.map(k=>wcPayout(WCT[k].stake,4,0,WCFEE)),wcPayout(250,4,1,WCFEE),wcPayout(250,4,2,WCFEE),wcPayout(250,4,3,WCFEE)]")
        chk('payouts',r,r==[[50,250,1000,2500],[176,880,3520,8800],100,0,0])
        # the secret code from the 8.2 notes: 2,500 coins and the Elder Rune back, once per save
        r=await E("async()=>{const g=P.gold,x=await ccRedeem('wildrune82');ccStop();return [x.ok,P.gold-g,wcSt().backs.rune,wcSt().back]}")
        chk('code',r,r[0]==1 and r[1]==2500 and r[2]==1 and r[3]=='rune')
        r=await E("async()=>{const g=P.gold,x=await ccRedeem('WILDRUNE82');ccStop();return [x.ok,P.gold-g]}")
        chk('code again',r,r[0]==0 and r[1]==0)
        await E("()=>{P.gold=5000;save()}")
        # a full staked solo game played by the test agent; gold must settle exactly
        await pg.add_script_tag(path=os.path.abspath('t_wc_agent.js'))
        await E("()=>{wcHome();wcStartSolo('c250')}");r=await E("()=>[P.gold,WX.stake,wcSt().dayN,WX.G.P.slice(1).every(p=>p.av.t==='crew'&&p.name.split(' ').length>=2)]");chk('buy-in and crew',r,r==[4750,250,1,True])
        t0=time.time()
        while time.time()-t0<300:
            await pg.wait_for_timeout(500)
            if await E("()=>!!document.getElementById('wcr')"):break
        r=await E("()=>{const R=wcRank(WX.G),me=R.indexOf(WX.me),pay=wcPayout(250,4,me,WCFEE),bonus=me===0?150:0;return [0,me,P.gold,4750+pay+bonus,wcSt().g,wcSt().byd.c250.g,__ag.errs.length]}")
        chk(f'solo game {time.time()-t0:.0f}s',r,r[2]==r[3] and r[4]==1 and r[5]==1 and r[6]==0)
        await pg.wait_for_timeout(2500);await pg.screenshot(path='shots/wc_results.png')
        await E("()=>clearInterval(__agT)")
        await pg.click('#wchome');await pg.wait_for_timeout(500);r=await E("()=>!!document.getElementById('wcsolo')");chk('back to menu',r,r)
        # leaving mid-game counts as a loss and keeps the buy-in in the pot
        await E("()=>{P.gold=1000;save();wcStartSolo('c50')}");await pg.wait_for_timeout(2500)
        await pg.keyboard.press('Escape');await pg.wait_for_timeout(300);r=await E("()=>!!document.querySelector('#wcmod.wcmn:not([hidden]) #wcquit')");chk('esc opens menu',r,r)
        await pg.keyboard.press('Escape');await pg.wait_for_timeout(300);r=await E("()=>document.getElementById('wcmod').hidden");chk('esc closes menu',r,r)
        await pg.click('#wcmenu');await pg.wait_for_timeout(300);await pg.click('#wcquit');await pg.wait_for_timeout(500)
        r=await E("()=>[P.gold,wcSt().g,wcSt().cur,!!document.getElementById('wcsolo')]");chk('forfeit',r,r[0]==950 and r[1]==2 and r[2]==0 and r[3])
        # daily cap: after 15 staked games the tables are free
        await E("()=>{const W=wcSt();W.dayN=15;W.day=wcDay();save();wcStartSolo('c1k')}");r=await E("()=>[WX.stake,P.gold]");chk('daily cap',r,r==[0,950])
        await E("()=>wcExit()");await pg.wait_for_timeout(300)
        # stats modal and Esc back to the casino
        await pg.click('#wcstats');await pg.wait_for_timeout(500);r=await E("()=>[!!document.querySelector('#wcmod:not([hidden])'),document.getElementById('wcmod').textContent.includes('Games played')]");chk('stats',r,all(r))
        await pg.screenshot(path='shots/wc_stats.png')
        await pg.keyboard.press('Escape');await pg.wait_for_timeout(300);await pg.keyboard.press('Escape');await pg.wait_for_timeout(500)
        r=await E("()=>[document.getElementById('ov').classList.contains('wcx'),!!document.querySelector('.gdt')]");chk('esc to casino',r,not r[0])
        print('bad',bad);print(er[:6]);await b.close()
asyncio.run(main())
