/* ===== 10.1 THE CROOKED CUE: Orbit 8, the cast (97b2) =====
   Five drawers in the 96g convention: pzMon[id](g,t,ex,p), origin at the bottom centre (up is negative), `ex` the live expression
   springs (eo eyes open, lx/ly look, br brow, bh brow height, mo mouth curve, ma mouth open, bl blush, sw sweat) and `p` the pose
   (breath, tilt, bob, hop). Every reaction is read from the springs through pznMood(ex) (cheer, sad, angry, rattled, wow), so each
   one blends in and out smoothly and also works on the hub, the results and the VS intro, where there is no match state.
   Each has breathing, blinking (from the springs), a sway and its own idle quirk:
     Bleep    a dome robot on a hover pod; a CRT face of pixels (^^ when cheering, O O for wow, static when rattled, a rain cloud when
              sad, a red screen when angry); polishes a glass; every 9 s the face buffers. Antenna blinks, LEDs chase.
     Octavia  an octopus lounge singer in a water-filled helmet; six tentacles curl out of phase, colour waves run over her skin,
              a microphone and a cocktail; ink puffs when rattled, music notes when she cheers.
     Facet    a floating crystal with a gem head; shards orbit it (faster when happy, flung wide on wow), a glint sweeps its facets,
              the core turns red when angry, cracks show when rattled; a little holo-prism turns over its palm.
     Rex      a gecko hotshot with a pompadour crest, a bomber jacket and a jetpack; gum bubbles grow and pop, the tail swishes,
              the jets roar on a cheer and sputter when sad; the bubble pops in his face when rattled.
     Vantara  a void-headed empress: an accretion disk swirls round a black sphere (red when angry, dim when sad, flaring on a
              cheer, wobbling when rattled), a starfield gown, an orbiting belt planet and a void 8-ball circling her palm.
   Gradients and the gown pattern are cached per context (pzGr/pzGrR keys pzn*); no shadowBlur, no ctx.filter. */
const pznCl=x=>x<0?0:x>1?1:x;
function pznMood(ex){return{ch:pznCl((ex.mo-.4)*1.6)*pznCl(ex.ma*1.5),sad:pznCl((-ex.mo-.3)*1.6),ang:pznCl((ex.br-.4)*1.8),rat:pznCl(ex.sw),wow:pznCl((ex.eo-1.02)*5)}}
function pznPat(g,key,mk){let m=PZ_GCACHE.get(g);if(!m)PZ_GCACHE.set(g,m=new Map());let q=m.get(key);if(!q){q=g.createPattern(mk(),'repeat');m.set(key,q)}return q}
/* an eye like pzEyeD with a choice of pupil: o.bar (horizontal, Octavia), o.slit (vertical) or round */
function pznEye(g,x,y,r,ex,o){o=o||{};const op=Math.max(.04,Math.min(1.25,ex.eo)),ry=r*(.3+.7*Math.min(1,op))*(op>1?1+(op-1)*.5:1),s=o.side||1;
 g.save();g.beginPath();g.ellipse(x,y,r,ry,0,0,TAU);g.clip();g.fillStyle=o.white||'#fff';g.fillRect(x-r,y-ry,r*2,ry*2);
 const px=x+ex.lx*r*.4,py=y+ex.ly*ry*.38+r*.04,pr=r*(o.pr||.52);
 if(o.iris){g.fillStyle=o.iris;g.beginPath();g.arc(px,py,pr*1.16,0,TAU);g.fill();if(o.iris2){g.fillStyle=o.iris2;g.beginPath();g.arc(px,py+pr*.35,pr*.8,0,Math.PI);g.fill()}}
 g.fillStyle=o.pupil||PZ_O;g.beginPath();if(o.bar)g.roundRect(px-pr*.82,py-pr*.26,pr*1.64,pr*.52,pr*.26);else g.ellipse(px,py,pr*(o.slit?.32:.8),pr*(o.slit?1.02:.8),0,0,TAU);g.fill();
 g.fillStyle='rgba(255,255,255,.95)';g.beginPath();g.arc(px-pr*.4,py-pr*.42,pr*.26,0,TAU);g.fill();
 if(Math.abs(ex.br)>.05){const k=ex.br;g.fillStyle=o.skin||'#777';g.beginPath();g.moveTo(x-r*1.2,y-ry*1.25);g.lineTo(x+r*1.2,y-ry*1.25);
  if(k>0){g.lineTo(x+r*1.2,y-ry+(s>0?k*r*.75:0));g.lineTo(x-r*1.2,y-ry+(s>0?0:k*r*.75))}else{const kk=-k;g.lineTo(x+r*1.2,y-ry+(s>0?0:kk*r*.55));g.lineTo(x-r*1.2,y-ry+(s>0?kk*r*.55:0))}g.closePath();g.fill()}
 g.restore();g.strokeStyle=PZ_O;g.lineWidth=o.lw||3;g.beginPath();g.ellipse(x,y,r,ry,0,0,TAU);g.stroke()}
/* a tapered limb along a quadratic curve (tentacles, tails): w0 at the root, w1 at the tip; returns the spine points */
function pznLimb(g,x0,y0,cx,cy,x1,y1,w0,w1,fill,lw,curl){const N=12,pts=[];for(let i=0;i<=N;i++){const u=i/N,a=(1-u)*(1-u),b=2*(1-u)*u,c=u*u;pts.push([a*x0+b*cx+c*x1,a*y0+b*cy+c*y1])}
 if(curl){/* the last part curls round on itself */const [lx,ly]=pts[N],[px,py]=pts[N-1];let ang=Math.atan2(ly-py,lx-px);const st=Math.hypot(lx-px,ly-py);for(let i=1;i<=6;i++){ang+=curl*.42;const q=pts[pts.length-1];pts.push([q[0]+Math.cos(ang)*st*(1-i*.12),q[1]+Math.sin(ang)*st*(1-i*.12)])}}
 const n=pts.length-1,L=[],R=[];for(let i=0;i<=n;i++){const a=pts[Math.max(0,i-1)],b=pts[Math.min(n,i+1)],dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy)||1,w=(w0+(w1-w0)*(i/n))/2;L.push([pts[i][0]-dy/d*w,pts[i][1]+dx/d*w]);R.push([pts[i][0]+dy/d*w,pts[i][1]-dx/d*w])}
 g.fillStyle=fill;g.strokeStyle=PZ_O;g.lineWidth=lw||3.5;g.beginPath();g.moveTo(L[0][0],L[0][1]);for(const q of L)g.lineTo(q[0],q[1]);const e=pts[n];g.quadraticCurveTo(e[0]+(L[n][0]-R[n][0])*.0,e[1],R[n][0],R[n][1]);for(let i=n;i>=0;i--)g.lineTo(R[i][0],R[i][1]);g.closePath();g.fill();g.stroke();return {pts,L,R}}
const pznStar4=(g,x,y,r)=>{g.beginPath();g.moveTo(x,y-r);g.quadraticCurveTo(x,y,x+r,y);g.quadraticCurveTo(x,y,x,y+r);g.quadraticCurveTo(x,y,x-r,y);g.quadraticCurveTo(x,y,x,y-r);g.fill()};
/* ================= Bleep: the rookie bar robot ================= */
pzMon.bleep=function(g,t,ex,p){const M=pznMood(ex),hov=Math.sin(t*2.4)*4+p.hop*0,fl=.75+.25*Math.sin(t*23)*Math.sin(t*7.3);
 pzEll(g,'rgba(0,0,0,.28)',0,2,80-hov*1.5,10,0,0);pzGlow(g,0,-6,50+fl*10,'rgba(110,236,255,1)',.5*fl);
 g.save();g.translate(0,-10-hov);g.rotate(Math.sin(t*1.1)*.025);g.scale(1,1+p.breath*.8);
 /* hover pod */
 pzBlob(g,pzGr(g,'pznb_pod',0,-30,0,0,[[0,'#5a6478'],[1,'#22283a']]),()=>{g.ellipse(0,-12,36,14,0,0,TAU)},3.5);
 g.fillStyle='#7af8ff';g.beginPath();g.ellipse(0,-6,22,5,0,0,Math.PI);g.fill();
 /* arms behind: left noodle arm (waves when cheering) */
 const arm=(x0,y0,cx,cy,x1,y1)=>{g.lineCap='round';g.strokeStyle=PZ_O;g.lineWidth=16;g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo(cx,cy,x1,y1);g.stroke();g.strokeStyle='#9aa6ba';g.lineWidth=10;g.stroke();g.strokeStyle='rgba(255,255,255,.55)';g.lineWidth=3;g.beginPath();g.moveTo(x0,y0-3);g.quadraticCurveTo(cx,cy-3,x1,y1-3);g.stroke();
  g.strokeStyle='rgba(18,8,31,.35)';g.lineWidth=2;for(let i=1;i<5;i++){const u=i/5,a=(1-u)*(1-u),b=2*(1-u)*u,c=u*u,x=a*x0+b*cx+c*x1,y=a*y0+b*cy+c*y1;g.beginPath();g.arc(x,y,5,0,TAU);g.stroke()}};
 const clamp=(x,y,a,open)=>{g.save();g.translate(x,y);g.rotate(a);for(const s of[-1,1]){pzBlob(g,'#c8d2e0',()=>{g.moveTo(0,s*3);g.quadraticCurveTo(14,s*(10+open*8),22,s*(4+open*6));g.lineTo(18,s*(1+open*3));g.quadraticCurveTo(10,s*4,0,s*1)},2.6)}pzEll(g,'#5a6478',0,0,7,7,0,2.6);g.restore()};
 {const wv=M.ch>.2?Math.sin(t*12)*.5*M.ch:0,lx=-96-M.ch*16,ly=-60-M.ch*130+M.sad*14,ax=lx+Math.cos(-2.2+wv)*0;arm(-58,-96,-96,-80+M.ch*-40,ax,ly);clamp(ax,ly,M.ch>.2?-1.6+wv:2.2,.4+.3*Math.sin(t*3))}
 /* body: a chrome egg with an amber band, rivets and chest LEDs */
 pzBlob(g,pzGr(g,'pznb_body',0,-160,0,-30,[[0,'#ffffff'],[.45,'#dfe6f0'],[1,'#8a96ac']]),()=>{g.ellipse(0,-92,72,62,0,0,TAU)},4.5);
 g.save();g.beginPath();g.ellipse(0,-92,70,60,0,0,TAU);g.clip();g.fillStyle='#ffb22e';g.fillRect(-80,-92,160,17);g.fillStyle='rgba(120,50,0,.35)';g.fillRect(-80,-79,160,4);g.fillStyle='rgba(255,255,255,.4)';g.fillRect(-80,-92,160,3);
 g.fillStyle='rgba(30,40,70,.18)';g.beginPath();g.ellipse(14,-70,70,44,0,0,TAU);g.fill();g.restore();
 g.strokeStyle=PZ_O;g.lineWidth=2;g.beginPath();g.moveTo(-70,-92);g.lineTo(70,-92);g.moveTo(-70,-75);g.lineTo(70,-75);g.stroke();
 for(let i=-3;i<=3;i++){if(!i)continue;g.fillStyle='#5a3a10';g.beginPath();g.arc(i*18,-83.5,2.2,0,TAU);g.fill()}
 pzBlob(g,'#141c2c',()=>{g.roundRect(-24,-66,48,24,6)},3);
 for(let i=0;i<3;i++){const on=((t*3+i*.33)%1)<.5,c=['#5aff9a','#ffc23a','#ff5a6a'][i];g.fillStyle=on?c:'#2a3044';g.beginPath();g.arc(-13+i*13,-54,4.5,0,TAU);g.fill();if(on)pzGlow(g,-13+i*13,-54,12,pzRgba(c),.5)}
 g.fillStyle='rgba(255,255,255,.75)';g.beginPath();g.ellipse(-34,-128,18,9,-.55,0,TAU);g.fill();g.fillStyle='rgba(255,255,255,.4)';g.beginPath();g.ellipse(-54,-104,5,9,-.3,0,TAU);g.fill();
 /* a bow tie and a TRAINEE badge */
 pzBlob(g,'#e8263a',()=>{g.moveTo(-22,-158);g.lineTo(0,-150);g.lineTo(-22,-140);g.closePath();g.moveTo(22,-158);g.lineTo(0,-150);g.lineTo(22,-140);g.closePath()},3);pzEll(g,'#ffc23a',0,-150,5,5,0,2.2);
 pzBlob(g,'#ffffff',()=>{g.roundRect(22,-128,34,14,4)},2.4);g.fillStyle='#e8263a';g.fillRect(24,-126,30,4);g.fillStyle='#3a4458';g.font='800 6px Poppins,sans-serif';g.textAlign='center';g.fillText('TRAINEE',39,-116.5);
 /* right arm polishing a glass with a rag, round and round */
 {const pa=t*4.2,gx=98,gy=-96+M.sad*10;arm(58,-100,98,-120,gx-8,gy+14);
  g.fillStyle='rgba(220,245,255,.35)';g.strokeStyle=PZ_O;g.lineWidth=3;g.beginPath();g.moveTo(gx-14,gy-26);g.lineTo(gx+14,gy-26);g.lineTo(gx+10,gy+8);g.lineTo(gx-10,gy+8);g.closePath();g.fill();g.stroke();
  g.fillStyle='rgba(255,255,255,.7)';g.fillRect(gx-9,gy-22,3,24);clamp(gx-10,gy+12,-.2,.1);
  if(M.ch<.5){const rx=gx+Math.cos(pa)*9,ry=gy-10+Math.sin(pa)*7;pzBlob(g,'#3ac8b8',()=>{g.moveTo(rx-14,ry-6);g.quadraticCurveTo(rx,ry-14,rx+14,ry-6);g.quadraticCurveTo(rx+18,ry+6,rx+6,ry+12);g.quadraticCurveTo(rx-8,ry+14,rx-14,ry-6)},2.6);g.strokeStyle='rgba(255,255,255,.4)';g.lineWidth=2;g.beginPath();g.moveTo(rx-8,ry-4);g.lineTo(rx+8,ry+2);g.stroke();
   if(((t*.7)%1)<.12){g.fillStyle='#fff';pznStar4(g,gx+12,gy-24,7)}}}
 /* neck and head */
 g.save();g.translate(0,-150);g.rotate(p.tilt*.6+M.sad*.08);g.translate(0,p.bob*.5+M.sad*4);
 for(let i=0;i<3;i++)pzBlob(g,i%2?'#aab4c6':'#8a96aa',()=>{g.roundRect(-16+i*1.5,-8-i*7,32-i*3,9,4)},2.6);
 const hy=-78;/* head centre */
 /* antenna */
 {g.save();g.translate(0,hy-54);g.rotate(Math.sin(t*2.1)*.12+M.sad*.5-M.ch*.1*Math.sin(t*14));g.strokeStyle=PZ_O;g.lineWidth=6;g.beginPath();g.moveTo(0,0);g.lineTo(0,-34);g.stroke();g.strokeStyle='#c8d2e0';g.lineWidth=3;g.stroke();
  const blink=M.ch>.3?1:((t*1.25)%1)<.6?1:0,bc=M.ch>.3?['#ff6ad5','#7af8ff','#ffc23a','#8affb4'][(t*8|0)%4]:M.ang>.4?'#ff4a4a':'#ffc23a';pzEll(g,blink?bc:'#6a5a3a',0,-40,8.5,8.5,0,3);if(blink)pzGlow(g,0,-40,30,pzRgba(bc),.75);g.fillStyle='rgba(255,255,255,.8)';g.beginPath();g.arc(-2.5,-43,2.5,0,TAU);g.fill();g.restore()}
 /* ear bolts (steam when angry) */
 for(const s of[-1,1]){pzEll(g,'#8a96aa',s*84,hy,11,16,0,3.5);g.strokeStyle=PZ_O;g.lineWidth=2;g.beginPath();g.moveTo(s*84-5,hy);g.lineTo(s*84+5,hy);g.stroke();
  if(M.ang>.2)for(let i=0;i<3;i++){const ph=(t*1.6+i*.33)%1;g.fillStyle=`rgba(255,255,255,${(1-ph)*.6*M.ang})`;g.beginPath();g.arc(s*(84+ph*18),hy-10-ph*36,5+ph*8,0,TAU);g.fill()}}
 /* the housing and the screen */
 pzBlob(g,pzGr(g,'pznb_head',0,hy-56,0,hy+56,[[0,'#ffffff'],[.6,'#d4dce8'],[1,'#8e9ab0']]),()=>{g.roundRect(-80,hy-56,160,112,26)},4.5);
 g.fillStyle='rgba(255,255,255,.6)';g.beginPath();g.roundRect(-64,hy-51,76,6,3);g.fill();g.fillStyle='rgba(40,50,80,.25)';g.beginPath();g.roundRect(-74,hy+40,148,10,5);g.fill();
 const scr=M.ang>.05?pzMix('#06121e','#3a0610',M.ang):M.sad>.05?pzMix('#06121e','#0a1236',M.sad):'#06121e',fc=M.ang>.4?'#ff7a7a':M.sad>.4?'#9ab8ff':'#7af8ff';
 g.fillStyle=scr;g.beginPath();g.roundRect(-64,hy-43,128,86,16);g.fill();g.strokeStyle=PZ_O;g.lineWidth=3.5;g.stroke();
 g.save();g.beginPath();g.roundRect(-62,hy-41,124,82,14);g.clip();
 g.fillStyle=pzGrR(g,'pznb_scr',0,hy,4,80,[[0,'rgba(80,220,255,.22)'],[1,'rgba(80,220,255,0)']]);g.fillRect(-60,hy-40,120,80);
 /* glitching: the face jumps sideways and noise bars cross the screen */
 const gl=Math.max(M.rat,PZ.pznGlitch&&performance.now()-PZ.pznGlitch<900?1:0),jx=gl>.1?((Math.sin(t*53)>.3?1:-1)*Math.round(gl*4)):0;
 g.translate(jx,0);const u=6,px=(x,y,w,h)=>g.fillRect(Math.round(x),Math.round(y),w,h);g.fillStyle=fc;
 const loading=((t%9)<1.3)&&M.ch<.2&&M.sad<.2&&M.ang<.2&&gl<.2&&M.wow<.2;
 if(loading){for(let i=0;i<8;i++){const a=i/8*TAU,k=((i-t*10)%8+8)%8/8;g.globalAlpha=.25+.75*(1-k);px(Math.cos(a)*16-3,hy-4+Math.sin(a)*16-3,6,6)}g.globalAlpha=1;g.font='700 9px Poppins,sans-serif';g.textAlign='center';g.fillText('LOADING',0,hy+30)}
 else{const ex0=Math.round(ex.lx*4)*1.5,ey0=Math.round(ex.ly*3)*1.5;
  for(const s of[-1,1]){const cx=s*28+ex0,cy=hy-8+ey0;
   if(M.ch>.5){/* ^ ^ */for(let i=-2;i<=2;i++)px(cx+i*u-u/2,cy-u-(2-Math.abs(i))*u,u,u)}
   else if(M.wow>.5){g.strokeStyle=fc;g.lineWidth=u;g.strokeRect(cx-2.5*u,cy-2.5*u-u,5*u,5*u)}
   else{const h=Math.max(u*.5,u*4*Math.min(1.15,ex.eo)),w=u*3;px(cx-w/2,cy-h/2,w,h);if(h>u*2){g.fillStyle=scr;px(cx-w/2,cy-h/2,u,u);g.fillStyle=fc}}
   /* pixel brows */
   if(Math.abs(ex.br)>.15||ex.bh>.2){const by=cy-u*4-ex.bh*6;for(let i=0;i<3;i++){const tilt=Math.round(ex.br*1.2*(s>0?-(i-1):(i-1)));px(cx-1.5*u+i*u,by+tilt*u*.6,u,u)}}}
  /* mouth */
  const my=hy+22;if(ex.ma>.3){const w=Math.round(2+ex.ma*2),h=Math.round(1+ex.ma*1.6);px(-w*u/2,my-u,w*u,h*u);g.fillStyle='#ff6a9a';px(-u,my-u+(h-1)*u,u*2,u);g.fillStyle=fc}
  else{const c=ex.mo>.25?1:ex.mo<-.25?-1:0;for(let i=-3;i<=3;i++){const yy=c===0?0:c>0?(Math.abs(i)===3?-u:0):(Math.abs(i)===3?u:0);px(i*u-u/2,my+yy-(c<0?u:0),u,u)}}
  if(ex.bl>.1){g.globalAlpha=Math.min(1,ex.bl);g.fillStyle='#ff6ad5';for(const s of[-1,1]){px(s*46-u,hy+10,u,u);px(s*46+u*.2,hy+10,u,u)}g.globalAlpha=1;g.fillStyle=fc}}
 /* overlays: rain cloud (sad), confetti (cheer), sweat, noise */
 if(M.sad>.35){g.globalAlpha=M.sad;g.fillStyle='#9ab8ff';px(-44,hy-32,20,6);px(-40,hy-36,12,4);for(let i=0;i<3;i++){const ph=(t*1.8+i*.33)%1;px(-42+i*7,hy-24+ph*30,2,4)}g.globalAlpha=1}
 if(M.ch>.3){for(let i=0;i<6;i++){const ph=(t*.9+i*.17)%1;g.fillStyle=['#ffc23a','#ff6ad5','#8affb4'][i%3];g.globalAlpha=M.ch*(1-ph);px(-50+((i*37)%100),hy-34+ph*60,4,4)}g.globalAlpha=1}
 if(ex.sw>.1){const ph=(t*1.3)%1;g.globalAlpha=Math.min(1,ex.sw);g.fillStyle='#9ae8ff';px(40,hy-26+ph*16,4,8);px(38,hy-20+ph*16,8,4);g.globalAlpha=1}
 if(gl>.1){for(let i=0;i<3;i++){const yy=hy-30+((t*137+i*53)%60);g.fillStyle=`rgba(255,255,255,${.25*gl})`;g.fillRect(-60,yy,120,3);g.fillStyle=`rgba(255,80,200,${.2*gl})`;g.fillRect(-60,yy+4,120,2)}}
 /* scanlines and glare */
 g.translate(-jx,0);g.fillStyle='rgba(0,0,0,.18)';for(let y=hy-41;y<hy+41;y+=4)g.fillRect(-62,y,124,1.5);
 g.fillStyle='rgba(255,255,255,.1)';g.beginPath();g.moveTo(-62,hy-41);g.lineTo(-12,hy-41);g.lineTo(-62,hy+12);g.closePath();g.fill();g.restore();
 g.restore();g.restore()};
/* ================= Octavia Inkwell: the octopus lounge singer ================= */
pzMon.octavia=function(g,t,ex,p){const M=pznMood(ex);g.save();g.scale(1,1+p.breath);
 pzEll(g,'rgba(0,0,0,.28)',0,2,150,14,0,0);
 /* six tentacles: back ones darker; they curl and uncurl out of phase, lift on a cheer and lie flat when sad */
 const tent=(i,back)=>{const s=i%2?1:-1,k=(i>>1),rx=s*(10+k*13),ph=t*1.5+i*1.3,lift=M.ch*30*(.6+.4*Math.sin(t*9+i))-M.sad*4,reach=50+k*34,tx=s*reach+Math.sin(ph)*7,ty=-16-lift-(back?16:0)+k*4,cl=s*(1.7+.6*Math.sin(ph*.8))*(1-M.sad*.75);
  const col=back?pzGr(g,'pzno_tb',0,-90,0,0,[[0,'#b8409e'],[1,'#7a1e6e']]):pzGr(g,'pzno_tf',0,-90,0,0,[[0,'#ff7ad8'],[1,'#c83a9e']]);
  const L=pznLimb(g,rx,-62,s*(reach*.62),-8-lift*.5,tx,ty,42-k*6,7,col,3.5,cl);
  if(!back){g.fillStyle='#ffd0ee';for(let j=3;j<L.pts.length-3;j+=2){const q=L.R[j],q0=L.pts[j];const sx=q0[0]+(q[0]-q0[0])*.7,sy=q0[1]+(q[1]-q0[1])*.7;g.beginPath();g.arc(sx,sy,2.6-j*.08,0,TAU);g.fill()}}};
 for(const i of[4,5])tent(i,true);
 /* ink puffs when rattled */
 if(M.rat>.05)for(let i=0;i<5;i++){const ph=(t*.7+i*.2)%1,a=i*1.26+t*.3;g.globalAlpha=M.rat*(1-ph)*.75;pzEll(g,'#2a0a3a',Math.cos(a)*(70+ph*60),-60-Math.sin(a)*20-ph*40,18+ph*26,14+ph*20,0,0);g.globalAlpha=1}
 /* the gown: sequins, scalloped hem */
 pzBlob(g,pzGr(g,'pzno_frill',0,-110,0,-40,[[0,'#8afff0'],[1,'#2ab8c0']]),()=>{g.moveTo(-40,-104);g.quadraticCurveTo(-70,-80,-86,-56);for(let i=0;i<8;i++){const x=-86+i*172/8;g.quadraticCurveTo(x+10.75,-36-(i%2)*4,x+21.5,-56)}g.quadraticCurveTo(70,-80,40,-104);g.closePath()},3.5);
 g.strokeStyle='rgba(10,80,100,.45)';g.lineWidth=2;for(let i=1;i<8;i++){const x=-86+i*21.5;g.beginPath();g.moveTo(x*.45,-100);g.quadraticCurveTo(x*.8,-74,x,-58);g.stroke()}
 pzBlob(g,pzGr(g,'pzno_gown',0,-176,0,-70,[[0,'#5af8e0'],[.5,'#1ab0b8'],[1,'#0e5a78']]),()=>{g.moveTo(-50,-150);g.bezierCurveTo(-60,-176,-26,-180,0,-176);g.bezierCurveTo(26,-180,60,-176,50,-150);g.bezierCurveTo(30,-128,30,-112,44,-86);g.quadraticCurveTo(0,-74,-44,-86);g.bezierCurveTo(-30,-112,-30,-128,-50,-150)},4);
 g.strokeStyle='#ffd45a';g.lineWidth=4;g.beginPath();g.moveTo(-36,-118);g.quadraticCurveTo(0,-108,36,-118);g.stroke();pzEll(g,'#ff6ad5',18,-114,6,5,0,2);
 g.fillStyle='rgba(255,255,255,.18)';g.beginPath();g.ellipse(-20,-140,10,26,-.2,0,TAU);g.fill();
 for(let i=0;i<14;i++){const x=-36+((i*29)%72),y=-90-((i*37)%80),a=.5+.5*Math.sin(t*3+i*1.7);if(a>.8){g.fillStyle=`rgba(255,255,255,${(a-.8)*4})`;pznStar4(g,x,y,4+(i%3))}else{g.fillStyle='rgba(200,255,250,.35)';g.beginPath();g.arc(x,y,1.6,0,TAU);g.fill()}}
 for(const i of[0,1,2,3])tent(i,false);
 /* pearls */
 for(let i=-4;i<=4;i++){const x=i*8,y=-168+Math.abs(i)*-.6+i*i*.5;pzEll(g,'#fff8f0',x,y,3.6,3.6,0,1.6)}
 /* arm tentacles: a retro microphone (left) and a fizzing cocktail (right) */
 {const sw=Math.sin(t*1.2)*6,my=-128-M.ch*30+sw;{const L=pznLimb(g,-40,-158,-100,-176,-92,my+8,24,8,'#f066c8',3.2,-.5);g.fillStyle='#ffd0ee';for(let j=3;j<L.pts.length-2;j+=2){const q=L.L[j],q0=L.pts[j];g.beginPath();g.arc(q0[0]+(q[0]-q0[0])*.6,q0[1]+(q[1]-q0[1])*.6,2.2,0,TAU);g.fill()}}
  g.save();g.translate(-98,my);g.rotate(-.35-M.ch*.3);g.fillStyle='#3a3a4a';g.strokeStyle=PZ_O;g.lineWidth=3;g.beginPath();g.roundRect(-5,0,10,34,4);g.fill();g.stroke();pzEll(g,pzGrR(g,'pzno_mic',-4,-14,2,16,[[0,'#ffffff'],[1,'#8a8aa0']]),0,-12,14,16,0,3.2);
  g.strokeStyle='rgba(18,8,31,.45)';g.lineWidth=1.4;for(let i=-2;i<=2;i++){g.beginPath();g.moveTo(-12,-12+i*5);g.lineTo(12,-12+i*5);g.stroke();g.beginPath();g.moveTo(i*5,-26);g.lineTo(i*5,2);g.stroke()}g.restore();
  if(M.ch>.2)for(let i=0;i<3;i++){const ph=(t*.8+i*.33)%1;g.globalAlpha=M.ch*Math.sin(ph*Math.PI);g.fillStyle=['#ffd45a','#ff9ad8','#8ef0ff'][i];g.font='400 26px "Pirata One",serif';g.textAlign='center';g.fillText(i%2?'♫':'♪',-110-i*14+Math.sin(t*3+i)*8,my-30-ph*80);g.globalAlpha=1}}
 {const cy=-118-M.ch*16+Math.sin(t*1.4+1)*4;{const L=pznLimb(g,40,-158,104,-180,92,cy+12,24,8,'#f066c8',3.2,.5);g.fillStyle='#ffd0ee';for(let j=3;j<L.pts.length-2;j+=2){const q=L.R[j],q0=L.pts[j];g.beginPath();g.arc(q0[0]+(q[0]-q0[0])*.6,q0[1]+(q[1]-q0[1])*.6,2.2,0,TAU);g.fill()}}
  g.save();g.translate(100,cy);g.rotate(.12+M.sad*.3);g.fillStyle='rgba(220,250,255,.35)';g.strokeStyle=PZ_O;g.lineWidth=3;g.beginPath();g.moveTo(-18,-28);g.lineTo(18,-28);g.lineTo(0,-6);g.closePath();g.fill();g.stroke();
  g.fillStyle='#4ad8ff';g.beginPath();g.moveTo(-14,-24);g.lineTo(14,-24);g.lineTo(0,-8);g.closePath();g.fill();pzGlow(g,0,-18,22,'rgba(90,220,255,1)',.45);
  g.beginPath();g.moveTo(0,-6);g.lineTo(0,10);g.stroke();g.beginPath();g.moveTo(-9,11);g.lineTo(9,11);g.stroke();
  pzEll(g,'#ffb84a',6,-26,5,5,0,2);g.strokeStyle='rgba(255,220,150,.9)';g.lineWidth=1.4;g.beginPath();g.ellipse(6,-26,9,2.5,-.3,0,TAU);g.stroke();
  for(let i=0;i<3;i++){const ph=(t*.9+i*.33)%1;g.fillStyle=`rgba(255,255,255,${.7*(1-ph)})`;g.beginPath();g.arc(-6+i*5,-26-ph*16,1.5,0,TAU);g.fill()}g.restore()}
 /* helmet collar */
 pzBlob(g,pzGr(g,'pzno_col',0,-186,0,-166,[[0,'#ffe08a'],[1,'#a8741a']]),()=>{g.ellipse(0,-174,56,13,0,0,TAU)},3.5);for(let i=-3;i<=3;i++){g.fillStyle='#6a4a10';g.beginPath();g.arc(i*14,-172+Math.abs(i)*-.4,1.8,0,TAU);g.fill()}
 /* the head inside its water-filled dome */
 g.save();g.translate(0,-256+p.bob);g.rotate(p.tilt*.6+Math.sin(t*.9)*.03);/* dome back: the water */
 g.save();g.beginPath();g.arc(0,-6,94,0,TAU);g.clip();g.fillStyle='rgba(40,120,180,.28)';g.fillRect(-100,-100,200,200);
 g.fillStyle='rgba(90,210,255,.22)';g.beginPath();g.moveTo(-100,40);for(let x=-100;x<=100;x+=15)g.lineTo(x,40+Math.sin(t*2.4+x*.06)*4);g.lineTo(100,100);g.lineTo(-100,100);g.closePath();g.fill();g.restore();
 /* mantle head */
 const sk=pzGr(g,'pzno_head',0,-90,0,50,[[0,'#ff9ae4'],[.55,'#e65ac4'],[1,'#a83296']]);
 pzBlob(g,sk,()=>{g.moveTo(-66,26);g.bezierCurveTo(-80,-40,-56,-88,0,-90);g.bezierCurveTo(56,-88,80,-40,66,26);g.bezierCurveTo(42,50,-42,50,-66,26)},4.5);
 /* colour waves over the skin (chromatophores) */
 for(let i=0;i<14;i++){const x=Math.sin(i*2.4)*48,y=-76+((i*23)%60),w=.5+.5*Math.sin(t*2.2-y*.06+x*.02);g.fillStyle=w>.6?`rgba(255,220,250,${(w-.6)*1.6})`:`rgba(120,20,110,${(.6-w)*.5})`;g.beginPath();g.ellipse(x,y,5+(i%3)*2,4+(i%2)*2,0,0,TAU);g.fill()}
 if(M.ang>.05){g.globalAlpha=M.ang*.45;pzBlob(g,'#ff2a3a',()=>{g.moveTo(-66,26);g.bezierCurveTo(-80,-40,-56,-88,0,-90);g.bezierCurveTo(56,-88,80,-40,66,26);g.bezierCurveTo(42,50,-42,50,-66,26)},0);g.globalAlpha=1}
 g.fillStyle='rgba(255,255,255,.3)';g.beginPath();g.ellipse(-26,-56,18,9,-.5,0,TAU);g.fill();
 /* eyes: gold with horizontal pupils, eyeshadow and lashes */
 for(const s of[-1,1]){g.fillStyle='rgba(120,70,220,.45)';g.beginPath();g.ellipse(s*27,-15,25,17,0,Math.PI,TAU);g.fill();
  pznEye(g,s*27,-8,20,ex,{skin:'#e65ac4',side:s,iris:'#ffcf3a',iris2:'#ff9a1a',pr:.55,bar:1});
  g.strokeStyle=PZ_O;g.lineWidth=2.6;g.lineCap='round';const ry=20*(.3+.7*Math.min(1,ex.eo));for(let j=0;j<3;j++){const a=-Math.PI/2+s*(.55+j*.32);g.beginPath();g.moveTo(s*27+Math.cos(a)*20,-8+Math.sin(a)*ry);g.lineTo(s*27+Math.cos(a)*28,-8+Math.sin(a)*(ry+8));g.stroke()}}
 pzBrowD(g,-27,-38,24,ex,1,'#ffd8f4',3.6);pzBrowD(g,27,-38,24,ex,-1,'#ffd8f4',3.6);
 pzBlush(g,-44,10,12,ex,'#ff4a9a');pzBlush(g,44,10,12,ex,'#ff4a9a');
 pzMouthD(g,0,26,32,ex,{in:'#4a0820',tongue:'#ff8aa8',line:'#d0104e',lw:5});g.fillStyle=PZ_O;g.beginPath();g.arc(32,18,2,0,TAU);g.fill();pzSweat(g,58,-44,t,ex);
 /* bubbles rising in the water */
 for(let i=0;i<6;i++){const ph=(t*.35+i*.17)%1,bx=-50+((i*41)%100)+Math.sin(t*2+i)*5,by=60-ph*130;g.strokeStyle=`rgba(220,250,255,${.7*Math.sin(ph*Math.PI)})`;g.lineWidth=1.6;g.beginPath();g.arc(bx,by,2+(i%3)*1.5,0,TAU);g.stroke()}
 /* the glass */
 g.strokeStyle=PZ_O;g.lineWidth=4;g.beginPath();g.arc(0,-6,94,0,TAU);g.stroke();g.strokeStyle='rgba(180,240,255,.55)';g.lineWidth=2;g.beginPath();g.arc(0,-6,90,0,TAU);g.stroke();
 g.strokeStyle='rgba(255,255,255,.7)';g.lineWidth=7;g.beginPath();g.arc(0,-6,80,Math.PI*1.12,Math.PI*1.42);g.stroke();g.lineWidth=4;g.beginPath();g.arc(0,-6,80,Math.PI*1.5,Math.PI*1.56);g.stroke();
 g.fillStyle='rgba(255,255,255,.18)';g.beginPath();g.ellipse(40,44,14,6,-.6,0,TAU);g.fill();
 g.restore();g.restore()};
/* ================= Facet: the calculating crystal ================= */
pzMon.facet=function(g,t,ex,p){const M=pznMood(ex),fy=Math.sin(t*1.3)*6,jit=M.rat>.1?M.rat*2.2:0,jx=jit?Math.sin(t*61)*jit:0,jy=jit?Math.cos(t*47)*jit:0;
 pzEll(g,'rgba(0,0,0,.24)',0,2,78+fy,10,0,0);pzGlow(g,0,-14,70,'rgba(140,240,255,1)',.35);
 g.save();g.translate(jx,-22-fy+jy);g.scale(1,1+p.breath);
 const cy=-150+M.sad*14,spin=t*(.55+M.ch*2.2),orx=104*(1+M.wow*.45),ory=24+M.wow*10;
 const shard=(a,i,front)=>{const z=Math.sin(a);if((z>=0)!==front)return;const x=Math.cos(a)*orx,y=cy+z*ory+Math.sin(t*2+i)*6+M.sad*24,sc=.82+.24*(z+1)/2,rot=t*(1+i*.2)+i;
  g.save();g.translate(x,y);g.rotate(rot);g.scale(sc,sc);pzBlob(g,i%2?'#c8f6ff':'#e8d8ff',()=>{g.moveTo(0,-15);g.lineTo(8,0);g.lineTo(0,15);g.lineTo(-8,0);g.closePath()},2.6);g.fillStyle='rgba(255,255,255,.6)';g.beginPath();g.moveTo(0,-15);g.lineTo(8,0);g.lineTo(0,0);g.closePath();g.fill();g.restore()};
 for(let i=0;i<7;i++)shard(spin+i*TAU/7,i,false);
 /* a cape of refracted light: two prismatic ribbons that ripple behind it, glowing (additive) and fading to nothing */
 {g.save();g.globalCompositeOperation='lighter';g.globalAlpha=.8-M.sad*.4;for(const s of[-1,1]){g.fillStyle=pzGr(g,'pznf_rib',0,-220,0,-20,[[0,'rgba(150,240,255,.55)'],[.45,'rgba(255,130,230,.35)'],[.8,'rgba(255,220,130,.18)'],[1,'rgba(255,220,130,0)']]);
  g.beginPath();g.moveTo(s*28,-222);for(let k=1;k<=8;k++){const u=k/8;g.lineTo(s*(34+u*120+Math.sin(t*1.8+u*4)*8*u),-222+u*200)}for(let k=8;k>=0;k--){const u=k/8;g.lineTo(s*(24+u*64+Math.sin(t*1.8+u*4+.8)*6*u),-200+u*186)}g.closePath();g.fill()}g.restore()}
 /* shoulder spikes */
 for(const s of[-1,1])for(let j=0;j<3;j++){const bx=s*(48+j*10),by=-196+j*10;pzBlob(g,j%2?'#bfefff':'#dcd0ff',()=>{g.moveTo(bx-6,by+8);g.lineTo(bx+s*(4+j*3),by-20+j*4);g.lineTo(bx+8,by+8);g.closePath()},2.6)}
 /* torso: cel-shaded facets around a glowing core */
 const V=[[0,-34],[-36,-104],[-62,-186],[-26,-230],[26,-230],[62,-186],[36,-104]],C=[0,-158];
 pzBlob(g,pzGr(g,'pznf_body',0,-230,0,-34,[[0,'#ecfdff'],[.45,'#9ee6ff'],[1,'#6a70d8']]),()=>{V.forEach(([x,y],i)=>i?g.lineTo(x,y):g.moveTo(x,y));g.closePath()},4.5);
 g.save();g.beginPath();V.forEach(([x,y],i)=>i?g.lineTo(x,y):g.moveTo(x,y));g.closePath();g.clip();
 for(let i=0;i<V.length;i++){const a=V[i],b=V[(i+1)%V.length];g.fillStyle=i%3===0?'rgba(255,255,255,.34)':i%3===1?'rgba(40,40,140,.16)':'rgba(255,255,255,.1)';g.beginPath();g.moveTo(C[0],C[1]);g.lineTo(a[0],a[1]);g.lineTo(b[0],b[1]);g.closePath();g.fill()}
 g.strokeStyle='rgba(255,255,255,.55)';g.lineWidth=1.6;for(const [x,y] of V){g.beginPath();g.moveTo(C[0],C[1]);g.lineTo(x,y);g.stroke()}
 /* the glint that sweeps the facets */
 {const gp=((t*.25)%1)*2-.4;if(gp>-.3&&gp<1.3){g.fillStyle='rgba(255,255,255,.55)';g.beginPath();g.moveTo(-90+gp*180,-240);g.lineTo(-70+gp*180,-240);g.lineTo(-130+gp*180,-30);g.lineTo(-150+gp*180,-30);g.closePath();g.fill()}}
 if(M.sad>.05){g.fillStyle=`rgba(20,20,70,${M.sad*.3})`;g.fillRect(-70,-240,140,210)}
 g.restore();
 /* core */
 {const pu=.7+.3*Math.sin(t*3),cc=M.ang>.3?'rgba(255,80,140,1)':'rgba(150,250,255,1)';pzGlow(g,C[0],C[1],40+pu*14,cc,.7);pzBlob(g,M.ang>.3?'#ff7ab0':'#ffffff',()=>{g.moveTo(0,C[1]-14*pu);g.lineTo(9,C[1]);g.lineTo(0,C[1]+14*pu);g.lineTo(-9,C[1]);g.closePath()},2.4)}
 /* cracks when rattled */
 if(M.rat>.1){g.strokeStyle=`rgba(255,255,255,${M.rat*.9})`;g.lineWidth=2;g.beginPath();g.moveTo(-30,-200);g.lineTo(-18,-176);g.lineTo(-28,-160);g.lineTo(-12,-128);g.moveTo(24,-120);g.lineTo(14,-96);g.lineTo(20,-80);g.stroke()}
 /* floating hands: the left turns a little holo-prism, the right gestures (to the chin when thinking) */
 {const hx=-106,hy=-128+Math.sin(t*1.6)*6-M.ch*40;g.save();g.translate(hx,hy);g.rotate(-.2);g.scale(1.5,1.5);pzBlob(g,'#d8f6ff',()=>{g.moveTo(-14,0);g.lineTo(0,-10);g.lineTo(14,0);g.lineTo(0,12);g.closePath()},3);for(let j=-1;j<=1;j++)pzBlob(g,'#bfefff',()=>{g.moveTo(j*8-3,-6);g.lineTo(j*9,-22-Math.abs(j)*-4);g.lineTo(j*8+3,-6);g.closePath()},2.2);g.restore();
  const pr=t*1.8;g.save();g.translate(hx,hy-44);g.globalAlpha=.85;g.strokeStyle='#7af8ff';g.lineWidth=2;g.beginPath();for(let k=0;k<3;k++){const a=pr+k*TAU/3;g.lineTo(Math.cos(a)*14,Math.sin(a)*7-Math.sin(pr+k)*4)}g.closePath();g.stroke();g.beginPath();g.moveTo(0,-16);for(let k=0;k<3;k++){const a=pr+k*TAU/3;g.moveTo(0,-16);g.lineTo(Math.cos(a)*14,Math.sin(a)*7-Math.sin(pr+k)*4)}g.stroke();pzGlow(g,0,-4,26,'rgba(120,240,255,1)',.5);g.restore()}
 {const think=pznCl(-ex.lx-.3)*pznCl(-ex.ly-.2)*2,hx=104-think*70,hy=-120+Math.sin(t*1.4+2)*6-think*140-M.ch*40;g.save();g.translate(hx,hy);g.rotate(.2-think*.6);g.scale(1.5,1.5);pzBlob(g,'#d8f6ff',()=>{g.moveTo(-14,0);g.lineTo(0,-10);g.lineTo(14,0);g.lineTo(0,12);g.closePath()},3);for(let j=-1;j<=1;j++)pzBlob(g,'#bfefff',()=>{g.moveTo(j*8-3,-6);g.lineTo(j*9,-22);g.lineTo(j*8+3,-6);g.closePath()},2.2);g.restore()}
 /* a halo ring for a neck */
 {const ny=-256+p.bob*.4;g.strokeStyle=PZ_O;g.lineWidth=7;g.beginPath();g.ellipse(0,ny,34,8,0,0,TAU);g.stroke();g.strokeStyle='#8ef0ff';g.lineWidth=3.5;g.stroke();pzGlow(g,0,ny,40,'rgba(140,240,255,1)',.35)}
 /* the gem head */
 g.save();g.translate(0,-296+p.bob*.8+Math.sin(t*1.9)*3);g.rotate(p.tilt*.5);g.scale(1.22,1.22);
 for(let i=0;i<3;i++){const a=t*1.2+i*TAU/3,x=Math.cos(a)*26,y=-74+Math.sin(a)*5;g.fillStyle=i%2?'#e8d8ff':'#c8f6ff';g.strokeStyle=PZ_O;g.lineWidth=2;g.beginPath();g.moveTo(x,y-8);g.lineTo(x+4,y);g.lineTo(x,y+8);g.lineTo(x-4,y);g.closePath();g.fill();g.stroke()}
 const HV=[[0,-58],[44,-34],[48,10],[0,40],[-48,10],[-44,-34]];
 pzBlob(g,pzGr(g,'pznf_head',0,-58,0,40,[[0,'#ffffff'],[.5,'#b8f0ff'],[1,'#8a8ae8']]),()=>{HV.forEach(([x,y],i)=>i?g.lineTo(x,y):g.moveTo(x,y));g.closePath()},4.5);
 g.fillStyle='rgba(255,255,255,.45)';g.beginPath();g.moveTo(0,-58);g.lineTo(-44,-34);g.lineTo(0,-30);g.closePath();g.fill();g.fillStyle='rgba(60,60,170,.16)';g.beginPath();g.moveTo(48,10);g.lineTo(0,40);g.lineTo(0,18);g.closePath();g.fill();
 g.strokeStyle='rgba(255,255,255,.6)';g.lineWidth=1.4;g.beginPath();g.moveTo(-44,-34);g.lineTo(0,-30);g.lineTo(44,-34);g.moveTo(0,-30);g.lineTo(0,-58);g.stroke();
 if(M.rat>.1){g.strokeStyle=`rgba(255,255,255,${M.rat})`;g.lineWidth=2;g.beginPath();g.moveTo(30,-40);g.lineTo(20,-22);g.lineTo(28,-10);g.stroke()}
 /* diamond eyes that glow, shard brows, a light-line mouth */
 const glowC=M.ang>.3?'rgba(255,120,170,1)':'rgba(140,250,255,1)';
 for(const s of[-1,1]){const x=s*20,y=-10,ry=Math.max(1.8,17*Math.min(1.2,ex.eo)),rx=12+M.wow*3;pzGlow(g,x,y,24,glowC,.55*Math.min(1,ex.eo));g.fillStyle='#ffffff';g.strokeStyle=PZ_O;g.lineWidth=2.6;g.beginPath();g.moveTo(x,y-ry);g.lineTo(x+rx,y);g.lineTo(x,y+ry);g.lineTo(x-rx,y);g.closePath();g.fill();g.stroke();
  if(ex.eo>.3){const px=x+ex.lx*5,py=y+ex.ly*5,k=Math.min(1,ex.eo);g.fillStyle=M.ang>.3?'#c8104e':'#1a4ab8';g.beginPath();g.moveTo(px,py-7*k);g.lineTo(px+5,py);g.lineTo(px,py+7*k);g.lineTo(px-5,py);g.closePath();g.fill();g.fillStyle='#fff';g.beginPath();g.arc(px-1.5,py-2.5*k,1.6,0,TAU);g.fill()}
  g.save();g.translate(x,-36-ex.bh*6);g.rotate(s*(-ex.br)*.45);g.fillStyle='#4a5ab8';g.strokeStyle=PZ_O;g.lineWidth=2;g.beginPath();g.moveTo(-13,2);g.lineTo(0,-4);g.lineTo(13,2);g.lineTo(0,4);g.closePath();g.fill();g.stroke();g.restore()}
 {const my=20,w=26,c=ex.mo*8,o=ex.ma*10;g.strokeStyle=M.ang>.3?'#ff7ab0':'#2a6ab8';g.lineWidth=3;g.lineCap='round';if(o>2){g.fillStyle='#1a2a6a';g.beginPath();g.moveTo(-w/2,my);g.quadraticCurveTo(0,my+c*2-o,w/2,my);g.quadraticCurveTo(0,my+c*2+o*1.4,-w/2,my);g.closePath();g.fill();g.stroke()}else{g.beginPath();g.moveTo(-w/2,my);g.quadraticCurveTo(0,my+c*2,w/2,my);g.stroke()}}
 if(ex.bl>.05){g.globalAlpha=ex.bl*.5;g.fillStyle='#ff9ad8';for(const s of[-1,1]){g.beginPath();g.moveTo(s*34,4);g.lineTo(s*40,8);g.lineTo(s*34,12);g.lineTo(s*28,8);g.closePath();g.fill()}g.globalAlpha=1}
 pzSweat(g,46,-30,t,ex);
 /* numbers drift round its head while it calculates */
 {const k=pznCl(-ex.lx-.3)+(M.ch+M.sad+M.ang+M.rat+M.wow<.2?.35:0);if(k>.05){g.font='800 13px Poppins,sans-serif';g.textAlign='center';const gl=['π','∑','%','√','7','∞'];for(let i=0;i<4;i++){const ph=(t*.45+i*.25)%1;g.globalAlpha=Math.min(1,k)*Math.sin(ph*Math.PI)*.9;g.fillStyle=i%2?'#8ef0ff':'#e8d8ff';g.fillText(gl[(i+Math.floor(t*.45+i*.25))%6],-56+i*36+Math.sin(t+i)*6,-50-ph*40)}g.globalAlpha=1}}
 g.restore();
 for(let i=0;i<7;i++)shard(spin+i*TAU/7,i,true);
 /* sparkles on a cheer or a wow */
 if(M.ch+M.wow>.2){g.fillStyle='#ffffff';for(let i=0;i<6;i++){const ph=(t*1.2+i*.17)%1;g.globalAlpha=Math.min(1,M.ch+M.wow)*Math.sin(ph*Math.PI);pznStar4(g,Math.cos(i*2.1+t)*(70+ph*40),cy-60+Math.sin(i*1.7)*90,6+ph*6)}g.globalAlpha=1}
 g.restore()};
/* ================= Rex Nova: the comet kid ================= */
pzMon.rex=function(g,t,ex,p){const M=pznMood(ex),sk='#2ac89a';g.save();g.scale(1,1+p.breath);
 pzEll(g,'rgba(0,0,0,.3)',0,2,110,13,0,0);
 /* the tail swishes behind him */
 {const sw=Math.sin(t*1.7)*18+M.ch*10*Math.sin(t*9);const L=pznLimb(g,-14,-74,-90,-40+sw*.3,-150,-26+sw,34,6,sk,3.5,-.6);g.fillStyle='rgba(10,80,60,.45)';for(let j=2;j<L.pts.length-4;j+=2){const q=L.pts[j];g.beginPath();g.ellipse(q[0],q[1]-3,5,3,0,0,TAU);g.fill()}}
 /* jetpack and its flames */
 {for(const s of[-1,1]){g.save();g.translate(s*80,0);g.rotate(s*.12);pzBlob(g,pzGr(g,'pznr_jp',-20,0,20,0,[[0,'#7a8494'],[.45,'#e8eef8'],[1,'#5a6474']]),()=>{g.roundRect(-20,-268,40,108,16)},3.5);pzBlob(g,'#e8263a',()=>{g.moveTo(-20,-250);g.quadraticCurveTo(0,-290,20,-250);g.closePath()},3);
   pzBlob(g,'#3a3a4a',()=>{g.moveTo(-13,-162);g.lineTo(13,-162);g.lineTo(17,-144);g.lineTo(-17,-144);g.closePath()},3);g.fillStyle='rgba(255,255,255,.55)';g.fillRect(-12,-254,5,82);g.fillStyle='#ffd23a';g.fillRect(-20,-206,40,7);g.strokeStyle=PZ_O;g.lineWidth=2;g.strokeRect(-20,-206,40,7);g.restore()}
  const pw=M.sad>.4?(Math.sin(t*17)>.4?.25:0):.55+.45*M.ch+.15*Math.sin(t*31),L=(22+pw*60)*(1+.12*Math.sin(t*41));
  if(pw>0)for(const s of[-1,1]){const x=s*(80+17),y0=-142;pzGlow(g,x,y0+20,30+pw*30,'rgba(255,170,60,1)',.6*pw);g.fillStyle='#ff7a2a';g.beginPath();g.moveTo(x-14,y0);g.quadraticCurveTo(x-9,y0+L*.5,x,y0+L);g.quadraticCurveTo(x+9,y0+L*.5,x+14,y0);g.closePath();g.fill();g.fillStyle='#ffe27a';g.beginPath();g.moveTo(x-8,y0);g.quadraticCurveTo(x-3,y0+L*.35,x,y0+L*.6);g.quadraticCurveTo(x+3,y0+L*.35,x+8,y0);g.closePath();g.fill()}}
 /* legs and boots */
 for(const s of[-1,1]){pzBlob(g,pzGr(g,'pznr_leg',0,-90,0,-10,[[0,'#2a3a6a'],[1,'#141c3a']]),()=>{g.roundRect(s*26-15,-92,30,74,10)},3.5);
  pzBlob(g,'#3a2a2a',()=>{g.moveTo(s*26-20,-30);g.lineTo(s*26+20,-30);g.quadraticCurveTo(s*26+s*40,-24,s*26+s*36,-4);g.lineTo(s*26-20,-4);g.closePath()},3.5);g.fillStyle='#ff7a2a';g.fillRect(s*26-20+(s>0?0:-8),-8,48,5);g.fillStyle='#ffd23a';g.beginPath();g.moveTo(s*26-4,-26);g.lineTo(s*26+4,-26);g.lineTo(s*26-2,-16);g.lineTo(s*26+6,-16);g.lineTo(s*26-6,-6);g.lineTo(s*26-2,-16);g.lineTo(s*26-8,-16);g.closePath();g.fill()}
 /* the bomber jacket */
 pzBlob(g,pzGr(g,'pznr_jk',0,-216,0,-80,[[0,'#ff7a3a'],[.6,'#d84a1e'],[1,'#9a2e12']]),()=>{g.moveTo(-74,-196);g.quadraticCurveTo(-86,-130,-52,-86);g.lineTo(52,-86);g.quadraticCurveTo(86,-130,74,-196);g.quadraticCurveTo(0,-222,-74,-196)},4.5);
 g.fillStyle='#3a1a14';g.fillRect(-52,-98,104,14);g.strokeStyle='rgba(255,180,120,.4)';g.lineWidth=1.6;for(let i=-4;i<=4;i++){g.beginPath();g.moveTo(i*11,-97);g.lineTo(i*11,-86);g.stroke()}g.strokeStyle=PZ_O;g.lineWidth=2.6;g.strokeRect(-52,-98,104,14);
 g.strokeStyle='#ffd23a';g.lineWidth=3;g.beginPath();g.moveTo(4,-200);g.lineTo(2,-98);g.stroke();g.fillStyle='#ffd23a';g.fillRect(-2,-160,9,12);
 g.fillStyle='#ffd23a';g.strokeStyle=PZ_O;g.lineWidth=2.4;{const sx=-36,sy=-150;g.beginPath();for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,r=i%2?6:14;g.lineTo(sx+Math.cos(a)*r,sy+Math.sin(a)*r)}g.closePath();g.fill();g.stroke()}
 g.fillStyle='rgba(255,255,255,.2)';g.beginPath();g.ellipse(-44,-176,10,22,.3,0,TAU);g.fill();
 /* arms: hands on hips, or a finger-gun and a fist pump when cheering */
 const hand=(x,y,a)=>{g.save();g.translate(x,y);g.rotate(a);pzEll(g,sk,0,0,13,11,0,3);for(let j=-1;j<=1;j++){pzEll(g,sk,12,j*7,7,4,j*.3,2.4);pzEll(g,'#9affe0',17,j*7.5,3,3,0,0)}g.restore()};
 for(const s of[-1,1]){const up=s<0?M.ch:0,hx=s*(64+up*8),hy=-112-up*124,ex2=s*86,ey=-156-up*50;g.lineCap='round';g.strokeStyle=PZ_O;g.lineWidth=26;g.beginPath();g.moveTo(s*62,-190);g.quadraticCurveTo(ex2,ey,hx,hy);g.stroke();g.strokeStyle='#d84a1e';g.lineWidth=19;g.stroke();g.strokeStyle='#3a1a14';g.lineWidth=19;g.beginPath();g.moveTo(hx+(ex2-hx)*.12,hy+(ey-hy)*.12);g.lineTo(hx,hy);g.stroke();hand(hx,hy+4,s>0?(Math.PI*.9):(up>.3?-Math.PI/2:Math.PI*.1))}
 /* the fur collar and bandana */
 pzBlob(g,'#f4e8d0',()=>{for(let i=0;i<=8;i++){const a=Math.PI*(1.05+i*.1125),x=Math.cos(a)*62,y=-196+Math.sin(a)*16;i?g.quadraticCurveTo(x+Math.cos(a)*10,y+Math.sin(a)*10-6,x,y):g.moveTo(x,y)}g.quadraticCurveTo(30,-178,0,-182);g.quadraticCurveTo(-30,-178,-62,-196)},3.5);
 pzBlob(g,'#e8263a',()=>{g.moveTo(-30,-206);g.lineTo(30,-206);g.lineTo(6,-176);g.lineTo(0,-170);g.lineTo(-6,-176);g.closePath()},3);g.fillStyle='#fff';for(const [x,y] of[[-14,-200],[10,-198],[0,-188]]){g.beginPath();g.arc(x,y,1.6,0,TAU);g.fill()}
 /* the head */
 g.save();g.translate(0,-250+p.bob);g.rotate(p.tilt*.6+Math.sin(t*1.1)*.02);
 /* the crest: a swept pompadour fin that bounces (flares red when angry, droops when sad) */
 {g.save();g.translate(-6,-34);g.rotate(Math.sin(t*3.2)*.05+M.sad*.45-M.ch*.08);const an=M.ang>.4;
  pzBlob(g,pzGr(g,'pznr_crest'+(an?'a':''),0,-80,0,0,[[0,an?'#ffb08a':'#ffd23a'],[1,an?'#ff1a2a':'#ff7a2a']]),()=>{g.moveTo(-40,4);g.quadraticCurveTo(-44,-50,-10,-74);g.quadraticCurveTo(-6,-56,6,-58);g.quadraticCurveTo(22,-88,60,-80);g.quadraticCurveTo(42,-66,46,-50);g.quadraticCurveTo(70,-54,82,-34);g.quadraticCurveTo(50,-26,44,-6);g.closePath()},4);
  g.strokeStyle='rgba(120,30,10,.5)';g.lineWidth=2.4;g.beginPath();g.moveTo(-26,-6);g.quadraticCurveTo(-24,-40,-6,-56);g.moveTo(4,-8);g.quadraticCurveTo(14,-50,48,-70);g.moveTo(24,-8);g.quadraticCurveTo(40,-30,70,-38);g.stroke();
  /* goggles on the crest */
  g.strokeStyle='#3a2a1a';g.lineWidth=6;g.beginPath();g.moveTo(-36,-14);g.quadraticCurveTo(10,-30,52,-14);g.stroke();for(const gx of[-6,26]){pzEll(g,'#c8902a',gx,-24,13,11,0,3.2);pzEll(g,'#5ad8ff',gx,-24,8,7,0,0);g.fillStyle='rgba(255,255,255,.75)';g.beginPath();g.arc(gx-3,-27,2.6,0,TAU);g.fill()}g.restore()}
 pzBlob(g,pzGr(g,'pznr_head',0,-60,0,40,[[0,'#7afcd0'],[.6,'#2ac89a'],[1,'#178a70']]),()=>{g.moveTo(-70,-6);g.bezierCurveTo(-76,-56,-30,-62,0,-60);g.bezierCurveTo(36,-62,80,-52,76,-6);g.bezierCurveTo(74,26,40,40,0,40);g.bezierCurveTo(-40,40,-70,26,-70,-6)},4.5);
 g.fillStyle='rgba(10,90,70,.35)';for(const [x,y,r] of[[-50,8,5],[-40,22,3.5],[52,10,4.5],[44,24,3],[-14,-44,3.5],[20,-48,3]]){g.beginPath();g.arc(x,y,r,0,TAU);g.fill()}
 g.fillStyle='rgba(255,255,255,.28)';g.beginPath();g.ellipse(-30,-44,22,8,-.3,0,TAU);g.fill();
 /* big gecko eyes on top of the head */
 const er=22*(1+M.wow*.22);for(const s of[-1,1]){pzEll(g,sk,s*38,-36,er+7,er+5,0,4);pznEye(g,s*38,-36,er,ex,{skin:'#3ae0b0',side:s,iris:'#ffd23a',iris2:'#ff9a1a',pr:.62,slit:1})}
 {g.strokeStyle='#ff9ab0';g.lineWidth=3;g.lineCap='round';g.beginPath();g.moveTo(-62,-58);g.lineTo(-48,-36);g.moveTo(-60,-44);g.lineTo(-52,-49);g.stroke()}
 pzBrowD(g,-38,-66,30,ex,1,'#0a5a46',5);pzBrowD(g,38,-66,30,ex,-1,'#0a5a46',5);
 g.fillStyle=PZ_O;for(const s of[-1,1]){g.beginPath();g.ellipse(s*9,-4,2.6,1.8,0,0,TAU);g.fill()}
 pzMouthD(g,0,16,64,ex,{in:'#3a0e18',tongue:'#ff6a8a',lw:4});pzBlush(g,-54,10,12,ex,'#ff7a9a');pzBlush(g,54,10,12,ex,'#ff7a9a');pzSweat(g,70,-40,t,ex);
 /* gum: a bubble grows and pops every 7 s; rattled, it bursts on his face */
 {const ph=t%7,mx=26,my=22;if(M.rat>.35){g.globalAlpha=M.rat;g.fillStyle='#ff8ac8';for(const [x,y,r] of[[20,10,13],[34,0,9],[8,22,8],[42,18,7],[-10,4,6]]){g.beginPath();g.arc(x,y,r,0,TAU);g.fill()}g.globalAlpha=1}
  else if(ex.ma<.35&&ph>2.5&&ph<6.2){const r=Math.min(26,(ph-2.5)*7.5)*(1+.04*Math.sin(t*8));pzEll(g,'rgba(255,138,200,.92)',mx+r*.55,my+r*.15,r,r*.94,0,3);g.fillStyle='rgba(255,255,255,.7)';g.beginPath();g.ellipse(mx+r*.3,my-r*.3,r*.28,r*.16,-.6,0,TAU);g.fill()}
  else if(ph>=6.2&&ph<6.5){const u=(ph-6.2)/.3;g.fillStyle=`rgba(255,138,200,${1-u})`;for(let i=0;i<7;i++){const a=i/7*TAU;g.beginPath();g.arc(mx+14+Math.cos(a)*(10+u*24),my+Math.sin(a)*(10+u*24),3,0,TAU);g.fill()}}}
 g.restore();g.restore()};
/* ================= Empress Vantara: the event horizon ================= */
let PZN_STARS=null;
function pznStarTile(){if(PZN_STARS)return PZN_STARS;const c=pzCv(160,160),g=c.getContext('2d');for(let i=0;i<70;i++){const x=pzNoise(i*3.1)*160,y=pzNoise(i*7.7+2)*160,r=pzNoise(i*1.3+5)*1.4+.3;g.fillStyle=i%5?`rgba(230,220,255,${.35+pzNoise(i)*.6})`:'rgba(255,200,240,.9)';g.beginPath();g.arc(x,y,r,0,TAU);g.fill()}
 for(let i=0;i<4;i++){const x=pzNoise(i*13.3)*160,y=pzNoise(i*5.9+1)*160;g.fillStyle='rgba(255,255,255,.9)';pznStar4(g,x,y,4)}return PZN_STARS=c}
pzMon.vantara=function(g,t,ex,p){const M=pznMood(ex),fy=Math.sin(t*1.0)*5,hemY=-12;
 pzEll(g,'rgba(0,0,0,.26)',0,2,130,13,0,0);pzGlow(g,0,-20,120,'rgba(170,110,255,1)',.3);
 g.save();g.translate(0,-fy);g.scale(1,1+p.breath*.8);
 /* the collar fan behind the head: gold crescent spikes */
 {g.save();g.translate(0,-300+p.bob);for(let i=0;i<7;i++){const a=-Math.PI*(.12+i*.127),r0=58,r1=112+(i%2?-14:10);pzBlob(g,i%2?'#3a1a7a':'#e8c060',()=>{g.moveTo(Math.cos(a-.12)*r0,Math.sin(a-.12)*r0);g.lineTo(Math.cos(a)*r1,Math.sin(a)*r1);g.lineTo(Math.cos(a+.12)*r0,Math.sin(a+.12)*r0);g.closePath()},3)}g.restore()}
 /* the belt planet behind her */
 const ba=t*1.2,bx=Math.cos(ba)*70,by=-170+Math.sin(ba)*14,bead=()=>{pzEll(g,'#5af0ff',bx,by,7,7,0,2.4);g.strokeStyle='#ffe0a0';g.lineWidth=1.6;g.beginPath();g.ellipse(bx,by,12,3,-.3,0,TAU);g.stroke()};if(Math.sin(ba)<0)bead();
 /* the gown: a nebula with stars, a rippling hem, gold trim */
 const gown=()=>{g.moveTo(-56,-232);g.quadraticCurveTo(-30,-176,-40,-168);g.bezierCurveTo(-70,-120,-120,-60,-150,hemY);for(let i=0;i<=10;i++){const x=-150+i*30;g.lineTo(x,hemY+Math.sin(t*2.4+i*.9)*6+(i%2?6:0))}g.bezierCurveTo(120,-60,70,-120,40,-168);g.quadraticCurveTo(30,-176,56,-232);g.quadraticCurveTo(0,-246,-56,-232)};
 pzBlob(g,pzGr(g,'pznv_gown',0,-240,0,0,[[0,'#140830'],[.55,'#2a1060'],[1,'#5a2aa8']]),gown,4.5);
 g.save();g.beginPath();gown();g.clip();
 g.fillStyle=pzGrR(g,'pznv_neb1',-60,-70,4,90,[[0,'rgba(255,90,200,.42)'],[1,'rgba(255,90,200,0)']]);g.fillRect(-160,-170,200,170);
 g.fillStyle=pzGrR(g,'pznv_neb2',60,-110,4,80,[[0,'rgba(90,220,255,.32)'],[1,'rgba(90,220,255,0)']]);g.fillRect(-20,-200,180,180);
 g.save();g.translate(Math.sin(t*.1)*20,(t*4)%160);g.fillStyle=pznPat(g,'pznv_st',pznStarTile);g.fillRect(-190,-420,380,600);g.restore();
 for(let i=0;i<7;i++){const a=.5+.5*Math.sin(t*2.2+i*2.1);if(a<.7)continue;g.fillStyle=`rgba(255,255,255,${(a-.7)*3})`;pznStar4(g,-100+((i*67)%200)*(.4+((i*13)%10)/16),-30-((i*41)%150),5+i%3)}
 g.restore();
 g.strokeStyle='#e8c060';g.lineWidth=3;g.beginPath();g.moveTo(-40,-168);g.bezierCurveTo(-60,-110,-96,-56,-118,-14);g.moveTo(40,-168);g.bezierCurveTo(60,-110,96,-56,118,-14);g.stroke();
 /* the bodice and the front of the orbit belt */
 pzBlob(g,pzGr(g,'pznv_bod',0,-240,0,-160,[[0,'#3a1a7a'],[1,'#1a0a3a']]),()=>{g.moveTo(-54,-232);g.quadraticCurveTo(-48,-190,-38,-166);g.quadraticCurveTo(0,-156,38,-166);g.quadraticCurveTo(48,-190,54,-232);g.quadraticCurveTo(0,-244,-54,-232)},4);
 g.fillStyle='#e8c060';g.beginPath();g.moveTo(0,-238);g.lineTo(10,-210);g.lineTo(0,-184);g.lineTo(-10,-210);g.closePath();g.fill();g.strokeStyle=PZ_O;g.lineWidth=2.2;g.stroke();pzEll(g,'#ff6ad5',0,-210,4,4,0,1.6);
 g.strokeStyle='#e8c060';g.lineWidth=3.5;g.beginPath();g.ellipse(0,-170,70,14,0,0,Math.PI);g.stroke();g.strokeStyle=PZ_O;g.lineWidth=1.4;g.beginPath();g.ellipse(0,-170,72,16,0,0,Math.PI);g.stroke();
 if(Math.sin(ba)>=0)bead();
 /* arms: the left rests low, the right turns a void 8-ball in its orbit */
 const glove=pzGr(g,'pznv_gl',0,-240,0,-120,[[0,'#2a1458'],[1,'#120830']]);
 {const hx=-98,hy=-136+Math.sin(t*1.3)*4-M.ch*70;pznLimb(g,-50,-228,-92,-206,hx+2,hy-22,22,40,'#2a1060',3.5,0);g.strokeStyle='#e8c060';g.lineWidth=3;g.beginPath();g.moveTo(hx-18,hy-26);g.lineTo(hx+22,hy-18);g.stroke();pzEll(g,'#2a1458',hx,hy,10,12,0,3);for(let j=0;j<4;j++){const fx=hx-6+j*4,fy2=hy+12+Math.abs(j-1.5)*-1.5;g.fillStyle='#ffe8ff';g.beginPath();g.arc(fx,fy2,1.8,0,TAU);g.fill()}}
 {const hx=104,hy=-232+Math.sin(t*1.1)*5-M.ch*20;pznLimb(g,50,-228,96,-180,hx-4,hy+20,22,38,'#2a1060',3.5,0);g.strokeStyle='#e8c060';g.lineWidth=3;g.beginPath();g.moveTo(hx-22,hy+14);g.lineTo(hx+14,hy+28);g.stroke();
  pzBlob(g,glove,()=>{g.moveTo(hx-16,hy);g.quadraticCurveTo(hx,hy+10,hx+18,hy-2);g.lineTo(hx+16,hy-8);g.quadraticCurveTo(hx,hy-4,hx-14,hy-8);g.closePath()},3);
  for(let j=0;j<4;j++){g.fillStyle='#ffe8ff';g.beginPath();g.arc(hx-12+j*9,hy-9,1.8,0,TAU);g.fill()}
  const ox=hx,oy=hy-46+Math.sin(t*2)*4,spinA=t*(1.4+M.ch*3),tilt=-.35;pzGlow(g,ox,oy,40,'rgba(180,120,255,1)',.5+.3*M.ch);
  g.strokeStyle='rgba(200,160,255,.65)';g.lineWidth=2;g.beginPath();g.ellipse(ox,oy,30,8,tilt,Math.PI,TAU);g.stroke();
  g.save();g.translate(ox,oy);pzEll(g,pzGrR(g,'pznv_8',-6,-6,1,20,[[0,'#3a2a5a'],[1,'#050208']]),0,0,17,17,0,3);g.restore();g.fillStyle='#f4f0ff';g.beginPath();g.arc(ox+Math.cos(spinA)*3,oy-2,7.5,0,TAU);g.fill();g.fillStyle='#120a20';g.font='800 10px Poppins,sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillText('8',ox+Math.cos(spinA)*3,oy-1.5);g.textBaseline='alphabetic';
  g.strokeStyle='rgba(220,190,255,.9)';g.lineWidth=2;g.beginPath();g.ellipse(ox,oy,30,8,tilt,0,Math.PI);g.stroke();
  for(let i=0;i<5;i++){const a=spinA*1.6+i*1.26,r=30-((t*20+i*6)%24);g.fillStyle='rgba(255,230,255,.85)';g.beginPath();g.arc(ox+Math.cos(a)*r,oy+Math.sin(a)*r*.3,1.5,0,TAU);g.fill()}}
 /* the head: a void sphere wrapped in its accretion disk (the back half first) */
 g.save();g.translate(0,-302+p.bob);g.rotate(p.tilt*.5);
 const wob=M.rat*Math.sin(t*9)*.18,dt=-.16+wob,dA=1-M.sad*.55,hot=M.ang;
 const disk=(front)=>{g.save();g.rotate(dt);const a0=front?0:Math.PI,a1=front?Math.PI:TAU,c1=hot>.2?'rgba(255,90,60,':'rgba(170,110,255,',c2=hot>.2?'rgba(255,170,90,':'rgba(255,180,120,';
  g.lineCap='butt';g.strokeStyle=c1+(.55*dA)+')';g.lineWidth=20;g.beginPath();g.ellipse(0,0,96,24,0,a0,a1);g.stroke();g.strokeStyle=c2+(.85*dA)+')';g.lineWidth=10;g.beginPath();g.ellipse(0,0,90,21,0,a0,a1);g.stroke();
  g.strokeStyle=`rgba(255,248,230,${.9*dA})`;g.lineWidth=3.5;g.beginPath();g.ellipse(0,0,84,19,0,a0,a1);g.stroke();
  g.setLineDash([14,22]);g.lineDashOffset=-t*(60+M.ch*120);g.strokeStyle=`rgba(255,255,255,${.6*dA})`;g.lineWidth=2;g.beginPath();g.ellipse(0,0,100,26,0,a0,a1);g.stroke();g.beginPath();g.ellipse(0,0,88,20,0,a0,a1);g.stroke();g.setLineDash([]);
  g.strokeStyle=PZ_O;g.lineWidth=2.5;g.beginPath();g.ellipse(0,0,107,30,0,a0,a1);g.stroke();g.restore()};
 disk(false);
 pzGlow(g,0,0,92,hot>.2?'rgba(255,110,70,1)':'rgba(170,120,255,1)',(.35+M.ch*.4)*dA);
 pzEll(g,pzGrR(g,'pznv_void',-10,-12,2,50,[[0,'#140a2a'],[.8,'#030108'],[1,'#000000']]),0,0,46,46,0,4.5);
 g.strokeStyle=`rgba(230,210,255,${.75*dA})`;g.lineWidth=2;g.beginPath();g.arc(0,0,42,0,TAU);g.stroke();g.strokeStyle='rgba(255,255,255,.18)';g.lineWidth=3;g.beginPath();g.arc(0,0,38,Math.PI*1.1,Math.PI*1.5);g.stroke();
 /* the face: glowing almond eyes, light brows, a light mouth */
 for(const s of[-1,1]){const x=s*17,y=-6,eo=Math.max(.06,Math.min(1.25,ex.eo)),h=7.5*eo*(1+M.wow*.3),w=12+M.wow*2;pzGlow(g,x,y,22,hot>.3?'rgba(255,120,90,1)':'rgba(210,170,255,1)',.7*Math.min(1,eo));
  g.fillStyle='#f4ecff';g.beginPath();g.moveTo(x-w,y);g.quadraticCurveTo(x,y-h*2,x+w,y);g.quadraticCurveTo(x,y+h*1.4,x-w,y);g.closePath();g.fill();
  if(eo>.3){g.fillStyle=hot>.3?'#ff3a3a':'#7a3aff';g.beginPath();g.arc(x+ex.lx*5,y+ex.ly*3,3.4*Math.min(1,eo),0,TAU);g.fill()}
  /* slanted lid for angry / sad */
  if(Math.abs(ex.br)>.1){g.fillStyle='#030108';g.beginPath();const k=ex.br;if(k>0){g.moveTo(x-w-2,y-h*2-2);g.lineTo(x+w+2,y-h*2-2);g.lineTo(s>0?x+w+2:x+w+2,s>0?y-h*2+k*h*2.4:y-h*1.2);g.lineTo(x-w-2,s>0?y-h*1.2:y-h*2+k*h*2.4)}else{g.moveTo(x-w-2,y-h*2-2);g.lineTo(x+w+2,y-h*2-2);g.lineTo(x+w+2,s>0?y-h*1.4:y-h*2-k*h*1.8);g.lineTo(x-w-2,s>0?y-h*2-k*h*1.8:y-h*1.4)}g.closePath();g.fill()}
  g.save();g.translate(x,-22-ex.bh*5);g.rotate(s*(-ex.br)*.4);g.strokeStyle='rgba(230,210,255,.85)';g.lineWidth=2.2;g.lineCap='round';g.beginPath();g.moveTo(-10,1);g.quadraticCurveTo(0,-3,10,1);g.stroke();g.restore()}
 {const my=18,w=22,c=ex.mo*6,o=ex.ma*8;g.strokeStyle=hot>.3?'rgba(255,150,120,.95)':'rgba(230,200,255,.95)';g.lineWidth=2.6;g.lineCap='round';if(o>2){g.fillStyle='#000';g.beginPath();g.moveTo(-w/2,my);g.quadraticCurveTo(0,my+c*2-o*.5,w/2,my);g.quadraticCurveTo(0,my+c*2+o*1.5,-w/2,my);g.closePath();g.fill();g.stroke()}else{g.beginPath();g.moveTo(-w/2,my);g.quadraticCurveTo(0,my+c*2,w/2,my);g.stroke()}}
 if(ex.bl>.05){g.globalAlpha=ex.bl*.45;g.fillStyle='#ff6ad5';for(const s of[-1,1]){g.beginPath();g.ellipse(s*28,8,7,3.5,0,0,TAU);g.fill()}g.globalAlpha=1}
 disk(true);
 /* three little moons for a crown */
 for(let i=0;i<3;i++){const a=t*.9+i*TAU/3,x=Math.cos(a)*34,y=-66+Math.sin(a)*7,r=[7,5,6][i];pzEll(g,['#f4ecd8','#8ef0ff','#ff9ad8'][i],x,y,r,r,0,2.4);g.fillStyle='rgba(0,0,0,.25)';g.beginPath();g.arc(x+r*.35,y+r*.2,r*.7,0,TAU);g.fill()}
 pzSweat(g,44,-34,t,ex);
 g.restore();
 /* a lensing ripple now and then */
 {const ph=(t*.2)%1;if(ph<.45){const u=ph/.45;g.strokeStyle=`rgba(200,170,255,${(1-u)*.35})`;g.lineWidth=2.5;g.globalAlpha=(1-u)*.6;g.beginPath();g.ellipse(0,-300,50+u*130,14+u*36,-.16,0,TAU);g.stroke();g.globalAlpha=1
}}
 /* motes drifting off the hem */
 for(let i=0;i<6;i++){const ph=(t*.25+i*.166)%1;g.fillStyle=`rgba(220,200,255,${.7*(1-ph)})`;g.beginPath();g.arc(-120+((i*47)%240)+Math.sin(t+i)*6,hemY+4+ph*-60*(i%2?1:-.2),1.6+(i%2),0,TAU);g.fill()}
 g.restore()};
