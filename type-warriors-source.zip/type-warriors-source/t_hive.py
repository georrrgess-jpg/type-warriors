# python3 t_hive.py [game.html] : the Clockwork Hive (98h art, 98i battle), the eleventh tower of Runestone Tower Defense.
# Key H, 350 supply, ground and air; bees seek, circle and sting (armor-piercing 2), honey slows 15%; tier 3 honey puddles, tier 4 pollen
# (+10% damage to towers within 150 px, no stacking), tier 5 the Queen's sting burst; Overcharge, the Starfall mark, jams, Rune Typing,
# Performance mode (fewer bees drawn, same damage), the info panel, the tower bar with eleven cards, frame cost, a full wave.
import asyncio,os,sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:500]),flush=True)
    if not ok:FAIL.append(name)
HELP=r"""()=>{
 window.tdBuild=(R,p,t,tier)=>{rpBuild(p,t);const tw=p.tw;tw.build=1;while(tw.tier<(tier||1)&&rpUpgrade(tw));tw.upK=1;return tw};
 window.tdNew=(map,wave)=>{try{rpLeave()}catch(e){}rpStart(map);const R=RPX;R.tut=null;R.hold=false;R.supply=1e9;R.wst='run';R.wave=wave||1;R.q=[];R.banner=null;R.toast=null;R.foes=[];return R};
 window.tdFoe=(R,id,s,pi)=>{const e=rpSpawn(id,pi||0);e.s=s;e.sp=0;return e};
 window.tdRun=(R,sec)=>{for(let i=0;i<Math.round(sec*30);i++)rpStep(R,1/30)};
 /* the road point nearest a pad (path pi) and the pad that has the road closest to it */
 window.tdNear=(R,pad,pi)=>{let best=0,bd=1e9;const L=R.G.paths[pi||0].len;for(let s=0;s<L;s+=4){const q=rpAt(R.G,s,pi||0),d=Math.hypot(q.x-pad.x,q.y-pad.y);if(d<bd){bd=d;best=s}}return best};
 window.tdPad=(R)=>{let best=null,bd=1e9;for(const p of R.pads){const s=tdNear(R,p,0),q=rpAt(R.G,s,0),d=Math.hypot(q.x-p.x,q.y-p.y);if(d>70&&d<bd&&p.x>250&&p.x<1350){bd=d;best=p}}return best};
 return 1}"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        pg.on('console',lambda m:er.append('console: '+m.text[:300]) if m.type=='error' and 'WebSocket' not in m.text and 'net::' not in m.text else None)
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E("()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const r=RPP();r.new99j=1;r.dragon=1;r.stars=Object.assign(r.stars||{},{moss:3,frost:3,ember:3});for(const k in r.tut)r.tut[k]=1;for(const k of['build','wave','coins','upgrade','abil','rune','twist','twist_frost','twist_ember','twist_wonder'])r.tut[k]=1;save()}")
        await E(HELP)
        # ---- data
        r=await E("()=>{const T=RP_TW.hive,i=RP_TWORDER.indexOf('hive');return [i,RP_KEYS[i],RPTW.hive.n,T.cost,T.air,T.ground,T.bees,T.range,T.ap,RPSKIN.hive,[1,2,3,4,5].map(t=>rpTowerTop('hive',t))]}")
        chk('the Clockwork Hive is the eleventh tower: key H, 350 supply, ground and air, 2-6 bees, range 250-300, armor-piercing 2, taller every tier',
            r[0]==10 and r[1]=='H' and r[2]=='Clockwork Hive' and r[3][0]==350 and r[4]==1 and r[5]==1 and r[6]==[2,3,4,5,6] and r[7][0]>=250 and r[7][4]<=300 and r[8]==[2]*5 and r[9]==['base'] and r[10]==sorted(r[10]) and len(set(r[10]))==5,r)
        r=await E("()=>{const T=RP_TW.hive;return [T.cost,T.dmg,T.cd,T.range,T.desc.length>40,T.up.length]}")
        chk('every tier is stronger (more damage, faster stings, more range) and has an upgrade text',all(r[1][i]<r[1][i+1] and r[2][i]>r[2][i+1] and r[3][i]<r[3][i+1] for i in range(4)) and r[4] and r[5]==4,r)
        # ---- hotkey, bar, build, upgrade, sell
        r=await E("""async()=>{try{rpLeave()}catch(e){}rpStart('moss');const R=RPX;R.tut=null;R.supply=1000;await new Promise(r=>setTimeout(r,700));window.dispatchEvent(new KeyboardEvent('keydown',{key:'h'}));const a=R.place;R.place=null;R.ghost=null;
          const c=document.querySelector('.rpcard[data-tw="hive"]'),ok=rpBuild(R.pads[0],'hive');const tw=R.pads[0].tw;tw.build=1;rpStep(R,1/30);const n1=tw.bees.length,paid=1000-R.supply;
          rpUpgrade(tw);tw.upK=1;rpStep(R,1/30);const n2=tw.bees.length,s0=R.supply;rpSell(tw);return [a,!!c,ok!==false,paid,n1,n2,R.pads[0].tw,Math.round(R.supply-s0),document.querySelectorAll('.rpbar .rpcard').length]}""")
        chk('key H picks it, its card is in the bar; it builds for 350 with 2 bees, an upgrade adds a bee, selling refunds 70% and removes it',r[:7]==['hive',True,True,350,2,3,None] and r[7]==round(610*.7) and r[8]>=11,r)
        r=await E("""async()=>{const h=document.getElementById('rphud');const bar=h.querySelector('.rpbar').getBoundingClientRect(),nx=h.querySelector('.rpnext'),ab=h.querySelector('.rpabs').getBoundingClientRect(),cards=[...h.querySelectorAll('.rpbar .rpcard')].map(c=>c.getBoundingClientRect());
          const nb=nx?nx.getBoundingClientRect():null;return [h.classList.contains('rp11'),Math.round(bar.left),Math.round(bar.right),nb?Math.round(nb.left):9999,Math.round(ab.right),cards.length,cards.every(c=>c.width>60&&c.right<=bar.right+1)]}""")
        chk('the tower bar fits eleven cards between the abilities and the wave panel',r[0] and r[1]>=r[4]-2 and r[2]<=r[3]+2 and r[6],r)
        r=await E("""()=>{const R=RPX;R.ty=R.ty||{};const was=R.ty.on;R.ty.on=true;R.place=null;window.dispatchEvent(new KeyboardEvent('keydown',{key:'h'}));const a=R.place;R.ty.on=was;return a}""")
        chk('with Rune Typing on, H types a letter instead of picking the hive',r!='hive',r)
        # ---- bees seek and sting, ground and air
        r=await E("""()=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'hive',1),e=tdFoe(R,'golem',tdNear(R,pad,0));e.hp=e.mx=1e5;e.armor=0;tdRun(R,.1);const out0=tw.bees.filter(b=>b.m==='out').length;
          tdRun(R,4);return [out0,tw.bees.filter(b=>b.m==='out'&&b.e===e).length,R.hvStings,Math.round(1e5-e.hp),tw.door>=0,Math.round(Math.hypot(pad.x-rpPos(R,e).x,pad.y-rpPos(R,e).y))]}""")
        chk('bees leave the hive through the door, fly to a ground monster in range, circle it and sting it',r[0]>=1 and r[1]==2 and r[2]>=8 and r[3]>=8*14*.9,r)
        r=await E("""()=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'hive',2),e=tdFoe(R,'gloom',tdNear(R,pad,0));e.hp=e.mx=1e5;tdRun(R,4);return [e.air,R.hvStings,Math.round(1e5-e.hp)]}""")
        chk('they sting flyers too',r[0]==True and r[1]>=8 and r[2]>100,r)
        r=await E("""()=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'hive',1);let far=0,fd=0;const L=R.G.paths[0].len;for(let s=0;s<L;s+=20){const q=rpAt(R.G,s,0),d=Math.hypot(q.x-pad.x,q.y-pad.y);if(d>fd){fd=d;far=s}}
          const e=tdFoe(R,'golem',far);e.hp=e.mx=1e5;tdRun(R,3);return [Math.round(fd),R.hvStings,tw.bees.every(b=>b.m==='in')]}""")
        chk('a monster out of range is left alone (the bees stay home)',r[0]>400 and r[1]==0 and r[2],r)
        r=await E("""()=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'hive',1),rg=RP_TW.hive.range[0];let s1=null;const L=R.G.paths[0].len;
          for(let s=0;s<L;s+=3){const q=rpAt(R.G,s,0),d=Math.sqrt(rpD2(q.x,q.y,pad.x,pad.y));if(d>rg*1.04&&d<rg*1.1){s1=s;break}}if(s1==null)return 'no spot';
          const e=tdFoe(R,'golem',s1);e.hp=e.mx=1e5;tdRun(R,2.5);const n0=R.hvStings;tw.rangeK=1.15;tdRun(R,3);return [n0,R.hvStings-n0]}""")
        chk('a range bonus from the map (tw.rangeK, the Glowcaps) lets the bees reach further',r!='no spot' and r[0]==0 and r[1]>0,r)
        r=await E("""()=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'hive',2),s=tdNear(R,pad,0),a=tdFoe(R,'golem',s-40),c=tdFoe(R,'golem',s+40);a.hp=a.mx=c.hp=c.mx=1e5;tdRun(R,3);
          return [tw.bees.filter(b=>b.e===a).length,tw.bees.filter(b=>b.e===c).length]}""")
        chk('the swarm spreads over the monsters in range (3 bees on 2 monsters)',(r==[2,1] or r==[1,2]),r)
        r=await E("""()=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'hive',1),s=tdNear(R,pad,0),a=tdFoe(R,'scamp',s);a.hp=a.mx=60;const c=tdFoe(R,'golem',s+70);c.hp=c.mx=1e5;
          tdRun(R,1.5);const firstA=tw.bees.filter(b=>b.e===a).length;a.hp=1;tdRun(R,3);return [a.dead?1:0,tw.bees.filter(b=>b.e===c).length,Math.round(1e5-c.hp)>0]}""")
        chk('when their monster dies the bees seek the next one',r[0]==1 and r[1]==2 and r[2],r)
        # ---- honey
        r=await E("""()=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'hive',1),s=tdNear(R,pad,0),e=tdFoe(R,'golem',s);e.hp=e.mx=1e5;tdRun(R,3);const h=[+e.hnS.toFixed(2)>0,e.slowK,e.slowT>0];
          e.sp=50;const f=tdFoe(R,'golem',s);f.hp=f.mx=1e5;f.slowK=.6;f.slowT=5;tdRun(R,.5);const strong=f.slowK;
          rpSell(tw);tdRun(R,2.2);return [...h,strong,e.hnS,e.slowK]}""")
        chk('each sting coats the monster in honey: 15% slower; a stronger slow is kept; the honey wears off after 1.5 s',r[0]==True and abs(r[1]-0.15)<1e-6 and r[2] and r[3]==0.6 and r[4]==0 and r[5]==0,r)
        r=await E("""()=>{const R=tdNew('moss',3),pad=tdPad(R),s=tdNear(R,pad,0);const e=tdFoe(R,'golem',s);e.hp=e.mx=1e5;e.sp=60;e.hnS=1.5;const s0=e.s;tdRun(R,1);const d1=e.s-s0;
          const f=tdFoe(R,'golem',s);f.hp=f.mx=1e5;f.sp=60;const s1=f.s;tdRun(R,1);return [+(d1/(f.s-s1)).toFixed(3)]}""")
        chk('a honeyed monster really moves 15% slower',abs(r[0]-0.85)<0.02,r)
        r=await E("""()=>{const R=tdNew('moss',3),pad=tdPad(R),s=tdNear(R,pad,0),e=tdFoe(R,'golem',s);e.hp=e.mx=1e5;e.hnS=1;e.vent=1;tdRun(R,.2);return [e.slowK||0,e.slowT>0]}""")
        chk('a slow-immune monster (venting) ignores the honey',r[0]==0,r)
        # ---- tier 3 honey puddles
        r=await E("""()=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'hive',2),s=tdNear(R,pad,0),e=tdFoe(R,'golem',s);e.hp=e.mx=1e5;tdRun(R,4);const n2=R.hvPools.length;
          const R2=tdNew('moss',3),tw3=tdBuild(R2,pad===null?R2.pads[0]:R2.pads[pad.i],'hive',3),f=tdFoe(R2,'golem',s);f.hp=f.mx=1e5;tdRun(R2,4);const n3=R2.hvPools.length,P=R2.hvPools[0];
          const g=tdFoe(R2,'scamp',f.s);g.hp=g.mx=1e5;g.hnS=0;rpStep(R2,1/30);rpStep(R2,1/30);const inP=[g.hnP>0,g.slowK];
          const R3=tdNew('moss',3),tw4=tdBuild(R3,R3.pads[pad.i],'hive',3),a=tdFoe(R3,'gloom',s);a.hp=a.mx=1e5;tdRun(R3,4);return [n2,n3>=1,P&&P.d,...inP,R3.hvPools.length,RPHVB.poolR]}""")
        chk('tier 3 Honeycomb: stings on the road leave honey puddles (3 s) that slow monsters in them 25%; none below tier 3 or from flyers',r[0]==0 and r[1] and r[2]==3 and r[3] and abs(r[4]-0.25)<1e-6 and r[5]==0,r)
        # ---- tier 4 pollen
        r=await E("""()=>{const R=tdNew('wonder',30);const pads=R.pads;let A=null,B=null,C=null;for(const p of pads)for(const q of pads){if(p===q)continue;const d=Math.hypot(p.x-q.x,p.y-q.y);if(d<145&&!A){A=p;B=q}}
          for(const q of pads){if(q!==A&&Math.hypot(q.x-A.x,q.y-A.y)>220){C=q;break}}
          const hv=tdBuild(R,A,'hive',4),ba=tdBuild(R,B,'ballista',1),far=tdBuild(R,C,'ballista',1);tdRun(R,.2);const e=tdFoe(R,'golem',100);e.hp=e.mx=1e5;e.armor=0;const h0=e.hp;rpHurt(e,100,99,ba);const d1=h0-e.hp;
          const h1=e.hp;rpHurt(e,100,99,far);const d2=h1-e.hp;return [ba.pol>0,far.pol>0,+d1.toFixed(2),+d2.toFixed(2),hv.pol>0,A.i,B.i,C.i]}""")
        chk('tier 4 Royal Jelly: a tower within 150 px is pollinated and hits 10% harder; a far one is not; the hive does not buff itself',r[0] and not r[1] and r[2]==110 and r[3]==100 and not r[4],r)
        r=await E("""()=>{const R=tdNew('wonder',30);const pads=R.pads;let A=null,B=null,C=null;for(const p of pads)for(const q of pads){if(p===q)continue;if(Math.hypot(p.x-q.x,p.y-q.y)<145&&!A){A=p;B=q}}
          for(const q of pads){if(q!==A&&q!==B&&Math.hypot(q.x-A.x,q.y-A.y)>220){C=q;break}}
          const h1=tdBuild(R,A,'hive',4),h2=tdBuild(R,C,'hive',4),ba=tdBuild(R,B,'ballista',1);h2.x=B.x+60;h2.y=B.y+40;/* a second Royal Jelly hive next to the same tower */
          tdRun(R,.2);const e=tdFoe(R,'golem',100);e.hp=e.mx=1e5;e.armor=0;const h0=e.hp;rpHurt(e,100,99,ba);const d=h0-e.hp,both=h1._pl.includes(ba)&&h2._pl.includes(ba);
          const R2=tdNew('wonder',30),t3=tdBuild(R2,R2.pads[A.i],'hive',3),b2=tdBuild(R2,R2.pads[B.i],'ballista',1);tdRun(R2,.2);const p3=b2.pol>0;
          return [+d.toFixed(2),both,p3]}""")
        r2=await E("""()=>{const R=tdNew('wonder',30);const pads=R.pads;let A=null,B=null;for(const p of pads)for(const q of pads){if(p===q)continue;if(Math.hypot(p.x-q.x,p.y-q.y)<145&&!A){A=p;B=q}}
          const h1=tdBuild(R,A,'hive',4),ba=tdBuild(R,B,'ballista',1);tdRun(R,.2);const a=ba.pol>0;rpSell(h1);tdRun(R,.6);return [a,ba.pol>0]}""")
        r=r+r2
        chk('pollen does not stack (two Royal Jelly hives on one tower: still +10%), tier 3 gives none, and it fades when the hive is sold',r==[110,True,False,True,False],r)
        # ---- tier 5 the Queen
        r=await E("""()=>{const R=tdNew('wonder',30),pad=tdPad(R),tw=tdBuild(R,pad,'hive',5);rpStep(R,1/30);const q0=[!!tw.qn,tw.qn&&tw.qn.m,tw.qHome];const s=tdNear(R,pad,0);
          const fs=[];for(const k of [-20,0,20]){const e=tdFoe(R,'golem',s+k);e.hp=e.mx=1e6;e.armor=0;fs.push(e)}const far=tdFoe(R,'golem',Math.max(0,s-260));far.hp=far.mx=1e6;far.armor=0;
          for(const b of tw.bees)b.m='in';const sting=rphvHit;let qm=null;tdRun(R,.8);qm=tw.qn.m;tw.bees.length=0;RP_TW.hive.bees[4]=0;
          tdRun(R,7);RP_TW.hive.bees[4]=6;return [...q0,qm,R.hvBurstN,fs.map(e=>Math.round(1e6-e.hp)),Math.round(1e6-far.hp)]}""")
        chk('tier 5 Queen\'s Court: the Queen perches on her crown, takes off when monsters come and her burst hits everything around her (not monsters far away)',
            r[0] and r[1]=='perch' and r[2]==1 and r[3]=='fly' and r[4]>=1 and all(x>=250 for x in r[5]) and r[6]==0,r)
        r=await E("""()=>{const R=tdNew('wonder',30),pad=tdPad(R),tw=tdBuild(R,pad,'hive',5);rpStep(R,1/30);tdRun(R,2);return [tw.qn.m,tw.qHome]}""")
        chk('with nothing in range she stays home on her crown',r==['perch',1],r)
        # ---- Overcharge, the Starfall mark, jams
        r=await E("""()=>{const run=(over)=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'hive',2),e=tdFoe(R,'golem',tdNear(R,pad,0));e.hp=e.mx=1e6;e.armor=0;tdRun(R,2.5);const n0=R.hvStings,h0=e.hp;if(over)tw.over=10;tdRun(R,4);return [R.hvStings-n0,(h0-e.hp)/(R.hvStings-n0)]};
          const a=run(0),b=run(1);return [a[0],b[0],+(b[0]/a[0]).toFixed(2),+(b[1]/a[1]).toFixed(3)]}""")
        chk('Overcharge: stings come about 2.4x faster and hit 15% harder',1.9<=r[2]<=2.9 and abs(r[3]-1.15)<0.01,r)
        r=await E("""()=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'hive',1),e=tdFoe(R,'golem',tdNear(R,pad,0));e.hp=e.mx=1e6;e.armor=0;e.mk=10;e.mkK=.18;const h0=e.hp;rphvHit(R,tw,tw.bees[0]||{x:e.x,y:0,h:0,pc:1},e,100);return +(h0-e.hp).toFixed(2)}""")
        chk('the Starfall mark makes stings hit harder too (they go through rpHurt)',r==118,r)
        r=await E("""()=>{const f0=rpFire;rpFire=function(R,tw,dt){if(tw.jam>0){tw.jam-=dt;return}return f0.apply(this,arguments)};try{const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'hive',2),e=tdFoe(R,'golem',tdNear(R,pad,0));e.hp=e.mx=1e6;tdRun(R,2.5);
          tw.jam=4;const n0=R.hvStings;tdRun(R,3.5);const n1=R.hvStings-n0,home=tw.bees.filter(b=>b.m==='in').length;tdRun(R,2);return [n1,home,R.hvStings-n0-n1>0]}finally{rpFire=f0}}""")
        chk('a jammed hive (its fire blocked) calls its bees home: no stings until the jam ends',r[0]==0 and r[1]==3 and r[2],r)
        # ---- Performance mode: fewer bees drawn, same damage
        r=await E("""()=>{const res=[];for(const lite of [0,1]){const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'hive',3),e=tdFoe(R,'golem',tdNear(R,pad,0));e.hp=e.mx=1e6;e.armor=0;R.lite=lite;tdRun(R,5);
           let n=0;const b0=rphvBee;rphvBee=function(){n++;return b0.apply(this,arguments)};try{rpDraw()}finally{rphvBee=b0}res.push([n,R.hvStings])}return res}""")
        chk('Performance mode draws half the bees but they sting just as often',r[1][0]<r[0][0] and r[1][0]>=2 and abs(r[1][1]-r[0][1])<=3,r)
        # ---- art
        r=await E("""()=>{const out=[];for(let t=1;t<=5;t++){const c=document.createElement('canvas');c.width=c.height=240;const g=c.getContext('2d');g.translate(120,190);rpTowerDraw(g,'hive',t,'base',1,{});
           const d=g.getImageData(0,0,240,240).data;let n=0;for(let i=3;i<d.length;i+=4)if(d[i]>20)n++;out.push([n,c.toDataURL().length])}
          const ic=rpTowerIcon('hive',1,'base',96);return [out.map(x=>x[0]),new Set(out.map(x=>x[1])).size,ic.width]}""")
        chk('each tier draws differently and grander (tier 5 fuller than tier 3, tier 3 than tier 1); the icon renders',r[1]==5 and r[0][2]>r[0][0] and r[0][4]>r[0][2] and r[2]==96,r)
        r=await E("""()=>{const out=[];for(const t of [0,.9,1.8]){const c=document.createElement('canvas');c.width=c.height=200;const g=c.getContext('2d');g.translate(100,160);RPHV.cur={type:'hive',door:t/1.8,qHome:1};try{rpTowerDraw(g,'hive',3,'base',t,{})}finally{RPHV.cur=null}out.push(c.toDataURL().length)}return new Set(out).size}""")
        chk('the hive is alive: door flap, drips, gears and vane change over time',r==3,r)
        # frame cost: the best of several batches (this machine may be shared); the hive is compared with the Starfall Observatory
        r=await E("""()=>{if(typeof RPG!=='undefined')RPG.off=1;const c=document.createElement('canvas');c.width=1600;c.height=900;const g=c.getContext('2d');for(let t=1;t<=5;t++){rpTowerWarm('hive',t,'base');rpTowerWarm('star',t,'base')}
          const best=f=>{let m=1e9;for(let k=0;k<7;k++){const t0=performance.now();for(let i=0;i<8;i++)f(i);m=Math.min(m,(performance.now()-t0)/8)}return m};
          const row=ty=>best(f=>{for(let t=1;t<=5;t++){g.save();g.translate(100+t*200,400);if(ty==='hive')RPHV.cur={type:'hive',door:(f%8)/8,qHome:f%2};rpTowerDraw(g,ty,t,'base',f/30,{aim:.3});RPHV.cur=null;g.restore()}})/5;
          const hv=row('hive'),sf=row('star');if(typeof RPG!=='undefined')RPG.off=0;return [+hv.toFixed(3),+sf.toFixed(3),!!RPG_SRC.hive&&RPG_SRC.hive.length===6,!!RPG_PAR.hive]}""")
        chk('frame cost: one hive draws in well under a millisecond (no more than the Starfall Observatory); it is in the 9.9p glow and particle layer',(r[0]<0.5 or r[0]<=1.3*r[1]) and r[2] and r[3],r)
        r=await E("""()=>{const R=tdNew('wonder',40);const pads=R.pads.slice(0,6);for(const p of pads)tdBuild(R,p,'hive',5);for(let k=0;k<24;k++){const f=tdFoe(R,k%3?'golem':'gloom',150+k*60,k%2);f.hp=f.mx=1e7}tdRun(R,6);
          const bz=R.pads.slice(6,12);for(const p of bz){if(!p.tw)tdBuild(R,p,'ballista',1);p.tw.pol=1}const n=pads.reduce((a,p)=>a+p.tw.bees.filter(b=>b.m!=='in').length,0);
          const c=document.createElement('canvas').getContext('2d');c.canvas.width=1600;c.canvas.height=900;
          /* only the hive's own layers: puddles, shadows, trails, bees, Queens, couriers, sparks, bursts, pollen */
          const layer=()=>{R.t+=1/30;RPHV_FR++;for(const p of R.hvPools)rphvPuddle(c,p.x,p.y,p.r,1,R.t,p.tier,p.seed);
            if(!R.lite)for(const pd of pads)for(const b of pd.tw.bees)if(b.m!=='in')rphvShadow(c,b.x,b.y,.8,.5);for(const b of R.hvBursts)rphvBurst(c,b.x,b.y,b.r,.4,5,b.h);rphvTrails(c,R);
            for(const pd of pads){const tw=pd.tw;tw.bees.forEach((b,j)=>{if(!rphvLiteSkip(tw,j))rphvDrawBee(c,R,tw,b)});rphvDrawQueen(c,R,tw);rphvCourier(c,R,tw)}
            if(!R.lite)for(const f of R.hvFx)rphvSting(c,f.x,f.y,.4,5);for(const p of bz)rphvPollen(c,p.x,p.y,R.t,1,120,0)};
          const best=f=>{let m=1e9;for(let k=0;k<7;k++){const t0=performance.now();for(let i=0;i<8;i++)f();m=Math.min(m,(performance.now()-t0)/8)}return m};
          const obs=()=>{for(const p of pads){c.save();c.translate(p.x,p.y);rpTowerDraw(c,'star',5,'base',R.t,{});c.restore()}};
          /* measured in turns with the reference, keeping the best of each, so a busy moment on the machine hits both */
          let full=1e9,ref=1e9;for(let k=0;k<4;k++){full=Math.min(full,best(layer));ref=Math.min(ref,best(obs))}R.lite=1;const lite=best(layer);R.lite=0;
          return [n,R.hvPools.length,+full.toFixed(3),+lite.toFixed(3),+ref.toFixed(3),R.hvBursts.length]}""")
        chk('frame cost: six tier 5 hives in full swarm (36 bees, Queens, trails, puddles, pollen) draw in about a millisecond (or no more than 2.5x six Observatories when the machine is busy); Performance mode draws less',
            r[0]>=24 and (r[2]<1.2 or r[2]<=2.5*r[4]) and r[3]<=r[2]*1.05,r)
        # ---- info panel
        r=await E("""async()=>{const R=tdNew('moss',3),pad=tdPad(R),tw=tdBuild(R,pad,'hive',2);tdFoe(R,'golem',300);R.sel=tw;await new Promise(r=>setTimeout(r,400));const el=document.getElementById('rpinfo');
          const t=el?el.textContent:'';const b=el.getBoundingClientRect();return [/Swarm damage/.test(t),/Bees/.test(t),/honey/.test(t),/armor-piercing/.test(t),/Clockwork Hive/.test(t),b.bottom<=780,b.top>=70]}""")
        chk('the info panel shows range, swarm damage, bees, sting rate and the honey, inside the stage',all(r),r)
        r=await E("""async()=>{try{rpLeave()}catch(e){}rampartsMenu(title);await new Promise(r=>setTimeout(r,500));let ok=false;try{rpHowTo();const w=ov.querySelector('#rpmod .rphw');ok=!!w&&/Clockwork Hive/.test(w.textContent)}catch(e){}
          const h=HELP.Modes.find(x=>x[0]==='Runestone Tower Defense');return [ok,!!h&&h[1].includes('Clockwork Hive (H, 350 supply)')]}""")
        chk('How to Play and the Help text describe the Clockwork Hive',r==[True,True],r)
        # ---- a full wave
        r=await E("""()=>{const R=tdNew('moss',6);R.wst='build';const pads=[...R.pads].sort((a,b)=>a.i-b.i);tdBuild(R,pads[2],'hive',3);tdBuild(R,pads[5],'hive',3);tdBuild(R,pads[7],'ballista',3);tdBuild(R,pads[9],'hive',2);R.cd=0;rpWaveStart();let t=0;
          while(R.wst==='run'&&t<240){rpStep(R,1/30);t+=1/30}return [R.wst,R.hp>0,R.hvStings>20,R.hvPoolN>0,R.foes.filter(e=>!e.dead&&!isFinite(e.hp)).length,R.pads.filter(p=>p.tw&&p.tw.type==='hive').every(p=>p.tw.bees.every(b=>isFinite(b.x)&&isFinite(b.h)))]}""")
        chk('a real wave with three hives ends cleanly (no broken monsters or bees)',r[0]=='build' and r[1] and r[2] and r[4]==0 and r[5],r)
        r=await E("""()=>{const R=tdNew('wonder',30);R.wst='build';for(const p of R.pads.slice(0,5))tdBuild(R,p,'hive',5);for(const p of R.pads.slice(5,9))tdBuild(R,p,'prism',4);R.cd=0;rpWaveStart();let t=0;
          while(R.wst==='run'&&t<300){rpStep(R,1/30);t+=1/30}rpDraw();return [R.wst,R.hp>0,R.hvBurstN>0,R.pads.filter(p=>p.tw&&p.tw.type==='hive').every(p=>p.tw.qn&&isFinite(p.tw.qn.x))]}""")
        chk('a Wonderland wave with tier 5 hives ends cleanly and the Queens burst',r[0]=='build' and r[1] and r[2] and r[3],r)
        await pg.screenshot(path=os.path.join(HERE,'shots','hive_test.png'))
        chk('no page errors',not er,er[:3])
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
