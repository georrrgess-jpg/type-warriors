/* ===== RUNESTONE RIDDLE: it takes the Daily Challenge's place everywhere =====
   - dcMenu (dock card, G hotkey, Choose mode, bell alert, shell) now opens the Riddle. The old one-attempt run is no longer reachable;
     its records stay in P.dc untouched.
   - Home card: the Daily Challenge postcard becomes a live runestone (today's pattern once solved), with riddle number, streak and payout chip.
   - Choose mode card, the bell alert and the "daily" bounty all point at the Riddle. The Riddlemaster title joins the bounty titles
     (earned with a 30-day riddle streak, never bought). */
dcMenu=function(back){rrMenu(typeof back==='function'?back:title,'d')};
/* the home card */
function rrCardLive(cv){const g=cv.getContext('2d'),W2=cv.width,H2=cv.height,k=rrKey(),e=RRP().d[k],done=!!(e&&e.st&&e.st!=='p');
 const rows=done?e.g.map(x=>rrScore(x,rrWord(k))):[];const last=done?rows[rows.length-1]:null;
 const P_=Array.from({length:18},(_,i)=>{const r=q=>{const x=Math.sin((i+1)*9.17+q*4.3)*43758.5453;return x-Math.floor(x)};return[r(1),r(2),r(3),r(4)]});
 const draw=t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,W2,H2);
  let q=g.createLinearGradient(0,0,W2,H2);q.addColorStop(0,'#2a1a64');q.addColorStop(.55,'#160e3c');q.addColorStop(1,'#0a0620');g.fillStyle=q;g.fillRect(0,0,W2,H2);
  q=g.createRadialGradient(W2/2,46,10,W2/2,46,W2*.45);q.addColorStop(0,done?(e.st==='w'?'#4ae89a44':'#ff6a7a33'):'#ffd45a40');q.addColorStop(1,'#0000');g.fillStyle=q;g.fillRect(0,0,W2,H2);
  for(const [a,b,c2,d] of P_){const y=H2-((a+t*(.03+c2*.04))%1)*H2,x=b*W2+Math.sin(t+d*6)*12;g.globalAlpha=.6*Math.sin(Math.min(1,y/H2)*Math.PI);g.fillStyle=d>.5?'#ffe08a':'#9dfccc';g.beginPath();g.arc(x,y,1+d*1.8,0,TAU);g.fill()}g.globalAlpha=1;
  /* the slab */
  const sw=212,sh=60,sx=(W2-sw)/2,sy=16;g.save();g.translate(sx,sy);
  q=g.createLinearGradient(0,0,sw,sh);q.addColorStop(0,'#5a4e70');q.addColorStop(.5,'#2a2433');q.addColorStop(1,'#1c1823');g.fillStyle=q;g.strokeStyle='#12081f';g.lineWidth=5;
  g.beginPath();g.roundRect(0,0,sw,sh,16);g.fill();g.stroke();
  for(const rx of [9,sw-9]){const pu=.55+.45*Math.sin(t*2.4+rx);q=g.createRadialGradient(rx,sh/2,1,rx,sh/2,14);q.addColorStop(0,'#b88aff'+Math.round(pu*200).toString(16).padStart(2,'0'));q.addColorStop(1,'#b88aff00');g.fillStyle=q;g.fillRect(rx-14,sh/2-14,28,28);g.strokeStyle='#e8d8ff';g.globalAlpha=pu;g.lineWidth=2;g.beginPath();g.moveTo(rx,sh/2-7);g.lineTo(rx,sh/2+7);g.moveTo(rx,sh/2-3);g.lineTo(rx+4,sh/2-7);g.stroke();g.globalAlpha=1}
  const ts=32,gp=6,ox=(sw-5*ts-4*gp)/2,oy=(sh-ts)/2;
  for(let i=0;i<5;i++){const x=ox+i*(ts+gp);let st=done?last[i]:'n',lt=done?rrWord(k)[i]:'?';
   let fl=1;if(!done){const ph=(t*.55+i*.16)%2.2;if(ph<.3){fl=Math.cos(ph/.3*Math.PI);if(fl<0)st=['c','p','c','a','p'][i]}}
   const yb=done&&e.st==='w'?-Math.max(0,Math.sin(t*2.4-i*.5))*3:0;
   g.save();g.translate(x+ts/2,oy+ts/2+yb);g.scale(1,Math.max(.06,Math.abs(fl)));
   const col=st==='c'?['#3cc274','#22934f','#6af0a0']:st==='p'?['#ecba3a','#c08a12','#ffe07a']:st==='a'?['#6c6779','#4e4a5c','#827d92']:['#26203a','#1a1626','#7a5ad8'];
   q=g.createLinearGradient(0,-ts/2,0,ts/2);q.addColorStop(0,col[0]);q.addColorStop(1,col[1]);g.fillStyle=q;g.strokeStyle=col[2];g.lineWidth=2;g.beginPath();g.roundRect(-ts/2,-ts/2,ts,ts,8);g.fill();g.stroke();
   g.fillStyle='#ffffff';g.font='800 19px Poppins,system-ui,sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillText(done?lt.toUpperCase():(fl<0?'':'?'),0,1);g.restore()}
  g.restore();
  q=g.createLinearGradient(0,H2*.36,0,H2);q.addColorStop(0,'#07041200');q.addColorStop(1,'#070412f0');g.fillStyle=q;g.fillRect(0,0,W2,H2)};
 draw(2);if(!dkRM())LIVE.push({cv,fn:t=>draw(t),slow:2,ph:1})}
dkDailyLive=function(cv){try{rrCardLive(cv)}catch(e){}};
function rrHomeCard(){const b=$('dcb');if(!b)return;const k=rrKey(),e=RRP().d[k],done=!!(e&&e.st&&e.st!=='p'),st=rrStreak(),n=rrIdx(k)>=0?'#'+rrNum(k):'';
 b.style.setProperty('--dac',done?(e.st==='w'?'#4ae89a':'#ff8a9a'):'#ffd45a');b.classList.toggle('done',done);b.title='Runestone Riddle (G)';
 b.setAttribute('aria-label',`Runestone Riddle ${n}${done?(e.st==='w'?', solved in '+e.g.length:', not solved'):', today\'s riddle is ready'}`);
 const cl=b.querySelector('.dkcl');const nw=!RRP().seen84;if(cl)cl.innerHTML=`<small>${st?`RIDDLE ${n} · <span class="dkstk">🔥${st}</span>`:`RUNESTONE RIDDLE ${n}`}${nw?'<i class="rrnewb">NEW</i>':''}</small><b>${done?(e.st==='w'?`Solved in ${e.g.length}!`:'Rune hidden'):'Today\'s riddle'}</b><span class="dkchip">${done?`+${rrFmt(e.c||0)} coins`:'Up to 1,500'}</span>`}
{const t0=title;title=function(){const r=t0.apply(this,arguments);try{rrHomeCard()}catch(e){}return r}}
/* Choose mode */
{const m0=modeSheet;modeSheet=function(){const r=m0.apply(this,arguments);try{const c=$('dmd');if(c){const k=rrKey(),done=rrDone(k);const t=c.querySelector('.dkmt');
  if(t)t.innerHTML=`<b>Runestone Riddle</b><small>${done?'Solved today · practice any time':'Today\'s five-letter riddle · up to 1,500 coins'}</small>`;c.style.setProperty('--c','#ffd45a');c.style.removeProperty('--img');const ic=c.querySelector('.dkmi');if(ic)ic.innerHTML=RR_MICO}}catch(e){}return r}}
const RR_MICO='<svg viewBox="0 0 58 58" width="58" height="58" aria-hidden="true"><rect x="7" y="9" width="44" height="40" rx="10" fill="#2a2433" stroke="#12081f" stroke-width="3"/><rect x="12" y="20" width="10" height="10" rx="2.5" fill="#22744a" stroke="#7af0b0" stroke-width="1.5"/><rect x="24" y="20" width="10" height="10" rx="2.5" fill="#b08418" stroke="#ffd45a" stroke-width="1.5"/><rect x="36" y="20" width="10" height="10" rx="2.5" fill="#22744a" stroke="#7af0b0" stroke-width="1.5"/><rect x="12" y="33" width="10" height="10" rx="2.5" fill="#1b1722" stroke="#6c6384" stroke-width="1.5"/><rect x="24" y="33" width="10" height="10" rx="2.5" fill="#1b1722" stroke="#6c6384" stroke-width="1.5"/><rect x="36" y="33" width="10" height="10" rx="2.5" fill="#1b1722" stroke="#6c6384" stroke-width="1.5"/></svg>';
/* the bell */
{const a0=alertList;alertList=function(run,dd){const a=a0.apply(this,arguments).filter(x=>x[0]!=='dgc');try{if(!rrDone())a.splice(dailyReady()?1:0,0,['dgc','daily','Runestone Riddle is ready','Today\'s five-letter riddle · up to 1,500 coins'])}catch(e){}return a}}
/* bounty: the "daily" contract is now the riddle */
{const b=BTPL.find(x=>x.k==='daily');if(b){b.ok=()=>!rrDone();b.txt=()=>'Solve today\'s Runestone Riddle'}}
/* the Riddlemaster title: shown in the exchange, earned only by the streak */
BT_TITLES.push(['riddlemaster','Riddlemaster',1e9]);
{const b0=bountyBoard;bountyBoard=function(){const r=b0.apply(this,arguments);try{const x=ov.querySelector('[data-buy="t:riddlemaster"]');if(x){const s=document.createElement('span');s.className='rrlock';s.textContent='Earn: 30-day riddle streak';x.replaceWith(s)}}catch(e){}return r}}
/* first visit clears the NEW ribbon */
{const m0=rrMenu;rrMenu=function(){const R=RRP();if(!R.seen84){R.seen84=1;save()}return m0.apply(this,arguments)}}
{const st=document.createElement('style');st.textContent=`.rrnewb{display:inline-block;margin-left:6px;vertical-align:1px;padding:1px 7px;letter-spacing:1px!important;border-radius:999px;font:800 11px Poppins,sans-serif;letter-spacing:1px;font-style:normal;color:#2a1604;background:linear-gradient(180deg,#ffe48a,#f5b928);border:1.5px solid #12081f}
#dcb.dkdaily .dkcl{max-width:86%!important}.dkdaily .dkcl b{white-space:nowrap}.rrlock{font:700 11.5px Poppins,sans-serif;color:#ffd45a;opacity:.85}`;document.head.appendChild(st)}
