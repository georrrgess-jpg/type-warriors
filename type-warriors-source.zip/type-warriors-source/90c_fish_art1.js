/* ===== MOONLIT FISHING: fish art 1 — reed, ember, moss, lant, pebble, copper, whisker, lily (commons) =====
   Each FISHART.<id>(g,t,o) draws one fish facing right, centred on the origin, ~200 units long. Helpers prefixed fa1_. */
/* path from a command list: 'M',x,y 'L',x,y 'Q',cx,cy,x,y 'C',c1x,c1y,c2x,c2y,x,y 'Z' */
function fa1_path(g,c){g.beginPath();let i=0;while(i<c.length){const k=c[i++];
 if(k==='M'){g.moveTo(c[i],c[i+1]);i+=2}else if(k==='L'){g.lineTo(c[i],c[i+1]);i+=2}
 else if(k==='Q'){g.quadraticCurveTo(c[i],c[i+1],c[i+2],c[i+3]);i+=4}
 else if(k==='C'){g.bezierCurveTo(c[i],c[i+1],c[i+2],c[i+3],c[i+4],c[i+5]);i+=6}else if(k==='Z')g.closePath()}}
/* gradient with explicit stops [[pos,colour],...] */
function fa1_grad(g,x0,y0,x1,y1,s){const q=g.createLinearGradient(x0,y0,x1,y1);for(const e of s)q.addColorStop(e[0],e[1]);return q}
/* run fn in a translated + rotated frame */
function fa1_at(g,x,y,a,fn){g.save();g.translate(x,y);g.rotate(a);fn();g.restore()}
/* glossy highlight: a soft white curve inside the clip path */
function fa1_gloss(g,clip,x0,y0,cx,cy,x1,y1,w,a){g.save();clip();g.clip();g.lineCap='round';g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo(cx,cy,x1,y1);
 g.strokeStyle=`rgba(255,255,255,${a*.45})`;g.lineWidth=w*2.1;g.stroke();g.strokeStyle=`rgba(255,255,255,${a})`;g.lineWidth=w;g.stroke();g.restore()}
/* gill arc (clipped to the body) */
function fa1_gill(g,clip,x,y,r,a0,a1,c,a){g.save();clip();g.clip();g.beginPath();g.arc(x,y,r,a0,a1);g.strokeStyle=c||FKO;g.globalAlpha=a==null?.6:a;g.lineWidth=2.4;g.lineCap='round';g.stroke();g.restore()}
/* rib lines from a root point to each listed point, clipped to the clip path */
function fa1_ribs(g,clip,x0,y0,pts,a,c){g.save();clip();g.clip();g.strokeStyle=c||FKO;g.globalAlpha=a==null?.25:a;g.lineWidth=1.3;g.lineCap='round';
 for(let i=0;i<pts.length;i+=2){g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo((x0+pts[i])/2,(y0+pts[i+1])/2*1.04,pts[i],pts[i+1]);g.stroke()}g.restore()}
/* tapered strand along a chain of cubic beziers b=[x0,y0, c1x,c1y,c2x,c2y,x1,y1, ...] (whiskers, barbels) */
function fa1_strand(g,b,w0,w1,col,lw){const P=[[b[0],b[1]]];let x=b[0],y=b[1];
 for(let i=2;i+5<b.length;i+=6){const c1x=b[i],c1y=b[i+1],c2x=b[i+2],c2y=b[i+3],ex=b[i+4],ey=b[i+5];
  for(let s=1;s<=12;s++){const u=s/12,v=1-u;P.push([v*v*v*x+3*v*v*u*c1x+3*v*u*u*c2x+u*u*u*ex,v*v*v*y+3*v*v*u*c1y+3*v*u*u*c2y+u*u*u*ey])}x=ex;y=ey}
 const n=P.length,L=[],R=[];for(let i=0;i<n;i++){const a=P[Math.max(0,i-1)],c=P[Math.min(n-1,i+1)],dx=c[0]-a[0],dy=c[1]-a[1],d=Math.hypot(dx,dy)||1,w=(w0+(w1-w0)*i/(n-1))/2;
  L.push([P[i][0]-dy/d*w,P[i][1]+dx/d*w]);R.push([P[i][0]+dy/d*w,P[i][1]-dx/d*w])}
 g.beginPath();g.moveTo(L[0][0],L[0][1]);for(const p of L)g.lineTo(p[0],p[1]);for(let i=n-1;i>=0;i--)g.lineTo(R[i][0],R[i][1]);g.closePath();
 g.lineJoin='round';g.lineWidth=lw||2.2;g.strokeStyle=FKO;g.stroke();g.fillStyle=col;g.fill()}
/* eyelid: amt 0 open .. 1 shut, tilt slopes the lid line (positive = lower toward the snout), col = lid colour */
function fa1_lid(g,x,y,r,amt,col,tilt){if(amt<=0)return;tilt=tilt||0;const ly=y-r+2*r*Math.min(1,amt);g.save();g.beginPath();g.arc(x,y,r,0,TAU);g.clip();
 g.beginPath();g.moveTo(x-r-3,y-r-3);g.lineTo(x+r+3,y-r-3);g.lineTo(x+r+3,ly+tilt*r);g.quadraticCurveTo(x,ly+r*.18,x-r-3,ly-tilt*r);g.closePath();g.fillStyle=col;g.fill();
 g.beginPath();g.moveTo(x+r+3,ly+tilt*r);g.quadraticCurveTo(x,ly+r*.18,x-r-3,ly-tilt*r);g.strokeStyle=FKO;g.lineWidth=Math.max(2,r*.26);g.stroke();g.restore();
 g.beginPath();g.arc(x,y,r,0,TAU);g.lineWidth=Math.max(2,r*.24);g.strokeStyle=FKO;g.stroke()}
/* blink: 0 open, rising to 1 for a quick blink every few seconds */
function fa1_blink(t,s){const p=((t+s)%4.7+4.7)%4.7;return p>4.5?1-Math.abs(p-4.6)/.1:0}
/* small open cartoon smile */
function fa1_smile(g,x0,y0,cx,cy,x1,y1,w){g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo(cx,cy,x1,y1);g.strokeStyle=FKO;g.lineWidth=w||2.4;g.lineCap='round';g.stroke()}
/* pectoral fin: a translucent fan hinged at (x,y), sweeping back; a = tilt (negative tips it downward) */
function fa1_pec(g,x,y,a,L,c1,c2,al){fa1_at(g,x,y,a,()=>{const P=()=>fa1_path(g,['M',3,-3.5,'C',-L*.3,-L*.34,-L*.78,-L*.3,-L,-L*.08,'Q',-L*1.02,L*.08,-L*.9,L*.18,'Q',-L*.8,L*.3,-L*.62,L*.3,'C',-L*.36,L*.28,-L*.1,L*.12,3,3.5,'Z']);
 g.globalAlpha=al||1;P();fkFill(g,fkLin(g,0,0,-L,L*.1,[c1,c2]),2.2);g.globalAlpha=1;fa1_ribs(g,P,2,0,[-L,-L*.12,-L,L*.04,-L*.9,L*.2,-L*.7,L*.3],.32);
 g.save();P();g.clip();g.beginPath();g.moveTo(2,-3);g.bezierCurveTo(-L*.3,-L*.3,-L*.78,-L*.26,-L*.98,-L*.06);g.strokeStyle='rgba(255,255,255,.5)';g.lineWidth=2;g.stroke();g.restore()})}
/* a catch-spectacle wash for common fish */
function fa1_catch(g,o,c){const k=o.glow||0;if(k>0)fkGlow(g,10,0,110,c||'#fff2c8',.22*k)}

/* ---------------- 1. Reed Darter: slim gold torpedo with a dark racing stripe ---------------- */
FISHART.reed=(g,t,o)=>{const fl=o.flex||0,sw=fkSway(o,5.2,.16),fin=Math.sin(t*7)*.12;g.save();g.rotate(-sw*.22);
 const B=()=>fkPath(g,[106,3,98,-10,68,-23,20,-27,-28,-20,-58,-10,-68,0,-58,10,-28,18,20,23,68,18,98,11]);
 const T=()=>fa1_path(g,['M',14,-6,'Q',-6,-7,-22,-19,'Q',-34,-30,-48,-37,'Q',-42,-16,-30,0,'Q',-42,16,-48,37,'Q',-34,30,-22,19,'Q',-6,7,14,6,'Z']);
 // tail
 fa1_at(g,-58,0,sw,()=>{T();fkFill(g,fkLin(g,4,0,-48,0,['#d8bf4a','#f0a03a','#ff5a2c']),2.6);
  fa1_ribs(g,T,4,0,[-46,-34,-40,-22,-34,-10,-34,10,-40,22,-46,34],.3);
  g.save();T();g.clip();fa1_path(g,['M',8,-3,'Q',-12,-2,-30,0,'Q',-12,2,8,3,'Z']);g.fillStyle='#3a2414';g.globalAlpha=.8;g.fill();g.restore()});
 // back fins
 fa1_at(g,-4,-23,fin*.6,()=>fkFin(g,[10,2,6,-10,-4,-17,-18,-15,-20,3],'#ff8a3a','#e0401e',[[0,0,-2,-15],[-8,0,-12,-15],[4,0,4,-10]],2.4));
 fa1_at(g,14,19,-fin,()=>fkFin(g,[6,-2,-2,10,-14,13,-12,-2],'#ff9a3a','#e8481e',[[0,0,-10,10]],2.4));
 fa1_at(g,-34,14,fin*.7,()=>fkFin(g,[6,-2,-2,9,-14,11,-14,-2],'#ff9a3a','#e8481e',[[0,0,-10,9]],2.4));
 // body
 B();fkFill(g,fa1_grad(g,0,-27,0,23,[[0,'#7c8a1e'],[.32,'#c8b23a'],[.5,'#f0d866'],[.7,'#fff0c0'],[1,'#fff8e6']]),3);
 fkScales(g,B,-66,92,-26,22,9,'#6a5a10',.16);
 fkShade(g,B,-8,-27,'#4a5a10',.45);
 // lateral stripe nose to tail + gold shimmer line
 g.save();B();g.clip();fa1_path(g,['M',104,0,'Q',70,-7,10,-5,'Q',-40,-3,-72,-1,'L',-72,4,'Q',-40,4,10,4,'Q',70,4,104,4,'Z']);g.fillStyle='#3a2414';g.globalAlpha=.88;g.fill();
 g.globalAlpha=.7;g.beginPath();g.moveTo(92,-10);g.quadraticCurveTo(30,-12,-60,-6);g.strokeStyle='#fff6b0';g.lineWidth=1.6;g.stroke();g.restore();
 fkShade(g,B,8,23,'#d8a050',.35);
 fa1_gloss(g,B,74,-17,30,-25,-24,-18,3,.65);
 fa1_gill(g,B,92,0,24,Math.PI*.72,Math.PI*1.28);
 // pectoral
 fa1_pec(g,66,6,-.35+fin,20,'#ffc060','#ff5a2a',.95);
 fkEye(g,80,-7,10,'#c06a1a',.3);fa1_lid(g,80,-7,10,fa1_blink(t,.3),'#c8b23a');
 fa1_smile(g,101,5,97,8,92,6,2.2);
 fa1_catch(g,o);g.restore()};

/* ---------------- 2. Ember Carp: deep koi with gold-edged scales and warm embers ---------------- */
FISHART.ember=(g,t,o)=>{const sw=fkSway(o,2.6,.14),fin=Math.sin(t*3.2)*.1,wv=Math.sin(t*2.6+1)*4;g.save();g.rotate(-sw*.2);
 const B=()=>fkPath(g,[102,4,98,-17,76,-37,30,-47,-16,-41,-50,-23,-66,-8,-66,8,-50,21,-16,37,30,43,76,33,98,17]);
 const T=()=>fa1_path(g,['M',14,-10,'C',-8,-14,-24,-40,-42,-46+wv,'C',-55,-46+wv,-53,-20,-38,-1,'C',-53,18,-55,46-wv,-42,46-wv,'C',-24,40,-8,14,14,10,'Z']);
 fa1_at(g,-58,0,sw,()=>{g.globalAlpha=.96;T();fkFill(g,fkLin(g,6,0,-56,0,['#ff5a26','#ff9a3a','#ffd36a']),2.6);g.globalAlpha=1;
  fa1_ribs(g,T,6,0,[-46,-44,-44,-30,-40,-14,-40,14,-44,30,-46,44],.25,'#a8301a');
  g.save();T();g.clip();g.globalAlpha=.35;g.strokeStyle='#fff3b0';g.lineWidth=5;T();g.stroke();g.restore()});
 // dorsal ridge fin
 fa1_at(g,0,0,0,()=>{const d=Math.sin(t*2.4)*2;fkFin(g,[36,-38,22,-58+d,-6,-62+d,-34,-52+d,-46,-30,0,-36],'#ffb84a','#e8461e',[[30,-40,22,-56],[16,-42,6,-60],[2,-42,-12,-58],[-12,-40,-28,-52]],2.4)});
 fa1_at(g,4,36,-fin,()=>fkFin(g,[8,-2,0,14,-16,18,-14,-2],'#ffa840','#e8461e',[[0,0,-12,14]],2.4));
 fa1_at(g,-34,30,fin,()=>fkFin(g,[8,-4,0,12,-16,14,-14,-4],'#ffa840','#e8461e',[[0,0,-12,12]],2.4));
 B();fkFill(g,fa1_grad(g,0,-47,0,43,[[0,'#a81c18'],[.3,'#ef4422'],[.6,'#ff7a30'],[1,'#ffc46a']]),3);
 // gold-edged koi scales
 g.save();B();g.clip();g.lineCap='round';
 for(let r=0,y=-40;y<42;y+=11,r++)for(let x=60-(r%2?6.5:0);x>-70;x-=13){const s=8.6;
  g.beginPath();g.arc(x,y,s,Math.PI*.56,Math.PI*1.44);g.strokeStyle='#8a1610';g.globalAlpha=.28;g.lineWidth=3.6;g.stroke();
  g.beginPath();g.arc(x+1,y,s,Math.PI*.58,Math.PI*1.42);g.strokeStyle='#ffd870';g.globalAlpha=.8;g.lineWidth=1.5;g.stroke()}
 g.globalAlpha=1;g.restore();
 // smooth head plate over the scales
 g.save();B();g.clip();g.beginPath();g.arc(104,0,40,0,TAU);g.fillStyle=fa1_grad(g,0,-40,0,40,[[0,'#d42e1c'],[.5,'#ff6a2c'],[1,'#ffb860']]);g.fill();g.restore();
 fkShade(g,B,-12,-47,'#6a0c10',.42);fkShade(g,B,14,43,'#ffd080',.35);
 fa1_gloss(g,B,82,-24,40,-42,-14,-37,3.4,.6);
 fa1_gill(g,B,104,0,40,Math.PI*.74,Math.PI*1.26);
 // embers glowing along the back
 const E=[[46,-38],[26,-42],[6,-42],[-14,-38],[-32,-30],[-48,-20]];
 E.forEach((e,i)=>{const k=.5+.5*Math.sin(t*2.2+i*1.7);g.beginPath();g.arc(e[0],e[1]+2,2.4+k*.8,0,TAU);g.fillStyle=`rgba(255,${200+Math.round(k*50)},120,${.55+k*.45})`;g.fill()});
 fkGlow(g,10,-36,34,'#ffb040',.22+.1*Math.sin(t*2)+(o.glow||0)*.25);fkGlow(g,-30,-28,26,'#ff8a30',.18+.08*Math.sin(t*2.6+1));
 for(let i=0;i<3;i++){const p=((t*.35+i/3)%1),x=30-i*28+Math.sin(t*2+i)*4,y=-46-p*26;fkSpark(g,x,y,2.6*(1-p)+.6,'#ffd27a',(1-p)*.85)}
 // pectoral fan
 fa1_pec(g,60,14,-.4+fin*1.4,28,'#ffd070','#ff6a2a',.95);
 // barbels
 fa1_strand(g,[96,12,100,18,98,24,90,28],2.6,1.2,'#ffb070',1.8);
 fa1_strand(g,[92,14,93,20,88,25,82,26],2.2,1,'#ffa060',1.8);
 fkEye(g,74,-12,11,'#7a2a10',.2);fa1_lid(g,74,-12,11,fa1_blink(t,1.1),'#e8401e');
 // puckered carp mouth
 g.beginPath();g.ellipse(100,8,3.2,4,0,0,TAU);g.fillStyle='#5a1420';g.fill();g.lineWidth=2.2;g.strokeStyle=FKO;g.stroke();
 fa1_catch(g,o,'#ffc070');g.restore()};

/* ---------------- 3. Mossback Perch: grumpy humpbacked perch with five shadow bars ---------------- */
FISHART.moss=(g,t,o)=>{const sw=fkSway(o,3.6,.15),fin=Math.sin(t*4)*.1;g.save();g.rotate(-sw*.2);
 const B=()=>fkPath(g,[102,10,94,-6,68,-31,22,-48,-20,-41,-52,-23,-66,-8,-66,8,-50,18,-10,34,40,37,80,27,100,19]);
 const T=()=>fa1_path(g,['M',14,-8,'Q',-8,-12,-30,-30,'Q',-40,-34,-46,-30,'Q',-40,-12,-36,0,'Q',-40,12,-46,30,'Q',-40,34,-30,30,'Q',-8,12,14,8,'Z']);
 fa1_at(g,-58,0,sw,()=>{T();fkFill(g,fkLin(g,6,0,-46,0,['#5a9a30','#8ab83a','#ffa030']),2.6);fa1_ribs(g,T,6,0,[-44,-28,-40,-16,-38,-6,-38,6,-40,16,-44,28],.3)});
 // spiny front dorsal + soft rear dorsal
 const d=Math.sin(t*2)*1.5;
 fa1_path(g,['M',48,-34,'L',44,-60+d,'L',38,-44,'L',30,-70+d,'L',24,-50,'L',15,-74+d,'L',10,-52,'L',0,-72+d,'L',-4,-50,'L',-14,-64+d,'L',-16,-40,'Z']);
 g.lineJoin='round';fkFill(g,fkLin(g,0,-74,0,-40,['#c8e060','#3e7a2a']),2.4);
 fa1_at(g,0,0,0,()=>fkFin(g,[-14,-42,-20,-60+d,-38,-60+d,-52,-44,-50,-26],'#a8d050','#3e7a2a',[[-18,-44,-24,-58],[-28,-40,-34,-58],[-38,-36,-46,-48]],2.4));
 // bright orange belly fins
 fa1_at(g,26,32,-fin,()=>fkFin(g,[8,-4,4,12,-10,22,-16,14,-12,-4],'#ffb03a','#ff5a12',[[0,0,-8,18],[-6,0,-14,14]],2.4));
 fa1_at(g,-30,24,fin,()=>fkFin(g,[10,-6,6,10,-8,18,-22,12,-20,-6],'#ffb03a','#ff5a12',[[2,0,-4,14],[-6,0,-14,14],[-12,0,-20,8]],2.4));
 B();fkFill(g,fa1_grad(g,0,-48,0,37,[[0,'#235a1e'],[.35,'#4e9a2e'],[.62,'#a0cc44'],[1,'#f2e47c']]),3);
 fkScales(g,B,-66,96,-46,36,9,'#1e4a12',.2);
 // five dark vertical bars
 g.save();B();g.clip();g.fillStyle='#173a12';g.globalAlpha=.55;
 [[56,9],[30,11],[4,12],[-22,11],[-46,9]].forEach((b,i)=>{const x=b[0],w=b[1];fa1_path(g,['M',x-w,-52,'Q',x-w*.7,-12,x-w*.3,20,'Q',x,26,x+w*.3,20,'Q',x+w*.8,-12,x+w,-52,'Z']);g.fill()});g.restore();
 fkShade(g,B,-10,-48,'#0e2a0c',.35);fkShade(g,B,18,37,'#ffe080',.3);
 fa1_gloss(g,B,76,-22,40,-44,-16,-38,3.2,.55);
 fa1_gill(g,B,98,0,30,Math.PI*.7,Math.PI*1.3);
 fa1_pec(g,60,8,-.35+fin*1.3,26,'#ffd060','#ff7a1a',.95);
 // grumpy eye with a heavy brow
 fkEye(g,76,-12,10,'#c8781a',.25);fa1_lid(g,76,-12,10,Math.max(.4,fa1_blink(t,.7)),'#3a7a26',.42);
 g.beginPath();g.moveTo(64,-24);g.quadraticCurveTo(76,-24,88,-17);g.strokeStyle=FKO;g.lineWidth=3.4;g.lineCap='round';g.stroke();
 // frown with a jutting lip
 g.beginPath();g.moveTo(101,14);g.quadraticCurveTo(94,10,86,17);g.strokeStyle=FKO;g.lineWidth=2.6;g.stroke();
 fa1_catch(g,o);g.restore()};

/* ---------------- 4. Lantern Guppy: little blue body, enormous glowing paper-lantern fan tail ---------------- */
FISHART.lant=(g,t,o)=>{const sw=fkSway(o,2.6,.09),fin=Math.sin(t*5)*.14,gl=o.glow||0;g.save();g.rotate(-sw*.2);
 const B=()=>fkPath(g,[102,2,98,-22,72,-36,38,-34,16,-18,12,0,16,18,38,34,72,36,98,22]);
 // fan tail (joint at x=22)
 const N=9,A0=-1.12,A1=1.12,E=k=>{const a=A0+(A1-A0)*k/N,wob=Math.sin(t*2.4+k*.8)*2.5;return[-(124+wob)*Math.cos(a)*.98,(70+wob*.6)*Math.sin(a)]};
 const T=()=>{g.beginPath();g.moveTo(14,-8);const e0=E(0);g.quadraticCurveTo(-10,-24,e0[0],e0[1]);
  for(let k=0;k<N;k++){const a=E(k),b=E(k+1),m=E(k+.5);g.quadraticCurveTo(m[0]*1.09,m[1]*1.09,b[0],b[1])}g.quadraticCurveTo(-10,24,14,8);g.closePath()};
 fa1_at(g,22,0,sw,()=>{T();fkFill(g,(()=>{const q=g.createRadialGradient(-40,0,4,-30,0,120);q.addColorStop(0,'#fffbd8');q.addColorStop(.35,'#ffe070');q.addColorStop(.7,'#ffa034');q.addColorStop(1,'#e0461e');return q})(),2.8);
  // lantern frame: ribs + rings
  g.save();T();g.clip();g.strokeStyle='#b8401a';g.lineCap='round';
  for(let k=1;k<N;k++){const e=E(k);g.globalAlpha=.45;g.lineWidth=1.8;g.beginPath();g.moveTo(4,0);g.quadraticCurveTo(e[0]*.5,e[1]*.42,e[0],e[1]);g.stroke()}
  for(const s of[.42,.72]){g.globalAlpha=.3;g.lineWidth=1.6;g.beginPath();for(let k=0;k<=N*2;k++){const e=E(k/2),x=4+(e[0]-4)*s,y=e[1]*s;k?g.lineTo(x,y):g.moveTo(x,y)}g.stroke()}
  g.globalAlpha=.5;g.strokeStyle='#fff8d0';g.lineWidth=4;T();g.stroke();g.restore()});
 fkGlow(g,-34,0,92,'#ffb43a',.3+.1*Math.sin(t*1.8)+gl*.3);fkGlow(g,-28,0,40,'#fff0a0',.25+.08*Math.sin(t*2.6)+gl*.25);
 // dorsal + anal
 fa1_at(g,0,0,0,()=>{const d=Math.sin(t*3)*2;fkFin(g,[60,-32,48,-50+d,24,-52+d,16,-38,30,-28],'#5ae0e0','#2a70c8',[[50,-34,40,-48],[40,-32,28,-48]],2.4);
  fkFin(g,[50,32,38,46-d,22,46-d,18,30],'#5ae0e0','#2a70c8',[[40,32,30,44]],2.4)});
 B();fkFill(g,fkRad(g,64,-6,52,['#8ef6ec','#34c4d8','#2a6ad0','#1e2c84']),3);
 fkScales(g,B,10,96,-34,34,8,'#e0ffff',.22);
 fkShade(g,B,8,36,'#14206a',.4);
 fa1_gloss(g,B,82,-26,52,-36,26,-22,3.4,.7);
 fa1_gill(g,B,82,2,26,Math.PI*.74,Math.PI*1.26,'#14206a');
 // warm lantern light spilling onto the body's rear
 g.save();B();g.clip();const q=g.createRadialGradient(10,0,0,10,0,40);q.addColorStop(0,'rgba(255,190,80,.55)');q.addColorStop(1,'rgba(255,190,80,0)');g.fillStyle=q;g.fillRect(-30,-40,80,80);g.restore();
 fa1_pec(g,60,10,-.4+fin*1.5,20,'#b0fff6','#3a9ad8',.92);
 fkEye(g,76,-6,14,'#2a4aa0',.25);fa1_lid(g,76,-6,14,fa1_blink(t,2.2),'#34c4d8');
 g.beginPath();g.ellipse(84,12,5,3,0,0,TAU);g.fillStyle='rgba(255,140,180,.5)';g.fill();
 fa1_smile(g,99,8,96,12,91,10,2.2);
 fkSpark(g,-70+Math.sin(t*1.3)*6,-30,3+Math.sin(t*3)*1,'#fff6c0',.6+.3*Math.sin(t*3));fkSpark(g,-86,22+Math.sin(t*1.1)*4,2.4,'#fff6c0',.5+.4*Math.sin(t*2.4+2));
 g.restore()};

/* pebble loach barbels: far (behind body, darker) or near side; three thin tapered strands rooted under the snout */
function fa1_pbw(g,t,far){const R=far?[[102.5,11,-.22],[97,14.5,.32],[91,17,.84]]:[[104,10,-.42],[98.5,14,.14],[92.5,16.5,.66]];
 R.forEach((r,i)=>fa1_at(g,r[0],r[1],r[2]+Math.sin(t*1.8+i*1.3+far)*.09,()=>{const L=[15,17,15][i]*(far?.7:1);
  fa1_strand(g,[0,0,L*.3,L*.14,L*.62,L*.5,L*.74,L*.86,L*.8,L*1.04,L*.68,L*1.12,L*.58,L*1.04],far?2:2.4,.8,far?'#b08a6e':'#f8e2bc',1.5)}))}

/* ---------------- 5. Pebble Loach: sleepy sausage of sand and stones, with three pairs of whiskers ---------------- */
FISHART.pebble=(g,t,o)=>{const fl=o.flex||0,sw=fkSway(o,2.4,.13),fin=Math.sin(t*3)*.12,wh=Math.sin(t*1.8)*2;g.save();g.rotate(-sw*.18);
 // gentle travelling wiggle along the long body
 const bd=x=>Math.sin(x*.03-t*2.2)*(3.2+fl*3)*(1-x/180),bs=x=>(bd(x+1)-bd(x-1))/2,bp=a=>{const r=a.slice();for(let i=0;i<r.length;i+=2)r[i+1]+=bd(r[i]);return r};
 const B=()=>fkPath(g,bp([108,4,101,-12,80,-21,20,-21,-40,-18,-66,-12,-74,0,-66,12,-40,18,20,21,80,21,101,14]));
 const T=()=>fa1_path(g,['M',12,-7,'C',-6,-11,-20,-25,-31,-21,'C',-41,-14,-41,14,-31,21,'C',-20,25,-6,11,12,7,'Z']);
 const hy=bd(92),ha=Math.atan(bs(92));
 // far-side whiskers
 fa1_at(g,0,hy,ha,()=>fa1_pbw(g,t,1));
 fa1_at(g,-66,bd(-66),sw+Math.atan(bs(-66)),()=>{T();fkFill(g,fkLin(g,4,0,-38,0,['#e8b48a','#ffa08a','#ff6e7a']),2.6);fa1_ribs(g,T,4,0,[-34,-17,-38,-6,-38,6,-34,17],.28);
  g.save();T();g.clip();[[-20,-10,2.4],[-28,4,2],[-18,10,1.8]].forEach(s=>{g.beginPath();g.arc(...s,0,TAU);g.fillStyle='#c0505a';g.globalAlpha=.5;g.fill()});g.restore()});
 fa1_at(g,-2,-19+bd(-2),fin*.5,()=>fkFin(g,[9,2,3,-11,-12,-11,-15,2],'#ffc0a4','#ff7a76',[[2,0,-2,-9],[-6,0,-8,-9]],2.2));
 fa1_at(g,-12,18+bd(-12),-fin,()=>fkFin(g,[6,-2,0,9,-12,9,-10,-2],'#ffc0a4','#ff7a76',null,2.2));
 fa1_at(g,-46,15+bd(-46),fin,()=>fkFin(g,[6,-2,0,9,-12,9,-10,-2],'#ffc0a4','#ff7a76',null,2.2));
 B();fkFill(g,fa1_grad(g,0,-21,0,21,[[0,'#a8845a'],[.32,'#dcbf8e'],[.62,'#f6e6c2'],[1,'#fff4e4']]),3);
 // pebble spots: little rounded stones in warm and lilac tones
 g.save();B();g.clip();
 [[52,-12,5.2,4.2,'#8a6a4c'],[40,-2,4,3.2,'#8278a8'],[32,-15,5,3.8,'#a4704e'],[16,-6,6.4,4.6,'#7c6a96'],[2,-16,4.6,3.4,'#8a6a4c'],[-12,-3,5.2,3.8,'#a4704e'],
  [-26,-14,6,4.4,'#8278a8'],[-42,-5,4.6,3.6,'#8a6a4c'],[-54,-13,3.8,2.9,'#a4704e'],[-62,1,3.2,2.5,'#7c6a96'],[24,7,3.4,2.6,'#a4704e'],[-30,7,3.6,2.6,'#8a6a4c'],[50,7,3,2.3,'#7c6a96']].forEach(p=>{const y=p[1]+bd(p[0]);
  g.beginPath();g.ellipse(p[0],y,p[2],p[3],.2,0,TAU);g.fillStyle=p[4];g.globalAlpha=.9;g.fill();g.globalAlpha=.45;g.lineWidth=1.2;g.strokeStyle=FKO;g.stroke();
  g.globalAlpha=.6;g.beginPath();g.ellipse(p[0]-p[2]*.3,y-p[3]*.38,p[2]*.38,p[3]*.24,.2,0,TAU);g.fillStyle='#fff8ea';g.fill()});g.globalAlpha=1;g.restore();
 fkShade(g,B,4,24,'#ffe8d0',.3);fkShade(g,B,-6,-24,'#5a3e24',.38);
 g.save();B();g.clip();g.lineCap='round';g.beginPath();for(let x=90;x>=-50;x-=4){const y=-14+bd(x);x===86?g.moveTo(x,y):g.lineTo(x,y)}g.strokeStyle='rgba(255,255,255,.3)';g.lineWidth=6;g.stroke();g.strokeStyle='rgba(255,255,255,.62)';g.lineWidth=2.6;g.stroke();g.restore();
 fa1_at(g,0,hy,ha,()=>{const GC=()=>{g.beginPath();g.rect(40,-30,80,60)};
  fa1_gill(g,GC,101,0,35,Math.PI*.83,Math.PI*1.17,'#fff4e0',.5);g.save();g.translate(-1.6,0);fa1_gill(g,GC,101,0,35,Math.PI*.82,Math.PI*1.18,'#4a2c18',.8);g.restore();
  fa1_pec(g,48,12,-.42+fin*1.5,18,'#ffcab0','#ff7a76');
  // near-side whiskers: three thin barbels fanning down and forward from under the snout
  fa1_pbw(g,t,0);
  // sleepy, contented face
  fkEye(g,82,-6,9.5,'#5a3a2a',.2);fa1_lid(g,82,-6,9.5,Math.max(.56,fa1_blink(t,1.6)),'#cdb288',-.05);
  g.strokeStyle=FKO;g.lineWidth=1.8;g.lineCap='round';g.beginPath();g.moveTo(73,-7);g.lineTo(69.5,-9.5);g.stroke();g.beginPath();g.moveTo(75,-4);g.lineTo(71,-4.5);g.stroke();
  g.beginPath();g.ellipse(87,6,5.4,3.2,0,0,TAU);g.fillStyle='rgba(255,120,140,.55)';g.fill();
  fa1_smile(g,105,6,101,10,95,8.5,2.3)});
 // sleepy bubbles
 for(let i=0;i<2;i++){const p=(t*.28+i*.5)%1,r=1.8+p*3.4,bx=104+Math.sin(t*2+i*2)*3,by=-18-p*50+hy;g.globalAlpha=(1-p)*.85;g.beginPath();g.arc(bx,by,r,0,TAU);g.strokeStyle='#d8f4ff';g.lineWidth=1.4;g.stroke();
  g.beginPath();g.arc(bx-r*.35,by-r*.35,r*.25,0,TAU);g.fillStyle='#fff';g.fill();g.globalAlpha=1}
 fa1_catch(g,o);g.restore()};

/* ---------------- 6. Copper Trout: gleaming copper trout with a rosy band and red/black spots ---------------- */
FISHART.copper=(g,t,o)=>{const sw=fkSway(o,3.8,.15),fin=Math.sin(t*4.4)*.1;g.save();g.rotate(-sw*.2);
 const B=()=>fkPath(g,[104,4,98,-13,72,-29,20,-35,-30,-27,-58,-13,-68,0,-58,12,-30,24,20,31,72,27,98,15]);
 const T=()=>fa1_path(g,['M',14,-8,'Q',-6,-10,-30,-30,'L',-42,-33,'Q',-36,0,-42,33,'L',-30,30,'Q',-6,10,14,8,'Z']);
 const spot=(x,y,r)=>{g.beginPath();g.arc(x,y,r,0,TAU);g.fillStyle='#1e1020';g.fill()};
 fa1_at(g,-60,0,sw,()=>{T();fkFill(g,fkLin(g,4,0,-42,0,['#b8703a','#8a7034','#6a6a2a']),2.6);fa1_ribs(g,T,4,0,[-40,-30,-38,-18,-36,-6,-36,6,-38,18,-40,30],.25);
  g.save();T();g.clip();[[-14,-12,1.8],[-24,-20,2],[-30,-8,1.6],[-22,6,1.8],[-32,18,2],[-14,14,1.5],[-36,-24,1.5]].forEach(s=>spot(...s));g.restore()});
 // dorsal (spotted, with a straight leading ray) + adipose
 const d=Math.sin(t*2.4)*1.5,D=()=>fa1_path(g,['M',26,-30,'L',20,-54+d,'Q',8,-58+d,-6,-52+d,'Q',-12,-44,-16,-28,'Z']);
 D();fkFill(g,fkLin(g,0,-58,0,-30,['#c8a050','#7a6a2c']),2.4);fa1_ribs(g,D,0,-26,[18,-52,10,-56,2,-55,-6,-52],.3);
 g.save();D();g.clip();[[12,-46,1.8],[2,-40,1.6],[-4,-49,1.5],[16,-38,1.4],[6,-51,1.3]].forEach(s=>spot(...s));g.globalAlpha=.6;g.strokeStyle='#fff3d8';g.lineWidth=2;g.beginPath();g.moveTo(25,-30);g.lineTo(19,-54+d);g.stroke();g.restore();
 fa1_path(g,['M',-40,-21,'Q',-42,-31,-48,-31,'Q',-53,-29,-55,-17,'Z']);fkFill(g,fkLin(g,0,-32,0,-18,['#a89a48','#6a5a24']),2.2);
 // belly fins: orange with crisp white leading edges
 const lf=(x,y,a,p)=>fa1_at(g,x,y,a,()=>{const F=()=>fkPath(g,p);fkFin(g,p,'#ffa24a','#e0602a',[[0,0,p[4],p[5]]],2.3);g.save();F();g.clip();g.beginPath();g.moveTo(p[0]+1,p[1]);g.quadraticCurveTo((p[0]+p[2])/2+2,(p[1]+p[3])/2,p[2]+2,p[3]);g.strokeStyle='#fff6ea';g.lineWidth=3.4;g.stroke();g.restore()});
 lf(10,28,-fin,[8,-2,2,12,-12,15,-12,-2]);lf(-34,22,fin,[8,-4,4,10,-12,13,-14,-4]);
 B();fkFill(g,fa1_grad(g,0,-35,0,31,[[0,'#46561e'],[.22,'#7a6a28'],[.42,'#d8743a'],[.62,'#ffa868'],[1,'#fff0d8']]),3);
 fkScales(g,B,-66,94,-34,30,8,'#6a3a1a',.16);
 g.save();B();g.clip();
 // rosy band
 g.fillStyle=fa1_grad(g,0,-8,0,12,[[0,'rgba(255,110,150,0)'],[.5,'rgba(255,100,150,.75)'],[1,'rgba(255,110,150,0)']]);g.fillRect(-80,-8,190,20);
 // metallic sheen
 g.fillStyle=fa1_grad(g,0,-22,0,-8,[[0,'rgba(255,230,180,0)'],[.5,'rgba(255,236,200,.5)'],[1,'rgba(255,230,180,0)']]);g.fillRect(-80,-22,190,14);
 // black spots on the back, red spots with pale halos on the band
 [[50,-20,1.8],[36,-26,2.2],[24,-18,1.8],[10,-26,2.2],[-4,-18,1.9],[-18,-24,2.2],[-30,-16,1.8],[-44,-18,1.8],[-54,-8,1.5],[30,-10,1.4],[-12,-8,1.4]].forEach(s=>spot(...s));
 [[40,4,2.6],[14,2,2.8],[-12,4,2.6],[-36,2,2.4]].forEach(s=>{g.beginPath();g.arc(s[0],s[1],s[2]+1.8,0,TAU);g.fillStyle='#e8f0ff';g.globalAlpha=.85;g.fill();g.globalAlpha=1;g.beginPath();g.arc(s[0],s[1],s[2],0,TAU);g.fillStyle='#e01e2a';g.fill()});
 g.restore();
 fkShade(g,B,-12,-35,'#24300c',.35);
 fa1_gloss(g,B,80,-21,36,-33,-30,-24,3.2,.7);
 fa1_gill(g,B,98,0,28,Math.PI*.72,Math.PI*1.28);
 fa1_pec(g,64,8,-.38+fin*1.4,26,'#ffb060','#e8602a');
 const tw=Math.max(0,Math.sin(t*1.7));fkSpark(g,30,-22,4+tw*3,'#fff6e0',tw*.9);
 fkEye(g,78,-8,11,'#d8a020',.3);fa1_lid(g,78,-8,11,fa1_blink(t,2.9),'#c8703a');
 fa1_smile(g,103,6,96,11,88,8,2.4);
 fa1_catch(g,o,'#ffd0a0');g.restore()};

/* ---------------- 7. Whisker Catfish: grumpy old indigo catfish, broad flat head, four long curling whiskers ---------------- */
/* whisker: dark under-stroke then a lighter tapered strand on top */
function fa1_wsk(g,b,w0,col){fa1_strand(g,b,w0,1.3,col,2.2)}
FISHART.whisker=(g,t,o)=>{const sw=fkSway(o,2.8,.14),fin=Math.sin(t*3)*.1,w1=Math.sin(t*1.6)*2.4,w2=Math.sin(t*1.3+1)*2.4;g.save();g.rotate(-sw*.2);
 // broad flat head clearly wider than the slim tapering body
 const B=()=>fkPath(g,[113,4,111,-11,98,-25,70,-33,38,-29,4,-21,-38,-13,-64,-7,-72,0,-64,7,-38,13,4,22,40,30,74,36,100,31,112,19]);
 const T=()=>fa1_path(g,['M',14,-6,'Q',-4,-8,-24,-24,'Q',-34,-30,-41,-26,'Q',-36,-10,-31,0,'Q',-36,10,-41,26,'Q',-34,30,-24,24,'Q',-4,8,14,6,'Z']);
 const F1='#5cc8c4',F2='#1d4570';
 // far whiskers (behind the body): long one from the far lip corner, short one from the chin
 fa1_wsk(g,[92,10,84,4,76,-6,70,-18,64,-30,60,-40+w2,55,-48+w2,49,-56+w2,49,-64+w2,55,-67+w2],2.8,'#7d96c4');
 fa1_wsk(g,[104,22,108,29,109,36-w1*.6,105,42-w1*.6,103,45-w1*.6,99,46-w1*.6,97,43-w1*.6],2.2,'#7d96c4');
 fa1_at(g,-66,0,sw,()=>{T();fkFill(g,fkLin(g,4,0,-41,0,['#2c4a7a','#22708c',F1]),2.6);fa1_ribs(g,T,4,0,[-39,-24,-36,-14,-33,-4,-33,4,-36,14,-39,24],.3)});
 // dorsal with spine, adipose, long anal fin (teal-tinted)
 const d=Math.sin(t*2)*1.5;
 fkFin(g,[22,-26,18,-52+d,10,-50+d,-4,-34,-8,-18],F1,F2,[[16,-28,16,-48],[8,-28,4,-44]],2.4);
 fkFin(g,[-30,-14,-36,-26,-52,-22,-56,-8],F1,F2,null,2.2);
 fkFin(g,[-4,20,-10,34-d,-40,28-d,-62,17-d,-62,5],F1,F2,[[-10,20,-14,31],[-22,18,-26,29],[-34,15,-40,25],[-46,11,-52,20]],2.4);
 fa1_at(g,34,30,-fin,()=>fkFin(g,[8,-2,2,11,-12,13,-10,-2],'#7ad8d0',F2,null,2.2));
 B();fkFill(g,fa1_grad(g,0,-33,0,36,[[0,'#1a2848'],[.28,'#283e6c'],[.48,'#34507e'],[.6,'#5a74a4'],[.68,'#cfdaee'],[.9,'#f2efe2'],[1,'#f4d8a8']]),3);
 // freckles + old-timer wrinkles
 g.save();B();g.clip();g.fillStyle='#9ec4ee';g.globalAlpha=.4;
 [[58,-22,1.6],[44,-24,1.3],[30,-18,1.5],[16,-19,1.3],[-2,-15,1.5],[-18,-11,1.2],[-34,-9,1.4],[50,-11,1.2],[22,-8,1.2],[6,-7,1.1]].forEach(s=>{g.beginPath();g.arc(s[0],s[1],s[2],0,TAU);g.fill()});
 g.globalAlpha=.45;g.strokeStyle=FKO;g.lineWidth=1.6;g.lineCap='round';
 g.beginPath();g.moveTo(98,-21);g.quadraticCurveTo(103,-19,106,-15);g.stroke();g.beginPath();g.moveTo(100,-24);g.quadraticCurveTo(104,-22,106,-20);g.stroke();g.restore();
 fkShade(g,B,-8,-33,'#0c1430',.4);
 // warm amber edge along the belly
 fkShade(g,B,22,37,'#f0a040',.55);
 fa1_gloss(g,B,98,-20,64,-33,-6,-19,3,.5);
 fa1_gill(g,B,106,4,44,Math.PI*.75,Math.PI*1.19,null,.6);
 // pectoral with a pale spine
 fa1_pec(g,62,18,-.32+fin*1.3,26,'#8ae0d8','#1d4570');
 fa1_at(g,62,18,-.32+fin*1.3,()=>{g.beginPath();g.moveTo(2,-3.5);g.bezierCurveTo(-8,-9,-18,-9,-26,-4);g.strokeStyle='#e4f6f4';g.lineWidth=2.2;g.lineCap='round';g.stroke()});
 // wide grumpy mouth with pale lips across the flat snout
 fa1_path(g,['M',113,6,'Q',106,12,92,12,'Q',89,15,92,18,'Q',106,20,112,13,'Z']);g.fillStyle='#e8c8c4';g.fill();g.lineWidth=2.2;g.strokeStyle=FKO;g.stroke();
 g.beginPath();g.moveTo(112,9);g.quadraticCurveTo(103,15,92,15);g.lineWidth=2.6;g.stroke();
 // near whiskers: long one from the upper-lip corner sweeps back and up in an S; short chin one droops below
 fa1_wsk(g,[92,14,82,21,70,22,60,14,50,6,44,-8,38,-22,33,-34,28,-42+w1,22,-50+w1,21,-58+w1*1.3,27,-62+w1*1.3],3.8,'#d8e6fa');
 fa1_wsk(g,[96,19,99,27,98,35-w2*.6,93,42-w2*.6,89,47-w2*.6,83,48-w2*.6,81,44-w2*.6],2.8,'#d8e6fa');
 // half-lidded grumpy eye + bushy brow
 fkEye(g,86,-15,9.5,'#e8a822',.35);fa1_lid(g,86,-15,9.5,Math.max(.5,fa1_blink(t,.9)),'#2a4170',.3);
 g.beginPath();g.moveTo(75,-26);g.quadraticCurveTo(86,-30,97,-22);g.strokeStyle=FKO;g.lineWidth=6.6;g.lineCap='round';g.stroke();g.strokeStyle='#d8def4';g.lineWidth=4;g.stroke();
 fa1_catch(g,o,'#c8d8ff');g.restore()};

/* ---------------- 8. Lily Sunfish: round blue-green disc with lily-pad rings and a sunset belly ---------------- */
FISHART.lily=(g,t,o)=>{const sw=fkSway(o,3.4,.15),fin=Math.sin(t*4)*.12;g.save();g.rotate(-sw*.18);
 const B=()=>fkPath(g,[102,4,98,-25,72,-49,26,-57,-14,-49,-38,-29,-50,-11,-58,0,-50,11,-38,29,-14,49,26,55,72,47,98,25]);
 const T=()=>fa1_path(g,['M',14,-9,'C',-4,-12,-26,-34,-42,-30,'C',-50,-16,-50,16,-42,30,'C',-26,34,-4,12,14,9,'Z']);
 fa1_at(g,-50,0,sw,()=>{T();fkFill(g,fkLin(g,4,0,-46,0,['#2a9a9a','#40b8a0','#8ad8a8']),2.6);fa1_ribs(g,T,4,0,[-40,-28,-44,-16,-46,-6,-46,6,-44,16,-40,28],.28)});
 // dorsal: spiny front, soft round rear; anal mirrored
 const d=Math.sin(t*2.2)*2;
 fa1_path(g,['M',58,-44,'L',52,-62+d,'L',46,-52,'L',38,-70+d,'L',32,-56,'L',22,-74+d,'L',16,-56,'L',8,-62,'Z']);fkFill(g,fkLin(g,0,-74,0,-46,['#8ae0c0','#1e7a8a']),2.4);
 fkFin(g,[10,-56,6,-74+d,-20,-76+d,-42,-56,-36,-34],'#6ad8b8','#1e7a8a',[[4,-54,-2,-70],[-8,-52,-16,-70],[-20,-48,-32,-60]],2.4);
 fkFin(g,[16,52,8,70-d,-18,72-d,-40,52,-34,30],'#ffb860','#e8642a',[[8,50,2,66],[-6,48,-14,66],[-18,44,-28,58]],2.4);
 fa1_at(g,28,52,-fin,()=>fkFin(g,[8,-4,4,10,-10,14,-12,-4],'#ffb860','#e8642a',null,2.2));
 B();fkFill(g,fa1_grad(g,0,-57,0,55,[[0,'#145a78'],[.3,'#2a9c9a'],[.52,'#58c6a2'],[.66,'#ffb04a'],[1,'#ff7428']]),3);
 g.save();B();g.clip();
 // lily pads: notched discs with fine veins
 [[40,-34,10,.3],[14,-42,8,2.2],[-12,-31,10.5,4],[18,-18,7,1],[-32,-12,7.5,5.2],[-6,-10,6,2.8],[-31,-26,5.5,.9],[32,-3,5.5,3.6]].forEach(p=>{const a=p[3],r=p[2];
  g.beginPath();g.moveTo(p[0],p[1]);g.arc(p[0],p[1],r,a+.36,a+TAU-.36);g.closePath();g.fillStyle='#5ed4a2';g.globalAlpha=.55;g.fill();g.globalAlpha=.9;g.strokeStyle='#c4ffba';g.lineWidth=1.5;g.stroke();
  g.globalAlpha=.45;g.lineWidth=1;for(let k=1;k<5;k++){const b=a+.36+k*(TAU-.72)/5;g.beginPath();g.moveTo(p[0],p[1]);g.lineTo(p[0]+Math.cos(b)*r*.8,p[1]+Math.sin(b)*r*.8);g.stroke()}});
 g.globalAlpha=1;
 // turquoise cheek stripes
 g.strokeStyle='#8af4ff';g.lineWidth=1.3;g.globalAlpha=.7;g.lineCap='round';
 [[0,0],[0,8]].forEach(s=>{g.beginPath();g.moveTo(98,2+s[1]);g.quadraticCurveTo(87,-3+s[1],77,4+s[1]);g.quadraticCurveTo(69,9+s[1],63,5+s[1]);g.stroke()});
 g.restore();
 fkShade(g,B,-20,-57,'#0a3050',.4);fkShade(g,B,30,55,'#e8401e',.3);
 fa1_gloss(g,B,82,-34,46,-54,0,-50,3.4,.6);
 fa1_gill(g,B,98,2,40,Math.PI*.74,Math.PI*1.24);
 // the dark ear flap: a short tab on the operculum's trailing edge, behind the gill arc at eye height, pointing back toward the tail; red rim on its rear edge
 const EAR=()=>fa1_path(g,['M',52,-24.5,'C',47,-25,40,-24.5,37,-20,'C',40,-15.5,47,-15,52,-15.5,'Q',54.5,-20,52,-24.5,'Z']);
 EAR();g.fillStyle='#0e1028';g.fill();
 g.save();EAR();g.clip();g.beginPath();g.rect(30,-30,14,20);g.clip();EAR();g.strokeStyle='#ff3a2e';g.lineWidth=7.5;g.stroke();g.restore();
 g.save();EAR();g.clip();g.beginPath();g.ellipse(47,-22,3.5,1.4,-.1,0,TAU);g.fillStyle='#ffffff';g.globalAlpha=.22;g.fill();g.restore();
 EAR();g.lineWidth=2.2;g.strokeStyle=FKO;g.stroke();
 // pectoral
 fa1_pec(g,40,12,-.3+fin*1.4,28,'#ffe0a0','#ff9a3a',.92);
 fkEye(g,80,-20,11,'#d83a1a',.25);fa1_lid(g,80,-20,11,fa1_blink(t,3.6),'#2a9c9a');
 fa1_smile(g,101,6,97,10,92,8,2.2);
 fa1_catch(g,o);g.restore()};
