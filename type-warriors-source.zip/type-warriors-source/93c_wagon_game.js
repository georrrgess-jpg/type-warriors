/* ===== LANTERN CARAVAN: the run =====
   A canvas mode like the Warden's Arena: S.mode='wagon', S.wr=1, and update/draw are wrapped to run wrUpdate/wrDraw.
   Everything on screen lives in screen space; the world scrolls under the wagon by WRX.x (world units travelled).
   Layout (1600x900, ground GY=770): pet 235, hero 330, wagon rear axle 640 (body 440..850), monsters stand at 930.
   Input: a capture-phase keydown (letters, Tab, Enter, Escape) plus key(c) for the touch keyboard. */
let WRX=null;
const wrRM=()=>{try{return ccReduce()}catch(e){return false}};
const wrClamp=(v,a,b)=>v<a?a:v>b?b:v;
const wrEase=k=>{k=wrClamp(k,0,1);return k*k*(3-2*k)};
const wrOver=k=>{const c1=1.70158,c3=c1+1,x=wrClamp(k,0,1)-1;return 1+c3*x*x*x+c1*x*x};
/* ---------- start / leave ---------- */
function wrStart(id){const rt=WR_RT(id),w=WRP();try{if(ST.res==='auto')applyLayout()}catch(e){}
 reset();S.mode='wagon';S.view='wagon';S.wr=1;S.camp=0;
 WRX={rt,tk:((WRX&&WRX.tk)||0)+1,t:0,time:0,x:0,v:0,tv:0,accel:0,int:WRT.MAXINT,leg:0,mobs:[],haz:null,hazT:7+Math.random()*4,tgt:null,
  flare:0,flareOn:0,flareFx:0,flares:0,combo:0,maxCombo:0,ok:0,chars:0,kills:0,repairs:0,coins:0,coinFly:[],fx:[],tx:[],rings:[],shots:[],
  st:'roll',pause:false,over:false,resT:0,shake:0,lunge:0,dash:null,heroPose:null,poseT:0,toast:null,spawnT:2.6,wave:0,boss:null,bossDone:0,
  gx:rt.len+1150,gateT:0,doneT:0,won:false,drv:{mode:'idle',t0:-9,dur:0},petHop:-9,petFl:-9,crack:[],ping:null,rm:wrRM(),hitFl:0,lastHit:-9,
  wheel:0,kick:0,swing:0,swv:0,embers:[],look:{lan:w.lan,ban:w.ban,paint:w.paint},result:null,fade:1,wpm:0,coinBump:0,flareFull:0,ambush:0};
 try{WRX.bake=wrBake(rt)}catch(e){console.error(e)}
 hide();try{ensureAudio()}catch(e){}try{inp.blur()}catch(e){}
 wrToast('Clear the road. Repair the wagon. Reach the gate.',3.4,'#fff8e8');wrDriver('point',1.4);wrSfx('start')}
function wrLeave(){const R=WRX;if(R&&!R.over){try{WRP().runs++;save()}catch(e){}}WRX=null;S.wr=0;if(S.mode==='wagon'||S.mode==='over')S.mode='title';try{pb.classList.remove('wrpb');pb.style.display='none';dkCorner()}catch(e){}}
function wrQuit(){wrLeave();if(typeof wagonMenu==='function')wagonMenu(title);else title()}
function wrRestart(){const id=WRX?WRX.rt.id:'mill';wrLeave();wrStart(id)}
{const t0=title;title=function(){if(S.wr||WRX){wrLeave()}return t0.apply(this,arguments)}}
{const u0=update;update=function(dt){if(S.wr&&WRX)return wrUpdate(dt);return u0.apply(this,arguments)}}
{const d0=draw;draw=function(){if(S.wr&&WRX)return wrDraw();return d0.apply(this,arguments)}}
/* ---------- small helpers ---------- */
function wrToast(txt,dur,c){WRX.toast={txt,t:dur||2,d:dur||2,c:c||'#ffd45a'}}
function wrDriver(mode,dur){if(!WRX)return;WRX.drv={mode,t0:WRX.t,dur:dur||1}}
function wrText(x,y,s,c,sz){WRX.tx.push({x,y,s,c,sz:sz||24,a:0,d:1.2})}
function wrRing(x,y,c,max,w,fl){WRX.rings.push({x,y,t:0,d:.55,r0:10,max:max||120,fl:fl==null?.4:fl,c:c||'#ffd45a',w:w||5})}
function wrSfx(k,v){try{switch(k){
 case 'key':beep(700+Math.min(v||0,30)*15,.04);break;
 case 'clink':beep(1180+Math.min(v||0,20)*20,.05,'triangle',.5);break;
 case 'miss':beep(110,.08,'sawtooth',.6);break;
 case 'slip':beep(260,.06,'triangle',.6);break;
 case 'none':beep(150,.04,'triangle',.3);break;
 case 'kill':beep(520+(v||0)*30,.12,'triangle',.7);break;
 case 'jam':beep(140,.25,'sawtooth',.7);beep(90,.3,'square',.4);break;
 case 'free':beep(330,.08,'triangle',.6);setTimeout(()=>beep(494,.1,'triangle',.6),80);break;
 case 'hit':beep(70,.3,'sawtooth',1);break;
 case 'flare':beep(392,.1,'triangle',.7);setTimeout(()=>beep(784,.3,'triangle',.7),60);setTimeout(()=>beep(1568,.5,'sine',.5),140);break;
 case 'coin':beep(1318+Math.random()*300,.05,'triangle',.1);break;
 case 'milestone':beep(1000,.2,'triangle',.9);break;
 case 'start':beep(392,.08,'triangle',.4);setTimeout(()=>beep(523,.1,'triangle',.4),110);break;
 case 'leg':beep(659,.08,'triangle',.5);setTimeout(()=>beep(880,.12,'triangle',.5),90);break;
 case 'gate':jingle('win');break;
 case 'break':jingle('lose');break;
 case 'boss':jingle('boss');break}}catch(e){}}
/* ---------- words ---------- */
function wrOnScreen(){const R=WRX,o=R.mobs.filter(e=>e.st!=='dead'&&e.st!=='fling').map(e=>e.w);if(R.haz)o.push(R.haz.w);return o}
function wrWord(role){const R=WRX,d=6*R.rt.d+R.leg*2;return pickWord(role,WR_WORDS,d,wrOnScreen())}
function wrNewWord(e){e.w=wrWord(e.boss?2:WR_ROLE(e.id));e.i=0;e.slip=0;e.bad=0}
/* ---------- monsters ---------- */
function wrSpawn(id,off){const R=WRX,M=MON[id];if(!M)return null;const d=R.rt.d,boss=!!M.boss,role=boss?2:WR_ROLE(id);
 const e={id,x:WRT.SPAWNX+(off||0),y:GY,h:M.h*(boss?.78:.92),th:M.th,sp:(M.sp||50)*.85*(1+.12*(d-1))*(M.fly?.9:1)*(.92+Math.random()*.16),fly:!!M.fly,hov:M.fly?190+Math.random()*60:0,w:'',i:0,slip:0,bad:0,badT:0,fl:0,lg:0,st:'walk',at:0,t:0,dt:0,ph:Math.random()*6,boss,phs:boss?3:1,kb:0,rot:0,vx:0,vy:0,vr:0,sx:WRT.AX+(boss?60:0)};
 e.w=wrWord(role);if(boss){e.sx=WRT.AX+70;e.sp=66}R.mobs.push(e);return e}
function wrSpawnWave(){const R=WRX,rt=R.rt,d=rt.d,last=R.leg===rt.legs-1,alive=R.mobs.filter(e=>e.st!=='dead'&&e.st!=='fling').length;
 if(last&&rt.boss&&!R.boss&&!R.bossDone){if(alive){R.spawnT=1;return}R.boss=wrSpawn(rt.boss,0);R.spawnT=99;wrToast('The Headless Horseman rides!',2.4,'#ff8a9a');wrSfx('boss');wrDriver('sad',1.5);return}
 if(R.boss&&!R.bossDone){R.spawnT=6;if(alive<2&&Math.random()<.6)wrSpawn('bat',0);return}
 const cap=3+(d-1)+(last?1:0);if(alive>=cap){R.spawnT=1;return}
 let n=1+(Math.random()<.5?1:0)+(d>=2&&Math.random()<.35?1:0)+(last?1:0);n=Math.min(n,cap-alive);
 if(last&&!R.ambush){R.ambush=1;wrToast('Ambush!',1.6,'#ff8a9a')}
 const pool=rt.mobs;for(let i=0;i<n;i++)wrSpawn(pool[Math.random()*pool.length|0],i*190+Math.random()*60);
 R.wave++;R.spawnT=(4.5+Math.random()*2.5)/(1+.25*(d-1))*(last?.7:1)}
function wrMobTick(e,dt){const R=WRX;e.t+=dt;e.fl=Math.max(0,e.fl-dt);e.badT=Math.max(0,e.badT-dt);
 if(e.st==='walk'){e.x-=(e.sp+R.v*(e.fly?.6:1))*dt;if(e.fly)e.y=GY-e.hov+Math.sin(e.t*4.5+e.ph)*10;if(e.x<=e.sx){e.x=e.sx;e.st='attack';e.at=0;e.hit=0}}
 else if(e.st==='attack'){e.at+=dt;const k=Math.min(1,e.at/.5);e.lg=Math.sin(k*Math.PI);if(e.fly)e.y=GY-e.hov+Math.sin(k*Math.PI)*(e.hov-130);if(!e.hit&&e.at>=.25){e.hit=1;if(R.st==='roll')wrHit(e)}if(e.at>=.5){e.st='wait';e.at=0;e.lg=0;wrNewWord(e);if(R.tgt===e)R.tgt=null}}
 else if(e.st==='wait'){e.at+=dt;const cd=e.boss?3.2:WRT.HITCD,k=Math.min(1,e.at/cd);e.x=e.sx+(1-wrEase(k))*52;if(e.fly)e.y=GY-e.hov+Math.sin(e.t*4.5+e.ph)*10;if(e.at>=cd&&R.st==='roll'){e.st='attack';e.at=0;e.hit=0}}
 else if(e.st==='kb'){e.at+=dt;const k=Math.min(1,e.at/.6);e.x=e.kx0+wrEase(k)*170;if(k>=1){e.st='walk';e.kb=0}}
 else if(e.st==='dead'){e.dt+=dt}
 else if(e.st==='fling'){e.dt+=dt;e.x+=e.vx*dt;e.y+=e.vy*dt;e.vy+=900*dt;e.rot+=e.vr*dt}}
function wrKill(e){const R=WRX;R.kills++;R.flare=Math.min(WRT.FLARE,R.flare+6);if(R.tgt===e)R.tgt=null;
 const cx=e.x,cy=e.y-e.h*.5,col=e.boss?'#ff8a9a':'#ffd45a';
 if(e.boss&&e.phs>1){e.phs--;e.st='kb';e.at=0;e.kx0=e.x;e.kb=1;e.fl=.5;wrNewWord(e);ptBurst(R.fx,cx,cy,26,['#ff8a9a','#fff'],{v:420,s:5});wrRing(cx,cy,'#ff8a9a',200,6);wrText(cx-170,cy-30,e.phs===2?'Driven back!':'Once more!','#ff8a9a',30);R.shake=Math.max(R.shake,10);R.lunge=1;wrHeroStrike(e);wrSfx('kill',6);return}
 if(e.boss){R.bossDone=1;R.boss=null;wrToast('The Horseman is banished!',2.4,'#ffd45a');wrSfx('gate')}
 e.st='dead';e.dt=0;e.lg=0;
 const n=Math.max(1,Math.round(e.w.length/4))*(e.boss?12:1)*2;R.coinFly.push({x:cx,y:cy,tx:1232,ty:42,u:0,n,ph:Math.random()*6});
 ptBurst(R.fx,cx,cy,e.boss?48:22,[col,'#fff8e8','#ff9a5a'],{v:e.boss?460:330,s:5});ptBurst(R.fx,cx,e.y-10,10,'#6a5a7a',{v:140,s:6,k:'dust',up:1,sp:2.6,g:60});wrRing(cx,cy,col,e.boss?240:130,5);
 R.lunge=1;wrHeroStrike(e);R.shake=Math.max(R.shake,e.boss?16:6);R.petHop=R.t;if(R.kills%3===1)wrDriver('cheer',.9);wrSfx('kill',Math.min(8,R.combo/10|0))}
/* the hero dashes to the monster and back (knight, rogue); archers and mages shoot */
function wrHeroStrike(e){const R=WRX,p=P.path;if(p==='archer'||p==='mage'){R.shots.push({x:WRT.HX+70,y:GY-130,tx:e.x,ty:e.y-e.h*.5,u:0,k:p});return}
 if(p==='rogue')R.shots.push({x:WRT.HX+70,y:GY-118,tx:e.x,ty:e.y-e.h*.5,u:0,k:'rogue'});
 if(R.rm)return;R.dash={t:0,x1:Math.max(WRT.HX+40,e.x-105)}}
/* ---------- the wagon takes a hit ---------- */
function wrHit(e,why){const R=WRX;if(R.st!=='roll')return;R.int--;R.shake=Math.max(R.shake,14);R.hitFl=1;R.lastHit=R.t;R.crack.push({i:R.int,t:0});R.petFl=R.t;
 const fx=WRT.WX+200,fy=GY-120;ptBurst(R.fx,fx,fy,18,['#ffd45a','#ff9a5a','#fff'],{v:340,s:5});ptBurst(R.fx,fx+20,GY-20,12,'#7a5a3a',{v:160,s:6,k:'dust',up:1,sp:2.4,g:80});wrRing(fx,fy,'#ff8a9a',150,6);
 wrText(fx,fy-60,why==='axle'?'Axle cracked!':'-1 shield','#ff8a9a',30);wrDriver('sad',1.2);wrSfx('hit');R.combo=0;
 if(R.int<=0)wrBreak()}
function wrBreak(){const R=WRX;R.st='break';R.doneT=0;R.won=false;R.tgt=null;R.haz=null;R.dash=null;wrDriver('sad',9);for(const e of R.mobs)if(e.st!=='dead'&&e.st!=='fling'){e.st='wait';e.at=-99;e.lg=0}
 ptBurst(R.fx,WRT.WX+120,GY-60,40,['#7a5a3a','#5a3a2a','#ffd45a'],{v:300,s:6,k:'dust',up:1,sp:2.8,g:200});wrToast('The wagon broke down...',2.6,'#ff8a9a');wrSfx('break')}
/* ---------- hazards ---------- */
function wrHazOk(){const R=WRX;if(R.st!=='roll'||R.haz)return false;if(R.x>R.rt.len*.9)return false;if(R.boss&&!R.bossDone)return false;return !R.mobs.some(e=>e.st!=='dead'&&e.st!=='fling'&&e.x<WRT.AX+300)}
function wrHazOpen(){const R=WRX,ks=R.rt.haz,k=ks[Math.random()*ks.length|0],H=WR_HAZ[k],firsts=new Set(wrOnScreen().map(w=>w[0]));let vs=H.verbs.filter(v=>!firsts.has(v[0]));if(!vs.length)vs=H.verbs;
 R.haz={hz:1,k,w:vs[Math.random()*vs.length|0],i:0,slip:0,bad:0,badT:0,t:H.fuse,fuse:H.fuse,x:WRT.WX+150,y:GY-150,h:0,fl:0,warn:0};
 wrDriver('think',H.fuse+1);wrToast(H.say,1.8,'#9fd0ff');wrSfx('jam');R.shake=Math.max(R.shake,8);
 ptBurst(R.fx,WRT.WX+150,GY-30,16,['#ffd45a','#ff9a5a'],{v:260,s:4,up:1,sp:2.2,g:300});ptBurst(R.fx,WRT.WX+150,GY-10,10,'#8a7a6a',{v:120,s:7,k:'dust',up:1,sp:2.6,g:60})}
function wrHazNext(){const R=WRX;R.hazT=(10+Math.random()*6)/(1+.15*(R.rt.d-1))}
function wrRepair(){const R=WRX,h=R.haz;if(!h)return;R.repairs++;R.flare=Math.min(WRT.FLARE,R.flare+4);R.haz=null;if(R.tgt===h)R.tgt=null;wrHazNext();R.kick=1;
 ptBurst(R.fx,h.x,GY-40,24,['#ffd45a','#fff8e8','#9fd0ff'],{v:360,s:5});ptBurst(R.fx,h.x-20,GY-6,14,'#8a7a6a',{v:200,s:7,k:'dust',up:1,sp:2.4,g:60});wrRing(h.x,GY-60,'#9fd0ff',140,5);
 wrText(h.x,GY-200,'Rolling!','#9fd0ff',30);wrDriver('cheer',1);wrSfx('free')}
function wrHazFail(){const R=WRX,h=R.haz;if(!h)return;R.haz=null;if(R.tgt===h)R.tgt=null;wrHazNext();wrHit(null,'axle');R.kick=.6}
/* ---------- Lantern Flare ---------- */
function wrFlare(){const R=WRX;if(!R||R.flare<WRT.FLARE||R.flareOn>0||R.st!=='roll'||R.pause||R.over)return;R.flare=0;R.flares++;R.flareOn=3;R.flareFx=.75;R.tgt=null;
 for(const e of R.mobs){if(e.st==='dead'||e.st==='fling')continue;if(e.boss){e.st='kb';e.at=-.6;e.kx0=e.x;e.kb=1;e.i=0;e.fl=.6;continue}e.st='fling';e.dt=0;e.vx=560+Math.random()*320;e.vy=-520-Math.random()*300;e.vr=(Math.random()-.5)*10;e.rot=0;e.lg=0}
 if(R.int<WRT.MAXINT){R.int++;wrText(WRT.WX+120,GY-250,'+1 shield','#7dffb0',30)}
 const lx=WRT.WX+90,ly=GY-205;ptBurst(R.fx,lx,ly,46,['#ffd45a','#fff4c8','#ff9a5a'],{v:420,s:5,k:'glow',g:-40,l:1.4});wrRing(lx,ly,'#ffe08a',700,10,.6);wrRing(lx,ly,'#ffd45a',420,8,.6);
 R.shake=Math.max(R.shake,10);wrToast('Lantern Flare!',1.8,'#ffe08a');wrDriver('cheer',1.6);wrSfx('flare')}
/* ---------- legs and the gate ---------- */
function wrLegToast(li){const R=WRX,rt=R.rt,nm=rt.wp[li-1]||'';R.ping={i:li,t:0};if(nm)wrToast(`${nm} · leg ${li+1} of ${rt.legs}`,2,'#ffd45a');wrSfx('leg')}
function wrGate(){const R=WRX;if(R.st!=='roll')return;R.st='gate';R.gateT=0;R.won=true;R.tgt=null;R.haz=null;R.dash=null;R.ping={i:R.rt.legs,t:0};R.heroPose='victory';R.poseT=0;
 for(const e of R.mobs){if(e.st==='dead'||e.st==='fling')continue;e.st='fling';e.dt=0;e.vx=420+Math.random()*300;e.vy=-420-Math.random()*200;e.vr=(Math.random()-.5)*8;e.rot=0;e.lg=0}
 wrToast(`${R.rt.dest}! Almost there...`,2.2,'#7dffb0');wrDriver('cheer',4);wrSfx('gate')}
/* ---------- finish ---------- */
function wrFinish(won){const R=WRX;if(!R||R.over)return;R.over=true;R.resT=won?1:.7;const w=WRP(),rt=R.rt;
 const acc=R.chars?R.ok/R.chars:1,prog=Math.min(1,R.x/rt.len),med=wrMedalOf(won,R.int,acc);
 let pay=wrPayOf(rt,won,R.int,acc,prog),first=false;const day=wrDay();
 if(won){if(w.day!==day){w.day=day;w.dayDone={}}if(!w.dayDone[rt.id]){w.dayDone[rt.id]=1;first=true;pay=Math.round(pay*WRT.FIRSTDAY)}}
 for(const q of R.coinFly)R.coins+=q.n;R.coinFly=[];const coins=R.coins,total=pay+coins;
 const l0=lvl(P.xp),xp=xpMode(Math.round(rt.xp*(won?1:prog*.5)*xpMulRun()));P.xp+=xp;const lg=levelGold(l0,lvl(P.xp)),xn=xpNoteH();
 const oldMed=w.med[rt.id]||0;if(med>oldMed)w.med[rt.id]=med;w.runs++;
 const wpm=R.time>5?Math.round((R.ok/5)/(R.time/60)):0;
 if(won){w.clears++;const b=w.best[rt.id];if(!b||R.time<b.t)w.best[rt.id]={t:Math.round(R.time*10)/10,acc:Math.round(acc*100)}}
 w.kills+=R.kills;w.repairs+=R.repairs;w.flares+=R.flares;P.gold=Math.min(1e12,P.gold+total);stat('gold',total,'add');w.gold+=total;
 const unl=wrUnlockSweep();let ttl=false;try{if(WR_ROUTES.every(r=>(w.med[r.id]||0)>=3)&&!BTY().own['t:caravanmaster']){BTY().own['t:caravanmaster']=1;ttl=true}}catch(e){}
 if(won)try{btyAdd('wagon',1)}catch(e){}
 try{stat('wpm',wpm,'max');P.bestCombo=Math.max(P.bestCombo||0,R.maxCombo)}catch(e){}
 save();R.result={won,med,newMed:med>oldMed,pay,coins,total,xp,xn,lg,first,unl,ttl,acc,prog,time:R.time,kills:R.kills,repairs:R.repairs,maxCombo:R.maxCombo,wpm,flares:R.flares,int:R.int,l0,l1:lvl(P.xp)}}
/* a plain result card; 93d replaces it with the real one */
function wrResult(){const R=WRX,r=R&&R.result;if(!r)return;S.mode='over';show(`<div class="wrres"><h2>${r.won?'Route complete!':'Broke down'}</h2><p>${WR_MED[r.med].n} · Earned ${r.total} coins · ${r.xp} XP</p><div class="row"><button id="wr1">Ride again</button><button class="sm" id="hm">Home</button></div></div>`);
 $('wr1').onclick=()=>wrRestart();$('hm').onclick=()=>{wrLeave();title()};S.back=()=>{wrLeave();title()}}
/* ---------- pause ---------- */
function wrPause(on){const R=WRX;if(!R||R.over)return;on=on===undefined?!R.pause:on;if(on===R.pause)return;R.pause=on;if(on)wrPauseMenu();else{hide();try{inp.blur()}catch(e){}}}
function wrPauseMenu(){const R=WRX;show(`<div class="wrpause"><h2>Paused</h2><p>Lantern Caravan · ${esc(R.rt.n)} · leg ${R.leg+1} of ${R.rt.legs}</p>
 <div class="wrph"><span><kbd>Type</kbd> the word on a monster or the wrench bubble</span><span><kbd>Tab</kbd> next target</span><span><kbd>Enter</kbd> Lantern Flare when the lantern is full</span><span><kbd>Esc</kbd> Resume</span></div>
 <div class="row"><button id="wr1">Resume</button></div><div class="row"><button class="sm" id="wr2">Restart</button><button class="sm dg" id="wr3">Quit route</button></div></div>`,'wrpx');
 S.back=()=>wrPause(false);$('wr1').onclick=()=>wrPause(false);$('wr2').onclick=e=>{const t=e.target;if(t.dataset.a)wrRestart();else{t.dataset.a=1;t.textContent='Click again to restart';setTimeout(()=>{if(t.isConnected){t.dataset.a='';t.textContent='Restart'}},3000)}};$('wr3').onclick=()=>wrQuit()}
/* ---------- input ---------- */
function wrKey(c){const R=WRX;if(!R||R.pause||R.over||R.st!=='roll')return;c=String(c||'').toLowerCase();if(!/^[a-z]$/.test(c))return;
 const live=e=>e.st!=='dead'&&e.st!=='fling'&&e.st!=='kb'&&e.x<W-10;
 let t=R.tgt;if(t&&((t.hz&&R.haz!==t)||(!t.hz&&!live(t))))t=R.tgt=null;
 if(!t||(t.i===0&&t.w[0]!==c)){let b=null;if(R.haz&&R.haz.w[0]===c)b=R.haz;else for(const e of R.mobs)if(live(e)&&e.w[0]===c&&(!b||e.x<b.x))b=e;if(b)t=R.tgt=b}
 if(!t){wrSfx('none');return}
 R.chars++;
 if(t.w[t.i]===c){t.i++;R.ok++;R.combo++;if(R.combo>R.maxCombo)R.maxCombo=R.combo;t.fl=.12;R.flare=Math.min(WRT.FLARE,R.flare+1);
  if(t.hz){ptBurst(R.fx,t.x,GY-40,5,['#ffd45a','#9fd0ff'],{v:220,s:3.5,up:1,sp:2,g:320});wrSfx('clink',t.i)}
  else{ptBurst(R.fx,t.x,t.y-t.h*.5,3,WP[P.weapon].col,{v:160,s:4});R.lunge=Math.max(R.lunge,.3);wrSfx('key',R.combo)}
  const MS={10:'Sharp!',25:'On fire!',50:'Unstoppable!',100:'LEGENDARY!'};if(MS[R.combo]){wrText(W/2,300,MS[R.combo],'#ffd76a',46);wrSfx('milestone')}
  if(t.i>=t.w.length){if(t.hz)wrRepair();else wrKill(t)}}
 else if(t.slip<1){t.slip++;t.bad=1;t.badT=.3;wrText(t.x,(t.hz?t.y:t.y-t.h)-70,'Slip forgiven','#9fe8ff',22);wrSfx('slip')}
 else{t.bad=1;t.badT=.3;R.combo=0;R.flare=Math.max(0,R.flare-4);R.shake=Math.max(R.shake,4);wrSfx('miss')}}
function wrTab(){const R=WRX;if(!R||R.st!=='roll')return;const L=[];if(R.haz)L.push(R.haz);for(const e of R.mobs)if(e.st!=='dead'&&e.st!=='fling'&&e.st!=='kb'&&e.x<W-10)L.push(e);L.sort((a,b)=>(a.hz?-1:a.x)-(b.hz?-1:b.x));if(!L.length)return;
 const i=L.indexOf(R.tgt);const n=L[(i+1)%L.length];if(R.tgt&&R.tgt!==n&&R.tgt.i>0){R.tgt.i=0;R.tgt.slip=0}R.tgt=n}
{const k0=key;key=function(c){if(S.wr&&WRX)return wrKey(c);return k0.apply(this,arguments)}}
if(!window.__wrk){window.__wrk=1;window.addEventListener('keydown',e=>{const R=WRX;if(!R||!S.wr||S.mode!=='wagon')return;if(e.ctrlKey||e.metaKey||e.altKey)return;
 if(e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();if(!R.over)wrPause();return}
 if(R.pause||R.over)return;
 try{ensureAudio()}catch(x){}
 if(e.key==='Enter'){e.preventDefault();e.stopImmediatePropagation();if(!e.repeat)wrFlare();return}
 if(e.key==='Tab'){e.preventDefault();e.stopImmediatePropagation();if(!e.repeat)wrTab();return}
 if(e.key===' '){e.preventDefault();e.stopImmediatePropagation();return}
 if(e.key.length===1){e.preventDefault();e.stopImmediatePropagation();if(!e.repeat)wrKey(e.key)}},true);
 window.addEventListener('blur',()=>{if(WRX&&S.wr&&S.mode==='wagon'&&!WRX.over&&!WRX.pause)wrPause(true)});
 document.addEventListener('visibilitychange',()=>{if(document.hidden&&WRX&&S.wr&&S.mode==='wagon'&&!WRX.over&&!WRX.pause)wrPause(true)});
 window.addEventListener('pagehide',()=>{if(WRX)try{save()}catch(e){}})}
/* the corner Pause button speaks for the caravan too, moved to the top right */
function wrPBHook(){if(wrPBHook.d)return;wrPBHook.d=1;const p0=pb.onclick;pb.onclick=e=>{if(S.wr&&WRX&&S.mode==='wagon'&&!WRX.over){wrPause();return}p0&&p0(e)}}
function wrPB(){const R=WRX,on=!!(R&&S.mode==='wagon'&&!R.over);pb.classList.toggle('wrpb',on);pb.style.display=on?'':'none';try{$('cn').classList.toggle('dkhid',!!(R&&S.mode==='wagon'))}catch(e){}if(on){const t=R.pause?'Resume':'Pause';if(pb.textContent!==t)pb.textContent=t}}
/* ---------- update ---------- */
function wrUpdate(dt){const R=WRX;if(!R)return;wrPBHook();wrPB();if(R.pause)return;dt=Math.min(dt,.05);S.t+=dt;R.t+=dt;
 R.shake=Math.max(0,R.shake-46*dt);R.lunge=Math.max(0,R.lunge-4*dt);R.hitFl=Math.max(0,R.hitFl-dt*2.5);R.flareFx=Math.max(0,R.flareFx-dt);if(R.flareOn>0)R.flareOn-=dt;R.kick=Math.max(0,R.kick-dt*1.6);R.coinBump=Math.max(0,R.coinBump-dt*4);R.fade=Math.max(0,R.fade-dt*1.6);
 if(R.toast){R.toast.t-=dt;if(R.toast.t<=0)R.toast=null}if(R.ping){R.ping.t+=dt;if(R.ping.t>1)R.ping=null}
 for(const q of R.crack)q.t+=dt;R.crack=R.crack.filter(q=>q.t<.7);
 if(R.heroPose){R.poseT+=dt}
 /* speed: stop for a hazard or a monster at the front, surge during a flare */
 let tv=0;if(R.st==='roll'){const near=R.mobs.some(e=>e.st!=='dead'&&e.st!=='fling'&&e.st!=='kb'&&e.x<WRT.AX+WRT.NEAR);tv=R.haz?0:near?0:R.flareOn>0?WRT.VSURGE:WRT.V}else if(R.st==='gate')tv=WRT.VGATE;
 R.tv=tv;const v0=R.v;R.v+=(tv-R.v)*Math.min(1,dt*(tv>R.v?2.4:4.5));if(R.st==='break')R.v=0;R.accel=(R.v-v0)/Math.max(dt,.001);
 R.x+=R.v*dt;R.wheel+=(R.v/52+R.kick*9)*dt;
 R.swv+=(-R.swing*16-R.swv*3-R.accel*.011+(R.kick?Math.sin(R.t*30)*.4*R.kick:0))*dt;R.swing+=R.swv*dt;
 if(R.st==='roll'){R.time+=dt;const ll=R.rt.len/R.rt.legs,li=Math.min(R.rt.legs-1,Math.floor(R.x/ll));if(li>R.leg){R.leg=li;wrLegToast(li)}if(R.x>=R.rt.len&&!(R.boss&&!R.bossDone))wrGate();else if(R.x>=R.rt.len)R.x=R.rt.len}
 if(R.st==='roll'){if(R.haz){R.haz.t-=dt;R.haz.badT=Math.max(0,R.haz.badT-dt);R.haz.fl=Math.max(0,R.haz.fl-dt);if(R.haz.t<=0)wrHazFail()}else{R.hazT-=dt;if(R.hazT<=0){if(wrHazOk())wrHazOpen();else R.hazT=1.5}}
  R.spawnT-=dt;if(R.spawnT<=0)wrSpawnWave()}
 for(const e of R.mobs)wrMobTick(e,dt);R.mobs=R.mobs.filter(e=>!(e.st==='dead'&&e.dt>.6)&&!(e.st==='fling'&&(e.x>W+260||e.y>H+200)));
 if(R.dash){const d=R.dash;d.t+=dt;if(d.t>.62)R.dash=null}
 for(const q of R.shots)q.u+=dt*(q.k==='archer'?9:q.k==='rogue'?7:7);R.shots=R.shots.filter(q=>q.u<1);
 for(const q of R.coinFly)q.u+=dt*1.9;R.coinFly=R.coinFly.filter(q=>{if(q.u>=1){R.coins+=q.n;R.coinBump=1;wrSfx('coin');return false}return true});
 if(R.st==='gate'){R.gateT+=dt;if(R.gateT>2.8&&!R.over)wrFinish(true)}
 if(R.st==='break'){R.doneT+=dt;if(R.doneT>2.2&&!R.over)wrFinish(false)}
 if(R.over&&R.result){R.resT-=dt;if(R.resT<=0&&S.mode==='wagon')wrResult()}}
/* ---------- draw ---------- */
function wrDraw(){const R=WRX,c=ctx;if(!R)return;if(NEEDRESET){NEEDRESET=false;if(c.reset)c.reset()}c.globalAlpha=1;c.filter='none';c.globalCompositeOperation='source-over';c.shadowBlur=0;c.setTransform(RS,0,0,RS,0,0);c.save();
 if(R.shake>0&&ST.shake&&!R.rm)c.translate((Math.random()-.5)*R.shake,(Math.random()-.5)*R.shake);
 c.fillStyle='#000';c.fillRect(-30,-30,W+60,H+60);
 const dt=Math.min(.05,1/Math.max(20,S.fps||60));
 try{wrSceneDraw(c,R)}catch(e){console.error(e);c.fillStyle='#10121c';c.fillRect(-30,-30,W+60,H+60)}
 try{wrGateDraw(c,R)}catch(e){}
 const mobs=R.mobs.slice().sort((a,b)=>b.x-a.x);
 try{wrPetDraw(c,R)}catch(e){}
 try{wrWagonDraw(c,R)}catch(e){console.error(e)}
 try{wrHeroDraw(c,R)}catch(e){}
 for(const e of mobs)try{wrMobDraw(c,e)}catch(e2){}
 try{wrTongueDraw(c,R)}catch(e){}
 if(R.haz)wrTag(c,R.haz,R.tgt===R.haz);{const L=mobs.filter(e=>e.st!=='dead'&&e.st!=='fling').sort((a,b)=>a.x-b.x),used=[];for(const e of L){const w=e.w.length*14.4+72,x0=e.x-w/2,y0=e.y-e.h-74;let lift=0;for(let n=0;n<8;n++){let hit=false;for(const u of used)if(x0<u.x1&&x0+w>u.x0&&Math.abs((y0-lift)-(u.y-u.lift))<48){lift=u.lift+52;hit=true;break}if(!hit)break}e.tlift=lift;used.push({x0,x1:x0+w,y:y0,lift});wrTag(c,e,R.tgt===e)}}
 try{wrSayDraw(c,R)}catch(e){}
 ptFxStep(c,R.fx,dt);ptRings(c,R.rings,dt);
 for(const q of R.coinFly){const u=wrEase(q.u),x=q.x+(q.tx-q.x)*u,y=q.y+(q.ty-q.y)*u-Math.sin(u*Math.PI)*(120+Math.sin(q.ph)*40);coin(c,x,y,9+2*Math.sin(q.ph+q.u*9))}
 ptTexts(c,R.tx,dt);
 if(R.flareFx>0){const k=1-R.flareFx/.75,lx=WRT.WX+90,ly=GY-205,r=80+k*1500,q=c.createRadialGradient(lx,ly,0,lx,ly,r);q.addColorStop(0,`rgba(255,244,200,${(1-k)*.9})`);q.addColorStop(.6,`rgba(255,200,90,${(1-k)*.45})`);q.addColorStop(1,'rgba(255,180,60,0)');c.fillStyle=q;c.fillRect(-30,-30,W+60,H+60)}
 if(R.flareOn>0&&!R.rm){c.save();c.globalAlpha=Math.min(1,R.flareOn)*.5;c.strokeStyle='#ffe9a0';c.lineWidth=2;for(let i=0;i<12;i++){const y=120+((i*73+R.t*900)%640),x=((i*311+R.t*1800)%(W+400))-200;c.beginPath();c.moveTo(x,y);c.lineTo(x+90+i*8,y);c.stroke()}c.restore()}
 if(R.hitFl>0){c.fillStyle=`rgba(255,40,70,${R.hitFl*.18})`;c.fillRect(-30,-30,W+60,H+60)}
 try{wrForeDraw(c,R)}catch(e){}
 wrHUD(c,R);
 if(R.toast)wrToastDraw(c,R.toast);
 if(R.fade>0){c.fillStyle=`rgba(0,0,0,${R.fade})`;c.fillRect(-30,-30,W+60,H+60)}
 c.restore()}
function wrHeroX(R){if(!R.dash)return WRT.HX;const d=R.dash,t=d.t;let k=t<.14?wrEase(t/.14):t<.24?1:1-wrEase((t-.24)/.38);return WRT.HX+(d.x1-WRT.HX)*k}
function wrHeroDraw(c,R){const x=wrHeroX(R),walking=R.v>8&&R.st!=='break'&&!R.dash,b=Math.sin(S.t*2.3),syy=1+b*.011,sxx=1-b*.006;let hop=0,pu=0;
 if(R.heroPose==='victory'){pu=Math.min(1,R.poseT/.3);hop=-Math.abs(Math.sin(R.poseT*5.5))*22*Math.min(1,R.poseT/.5)}
 c.save();c.translate(x+(R.ox||0),GY);c.fillStyle='#0007';c.beginPath();c.ellipse(0,6,58,10,0,0,TAU);c.fill();
 const col=WCOL();glow(c,0,-100,120,col+'22');c.translate(0,hop);c.scale(1.5*sxx,1.5*syy);drawHero(c,{arm:P.armor,wp:P.weapon,col:P.col,t:S.t,lg:R.lunge,walk:walking,pose:R.heroPose,pu});c.restore()}
function wrPetDraw(c,R){const id=P.pet;if(!id||!PDEF[id])return;const hv=PDEF[id].hover,walking=R.v>8&&R.st!=='break';const hk=(R.t-R.petHop)/.38,fk=(R.t-R.petFl)/.34,hop=hk>=0&&hk<1?-Math.sin(hk*Math.PI)*13:0,fl=fk>=0&&fk<1?Math.sin(fk*Math.PI*3)*(1-fk)*7:0;
 const pose=R.heroPose==='victory'?{pose:'greet',u:(R.poseT%2.2)/2.2}:walking?{pose:'walk',u:0}:{pose:'idle',u:0};
 c.save();c.translate(WRT.PX+(R.ox||0)-fl,GY+2-(hv?34:0)+hop);c.rotate(-fl*.012);c.scale(.95,.95);petDraw(c,id,Object.assign({t:S.t,pose:pose.pose,u:pose.u,noSh:hv||hop?1:0},petLook(id)));c.restore()}
function wrMobDraw(c,e){const M=MON[e.id];if(!M)return;const R=WRX,sc=e.h/M.th,dead=e.st==='dead',fl=e.st==='fling';
 c.save();
 if(!dead&&!fl&&!e.fly){c.fillStyle='rgba(0,0,0,.32)';c.beginPath();c.ellipse(e.x,GY+6,e.h*.3,8,0,0,TAU);c.fill()}
 if(!dead&&!fl){const cyc=e.y-e.h*.5;glow(c,e.x,cyc,e.h*.8,(e.boss?'#ff8a9a':R.rt.far==='forest'?'#7af0b0':R.rt.far==='keep'?'#c88aff':'#ffb86a')+(e.boss?'55':'30'))}
 if(dead){const k=Math.min(1,e.dt/.5);c.globalAlpha=1-k;c.translate(e.x,e.y);c.scale(1+k*.35,Math.max(.02,1-k*1.1));c.rotate(k*.4);c.translate(-e.x,-e.y)}
 if(fl){c.translate(e.x,e.y-e.h*.5);c.rotate(e.rot);c.translate(-e.x,-(e.y-e.h*.5))}
 c.translate(e.x-(e.lg||0)*64+(e.badT>0?Math.sin(e.badT*60)*4:0),e.y);c.scale(sc,sc);M.d(c,S.t+e.ph*3,{lg:e.lg||0});c.restore();
 if(e.fl>0&&!dead){c.save();c.globalCompositeOperation='lighter';c.globalAlpha=Math.min(1,e.fl*5);glow(c,e.x-(e.lg||0)*64,e.y-e.h*.5,e.h*.5,'#fff8e8');c.restore()}}
/* the word tag: a red sword pill over a monster, a blue wrench bubble over a hazard */
function wrTagFont(c){c.font='bold 24px ui-monospace,Menlo,Consolas,"Courier New",monospace'}
function wrTag(c,e,tgt){const R=WRX,hz=!!e.hz;wrTagFont(c);const pw=c.measureText('M').width,tw=pw*e.w.length,w=tw+72,h=44;let x=wrClamp((hz?e.x:e.x-(e.lg||0)*30)-w/2,8,W-w-8),y=hz?e.y-h:e.y-e.h-30-h-(e.tlift||0);if(!hz&&e.fly)y=Math.max(90,y);
 const bob=Math.sin(S.t*3+(e.ph||0))*3;y+=bob;if(e.badT>0)x+=Math.sin(e.badT*60)*5;
 const col=WCOL(),fill=hz?'#1a2550':'#3a0c18',bd=hz?'#6ab0ff':tgt?col:'#e8364e';
 c.save();c.fillStyle=fill;c.strokeStyle=bd;c.lineWidth=tgt?3:2;c.beginPath();c.roundRect(x,y,w,h,13);c.fill();c.stroke();
 c.fillStyle=fill;c.beginPath();c.moveTo(x+w/2-9,y+h-1);c.lineTo(x+w/2+9,y+h-1);c.lineTo(x+w/2,y+h+10);c.closePath();c.fill();c.strokeStyle=bd;c.lineWidth=2;c.beginPath();c.moveTo(x+w/2-9,y+h);c.lineTo(x+w/2,y+h+10);c.lineTo(x+w/2+9,y+h);c.stroke();
 if(hz){const u=1-e.t/e.fuse;c.fillStyle=u>.6?'#ff8a9a':'#6ab0ff';c.fillRect(x+10,y+h-6,(w-20)*(1-u),3)}
 c.save();c.translate(x+26,y+h/2);if(hz)wrIcoWrench(c,0,0,11,'#9fd0ff');else wrIcoSword(c,0,0,11,'#ff6a7a');c.restore();
 wrTagFont(c);c.textBaseline='middle';c.textAlign='left';const x0=x+50,cy=y+h/2;
 for(let i=0;i<e.w.length;i++){c.fillStyle=i<e.i?(hz?'#9fd0ff':col):'#fff8e8';c.fillText(e.w[i],x0+i*pw,cy)}
 if(tgt&&e.i<e.w.length){c.fillStyle=hz?'#9fd0ff':col;c.fillRect(x0+e.i*pw,cy+13,pw,3.4)}c.restore()}
function wrIcoSword(c,x,y,s,col){c.save();c.translate(x,y);c.rotate(-Math.PI/4);c.fillStyle=col;c.strokeStyle='#12081f';c.lineWidth=1.6;c.beginPath();c.moveTo(-s*.18,-s);c.lineTo(s*.18,-s);c.lineTo(s*.14,s*.35);c.lineTo(-s*.14,s*.35);c.closePath();c.fill();c.stroke();c.fillStyle='#ffd45a';c.fillRect(-s*.55,s*.35,s*1.1,s*.22);c.fillStyle='#8a5a2c';c.fillRect(-s*.12,s*.57,s*.24,s*.45);c.restore()}
function wrIcoWrench(c,x,y,s,col){c.save();c.translate(x,y);c.rotate(Math.PI/4);c.strokeStyle='#12081f';c.lineWidth=s*.62;c.lineCap='round';c.beginPath();c.moveTo(0,-s*.2);c.lineTo(0,s*.95);c.stroke();c.strokeStyle=col;c.lineWidth=s*.34;c.stroke();c.fillStyle=col;c.strokeStyle='#12081f';c.lineWidth=1.5;c.beginPath();c.arc(0,-s*.42,s*.5,0,TAU);c.fill();c.stroke();c.fillStyle='#1a2550';c.beginPath();c.rect(-s*.2,-s*1.05,s*.4,s*.5);c.fill();c.restore()}
/* ---------- HUD ---------- */
function wrPanel(c,x,y,w,h,r){c.fillStyle='rgba(6,4,16,.58)';c.strokeStyle='#5a4ca0';c.lineWidth=1.5;c.beginPath();c.roundRect(x,y,w,h,r||14);c.fill();c.stroke();c.strokeStyle='rgba(255,255,255,.12)';c.lineWidth=1;c.beginPath();c.moveTo(x+r,y+1.5);c.lineTo(x+w-r,y+1.5);c.stroke()}
function wrShieldIcon(c,x,y,s,on,k){c.save();c.translate(x,y);const p=()=>{c.beginPath();c.moveTo(0,-s);c.lineTo(s*.85,-s*.65);c.lineTo(s*.8,s*.1);c.quadraticCurveTo(s*.6,s*.75,0,s);c.quadraticCurveTo(-s*.6,s*.75,-s*.8,s*.1);c.lineTo(-s*.85,-s*.65);c.closePath()};
 if(k!=null){const u=k/.7;c.globalAlpha=1-u;for(const d of[-1,1]){c.save();c.translate(d*u*18,u*u*40);c.rotate(d*u*.9);c.beginPath();c.rect(d>0?0:-s*1.2,-s*1.2,s*1.2,s*2.4);c.clip();p();c.fillStyle='#ffd45a';c.fill();c.strokeStyle='#12081f';c.lineWidth=2.5;c.stroke();c.restore()}c.restore();return}
 p();if(on){c.fillStyle=vgr(c,-s,s,'#ffe48a','#e8a820');c.fill();c.strokeStyle='#12081f';c.lineWidth=2.5;c.stroke();c.strokeStyle='rgba(255,255,255,.7)';c.lineWidth=1.6;c.beginPath();c.moveTo(-s*.5,-s*.45);c.lineTo(-s*.5,s*.1);c.stroke()}
 else{c.fillStyle='#2a2438';c.fill();c.strokeStyle='#4a4260';c.lineWidth=2.5;c.stroke();c.strokeStyle='#5a526c';c.lineWidth=1.5;c.beginPath();c.moveTo(-s*.2,-s*.7);c.lineTo(s*.1,-s*.1);c.lineTo(-s*.15,s*.2);c.lineTo(s*.2,s*.8);c.stroke()}c.restore()}
function wrGateGlyph(c,x,y,s,col){c.save();c.translate(x,y);c.fillStyle=col;c.strokeStyle='#12081f';c.lineWidth=1.5;c.beginPath();c.rect(-s,-s*.5,s*2,s*1.5);c.fill();c.stroke();for(let i=-1;i<=1;i++){c.beginPath();c.rect(i*s*.7-s*.22,-s*.95,s*.44,s*.5);c.fill();c.stroke()}c.fillStyle='#12081f';c.beginPath();c.moveTo(-s*.35,s);c.lineTo(-s*.35,s*.2);c.arc(0,s*.2,s*.35,Math.PI,0);c.lineTo(s*.35,s);c.fill();c.restore()}
function wrWagonGlyph(c,x,y,s,col){c.save();c.translate(x,y);c.fillStyle=col;c.strokeStyle='#12081f';c.lineWidth=1.5;c.beginPath();c.roundRect(-s,-s*.7,s*2,s*.9,s*.2);c.fill();c.stroke();c.fillStyle='#ffd45a';c.beginPath();c.arc(s*.2,-s*1.05,s*.38,0,TAU);c.fill();c.stroke();c.fillStyle='#2a2438';for(const d of[-.55,.55]){c.beginPath();c.arc(d*s,s*.4,s*.38,0,TAU);c.fill();c.stroke()}c.restore()}
function wrLanternGlyph(c,x,y,s,fill,col){c.save();c.translate(x,y);c.strokeStyle='#d9a441';c.lineWidth=1.8;c.fillStyle='#2a2438';c.beginPath();c.roundRect(-s*.55,-s*.8,s*1.1,s*1.6,s*.18);c.fill();c.stroke();c.beginPath();c.arc(0,-s*.95,s*.32,Math.PI,0);c.stroke();
 if(fill>0){c.save();c.beginPath();c.rect(-s*.5,s*.75-fill*s*1.5,s,fill*s*1.5);c.clip();c.fillStyle=col;c.beginPath();c.roundRect(-s*.55,-s*.8,s*1.1,s*1.6,s*.18);c.fill();c.restore()}
 c.strokeStyle='rgba(255,255,255,.35)';c.lineWidth=1;c.beginPath();c.moveTo(-s*.18,-s*.75);c.lineTo(-s*.18,s*.75);c.moveTo(s*.18,-s*.75);c.lineTo(s*.18,s*.75);c.stroke();c.restore()}
function wrHUD(c,R){c.save();c.textBaseline='middle';const lab=(s,x,y,col,al)=>{c.font='800 12.5px Poppins,system-ui,sans-serif';c.fillStyle=col||'#ffd45a';c.textAlign=al||'left';c.letterSpacing='2px';c.fillText(s,x,y);c.letterSpacing='0px'};
 /* integrity */
 wrPanel(c,18,16,300,66);lab('WAGON INTEGRITY',36,34);
 for(let i=0;i<WRT.MAXINT;i++){const q=R.crack.find(z=>z.i===i);wrShieldIcon(c,52+i*38,60,13,i<R.int,q?q.t:null)}
 c.font='800 22px Poppins,system-ui,sans-serif';c.fillStyle='#fff8e8';c.textAlign='left';c.fillText(`${R.int} / ${WRT.MAXINT}`,214,60);
 if(R.int===1&&R.st==='roll'){const pu=.5+.5*Math.sin(R.t*8.8);c.strokeStyle=`rgba(232,54,78,${.35+.5*pu})`;c.lineWidth=2.5;c.beginPath();c.roundRect(18,16,300,66,14);c.stroke()}
 /* route progress */
 const px=W/2-310,pw=620,prog=Math.min(1,R.x/R.rt.len);wrPanel(c,px,16,pw,66);
 c.font='800 17px Poppins,system-ui,sans-serif';c.fillStyle='#ffd45a';c.textAlign='center';c.fillText(`${R.rt.dest} · ${Math.round(prog*100)}%`,px+pw/2-14,34);
 wrGateGlyph(c,px+pw-40,52,10,'#9a8ad0');
 const tx0=px+34,tx1=px+pw-76,ty=60;c.strokeStyle='#3a3070';c.lineWidth=4;c.lineCap='round';c.beginPath();c.moveTo(tx0,ty);c.lineTo(tx1,ty);c.stroke();c.strokeStyle='#ffd45a';c.beginPath();c.moveTo(tx0,ty);c.lineTo(tx0+(tx1-tx0)*prog,ty);c.stroke();
 for(let i=0;i<=R.rt.legs;i++){const u=i/R.rt.legs,x=tx0+(tx1-tx0)*u,on=prog>=u-1e-6;c.fillStyle=on?'#ffd45a':'#1c1446';c.strokeStyle=on?'#fff0b0':'#5a4ca0';c.lineWidth=2;c.beginPath();c.arc(x,ty,i===R.rt.legs?7:5,0,TAU);c.fill();c.stroke();
  if(R.ping&&R.ping.i===i){const k=R.ping.t;c.strokeStyle=`rgba(255,228,138,${1-k})`;c.lineWidth=3;c.beginPath();c.arc(x,ty,6+k*22,0,TAU);c.stroke()}}
 wrWagonGlyph(c,tx0+(tx1-tx0)*prog,ty-3,8,'#c89a5a');
 /* coins */
 wrPanel(c,1124,16,166,50);const cb=1+R.coinBump*.18;c.save();c.translate(1150,41);c.scale(cb,cb);coin(c,0,0,11);c.restore();c.font='800 22px Poppins,system-ui,sans-serif';c.fillStyle='#fff8e8';c.textAlign='left';c.fillText(R.coins.toLocaleString(),1172,41);
 /* the lantern meter */
 const full=R.flare>=WRT.FLARE,fu=R.flare/WRT.FLARE,pu=full?.5+.5*Math.sin(R.t*7):0;wrPanel(c,1306,16,176,50);if(full){c.strokeStyle=`rgba(255,228,138,${.4+.5*pu})`;c.lineWidth=2.5;c.beginPath();c.roundRect(1306,16,176,50,14);c.stroke()}
 wrLanternGlyph(c,1332,41,13,fu,full?'#ffe9a0':'#ffb84a');c.fillStyle='#3a3070';c.beginPath();c.roundRect(1356,35,96,12,6);c.fill();c.fillStyle=full?'#ffe9a0':'#ffb84a';c.beginPath();c.roundRect(1356,35,96*fu,12,6);c.fill();
 c.font='800 11px Poppins,system-ui,sans-serif';c.fillStyle=full?'#fff8e8':'#c4badf';c.textAlign='left';c.letterSpacing='1px';c.fillText(full?'ENTER · FLARE':'LANTERN FLARE',1356,56);c.letterSpacing='0px';
 c.restore()}
function wrToastDraw(c,t){const a=Math.min(1,(t.d-t.t)*4,t.t*2.5);c.save();c.globalAlpha=a;c.font='700 22px Poppins,system-ui,sans-serif';c.textAlign='center';c.textBaseline='middle';const w=c.measureText(t.txt).width+56,y=108;c.fillStyle='rgba(8,4,20,.82)';c.strokeStyle=t.c;c.lineWidth=2;c.beginPath();c.roundRect(W/2-w/2,y,w,46,16);c.fill();c.stroke();c.fillStyle=t.c;c.fillText(t.txt,W/2,y+24);c.restore()}

{const st=document.createElement('style');st.textContent=`#pb.wrpb{bottom:auto!important;left:auto!important;top:16px;right:16px;font-family:var(--ui);font-weight:700;font-size:16px;letter-spacing:0;padding:8px 18px;border-radius:12px}
.wrpause,.wrres{display:flex;flex-direction:column;align-items:center;gap:14px}.wrph{display:flex;flex-wrap:wrap;justify-content:center;gap:10px 22px;max-width:900px;font:15px var(--ui);color:#c4badf}.wrph kbd{font:700 13px var(--ui);color:#ffd45a;border:1px solid #5a4ca0;border-radius:6px;padding:1px 7px;margin-right:4px;background:#1c1446}`;document.head.appendChild(st)}
