/* ===== PENALTY KINGS 9.9b: the game screen rebuilt from the owner's concept (96zw, after 96zv; markup in 96zs) =====
   Top bar: the tell chip (what the monster gives away, and a plain "do this" line with the keys), Kick n/10 and ten numbered kick icons.
   The pitch: key chips on the six goal spots (Q W E / A S D) or the three dive columns, a step bar along the bottom.
   Right panel: the keeper card (Round setup with ‹ › to change keeper, locked during a round), Your bet / If successful, the cap, the next
   stages of the ladder (or the full ladder), the selected spot with a mini goal, Cashout and the big gold button (Shoot • Q). */
function pkKeyChip(g,x,y,k,on){g.save();g.translate(x,y);const w=34,h=30;g.fillStyle=on?'#ffd45a':'rgba(18,8,31,.86)';g.beginPath();g.roundRect(-w/2,-h/2,w,h,8);g.fill();
 g.lineWidth=2.4;g.strokeStyle=on?'#12081f':'#fff8e8';g.stroke();g.fillStyle=on?'#3a1a04':'#fff8e8';g.font='800 17px Poppins,system-ui,sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillText(k,0,1);g.restore()}
{const st=document.createElement('style');st.textContent=`
.pkw.pk2{grid-template-columns:1008px 1fr;grid-template-rows:58px 560px 1fr;gap:10px 14px}
.pk2 .pktop{grid-column:1;grid-row:1;display:flex;align-items:center;gap:12px;padding:0 12px;border-radius:18px;background:linear-gradient(180deg,#1e1650f4,#0e0a2cf6);border:2px solid #6a4ab0;box-shadow:0 0 0 2px #12081f}
.pk2 .pktell{position:relative;left:auto;top:auto;flex:0 1 auto;min-width:0;max-width:420px;padding:4px 10px 4px 8px;border-radius:13px;gap:9px;border-width:2px}
.pk2 .pktell span{display:flex;flex-direction:column;min-width:0}.pk2 .pktell b{font:700 14px var(--ui);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.pk2 .pktell small{font:600 11.5px var(--ui);letter-spacing:0;color:#cfc6f0;white-space:nowrap}.pk2 .pktell small b{font-size:11.5px;color:#fff}.pk2 .pktell small b.go{color:#7dff9a}
.pk2 .pktell em{flex:none;width:18px;height:18px;border-radius:50%;display:grid;place-items:center;background:#6a4ab0;color:#fff;font:800 11px var(--ui);font-style:normal;cursor:help}
.pk2 .pktell.off{opacity:.6;border-color:#6a4ab0}
.pk2 .pkkick{flex:none;padding-left:12px;border-left:2px solid #3a3070;font:700 14px var(--ui);color:#e8e0ff;white-space:nowrap}.pk2 .pkkick b{color:#ffd45a;letter-spacing:.06em}.pk2 .pkkick b.save{color:#9fe8ff}
.pk2 .pkkick.pop{animation:pkpop .45s cubic-bezier(.34,1.56,.64,1)}
.pk2 .pksbd{display:flex;gap:3px;margin-left:auto}.pk2 .pksbd i{width:30px;height:44px;border:0;background:none;display:flex;flex-direction:column;align-items:center;gap:1px;font-style:normal}
.pk2 .pksbd i s{width:26px;height:26px;border-radius:50%;display:grid;place-items:center;text-decoration:none;background:#2c2466;border:2px solid #12081f;font:900 13px var(--ui);color:#fff}
.pk2 .pksbd i s svg{width:17px;height:17px}.pk2 .pksbd i.sv s{background:#24407a}.pk2 .pksbd i.bt s{background:#7a5a10}
.pk2 .pksbd i u{text-decoration:none;font:700 11px var(--ui);color:#a99be0}
.pk2 .pksbd i.w s{background:#2fb860}.pk2 .pksbd i.l s{background:#d0304a}.pk2 .pksbd i.cur s{background:#ffd45a;transform:scale(1.15);box-shadow:0 0 0 3px #ffd45a55}.pk2 .pksbd i.cur u{color:#ffd45a}
.pk2 .pkst{grid-column:1;grid-row:2}.pk2 .pkhint{top:12px}
.pk2 .pksteps{position:absolute;left:50%;bottom:6px;transform:translateX(-50%);display:flex;align-items:center;gap:9px;padding:5px 16px;border-radius:12px;background:#12081fdc;border:2px solid #3a3070;font:700 13px var(--ui);color:#a99be0;white-space:nowrap;pointer-events:none}
.pk2 .pksteps span.on{color:#fff8e8}.pk2 .pksteps span.seen{color:#7dff9a}.pk2 .pksteps i{font-style:normal;color:#ffd45a}
.pk2 .pkside{grid-column:2;grid-row:1/4;align-self:start;height:748px;box-sizing:border-box;gap:9px;padding:12px}
.pk2 .pkkc{display:grid;grid-template-columns:76px 1fr auto;align-items:center;gap:8px;padding:6px 8px;border-radius:16px;background:#ffffff0a;border:2px solid #3a3070}
.pk2 .pkkc canvas{width:76px;height:76px;border-radius:14px;background:#0c0824;border:2px solid #12081f}
.pk2 .pkkn{display:flex;flex-direction:column;min-width:0}.pk2 .pkkn b{font:400 28px/1 'Pirata One',Georgia,serif;color:#ffd45a}.pk2 .pkkn small{font:600 12px var(--ui);color:#cfc6f0}
.pk2 .pkset{display:flex;flex-direction:column;align-items:center;gap:3px}
.pk2 .pkseti{display:flex;align-items:center;gap:4px;padding:5px 6px;border-radius:12px;background:#2c2466;border:2px solid #4a3a90}
.pk2 .pkseti span{display:flex;flex-direction:column;align-items:center;min-width:92px}.pk2 .pkseti b{font:800 12.5px var(--ui);color:#fff8e8}.pk2 .pkseti small{font:600 10.5px var(--ui);color:#a99be0}
.pk2 .pkseti button{all:unset;cursor:pointer;width:24px;height:28px;border-radius:8px;display:grid;place-items:center;background:#ffd45a;color:#3a1a04;font:900 18px/1 var(--ui);transition:transform .12s}
.pk2 .pkseti button:hover{transform:scale(1.1)}.pk2 .pkseti small.l{display:none}
.pk2 .pkset.lock .pkseti button{visibility:hidden;width:6px}.pk2 .pkset.lock .pkseti small.u{display:none}.pk2 .pkset.lock .pkseti small.l{display:block}.pk2 .pkset.lock .pkseti b::before{content:'🔒 '}
.pk2 .pkset em{font:700 11px var(--ui);font-style:normal;color:#ffd45a}
.pk2 .pkbetb{padding:8px 12px;border-radius:16px;background:#ffffff0a;border:2px solid #3a3070}
.pk2 .pkbb{display:grid;grid-template-columns:1fr 1fr}.pk2 .pkbb>div{display:flex;flex-direction:column;gap:2px}.pk2 .pkbb>div+div{padding-left:12px;border-left:2px solid #3a3070}
.pk2 .pkbb small{font:600 12px var(--ui);color:#a99be0}.pk2 .pkbb b{display:flex;align-items:center;gap:6px;font:800 24px var(--ui);color:#fff8e8}
.pk2 .pkbb u{text-decoration:none;margin-left:4px;padding:1px 7px;border-radius:8px;border:2px solid #ffd45a;font:800 13px var(--ui);color:#ffd45a}
.pk2 .pkcn{display:inline-block;flex:none;width:16px;height:16px;border-radius:50%;background:radial-gradient(circle at 35% 35%,#fff3b0,#ffd45a 45%,#c98a1c);border:2px solid #12081f;vertical-align:-3px}
.pk2 .pkbb .pkcn{width:22px;height:22px}
.pk2 .pkcap{margin:6px 0 0;font-size:13px}
.pk2 .pkstg{flex:1;display:flex;flex-direction:column;gap:5px;padding:8px 10px;border-radius:16px;background:#ffffff0a;border:2px solid #3a3070;min-height:0}
.pk2 .pkstgh{display:flex;align-items:center;justify-content:space-between}.pk2 .pkstgh b{font:800 14px var(--ui);color:#fff8e8}.pk2 .pkstgh b small{font:600 12px var(--ui);color:#a99be0}
.pk2 .pkstgh button{all:unset;cursor:pointer;padding:3px 10px;border-radius:9px;border:2px solid #6a4ab0;font:700 12px var(--ui);color:#e8e0ff}.pk2 .pkstgh button:hover{border-color:#ffd45a}
.pk2 .pklad{gap:3px;overflow:hidden}
.pk2 .pkr{height:31px;padding:0 10px 0 5px;border-radius:10px}.pk2 .pkr span{text-align:left;font:600 13px var(--ui);color:#e8e0ff}.pk2 .pkr span em{font-size:12px;color:#ffd45a;font-weight:700;margin:0}
.pk2 .pkr u{display:flex;align-items:center;gap:5px;min-width:92px;justify-content:flex-start;font:800 14px var(--ui);color:#fff8e8}.pk2 .pkr b{min-width:54px;text-align:right;font:800 14px var(--ui);color:#cfc6f0}
.pk2 .pkr.next{background:#ffd45a1c;border-color:#ffd45a}.pk2 .pkr.next u,.pk2 .pkr.next span{color:#fff8e8}.pk2 .pkr.next b{color:#ffd45a}
.pk2 .pkr.cap{background:none;border-style:dashed}.pk2 .pkr.cap u{font-size:13px;color:#ffd45a}.pk2 .pkr.cap b{color:#ffd45a}
.pk2 .pkspot{display:flex;align-items:center;justify-content:space-between;padding:8px 12px;border-radius:16px;background:#ffffff0a;border:2px solid #3a3070}
.pk2 .pkspot small{display:block;font:600 12px var(--ui);color:#a99be0}.pk2 .pkspot b{font:800 16px var(--ui);color:#fff8e8}
.pk2 .pkmini{display:grid;grid-template-columns:repeat(3,26px);grid-template-rows:repeat(2,20px);gap:2px;padding:3px;border:2px solid #cfc6f0;border-bottom:0;border-radius:4px 4px 0 0}
.pk2 .pkmini i{background:#ffffff10;border-radius:3px;transition:background .15s}.pk2 .pkmini i.on{background:#ffd45a;box-shadow:inset 0 0 0 2px #12081f}
.pk2 .pkmini.dv i.on{background:#9fe8ff}
.pk2 .pkbtns{grid-template-columns:1fr 1.35fr}
.pk2 .pkco{height:70px;background:linear-gradient(180deg,#5a5290,#3a3270);color:#e8e0ff;box-shadow:0 5px 0 #241c50,0 8px 16px #0008}.pk2 .pkco b{font:800 18px var(--ui)}.pk2 .pkco small{font:600 11px var(--ui);opacity:.85}
.pk2 .pkco:not(:disabled){background:linear-gradient(180deg,#8affa8,#22a85a);color:#06301a;box-shadow:0 5px 0 #0e5a2a,0 8px 16px #0008}
.pk2 .pkgob{height:70px;font-size:26px}
.pk2 .pkbot{grid-column:1;grid-row:3;grid-template-columns:1fr 640px;gap:12px;max-width:none}
.pk2 .pkleft{justify-content:center;gap:4px;padding:6px 10px;border-radius:16px;background:#ffffff08;border:2px solid #2c2466}
.pkw.pk2 .pkleft p.cmsg{margin:0;font:600 14px/1.3 var(--ui)!important;text-align:left;padding:6px 10px}
.pk2 .pkmid{overflow:visible;align-items:center}.pk2 .pkmid .ctl{transform:scale(.8);transform-origin:top center;margin-top:-10px}
.pk2 .pkstat{justify-content:flex-start;gap:12px;font-size:12px}`;document.head.appendChild(st)}
/* 9.9c: the hint line over the pitch is gone (the tell chip and the step bar carry the instructions) */
{const st=document.createElement('style');st.textContent='.pk2 .pkhint{display:none!important}';document.head.appendChild(st)}
