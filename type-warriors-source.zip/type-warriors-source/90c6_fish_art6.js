/* ===== MOONLIT FISHING: fish art 6 — Tavern Pond: honey (common), skipper (common), knight (rare), lion (rare), arowana (legendary) =====
   Each FISHART.<id>(g,t,o) draws one fish facing right, centred on the origin, ~200 units long. Helpers prefixed fa6_
   (the polish kit is a private copy so this file never depends on another file's internals). */
/* path from a command list: 'M',x,y 'L',x,y 'Q',cx,cy,x,y 'C',c1x,c1y,c2x,c2y,x,y 'Z' */
function fa6_path(g,c){g.beginPath();let i=0;while(i<c.length){const k=c[i++];
 if(k==='M'){g.moveTo(c[i],c[i+1]);i+=2}else if(k==='L'){g.lineTo(c[i],c[i+1]);i+=2}
 else if(k==='Q'){g.quadraticCurveTo(c[i],c[i+1],c[i+2],c[i+3]);i+=4}
 else if(k==='C'){g.bezierCurveTo(c[i],c[i+1],c[i+2],c[i+3],c[i+4],c[i+5]);i+=6}else if(k==='Z')g.closePath()}}
/* crisp closed polygon */
function fa6_poly(g,p){g.beginPath();g.moveTo(p[0],p[1]);for(let i=2;i<p.length;i+=2)g.lineTo(p[i],p[i+1]);g.closePath()}
/* gradient with explicit stops [[pos,colour],...] */
function fa6_grad(g,x0,y0,x1,y1,s){const q=g.createLinearGradient(x0,y0,x1,y1);for(const e of s)q.addColorStop(e[0],e[1]);return q}
function fa6_rgrad(g,x,y,r0,r1,s){const q=g.createRadialGradient(x,y,r0,x,y,r1);for(const e of s)q.addColorStop(e[0],e[1]);return q}
/* run fn in a translated + rotated frame */
function fa6_at(g,x,y,a,fn){g.save();g.translate(x,y);g.rotate(a);fn();g.restore()}
/* twinkle 0..1 */
const fa6_tw=(t,i,sp)=>.5+.5*Math.sin(t*(sp||3)+i*1.91);
/* glossy highlight: a soft white curve inside the clip path */
function fa6_gloss(g,clip,x0,y0,cx,cy,x1,y1,w,a){g.save();clip();g.clip();g.lineCap='round';g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo(cx,cy,x1,y1);
 g.strokeStyle=`rgba(255,255,255,${a*.4})`;g.lineWidth=w*2.2;g.stroke();g.strokeStyle=`rgba(255,255,255,${a})`;g.lineWidth=w;g.stroke();g.restore()}
/* gill arc (clipped to the body) */
function fa6_gill(g,clip,x,y,r,a0,a1,c,a){g.save();clip();g.clip();g.beginPath();g.arc(x,y,r,a0,a1);g.strokeStyle=c||FKO;g.globalAlpha=a==null?.6:a;g.lineWidth=2.4;g.lineCap='round';g.stroke();g.restore()}
/* rib lines from a root point to each listed point, clipped to the clip path */
function fa6_ribs(g,clip,x0,y0,pts,a,c,lw){g.save();clip();g.clip();g.strokeStyle=c||FKO;g.globalAlpha=a==null?.25:a;g.lineWidth=lw||1.3;g.lineCap='round';
 for(let i=0;i<pts.length;i+=2){g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo((x0+pts[i])/2,(y0+pts[i+1])/2*1.04,pts[i],pts[i+1]);g.stroke()}g.restore()}
/* tapered strand along a chain of cubic beziers b=[x0,y0, c1x,c1y,c2x,c2y,x1,y1, ...] */
function fa6_strand(g,b,w0,w1,col,lw,rays){const P=[[b[0],b[1]]];let x=b[0],y=b[1];
 for(let i=2;i+5<b.length;i+=6){const c1x=b[i],c1y=b[i+1],c2x=b[i+2],c2y=b[i+3],ex=b[i+4],ey=b[i+5];
  for(let s=1;s<=12;s++){const u=s/12,v=1-u;P.push([v*v*v*x+3*v*v*u*c1x+3*v*u*u*c2x+u*u*u*ex,v*v*v*y+3*v*v*u*c1y+3*v*u*u*c2y+u*u*u*ey])}x=ex;y=ey}
 const n=P.length,L=[],R=[];for(let i=0;i<n;i++){const a=P[Math.max(0,i-1)],c=P[Math.min(n-1,i+1)],dx=c[0]-a[0],dy=c[1]-a[1],d=Math.hypot(dx,dy)||1,w=(w0+(w1-w0)*i/(n-1))/2;
  L.push([P[i][0]-dy/d*w,P[i][1]+dx/d*w]);R.push([P[i][0]+dy/d*w,P[i][1]-dx/d*w])}
 g.beginPath();g.moveTo(L[0][0],L[0][1]);for(const p of L)g.lineTo(p[0],p[1]);for(let i=n-1;i>=0;i--)g.lineTo(R[i][0],R[i][1]);g.closePath();
 g.lineJoin='round';g.lineWidth=lw||2.2;g.strokeStyle=FKO;g.stroke();g.fillStyle=col;g.fill();
 /* optional fin finish: fine rays along the strand and a soft highlight on one edge */
 if(rays){g.save();g.clip();g.lineCap='round';const line=(f,c,w)=>{g.beginPath();for(let i=0;i<n;i++){const px=L[i][0]+(R[i][0]-L[i][0])*f,py=L[i][1]+(R[i][1]-L[i][1])*f;i?g.lineTo(px,py):g.moveTo(px,py)}g.strokeStyle=c;g.lineWidth=w;g.stroke()};
  for(const f of [.3,.5,.7])line(f,rays,.7);line(.16,'rgba(255,255,255,.65)',1.1);g.restore()}}
/* eyelid: amt 0 open .. 1 shut */
function fa6_lid(g,x,y,r,amt,col){if(amt<=0)return;const ly=y-r+2*r*Math.min(1,amt);g.save();g.beginPath();g.arc(x,y,r,0,TAU);g.clip();
 g.beginPath();g.moveTo(x-r-3,y-r-3);g.lineTo(x+r+3,y-r-3);g.lineTo(x+r+3,ly);g.quadraticCurveTo(x,ly+r*.2,x-r-3,ly);g.closePath();g.fillStyle=col;g.fill();
 g.beginPath();g.moveTo(x+r+3,ly);g.quadraticCurveTo(x,ly+r*.2,x-r-3,ly);g.strokeStyle=FKO;g.lineWidth=Math.max(2,r*.26);g.stroke();if(amt>.7){g.globalAlpha=Math.min(1,(amt-.7)/.22);g.beginPath();g.moveTo(x-r*.8,y+r*.02);g.quadraticCurveTo(x,y+r*.56,x+r*.8,y+r*.02);g.lineWidth=Math.max(1.8,r*.24);g.stroke();g.beginPath();g.moveTo(x-r*.5,y-r*.32);g.quadraticCurveTo(x,y-r*.02,x+r*.5,y-r*.32);g.strokeStyle='rgba(255,255,255,.32)';g.lineWidth=Math.max(1,r*.13);g.stroke();g.globalAlpha=1}g.restore();
 g.beginPath();g.arc(x,y,r,0,TAU);g.lineWidth=Math.max(2,r*.24);g.strokeStyle=FKO;g.stroke()}
/* blink: 0 open, rising to 1 for a quick blink every few seconds */
function fa6_blink(t,s){const p=((t+s)%5.1+5.1)%5.1;return p>4.9?1-Math.abs(p-5)/.1:0}
/* small cartoon smile */
function fa6_smile(g,x0,y0,cx,cy,x1,y1,w){g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo(cx,cy,x1,y1);g.strokeStyle=FKO;g.lineWidth=w||2.4;g.lineCap='round';g.stroke()}
/* rosy cheek blush */
function fa6_blush(g,x,y,r,c,a){g.save();g.globalAlpha=a==null?.45:a;g.fillStyle=fa6_rgrad(g,x,y,0,r,[[0,c||'#ff7aa0'],[1,(c||'#ff7aa0')+'00']]);g.beginPath();g.ellipse(x,y,r,r*.62,0,0,TAU);g.fill();g.restore()}
/* pectoral fin: a fan hinged at (x,y), sweeping back; a = tilt */
function fa6_pec(g,x,y,a,L,c1,c2,al,rim){fa6_at(g,x,y,a,()=>{const P=()=>fa6_path(g,['M',3,-3.5,'C',-L*.3,-L*.34,-L*.78,-L*.3,-L,-L*.08,'Q',-L*1.02,L*.08,-L*.9,L*.18,'Q',-L*.8,L*.3,-L*.62,L*.3,'C',-L*.36,L*.28,-L*.1,L*.12,3,3.5,'Z']);
 g.globalAlpha=al||1;P();fkFill(g,fkLin(g,0,0,-L,L*.1,[c1,c2]),2.2);g.globalAlpha=1;fa6_ribs(g,P,2,0,[-L,-L*.12,-L,L*.04,-L*.9,L*.2,-L*.7,L*.3],.3);
 fa6_finfx(g,P,0,0,shade(c1,.45),[-L*.98,-L*.03,-L*.96,L*.12,-L*.82,L*.26],.6,0);
 g.save();P();g.clip();g.beginPath();g.moveTo(2,-3);g.bezierCurveTo(-L*.3,-L*.3,-L*.78,-L*.26,-L*.98,-L*.06);g.strokeStyle=rim||'rgba(255,255,255,.55)';g.lineWidth=2;g.stroke();g.restore();P();g.lineJoin='round';g.lineWidth=2.2;g.strokeStyle=FKO;g.stroke()})}
/* 6-armed snowflake crystal */
function fa6_snow(g,x,y,r,rot,c,a){g.save();g.translate(x,y);g.rotate(rot);g.globalAlpha=a==null?1:a;g.strokeStyle=c||'#fff';g.lineCap='round';g.lineWidth=Math.max(1,r*.26);
 for(let i=0;i<6;i++){g.rotate(TAU/6);g.beginPath();g.moveTo(0,0);g.lineTo(r,0);g.moveTo(r*.55,0);g.lineTo(r*.8,-r*.24);g.moveTo(r*.55,0);g.lineTo(r*.8,r*.24);g.stroke()}
 g.beginPath();g.arc(0,0,r*.2,0,TAU);g.fillStyle=c||'#fff';g.fill();g.restore()}
/* catch-spectacle wash */
function fa6_catch(g,o,c,k){const v=(o.glow||0)*(k||1);if(v>0)fkGlow(g,10,0,115,c||'#fff2c8',.24*v)}
/* ribbon outline from a centre line fn(s)->[x,y,halfWidth]; returns flat points (left side then right side reversed) */
function fa6_rib(n,fn){const c=[];for(let i=0;i<=n;i++)c.push(fn(i/n));const L=[],R=[];
 for(let i=0;i<=n;i++){const a=c[Math.max(0,i-1)],b=c[Math.min(n,i+1)],dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy)||1,nx=-dy/d,ny=dx/d,w=c[i][2];
  L.push(c[i][0]+nx*w,c[i][1]+ny*w);R.unshift(c[i][0]-nx*w,c[i][1]-ny*w)}return L.concat(R)}
/* closed smooth spline (same curve as fkPath) appended to the current path when cont is true */
function fa6_blob(g,p,cont){const n=p.length/2,mx=i=>(p[(i%n)*2]+p[((i+1)%n)*2])/2,my=i=>(p[(i%n)*2+1]+p[((i+1)%n)*2+1])/2;if(!cont)g.beginPath();g.moveTo(mx(n-1),my(n-1));for(let i=0;i<n;i++)g.quadraticCurveTo(p[i*2],p[i*2+1],mx(i),my(i));g.closePath()}
/* clip to everything OUTSIDE a spline outline (so see-through bodies do not show the fin roots behind them) */
function fa6_outside(g,p){g.beginPath();g.rect(-400,-400,800,800);fa6_blob(g,p,1);g.clip('evenodd')}
/* crystal fin polygon: pre points, then an outer edge with a sharp ice shard between every pair of edge points, then post points */
function fa6_crys(pre,edge,post,len){const out=pre.slice();let cx=0,cy=0;const all=pre.concat(edge,post);for(let i=0;i<all.length;i+=2){cx+=all[i];cy+=all[i+1]}cx/=all.length/2;cy/=all.length/2;
 for(let i=0;i<edge.length;i+=2){out.push(edge[i],edge[i+1]);if(i+3<edge.length){const ax=edge[i],ay=edge[i+1],bx=edge[i+2],by=edge[i+3],mx=(ax+bx)/2,my=(ay+by)/2;let nx=-(by-ay),ny=bx-ax;const d=Math.hypot(nx,ny)||1;nx/=d;ny/=d;
  if(nx*(mx-cx)+ny*(my-cy)<0){nx=-nx;ny=-ny}const L=len*(i/2%2?.72:1);out.push(mx+nx*L,my+ny*L)}}
 return out.concat(post)}
/* ---- polish kit (fa6_) ---- */
/* hex colour + alpha -> rgba() */
function fa6_rgba(h,a){const n=parseInt(h.slice(1,7),16);return `rgba(${n>>16},${n>>8&255},${n&255},${a})`}
/* rich eye: shaded sclera, gradient iris with a dark rim and fine striations, pupil, big catch-light, second glint and a soft lower reflection */
function fa6_eye(g,x,y,r,iris,look){look=look||0;const ix=x+r*.18+look*r*.12,iy=y+r*.05,ir=r*.62;
 g.beginPath();g.arc(x,y,r,0,TAU);g.fillStyle=fa6_rgrad(g,x-r*.25,y-r*.3,r*.1,r*1.05,[[0,'#ffffff'],[.62,'#fbf7f0'],[1,'#d8d0e6']]);g.fill();
 g.save();g.beginPath();g.arc(x,y,r,0,TAU);g.clip();
 g.beginPath();g.arc(ix,iy,ir,0,TAU);g.fillStyle=fa6_rgrad(g,ix-ir*.15,iy+ir*.25,ir*.08,ir,[[0,shade(iris,.5)],[.45,iris],[.85,shade(iris,-.35)],[1,shade(iris,-.6)]]);g.fill();
 g.strokeStyle=fa6_rgba(shade(iris,.55),.35);g.lineWidth=Math.max(.6,r*.06);g.beginPath();
 for(let i=0;i<10;i++){const a=i/10*TAU+.3;g.moveTo(ix+Math.cos(a)*ir*.42,iy+Math.sin(a)*ir*.42);g.lineTo(ix+Math.cos(a)*ir*.86,iy+Math.sin(a)*ir*.86)}g.stroke();
 g.beginPath();g.arc(ix,iy,ir,0,TAU);g.strokeStyle=fa6_rgba(shade(iris,-.7),.85);g.lineWidth=Math.max(.8,r*.08);g.stroke();
 g.beginPath();g.arc(x+r*.22+look*r*.12,y+r*.08,r*.34,0,TAU);g.fillStyle='#0c0612';g.fill();
 /* upper lid shadow */
 g.fillStyle=fa6_grad(g,0,y-r,0,y-r*.2,[[0,'rgba(40,20,60,.32)'],[1,'rgba(40,20,60,0)']]);g.fillRect(x-r,y-r,r*2,r*.8);
 /* lower reflection crescent */
 g.beginPath();g.arc(ix,iy,ir*.72,Math.PI*.25,Math.PI*.8);g.strokeStyle='rgba(255,255,255,.42)';g.lineWidth=Math.max(.8,r*.1);g.lineCap='round';g.stroke();
 g.restore();
 g.beginPath();g.arc(x,y,r,0,TAU);g.lineWidth=Math.max(2,r*.24);g.strokeStyle=FKO;g.stroke();
 g.beginPath();g.ellipse(x+r*.34,y-r*.24,r*.25,r*.21,-.5,0,TAU);g.fillStyle='#fff';g.fill();
 g.beginPath();g.arc(x+r*.08,y-r*.34,r*.08,0,TAU);g.fill();
 g.beginPath();g.arc(x-r*.06,y+r*.34,r*.1,0,TAU);g.fillStyle='rgba(255,255,255,.75)';g.fill()}
/* rim light: thin light just inside the top edge (moonlight) and a reflected glow inside the bottom edge */
function fa6_rim(g,clip,top,bot,a,w){a=a==null?1:a;w=w||2;g.save();clip();g.clip();
 if(top){g.save();g.translate(.6,w*1.25);clip();g.strokeStyle=top;g.globalAlpha=.55*a;g.lineWidth=w;g.stroke();g.restore()}
 if(bot){g.save();g.translate(-.6,-w*1.3);clip();g.strokeStyle=bot;g.globalAlpha=.5*a;g.lineWidth=w*1.2;g.stroke();g.restore()}
 g.restore()}
/* crisp specular glint (a bright tilted lozenge and a dot) */
function fa6_spec(g,x,y,s,a){g.save();g.globalAlpha=a==null?.95:a;g.fillStyle='#fff';g.beginPath();g.ellipse(x,y,3.4*s,1.25*s,-.42,0,TAU);g.fill();
 g.beginPath();g.arc(x+4.6*s,y-2.4*s,.9*s,0,TAU);g.fill();g.restore()}
/* fin finish: shadowed root, fine secondary rays, and a light translucent band toward the edge */
function fa6_finfx(g,P,rx,ry,edge,rays,a,lw){a=a==null?1:a;g.save();P();g.clip();
 if(rays&&rx!=null){g.strokeStyle=fa6_rgba(edge,.32*a);g.lineWidth=.8;g.lineCap='round';g.beginPath();for(let i=0;i<rays.length;i+=2){g.moveTo(rx,ry);g.lineTo(rx+(rays[i]-rx)*1.1,ry+(rays[i+1]-ry)*1.1)}g.stroke()}
 g.lineJoin='round';P();g.strokeStyle=fa6_rgba(edge,.16*a);g.lineWidth=12;g.stroke();P();g.strokeStyle=fa6_rgba(edge,.3*a);g.lineWidth=5;g.stroke();
 if(rx!=null&&ry!=null){g.fillStyle=fa6_rgrad(g,rx,ry,0,26,[[0,'rgba(20,8,30,.2)'],[1,'rgba(20,8,30,0)']]);g.fillRect(rx-28,ry-28,56,56)}
 g.restore();if(lw!==0){P();g.lineJoin='round';g.lineWidth=lw||2.4;g.strokeStyle=FKO;g.stroke()}}
/* embossed fine scales: dark scale edges with a lighter catch-light just inside */
function fa6_tex(g,clip,x0,x1,y0,y1,s,dark,light,a){fkScales(g,clip,x0,x1,y0,y1,s,dark,a);g.save();g.translate(0,-1);fkScales(g,clip,x0,x1,y0,y1,s,light,a*.75);g.restore()}
/* operculum: soft shade behind the gill, a crisp gill line, a highlight on its front lip and a faint second slit */
function fa6_gill2(g,clip,x,y,r,a0,a1,c,a){a=a==null?.6:a;g.save();clip();g.clip();g.lineCap='round';
 g.beginPath();g.arc(x,y,r,a0,a1);g.arc(x,y,r+10,a1,a0,true);g.closePath();g.fillStyle=fa6_rgrad(g,x,y,r,r+10,[[0,fa6_rgba(c,.24)],[1,fa6_rgba(c,0)]]);g.fill();
 g.beginPath();g.arc(x+7,y,r+6,a0+.08,a1-.08);g.strokeStyle=fa6_rgba(c,.28*a/.6);g.lineWidth=1.2;g.stroke();
 g.beginPath();g.arc(x,y,r,a0,a1);g.strokeStyle=c;g.globalAlpha=Math.min(1,a*1.2);g.lineWidth=1.8;g.stroke();
 g.beginPath();g.arc(x-1.6,y,r,a0+.06,a1-.06);g.strokeStyle='#ffffff';g.globalAlpha=.3;g.lineWidth=1.2;g.stroke();g.restore()}
/* mouth with a soft lower lip, a lip highlight and a curled corner */
function fa6_mouth(g,x0,y0,cx,cy,x1,y1,w,lip){g.save();g.lineCap='round';
 g.beginPath();g.moveTo(x0-.5,y0+1.8);g.quadraticCurveTo(cx,cy+2.4,x1+.5,y1+1.8);g.strokeStyle=fa6_rgba(lip||'#ff8aa8',.55);g.lineWidth=3.2;g.stroke();
 g.beginPath();g.moveTo(x0,y0-1.4);g.quadraticCurveTo(cx,cy-1.6,x1+1,y1-1.4);g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=1.1;g.stroke();
 fa6_smile(g,x0,y0,cx,cy,x1,y1,w||2);
 g.beginPath();g.arc(x1+1.6,y1,2,Math.PI*.72,Math.PI*1.28);g.strokeStyle=FKO;g.lineWidth=1.2;g.stroke();g.restore()}
/* gentle colour variation: a few soft tinted blotches inside a clip; b=[[x,y,r,colour,alpha],...] */
function fa6_mottle(g,clip,b){g.save();clip();g.clip();for(const m of b){g.fillStyle=fa6_rgrad(g,m[0],m[1],0,m[2],[[0,fa6_rgba(m[3],m[4])],[1,fa6_rgba(m[3],0)]]);g.fillRect(m[0]-m[2],m[1]-m[2],m[2]*2,m[2]*2)}g.restore()}
/* fine speckle texture (deterministic) inside a clip */
function fa6_speck(g,clip,x0,x1,y0,y1,n,col,a,r,seed){g.save();clip();g.clip();g.fillStyle=col;g.globalAlpha=a;g.beginPath();let s=seed||7;
 for(let i=0;i<n;i++){s=(s*9301+49297)%233280;const u=s/233280;s=(s*9301+49297)%233280;const v=s/233280;const x=x0+(x1-x0)*u,y=y0+(y1-y0)*v,rr=r*(.6+.8*((i*37)%10)/10);g.moveTo(x+rr,y);g.arc(x,y,rr,0,TAU)}g.fill();g.restore()}
/* frost rime: a dotted white crust just inside an outline */
function fa6_rime(g,P,a,w){g.save();P();g.clip();P();g.strokeStyle=`rgba(255,255,255,${a==null?.7:a})`;g.lineWidth=w||3;g.setLineDash([1.6,3.4]);g.lineCap='round';g.stroke();g.setLineDash([]);g.restore()}
/* frosted fin: translucent ice gradient, fine rays, a misty edge band and a rime crust */
function fa6_frostFin(g,pp,rx,ry,c1,c2,ribs,lw,al){const P=()=>fkPath(g,pp);g.globalAlpha=al==null?.92:al;fkFin(g,pp,c1,c2,ribs,lw||2.3);g.globalAlpha=1;
 fa6_finfx(g,P,null,null,'#ffffff',null,1,0);fa6_rime(g,P,.8,2.4);P();g.lineJoin='round';g.lineWidth=lw||2.3;g.strokeStyle=FKO;g.stroke()}
/* faceted ice crystal (a hexagonal prism with a pointed cap) standing at (x,y), pointing along angle a; length L, width w */
function fa6_icicle(g,x,y,a,L,w,al,t){fa6_at(g,x,y,a,()=>{const h=w*.5,P=()=>fa6_poly(g,[-2,-h,L*.66,-h,L,0,L*.66,h,-2,h]);
 g.globalAlpha=al==null?1:al;P();fkFill(g,fa6_grad(g,0,-h,0,h,[[0,'#ffffff'],[.45,'#d4f2ff'],[.5,'#9ad6ff'],[1,'#5aa8f0']]),2);
 g.save();P();g.clip();g.fillStyle='rgba(255,255,255,.55)';fa6_poly(g,[-2,-h,L*.66,-h,L,0,L*.62,-h*.15,-2,-h*.15]);g.fill();
 g.beginPath();g.moveTo(L*.66,-h);g.lineTo(L*.62,-h*.15);g.lineTo(L*.66,h);g.moveTo(L*.62,-h*.15);g.lineTo(L,0);g.strokeStyle='rgba(30,90,180,.5)';g.lineWidth=.9;g.stroke();g.restore();
 P();g.lineWidth=2;g.strokeStyle=FKO;g.stroke();g.globalAlpha=1})}
/* a little cluster of three ice crystals fanning out of a surface at (x,y); a = outward angle; a frosty rime patch hides the roots */
function fa6_cluster(g,x,y,a,s,t,i){const k=fa6_tw(t,i||0,2.2),ix=x-Math.cos(a)*3*s,iy=y-Math.sin(a)*3*s;
 fa6_icicle(g,ix+Math.sin(a)*3*s,iy-Math.cos(a)*3*s,a-.7,13*s,6.2*s);fa6_icicle(g,ix-Math.sin(a)*3*s,iy+Math.cos(a)*3*s,a+.66,11.5*s,5.8*s);fa6_icicle(g,ix,iy,a,18*s,7.4*s);
 g.save();g.translate(x-Math.cos(a)*1.5*s,y-Math.sin(a)*1.5*s);g.rotate(a+Math.PI/2);g.beginPath();g.ellipse(0,0,10*s,3.6*s,0,0,TAU);g.fillStyle=fa6_rgrad(g,0,0,0,8*s,[[0,'rgba(255,255,255,.95)'],[.6,'rgba(220,246,255,.7)'],[1,'rgba(200,240,255,0)']]);g.fill();
 g.fillStyle='#fff';for(const d of [[-5,.6,1],[4.5,.4,.9],[0,1.4,.8]]){g.beginPath();g.arc(d[0]*s,d[1]*s,d[2]*s,0,TAU);g.fill()}g.restore();
 fkSpark(g,x+Math.cos(a)*18*s,y+Math.sin(a)*18*s,(2.4+3.4*k)*s,'#ffffff',.45+.55*k)}
/* outlined 4-point star (fill + dark rim) */
function fa6_star(g,x,y,r,c,lw){g.beginPath();g.moveTo(x,y-r);g.quadraticCurveTo(x+r*.16,y-r*.16,x+r,y);g.quadraticCurveTo(x+r*.16,y+r*.16,x,y+r);g.quadraticCurveTo(x-r*.16,y+r*.16,x-r,y);g.quadraticCurveTo(x-r*.16,y-r*.16,x,y-r);g.closePath();
 g.fillStyle=c;g.fill();g.lineJoin='round';g.lineWidth=lw||1.4;g.strokeStyle=FKO;g.stroke()}
/* soft travelling sheen band clipped to a path */
function fa6_sheen(g,P,t,sp,c,a){const sx=((t*sp)%280)-130;g.save();P();g.clip();g.fillStyle=fa6_grad(g,sx-24,-34,sx+24,34,[[0,'rgba(255,255,255,0)'],[.5,fa6_rgba(c,a)],[1,'rgba(255,255,255,0)']]);g.fillRect(-120,-60,240,120);g.restore()}


/* ---------------- 1. Honeycomb Goby (Common): a chubby honey-gold goby tiled in hexagons, striped amber fins and a drip of honey under its chin ---------------- */
/* hexagon grid (flat-top cells of radius s) added to the current path */
function fa6_hexes(g,x0,x1,y0,y1,s){const w=s*1.5,h=s*Math.sqrt(3);g.beginPath();
 for(let c=0,x=x0;x<x1;x+=w,c++)for(let y=y0+(c%2?h/2:0);y<y1;y+=h){g.moveTo(x+s,y);for(let k=1;k<6;k++)g.lineTo(x+Math.cos(k*Math.PI/3)*s,y+Math.sin(k*Math.PI/3)*s);g.closePath()}}
function fa6_hexOne(g,x,y,s){g.beginPath();g.moveTo(x+s,y);for(let k=1;k<6;k++)g.lineTo(x+Math.cos(k*Math.PI/3)*s,y+Math.sin(k*Math.PI/3)*s);g.closePath()}
FISHART.honey=(g,t,o)=>{const sw=fkSway(o,4.2,.15),fin=Math.sin(t*5.2)*.1,fx=o.flex||0,gl=o.glow||0;g.save();g.translate(-2,0);g.rotate(-sw*.18);
 const BP=[107,8,104,-15,91,-35,67,-45,37,-43,7,-34,-22,-22,-46,-13,-58,-10.5,-58,10.5,-46,13,-22,21,7,31,37,38,67,40,93,31,105,19],B=()=>fkPath(g,BP);
 const amb1='#ffa526',amb2='#c4520a',band='rgba(74,26,4,.82)';
 /* fin with dark amber bands following its outer edge (concentric arcs around the root) */
 const bandFin=(pp,rx,ry,rays,radii,lw,cA,cB)=>{const P=()=>fkPath(g,pp);P();fkFill(g,fa6_grad(g,rx,ry,pp[Math.floor(pp.length/4)*2],pp[Math.floor(pp.length/4)*2+1],[[0,cA||'#ffd770'],[.5,amb1],[1,cB||amb2]]),lw||2.4);
  g.save();P();g.clip();g.lineCap='round';for(const r of radii){g.beginPath();g.arc(rx,ry,r,0,TAU);g.strokeStyle=band;g.lineWidth=2.6;g.stroke();g.beginPath();g.arc(rx,ry,r+2.2,0,TAU);g.strokeStyle='rgba(255,240,190,.45)';g.lineWidth=1;g.stroke()}g.restore();
  fa6_ribs(g,P,rx,ry,rays,.26,'#6a3006',1.1);fa6_finfx(g,P,rx,ry,'#fff4c8',null,.8,0);P();g.lineJoin='round';g.lineWidth=lw||2.4;g.strokeStyle=FKO;g.stroke()};
 // tail: a round goby fan with amber bars
 fa6_at(g,-54,0,sw,()=>{const tp=[6,-7,-8,-14,-24,-26,-38,-31,-48,-24,-52,-10,-53,0,-52,10,-48,24,-38,31,-24,26,-8,14,6,7];
  bandFin(tp,4,0,[-38,-29,-48,-20,-52,-6,-52,6,-48,20,-38,29,-24,24,-24,-24],[22,34,45],2.6,'#ffd36a','#c24c08');
  g.save();fkPath(g,tp);g.clip();fa6_rim(g,()=>fkPath(g,tp),'#fff2c0',null,1,1.5);g.restore()});
 // second dorsal: a long low fin running back toward the tail
 fa6_at(g,-12,-29,fin*.35,()=>bandFin([10,3,7,-8,0,-15,-8,-18,-16,-16,-24,-19,-32,-14,-40,-12,-46,-4,-44,8],2,4,[-2,-15,-14,-16,-26,-15,-38,-11],[12,21],2.3));
 // anal fin
 fa6_at(g,-14,24,-fin*.4,()=>bandFin([10,-2,6,8,-8,14,-24,14,-38,9,-42,-2],2,-3,[-6,13,-20,13,-34,9],[12,21],2.3));
 // first dorsal: a tall rounded spiny fan, the goby's flag
 fa6_at(g,28,-38,fin*.5,()=>bandFin([12,5,13,-10,9,-21,4,-24,-1,-30,-7,-28,-12,-30,-17,-24,-22,-18,-23,-6,-22,7],0,4,[8,-22,0,-28,-9,-27,-17,-20,-21,-8],[12,22],2.4));
 // pelvic sucker disc (the goby's fused pelvic cup): a flat pale cup peeking out under the belly, with radial ribs
 fa6_at(g,46,38.5,-fin*.3,()=>{const D=()=>{g.beginPath();g.ellipse(0,0,14,5.4,0,0,TAU)};D();fkFill(g,fa6_grad(g,0,-5,0,5,[[0,'#ffeec0'],[.5,'#ffd890'],[1,'#e8a040']]),2);
  g.save();D();g.clip();g.strokeStyle='rgba(130,60,8,.5)';g.lineWidth=1;g.lineCap='round';g.beginPath();for(let k=-3;k<=3;k++){g.moveTo(0,-3);g.lineTo(k*4.4,6)}g.stroke();
  g.beginPath();g.ellipse(-1,-.6,9.5,3,0,0,TAU);g.strokeStyle='rgba(255,252,236,.6)';g.lineWidth=1;g.stroke();g.restore()});
 // body: deep amber back, honey-gold flank, creamy belly
 B();fkFill(g,fa6_grad(g,0,-38,0,36,[[0,'#b05a06'],[.18,'#e48c10'],[.4,'#ffbe2e'],[.62,'#ffd866'],[.8,'#fff0b4'],[1,'#ffe2a0']]),3);
 fa6_mottle(g,B,[[56,-16,28,'#ff9a20',.25],[-20,-6,30,'#ffcf40',.22],[30,20,24,'#fff6d0',.3]]);
 // honeycomb: dark-amber cell walls with a light inner rim, a few cells brimming with glossy honey
 {const s=6.4;g.save();B();g.clip();
  // the comb fades out toward the face (x>55) so the cheek stays smooth honey-cream
  const w=s*1.5,h=s*Math.sqrt(3),gD=fa6_grad(g,0,-38,0,30,[[0,'rgba(110,46,2,.78)'],[.55,'rgba(150,72,6,.55)'],[1,'rgba(170,96,20,.14)']]),gL=fa6_grad(g,0,-38,0,30,[[0,'rgba(255,226,140,.5)'],[1,'rgba(255,250,220,.1)']]);
  const col=(x,y0)=>{g.beginPath();for(let y=y0;y<40;y+=h){g.moveTo(x+s,y);for(let k=1;k<6;k++)g.lineTo(x+Math.cos(k*Math.PI/3)*s,y+Math.sin(k*Math.PI/3)*s);g.closePath()}};
  g.lineJoin='round';for(let c=0,x=-70;x<70;x+=w,c++){const f=Math.max(0,Math.min(1,(62-x)/14));if(f<=0)continue;g.globalAlpha=f;const y0=-44+(c%2?h/2:0);
   col(x,y0);g.strokeStyle=gD;g.lineWidth=1.8;g.stroke();g.translate(.7,.9);col(x,y0);g.strokeStyle=gL;g.lineWidth=.9;g.stroke();g.translate(-.7,-.9)}g.globalAlpha=1;
  // honey-filled cells (the grid's own centres), flank only
  const cell=(c,r)=>[-70+c*w,-44+(c%2?h/2:0)+r*h];
  [[8,2],[11,3],[13,4],[6,4],[10,1],[4,3],[2,3],[7,1],[12,2]].forEach(([c,r],i)=>{const p=cell(c,r),k=fa6_tw(t,i*1.3,1.6);
   fa6_hexOne(g,p[0],p[1],s-1.2);g.fillStyle=fa6_rgrad(g,p[0]-1.5,p[1]-1.5,.5,s,[[0,'#fff3b0'],[.4,'#ffb820'],[1,'#c46a04']]);g.fill();
   g.beginPath();g.ellipse(p[0]-1.6,p[1]-2,1.8,1,-.5,0,TAU);g.fillStyle=`rgba(255,255,255,${.55+.4*k})`;g.fill()});
  g.restore()}
 fkShade(g,B,-6,-38,'#7a3402',.42);
 fkShade(g,B,14,36,'#e8a040',.28);
 fa6_rim(g,B,'#fff0b8','#ffe8a8',1,2);
 fa6_gloss(g,B,90,-25,58,-38,8,-31,3,.75);
 // gill arc just behind the eye
 fa6_gill(g,B,88,-2,32,Math.PI*.74,Math.PI*1.26,'#7a3404',.72);
 g.save();B();g.clip();g.beginPath();g.arc(89.6,-2,32,Math.PI*.76,Math.PI*1.24);g.strokeStyle='rgba(255,255,255,.3)';g.lineWidth=1.2;g.lineCap='round';g.stroke();g.restore();
 // a clear soft pink cheek
 g.save();B();g.clip();g.fillStyle=fa6_rgrad(g,83,6,0,11,[[0,'rgba(255,122,150,.66)'],[.5,'rgba(255,122,150,.55)'],[1,'rgba(255,122,150,0)']]);g.beginPath();g.ellipse(83,6,10.5,7,0,0,TAU);g.fill();g.restore();
 fa6_spec(g,46,-26,.85,.95);
 // big round pectoral fan
 fa6_at(g,60,12,-.5+fin*1.2,()=>{g.globalAlpha=.86;bandFin([4,-5,-4,-9,-15,-11,-25,-8,-30,-1,-28,8,-20,12,-8,10,4,5],2,0,[-25,-7,-29,0,-27,7,-19,11,-9,10,-14,-10],[22],2.2,'#ffe7a0','#ff9a2a');g.globalAlpha=1});
 // eye high on the head, and a friendly face
 fa6_eye(g,72,-19,14.5,'#8a4a12',.35);fa6_lid(g,72,-19,14.5,fa6_blink(t,.7),'#d47a0c');
 fa6_mouth(g,105,10,99,16.5,90,13.5,2.4,'#ff8a6a');
 // the honey drip: a thin strand from the lower lip ending in one glossy tapered teardrop that slowly swells and lets go
 {const ph=(t*.45)%1,st=ph<.8?ph/.8:1,len=6+st*4,dr=3.6+st*1.7,sx=Math.sin(t*1.8)*.7,bx=97.5+sx,ty=18+len,by=ty+dr*1.75;
  g.lineCap='round';g.beginPath();g.moveTo(97.5,17.6);g.quadraticCurveTo(97.5+sx*.4,17.6+len*.5,bx,ty+1.2);g.strokeStyle=FKO;g.lineWidth=2.2;g.globalAlpha=.75;g.stroke();g.globalAlpha=1;g.strokeStyle='#ffb424';g.lineWidth=1.1;g.stroke();
  const D=()=>{g.beginPath();g.moveTo(bx,ty);g.lineTo(bx+dr*.821,by-dr*.571);g.arc(bx,by,dr,-.607,Math.PI+.607);g.closePath()};
  D();g.fillStyle=fa6_rgrad(g,bx-dr*.35,by-dr*.4,0,dr*1.5,[[0,'#ffe27a'],[.45,'#ffae1c'],[1,'#b84e02']]);g.fill();g.lineJoin='round';g.lineWidth=1.4;g.strokeStyle=FKO;g.stroke();
  g.beginPath();g.ellipse(bx-dr*.38,by-dr*.3,dr*.26,dr*.44,.35,0,TAU);g.fillStyle='#fff';g.fill();g.beginPath();g.arc(bx+dr*.3,by+dr*.5,dr*.14,0,TAU);g.fillStyle='rgba(255,255,255,.75)';g.fill();
  // a falling droplet once the bead lets go
  if(ph>.8){const q=(ph-.8)/.2;g.beginPath();g.arc(bx,by+dr+2+q*22,1.8*(1-q*.4),0,TAU);g.fillStyle=`rgba(255,180,30,${1-q})`;g.fill()}}
 // honey sparkle on the comb
 fkSpark(g,20,-20,3+fa6_tw(t,2,2.2)*2.4,'#fff6d0',.45+.5*fa6_tw(t,2,2.2));
 fkSpark(g,-26,-12,2.4+fa6_tw(t,5,2.6)*2,'#fff6d0',.35+.5*fa6_tw(t,5,2.6));
 fa6_catch(g,o,'#ffe6a0');g.restore()};

/* ---------------- 2. Mossy Mudskipper (Common): froggy turret eyes, muscly pectoral arms, a tall spiny sail and moss tufts on its back ---------------- */
/* a fluffy moss clump: circles c=[[x,y,r],...] united under one outline, lit from the top, with sprouts */
function fa6_moss(g,x,y,w,h,t,ph,sprouts){g.save();g.lineJoin='round';const n=26,pts=[];
 for(let i=0;i<n;i++){const a=Math.PI+i/(n-1)*Math.PI,bump=1+.16*Math.sin(i*2.6+ph*3)+.08*Math.sin(i*5.3);pts.push(x+Math.cos(a)*w*bump,y+Math.sin(a)*h*bump)}
 pts.push(x+w*.9,y+3,x-w*.9,y+3);const P=()=>fkPath(g,pts);
 P();fkFill(g,fa6_grad(g,0,y-h,0,y+3,[[0,'#a6e652'],[.5,'#5aa62c'],[1,'#2a5e16']]),2.4);
 g.save();P();g.clip();g.fillStyle='rgba(206,255,130,.7)';for(let i=0;i<16;i++){const u=((i*37)%16)/16,v=((i*11)%7)/7;g.beginPath();g.arc(x-w*.8+u*w*1.6,y-h*.85+v*h*.9,.8+(i%3)*.4,0,TAU);g.fill()}
 g.fillStyle='rgba(16,50,10,.35)';for(let i=0;i<9;i++){const u=((i*29)%9)/9;g.beginPath();g.arc(x-w*.7+u*w*1.4,y-h*.15+(i%3)*1.4,.9+(i%2)*.5,0,TAU);g.fill()}
 g.translate(-1.2,1.6);P();g.strokeStyle='rgba(230,255,170,.6)';g.lineWidth=1.6;g.stroke();g.restore();
 // stray mossy strands drooping over the back
 g.lineCap='round';for(let i=0;i<3;i++){const sx=x-w*.6+i*w*.6,L=3+(i%2)*3;g.beginPath();g.moveTo(sx,y+1);g.quadraticCurveTo(sx-1.5,y+L*.6,sx-.5+Math.sin(t*2+i)*.6,y+L);g.strokeStyle='#4a9a26';g.lineWidth=1.4;g.stroke()}
 for(const s of sprouts||[]){const a=s[2]+Math.sin(t*2.2+ph+s[0]*.3)*.12;fa6_at(g,s[0],s[1],a,()=>{const L=s[3];
   g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(1.5,-L*.5,0,-L);g.strokeStyle=FKO;g.lineWidth=3.4;g.stroke();g.strokeStyle='#8ad848';g.lineWidth=1.6;g.stroke();
   for(const k of [-1,1]){g.save();g.translate(0,-L*.62);g.rotate(k*.9);g.beginPath();g.ellipse(k*3.2,0,3.6,1.9,0,0,TAU);fkFill(g,'#9ae654',1.4);g.restore()}
   if(s[4]){for(let q=0;q<5;q++){const aa=q/5*TAU+t*.3;g.beginPath();g.arc(Math.cos(aa)*2.2,-L+Math.sin(aa)*2.2,1.7,0,TAU);fkFill(g,s[4],1)}g.beginPath();g.arc(0,-L,1.3,0,TAU);g.fillStyle='#ffe066';g.fill()}})}
 g.restore()}
FISHART.skipper=(g,t,o)=>{const fx=o.flex||0,sw=fkSway(o,3.6,.14),fin=Math.sin(t*4.6)*.1,bob=Math.sin(t*2.4)*1.6*(1-fx)+Math.sin(t*14)*fx*2.4;
 g.save();g.translate(-2,0);g.rotate(-.05-sw*.15);
 const BP=[107,8,105,-8,97,-20,81,-27,56,-28,28,-24,0,-19,-30,-13,-54,-8,-64,-6.5,-64,6.5,-54,9,-30,15,0,22,30,27,60,29,89,26,103,18],B=()=>fkPath(g,BP);
 const olive=['#34461a','#647226','#a89036','#d8b45a','#f8e2a0'];
 // far pectoral arm (behind the body), planted on the mud
 const arm=(sx,sy,wx,wy,dark,flap)=>{const dx=wx-sx,dy=wy-sy,L=Math.hypot(dx,dy),a=Math.atan2(dy,dx);
  const dk=c=>dark?shade(c,-.25):c;
  fa6_at(g,sx,sy,a,()=>{const P=()=>fa6_path(g,['M',-2,-8,'C',L*.3,-12,L*.6,-10,L,-5,'Q',L+3.4,0,L,5,'C',L*.6,8,L*.3,10,-2,8,'Z']);P();fkFill(g,fa6_grad(g,0,-10,0,9,[[0,dk('#b8a848')],[.45,dk('#98843a')],[1,dk('#5e501c')]]),2.4);
   g.save();P();g.clip();[[L*.3,-4,1.7],[L*.55,-1,1.4],[L*.8,-3,1.3],[L*.4,3,1.2]].forEach(q=>{g.beginPath();g.arc(q[0],q[1],q[2],0,TAU);g.fillStyle=dark?'#2cc4b4':'#4ef2e0';g.fill()});
   g.beginPath();g.moveTo(2,-4.6);g.quadraticCurveTo(L*.5,-6.5,L-2,-3);g.strokeStyle=`rgba(255,246,200,${dark?.32:.6})`;g.lineWidth=1.8;g.stroke();
   g.beginPath();g.moveTo(L*.36,5);g.quadraticCurveTo(L*.45,1,L*.55,5.6);g.strokeStyle='rgba(40,30,10,.35)';g.lineWidth=1.2;g.stroke();g.restore()});
  // the fan "hand": a little fin splayed flat on the ground
  fa6_at(g,wx,wy,flap,()=>{const pp=[-3,-2,6,-3,14,1,17,7,12,10,2,10,-8,9,-13,5,-10,0],P=()=>fkPath(g,pp);P();fkFill(g,fa6_grad(g,0,-3,0,10,[[0,dk('#ffbe6a')],[.6,dk('#f08a2a')],[1,dk('#b8501a')]]),2.2);
   fa6_ribs(g,P,1,-2,[16,7,10,10,2,10,-6,9,-12,5],.35,'#4a1a04',1);fa6_finfx(g,P,1,-2,'#fff0c8',null,dark?.5:.8,0);P();g.lineWidth=2.2;g.strokeStyle=FKO;g.stroke()})};
 const wy=40-bob*.2;
 arm(40,12+bob,30,wy,1,Math.sin(t*14)*fx*.3);
 g.translate(0,bob);
 // tail: rounded with a longer lower lobe
 fa6_at(g,-60,0,sw,()=>{const tp=[6,-6,-10,-11,-25,-17,-38,-15,-46,-7,-49,3,-45,15,-34,24,-18,19,-6,10,6,6],P=()=>fkPath(g,tp);
  P();fkFill(g,fa6_grad(g,6,0,-48,0,[[0,'#8a7828'],[.5,'#c8a040'],[1,'#e0b858']]),2.5);
  fa6_ribs(g,P,4,0,[-38,-14,-45,-6,-48,3,-44,14,-34,22,-22,-16,-22,18],.3,'#3a2a08',1.1);
  g.save();P();g.clip();P();g.strokeStyle='rgba(255,110,40,.95)';g.lineWidth=8;g.stroke();P();g.strokeStyle='rgba(255,224,120,.95)';g.lineWidth=2.2;g.stroke();
  [[-29,-6,2.3],[-37,6,2],[-23,11,1.8]].forEach(([x,y,r],i)=>{const k=fa6_tw(t,i*2.3+9,1.8);g.fillStyle=fa6_rgrad(g,x,y,0,r*2.6,[[0,`rgba(80,255,230,${.25+.2*k})`],[1,'rgba(80,255,230,0)']]);g.fillRect(x-r*3,y-r*3,r*6,r*6);g.beginPath();g.arc(x,y,r,0,TAU);g.fillStyle='#4ef2e0';g.fill();g.beginPath();g.arc(x-r*.3,y-r*.35,r*.42,0,TAU);g.fillStyle='#dafffa';g.fill()});
  g.restore();
  fa6_finfx(g,P,4,0,'#fff2c0',null,.7,0);P();g.lineWidth=2.5;g.strokeStyle=FKO;g.stroke();
  for(const [x,y] of [[-38,-14],[-45,-6],[-48,3],[-44,14],[-34,22]]){g.beginPath();g.arc(x,y,1.4,0,TAU);g.fillStyle='#fff6d8';g.fill()}});
 // spiny sail fin: teal membrane with turquoise spots, a hot-orange edge band; spines poke out past the membrane
 const sail=(bx,by,n,dx,H,ph,lean,prof)=>{const base=[],tip=[];for(let i=0;i<n;i++){const k=i/(n-1),x=bx-i*dx,y=by+i*1.2,h=H*prof(k)*(1+Math.sin(t*3+ph+i*.6)*.03),a=lean+k*.42;base.push([x,y]);tip.push([x-Math.sin(a)*h,y-Math.cos(a)*h])}
  const m=q=>[base[q][0]+(tip[q][0]-base[q][0])*.88,base[q][1]+(tip[q][1]-base[q][1])*.88];
  const P=()=>{g.beginPath();g.moveTo(base[0][0]+6,base[0][1]+4);let a=m(0);g.lineTo(a[0],a[1]);for(let i=1;i<n;i++){const b=m(i),cx=(a[0]+b[0])/2,cy=(a[1]+b[1])/2,bx2=(base[i-1][0]+base[i][0])/2,by2=(base[i-1][1]+base[i][1])/2;g.quadraticCurveTo(cx+(bx2-cx)*.14,cy+(by2-cy)*.14,b[0],b[1]);a=b}g.lineTo(base[n-1][0]-7,base[n-1][1]+4);g.closePath()};
  g.lineCap='round';for(let i=0;i<n;i++){g.beginPath();g.moveTo(base[i][0],base[i][1]+3);g.lineTo(tip[i][0],tip[i][1]);g.strokeStyle=FKO;g.lineWidth=3.6;g.stroke();g.strokeStyle='#ffe2a0';g.lineWidth=1.4;g.stroke()}
  P();g.lineJoin='round';fkFill(g,fa6_grad(g,0,by,0,by-H,[[0,'#0e4a5a'],[.45,'#1a8aa2'],[1,'#40dcdc']]),2.4);
  g.save();P();g.clip();
  P();g.strokeStyle='rgba(255,110,40,.95)';g.lineWidth=8;g.stroke();P();g.strokeStyle='rgba(255,224,120,.95)';g.lineWidth=2.2;g.stroke();
  for(let i=0;i<n-1;i++)for(let j=1;j<5;j++){const k=j/5.6,x=(base[i][0]+base[i+1][0])/2+((tip[i][0]+tip[i+1][0])/2-(base[i][0]+base[i+1][0])/2)*k,y=(base[i][1]+base[i+1][1])/2+((tip[i][1]+tip[i+1][1])/2-(base[i][1]+base[i+1][1])/2)*k;g.beginPath();g.arc(x+(j%2?1:-1),y,1.5+(j%2)*.5,0,TAU);g.fillStyle='#8afff0';g.fill()}
  for(let i=0;i<n;i++){g.beginPath();g.moveTo(base[i][0],base[i][1]+3);g.lineTo(tip[i][0],tip[i][1]);g.strokeStyle='rgba(6,30,40,.55)';g.lineWidth=1.3;g.stroke()}
  g.restore();fa6_finfx(g,P,base[0][0],base[0][1]+4,'#c8fff8',null,.6,0);P();g.lineWidth=2.4;g.strokeStyle=FKO;g.stroke();
  for(let i=0;i<n;i++){g.beginPath();g.arc(tip[i][0],tip[i][1],1.4,0,TAU);g.fillStyle='#fff6d8';g.fill()}};
 sail(26,-25,8,5.6,49,0,-.32,k=>.34+.7*Math.sin(Math.PI*Math.min(1,k*.95+.08)));
 sail(-26,-15,6,6.2,17,1.7,.35,k=>1-k*.35);
 // body: olive-brown with a cream belly, darker saddle blotches and glowing turquoise speckles
 B();fkFill(g,fa6_grad(g,0,-28,0,29,[[0,olive[0]],[.25,olive[1]],[.52,olive[2]],[.72,olive[3]],[.88,olive[4]],[1,'#e6bc68']]),3);
 g.save();B();g.clip();
 [[60,-22,10],[30,-20,11],[0,-15,10],[-28,-10,9],[-52,-6,7]].forEach(([x,y,r])=>{g.fillStyle=fa6_rgrad(g,x,y,0,r*1.6,[[0,'rgba(30,34,8,.5)'],[1,'rgba(30,34,8,0)']]);g.beginPath();g.ellipse(x,y+2,r*1.1,r*1.5,0,0,TAU);g.fill()});
 g.restore();
 fa6_tex(g,B,-66,90,-26,20,5.2,'#2a2a0a','#f6e6b0',.1);
 fkShade(g,B,-4,-29,'#1a2408',.4);
 // turquoise speckles with soft halos
 g.save();B();g.clip();const SP=[[90,-6,2],[84,4,1.7],[72,-14,2.2],[64,-4,1.8],[52,-16,2],[44,-6,2.4],[36,-16,1.7],[24,-8,2.2],[14,-16,1.8],[4,-6,2],[-8,-13,1.7],[-18,-4,2.2],[-30,-9,1.8],[-40,-2,1.9],[-50,-5,1.5],[56,6,1.6],[30,4,1.7],[10,6,1.5],[-12,6,1.6],[76,-22,1.5],[-58,0,1.2]];
 SP.forEach(([x,y,r],i)=>{const k=fa6_tw(t,i*1.7,1.8);g.fillStyle=fa6_rgrad(g,x,y,0,r*2.6,[[0,`rgba(80,255,230,${.25+.2*k})`],[1,'rgba(80,255,230,0)']]);g.fillRect(x-r*3,y-r*3,r*6,r*6);
  g.beginPath();g.arc(x,y,r,0,TAU);g.fillStyle='#4ef2e0';g.fill();g.beginPath();g.arc(x-r*.3,y-r*.35,r*.42,0,TAU);g.fillStyle='#dafffa';g.fill()});g.restore();
 fkShade(g,B,16,29,'#d49838',.34);
 fa6_rim(g,B,'#e8f4a0','#fff0c0',1,1.8);
 fa6_gloss(g,B,92,-17,70,-26,30,-24,2.4,.6);
 fa6_gill2(g,B,92,4,24,Math.PI*.7,Math.PI*1.28,'#2a2a08',.55);
 // moss tufts on the back
 fa6_moss(g,44,-26,12.5,9,t,0,[[47,-32,-.25,9,'#ffb0de']]);
 fa6_moss(g,-6,-18.5,9.5,7,t,1.3,[[-4,-23,.25,7]]);
 fa6_moss(g,-56,-8.5,7.5,5.4,t,2.1,null);
 fa6_spec(g,22,-18,.8,.85);
 // pelvic nub and the near pectoral arm, propping the fish up
 g.translate(0,-bob);
 arm(54,14+bob,64,wy,0,Math.sin(t*14+1)*fx*.3);
 g.translate(0,bob);
 // turret eyes perched on top of the head: the far one peeks up behind the near one
 const eye=(x,y,r,look,lid,ph)=>{const R=r*1.24;
  const sf=fa6_grad(g,0,y-R,0,y+R*1.4,[[0,'#8a8a34'],[.6,olive[1]],[1,olive[1]]]);g.beginPath();g.arc(x,y,R*.96,0,TAU);g.fillStyle=sf;g.fill();
  g.save();B();g.clip();g.fillStyle=fa6_rgrad(g,x,y+R*.2,R*.5,R*1.5,[[0,fa6_rgba(olive[1],1)],[.6,fa6_rgba(olive[1],.55)],[1,fa6_rgba(olive[1],0)]]);g.beginPath();g.ellipse(x,y+R*.4,R*1.25,R*1.4,0,0,TAU);g.fill();g.restore();
  g.beginPath();g.arc(x,y,R*.96,Math.PI*.82,Math.PI*2.18);g.lineWidth=2.6;g.strokeStyle=FKO;g.stroke();
  g.beginPath();g.arc(x,y,R*.96,Math.PI*1.1,Math.PI*1.5);g.strokeStyle='rgba(240,255,170,.5)';g.lineWidth=1.6;g.stroke();
  fa6_eye(g,x,y,r,'#e0a018',look);
  const b=fa6_blink(t,ph);fa6_lid(g,x,y,r,Math.max(lid,b),'#7a7a2a')};
 const roll=Math.sin(t*.9)*.6;
 eye(64,-33,9.6,.9+roll*.2,.34,2.2);
 eye(80,-32,12.5,.2-roll,.24,.6);
 // a big goofy grin and blush
 fa6_blush(g,91,6,6,'#ff8a6a',.5);
 g.save();g.lineCap='round';g.beginPath();g.moveTo(106,9);g.quadraticCurveTo(98,17.5,84,10.5);g.strokeStyle='rgba(255,140,120,.6)';g.lineWidth=4;g.stroke();g.restore();
 fa6_smile(g,106,8,97,15.5,83,9,2.4);g.beginPath();g.arc(82.6,7,2.4,Math.PI*.4,Math.PI*1.1);g.strokeStyle=FKO;g.lineWidth=1.6;g.stroke();
 // one big goofy tooth
 g.beginPath();g.moveTo(97.2,12.6);g.lineTo(99.9,18.4);g.lineTo(102.6,12.2);g.closePath();fkFill(g,'#ffffff',1.4);
 // nostril
 g.beginPath();g.arc(101,-2,1.2,0,TAU);g.fillStyle=FKO;g.fill();
 fa6_catch(g,o,'#e0ffd0');g.restore()};

/* ---------------- 3. Knightfin Perch (Rare): polished plate-mail with riveted gold bands, a crested helm with a visor, a crimson pennant and a heater-shield tail ---------------- */
/* fleur-de-lis emblem centred at (x,y), height s */
function fa6_fleur(g,x,y,s,fill,lw){g.save();g.translate(x,y);g.scale(s/24,s/24);
 const P=()=>{g.beginPath();
  // centre petal
  g.moveTo(0,-12);g.bezierCurveTo(5,-7,5,-1,1.6,4);g.lineTo(-1.6,4);g.bezierCurveTo(-5,-1,-5,-7,0,-12);
  // side petals curling out and down
  for(const k of [-1,1]){g.moveTo(k*1.4,3);g.bezierCurveTo(k*4,-4,k*11,-6,k*11,0);g.bezierCurveTo(k*11,3,k*8,4,k*7,2);g.bezierCurveTo(k*8,0,k*6,-1,k*4.6,3.4);g.closePath()}
  // band and foot
  g.rect(-6,3.4,12,3.2);g.moveTo(-1.8,6.6);g.lineTo(1.8,6.6);g.lineTo(3.4,12);g.lineTo(0,10);g.lineTo(-3.4,12);g.closePath()};
 P();g.fillStyle=fill;g.fill();g.lineWidth=lw*24/s;g.strokeStyle=FKO;g.lineJoin='round';g.stroke();g.restore()}
/* small brass rivet */
function fa6_rivet(g,x,y,r){g.beginPath();g.arc(x,y,r,0,TAU);g.fillStyle=fa6_rgrad(g,x-r*.35,y-r*.4,0,r*1.1,[[0,'#fffbe0'],[.4,'#ffd34a'],[1,'#9a5a0a']]);g.fill();g.lineWidth=.9;g.strokeStyle='rgba(27,16,36,.85)';g.stroke()}
FISHART.knight=(g,t,o)=>{const fx=o.flex||0,gl=o.glow||0,sw=fkSway(o,3.2,.12),fin=Math.sin(t*4)*.08,pu=.5+.5*Math.sin(t*1.8);g.save();g.translate(2,8);g.rotate(-sw*.18);
 // heroic golden aura
 if(g.canvas!==FKSIL)fkGlow(g,10,-10,94,'#ffd88a',.12+.05*pu+gl*.5);if(gl>0)if(g.canvas!==FKSIL)fkGlow(g,30,-6,70,'#fff4d0',gl*.3);
 const BP=[107,4,102,-13,86,-30,58,-41,22,-43,-12,-37,-40,-24,-58,-13,-66,-10,-66,10,-58,13,-40,21,-12,31,22,35,56,33,86,25,102,14],B=()=>fkPath(g,BP);
 const steel=(y0,y1)=>fa6_grad(g,0,y0,0,y1,[[0,'#46557a'],[.16,'#9aaacc'],[.32,'#f4f8ff'],[.44,'#c4d0e6'],[.54,'#6a7a9e'],[.62,'#8e9cbc'],[.8,'#dce4f4'],[1,'#9aa6c4']]);
 const gold=(y0,y1)=>fa6_grad(g,0,y0,0,y1,[[0,'#fff4b0'],[.35,'#ffd040'],[.7,'#d88a10'],[1,'#8a4a06']]);
 const red=(y0,y1)=>fa6_grad(g,0,y0,0,y1,[[0,'#ff5a4e'],[.45,'#cc1a2e'],[1,'#68081c']]);
 // heater-shield tail: royal-blue field, silver cross, gold rim with rivets
 fa6_at(g,-57,0,sw*.45,()=>{const S=()=>fa6_path(g,['M',6,-6,'Q',-12,-14,-26,-28,'Q',-32,-34,-42,-35,'Q',-47,-35,-47,-30,'L',-47,30,'Q',-47,35,-42,35,'Q',-32,34,-26,28,'Q',-12,14,6,6,'Z']);
  S();fkFill(g,fa6_grad(g,0,-36,0,36,[[0,'#3a6af0'],[.5,'#1a3aa8'],[1,'#0e2070']]),2.6);
  g.save();S();g.clip();
  // fine damask diaper on the field
  g.strokeStyle='rgba(140,180,255,.22)';g.lineWidth=1;g.beginPath();for(let k=-60;k<60;k+=7){g.moveTo(-60,k);g.lineTo(10,k+40);g.moveTo(-60,k);g.lineTo(10,k-40)}g.stroke();
  // silver cross
  const C=()=>{g.beginPath();g.rect(-44,-4.4,44,8.8);g.rect(-34,-29,8.8,58)};C();g.fillStyle=steel(-30,30);g.fill();g.lineWidth=1.8;g.strokeStyle=FKO;g.stroke();
  g.fillStyle='rgba(255,255,255,.7)';g.fillRect(-44,-4.4,42,2.2);g.fillRect(-34,-29,2.4,58);
  // gold rim band
  S();g.strokeStyle=gold(-36,36);g.lineWidth=9;g.stroke();S();g.strokeStyle='rgba(120,60,6,.7)';g.lineWidth=11.5;g.globalAlpha=.25;g.stroke();g.globalAlpha=1;
  g.translate(-.8,-1);S();g.strokeStyle='rgba(255,250,220,.75)';g.lineWidth=1.4;g.stroke();g.translate(.8,1);
  // a moonlit sheen across the shield
  const sx=Math.sin(t*1.2)*20;g.fillStyle=fa6_grad(g,-40+sx,-36,-10+sx,36,[[0,'rgba(255,255,255,0)'],[.5,'rgba(255,255,255,.22)'],[1,'rgba(255,255,255,0)']]);g.fillRect(-60,-40,70,80);
  g.restore();
  {const bx=-29.6,R=7;if(gl>0)fkGlow(g,bx,0,18,'#ffe9a0',gl*.6);g.beginPath();g.arc(bx,0,R,0,TAU);fkFill(g,fa6_rgrad(g,bx-2,-2.4,0,R*1.1,[[0,'#fff8d0'],[.45,'#ffc830'],[1,'#8a4a06']]),1.8);g.beginPath();g.ellipse(bx-2,-2.6,2.4,1.4,-.5,0,TAU);g.fillStyle='#fff';g.fill();
   if(gl>0)fkSpark(g,bx-1.5,-2,2+4*gl*fa6_tw(t,7,3),'#ffffff',gl)}
  for(const [x,y] of [[-43,-30],[-43,30],[-43,0],[-30,-27],[-30,27],[-15,-17],[-15,17]])fa6_rivet(g,x,y,1.6);
  S();g.lineJoin='round';g.lineWidth=2.6;g.strokeStyle=FKO;g.stroke()});
 // rear soft dorsal: steel with a gold edge
 fa6_at(g,-24,-31,fin*.4,()=>{const pp=[10,4,7,-6,0,-12,-8,-14,-16,-13,-24,-11,-31,-6,-36,2,-32,10],P=()=>fkPath(g,pp);P();fkFill(g,steel(-14,8),2.3);
  fa6_ribs(g,P,0,8,[4,-10,-3,-13,-10,-14,-17,-13.5,-24,-11,-30,-6],.9,'#e8a820',1.3);g.save();P();g.clip();P();g.strokeStyle=gold(-14,4);g.lineWidth=4.4;g.stroke();g.restore();P();g.lineWidth=2.3;g.strokeStyle=FKO;g.stroke()});
 // anal fin: crimson with gold rays
 fa6_at(g,-30,22,-fin*.5,()=>{const pp=[12,-3,8,8,-4,15,-18,15,-26,8,-24,-3],P=()=>fkPath(g,pp);P();fkFill(g,red(-3,15),2.3);
  fa6_ribs(g,P,2,-3,[4,12,-6,15,-16,15,-23,8],.8,'#ffcf4a',1.2);fa6_finfx(g,P,2,-3,'#ffd0c0',null,.7,0);P();g.lineWidth=2.3;g.strokeStyle=FKO;g.stroke()});
 // the pennant: a gold lance (the first dorsal spine) flying a crimson swallow-tail banner with a gold fleur
 {const px=44,py=-40,top=-74,wv=t*3.2+fx*t*4;
  // short spiny membrane between the lance and the soft dorsal
  {const pp=[px+2,py+4,px,py-6,px-8,py-9,px-18,py-5,px-28,py-6,px-40,py+1,px-46,py+8],P=()=>fkPath(g,pp);P();fkFill(g,steel(py-10,py+6),2.2);
   fa6_ribs(g,P,px-20,py+10,[px-6,py-9,px-16,py-6,px-28,py-6,px-38,py],.4,'#2a3450',1.1)}
  const L=60,H0=top+40,H1=top+8,pt=(u,v)=>{const x=px-2-u*L,yb=(H1+u*7)+((H0-u*12)-(H1+u*7))*v,w=Math.sin(wv-u*4.2)*u*4.2+Math.sin(wv*1.7-u*7)*u*1.4;return [x,yb+w]};
  const F=()=>{g.beginPath();let p=pt(0,0);g.moveTo(p[0],p[1]);for(let i=1;i<=14;i++){p=pt(i/14,0);g.lineTo(p[0],p[1])}
   const tip=pt(1,0),notch=pt(.8,.5),tip2=pt(1,1);g.lineTo(tip[0],tip[1]);g.lineTo(notch[0],notch[1]);g.lineTo(tip2[0],tip2[1]);
   for(let i=14;i>=0;i--){p=pt(i/14,1);g.lineTo(p[0],p[1])}g.closePath()};
  F();g.lineJoin='round';fkFill(g,red(H1,H0),2.4);
  g.save();F();g.clip();
  // fold shading that travels with the wave
  for(let i=0;i<14;i++){const u=i/14,sl=Math.cos(wv-u*4.2);const a=pt(u,0),b=pt(u+1/14,1);g.fillStyle=sl>0?`rgba(255,200,190,${.2*sl})`:`rgba(60,0,20,${-.32*sl})`;g.fillRect(Math.min(a[0],b[0])-1,H1-14,L/14+2,H0-H1+28)}
  // gold trim along both edges
  g.lineCap='round';for(const v of [0,1]){g.beginPath();for(let i=0;i<=14;i++){const p=pt(i/14*.8,v);i?g.lineTo(p[0],p[1]+(v?-1.6:1.6)):g.moveTo(p[0],p[1]+(v?-1.6:1.6))}g.strokeStyle='#ffd040';g.lineWidth=2.4;g.stroke()}
  g.restore();F();g.lineWidth=2.4;g.strokeStyle=FKO;g.stroke();
  {const c=pt(.28,.42);fa6_fleur(g,c[0],c[1],17,gold(c[1]-8,c[1]+8),1.6)}
  // lance shaft and its silver spear tip
  g.lineCap='round';g.beginPath();g.moveTo(px,py+6);g.lineTo(px-1,top+6);g.strokeStyle=FKO;g.lineWidth=5.6;g.stroke();g.strokeStyle=fa6_grad(g,px-3,0,px+2,0,[[0,'#ffe680'],[.5,'#ffc020'],[1,'#a05a08']]);g.lineWidth=3;g.stroke();
  g.beginPath();g.moveTo(px-1,top-3);g.lineTo(px+3,top+5);g.lineTo(px-1,top+9);g.lineTo(px-5,top+5);g.closePath();fkFill(g,fa6_grad(g,px-5,0,px+3,0,[[0,'#ffffff'],[.5,'#c8d4ee'],[1,'#6a7ab0']]),1.8);
  fa6_rivet(g,px-1,top+11,2.2);
  const w=fa6_tw(t,1,2.2);fkSpark(g,px-1,top-3,2+2.2*w,'#fffbe0',.5+.5*w)}
 // body: mirror-polished steel
 B();fkFill(g,steel(-43,35),3);
 fa6_tex(g,B,-70,92,-40,34,6,'#3a4870','#ffffff',.16);
 fkShade(g,B,-10,-43,'#1a2648',.3);
 // riveted gold bands between the armour plates (each plate casts a soft shadow onto the next)
 g.save();B();g.clip();
 const seams=[52,26,0,-26,-48],sx=x=>y=>x+Math.pow(y/40,2)*-7;
 seams.forEach((x0,i)=>{const X=sx(x0);
  g.beginPath();for(let y=-46;y<=40;y+=4){const x=X(y)-2;y===-46?g.moveTo(x,y):g.lineTo(x,y)}g.lineTo(X(40)-16,40);g.lineTo(X(-46)-16,-46);g.closePath();
  g.fillStyle=fa6_grad(g,x0-2,0,x0-16,0,[[0,'rgba(20,28,60,.32)'],[1,'rgba(20,28,60,0)']]);g.fill();
  g.beginPath();for(let y=-46;y<=40;y+=4){const x=X(y);y===-46?g.moveTo(x,y):g.lineTo(x,y)}g.strokeStyle=FKO;g.lineWidth=6.4;g.stroke();g.strokeStyle=gold(-40,34);g.lineWidth=4;g.stroke();
  g.save();g.translate(-.9,0);g.strokeStyle='rgba(255,250,220,.7)';g.lineWidth=1;g.stroke();g.restore();
  for(let y=-34+(i%2)*5;y<32;y+=10)fa6_rivet(g,X(y),y,1.7)});
 // travelling glint across the plates
 {const gx=((t*44)%300)-140;g.fillStyle=fa6_grad(g,gx-18,-40,gx+18,40,[[0,'rgba(255,255,255,0)'],[.5,`rgba(255,255,255,${.35+gl*.35})`],[1,'rgba(255,255,255,0)']]);g.fillRect(-80,-50,200,100)}
 if(gl>0)seams.forEach((x0,i)=>{const X=sx(x0);for(let y=-34+(i%2)*5;y<32;y+=20){const w=fa6_tw(t,i*2.3+y*.3,4);fkSpark(g,X(y),y,1.5+3.5*w*gl,'#ffffff',gl*(.4+.6*w))}});
 g.restore();
 // the helm: a separate bright plate over the head, bordered by a gold gorget
 const HP=()=>{g.beginPath();g.arc(124,0,64,Math.PI*.72,Math.PI*1.28);g.lineTo(140,-60);g.lineTo(140,60);g.closePath()};
 g.save();B();g.clip();HP();g.clip();B();g.fillStyle=fa6_grad(g,60,-40,110,30,[[0,'#ffffff'],[.3,'#d4def0'],[.55,'#8a9ac0'],[.7,'#c8d4ea'],[1,'#7a88ac']]);g.fill();
 g.fillStyle=fa6_grad(g,0,-40,0,30,[[0,'rgba(30,40,80,.25)'],[.4,'rgba(30,40,80,0)'],[1,'rgba(30,40,80,.25)']]);g.fillRect(50,-50,70,100);
 g.restore();
 g.save();B();g.clip();g.beginPath();g.arc(124,0,64,Math.PI*.72,Math.PI*1.28);g.strokeStyle=FKO;g.lineWidth=7;g.stroke();g.strokeStyle=gold(-40,34);g.lineWidth=4.4;g.stroke();
 g.beginPath();g.arc(123,0,64,Math.PI*.74,Math.PI*1.26);g.strokeStyle='rgba(255,250,220,.7)';g.lineWidth=1.1;g.stroke();
 for(let k=0;k<5;k++){const a=Math.PI*(.79+k*.105);fa6_rivet(g,124+Math.cos(a)*64,Math.sin(a)*64,1.7)}g.restore();
 fa6_rim(g,B,'#ffffff','#d4e0ff',1,2);
 fa6_gloss(g,B,92,-27,52,-44,4,-41,3.2,.85);
 // visor ridge sweeping over the eye, pierced with breathing slits, pivoting on a rivet
 {// the visor plate over the front of the face, under the ridge
  const VP=()=>fa6_path(g,['M',91,-14.5,'Q',99.5,-13,103.8,-6,'Q',105.4,-1,103.2,3.6,'Q',97,2.6,90.5,-1.5,'Z']);
  VP();fkFill(g,fa6_grad(g,90,-14,104,4,[[0,'#eef2fb'],[.4,'#b4c0da'],[.7,'#7684a8'],[1,'#a8b4cc']]),2.2);
  g.save();VP();g.clip();g.beginPath();g.moveTo(91,-12.6);g.quadraticCurveTo(99,-11,103,-5);g.strokeStyle='rgba(255,255,255,.8)';g.lineWidth=1.2;g.stroke();
  // breathing slits: dark holes with a pale lower lip each
  g.lineCap='round';for(const [x,y] of [[93.6,-10.4],[96.8,-9],[99.9,-7.4],[102.4,-5]]){g.beginPath();g.moveTo(x+.3,y+5.6);g.lineTo(x+.3,y+.4);g.strokeStyle='rgba(255,255,255,.85)';g.lineWidth=2.2;g.stroke();
   g.beginPath();g.moveTo(x,y);g.lineTo(x,y+5);g.strokeStyle=FKO;g.lineWidth=2.3;g.stroke()}
  g.beginPath();g.moveTo(91,-1.6);g.quadraticCurveTo(97,2.4,103,3.4);g.strokeStyle='rgba(255,255,255,.75)';g.lineWidth=1.4;g.stroke();g.restore();
  // the eye ridge sweeping back over the eye, pivoting on a rivet
  const V=()=>fa6_path(g,['M',104.5,-9,'Q',90,-20,66,-23,'Q',64,-17.5,67,-15.5,'Q',88,-14,103.5,-3,'Z']);
  V();fkFill(g,fa6_grad(g,0,-24,0,-4,[[0,'#ffffff'],[.4,'#b8c4de'],[1,'#56648c']]),2.2);
  g.save();V();g.clip();g.beginPath();g.moveTo(103,-8);g.quadraticCurveTo(90,-18.5,67,-21.5);g.strokeStyle='rgba(255,255,255,.9)';g.lineWidth=1.3;g.stroke();g.restore();
  fa6_rivet(g,67.5,-19,2.6)}
 // crest: a steel comb along the top of the helm with a gold rim
 {const C=()=>fa6_path(g,['M',100,-12,'Q',96,-22,88,-30,'Q',78,-41,64,-47,'Q',56,-50,49,-49,'Q',52,-45,52,-40,'Q',68,-37,80,-28,'Q',90,-20,93,-11,'Z']);
  C();fkFill(g,steel(-50,-22),2.4);g.save();C();g.clip();C();g.strokeStyle=gold(-50,-22);g.lineWidth=4.2;g.stroke();g.restore();C();g.lineWidth=2.4;g.strokeStyle=FKO;g.stroke();
  const w=fa6_tw(t,3,2.6);fkSpark(g,52,-49,2.4+3.2*w,'#ffffff',.4+.6*w)}
 // pelvic: crimson
 fa6_at(g,46,31,-fin,()=>{const pp=[8,-3,6,6,-4,12,-14,9,-14,-3],P=()=>fkPath(g,pp);P();fkFill(g,red(-3,12),2.2);fa6_ribs(g,P,2,-3,[-2,11,-10,10,-13,4],.8,'#ffcf4a',1.1);P();g.lineWidth=2.2;g.strokeStyle=FKO;g.stroke()});
 // pectoral: a steel gauntlet-fan with gold ribs
 fa6_at(g,62,8,-.28+fin*1.2,()=>{const pp=[4,-5,-8,-9,-24,-8,-32,-2,-28,6,-16,9,-4,8,4,4],P=()=>fkPath(g,pp);P();fkFill(g,steel(-9,9),2.3);
  fa6_ribs(g,P,2,0,[-31,-3,-29,3,-22,7,-12,8.4],.9,'#e8a820',1.3);fa6_finfx(g,P,2,0,'#ffffff',null,.6,0);P();g.lineWidth=2.3;g.strokeStyle=FKO;g.stroke();fa6_rivet(g,1,0,2.1)});
 // brave eye under the visor
 fa6_eye(g,82,-8,10.5,'#2a6ae8',.4);fa6_lid(g,82,-8,10.5,Math.max(.2,fa6_blink(t,2.2)),'#9aa8c8');
 fa6_mouth(g,106,8,100,12.5,92,10.5,2.2,'#e88a9a');
 fa6_spec(g,30,-30,1,.95);fa6_spec(g,-14,-22,.7,.8);
 // gleaming star glints
 [[14,-36,0],[-40,-14,1],[78,14,2],[-6,24,3]].forEach(([x,y,i])=>{const w=fa6_tw(t,i*1.7,2.4);fkSpark(g,x,y,2+4*w*(1+gl*.7),'#ffffff',.25+.7*w+gl*.2)});
 g.restore()};

/* ---------------- 4. Emberwing Lionfish (Rare): cream and ember stripes, a crown of smouldering feather spines and huge fan pectorals tipped with pulsing embers ---------------- */
/* glowing ember: additive halo (one shared unit gradient, scaled) and a hot core */
function fa6_ember(g,G,x,y,r,k){g.save();g.globalCompositeOperation='lighter';g.translate(x,y);g.scale(r*3.2,r*3.2);g.globalAlpha=.55+.45*k;g.fillStyle=G;g.beginPath();g.arc(0,0,1,0,TAU);g.fill();g.restore();
 g.beginPath();g.arc(x,y,r,0,TAU);g.fillStyle=k>.5?'#fff2a8':'#ffc040';g.fill();g.beginPath();g.arc(x-r*.3,y-r*.3,r*.4,0,TAU);g.fillStyle='#ffffff';g.globalAlpha=.6+.4*k;g.fill();g.globalAlpha=1}
/* a smouldering feather from (x0,y0) along angle a, length L, max half-width w: coal core, glowing ember edges, barbs and an ember tip */
function fa6_feather(g,G,x0,y0,a,L,w,t,ph,bands){fa6_at(g,x0,y0,a,()=>{
 const V=()=>{g.beginPath();g.moveTo(0,0);g.bezierCurveTo(L*.25,-w*1.1,L*.75,-w*1.05,L,0);g.bezierCurveTo(L*.75,w*.9,L*.25,w,0,0);g.closePath()};
 V();g.fillStyle=fa6_grad(g,0,0,L,0,[[0,'#24060a'],[.35,'#5a0e0c'],[.7,'#a8200e'],[.92,'#ff6a1a'],[1,'#ffb040']]);g.fill();
 g.save();V();g.clip();
 // glowing cracked edges like a coal
 V();g.strokeStyle=fa6_grad(g,0,0,L,0,[[0,'rgba(255,90,20,.2)'],[.5,'rgba(255,110,30,.75)'],[1,'rgba(255,220,120,.95)']]);g.lineWidth=3;g.stroke();
 // barbs
 g.strokeStyle='rgba(20,4,6,.45)';g.lineWidth=.8;g.beginPath();for(let s=.12;s<.95;s+=.08){const x=L*s;g.moveTo(x,0);g.lineTo(x-w*.9,-w);g.moveTo(x,0);g.lineTo(x-w*.9,w)}g.stroke();
 // ember bands along the feather, slowly breathing
 if(bands)for(let b=0;b<bands;b++){const s=.42+b*.2,k=.5+.5*Math.sin(t*2.4+ph+b*1.3);g.fillStyle=`rgba(255,${120+80*k|0},40,${.35+.4*k})`;g.fillRect(L*s-1.4,-w,2.8,w*2)}
 g.restore();
 V();g.lineJoin='round';g.lineWidth=1.8;g.strokeStyle=FKO;g.stroke();
 // rachis
 g.beginPath();g.moveTo(0,0);g.lineTo(L*.98,0);g.strokeStyle='#ffd8a0';g.globalAlpha=.85;g.lineWidth=1;g.stroke();g.globalAlpha=1;
 fa6_ember(g,G,L,0,2.2+1.1*Math.sin(t*3+ph),.5+.5*Math.sin(t*3+ph))})}
FISHART.lion=(g,t,o)=>{const fx=o.flex||0,gl=o.glow||0,sw=fkSway(o,3,.12),pu=.5+.5*Math.sin(t*2.2);g.save();g.translate(3,1);g.rotate(-sw*.15);
 const G=g.createRadialGradient(0,0,0,0,0,1);G.addColorStop(0,'rgba(255,170,60,.85)');G.addColorStop(.4,'rgba(255,90,20,.35)');G.addColorStop(1,'rgba(255,60,10,0)');
 // smouldering heat aura
 if(g.canvas!==FKSIL)fkGlow(g,-4,-6,96,'#ff5a1a',.11+.06*pu+gl*.3);
 // heat shimmer rising off the spines
 // heat haze: faint warm amber wisps that fade at both ends
 g.save();g.lineCap='round';g.globalCompositeOperation='lighter';for(let i=0;i<4;i++){const x0=-34+i*26,p=(t*.4+i*.27)%1,y0=-46-p*7,y1=y0-27;g.beginPath();for(let k=0;k<=12;k++){const y=y0+(y1-y0)*k/12,x=x0+Math.sin(k*.8+t*2.6+i)*3;k?g.lineTo(x,y):g.moveTo(x,y)}
  const a=.13*(1-p*.5);g.strokeStyle=fa6_grad(g,0,y0,0,y1,[[0,'rgba(255,170,60,0)'],[.35,`rgba(255,180,80,${a})`],[.65,`rgba(255,150,50,${a*.8})`],[1,'rgba(255,120,40,0)']]);g.lineWidth=3.4;g.stroke()}g.restore();
 const BP=[104,6,99,-10,82,-24,52,-30,18,-28,-18,-21,-46,-12,-58,-9,-58,9,-46,12,-18,20,18,26,50,28,80,22,98,14],B=()=>fkPath(g,BP);
 const fanAng=(i,n,a0,a1,ph)=>a0+(a1-a0)*i/(n-1)+Math.sin(t*1.8+i*.45+ph)*.035*(1+fx*3);
 // far pectoral fan (behind the body): dimmer and tucked higher
 g.save();g.globalAlpha=.86;for(let i=0;i<7;i++)fa6_feather(g,G,40,4,fanAng(i,7,Math.PI*.98,Math.PI*.66,1),66-i*2.4,5,t,i*.7+2,0);g.restore();
 // tail: a round clear fan with rows of dark spots and ember rays
 fa6_at(g,-56,0,sw,()=>{const tp=[6,-6,-10,-14,-26,-24,-40,-26,-50,-16,-54,0,-50,16,-40,26,-26,24,-10,14,6,6],P=()=>fkPath(g,tp);
  P();g.fillStyle=fa6_grad(g,6,0,-54,0,[[0,'rgba(255,214,150,1)'],[.5,'rgba(255,140,60,.98)'],[1,'rgba(214,56,26,.96)']]);g.fill();
  fa6_ribs(g,P,4,0,[-40,-25,-48,-16,-53,-5,-53,5,-48,16,-40,25],.5,'#7a1a0a',1.3);
  g.save();P();g.clip();g.fillStyle='#5a0e0c';for(let r=0;r<4;r++)for(let k=-3;k<=3;k++){const a=k*.36,d=14+r*10;g.beginPath();g.arc(4-Math.cos(a)*d,Math.sin(a)*d*1.1,1.7,0,TAU);g.fill()}g.restore();
  fa6_finfx(g,P,4,0,'#ffe8c8',null,.7,0);P();g.lineWidth=2.4;g.strokeStyle=FKO;g.stroke()});
 // rear soft dorsal + anal: clear, spotted
 const soft=(pp,rx,ry,rays)=>{const P=()=>fkPath(g,pp);P();g.fillStyle=fa6_grad(g,rx,ry,pp[6],pp[7],[[0,'rgba(255,200,130,1)'],[1,'rgba(220,70,30,.96)']]);g.fill();
  fa6_ribs(g,P,rx,ry,rays,.45,'#7a1a0a',1.2);g.save();P();g.clip();g.fillStyle='#5a0e0c';for(let i=0;i<rays.length;i+=2)for(let k=1;k<4;k++){g.beginPath();g.arc(rx+(rays[i]-rx)*k/4,ry+(rays[i+1]-ry)*k/4,1.4,0,TAU);g.fill()}g.restore();
  fa6_finfx(g,P,rx,ry,'#ffe8c8',null,.7,0);P();g.lineWidth=2.3;g.strokeStyle=FKO;g.stroke()};
 soft([-16,-17,-22,-27,-32,-30,-42,-27,-50,-17,-52,-9,-40,-12],-30,-12,[-23,-27,-32,-29,-41,-26,-48,-17]);
 soft([-16,15,-22,24,-32,27,-42,24,-50,15,-52,7,-40,10],-30,12,[-23,24,-32,26,-41,23,-48,15]);
 // the crown: tall feather spines over a coal-red membrane
 {const n=12,SP=[];for(let i=0;i<n;i++){const k=i/(n-1),x=72-k*84,y=-26+Math.pow(k-.4,2)*10-(k<.4?(.4-k)*6:0),a=-Math.PI/2-.22-k*.62+Math.sin(t*2+i*.5)*.035*(1+fx*2),L=(37+18*Math.sin(Math.PI*Math.min(1,k*1.25+.1)))*(1-k*.2);SP.push([x,y,a,L])}
  const pt=(s,f)=>[s[0]+Math.cos(s[2])*s[3]*f,s[1]+Math.sin(s[2])*s[3]*f];
  // membrane between the spine bases
  g.beginPath();g.moveTo(SP[0][0]+6,SP[0][1]+6);for(let i=0;i<n;i++){const p=pt(SP[i],.42);if(i){const q=pt(SP[i-1],.42),m=pt(SP[i-1],.3),m2=pt(SP[i],.3);g.quadraticCurveTo((m[0]+m2[0])/2,(m[1]+m2[1])/2,p[0],p[1])}else g.lineTo(p[0],p[1])}g.lineTo(SP[n-1][0]-4,SP[n-1][1]+6);g.closePath();
  g.fillStyle=fa6_grad(g,0,-26,0,-50,[[0,'rgba(120,20,14,.9)'],[1,'rgba(255,90,30,.55)']]);g.fill();g.lineWidth=2;g.strokeStyle=FKO;g.stroke();
  for(let i=n-1;i>=0;i--){const s=SP[i];fa6_feather(g,G,s[0],s[1]+4,s[2],s[3]+4,4.2,t,i*.9,2)}}
 // body: cream with bold ember-orange bands
 B();fkFill(g,fa6_grad(g,0,-30,0,28,[[0,'#ffe2c0'],[.5,'#fff4e4'],[1,'#ffd8b8']]),3);
 g.save();B();g.clip();
 const band=(x0,w,c)=>{g.beginPath();for(let y=-34;y<=32;y+=4){const x=x0+Math.sin(y/14)*3+y*.22;y===-34?g.moveTo(x-w/2,y):g.lineTo(x-w/2,y)}for(let y=32;y>=-34;y-=4){const x=x0+Math.sin(y/14)*3+y*.22;g.lineTo(x+w/2,y)}g.closePath();g.fillStyle=c;g.fill();g.strokeStyle='rgba(70,10,8,.75)';g.lineWidth=1.4;g.stroke()};
 const ember=fa6_grad(g,0,-30,0,28,[[0,'#a01e0e'],[.35,'#ff5a14'],[.7,'#ff8a2a'],[1,'#d83a12']]);
 for(let i=0;i<10;i++){const x=-56+i*14.4;band(x,6,ember);band(x+7.2,1.3,'rgba(255,130,50,.55)')}
 // the dark coal bar slanting through the eye, from the top of the head down to the cheek
 {const xb=y=>81+(y+8)*.46+Math.sin(y/16)*1.5;g.beginPath();for(let y=-34;y<=32;y+=4){const x=xb(y);y===-34?g.moveTo(x-7.5,y):g.lineTo(x-7.5,y)}for(let y=32;y>=-34;y-=4)g.lineTo(xb(y)+7.5,y);g.closePath();
  g.fillStyle=fa6_grad(g,0,-30,0,28,[[0,'#1c0406'],[.5,'#3a0a0a'],[1,'#6a1810']]);g.fill();g.strokeStyle='rgba(255,130,50,.55)';g.lineWidth=2.6;g.stroke();g.strokeStyle='rgba(20,2,4,.9)';g.lineWidth=1.2;g.stroke()}
 // a slow ember glow travelling through the stripes
 {const gx=((t*30)%220)-100;g.globalCompositeOperation='lighter';g.fillStyle=fa6_grad(g,gx-22,0,gx+22,0,[[0,'rgba(255,120,30,0)'],[.5,`rgba(255,140,40,${.22+gl*.2})`],[1,'rgba(255,120,30,0)']]);g.fillRect(-80,-40,200,80);g.globalCompositeOperation='source-over'}
 g.restore();
 fa6_tex(g,B,-62,96,-28,26,5,'#7a2a10','#fffaf0',.1);
 fkShade(g,B,-6,-30,'#5a0a08',.28);
 fkShade(g,B,12,28,'#c84a2a',.22);
 fa6_rim(g,B,'#fff6e0','#ffc090',1,2);
 fa6_gloss(g,B,88,-19,56,-30,10,-27,2.6,.7);
 fa6_gill2(g,B,90,4,28,Math.PI*.72,Math.PI*1.27,'#5a0e0c',.6);
 fa6_spec(g,36,-22,.8,.9);
 // pelvic: a short ember feather pair
 fa6_feather(g,G,44,24,Math.PI*.62,26,4,t,4,0);fa6_feather(g,G,40,24,Math.PI*.7,22,3.6,t,5,0);
 // near pectoral fan: the great ember wing, membrane at its root, feathers flaring free beyond
 {const n=9,R=[];for(let i=0;i<n;i++){const a=fanAng(i,n,Math.PI*1.03,Math.PI*.5,0),L=(84-i*3.4)*(1+Math.sin(t*1.8+i*.45)*.015);R.push([a,L])}
  const rx=54,ry=12,pt=(i,f)=>[rx+Math.cos(R[i][0])*R[i][1]*f,ry+Math.sin(R[i][0])*R[i][1]*f];
  g.beginPath();g.moveTo(rx+4,ry-4);for(let i=0;i<n;i++){const p=pt(i,.66);if(i){const a=pt(i-1,.54),b=pt(i,.54);g.quadraticCurveTo((a[0]+b[0])/2,(a[1]+b[1])/2,p[0],p[1])}else g.lineTo(p[0],p[1])}g.lineTo(rx+4,ry+4);g.closePath();
  g.fillStyle=fa6_rgrad(g,rx,ry,4,48,[[0,'rgba(90,12,10,.95)'],[.7,'rgba(200,40,14,.75)'],[1,'rgba(255,110,30,.6)']]);g.fill();g.lineWidth=2;g.strokeStyle=FKO;g.stroke();
  for(let i=0;i<n;i++)fa6_feather(g,G,rx,ry,R[i][0],R[i][1],7.4,t,i*.8+1,3);
  // fin base: a small dark coal knuckle with an ember rim and glint
  const K=()=>{g.beginPath();g.ellipse(rx-1,ry,7,5.2,-.5,0,TAU)};K();fkFill(g,fa6_grad(g,rx-6,ry-5,rx+5,ry+5,[[0,'#6a1a12'],[.5,'#2a0a0a'],[1,'#140406']]),2);
  g.save();K();g.clip();K();g.strokeStyle='rgba(255,110,30,.6)';g.lineWidth=3;g.stroke();g.restore();
  fa6_ember(g,G,rx-3,ry-1.6,1.3,.5+.5*Math.sin(t*2.4))}
 // feathery brow tentacles over the eye and a little chin frond
 const frond=(x,y,a,L,ph)=>fa6_at(g,x,y,a+Math.sin(t*2.6+ph)*.08,()=>{g.lineCap='round';g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(L*.5,-2,L,1);g.strokeStyle=FKO;g.lineWidth=4.4;g.stroke();g.strokeStyle='#ff7a2a';g.lineWidth=2.4;g.stroke();
  for(let k=1;k<4;k++){const x=L*k/4;g.beginPath();g.moveTo(x,-.6);g.lineTo(x+2.6,-4.4);g.moveTo(x,.6);g.lineTo(x+2.6,3.6);g.strokeStyle='#ffb070';g.lineWidth=1.2;g.stroke()}
  fa6_ember(g,G,L,1,1.4,.5+.5*Math.sin(t*3+ph))});
 frond(79,-21,-1.95,12,0);frond(84,-20,-1.5,10,1.3);
 fa6_eye(g,81,-8,12,'#ff8a1a',.35);fa6_lid(g,81,-8,12,fa6_blink(t,1.9),'#e85a1a');
 fa6_blush(g,97,4,4.2,'#ff5a7a',.45);
 fa6_mouth(g,104,8,99,13,92,11,2.2,'#ff7a6a');
 // rising sparks
 for(let i=0;i<10;i++){const p=((t*.28+i/10)%1),x=-84+i*19+Math.sin(t*1.6+i*2)*6,y=40-p*116,k=1-Math.abs(p*2-1);if(y<-76)continue;fa6_ember(g,G,x,y,(1.1+(i%3)*.5)*k+.2,k*.9)}
 fa6_catch(g,o,'#ffb070',1.2);g.restore()};

/* ---------------- 5. Starfall Arowana (Legendary): a silver dragon in mirror-armour scales each holding a star, a glowing constellation, comet-tail fins and golden barbels ---------------- */
/* additive star glow from a shared unit gradient */
function fa6_sglow(g,G,x,y,r,a){if(a<=0)return;g.save();g.globalCompositeOperation='lighter';g.globalAlpha=Math.min(1,a);g.translate(x,y);g.scale(r,r);g.fillStyle=G;g.beginPath();g.arc(0,0,1,0,TAU);g.fill();g.restore()}
FISHART.arowana=(g,t,o)=>{const fx=o.flex||0,gl=o.glow||0,sw=fkSway(o,2.6,.1),pu=.5+.5*Math.sin(t*1.6),bend=Math.sin(t*2.6)*fx*.06;g.save();g.translate(-4,0);g.rotate(-sw*.14);g.scale(.94,.94);
 const SG=g.createRadialGradient(0,0,0,0,0,1);SG.addColorStop(0,'rgba(255,246,210,.95)');SG.addColorStop(.3,'rgba(255,214,120,.4)');SG.addColorStop(1,'rgba(255,200,100,0)');
 // golden-white aura
 g.save();g.translate(-4,0);g.scale(1,.62);if(g.canvas!==FKSIL)fkGlow(g,0,0,118,'#ffe6a8',.14+.06*pu+gl*.5);g.restore();
 if(g.canvas!==FKSIL)fkGlow(g,30,-4,70,'#fff6dc',.08+.04*pu+gl*.38);
 // a falling star streaking past in the distance every few seconds
 {const p=(t*.28)%1;if(p<.34){const q=p/.34,x=84-q*130,y=-66+q*46,a=Math.sin(q*Math.PI);g.save();g.lineCap='round';g.globalCompositeOperation='lighter';
   g.strokeStyle=fa6_grad(g,x,y,x+22,y-7,[[0,`rgba(255,246,210,${.9*a})`],[1,'rgba(255,220,150,0)']]);g.lineWidth=2.6;g.beginPath();g.moveTo(x,y);g.lineTo(x+22,y-7);g.stroke();g.restore();fkSpark(g,x,y,4+3*a,'#fffbe8',a)}}
 // orbiting star dust
 for(let i=0;i<14;i++){const a=t*.18+i/14*TAU,x=-4+Math.cos(a)*108,y=Math.sin(a)*66,w=fa6_tw(t,i*1.37,2.2);if(Math.abs(x)>104||Math.abs(y)>70)continue;
  if(i%3===0)fkSpark(g,x,y,2+3*w,i%2?'#fff3c0':'#ffffff',.35+.6*w);else{g.beginPath();g.arc(x,y,.8+.9*w,0,TAU);g.fillStyle='#fff6d8';g.globalAlpha=.3+.6*w;g.fill();g.globalAlpha=1}}
 const BP=[105,-13,95,-21,74,-26,44,-28,10,-28,-24,-27,-46,-23,-60,-15,-66,-11,-66,11,-58,18,-40,29,-14,33,18,31,50,26,76,17,94,3],B=()=>fkPath(g,BP);
 const gold=(x0,y0,x1,y1)=>fa6_grad(g,x0,y0,x1,y1,[[0,'#fff6c8'],[.4,'#ffd450'],[1,'#c07a10']]);
 // comet-tail fin: luminous gold root fading through white to a translucent tail, with streaks and star dust
 const comet=(pp,rx,ry,tx,ty,ph,sgn)=>{const P=()=>fa6_path(g,pp);
  P();g.fillStyle=fa6_grad(g,rx,ry,tx,ty,[[0,'rgba(255,200,70,1)'],[.22,'rgba(255,232,150,.97)'],[.45,'rgba(255,150,206,.85)'],[.7,'rgba(156,128,255,.6)'],[.9,'rgba(110,200,255,.3)'],[1,'rgba(110,200,255,.05)']]);g.fill();
  g.save();P();g.clip();g.lineCap='round';
  for(let k=0;k<7;k++){const f=k/6,sx=rx+(tx-rx)*.04,sy=ry+sgn*k*2.2;g.beginPath();g.moveTo(sx,sy);g.quadraticCurveTo((sx+tx)/2,(sy+ty)/2+sgn*(10-k*1.6),tx+4,ty+sgn*(k-3)*1.4);
   g.strokeStyle=k%2?'rgba(255,255,255,.55)':'rgba(255,214,120,.5)';g.lineWidth=k%2?1:1.6;g.stroke()}
  // a slow shimmer pulse running out along the fin
  const q=((t*.55+ph)%1),cx=rx+(tx-rx)*q,cy=ry+(ty-ry)*q;g.fillStyle=fa6_rgrad(g,cx,cy,0,22,[[0,'rgba(255,255,255,.55)'],[1,'rgba(255,255,255,0)']]);g.fillRect(cx-24,cy-24,48,48);
  g.restore();
  g.save();g.globalAlpha=.9;P();g.lineJoin='round';g.lineWidth=2.4;g.strokeStyle=fa6_grad(g,rx,ry,tx,ty,[[0,'rgba(27,16,36,1)'],[.6,'rgba(27,16,36,.7)'],[1,'rgba(27,16,36,.1)']]);g.stroke();g.restore();
  // dust trailing off the tip
  for(let i=0;i<7;i++){const p=((t*.5+i/7+ph)%1),x=tx+6-p*10+(rx-tx)*.12*(1-p)*(i%3)/2,y=ty+sgn*(p*6)+Math.sin(t*2+i)*2,a=(1-p);if(x<-103)continue;
   if(i%2)fkSpark(g,x,y,(1.6+(i%3)*.8)*a+.5,'#fff6d0',a*.9);else{g.beginPath();g.arc(x,y,1.2*a+.3,0,TAU);g.fillStyle='#fffbe8';g.globalAlpha=a;g.fill();g.globalAlpha=1}}};
 const dw=Math.sin(t*1.9)*3*(1+fx*.5),aw=Math.sin(t*1.9+.8)*3*(1+fx*.5);
 // layered comet streamers trailing behind the two great fins
 {const st=(x0,y0,c1x,c1y,c2x,c2y,x1,y1,w0,ph)=>{const wv=Math.sin(t*1.9+ph)*3*(1+fx*.6),wv2=Math.sin(t*1.9+ph+1.2)*2.4*(1+fx*.6);
   const q=fa6_grad(g,x0,y0,x1,y1,[[0,'rgba(255,200,80,1)'],[.35,'rgba(255,150,210,.9)'],[.7,'rgba(160,130,255,.7)'],[1,'rgba(120,210,255,.2)']]);
   g.save();g.globalAlpha=.92;fa6_strand(g,[x0,y0,c1x,c1y+wv2,c2x,c2y+wv,x1,y1+wv],w0,.6,q,1.8,'rgba(255,255,255,.35)');g.restore();
   const w=fa6_tw(t,ph*2,2.4);fkSpark(g,x1,y1+wv,2+2.6*w,'#fff6d8',.4+.5*w)};
  st(-26,-30,-46,-50,-70,-61,-100,-62,11,0);
  st(-20,34,-42,52,-68,61,-100,61,11,.7)}
 comet(['M',-10,-27,'C',-24,-44,-58,-52,-104,-48+dw,'C',-84,-40,-72,-30,-62,-14,'Z'],-24,-30,-103,-48+dw,0,-1);
 comet(['M',12,32,'C',-2,50,-50,62,-104,54+aw,'C',-84,46,-70,32,-58,17,'Z'],-6,34,-103,54+aw,.5,1);
 // tail: a golden diamond fan with silver rays
 fa6_at(g,-61,0,sw+bend,()=>{const tp=['M',6,-8,'Q',-11,-14,-26,-26,'Q',-36,-31,-41.5,-24,'Q',-45,-12,-43.5,0,'Q',-45,12,-41.5,24,'Q',-36,31,-26,26,'Q',-11,14,6,8,'Z'],P=()=>fa6_path(g,tp);
  P();fkFill(g,fa6_grad(g,4,0,-44,0,[[0,'#fff2c0'],[.28,'#ffd050'],[.55,'#ffb0d8'],[.8,'#a890ff'],[1,'#90d8ff']]),2.5);
  g.save();P();g.clip();g.lineCap='round';for(let k=-3;k<=3;k++){g.beginPath();g.moveTo(2,k*1.2);g.quadraticCurveTo(-24,k*6,-48,k*9.6);g.strokeStyle=k%2?'rgba(255,255,255,.5)':'rgba(255,200,90,.45)';g.lineWidth=k%2?1:1.5;g.stroke()}g.restore();
  fa6_ribs(g,P,4,0,[-38,-27,-43,-16,-44.5,-5,-44.5,5,-43,16,-38,27],.32,'#7a4a06',1.1);
  fa6_finfx(g,P,4,0,'#ffffff',[-41,-22,-44.5,-10,-44.5,10,-41,22],.9,0);
  g.save();P();g.clip();for(let i=0;i<5;i++){const w=fa6_tw(t,i*1.5,2.6);fkSpark(g,-16-i*6,(i%2?-1:1)*(6+i*3),1.6+2.2*w,'#ffffff',.4+.6*w)}g.restore();
  fa6_rim(g,P,'#ffffff',null,1,1.6);P();g.lineJoin='round';g.lineWidth=2.5;g.strokeStyle=FKO;g.stroke()});
 // body: night-navy back, mirror-silver flanks, pearly belly
 B();fkFill(g,fa6_grad(g,0,-29,0,31,[[0,'#14083c'],[.2,'#2c1a74'],[.38,'#5c54b8'],[.52,'#a8b0e8'],[.66,'#dcdcf8'],[.84,'#dcb8e0'],[1,'#a67cc0']]),3);
 // mirror-armour scales, laid tail to head so each overlaps the one behind; every scale cups a tiny star
 {const SC=g.createRadialGradient(-3,-3,0,0,0,10.5);SC.addColorStop(0,'rgba(255,255,255,.42)');SC.addColorStop(.5,'rgba(220,228,255,.12)');SC.addColorStop(.82,'rgba(40,50,140,.2)');SC.addColorStop(1,'rgba(20,24,90,.45)');
  g.save();B();g.clip();const rows=[-24,-11,2,15,28],S=[];
  for(let c=0;c<10;c++)for(let r=0;r<5;r++){const x=-60+c*15.4+(r%2?7.7:0),y=rows[r]+Math.sin(x/40)*1.5;if(x>72)continue;S.push([x,y,c,r])}
  for(const [x,y,c,r] of S){g.save();g.translate(x,y);g.beginPath();g.arc(0,0,10.5,0,TAU);g.fillStyle=SC;g.fill();g.fillStyle=['rgba(104,66,230,.46)','rgba(150,120,250,.32)','rgba(255,255,255,.26)','rgba(255,160,215,.36)','rgba(255,118,185,.46)'][r];g.fill()
   g.beginPath();g.arc(0,0,10.5,Math.PI*.55,Math.PI*1.45);g.strokeStyle='rgba(27,16,36,.9)';g.lineWidth=3;g.stroke();
   g.beginPath();g.arc(.6,0,10.2,Math.PI*.58,Math.PI*1.42);g.strokeStyle='#ffd040';g.lineWidth=1.6;g.stroke();
   g.beginPath();g.arc(1.4,0,9.6,Math.PI*.62,Math.PI*1.38);g.strokeStyle='rgba(255,250,220,.55)';g.lineWidth=.7;g.stroke();g.restore()}
  // iridescent wash sliding across the armour
  const sh=Math.sin(t*.9)*40;g.fillStyle=fa6_grad(g,-80+sh,-30,80+sh,30,[[0,'#ff9ad8'],[.25,'#ffe28a'],[.5,'#9ae8ff'],[.75,'#c8a8ff'],[1,'#ffb8d8']]);g.globalAlpha=.14;g.fillRect(-80,-35,190,70);g.globalAlpha=1;
  for(const [x,y,c,r] of S){const w=fa6_tw(t,c*1.3+r*2.1,1.7+(c%3)*.4);fkSpark(g,x-1,y,1.8+.7*w,'#fff4d8',.55+.45*w)}
  g.restore()}
 // deep indigo-violet back shade so the silver reads as metal
 fkShade(g,B,-4,-29,'#2a0c6a',.64);
 fkShade(g,B,16,31,'#b070b8',.32);
 // the constellation: a dragon of stars linked by threads of light along the flank
 {const C=[[58,-4],[40,-13],[22,-6],[4,-15],[-14,-5],[-32,-12],[-48,-3],[-60,-8]],k=.82+.18*Math.sin(t*1.4),bw=1+gl*.8;
  g.save();B();g.clip();g.lineCap='round';g.lineJoin='round';
  const line=()=>{g.beginPath();C.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.moveTo(22,-6);g.lineTo(14,6);g.moveTo(-14,-5);g.lineTo(-22,7)};
  line();g.strokeStyle=`rgba(30,90,190,${.6*k})`;g.lineWidth=5.6*bw;g.stroke();
  line();g.strokeStyle=`rgba(110,225,255,${.62*k+gl*.3})`;g.lineWidth=3*bw;g.stroke();
  line();g.strokeStyle=`rgba(236,255,255,${.95*k})`;g.lineWidth=1.4;g.stroke();
  // a spark of light travelling the thread
  {const L=C.length-1,q=(t*.35)%1*L,i=Math.floor(q),f=q-i,a=C[i],b2=C[i+1],x=a[0]+(b2[0]-a[0])*f,y=a[1]+(b2[1]-a[1])*f;fa6_sglow(g,SG,x,y,7+gl*4,.8);g.beginPath();g.arc(x,y,1.6,0,TAU);g.fillStyle='#ffffff';g.fill()}
  g.restore();
  C.concat([[14,6],[-22,7]]).forEach((p,i)=>{const w=fa6_tw(t,i*1.9,2.4),r=(i===0||i===3||i===6?4.8:3.6)*(1+gl*.35);fa6_sglow(g,SG,p[0],p[1],r*2+w*1.5+gl*2.5,.26+.16*w+gl*.2);
   fa6_star(g,p[0],p[1],r+1.3*w,'#ffd040',1.3);g.beginPath();g.arc(p[0]-r*.1,p[1]-r*.1,r*.3,0,TAU);g.fillStyle='#fffbe8';g.fill()})}
 fa6_rim(g,B,'#e4ecff','#fff0d0',1,2);
 fa6_sheen(g,B,t,36,'#ffffff',.22);
 fa6_gloss(g,B,90,-21,50,-30,-6,-29,3,.8);
 // head armour: a smooth gilded helm plate with a gold-edged gill cover
 g.save();B();g.clip();g.beginPath();g.arc(122,-2,54,Math.PI*.7,Math.PI*1.3);g.lineTo(140,-50);g.lineTo(140,50);g.closePath();g.clip();
 g.fillStyle=fa6_grad(g,70,-30,100,20,[[0,'rgba(255,255,255,.22)'],[.5,'rgba(220,226,255,.06)'],[1,'rgba(255,220,150,.18)']]);g.fillRect(60,-40,60,80);
 g.restore();
 // the steep dragon jaw: an oblique gold-lipped mouth line
 {const J=()=>fa6_path(g,['M',106,-14,'Q',97,-5,84,2,'Q',88,7,95,5,'Q',103,0,107.5,-10,'Z']);J();fkFill(g,fa6_grad(g,86,0,105,-10,[[0,'#cfc4ec'],[1,'#ffffff']]),2.2);
  g.save();g.lineCap='round';g.beginPath();g.moveTo(105,-13);g.quadraticCurveTo(96,-5.5,85,1.6);g.strokeStyle=FKO;g.lineWidth=2.6;g.stroke();g.beginPath();g.moveTo(104,-10.5);g.quadraticCurveTo(96,-3,88,3.2);g.strokeStyle=gold(86,1,104,-12);g.lineWidth=1.4;g.stroke();g.restore()}
 // two long dragon whiskers from the jaw tip: tapered, gently S-curved, thrusting forward and up, each ending in a star
 {const wk=(x0,y0,c1x,c1y,c2x,c2y,x1,y1,ph)=>{const s1=Math.sin(t*2.1+ph)*1.4*(1+fx*1.5),s2=Math.sin(t*2.1+ph+1.1)*2.2*(1+fx*1.5),ey=y1+s2;
   fa6_strand(g,[x0,y0,c1x,c1y+s1*.4,c2x,c2y+s2*.7,x1,ey],3.4,.9,gold(x0,y0,x1,y1),1.6);
   g.save();g.lineCap='round';g.beginPath();g.moveTo(x0+1,y0-1.2);g.bezierCurveTo(c1x,c1y+s1*.4-1.1,c2x,c2y+s2*.7-.8,x1,ey);g.strokeStyle='rgba(255,255,235,.6)';g.lineWidth=.8;g.stroke();g.restore();
   const w=fa6_tw(t,ph,2.6);fa6_sglow(g,SG,x1,ey,5+2*w+gl,.5+.3*w+gl*.3);fkSpark(g,x1,ey,2.2+1.2*w,'#fffbe8',.95)};
  wk(105,-10,112,-14,118.5,-23,116,-33,0);
  wk(104,-6,112,-5,119.5,-12,118,-23,1.4)}
 // pectoral: a slim golden blade tucked behind the gill, sweeping down and back
 fa6_at(g,64,21,.75+Math.sin(t*3)*.07*(1+fx),()=>{const pp=['M',3,-4,'C',-6,-7,-18,-6,-27,0,'C',-25,6,-16,10,-8,9,'C',-3,8,1,5,3,4,'Z'],P=()=>fa6_path(g,pp);
  g.globalAlpha=.9;P();fkFill(g,fa6_grad(g,0,-4,-27,4,[[0,'#fff4c8'],[.4,'#ffcc48'],[.75,'#ffa8d4'],[1,'#a890ff']]),2.1);g.globalAlpha=1;fa6_ribs(g,P,2,0,[-27,0,-24,5,-17,8.6,-10,8.6],.32,'#7a4a06',1);
  fa6_finfx(g,P,2,0,'#ffffff',null,.8,0);P();g.lineWidth=2.1;g.strokeStyle=FKO;g.stroke()});
 // pelvic: a small gold fan
 fa6_at(g,8,31,.3+Math.sin(t*3+1)*.06,()=>{const pp=['M',4,-3,'C',-2,2,-10,9,-18,11,'C',-14,4,-8,0,-3,-2,'Z'],P=()=>fa6_path(g,pp);P();fkFill(g,fa6_grad(g,0,-3,-18,11,[[0,'#fff0b0'],[.6,'#ffc840'],[1,'rgba(160,214,255,.8)']]),2);fa6_ribs(g,P,1,-2,[-17,10,-12,8,-8,4],.3,'#7a4a06',1)});
 // gilded gill-cover plate: an engraved gold crescent behind the eye with a mirror sheen, rimmed in dark and gold
 {const GP=()=>{g.beginPath();g.arc(122,-2,54,Math.PI*.72,Math.PI*1.28);g.arc(122,-2,43.5,Math.PI*1.27,Math.PI*.73,true);g.closePath()};
  g.save();B();g.clip();GP();g.fillStyle=fa6_grad(g,66,-30,82,30,[[0,'#fff2b8'],[.3,'#ffd24a'],[.62,'#e09a18'],[1,'#8a5208']]);g.fill();
  g.save();GP();g.clip();
  // engraving: concentric grooves with catch-lights, a row of ticks, a scroll curl
  for(let k=0;k<2;k++){g.beginPath();g.arc(122,-2,47+k*3.6,Math.PI*.74,Math.PI*1.26);g.strokeStyle='rgba(90,40,4,.6)';g.lineWidth=1;g.stroke();g.beginPath();g.arc(122,-2,47.8+k*3.6,Math.PI*.74,Math.PI*1.26);g.strokeStyle='rgba(255,250,220,.55)';g.lineWidth=.7;g.stroke()}
  g.strokeStyle='rgba(90,40,4,.55)';g.lineWidth=1;g.beginPath();for(let k=0;k<11;k++){const a=Math.PI*(.78+k*.044);g.moveTo(122+Math.cos(a)*44.5,-2+Math.sin(a)*44.5);g.lineTo(122+Math.cos(a)*46.5,-2+Math.sin(a)*46.5)}g.stroke();
  g.beginPath();g.arc(73,9,3.2,Math.PI*.1,Math.PI*1.85);g.strokeStyle='rgba(90,40,4,.6)';g.lineWidth=1.1;g.stroke();
  // mirror sheen sliding over the gold
  const sx=Math.sin(t*1.1)*5;g.fillStyle=fa6_grad(g,62+sx,-22,80+sx,14,[[0,'rgba(255,255,255,0)'],[.42,'rgba(255,255,255,.7)'],[.58,'rgba(255,255,255,.7)'],[1,'rgba(255,255,255,0)']]);g.fillRect(50,-50,60,100);
  g.restore();
  GP();g.lineJoin='round';g.strokeStyle=FKO;g.lineWidth=2.4;g.stroke();
  g.beginPath();g.arc(122,-2,52.6,Math.PI*.74,Math.PI*1.26);g.strokeStyle='rgba(255,250,210,.75)';g.lineWidth=1;g.stroke();
  g.restore()}
 // dragon-brow ridge: a swept gold flame-spike over the eye, with a smaller one behind
 {const sp=(pp,x0,y0,x1,y1)=>{const P=()=>fa6_path(g,pp);P();fkFill(g,fa6_grad(g,x0,y0,x1,y1,[[0,'#fff4c0'],[.4,'#ffd040'],[1,'#b8700c']]),2.2);
   g.save();P();g.clip();g.translate(.8,1.6);P();g.strokeStyle='rgba(255,255,235,.75)';g.lineWidth=1.2;g.stroke();g.restore()};
  sp(['M',79,-24.5,'Q',71,-29,58,-33,'Q',67,-28.5,71,-25.5,'Z'],58,-33,79,-24);
  sp(['M',96,-20.5,'Q',85,-32,65,-41,'Q',74,-31,80,-24.5,'Z'],65,-41,96,-20);
  const w=fa6_tw(t,4,2.4);fkSpark(g,65,-41,2.4+2.6*w+gl*2,'#fffbe8',.6+.4*w)}
 // wise golden eye with a starlit glint
 fa6_eye(g,87,-13,9.4,'#e8a020',.4);fa6_lid(g,87,-13,9.4,Math.max(.12,fa6_blink(t,2.7)),'#5a6ab8');
 fkSpark(g,90.5,-16.5,2+1.3*pu,'#ffffff',.9);
 fa6_spec(g,40,-22,1,.95);
 // grand twinkles around the body
 [[100,-40,5],[-30,-60,4],[50,44,4],[-88,0,3.4],[10,-48,3.2]].forEach(([x,y,r],i)=>{const k=fa6_tw(t,i*1.9,2.1);fkSpark(g,x,y+Math.sin(t*1.2+i)*2,r*(.6+.6*k)*(1+gl*.5),i%2?'#fff3c0':'#ffffff',.35+.6*k)});
 g.restore()};

/* update 7: when drawn as an undiscovered silhouette (o.sil), these fish skip additive light (auras, glows, rays), so the
   journal shows a clean solid outline instead of a hazy blob. Normal drawing is untouched. */
(()=>{const P=new WeakMap(),wrap=c=>{let p=P.get(c);if(!p){const F=new Map();p=new Proxy(c,{get(t,k){const v=t[k];if(typeof v!=='function')return v;let f=F.get(k);
  if(!f){f=(k==='fill'||k==='fillRect'||k==='stroke'||k==='strokeRect'||k==='drawImage')?function(){if(t.globalCompositeOperation==='lighter')return;return v.apply(t,arguments)}:v.bind(t);F.set(k,f)}return f},
  set(t,k,v){t[k]=v;return true}});P.set(c,p)}return p};
 ['honey','skipper','knight','lion','arowana'].forEach(id=>{const f=FISHART[id];if(f)FISHART[id]=(g,t,o)=>f(typeof FKSIL!=='undefined'&&FKSIL&&g.canvas===FKSIL?wrap(g):g,t,o)})})();
