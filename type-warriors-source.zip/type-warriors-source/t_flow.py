import asyncio,os
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append('PE '+str(e)[:300]))
        await pg.goto('file://'+os.path.abspath('out.html'));await pg.wait_for_timeout(900);E=pg.evaluate
        await E("()=>{RS_ASK=false;title();P.petSt=2;P.pets={antler:{b:560,acc:1},bramble:{b:120}};P.pet='antler';P.eggs={r:0,l:0};P.trail={n:4,c:0};P.trSeen=4;P.gold=3000;petNorm();PTX.sel='antler';petHall('Pets')}");await pg.wait_for_timeout(700)
        await pg.click('.ptlink');await pg.wait_for_timeout(600)
        print('open',await E("()=>[!!document.getElementById('ptat'),document.getElementById('patsave').disabled,document.activeElement&&document.activeElement.className]"))
        # preview locked trim
        await pg.click('[data-pv="trim"]');await pg.wait_for_timeout(300)
        print('preview',await E("()=>[document.getElementById('patpv').className,document.getElementById('patsave').disabled,document.getElementById('patmsg').textContent,P.pets.antler.trim]"))
        await pg.screenshot(path='shots/fl_preview.png')
        await pg.keyboard.press('Escape');await pg.wait_for_timeout(200)
        print('esc exits preview',await E("()=>[!!document.getElementById('ptat'),document.getElementById('patpv').className]"))
        # select owned palette (unlocked at bond 6) and type a nickname
        await pg.click('[data-o="pal:1"]');await pg.focus('#patnk');await pg.keyboard.type('Fern');await pg.wait_for_timeout(200)
        print('dirty',await E("()=>[document.getElementById('patsave').disabled,document.getElementById('patmsg').textContent,S.mode,P.pets.antler.pal]"))
        # tab focus trap
        for i in range(60): await pg.keyboard.press('Tab')
        print('focus inside',await E("()=>!!document.activeElement.closest('#ptat')"))
        await pg.click('#patcc');await pg.wait_for_timeout(400)
        print('cancel discards',await E("()=>[!!document.getElementById('ptat'),P.pets.antler.pal,P.pets.antler.nk]"))
        await pg.click('.ptlink');await pg.wait_for_timeout(500);await pg.click('[data-o="pal:1"]');await pg.click('[data-o="cel:1"]');await pg.wait_for_timeout(150)
        print('locked cel click previews',await E("()=>[P.pets.antler.cel,document.getElementById('patsave').disabled]"))
        await pg.wait_for_timeout(2200);await pg.fill('#patnk','Fern');await pg.click('#patsave');await pg.wait_for_timeout(500)
        print('saved',await E("()=>JSON.stringify(P.pets.antler)"))
        # eggs
        await E("()=>petHall('Eggs')");await pg.wait_for_timeout(700)
        print('zero eggs',await E("()=>[!!document.getElementById('phxht'),document.querySelector('.phx-hatch').disabled,document.querySelector('.phx-why')&&document.querySelector('.phx-why').textContent]"))
        await pg.click('#phxby');await pg.wait_for_timeout(150);print('armed',await E("()=>[document.getElementById('phxby').textContent,P.gold,P.eggs.r]"))
        await pg.click('#phxby');await pg.wait_for_timeout(500);print('bought',await E("()=>[P.gold,P.eggs.r,document.getElementById('phxby').textContent]"))
        await pg.click('[data-egg="l"]');await pg.wait_for_timeout(500);print('legendary view',await E("()=>[document.querySelector('.phx-tt h3').textContent,document.querySelector('.phx-pool p').textContent,document.getElementById('phxby').textContent,P.eggs]"))
        await pg.screenshot(path='shots/fl_eggs_l.png')
        await pg.click('[data-egg="r"]');await pg.wait_for_timeout(500)
        await pg.click('#phxht');await pg.wait_for_timeout(200);await pg.click('#ptsk');await pg.wait_for_timeout(400);print('hatched',await E("()=>[Object.keys(P.pets).length,P.eggs.r,P.petPend]"))
        await pg.click('#ptrvq');await pg.wait_for_timeout(500)
        # complete rarity conversion
        await E("()=>{petList('r').forEach(id=>{if(!P.pets[id])P.pets[id]={b:0}});P.eggs.r=1;petNorm();PTX.egg='r';petHall('Eggs')}");await pg.wait_for_timeout(600)
        print('full',await E("()=>[document.querySelector('.phx-pool p').textContent,!!document.getElementById('phxcv2'),document.getElementById('phxby').textContent]"))
        await pg.click('#phxcv2');await pg.wait_for_timeout(300);b0=await E("()=>P.pets.bramble.b");await pg.click('[data-cs="bramble"]');await pg.click('#ptcy');await pg.wait_for_timeout(400)
        print('converted',b0,await E("()=>[P.pets.bramble.b,P.eggs.r]"))
        # trail animation 4 -> 5
        await E("()=>{P.trSeen=4;petStamp('camp');petHall('Trail')}");await pg.wait_for_timeout(500);await pg.screenshot(path='shots/fl_trail_anim.png');await pg.wait_for_timeout(1500)
        print('trail',await E("()=>[P.trail.n,P.trSeen,document.querySelector('.pat-left')&&document.querySelector('.pat-left').textContent,document.querySelector('.pat-ni small').textContent]"))
        await E("()=>petHall('Trail')");await pg.wait_for_timeout(300);print('reopen no anim seen',await E("()=>P.trSeen"))
        for n in [0,9,14,19]:
            await E(f"()=>{{P.trail={{n:{n},c:0}};P.trSeen={n};petHall('Trail')}}");await pg.wait_for_timeout(250)
            print(n,await E("()=>[document.querySelector('.pat-en').textContent,document.querySelector('.pat-left').textContent,document.querySelector('.pat-ni small').textContent]"))
        await pg.screenshot(path='shots/fl_trail19.png')
        await pg.click('[data-act="endless"]');await pg.wait_for_timeout(600);print('endless nav',await E("()=>document.querySelector('h2')&&document.querySelector('h2').textContent"))
        await E("()=>petHall('Trail')");await pg.wait_for_timeout(300);await pg.click('[data-act="arena"]');await pg.wait_for_timeout(600);print('arena nav',await E("()=>(document.querySelector('h2')||{}).textContent"))
        await E("()=>petHall('Trail')");await pg.wait_for_timeout(300);await pg.click('[data-act="camp"]');await pg.wait_for_timeout(600);print('camp nav',await E("()=>S.view"))
        print(er[:6]);await b.close()
asyncio.run(main())
