/* ===== RUNESTONE RAMPARTS (8.8b): HUD, tutorials, hub, result and hooks =====
   The in-run HUD is a DOM layer (#rphud, 1600x900 inside #wrap, pointer-events only on its controls) floating over the full-screen map:
   top row (map plaque, Health / Supply / Coins chips, help, speed, pause), boss bar, toast, "new monster" card (top right, clear of the
   pads), first-time tutorial bubbles, and a bottom row: abilities with cooldown shades (left), the tower bar (centre), the next-wave
   preview and the Start-wave button (right). The tower panel and the pad build ring are built once per selection and only patched
   afterwards (no re-rendering under the pointer). Menus (hub, pause, victory, result) use show() like every other mode. */
const RPI={
 heart:'<svg viewBox="0 0 24 24"><path d="M12 21s-8-5.2-8-11.2C4 6.6 6.4 4.5 9 4.5c1.4 0 2.4.7 3 1.6.6-.9 1.6-1.6 3-1.6 2.6 0 5 2.1 5 5.3C20 15.8 12 21 12 21z" fill="#ff5a6a" stroke="#12081f" stroke-width="1.6" stroke-linejoin="round"/><path d="M7.4 8.2c.4-1 1.2-1.5 2-1.5" stroke="#ffd0d6" stroke-width="1.5" stroke-linecap="round" fill="none"/></svg>',
 coin:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" fill="#ffc83a" stroke="#12081f" stroke-width="1.6"/><circle cx="12" cy="12" r="6" fill="none" stroke="#c88a10" stroke-width="1.4"/><path d="M8.5 9.5a4.5 4.5 0 0 1 4-3" stroke="#fff4c8" stroke-width="1.4" stroke-linecap="round" fill="none"/></svg>',
 keep:'<svg viewBox="0 0 24 24"><path d="M4 21V8h3V5h2v3h2V5h2v3h2V5h2v3h3v13h-6v-5h-4v5z" fill="#ffd45a" stroke="#12081f" stroke-width="1.6" stroke-linejoin="round"/></svg>',
 sup:'<svg viewBox="0 0 24 24"><path d="M12 2l9 5v10l-9 5-9-5V7z" fill="#e0a85a" stroke="#12081f" stroke-width="1.6" stroke-linejoin="round"/><path d="M3 7l9 5 9-5M12 12v10" fill="none" stroke="#12081f" stroke-width="1.6"/><path d="M7.5 4.6l9 5" stroke="#fff4c8" stroke-width="1.4" opacity=".6"/></svg>',
 over:'<svg viewBox="0 0 24 24"><path d="M13 2L4 14h7l-1 8 9-12h-7z" fill="#ffd45a" stroke="#12081f" stroke-width="1.6" stroke-linejoin="round"/></svg>',
 slow:'<svg viewBox="0 0 24 24"><g stroke="#9fe8ff" stroke-width="2.2" stroke-linecap="round"><path d="M12 2v20M3.3 7l17.4 10M3.3 17L20.7 7"/><path d="M9.5 3.5L12 6l2.5-2.5M9.5 20.5L12 18l2.5 2.5" fill="none"/></g></svg>',
 repair:'<svg viewBox="0 0 24 24"><path d="M12 2l8 3v6c0 5-3.4 9-8 11-4.6-2-8-6-8-11V5z" fill="#7dffb0" stroke="#12081f" stroke-width="1.6" stroke-linejoin="round"/><path d="M12 8v8M8 12h8" stroke="#12081f" stroke-width="2.4" stroke-linecap="round"/></svg>',
 play:'<svg viewBox="0 0 24 24"><path d="M7 4l13 8-13 8z" fill="#3a1a04" stroke="#3a1a04" stroke-width="1.5" stroke-linejoin="round"/></svg>',
 lock:'<svg viewBox="0 0 24 24"><path d="M7 11V8a5 5 0 0 1 10 0v3" fill="none" stroke="#12081f" stroke-width="4"/><path d="M7 11V8a5 5 0 0 1 10 0v3" fill="none" stroke="#e8e0ff" stroke-width="2"/><rect x="4.5" y="10.5" width="15" height="11" rx="2.5" fill="#ffd45a" stroke="#12081f" stroke-width="1.6"/><circle cx="12" cy="15.5" r="1.8" fill="#12081f"/></svg>',
 star:(on,s)=>`<svg viewBox="0 0 24 24" width="${s||22}" height="${s||22}"><path d="M12 2l3 6.6 7.2.8-5.4 4.9 1.5 7.1L12 17.8l-6.3 3.6 1.5-7.1L1.8 9.4 9 8.6z" fill="${on?'#ffd45a':'#2a2050'}" stroke="${on?'#7a4a0a':'#5a4ca0'}" stroke-width="1.6" stroke-linejoin="round"/>${on?'<path d="M9.6 9.2L12 4.4" stroke="#fff6c0" stroke-width="1.4" stroke-linecap="round"/>':''}</svg>`};
let RPH=null;/* cached HUD state */
const rpIconURL={};
function rpIconCanvas(type,tier,skin,size){try{const k=type+tier+skin+size;if(!rpIconURL[k])rpIconURL[k]=rpTowerIcon(type,tier,skin,size).toDataURL();return rpIconURL[k]}catch(e){return''}}
function rpMobURL(id,size,v){const k='m'+id+size+(v||'moss');if(!rpIconURL[k])try{rpIconURL[k]=rpMobIcon(id,size,v||'moss').toDataURL()}catch(e){rpIconURL[k]=''}return rpIconURL[k]}
const RP_KEYS=['Q','W','E','R','T'];
function rpHudOn(){const R=RPX;if(!R)return;let h=$('rphud');if(!h){h=document.createElement('div');h.id='rphud';wrap.appendChild(h)}h.className='rph'+(R.rm?' rprm':'');h.hidden=false;
 const ab=k=>{const A=RPT.AB[k];return `<button class="rpab" data-ab="${k}" aria-label="${A.n}"><span class="rpabi">${RPI[k]}</span><i class="rpcdf"></i><b class="rpcdn"></b><kbd>${A.key}</kbd><em>${A.n}</em><span class="rptip"><b>${A.n} · ${A.key}</b>${A.desc} Recharges in ${A.cd} s.</span></button>`};
 const card=(t,i)=>{const T=RP_TW[t],TW=RPTW[t];return `<button class="rpcard" data-tw="${t}" style="--c:${TW.col}" aria-label="${TW.n}, ${T.cost[0]} supply"><img alt="" src="${rpIconCanvas(t,1,rpSkinOf(t),96)}"><span class="rpct"><b>${TW.n}</b><span class="rpcost">${RPI.sup}<b>${T.cost[0]}</b></span></span><kbd>${RP_KEYS[i]}</kbd><span class="rptip"><b>${TW.n}</b>${T.desc}</span></button>`};
 h.innerHTML=`<div class="rpplq${R.map.endless?' rpend':''}"><b>${esc(R.map.n)}</b><small id="rpwv">${R.map.endless?'Endless':`Wave 0 / ${R.map.waves}`}</small></div>
  <div class="rpchips"><span class="rpchip rphp" id="rpck">${RPI.heart}<span>Health</span><b id="rpckv">20 / 20</b><em class="rpkb"><i id="rpckb"></i></em></span><span class="rpchip" id="rpcs">${RPI.sup}<span>Supply</span><b id="rpcsv">0</b></span><span class="rpchip rpcoin" id="rpcc">${RPI.coin}<span>Coins</span><b id="rpccv">0</b></span></div>
  <div class="rptr"><button class="rpsq" id="rphelp" title="How to play">?</button><button class="rpsq" id="rpspd" title="Game speed (F)">1×</button><button class="rpsq" id="rppau" title="Pause (Esc)"><svg viewBox="0 0 24 24"><path d="M7 5h4v14H7zM13 5h4v14h-4z" fill="currentColor"/></svg></button></div>
  <div class="rpboss" id="rpboss" hidden><img alt="" src="${rpMobURL('behemoth',64,R.map.pal)}"><span><b>${esc(rpName('behemoth',R))}</b><em><i id="rpbossf"></i></em></span></div>
  <div class="rptoast" id="rptoast" hidden></div>
  <div class="rpfoe" id="rpfoe" hidden></div>
  <div class="rptut" id="rptut" hidden></div>
  <div class="rpinfo" id="rpinfo" hidden></div>
  <div class="rpring" id="rpring" hidden></div>
  <div class="rpabs">${ab('over')}${ab('slow')}${ab('repair')}</div>
  <div class="rpbar">${RP_TWORDER.map(card).join('')}</div>
  <div class="rpnext" id="rpnext" hidden></div>
  <button class="rpgo" id="rpgo"><span class="rpgoi">${RPI.play}</span><span class="rpgot"><b id="rpgob">Start wave 1</b><small id="rpgos">Space</small></span></button>`;
 RPH={};
 h.addEventListener('mousedown',e=>{if(e.target.closest('button'))e.preventDefault()});
 h.querySelector('#rpgo').onclick=()=>{if(R.wst==='build')rpWaveStart()};
 h.querySelector('#rpspd').onclick=()=>rpSpeed();h.querySelector('#rppau').onclick=()=>rpPause(true);h.querySelector('#rphelp').onclick=()=>rpPause(true);
 h.querySelectorAll('.rpab').forEach(b=>b.onclick=()=>rpAbPress(b.dataset.ab));
 h.querySelectorAll('.rpcard').forEach(b=>b.onclick=()=>rpPlace(b.dataset.tw));
 rpHudTick(true);pb.style.display='none';try{$('cn').classList.add('dkhid')}catch(e){}
 if(R.tut)rpTutShow(R.tut)}
function rpHudOff(){const h=$('rphud');if(h){h.hidden=true;h.innerHTML=''}RPH=null}
function rpHudFoeCard(id){const R=RPX,el=$('rpfoe');if(!R||!el||!RPMOB[id])return;const v=R.map.pal,r=RPP();r.hint[v+':'+id]=1;
 el.innerHTML=`<img alt="" src="${rpMobURL(id,96,v)}"><span><small>NEW MONSTER</small><b>${esc(rpName(id,R))}</b><em>${esc(RP_FOETIP[id]||'')}</em></span>`;el.hidden=false;el.classList.remove('in');void el.offsetWidth;el.classList.add('in');
 clearTimeout(rpHudFoeCard.t);rpHudFoeCard.t=setTimeout(()=>{if(el.isConnected)el.hidden=true},7000);el.onclick=()=>{el.hidden=true}}
/* ---------- first-time tutorials: one bubble at a time; some pause the battle until "Got it" ---------- */
const RP_TUT={
 build:{t:'Build your first tower',p:'Pick a tower in the bar below (or press Q, W, E, R, T), then click a glowing stone pad. You can also click a pad first and choose from the ring. Towers fire on their own.',at:'bar',until:R=>R.built>0},
 wave:{t:'Start the wave',p:'Press Start wave (or Space) when you are ready. Monsters follow the road to your castle; each one that gets through costs health.',at:'go',until:R=>R.wave>0},
 coins:{t:'Supply and coins',p:'Every monster you defeat drops supply, which builds and upgrades towers in this battle, and coins, which are yours to keep. Clearing a wave pays both.',at:'top',pause:1},
 upgrade:{t:'Upgrade between waves',p:'Click a tower to see its range, upgrade it (it grows grander at every tier) or sell it. The next wave starts by itself; calling it early pays bonus supply.',at:'mid'},
 abil:{t:'Abilities',p:'Bottom left: Overcharge (1) makes one tower fire much faster, Slow Field (2) freezes a stretch of road, Repair (3) restores castle health. Each one recharges on its own.',at:'abil',pause:1},
 twist:{t:'',p:'',at:'mid'}};
function rpTut(id){const R=RPX;if(!R||!id||!RP_TUT[id])return;const r=RPP(),key=id==='twist'?'twist_'+R.map.id:id;if(r.tut[key])return;
 if(R.tut){R.tutQ=R.tutQ||[];if(!R.tutQ.includes(id))R.tutQ.push(id);return}R.tut=id;if(RP_TUT[id].pause&&R.wst==='run')R.hold=true;rpTutShow(id)}
function rpTutShow(id){const R=RPX,el=$('rptut');if(!R||!el)return;const T=RP_TUT[id];let t=T.t,p=T.p;
 if(id==='twist'){t=R.map.n;p=R.map.twist+(R.map.ice?' Guard the icy stretches well.':R.map.vents?' Build so both forks are covered.':'')}
 el.className='rptut at-'+T.at;el.innerHTML=`<small>${id==='twist'?'THIS MAP':'TIP'}</small><b>${esc(t)}</b><p>${esc(p)}</p><button id="rptok">Got it</button>`;el.hidden=false;
 $('rptok').onclick=()=>rpTutDone(id)}
function rpTutDone(id){const R=RPX;if(!R||R.tut!==id)return;const r=RPP();r.tut[id==='twist'?'twist_'+R.map.id:id]=1;try{save()}catch(e){}R.tut=null;R.hold=false;const el=$('rptut');if(el)el.hidden=true;
 const nx=R.tutQ&&R.tutQ.shift();if(nx)setTimeout(()=>{if(RPX===R)rpTut(nx)},350);
 if(id==='build'&&R.map.id!=='moss')setTimeout(()=>{if(RPX===R)rpTut('twist')},400)}
/* ---------- the victory choice ---------- */
function rpHudVictory(){const R=RPX;if(!R)return;const k=R.winHp,st=rpStarsFor(k);rpHudOff();
 const win=rpWinCoins(R.map,st);
 show(`<div class="rpvic"><h2>Victory!</h2><div class="rpvst">${[0,1,2].map(i=>`<span style="--d:${i*.18}s">${RPI.star(i<st,58)}</span>`).join('')}</div><p>${esc(R.map.n)} is safe. The castle stands at ${k} / ${RPT.HP} health.</p>
  <p class="rpvc">${RPI.coin}<span><b>${Math.floor(R.coins).toLocaleString()}</b> coins earned so far · victory bonus <b>${win.toLocaleString()}</b></span></p>
  <div class="rpvch"><button id="rpv1">Claim rewards</button><button class="sm" id="rpv2">Keep defending: Freeplay</button></div><small>Freeplay: endless, harder waves. Every monster and every wave keeps paying coins with no limit; you collect it all when you stop or the castle falls.</small></div>`,'rpx rpvx');
 $('rpv1').onclick=()=>rpFinish(true);$('rpv2').onclick=()=>{hide();rpFreeplay()};S.back=()=>rpFinish(true)}
function rpSetText(el,v){if(el&&el.textContent!==v)el.textContent=v}
function rpHudTick(force){const R=RPX,h=$('rphud');if(!R||!h||h.hidden||!RPH)return;const C=RPH;
 const sv=String(Math.floor(R.supply));if(force||C.s!==sv){const up=C.s!==undefined&&+sv>+C.s;C.s=sv;rpSetText($('rpcsv'),sv);const b=$('rpcs');if(b&&up){b.classList.remove('bump');void b.offsetWidth;b.classList.add('bump')}}
 const cv2=String(Math.floor(R.coins));if(force||C.c!==cv2){const up=C.c!==undefined&&+cv2>+C.c;C.c=cv2;rpSetText($('rpccv'),(+cv2).toLocaleString());const b=$('rpcc');if(b&&up){b.classList.remove('bump');void b.offsetWidth;b.classList.add('bump')}}
 const wv=R.map.endless?`Endless · wave ${R.wave}`:R.free?`Freeplay wave ${Math.max(0,R.wave-R.map.waves)}`:`Wave ${R.wave} / ${R.map.waves}`;if(C.w!==wv){C.w=wv;rpSetText($('rpwv'),wv)}
 if(C.k!==R.hp){if(C.k!==undefined&&R.hp<C.k){const b=$('rpck');b.classList.remove('hurt');void b.offsetWidth;b.classList.add('hurt')}C.k=R.hp;rpSetText($('rpckv'),`${R.hp} / ${RPT.HP}`);const f=$('rpckb');if(f)f.style.transform=`scaleX(${R.hp/RPT.HP})`;$('rpck').classList.toggle('low',R.hp<=6)}
 /* abilities: a dark shade that shrinks as it recharges, the seconds left, a pop when ready */
 for(const k of['over','slow','repair']){const cd=R.abCd[k],A=RPT.AB[k],q=cd>0?Math.ceil(cd):0,st=`${q}|${R.aim===k}|${k==='repair'&&R.hp>=RPT.HP}`;
  const b=h.querySelector(`.rpab[data-ab="${k}"]`);if(!b)continue;if(cd>0||C['f'+k]!==0){const f=cd/A.cd;C['f'+k]=cd>0?f:0;b.querySelector('.rpcdf').style.transform=`scaleY(${f})`}
  if(C['a'+k]!==st){const was=C['a'+k];C['a'+k]=st;rpSetText(b.querySelector('.rpcdn'),q?String(q):'');b.classList.toggle('cd',q>0);b.classList.toggle('aim',R.aim===k);b.classList.toggle('dim',k==='repair'&&R.hp>=RPT.HP);
   if(was&&!q&&+was.split('|')[0]>0){b.classList.remove('rdy');void b.offsetWidth;b.classList.add('rdy')}}}
 /* the go button */
 const go=R.wst==='build'?(R.wave===0?'Start wave 1':`Wave ${R.wave+1} in ${Math.ceil(Math.max(0,R.cd))}`):R.wst==='run'?`${R.q.length+R.foes.filter(e=>!e.dead).length} monsters left`:'';
 const gos=R.wst==='build'?(R.wave===0?'Space':`Space: call it now +${Math.ceil(Math.max(0,R.cd))*RPT.EARLY} supply`):`Wave ${R.free?R.wave-R.map.waves:R.wave} in progress`;/* (endless counts plainly) */
 if(C.go!==go+gos){C.go=go+gos;rpSetText($('rpgob'),go);rpSetText($('rpgos'),gos);const b=$('rpgo');b.hidden=R.wst==='done';b.classList.toggle('run',R.wst==='run');b.disabled=R.wst!=='build'}
 const sp=R.spd+'×';if(C.sp!==sp){C.sp=sp;rpSetText($('rpspd'),sp);$('rpspd').classList.toggle('on',R.spd>1)}
 /* tower bar: affordability and the type being placed */
 const ck=RP_TWORDER.map(t=>R.supply>=rpCost(t,1)?1:0).join('')+(R.place||'');if(C.ck!==ck){C.ck=ck;h.querySelectorAll('.rpcard').forEach(b=>{b.classList.toggle('no',R.supply<rpCost(b.dataset.tw,1));b.classList.toggle('on',R.place===b.dataset.tw)})}
 /* next-wave preview */
 const nw=R.wst==='done'?-1:R.wave+(R.wst==='build'?1:0);if(C.nw!==nw){C.nw=nw;const el=$('rpnext');if(el){if(nw<1||(!R.free&&!R.map.endless&&nw>R.map.waves)){el.hidden=true;el.innerHTML=''}else{const W=rpWave(R.map,nw),agg={};for(const g of W)agg[g.id]=(agg[g.id]||0)+g.n;
   el.hidden=false;el.innerHTML=`<small>${R.wst==='build'?'Next wave':'This wave'}</small><div>${Object.keys(agg).slice(0,4).map(id=>`<span title="${esc(rpName(id,R))}"><img alt="" src="${rpMobURL(id,56,R.map.pal)}"><b>×${agg[id]}</b></span>`).join('')}</div>`}}}
 /* boss bar */
 const bo=R.boss&&!R.boss.dead?R.boss:null;if(C.bo!==!!bo){C.bo=!!bo;$('rpboss').hidden=!bo;h.classList.toggle('bossup',!!bo)}if(bo){const f=$('rpbossf');if(f)f.style.transform=`scaleX(${Math.max(0,bo.hp/bo.mx)})`}
 rpHudInfo(R,C);rpHudRing(R,C);
 /* tutorials close themselves once their step is done */
 if(R.tut&&RP_TUT[R.tut].until&&RP_TUT[R.tut].until(R))rpTutDone(R.tut);
 const tt=R.toast?R.toast.txt:'';if(C.tt!==tt){C.tt=tt;const el=$('rptoast');el.hidden=!tt;if(tt){el.textContent=tt;el.style.color=R.toast.c;el.classList.remove('in');void el.offsetWidth;el.classList.add('in')}}}
/* the tower panel: built when the selection (or its tier or target) changes, then only patched */
function rpHudInfo(R,C){const el=$('rpinfo'),tw=R.sel;const key=tw?`${tw.pad.i}|${tw.tier}|${tw.prio}`:'';
 if(C.in!==key){C.in=key;C.inv=null;if(!tw){el.hidden=true;return}rpInfoBuild(R,tw,el)}
 if(!tw)return;const can=tw.tier<RP_MAXT(R.map)&&R.supply>=rpCost(tw.type,tw.tier+1),v=`${can}|${tw.kills}|${tw.over>0}`;if(C.inv===v)return;C.inv=v;
 const up=$('rpup');if(up)up.classList.toggle('no',!can);rpSetText($('rpikl'),`${tw.kills} defeated`);const oc=$('rpioc');if(oc)oc.hidden=!(tw.over>0)}
function rpInfoBuild(R,tw,el){const T=RP_TW[tw.type],TW=RPTW[tw.type],i=tw.tier-1,top=RP_MAXT(R.map),nx=tw.tier<top?tw.tier:null;
 /* six segments; damage on a square-root scale so tier 1 and tier 5 both read sensibly */
 const seg=(v,max)=>Math.max(0,Math.min(6,Math.round(v/max*6)));
 const bar=(lab,v,max,nv)=>`<div class="rpst"><span>${lab}</span><i>${[0,1,2,3,4,5].map(k=>`<s class="${k<seg(v,max)?'on':nv!=null&&k<seg(nv,max)?'up':''}"></s>`).join('')}</i></div>`;
 const dps=j=>Math.sqrt(T.dps?T.dps[j]*T.beams[j]*1.8:T.dmg[j]/T.cd[j]*(T.chain?T.chain[j]*.7:1));
 const extra=T.beams?bar('Beams',T.beams[i],5,nx!=null?T.beams[nx]:null):T.slow?bar('Slow',T.slow[i],.7,nx!=null?T.slow[nx]:null):T.splash?bar('Splash',T.splash[i],120,nx!=null?T.splash[nx]:null):T.chain?bar('Chain',T.chain[i],9,nx!=null?T.chain[nx]:null):bar('Armor pierce',Math.min(T.ap[i],12),12,nx!=null?Math.min(T.ap[nx],12):null);
 const maxNote=tw.tier>=5?'Celestial · the highest tier':tw.tier>=3&&!R.map.endless?(RP_MAPOPEN(RP_MAP('wonder'))?'Fully upgraded here · tiers 4 and 5 awaken in the Wonderland':'Fully upgraded here · win Ember Crown to reach the Wonderland, where tiers 4 and 5 awaken'):'Fully upgraded';
 el.innerHTML=`<button class="rpix" id="rpix" aria-label="Close">×</button><div class="rpih"><img alt="" src="${rpIconCanvas(tw.type,tw.tier,tw.skin,120)}"><span><b>${TW.n}</b><em>${Array.from({length:Math.max(3,top)},(_,k)=>RPI.star(k<tw.tier,15)).join('')} Tier ${tw.tier}${tw.tier>=5?' · Celestial':tw.tier>=4?' · Mythic':''}</em><small>${T.desc}</small></span></div>
  ${nx!=null?`<button class="rpup" id="rpup"><b>Upgrade · ${RPI.sup} ${rpCost(tw.type,tw.tier+1)}</b><small>${T.up[tw.tier-1]}</small><kbd>U</kbd></button>`:`<div class="rpmax${tw.tier>=4?' asc':''}">${maxNote}</div>`}
  <div class="rpsts">${bar('Range',T.range[i],320,nx!=null?T.range[nx]:null)}${bar('Damage',dps(i),Math.sqrt(1400),nx!=null?dps(nx):null)}${T.cd?bar('Fire rate',1/T.cd[i],2.1,nx!=null?1/T.cd[nx]:null):bar('Ramp',T.rampK+1,2.6,null)}${extra}</div>
  <div class="rppri"><span>Target</span>${['first','strong','close'].map(p=>`<button data-p="${p}" class="${tw.prio===p?'on':''}">${p[0].toUpperCase()+p.slice(1)}</button>`).join('')}</div>
  <div class="rpif"><span><i id="rpikl">${tw.kills} defeated</i> <b class="rpoc" id="rpioc" ${tw.over>0?'':'hidden'}>· Overcharged</b></span><button class="rpsell" id="rpsell">Sell +${Math.round(tw.spent*RPT.SELL)} <kbd>X</kbd></button></div>`;
 /* beside the tower, on the side with more room, clear of the top and bottom rows */
 el.classList.toggle('lf',tw.x>=800);el.hidden=false;el.style.top='0px';
 /* measured after rendering, so the Sell row always clears the bottom bar (which starts at y 778) */
 const w=316,hgt=el.offsetHeight||360,left=rpClamp(tw.x<800?tw.x+64:tw.x-64-w,8,1592-w),ty=rpClamp(tw.y-hgt*.62,76,770-hgt);
 el.style.left=left+'px';el.style.top=ty+'px';el.classList.remove('in');void el.offsetWidth;el.classList.add('in');
 $('rpix').onclick=()=>{R.sel=null};const up=$('rpup');if(up)up.onclick=()=>rpUpgrade(tw);$('rpsell').onclick=()=>rpSell(tw);
 el.querySelectorAll('.rppri button').forEach(b=>b.onclick=()=>{tw.prio=b.dataset.p;rpSfx('key',2)})}
/* the build ring around an empty pad: built once per pad, affordability patched */
function rpHudRing(R,C){const el=$('rpring'),p=R.selPad&&!R.selPad.tw?R.selPad:null,key=p?String(p.i):'';
 if(C.rg!==key){C.rg=key;C.rga=null;if(!p){el.hidden=true;el.innerHTML='';return}
  const below=p.y<330,ang=below?[170,130,90,50,10]:[-170,-130,-90,-50,-10],rad=150;
  el.innerHTML=RP_TWORDER.map((t,i)=>{const a=ang[i]*Math.PI/180,x=Math.cos(a)*rad,y=Math.sin(a)*rad*.72;return `<button class="rprb" data-tw="${t}" style="--x:${x.toFixed(1)}px;--y:${y.toFixed(1)}px;--d:${i*.04}s;--c:${RPTW[t].col}" aria-label="${RPTW[t].n}, ${rpCost(t,1)} supply"><img alt="" src="${rpIconCanvas(t,1,rpSkinOf(t),80)}"><b>${RPI.sup}${rpCost(t,1)}</b><em>${RPTW[t].n}</em></button>`}).join('');
  el.style.left=p.x+'px';el.style.top=(p.y-8)+'px';el.hidden=false;
  el.querySelectorAll('.rprb').forEach(b=>b.onclick=e=>{e.stopPropagation();rpBuild(p,b.dataset.tw)})}
 if(!p)return;const a=RP_TWORDER.map(t=>R.supply>=rpCost(t,1)?1:0).join('');if(C.rga===a)return;C.rga=a;el.querySelectorAll('.rprb').forEach(b=>b.classList.toggle('no',R.supply<rpCost(b.dataset.tw,1)))}
/* ---------- pause ---------- */
function rpPauseMenu(){const R=RPX;rpHudOff();const coins=Math.floor(R.coins);
 show(`<div class="rppause"><h2>Paused</h2><p>Runestone Tower Defense · ${esc(R.map.n)} · ${R.map.endless?`endless wave ${R.wave}`:R.free?`freeplay wave ${R.wave-R.map.waves}`:`wave ${R.wave} of ${R.map.waves}`} · health ${R.hp} / ${RPT.HP} · ${coins.toLocaleString()} coins earned</p>
 <div class="rpph"><span><kbd>Q</kbd><kbd>W</kbd><kbd>E</kbd><kbd>R</kbd><kbd>T</kbd> pick a tower, then click a pad</span><span><kbd>Click</kbd> a pad for the build ring, a tower to upgrade or sell</span><span><kbd>U</kbd> upgrade · <kbd>X</kbd> sell the selected tower</span>
  <span><kbd>1</kbd><kbd>2</kbd><kbd>3</kbd> Overcharge, Slow Field, Repair</span><span><kbd>Space</kbd> start or call the next wave early</span><span><kbd>F</kbd> game speed</span><span><kbd>Esc</kbd> cancel or resume</span></div>
 <div class="rphowx"><p><b>Supply</b> builds and upgrades towers in this battle. Monsters drop it, waves pay it, and calling a wave early pays extra.</p><p><b>Coins</b> are yours to keep: every monster, every wave and a victory bonus. More stars (castle health) mean a bigger bonus.</p></div>
 <div class="row"><button id="rp1">Resume</button></div><div class="row">${R.free||R.map.endless?'<button class="sm" id="rp4">Collect coins and leave</button>':''}<button class="sm" id="rp2">Restart</button><button class="sm dg" id="rp3">${R.free||R.map.endless?'Quit':coins?`Leave (keep ${coins.toLocaleString()} coins)`:'Quit to maps'}</button></div></div>`,'rpx rppx');
 S.back=()=>rpPause(false);$('rp1').onclick=()=>rpPause(false);const f=$('rp4');if(f)f.onclick=()=>{R.pause=false;hide();rpFinish(true)};
 $('rp2').onclick=e=>{const t=e.target.closest('button');if(t.dataset.a)rpRestart();else{t.dataset.a=1;t.textContent='Click again to restart';setTimeout(()=>{if(t.isConnected){t.dataset.a='';t.textContent='Restart'}},3000)}};
 $('rp3').onclick=()=>{if(R.free||R.map.endless){R.pause=false;hide();rpFinish(true)}else if(Math.floor(R.coins)>0){R.pause=false;hide();rpFinish(false)}else rpQuit()}}
/* ---------- result ---------- */
function rpResultEndless(R,r){const map=R.map,ab=r.abil.over+r.abil.slow+r.abil.repair;
 show(`<div class="rpres ${r.newBest?'win':'lose'} rpresx"><h2>${r.newBest?'A new record!':'The palace has fallen'}</h2>
  <div class="rpebig"><b>${r.held}</b><span>waves held</span></div>
  <p class="rpsub">${esc(map.n)} · endless · best ${r.best} waves${r.newBest?' · <b class="rpnb">new best!</b>':''}${r.asc?` · ${r.asc} ascension${r.asc>1?'s':''}`:''}</p>
  <div class="res"><div><b>${r.kills}</b>Monsters defeated</div><div><b>${r.built}</b>Towers built</div><div><b>${r.ups}</b>Upgrades</div><div><b>${ab}</b>Abilities used</div><div><b>${rpFmtT(r.time)}</b>Time</div></div>
  <div class="wrpay"><span class="wrpayc"><i class="wrcoinb" id="wrcoinb"></i><b id="wrtot">+0</b> coins</span><small>monsters ${r.kill.toLocaleString()} · waves ${r.wave.toLocaleString()} · no limit in the Wonderland${r.lg?` · level-up bonus ${r.lg}`:''}</small></div>
  <p class="wrxp">Earned <b>${r.xp.toLocaleString()} XP</b>${r.l1>r.l0?`<br><b>Level up! You are now level ${r.l1}.</b>`:''}${r.xn||''}</p>
  <div class="row"><button id="rp1">Defend again</button><button class="sm" id="rp2">Maps</button><button class="sm" id="hm">Home</button></div></div>`,'rpx rprx');
 $('rp1').onclick=()=>{rpLeave();rpStart(map.id)};$('rp2').onclick=()=>rpQuit();$('hm').onclick=()=>{rpLeave();title()};S.back=()=>{rpLeave();title()};
 const tt=$('wrtot');if(rpRM()||!r.total){if(tt)tt.textContent='+'+r.total.toLocaleString()}else setTimeout(()=>{try{wrCount(tt,r.total);wrCoinsFly(tt)}catch(e){if(tt)tt.textContent='+'+r.total.toLocaleString()}},700)}
function rpResult(){const R=RPX,r=R&&R.result;if(!r)return;S.mode='over';if(r.endless)return rpResultEndless(R,r);const map=R.map,nx=RP_MAPS[RP_MAPS.indexOf(map)+1];
 const unl=r.unl.map(s=>`<span class="rpunl"><img alt="" src="${rpIconCanvas(s.tw,3,s.k,96)}"><b>${esc(s.n)}</b><small>New tower skin</small></span>`).join('');
 const ab=r.abil.over+r.abil.slow+r.abil.repair;
 show(`<div class="rpres ${r.won?'win':'lose'}"><h2>${r.won?(r.free?'Freeplay over':'Victory!'):'The castle has fallen'}</h2>
  <div class="rpvst">${[0,1,2].map(i=>`<span style="--d:${.25+i*.2}s">${RPI.star(i<r.stars,62)}</span>`).join('')}</div>
  <p class="rpsub">${esc(map.n)} · ${r.won?`health ${r.hp} / ${RPT.HP}${r.newStars?' · <b class="rpnb">new best!</b>':''}`:`held ${r.cleared} of ${map.waves} waves`}${r.free?` · ${r.fpWaves} freeplay waves`:''}</p>
  <div class="res"><div><b>${r.kills}</b>Monsters defeated</div><div><b>${r.built}</b>Towers built</div><div><b>${r.ups}</b>Upgrades</div><div><b>${ab}</b>Abilities used</div><div><b>${r.leaked}</b>Got through</div><div><b>${rpFmtT(r.time)}</b>Time</div></div>
  <div class="wrpay"><span class="wrpayc"><i class="wrcoinb" id="wrcoinb"></i><b id="wrtot">+0</b> coins</span><small>monsters ${r.kill.toLocaleString()} · waves ${r.wave.toLocaleString()}${r.win?` · victory ${r.win.toLocaleString()}${r.first?' (first win today ×1.5)':''}`:''}${r.lg?` · level-up bonus ${r.lg}`:''}</small></div>
  <p class="wrxp">Earned <b>${r.xp.toLocaleString()} XP</b>${r.l1>r.l0?`<br><b>Level up! You are now level ${r.l1}.</b>`:''}${r.xn||''}${r.ttl?'<br><b style="color:#ffd45a">Rampart Warden! The title is yours in the bounty exchange.</b>':''}</p>
  ${unl?`<div class="rpunls">${unl}</div>`:''}
  <div class="row"><button id="rp1">${r.won&&nx&&RP_MAPOPEN(nx)&&!(RPP().stars[nx.id])?`Next map: ${esc(nx.n)}`:'Play again'}</button><button class="sm" id="rp2">Maps</button><button class="sm" id="hm">Home</button></div></div>`,'rpx rprx');
 const goNext=r.won&&nx&&RP_MAPOPEN(nx)&&!(RPP().stars[nx.id]);$('rp1').onclick=()=>{const id=goNext?nx.id:map.id;rpLeave();rpStart(id)};$('rp2').onclick=()=>rpQuit();$('hm').onclick=()=>{rpLeave();title()};S.back=()=>{rpLeave();title()};
 const tt=$('wrtot');if(rpRM()||!r.total){if(tt)tt.textContent='+'+r.total.toLocaleString()}else setTimeout(()=>{try{wrCount(tt,r.total);wrCoinsFly(tt)}catch(e){if(tt)tt.textContent='+'+r.total.toLocaleString()}},700)}
const rpFmtT=s=>`${Math.floor(s/60)}:${String(Math.floor(s%60)).padStart(2,'0')}`;
/* ---------- the hub: one world map merging the three regions, a side panel for the chosen map, the Rampart Armory below ---------- */
let RPSEL='moss';
const RP_NODE_DEF={moss:{x:250,y:540},frost:{x:690,y:250},ember:{x:1080,y:200},wonder:{x:900,y:600}};
function rpNodes(){try{if(typeof RPWORLD!=='undefined'&&RPWORLD.nodes)return RPWORLD.nodes}catch(e){}return RP_NODE_DEF}
const rpWonderOpen=()=>RP_MAPOPEN(RP_MAP('wonder'));
/* the Ascended collection: the highest tier each tower has reached in the Wonderland */
function rpAscRow(r){const n=RP_TWORDER.filter(t=>(r.asc[t]||0)>=5).length;
 return `<div class="rpasc"><small>ASCENDED TOWERS <b>${n} / ${RP_TWORDER.length}</b></small><div>${RP_TWORDER.map(t=>{const a=r.asc[t]||0;return `<span class="rpai${a>=5?' t5':a>=4?' t4':''}" title="${esc(RPTW[t].n)}: ${a>=5?'Celestial (tier 5)':a>=4?'Mythic (tier 4)':'not yet ascended'}"><img alt="" src="${rpIconCanvas(t,a>=4?a:5,'base',64)}"><em>${a>=5?'V':a>=4?'IV':''}</em></span>`}).join('')}</div></div>`}
function rampartsMenu(back){S.mode='title';S.view='ramparts';const r=RPP();r.seen=1;save();if(!RP_MAPOPEN(RP_MAP(RPSEL)))RPSEL='moss';const sn=rpStarN(),m=RP_MAP(RPSEL),N=rpNodes(),wOpen=rpWonderOpen();
 const node=mm=>{const open=RP_MAPOPEN(mm),st=r.stars[mm.id]||0,p=N[mm.id]||RP_NODE_DEF[mm.id],myst=mm.endless&&!open;
  const sub=mm.endless?`<span class="rpnend">${open?(r.ebest?`Best: ${r.ebest} waves`:'Endless'):'Win Ember Crown'}</span>`:`<span>${[0,1,2].map(i=>RPI.star(i<st,17)).join('')}<em>${st} / 3</em></span>`;
  return `<button class="rpnode${mm.id===RPSEL?' on':''}${open?'':' lock'}${myst?' myst':''}${mm.endless?' rpwn':''}" data-m="${mm.id}" style="left:${p.x}px;top:${p.y}px" aria-label="${myst?'An unknown land, locked':esc(mm.n)+(open?'':', locked')}"><i class="rpnglow"></i>${myst?"":open?'':`<span class="rpnlk">${RPI.lock}</span>`}<span class="rpnbn"><b>${myst?'? ? ?':esc(mm.n)}</b>${sub}</span></button>`};
 const day=rpDay(),first=r.day!==day||!r.dayDone[m.id],b=r.best[m.id];
 const nxt=RP_MAPS[RP_MAPS.indexOf(m)+1],nxtMyst=nxt&&nxt.endless&&!RP_MAPOPEN(nxt);
 const track=[...RP_SKINS.map(s=>({need:s.need,n:s.n,img:rpIconCanvas(s.tw,3,s.k,88),own:!!r.own[s.tw+':'+s.k]})),{need:RP_TITLE_NEED,n:'Rampart Warden title',ttl:1,own:sn>=RP_TITLE_NEED}];
 const nu=track.find(x=>sn<x.need);
 const side=m.endless?`<h2 class="rpsn rpsnw">${esc(m.n)}</h2><p class="rpss">Endless waves · starts like Ember Crown</p>
   <div class="rpsst"><em>${r.ebest?`Best: ${r.ebest} waves held`:'No waves held yet'}</em></div>
   <p class="rpstw">${esc(m.twist)}</p>
   <p class="rpscn">${RPI.coin}<span>Coins for every monster and every wave, with <b>no limit</b>.</span></p>
   <button class="rpgo2 rpgow" id="rpdef"><span>Enter the Wonderland</span><i>›</i></button>${rpAscRow(r)}`
  :`<h2 class="rpsn">${esc(m.n)}</h2><p class="rpss">${esc(m.sub)} · ${m.waves} waves</p>
   <div class="rpsst">${[0,1,2].map(i=>RPI.star(i<(r.stars[m.id]||0),30)).join('')}<em>${b&&b.hp!=null?`Best: ${b.hp} / ${RPT.HP} health${r.fp[m.id]?` · freeplay ${r.fp[m.id]}`:''}`:'Not yet defended'}</em></div>
   <p class="rpstw">${esc(m.twist)}</p>
   <p class="rpscn">${RPI.coin}<span>Coins for every monster and wave, plus a victory bonus up to <b>${Math.round(rpWinCoins(m,3)*(first?RPT.FIRSTDAY:1)).toLocaleString()}</b>${first?' (first win today ×1.5)':''}</span></p>
   <button class="rpgo2" id="rpdef"><span>Defend the castle</span><i>›</i></button>
   ${nxt?`<div class="rpnr"><small>NEXT REGION</small><div><span class="rpnri${nxtMyst?' myst':''}" id="rpnri">${nxtMyst?'<b class="rpnriq">?</b>':''}</span><span><b>${nxtMyst?'? ? ?':esc(nxt.n)}</b><em>${RP_MAPOPEN(nxt)?(nxt.endless?'Unlocked · endless waves':`Unlocked · ${nxt.waves} waves`):nxt.endless?`Win ${esc(m.n)} to reveal it`:`Earn 1 star in ${esc(m.n)}`}</em></span></div></div>`:''}`;
 show(`<div class="rpx rphub"><canvas class="rphbg" id="rphbg" width="1600" height="900"></canvas>
  <div class="rphtop"><button class="rpbk" id="rphback" aria-label="Back (Esc)">‹ Back</button><button class="rpbk" id="rphow"><i>?</i> How to play</button></div>
  <div class="rphl"><p class="rpkick">BUILD · UPGRADE · DEFEND</p><h1 class="rptitle">Runestone<br>Tower Defense</h1></div>
  ${RP_MAPS.map(node).join('')}
  <div class="rpside${m.endless?' rpsidew':''}"><canvas class="rpprev" id="rpprev" width="680" height="383"></canvas>${side}</div>
  <div class="rparm"><div class="rparmh"><b>Rampart Armory</b><span>${RPI.star(1,20)} ${sn} / 9 stars</span><em><i style="transform:scaleX(${sn/9})"></i></em></div>
   <div class="rptrk"><i class="rptrl"><s style="transform:scaleX(${Math.min(1,Math.max(0,(sn-1)/8))})"></s></i>${track.map(x=>`<span class="rptk${x.own?' own':''}${x===nu?' nx':''}" style="left:${(x.need-1)/8*100}%">${x.ttl?`<span class="rptki">${RPI.keep}</span>`:`<img alt="" src="${x.img}">`}<em>${RPI.star(1,13)} ${x.need}</em></span>`).join('')}</div>
   <div class="rpnu">${nu?`<small>Next unlock</small><b>${nu.need} stars</b><span>${esc(nu.n)}</span>`:'<small>All rewards</small><b>Earned</b>'}</div>
   <button class="rpvr" id="rpvr">View rewards ›</button></div>
  <div class="rpmod" id="rpmod" hidden></div></div>`,'rpx rphubx');
 S.view='ramparts';S.back=back||title;$('rphback').onclick=()=>(back||title)();
 $('rpdef').onclick=()=>rpStart(RPSEL);$('rphow').onclick=()=>rpHowTo();$('rpvr').onclick=()=>rpRewards(back);
 ov.querySelectorAll('.rpnode').forEach(b=>{b.onclick=()=>{if(b.classList.contains('lock')){rpSfx('no');const mm=RP_MAP(b.dataset.m),pv=RP_MAPS[RP_MAPS.indexOf(mm)-1];try{toast(mm.endless?`Win ${pv.n} to reveal this land`:`Earn 1 star in ${pv.n} to unlock ${mm.n}`)}catch(e){}return}
  if(RPSEL===b.dataset.m){rpStart(RPSEL);return}RPSEL=b.dataset.m;rpSfx('key',2);rampartsMenu(back)}});
 {const pc=$('rpprev'),B=rpBake(m),g=pc.getContext('2d');g.drawImage(B.c,0,0,1600,900,0,0,680,383)}
 if(nxt&&!nxtMyst){const sl=$('rpnri');try{const ic=rpMapIcon(nxt.id,72,72);const c2=document.createElement('canvas');c2.width=ic.width;c2.height=ic.height;c2.getContext('2d').drawImage(ic,0,0);c2.className='rpnric';sl.appendChild(c2)}catch(e){}if(!RP_MAPOPEN(nxt))sl.insertAdjacentHTML('beforeend',`<i class="rpnrl">${RPI.lock}</i>`)}
 rpHubBG()}
function rpHowTo(){const el=$('rpmod');if(!el)return;el.innerHTML=`<div class="rpmc2"><button class="rpix" id="rpmx" aria-label="Close">×</button><h2>How to play</h2>
 <div class="rphw"><p><b>1 · Build.</b> Pick a tower in the bar (or press Q, W, E, R, T) and click a glowing stone pad, or click a pad and choose from the ring. Towers fire on their own.</p>
 <p><b>2 · Start the wave.</b> Monsters follow the road to your castle. Each one that gets through costs health; at 0 the castle falls.</p>
 <p><b>3 · Spend supply.</b> Monsters and waves pay supply. Click a tower to upgrade it (three tiers, each grander than the last) or sell it. Calling a wave early pays extra supply.</p>
 <p><b>4 · Use abilities.</b> Overcharge (1) makes a tower fire much faster, Slow Field (2) freezes a stretch of road, Repair (3) heals the castle. Each recharges on its own.</p>
 <p><b>Towers.</b> Rune Ballista: strong single shots, hits flyers, pierces armor. Ember Blazer: splash, ground only. Frost Spire: slows every ground foe in range. Storm Bell: chain lightning, double damage to flyers. Celestial Prism: the costliest tower; radiant beams that burn hotter the longer they hold a target.</p>
 <p><b>The Wonderland.</b> Win Ember Crown to reveal it: an endless siege that starts like Ember Crown and grows harder every wave after 15. Only there can towers ascend to tier 4 (Mythic) and tier 5 (Celestial); every tower you take to tier 5 joins your Ascended collection.</p>
 <p><b>Rewards.</b> Coins for every monster and every wave, plus a victory bonus (bigger with more stars, ×1.5 for the first win of the day on each map). After a win, Freeplay keeps paying with no limit. Stars unlock tower skins and the Rampart Warden title.</p></div></div>`;
 el.hidden=false;$('rpmx').onclick=()=>{el.hidden=true};el.onclick=e=>{if(e.target===el)el.hidden=true}}
function rpRewards(back){const el=$('rpmod');if(!el)return;const r=RPP(),sn=rpStarN();
 const skin=s=>{const own=!!r.own[s.tw+':'+s.k],on=rpSkinOf(s.tw)===s.k;return `<button class="rpsk${own?'':' lock'}${on?' on':''}" data-tw="${s.tw}" data-k="${s.k}"><img alt="" src="${rpIconCanvas(s.tw,3,s.k,88)}"><b>${esc(s.n)}</b><small>${own?(on?'Equipped · click to remove':'Owned · click to equip'):`${RPI.star(1,13)} ${s.need} stars`}</small></button>`};
 el.innerHTML=`<div class="rpmc2 wide"><button class="rpix" id="rpmx" aria-label="Close">×</button><h2>Rampart Armory</h2><p class="rparmn">${sn} / 9 stars. Stars per map: a win = 1, 10+ health = 2, 18+ health = 3. Skins and the title are only found here.</p>
  <div class="rpsks">${RP_SKINS.map(skin).join('')}<span class="rpsk rpttl${sn>=RP_TITLE_NEED?'':' lock'}"><span class="rpttli">${RPI.keep}</span><b>Rampart Warden</b><small>${sn>=RP_TITLE_NEED?'Title earned':`Title · ${RPI.star(1,13)} 9`}</small></span></div></div>`;
 el.hidden=false;$('rpmx').onclick=()=>{el.hidden=true};el.onclick=e=>{if(e.target===el)el.hidden=true};
 el.querySelectorAll('.rpsk[data-k]').forEach(b=>b.onclick=()=>{if(b.classList.contains('lock')){rpSfx('no');return}const r2=RPP();r2.skin[b.dataset.tw]=rpSkinOf(b.dataset.tw)===b.dataset.k?'base':b.dataset.k;save();rpSfx('up');rampartsMenu(back);rpRewards(back)})}
/* the hub backdrop: the painted world (95h) with its live overlay; without it, the chosen map */
function rpHubBG(){const cv2=$('rphbg');if(!cv2)return;const g=cv2.getContext('2d'),op=rpWonderOpen();let bg=null;try{if(typeof rpWorldArt==='function')bg=rpWorldArt(op)}catch(e){bg=null}
 if(!bg)bg=rpBake(RP_MAP(RPSEL)).c;
 const draw=t=>{g.setTransform(1,0,0,1,0,0);g.drawImage(bg,0,0,1600,900);if(typeof rpWorldLive==='function')try{rpWorldLive(g,t,op)}catch(e){}};
 draw(1);if(!rpRM())LIVE.push({cv:cv2,fn:draw,slow:2})}
/* ---------- hooks ---------- */
MG.ramparts=bP('M18 82V40h12v-12h10v12h20v-12h10v12h12v42H58V64H42v18z','#8a8aa8')+bF('M60 40h22v42H60z','#000',.2)+bP('M44 64h12v18H44z','#3a2414')+bP('M28 22l6-10 6 10z','#ffd45a')+bH('M22 46h20','#fff',3)+bS(76,22,5,'#9fe8ff');
MA.ramparts='#9fe8ff';
{const m0=modeSheet;modeSheet=function(){const r=m0.apply(this,arguments);try{const sh=document.querySelector('.dks .dkpv[data-v="m"]')||document.querySelector('.dkpv[data-v="m"]'),g=sh&&sh.querySelector('.dkmg');if(g&&!sh.querySelector('#dmrp')){const p=RPP(),b=document.createElement('button');b.className='dkm dkmrp';b.id='dmrp';b.style.setProperty('--c','#9fe8ff');
  b.innerHTML=`<span class="dkmi">${mico('ramparts',58)}</span><span class="dkmt"><b>Runestone Tower Defense${p.seen?'':' <em class="dkmnew">NEW</em>'}</b><small>Tower defense. Build, upgrade, hold the castle. ${rpStarN()} / 9 stars.</small></span><i class="dkchv">›</i>`;
  g.insertBefore(b,g.firstChild);b.onclick=()=>{dkClose(true);setTimeout(()=>rampartsMenu(title),0)}}}catch(e){console.error(e)}return r}}
/* the home card takes Moonlit Fishing's slot (Fishing stays in Choose a mode and on the F key) */
{const t0=title;title=function(){const r=t0.apply(this,arguments);try{rpHomeCard()}catch(e){console.error(e)}return r}}
function rpHomeCard(){const sc=ov.querySelector('.dksc');if(!sc||sc.querySelector('#dkrp'))return;const p=RPP(),n=rpStarN(),fish=sc.querySelector('#dkfish'),d=document.createElement('div');
 d.innerHTML=`<button class="dkcard dkrp dklive dkg dktilt" id="dkrp" title="Runestone Tower Defense (U)" aria-label="Runestone Tower Defense${p.seen?'':', new mode'}. ${n} of 9 stars"><canvas class="dkcv" width="560" height="320" aria-hidden="true"></canvas><i class="dkgl"></i>${p.seen?'':'<em class="dknew">NEW</em>'}<span class="dkcl"><small>${p.seen?'TOWER DEFENSE':'NEW MODE'}</small><b>Runestone Tower Defense</b><small class="dkevv">${n?`${n} / 9 stars`:'Hold the castle'} <i>›</i></small></span></button>`;
 const card=d.firstChild;if(fish)fish.replaceWith(card);else{sc.appendChild(card)}card.onclick=()=>rampartsMenu(title);
 const cv2=card.querySelector('canvas'),g=cv2.getContext('2d'),map=RP_MAP('moss'),B=rpBake(map),G=rpGeo(map);
 const sx=860,sy=250,sw=740,sh=423,k=560/sw;
 const draw=t=>{g.setTransform(1,0,0,1,0,0);g.drawImage(B.c,sx,sy,sw,sh,0,0,560,320);g.save();g.scale(k,k);g.translate(-sx,-sy);
  for(let i=0;i<3;i++){const s=((t*36+i*180)%G.len),pp=rpAt(G,s);if(pp.x>sx-20&&pp.x<sx+sw)try{rpMobBlit(g,['scamp','bulwark','golem'][i],pp.x,pp.y,(t+i*.3)%1,{s:1,flip:Math.cos(pp.a)<-.2})}catch(e){}}
  for(const pd of G.pads)if(pd.x>sx+20&&pd.x<sx+sw-20&&pd.y>sy+120&&pd.y<sy+sh){g.save();g.translate(pd.x,pd.y);try{rpTowerDraw(g,RP_TWORDER[pd.x%4],2,'base',t,{aim:Math.sin(t+pd.x)})}catch(e){}g.restore()}g.restore();
  const q=g.createLinearGradient(0,0,560,0);q.addColorStop(0,'#0c0822c0');q.addColorStop(.45,'#0c082230');q.addColorStop(1,'#0c082200');g.fillStyle=q;g.fillRect(0,0,560,320)};
 draw(2);if(!dkRM())LIVE.push({cv:cv2,fn:draw,slow:3,ph:1})}
{const hk0=homeKey;homeKey=function(e){if(HOME&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&(e.key==='u'||e.key==='U')&&!document.querySelector('.dks.on')){const ae=document.activeElement;if(!(ae&&ae!==inp&&/INPUT|TEXTAREA|SELECT/.test(ae.tagName))){e.preventDefault();rampartsMenu(title);return true}}return hk0.apply(this,arguments)}}
{const d0=dkDetect;dkDetect=function(html){if(typeof html==='string'&&/class="rpx rphub/.test(html))return'pl';return d0.apply(this,arguments)}}
try{HELP.Modes.unshift(['Runestone Tower Defense','Tower defense, all strategy. Monsters march along the roads toward your castle. Pick a tower (Q W E R T) and click a stone pad, or click a pad and choose from the ring: Rune Ballista (single target, hits flyers, pierces armor), Ember Blazer (splash), Frost Spire (slows), Storm Bell (chain lightning, double damage to flyers) or the Celestial Prism (the costliest: ramping radiant beams). Click a tower to upgrade it (three tiers) or sell it. Abilities recharge on cooldowns: 1 Overcharge, 2 Slow Field, 3 Repair. Space starts or calls the next wave early for bonus supply; F switches speed. Each map has a twist: a river bridge, two caves and ice, or a split road with lava vents. Coins are paid for every monster and wave plus a victory bonus, with no limit in Freeplay. Win Ember Crown to reveal the Wonderland, an endless mode where towers ascend to tiers 4 and 5. Stars unlock tower skins and the Rampart Warden title, found only here.']);
 const sc=HELP.Shortcuts&&HELP.Shortcuts.find(x=>x[0]==='F W G'||x[0]==='F W G U');if(sc){sc[0]='F W G U';sc[1]='Moonlit Fishing, Lantern Caravan, Runestone Riddle, Runestone Tower Defense.'}}catch(e){}
try{const t={k:'ramparts',tier:1,ok:()=>true,mk:r=>({n:1}),txt:c=>'Win a Runestone Tower Defense map'};BTPL.push(t);BTK.ramparts=t}catch(e){}
try{BT_TITLES.push(['rampartwarden','Rampart Warden',1e9]);const b0=bountyBoard;bountyBoard=function(){const r=b0.apply(this,arguments);try{const x=ov.querySelector('[data-buy="t:rampartwarden"]');if(x){const s=document.createElement('span');s.className='rrlock';s.textContent='Earn: 9 stars in Runestone Tower Defense';x.replaceWith(s)}}catch(e){}return r}}catch(e){}
/* music: the caravan's soundtrack engine plays the road theme in a run and the camp theme on the hub */
function wraWant(){try{if(typeof S==='undefined')return null;if(WRX&&S.wr&&(S.mode==='wagon'||S.mode==='over'))return 'road';if(S.mode==='title'&&S.view==='wagon'&&$('wrhub'))return 'camp';
 if(RPX&&S.rp&&(S.mode==='ramparts'||S.mode==='over'))return 'road';if(S.mode==='title'&&S.view==='ramparts'&&ov.querySelector('.rphub'))return 'camp';return null}catch(e){return null}}
{const s0=wraState;wraState=function(){const R=RPX;if(R&&S.rp&&S.mode==='ramparts'){if(R.over||R.pause||R.wst!=='run')return{v:0,danger:0,flare:0};let d=0;for(const e of R.foes)if(!e.dead&&e.s>rpLen(R,e)*.8)d++;return{v:1,danger:Math.min(1,d/4+(R.boss?.5:0)+(R.hp<=6?.3:0)),flare:R.pads.some(p=>p.tw&&p.tw.over>0)?1:0}}return s0.apply(this,arguments)}}
/* the legacy corner buttons stay hidden for the whole run, the victory choice and the result */
{const m0=mfxCorner;mfxCorner=function(){const r=m0.apply(this,arguments);try{const c=$('cn');if(c&&(S.rp||RPX))c.classList.add('mfxhid')}catch(e){}return r}}
