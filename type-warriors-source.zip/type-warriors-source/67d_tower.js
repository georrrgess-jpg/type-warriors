/* ---------- casino: Tower Climb (the launch special) ---------- */
/* Ten floors, three doors each, one hides a trap. Every safe floor multiplies the payout.
   Odds: each floor is a fair 2 in 3 shot. Payout after n floors is EDGE x 1.5^n, so the house edge is the same on every floor.
   Normal days EDGE = 0.96 (4% house edge). On the launch day EDGE = 1.10, a +10% player edge, so the boost is real. */
const TW={FLOORS:10,CAP:20000,EDGE:.96,BOOST_EDGE:1.10,BOOST_DAY:'2026-10-06',STEP:1.5,FH:130,
 day:()=>window.__twDay||(()=>{const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')})()};
const twBoost=()=>TW.day()===TW.BOOST_DAY;
const twEdge=b=>b?TW.BOOST_EDGE:TW.EDGE;
const twMul=(n,b)=>n<1?1:Math.floor(twEdge(b)*Math.pow(TW.STEP,n)*100+1e-6)/100;
const twPay=(bet,n,b)=>n<1?0:Math.min(TW.CAP,Math.floor(bet*twMul(n,b)));
const twSt=()=>{const c=cst();return c.tw=c.tw&&typeof c.tw==='object'?c.tw:{best:0,climbs:0,summits:0,top:0}};
const twLeft=()=>{const n=new Date(),e=new Date(n.getFullYear(),n.getMonth(),n.getDate()+1),ms=Math.max(0,e-n),h=Math.floor(ms/36e5),m=Math.floor(ms%36e5/6e4);return h+'h '+String(m).padStart(2,'0')+'m'};

/* ---------- Tower Climb score: "The Ascent", an invigorating A minor climb ----------
   16 bars, loops. It starts as a quiet, tense waiting theme and builds as you climb:
   floors 1-2 bass pulse + arpeggio + kick, 3-5 backbeat, hats and a heroic brass theme, 6-8 strings, choir, octave bass and fills,
   9-10 crash cymbals and a screaming top line. The tempo rises with every floor. A trap drops everything out for a beat. */
const TWM={on:0,tok:-1,fl:-1,s:0,n0:0,mute:0};
const twMusic=()=>TWM.on&&CAS.on&&TWM.tok===CAS.tok;
const twBpm=()=>TWM.fl<0?104:126+TWM.fl*2.6;
const TWR=[7,3,10,5,7,3,5,7,7,3,10,5,3,5,7,7],TWQ='mMMMmMMmmMMMMMmm';
const TWMEL=(()=>{const A=[[[0,12,3],[3,10,1],[4,12,2],[6,15,2]],[[0,17,3],[3,15,1],[4,12,2],[6,8,2]],[[0,15,3],[3,12,1],[4,15,2],[6,19,2]],[[0,17,2],[2,14,2],[4,10,4]]],
 B=[A[0],[[0,17,2],[2,19,2],[4,20,4]],[[0,19,2],[2,17,2],[4,14,2],[6,17,2]],[[0,12,8]]],
 C=[[[0,17,3],[3,15,1],[4,17,2],[6,20,2]],[[0,19,3],[3,17,1],[4,14,2],[6,17,2]],[[0,19,2],[2,17,2],[4,15,2],[6,12,2]],[[0,12,6]]];
 return [...A,...B,...A,...C]})();
function twScore(t,n0){if(!TWM.s){TWM.s=1;TWM.n0=n0}KS.on=0;const n=n0-TWM.n0,B=kInit(),bar=(n>>3)&15,k=n&7,sd=stepD(),bl=sd*8,r=TWR[bar],th=TWQ[bar]==='m'?3:4,F=m=>fq(m),fl=TWM.fl,idle=fl<0,muted=ac.currentTime<TWM.mute,lv=idle?.5:1,hi=fl>=6,mid=fl>=3;
 /* pad: sustained strings on every chord */
 if(k===0)for(const iv of [r,r+th,r+7])kv(t,F(iv+12),bl*.97,{ty:['sawtooth','sawtooth'],det:[-9,9],lp:900+Math.max(0,fl)*200,a:.35,r:.5,v:(idle?.014:.02+(hi?.01:0))*(muted?.5:1),bus:B.st});
 if(muted)return;
 /* idle: just a slow heartbeat and a sparse, anticipating arpeggio */
 if(idle){if(k===0||k===3)ktaiko(t,k?.25:.4,F(r)*1);if(k%2===0)kv(t,F(r+24+[0,th,7,12][(k>>1)&3]),sd*1.4,{ty:['triangle'],lp:1800,a:.01,r:.2,v:.018,bus:B.st});return}
 /* bass pulse */
 kv(t,F(r),sd*.85,{ty:['sawtooth'],lp:520+fl*40,a:.006,r:.06,v:(k%4===0?.062:.044)*lv,bus:B.br});
 if(hi&&k%2===1)kv(t,F(r+12),sd*.7,{ty:['square'],lp:700,a:.005,r:.05,v:.026,bus:B.br});
 /* rolling arpeggio */
 const fig=[0,th,7,12,7,th+12,7,th][k];kv(t,F(r+24+fig),sd*.8,{ty:['sawtooth','sawtooth'],det:[-8,8],lp:2300+fl*120,a:.005,r:.06,v:.028+(mid?.004:0),bus:B.st,f0:.5});
 /* drums: kick on the beat, backbeat snare, hats */
 if(k===0||k===4)ktaiko(t,k?.7:.95,F(r)*1.1);
 if(fl>=1&&k===6&&bar%2)ktaiko(t,.5,F(r)*1.1);
 if(fl>=2&&(k===2||k===6))ksnare(t,.55+fl*.04);
 if(fl>=2)kns(t,.035,.035+(k%2?.0:.012),7500,'highpass',B.pc);
 if(mid&&k%2===1)kns(t,.12,.03,6500,'highpass',B.pc);
 if(hi&&(bar%4===3)&&k>=4){ktaiko(t,.5+(k-4)*.12,F(r)*(k>5?1.5:1.1));ksnare(t,.5)}
 if(fl>=3&&k===0&&bar%4===0)kns(t,1.5,.06+fl*.006,5200,'highpass',B.pc,.7,.004);
 if(fl>=4&&bar===15&&k===0)kns(t,bl*.97,.07,3000,'bandpass',B.pc,.9,bl*.9);
 /* the heroic theme */
 if(mid&&(bar>=4||hi)){for(const [st,p,len] of TWMEL[bar]){if(st!==k)continue;const d=len*sd*.96,f=F(7+24+p);
  kv(t,f,d,{ty:['sawtooth','sawtooth','square'],mul:[1,1,.5],det:[-6,6,0],lp:2700+fl*160,f0:.3,a:.04,r:.12,v:.05+(hi?.016:0),vib:7,bus:B.br,q:1.1});
  if(hi)kv(t,f*Math.pow(2,-7/12),d,{ty:['sawtooth','sawtooth'],det:[-5,5],lp:2300,f0:.3,a:.05,r:.12,v:.034,vib:7,bus:B.br});
  if(fl>=9)kv(t,f*2,d,{ty:['triangle'],lp:6000,a:.01,r:.1,v:.018,bus:B.st})}}
 /* choir lift on the first beat of every second bar at the top */
 if(hi&&k===0&&bar%2===0)for(const iv of [r,r+th,r+7])kv(t,F(iv+24),bl*1.9,{ty:['sawtooth','sine'],det:[-6,6],lp:1200,a:.5,r:.5,v:.014,bus:B.ch,vib:12})}
{const n0=note;note=function(t,n){if(twMusic())return twScore(t,n);if(TWM.s)TWM.s=0;return n0(t,n)}}

/* lobby: its own tab, tile art and feature card */
TCAT.tw='special';
TTAB.splice(1,0,['special','Special','<path d="M12 1l2.6 6.6L21.5 8l-5.3 4.6L17.8 20 12 16.2 6.2 20l1.6-7.4L2.5 8l6.9-.4z"/>']);
TA.tw=(()=>{const st=[[22,24,2.2],[60,14,1.5],[120,30,1.8],[200,18,2],[262,34,1.6],[296,16,2.2],[40,70,1.4],[286,80,1.6],[16,120,1.8]].map(s=>`<circle cx="${s[0]}" cy="${s[1]}" r="${s[2]}" fill="#fff6c8" opacity=".85"/>`).join('');
 const door=(x,y,glow,trap)=>`<g transform="translate(${x} ${y})"><path d="M-20 0V-44a20 20 0 0 1 40 0V0z" fill="${glow?'#ffe27a':trap?'#ff3a50':'#1a1030'}" ${glow||trap?'':'opacity=".9"'}/><path d="M-20 0V-44a20 20 0 0 1 40 0V0z" fill="none" stroke="#f0c050" stroke-width="3"/>${glow?'<circle cx="0" cy="-30" r="30" fill="#fff6c0" opacity=".35"/>':''}<path d="M-20 0V-44a20 20 0 0 1 14-19L-6 0z" fill="#8a4a1a" stroke="#3a1a08" stroke-width="2" transform="${glow?'skewY(-8) translate(-4 0)':''}"/><circle cx="-12" cy="-24" r="2.4" fill="#ffd24a"/></g>`;
 return `<svg viewBox="0 0 320 176" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="twg0" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#120a34"/><stop offset=".55" stop-color="#4a1c6e"/><stop offset="1" stop-color="#e8782a"/></linearGradient><linearGradient id="twg1" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#2a2042"/><stop offset=".5" stop-color="#4a3a6a"/><stop offset="1" stop-color="#2a2042"/></linearGradient><radialGradient id="twg2" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#fff2a0" stop-opacity=".9"/><stop offset="1" stop-color="#ffb030" stop-opacity="0"/></radialGradient></defs>
<rect width="320" height="176" fill="url(#twg0)"/>${st}<circle cx="160" cy="26" r="46" fill="url(#twg2)"/>
<g><path d="M92 176V44h136v132z" fill="url(#twg1)" stroke="#f0c050" stroke-width="3"/><path d="M84 44h152v-10h-14v-10h-14v10h-20v-10h-14v10h-20v-10h-14v10h-20v-10h-14v10H98v-10H84z" fill="#3a2e58" stroke="#f0c050" stroke-width="2.4"/>
${[0,1,2].map(i=>`<path d="M92 ${70+i*36}H228" stroke="#f0c05088" stroke-width="2"/>`).join('')}
${door(124,100,0,0)}${door(160,100,1,0)}${door(196,100,0,1)}${door(124,136,1,0)}${door(160,136,0,0)}${door(196,136,0,0)}
<path d="M138 84l8 10h-16z" fill="#ffe27a" opacity=".0"/></g>
<g fill="#ffd24a"><path d="M160 8l3 8 8 3-8 3-3 8-3-8-8-3 8-3z"/></g>
</svg>`})();
GAMES.unshift({id:'tw',n:'Tower Climb',d:'Climb a tower one floor at a time. Each floor has three doors and one hides a trap. Every safe floor raises your payout. Cash out any time. Payouts are capped at 20,000.',m:(e,t)=>mTW(e,t)});

/* the Special tab: one big feature card */
function twLobby(){const g=$('gdgrid'),b=twBoost(),S2=twSt(),tok=CAS.tok,m1=twMul(1,b),m5=twMul(5,b),m10=twMul(10,b);
 g.className='gdgrid twspecial';
 g.innerHTML=`<div class="twfeat${b?' boost':''}"><button class="twfart" data-g="tw" aria-label="Play Tower Climb"><span class="twfa">${TA.tw}</span><i class="co c1"></i><i class="co c2"></i><i class="co c3"></i><i class="co c4"></i>${b?'<span class="twrib">TODAY ONLY</span>':''}</button>
 <div class="twfinfo"><div class="twfk">${b?'<span class="twbadge">LAUNCH DAY BOOST</span>':'<span class="twbadge dim">NOW OPEN</span>'}<span class="twnew">NEW</span></div>
 <h3>Tower Climb</h3>
 <p>Pick a door on each floor. Two are safe, one is a trap. Every safe floor raises your payout. Cash out any time.</p>
 <ul class="twfl"><li><b>Odds</b> every floor is 2 in 3 to be safe</li><li><b>Payouts</b> floor 1 pays ×${m1.toFixed(2)}, floor 5 ×${m5.toFixed(2)}, the summit ×${m10.toFixed(2)}</li><li><b>Limits</b> bets up to 7,500, payout capped at 20,000</li></ul>
 ${b?`<div class="twboost"><span class="twsp"></span><div><b>Boosted payouts today only</b><small>Every floor pays about ${Math.round((TW.BOOST_EDGE/TW.EDGE-1)*100)}% more than normal. Boost ends in <span id="twcd">${twLeft()}</span>.</small></div></div>`:''}</div>
 <div class="twfside"><div class="twfs"><span>Best climb</span><b>${S2.best?'Floor '+S2.best:'None yet'}</b></div><div class="twfs"><span>Summits</span><b>${S2.summits}</b></div><div class="twfs"><span>Best payout</span><b>${S2.top?cmn(S2.top):'None yet'}</b></div><button class="twplay" data-g="tw">Play now</button></div></div>`;
 g.querySelectorAll('[data-g]').forEach(x=>x.onclick=()=>gameOpen('tw'));
 if(b){const iv=setInterval(()=>{const e=$('twcd');if(!e||CAS.tok!==tok){clearInterval(iv);return}e.textContent=twLeft()},20000)}}

/* ---------- the game ---------- */
function mTW(el,tok){
 const alive=()=>CAS.tok===tok,rm=matchMedia('(prefers-reduced-motion: reduce)').matches,K=rm?.35:1,wait=ms=>csleep(ms*K);
 let idleSub='Place a bet to start climbing.',ph='idle',bet=0,lvl=0,boost=twBoost(),traps=[],busy=false,shown=0,hint=-1;
 const FH=TW.FH,N=TW.FLOORS;
 TWM.on=1;TWM.tok=tok;TWM.fl=-1;TWM.s=0;TWM.mute=0;
 const doorSvg=n=>`<span class="twp"><i class="twplank"></i><i class="twband b1"></i><i class="twband b2"></i><i class="twknob"></i><b>${n}</b></span>`;
 const heroSvg=`<svg viewBox="0 0 36 56" width="44" height="68" aria-hidden="true"><ellipse cx="18" cy="53" rx="11" ry="3" fill="#0008"/><path d="M12 20c-2 8-1 18 0 30h5V34h2v16h5c1-12 2-22 0-30z" fill="#7a86b8" stroke="#1a2040" stroke-width="1.4"/><path d="M10 22l-4 14 4 2 3-10zM26 22l4 14-4 2-3-10z" fill="#5a6698" stroke="#1a2040" stroke-width="1.2"/><rect x="13" y="32" width="10" height="4" fill="#ffd24a" stroke="#6a4a08" stroke-width="1"/><circle cx="18" cy="13" r="8" fill="#d8dcf0" stroke="#1a2040" stroke-width="1.6"/><path d="M10 12h16v4H10z" fill="#1a2040"/><rect x="12" y="13" width="12" height="2" fill="#9fe8ff"/><path d="M18 5c4-6 10-3 11 2-4-2-7-1-11-2z" fill="#e8283e" stroke="#5a0a18" stroke-width="1"/><rect x="29" y="22" width="3" height="22" fill="#e8eefc" stroke="#445" stroke-width="1" transform="rotate(14 30 33)"/></svg>`;
 const torch=`<span class="twtorch twtl"><i class="twfl1"></i><i class="twfl2"></i><i class="twstick"></i></span>`;
 const floorHTML=i=>{if(i===0)return `<div class="twf twf0" data-r="0"><span class="twplate">ENTRANCE</span><span class="twhere">START HERE</span><div class="twgate"><i></i></div>${torch}${torch.replace('twtl','twtr')}</div>`;
  if(i===N+1)return `<div class="twf twroof" data-r="${i}"><span class="twplate">SUMMIT</span><div class="twtres" id="twtres"><i></i><b></b></div>${torch}${torch.replace('twtl','twtr')}</div>`;
  return `<div class="twf" data-r="${i}"><span class="twplate">FLOOR ${i}</span><span class="twfm">×${twMul(i,boost).toFixed(2)}</span><div class="twdoors">${[0,1,2].map(d=>`<button class="twd" data-d="${d}" data-r="${i}" aria-label="Floor ${i}, door ${d+1}" disabled><span class="twa"><i class="twray"></i><i class="twlt"></i><i class="twsp2"></i><i class="twskull"></i></span>${doorSvg(d+1)}</button>`).join('')}</div>${torch}${torch.replace('twtl','twtr')}</div>`};
 const stackHTML=()=>Array.from({length:N+2},(_,i)=>floorHTML(i)).join('');
 el.innerHTML=`<div class="tw" id="tw"><aside class="twl"><div class="twbox twmain"><span class="twlab">Payout now</span><b class="twbig" id="twpay"><i class="coin"></i><em id="twpv">0</em></b><span class="twsub" id="twsub">Place a bet to start climbing.</span></div>
 <div class="twbox twnext" id="twnext"></div><div class="twbox twrec" id="twrec"></div></aside>
 <div class="twview" id="twview"><div class="twsky" id="twsky"><i class="twcl c1"></i><i class="twcl c2"></i><i class="twcl c3"></i></div><div class="twshaft" id="twshaft"><div class="twstack" id="twstack">${stackHTML()}</div></div><div class="twfx" id="twfx"></div><div class="twflash" id="twflash"></div><div class="twbanner" id="twbanner"></div><div class="twvig"></div>${boost?'<div class="twtag">TODAY ONLY · BOOSTED</div>':''}</div>
 <aside class="twr"><div class="twlh">Payout ladder</div><div class="twlad" id="twlad">${Array.from({length:N},(_,k)=>{const f=N-k;return `<div class="twlr${f===5?' ms':f===N?' ms top':''}" data-f="${f}"><span class="twlf">${f===N?'♛':f}</span><span class="twlm">×${twMul(f,boost).toFixed(2)}</span>${boost?`<s>×${twMul(f,false).toFixed(2)}</s>`:''}<span class="twlp"></span></div>`}).join('')}</div></aside></div>
 <p class="cmsg" id="cm"> </p><div class="ctl">${betBar()}<div class="btns"><button class="bbig" id="t0">Start climb</button><button class="bbig" id="tc" style="display:none">Cash out</button></div></div>`;
 const view=$('twview'),stack=$('twstack'),fx=$('twfx');
 const doors=r=>[...stack.querySelectorAll(`.twd[data-r="${r}"]`)];
 const row=r=>stack.querySelector(`.twf[data-r="${r}"]`);
 /* the knight stands in the tower itself: he waits at the entrance, then hops into each door you open and stays there */
 const hero=document.createElement('div');hero.className='twh';hero.innerHTML=heroSvg;
 const DX=108,hpos=(r,dx)=>{hero.style.left=`calc(50% + ${dx}px)`;hero.style.bottom=`${r*FH+10}px`};
 const place=(r,dx,anim)=>{if(hero.parentNode!==stack)stack.appendChild(hero);hero.style.transition='none';hero.style.transform='';hpos(r,dx||0);hero.className='twh'+(anim?' '+anim:'');void hero.offsetWidth};
 const moveTo=(r,dx)=>{hero.style.transition=`left ${.6*K}s cubic-bezier(.4,.1,.3,1),bottom ${.6*K}s cubic-bezier(.4,.1,.3,1)`;hero.classList.remove('hop');void hero.offsetWidth;hero.classList.add('hop');hpos(r,dx)};
 const dust=(node,n)=>{const [x,y]=pos(node);burst(x,y+36,n||10,['#d8c8a8','#a89878','#fff0d0'],46,false)};
 const scroll=(n,instant)=>{stack.style.transition=instant?'none':`transform ${.85*K}s cubic-bezier(.3,.85,.25,1)`;stack.style.transform=`translateY(${n*FH}px)`;const sk=$('twsky');sk.style.setProperty('--h',Math.min(1,n/N));if(instant)void stack.offsetHeight};
 /* particles */
 const burst=(x,y,n,cols,pw,up)=>{if(rm)n=Math.ceil(n/3);for(let i=0;i<n;i++){const p=document.createElement('i');p.className='twpt';const a=(up?-Math.PI/2+(Math.random()-.5)*2.4:Math.random()*Math.PI*2),v=(pw||90)*(.4+Math.random());p.style.cssText=`left:${x}px;top:${y}px;--dx:${Math.cos(a)*v}px;--dy:${Math.sin(a)*v}px;--s:${3+Math.random()*5}px;background:${cols[i%cols.length]};animation-duration:${(.6+Math.random()*.7)*K+.05}s`;fx.appendChild(p);setTimeout(()=>p.remove(),1600)}};
 const coinRain=n=>{if(rm)n=Math.ceil(n/3);for(let i=0;i<n;i++){const c=document.createElement('i');c.className='twrain';c.style.cssText=`left:${6+Math.random()*88}%;animation-delay:${Math.random()*1.1}s;animation-duration:${1+Math.random()*.9}s;--sz:${14+Math.random()*14}px`;fx.appendChild(c);setTimeout(()=>c.remove(),3200)}};
 const pos=node=>{const a=node.getBoundingClientRect(),b=view.getBoundingClientRect(),s=b.width/view.offsetWidth||1;return[(a.left+a.width/2-b.left)/s,(a.top+a.height/2-b.top)/s]};
 const banner=(t,cl)=>{const b=$('twbanner');b.className='twbanner';b.textContent=t;void b.offsetWidth;b.className='twbanner show '+(cl||'')};
 const flash=c=>{const f=$('twflash');f.className='twflash';f.style.setProperty('--c',c);void f.offsetWidth;f.className='twflash on'};
 const shake=()=>{view.classList.remove('twshk');void view.offsetWidth;view.classList.add('twshk')};
 /* tween number */
 let pv=0,pvT=0;const tween=to=>{const e=$('twpv');if(!e)return;const from=pv;pv=to;cancelAnimationFrame(pvT);const t0=performance.now(),d=rm?1:520;const f=t=>{const u=Math.min(1,(t-t0)/d),k=1-Math.pow(1-u,3);e.textContent=cmn(from+(to-from)*k);if(u<1&&alive())pvT=requestAnimationFrame(f)};pvT=requestAnimationFrame(f);const b=e.parentNode;b.classList.remove('pop');void b.offsetWidth;b.classList.add('pop')};
 const sfx={creak:()=>{beep(170,.1,'sawtooth',.28);setTimeout(()=>beep(140,.14,'sawtooth',.26),70)},
  safe:n=>{const b=60+n*2;[0,4,7,12].forEach((s,i)=>setTimeout(()=>beep(nf(b+s),.14,'triangle',.55),i*70))},
  trap:()=>{beep(80,.45,'sawtooth',.85);setTimeout(()=>beep(55,.5,'square',.6),90);setTimeout(()=>beep(300,.08,'square',.4),20)},
  coin:()=>{for(let i=0;i<7;i++)setTimeout(()=>beep(1200+Math.random()*900,.07,'triangle',.5),i*70)},
  hop:()=>{beep(330,.07,'triangle',.4);setTimeout(()=>beep(520,.09,'triangle',.35),160)},
  tick:()=>beep(900,.025,'triangle',.25)};
 /* panels */
 const nextPanel=()=>{const n=$('twnext');if(ph!=='play'){n.innerHTML=`<span class="twlab">How to play</span><ol class="twhow"><li><b>1</b>Set a bet and press Start</li><li><b>2</b>Pick a door. Two are safe, one is a trap</li><li><b>3</b>Safe floor? Your payout grows</li><li><b>4</b>Cash out any time, or keep climbing</li></ol>`;return}
  if(lvl>=N){n.innerHTML='';return}const nm=twMul(lvl+1,boost),np=twPay(bet,lvl+1,boost);
  n.innerHTML=`<span class="twlab">Next floor ${lvl+1}</span><div class="twodds"><span class="ok"><b>67%</b> safe<em>${np>=TW.CAP?'MAX ':''}${cmn(np)}</em></span><span class="no"><b>33%</b> trap<em>${lvl>=1?'lose '+cmn(bet):'lose '+cmn(bet)}</em></span></div><div class="twrisk"><i style="width:66.7%"></i></div><small>×${nm.toFixed(2)} if you pick right</small>`};
 const recPanel=()=>{const s=twSt();$('twrec').innerHTML=`<div><span>Best climb</span><b>${s.best?'Floor '+s.best:'-'}</b></div><div><span>Summits</span><b>${s.summits}</b></div><div><span>Climbs</span><b>${s.climbs}</b></div>`};
 const ladder=()=>{ov.querySelectorAll('#twlad .twlr').forEach(r=>{const f=+r.dataset.f;r.classList.toggle('done',ph!=='idle'&&f<=lvl);r.classList.toggle('cur',ph==='play'&&f===lvl+1);const p=r.querySelector('.twlp');const b0=ph==='idle'?CAS.bet:bet;p.textContent=b0>=1?cmn(twPay(b0,f,boost)):''})};
 const U=()=>{const pl=ph==='play';TWM.fl=pl?lvl:-1;$('t0').style.display=pl?'none':'';$('t0').disabled=busy;$('tc').style.display=pl?'':'none';$('tc').disabled=!pl||lvl<1||busy;$('tc').textContent=lvl>=1?'Cash out '+cmn(twPay(bet,lvl,boost)):'Cash out';
  $('twsub').textContent=pl?`Floor ${Math.min(lvl+1,N)} of ${N}  ·  ×${twMul(lvl,boost).toFixed(2)}`:idleSub;nextPanel();ladder();recPanel();
  doors(lvl+1).forEach(d=>{d.disabled=!(pl&&!busy)})};
 const setPay=()=>tween(twPay(bet,lvl,boost));
 /* persist so a refresh mid-climb never loses the stake */
 const saveRun=on=>{const c=cst();if(on)c.twp={b:bet,l:lvl,e:boost?1:0};else delete c.twp;save()};
 const settle=(pay)=>{cPay(bet,pay)};
 /* ending a climb */
 const endClimb=(kind,pay)=>{ph='idle';busy=true;const s=twSt();s.climbs++;if(lvl>s.best)s.best=lvl;if(kind==='summit')s.summits++;if(pay>s.top)s.top=pay;stat('twf',lvl,'max');if(kind==='summit')stat('tws',1,'add');try{achCheck()}catch(e){}};
 const cashOut=async(kind)=>{if(ph!=='play'||busy&&kind!=='auto')return;busy=true;const pay=twPay(bet,lvl,boost);saveRun(false);
  idleSub=kind==='summit'?`Summit reached at ×${twMul(lvl,boost).toFixed(2)}`:`Cashed out on floor ${lvl} at ×${twMul(lvl,boost).toFixed(2)}`;endClimb(kind==='summit'?'summit':'cash',pay);settle(pay);U();$('tc').disabled=true;
  hero.classList.remove('hop');hero.classList.add('twcheer');sfx.coin();flash('#ffd24a');
  const [cx,cy]=pos(hero);burst(cx,cy-20,36,['#ffe27a','#fff6c0','#ffb030','#fff'],140,true);coinRain(kind==='summit'?46:26);
  const capped=pay>=TW.CAP&&twMul(lvl,boost)*bet>TW.CAP;
  banner(kind==='summit'?'SUMMIT!':capped?'MAX PAYOUT':'CASHED OUT','win');
  msg(kind==='summit'?`You reached the summit! ${twMul(lvl,boost).toFixed(2)}×  +${cmn(pay-bet)}`:capped?`Maximum payout reached! Cashed out ${cmn(pay)} (+${cmn(pay-bet)}).`:`Cashed out on floor ${lvl} at ${twMul(lvl,boost).toFixed(2)}×  +${cmn(pay-bet)}`,'w');
  const tr=$('twtres');if(kind==='summit'&&tr)tr.classList.add('open');
  await wait(1700);if(!alive())return;await toEntrance();if(!alive())return;busy=false;betLock(false);$('t0').textContent='Climb again';U()};
 const trapHit=async(d,r)=>{const ds=doors(r),chosen=ds[d];idleSub=`Fell from floor ${lvl+1}. Stake lost.`;saveRun(false);endClimb('trap',0);settle(0);tween(0);U();
  chosen.classList.add('trap');sfx.trap();try{TWM.mute=ac.currentTime+2.2}catch(e){}shake();flash('#ff2a40');view.classList.add('twdanger');
  const [hx,hy]=pos(hero);hero.classList.remove('hop');hero.classList.add('twhit');burst(hx,hy-10,30,['#ff5c6c','#ff9a3a','#ffd24a'],150);
  msg(`A trap! You fall from floor ${lvl+1}. You lose ${cmn(bet)}.${broke()?' '+broke():''}`,'l');banner('TRAP!','lose');
  await wait(750);if(!alive())return;
  /* near miss: show that the other two doors were safe */
  ds.forEach((x,i)=>{if(i!==d)setTimeout(()=>{if(!alive())return;x.classList.add('open','dim');setTimeout(()=>{x.classList.add('safe');sfx.tick()},320*K)},i*260*K)});
  await wait(1500);if(!alive())return;view.classList.remove('twdanger');await toEntrance();if(!alive())return;busy=false;betLock(false);$('t0').textContent='Climb again';U()};
 const pick=async d=>{if(ph!=='play'||busy||lvl>=N)return;const r=lvl+1,ds=doors(r),chosen=ds[d];if(!chosen)return;busy=true;U();
  const isTrap=traps[lvl]===d,dx=(d-1)*DX;ds.forEach(x=>x.disabled=true);hint=-1;
  /* 1. the door shakes, then swings open onto darkness. The knight keeps waiting where he stands. */
  view.classList.add('moved');sfx.creak();chosen.classList.add('knock');await wait(300);if(!alive())return;
  chosen.classList.remove('knock');chosen.classList.add('open');dust(chosen,12);
  await wait(560);if(!alive())return;
  /* 2. he hops up into the doorway, the camera follows */
  scroll(Math.max(0,r-1),false);moveTo(r,dx);sfx.hop();
  await wait(680);if(!alive())return;
  hero.classList.remove('hop');dust(hero,8);
  if(isTrap)return trapHit(d,r);
  /* 3. safe: the door lights up, the step is final */
  lvl++;saveRun(true);chosen.classList.add('safe');
  const [cx,cy]=pos(chosen);burst(cx,cy-10,26,['#ffe27a','#fff6c0','#ffb030'],110);sfx.safe(lvl);setPay();
  banner(`Floor ${lvl} clear`,lvl>=7?'hot':'');flash('#ffe27a40');
  const ms=$('twlad').querySelector(`[data-f="${lvl}"]`);ladder();if(ms){ms.classList.add('flare');setTimeout(()=>ms.classList.remove('flare'),900)}
  const s=twSt();if(lvl>s.best){s.best=lvl;save()}
  const full=twPay(bet,lvl,boost)>=TW.CAP&&twMul(lvl,boost)*bet>=TW.CAP;
  await wait(520);if(!alive())return;
  if(lvl>=N||full){if(lvl>=N){scroll(N,false);moveTo(N+1,0);await wait(800);if(!alive())return}busy=false;ph='play';return cashOut(lvl>=N?'summit':'cap')}
  msg(`Safe! ${cmn(twPay(bet,lvl,boost))} so far. Pick a door or cash out.`,'w');
  busy=false;U()};
 /* after a climb ends the knight slips away and the tower resets with him at the entrance */
 const toEntrance=async()=>{hero.style.transition='opacity .35s,scale .35s';hero.className='twh twgo';scroll(0,false);await wait(1000);if(!alive())return;resetTower();hero.className='twh twdrop'};
 const resetTower=()=>{view.classList.remove('moved');stack.innerHTML=stackHTML();scroll(0,true);place(0,0)};
 const start=()=>{if(ph!=='idle'||busy||CAS.lock)return;if(CAS.bet<1){msg(broke()||'Place a bet first.');return}if(CAS.bet>P.gold){msg('Not enough gold.');return}
  bet=Math.min(CAS.bet,CAS_MAX);boost=twBoost();if(!cTake(bet))return;betLock(true);
  traps=Array.from({length:N},()=>Math.random()*3|0);lvl=0;ph='play';busy=false;pv=0;$('twpv').textContent='0';
  resetTower();view.classList.remove('twdanger','twshk');saveRun(true);idleSub='';
  banner('Floor 1','');sfx.safe(0);msg('Pick a door. One hides a trap.','w');U()};
 /* input */
 stack.addEventListener('click',e=>{const d=e.target.closest('.twd');if(d&&!d.disabled&&+d.dataset.r===lvl+1)pick(+d.dataset.d)});
 $('t0').onclick=start;$('tc').onclick=()=>cashOut('cash');
 const cashKey=()=>{if(ph==='play'&&lvl>=1&&!busy)cashOut('cash')};
 CAS.key={' ':()=>{ph==='idle'?start():cashKey()},enter:()=>{if(ph==='idle')start()},c:cashKey,'1':()=>pick(0),'2':()=>pick(1),'3':()=>pick(2),arrowleft:()=>pick(0),arrowup:()=>pick(1),arrowdown:()=>pick(1),arrowright:()=>pick(2)};
 wireBet(()=>{ladder()});
 /* restore an unfinished climb, cashing it out at the floor it reached */
 const c0=cst(),rs=c0.twp;
 resetTower();
 if(rs&&rs.b>=1){delete c0.twp;const b0=rs.e?1:0,pay=rs.l>=1?twPay(rs.b,rs.l,b0):rs.b;bet=rs.b;lvl=rs.l;ph='play';const s=twSt();if(lvl>s.best)s.best=lvl;s.climbs++;ph='idle';
   cPay(rs.b,pay);msg(rs.l>=1?`Your unfinished climb was cashed out on floor ${rs.l}: ${cmn(pay)} gold.`:`Your unfinished climb was refunded: ${cmn(pay)} gold.`,'w');lvl=0;bet=0;save()}
 else msg(boost?'Boosted payouts today only! Set your bet and press Start.':'Set your bet and press Start.');
 U();
}
