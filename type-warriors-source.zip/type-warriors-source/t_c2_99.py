# python3 t_c2_99.py [game.html] : Runestone Tower Defense 9.9q (97l): the second concept set - graded and detailed maps, richer and
# larger monsters, the hub (title in the top bar, the new side panel, the armory bar and championship card) and the three-column
# Tower Skins screen; no overlaps, everything clickable, bakes stay fast.
import asyncio,os,sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:500]),flush=True)
    if not ok:FAIL.append(name)
SETUP="()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const r=RPP();r.new99j=1;r.dragon=1;r.stars={moss:3,frost:2,ember:1};r.own={'ballista:gilded':1};for(const k in r.tut)r.tut[k]=1;save()}"
BOX="(s)=>{const e=document.querySelector(s);if(!e)return null;const r=e.getBoundingClientRect();return [r.left,r.top,r.right,r.bottom]}"
def over(a,b):return a and b and a[0]<b[2]-1 and b[0]<a[2]-1 and a[1]<b[3]-1 and b[1]<a[3]-1
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E(SETUP)
        # maps
        r=await E("""()=>{const out={};for(const id of ['moss','frost','ember','wonder']){delete RPBAKE[id];const t0=performance.now();const B=rpBake(RP_MAP(id));out[id]=[B._c2===1,Math.round(performance.now()-t0)]}return out}""")
        chk('every map gets the concept grade and detail once, at bake time (each bake under 1.5 s here)',all(v[0] and v[1]<1500 for v in r.values()),r)
        r=await E("""()=>{const mean=()=>{delete RPBAKE.moss;const B=rpBake(RP_MAP('moss')),d=B.c.getContext('2d').getImageData(0,0,1600,900).data;let g=0,n=0;for(let i=0;i<d.length;i+=16){g+=d[i+1];n++}return g/n};
          const G0=RPC_GRADE.moss;RPC_GRADE.moss=null;const a=mean();RPC_GRADE.moss=G0;const b=mean();return [Math.round(a),Math.round(b)]}""")
        chk('Mossgate Hollow is graded brighter and greener (mean green channel up by more than 15%)',r[1]>r[0]*1.15,r)
        r=await E("""()=>{const a=RPBAKE.moss;rpBake(RP_MAP('moss'));return RPBAKE.moss===a}""")
        chk('a baked map is graded only once (a second rpBake call returns the same canvas untouched)',r,r)
        # monsters
        r=await E("""()=>{const out=[];for(const v of ['moss','frost','ember','wonder']){const C=rpvSheet('scamp',v);out.push(!!(C&&C._c2))}return [out,RPC.mob]}""")
        chk('every monster sheet (all four map variants) is graded, and monsters are drawn 8% larger',all(r[0]) and r[1]==1.08,r)
        r=await E("""()=>{const c=document.createElement('canvas');c.width=400;c.height=400;const g=c.getContext('2d');const sz=k=>{RPC.mob=k;g.clearRect(0,0,400,400);rpMobBlit(g,'golem',200,320,0,{v:'moss'});const d=g.getImageData(0,0,400,400).data;let top=400;for(let y=0;y<400&&top===400;y++)for(let x=0;x<400;x++)if(d[(y*400+x)*4+3]>40){top=y;break}return 320-top};const a=sz(1),b2=sz(1.08);RPC.mob=1.08;return [a,b2]}""")
        chk('the larger monster is drawn about the same foot point (painted height grows by about 8%)',r[0]>0 and 1.04<r[1]/r[0]<1.12,r)
        # the hub
        await E("()=>{RPSEL='moss';rampartsMenu()}");await pg.wait_for_timeout(1300)
        r=await E("""()=>{const t=ov.querySelector('.rphtop .rphttl .rptitle');return [t&&t.textContent,!ov.querySelector('.rphl h1'),ov.querySelectorAll('.rpcm').length,ov.querySelector('.rpcbest').textContent,!!ov.querySelector('.rpccoin'),!!ov.querySelector('.rpcfw'),$('rpdef').textContent.trim().replace('›','').trim(),!!ov.querySelector('.rpcrule'),!!ov.querySelector('.rpcnr'),ov.querySelector('.rpnu').contains($('rpvr')),!!ov.querySelector('.rpcvl')]}""")
        chk('hub: title in the top bar, waves and features lines, Best box, Up to N coins, first-win chip, "Defend Mossgate", rule, next region card, View rewards under All rewards, View leaderboard',r==['Runestone Tower Defense',True,2,'Best: 3 / 3 stars',True,True,'Defend Mossgate',True,True,True,True],r)
        boxes={k:await E(BOX,k) for k in ['.rphtop','.rpside','.rparm','.rpcvl','.rpcht','#rpchcv']}
        r=[over(boxes['.rphtop'],boxes['.rpside']),over(boxes['.rpside'],boxes['.rparm']),over(boxes['.rpcvl'],boxes['.rpcht']),boxes['.rpside'][3]]
        chk('hub: the top bar, the side panel and the armory bar do not overlap; the championship text clears its button',r[:3]==[False,False,False],[r,boxes])
        r=await E("""()=>{const bs=[...ov.querySelectorAll('.rphtop .rpbk')];return bs.every(b=>b.getBoundingClientRect().height<56)}""")
        chk('hub: the top bar buttons stay on one line',r,r)
        await pg.screenshot(path=os.path.join(HERE,'shots','c2_hub.png'))
        await E("()=>ov.querySelector('.rpcnr').click()");await pg.wait_for_timeout(900)
        r=await E("()=>[RPSEL,$('rpdef').textContent.trim().replace('›','').trim(),ov.querySelector('.rpcm').textContent]")
        chk('the Next region card opens the next map (Frostfang Pass, 15 waves)',r==['frost','Defend Frostfang','15 waves'],r)
        await E("()=>{RPSEL='wonder';rampartsMenu()}");await pg.wait_for_timeout(1100)
        r=await E("()=>[!!ov.querySelector('.rpsidew'),!!$('rpdef'),!!ov.querySelector('.rpasc')]")
        chk('the Wonderland panel keeps its own layout (Ascended Towers row, Enter button)',r==[True,True,True],r)
        # Tower Skins
        await E("()=>{RPSKSEL=null;rpSkins()}");await pg.wait_for_timeout(700)
        r=await E("""()=>[ov.querySelectorAll('.rpcsn').length,ov.querySelector('.rpcsn.on').dataset.tw,ov.querySelectorAll('.rpskt').length,ov.querySelector('.rpcsm h3').textContent,ov.querySelector('.rpcst h3').textContent,ov.querySelector('.rpcstat').textContent,!!ov.querySelector('.rpcend'),$('rpskeq').textContent,ov.querySelectorAll('.rpcms').length]""")
        chk('Tower Skins: ten towers on the left, the Dragon Roost skins, the Azure Dragon locked with the championship end and View championship, four milestones',r==[10,'dragon',2,'Dragon Roost Skins','Azure Dragon','Locked',True,'View championship ›',4],r)
        await pg.screenshot(path=os.path.join(HERE,'shots','c2_skins.png'))
        boxes=[await E(BOX,k) for k in ['.rpcsl','.rpcsm','.rpcsr','.rpcskh']]
        chk('Tower Skins: the three columns and the header do not overlap and stay on the stage',not any(over(boxes[i],boxes[j]) for i in range(4) for j in range(i+1,4)) and all(x[2]<=1600 and x[3]<=900 for x in boxes),boxes)
        await E("()=>ov.querySelector('.rpcsn[data-tw=\"ballista\"]').click()");await pg.wait_for_timeout(300)
        r=[await E("()=>[ov.querySelector('.rpcsm h3').textContent,RPSKSEL.k,ov.querySelector('.rpcsk.eq').dataset.k]")]
        await E("()=>ov.querySelector('.rpskt[data-k=\"gilded\"]').click()");await pg.wait_for_timeout(300)
        r.append(await E("()=>[RPP().skin.ballista,ov.querySelector('.rpcstat').textContent,$('rpskeq').textContent]"))
        await E("()=>$('rpskeq').click()");await pg.wait_for_timeout(300);r.append(await E("()=>RPP().skin.ballista"))
        chk('choosing a tower shows its equipped skin; clicking an owned skin equips it; Unequip goes back to Classic',r==[['Rune Ballista Skins','base','base'],['gilded','Equipped','Unequip'],'base'],r)
        await E("()=>ov.querySelector('.rpcsn[data-tw=\"brazier\"]').click()");await pg.wait_for_timeout(200)
        await E("()=>ov.querySelector('.rpskt[data-k=\"azure\"]').click()");await pg.wait_for_timeout(300)
        r=await E("()=>[RPP().skin.brazier||'base',ov.querySelector('.rpcstat').textContent,$('rpskeq')===null,!!ov.querySelector('.rpcbar'),ov.querySelector('.rpskbt button').disabled]")
        chk('a locked star skin cannot be equipped and shows the stars needed with a progress bar',r==['base','Locked',True,True,True],r)
        await E("()=>ov.querySelector('.rpcsn[data-tw=\"dragon\"]').click()");await pg.wait_for_timeout(200)
        await E("()=>ov.querySelector('.rpskt[data-k=\"base\"]').click()");await pg.wait_for_timeout(300)
        r=await E("()=>{const g=$('rpskcv').getContext('2d'),d=g.getImageData(0,0,520,430).data;let n=0;for(let i=3;i<d.length;i+=4)if(d[i]>40)n++;return n>4000}")
        chk('the classic Dragon Roost previews as itself (not the Azure Dragon)',r,r)
        await E("()=>$('rpskback').click()");await pg.wait_for_timeout(900)
        chk('Back returns to the hub',await E("()=>!!ov.querySelector('.rphub')"))
        # in battle
        await E("()=>{rpStart('ember');RPX.tut=null;RPX.wave=3;rpWaveStart();for(let i=0;i<30*8;i++)rpStep(RPX,1/30)}");await pg.wait_for_timeout(800)
        await pg.screenshot(path=os.path.join(HERE,'shots','c2_battle.png'))
        r=await E("""()=>{const R=RPX,c=ctx;let t0=performance.now();for(let i=0;i<40;i++)rpDraw();return +((performance.now()-t0)/40).toFixed(2)}""")
        chk('a battle frame with the graded map and larger monsters still draws quickly (under 25 ms in headless Chromium)',r<25,r)
        await E("()=>rpLeave()")
        chk('no page errors',not er,er)
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
