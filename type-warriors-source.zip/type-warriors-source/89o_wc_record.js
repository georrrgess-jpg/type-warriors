/* ===== WILDCARD: Your Record (statistics) and the Card Back Vault =====
   Two full screens reached from the Wildcard home. The record shows a profile with a win-rate ring and a lounge rank,
   highlight tiles that count up, the last eight games as 1st/2nd/3rd/4th with the gold won or lost, and wins per
   table. The vault holds the nine card backs: rarity tiers, progress toward every locked back, a large preview that
   tilts with the pointer, and Equip. Newly unlocked backs carry a NEW badge until they are looked at. */
const WCPL=['1st','2nd','3rd','4th'];
const WCRK=[[0,'Newcomer','#c8bfa8'],[4,'Regular','#7ae07a'],[12,'Card Shark','#5ab8ff'],[30,'High Roller','#c87aff'],[60,'Lounge Legend','#ffb02a']];
const wcRank2=W=>{let r=WCRK[0];for(const x of WCRK)if(W.w>=x[0])r=x;return [r[1],r[2]]};
const wcRankNext=W=>WCRK.find(x=>W.w<x[0]);
const wcTblName=k=>WCT[k]?WCT[k].n:k==='pp'?'Same screen':k==='net'?'Room code':k==='e'?'Old Easy table':k==='m'?'Old Medium table':k==='h'?'Old Hard table':'Table';
const WCI2={cards:'<svg viewBox="0 0 24 24"><rect x="3" y="5" width="11" height="15" rx="2" fill="none" stroke="currentColor" stroke-width="2" transform="rotate(-10 8 12)"/><rect x="10" y="4" width="11" height="15" rx="2" fill="currentColor" opacity=".85" transform="rotate(8 15 11)"/></svg>',
 lock:'<svg viewBox="0 0 24 24"><rect x="5" y="10" width="14" height="11" rx="2.5" fill="currentColor"/><path d="M8 10V7a4 4 0 0 1 8 0v3" fill="none" stroke="currentColor" stroke-width="2.4"/></svg>',
 flame:'<svg viewBox="0 0 24 24"><path d="M12 2c4 5 7 8 6 13a6 6 0 0 1-12 0c0-4 3-5 3-9 2 2 3 3 3 5 1-3 0-6 0-9z" fill="currentColor"/></svg>'};
/* numbers that count up when a screen opens */
function wcCountUp(root){root.querySelectorAll('[data-cu]').forEach(el=>{const to=+el.dataset.cu,pre=el.dataset.pre||'',suf=el.dataset.suf||'';if(wcRM()||!isFinite(to)){el.textContent=pre+cmn(Math.abs(to))+suf;return}
 const t0=performance.now(),d=900;const step=t=>{const k=Math.min(1,(t-t0)/d),e=1-Math.pow(1-k,3);el.textContent=pre+cmn(Math.round(Math.abs(to)*e))+suf;if(k<1&&el.isConnected)requestAnimationFrame(step)};requestAnimationFrame(step)})}
/* ---------- Your Record ---------- */
function wcStats(){WX.tok++;wcClear();const W=wcSt(),rate=W.g?Math.round(W.w/W.g*100):0,[rk,rc]=wcRank2(W),C=2*Math.PI*78;
 const tile=(ic,l,v,o)=>`<div class="wcrt" style="--d:${o.d||0}"><span class="wcrti" style="--c:${o.c||'#ffd45a'}">${ic}</span><span><small>${l}</small><b ${o.raw?'':`data-cu="${v}" data-pre="${o.pre||''}" data-suf="${o.suf||''}"`}>${o.raw||'0'}</b>${o.sub?`<em>${o.sub}</em>`:''}</span></div>`;
 const ic=p=>`<svg viewBox="0 0 24 24">${p}</svg>`;
 const tiles=[tile(ic('<rect x="4" y="5" width="10" height="14" rx="2" fill="currentColor"/><rect x="10" y="3" width="10" height="14" rx="2" fill="none" stroke="currentColor" stroke-width="2"/>'),'Games played',W.g,{d:0}),
  tile(ic('<path d="M3 8l4.5 3.6L12 4.5l4.5 7.1L21 8l-1.8 10.5H4.8z" fill="currentColor"/>'),'Wins',W.w,{d:1,sub:rate+'% win rate'}),
  tile(ic('<circle cx="12" cy="12" r="9" fill="currentColor"/><text x="12" y="16.5" text-anchor="middle" font-size="12" font-weight="900" fill="#2a1406">$</text>'),'Gold won',W.net,{d:2,c:W.net>=0?'#8ae060':'#ff8a98',pre:W.net>=0?'+':'−',sub:'all time, after buy-ins'}),
  tile(WCI2.flame,'Best streak',W.best,{d:3,c:'#ff8a3a',sub:W.cur?`on a ${W.cur}-game streak now`:'wins in a row'}),
  tile(ic('<circle cx="12" cy="13" r="8" fill="none" stroke="currentColor" stroke-width="2.4"/><path d="M12 9v4l3 2M9 2h6" stroke="currentColor" stroke-width="2.4" fill="none" stroke-linecap="round"/>'),'Fastest win',W.fast,{d:4,c:'#6ab8ff',raw:W.fast?null:'–',suf:' turns'}),
  tile(ic('<path d="M5 19L12 4l7 15z" fill="currentColor"/>'),'Cards played',W.cards,{d:5,c:'#d0a8ff'}),
  tile(ic('<path d="M12 3l8 4.5v9L12 21l-8-4.5v-9z" fill="currentColor"/>'),'+4 Hex played',W.d4,{d:6,c:'#c87aff'}),
  tile(ic('<circle cx="12" cy="12" r="9" fill="currentColor"/><text x="12" y="15.5" text-anchor="middle" font-size="8" font-weight="900" fill="#fff">W!</text>'),'WILD! calls',W.ones,{d:7,c:'#ff5a6a'}),
  tile(ic('<path d="M4 12a8 8 0 1 0 16 0 8 8 0 1 0-16 0M12 8v4M12 16h0" stroke="currentColor" stroke-width="2.6" fill="none" stroke-linecap="round"/>'),'Catches',W.catches,{d:8,c:'#ffd45a',sub:'forgotten WILD!s you caught'}),
  tile(ic('<path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>'),'Times caught',W.caught,{d:9,c:'#ff8a98',sub:'your forgotten WILD!s'})].join('');
 const hist=W.hist.slice(-6).reverse(),recent=hist.length?hist.map((h,i)=>`<div class="wcrg2" style="--d:${i}"><span class="wcpl p${Math.min(3,h.p)}">${WCPL[Math.min(3,h.p)]}</span><span class="wcrgt"><b>${esc(wcTblName(h.k))}</b><small>${h.p===0?'Won the pot':h.p===1?'Runner-up':'Out of the money'}</small></span><b class="${h.n>=0?'up':'dn'}">${h.n>=0?'+':'−'}${cmn(Math.abs(h.n))}</b></div>`).join('')
  :'<p class="wcempty">No games yet. Take a seat and your last six results will appear here.</p>';
 const rows=[...WCTK,'pp','net'].map(k=>{const b=W.byd[k];const p=b.g?Math.round(b.w/b.g*100):0;return `<div class="wcbt">${WCT[k]?wcChip(k,30):`<span class="wcbti">${k==='pp'?WCI.users:WCI.globe}</span>`}<span>${esc(wcTblName(k))}</span><div class="wcsb"><i style="--w:${p}%"></i></div><b>${b.w}/${b.g}</b></div>`}).join('');
 show(`<div class="wcrec" id="wcrec"><div class="wclbg"><i class="wcspot a"></i><i class="wcspot b"></i></div>
 <header class="wclh"><button class="wcpb back" id="wcrb">${WCI.back}<span>Wildcard</span></button><h1>Your Record</h1><button class="wcpb" id="wcrv">${WCI2.cards}<span>Card Back Vault</span></button></header>
 <section class="wcrp1"><div class="wcpor"><canvas width="220" height="220" id="wcrpc"></canvas></div><h2>${esc(P.name||'Hero')}</h2><span class="wcrank" style="--c:${rc}">${rk}</span>
  <div class="wcring2"><svg viewBox="0 0 180 180"><circle cx="90" cy="90" r="78" class="bg"/><circle cx="90" cy="90" r="78" class="fg" style="stroke-dasharray:${C};--off:${C*(1-rate/100)};--full:${C}"/></svg><div><b data-cu="${rate}" data-suf="%">0%</b><small>win rate</small></div></div>
  ${(()=>{const nx=wcRankNext(W),cur=[...WCRK].reverse().find(x=>W.w>=x[0]);return nx?`<div class="wcrkp"><small>Next rank: <b style="color:${nx[2]}">${nx[1]}</b> at ${nx[0]} wins</small><span class="wcvp big"><i style="--w:${Math.round((W.w-cur[0])/(nx[0]-cur[0])*100)}%"></i></span><em>${nx[0]-W.w} more win${nx[0]-W.w>1?'s':''} to go</em></div>`:`<div class="wcrkp"><small>Top rank reached. The lounge bows to you.</small></div>`})()}
  <div class="wcwl"><div><b data-cu="${W.w}">0</b><small>Wins</small></div><div><b data-cu="${W.g-W.w}">0</b><small>Losses</small></div><div class="st"><b>${WCI2.flame}<span data-cu="${W.cur}">0</span></b><small>Streak</small></div></div></section>
 <section class="wcrp2"><h4>Highlights</h4><div class="wcrts">${tiles}</div>
  <h4 class="wcsp">Gold per game · last 12</h4><div class="wcspark">${(()=>{const L=W.hist.slice(-12),mx=Math.max(1,...L.map(h=>Math.abs(h.n)));return L.length?L.map((h,i)=>`<i class="${h.n>=0?'up':'dn'}" style="--h:${Math.round(6+Math.sqrt(Math.abs(h.n)/mx)*40)}px;--d:${i}" title="${h.n>=0?'+':'−'}${cmn(Math.abs(h.n))}"></i>`).join(''):'<p class="wcempty">Play a few games to see your gold swing.</p>'})()}</div></section>
 <section class="wcrp3"><h4>Recent games</h4><div class="wcrgs">${recent}</div><h4>Wins by table</h4><div class="wcbts">${rows}</div></section>
 <div class="wcmod" id="wcmod" hidden></div></div>`,'casbg wcx');
 S.back=wcHome;$('wcrb').onclick=()=>{wcFx('back');wcHome()};$('wcrv').onclick=()=>{wcFx('click');wcVault()};
 const cv=$('wcrpc');try{wcPortrait(cv,wcMyAv())}catch(e){}wcCountUp($('wcrec'));wcFx('vault')}
/* ---------- the Card Back Vault ---------- */
function wcVault(sel){WX.tok++;wcClear();const W=wcSt();if(!W.seen||typeof W.seen!=='object')W.seen={classic:1};const own=WCBKK.filter(k=>W.backs[k]).length;
 sel=WCBK[sel]?sel:(WCBK[W.back]?W.back:'classic');
 const tileH=k=>{const B=WCBK[k],o=W.backs[k],[h,g]=B.need(W),p=Math.min(100,Math.round(Math.min(h,g)/g*100));return `<button class="wcvt r${B.r}${o?'':' lk'}${k===sel?' sel':''}" data-vk="${k}" style="--rc:${WCRARC[B.r]};--d:${WCBKK.indexOf(k)}" aria-label="${esc(B.n)}, ${WCRAR[B.r]}${o?'':', locked'}">
  <span class="wcvc">${wcBack(k)}${o?'':`<i class="wclk">${WCI2.lock}</i>`}${o&&!W.seen[k]?'<em class="wcnew">NEW</em>':''}${W.back===k&&o?'<em class="wceq">IN USE</em>':''}</span><b>${esc(B.n)}</b><small style="color:${WCRARC[B.r]}">${WCRAR[B.r]}</small>
  ${o?'':`<span class="wcvp"><i style="--w:${p}%"></i></span><small class="wcvh">${B.r===5?'???':cmn(Math.min(h,g))+' / '+cmn(g)}</small>`}</button>`};
 show(`<div class="wcvault" id="wcvault"><div class="wclbg"><i class="wcspot a"></i><i class="wcspot b"></i></div>
 <header class="wclh"><button class="wcpb back" id="wcvb">${WCI.back}<span>Wildcard</span></button><h1>Card Back Vault</h1><div class="wcvcnt"><b>${own} / ${WCBKK.length}</b><small>collected</small><span><i style="--w:${own/WCBKK.length*100}%"></i></span></div><button class="wcpb" id="wcvs">${WCI.chart}<span>Your Record</span></button></header>
 <section class="wcvpv" id="wcvpv"></section><section class="wcvgrid">${WCBKK.map(tileH).join('')}</section><div class="wcmod" id="wcmod" hidden></div></div>`,'casbg wcx');
 S.back=wcHome;$('wcvb').onclick=()=>{wcFx('back');wcHome()};$('wcvs').onclick=()=>{wcFx('click');wcStats()};
 const pick=k=>{sel=k;ov.querySelectorAll('[data-vk]').forEach(b=>b.classList.toggle('sel',b.dataset.vk===k));wcVaultPv(k);if(W.backs[k]&&!W.seen[k]){W.seen[k]=1;save();const e=ov.querySelector(`[data-vk="${k}"] .wcnew`);if(e)e.remove()}};
 ov.querySelectorAll('[data-vk]').forEach(b=>{b.onclick=()=>{wcFx(W.backs[b.dataset.vk]?'flip':'bad');pick(b.dataset.vk)};b.onmouseenter=()=>wcFx('hover')});pick(sel);wcFx('vault')}
function wcVaultPv(k){const W=wcSt(),B=WCBK[k],o=W.backs[k],[h,g]=B.need(W),p=Math.min(100,Math.round(Math.min(h,g)/g*100)),eq=W.back===k,pv=$('wcvpv');if(!pv)return;
 pv.style.setProperty('--rc',WCRARC[B.r]);pv.innerHTML=`<div class="wcvbig${o?'':' lk'}" id="wcvbig"><div class="wcvin">${wcBack(k)}<i class="wcvsh"></i>${o?'':`<i class="wclk big">${WCI2.lock}</i>`}</div></div>
 <div class="wcvinfo"><span class="wcrar" style="--c:${WCRARC[B.r]}">${WCRAR[B.r]}</span><h2>${esc(B.n)}</h2><p>${esc(B.fl)}</p>
 <div class="wcvreq${o?' ok':''}"><small>${o?'Unlocked':'How to unlock'}</small><b>${esc(B.how)}</b>${o?'':`<span class="wcvp big"><i style="--w:${p}%"></i></span><em>${B.r===5?'Find the secret word':cmn(Math.min(h,g))+' / '+cmn(g)+(p>=70?' · almost there!':'')}</em>`}</div>
 <button class="wcbtn ${o?(eq?'ok':'gold'):'dark'} big" id="wcveq" ${o&&!eq?'':'disabled'}>${o?(eq?'✓ In use on your cards':'Use this card back'):`${WCI2.lock} Locked`}</button></div>`;
 const big=$('wcvbig');big.classList.remove('in');void big.offsetWidth;big.classList.add('in');
 big.onpointermove=e=>{if(wcRM())return;const r=big.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;big.style.setProperty('--rx',(-y*16)+'deg');big.style.setProperty('--ry',(x*20)+'deg');big.style.setProperty('--sx',(x*100+50)+'%')};
 big.onpointerleave=()=>{big.style.setProperty('--rx','0deg');big.style.setProperty('--ry','0deg')};
 const b=$('wcveq');if(b&&o&&!eq)b.onclick=()=>{W.back=k;save();wcFx('equip');wcVault(k)}}
