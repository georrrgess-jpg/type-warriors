/* ===== RUNESTONE TOWER DEFENSE 10.2: the Moonblade Sentinel in battle (99b, after 99a) =====
   The thirteenth tower (key M, 300 supply, ground and air; UPDATE_10_2_PLAN.md section 1), the value pick.
   The statue winds up (RPMBL.wind s, the arm swings back over the helm) and hurls a spinning crescent glaive. The glaive flies a
   boomerang loop on the ground plane: out along a curve that passes through the target's predicted spot (rpqLand) and on to the edge of
   the tower's range, then back on the other side of the loop to the statue's hand (the catch: a small recoil). It cuts every monster it
   passes through, ground or air, once on the way out and once on the way back (a set of hit monsters per pass); damage per pass
   RP_TW.moon.dmg, armor-piercing RP_TW.moon.ap. It throws again when its glaives are home and the reload (cd) has run down.
   The loop: in ground-plane units (y / RPFX.sq, the same metric as rpD2 and the range), the out leg is a quadratic curve from the hand H to
   the far point F (distance = range from H) bulging RPMBL.bulge of its chord to one side; F is turned (rpmbSolve) so the curve runs through
   the target. The way back bulges RPMBL.back to the other side.
   Tier 2 Keen Edge: sharper, faster glaives. Tier 3 Twin Moons: one glaive from each hand, on mirrored curves through the same target.
   Tier 4 (Mythic) Moonlit Wake: where a glaive crosses the road it leaves a silver wake (RPMBL.wakeLife s); ground monsters that touch it
   are slowed RPMBL.wakeK for RPMBL.wakeT s (never on top of a stronger slow, never while slow-immune, never stacking).
   Tier 5 (Celestial) Eclipse: a third glaive (from over the helm, at the next target), and every RPMBL.eclN-th throw an eclipse crescent
   circles the tower for RPMBL.eclT s at RPMBL.eclR of its range and cuts everything it touches (RPMBL.eclDmg, once per RPMBL.eclRe s each).
   Target modes: First / Strong / Close pick the target (tw.prio). Overcharge: the reload and the wind-up run RPT.AB.over.k faster, the
   glaives fly RPMBL.overV x faster and hit 15% harder. Jams (tw.jam, 98b): no new throw; glaives in flight lose their edge and fly straight
   home without cutting. Hidden monsters (e.hide: dive, leap, glimmer) are never picked or cut; a fogged monster (Shipwreck Cove) further
   than map.fogNear from the tower is never picked (a glaive already flying still cuts what it passes). Range: RP_TW.moon.range x tw.rangeK
   or the Glowcap bonus tw.glowK (Kraken's Maw). Damage goes through rpHurt with the tower as the source (marks, pollen, damage meters).
   The fire routine is wrapped last (after 98b's jam and 98p's veil), so it repeats those two: a jammed tower runs the inner chain (98b
   counts the jam down), otherwise 98p's rpiaVeil hides hidden and fogged monsters while it aims.
   Drawing: R.lite / Performance mode drops the motion trails, sparks and wake glints; reduced motion (R.rm) drops the trails and sparks.
   State on RPX: mbGl [glaives], mbWake [{x,y,t,d,tier,rot}], mbEcl [{tw,t,d,a0,dir,hit:Map}], mbFx [sparks], mbThrows, mbHits, mbEclN,
   mbEclHits, mbWakeN. Tower: tw.mbW (wind-up 0..1), tw.mbT (follow-through), tw.mbC (catch recoil), tw.mbSide (throwing hand, tiers 1-2),
   tw.mbHold [left, right, helm] (glaive home), tw.mbOut (glaives in flight), tw.nv (throws). Monster: e.mbWk (wake slow left, s), e._mk. */
RP_TW.moon={cost:[300,220,420,850,1450],range:[210,225,240,255,270],dmg:[36,54,80,122,182],cd:[1.4,1.3,1.2,1.1,1],glaives:[1,1,2,2,3],ap:[2,3,99,99,99],air:1,ground:1,
 desc:'Hurls crescent glaives that fly out through the target and boomerang back, cutting every monster they pass, both ways.',
 up:['Keen Edge: sharper, faster glaives that pierce more armor.','Twin Moons: a glaive in each hand, thrown on mirrored curves; armor no longer matters.','Moonlit Wake: glaives leave a silver wake on the road that slows monsters 20%.','Eclipse: a third glaive, and every fifth throw an eclipse crescent circles the tower for 3 s, cutting everything it touches.']};
RP_TWORDER.push('moon');RP_KEYS.push('M');
const RPMBL={spd:[560,620,660,700,740],bulge:.24,back:.1,hit:22,hitW:.3,wind:.2,cruise:30,overV:2.1,
 wakeK:.2,wakeT:1.5,wakeLife:2,wakeGap:16,wakeRoad:30,wakeR:22,eclN:5,eclT:3,eclR:.56,eclW:34,eclSpan:.34,eclSpd:2.4,eclDmg:180,eclRe:.8,f:0};
const rpmbK=()=>{try{return RPG.off?1:(RPG.k||1)}catch(e){return 1}};
const rpmbMs=()=>{try{return RPC.mob||1}catch(e){return 1}};
/* the tower's reach: its tier's range x the map's bonus (tw.rangeK, or the Glowcap tw.glowK) */
function rpmbRange(tw){const k=tw.rangeK||(tw.glowK>1?tw.glowK:1);return RP_TW.moon.range[tw.tier-1]*k}
/* can a glaive cut this monster now; can the tower pick it (fog) */
function rpmbCan(e){if(!e||e.dead||e.s<0)return false;try{if(typeof rpwCanHit==='function')return !!rpwCanHit(e)}catch(x){}return !(e.hide||e.dive>0||e.leap>0||e.glim>0)}
function rpmbSee(R,tw,e){const fn=R.map&&R.map.fogNear;if(fn&&e.fogd&&tw){const q=rpPos(R,e);if(rpD2(q.x,q.y,tw.x,tw.y)>fn*fn)return false}return true}
function rpmbSfx(k){try{const n=performance.now();if(k==='throw'){beep(520+Math.random()*60,.07,'triangle',.06);setTimeout(()=>beep(880,.05,'sine',.04),40)}
 else if(k==='cut'){if(n-(RPMBL.f||0)<70)return;RPMBL.f=n;beep(1900+Math.random()*500,.03,'square',.03)}
 else if(k==='catch'){beep(1320,.06,'triangle',.06);setTimeout(()=>beep(990,.08,'sine',.05),35)}
 else if(k==='eclipse'){[392,523,659,784].forEach((f,j)=>setTimeout(()=>beep(f,.12,'triangle',.08),j*60));setTimeout(()=>beep(110,.4,'sawtooth',.06),40)}
 else if(k==='wake'){beep(1560+Math.random()*300,.04,'sine',.025)}}catch(e){}}
{const s0=rpSfx;rpSfx=function(k,v){if(typeof k==='string'&&k.slice(0,2)==='mb')return rpmbSfx(k.slice(2).toLowerCase());return s0.apply(this,arguments)}}
/* ---------- geometry (ground plane: X = x, Y = y / sq) ---------- */
const rpmbQ=(a,c,b,u)=>{const v=1-u;return{X:v*v*a.X+2*u*v*c.X+u*u*b.X,Y:v*v*a.Y+2*u*v*c.Y+u*u*b.Y}};
/* the hand a glaive leaves from (slot 0 = left hand at tier 3+ or the throwing hand, 1 = right hand, 2 = over the helm) */
function rpmbHandW(tw,slot,a){const K=rpmbK(),tier=tw.tier,L=RPLAY.moon[rpmbT(tier)];let p;
 if(slot===2)p={x:0,y:L.py-59*L.s-26*L.s};else{const side=tier>=3?(slot===0?-1:1):(tw.mbSide||1);p=rpmbHand(tier,side,a==null?RPMB_A.rel:a)}
 return{x:tw.x+p.x*K,y:tw.y+4,h:4-p.y*K}}
/* the loop through target point T (plane) from hand H: bulge side s; returns {P0,C1,P2,C2,L1,L2} */
function rpmbSolve(H,T,reach,s,O){const dx=T.X-H.X,dy=T.Y-H.Y,dT=Math.hypot(dx,dy)||1,th=Math.atan2(dy,dx),b=RPMBL.bulge;let L=reach,al=0,ph=th;
 /* the chord H -> F ends on the range circle round the tower O (the hand is a little off centre) */
 for(let it=0;it<3;it++){const q=Math.min(.96,dT/L);al=Math.atan(2*b*s*(1-q));for(let k=0;k<4;k++)al=Math.atan(2*b*s*(1-q*Math.cos(al)));ph=th-al;
  if(O){const ox=H.X-O.X,oy=H.Y-O.Y,c=ox*Math.cos(ph)+oy*Math.sin(ph),D=c*c-(ox*ox+oy*oy)+reach*reach;L=Math.max(dT*1.05,-c+Math.sqrt(Math.max(0,D)))}}
 const cx=Math.cos(ph),cy=Math.sin(ph),px=-cy,py=cx,F={X:H.X+cx*L,Y:H.Y+cy*L},M={X:(H.X+F.X)/2,Y:(H.Y+F.Y)/2};
 return{P0:H,P2:F,C1:{X:M.X+px*b*s*L,Y:M.Y+py*b*s*L},C2:{X:M.X-px*RPMBL.back*s*L,Y:M.Y-py*RPMBL.back*s*L},L1:L*(1+8/3*b*b),L2:L*(1+8/3*RPMBL.back*RPMBL.back)}}
/* the targets in range by the tower's Target setting (best first) */
function rpmbTargets(R,tw,n){const rg=rpmbRange(tw),r2=rg*rg,L=[];for(const e of R.foes){if(!rpmbCan(e))continue;const q=rpPos(R,e),d2=rpD2(q.x,q.y,tw.x,tw.y);if(d2>r2||!rpmbSee(R,tw,e))continue;
  L.push([tw.prio==='strong'?e.hp:tw.prio==='close'?-d2:e.s/rpLen(R,e),e])}L.sort((a,b)=>b[0]-a[0]);return L.slice(0,n||1).map(x=>x[1])}
/* plan one throw: for each glaive, its slot, hand, target and loop */
function rpmbPlan(R,tw,tg){const T=RP_TW.moon,i=tw.tier-1,n=T.glaives[i],sq=RPFX.sq,reach=rpmbRange(tw),ov=tw.over>0,v=RPMBL.spd[i]*(ov?RPMBL.overV:1),out=[];
 const e0=tg[0],q0=rpPos(R,e0);if(tw.tier<3)tw.mbSide=q0.x<tw.x-4?-1:q0.x>tw.x+4?1:(tw.mbSide||1);
 for(let k=0;k<n;k++){const slot=n===1?0:k,e=k<2?e0:(tg[1]||e0),Hw=rpmbHandW(tw,slot),H={X:Hw.x,Y:Hw.y/sq};
  const qe=rpPos(R,e),ft=Math.hypot(qe.x-H.X,qe.y/sq-H.Y)/v*1.05,Lp=typeof rpqLand==='function'?rpqLand(R,e,ft):qe,Tp={X:Lp.x,Y:Lp.y/sq};
  /* the side a glaive bulges to: towards its own hand; the twin goes the other way */
  const dx=Tp.X-H.X,dy=Tp.Y-H.Y,dd=Math.hypot(dx,dy)||1,px=-dy/dd,hs=slot===2?0:tw.tier>=3?(slot===0?-1:1):(tw.mbSide||1);
  let s=Math.abs(px)>.3&&hs?(px*hs>0?1:-1):((tw.nv||0)%2?1:-1);if(n>1&&k===1)s=-out[0].s;
  const O={X:tw.x,Y:tw.y/sq};let L=rpmbSolve(H,Tp,reach,s,O);
  /* a lone glaive (tiers 1-2, and the third at tier 5) takes the side whose loop sweeps more monsters */
  if(n===1||k===2){const L2=rpmbSolve(H,Tp,reach,-s,O),a=rpmbSweep(R,L),b=rpmbSweep(R,L2);if(b>a){s=-s;L=L2}}
  out.push(Object.assign(L,{slot,s,e,h0:Hw.h,v}))}return out}
/* how many monsters a loop would cut (the current positions, sampled along both legs) */
function rpmbSweep(R,L){const sq=RPFX.sq,P=[];for(let k=1;k<=12;k++){const u=k/12;P.push(rpmbQ(L.P0,L.C1,L.P2,u),rpmbQ(L.P2,L.C2,L.P0,u))}let n=0;
 for(const e of R.foes){if(!rpmbCan(e))continue;const q=rpPos(R,e),X=q.x,Y=q.y/sq,r=rpmbHitR(e)+6,r2=r*r;let a=0,b=0;for(let j=0;j<P.length;j++){const d=(P[j].X-X)**2+(P[j].Y-Y)**2;if(d<r2){if(j%2)b=1;else a=1}}n+=a+b}return n}
function rpmbThrow(R,tw,tg){const T=RP_TW.moon,i=tw.tier-1,ov=tw.over>0,P=rpmbPlan(R,tw,tg);tw.nv=(tw.nv||0)+1;R.mbThrows=(R.mbThrows||0)+1;
 for(const p of P){R.mbGl.push({tw,tier:tw.tier,slot:p.slot,P0:p.P0,C1:p.C1,P2:p.P2,C2:p.C2,L1:p.L1,L2:p.L2,u:0,X:p.P0.X,Y:p.P0.Y,h:p.h0,h0:p.h0,v:p.v,spin:Math.random()*TAU,sd:p.s,
   dmg:T.dmg[i]*(ov?1.15:1),ap:T.ap[i],hitO:new Set(),hitB:new Set(),tr:[],tt:0,wd:0,home:0});tw.mbHold[p.slot]=0}
 tw.mbOut=P.length;tw.mbW=0;tw.mbT=1;tw.fire=1;tw.cd=T.cd[i];
 /* tier 5: every eclN-th throw an eclipse circles the tower */
 if(tw.tier>=5&&tw.nv%RPMBL.eclN===0){const q=rpPos(R,tg[0]);R.mbEcl.push({tw,t:0,d:RPMBL.eclT,a0:Math.atan2(q.y/RPFX.sq-tw.y/RPFX.sq,q.x-tw.x),dir:tw.nv%2?1:-1,hit:new Map(),tier:tw.tier});R.mbEclN=(R.mbEclN||0)+1;
  R.shake=Math.max(R.shake||0,2);rpmbSfx('eclipse');try{ptBurst(R.fx,tw.x,tw.y-rpTowerTop('moon',5)*.7,R.lite?6:16,['#fff6d8','#ffe27a','#9ae8ff','#ffffff'],{v:220,s:3.4,k:'star'})}catch(x){}}
 rpmbSfx('throw')}
/* the fire routine: wind up while a target is in range and the glaives are home, throw when the reload has run down */
function rpmbFire(R,tw,dt){const T=RP_TW.moon,i=tw.tier-1,sk=tw.over>0?RPT.AB.over.k:1;tw.over=Math.max(0,(tw.over||0)-dt);rpmbSync(tw);
 tw.fire=Math.max(0,(tw.fire||0)-dt*3);tw.cd=(tw.cd||0)-dt*sk;
 const home=!(tw.mbOut>0),tg=home&&tw.cd<=RPMBL.wind?rpmbTargets(R,tw,T.glaives[i]>2?2:1):[];
 if(tg.length){const q=rpPos(R,tg[0]);tw.aim=Math.atan2(q.y-tw.y,q.x-tw.x);if(tw.tier<3&&tw.mbW<=0)tw.mbSide=q.x<tw.x-4?-1:q.x>tw.x+4?1:(tw.mbSide||1);
  tw.mbW=Math.min(1,(tw.mbW||0)+dt*sk/RPMBL.wind);if(tw.cd<=0&&tw.mbW>=1)rpmbThrow(R,tw,tg)}
 else{tw.mbW=Math.max(0,(tw.mbW||0)-dt*4);if(tw.cd<0)tw.cd=0}}
/* the hold slots match the tier (an upgrade hands the statue its new glaives) */
function rpmbSync(tw){const n=RP_TW.moon.glaives[tw.tier-1];if(!tw.mbHold)tw.mbHold=[1,1,1];if(!(tw.mbOut>0))tw.mbHold=[1,1,1];else for(let k=n;k<3;k++)tw.mbHold[k]=1}
/* ---------- the glaives in flight ---------- */
const rpmbDistSeg=(px,py,ax,ay,bx,by)=>{const dx=bx-ax,dy=by-ay,l=dx*dx+dy*dy;let u=l?((px-ax)*dx+(py-ay)*dy)/l:0;u=u<0?0:u>1?1:u;const x=ax+dx*u-px,y=ay+dy*u-py;return Math.sqrt(x*x+y*y)};
function rpmbHitR(e){const M=RPMOB[e.id]||{w:40};return RPMBL.hit+(M.w||40)*rpmbMs()*RPMBL.hitW}
/* road samples in 32 px cells, so a wake mark knows if it is on the road */
function rpmbRoad(R,x,y){const G=R.G;if(!G||!G.U)return false;let M=G._mbG;if(!M){M=G._mbG=new Map();for(const q of G.U){const k=(q.x>>5)*1024+(q.y>>5);let L=M.get(k);if(!L)M.set(k,L=[]);L.push(q)}}
 const r=RPMBL.wakeRoad,cx=x>>5,cy=y>>5;for(let i=cx-1;i<=cx+1;i++)for(let j=cy-1;j<=cy+1;j++){const L=M.get(i*1024+j);if(L)for(const q of L)if((q.x-x)*(q.x-x)+(q.y-y)*(q.y-y)<r*r)return true}return false}
function rpmbCatch(R,gl){const tw=gl.tw;gl.done=1;tw.mbHold[gl.slot]=1;tw.mbOut=Math.max(0,(tw.mbOut||1)-1);tw.mbC=1;tw.fire=Math.max(tw.fire||0,.45);
 if(!R.lite&&!R.rm)R.mbFx.push({x:gl.X,y:gl.Y*RPFX.sq-gl.h,t:0,d:.3,tier:gl.tier});rpmbSfx('catch')}
function rpmbStepGl(R,gl,dt){const tw=gl.tw,sq=RPFX.sq;if(!tw.pad||tw.pad.tw!==tw){gl.done=1;return}
 const x0=gl.X,y0=gl.Y;gl.spin+=dt*(gl.home?14:22)*gl.sd;
 /* jammed: the glaive loses its edge and comes straight home */
 if(tw.jam>0&&!gl.home)gl.home=1;
 if(gl.home){const H=rpmbHandW(tw,gl.slot,RPMB_A.hold),hx=H.x,hy=H.y/sq,dx=hx-gl.X,dy=hy-gl.Y,d=Math.hypot(dx,dy),st=gl.v*1.1*dt;
  if(d<=st+2){gl.X=hx;gl.Y=hy;gl.h=H.h;rpmbCatch(R,gl);return}gl.X+=dx/d*st;gl.Y+=dy/d*st;gl.h+=(H.h-gl.h)*Math.min(1,dt*6);rpmbTrail(R,gl,dt);return}
 const out=gl.u<1;gl.u+=dt*gl.v/(out?gl.L1:gl.L2);
 if(gl.u>=2){/* home to the hand at the hold pose */const H=rpmbHandW(tw,gl.slot,RPMB_A.hold);gl.X=H.x;gl.Y=H.y/sq;gl.h=H.h;rpmbCatch(R,gl);return}
 const p=gl.u<1?rpmbQ(gl.P0,gl.C1,gl.P2,gl.u):rpmbQ(gl.P2,gl.C2,gl.P0,gl.u-1);gl.X=p.X;gl.Y=p.Y;
 const c=RPMBL.cruise,w=gl.u<1?Math.pow(1-gl.u,3):Math.pow(gl.u-1,3);gl.h=c+(gl.h0-c)*w;
 /* cut every monster this step's stretch passes through, once per pass */
 const set=gl.u<1?gl.hitO:gl.hitB;
 for(const e of R.foes){if(set.has(e)||!rpmbCan(e))continue;const q=rpPos(R,e);if(rpmbDistSeg(q.x,q.y/sq,x0,y0,gl.X,gl.Y)>rpmbHitR(e))continue;
  set.add(e);rpHurt(e,gl.dmg,gl.ap,tw);R.mbHits=(R.mbHits||0)+1;
  if(!R.lite&&!R.rm){const M=RPMOB[e.id]||{h:50},lift=e.air?(M.lift||38)*rpmbMs():0;R.mbFx.push({x:(q.x+gl.X)/2,y:q.y-lift-M.h*rpmbMs()*.45,t:0,d:.26,tier:gl.tier});if(R.mbFx.length>50)R.mbFx.shift()}rpmbSfx('cut')}
 /* tier 4+: the silver wake where it crosses the road */
 if(gl.tier>=4){gl.wd+=Math.hypot(gl.X-x0,gl.Y-y0);if(gl.wd>=RPMBL.wakeGap){gl.wd=0;const x=gl.X,y=gl.Y*sq;if(rpmbRoad(R,x,y)){R.mbWake.push({x,y,t:0,d:RPMBL.wakeLife,tier:gl.tier,rot:Math.atan2((gl.Y-y0)*sq,gl.X-x0)});R.mbWakeN=(R.mbWakeN||0)+1;if(R.mbWake.length>160)R.mbWake.shift()}}}
 rpmbTrail(R,gl,dt)}
function rpmbTrail(R,gl,dt){if(R.lite||R.rm){gl.tr.length=0;return}gl.tt-=dt;if(gl.tt<=0){gl.tt=.022;gl.tr.unshift(gl.X,gl.Y*RPFX.sq-gl.h,gl.spin);if(gl.tr.length>15)gl.tr.length=15}}
/* the eclipse: a crescent orbiting the tower that cuts what it touches */
function rpmbEclPos(R,E){const tw=E.tw,r=rpmbRange(tw)*RPMBL.eclR,a=E.a0+E.dir*RPMBL.eclSpd*E.t;return{X:tw.x+Math.cos(a)*r,Y:tw.y/RPFX.sq+Math.sin(a)*r,a,r}}
function rpmbStepEcl(R,E,dt){const tw=E.tw;if(!tw.pad||tw.pad.tw!==tw){E.t=E.d;return}E.t+=dt;if(E.t>=E.d)return;const P=rpmbEclPos(R,E),sq=RPFX.sq,ov=tw.over>0?1.15:1,k=Math.min(1,E.t/.25,(E.d-E.t)/.3);if(k<.3)return;
 for(const e of R.foes){if(!rpmbCan(e))continue;const q=rpPos(R,e),X=q.x-tw.x,Y=q.y/sq-tw.y/sq,d=Math.hypot(X,Y);if(Math.abs(d-P.r)>RPMBL.eclW+rpmbHitR(e)*.4)continue;
  let da=Math.atan2(Y,X)-P.a;da=Math.atan2(Math.sin(da),Math.cos(da));if(Math.abs(da)*Math.max(d,1)>RPMBL.eclSpan*P.r+rpmbHitR(e)*.5)continue;
  const last=E.hit.get(e);if(last!=null&&E.t-last<RPMBL.eclRe)continue;E.hit.set(e,E.t);rpHurt(e,RPMBL.eclDmg*ov,99,tw);R.mbEclHits=(R.mbEclHits||0)+1;
  if(!R.lite&&!R.rm)R.mbFx.push({x:q.x,y:q.y-20,t:0,d:.3,tier:5});rpmbSfx('cut')}}
/* the wake slows (pre-step: like honey, re-applied every step while it lasts); contact with the wake and its fading (post-step) */
function rpmbPre(R,dt){if(!R.mbWake)return;const k=RPMBL.wakeK;for(const e of R.foes){e._mk=0;if(e.dead||!(e.mbWk>0)||e.air||e.vent>0)continue;
 if(!(e.slowT>0)||e.slowK<=k+1e-9){e.slowK=k;e.slowT=Math.max(e.slowT||0,dt*1.5);e._mk=k}}}
function rpmbPost(R,dt){if(!R.mbGl)return;
 for(const gl of R.mbGl)if(!gl.done)rpmbStepGl(R,gl,dt);R.mbGl=R.mbGl.filter(g=>!g.done);
 for(const E of R.mbEcl)rpmbStepEcl(R,E,dt);R.mbEcl=R.mbEcl.filter(E=>E.t<E.d);
 for(const e of R.foes)if(e.mbWk>0)e.mbWk=Math.max(0,e.mbWk-dt);
 if(R.mbWake.length){for(const w of R.mbWake)w.t+=dt;R.mbWake=R.mbWake.filter(w=>w.t<w.d);const r2=RPMBL.wakeR*RPMBL.wakeR;
  for(const e of R.foes){if(e.dead||e.air||e.s<0||e.hide)continue;const q=rpPos(R,e);for(const w of R.mbWake){if(w.t>w.d-.25)continue;const dx=q.x-w.x,dy=(q.y-w.y)/RPFX.sq;if(dx*dx+dy*dy<r2){if(!(e.mbWk>0)&&!R.rm&&Math.random()<.3)rpmbSfx('wake');e.mbWk=RPMBL.wakeT;break}}}}
 for(const f of R.mbFx)f.t+=dt;R.mbFx=R.mbFx.filter(f=>f.t<f.d);
 for(const p of R.pads){const tw=p.tw;if(!tw||tw.type!=='moon')continue;tw.mbT=Math.max(0,(tw.mbT||0)-dt/.3);tw.mbC=Math.max(0,(tw.mbC||0)-dt/.35);if(tw.jam>0)tw.mbW=Math.max(0,(tw.mbW||0)-dt*4)}}
/* ---------- hooks: fire routine (last in the chain, see the header), battle state, step, build, upgrade, sell ---------- */
{const f0=rpFire;rpFire=function(R,tw,dt){if(tw.type!=='moon')return f0.apply(this,arguments);
 if(tw.jam>0){tw.mbW=Math.max(0,(tw.mbW||0)-dt*4);return f0.apply(this,arguments)}/* 98b counts the jam down */
 if(tw.jamImm>0)tw.jamImm-=dt;
 if(typeof rpiaVeil==='function'&&!(typeof RPIA!=='undefined'&&RPIA.off))return rpiaVeil(R,tw,true,()=>rpmbFire(R,tw,dt));return rpmbFire(R,tw,dt)}}
{const s0=rpStart;rpStart=function(){const r=s0.apply(this,arguments);if(RPX)Object.assign(RPX,{mbGl:[],mbWake:[],mbEcl:[],mbFx:[],mbThrows:0,mbHits:0,mbEclN:0,mbEclHits:0,mbWakeN:0});return r}}
{const s0=rpStep;rpStep=function(R,dt){if(R&&R.mbWake)try{rpmbPre(R,dt)}catch(e){console.error(e)}const r=s0.apply(this,arguments);try{rpmbPost(R,dt)}catch(e){console.error(e)}return r}}
{const b0=rpBuild;rpBuild=function(pad,type){const r=b0.apply(this,arguments);try{if(r!==false&&type==='moon'&&pad&&pad.tw&&pad.tw.type==='moon'){const tw=pad.tw;tw.mbHold=[1,1,1];tw.mbOut=0;tw.mbW=0;tw.mbT=0;tw.mbC=0;tw.mbSide=1;tw.nv=0}}catch(e){}return r}}
{const u0=rpUpgrade;rpUpgrade=function(tw){const r=u0.apply(this,arguments);if(r&&tw&&tw.type==='moon')try{rpmbSync(tw)}catch(e){}return r}}
{const s0=rpSell;rpSell=function(tw){try{const R=RPX;if(R&&tw&&tw.type==='moon'&&R.mbGl){for(const g of R.mbGl)if(g.tw===tw){g.done=1;try{ptBurst(R.fx,g.X,g.Y*RPFX.sq-g.h,R.lite?2:6,['#e8f0ff','#bfe0ff','#ffffff'],{v:140,s:2.6})}catch(x){}}
  R.mbGl=R.mbGl.filter(g=>!g.done);R.mbEcl=R.mbEcl.filter(E=>E.tw!==tw)}}catch(e){}return s0.apply(this,arguments)}}
/* ---------- drawing ---------- */
const rpmbScr=gl=>({x:gl.X,y:gl.Y*RPFX.sq-gl.h});
const rpmbBig=t=>t>=5?1.55:t>=4?1.48:t>=3?1.42:1.36;/* glaives read bigger in flight than in the hand */
/* the arms and held glaives follow the tower being drawn */
{const t0=rpTowerAt;rpTowerAt=function(c,R,tw){if(tw&&tw.type==='moon')RPMB_ART.cur=tw;try{return t0.apply(this,arguments)}finally{RPMB_ART.cur=null}}}
/* ground layer: the wake, glaive shadows, the eclipse's track */
{const a0=rpAmbient;rpAmbient=function(c,R){const r=a0.apply(this,arguments);try{if(R&&R.mbGl){const sq=RPFX.sq;
 if(R.mbWake.length){c.save();c.globalCompositeOperation='lighter';for(const w of R.mbWake){const k=Math.min(1,w.t*8,(w.d-w.t)/.5);rpmbWake(c,w.x,w.y,k*.9,w.tier,w.rot)}c.restore();c.globalAlpha=1;
  if(!R.lite&&!R.rm){const st=rpStarS().c;c.save();c.globalCompositeOperation='lighter';for(let j=0;j<R.mbWake.length;j+=3){const w=R.mbWake[j],u=(R.t*1.3+j*.37)%1,z=3+3*Math.sin(Math.PI*u);c.globalAlpha=Math.min(1,(w.d-w.t)/.5)*Math.sin(Math.PI*u)*.8;c.drawImage(st,w.x-z+Math.sin(j)*8,w.y-z-u*6,z*2,z*2)}c.restore();c.globalAlpha=1}}
 for(const gl of R.mbGl){const k=Math.max(.25,1-gl.h/150);c.fillStyle=`rgba(8,4,20,${(.28*k).toFixed(3)})`;c.beginPath();c.ellipse(gl.X,gl.Y*sq,11*k+3,4*k+1.4,0,0,TAU);c.fill()}
 for(const E of R.mbEcl){const tw=E.tw,r=rpmbRange(tw)*RPMBL.eclR,k=Math.min(1,E.t/.25,(E.d-E.t)/.3);c.save();c.globalAlpha=.45*k;c.setLineDash([10,8]);c.lineDashOffset=-R.t*40*E.dir;c.lineWidth=2.6;c.strokeStyle='#ffe9a0';
  c.beginPath();c.ellipse(tw.x,tw.y,r,r*sq,0,0,TAU);c.stroke();c.setLineDash([]);c.restore();c.globalAlpha=1}}}catch(e){console.error(e)}return r}}
/* top layer: trails, glaives, the eclipse, cut sparks */
{const b0=rpBeamsDraw;rpBeamsDraw=function(c,R){b0.apply(this,arguments);if(!R.mbGl)return;try{const sq=RPFX.sq;
 if(!R.lite&&!R.rm){c.save();c.globalCompositeOperation='lighter';for(const gl of R.mbGl){const T=gl.tr,n=T.length/3,big=rpmbBig(gl.tier);for(let k=1;k<n;k++){const a=(1-k/n)*.7;rpmbGhost(c,T[k*3],T[k*3+1],gl.tier,T[k*3+2],.55,big*(1-k/n*.3),a)}}c.restore();c.globalAlpha=1}
 for(const gl of R.mbGl){const p=rpmbScr(gl),big=rpmbBig(gl.tier);
  if(!R.lite){c.save();c.globalCompositeOperation='lighter';rpGlow(c,p.x,p.y,24*big,15*big,rpmbMet(gl.tier).glow,gl.home?.3:gl.tier>=3?.6:.45);c.restore();c.globalAlpha=1}
  rpmbBlade(c,p.x,p.y,gl.tier,gl.spin,.55,big*(gl.home?.9:1),gl.home?.75:1)}
 for(const E of R.mbEcl){const P=rpmbEclPos(R,E),k=Math.min(1,E.t/.25,(E.d-E.t)/.3);
  if(!R.lite&&!R.rm){c.save();c.globalCompositeOperation='lighter';for(let j=1;j<=4;j++){const a=P.a-E.dir*j*.13,x=E.tw.x+Math.cos(a)*P.r,y=(E.tw.y/sq+Math.sin(a)*P.r)*sq-34;c.globalAlpha=k*(.5-j*.1);c.drawImage(rpGlowC('#fff0c0'),x-26,y-18,52,36)}c.restore();c.globalAlpha=1}
  rpmbEclipse(c,P.X,P.Y*sq-34,5,R.t*6*E.dir,1.55,k)}
 if(!R.lite&&!R.rm)for(const f of R.mbFx)rpmbSpark(c,f.x,f.y,f.t/f.d,f.tier)}catch(e){console.error(e)}}}
/* while a Sentinel is selected: its next loop as a faint dashed path (refreshed five times a second) */
{const d0=rpDraw;rpDraw=function(){const r=d0.apply(this,arguments);try{const R=RPX;if(!R||!S.rp||!R.sel||R.sel.type!=='moon'||R.sel.build<1||!R.mbGl)return r;const tw=R.sel;
  if(!tw._pvT||R.t-tw._pvT>.2||R.t<tw._pvT){tw._pvT=R.t;const tg=rpmbTargets(R,tw,2);tw._pv=tg.length?rpmbPlan(R,tw,tg):null}const P=tw._pv;if(!P)return r;
  const c=ctx,sq=RPFX.sq;c.save();c.setTransform(RS,0,0,RS,0,0);c.globalAlpha=.5+.15*Math.sin(R.t*4);c.setLineDash([7,8]);c.lineDashOffset=-R.t*30;c.lineWidth=2;c.strokeStyle='#cfe0ff';
  for(const p of P){c.beginPath();for(let k=0;k<=40;k++){const u=k/20,q=u<=1?rpmbQ(p.P0,p.C1,p.P2,u):rpmbQ(p.P2,p.C2,p.P0,u-1);k?c.lineTo(q.X,q.Y*sq-RPMBL.cruise):c.moveTo(q.X,q.Y*sq-RPMBL.cruise)}c.stroke()}
  c.setLineDash([]);c.restore()}catch(e){}return r}}
/* monsters in the wake: a silver sheen instead of the frost look (they are slowed 20%) */
{const f0=rpFoeDraw;rpFoeDraw=function(c,R,e,q){let hide=false,st=0;try{if(e._mk>0&&e.slowT>0&&e.slowK<=e._mk+1e-6&&!(e.inField>0)){hide=true;st=e.slowT;e.slowT=0}}catch(x){}
 let r;try{r=f0.apply(this,arguments)}finally{if(hide)e.slowT=st}
 if(hide&&!e.dead&&q)try{const M=RPMOB[e.id]||{h:50,w:40},s=rpmbMs();c.save();c.globalCompositeOperation='lighter';rpGlow(c,q.x,q.y-2,(M.w||40)*s*.7,10,'#dfe8ff',.55+.15*Math.sin(R.t*6+(e.uid||0)));c.restore();c.globalAlpha=1}catch(x){}
 return r}}
/* ---------- the info panel ---------- */
{const i0=rpInfoBuild;rpInfoBuild=function(R,tw,el){const r=i0.apply(this,arguments);if(tw.type!=='moon')return r;try{const T=RP_TW.moon,i=tw.tier-1,top=RP_MAXT(R.map),nx=tw.tier<top?tw.tier:null;
  const seg=(v,max)=>Math.max(0,Math.min(6,Math.round(v/max*6))),bar=(lab,v,max,nv)=>`<div class="rpst"><span>${lab}</span><i>${[0,1,2,3,4,5].map(k=>`<s class="${k<seg(v,max)?'on':nv!=null&&k<seg(nv,max)?'up':''}"></s>`).join('')}</i></div>`;
  const gd=j=>Math.sqrt(T.dmg[j]*T.glaives[j]*2/T.cd[j]);
  const st=el.querySelector('.rpsts');if(st)st.innerHTML=bar('Range',T.range[i],320,nx!=null?T.range[nx]:null)+bar('Glaive damage',gd(i),gd(4),nx!=null?gd(nx):null)+bar('Glaives',T.glaives[i],3,nx!=null?T.glaives[nx]:null)+bar('Throw rate',1/T.cd[i],1,nx!=null?1/T.cd[nx]:null);
  const ex=[`<b>${T.dmg[i]}</b> per pass, out and back`,`<b>${T.glaives[i]}</b> glaive${T.glaives[i]>1?'s':''} · ground and air`,T.ap[i]>=99?'ignores armor':`armor-piercing <b>${T.ap[i]}</b>`];
  if(tw.tier>=4)ex.push(`wake <b>${Math.round(RPMBL.wakeK*100)}%</b> slow`);if(tw.tier>=5)ex.push(`eclipse every <b>${RPMBL.eclN}th</b> throw`);
  if(st)st.insertAdjacentHTML('afterend',`<div class="rpmbx">${ex.join(' · ')}</div>`);
  {const b=el.querySelector('.rpih b');if(b){b.style.fontSize='22px';b.style.whiteSpace='nowrap';if(typeof rpuFit==='function')requestAnimationFrame(()=>rpuFit(b,14))}}
  const hgt=el.offsetHeight||420;el.style.top=rpClamp(tw.y-hgt*.62,76,770-hgt)+'px'}catch(e){console.error(e)}return r}}
{const st=document.createElement('style');st.textContent=`.rpmbx{margin:6px 0 2px;font:600 12px Poppins,system-ui,sans-serif;color:#e4ecff;line-height:1.35}.rpmbx b{color:#a8c8ff}`;document.head.appendChild(st)}
/* key M picks it (not while Rune Typing is on: letters type then) */
{const k0=rpKeyDown;window.removeEventListener('keydown',rpKeyDown,true);rpKeyDown=function(e){const R=RPX;if(R&&S.rp&&S.mode==='ramparts'&&!R.pause&&!R.over&&!(R.ty&&R.ty.on)&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&e.key.length===1&&e.key.toLowerCase()==='m'){e.preventDefault();e.stopImmediatePropagation();if(!e.repeat)rpPlace('moon');return}return k0.apply(this,arguments)};window.addEventListener('keydown',rpKeyDown,true)}
/* the bar and the ring list every tower in RP_TWORDER; the count classes (rp11, rp12) are set by 98n for its sizes */
{const h0=rpHudOn;rpHudOn=function(){const r=h0.apply(this,arguments);try{const h=$('rphud');if(h)h.classList.toggle('rp13',h.querySelectorAll('.rpcard').length>=13)}catch(e){}return r}}
/* a stopgap so thirteen cards fit the 871 px bar of 98n (cards 63 px); the 10.2 battle-UI module lays the bar out for fourteen */
{const st=document.createElement('style');const P='.rph.rp7.rp8.rp9.rp10.rp11.rp12.rp13';st.textContent=`${P} .rpcard{width:63px}${P} .rpct>b{max-width:61px;font-size:9.5px}${P} .rpcard img{width:52px;height:52px;margin-left:-26px;top:-14px}`;document.head.appendChild(st)}
/* ---------- texts ---------- */
const RPMB_NUM=['no','one','two','three','four','five','six','seven','eight','nine','ten','eleven','twelve','thirteen','fourteen','fifteen','sixteen'];
try{const h=HELP.Modes.find(x=>x[0]==='Runestone Tower Defense');if(h){h[1]=h[1].replace(/all (\w+) are open from the start/,()=>`all ${RPMB_NUM[RP_TWORDER.length]||RP_TWORDER.length} are open from the start`);
 h[1]+=" The Moonblade Sentinel (M, 300 supply) hurls spinning crescent glaives that fly out through the target and boomerang back, cutting every monster they pass on the ground or in the air, once each way."}}catch(e){}
{const h0=rpHowTo;rpHowTo=function(){const r=h0.apply(this,arguments);try{const w=ov.querySelector('#rpmod .rphw');if(w){
  for(const p of w.querySelectorAll('p'))if(/^Towers\./.test(p.textContent))p.innerHTML=p.innerHTML.replace(/All (\w+) are open/,()=>`All ${RPMB_NUM[RP_TWORDER.length]||RP_TWORDER.length} are open`);
  w.insertAdjacentHTML('beforeend',`<p><b>Moonblade Sentinel.</b> A moonstone guardian (${rpCost('moon',1)} supply, key M), ground and air. It hurls a spinning crescent glaive that flies out through its target to the edge of its range and boomerangs back to its hand, cutting every monster it passes through, once on the way out and once on the way back (armor-piercing). Line it up along a long stretch of road. Tier 3 throws a glaive from each hand on mirrored curves, tier 4 glaives leave a silver wake on the road that slows monsters 20%, and at tier 5 a third glaive joins them and every fifth throw an eclipse crescent circles the tower for three seconds, cutting everything it touches.</p>`)}}catch(e){}return r}}
/* ---------- mastery skins (98m): five themes from RPY_TH ---------- */
try{RPY_SET.moon=[['jade','Jade Sentinel'],['rosegold','Rose Moon Sentinel'],['inferno','Harvest Moon Sentinel'],['voidstar','Eclipse Sentinel'],['aurora','Aurora Sentinel']]}catch(e){}
/* warm the battle sprites with the tower */
{const w0=rpTowerWarm;rpTowerWarm=function(type,tier,skin){const r=w0.apply(this,arguments);if(type==='moon')try{rpStarS()}catch(e){}return r}}
