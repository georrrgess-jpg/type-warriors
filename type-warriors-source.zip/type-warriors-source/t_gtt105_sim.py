# python3 t_gtt105_sim.py [game.html] : The Great Turkey Trot (10.5) part 1, the pure logic running in the real page (99u data, 99u2 sim).
# Determinism after a reload (and equal to the node run of tools/gtt/rtp.js), gttNorm repairs, gttCard, pricing sums / steps / clamps,
# state shape, events, photo finish, cash-out offers, settle for the four bet types and the cap, no top-level name clashes, no page errors, timings.
import asyncio,os,re,sys,glob
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(n,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+n+('' if ok else '  '+str(info)[:500]),flush=True)
    if not ok:FAIL.append(n)
HASH="""()=>{let h=0;for(let i=0;i<150;i++){const c=gttCard(i*13+5),st=gttRun(c,i*977+3);for(const t of st.times)h=(Math.imul(h,31)+Math.round(t*1e6))|0;h=(Math.imul(h,31)+st.ev.length)|0;h=(Math.imul(h,31)+st.order.join('').length*7+st.order.reduce((a,b,j)=>a+b*(j+1),0))|0}return h}"""
def toplevel(src):
    return set(re.findall(r'^(?:const|let|class|function)\s+([A-Za-z_$][\w$]*)',src,re.M))
async def main():
    # ---- static: top-level names of the two modules never clash with another module and all start with gtt / GTT ----
    mine=['99u_gtt_data.js','99u2_gtt_sim.js'];names={}
    for f in mine: names[f]=toplevel(open(os.path.join(HERE,f)).read())
    bs=open(os.path.join(HERE,'build.sh')).read()
    order=re.findall(r'\b([\w.]+\.js)\b',bs)
    chk('both modules are registered in build.sh and build_ast3.sh in order',all(m in order for m in mine) and order.index(mine[0])<order.index(mine[1]) and all(m in open(os.path.join(HERE,'build_ast3.sh')).read() for m in mine),order[-8:])
    other=set()
    for f in sorted(glob.glob(os.path.join(HERE,'*.js'))):
        b=os.path.basename(f)
        if b in mine or b not in order or b.startswith('out'): continue
        if b.startswith('99u'): continue
        other|=toplevel(open(f).read())
    allm=set().union(*names.values())
    chk('every top-level name starts with gtt / GTT',all(re.match(r'(gtt|GTT)',n) for n in allm),[n for n in allm if not re.match(r'(gtt|GTT)',n)])
    chk('no top-level name clashes with any other module',not (allm&other),sorted(allm&other))
    chk('the two modules have no DOM or game globals at top level (window, document, P, ctx)',not re.search(r'\b(document|localStorage|ctx)\b',open(os.path.join(HERE,'99u2_gtt_sim.js')).read()) and not re.search(r'\bdocument\b',open(os.path.join(HERE,'99u_gtt_data.js')).read()))
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]));await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E("()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}}")
        r=await E("()=>['GTT','GTT_RUN','gttNorm','gttCard','gttRng','gttSimNew','gttStep','gttRun','gttPriceSync','gttPrice','gttLiveP','gttOffer','gttSettle'].map(n=>{try{return typeof eval(n)}catch(e){return 'missing'}})")
        chk('all contract names exist',r==['object','object','function','function','function','function','function','function','function','function','function','function','function'],r)
        r=await E("()=>[GTT.rtp,GTT.coRtp,GTT.cap,GTT.maxBet,GTT.maxTotal,GTT.minBet,GTT.maxBets,GTT.len,GTT.hz,GTT.runners,GTT.acorn.win,GTT.acorn.perDay,GTT_RUN.length]")
        chk('GTT constants match the contract',r==[.95,.93,20000,5000,5000,10,3,1000,30,6,5,10,12],r)
        r=await E("()=>{const ids=['gravy','comet','gobbles','spice','willie','butter','maple','drum','annie','stuff','hank','duchess'];const ks=['id','n','style','spd','sta','kick','gate','focus','mud','wild','col','silk','jockey','tip'];return [GTT_RUN.map(r=>r.id).join()===ids.join(),GTT_RUN.every(r=>ks.every(k=>r[k]!==undefined)&&r.col.length===2&&r.silk.length===2&&r.jockey.n&&r.jockey.kind&&['front','close','stalk'].includes(r.style)),new Set(GTT_RUN.map(r=>r.n)).size]}")
        chk('twelve runners with ids, styles, colours, silks, jockeys and tips',r==[True,True,12],r)
        # determinism
        h1=await E(HASH);h2=await E(HASH)
        await pg.reload();await pg.wait_for_timeout(1500);h3=await E(HASH)
        chk('the same seeds give the same races twice in a page and after a reload',h1==h2==h3,[h1,h2,h3])
        import subprocess
        try:
            out=subprocess.run(['node',os.path.join(HERE,'..','tools','gtt','rtp.js'),'--hash'],capture_output=True,text=True,timeout=60).stdout.strip()
        except Exception as e: out=str(e)
        chk('the browser and node produce the same races (hash)',out=='HASH %d'%h1,[out,h1])
        # card
        r=await E("()=>{const a=gttCard(12345),b=gttCard(12345),c=gttCard(12346);let ok=true;const ids=new Set(GTT_RUN.map(r=>r.id));for(let i=0;i<500;i++){const k=gttCard(i*977+1);if(new Set(k.field).size!==6||!k.field.every(x=>ids.has(x))||!['firm','good','muddy'].includes(k.going)||!['clear','wind','drizzle'].includes(k.weather)||!(k.no>=1))ok=false}return [JSON.stringify(a)===JSON.stringify(b),JSON.stringify(a)!==JSON.stringify(c),ok,a.seed,Object.keys(a).sort().join()]}")
        chk('gttCard is deterministic, six distinct known runners, valid going and weather',r[0] and r[1] and r[2] and r[4]=='field,going,no,seed,weather',r)
        r=await E("()=>{const c={firm:0,good:0,muddy:0,clear:0,wind:0,drizzle:0};for(let i=0;i<3000;i++){const k=gttCard(i*31+7);c[k.going]++;c[k.weather]++}return c}")
        chk('cards show every going and weather, none rare enough to vanish',all(r[k]>200 for k in r),r)
        # norm
        r=await E("""()=>{const bad=[{},null,'x',5,[],{v:'a',races:'12',bets:-5,wins:1e99,best:'abc',long:NaN,fav:'z',rec:5,seen:'yes',pend:'oops',acorn:7},
          {races:3.7,fav:{gravy:'4',nope:9},rec:{gravy:{s:2,w:'1',p:-4,last:[1,2,3,4,5,6,7,0,9,'3',null,2.5]}},pend:{cardSeed:1,raceSeed:2,bets:[{k:'win',a:9,stake:100,mult:3}]}},
          {pend:{cardSeed:1,raceSeed:2,bets:[]}},{pend:{cardSeed:1,raceSeed:2,bets:[{k:'exact',a:1,b:1,stake:100,mult:3}]}},{pend:{cardSeed:'q',raceSeed:2,bets:[{k:'win',a:1,stake:100,mult:3}]}},
          {pend:{cardSeed:1,raceSeed:2,bets:[{k:'win',a:1,stake:99999,mult:3}]}},{pend:{cardSeed:1,raceSeed:2,bets:[{k:'win',a:1,stake:100,mult:1e9}]}},
          {pend:{cardSeed:1,raceSeed:2,bets:[{k:'win',a:1,stake:3000,mult:3},{k:'win',a:2,stake:3000,mult:3}]}}];
          const keys='v,races,bets,wins,best,long,fav,rec,seen,pend,acorn';const out=[];
          for(const g of bad){const o=gttNorm(g);const okShape=Object.keys(o).sort().join()===keys.split(',').sort().join()&&o.v===1&&[o.races,o.bets,o.wins,o.best,o.long].every(n=>Number.isInteger(n)&&n>=0&&n<=1e9)&&GTT_RUN.every(r=>Number.isInteger(o.fav[r.id])&&o.rec[r.id]&&o.rec[r.id].last.length<=5&&o.rec[r.id].last.every(x=>x>=1&&x<=6))&&(o.seen===0||o.seen===1)&&typeof o.acorn.day==='string'&&Number.isInteger(o.acorn.n)&&(o.pend===null||Array.isArray(o.pend.bets));out.push(okShape&&o.pend===null)}
          const good={pend:{cardSeed:5,raceSeed:-9,bets:[{k:'exact',a:1,b:2,stake:500,mult:20.5},{k:'win',a:0,stake:100,mult:3}],cash:[{i:1,pay:250},{i:1,pay:3},{i:7,pay:3}],t0:5}};const g=gttNorm(good);
          const a=gttNorm({races:12,bets:3,wins:2,best:900,long:1,fav:{gravy:2},rec:{gravy:{s:2,w:1,p:1,last:[1,3]}},seen:1,acorn:{day:'2026-11-09',n:5}});
          return [out,g.pend&&g.pend.bets.length,g.pend&&g.pend.cash.length,g.pend&&g.pend.bets[0].b,JSON.stringify(gttNorm(a))===JSON.stringify(a),a.races,a.fav.gravy,a.rec.gravy.last.join(),a.acorn.n,gttNorm({races:3.7}).races,JSON.stringify(gttNorm({rec:{gravy:{last:[1,2,3,4,5,6,7,0,9,'3',null,2.5]}}}).rec.gravy.last)]}""")
        chk('gttNorm repairs strings, negatives, huge numbers and malformed pends',all(r[0]) and len(r[0])==13,r[0])
        chk('gttNorm keeps a good pend (bad cash lines dropped), is idempotent and keeps good numbers',r[1]==2 and r[2]==1 and r[3]==2 and r[4] and r[5]==12 and r[6]==2 and r[7]=='1,3' and r[8]==5 and r[9]==3 and r[10]=='[4,5,6,3,2]',r)
        r=await E("()=>{const o=P.gtt;P.gtt={races:'9',pend:'bad'};const n=gttNorm();const same=P.gtt===n;P.gtt=o;return [same,n.races,n.pend]}")
        chk('gttNorm() with no argument repairs P.gtt in place',bool(r[0]) and r[1]==9 and r[2] is None,r)
        # state shape and stepping
        r=await E("""()=>{const card=gttCard(4242),st=gttSimNew(card,99);const shape0=Object.keys(st).filter(k=>['card','t','n','len','run','ev','done','order','times','photo'].includes(k)).length;
          const r0=st.run[0];const rk=['lane','id','x','v','fin','ev','pos'].every(k=>k in r0);let mono=true,posOk=true,prev=st.run.map(r=>r.x),steps=0;
          while(!st.done&&steps<3000){gttStep(st);steps++;for(let i=0;i<6;i++){if(st.run[i].x<prev[i]-1e-9)mono=false;prev[i]=st.run[i].x}
            const ps=st.run.map(r=>r.pos).sort().join();if(ps!=='1,2,3,4,5,6')posOk=false}
          const run=gttRun(card,99);return [shape0,rk,st.len,mono,posOk,st.done,st.order.length,new Set(st.order).size,st.t>18&&st.t<30,st.n===steps,JSON.stringify(st.times)===JSON.stringify(run.times),JSON.stringify(st.ev)===JSON.stringify(run.ev),st.order.every((l,i)=>i===0||st.times[st.order[i-1]]<=st.times[l]),st.run.every(r=>r.fin>0&&r.pos>=1),st.run.filter(r=>r.pos===1)[0].lane===st.order[0]]}""")
        chk('state shape per the contract; stepping equals running; ranks are 1..6; order matches finish times',r[0]==10 and r[1] and r[2]==1000 and r[3] and r[4] and r[5] and r[6]==6 and r[7]==6 and r[8] and r[9] and r[10] and r[11] and r[12] and r[13] and r[14],r)
        r=await E("""()=>{const kinds={},lanesOk=[];let n=0,bad=0,gap=0,photo=0,pairs=0;for(let i=0;i<400;i++){const st=gttRun(gttCard(i*5+2),i*91+7);n++;for(const e of st.ev){kinds[e.k]=(kinds[e.k]||0)+1;if(!(e.t>=0&&e.t<=st.t)||!(e.lane===-1&&e.k==='gust'||e.lane>=0&&e.lane<6))bad++}
            if(st.photo){photo++;const g=st.times[st.photo.b]-st.times[st.photo.a];if(Math.abs(g-st.photo.gap)>1e-12||g>=0.06||st.order[0]!==st.photo.a||st.order[1]!==st.photo.b)bad++}else{const g=st.times[st.order[1]]-st.times[st.order[0]];if(g<0.06)bad++}}
            return [kinds,bad,photo/n]}""")
        chk('events carry kind, time and lane (gust lane -1); photo is set exactly when the first two are within 0.06 s',r[1]==0 and all(k in r[0] for k in ['stumble','burst','pie','kick','gust']),r)
        chk('photo finishes happen in roughly 1 race in 8 (8-18%)',.08<r[2]<.18,r[2])
        # events set run.ev while active
        r=await E("""()=>{let seen={};for(let i=0;i<60;i++){const st=gttSimNew(gttCard(i*3+1),i+11);while(!st.done){gttStep(st);for(const r of st.run)if(r.ev){seen[r.ev.k]=1;if(!(r.ev.t0<=st.t+1e-9))seen.bad=1}}}return Object.keys(seen).sort().join()}""")
        chk('run.ev shows the active event (stumble, burst, pie, kick, gust) while it lasts',r=='burst,gust,kick,pie,stumble',r)
        # pricing
        r=await E("""()=>{const card=gttCard(777),t0=performance.now(),p=gttPriceSync(card),dt=performance.now()-t0;const sum=a=>a.reduce((x,y)=>x+y,0);const ex=sum(p.exact.map(sum));
          const stepOk=m=>m==null||(m>=1.1&&(m<3?Math.abs(m*20-Math.round(m*20))<1e-6:m<10?Math.abs(m*10-Math.round(m*10))<1e-6:m<25?Math.abs(m*2-Math.round(m*2))<1e-6:Math.abs(m-Math.round(m))<1e-6));
          const all=[];for(const k of['win','top2','top3'])for(const m of p.mult[k])all.push([k,m]);for(let i=0;i<6;i++)for(let j=0;j<6;j++)all.push(['exact',p.mult.exact[i][j]]);
          return [sum(p.win),sum(p.top2),sum(p.top3),ex,all.every(([k,m])=>stepOk(m)),all.every(([k,m])=>m==null||m<=(k==='exact'?150:40)),p.exact[2][2]===0&&p.mult.exact[2][2]===null,dt,p.mult.win.map((m,i)=>m==null||Math.abs(m*p.win[i]-.95)<.06||m===1.1||m===40)]}""")
        chk('pricing probabilities sum to 1 / 2 / 3 (and the exact table to 1)',abs(r[0]-1)<1e-9 and abs(r[1]-2)<1e-9 and abs(r[2]-3)<1e-9 and abs(r[3]-1)<1e-9,r[:4])
        chk('multipliers respect the steps, the 1.10 floor and the 40 / 150 caps; the diagonal of Exact is empty',r[4] and r[5] and r[6],r[4:7])
        chk('win multiplier x probability is about the 0.95 return, bar rounding',all(r[8]),r[8])
        print('INFO gttPriceSync(4000) took %.0f ms in this browser'%r[7])
        chk('gttPriceSync(4000) is under 2500 ms even in a slow shared software browser (about 250 ms on a desktop)',r[7]<2500,r[7])
        r=await E("""()=>{const out=[];for(const p of [.0059,.006,.02,.0225,.3,.5,.8636,.88,.9,.91,.99]){out.push([p,gttMultFor(p,'win'),gttMultFor(p,'exact')])}return out}""")
        d={x[0]:x for x in r}
        chk('gttMultFor clamps: under 0.6% not offered; floor 1.10; win max 40 (a long shot whose capped price returns under 88% is not offered), exact max 150; very likely selections not offered',d[.0059][1] is None and d[.006][1] is None and d[.006][2]==150 and d[.02][1] is None and d[.0225][1]==40 and d[.3][1]==3.1 and d[.5][1]==1.9 and d[.8636][1]==1.1 and d[.9][1]==1.1 and d[.91][1] is None,r)
        r=await E("""()=>{const card=gttCard(31),a=gttPriceSync(card,1000),b=gttPriceSync(card,1000);return [JSON.stringify(a)===JSON.stringify(b)]}""")
        chk('pricing is deterministic for a card (uses its own seeds)',r[0],r)
        r=await E("""()=>new Promise(ok=>{const card=gttCard(55);const sync=gttPriceSync(card,2000);let frames=0,fr=true;const t0=performance.now();gttPrice(card,2000,res=>{ok([JSON.stringify(res)===JSON.stringify(sync),performance.now()-t0,frames])});const tick=()=>{frames++;requestAnimationFrame(tick)};requestAnimationFrame(tick)})""")
        chk('gttPrice (chunked, async) returns the same result as gttPriceSync',r[0],r)
        # cash out
        r=await E("""()=>{const card=gttCard(901),pr=gttPriceSync(card,1500),st=gttSimNew(card,5);const bets=[0,1,2].map(i=>({k:['win','top2','top3'][i],a:i,stake:100,mult:pr.mult[['win','top2','top3'][i]][i]||2}));bets.push({k:'exact',a:0,b:1,stake:100,mult:pr.mult.exact[0][1]||30});
          for(let i=0;i<300;i++)gttStep(st);const lead0=Math.max(...st.run.map(r=>r.x));
          const snap=JSON.stringify([st.run.map(r=>[r.x,r.v,r.pos,r.fin]),st.n,st.order,st.times]);
          const t0=performance.now();let offs;for(let i=0;i<10;i++)offs=gttOffers(st,bets);const dt=(performance.now()-t0)/10;
          const t1=performance.now();const o1=gttOffer(st,bets[0]);const dt1=performance.now()-t1;
          const same=JSON.stringify([st.run.map(r=>[r.x,r.v,r.pos,r.fin]),st.n,st.order,st.times])===snap;
          const p=gttLiveP(st,bets[0],300);
          const st2=gttSimNew(card,5);while(Math.max(...st2.run.map(r=>r.x))<905)gttStep(st2);
          return [offs,o1,lead0,same,dt,dt1,p,gttOffer(st2,bets[0]),gttOffers(st2,bets),offs.every(Number.isInteger),JSON.stringify(gttOffers(st,bets))===JSON.stringify(offs)]}""")
        chk('cash-out offers are whole coins, deterministic for a state, do not change the race, and are 0 in the last 10%',all(isinstance(x,int) for x in r[0]) and r[3] and r[9] and r[10] and r[7]==0 and r[8]==[0,0,0,0] and 0<=r[6]<=1,r)
        print('INFO cash-out offer for 4 bets: %.1f ms, for one bet: %.1f ms'%(r[4],r[5]))
        chk('the cash-out offer costs well under 50 ms in this slow shared browser (about 10-20 ms on a desktop)',r[5]<50 and r[4]<60,[r[4],r[5]])
        # offer sanity: leader's win offer is higher than the last runner's
        r=await E("""()=>{const card=gttCard(901),st=gttSimNew(card,5);for(let i=0;i<400;i++)gttStep(st);const lead=st.run.find(r=>r.pos===1).lane,last=st.run.find(r=>r.pos===6).lane;
          const a=gttOffer(st,{k:'win',a:lead,stake:100,mult:4}),b=gttOffer(st,{k:'win',a:last,stake:100,mult:4});return [a,b]}""")
        chk('at 400 steps the leader\'s win offer is above the last runner\'s',r[0]>r[1],r)
        # settle
        r=await E("""()=>{const card=gttCard(222),st=gttRun(card,8),o=st.order;const L=(k,a,b,stake,mult)=>({k,a,b,stake,mult});
          const w=gttSettle([L('win',o[0],undefined,100,4.2),L('win',o[1],undefined,100,4.2)],st);
          const t2=gttSettle([L('top2',o[1],undefined,100,2),L('top2',o[2],undefined,100,2)],st);
          const t3=gttSettle([L('top3',o[2],undefined,100,1.5),L('top3',o[3],undefined,100,1.5)],st);
          const ex=gttSettle([L('exact',o[0],o[1],100,12.5),L('exact',o[1],o[0],100,12.5)],st);
          const mix=gttSettle([L('win',o[0],undefined,50,3.3),L('top3',o[5],undefined,50,2),L('exact',o[0],o[1],10,150)],st);
          const cap=gttSettle([L('win',o[0],undefined,5000,40),L('exact',o[0],o[1],5000,150),L('top3',o[0],undefined,5000,40)],st);
          const cap2=gttSettle([L('win',o[0],undefined,1000,2),L('exact',o[0],o[1],1000,3),L('top3',o[0],undefined,1000,1.1)],st);
          return [w.lines.map(l=>[l.won,l.pay]),w.total,t2.lines.map(l=>[l.won,l.pay]),t3.lines.map(l=>[l.won,l.pay]),ex.lines.map(l=>[l.won,l.pay]),mix.lines.map(l=>[l.won,l.pay]),mix.total,cap.total,cap.lines.map(l=>l.pay),cap2.total,w.lines[0].bet.k]}""")
        chk('settle: win pays floor(stake x mult) only to the winner; top2, top3 and exact (in order) each settle on their own',r[0]==[[True,420],[False,0]] and r[1]==420 and r[2]==[[True,200],[False,0]] and r[3]==[[True,150],[False,0]] and r[4]==[[True,1250],[False,0]] and r[5]==[[True,165],[False,0],[True,1500]] and r[6]==1665 and r[10]=='win',r)
        chk('settle: the total is capped at 20,000 and the lines add up to it; under the cap nothing is cut',r[7]==20000 and sum(r[8])==20000 and r[8]==[20000,0,0] and r[9]==6100,r[7:10])
        r=await E("""()=>{let worst=0,bad=0;for(let i=0;i<300;i++){const st=gttRun(gttCard(i*17+3),i*29+1),bets=[];for(let b=0;b<3;b++){const k=['win','top2','top3','exact'][(i+b)%4],a=st.order[b%3];bets.push({k,a,b:k==='exact'?st.order[(b+1)%6]:undefined,stake:5000,mult:k==='exact'?150:40})}
          bets[0]={k:'win',a:st.order[0],stake:5000,mult:40};bets[1]={k:'exact',a:st.order[0],b:st.order[1],stake:5000,mult:150};const s=gttSettle(bets,st);worst=Math.max(worst,s.total);if(s.lines.reduce((t,l)=>t+l.pay,0)!==s.total)bad++}return [worst,bad]}""")
        chk('settle never pays above the cap over 300 maxed slips, and lines always add up',r[0]<=20000 and r[1]==0,r)
        # race time and ordering sanity
        r=await E("""()=>{let ts=0,n=300,mx=0,mn=99;for(let i=0;i<n;i++){const st=gttRun(gttCard(i*3+9),i*53+5);ts+=st.t;mx=Math.max(mx,st.t);mn=Math.min(mn,st.t)}return [ts/n,mn,mx]}""")
        chk('a race lasts 20-25 s of sim time on average (all six home)',20<r[0]<25 and r[1]>18 and r[2]<30,r)
        t=await E("""()=>{const card=gttCard(3);const t0=performance.now();for(let i=0;i<50;i++)gttRun(card,i);return (performance.now()-t0)/50}""")
        print('INFO a full logged race costs %.2f ms'%t)
        chk('a full logged race costs under 15 ms (the screen only replays it at 30 Hz)',t<15,t)
        chk('no page errors',not er,er);await b.close()
    print(f'\n{N[0]-len(FAIL)} / {N[0]} passed');print(FAIL)
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
