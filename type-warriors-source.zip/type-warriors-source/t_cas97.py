# python3 t_cas97.py : 9.7c casino exploit and balance pass (96zm + HLE in 65_casino.js + Quiz cash-out in 67c_quiz.js):
# every game returns less than its stake in the long run, Rocket's crash curve and payout cap, Slots, Higher or Lower,
# the Quiz cap / minimum clues / daily taper, the trophy bet floor and Lucky Streak.
import asyncio,os,sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,r=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(r)[:500]),flush=True)
    if not ok:FAIL.append(name)
W="new Promise(r=>setTimeout(r,300))"
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E("()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;PFW.asked=true;P.gold=1e6;P.qzd=null;for(const a of ACH)P.ach[a.id]=1;save()}")
        # ---------------------------------------------------------------- Rocket
        r=await E("""()=>{const N=1e6,cs=new Float64Array(N);for(let i=0;i<N;i++)cs[i]=rkCrash();const out={};for(const x of[1.01,1.2,1.5,2,3,10,30,60]){let s=0;for(let i=0;i<N;i++)if(cs[i]>=x)s+=x;out[x]=+(s/N).toFixed(4)}return out}""")
        chk('Rocket returns about 96% at every cash-out target (it was exactly 100% at 1.5x and at 60x+)',all(.94<v<.975 for v in r.values()),r)
        r=await E(f"async()=>{{casinoOpen();await {W};gameOpen('rk');await {W};const g0=P.gold;cPay(5000,5000*1000);const d=P.gold-g0;lobby();await {W};const g1=P.gold;CAS.gid='sl';cPay(100,200);return [d,RKWIN,P.gold-g1]}}")
        chk('Rocket pays at most 250,000 a round; other games are not capped by it',r[0]==r[1]==250000 and r[2]==200,r)
        # ---------------------------------------------------------------- Slots
        r=await E("()=>{const W=SLW,T=Object.values(W).reduce((a,b)=>a+b,0),ks=Object.keys(W);let rtp=0;for(const a of ks)for(const b of ks)for(const c of ks)rtp+=W[a]*W[b]*W[c]/T**3*slotPay(a,b,c);return [+rtp.toFixed(4),SLP.crown]}")
        chk('Slots return 96.0% (crowns 125)',r==[0.96,125],r)
        # ---------------------------------------------------------------- Higher or Lower
        r=await E(f"""async()=>{{casinoOpen();await {W};gameOpen('hl');await {W};CAS.bet=1000;betRefresh();document.getElementById('h0').click();await {W};
          const hb=document.getElementById('hh'),lb=document.getElementById('hlw'),m=x=>parseFloat((x.textContent.match(/×([\\d.]+)/)||[])[1]||0);
          return [HLE,HLFACE,m(hb),m(lb)]}}""")
        chk('Higher or Lower: edge .99 and no face-card cut (it paid 107.5% a guess)',r[0]==0.99 and r[1]==1 and (r[2]>0 or r[3]>0),r)
        r=await E("""()=>{const T=HLTIE,pH=r=>(1-T)*(14-r)/12,pL=r=>(1-T)*(r-2)/12;let worst=0;for(let r=2;r<=14;r++){for(const p of[pH(r),pL(r)])if(p>0)worst=Math.max(worst,p*Math.floor(HLE/p*100)/100)}
          const sim=(N,bet)=>{let tot=0;for(let n=0;n<N;n++){let cur=2+(Math.random()*13|0),cm=1,gn=0,pay;for(;;){if(cm>1&&cur>=11){pay=Math.floor(bet*cm);break}const up=pH(cur)>=pL(cur),pp=up?pH(cur):pL(cur),m=HLE/pp;
            let nx;if(Math.random()<T)nx=cur;else{nx=2+(Math.random()*12|0);if(nx>=cur)nx++}const win=up?nx>cur:nx<cur;if(!win){pay=0;break}gn++;cm=Math.floor(cm*m*100)/100;if(bet*cm>=HLMAX||gn>=HLGUESS){pay=Math.min(HLMAX,Math.floor(bet*cm));break}cur=nx}tot+=pay}return tot/N/bet};
          return [+worst.toFixed(4),+sim(4e5,1000).toFixed(4)]}""")
        chk('Higher or Lower: no single guess returns more than 99%, and the old best strategy now returns 95-98%',r[0]<=.99 and .94<r[1]<.98,r)
        # ---------------------------------------------------------------- Quiz
        r=await E("()=>{P.qzd=null;const a=[QZ.mult(1000),QZ.mult(1500),QZ.mult(9000),QZ.MINP];CAS.gid='qz';for(let i=0;i<5;i++)cPay(100,150);const b=[P.qzd.n,QZ.mult(9000),QZ.mult(800)];P.qzd.d='2000-01-01';const c=QZ.mult(9000);CAS.gid=null;return [a,b,c]}")
        chk('Quiz: tops out at 1.5x, cash out after 4 clues; after 5 winning quizzes a day the profit is a quarter, and a new day resets it',
            r[0]==[1,1.5,1.5,4] and r[1][0]==5 and abs(r[1][1]-1.125)<1e-9 and r[1][2]==0.8 and r[2]==1.5,r)
        r=await E("()=>[/picks<\\(QZ.MINP\\|\\|1\\)/.test(mQZ.toString()),/picks>=\\(QZ.MINP\\|\\|1\\)/.test(mQZ.toString()),GAMES.find(g=>g.id==='qz').d.includes('1.5x'),ACH.find(a=>a.id==='qz2x').d.includes('1.5x')]")
        chk('Quiz: the cash-out button and key both need 4 clues, and the texts say 1.5x',all(r),r)
        r=await E(f"""async()=>{{P.qzd=null;casinoOpen();await {W};gameOpen('qz');await {W};const b=[...ov.querySelectorAll('button')].find(x=>/Start|Play/.test(x.textContent)&&!x.disabled);if(b)b.click();await new Promise(r=>setTimeout(r,900));
          const co=document.getElementById('qco');return [!!co,co&&co.disabled]}}""")
        chk('Quiz: on a fresh board Cash out is disabled',r==[True,True],r)
        await E("()=>{try{lobby()}catch(e){}}")
        # ---------------------------------------------------------------- Plinko (9.7d)
        r=await E("""()=>{const out={};let top=0,rt=[];for(const n of[8,12,16])for(const k of['l','m','h']){const t=plkTab(n,k);top=Math.max(top,t[0]);let x=0;for(let i=0;i<=n;i++){let c=1;for(let j=0;j<i;j++)c=c*(n-j)/(j+1);x+=c/2**n*t[i]}rt.push(+x.toFixed(3))}return [top,Math.min(...rt),Math.max(...rt),PLMAX]}""")
        chk('Plinko: top multiplier at most 130x (was 970x) and every board returns about 93% (was 96%)',r[0]<=130 and .9<=r[1] and r[2]<=.931 and r[3]==20000,r)
        async def plk(leave):
            return await E(f"""async(leave)=>{{for(const a of ACH)P.ach[a.id]=1;casinoOpen();await {W};gameOpen('pl');await {W};ov.querySelector('#plr [data-r="16"]').click();ov.querySelector('#plk [data-k="h"]').click();
              P.gold=1e6;CAS.bet=5000;betRefresh();const g0=P.gold,r0=Math.random;Math.random=()=>0;document.getElementById('pld').click();Math.random=r0;
              if(leave){{lobby();await {W}}}else await new Promise(r=>setTimeout(r,6000));return [P.gold-g0,plkTab(16,'h')[0]]}}""",leave)
        r=await plk(False)
        chk('Plinko: a 5,000 ball in the top slot pays 20,000, never more',r[0]==20000-5000 and 5000*r[1]>20000,r)
        r=await plk(True)
        chk('Plinko: the cap also holds for balls settled when you leave mid-drop',r[0]==20000-5000,r)
        # ---------------------------------------------------------------- Blackjack and Tower Climb
        r=await E(r"()=>[/[^.]shoe\(\);bet=CAS.bet/.test(mBJ.toString()),!/sh.length<90/.test(mBJ.toString())]")
        chk('Blackjack shuffles a fresh shoe for every hand (no card counting)',all(r),r)
        r=await E("()=>{window.__twDay='2026-10-06';const a=[twBoost(),twMul(1,twBoost())];delete window.__twDay;return a}")
        chk('Tower Climb: the old boost day cannot be brought back by changing the clock',r==[False,1.44],r)
        # ---------------------------------------------------------------- trophies and streak
        r=await E("()=>{const a=P.as;delete a.rk;delete a.twf;CAS.lb=1;stat('rk',50,'max');stat('twf',10,'max');const x=[a.rk||0,a.twf||0];CAS.lb=100;stat('rk',12,'max');return [x,a.rk]}")
        chk('multiplier and Tower trophies need a bet of 100 or more (they were farmed with 1-gold bets)',r==[[0,0],12],r)
        r=await E("()=>{P.as.cwc=4;casTrack(99,99);return P.as.cwc}")
        chk('a round that only returns the stake ends a Lucky Streak',r==0,r)
        chk('no page errors',not er,er)
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
