/* ===== PENALTY KINGS 9.9b: rig fixes (96zv, after 96zu) =====
   - Arms belong to the body: the upper arm is drawn behind the shirt from a shoulder at the shirt's edge, a sleeve cap covers the joint,
     and the forearm and hand are drawn on top. (The keeper's shoulders used to sit in front of his chest; the kicker's arms looked
     like they came from behind his back.)
   - The shorts' side stripes are clipped to the shorts (they used to stick out as loose boxes at the hips).
   - A new run from behind: alternating heel flicks (an explicit knee, so the knees no longer splay sideways), pumping arms, a bob.
   - A new kick: last stride, heel cocked back, the leg whips through the ball, a high follow-through with the boot pointing where the
     ball went, then the foot comes down. Raised boots show their studded soles.
   - Hands on the head after a miss sit on the head with the elbows out (they used to cross in an X in front of the face).
   Poses may carry R.kn = [knee or null, knee or null] (explicit knee joints) and R.sole = [bool, bool]. */
function pkHeelLeg(hj,side,s,lift){/* swing leg seen from behind: knee under the hip, shin flipping back toward the camera */
 const kn={x:hj.x+side*2,y:hj.y+PKR.th*(1-.18*s)},ph=s*2.55*(lift==null?1:lift),ft={x:kn.x+side*5*s,y:kn.y+PKR.sh*Math.cos(ph)};return{kn,ft,sole:ph>1.7}}
{const k0=pkKickerPose;pkKickerPose=function(X,Y,P,t){if(P.blend)return pkPoseLerp2(pkKickerPose(X,Y,P.blend[0],t),pkKickerPose(X,Y,P.blend[1],t),P.blend[2]);
 const st=P.st||'idle',R={th:0,look:0,mood:0,kb:[1,-1],eb:[1,-1],ha:0,kn:[null,null],sole:[false,false]};
 if(st==='idle'){const bo=Math.sin(t*3)*1.6;R.hip={x:X,y:Y-74+bo};R.feet=[{x:X-18,y:Y},{x:X+18,y:Y}];R.hands=[{x:X-40,y:R.hip.y-4},{x:X+40,y:R.hip.y-4}];return R}
 if(st==='run'){const f=P.f;R.hip={x:X,y:Y-73-5*Math.abs(Math.sin(f))};R.th=Math.sin(f)*.05;R.feet=[];R.hands=[];
  for(let i=0;i<2;i++){const side=i?1:-1,s=Math.sin(f+i*Math.PI),hj=pkL(R.hip,R.th,side*PKR.hw,0);
   if(s>0){const L=pkHeelLeg(hj,side,s);R.kn[i]=L.kn;R.feet[i]=L.ft;R.sole[i]=L.sole}else R.feet[i]={x:X+side*13,y:Y}}
  for(let i=0;i<2;i++){const side=i?1:-1,a=Math.sin(f+i*Math.PI);/* the arm opposite the swing leg comes forward (up and in); the other goes back (down and out) */
   R.hands[i]={x:X+side*(34+8*Math.max(0,a)),y:R.hip.y-14+16*a}}
  return R}
 if(st==='kick'){const k=pkCl(P.k),side=1;
  /* body: drops into the plant, leans away from the kicking leg, swings round after the strike */
  const plant=pkSm(k/.28),hit=pkSm((k-.28)/.16),fol=pkSm((k-.44)/.24),rec=pkSm((k-.72)/.28);
  R.hip={x:X+10*plant-4*rec,y:Y-74+6*Math.sin(Math.PI*pkCl(k/.8))};R.th=-.06*plant-.1*hit+.2*fol-.04*rec;
  R.feet=[{x:X-16,y:Y},null];const hj=pkL(R.hip,R.th,PKR.hw,0);
  if(k<.28){/* the last stride: the kicking heel cocks back */const L=pkHeelLeg(hj,side,.35+.65*pkSm(k/.28),1.05);R.kn[1]=L.kn;R.feet[1]=L.ft;R.sole[1]=L.sole}
  else{/* the leg whips through the ball, follows through high, then comes down */
   const K=[[.28,{x:16,y:-56}],[.42,{x:64,y:-46}],[.56,{x:52,y:-104}],[.7,{x:34,y:-132}],[.86,{x:30,y:-48}],[1,{x:20,y:0}]];let fo=K[0][1];
   for(let i=1;i<K.length;i++){if(k<=K[i][0]){fo=pkLp(K[i-1][1],K[i][1],pkSm((k-K[i-1][0])/(K[i][0]-K[i-1][0])));break}fo=K[i][1]}
   R.feet[1]={x:X+fo.x,y:Y+fo.y};R.kb=[1,k<.4?1:-1];R.sole[1]=k<.33}
  /* arms: the left arm flies out for balance, the right swings back and across */
  const bal=pkSm((k-.12)/.22)*(1-rec);R.hands=[{x:X-40-38*bal,y:R.hip.y-4-38*bal},{x:X+40+16*bal-30*fol*(1-rec),y:R.hip.y-4+10*bal-6*fol}];R.eb=[1,-1];return R}
 if(st==='headhands'){const D=pkKickerPose(X,Y,{st:'idle'},t),hp=pkL(D.hip,0,0,-PKR.to-20);D.hip.y+=3;D.th=Math.sin(t*2)*.04;
  /* hands on the back of the head, elbows out wide */D.hands=[{x:hp.x-17,y:hp.y-6},{x:hp.x+17,y:hp.y-6}];D.eb=[-1,1];D.mood=1;return D}
 const r=k0.apply(this,arguments);if(!r.kn)r.kn=[null,null];if(!r.sole)r.sole=[false,false];return r}}
{const k0=pkKeeperPose;pkKeeperPose=function(x0,gy,P,t){if(P.blend)return pkPoseLerp2(pkKeeperPose(x0,gy,P.blend[0],t),pkKeeperPose(x0,gy,P.blend[1],t),P.blend[2]);
 if(P.st==='headhands'){const D=k0.call(this,x0,gy,{st:'ready',x:P.x},t),hp=pkL(D.hip,0,0,-PKR.to-20);D.hands=[{x:hp.x-20,y:hp.y-20},{x:hp.x+20,y:hp.y-20}];D.eb=[-1,1];D.mood=1;D.kn=[null,null];D.sole=[false,false];return D}
 const r=k0.apply(this,arguments);if(!r.kn)r.kn=[null,null];if(!r.sole)r.sole=[false,false];return r}}
/* blending also carries explicit knees (resolved to plain IK joints when only one side has one) */
function pkPoseLerp2(A,B,k){const R=pkPoseLerp(A,B,k),kn=[null,null],so=[false,false];
 for(let i=0;i<2;i++){const a=A.kn&&A.kn[i],b=B.kn&&B.kn[i];if(a&&b)kn[i]=pkLp(a,b,k);else if(a&&k<.5)kn[i]=a;else if(b&&k>=.5)kn[i]=b;so[i]=k<.5?!!(A.sole&&A.sole[i]):!!(B.sole&&B.sole[i])}
 R.kn=kn;R.sole=so;return R}
pkRigDraw=function(g,R,o,t,back,sc){g.save();if(sc&&sc!==1){const p=R.feet[0].y>R.feet[1].y?R.feet[0]:R.feet[1];g.translate(R.hip.x,p.y);g.scale(sc,sc);g.translate(-R.hip.x,-p.y)}
 const th=R.th,hip=R.hip,hL=pkL(hip,th,-PKR.hw,0),hR=pkL(hip,th,PKR.hw,0),SW=25,sL=pkL(hip,th,-SW,-PKR.to+13),sR=pkL(hip,th,SW,-PKR.to+13);
 const kn=R.kn||[null,null],so=R.sole||[false,false];
 const lg=[0,1].map(i=>{const h=i?hR:hL,f=R.feet[i];return kn[i]?{j:kn[i],e:f}:pkIK(h,f,PKR.th,PKR.sh,R.kb[i])});
 const ar=[pkIK(sL,R.hands[0],PKR.ua,PKR.fa,R.eb[0]),pkIK(sR,R.hands[1],PKR.ua,PKR.fa,R.eb[1])];
 const kit=o.kit,kit2=o.kit2,skin=o.skin||o.col||'#c8ccdf';
 /* ground shadow */g.fillStyle='rgba(0,0,0,.26)';g.beginPath();g.ellipse(hip.x,Math.max(R.feet[0].y,R.feet[1].y)+3,46+Math.abs(Math.sin(th))*40,9,0,0,TAU);g.fill();
 /* legs (the lifted leg first, so the standing leg overlaps it) */
 const order=R.feet[0].y<R.feet[1].y?[0,1]:[1,0];
 for(const i of order){const h=i?hR:hL,l=lg[i];pkLimb(g,[h,l.j,l.e],17,'#221c4a');const m=pkLp(l.j,l.e,.3);pkLimb(g,[m,l.e],16,kit);
  g.strokeStyle='rgba(255,255,255,.8)';g.lineWidth=3;g.beginPath();const m2=pkLp(l.j,l.e,.42),m3=pkLp(l.j,l.e,.47);g.moveTo(m2.x,m2.y);g.lineTo(m3.x,m3.y);g.stroke();
  const a=Math.atan2(l.e.y-l.j.y,l.e.x-l.j.x);g.save();g.translate(l.e.x,l.e.y);g.rotate(a-Math.PI/2);
  if(so[i]){/* the sole and studs face the camera */g.fillStyle='#14102a';g.beginPath();g.ellipse(0,4,10,13,0,0,TAU);g.fill();pkOut(g,2.4);g.fillStyle='#4a4470';g.beginPath();g.ellipse(0,4,6.5,9.5,0,0,TAU);g.fill();
   g.fillStyle='#e8e4ff';for(const [x,y] of [[-3,-1],[3,-1],[-3,6],[3,6],[0,11]]){g.beginPath();g.arc(x,y,1.5,0,TAU);g.fill()}}
  else{g.fillStyle='#14102a';g.beginPath();g.ellipse(0,5,11,12,0,0,TAU);g.fill();pkOut(g,2.4);g.fillStyle='#ffd45a';g.fillRect(-7,1,14,3)}
  g.restore()}
 /* shorts (stripes clipped to the shorts) */
 g.save();g.translate(hip.x,hip.y);g.rotate(th);
 g.fillStyle='#2a2460';g.beginPath();g.roundRect(-25,-12,50,26,9);g.fill();g.save();g.clip();g.fillStyle=kit2;g.fillRect(-25,-1,6,15);g.fillRect(19,-1,6,15);g.restore();g.beginPath();g.roundRect(-25,-12,50,26,9);pkOut(g,3);
 g.restore();
 /* upper arms, behind the shirt */
 const arm=(s,a)=>pkLimb(g,[s,a.j],15,kit);arm(sL,ar[0]);arm(sR,ar[1]);
 /* the shirt */
 g.save();g.translate(hip.x,hip.y);g.rotate(th);
 g.beginPath();g.moveTo(-23,-8);g.quadraticCurveTo(-30,-PKR.to*.55,-29,-PKR.to+4);g.quadraticCurveTo(0,-PKR.to-6,29,-PKR.to+4);g.quadraticCurveTo(30,-PKR.to*.55,23,-8);g.quadraticCurveTo(0,-3,-23,-8);g.closePath();
 const q=g.createLinearGradient(-30,0,30,0);q.addColorStop(0,pkMix(kit,'#ffffff',.18));q.addColorStop(.6,kit);q.addColorStop(1,pkMix(kit,'#12081f',.25));g.fillStyle=q;g.fill();pkOut(g,3.2);
 g.save();g.clip();g.fillStyle=kit2;g.fillRect(-32,-PKR.to,9,PKR.to);g.fillRect(23,-PKR.to,9,PKR.to);g.fillRect(-32,-PKR.to-2,64,7);g.restore();
 g.textAlign='center';g.textBaseline='middle';g.lineJoin='round';
 if(back){g.font=`800 ${o.n.length>6?8:10}px Poppins,sans-serif`;g.fillStyle='#fff8e0';g.fillText(o.n.toUpperCase(),0,-PKR.to+21);g.font="400 32px 'Pirata One',Georgia,serif";g.lineWidth=5;g.strokeStyle=PKO;g.strokeText(String(o.num),0,-PKR.to*.42);g.fillText(String(o.num),0,-PKR.to*.42)}
 else{g.font="400 30px 'Pirata One',Georgia,serif";g.lineWidth=5;g.strokeStyle=PKO;g.strokeText(String(o.num),0,-PKR.to*.45);g.fillStyle='#fff8e0';g.fillText(String(o.num),0,-PKR.to*.45);
  g.fillStyle='#ffd45a';g.beginPath();g.arc(-13,-PKR.to+18,4,0,TAU);g.fill();pkOut(g,1.6)}
 g.restore();
 /* sleeve caps: round shoulders joining the arms to the shirt (outlined on the outside only) */
 for(const [s,sd,a] of [[sL,-1,ar[0]],[sR,1,ar[1]]]){const ua=Math.atan2(a.j.y-s.y,a.j.x-s.x);g.fillStyle=kit;g.beginPath();g.arc(s.x,s.y,10.5,0,TAU);g.fill();
  const out=th+(sd<0?Math.PI:0);g.beginPath();g.arc(s.x,s.y,10.5,out-1.5,out+1.5);g.lineWidth=3.2;g.strokeStyle=PKO;g.stroke();
  g.fillStyle=kit2;g.beginPath();g.arc(s.x+Math.cos(ua)*7,s.y+Math.sin(ua)*7,4,0,TAU);g.fill()}
 /* head */
 const hp=pkL(hip,th,0,-PKR.to-20);g.save();g.translate(hp.x,hp.y);g.rotate(R.ha||th*.5);g.scale(PKR.hd,PKR.hd);if(back)pkBackHead(g,o.id,t);else pkHead(g,o.id,R.look||0,R.mood||0,t);g.restore();
 /* forearms and hands, on top */
 [ar[0],ar[1]].forEach(a=>{pkLimb(g,[a.j,a.e],14,kit);const cf=pkLp(a.j,a.e,.74);pkLimb(g,[cf,a.e],14,kit2);const ang=Math.atan2(a.e.y-a.j.y,a.e.x-a.j.x);
  if(back){g.fillStyle=skin;g.beginPath();g.arc(a.e.x,a.e.y,9,0,TAU);g.fill();pkOut(g,2.6)}else{g.save();g.translate(a.e.x,a.e.y);g.rotate(ang+Math.PI/2);pkGlove(g,0,-6,.78,'#ffd45a');g.restore()}});
 g.restore()};
