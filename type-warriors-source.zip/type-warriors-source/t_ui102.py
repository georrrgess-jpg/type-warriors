# python3 t_ui102.py [game.html] : Runestone Tower Defense 10.2 battle UI (99e_rp_ui102.js, prefix rpq).
# Damage meter (attribution for every tower type, splash / burning ground / puddles / chains / bees / stars / wells / Tide waves,
# executes, sold towers, map hazards unattributed, no overkill), the info panel numbers, the MVP card on the results; calling the next
# wave early (bonus, Space, per-wave clearing, coins / kills / supply parity with normal play, older waves' health, boss and final
# waves, freeplay, the endless Wonderland and its Championship count, defeat and quit with called waves open), Auto-start in Settings;
# the Next Wave preview (types, counts, badges, hover card); 14 towers (two temporary dummies from tools/td/rpq_dummy.js) in the bar,
# the build ring, How to Play, Tower Skins and the results, with the overlap audit (tools/td/rpu_ovl.js) at 1600x900, 1280x720 and
# 1024x640; no page errors.
import asyncio,os,sys,json
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
TD=os.path.join(HERE,'..','tools','td')
OVL=open(os.path.join(TD,'rpu_ovl.js')).read();DUMMY=open(os.path.join(TD,'rpq_dummy.js')).read()
SHOTS=os.path.join(HERE,'shots','w102_ui');os.makedirs(SHOTS,exist_ok=True)
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:700]),flush=True)
    if not ok:FAIL.append(name)
SETUP="()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const r=RPP();r.new99j=1;r.dragon=1;r.stars=%s;r.opt=r.opt||{};delete r.opt.auto;for(const k in r.tut)r.tut[k]=1;for(const k of ['build','wave','coins','upgrade','abil','rune'])r.tut[k]=1;save()}"
ALL="{moss:3,frost:3,ember:3,coral:3,wreck:2,abyss:3,meadow:1,foundry:3,storm:2,wonder:0}"
MAPS=['moss','frost','ember','wonder','coral','wreck','abyss','meadow','foundry','storm']
HELP_JS="""()=>{window.__q={
 start(m){rpStart(m);const R=RPX;R.tut=null;R.tutQ=[];return R},
 run(R,s,dt){dt=dt||1/30;for(let i=0;i<s/dt;i++){rpStep(R,dt);if(R.wst==='done'||R.over)break}},
 till(R,f,s,dt){dt=dt||1/30;for(let i=0;i<s/dt;i++){if(f())return true;rpStep(R,dt);if(R.over)break}return f()},
 build(R,p,t,tier){R.supply=1e7;if(p.tw)rpSell(p.tw);R.supply=1e7;rpBuild(p,t);p.tw.build=1;while(p.tw.tier<tier){R.supply=1e7;rpUpgrade(p.tw);p.tw.upK=1}return p.tw},
 near(R,n){/* pads closest to the road */return R.pads.slice().sort((a,b)=>R.G.dRoad(a.x,a.y)-R.G.dRoad(b.x,b.y)).slice(0,n)},
 log:[]};
 const d0=RPQX.done;RPQX.done=function(){try{__q.log.push(RPX&&RPX.wave)}catch(e){}return d0.apply(this,arguments)}}"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate;await E(OVL);await E(HELP_JS);await E(SETUP%ALL)
        # ================= 1. damage meter =================
        r=await E("""()=>{const out={};for(const t of RP_TWORDER){const R=__q.start(t==='dragon'||t==='tide'?'moss':'moss');R.supply=1e7;const ps=__q.near(R,2);const tw=__q.build(R,ps[0],t,3);
           rpWaveStart();__q.run(R,40);out[t]=[Math.round(tw.rpqD||0),Math.round(tw.dmg||0),tw.kills,Math.round(R.rpqTot),Math.round(R.rpqUn||0)];rpLeave()}return out}""")
        bad={t:v for t,v in r.items() if not(v[0]>0 and v[0]<=v[1]+1 and abs(v[3]-v[0])<=1 and v[4]==0)}
        chk(f'damage meter: each of the {len(r)} towers alone on Mossgate books damage on itself (tw.rpqD > 0), never more than the raw hits (no overkill), all of the monsters\' lost health is attributed (nothing unattributed without hazards)',not bad and len(r)>=12,bad or r)
        r=await E("""()=>{const out={};const H0=rpHurt;let cur=null;
           rpHurt=function(e,dmg,ap,s){if(cur&&e&&!e.dead){const st=(new Error().stack||'').split('\\n').slice(2).map(l=>(l.trim().match(/^at (?:Object\\.)?([\\w$.]+)/)||[])[1]).filter(n=>n&&!/^(rpHurt|h0|eval)$/.test(n));const k=(s&&s.pad?'T':s?'?':'0')+':'+(st[0]||'?');cur[k]=(cur[k]||0)+1}return H0.apply(this,arguments)};
           try{for(const t of ['brazier','bell','still','hive','grav','tide','star','mortar','dragon','prism']){const R=__q.start('moss');const tw=__q.build(R,__q.near(R,1)[0],t,3);cur={};rpWaveStart();__q.run(R,45);out[t]=[Math.round(tw.rpqD||0),Math.round(R.rpqTot),Object.keys(cur)];rpLeave()}}finally{rpHurt=H0;cur=null}return out}""")
        print('   damage call sites per tower:',json.dumps({t:v[2] for t,v in r.items()}),flush=True)
        bad={t:v for t,v in r.items() if not(v[0]>0 and abs(v[0]-v[1])<=1 and all(k.startswith('T:') for k in v[2]))}
        multi=[t for t,v in r.items() if len(set(k.split(':')[1] for k in v[2]))>=2]
        chk('delayed and secondary effects book on their tower: every rpHurt call in a run of each of ten towers (splash + burning ground, chains, puddles, bees, wells, Tide waves, stars, shells, dragon fire, beams + novas) carries that tower as its source, and the towers with secondary effects hit from more than one place',not bad and len(multi)>=3,[bad,multi])
        r=await E("""()=>{const R=__q.start('moss');const tw=__q.build(R,R.pads[0],'ballista',1);rpWaveStart();__q.run(R,3);const e=R.foes.find(f=>!f.dead);const out=[];
           e.hp=10;const d0=tw.rpqD||0;rpKillFoe(e,tw);out.push(Math.round((tw.rpqD-d0)*10)/10);
           const e2=R.foes.find(f=>!f.dead);const hp=e2.hp,u0=R.rpqUn||0;rpHurt(e2,25,99,null);out.push(Math.round(((R.rpqUn||0)-u0)*10)/10,Math.round((hp-e2.hp)*10)/10);
           const e3=R.foes.find(f=>!f.dead&&f!==e2);const h3=e3.hp;const proj={k:'blade',tw};rpHurt(e3,5,99,proj);out.push(Math.round((h3-e3.hp)*10)/10);
           const D=tw.rpqD;rpSell(tw);const S=rpqDmStats(R);out.push(S.mvp&&S.mvp.sold===1&&Math.abs(S.mvp.d-D)<1e-6,rpqFmt(999),rpqFmt(12400),rpqFmt(1234567),rpqFmt(56789));rpLeave();return out}""")
        chk('executes book the health that was left (Starfall / Engine / Midas style rpKillFoe(e,tw)); map hazards (src null) go to R.rpqUn; a projectile carrying .tw books on its tower; a sold tower stays in the stats; compact numbers 999 / 12.4k / 1.2M / 56.7k',
            r[0]==10 and r[1]==r[2]==25 and r[3]==5 and r[4] and r[5:]==['999','12.4k','1.2M','56.7k'],r)
        r=await E("""async()=>{const R=__q.start('ember');R.supply=1e7;rpWaveStart();R.vents.forEach(v=>{v.t=0.01});__q.run(R,22);const u=R.rpqUn||0;rpLeave();return Math.round(u)}""")
        chk('the Ember Crown lava vents (a map hazard) are counted as unattributed damage, not on any tower',r>0,r)
        # ================= 2. info panel =================
        r=await E("""async()=>{const R=__q.start('moss');const tw=__q.build(R,__q.near(R,1)[0],'ballista',2);rpWaveStart();__q.run(R,20);R.hold=true;R.sel=tw;await new Promise(r=>setTimeout(r,250));
           const el=document.getElementById('rpinfo'),dm=document.getElementById('rpqdm');const t1=dm?dm.textContent:'';const want=`${rpqFmt(tw.rpqD)} damage · ${rpqFmt(tw.rpqD/tw.rpqT)} DPS`;
           __q.run(R,10);R.hold=true;await new Promise(r=>setTimeout(r,250));const t2=dm.textContent,want2=`${rpqFmt(tw.rpqD)} damage · ${rpqFmt(tw.rpqD/tw.rpqT)} DPS`;const q=el.getBoundingClientRect(),kl=document.getElementById('rpikl').getBoundingClientRect(),dq=dm.getBoundingClientRect();
           const o=__rpuOvl(el);R.hold=false;return [t1===want,t2===want2&&t2!==t1,t1,t2,Math.round(q.top),Math.round(q.bottom),dq.top>=kl.bottom-1&&Math.abs(dq.left-kl.left)<3,o]}""")
        chk('info panel: "N damage · M DPS" under the defeated count, matching the tower\'s numbers and updating live; the panel sits below the toast row (top >= 128) and above the bottom row (bottom <= 770); no overlaps',
            r[0] and r[1] and r[4]>=127 and r[5]<=770 and r[6] and not r[7],r)
        await pg.screenshot(path=os.path.join(SHOTS,'info_panel.png'))
        await E("()=>rpLeave()")
        # ================= 3. call the next wave early =================
        r=await E("""async()=>{const R=__q.start('moss');__q.build(R,__q.near(R,1)[0],'prism',3);R.supply=500;rpWaveStart();__q.run(R,3);await new Promise(r=>setTimeout(r,200));
           const c=rpqWvCan(R),badge=document.getElementById('rpqb').textContent,gob=document.getElementById('rpgob').textContent,s0=R.supply;
           window.dispatchEvent(new KeyboardEvent('keydown',{key:' ',bubbles:true}));const out=[c.ok,c.b,badge,gob,R.wave,R.supply-s0,R.rpqDue.slice(),R.tx.some(t=>/called early/.test(t.s)),!!document.querySelector('#rpgo .rpqpop'),R.q.filter(q=>q.w===1).length>0,R.q.filter(q=>q.w===2).length>0];
           await new Promise(r=>setTimeout(r,250));out.push(document.getElementById('rpgob').textContent);return out}""")
        chk('during wave 1, Space calls wave 2: the panel showed "+N", the supply goes up by exactly N, R.wave 2 with wave 1 open (R.rpqDue [1]), a floating "called early" text and a "+N" pop, both waves\' monsters in the queue tagged by wave',
            r[0] and r[2]=='+'+str(r[1]) and r[3]=='Call wave 2' and r[4]==2 and r[5]==r[1] and r[6]==[1] and r[7] and r[8] and r[9] and r[10],r)
        await pg.screenshot(path=os.path.join(SHOTS,'call_early.png'))
        r=await E("""async()=>{const R=RPX;R.time+=2;const a=rpqWvCall(true);R.time+=2;const b=rpqWvCan(R);const t=R.toast&&R.toast.txt;const out=[a,R.wave,R.rpqDue.slice(),b.ok,b.why];
           /* the third call on top is refused with a reason; Enter is the same key */R.toast=null;window.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',bubbles:true}));out.push(R.wave,R.toast&&R.toast.txt);
           /* the older wave's monsters spawn with their own wave's health */
           const sp=[];const S0=rpSpawn;rpSpawn=function(){const e=S0.apply(this,arguments);if(e)sp.push([e.rpqW,e.id,Math.round(e.mx),R.wave]);return e};try{__q.run(R,8)}finally{rpSpawn=S0}
           const f1=sp.find(x=>x[0]===1&&x[1]==='scamp'&&x[3]===3),f3=sp.find(x=>x[0]===3&&x[1]==='scamp');
           out.push(f1?f1[2]:null,Math.round(RP_FOE.scamp.hp*rpHpK(R.map,1)),f3?f3[2]:null,Math.round(RP_FOE.scamp.hp*rpHpK(R.map,3)));rpLeave();return out}""")
        chk('a second call stacks wave 3 (half bonus); a third is refused ("3 waves on the road") by Space or Enter; monsters of wave 1 still spawning after the calls keep wave 1 health, wave 3 ones get wave 3 health',
            r[0] and r[1]==3 and r[2]==[1,2] and not r[3] and 'waves on the road' in r[4] and r[5]==3 and r[6] and r[7]==r[8] and r[9]==r[10] and r[7]!=r[9],r)
        # parity: the same strong defense, waves on the countdown vs called as early as possible
        r=await E("""async()=>{const res=[];for(const mode of ['normal','early']){const R=__q.start('moss');for(const p of R.pads)__q.build(R,p,'prism',3);R.supply=0;__q.log=[];R.ups=0;
           rpWaveStart();let guard=0;while(R.wst!=='done'&&guard++<40000){rpStep(R,1/30);if(mode==='early'&&R.wst==='run'&&rpqWvCan(R).ok&&R.wt>4)rpqWvCall(false)}
           res.push({mode,won:R.won,leaked:R.leaked,kills:R.kills,coins:Math.round(R.coins),cWave:Math.round(R.cWave),cKill:Math.round(R.cKill),supply:Math.round(R.supply),early:R.rpqEarly,calls:R.rpqCalls,log:__q.log.slice(),time:Math.round(R.time)});rpLeave()}return res}""")
        n,e=r[0],r[1]
        chk('parity on Mossgate Hollow (all pads Celestial Prism III): calling every wave early gives exactly the same kills, kill coins, wave coins and wave clears (1..10, in order) as waiting; the only extra is the early supply; it is faster',
            n['won'] and e['won'] and n['leaked']==e['leaked']==0 and n['kills']==e['kills'] and n['cKill']==e['cKill'] and n['cWave']==e['cWave'] and n['log']==e['log']==list(range(1,11)) and e['calls']>=5 and e['supply']-n['supply']==e['early'] and e['time']<n['time'],r)
        r=await E("""async()=>{const R=__q.start('moss');for(const p of R.pads)__q.build(R,p,'prism',3);__q.log=[];R.wave=8;R.wst='build';rpWaveStart();__q.run(R,4);
           const c=rpqWvCan(R);rpqWvCall(false);const boss=R.q.some(q=>q.id==='behemoth'),ban=R.banner&&R.banner.txt;const c2=rpqWvCan(R);
           let wins=0;const v0=rpVictory;rpVictory=function(){wins++;return v0.apply(this,arguments)};__q.till(R,()=>R.wst==='done',300);rpVictory=v0;
           const out=[c.ok,c.n,boss,ban,c2.ok,c2.why,__q.log.slice(),wins,R.won,R.wave];rpLeave();return out}""")
        chk('boss and final wave: during wave 9 of Mossgate the boss wave 10 can be called (banner and boss in the queue); nothing can be called on top of the final wave ("Final wave"); wave 9 then 10 are cleared in order and the victory comes once',
            r[0] and r[1]==10 and r[2] and r[3] and not r[4] and r[5]=='Final wave' and r[6]==[9,10] and r[7]==1 and r[8],r)
        r=await E("""async()=>{const R=__q.start('moss');for(const p of R.pads)__q.build(R,p,'prism',3);R.wave=4;R.wst='build';rpWaveStart();__q.run(R,3);rpqWvCall(false);__q.log=[];
           /* wave 4 clears first while wave 5 is still on the road: it is paid on its own */
           const ok=__q.till(R,()=>__q.log.length>0,200);const st=R.wst,w=R.wave,due=R.rpqDue.slice(),c0=R.cWave;__q.till(R,()=>R.wst==='build',200);
           const out=[ok,__q.log.slice(),st,w,due,Math.round(R.cWave-c0)===Math.round(rpWaveCoins(R.map,6))];rpLeave();return out}""")
        chk('per-wave clearing: a called-over wave (5) is paid as soon as its own monsters are gone, while the next wave keeps running (state stays "run", R.wave stays 6); wave 6 pays its own coins afterwards',
            r[0] and r[1][:1]==[5] and r[2]=='run' and r[3]==6 and r[4]==[] and r[5],r)
        r=await E("""async()=>{const out=[];
           /* the Wonderland: a defeat with called waves open counts the waves held up to the oldest open one (Championship, best, XP) */
           let R=__q.start('wonder');R.wave=19;R.wst='build';rpWaveStart();__q.run(R,2);rpqWvCall(false);R.time+=2;rpqWvCall(false);out.push(R.wave,R.rpqDue.slice());
           R.hp=0;rpDefeat();out.push(R.heldAt);rpFinish(false);out.push(R.result&&R.result.held);await new Promise(r=>setTimeout(r,300));
           /* campaign: Leave mid-run with a called wave open counts the cleared waves only */
           R=__q.start('frost');R.wave=6;R.wst='build';rpWaveStart();__q.run(R,2);rpqWvCall(false);rpFinish(false);out.push(R.result&&R.result.cleared);
           /* the Wonderland: wave 15 held, called over */
           R=__q.start('wonder');for(const p of R.pads)__q.build(R,p,'prism',4);R.wave=14;R.wst='build';rpWaveStart();__q.run(R,2);rpqWvCall(false);__q.log=[];
           const seen=[];__q.till(R,()=>{if(R.banner&&/Wave 15/.test(R.banner.txt))seen.push(1);return R.wst==='build'},300);out.push(__q.log.slice(),seen.length>0);rpLeave();return out}""")
        chk('defeat in the Wonderland at wave 22 with waves 20 and 21 called open counts 19 held (heldAt and result), a campaign quit with wave 7 open (8 called) counts 6 cleared, and the "Wave 15 held" banner still comes when wave 15 is cleared under wave 16',
            r[0]==22 and r[1]==[20,21] and r[2]==19 and r[3]==19 and r[4]==6 and r[5]==[15,16] and r[6],r)
        r=await E("""async()=>{const R=__q.start('moss');for(const p of R.pads)__q.build(R,p,'prism',3);R.wave=9;R.wst='build';rpWaveStart();__q.till(R,()=>R.wst==='done',300);R.over=false;
           rpFreeplay();rpWaveStart();__q.run(R,3);const c=rpqWvCan(R);rpqWvCall(false);await new Promise(r=>setTimeout(r,200));const lab=document.getElementById('rpgob').textContent;
           __q.till(R,()=>R.wst==='build'&&!R.rpqDue.length,400);const out=[c.ok,R.wave,R.fpWaves,lab];rpLeave();return out}""")
        chk('freeplay: waves can be called on top, and both called waves count as freeplay waves once cleared',r[0] and r[1]==12 and r[2]==2,r)
        # ================= 4. auto-start =================
        r=await E("""async()=>{const out=[rpqOpt().auto];RPSEL='moss';rampartsMenu(title);await new Promise(r=>setTimeout(r,300));rpSettings();await new Promise(r=>setTimeout(r,300));
           const m=document.getElementById('rpmod');const sw=m.querySelector('#rpqasw');out.push(!!sw,sw&&sw.getAttribute('aria-checked'),__rpuOvl(m.querySelector('.rpmc2')));sw.click();await new Promise(r=>setTimeout(r,150));
           out.push(RPP().opt.auto,m.querySelector('#rpqasw').getAttribute('aria-checked'));const q=m.querySelector('.rpmc2').getBoundingClientRect(),W=document.getElementById('wrap').getBoundingClientRect();out.push(q.top>=W.top-1&&q.bottom<=W.bottom+1);return out}""")
        chk('Auto-start next wave is off by default; the hub Settings panel has its switch (on the stage, no overlaps); switching it saves P.rp.opt.auto = 1',r[0]==0 and r[1] and r[2]=='false' and not r[3] and r[4]==1 and r[5]=='true' and r[6],r)
        await pg.screenshot(path=os.path.join(SHOTS,'settings_autostart.png'))
        r=await E("""async()=>{document.getElementById('rpmod').hidden=true;const R=__q.start('moss');for(const p of R.pads)__q.build(R,p,'prism',3);rpWaveStart();__q.till(R,()=>R.wst==='build',200);
           const t0=R.time,s0=R.supply;__q.till(R,()=>R.wst==='run',10);const dt=R.time-t0,gain=R.supply-s0,w=R.wave;rpPause(true);await new Promise(r=>setTimeout(r,300));const pz=ov.querySelector('.rppause');
           const sw=pz&&pz.querySelector('#rpqasw');const o=__rpuOvl(pz),q=pz.getBoundingClientRect(),W=document.getElementById('wrap').getBoundingClientRect();
           sw.click();await new Promise(r=>setTimeout(r,150));const off=rpqOpt().auto;rpPause(false);__q.till(R,()=>R.wst==='build',200);const t1=R.time;__q.till(R,()=>R.wst==='run',30);const dt2=R.time-t1;rpLeave();
           return [w,Math.round(dt*10)/10,gain>0,!!sw,o,q.top>=W.top-1&&q.bottom<=W.bottom+1,off,Math.round(dt2)]}""")
        chk('Auto-start on: wave 2 starts by itself 2 s after wave 1 is cleared (with early supply); the pause menu has the same switch (on the stage, no overlaps); switched off, the 15 s countdown is back',
            r[0]==2 and 1.9<=r[1]<=2.3 and r[2] and r[3] and not r[4] and r[5] and r[6]==0 and r[7]>=14,r)
        # ================= 5. next wave preview =================
        r=await E("""async()=>{const R=__q.start('frost');R.wave=7;R.wst='build';R.cd=9;await new Promise(r=>setTimeout(r,350));const el=document.getElementById('rpnext');
           const W=rpWave(R.map,8),agg={};for(const g of W)agg[g.id]=(agg[g.id]||0)+g.n;const ids=Object.keys(agg).sort((a,b)=>(RP_FOE[b].boss?1:0)-(RP_FOE[a].boss?1:0)||agg[b]-agg[a]);
           const chips=[...el.querySelectorAll('.rpqms .rpqm')].map(c=>c.querySelector('b').textContent);const rows=[...el.querySelectorAll('.rpqnc li')].map(l=>[l.querySelector('b').textContent,l.querySelector('i').textContent,[...l.querySelectorAll('s')].map(s=>s.textContent).join('|')]);
           const hd=el.querySelector('.rpqnh small').textContent;el.classList.add('open');await new Promise(r=>setTimeout(r,350));const card=el.querySelector('.rpqnc').getBoundingClientRect(),St=document.getElementById('wrap').getBoundingClientRect();
           const o=__rpuOvl(document.getElementById('rphud'));const out=[hd,chips,ids.slice(0,3).map(i=>'×'+agg[i]),rows.length===ids.length,rows,card.top>=St.top&&card.right<=St.right+1,o,+getComputedStyle(el.querySelector('.rpqnc')).opacity];return out}""")
        flags=' '.join(x[2] for x in r[4])
        chk('Next Wave preview (Frostfang wave 8): header "Next · Wave 8 / 15", up to three chips with the counts of the most numerous types, a hover card listing every type with its count and badges (Flying for gloom, Armor for bulwark / golem, an ability for shaman / ooze), on the stage, no overlaps',
            r[0].startswith('Next · Wave 8') and r[1]==r[2] and r[3] and ('Flying' in flags or 'Armor' in flags) and r[5] and not r[6] and r[7]>.9,r)
        await pg.screenshot(path=os.path.join(SHOTS,'next_wave_card.png'))
        r=await E("""async()=>{const R=RPX;document.getElementById('rpnext').classList.remove('open');R.wave=14;R.wst='build';R.cd=5;await new Promise(r=>setTimeout(r,300));const el=document.getElementById('rpnext');
           const boss=!!el.querySelector('.rpqboss'),bb=el.querySelector('.rpqms .rpqm .rpqbg-boss');const lab=el.querySelector('.rpqnh small').textContent;
           R.wave=12;R.wst='build';R.cd=3;rpWaveStart();for(let i=0;i<60;i++)rpStep(R,1/30);await new Promise(r=>setTimeout(r,300));rpHudTick();const lab2=el.querySelector('.rpqnh small').textContent,road=(el.querySelector('#rpqroad')||{}).textContent;R.wave=15;R.wst='run';await new Promise(r=>setTimeout(r,300));rpHudTick();
           const hid=el.hidden,go=document.getElementById('rpgob').textContent,gos=document.getElementById('rpgos').textContent;rpLeave();
           const ab=['shaman','ooze','gloom','golem','behemoth','siren','squid','titan','jelly'].map(i=>[i,rpqFoeBadges(i).join(',')]);return [boss,!!bb,lab,lab2,road,hid,go,gos,ab]}""")
        ab=dict(r[8])
        chk('the boss wave shows a Boss tag and a crown badge first; during a wave the panel previews the NEXT wave (it used to say "Next wave" over the current one) with what is still on the road; on the final wave it hides and the button says "Final wave"; badges per monster type',
            r[0] and r[1] and r[2].startswith('Next · Wave 15') and r[3].startswith('Next · Wave 14') and r[5] and 'Final wave' in r[7] and 'on the road' in (r[4] or '') and 'ab' in ab['shaman'] and 'ab' in ab['ooze'] and 'fly' in ab['gloom'] and 'arm' in ab['golem'] and 'boss' in ab['behemoth'] and 'ab' in ab['siren'] and 'fly' in ab['jelly'],r)
        # ================= 6. results: MVP =================
        await E(SETUP%ALL)
        r=await E("""async()=>{const R=__q.start('moss');const ps=__q.near(R,5);const c=__q.build(R,ps[0],'brazier',1),d=__q.build(R,ps[1],'brazier',1),a=__q.build(R,ps[2],'bell',1),b2=__q.build(R,ps[3],'ballista',1),f=__q.build(R,ps[4],'frost',1);
           rpWaveStart();__q.run(R,60);R.wave=R.map.waves;R.wst='run';R.foes=[];R.q=[];R.hp=20;rpVictory();await new Promise(r=>setTimeout(r,2700));if(document.querySelector('#rpv1'))document.querySelector('#rpv1').click();await new Promise(r=>setTimeout(r,2600));
           const box=document.querySelector('.rpres'),mv=box&&box.querySelector('.rpqmvp');const L=[a,b2,c,d,f].sort((x,y)=>y.rpqD-x.rpqD);const S=R.result.rpq;
           const bars=mv?[...mv.querySelectorAll('.rpqbars li')].map(l=>l.querySelector('b').textContent.replace(/\\s+/g,' ').trim()):[];const q=box.getBoundingClientRect(),W=document.getElementById('wrap').getBoundingClientRect();
           const nb=mv&&mv.querySelector('.rpqmvt b');const mvn=L[0];const barsOk=!!mv&&[...mv.querySelectorAll('.rpqbars li i')].every(i=>i.getBoundingClientRect().width>40);return [!!mv,mv&&mv.querySelector('.rpqmvt b').textContent,RPTW[L[0].type].n,bars,S.types.length,!!(mv&&mv.querySelector('.rpqmvi img')),__rpuOvl(box),q.top>=W.top-1&&q.bottom<=W.bottom+1,box.scrollHeight<=box.clientHeight+1,
            Math.round(S.tot),Math.round(R.rpqTot),nb&&nb.scrollWidth<=nb.clientWidth+1,c.rpqD>0&&d.rpqD>0,barsOk]}""")
        chk('results (victory): the MVP card names the tower that dealt the most damage with its art; damage bars for the top tower types (two Ember Blazers shown as one bar ×2); totals match; the card fits on the stage without scrolling or overlaps',
            r[0] and r[1]==r[2] and len(r[3])==min(4,r[4]) and r[4]>=2 and any('×2' in x for x in r[3])==r[12] and r[5] and not r[6] and r[7] and r[8] and abs(r[9]-r[10])<=2 and r[11] and r[13],r)
        await pg.screenshot(path=os.path.join(SHOTS,'results_mvp_win.png'))
        r=await E("""async()=>{rpLeave();const R=__q.start('wonder');for(const p of __q.near(R,3))__q.build(R,p,'hive',2);rpWaveStart();__q.run(R,30);R.wave=23;R.hp=0;rpDefeat();await new Promise(r=>setTimeout(r,2900));
           const box=document.querySelector('.rpres'),mv=box&&box.querySelector('.rpqmvp');const q=box.getBoundingClientRect(),W=document.getElementById('wrap').getBoundingClientRect();return [!!mv,mv&&mv.textContent.includes('Clockwork Hive'),__rpuOvl(box),q.top>=W.top-1&&q.bottom<=W.bottom+1]}""")
        chk('results (Wonderland, endless): the MVP card and damage bars are there too, on the stage, no overlaps',r[0] and r[1] and not r[2] and r[3],r)
        await pg.screenshot(path=os.path.join(SHOTS,'results_mvp_endless.png'))
        await E("()=>{rpLeave()}")
        # ================= 7. fourteen towers at three sizes =================
        await b.close()
        b=await p.chromium.launch()
        sizes=[(1600,900),(1280,720),(1024,640)];allbad={}
        for vw,vh in sizes:
            pg=await b.new_page(viewport={'width':vw,'height':vh});pg.on('pageerror',lambda e:er.append(str(e)[:300]));E=pg.evaluate
            await pg.goto(H);await pg.wait_for_timeout(1500);await E(OVL);await E(HELP_JS);await E(SETUP%ALL);await E('()=>{'+DUMMY+'}');tag=f'{vw}x{vh}'
            bad=await E("""async(M)=>{const out={};const ov2=(k,el)=>{const o=__rpuOvl(el);if(o.length)out[k]=o.slice(0,4)};
              for(const m of M){const R=__q.start(m);R.supply=1e5;await new Promise(r=>setTimeout(r,350));const h=document.getElementById('rphud');
               const bar=h.querySelector('.rpbar').getBoundingClientRect(),ab=h.querySelector('.rpabs').getBoundingClientRect(),nx=h.querySelector('#rpnext').getBoundingClientRect(),go=h.querySelector('#rpgo').getBoundingClientRect();
               const cards=[...h.querySelectorAll('.rpbar .rpcard')];if(cards.length!==14)out[m+':cards']=cards.length;
               const k=bar.width/1600*0+1;if(bar.left<ab.right-1||bar.right>Math.min(nx.left,go.left)+1)out[m+':bar']=[bar.left,bar.right,ab.right,nx.left];
               const vis=cards.filter(c=>{const co=c.querySelector('.rpcost'),kb=c.querySelector('kbd');return co&&kb&&co.getBoundingClientRect().width>8&&kb.getBoundingClientRect().width>5&&getComputedStyle(kb).visibility!=='hidden'}).length;if(vis!==14)out[m+':costkey']=vis;
               ov2(m+':build',h);rpWaveStart();for(let i=0;i<150;i++)rpStep(R,1/30);await new Promise(r=>setTimeout(r,200));ov2(m+':run',h);
               if(m==='moss'||m==='storm'){const P=R.pads,pick=f=>P.reduce((a,b)=>f(b)<f(a)?b:a);for(const pd of [pick(q=>q.x),pick(q=>-q.x),pick(q=>q.y),pick(q=>-q.y)]){R.sel=null;R.selPad=pd;await new Promise(r=>setTimeout(r,320));ov2(m+':ring'+pd.i,document.getElementById('rpring'))}R.selPad=null;
                const tw=__q.build(R,P[0],'rpqdm',1);R.sel=tw;await new Promise(r=>setTimeout(r,250));ov2(m+':info',document.getElementById('rpinfo'));R.sel=null}
               rpLeave()}
              RPSEL='wonder';RPW_FORCE=1;rampartsMenu(title);await new Promise(r=>setTimeout(r,500));{const T=[...ov.querySelectorAll('.rpasc .rpai')],arm=ov.querySelector('.rparm'),sd=ov.querySelector('.rpside');
               const lim=Math.min(arm?arm.getBoundingClientRect().top:1e9,sd?sd.getBoundingClientRect().bottom:1e9);const low=T.filter(t=>t.getBoundingClientRect().bottom>lim+1).length;if(T.length!==14||low)out.ascended=[T.length,low]}
              RPSEL='moss';RPW_FORCE=1;rampartsMenu(title);await new Promise(r=>setTimeout(r,500));ov2('hub',ov.querySelector('.rphub'));rpHowTo();await new Promise(r=>setTimeout(r,500));const hw=document.querySelector('#rpmod .rpmc2');ov2('howto',hw);
              const n=hw.querySelectorAll('.rputw>span').length;if(n!==14)out.howtoN=n;if(!/All fourteen are open/.test(hw.textContent))out.howtoTxt=1;document.getElementById('rpmod').hidden=true;
              rpSettings();await new Promise(r=>setTimeout(r,300));ov2('settings',document.querySelector('#rpmod .rpmc2'));document.getElementById('rpmod').hidden=true;
              rpSkins();await new Promise(r=>setTimeout(r,700));ov2('skins',ov);const nav=[...ov.querySelectorAll('.rpcsn')];if(nav.length<14)out.skinsN=nav.length;
              const last=nav[nav.length-1];if(last){last.scrollIntoView({block:'nearest'});await new Promise(r=>setTimeout(r,200));last.click();await new Promise(r=>setTimeout(r,500));ov2('skins_last',ov);const t=ov.querySelector('.rpcsn.on');if(!t||t.dataset.tw!==RP_TWORDER[RP_TWORDER.length-1])out.skinsLast=t&&t.dataset.tw}
              return out}""",MAPS)
            await pg.screenshot(path=os.path.join(SHOTS,f'skins14_{tag}.png'))
            # results with fourteen towers in play (mastery and MVP)
            r=await E("""async()=>{const R=__q.start('meadow');const P=R.pads;RP_TWORDER.forEach((t,i)=>{if(P[i])__q.build(R,P[i],t,2)});rpWaveStart();__q.run(R,25);R.wave=R.map.waves;R.wst='run';R.foes=[];R.q=[];R.hp=19;rpVictory();rpFinish(true);
              await new Promise(r=>setTimeout(r,2600));const box=document.querySelector('.rpres');const q=box.getBoundingClientRect(),W=document.getElementById('wrap').getBoundingClientRect();const mv=box.querySelector('.rpqmvp');return [__rpuOvl(box),q.top>=W.top-1&&q.bottom<=W.bottom+1,!!mv,!!mv&&[...mv.querySelectorAll('.rpqbars li i')].every(i=>i.getBoundingClientRect().width>40*q.width/940)]}""")
            if r[0] or not r[1] or not r[2] or not r[3]:bad['results14']=r
            await pg.screenshot(path=os.path.join(SHOTS,f'results14_{tag}.png'))
            await E("()=>{rpLeave();const R=__q.start('foundry');R.supply=1e4;}");await pg.wait_for_timeout(500);await pg.screenshot(path=os.path.join(SHOTS,f'hud14_{tag}.png'))
            await E("()=>{const R=RPX;R.selPad=R.pads[4]}");await pg.wait_for_timeout(500);await pg.screenshot(path=os.path.join(SHOTS,f'ring14_{tag}.png'));await E("()=>{RPX.selPad=null;rpLeave()}")
            allbad[tag]=bad;await pg.close()
        for tag,bad in allbad.items():
            chk(f'14 towers at {tag}: 14 cards with cost and key visible between the abilities and the wave panel on all ten maps, no overlaps in the HUD (build and run), the 14-button ring on edge pads, the info panel, the hub (the Wonderland Ascended Towers grid above the Armory bar), How to Play (14 cards, "All fourteen"), Settings, Tower Skins (all 14, the last one selectable) and the results',not bad,bad)
        r=await (await b.new_page(viewport={'width':1600,'height':900})).evaluate("()=>1")
        pg=await b.new_page(viewport={'width':1600,'height':900});pg.on('pageerror',lambda e:er.append(str(e)[:300]));E=pg.evaluate
        await pg.goto(H);await pg.wait_for_timeout(1500);await E(OVL);await E(HELP_JS);await E(SETUP%ALL);await E('()=>{'+DUMMY+'}')
        r=await E("""async(M)=>{const out=[];for(const m of M){const R=__q.start(m);R.supply=1e5;
            for(const p of R.pads){R.sel=null;R.selPad=p;await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));const el=document.getElementById('rpring'),ex=parseFloat(el.style.left),ey=parseFloat(el.style.top);
             const bs=[...el.querySelectorAll('.rprb')].map(b=>[ex+parseFloat(b.style.getPropertyValue('--x')),ey+parseFloat(b.style.getPropertyValue('--y'))]);let mn=1e9;
             for(let i=0;i<bs.length;i++)for(let j=i+1;j<bs.length;j++)mn=Math.min(mn,Math.hypot(bs[i][0]-bs[j][0],bs[i][1]-bs[j][1]));
             out.push([m,p.i,bs.length,Math.round(mn),Math.round(Math.min(...bs.map(q=>Math.hypot(q[0]-p.x,q[1]-p.y)))),bs.filter(q=>q[0]<40||q[0]>1560||q[1]<40||q[1]>860).length])}R.selPad=null;rpLeave()}return out}""",MAPS)
        bad=[x for x in r if x[2]!=14 or x[3]<80 or x[4]<70 or x[5]]
        chk(f'the build ring with 14 towers on all {len(r)} pads of the ten maps: 14 buttons on two arcs, at least 80 px apart, clear of the pad, all on the stage',not bad and len(r)>100,bad[:6])
        r=await E("""()=>{const h=HELP.Modes.find(x=>x[0]==='Runestone Tower Defense')[1];return [/fourteen/.test(h),/twelve/.test(h),/Space calls the next one early/.test(h),JSON.stringify(HELP).includes('fourteen')]}""")
        chk('help text counts the towers (fourteen with the dummies) and explains calling early; it survives JSON',r[0] and not r[1] and r[2] and r[3],r)
        chk('no page errors',not er,er[:5])
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print(FAIL)
asyncio.run(main())
