/* ===== MOONLIT FISHING update 6: art (creel tiers, baits, trophy plaques, medals, hub icons) =====
   fsCreelArt(g,tier,x,y,s,t,fill)  the fish basket, tiers 0..4 (Wicker, Sturdy, Frostkeeper, Enchanted, Moonlit Treasure);
                                    fits about +-110 x -100..95 at s=1; fill 0..1 = fish poking out of the top
   fsBaitArt(g,kind,x,y,s,t)        bait icons (worm, moth, roe, shrimp, spore, none), about +-50 at s=1
   fsPlaque(g,cx,cy,w,h,rk,t,empty) trophy-wall mount board, trim shows the rarity rk; empty = dusty with a dashed outline
   fsMedal(g,kind,x,y,s,t,got)      achievement medal about +-40 at s=1; got=false is a dim locked silhouette
   fsIcon kinds added: trophy, board, bait, creel0..creel4.
   Performance: every static layer is painted once into a cached offscreen sprite (keyed by args and pixel scale, LRU),
   only the small animated bits (glows, runes, wisps, sparkles, wings, worms) are drawn live. Glows are cached sprites too. */
const UA_O='#1b1024',UA_O2='#12081f';
const UA_SPR=new Map(),UA_GW=new Map(),UA_GC=new Map();
const ua_ps=g=>{const k=g.getTransform();return Math.max(Math.hypot(k.a,k.b),Math.hypot(k.c,k.d))||1};
let UA_SPX=0;
/* cached sprite of fn painted over the local box (x0,y0,w,h); resolution follows the current pixel scale in 1/4 steps */
function ua_spr(g,key,x0,y0,w,h,fn){const b=Math.min(4,Math.max(.5,Math.ceil(ua_ps(g)*4-.05)/4)),id=key+'@'+b;let c=UA_SPR.get(id);
 if(!c){c=document.createElement('canvas');c.width=Math.ceil(w*b);c.height=Math.ceil(h*b);const x=c.getContext('2d');x.setTransform(b,0,0,b,-x0*b,-y0*b);x.lineJoin='round';x.lineCap='round';
  try{fn(x)}catch(e){console.error('u6art',key,e)}UA_SPX+=c.width*c.height;
  /* keep the cache under ~10M pixels (about 40MB) and 120 sprites: drop the least recently used */
  while((UA_SPX>1e7||UA_SPR.size>=120)&&UA_SPR.size){const k0=UA_SPR.keys().next().value,o=UA_SPR.get(k0);UA_SPX-=o.width*o.height;UA_SPR.delete(k0)}}else UA_SPR.delete(id);
 UA_SPR.set(id,c);g.drawImage(c,x0,y0,w,h)}
/* cheap additive glow from a cached radial sprite */
function ua_glow(g,x,y,r,c,a){if(r<=0||a<=0)return;let s=UA_GW.get(c);if(!s){s=document.createElement('canvas');s.width=s.height=64;const x2=s.getContext('2d'),q=x2.createRadialGradient(32,32,0,32,32,32);
  q.addColorStop(0,c+'ff');q.addColorStop(.3,c+'a0');q.addColorStop(.62,c+'38');q.addColorStop(1,c+'00');x2.fillStyle=q;x2.fillRect(0,0,64,64);UA_GW.set(c,s)}
 const o=g.globalCompositeOperation,oa=g.globalAlpha;g.globalCompositeOperation='lighter';g.globalAlpha=oa*Math.min(1,a);g.drawImage(s,x-r,y-r,r*2,r*2);g.globalCompositeOperation=o;g.globalAlpha=oa}
const ua_gc=(k,f)=>{let q=UA_GC.get(k);if(!q){q=f();UA_GC.set(k,q)}return q};
function ua_mix(h,a){const n=parseInt(h.slice(1,7),16);let r=n>>16,gg=n>>8&255,b=n&255;const T=a<0?0:255,p=Math.abs(a);r=Math.round(r+(T-r)*p);gg=Math.round(gg+(T-gg)*p);b=Math.round(b+(T-b)*p);return '#'+((1<<24)+(r<<16)+(gg<<8)+b).toString(16).slice(1)}
function ua_grey(h,p){const n=parseInt(h.slice(1,7),16);let r=n>>16,gg=n>>8&255,b=n&255;const l=(r*.3+gg*.55+b*.15);r=Math.round(r+(l-r)*p);gg=Math.round(gg+(l-gg)*p);b=Math.round(b+(l-b)*p);return '#'+((1<<24)+(r<<16)+(gg<<8)+b).toString(16).slice(1)}
const UA_MET={gold:['#fff6c8','#ffd45a','#d8901e','#8a5210'],brass:['#ffeab0','#e0b050','#a06a1e','#5e380c'],silver:['#ffffff','#dde4f4','#9aa6c8','#5a6488'],
 steel:['#ffffff','#d4e4f6','#8aa0c4','#4a5a80'],bronze:['#ffdcb0','#e0985a','#a85e28','#5e3014'],prism:['#fff0ff','#ffb0ec','#c870e0','#6a3a9a']};
const ua_met=(c,x0,y0,x1,y1,m)=>{const M=UA_MET[m]||UA_MET.gold;return fkLin(c,x0,y0,x1,y1,[M[0],M[1],M[2],M[1]])};
/* a stroked "tube" with an outline, used for straps, hooks, handles */
function ua_tube(c,path,w,col,hi,ow){path();c.strokeStyle=UA_O;c.lineWidth=w+(ow||3.4);c.stroke();path();c.strokeStyle=col;c.lineWidth=w;c.stroke();
 if(hi){c.save();c.translate(-w*.12,-w*.22);path();c.strokeStyle=hi;c.lineWidth=Math.max(1,w*.28);c.stroke();c.restore()}}
function ua_dot(c,x,y,r,f,lw){c.beginPath();c.arc(x,y,r,0,TAU);c.fillStyle=f;c.fill();if(lw){c.lineWidth=lw;c.strokeStyle=UA_O;c.stroke()}}
function ua_rivet(c,x,y,r,m){ua_dot(c,x,y,r,fkRad(c,x,y,r,[UA_MET[m||'brass'][0],UA_MET[m||'brass'][1],UA_MET[m||'brass'][3]]),Math.max(1,r*.45))}
/* six-armed frost crystal */
function ua_flake(c,x,y,r,col,sh){c.save();c.translate(x,y);for(const pass of [0,1]){c.strokeStyle=pass?col:sh;c.lineWidth=pass?r*.16:r*.32;c.beginPath();
 for(let i=0;i<6;i++){const a=i*Math.PI/3,ca=Math.cos(a),sa=Math.sin(a);c.moveTo(0,0);c.lineTo(ca*r,sa*r);const m=r*.55,b=r*.28;
  c.moveTo(ca*m,sa*m);c.lineTo(ca*m+Math.cos(a+.8)*b,sa*m+Math.sin(a+.8)*b);c.moveTo(ca*m,sa*m);c.lineTo(ca*m+Math.cos(a-.8)*b,sa*m+Math.sin(a-.8)*b)}c.stroke()}c.restore()}
/* faceted gem (diamond cut) centred at x,y, radius r, colours [light, mid, dark] */
function ua_gem(c,x,y,r,C,lw){c.save();c.translate(x,y);const p=()=>{c.beginPath();c.moveTo(-r,-r*.25);c.lineTo(-r*.55,-r*.8);c.lineTo(r*.55,-r*.8);c.lineTo(r,-r*.25);c.lineTo(0,r);c.closePath()};
 p();c.fillStyle=fkLin(c,-r,-r,r,r,C);c.fill();c.lineWidth=lw||Math.max(1.4,r*.22);c.strokeStyle=UA_O;c.stroke();
 c.fillStyle='rgba(255,255,255,.55)';c.beginPath();c.moveTo(-r*.55,-r*.8);c.lineTo(-r*.2,-r*.25);c.lineTo(-r,-r*.25);c.closePath();c.fill();
 c.fillStyle='rgba(0,0,0,.22)';c.beginPath();c.moveTo(r,-r*.25);c.lineTo(r*.2,-r*.25);c.lineTo(0,r);c.closePath();c.fill();
 c.strokeStyle='rgba(255,255,255,.5)';c.lineWidth=Math.max(.8,r*.1);c.beginPath();c.moveTo(-r,-r*.25);c.lineTo(r,-r*.25);c.moveTo(-r*.2,-r*.25);c.lineTo(0,r);c.stroke();c.restore()}

/* ====================================================================================================================
   CREEL
   ==================================================================================================================== */
/* body shape per tier: rim half-width w at rim y with ellipse ry, bulge mw, bottom half-width bw at by, corner radius, bottom sag */
const UA_CP=[{w:90,y:-28,ry:15,mw:99,bw:78,by:86,cr:18,sag:7},{w:92,y:-30,ry:15,mw:99,bw:83,by:85,cr:12,sag:6},{w:92,y:-24,ry:14,mw:95,bw:90,by:84,cr:8,sag:6},
 {w:80,y:-30,ry:13,mw:108,bw:64,by:86,cr:22,sag:8},{w:96,y:-20,ry:13,mw:99,bw:95,by:82,cr:8,sag:5}];
/* which fish poke out of each tier (falls back to a simple stub fish if an art module is missing) */
const UA_CF=[['ember','reed','copper','moss','willow'],['copper','whisker','ember','bramble','lily'],['frost','herring','char','smelt','narwhal'],
 ['glass','rose','tetra','cavefish','lant'],['moonfin','aurora','sun','tidecrown','arowana']];
/* fish slots: x, y (relative to rim y), rotation, scale, mirror. drawn in the order 3,4,1,2,0 */
const UA_SLOT=[[2,-30,-1.5,.42,0],[-36,-22,1.82,.38,1],[40,-24,-1.18,.39,1],[-64,-12,-1.98,.33,0],[66,-13,1.3,.33,0]];
function ua_bodyPath(c,P){const {w,y,ry,mw,bw,by,cr,sag}=P,y3=y+(by-y)*.36;c.beginPath();c.moveTo(-w,y);c.bezierCurveTo(-mw,y3,-bw,by-cr*2.4,-bw,by-cr);
 c.quadraticCurveTo(-bw,by,-bw+cr,by+sag*.3);c.quadraticCurveTo(0,by+sag,bw-cr,by+sag*.3);c.quadraticCurveTo(bw,by,bw,by-cr);c.bezierCurveTo(bw,by-cr*2.4,mw,y3,w,y);c.ellipse(0,y,w,P.ry,0,0,Math.PI,false);c.closePath()}
/* points of a horizontal ring around the basket (front half), base yy, half-width W, sag k */
function ua_ringPts(yy,W,k,a0,a1,n){const o=[];for(let i=0;i<=n;i++){const a=a0+(a1-a0)*i/n;o.push(W*Math.sin(a),yy+k*Math.cos(a))}return o}
function ua_poly(c,p,close){c.beginPath();c.moveTo(p[0],p[1]);for(let i=2;i<p.length;i+=2)c.lineTo(p[i],p[i+1]);if(close)c.closePath()}
/* woven wicker clipped to the body (caller clips): continuous horizontal weavers, upright stakes showing where a weaver passes behind */
function ua_weave(c,P,rh,S){const W=P.mw+6,top=P.y-P.ry,bot=P.by+P.sag+4,nS=S.nS,da=3.1/nS;
 c.fillStyle=S.base;c.fillRect(-W-4,top-4,W*2+8,bot-top+8);
 const SA=[];for(let i=0;i<=nS;i++)SA.push(-1.55+i*da);
 for(const a of SA){const x=W*Math.sin(a),sw=Math.max(1.5,7*Math.cos(a));c.fillStyle=S.stake[1];c.fillRect(x-sw/2,top,sw,bot-top)}
 for(let j=0,yy=P.y-P.ry*.25;yy<bot;j++,yy+=rh){const k=P.ry*(1-.15*(yy-P.y)/(P.by-P.y)),p=ua_ringPts(yy,W,k,-1.62,1.62,28),sh=(j*37%5)/5;
  ua_poly(c,p);c.strokeStyle=UA_O2;c.globalAlpha=.85;c.lineWidth=rh+.6;c.stroke();c.globalAlpha=1;c.strokeStyle=sh>.6?S.over[2]||S.over[0]:S.over[0];c.lineWidth=rh-2.4;c.stroke();
  c.save();c.translate(0,rh*.2);ua_poly(c,p);c.strokeStyle=S.over[1];c.lineWidth=rh*.32;c.stroke();c.restore();
  c.save();c.translate(0,-rh*.2);ua_poly(c,p);c.strokeStyle=S.hi;c.globalAlpha=.75;c.lineWidth=1.5;c.stroke();c.restore();
  for(let i=0;i<SA.length;i++){if((i+j)%2)continue;const a=SA[i],x=W*Math.sin(a),y=yy+k*Math.cos(a),sw=Math.max(1.2,7.4*Math.cos(a));if(sw<2)continue;
   c.beginPath();c.roundRect(x-sw/2,y-rh/2-1.2,sw,rh+2.4,sw*.45);c.fillStyle=S.stake[0];c.fill();c.lineWidth=1.5;c.strokeStyle=UA_O2+'cc';c.stroke();
   c.fillStyle=S.hi;c.globalAlpha=.55;c.fillRect(x-sw*.3,y-rh/2,Math.max(.8,sw*.22),rh);c.globalAlpha=1;c.fillStyle='rgba(0,0,0,.25)';c.fillRect(x+sw*.12,y-rh/2,sw*.3,rh)}}}
/* rounded cylinder shading, top occlusion under the rim and a darker base (caller clips) */
function ua_cylShade(c,P,cold){const W=P.mw+8,sh=cold?'40,60,120':'26,10,40';
 c.fillStyle=ua_gc('cs'+W+cold,()=>fkLin(c,-W,0,W,0,[`rgba(${sh},.62)`,`rgba(${sh},.12)`,'rgba(255,244,214,.16)','rgba(255,244,214,0)',`rgba(${sh},.08)`,`rgba(${sh},.34)`,`rgba(${sh},.7)`]));
 c.fillRect(-W,P.y-P.ry-6,W*2,P.by-P.y+P.ry+20);
 c.fillStyle=fkLin(c,0,P.y,0,P.y+P.ry+26,[`rgba(${sh},.55)`,`rgba(${sh},0)`]);c.fillRect(-W,P.y-P.ry,W*2,P.ry*2+26);
 c.fillStyle=fkLin(c,0,P.by-34,0,P.by+P.sag,[`rgba(${sh},0)`,`rgba(${sh},.45)`]);c.fillRect(-W,P.by-34,W*2,40+P.sag)}
/* rim band along the ellipse (a0..a1), styles per tier */
const UA_RIM=[{th:10,c:'#d8a466',hi:'#fff0c8',lo:'#8a5626',tick:'rgba(74,38,10,.6)'},{th:12,c:'#6a361a',hi:'#c88a5a',lo:'#3a1a0a',stitch:'#e0b070'},
 {th:11,c:'#cfe4f8',hi:'#ffffff',lo:'#7aa0cc'},{th:10,c:'#9a8ad8',hi:'#f0ecff',lo:'#4a3c90',tick:'rgba(30,16,70,.55)'},{th:12,c:'#f0b83a',hi:'#fff4b8',lo:'#9a5a10',bead:1}];
function ua_rimArc(c,tr,P,a0,a1){const R=UA_RIM[tr],{w,y,ry}=P,th=R.th,arc=(dy)=>{c.beginPath();c.ellipse(0,y+(dy||0),w,ry,0,a0,a1)};
 c.lineCap='butt';arc();c.strokeStyle=UA_O;c.lineWidth=th+4;c.stroke();arc();c.strokeStyle=R.c;c.lineWidth=th;c.stroke();
 arc(th*.26);c.strokeStyle=R.lo;c.lineWidth=th*.36;c.stroke();arc(-th*.24);c.strokeStyle=R.hi;c.globalAlpha=.75;c.lineWidth=th*.24;c.stroke();c.globalAlpha=1;
 if(R.tick){c.strokeStyle=R.tick;c.lineWidth=1.6;c.beginPath();for(let a=a0+.08;a<a1;a+=.15){const px=w*Math.cos(a),py=y+ry*Math.sin(a);c.moveTo(px-3,py-th*.42);c.lineTo(px+3,py+th*.42)}c.stroke()}
 if(R.stitch){arc();c.setLineDash([3,3.4]);c.strokeStyle=R.stitch;c.lineWidth=1.2;c.stroke();c.setLineDash([])}
 if(R.bead){for(let a=a0+.1;a<a1;a+=.2){const px=w*Math.cos(a),py=y+ry*Math.sin(a);ua_dot(c,px,py,2.1,'#fff2b0',0);ua_dot(c,px+.4,py+.6,1.1,'#b8741a',0)}}
 c.lineCap='round'}
function ua_fishIn(c,id,x,y,rot,sc,mir){c.save();c.translate(x,y);c.rotate(rot);c.scale(mir?-sc:sc,sc);
 if(typeof FISHART!=='undefined'&&FISHART[id])fishDraw(c,id,{t:1.2});
 else{fkPath(c,[-60,0,-20,-40,50,-30,98,0,50,30,-20,40]);fkFill(c,fkLin(c,0,-40,0,40,['#ffd08a','#e8783a']),5);c.beginPath();c.moveTo(-55,0);c.lineTo(-100,-34);c.lineTo(-100,34);c.closePath();fkFill(c,'#e8783a',5);fkEye(c,58,-6,10)}
 c.restore()}
function ua_ice(c,x,y,s,r){c.save();c.translate(x,y);c.rotate(r);const h=s*.5;
 c.beginPath();c.moveTo(-s,-h*.4);c.lineTo(0,-h*1.1);c.lineTo(s,-h*.4);c.lineTo(s,h*.9);c.lineTo(0,h*1.5);c.lineTo(-s,h*.9);c.closePath();c.fillStyle='rgba(110,190,245,.95)';c.fill();c.lineWidth=2;c.strokeStyle=UA_O;c.stroke();
 c.fillStyle='rgba(240,250,255,.95)';c.beginPath();c.moveTo(-s,-h*.4);c.lineTo(0,-h*1.1);c.lineTo(s,-h*.4);c.lineTo(0,h*.25);c.closePath();c.fill();
 c.fillStyle='rgba(30,90,180,.5)';c.beginPath();c.moveTo(0,h*.25);c.lineTo(s,-h*.4);c.lineTo(s,h*.9);c.lineTo(0,h*1.5);c.closePath();c.fill();
 c.strokeStyle='rgba(255,255,255,.9)';c.lineWidth=1.2;c.beginPath();c.moveTo(-s*.7,h*.1);c.lineTo(-s*.7,h*.8);c.stroke();c.restore()}
function ua_coin(c,x,y,r){c.beginPath();c.ellipse(x,y+1.6,r,r*.5,0,0,TAU);c.fillStyle='#8a5210';c.fill();c.lineWidth=1.6;c.strokeStyle=UA_O;c.stroke();
 c.beginPath();c.ellipse(x,y,r,r*.5,0,0,TAU);c.fillStyle=fkLin(c,x-r,y-r*.5,x+r,y+r*.5,['#fff6c8','#ffd45a','#d8901e']);c.fill();c.stroke();
 c.beginPath();c.ellipse(x,y,r*.6,r*.28,0,0,TAU);c.strokeStyle='#b8741a';c.lineWidth=1;c.stroke()}
function ua_fern(c,x,y,dx,h,s){c.save();c.translate(x,y);c.scale(s,1);c.strokeStyle='#1e4a1a';c.lineWidth=2.4;c.beginPath();c.moveTo(0,0);c.quadraticCurveTo(dx*.2,-h*.7,dx,-h);c.stroke();
 for(let i=1;i<=6;i++){const u=i/7,px=dx*u*u*.9+dx*.1*u,py=-h*(u*1.15-u*u*.3),r=5.5*(1-u*.6);for(const sd of [-1,1]){c.save();c.translate(px,py);c.rotate(-.9*sd+(dx>0?.3:-.3));
  c.beginPath();c.ellipse(sd*r*.9,0,r,r*.42,0,0,TAU);c.fillStyle=i%2?'#6ab84e':'#4e9a3c';c.fill();c.lineWidth=1.3;c.strokeStyle=UA_O;c.stroke();c.restore()}}c.restore()}
/* ---- back layer: handles and lids ---- */
function ua_crBack(c,tr,P){const {w,y}=P;
 if(tr===0||tr===1||tr===3){const pts=()=>{c.beginPath();c.moveTo(-w+8,y+4);c.bezierCurveTo(-w+2,-119,w-2,-119,w-8,y+4)};
  if(tr===0){c.lineCap='butt';ua_tube(c,pts,8,fkLin(c,0,-98,0,y,['#d8a468','#9a6430']),'rgba(255,236,190,.55)');c.lineCap='round'}
  else if(tr===1){c.lineCap='butt';ua_tube(c,pts,12,fkLin(c,0,-98,0,y,['#6a361c','#3e1c0a']),'rgba(220,150,100,.4)');pts();c.setLineDash([3,3.2]);c.strokeStyle='#e0b070';c.lineWidth=1.2;c.stroke();c.setLineDash([]);c.lineCap='round'}
  else{ua_tube(c,pts,9,'#4a2488','rgba(220,190,255,.5)');pts();c.setLineDash([6,5]);c.strokeStyle='#8a5ad8';c.lineWidth=6;c.stroke();c.setLineDash([]);
   pts();c.setLineDash([2,9]);c.lineDashOffset=-5;c.strokeStyle='#5af0ff';c.lineWidth=2;c.stroke();c.setLineDash([]);c.lineDashOffset=0;
   ua_gem(c,0,-94,9,['#e8ffff','#5af0ff','#2a6ab8'])}}
 if(tr===2){/* the lid, swung open behind: we see its shaded underside, a frosted top edge with a snow drift, steel hinges */
  const H=56,lid=k=>{c.beginPath();c.moveTo(-w+3+k,y);c.lineTo(-w+12+k,y-H+k*1.1);c.quadraticCurveTo(0,y-H-16+k*1.3,w-12-k,y-H+k*1.1);c.lineTo(w-3-k,y);c.ellipse(0,y,w-3-k,P.ry,0,0,Math.PI,true);c.closePath()};
  lid(0);c.fillStyle=fkLin(c,0,y-H-16,0,y,['#d8ecfc','#a8c6e6','#7a9ccc']);c.fill();c.lineWidth=3.6;c.strokeStyle=UA_O;c.stroke();
  lid(9);c.fillStyle=fkLin(c,0,y-H,0,y,['#8aaad4','#5e80b4','#3e5a8e']);c.fill();c.lineWidth=2;c.strokeStyle='rgba(20,30,70,.7)';c.stroke();
  c.save();lid(9);c.clip();c.strokeStyle='rgba(20,40,90,.45)';c.lineWidth=1.6;for(let i=-3;i<=3;i++){const bx=i*(w-12)/3.6,tx=i*(w-24)/3.6;c.beginPath();c.moveTo(bx,y+2);c.lineTo(tx,y-H);c.stroke()}
   c.strokeStyle='rgba(220,240,255,.28)';c.lineWidth=1;for(let i=-3;i<=3;i++){const bx=i*(w-12)/3.6+2.4,tx=i*(w-24)/3.6+2;c.beginPath();c.moveTo(bx,y+2);c.lineTo(tx,y-H);c.stroke()}
   c.fillStyle='rgba(235,248,255,.5)';for(let i=0;i<22;i++){c.beginPath();c.arc(-w+18+((i*41)%(w*2-36)),y-H+6+((i*23)%40),.7+(i%3)*.4,0,TAU);c.fill()}
   c.fillStyle=fkLin(c,0,y-24,0,y+4,['rgba(20,30,80,0)','rgba(20,30,80,.5)']);c.fillRect(-w,y-24,w*2,30);c.restore();
  /* hinges */for(const sx of [-48,48]){c.fillStyle=ua_met(c,sx-6,0,sx+6,0,'steel');c.beginPath();c.roundRect(sx-5.5,y-34,11,30,3);c.fill();c.lineWidth=2.4;c.strokeStyle=UA_O;c.stroke();ua_rivet(c,sx,y-28,1.8,'steel');ua_rivet(c,sx,y-17,1.8,'steel')}
  /* snow drift along the top edge */const sn=[];for(let i=0;i<=12;i++){const u=i/12,x=(-w+16)+u*(w*2-32),yy=y-H-16*Math.sin(Math.PI*u)*1.0+3;sn.push([x,yy,4+((i*7)%5)*1.1])}
  for(const pass of [0,1])for(const [sx,sy,r] of sn){c.beginPath();c.arc(sx,sy,r,0,TAU);if(pass){c.fillStyle=fkLin(c,0,sy-r,0,sy+r,['#ffffff','#e4f2ff']);c.fill()}else{c.lineWidth=3.4;c.strokeStyle=UA_O;c.stroke()}}
  c.fillStyle='rgba(150,190,230,.5)';for(const [sx,sy,r] of sn){c.beginPath();c.arc(sx,sy+r*.35,r*.6,0,Math.PI);c.fill()}
}
 if(tr===4){/* ball feet */for(const sx of [-1,1]){const fx=sx*(P.bw-14),fy=P.by+4;c.beginPath();c.ellipse(fx,fy,10,7,0,0,TAU);c.fillStyle=fkRad(c,fx,fy,10,['#fff2b0','#e8a21e','#7a4a0a']);c.fill();c.lineWidth=2.6;c.strokeStyle=UA_O;c.stroke()}
  const lid=k=>{const ww=w-2-k,yy=y-74+k*1.2;c.beginPath();c.moveTo(-ww,y);c.bezierCurveTo(-ww,y-46,-ww*.62,yy,0,yy);c.bezierCurveTo(ww*.62,yy,ww,y-46,ww,y);c.ellipse(0,y,ww,P.ry,0,0,Math.PI,true);c.closePath()};
  lid(0);c.fillStyle=ua_met(c,-w,y-74,w,y,'gold');c.fill();c.lineWidth=3.6;c.strokeStyle=UA_O;c.stroke();
  lid(9);c.fillStyle=fkLin(c,0,y-64,0,y,['#3a2a8a','#22175c','#140c3a']);c.fill();c.lineWidth=2.4;c.strokeStyle=UA_O;c.stroke();
  c.save();lid(9);c.clip();c.fillStyle='rgba(255,236,170,.85)';const st=[[-50,-40],[-24,-58],[8,-50],[36,-60],[60,-34],[-66,-18],[-10,-30],[30,-24],[50,-10],[-36,-12]];
   for(const [sx,sy] of st){fkSpark(c,sx,y+sy,2.6,'#ffe9a0',.9)}
   /* quilted velvet lines */c.strokeStyle='rgba(120,100,220,.35)';c.lineWidth=1.2;for(let i=-3;i<=3;i++){c.beginPath();c.moveTo(i*24,y+4);c.quadraticCurveTo(i*20,y-40,i*14,y-70);c.stroke()}
   c.fillStyle=fkLin(c,0,y-30,0,y+4,['rgba(255,190,80,0)','rgba(255,190,80,.4)']);c.fillRect(-w,y-30,w*2,40);c.restore();
  /* gold filigree on the lid rim */
  c.strokeStyle='#fff2b0';c.lineWidth=1.2;c.beginPath();c.moveTo(-w+6,y-8);c.bezierCurveTo(-w+6,y-48,-w*.6,y-70,0,y-70);c.bezierCurveTo(w*.6,y-70,w-6,y-48,w-6,y-8);c.setLineDash([2,4]);c.stroke();c.setLineDash([]);
  ua_gem(c,0,y-71,6,['#fff0ff','#ff7ad8','#a02a8a'])}}
/* ---- inside the opening ---- */
function ua_crInside(c,tr,P){const {w,y,ry}=P,IN=[['#7a4c24','#2a1408'],['#6a3c1c','#1e0e06'],['#6a8ec0','#1e3462'],['#5a3492','#12062a'],['#ffe0a0','#a85a14']][tr];
 c.beginPath();c.ellipse(0,y,w-1,ry,0,0,TAU);c.fillStyle=fkLin(c,0,y-ry,0,y+ry,IN);c.fill();
 if(tr===4){c.save();c.beginPath();c.ellipse(0,y,w-1,ry,0,0,TAU);c.clip();c.fillStyle=fkRad(c,0,y+4,w*.8,['#fff6c8','#ffc23a00']);c.fillRect(-w,y-ry,w*2,ry*2);c.restore()}
 ua_rimArc(c,tr,P,Math.PI,TAU)}
/* ---- inside filler in front of the fish (ferns, ice, coins) ---- */
function ua_crFill(c,tr,P){const {y,ry}=P;
 if(tr===0||tr===1){ua_fern(c,-72,y+ry*.5,-14,26,1);ua_fern(c,-50,y+ry*.8,-6,20,1);ua_fern(c,58,y+ry*.75,8,22,1);ua_fern(c,76,y+ry*.45,14,24,1)}
 if(tr===2){const X=[-76,-58,-40,-20,0,20,40,58,76],Y=[2,-2,6,1,8,2,6,-1,3];X.forEach((x,i)=>{const yy=y-3+Y[i]+(Math.abs(x)<50?3:0);ua_ice(c,x,yy,11+(i%3)*2,(i%2?.3:-.25))});
  c.fillStyle='rgba(235,248,255,.9)';for(let i=0;i<14;i++){const x=-70+i*11,yy=y+9+((i*7)%5);c.beginPath();c.arc(x,yy,1.6+(i%3)*.6,0,TAU);c.fill()}}
 if(tr===4){const X=[-80,-66,-52,-36,-20,-4,12,28,44,60,74],Y=[3,0,5,1,7,3,8,2,6,1,4];X.forEach((x,i)=>ua_coin(c,x,y+Y[i]+(Math.abs(x)<55?3:0),7));
  ua_gem(c,-28,y+4,6,['#ffd0d8','#ff3a5a','#8a0a2a']);ua_gem(c,34,y+6,6,['#d8f0ff','#3a8aff','#1a2a8a']);ua_dot(c,6,y+12,3.4,fkRad(c,6,y+12,3.4,['#ffffff','#f0e0ff','#a898c8']),1.4);ua_dot(c,12,y+13,3,fkRad(c,12,y+13,3,['#ffffff','#f0e0ff','#a898c8']),1.4)}}
/* ---- the body ---- */
function ua_crBody(c,tr,P){const bp=()=>ua_bodyPath(c,P);c.save();bp();c.clip();
 if(tr===0)ua_weave(c,P,10,{base:'#3a2010',over:['#ecc07e','#b07638','#e2b06a'],stake:['#c8904c','#6a4018'],hi:'#fff2cc',nS:13});
 else if(tr===1)ua_weave(c,P,8,{base:'#22100a',over:['#cf9450','#8e5424','#c4883e'],stake:['#9a6028','#4a2810'],hi:'#ffdca0',nS:17});
 else if(tr===3)ua_weave(c,P,10,{base:'#0e0424',over:['#8a5ae0','#4e2698','#7a4cd0'],stake:['#5a34b0','#2a1060'],hi:'#e4d0ff',nS:14});
 else if(tr===2){const W=P.mw+6,top=P.y-P.ry-4,bot=P.by+P.sag+4,N=9;c.fillStyle=fkLin(c,0,top,0,bot,['#f6fcff','#cfe4f6','#94b8de']);c.fillRect(-W,top,W*2,bot-top);
  for(let i=0;i<=N;i++){const a=-Math.PI/2+i*Math.PI/N,x=W*Math.sin(a);if(i>0){const xa=W*Math.sin(a-Math.PI/N);c.fillStyle=i%2?'rgba(255,255,255,.12)':'rgba(60,100,170,.08)';c.fillRect(xa,top,x-xa,bot-top);
    c.strokeStyle='rgba(80,120,180,.28)';c.lineWidth=1;for(let k=1;k<3;k++){const gx=xa+(x-xa)*k/3;c.beginPath();c.moveTo(gx,top);c.bezierCurveTo(gx+2,top+40,gx-2,top+70,gx+1,bot);c.stroke()}}
   c.strokeStyle='rgba(30,50,100,.6)';c.lineWidth=1.8;c.beginPath();c.moveTo(x,top);c.lineTo(x,bot);c.stroke();c.strokeStyle='rgba(255,255,255,.6)';c.lineWidth=1;c.beginPath();c.moveTo(x+1.6,top);c.lineTo(x+1.6,bot);c.stroke()}
  c.fillStyle=fkLin(c,0,P.by-18,0,P.by+8,['rgba(255,255,255,0)','rgba(255,255,255,.85)']);c.fillRect(-W,P.by-18,W*2,30);
  c.fillStyle='rgba(255,255,255,.75)';for(let i=0;i<40;i++){const x=-W+((i*53)%(W*2)),yy=P.by-4-((i*29)%22);c.beginPath();c.arc(x,yy,.8+(i%3)*.5,0,TAU);c.fill()}}
 else{const W=P.mw+6,top=P.y-P.ry-4,bot=P.by+P.sag+4;c.fillStyle=fkLin(c,0,top,0,bot,['#4a3c9a','#2a1f6c','#160e40']);c.fillRect(-W,top,W*2,bot-top);
  for(let yy=P.y+8;yy<bot;yy+=21){const p=ua_ringPts(yy,W,P.ry,-1.6,1.6,16);ua_poly(c,p);c.strokeStyle='rgba(8,4,24,.7)';c.lineWidth=2;c.stroke();c.save();c.translate(0,2);ua_poly(c,p);c.strokeStyle='rgba(150,130,255,.25)';c.lineWidth=1.2;c.stroke();c.restore()}
  c.strokeStyle='rgba(160,140,255,.12)';c.lineWidth=1;for(let i=0;i<14;i++){const yy=P.y+14+i*5.5,x0=-80+((i*37)%50);c.beginPath();c.moveTo(x0,yy+P.ry*.6);c.quadraticCurveTo(x0+30,yy+P.ry*.9,x0+60,yy+P.ry*.6);c.stroke()}}
 ua_cylShade(c,P,tr===2);c.restore();bp();c.lineWidth=3.6;c.strokeStyle=UA_O;c.lineJoin='round';c.stroke()}
/* horizontal band around the body (clipped by the caller) */
function ua_band(c,P,yb,h,fill,edge,stitch){const W=P.mw+8,top=ua_ringPts(yb-h/2,W,P.ry,-1.6,1.6,20),bot=ua_ringPts(yb+h/2,W,P.ry,1.6,-1.6,20);
 ua_poly(c,top.concat(bot),true);c.fillStyle=fill;c.fill();
 ua_poly(c,top);c.strokeStyle=UA_O;c.lineWidth=3;c.stroke();ua_poly(c,bot);c.stroke();
 if(edge){c.save();c.translate(0,2.2);ua_poly(c,top);c.strokeStyle=edge;c.lineWidth=1.8;c.stroke();c.restore();c.save();c.translate(0,-2.2);ua_poly(c,bot);c.strokeStyle='rgba(0,0,0,.35)';c.lineWidth=2;c.stroke();c.restore()}
 if(stitch){c.setLineDash([3,3.2]);c.strokeStyle=stitch;c.lineWidth=1.1;c.save();c.translate(0,3.2);ua_poly(c,top);c.stroke();c.restore();c.save();c.translate(0,-3.2);ua_poly(c,bot);c.stroke();c.restore();c.setLineDash([])}}
const ua_ringY=(P,yb,x,W)=>yb+P.ry*Math.sqrt(Math.max(0,1-(x/W)*(x/W)));
/* runes on the enchanted creel's band (shared by the sprite and the live pulse) */
const UA_GLYPH=[[[0,-1,0,1],[0,-.9,.6,-.35,0,.2]],[[-.5,-1,.5,1],[.5,-1,-.5,1]],[[0,1,0,-1],[-.6,-.35,0,-1,.6,-.35]],[[0,-1,.6,0,0,1,-.6,0,0,-1]],[[-.5,-1,-.5,1],[.5,-1,.5,1],[-.5,-.3,.5,.35]],[[0,-1,0,1],[-.55,-.6,.55,-.1],[-.55,.15,.55,.65]]];
const UA_RUNES=[-1.08,-.72,-.36,.36,.72,1.08].map((a,i)=>({x:92*Math.sin(a),y:12+13*Math.cos(a)+1,sx:6*Math.cos(a)+.8,sy:6.6,gl:UA_GLYPH[i],col:i%2?'#ff6ae0':'#5af0ff'}));
function ua_rune(c,R){c.beginPath();for(const l of R.gl){c.moveTo(R.x+l[0]*R.sx,R.y+l[1]*R.sy);for(let k=2;k<l.length;k+=2)c.lineTo(R.x+l[k]*R.sx,R.y+l[k+1]*R.sy)}c.stroke()}
/* filigree scroll (spiral end) */
function ua_scroll(c,x,y,r,dir,a0){c.beginPath();for(let i=0;i<=24;i++){const u=i/24,a=a0+dir*u*Math.PI*2.1,rr=r*(1-u*.78);const px=x+Math.cos(a)*rr,py=y+Math.sin(a)*rr;i?c.lineTo(px,py):c.moveTo(px,py)}}
function ua_gold(c,path,w){path();c.strokeStyle=UA_O;c.lineWidth=(w||2)+2.4;c.stroke();path();c.strokeStyle='#ffd45a';c.lineWidth=w||2;c.stroke();c.save();c.translate(-.4,-.6);path();c.strokeStyle='#fff6c8';c.lineWidth=(w||2)*.4;c.stroke();c.restore()}
/* ---- front rim and per-tier decorations ---- */
function ua_crFront(c,tr,P){const {w,y,ry}=P,bp=()=>ua_bodyPath(c,P);
 if(tr===1){c.save();bp();c.clip();const W=P.mw+6;ua_band(c,P,36,13,fkLin(c,0,30,0,62,['#6a361a','#3e1c0a']),'rgba(220,150,100,.45)','#e0b070');
  for(const sx of [-46,46]){const t0=ua_ringY(P,y,sx,w)-2;c.fillStyle=fkLin(c,sx-7,0,sx+7,0,['#7a4222','#4a2410','#331606']);c.fillRect(sx-7,t0,14,P.by+10-t0);
   c.strokeStyle=UA_O;c.lineWidth=2.6;c.beginPath();c.moveTo(sx-7,t0);c.lineTo(sx-7,P.by+12);c.moveTo(sx+7,t0);c.lineTo(sx+7,P.by+12);c.stroke();
   c.setLineDash([3,3.2]);c.strokeStyle='#e0b070';c.lineWidth=1.1;c.beginPath();c.moveTo(sx-4,t0);c.lineTo(sx-4,P.by+12);c.moveTo(sx+4,t0);c.lineTo(sx+4,P.by+12);c.stroke();c.setLineDash([])}
  for(const sd of [-1,1]){const cx=sd*(P.bw-3),cy=P.by+3;c.beginPath();c.arc(cx,cy,28,0,TAU);c.fillStyle=fkRad(c,cx,cy,28,['#fff0b8','#e0b050','#8a5a18']);c.fill();c.lineWidth=3;c.strokeStyle=UA_O;c.stroke();
   c.beginPath();c.arc(cx,cy,22,0,TAU);c.strokeStyle='rgba(120,70,10,.6)';c.lineWidth=1.4;c.stroke();ua_rivet(c,cx-sd*16,cy-14,2.4);ua_rivet(c,cx-sd*20,cy-2,2.4);ua_rivet(c,cx-sd*6,cy-20,2.4)}
  c.restore();bp();c.lineWidth=3.6;c.strokeStyle=UA_O;c.stroke()}
 if(tr===2){c.save();bp();c.clip();for(const yb of [-2,56])ua_band(c,P,yb,10,fkLin(c,0,yb,0,yb+P.ry+10,['#ffffff','#a8bcd8','#6a7ea8']),'rgba(255,255,255,.8)');
  for(const yb of [-2,56])for(const fx of [-.86,-.55,-.2,.2,.55,.86]){const x=fx*(P.mw+6);ua_rivet(c,x,ua_ringY(P,yb,x,P.mw+6),1.9,'steel')}
  ua_flake(c,-50,30,10,'#ffffff','rgba(60,110,180,.45)');ua_flake(c,50,22,8,'#ffffff','rgba(60,110,180,.45)');ua_flake(c,-8,40,6,'#ffffff','rgba(60,110,180,.45)');ua_flake(c,66,68,5,'#ffffff','rgba(60,110,180,.45)');ua_flake(c,-70,72,5,'#ffffff','rgba(60,110,180,.45)');
  c.restore();bp();c.lineWidth=3.6;c.strokeStyle=UA_O;c.stroke()}
 if(tr===3){c.save();bp();c.clip();ua_band(c,P,12,22,fkLin(c,0,0,0,40,['#2e1458','#160628']),'#d8d0ff');
  c.strokeStyle='#d0c8f8';c.lineWidth=1.3;c.save();c.translate(0,-9.5);ua_poly(c,ua_ringPts(12,P.mw+8,P.ry,-1.6,1.6,20));c.stroke();c.restore();c.save();c.translate(0,9.5);ua_poly(c,ua_ringPts(12,P.mw+8,P.ry,-1.6,1.6,20));c.stroke();c.restore();
  c.lineWidth=2.2;for(const R of UA_RUNES){c.strokeStyle=R.col==='#5af0ff'?'#2a7a9a':'#8a2a7a';ua_rune(c,R)}
  /* silver tips on the base */for(const sd of [-1,1]){const cx=sd*(P.bw-4),cy=P.by;c.beginPath();c.arc(cx,cy,20,0,TAU);c.fillStyle=fkRad(c,cx,cy,20,['#ffffff','#b8b0e8','#5a4ca0']);c.fill();c.lineWidth=2.6;c.strokeStyle=UA_O;c.stroke()}
  c.restore();bp();c.lineWidth=3.6;c.strokeStyle=UA_O;c.stroke();
  c.beginPath();c.arc(0,26,10,0,TAU);c.fillStyle=ua_met(c,-10,16,10,36,'silver');c.fill();c.lineWidth=2.6;c.strokeStyle=UA_O;c.stroke();ua_gem(c,0,25.5,7,['#ffe0ff','#ff5ad8','#7a1a8a'],1.8)}
 if(tr===4){c.save();bp();c.clip();
  for(const sx of [-62,62]){const t0=ua_ringY(P,y,sx,w)-2;c.fillStyle=fkLin(c,sx-7,0,sx+7,0,['#fff2b0','#ffd45a','#c8841a','#ffd45a']);c.fillRect(sx-7,t0,14,P.by+12-t0);
   c.strokeStyle=UA_O;c.lineWidth=2.6;c.beginPath();c.moveTo(sx-7,t0);c.lineTo(sx-7,P.by+12);c.moveTo(sx+7,t0);c.lineTo(sx+7,P.by+12);c.stroke();for(let yy=t0+10;yy<P.by;yy+=16)ua_rivet(c,sx,yy,2,'gold')}
  for(const sd of [-1,1]){const cx=sd*(P.bw+2),cy=P.by+2;c.beginPath();c.moveTo(cx,cy-36);c.quadraticCurveTo(cx-sd*14,cy-30,cx-sd*16,cy-16);c.quadraticCurveTo(cx-sd*30,cy-14,cx-sd*36,cy+4);c.lineTo(cx,cy+8);c.closePath();
   c.fillStyle=ua_met(c,cx-20,cy-36,cx+10,cy+8,'gold');c.fill();c.lineWidth=2.8;c.strokeStyle=UA_O;c.stroke();ua_rivet(c,cx-sd*8,cy-8,2.2,'gold')}
  /* filigree flanking the emblem */
  for(const sd of [-1,1]){ua_gold(c,()=>{c.beginPath();c.moveTo(sd*24,36);c.bezierCurveTo(sd*34,22,sd*46,24,sd*50,34);c.bezierCurveTo(sd*54,44,sd*44,50,sd*40,44)},1.8);
   ua_gold(c,()=>{c.beginPath();c.moveTo(sd*24,40);c.bezierCurveTo(sd*30,56,sd*44,60,sd*50,52)},1.6);ua_gold(c,()=>ua_scroll(c,sd*42,40,5,sd,sd>0?0:Math.PI),1.4);
   ua_gold(c,()=>{c.beginPath();c.moveTo(sd*80,4);c.bezierCurveTo(sd*72,20,sd*84,36,sd*76,52)},1.5);ua_gold(c,()=>ua_scroll(c,sd*76,58,4,-sd,-Math.PI/2),1.3)}
  c.restore();bp();c.lineWidth=3.6;c.strokeStyle=UA_O;c.stroke();
  /* moon medallion */
  const mx=0,my=34;c.beginPath();c.arc(mx,my,21,0,TAU);c.fillStyle=ua_met(c,-21,13,21,55,'gold');c.fill();c.lineWidth=3.2;c.strokeStyle=UA_O;c.stroke();
  for(let i=0;i<16;i++){const a=i/16*TAU;ua_dot(c,mx+Math.cos(a)*18,my+Math.sin(a)*18,1.3,'#fff2b0',0)}
  c.beginPath();c.arc(mx,my,15,0,TAU);c.fillStyle=fkRad(c,mx,my,15,['#3a4ab8','#1a1a6a','#0c0a30']);c.fill();c.lineWidth=2;c.strokeStyle=UA_O;c.stroke();
  c.save();c.beginPath();c.arc(mx-2,my,11,0,TAU);c.arc(mx+4,my-3,9.5,0,TAU,true);c.fillStyle=fkLin(c,mx-12,my-10,mx+6,my+10,['#fffbe0','#ffe08a','#d8a02a']);c.fill('evenodd');c.restore();
  c.beginPath();c.arc(mx-2,my,11,Math.PI*.38,Math.PI*1.62);c.strokeStyle='rgba(120,70,10,.6)';c.lineWidth=1;c.stroke();
  ua_gem(c,mx+6,my-1,5.5,['#f0ffff','#7ae8ff','#2a7ab8'],1.6);fkSpark(c,mx-8,my-10,2.6,'#ffffff',.9);
  /* side ring handles */for(const sd of [-1,1]){const hx=sd*(P.w+1),hy=y+30;c.beginPath();c.ellipse(hx,hy,5,9,0,0,TAU);c.strokeStyle=UA_O;c.lineWidth=6.5;c.stroke();c.strokeStyle='#ffd45a';c.lineWidth=3.4;c.stroke();ua_rivet(c,hx-sd*2,hy-9,3,'gold')}}
 /* front rim on top of everything below it */
 ua_rimArc(c,tr,P,0,Math.PI);
 if(tr===0){for(const sd of [-1,1]){const hx=sd*(w-7),hy=y+7;c.save();c.translate(hx,hy);c.rotate(sd*.3);c.beginPath();c.ellipse(0,0,6,8,0,0,TAU);c.fillStyle='#c08a50';c.fill();c.lineWidth=2.4;c.strokeStyle=UA_O;c.stroke();
   c.strokeStyle='rgba(80,40,10,.7)';c.lineWidth=1.2;c.beginPath();for(let k=-1;k<=1;k++){c.moveTo(-5,k*3.5-1);c.lineTo(5,k*3.5+1)}c.stroke();c.restore()}}
 if(tr===1){for(let a=.2;a<Math.PI;a+=.32)ua_rivet(c,w*Math.cos(a),y+ry*Math.sin(a),1.9);
  for(const sx of [-46,46]){const yb=ua_ringY(P,36,sx,P.mw+8);c.fillStyle=ua_met(c,sx-9,yb-9,sx+9,yb+9,'brass');c.beginPath();c.roundRect(sx-9,yb-9,18,18,3);c.fill();c.lineWidth=2.6;c.strokeStyle=UA_O;c.stroke();
   c.fillStyle='#4a2410';c.fillRect(sx-5,yb-5,10,10);c.strokeStyle=UA_O;c.lineWidth=1.4;c.strokeRect(sx-5,yb-5,10,10);c.strokeStyle='#ffe7a0';c.lineWidth=2;c.beginPath();c.moveTo(sx,yb-5);c.lineTo(sx,yb+3);c.stroke();
   const ty=ua_ringY(P,y,sx,w);c.fillStyle='#4a2410';c.beginPath();c.roundRect(sx-7,ty-9,14,16,3);c.fill();c.lineWidth=2.4;c.strokeStyle=UA_O;c.stroke();ua_rivet(c,sx,ty-1,2.4)}
  for(const sd of [-1,1]){const hx=sd*(w-6),hy=y+6;c.beginPath();c.arc(hx,hy,6,0,TAU);c.strokeStyle=UA_O;c.lineWidth=6;c.stroke();c.strokeStyle='#e0b050';c.lineWidth=3;c.stroke();ua_rivet(c,hx,hy+7,2.6)}}
 if(tr===2){/* snow drifting on the rim */const pts=[];for(let i=0,a=.1;a<Math.PI;a+=.15,i++)pts.push([w*Math.cos(a),y+ry*Math.sin(a)-4.5,3.6+((i*5)%4)*1.3]);
  for(const pass of [0,1])for(const [sx,sy,r] of pts){c.beginPath();c.arc(sx,sy,r,0,TAU);if(pass){c.fillStyle=fkLin(c,0,sy-r,0,sy+r,['#ffffff','#e2f0ff']);c.fill()}else{c.lineWidth=3.2;c.strokeStyle=UA_O;c.stroke()}}
  c.fillStyle='rgba(140,185,230,.45)';for(const [sx,sy,r] of pts){c.beginPath();c.arc(sx,sy+r*.3,r*.62,0,Math.PI);c.fill()}
  /* icicles */const IC=[[.32,10],[.62,22],[1.0,14],[1.28,27],[1.72,17],[2.05,24],[2.42,11],[2.75,18]];
  for(const [a,L] of IC){const px=w*Math.cos(a),py=y+ry*Math.sin(a)+4;c.beginPath();c.moveTo(px-4.6,py);c.quadraticCurveTo(px-1.2,py+L*.6,px+.6,py+L);c.quadraticCurveTo(px+1.6,py+L*.5,px+4.6,py);c.closePath();
   c.fillStyle=fkLin(c,0,py,0,py+L,['#ffffff','#a8e2ff','#5ab4ec']);c.fill();c.lineWidth=1.8;c.strokeStyle=UA_O;c.stroke();c.strokeStyle='rgba(255,255,255,.95)';c.lineWidth=1.1;c.beginPath();c.moveTo(px-2,py+2);c.lineTo(px-.6,py+L*.62);c.stroke()}
  /* steel latch */c.fillStyle=ua_met(c,-9,y+ry,9,y+ry+22,'steel');c.beginPath();c.roundRect(-8,y+ry+2,16,22,4);c.fill();c.lineWidth=2.6;c.strokeStyle=UA_O;c.stroke();
  c.beginPath();c.arc(0,y+ry+17,4,0,TAU);c.fillStyle='#2a3a5a';c.fill();c.lineWidth=1.6;c.stroke();ua_rivet(c,0,y+ry+7,1.8,'steel');
  for(const sd of [-1,1]){const hx=sd*(P.w+3),hy=y+26;c.beginPath();c.arc(hx,hy,7,-Math.PI/2,Math.PI/2,sd<0);c.strokeStyle=UA_O;c.lineWidth=6.5;c.stroke();c.strokeStyle='#d4e4f6';c.lineWidth=3.2;c.stroke();ua_rivet(c,hx-sd*1,hy-7,2.4,'steel');ua_rivet(c,hx-sd*1,hy+7,2.4,'steel')}}
 if(tr===3){for(let a=.25;a<Math.PI;a+=.42)ua_gem(c,w*Math.cos(a),y+ry*Math.sin(a),3.2,['#f0ffff','#5af0ff','#2a5aa8'],1.2);
  for(const sd of [-1,1]){const hx=sd*(w-6),hy=y+6;c.beginPath();c.arc(hx,hy,5.5,0,TAU);c.fillStyle=ua_met(c,hx-5,hy-5,hx+5,hy+5,'silver');c.fill();c.lineWidth=2.4;c.strokeStyle=UA_O;c.stroke()}}
 if(tr===4){for(const sd of [-1,1]){const cx=sd*w,cy=y;c.beginPath();c.moveTo(cx-sd*2,cy-6);c.lineTo(cx-sd*22,cy+4);c.quadraticCurveTo(cx-sd*12,cy+14,cx-sd*4,cy+30);c.lineTo(cx+sd*3,cy+20);c.closePath();
  c.fillStyle=ua_met(c,cx-16,cy-6,cx+8,cy+30,'gold');c.fill();c.lineWidth=2.6;c.strokeStyle=UA_O;c.stroke();ua_rivet(c,cx-sd*6,cy+8,1.9,'gold')}}}
function ua_creelSprite(c,tr,n){const P=UA_CP[tr];
 if(tr===4)ua_glow(c,0,-6,104,'#ffc23a',.2);if(tr===2)ua_glow(c,0,6,104,'#bfe8ff',.12);if(tr===3)ua_glow(c,0,-4,104,'#8a5aff',.1);
 c.fillStyle='rgba(8,4,20,.42)';c.beginPath();c.ellipse(0,P.by+P.sag*.6+2,P.bw+16,7,0,0,TAU);c.fill();
 ua_crBack(c,tr,P);ua_crInside(c,tr,P);const F=UA_CF[tr];
 for(const i of [3,4,1,2,0])if(i<n){const q=UA_SLOT[i];ua_fishIn(c,F[i],q[0]*(P.w/90),P.y+q[1],q[2],q[3],q[4])}
 ua_crFill(c,tr,P);if(tr===3)ua_glow(c,0,P.y,62,'#b07aff',.2);if(tr===4)ua_glow(c,0,P.y,70,'#ffd45a',.16);ua_crBody(c,tr,P);ua_crFront(c,tr,P)}
/* live layers */
function ua_wisps(g,t,front){for(let i=0;i<3;i++){const a=t*1.15+i*2.094,d=Math.sin(a);if((d>0)!==!!front)continue;const x=Math.cos(a)*104,y=-6+d*24+Math.sin(t*2.3+i*1.7)*7,col=i%2?'#ff6ae0':'#5af0ff',k=front?1:.55;
 g.fillStyle=col;for(let j=3;j>0;j--){const b=a-j*.17;g.globalAlpha=.45*k*(1-j/4);g.beginPath();g.arc(Math.cos(b)*104,-6+Math.sin(b)*24+Math.sin(t*2.3-j*.3+i*1.7)*7,2.6-j*.5,0,TAU);g.fill()}g.globalAlpha=1;
 ua_glow(g,x,y,15,col,.5*k);ua_dot(g,x,y,2.4,'#ffffff',0)}}
function fsCreelArt(g,tier,x,y,s,t,fill){tier=Math.max(0,Math.min(4,tier|0));fill=Math.max(0,Math.min(1,+fill||0));t=t||0;s=s||1;
 const n=fill<=0?0:Math.min(5,1+Math.floor(fill*4.999)),P=UA_CP[tier];g.save();g.translate(x,y);g.scale(s,s);
 if(tier===3)ua_wisps(g,t,0);
 ua_spr(g,'cr'+tier+n,-118,-106,236,206,c=>ua_creelSprite(c,tier,n));
 if((tier===0||tier===1)&&n){for(let i=0;i<2;i++){const u=(t*.7+i*.5)%1,dx=i?22:-30;g.fillStyle=`rgba(170,220,255,${(1-u)*.85})`;g.beginPath();g.ellipse(dx,P.by+6+u*8,1.8,2.6,0,0,TAU);g.fill()}}
 if(tier===2){for(let i=0;i<4;i++){const u=((t*.09+i*.25)%1),xx=-120+u*240,a=.32*Math.sin(Math.PI*u);ua_glow(g,xx,P.by-2+Math.sin(t+i)*3,30,'#e8f6ff',a)}
  for(let i=0;i<3;i++){const u=((t*.35+i*.33)%1);ua_glow(g,-40+i*40+Math.sin(t+i*2)*8,P.y-4-u*40,16+u*10,'#f0faff',.28*(1-u)*Math.min(1,u*5))}
  for(let i=0;i<3;i++){const a=Math.max(0,Math.sin(t*2.6+i*2.1));if(a>.05)fkSpark(g,[-56,0,58][i],P.y+[-2,4,-3][i],2+a*4,'#ffffff',a)}}
 if(tier===3){ua_glow(g,0,P.y-4,34,'#c8a0ff',.1+.08*Math.sin(t*2));ua_glow(g,0,-94,20,'#5af0ff',.35+.15*Math.sin(t*3));
  g.lineCap='round';g.lineJoin='round';for(let i=0;i<UA_RUNES.length;i++){const R=UA_RUNES[i],p=.5+.5*Math.sin(t*2.2-i*.9);ua_glow(g,R.x,R.y,11,R.col,.18+.4*p);
   g.globalAlpha=.45+.55*p;g.strokeStyle=R.col;g.lineWidth=2.4;ua_rune(g,R);g.globalAlpha=p*.85;g.strokeStyle='#ffffff';g.lineWidth=.9;ua_rune(g,R);g.globalAlpha=1}
  ua_glow(g,0,26,14,'#ff5ad8',.25+.2*Math.sin(t*2.6));ua_wisps(g,t,1)}
 if(tier===4){ua_glow(g,6,33,18,'#9ff0ff',.3+.22*Math.sin(t*2.2));ua_glow(g,0,P.y-4,40,'#ffd45a',.08+.07*Math.sin(t*1.3));
  const SP=[[-96,-40],[90,-66],[-70,-88],[104,10],[-104,40],[60,-92]];for(let i=0;i<SP.length;i++){const a=Math.max(0,Math.sin(t*2.4+i*1.9));if(a>.05)fkSpark(g,SP[i][0],SP[i][1],2+a*5,'#fff6c8',a)}
  const a2=Math.max(0,Math.sin(t*3.1));if(a2>.05)fkSpark(g,10,27,2+a2*5,'#ffffff',a2)}
 g.restore()}

/* ====================================================================================================================
   BAIT
   ==================================================================================================================== */
function ua_jarPath(c){c.beginPath();c.moveTo(-17,-28);c.lineTo(-17,-21);c.quadraticCurveTo(-28,-19,-28,-6);c.lineTo(-28,30);c.quadraticCurveTo(-28,40,-18,40);c.lineTo(18,40);c.quadraticCurveTo(28,40,28,30);c.lineTo(28,-6);c.quadraticCurveTo(28,-19,17,-21);c.lineTo(17,-28);c.closePath()}
function ua_baitBack(c,k){
 c.fillStyle='rgba(8,4,20,.4)';c.beginPath();c.ellipse(0,42,34,6,0,0,TAU);c.fill();
 if(k==='worm'){ua_jarPath(c);c.fillStyle='rgba(170,220,255,.16)';c.fill();c.save();ua_jarPath(c);c.clip();
  c.beginPath();c.moveTo(-30,6);c.quadraticCurveTo(-14,0,0,5);c.quadraticCurveTo(14,10,30,4);c.lineTo(30,44);c.lineTo(-30,44);c.closePath();c.fillStyle=fkLin(c,0,2,0,42,['#5a3820','#3a2010','#22100a']);c.fill();
  c.fillStyle='rgba(255,220,170,.18)';for(let i=0;i<26;i++){c.beginPath();c.arc(-24+((i*17)%48),10+((i*23)%28),.8+(i%3)*.5,0,TAU);c.fill()}
  ua_dot(c,-12,30,3,'#7a6a5a',1.2);ua_dot(c,14,34,2.4,'#8a7a6a',1.2);
  ua_glow(c,12,22,16,'#5aff8a',.35);ua_glow(c,-14,26,14,'#5aff8a',.3);ua_glow(c,0,26,30,'#5aff8a',.14);ua_worm(c,[10,30,24,28,22,12,6,16],5,.8);ua_worm(c,[-18,34,-24,22,-4,18,-12,25],4.4,.7);c.restore()}
 if(k==='roe'){/* scallop shell: the upper half fans out behind the eggs, the lower half is the dish */
  const fan=()=>{c.beginPath();c.moveTo(0,36);for(let i=0;i<=9;i++){const a0=-Math.PI*.93+i*Math.PI*.86/9,a1=a0+Math.PI*.86/9,r=50;if(i<9){const am=(a0+a1)/2;c.lineTo(Math.cos(a0)*r,36+Math.sin(a0)*r);c.quadraticCurveTo(Math.cos(am)*(r+7),36+Math.sin(am)*(r+7),Math.cos(a1)*r,36+Math.sin(a1)*r)}}c.closePath()};
  fan();c.fillStyle=fkRad(c,0,36,56,['#fff6ee','#ffd6d0','#f0a0b0','#c86a8a']);c.fill();c.lineWidth=3;c.strokeStyle=UA_O;c.stroke();
  c.save();fan();c.clip();for(let i=0;i<=9;i++){const a=-Math.PI*.93+i*Math.PI*.86/9;c.strokeStyle='rgba(150,60,90,.45)';c.lineWidth=1.6;c.beginPath();c.moveTo(0,36);c.lineTo(Math.cos(a)*60,36+Math.sin(a)*60);c.stroke();
   c.strokeStyle='rgba(255,255,255,.5)';c.lineWidth=1;c.beginPath();c.moveTo(0,36);c.lineTo(Math.cos(a+.07)*60,36+Math.sin(a+.07)*60);c.stroke()}c.restore();
  const E=[[0,-22,8.5],[-9,-9,9],[9,-9,9],[-20,4,9],[0,3,9.5],[20,4,9],[-30,17,8],[-11,17,9],[10,17,9],[29,17,8]];
  for(const [x,y,r] of E){c.beginPath();c.arc(x,y,r,0,TAU);c.fillStyle=fkRad(c,x,y,r,['#fffbe8','#ffd890','#ff9a96','#c8487a']);c.fill();c.lineWidth=2.2;c.strokeStyle=UA_O;c.stroke();
   ua_dot(c,x+r*.18,y+r*.15,r*.48,'rgba(255,220,140,.6)',0);fkSpark(c,x+r*.12,y+r*.1,r*.46,'#fffbe0',1);ua_dot(c,x-r*.38,y-r*.42,r*.24,'#ffffff',0)}
  c.save();c.translate(0,30);c.beginPath();c.moveTo(-40,-2);c.quadraticCurveTo(-34,12,0,14);c.quadraticCurveTo(34,12,40,-2);c.quadraticCurveTo(0,7,-40,-2);c.closePath();
  c.fillStyle=fkLin(c,0,-2,0,14,['#ffe8e4','#f4b4bc','#d07a92']);c.fill();c.lineWidth=3;c.strokeStyle=UA_O;c.stroke();c.strokeStyle='rgba(150,60,90,.5)';c.lineWidth=1.3;
  for(let i=-4;i<=4;i++){c.beginPath();c.moveTo(i*8.6,1+Math.abs(i)*.2);c.quadraticCurveTo(i*6,8,i*3,13);c.stroke()}c.beginPath();c.moveTo(-40,-2);c.quadraticCurveTo(0,7,40,-2);c.strokeStyle='#fff6f0';c.lineWidth=1.8;c.stroke();c.restore()}
 if(k==='shrimp'){const cx=4,cy=2,R=19,seg=(a0,a1,th,col)=>{const ro=R+th/2,ri=R-th/2;c.beginPath();c.arc(cx,cy,ro,a0,a1);c.arc(cx,cy,ri,a1,a0,true);c.closePath();
   const am=(a0+a1)/2;c.fillStyle=fkLin(c,cx+Math.cos(am)*ro,cy+Math.sin(am)*ro,cx+Math.cos(am)*ri,cy+Math.sin(am)*ri,col);c.fill();c.lineWidth=2.2;c.strokeStyle=UA_O;c.stroke();
   c.beginPath();c.arc(cx,cy,ro-2.2,a0+.05,a1-.05);c.strokeStyle='rgba(255,255,255,.8)';c.lineWidth=1.4;c.stroke()};
  /* tail fan */const ta=Math.PI*.6,tx=cx+Math.cos(ta)*R,ty=cy+Math.sin(ta)*R;c.save();c.translate(tx,ty);for(const [a,l] of [[2.2,17],[2.75,19],[3.3,17]]){c.save();c.rotate(a);c.beginPath();c.moveTo(0,0);c.quadraticCurveTo(l*.6,-6,l,0);c.quadraticCurveTo(l*.6,6,0,0);c.fillStyle=fkLin(c,0,0,l,0,['#9ad4f8','#d8f2ff']);c.fill();c.lineWidth=2;c.strokeStyle=UA_O;c.stroke();c.restore()}c.restore();
  /* swimmerets and walking legs */c.strokeStyle=UA_O;c.lineWidth=3.4;c.beginPath();for(let i=0;i<5;i++){const a=Math.PI*(.4-i*.2),x=cx+Math.cos(a)*(R-7),y=cy+Math.sin(a)*(R-7);c.moveTo(x,y);c.lineTo(cx+Math.cos(a)*(R-14),cy+Math.sin(a)*(R-14)+3)}
  for(let i=0;i<3;i++){const x=-18+i*5;c.moveTo(x,4);c.lineTo(x-3,14)}c.stroke();c.strokeStyle='#9ad4f8';c.lineWidth=1.6;c.stroke();
  /* abdomen plates, tail to head */const cols=['#f4fcff','#a8dcfa','#3c8ad2'];for(let i=0;i<6;i++){const a1=Math.PI*.62-i*.5,a0=a1-.58;seg(a0,a1,8.5+i*1.4,cols)}
  ua_flake(c,cx+Math.cos(.15)*R,cy+Math.sin(.15)*R,4.2,'#ffffff','rgba(40,90,170,.5)');ua_flake(c,cx+Math.cos(1.1)*R,cy+Math.sin(1.1)*R,3,'#ffffff','rgba(40,90,170,.5)');
  /* carapace (head) with the rostrum */c.beginPath();c.moveTo(cx+Math.cos(-1.0)*(R+9),cy+Math.sin(-1.0)*(R+9));c.quadraticCurveTo(-6,-30,-26,-12);c.lineTo(-44,-16);c.lineTo(-28,-6);c.quadraticCurveTo(-24,6,-10,6);c.lineTo(cx+Math.cos(-1.25)*(R-9),cy+Math.sin(-1.25)*(R-9));c.closePath();
  c.fillStyle=fkLin(c,-20,-24,-10,8,['#ffffff','#b4e2fc','#4a96dc']);c.fill();c.lineWidth=2.6;c.strokeStyle=UA_O;c.stroke();
  c.strokeStyle='rgba(255,255,255,.85)';c.lineWidth=1.4;c.beginPath();c.moveTo(-22,-14);c.quadraticCurveTo(-12,-21,-2,-19);c.stroke();c.strokeStyle='rgba(30,80,150,.45)';c.lineWidth=1.2;c.beginPath();c.moveTo(-6,-16);c.quadraticCurveTo(-10,-6,-8,4);c.stroke();
  ua_dot(c,-20,-10,4,'#0c0612',1.4);ua_dot(c,-21.2,-11.3,1.4,'#ffffff',0);ua_flake(c,-6,-10,3.2,'#ffffff','rgba(40,90,170,.5)')}
 if(k==='spore'){/* spill trail on the ground */for(let i=0;i<12;i++){const x=8+i*3.4,y=36+((i*5)%4)-(i>8?1:0);ua_dot(c,x,y,1.4+((i*3)%3)*.6,'#8ff8ff',0)}
  /* a tiny glowcap growing beside */c.save();c.translate(-34,36);c.fillStyle='#e8f8f0';c.beginPath();c.roundRect(-2,-9,4,9,1.5);c.fill();c.lineWidth=1.6;c.strokeStyle=UA_O;c.stroke();c.beginPath();c.arc(0,-9,7,Math.PI,TAU);c.closePath();c.fillStyle=fkLin(c,0,-16,0,-9,['#c8ffff','#3ad8e8']);c.fill();c.stroke();ua_dot(c,-2.4,-12,1.2,'#ffffff',0);c.restore();
  c.save();c.translate(-6,15);c.rotate(-.3);const pb=()=>{c.beginPath();c.moveTo(12,-8);c.bezierCurveTo(4,-20,-12,-25,-26,-21);c.quadraticCurveTo(-42,-14,-40,2);c.quadraticCurveTo(-39,22,-20,24);c.bezierCurveTo(-6,26,6,18,12,8);c.closePath()};
  pb();c.fillStyle=fkLin(c,-30,-24,0,24,['#7a6ad0','#4a3c98','#241a5a']);c.fill();c.lineWidth=3;c.strokeStyle=UA_O;c.stroke();
  c.save();pb();c.clip();c.fillStyle='rgba(10,4,30,.3)';c.beginPath();c.ellipse(-12,16,30,10,0,0,TAU);c.fill();
   /* cloth folds gathering into the neck */c.strokeStyle='rgba(16,8,40,.5)';c.lineWidth=1.6;for(const [ex,ey] of [[-30,-14],[-34,4],[-24,18],[-10,20]]){c.beginPath();c.moveTo(10,0);c.quadraticCurveTo((10+ex)/2,ey*.4,ex,ey);c.stroke()}
   c.strokeStyle='rgba(200,190,255,.3)';c.lineWidth=1.2;for(const [ex,ey] of [[-28,-10],[-32,8]]){c.beginPath();c.moveTo(8,-1);c.quadraticCurveTo((8+ex)/2,ey*.4-2,ex,ey-2);c.stroke()}
   /* embroidered glowcap */c.fillStyle='#e8f8f0';c.fillRect(-23,0,3,6);c.fillStyle='#8ff8ff';c.beginPath();c.arc(-21.5,1,6,Math.PI,TAU);c.closePath();c.fill();c.lineWidth=1.2;c.strokeStyle=UA_O;c.stroke();ua_dot(c,-23.5,-1.5,1.1,'#ffffff',0);c.restore();
  c.fillStyle='rgba(230,220,255,.3)';c.beginPath();c.ellipse(-24,-14,9,3.4,-.2,0,TAU);c.fill();
  /* gathered neck and a wavy open mouth */c.fillStyle='#5a4ca0';c.beginPath();c.moveTo(9,-9);c.lineTo(16,-6);c.lineTo(16,6);c.lineTo(9,9);c.closePath();c.fill();c.lineWidth=2.6;c.strokeStyle=UA_O;c.stroke();
  const fr=()=>{c.beginPath();c.moveTo(15,-6);c.quadraticCurveTo(20,-12,22,-16);for(let i=0;i<5;i++){const y0=-16+i*6.4,y1=y0+6.4;c.quadraticCurveTo(30,(y0+y1)/2,i===4?22:25,y1)}c.quadraticCurveTo(20,12,15,6);c.closePath()};
  fr();c.fillStyle=fkLin(c,15,0,30,0,['#4a3c98','#8a7ae0']);c.fill();c.lineWidth=2.6;c.strokeStyle=UA_O;c.stroke();
  c.beginPath();c.ellipse(25,0,3.6,12,0,0,TAU);c.fillStyle=fkRad(c,25,0,12,['#f0ffff','#5af0ff','#0e4a5a']);c.fill();c.lineWidth=1.8;c.strokeStyle=UA_O;c.stroke();
  c.strokeStyle=UA_O;c.lineWidth=5.6;c.beginPath();c.moveTo(12.5,-9);c.lineTo(12.5,9);c.stroke();c.strokeStyle='#ffd45a';c.lineWidth=3;c.stroke();
  c.strokeStyle=UA_O;c.lineWidth=3.6;c.beginPath();c.moveTo(12,8);c.bezierCurveTo(9,18,2,22,-4,26);c.stroke();c.strokeStyle='#ffd45a';c.lineWidth=1.8;c.stroke();ua_dot(c,-5,27,3,'#ffd45a',1.4);c.restore()}}
function ua_baitFront(c,k){
 if(k==='worm'){ua_jarPath(c);c.lineWidth=3;c.strokeStyle=UA_O;c.stroke();
  c.strokeStyle='rgba(255,255,255,.6)';c.lineWidth=3;c.beginPath();c.moveTo(-21,-6);c.lineTo(-21,28);c.stroke();c.lineWidth=1.6;c.beginPath();c.moveTo(-14,-12);c.lineTo(-14,-2);c.moveTo(21,4);c.lineTo(21,30);c.stroke();
  c.beginPath();c.ellipse(0,-28,17,4,0,0,TAU);c.fillStyle='rgba(200,235,255,.35)';c.fill();c.lineWidth=2.6;c.strokeStyle=UA_O;c.stroke();
  /* twine around the neck */c.strokeStyle='#c8a070';c.lineWidth=3;c.beginPath();c.moveTo(-18,-22);c.quadraticCurveTo(0,-19,18,-22);c.stroke();
  /* the cork lying beside */c.save();c.translate(31,34);c.rotate(-.5);c.beginPath();c.roundRect(-7,-9,14,18,3);c.fillStyle=fkLin(c,-7,0,7,0,['#e8c08a','#b88a50','#8a5a2a']);c.fill();c.lineWidth=2.4;c.strokeStyle=UA_O;c.stroke();
  c.beginPath();c.ellipse(0,-9,7,2.6,0,0,TAU);c.fillStyle='#f0d0a0';c.fill();c.lineWidth=1.8;c.stroke();c.restore()}
 if(k==='moth'){/* fuzzy body with stripes, feathery antennae */c.save();c.translate(0,-6);
  c.strokeStyle=UA_O;c.lineWidth=3.6;c.beginPath();c.moveTo(-2,-20);c.quadraticCurveTo(-8,-32,-16,-36);c.moveTo(2,-20);c.quadraticCurveTo(8,-32,16,-36);c.stroke();
  c.strokeStyle='#f4ecd8';c.lineWidth=1.8;c.stroke();c.strokeStyle='#f4ecd8';c.lineWidth=1;c.beginPath();for(let i=1;i<5;i++){const u=i/5;for(const sd of [-1,1]){const x=sd*(2+u*13),y=-20-u*15;c.moveTo(x,y);c.lineTo(x+sd*3,y+2.5);c.moveTo(x,y);c.lineTo(x-sd*1,y-3)}}c.stroke();
  c.beginPath();c.ellipse(0,-1,7,19,0,0,TAU);c.fillStyle=fkLin(c,-7,0,7,0,['#fffaf0','#f0e4c8','#c8b490']);c.fill();c.lineWidth=2.6;c.strokeStyle=UA_O;c.stroke();
  c.strokeStyle='rgba(150,120,90,.55)';c.lineWidth=1.3;c.beginPath();for(let i=0;i<4;i++){c.moveTo(-6,4+i*4.5);c.quadraticCurveTo(0,6+i*4.5,6,4+i*4.5)}c.stroke();
  ua_dot(c,0,-17,6,fkRad(c,0,-17,6,['#ffffff','#f0e4c8','#c8b490']),2.2);ua_dot(c,-2.4,-18,1.5,UA_O,0);ua_dot(c,2.4,-18,1.5,UA_O,0);c.restore()}}
function ua_mothWing(g){g.lineJoin='round';
 g.beginPath();g.moveTo(2,-4);g.bezierCurveTo(14,-34,42,-36,44,-22);g.bezierCurveTo(46,-10,30,0,4,4);g.closePath();g.fillStyle=fkLin(g,0,-34,40,6,['#ffffff','#e4eefc','#b8c8ee','#a898e0']);g.fill();g.lineWidth=2.6;g.strokeStyle=UA_O;g.stroke();
 g.beginPath();g.moveTo(3,4);g.bezierCurveTo(22,6,30,18,26,28);g.quadraticCurveTo(24,40,20,50);g.quadraticCurveTo(12,36,10,30);g.quadraticCurveTo(2,22,2,8);g.closePath();g.fillStyle=fkLin(g,0,4,20,50,['#f4f8ff','#c8d6f4','#9a8ad8']);g.fill();g.stroke();
 g.strokeStyle='rgba(120,110,190,.5)';g.lineWidth=1.1;g.beginPath();g.moveTo(4,0);g.lineTo(38,-24);g.moveTo(4,0);g.lineTo(30,-10);g.moveTo(4,6);g.lineTo(22,26);g.stroke();
 g.beginPath();g.arc(28,-18,5,0,TAU);g.fillStyle='#fff2c0';g.fill();g.lineWidth=1.6;g.strokeStyle=UA_O;g.stroke();g.beginPath();g.arc(29.5,-19,3.4,0,TAU);g.fillStyle='#b8a8e8';g.fill();
 g.beginPath();g.arc(18,20,3,0,TAU);g.fillStyle='#fff2c0';g.fill();g.lineWidth=1.3;g.stroke()}
function ua_hook(c,col){const p=()=>{c.beginPath();c.moveTo(0,-30);c.lineTo(0,18);c.arc(12,18,12,Math.PI,0,true);c.lineTo(24,4)};
 c.lineCap='round';p();c.strokeStyle=UA_O;c.lineWidth=7;c.stroke();p();c.strokeStyle=col||'#c8d4ec';c.lineWidth=3.8;c.stroke();c.save();c.translate(-1,-1);p();c.strokeStyle='rgba(255,255,255,.85)';c.lineWidth=1.2;c.stroke();c.restore();
 c.beginPath();c.moveTo(24,1);c.lineTo(28,10);c.lineTo(23,9);c.closePath();c.fillStyle=col||'#c8d4ec';c.fill();c.lineWidth=2;c.strokeStyle=UA_O;c.stroke();
 c.beginPath();c.arc(0,-34,4.5,0,TAU);c.strokeStyle=UA_O;c.lineWidth=6.5;c.stroke();c.strokeStyle=col||'#c8d4ec';c.lineWidth=3;c.stroke()}
function ua_worm(g,pts,w,a,nd){const p=()=>{g.beginPath();g.moveTo(pts[0],pts[1]);g.bezierCurveTo(pts[2],pts[3],pts[4],pts[5],pts[6],pts[7])};
 g.globalAlpha=a==null?1:a;g.lineCap='round';p();g.strokeStyle=UA_O;g.lineWidth=w+3.2;g.stroke();p();g.strokeStyle='#7affa0';g.lineWidth=w;g.stroke();
 if(!nd){p();g.setLineDash([1.2,3.6]);g.strokeStyle='rgba(20,90,40,.55)';g.lineWidth=w;g.stroke();g.setLineDash([])}g.save();g.translate(-.8,-1.2);p();g.strokeStyle='#e8ffe0';g.lineWidth=w*.28;g.stroke();g.restore();
 ua_dot(g,pts[6],pts[7],w*.62,'#9affb0',0);g.globalAlpha=1}
function fsBaitArt(g,kind,x,y,s,t){t=t||0;s=s||1;g.save();g.translate(x,y);g.scale(s,s);g.lineJoin='round';g.lineCap='round';
 if(kind==='worm'){ua_spr(g,'bw',-46,-50,92,96,c=>ua_baitBack(c,'worm'));ua_glow(g,0,22,20,'#5aff8a',.08+.08*Math.sin(t*2));
  const w1=Math.sin(t*2.2)*4,w2=Math.cos(t*1.7)*3;ua_worm(g,[-4,10,-12+w2,-6,6+w1,-22,4+w1*1.4,-40+Math.sin(t*2.2+1)*2],5.6,1,1);ua_glow(g,4+w1*1.4,-40,14,'#5aff8a',.4+.15*Math.sin(t*3));
  ua_spr(g,'bwf',-46,-50,92,96,c=>ua_baitFront(c,'worm'))}
 else if(kind==='moth'){const by=Math.sin(t*1.8)*2.5;g.translate(0,by);ua_glow(g,0,-6,52,'#dfe8ff',.34+.08*Math.sin(t*2.4));
  g.strokeStyle='rgba(240,236,216,.8)';g.lineWidth=1.2;g.beginPath();g.moveTo(0,-50-by);g.lineTo(0,-38);g.stroke();
  g.save();g.translate(0,6);g.scale(.9,.9);ua_spr(g,'bmh',-14,-44,50,82,c=>ua_hook(c,'#d8e0f4'));g.restore();
  const f=.62+.38*Math.abs(Math.cos(t*4.2));for(const sd of [-1,1]){g.save();g.translate(0,-10);g.scale(sd*f,1);ua_spr(g,'bmw',-2,-40,52,94,ua_mothWing);g.restore()}
  ua_spr(g,'bmb',-24,-50,48,74,c=>ua_baitFront(c,'moth'));
  for(let i=0;i<3;i++){const u=(t*.5+i/3)%1;fkSpark(g,-26+i*26+Math.sin(t+i)*6,20+u*20,1.5+2*Math.sin(Math.PI*u),'#ffffff',Math.sin(Math.PI*u))}}
 else if(kind==='roe'){ua_glow(g,0,0,50,'#ffb090',.26+.08*Math.sin(t*2));ua_spr(g,'br',-48,-46,96,96,c=>ua_baitBack(c,'roe'));
  const E=[[0,-22,8.5],[-9,-9,9],[9,-9,9],[-20,4,9],[0,3,9.5],[20,4,9],[-30,17,8],[-11,17,9],[10,17,9],[29,17,8]];
  for(let i=0;i<E.length;i++){const a=.5+.5*Math.sin(t*2.6+i*1.3);if(a>.55){const [ex,ey,r]=E[i];ua_glow(g,ex,ey,r*1.4,'#ffe2a0',(a-.55)*.9);fkSpark(g,ex+r*.15,ey+r*.12,r*(.3+.25*a),'#ffffff',a)}}
  const u=(t*.4)%1;fkSpark(g,24,-24+Math.sin(t)*2,2+3*Math.sin(Math.PI*u),'#fff6c8',Math.sin(Math.PI*u))}
 else if(kind==='shrimp'){ua_glow(g,0,0,46,'#9ad8ff',.2+.05*Math.sin(t*2));g.save();g.translate(0,Math.round(Math.sin(t*1.8)*3)/2);
  const aw=Math.sin(t*2.6)*4;for(const k of [0,1]){g.beginPath();g.moveTo(-28,-12+k*3);g.bezierCurveTo(-44,-30-k*2,-20-aw,-50+k*6,14+aw*(k?1:.5),-44+k*8);g.strokeStyle=UA_O;g.lineWidth=3.6;g.stroke();g.strokeStyle='#c8ecff';g.lineWidth=1.6;g.stroke()}
  ua_spr(g,'bs',-48,-46,96,96,c=>ua_baitBack(c,'shrimp'));g.restore();
  for(let i=0;i<4;i++){const a=Math.max(0,Math.sin(t*2.2+i*1.6));if(a>.05)fkSpark(g,[-30,30,34,-36][i],[18,-26,24,-6][i],1.6+a*3.6,'#ffffff',a)}}
 else if(kind==='spore'){ua_spr(g,'bp',-48,-48,96,96,c=>ua_baitBack(c,'spore'));const mx=22,my=0;ua_glow(g,mx,my,22,'#5af0ff',.4+.14*Math.sin(t*2.4));
  for(let i=0;i<9;i++){const u=(t*.32+i/9)%1,px=mx+4+Math.sin(u*6+i*2)*8+u*(i%2?12:-8),py=my-6-u*42,a=Math.sin(Math.PI*u);ua_glow(g,px,py,7,'#5af0ff',.55*a);ua_dot(g,px,py,1.5+(1-u)*.9,'#e8ffff',0)}
  for(let i=0;i<4;i++){const a=.5+.5*Math.sin(t*2+i*2);ua_glow(g,12+i*10,37,8,'#5af0ff',.35*a)}}
 else{const r=Math.sin(t*1.3)*.12;g.strokeStyle='rgba(240,236,216,.8)';g.lineWidth=1.3;g.beginPath();g.moveTo(0,-52);g.lineTo(Math.sin(r)*12,-40);g.stroke();
  g.save();g.translate(0,-50);g.rotate(r);g.translate(-6,52);ua_spr(g,'bnh',-14,-44,50,82,c=>ua_hook(c));g.restore();
  const a=Math.max(0,Math.sin(t*2.2));if(a>.05)fkSpark(g,10,26,2+a*3.5,'#ffffff',a)}
 g.restore()}

/* ====================================================================================================================
   TROPHY PLAQUE
   ==================================================================================================================== */
function ua_plqPath(c,w,h,k){const hw=w/2*k,hh=h/2*k;fkPath(c,[-1.02,-.6,-.96,-1.02,-.56,-.86,0,-1.1,.56,-.86,.96,-1.02,1.02,-.6,1.04,.22,.8,.74,.3,1,0,1.06,-.3,1,-.8,.74,-1.04,.22].map((v,i)=>v*(i%2?hh:hw)))}
const UA_TRIM={c:'#cfd6e6',u:'#6ee08a',r:'#5ab8ff',l:'#ffc23a',m:'#ff5ad8'};
function ua_plaqueSprite(c,w,h,rk,empty){const tc0=(typeof FSR!=='undefined'&&FSR[rk]&&FSR[rk].c)||UA_TRIM[rk]||'#cfd6e6',tc=empty?ua_grey(ua_mix(tc0,-.25),.7):tc0;
 /* shadow */c.save();c.translate(4,7);ua_plqPath(c,w,h,1);c.fillStyle='rgba(10,4,20,.5)';c.fill();c.restore();
 /* trim */ua_plqPath(c,w,h,1);c.fillStyle=fkLin(c,-w/2,-h/2,w/2,h/2,[ua_mix(tc,.55),tc,ua_mix(tc,-.35),ua_mix(tc,-.6)]);c.fill();c.lineWidth=3.6;c.strokeStyle=UA_O;c.stroke();
 c.save();ua_plqPath(c,w,h,1);c.clip();c.translate(2,3);ua_plqPath(c,w,h,1);c.strokeStyle='rgba(255,255,255,.5)';c.lineWidth=3;c.stroke();c.restore();
 if(rk==='r'&&!empty){for(let i=0;i<18;i++){const a=i/18*TAU,x=Math.cos(a)*w*.47,y=Math.sin(a)*h*.44;if(Math.abs(x)>w*.36||y<-h*.38)ua_dot(c,x*.98,y,2.6,fkRad(c,x,y,2.6,['#ffffff','#c8d8f0','#6a7aa0']),1.2)}}
 /* wood board */const k=.86,wb=()=>ua_plqPath(c,w,h,k);wb();
 c.fillStyle=empty?fkLin(c,-w/2,-h/2,w/2,h/2,['#6a5a50','#4a3e38','#2e2622']):fkLin(c,-w/2,-h/2,w/2,h/2,['#8a4c26','#5a2c14','#341608']);c.fill();
 c.save();wb();c.clip();c.lineWidth=1.4;for(let i=0;i<16;i++){const yy=-h/2+i*h/15+((i*13)%7)-3;c.strokeStyle=i%3?'rgba(20,6,0,.32)':'rgba(255,200,140,.10)';c.beginPath();c.moveTo(-w/2,yy);c.bezierCurveTo(-w*.2,yy+((i*29)%9)-4,w*.1,yy-((i*17)%9)+4,w/2,yy+((i*7)%5)-2);c.stroke()}
  c.strokeStyle='rgba(20,6,0,.3)';c.beginPath();c.ellipse(w*.22,h*.05,w*.05,h*.03,0,0,TAU);c.stroke();c.beginPath();c.ellipse(w*.22,h*.05,w*.025,h*.014,0,0,TAU);c.stroke();
  c.translate(2.5,3.5);wb();c.strokeStyle=empty?'rgba(220,210,190,.25)':'rgba(255,214,160,.35)';c.lineWidth=5;c.stroke();c.translate(-5,-7);wb();c.strokeStyle='rgba(10,2,0,.45)';c.lineWidth=5;c.stroke();c.translate(2.5,3.5);
  c.fillStyle=empty?'rgba(255,255,255,.04)':'rgba(255,240,220,.10)';c.beginPath();c.ellipse(-w*.16,-h*.3,w*.26,h*.08,-.15,0,TAU);c.fill();
  if(empty){c.fillStyle=fkLin(c,0,-h/2,0,h/2,['rgba(210,200,180,.16)','rgba(210,200,180,.04)']);c.fillRect(-w/2,-h/2,w,h);c.fillStyle='rgba(225,215,195,.35)';for(let i=0;i<70;i++){c.beginPath();c.arc(-w*.42+((i*67)%(w*.84)),-h*.42+((i*41)%(h*.8)),.6+(i%4)*.35,0,TAU);c.fill()}}
  c.restore();wb();c.lineWidth=2.6;c.strokeStyle=UA_O;c.stroke();
 /* carved groove */c.save();ua_plqPath(c,w,h,.78);c.strokeStyle='rgba(10,2,0,.5)';c.lineWidth=2;c.stroke();c.translate(.8,1.2);ua_plqPath(c,w,h,.78);c.strokeStyle=empty?'rgba(220,210,190,.12)':'rgba(255,210,150,.2)';c.lineWidth=1;c.stroke();c.restore();
 /* rarity decorations */
 if(!empty&&rk==='u'){for(const sd of [-1,1]){c.beginPath();c.moveTo(0,-h*.49);c.quadraticCurveTo(sd*w*.1,-h*.53,sd*w*.2,-h*.45);c.strokeStyle=UA_O;c.lineWidth=4;c.stroke();c.strokeStyle='#3a9a5a';c.lineWidth=2;c.stroke();
   for(let i=0;i<3;i++){const u=.3+i*.3,x=sd*w*.2*u,y=-h*.49-h*.035*Math.sin(Math.PI*u)+u*h*.02;c.save();c.translate(x,y);c.rotate(sd*(i%2?-.5:.9)-(i%2?Math.PI/2:0));c.beginPath();c.moveTo(0,0);c.quadraticCurveTo(5,-5,11,0);c.quadraticCurveTo(5,5,0,0);c.fillStyle=i%2?'#9af0aa':'#5ac87a';c.fill();c.lineWidth=1.5;c.strokeStyle=UA_O;c.stroke();
    c.beginPath();c.moveTo(1,0);c.lineTo(9,0);c.strokeStyle='rgba(20,80,40,.6)';c.lineWidth=.8;c.stroke();c.restore()}}ua_dot(c,0,-h*.49,4,fkRad(c,0,-h*.49,4,['#ffffff','#9af0aa','#2a8a4a']),1.6)}
 if(!empty&&rk==='l'){for(const sd of [-1,1]){ua_gold(c,()=>{c.beginPath();c.moveTo(0,-h*.5);c.bezierCurveTo(sd*w*.06,-h*.56,sd*w*.14,-h*.5,sd*w*.17,-h*.44)},2.2);ua_gold(c,()=>ua_scroll(c,sd*w*.19,-h*.455,6,sd,sd>0?Math.PI:0),1.8);
   ua_gold(c,()=>{c.beginPath();c.moveTo(sd*w*.42,-h*.42);c.bezierCurveTo(sd*w*.5,-h*.3,sd*w*.5,-h*.18,sd*w*.47,-h*.1)},2);ua_gold(c,()=>ua_scroll(c,sd*w*.44,-h*.42,5,-sd,-Math.PI/2),1.6);
   ua_gold(c,()=>{c.beginPath();c.moveTo(sd*w*.12,h*.48);c.bezierCurveTo(sd*w*.22,h*.46,sd*w*.3,h*.4,sd*w*.34,h*.33)},2);ua_gold(c,()=>ua_scroll(c,sd*w*.35,h*.31,5,sd,Math.PI/2),1.6)}
  c.save();c.translate(0,-h*.51);c.beginPath();for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,r=i%2?4:10;c.lineTo(Math.cos(a)*r,Math.sin(a)*r)}c.closePath();c.fillStyle=ua_met(c,-10,-10,10,10,'gold');c.fill();c.lineWidth=2.2;c.strokeStyle=UA_O;c.stroke();c.restore()}
 if(!empty&&rk==='m'){for(const sd of [-1,1]){ua_gold(c,()=>{c.beginPath();c.moveTo(sd*w*.06,-h*.5);c.bezierCurveTo(sd*w*.12,-h*.55,sd*w*.2,-h*.49,sd*w*.22,-h*.44)},2)}
  const GM=[[0,-h*.5,10,0],[-w*.44,-h*.44,6.5,1],[w*.44,-h*.44,6.5,2],[-w*.47,h*.16,6,3],[w*.47,h*.16,6,4],[-w*.22,h*.44,5,2],[w*.22,h*.44,5,1]],PC=[['#ffe0ff','#ff5ad8','#8a1a8a'],['#e0ffff','#5af0ff','#2a5ab8'],['#fffbe0','#ffd45a','#c8641a'],['#e8ffe8','#6ef08a','#1a7a4a'],['#f0e0ff','#a87aff','#4a2aa8']];
  for(const [x,y,r,ci] of GM){c.beginPath();c.arc(x,y,r+3,0,TAU);c.fillStyle=ua_met(c,x-r,y-r,x+r,y+r,'gold');c.fill();c.lineWidth=2;c.strokeStyle=UA_O;c.stroke();ua_gem(c,x,y+.5,r,PC[ci],1.6)}}
 /* side screws on the trim */for(const sd of [-1,1]){const x=sd*w*.465,y=-h*.04;ua_dot(c,x,y,5.2,fkRad(c,x,y,5.2,['#fff4c8','#d8a640','#6a4410']),2);c.strokeStyle='rgba(60,30,0,.8)';c.lineWidth=1.6;c.beginPath();c.moveTo(x-3,y-2);c.lineTo(x+3,y+2);c.stroke()}
 /* nameplate */{const nw=w*.4,nh=h*.13,ny=h*.335;c.beginPath();c.roundRect(-nw/2+2,ny-nh/2+4,nw,nh,5);c.fillStyle='rgba(10,4,20,.45)';c.fill();
  c.beginPath();c.moveTo(-nw/2,ny-nh/2+5);c.quadraticCurveTo(-nw/2,ny-nh/2,-nw/2+6,ny-nh/2);c.lineTo(nw/2-6,ny-nh/2);c.quadraticCurveTo(nw/2,ny-nh/2,nw/2,ny-nh/2+5);c.lineTo(nw/2+5,ny);c.lineTo(nw/2,ny+nh/2-5);c.quadraticCurveTo(nw/2,ny+nh/2,nw/2-6,ny+nh/2);c.lineTo(-nw/2+6,ny+nh/2);c.quadraticCurveTo(-nw/2,ny+nh/2,-nw/2,ny+nh/2-5);c.lineTo(-nw/2-5,ny);c.closePath();
  c.fillStyle=empty?fkLin(c,0,ny-nh/2,0,ny+nh/2,['#bca880','#8a7650','#5e4c30']):fkLin(c,0,ny-nh/2,0,ny+nh/2,['#fff0b8','#e0b050','#a06a1e','#d8a640']);c.fill();c.lineWidth=2.8;c.strokeStyle=UA_O;c.stroke();
  c.beginPath();c.roundRect(-nw/2+6,ny-nh/2+4,nw-12,nh-8,3);c.strokeStyle='rgba(110,60,10,.55)';c.lineWidth=1.2;c.stroke();c.strokeStyle='rgba(255,250,220,.5)';c.beginPath();c.moveTo(-nw/2+8,ny-nh/2+3);c.lineTo(nw/2-8,ny-nh/2+3);c.stroke();
  for(const sd of [-1,1])ua_dot(c,sd*(nw/2-2),ny,2,'#6a4410',1)}
 if(empty){/* cobweb in the upper-left of the board */c.save();c.translate(-w*.36,-h*.33);c.strokeStyle='rgba(230,225,215,.4)';c.lineWidth=.9;c.beginPath();for(let i=0;i<5;i++){const a=i*Math.PI/8;c.moveTo(0,0);c.lineTo(Math.cos(a)*w*.13,Math.sin(a)*w*.13)}
   for(let r=8;r<w*.13;r+=7){for(let i=0;i<4;i++){const a0=i*Math.PI/8,a1=(i+1)*Math.PI/8;c.moveTo(Math.cos(a0)*r,Math.sin(a0)*r);c.quadraticCurveTo(Math.cos((a0+a1)/2)*r*.8,Math.sin((a0+a1)/2)*r*.8,Math.cos(a1)*r,Math.sin(a1)*r)}}c.stroke();c.restore();
  /* faint dashed fish outline */c.save();c.translate(0,-h*.08);const fs=w/260;c.scale(fs,fs);c.beginPath();c.moveTo(-58,0);c.bezierCurveTo(-30,-44,40,-50,82,-8);c.quadraticCurveTo(90,0,82,8);c.bezierCurveTo(40,50,-30,44,-58,0);c.lineTo(-92,-30);c.quadraticCurveTo(-80,0,-92,30);c.closePath();
   c.setLineDash([8,7]);c.strokeStyle='rgba(235,220,195,.32)';c.lineWidth=3;c.stroke();c.setLineDash([]);c.beginPath();c.arc(58,-8,6,0,TAU);c.strokeStyle='rgba(235,220,195,.22)';c.lineWidth=2;c.stroke();c.restore();
  /* brass cup hook */c.save();c.translate(0,-h*.34);ua_dot(c,0,0,5,fkRad(c,0,0,5,['#fff0b8','#c8963a','#6a4410']),2);c.beginPath();c.moveTo(0,3);c.lineTo(0,12);c.arc(6,12,6,Math.PI,0,true);c.lineTo(12,8);
   c.strokeStyle=UA_O;c.lineWidth=5.4;c.stroke();c.strokeStyle='#e0b050';c.lineWidth=2.6;c.stroke();c.restore()}}
function ua_plqSheen(g,w,h,t,rk){const u=(t*.24)%1;if(u>.5)return;const x=-w*.8+u/.5*w*1.6;g.save();ua_plqPath(g,w,h,1);g.clip();
 g.translate(x,0);g.rotate(.45);g.globalCompositeOperation='lighter';g.fillStyle=ua_gc('psh',()=>fkLin(g,-24,0,24,0,['rgba(255,250,220,0)','rgba(255,250,220,.36)','rgba(255,250,220,0)']));g.fillRect(-24,-h,48,h*2);g.restore()}
function fsPlaque(g,cx,cy,w,h,rk,t,empty){w=w||260;h=h||200;t=t||0;rk=rk||'c';g.save();g.translate(cx,cy);
 const W=Math.round(w),H=Math.round(h);ua_spr(g,'pq'+rk+(empty?'e':'')+W+'x'+H,-W/2-8,-H/2-10,W+22,H+24,c=>ua_plaqueSprite(c,W,H,rk,!!empty));
 if(!empty&&(rk==='l'||rk==='m')){ua_plqSheen(g,W,H,t,rk);
  if(rk==='l'){const a=Math.max(0,Math.sin(t*2.4));if(a>.05)fkSpark(g,0,-H*.51,4+a*6,'#fff6c8',a);const b=Math.max(0,Math.sin(t*2.4+2.4));if(b>.05)fkSpark(g,W*.19,-H*.455,2+b*4,'#ffffff',b)}
  else{const GM=[[0,-H*.5],[-W*.44,-H*.44],[W*.44,-H*.44],[-W*.47,H*.16],[W*.47,H*.16],[-W*.22,H*.44],[W*.22,H*.44]],C=['#ff5ad8','#5af0ff','#ffd45a','#6ef08a','#a87aff'];
   for(let i=0;i<GM.length;i++){const a=.5+.5*Math.sin(t*2.6+i*1.1);ua_glow(g,GM[i][0],GM[i][1],9+a*5,C[(i+Math.floor(t*.7))%5],.18+.3*a);if(a>.8)fkSpark(g,GM[i][0]+2,GM[i][1]-2,(a-.8)*30,'#ffffff',(a-.8)*5)}}}
 g.restore()}

/* ====================================================================================================================
   MEDALS
   ==================================================================================================================== */
const UA_MD={catch:['bronze','#1f8fb0','#2a7ad8','#ffd45a'],species:['silver','#2a9a5a','#2a9a5a','#f4ecd8'],rare:['silver','#1e3a8a','#3a8aff','#c8e4ff'],legend:['gold','#a8203a','#ffc23a','#a8203a'],
 myth:['prism','#4a1a7a','#ff5ad8','#7ae8ff'],giant:['silver','#1a6a8a','#3ac8a0','#f4ecd8'],streak:['bronze','#8a1a1a','#ff6a2a','#ffd45a'],spots:['bronze','#2a7a5a','#e8364e','#f4ecd8'],
 bounty:['gold','#6a3a1a','#c8282a','#ffd45a'],creel:['bronze','#2a1f5c','#c8904a','#5a4ca0'],trophy:['gold','#22306a','#5a4ca0','#ffc23a'],bait:['bronze','#3a6a2a','#7aff9a','#5a3a1a'],
 gold:['gold','#4a2a7a','#ffd45a','#2a1f5c'],speed:['silver','#1a3a9a','#ffe04a','#2a5ad8']};
const UA_FLAT='#4a4288',UA_FLAT2='#383068';
/* emblems drawn around (0,0), radius ~14; P(col) returns the colour (or the flat silhouette tone when not earned) */
function ua_fishShape(c,x,y,s,rot){c.save();c.translate(x,y);c.rotate(rot||0);c.scale(s,s);c.beginPath();c.moveTo(-6,0);c.bezierCurveTo(-2,-8,8,-9,13,-1);c.quadraticCurveTo(14,0,13,1);c.bezierCurveTo(8,9,-2,8,-6,0);c.lineTo(-13,-6);c.quadraticCurveTo(-10,0,-13,6);c.closePath();c.restore()}
const UA_EMB={
 catch(c,P,L){ua_fishShape(c,0,0,1.05,-.15);c.fillStyle=P(()=>fkLin(c,0,-9,0,9,['#ffd08a','#ff8a3a','#c8401a']));c.fill();c.lineWidth=L;c.strokeStyle=UA_O;c.stroke();if(P.got){ua_dot(c,8,-3,2.2,'#fff',1);ua_dot(c,8.4,-3,1,UA_O,0);c.strokeStyle='rgba(255,255,255,.6)';c.lineWidth=1.2;c.beginPath();c.arc(1,-1,6,Math.PI*1.1,Math.PI*1.6);c.stroke()}},
 species(c,P,L){c.beginPath();c.moveTo(0,-7);c.quadraticCurveTo(-7,-11,-14,-8);c.lineTo(-14,9);c.quadraticCurveTo(-7,6,0,10);c.quadraticCurveTo(7,6,14,9);c.lineTo(14,-8);c.quadraticCurveTo(7,-11,0,-7);c.closePath();c.fillStyle=P('#fff6e0');c.fill();c.lineWidth=L;c.strokeStyle=UA_O;c.stroke();
  c.beginPath();c.moveTo(0,-7);c.lineTo(0,10);c.stroke();if(P.got){c.strokeStyle='#b89a6a';c.lineWidth=1;c.beginPath();for(let i=0;i<3;i++){c.moveTo(-11,-3+i*4);c.lineTo(-3,-2+i*4);c.moveTo(3,-2+i*4);c.lineTo(11,-3+i*4)}c.stroke();
   c.fillStyle='#e8364e';c.beginPath();c.moveTo(7,-9);c.lineTo(11,-9);c.lineTo(11,1);c.lineTo(9,-1);c.lineTo(7,1);c.closePath();c.fill();c.lineWidth=1.2;c.strokeStyle=UA_O;c.stroke()}},
 rare(c,P,L){if(P.got)ua_gem(c,0,0,12,['#d8f0ff','#3a8aff','#1a2a8a'],L);else{c.beginPath();c.moveTo(-12,-3);c.lineTo(-6.6,-9.6);c.lineTo(6.6,-9.6);c.lineTo(12,-3);c.lineTo(0,12);c.closePath();c.fillStyle=UA_FLAT;c.fill();c.lineWidth=L;c.strokeStyle=UA_O;c.stroke()}},
 legend(c,P,L){c.beginPath();c.moveTo(-13,7);c.lineTo(-14,-7);c.lineTo(-7,-1);c.lineTo(0,-11);c.lineTo(7,-1);c.lineTo(14,-7);c.lineTo(13,7);c.closePath();c.fillStyle=P(()=>ua_met(c,-14,-11,14,9,'gold'));c.fill();c.lineWidth=L;c.strokeStyle=UA_O;c.stroke();
  c.beginPath();c.roundRect(-13.5,6,27,5,1.5);c.fill();c.stroke();for(const [x,y] of [[-14,-7],[0,-11],[14,-7]])ua_dot(c,x,y,2.3,P('#fff6c8'),1.4);if(P.got){ua_gem(c,0,2,3.4,['#ffd0d8','#ff3a5a','#8a0a2a'],1.2);ua_dot(c,-7,8.5,1.3,'#3a8aff',0);ua_dot(c,7,8.5,1.3,'#3a8aff',0)}},
 myth(c,P,L){c.beginPath();for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,r=i%2?5.6:14;c.lineTo(Math.cos(a)*r,Math.sin(a)*r)}c.closePath();c.fillStyle=P(()=>fkLin(c,-14,-14,14,14,['#fff0ff','#ff7ae0','#c86aff','#7ae8ff']));c.fill();c.lineWidth=L;c.strokeStyle=UA_O;c.stroke();
  if(P.got){c.strokeStyle='rgba(255,255,255,.7)';c.lineWidth=1;c.beginPath();for(let i=0;i<5;i++){const a=-Math.PI/2+i*Math.PI*2/5;c.moveTo(0,0);c.lineTo(Math.cos(a)*12,Math.sin(a)*12)}c.stroke();ua_dot(c,0,0,2.4,'#ffffff',0)}},
 giant(c,P,L){ua_fishShape(c,-2,-2,.85,0);c.fillStyle=P(()=>fkLin(c,0,-9,0,6,['#bff0ff','#5ab8e8','#2a6ab8']));c.fill();c.lineWidth=L;c.strokeStyle=UA_O;c.stroke();if(P.got)ua_dot(c,5,-4.5,1.6,'#fff',1);
  c.beginPath();c.roundRect(-14,8,28,6,1.5);c.fillStyle=P('#ffd45a');c.fill();c.lineWidth=L*.8;c.stroke();c.strokeStyle=P.got?'#7a4a0a':UA_O;c.lineWidth=1;c.beginPath();for(let i=-12;i<=12;i+=4){c.moveTo(i,8);c.lineTo(i,i%8?10.5:12)}c.stroke();
  c.beginPath();c.moveTo(12,4);c.lineTo(12,-10);c.moveTo(8,-6);c.lineTo(12,-11);c.lineTo(16,-6);c.strokeStyle=UA_O;c.lineWidth=4.6;c.stroke();c.strokeStyle=P('#7affb4');c.lineWidth=2.2;c.stroke()},
 streak(c,P,L){c.beginPath();c.moveTo(0,13);c.bezierCurveTo(-12,12,-13,0,-6,-6);c.quadraticCurveTo(-5,-1,-2,0);c.quadraticCurveTo(-4,-9,4,-14);c.quadraticCurveTo(2,-6,8,-2);c.quadraticCurveTo(13,4,9,10);c.quadraticCurveTo(6,13,0,13);c.closePath();
  c.fillStyle=P(()=>fkLin(c,0,-14,0,13,['#ffe04a','#ff8a2a','#e8362a']));c.fill();c.lineWidth=L;c.strokeStyle=UA_O;c.stroke();if(P.got){c.beginPath();c.moveTo(0,11);c.bezierCurveTo(-6,10,-6,3,-2,0);c.quadraticCurveTo(1,4,3,1);c.quadraticCurveTo(7,7,0,11);c.fillStyle='#fff6b0';c.fill()}},
 spots(c,P,L){if(P.got){c.beginPath();c.ellipse(0,12,7,2.4,0,0,TAU);c.fillStyle='rgba(0,0,0,.35)';c.fill()}c.beginPath();c.moveTo(0,12);c.bezierCurveTo(-4,5,-10,0,-10,-4);c.arc(0,-4,10,Math.PI,0);c.bezierCurveTo(10,0,4,5,0,12);c.closePath();c.fillStyle=P(()=>fkLin(c,-10,-14,10,10,['#ff8a9a','#e8364e','#a01a2e']));c.fill();c.lineWidth=L;c.strokeStyle=UA_O;c.stroke();
  ua_dot(c,0,-4,3.8,P('#fff6e0'),1.6);if(P.got){c.strokeStyle='rgba(255,255,255,.6)';c.lineWidth=1.3;c.beginPath();c.arc(0,-4,7.5,Math.PI*1.1,Math.PI*1.5);c.stroke()}},
 bounty(c,P,L){c.beginPath();c.moveTo(-10,-10);c.lineTo(10,-10);c.lineTo(10,9);c.lineTo(-10,9);c.closePath();c.fillStyle=P('#f4e2b8');c.fill();c.lineWidth=L;c.strokeStyle=UA_O;c.stroke();
  for(const yy of [-11,10]){c.beginPath();c.roundRect(-13,yy-3,26,6,3);c.fillStyle=P('#d8bc84');c.fill();c.stroke()}if(P.got){c.strokeStyle='#a88a5a';c.lineWidth=1;c.beginPath();for(let i=0;i<3;i++){c.moveTo(-7,-4+i*4);c.lineTo(i===2?0:7,-4+i*4)}c.stroke()}
  c.beginPath();for(let i=0;i<12;i++){const a=i/12*TAU,r=i%2?4.6:5.6;c.lineTo(7+Math.cos(a)*r,6+Math.sin(a)*r)}c.closePath();c.fillStyle=P('#c8282a');c.fill();c.lineWidth=L*.8;c.stroke();if(P.got)ua_dot(c,7,6,2.2,'#e8545a',0)},
 creel(c,P,L){c.beginPath();c.arc(0,-3,9,Math.PI*1.05,Math.PI*1.95);c.strokeStyle=UA_O;c.lineWidth=4.8;c.stroke();c.strokeStyle=P('#8a5a28');c.lineWidth=2.2;c.stroke();
  c.beginPath();c.moveTo(-13,-3);c.lineTo(13,-3);c.lineTo(10,12);c.quadraticCurveTo(0,14,-10,12);c.closePath();c.fillStyle=P(()=>fkLin(c,0,-3,0,13,['#e8b878','#a06a30']));c.fill();c.lineWidth=L;c.strokeStyle=UA_O;c.stroke();
  if(P.got){c.strokeStyle='rgba(90,50,20,.7)';c.lineWidth=1.1;c.beginPath();for(let i=0;i<3;i++){c.moveTo(-12,1.5+i*3.6);c.quadraticCurveTo(0,3+i*3.6,12,1.5+i*3.6)}for(let i=-2;i<=2;i++){c.moveTo(i*4.5,-3);c.lineTo(i*3.8,13)}c.stroke()}
  c.beginPath();c.roundRect(-14,-6,28,4.5,2);c.fillStyle=P('#c8904a');c.fill();c.lineWidth=L*.8;c.strokeStyle=UA_O;c.stroke()},
 trophy(c,P,L){c.beginPath();c.moveTo(-12,-10);c.lineTo(12,-10);c.lineTo(12,1);c.quadraticCurveTo(10,10,0,14);c.quadraticCurveTo(-10,10,-12,1);c.closePath();c.fillStyle=P(()=>ua_met(c,-12,-10,12,14,'gold'));c.fill();c.lineWidth=L;c.strokeStyle=UA_O;c.stroke();
  c.beginPath();c.moveTo(-8.5,-7);c.lineTo(8.5,-7);c.lineTo(8.5,1);c.quadraticCurveTo(7,7.5,0,10.5);c.quadraticCurveTo(-7,7.5,-8.5,1);c.closePath();c.fillStyle=P(()=>fkLin(c,0,-7,0,10,['#8a4c26','#4a2412']));c.fill();c.lineWidth=1.2;c.stroke();
  ua_fishShape(c,0,-.5,.5,0);c.fillStyle=P('#7ad8ff');c.fill();c.lineWidth=1;c.strokeStyle=UA_O;c.stroke()},
 bait(c,P,L){c.save();c.translate(-2,0);c.beginPath();c.moveTo(0,-13);c.lineTo(0,5);c.arc(5,5,5,Math.PI,0,true);c.lineTo(10,0);c.strokeStyle=UA_O;c.lineWidth=5;c.stroke();c.strokeStyle=P('#d8e0f4');c.lineWidth=2.4;c.stroke();
  c.beginPath();c.arc(0,-14,2.4,0,TAU);c.strokeStyle=UA_O;c.lineWidth=4.2;c.stroke();c.strokeStyle=P('#d8e0f4');c.lineWidth=1.8;c.stroke();
  c.beginPath();c.moveTo(-6,-6);c.bezierCurveTo(6,-8,6,-2,-5,0);c.bezierCurveTo(-12,2,-6,8,2,6);c.strokeStyle=UA_O;c.lineWidth=6.4;c.stroke();c.strokeStyle=P('#ff9ab0');c.lineWidth=3.6;c.stroke();if(P.got){c.strokeStyle='rgba(255,255,255,.55)';c.lineWidth=1;c.stroke()}c.restore()},
 gold(c,P,L){for(let i=0;i<3;i++){const y=9-i*5;c.beginPath();c.ellipse(-3,y+2,9,3.6,0,0,TAU);c.fillStyle=P('#b8741a');c.fill();c.lineWidth=L*.8;c.strokeStyle=UA_O;c.stroke();c.beginPath();c.ellipse(-3,y,9,3.6,0,0,TAU);c.fillStyle=P(()=>fkLin(c,-12,y-4,6,y+4,['#fff6c8','#ffd45a','#d8901e']));c.fill();c.stroke()}
  c.beginPath();c.ellipse(8,2,5.5,8.5,.15,0,TAU);c.fillStyle=P(()=>fkLin(c,3,-6,13,10,['#fff6c8','#ffd45a','#c8841a']));c.fill();c.lineWidth=L*.8;c.stroke();if(P.got){c.beginPath();c.ellipse(8,2,3.2,5.6,.15,0,TAU);c.strokeStyle='#b8741a';c.lineWidth=1;c.stroke()}},
 speed(c,P,L){c.beginPath();c.moveTo(3,-14);c.lineTo(-9,2);c.lineTo(-1,2);c.lineTo(-4,14);c.lineTo(9,-3);c.lineTo(1,-3);c.closePath();c.fillStyle=P(()=>fkLin(c,0,-14,0,14,['#fffbd0','#ffe04a','#f0a018']));c.fill();c.lineWidth=L;c.strokeStyle=UA_O;c.stroke();
  if(P.got){c.strokeStyle='rgba(255,255,255,.75)';c.lineWidth=1.1;c.beginPath();c.moveTo(1.5,-10);c.lineTo(-5.5,0);c.stroke()}}};
function ua_medalSprite(c,kind,got){const D=UA_MD[kind]||UA_MD.catch,M=got?(UA_MET[D[0]]||UA_MET.gold):['#5a5294','#3e3672','#2a2452','#1c1838'],R=27,cy=7;
 /* ribbon */const rb=()=>{c.beginPath();c.moveTo(-15,-42);c.lineTo(15,-42);c.lineTo(10,-12);c.lineTo(-10,-12);c.closePath()};
 rb();c.fillStyle=got?D[2]:'#2a2452';c.fill();c.save();rb();c.clip();c.fillStyle=got?D[3]:'#221c44';c.fillRect(-4.5,-44,9,34);c.fillStyle=got?'rgba(255,255,255,.18)':'rgba(255,255,255,.04)';c.fillRect(-15,-44,4,34);
  c.fillStyle='rgba(0,0,0,.25)';c.fillRect(8,-44,8,34);c.fillStyle=fkLin(c,0,-24,0,-12,['rgba(0,0,0,0)','rgba(0,0,0,.35)']);c.fillRect(-16,-24,32,12);c.restore();rb();c.lineWidth=3;c.strokeStyle=UA_O;c.stroke();
 c.beginPath();c.arc(0,-17,4,0,TAU);c.strokeStyle=UA_O;c.lineWidth=5.4;c.stroke();c.strokeStyle=M[1];c.lineWidth=2.4;c.stroke();
 if(got&&D[0]==='prism')ua_glow(c,0,cy,40,'#ff5ad8',.25);
 /* medal rim with beads, enamel, inner ring */
 c.beginPath();c.arc(0,cy,R,0,TAU);c.fillStyle=fkLin(c,-R,cy-R,R,cy+R,[M[0],M[1],M[2],M[3]]);c.fill();c.lineWidth=3.4;c.strokeStyle=UA_O;c.stroke();
 for(let i=0;i<24;i++){const a=i/24*TAU;ua_dot(c,Math.cos(a)*(R-3.4),cy+Math.sin(a)*(R-3.4),1.25,got?M[0]:'#6a62a4',0)}
 c.beginPath();c.arc(0,cy,R-6.5,0,TAU);c.fillStyle=got?fkRad(c,0,cy,R-6.5,[ua_mix(D[1],.35),D[1],ua_mix(D[1],-.45)]):fkRad(c,0,cy,R-6.5,['#221c44','#17122e','#100c22']);c.fill();c.lineWidth=2.4;c.strokeStyle=UA_O;c.stroke();
 c.beginPath();c.arc(0,cy,R-8.4,0,TAU);c.strokeStyle=got?ua_mix(D[1],.3):'#2a2452';c.lineWidth=1;c.stroke();
 if(got){c.save();c.beginPath();c.arc(0,cy,R-6.5,0,TAU);c.clip();c.fillStyle='rgba(255,255,255,.14)';c.beginPath();c.ellipse(-6,cy-12,16,8,-.4,0,TAU);c.fill();c.restore()}
 /* emblem */const P=got?(x=>typeof x==='function'?x():x):(()=>UA_FLAT);P.got=got;c.save();c.translate(0,cy);c.lineJoin='round';c.lineCap='round';(UA_EMB[kind]||UA_EMB.catch)(c,P,2.2);c.restore();
 if(got){c.strokeStyle='rgba(255,255,255,.65)';c.lineWidth=1.6;c.beginPath();c.arc(0,cy,R-1.6,Math.PI*1.1,Math.PI*1.45);c.stroke()}
 else{/* lock */c.save();c.translate(17,cy+19);c.beginPath();c.arc(0,-4,4.6,Math.PI,0);c.strokeStyle=UA_O;c.lineWidth=5;c.stroke();c.strokeStyle='#9a92c8';c.lineWidth=2.4;c.stroke();
  c.beginPath();c.roundRect(-7,-4,14,11,2.5);c.fillStyle=fkLin(c,0,-4,0,7,['#a8a0d8','#6a62a4']);c.fill();c.lineWidth=2.2;c.strokeStyle=UA_O;c.stroke();ua_dot(c,0,0.5,1.7,UA_O,0);c.fillStyle=UA_O;c.fillRect(-.7,1,1.4,3.4);c.restore()}}
function fsMedal(g,kind,x,y,s,t,got){t=t||0;s=s||1;got=!!got;g.save();g.translate(x,y);g.scale(s,s);
 const D=UA_MD[kind]||UA_MD.catch;if(got&&kind==='myth')ua_glow(g,0,7,44,'#ff5ad8',.12+.08*Math.sin(t*2.2));
 ua_spr(g,'md'+kind+(got?1:0),-44,-46,88,88,c=>ua_medalSprite(c,kind,got));
 if(got){const u=((t*.28)+(kind.length*.13))%1;if(u<.3){g.save();g.beginPath();g.arc(0,7,27,0,TAU);g.clip();g.translate(-40+u/.3*80,7);g.rotate(.5);g.globalCompositeOperation='lighter';
   g.fillStyle=ua_gc('mdsh',()=>fkLin(g,-9,0,9,0,['rgba(255,255,240,0)','rgba(255,255,240,.45)','rgba(255,255,240,0)']));g.fillRect(-9,-40,18,80);g.restore()}
  const a=Math.max(0,Math.sin(t*2.3+kind.length));if(a>.1)fkSpark(g,19,-12,2+a*4,'#ffffff',a)}
 g.restore()}

/* ====================================================================================================================
   HUB ICONS (wraps fsIcon from 90m)
   ==================================================================================================================== */
function ua_cup(c,x,y,s){c.save();c.translate(x,y);c.scale(s,s);for(const sd of [-1,1]){c.beginPath();c.arc(sd*11,-8,5.5,sd>0?-Math.PI/2:Math.PI/2,sd>0?Math.PI/2:Math.PI*1.5,false);c.strokeStyle=UA_O;c.lineWidth=5.4;c.stroke();c.strokeStyle='#ffd45a';c.lineWidth=2.6;c.stroke()}
 c.beginPath();c.moveTo(-12,-16);c.lineTo(12,-16);c.quadraticCurveTo(12,2,2,5);c.lineTo(2,10);c.lineTo(-2,10);c.lineTo(-2,5);c.quadraticCurveTo(-12,2,-12,-16);c.closePath();c.fillStyle=ua_met(c,-12,-16,12,10,'gold');c.fill();c.lineWidth=2.6;c.strokeStyle=UA_O;c.stroke();
 c.beginPath();c.roundRect(-9,9,18,6,2);c.fillStyle=fkLin(c,0,9,0,15,['#8a4c26','#4a2412']);c.fill();c.stroke();c.beginPath();c.ellipse(0,-16,12,2.8,0,0,TAU);c.fillStyle='#fff2b0';c.fill();c.lineWidth=2;c.stroke();
 c.strokeStyle='rgba(255,255,255,.75)';c.lineWidth=1.4;c.beginPath();c.moveTo(-7,-12);c.quadraticCurveTo(-7,-4,-3,0);c.stroke();c.restore()}
function ua_note(c,x,y,w,h,rot,pin,draw){c.save();c.translate(x,y);c.rotate(rot);c.fillStyle='rgba(10,4,20,.35)';c.fillRect(-w/2+2,-h/2+3,w,h);
 c.beginPath();c.moveTo(-w/2,-h/2);c.lineTo(w/2,-h/2);c.lineTo(w/2,h/2-4);c.lineTo(w/2-5,h/2);c.lineTo(-w/2,h/2);c.closePath();c.fillStyle=fkLin(c,0,-h/2,0,h/2,['#fff6dc','#ead2a0']);c.fill();c.lineWidth=2;c.strokeStyle=UA_O;c.stroke();
 if(draw)draw(c,w,h);ua_dot(c,0,-h/2+3,3,pin,1.4);ua_dot(c,-.8,-h/2+2.2,1,'rgba(255,255,255,.8)',0);c.restore()}
function ua_iconSprite(c,kind){
 if(kind==='trophy'){c.save();c.translate(-4,-4);ua_plaqueSprite(c,78,62,'l',false);fishFit(c,'moonfin',0,-4,62,34,{t:1.1});c.restore();ua_cup(c,28,22,.95)}
 if(kind==='board'){/* posts and roof */c.fillStyle=fkLin(c,0,-30,0,40,['#6a3a1c','#3a1a0a']);for(const sx of [-38,32]){c.beginPath();c.roundRect(sx,-24,6,64,2);c.fill();c.lineWidth=2.4;c.strokeStyle=UA_O;c.stroke()}
  c.beginPath();c.roundRect(-36,-22,72,50,4);c.fillStyle=fkLin(c,0,-22,0,28,['#a86a3a','#7a4622']);c.fill();c.lineWidth=3;c.strokeStyle=UA_O;c.stroke();
  c.save();c.beginPath();c.roundRect(-36,-22,72,50,4);c.clip();c.strokeStyle='rgba(40,16,4,.5)';c.lineWidth=1.4;for(let i=1;i<4;i++){c.beginPath();c.moveTo(-36,-22+i*12.5);c.lineTo(36,-22+i*12.5);c.stroke()}c.restore();
  c.beginPath();c.roundRect(-36,-22,72,50,4);c.strokeStyle='#5a2e14';c.lineWidth=1;c.stroke();
  c.beginPath();c.moveTo(-44,-20);c.lineTo(0,-38);c.lineTo(44,-20);c.lineTo(38,-16);c.lineTo(0,-31);c.lineTo(-38,-16);c.closePath();c.fillStyle=fkLin(c,0,-38,0,-16,['#c85a3a','#8a2a1a']);c.fill();c.lineWidth=2.8;c.strokeStyle=UA_O;c.stroke();
  c.strokeStyle='rgba(255,200,170,.5)';c.lineWidth=1.2;c.beginPath();c.moveTo(-36,-20);c.lineTo(0,-35);c.stroke();ua_rivet(c,0,-33,2.2,'brass');
  ua_note(c,-19,-3,22,28,-.12,'#e8364e',(c,w,h)=>{ua_fishShape(c,0,1,.62,0);c.fillStyle='#5ab8ff';c.fill();c.lineWidth=1.1;c.strokeStyle=UA_O;c.stroke();c.strokeStyle='#a88a5a';c.lineWidth=1;c.beginPath();c.moveTo(-7,9);c.lineTo(7,9);c.stroke()});
  ua_note(c,5,2,22,32,.07,'#ffd45a',(c,w,h)=>{c.strokeStyle='#8a2a1a';c.lineWidth=2;c.beginPath();c.moveTo(-6,-8);c.lineTo(6,-8);c.stroke();c.strokeStyle='#a88a5a';c.lineWidth=1;c.beginPath();for(let i=0;i<3;i++){c.moveTo(-7,-2+i*4);c.lineTo(7,-2+i*4)}c.stroke();
   c.beginPath();for(let i=0;i<12;i++){const a=i/12*TAU,r=i%2?4.4:5.4;c.lineTo(4+Math.cos(a)*r,11+Math.sin(a)*r)}c.closePath();c.fillStyle='#c8282a';c.fill();c.lineWidth=1.4;c.strokeStyle=UA_O;c.stroke();ua_dot(c,4,11,2,'#e8545a',0)})}
 if(kind==='bait'){/* lid leaning behind */c.save();c.translate(-14,-12);c.rotate(-.35);c.beginPath();c.ellipse(0,0,22,9,0,0,TAU);c.fillStyle=ua_met(c,-22,-9,22,9,'steel');c.fill();c.lineWidth=2.8;c.strokeStyle=UA_O;c.stroke();
   c.beginPath();c.ellipse(0,0,15,5.5,0,0,TAU);c.strokeStyle='rgba(40,60,100,.5)';c.lineWidth=1.4;c.stroke();c.restore();
  c.fillStyle='rgba(8,4,20,.4)';c.beginPath();c.ellipse(2,32,32,5,0,0,TAU);c.fill();
  const bp=()=>{c.beginPath();c.moveTo(-28,-2);c.lineTo(-28,24);c.ellipse(2,24,30,8,0,Math.PI,0,true);c.lineTo(32,-2);c.closePath()};
  bp();c.fillStyle=fkLin(c,-28,0,32,0,['#6a7aa0','#d4e4f6','#9aaccc','#4a5a80']);c.fill();c.lineWidth=3;c.strokeStyle=UA_O;c.stroke();
  c.save();bp();c.clip();c.beginPath();c.moveTo(-30,6);c.ellipse(2,6,31,8,0,Math.PI,0,true);c.lineTo(34,18);c.ellipse(2,18,31,8,0,0,Math.PI,false);c.closePath();c.fillStyle=fkLin(c,-28,0,32,0,['#8a1a1a','#e8364e','#a8202a']);c.fill();
   c.strokeStyle=UA_O;c.lineWidth=1.6;c.beginPath();c.ellipse(2,6,31,8,0,0,Math.PI);c.stroke();c.beginPath();c.ellipse(2,18,31,8,0,0,Math.PI);c.stroke();
   c.beginPath();c.moveTo(-8,14);c.bezierCurveTo(-2,8,4,20,12,12);c.strokeStyle='#ffd45a';c.lineWidth=2.4;c.stroke();c.restore();
  c.beginPath();c.ellipse(2,-2,30,8,0,0,TAU);c.fillStyle=fkLin(c,0,-10,0,6,['#c8d8ec','#7a8eb0']);c.fill();c.lineWidth=3;c.strokeStyle=UA_O;c.stroke();
  c.beginPath();c.ellipse(2,-1,26,6,0,0,TAU);c.fillStyle=fkLin(c,0,-7,0,5,['#3a2010','#5a3820']);c.fill();c.lineWidth=1.6;c.stroke();
  c.fillStyle='rgba(255,220,170,.2)';for(let i=0;i<10;i++){c.beginPath();c.arc(-18+i*4.2,-1+((i*5)%4)-1,.8,0,TAU);c.fill()}}}
{const o=fsIcon;fsIcon=function(g,kind,x,y,s,t){t=t||0;
 if(typeof kind==='string'&&/^creel[0-4]$/.test(kind)){g.save();g.translate(x,y);g.scale(s,s);fsCreelArt(g,+kind[5],0,2,.4,t,.6);g.restore();return}
 if(kind==='trophy'||kind==='board'||kind==='bait'){g.save();g.translate(x,y);g.scale(s,s);g.lineJoin='round';g.lineCap='round';
  if(kind==='trophy')ua_glow(g,0,-4,46,'#ffd45a',.14);if(kind==='bait')ua_glow(g,2,-4,40,'#5aff8a',.12+.05*Math.sin(t*2));
  ua_spr(g,'ic'+kind,-48,-44,96,88,c=>ua_iconSprite(c,kind));
  if(kind==='trophy'){ua_plqSheen(g,78,62,t,'l');g.save();g.translate(-4,-4);const a=Math.max(0,Math.sin(t*2.4));if(a>.05)fkSpark(g,0,-32,3+a*4,'#fff6c8',a);g.restore();fkSpark(g,38,4,3+2*Math.abs(Math.sin(t*3)),'#fff6c0',.9)}
  if(kind==='board'){const r=Math.sin(t*2.2)*.06;ua_note(g,25,-6,18,22,.16+r,'#5ab8ff',(c)=>{c.strokeStyle='#a88a5a';c.lineWidth=1;c.beginPath();for(let i=0;i<3;i++){c.moveTo(-5,-3+i*4);c.lineTo(5,-3+i*4)}c.stroke();ua_dot(c,0,-7.5,0,'#000',0)});
   const a=Math.max(0,Math.sin(t*2.6));if(a>.05)fkSpark(g,13,9,2+a*4,'#fff6c0',a)}
  if(kind==='bait'){const w1=Math.sin(t*2.4)*4,w2=Math.cos(t*1.9)*3;ua_worm(g,[0,0,-6+w2,-14,12+w1,-20,8+w1*1.3,-34+Math.sin(t*2.4+1)*2],4.4,1,1);ua_glow(g,8+w1*1.3,-34,14,'#5aff8a',.4+.15*Math.sin(t*3));
   ua_worm(g,[-14,1,-18,-6,-10,-10,-8,-16],3.2,.9,1);fkSpark(g,28,-22,3+2*Math.abs(Math.sin(t*3)),'#e8fff0',.9)}
  g.restore();return}
 return o.apply(this,arguments)}}
