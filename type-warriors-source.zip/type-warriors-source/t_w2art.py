# python3 t_w2art.py [game.html] [--shots DIR] : World 2 art (98f, 98f2) - Coral Shallows, Shipwreck Cove, Kraken's Maw.
# The bakes (size, castle box, the road on the rpGeo samples, no water on the road, props clear of the pads), the live layers on a full
# battle (frame cost, lite and reduced motion), the twist visuals with the state set by hand (tide, fog, cannon, whirlpools, glowcaps),
# the castle flinch, the map pictures and the World 2 painting. With --shots it also saves the screenshots.
import asyncio,os,sys,base64
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
A=[a for a in sys.argv[1:] if not a.startswith('--')]
SHOTS=sys.argv[sys.argv.index('--shots')+1] if '--shots' in sys.argv else None
if SHOTS and SHOTS in A:A.remove(SHOTS)
H='file://'+os.path.abspath(A[0] if A else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:500]),flush=True)
    if not ok:FAIL.append(name)
MAPS=['coral','wreck','abyss']
HELP=r"""()=>{
 window.w2New=(m)=>{try{rpLeave()}catch(e){}rpStart(m);const R=RPX;R.tut=null;R.hold=false;R.supply=1e9;R.banner=null;const el=document.getElementById('rptut');if(el)el.style.display='none';return R};
 window.w2Full=(R)=>{const T=RP_TWORDER;R.pads.forEach((p,i)=>{if(i%5===4)return;rpBuild(p,T[i%T.length]);if(p.tw){p.tw.build=1;for(let k=0;k<i%3;k++)try{rpUpgrade(p.tw)}catch(e){}p.tw.upK=1}});
  const ids=['scamp','bulwark','golem','gloom','ooze','shaman'];for(let i=0;i<30;i++){const e=rpSpawn(ids[i%ids.length],i%R.G.paths.length);if(e)e.s=60+i*(R.G.paths[e.pi||0].len-200)/30}for(let i=0;i<20;i++)rpStep(R,1/30);R.pause=true};
 window.w2Cv=()=>{const c=document.createElement('canvas');c.width=1600;c.height=900;return c};
 window.w2Layers=(R,c)=>{const m=R.map.id;for(const f of[RPW.amb[m],RPW.twist[m],RPW.ambTop[m]])if(f){c.save();f(c,R);c.restore()}};
 window.w2Diff=(a,b,x0,y0,w,h)=>{const A=a.getContext('2d').getImageData(x0,y0,w,h).data,B=b.getContext('2d').getImageData(x0,y0,w,h).data;let s=0,n=0;for(let i=0;i<A.length;i+=4){const d=Math.abs(A[i]-B[i])+Math.abs(A[i+1]-B[i+1])+Math.abs(A[i+2]-B[i+2]);if(d>24)n++;s+=d}return [n/(A.length/4),s/(A.length/4)]};
 window.w2Lum=(c,x0,y0,w,h)=>{const d=c.getContext('2d').getImageData(x0,y0,w,h).data;let s=0;for(let i=0;i<d.length;i+=4)s+=d[i]*.3+d[i+1]*.59+d[i+2]*.11;return s/(d.length/4)};
 window.w2Shot=(R)=>{const c=w2Cv(),g=c.getContext('2d');g.drawImage(R.bake.c,0,0);w2Layers(R,g);return c};
 return 1}"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]));pg.on('console',lambda m:er.append(m.text[:300]) if m.type=='error' and 'WebSocket' not in m.text and 'relay' not in m.text else None)
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E("()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const r=RPP();r.new99j=1;r.dragon=1;r.stars=Object.assign(r.stars||{},{moss:3,frost:3,ember:3});for(const k in r.tut)r.tut[k]=1;for(const k in RP_TUT)r.tut[k]=1;for(const m of RP_MAPS)r.tut['twist_'+m.id]=1}")
        await E(HELP)
        r=await E("()=>['coral','wreck','abyss'].map(m=>[!!RPW.bake[m],!!RPW.amb[m],!!RPW.castleHit[m],!!RPW.icon[m]]).concat([[!!RPW.twist.coral,!!RPW.ambTop.wreck,!!RPW.twist.abyss,!!RPW.world[2]]])")
        chk('the art registries are filled for the three maps: bake, live layer, castle flinch, map picture; tide, fog and cannon, whirlpools and glowcaps; the World 2 painting',all(all(x) for x in r),r)
        # ---- the bakes
        for m in MAPS:
            r=await E("""(m)=>{const map=RP_MAP(m);delete RPBAKE[m];const t0=performance.now();const B=rpBake(map);const ms=performance.now()-t0;const G=rpGeo(map);
              return [B.c.width,B.c.height,B.id,B.G===G,B.cast.w,B.cast.h,Math.round(B.cast.x+RPW2A_GX)===Math.round(G.gate.x),Math.round(ms),rpBake(map)===B,Array.isArray(B.trees)]}""",m)
            chk(f'{m}: baked once into a 1600 x 900 canvas with rpGeo, the castle box on the road end and the props list (bake {r[7]} ms)',r[:7]==[1600,900,m,True,300,520,True] and r[8] and r[9],r)
            r=await E("""(m)=>{const B=rpBake(RP_MAP(m)),G=B.G,g=B.c.getContext('2d');let n=0,ok=0,wet=0;const C={coral:[244,220,166],wreck:[138,100,64],abyss:[66,96,140]}[m];
              for(const P of G.paths)for(let i=20;i<P.S.length-20;i+=6){if(!P.own[i])continue;const q=P.S[i];n++;if(m!=='abyss'&&B.F.at(q.x,q.y)>0)wet++;
               const d=g.getImageData(q.x|0,q.y|0,1,1).data;if(Math.abs(d[0]-C[0])+Math.abs(d[1]-C[1])+Math.abs(d[2]-C[2])<150)ok++}return [n,ok/n,wet]}""",m)
            chk(f'{m}: the road is painted on the rpGeo samples (road colour under {round(r[1]*100)}% of the centre line) and no water reaches the road',r[1]>0.85 and r[2]==0,r)
            r=await E("""(m)=>{const B=rpBake(RP_MAP(m)),G=B.G,bad=[];const box={palm:[1.15,1.05],pine:[.7,1.05],dead:[.7,.9],bush:[60,44],pool:[70,34],kelp:[40,130],cap:[42,40],ribs:[90,60],head:[80,56],col:[30,100],colb:[30,70],arch:[90,120],skull:[90,70],shack:[80,80],camp:[60,40],lamp:[24,60],stack:[60,80],vent:[50,50],light:[100,220],castle:[50,50],chest:[36,30]};
              for(const it of B.trees.concat((B.kelp||[]).map(k=>({k:'kelp',x:k[0],y:k[1]})))){const b=box[it.k];if(!b)continue;const w=b[0]<3?b[0]*(it.h||60):b[0],h=b[1]<3?b[1]*(it.h||60):b[1];
               if(rpw2aPadHit(G,it.x-w/2+4,it.y-h+4,it.x+w/2-4,it.y-2))bad.push([it.k,Math.round(it.x),Math.round(it.y)])}
              const c=B.cast;for(const p of G.pads)if(p.x+40>c.x+30&&p.y>c.y+60)bad.push(['castle',p.x,p.y]);
              if(m==='wreck'){const s=RP_MAP(m).ship;for(const p of G.pads)if(Math.abs(p.x-s[0])<s[2]/2+30&&p.y+20>s[1]-s[3]/2&&p.y<s[1]+s[3]/2)bad.push(['ship',p.x,p.y])}
              if(m==='abyss')for(const p of G.pads)if(B.F.at(p.x,p.y)>-10)bad.push(['pit',p.x,p.y]);return [B.trees.length,bad]}""",m)
            chk(f'{m}: the {r[0]} props, the castle'+(', the wreck' if m=='wreck' else ', the trench' if m=='abyss' else '')+' stay clear of every pad and its tower',len(r[1])==0,r)
        r=await E("""()=>{const L=[];for(const m of['moss','frost','ember','coral','wreck','abyss']){const map=RP_MAP(m),k=RPBAKE[m];delete RPBAKE[m];const t0=performance.now();rpBake(map);L.push(Math.round(performance.now()-t0))}return L}""")
        chk(f'bake times (ms) Mossgate / Frostfang / Ember Crown / Coral / Wreck / Abyss: {r} - each World 2 bake within 4x of Frostfang',max(r[3:])<4*max(r[1],300),r)
        # ---- live layers on a full battle
        for m in MAPS:
            r=await E("""(m)=>{const R=w2New(m);w2Full(R);if(m==='coral')R.tide={k:.6,high:true};if(m==='wreck'){R.fog=[{x:420,y:330,rx:150,ry:90},{x:1060,y:420,rx:170,ry:100},{x:700,y:250,rx:130,ry:80}];R.cannon={t:0,x:800,y:585,fire:.2,tx:640,ty:360}}
              const c=w2Cv().getContext('2d');const one=()=>{R.t+=1/60;w2Layers(R,c)};const meas=()=>{for(let i=0;i<6;i++)one();const L=[];for(let k=0;k<16;k++){const t0=performance.now();for(let i=0;i<8;i++)one();L.push((performance.now()-t0)/8)}L.sort((a,b)=>a-b);return +L[0].toFixed(3)};
              const full=meas();R.lite=1;const lite=meas();R.lite=0;R.rm=1;const rm=meas();R.rm=0;return [full,lite,rm,R.foes.length,R.pads.filter(p=>p.tw).length]}""",m)
            chk(f'{m}: the live layers on a full battle ({r[4]} towers, {r[3]} monsters) cost {r[0]} ms a frame (lite {r[1]}, reduced motion {r[2]}) - under 1 ms',r[0]<1.0 and r[1]<=r[0]*1.3+.05 and r[2]<=r[0]*1.3+.05,r)
        r=await E("""()=>{const out=[];for(const m of['ember','wonder']){const R=w2New(m);w2Full(R);const c=w2Cv().getContext('2d');const one=()=>{R.t+=1/60;c.save();rpAmbient(c,R);c.restore()};for(let i=0;i<6;i++)one();const L=[];
          for(let k=0;k<9;k++){const t0=performance.now();for(let i=0;i<12;i++)one();L.push((performance.now()-t0)/12)}L.sort((a,b)=>a-b);out.push(+L[0].toFixed(3))}return out}""")
        print(f'     (for comparison, World 1 rpAmbient on a full battle: Ember Crown {r[0]} ms, Wonderland {r[1]} ms)')
        r=await E("""()=>{const out=[];for(const m of['coral','wreck','abyss']){const R=w2New(m);R.tide=undefined;R.fog=undefined;R.cannon=undefined;const c=w2Cv().getContext('2d');w2Layers(R,c);R.cannon={fire:null};R.tide={};w2Layers(R,c);out.push(m)}return out}""")
        chk('the layers draw without twist state, or with partial state, without errors',r==MAPS and not er,[r,er])
        # ---- twists with the state set by hand
        r=await E("""()=>{const R=w2New('coral');const T=R.map.tide;R.t=3;R.tide={k:0,high:false};const a=w2Shot(R);R.tide={k:1,high:true};const b=w2Shot(R);R.tide={k:.4,high:true};const c=w2Shot(R);
          const d=T.map(t=>w2Diff(a,b,t[0]-t[2]*.6|0,t[1]-t[2]*.35|0,t[2]*1.2|0,t[2]*.7|0)[0]),e=T.map(t=>w2Diff(a,c,t[0]-t[2]*1.1|0,t[1]-t[2]*.8|0,t[2]*2.2|0,t[2]*1.6|0)[0]),f=T.map(t=>w2Diff(a,b,t[0]-t[2]*1.1|0,t[1]-t[2]*.8|0,t[2]*2.2|0,t[2]*1.6|0)[0]);
          return [d.map(x=>+x.toFixed(2)),e.map((x,i)=>x<f[i])]}""")
        chk('coral: the rising tide floods every tide stretch at k = 1 and covers less at k = 0.4',all(x>0.6 for x in r[0]) and all(r[1]),r)
        r=await E("""()=>{const R=w2New('wreck');R.t=2;R.fog=[];R.cannon=null;const a=w2Shot(R);R.fog=[{x:420,y:330,rx:150,ry:90}];const b=w2Shot(R);
          const lin=w2Lum(b,360,300,120,60)-w2Lum(a,360,300,120,60),lout=w2Diff(a,b,900,600,100,60)[0];
          R.fog=[];R.cannon={t:0,x:800,y:585,fire:.04,tx:640,ty:360};const c=w2Shot(R);R.cannon={t:0,x:800,y:585,fire:.3,tx:640,ty:360};const d=w2Shot(R);R.cannon={t:0,x:800,y:585,fire:.6,tx:640,ty:360};const e=w2Shot(R);
          const A2=rpw2aCannonAim(R),mx=A2.x+Math.cos(A2.a)*32|0,my=A2.y-4+Math.sin(A2.a)*32|0;
          return [+lin.toFixed(1),+lout.toFixed(3),+(w2Lum(c,mx-20,my-20,40,40)-w2Lum(a,mx-20,my-20,40,40)).toFixed(1),+w2Diff(a,d,600,250,240,200)[0].toFixed(3),+w2Diff(a,e,600,320,80,80)[0].toFixed(3),A2.a<-1.5&&A2.a>-3]}""")
        chk('wreck: a fog bank whitens its area (and nothing far away); the cannon aims at its target, flashes, flies a ball and bursts on impact',r[0]>25 and r[1]<0.01 and r[2]>20 and r[3]>0.002 and r[4]>0.05 and r[5],r)
        r=await E("""()=>{const R=w2New('abyss');const W=R.map.whirl,Gl=R.map.glow;R.t=2;const a=w2Shot(R);R.t=2.25;const b=w2Shot(R);
          const d=W.map(w=>+w2Diff(a,b,w[0]-30,w[1]-16,60,32)[0].toFixed(2));const c=w2Cv(),g=c.getContext('2d');g.drawImage(R.bake.c,0,0);RPW.amb.abyss(g,R);
          const gl=Gl.map(p=>+(w2Lum(a,p[0]+60,p[1]+10,30,16)-w2Lum(c,p[0]+60,p[1]+10,30,16)).toFixed(1));return [d,gl]}""")
        chk('abyss: the whirlpools spin on the road and every glowcap lights a pool round it',all(x>0.2 for x in r[0]) and all(x>2 for x in r[1]),r)
        r=await E("""()=>{const R=w2New('abyss');R.t=3;const L=[];for(const t of[3,3.6,4.2]){R.t=t;L.push(w2Shot(R))}const [lx,ly,rx,ry]=R.map.lake;return [+w2Diff(L[0],L[1],lx-rx-60,ly-ry-60,rx*2+120,ry*2+120)[0].toFixed(3),+w2Diff(L[0],L[2],lx-40,ly-10,80,40)[0].toFixed(3)]}""")
        chk('abyss: the tentacles move round the maw and the Kraken\'s eye lives',r[0]>0.01,r)
        # ---- castle flinch, icons, world painting
        r=await E("""()=>{const out=[];for(const m of['coral','wreck','abyss']){const R=w2New(m),B=R.bake.cast,c=w2Cv(),g=c.getContext('2d');g.drawImage(R.bake.c,0,0);const a=w2Cv();a.getContext('2d').drawImage(c,0,0);
           RPW.castleHit[m](g,B.x,B.y,.3);const d=w2Diff(a,c,B.x,B.y,B.w,B.h)[0];const e=w2Cv();e.getContext('2d').drawImage(a,0,0);RPW.castleHit[m](e.getContext('2d'),B.x,B.y,1);out.push([+d.toFixed(2),w2Diff(a,e,B.x,B.y,B.w,B.h)[0]])}return out}""")
        chk('the castle flinches (red flash, shake, flying bits) while hit and draws nothing at k = 1',all(x[0]>0.2 and x[1]==0 for x in r),r)
        r=await E("""()=>['coral','wreck','abyss'].map(m=>{const c=RPW.icon[m](88,88),d=c.getContext('2d').getImageData(44,60,1,1).data,e=c.getContext('2d').getImageData(1,1,1,1).data;return [c.width,c.height,RPW.icon[m](88,88)===c,d[3],e[3]<255,rpMapIcon(m,72,72).width]})""")
        chk('the map pictures: 88 x 88 tiles with the castle, rounded corners, cached; rpMapIcon uses them',all(x[:5]==[88,88,True,255,True] and x[5]==72 for x in r),r)
        r=await E("""()=>{const t0=performance.now();const W=RPW.world[2]();const ms=performance.now()-t0;const W2=RPW.world[2]();const g=w2Cv().getContext('2d');g.drawImage(W.c,0,0);W.anim(g,1);
          const L=[];for(let k=0;k<7;k++){const t1=performance.now();for(let i=0;i<10;i++)W.anim(g,1+i*.05);L.push((performance.now()-t1)/10)}L.sort((a,b)=>a-b);const n=W.nodes;
          const vis=['coral','wreck','abyss'].every(k=>n[k]&&n[k].x>80&&n[k].x<1170&&n[k].y>150&&n[k].y<730);
          return [W.c.width,W.c.height,W2.c===W.c,vis,+L[3].toFixed(3),Math.round(ms),Object.keys(n)]}""")
        chk(f'the World 2 painting: 1600 x 900, cached, the three nodes in the open part of the hub (clear of the side panel and the armory bar), live overlay {r[4]} ms',r[:4]==[1600,900,True,True] and r[4]<1.5,r)
        chk('no page errors',not er,er)
        if SHOTS:
            os.makedirs(SHOTS,exist_ok=True)
            async def shot(name):await pg.screenshot(path=os.path.join(SHOTS,name+'.png'))
            async def dump(js,name):
                d=await E(js);open(os.path.join(SHOTS,name+'.png'),'wb').write(base64.b64decode(d.split(',')[1]))
            for m in MAPS:
                await dump(f"()=>{{const B=rpBake(RP_MAP('{m}'));const c=w2Cv(),g=c.getContext('2d');g.drawImage(B.c,0,0);for(const p of B.G.pads){{g.save();g.translate(p.x,p.y);rpPadDraw(g,0,'idle');g.restore()}}return c.toDataURL()}}",m+'_clean')
                await E(f"()=>{{const R=w2New('{m}');R.t=2.2;rpDraw()}}");await pg.wait_for_timeout(300);await shot(m+'_start')
                await E(f"()=>{{const R=w2New('{m}');w2Full(R);R.t=4.1;rpDraw()}}");await pg.wait_for_timeout(300);await shot(m+'_battle')
            await E("()=>{const R=w2New('coral');w2Full(R);R.tide={k:1,high:true};R.t=6.3;rpDraw()}");await pg.wait_for_timeout(300);await shot('coral_high_tide')
            await E("()=>{const R=w2New('coral');w2Full(R);R.tide={k:.45,high:true};R.t=7.1;rpDraw()}");await pg.wait_for_timeout(300);await shot('coral_tide_rising')
            await E("()=>{const R=w2New('wreck');w2Full(R);R.fog=[{x:420,y:330,rx:150,ry:90},{x:1060,y:420,rx:170,ry:100},{x:700,y:250,rx:130,ry:80}];R.cannon={t:0,x:800,y:585,fire:.07,tx:600,ty:390};R.t=3;rpDraw()}");await pg.wait_for_timeout(300);await shot('wreck_fog_cannon_fire')
            await E("()=>{const R=RPX;R.cannon.fire=.3;R.t+=.2;rpDraw()}");await shot('wreck_cannonball')
            await E("()=>{const R=RPX;R.cannon.fire=.5;R.t+=.2;rpDraw()}");await shot('wreck_cannon_impact')
            await E("()=>{const R=w2New('abyss');w2Full(R);R.t=5.5;rpDraw()}");await pg.wait_for_timeout(300);await shot('abyss_whirlpools_glowcaps')
            await dump("()=>{const W=RPW.world[2]();const c=w2Cv(),g=c.getContext('2d');g.drawImage(W.c,0,0);W.anim(g,4);return c.toDataURL()}",'world2_painting')
            await dump("()=>{const c=document.createElement('canvas');c.width=300;c.height=100;const g=c.getContext('2d');['coral','wreck','abyss'].forEach((m,i)=>g.drawImage(RPW.icon[m](88,88),6+i*98,6));return c.toDataURL()}",'map_icons')
            await dump("()=>{const c=document.createElement('canvas');c.width=930;c.height=540;const g=c.getContext('2d');g.fillStyle='#2a2a3a';g.fillRect(0,0,930,540);['coral','wreck','abyss'].forEach((m,i)=>g.drawImage(rpw2aCastle(m).c,10+i*310,10));return c.toDataURL()}",'castles')
            print('screenshots in',SHOTS)
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed'+(' - FAILED: '+', '.join(FAIL) if FAIL else ''))
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
