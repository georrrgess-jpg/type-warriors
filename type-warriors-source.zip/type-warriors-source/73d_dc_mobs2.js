/* ---------- Daily Challenge: eight more monsters and three bosses ---------- */
/* all face left (toward the hero); y=0 is the ground */
function boilerkin(g,t,o){const S7=Math.sin(t*8),b=Math.abs(Math.cos(t*8))*3,lg=(o&&o.lg)||0;
 g.save();g.lineJoin='round';g.lineCap='round';
 for(const [x,ph] of[[-12,0],[12,Math.PI]]){const a=Math.sin(t*8+ph)*5;limb(g,x,-22,x+a*.6,-8,7,'#6a4a2a');limb(g,x+a*.6,-8,x+a,-2,5,'#3a2a1a');poly(g,[x+a-9,-1,x+a+8,-1,x+a+6,-6,x+a-7,-6],'#8a6a3a','#2a1a0a',1.4)}
 g.translate(0,-b);
 g.fillStyle=hgr(g,-26,26,'#e09a5a','#7a3e18');g.beginPath();g.roundRect(-24,-70,48,50,12);g.fill();g.strokeStyle='#2a1406';g.lineWidth=2;g.stroke();
 g.strokeStyle='#5a2a0a';g.lineWidth=3;for(const y of[-58,-34]){g.beginPath();g.moveTo(-24,y);g.lineTo(24,y);g.stroke()}
 g.fillStyle='#ffe0a0';for(const y of[-58,-34])for(let x=-18;x<=18;x+=9){g.beginPath();g.arc(x,y,1.6,0,TAU);g.fill()}
 ell(g,-8,-46,10,8,'#2a1006');glow(g,-8,-46,22,'#ff8a2a99');const fl=.6+.4*Math.sin(t*13);ell(g,-8,-46,7*fl+2,5*fl+1.5,'#ffb03a');ell(g,-8,-47,3,2.4,'#fff0b0');
 g.strokeStyle='#2a1006';g.lineWidth=2;for(let i=-2;i<=2;i++){g.beginPath();g.moveTo(-8+i*3.4,-53);g.lineTo(-8+i*3.4,-39);g.stroke()}
 g.fillStyle='#4a2a14';g.fillRect(8,-88,10,20);g.fillStyle='#8a5a2a';g.fillRect(6,-90,14,5);
 for(let i=0;i<4;i++){const u=(t*.9+i/4)%1;g.globalAlpha=(1-u)*.75;ell(g,13+Math.sin(u*6+i)*5-u*8,-94-u*36,5+u*9,4+u*7,'#e8eef4');g.globalAlpha=1}
 const ax=-34-lg*14;limb(g,-20,-52,-28,-44,5,'#6a4a2a');limb(g,-28,-44,ax,-50,5,'#6a4a2a');poly(g,[ax-2,-57,ax-10,-54,ax-6,-50,ax-10,-46,ax-2,-43],'#c8c0b0','#2a1a0a',1.2);
 limb(g,22,-50,30,-36,5,'#6a4a2a');ell(g,31,-34,4,4,'#8a6a3a');
 ell(g,4,-74,3,3,'#ffd76a');g.restore()}

function thornling(g,t,o){const hop=Math.abs(Math.sin(t*6))*6,lg=(o&&o.lg)||0;g.save();g.lineJoin='round';g.lineCap='round';
 for(const [x,ph] of[[-10,0],[10,Math.PI]]){const a=Math.sin(t*6+ph)*6;g.strokeStyle='#3a5a1a';g.lineWidth=5;g.beginPath();g.moveTo(x,-22-hop);g.quadraticCurveTo(x+a,-12,x+a*1.3,-1);g.stroke();for(let k=0;k<3;k++)poly(g,[x+a*.4+k*2,-18+k*6-hop*.5,x+a*.4+k*2-6,-20+k*6-hop*.5,x+a*.4+k*2,-15+k*6-hop*.5],'#c8d870')}
 g.translate(0,-hop);
 g.strokeStyle='#2a3a10';g.lineWidth=4.5;for(let i=0;i<9;i++){const a=i*.7+t*.3;g.beginPath();g.ellipse(0,-40,24,22,a,0,Math.PI*1.4);g.stroke()}
 ell(g,0,-40,19,18,rgr(g,-6,-46,2,22,'#7ab040','#2a4a10'));
 g.strokeStyle='#4a6a1a';g.lineWidth=3.4;for(let i=0;i<6;i++){const a=i*1.05+t*.4;g.beginPath();g.arc(0,-40,20,a,a+.9);g.stroke()}
 for(let i=0;i<14;i++){const a=i*TAU/14+Math.sin(t*2)*.05,r=22;poly(g,[Math.cos(a)*r,-40+Math.sin(a)*r,Math.cos(a+.12)*(r+9),-40+Math.sin(a+.12)*(r+9),Math.cos(a+.2)*r,-40+Math.sin(a+.2)*r],'#e8e0a8','#3a2a0a',1)}
 eye(g,-9,-44,3.4,'#ffe04a');eye(g,3,-45,3,'#ffe04a');g.strokeStyle='#1a2a08';g.lineWidth=2;g.beginPath();g.moveTo(-10,-33);g.quadraticCurveTo(-4,-29-lg*4,2,-33);g.stroke();
 for(const [x,r] of[[-8,-.5],[6,.4]]){g.save();g.translate(x,-60);g.rotate(r+Math.sin(t*3+x)*.15);ell(g,0,-9,6,11,vgr(g,-20,0,'#a8e060','#4a8a20'));g.strokeStyle='#2a5a10';g.lineWidth=1.2;g.beginPath();g.moveTo(0,0);g.lineTo(0,-18);g.stroke();g.restore()}
 ell(g,10,-66,4.4,4.4,'#ff6aa8');ell(g,10,-66,1.6,1.6,'#ffe04a');
 g.restore()}

function bogfrog(g,t,o){const ph=(t*1.6)%1,hop=Math.sin(Math.min(1,ph*1.6)*Math.PI)*16,sq=ph>.62?1-(ph-.62)*1.2:1,lg=(o&&o.lg)||0;g.save();g.lineJoin='round';g.lineCap='round';
 g.translate(0,-hop);
 limb(g,10,-16,22,-6,9,'#4a8a3a');limb(g,22,-6,10,-1,7,'#4a8a3a');ell(g,4,-1,9,3,'#5a9a44');
 ell(g,2,-36,22,24*sq,vgr(g,-60,-12,'#7ac850','#3a7a2a'));ell(g,-2,-30,14,15*sq,'#e8e0a0');
 limb(g,-10,-18,-18,-6,8,'#4a8a3a');ell(g,-21,-2,8,3,'#5a9a44');
 ell(g,-8,-62*sq+4,17,14,vgr(g,-76,-48,'#8ad860','#4a8a3a'));
 for(const x of[-18,-4]){ell(g,x,-72*sq+6,7,7,'#9ae070');ell(g,x,-72*sq+6,4.4,4.4,'#ffd84a');ell(g,x-1,-72*sq+6,1.6,3.6,'#1a1000')}
 g.strokeStyle='#1a3a10';g.lineWidth=2;g.beginPath();g.moveTo(-24,-56*sq+4);g.quadraticCurveTo(-12,-50*sq+4,2,-55*sq+4);g.stroke();
 g.fillStyle='#8a5a2a';poly(g,[-14,-80*sq+6,-2,-80*sq+6,4,-74*sq+6,-20,-74*sq+6],'#b8402a','#2a0a04',1.4);
 const sx=-30-lg*16;g.strokeStyle='#8a6a3a';g.lineWidth=3.4;g.beginPath();g.moveTo(sx+30,-20);g.lineTo(sx-12,-74);g.stroke();poly(g,[sx-12,-74,sx-18,-90,sx-6,-78],'#d8d0c0','#2a1a0a',1.2);
 limb(g,-14,-40,sx+2,-46,6,'#4a8a3a');
 g.save();g.translate(18,-40);g.rotate(.2);ell(g,0,0,16,20,vgr(g,-20,20,'#5ab05a','#2a6a2a'));g.strokeStyle='#1a4a1a';g.lineWidth=1.5;for(let i=0;i<5;i++){g.beginPath();g.moveTo(0,0);g.lineTo(Math.cos(i*1.25-1)*14,Math.sin(i*1.25-1)*18);g.stroke()}ell(g,0,0,3,3,'#ff9ad0');g.restore();
 g.restore()}

function scarab(g,t,o){const cy=-44+Math.sin(t*7)*5,fl=Math.sin(t*40);g.save();g.lineJoin='round';glow(g,0,cy,58,'#ffd06a55');g.translate(0,cy);
 g.globalAlpha=.55;for(const s of[1,-1]){g.save();g.rotate(-.5*s+fl*.25*s);ell(g,8,-14*s,24,8,'#fff6d0');g.restore()}g.globalAlpha=1;
 for(let i=0;i<3;i++){const y=6+i*2;limb(g,-10+i*10,y,-16+i*10+Math.sin(t*14+i)*3,y+10,2.4,'#3a2408')}
 ell(g,4,0,22,15,rgr(g,-4,-8,2,24,'#ffe890','#a8701a'));g.strokeStyle='#5a3a08';g.lineWidth=2;g.beginPath();g.moveTo(-2,-14);g.lineTo(6,14);g.stroke();
 g.strokeStyle='#fff8d088';g.lineWidth=2.4;g.beginPath();g.ellipse(2,-4,14,7,-.2,Math.PI*1.1,Math.PI*1.7);g.stroke();
 ell(g,-17,-2,9,8,'#6a4410');eye(g,-21,-4,2.2,'#7affd8');
 g.strokeStyle='#3a2408';g.lineWidth=2.4;g.beginPath();g.moveTo(-24,-6);g.quadraticCurveTo(-34,-14,-30,-22);g.moveTo(-24,0);g.quadraticCurveTo(-36,0,-36,-8);g.stroke();
 gem(g,10,-2,4,'#4ad8ff');g.restore()}

function prismoth(g,t,o){const cy=-48+Math.sin(t*3.4)*8,fl=Math.sin(t*16);g.save();g.lineJoin='round';glow(g,0,cy+10,80,'#c89aff55');g.translate(0,cy);
 const wing=(sy,f)=>{g.save();g.scale(1,sy*(.82+.18*f));poly(g,[2,-2,-14,-34,-34,-30,-36,-10,-6,2],vgr(g,-34,0,'#f4e8ff','#9a6ae0'),'#3a1a7a',1.4);poly(g,[2,-2,22,-30,38,-24,34,-6,6,2],vgr(g,-30,0,'#e8f8ff','#6ab0f0'),'#1a3a7a',1.4);
  g.fillStyle='#ffffff55';poly(g,[-6,-6,-18,-26,-26,-22],'#ffffff66');poly(g,[10,-6,24,-22,30,-18],'#ffffff55');g.restore()};
 wing(1,fl);wing(-.7,-fl);
 ell(g,0,0,6,13,vgr(g,-12,12,'#d8c8ff','#5a3aa8'));
 g.strokeStyle='#5a3aa8';g.lineWidth=1.6;g.beginPath();g.moveTo(-2,-12);g.quadraticCurveTo(-10,-24,-16,-26);g.moveTo(2,-12);g.quadraticCurveTo(6,-24,12,-27);g.stroke();
 ell(g,-16,-26,2.4,2.4,'#fff');ell(g,12,-27,2.4,2.4,'#fff');eye(g,-3,-9,2,'#ffe04a');eye(g,3,-9,2,'#ffe04a');
 g.strokeStyle='#e8d8ff';g.lineWidth=1;g.beginPath();g.moveTo(0,12);g.lineTo(0,26);g.stroke();
 glow(g,0,32,26,'#ffd06acc');poly(g,[-5,24,5,24,7,38,-7,38],'#ffcf5a','#6a4a08',1.2);ell(g,0,31,3,4,'#fff8d0');
 for(let i=0;i<3;i++)sparkle(g,Math.sin(t*2+i*2)*26,10+Math.cos(t*2.4+i)*16,4,.5+.5*Math.sin(t*5+i),'#e8d8ff');g.restore()}

function starwisp(g,t,o){const cy=-50+Math.sin(t*4)*7,sp=t*1.6;g.save();
 for(let i=0;i<10;i++){const u=i/10;g.globalAlpha=(1-u)*.5;ell(g,10+i*7,cy+Math.sin(t*4-i*.5)*4,7*(1-u)+1,5*(1-u)+1,i%2?'#9ad8ff':'#ffd0f4');g.globalAlpha=1}
 glow(g,0,cy,64,'#9ad8ff88');g.translate(0,cy);g.rotate(Math.sin(t*2)*.25);
 g.beginPath();for(let k=0;k<10;k++){const a=-Math.PI/2+k*Math.PI/5,r=k%2?9:24;g.lineTo(Math.cos(a)*r,Math.sin(a)*r)}g.closePath();g.fillStyle=rgr(g,-4,-6,2,26,'#fffbe0','#7ab8ff');g.fill();g.strokeStyle='#1a3a7a';g.lineWidth=1.8;g.stroke();
 eye(g,-6,-2,2.6,'#1a2a6a');eye(g,4,-2,2.6,'#1a2a6a');g.strokeStyle='#1a2a6a';g.lineWidth=1.6;g.beginPath();g.arc(-1,3,4,.2,Math.PI-.2);g.stroke();
 for(let i=0;i<4;i++)sparkle(g,Math.cos(sp+i*1.57)*34,Math.sin(sp+i*1.57)*22,4,.8,'#fff');g.restore()}

Object.assign(DR,{boilerkin,thornling,bogfrog,scarab,prismoth,starwisp,
 ashbrute:(g,t,o)=>hum(g,t,{lg:o.lg,sk:'#5a5258',dk:'#2a2428',cl:'#6a1a14',top:'#8a2a1a',hd:13,eye:'#ffb030',wp:'club',wsc:1.5,bulk:1.95,lw:12,reach:8,legH:32,belly:1,hunch:.8,pad:'#3a3036',padspike:1,aura:'#ff6a2a',
  fx:(g2,t2,q)=>{g2.strokeStyle='#ff8a2a';g2.lineWidth=2;for(const p of[[-14,q.SH+4,-6,q.SH+16,-12,q.SH+26],[10,q.SH+8,16,q.SH+18,8,q.SH+30]]){g2.globalAlpha=.6+.4*Math.sin(t2*6);g2.beginPath();g2.moveTo(p[0],p[1]);g2.lineTo(p[2],p[3]);g2.lineTo(p[4],p[5]);g2.stroke();g2.globalAlpha=1}
   for(let i=0;i<4;i++){const u=(t2*.8+i/4)%1;g2.globalAlpha=1-u;ell(g2,-10+i*7,q.SH-10-u*40,2,2,'#ffb02e');g2.globalAlpha=1}}}),
 hoardgol:(g,t,o)=>hum(g,t,{lg:o.lg,sk:'#e0b040',dk:'#8a6010',cl:'#a87818',top:'#c89020',hd:14,eye:'#ff4a6a',wp:'club',wsc:1.4,bulk:1.9,lw:12,reach:8,legH:32,belly:1,pad:'#b8861a',aura:'#ffd76a',
  fx:(g2,t2,q)=>{for(const [x,y,r] of[[-12,q.SH+8,5],[6,q.SH+4,4.4],[12,q.SH+18,4],[-4,q.SH+22,4.6]])coin(g2,x,y,r);gem(g2,0,q.SH+12,4,'#ff4a6a');for(let i=0;i<3;i++){const u=(t2*.7+i/3)%1;g2.globalAlpha=1-u;coin(g2,-14+i*14,q.SH-30-u*40,3.4);g2.globalAlpha=1}}})});
Object.assign(MON,{
 boilerkin:{n:'Boilerkin',h:120,sp:60,th:96,pj:'bone',ds:'A walking kettle with a furnace for a heart. Mind the steam.'},
 thornling:{n:'Thornling',h:112,sp:66,th:84,ds:'A ball of living bramble that bounces toward anyone who steps off the path.'},
 bogfrog:{n:'Bog Knight',h:124,sp:62,th:96,ds:'A frog in a tin hat with a reed spear and big ambitions.'},
 scarab:{n:'Gilded Scarab',h:84,sp:124,th:62,fly:1,ds:'A golden beetle that buzzes louder the closer it gets.'},
 prismoth:{n:'Prism Moth',h:100,sp:112,th:80,fly:1,ds:'Glass wings and a lantern tail. It drifts toward any light, including you.'},
 starwisp:{n:'Star Wisp',h:88,sp:132,th:60,fly:1,ds:'A fallen star that would very much like to get back up.'},
 ashbrute:{n:'Ash Brute',h:226,sp:30,th:120,ds:'A hulk of cooled lava. The cracks still glow when it is angry, which is always.'},
 hoardgol:{n:'Hoard Golem',h:226,sp:30,th:120,ds:'A treasure pile that stood up. Every coin it drops is a trap.'}});
for(const k of['boilerkin','thornling','bogfrog','scarab','prismoth','starwisp','ashbrute','hoardgol'])MON[k].d=DR[k];

/* ----- bosses ----- */
function sphW(g,x,y,rot,sc,c0,c1){g.save();g.translate(x,y);g.rotate(rot);g.scale(sc,sc);
 for(let i=0;i<7;i++){const a=-1.95+i*.2,L=150-Math.abs(i-2)*14;g.save();g.rotate(a);g.beginPath();g.moveTo(0,-7);g.quadraticCurveTo(L*.55,-14,L,0);g.quadraticCurveTo(L*.55,14,0,7);g.closePath();g.fillStyle=hgr(g,0,L,c0,c1);g.fill();g.strokeStyle='#0a1030';g.lineWidth=2;g.stroke();g.strokeStyle='#ffffff40';g.lineWidth=1.4;g.beginPath();g.moveTo(6,0);g.lineTo(L-10,0);g.stroke();g.restore()}
 ell(g,0,0,18,14,'#c8923a');g.restore()}
function sphinxB(g,t,o){const lg=o.lg||0,br=Math.sin(t*2)*2,wf=Math.sin(t*1.6);g.save();g.lineJoin='round';g.lineCap='round';glow(g,-10,-110,150,'#ffd06a33');
 // tail
 g.strokeStyle='#b8862a';g.lineWidth=9;g.beginPath();g.moveTo(96,-50);g.quadraticCurveTo(140,-70+Math.sin(t*2)*10,128,-120);g.stroke();ell(g,128,-124,9,12,'#6a4010');
 // far wing
 sphW(g,44,-118,-.05-wf*.05,.8,'#2a4aa0','#c89a3a');
 // body
 g.fillStyle=vgr(g,-130,-10,'#e8b860','#a87428');g.beginPath();g.moveTo(-60,-60);g.quadraticCurveTo(-40,-128-br,40,-122-br);g.quadraticCurveTo(108,-118,104,-50);g.lineTo(100,-18);g.lineTo(-56,-18);g.closePath();g.fill();g.strokeStyle='#3a2208';g.lineWidth=2.4;g.stroke();
 g.strokeStyle='#8a5a1a88';g.lineWidth=2;for(let i=0;i<5;i++){g.beginPath();g.moveTo(-10+i*20,-112-br);g.quadraticCurveTo(-4+i*20,-90,-12+i*20,-70);g.stroke()}
 // legs
 for(const [x,f] of[[70,0],[96,1]]){limb(g,x,-40,x+2,-10,18,'#c8923a');ell(g,x-4,-6,16,8,'#d8a248')}
 const px=-62-lg*30;limb(g,-40,-58,px+10,-14,20,'#d8a248');ell(g,px,-8,22,9,'#e8b860');for(let i=0;i<3;i++)poly(g,[px-18+i*8,-6,px-24+i*8,0,px-14+i*8,-1],'#fff6e0','#3a2208',1);
 // near wing
 sphW(g,14,-116,.05+wf*.06,1,'#4a7ae0','#ffd76a');
 /* mane joining head and body */
 poly(g,[-30,-120-br,-74-lg*30,-150+br,-82-lg*30,-104+br,-48,-60],vgr(g,-150,-60,'#c8923a','#8a5a1a'),'#3a2208',2);
 // head with nemes headdress
 const hx=-62-lg*36,hy=-146+br;g.save();g.translate(hx,hy);
  g.fillStyle='#1a3a8a';g.beginPath();g.moveTo(-40,-6);g.quadraticCurveTo(-34,-58,0,-62);g.quadraticCurveTo(34,-58,40,-6);g.lineTo(36,50);g.lineTo(18,32);g.lineTo(-18,32);g.lineTo(-36,50);g.closePath();g.fill();
 g.save();g.clip();g.fillStyle='#ffd76a';for(let i=-8;i<10;i++)g.fillRect(-50,-60+i*9,100,4);g.restore();g.strokeStyle='#0a1030';g.lineWidth=2.4;g.stroke();
 ell(g,0,0,22,27,rgr(g,-6,-8,3,30,'#f0c880','#b07a30'));
 g.fillStyle='#1a1a3a';g.fillRect(-22,-26,44,6);ell(g,0,-40,7,9,'#ffd76a');ell(g,0,-42,3,4,'#3ad8ff');
 eye(g,-9,-6,3.6,'#3ad8ff');eye(g,8,-6,3.6,'#3ad8ff');g.strokeStyle='#1a0a00';g.lineWidth=2.4;g.beginPath();g.moveTo(-17,-12);g.lineTo(-3,-10);g.moveTo(16,-12);g.lineTo(3,-10);g.stroke();
 g.strokeStyle='#5a3008';g.lineWidth=2;g.beginPath();g.moveTo(-8,12+lg*6);g.quadraticCurveTo(0,16+lg*10,8,12+lg*6);g.stroke();
 g.fillStyle='#1a3a8a';g.fillRect(-4,22,8,18);g.fillStyle='#ffd76a';for(let i=0;i<3;i++)g.fillRect(-4,24+i*6,8,2.4);
 g.restore();
 for(let i=0;i<5;i++){const a=t*1.2+i*1.26;glow(g,hx+Math.cos(a)*70,hy-20+Math.sin(a)*30,10,'#3ad8ffaa')}
 g.restore()}

function clockwyrm(g,t,o){const lg=o.lg||0;g.save();g.lineJoin='round';g.lineCap='round';glow(g,0,-120,150,'#ffb04033');
 const pts=[];for(let i=0;i<=14;i++){const u=i/14,x=90-u*130+Math.sin(t*1.6+u*5)*14,y=-10-u*170+Math.sin(t*2+u*4)*8;pts.push([x,y])}
 const head=pts[14];head[0]-=lg*40;
 for(let i=0;i<14;i++){const [x,y]=pts[i],r=26-i*.9;
  g.save();g.translate(x,y);g.rotate(t*(i%2?1.4:-1.4));g.fillStyle='#8a5a1a';g.beginPath();for(let k=0;k<20;k++){const a=k*Math.PI/10,rr=k%2?r*.84:r+5;g.lineTo(Math.cos(a)*rr,Math.sin(a)*rr)}g.closePath();g.fill();g.strokeStyle='#2a1404';g.lineWidth=1.6;g.stroke();g.restore();
  ell(g,x,y,r,r,rgr(g,x-r*.3,y-r*.3,2,r,'#ffd27a','#a8701e'));g.strokeStyle='#2a1404';g.lineWidth=1.6;g.beginPath();g.arc(x,y,r,0,TAU);g.stroke();
  ell(g,x,y,r*.38,r*.38,'#5a3a10');ell(g,x,y,r*.15,r*.15,'#ffb03a')}
 for(let i=0;i<6;i++){const u=(t*.7+i/6)%1,[x,y]=pts[(i*2+3)%14];g.globalAlpha=(1-u)*.6;ell(g,x+8,y-20-u*40,6+u*10,5+u*8,'#e8eef4');g.globalAlpha=1}
 // head
 const [hx,hy]=head;g.save();g.translate(hx,hy);g.rotate(-.15+lg*.15);
 poly(g,[20,-22,-30,-28,-70,-12,-74,4,-36,8,-30,18,-66,26,-60,36,-20,30,22,22],vgr(g,-30,36,'#e8b050','#7a4a12'),'#2a1404',2.4);
 const jaw=.2+lg*.5+Math.sin(t*3)*.05;g.save();g.translate(-24,14);g.rotate(jaw*.6);poly(g,[0,0,-44,12,-38,22,4,14],'#a8701e','#2a1404',2);for(let i=0;i<4;i++)poly(g,[-8-i*9,2,-12-i*9,10,-4-i*9,4],'#fff6e0');g.restore();
 glow(g,-46,14,30,'#ff8a2acc');ell(g,-46,14,9,5,'#ffe08a');
 for(let i=0;i<4;i++)poly(g,[-30-i*9,-20,-34-i*9,-10,-26-i*9,-14],'#fff6e0','#2a1404',1);
 eye(g,-22,-14,5,'#ff5a2a');g.strokeStyle='#2a1404';g.lineWidth=2.6;g.beginPath();g.moveTo(-34,-24);g.lineTo(-12,-20);g.stroke();
 for(const [x,a] of[[0,-.6],[12,-.3]]){g.save();g.translate(x,-22);g.rotate(a);poly(g,[0,0,10,-34,16,-4],'#ffd27a','#2a1404',1.6);g.restore()}
 g.save();g.translate(4,0);g.rotate(t*2);g.fillStyle='#ffd76a';g.beginPath();for(let k=0;k<16;k++){const a=k*Math.PI/8,r=k%2?7:10;g.lineTo(Math.cos(a)*r,Math.sin(a)*r)}g.closePath();g.fill();g.strokeStyle='#2a1404';g.lineWidth=1.2;g.stroke();g.restore();
 g.restore();g.restore()}

function mothqueen(g,t,o){const lg=o.lg||0,cy=-130+Math.sin(t*1.8)*8,fl=Math.sin(t*5);g.save();g.lineJoin='round';glow(g,0,cy,170,'#ffcf5a33');g.translate(-lg*30,cy);
 const W1=(sy,f,c0,c1,big)=>{g.save();g.scale(1,sy*(.86+.14*f));const s=big?1:.72;
  poly(g,[0,-4,-30*s,-90*s,-96*s,-110*s,-122*s,-70*s,-104*s,-20*s,-20,6],vgr(g,-110*s,0,c0,c1),'#2a1408',2.4);
  poly(g,[0,-4,26*s,-96*s,90*s,-112*s,118*s,-74*s,100*s,-22*s,20,6],vgr(g,-110*s,0,c0,c1),'#2a1408',2.4);
  for(const sx of[-1,1]){ell(g,sx*64*s,-64*s,16*s,16*s,'#2a1408');ell(g,sx*64*s,-64*s,11*s,11*s,'#ffcf5a');ell(g,sx*64*s,-64*s,5*s,5*s,'#2a1408')}
  g.strokeStyle='#ffffff40';g.lineWidth=2;for(const sx of[-1,1])for(let i=1;i<4;i++){g.beginPath();g.moveTo(0,0);g.lineTo(sx*(30+i*24)*s,-(40+i*20)*s);g.stroke()}g.restore()};
 W1(1,fl,'#c8a8f0','#5a3a8a',1);W1(-.7,-fl,'#a888d8','#3a2a6a',0);
 ell(g,0,10,16,34,vgr(g,-20,44,'#d8c0f0','#6a4aa0'));for(let i=0;i<4;i++){g.strokeStyle='#3a2a6a';g.lineWidth=2;g.beginPath();g.ellipse(0,18+i*8,14-i*1.5,3,0,0,Math.PI);g.stroke()}
 glow(g,0,62,60,'#ffcf5acc');poly(g,[-14,44,14,44,18,78,0,88,-18,78],'#ffcf5a','#6a4a08',2);ell(g,0,64,7,10,'#fff8d0');
 ell(g,0,-28,22,20,vgr(g,-48,-8,'#e8d8ff','#7a5ab8'));
 g.fillStyle='#fff';for(let i=0;i<14;i++){const a=Math.PI+i*Math.PI/13;ell(g,Math.cos(a)*24,-20+Math.sin(a)*-6,4,6,'#f4ecff')}
 eye(g,-9,-32,6,'#ff4a8a');eye(g,9,-32,6,'#ff4a8a');
 g.strokeStyle='#5a3a8a';g.lineWidth=3;for(const sx of[-1,1]){g.beginPath();g.moveTo(sx*6,-46);g.quadraticCurveTo(sx*22,-90,sx*44,-96+Math.sin(t*3)*4);g.stroke();for(let i=0;i<6;i++){const u=i/6;g.beginPath();g.moveTo(sx*(10+u*30),-56-u*36);g.lineTo(sx*(16+u*30),-50-u*38);g.stroke()}}
 poly(g,[-14,-46,-10,-60,-4,-50,0,-64,4,-50,10,-60,14,-46],'#ffd76a','#6a4a08',1.4);gem(g,0,-52,3,'#ff4a8a');
 for(let i=0;i<8;i++){const u=(t*.4+i/8)%1;g.globalAlpha=1-u;sparkle(g,Math.sin(i*2.3+t)*120,40+u*120,5,1,'#ffe8a0');g.globalAlpha=1}
 g.restore()}
Object.assign(DR,{sphinx:sphinxB,clockwyrm,mothqueen});
Object.assign(MON,{
 sphinx:{n:'Riddle Sphinx',h:340,sp:54,th:220,tw:320,boss:1,cx:20,ds:'Answers questions with questions and travellers with claws.'},
 clockwyrm:{n:'Clockwork Wyrm',h:380,sp:56,th:240,tw:260,boss:1,ds:'A brass serpent built to guard the Foundry. Nobody remembers how to turn it off.'},
 mothqueen:{n:'Lantern Moth Queen',h:360,sp:54,th:250,tw:300,boss:1,ds:'Mother of every moth that ever chased a light.'}});
for(const k of['sphinx','clockwyrm','mothqueen'])MON[k].d=DR[k];
Object.assign(ROARK,{sphinx:'growl',clockwyrm:'rumble',mothqueen:'screech'});
