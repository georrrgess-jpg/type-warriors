/* ===== THE CROOKED CUE 9.9g: the 8-ball "glitch", the guide on the wrong ball, clearer groups (97b, after 97a) =====
   - Players reported potting the 8 after clearing their group and getting a foul screen ("8 without a bank"), the 8 spotted and a
     re-shot. That was Barnacle's house rule (the 8 had to kiss a cushion before it dropped), shown only on his card, so it read as a
     bug. It is retired: a legally potted 8 in the called pocket wins the rack against everyone. Barnacle plays plain 8-ball; resumed
     matches drop the rule too (the judge strips house.bank8). The rule code in 96c stays, unused.
   - The aim guide is not drawn when the first ball on the aim line is one you may not hit first (the opponent's group, or the 8 too
     early); that ball gets a small red "not yours" ring instead.
   - While you aim, your own group's balls wear a soft gold ring (and the 8 too once it is your target), so solids and stripes are
     easy to tell apart with any ball set. */
try{if(PZ_REG.barnacle){PZ_REG.barnacle.house={};PZ_REG.barnacle.houseTxt='No house rule: plain 8-ball. He just loves bank shots.'}}catch(e){}
try{PZ97_HOUSE.barnacle='None. Plain 8-ball (he loves banks).'}catch(e){}
try{PZ_TIPS.barnacle='Loves banks and kicks. Leave him straight shots and he gets fancy.'}catch(e){}
{const j0=pzrJudge;pzrJudge=function(st,ev){if(st&&st.house&&st.house.bank8)st.house=Object.assign({},st.house,{bank8:0});return j0.apply(this,arguments)}}
{const d0=pzDrawGuide;pzDrawGuide=function(g,B,ang,mode,t,spinB){const st=PZ.st;let tg=null;try{if(st&&!st.brk)tg=pzrTargets(st)}catch(e){}
 const cue=B[0],R=PZ_PHY.R,G=PZ_G;
 /* gold rings on your own balls (the 8 once it is yours) */
 if(tg&&cue&&cue.on){g.save();g.translate(G.x,G.y);const pu=.55+.2*Math.sin(t*4);g.lineWidth=2.4;g.strokeStyle=`rgba(255,212,90,${pu.toFixed(3)})`;
  for(const b of B)if(b.on&&b.id&&tg.includes(b.id)&&!(st.open&&!st.grp[st.turn])){g.beginPath();g.arc(b.x,b.y,R+3.5,0,TAU);g.stroke()}g.restore()}
 if(tg&&cue&&cue.on){const h=pzRay(B,cue.x,cue.y,Math.cos(ang),Math.sin(ang),0);
  if(h&&h.type==='ball'&&!tg.includes(h.id)){/* not a legal first ball: no guide, a red ring on it */
   g.save();g.translate(G.x,G.y);g.lineWidth=3;g.strokeStyle='rgba(255,90,110,.95)';g.beginPath();g.arc(h.b.x,h.b.y,R+4,0,TAU);g.stroke();
   g.beginPath();g.moveTo(h.b.x-R*.55,h.b.y-R*.55);g.lineTo(h.b.x+R*.55,h.b.y+R*.55);g.stroke();g.restore();return {hit:h,pocket:-1,blocked:true}}}
 return d0.apply(this,arguments)}}
