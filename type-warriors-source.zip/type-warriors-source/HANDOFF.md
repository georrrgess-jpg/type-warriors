# Type Warriors — Handoff Brief

Read this whole file before changing anything. It records how the game is built, the art and UI style the owner has approved, and the standing rules. Screenshots of the approved look are in `refs/`.

---

## 1. What the game is

Type Warriors is a browser typing game: a chunky cartoon knight (or archer, mage or rogue) fights monsters by typing words. It ships as **one self-contained HTML file** (`type-warriors.html`), with no external assets apart from Google Fonts. The owner plans to publish it on their Wix site.

Major systems:
- Campaign (regions such as Goblin Woods and Sunken Ruins, with stages, stars and region bosses), Endless, Daily Challenge (a new realm and modifier each day), Warden's Arena, Graveyard event, Halloween events.
- Armory: classes, weapons and armor with mastery, Skill Tree, Auto-Equip.
- Casino and minigames, Shop, chests (Celestial / Astral chest, Graveyard crate), Bounty board, Bestiary, Hall, Save Center, Updates/News (the bell), Calendar.
- Companion Hall (pets): roster, eggs (Runeshell = Rare, Crownheart = Legendary), hatching, Adventure Trail stamps, bond levels and cosmetics.
- Main menu: the "Console Dock" hub. A bright diorama of the current region on the right, a campaign panel on the left, a six-tab dock at the bottom (Play, Gear, Pets, Progress, Shop, More), and the bell and calendar in the bottom-right corner.

---

## 2. How the code is organised (important)

- Source is about 145 numbered modules (`00_head.html`, `10_data.js`, … `88c_dockicons.js`, `70_main.js`). `build.sh` concatenates them **in a fixed order** into `out.html`, then syntax-checks the extracted script with `node --check` (it prints `SYNTAX_OK`).
- The deliverable is `out.html`, copied to **`type-warriors.html`**. A second copy, **`type-warriors-act6-TEST.html`**, has always been delivered alongside it. It is byte-identical, built by `build_ast3.sh` into `out_ast.html`. Always build both, confirm `cmp out.html out_ast.html` passes, and deliver both.
- **Everything is one script, so later code overrides earlier code:**
  - A later `function foo(){}` replaces an earlier one everywhere.
  - Wrap an existing function with `{const f0=foo;foo=function(){const r=f0.apply(this,arguments);/*extra*/;return r}}`.
  - Some globals are `const` (for example `dcKey`, `hwOn`, `DKI`, `PTICO`) and cannot be reassigned. Mutate them (`Object.assign(DKI,{...})`) or wrap their callers.
- **Preferred way to make changes:** add a new module after the module you are changing (for example `87h_pet_fx.js` after `87g_pet_polish.js`), add it to the file lists in **both** `build.sh` and `build_ast3.sh`, and do the overrides there. When you edit an existing module, save a backup first (`file.js.v7bak`).
- **UI framework:**
  - `show(html, cls)` renders a menu into `#ov` and clears `LIVE`.
  - Animate canvases with `LIVE.push({cv, fn: t => draw(t), slow: N})`, where `slow` means "render every Nth frame".
  - `S.back` is the Back/Esc handler. `$('id')` is `getElementById`. `title()` opens the main menu.
- **CSS** is added by each module through `document.createElement('style')`. Later styles win.
- **Save data** is the global `P` (for example `P.gold`, `P.pets`, `P.eggs`, `P.petSort`). Call `save()` after changing it.
- **Pets:**
  - Data and logic: `87a_pet_data.js` (`PDEF`, `PIDS`, `petOwned`, `petHatch`, `petBuy`, `petEquip`, `petNextEgg`, `PEGG_PRICE = {r:2000, l:10000}`).
  - Art: `87b_pet_art.js` (`petDraw`, `petFit`, `eggDraw`, `eggFit`, `PSIG` signature colours).
  - Menus: `87c`, `87e`, `87g`, `87h`. Hatch cinematic: `87f` (`ptHatchScene`). State object: `PTX`.
- **Dock and hub:**
  - `88_dock.js` holds the dock, sheets and Daily card.
  - `88b_hub.js` holds the diorama `homeScene`/`drawBG`, the `DKI` icon set, glare and tilt (`.dkg`, `.dktilt`), the hero hotspot and the Daily medallion `dkDailyLive`.
  - `88c_dockicons.js` holds the current dock icons and their animations.

---

## 3. Art and UI style (the owner's approved look; match it)

Look at `refs/` first. In short: **a polished, warm, storybook-cartoon fantasy, lit at night.**

- **Illustration:** hand-built vector art drawn in canvas or inline SVG, never bitmaps.
  - Chunky shapes with **dark outlines** (`#12081f`, about 2.4–3px at a 100-unit scale).
  - Soft gradient fills, a darker "shade" half on the right, and a **white highlight stroke** on the upper left.
  - Small sparkles (4-point stars) and soft additive glows (`pGlow` / `globalCompositeOperation='lighter'`).
  - Characters are cute and round, with big friendly eyes.
- **SVG icon helpers** (in `31b_boonicons.js`; reuse them):
  - `bP(path, fill)`: outlined shape. `bF(path, fill, opacity)`: shade. `bH(path, colour, width)`: highlight.
  - `bC(x, y, r, fill)`: circle. `bEl(...)`: ellipse. `bL(...)`: outlined line. `bS(x, y, r, fill)`: sparkle.
  - Icons use a 100×100 viewBox, with the art roughly between 14 and 86.
- **Palette:**
  - Panels are deep indigo and purple: `#1c1446` to `#0c0822`, borders `#3a3070` / `#5a4ca0`, glassy, with a 1px inner top highlight.
  - Gold accent: `--gold: #ffc94a` / `#ffd45a`. Body text is warm white (`#fff8e8`, `#f4ecd8`). Muted text is lavender (`#c4badf`).
  - Rarity colours: Rare is blue `#5ab8ff`, Legendary is gold `#ffc23a`, and purple `#b47aff` marks magic.
  - Errors and badges use red `#e8364e`.
- **Type:**
  - **Pirata One** for big decorative titles ("Companion Hall", "Armory", pet names), in gold.
  - **Poppins** (`var(--ui)`) for all UI text, bold 700/800 on buttons. Cinzel is used occasionally.
- **Buttons:**
  - Primary is a gold gradient with dark-brown text and a 4px "pressed" bottom shadow.
  - Secondary is indigo with a lavender border. Soft and ghost buttons are text with a chevron.
  - Pills, tags and badges are rounded.
- **Motion:**
  - Springy and lively but tasteful: `cubic-bezier(.3,1.5,.5,1)` overshoot, short (0.2–0.7s) one-shot animations, staggered entrances.
  - Hover lifts things by 2–4px; presses squish them to about 0.9.
  - Idle life comes from bobbing, breathing, blinking and drifting motes.
  - Every animation must finish cleanly. Don't let a hover animation snap back halfway; play it once with a class and remove the class afterwards.
  - Respect `prefers-reduced-motion`.
- **Layout:** 1600×900 design space, scaled to fit. The dock is centred at the bottom. Panels have 18–22px radii. Don't clutter: give one clear next action per screen.

---

## 4. Performance rules (learned the hard way)

Rendering is fill-bound on weaker machines. **Avoid:**
- `backdrop-filter`
- `mix-blend-mode` soft-light or screen
- animated `box-shadow` or `filter`
- infinite `background-position` animations
- large full-screen additive glows every frame

**Prefer:**
- `transform` and `opacity` animations
- cached offscreen canvases for static layers
- `slow` on `LIVE` canvases
- one-shot timed shines instead of constant ones

Measure the frame rate before and after visual changes; headless Chromium gives roughly 18–27 fps as a baseline. For a weaker machine, add CDP `Emulation.setCPUThrottlingRate` (2 or 4) and test at device scale factor 1.5.

---

## 5. Testing

Python Playwright scripts (`t_*.py`) load `out.html` headless, drive the game with `page.evaluate`, print results and write screenshots to `shots/`. An empty `[]` at the end means no page errors. `ERR_TUNNEL_CONNECTION_FAILED` is only the offline font load and is harmless.

Useful patterns:
- Set up state with `await pg.evaluate("()=>{RS_ASK=false;P.gold=5000;P.petSt=2;petNorm();petHall('Pets')}")`.
- Change the date with `pg.clock.install(...)`, because `dcKey` is const.
- Freeze CSS animations mid-way: `el.getAnimations({subtree:true}).forEach(a=>{a.pause();a.currentTime=200})`.

Regression set to run after changes: `t_time_alert t_leaderboard t_ranked t_ranked_net t_wc_school t_perf_casino t_wildcard t_wc_pp t_wc_scan t_access t_code81 t_petclick t_loadout_polish t_loadouts t_flow t_pe t_pdet t_entry t_misc t_trail t_modes t_start6 t_stuck2 t_dkacc t_audit t_sort t_fx t_dock t_dkanim t_fishing t_finishers`. Some depend on game state and may need small updates when a layout changes. Wildcard room codes have their own test, `t_wc_code.py`, which needs a local MQTT broker (see the Wildcard notes below). Keep element IDs stable where you can.

Always **look at screenshots** of what you changed (at 1600×900, and also at 1280×720 or smaller) before delivering.

---

## 6. Standing rules from the owner

1. **Updates tab (bell):** only add or push an in-game update notification when the owner explicitly asks. Even then, **ask for their okay first**.
2. **Do not alter the Celestial chest or Graveyard chest opening animations** unless asked.
3. Deliver **both** `type-warriors.html` and `type-warriors-act6-TEST.html` (identical), plus a few screenshots, with a short, honest summary of what changed and anything not done.
4. The owner gives you creative authority to polish and improve. Keep the existing art style, keep every menu reachable quickly, and keep things functional and intuitive.

---

## 7. Recent work (latest first)

- **Moonlit Fishing v2 (`90h_fish_rods.js`, `90i_fish_hub.js`, `90j_fish_hub_style.js`, plus edits in `90a`/`90d`/`90e`/`90f`/`91`; backups `*.v1bak`):**
  - **Flow:** `fishing()` now opens the landing menu `fsHub()`.
    - The landing menu is the living pond backdrop drawn by `fsScene` with `V.noHero`, a title, tonight's moon card, Go Fishing (Space) and four tiles: Journal, Rod Workshop, Creel, Stats.
    - Go Fishing calls `fsPond()`, the original fishing screen. Back from the pond (`fsLeave`) returns to the landing menu; Esc there goes home.
  - **Angler's Journal `fsJournal(id)`:** a leather book. The left page is a 6×4 index with rarity bookmarks; the right page is the entry (portrait, lore, size ruler with the record and the giant zone, field notes). Arrow keys and the corner buttons turn the page (`.fsjflip`, a rotateY animation).
  - **Rod Workshop `fsWorkshop()`:** the rod drawn large on a bench, the 5 tier models, upgrade cards and rod looks.
  - **Rod models:** `fsRod(g,hx,hy,a,bend,len,t,skin,tier)` now draws 5 models (`fsTier()` from total level: 0/3/6/10/15). Rod looks tint the model. `FSTIERN` holds the names.
  - **Animations (`90e`):**
    - Cast: wind-up, whip and tip trail (`FS.trail`), the bobber flight (`FS.fly`) and a damped landing bob.
    - Bite: a yank and rod snap (`FS.biteT`).
    - Reeling: the line vibrates (`fsLine` `vib`), droplets run along the line, and the fish breaches between words (`FS.breach`).
    - Catch: water trail, a size stamp and the hero pulling back.
    - Escape: the line snaps (`FS.snap`).
  - **Ease of play:**
    - A how-to guide on the first visit (`P.fish.tut`), rotating tips under Cast, a next-letter caret and the prompt "Watch the bobber".
    - Esc twice to leave mid-fight.
    - A smarter default Keep: rare+, new, record, giant, or needed for a rod look.
    - Auto-sell (`P.fish.auto`), set from the catch preview or the Creel tab.
  - **Economy (owner chose "lower"):**
    - Simulated gold/min: about 80–96 with a basic rod, 97–112 mid-game and 123–144 maxed. Combat is about 150–200.
    - Upgrade total is about 29k; the max luck multiplier is ×1.5.
  - **Finishers v2 (`91`):**
    - A one-colour hero silhouette `pfxSil` for golden knight afterimages and violet rogue shadow clones.
    - Knight: ground cracks and a light pillar. Archer: a leaf vortex, a sky-high volley and target runes. Mage: a ground rune circle, lightning and a rune blast. Rogue: smoke puffs.
- **Moonlit Fishing (new mode; modules `90a`–`90g`, after `89y6`):**
  - **Where it lives:** a NEW card on the home screen (`fsHomeCard`, wraps `title`), the **F** key on the home screen, and Starfall Rift's spot in Choose a mode (`#dma`). Warden's Arena moved to a row under the cards (`#dmwa`). `fishing()` opens the pond; Esc / Back calls `fsLeave` (an undecided catch is kept or sold, never lost). `S.mode='fish'` while fishing.
  - **Data and economy (`90a_fish_data.js`):**
    - `FISH` has 24 species: 10 Common, 7 Uncommon, 4 Rare, 3 Legendary. `FSR` holds per-rarity odds, stages (Rare 2, Legendary 3), line hearts (Legendary 2, so one retry) and time per letter.
    - `fsRoll`, `fsValue` (size factor; giants ×2), `fsTime` (rarer means less time per letter; Line +8%/level), `fsWait`.
    - Rod upgrades `FSUP` (Line / Lure / Hook, 5 levels each, about 42k gold total). Rod looks `FSKIN` are crafted from kept fish. `fsMoon()` sets a daily moon phase and featured fish.
    - Save: `P.fish` = `{b: bestiary, cr: creel (cap 30), up, sk, skin, s: stats}`.
  - **Balance:** `../fish/sim/sim.js` loads the real data module and models typists by WPM.
    - Base rod: about 125–155 gold/min, below combat (about 200).
    - Max rod: about 240–310 gold/min.
    - About 1–2.7 Legendaries per hour; the full bestiary takes 2–4 h.
    - 20 WPM players need Line upgrades for Rare and Legendary fish.
  - **Art:** `90b_fish_art.js` is the kit (`fishDraw(g,id,o)`, `fishFit`, `fk*` helpers, silhouettes via `o.sil`). Fish are drawn in `90c_fish_art1.js` (Commons), `90c2_fish_art2.js` (mixed) and `90c3_fish_art3.js` (Rare/Legendary). Brief: `../fish/BRIEF.md`. Contact sheet: `cd ../fish && python3 render.py OUT.png ART.js[,ART2.js] [ids]`.
  - **Scene (`90d`):** one cached still layer (`FSBG`) plus live water shimmer, ripples, lotus, lanterns, reeds, fish shadows, willows and fireflies. The hero comes from `drawHero` with `wp:null` and a rod drawn from the hand (`fsRod`, `fsBobber`, `fsLine`).
  - **Game (`90e`):**
    - State machine `FS.st`: idle, cast, wait, reel/stage, show, reveal (or escape).
    - Catch spectacles scale by rarity in `fsShowFx`. Legendary adds a darkened sky, a pillar of light, aurora ribbons, god rays and gold rain, and can be skipped.
    - Keys go through a capture-phase `fsKeyDown`; touch keyboards use `beforeinput` on `inp`.
  - **UI (`90f`) and styles (`90g`):** side panel tabs Bestiary / Creel / Rod / Stats, the Catch preview with Sell/Keep (Space takes the default), and a fish detail modal.
  - **Tests:** `t_fishing.py`. Probes: `../fish/play.py HTML OUT [c u r l]` screenshots every phase.
- **Hero path finishers and signature weapons (`91_path_fx.js`, `91b_sig_weapons.js`):**
  - **Finishers:** Knight Final Verdict (leap and golden crescent slam), Archer Verdant Volley, Mage Arcane Beam, Rogue Shadow Flurry.
    - They play on Fury (smaller version) and on a boss finished with Space (big version, in the existing slow motion, with its name).
    - Finishing within 2 s of the boss being beaten gives a "Swift finish" bonus of 40 + tier×20 gold.
    - Hooks: wraps of `kill`, `fury`, `update` (remembers when the boss became beatable), `drawHeroGame` (moves the hero for the leap/blink) and `drawFxList` (draws the effects layer). Reduced motion turns off shake and movement.
  - **Signature weapons** (`SIGW`, `hw:1` keeps them out of crates and the shop): Dawnbreaker, Verdant Tempest, Astral Conduit, Nightwhisper.
    - Art is in `WNEW.sig_*`.
    - A Forge card sits at the top of the path's Armory list (`sigCard`, 15,000 gold). The weapon is also forged free after 3 boss finishers with that path (`P.sigf`).
  - **Tests:** `t_finishers.py`. Probe: `../fish/hero.py`.
- **Hand: no stacking glitch on fast sweeps; motion survives re-renders (`89y4_wc_hand.js`, backup `.bak3`):**
  - **Stacking:** the sink-on-top class `.wchz` is gone. A card you move off drops straight back to its own place in the stack (z-index = hand index), so only the hovered card (z 50) is ever out of order. Before, on a fast sweep to the left, each passed card stayed on top of its right-hand neighbour for 200 ms and then popped under it, so card edges seemed to glitch through the cards covering them.
  - **Re-render mid-motion:** `wcRenderHand` replaces every card element. The wrapper now records each card's current transform while it is still moving, and the progress of its draw-in and sheen animations (`WCH_CARRY`). The new card carries on from there instead of snapping.
  - **Reflow class:** `.wchfl` (springy FLIP glide) is now set per card, only on cards whose slot changed, and is removed when that card's hover changes. Hovering right after a sort or play keeps the normal quick timing.
  - **Probes (`../wv/`):**
    - `zprobe.py HTML` counts frames where two neighbouring resting cards are stacked out of hand order (old build: 531, now 0).
    - `jprobe.py HTML` finds frame-to-frame snaps when re-rendering during a sweep, a draw-in or a sort.
    - `lstrip.py HTML TAG` saves screenshots during a leftward sweep.
- **Hand: smooth fast sweeps, unplayable cards stay still (`89y4_wc_hand.js`, backups `.bak1`, `.bak2`):**
  - **Hover easing:** hover now uses a quick ease with no overshoot (the springy ease is kept for reflows).
  - **Sweeps:** while the pointer sweeps, only the card under it moves. Neighbours part and the sheen/tick play only after the pointer rests `WCHL_SETTLE` (110 ms) on one card.
  - **Unplayable cards (`.no`, your turn only):** they never lift, raise or lose their dark veil when hovered (CSS `.no.hv`, `wchS`, `wchUp`).
  - **Z-order:** (superseded: `.wchz` was removed in the entry above.)
  - **Hit-test:** `wchPick`'s hysteresis margin applies only to a raised card, so a flat card can't claim a strip its neighbour covers.
  - **Probe:** `../wv/sweep.py HTML`. Before: up to 2 cards moving at once and 19–42 bounces per sweep. After: 1 card and about 1–6.
- **Wildcard visual overhaul (five new modules after `89x`, in this order):**
  - **`89y0_wc_bkcore.js` (card-back pipeline, designer kit, vault showcase):**
    - Each back is a full standalone SVG document (`WCBKX[key]`). It is drawn once into a WebP bitmap in idle time (never while a table is on screen).
    - `wcBack(k)` returns a small `<svg class="wcbx">` wrapper holding that image, so heavy detail costs nothing per card.
    - The kit `WB` holds the frames, filigree, vector Pirata One lettering (`WB.word`; an image cannot use web fonts), guilloche, gems, rivets, damask and so on. Read the header before drawing a back, and run `WB.check(key)` on it.
    - The vault preview tilts under the pointer and has a light sweep; tiles have rarity rims.
    - It also holds the redrawn Lounge Velvet.
  - **`89y1_wc_backs.js`:** the other 14 backs, redrawn with far more detail and each keeping its theme.
    - The six Ranked sleeves share `BX.sleeve` (rank metal frame, element gems in the corners, WILDCARD plaques, rank emblem).
    - Each document is 19–52 kB.
  - **`89y4_wc_hand.js` (hand hover flicker fix and polish):**
    - Hand cards no longer take pointer events. The hovered card is picked from the cards' resting slots, with hysteresis, and marked `.hv`.
    - Because the hovered card no longer moves out from under the pointer, the hover can't flip back and forth.
    - The hand fans on an arc, neighbours part, and playable cards glow. Hands of more than 12 cards compress.
    - Use `.hv`, `wcHandLay` or `el.click()`; `elementFromPoint` never returns a hand card.
  - **`89y5_wc_table.js` (premium table):**
    - Felt texture, a leather rail with stitching and brass, the printed crest and lettering, a spotlight and vignette.
    - Variants: per-table leather colours for solo tables, blue for rooms, midnight and gold for Ranked (`rktbl`).
    - Brass-studded nameplates, rail medallions, a direction ring that rests clear of the piles, and a crest in the Menu.
  - **`89y6_wc_anim.js` (animations):** reassigns `wcFly`, `wcBurst`, `wcPop`, `wcShake`, `wcDeal2`, `wcWild2`, `wcRev2`, `wcSkip2` and wraps `wcAnim`.
    - Riffle shuffle and dealt arcs, flights with light trails, landing squash with element particles, a Stun lightning bolt, the wild colour wheel, a +2/+4 slam, stamp banners, and a win spotlight with confetti and coins.
    - Transform/opacity only; respects `wcRM()`.
  - **Tools:**
    - `../wv/bldx.sh OUT.html extra.js...` builds a separate copy without touching `out.html`.
    - `../wv/wcshots.py HTML OUTDIR [backs table hover anim menus perf]` takes screenshots and runs the hover-flicker probe (0 switches now; the bug measured 35) and a frame-time probe at 4x CPU throttle (within noise of the old build).
  - Built by a multi-agent workflow with critic reviews (table, framework, hand and animations); the 14 backs were drawn and checked directly.
- **Ranked: 1,000 points to Legend (was 500), back-loaded:** each rank has its own bar size, `WCRN[].need` = 110 (Bronze), 150, 200, 250, 290 (Diamond); helper `rkNeed(r)` (`89s`). `rkApply` ranks up at the need, `rkSt` clamps the bar below it, and every screen shows "/ need" (`rkPct` for bar widths in `89u`: hub, results animation, road, home pill, leaderboard). Each history entry stores its bar size `q`.
  - Leaderboard (`89w`): entries are now `v:2` with 5-number matches `[t,place,points,rank,q]`; the check accepts `q` = that rank's need, or the old 100 for season-1 matches before `RKLBQCUT` (1 Nov 2026), so players who climbed under the old bars stay on the board. The whole-season replay uses each match's own `q`.
- **Reset save fixed (`60_ui.js`, backup `.v12bak`):** the Profile "Reset save" button set `P=fresh()` directly, which skipped the pet and Trick-or-Treat setup that `load()` wrappers add, so the title screen threw (`petEggsN`). It now calls `load({})`. Also: the code-reward glow (`86b_codes.js`) could build an invalid colour on its first frame (clamped), and the countdown hides at once on a move (`wcApply` wrapper in `89x`).
- **Reset profile leaves the board (`89w`):** a `save` wrapper (`rkLbDevCheck`) remembers the key of the save this device last wrote (`localStorage.twlbDev`). When the save changes to another key or none (reset, import, restore), the old key signs `{hide:1,gone:1}` (not counted as hidden). Pending ones wait in `localStorage.twlbRetire` (retried at start, on `rkLbLoad`, when back online) and stay listed as done for 60 days; a retired save that is restored gets `lbPend` and posts again.
  - Resets made before this fix: `rkLbScanErased` (at start) reads the "Before erase" backups (`sgList`/`sgGet(BKP+id)`) and retires any erased save that had posted, unless it is the save in use.
- **Last 5 seconds countdown (`89x_time_alert.js`, after `89w`):** one driver (`taStep`, every 100 ms) asks `taSource()` which timed game is running and draws `#tacd` on the stage: a gold 5-4-3-2-1 badge that turns red at 3, pops each second and ticks (`beep`).
  - Sources: Wildcard turn timers, only on your own turn (the host takes the start time from a `wcStep` wrapper, `TCD.wc`; a guest counts from when its turn or phase began); it replaces Wildcard's old 3-2-1 `tick` unless the setting is Off. Casino Quiz clue (read from `#qtn`; no extra tick because the Quiz already beeps). Trick-or-Treat doorsteps (`TRT.run.remaining`, hidden during walk, greet and Moonfreeze). Timed Practice (`S.prac.gn - S.pel`) and Starfall Rift (`S.time`), at the top centre. Paused games hide it.
  - Settings › Effects › "Last 5 seconds countdown": On / Silent / Off (`ST.tacd`).
  - Also fixed: "Fit to screen on websites" (`88n`) showed on every Settings tab; it is now added before the tabs are built, next to Fullscreen (backup `.bak4`).
  - Test: `t_time_alert.py`.
- **Doubled text in ranked matches fixed:** the ranked table was tagged with the class `rkt`, which is also the results title (`<h1 class="rkt">`, brown 4px text shadow, absolute position). Every text on the table inherited that shadow and the table was shifted. The table class is now `rktbl` (`89s_wc_ranked.js`, `89u_wc_rkui.js`; backups `.bak2`). `t_ranked.py` checks for it. Keep class names unique: `rkt` is the title only.
- **Ranked season leaderboard (`89w_wc_board.js`, after `89v`), on public Nostr relays (no Firebase, no server of our own):**
  - **Storage:** after each ranked match the game signs one replaceable event per player per season (kind 30078, tags `d`/`t` = `twwc-lb-s<season>`) and sends it to the `nostr:` relays in `WCRELAYS`. Relays keep only the newest one per key. Time stamps always increase (`P.rk.lbAt`), so the newest entry always wins.
  - **Identity:** a key made once per save (`P.rk.nsk`/`npk`). Shown as the player name plus `#` and the first 4 characters of the key.
  - **Save fields:** `sm`/`sw` (season matches and wins), `r0` (the season's starting rank), `lbHide`, `lbLast` (the last content sent), `lbPend` (waiting to send), `lbSent`, `lbAt`, `lbc` (the last board, shown when offline). A new season resets `sm`, `sw` and `lbLast`, and sets `r0`.
  - **Reading:** `rkLbLoad(force)` (2-minute cache) queries all relays (`rkRelayQueryAll` pages back with `until` when a relay caps a reply), keeps the newest event per key, checks it with `rkLbCheck`, verifies BIP-340 signatures (`rkEvOk`/`rkSchnorrOk`) for the top 100 and for any newer event that would hide or remove an entry (a forged newer event falls back to the player's previous one), then ranks with `rkLbSort` (score, wins, fewer matches, earlier). The player's own row and place always come from their own save.
  - **Anti-cheat (`rkLbCheck`):** the right season, tag and time window; sane values; enough matches for the rank and bar (each rank needs its full 100 at that rank's 1st-place points); enough time for the wins; the last 10 matches listed with points from `WCRN`, wins at least `RKLBGAP` (20) seconds apart, and ranks that only go up after a gain; when the whole season fits in 10 matches it is replayed and must match exactly. Names: control and invisible characters stripped, 14 characters, a word filter (`RKBAD`), and always escaped. This blocks impossible scores and forgeries, not a careful cheater who edits their own game to post a plausible score.
  - **Screens:** `rkBoard()` (your place, insignia, "Show me on the leaderboard" On/Off, top 100 with your row highlighted and, if you are further down, a gap and your row; loading, offline-with-saved-copy and no-connection states; Refresh with a 4-second cooldown). The Ranked hub has a top-3 preview with "View all" in the middle panel; at Legend the right panel shows the players around you (`rkStandings` replaced).
  - **Tests:** `t_leaderboard.py` (needs `PYTHONPATH=../../pylib`). It starts three local relays from `t_nostr_relay.py` (now stores events like public relays; `--noverify` acts as a dishonest relay, `--slow MS`), uses `t_nostr_tools.py` (an independent Python BIP-340 signer and a ranked-season simulator) and `t_nostr_relay_math.py`. It covers BIP-340 vectors, JS↔Python signatures, every cheat rule, forged, tampered and impossible entries, XSS names, two players, replacement, hide/show, offline queue and retry, a new season, 650 players with paging, the hub preview, the Legend panel, the push throttle and one real match played to the end.
  - Not tested against the live public relays: the sandbox blocks them. Some public relays may refuse kind 30078 or rate-limit; the board works with any that answer.
- **Ranked polish:** the Wildcard home's Ranked button sits above the top bar (`.wchbar` had covered most of it), is larger, says "Play Ranked" and carries a gold trophy symbol (`.rktro`). With Settings › Text visibility › Clear on, the dark edges it adds no longer apply on the Ranked screens (they looked like doubled text). The rewards road shows "You · x / 100" above the current insignia instead of on the line.
- **Fit to the screen when embedded (`88n_fit_screen.js`, wraps `applyLayout`):** in an iframe (the owner's Wix page on a Chromebook) an invisible full-height marker (`#fitmark`) is measured with an IntersectionObserver against the browser window (works across origins), re-measured every 0.7 s. When part of the box is off screen, the stage fits the band of the box that is visible (`FIT.bt`/`FIT.bh`), wherever the page is scrolled (unless most of it is scrolled away); re-measured on resize and every 0.6 s, so switching the Chromebook between fullscreen and normal is followed both ways. Without IntersectionObserver it falls back to a screen-size estimate. Inside an iframe the mouse wheel no longer scrolls the website behind the game (wheel `preventDefault` unless a game list can scroll; `#ov` has `overscroll-behavior:contain`). Settings › Display › "Fit to screen on websites" (`ST.fitscr`) turns both off. The owner's site uses Wix's newest editor (with Aria), which has no Dev Mode, so the Big Screen lightbox plan cannot be set up there. Test: `t_fit_screen.py` (resizes the window to mimic fullscreen, checks wheel scrolling).
- **Fullscreen on Wix: Big Screen instead of a new tab (`88m_fs_bigscreen.js`, overrides `fsFallback` from `50_game.js`):** inside an iframe the game flushes the save, posts `{type:'type-warriors-fullscreen'}` to the parent and waits 400 ms for `{type:'type-warriors-fullscreen-ack'}` from `window.parent` only. Ack: no message (a 2-second note mid-run; with `action:'close'` the note says it is going back), and this copy goes quiet (`fsSleep`: sound suspended, typing run paused; the stale-save question is skipped while hidden and the first tap after returning reloads the newest save). No ack: the device-fullscreen tip, no new-tab button. Top-level pages keep the old message with "Open in new tab". The owner's Wix setup (lightbox `GameBig`, embeds `#htmlGame`/`#htmlBig`, Velo `onMessage` code) is in the "Type Warriors Fullscreen Workaround" plan. Test: `t_fs_bigscreen.py` (serves a mock parent page on a local port).
- **Wildcard Ranked (`89s`–`89v`), built from the owner's "Ranked ONE" plan, placed inside Wildcard (the owner's choice), unlocked from the start, online through the relays (no Firebase):**
  - **`89s_wc_ranked.js` (rules and data):** `WCRN` (six ranks: points per place, coins, sleeve, emote, AI description), `WCREMO`/`WCREMK` (five moment emotes), seasons (`WCRSEA`: 6 weeks from 12 Oct 2026, `rkSeason()`), save data `P.rk` via `rkSt()` (`r`, `bar`, `lp` Legend points, `season`, `peak`, `n`, `w`, `paid` {season: [ranks paid]}, `em` owned emotes, `hist`, `title`, `met`, `note`, `live`). `rkApply(place, why)` moves the bar (floor 0, rank up at 100 then 0, never drops in a season; Legend counts `lp`), `rkReward(r)` pays sleeve/emote once ever and coins once per season. A new season (checked in `rkSt`) drops 2 ranks and resets the bar. `R.live` marks a match in progress; a match left behind (page closed) counts as 4th (`rkDodge`).
    - Placing: `wcRank` now also breaks ties by whoever played last (`p.lp`, set in a `wcPlay` wrapper).
    - AI ladder: bots with `diff:'r0'..'r4'` use `wcBotRk` (Bronze random; Silver numbers first, saves wilds, most-held colour; Gold aims actions at the leader and always calls; Platinum remembers colours a player could not match, forgotten once they play it; Diamond/Legend also counts played cards, holds +4, dumps high-point cards near the end). `WCB.r0..r4` set forget/catch/reaction. Measured in 1,500-game simulations: Bronze→Silver is a big step (1.70 average place score vs three Bronze AI, 1.5 = even), later steps are small (about 1.5–1.57): the game has a lot of luck. Ranked AI think 0.8–2 s.
    - Matches: `rkStart()` (offline, 3 AI at your rank, 15-second turns, no stake, mode `solo` with `WX.tbl='rk'`, `WX.rk` set). Timeouts: a move not sent by the player (`wcSend` sets `WX.rkUser`) counts; three in a row → `rkAfk` (4th). Leaving through the menu → 4th. `wcReset` clears all ranked state so casual games stay casual.
  - **`89t_wc_rkart.js` (art):** `rkInsig(r,size,{label,anim})` builds each insignia from a card fan (2–6 cards, a wheel at Legend), wings (Platinum frost, Diamond crystal, Legend gold), medallion and emblem. Sleeves are card backs `rkcopper`, `rkmoon`, `rksun`, `rkglacier`, `rkprism`, `rkcelest` in `WCBK` with a new rarity "Ranked" (`RKRAR`), drawn by `rkSleeve(i)` through a `wcBackArt` wrapper; Celestial's rays and orbiting cards only move in big views (`.rkbig`, vault preview, ceremony). `rkEmo(key,av,cls)` + `rkEmoPaint(root)`: comic-burst emote badges with the player's own hero (crew portrait for AI).
  - **`89u_wc_rkui.js` (screens and emotes):** `rkHub()`, `rkResults(res,rank,o)` (the concept-6 result screen with the bar filling), `rkUp(up,done)` (rank-up ceremony), `rkRoad()` (rank-up rewards road). The Wildcard home has a Ranked pill next to Casino (`#rkhome`). The vault has two shelves (Lounge / Ranked sleeves). Emotes on every Wildcard table: the Emote button opens `rkPick()` (8 free emotes + 5 ranked, locked ones show their rank); `rkSend` (3-second cooldown) → `wcEmote`; ranked emotes travel as text `@key` and `wcBubble` turns them into bursts (`rkShow`); moments are detected from table events in a `wcAnim` wrapper (`rkMoment`): the matching emote glows on the button for 4 s; AI at that rank sometimes sends theirs. Tap a seat's name to mute it (`WX.mute`, also mutes taunts).
  - **`89v_wc_rkmm.js` (online):** `rkFind()` searches on the relay channel "RANKED" (`{t:'seek'}` every 1.5 s; own rank for 8 s, then ±1). The smallest compatible id hosts: picks a room code, announces `{t:'room'}`, opens a private room (`WCL.rk`) under a matchmaking overlay; guests join by code and auto-ready. The host deals when everyone invited is ready (or after 16 s) with AI in empty seats (`rkNetStart`, mode `net`, `{t:'rk'}` sent right after `start`). At the end the host sends `{t:'rkfin', rank, hands}`; each player applies their own points. Host-counted timeouts send `{t:'rkafk'}`. The host leaving voids the match for guests. Alone for 15 s → AI match. No server, so points are not protected against cheating.
  - **Tests:** `t_ranked.py` (the plan's checklist: old saves, points table, bar floor, rank up once, rewards once, coins per season, season drop, Legend, tie-breaks, AI strength, a full match, three timeouts, leaving, closing the page, emote picker/cooldown/moment/mute, other screen sizes) and `t_ranked_net.py` (two browsers matched through the local MQTT broker, a full online ranked match with identical standings on both, a lone seeker getting AI at 15 s).
  - Not done: no Updates-tab notice (the owner is asked first). The Legend standings were local at first; the season leaderboard (`89w`) replaced them.
- **Playing together on school networks (`89q_wc_nostr.js`, `89r_wc_school.js`, edits in `89k`, small addition in `88l`):**
  - **Why it failed at school:** the room-code relays used ports 8084/8884/8081, which school firewalls block (only 443 gets out). Both ways in then needed a direct WebRTC link, which school networks stop (Wi-Fi client isolation, blocked UDP/STUN, blocked mDNS), so the offline QR method could not work there either.
  - **Relays:** `WCRELAYS` now lists MQTT brokers on 443 (`mqtt.eclipseprojects.io`, `public.cloud.shiftr.io` with `public:public`, credentials parsed from the URL into the MQTT CONNECT), four Nostr relays (`nostr:wss://…`, all on 443), then the old three. Relays that worked and then dropped are reconnected with a growing pause. `wcRelaySend` captures the key and connections at call time and `wcRelayClose` waits 700 ms before closing sockets, so a last message still goes out. `wcRelayOk()` no longer requires WebRTC.
  - **Nostr (`89q`):** `wcNostr(url, topics, onMsg, onState)` has the same shape as `wcMq`. Messages are ephemeral events (kind 25051, tag `t` = topic, content = base64 AES-GCM ciphertext), signed with BIP-340 Schnorr (`wcSchnorr`, BigInt secp256k1, about 5 ms per signature) using a throwaway key per page. One signed event per message is shared by all Nostr relays (`WCNEV`).
  - **Relay fallback (`89r`):** the guest tries a direct link first; if its data channel has not opened `WCFB_MS` (5 s) after answering, or the connection fails, or the browser has no WebRTC, both sides switch to `wcVC`, a data-channel look-alike over the relay (`{t:'d', gid, n, x}`, numbered for in-order, once-only delivery; pings throttled to every 8 s; 45 s idle timeout; `{"t":"bye"}` on leaving). New relay messages: `viarelay`, `relayok`, knock flag `relay:1`. A device that needed the relay remembers it for 7 days (`localStorage.twwcRelay`) and goes straight to it next time (joins in about 2 s instead of about 11).
  - **QR invites** carry `WCR~CODE` while the room is online (scan = join by code, nothing to scan back). The old offline invite is still offered when there is no internet.
  - **Connection check** (`wcNetCheck`, linked from the home join card, the join screens and the room): tests every relay (connect plus a message round trip), direct links (two connections inside the page), the camera and how the page was opened, then gives a summary and a copyable report.
  - The "Running slowly?" offer now waits until you are outside the Casino (`88l`), since Performance mode no longer changes the Casino.
  - **Tests:** `t_wc_school.py` (needs the local MQTT broker and `t_nostr_relay.py`, a local Nostr relay that verifies every signature with its own Python BIP-340 code): a full staked game over Nostr with direct links blocked, a guest without WebRTC, relay reconnection, a normal network staying direct, the QR content, the 7-day memory and the connection check. The public relays themselves could not be reached from the build sandbox, so they have not been tested live.
- **Performance mode leaves the Casino alone (`88l_perf_casino.js`, small edit in `88k`):**
  - `PFSET()` is the saved choice (`ST.perf`); `PFM()` is the mode in effect and returns `'high'` whenever `pfCas()` is true, meaning `#ov` has the `casbg` class (the casino lobby, every casino game and all Wildcard screens).
  - So inside the Casino, Balanced and Performance change nothing: full canvas resolution, full-rate `LIVE` canvases, canvas `shadowBlur`, looping CSS animations, `backdrop-filter`, and Wildcard's full-length deal and effects (`wcRM()` only follows `prefers-reduced-motion` there).
  - `pfCasSync()` re-runs `applyLayout()` (which calls `pfApply`) the moment you enter or leave; it is hooked into `show`, `hide` and `loop`.
  - Settings shows the saved choice and notes that the Casino keeps its full animations; the "running slowly" offer also reads `PFSET()`.
  - Test: `t_perf_casino.py`.
- **Wildcard polish round (modules `89n`–`89p`, plus rewrites of `89b` and parts of `89d`/`89m`):**
  - **Cards (`89b_wc_cards.js`, rewritten):** brighter three-stop element palettes (`WCK`), white outer border, sunburst rays and element motif, a large faint element glyph, gloss sweep, gold diamond with cream centre, value or action icon, a ribbon pill for actions, and corner indexes with element coins. The four-element wild and +4 Hex keep their concepts.
  - **Card backs:** nine backs with rarities (`WCRAR`: Common, Rare, Epic, Legendary, Secret; colours `WCRARC`). `WCBK[k]` has `n` (name), `r` (rarity), `how` (unlock hint), `fl` (flavour text) and `need(W)` returning `[have, goal]` for progress bars. Unlocks live in `wcRecord`: Neon Arcade (10 games), Hallow's Eve, Emerald Jackpot (10 wins), Royal Gold, Astral, Dragonfire (5-win streak), Pastel Wyrm (win a game the rare guest sat at, `W.pbeat`), Elder Rune (secret, code WILDRUNE82). `W.seen` drives the NEW badges and the red dot on the home screen's Card backs button.
  - **Your Record and the Card Back Vault (`89o_wc_record.js`):** `wcStats()` is a full record screen (profile and rank via `WCRK`/`wcRank2`, win-rate ring, rank progress, highlight tiles, gold-per-game sparkline, recent games labelled 1st–4th via `WCPL`, wins by table). "Biggest pot" was removed at the owner's request. `wcVault(sel)` is a separate menu (home header › Card backs, and from the results unlock button): a tilting preview, rarity, flavour text, progress and Equip.
  - **Rare guest (`89n_wc_rare.js`):** a dragon in a pink (Baron Bubblegum) or baby-blue (Duke Azurine) suit, species `pdragon`, with an aura, wings, a tail, sparkles, gold horns and heart shades. `wcCrewGen(n, rnd, {rare: p})` swaps one regular for the guest with probability `p`: 10% per solo game or room, 25% on the home screen. Seats show "★ RARE GUEST".
  - **Effects (`89p_wc_fx2.js`):** `wcDeal2` (deck drop, riffle and bridge, round-robin deal straight into your hand slots face down, a flip wave, the first card to the pile), `wcWild2` (element orbs orbit and the chosen one slams into the pile), `wcRev2` (Turnabout arrow sweep and seat hops), `wcSkip2` (Stun bolt and a frozen seat). They wrap `wcAnim` for `deal`, `rev` and `skip`. All use WAAPI transforms and opacity only.
  - **Home:** header no longer overlaps the sign at 1280 wide; new add-player seat button (`.wcadd2`, a soft ping and a rotating dashed ring); a streak chip after 2+ wins in a row; card fan hover plays the `shimmer` chime.
  - **Tests:** `t_wildcard.py` now also checks the record screen, the vault, equipping a back, unlocks and the rare-guest rate (about 10%).
- **Update 8.2: Wildcard, the Dragon Lounge card game (modules `89a`–`89m`, after `88k_access_perf.js`):**
  - **Where it lives:** Casino → Cards tab (first tile, red NEW corner ribbon; the ribbon moved off Nebula Scratch) and the Special tab feature card (the Wildcard / Nebula / Tower switch defaults to Wildcard). `gameOpen('wc')` opens `wcHome()`.
  - **Casino grid:** with 13+ games the grid switches to 7 columns (`:has(>.gdt:nth-child(13))`), and from 15 games it scrolls, so no tile (Quiz Showdown last time) is ever cut off again.
  - **Modules:**
    - `89a_wc_core.js`: the pure rules engine. `wcNew` builds the game `G`; actions `wcPlay`, `wcDrawAct`, `wcPass`, `wcCall` (WILD!), `wcCatch`, all via `wcDo(G, seat, action)`. Every change is logged to `G.ev`; the table replays events as animations. Bots: `wcBot` (all lounge regulars play at the `m` level of `WCB`). Economy: `WCT` (four tables keyed `c50`, `c250`, `c1k`, `c2k5`), `WCTK`, `WCFEE`, `WCE`, `wcPayout`.
    - `89b_wc_cards.js`: SVG card art (`wcSVG`, cached): element gradients with element motifs (flames, waves, leaves, bolts), a gold inner frame with corner gems, a gold-rimmed shield, action ribbons (STUN, TURN, CURSE, WILD, HEX), four-element wilds. Card backs `WCBK` and `wcBack`.
    - `89c_wc_table.js`: the table. `WX` is the state. `wcPump` plays events through `wcAnim`; `wcStep` schedules the regulars, catch windows, the same-screen curtain and turn timers. Effects: `wcFly`, `wcBurst` (element-glyph particles), `wcWave` (wild colour sweep), `wcShake`, `wcFlash`, riffle shuffle. The status pill above the hand says whose turn it is and what to play. `wcMenu` is the in-game menu (Esc opens it). It also holds back the "Running slowly?" offer while a card game is on screen.
    - `89d_wc_menus.js`: home (`wcHome`: neon marquee, live regulars, chip table picker, room-code boxes), rules, save data in `P.wc` via `wcSt()` (the stats screen now lives in `89o`), solo start, `wcRecord`, results podium, the private room (`WCL`, `wcLobbyRender`, seat menu `wcSeatMenu`, chip buy-ins, segmented timer and hand size, house-rule tiles) and the join screens (`wcJoinView(state)`).
    - `89e_wc_net.js`: playing with friends on other devices (see below). Host is authoritative: guests get `wcView` (other hands masked) and send actions by card id.
    - `89f_wc_casino.js`: casino listing, `wcFeat`, the Special switch.
    - `89g_wc_qr.js`: QR encoder (`wcQR`). `89g9_wc82img.js`: the 8.2 collage. `89h_update82.js`: the 8.2 Updates entry (no News card, by the owner's choice) and the code **WILDRUNE82** (2,500 coins plus the Elder Rune card back, once per save), hidden at the end of the notes.
    - `89i_wc_crew.js`: the lounge regulars — monsters in suits drawn on canvas (dragon, goblin, orc, skeleton, lizard, wolf, frog, octopus) with random suits, ties, hats, eyewear and held items. `wcCrewGen(n)` makes a lineup with random names; `wcCrewDraw(g, A, t)` animates breathing, blinking and a flipping chip. `wcPortrait`/`wcFigure` are wrapped for `av.t==='crew'`.
    - `89j_wc_audio.js`: "Neon Wildcard", a synthesised arcade lounge theme (16 bars, A minor, the casino's 116 bpm) with menu, game and tense variations, routed through the casino music busses (so the Music setting applies), plus `wcFx(name)` sound effects through the sound-effects volume.
    - `89k_wc_relay.js`: room codes over public MQTT brokers on secure WebSockets (`WCRELAYS`), messages AES-GCM encrypted with a key from the room code. `89l_wc_scan.js`: camera scanning (`wcScan`) with a built-in QR decoder (`wcQRDecode`, Reed-Solomon corrected) for offline joining.
    - `89m_wc_style.js`: every Wildcard style.
  - **Playing with friends:**
    - *Room code (needs internet):* the host's room shows a 4-letter code. The guest types it on the home screen; the devices swap WebRTC details through the relay (several brokers at once, whichever answer), then play directly. STUN servers help devices on different networks; some strict networks still block direct play, and the join screen says so.
    - *Scan to join (no internet, same Wi-Fi):* the host taps Invite by QR, the guest scans it (Join a room › No internet? Scan to join), then the host scans the guest's reply QR. Paste and copy fallbacks exist for devices without a camera.
  - **Economy (3,000-game simulations, `sim2.js` style):** buy-ins 50 / 250 / 1,000 / 2,500 with a 12% house cut; the winner takes the pot less the cut, 2nd gets 40% of their buy-in back. Gold returned per gold staked: careless player 0.52, typical 0.98, sharp 1.12 (and a sharp player still wins only about 29% of games). 15 paid games a day (then practice), first win of the day +150, private rooms cut 10%, same-screen games are free.
  - **Tests:** `t_wildcard.py` (listing, payouts, the code, a staked solo game played by `t_wc_agent.js`, the in-game menu, forfeit, daily cap, stats, Esc), `t_wc_pp.py` (same screen), `t_wc_scan.py` (two browsers joined by scanning each other's QR through the real decoder), `t_wc_code.py` (two browsers joined by room code through a real MQTT broker; start one locally first, for example `pip install amqtt` and run its broker with a `ws` listener on `127.0.0.1:18083`).
- **Text visibility and Performance mode (`88k_access_perf.js`, Settings → Display):**
  - **Text visibility** (`ST.tvis`, Standard or Clear): `tvBuild()` reads every style rule once and writes stronger copies of the faint ones into `#tvcss`. Faded colours are brightened while vivid gold and rarity colours are kept, small text gets bolder, and light menu text gets a dark edge.
    - The copies are wrapped in `:where(body.tv)` so they never beat a more specific state rule such as a selected tab.
    - Note: weight and size are parsed from `font:` shorthands, because rules using `var(--ui)` report blank longhands.
  - **Performance mode** (`ST.perf`: `high`, `bal` or `low`). Profiling showed the canvas is fill-bound: the zone background is about 45% of a frame and the vignette about 15%.
    - Balanced: resolution at most 1×, the background is redrawn every 2nd frame (`PFBG` copies the freshly drawn background and replays it), and the vignette is pre-rendered.
    - Performance: resolution 0.75×, background every 4th frame, no decorative vignette, `runLive` at half rate, looping CSS animations paused (`pfAnims`), and a `shadowBlur` hook that exists only while Performance is on.
    - The background cache is bypassed while the screen shakes or a cutscene zooms.
    - In Quality mode the game offers Performance once after two 5-second windows under 20 fps outside gameplay (`ST.perfAsked`).
  - Tests: `t_access.py`.
- **Code NEWUPDATECOINS81 (`88j_code81.js`):**
  - A built-in code (in `CC_BUILTIN`, `max:0`) worth 1,500 coins plus a Runeshell egg.
  - Each save can redeem it once (`P.ccUsed`), and it's case-insensitive.
  - `ccGrant` and `ccPlay` are wrapped to add the egg and show it on the reward card.
  - The code is hidden at the end of the 8.1 notes in the Updates tab only (`.blsec`). The News card is unchanged.
  - Test: `t_code81.py`.
- **Update 8.1 notification (`88i_update81.js`), pushed with the owner's okay:**
  - Adds `u-8.1` to `UPDATES` and `n-8.1` (out) to `NEWS`, both titled "Companions & Loadouts".
  - Both carry a collage (`UPD81_IMG`, a 900px WebP data URL of about 102 KB, made from in-game screenshots).
  - `bellInner` is wrapped so Updates entries with `img` show it, as News does. Any `.blimg` opens full size on click (`updZoom`, Esc closes).
- **XP pacing (from another session, ported in):**
  - New `88h_xp_pacing.js`, plus small edits in `60_ui.js`, `70a_modes.js`, `73c_dc_game.js`, `84c_gy_mode.js`, `84i_beginner.js` and `85_astral.js` (backups `*.v11bak`).
  - The build matched the owner's `type-warriors_58.html` byte for byte before 8.1 was added.
- **Roster card flicker fix (`87j_pet_cardfix.js`, after `87i`):**
  - The bug: selecting a companion added an idle `LIVE` loop to its card but never removed the old one, re-clicking stacked more, and the hover greeting loop kept running after a click. Several loops drew different poses into one canvas, so the card glitched.
  - Also, the original `live()` takes the card's first canvas, which on a Mythic card is the backdrop.
  - The fix: `ptCardTidy()` runs after every click in the hall. It keeps exactly one idle loop on the selected card's `canvas[data-pc]`, returns other cards to a still frame, and keeps backdrop canvases on their own painter. `ptCardWake` stops as soon as its card is selected.
  - Test: `t_petclick.py`.
- **Mythic backdrop (`88g_mythic_bg.js`) and a tile fix:**
  - Every owned Mythic pet shown in a frame gets an animated cosmic backdrop on a canvas behind the art. Frames covered: Companion Hall roster cards and portrait, Loadout Locker cards, slots, picker and compare, the Armory pet slot, and egg pool lists.
  - The backdrop: a turning spiral nebula with stars, twinkles, a breathing glow, an upright halo, a gold magic circle under the feet, rising motes and a shooting star.
  - Palettes are per pet (`MYPAL`: yeti frost, sol sunfire, `_` default for any future Mythic). Sprites are cached in `MYIMG`.
  - A MutationObserver finds hosts (`MYHOST`) and adds the canvas to `LIVE` with `slow:3` (`slow:4` for small frames). Reduced motion shows a still frame.
  - Fix in `88f`: `.lotile` clips again, and canvases are absolutely positioned to the tile. Snap sparkles now live on the slot row, not inside the tile.
- **Loadout Locker polish (`88f_loadout_polish.js`, after `88e`):**
  - The right panel is now a slot editor. Click a slot, drop gear onto it, or press Enter on it to open the gear picker in the left panel. The picker has class or rarity filter chips, a "Sort:" dropdown in the Pets-tab style (saved in `P.lo.so`), and a "Best" badge.
  - Hovering or focusing an item previews it on the hero. A compare box shows overall strength (the Auto-Equip test run) and per-stat changes with green ▲ / red ▼.
  - Put an item in with the button, a double-click, Enter, or drag and drop. Clear a slot with × or Delete. Auto-fill best uses `autoPick` for the preset's class.
  - Slot snap animation with sparkles and a beep. Enter on the selected preset equips it. Esc closes the innermost layer (sort menu, then picker, then the page).
  - The Armory bar has a "Loadouts" button (`#arlo`).
  - Gotchas found:
    - The game's global `.em` class (Endless menu) leaked padding into empty slots, so they now use `lomt`.
    - HTML5 drag needs a `div` (Chromium won't drag a `<button>`) and `-webkit-user-drag:element` once `all:unset` is applied.
  - Test: `t_loadout_polish.py`.
- **Loadout Locker (`88e_loadouts.js`, Gear → Loadouts):**
  - Three named presets (default names Campaign, Endless, Gold Hunt) in `P.lo = {s:[{n,w,a,p,c}×3], sel, ask}`. Each stores weapon, armor, companion and the weapon's class.
  - The Gear sub-tab strip is now Armory · Loadouts · Skill Tree (`DKSUB.gr`, `DKG.lo`, and `DKGO.gr` remembers it). The page is detected by `class="lol"`.
  - Equip applies only owned, usable pieces: it checks `P.own`/`P.ownA`, `pathOpen` for the class and `petOwned`. Anything else is skipped, marked on the tile, and reported in a toast. Skill Tree ranks are never touched.
  - Save current loadout: overwriting a filled preset needs a second click. Rename is inline (pencil, Enter/Esc, 16 characters max). "Ask before replacing gear" (`P.lo.ask`) shows a confirm dialog listing each change.
  - Illustrated locker-room stage (cached background, torches, motes). It previews the hovered or selected preset; a swap sparkles and an equip plays a gold celebration. Keys 1–3 pick a preset.
  - Test: `t_loadouts.py`.
- **Source synced with the shipped HTML:** the changes that existed only in the delivered `type-warriors.html` now live in the source, and the build is byte-identical to it.
  - New `87i_pet_mythic.js` (after `87h`): Mythic companions Glacierhorn and Solmane, the Starforge egg (50,000 gold, `P.eggs.m`), the Starforge hatch cinematic, Mythic battle effects and the companion power hotkey.
  - New `88d_spnote.js` (after `88c`): `spNote()`, so the Skill Tree badge only appears when a point can actually be spent.
  - Small in-place edits (backups `*.v7bak`): `74_shell.js` and `88_dock.js` use `spNote()`; `86b_codes.js` adds the `BRAYDENSGIFT` code; `87a_pet_data.js` counts Mythic eggs; `87d_pet_game.js` draws the companion in front of the knight (`petDrawGame`).
- Tests need Python Playwright pinned to the installed browser (here `pip install playwright==1.56.0`).
- **Dock icons v2 (`88c_dockicons.js`):**
  - All six icons redrawn: crossed swords, knight's helm with plume, paw with a heart pad, rounded bar chart, coin pouch, three dots.
  - Each icon has a hover, focus and press animation that plays to the end.
  - Badges moved off the icon art, and the label no longer shifts on hover.
- **Pet and egg effects (`87h_pet_fx.js`):**
  - Descriptions for both eggs (`PEGGD`), on the stage and in an "About" card. Redrawn `PTICO` icons.
  - Pet stage: pop-in on select, signature-colour motes, petting with hearts and combos (every fifth pet plays the power animation), a "Tap to pet" hint, and a gold celebration on equip.
  - Roster: cards wake and greet on hover, and owned legendary cards get a gold shine.
  - Eggs: ready eggs rock, sparkle and pulse; tapping the egg gives a reaction; the hatch button gets a shine.
  - The hatch reveal shows collection progress and the next free egg.
- **Pets sort and Eggs declutter (`87g_pet_polish.js`):**
  - "Sort:" dropdown with Collection, Recommended, Rarity, Bond high/low, Name A–Z and Recently acquired, saved in `P.petSort`.
  - Rarity-bordered cards.
  - Eggs tab is now three columns: Your Eggs, the egg stage, and Hatchery (with Buy and "Earn one free").
- **Earlier:** Console Dock main-menu overhaul; bright region diorama; Manage pet / Manage gear buttons; Daily Challenge medallion that changes every day; smooth menu transitions; pet starter-screen fixes.
