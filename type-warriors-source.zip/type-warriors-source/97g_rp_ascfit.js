/* ===== RUNESTONE TOWER DEFENSE 9.9j: the Ascended Towers row fits its panel (97g, after 97f) =====
   The Wonderland side panel showed the Ascended Towers as one row of 52 px tiles; with ten towers it ran past the panel and off the
   stage. Now the tiles sit in a grid of five per row that always fills the panel's width (two rows for ten towers, a third would
   wrap the same way), and the tiles are a little smaller so the panel still clears the Armory bar. */
{const st=document.createElement('style');st.textContent=`.rpasc>div{display:grid!important;grid-template-columns:repeat(5,minmax(0,1fr));gap:5px}
.rpasc .rpai{width:auto!important;height:36px!important;min-width:0}.rpasc .rpai img{width:34px!important;height:34px!important}
.rpasc{margin-top:8px!important;padding-top:7px!important}.rpasc>div{margin-top:4px!important}
.rpasc .rpai em{font-size:12px;right:2px;bottom:0}`;document.head.appendChild(st)}
