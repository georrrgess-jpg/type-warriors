# Wildcard Ranked online: matchmaking through the relay (local MQTT broker on ws 127.0.0.1:18083), a full match, results.
import asyncio,os,sys,time
from playwright.async_api import async_playwright
MQ='ws://127.0.0.1:18083/mqtt'
async def main():
    html=os.path.abspath(sys.argv[1] if len(sys.argv)>1 else 'out.html');bad=0;er=[]
    def chk(n,v,ok):
        nonlocal bad;bad+=0 if ok else 1;print(n,v,'OK' if ok else 'BAD',flush=True)
    async with async_playwright() as p:
        b=await p.chromium.launch();pages=[]
        for nm in ('Seth','Mia'):
            c=await b.new_context(viewport={'width':1600,'height':900});pg=await c.new_page();pg.on('pageerror',lambda e,nm=nm:er.append(nm+' PE '+str(e)[:300]));await pg.goto('file://'+html);pages.append(pg)
        A,B=pages;await A.wait_for_timeout(1200)
        for pg,nm in ((A,'Seth'),(B,'Mia')):await pg.evaluate(f"()=>{{RS_ASK=false;WCRELAYS=['{MQ}'];P.name='{nm}';P.gold=1000;delete P.rk;const R=rkSt();R.r=2;R.bar=40;save();rkHub()}}")
        await A.click('#rkfind');await B.wait_for_timeout(700);await B.click('#rkfind');t0=time.time()
        await A.wait_for_timeout(2500);await A.screenshot(path='shots/rk_mm.png')
        while time.time()-t0<45 and not (await A.evaluate("()=>!!(WX.rk&&WX.G&&document.getElementById('wct'))") and await B.evaluate("()=>!!(WX.rk&&WX.G&&document.getElementById('wct'))")):await A.wait_for_timeout(300)
        q="()=>[WX.mode,WX.host,!!WX.rk,WX.rk&&WX.rk.net,WX.G&&WX.G.P.map(p=>p.kind+':'+p.name+(p.ai?':ai':'')),!!rkSt().live,WX.cfg.timer]"
        ra=await A.evaluate(q);rb=await B.evaluate(q);chk(f'paired and dealt in {time.time()-t0:.1f}s, host',ra,ra[0]=='net' and ra[2] and ra[3] and sum(1 for x in ra[4] if x.startswith('net'))==1 and ra[5] and ra[6]==15)
        chk('guest',rb,rb[0]=='net' and rb[2] and not rb[1] and rb[5])
        await A.wait_for_timeout(1500);await B.screenshot(path='shots/rk_net_B.png')
        for pg in (A,B):await pg.add_script_tag(path=os.path.abspath('t_wc_agent.js'))
        t1=time.time()
        while time.time()-t1<400 and not (await A.evaluate("()=>!!document.getElementById('rkres')") and await B.evaluate("()=>!!document.getElementById('rkres')")):await A.wait_for_timeout(600)
        await A.wait_for_timeout(2500)
        q="()=>{const R=rkSt(),h=R.hist[R.hist.length-1];return [!!document.getElementById('rkres'),h&&h.p,h&&h.d,R.bar,R.live,[...document.querySelectorAll('.rkrr .rkrn b')].map(e=>e.textContent)]}"
        ra=await A.evaluate(q);rb=await B.evaluate(q)
        chk(f'match over in {time.time()-t1:.0f}s, host result',ra,ra[0] and ra[2]==[30,10,0,-10][ra[1]] and ra[3]==40+ra[2] and ra[4] is None)
        chk('guest result',rb,rb[0] and rb[2]==[30,10,0,-10][rb[1]] and rb[3]==40+rb[2] and rb[4] is None)
        na=[x.replace(' (you)','').split(' AI')[0].split(' ★')[0] for x in ra[5]];nb=[x.replace(' (you)','').split(' AI')[0].split(' ★')[0] for x in rb[5]]
        chk('both see the same standings',[na,nb],na==nb and ra[1]!=rb[1])
        await B.screenshot(path='shots/rk_net_res_B.png')
        # a lone seeker: AI fills the seats at 15 s
        await A.evaluate("()=>{clearInterval(window.__agT);rkHub()}");await B.evaluate("()=>{clearInterval(window.__agT);rkHub()}");await A.wait_for_timeout(500)
        await A.click('#rkfind');t2=time.time()
        while time.time()-t2<25 and not await A.evaluate("()=>!!(WX.rk&&WX.G&&document.getElementById('wct'))"):await A.wait_for_timeout(250)
        r=await A.evaluate("()=>[WX.mode,WX.G.P.filter(p=>p.kind==='bot'&&p.ai).length,WX.G.P.filter(p=>p.diff==='r2').length]");chk(f'nobody else searching: AI match after {time.time()-t2:.1f}s',r,r==['solo',3,3] and 14<time.time()-t2<18)
        print('bad',bad);print(er[:6]);await b.close()
asyncio.run(main())
