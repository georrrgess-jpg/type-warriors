/* ===== 9.4 THE CROOKED CUE: frame step and rendering (96i2) =====
   One canvas, drawn in stage coordinates. Order: baked room+table, lamp light, string lights, dust, cast, tray, shadows, balls, drops,
   guide, cue and hands, ghost, fx. Everything moves by transforms; nothing allocates per frame except short-lived fx. */
const PZ_BD=26;/* drawn ball diameter (the physics ball is 24) */
/* ---------- fx pools ---------- */
function pzPuff(x,y,n,col,sp){if(pzRM())n=Math.min(n,3);for(let i=0;i<n;i++){if(PZ.fx.length>130)PZ.fx.shift();const a=Math.random()*TAU,s=(.3+Math.random())*(sp||80);PZ.fx.push({k:'puff',x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s*.7,t:0,d:.35+Math.random()*.25,r:2.5+Math.random()*3,col})}}
function pzSpecks(x,y,n,col){if(pzRM())n=Math.min(n,2);for(let i=0;i<n;i++){if(PZ.fx.length>130)PZ.fx.shift();const a=Math.random()*TAU,s=70+Math.random()*190;PZ.fx.push({k:'speck',x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s*.75,t:0,d:.2+Math.random()*.18,r:1.3+Math.random()*1.4,col})}}
function pzDust(x,y,n){if(pzRM())return;for(let i=0;i<n;i++){if(PZ.fx.length>130)PZ.fx.shift();const a=Math.random()*TAU,s=30+Math.random()*60;PZ.fx.push({k:'dust',x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s*.6,t:0,d:.5+Math.random()*.3,r:3+Math.random()*4,col:'rgba(190,230,200,'})}}
function pzCoinBurst(x,y,n){if(pzRM())n=Math.min(n,6);for(let i=0;i<n;i++){if(PZ.fx.length>130)PZ.fx.shift();const a=-Math.PI/2+(Math.random()-.5)*1.8,s=240+Math.random()*320;PZ.fx.push({k:'coin',x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,t:0,d:1.1+Math.random()*.4,r:7+Math.random()*3,ph:Math.random()*6})}}
function pzFloat(x,y,text,col){PZ.floats.push({x,y,text,col,t:0,d:1.3})}
/* impact flash: a baked glow plus a few tapered rays, plain alpha (no blend modes) */
let PZ_GLOWSP=null;
function pzGlowSprite(){if(PZ_GLOWSP)return PZ_GLOWSP;const c=pzCv(64,64),g=c.getContext('2d'),q=g.createRadialGradient(32,32,0,32,32,32);q.addColorStop(0,'rgba(255,255,255,1)');q.addColorStop(.22,'rgba(255,250,225,.8)');q.addColorStop(.55,'rgba(255,238,175,.28)');q.addColorStop(1,'rgba(255,230,150,0)');g.fillStyle=q;g.fillRect(0,0,64,64);return PZ_GLOWSP=c}
function pzFlash(x,y,s,big){if(pzRM())return;const f=PZ.flashes||(PZ.flashes=[]);if(f.length>9)f.shift();const n=big?16:5+Math.min(5,s/500|0),rays=[],a0=Math.random()*TAU;for(let i=0;i<n;i++)rays.push({a:a0+i/n*TAU+(Math.random()-.5)*.5,l:(.45+Math.random()*.75)*(big?104:20+Math.min(34,s/70)),w:big?4.5:2.6});f.push({x,y,t:0,d:big?.36:.2,rays,r:big?78:12+Math.min(24,s/80)})}
function pzFxStep(dt){const f=PZ.fx;for(let i=f.length-1;i>=0;i--){const p=f[i];p.t+=dt;if(p.t>=p.d){f.splice(i,1);continue}const dr=p.k==='speck'?.88:.92;p.x+=p.vx*dt;p.y+=p.vy*dt;p.vx*=Math.pow(dr,dt*60);p.vy*=Math.pow(dr,dt*60);if(p.k==='coin'){p.vy+=900*dt}}
 const r=PZ.rings;for(let i=r.length-1;i>=0;i--){r[i].t+=dt;if(r[i].t>=r[i].d)r.splice(i,1)}const fh=PZ.flashes;if(fh)for(let i=fh.length-1;i>=0;i--){fh[i].t+=dt;if(fh[i].t>=fh[i].d)fh.splice(i,1)}const fl=PZ.floats;for(let i=fl.length-1;i>=0;i--){fl[i].t+=dt;if(fl[i].t>=fl[i].d)fl.splice(i,1)}}
function pzFxDraw(g){for(const p of PZ.fx){const u=p.t/p.d;
  if(p.k==='coin'){g.save();g.translate(p.x,p.y);g.scale(1,Math.abs(Math.cos(p.ph+p.t*9))*.9+.1);g.globalAlpha=Math.min(1,(1-u)*2);g.fillStyle='#ffd45a';g.strokeStyle=PZ_O;g.lineWidth=2;g.beginPath();g.arc(0,0,p.r,0,TAU);g.fill();g.stroke();g.strokeStyle='#c88a10';g.lineWidth=1.4;g.beginPath();g.arc(0,0,p.r*.6,0,TAU);g.stroke();g.restore();continue}
  if(p.k==='speck'){g.globalAlpha=1-u;g.fillStyle=p.col;g.beginPath();g.arc(p.x,p.y,p.r*(1-u*.5),0,TAU);g.fill();g.globalAlpha=1;continue}
  g.globalAlpha=(1-u)*(p.k==='dust'?.5:.75);g.fillStyle=p.col.endsWith(',')?p.col+'1)':p.col;g.beginPath();g.arc(p.x,p.y,p.r*(1+u*(p.k==='dust'?2.2:1)),0,TAU);g.fill();g.globalAlpha=1}
 for(const r of PZ.rings){const u=r.t/r.d,e=1-(1-u)*(1-u);g.globalAlpha=(1-u)*.9;g.strokeStyle=r.c;g.lineWidth=r.ring?3.5*(1-u)+1:2.5*(1-u)+1;g.beginPath();g.arc(r.x,r.y,r.r*(.4+e*1.4),0,TAU);g.stroke();g.globalAlpha=1}
 if(PZ.flashes&&PZ.flashes.length){const sp=pzGlowSprite();for(const f of PZ.flashes){const u=f.t/f.d,e=1-(1-u)*(1-u),al=1-u,R=f.r*(.55+e*.75);g.globalAlpha=al;g.drawImage(sp,f.x-R,f.y-R,R*2,R*2);g.fillStyle='#fffbe8';for(const r of f.rays){const L=r.l*(.35+e*.85),w=r.w*(1-u),c=Math.cos(r.a),s=Math.sin(r.a);g.beginPath();g.moveTo(f.x+c*f.r*.25-s*w,f.y+s*f.r*.25+c*w);g.lineTo(f.x+c*(f.r*.25+L),f.y+s*(f.r*.25+L));g.lineTo(f.x+c*f.r*.25+s*w,f.y+s*f.r*.25-c*w);g.closePath();g.fill()}g.globalAlpha=1}}
 for(const f of PZ.floats){const u=f.t/f.d,e=u<.18?pzBack(u/.18):1;g.save();g.translate(f.x,f.y-u*46);g.scale(e,e);g.globalAlpha=Math.min(1,(1-u)*2.4);g.font='400 40px "Pirata One",Georgia,serif';g.textAlign='center';g.lineWidth=7;g.strokeStyle=PZ_O;g.lineJoin='round';g.strokeText(f.text,0,0);g.fillStyle=f.col;g.fillText(f.text,0,0);g.restore()}}
const pzBack=u=>{const c1=1.70158,c3=c1+1;return 1+c3*Math.pow(u-1,3)+c1*Math.pow(u-1,2)};
/* ---------- the ball-return tray ---------- */
function pzTrayAdd(id,instant){const G=PZ_G,n=PZ.tray.length,tx=G.trayX0+12+n*23.2;PZ.tray.push({id,x:instant?tx:G.trayX1+16,tx,v:0,vis:!!instant,age:instant?9:0})}
function pzTrayRemove(id){const i=PZ.tray.findIndex(t=>t.id===id);if(i>=0){PZ.tray.splice(i,1);PZ.tray.forEach((t,k)=>{t.tx=PZ_G.trayX0+12+k*23.2})}}
function pzTrayStep(dt){const B=PZ.B;for(const t of PZ.tray){t.age+=dt;if(Math.abs(t.x-t.tx)<.4){t.x=t.tx;continue}const v=Math.min(540,(t.x-t.tx)*3.2+70);t.x=Math.max(t.tx,t.x-v*dt);const b=B[t.id];if(b){b.M=pzbRot(b.M,0,-1,0,-v*dt/10);b.dirty=1;if((b.rc=(b.rc||0)+1)>48){b.rc=0;pzbOrtho(b)}}if(t.x<=t.tx+.4&&!t.landed){t.landed=1;pzFx('tray')}}}
/* ---------- the re-rack ---------- */
function pzRackTri(g,a){const R=PZ_PHY.R,G=PZ_G,fx=G.x+PZ_PHY.W*.75,fy=G.y+PZ_PHY.H/2,xb=fx+4*R*Math.sqrt(3)*1.02,hh=4*R*1.02+R*1.55,p=[[fx-R*2.1,fy],[xb+R*1.55,fy-hh-4],[xb+R*1.55,fy+hh+4]];
 g.save();g.globalAlpha=a;g.translate(0,(1-a)*-26);g.lineJoin='round';g.fillStyle='rgba(0,0,0,.28)';g.beginPath();p.forEach(([x,y],i)=>i?g.lineTo(x+5,y+9):g.moveTo(x+5,y+9));g.closePath();g.fill();
 g.lineWidth=18;g.strokeStyle=pzLin(g,fx,fy-hh,fx,fy+hh,[[0,'#a8642c'],[.5,'#7a4018'],[1,'#5a2c10']]);g.beginPath();p.forEach(([x,y],i)=>i?g.lineTo(x,y):g.moveTo(x,y));g.closePath();g.stroke();
 g.lineWidth=2.6;g.strokeStyle=PZ_O;g.beginPath();p.forEach(([x,y],i)=>i?g.lineTo(x,y):g.moveTo(x,y));g.closePath();g.stroke();g.lineWidth=1.4;g.strokeStyle='rgba(255,220,170,.4)';g.beginPath();p.forEach(([x,y],i)=>i?g.lineTo(x,y-5):g.moveTo(x,y-5));g.closePath();g.stroke();g.restore()}
function pzRerackStep(dt){const rk=PZ.rk,B=PZ.B;rk.t+=dt;let all=true;for(const it of rk.items){const lt=rk.t-it.delay;if(lt<.42)all=false;if(lt>=.42&&!it.done){it.done=true;const b=B[it.id];if(PZ.B[it.id]&&!pzRM()){pzFx('drop',it.id);pzPuff(PZ_G.x+b.x,PZ_G.y+b.y,3,'rgba(190,230,200,.6)',40)}}}
 if(rk.t>=rk.dur||(pzRM()&&rk.t>.3)){PZ.rk=null;for(const b of B)b.fly=null;pzBeginTurn(true)}}
/* ---------- steps per phase ---------- */
function pzSpringAng(dt){let n=Math.ceil(dt/.008),h=dt/n;const W0=PZ.ph==='ai'?16:30;for(let i=0;i<n;i++){let d=PZ.aim.ang-PZ.cueAng;while(d>Math.PI)d-=TAU;while(d<-Math.PI)d+=TAU;PZ.cueAv+=(d*W0*W0-PZ.cueAv*2*W0)*h;PZ.cueAng+=PZ.cueAv*h}}
function pzPullSpring(dt,tgt){const W0=26;let n=Math.ceil(dt/.008),h=dt/n;PZ.pullV=PZ.pullV||0;for(let i=0;i<n;i++){PZ.pullV+=((tgt-PZ.pull)*W0*W0-PZ.pullV*2*W0)*h;PZ.pull+=PZ.pullV*h}}
function pzAimStep(dt){PZ.cueA=Math.min(1,PZ.cueA+dt*5);const K=PZ.keys||{};
 if(PZ.mode==='aim'){K.th=(K.left||K.right)?(K.th||0)+dt:0;if((K.left||K.right)&&K.th>.28){PZ.aim.ang+=((K.right?1:0)-(K.left?1:0))*dt*(K.shift?.03:Math.min(.45,.08+(K.th-.28)*.35));PZ.moved=true}if(K.up||K.down){PZ.aim.pow=Math.max(0,Math.min(1,PZ.aim.pow+((K.up?1:0)-(K.down?1:0))*dt*(K.shift?.15:.6)));pzHudBar()}}
 pzSpringAng(dt);pzPullSpring(dt,PZ.aim.pow*105);
 if(PZ.clockOn&&!PZ.paused){PZ.clock-=dt;if(PZ.clock<=0){pzTimeFoul()}else pzHudClock()}}
function pzStrokeStep(dt){const s=PZ.stroke;s.t+=dt;const u=Math.min(1,s.t/s.dur);PZ.gapNow=s.g0*(1-u*u*u);
 if(PZ.ph==='stroke'){PZ.cueA=1;if(u>=1){PZ.gapNow=0;pzContact()}}}
/* the common step */
function pzStep(dt){const ph=PZ.ph;
 if(ph==='rerack')pzRerackStep(dt);else if(ph==='aim')pzAimStep(dt);else if(ph==='ai'){pzAiStep(dt);pzSpringAng(dt);pzPullSpring(dt,(PZ.aiPull||0))}
 else if(ph==='stroke')pzStrokeStep(dt);else if(ph==='roll')pzRollStep(dt);else if(ph==='settle')pzSettleStep(dt);else if(ph==='gap')pzGapStep(dt);else if(ph==='endhold')pzEndStep(dt);
 if(ph==='roll'||ph==='settle'||ph==='gap'){PZ.cueFade=Math.max(0,(PZ.cueFade||0)-dt*3);if(PZ.ph==='roll'){PZ.gapNow=Math.max(-26,(PZ.gapNow||0)-dt*300)}}
 pzCastFrame(dt);pzFxStep(dt);pzTrayStep(dt);
 for(const d of PZ.drops)d.t+=dt;for(let i=PZ.drops.length-1;i>=0;i--){const d=PZ.drops[i];if(d.t>=d.dur){PZ.drops.splice(i,1);if(d.id>0)pzTrayAdd(d.id)}}
 if(PZ.placePop){PZ.placePop.t+=dt;if(PZ.placePop.t>.5)PZ.placePop=null}
 pzCamStep(dt);if(PZ.shake>0)PZ.shake=Math.max(0,PZ.shake-dt*3.4)}
function pzCamStep(dt){const C=PZ.cam=PZ.cam||{z:1,cx:800,cy:450};let tz=1,tx=800,ty=450;
 if(PZ.slow&&PZ.slow.on){const P=PZ_POCK[PZ.slow.k];tz=1.62;tx=PZ_G.x+P[0]+(P[0]<440?110:(P[0]>440?-110:0));ty=PZ_G.y+P[1]+(P[1]<220?70:-70)}
 const k=Math.min(1,dt*(tz>1?4:3));C.z+=(tz-C.z)*k;C.cx+=(tx-C.cx)*k;C.cy+=(ty-C.cy)*k}
/* ---------- the frame ---------- */
/* fast-forward: hold click or Space for 3x between shots and while the balls roll; the slow tail of a roll runs at 2x by itself. The physics
   still steps at 1/120 s, so the result is exactly the same as at normal speed. */
function pzFF(){const ph=PZ.ph;if(PZ.slow&&PZ.slow.on)return 1;if(PZ.ffHeld&&(ph==='roll'||ph==='settle'||ph==='gap'||ph==='ai'||ph==='endhold'||ph==='rerack'||ph==='stroke'))return 3;
 if(ph==='roll'&&PZ.B&&!pzRM()){let ok=true;for(const b of PZ.B){if(!b.on)continue;const s=Math.hypot(b.vx,b.vy);if(s>230){ok=false;break}if(s>0)for(const P of PZ_POCK)if((b.x-P[0])**2+(b.y-P[1])**2<8100){ok=false;break}if(!ok)break}if(ok)return 2}return 1}
/* the first AI decisions and the first break are slow only because the code is cold: run a throw-away decision in small slices while the intro plays */
let PZ_WARMED=false,PZ_WARM=null;
function pzWarmStep(){if(PZ_WARMED||pzRM()||!PZ.reg)return;const t0=performance.now();try{if(!PZ_WARM){const rng=pzRng(97),B=pzpRack(rng),st=pzrNew(B,1,{});st.brk=false;st.open=true;B[0].x=PZ_PHY.W*.4;B[0].y=PZ_PHY.H*.5;PZ_WARM={n:0,gen:pzaThink(st,Object.assign({},PZ.reg.ai),rng,{sigK:1})}}
  do{const r=PZ_WARM.gen.next();if(r.done||++PZ_WARM.n>70){PZ_WARMED=true;break}}while(performance.now()-t0<3)}catch(e){PZ_WARMED=true}}
function pzFrame(g){if(!PZ.on||!PZ.B||!PZ.bk)return;const now=performance.now();if(PZ.ph==='intro'||PZ.ph==='rerack')pzWarmStep();let dt=(now-(PZ.last||now))/1000;PZ.last=now;
 /* lite mode: if frames average over 30 ms for about three seconds, drop the extras (string lights, dust, ball streaks) and use smaller ball sprites */
 if(!PZ.lite&&!PZ.paused&&!PZ.modal&&dt>0&&dt<.5){PZ.lt=(PZ.lt||16)*.96+dt*1000*.04;if(PZ.lt>30){if(++PZ.ltN>150){PZ.lite=true;try{pzbSetup(36,PZS().balls);PZ_BS.dirtyAll=1}catch(e){}}}else PZ.ltN=0}
dt=Math.max(0,Math.min(.1,dt*(PZ.speed||1)))*pzFF();if(PZ.paused||PZ.modal)dt=0;PZ.t+=dt;
 try{pzStep(dt)}catch(e){console.error(e)}
 pzbSync(PZ.B);pzRender(g)}
function pzRender(g){const t=PZ.t,G=PZ_G,C=PZ.cam||{z:1,cx:800,cy:450};g.setTransform(1,0,0,1,0,0);
 const sk=PZ.shake>0?PZ.shake:0,shx=sk?(Math.sin(t*91)+Math.sin(t*57))*3.2*sk:0,shy=sk?(Math.cos(t*83)+Math.cos(t*61))*3.2*sk:0;
 g.translate(800+shx,450+shy);g.scale(C.z,C.z);g.translate(-C.cx,-C.cy);
 g.drawImage(PZ.bk,0,0);
 pzDrawLamp(g,t);if(!PZ.lite){pzDrawLights(g,t);pzDrawDust(g,t)}
 pzCastDraw(g,t,{heroPose:PZ.heroPose});
 pzDrawTable(g,t);
 pzFxDraw(g);
 if(PZ.slow&&PZ.slow.on&&!pzRM())pzDrawSlow(g,t)}
/* the deciding 8: the room dims around the pocket, which glows and pulses like a heartbeat */
function pzDrawSlow(g,t){const P=PZ_POCK[PZ.slow.k],x=PZ_G.x+P[0],y=PZ_G.y+P[1],u=Math.min(1,PZ.slow.t*3),fade=PZ.slow.drop!=null?Math.max(0,1-PZ.slow.drop/.7):1,a=u*fade;
 g.save();const q=g.createRadialGradient(x,y,70,x,y,560);q.addColorStop(0,'rgba(4,2,16,0)');q.addColorStop(1,`rgba(4,2,16,${.62*a})`);g.fillStyle=q;g.fillRect(x-1300,y-900,2600,1800);
 const pu=.5+.5*Math.sin(t*11);g.globalAlpha=(.55+.4*pu)*a;g.strokeStyle='#ffe066';g.lineWidth=5;g.beginPath();g.arc(x,y,34+pu*9,0,TAU);g.stroke();g.globalAlpha=.35*a*pu;g.lineWidth=12;g.beginPath();g.arc(x,y,40+pu*14,0,TAU);g.stroke();g.restore()}
/* the lamp over the table, bulbs, drifting dust */
function pzDrawLamp(g,t){const sw=Math.sin(t*.9)*5,x=PZ_G.lampX+sw;g.save();
 g.strokeStyle='#120a06';g.lineWidth=3;g.beginPath();g.moveTo(PZ_G.lampX,60);g.lineTo(x,PZ_G.lampY-30);g.stroke();
 g.translate(x,PZ_G.lampY);g.rotate(sw*.0018);g.fillStyle=pzLin(g,-110,0,110,0,[[0,'#143a2a'],[.5,'#2a7a54'],[1,'#143a2a']]);g.beginPath();g.moveTo(-40,-26);g.lineTo(40,-26);g.lineTo(112,24);g.lineTo(-112,24);g.closePath();g.fill();g.strokeStyle=PZ_O;g.lineWidth=4;g.stroke();
 g.fillStyle='#d8a03a';g.fillRect(-112,22,224,6);g.strokeRect(-112,22,224,6);g.fillStyle='rgba(255,255,255,.22)';g.beginPath();g.moveTo(-34,-22);g.lineTo(-14,-22);g.lineTo(-62,20);g.lineTo(-84,20);g.fill();
 pzGlow(g,0,30,90,'rgba(255,240,190,1)',.9);g.fillStyle='rgba(255,246,210,.95)';g.beginPath();g.ellipse(0,28,70,6,0,0,TAU);g.fill();g.restore()}
const PZ_LCOL=['rgba(255,212,90,1)','rgba(255,154,208,1)','rgba(159,232,255,1)','rgba(138,255,180,1)'];
function pzDrawLights(g,t){/* plain alpha blits of a baked glow (no per-bulb blend-mode change): about 40 draw calls */for(let i=0;i<32;i++){const x=i*50+25,y=37+Math.sin(((x%200)/200)*Math.PI)*28,c=PZ_LCOL[i&3],a=.5+.35*Math.sin(t*2.2+i*1.7);g.globalAlpha=a*.8;g.drawImage(pzGlowS(c),x-26,y-19,52,52);g.globalAlpha=.9;g.fillStyle=c;g.beginPath();g.arc(x,y+7,4.4,0,TAU);g.fill()}g.globalAlpha=1}
function pzDrawDust(g,t){if(pzRM())return;g.save();g.globalCompositeOperation='lighter';for(let i=0;i<22;i++){const ph=(t*.018+i*.0455)%1,x=PZ_G.lampX-250+((i*137)%500)+Math.sin(t*.4+i)*18,y=170+ph*520;const a=Math.sin(ph*Math.PI)*.15;g.fillStyle=`rgba(255,236,190,${a})`;g.beginPath();g.arc(x,y,1.2+(i%3)*.5,0,TAU);g.fill()}
 if(PZ.reg&&PZ.reg.house&&PZ.reg.house.spores){for(let i=0;i<14;i++){const ph=(t*.05+i*.071)%1,x=PZ_G.x+80+((i*211)%720)+Math.sin(t*.7+i*2)*24,y=PZ_G.y+PZ_PHY.H-ph*PZ_PHY.H;const a=Math.sin(ph*Math.PI)*.4;g.fillStyle=`rgba(190,255,170,${a})`;g.beginPath();g.arc(x,y,2+(i%3),0,TAU);g.fill()}}g.restore()}
/* ---------- the table's contents ---------- */
function pzDrawTable(g,t){const B=PZ.B,G=PZ_G,st=PZ.st,ph=PZ.ph,Lx=PZ_G.lampX,Ly=PZ_G.lampY;
 pzDrawTray(g);
 /* the called pocket and the pockets to choose from (the 8 is next) */
 if(PZ.mode==='aim'&&st&&pzrOn8(st))pzDrawCall(g,t);
 /* table balls, back to front */
 const list=[];for(const b of B){if(b.on&&(!PZ.rk||pzVisRk(b)))list.push(b)}list.sort((a,b)=>a.y-b.y);
 for(const b of list){const sx=G.x+b.x,sy=G.y+b.y;let oy=0,sc=1,ga=1;
  if(PZ.rk&&!pzRM()){const it=PZ.rk.items[b.id],lt=PZ.rk.t-it.delay,u=Math.min(1,lt/.42);if(u<1){const e=(1-u);oy=-e*e*560;sc=1+e*.5;ga=.3+.7*u}}
  if(b.id===0&&PZ.mode==='place'&&PZ.ph==='aim')continue;
  const sp2=b.vx*b.vx+b.vy*b.vy;
  if(sp2>160000&&!pzRM()&&!PZ.lite&&!PZ.rk){const sp=Math.sqrt(sp2),L=Math.min(66,sp*.027),ux=-b.vx/sp,uy=-b.vy/sp,al=Math.min(.36,.07+(sp-400)/3400);g.save();g.lineCap='round';g.strokeStyle='#fffbe8';for(let k=0;k<3;k++){g.globalAlpha=al*(k?.85:.55);g.lineWidth=PZ_BD*(.66-k*.2);const l=L*(1-k*.34);g.beginPath();g.moveTo(sx,sy);g.lineTo(sx+ux*l,sy+uy*l);g.stroke()}g.restore()}
  pzbShadow(g,sx,sy,Lx,Ly,sc*1.0,.95*ga);pzbBlit(g,b.id,sx,sy+oy,PZ_BD*sc)}
 /* triangle during the re-rack */
 if(PZ.rk&&!PZ.rk.notri){const rk=PZ.rk,u=rk.t/rk.dur,a=u<.62?1:Math.max(0,1-(u-.62)/.3);if(a>0&&!pzRM())pzRackTri(g,a)}
 /* pocket drops */
 for(const d of PZ.drops){const k=d.k<0?0:d.k,P=PZ_POCK[k],u=Math.min(1,d.t/d.dur),e=u*u,x=G.x+d.x+(P[0]-d.x)*e,y=G.y+d.y+(P[1]-d.y)*e,sc=1-.32*e;pzbBlit(g,d.id,x,y,PZ_BD*sc);g.fillStyle=`rgba(4,2,8,${e*.95})`;g.beginPath();g.arc(x,y,PZ_BD*.5*sc,0,TAU);g.fill()}
 /* the cue, its hands, and the aim guide */
 if((ph==='aim'&&PZ.mode!=='place')||ph==='ai'||ph==='stroke'||(ph==='roll'&&PZ.cueFade>0))pzDrawCueSet(g,t);
 /* ball in hand: the ghost follows the pointer */
 if(PZ.mode==='place'&&PZ.ph==='aim'&&PZ.place)pzDrawPlace(g,t);
 if(PZ.placePop){const p=PZ.placePop,u=p.t/.5;g.strokeStyle=`rgba(255,255,255,${(1-u)*.9})`;g.lineWidth=3;g.beginPath();g.arc(G.x+p.x,G.y+p.y,10+u*34,0,TAU);g.stroke()}}
const pzVisRk=b=>{if(!PZ.rk)return true;const it=PZ.rk.items[b.id];return it&&PZ.rk.t>=it.delay};
function pzDrawTray(g){const B=PZ.B,G=PZ_G;for(const t of PZ.tray){const b=B[t.id];if(!b)continue;const k=Math.min(1,t.age/.22),e=1-(1-k)*(1-k),y=G.trayY-(1-e)*9-Math.sin(k*Math.PI)*5*(t.landed?0:1);pzbShadow(g,t.x,G.trayY,800,150,.8*(.4+.6*e),.6);pzbBlit(g,t.id,t.x,y,22*(.62+.38*e))}}
function pzDrawCall(g,t){const G=PZ_G,st=PZ.st,call=PZ.call>=0?PZ.call:(PZ.autoCall==null?-1:PZ.autoCall),lab=['1','2','3','4','5','6'];
 for(let k=0;k<6;k++){const P=PZ_POCK[k],x=G.x+P[0],y=G.y+P[1],on=k===call,pu=.5+.5*Math.sin(t*5+k);g.save();g.lineWidth=on?4:2.4;g.strokeStyle=on?`rgba(255,212,90,${.8+.2*pu})`:`rgba(255,255,255,${.32+.25*pu})`;g.beginPath();g.arc(x,y,P[3]+4+(on?pu*3:0),0,TAU);g.stroke();
  g.fillStyle=on?'rgba(255,212,90,.2)':'rgba(255,255,255,.07)';g.beginPath();g.arc(x,y,P[3],0,TAU);g.fill();g.font='800 15px Poppins,sans-serif';g.textAlign='center';g.fillStyle=on?'#ffd45a':'rgba(255,255,255,.75)';g.strokeStyle=PZ_O;g.lineWidth=4;
  const lx=x+(P[0]<440?26:(P[0]>440?-26:0)),ly=y+(P[1]<220?30:-24);g.strokeText(lab[k],lx,ly+5);g.fillText(lab[k],lx,ly+5);g.restore()}}
function pzDrawPlace(g,t){const G=PZ_G,p=PZ.place,x=G.x+p.x,y=G.y+p.y;g.save();g.globalAlpha=.9;pzbShadow(g,x,y-4,PZ_G.lampX,PZ_G.lampY,1.25,.6);pzbBlit(g,0,x,y-5,PZ_BD*1.14);g.restore();
 g.strokeStyle=p.ok?'rgba(138,255,180,.95)':'rgba(255,90,100,.95)';g.lineWidth=3;g.beginPath();g.arc(x,y,17+Math.sin(t*6)*1.2,0,TAU);g.stroke();
 if(PZ.st.kitchen||PZ.st.brk){g.strokeStyle='rgba(255,255,255,.4)';g.setLineDash([6,8]);g.lineWidth=2;g.beginPath();g.moveTo(G.x+PZ_PHY.W/4,G.y+6);g.lineTo(G.x+PZ_PHY.W/4,G.y+PZ_PHY.H-6);g.stroke();g.setLineDash([])}}
function pzSkinOf(who){return who===0?PZS().cue:(PZ.reg?PZ.reg.cue:'house')}
/* the shoulder that holds the cue, in stage coordinates */
function pzShoulder(who){const C=PZ_CAST;if(who===0){const H=C.hero||{lean:0,hop:0};return {x:264+(H.lean||0)*30,y:656-(H.hop||0)*30}}const M=C.mon||{lean:0,hop:0},h=PZ_MONH[PZ.reg.id]||320;return {x:1398-(M.lean||0)*26,y:846-h*.84*.52-(M.hop||0)*30}}
function pzDrawCueSet(g,t){const B=PZ.B,c=B[0],G=PZ_G,st=PZ.st,R=PZ_PHY.R;if(!c.on)return;const aiShot=PZ.ph==='ai'||(PZ.ph==='stroke'&&PZ.stroke&&PZ.stroke.ai)||(PZ.ph==='roll'&&PZ.shot&&PZ.shotAi);
 const who=aiShot?1:0,skin=pzSkinOf(who),ang=(PZ.ph==='stroke'||PZ.ph==='roll')?PZ.shot.ang:PZ.cueAng,cx=G.x+c.x,cy=G.y+c.y,dx=Math.cos(ang),dy=Math.sin(ang);
 /* extra = how far the tip is from the ball surface */
 let extra=(PZ.ph==='aim'||PZ.ph==='ai')?5+PZ.pull:(PZ.gapNow||0);const gap=R+extra;
 let al=Math.min(1,PZ.cueA==null?1:PZ.cueA);if(PZ.ph==='roll')al=Math.max(0,(PZ.cueFade||0));if(al<=0)return;
 /* the aim guide first (under the cue) */
 if(who===0&&PZ.ph==='aim'&&PZ.mode==='aim'){const o=pzDrawGuide(g,B,PZ.cueAng,pzGuideMode(),t,PZ.aim.b);PZ.autoCall=(pzrOn8(st)&&o.hit&&o.hit.type==='ball'&&o.hit.id===8)?o.pocket:(pzrOn8(st)?PZ.autoCall:-1);if(!PZ.callManual&&PZ.autoCall>=0)PZ.call=PZ.autoCall;PZ.guideHit=o}
 const skinC=who===0?'#e8b890':(PZ.reg.skin||'#f2dcc0'),cuff=who===0?'#4a3a8a':pzMix(PZ.reg.c,'#000000',.45);
 g.save();g.globalAlpha=al;
 /* the cue's shadow on the cloth, the bridge hand, the cue, then the gripping hand */
 g.strokeStyle='rgba(0,0,0,.2)';g.lineWidth=7;g.lineCap='round';g.beginPath();g.moveTo(cx-dx*gap+3,cy-dy*gap+9);g.lineTo(cx-dx*(gap+PZ_CUE.L)+3,cy-dy*(gap+PZ_CUE.L)+9);g.stroke();
 pzHand(g,cx-dx*(R+46),cy-dy*(R+46),ang,skinC,'bridge');
 pzDrawCue(g,cx,cy,ang,gap,skin,1);
 /* who holds the cue: an arm from the shoulder to a grip on the shaft (the nearest point it can reach); too far and an arm reaches in from outside the table */
 const sh=pzShoulder(who),tpx=cx-dx*gap,tpy=cy-dy*gap,pr=-((sh.x-tpx)*dx+(sh.y-tpy)*dy),ss=Math.max(150,Math.min(PZ_CUE.L-40,pr)),gx=tpx-dx*ss,gy=tpy-dy*ss,gd=Math.hypot(gx-sh.x,gy-sh.y),ak=Math.max(0,Math.min(1,(330-gd)/90));
 const sp=PZ_CUES.find(x=>x.id===skin);if(sp&&sp.glow){const bt=pzCueButt(cx,cy,ang,gap,PZ_CUE.L*.6);pzGlow(g,bt.x,bt.y,50,pzRgba(sp.glow),.4)}
 if(ak>0){g.globalAlpha=al*ak;pzArm(g,sh.x,sh.y,gx,gy,who===0?'#8a7d62':cuff,skinC);pzHand(g,gx,gy,ang,skinC,'grip')}
 if(ak<1){g.globalAlpha=al*(1-ak);const bt=pzCueButt(cx,cy,ang,gap,PZ_CUE.L*1.0);pzHand(g,bt.x,bt.y,ang,skinC,'grip',cuff)}
 g.restore();
 /* chalk over the tip while the monster chalks up */
 if(PZ.ai&&PZ.ai.chalk>0){const u=PZ.ai.chalk,tx=cx-dx*gap,ty=cy-dy*gap,ly=ty-26-Math.sin(u*Math.PI)*16;pzChalk(g,tx+8,ly,Math.sin(u*TAU*2)*.5,.9+.1*Math.sin(u*Math.PI));if(Math.sin(u*TAU*2)>.9)pzPuff(tx,ty,1,'rgba(150,200,255,.7)',30)}}
const pzRgba=h=>{const n=parseInt(h.slice(1),16);return `rgba(${n>>16&255},${n>>8&255},${n&255},1)`};
function pzGuideMode(){const R=PZ.reg,Z=PZS();if(R&&R.house&&R.house.shortGuide&&Z.guide==='full')return 'short';return Z.guide}
