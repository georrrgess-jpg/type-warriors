# Wildcard Ranked leaderboard (89w) end to end, against local Nostr relays that store events like public ones:
#   A 18091 honest · B 18092 honest but slow (1.2 s) · C 18093 dishonest (stores anything, no checks) · 18099 dead
# Run from the source folder: PYTHONPATH=../../pylib python3 t_leaderboard.py [out.html]
import asyncio,json,os,subprocess,sys,time,random,hashlib
HERE=os.path.dirname(os.path.abspath(__file__));sys.path.insert(0,HERE)
import websockets
import t_nostr_tools as T
from playwright.async_api import async_playwright
PYLIB=os.path.abspath(os.path.join(HERE,'../../pylib'))
A,B,C,DEAD=18091,18092,18093,18099
URL=lambda p:f'ws://127.0.0.1:{p}'
RELAYS=[f'nostr:{URL(A)}',f'nostr:{URL(B)}',f'nostr:{URL(C)}',f'nostr:{URL(DEAD)}']
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:400]),flush=True)
    if not ok:FAIL.append(name)
def start(port,*flags):
    log=open(os.path.join(HERE,f'../lbt/relay{port}.log'),'w')
    return subprocess.Popen([sys.executable,'t_nostr_relay.py',str(port),*flags],cwd=HERE,env={**os.environ,'PYTHONPATH':PYLIB+':'+HERE},stdout=log,stderr=subprocess.STDOUT)
async def post(port,ev):
    async with websockets.connect(URL(port),max_size=2**22) as ws:
        await ws.send(json.dumps(['EVENT',ev]))
        while True:
            a=json.loads(await asyncio.wait_for(ws.recv(),10))
            if a[0]=='OK':return a[2]
async def post_many(port,evs):
    async with websockets.connect(URL(port),max_size=2**22) as ws:
        for ev in evs:await ws.send(json.dumps(['EVENT',ev]))
        ok=0
        for _ in evs:
            a=json.loads(await asyncio.wait_for(ws.recv(),30));ok+=a[0]=='OK' and a[2]
        return ok
async def query(port,f):
    out=[]
    async with websockets.connect(URL(port),max_size=2**24) as ws:
        await ws.send(json.dumps(['REQ','q',f]))
        while True:
            a=json.loads(await asyncio.wait_for(ws.recv(),10))
            if a[0]=='EOSE':return out
            if a[0]=='EVENT':out.append(a[2])
async def clear(*ports):
    for p in ports:
        async with websockets.connect(URL(p)) as ws:await ws.send(json.dumps(['TESTCLEAR']));await ws.recv()
def score(c):return c['r']*10**7+(c['lp'] if c['r']==5 else c['b'])
def honest(seed,places,r0=0,name=None,gap=90,t0=None):
    d,pk=T.keypair(seed);c,t=T.play(places,r0=r0,t0=t0,gap=gap);c['n']=name or f'Bot{seed}'
    return T.event(d,pk,c,min(t,int(time.time())-5)),c,pk
async def main():
    html='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else 'out.html')
    procs=[start(A),start(B,'--slow','1200'),start(C,'--noverify')];await asyncio.sleep(1.5)
    er=[]
    try:
        async with async_playwright() as pw:
            b=await pw.chromium.launch()
            async def player(name,relays=RELAYS):
                c=await b.new_context(viewport={'width':1600,'height':900});pg=await c.new_page()
                pg.on('pageerror',lambda e:er.append(name+' PE '+str(e)[:300]))
                pg.on('console',lambda m:er.append(name+' CE '+m.text[:300]) if m.type=='error' and 'WebSocket' not in m.text and 'ERR_CONNECTION_REFUSED' not in m.text else None)
                await pg.goto(html);await pg.wait_for_timeout(1200)
                await pg.evaluate("(a)=>{RS_ASK=false;WCRELAYS=a[0];P.name=a[1];P.gold=1e6;delete P.rk;save();rkSt();RKLB.t=0;RKLB.state='idle';RKLB.ver.clear()}",[relays,name])
                return c,pg
            # ---------------------------------------------------------------- 1. cryptography
            c1,pg=await player('Ava');E=pg.evaluate
            v=await E("""async()=>{const H=s=>Uint8Array.from(s.match(/../g).map(x=>parseInt(x,16)));
              const pk0='F9308A019258C31049344F85F89D5229B531C845836F99B08601F113BCE036F9'.toLowerCase(),s0='E907831F80848D1069A5371B402410364BDF1C5F8307B0084C55F1CE2DCA821525F66A4A85EA8B71E482A74F382D2CE5EBEEE8FDB2172F477DF4900D310536C0'.toLowerCase();
              const pk1='DFF1D77F2A671C5F36183726DB2341BE58FEAE1DA2DECED843240F7B502BA659'.toLowerCase(),m1=H('243F6A8885A308D313198A2E03707344A4093822299F31D0082EFA98EC4E6C89'),s1='6896BD60EEAE296DB48A229FF71DFE071BDE413E6D43F917DC8DCF8C78DE33418906D11AC976ABCCB20B091292BFF4EA897EFCB639EA871CFA95F6DE339E4B0A'.toLowerCase();
              const z=new Uint8Array(32),flip=(s,i)=>s.slice(0,i)+((parseInt(s[i],16)^1).toString(16))+s.slice(i+1);
              const o={v0:await rkSchnorrOk(pk0,z,s0),v1:await rkSchnorrOk(pk1,m1,s1),badsig:await rkSchnorrOk(pk0,z,flip(s0,70)),badr:await rkSchnorrOk(pk0,z,flip(s0,5)),badmsg:await rkSchnorrOk(pk1,z,s1),
                badpk:await rkSchnorrOk(pk1,z,s0),offcurve:await rkSchnorrOk('eefdea4cdb677750a420fee807eacf21eb9898ae79b9768766e4faa04a2d4a34',z,s0),short:await rkSchnorrOk(pk0,z,s0.slice(2)),
                rgep:await rkSchnorrOk(pk0,z,'ff'.repeat(32)+s0.slice(64)),sgen:await rkSchnorrOk(pk0,z,s0.slice(0,64)+'ff'.repeat(32))};
              const K=rkLbKey();let ok=0;const t=performance.now();for(let i=0;i<20;i++){const ev=await rkEvSign(K,30078,[['d','x']],'hello '+i+' é ✓ "q" \\n');if(await rkEvOk(ev))ok++}o.round=ok;o.ms=(performance.now()-t)/20;
              const ev=await rkEvSign(K,30078,[['d','x']],'{"a":1}');o.tamperC=await rkEvOk(Object.assign({},ev,{content:'{"a":2}'}));o.tamperT=await rkEvOk(Object.assign({},ev,{created_at:ev.created_at+1}));
              o.tamperK=await rkEvOk(Object.assign({},ev,{pubkey:pk1}));o.tamperS=await rkEvOk(Object.assign({},ev,{sig:flip(ev.sig,100)}));o.orig=await rkEvOk(ev);o.ev=ev;return o}""")
            chk('BIP-340 vector 0 verifies',v['v0']);chk('BIP-340 vector 1 verifies',v['v1'])
            for k in ('badsig','badr','badmsg','badpk','offcurve','short','rgep','sgen'):chk('BIP-340 rejects '+k,v[k] is False,v[k])
            chk('JS sign then JS verify, 20 events with unicode',v['round']==20,v['round']);print('   sign+verify per event ms',round(v['ms'],1))
            chk('tampered content/time/key/signature rejected',not any(v[k] for k in ('tamperC','tamperT','tamperK','tamperS')) and v['orig'],v)
            ev=v['ev'];ser=T.ser(ev);chk('JS event id = Python NIP-01 id',hashlib.sha256(ser.encode()).hexdigest()==ev['id'])
            chk('JS signature verifies in Python (independent BIP-340)',T.verify(bytes.fromhex(ev['pubkey']),bytes.fromhex(ev['id']),bytes.fromhex(ev['sig'])))
            pyev=[T.event(*T.keypair(900+i),json.dumps({'x':i,'s':'ünï ✓ "q"\n\t'}),int(time.time())-10) for i in range(6)]
            r=await E("async(evs)=>{const o=[];for(const e of evs)o.push(await rkEvOk(e));return o}",pyev)
            chk('Python-signed events verify in JS',all(r),r)
            # ---------------------------------------------------------------- 2. the checks
            now=int(time.time())
            def mk(c,seed=1,at=None,season=1,tags=None):
                d,pk=T.keypair(seed);return T.event(d,pk,c,at or now-30,tags=tags,season=season)
            good,t=T.play([0]*12);good['n']='Good'
            good2,_=T.play([0,1,2,3]*6,r0=0);good2['n']='Mixed'
            short,_=T.play([0,0,1,0,2,0,0],r0=0);short['n']='Short'
            leg,_=T.play([0]*20+[0,1,0,2,3,0,0],r0=0);leg['n']='Leg'
            r3,_=T.play([0]*5,r0=3);r3['n']='Started high'
            cases={'honest 12 wins':(good,True),'honest mixed 24':(good2,True),'honest legend':(leg,True),'honest season starting at Platinum':(r3,True)}
            def bad(name,**kw):
                c=json.loads(json.dumps(good));c.update(kw);cases[name]=(c,False)
            bad('legend after 12 matches',r=5,b=0,lp=100)
            bad('bar 99 at Bronze claimed with full history',r=0,b=99)
            bad('wins more than matches',w=13)
            bad('matches 0',m=0)
            bad('history too short',h=good['h'][:5])
            c=json.loads(json.dumps(good));c['h'][3][2]=40;cases['history points not in table']=(c,False)
            c=json.loads(json.dumps(good));c['h'][5][0]=c['h'][4][0]+5;cases['two wins 5 s apart']=(c,False)
            c=json.loads(json.dumps(good));c['h'][6][3]=0;cases['rank goes down in history']=(c,False)
            c=json.loads(json.dumps(good2));c['r']=3;cases['rank higher than history allows']=(c,False)
            bad('start rank 4',r0=4)
            bad('LP below Legend',lp=50)
            bad('bar out of range',b=100)
            bad('rank 6',r=6)
            bad('string numbers',r='2')
            bad('wrong season in content',s=2)
            bad('version 2',v=2)
            cases['honest 7 matches (whole season listed)']=(short,True)
            c=json.loads(json.dumps(short));c['b']=short['b']+10;cases['replay does not match bar']=(c,False)
            c=json.loads(json.dumps(short));c['w']=6;cases['replay does not match wins']=(c,False)
            c=json.loads(json.dumps(short));c['r0']=1;cases['replay: wrong start rank']=(c,False)
            c=json.loads(json.dumps(good));c['b']=good['b']+30;cases['bar higher than 12 matches can give']=(c,False)
            big=json.loads(json.dumps(leg));big.update(m=30,w=30,lp=4000);cases['4000 LP in 30 matches']=(big,False)
            pace=json.loads(json.dumps(leg));pace.update(m=200000,w=100);cases['200000 matches in 3 days']=(pace,False)
            evs=[[k,mk(cv),ok] for k,(cv,ok) in cases.items()]
            evs.append(['future time stamp',mk(good,at=now+3600),False]);evs.append(['before the season',mk(good,at=T.season_start(1)-7200),False])
            evs.append(['season 2 tag',mk(good,season=2),False]);evs.append(['no d tag',mk(good,tags=[['t','twwc-lb-s1']]),False])
            evs.append(['content not JSON',mk('{oops'),False]);evs.append(['content is an array',mk('[1,2]'),False])
            evs.append(['content too long',mk(json.dumps(dict(good,pad='x'*5000))),False])
            evs.append(['hide entry',mk({'v':1,'s':1,'hide':1}),'hide'])
            r=await E("(evs)=>evs.map(([k,ev])=>{const e=rkLbCheck(ev,1);return e?(e.hide?'hide':true):false})",[[k,e] for k,e,_ in evs])
            for (k,e,want),got in zip(evs,r):chk('check: '+k,got==want,f'want {want} got {got}')
            # names
            r=await E("""()=>[rkLbName('Ava'),rkLbName('  Long   name with spaces and more  '),rkLbName('a\\u202eevil'),rkLbName('zero\\u200bwidth'),rkLbName('sh1t head'),rkLbName('F.u.c.k'),rkLbName(''),rkLbName('\\u0000\\u0001'),rkLbName('🎉🎉'),rkLbName('Zoë'),rkLbName('<img src=x>'),rkLbName(null),rkLbName('Essex Sam'),rkLbName('Grape Hancock'),rkLbName('sexy pants'),rkLbName('Mr D1ck'),rkLbName('NAZI4life')]""")
            chk('names cleaned',r[0]=='Ava' and r[1]=='Long name with' and r[2]=='aevil' and r[3]=='zerowidth' and r[4]=='Player' and r[5]=='Player' and r[6]=='Player' and r[7]=='Player' and r[8]=='Player' and r[9]=='Zoë' and r[10]=='<img src=x>' and r[11]=='Player',r)
            chk('word filter: no false alarms, look-alikes caught',r[12:]==['Essex Sam','Grape Hancock','Player','Player','Player'],r[12:])
            # ---------------------------------------------------------------- 3. empty board, nothing posted before playing
            await clear(A,B,C)
            await E("()=>{rkHub()}");await pg.wait_for_timeout(300)
            st=await E("async()=>{await rkLbLoad(true);return [RKLB.state,RKLB.reached,RKLB.relays,RKLB.list.length,document.getElementById('rklbmr').textContent]}")
            chk('empty season: board loads from 3 of 4 relays',st[0]=='ok' and st[1]==3 and st[2]==4 and st[3]==0,st)
            chk('hub preview says no one yet',"No one is on the board yet" in st[4],st[4])
            q=await query(A,{'kinds':[30078]});chk('nothing posted before a ranked match',len(q)==0,len(q))
            await E("()=>rkBoard()");await pg.wait_for_timeout(700);await pg.screenshot(path='shots/lb_empty.png')
            # ---------------------------------------------------------------- 4. honest players + this player's matches
            seeds=[];ex=[]
            rnd=random.Random(7)
            for i in range(30):
                n=rnd.randint(1,45);places=[rnd.choice([0,0,1,1,2,3]) for _ in range(n)];r0=rnd.choice([0,0,0,1,2,3])
                e,cc,pk=honest(100+i,places,r0=r0,name=f'Bot{i:02d}');seeds.append(e);ex.append((score(cc),cc['w'],cc['m'],e['created_at'],pk,cc))
            okA=await post_many(A,seeds);okB=await post_many(B,seeds);okC=await post_many(C,seeds)
            chk('30 honest entries stored on all 3 relays',okA==30 and okB==30 and okC==30,(okA,okB,okC))
            ex.sort(key=lambda x:(-x[0],-x[1],x[2],x[3],x[4]))
            # this player plays four matches (times spread one minute apart, as real matches are)
            await E("()=>{window.__play=async ps=>{for(const p of ps)rkApply(p);const R=rkSt(),n=Date.now();R.hist.forEach((h,i,a)=>h.t=n-(a.length-i)*60000);save();await rkLbPush(true);await new Promise(r=>setTimeout(r,300));while(RKLB.p)await RKLB.p;return rkSt()}}")
            R=await E("async()=>{const R=await __play([0,0,1,2]);return [R.r,R.bar,R.sm,R.sw,R.lbPend,R.lbLast&&JSON.parse(R.lbLast).m]}")
            chk('four ranked matches: Bronze 90, counters, sent',R[:4]==[0,90,4,2] and not R[4] and R[5]==4,R)
            me=await E("()=>rkLbKey().pk")
            q=await query(A,{'kinds':[30078],'authors':[me]});chk('my entry is on relay A, once',len(q)==1 and json.loads(q[0]['content'])['m']==4,len(q))
            qb=await query(B,{'kinds':[30078],'authors':[me]});chk('my entry is on relay B',len(qb)==1)
            st=await E("async()=>{await rkLbLoad(true);return {n:RKLB.list.length,all:RKLB.all,place:RKLB.me&&RKLB.me.place,names:RKLB.list.map(e=>e.me?'ME':e.n),hid:RKLB.hidden}}")
            mysc=0*10**7+90;want=[x[5]['n'] for x in ex];pos=sum(1 for x in ex if (x[0],x[1],-x[2])>(mysc,2,-4))+1
            got=[n for n in st['names'] if n!='ME']
            chk('board order matches an independent sort',got==want,(got[:8],want[:8]))
            chk('my place is right and shown in the list',st['place']==pos and st['names'].index('ME')==pos-1 and st['all']==31,(st['place'],pos,st['all']))
            await E("()=>rkBoard()");await pg.wait_for_timeout(1500)
            ui=await E("()=>({place:document.getElementById('rkbplace').textContent,of:document.getElementById('rkbof').textContent,rows:document.querySelectorAll('#rkbrows .rkbr').length,me:document.querySelectorAll('#rkbrows .rkbr.me').length,st:document.getElementById('rkbst').textContent})")
            chk('board screen: place, rows, my row',ui['place']==f'#{pos}' and ui['rows']==31 and ui['me']==1 and 'of 31 players' in ui['of'],ui)
            chk('status names the relays',' 3 of 4 relays' in ui['st'],ui['st'])
            await pg.screenshot(path='shots/lb_board.png')
            # ---------------------------------------------------------------- 5. a second player, replaceable updates
            c2,pg2=await player('Ben');E2=pg2.evaluate
            await E2("()=>{window.__play=async ps=>{for(const p of ps)rkApply(p);const R=rkSt(),n=Date.now();R.hist.forEach((h,i,a)=>h.t=n-(a.length-i)*60000);save();await rkLbPush(true);await new Promise(r=>setTimeout(r,300));while(RKLB.p)await RKLB.p;return rkSt()}}")
            await E2("()=>__play([0,0,0,0])");ben=await E2("()=>rkLbKey().pk")
            await E2("()=>__play([0,0,0])")
            q=await query(A,{'kinds':[30078],'authors':[ben]});chk('second player updated: one entry, newest',len(q)==1 and json.loads(q[0]['content'])['m']==7,[json.loads(x['content'])['m'] for x in q])
            st=await E("async()=>{await rkLbLoad(true);const b=RKLB.list.find(e=>e.n==='Ben');return b&&[b.r,b.b,b.m,b.w,b.pk]}")
            chk('first player sees Ben at Silver 90 after 7 wins',st and st[:4]==[1,90,7,7] and st[4]==ben,st)
            # ---------------------------------------------------------------- 6. forgeries on the dishonest relay
            d9,pk9=T.keypair(999);benc=json.loads(q[0]['content'])
            def forged(pk,content,at):
                ev={'pubkey':pk,'created_at':at,'kind':30078,'tags':[['d','twwc-lb-s1'],['t','twwc-lb-s1'],['t','twwc-lb']],'content':json.dumps(content)}
                ev['id']=hashlib.sha256(T.ser(ev).encode()).hexdigest();ev['sig']=T.sign(d9,bytes.fromhex(ev['id']));return ev
            f1=forged(ben,{'v':1,'s':1,'hide':1},int(time.time())-2)  # someone else's key signing as Ben: invalid
            await post(C,f1)
            st=await E("async()=>{await rkLbLoad(true);const b=RKLB.list.find(e=>e.n==='Ben');return [!!b,RKLB.hidden]}")
            chk('forged "hide" for Ben does not hide him',st[0] and st[1]==0,st)
            f2=forged(ben,dict(leg,n='Ben'),int(time.time())-1);await post(C,f2)
            st=await E("async()=>{await rkLbLoad(true);const b=RKLB.list.find(e=>e.n==='Ben');return b&&[b.r,b.m]}")
            chk('forged Legend score for Ben ignored, real one kept',st==[1,7],st)
            f3=dict(q[0]);f3['content']=json.dumps(dict(benc,b=99));f3['created_at']=int(time.time());await post(C,f3)
            st=await E("async()=>{await rkLbLoad(true);const b=RKLB.list.find(e=>e.n==='Ben');return b&&[b.r,b.b]}")
            chk('tampered copy of Ben\'s real entry ignored',st==[1,90],st)
            f4=forged('ab'*32,dict(leg,n='Faker'),int(time.time())-3);await post(C,f4)
            st=await E("async()=>{await rkLbLoad(true);return RKLB.list.some(e=>e.n==='Faker')}")
            chk('entry with a bad signature never shown',st is False)
            # impossible scores with valid signatures, on an honest relay
            imp=[]
            for i,(cc) in enumerate([dict(good,r=5,b=0,lp=900,n='Cheat1'),dict(good,b=good['b']+30,n='Cheat2'),dict(big,n='Cheat3'),dict(good,w=99,m=12,n='Cheat4')]):
                d,pk=T.keypair(500+i);imp.append(T.event(d,pk,cc,int(time.time())-20))
            okA=await post_many(A,imp);chk('validly signed cheat entries accepted by the relay',okA==4)
            st=await E("async()=>{await rkLbLoad(true);return RKLB.list.filter(e=>/Cheat/.test(e.n)).map(e=>e.n)}")
            chk('impossible scores hidden from the board',st==[],st)
            # XSS and odd names, validly signed and plausible
            odd=[]
            for i,nm in enumerate(['<img src=x onerror="window.__xss=1">','<b>bold</b>','a‮evil','F.U.C.K',"O'Neil & co"]):
                e,cc,pk=honest(600+i,[0,0,1],name=nm);odd.append(e)
            await post_many(A,odd)
            await E("async()=>{await rkLbLoad(true);rkBoard()}");await pg.wait_for_timeout(1800)
            st=await E("()=>({xss:window.__xss||0,img:document.querySelectorAll('#rkbrows img').length,bold:document.querySelectorAll('#rkbrows .rkbn b b').length,names:[...document.querySelectorAll('#rkbrows .rkbn b')].map(b=>b.textContent)})")
            chk('names are shown as text, never as HTML',st['xss']==0 and st['img']==0 and st['bold']==0 and any(n.startswith('<img src=x') for n in st['names']) and '<b>bold</b>' in st['names'],st)
            chk('odd names cleaned on screen','aevil' in st['names'] and "O'Neil & co" in st['names'] and 'F.U.C.K' not in st['names'],[n for n in st['names'] if not n.startswith('Bot')])
            # ---------------------------------------------------------------- 7. hide toggle
            await E2("()=>rkBoard()");await pg2.wait_for_timeout(800)
            await pg2.click('.rkbtog [data-h="1"]');await pg2.wait_for_timeout(2500)
            st=await E2("()=>[rkSt().lbHide,document.getElementById('rkbplace').textContent]")
            chk('Ben turns the leaderboard off',st==[1,'Hidden'],st)
            st=await E("async()=>{await rkLbLoad(true);return [RKLB.list.some(e=>e.n==='Ben'),RKLB.hidden]}")
            chk('Ben is gone for others and counted as hidden',st==[False,1],st)
            await pg2.click('.rkbtog [data-h="0"]');await pg2.wait_for_timeout(2500)
            st=await E("async()=>{await rkLbLoad(true);return RKLB.list.some(e=>e.n==='Ben')}")
            chk('Ben turns it back on and is shown again',st is True)
            # ---------------------------------------------------------------- 8. offline, queue and retry
            await E("()=>{WCRELAYS=['nostr:ws://127.0.0.1:18099'];RKLB.t=0}")
            st=await E("async()=>{const R=await __play([0]);return [R.lbPend,R.sm]}")
            chk('offline: the new score waits on this device',st==[1,5],st)
            await E("()=>rkBoard()");await pg.wait_for_timeout(1500)
            st=await E("()=>[document.getElementById('rkbst').textContent,document.querySelectorAll('#rkbrows .rkbr').length,RKLB.state]")
            chk('offline: board shows the saved copy',st[0].startswith('Offline · showing the board saved') and st[1]>30 and st[2]=='offline',st)
            await pg.screenshot(path='shots/lb_offline.png')
            await E("(a)=>{WCRELAYS=a}",RELAYS)
            await E("async()=>{await rkLbLoad(true);await new Promise(r=>setTimeout(r,400));while(RKLB.p)await RKLB.p}")
            q=await query(A,{'kinds':[30078],'authors':[me]})
            st=await E("()=>rkSt().lbPend")
            chk('back online: the waiting score is sent',len(q)==1 and json.loads(q[0]['content'])['m']==5 and not st,(len(q),st))
            # empty relays + no cache: the no-connection message
            c3,pg3=await player('Cy',['nostr:ws://127.0.0.1:18099']);await pg3.evaluate("()=>rkBoard()");await pg3.wait_for_timeout(1500)
            st=await pg3.evaluate("()=>[document.querySelector('#rkbrows .rkbmt b')&&document.querySelector('#rkbrows .rkbmt b').textContent,!!document.getElementById('rkbretry')]")
            chk('no connection and nothing saved: clear message and Try again',st==["Couldn't reach the leaderboard",True],st)
            await pg3.screenshot(path='shots/lb_noconn.png')
            # ---------------------------------------------------------------- 9. new season
            st=await E("()=>{const n0=Date.now;Date.now=()=>n0.call(Date)+42*864e5;const R=rkSt();const o=[R.season,R.r0,R.sm,R.sw,R.lbLast];Date.now=n0;return o}")
            chk('new season: counters reset, start rank kept',st[0]==2 and st[2]==0 and st[3]==0 and st[4]=='',st)
            await E("()=>{const R=rkSt();R.season=1;R.sm=5;R.sw=3;R.r0=0;R.note='';save()}")
            # ---------------------------------------------------------------- 10. 650 players: top 100, paging, my place far down
            await clear(A,B,C)
            many=[]
            rnd=random.Random(11)
            t_s=time.time()
            for i in range(650):
                n=rnd.randint(6,60);places=[rnd.choice([0,0,1,2,3]) for _ in range(n)]
                e,cc,pk=honest(2000+i,places,r0=rnd.choice([1,2,3]),name=f'P{i:03d}',gap=60);many.append((e,cc))
            print('   signed 650 entries in',round(time.time()-t_s,1),'s')
            okA=await post_many(A,[e for e,_ in many]);chk('650 entries stored on relay A',okA==650,okA)
            await E("async()=>{const R=rkSt();R.r=0;R.bar=0;R.hist=[];R.sm=0;R.sw=0;R.r0=0;R.lbHide=0;save();const n=Date.now();rkApply(3);rkSt().hist.slice(-1)[0].t=n;save();while(RKLB.p)await RKLB.p}")
            t0=time.time()
            st=await E("async()=>{const t=performance.now();await rkLbLoad(true);return {ms:performance.now()-t,n:RKLB.list.length,all:RKLB.all,place:RKLB.me&&RKLB.me.place,last:RKLB.list[RKLB.list.length-1].me}}")
            print('   load + check + verify of 650 players:',round(st['ms']),'ms')
            chk('650 players: all counted across relay pages',st['all']==651,st)
            chk('top 100 shown plus me at the bottom',st['n']==101 and st['last'] and st['place']>=600,st)
            chk('loading 650 players takes under 8 s',st['ms']<8000,st['ms'])
            await E("()=>rkBoard()");await pg.wait_for_timeout(2000)
            st=await E("()=>({rows:document.querySelectorAll('#rkbrows .rkbr').length,gap:!!document.querySelector('#rkbrows .rkbgap'),place:document.getElementById('rkbplace').textContent,top:document.getElementById('rkbrows').scrollTop})")
            chk('board: 100 rows, a gap, my row after it, scrolled to me',st['rows']==101 and st['gap'] and st['place'].startswith('#') and st['top']>500,st)
            await pg.screenshot(path='shots/lb_far.png')
            exp=sorted(many,key=lambda x:(-score(x[1]),-x[1]['w'],x[1]['m'],x[0]['created_at'],x[0]['pubkey']))
            got=await E("()=>RKLB.list.filter(e=>!e.me).slice(0,100).map(e=>e.n)")
            chk('top 100 of 650 in the right order',got==[x[1]['n'] for x in exp[:100]],(got[:5],[x[1]['n'] for x in exp[:5]]))
            # ---------------------------------------------------------------- 11. hub preview and Legend panel
            await E("()=>rkHub()");await pg.wait_for_timeout(1500)
            st=await E("()=>({rows:document.querySelectorAll('#rklbmr .rkbr').length,me:document.querySelectorAll('#rklbmr .rkbr.me').length})")
            chk('hub preview: top 3 and my row',st=={'rows':4,'me':1},st)
            await pg.screenshot(path='shots/lb_hub.png')
            await pg.click('#rklbview');await pg.wait_for_timeout(600)
            chk('"View all" opens the board',await E("()=>!!document.getElementById('rkboard')"))
            await pg.keyboard.press('Escape');await pg.wait_for_timeout(600)
            chk('Escape goes back to Ranked',await E("()=>!!document.getElementById('rkhub')"))
            await E("async()=>{const R=rkSt();R.r=5;R.lp=640;R.bar=0;save();rkHub();await rkLbLoad(true)}");await pg.wait_for_timeout(1200)
            st=await E("()=>({near:document.querySelectorAll('#rklbnear .rkbr').length,me:document.querySelectorAll('#rklbnear .rkbr.me').length})")
            chk('Legend: players around you in the side panel',st['near']>=3 and st['me']==1,st)
            await pg.screenshot(path='shots/lb_hub_legend.png')
            await pg.click('#rklbview2');await pg.wait_for_timeout(600);chk('"Full leaderboard" opens the board',await E("()=>!!document.getElementById('rkboard')"))
            await pg.click('#rkback');await pg.wait_for_timeout(500);chk('back button goes to Ranked',await E("()=>!!document.getElementById('rkhub')"))
            # ---------------------------------------------------------------- 12. push throttle: back-to-back matches still end with the newest score
            await clear(A,B)
            await E("()=>{const R=rkSt();R.r=1;R.bar=0;R.lp=0;R.hist=[];R.sm=0;R.sw=0;R.r0=0;save()}")
            await E("async()=>{rkApply(1);await new Promise(r=>setTimeout(r,50));rkApply(2);await new Promise(r=>setTimeout(r,50));rkApply(1)}")
            await pg.wait_for_timeout(17500)
            q=await query(A,{'kinds':[30078],'authors':[me]})
            chk('three quick matches: relay ends with the newest (3 matches)',len(q)==1 and json.loads(q[0]['content'])['m']==3,[json.loads(x['content'])['m'] for x in q])
            # ---------------------------------------------------------------- 13. a real ranked match, played to the end by the test agent
            c4,pg4=await player('Dee');E4=pg4.evaluate
            await E4("()=>{rkHub()}");await pg4.wait_for_timeout(800);await E4("()=>rkStart()");await pg4.wait_for_timeout(1500)
            await pg4.add_script_tag(path=os.path.abspath('t_wc_agent.js'));t0=time.time()
            while time.time()-t0<420 and not await E4("()=>!!document.getElementById('rkres')"):await pg4.wait_for_timeout(1000)
            dur=time.time()-t0;await pg4.wait_for_timeout(3000);await E4("()=>clearInterval(window.__agT)")
            st=await E4("async()=>{while(RKLB.p)await RKLB.p;const R=rkSt();return [!!document.getElementById('rkres'),R.sm,R.hist.length,R.lbPend,rkLbKey().pk]}")
            print('   real match took',round(dur),'s')
            chk('real ranked match finished and its score was sent',st[0] and st[1]==1 and st[2]==1 and not st[3],st)
            q=await query(A,{'kinds':[30078],'authors':[st[4]]})
            chk('the relay has the real match entry',len(q)==1 and json.loads(q[0]['content'])['m']==1)
            r=await E("async()=>{await rkLbLoad(true);const d=RKLB.list.find(e=>e.n==='Dee');return d&&[d.m,d.r]}")
            chk('another player sees the real match on the board',r is not None and r[0]==1,r)
            for p in (pg,pg2,pg3):await p.wait_for_timeout(10)
            await b.close()
    finally:
        for p in procs:p.terminate()
    real=[e for e in er if 'Failed to load resource' not in e]
    chk('no page errors',not real,real[:5])
    print(f'\n{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else None
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
