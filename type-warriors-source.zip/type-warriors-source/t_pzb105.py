# python3 t_pzb105.py [out.html] : 10.6 The Crooked Cue premium ball sets (97b6 painter, 97b7-97b9 sets, 97ba Cue Rack strip).
# The six premium sets (Harvest Amber 15,000, Cathedral Glass 20,000, Glacier Crystal 25,000, Dragonscale 35,000, Aurora Opal 50,000,
# Diamond Brilliance 75,000) exist with their prices (all above every older shop set), older sets are unchanged, they are bought in the Cue Rack
# by holding the button (coins taken once, owned and equipped), they paint balls in a match and in the Cue Rack demo, the ball tab holds fourteen
# cards that scroll (arrows, PREMIUM marks, the equipped set scrolled into view) with no overlaps at 1600x900 / 1280x720 / 1024x640, the DEV
# "own everything" cheat covers them, no page errors. (The owner's readability rule for every set is measured by t_pzb102.py.)
import asyncio,os,sys,json
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
SHOTS=os.path.join(HERE,'shots','w106_balls');os.makedirs(SHOTS,exist_ok=True)
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:500]),flush=True)
    if not ok:FAIL.append(name)
PRE="()=>{PZ_TUT_OFF=true;RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}return 1}"
SETS=[('amber',15000),('cathedral',20000),('glacier',25000),('dragon',35000),('opal',50000),('diamond',75000)]
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();er=[]
        pg=await b.new_page(viewport={'width':1600,'height':900});pg.on('pageerror',lambda e:er.append(str(e)[:300]));E=pg.evaluate
        await pg.goto(H);await pg.wait_for_timeout(1400);await E(PRE)
        r=await E("()=>PZ_BALLS.map(b=>[b.id,b.price==null?-1:b.price,!!b.prem,!!PZ_BPAL[b.id],(PZ_TAG97[b.id]||'').length>8,b.n])")
        ids=[x[0] for x in r];prem=[x for x in r if x[2]]
        chk('PZ_BALLS lists the six premium sets in price order, each with a palette, a tag line and a name',[x[0] for x in prem]==[s for s,_ in SETS] and [x[1] for x in prem]==[q for _,q in SETS] and all(x[3] and x[4] and x[5] for x in prem),r)
        old=dict((x[0],x[1]) for x in r if not x[2])
        chk('the older sets and their prices are unchanged (classic free, Gemstone 6,000, Carrara 2,500, Neon Nights 8,000) and every premium price is above them all',old.get('classic')==0 and old.get('gem')==6000 and old.get('marble')==2500 and old.get('neon')==8000 and min(q for _,q in SETS)>max(v for v in old.values()),old)
        # paint: every premium set paints all 16 balls with a visible, distinct, non-empty image
        r=await E("""()=>{const out={},D=64;const M=pzbRot(pzbRot(pzbI(),0,1,0,.4),1,0,0,-.2);for(const [id] of %s){pzbSetup(D,id);const row=[];for(let n=0;n<16;n++){pzbPaint(15,n,M);const d=PZ_BS.ax.getImageData(15*D,0,D,D).data;let px=0,s=0,h=0;for(let i=0;i<d.length;i+=4)if(d[i+3]>20){px++;s+=d[i]+d[i+1]+d[i+2];h=(h*31+d[i]+d[i+1]*3+d[i+2]*7)|0}row.push([px,Math.round(s/Math.max(1,px)/3),h])}out[id]=row}pzbSetup(64,'classic');return out}"""%json.dumps(SETS))
        okp=all(all(x[0]>2800 for x in row) for row in r.values());sig=[tuple(x[2] for x in row) for row in r.values()]
        chk('every premium set paints all sixteen balls full (cue to 15), and no two sets paint alike',okp and len(set(sig))==6,{k:[x[0] for x in v][:3] for k,v in r.items()})
        # buying in the Cue Rack: hold the button, coins taken once, owned and equipped
        await E("()=>{const Z=PZS();for(const s of %s)delete Z.ballsets[s];Z.balls='classic';P.gold=40000;save();PZ.rackTab='balls';PZ.rackSel=null;pzCueRack();0}"%json.dumps([s for s,_ in SETS]));await pg.wait_for_timeout(1500)
        g0=await E("()=>P.gold");await pg.evaluate("()=>{const s=document.querySelector('.pzkbstrip');s.scrollLeft=s.scrollWidth}");await pg.wait_for_timeout(300)
        await pg.click('.pzki[data-i=glacier]');await pg.wait_for_timeout(400)
        await pg.hover('#pzkbuy');await pg.mouse.down();await pg.wait_for_timeout(1700);await pg.mouse.up();await pg.wait_for_timeout(500)
        r=await E("()=>[P.gold,!!PZS().ballsets.glacier,PZS().balls,PZ_BS.set]")
        chk('hold to buy: Glacier Crystal costs exactly 25,000 once, is owned and equipped',r[0]==g0-25000 and r[1] and r[2]=='glacier',r)
        g1=await E("()=>P.gold");await pg.click('.pzki[data-i=amber]');await pg.wait_for_timeout(300)
        await pg.hover('#pzkbuy');await pg.mouse.down();await pg.wait_for_timeout(300);await pg.mouse.up();await pg.wait_for_timeout(300)
        r=await E("()=>[P.gold,!!PZS().ballsets.amber]");chk('letting go early buys nothing',r[0]==g1 and not r[1],r)
        await E("()=>{P.gold=14999;pzRk97Wall();pzRk97Detail()}");await pg.wait_for_timeout(300);await pg.click('.pzki[data-i=amber]');await pg.wait_for_timeout(300)
        await pg.hover('#pzkbuy');await pg.mouse.down();await pg.wait_for_timeout(1700);await pg.mouse.up();await pg.wait_for_timeout(300)
        r=await E("()=>[P.gold,!!PZS().ballsets.amber]");chk('with 1 coin too few nothing is bought',r[0]==14999 and not r[1],r)
        # the strip
        r=await E("()=>{const s=document.querySelector('.pzkbstrip'),c=[...s.querySelectorAll('.pzkbc')];return [c.length,c.filter(x=>x.classList.contains('prem')).length,Math.min(...c.map(x=>x.getBoundingClientRect().width)),s.scrollWidth>s.clientWidth,!!document.querySelector('.pzkbnav')]}")
        chk('the ball tab has fourteen cards of full size, six marked PREMIUM, scrolls and has arrows',r[0]==14 and r[1]==6 and r[2]>=150 and r[3] and r[4],r)
        await E("()=>{const Z=PZS();Z.balls='dragon';Z.ballsets.dragon=1;save();pzCueRack();0}");await pg.wait_for_timeout(1500)
        r=await E("()=>{const s=document.querySelector('.pzkbstrip'),e=s.querySelector('.pzkbc.sel'),a=e.getBoundingClientRect(),b=s.getBoundingClientRect();return [a.left>=b.left-2&&a.right<=b.right+2,s.scrollLeft>0]}")
        chk('opening the tab scrolls the equipped set into view',r[0] and r[1],r)
        await pg.screenshot(path=os.path.join(SHOTS,'rack_dragon_1600.png'))
        # DEV cheat and a match
        await E("()=>{devAct('x:pzown');0}");r=await E("()=>PZ_BALLS.every(b=>PZS().ballsets[b.id])");chk('the DEV "own everything" cheat covers the premium sets',r)
        for s,_ in SETS:
            await E("(s)=>{PZS().ballsets[s]=1;PZS().balls=s;save()}",s)
        await E("()=>{casinoOpen();gameOpen('pz');pzStart({opp:'gloop',practice:true,seed:7});setTimeout(()=>{const i=document.getElementById('pzintro');if(i)i.click()},500);0}");await pg.wait_for_timeout(3500)
        r=await E("()=>[PZ.on,PZ_BS.set,!!PZ.B&&PZ.B.length>=16]");chk('a match starts with a premium set equipped and paints the table',r[0] and r[1]=='diamond' and r[2],r)
        await pg.screenshot(path=os.path.join(SHOTS,'match_diamond_1600.png'))
        chk('no page errors (1600x900)',not er,er)
        await pg.close()
        # fit at three sizes
        OVL=open(os.path.join(HERE,'..','tools','td','rpu_ovl.js')).read()
        for vw,vh in [(1600,900),(1280,720),(1024,640)]:
            pg=await b.new_page(viewport={'width':vw,'height':vh});er2=[];pg.on('pageerror',lambda e:er2.append(str(e)[:300]))
            await pg.goto(H);await pg.wait_for_timeout(1300);await pg.evaluate(PRE)
            await pg.evaluate("()=>{const Z=PZS();for(const b of PZ_BALLS)Z.ballsets[b.id]=1;Z.balls='opal';P.gold=100000;save();PZ.rackTab='balls';PZ.rackSel=null;pzCueRack();0}");await pg.wait_for_timeout(1700)
            r=await pg.evaluate("()=>{const w=document.getElementById('pzkwall').getBoundingClientRect(),o=[];for(const c of document.querySelectorAll('.pzkbc')){const a=c.getBoundingClientRect();const s=c.parentElement.getBoundingClientRect();if(a.right<s.left||a.left>s.right)continue;const t=c.querySelector('b');if(t&&t.scrollWidth>t.clientWidth+1&&!c.classList.contains('prem'))o.push('clipped '+t.textContent);if(a.top<w.top-1||a.bottom>w.bottom+1)o.push('card outside the wall '+c.dataset.i)}return o}")
            chk(f'Cue Rack ball tab at {vw}x{vh}: visible cards stay inside the wall, names not clipped',r==[],r)
            await pg.screenshot(path=os.path.join(SHOTS,f'rack_{vw}x{vh}.png'))
            chk(f'no page errors at {vw}x{vh}',not er2,er2);await pg.close()
        await b.close()
    print(f'\n{N[0]-len(FAIL)} / {N[0]} passed',flush=True)
    if FAIL:print('FAILED:',FAIL)
asyncio.run(main())
