window.__ag={acts:0,picks:0,catches:0,calls:0,errs:[]};
window.__agT=setInterval(()=>{try{const G=WX.G;if(!G||!document.getElementById('wct'))return;
 const pk=document.querySelector('#wcmod:not([hidden]) [data-col]');if(pk){pk.click();__ag.picks++;return}
 if(G.one&&G.one.p!==WX.me&&G.P[G.one.p].kind==='bot'&&Math.random()<.5){const a=document.querySelector(`.wcseat[data-seat="${G.one.p}"] .wcav`);if(a){a.click();__ag.catches++}return}
 if(WX.busy||!wcMine())return;const me=G.P[WX.me];const sv=me.diff;me.diff='h';const a=wcBot(G,WX.me);me.diff=sv;
 if(G.phase==='drawn'){const b=a.t==='play'?document.getElementById('wcplayd'):document.getElementById('wckeep');if(b){b.click();__ag.acts++}return}
 if(a.t==='draw'){document.getElementById('wcdeck').click();__ag.acts++;return}
 const c=me.hand[a.i];if(me.hand.length===2&&!me.called){document.getElementById('wcone').click();__ag.calls++}
 const el=document.querySelector(`.wchc[data-id="${c.id}"]`);if(el){el.click();__ag.acts++}}catch(e){__ag.errs.push(String(e))}},250);
