# A minimal local Nostr relay for testing Wildcard's Nostr path (89q). It checks every event the way public relays do:
# the id must be the SHA-256 of the NIP-01 serialisation and the signature must be a valid BIP-340 Schnorr signature.
# The verifier below is written independently from the BIP-340 specification, not from the game's JavaScript.
# Run: PYTHONPATH=<dir with websockets> python3 t_nostr_relay.py [port]   (default 18090). Prints counts on stdout.
import asyncio,hashlib,json,sys
import websockets
p=2**256-2**32-977;n=0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141
G=(0x79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798,0x483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8)
def add(P1,P2):
    if P1 is None:return P2
    if P2 is None:return P1
    if P1[0]==P2[0] and P1[1]!=P2[1]:return None
    lam=(3*P1[0]*P1[0]*pow(2*P1[1],p-2,p))%p if P1==P2 else ((P2[1]-P1[1])*pow(P2[0]-P1[0],p-2,p))%p
    x=(lam*lam-P1[0]-P2[0])%p;return (x,(lam*(P1[0]-x)-P1[1])%p)
def mul(P,k):
    R=None
    for i in range(256):
        if (k>>i)&1:R=add(R,P)
        P=add(P,P)
    return R
def lift_x(x):
    if x>=p:return None
    c=(pow(x,3,p)+7)%p;y=pow(c,(p+1)//4,p)
    if pow(y,2,p)!=c:return None
    return (x,y if y%2==0 else p-y)
def th(tag,m):
    h=hashlib.sha256(tag.encode()).digest();return hashlib.sha256(h+h+m).digest()
def verify(pk,m,sig):
    P=lift_x(int.from_bytes(pk,'big'))
    if P is None:return False
    r=int.from_bytes(sig[:32],'big');s=int.from_bytes(sig[32:],'big')
    if r>=p or s>=n:return False
    e=int.from_bytes(th('BIP0340/challenge',sig[:32]+pk+m),'big')%n
    R=add(mul(G,s),mul(P,n-e))
    return R is not None and R[1]%2==0 and R[0]==r
SUBS={};ST={'ok':0,'bad':0,'fwd':0}
def match(f,ev):
    if 'kinds' in f and ev['kind'] not in f['kinds']:return False
    for k,v in f.items():
        if k.startswith('#'):
            vals=[t[1] for t in ev.get('tags',[]) if len(t)>1 and t[0]==k[1:]]
            if not any(x in v for x in vals):return False
    return True
async def handle(ws):
    SUBS[ws]={}
    try:
        async for raw in ws:
            try:a=json.loads(raw)
            except Exception:continue
            if a[0]=='REQ':SUBS[ws][a[1]]=a[2:];await ws.send(json.dumps(['EOSE',a[1]]))
            elif a[0]=='CLOSE':SUBS[ws].pop(a[1],None)
            elif a[0]=='EVENT':
                ev=a[1];ser=json.dumps([0,ev['pubkey'],ev['created_at'],ev['kind'],ev['tags'],ev['content']],separators=(',',':'),ensure_ascii=False)
                idb=hashlib.sha256(ser.encode()).digest()
                ok=idb.hex()==ev['id'] and verify(bytes.fromhex(ev['pubkey']),idb,bytes.fromhex(ev['sig']))
                ST['ok' if ok else 'bad']+=1;await ws.send(json.dumps(['OK',ev['id'],ok,'' if ok else 'invalid: bad id or signature']))
                if not ok:print('REJECTED',ev['id'][:12],flush=True);continue
                for c,subs in list(SUBS.items()):
                    for sid,fs in subs.items():
                        if any(match(f,ev) for f in fs):
                            ST['fwd']+=1
                            try:await c.send(json.dumps(['EVENT',sid,ev]))
                            except Exception:pass
    finally:SUBS.pop(ws,None)
async def report():
    while True:
        await asyncio.sleep(5);print('stats',ST,flush=True)
async def main():
    port=int(sys.argv[1]) if len(sys.argv)>1 else 18090
    async with websockets.serve(handle,'127.0.0.1',port,max_size=2**20):
        print('nostr relay on',port,flush=True);await report()
asyncio.run(main())
