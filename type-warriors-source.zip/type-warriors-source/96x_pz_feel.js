/* ===== 9.5 THE CROOKED CUE: feel and fairness at the table (96x) =====
   From the first-time playtest:
   - The aim holds still while the pointer is over the HUD (the bottom bar, the top cards, the far edges), so reaching for
     SHOOT, the power bar or the spin ball never swings the cue.
   - A shot needs a real pull: at least 7% power, mostly straight back. A sideways flick or a plain click says how instead.
   - On the break, a cue ball you pick up and drag drops where you let go.
   - No shot clock against Gloop or in your very first match.
   - A run counter: every pot in the same visit lifts a "RUN x3" badge and a rising chime; a ball that rattles in the jaws
     gets "So close!" (or a cheer when it is the monster's).
   - A hold-to-speed-up button while the balls roll or the monster plays.
   - A one-time first-win bonus for each regular (100 gold per level), shown on the results.
   Floats that would land on top of each other stack upwards. */
const PZ_AIMZ={x0:118,x1:1482,y0:126,y1:742};
{const f0=pzBindMatch;pzBindMatch=function(tok){const r=f0.apply(this,arguments);try{const cv=PZ.cv;
 cv.addEventListener('pointermove',e=>{if(PZ.tok!==tok||PZ.ph!=='aim'||PZ.mode!=='aim'||PZ.drag||PZ.dragT||e.shiftKey||PZ.fineBtn)return;const p=pzXY(e);
  if(p.x<PZ_AIMZ.x0||p.x>PZ_AIMZ.x1||p.y<PZ_AIMZ.y0||p.y>PZ_AIMZ.y1){e.stopImmediatePropagation();PZ.lastPtr=null}},true);
 cv.addEventListener('pointerdown',e=>{if(PZ.tok!==tok||e.button===2)return;const p=pzXY(e);PZ.pd={x:p.x,y:p.y,mode:PZ.mode,ph:PZ.ph}},true);
 cv.addEventListener('pointerup',e=>{if(PZ.tok!==tok||e.button===2)return;const p=pzXY(e),pd=PZ.pd;PZ.pd=null;
  /* a cue ball picked up on the break drops where you let go */
  if(PZ.ph==='aim'&&PZ.mode==='place'&&pd&&pd.mode==='aim'&&Math.hypot(p.x-pd.x,p.y-pd.y)>12){const pl=PZ.place;if(pl&&pl.ok){pzPlaceCue(pl.x,pl.y);e.stopImmediatePropagation();return}}
  const d=PZ.drag;if(!d||d.id!==e.pointerId||PZ.ph!=='aim'||PZ.mode!=='aim')return;const dist=Math.hypot(p.x-d.sx,p.y-d.sy),pow=PZ.aim.pow;
  if(dist<=10){if(!pd||pd.ph==='aim')pztHint('Press on the table, pull straight back and let go to shoot (or use SHOOT).');return}
  const pull=(d.sx-p.x)*Math.cos(d.ang)+(d.sy-p.y)*Math.sin(d.ang);if(pow<.07||pull/dist<.55){PZ.drag=null;PZ.aim.pow=PZ.lastPow||.5;pzHudBar();pzFx('no');pztHint('Pull straight back from the cue ball, then let go.');e.stopImmediatePropagation()}},true);
 }catch(err){}return r}}
function pztHint(t){const n=performance.now();if(PZ.hintAt&&n-PZ.hintAt<2500&&PZ.hintTx===t)return;PZ.hintAt=n;PZ.hintTx=t;try{pzSub(t,2200)}catch(e){}}
/* no shot clock against Gloop or in the very first match */
{const f0=pzBeginTurn;pzBeginTurn=function(){const r=f0.apply(this,arguments);try{const Z=PZS(),M=PZ.M;if(PZ.clockOn&&M&&(M.opp==='gloop'||((Z.wins||0)+(Z.losses||0))===0)){PZ.clockOn=false;pzHudClock()}}catch(e){}return r}}
/* runs and near misses */
PZSFX.run=(t,n)=>{const f=660*Math.pow(2,Math.min(12,n*2)/12);wcTone(t,f,.12,'sine',.07,{r:.2});wcTone(t+.06,f*1.5,.14,'triangle',.04,{r:.25})};
PZSFX.close=t=>{wcTone(t,300,.18,'sine',.06,{to:180});wcNz(t,.12,.04,900,'bandpass',2)};
{const f0=pzJudgeShot;pzJudgeShot=function(silent){const who=PZ.st?PZ.st.turn:-1;const r=f0.apply(this,arguments);try{if(silent||!PZ.M||PZ.M.trick)return r;const rep=PZ.rep||{},pk=rep.pk||[];
  if(who===0){if(pk.length&&!rep.foul){PZ.run=(PZ.run||0)+pk.length;if(PZ.run>=2&&rep.keep){pzFloat(800,182,`RUN ×${PZ.run}`,PZ.run>=5?'#ff9a4a':'#ffd45a');pzSound('run',PZ.run);if(PZ.run===4||PZ.run===6)pzCastReact('mon','rattled',1400)}}if(!rep.keep||rep.foul)PZ.run=0}
  else PZ.run=0;
  /* a ball that kissed a jaw and stayed up */
  if(!pk.length&&PZ.ev&&PZ.B){const j=PZ.ev.find(e=>e.t==='cu'&&e.j&&e.a>0&&PZ.B[e.a]&&PZ.B[e.a].on);if(j){const b=PZ.B[j.a];pzFloat(PZ_G.x+b.x,PZ_G.y+b.y-30,who===0?'So close!':'Rattled out!',who===0?'#ff9ad0':'#8affb4');pzSound('close');
   if(who===0)pzCastReact('mon','smug',1200);else{pzCastReact('hero','happy',1200);pzCastReact('mon','angry',1200)}}}}catch(e){}return r}}
{const f0=pzStart;pzStart=function(){const r=f0.apply(this,arguments);PZ.run=0;return r}}
/* floats stack instead of landing on each other */
function pzFloat(x,y,text,col){for(const f of PZ.floats||[]){if(f.t<.6&&Math.abs(f.x-x)<170&&Math.abs(f.y-y)<40)y=f.y-40}PZ.floats.push({x,y,text,col,t:0,d:1.3})}
/* hold-to-speed-up button while the balls roll or the monster plays */
{const f0=pzMount;pzMount=function(){const r=f0.apply(this,arguments);try{const m=$('pzm');if(m&&!$('pzffb')){const b=document.createElement('button');b.id='pzffb';b.className='pzffb';b.innerHTML='<i></i><i></i> Hold to speed up';m.appendChild(b);
  const on=e=>{e.preventDefault();PZ.ffHeld=true;if(PZ.ph==='ai'&&PZ.ai)PZ.ai.skip=true;if(PZ.ph==='rerack'&&PZ.rk)PZ.rk.t=Math.max(PZ.rk.t,PZ.rk.dur-.05)},off=()=>{PZ.ffHeld=false};
  b.addEventListener('pointerdown',on);for(const ev of['pointerup','pointerleave','pointercancel'])b.addEventListener(ev,off);clearInterval(PZ.ffIv);PZ.ffIv=setInterval(pzFfTick,200)}}catch(e){}return r}}
function pzFfTick(){const b=$('pzffb');if(!b||!b.isConnected){clearInterval(PZ.ffIv);PZ.ffIv=0;return}const busy=PZ.on&&PZ.M&&!PZ.M.trick&&!PZ.modal&&(PZ.ph==='ai'||PZ.ph==='roll'||PZ.ph==='settle'||PZ.ph==='gap'||PZ.ph==='rerack');if(b._on!==busy){b._on=busy;b.classList.toggle('on',busy)}}
/* first win against each regular: a one-time bonus, shown on the results */
{const f0=pzMatchEnd;pzMatchEnd=function(){const M=PZ.M,Z=PZS();let fb=0;try{if(M&&!M.practice&&M.over&&M.over.winner===0&&M.opp!=='shade'&&!(Z.beat[M.opp]>0)&&!(Z.first||{})[M.opp]){const R=PZ_REG[M.opp];fb=100*(R.lvl||1)}}catch(e){}
 if(fb){try{Z.first=Z.first||{};Z.first[M.opp]=1;ecSrc('pool',()=>{P.gold+=fb;balUp(fb)});Z.net=(Z.net||0)+fb;save();PZ.fbPending=fb}catch(e){}}
 try{return f0.apply(this,arguments)}finally{PZ.fbPending=0}}}
{const st=document.createElement('style');st.textContent=`
.pzffb{position:absolute;left:1306px;top:792px;height:48px;padding:0 16px 0 12px;border-radius:16px;border:3px solid #12081f;background:linear-gradient(180deg,#3a2f8a,#1e1660);color:#efe8ff;font:800 14px Poppins,sans-serif;cursor:pointer;display:flex;align-items:center;gap:2px;opacity:0;pointer-events:none;transform:translateY(8px);transition:opacity .2s,transform .2s;z-index:6}
.pzffb.on{opacity:1;pointer-events:auto;transform:none}.pzffb:active{transform:scale(.96)}
.pzffb i{width:0;height:0;border:8px solid transparent;border-left:11px solid #ffd45a;border-right:0;margin-right:1px}.pzffb i+i{margin-right:8px}
.pzun.fb{border-color:#ffd45a}.pzun.fb b{color:#ffd45a}
`;document.head.appendChild(st)}
