/* ===== 9.4 THE CROOKED CUE: sound (96l) =====
   Music: "Back Room Blues", a swinging tavern tune synthesised live at the casino's tempo, through the casino's music buses so the
   Music setting applies. Levels: 0 hub (walking bass, brushes, sparse piano), 1 match (+ ride, comping, a lazy lead), 2 the 8 (stop-time).
   Effects go through the sound-effects volume. Everything reuses the casino voices (wcv, wcKick, kns, wcNz, wcTone). */
const PZM={lv:0,s:0,n0:0,B:null,bk:null,last:{click:0,n:0}};
const pzMusic=()=>{try{return CAS.on&&ov.classList.contains('pzx')&&!ov.classList.contains('hide')}catch(e){return false}};
const pzMusicOn=()=>{try{ensureAudio()}catch(e){}};const pzMusicOff=()=>{PZM.s=0};
/* chords per bar: [root midi, quality] ii-V-I-ish in A minor and C, 16 bars */
const PZ_CH=[[57,'m7'],[50,'m7'],[55,'7'],[48,'M7'],[53,'M7'],[59,'m7b5'],[52,'7'],[57,'m7'],[62,'m7'],[55,'7'],[48,'M7'],[53,'M7'],[50,'m7'],[55,'7'],[57,'m7'],[52,'7']];
const PZ_Q={m7:[0,3,7,10],'7':[0,4,7,10],M7:[0,4,7,11],m7b5:[0,3,6,10]};
const PZ_LEAD=(()=>{const _=null;return [[76,_,_,79,_,76,_,_],[74,_,_,_,77,_,74,_],[71,_,_,74,_,_,71,_],[72,_,_,_,_,76,_,_],[77,_,_,_,76,_,72,_],[74,_,71,_,_,_,_,_],[71,_,_,76,_,_,75,_],[76,_,_,_,_,_,_,_],
 [77,_,_,81,_,77,_,_],[79,_,_,_,74,_,71,_],[72,_,76,_,_,79,_,_],[77,_,_,_,_,_,72,_],[74,_,_,77,_,74,_,_],[71,_,_,_,74,_,_,_],[72,_,_,_,69,_,_,_],[68,_,71,_,76,_,_,_]]})();
function pzBus(lv){const K=kInit();if(!PZM.B||PZM.bk!==K){PZM.bk=K;PZM.B={};for(const k of['pc','st','br']){const g=ac.createGain();g.connect(K[k]);PZM.B[k]=g}}
 const duck=PZ.slow&&PZ.slow.on?.18:1,m=(lv?1.15:1.5)*duck;for(const k in PZM.B)PZM.B[k].gain.value=m;return PZM.B}
function pzLevel(){try{if(!PZ.on||!PZ.st)return PZ.hub||!PZ.on?0:0;if(PZ.ph==='over')return 0;return pzrOn8(PZ.st)&&PZ.ph!=='intro'?2:1}catch(e){return 0}}
function pzScore(t,n0){if(!PZM.s){PZM.s=1;PZM.n0=n0}KS.on=0;const n=n0-PZM.n0,bar=(n>>3)&15,k=n&7,sd=stepD(),sw=(k%2)?sd*.16:0;if(k===0)PZM.lv=pzLevel();const lv=PZM.lv,B=pzBus(lv),[root,q]=PZ_CH[bar],ch=PZ_Q[q];
 /* walking bass on the quarter notes (steps 0,2,4,6) */
 if(k%2===0){const walk=[0,ch[1],ch[2],ch[3]][k/2];wcv(t,mf(root-24+walk),sd*1.8,{w:'triangle',lp:lv===2?700:1000,v:lv?.085:.07,a:.008,r:.1,bus:B.pc})}
 /* brushes and ride (swing: the offbeat eighth is late) */
 kns(t+sw,.04,lv?.05:.035,7500,'highpass',B.pc);if(k%2===0)kns(t,.02,lv?.04:.03,9000,'highpass',B.pc);
 if(lv>0){if(k===0||k===4)wcKick(t,.22,B.pc);if(k===2||k===6){kns(t,.09,.08,1700,'bandpass',B.pc,.8)}
}
 /* piano comping on 2 and 4 (and the odd push) */
 if((k===2||k===6||(lv>0&&k===3&&bar%4===1))&&!(lv===2&&k===6)){const root2=root+12;for(const i of ch.slice(1))wcv(t+(k===3?sd*.16:0),mf(root2+i),sd*.9,{w:'triangle',lp:2400,v:.022,a:.006,r:.35,bus:B.st,det:(i%3-1)*5});wcv(t,mf(root2+ch[1]+12),sd*.5,{w:'sine',lp:3000,v:.012,a:.003,r:.3,bus:B.st})}
 /* a lazy lead with a little vibrato (only at the table) */
 const nt=PZ_LEAD[bar][k];if(nt!=null&&lv>0&&!(lv===2&&bar%2===0)){let len=1;while(k+len<8&&PZ_LEAD[bar][k+len]===null&&len<4)len++;wcv(t+sw,mf(nt),sd*len*.95,{w:'square',lp:2000,v:.022,a:.02,r:.18,bus:B.br,det:Math.sin(n*.9)*8});wcv(t+sw,mf(nt+12),sd*len*.5,{w:'sine',lp:3200,v:.008,a:.02,r:.1,bus:B.br})}
 /* hub: a sparse upper chime */
 if(lv===0&&k===5&&bar%2===0)wcv(t,mf(root+24+ch[2]),sd*2,{w:'sine',lp:3500,v:.014,a:.004,r:.5,bus:B.br})}
{const n0=note;note=function(t,n){if(pzMusic())return pzScore(t,n);if(PZM.s)PZM.s=0;return n0(t,n)}}
/* ---------- sound effects ---------- */
const pzT=()=>ac.currentTime+.003;
const pzClickGate=()=>{const n=performance.now();if(n-PZM.last.click>60){PZM.last.click=n;PZM.last.n=0}return ++PZM.last.n<=7};
const PZSFX={
 cue:(t,p)=>{const v=.08+.18*p;wcNz(t,.018,v,3200,'highpass');wcTone(t,1300,.045,'sine',v*.7,{to:520});wcTone(t,150,.06,'sine',v*.5,{to:70})},
 click:(t,s)=>{if(!pzClickGate())return;const v=Math.min(1,.12+s/1900),d=1+(Math.random()-.5)*.1;wcTone(t,2900*d,.05,'sine',.07*v,{r:.08});wcTone(t,3700*d,.035,'sine',.045*v,{r:.06});wcNz(t,.012,.1*v,5200,'highpass')},
 rail:(t,s)=>{const v=Math.min(1,.15+s/1600);wcTone(t,140,.07,'sine',.14*v,{to:85});wcNz(t,.06,.1*v,700,'lowpass')},
 pocket:(t,id)=>{wcTone(t,230,.06,'sine',.16,{to:120});wcTone(t,340,.05,'triangle',.07);for(let i=0;i<5;i++)wcNz(t+.06+i*.045,.04,.06*(1-i*.15),500+Math.random()*350,'lowpass',2)},
 tray:t=>{wcTone(t,1800,.03,'sine',.05,{r:.06});wcNz(t,.01,.07,4200,'highpass')},
 rerack:t=>{for(let i=0;i<16;i++){wcNz(t+i*.045,.02,.08,2800+Math.random()*1800,'bandpass',3);if(i%3===0)wcTone(t+i*.045,2200+Math.random()*700,.03,'sine',.03)}},
 drop:(t,id)=>{wcTone(t,260+id*8,.05,'sine',.07,{to:140});wcNz(t,.02,.08,2400,'bandpass',2)},
 chalk:t=>{wcNz(t,.14,.07,2600,'bandpass',4,3600);wcNz(t+.17,.1,.05,3000,'bandpass',4)},
 thump:t=>{wcTone(t,58,.16,'sine',.2,{to:40});wcTone(t+.14,52,.14,'sine',.14,{to:38})},
 hush:t=>{wcTone(t,70,.6,'sine',.06,{to:48,r:.4});wcNz(t,.5,.03,300,'lowpass')},
 eight:t=>{wcTone(t,62,.5,'sine',.2,{to:34});wcNz(t,.4,.12,420,'lowpass');[392,494,587].forEach((f,i)=>wcTone(t+.08+i*.04,f,.5,'triangle',.03,{r:.6}))},
 foul:t=>{wcTone(t,220,.14,'sawtooth',.05,{lp:1200,to:150});wcTone(t+.15,165,.2,'sawtooth',.05,{lp:900,to:110})},
 golden:t=>{[1047,1319,1568,2093,2637,3136].forEach((f,i)=>wcTone(t+i*.07,f,.2,'sine',.05,{r:.5}));wcNz(t,.8,.05,9000,'highpass');WCFX.chip(t+.3)},
 rackwin:t=>{[523,659,784,1047].forEach((f,i)=>{wcTone(t+i*.09,f,.14,'pulse',.045);wcTone(t+i*.09,f/2,.14,'triangle',.04)})},
 racklose:t=>{[330,294,262].forEach((f,i)=>wcTone(t+i*.14,f,.18,'triangle',.05,{lp:1400}))},
 win:t=>WCFX.win(t),lose:t=>WCFX.lose(t),
 vs:t=>{wcNz(t,.5,.14,300,'bandpass',1.2,3600);wcTone(t+.25,98,.4,'sine',.2,{to:50});wcNz(t+.25,.3,.12,700,'lowpass');[392,523,659].forEach((f,i)=>wcTone(t+.3+i*.1,f,.2,'pulse',.04,{r:.3}))},
 place:t=>{wcTone(t,520,.04,'sine',.07,{to:760});wcNz(t,.015,.06,3200,'highpass')},lift:t=>wcTone(t,700,.05,'sine',.05,{to:520}),
 tick:t=>WCFX.tick(t),no:t=>{wcTone(t,200,.09,'square',.035,{lp:1000});wcTone(t+.09,160,.1,'square',.03,{lp:900})},key:t=>wcTone(t,1500+Math.random()*300,.025,'square',.02),call:t=>WCFX.call(t),spot:t=>{wcTone(t,520,.06,'sine',.07);wcTone(t+.07,780,.12,'triangle',.06,{r:.2})},
 taunt:t=>{[784,988,1175,1568].forEach((f,i)=>wcTone(t+i*.05,f,.1,'square',.045));wcNz(t+.2,.2,.05,7000,'highpass')}};
function pzSound(name,arg){try{if(!ac||!sg||ST.svol<=0)return;if(name==='voice'){pzVoice(arg);return}const f=PZSFX[name];if(f)f(pzT(),arg)}catch(e){}}
/* a monster talks: a burst of syllable beeps, one per two letters, in its own voice */
function pzVoice(o){const R=PZ_REG[o.id];if(!R)return;const v=R.voice,t0=pzT(),n=Math.min(16,Math.ceil((o.n||8)/2));
 for(let i=0;i<n;i++){const t=t0+i*.058,f=v.f*(.8+Math.random()*.45);
  if(v.whisper){wcNz(t,.045,.05,2200+Math.random()*1200,'bandpass',3)}else{wcv(t,f,.04,{w:v.t,v:.03,a:.004,r:.04,bus:sg,lp:3200,det:(v.w||0)*(Math.random()-.5)*400});if(v.id==='barnacle'||R.id==='barnacle')wcNz(t,.02,.03,3500,'highpass')}
  if(v.echo)wcv(t+.2,f*.99,.04,{w:v.t,v:.012,a:.004,r:.2,bus:sg,lp:2500})}}
