/* ===== 9.4 THE CROOKED CUE: physics (96b). Pure functions, no DOM, no Math.random (the rack takes an rng). =====
   Ported from pool_plan/pzphys.js. Pure functions, no DOM; the same code runs the live table
   and the AI's look-ahead. Units: table pixels (playfield W x H = 880 x 440, origin at the top-left cushion nose), seconds.
   Each ball: {id,x,y,vx,vy,ux,uy,es,on}. (vx,vy) = centre velocity; (ux,uy) = "roll velocity" = surface speed from spin
   (ux,uy == vx,vy means pure rolling; 0 = stun/sliding; opposite = draw); es = side spin (english) in px/s at the equator. */
const PZ_PHY={W:880,H:440,R:12,G:3390/* 9.81 m/s^2 in px (346 px/m) */,MUS:.2,MUR:.035,MURL:.06/* 9.6: extra rolling drag at crawling speed (fraction of g, fades out by VL px/s) */,VL:320,MUSP:.9/* side-spin decay, as a fraction of g */,
 EB:.95/* ball-ball restitution */,EC:.78/* cushion restitution */,CF:.97/* cushion tangential keep */,ENG:.35/* english -> rebound */,
 CM:31/* corner mouth: cushion stops this far from the corner along each rail */,SM:27/* side mouth half-width */,
 STOP:3,MAXV:3200};
/* the cushion nose as segments (ball centres stay R away from them) + pocket capture circles */
function pzpTable(){const {W,H,CM,SM}=PZ_PHY,S=[],P=[];const seg=(a,b,c,d)=>S.push([a,b,c,d]);
 /* rails */
 seg(CM,0,W/2-SM,0);seg(W/2+SM,0,W-CM,0);seg(CM,H,W/2-SM,H);seg(W/2+SM,H,W-CM,H);seg(0,CM,0,H-CM);seg(W,CM,W,H-CM);
 /* corner jaws (45 deg, angled back into the pocket) */
 const J=17;seg(CM,0,CM-J,-J);seg(0,CM,-J,CM-J);seg(W-CM,0,W-CM+J,-J);seg(W,CM,W+J,CM-J);
 seg(CM,H,CM-J,H+J);seg(0,H-CM,-J,H-CM+J);seg(W-CM,H,W-CM+J,H+J);seg(W,H-CM,W+J,H-CM+J);
 /* side jaws (slightly narrowing) */
 const K=16;seg(W/2-SM,0,W/2-SM+5,-K);seg(W/2+SM,0,W/2+SM-5,-K);seg(W/2-SM,H,W/2-SM+5,H+K);seg(W/2+SM,H,W/2+SM-5,H+K);
 /* pockets: [x,y,capture radius] - a ball whose centre gets inside drops */
 P.push([-9,-9,19],[W/2,-17,17],[W+9,-9,19],[-9,H+9,19],[W/2,H+17,17],[W+9,H+9,19]);
 return {S,P}}
const PZ_TBL=pzpTable();
/* cue strike: ang (rad), pow 0..1, spin a (side, -1..1), b (top/back, -1..1) */
function pzpStrike(c,ang,pow,a,b){const v=60+pow*(PZ_PHY.MAXV-60);c.vx=Math.cos(ang)*v;c.vy=Math.sin(ang)*v;
 const k=1.25*b;/* tip offset b*R/2 -> surface speed 5/2*v*(h/R) */c.ux=c.vx*k;c.uy=c.vy*k;c.es=v*.6*a}
/* advance the whole table by dt; ev collects events {t:'bb'|'cu'|'pk',a,b,s} for rules, sound and the AI */
function pzpStep(B,dt,ev,t0){t0=t0||0;let mv=0;for(const b of B)if(b.on){const s=Math.hypot(b.vx,b.vy);if(s>mv)mv=s}
 const n=Math.max(1,Math.ceil(mv*dt/4)),h=dt/n,{R,G,MUS,MUR,MUSP}=PZ_PHY;
 for(let k=0;k<n;k++){
  for(const b of B){if(!b.on||(b.vx===0&&b.vy===0&&b.ux===0&&b.uy===0))continue;
   /* friction: slide until the surface speed matches the centre speed, then roll */
   const dx=b.ux-b.vx,dy=b.uy-b.vy,dl=Math.hypot(dx,dy);
   if(dl>.5){const a=MUS*G*h,ex=dx/dl,ey=dy/dl;if(a*3.5>=dl){/* reaches rolling inside this step: 5v+2u over 7 */const rx=(5*b.vx+2*b.ux)/7,ry=(5*b.vy+2*b.uy)/7;b.vx=b.ux=rx;b.vy=b.uy=ry}
    else{b.vx+=ex*a;b.vy+=ey*a;b.ux-=ex*a*2.5;b.uy-=ey*a*2.5}}
   else{const s=Math.hypot(b.vx,b.vy);if(s>0){const ns=Math.max(0,s-(MUR+(s<PZ_PHY.VL?PZ_PHY.MURL*(1-s/PZ_PHY.VL):0))*G*h);b.vx*=ns/s;b.vy*=ns/s}b.ux=b.vx;b.uy=b.vy}
   if(b.es){const d=MUSP*G*h*.15;b.es=Math.abs(b.es)<=d?0:b.es-Math.sign(b.es)*d}
   b.x+=b.vx*h;b.y+=b.vy*h}
  /* ball-ball */
  for(let i=0;i<B.length;i++){const p=B[i];if(!p.on)continue;for(let j=i+1;j<B.length;j++){const q=B[j];if(!q.on)continue;if(p.vx===0&&p.vy===0&&q.vx===0&&q.vy===0)continue;
   const dx=q.x-p.x,dy=q.y-p.y,d2=dx*dx+dy*dy;if(d2>=4*R*R||d2===0)continue;
   /* swept contact: the balls have overlapped a little inside this step. Step back to the instant they first touched (|r - w s| = 2R) and take
      the line of centres there, so the object ball leaves exactly along the ghost-ball line however fast the cue ball was going. */
   const wx=q.vx-p.vx,wy=q.vy-p.vy,ww=wx*wx+wy*wy;let s=0,nx,ny;
   if(ww>1e-9){const rw=dx*wx+dy*wy,disc=rw*rw-ww*(d2-4*R*R);s=Math.max(0,Math.min(h,(rw+Math.sqrt(Math.max(0,disc)))/ww));const ix=dx-wx*s,iy=dy-wy*s,il=Math.hypot(ix,iy)||1;nx=ix/il;ny=iy/il}else{const d=Math.sqrt(d2);nx=dx/d;ny=dy/d}
   const vr=(p.vx-q.vx)*nx+(p.vy-q.vy)*ny;
   if(vr<=0){const d=Math.sqrt(d2),ov=2*R-d,mx=dx/d,my=dy/d;p.x-=mx*ov/2;p.y-=my*ov/2;q.x+=mx*ov/2;q.y+=my*ov/2;continue}
   const J=(1+PZ_PHY.EB)/2*vr,pvx=p.vx,pvy=p.vy,qvx=q.vx,qvy=q.vy;
   p.vx-=J*nx;p.vy-=J*ny;q.vx+=J*nx;q.vy+=J*ny;
   p.x+=(p.vx-pvx)*s;p.y+=(p.vy-pvy)*s;q.x+=(q.vx-qvx)*s;q.y+=(q.vy-qvy)*s;
   {const ex=q.x-p.x,ey=q.y-p.y,ed=Math.hypot(ex,ey);if(ed<2*R&&ed>0){const o=2*R-ed;p.x-=ex/ed*o/2;p.y-=ey/ed*o/2;q.x+=ex/ed*o/2;q.y+=ey/ed*o/2}}
   if(ev)ev.push({t:'bb',a:p.id,b:q.id,s:vr,x:(p.x+q.x)/2,y:(p.y+q.y)/2,tm:t0+(k+1)*h})}}
  /* cushions and jaws */
  for(const b of B){if(!b.on||(b.vx===0&&b.vy===0))continue;/* cushions are only near the edges */if(b.x>40&&b.x<PZ_PHY.W-40&&b.y>40&&b.y<PZ_PHY.H-40)continue;for(let si=0;si<PZ_TBL.S.length;si++){const s=PZ_TBL.S[si],ax=s[0],ay=s[1],sx=s[2]-ax,sy=s[3]-ay,L2=sx*sx+sy*sy;
    let t=((b.x-ax)*sx+(b.y-ay)*sy)/L2;t=t<0?0:t>1?1:t;const cx=ax+sx*t,cy=ay+sy*t,dx=b.x-cx,dy=b.y-cy,d2=dx*dx+dy*dy;if(d2>=R*R)continue;
    const d=Math.sqrt(d2)||1e-6,nx=dx/d,ny=dy/d;b.x+=nx*(R-d);b.y+=ny*(R-d);const vn=b.vx*nx+b.vy*ny;if(vn>=0)continue;
    const tx=-ny,ty=nx,vt=b.vx*tx+b.vy*ty,nvn=-vn*PZ_PHY.EC,nvt=vt*PZ_PHY.CF+b.es*PZ_PHY.ENG*Math.min(1,-vn/600);
    b.vx=nx*nvn+tx*nvt;b.vy=ny*nvn+ty*nvt;b.es*=.55;const un=b.ux*nx+b.uy*ny,ut=b.ux*tx+b.uy*ty;b.ux=nx*(-un*.4)+tx*ut;b.uy=ny*(-un*.4)+ty*ut;
    if(ev)ev.push({t:'cu',a:b.id,s:-vn,x:b.x,y:b.y,tm:t0+(k+1)*h,j:si>=6})}}
  /* pockets */
  for(const b of B){if(!b.on||(b.vx===0&&b.vy===0))continue;for(let pi=0;pi<6;pi++){const p=PZ_TBL.P[pi];if((b.x-p[0])**2+(b.y-p[1])**2<p[2]*p[2]){b.on=false;b.pk=pi;b.vx=b.vy=b.ux=b.uy=0;if(ev)ev.push({t:'pk',a:b.id,p:pi,x:b.x,y:b.y,tm:t0+(k+1)*h});break}}
   /* safety: a ball that escapes the table (should not happen) is treated as pocketed in the nearest pocket */
   if(b.on&&(b.x<-40||b.x>PZ_PHY.W+40||b.y<-40||b.y>PZ_PHY.H+40)){b.on=false;b.pk=-1;if(ev)ev.push({t:'pk',a:b.id,p:-1,x:b.x,y:b.y,tm:t0+(k+1)*h})}}}
 /* settle */
 let moving=false;for(const b of B){if(!b.on)continue;if(Math.hypot(b.vx,b.vy)<PZ_PHY.STOP&&Math.hypot(b.ux,b.uy)<PZ_PHY.STOP){b.vx=b.vy=b.ux=b.uy=0;b.es=0}else moving=true}
 return moving}
/* run a whole shot headless (AI and tests): returns {ev,t} with the balls mutated in place */
/* the same run as a generator that yields every `slice` steps, so the AI can think without a long frame */
function* pzpRunG(B,maxT,slice){const ev=[];let t=0,n=0;const dt=1/120;while(t<(maxT||12)){if(!pzpStep(B,dt,ev,t))break;t+=dt;if(++n%(slice||60)===0)yield 0}return {ev,t}}
function pzpRun(B,maxT){const ev=[];let t=0;const dt=1/120;while(t<(maxT||12)){if(!pzpStep(B,dt,ev,t))break;t+=dt}return {ev,t}}
/* rack: apex on the foot spot, 8 in the middle, a solid and a stripe in the back corners */
function pzpRack(rnd){const {W,H,R}=PZ_PHY,fx=W*.75,fy=H/2,B=[{id:0,x:W*.25,y:H/2}];rnd=rnd||Math.random;
 const sol=[1,2,3,4,5,6,7],str=[9,10,11,12,13,14,15],sh=a=>{for(let i=a.length-1;i>0;i--){const j=(rnd()*(i+1))|0;[a[i],a[j]]=[a[j],a[i]]}return a};sh(sol);sh(str);
 const slots=[];for(let r=0;r<5;r++)for(let k=0;k<=r;k++)slots.push([r,k]);const ids=new Array(15).fill(0);
 const center=4/*row 2 middle*/,cA=10,cB=14;ids[center]=8;const s0=sol.pop(),t0=str.pop();if(rnd()<.5){ids[cA]=s0;ids[cB]=t0}else{ids[cA]=t0;ids[cB]=s0}
 const rest=sh(sol.concat(str));for(let i=0;i<15;i++)if(!ids[i])ids[i]=rest.pop();
 slots.forEach(([r,k],i)=>{const gap=.03;/* tiny gaps so the rack is not over-constrained, and a little jitter (under 0.3 px) so no two breaks are identical */const jx=i?(rnd()-.5)*.6:0,jy=i?(rnd()-.5)*.6:0;B.push({id:ids[i],x:fx+r*R*Math.sqrt(3)*(1+gap)+jx,y:fy+(k-r/2)*2*R*(1+gap)+jy})});
 for(const b of B)Object.assign(b,{vx:0,vy:0,ux:0,uy:0,es:0,on:true});return B}
/* ball in hand: is (x,y) a legal place for the cue ball? (kitchen = behind the head string only) */
function pzpCanPlace(B,x,y,kitchen){const {R,W:pw,H:ph}=PZ_PHY;if(x<R+1||x>pw-R-1||y<R+1||y>ph-R-1)return false;if(kitchen&&x>pw/4)return false;
 for(const b of B)if(b.on&&b.id&&(b.x-x)**2+(b.y-y)**2<(2*R+1)**2)return false;return true}
/* the nearest legal spot to (x,y) (for a pointer that is over a ball or off the cloth) */
function pzpNearestPlace(B,x,y,kitchen){const {R,W:pw,H:ph}=PZ_PHY;x=Math.max(R+1,Math.min(kitchen?pw/4:pw-R-1,x));y=Math.max(R+1,Math.min(ph-R-1,y));if(pzpCanPlace(B,x,y,kitchen))return {x,y,ok:true};
 let best=null;for(let r=4;r<120;r+=4){for(let a=0;a<24;a++){const px=x+Math.cos(a/24*TAU)*r,py=y+Math.sin(a/24*TAU)*r;if(pzpCanPlace(B,px,py,kitchen)){best={x:px,y:py,ok:false};break}}if(best)break}
 return best||{x:pw/4,y:ph/2,ok:false}}
/* seeded RNG (mulberry32): racks and AI noise use it, so tests are repeatable */
function pzRng(seed){let a=(seed>>>0)||1;return function(){a=(a+0x6D2B79F5)>>>0;let t=a;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296}}
