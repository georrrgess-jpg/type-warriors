/* ---------- casino: plinko and wheel of fortune ---------- */
ICON.pl='<svg viewBox="0 0 64 64"><g fill="#ffe9a8"><circle cx="32" cy="10" r="3"/><circle cx="22" cy="24" r="3"/><circle cx="42" cy="24" r="3"/><circle cx="12" cy="38" r="3"/><circle cx="32" cy="38" r="3"/><circle cx="52" cy="38" r="3"/></g><circle cx="27" cy="16" r="5.5" fill="#ff5c6c" stroke="#fff" stroke-width="1.5"/><g><rect x="4" y="50" width="12" height="8" rx="2" fill="#e0b02a"/><rect x="18" y="50" width="12" height="8" rx="2" fill="#2aa870"/><rect x="32" y="50" width="12" height="8" rx="2" fill="#3a7ad8"/><rect x="46" y="50" width="12" height="8" rx="2" fill="#e8702a"/></g></svg>';
ICON.wh='<svg viewBox="0 0 64 64"><circle cx="32" cy="34" r="26" fill="#2a2a3d" stroke="#ffd76a" stroke-width="3"/><path d="M32 34L32 8A26 26 0 0 1 54.5 21z" fill="#e0b02a"/><path d="M32 34L54.5 21A26 26 0 0 1 54.5 47z" fill="#2aa870"/><path d="M32 34L54.5 47A26 26 0 0 1 32 60z" fill="#3a7ad8"/><path d="M32 34L32 60A26 26 0 0 1 9.5 47z" fill="#e8702a"/><path d="M32 34L9.5 47A26 26 0 0 1 9.5 21z" fill="#c02ad8"/><path d="M32 34L9.5 21A26 26 0 0 1 32 8z" fill="#3a7ad8"/><circle cx="32" cy="34" r="6" fill="#ffd76a"/><path d="M26 2h12l-6 12z" fill="#e8455a" stroke="#fff" stroke-width="1.5"/></svg>';
GAMES.push({id:'pl',n:'Plinko',d:'Drop balls through a field of pegs. Pick the rows and the risk. The edges pay the most.',m:(e,t)=>mPL(e,t)},
 {id:'wh',n:'Wheel of Fortune',d:'Spin the wheel and win the multiplier under the pointer. Pick low, medium or high risk.',m:(e,t)=>mWH(e,t)});
const PLK={8:{l:[5.6,2.1,1.1,1,.5,1,1.1,2.1,5.6],m:[13,3,1.3,.7,.4,.7,1.3,3,13],h:[29,4,1.5,.3,.2,.3,1.5,4,29]},
 12:{l:[10,3,1.6,1.4,1.1,1,.5,1,1.1,1.4,1.6,3,10],m:[33,11,4,2,1.1,.6,.3,.6,1.1,2,4,11,33],h:[170,24,8.1,2,.7,.2,.2,.2,.7,2,8.1,24,170]},
 16:{l:[16,9,2,1.4,1.4,1.2,1.1,1,.5,1,1.1,1.2,1.4,1.4,2,9,16],m:[110,41,10,5,3,1.5,1,.5,.3,.5,1,1.5,3,5,10,41,110],h:[1000,130,26,9,4,2,.2,.2,.2,.2,.2,2,4,9,26,130,1000]}};
function plkTab(n,k){const b=PLK[n][k];let rtp=0;for(let i=0;i<=n;i++){let c=1;for(let j=0;j<i;j++)c=c*(n-j)/(j+1);rtp+=c/Math.pow(2,n)*b[i]}const f=.96/rtp;return b.map(x=>Math.floor(x*f*100)/100)}
const plCol=m=>m<1?'#3a6ad8':m<1.5?'#2a9a9a':m<3?'#2aa870':m<6?'#c8b02a':m<15?'#e8802a':m<60?'#e8452a':'#d02ad8';
const fmM=m=>m>=100?String(Math.round(m)):m>=10?String(+m.toFixed(1)):String(m);
function mPL(el,tok){
 const alive=()=>CAS.tok===tok;let rows=12,risk='m',tab=plkTab(rows,risk),balls=[],flash={},sf={},autoOn=false,autoT=0,hist=[],last=performance.now();
 el.innerHTML=`<div class="felt" style="padding:6px;background:linear-gradient(#150a34,#2a0a22)"><canvas id="pl" width="1100" height="440"></canvas></div><p class="cmsg" id="cm"> </p>
<div class="ctl">${betBar()}<div class="ac"><div class="seg2" id="plr">${[8,12,16].map(v=>`<button data-r="${v}" class="${v===12?'on':''}">${v} rows</button>`).join('')}</div><div class="seg2" id="plk">${[['l','Low'],['m','Medium'],['h','High']].map(([v,n])=>`<button data-k="${v}" class="${v==='m'?'on':''}">${n}</button>`).join('')}</div></div><div class="btns"><button class="bbig" id="pld">Drop ball</button><button class="bbig" id="pla">Auto: off</button></div></div><div class="hist" id="plh"></div>`;
 const H=()=>{$('plh').innerHTML=hist.map(v=>`<span class="${v>=10?'hi':v>=2?'mid':'lo'}">${fmM(v)}×</span>`).join('')};
 const lock=()=>ov.querySelectorAll('#plr button,#plk button').forEach(b=>b.disabled=balls.length>0);
 const geo=()=>{const Wd=1100,Ht=440,gx=Math.min(58,(Wd-160)/(rows+1)),top=26,sh=32,slotY=Ht-sh-6,gy=(slotY-14-top)/rows;return{Wd,Ht,gx,top,sh,slotY,gy,cx:Wd/2,pr:rows>=16?3.2:rows>=12?3.8:4.6}};
 const drop=()=>{if(balls.length>=12)return false;if(CAS.bet<1){msg(broke()||'Place a bet first.');return false}if(CAS.bet>P.gold){msg('Not enough gold.');return false}const bet=CAS.bet;if(!cTake(bet))return false;
  const d=[];let k=0;for(let i=0;i<rows;i++){const r=Math.random()<.5?0:1;d.push(r);k+=r}balls.push({d,k:0,row:-1,t:-1,bet,slot:k,rows,tab,risk,j:(Math.random()-.5)*.6});lock();beep(420,.04,'triangle',.4);betRefresh();return true};
 const settle=(b,quiet)=>{const m=b.tab[b.slot],pay=Math.floor(b.bet*m);stat('plk',m,'max');
  if(quiet){P.gold+=pay;casTrack(b.bet,pay);const c=cst();c.plays++;c.net+=pay-b.bet;if(pay-b.bet>c.best)c.best=pay-b.bet;save();return}
  cPay(b.bet,pay);sf[b.slot]=1;hist.unshift(m);hist.length=Math.min(hist.length,14);H();
  msg(`${fmM(m)}×  ${pay>b.bet?'+'+cmn(pay-b.bet):pay<b.bet?'−'+cmn(b.bet-pay):'Break even'}${broke()?' '+broke():''}`,pay>b.bet?'w':pay<b.bet?'l':'');
  beep(300+Math.min(900,m*60),.12,'triangle',.6)};
 CAS.flush=()=>{for(const b of balls)settle(b,true);balls=[]};
 const setA=v=>{autoOn=v;$('pla').textContent='Auto: '+(v?'on':'off');$('pla').classList.toggle('on',v)};
 live('pl',cv=>{const g=cv.getContext('2d');
  return()=>{if(!alive())return;const now=performance.now(),dt=Math.min(.05,(now-last)/1000);last=now;const G=geo();
   if(autoOn){autoT-=dt;if(autoT<=0){autoT=.42;if(!drop())setA(false)}}
   for(const b of balls){b.t+=dt/(rows>=16?.2:.24);const T=b.rows;
    while(b.row<Math.floor(b.t)&&b.row<T-1){b.row++;const j=b.k+1;(flash[b.row]=flash[b.row]||{})[j]=1;b.k+=b.d[b.row];beep(480+b.row*22+Math.random()*30,.03,'triangle',.22)}}
   const done=balls.filter(b=>b.t>=b.rows);if(done.length){balls=balls.filter(b=>b.t<b.rows);for(const b of done)settle(b);lock()}
   for(const r in flash)for(const j in flash[r]){flash[r][j]-=dt*3.2;if(flash[r][j]<=0)delete flash[r][j]}
   for(const k in sf){sf[k]-=dt*1.6;if(sf[k]<=0)delete sf[k]}
   plBack(g,G);
   const pgx=(i,j)=>G.cx+(j-(i+2)/2)*G.gx,pgy=i=>G.top+i*G.gy;
   for(let i=0;i<rows;i++)for(let j=0;j<i+3;j++){const f=(flash[i]&&flash[i][j])||0,x=pgx(i,j),y=pgy(i);if(f>0){const q=g.createRadialGradient(x,y,0,x,y,G.pr*5);q.addColorStop(0,`rgba(255,240,160,${f*.8})`);q.addColorStop(1,'rgba(255,240,160,0)');g.fillStyle=q;g.beginPath();g.arc(x,y,G.pr*5,0,TAU);g.fill()}g.fillStyle=f>0?'#fff':'#ffe3a0';g.beginPath();g.arc(x,y,G.pr*(1+f*.35),0,TAU);g.fill();if(!f){g.fillStyle='#fffbe0aa';g.beginPath();g.arc(x-G.pr*.3,y-G.pr*.3,G.pr*.35,0,TAU);g.fill()}}
   for(let k=0;k<=rows;k++){const x=G.cx+(k-rows/2)*G.gx,w=G.gx*.9,m=tab[k],f=sf[k]||0;g.save();g.translate(x,G.slotY+f*6);g.fillStyle=plCol(m);g.globalAlpha=.75+f*.25;g.beginPath();g.roundRect(-w/2,0,w,G.sh,6);g.fill();g.globalAlpha=1;g.fillStyle='#fff3';g.beginPath();g.roundRect(-w/2,0,w,G.sh/2,6);g.fill();g.fillStyle='#fff';g.font=`700 ${rows>=16?11:rows>=12?13:16}px Georgia,serif`;g.textAlign='center';g.textBaseline='middle';g.fillText(fmM(m)+'×',0,G.sh/2+1);if(f>0){g.strokeStyle=`rgba(255,255,255,${f})`;g.lineWidth=3;g.beginPath();g.roundRect(-w/2,0,w,G.sh,6);g.stroke()}g.restore()}
   for(const b of balls){const T=b.rows,i=Math.max(0,Math.min(T-1,Math.floor(b.t))),tau=b.t-i;let kk=0;for(let q=0;q<i;q++)kk+=b.d[q];
    let x,y;if(b.t<0){x=G.cx+b.j*10;y=-12+(G.top-4+12)*(1+b.t)*(1+b.t)}else{const x0=G.cx+(kk-i/2)*G.gx,y0=pgy(i),y1=i+1>=T?G.slotY-8:pgy(i+1);x=x0+(b.d[i]-.5)*G.gx*tau;y=y0+(y1-y0)*tau-Math.sin(Math.PI*tau)*G.gy*.4-G.pr-G.pr*1.6}
    const r=G.pr*1.9;const q=g.createRadialGradient(x,y,0,x,y,r*3);q.addColorStop(0,'rgba(255,90,110,.55)');q.addColorStop(1,'rgba(255,90,110,0)');g.fillStyle=q;g.beginPath();g.arc(x,y,r*3,0,TAU);g.fill();g.fillStyle='#ff5c6c';g.strokeStyle='#fff';g.lineWidth=1.6;g.beginPath();g.arc(x,y,r,0,TAU);g.fill();g.stroke();g.fillStyle='#fff9';g.beginPath();g.arc(x-r*.3,y-r*.3,r*.3,0,TAU);g.fill()}}});
 const rebuild=()=>{tab=plkTab(rows,risk)};
 ov.querySelectorAll('#plr button').forEach(b=>b.onclick=()=>{if(balls.length)return;rows=+b.dataset.r;rebuild();flash={};ov.querySelectorAll('#plr button').forEach(x=>x.classList.toggle('on',x===b))});
 ov.querySelectorAll('#plk button').forEach(b=>b.onclick=()=>{if(balls.length)return;risk=b.dataset.k;rebuild();ov.querySelectorAll('#plk button').forEach(x=>x.classList.toggle('on',x===b))});
 $('pld').onclick=drop;$('pla').onclick=()=>setA(!autoOn);wireBet();CAS.key={' ':drop,enter:drop,a:()=>setA(!autoOn)};H();
 msg('Pick rows and risk, place your bet and drop a ball. Space drops, A toggles auto.')}

/* ---------- wheel of fortune ---------- */
const WHL={l:{n:'Low',c:{0:8,1.2:3,1.5:7,2:1,3:1}},m:{n:'Medium',c:{0:14,1.4:3,2:1,3:1,10:1}},h:{n:'High',c:{0:16,2:2,5:1,10:1}}};
function whlSegs(k){const list=[];for(const m of Object.keys(WHL[k].c))for(let i=0;i<WHL[k].c[m];i++)list.push(+m);list.sort((a,b)=>b-a);const out=Array(20);for(let i=0;i<20;i++)out[(i*7)%20]=list[i];return out}
const whCol=(m,i)=>m===0?(i%2?'#232336':'#2c2c44'):m<1.5?(i%2?'#3a72d0':'#4a82e0'):m<3?(i%2?'#26a068':'#30b478'):m<6?(i%2?'#d8aa28':'#e8ba38'):m<15?(i%2?'#e06a24':'#f07a34'):(i%2?'#b828d0':'#cc3ae4');
