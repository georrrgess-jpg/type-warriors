# python3 t_ty99.py [game.html] : Runestone Tower Defense 9.9j - Rune Typing (97h: typing words over the abilities casts or charges
# them; a Settings panel and a pause-menu switch; the one-time "New" card), the Ascended Towers row that fits its panel (97g) and
# U upgrading the selected tower again (97e).
import asyncio,os,sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:500]),flush=True)
    if not ok:FAIL.append(name)
SETUP="()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const r=RPP();r.dragon=1;r.stars={moss:3,frost:3,ember:3};const T=r.tut;for(const k in T)T[k]=1;for(const k of['build','wave','coins','upgrade','abil','twist_frost','twist_ember','twist_wonder'])T[k]=1;save()}"
BATTLE="""()=>{rpStart('frost');const R=RPX;R.tut=null;R.hold=false;R.supply=5000;const cov=p=>{let n=0;for(const q of R.G.U){if((q.x-p.x)**2+((q.y-p.y)/.75)**2<210*210)n++}return n};const pads=[...R.pads].sort((a,b)=>cov(b)-cov(a));
  for(const [i,t] of [[0,'ballista'],[1,'frost']]){rpBuild(pads[i],t);pads[i].tw.build=1}R.wave=3;rpWaveStart();for(let i=0;i<30*6;i++)rpStep(R,1/30);window.__pads=pads;return 1}"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();ctx=await b.new_context(viewport={'width':1600,'height':900});await ctx.add_init_script('window.RPTY_NEWS=1');pg=await ctx.new_page();er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate;K=pg.keyboard
        await E(SETUP)
        # ---- off by default: letters still pick towers
        await E(BATTLE);await pg.wait_for_timeout(500)
        r=await E("()=>[rptyOpt().ty,!!document.querySelector('.rptyw'),!!document.querySelector('.rptyb')]")
        await K.press('q');r.append(await E("()=>{const a=RPX.place;RPX.place=null;return a}"))
        chk('Rune Typing is off by default: no words over the abilities, Q still picks the Rune Ballista',r==[0,False,False,'ballista'],r)
        # ---- U: upgrade the selected tower, or pick the Observatory
        r=await E("()=>{const R=RPX,tw=__pads[0].tw;R.sel=tw;tw.upK=1;const t0=tw.tier;window.dispatchEvent(new KeyboardEvent('keydown',{key:'u'}));const up=tw.tier;R.sel=null;window.dispatchEvent(new KeyboardEvent('keydown',{key:'u'}));const pl=R.place;R.place=null;return [t0,up,pl]}")
        chk('U upgrades the selected tower again; with nothing selected it picks the Starfall Observatory',r==[1,2,'star'],r)
        await E("()=>rpLeave()")
        # ---- the New card, once; the Settings button
        await E("()=>{delete RPP().new99j;save();RPSEL='frost';rampartsMenu()}");await pg.wait_for_timeout(1100)
        r=await E("()=>[!$('rpmod').hidden,!!$('rptyon'),/Rune Typing/.test($('rpmod').textContent),document.querySelectorAll('#rpmod .rptyw').length,!!$('rphset')]")
        chk('the first time tower defense opens, a "New: Rune Typing" card shows (with a preview of the words) and a Settings button sits in the top bar',r==[True,True,True,3,True],r)
        await pg.screenshot(path=os.path.join(HERE,'shots','ty99_news.png'))
        await E("()=>$('rptyno').click()");await E("()=>{rampartsMenu()}");await pg.wait_for_timeout(900)
        r=await E("()=>[$('rpmod').hidden,RPP().new99j,rptyOpt().ty]")
        chk('"Not now" closes it, it does not come back, and the option stays off',r==[True,1,0],r)
        await E("()=>$('rphset').click()");await pg.wait_for_timeout(300)
        r=await E("()=>{const sw=$('rptysw');sw.click();const on=rptyOpt().ty;document.querySelector('.rpseg [data-l=long]').click();return [on,rptyOpt().tyl,$('rptysw').classList.contains('on'),JSON.parse(localStorage.getItem(Object.keys(localStorage).find(k=>{try{const o=JSON.parse(localStorage.getItem(k));return o&&o.rp&&o.rp.opt}catch(e){return false}}))||'{}').rp.opt]}")
        chk('Settings: the Rune Typing switch and the word length are saved',r[0]==1 and r[1]=='long' and r[2] and r[3]=={'ty':1,'tyl':'long'},r)
        await pg.screenshot(path=os.path.join(HERE,'shots','ty99_settings.png'))
        await E("()=>{$('rpmod').hidden=true;rptyLen('normal')}")
        # ---- typing in battle
        await E(BATTLE);await pg.wait_for_timeout(700)
        r=await E("()=>{const w=RPX.ty.w;return [RPX.ty.on,Object.keys(w),new Set(Object.values(w).map(x=>x[0])).size,Object.values(w).every(x=>x.length>=4&&x.length<=7),document.querySelectorAll('#rphud .rptyw').length,!!document.querySelector('#rphud .rptyb'),$('rphud').classList.contains('rptyon')]}")
        chk('in battle: a word over each ability, three different first letters, normal length 4-7; the streak badge shows',r==[True,['over','slow','repair'],3,True,3,True,True],r)
        r=await E("()=>{const s=document.querySelector('.rpabs').getBoundingClientRect(),c=[...document.querySelectorAll('#rphud .rptyw')].map(x=>x.getBoundingClientRect());let ov=0;for(let i=0;i<c.length;i++)for(let j=i+1;j<c.length;j++)if(c[i].right>c[j].left+1&&c[j].right>c[i].left+1)ov++;return [ov,c.every(x=>x.left>=0&&x.bottom<s.top+2)]}")
        chk('the word chips do not overlap each other and sit above the ability buttons',r==[0,True],r)
        await E("()=>{RPX.place=null;RPX.abCd.slow=30;RPX.abCd.repair=0;RPX.hp=15}")
        w=await E("()=>RPX.ty.w")
        await K.press(w['slow'][0]);r=await E("()=>[RPX.place,RPX.ty.buf]")
        chk('letters type instead of picking towers',r[0] is None and r[1]==w['slow'][0],r)
        for c in w['slow'][1:]:await K.press(c)
        r=await E("()=>[+RPX.abCd.slow.toFixed(1),RPX.ty.streak,RPX.ty.w.slow!==%r]"%w['slow'])
        chk('typing the word of a recharging ability charges it by 15% of its cooldown (30 s -> 24 s) and brings a new word',abs(r[0]-24)<0.3 and r[1]==1 and r[2],r)
        w=await E("()=>RPX.ty.w")
        for c in w['repair']:await K.press(c)
        r=await E("()=>[RPX.hp,RPX.abCd.repair>0,RPX.ty.streak]")
        chk('typing the word of a ready ability casts it (Repair heals the castle)',r==[19,True,2],r)
        await E("()=>{RPX.abCd.slow=30}");w=await E("()=>RPX.ty.w")
        for c in w['slow']:await K.press(c)
        r=await E("()=>+RPX.abCd.slow.toFixed(2)")
        chk('a streak charges faster (third clean word: 15% + 2%)',abs(r-(30-40*0.17))<0.3,r)
        w=await E("()=>RPX.ty.w")
        bad=next(c for c in 'zqxjkvwy' if c not in [x[0] for x in w.values()])
        await K.press(w['over'][0]);await K.press('Backspace');r1=await E("()=>RPX.ty.buf")
        await K.press(w['over'][0]);await K.press(bad if bad!=w['over'][1] else 'z');r=await E("()=>[RPX.ty.buf,RPX.ty.streak,RPX.ty.best]")
        chk('Backspace takes a letter back; a wrong letter clears the word and breaks the streak (the best stays)',r1=='' and r==['',0,3],[r1,r])
        await pg.wait_for_timeout(300);await pg.screenshot(path=os.path.join(HERE,'shots','ty99_battle.png'))
        r=await E("()=>{const R=RPX,tw=__pads[0].tw;R.sel=tw;R.abCd.over=0;return 1}");w=await E("()=>RPX.ty.w")
        for c in w['over']:await K.press(c)
        r=await E("()=>[__pads[0].tw.over>0,RPX.abCd.over>0]")
        chk('Overcharge typed while a tower is selected overcharges that tower',r==[True,True],r)
        # ---- the pause menu switch, live
        await E("()=>{RPX.sel=null}");await K.press('Escape');await pg.wait_for_timeout(400)
        r=await E("()=>[!!document.querySelector('.rppause #rptysw'),/Rune Typing: type/.test(document.querySelector('.rppause').textContent)]")
        await E("()=>$('rptysw').click()");await E("()=>rpPause(false)");await pg.wait_for_timeout(300)
        await K.press('w');r+=await E("()=>{const a=RPX.place;RPX.place=null;return [RPX.ty.on,document.querySelectorAll('#rphud .rptyw').length,a]}")
        chk('the pause menu has the switch: turning it off removes the words at once and letters pick towers again',r==[True,True,False,0,'brazier'],r)
        await E("()=>rpLeave()")
        # ---- word lengths
        r=await E("()=>{const out={};for(const l of ['short','long']){rptyLen(l);rptyOpt().ty=1;rpStart('moss');RPX.tut=null;const L=[];for(let i=0;i<30;i++)L.push(rptyWord(RPX,'over').length);out[l]=[Math.min(...L),Math.max(...L)];rpLeave()}rptyLen('normal');rptyOpt().ty=0;save();return out}")
        chk('word length: Short 3-5 letters, Long 6-9',r['short'][0]>=3 and r['short'][1]<=5 and r['long'][0]>=6 and r['long'][1]<=9,r)
        # ---- the Ascended Towers row
        await E("()=>{RPP().ebest=40;RPSEL='wonder';rampartsMenu()}");await pg.wait_for_timeout(1100)
        r=await E("()=>{const s=document.querySelector('.rpside').getBoundingClientRect(),row=document.querySelector('.rpasc>div').getBoundingClientRect(),t=[...document.querySelectorAll('.rpasc .rpai')].map(x=>x.getBoundingClientRect());const arm=[...document.querySelectorAll('#ov *')].find(x=>/Rampart Armory/.test(x.textContent)&&x.children.length<12&&x.getBoundingClientRect().height>60);return [t.length,t.every(x=>x.right<=s.right-4&&x.left>=s.left),Math.round(s.bottom),arm?Math.round(arm.getBoundingClientRect().top):null,Math.round(row.right),Math.round(s.right)]}")
        chk('Wonderland panel: all ten Ascended Towers tiles stay inside the panel (two rows), and the panel clears the Armory bar',r[0]==10 and r[1] and r[2]<=760,r)
        await pg.screenshot(path=os.path.join(HERE,'shots','ty99_wonder.png'))
        chk('no page errors',not er,er)
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
