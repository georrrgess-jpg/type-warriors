/* ===== HOME SCREEN 9.9e: the menu panel clears the dock (97a, after 96zz) =====
   The bottom dock (Play, Gear, Pets, Progress, Shop, More) used to overlap the lowest home cards (Halloween events, Lantern Caravan)
   and the panel's bottom edge. The panel now hangs from the top of its row instead of centring, the lowest cards are a little shorter
   and the panel's bottom padding tighter, so everything ends above the dock with a clear gap. */
{const st=document.createElement("style");st.textContent=`.dkcp{align-self:start;padding-top:20px!important;padding-bottom:20px!important}.dkcp .dksc{margin-top:12px!important}.dkcp .dks4 .dkcard{min-height:120px;padding-top:11px!important;padding-bottom:11px!important}`;document.head.appendChild(st)}
