# python3 t_cas93.py : 9.3 casino limits - 5,000 max bet in every casino game except Blackjack, Higher or Lower and Tower Climb;
# the roulette table limit; Mines pays at most 15,000 (and cashes out by itself when it gets there).
import asyncio
from playwright.async_api import async_playwright
H='file:///home/user/type-warriors/type-warriors-source/out.html'
FAIL=[];N=[0]
def chk(name,ok,r):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(r)))
    if not ok:FAIL.append(name)
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(H);await pg.wait_for_timeout(1500)
        E=pg.evaluate
        await E("()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;PFW.asked=true;P.gold=1e6}")
        want={'bj':7500,'hl':5000,'tw':7500,'rk':5000,'sl':5000,'ro':5000,'di':5000,'mi':5000,'pl':5000,'wh':5000,'qz':1000}
        for gid,cap in want.items():
            r=await E("async(id)=>{casinoOpen();await new Promise(r=>setTimeout(r,300));gameOpen(id);await new Promise(r=>setTimeout(r,250));CAS.bet=99999;betRefresh();const s=ov.querySelector('.bv small');return [CAS.cap,CAS.bet,s?s.textContent:'']}",gid)
            chk(f'{gid}: bets stop at {cap:,} and the bar says so',r[0]==cap and r[1]==cap and r[2].replace(',','')=='max '+str(cap),r)
        r=await E("async()=>{casinoOpen();await new Promise(r=>setTimeout(r,300));gameOpen('ro');await new Promise(r=>setTimeout(r,250));return [typeof CAS_LIM,CAS_LIM]}")
        chk('roulette: the table limit per spin is 5,000',r==['number',5000],r)
        # mines: 24 bombs on tiles 0..23, tile 24 is the only gem; a 5,000 bet would pay 120,000 but stops at 15,000
        r=await E("""async()=>{casinoOpen();await new Promise(r=>setTimeout(r,300));gameOpen('mi');await new Promise(r=>setTimeout(r,250));
          ov.querySelector('#mn button[data-n="24"]').click();CAS.bet=5000;betRefresh();const g0=P.gold;let paid=null;const cp=cPay;cPay=function(b,p){paid=[b,p];return cp.apply(this,arguments)};const R=Math.random;let i=0;Math.random=()=>((i++)%24+.5)/25;
          $('m0').click();Math.random=R;const shown=ov.querySelector('.msi').textContent.includes('Max payout');ov.querySelectorAll('#mg .mt')[24].click();await new Promise(r=>setTimeout(r,300));cPay=cp;
          return [paid,$('cm').textContent,shown,$('m0').style.display!=='none']}""")
        chk('mines: the payout stops at 15,000 and the round cashes out by itself',r[0]==[5000,15000] and 'Max payout' in r[1] and r[2] and r[3],r)
        r=await E("""async()=>{casinoOpen();await new Promise(r=>setTimeout(r,300));gameOpen('mi');await new Promise(r=>setTimeout(r,250));
          ov.querySelector('#mn button[data-n="3"]').click();CAS.bet=100;betRefresh();const g0=P.gold;const R=Math.random;let i=0;Math.random=()=>((i++)%3+.5)/25;
          $('m0').click();Math.random=R;const T=ov.querySelectorAll('#mg .mt');T[10].click();T[11].click();$('mc').click();await new Promise(r=>setTimeout(r,200));return [P.gold-g0]}""")
        chk('mines: small wins below the cap still pay (3 bombs, 2 gems, 100 bet)',r[0]>0,r)
        chk('no page errors',not er,er)
        print(f'{N[0]-len(FAIL)} / {N[0]} passed');await b.close()
asyncio.run(main())
