/* ===== FIT THE SCREEN WHEN EMBEDDED IN A WEBSITE =====
   On a website (for example a Wix HTML embed) the game's box can be taller than the screen can show, so the bottom of the
   game sat off screen, and the mouse wheel over the game scrolled the website behind it.
   Fit: the browser tells a page inside an iframe how much of it is really on screen (IntersectionObserver, measured
   against the whole browser window even across sites). A full-size invisible marker is measured about every 0.7 s, so
   switching the Chromebook between fullscreen and normal is followed both ways. When part of the box is off screen, the
   stage fits the band of the box that is visible (wherever the page is scrolled, unless most of it is scrolled away). Without
   IntersectionObserver it falls back to an estimate from the screen size.
   Scroll: inside an iframe, wheel scrolling over the game no longer moves the website behind it; lists and menus in the
   game still scroll. Settings › Display › "Fit to screen on websites" turns both off. */
Object.assign(defST,{fitscr:'auto'});if(ST.fitscr==null)ST.fitscr='auto';
const FIT={on:0,bt:0,bh:0,io:null,cap:0};
const fitOn=()=>ST.fitscr!=='off'&&inFrame()&&!TM();
function fitCap(){const sh=screen.height||0,ah=screen.availHeight||sh,oh=window.outerHeight||0;if(sh<300)return 0;return Math.round(oh>=sh-2?sh:Math.max(300,ah-100))}
/* the part of the box to fit into: {t: top, h: height}, or null when the whole box is on screen */
function fitTarget(){if(FIT.io)return FIT.bh&&(FIT.bt>1||FIT.bh<innerHeight-12)?{t:FIT.bt,h:FIT.bh}:null;const c=fitCap();FIT.cap=c;return c&&innerHeight>c+24?{t:0,h:c}:null}
{const a0=applyLayout;applyLayout=function(){const r=a0.apply(this,arguments);try{const t=fitOn()?fitTarget():null;
 if(t&&t.h>=200){let k=Math.min(innerWidth/W,t.h/H);if(ST.size!=='fit')k=Math.min(k,+ST.size);wrap.style.top=Math.round(t.t+t.h/2)+'px';wrap.style.transform=`translate(-50%,-50%) scale(${k})`;FIT.on=1}
 else if(FIT.on){FIT.on=0;if(!TM())wrap.style.top=''}}catch(e){}return r}}
/* how much of this frame is on screen, measured from its top */
try{if(inFrame()&&'IntersectionObserver' in window){const m=document.createElement('div');m.id='fitmark';m.setAttribute('aria-hidden','true');m.style.cssText='position:fixed;left:0;top:0;width:2px;height:100%;opacity:0;pointer-events:none;z-index:-1';document.body.appendChild(m);
 FIT.io=new IntersectionObserver(es=>{try{const e=es[es.length-1],B=e.boundingClientRect,I=e.intersectionRect;let v;
  if(!e.isIntersecting)return;const t=Math.max(0,Math.round(I.top-B.top)),h=Math.round(I.height);if(h<innerHeight*.3&&h<300)return;/* mostly scrolled away: keep the last fit */
  if(Math.abs(t-FIT.bt)>=3||Math.abs(h-FIT.bh)>=3){FIT.bt=t;FIT.bh=h;if(fitOn()||FIT.on)applyLayout()}}catch(x){}},{threshold:Array.from({length:101},(_,i)=>i/100)});
 FIT.io.observe(m);const again=()=>{try{FIT.io.unobserve(m);FIT.io.observe(m)}catch(x){}};setInterval(again,600);addEventListener('resize',()=>setTimeout(again,60));document.addEventListener('visibilitychange',again)}
 else if(inFrame())setInterval(()=>{try{if(fitCap()!==FIT.cap)applyLayout()}catch(e){}},1500)}catch(e){}
/* the wheel over the game stays in the game */
function fitScrollable(el,dy){for(;el&&el!==document.body&&el!==document.documentElement;el=el.parentElement){const cs=getComputedStyle(el);if(!/(auto|scroll)/.test(cs.overflowY)||el.scrollHeight<=el.clientHeight+1)continue;
 if(dy<0?el.scrollTop>0:el.scrollTop+el.clientHeight<el.scrollHeight-1)return true}return false}
if(inFrame())window.addEventListener('wheel',e=>{try{if(ST.fitscr==='off'||e.ctrlKey)return;if(!fitScrollable(e.target,e.deltaY||e.deltaX))e.preventDefault()}catch(x){}},{passive:false,capture:true});
{const st=document.createElement('style');st.textContent='#ov,#ov *{overscroll-behavior:contain}';document.head.appendChild(st)}
/* Settings › Display */
SETG.Display.push('Fit to screen on websites');
/* added before the tabs are built (next to Fullscreen), so the Display tab owns it and other tabs hide it */
{const st0=settingsTabs;settingsTabs=function(){try{const box=ov.querySelector('.opts'),fs=box&&[...box.querySelectorAll(':scope>.opt')].find(o=>(o.querySelector('label')||{}).textContent==='Fullscreen');if(fs&&!ov.querySelector('#fitopt')){const pf=fs;
 const o=document.createElement('div');o.className='opt';o.id='fitopt';o.innerHTML=`<div><label>Fit to screen on websites</label><small>When the game is embedded in a website: shrink it so all of it fits on screen, and keep the mouse wheel from scrolling the page behind it.</small></div><div class="seg">${[['auto','On'],['off','Off']].map(([v,l])=>`<button class="sm${ST.fitscr===v?' on':''}" data-k="fitscr" data-v="${v}">${l}</button>`).join('')}</div>`;
 pf.after(o);o.querySelectorAll('[data-k]').forEach(b=>b.onclick=()=>{ST.fitscr=b.dataset.v;saveST();applyLayout();o.querySelectorAll('[data-k]').forEach(x=>x.classList.toggle('on',x===b))})}}catch(e){}return st0.apply(this,arguments)}}
