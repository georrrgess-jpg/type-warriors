# Fullscreen on Wix: the game in an iframe asks the page for Big Screen and waits 400 ms for an ack from window.parent.
import asyncio,os,sys,threading,http.server,functools,socketserver
from playwright.async_api import async_playwright
ROOT=os.path.abspath('.');PORT=18473
PARENT="""<!doctype html><html><body style="margin:0;background:#000">
<iframe id="g" src="/out.html" allow="fullscreen 'none'" style="width:1200px;height:700px;border:0"></iframe>
<iframe id="big" src="about:blank" style="width:1200px;height:700px;border:0;display:none"></iframe>
<script>window.got=[];const mode=new URLSearchParams(location.search).get('ack');
addEventListener('message',e=>{if(!e.data||e.data.type!=='type-warriors-fullscreen')return;got.push(e.source===document.getElementById('g').contentWindow?'small':'other');
 if(mode==='yes'){e.source.postMessage({type:'type-warriors-fullscreen-ack'},'*');const b=document.getElementById('big');b.style.display='block';if(b.src==='about:blank')b.src='/out.html'}
 if(mode==='sibling'){document.getElementById('big').contentWindow.postMessage('x','*')}});
</script></body></html>"""
SIB="""<!doctype html><script>addEventListener('message',()=>{parent.frames[0].postMessage({type:'type-warriors-fullscreen-ack'},'*')})</script>"""
class H(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path.startswith('/parent'):b=PARENT.encode();self.send_response(200);self.send_header('Content-Type','text/html');self.end_headers();self.wfile.write(b);return
        if self.path.startswith('/sib'):b=SIB.encode();self.send_response(200);self.send_header('Content-Type','text/html');self.end_headers();self.wfile.write(b);return
        return super().do_GET()
    def log_message(self,*a):pass
async def main():
    socketserver.ThreadingTCPServer.allow_reuse_address=True;srv=socketserver.ThreadingTCPServer(('127.0.0.1',PORT),functools.partial(H,directory=ROOT));threading.Thread(target=srv.serve_forever,daemon=True).start()
    bad=0;er=[]
    def chk(n,v,ok):
        nonlocal bad;bad+=0 if ok else 1;print(n,v,'OK' if ok else 'BAD',flush=True)
    async with async_playwright() as p:
        b=await p.chromium.launch()
        async def open_(q):
            pg=await b.new_page(viewport={'width':1300,'height':800});pg.on('pageerror',lambda e:er.append(str(e)[:200]));await pg.goto(f'http://127.0.0.1:{PORT}/parent?ack={q}');await pg.wait_for_timeout(2500)
            fr=pg.frame_locator('#g');g=[f for f in pg.frames if f.url.endswith('/out.html')][0];await g.evaluate("()=>{RS_ASK=false}");print('   frame fullscreenEnabled:',await g.evaluate("()=>document.fullscreenEnabled"));return pg,g
        # 1. no page code: tip instead of a new tab, no new-tab button
        pg,g=await open_('no');await g.evaluate("()=>toggleFS()");await pg.wait_for_timeout(150);early=await g.evaluate("()=>!!document.getElementById('fsmsg')")
        await pg.wait_for_timeout(500);r=await g.evaluate("()=>{const m=document.getElementById('fsmsg');return m?[m.textContent.includes('F11'),m.textContent.includes('Chromebook'),!!document.getElementById('fso')]:null}")
        chk('no ack: waits 400 ms, then the device-fullscreen tip, no new-tab button',[early,r],early is False and r==[True,True,False])
        await pg.screenshot(path='shots/fs_noack.png');await pg.close()
        # 2. the page acks: no message, a note only mid-run, this copy goes quiet
        pg,g=await open_('yes');await g.evaluate("()=>toggleFS()");await pg.wait_for_timeout(700)
        r=await g.evaluate("()=>[!!document.getElementById('fsmsg'),!!document.getElementById('fsnote'),FSB.dormant]");got=await pg.evaluate("()=>got")
        chk('ack: no message, no note when not mid-run',[r,got],r==[False,False,True] and got==['small'])
        await g.evaluate("()=>{fsWake();start(1)}");await pg.wait_for_timeout(1200);await g.evaluate("()=>toggleFS()");await pg.wait_for_timeout(300)
        r=await g.evaluate("()=>[!!document.getElementById('fsmsg'),(document.getElementById('fsnote')||{}).textContent,S.mode,FSB.dormant]")
        chk('ack mid-run: 2-second note, run paused',r,r[0] is False and r[1] and 'Opening Big Screen' in r[1] and 'restart there' in r[1] and r[2]=='pause' and r[3])
        await pg.screenshot(path='shots/fs_ack_note.png');await pg.wait_for_timeout(2200);r=await g.evaluate("()=>!!document.getElementById('fsnote')");chk('note gone after 2 s',r,r is False)
        # 3. the Big Screen copy saves; the small copy does not ask, and reloads the newest save on the first tap
        await pg.wait_for_timeout(3000);big=[f for f in pg.frames if f.url.endswith('/out.html') and f!=g][0]
        await big.evaluate("()=>{RS_ASK=false;P.gold=424242;save()}");await pg.wait_for_timeout(500)
        r=await g.evaluate("()=>[FSB.stale,!!document.querySelector('.sgm,.sgmodal,[class*=sgmod]'),SGS.stale]");chk('other copy saved: no question while hidden',r,r[0] is True and r[1] is False)
        await g.evaluate("()=>{window.__mark=1}");await pg.locator('#g').click(position={'x':600,'y':350});await pg.wait_for_timeout(3500)
        g=[f for f in pg.frames if f.url.endswith('/out.html')][0];r=await g.evaluate("()=>[typeof window.__mark,P.gold]");chk('first tap back: reloads with the newest save',r,r==['undefined',424242])
        await pg.close()
        # 4. an ack that does not come from the parent is ignored
        pg,g=await open_('sibling');await pg.evaluate("()=>{document.getElementById('big').src='/sib'}");await pg.wait_for_timeout(800)
        await g.evaluate("()=>toggleFS()");await pg.wait_for_timeout(700);r=await g.evaluate("()=>[!!document.getElementById('fsmsg'),FSB.dormant]");chk('ack from another frame ignored',r,r==[True,False]);await pg.close()
        # 5. not in an iframe: the new-tab button stays
        pg=await b.new_page();await pg.goto(f'http://127.0.0.1:{PORT}/out.html');await pg.wait_for_timeout(1500)
        await pg.evaluate("()=>{RS_ASK=false;fsFallback()}");await pg.wait_for_timeout(200);r=await pg.evaluate("()=>[!!document.getElementById('fsmsg'),!!document.getElementById('fso')]");chk('top-level page keeps the new-tab button',r,r==[True,True])
        print('bad',bad);print(er[:5]);await b.close()
    srv.shutdown()
asyncio.run(main())
