/* ===== RUNESTONE TOWER DEFENSE 10.0: integration fixes (98n, after 98m) =====
   - The tower bar fits twelve cards (the Clockwork Hive and the Singularity Engine are open from the start since 10.1): 95m/97e
     size the bar for up to ten (.rp10), 98i/98k add .rp11; this adds .rp12 (cards 68 px, smaller icons and names) in the same
     871 px between the abilities and Next wave. The bar always shows 12 now (the Dragon Roost card shows a lock until earned). */
{const st=document.createElement('style');const P='.rph.rp7.rp8.rp9.rp10.rp11.rp12';
 st.textContent=`${P} .rpbar{gap:2px;padding-left:8px;padding-right:8px}${P} .rpcard{width:68px}${P} .rpct>b{max-width:66px;font-size:10px;letter-spacing:-.1px}
${P} .rpcard img{width:56px;height:56px;margin-left:-28px;top:-15px}${P} .rpcard .rpcc{font-size:11px}`;document.head.appendChild(st)}
{const h0=rpHudOn;rpHudOn=function(){const r=h0.apply(this,arguments);try{const h=$('rphud');if(h){const n=h.querySelectorAll('.rpcard').length;h.classList.toggle('rp11',n>=11);h.classList.toggle('rp12',n>=12)}}catch(e){}return r}}
/* - Clockwork Hive (98i) hooks: its bees skip monsters the core hides this frame (glimmer, dive, leap, shell-free: e.hide), and its reach
     gets the Glowcap bonus like every other tower (tw.glowK, 98b). */
function rpwCanHit(e){return !!e&&!e.dead&&!e.hide}
{const r0=rphvRange;rphvRange=function(R,tw){const r=r0.apply(this,arguments);return tw&&tw.glowK>1&&!tw.rangeK?r*tw.glowK:r}}
/* - Singularity Engine (98k) hooks: its aim skips monsters the core hides (e.hide) and fogged monsters out of reach (Shipwreck Cove),
     like rpTarget does for every other tower in 98b. */
RPGV.see=(R,tw,e)=>{if(e.hide)return false;const fn=R.map&&R.map.fogNear;if(fn&&e.fogd&&tw){const q=rpPos(R,e);if(rpD2(q.x,q.y,tw.x,tw.y)>fn*fn)return false}return true};
{const a0=rpgvAim;rpgvAim=function(R,tw,T,i){if(tw&&tw.glowK>1&&T&&T.range){const k=tw.glowK;T=Object.create(T,{range:{value:T.range.map(r=>r*k)}})}return a0.call(this,R,tw,T,i)}}
/* - the build ring with twelve buttons (10.1: always twelve). Earlier wrappers (95m semicircle, then 95v/97e/98i/98k stretches and
     96zu's stage clamp) left the ring lopsided once 98n scaled it after the clamp: buttons covered each other and the pad near the edges.
     This lays the ring out last, from scratch: twelve buttons spaced evenly by arc length on half an ellipse (rx 340, ry 270) that bulges
     away from the nearest edges, so the pad stays clear; the arc that needs the least shift to sit inside RPSAFE wins; then it is
     clamped. rpnRing(p) returns the offsets (tested by t_ui101). */
{const st=document.createElement('style');st.textContent=`.rph.rp12 .rprb{width:72px;height:72px;left:-36px;top:-36px}.rph.rp12 .rprb img{width:60px;height:60px;margin-top:-12px}.rph.rp12 .rprb em{font-size:11px;padding:2px 6px}`;document.head.appendChild(st)}
const RPN_RING={rx:340,ry:270,pad:58};
function rpnArc(n,dir){const{rx,ry}=RPN_RING,K=400,pts=[];let L=0,px=0,py=0;
 for(let k=0;k<=K;k++){const a=(dir-90+180*k/K)*Math.PI/180,x=Math.cos(a)*rx,y=Math.sin(a)*ry;if(k)L+=Math.hypot(x-px,y-py);pts.push([x,y,L]);px=x;py=y}
 const out=[];let j=0;for(let i=0;i<n;i++){const t=n>1?L*i/(n-1):L/2;while(j<K&&pts[j+1][2]<t)j++;const A=pts[j],B=pts[Math.min(K,j+1)],f=B[2]>A[2]?(t-A[2])/(B[2]-A[2]):0;out.push([A[0]+(B[0]-A[0])*f,A[1]+(B[1]-A[1])*f])}
 /* buttons run left to right along the arc, whichever way it faces */
 if(out.length>1&&out[0][0]>out[out.length-1][0]+1)out.reverse();return out}
function rpnRing(p,n){const S=typeof RPSAFE==='object'?RPSAFE:{x0:96,x1:1504,y0:128,y1:724},h=40;let best=null;
 for(const dir of [90,270,0,180,45,135,315,225]){const pts=rpnArc(n,dir),xs=pts.map(q=>p.x+q[0]),ys=pts.map(q=>p.y+q[1]);
  const lo=Math.min(...xs)-h,hi=Math.max(...xs)+h,top=Math.min(...ys)-h,bot=Math.max(...ys)+h;
  const dx=lo<S.x0?S.x0-lo:hi>S.x1?S.x1-hi:0,dy=top<S.y0?S.y0-top:bot>S.y1?S.y1-bot:0;
  const sh=pts.map(q=>[q[0]+dx,q[1]+dy]),near=Math.min(...sh.map(q=>Math.hypot(q[0],q[1])));
  /* cost: how far the ring had to move, a big penalty when a button would sit on the pad, a small one for the diagonal arcs */
  const cost=Math.hypot(dx,dy)+(near<RPN_RING.pad+36?1e4:0)+(dir%90?40:0)+(dir===0||dir===180?20:0);if(!best||cost<best.cost)best={cost,pts:sh,dir}}
 return best}
{const g0=rpHudRing;rpHudRing=function(R,C){const was=C.rg;const r=g0.apply(this,arguments);try{if(C.rg!==was&&C.rg){const el=$('rpring'),p=R.selPad,bs=[...el.querySelectorAll('.rprb')];
 if(p&&bs.length>=6){const L=rpnRing(p,bs.length);el.dataset.dir=L.dir;bs.forEach((b,i)=>{b.style.setProperty('--x',L.pts[i][0].toFixed(1)+'px');b.style.setProperty('--y',(L.pts[i][1]+8).toFixed(1)+'px')})}}}catch(e){console.error(e)}return r}}
