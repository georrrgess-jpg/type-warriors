/* ---------- drawing primitives ---------- */
function shade(hex,a){const n=parseInt(hex.slice(1,7),16);let r=n>>16,g=n>>8&255,b=n&255;const t=a<0?0:255,p=Math.abs(a);r=Math.round((t-r)*p+r);g=Math.round((t-g)*p+g);b=Math.round((t-b)*p+b);return '#'+((1<<24)+(r<<16)+(g<<8)+b).toString(16).slice(1)}
let OL=0;
const ell=(g,x,y,rx,ry,f,rot)=>{g.beginPath();g.ellipse(x,y,Math.max(.1,rx),Math.max(.1,ry),rot||0,0,TAU);g.fillStyle=f;g.fill();if(OL){g.strokeStyle='#000000a8';g.lineWidth=OL;g.stroke()}};
const poly=(g,p,f,s,lw)=>{g.beginPath();g.moveTo(p[0],p[1]);for(let i=2;i<p.length;i+=2)g.lineTo(p[i],p[i+1]);g.closePath();if(f){g.fillStyle=f;g.fill()}if(s){g.strokeStyle=s;g.lineWidth=lw||2;g.lineJoin='round';g.stroke()}else if(OL&&f){g.strokeStyle='#000000a8';g.lineWidth=OL;g.lineJoin='round';g.stroke()}};
const limb=(g,x0,y0,x1,y1,w,f)=>{if(OL){g.strokeStyle='#000000a8';g.lineWidth=w+OL*2;g.lineCap='round';g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.stroke()}g.strokeStyle=f;g.lineWidth=w;g.lineCap='round';g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.stroke()};
const vgr=(g,y0,y1,c0,c1)=>{const q=g.createLinearGradient(0,y0,0,y1);q.addColorStop(0,c0);q.addColorStop(1,c1);return q};
const hgr=(g,x0,x1,c0,c1)=>{const q=g.createLinearGradient(x0,0,x1,0);q.addColorStop(0,c0);q.addColorStop(1,c1);return q};
const rgr=(g,x,y,r0,r1,c0,c1)=>{const q=g.createRadialGradient(x,y,r0,x,y,r1);q.addColorStop(0,c0);q.addColorStop(1,c1);return q};
const nc=c=>(c.length===4||c.length===5)?'#'+[...c.slice(1)].map(h=>h+h).join(''):c;
const glow=(g,x,y,r,c)=>{c=nc(c);const q=g.createRadialGradient(x,y,0,x,y,r);q.addColorStop(0,c);q.addColorStop(1,c.slice(0,7)+'00');g.fillStyle=q;g.fillRect(x-r,y-r,r*2,r*2)};
const eye=(g,x,y,r,c)=>{c=nc(c);glow(g,x,y,r*3.2,c.slice(0,7)+'99');ell(g,x,y,r,r*.85,c);ell(g,x-r*.1,y,r*.28,r*.75,'#100')};
const rnd=i=>{const x=Math.sin(i*127.1+311.7)*43758.5453;return x-Math.floor(x)};
const lerp=(a,b,u)=>a+(b-a)*u,sstep=(a,b,x)=>{x=Math.max(0,Math.min(1,(x-a)/(b-a)));return x*x*(3-2*x)};
function heart(g,x,y,s,f,st){g.beginPath();g.moveTo(x,y+s*.9);g.bezierCurveTo(x-s*1.5,y-s*.1,x-s*.9,y-s*1.1,x,y-s*.35);g.bezierCurveTo(x+s*.9,y-s*1.1,x+s*1.5,y-s*.1,x,y+s*.9);g.fillStyle=f;g.fill();if(st){g.strokeStyle=st;g.lineWidth=2;g.stroke()}}

/* ---------- monster weapons (drawn upward from the hand) ---------- */
function mweap(g,k,c,t){
 const L=c.wsc||1;g.save();g.scale(L,L);if(k==='axe'||k==='bow')g.scale(-1,1);
 if(k==='club'){g.fillStyle='#6a4526';g.beginPath();g.roundRect(-3,-46,6,48,3);g.fill();ell(g,0,-52,9,14,'#7a5230');for(const [x,y] of[[-6,-58],[6,-54],[-5,-46],[7,-62]])poly(g,[x,y-4,x+3*Math.sign(x),y,x,y+4],'#c8c0a8')}
 else if(k==='sword'){g.fillStyle='#4a3626';g.fillRect(-2.5,-4,5,10);poly(g,[-11,-4,11,-4,11,-8,-11,-8],c.gd||'#c9a545');poly(g,[-5,-8,5,-8,4,-56,0,-64,-4,-56],c.bl||'#b9bfc8');g.fillStyle='#0003';g.fillRect(-.6,-54,1.2,46);if(c.flame){glow(g,0,-36,32,'#ff7a1a99');for(let i=0;i<5;i++)ell(g,Math.sin(t*9+i)*3,-14-i*11,4-i*.4,7,`rgba(255,${140+i*20},40,.75)`)}}
 else if(k==='axe'){g.fillStyle='#5a3c22';g.beginPath();g.roundRect(-3,-56,6,62,3);g.fill();poly(g,[2,-56,26,-66,30,-42,2,-38],c.bl||'#aab2bc','#3a4048',2);poly(g,[-2,-56,-14,-60,-12,-46,-2,-44],c.bl||'#aab2bc')}
 else if(k==='fork'){g.fillStyle='#3a2a20';g.fillRect(-2,-56,4,60);for(const x of[-9,0,9])poly(g,[x-2.5,-60,x+2.5,-60,x,-78],'#c8ccd4');poly(g,[-9,-56,9,-56,9,-60,-9,-60],'#c8ccd4')}
 else if(k==='staff'){g.fillStyle='#3a2a20';g.beginPath();g.roundRect(-2.5,-84,5,90,2);g.fill();const o=c.orb||'#7dff7a';glow(g,0,-92,30,o+'aa');ell(g,0,-92,9,10,o);ell(g,-2,-95,3,3,'#fff')}
 else if(k==='bow'){g.strokeStyle='#6a4526';g.lineWidth=4;g.beginPath();g.arc(0,-24,30,-1.15,1.15);g.stroke();g.strokeStyle='#ddd';g.lineWidth=1.4;g.beginPath();g.moveTo(Math.cos(-1.15)*30,-24+Math.sin(-1.15)*30);g.lineTo(-6,-24);g.lineTo(Math.cos(1.15)*30,-24+Math.sin(1.15)*30);g.stroke();limb(g,-6,-24,-38,-24,2,'#8a6a4a');poly(g,[-38,-24,-30,-28,-30,-20],'#ddd')}
 g.restore()}

/* ---------- generic humanoid ---------- */
function hum(g,t,c){
 const wk=c.walk===undefined?1:c.walk,S7=Math.sin(t*7)*wk,B=c.bulk||1,LH=c.legH||34,lw=c.lw||8,hd=c.hd||13,hn=c.hunch||0,lg=c.lg||0,bob=Math.abs(Math.cos(t*7))*2.5*wk;
 const sk=c.sk,dk=c.dk||shade(sk,-.35),hl=c.hl||shade(sk,.3),SH=-LH-30,tw=15*B;
 g.save();g.lineJoin='round';g.lineCap='round';
 if(c.aura)glow(g,0,-50,70,c.aura+'55');
 if(c.cape){g.fillStyle=c.cape;g.beginPath();g.moveTo(5*B,SH+4);g.quadraticCurveTo(46*B,SH+30+Math.sin(t*3)*4,40*B+Math.sin(t*3)*6,-5);g.lineTo(10*B,-LH+4);g.closePath();g.fill();g.fillStyle='#0003';g.beginPath();g.moveTo(5*B,SH+4);g.quadraticCurveTo(30*B,SH+34,26*B+Math.sin(t*3)*4,-8);g.lineTo(10*B,-LH+4);g.closePath();g.fill()}
 if(c.wing){const f=Math.sin(t*(c.wf||4))*.25,ws=c.ws||1;for(const k of[0,1]){g.save();g.translate(6*B,SH+8);g.rotate(-.35-f-k*.3);g.fillStyle=k?shade(c.wing,-.4):c.wing;g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(24*ws,-46*ws,70*ws,-40*ws);g.quadraticCurveTo(52*ws,-20*ws,62*ws,-2*ws);g.quadraticCurveTo(40*ws,-6*ws,46*ws,18*ws);g.quadraticCurveTo(20*ws,4*ws,0,12*ws);g.closePath();g.fill();g.strokeStyle='#0005';g.lineWidth=1.6;g.beginPath();g.moveTo(0,0);g.lineTo(70*ws,-40*ws);g.moveTo(0,0);g.lineTo(62*ws,-2*ws);g.stroke();g.restore()}}
 if(c.tail){const tw2=Math.sin(t*5)*8;g.strokeStyle=c.dk||dk;g.lineWidth=5;g.beginPath();g.moveTo(8*B,-LH);g.quadraticCurveTo(38*B,-LH+10+tw2,48*B,-LH-22+tw2);g.stroke();if(c.tail==='spade')poly(g,[48*B,-LH-22+tw2,56*B,-LH-34+tw2,60*B,-LH-14+tw2],c.hl||hl)}
 const leg=(hx,fx,col)=>{const kx=(hx+fx)/2-5,ky=-LH/2+2;limb(g,hx,-LH+2,kx,ky,lw,col);limb(g,kx,ky,fx,-3,lw*.9,col);ell(g,fx-4,-3,lw*.95,3.6,shade(col,-.3))};
 const bl=c.bone?sk:null;
 leg(6*B,9-S7*11,shade(sk,-.32));leg(-6*B,-7+S7*11,sk);
 if(c.cl){g.fillStyle=c.cl;if(c.robe){g.beginPath();g.moveTo(-15*B,-LH-6);g.quadraticCurveTo(-24*B+S7*3,-16,-22*B+S7*4,-2);g.lineTo(22*B+S7*4,-2);g.quadraticCurveTo(24*B+S7*3,-16,15*B,-LH-6);g.fill();g.fillStyle='#0004';g.fillRect(-2,-LH-4,4,LH)}else{poly(g,[-12*B,-LH-2,-14*B+S7*2,-LH+20,-2,-LH+14,12*B,-LH+20,12*B,-LH-2],c.cl);g.fillStyle='#0003';g.fillRect(-12*B,-LH-2,24*B,5)}}
 g.save();g.translate(-hn*5,-bob);
 const arm=(sx,hx,hy,col)=>{const ex=(sx+hx)/2-4,ey=(SH+8+hy)/2+6;limb(g,sx,SH+8,ex,ey,lw*.78,col);limb(g,ex,ey,hx,hy,lw*.72,col);ell(g,hx,hy,lw*.62,lw*.62,shade(col,-.15))};
 const sw=Math.sin(t*7+Math.PI)*5;
 if(c.zomb){arm(6*B,-30*B-4,SH+22,shade(sk,-.3))}else arm(6*B,4+sw,-LH-10,shade(sk,-.32));
 if(c.bone){for(let i=0;i<4;i++){g.strokeStyle=sk;g.lineWidth=3.2;g.beginPath();g.ellipse(0,SH+9+i*7,tw*(.95-i*.09),4.6,0,0,TAU);g.stroke()}limb(g,0,SH+2,0,-LH,4,dk);poly(g,[-9,-LH+3,9,-LH+3,7,-LH+11,-7,-LH+11],sk);if(c.top){g.fillStyle=c.top;g.globalAlpha=.85;g.beginPath();g.moveTo(-tw,SH+6);g.lineTo(tw,SH+10);g.lineTo(tw*.8,SH+26);g.lineTo(tw*.2,SH+22);g.lineTo(-tw*.3,SH+30);g.lineTo(-tw,SH+20);g.fill();g.globalAlpha=1}}
 else{g.beginPath();g.roundRect(-tw,SH,tw*2,-LH-SH+3,11);g.fillStyle=hgr(g,-tw,tw,hl,dk);g.fill();if(c.belly)ell(g,-5*B,-LH-8,tw*.85,14,shade(sk,.18));if(c.top){g.fillStyle=c.top;g.beginPath();g.roundRect(-tw,SH+2,tw*2,-LH-SH-8,9);g.fill();g.fillStyle='#0003';for(let i=0;i<4;i++)poly(g,[-tw+i*tw/2,-LH-5,-tw+i*tw/2+tw/4,-LH+4,-tw+i*tw/2+tw/2,-LH-5],'#0003')}if(c.fur){g.fillStyle=c.fur;for(let i=0;i<9;i++){const y=SH+i*4.2;poly(g,[-tw-2,y,-tw-9-(i%2)*4,y+5,-tw+2,y+7],c.fur);poly(g,[tw+2,y,tw+9+(i%2)*4,y+5,tw-2,y+7],c.fur)}}}
 if(c.fx)c.fx(g,t,{tw,SH,LH,B});
 const hx=-3-hn*7,hy=SH-hd+5;
 limb(g,hx+3,hy+hd*.6,0,SH+4,hd*.7,c.bone?dk:sk);
 if(c.ear==='pt'){poly(g,[hx-hd*.55,hy-hd*.45,hx-hd*2.2,hy-hd*1.1,hx-hd*.9,hy+hd*.2],dk);poly(g,[hx+hd*.5,hy-hd*.6,hx+hd*2,hy-hd*1.2,hx+hd*.85,hy+hd*.2],shade(dk,-.25))}
 if(c.horn){const hc=c.horn,hl2=c.hornL||1;for(const k of[0,1]){g.strokeStyle=hc;g.lineWidth=(5-k)*hl2;g.beginPath();g.moveTo(hx-hd*.4+k*hd*.9,hy-hd*.7);g.quadraticCurveTo(hx-hd*(1.3-k)*hl2,hy-hd*1.9*hl2,hx-hd*(1.9-k*1.2)*hl2,hy-hd*2.2*hl2);g.stroke()}}
 g.beginPath();g.arc(hx,hy,hd,0,TAU);g.fillStyle=c.bone?sk:rgr(g,hx-hd*.3,hy-hd*.3,1,hd*1.2,hl,dk);g.fill();
 if(c.face){ell(g,hx-hd*.35,hy+hd*.15,hd*.62,hd*.6,c.face)}
 if(c.nose)poly(g,[hx-hd*.9,hy+hd*.05,hx-hd*1.9,hy+hd*.55,hx-hd*.8,hy+hd*.45],dk);
 if(c.bone){ell(g,hx-hd*.3,hy-hd*.05,hd*.34,hd*.4,'#150f0a');ell(g,hx+hd*.35,hy-hd*.05,hd*.28,hd*.34,'#150f0a');eye(g,hx-hd*.3,hy-hd*.05,hd*.16,c.eye||'#7fffd0');poly(g,[hx-hd*.1,hy+hd*.25,hx+hd*.05,hy+hd*.25,hx-hd*.02,hy+hd*.5],'#150f0a');g.fillStyle=shade(sk,-.1);g.fillRect(hx-hd*.7,hy+hd*.55,hd*1.3,hd*.42);g.fillStyle='#150f0a';for(let i=0;i<5;i++)g.fillRect(hx-hd*.6+i*hd*.27,hy+hd*.56,1.4,hd*.4)}
 else{eye(g,hx-hd*.42,hy-hd*.12,hd*.24,c.eye||'#ffe04a');ell(g,hx+hd*.25,hy-hd*.15,hd*.16,hd*.16,c.eye||'#ffe04a');g.strokeStyle='#0008';g.lineWidth=1.8;g.beginPath();g.moveTo(hx-hd*.8,hy-hd*.5);g.lineTo(hx-hd*.1,hy-hd*.28);g.stroke();g.beginPath();g.moveTo(hx-hd*.75,hy+hd*.5);g.lineTo(hx-hd*.05,hy+hd*.55);g.stroke();if(c.fang||c.tusk){poly(g,[hx-hd*.7,hy+hd*.52,hx-hd*.55,hy+hd*.52,hx-hd*.62,hy+hd*.12],'#f4ecd0');poly(g,[hx-hd*.25,hy+hd*.54,hx-hd*.1,hy+hd*.54,hx-hd*.17,hy+hd*.2],'#f4ecd0')}if(c.tusk){poly(g,[hx-hd*.9,hy+hd*.5,hx-hd*1.35,hy-hd*.7,hx-hd*.7,hy+hd*.3],'#f4ecd0')}}
 if(c.crown){g.fillStyle='#ffc94a';g.beginPath();g.moveTo(hx-hd*.9,hy-hd*.65);g.lineTo(hx-hd*.9,hy-hd*1.5);g.lineTo(hx-hd*.45,hy-hd*1.05);g.lineTo(hx,hy-hd*1.7);g.lineTo(hx+hd*.45,hy-hd*1.05);g.lineTo(hx+hd*.9,hy-hd*1.5);g.lineTo(hx+hd*.9,hy-hd*.65);g.closePath();g.fill();g.strokeStyle='#8a5a10';g.lineWidth=1.5;g.stroke();ell(g,hx,hy-hd*.95,hd*.14,hd*.14,'#e8455a')}
 if(c.pad){for(const [x,k] of[[-tw+2,0],[tw-2,1]]){g.fillStyle=c.pad;g.beginPath();g.ellipse(x,SH+4,11*B,8,0,Math.PI,TAU);g.fill();if(c.padspike)poly(g,[x-5,SH-2,x,SH-14,x+5,SH-2],shade(c.pad,.3))}}
 const ax=-27*B-(c.reach||0)-lg*18,ay=c.zomb?SH+22:-LH-8-lg*22+sw*.4;
 arm(-6*B,ax,ay,sk);
 if(c.wp){g.save();g.translate(ax,ay);g.rotate(.55-lg*2-Math.sin(t*7)*.06);mweap(g,c.wp,c,t);g.restore();ell(g,ax,ay,lw*.66,lw*.66,shade(sk,-.1))}
 g.restore();g.restore()}

/* ---------- creatures ---------- */
function bat(g,t,o,c){c=c||{};const col=c.col||'#5b3a80',dk=shade(col,-.4),fl=Math.sin(t*15),cy=-52+Math.sin(t*4)*3;
 const wing=(k)=>{g.save();g.translate(4+k*7,cy-8);g.rotate(-.35-.75*fl+k*.25);g.fillStyle=k?dk:shade(col,.12);g.beginPath();g.moveTo(0,0);g.lineTo(32,-26);g.lineTo(62,-18);g.lineTo(78,4);g.quadraticCurveTo(66,2,60,18);g.quadraticCurveTo(48,4,40,20);g.quadraticCurveTo(28,4,14,14);g.closePath();g.fill();g.strokeStyle='#0006';g.lineWidth=1.6;g.beginPath();g.moveTo(0,0);g.lineTo(32,-26);g.moveTo(0,0);g.lineTo(62,-18);g.moveTo(0,0);g.lineTo(78,4);g.moveTo(0,0);g.lineTo(60,18);g.stroke();g.restore()};
 if(c.aura)glow(g,0,cy,60,c.aura+'55');
 wing(1);ell(g,0,cy,16,12,vgr(g,cy-12,cy+12,shade(col,.2),dk),-.25);
 poly(g,[-6,cy+9,-2,cy+22,4,cy+9],dk);limb(g,-3,cy+10,-6,cy+18,2,'#222');limb(g,3,cy+10,4,cy+18,2,'#222');
 wing(0);
 ell(g,-16,cy-3,10,9,shade(col,.1));poly(g,[-20,cy-9,-24,cy-24,-13,cy-11],col);poly(g,[-12,cy-11,-8,cy-25,-5,cy-10],dk);
 poly(g,[-25,cy-1,-30,cy+3,-24,cy+3],dk);eye(g,-19,cy-5,2.6,c.eye||'#ff4a5a');
 poly(g,[-23,cy+3,-21.5,cy+9,-20,cy+3],'#fff');poly(g,[-18,cy+3,-16.5,cy+8,-15,cy+3],'#fff')}
function ghost(g,t,o){const y0=-14,ha=Math.sin(t*3)*4;glow(g,0,-60,80,'#a8f0ff55');g.save();g.globalAlpha=.88;
 g.beginPath();g.moveTo(-26,-64);g.quadraticCurveTo(-30,-104+ha,0,-106+ha);g.quadraticCurveTo(30,-104+ha,26,-64);g.lineTo(30,y0);
 for(let i=0;i<6;i++){const x=30-i*12;g.quadraticCurveTo(x-3,y0+14+Math.sin(t*5+i)*7,x-6,y0+Math.sin(t*4+i)*3)}
 g.lineTo(-30,y0-4);g.closePath();g.fillStyle=vgr(g,-106,y0,'#f4fcff','#7ec8e8');g.fill();g.globalAlpha=.45;g.fillStyle='#fff';g.beginPath();g.ellipse(-8,-86+ha,7,15,.3,0,TAU);g.fill();g.globalAlpha=.9;
 ell(g,-8,-78+ha,14,17,'#0a1420');ell(g,16,-80+ha,6,8,'#0a1420');eye(g,-13,-80+ha,3.4,'#9ff');eye(g,-1,-80+ha,3,'#9ff');ell(g,-7,-66+ha,5,7+Math.sin(t*4)*1.5,'#050b12');
 const arm=(x,y,k)=>{g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x-24,y+10+Math.sin(t*3+k)*6,x-40,y-4+Math.sin(t*3+k)*8);g.strokeStyle='#dff6ff';g.lineWidth=9;g.lineCap='round';g.stroke();g.strokeStyle='#0004';g.lineWidth=2;g.stroke()};
 arm(-18,-52,0);arm(10,-48,2);g.restore()}
function snake(g,t,o){const N=26;let pts=[];for(let i=0;i<N;i++){const s=i/(N-1),x=lerp(74,-14,s),y=-9-sstep(.5,1,s)*66+Math.sin(s*9-t*5)*6*(1-s*.6);pts.push([x,y])}
 for(let i=0;i<N;i++){const s=i/(N-1),r=lerp(3,10,Math.sin(s*Math.PI*.9+.4)*.8+.1);ell(g,pts[i][0],pts[i][1],r*1.15,r,i%2?'#3d8a3a':'#4aa044')}
 for(let i=0;i<N;i+=2){const s=i/(N-1);ell(g,pts[i][0],pts[i][1]-1,3,2.4,'#c9e04a')}
 const [hx,hy]=pts[N-1];ell(g,hx+5,hy+10,15+Math.sin(t*3)*1.2,22,'#2f6f30',.2);ell(g,hx+3,hy+10,10,17,'#c9e04a',.2);ell(g,hx,hy,14,10,'#4aa044');poly(g,[hx-10,hy+2,hx-24,hy+6,hx-10,hy+9],'#3d8a3a');
 eye(g,hx-3,hy-3,3.4,'#ffe14a');poly(g,[hx-15,hy+7,hx-13,hy+17,hx-11,hy+7],'#fff');const tg=Math.sin(t*14)*3;g.strokeStyle='#e8455a';g.lineWidth=2;g.beginPath();g.moveTo(hx-22,hy+6);g.lineTo(hx-34,hy+6+tg);g.lineTo(hx-38,hy+2+tg);g.moveTo(hx-34,hy+6+tg);g.lineTo(hx-38,hy+10+tg);g.stroke()}
function spid(g,t,o,c){c=c||{};const col=c.col||'#2a2032',hi=c.hi||'#5a4270',s=c.s||1;g.save();g.scale(s,s);if(c.aura)glow(g,0,-40,90,c.aura+'55');
 const leg=(hx,k,near)=>{const ph=t*9+k*1.3+(near?0:1.6),up=Math.max(0,Math.sin(ph))*9,ex=hx*1.0+(k-1.5)*16-(near?6:0),fx=ex-8*Math.cos(ph)+ (hx<0?-18:16),kx=(hx+fx)/2+(hx<0?-14:8),ky=-70-k*2;g.strokeStyle=near?col:shade(col,-.3);g.lineWidth=near?4.4:3.2;g.lineCap='round';g.lineJoin='round';g.beginPath();g.moveTo(hx,-38);g.lineTo(kx,ky);g.lineTo(fx,-2-up);g.stroke();g.strokeStyle=near?hi:'#0000';g.lineWidth=1;g.stroke()};
 for(let k=0;k<4;k++)leg(-6+k*5,k,0);
 ell(g,20,-42,24,20,vgr(g,-62,-22,hi,col),.15);ell(g,-12,-40,15,12,vgr(g,-52,-28,hi,col));
 if(c.mark){poly(g,[16,-52,26,-52,22,-44,26,-34,16,-34,20,-44],c.mark)}else{poly(g,[16,-52,26,-52,22,-44,26,-34,16,-34,20,-44],'#c81e3a')}
 for(let k=0;k<4;k++)leg(-6+k*5,k,1);
 for(const [x,y,r] of[[-22,-45,3.2],[-17,-49,2.4],[-12,-46,2],[-24,-40,2.2]])eye(g,x,y,r,c.eye||'#ff3b5a');
 poly(g,[-25,-34,-22,-24,-19,-34],'#d8d0b8');poly(g,[-18,-34,-14,-25,-12,-34],'#d8d0b8');
 if(c.crown){g.fillStyle='#ffc94a';g.beginPath();g.moveTo(-24,-52);g.lineTo(-24,-66);g.lineTo(-18,-58);g.lineTo(-12,-70);g.lineTo(-6,-58);g.lineTo(-2,-64);g.lineTo(-2,-52);g.closePath();g.fill();ell(g,-13,-60,2,2,'#e8455a')}
 g.restore()}
function scor(g,t,o){const col='#7a4a2a',hi='#c8843a',dk='#3a2010',w=Math.sin(t*3)*4;
 for(let k=0;k<4;k++){const ph=t*8+k*1.4,x=-4+k*9,up=Math.max(0,Math.sin(ph))*6;limb(g,x,-22,x-10+Math.sin(ph)*5,-26,4,dk);limb(g,x-10+Math.sin(ph)*5,-26,x-14+Math.cos(ph)*4,-2-up,3.6,dk)}
 for(let i=0;i<26;i++){const s=i/25,x=lerp(28,88,s),y=-28-Math.sin(s*Math.PI*.95)*66+(s>.75?(s-.75)*40:0)+Math.sin(t*3+i*.2)*2;ell(g,x,y,lerp(9.5,5,s),lerp(8.5,4.4,s),i%2?col:hi)}
 poly(g,[82,-80,96,-66+w*.3,84,-64],'#e8455a');ell(g,86,-72,3,3,'#ffe14a');
 ell(g,4,-30,32,17,vgr(g,-47,-13,hi,dk));for(let i=0;i<5;i++)limb(g,-12+i*9,-44,-12+i*9,-18,1.6,'#0004');
 const claw=(k)=>{const a=Math.sin(t*4+k*2)*.15,bx=-34,by=-32+k*4;limb(g,-20,-30+k*3,bx-8,by,7,dk);g.save();g.translate(bx-8,by);g.rotate(a-k*.1);ell(g,-10,-4,14,9,vgr(g,-12,4,hi,col),-.1);poly(g,[-20,-6,-32,-2,-20,2],dk);poly(g,[-14,-12,-26,-16,-16,-6],col);g.restore()};
 claw(0);claw(1);ell(g,-22,-40,6,6,col);eye(g,-24,-42,2.6,'#ff4a4a')}
function flame(g,t,o){glow(g,0,-55,90,'#ff7a1a66');const L=[['#d8300a',1],['#ff6a1a',.82],['#ffae2a',.62],['#fff0a0',.4]];
 L.forEach(([c,s],l)=>{g.fillStyle=c;g.beginPath();g.moveTo(-26*s,-8);g.bezierCurveTo(-34*s+Math.sin(t*6+l)*4,-50,-14*s,-72*s,Math.sin(t*7+l)*7,-108*s-l*2);g.bezierCurveTo(16*s,-72*s,34*s+Math.sin(t*5+l)*4,-46,26*s,-8);g.quadraticCurveTo(0,4,-26*s,-8);g.fill()});
 for(const k of[0,1]){g.fillStyle='#ff8a2a';g.beginPath();g.moveTo(-18,-64);g.quadraticCurveTo(-44-k*4,-56+Math.sin(t*6+k)*6,-58-k*6,-66+Math.sin(t*5+k)*10);g.quadraticCurveTo(-42,-46,-14,-50);g.fill()}
 eye(g,-9,-66,4,'#300');eye(g,5,-66,3.4,'#300');ell(g,-9,-66,2,2.6,'#fff');ell(g,5,-66,1.8,2.3,'#fff');poly(g,[-12,-52,0,-52,-6,-44],'#300');
 for(let i=0;i<6;i++){const u=(t*.9+i/6)%1;ell(g,Math.sin(i*5)*24,-30-u*100,2.6*(1-u),2.6*(1-u),'#ffcf5a')}}
function wolf(g,t,o,c){c=c||{};const col=c.col||'#6a6470',hi=c.hi||'#9a94a2',dk=shade(col,-.4),g1=Math.sin(t*10)*.5;
 const leg=(x,ph,near)=>{const a=Math.sin(t*10+ph)*.55,b=Math.cos(t*10+ph)*.4;const col2=near?col:dk;limb(g,x,-36,x+a*20-2,-18,near?9:7,col2);limb(g,x+a*20-2,-18,x+a*30-6,-3+Math.max(0,b)*-4,near?7:5.5,col2);ell(g,x+a*30-9,-3,6,3.4,dk)};
 leg(26,0,0);leg(-14,Math.PI,0);
 g.strokeStyle=col;g.lineWidth=12;g.lineCap='round';g.beginPath();g.moveTo(38,-52);g.quadraticCurveTo(62,-46+g1*6,70,-26+g1*8);g.stroke();g.strokeStyle=hi;g.lineWidth=5;g.stroke();
 ell(g,6,-46,36,20,vgr(g,-66,-26,hi,col));ell(g,-10,-42,22,15,shade(hi,.2));
 leg(30,Math.PI+.7,1);leg(-10,.7,1);
 for(let i=0;i<7;i++)poly(g,[-14+i*8,-64+Math.abs(3-i),-10+i*8,-72,-6+i*8,-64+Math.abs(3-i)],col);
 ell(g,-36,-64,17,14,vgr(g,-78,-50,hi,col),-.2);poly(g,[-46,-64,-70,-56,-68,-50,-46,-50],shade(hi,.1));poly(g,[-70,-56,-72,-52,-66,-52],'#111');
 poly(g,[-44,-50,-66,-50,-56,-42],'#f4ecd0');poly(g,[-46,-50,-60,-50,-53,-45],'#a02a3a');
 poly(g,[-32,-74,-30,-92,-22,-74],col);poly(g,[-26,-74,-20,-90,-14,-72],dk);eye(g,-42,-66,3,c.eye||'#ffdd33')}
/* a proper crab claw: the wrist is the origin, the pincers point to the left; op opens the lower finger */
function crabClaw(g,col,hi,dk,op,lw){const ol='#000000b0';g.save();g.lineJoin='round';g.lineCap='round';
 const finger=(sy,top)=>{g.save();g.translate(-30,sy);if(!top)g.rotate(-op);const m=top?-1:1;
  g.beginPath();g.moveTo(10,m*8);g.quadraticCurveTo(-30,m*26,-54,m*-1);g.quadraticCurveTo(-34,m*-9,-14,m*-4);g.quadraticCurveTo(0,m*-2,10,m*-8);g.closePath();
  g.fillStyle=top?hi:col;g.fill();g.strokeStyle=ol;g.lineWidth=lw||2.4;g.stroke();
  g.fillStyle='#f4ecd0';for(let k=0;k<4;k++){const x=-16-k*9,y=m*(-5+k*1.4);g.beginPath();g.moveTo(x,y);g.lineTo(x-4.5,y+m*(-5.5));g.lineTo(x-9,y+m*-.5);g.closePath();g.fill()}
  g.restore()};
 finger(10,0);
 g.beginPath();g.ellipse(-18,0,29,22,-.08,0,TAU);g.fillStyle=vgr(g,-22,22,hi,col);g.fill();g.strokeStyle=ol;g.lineWidth=lw||2.4;g.stroke();
 g.fillStyle='#ffffff30';g.beginPath();g.ellipse(-24,-9,15,6,-.2,0,TAU);g.fill();
 finger(-10,1);
 g.beginPath();g.ellipse(-18,0,29,22,-.08,0,TAU);g.save();g.clip();g.fillStyle=vgr(g,-22,22,hi,col);g.fillRect(-60,-30,80,60);g.fillStyle='#ffffff30';g.beginPath();g.ellipse(-24,-9,15,6,-.2,0,TAU);g.fill();g.restore();
 g.beginPath();g.ellipse(-18,0,29,22,-.08,0,TAU);g.strokeStyle=ol;g.lineWidth=lw||2.4;g.stroke();g.restore()}
function crab(g,t,o){const col='#c8442e',hi='#ee7a4a',dk='#7a2416',s=Math.sin(t*8),lg=o.lg||0;g.save();g.lineJoin='round';g.lineCap='round';
 ell(g,0,0,52,5,'#0004');
 for(const sd of[-1,1])for(let k=0;k<3;k++){const ph=t*9+k*1.2+(sd>0?1.5:0),up=Math.max(0,Math.sin(ph))*4,sx=sd*(14+k*7),kx=sd*(34+k*9),fx=sd*(44+k*12)+Math.cos(ph)*3;limb(g,sx,-20,kx,-40+k*3,4.4,dk);limb(g,kx,-40+k*3,fx,-2-up,3.4,dk)}
 const arm=(k)=>{const bob=Math.sin(t*4+k*2)*2.5,sx=-26+k*8,sy=-28-k*8,ex=-40+k*6,ey=-50-k*8+bob,wx=-48+k*4-lg*8,wy=-34-k*8+bob,sc=.5-k*.06;
  const c=k?dk:col,h=k?col:hi;limb(g,sx,sy,ex,ey,6.4,c);limb(g,ex,ey,wx,wy,5.6,c);ell(g,ex,ey,4.2,4.2,h);g.save();g.translate(wx,wy);g.rotate(-.3+Math.sin(t*4+k*2)*.12);g.scale(sc,sc);crabClaw(g,c,h,dk,.28+Math.sin(t*5+k*2)*.18+lg*.4,3.6);g.restore()};
 arm(1);
 ell(g,0,-28,36,22,vgr(g,-50,-6,hi,col));ell(g,0,-20,34,12,'#7a24165a');ell(g,-6,-38,20,6,'#ffffff30');for(let i=0;i<8;i++)ell(g,-20+i*6,-32+Math.sin(i)*3,2.4,2.4,'#0003');
 arm(0);
 for(const [x,h2] of[[-18,0],[-8,1]]){limb(g,x,-44,x-3,-56-h2*2,2.6,dk);ell(g,x-3,-58-h2*2,5,5,'#fff');ell(g,x-5,-58-h2*2,2.4,3,'#111')}
 g.restore()}
function fish(g,t,o){const col='#4a7ac8',hi='#9ad0ff',dk='#2a3a78',w=Math.sin(t*10)*6,cy=-50;
 poly(g,[24,cy,54,cy-22+w,50,cy+w*.3,54,cy+22+w],dk);poly(g,[-4,cy-22,12,cy-42,20,cy-16],dk);poly(g,[0,cy+18,12,cy+34,18,cy+14],dk);
 ell(g,0,cy,34,22,vgr(g,cy-22,cy+22,hi,col));ell(g,-2,cy+9,26,10,'#e8f4ff');
 for(let i=0;i<10;i++){g.strokeStyle='#0002';g.lineWidth=1.2;g.beginPath();g.arc(-6+(i%5)*9,cy-8+Math.floor(i/5)*10,4,0,Math.PI);g.stroke()}
 poly(g,[-30,cy+2,-14,cy+2,-22,cy+12,-30,cy+8],'#3a0810');for(let i=0;i<5;i++)poly(g,[-30+i*3.6,cy+3,-28+i*3.6,cy+10,-26+i*3.6,cy+3],'#fff');
 poly(g,[10,cy-4,24,cy+8,8,cy+12],dk);eye(g,-18,cy-8,4.6,'#ffe14a')}
function octo(g,t,o){const col='#8a3aa8',hi='#c86ae0',dk='#4a1a68';
 for(let i=0;i<8;i++){const bx=-34+i*10,ph=t*3+i*.8;for(let j=0;j<12;j++){const u=j/11,x=bx+(i-3.5)*u*16+Math.sin(ph+u*4)*10*u,y=-30+u*28+Math.abs(Math.sin(ph+u*3))*-10*u;ell(g,x,Math.min(-2,y),lerp(6.5,2.2,u),lerp(6,2,u),i%2?col:hi);if(j%3===1)ell(g,x-1,Math.min(-2,y)+2,1.6,1.6,'#f6d8ff')}}
 ell(g,0,-74,36,42,vgr(g,-116,-32,hi,col));ell(g,-8,-90,14,18,'#ffffff22');
 for(const x of[-14,12]){ell(g,x,-66,9,10,'#f4f0d8');ell(g,x-1.5,-66,3.8,8,'#111');ell(g,x-2.5,-69,1.6,1.6,'#fff')}
 g.strokeStyle=dk;g.lineWidth=3;g.beginPath();g.moveTo(-14,-78);g.lineTo(-2,-74);g.moveTo(8,-78);g.lineTo(20,-72);g.stroke()}
function frostSk(g,t,o){hum(g,t,{lg:o.lg,bone:1,sk:'#d6ecfa',dk:'#7aa0c0',eye:'#7fd8ff',wp:'bow',cl:'#2f4f7a',top:'#3a5a8a',lw:4,bulk:.8,hd:13,wsc:1,reach:2,fx:(g,t,q)=>{glow(g,0,-60,60,'#7fd8ff33')}})}

/* ---------- bosses ---------- */
function wyrm(g,t,o){const fl=Math.sin(t*3),col='#77bde6',dk='#356ea0',lt='#dff6ff';glow(g,-20,-70,150,'#8fdcff44');
 for(let i=0;i<16;i++){const u=i/15,x=38+u*110,y=-44+Math.sin(u*4-t*3)*10*u+u*26;ell(g,x,y,lerp(18,3,u),lerp(14,2.5,u),i%2?dk:col)}
 poly(g,[140,-14,164,-24,150,-10,166,-2,146,-4],lt);
 g.save();g.translate(14,-78);g.rotate(-.1+fl*.14);g.fillStyle=dk;g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(20,-100,84,-124);g.quadraticCurveTo(68,-90,96,-70);g.quadraticCurveTo(70,-66,80,-34);g.quadraticCurveTo(46,-46,44,-10);g.quadraticCurveTo(20,-16,0,0);g.fill();g.fillStyle='#8fd4f8aa';g.beginPath();g.moveTo(4,-4);g.quadraticCurveTo(24,-86,78,-112);g.quadraticCurveTo(64,-86,88,-68);g.quadraticCurveTo(60,-64,68,-36);g.quadraticCurveTo(40,-46,36,-14);g.closePath();g.fill();g.strokeStyle=lt;g.lineWidth=2.4;g.beginPath();g.moveTo(0,0);g.lineTo(84,-124);g.moveTo(0,0);g.lineTo(96,-70);g.moveTo(0,0);g.lineTo(80,-34);g.stroke();g.restore();
 const leg=(x,ph)=>{const a=Math.sin(t*4+ph)*.2;limb(g,x,-34,x+a*8,-16,13,dk);limb(g,x+a*8,-16,x+a*14-3,-3,10,col);poly(g,[x+a*14-12,-2,x+a*14-3,-10,x+a*14+6,-2],lt)};leg(46,0);leg(-14,1.4);
 ell(g,20,-56,54,32,vgr(g,-88,-24,lt,col),.08);ell(g,14,-40,44,14,'#f6fcff');for(let i=0;i<6;i++)poly(g,[-20+i*13,-84+Math.abs(2.5-i)*3,-13+i*13,-100+Math.abs(2.5-i)*3,-6+i*13,-84+Math.abs(2.5-i)*3],lt);
 leg(38,2.3);leg(-22,3.5);
 for(let i=0;i<12;i++){const u=i/11,x=lerp(-16,-60,u),y=lerp(-74,-98,u)-Math.sin(u*Math.PI)*8+Math.sin(t*2+u*3)*2;ell(g,x,y,lerp(20,12,u),lerp(18,11,u),i%2?col:lt)}
 g.save();g.translate(-70,-104);poly(g,[8,-6,-38,-4,-46,6,-30,14,10,14],col,dk,2);poly(g,[-36,4,-46,6,-30,14,-10,14],'#f6fcff');
 const jw=8+Math.sin(t*3)*5;poly(g,[8,12,-36,10+jw*.4,-42,14+jw,-26,20+jw,4,20],dk);for(let i=0;i<5;i++)poly(g,[-34+i*8,14,-31+i*8,22+jw*.5,-28+i*8,14],'#fff');
 poly(g,[4,-10,26,-34,16,-6],lt);poly(g,[10,-4,40,-22,20,2],'#a8dcff');eye(g,-14,-2,4.4,'#8ff');
 for(let k=0;k<7;k++){const u=(t*.8+k/7)%1;g.globalAlpha=.55*(1-u);ell(g,-46-u*90,10+jw*.6+Math.sin(k*3)*8,8+u*30,7+u*24,'#dff6ff')}g.globalAlpha=1;g.restore()}
function kraken(g,t,o){const col='#2f5aa0',hi='#5a92d8',dk='#16305a';glow(g,0,-90,150,'#4a9aff44');
 for(let i=0;i<8;i++){const bx=-78+i*22,ph=t*2+i*.9,dir=(i-3.5)*.4;for(let j=0;j<20;j++){const u=j/19,x=bx+dir*u*90+Math.sin(ph+u*5)*18*u,y=-30+Math.sin(u*Math.PI*.9)*(-46*(i%2?1:.5))+u*30-Math.abs(Math.sin(ph+u*2))*10*u;const yy=Math.min(-4,y),r=lerp(13,3,u);ell(g,x,yy,r*1.1,r,j%2?col:hi);if(j%3===1)ell(g,x,yy+r*.4,r*.32,r*.32,'#f0d8c8')}}
 ell(g,4,-102,58,68,vgr(g,-170,-36,hi,dk));ell(g,-10,-130,22,26,'#ffffff20');
 for(let i=0;i<9;i++){const a=-Math.PI+i*Math.PI/8,x=4+Math.cos(a)*58,y=-102+Math.sin(a)*66;poly(g,[x-5,y,x+Math.cos(a)*14,y+Math.sin(a)*22,x+5,y],'#8ad0ff')}
 for(const x of[-24,28]){ell(g,x,-98,15,17,'#f8f0c0');ell(g,x-2,-98,5.6,14,'#111');glow(g,x,-98,40,'#ffe14a66');ell(g,x-4,-104,2.4,2.4,'#fff')}
 g.strokeStyle=dk;g.lineWidth=5;g.beginPath();g.moveTo(-42,-120);g.lineTo(-10,-112);g.moveTo(44,-124);g.lineTo(12,-112);g.stroke();
 ell(g,2,-70,16,10,'#2a0a1a');poly(g,[-8,-72,-2,-64,4,-72],'#fff');poly(g,[4,-72,10,-64,14,-72],'#fff');
 g.fillStyle='#ffc94a';g.beginPath();g.moveTo(-32,-160);g.lineTo(-28,-176);g.lineTo(-16,-164);g.lineTo(4,-182);g.lineTo(22,-164);g.lineTo(34,-176);g.lineTo(38,-160);g.closePath();g.fill()}
const CFG={
gob:o=>({lg:o.lg,sk:'#62b04a',cl:'#6a4a2a',hd:14,hunch:1,ear:'pt',nose:1,eye:'#ffe04a',fang:1,wp:'club',bulk:.9,reach:4,legH:32,pad:'#7a5a3a'}),
troll:o=>({lg:o.lg,sk:'#6a9048',dk:'#3a5a2a',cl:'#5a4a30',hd:13,hunch:1.3,nose:1,tusk:1,eye:'#ffcf3a',wp:'club',wsc:1.5,bulk:1.75,lw:12,reach:8,legH:32,belly:1,fx:(g,t,q)=>{ell(g,-10,q.SH+4,12,7,'#3f7a2a');ell(g,8,q.SH+8,9,5,'#4a8a34');ell(g,-4,-40,10,5,'#3f7a2a')}}),
skel:o=>({lg:o.lg,bone:1,sk:'#e8e2cc',dk:'#8a8470',eye:'#7fffd0',wp:'sword',bl:'#9a8a70',lw:4,bulk:.8,cl:'#3a2a4a'}),
zomb:o=>({lg:o.lg,sk:'#7c9c6c',dk:'#3e5a3a',cl:'#4a4058',top:'#4a4058',hd:13,hunch:1.5,eye:'#e8ff7a',fang:1,zomb:1,bulk:1.05,walk:.55,legH:33,reach:6}),
imp:o=>({lg:o.lg,sk:'#d8402e',cl:'#3a1a1a',hd:12,ear:'pt',horn:'#2a0e0e',eye:'#ffe04a',fang:1,wp:'fork',wing:'#7a1a1a',wf:9,ws:.8,tail:'spade',bulk:.8,legH:28,hunch:.6,aura:'#ff5a2a'}),
brute:o=>({lg:o.lg,sk:'#b04a2a',dk:'#5a1a10',cl:'#3a2a26',hd:12,horn:'#2a1010',tusk:1,eye:'#ffcc33',wp:'club',wsc:1.6,bulk:1.75,lw:12,belly:1,reach:8,legH:32,hunch:1,aura:'#ff6a2a',fx:(g,t,q)=>{g.strokeStyle='#ff9a2a';g.lineWidth=2.4;g.shadowColor='#ff7a1a';g.shadowBlur=8;for(const p of[[-12,q.SH+8,-2,q.SH+18,-10,q.SH+26],[8,q.SH+6,14,q.SH+16,6,q.SH+24]]){g.beginPath();g.moveTo(p[0],p[1]);g.lineTo(p[2],p[3]);g.lineTo(p[4],p[5]);g.stroke()}g.shadowBlur=0}}),
yeti:o=>({lg:o.lg,sk:'#e6f0f8',dk:'#9ab6cc',hl:'#ffffff',face:'#7fb0d8',fur:'#f4f8fc',hd:13,tusk:1,eye:'#7fe0ff',bulk:1.7,lw:13,reach:12,hunch:1.3,legH:32,belly:1}),
bGob:o=>({lg:o.lg,sk:'#4a9a3a',cl:'#5a3a26',cape:'#8a1a2a',hd:16,hunch:.6,ear:'pt',nose:1,eye:'#ffdd33',tusk:1,wp:'axe',wsc:1.5,bulk:1.5,lw:11,reach:6,legH:34,belly:1,crown:1,pad:'#8a8a9a',padspike:1}),
bLich:o=>({lg:o.lg,bone:1,sk:'#e4dec8',dk:'#8a8470',eye:'#7dff7a',orb:'#7dff7a',wp:'staff',cl:'#2a1a4a',robe:1,cape:'#1a0f30',horn:'#d8d0b8',hornL:1.4,hd:14,bulk:1.15,walk:.3,legH:34,aura:'#7dff7a',crown:0,fx:(g,t)=>{for(let i=0;i<3;i++){const a=t*1.6+i*2.1;const x=Math.cos(a)*44,y=-70+Math.sin(a)*14-i*6;glow(g,x,y,22,'#7dff7a99');ell(g,x,y,5,5,'#c8ffc0')}}}),
bDemon:o=>({lg:o.lg,sk:'#a82a1e',cl:'#2a1a1a',hd:15,hunch:.5,horn:'#2a0a0a',hornL:1.6,ear:'pt',eye:'#ffdd33',tusk:1,wp:'sword',flame:1,gd:'#ffb84a',bl:'#ffb060',wsc:1.5,bulk:1.6,lw:11,reach:6,legH:36,wing:'#5a0a10',ws:1.6,wf:3,tail:'spade',aura:'#ff4a1a',pad:'#3a3a44',padspike:1,belly:1})};
const DR={
gob:(g,t,o)=>hum(g,t,CFG.gob(o)),troll:(g,t,o)=>hum(g,t,CFG.troll(o)),bat:(g,t,o)=>bat(g,t,o,{col:'#5b3a80'}),
skel:(g,t,o)=>hum(g,t,CFG.skel(o)),ghost,zomb:(g,t,o)=>hum(g,t,CFG.zomb(o)),
snake,spid:(g,t,o)=>spid(g,t,o),scor,imp:(g,t,o)=>hum(g,t,CFG.imp(o)),flame,brute:(g,t,o)=>hum(g,t,CFG.brute(o)),
fsk:frostSk,wolf:(g,t,o)=>wolf(g,t,o,{col:'#7a8ca0',hi:'#c4d4e4',eye:'#7fe8ff'}),yeti:(g,t,o)=>hum(g,t,CFG.yeti(o)),
crab,fish,octo,
bGob:(g,t,o)=>hum(g,t,CFG.bGob(o)),bLich:(g,t,o)=>hum(g,t,CFG.bLich(o)),
bQueen:(g,t,o)=>spid(g,t,o,{col:'#3a1a4a',hi:'#8a4aa8',s:1.55,crown:1,eye:'#ff3b5a',aura:'#c86bff'}),
bDemon:(g,t,o)=>hum(g,t,CFG.bDemon(o)),bWyrm:wyrm,bKraken:kraken};
/* h = on-screen height in px, sp = base speed, th = nominal art height (for thumbnails), cx = centre offset */
const MON={
gob:{n:'Goblin',h:138,sp:56,th:96,pj:'arrow'},bat:{n:'Cave Bat',h:104,sp:112,th:68,fly:1},troll:{n:'Moss Troll',h:212,sp:30,th:118},
skel:{n:'Skeleton',h:150,sp:50,th:96,pj:'bone'},ghost:{n:'Wraith',h:156,sp:66,th:110,fly:1},zomb:{n:'Zombie',h:158,sp:32,th:98},
snake:{n:'Cobra',h:138,sp:56,th:90,cx:20,pj:'venom'},spid:{n:'Cave Spider',h:104,sp:108,th:64},scor:{n:'Scorpion',h:110,sp:34,th:92,cx:20},
imp:{n:'Imp',h:130,sp:58,th:92,pj:'fire'},flame:{n:'Ember Spirit',h:138,sp:90,th:108,fly:1},brute:{n:'Magma Brute',h:224,sp:30,th:118},
fsk:{n:'Frost Archer',h:150,sp:52,th:96,pj:'ice'},wolf:{n:'Dire Wolf',h:104,sp:120,th:82,cx:-8},yeti:{n:'Yeti',h:222,sp:30,th:118},
crab:{n:'Reef Crab',h:108,sp:58,th:70,tw:130,cx:-12,pj:'bubble'},fish:{n:'Ghoul Fish',h:104,sp:104,th:78,fly:1},octo:{n:'Abyss Octopus',h:186,sp:30,th:120},
bGob:{n:'Goblin King',h:330,sp:60,th:120,boss:1},bLich:{n:'Crypt Lord',h:340,sp:58,th:130,boss:1},bQueen:{n:'Web Queen',h:300,sp:60,th:100,tw:170,boss:1,cx:0},
bDemon:{n:'Ember Tyrant',h:380,sp:56,th:130,boss:1},bWyrm:{n:'Frost Wyrm',h:390,sp:56,th:150,tw:320,boss:1,cx:30},bKraken:{n:'Tide Ravager',h:400,sp:54,th:190,tw:230,boss:1}};
for(const k in MON)MON[k].d=DR[k];
