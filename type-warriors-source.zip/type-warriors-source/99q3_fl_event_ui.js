/* ===== 10.4 HARVEST FESTIVAL: screens (99q3, prefix fle) =====
   fleHub()     the festival: a harvest-table scene, the Gratitude tasks, tiles to the Calendar, the Market, Harvest Moon Rush
                (flrMenu) and the Harvest Chest (flcOpenUI).
   fleCal()     the Harvest Calendar: an advent board, 6 to 26 November laid out by week, the Thanksgiving feast across Thu to Sun.
   fleMarket()  the Harvest Market stall.
   Home: the events card shows the festival (with a Halloween button while Halloween lasts), falling leaves drift over the home
   screen (not with reduced motion or Performance mode, and switchable in the festival), Choose a mode's Events lists it all. */
const FLU={rev:null,conf:null};
const fleWal=()=>`<span class="flewal" id="flewal" title="Your acorns">${fleIco('acorn',30)}<b id="flewaln">${fleAcorns().toLocaleString()}</b><span>acorns</span></span>`;
function fleTag(){if(flOn())return`HARVEST FESTIVAL &bull; ${esc(flLeft()).toUpperCase()}`;if(!flShopOn())return'THE HARVEST FESTIVAL HAS ENDED';const d=Math.max(0,Math.ceil((FL.end+FL.grace-flNow())/864e5));return`THE HARVEST IS IN &bull; MARKET OPEN ${d} MORE DAY${d===1?'':'S'}`}
const fleTop=(back,lab)=>`<header class="fletop"><button class="fleback" id="fleback">${typeof TV_ICON==='object'?TV_ICON.back:'‹'}<span>${lab||'Back'}</span></button><span class="fleev">${fleIco('leaf',32)}<b>${fleTag()}</b></span><span class="flesp"></span>${flShopOn()?fleWal():''}<button class="fleic" id="flehelp" aria-label="How the Harvest Festival works" title="How it works">${typeof TV_ICON==='object'?TV_ICON.help:'?'}</button></header>`;
function fleLiveCv(id,fn,slow){const c=$(id);if(!c)return;const g=c.getContext('2d');const d=t=>{try{fn(g,c,t)}catch(e){}};d(2.5);if(!fleRM())LIVE.push({cv:c,fn:d,slow:slow||2})}
function fleClosed(){show(`<section class="fle flehub">${fleTop()}<div class="flegone"><h2>The Harvest Festival is over</h2><p>Thank you for celebrating! The festival ran from 6 November to 1 December, and the market stayed open a week for leftover acorns.</p><button class="flebig" id="flegone">Back to the home screen</button></div></section>`,'m');S.back=title;$('fleback').onclick=title;$('flegone').onclick=title;$('flehelp').onclick=fleHow}

/* ---------- the festival hub ---------- */
function fleHub(){if(!P)return;S.mode='title';S.view='menu';if(!flShopOn())return fleClosed();const f=FLP(),e=f.fe;if(!e.seen){e.seen=1;save()}
 const on=flOn(),G=on?fleGT():null,D=fleToday(),note=e.note;if(note){e.note='';save()}
 const task=(k,i)=>{const T=FLE_TK[k],n=T.n,p=G.p[i],dn=p>=n,cl=G.c[i],rw=FLE.gtRw[T.t],col=FLE_TCOL[T.ic]||'#ffd45a';
  return `<div class="flegt${dn?' done':''}${cl?' got':''}" style="--c:${col}"><span class="flegti">${fleTGlyph(T.ic,28)}</span><div class="flegtx"><em>${['Easy','Medium','Hard'][T.t]}</em><b>${esc(T.x)}</b><i class="flebar"><u style="width:${(Math.min(1,p/n)*100).toFixed(1)}%"></u></i><small>${cl?'Thank you!':dn?'Done! Claim your acorns':n>1?`${p.toLocaleString()} / ${n.toLocaleString()}`:'Not yet'}</small></div>${cl?`<span class="flegtok">${typeof TV_ICON==='object'?TV_ICON.check:'✓'}</span>`:dn?`<button class="flecl" data-fle-cl="${i}">${fleIco('acorn',20)}Claim +${rw}</button>`:`<span class="flegtr">${fleIco('acorn',20)}+${rw}</span>`}</div>`};
 const calN=fleCalN(),ready=fleCalReady(),fcr=P[FL.chest.cnt]|0,rush=typeof flrMenu==='function',rushOn=rush&&(typeof flrOn!=='function'||flrOn());
 const panel=on?`<div class="flegth"><h3>Gratitude</h3><small>New tasks in ${fleTaskLeft()}</small></div><div class="flegts">${G.k.map(task).join('')}</div>
   <div class="flegtb${G.b?' got':''}">${fleIco('leaf2',22)}<span>${G.b?'All three done today: bonus paid':`Finish all three today: <b>+${FLE.gtBonus}</b> bonus acorns`}</span></div>
   <div class="flebag" title="Play acorns pay in full up to the daily bag, then a quarter"><span>Today's acorn bag</span><i class="flebar"><u style="width:${(Math.min(1,D.play/FLE.bag)*100).toFixed(1)}%"></u></i><b>${Math.min(D.play,FLE.bag)} / ${FLE.bag}</b></div>`
  :`<div class="flegth"><h3>The harvest is in</h3></div><p class="flegrace">Thank you for celebrating! The festival ended on 1 December. Hazel keeps the market open a few more days so you can spend your leftover acorns.</p>
   <div class="flesum"><span>${fleIco('acorn',26)}<b>${e.tot.toLocaleString()}</b>acorns gathered</span><span>${fleIco('gift',26)}<b>${calN} / 21</b>presents opened</span><span>${fleIco('leaf',26)}<b>${e.gtN}</b>Gratitude tasks</span><span>${fleIco('chest',26)}<b>${Object.values(e.buy).reduce((a,b)=>a+b,0)}</b>market buys</span></div>
   <button class="flebig" id="flegomk">${fleIco('acorn',26)}Spend ${f.ac.toLocaleString()} acorns at the market</button>`;
 show(`<section class="fle flehub">${fleTop()}
 ${note?`<p class="flenote" role="status">${esc(note)}</p>`:''}
 <div class="flemain"><canvas id="flescene" width="1320" height="500" aria-label="A harvest table under a rising orange moon, with lanterns, pumpkins and your hero"></canvas>
  <div class="flehero"><div class="flekick"><span>TYPE WARRIORS</span><em class="flelt">${on?'LIMITED TIME':'THANK YOU'}</em></div><h2>Harvest Festival</h2>
   <p>Gather acorns in every mode, open a present each day until Thanksgiving and spend your harvest at the market.</p>
   <div class="flestats"><span><b>${e.tot.toLocaleString()}</b> acorns gathered</span><span><b>${calN} / 21</b> presents</span><span><b>${e.gtN}</b> tasks done</span>${!fleLite()||e.lv?`<button class="flelv" id="flelv" aria-pressed="${e.lv?'true':'false'}" title="Falling leaves on the home screen">${fleIco('leaf3',18)}Leaves ${e.lv?'on':'off'}</button>`:''}</div></div>
  <aside class="flepanel" aria-label="Gratitude tasks">${panel}</aside></div>
 <div class="flerow">
  <button class="fletile fletcal${ready?' hot':''}" id="flecalb"><canvas width="132" height="100" data-fle-tile="cal" aria-hidden="true"></canvas><div><b>Harvest Calendar</b><small>${!on?'Closed with the festival':ready?"Today's present is ready!":fleCalNow()>26?'Catch up on missed presents':fleCalNow()<6?'Opens on 6 November':`${calN} of 21 presents opened`}</small></div>${ready?'<em>Open</em>':''}</button>
  <button class="fletile flemkt" id="flemktb"><canvas width="132" height="100" data-fle-tile="mkt" aria-hidden="true"></canvas><div><b>Harvest Market</b><small>Chests, companions, the Golden Harvest Egg</small></div></button>
  <button class="fletile flerush" id="flerushb" ${rushOn?'':'disabled'}><canvas width="132" height="100" data-fle-tile="rush" aria-hidden="true"></canvas><div><b>Harvest Moon Rush</b><small>${rushOn?'The festival’s own Endless run':rush?'Closed':'Opens soon'}</small></div></button>
  <button class="fletile flechest" id="flechestb" ${typeof flcOpenUI==='function'?'':'disabled'}><canvas width="132" height="100" data-fle-tile="chest" aria-hidden="true"></canvas><div><b>Harvest Chest</b><small>${fcr?`${fcr} to open`:'Win them in the festival'}</small></div>${fcr?`<em>${fcr}</em>`:''}</button>
 </div></section>`,'m');
 S.back=title;$('fleback').onclick=title;$('flehelp').onclick=fleHow;
 $('flecalb').onclick=()=>{fleSnd('tap');fleCal()};$('flemktb').onclick=()=>{fleSnd('tap');fleMarket()};
 $('flerushb').onclick=()=>{if(typeof flrMenu==='function'){try{ensureAudio()}catch(x){}flrMenu()}};$('flechestb').onclick=()=>{if(typeof flcOpenUI==='function')flcOpenUI()};
 if($('flegomk'))$('flegomk').onclick=()=>fleMarket();
 if($('flelv'))$('flelv').onclick=()=>{e.lv=e.lv?0:1;save();fleSnd('tap');const b=$('flelv');b.setAttribute('aria-pressed',e.lv?'true':'false');b.lastChild.textContent='Leaves '+(e.lv?'on':'off')};
 ov.querySelectorAll('[data-fle-cl]').forEach(b=>b.onclick=()=>{const i=+b.dataset.fleCl,G0=fleGT(),hadB=G0.b,n=fleClaimTask(i);if(n){fleSnd('claim');const row=b.closest('.flegt');fleBurst(b);const bon=!hadB&&fleGT().b;setTimeout(()=>{fleHub();fleWalPop();if(bon)fleToast(FLE.gtBonus,'All three Gratitude tasks')},420);if(row)row.classList.add('pop')}});
 fleLiveCv('flescene',fleHubPaint,2);
 ov.querySelectorAll('canvas[data-fle-tile]').forEach(c=>{const k=c.dataset.fleTile,g=c.getContext('2d');const d=t=>{try{fleTilePaint(g,c,k,t)}catch(x){}};d(2.5);if(!fleRM()&&(k==='cal'||k==='chest'||k==='rush'))LIVE.push({cv:c,fn:d,slow:3})})}

/* ---------- the Harvest Calendar ---------- */
const FLE_WD=['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
const FLE_LOCK='<svg viewBox="0 0 24 24" width="15" height="15" aria-hidden="true"><rect x="5" y="10.5" width="14" height="10" rx="2.5" fill="#3a1a08" stroke="#f4d8a8" stroke-width="1.6"/><path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5" fill="none" stroke="#f4d8a8" stroke-width="1.8"/></svg>';
function fleGiftIco(k,s){return k==='ac'?fleIco('acorn',s):k==='co'?fleIco('coins',s):k==='ch'?fleIco('chest',s):k==='eg'?fleIco('egg',s):k==='gold'?fleIco('gold',s):k==='ti'?fleIco('title',s):fleIco('feast',s)}
function fleGiftTxt(k,v){return k==='ac'?`${v} acorns`:k==='co'?`${v.toLocaleString()} coins`:k==='ch'?`${v} Harvest Chest${v>1?'s':''}`:k==='eg'?'Runeshell egg':k==='gold'?'Golden Harvest Egg':k==='ti'?'Thankful Heart title':''}
function fleCal(){if(!P)return;S.mode='title';S.view='menu';if(!flShopOn())return fleClosed();const now=fleCalNow(),on=flOn(),e=FLP().fe,earlier=FLE_DAYS.filter(d=>d<26),eN=earlier.filter(d=>e.cal[d]).length;
 const cell=d=>{const C=FLE_CAL[d],st=on?fleCalSt(d):e.cal[d]?'got':'lock',wk=fleWknd(d),wd=FLE_WD[(new Date(2026,10,d).getDay()+6)%7],gifts=C.g;
  const inside=`<span class="flecdin">${gifts.map(([k])=>`<i>${fleGiftIco(k,gifts.length>1?40:54)}</i>`).join('')}<small>${esc(C.n)}</small></span>`;
  const lab=`${d} November, ${wd}: ${C.n}. ${st==='got'?'Opened':st==='today'?'Ready to open':st==='miss'?`Missed, catch up for ${FLE.catchUp} acorns`:'Not yet'}`;
  if(C.feast){const egg=fleFeastEarned()||e.feast;return `<button class="flecd flefeast ${st}" data-fle-day="${d}" aria-label="${esc(lab)}" style="grid-column:4 / 8">
   <span class="flecdin flefin">${fleIco('feast',58)}<span><b>The Thanksgiving Feast</b><small>200 acorns · 2 Harvest Chests${egg?' · the Golden Harvest Egg':''}</small></span></span>
   <span class="flecddoor fledbl"><span class="fledl"></span><span class="fledr"></span><span class="fledfx"><span class="fledcorn">${fleIco('feast',46)}</span><span class="fledcorn2">${fleIco('pumpkin',42)}</span><span class="fledpl"><em>THANKSGIVING FEAST</em><b>26</b><small>${egg?`${fleIco('gold',22)} Golden Harvest Egg unlocked`:`${fleIco('gold',22)} ${eN} / 20 earlier presents for the Golden Egg`}</small></span>${st==='miss'?`<i class="flecu">${fleIco('acorn',16)} Catch up · ${FLE.catchUp}</i>`:st==='today'?'<i class="flego">Open the feast!</i>':''}</span></span></button>`}
  return `<button class="flecd ${st}${wk?' wk':''}" data-fle-day="${d}" aria-label="${esc(lab)}" ${st==='lock'?'aria-disabled="true"':''}>${inside}<span class="flecddoor">${wk?'':`<span class="flemb2">${fleIco(['leaf','acorn','pumpkin','apple','leaf2','oak','leaf3'][d%7],26)}</span>`}<em>${wd.toUpperCase()}</em><b>${d}</b>${wk?'<i class="flerib" aria-hidden="true"></i>':''}${st==='miss'?`<i class="flecu">${fleIco('acorn',14)} ${FLE.catchUp}</i>`:st==='today'?'<i class="flego">Open!</i>':st==='lock'?`<i class="flelk">${FLE_LOCK}</i>`:''}</span>${st==='got'?`<i class="flechk">${typeof TV_ICON==='object'?TV_ICON.check:'✓'}</i>`:''}</button>`};
 const blank=n=>`<div class="flecalt" style="grid-column:1 / ${n+1}"><span>${fleIco('leaf',30)}${fleIco('acorn',30)}${fleIco('leaf2',30)}</span><h2>Harvest Calendar</h2><p>One present a day until Thanksgiving. Weekends are bigger; the feast is the biggest of all.</p></div>`;
 const rows=[blank(4),...[6,7,8].map(cell),...[9,10,11,12,13,14,15,16,17,18,19,20,21,22].map(cell),...[23,24,25,26].map(cell)].join('');
 const miss=on?FLE_DAYS.filter(d=>fleCalSt(d)==='miss').length:0;
 show(`<section class="fle flecalp">${fleTop(0,'Festival')}
  <div class="flecalw"><canvas id="flecalbg" width="1300" height="640" aria-hidden="true"></canvas>
   <div class="flecalg" role="grid" aria-label="Harvest Calendar">${FLE_WD.map(w=>`<span class="flewd">${w}</span>`).join('')}${rows}</div></div>
  <footer class="flecalf"><span>${fleIco('gift',24).replace('fleico','fleico')}${calNTxt()}</span>${miss?`<span>${fleIco('acorn',22)}Missed a day? Catch it up for <b>${FLE.catchUp}</b> acorns.</span>`:''}<span>${fleIco('gold',22)}Open every present before the feast to win the <b>Golden Harvest Egg</b> and the title Thankful Heart.</span></footer></section>`,'m');
 function calNTxt(){return `<b>${fleCalN()} / 21</b> presents opened${!on?' · the calendar closed with the festival':now<6?' · opens on 6 November':''}`}
 S.back=fleHub;$('fleback').onclick=fleHub;$('flehelp').onclick=fleHow;
 const bg=$('flecalbg');if(bg){const g=bg.getContext('2d');g.drawImage(fleBoardBake(bg.width,bg.height),0,0)}
 ov.querySelectorAll('[data-fle-day]').forEach(b=>b.onclick=()=>fleCalTap(+b.dataset.fleDay,b))}
function fleCalTap(d,b){const st=fleCalSt(d);if(!flOn())return;if(st==='lock'||st==='got'){b.classList.remove('nope');void b.offsetWidth;b.classList.add('nope');fleSnd('no');return}
 if(st==='miss'&&!b.classList.contains('confirm')){if(fleAcorns()<FLE.catchUp){fleSnd('no');fleMsg(`Catching up a missed present costs ${FLE.catchUp} acorns. You have ${fleAcorns()}.`);return}
  b.classList.add('confirm');const cu=b.querySelector('.flecu');if(cu)cu.innerHTML=`${fleIco('acorn',14)} Pay ${FLE.catchUp}?`;fleSnd('tap');setTimeout(()=>{if(b.isConnected){b.classList.remove('confirm');if(cu)cu.innerHTML=`${fleIco('acorn',14)} ${FLE_CAL[d].feast?'Catch up · ':''}${FLE.catchUp}`}},3500);return}
 if(FLE_CAL[d].feast&&!fleFeastEarned()&&!b.classList.contains('sure')&&FLE_DAYS.some(x=>x<26&&fleCalSt(x)==='miss')){b.classList.add('sure');fleMsg('Open the missed presents first (catch them up) to win the Golden Harvest Egg at the feast. Tap the feast again to open it anyway.');setTimeout(()=>b.classList.remove('sure'),5000);return}
 const r=fleCalClaim(d);if(!r){fleSnd('no');return}
 b.classList.add('opening');fleSnd('door');setTimeout(()=>fleReveal(r),fleRM()?0:620)}
/* the reveal: the present pops out of the door; the rewards are already in the save */
function fleReveal(r){const C=FLE_CAL[r.day],m=document.createElement('div');m.id='flerev';m.setAttribute('role','dialog');m.setAttribute('aria-modal','true');m.setAttribute('aria-label',C.n);
 const hasCh=r.gifts.some(g=>g.k==='ch')&&typeof flcOpenUI==='function',hasGold=r.gifts.some(g=>g.k==='gold')&&typeof flpEgg==='function',hasEg=r.gifts.some(g=>g.k==='eg');
 m.innerHTML=`<div class="flerb${C.feast?' feast':''}"><i class="flerays" aria-hidden="true"></i><em>${r.st==='miss'?'Caught up · ':''}${r.day} November</em><h3>${esc(C.n)}</h3>
  <div class="flergs">${r.gifts.map((g,i)=>`<div class="flerg" style="--d:${(i*.12+.15).toFixed(2)}s"><span class="flergi">${fleGiftIco(g.k,g.k==='gold'?130:104)}</span><b>${esc(g.txt||fleGiftTxt(g.k,g.v))}</b></div>`).join('')}</div>
  ${C.feast&&!r.gifts.some(g=>g.k==='gold')?'<p>The Golden Harvest Egg needed every earlier present. You still have the feast!</p>':''}
  <div class="flerbt">${hasGold?'<button class="flebig" id="flerhatch">Hatch the egg</button>':''}${hasCh?'<button class="flebig'+(hasGold?' sec':'')+'" id="flerchest">Open the chest</button>':''}${hasEg?'<button class="flebig sec" id="flereg">Go to the eggs</button>':''}<button class="flebig${hasCh||hasGold||hasEg?' sec':''}" id="flerok">Collect</button></div></div>`;
 (document.getElementById('wrap')||document.body).appendChild(m);fleSnd(C.feast?'feast':'gift');setTimeout(()=>{const gi=m.querySelector('.flergi');if(gi)fleBurst(gi)},260);
 const close=()=>{document.removeEventListener('keydown',key,true);m.classList.add('out');setTimeout(()=>m.remove(),200)};const key=ev=>{if(ev.key==='Escape'||ev.key==='Enter'){ev.preventDefault();ev.stopPropagation();close();fleCal()}};document.addEventListener('keydown',key,true);
 m.querySelector('#flerok').onclick=()=>{close();fleCal();fleWalPop()};
 const hc=m.querySelector('#flerchest');if(hc)hc.onclick=()=>{close();flcOpenUI()};const hg=m.querySelector('#flerhatch');if(hg)hg.onclick=()=>{close();try{flpEgg()}catch(x){console.error(x);fleCal()}};
 const he=m.querySelector('#flereg');if(he)he.onclick=()=>{close();try{PTX.back=fleCal;petHall('Eggs')}catch(x){fleCal()}};
 setTimeout(()=>{try{m.querySelector('#flerok').focus({preventScroll:true})}catch(x){}},60)}

/* ---------- the Harvest Market ---------- */
const FLE_MKV=[['egg'],['chest','chest5'],['squir'],['fox'],['trail'],['title'],['keep']];
function fleMarket(note){if(!P)return;S.mode='title';S.view='menu';if(!flShopOn())return fleClosed();
 const card=ks=>{const it=fleItem(ks[0]),k=it.k,big=k==='egg';return `<article class="flemi${big?' feat':''}" data-fle-k="${k}" style="--c:${it.c}">${big?'<span class="flefx">THE FESTIVAL’S MYTHIC</span>':''}<span class="flemr">${esc(it.r)}</span><canvas width="${big?360:300}" height="${big?300:130}" data-fle-it="${ks.length>1?'chest5':k}" aria-hidden="true"></canvas>
  <div class="flemt"><b>${esc(it.n)}</b><small>${esc(ks.length>1?'One harvest relic, coins or acorns, and a small chance of a companion. Five cost less.':it.d)}</small></div>
  <div class="flemp">${ks.length>1?ks.map(q=>`<button class="flebuy flebq" data-fle-buy="${q}" aria-label="Buy ${q==='chest5'?'five Harvest Chests':'a Harvest Chest'} for ${FLE.price[q]} acorns"></button>`).join(''):`<span class="flepr">${fleIco('acorn',24)}<b>${FLE.price[k].toLocaleString()}</b></span><button class="flebuy" data-fle-buy="${k}"></button>`}</div><i class="flebar flemb" aria-hidden="true"><u></u></i></article>`};
 show(`<section class="fle flemk">${fleTop(0,'Festival')}
  <div class="flestallh"><canvas id="flestall" width="1320" height="190" aria-label="A wooden market stall under a striped awning, kept by a squirrel in an acorn-cap hat"></canvas>
   <div class="flestt"><em class="flelt">${flOn()?'LIMITED TIME':'LAST DAYS'}</em><h2>The Harvest Market</h2><p>Hazel trades for acorns only. Gather them in every mode.</p></div><p class="flenote" id="flemknote" role="status" ${note?'':'hidden'}>${esc(note||'')}</p></div>
  <div class="flemkg">${FLE_MKV.map(card).join('')}</div></section>`,'m');
 S.back=fleHub;$('fleback').onclick=fleHub;$('flehelp').onclick=fleHow;
 fleLiveCv('flestall',fleStallPaint,2);
 ov.querySelectorAll('canvas[data-fle-it]').forEach(c=>{const k=c.dataset.fleIt,g=c.getContext('2d');const d=t=>{try{fleItemPaint(g,c,k,t)}catch(x){}};d(2.5);if(!fleRM()&&k!=='title')LIVE.push({cv:c,fn:d,slow:k==='egg'?2:3})});
 ov.querySelectorAll('[data-fle-buy]').forEach(b=>b.onclick=()=>fleBuyTap(b.dataset.fleBuy,b));fleMkRefresh()}
/* bring every card up to date in place (a companion's reveal may be on screen, so the page is not rebuilt after a purchase) */
function fleMkRefresh(){const a=fleAcorns(),n=$('flewaln');if(n)n.textContent=a.toLocaleString();const B=fleBty(),ck=typeof TV_ICON==='object'?TV_ICON.check:'✓';
 ov.querySelectorAll('.flemi[data-fle-k]').forEach(c=>{const k=c.dataset.fleK,st=fleMkSt(k),pr=FLE.price[k];
  c.classList.toggle('own',st==='own');c.classList.toggle('can',st==='ok'||(k==='chest'&&fleMkSt('chest5')==='ok'));c.classList.toggle('poor',st==='poor');
  const bar=c.querySelector('.flemb');if(bar){bar.hidden=st!=='poor';bar.firstChild.style.width=(st==='poor'?Math.min(100,a/pr*100):0).toFixed(1)+'%'}
  c.querySelectorAll('[data-fle-buy]').forEach(b=>{const q=b.dataset.fleBuy,s2=fleMkSt(q),p2=FLE.price[q],eqT=q==='title'&&B.title==='harvesthero',eqR=q==='trail'&&B.trail==='flleaf',multi=b.classList.contains('flebq');
   b.disabled=!(s2==='ok'||(s2==='own'&&(q==='title'||q==='trail'||q==='keep')));b.classList.remove('confirm');b.classList.toggle('eq',eqT||eqR||(q==='keep'&&s2==='own'&&!!FLP().fe.lv));
   b.innerHTML=multi?`<span>${q==='chest5'?'×5':'×1'}</span>${fleIco('acorn',18)}<b>${p2.toLocaleString()}</b>`
    :s2==='ok'?'Buy':s2==='own'?(q==='title'?(eqT?'Equipped':'Equip'):q==='trail'?(eqR?'Equipped':'Equip'):q==='keep'?(FLP().fe.lv?'Leaves on':'Leaves off'):`${ck} Owned`)
    :s2==='poor'?`${(p2-a).toLocaleString()} more`:s2==='closed'?'Closed':'Coming soon';
   if(multi)b.title=s2==='ok'?'':s2==='poor'?`${(p2-a).toLocaleString()} more acorns`:s2==='closed'?'Market closed':'Coming soon'})})}
function fleBuyTap(k,b){const st=fleMkSt(k),B=fleBty();
 if(st==='own'){if(k==='title'){B.title=B.title==='harvesthero'?'':'harvesthero';if(B.title)P.ttl=''}else if(k==='trail')B.trail=B.trail==='flleaf'?'':'flleaf';else if(k==='keep'){const e=FLP().fe;e.lv=e.lv?0:1}save();fleSnd('tap');return fleMkRefresh()}
 if(st!=='ok'){fleSnd('no');return}const pr=FLE.price[k];
 if(pr>=1000&&!b.classList.contains('confirm')){b.classList.add('confirm');b.innerHTML=`Confirm ${fleIco('acorn',18)}${pr.toLocaleString()}`;fleSnd('tap');clearTimeout(FLU.conf);FLU.conf=setTimeout(()=>{if(b.isConnected)fleMkRefresh()},4000);return}
 clearTimeout(FLU.conf);if(!fleBuy(k)){fleSnd('no');return fleMkRefresh()}
 const it=fleItem(k),card=b.closest('.flemi');fleSnd('buy');fleBurst(card);if(card){card.classList.remove('bought');void card.offsetWidth;card.classList.add('bought')}fleWalPop();
 const msg=k==='egg'?'The Golden Harvest Egg is yours!':k==='chest'?'A Harvest Chest was added.':k==='chest5'?'Five Harvest Chests were added.':k==='squir'?'Acorn Scamp joins your companions!':k==='fox'?'Emberleaf joins your companions!':k==='trail'?'Falling Leaves is your letter trail now.':k==='title'?'You are now the Harvest Hero.':'The Autumn Keepsake is yours: leaves will keep falling on your home screen.';
 const nt=$('flemknote');if(nt){nt.hidden=false;nt.textContent=msg}fleMkRefresh();
 if(k==='egg'&&typeof flpEgg==='function')fleAsk(msg,'Hatch it now',()=>{try{flpEgg()}catch(x){console.error(x)}});
 else if((k==='chest'||k==='chest5')&&typeof flcOpenUI==='function')fleAsk(msg,'Open it now',()=>flcOpenUI())}
/* a small "now or later" card over the market */
function fleAsk(msg,yes,fn){const o=$('fleask');if(o)o.remove();const d=document.createElement('div');d.id='fleask';d.setAttribute('role','dialog');d.setAttribute('aria-label',msg);
 d.innerHTML=`<b>${esc(msg)}</b><div><button class="flebig" id="fleasky">${esc(yes)}</button><button class="flebig sec" id="fleaskn">Later</button></div>`;(document.getElementById('wrap')||document.body).appendChild(d);
 const close=()=>{d.classList.add('out');setTimeout(()=>d.remove(),180)};d.querySelector('#fleasky').onclick=()=>{close();fn()};d.querySelector('#fleaskn').onclick=close;setTimeout(()=>{try{d.querySelector('#fleasky').focus({preventScroll:true})}catch(x){}},40)}
function fleMsg(t){const o=$('flemsg');if(o)o.remove();const d=document.createElement('div');d.id='flemsg';d.setAttribute('role','status');d.textContent=t;(document.getElementById('wrap')||document.body).appendChild(d);setTimeout(()=>{d.classList.add('out');setTimeout(()=>d.remove(),220)},3400)}
function fleWalPop(){const w=$('flewal');if(!w)return;const n=$('flewaln');if(n)n.textContent=fleAcorns().toLocaleString();w.classList.remove('pop');void w.offsetWidth;w.classList.add('pop')}
/* a burst of leaves and acorns from an element (one-shot, transform and opacity only) */
function fleBurst(el){if(!el||fleRM())return;const r=el.getBoundingClientRect(),W0=document.getElementById('wrap'),wr=W0.getBoundingClientRect(),k=wr.width/1600||1;const x=(r.left+r.width/2-wr.left)/k,y=(r.top+r.height/2-wr.top)/k;
 const b=document.createElement('div');b.className='fleburst';b.style.left=x+'px';b.style.top=y+'px';let h='';for(let i=0;i<12;i++){const a=i/12*TAU+Math.random()*.4,d=60+Math.random()*60;h+=`<i style="--x:${(Math.cos(a)*d).toFixed(0)}px;--y:${(Math.sin(a)*d-30).toFixed(0)}px;--r:${(Math.random()*540-270).toFixed(0)}deg;--dl:${(Math.random()*.08).toFixed(2)}s">${fleIco(i%3?['leaf','leaf2','leaf3'][i%3]:'acorn',i%3?20:22)}</i>`}b.innerHTML=h;W0.appendChild(b);setTimeout(()=>b.remove(),1000)}
/* little sounds, synthesized with the game's beep */
function fleSnd(k){try{ensureAudio()}catch(e){}try{const B=(f,d,ty,v,at)=>setTimeout(()=>beep(f,d,ty,v),at||0);
 if(k==='tap')B(620,.04,'triangle',.25);else if(k==='no'){B(180,.09,'sawtooth',.25);B(140,.12,'sawtooth',.2,70)}
 else if(k==='claim'){B(660,.08,'triangle',.4);B(880,.08,'triangle',.4,70);B(1320,.14,'triangle',.35,150)}
 else if(k==='buy'){[523,659,784,1047].forEach((f,i)=>B(f,.12,'triangle',.45,i*80));B(196,.2,'sine',.4)}
 else if(k==='door'){B(150,.06,'square',.25);B(110,.08,'square',.2,50);B(330,.16,'sine',.3,140)}
 else if(k==='gift'){[784,988,1175,1568].forEach((f,i)=>B(f,.14,'triangle',.4,i*90));B(392,.3,'sine',.3)}
 else if(k==='feast'){[392,523,659,784,1047,1319].forEach((f,i)=>B(f,.2,'triangle',.45,i*110));[196,262].forEach((f,i)=>B(f,.5,'sine',.35,i*220))}}catch(e){}}

/* ---------- how it works ---------- */
function fleHow(){if($('flehow'))return;const m=document.createElement('div');m.id='flehow';m.setAttribute('role','dialog');m.setAttribute('aria-modal','true');m.setAttribute('aria-label','How the Harvest Festival works');const P5=FLE.pay;
 m.innerHTML=`<div class="flehb"><h3>The Harvest Festival</h3><p class="flehl">6 November to 1 December. Thanksgiving is 26 November.</p><ol>
 <li>${fleIco('acorn',36)}<div><b>Gather acorns by playing</b><small>Campaign level ${P5.camp[0]}–${P5.camp[2]} (by stars) · Tower Defense win ${P5.td}–${P5.td+P5.td3} · Daily Challenge ${P5.dc} · Runestone Riddle ${P5.rr} · Lantern Caravan ${P5.wr} · Warden's Arena ${P5.arena} · Crooked Cue win ${P5.pool} · Wildcard win ${P5.wc} · ${P5.endless5} every 5 Endless rounds · ${P5.fish} a fish. Up to ${FLE.bag} a day pay in full, then a quarter.</small></div></li>
 <li>${fleIco('leaf',36)}<div><b>Gratitude tasks</b><small>Three a day: +${FLE.gtRw[0]}, +${FLE.gtRw[1]} and +${FLE.gtRw[2]} acorns, and +${FLE.gtBonus} for all three. Finished tasks you forget to claim are paid the next day.</small></div></li>
 <li>${fleIco('gift',36)}<div><b>The Harvest Calendar</b><small>One present a day from 6 to 26 November, bigger at weekends. Missed one? Catch it up for ${FLE.catchUp} acorns. Open all twenty before Thanksgiving and the feast brings the Golden Harvest Egg.</small></div></li>
 <li>${fleIco('chest',36)}<div><b>The Harvest Market</b><small>Harvest Chests, the Acorn Scamp and Emberleaf, the Golden Harvest Egg, a letter trail, a title and a keepsake. It stays open seven days after the festival for leftover acorns.</small></div></li>
 <li>${fleIco('moon',36)}<div><b>Harvest Moon Rush</b><small>The festival's own Endless run pays acorns and Harvest Chests.</small></div></li></ol>
 <button class="flebig" id="flehx">Got it</button></div>`;
 (document.getElementById('wrap')||document.body).appendChild(m);const close=()=>{document.removeEventListener('keydown',key,true);m.remove()};const key=e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();close()}};document.addEventListener('keydown',key,true);
 m.querySelector('#flehx').onclick=close;m.onclick=e=>{if(e.target===m)close()};setTimeout(()=>{try{m.querySelector('#flehx').focus({preventScroll:true})}catch(x){}},40)}

/* ---------- home: the events card and the falling leaves ---------- */
function fleHomeCard(){const sc=ov.querySelector('.dksc');if(!sc||sc.querySelector('#dkflc'))return;if(!flShopOn())return;const on=flOn();if(!on&&!(fleAcorns()>0))return;
 const hw=typeof hwOn==='function'&&hwOn()&&sc.querySelector('#dkev'),ready=on&&fleCalReady(),tk=on?fleTaskReady():0;
 const line2=!on?`${fleIco('acorn',16)}Spend your leftover acorns`:ready?`${fleIco('gift',16)}Today's present is ready`:tk?`${fleIco('leaf',16)}${tk} Gratitude task${tk>1?'s':''} to claim`:(()=>{const n=3-fleGT().c.filter(x=>x).length;return n?`${fleIco('leaf',16)}${n} Gratitude task${n>1?'s':''} today`:`${fleIco('leaf',16)}All Gratitude tasks done`})();
 const d=document.createElement('div');
 d.innerHTML=`<div class="dkcard dkev dkfl dklive dkg dktilt" id="dkflc" role="group" aria-label="Harvest Festival"><canvas class="dkcv" width="560" height="320" aria-hidden="true"></canvas><i class="dkgl"></i>
  <span class="dkcl"><b>Harvest Festival</b><span class="dkevl"><span>${fleIco('acorn',16)}${fleAcorns().toLocaleString()} acorns <u>·</u> ${on?esc(flLeft()):'market open'}</span><span>${line2}</span></span>
  <span class="flecrow"><button class="flecm" id="dkfl" aria-label="Enter the Harvest Festival, ${esc(flLeft())}. ${fleAcorns()} acorns.${ready?' Today\'s present is ready.':''}${tk?` ${tk} Gratitude tasks to claim.`:''}">Enter the festival <i>›</i></button>${hw?`<button class="flehw" id="dkev" aria-haspopup="dialog" title="Trick-or-Treat and Monster Mash · ${esc(hwLeft())}" aria-label="Halloween events: Trick-or-Treat and Monster Mash, ${esc(hwLeft())}">${typeof DKPUMP==='string'?DKPUMP:''}<span>Halloween</span><i>›</i></button>`:''}</span></span>
  ${ready||tk?`<i class="bdg fledot" aria-hidden="true">${ready&&tk?tk+1:tk||'!'}</i>`:''}</div>`;
 const card=d.firstElementChild;if(hw)hw.replaceWith(card);else{const wg=sc.querySelector('#dkwagon');if(wg)sc.insertBefore(card,wg);else sc.appendChild(card);sc.classList.remove('dks3');sc.classList.add('dks4');try{dkFit()}catch(e){}}
 const go=()=>{try{ensureAudio()}catch(e){}fleHub()};card.querySelector('#dkfl').onclick=e=>{e.stopPropagation();go()};card.onclick=e=>{if(e.target.closest&&e.target.closest('#dkev'))return;go()};
 const hb=card.querySelector('#dkev');if(hb)hb.onclick=e=>{e.stopPropagation();modeSheet('ev')};
 const cv=card.querySelector('canvas'),g=cv.getContext('2d');const draw=t=>{try{fleCardPaint(g,560,320,t)}catch(e){}};draw(2);if(!(typeof dkRM==='function'&&dkRM()))LIVE.push({cv,fn:draw,slow:2,ph:3})}
const fleLeavesOn=()=>{try{if(!P||fleLite())return false;const e=FLP().fe;if(!e.lv)return false;return flOn()||!!e.buy.keep}catch(x){return false}};
function fleLeaves(){const h=ov.querySelector('.dkh');if(!h||h.querySelector('.flleaves')||!fleLeavesOn())return;const L=document.createElement('div');L.className='flleaves';L.setAttribute('aria-hidden','true');
 const ks=['leaf','leaf2','leaf3','oak','leaf','leaf3','leaf2','leaf','oak','leaf2','leaf3','leaf','leaf2','oak'];let s='';
 ks.forEach((k,i)=>{const x=i<3?120+i*260:800+((i-3)*71)%780,dur=12+(i*37%9),dl=-(i*3.7%dur),sz=34+(i*7%20),dx=(i%2?1:-1)*(70+(i*29%110));
  s+=`<i class="fllf" style="--x:${x}px;--dx:${dx}px;--d:${dur}s;--dl:${dl.toFixed(1)}s;--sw:${(2.4+(i%4)*.6).toFixed(1)}s"><i>${fleIco(k,sz)}</i></i>`});L.innerHTML=s;h.appendChild(L)}
{const t0=title;title=function(){const r=t0.apply(this,arguments);try{fleHomeCard()}catch(e){console.error(e)}try{fleLeaves()}catch(e){}return r}}
/* the H key family is full; V opens the festival from the home screen */
{const hk0=homeKey;homeKey=function(e){if(HOME&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&(e.key==='v'||e.key==='V')&&!document.querySelector('.dks.on')&&flShopOn()){const ae=document.activeElement;if(!(ae&&ae!==inp&&/INPUT|TEXTAREA|SELECT/.test(ae.tagName))){e.preventDefault();fleHub();return true}}return hk0.apply(this,arguments)}}
{const d0=dkDetect;dkDetect=function(html){if(typeof html==='string'&&/class="fle /.test(html))return'pl';return d0.apply(this,arguments)}}
/* Choose a mode › Events: the festival first, Halloween while it lasts */
{const m0=modeSheet;modeSheet=function(view){const r=m0.apply(this,arguments);try{fleModeSheet()}catch(e){console.error(e)}return r}}
/* the Events tile's picture: encoded off the main thread (toBlob) the first time Choose a mode opens, then reused */
let FLE_SHOT='',FLE_SHOTP=0;
function fleCardShot(){if(FLE_SHOT||FLE_SHOTP)return FLE_SHOT;FLE_SHOTP=1;try{const c=fleCv(480,360),g=c.getContext('2d');g.fillStyle='#120a30';g.fillRect(0,0,480,360);g.drawImage(fleCardBake(560,320),0,0,560,320,0,43,480,274);g.fillStyle='rgba(12,8,34,.3)';g.fillRect(0,0,480,360);
 c.toBlob(b=>{if(!b)return;FLE_SHOT=URL.createObjectURL(b);const v=document.querySelector('#dmv[data-fle]');if(v)v.style.setProperty('--img',`url(${FLE_SHOT})`)},'image/webp',.72)}catch(e){}return FLE_SHOT}
function fleModeSheet(){if(!flShopOn())return;const all=document.querySelectorAll('.dks'),sh=all[all.length-1];if(!sh)return;const on=flOn(),hw=typeof hwOn==='function'&&hwOn();
 const v=sh.querySelector('#dmv');if(v&&!v.dataset.fle){v.dataset.fle=1;v.style.setProperty('--c','#ff9a3a');const im=fleCardShot();if(im)v.style.setProperty('--img',`url(${im})`);const ic=v.querySelector('.dkmi');if(ic)ic.innerHTML=fleIco('leaf',54);
  const tt=v.querySelector('.dkmt small');if(tt)tt.textContent=on?(typeof flrMenu==='function'?'Harvest Festival · Harvest Moon Rush':'Harvest Festival')+(hw?' · Halloween':''):'The harvest is in · the market is open'}
 const ev=sh.querySelector('.dkpv[data-v="e"]');if(!ev||ev.dataset.fle)return;ev.dataset.fle=1;const h=ev.querySelector('#dkmsh');if(h)h.textContent='Events';const p=ev.querySelector('.dkpn');
 if(p)p.textContent=on?`The Harvest Festival · ${flLeft()}.${hw?` Halloween is still on: ${hwLeft()}.`:''}`:'The Harvest Festival is over; the market stays open for leftover acorns.';
 const g=ev.querySelector('.dkmg');if(!g)return;const mk=(id,t,d,ic,c,first)=>{const b=document.createElement('button');b.className='dkm';b.id=id;b.style.setProperty('--c',c);b.innerHTML=`<span class="dkmi">${ic}</span><span class="dkmt"><b>${t}</b><small>${d}</small></span><i class="dkchv">›</i>`;if(first)b.setAttribute('data-first','');return b};
 const old=g.querySelector('[data-first]');if(old)old.removeAttribute('data-first');
 const a=mk('dmfl','Harvest Festival',on?'Acorns, Gratitude tasks, the Calendar and the Harvest Market.':'Spend your leftover acorns at the Harvest Market.',fleIco('acorn',54),'#ffb04a',1);a.onclick=()=>{dkClose(true);setTimeout(fleHub,0)};g.insertBefore(a,g.firstChild);
 if(on&&typeof flrMenu==='function'&&!g.querySelector('#dmflr')){const b=mk('dmflr','Harvest Moon Rush','The festival’s own Endless run under the harvest moon.',fleIco('moon',54),'#ff8a3a');b.onclick=()=>{dkClose(true);setTimeout(()=>flrMenu(),0)};a.after(b)}
 g.classList.add('flemg');if(hw){const s=document.createElement('p');s.className='dkpn flehwl';s.textContent=`Halloween · ${hwLeft()}`;const tt=g.querySelector('#dmt');if(tt)g.insertBefore(s,tt)}
 const cur=sh.querySelector('.dkpv[data-v="e"]:not([hidden]) [data-first]');if(cur)try{cur.focus({preventScroll:true})}catch(e){}}
try{const sc=HELP.Shortcuts&&HELP.Shortcuts.find(x=>/^F W G/.test(x[0]));if(sc&&!/V/.test(sc[0])){sc[0]+=' V';sc[1]=sc[1].replace(/\.$/,'')+', the Harvest Festival (while it runs).'}}catch(e){}
try{HELP.Modes.unshift(['Harvest Festival','A limited event from 6 November to 1 December (Thanksgiving is 26 November). Every main mode pays acorns: campaign levels, Endless rounds, Tower Defense, the Daily Challenge, the Runestone Riddle, the Lantern Caravan, Warden\'s Arena, Moonlit Fishing, Wildcard and The Crooked Cue, up to a daily bag of 150 at full rate. Three Gratitude tasks a day pay more, and the Harvest Calendar has a present every day until Thanksgiving (bigger at weekends; a missed day can be caught up for 40 acorns). Spend acorns at the Harvest Market on Harvest Chests, the Acorn Scamp and Emberleaf companions, the Golden Harvest Egg, a letter trail, a title and the Autumn Keepsake. V opens the festival from the home screen.'])}catch(e){}

/* ---------- styles ---------- */
{const st=document.createElement('style');st.textContent=`
.fle{max-width:1320px;width:100%;margin:0 auto;display:flex;flex-direction:column;gap:12px;text-align:left;font-family:var(--ui,'Poppins',sans-serif);color:#fff8e8;padding:2px 0 16px;box-sizing:border-box}
.fleico{display:inline-block;vertical-align:middle;flex-shrink:0}
.fletop{display:flex;align-items:center;gap:12px;min-height:54px}.flesp{flex:1}
.fleback,.fleic{all:unset;box-sizing:border-box;cursor:pointer;display:flex;align-items:center;gap:8px;height:48px;padding:0 20px 0 16px;border-radius:14px;background:#181240;border:1.5px solid #4c3f8e;color:#f1ecff;font:600 17px var(--ui,Poppins,sans-serif);transition:transform .16s cubic-bezier(.3,1.5,.5,1),background .15s,border-color .15s}
.fleic{width:48px;padding:0;justify-content:center}.fleback:hover,.fleic:hover{background:#241a5c;border-color:#7a6ad0;transform:translateY(-2px)}.fleback:active,.fleic:active{transform:scale(.94)}
.fleev{display:flex;align-items:center;gap:10px;color:#ffc65a}.fleev b{font:700 15px var(--ui,Poppins,sans-serif);letter-spacing:.14em}
.flewal{display:flex;align-items:center;gap:10px;height:52px;padding:0 24px 0 14px;border-radius:99px;background:linear-gradient(180deg,#2a1a30,#170f2c);border:2px solid #c8862c;color:#f4e2c0;font:500 17px var(--ui,Poppins,sans-serif);box-shadow:0 0 18px #ff9a3a26}.flewal b{font:800 27px var(--ui,Poppins,sans-serif);color:#fff}
.flewal.pop{animation:flepop .5s cubic-bezier(.3,1.6,.5,1)}@keyframes flepop{40%{transform:scale(1.12)}}
.flelt{display:inline-block;padding:3px 10px;border-radius:99px;background:linear-gradient(90deg,#e8562a,#ff9a3a);color:#fff;font:800 11px var(--ui,Poppins,sans-serif);font-style:normal;letter-spacing:.12em}
.flenote{margin:0;padding:10px 16px;border-radius:14px;background:#2a1a10;border:1.5px solid #c8862c;color:#ffe0a8;font:600 15px var(--ui,Poppins,sans-serif)}
.flebig{all:unset;box-sizing:border-box;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;gap:10px;height:52px;padding:0 26px;border-radius:15px;background:linear-gradient(180deg,#ffe07a,#f7b21f 55%,#eb9810);color:#2a1700;font:800 17px var(--ui,Poppins,sans-serif);box-shadow:0 5px 0 #8a5a08;transition:transform .16s cubic-bezier(.3,1.5,.5,1)}
.flebig:hover{transform:translateY(-2px)}.flebig:active{transform:translateY(3px)}.flebig.sec{background:linear-gradient(180deg,#2c2470,#1a1450);color:#fff8e8;border:1.5px solid #5a4ca0;box-shadow:0 5px 0 #0c0828}
.fle button:focus-visible,#flerev button:focus-visible,#flehow button:focus-visible,#fleask button:focus-visible,.flecm:focus-visible,.flehw:focus-visible{outline:3px solid #ffd45a;outline-offset:2px}
.flebar{display:block;height:7px;border-radius:9px;background:#ffffff1a;overflow:hidden}.flebar u{display:block;height:100%;border-radius:9px;background:linear-gradient(90deg,#e8562a,#ffc23a)}
/* hub */
.flemain{position:relative;display:grid;grid-template-columns:1fr 452px;min-height:476px;border-radius:24px;overflow:hidden;border:1.5px solid #5a3a48;box-shadow:0 18px 50px #000a;background:#0c0620}
.flemain>canvas{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
.flehero{position:relative;z-index:1;padding:28px 0 20px 38px;display:flex;flex-direction:column;pointer-events:none}.flehero>*{pointer-events:auto}
.flekick{display:flex;align-items:center;gap:12px}.flekick span{font:700 19px var(--ui,Poppins,sans-serif);letter-spacing:.32em;color:#ffcf9a}
.flehero h2{margin:14px 0 0;font:400 92px/.95 'Pirata One',Georgia,serif;color:#ffc23a;text-shadow:0 4px 0 #8a3a06,0 6px 0 #4a1a03,0 0 26px #ff8a3c66}
.flehero p{margin:8px 0 0;max-width:600px;font:500 18px/1.4 var(--ui,Poppins,sans-serif);color:#fff2dc;text-shadow:0 2px 8px #000}
.flestats{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-top:12px;max-width:620px}.flestats span{padding:6px 13px;border-radius:99px;background:#0c0716cc;border:1px solid #6a4a48;color:#f0dcc8;font:500 13.5px var(--ui,Poppins,sans-serif)}.flestats b{color:#ffd76a}
.flelv{all:unset;cursor:pointer;display:flex;align-items:center;gap:6px;padding:5px 12px;border-radius:99px;background:#2a1a10cc;border:1px solid #c8862c;color:#ffe0a8;font:600 13px var(--ui,Poppins,sans-serif)}.flelv[aria-pressed="false"]{opacity:.7;filter:grayscale(.6)}
.flepanel{position:relative;z-index:1;margin:14px 14px 14px 0;padding:16px 18px 14px;border-radius:20px;background:linear-gradient(180deg,#1c1240f2,#0e0a28f4);border:1.5px solid #5a4a86;box-shadow:0 12px 40px #000a,inset 0 1px 0 #ffffff14;display:flex;flex-direction:column;gap:10px}
.flegth{display:flex;align-items:baseline;justify-content:space-between;gap:10px}.flegth h3{margin:0;font:400 40px/1 'Pirata One',Georgia,serif;color:#ffd24a;text-shadow:0 2px 0 #5a2c04}.flegth small{font:600 13px var(--ui,Poppins,sans-serif);color:#c4badf}
.flegts{display:flex;flex-direction:column;gap:9px}
.flegt{position:relative;display:flex;align-items:center;gap:12px;min-height:80px;padding:9px 12px;border-radius:16px;background:#150f35;border:1.5px solid #3a2f68;transition:transform .2s,border-color .2s}
.flegt.done{border-color:#ffc83a;background:linear-gradient(90deg,#3a2a18,#1d1438)}.flegt.got{opacity:.78}.flegt.pop{animation:flepop .42s cubic-bezier(.3,1.6,.5,1)}
.flegti{display:grid;place-items:center;width:46px;height:46px;border-radius:50%;flex-shrink:0;background:#0c0820;border:2px solid var(--c);color:var(--c)}
.flegtx{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}.flegtx em{font:800 10.5px var(--ui,Poppins,sans-serif);font-style:normal;letter-spacing:.14em;color:var(--c);text-transform:uppercase}.flegtx b{font:700 15px/1.2 var(--ui,Poppins,sans-serif);color:#fff8e8}.flegtx small{font:500 12.5px var(--ui,Poppins,sans-serif);color:#c4badf}
.flegtr{display:flex;align-items:center;gap:4px;flex-shrink:0;font:800 16px var(--ui,Poppins,sans-serif);color:#ffd76a}
.flegtok{display:grid;place-items:center;width:36px;height:36px;border-radius:50%;background:#2a6a3a;color:#bfffcf;flex-shrink:0}
.flecl{all:unset;box-sizing:border-box;cursor:pointer;display:flex;align-items:center;gap:6px;height:40px;padding:0 14px;border-radius:12px;flex-shrink:0;background:linear-gradient(180deg,#ffe07a,#f7b21f 55%,#eb9810);color:#2a1700;font:800 14.5px var(--ui,Poppins,sans-serif);box-shadow:0 4px 0 #8a5a08;animation:flecl 1.8s ease-in-out infinite;transition:transform .14s}
.flecl:hover{transform:translateY(-2px)}.flecl:active{transform:translateY(2px)}@keyframes flecl{0%,100%{transform:translateY(0)}50%{transform:translateY(-3px)}}
.flegtb{display:flex;align-items:center;gap:8px;padding:8px 12px;border-radius:12px;background:#2a1a10aa;border:1px dashed #c8862c;font:500 13.5px var(--ui,Poppins,sans-serif);color:#ffe0a8}.flegtb b{color:#fff}.flegtb.got{border-style:solid;opacity:.8}
.flebag{display:grid;grid-template-columns:auto 1fr auto;align-items:center;gap:10px;font:600 12.5px var(--ui,Poppins,sans-serif);color:#c4badf}.flebag b{color:#ffd76a;font-size:13px}
.flesum{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:4px 0 6px}.flesum span{display:flex;flex-direction:column;align-items:flex-start;gap:2px;padding:10px 12px;border-radius:14px;background:#150f35;border:1.5px solid #3a2f68;font:500 13px var(--ui,Poppins,sans-serif);color:#c4badf}.flesum b{font:800 22px var(--ui,Poppins,sans-serif);color:#ffd76a}
.flegrace{margin:0;font:500 15px/1.45 var(--ui,Poppins,sans-serif);color:#e6deff}.flegone{padding:60px 40px;text-align:center;border-radius:24px;background:#120c2e;border:1.5px solid #4a3c86}.flegone h2{font:400 64px 'Pirata One',Georgia,serif;color:#ffc23a;margin:0 0 10px}.flegone p{max-width:640px;margin:0 auto 22px;font:500 17px/1.5 var(--ui,Poppins,sans-serif);color:#e6deff}
.flerow{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}
.fletile{all:unset;box-sizing:border-box;cursor:pointer;position:relative;display:flex;align-items:center;gap:12px;min-height:110px;padding:8px 14px 8px 8px;border-radius:18px;background:linear-gradient(180deg,#1c1240,#100a2a);border:1.5px solid #4a3a6a;transition:transform .18s cubic-bezier(.3,1.5,.5,1),border-color .15s;overflow:hidden}
.fletile canvas{width:116px;height:88px;flex-shrink:0}.fletile>div{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}.fletile b{font:400 25px/1.02 'Pirata One',Georgia,serif;color:#fff1d6}.fletile small{font:500 13px/1.3 var(--ui,Poppins,sans-serif);color:#d8cff0}
.fletile:hover:not([disabled]){transform:translateY(-3px);border-color:#ffb04a}.fletile:active:not([disabled]){transform:scale(.97)}.fletile[disabled]{cursor:default;opacity:.62}
.fletile em{position:absolute;top:9px;right:10px;font:800 11px var(--ui,Poppins,sans-serif);font-style:normal;letter-spacing:.08em;color:#2a1700;background:#ffc83a;padding:3px 9px;border-radius:99px;text-transform:uppercase}.fletile em.g{background:#ff8a3a;color:#fff}
.fletile.hot{border-color:#ffc83a;box-shadow:0 0 22px #ffc83a33}.flemkt{border-color:#c8862c}
/* calendar */
.flecalw{position:relative;border-radius:26px;box-shadow:0 18px 50px #000a}.flecalw>canvas{position:absolute;inset:0;width:100%;height:100%}
.flecalg{position:relative;display:grid;grid-template-columns:repeat(7,minmax(0,1fr));grid-template-rows:auto repeat(4,124px);gap:10px;padding:22px 30px 30px}
.flewd{text-align:center;font:800 12px var(--ui,Poppins,sans-serif);letter-spacing:.2em;color:#f4d8a8;text-transform:uppercase;text-shadow:0 1px 0 #000}
.flecalt{display:flex;flex-direction:column;justify-content:center;padding:6px 16px;border-radius:16px;background:linear-gradient(180deg,#2a160ccc,#1a0c06cc);border:2px solid #a8763e}.flecalt span{display:flex;gap:6px}.flecalt h2{margin:2px 0 0;font:400 46px/1 'Pirata One',Georgia,serif;color:#ffc23a;text-shadow:0 3px 0 #5a2004}.flecalt p{margin:4px 0 0;font:500 13.5px/1.35 var(--ui,Poppins,sans-serif);color:#f4e2c0}
.flecd{all:unset;box-sizing:border-box;position:relative;cursor:pointer;border-radius:14px;perspective:700px;background:radial-gradient(ellipse at 50% 40%,#3a1e10,#1a0c06);border:2px solid #12081f;box-shadow:inset 0 2px 8px #000c}
.flecdin{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;padding:6px;text-align:center}.flecdin i{display:inline-flex}.flecdin>i+i{margin-top:-6px}
.flecdin small{font:700 11.5px/1.15 var(--ui,Poppins,sans-serif);color:#ffe0a8}.flecd:not(.got):not(.opening) .flecdin{visibility:hidden}.flecd.got .flecddoor,.flecd.got .fledfx{visibility:hidden}
.flecddoor{position:absolute;inset:0;border-radius:12px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:0;transform-origin:0 50%;transition:transform .62s cubic-bezier(.3,1.25,.5,1);
 background:linear-gradient(90deg,#00000022 0 3px,transparent 3px 33%,#00000022 33% calc(33% + 3px),transparent 0 66%,#00000022 66% calc(66% + 3px),transparent 0),linear-gradient(180deg,#b07a42,#7a4a22);border:2px solid #12081f;box-shadow:inset 0 2px 0 #ffffff2a,inset 0 -3px 0 #00000040;backface-visibility:hidden}
.flecddoor em{font:800 11px var(--ui,Poppins,sans-serif);font-style:normal;letter-spacing:.18em;color:#ffe8c0;text-shadow:0 1px 0 #3a1a08}.flecddoor b{margin:7px 0 1px;font:400 40px/1 'Pirata One',Georgia,serif;color:#fff4d8;text-shadow:0 3px 0 #4a2008}
.flecd.wk .flecddoor{background:linear-gradient(90deg,#00000022 0 3px,transparent 3px 33%,#00000022 33% calc(33% + 3px),transparent 0 66%,#00000022 66% calc(66% + 3px),transparent 0),linear-gradient(180deg,#c8503a,#8a2a1a)}
.flerib{position:absolute;inset:0;pointer-events:none;z-index:0;background:linear-gradient(225deg,transparent 24px,#8a5010 24px,#e8a42a 25.5px,#ffd86a 31px,#e8a42a 36.5px,#8a5010 38px,transparent 38px);border-radius:12px}
.flerib::after{content:'';position:absolute;right:6px;top:10px;width:34px;height:20px;transform:rotate(45deg);background:radial-gradient(ellipse 8px 7px at 28% 50%,#ffd86a 0 6px,#8a5010 6.5px 7.5px,transparent 8px),radial-gradient(ellipse 8px 7px at 72% 50%,#ffd86a 0 6px,#8a5010 6.5px 7.5px,transparent 8px),radial-gradient(circle at 50% 50%,#ffe9a0 0 4px,#8a5010 4.5px 5.5px,transparent 6px)}
.flecddoor>em,.flecddoor>b{position:relative;z-index:1}.flecddoor::after{content:'';position:absolute;right:9px;top:50%;width:9px;height:9px;margin-top:-4px;border-radius:50%;background:radial-gradient(circle at 35% 35%,#fff2b0,#c8902a 60%,#6a4010);box-shadow:0 1px 0 #0008}
.flecd.got .flecddoor{transform:rotateY(-104deg)}.flecd.got{background:radial-gradient(ellipse at 50% 40%,#5a3418,#2a140a)}.flecd.got .flecdin{opacity:.9}
.flecd.opening .flecddoor{transform:rotateY(-104deg)}.flecd.opening .flecdin{animation:flein .5s .3s both cubic-bezier(.3,1.6,.5,1)}@keyframes flein{from{transform:scale(.3);opacity:0}}
.flecd.today{z-index:1}.flecd.today .flecddoor{background:linear-gradient(180deg,#ffd86a,#e8962a);animation:flebob 2.2s ease-in-out infinite}.flecd.today .flecddoor b{color:#4a2008;text-shadow:0 2px 0 #fff4c8}.flecd.today .flecddoor em{color:#5a2a08;text-shadow:none}
@keyframes flebob{0%,100%{transform:translateY(0) rotate(0)}50%{transform:translateY(-4px) rotate(-1deg)}}
.flecd.today::before{content:'';position:absolute;inset:-8px;border-radius:20px;background:radial-gradient(ellipse,#ffc23a66,#ffc23a00 70%);pointer-events:none}
.flecddoor::before{content:'';position:absolute;inset:0;border-radius:inherit;background:#0c0614;opacity:0;pointer-events:none}.flecd.lock .flecddoor::before{opacity:.42}.flecd.miss .flecddoor::before{opacity:.2}.flecd.lock{cursor:default}.flecd.lock .flecddoor b{color:#d8c8b0}
.flego,.flecu,.flelk{position:absolute!important;bottom:6px;left:50%;transform:translateX(-50%);white-space:nowrap;display:flex;align-items:center;gap:4px;padding:2px 9px;border-radius:99px;font:800 11px var(--ui,Poppins,sans-serif);font-style:normal}
.flego{background:#4a1a08;color:#ffe8b0}.flecu{background:#1c1440ee;color:#ffd76a;border:1px solid #c8862c}.flelk{background:none;bottom:5px;opacity:.7}
.flecd.today .flecddoor,.flecd.miss .flecddoor{padding-bottom:22px;box-sizing:border-box}.flecd.confirm .flecu{background:#ffc23a;color:#2a1700}
.flechk{position:absolute;top:6px;right:6px;display:grid;place-items:center;width:26px;height:26px;border-radius:50%;background:#2a6a3a;color:#bfffcf;font-style:normal}
.flemb2{position:relative;z-index:1;display:block;line-height:0;margin:-4px 0 2px;filter:drop-shadow(0 2px 0 #0006)}.flecd.lock .flemb2{opacity:.75}.flecd.today .flemb2,.flecd.miss .flemb2{display:none}.flecd.nope{animation:flenope .32s}@keyframes flenope{25%{transform:translateX(-4px)}75%{transform:translateX(4px)}}
.flecd:not(.lock):not(.got):hover .flecddoor{transform:rotateY(-14deg)}.flecd.today:hover .flecddoor{animation:none}
.flefeast .flecddoor{background:none;border:none;box-shadow:none}.fledbl{display:block}
.fledl,.fledr{position:absolute;top:0;bottom:0;width:50%;background:radial-gradient(ellipse at 50% 120%,#ffb04a40,#ffb04a00 60%),linear-gradient(90deg,#00000026 0 3px,transparent 3px 50%,#00000026 50% calc(50% + 3px),transparent 0),linear-gradient(180deg,#a8461e,#6a1e0a);border:2px solid #12081f;transition:transform .7s cubic-bezier(.3,1.2,.5,1);box-shadow:inset 0 2px 0 #ffffff2a}
.fledl{left:0;border-radius:12px 0 0 12px;transform-origin:0 50%;backface-visibility:hidden}.fledr{right:0;border-radius:0 12px 12px 0;transform-origin:100% 50%;backface-visibility:hidden}
.fledfx{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:0;transition:opacity .3s;border-radius:12px;box-shadow:inset 0 0 0 3px #e8a42a55}.fledcorn{position:absolute;left:28px;top:50%;margin-top:-23px}.fledcorn2{position:absolute;right:34px;top:50%;margin-top:-22px}.fledpl{display:flex;flex-direction:column;align-items:center;padding:4px 20px 3px;border-radius:14px;background:radial-gradient(ellipse at 50% 40%,#6a2410f0,#3a0e06f0);border:2px solid #e8a42a;box-shadow:0 4px 12px #0008;margin-bottom:12px}.flefeast.today .fledpl,.flefeast.miss .fledpl{margin-bottom:30px}.flefeast.today .fledpl{background:radial-gradient(ellipse at 50% 40%,#ffe08af4,#e8a42af4);border-color:#fff4c8}.fledfx em{font:800 12px var(--ui,Poppins,sans-serif);font-style:normal;letter-spacing:.3em;color:#ffd76a}.fledfx b{margin:6px 0 4px;font:400 36px/1 'Pirata One',Georgia,serif;color:#ffc23a;text-shadow:0 3px 0 #3a0a02}.fledfx small{display:flex;align-items:center;gap:6px;font:600 12.5px var(--ui,Poppins,sans-serif);color:#ffe8c8}
.flefeast.today .fledl,.flefeast.today .fledr{background:linear-gradient(90deg,#00000026 0 3px,transparent 3px 50%,#00000026 50% calc(50% + 3px),transparent 0),linear-gradient(180deg,#ffc23a,#d8761e)}.flefeast.today .fledfx b{color:#fff4d8;text-shadow:0 3px 0 #6a2a04}.flefeast.today .fledfx em{color:#4a1a04}.flefeast.today .fledfx small{color:#3a1404}
.flefeast.got .fledl,.flefeast.opening .fledl{transform:perspective(900px) rotateY(-100deg)}.flefeast.got .fledr,.flefeast.opening .fledr{transform:perspective(900px) rotateY(100deg)}.flefeast.got .fledfx,.flefeast.opening .fledfx{opacity:0}
.flefeast:not(.got):not(.lock):hover .fledl{transform:perspective(900px) rotateY(-10deg)}.flefeast:not(.got):not(.lock):hover .fledr{transform:perspective(900px) rotateY(10deg)}
.flefin{flex-direction:row;gap:16px}.flefin b{display:block;font:400 30px/1 'Pirata One',Georgia,serif;color:#ffd24a}.flefin small{font-size:13px}
.flefeast.lock{filter:none}.flefeast .fledl,.flefeast .fledr{box-shadow:inset 0 2px 0 #ffffff2a,inset 0 0 0 4px #e8a42a44}
.flecalf{display:flex;flex-wrap:wrap;gap:10px 22px;align-items:center;padding:10px 18px;border-radius:16px;background:#120c2e;border:1.5px solid #3a2f68;font:500 14px var(--ui,Poppins,sans-serif);color:#e6deff}.flecalf span{display:flex;align-items:center;gap:8px}.flecalf b{color:#ffd76a}
/* reveal */
#flerev{position:absolute;inset:0;z-index:9000;display:flex;align-items:center;justify-content:center;background:#05030cc8;animation:flefade .2s}#flerev.out{opacity:0;transition:opacity .2s}@keyframes flefade{from{opacity:0}}
.flerb{position:relative;width:640px;max-width:92%;padding:28px 30px 24px;border-radius:24px;text-align:center;background:linear-gradient(180deg,#2a1a40,#120a28);border:2px solid #c8862c;box-shadow:0 24px 70px #000;animation:flerb .5s cubic-bezier(.3,1.5,.5,1);overflow:hidden}
@keyframes flerb{from{transform:scale(.7);opacity:0}}.flerb.feast{border-color:#ffd45a;width:760px}
.flerays{position:absolute;left:50%;top:52%;width:900px;height:900px;margin:-450px 0 0 -450px;background:repeating-conic-gradient(#ffc23a22 0 9deg,#ffc23a00 9deg 18deg);border-radius:50%;animation:flespin 18s linear infinite;pointer-events:none}@keyframes flespin{to{transform:rotate(360deg)}}
.flerb>*{position:relative}.flerb em{font:800 13px var(--ui,Poppins,sans-serif);font-style:normal;letter-spacing:.24em;color:#ffcf9a;text-transform:uppercase}.flerb h3{margin:14px 0 14px;font:400 52px/1 'Pirata One',Georgia,serif;color:#ffc23a;text-shadow:0 3px 0 #5a2004}
.flergs{display:flex;justify-content:center;gap:30px;flex-wrap:wrap;margin:6px 0 2px}.flergi{display:grid;place-items:center;width:150px;height:150px;border-radius:50%;background:radial-gradient(circle,#ffc23a55,#ffc23a00 68%)}.flerg{display:flex;flex-direction:column;align-items:center;gap:8px;animation:flein .55s var(--d) both cubic-bezier(.3,1.7,.5,1)}.flerg b{font:800 18px var(--ui,Poppins,sans-serif);color:#fff}
.flerb p{margin:14px 0 0;font:500 14px var(--ui,Poppins,sans-serif);color:#e6deff}.flerbt{display:flex;justify-content:center;gap:12px;margin-top:20px;flex-wrap:wrap}
/* market */
.flestallh{position:relative;height:168px;border-radius:24px;overflow:hidden;border:1.5px solid #6a3a28;box-shadow:0 14px 40px #000a}.flestallh canvas{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
.flestt{position:relative;z-index:1;padding:22px 30px;max-width:520px}#flemknote{position:absolute;right:16px;bottom:14px;z-index:2;max-width:560px;box-shadow:0 8px 20px #000a;animation:fleask2 .3s cubic-bezier(.3,1.5,.5,1)}.flestt h2{margin:6px 0 4px;font:400 62px/1 'Pirata One',Georgia,serif;color:#ffc23a;text-shadow:0 3px 0 #6a2a04,0 0 20px #ff8a3c55}.flestt p{margin:0;font:500 14.5px/1.4 var(--ui,Poppins,sans-serif);color:#f4e2c0}
.flemkg{display:grid;grid-template-columns:1.3fr repeat(3,minmax(0,1fr));grid-template-rows:repeat(2,auto);gap:12px}
.flemi{position:relative;display:flex;flex-direction:column;gap:6px;padding:10px 12px 12px;border-radius:18px;background:linear-gradient(180deg,#1c1240,#100a2a);border:1.5px solid #3a2f68;transition:transform .2s cubic-bezier(.3,1.5,.5,1),border-color .15s;overflow:hidden;min-width:0}
.flemi:hover{transform:translateY(-3px);border-color:var(--c)}.flemi.can{border-color:#c8862c}.flemi.own{border-color:#3a7a4a}.flemi.bought{animation:flepop .5s cubic-bezier(.3,1.6,.5,1)}
.flemi canvas{width:100%;height:96px;object-fit:contain}.flemi.feat{grid-row:1 / 3;background:radial-gradient(ellipse at 50% 30%,#4a2a10,#1a0e24 70%);border-color:#ffb04a;box-shadow:0 0 30px #ff9a3a22}.flemi.feat canvas{height:auto;flex:1;min-height:180px}
.flemr{align-self:flex-start;padding:2px 9px;border-radius:99px;background:#0c0820;border:1px solid var(--c);color:var(--c);font:800 10.5px var(--ui,Poppins,sans-serif);letter-spacing:.12em;text-transform:uppercase}
.flefx{position:absolute;top:10px;right:12px;font:800 10.5px var(--ui,Poppins,sans-serif);letter-spacing:.12em;color:#ffd76a}
.flemt{display:flex;flex-direction:column;gap:2px;min-height:58px}.flemt b{font:400 24px/1.15 'Pirata One',Georgia,serif;color:#fff1d6}.flemt small{font:500 12px/1.3 var(--ui,Poppins,sans-serif);color:#cfc6ec}
.flemi.feat .flemt b{font-size:34px;line-height:1.25;color:#ffc23a}.flemi.feat .flemt small{font-size:13.5px}
.flemp{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:auto}.flepr{display:flex;align-items:center;gap:5px;font:800 19px var(--ui,Poppins,sans-serif);color:#fff}
.flebuy{all:unset;box-sizing:border-box;cursor:pointer;display:inline-flex;align-items:center;gap:4px;height:38px;padding:0 14px;border-radius:12px;background:linear-gradient(180deg,#ffe07a,#f7b21f 55%,#eb9810);color:#2a1700;font:800 13.5px var(--ui,Poppins,sans-serif);box-shadow:0 4px 0 #8a5a08;white-space:nowrap;transition:transform .14s}
.flebuy:hover:not([disabled]){transform:translateY(-2px)}.flebuy:active:not([disabled]){transform:translateY(2px)}.flebuy[disabled]{cursor:default;background:#241c48;color:#a89cd0;box-shadow:none;border:1px solid #3a2f68}
.flemi.own .flebuy{background:#1e4a2a;color:#bfffcf;box-shadow:none;border:1px solid #3a7a4a}.flemi.own .flebuy[disabled]{opacity:1}.flebuy.confirm{background:linear-gradient(180deg,#ff9a6a,#e8562a);color:#fff;box-shadow:0 4px 0 #8a2a08}
.flemb{position:absolute;left:12px;right:12px;bottom:5px;height:4px}.flebq{padding:0 11px;gap:3px}.flebq span{font-weight:700;opacity:.8;margin-right:2px}.flemi .flemp:has(.flebq){justify-content:flex-start}.flemi .flebuy.eq{background:#2a6a3a;color:#dfffe6;border:1px solid #5aba6a}
#fleask{position:absolute;left:50%;top:50%;z-index:9000;transform:translate(-50%,-50%);display:flex;flex-direction:column;align-items:center;gap:16px;padding:24px 28px;border-radius:20px;background:linear-gradient(180deg,#2a1a40,#120a28);border:2px solid #c8862c;box-shadow:0 24px 60px #000;animation:fleask .35s cubic-bezier(.3,1.5,.5,1)}#fleask b{font:400 34px 'Pirata One',Georgia,serif;color:#ffc23a}#fleask div{display:flex;gap:12px}#fleask.out{opacity:0;transition:opacity .18s}
@keyframes fleask{from{opacity:0;transform:translate(-50%,-50%) scale(.8)}}
#flemsg{position:absolute;left:50%;bottom:130px;z-index:9001;transform:translateX(-50%);max-width:640px;padding:12px 18px;border-radius:14px;background:#1c1440f4;border:1.5px solid #c8862c;font:600 15px/1.4 var(--ui,Poppins,sans-serif);color:#ffe0a8;text-align:center;animation:fleask2 .3s cubic-bezier(.3,1.5,.5,1)}#flemsg.out{opacity:0;transition:opacity .2s}@keyframes fleask2{from{opacity:0;transform:translate(-50%,10px)}}
/* help */
#flehow{position:absolute;inset:0;z-index:9000;display:flex;align-items:center;justify-content:center;background:#05030cd0}
.flehb{width:720px;max-width:92%;padding:24px 28px 22px;border-radius:22px;background:linear-gradient(180deg,#24183e,#0e0c30);border:2px solid #c8862c;box-shadow:0 24px 60px #000;animation:flerb .3s ease-out;text-align:left}
.flehb h3{margin:0;font:400 46px 'Pirata One',Georgia,serif;color:#ffc23a}.flehl{margin:0 0 14px;font:600 14px var(--ui,Poppins,sans-serif);color:#ffcf9a}.flehb ol{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:12px}.flehb li{display:flex;gap:14px;align-items:flex-start}
.flehb li b{display:block;font:700 17px var(--ui,Poppins,sans-serif);color:#fff}.flehb li small{display:block;font:500 13.5px/1.45 var(--ui,Poppins,sans-serif);color:#d4cbef}.flehb .flebig{display:flex;margin:18px 0 0 auto;width:max-content}
/* toast and result line */
#fletoast{position:absolute;right:36px;top:112px;z-index:9500;display:flex;align-items:center;gap:12px;padding:9px 20px 9px 12px;border-radius:99px;background:linear-gradient(180deg,#2e1c34,#1a1030);border:2px solid #c8862c;box-shadow:0 10px 30px #000a;pointer-events:none;opacity:0;transform:translate(0,-18px) scale(.9);transform-origin:100% 0;transition:opacity .25s,transform .35s cubic-bezier(.3,1.5,.5,1)}
#fletoast.show{opacity:1;transform:translate(0,0) scale(1)}#fletoast div{display:flex;flex-direction:column;line-height:1.1}#fletoast i{font:700 11px var(--ui,Poppins,sans-serif);font-style:normal;letter-spacing:.14em;color:#ffcf9a;text-transform:uppercase}#fletoast b{font:800 21px var(--ui,Poppins,sans-serif);color:#fff}#fletoast span{font:500 12.5px var(--ui,Poppins,sans-serif);color:#e6deff}
#fletoast.task{border-color:#7affa0}#fletoast.task b{font-size:17px}.fltic{display:grid;place-items:center}
.flres{display:flex;align-items:center;justify-content:center;gap:8px;margin:6px 0;font:600 16px var(--ui,Poppins,sans-serif);color:#ffe0a8}.flres b{color:#ffc23a}
.fleburst{position:absolute;z-index:9600;width:0;height:0;pointer-events:none}.fleburst i{position:absolute;left:-11px;top:-11px;animation:fleb .9s var(--dl) cubic-bezier(.2,.8,.3,1) both}
@keyframes fleb{0%{transform:translate(0,0) scale(.4) rotate(0);opacity:1}70%{opacity:1}100%{transform:translate(var(--x),calc(var(--y) + 60px)) scale(1) rotate(var(--r));opacity:0}}
/* home card */
.dkfl{border-color:#ff9a3aaa!important}.dkfl:hover{border-color:#ffc46a!important}.dkfl .dkcl{max-width:100%;width:100%}
.flecrow{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:2px}.flecm{all:unset;box-sizing:border-box;cursor:pointer;font:600 15px var(--ui,Poppins,sans-serif);color:#e8e0ff;border-radius:6px;white-space:nowrap}.flecm i{font-style:normal;margin-left:4px}.flecm:hover{color:#fff}
.dkfl .dkevl u{text-decoration:none;opacity:.6}.dkfl .dkevl span{display:flex;align-items:center;gap:6px;line-height:1.3}.dkfl .dkevl{margin:1px 0 2px}.dkfl .dkevl .fleico{margin:0}
.flehw{all:unset;box-sizing:border-box;position:relative;z-index:2;flex-shrink:0;cursor:pointer;display:flex;align-items:center;gap:6px;height:28px;padding:0 12px 0 8px;border-radius:99px;background:#1a0e2ee8;border:1.5px solid #ff9a2a;color:#ffe0b0;font:700 13px var(--ui,Poppins,sans-serif);transition:transform .16s cubic-bezier(.3,1.5,.5,1),background .15s}
.flehw svg{width:20px;height:20px}.flehw{white-space:nowrap}.flehw i{font-style:normal}.flehw:hover{background:#3a1a3e;transform:translateY(-2px)}
.fledot{position:absolute!important;top:10px!important;right:12px!important;left:auto!important;z-index:2}
#ov.dknar.dkshort .flehw{height:26px}
/* falling leaves over the home screen (transform and opacity only) */
.flleaves{position:absolute;inset:0;z-index:6;overflow:hidden;pointer-events:none}
.fllf{position:absolute;left:0;top:0;transform:translate3d(var(--x),-60px,0);animation:flfall var(--d) linear var(--dl) infinite;opacity:.9}
.fllf>i{display:block;animation:flsway var(--sw) ease-in-out infinite alternate}
@keyframes flfall{from{transform:translate3d(var(--x),-60px,0)}to{transform:translate3d(calc(var(--x) + var(--dx)),960px,0)}}
@keyframes flsway{from{transform:translateX(-30px) rotate(-35deg) scaleX(1)}to{transform:translateX(30px) rotate(55deg) scaleX(.5)}}
@media (prefers-reduced-motion:reduce){.flleaves{display:none}.flecl,.flecd.today .flecddoor,.flerays{animation:none}}
body.pf-low .flleaves{display:none}body.pf-low .flerays{animation:none}
.flemg .flehwl{grid-column:1 / -1;margin:6px 0 -2px;font-weight:700;color:#ffb86a}
/* narrow stages (touch phones and small windows: #ov.dknar), sized from the stage like the rest of the dock pages */
#ov.dknar .fle{padding:0 4px 12px;gap:10px}#ov.dknar .fletop{flex-wrap:wrap;gap:8px}#ov.dknar .fleev{order:5;flex-basis:100%}#ov.dknar .fleev b{font-size:12px}#ov.dknar .flewal{height:46px;padding:0 16px 0 10px}#ov.dknar .flewal b{font-size:22px}
#ov.dknar .flemain{grid-template-columns:1fr;min-height:0}#ov.dknar .flehero{padding:20px 18px 12px}#ov.dknar .flehero h2{font-size:60px;margin-top:8px}#ov.dknar .flehero p{font-size:15px}#ov.dknar .flekick span{font-size:14px}
#ov.dknar .flepanel{margin:0 12px 12px}#ov.dknar .flerow{grid-template-columns:1fr 1fr}#ov.dknar .fletile{min-height:86px;gap:8px}#ov.dknar .fletile canvas{width:84px;height:64px}#ov.dknar .fletile b{font-size:20px}#ov.dknar .fletile small{font-size:12px}
#ov.dknar .flecalg{grid-template-rows:auto repeat(4,88px);gap:6px;padding:14px 12px 18px}#ov.dknar .flecdin small,#ov.dknar .flecalt p,#ov.dknar .flemb2,#ov.dknar .fledcorn,#ov.dknar .fledcorn2,#ov.dknar .fledfx small,#ov.dknar .flechk{display:none}
#ov.dknar .flecddoor b{font-size:28px;margin:2px 0 0}#ov.dknar .flecddoor em{font-size:9px;letter-spacing:.08em}#ov.dknar .flecalt{padding:4px 10px}#ov.dknar .flecalt h2{font-size:28px}#ov.dknar .flecalt span .fleico{width:20px;height:20px}
#ov.dknar .flego,#ov.dknar .flecu{font-size:9.5px;padding:1px 6px}#ov.dknar .fledpl{padding:2px 10px;margin-bottom:22px}#ov.dknar .fledfx em{font-size:9px;letter-spacing:.12em}#ov.dknar .fledfx b{font-size:26px;margin:2px 0}
#ov.dknar .flecd.today .flecddoor,#ov.dknar .flecd.miss .flecddoor{padding-bottom:16px}#ov.dknar .flecdin i .fleico{width:34px;height:34px}
#ov.dknar .flemkg{grid-template-columns:1fr 1fr}#ov.dknar .flemi.feat{grid-column:1 / -1;grid-row:auto}#ov.dknar .flemi.feat canvas{min-height:140px;max-height:200px}#ov.dknar .flestallh{height:140px}#ov.dknar .flestt{padding:14px 18px}#ov.dknar .flestt h2{font-size:42px}#ov.dknar .flestt p{font-size:13px}
#ov.dknar .flecalf{font-size:12.5px}
`;document.head.appendChild(st)}
