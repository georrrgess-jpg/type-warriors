/* ===== RUNESTONE TOWER DEFENSE 10.0: Three Worlds - data (98a) =====
   The spec is TD_WORLDS_PLAN.md at the repo root. This module only holds data and the art registries; the rules are in 98b, the
   mastery system in 98m, the art in 98d-98k.
   - RP_WORLDS: the three worlds and their maps. World 2 (Tidebreak Isles) opens with a star on Ember Crown, World 3 (Skyforge
     Heights) with a star on Kraken's Maw. Inside a world each map needs a star on the one before.
   - Six new maps are appended to RP_MAPS (after the Wonderland). RP_MAP_OPEN (a const in 95a) looks at the map before it in RP_MAPS;
     the array's own indexOf is shadowed so Coral Shallows looks at Ember Crown instead of the Wonderland.
   - map fields: world, maxT (top tower tier: 4 in World 2, 5 in World 3), pool [[id,cost,fromWave]], boss, and the twist data
     (tide, fog, cannon, whirl, glow, bridge, gust, sw, conv, vents, rods). Paths are on the 1600 x 900 stage like World 1's.
   - Monsters: RPMOB (name, size, flying), RP_FOE (stats and ability numbers), RP_FOETIP, RPMOBV (names per map variant).
   - RPW: the art registries the art modules fill (see the plan, section 6). */
const RP_WORLDS=[
 {id:1,n:'The Runestone Realm',sub:'Forest, frost and fire',maps:['moss','frost','ember','wonder'],col:'#7dd36a'},
 {id:2,n:'Tidebreak Isles',sub:'Reefs, wrecks and the deep',maps:['coral','wreck','abyss'],col:'#4ad8e8',need:'ember'},
 {id:3,n:'Skyforge Heights',sub:'Sky islands, gears and storms',maps:['meadow','foundry','storm'],col:'#ffb84a',need:'abyss'}];
const RP_WORLD=id=>RP_WORLDS.find(w=>w.id===id)||RP_WORLDS[0];
const rpWorldOf=m=>m&&m.world?m.world:1;
/* ---------- the six new maps ---------- */
const RP_W2POOL=[['crab',1,1],['shell',3,2],['jelly',2,3],['puffer',3,4],['squid',3,6],['brute',7,7],['siren',6,8]];
const RP_W3POOL=[['cog',1,1],['knight',3,2],['gyro',2,3],['spring',3,4],['jammer',4,6],['steam',7,7],['tinker',6,8]];
RP_MAPS.push(
 {id:'coral',world:2,n:'Coral Shallows',sub:'A long road along the reef',waves:15,start:420,hpk:2.9,spk:1.06,coinK:.48,bonus:1100,late:.4,lateW:6,lateC:.2,xp:350,pal:'coral',pads:14,maxT:4,
  pool:RP_W2POOL,boss:'leviathan',
  twist:'Rising Tide: every so often the tide floods the low stretches of road. Wading monsters are slowed but take less damage, except from the Tidecaller.',
  paths:[[[-60,640],[120,650],[260,600],[330,480],[300,350],[380,240],[540,200],[680,260],[720,400],[640,520],[700,640],[860,690],[1000,620],[1040,480],[980,340],[1060,220],[1220,200],[1320,300],[1300,460],[1360,580],[1450,628]]],
  tide:[[190,625,82],[780,668,86],[1012,560,74]],tideT:26,tideHi:9},
 {id:'wreck',world:2,n:'Shipwreck Cove',sub:'Two sea caves, one misty cove',waves:18,start:460,hpk:3.3,spk:1.07,coinK:.48,bonus:1300,late:.45,lateW:6,lateC:.22,xp:400,pal:'wreck',pads:14,maxT:4,
  pool:RP_W2POOL,boss:'leviathan',
  twist:'Fog banks drift through the cove: a monster in the fog can only be hit by towers close to it. The old wreck\'s cannon fires at the leading monster.',
  paths:[[[-60,220],[140,230],[300,300],[420,380],[560,420],[700,330],[860,300],[1000,360],[1080,480],[1200,520],[1330,470],[1450,440]],
         [[-60,690],[150,680],[300,610],[440,520],[560,420],[700,330],[860,300],[1000,360],[1080,480],[1200,520],[1330,470],[1450,440]]],
  fog:3,fogNear:150,cannon:[800,585],cannonT:12,ship:[790,610,330,170]},
 {id:'abyss',world:2,n:'Kraken\'s Maw',sub:'Two roads around the deep',waves:20,start:500,hpk:3.8,spk:1.08,coinK:.5,bonus:1500,late:.5,lateW:6,lateC:.25,xp:450,pal:'abyss',pads:14,maxT:4,
  pool:RP_W2POOL,boss:'leviathan',
  twist:'Whirlpools sweep monsters along the road; Glowcap lights light the dark, giving nearby towers more range.',
  paths:[[[-60,250],[150,250],[320,180],[520,140],[760,130],[980,170],[1120,260],[1170,400],[1260,500],[1360,540],[1450,560]],
         [[-60,650],[140,650],[300,700],[520,710],[760,700],[980,680],[1120,610],[1170,500],[1260,500],[1360,540],[1450,560]]],
  lake:[650,425,250,135],whirl:[[520,140,46],[760,702,46],[1168,452,46]],glow:[[400,330],[900,315],[410,560],[905,565]],glowR:150},
 {id:'meadow',world:3,n:'Cloudspire Meadows',sub:'Islands above the clouds',waves:18,start:560,hpk:4.6,spk:1.08,coinK:.5,bonus:1800,late:.45,lateW:6,lateC:.22,xp:500,pal:'meadow',pads:14,maxT:5,
  pool:RP_W3POOL,boss:'titan',
  twist:'The road crosses swaying rope bridges that slow walkers; gales sweep flyers forward.',
  paths:[[[-60,260],[140,260],[260,330],[300,460],[220,580],[300,690],[480,700],[600,600],[620,460],[560,330],[640,210],[800,180],[920,260],[940,400],[880,540],[960,660],[1120,690],[1240,600],[1250,470],[1340,430],[1450,470]]],
  bridge:[[258,522,58],[612,525,58],[912,470,58],[1186,646,58]],gustT:18,gustD:2.5},
 {id:'foundry',world:3,n:'Gearworks Foundry',sub:'A switch track through the works',waves:20,start:600,hpk:5.2,spk:1.09,coinK:.5,bonus:2100,late:.5,lateW:6,lateC:.25,xp:550,pal:'foundry',pads:14,maxT:5,
  pool:RP_W3POOL,boss:'titan',
  twist:'The road splits at a rail switch that flips every wave; conveyor belts carry monsters faster; furnace vents burn them.',
  paths:[[[-60,450],[160,450],[320,450],[420,450],[520,300],[700,220],[900,220],[1040,320],[1100,450],[1240,470],[1350,520],[1450,540]],
         [[-60,450],[160,450],[320,450],[420,450],[520,600],[700,690],[900,690],[1040,590],[1100,450],[1240,470],[1350,520],[1450,540]]],
  sw:[420,450],conv:[[800,220,95],[800,690,95]],vents:[[612,262],[612,646],[1190,560]]},
 {id:'storm',world:3,n:'Storm Citadel',sub:'Two climbs in a thunderstorm',waves:25,start:650,hpk:5.6,spk:1.1,coinK:.52,bonus:2600,late:.55,lateW:7,lateC:.28,xp:650,pal:'storm',pads:15,maxT:5,
  pool:RP_W3POOL,boss:'titan',
  twist:'Lightning strikes the leading monster, but also jams towers far from a lightning rod. Towers near a rod are safe and hit harder.',
  paths:[[[-60,690],[160,690],[300,640],[360,520],[300,400],[380,280],[560,240],[700,320],[720,460],[820,560],[1000,580],[1120,500],[1140,360],[1240,330],[1340,400],[1450,460]],
         [[-60,170],[140,180],[300,150],[460,120],[600,170],[700,320],[720,460],[820,560],[1000,580],[1120,500],[1140,360],[1240,330],[1340,400],[1450,460]]],
  rods:[[500,410],[930,420],[1255,520]],rodR:130,boltT:10,boltTwT:16});
/* Coral Shallows needs a star on Ember Crown: RP_MAPOPEN uses RP_MAPS.indexOf(m) - 1 */
Object.defineProperty(RP_MAPS,'indexOf',{value:function(x,i){if(x&&x.id==='coral')return Array.prototype.indexOf.call(this,RP_MAP('ember'))+1;return Array.prototype.indexOf.call(this,x,i)},writable:true,configurable:true});
/* fallback ground palettes (the art modules bake their own maps) */
Object.assign(RP_PAL,{
 coral:{g0:'#c8a868',g1:'#f0d898',g2:'#b89458',blot:['#e8cc88','#dcc07c','#f4e0a8','#d0b070'],tree:['#2a8a5a','#3aa46a','#1e6a48'],treeHi:'#9aff9a',trunk:'#8a5a32',rock:'#a88a6a',rockHi:'#e8d0b0',edge:'#5a4428',curb:'#e8d8b8',dirt:'#f4e6c4',dirt2:'#e2d0a8',cob:['#fff0d0','#f0dcb4','#e4cca4'],chev:'rgba(90,60,30,.3)',water:'#1ab0c8',waterHi:'#bff8ff',mote:'#ffffff',sky:'#0a3a5a'},
 wreck:{g0:'#3a4a48',g1:'#566a62',g2:'#2c3a38',blot:['#4a5e56','#3e5048','#5e7268','#34443e'],tree:['#2a4a3a','#38604a','#1e3a2c'],treeHi:'#8ac8a0',trunk:'#4a3424',rock:'#5a6266',rockHi:'#9aa4a8',edge:'#1e2826',curb:'#8a8678',dirt:'#8a7a5e',dirt2:'#76684e',cob:['#a8987a','#988a6c','#b4a688'],chev:'rgba(255,240,200,.3)',water:'#1e5a6a',waterHi:'#8ad8e8',mote:'#e8f8ff',sky:'#0e1a24'},
 abyss:{g0:'#0a1838',g1:'#12264e',g2:'#08122c',blot:['#16305a','#0e2248','#1c3a6a','#0a1a3c'],tree:['#1a4a6a','#2a6a8a','#123a5a'],treeHi:'#6af0ff',trunk:'#2a3a5a',rock:'#2a3a62',rockHi:'#6a8ac8',edge:'#040a1c',curb:'#3a5a8a',dirt:'#2a4270',dirt2:'#22385e',cob:['#3a5a8a','#324e7c','#466898'],chev:'rgba(120,240,255,.35)',water:'#0a3a6a',waterHi:'#6af0ff',mote:'#8affff',sky:'#020818'},
 meadow:{g0:'#3a8a3a',g1:'#6ac454',g2:'#2c722e',blot:['#5ab84a','#4aa040','#7ad060','#3c8a36'],tree:['#2a7a3a','#3a9a4a','#1e5a2c'],treeHi:'#b8ff8a',trunk:'#7a5232',rock:'#8a8aa0',rockHi:'#d8d8ea',edge:'#2a3a2a',curb:'#c8b898',dirt:'#c8a878',dirt2:'#b49464',cob:['#d8c09a','#c8b08a','#e4cca8'],chev:'rgba(70,50,20,.3)',water:'#7ac8f0',waterHi:'#ffffff',mote:'#ffffff',sky:'#7ac0f0'},
 foundry:{g0:'#2a2420',g1:'#3e342c',g2:'#201a16',blot:['#3a302a','#4a3e34','#2e2620','#56483c'],tree:['#4a4038','#5a4e44','#3a322c'],treeHi:'#ffb84a',trunk:'#3a2a20',rock:'#5a5450',rockHi:'#9a908a',edge:'#14100c',curb:'#8a7a5a',dirt:'#5a5048',dirt2:'#4a4038',cob:['#6a6058','#5a5048','#7a6e64'],chev:'rgba(255,190,90,.4)',water:'#ff7a2a',waterHi:'#ffe08a',mote:'#ffb84a',sky:'#1a1210'},
 storm:{g0:'#2a3044',g1:'#3c4660',g2:'#20263a',blot:['#36405a','#2c3450','#46506c','#283048'],tree:['#2a3a4a','#3a4a5e','#1e2a38'],treeHi:'#9ad8ff',trunk:'#3a3440',rock:'#4a5470',rockHi:'#9aa8c8',edge:'#121624',curb:'#7a849e',dirt:'#5a6280',dirt2:'#4a5270',cob:['#6a7290','#5e6684','#7a82a0'],chev:'rgba(160,220,255,.4)',water:'#3a5a9a',waterHi:'#c8eaff',mote:'#c8eaff',sky:'#0c1020'}});
/* ---------- monsters ---------- */
Object.assign(RPMOB,{
 crab:{n:'Crabling',h:34,air:false,w:34,desc:'Scuttles in quick sprints.'},
 shell:{n:'Shellback',h:56,air:false,w:52,desc:'Hides in its shell: stops, but becomes very hard to hurt.'},
 puffer:{n:'Puffer',h:50,air:false,w:46,desc:'Puffs up when hurt: bigger, slower and tougher.'},
 jelly:{n:'Jellyglide',h:46,air:true,lift:40,w:40,desc:'Floats over the road and glimmers out of reach now and then.'},
 brute:{n:'Barnacle Brute',h:86,air:false,w:72,desc:'A huge crusted tank; its armor falls away as it is hurt.'},
 siren:{n:'Siren',h:62,air:false,w:38,desc:'Her song shields nearby monsters.'},
 squid:{n:'Inkling',h:50,air:false,w:38,desc:'Inks the nearest tower when hurt, jamming it.'},
 leviathan:{n:'Leviathan',h:140,air:false,boss:true,w:210,desc:'Boss: a sea serpent that dives out of reach and calls Crablings.'},
 cog:{n:'Cogling',h:38,air:false,w:30,desc:'A fast little wind-up bot.'},
 knight:{n:'Brass Knight',h:64,air:false,w:40,desc:'Guards the monsters behind it: they take less damage.'},
 steam:{n:'Steam Golem',h:92,air:false,w:74,desc:'Vents steam as it is hurt and charges ahead, ignoring slows.'},
 gyro:{n:'Gyrocopter',h:42,air:true,lift:42,w:46,desc:'A fast flying contraption.'},
 tinker:{n:'Chronotinker',h:60,air:false,w:38,desc:'Winds up nearby monsters: they move faster.'},
 spring:{n:'Springjack',h:56,air:false,w:38,desc:'Leaps far down the road, out of reach in mid-air.'},
 jammer:{n:'Sparkjammer',h:52,air:false,w:40,desc:'Its EMP jams the towers it passes.'},
 titan:{n:'Titan Automaton',h:160,air:false,boss:true,w:200,desc:'Boss: stomps to jam towers and sheds armor plates to speed up.'}});
Object.assign(RP_FOE,{
 crab:{hp:44,sp:104,bounty:6,coin:2,dmg:1,armor:0,scut:[4,.8,1.6]},
 shell:{hp:150,sp:46,bounty:12,coin:5,dmg:2,armor:8,shellT:6,shellD:1.6,shellA:16},
 puffer:{hp:120,sp:58,bounty:9,coin:4,dmg:2,armor:2,puffAt:.5,puffSp:.75,puffA:6},
 jelly:{hp:70,sp:72,bounty:9,coin:3,dmg:1,armor:0,air:1,glimT:5,glimD:1.2},
 brute:{hp:440,sp:34,bounty:22,coin:9,dmg:3,armor:14,shed:1},
 siren:{hp:120,sp:52,bounty:14,coin:6,dmg:2,armor:0,songT:6,songR:110,songK:.12,songD:4},
 squid:{hp:95,sp:64,bounty:10,coin:4,dmg:2,armor:1,inkAt:.6,inkR:170,inkD:2.5},
 leviathan:{hp:4200,sp:22,bounty:220,coin:130,dmg:10,armor:10,boss:1,dive:[.75,.5,.25],diveD:2.5,diveSp:1.6,diveN:4},
 cog:{hp:50,sp:110,bounty:6,coin:2,dmg:1,armor:0},
 knight:{hp:170,sp:48,bounty:13,coin:5,dmg:2,armor:10,guardR:70,guardK:.3},
 steam:{hp:500,sp:32,bounty:24,coin:10,dmg:3,armor:9,ventAt:.15,ventD:1.8,ventSp:1.6},
 gyro:{hp:85,sp:94,bounty:9,coin:3,dmg:1,armor:0,air:1},
 tinker:{hp:130,sp:50,bounty:14,coin:6,dmg:2,armor:0,hasteR:110,hasteK:.25},
 spring:{hp:105,sp:56,bounty:11,coin:4,dmg:2,armor:3,leapT:4.5,leapD:.45,leapS:80},
 jammer:{hp:115,sp:60,bounty:12,coin:5,dmg:2,armor:4,empR:120,empD:2},
 titan:{hp:5600,sp:20,bounty:300,coin:160,dmg:10,armor:14,boss:1,stompT:8,stompR:200,stompD:1.6,shedAt:[.66,.33],shedA:4,shedSp:.2}});
Object.assign(RP_FOETIP,{
 crab:'Fast and small: slows and splash keep them in check.',shell:'Hides in its shell: hit it while it walks, or melt its armor with the Alchemist\'s Still.',
 puffer:'Puffs up at half health: finish it fast.',jelly:'Flies and glimmers out of reach: towers that hit flyers, and splash, catch it.',
 brute:'Huge armor that falls away as it is hurt: armor-piercing towers open it up.',siren:'Shields its friends: take it out first.',
 squid:'Inks a tower when hurt: long-range towers keep away from it.',leviathan:'Dives out of reach three times and calls Crablings: keep damage on the road ahead.',
 cog:'Very fast: slows and splash.',knight:'Protects the monsters behind it: hit the knight first or from the side.',steam:'Vents steam to charge past slows: burst it down.',
 gyro:'A fast flyer: towers that hit flyers.',tinker:'Speeds up its friends: slow it and kill it early.',spring:'Leaps down the road: cover the far end too.',
 jammer:'Jams towers as it walks by: kill it before it reaches your best towers.',titan:'Stomps to jam nearby towers: spread your defense and keep damage out of its reach.'});
RPMOBV.coral={crab:{n:'Reef Crabling'},shell:{n:'Coral Shellback'},puffer:{n:'Reef Puffer'},jelly:{n:'Moon Jelly'},brute:{n:'Barnacle Brute'},siren:{n:'Coral Siren'},squid:{n:'Reef Inkling'},leviathan:{n:'Reef Leviathan'}};
RPMOBV.wreck={crab:{n:'Deckhand Crab'},shell:{n:'Ironclad Shellback'},puffer:{n:'Powder Puffer'},jelly:{n:'Lantern Jelly'},brute:{n:'Bilge Brute'},siren:{n:'Wreck Siren'},squid:{n:'Ink Corsair'},leviathan:{n:'Dreadnought Leviathan'}};
RPMOBV.abyss={crab:{n:'Abyss Crawler'},shell:{n:'Trench Shellback'},puffer:{n:'Lure Puffer'},jelly:{n:'Glowjelly'},brute:{n:'Deepsea Brute'},siren:{n:'Abyssal Siren'},squid:{n:'Void Squid'},leviathan:{n:'Kraken Leviathan'}};
RPMOBV.meadow={cog:{n:'Mossy Cogling'},knight:{n:'Verdigris Knight'},steam:{n:'Ivy Steam Golem'},gyro:{n:'Dandelion Gyro'},tinker:{n:'Garden Tinker'},spring:{n:'Hopper Jack'},jammer:{n:'Meadow Jammer'},titan:{n:'Overgrown Titan'}};
RPMOBV.foundry={cog:{n:'Soot Cogling'},knight:{n:'Forge Knight'},steam:{n:'Furnace Golem'},gyro:{n:'Smog Gyro'},tinker:{n:'Foundry Tinker'},spring:{n:'Piston Jack'},jammer:{n:'Slag Jammer'},titan:{n:'Foundry Titan'}};
RPMOBV.storm={cog:{n:'Spark Cogling'},knight:{n:'Thunder Knight'},steam:{n:'Storm Golem'},gyro:{n:'Storm Gyro'},tinker:{n:'Tempest Tinker'},spring:{n:'Volt Jack'},jammer:{n:'Arc Jammer'},titan:{n:'Storm Titan'}};
/* which world each new monster belongs to, and its map variants */
const RPW_MOBS={crab:2,shell:2,puffer:2,jelly:2,brute:2,siren:2,squid:2,leviathan:2,cog:3,knight:3,steam:3,gyro:3,tinker:3,spring:3,jammer:3,titan:3};
const RPW_VARS={2:['coral','wreck','abyss'],3:['meadow','foundry','storm']};
/* ---------- art registries (filled by 98d-98k) ---------- */
const RPW={bake:{},amb:{},ambTop:{},twist:{},world:{},icon:{},castleHit:{}};
/* ---------- the hub shows one world at a time ----------
   rampartsMenu (95f and its wrappers) lays out every map in RP_MAPS on one painting. While it runs, RP_MAPS holds only the maps of
   the world on show (RPW_VIEW); the full list is put back straight after. 98b adds the world switcher on top. */
let RPW_VIEW=1;
function rpwOnly(wid,fn){const all=RP_MAPS.slice(),vis=all.filter(m=>rpWorldOf(m)===wid);RP_MAPS.length=0;RP_MAPS.push(...vis);try{return fn()}finally{RP_MAPS.length=0;RP_MAPS.push(...all)}}
{const m0=rampartsMenu;rampartsMenu=function(){const a=arguments,t=this;return rpwOnly(RPW_VIEW,()=>m0.apply(t,a))}}
/* ---------- art hooks: the registries above, wired into the renderer ----------
   - RPW.bake[id](map) replaces the generic bake for that map; it must return {c (1600 x 900 canvas), pal, G: rpGeo(map), trees: [],
     cast: {x, y, w, h} (the castle box, for hit effects), id}. Pads are drawn by the engine every frame: never bake them.
   - RPW.amb[id](c, R) replaces the generic animated ambience (drawn on the ground, below towers and monsters);
     RPW.twist[id](c, R) draws the twist (tide, fog, whirlpools, gusts, switch lever, lightning...) right after it.
   - RPW.ambTop[id](c, R) is drawn above everything in the battle except the banner (rain, fog over monsters, foreground clouds).
   - RPW.castleHit[id](c, x, y, k) the castle flinch when a monster gets through (k 0..1); without it the new maps show none.
   - RPW.icon[id](w, h) the little map picture (next-region cards). RPW.world[wid]() is wired up by the hub (98b). */
{const b0=rpBake;rpBake=function(map){const f=map&&RPW.bake[map.id];if(!f)return b0.apply(this,arguments);if(RPBAKE[map.id])return RPBAKE[map.id];const B=f(map);B.id=map.id;if(!B.G)B.G=rpGeo(map);if(!B.trees)B.trees=[];return RPBAKE[map.id]=B}}
{const a0=rpAmbient;rpAmbient=function(c,R){const id=R&&R.map&&R.map.id,f=id&&RPW.amb[id];if(f){try{f(c,R)}catch(e){console.error(e)}}else a0.apply(this,arguments);const tw=id&&RPW.twist[id];if(tw)try{tw(c,R)}catch(e){console.error(e)}}}
{const d0=rpBannerDraw;rpBannerDraw=function(c,R){const id=R&&R.map&&R.map.id,f=id&&RPW.ambTop[id];if(f)try{c.save();f(c,R);c.restore()}catch(e){console.error(e)}return d0.apply(this,arguments)}}
{const h0=rpCastleHit;rpCastleHit=function(c,id,x,y,k){if(RPW.castleHit[id])return RPW.castleHit[id](c,x,y,k);if(RP_MAP(id).world>1)return;return h0.apply(this,arguments)}}
{const i0=rpMapIcon;rpMapIcon=function(id,w,h){if(RPW.icon[id])return RPW.icon[id](w,h);return i0.apply(this,arguments)}}
/* monsters of the new worlds always draw in one of their world's variants (98d / 98e draw them; o.v is the variant) */
{const v0=rpvV;rpvV=function(id,v){const w=RPW_MOBS[id];if(w){const L=RPW_VARS[w];return L.includes(v)?v:L[0]}return v0.apply(this,arguments)}}
