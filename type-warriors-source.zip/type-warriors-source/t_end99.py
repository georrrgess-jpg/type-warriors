# python3 t_end99.py [game.html] : Runestone Tower Defense 9.9h (97c) - Hex Shamans that can be out-damaged (one heal per pulse window
# however many shamans reach a monster, no shaman-on-shaman healing, half on bosses, a fading pulse in the late Wonderland) and the
# endless curve past wave 50 (no extra compounding, at most two Behemoths per boss wave, boss hit points that stop compounding).
import asyncio,os,sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:500]),flush=True)
    if not ok:FAIL.append(name)
HELP=r"""()=>{
 window.tdNew=(map,wave)=>{try{rpLeave()}catch(e){}rpStart(map);const R=RPX;R.tut=null;R.hold=false;R.supply=1e9;R.wst='run';R.wave=wave;R.q=[];R.banner=null;R.foes=[];return R};
 /* n shamans and the given monsters on one spot of the road, everyone at half health; T seconds; health gained as a share of max */
 window.tdHeal=(map,wave,nSh,ids,T)=>{const R=tdNew(map,wave);const s0=300;const sh=[],tg=[];
  for(let i=0;i<nSh;i++){const e=rpSpawn('shaman',0);e.s=s0+i*2;e.sp=0;sh.push(e)}
  for(const id of ids){const e=rpSpawn(id,0);e.s=s0+1;e.sp=0;tg.push(e)}
  for(const e of [...sh,...tg])e.hp=e.mx*.5;for(let i=0;i<Math.round(T*30);i++)rpStep(R,1/30);
  const g=e=>+((e.hp-e.mx*.5)/e.mx).toFixed(3);const out={sh:sh.map(g),tg:tg.map(g)};rpLeave();return out};
 return 1}"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E("()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const T=RPP().tut;for(const k of['build','wave','coins','upgrade','abil','twist_frost','twist_ember','twist_wonder'])T[k]=1;RPP().stars.ember=1;RPP().dragon=1}")
        await E(HELP)
        r=await E("()=>tdHeal('ember',8,1,['bulwark'],2.5)")
        chk('one Hex Shaman still heals a hurt monster next to it by 8% per pulse (early maps unchanged)',r['tg']==[0.08],r)
        r=await E("()=>tdHeal('ember',8,3,['bulwark'],2.5)")
        chk('three shamans around one monster: still one 8% heal per pulse window, not 24%',r['tg']==[0.08],r)
        r=await E("()=>tdHeal('ember',8,4,[],7.5)")
        chk('shamans no longer heal each other (a pack of them cannot out-heal the towers)',all(x==0 for x in r['sh']),r)
        r=await E("()=>{const o=tdHeal('wonder',40,1,['behemoth'],2.5);return o}")
        chk('a boss takes half a heal',0<r['tg'][0]<=0.04+1e-9,r)
        r=await E("()=>[30,45,60,90].map(w=>{const R=tdNew('wonder',w);const k=rpHealK(R);rpLeave();return +k.toFixed(4)})")
        chk('in the endless Wonderland the pulse fades after wave 30: 8% -> 4.5% at wave 60 and later',r[0]==0.08 and 0.045<r[1]<0.08 and r[2]==0.045 and r[3]==0.045,r)
        r=await E("()=>[60,90,120].map(w=>rpWave(RP_MAP('wonder'),w).filter(g=>g.id==='behemoth').reduce((a,g)=>a+g.n,0))")
        chk('at most two Behemoths per Wonderland boss wave (it was 3 at wave 60, 4 at 90)',r==[2,2,2],r)
        r=await E("()=>{const m=RP_MAP('wonder');return [rpHpK(m,50,false),rpHpK(m,80,false),rpHpK(m,50,true),rpHpK(m,80,true),rpHpK(m,15,false),rpHpK(RP_MAP('ember'),10,false)-rpHpK(m,10,false)].map(x=>+x.toFixed(2))}")
        chk('past wave 50 hit points climb more gently (ordinary and boss), and nothing changes up to wave 15',r[1]/r[0]<3.2 and r[3]/r[2]<2.9 and r[5]==0 and r[1]>r[0] and r[3]>r[2],r)
        r=await E("()=>{const m=RP_MAP('ember');const W=rpWave(m,m.waves);const R=tdNew('frost',10);const k=rpHealK(R);rpLeave();return [W.filter(g=>g.id==='behemoth').length,k]}")
        chk('the story maps keep their waves and healing',r==[1,0.08],r)
        chk('no page errors',not er,er)
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
