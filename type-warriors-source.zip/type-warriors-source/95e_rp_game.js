/* ===== RUNESTONE RAMPARTS (8.8b): the run =====
   A canvas mode like the caravan: S.mode='ramparts', S.rp=1; update/draw are wrapped to run rpUpdate/rpDraw. The map fills the whole
   1600x900 stage; the DOM HUD (95f) floats over it. Time runs at R.spd (1x, 2x or 3x) in fixed sub-steps. No typing: strategy only.
   States: R.wst 'build' (between waves; a countdown after wave 1), 'run' (spawning and fighting), 'done' (finished).
   Towers stand on pads (R.pads[i].tw); a new tower plays its build animation (tw.build 0..1) before it fires, an upgrade plays tw.upK.
   Foes walk their road (e.pi) by distance s; ice speeds them up, vents scorch them. Abilities recharge on cooldowns (R.abCd).
   Supply builds towers inside the run; coins (R.coins) are paid for every kill and wave, plus a win bonus, with no ceiling. */
let RPX=null;
/* 8.9b: no typing here, so the hidden typing box never takes focus during a Runestone Tower Defense run (on touch screens and in
   embedded pages focusing it can pop a keyboard or make the browser re-fit and zoom the page), and the stage never scrolls */
try{const f0=inp.focus;inp.focus=function(){if(typeof S!=='undefined'&&S&&S.rp&&RPX)return;return f0.apply(this,arguments)}}catch(e){}
try{wrap.addEventListener('scroll',()=>{if(S&&S.rp&&(wrap.scrollLeft||wrap.scrollTop)){wrap.scrollLeft=0;wrap.scrollTop=0}})}catch(e){}
try{RPTW.brazier.n='Ember Blazer';if(!RPTW.prism)RPTW.prism={n:'Celestial Prism',role:'Radiant beam',col:'#ffe08a'}}catch(e){}
const rpRM=()=>{try{return ccReduce()}catch(e){return false}};
const rpClamp=(v,a,b)=>v<a?a:v>b?b:v;
const rpEase=k=>{k=rpClamp(k,0,1);return k*k*(3-2*k)};
const rpOver=k=>{const c1=1.70158,c3=c1+1,x=rpClamp(k,0,1)-1;return 1+c3*x*x*x+c1*x*x};
function rpStart(id){const map=RP_MAP(id);try{if(ST.res==='auto')applyLayout()}catch(e){}
 reset();S.mode='ramparts';S.view='ramparts';S.rp=1;S.camp=0;
 const G=rpGeo(map),bake=rpBake(map);
 RPX={map,G,bake,tk:((RPX&&RPX.tk)||0)+1,t:0,time:0,spd:1,pause:false,over:false,result:null,rm:rpRM(),
  pads:G.pads.map((p,i)=>({x:p.x,y:p.y,i,tw:null})),foes:[],shots:[],arcs:[],rings:[],burns:[],fields:[],fx:[],tx:[],uid:0,
  wave:0,wst:'build',wt:0,cd:0,q:[],hp:RPT.HP,supply:map.start,coins:0,cKill:0,cWave:0,
  abCd:{over:0,slow:0,repair:0},abil:{over:0,slow:0,repair:0},
  sel:null,selPad:null,place:null,ghost:null,aim:null,hover:null,mx:-1,my:-1,shake:0,hitFl:0,castHit:0,banner:null,toast:null,
  kills:0,leaked:0,built:0,spent:0,ups:0,free:false,fpWaves:0,seenFoe:{},boss:null,spawnI:0,
  vents:(map.vents||[]).map((v,i)=>({x:v[0],y:v[1],t:RPT.VENT_T*(.45+i*.22),k:-1,hit:0}))};
 hide();try{ensureAudio()}catch(e){}try{inp.blur()}catch(e){}try{rpMobPrebake(null,map.pal)}catch(e){}
 rpToast(`${map.n} · build towers on the glowing pads, then start wave 1`,4,'#fff8e8');try{wrSfx('start')}catch(e){}
 if(typeof rpHudOn==='function')rpHudOn();
 if(typeof rpTut==='function')setTimeout(()=>{if(RPX&&RPX.wave===0)rpTut(RPP().tut.build?(map.id!=='moss'?'twist':null):'build')},700)}
function rpLeave(){const R=RPX;if(R&&!R.over){try{RPP().runs++;save()}catch(e){}}RPX=null;S.rp=0;if(S.mode==='ramparts'||S.mode==='over')S.mode='title';
 try{if(typeof rpHudOff==='function')rpHudOff()}catch(e){}try{pb.style.display='none';dkCorner()}catch(e){}}
function rpQuit(){rpLeave();if(typeof rampartsMenu==='function')rampartsMenu(title);else title()}
function rpRestart(){const id=RPX?RPX.map.id:'moss';rpLeave();rpStart(id)}
{const t0=title;title=function(){if(S.rp||RPX)rpLeave();return t0.apply(this,arguments)}}
{const u0=update;update=function(dt){if(S.rp&&RPX)return rpUpdate(dt);return u0.apply(this,arguments)}}
{const d0=draw;draw=function(){if(S.rp&&RPX)return rpDraw();return d0.apply(this,arguments)}}
/* no typing in this mode: letters do nothing (the keydown handler below owns the keys) */
{const k0=key;key=function(c){if(S.rp&&RPX)return;return k0.apply(this,arguments)}}
/* ---------- helpers ---------- */
function rpToast(txt,dur,c){if(RPX)RPX.toast={txt,t:dur||2,d:dur||2,c:c||'#ffd45a'}}
function rpText(x,y,s,c,sz){const R=RPX;if(!R)return;if(R.tx.length>60)R.tx.shift();R.tx.push({x,y,s,c,sz:sz||20,t:0,d:1})}
function rpRing(x,y,c,max,w){const R=RPX;if(R.rings.length>40)R.rings.shift();R.rings.push({x,y,t:0,d:.5,max:max||80,c:c||'#ffd45a',w:w||4})}
function rpSfx(k,v){try{switch(k){
 case 'build':beep(330,.07,'triangle',.5);setTimeout(()=>beep(495,.09,'triangle',.5),70);break;
 case 'thud':beep(110,.08,'triangle',.5);break;
 case 'done':beep(660,.06,'triangle',.45);setTimeout(()=>beep(990,.1,'triangle',.45),60);break;
 case 'up':beep(523,.07,'triangle',.5);setTimeout(()=>beep(659,.07,'triangle',.5),70);setTimeout(()=>beep(880,.12,'triangle',.5),140);break;
 case 'sell':beep(880,.05,'triangle',.4);setTimeout(()=>beep(660,.07,'triangle',.4),60);break;
 case 'bolt':beep(1500+Math.random()*200,.025,'square',.06);break;
 case 'boom':beep(90+Math.random()*30,.12,'sawtooth',.18);break;
 case 'zap':beep(1900+Math.random()*400,.04,'sawtooth',.07);break;
 case 'frost':beep(2200,.05,'sine',.06);break;
 case 'vent':beep(70,.3,'sawtooth',.3);break;
 case 'leak':beep(80,.25,'sawtooth',.7);break;
 case 'key':try{wrSfx('key',v)}catch(e){}break;
 case 'ability':beep(392,.08,'triangle',.6);setTimeout(()=>beep(784,.2,'triangle',.6),70);setTimeout(()=>beep(1568,.3,'sine',.4),150);break;
 case 'ready':beep(1046,.05,'sine',.25);setTimeout(()=>beep(1318,.08,'sine',.25),60);break;
 case 'no':beep(150,.06,'triangle',.4);break;
 case 'wave':beep(440,.1,'triangle',.5);setTimeout(()=>beep(660,.14,'triangle',.5),120);break;
 case 'clear':beep(660,.08,'triangle',.5);setTimeout(()=>beep(880,.1,'triangle',.5),90);setTimeout(()=>beep(1320,.18,'triangle',.45),180);break;
 case 'boss':try{jingle('boss')}catch(e){}break;
 case 'win':try{jingle('win')}catch(e){}break;
 case 'lose':try{jingle('lose')}catch(e){}break}}catch(e){}}
/* a monster's ground position, cached until it moves (towers query it many times per step) */
function rpPos(R,e){if(e._s===e.s&&e._q)return e._q;const p=rpAt(R.G,e.s,e.pi),o=e.off||0;e._s=e.s;return e._q={x:p.x-Math.sin(p.a)*o,y:p.y+Math.cos(p.a)*o,a:p.a,ice:p.ice}}
const rpLen=(R,e)=>(R.G.paths[e.pi||0]||R.G.paths[0]).len;
const rpCastC=R=>{const c=R.bake.cast;return{x:c.x+c.w*.5,y:c.y+c.h*.42}};
const rpName=(id,R)=>{try{return rpMobName(id,R?R.map.pal:'moss')}catch(e){return RPMOB[id]?RPMOB[id].n:id}};
/* ---------- building ---------- */
const rpCost=(type,tier)=>RP_TW[type].cost[tier-1];
function rpBuild(pad,type){const R=RPX;if(!R||R.over||!pad||pad.tw||R.wst==='done')return false;const c=rpCost(type,1);
 if(R.supply<c){rpSfx('no');rpToast(`The ${RPTW[type].n} needs ${c} supply (you have ${Math.floor(R.supply)})`,1.6,'#ff8a9a');return false}
 R.supply-=c;R.spent+=c;R.built++;pad.tw={type,tier:1,skin:rpSkinOf(type),x:pad.x,y:pad.y,pad,cd:.3,aim:0,fire:0,over:0,kills:0,dmg:0,prio:'first',spent:c,ph:Math.random()*10,build:0,upK:1,from:0};
 try{rpTowerWarm(type,1,pad.tw.skin)}catch(e){}
 rpSfx('build');R.sel=null;R.selPad=null;R.place=null;R.ghost=null;
 if(typeof rpTut==='function'&&R.built===1)setTimeout(()=>{if(RPX===R&&R.wave===0)rpTut('wave')},900);
 return true}
function rpUpgrade(tw){const R=RPX;if(!R||!tw||tw.tier>=RP_MAXT(R.map)||R.wst==='done')return false;const c=rpCost(tw.type,tw.tier+1);
 if(R.supply<c){rpSfx('no');rpToast(`Upgrade needs ${c} supply (you have ${Math.floor(R.supply)})`,1.6,'#ff8a9a');return false}
 R.supply-=c;R.spent+=c;R.ups++;tw.spent+=c;tw.from=tw.tier;tw.tier++;tw.upK=0;tw.upD=tw.tier>=4?RPT.ASC_ANIM:RPT.UP_ANIM;tw.build=1;tw.beams=null;try{rpTowerWarm(tw.type,tw.tier,tw.skin)}catch(e){}
 rpRing(tw.x,tw.y-40,'#ffd45a',120,6);try{ptBurst(R.fx,tw.x,tw.y-50,22,['#ffd45a','#fff4c8',RPTW[tw.type].col],{v:260,s:4.5,k:'star'})}catch(e){}
 rpText(tw.x,tw.y-130,`Tier ${tw.tier}!`,'#ffd45a',26);rpSfx('up');if(tw.tier>=4)rpAscend(R,tw);return true}
/* tiers 4 and 5 (endless only): a grand moment, and a record that the hub shows as the Ascended collection */
function rpAscend(R,tw){const r=RPP(),first=(r.asc[tw.type]||0)<tw.tier;if(first){r.asc[tw.type]=tw.tier;try{save()}catch(e){}}R.ascN=(R.ascN||0)+1;
 rpRing(tw.x,tw.y,tw.tier>=5?'#fff6d8':'#c89aff',220,8);R.shake=Math.max(R.shake,6);try{ptBurst(R.fx,tw.x,tw.y-60,40,tw.tier>=5?['#ffffff','#fff2b0','#ffd45a','#9fe8ff','#ffb8f0']:['#c89aff','#ffd45a','#ffffff'],{v:360,s:5,k:'star'})}catch(e){}
 rpText(tw.x,tw.y-158,tw.tier>=5?'CELESTIAL!':'MYTHIC!',tw.tier>=5?'#fff6c0':'#d8b8ff',34);rpSfx('ability');
 if(first)R.banner={txt:'Ascended!',sub:`${RPTW[tw.type].n} reached tier ${tw.tier}${tw.tier>=5?' - Celestial':' - Mythic'}`,t:0,d:2.2,asc:1}}
function rpSell(tw){const R=RPX;if(!R||!tw)return;const v=Math.round(tw.spent*RPT.SELL);R.supply+=v;tw.pad.tw=null;if(R.sel===tw)R.sel=null;
 rpText(tw.x,tw.y-60,`+${v} supply`,'#ffd45a',22);try{ptBurst(R.fx,tw.x,tw.y-20,16,['#8a7a6a','#c8b89a'],{v:180,s:4,up:1,g:400})}catch(e){}rpSfx('sell')}
/* placement: pick a tower type, the ghost snaps to the nearest free pad under the pointer, one click builds */
function rpPlace(type){const R=RPX;if(!R||R.over||R.wst==='done')return;if(R.place===type){R.place=null;R.ghost=null;return}
 if(R.supply<rpCost(type,1)){rpSfx('no');rpToast(`The ${RPTW[type].n} needs ${rpCost(type,1)} supply`,1.4,'#ff8a9a');return}
 if(R.selPad&&!R.selPad.tw){rpBuild(R.selPad,type);return}
 R.place=type;R.sel=null;R.selPad=null;R.aim=null;R.ghost=R.my>=0?rpSnap(R,R.mx,R.my):null;rpSfx('key',2)}
function rpSnap(R,x,y){let best=null,bd=86*86;for(const p of R.pads){if(p.tw)continue;const dx=x-p.x,dy=(y-p.y+10)*1.25,d=dx*dx+dy*dy;if(d<bd){bd=d;best=p}}return best}
/* what is under the pointer: a tower (its body) or an empty pad (its stone top); the nearest wins */
function rpPick(R,x,y){let best=null,bd=1;for(const p of R.pads){const dx=x-p.x,dy=y-p.y;let d;
  if(p.tw){if(Math.abs(dx)>48||dy<-128||dy>30)continue;d=(dx/48)**2+((dy+48)/80)**2}else{d=(dx/54)**2+(dy/34)**2}
  if(d<bd){bd=d;best=p}}return best}
/* ---------- waves ---------- */
function rpWaveStart(){const R=RPX;if(!R||R.over||R.wst!=='build')return;
 if(R.wave>0&&R.cd>0){const b=Math.ceil(R.cd)*RPT.EARLY;if(b>0){R.supply+=b;rpText(800,300,`Early call +${b} supply`,'#ffd45a',26)}}
 R.wave++;R.wst='run';R.wt=0;R.q=[];const W=rpWave(R.map,R.wave);
 for(const g of W)for(let i=0;i<g.n;i++)R.q.push({id:g.id,at:g.at+i*g.gap});R.q.sort((a,b)=>a.at-b.at);
 const boss=W.some(g=>g.id==='behemoth');R.banner={txt:R.free?`Freeplay wave ${R.wave-R.map.waves}`:boss?`${rpName('behemoth',R)}!`:`Wave ${R.wave}`,sub:boss?'The boss is coming. Slow it, focus it, keep Repair ready.':rpWaveSub(W,R),t:0,d:2.2,boss};
 rpSfx(boss?'boss':'wave');
 const nw=W.map(g=>g.id).filter((id,i,a)=>a.indexOf(id)===i&&!R.seenFoe[id]);for(const id of nw)R.seenFoe[id]=1;
 const card=nw.filter(id=>!RPP().hint[R.map.pal+':'+id]);if(card.length&&typeof rpHudFoeCard==='function')rpHudFoeCard(card[0]);
 if(R.wave===2&&typeof rpTut==='function')rpTut('abil')}
function rpWaveSub(W,R){const n=W.reduce((a,g)=>a+g.n,0),ids=[...new Set(W.map(g=>g.id))];return `${n} monsters · ${ids.map(i=>rpName(i,R)).join(', ')}`}
function rpSpawn(id,pi){const R=RPX,F=RP_FOE[id];if(!F)return null;const k0=rpHpK(R.map,R.wave,F.boss),k=F.boss?1+(k0-1)*.5:k0,hp=Math.round(F.hp*k*(R.free?1+.05*(R.wave-R.map.waves):1));
 const np=R.G.paths.length;if(pi==null)pi=F.boss?0:(R.spawnI++)%np;
 const e={id,uid:++R.uid,pi,s:-30-Math.random()*20,hp,mx:hp,sp:F.sp*R.map.spk*(.94+Math.random()*.12),air:!!F.air,armor:F.armor||0,bounty:Math.round(F.bounty*rpBountyK(R.wave)),dmg:F.dmg,
  coin:F.coin*R.map.coinK,ph:Math.random(),fl:0,slowT:0,slowK:0,stun:0,dead:0,dk:0,off:(Math.random()-.5)*(F.boss?6:22),heal:F.heal?F.healT:0,boss:!!F.boss,ice:0,inField:0};
 if(e.boss){R.boss=e}R.foes.push(e);return e}
function rpWaveDone(){const R=RPX;R.wst='build';const b=rpWaveBonus(R.wave),c=rpWaveCoins(R.map,R.wave);R.supply+=b;R.coins+=c;R.cWave+=c;R.cd=RPT.BUILD_T;
 if(R.free)R.fpWaves++;
 rpText(800,280,`${R.free?'Freeplay wave':'Wave'} ${R.free?R.wave-R.map.waves:R.wave} cleared · +${b} supply · +${c} coins`,'#ffd45a',26);
 rpSfx('clear');if(R.map.endless){if(R.wave===15)R.banner={txt:'Wave 15 held',sub:'From here on every wave is harder than the last',t:0,d:2.6};return}
 if(!R.free&&R.wave>=R.map.waves){rpVictory();return}
 if(typeof rpTut==='function'&&R.wave===1)setTimeout(()=>{if(RPX===R&&R.wst==='build')rpTut('upgrade')},600)}
const rpStarsFor=hp=>hp>=18?3:hp>=10?2:1;
function rpVictory(){const R=RPX;if(R.wst==='done')return;R.wst='done';R.won=true;R.banner={txt:'Victory!',sub:'The castle stands',t:0,d:2.6,win:1};rpSfx('win');
 try{for(let i=0;i<5;i++)setTimeout(()=>{if(RPX===R)ptBurst(R.fx,300+Math.random()*1000,200+Math.random()*350,30,['#ffd45a','#fff4c8','#5ab8ff','#ff8a3a'],{v:340,s:5,k:'star'})},i*220)}catch(e){}
 R.winHp=R.hp;R.place=null;R.sel=null;R.selPad=null;R.aim=null;setTimeout(()=>{if(RPX===R&&!R.over){if(typeof rpHudVictory==='function')rpHudVictory();else rpFinish(true)}},2500)}
function rpDefeat(){const R=RPX;if(R.wst==='done')return;R.heldAt=Math.max(0,R.wave-(R.wst==='build'?0:1));R.wst='done';R.won=R.free;R.banner={txt:'The castle has fallen',sub:R.map.endless?`You held ${Math.max(0,R.wave-1)} waves`:R.free?`Freeplay ends after ${R.fpWaves} waves`:`Wave ${R.wave} of ${R.map.waves}`,t:0,d:2.4,lose:1};
 R.place=null;R.sel=null;R.selPad=null;R.aim=null;rpSfx('lose');setTimeout(()=>{if(RPX===R&&!R.over)rpFinish(R.free)},2400)}
/* ---------- abilities: each recharges on its own cooldown ---------- */
function rpAbility(k,arg){const R=RPX;if(!R||R.over||R.pause||R.wst==='done')return false;const A=RPT.AB[k];if(!A)return false;
 if(R.abCd[k]>0){rpSfx('no');rpToast(`${A.n} recharges in ${Math.ceil(R.abCd[k])} s`,1.4,'#9fd0ff');return false}
 if(k==='repair'){if(R.hp>=RPT.HP){rpSfx('no');rpToast('The castle is at full health',1.4,'#9fd0ff');return false}
  const h=Math.min(A.heal,RPT.HP-R.hp);R.hp+=h;R.abCd.repair=A.cd;R.abil.repair++;const p=rpCastC(R);rpRing(p.x,p.y,'#7dffb0',220,7);rpText(p.x,p.y-60,`+${h} health`,'#7dffb0',30);
  try{ptBurst(R.fx,p.x,p.y,26,['#7dffb0','#ffffff','#ffd45a'],{v:260,s:4.5,k:'star'})}catch(e){}rpSfx('ability');return true}
 if(k==='over'){let tw=arg&&arg.type?arg:arg===true?rpBusiest():null;
  if(!tw){if(!R.pads.some(p=>p.tw)){rpSfx('no');rpToast('Build a tower first',1.4,'#ff8a9a');return false}R.aim='over';R.place=null;R.ghost=null;R.selPad=null;
   rpToast('Click a tower to Overcharge it (press 1 again for the busiest)',2.6,'#ffd45a');return false}
  R.aim=null;tw.over=A.dur;R.abCd.over=A.cd;R.abil.over++;rpRing(tw.x,tw.y-40,'#ffd45a',140,7);rpText(tw.x,tw.y-130,'OVERCHARGE!','#ffd45a',30);rpSfx('ability');return true}
 if(k==='slow'){let pt=arg&&arg.x!==undefined?arg:null;
  if(!pt&&arg===true){const L=R.foes.filter(e=>!e.dead&&!e.air&&e.s>0).sort((a,b)=>b.s/rpLen(R,b)-a.s/rpLen(R,a))[0];if(L){const p=rpAt(R.G,Math.min(rpLen(R,L)-40,L.s+60),L.pi);pt={x:p.x,y:p.y}}
   else{rpSfx('no');rpToast('No monsters on the road yet',1.4,'#9fd0ff');R.aim=null;return false}}
  if(!pt){R.aim='slow';R.place=null;R.ghost=null;R.selPad=null;R.sel=null;rpToast('Click the road to place the Slow Field (press 2 again to drop it ahead of the leader)',2.8,'#9fe8ff');return false}
  R.aim=null;R.fields.push({x:pt.x,y:pt.y,r:A.r,t:0,d:A.dur});R.abCd.slow=A.cd;R.abil.slow++;rpRing(pt.x,pt.y,'#9fe8ff',A.r*1.3,6);rpSfx('ability');return true}
 return false}
/* a button or hotkey press: Overcharge uses the selected tower, otherwise asks for one; pressing again while aiming auto-picks */
function rpAbPress(k){const R=RPX;if(!R)return;if(R.abCd[k]>0||k==='repair')return rpAbility(k,true);
 if(k==='over')return rpAbility('over',R.aim==='over'?true:R.sel&&R.sel.build>=1?R.sel:undefined);
 if(k==='slow')return rpAbility('slow',R.aim==='slow'?true:undefined)}
function rpBusiest(){const R=RPX;let best=null,bs=-1;for(const p of R.pads){const tw=p.tw;if(!tw||tw.build<1)continue;const rg=RP_TW[tw.type].range[tw.tier-1];let n=0;for(const e of R.foes)if(!e.dead&&e.s>0){const q=rpPos(R,e);if(rpD2(q.x,q.y,tw.x,tw.y)<rg*rg)n++}
  const T=RP_TW[tw.type],j=tw.tier-1,sc=n*10+tw.tier*3+(T.dps?T.dps[j]*T.beams[j]:T.dmg[j]/T.cd[j])*.01;if(sc>bs){bs=sc;best=tw}}return best}
/* ---------- combat ---------- */
function rpHurt(e,dmg,ap,src){if(e.dead)return;const arm=Math.max(0,e.armor-(ap||0));const d=Math.max(dmg*.3,dmg-arm);e.hp-=d;e.fl=.1;if(src){src.dmg+=d}
 if(e.hp<=0)rpKillFoe(e,src)}
function rpKillFoe(e,src){const R=RPX;if(e.dead)return;e.dead=1;e.dk=0;R.kills++;if(src&&src.kills!==undefined)src.kills++;R.supply+=e.bounty;R.coins+=e.coin;R.cKill+=e.coin;const p=rpPos(R,e);
 rpText(p.x,p.y-(e.air?70:40),`+${e.bounty}`,'#ffd45a',e.boss?34:18);
 try{ptBurst(R.fx,p.x,p.y-(e.air?40:20),e.boss?60:10,R.map.pal==='frost'?['#d8f4ff','#ffffff','#7ac8f0']:R.map.pal==='ember'?['#ff8a2a','#ffd27a','#3a1a14']:e.id==='ooze'||e.id==='oozelet'?['#7affc8','#3ad89a']:['#ffd45a','#ffffff'],{v:e.boss?420:200,s:e.boss?6:3.5})}catch(x){}
 const F=RP_FOE[e.id];if(F.split){for(let i=0;i<F.splitN;i++){const c=rpSpawn(F.split,e.pi);if(c){c.s=e.s-8-i*14;c.off=e.off+(i?10:-10);c.hp=c.mx=Math.round(RP_FOE[F.split].hp*rpHpK(R.map,R.wave));c.ph=Math.random()}}}
 if(e.boss){R.shake=Math.max(R.shake,18);rpRing(p.x,p.y-60,'#ffb04a',260,9);rpText(800,300,`${rpName('behemoth',R)} falls!`,'#ffd45a',40);R.boss=null}
 if(R.kills===1&&typeof rpTut==='function')rpTut('coins')}
const rpD2=(ax,ay,bx,by)=>{const dy=(ay-by)/RPFX.sq;return(ax-bx)*(ax-bx)+dy*dy};
function rpTarget(R,tw,rg,airOk,groundOk,prio,preferAir){let best=null,bv=-1e9;const r2=rg*rg;
 for(const e of R.foes){if(e.dead||e.s<0)continue;if(e.air?!airOk:!groundOk)continue;const p=rpPos(R,e),d2=rpD2(p.x,p.y,tw.x,tw.y);if(d2>r2)continue;
  let v=prio==='strong'?e.hp:prio==='close'?-d2:e.s/rpLen(R,e);if(preferAir&&e.air)v+=1e7;if(v>bv){bv=v;best=e}}return best}
function rpFire(R,tw,dt){const T=RP_TW[tw.type],i=tw.tier-1,rg=T.range[i];tw.over=Math.max(0,tw.over-dt);if(tw.type==='prism')return rpPrismFire(R,tw,T,i,rg,dt);tw.fire=Math.max(0,tw.fire-dt*3);
 tw.cd-=dt*(tw.over>0?RPT.AB.over.k:1);if(tw.cd>0)return;
 const dmgK=tw.over>0?1.15:1;
 if(tw.type==='frost'){let n=0;for(const e of R.foes){if(e.dead||(e.air&&i<3)||e.s<0)continue;const p=rpPos(R,e);if(rpD2(p.x,p.y,tw.x,tw.y)>rg*rg)continue;n++;
   const chill=e.slowT>0;e.slowK=Math.max(e.slowK,T.slow[i]);e.slowT=Math.max(e.slowT,T.slowT[i]);rpHurt(e,T.dmg[i]*dmgK*(i>=2&&chill?2:1),0,tw);if(i>=4&&!e.boss)e.stun=Math.max(e.stun,.25)}
  if(n){tw.cd=T.cd[i];tw.fire=1;R.rings.push({x:tw.x,y:tw.y,t:0,d:.55,max:rg,c:'#9fe8ff',w:3,frost:1,skin:tw.skin,tier:tw.tier});if(Math.random()<.5)rpSfx('frost')}else tw.cd=.12;return}
 const e=rpTarget(R,tw,rg,!!T.air,!!T.ground,tw.prio,tw.type==='bell');if(!e){tw.cd=.1;return}
 const p=rpPos(R,e),ty=p.y-(e.air?40:18);tw.aim=Math.atan2(ty-(tw.y-40),p.x-tw.x);tw.cd=T.cd[i];tw.fire=1;
 if(tw.type==='ballista'){R.shots.push({k:'bolt',x:tw.x+Math.cos(tw.aim)*30,y:tw.y-46+Math.sin(tw.aim)*30,e,sp:1000,dmg:T.dmg[i]*dmgK,ap:T.ap[i],pierce:T.pierce[i],tw,skin:tw.skin,tier:tw.tier,life:1.2,a:tw.aim});rpSfx('bolt')}
 else if(tw.type==='brazier'){const lead=Math.min(rpLen(R,e),e.s+e.sp*(e.slowT>0?1-e.slowK:1)*.5),lp=rpAt(R.G,lead,e.pi);
  R.shots.push({k:'ember',x0:tw.x,y0:tw.y-60,x1:lp.x,y1:lp.y,t:0,d:.5,dmg:T.dmg[i]*dmgK,r:T.splash[i],burn:T.burn[i],tw,skin:tw.skin,tier:tw.tier})}
 else if(tw.type==='bell'){const hit=[e];let cur=e;for(let k=1;k<T.chain[i];k++){let nb=null,nd=130*130;const cp=rpPos(R,cur);for(const f of R.foes){if(f.dead||hit.includes(f)||f.s<0)continue;const q=rpPos(R,f),d2=(q.x-cp.x)**2+(q.y-cp.y)**2;if(d2<nd){nd=d2;nb=f}}if(!nb)break;hit.push(nb);cur=nb}
  const pts=[{x:tw.x,y:tw.y-92}];for(const f of hit){const q=rpPos(R,f);pts.push({x:q.x,y:q.y-(f.air?40:20)});rpHurt(f,T.dmg[i]*dmgK*(f.air?T.airK:1),2,tw);if(i>=2&&f.air)f.stun=.6}
  R.arcs.push({pts,t:0,d:.2,skin:tw.skin,tier:tw.tier});rpSfx('zap')}}
/* the Celestial Prism: up to T.beams continuous beams; a beam that stays on one target ramps from 1x to (1+rampK)x over T.ramp seconds;
   armor softens a beam by a fraction (1 - armor/30, at least 30%) unless the tier melts it; tier 5 adds a supernova every T.novaT seconds */
function rpPrismFire(R,tw,T,i,rg,dt){const nb=T.beams[i],r2=rg*rg,over=tw.over>0?1.8:1;tw.beams=tw.beams||[];
 tw.beams=tw.beams.filter(b=>{const e=b.e;if(e.dead||e.s<0)return false;const p=rpPos(R,e);return rpD2(p.x,p.y,tw.x,tw.y)<=r2});
 if(tw.beams.length<nb){const used=new Set(tw.beams.map(b=>b.e)),c=[];for(const e of R.foes){if(e.dead||e.s<0||used.has(e))continue;const p=rpPos(R,e),d2=rpD2(p.x,p.y,tw.x,tw.y);if(d2>r2)continue;
   c.push([tw.prio==='strong'?e.hp:tw.prio==='close'?-d2:e.s/rpLen(R,e),e])}c.sort((a,b)=>b[0]-a[0]);for(let k=0;k<c.length&&tw.beams.length<nb;k++)tw.beams.push({e:c[k][1],ramp:0})}
 let mx=0;for(const b of tw.beams){b.ramp=Math.min(1,b.ramp+dt/T.ramp);mx=Math.max(mx,b.ramp);const e=b.e,arm=Math.max(0,e.armor-T.ap[i]),f=Math.max(.3,1-arm/30);
  const fl=e.fl;rpHurt(e,T.dps[i]*(1+T.rampK*b.ramp)*over*f*dt,99,tw);e.fl=fl;e.beamT=.1}/* a beam burns steadily: no hit flash every tick */
 tw.charge=mx;tw.fire=tw.beams.length?1:Math.max(0,(tw.fire||0)-dt*3);if(tw.beams.length){const e=tw.beams[0].e,p=rpPos(R,e);tw.aim=Math.atan2(p.y-(e.air?40:18)-(tw.y-60),p.x-tw.x);if(!R.rm&&Math.random()<dt*2)rpSfx('zap')}
 if(T.nova[i]){tw.nova=(tw.nova==null?T.novaT:tw.nova)-dt;if(tw.nova<=0&&tw.beams.length){tw.nova=T.novaT;const nr=T.novaR;
   for(const e of R.foes){if(e.dead||e.s<0)continue;const p=rpPos(R,e);if(rpD2(p.x,p.y,tw.x,tw.y)<nr*nr)rpHurt(e,T.nova[i]*over,99,tw)}
   R.rings.push({x:tw.x,y:tw.y,t:0,d:.8,max:nr,c:'#fff6d8',w:6,nova:1,tier:tw.tier});R.shake=Math.max(R.shake,5);rpSfx('boom')}}}
function rpShots(R,dt){for(const s of R.shots){if(s.k==='bolt'){s.life-=dt;let tx,ty;if(!s.e.dead){const p=rpPos(R,s.e);tx=p.x;ty=p.y-(s.e.air?40:18);s.lx=tx;s.ly=ty}else{tx=s.lx;ty=s.ly}
   if(tx===undefined){s.done=1;continue}const dx=tx-s.x,dy=ty-s.y,d=Math.hypot(dx,dy),st=s.sp*dt;s.a=Math.atan2(dy,dx);
   if(d<=st+6||s.life<=0){s.done=1;if(!s.e.dead){rpHurt(s.e,s.dmg,s.ap,s.tw);try{ptBurst(R.fx,tx,ty,5,['#9fdcff','#ffffff'],{v:160,s:3})}catch(e){}
     if(s.pierce){const near=[];for(const f of R.foes){if(f.dead||f===s.e)continue;const q=rpPos(R,f),d2=(q.x-tx)**2+(q.y-ty)**2;if(d2<110*110)near.push([d2,f])}near.sort((a,b)=>a[0]-b[0]);for(let k=0;k<Math.min(s.pierce,near.length);k++)rpHurt(near[k][1],s.dmg*.6,s.ap,s.tw)}}}
   else{s.x+=dx/d*st;s.y+=dy/d*st}}
  else if(s.k==='ember'){s.t+=dt;if(s.t>=s.d){s.done=1;for(const e of R.foes){if(e.dead||e.air)continue;const p=rpPos(R,e);if(rpD2(p.x,p.y,s.x1,s.y1)<=s.r*s.r)rpHurt(e,s.dmg,0,s.tw)}
    R.rings.push({x:s.x1,y:s.y1,t:0,d:.45,max:s.r,c:'#ff8a3a',w:4,boom:1,skin:s.skin,tier:s.tier});if(s.burn)R.burns.push({x:s.x1,y:s.y1,r:s.r*.8,t:0,d:2.6,dps:s.burn,tw:s.tw});
    try{ptBurst(R.fx,s.x1,s.y1-6,8,['#ffb04a','#ff6a1a','#ffd45a'],{v:200,s:4,up:1,g:300})}catch(e){}if(Math.random()<.6)rpSfx('boom')}}}
 R.shots=R.shots.filter(s=>!s.done)}
/* ---------- update ---------- */
function rpUpdate(dt){const R=RPX;if(!R)return;try{if(typeof rpHudTick==='function')rpHudTick()}catch(e){}if(R.pause||R.hold)return;dt=Math.min(dt,.05);S.t+=dt;R.t+=dt;
 const n=R.wave===0?1:R.spd;for(let k=0;k<n;k++)rpStep(R,dt);
 /* build and upgrade animations run on real time (not game speed), so they read the same at 1x and 3x */
 for(const p of R.pads){const tw=p.tw;if(!tw)continue;if(tw.build<1){const b0=tw.build;tw.build=Math.min(1,tw.build+dt/RPT.BUILD_ANIM);if(b0<.45&&tw.build>=.45)rpSfx('thud');
   if(tw.build>=1){rpSfx('done');rpRing(tw.x,tw.y,'#ffd45a',96,5);try{ptBurst(R.fx,tw.x,tw.y-10,16,['#c8b89a','#8a7a6a','#ffd45a'],{v:220,s:4,up:1,g:420})}catch(e){}}}
  if(tw.upK<1)tw.upK=Math.min(1,tw.upK+dt/(tw.upD||RPT.UP_ANIM))}
 R.fdt=(R.fdt||dt)*.97+dt*.03;if(!R.lite&&(R.fdt>.03||(()=>{try{return PFM()==='low'}catch(e){return false}})()))R.lite=1;
 if(R.fx.length>(R.lite?120:420))R.fx.splice(0,R.fx.length-(R.lite?120:420));
 R.shake=Math.max(0,R.shake-dt*40);R.hitFl=Math.max(0,R.hitFl-dt*2);R.castHit=Math.max(0,R.castHit-dt*2.2);
 for(const t of R.tx)t.t+=dt;R.tx=R.tx.filter(t=>t.t<t.d);if(R.toast){R.toast.t-=dt;if(R.toast.t<=0)R.toast=null}if(R.banner){R.banner.t+=dt;if(R.banner.t>R.banner.d)R.banner=null}}
function rpStep(R,dt){R.time+=dt;
 if(R.wst==='build'&&R.wave>0&&!R.over){R.cd-=dt;if(R.cd<=0)rpWaveStart()}
 if(R.wst==='run'){R.wt+=dt;while(R.q.length&&R.q[0].at<=R.wt)rpSpawn(R.q.shift().id)}
 if(R.wst!=='done'&&R.wave>0)for(const k in R.abCd)if(R.abCd[k]>0){R.abCd[k]=Math.max(0,R.abCd[k]-dt);if(R.abCd[k]===0)rpSfx('ready')}
 for(const f of R.fields)f.t+=dt;R.fields=R.fields.filter(f=>f.t<f.d);
 for(const b of R.burns){b.t+=dt;for(const e of R.foes){if(e.dead||e.air)continue;const p=rpPos(R,e);if(rpD2(p.x,p.y,b.x,b.y)<b.r*b.r)rpHurt(e,b.dps*dt,99,b.tw)}}R.burns=R.burns.filter(b=>b.t<b.d);
 /* lava vents (Ember Crown): erupt every few seconds while a wave runs and scorch the ground foes nearby */
 if(R.wst==='run')for(const v of R.vents){if(v.k>=0){v.k+=dt/1.3;if(!v.hit&&v.k>=.15){v.hit=1;R.shake=Math.max(R.shake,4);if(!R.rm)rpSfx('vent');
     for(const e of R.foes){if(e.dead||e.air||e.s<0)continue;const p=rpPos(R,e);if(rpD2(p.x,p.y,v.x,v.y)<RPT.VENT_R*RPT.VENT_R){rpHurt(e,e.mx*(e.boss?.03:RPT.VENT_K),99,null);e.fl=.1}}
     try{ptBurst(R.fx,v.x,v.y-10,14,['#ffd27a','#ff8a2a','#3a1a14'],{v:260,s:4,up:1,g:380})}catch(e){}}if(v.k>=1){v.k=-1;v.hit=0;v.t=RPT.VENT_T}}
  else{v.t-=dt;if(v.t<=0)v.k=0}}
 /* foes */
 for(const e of R.foes){if(e.dead){e.dk+=dt*2.6;continue}e.fl=Math.max(0,e.fl-dt);e.stun=Math.max(0,e.stun-dt);e.inField=Math.max(0,e.inField-dt);
  let k=1;if(e.slowT>0){e.slowT-=dt;k=1-e.slowK;if(e.slowT<=0)e.slowK=0}
  if(!e.air){const p=rpPos(R,e);e.ice=p.ice?1:0;if(e.ice)k*=RPT.ICE_K;
   if(R.fields.length)for(const f of R.fields)if(rpD2(p.x,p.y,f.x,f.y)<f.r*f.r){k=Math.min(k,1-RPT.AB.slow.k);e.inField=.2}}
  if(e.stun>0)k=0;e.s+=e.sp*k*dt;e.ph=(e.ph+dt*e.sp*k/(e.air?60:52)+(e.air?dt*1.6:0))%1;
  if(e.heal>0){e.heal-=dt;if(e.heal<=0){const F=RP_FOE[e.id];e.heal=F.healT;const p=rpPos(R,e);let n=0;for(const f of R.foes){if(f.dead||f===e||f.hp>=f.mx)continue;const q=rpPos(R,f);if((q.x-p.x)**2+(q.y-p.y)**2<F.healR*F.healR){f.hp=Math.min(f.mx,f.hp+f.mx*F.heal);n++}}
    if(n)R.rings.push({x:p.x,y:p.y,t:0,d:.6,max:F.healR,c:'#b47aff',w:3,heal:1})}}
  if(e.s>=rpLen(R,e)){e.dead=1;e.dk=1;e.leak=1;R.leaked++;R.hp=Math.max(0,R.hp-e.dmg);R.shake=Math.max(R.shake,e.boss?24:8);R.hitFl=1;R.castHit=1;rpSfx('leak');
   const c=rpCastC(R);rpText(c.x,c.y-20,`-${e.dmg} health`,'#ff5a6a',e.boss?44:28);if(e.boss)R.boss=null;if(R.hp<=0&&R.wst!=='done')rpDefeat()}}
 R.foes=R.foes.filter(e=>!e.dead||e.dk<1);
 /* towers (a tower under construction does not fire yet) */
 for(const p of R.pads){const tw=p.tw;if(tw&&tw.build>=1)rpFire(R,tw,dt)}
 rpShots(R,dt);for(const a of R.arcs)a.t+=dt;R.arcs=R.arcs.filter(a=>a.t<a.d);for(const r of R.rings)r.t+=dt;R.rings=R.rings.filter(r=>r.t<r.d);
 if(R.wst==='run'&&!R.q.length&&!R.foes.some(e=>!e.dead))rpWaveDone()}
/* ---------- draw ---------- */
function rpBeamsDraw(c,R){for(const p of R.pads){const tw=p.tw;if(!tw||tw.type!=='prism'||!tw.beams||!tw.beams.length||tw.build<1)continue;
  const top=(typeof rpTowerTop==='function'?rpTowerTop('prism',tw.tier):110)||110;
  for(const b of tw.beams){const e=b.e;if(e.dead)continue;const q=rpPos(R,e),x=q.x,y=q.y-(e.air?40:18);
   if(R.lite&&b!==tw.beams[0]){c.save();c.globalCompositeOperation='lighter';c.globalAlpha=.8;c.strokeStyle='#fff2b0';c.lineWidth=3+4*b.ramp;c.beginPath();c.moveTo(tw.x,tw.y-top);c.lineTo(x,y);c.stroke();c.restore()}/* slow device: extra beams drawn plainly */
   else if(typeof rpPrismBeam==='function'){rpPrismBeam(c,tw.x,tw.y-top,x,y,R.t,b.ramp,tw.tier);if(typeof rpPrismHit==='function'&&(!R.lite||b===tw.beams[0]))rpPrismHit(c,x,y,R.t,b.ramp,tw.tier)}
   else{c.save();c.globalCompositeOperation='lighter';c.strokeStyle='#fff2b0';c.lineWidth=3+5*b.ramp;c.beginPath();c.moveTo(tw.x,tw.y-top);c.lineTo(x,y);c.stroke();c.restore()}}}}
function rpTowerAt(c,R,tw){c.save();c.translate(tw.x,tw.y);const o={aim:tw.aim,fire:tw.fire,over:tw.over>0?Math.min(1,tw.over):0,sel:R.sel===tw,ph:tw.ph,charge:tw.charge||0};
 if(tw.build<1){if(typeof rpTowerBuild==='function')rpTowerBuild(c,tw.type,tw.tier,tw.skin,tw.build,R.t,{aim:tw.aim,ph:tw.ph});else{const k=rpOver(tw.build);c.globalAlpha=Math.min(1,tw.build*3);c.scale(.4+.6*k,.2+.8*k);rpTowerDraw(c,tw.type,tw.tier,tw.skin,R.t,o)}}
 else if(tw.upK<1&&typeof rpTowerBuild==='function')rpTowerBuild(c,tw.type,tw.tier,tw.skin,tw.upK,R.t,{aim:tw.aim,ph:tw.ph,from:tw.from});
 else{if(tw.upK<1){const k=.85+.15*rpOver(tw.upK);c.scale(k,2-k)}rpTowerDraw(c,tw.type,tw.tier,tw.skin,R.t,o)}
 c.restore();if(tw.over>0)rpOvercharge(c,tw.x,tw.y,R.t,Math.min(1,tw.over),rpTowerTop(tw.type,tw.tier))}
function rpDraw(){const R=RPX,c=ctx;if(!R)return;if(NEEDRESET){NEEDRESET=false;if(c.reset)c.reset()}c.setTransform(RS,0,0,RS,0,0);/* the canvas is W x H times the render scale RS */c.globalAlpha=1;c.globalCompositeOperation='source-over';
 c.save();/* 8.9b: no whole-screen shake; hits show on the castle and the Health chip instead */
 try{RPFX.lite=!!R.lite}catch(e){}c.drawImage(R.bake.c,0,0);rpAmbient(c,R);
 if(R.castHit>0&&typeof rpCastleHit==='function'){const B=R.bake.cast;try{rpCastleHit(c,R.bake.id,B.x,B.y,1-R.castHit)}catch(e){}}
 for(const v of R.vents)if(v.k>=0)rpVentDraw(c,v.x,v.y,R.t,v.k);
 for(const f of R.fields){const k=f.t<.3?f.t/.3:f.t>f.d-.5?(f.d-f.t)/.5:1;rpSlowField(c,f.x,f.y,f.r,R.t,k)}
 for(const b of R.burns){const k=Math.min(1,(b.d-b.t)/.6);c.save();c.globalCompositeOperation='lighter';c.globalAlpha=.55*k;glow(c,b.x,b.y,b.r,'#ff6a1a88');c.restore();if(!R.rm&&Math.random()<.3)try{ptBurst(R.fx,b.x+(Math.random()-.5)*b.r,b.y+(Math.random()-.5)*b.r*.5,1,['#ffb04a','#ff6a1a'],{v:60,s:2.5,up:1,g:-80})}catch(e){}}
 /* pads: glowing when they can take the tower being placed, red when it cannot be afforded */
 const placing=!!R.place,afford=placing&&R.supply>=rpCost(R.place,1);
 for(const p of R.pads){if(p.tw)continue;c.save();c.translate(p.x,p.y);rpPadDraw(c,R.t,placing?(R.ghost===p?'hover':afford?'valid':'invalid'):(R.selPad===p||R.hover===p?'hover':'idle'));c.restore()}
 /* range rings */
 const rr=(x,y,r,col)=>{c.save();c.globalAlpha=.16;c.fillStyle=col;c.beginPath();c.ellipse(x,y,r,r*RPFX.sq,0,0,TAU);c.fill();c.globalAlpha=.75;c.setLineDash([10,8]);c.lineDashOffset=-R.t*30;c.lineWidth=2.5;c.strokeStyle=col;c.stroke();c.restore()};
 if(R.sel){const T=RP_TW[R.sel.type];rr(R.sel.x,R.sel.y,T.range[R.sel.tier-1],'#ffd45a')}
 if(placing&&R.ghost)rr(R.ghost.x,R.ghost.y,RP_TW[R.place].range[0],'#9fe8ff');
 if(R.aim==='over')for(const p of R.pads)if(p.tw&&p.tw.build>=1){c.save();c.globalAlpha=.5+.3*Math.sin(R.t*6);c.strokeStyle='#ffd45a';c.lineWidth=4;c.beginPath();c.ellipse(p.x,p.y+4,52,22,0,0,TAU);c.stroke();c.restore()}
 /* entities by depth */
 const L=[];for(const p of R.pads)if(p.tw)L.push({y:p.y,k:0,o:p.tw});for(const e of R.foes){if(e.air)continue;const q=rpPos(R,e);L.push({y:q.y,k:1,o:e,q})}L.sort((a,b)=>a.y-b.y);
 for(const it of L){if(it.k===0)rpTowerAt(c,R,it.o);else rpFoeDraw(c,R,it.o,it.q)}
 if(placing&&R.ghost){c.save();c.translate(R.ghost.x,R.ghost.y);c.globalAlpha=afford?1:.5;rpTowerDraw(c,R.place,1,rpSkinOf(R.place),R.t,{ghost:true,aim:0,fire:0,over:0});c.restore()}
 for(const e of R.foes)if(e.air)rpFoeDraw(c,R,e,rpPos(R,e));
 /* shots, arcs, rings */
 for(const s of R.shots){if(s.k==='bolt')rpBolt(c,s.x,s.y,s.a,s.skin,s.tier);else{const u=s.t/s.d,x=s.x0+(s.x1-s.x0)*u,y=s.y0+(s.y1-s.y0)*u-Math.sin(u*Math.PI)*110;rpEmber(c,x,y,R.t,s.skin,s.tier)}}
 rpBeamsDraw(c,R);
 for(const a of R.arcs){for(let i=0;i<a.pts.length-1;i++)rpBolt2(c,a.pts[i].x,a.pts[i].y,a.pts[i+1].x,a.pts[i+1].y,R.t+i,a.skin,a.tier)}
 for(const r of R.rings){const k=r.t/r.d;if(r.boom)rpBurst(c,r.x,r.y,k,r.max,r.skin,r.tier);else if(r.frost)rpFrostPulse(c,r.x,r.y,k,r.max,r.skin,r.tier);else if(r.nova&&typeof rpPrismNova==='function')rpPrismNova(c,r.x,r.y,k,r.max,r.tier);
  else{c.save();c.globalAlpha=(1-k)*.85;c.strokeStyle=r.c;c.lineWidth=r.w*(1-k*.5);c.beginPath();c.ellipse(r.x,r.y,8+(r.max-8)*rpEase(k),(8+(r.max-8)*rpEase(k))*RPFX.sq,0,0,TAU);c.stroke();c.restore()}}
 try{ptFxStep(c,R.fx,R.pause?0:1/60)}catch(e){}
 /* floating text */
 c.textAlign='center';c.textBaseline='middle';for(const t of R.tx){const u=t.t/t.d,a=u<.15?u/.15:1-Math.max(0,(u-.6)/.4);c.globalAlpha=a;c.font=`800 ${t.sz}px Poppins,system-ui,sans-serif`;
  c.lineWidth=4;c.strokeStyle=RPO;c.strokeText(t.s,t.x,t.y-u*34);c.fillStyle=t.c;c.fillText(t.s,t.x,t.y-u*34)}c.globalAlpha=1;
 /* aiming the Slow Field: a preview that turns red off the road */
 if(R.aim==='slow'&&R.my>=0){const on=R.G.dRoad(R.mx,R.my)<70;c.save();c.globalAlpha=on?.65:.35;rpSlowField(c,R.mx,R.my,RPT.AB.slow.r,R.t,.8);if(!on){c.strokeStyle='#ff6a7a';c.lineWidth=3;c.beginPath();c.ellipse(R.mx,R.my,RPT.AB.slow.r,RPT.AB.slow.r*RPFX.sq,0,0,TAU);c.stroke()}c.restore()}
 c.restore();
 rpBannerDraw(c,R)}
function rpFoeDraw(c,R,e,q){const k=e.dead?1-rpClamp(e.dk,0,1):1;if(k<=0)return;const v=R.map.pal;
 if(e.dead&&!e.leak&&typeof rpMobDeath==='function'){rpMobDeath(c,e.id,q.x,q.y,rpClamp(e.dk,0,1),{v});return}
 const flip=Math.cos(q.a)<-.2;rpMobBlit(c,e.id,q.x,q.y,e.ph,{s:1,flip,a:k,flash:e.fl>0?e.fl/.1:0,chill:e.slowT>0||e.inField>0?.55:0,v});
 if(e.ice&&!R.rm&&Math.random()<.05)try{ptBurst(R.fx,q.x,q.y-4,1,['#ffffff'],{v:50,s:2})}catch(x){}
 if(e.slowT>0&&!R.rm&&Math.random()<.08)try{ptBurst(R.fx,q.x,q.y-20,1,['#d8f4ff'],{v:40,s:2})}catch(x){}
 if(!e.dead&&e.hp<e.mx){const h=(RPMOB[e.id]?RPMOB[e.id].h:50)+(e.air?44:8),w=e.boss?90:36,y=q.y-h;c.fillStyle='rgba(10,6,20,.8)';c.fillRect(q.x-w/2-1,y-1,w+2,7);
  c.fillStyle=e.boss?'#ff8a3a':e.hp/e.mx>.5?'#7dffb0':e.hp/e.mx>.25?'#ffd45a':'#ff5a6a';c.fillRect(q.x-w/2,y,w*rpClamp(e.hp/e.mx,0,1),5)}}
function rpBannerDraw(c,R){const b=R.banner;if(!b)return;const u=b.t/b.d,a=u<.12?u/.12:u>.8?(1-u)/.2:1,s=R.rm?1:.85+.15*rpOver(Math.min(1,b.t/.35));
 c.save();c.globalAlpha=a;c.translate(800,330);c.scale(s,s);c.textAlign='center';c.textBaseline='middle';
 const w=620;c.fillStyle='rgba(8,5,22,.8)';c.strokeStyle=b.boss||b.lose?'#ff6a5a':'#ffd45a';c.lineWidth=3;c.beginPath();c.roundRect(-w/2,-62,w,124,24);c.fill();c.stroke();
 c.font=`400 ${b.txt.length>16?54:70}px 'Pirata One',Georgia,serif`;c.lineWidth=7;c.strokeStyle=RPO;c.strokeText(b.txt,0,-14);const g=c.createLinearGradient(0,-50,0,20);g.addColorStop(0,'#fff6c0');g.addColorStop(.5,b.boss||b.lose?'#ff9a6a':'#ffd45a');g.addColorStop(1,b.boss||b.lose?'#c8301a':'#e08a1a');c.fillStyle=g;c.fillText(b.txt,0,-14);
 if(b.sub){c.font='600 18px Poppins,system-ui,sans-serif';c.fillStyle='#e8e0ff';c.fillText(b.sub,0,36)}c.restore()}
/* ---------- input ---------- */
function rpStageXY(ev){const r=cv.getBoundingClientRect();return{x:(ev.clientX-r.left)/r.width*W,y:(ev.clientY-r.top)/r.height*H}}
function rpClick(x,y,btn,touch){const R=RPX;if(!R||R.pause||R.over||R.wst==='done')return;
 if(btn===2){R.place=null;R.ghost=null;R.aim=null;R.selPad=null;R.sel=null;return}
 if(R.aim==='slow'){if(R.G.dRoad(x,y)<70)rpAbility('slow',{x,y});else{rpSfx('no');rpToast('Place the Slow Field on the road',1.2,'#9fe8ff')}return}
 const p=rpPick(R,x,y);
 if(R.aim==='over'){if(p&&p.tw&&p.tw.build>=1)rpAbility('over',p.tw);else R.aim=null;return}
 if(R.place){const g=rpSnap(R,x,y);if(g){rpBuild(g,R.place);return}if(p&&p.tw){R.place=null;R.ghost=null;R.sel=p.tw;rpSfx('key',3);return}R.place=null;R.ghost=null;return}
 if(p&&p.tw){R.sel=R.sel===p.tw?null:p.tw;R.selPad=null;rpSfx('key',3);return}
 const pad=p||(touch?rpSnap(R,x,y):null);
 if(pad){R.selPad=R.selPad===pad?null:pad;R.sel=null;rpSfx('key',1);return}
 R.sel=null;R.selPad=null}
function rpKeyDown(e){const R=RPX;if(!R||!S.rp||S.mode!=='ramparts')return;if(e.ctrlKey||e.metaKey||e.altKey)return;
 const k=e.key,lk=k.length===1?k.toLowerCase():k,stop=()=>{e.preventDefault();e.stopImmediatePropagation()};
 if(k==='Escape'){stop();if(R.place||R.aim||R.selPad||R.sel){R.place=null;R.ghost=null;R.aim=null;R.selPad=null;R.sel=null;return}if(!R.over&&R.wst!=='done')rpPause();return}
 if(R.pause||R.over){return}try{ensureAudio()}catch(x){}
 if(k===' '||k==='Enter'){stop();if(!e.repeat&&R.wst==='build')rpWaveStart();return}
 if(k==='Tab'||lk==='f'){stop();if(!e.repeat)rpSpeed();return}
 if(k==='1'||k==='2'||k==='3'){stop();if(!e.repeat)rpAbPress(['over','slow','repair'][+k-1]);return}
 const ti='qwert'.indexOf(lk);if(ti>=0&&k.length===1){stop();if(!e.repeat)rpPlace(RP_TWORDER[ti]);return}
 if(lk==='u'&&R.sel){stop();if(!e.repeat)rpUpgrade(R.sel);return}
 if(lk==='x'&&R.sel){stop();if(!e.repeat)rpSell(R.sel);return}
 if(k.length===1){stop()}}
if(!window.__rpk2){window.__rpk2=1;
 window.addEventListener('keydown',rpKeyDown,true);
 cv.addEventListener('pointerdown',e=>{const R=RPX;if(!R||!S.rp||S.mode!=='ramparts')return;const p=rpStageXY(e);R.mx=p.x;R.my=p.y;if(R.place)R.ghost=rpSnap(R,p.x,p.y);try{ensureAudio()}catch(x){}rpClick(p.x,p.y,e.button,e.pointerType==='touch'||e.pointerType==='pen')});
 cv.addEventListener('pointermove',e=>{const R=RPX;if(!R||!S.rp)return;const p=rpStageXY(e);R.mx=p.x;R.my=p.y;
  if(R.place){R.ghost=rpSnap(R,p.x,p.y);R.hover=null}else R.hover=R.aim==='slow'?null:rpPick(R,p.x,p.y);
  const cur=R.place?(R.ghost?'pointer':''):R.aim?'crosshair':R.hover?'pointer':'';if(cv.style.cursor!==cur)cv.style.cursor=cur});
 cv.addEventListener('pointerleave',()=>{const R=RPX;if(R&&S.rp){R.hover=null;R.ghost=null;R.my=-1}});
 cv.addEventListener('contextmenu',e=>{if(RPX&&S.rp){e.preventDefault();rpClick(0,0,2)}});
 window.addEventListener('blur',()=>{if(RPX&&S.rp&&S.mode==='ramparts'&&!RPX.over&&!RPX.pause&&RPX.wst!=='done')rpPause(true)});
 document.addEventListener('visibilitychange',()=>{if(document.hidden&&RPX&&S.rp&&S.mode==='ramparts'&&!RPX.over&&!RPX.pause&&RPX.wst!=='done')rpPause(true)})}
function rpSpeed(){const R=RPX;if(!R)return;R.spd=R.spd>=3?1:R.spd+1;rpSfx('key',R.spd*3)}
function rpPause(on){const R=RPX;if(!R||R.over)return;on=on===undefined?!R.pause:on;if(on===R.pause)return;R.pause=on;if(on){if(typeof rpPauseMenu==='function')rpPauseMenu()}else{hide();try{inp.blur()}catch(e){}if(typeof rpHudOn==='function')rpHudOn()}}
/* ---------- the finish: coins, XP, stars, unlocks ---------- */
/* the endless Wonderland: no stars and no victory; the waves held, the coins earned and the best run */
function rpFinishEndless(){const R=RPX;R.over=true;const r=RPP(),map=R.map,held=R.heldAt!=null?R.heldAt:Math.max(0,R.wave-(R.wst==='build'?0:1)),old=r.ebest||0;
 const run=Math.floor(R.coins),total=run,l0=lvl(P.xp),xp=xpMode(Math.round(Math.min(1500,map.xp*held)*xpMulRun()));P.xp+=xp;const lg=levelGold(l0,lvl(P.xp)),xn=xpNoteH();
 r.ebest=Math.max(old,held);r.runs++;r.kills+=R.kills;r.gold+=total;P.gold=Math.min(1e12,P.gold+total);try{stat('gold',total,'add')}catch(e){}save();
 R.result={endless:1,won:false,free:false,stars:0,old:0,newStars:false,held,best:r.ebest,newBest:held>old,run,kill:Math.floor(R.cKill),wave:Math.floor(R.cWave),win:0,first:false,total,xp,xn,lg,unl:[],ttl:false,
  cleared:held,hp:R.hp,kills:R.kills,time:R.time,built:R.built,ups:R.ups,leaked:R.leaked,waveN:R.wave,fpWaves:0,abil:R.abil,asc:R.ascN||0,l0,l1:lvl(P.xp)};
 try{if(typeof rpHudOff==='function')rpHudOff()}catch(e){}if(typeof rpResult==='function')rpResult()}
function rpFinish(won){const R=RPX;if(!R||R.over)return;if(R.map.endless)return rpFinishEndless();R.over=true;const r=RPP(),map=R.map;
 const hp=won?(R.winHp!=null?R.winHp:R.hp):0,cleared=won?map.waves:Math.max(0,R.wave-1),stars=won?rpStarsFor(hp):0,old=r.stars[map.id]||0;
 const run=Math.floor(R.coins);let win=won?rpWinCoins(map,stars):0,first=false;const day=rpDay();
 if(won){if(r.day!==day){r.day=day;r.dayDone={}}if(!r.dayDone[map.id]){r.dayDone[map.id]=1;first=true;win=Math.round(win*RPT.FIRSTDAY)}}
 const total=run+win;
 const frac=won?1:cleared/map.waves,l0=lvl(P.xp),xp=xpMode(Math.round(map.xp*(won?1:.5*frac)*xpMulRun())+(R.free?R.fpWaves*8:0));P.xp+=xp;const lg=levelGold(l0,lvl(P.xp)),xn=xpNoteH();
 if(stars>old)r.stars[map.id]=stars;r.runs++;if(won)r.wins++;r.kills+=R.kills;r.gold+=total;
 const b=r.best[map.id]||{};if(won&&(b.hp==null||hp>b.hp))r.best[map.id]={hp,t:Math.round(R.time)};if(R.free){r.fp[map.id]=Math.max(r.fp[map.id]||0,R.fpWaves)}
 P.gold=Math.min(1e12,P.gold+total);try{stat('gold',total,'add')}catch(e){}
 const unl=rpUnlockSweep();let ttl=false;try{if(rpStarN()>=RP_TITLE_NEED&&!BTY().own['t:rampartwarden']){BTY().own['t:rampartwarden']=1;ttl=true}}catch(e){}
 if(won)try{btyAdd('ramparts',1)}catch(e){}
 save();R.result={won,free:R.free,stars,old,newStars:stars>old,run,kill:Math.floor(R.cKill),wave:Math.floor(R.cWave),win,first,total,xp,xn,lg,unl,ttl,cleared,hp,kills:R.kills,
  time:R.time,built:R.built,ups:R.ups,leaked:R.leaked,waveN:R.wave,fpWaves:R.fpWaves,abil:R.abil,l0,l1:lvl(P.xp)};
 try{if(typeof rpHudOff==='function')rpHudOff()}catch(e){}if(typeof rpResult==='function')rpResult()}
function rpUnlockSweep(){const r=RPP(),n=rpStarN(),out=[];for(const s of RP_SKINS){const k=s.tw+':'+s.k;if(n>=s.need&&!r.own[k]){r.own[k]=1;out.push(s)}}return out}
/* freeplay: after a win the player may keep defending; kills and waves keep paying coins with no ceiling */
function rpFreeplay(){const R=RPX;if(!R||R.over||!R.won)return;R.free=true;R.wst='build';R.hp=Math.max(R.hp,1);R.cd=RPT.BUILD_T;R.banner={txt:'Freeplay',sub:'Every monster and every wave keeps paying coins. How long can the castle stand?',t:0,d:2.6};if(typeof rpHudOn==='function')rpHudOn()}
