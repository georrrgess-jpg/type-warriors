/* ===== MOONLIT FISHING update 7: music (menu themes and one per spot) =====
   Everything is synthesised live with WebAudio, scheduled about a second ahead from the game's own music tick (note()).
   Menu (hub, journal, workshop, trophy hall, map) alternates two themes, one full loop each:
     shanty  "Fisherman's Shanty"  G major 6/8, dotted crotchet 76: accordion lead, plucked bass, frame drum, lapping water
     night   "Moonlit Night"       D minor 4/4, crotchet 56: low drones, tubular bells, choir pad, harp, wind, an owl
   While fishing (S.view 'fish') each spot has its own track:
     pond    "Tavern Pond"         D major 3/4, crotchet 96: harp and lute arpeggios, wooden flute, crickets and frogs
     frost   "Frostfall Lake"      E major (Lydian colour) 4/4, crotchet 72: celesta, music box, glass pads, wind, ice chimes
     grotto  "Glowcap Grotto"      F# minor 4/4, crotchet 84: marimba ostinato, kalimba with echo, choir hum, drips, cave reverb
     cove    "Lighthouse Cove"     C minor 6/8, dotted crotchet 50: cello drone, whistled tune, foghorn, creaks, waves, ship's bell
   Hand-over: on entering fishing the normal music master (mg) fades to 0 over 1.2 s while the fishing track fades in on its
   own output (FM7.vol, which mirrors the Music volume and mute: ST.mute ? 0 : ST.mvol*.6). On leaving, the fishing track fades
   out and mg fades back up while note() resumes the normal score, so two scores never play together. Views and spots crossfade
   over 1.2 s; the spot tracks sit about 2.5 dB under the menu themes. Every other loop varies: the shanty's harmony line flips
   above/below the tune, the owl moves, the pond harp doubles the tune, the frost music box runs on, a hand drum joins the
   grotto, a low cello shadows the cove whistle; crickets, frogs, drips, chimes, creaks and laps fall at random.
   A hidden tab, mute or zero Music volume stops the track (it resumes from the start of its current section).
   Levels: every track renders at about -18.7 LUFS with peaks between -3 and -7 dBFS before FM7.lvl; FM7.lvl puts the menu
   themes between the normal title music and the casino theme. CPU: one pump is about 0.5 ms every half second; noise and
   reverb buffers are built once in timer slices; chords share one envelope; reverbs are mono convolvers widened by a delay. */
const FM7={P:[],duck:0,dt:0,vol:null,ac:null,menu:'shanty',cyc:0,pos:{},lvl:.44,spot:.75,R:new WeakMap(),cpu:{n:0,ms:0,max:0},err:0};
const fm7M=m=>440*Math.pow(2,(m-69)/12);
const fm7Mel=a=>a.map(s=>s?s.trim().split(/\s+/).map(x=>x.split(':').map(Number)):[]);
const FM7PC={C:0,D:2,E:4,F:5,G:7,A:9,B:11},FM7Q={'':[0,4,7],m:[0,3,7],M7:[0,4,7,11],m7:[0,3,7,10],'7':[0,4,7,10],s4:[0,5,7]};
const fm7Pc=s=>{const m=s.match(/^([A-G])([#b]?)(.*)$/);return {pc:(FM7PC[m[1]]+(m[2]==='#'?1:m[2]==='b'?-1:0)+12)%12,q:m[3]}};
function fm7Ch(s){const [c,b]=s.split('/'),a=fm7Pc(c);return {r:a.pc,b:b?fm7Pc(b).pc:a.pc,q:FM7Q[a.q]||FM7Q['']}}
const fm7Bars=s=>s.split(/[\s|]+/).filter(Boolean).map(fm7Ch);
const fm7Up=(pc,lo)=>lo+((((pc-lo)%12)+12)%12);                       /* lowest MIDI note >= lo with pitch class pc */
const fm7Vc=(c,lo)=>c.q.map(i=>fm7Up((c.r+i)%12,lo)).sort((a,b)=>a-b);  /* close voicing from lo up */
function fm7Dia(m,key,deg){const sc=[0,2,4,5,7,9,11],rel=((m-key)%12+12)%12,i=sc.indexOf(rel);if(i<0)return m-3;
 const j=i+deg,oc=Math.floor(j/7);return m-rel+sc[((j%7)+7)%7]+12*oc}  /* move a melody note by scale degrees (harmony lines) */
const fm7R=()=>Math.random();

/* ---------- shared buffers: noise, brown noise, reed wave and reverbs (one set per audio context) ----------
   Live, the noise is filled in small slices on timers (R.ready turns on when done, within a few tenths of a second of the
   audio starting) so no frame pays for it; an offline render fills it at once. */
const fm7Off=X=>typeof OfflineAudioContext!=='undefined'&&X instanceof OfflineAudioContext;
function fm7Res(X){let R=FM7.R.get(X);if(R)return R;R={rv:{},ready:0};FM7.R.set(X,R);const sr=X.sampleRate,C=20000;
 R.out=X.createGain();{const N=24,re=new Float32Array(N),im=new Float32Array(N);for(let k=1;k<N;k++)im[k]=(k%2?1:.55)/Math.pow(k,.85);R.reed=X.createPeriodicWave(re,im)}
 R.nb=X.createBuffer(1,sr*2,sr);const n=sr*6|0,xf=sr/2|0;R.bn=X.createBuffer(1,n,sr);
 const job=(function*(){const w=R.nb.getChannelData(0);for(let i=0;i<w.length;i++){w[i]=Math.random()*2-1;if(i%C===0)yield}
  /* 6 s of brown noise that loops without a seam: the tail is crossfaded into the pre-roll that precedes sample 0 */
  const tmp=new Float32Array(n+xf),d=R.bn.getChannelData(0);let b=0,mx=0;for(let i=0;i<tmp.length;i++){b=(b+.02*(Math.random()*2-1))*.997;tmp[i]=b;if(i%C===0)yield}
  for(let i=0;i<n;i++){d[i]=tmp[i+xf];if(i%(C*4)===0)yield}for(let i=0;i<xf;i++){const u=i/xf;d[n-xf+i]=d[n-xf+i]*(1-u)+tmp[i]*u}
  for(let i=0;i<n;i++){mx=Math.max(mx,Math.abs(d[i]));if(i%(C*4)===0)yield}const sc=.9/mx;for(let i=0;i<n;i++){d[i]*=sc;if(i%(C*4)===0)yield}R.ready=1})();
 if(fm7Off(X))while(!job.next().done);else{const go=()=>{try{if(!job.next().done)setTimeout(go,0)}catch(e){fm7Err(e)}};go()}
 return R}
/* reverbs: room (pond, shanty), hall (night, frost, cove), cave (grotto: long, with early slaps). The returned high-pass is
   the send input (no rumble into the tail). In the live game the impulse responses are built in small slices on timers
   and the convolver is attached when ready, so no frame pays for them; an offline render builds them at once. */
function fm7Rv(X,R,k){if(R.rv[k])return R.rv[k];const hp=X.createBiquadFilter();hp.type='highpass';hp.frequency.value=200;hp.Q.value=.6;R.rv[k]=hp;
 /* a mono impulse response (half the convolution work of a stereo one), widened afterwards by delaying the right side 13 ms */
 const sr=X.sampleRate,L={room:1.2,hall:2.4,cave:3}[k],len=sr*L|0,ir=X.createBuffer(1,len,sr),pw={room:2.6,hall:2.1,cave:1.8}[k],d=ir.getChannelData(0);let i=0,lp=0;
 const work=n=>{const e=Math.min(len,i+n);for(;i<e;i++){const u=i/len;lp+=((Math.random()*2-1)-lp)*(.62-.48*u);d[i]=lp*Math.pow(1-u,pw)}
  if(i>=len&&k==='cave')for(const [ms,a] of [[61,.5],[97,-.35],[143,.28],[211,-.2]]){const j=ms*sr/1000|0;if(j<len)d[j]+=a}return i>=len};
 const fin=()=>{try{const cv=X.createConvolver(),dl=X.createDelay(.05),mx=X.createChannelMerger(2);cv.buffer=ir;dl.delayTime.value=.013;
  cv.connect(mx,0,0);cv.connect(dl);dl.connect(mx,0,1);mx.connect(R.out);hp.connect(cv)}catch(e){fm7Err(e)}};
 if(fm7Off(X)){work(1e9);fin()}else{const go=()=>{if(work(20000))setTimeout(fin,0);else setTimeout(go,0)};setTimeout(go,0)}
 return hp}

/* ---------- envelopes and voices ----------
   Every envelope gain starts at 0, not the default 1: a source can start one sample before its first automation event. */
function fm7Env(g,t,v,a,d,r){const p=g.gain;p.value=0;p.setValueAtTime(.0001,t);p.linearRampToValueAtTime(v,t+a);if(d>a)p.setValueAtTime(v,t+d);p.exponentialRampToValueAtTime(.0001,t+Math.max(a,d)+r)}
function fm7Pl(g,t,v,a,dec){const p=g.gain;p.value=0;p.setValueAtTime(.0001,t);p.linearRampToValueAtTime(v,t+a);p.exponentialRampToValueAtTime(.0001,t+a+dec)}
function fm7O(P,w,f,t,e,dst,det){const o=P.X.createOscillator();if(typeof w==='string')o.type=w;else o.setPeriodicWave(w);o.frequency.value=f;if(det)o.detune.value=det;o.connect(dst);o.start(t);o.stop(e);return o}
function fm7G(P,v,dst){const g=P.X.createGain();g.gain.value=v;if(dst)g.connect(dst);return g}
function fm7Vib(P,os,t,e,dep,rate,del){const X=P.X,l=X.createOscillator(),g=X.createGain();l.frequency.value=rate||5.2;g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(0,t+(del||.2));g.gain.linearRampToValueAtTime(dep,t+(del||.2)+.35);l.connect(g);for(const o of os)g.connect(o.detune);l.start(t);l.stop(e)}
/* noise burst through a filter (laps, washes, drum skin, breath, knocks) */
function fm7N(P,bus,t,d,v,fc,ty,q,att,buf,to){const X=P.X,s=X.createBufferSource(),f=X.createBiquadFilter(),g=X.createGain();att=att||.002;buf=buf||P.R.nb;s.buffer=buf;s.loop=true;
 f.type=ty||'bandpass';f.frequency.setValueAtTime(fc,t);if(to)f.frequency.exponentialRampToValueAtTime(to,t+att+d);f.Q.value=q||1;fm7Pl(g,t,v,att,d);s.connect(f);f.connect(g);g.connect(bus);s.start(t,Math.random()*(buf.duration-.5));s.stop(t+att+d+.05)}
/* a looping noise bed with a slow swell (water, wind, sea); the LFO also moves the filter */
function fm7Bed(P,bus,t,buf,ty,fc,q,lv,rate,dep,fd){const X=P.X,s=X.createBufferSource(),f=X.createBiquadFilter(),g=X.createGain(),l=X.createOscillator(),lg=X.createGain();
 s.buffer=buf;s.loop=true;f.type=ty;f.frequency.value=fc;f.Q.value=q;g.gain.value=lv;l.frequency.value=rate;lg.gain.value=lv*dep;l.connect(lg);lg.connect(g.gain);
 if(fd){const fg=X.createGain();fg.gain.value=fd;l.connect(fg);fg.connect(f.frequency);P.nodes.push(fg)}
 s.connect(f);f.connect(g);g.connect(bus);s.start(t,Math.random()*4);l.start(t);P.stop.push(s,l);P.nodes.push(f,g,lg)}
/* accordion / concertina: two reeds a few cents apart (musette beating) through a reedy low-pass */
function fm7Reed(P,bus,t,f,d,v,lp){const X=P.X,g=X.createGain(),fl=X.createBiquadFilter(),e=t+d+.15;fl.type='lowpass';fl.frequency.value=lp||2600;fl.Q.value=1.1;fl.connect(g);
 fm7Env(g,t,v,.035,d,.1);fm7O(P,P.R.reed,f,t,e,fl,-7);fm7O(P,P.R.reed,f,t,e,fl,8);g.connect(bus)}
/* accordion left hand: a whole chord, one reed per note, one filter and one envelope */
function fm7Chord(P,bus,t,fs,d,v,lp){const X=P.X,g=X.createGain(),fl=X.createBiquadFilter(),e=t+d+.15;fl.type='lowpass';fl.frequency.value=lp||1700;fl.Q.value=1.1;fl.connect(g);
 fm7Env(g,t,v,.03,d,.1);fs.forEach((f,i)=>fm7O(P,P.R.reed,f,t,e,fl,i%2?6:-6));g.connect(bus)}
/* plucked bass */
function fm7Bass(P,bus,t,f,v,dec){const X=P.X,g=X.createGain(),fl=X.createBiquadFilter(),e=t+dec+.06;fl.type='lowpass';fl.Q.value=1.8;fl.frequency.setValueAtTime(1500,t);fl.frequency.exponentialRampToValueAtTime(240,t+.22);fl.connect(g);
 fm7Pl(g,t,v,.004,dec);fm7O(P,'triangle',f,t,e,fl);fm7O(P,'sawtooth',f,t,e,fm7G(P,.45,fl));g.connect(bus)}
/* soft sine (sub bass, deep pulses) */
function fm7Sub(P,bus,t,f,v,a,dec){const g=P.X.createGain();fm7Pl(g,t,v,a,dec);fm7O(P,'sine',f,t,t+a+dec+.05,g);g.connect(bus)}
/* hand / frame drum: pitched thump plus a skin slap */
function fm7Drum(P,bus,t,v,f0,slap){const X=P.X,o=X.createOscillator(),g=X.createGain();f0=f0||100;o.frequency.setValueAtTime(f0*1.9,t);o.frequency.exponentialRampToValueAtTime(f0,t+.08);
 fm7Pl(g,t,v,.003,.32);o.connect(g);g.connect(bus);o.start(t);o.stop(t+.4);if(slap!==0)fm7N(P,bus,t,.045,v*(slap||.3),1100,'bandpass',1.3)}
/* struck partials: bells, celesta, music box, ice chimes, kalimba, marimba, harp */
const FM7B={tub:[[1,1,1],[2.76,.45,.45],[5.4,.22,.25],[8.93,.1,.14]],ship:[[.5,.3,1.3],[1,1,1],[2,.45,.6],[3.01,.3,.4],[4.2,.14,.25]],
 cel:[[1,1,1],[2,.1,.45],[4,.14,.16]],box:[[1,1,1],[2.01,.2,.35],[5.6,.08,.1]],ice:[[1,1,1],[2.32,.35,.5],[4.25,.16,.25]],
 kal:[[1,1,1],[5.95,.15,.07]],mar:[[1,1,1],[4,.22,.16]],harp:[[1,1,1],[2,.3,.5],[3,.08,.3]]};
function fm7Bell(P,bus,t,f,v,dec,kind){const X=P.X,ny=X.sampleRate*.45;for(const [m,a,dm] of FM7B[kind]){if(f*m>ny)continue;const o=X.createOscillator(),g=X.createGain(),dd=dec*dm;o.frequency.value=f*m;fm7Pl(g,t,v*a,.002,dd);o.connect(g);g.connect(bus);o.start(t);o.stop(t+dd+.05)}}
/* lute: bright saw pluck with a fast-closing filter */
function fm7Lute(P,bus,t,f,v,dec){const X=P.X,g=X.createGain(),fl=X.createBiquadFilter(),e=t+dec+.06;fl.type='lowpass';fl.Q.value=1.6;fl.frequency.setValueAtTime(3400,t);fl.frequency.exponentialRampToValueAtTime(650,t+.16);fl.connect(g);
 fm7Pl(g,t,v,.003,dec);fm7O(P,'sawtooth',f,t,e,fl,-4);fm7O(P,'triangle',f*2,t,e,fm7G(P,.3,fl),3);g.connect(bus)}
/* choir: detuned saws through two vowel formants (f may be a whole chord: one envelope and one pair of formants) */
const FM7V={oo:[[330,5,1],[820,7,.35]],aa:[[720,5,1],[1150,6,.5]],mm:[[250,3,1],[540,4,.25]]};
function fm7Choir(P,bus,t,f,d,v,vw){const X=P.X,g=X.createGain(),e=t+d+1.3;fm7Env(g,t,v,Math.min(1.4,d*.4),d,1.1);
 const fs=FM7V[vw||'oo'].map(([fc,q,l])=>{const b=X.createBiquadFilter();b.type='bandpass';b.frequency.value=fc;b.Q.value=q;b.connect(l<1?fm7G(P,l,g):g);return b});
 for(const fr of [].concat(f))for(const dt of [-9,9]){const o=X.createOscillator();o.type='sawtooth';o.frequency.value=fr;o.detune.value=dt;for(const b of fs)o.connect(b);o.start(t);o.stop(e)}g.connect(bus)}
/* bowed strings / drones: two saws, low-pass, slow swell, optional vibrato */
function fm7Bow(P,bus,t,f,d,v,o){o=o||{};const X=P.X,g=X.createGain(),fl=X.createBiquadFilter(),r=o.r||1,e=t+d+r+.05;fl.type='lowpass';fl.frequency.value=o.lp||800;fl.Q.value=.8;fl.connect(g);
 fm7Env(g,t,v,o.a||.4,d,r);const os=[fm7O(P,'sawtooth',f,t,e,fl,-5),fm7O(P,'sawtooth',f,t,e,fl,5)];if(o.vib)fm7Vib(P,os,t,e,o.vib,o.vr||5,.3);g.connect(bus)}
/* glass pad: sine and triangle a few cents apart, slow in, slow out */
function fm7Glass(P,bus,t,f,d,v){const g=P.X.createGain(),e=t+d+1.7,tg=fm7G(P,.6,g);fm7Env(g,t,v,1.1,d,1.5);for(const fr of [].concat(f)){fm7O(P,'sine',fr,t,e,g,-5);fm7O(P,'triangle',fr,t,e,tg,5)}g.connect(bus)}
/* wooden flute: sine body, a little second harmonic, delayed vibrato and a breathy chiff */
function fm7Flute(P,bus,t,f,d,v){const g=P.X.createGain(),e=t+d+.2;fm7Env(g,t,v,.05,d,.14);const os=[fm7O(P,'sine',f,t,e,g),fm7O(P,'sine',f*2,t,e,fm7G(P,.12,g)),fm7O(P,'triangle',f,t,e,fm7G(P,.16,g))];
 if(d>.35)fm7Vib(P,os,t,e,13,5.1,.22);fm7N(P,bus,t,.07,v*.35,f*2,'bandpass',3);g.connect(bus)}
/* whistle: pure sine scooping up from the previous note, wide vibrato on long notes, a breath of air */
function fm7Whistle(P,bus,t,f,d,v,from){const X=P.X,o=X.createOscillator(),g=X.createGain(),e=t+d+.25;o.type='sine';
 if(from&&Math.abs(from-f)>1){o.frequency.setValueAtTime(from,t);o.frequency.exponentialRampToValueAtTime(f,t+.1)}else{o.frequency.setValueAtTime(f*.96,t);o.frequency.exponentialRampToValueAtTime(f,t+.07)}
 fm7Env(g,t,v,.06,d,.2);fm7Vib(P,[o],t,e,d>.6?20:8,5.6,Math.min(.35,d*.4));o.connect(g);g.connect(bus);o.start(t);o.stop(e);fm7N(P,bus,t,d*.8,v*.05,f,'bandpass',7,.06)}
/* night creatures and the sea */
function fm7Owl(P,bus,t,v){const X=P.X,f=360+fm7R()*40;for(const [dt,d,a] of [[0,.42,1],[.75,.18,.7],[1.0,.55,.9]]){const o=X.createOscillator(),g=X.createGain(),s=t+dt;o.type='sine';
 o.frequency.setValueAtTime(f*1.05,s);o.frequency.exponentialRampToValueAtTime(f*.92,s+d);fm7Env(g,s,v*a,.07,d*.6,d*.45);o.connect(g);g.connect(bus);o.start(s);o.stop(s+d+.5)}}
function fm7Cricket(P,bus,t,v){const X=P.X,o=X.createOscillator(),g=X.createGain(),n=3+(fm7R()*3|0),p=g.gain;o.frequency.value=4200+fm7R()*600;p.value=0;p.setValueAtTime(0,t);
 for(let i=0;i<n;i++){const s=t+i*.042;p.setValueAtTime(0,s);p.linearRampToValueAtTime(v,s+.008);p.linearRampToValueAtTime(0,s+.028)}o.connect(g);g.connect(bus);o.start(t);o.stop(t+n*.042+.05)}
function fm7Frog(P,bus,t,v){const X=P.X,o=X.createOscillator(),f=X.createBiquadFilter(),g=X.createGain(),f0=105+fm7R()*45,p=g.gain;o.type='sawtooth';o.frequency.setValueAtTime(f0,t);o.frequency.linearRampToValueAtTime(f0*1.25,t+.24);
 f.type='bandpass';f.frequency.value=620;f.Q.value=2.4;p.value=0;p.setValueAtTime(0,t);for(let i=0;i<7;i++){const s=t+i*.036;p.setValueAtTime(0,s);p.linearRampToValueAtTime(v*(i<5?1:.55),s+.006);p.linearRampToValueAtTime(0,s+.028)}
 o.connect(f);f.connect(g);g.connect(bus);o.start(t);o.stop(t+.3)}
function fm7Drip(P,bus,t,v){const X=P.X,o=X.createOscillator(),g=X.createGain(),f=700+fm7R()*900;o.frequency.setValueAtTime(f,t);o.frequency.exponentialRampToValueAtTime(f*2.3,t+.05);fm7Pl(g,t,v,.002,.11);o.connect(g);g.connect(bus);o.start(t);o.stop(t+.16)}
function fm7Creak(P,bus,t,v){const X=P.X,o=X.createOscillator(),f=X.createBiquadFilter(),g=X.createGain(),d=.7+fm7R()*.6,fc=380+fm7R()*260;o.type='sawtooth';
 o.frequency.setValueAtTime(14,t);o.frequency.linearRampToValueAtTime(30,t+d*.5);o.frequency.linearRampToValueAtTime(17,t+d);f.type='bandpass';f.Q.value=7;f.frequency.setValueAtTime(fc,t);f.frequency.linearRampToValueAtTime(fc*1.45,t+d);
 fm7Env(g,t,v,d*.3,d*.55,d*.4);o.connect(f);f.connect(g);g.connect(bus);o.start(t);o.stop(t+d+.5)}
function fm7Fog(P,bus,t,v,f){const X=P.X,g=X.createGain(),fl=X.createBiquadFilter(),d=2.6,e=t+d+1.6;fl.type='lowpass';fl.frequency.value=430;fl.Q.value=1.4;fl.connect(g);fm7Env(g,t,v,.55,d,1.4);
 for(const [m,w,dt] of [[1,'sawtooth',0],[1,'square',-7],[2,'sawtooth',5]]){const o=fm7O(P,w,f*m,t,e,fl,dt);o.frequency.setValueAtTime(f*m,t+d-.3);o.frequency.linearRampToValueAtTime(f*m*.94,t+d+1)}g.connect(bus)}

/* ---------- the tracks ----------
   Each track: sd (seconds per step), spb (steps per bar), bars, secs (section start bars, for resuming), rv (reverb),
   gain (loudness trim), bus {name:[dry, reverb send]}, init(P,t) for ambience beds, step(P,t,bar,k) per step. */
const FM7T={};
/* Fisherman's Shanty: G major, 6/8 at dotted crotchet 76 (quaver steps), 28 bars, about 44 s
   intro 2 | A 8 (tune) | B 8 (chorus, whistle sparkle an octave up) | A' 8 (tune with a harmony a third below, busier drum) | tag 2 */
FM7T.shanty={sd:60/76/3,spb:6,bars:28,secs:[0,2,10,18,26],rv:'room',gain:2.06,alt:'night',
 bus:{lead:[1,.32],harm:[1,.32],acc:[1,.28],bass:[.55,.06],perc:[.4,.14],amb:[1.3,.2],hi:[1,.45]},
 ch:fm7Bars('G D | G C G D G C D G | Em C G D Em C D G | G C G D G C D G | C G'),
 A:fm7Mel(['0:62:2 2:67:1 3:67:2 5:69:1','0:71:2 2:72:1 3:71:2 5:69:1','0:67:3 3:71:2 5:74:1','0:74:2 2:72:1 3:71:2 5:69:1',
  '0:62:2 2:67:1 3:67:2 5:69:1','0:71:2 2:72:1 3:76:2 5:74:1','0:72:2 2:71:1 3:69:2 5:66:1','0:67:5']),
 B:fm7Mel(['0:76:3 3:74:2 5:71:1','0:72:2 2:74:1 3:76:3','0:74:2 2:71:1 3:67:2 5:71:1','0:69:6',
  '0:76:3 3:79:2 5:78:1','0:76:2 2:74:1 3:72:2 5:71:1','0:69:2 2:71:1 3:72:2 5:66:1','0:67:3 3:62:1 4:66:1 5:67:1']),
 T:fm7Mel(['0:72:3 3:71:3','0:67:6']),
 init(P,t){fm7Bed(P,P.B.amb,t,P.R.bn,'lowpass',420,.7,.05,.16,.55,160)},
 step(P,t,bar,k){const T=this,sd=P.sd,c=T.ch[bar],B=P.B,sec=bar<2?0:bar<10?1:bar<18?2:bar<26?3:4,br=fm7Up(c.r,40),vc=fm7Vc(c,55),last=bar===27;
  /* plucked bass: root on the bar, fifth on the half-bar */
  if(k===0)fm7Bass(P,B.bass,t,fm7M(br),.17,last?2.2:.75);else if(k===3&&sec&&!last)fm7Bass(P,B.bass,t,fm7M(br+(br+7>51?-5:7)),.12,.6);
  /* left-hand accordion: held chords in the intro and tag, boom-chick-chick stabs elsewhere */
  if(sec===0||sec===4){if(k===0)fm7Chord(P,B.acc,t,vc.map(fm7M),sd*(last?8:5.8),.031,1500)}
  else if(k%3)fm7Chord(P,B.acc,t,vc.map(fm7M),sd*.62,k%3===1?.031:.022,1700);
  /* the tune */
  const mel=sec===1||sec===3?T.A[bar-(sec===1?2:18)]:sec===2?T.B[bar-10]:sec===4?T.T[bar-26]:null;
  if(mel)for(const [s,p,len] of mel){if(s!==k)continue;const d=len*sd*.94;fm7Reed(P,B.lead,t,fm7M(p),d,.05,2800);
   if(sec===3)fm7Reed(P,B.harm,t,fm7M(fm7Dia(p,7,(FM7.cyc>>1)%2?2:-2)),d,.028,2600);
   if(sec===2)fm7Flute(P,B.hi,t,fm7M(p+12),d,.018)}
  /* frame drum */
  if(sec===0){if(k===0&&bar===1)fm7Drum(P,B.perc,t,.22,95)}
  else if(sec===4){if(k===0)fm7Drum(P,B.perc,t,last?.34:.28,90)}
  else{if(k===0)fm7Drum(P,B.perc,t,.38,95);if(k===3)fm7Drum(P,B.perc,t,.24,110);if(k===5&&sec>=2)fm7Drum(P,B.perc,t,.1,120,.7);if(k===2&&sec===3)fm7N(P,B.perc,t,.035,.05,1600,'bandpass',1.5)}
  /* water lapping against the jetty */
  if(k===0&&fm7R()<.6)fm7N(P,B.amb,t+fm7R()*sd*4,.9,.07,520+fm7R()*400,'bandpass',.9,.35,P.R.bn)}};
/* Moonlit Night: D minor, 4/4 at crotchet 56 (quaver steps), 12 bars, about 51 s
   intro 2 (drone, wind, a deep toll) | A 4 (bells, "oo" choir) | B 4 (higher bells, "aa" choir, harp) | tag 2 (toll, "mm" choir) */
FM7T.night={sd:60/56/2,spb:8,bars:12,secs:[0,2,6,10],rv:'hall',gain:1.78,alt:'shanty',
 bus:{dr:[.6,.25],ch:[1,.6],bell:[1.3,.7],harp:[1,.6],amb:[1.6,.3],owl:[.25,1.4]},
 ch:fm7Bars('Dm Dm | Dm Bb Gm A | Dm F C Bb | Bb Dm'),
 M:fm7Mel(['','4:69:2 6:74:2','0:74:3 3:77:1 4:76:4','0:74:2 2:70:2 4:69:4','0:67:3 3:70:1 4:74:2 6:72:2','0:73:6 6:69:2',
  '0:81:3 3:77:1 4:79:2 6:76:2','0:77:4 4:72:4','0:76:3 3:79:1 4:74:4','0:74:2 2:73:2 4:69:4','0:70:4 4:69:4','0:62:8']),
 init(P,t){fm7Bed(P,P.B.amb,t,P.R.nb,'bandpass',650,1.3,.022,.07,.7,380)},
 step(P,t,bar,k){const T=this,sd=P.sd,bl=sd*8,B=P.B,sec=bar<2?0:bar<6?1:bar<10?2:3;let c=T.ch[bar];if(bar===9&&k>=4)c=fm7Ch('A');
  /* pedal drone D2 + A2, re-bowed every two bars with overlap so it never breaks */
  if(k===0&&bar%2===0){fm7Bow(P,B.dr,t,fm7M(38),bl*2.1,.05,{lp:420,a:1.6,r:2.4});fm7Bow(P,B.dr,t,fm7M(45),bl*2.1,.03,{lp:520,a:1.8,r:2.4})}
  /* chord root a little above the pedal */
  if(k===0&&sec&&sec<3)fm7Sub(P,B.dr,t,fm7M(fm7Up(c.r,38)+12),.05,.4,bl*.95);
  /* choir pad */
  if(k===0||(bar===9&&k===4)){const d=bar===9?bl*.5:bl*.98,vw=sec===2?'aa':sec===3?'mm':'oo';fm7Choir(P,B.ch,t,fm7Vc(c,57).map(fm7M),d,sec?.05:.04,bar<2?'mm':vw)}
  /* bell melody */
  const mel=T.M[bar];for(const [s,p,len] of mel){if(s!==k)continue;fm7Bell(P,B.bell,t,fm7M(p),bar===11?.07:.085,Math.max(2.4,len*sd*1.6),'tub')}
  /* deep tolls at the start and the end */
  if(k===0&&(bar===0||bar===10))fm7Bell(P,B.bell,t,fm7M(50),.11,6,'tub');
  /* harp rising in crotchets through B */
  if(sec===2&&k%2===0){const v=fm7Vc(c,62).concat(fm7Vc(c,74));fm7Bell(P,B.harp,t+.02,fm7M(v[(k>>1)+(bar%2)*2]),.045,2.2,'harp')}
  /* an owl, once a loop, in a different place each time */
  if(bar===(FM7.cyc%4<2?1:10)&&k===3)fm7Owl(P,B.owl,t,.07)}};
/* Tavern Pond: D major, 3/4 at crotchet 96 (quaver steps), 24 bars, 45 s
   A 8 (harp arpeggios, flute tune) | B 8 (lute arpeggios, higher flute, tapping) | A' 8 (harp + lute strums, harp doubles the tune) */
FM7T.pond={sd:60/96/2,spb:6,bars:24,secs:[0,8,16],rv:'room',gain:1.72,
 bus:{fl:[1,.3],harp:[1,.3],lute:[1,.22],bass:[.45,.06],perc:[.7,.12],amb:[1.8,.25]},
 ch:fm7Bars('D G D A Bm G A D | G D Em A G D A D | D G D A Bm G A D'),
 A:fm7Mel(['0:66:2 2:69:2 4:74:2','0:71:3 3:74:1 4:71:2','0:69:2 2:66:2 4:69:1 5:71:1','0:73:4 4:69:2','0:71:2 2:74:2 4:78:2','0:79:3 3:78:1 4:76:2',
  '0:76:2 2:74:1 3:73:1 4:71:1 5:73:1','0:74:6']),
 B:fm7Mel(['0:79:2 2:78:2 4:76:2','0:78:3 3:76:1 4:74:2','0:71:2 2:74:2 4:79:2','0:76:6','0:74:2 2:76:2 4:79:2','0:81:3 3:78:1 4:74:2','0:76:2 2:73:2 4:69:2','0:74:4 4:73:1 5:71:1']),
 init(P,t){fm7Bed(P,P.B.amb,t,P.R.bn,'lowpass',300,.7,.03,.12,.5,90)},
 step(P,t,bar,k){const T=this,sd=P.sd,c=T.ch[bar],B=P.B,sec=bar<8?0:bar<16?1:2,root=fm7Up(c.r,50),th=c.q[1],arp=[root,root+7,root+12,root+12+th,root+12,root+7][k];
  if(k===0)fm7Bass(P,B.bass,t,fm7M(fm7Up(c.r,38)),.15,1.1);
  if(sec!==1)fm7Bell(P,B.harp,t,fm7M(arp),k===0?.05:.036,1.5,'harp');else fm7Lute(P,B.lute,t,fm7M(arp),k===0?.09:.065,.85);
  if(sec===2&&(k===2||k===4))fm7Vc(c,57).forEach((m,i)=>fm7Lute(P,B.lute,t+i*.014,fm7M(m),.02,.45));
  const mel=sec===1?T.B[bar-8]:T.A[bar%8],end=bar===23;for(const [s,p,len] of mel){if(s!==k)continue;const d=len*sd*.95;fm7Flute(P,B.fl,t,fm7M(p),end?d*1.2:d,.06);if(sec===2||(sec===0&&P.lp%2))fm7Bell(P,B.harp,t,fm7M(p-12),.03,1.4,'harp')}
  if(sec>0){if(k===2||k===4)fm7N(P,B.perc,t,.03,.06,1900,'bandpass',2.2);if(k===0)fm7Drum(P,B.perc,t,.13,85,0)}
  if(fm7R()<.22)fm7Cricket(P,B.amb,t+fm7R()*sd,.008);if(fm7R()<.035)fm7Frog(P,B.amb,t+fm7R()*sd,.05)}};
/* Frostfall Lake: E major with a Lydian A#, 4/4 at crotchet 72 (quaver steps), 16 bars, 53 s
   A 8 (celesta tune, music box on the off-beats, glass pads) | B 8 (new celesta line, music box in running quavers) */
FM7T.frost={sd:60/72/2,spb:8,bars:16,secs:[0,8],rv:'hall',gain:2.29,
 bus:{cel:[1.4,.6],box:[1,.7],pad:[.7,.5],bass:[.45,.15],amb:[1,.5]},
 ch:fm7Bars('EM7 F#/E C#m7 AM7 EM7 F#/E G#m7 B | AM7 B G#m7 C#m7 AM7 B F#m7 B'),
 M:fm7Mel(['0:83:2 2:80:1 3:78:1 4:76:2 6:78:2','0:80:3 3:82:1 4:78:4','0:76:2 2:80:2 4:83:2 6:85:2','0:83:6 6:80:2',
  '0:83:2 2:80:1 3:78:1 4:76:2 6:71:2','0:73:2 2:75:2 4:78:4','0:80:2 2:78:2 4:75:2 6:78:2','0:78:4 4:75:4',
  '0:81:3 3:80:1 4:76:4','0:78:3 3:80:1 4:75:4','0:80:2 2:83:2 4:87:4','0:85:6 6:83:2','0:81:2 2:80:2 4:78:2 6:76:2','0:75:4 4:78:4','0:73:2 2:76:2 4:81:2 6:80:2','0:78:4 4:71:4']),
 init(P,t){fm7Bed(P,P.B.amb,t,P.R.nb,'bandpass',1150,1.6,.016,.09,.75,500)},
 step(P,t,bar,k){const T=this,sd=P.sd,bl=sd*8,c=T.ch[bar],B=P.B,sec=bar<8?0:1;
  if(k===0){fm7Sub(P,B.bass,t,fm7M(fm7Up(c.b,40)),.11,.05,bl*1.1);fm7Glass(P,B.pad,t,fm7Vc(c,59).map(fm7M),bl*.95,.018)}
  const tones=fm7Vc(c,79).concat(fm7Vc(c,91)),pat=sec?[0,2,1,3,2,4,3,1]:[0,1,2,3,1,2,3,4];
  if(sec||k%2||P.lp%2)fm7Bell(P,B.box,t,fm7M(tones[pat[k]%tones.length]),sec||k%2?.024:.016,1.3,'box');
  for(const [s,p,len] of T.M[bar]){if(s!==k)continue;fm7Bell(P,B.cel,t,fm7M(p),.075,Math.max(1.6,len*sd*1.4),'cel')}
  if(fm7R()<.07)fm7Bell(P,B.amb,t+fm7R()*sd,fm7M([88,90,92,95,97,100][fm7R()*6|0]),.018,2.6,'ice')}};
/* Glowcap Grotto: F# minor, 4/4 at crotchet 84 (quaver steps), 16 bars, 46 s
   A 8 (marimba ostinato, kalimba tune with a dotted-quaver echo, hummed choir) | B 8 (new tune, "oo" choir, hand drum) */
FM7T.grotto={sd:60/84/2,spb:8,bars:16,secs:[0,8],rv:'cave',gain:1.56,
 bus:{kal:[1.4,.75],mar:[1.6,.45],ch:[.65,.8],bass:[.5,.2],perc:[.8,.35],amb:[1.6,1.2]},
 ch:fm7Bars('F#m E D E F#m E D C# | Bm F#m D E Bm F#m D C#'),
 M:fm7Mel(['0:73:2 2:76:1 3:78:3 6:76:1 7:73:1','0:71:3 3:68:1 4:71:2 6:73:2','0:74:2 2:73:2 4:69:2 6:66:2','0:68:4 4:71:4',
  '0:73:2 2:76:1 3:78:3 6:81:2','0:80:3 3:78:1 4:76:2 6:73:2','0:74:2 2:76:2 4:78:2 6:74:2','0:77:4 4:73:4',
  '0:74:3 3:78:1 4:81:4','0:81:2 2:80:1 3:78:1 4:76:4','0:78:2 2:74:2 4:69:2 6:74:2','0:76:6 6:80:2','0:83:3 3:81:1 4:78:4','0:76:2 2:78:1 3:76:1 4:73:4','0:74:2 2:73:2 4:71:2 6:69:2','0:73:4 4:68:4']),
 init(P,t){const X=P.X,d=X.createDelay(2),fb=X.createGain(),lp=X.createBiquadFilter();d.delayTime.value=P.sd*1.5;fb.gain.value=.36;lp.type='lowpass';lp.frequency.value=2300;
  P.B.kal.connect(d);d.connect(lp);lp.connect(fb);fb.connect(d);const o=fm7G(P,.55,P.g),ow=fm7G(P,.9,P.gw);lp.connect(o);lp.connect(ow);P.nodes.push(d,fb,lp,o,ow);
  fm7Bed(P,P.B.amb,t,P.R.bn,'lowpass',220,.6,.025,.05,.4,60)},
 step(P,t,bar,k){const T=this,sd=P.sd,bl=sd*8,c=T.ch[bar],B=P.B,sec=bar<8?0:1,r=fm7Up(c.r,50),th=c.q[1],tn=[r,r+7,r+12,r+12+th],pat=sec?[0,2,1,3,2,1,3,2]:[0,1,2,1,3,2,1,2];
  fm7Bell(P,B.mar,t,fm7M(tn[pat[k]]),k%2?.032:.045,.75,'mar');
  if(k===0){fm7Sub(P,B.bass,t,fm7M(fm7Up(c.r,30)+12),.16,.03,bl*.9);if(bar%2===0)fm7Choir(P,B.ch,t,fm7Vc(c,57).map(fm7M),bl*2,.05,sec?'oo':'mm')}
  for(const [s,p,len] of T.M[bar]){if(s!==k)continue;fm7Bell(P,B.kal,t,fm7M(p),.075,Math.max(1,len*sd*1.2),'kal')}
  if(!sec&&P.lp%2&&(k===0||k===6))fm7Drum(P,B.perc,t,k?.1:.15,80,.15);
  if(sec){if(k===0)fm7Drum(P,B.perc,t,.26,80,.15);if(k===3)fm7Drum(P,B.perc,t,.15,95,.2);if(k===6)fm7Drum(P,B.perc,t,.19,88,.2)}
  if(fm7R()<.1)fm7Drip(P,B.amb,t+fm7R()*sd,.035)}};
/* Lighthouse Cove: C minor, 6/8 at dotted crotchet 50 (quaver steps), 20 bars, 48 s
   intro 2 (foghorn, waves) | A 8 (whistled tune over a cello drone) | B 8 (cello melody, heartbeat drum, whistle answers, ship's bell) | tag 2 */
FM7T.cove={sd:60/50/3,spb:6,bars:20,secs:[0,2,10,18],rv:'hall',gain:1.71,
 bus:{wh:[1.2,.6],cel:[1,.4],dr:[.7,.3],bell:[.7,1],far:[.08,3],perc:[.6,.25],amb:[1.3,.3]},
 ch:fm7Bars('Cm Cm | Cm Ab Cm G Cm Ab Fm G | Ab Eb Fm G Ab Eb Db G | Cm Cm'),
 W:fm7Mel(['','','0:67:3 3:72:2 5:70:1','0:68:4 4:67:1 5:65:1','0:67:3 3:63:3','0:62:6','0:67:3 3:72:2 5:74:1','0:75:3 3:74:2 5:72:1','0:72:2 2:68:1 3:65:3','0:67:3 3:71:3',
  '','','','0:79:3 3:74:3','','','','0:79:2 2:77:1 3:74:3','0:72:6','']),
 C:fm7Mel(['0:48:3 3:51:2 5:53:1','0:55:4 4:53:1 5:51:1','0:53:3 3:56:3','0:55:6','0:60:3 3:58:2 5:56:1','0:55:3 3:58:3','0:56:2 2:53:1 3:49:3','0:50:3 3:47:3']),
 init(P,t){fm7Bed(P,P.B.amb,t,P.R.bn,'lowpass',520,.7,.06,.085,.75,330);P.wp=0},
 step(P,t,bar,k){const T=this,sd=P.sd,bl=sd*6,c=T.ch[bar],B=P.B,sec=bar<2?0:bar<10?1:bar<18?2:3;
  /* cello drone on C2 + G2 */
  if(k===0&&bar%2===0){fm7Bow(P,B.dr,t,fm7M(36),bl*2.15,.05,{lp:560,a:1.4,r:2.2,vib:4});fm7Bow(P,B.dr,t,fm7M(43),bl*2.15,.03,{lp:640,a:1.6,r:2.2,vib:4})}
  /* low strings fill in the harmony under the tune */
  if(k===0&&(sec===1||sec===2)){const v=fm7Vc(c,51);fm7Bow(P,B.dr,t,fm7M(v[1]),bl*.98,.022,{lp:700,a:.6,r:1});fm7Bow(P,B.dr,t,fm7M(v[2]),bl*.98,.016,{lp:700,a:.6,r:1})}
  /* the whistled tune (an octave up) */
  for(const [s,p,len] of T.W[bar]){if(s!==k)continue;const f=fm7M(p+12);fm7Whistle(P,B.wh,t,f,len*sd*.95,.05,P.wp);P.wp=f;if(P.lp%2&&sec===1)fm7Bow(P,B.cel,t,fm7M(p-12),len*sd*.96,.035,{lp:900,a:.25,r:.5,vib:8})}
  /* the cello melody in B */
  if(sec===2)for(const [s,p,len] of T.C[bar-10]){if(s!==k)continue;fm7Bow(P,B.cel,t,fm7M(p),len*sd*.96,.07,{lp:1500,a:.18,r:.5,vib:11})}
  if(sec===2){if(k===0)fm7Drum(P,B.perc,t,.3,58,0);if(k===3)fm7Drum(P,B.perc,t,.15,62,0)}
  /* a distant foghorn, the ship's bell, creaking timber and waves breaking */
  if(k===0&&(bar===0||bar===10))fm7Fog(P,B.far,t+sd,.09,fm7M(36));
  if((bar===9&&k===3)||(bar===18&&k===0)){fm7Bell(P,B.bell,t,fm7M(72),.07,4,'ship');fm7Bell(P,B.bell,t+.32,fm7M(72),.06,4,'ship')}
  if(k===0&&fm7R()<.5)fm7Creak(P,B.amb,t+fm7R()*bl,.02);
  if(k===0&&bar%2===1)fm7N(P,B.amb,t,2.6,.05,900,'highpass',.7,1.5,P.R.bn)}};

/* ---------- players: one per playing track, each with its own fade ---------- */
function fm7Bus(P,dry,wet){const b=fm7G(P,dry,P.g);if(wet)b.connect(fm7G(P,wet,P.gw));return b}
function fm7Start(key,tid,at,fi,X,list,off){const T=FM7T[tid],R=fm7Res(X),P={key,tid,T,X,R,list,off,dead:0,sd:T.sd,stop:[],nodes:[],lp:0};
 const lv=T.gain*(off||key==='menu'?1:FM7.spot);P.g=X.createGain();P.gw=X.createGain();
 P.lv=lv;P.fs=at;P.fe=at+fi;for(const g of [P.g,P.gw]){g.gain.setValueAtTime(0,X.currentTime);g.gain.setValueAtTime(0,at);g.gain.linearRampToValueAtTime(lv,at+fi)}
 P.g.connect(R.out);P.gw.connect(fm7Rv(X,R,T.rv));P.B={};for(const k in T.bus)P.B[k]=fm7Bus(P,T.bus[k][0],T.bus[k][1]);
 let b0=0;if(!off){const sv=FM7.pos[tid]|0;for(const s of T.secs)if(s<=sv)b0=s}P.n=b0*T.spb;P.nt=at;
 T.init&&T.init(P,at);list.push(P);return P}
/* fades always restart from an explicit value: a ramp after cancelAndHoldAtTime() with no later event would start from the
   previous (long past) event and jump */
function fm7Fade(a,at,v0,v1,dur){a.cancelScheduledValues(at);a.setValueAtTime(v0,at);a.linearRampToValueAtTime(v1,at+dur)}
function fm7Kill(P,at,fo){let v;if(P.dead){if(P.ke<=at+fo)return;v=at<=P.ka?P.kv:P.kv*Math.max(0,(P.ke-at)/(P.ke-P.ka))}  /* hurry a fade already under way */
 else{P.dead=1;v=at>=P.fe?P.lv:at<=P.fs?0:P.lv*(at-P.fs)/(P.fe-P.fs);if(!P.off)FM7.pos[P.tid]=(P.n/P.T.spb)|0}
 P.ka=at;P.kv=v;P.ke=at+fo;for(const g of [P.g,P.gw])fm7Fade(g.gain,at,v,0,fo);for(const s of P.stop)try{s.stop(at+fo+.05)}catch(e){}P.end=at+fo+5}
function fm7Sched(P,until){const T=P.T,tot=T.bars*T.spb;let n=0;
 while(!P.dead&&P.nt<until&&n++<96){const bar=(P.n/T.spb)|0,k=P.n%T.spb;try{T.step(P,P.nt,bar,k)}catch(e){fm7Err(e)}P.n++;P.nt+=P.sd;
  if(P.n>=tot){if(T.alt){/* menu: hand over to the other theme exactly at the loop boundary */const at=P.nt;fm7Kill(P,at,2.5);if(!P.off){FM7.pos[P.tid]=0;FM7.menu=T.alt;FM7.cyc++}
    const Q=fm7Start(P.key,T.alt,at,.5,P.X,P.list,P.off);Q.n=0;fm7Sched(Q,until);return}P.n=0;P.lp++}}}
function fm7Err(e){if(FM7.err++<3)try{console.warn('fishing music',e)}catch(x){}}
function fm7Want(){if(typeof S==='undefined'||S.mode!=='fish')return null;if(S.view==='fish'){let k='pond';try{k=fsLoc()}catch(e){}return FM7T[k]?k:'pond'}return 'menu'}
function fm7Vol(){if(FM7.vol)FM7.vol.gain.value=(ST.mute?0:ST.mvol*.6)*FM7.lvl}
function fm7Duck(on,now){FM7.duck=on?1:0;FM7.dt=now;const a=mg.gain;fm7Fade(a,now,a.value,on?0:(ST.mute?0:ST.mvol*.6),1.2)}
function fm7Pump(){if(!ac||!mg)return;const t0=performance.now(),X=ac,now=X.currentTime;
 if(FM7.ac!==X){FM7.ac=X;FM7.P=[];FM7.vol=X.createGain();FM7.vol.connect(X.destination);const R=fm7Res(X);R.out.connect(FM7.vol);for(const k of ['room','hall','cave'])fm7Rv(X,R,k);fm7Vol()}
 const fish=S.mode==='fish';
 if(fish!==!!FM7.duck)fm7Duck(fish,now);
 else if(fish&&now-FM7.dt>1.4&&mg.gain.value>.001)mg.gain.setTargetAtTime(0,now,.2);  /* something raised the master: keep the normal score quiet */
 const key=fish&&!document.hidden&&!ST.mute&&ST.mvol>0&&fm7Res(X).ready?fm7Want():null,cur=FM7.P.find(p=>!p.dead);
 if(key){if(!cur||cur.key!==key){for(const p of FM7.P)fm7Kill(p,now,1.2);fm7Start(key,key==='menu'?FM7.menu:key,now+.06,1.2,X,FM7.P)}}
 else if(cur||FM7.P.length)for(const p of FM7.P)fm7Kill(p,now,document.hidden?.3:1.2);
 for(const p of FM7.P.slice())if(!p.dead)fm7Sched(p,now+1.1);
 if(FM7.P.some(p=>p.dead&&now>p.end))FM7.P=FM7.P.filter(p=>{if(p.dead&&now>p.end){for(const x of [p.g,p.gw,...p.nodes])try{x.disconnect()}catch(e){}return false}return true});
 const ms=performance.now()-t0,C=FM7.cpu;C.n++;C.ms+=ms;if(ms>C.max)C.max=ms}
/* what is playing now (for tests and the dev tools) */
function fm7Now(){const p=FM7.P.find(q=>!q.dead);return p?{key:p.key,track:p.tid,bar:(p.n/p.T.spb)|0}:null}
{const n0=note;note=function(t,n){try{fm7Pump()}catch(e){fm7Err(e)}if(S.mode==='fish'&&FM7.ac===ac)return;return n0(t,n)}}
{const a0=applyVol;applyVol=function(){const r=a0.apply(this,arguments);try{fm7Vol();if(FM7.duck&&mg&&ac){mg.gain.cancelScheduledValues(ac.currentTime);mg.gain.value=0}}catch(e){}return r}}
document.addEventListener('visibilitychange',()=>{try{fm7Pump()}catch(e){}});
{const s0=show;show=function(){const r=s0.apply(this,arguments);try{if(ac&&FM7.ac===ac)setTimeout(()=>{try{fm7Pump()}catch(e){}},0)}catch(e){}return r}}
