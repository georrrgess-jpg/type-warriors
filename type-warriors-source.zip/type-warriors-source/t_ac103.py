# python3 t_ac103.py [game.html] : 10.1h save integrity (98t, 98v, 00a). Runs with window.TW_AC_TEST so the guard is enforced under
# automation. Checks: the device key is a non-extractable key object (no readable key left in IndexedDB), a 10.1g browser moves over
# to it and keeps its progress, a forged save written with a made-up "other tab" storage event is still undone, coins / XP cannot be
# set by scheduling a built-in function on a timer or promise, the game still pays, an exported file re-imports on the same device,
# an edited (re-signed) export counts as unverified and is capped, and no page errors.
import asyncio,os,sys,shutil,subprocess,tempfile
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
NEW=os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:400]),flush=True)
    if not ok:FAIL.append(name)
FORGE=r"""(function(){const SK=[116,119,45,107,101,101,112,45,51,57,49,55,45,114,117,110,101,115,116,111,110,101].map((c,i)=>String.fromCharCode(c^((i*7)&3))).join('');
function mac(v){const s=SK+'|'+v+'|'+SK.length;let a=0x6b2fe4c1^s.length,b=0x9e3779b9,c=0x1f83d9ab;for(let i=0;i<s.length;i++){const k=s.charCodeAt(i);a=Math.imul(a^k,2654435761);b=Math.imul(b^k,1597334677)^(a>>>15);c=Math.imul(c+k,0x27d4eb2f)^(b>>>13)}
a=Math.imul(a^(a>>>16),2246822507)^Math.imul(b^(b>>>13),3266489909);b=Math.imul(b^(b>>>16),2246822507)^Math.imul(c^(c>>>13),3266489909);c=Math.imul(c^(c>>>15),0x85ebca6b)^a;return [a,b,c].map(v=>(v>>>0).toString(16).padStart(8,'0')).join('')}
window.twForge=function(gold,xp){const K='typeWarriorsSave',before=localStorage.getItem(K);if(!before)return 'nosave';const n=JSON.parse(before);n.gold=gold;n.xp=xp;n.xpv=3;const u=JSON.stringify(n);
 const g=Math.round(+n.gold||0),x=Math.round(+n.xp||0),p=n.pres|0;localStorage.setItem(K,u);localStorage.setItem('typeWarriorsAux',JSON.stringify({m:mac('s|'+u),g,x,p,a:mac('a|'+g+'|'+x+'|'+p)}));return 'ok'}})();"""
WIN="()=>{RS_ASK=false;WCRELAYS=[];RPP();rpStart('moss');RPX.tut=null;RPX.won=true;RPX.free=false;RPX.wave=RPX.map.waves;setTimeout(rpFinish,0,true)}"
async def ready(pg):
    for _ in range(60):
        if await pg.evaluate("()=>typeof TWAC2!=='undefined'&&TWAC2.stat().ready===1"):return True
        await pg.wait_for_timeout(100)
    return False
IDB="()=>new Promise(res=>{const q=indexedDB.open('typeWarriorsK',1);q.onupgradeneeded=()=>{try{q.result.createObjectStore('k')}catch(e){}};q.onsuccess=()=>{const db=q.result,t=db.transaction('k','readonly'),s=t.objectStore('k'),a=s.get('dk'),b=s.get('dk3');t.oncomplete=()=>{db.close();const k=b.result;res([typeof a.result,!!k&&typeof k==='object',k?k.extractable:null,k?k.type:null])}}})"
async def main():
    td=tempfile.mkdtemp();old=os.path.join(td,'old.html');new=os.path.join(td,'new.html');shutil.copy(NEW,new)
    root=os.path.abspath(os.path.join(HERE,'..'))
    open(old,'wb').write(subprocess.run(['git','-C',root,'show','fe3003c:type-warriors.html'],capture_output=True).stdout)
    cf=os.path.join(td,'tool.js');open(cf,'w').write(FORGE)
    async with async_playwright() as p:
        b=await p.chromium.launch()
        # 1-2. a browser that ran 10.1g (readable key) moves to the key object and keeps its progress
        ctx=await b.new_context(viewport={'width':1600,'height':900});await ctx.add_init_script('window.TW_AC_TEST=1')
        pg=await ctx.new_page();er=[];pg.on('pageerror',lambda e:er.append(str(e)[:300]));E=pg.evaluate
        await pg.goto('file://'+old);await pg.wait_for_timeout(1300);await ready(pg)
        await E(WIN);await pg.wait_for_timeout(2500);await E("()=>{try{rpLeave()}catch(e){}title()}");await pg.wait_for_timeout(400)
        g1=await E("()=>[P.gold,P.xp]");k1=await E(IDB)
        er.clear();await pg.goto('file://'+new);await pg.wait_for_timeout(1300);await ready(pg);await pg.wait_for_timeout(300)
        r=await E("()=>[P.gold,P.xp,TWAC2.stat().edited,TWAC2.stat().ck]");k2=await E(IDB)
        chk('a 10.1g browser moves to the new device key and keeps its coins and level',k1[0]=='string' and r==[g1[0],g1[1],0,1],[g1,k1,r])
        chk('the device key is a key object that cannot be read out, and the old readable key is gone',k2==['undefined',True,False,'secret'],k2)
        await pg.reload();await pg.wait_for_timeout(1300);await ready(pg)
        r=await E("()=>[P.gold,P.xp,TWAC2.stat().edited]")
        chk('a normal reload with the key object keeps everything',r==[g1[0],g1[1],0],[g1,r])
        # 3. a forged write announced by a made-up storage event is still undone before the reload
        await pg.add_script_tag(path=cf)
        await E("()=>{twForge(999999999,lvx(30));window.dispatchEvent(new StorageEvent('storage',{key:KEY,newValue:localStorage.getItem(KEY),storageArea:localStorage,url:location.href}));SGS.lock=true;location.reload()}")
        await pg.wait_for_timeout(1500);await ready(pg)
        r=await E("()=>[P.gold,P.xp,JSON.parse(localStorage.getItem(KEY)).gold]")
        chk('a forged save with a made-up "other tab" event is undone (real coins and level after the reload)',r==[g1[0],g1[1],g1[0]],[g1,r])
        # 4. coins / XP set by a timer or promise scheduled straight onto a built-in function are refused
        r=await E("""()=>new Promise(res=>{const g=P.gold,x=P.xp;setTimeout(Reflect.set,0,P,'gold',123456789);setTimeout(Reflect.set.bind(null,P,'gold',223456789),0);
          Promise.resolve().then(Reflect.set.bind(null,P,'xp',99999999));queueMicrotask(Reflect.set.bind(null,P,'pres',9));setTimeout(()=>res([g,x,P.gold,P.xp,P.pres|0]),80)})""")
        chk('coins / XP / prestige cannot be set through a timer or promise on a built-in function',r[2]==r[0] and r[3]==r[1] and r[4]==0,r)
        # 5. the game itself still pays
        g0=await E("()=>P.gold");await E(WIN);await pg.wait_for_timeout(2500);g2=await E("()=>P.gold")
        chk('the game still pays a map win',g2>g0,[g0,g2])
        await E("()=>{try{rpLeave()}catch(e){}title()}");await pg.wait_for_timeout(300)
        # 6-7. exports: the same device re-imports its own file; an edited, re-signed file is capped
        r=await E("()=>{const txt=JSON.stringify(sgPack());const a=sgRead(txt);return [a.ok,!!a.keyed,!!a.capped,a.P.gold===P.gold,typeof JSON.parse(txt).dm]}")
        chk('an exported file re-imports on the same device as verified',r==[True,True,False,True,'string'],r)
        r=await E("""()=>{const o=sgPack();const q=JSON.parse(o.payload);q.gold=500000000;q.xp=lvx(30);o.payload=JSON.stringify(q);o.sum=sgHash(o.payload);delete o.dm;
          const SK=[116,119,45,107,101,101,112,45,51,57,49,55,45,114,117,110,101,115,116,111,110,101].map((c,i)=>String.fromCharCode(c^((i*7)&3))).join('');
          function mac(v){const s=SK+'|'+v+'|'+SK.length;let a=0x6b2fe4c1^s.length,b=0x9e3779b9,c=0x1f83d9ab;for(let i=0;i<s.length;i++){const k=s.charCodeAt(i);a=Math.imul(a^k,2654435761);b=Math.imul(b^k,1597334677)^(a>>>15);c=Math.imul(c+k,0x27d4eb2f)^(b>>>13)}
          a=Math.imul(a^(a>>>16),2246822507)^Math.imul(b^(b>>>13),3266489909);b=Math.imul(b^(b>>>16),2246822507)^Math.imul(c^(c>>>13),3266489909);c=Math.imul(c^(c>>>15),0x85ebca6b)^a;return [a,b,c].map(v=>(v>>>0).toString(16).padStart(8,'0')).join('')}
          o.mac=mac('x|'+o.payload);const a=sgRead(JSON.stringify(o));return [a.ok,!!a.keyed,!!a.capped,a.P.gold<=Math.max(P.gold,25000),lvl(a.P.xp)<=Math.max(lvl(P.xp),8)]}""")
        chk('an edited export re-signed with the old checksum counts as unverified and is capped',r==[True,False,True,True,True],r)
        chk('no page errors',not er,er)
        await ctx.close();await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
