/* ===== 9.7 THE CROOKED CUE: the Trick Shots chalkboard (96zh) =====
   The owner's concept "2C". A chalkboard holds the trick shots as little tables (baked felt and rails, the real ball positions from
   PZ_TRICK, the cue-ball finish area where a goal has one) on a dashed chalk loop, each with a gold number, its name and 3 stars.
   Granny Moldwick leans on the counter at the left with her cue and a tankard. The header pill counts the stars and states the rules;
   the bar along the bottom shows the picked trick (bigger table, number, name, goal, hint once tried, the +200 bounty, its stars) and
   a big Start. Click a table to pick it, click it again (or Start, Enter) to play. Keys: arrows, 1-9 and 0, Enter, Esc.
   More than ten tricks page with arrows. Replaces the whole pzTrick chain (96o, 96t, 96u, 96za) and re-adds the tour and the back wiring.
   Everything is baked once; per frame only Granny draws (slow 2). */
const PZ97T={sel:null,seen:{},mini:{},board:null,bgc:null,page:0};
/* card centres on the board (board origin 402,177; the concept's winding layout), and the board size */
const PZ97T_POS=[[134,108],[356,99],[576,94],[801,106],[1022,134],[141,318],[347,309],[560,316],[788,328],[1010,326]],PZ97T_BW=1177,PZ97T_BH=483;
const pz97Star=(cls,d)=>`<svg class="pz97st ${cls||''}" viewBox="0 0 24 24"${d!=null?` style="--d:${d}s"`:''}><path d="M12 1.8l3 6.5 7.1.8-5.3 4.8 1.5 7L12 17.3l-6.3 3.6 1.5-7L1.9 9.1 9 8.3z"/></svg>`;
/* a top-down table, baked once per size and felt: w x h css pixels at 2x, rail r */
function pz97Mini(w,h,r){const Z=PZS(),key=w+'x'+h+Z.felt;if(PZ97T.mini[key])return PZ97T.mini[key];const F=PZ_FELT.find(f=>f.id===Z.felt)||PZ_FELT[0],c=pzCv(w*2,h*2),g=c.getContext('2d');g.scale(2,2);g.lineJoin='round';
 g.fillStyle='rgba(0,0,0,.35)';pzRR(g,2,4,w-2,h-3,r*.9);g.fill();
 g.fillStyle=pzLin(g,0,0,0,h,[[0,'#b0642c'],[.5,'#8a4a1c'],[1,'#5a2c10']]);pzRR(g,1.5,1.5,w-3,h-4,r*.9);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2.5;g.stroke();
 g.strokeStyle='rgba(255,220,170,.35)';g.lineWidth=1.2;pzRR(g,4,4,w-8,h-10,r*.7);g.stroke();
 const fx=r,fy=r,fw=w-2*r,fh=h-2*r-1;g.fillStyle=pzMix(F.c,'#000000',.3);g.fillRect(fx-2,fy-2,fw+4,fh+4);
 const q=g.createRadialGradient(fx+fw/2,fy+fh*.45,4,fx+fw/2,fy+fh/2,fw*.62);q.addColorStop(0,pzMix(F.a,'#ffffff',.14));q.addColorStop(.6,F.a);q.addColorStop(1,F.c);g.fillStyle=q;g.fillRect(fx,fy,fw,fh);
 g.strokeStyle='rgba(0,0,0,.35)';g.lineWidth=1;g.strokeRect(fx+.5,fy+.5,fw-1,fh-1);
 const pr=Math.max(3.2,r*.42);for(const [u,v] of[[0,0],[.5,0],[1,0],[0,1],[.5,1],[1,1]]){const x=fx+u*fw+(u===0?1:u===1?-1:0),y=fy+v*fh+(v?-0:0)+(v===0?1:-1);g.fillStyle='#2a1206';g.beginPath();g.arc(x,y,pr+1.6,0,TAU);g.fill();g.fillStyle='#050208';g.beginPath();g.arc(x,y,pr,0,TAU);g.fill()}
 g.fillStyle='rgba(255,240,200,.7)';for(const u of[.25,.75])for(const v of[0,1]){g.beginPath();g.arc(fx+u*fw,v?h-r*.5-1:r*.5,1.1,0,TAU);g.fill()}
 return PZ97T.mini[key]=c}
/* one trick's table: the baked table plus the balls (imgs from the player's set) and the cue-ball finish area */
function pz97TFelt(t,cls,bp){const zone=t.goal.cueIn?`<u class="pz97zone" style="left:${t.goal.cueIn[0]/8.8}%;top:${t.goal.cueIn[1]/4.4}%;width:${(t.goal.cueIn[2]-t.goal.cueIn[0])/8.8}%;height:${(t.goal.cueIn[3]-t.goal.cueIn[1])/4.4}%"></u>`:'';
 return `<div class="${cls}">${zone}${t.balls.map(([id,x,y])=>`<img src="${pzbIcon(id,bp)}" style="left:${x/8.8}%;top:${y/4.4}%" alt="${id}">`).join('')}<img class="cue" src="${pzbIcon(0,bp)}" style="left:${t.cue[0]/8.8}%;top:${t.cue[1]/4.4}%" alt="cue ball"></div>`}
/* the chalkboard: wooden frame, slate with chalk smudges, the dashed loop between the tables, the chalk tray */
function pz97Board(){if(PZ97T.board)return PZ97T.board;const W=PZ97T_BW,H=PZ97T_BH,c=pzCv(W,H),g=c.getContext('2d');g.lineJoin='round';g.lineCap='round';
 g.fillStyle='rgba(0,0,0,.45)';pzRR(g,8,14,W-8,H-12,20);g.fill();
 g.fillStyle=pzLin(g,0,0,0,H,[[0,'#9a5424'],[.5,'#7a3e18'],[1,'#5a2c10']]);pzRR(g,2,2,W-6,H-10,20);g.fill();g.strokeStyle=PZ_O;g.lineWidth=4;g.stroke();
 for(let i=0;i<26;i++){g.strokeStyle=`rgba(40,16,4,${.18+pzNoise(i)*.2})`;g.lineWidth=1.4;g.beginPath();const y=8+pzNoise(i+5)*14;g.moveTo(20+i*45,y);g.quadraticCurveTo(40+i*45,y+4,64+i*45,y);g.stroke()}
 g.strokeStyle='rgba(255,220,170,.35)';g.lineWidth=2;pzRR(g,6,6,W-14,H-18,17);g.stroke();
 const sx=20,sy=20,sw=W-46,sh=H-52;g.fillStyle='#0e2018';pzRR(g,sx-3,sy-3,sw+6,sh+6,10);g.fill();
 const q=g.createRadialGradient(W/2,H*.42,40,W/2,H/2,W*.62);q.addColorStop(0,'#2a4a38');q.addColorStop(.6,'#1f3a2c');q.addColorStop(1,'#14281e');g.fillStyle=q;pzRR(g,sx,sy,sw,sh,8);g.fill();
 g.save();pzRR(g,sx,sy,sw,sh,8);g.clip();
 for(let i=0;i<16;i++){const x=sx+pzNoise(i*3+1)*sw,y=sy+pzNoise(i*7+2)*sh,rx=60+pzNoise(i+11)*160,ry=20+pzNoise(i+13)*50;g.fillStyle=`rgba(230,240,230,${.025+pzNoise(i+17)*.035})`;g.beginPath();g.ellipse(x,y,rx,ry,pzNoise(i+19)*.6-.3,0,TAU);g.fill()}
 for(let i=0;i<14;i++){const x=sx+pzNoise(i*5+3)*sw,y=sy+pzNoise(i*9+4)*sh;g.strokeStyle=`rgba(230,240,230,${.04+pzNoise(i+23)*.05})`;g.lineWidth=10+pzNoise(i)*14;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+60,y+(pzNoise(i+29)-.5)*40,x+120+pzNoise(i+31)*80,y+(pzNoise(i+37)-.5)*30);g.stroke()}
 for(let i=0;i<900;i++){g.fillStyle=`rgba(255,255,255,${.03+pzNoise(i+41)*.05})`;g.fillRect(sx+pzNoise(i+43)*sw,sy+pzNoise(i+47)*sh,1.2,1.2)}
 /* the dashed chalk loop */
 const P=PZ97T_POS,hw=74;g.strokeStyle='rgba(240,244,236,.62)';g.lineWidth=3.2;g.setLineDash([13,9]);
 const seg=(a,b)=>{const x0=a[0]+hw,y0=a[1],x1=b[0]-hw,y1=b[1],mx=(x0+x1)/2,my=(y0+y1)/2+((y1>y0)?-6:6);g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo(mx,my,x1,y1);g.stroke()};
 for(let i=0;i<4;i++){seg(P[i],P[i+1]);seg(P[i+5],P[i+6])}
 g.beginPath();g.moveTo(P[4][0]+hw,P[4][1]+4);g.bezierCurveTo(P[4][0]+hw+70,P[4][1]+30,P[9][0]+hw+80,P[9][1]-60,P[9][0]+hw,P[9][1]);g.stroke();
 g.beginPath();g.moveTo(P[5][0]-hw,P[5][1]);g.bezierCurveTo(P[5][0]-hw-60,P[5][1]-50,P[0][0]-hw-64,P[0][1]+70,P[0][0]-hw,P[0][1]+6);g.stroke();g.setLineDash([]);
 /* a few chalk doodles in the gaps: a ball with a motion line, tally marks, an arrow into a pocket */
 g.strokeStyle='rgba(240,244,236,.28)';g.lineWidth=2.2;g.beginPath();g.arc(690,228,12,0,TAU);g.stroke();g.beginPath();g.arc(690,228,4,0,TAU);g.stroke();for(const d of[0,8,16]){g.beginPath();g.moveTo(668-d*1.6,222+d*.3);g.lineTo(652-d*2.4,222+d*.3);g.stroke()}
 for(let k=0;k<4;k++){g.beginPath();g.moveTo(920+k*9,226);g.lineTo(922+k*9,250);g.stroke()}g.beginPath();g.moveTo(914,246);g.lineTo(956,230);g.stroke();
 g.beginPath();g.moveTo(240,420);g.quadraticCurveTo(262,398,292,404);g.stroke();g.beginPath();g.moveTo(284,396);g.lineTo(293,404);g.lineTo(282,410);g.stroke();
 g.restore();
 g.strokeStyle='rgba(0,0,0,.5)';g.lineWidth=3;pzRR(g,sx,sy,sw,sh,8);g.stroke();
 /* the chalk tray with a stick of chalk and a felt eraser */
 const ty=H-32;g.fillStyle=pzLin(g,0,ty,0,ty+20,[[0,'#b06a30'],[1,'#6a3412']]);pzRR(g,14,ty,W-34,16,6);g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();
 g.fillStyle='#f4f0e6';pzRR(g,652,ty-7,40,9,4);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2;g.stroke();g.fillStyle='#8adcff';pzRR(g,702,ty-6,26,8,4);g.fill();g.stroke();
 g.fillStyle='#3a2a6a';pzRR(g,436,ty-13,66,15,4);g.fill();g.stroke();g.fillStyle='#c8b890';pzRR(g,438,ty-4,62,6,2);g.fill();
 return PZ97T.board=c}
/* the tavern behind the board: the shared bake with the string lights lit and a wall lantern */
function pz97TBg(){if(PZ97T.bgc)return PZ97T.bgc;const c=pzCv(1600,900),g=c.getContext('2d');g.lineJoin='round';g.lineCap='round';g.drawImage(pzHubBake(),0,0);pz97Bg();
 pzGlow(g,800,40,700,'rgba(255,170,90,1)',.08);
 for(const [x,y] of PZ97.bulbs){pzGlow(g,x,y+4,34,'rgba(255,200,110,1)',.55);g.fillStyle='#2a1a0a';g.fillRect(x-3,y-6,6,6);g.fillStyle='#ffe9a8';g.beginPath();g.ellipse(x,y+4,5,7,0,0,TAU);g.fill();g.strokeStyle='rgba(18,8,31,.7)';g.lineWidth=1.5;g.stroke();g.fillStyle='#fff';g.beginPath();g.arc(x-1.5,y+2,1.6,0,TAU);g.fill()}
 for(let i=0;i<10;i++){const x=i*40;g.fillStyle=pzMix('#2e1a10','#3e2214',pzNoise(i+5));g.fillRect(x,140,38,500);g.fillStyle='rgba(0,0,0,.42)';g.fillRect(x+38,140,2,500)}
 g.fillStyle=pzLin(g,0,140,0,200,[[0,'rgba(8,4,12,.7)'],[1,'rgba(8,4,12,0)']]);g.fillRect(0,140,400,60);
 {const y=232;g.fillStyle='#5a3418';g.fillRect(96,y,290,12);g.strokeStyle=PZ_O;g.lineWidth=3;g.strokeRect(96,y,290,12);g.fillStyle='rgba(255,210,150,.18)';g.fillRect(98,y+1,286,2);
  const bc=['#3aa85a','#c83a3a','#7ad8ff','#d8a03a','#9a5ad8'];for(let i=0;i<6;i++){const x=116+i*22,h=34+pzNoise(i+61)*18;g.globalAlpha=.85;g.fillStyle=bc[i%5];pzRR(g,x,y-h,15,h,4);g.fill();pzRR(g,x+5,y-h-10,5,12,2);g.fill();g.globalAlpha=1;g.strokeStyle=PZ_O;g.lineWidth=2;pzRR(g,x,y-h,15,h,4);g.stroke();g.fillStyle='rgba(255,255,255,.35)';g.fillRect(x+3,y-h+5,2,h-10)}
  for(let i=0;i<5;i++){const x=270+i*15,h=36+pzNoise(i+71)*14;g.fillStyle=['#7a2a3a','#2a4a8a','#5a7a2a','#8a5a1a','#4a2a6a'][i];g.fillRect(x,y-h,13,h);g.strokeStyle=PZ_O;g.lineWidth=2;g.strokeRect(x,y-h,13,h);g.fillStyle='rgba(255,230,180,.35)';g.fillRect(x+3,y-h+6,7,2)}}
 pz97Sconce(g,42,214);pzGlow(g,42,214,240,'rgba(255,150,70,1)',.2);
 return PZ97T.bgc=c}
/* ---------- the screen ---------- */
function pz97TrickScreen(){PZ.on=false;PZ.hub=true;CAS.on=true;CAS.key=null;CAS.tok++;pzCastInit('moldwick');try{pzMusicOn()}catch(e){}const Z=PZS();pzbSetup(52,Z.balls);
 const N=PZ_TRICK.length,pages=Math.ceil(N/10),total=pzTrickTotal(),rm=pzRM();
 if(PZ97T.sel==null||PZ97T.sel>=N){const nx=PZ_TRICK.findIndex((t,i)=>pzTrickStars(i)<3);PZ97T.sel=nx<0?0:nx}
 const page=PZ97T.page=Math.floor(PZ97T.sel/10),first=page*10,last=Math.min(N,first+10);
 const cards=[];for(let i=first;i<last;i++){const t=PZ_TRICK[i],s=pzTrickStars(i),[cx,cy]=PZ97T_POS[i-first],old=PZ97T.seen[i]==null?s:PZ97T.seen[i];
  cards.push(`<button class="pzti pz97tc ${i===PZ97T.sel?'sel':''} ${s===3?'done':''}" data-i="${i}" style="left:${cx-82}px;top:${cy-50}px;--k:${i-first}" aria-label="Trick shot ${i+1}: ${t.n}, ${s} of 3 stars">
   <span class="pztm pz97mtw"><canvas class="pz97mt" width="296" height="176"></canvas>${pz97TFelt(t,'pztf',10)}<i class="pz97ring"></i></span><span class="pz97nb">${i+1}</span>
   <b>${t.n}</b><em class="st${s}">${[0,1,2].map(k=>pz97Star(k<s?(k>=old?'on new':'on'):'',.35+k*.12)).join('')}</em></button>`)}
 for(let i=first;i<last;i++)PZ97T.seen[i]=pzTrickStars(i);
 const arrows=pages>1?`<button class="pz97pg l" id="pz97pl" ${page===0?'disabled':''} aria-label="Previous trick shots">‹</button><button class="pz97pg r" id="pz97pr" ${page>=pages-1?'disabled':''} aria-label="More trick shots">›</button><div class="pz97dots">${Array.from({length:pages},(_,k)=>`<i class="${k===page?'on':''}"></i>`).join('')}</div>`:'';
 const orn=f=>{const curl='M84 22c8-14 26-14 30-4 3 8-6 12-10 7M84 22c8 14 26 14 30 4 3-8-6-12-10-7M40 22h46';return `<svg class="pz97orn ${f?'f':''}" viewBox="0 0 124 44"><path d="${curl}" fill="none" stroke="#12081f" stroke-width="10" stroke-linecap="round"/><path d="M6 22 34 12q8 10 0 20z" fill="#ffd45a" stroke="#12081f" stroke-width="3.5" stroke-linejoin="round"/><path d="${curl}" fill="none" stroke="#ffd45a" stroke-width="5" stroke-linecap="round"/><path d="M62 13l8 9-8 9-8-9z" fill="#fff2b0" stroke="#12081f" stroke-width="3" stroke-linejoin="round"/><path d="M12 22h18" stroke="#c88a1a" stroke-width="2"/></svg>`};
 show(`<div class="pzk pzt97 pzin${rm?' rm':''}" id="pzk"><canvas id="pzkbg" width="1600" height="900"></canvas><canvas class="pz97tw a" width="1600" height="100"></canvas><canvas class="pz97tw b" width="1600" height="100"></canvas>
  <button class="pzback" id="pzbk">‹&nbsp; The bar</button><div class="pzgold"><i></i><b>${cmn(P.gold)}</b></div>
  <div class="pz97tt">${orn(0)}<span>Trick Shots</span>${orn(1)}</div>
  <div class="pz97tp" id="pz97tp"><span class="pz97tps">${pz97Star('on')}<span><b>${total}</b> of ${N*3} stars</span></span><span class="pz97tpr"><b>3 stars</b> within 3 tries, <b>2 stars</b> within 8 tries. First time 3 stars earns <b>200 gold</b>.</span></div>
  <canvas id="pz97gr" width="400" height="360"></canvas><div class="pz97gb" id="pz97gb"></div><button class="pz97grb" id="pz97grb" aria-label="Granny Moldwick"></button>
  <div class="pz97bd" id="pz97bd"><canvas class="pz97bdc" width="${PZ97T_BW}" height="${PZ97T_BH}"></canvas>${cards.join('')}${arrows}</div>
  <div class="pz97tb" id="pz97tb"></div></div>`,'casbg pzx');
 const root=$('pzk');$('pzkbg').getContext('2d').drawImage(pz97TBg(),0,0);root.querySelectorAll('.pz97tw').forEach((c,i)=>c.getContext('2d').drawImage(pz97Twinkle(i),0,0));
 root.querySelector('.pz97bdc').getContext('2d').drawImage(pz97Board(),0,0);
 const mini=pz97Mini(148,88,11);root.querySelectorAll('.pz97mt').forEach(cv=>cv.getContext('2d').drawImage(mini,0,0));
 /* Granny at the counter: her signature cue against the wall, a tankard by the board; she hops when you pick a shot */
 const gc=$('pz97gr'),gg=gc.getContext('2d');gg.lineJoin='round';gg.lineCap='round';const gb=pzMonBox('moldwick'),gs=1,gex=Object.assign(pzCastEx(),PZ_EXP.happy);PZ97T.hop=0;PZ97T.gex=gex;
 let cue=null;try{cue=pzCueSprite('mycelium')}catch(e){}
 const drawG=()=>{if(!gc.isConnected)return;const t=performance.now()/1000;gg.clearRect(0,0,400,360);
  if(cue){gg.save();gg.translate(40,332);gg.rotate(-Math.PI/2+.08);gg.scale(.42,.52);gg.drawImage(cue.c,0,-cue.H/2);gg.restore()}
  const hp=PZ97T.hop&&t-PZ97T.hop<.5?-Math.sin((t-PZ97T.hop)/.5*Math.PI)*14:0;if(PZ97T.hop&&t-PZ97T.hop>1.4){Object.assign(gex,PZ_EXP.happy);PZ97T.hop=0}
  gg.save();gg.translate(190-(gb.x0+gb.x1)/2*gs,-6+hp+372*gs);gg.scale(gs,gs);pzMon.moldwick(gg,t,gex,{breath:Math.sin(t*2)*.014,tilt:Math.sin(t*.8)*.025,bob:Math.sin(t*1.6)*1.2,hop:0});gg.restore();
  gg.fillStyle=pzLin(gg,0,300,0,360,[[0,'#a85e2a'],[.2,'#7a3e18'],[1,'#3a1a08']]);pzRR(gg,-10,296,420,80,12);gg.fill();gg.strokeStyle=PZ_O;gg.lineWidth=3.5;gg.stroke();gg.fillStyle='rgba(255,220,170,.32)';gg.fillRect(0,300,400,2.5);
  for(let k=0;k<4;k++){gg.strokeStyle='rgba(40,16,4,.4)';gg.lineWidth=2;gg.beginPath();gg.moveTo(20+k*100,318);gg.quadraticCurveTo(60+k*100,324,96+k*100,318);gg.stroke()}
  pz97Mug(gg,350,300,1.05)};
 gc.style.transform='';LIVE.push({cv:gc,fn:drawG,slow:2,ph:0});drawG();
 $('pz97grb').onclick=()=>{pzFx('tick');pz97TSay(true)};
 root.querySelectorAll('.pz97tc').forEach(b=>b.onclick=()=>{const i=+b.dataset.i;if(i===PZ97T.sel)pz97TStart();else pz97TSel(i)});
 {const l=$('pz97pl'),r=$('pz97pr');if(l)l.onclick=()=>{pz97TSel(Math.max(0,first-10))};if(r)r.onclick=()=>{pz97TSel(Math.min(N-1,first+10))}}
 const back=()=>pzGo(pzHub);$('pzbk').onclick=back;S.back=back;
 pz97TBar(true);pz97TSay(false,true);
 setTimeout(()=>{const k=$('pzk');if(k)k.classList.remove('pzin')},1500);
 try{const s=root.querySelector('.pz97tc.sel');if(s)s.focus({preventScroll:true})}catch(e){}
 pzFitTM();pz97TTour()}
/* the bar along the bottom: the picked trick */
function pz97TBar(first){const el=$('pz97tb');if(!el)return;const i=PZ97T.sel,t=PZ_TRICK[i],Z=PZS(),s=pzTrickStars(i),tried=s>0||!!Z.trick['t'+i],bounty=!Z.trick['$'+i];
 el.innerHTML=`<div class="pz97pv ${first?'':'swap'}"><span class="pz97pvt"><canvas class="pz97pvc" width="532" height="280"></canvas>${pz97TFelt(t,'pz97pvf',16)}</span></div>
  <div class="pz97ti ${first?'':'swap'}"><div class="pz97tih"><span class="pz97nb big">${i+1}</span><b>${t.n}</b></div><p>${pzTrickGoalText(t)}.</p><small>${tried?`<i>Granny's hint:</i> ${t.hint}`:'Granny gives you a hint at the table.'}</small></div>
  <i class="pz97tsep"></i><div class="pz97tst ${first?'':'swap'}"><div>${[0,1,2].map(k=>pz97Star(k<s?'on':'',.08+k*.08)).join('')}</div><small>${s===3?'Perfect!':bounty?'<b>+200 gold</b> for 3 stars':'Bounty claimed'}</small></div>
  <button class="pz97go" id="pz97start"><span>${s===3?'Play again':'Start'}</span><kbd>Enter</kbd><i class="pzshine"></i></button>`;
 el.querySelector('.pz97pvc').getContext('2d').drawImage(pz97Mini(266,140,15),0,0);
 $('pz97start').onclick=()=>pz97TStart()}
/* Granny's line: a short reaction to the pick (hidden while the tour talks) */
function pz97TSay(poke,first){const b=$('pz97gb');if(!b)return;const i=PZ97T.sel,s=pzTrickStars(i),Z=PZS(),t=PZ_TRICK[i];
 const L=first?['Fancy a trick shot, dear?','Pick a table, dear. Any table.']:s===3?['Show-off. Try another!','That one is all yours, dear.']:Z.trick['t'+i]?['Back for more? Good.','Chin up. You nearly had it.']:['Ooh, a good one.','Take your time, dear.','One shot. Make it count.'];
 const line=poke?["Careful with my cue, dear.","Eyes on the table, sweetheart.","I used to play for keeps, you know."][Math.floor(Math.random()*3)]:L[(i+(first?0:1))%L.length];
 b.textContent=line;b.classList.remove('on');void b.offsetWidth;b.classList.toggle('hide',pzCoachActive());clearTimeout(PZ97T.sayT);
 const show=()=>{if(!b.isConnected)return;b.classList.add('on');PZ97T.sayT=setTimeout(()=>{if(b.isConnected)b.classList.remove('on')},3600)};if(first&&!pzRM())PZ97T.sayT=setTimeout(show,750);else show();
 if(!first&&!pzRM()){PZ97T.hop=performance.now()/1000;if(PZ97T.gex)Object.assign(PZ97T.gex,PZ_EXP[s===3?'smug':'happy'])}}
/* pick a trick (another page re-renders the board) */
function pz97TSel(i){const N=PZ_TRICK.length;if(!(i>=0&&i<N)||i===PZ97T.sel)return;const pg=Math.floor(i/10);PZ97T.sel=i;pzFx('tick');
 if(pg!==PZ97T.page){pz97TrickScreen();return}
 ov.querySelectorAll('.pz97tc').forEach(b=>b.classList.toggle('sel',+b.dataset.i===i));pz97TBar(false);pz97TSay(false);
 try{const s=ov.querySelector('.pz97tc.sel');if(s)s.focus({preventScroll:true})}catch(e){}}
function pz97TStart(){const i=PZ97T.sel;if(!(i>=0&&i<PZ_TRICK.length)||!$('pz97tb'))return;pzFx('tick');pzMusicOff();pzStart({trick:i})}
/* the first-visit tour: Granny explains, then the stars and gold (2 steps, as before) */
function pz97TTour(){const Z=PZS(),tk=PZ.tok;if(Z.tut.trick)return;setTimeout(()=>{if(PZ.tok!==tk||pzCoachActive()||!ov.querySelector('.pz97tc'))return;
 const ok=pzCoach('trick',[
  {sel:()=>({x:84,y:398,w:212,h:150}),round:true,nodim:true,side:'top',w:310,title:'Trick Shots',text:'One shot. One goal. Misses reset the balls. Pick a table on the board, then press <b>Start</b>.'},
  {sel:'#pz97tp',side:'bottom',w:420,title:'Stars and gold',text:'Make it within <b>3 tries</b> for 3 stars, within 8 for 2. Your first 3 stars on a puzzle pay <b>200 gold</b>. Granny gives you a hint at the table.'}
 ],{kicker:'FIRST VISIT',onEnd:()=>{const b=$('pz97gb');if(b)b.classList.remove('hide')}});
 if(ok){const b=$('pz97gb');if(b)b.classList.add('hide')}},900)}
/* the whole old chain (96o list, 96t back wiring, 96u tour, 96za tags) is replaced by the board */
pzTrick=function(){return pz97TrickScreen()};
{const f0=pzTrickStart;pzTrickStart=function(n){const r=f0.apply(this,arguments);if(r)PZ97T.sel=n;return r}}
/* keys on the board */
if(!window.__pz97TKeys){window.__pz97TKeys=1;addEventListener('keydown',e=>{try{const r=$('pzk');if(!r||!r.classList.contains('pzt97')||PZ.on||PZ.modal||pzCoachActive())return;if(document.activeElement&&/INPUT|TEXTAREA/.test(document.activeElement.tagName))return;if(e.ctrlKey||e.metaKey||e.altKey)return;
 const k=e.key,N=PZ_TRICK.length;let i=PZ97T.sel;
 if(k==='Enter'||k===' '){e.preventDefault();if(!e.repeat)pz97TStart();return}
 if(k==='ArrowRight')i++;else if(k==='ArrowLeft')i--;else if(k==='ArrowDown')i+=5;else if(k==='ArrowUp')i-=5;else if(k==='PageDown')i+=10;else if(k==='PageUp')i-=10;else if(/^[0-9]$/.test(k))i=PZ97T.page*10+(k==='0'?9:+k-1);else return;
 e.preventDefault();i=Math.max(0,Math.min(N-1,i));if(i!==PZ97T.sel)pz97TSel(i)}catch(err){}})}
{const st=document.createElement('style');st.textContent=`
.pzt97>canvas.pz97tw{height:100px;opacity:.15;animation:pz97tw 2.8s ease-in-out infinite}.pzt97>canvas.pz97tw.b{animation-duration:3.7s;animation-delay:-1.2s}
.pz97tt{position:absolute;left:50%;top:10px;transform:translateX(-50%);display:flex;align-items:center;gap:6px;pointer-events:none;z-index:2}
.pz97tt span{font:400 88px/1 "Pirata One",Georgia,serif;color:#ffd45a;text-shadow:0 5px 0 #12081f,3px 0 0 #12081f,-3px 0 0 #12081f,0 -3px 0 #12081f,0 0 22px #000;white-space:nowrap}
.pz97orn{width:118px;height:42px;margin-top:12px}.pz97orn.f{transform:scaleX(-1)}
.pz97tp{position:absolute;left:50%;top:108px;transform:translateX(-50%);display:flex;align-items:stretch;white-space:nowrap;z-index:3;border-radius:16px;box-shadow:0 0 0 3px #12081f,0 8px 20px #0009}
.pz97tps{display:flex;align-items:center;gap:8px;padding:6px 16px 6px 12px;border-radius:16px 0 0 16px;background:linear-gradient(180deg,#2e2478,#160e44);border:2.5px solid #ffd45a;font:700 17px Poppins,sans-serif;color:#efe8ff}.pz97tps b{color:#fff;font-weight:800}
.pz97tps .pz97st{width:26px;height:26px}
.pz97tpr{display:block;line-height:24px;padding:7px 18px;border-radius:0 16px 16px 0;background:linear-gradient(180deg,#221a5a,#100a30);border:2.5px solid #4a3e90;border-left:0;font:500 15px Poppins,sans-serif;color:#d8d0f4}.pz97tpr b{color:#fff;font-weight:800}
.pz97st{display:inline-block;width:1em;height:1em;vertical-align:middle;overflow:visible}
.pz97st path{fill:#1a2440;stroke:#7a86b0;stroke-width:1.6;stroke-linejoin:round}
.pz97st.on path{fill:#ffd45a;stroke:#12081f;stroke-width:2}
.pz97bd{position:absolute;left:402px;top:177px;width:${PZ97T_BW}px;height:${PZ97T_BH}px;z-index:2}
.pz97bdc{position:absolute;left:0;top:0;width:${PZ97T_BW}px;height:${PZ97T_BH}px;pointer-events:none}
.pzt97 .pzti.pz97tc{position:absolute;display:block;width:164px;height:166px;min-width:0;padding:0;margin:0;border:0;border-radius:0;background:none;box-shadow:none;text-align:center;color:#f4f0e2;letter-spacing:normal;cursor:pointer;transition:transform .32s cubic-bezier(.3,1.6,.5,1);z-index:1}
.pzt97 .pzti.pz97tc:hover,.pzt97 .pzti.pz97tc:focus-visible{transform:translateY(-6px) rotate(-1.5deg);outline:none;z-index:3}.pzt97 .pzti.pz97tc:active{transform:translateY(1px) scale(.97)}
.pzt97 .pzti.pz97tc.sel{z-index:2}
.pzt97 .pz97mtw.pztm{position:absolute;left:8px;top:6px;display:block;width:148px;height:88px;padding:0;border:0;border-radius:12px;background:none;transition:transform .35s cubic-bezier(.3,1.6,.5,1)}
.pzt97 .pz97tc.sel .pz97mtw{transform:scale(1.05)}
.pz97mt{position:absolute;left:0;top:0;width:148px;height:88px}
.pzt97 .pz97mtw .pztf{position:absolute;left:11px;top:11px;width:126px;height:65px;padding:0;border-radius:0;background:none;overflow:visible}
.pzt97 .pztf img{position:absolute;width:16px;height:16px;margin:0;transform:translate(-50%,-50%)}
.pzt97 .pztf img.cue{width:17px;height:17px}
.pz97zone{position:absolute;box-sizing:border-box;border:1.5px dashed #a8ffccb0;background:#8affb41c;border-radius:2px;text-decoration:none}
.pz97ring{position:absolute;inset:-5px;border-radius:15px;border:3.5px solid #ffd45a;box-shadow:0 0 0 2.5px #12081f,inset 0 0 0 2px #12081f;opacity:0;transform:scale(.9);transition:opacity .2s,transform .35s cubic-bezier(.3,1.6,.5,1);pointer-events:none}
.pz97ring::after{content:'';position:absolute;inset:-14px;border-radius:24px;background:radial-gradient(closest-side,#ffd45a55,#ffd45a00);z-index:-1}
.pz97tc.sel .pz97ring{opacity:1;transform:none}
.pz97nb{position:absolute;left:-4px;top:-10px;width:38px;height:38px;box-sizing:border-box;border-radius:50%;background:radial-gradient(circle at 38% 32%,#fff2b0,#ffd45a 45%,#d89a1a);border:3px solid #12081f;box-shadow:0 3px 0 #0008;font:800 19px/32px Poppins,sans-serif;color:#2a1a04;text-align:center;z-index:2;transition:transform .35s cubic-bezier(.3,1.7,.5,1)}
.pzt97 .pz97tc .pz97nb{position:absolute;display:block;margin:0;font:800 19px/32px Poppins,sans-serif;color:#2a1a04}.pzt97 .pz97tc.sel .pz97nb{transform:scale(1.12) rotate(-8deg)}
.pzt97 .pz97tc b{position:absolute;left:-14px;right:-14px;top:107px;margin:0;font:400 25px/1.05 "Pirata One",Georgia,serif;color:#f4f0e2;text-shadow:0 2px 0 #0a1a12;white-space:nowrap}
.pzt97 .pz97tc.sel b{color:#ffe9a0}
.pzt97 .pz97tc em{position:absolute;left:0;right:0;top:137px;display:flex;justify-content:center;gap:5px;font-size:24px;letter-spacing:0;font-style:normal}
.pz97st.new{animation:pz97starpop .6s var(--d,.3s) cubic-bezier(.3,1.8,.5,1) both}
.pz97gb{position:absolute;left:110px;top:262px;max-width:270px;padding:10px 14px;border-radius:16px;background:#fff8ec;border:3px solid #12081f;box-shadow:0 6px 0 #0007;font:600 italic 14px/1.35 Poppins,sans-serif;color:#24124a;opacity:0;transform:translateY(10px) scale(.8);transform-origin:20% 100%;transition:opacity .2s,transform .35s cubic-bezier(.3,1.6,.5,1);pointer-events:none;z-index:4}
.pz97gb::after{content:'';position:absolute;left:44px;bottom:-14px;border:10px solid transparent;border-top:12px solid #12081f;border-bottom:0}
.pz97gb.on{opacity:1;transform:none}.pz97gb.hide{opacity:0!important}
.pzk>canvas#pz97gr{left:0;top:340px;width:400px;height:360px;z-index:3}
.pzt97 .pz97grb{position:absolute;left:100px;top:380px;width:200px;height:250px;min-width:0;padding:0;border:0;border-radius:50%;background:none;box-shadow:none;cursor:pointer;z-index:3}
.pz97pg{position:absolute;top:200px;width:46px;height:64px;min-width:0;padding:0;border-radius:14px;border:3px solid #12081f;background:linear-gradient(180deg,#ffe27a,#f2b631);box-shadow:0 5px 0 #8a5610;font:800 34px/1 Poppins,sans-serif;color:#2a1a04;z-index:4;transition:transform .25s cubic-bezier(.3,1.6,.5,1)}
.pz97pg.l{left:-20px}.pz97pg.r{right:-20px}.pz97pg:hover:not(:disabled){transform:scale(1.1)}.pz97pg:disabled{opacity:.3;cursor:default}
.pz97dots{position:absolute;left:50%;bottom:44px;transform:translateX(-50%);display:flex;gap:8px}.pz97dots i{width:10px;height:10px;border-radius:50%;background:#ffffff40}.pz97dots i.on{background:#ffd45a}
.pz97tb{position:absolute;left:48px;top:684px;width:1507px;height:173px;box-sizing:border-box;display:flex;align-items:center;gap:26px;padding:0 30px 0 22px;border-radius:28px;background:linear-gradient(180deg,#241c62,#100a30);border:3px solid #4a3e90;box-shadow:0 0 0 3px #12081f,inset 0 1px 0 #ffffff24,0 14px 30px #000a;z-index:4}
.pz97pv{flex:none;width:300px;height:142px;border-radius:18px;background:#0c0824;border:2px solid #2a2468;display:flex;align-items:center;justify-content:center}
.pz97pvt{position:relative;display:block;width:266px;height:140px}.pz97pvc{position:absolute;left:0;top:0;width:266px;height:140px}
.pz97pvf{position:absolute;left:15px;top:15px;width:236px;height:109px}.pz97pvf img{position:absolute;width:24px;height:24px;transform:translate(-50%,-50%)}
.pz97pvf .pz97zone{border-width:2px}
.pz97ti{flex:1;min-width:0;padding-left:16px;text-align:left}
.pz97tih{display:flex;align-items:center;gap:16px}.pz97nb.big{position:static;flex:none;width:52px;height:52px;font-size:26px;line-height:46px}
.pz97tih b{font:400 54px/1 "Pirata One",Georgia,serif;color:#fff2c8;text-shadow:0 3px 0 #12081f;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.pz97ti p{margin:8px 0 0 68px;font:500 21px/1.25 Poppins,sans-serif;color:#e2dafc}
.pz97ti small{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;margin:6px 0 0 68px;font:600 13px/1.35 Poppins,sans-serif;color:#9ad8b0;overflow:hidden}.pz97ti small i{font-style:normal;color:#8affb4;font-weight:800}
.pz97tsep{flex:none;width:2px;height:104px;background:#4a3e90;border-radius:2px}
.pz97tst{flex:none;width:200px;text-align:center}.pz97tst div{display:flex;justify-content:center;gap:10px;font-size:46px}.pz97tst small{display:block;margin-top:8px;font:600 13px Poppins,sans-serif;color:#c4badf}.pz97tst small b{color:#ffd45a}
.pzt97 .pz97go{position:relative;flex:none;width:260px;height:92px;min-width:0;padding:0;border-radius:22px;border:4px solid #12081f;background:linear-gradient(180deg,#ffe27a,#f2b631);box-shadow:0 8px 0 #9a6a10,0 12px 26px #000a;color:#2a1a04;font:800 36px/1 Poppins,sans-serif;letter-spacing:normal;overflow:hidden;cursor:pointer;transition:transform .15s cubic-bezier(.3,1.6,.5,1);animation:pzrkb 2.6s ease-in-out 1.6s infinite}
.pzt97 .pz97go:hover{animation:none;transform:translateY(-3px) scale(1.02)}.pzt97 .pz97go:active{transform:translateY(5px)}
.pz97go kbd{position:absolute;right:10px;top:8px;padding:0 6px;border-radius:7px;background:#2a1a04;color:#ffe27a;font:800 10px/17px Poppins,sans-serif;opacity:.75}
.pz97pv.swap .pz97pvt{animation:pz97pvIn .45s cubic-bezier(.25,1.5,.45,1) both}.pz97ti.swap{animation:pz97tiIn .38s cubic-bezier(.25,1.3,.45,1) both}.pz97tst.swap .pz97st{animation:pz97starpop .45s var(--d) cubic-bezier(.3,1.8,.5,1) both}
.pzt97.pzin .pz97tt{animation:pz97ttIn .7s cubic-bezier(.25,1.5,.45,1) both}
.pzt97.pzin .pz97tp{animation:pzfadeY .5s .2s both}
.pzt97.pzin .pz97bd{animation:pz97bdIn .6s .05s cubic-bezier(.25,1.25,.45,1) both}
.pzt97.pzin .pz97tc{animation:pz97tcIn .5s calc(.22s + var(--k)*.055s) cubic-bezier(.25,1.6,.45,1) both}
.pzt97.pzin #pz97gr{animation:pzfromL .6s .15s cubic-bezier(.25,1.25,.45,1) both}
.pzt97.pzin .pz97tb{animation:pz97barIn .55s .2s cubic-bezier(.25,1.3,.45,1) both}
.pzt97.pzin .pz97go{animation:pzpopIn .45s .6s cubic-bezier(.25,1.6,.45,1) both,pzrkb 2.6s ease-in-out 1.6s infinite}
.pzt97.pzin .pzback,.pzt97.pzin .pzgold{animation:pzfade .5s .2s both}
.pzt97.rm *,.pzt97.rm>canvas.pz97tw{animation:none!important}
@keyframes pz97ttIn{0%{opacity:0;transform:translate(-50%,-60px) rotate(-3deg)}60%{opacity:1;transform:translate(-50%,6px) rotate(1deg)}100%{transform:translateX(-50%)}}
@keyframes pz97bdIn{from{opacity:0;transform:translateY(-40px) scale(.96)}to{opacity:1;transform:none}}
@keyframes pz97tcIn{from{opacity:0;transform:scale(.4) rotate(-8deg)}to{opacity:1;transform:none}}
@keyframes pz97pvIn{from{opacity:0;transform:scale(.8) rotate(-3deg)}to{opacity:1;transform:none}}
@keyframes pz97tiIn{from{opacity:0;transform:translateX(-18px)}to{opacity:1;transform:none}}
@keyframes pz97starpop{0%{transform:scale(0) rotate(-40deg)}100%{transform:none}}
`;document.head.appendChild(st)}
