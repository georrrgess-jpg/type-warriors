/* ===== 10.4 HARVEST FESTIVAL: art (99q2, prefix fle) =====
   Inline SVG icons (acorn, leaves, task badges, presents) and canvas paintings: the festival hub scene (a harvest table under a
   rising moon, lanterns, an orchard and a barn), the home card, the Harvest Market stall with its squirrel keeper, the market
   items, the calendar board and the hub tiles. Static layers are baked once into offscreen canvases; each frame only blits them
   and draws a few lantern glows, candle flames, leaves, fireflies and the hero (well under 1 ms apart from the hero). */
const FLA={};/* baked layers */
const fleCv=(w,h)=>{const c=document.createElement('canvas');c.width=w;c.height=h;return c};
const FLEO='#12081f';
/* ---------- SVG icons ---------- */
function fleIco(k,s){s=s||24;const v=(b,vb)=>`<svg class="fleico" viewBox="${vb||'0 0 64 64'}" width="${s}" height="${s}" aria-hidden="true">${b}</svg>`;
 if(k==='acorn')return v(`<path d="M32 58c-11-2-18-11-18-23V27h36v8c0 12-7 21-18 23z" fill="#d88a3a" stroke="${FLEO}" stroke-width="3.4" stroke-linejoin="round"/><path d="M40 29h10v6c0 11-6 19-15 22 6-5 6-14 5-28z" fill="#a85a22"/><path d="M21 33c0 8 3 14 8 18" stroke="#ffe0a8" stroke-width="3.2" fill="none" stroke-linecap="round" opacity=".85"/><path d="M8 27c0-9 11-15 24-15s24 6 24 15c0 3-3 5-6 5H14c-3 0-6-2-6-5z" fill="#7a4a24" stroke="${FLEO}" stroke-width="3.4" stroke-linejoin="round"/><path d="M14 22l8 8M22 18l10 12M32 16l9 13M42 18l7 9M18 30l8-11M28 30l9-13M38 30l8-10" stroke="#5a3214" stroke-width="2" stroke-linecap="round"/><path d="M31 13c0-4 1-7 5-9" stroke="${FLEO}" stroke-width="5" stroke-linecap="round" fill="none"/><path d="M31 13c0-4 1-7 5-9" stroke="#8a5a2a" stroke-width="2.4" stroke-linecap="round" fill="none"/><path d="M14 23c4-5 10-7 16-7" stroke="#b07a48" stroke-width="2.6" fill="none" stroke-linecap="round"/>`);
 if(k==='leaf'||k==='leaf2'||k==='leaf3'){const c=k==='leaf'?['#f07a2a','#c8401e']:k==='leaf2'?['#ffc23a','#d8861e']:['#e0452a','#a02a1a'];
  const d='M'+FLE_MAPLE.map(([a,b])=>(32+a*27).toFixed(1)+' '+(30+b*27).toFixed(1)).join('L')+'Z',h='M'+FLE_MAPLE.filter(([a])=>a>=0).map(([a,b])=>(32+a*27).toFixed(1)+' '+(30+b*27).toFixed(1)).join('L')+'L32 50Z';
  return v(`<path d="M32 46l3 15" stroke="${FLEO}" stroke-width="5" stroke-linecap="round"/><path d="M32 46l3 15" stroke="#8a4a1a" stroke-width="2.2" stroke-linecap="round"/><path d="${d}" fill="${c[0]}" stroke="${FLEO}" stroke-width="3" stroke-linejoin="round"/><path d="${h}" fill="${c[1]}" opacity=".45"/><path d="M32 52V14M32 37l15-6M32 37l-15-6" stroke="#5a1a0a" stroke-width="2" stroke-linecap="round" fill="none" opacity=".6"/><path d="M22 14l-3-4M16 26l-6-1" stroke="#fff3c8" stroke-width="2.2" stroke-linecap="round" opacity=".75"/>`)}
 if(k==='oak')return v(`<path d="M32 4c4 3 4 8 2 11 5-3 10-1 10 4-1 4-4 5-7 6 5 0 9 3 8 8-1 4-5 4-8 3 4 3 5 8 1 11-3 2-6 0-6-2l-1 13h-2l-1-13c0 2-3 4-6 2-4-3-3-8 1-11-3 1-7 1-8-3-1-5 3-8 8-8-3-1-6-2-7-6 0-5 5-7 10-4-2-3-2-8 2-11z" fill="#c8862a" stroke="${FLEO}" stroke-width="3" stroke-linejoin="round"/><path d="M32 60V12" stroke="#5a3a0a" stroke-width="2" stroke-linecap="round" opacity=".7"/>`);
 if(k==='coins')return v(`<ellipse cx="32" cy="50" rx="20" ry="7" fill="#a8701a" stroke="${FLEO}" stroke-width="3"/><ellipse cx="32" cy="44" rx="20" ry="7" fill="#e8b02a" stroke="${FLEO}" stroke-width="3"/><path d="M14 30c0-12 8-20 18-20s18 8 18 20v14H14z" fill="#8a5a2a" stroke="${FLEO}" stroke-width="3.2" stroke-linejoin="round"/><path d="M22 14c3-6 17-6 20 0l-4 4H26z" fill="#6a3e1a" stroke="${FLEO}" stroke-width="3" stroke-linejoin="round"/><path d="M20 20h24" stroke="#ffd45a" stroke-width="4" stroke-linecap="round"/><circle cx="32" cy="33" r="7" fill="#ffd45a" stroke="${FLEO}" stroke-width="2.6"/><path d="M32 29v8" stroke="#a8701a" stroke-width="2.4" stroke-linecap="round"/><path d="M19 26c0-4 2-7 5-9" stroke="#c89060" stroke-width="2.4" stroke-linecap="round" fill="none"/>`);
 if(k==='chest')return v(`<path d="M8 30h48v24H8z" fill="#c89a5a" stroke="${FLEO}" stroke-width="3.2" stroke-linejoin="round"/><path d="M8 34l8 8 8-8 8 8 8-8 8 8 8-8M8 44l8 8 8-8 8 8 8-8 8 8 8-8" stroke="#8a6030" stroke-width="2" fill="none"/><path d="M6 30c0-12 10-18 26-18s26 6 26 18z" fill="#7a4a24" stroke="${FLEO}" stroke-width="3.2" stroke-linejoin="round"/><path d="M12 30V20M52 30V20M6 30h52" stroke="${FLEO}" stroke-width="2.4"/><path d="M14 54V30M50 54V30" stroke="#5a3214" stroke-width="5"/><circle cx="32" cy="34" r="8" fill="#f08a2a" stroke="${FLEO}" stroke-width="2.8"/><path d="M29 34h6M32 26v-3" stroke="#a04a10" stroke-width="2.2" stroke-linecap="round"/><path d="M40 14c4-4 10-3 12 1-4 0-6 2-8 4" fill="#5aa84a" stroke="${FLEO}" stroke-width="2.4"/><path d="M12 22c4-6 12-8 18-8" stroke="#b07a48" stroke-width="2.6" fill="none" stroke-linecap="round"/>`);
 if(k==='egg'||k==='gold'){const g=k==='gold';return v(`<defs><radialGradient id="flegg${k}" cx=".38" cy=".32" r=".8"><stop offset="0" stop-color="${g?'#fff6c8':'#cfe8ff'}"/><stop offset=".55" stop-color="${g?'#ffc23a':'#5ab8ff'}"/><stop offset="1" stop-color="${g?'#c8781a':'#2a6ab8'}"/></radialGradient></defs><path d="M32 6c12 0 20 18 20 32 0 12-9 20-20 20s-20-8-20-20C12 24 20 6 32 6z" fill="url(#flegg${k})" stroke="${FLEO}" stroke-width="3.2"/>${g?'<path d="M13 38c6 4 32 4 38 0v5c-6 4-32 4-38 0z" fill="#d8961e" stroke="#12081f" stroke-width="2"/><path d="M16 40l4 3M22 41l4 3M28 42l4 2M34 42l4-1M40 41l4-2M46 40l3-2" stroke="#fff0b0" stroke-width="1.6"/><path d="M32 18l3 6 6-2-2 6 5 2-6 3 2 5-6-2-2 6-2-6-6 2 2-5-6-3 5-2-2-6 6 2z" fill="#f07a2a" stroke="#12081f" stroke-width="1.8" stroke-linejoin="round"/>':'<path d="M22 22l6 6-4 8 8 4M40 18l-4 8 6 6M26 46l6-4 8 6" stroke="#ffffff" stroke-width="2.4" fill="none" opacity=".75" stroke-linecap="round"/>'}<path d="M21 26c2-8 6-14 10-15" stroke="#ffffff" stroke-width="3" fill="none" stroke-linecap="round" opacity=".7"/>`)}
 if(k==='title')return v(`<path d="M4 22h12v20H4l5-10z" fill="#a8401e" stroke="${FLEO}" stroke-width="3" stroke-linejoin="round"/><path d="M60 22H48v20h12l-5-10z" fill="#a8401e" stroke="${FLEO}" stroke-width="3" stroke-linejoin="round"/><path d="M12 16h40v24H12z" fill="#e05a2a" stroke="${FLEO}" stroke-width="3.2" stroke-linejoin="round"/><path d="M18 28h28" stroke="#ffe0a0" stroke-width="3.4" stroke-linecap="round"/><path d="M14 19h36" stroke="#ff9a5a" stroke-width="2"/><path d="M32 40v14l-5-4-5 4" fill="none" stroke="${FLEO}" stroke-width="2.4"/>`);
 if(k==='pumpkin')return v(`<ellipse cx="20" cy="38" rx="12" ry="17" fill="#e8761e" stroke="${FLEO}" stroke-width="3"/><ellipse cx="44" cy="38" rx="12" ry="17" fill="#e8761e" stroke="${FLEO}" stroke-width="3"/><ellipse cx="32" cy="38" rx="13" ry="19" fill="#ff9a3a" stroke="${FLEO}" stroke-width="3"/><path d="M30 20c0-6 2-10 7-12l2 4c-3 1-5 4-5 8z" fill="#5a7a2a" stroke="${FLEO}" stroke-width="2.4" stroke-linejoin="round"/><path d="M24 30c-2 4-2 10 0 14" stroke="#fff3c8" stroke-width="2.4" stroke-linecap="round" fill="none" opacity=".7"/>`);
 if(k==='apple')return v(`<path d="M32 20c10-6 22 0 21 14-1 14-10 24-21 22-11 2-20-8-21-22-1-14 11-20 21-14z" fill="#e0402a" stroke="${FLEO}" stroke-width="3" stroke-linejoin="round"/><path d="M32 20c0-6 1-10 3-13" stroke="${FLEO}" stroke-width="3.4" stroke-linecap="round" fill="none"/><path d="M35 12c4-5 11-5 14-2-4 4-10 5-14 2z" fill="#5aa84a" stroke="${FLEO}" stroke-width="2.4" stroke-linejoin="round"/><path d="M20 30c-2 4-2 9 0 13" stroke="#ffffff" stroke-width="3" stroke-linecap="round" fill="none" opacity=".6"/>`);
 if(k==='gift')return v(`<path d="M10 28h44v28H10z" fill="#c8402a" stroke="${FLEO}" stroke-width="3.2" stroke-linejoin="round"/><path d="M6 20h52v10H6z" fill="#e8562a" stroke="${FLEO}" stroke-width="3.2" stroke-linejoin="round"/><path d="M28 20h8v36h-8z" fill="#ffc23a" stroke="${FLEO}" stroke-width="2.6"/><path d="M32 20c-4-10-16-12-16-4 0 4 8 4 16 4zM32 20c4-10 16-12 16-4 0 4-8 4-16 4z" fill="#ffd45a" stroke="${FLEO}" stroke-width="2.8" stroke-linejoin="round"/><path d="M14 33v18" stroke="#ff8a6a" stroke-width="2.4" stroke-linecap="round" opacity=".8"/>`);
 if(k==='feast')return v(`<path d="M6 40c4-18 22-30 44-28-6 6-8 14-6 24-12-4-26-2-38 4z" fill="#c8862a" stroke="${FLEO}" stroke-width="3.2" stroke-linejoin="round"/><path d="M14 36c6-10 18-16 30-18M20 38c4-8 14-12 24-13" stroke="#8a5a1a" stroke-width="2" fill="none"/><circle cx="46" cy="40" r="8" fill="#e8402a" stroke="${FLEO}" stroke-width="2.8"/><circle cx="34" cy="46" r="8" fill="#f08a2a" stroke="${FLEO}" stroke-width="2.8"/><path d="M34 38v-3" stroke="#3a6a1a" stroke-width="2.6" stroke-linecap="round"/><circle cx="52" cy="50" r="5" fill="#8a4ac8" stroke="${FLEO}" stroke-width="2.4"/><circle cx="46" cy="53" r="5" fill="#9a5ad8" stroke="${FLEO}" stroke-width="2.4"/><path d="M8 54h50" stroke="#ffd45a" stroke-width="3" stroke-linecap="round"/>`);
 if(k==='moon')return v(`<circle cx="32" cy="28" r="22" fill="#ffb04a" stroke="${FLEO}" stroke-width="3.2"/><path d="M32 6a22 22 0 0 1 0 44 18 22 0 0 0 0-44z" fill="#e8862a" opacity=".55"/><circle cx="25" cy="21" r="4" fill="#e8902a"/><circle cx="37" cy="33" r="3" fill="#e8902a"/><path d="M4 58V48l5-8 3 8 5-12 4 12 5-9 4 9 5-13 4 13 5-9 4 9 4-11 4 11 2 0V58z" fill="#2a1430" stroke="${FLEO}" stroke-width="2.6" stroke-linejoin="round"/><path d="M16 18c2-5 6-8 10-9" stroke="#fff3c8" stroke-width="2.6" stroke-linecap="round" fill="none" opacity=".7"/>`);
 return v(`<circle cx="32" cy="32" r="20" fill="#ffd45a"/>`)}
/* task glyphs: stroke icons in a round badge */
const FLE_TGL={camp:'<path d="M10 52V24l12-10 12 10v28M34 52V30l10-8 10 8v22M6 52h52M18 52V40h8v12"/>',endless:'<path d="M22 22c-8 0-12 5-12 10s4 10 12 10c10 0 10-20 20-20 8 0 12 5 12 10s-4 10-12 10c-10 0-10-20-20-20z"/>',
 sword:'<path d="M44 10l10 0 0 10-24 24-10-10z"/><path d="M14 38l12 12M10 54l8-8M20 34l10 10"/>',fish:'<path d="M8 32c8-12 24-14 36-4l10-8v24l-10-8C32 46 16 44 8 32z"/><circle cx="20" cy="30" r="2"/>',
 rune:'<rect x="10" y="10" width="44" height="44" rx="10"/><path d="M24 20v24M24 32l14-12M24 32l14 12"/>',tower:'<path d="M18 54V24h28v30M14 24V14h8v6h6v-6h8v6h6v-6h8v10M28 54V42h8v12"/>',
 lantern:'<path d="M24 14h16M32 6v8M22 18h20l4 10v16l-4 8H22l-4-8V28z"/><path d="M28 30c0 6 8 6 8 0s-4-6-4-6-4 0-4 6z"/>',gift:'<rect x="10" y="26" width="44" height="28" rx="4"/><path d="M6 18h52v8H6zM32 18v36M32 18c-6-10-18-8-14 0M32 18c6-10 18-8 14 0"/>',
 star:'<path d="M32 8l7 15 16 2-12 11 3 16-14-8-14 8 3-16-12-11 16-2z"/>',ball:'<circle cx="32" cy="32" r="22"/><circle cx="32" cy="32" r="9"/><path d="M29 29h6v6"/>',
 moon:'<path d="M40 8a22 22 0 1 0 16 30A18 18 0 0 1 40 8z"/><path d="M10 58c4-6 6-10 8-16M22 58c2-6 3-10 4-14"/>',quill:'<path d="M50 8C30 12 18 26 14 50l4 4c24-4 38-16 42-36z"/><path d="M14 50L36 28M8 56l6-6"/>',
 acorn:'<path d="M32 54c-9-2-15-9-15-19v-6h30v6c0 10-6 17-15 19z"/><path d="M12 29c0-8 9-13 20-13s20 5 20 13zM32 16c0-4 2-7 5-9"/>'};
const FLE_TCOL={camp:'#ffc94a',endless:'#ff8a3a',sword:'#ff7a6a',fish:'#7ad8ff',rune:'#b49cff',tower:'#9fe8ff',lantern:'#ffb04a',gift:'#5ad3e8',star:'#ffd45a',ball:'#7affc8',moon:'#ff9a3a',quill:'#e8e0ff',acorn:'#e8a23a'};
const fleTGlyph=(k,s)=>`<svg viewBox="0 0 64 64" width="${s||28}" height="${s||28}" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="4.4" stroke-linecap="round" stroke-linejoin="round">${FLE_TGL[k]||FLE_TGL.acorn}</svg>`;

/* ---------- canvas primitives with the house outline ---------- */
function flaO(g,w){g.strokeStyle=FLEO;g.lineWidth=w||3;g.lineJoin='round';g.lineCap='round';g.stroke()}
function flaEl(g,x,y,rx,ry,f,o,rot){g.beginPath();g.ellipse(x,y,Math.max(.1,rx),Math.max(.1,ry),rot||0,0,TAU);g.fillStyle=f;g.fill();if(o)flaO(g,o)}
function flaRG(g,x,y,r,c0,c1,ox,oy){const q=g.createRadialGradient(x+(ox||-.35)*r,y+(oy||-.35)*r,r*.08,x,y,r*1.05);q.addColorStop(0,c0);q.addColorStop(1,c1);return q}
function flaPumpkin(g,x,y,r,c,t){c=c||['#ffb04a','#f07a1e','#b8480e'];g.save();g.translate(x,y);
 const ribs=[[-.62,.8],[-.3,.95],[.3,.95],[.62,.8],[0,1]];for(const [ox,w] of ribs){g.beginPath();g.ellipse(ox*r,0,r*.46*w,r*.78,0,0,TAU);g.fillStyle=flaRG(g,ox*r,0,r*.6,c[0],c[1]);g.fill();g.strokeStyle=FLEO;g.lineWidth=Math.max(1.4,r*.08);g.stroke()}
 g.beginPath();g.ellipse(r*.38,r*.06,r*.36,r*.66,0,0,TAU);g.fillStyle=c[2]+'44';g.fill();
 g.strokeStyle='#ffffff55';g.lineWidth=Math.max(1,r*.07);g.beginPath();g.arc(-r*.5,-r*.18,r*.34,Math.PI*1.1,Math.PI*1.55);g.stroke();
 g.beginPath();g.moveTo(-r*.08,-r*.7);g.quadraticCurveTo(-r*.02,-r*1.08,r*.2,-r*1.12);g.lineTo(r*.22,-r*.96);g.quadraticCurveTo(r*.1,-r*.92,r*.1,-r*.7);g.closePath();g.fillStyle='#5a7a2a';g.fill();flaO(g,Math.max(1.2,r*.07));
 if(r>16){g.beginPath();g.moveTo(r*.1,-r*.8);g.bezierCurveTo(r*.6,-r*1.1,r*.8,-r*.7,r*.55,-r*.6);g.strokeStyle='#4a6a1a';g.lineWidth=Math.max(1,r*.05);g.stroke()}g.restore()}
function flaApple(g,x,y,r,c){g.save();g.translate(x,y);g.beginPath();g.moveTo(0,-r*.7);g.bezierCurveTo(r*.9,-r*1.15,r*1.25,r*.2,r*.4,r*.9);g.quadraticCurveTo(0,r*1.05,-r*.4,r*.9);g.bezierCurveTo(-r*1.25,r*.2,-r*.9,-r*1.15,0,-r*.7);g.closePath();g.fillStyle=flaRG(g,0,0,r,c?c[0]:'#ff6a4a',c?c[1]:'#b81e1e');g.fill();flaO(g,Math.max(1.2,r*.12));
 g.strokeStyle='#ffffff88';g.lineWidth=Math.max(1,r*.12);g.beginPath();g.arc(-r*.3,-r*.1,r*.4,Math.PI*1.1,Math.PI*1.5);g.stroke();
 g.strokeStyle=FLEO;g.lineWidth=Math.max(1.4,r*.14);g.beginPath();g.moveTo(0,-r*.6);g.lineTo(r*.1,-r*1.05);g.stroke();flaEl(g,r*.36,-r*.95,r*.3,r*.13,'#5aa84a',Math.max(1,r*.08),-.5);g.restore()}
function flaCorn(g,x,y,l,a){g.save();g.translate(x,y);g.rotate(a||0);g.beginPath();g.ellipse(0,0,l*.5,l*.17,0,0,TAU);g.fillStyle='#ffd04a';g.fill();flaO(g,2.2);
 g.fillStyle='#e8a01e';for(let i=-3;i<=3;i++)for(let j=-1;j<=1;j++){g.beginPath();g.arc(i*l*.12,j*l*.075,l*.032,0,TAU);g.fill()}
 g.beginPath();g.moveTo(-l*.5,0);g.quadraticCurveTo(-l*.2,-l*.32,l*.15,-l*.16);g.quadraticCurveTo(-l*.15,-l*.08,-l*.3,0);g.closePath();g.fillStyle='#c8b26a';g.fill();flaO(g,2);
 g.beginPath();g.moveTo(-l*.5,0);g.quadraticCurveTo(-l*.2,l*.32,l*.1,l*.2);g.quadraticCurveTo(-l*.15,l*.08,-l*.3,0);g.closePath();g.fillStyle='#a8924a';g.fill();flaO(g,2);g.restore()}
function flaAcorn(g,x,y,r,a){g.save();g.translate(x,y);g.rotate(a||0);g.beginPath();g.moveTo(-r*.8,-r*.1);g.lineTo(r*.8,-r*.1);g.quadraticCurveTo(r*.85,r*1.1,0,r*1.25);g.quadraticCurveTo(-r*.85,r*1.1,-r*.8,-r*.1);g.closePath();g.fillStyle=flaRG(g,0,r*.4,r,'#f0b060','#b8682a');g.fill();flaO(g,Math.max(1.2,r*.16));
 g.beginPath();g.ellipse(0,-r*.2,r*.98,r*.56,0,Math.PI,TAU);g.lineTo(r*.98,-r*.05);g.lineTo(-r*.98,-r*.05);g.closePath();g.fillStyle='#7a4a24';g.fill();flaO(g,Math.max(1.2,r*.16));
 g.strokeStyle='#5a3214';g.lineWidth=Math.max(.8,r*.08);for(let i=-2;i<=2;i++){g.beginPath();g.moveTo(i*r*.3-r*.2,-r*.6);g.lineTo(i*r*.3+r*.2,-r*.1);g.stroke()}
 g.strokeStyle=FLEO;g.lineWidth=Math.max(1.4,r*.2);g.beginPath();g.moveTo(0,-r*.7);g.quadraticCurveTo(r*.1,-r*1.1,r*.35,-r*1.2);g.stroke();
 g.strokeStyle='#ffe0a888';g.lineWidth=Math.max(1,r*.14);g.beginPath();g.arc(-r*.25,r*.4,r*.4,Math.PI*.7,Math.PI*1.1);g.stroke();g.restore()}
function flaLantern(g,x,y,r,c){g.save();g.translate(x,y);g.strokeStyle=FLEO;g.lineWidth=2;g.beginPath();g.moveTo(0,-r*1.5);g.lineTo(0,-r*.9);g.stroke();
 g.fillStyle='#3a2414';g.fillRect(-r*.45,-r*1.02,r*.9,r*.22);g.fillRect(-r*.4,r*.8,r*.8,r*.2);
 g.beginPath();g.ellipse(0,0,r,r*.9,0,0,TAU);g.fillStyle=flaRG(g,0,0,r,'#fff2c0',c,0,0);g.fill();flaO(g,2.2);
 g.strokeStyle='#00000030';g.lineWidth=1.2;for(const k of[-.55,0,.55]){g.beginPath();g.ellipse(0,0,r*Math.abs(k)+.5,r*.9,0,-Math.PI/2,Math.PI/2,k<0);g.stroke()}
 g.strokeStyle=FLEO;g.lineWidth=1.6;g.beginPath();g.moveTo(0,r*.98);g.lineTo(0,r*1.4);g.stroke();g.restore()}
/* a soft round glow sprite, drawn once, blitted with alpha */
function flaGlowSpr(c){const k='g'+c;if(FLA[k])return FLA[k];const s=fleCv(64,64),g=s.getContext('2d'),q=g.createRadialGradient(32,32,0,32,32,32);q.addColorStop(0,c+'cc');q.addColorStop(.4,c+'55');q.addColorStop(1,c+'00');g.fillStyle=q;g.fillRect(0,0,64,64);return FLA[k]=s}
function flaGlow(g,x,y,r,c,a){g.save();g.globalAlpha=a==null?1:a;g.globalCompositeOperation='lighter';g.drawImage(flaGlowSpr(c),x-r,y-r,r*2,r*2);g.restore()}
function flaCandle(g,x,y,h,t,i){g.save();g.translate(x,y);g.fillStyle='#f4e6c8';g.beginPath();g.roundRect(-5,-h,10,h,2);g.fill();flaO(g,2);g.fillStyle='#d8c49c';g.fillRect(1,-h+2,3,h-4);
 const f=1+Math.sin(t*9+i*2.3)*.12+Math.sin(t*23+i)*.05;flaGlow(g,0,-h-8,26,'#ffb04a',.8);g.beginPath();g.moveTo(0,-h-16*f);g.quadraticCurveTo(5,-h-6,0,-h-1);g.quadraticCurveTo(-5,-h-6,0,-h-16*f);g.fillStyle='#ffd45a';g.fill();g.beginPath();g.moveTo(0,-h-9*f);g.quadraticCurveTo(2.4,-h-4,0,-h-2);g.quadraticCurveTo(-2.4,-h-4,0,-h-9*f);g.fillStyle='#fff8e0';g.fill();g.restore()}
/* falling leaves for canvases: deterministic, cheap */
function flaLeaves(g,w,h,t,n,s,x0){const cols=['#f07a2a','#ffc23a','#e0452a','#d8861e','#c8402a'];for(let i=0;i<n;i++){const sp=.05+(i*37%10)/170,u=((t*sp+i*.137)%1),x=(x0||0)+((i*211)%w)+Math.sin(t*.9+i*1.7)*26*s,y=-20+u*(h+40),a=t*(1+(i%3)*.4)+i;g.save();g.globalAlpha=Math.min(1,Math.sin(u*Math.PI)*1.6);g.translate(x,y);g.rotate(a);g.scale(Math.cos(t*2+i)*.9||.1,1);fleLeafPath(g,0,0,(7+(i%4)*2)*s,cols[i%5],undefined);g.restore()}g.globalAlpha=1}

/* ---------- the hub scene: harvest table under the rising moon ---------- */
const FLEH={w:1320,h:500,gy:446};
function flaSky(g,w,h,hz){const q=g.createLinearGradient(0,0,0,hz);q.addColorStop(0,'#120a30');q.addColorStop(.42,'#2a1848');q.addColorStop(.72,'#6a2e4c');q.addColorStop(.9,'#c25e3a');q.addColorStop(1,'#e8884a');g.fillStyle=q;g.fillRect(0,0,w,hz+4);
 for(let i=0;i<110;i++){const x=(i*173+29)%w,y=(i*67+11)%(hz*.55),r=i%11?.9:1.6;g.globalAlpha=.3+.5*((i*7)%10)/10;g.fillStyle='#fff3d8';g.beginPath();g.arc(x,y,r,0,TAU);g.fill()}g.globalAlpha=1}
function flaMoon(g,x,y,r){let q=g.createRadialGradient(x,y,r*.6,x,y,r*3.6);q.addColorStop(0,'#ffb84a55');q.addColorStop(.5,'#ff8a3a1c');q.addColorStop(1,'#ff8a3a00');g.fillStyle=q;g.fillRect(x-r*3.6,y-r*3.6,r*7.2,r*7.2);
 g.beginPath();g.arc(x,y,r,0,TAU);g.fillStyle=flaRG(g,x,y,r,'#fff4cc','#f0902e',-.3,-.3);g.fill();g.lineWidth=3;g.strokeStyle='#a8501e';g.stroke();
 g.save();g.beginPath();g.arc(x,y,r,0,TAU);g.clip();for(const [a,b,c] of[[-.3,-.2,.18],[.25,.15,.24],[-.05,.45,.12],[.4,-.35,.1],[-.5,.3,.09]]){g.beginPath();g.ellipse(x+a*r,y+b*r,c*r,c*r*.8,0,0,TAU);g.fillStyle='#e0883a55';g.fill()}
 g.beginPath();g.arc(x+r*.25,y+r*.2,r*1.02,0,TAU);g.fillStyle='#a8401e22';g.fill();g.restore()}
function flaCloud(g,x,y,w,c){g.fillStyle=c;g.beginPath();g.ellipse(x,y,w*.5,w*.07,0,0,TAU);g.fill();g.beginPath();g.ellipse(x-w*.18,y-w*.04,w*.2,w*.06,0,0,TAU);g.fill();g.beginPath();g.ellipse(x+w*.12,y-w*.05,w*.16,w*.055,0,0,TAU);g.fill()}
function flaHills(g,w,y,amp,c,seed){g.beginPath();g.moveTo(0,y+80);for(let x=0;x<=w;x+=20)g.lineTo(x,y-Math.sin(x*.004+seed)*amp-Math.sin(x*.011+seed*2)*amp*.35);g.lineTo(w,y+300);g.lineTo(0,y+300);g.closePath();g.fillStyle=c;g.fill()}
function flaTree(g,x,y,r,c){g.fillStyle='#1a0e1e';g.fillRect(x-2.5,y-r*.4,5,r*.9);g.fillStyle=c;for(const [a,b,k] of[[0,-r*.9,1],[-r*.45,-r*.6,.75],[r*.45,-r*.6,.75]]){g.beginPath();g.arc(x+a,y+b,r*.55*k,0,TAU);g.fill()}}
function flaBarn(g,x,y,s){g.save();g.translate(x,y);g.scale(s,s);g.fillStyle='#3a1a26';g.beginPath();g.moveTo(-50,0);g.lineTo(-50,-46);g.lineTo(-30,-70);g.lineTo(30,-70);g.lineTo(50,-46);g.lineTo(50,0);g.closePath();g.fill();
 g.fillStyle='#4a2230';g.beginPath();g.moveTo(-34,-66);g.lineTo(34,-66);g.lineTo(-10,-50);g.closePath();g.fill();g.fillStyle='#ffc46a';g.fillRect(-9,-48,18,14);g.fillStyle='#3a1a26';g.fillRect(-1,-48,2,14);g.fillRect(-9,-42,18,2);
 g.fillStyle='#2a1018';g.fillRect(-14,-26,28,26);g.strokeStyle='#5a2a34';g.lineWidth=2;g.beginPath();g.moveTo(-14,-26);g.lineTo(14,0);g.moveTo(14,-26);g.lineTo(-14,0);g.stroke();
 g.fillStyle='#2a1420';g.fillRect(56,-58,16,58);g.beginPath();g.arc(64,-58,8,Math.PI,0);g.fill();g.restore()}
function flaCornRow(g,x0,x1,y,h,c,seed){for(let x=x0;x<x1;x+=11){const hh=h*(.75+.25*Math.sin(x*.7+seed)),lean=Math.sin(x*.3+seed)*4;g.strokeStyle=c;g.lineWidth=3;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+lean*.5,y-hh*.5,x+lean,y-hh);g.stroke();
  g.fillStyle=c;for(let k=0;k<3;k++){const yy=y-hh*(.3+k*.22),d=k%2?1:-1;g.beginPath();g.moveTo(x+lean*(.3+k*.2),yy);g.quadraticCurveTo(x+d*14,yy-10,x+d*20,yy+2);g.quadraticCurveTo(x+d*10,yy-2,x+lean*(.3+k*.2),yy+3);g.fill()}}}
function flaHay(g,x,y,w,h){g.save();g.translate(x,y);g.beginPath();g.roundRect(-w/2,-h,w,h,10);g.fillStyle=vgr(g,-h,0,'#e8c46a','#b8862e');g.fill();flaO(g,3);
 g.strokeStyle='#a8762a';g.lineWidth=1.4;for(let i=0;i<14;i++){const xx=-w/2+6+((i*37)%(w-12)),yy=-h+6+((i*23)%(h-12));g.beginPath();g.moveTo(xx,yy);g.lineTo(xx+8,yy+3);g.stroke()}
 g.strokeStyle='#7a4a1a';g.lineWidth=3;g.beginPath();g.moveTo(-w*.25,-h);g.lineTo(-w*.25,0);g.moveTo(w*.25,-h);g.lineTo(w*.25,0);g.stroke();g.strokeStyle='#fff0b066';g.lineWidth=2;g.beginPath();g.moveTo(-w/2+8,-h+5);g.lineTo(w/2-14,-h+5);g.stroke();g.restore()}
function flaSheaf(g,x,y,h){g.save();g.translate(x,y);for(let i=-6;i<=6;i++){const a=i*.06;g.strokeStyle=i%2?'#d8a84a':'#c8963a';g.lineWidth=3;g.beginPath();g.moveTo(i*1.5,0);g.lineTo(Math.sin(a)*h*1.1+i*2,-h);g.stroke();flaEl(g,Math.sin(a)*h*1.1+i*2,-h-5,3,7,'#e8c060',1.2,a)}
 g.fillStyle='#a8401e';g.fillRect(-11,-h*.42,22,7);g.strokeStyle=FLEO;g.lineWidth=2;g.strokeRect(-11,-h*.42,22,7);g.restore()}
function flaPie(g,x,y,r){g.save();g.translate(x,y);flaEl(g,0,4,r*1.15,r*.36,'#e8e0d0',2.4);flaEl(g,0,0,r,r*.32,'#d8902a',2.4);flaEl(g,0,-1,r*.84,r*.24,'#b85a1a');
 g.strokeStyle='#f0b860';g.lineWidth=3;for(let i=-2;i<=2;i++){g.beginPath();g.moveTo(i*r*.3-r*.12,-r*.2);g.lineTo(i*r*.3+r*.12,r*.18);g.stroke();g.beginPath();g.moveTo(i*r*.3+r*.12,-r*.2);g.lineTo(i*r*.3-r*.12,r*.18);g.stroke()}
 g.beginPath();g.ellipse(0,0,r,r*.32,0,0,TAU);flaO(g,2.4);g.restore()}
function flaLoaf(g,x,y,w){g.save();g.translate(x,y);g.beginPath();g.ellipse(0,0,w*.5,w*.26,0,Math.PI,TAU);g.lineTo(w*.5,4);g.lineTo(-w*.5,4);g.closePath();g.fillStyle=vgr(g,-w*.26,4,'#e8a85a','#a8622a');g.fill();flaO(g,2.4);
 g.strokeStyle='#ffe0a0aa';g.lineWidth=2.4;for(const k of[-.25,0,.25]){g.beginPath();g.moveTo(w*k-6,-w*.16);g.lineTo(w*k+6,-w*.08);g.stroke()}g.restore()}
function flaJug(g,x,y,h){g.save();g.translate(x,y);g.beginPath();g.moveTo(-h*.22,-h*.92);g.lineTo(h*.22,-h*.92);g.quadraticCurveTo(h*.2,-h*.7,h*.38,-h*.45);g.quadraticCurveTo(h*.5,-h*.05,h*.3,0);g.lineTo(-h*.3,0);g.quadraticCurveTo(-h*.5,-h*.05,-h*.38,-h*.45);g.quadraticCurveTo(-h*.2,-h*.7,-h*.22,-h*.92);g.closePath();
 g.fillStyle=vgr(g,-h,0,'#e8b26a','#a8622a');g.fill();flaO(g,2.6);g.fillStyle='#7a3a1a';g.fillRect(-h*.36,-h*.42,h*.72,h*.12);g.beginPath();g.arc(h*.42,-h*.5,h*.16,-1.2,1.2);g.strokeStyle=FLEO;g.lineWidth=4;g.stroke();g.strokeStyle='#ffffff55';g.lineWidth=2;g.beginPath();g.moveTo(-h*.22,-h*.7);g.lineTo(-h*.26,-h*.2);g.stroke();g.restore()}
function flaCornucopia(g,x,y,s){g.save();g.translate(x,y);g.scale(s,s);g.beginPath();g.moveTo(-70,-6);g.bezierCurveTo(-60,-40,-10,-46,20,-36);g.quadraticCurveTo(10,-14,24,6);g.bezierCurveTo(-10,4,-40,6,-70,-6);g.closePath();g.fillStyle=vgr(g,-46,6,'#e0a04a','#9a5a1e');g.fill();flaO(g,3);
 g.strokeStyle='#8a5018';g.lineWidth=2;for(let i=0;i<6;i++){g.beginPath();g.moveTo(-58+i*13,-28+i*2);g.quadraticCurveTo(-50+i*13,-10,-56+i*13,2);g.stroke()}
 g.beginPath();g.moveTo(-70,-6);g.quadraticCurveTo(-86,-14,-80,-30);g.quadraticCurveTo(-74,-20,-64,-16);g.fillStyle='#b8762a';g.fill();flaO(g,2.4);
 flaEl(g,30,-14,13,13,'#8a4ac8',2.2);flaEl(g,40,-4,11,11,'#9a5ad8',2.2);flaEl(g,22,-2,11,11,'#7a3ab8',2.2);flaApple(g,44,-26,13);flaPumpkin(g,60,-6,14,['#ffd06a','#e8a01e','#a8600e']);flaApple(g,30,6,11,['#ffd84a','#c88a1e']);flaCorn(g,8,-34,40,-.5);g.restore()}
function flaTable(g,x0,x1,y){/* top surface, cloth with a checked runner, legs */const w=x1-x0;g.fillStyle='#2a160e';g.fillRect(x0+14,y+40,12,52);g.fillRect(x1-26,y+40,12,52);
 g.beginPath();g.moveTo(x0,y);g.lineTo(x1,y);g.lineTo(x1+10,y+16);g.lineTo(x0-10,y+16);g.closePath();g.fillStyle=vgr(g,y,y+16,'#f4e6c8','#d8c49c');g.fill();flaO(g,3);
 g.beginPath();g.moveTo(x0-10,y+16);g.lineTo(x1+10,y+16);g.lineTo(x1+8,y+62);for(let i=12;i>=0;i--){const xx=x0-8+(w+16)*i/12;g.quadraticCurveTo(xx+(w+16)/24,y+70,xx,y+62)}g.closePath();g.fillStyle=vgr(g,y+16,y+70,'#e8d6b0','#b8a07a');g.fill();flaO(g,3);
 g.save();g.beginPath();g.rect(x0+w*.3,y,w*.4,72);g.clip();const cw=12;for(let r=0;r<7;r++)for(let c=0;c<Math.ceil(w*.4/cw)+1;c++){if((r+c)%2)continue;g.fillStyle='#b8341e';g.fillRect(x0+w*.3+c*cw,y+r*cw-2,cw,cw)}g.restore();
 g.strokeStyle=FLEO;g.lineWidth=2.2;g.strokeRect(x0+w*.3,y+1,w*.4,66);
 g.fillStyle='#00000026';g.fillRect(x0-10,y+60,w+20,6)}
function fleHubBake(){if(FLA.hub)return FLA.hub;const {w,h,gy}=FLEH,c=fleCv(w,h),g=c.getContext('2d'),hz=330;
 flaSky(g,w,h,hz);flaMoon(g,770,150,78);flaCloud(g,720,184,260,'#3a1e4aaa');flaCloud(g,880,120,200,'#4a2a5a88');flaCloud(g,300,90,240,'#2a1a4a88');
 flaHills(g,w,300,22,'#4a2448',1.3);for(let x=40;x<w;x+=46){const y=300-Math.sin(x*.004+1.3)*22-Math.sin(x*.011+2.6)*7.7;flaTree(g,x+((x*7)%13),y+8,20+(x%3)*4,x%2?'#5a2a4e':'#4e2446')}
 flaBarn(g,600,314,.9);flaHills(g,w,330,12,'#33183a',4.1);flaCornRow(g,860,w,350,70,'#2a1428',.4);flaCornRow(g,0,250,348,58,'#2a1428',2.2);
 /* ground */const q=g.createLinearGradient(0,hz,0,h);q.addColorStop(0,'#3a1e34');q.addColorStop(.5,'#26122a');q.addColorStop(1,'#140a1a');g.fillStyle=q;g.fillRect(0,hz+10,w,h-hz);
 g.globalAlpha=.5;for(let i=0;i<60;i++){const x=(i*97)%w,y=gy-30+((i*53)%60);g.strokeStyle=i%2?'#5a3a2a':'#4a2a30';g.lineWidth=2;g.beginPath();g.moveTo(x,y);g.lineTo(x-3,y-8);g.moveTo(x+3,y);g.lineTo(x+5,y-7);g.stroke()}g.globalAlpha=1;
 /* lantern strings */for(const [x1,y1,x2,y2,sag] of[[540,-8,1000,22,64],[880,-6,1330,34,50]]){g.strokeStyle='#1a0e14';g.lineWidth=2;g.beginPath();for(let i=0;i<=30;i++){const u=i/30,x=x1+(x2-x1)*u,y=y1+(y2-y1)*u+Math.sin(u*Math.PI)*sag;i?g.lineTo(x,y):g.moveTo(x,y)}g.stroke()}
 flaSheaf(g,250,gy-6,64);flaHay(g,960,gy+2,130,64);flaSheaf(g,1040,gy-2,58);
 /* the harvest table and its feast */
 flaTable(g,330,860,362);
 flaLoaf(g,400,374,64);flaPie(g,480,372,30);flaCornucopia(g,600,366,1.05);flaJug(g,700,376,44);
 for(const [x,y,r] of[[760,370,11],[778,374,10],[768,360,10]])flaApple(g,x,y,r);flaPumpkin(g,815,364,15,['#ffd06a','#e8a01e','#a8600e']);flaCorn(g,452,380,34,.3);
 /* pumpkins on the ground */flaPumpkin(g,300,gy-10,30);flaPumpkin(g,348,gy+4,20,['#ffd06a','#e8a01e','#a8600e']);flaPumpkin(g,885,gy-8,26);flaPumpkin(g,850,gy+8,16,['#f0e6c8','#c8b890','#8a7a5a']);
 for(const [x,y,a] of[[420,gy+16,.4],[520,gy+22,-.6],[640,gy+18,1.2],[760,gy+20,2.2]])flaAcorn(g,x,y,7,a);
 /* fallen leaves */for(let i=0;i<26;i++){g.save();g.translate((i*131)%w,gy+10+((i*47)%(h-gy-12)));g.rotate(i*1.3);g.scale(1,.55);fleLeafPath(g,0,0,7+(i%3)*2,['#c8402a','#e0702a','#d8961e'][i%3],'#12081f99');g.restore()}
 /* vignette */let v=g.createLinearGradient(0,0,0,h);v.addColorStop(.7,'#00000000');v.addColorStop(1,'#000000aa');g.fillStyle=v;g.fillRect(0,0,w,h);
 v=g.createLinearGradient(0,0,560,0);v.addColorStop(0,'#0c0620cc');v.addColorStop(1,'#0c062000');g.fillStyle=v;g.fillRect(0,0,560,h);
 return FLA.hub=c}
function fleLanterns(){if(FLA.lan)return FLA.lan;const out=[],cs=['#ff8a3a','#ffb84a','#e0503a','#ffd88a'];
 for(const [x1,y1,x2,y2,sag,n] of[[540,-8,1000,22,64,7],[880,-6,1330,34,50,7]])for(let i=1;i<n;i++){const u=i/n;out.push({x:x1+(x2-x1)*u,y:y1+(y2-y1)*u+Math.sin(u*Math.PI)*sag+16,c:cs[(i+n)%4],r:10+(i%3)*2})}return FLA.lan=out}
function fleHubPaint(g,c,t){const rm=fleRM();t=rm?2:t;const {w,h,gy}=FLEH;g.setTransform(c.width/w,0,0,c.height/h,0,0);g.drawImage(fleHubBake(),0,0);
 /* moon shimmer */flaGlow(g,770,150,150,'#ffb04a',.18+.06*Math.sin(t*.8));
 for(const [i,L] of fleLanterns().entries()){const f=.7+.3*Math.sin(t*2.6+i*1.9)*Math.sin(t*1.1+i);flaGlow(g,L.x,L.y,L.r*3.4,L.c,.55*f+.2);flaLantern(g,L.x,L.y,L.r,L.c)}
 flaCandle(g,372,368,26,t,0);flaCandle(g,540,368,32,t,1);flaCandle(g,656,370,22,t,2);flaCandle(g,840,370,28,t,3);
 /* the hero beside the table, the companion at their feet */
 g.save();g.translate(200,gy+6);g.fillStyle='#00000055';g.beginPath();g.ellipse(0,0,54,10,0,0,TAU);g.fill();g.scale(1.42,1.42);try{drawHero(g,{arm:P.armor,wp:P.weapon,col:P.col,t,lg:0})}catch(e){}g.restore();
 if(P.pet&&typeof PDEF!=='undefined'&&PDEF[P.pet]){g.save();g.translate(96,gy+8-(PDEF[P.pet].hover?30:0));g.scale(.95,.95);try{petDraw(g,P.pet,Object.assign({t:t+3,pose:'idle',u:0},petLook(P.pet)))}catch(e){}g.restore()}
 /* fireflies and drifting leaves */for(let i=0;i<12;i++){const u=((t*.08+i*.137)%1),x=120+((i*97)%760)+Math.sin(t*.9+i)*16,y=gy-20-u*260;flaGlow(g,x,y,9,i%3?'#ffe9a0':'#ffb04a',Math.sin(u*Math.PI)*.9)}
 if(!rm)flaLeaves(g,w,h,t,10,1);g.setTransform(1,0,0,1,0,0)}

/* ---------- the home card ---------- */
function fleCardBake(w,h){const k='card'+w;if(FLA[k])return FLA[k];const c=fleCv(w,h),g=c.getContext('2d'),s=h/320,hz=h*.68;
 flaSky(g,w,h,hz);flaMoon(g,w*.74,h*.3,46*s);flaCloud(g,w*.7,h*.38,170*s,'#3a1e4aaa');flaHills(g,w,h*.66,10*s,'#4a2448',2);
 for(let x=w*.36;x<w;x+=34*s)flaTree(g,x,h*.68-Math.sin(x*.01)*6*s,15*s,'#4e2446');flaBarn(g,w*.9,h*.72,.6*s);
 const q=g.createLinearGradient(0,hz,0,h);q.addColorStop(0,'#3a1e34');q.addColorStop(1,'#160a1c');g.fillStyle=q;g.fillRect(0,hz,w,h-hz);
 g.strokeStyle='#1a0e14';g.lineWidth=2;g.beginPath();for(let i=0;i<=20;i++){const u=i/20,x=w*.3+w*.72*u,y=h*.07+Math.sin(u*Math.PI)*h*.14;i?g.lineTo(x,y):g.moveTo(x,y)}g.stroke();
 flaHay(g,w*.62,h*.93,110*s,52*s);flaSheaf(g,w*.47,h*.95,56*s);flaPumpkin(g,w*.77,h*.88,30*s);flaPumpkin(g,w*.88,h*.92,22*s,['#ffd06a','#e8a01e','#a8600e']);flaPumpkin(g,w*.69,h*.95,15*s,['#f0e6c8','#c8b890','#8a7a5a']);
 flaApple(g,w*.95,h*.94,10*s);flaCorn(g,w*.83,h*.97,34*s,-.3);flaAcorn(g,w*.56,h*.96,8*s,.5);
 const v=g.createLinearGradient(0,0,w,0);v.addColorStop(0,'#0c0822e8');v.addColorStop(.48,'#0c082260');v.addColorStop(1,'#0c082200');g.fillStyle=v;g.fillRect(0,0,w,h);return FLA[k]=c}
function fleCardPaint(g,w,h,t){const rm=fleRM();t=rm?2:t;g.setTransform(1,0,0,1,0,0);g.drawImage(fleCardBake(w,h),0,0);const s=h/320;
 for(let i=1;i<8;i++){const u=i/8,x=w*.3+w*.72*u,y=h*.07+Math.sin(u*Math.PI)*h*.14+10*s,c=['#ff8a3a','#ffb84a','#e0503a','#ffd88a'][i%4];flaGlow(g,x,y,26*s,c,.5+.3*Math.sin(t*2.4+i*1.7));flaLantern(g,x,y,8*s,c)}
 if(!rm){g.save();g.beginPath();g.rect(w*.3,0,w*.7,h);g.clip();flaLeaves(g,w*.7,h,t,6,s*.9,w*.3);g.restore()}}

/* ---------- the Harvest Market stall and its keeper ---------- */
function flaSquirrel(g,x,y,s,t,blink){g.save();g.translate(x,y);g.scale(s,s);const sw=Math.sin(t*1.6)*.08;
 /* tail */g.save();g.translate(30,-20);g.rotate(sw);g.beginPath();g.moveTo(0,10);g.bezierCurveTo(40,10,60,-40,40,-80);g.bezierCurveTo(26,-104,-8,-96,-4,-70);g.bezierCurveTo(14,-74,26,-62,18,-42);g.bezierCurveTo(10,-22,-8,-12,0,10);g.closePath();g.fillStyle=flaRG(g,30,-50,50,'#f09a4a','#b8541e',.1,-.3);g.fill();flaO(g,3.4);
 g.strokeStyle='#ffd8a0aa';g.lineWidth=3;g.beginPath();g.moveTo(36,-74);g.quadraticCurveTo(46,-50,34,-20);g.stroke();g.restore();
 /* body with an apron */g.beginPath();g.ellipse(0,-8,30,34,0,0,TAU);g.fillStyle=flaRG(g,0,-8,32,'#e8823a','#a8461a');g.fill();flaO(g,3.4);flaEl(g,-2,-2,17,22,'#f8e4c0');
 g.beginPath();g.moveTo(-20,-20);g.lineTo(20,-20);g.lineTo(24,22);g.lineTo(-24,22);g.closePath();g.fillStyle='#3a7a4a';g.fill();flaO(g,2.6);g.fillStyle='#2a5a3a';g.fillRect(-9,0,18,10);g.strokeStyle=FLEO;g.lineWidth=2;g.strokeRect(-9,0,18,10);
 g.strokeStyle='#3a7a4a';g.lineWidth=3;g.beginPath();g.moveTo(-18,-20);g.lineTo(-10,-40);g.moveTo(18,-20);g.lineTo(10,-40);g.stroke();
 /* head */g.save();g.translate(0,-52);g.rotate(Math.sin(t*.9)*.05);
 for(const d of[-1,1]){g.beginPath();g.moveTo(d*12,-18);g.lineTo(d*20,-40);g.lineTo(d*26,-16);g.closePath();g.fillStyle='#c8642a';g.fill();flaO(g,3);g.beginPath();g.moveTo(d*20,-40);g.lineTo(d*22,-50);g.lineTo(d*24,-38);g.fillStyle='#a8461a';g.fill()}
 g.beginPath();g.ellipse(0,0,27,24,0,0,TAU);g.fillStyle=flaRG(g,0,0,27,'#f09a4a','#b8541e');g.fill();flaO(g,3.4);flaEl(g,0,9,16,11,'#f8e4c0');
 /* acorn-cap hat */g.beginPath();g.ellipse(2,-20,20,11,-.12,Math.PI,TAU);g.lineTo(22,-18);g.lineTo(-18,-16);g.closePath();g.fillStyle='#7a4a24';g.fill();flaO(g,2.8);g.strokeStyle='#5a3214';g.lineWidth=1.6;for(let i=-2;i<=2;i++){g.beginPath();g.moveTo(i*7-3,-29);g.lineTo(i*7+3,-19);g.stroke()}g.strokeStyle=FLEO;g.lineWidth=3;g.beginPath();g.moveTo(3,-31);g.lineTo(6,-37);g.stroke();
 const bl=blink?.15:1;for(const d of[-1,1]){flaEl(g,d*10,-1,6,7*bl,'#1a0e1e');if(!blink){flaEl(g,d*10+2,-4,2.2,2.4,'#ffffff')}}
 flaEl(g,0,7,4,3,'#3a1a1e');g.strokeStyle=FLEO;g.lineWidth=2;g.beginPath();g.moveTo(-5,12);g.quadraticCurveTo(0,16,5,12);g.stroke();flaEl(g,-16,8,4,2.6,'#ff8a8a66');flaEl(g,16,8,4,2.6,'#ff8a8a66');g.restore();
 /* paws holding an acorn */flaAcorn(g,0,-22,9,0);flaEl(g,-10,-16,6,5,'#c8642a',2.4);flaEl(g,10,-16,6,5,'#c8642a',2.4);g.restore()}
function fleStallBake(w,h){const k='stall'+w+'x'+h;if(FLA[k])return FLA[k];const c=fleCv(w,h),g=c.getContext('2d'),s=h/200,x0=w*.42,x1=w*.985,top=h*.16;
 flaSky(g,w,h,h*.8);flaMoon(g,w*.3,h*.34,34*s);flaHills(g,w,h*.78,8*s,'#3a1e40',1.1);const q=g.createLinearGradient(0,h*.8,0,h);q.addColorStop(0,'#2a1630');q.addColorStop(1,'#120a18');g.fillStyle=q;g.fillRect(0,h*.8,w,h*.2);
 /* posts and back wall */g.fillStyle='#3a2414';g.fillRect(x0,top,(x1-x0),h*.7);g.fillStyle='#4a2e1a';for(let x=x0;x<x1;x+=26*s){g.fillRect(x+2,top,22*s,h*.7)}g.fillStyle='#2a160e';g.fillRect(x0-6*s,top,14*s,h*.84);g.fillRect(x1-8*s,top,14*s,h*.84);
 /* shelves of jars */for(let i=0;i<9;i++){const x=x0+40*s+i*((x1-x0-80*s)/8),y=top+h*.3;g.beginPath();g.roundRect(x-9*s,y-22*s,18*s,22*s,4);g.fillStyle=i%3?'#e8a03a99':'#c8502a99';g.fill();flaO(g,2);g.fillStyle='#7a4a24';g.fillRect(x-10*s,y-25*s,20*s,5*s)}
 g.fillStyle='#2a160e';g.fillRect(x0,top+h*.3,(x1-x0),5*s);
 /* counter */g.beginPath();g.roundRect(x0-14*s,h*.62,(x1-x0)+28*s,h*.3,6);g.fillStyle=vgr(g,h*.62,h*.92,'#8a5a2e','#5a3218');g.fill();flaO(g,3);g.fillStyle='#a8763e';g.fillRect(x0-14*s,h*.62,(x1-x0)+28*s,8*s);
 g.strokeStyle='#4a2810';g.lineWidth=2;for(let x=x0;x<x1;x+=60*s){g.beginPath();g.moveTo(x,h*.66);g.lineTo(x,h*.9);g.stroke()}
 /* awning: scalloped stripes */const aw=h*.2;g.save();g.beginPath();g.moveTo(x0-24*s,top-8*s);g.lineTo(x1+24*s,top-8*s);g.lineTo(x1+24*s,top+aw);const n=14,sw=((x1-x0)+48*s)/n;for(let i=0;i<n;i++)g.arc(x1+24*s-sw/2-i*sw,top+aw,sw/2,0,Math.PI);g.closePath();g.clip();
 for(let i=0;i<n;i++){g.fillStyle=i%2?'#f4e2c0':'#c8402a';g.fillRect(x0-24*s+i*sw,top-10*s,sw+1,aw+sw)}g.fillStyle='#00000022';g.fillRect(x0-24*s,top+aw*.5,(x1-x0)+48*s,aw);g.restore();
 g.beginPath();g.moveTo(x0-24*s,top-8*s);g.lineTo(x1+24*s,top-8*s);g.lineTo(x1+24*s,top+aw);for(let i=0;i<n;i++)g.arc(x1+24*s-sw/2-i*sw,top+aw,sw/2,0,Math.PI);g.closePath();flaO(g,3);
 g.fillStyle='#5a3218';g.fillRect(x0-30*s,top-16*s,(x1-x0)+60*s,10*s);g.strokeStyle=FLEO;g.lineWidth=2.4;g.strokeRect(x0-30*s,top-16*s,(x1-x0)+60*s,10*s);
 /* leaf garland under the awning */for(let i=0;i<22;i++){const u=i/21,x=x0+(x1-x0)*u,y=top+aw+sw*.55+Math.sin(u*Math.PI*3)*4*s;g.save();g.translate(x,y);g.rotate(i*.9);fleLeafPath(g,0,0,7*s,['#e0452a','#f07a2a','#ffc23a'][i%3]);g.restore()}
 /* goods on the counter */const cy=h*.62;g.beginPath();g.roundRect(x0+10*s,cy-30*s,70*s,30*s,3);g.fillStyle='#a8763e';g.fill();flaO(g,2.4);for(let i=0;i<6;i++)flaApple(g,x0+20*s+i*10*s,cy-30*s-((i%2)*5)*s,8*s);
 flaPumpkin(g,x0+120*s,cy-18*s,20*s);flaPumpkin(g,x0+152*s,cy-12*s,13*s,['#ffd06a','#e8a01e','#a8600e']);
 flaPumpkin(g,x1-150*s,cy-16*s,18*s,['#f0e6c8','#c8b890','#8a7a5a']);g.beginPath();g.roundRect(x1-118*s,cy-28*s,74*s,28*s,3);g.fillStyle='#8a5a2e';g.fill();flaO(g,2.4);for(let i=0;i<5;i++)flaCorn(g,x1-104*s+i*13*s,cy-30*s,26*s,-1.3+i*.15);
 for(let i=0;i<5;i++)flaAcorn(g,x1-32*s+((i%2)*8-4)*s,cy-8*s-(i>>1)*8*s,6*s,i*.6);
 /* crates on the ground */flaHay(g,x0-40*s,h*.97,80*s,40*s);flaPumpkin(g,x0-90*s,h*.95,24*s);flaSheaf(g,x1-20*s,h*.98,50*s);
 const v=g.createLinearGradient(0,0,w*.5,0);v.addColorStop(0,'#0c0620ee');v.addColorStop(.8,'#0c062040');v.addColorStop(1,'#0c062000');g.fillStyle=v;g.fillRect(0,0,w*.5,h);return FLA[k]=c}
function fleStallPaint(g,c,t){const rm=fleRM();t=rm?2:t;const w=c.width,h=c.height,s=h/200,x0=w*.42,x1=w*.985,top=h*.16,aw=h*.2;g.setTransform(1,0,0,1,0,0);g.drawImage(fleStallBake(w,h),0,0);
 for(let i=0;i<4;i++){const x=x0+(x1-x0)*(i+.5)/4,y=top+aw+30*s,col=['#ffb84a','#ff8a3a','#ffd88a','#e0503a'][i];flaGlow(g,x,y,40*s,col,.45+.25*Math.sin(t*2.2+i*1.6));flaLantern(g,x,y,10*s,col)}
 const bl=!rm&&(t%4.2)<.14;flaSquirrel(g,x0+(x1-x0)*.56,h*.62,.95*s,t,bl);
 /* the counter edge in front of the keeper */g.fillStyle='#a8763e';g.fillRect(x0-14*s,h*.62,(x1-x0)+28*s,8*s);g.strokeStyle=FLEO;g.lineWidth=3;g.beginPath();g.moveTo(x0-14*s,h*.62);g.lineTo(x1+14*s,h*.62);g.stroke();
 if(!rm)flaLeaves(g,w,h,t,7,s*.9)}

/* ---------- the market items ---------- */
function flaChest(g,x,y,s,t){g.save();g.translate(x,y);g.scale(s,s);
 g.fillStyle='#00000055';g.beginPath();g.ellipse(0,4,64,10,0,0,TAU);g.fill();
 /* wicker body */g.beginPath();g.roundRect(-56,-52,112,52,6);g.fillStyle=vgr(g,-52,0,'#e0b46a','#a8763a');g.fill();flaO(g,3.4);
 g.save();g.beginPath();g.roundRect(-56,-52,112,52,6);g.clip();g.strokeStyle='#8a5a28';g.lineWidth=2.2;for(let i=-8;i<10;i++){g.beginPath();g.moveTo(-60+i*14,-54);g.lineTo(-40+i*14,2);g.stroke();g.beginPath();g.moveTo(-40+i*14,-54);g.lineTo(-60+i*14,2);g.stroke()}g.restore();
 /* oak frame */g.fillStyle='#6a3e1e';for(const x of[-56,-6,44]){g.fillRect(x,-52,12,52)}g.strokeStyle=FLEO;g.lineWidth=2.4;for(const x of[-56,-6,44])g.strokeRect(x,-52,12,52);
 /* lid */g.beginPath();g.moveTo(-60,-52);g.quadraticCurveTo(-58,-88,0,-90);g.quadraticCurveTo(58,-88,60,-52);g.closePath();g.fillStyle=vgr(g,-90,-52,'#9a5e2e','#5a3218');g.fill();flaO(g,3.4);
 g.strokeStyle='#3a2010';g.lineWidth=2;for(const k of[-30,0,30]){g.beginPath();g.moveTo(k,-52);g.quadraticCurveTo(k*1.02,-80,k*.9,-88);g.stroke()}
 g.strokeStyle='#ffffff40';g.lineWidth=3;g.beginPath();g.moveTo(-46,-62);g.quadraticCurveTo(-40,-82,-10,-86);g.stroke();
 /* vines */g.strokeStyle='#3a7a2a';g.lineWidth=3;g.beginPath();g.moveTo(-60,-50);g.bezierCurveTo(-40,-70,-20,-40,4,-62);g.bezierCurveTo(24,-80,40,-50,60,-64);g.stroke();for(const [vx,vy,a] of[[-44,-62,-.6],[-14,-50,.5],[18,-72,-.4],[46,-56,.6]])flaEl(g,vx,vy,7,3.6,'#5aa84a',1.6,a);
 /* the carved pumpkin lock */flaPumpkin(g,0,-50,14);g.fillStyle='#3a1a08';g.beginPath();g.moveTo(-6,-52);g.lineTo(-3,-56);g.lineTo(-1,-52);g.fill();g.beginPath();g.moveTo(6,-52);g.lineTo(3,-56);g.lineTo(1,-52);g.fill();g.beginPath();g.moveTo(-7,-46);g.lineTo(7,-46);g.lineTo(4,-42);g.lineTo(-4,-42);g.fill();
 if(t!=null)flaGlow(g,0,-48,22,'#ffb04a',.35+.2*Math.sin(t*3));
 /* wheat sheaf and lantern at the sides */flaSheaf(g,-66,0,40);g.save();g.translate(62,-2);g.strokeStyle=FLEO;g.lineWidth=2;g.beginPath();g.moveTo(0,-30);g.lineTo(0,-22);g.stroke();g.beginPath();g.roundRect(-8,-22,16,22,3);g.fillStyle='#ffd06a';g.fill();flaO(g,2.4);if(t!=null)flaGlow(g,0,-11,18,'#ffb04a',.5);g.fillStyle='#3a2414';g.fillRect(-9,-24,18,4);g.restore();g.restore()}
function flaGoldEgg(g,x,y,s,t){g.save();g.translate(x,y);g.scale(s,s);const b=t==null?0:Math.sin(t*2)*2;flaGlow(g,0,-52,56,'#ffb04a',.5+.15*Math.sin((t||0)*1.6));
 g.fillStyle='#00000055';g.beginPath();g.ellipse(0,4,40,9,0,0,TAU);g.fill();g.translate(0,b*.3);
 g.beginPath();g.moveTo(0,-104);g.bezierCurveTo(30,-104,44,-50,42,-30);g.bezierCurveTo(40,-6,22,4,0,4);g.bezierCurveTo(-22,4,-40,-6,-42,-30);g.bezierCurveTo(-44,-50,-30,-104,0,-104);g.closePath();
 g.fillStyle=flaRG(g,0,-50,52,'#fff8d0','#d8901e',-.4,-.5);g.fill();flaO(g,3.6);
 g.save();g.clip();g.fillStyle='#c8781a';g.fillRect(-50,-36,100,14);g.strokeStyle='#fff0b0';g.lineWidth=2;for(let i=-6;i<7;i++){g.beginPath();g.moveTo(i*8-4,-34);g.lineTo(i*8+4,-24);g.stroke()}g.strokeStyle=FLEO;g.lineWidth=2;g.beginPath();g.moveTo(-50,-36);g.lineTo(50,-36);g.moveTo(-50,-22);g.lineTo(50,-22);g.stroke();
 g.save();g.translate(0,-62);fleLeafPath(g,0,0,16,'#f07a2a');g.restore();for(const [a,b2] of[[-24,-80],[22,-84],[-28,-50],[28,-48]]){g.save();g.translate(a,b2);g.rotate(a*.05);fleLeafPath(g,0,0,5,'#e0452a','#12081f88');g.restore()}g.restore();
 g.strokeStyle='#ffffffaa';g.lineWidth=4;g.beginPath();g.moveTo(-24,-70);g.quadraticCurveTo(-20,-92,-6,-98);g.stroke();
 if(t!=null)for(let i=0;i<4;i++){const a=t*.8+i*1.57,r=56+Math.sin(t*2+i)*6;sparkle(g,Math.cos(a)*r,-52+Math.sin(a)*r*.7,5,.5+.5*Math.sin(t*3+i*2),'#fff4c0')}g.restore()}
function flaJar(g,x,y,s,t){g.save();g.translate(x,y);g.scale(s,s);g.fillStyle='#00000055';g.beginPath();g.ellipse(0,3,34,7,0,0,TAU);g.fill();
 g.beginPath();g.roundRect(-30,-80,60,80,14);g.fillStyle='#bfe8ff2a';g.fill();
 g.save();g.beginPath();g.roundRect(-30,-80,60,80,14);g.clip();for(let i=0;i<9;i++){const u=t==null?i/9:((t*.1+i/9)%1);g.save();g.translate(-18+((i*17)%36),-8-u*64);g.rotate(i+(t||0)*.6);fleLeafPath(g,0,0,7+(i%3)*1.5,['#e0452a','#f07a2a','#ffc23a'][i%3]);g.restore()}g.restore();
 g.beginPath();g.roundRect(-30,-80,60,80,14);flaO(g,3.2);g.strokeStyle='#ffffff88';g.lineWidth=3;g.beginPath();g.moveTo(-20,-66);g.lineTo(-20,-18);g.stroke();
 g.fillStyle='#b8865a';g.beginPath();g.roundRect(-20,-96,40,16,4);g.fill();flaO(g,2.6);g.fillStyle='#c8402a';g.fillRect(-30,-82,60,6);g.strokeStyle=FLEO;g.lineWidth=2;g.strokeRect(-30,-82,60,6);
 g.beginPath();g.roundRect(-18,-50,36,20,4);g.fillStyle='#f4e2c0';g.fill();flaO(g,2.2);g.fillStyle='#c8402a';g.beginPath();g.arc(0,-40,4,0,TAU);g.fill();g.restore()}
function flaRibbon(g,x,y,s){g.save();g.translate(x,y);g.scale(s,s);for(const d of[-1,1]){g.beginPath();g.moveTo(d*58,-14);g.lineTo(d*86,-14);g.lineTo(d*76,0);g.lineTo(d*86,14);g.lineTo(d*58,14);g.closePath();g.fillStyle='#8a2a14';g.fill();flaO(g,3)}
 g.beginPath();g.moveTo(-64,-20);g.quadraticCurveTo(0,-30,64,-20);g.lineTo(64,16);g.quadraticCurveTo(0,6,-64,16);g.closePath();g.fillStyle=vgr(g,-24,14,'#f07a3a','#b8401e');g.fill();flaO(g,3.2);
 g.strokeStyle='#ffd27a';g.lineWidth=2;g.beginPath();g.moveTo(-58,-15);g.quadraticCurveTo(0,-24,58,-15);g.moveTo(-58,11);g.quadraticCurveTo(0,2,58,11);g.stroke();
 for(const d of[-1,1]){g.save();g.translate(d*40,-1);g.rotate(d*.3);fleLeafPath(g,0,0,8,'#ffc23a');g.restore()}flaAcorn(g,0,-4,8,0);g.restore()}
/* draw a market item into a canvas */
function fleItemPaint(g,c,k,t){const w=c.width,h=c.height,s=h/130;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,w,h);if(fleRM())t=2;
 if(k==='egg'){flaGoldEgg(g,w/2,h*.94,s*1.08,t);return}
 if(k==='chest'){flaGlow(g,w/2,h*.55,70*s,'#ffb04a',.25);flaChest(g,w/2,h*.9,s*.95,t);return}
 if(k==='chest5'){flaGlow(g,w/2,h*.55,80*s,'#ffd45a',.25);flaChest(g,w*.3,h*.92,s*.62,null);flaChest(g,w*.7,h*.92,s*.62,null);flaChest(g,w/2,h*.62,s*.66,t);return}
 if(k==='squir'||k==='fox'){const id=FL.pets[k==='squir'?'r':'l'];flaGlow(g,w/2,h*.55,64*s,k==='fox'?'#ffb04a':'#5ab8ff',.3);
  if(typeof PDEF!=='undefined'&&PDEF[id]&&typeof petFit==='function'){const o=FLA.pc||(FLA.pc=fleCv(1,1));if(o.width!==w||o.height!==h){o.width=w;o.height=h}try{petFit(o,id,{t,pose:'idle',u:0,zoom:.95});g.drawImage(o,0,0)}catch(e){}}
  else if(k==='squir')flaSquirrel(g,w/2,h*.86,s*.7,t||0,false);else{g.globalAlpha=.85;flaEl(g,w/2,h*.6,40*s,36*s,'#2a1838',3);g.globalAlpha=1;g.fillStyle='#ffd45a';g.font=`700 ${34*s}px Poppins,sans-serif`;g.textAlign='center';g.textBaseline='middle';g.fillText('?',w/2,h*.6)}return}
 if(k==='trail'){g.strokeStyle='#ff8a3a55';g.lineWidth=4*s;g.lineCap='round';g.beginPath();for(let i=0;i<=20;i++){const u=i/20,x=16*s+u*(w-32*s),y=h*.74-Math.sin(u*Math.PI)*h*.46;i?g.lineTo(x,y):g.moveTo(x,y)}g.stroke();
  const L='LEAF';for(let i=0;i<4;i++){const u=((t*.4)+i*.25)%1,x=16*s+u*(w-32*s),y=h*.74-Math.sin(u*Math.PI)*h*.46;g.globalAlpha=Math.sin(u*Math.PI);btyTrailArt(g,'flleaf',x,y,u,L[i],i*1.7,1);g.globalAlpha=1}return}
 if(k==='title'){flaGlow(g,w/2,h*.5,80*s,'#ff8a3a',.25);flaRibbon(g,w/2,h*.52,s*1.15);return}
 if(k==='keep'){flaGlow(g,w/2,h*.55,60*s,'#ff8a3a',.25);flaJar(g,w/2,h*.92,s*.95,t);return}}

/* ---------- hub tiles and the calendar board ---------- */
function fleTilePaint(g,c,k,t){const w=c.width,h=c.height,s=h/100;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,w,h);if(fleRM())t=2;
 if(k==='cal'){g.beginPath();g.roundRect(6*s,10*s,w-12*s,h-18*s,8*s);g.fillStyle=vgr(g,10*s,h,'#8a5a2e','#5a3218');g.fill();flaO(g,2.6);
  const cw=(w-24*s)/4,ch=(h-34*s)/3;for(let r=0;r<3;r++)for(let q=0;q<4;q++){const x=12*s+q*cw,y=16*s+r*ch,on=r===1&&q===2;g.beginPath();g.roundRect(x+1.5*s,y+1.5*s,cw-3*s,ch-3*s,3*s);g.fillStyle=on?'#ffd45a':(r*4+q)<6?'#3a2010':'#a8763e';g.fill();g.strokeStyle=FLEO;g.lineWidth=1.6;g.stroke();
   if(on)flaGlow(g,x+cw/2,y+ch/2,24*s,'#ffd45a',.5+.3*Math.sin(t*3));else if((r*4+q)<6)flaAcorn(g,x+cw/2,y+ch/2-1*s,4*s,0)}
  g.save();g.translate(w-14*s,12*s);g.rotate(.4);fleLeafPath(g,0,0,10*s,'#f07a2a');g.restore();return}
 if(k==='mkt'){const sc=FLA.tm||(FLA.tm=fleCv(320,200));if(!sc._d){const sg=sc.getContext('2d');fleStallPaint(sg,sc,2);sc._d=1}g.drawImage(sc,320*.38,0,320*.62,200,0,0,w,h);return}
 if(k==='rush'){const q=g.createLinearGradient(0,0,0,h);q.addColorStop(0,'#1a0e34');q.addColorStop(1,'#6a2a3a');g.fillStyle=q;g.beginPath();g.roundRect(4*s,4*s,w-8*s,h-8*s,10*s);g.fill();g.save();g.clip();
  flaMoon(g,w*.58,h*.42,26*s);flaCornRow(g,0,w,h*.98,40*s,'#1a0a18',.7);g.fillStyle='#1a0a18';g.beginPath();g.moveTo(w*.22,h*.36);g.quadraticCurveTo(w*.28,h*.3+Math.sin(t*6)*3,w*.34,h*.36);g.quadraticCurveTo(w*.28,h*.34,w*.22,h*.36);g.fill();g.restore();g.beginPath();g.roundRect(4*s,4*s,w-8*s,h-8*s,10*s);flaO(g,2.4);return}
 if(k==='chest'){flaGlow(g,w/2,h*.55,46*s,'#ffb04a',.3);flaChest(g,w*.52,h*.92,s*.8,t);return}}
function fleBoardBake(w,h){const k='board'+w+'x'+h;if(FLA[k])return FLA[k];const c=fleCv(w,h),g=c.getContext('2d');
 g.beginPath();g.roundRect(0,0,w,h,26);g.fillStyle=vgr(g,0,h,'#6a4020','#3a2010');g.fill();
 g.save();g.beginPath();g.roundRect(0,0,w,h,26);g.clip();for(let y=0;y<h;y+=46){g.fillStyle=(y/46)%2?'#5a3418':'#643a1c';g.fillRect(0,y,w,44);g.strokeStyle='#2a140a';g.lineWidth=2;g.beginPath();g.moveTo(0,y+45);g.lineTo(w,y+45);g.stroke();
  g.strokeStyle='#ffffff10';g.lineWidth=1;for(let i=0;i<6;i++){const x=(i*271+y*7)%w;g.beginPath();g.moveTo(x,y+10+(i%3)*9);g.quadraticCurveTo(x+60,y+6+(i%3)*9,x+130,y+12+(i%3)*9);g.stroke()}}g.restore();
 g.lineWidth=14;g.strokeStyle='#3a2010';g.beginPath();g.roundRect(7,7,w-14,h-14,22);g.stroke();g.lineWidth=3;g.strokeStyle=FLEO;g.beginPath();g.roundRect(1.5,1.5,w-3,h-3,25);g.stroke();g.strokeStyle='#a8763e';g.lineWidth=2;g.beginPath();g.roundRect(14,14,w-28,h-28,18);g.stroke();
 for(const [x,y] of[[22,22],[w-22,22],[22,h-22],[w-22,h-22]]){g.beginPath();g.arc(x,y,5,0,TAU);g.fillStyle='#c8a050';g.fill();flaO(g,1.6)}
 /* corner bouquets */for(const [x,y,f] of[[30,h-20,1],[w-30,h-20,-1]]){g.save();g.translate(x,y);g.scale(f,1);for(let i=0;i<5;i++){g.save();g.rotate(-1.4+i*.32);g.translate(0,-30);fleLeafPath(g,0,0,14,['#e0452a','#f07a2a','#ffc23a','#d8861e','#c8402a'][i]);g.restore()}flaPumpkin(g,22,-6,18);flaAcorn(g,52,0,8,.4);g.restore()}
 /* the vine across the top */g.strokeStyle='#3a6a2a';g.lineWidth=4;g.beginPath();g.moveTo(40,10);for(let x=40;x<w-40;x+=40)g.quadraticCurveTo(x+20,26,x+40,10);g.stroke();
 for(let x=60;x<w-40;x+=80){g.save();g.translate(x,16);g.rotate(Math.sin(x)*.6);fleLeafPath(g,0,0,9,x%160?'#f07a2a':'#ffc23a');g.restore()}return FLA[k]=c}
