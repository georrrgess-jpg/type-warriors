/* ===== RUNESTONE RAMPARTS 8.7: towers, build pads and projectiles (95c, art only) =====
   Seen from a 3/4 top-down angle: a ground circle of radius r is an ellipse r x r*RPSQ on the pads and towers (RPSQ = .42) and
   r x r*RPFX.sq for ground effects (burst, frost pulse, slow field; the mode may change RPFX.sq to match its range rings).
   Baked once (2x sprites in RPSPR, lazily, keyed by type|tier|skin): the stone pad, each tower's static body (a back layer and,
   where something live sits inside it, a front layer: the brazier's front lip, the belfry's front pillars and roof), the
   ballista turret in RPFX.dirs (32) yaw frames, the bells, 8 flame frames per palette, bolts, embers, snowflakes, the slow-field
   rune circle and one radial glow sprite per colour (turret frames at 1.5x to keep memory down: about 3-7 MB per tier and skin). Live each frame: drawImage of those plus a few short paths (the loaded
   ballista bolts, lightning, sparks). Glows are the baked radial sprite drawn with 'lighter'; no shadowBlur, no ctx.filter.
   API
     RPTW, RPSKIN                        names, roles, colours; skins per tower (the second one is the unlockable reward)
     rpTowerDraw(g,type,tier,skin,t,o)   tower on its pad, pad centre at (0,0); o = {aim, fire 0..1, over 0..1, sel, ghost}
     rpPadDraw(g,t,state)                empty pad: 'idle' | 'hover' | 'valid' | 'none'
     rpTowerIcon(type,tier,skin,size)    cached transparent size x size canvas
     rpBolt rpEmber rpBurst rpFrostPulse rpBolt2 rpChill rpSlowField rpOvercharge   projectiles and effects
     rpTowerTop(type,tier)               height above the pad centre of the tower's top (for health bars, labels, fx anchors)
     rpTowerWarm(type,tier,skin)         optional: bake a tower's sprites (and all 32 ballista turret frames) ahead of time
   o.ph (optional) is a per-tower phase so neighbouring towers do not flicker or sway in sync. */
const RPTO='#12081f',RPK=2,RPSQ=.42,RPSPR=new Map(),RPGLW=new Map(),RPFX={sq:.55,dirs:32};
let RPGA=1;
const RPTW={ballista:{n:'Rune Ballista',role:'Precision',col:'#5ab8ff'},brazier:{n:'Ember Brazier',role:'Splash',col:'#ff8a3a'},frost:{n:'Frost Spire',role:'Slow',col:'#8ae6ff'},bell:{n:'Storm Bell',role:'Flying foes',col:'#ffd45a'}};
const RPSKIN={ballista:['base','gilded'],brazier:['base','azure'],frost:['base','aurora'],bell:['base','thunderking']};
const RPSTONE={
 pad:{l:'#a7a3c0',m:'#83809e',d:'#5b5876',k:'#2c2940',top:'#b6b2cc',topD:'#8b87a6'},
 base:{l:'#a39fbd',m:'#7e7a9a',d:'#575472',k:'#2a273e',top:'#b2aecb',topD:'#8884a4'},
 marble:{l:'#fbf7ef',m:'#ddd5c6',d:'#aea392',k:'#5c5246',top:'#fffdf8',topD:'#d9d0c0'},
 violet:{l:'#ad98d0',m:'#856ca8',d:'#5c467e',k:'#2a1c40',top:'#bea9de',topD:'#8f78b2'}};
const RPPAL={
 ballista:{
  base:{wood:'#a3683a',woodL:'#d4955c',woodD:'#5e3519',iron:'#3c5694',ironL:'#7ea4e6',ironD:'#1e2a58',trim:'#ffd45a',trimL:'#fff0a8',trimD:'#b07a1a',rune:'#5ab8ff',runeL:'#e2f6ff',str:'#efe2c4',stone:RPSTONE.base,flag:'#3264c8',flagD:'#1c3478',bolt:'#5ab8ff',boltL:'#e2f6ff',shaft:'#d9a86a'},
  gilded:{wood:'#efe6d4',woodL:'#ffffff',woodD:'#b6a27e',iron:'#e2aa30',ironL:'#ffe88e',ironD:'#93600f',trim:'#ffffff',trimL:'#ffffff',trimD:'#c6b48e',rune:'#ffbe3a',runeL:'#fff6c8',str:'#fff4d0',stone:RPSTONE.marble,flag:'#f6eedc',flagD:'#c9b48a',bolt:'#ffc23a',boltL:'#fffbe0',shaft:'#fff2d0',sun:1}},
 brazier:{
  base:{iron:'#4c4460',ironL:'#80769a',ironD:'#241e32',trim:'#e2a244',trimL:'#ffdc90',trimD:'#8a5418',rune:'#ff8a3a',coal:'#ff6a1a',coalL:'#ffd27a',coalD:'#7a1a0a',stone:RPSTONE.base,fl:['#d6301a','#ff8a1e','#ffd54a','#fff6c8'],glow:'#ff7a2a',glow2:'#ffc860'},
  azure:{iron:'#38497a',ironL:'#7d96d0',ironD:'#18203e',trim:'#cfe0ff',trimL:'#ffffff',trimD:'#6a7cae',rune:'#4ac8ff',coal:'#2a8cff',coalL:'#c4f2ff',coalD:'#0c2a7a',stone:RPSTONE.base,fl:['#1e46d8','#2ea8ff','#8ce8ff','#f2feff'],glow:'#2a8cff',glow2:'#8adcff'}},
 frost:{
  base:{metal:'#2f5cae',metalL:'#6e9eec',metalD:'#182f6a',trim:'#ffd45a',trimL:'#fff0a8',trimD:'#b07a1a',cr:[{l:'#e8fbff',m:'#80d8ff',d:'#2f80e0',k:'#1a3a96'}],ring:'#c6f6ff',glow:'#62d4ff',glow2:'#c6f6ff',rune:'#8ae6ff',stone:RPSTONE.base},
  aurora:{metal:'#4c2c7e',metalL:'#8e6ccc',metalD:'#24123e',trim:'#ffd45a',trimL:'#fff0a8',trimD:'#b07a1a',cr:[{l:'#fff0fa',m:'#ff9ce0',d:'#d0509e',k:'#842a78'},{l:'#effff8',m:'#8affd2',d:'#28b890',k:'#126e68'}],ring:'#ffd0f2',glow:'#ff74d4',glow2:'#6effc4',rune:'#9affd8',stone:RPSTONE.violet}},
 bell:{
  base:{stone:RPSTONE.base,wood:'#74482a',woodL:'#a8744a',woodD:'#40240f',bell:['#fff5b8','#ffd45a','#d8962a','#8a5414'],band:'#a8681a',roof:'#3c4c92',roofL:'#7086d2',roofD:'#202a5e',trim:'#ffd45a',trimL:'#fff0a8',trimD:'#b07a1a',bolt:'#9adcff',rune:'#7ad0ff',glow:'#5ac0ff',iron:'#4a4458',ironL:'#7a7490'},
  thunderking:{stone:RPSTONE.violet,wood:'#4e2c64',woodL:'#7e54a0',woodD:'#26122e',bell:['#fff3c4','#ffd45a','#c98a1c','#5a2a72'],band:'#7a36b0',roof:'#5c2a92',roofL:'#a466e2',roofD:'#2c1052',trim:'#ffd45a',trimL:'#fff0a8',trimD:'#b07a1a',bolt:'#c890ff',rune:'#d4a4ff',glow:'#a460ff',iron:'#3e2c58',ironL:'#7a64a0',crown:1}}};
const RPLC={base:'#9adcff',thunderking:'#c890ff',gold:'#ffd45a',frost:'#c6f6ff'};

/* ---------- small helpers ---------- */
const rpR=i=>{const x=Math.sin(i*127.1+311.7)*43758.5453;return x-Math.floor(x)};
function rpHx(h){h=h.replace('#','');if(h.length===3)h=h.split('').map(c=>c+c).join('');return [parseInt(h.slice(0,2),16),parseInt(h.slice(2,4),16),parseInt(h.slice(4,6),16)]}
function rpMix(a,b,t){t=t<0?0:t>1?1:t;const A=rpHx(a),B=rpHx(b);return '#'+A.map((v,i)=>Math.round(v+(B[i]-v)*t).toString(16).padStart(2,'0')).join('')}
function rpA(h,a){const A=rpHx(h);return 'rgba('+A[0]+','+A[1]+','+A[2]+','+a+')'}
function rpSpr(key,x0,y0,w,h,fn,k){let s=RPSPR.get(key);if(s)return s;k=k||RPK;const c=document.createElement('canvas');c.width=Math.ceil(w*k);c.height=Math.ceil(h*k);const g=c.getContext('2d');
 g.setTransform(k,0,0,k,-x0*k,-y0*k);g.lineJoin='round';g.lineCap='round';try{fn(g)}catch(e){console.error(e)}s={c,x0,y0,w,h};RPSPR.set(key,s);return s}
const rpPut=(g,s,dx,dy)=>g.drawImage(s.c,s.x0+(dx||0),s.y0+(dy||0),s.w,s.h);
function rpOut(g,lw){g.lineWidth=lw;g.strokeStyle=RPTO;g.stroke()}
function rpHG(g,x0,x1,a,b,c){const q=g.createLinearGradient(x0,0,x1,0);q.addColorStop(0,a);q.addColorStop(.42,b);q.addColorStop(1,c);return q}
function rpVG(g,y0,y1,a,b){const q=g.createLinearGradient(0,y0,0,y1);q.addColorStop(0,a);q.addColorStop(1,b);return q}
function rpRiv(g,x,y,r,col){g.beginPath();g.arc(x,y,r,0,TAU);g.fillStyle=col;g.fill();g.lineWidth=1;g.strokeStyle=RPTO;g.stroke();g.fillStyle='rgba(255,255,255,.6)';g.beginPath();g.arc(x-r*.35,y-r*.35,r*.38,0,TAU);g.fill()}
/* a glow: one baked radial sprite per colour, stamped with 'lighter' (the caller sets the composite) */
function rpGlowC(col){let c=RPGLW.get(col);if(c)return c;c=document.createElement('canvas');c.width=c.height=64;const g=c.getContext('2d'),q=g.createRadialGradient(32,32,0,32,32,32);
 q.addColorStop(0,rpA(col,1));q.addColorStop(.2,rpA(col,.62));q.addColorStop(.5,rpA(col,.2));q.addColorStop(1,rpA(col,0));g.fillStyle=q;g.fillRect(0,0,64,64);RPGLW.set(col,c);return c}
function rpGlow(g,x,y,rx,ry,col,a){if(a<=.01)return;g.globalAlpha=Math.min(1,a)*RPGA;g.drawImage(rpGlowC(col),x-rx,y-ry,rx*2,ry*2)}
/* sides of an upright cylinder whose bottom ellipse is centred on (cx,cy), height h, bottom radius rx, top radius rxT */
function rpSide(g,cx,cy,rx,rxT,h){g.beginPath();g.ellipse(cx,cy,rx,rx*RPSQ,0,Math.PI,0,true);g.lineTo(cx+rxT,cy-h);g.ellipse(cx,cy-h,rxT,rxT*RPSQ,0,0,Math.PI,false);g.closePath()}
function rpTube(g,cx,cy,rx,rxT,h,cl,cm,cd,lw){rpSide(g,cx,cy,rx,rxT,h);g.fillStyle=rpHG(g,cx-rx,cx+rx,cl,cm,cd);g.fill();
 g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=Math.max(1,rx*.08);g.beginPath();g.moveTo(cx-rx*.62,cy+rx*RPSQ*.7-2);g.lineTo(cx-rxT*.62,cy-h+rxT*RPSQ*.7+2);if(h>6)g.stroke();
 rpSide(g,cx,cy,rx,rxT,h);rpOut(g,lw||2.4)}
function rpCap(g,cx,cy,rx,cl,cd,lw){g.beginPath();g.ellipse(cx,cy,rx,rx*RPSQ,0,0,TAU);const q=g.createLinearGradient(cx-rx,cy-rx*RPSQ,cx+rx*.6,cy+rx*RPSQ);q.addColorStop(0,cl);q.addColorStop(1,cd);g.fillStyle=q;g.fill();rpOut(g,lw||2.4)}
/* a metal band around a cylinder, with rivets on its visible half */
function rpBand(g,cx,cy,rx,z,th,cl,cm,cd,nr,rc){rpTube(g,cx,cy-z,rx,rx,th,cl,cm,cd,1.8);if(nr)for(let i=0;i<nr;i++){const a=(i+.5)/nr*Math.PI;rpRiv(g,cx+Math.cos(a)*rx*.97,cy-z-th/2+Math.sin(a)*rx*RPSQ,Math.max(1,th*.22),rc||cl)}}
/* carved masonry on a cylinder: bevelled blocks shaded by the upper-left light */
function rpMason(g,cx,cy,rx,rxT,h,C,rows,cols,seed){rpSide(g,cx,cy,rx,rxT,h);g.fillStyle=C.k;g.fill();const rAt=z=>rx+(rxT-rx)*z/h,P=Math.PI;
 for(let r=0;r<rows;r++){const z0=h*r/rows+.8,z1=h*(r+1)/rows-.8,off=(r%2)*.5;
  for(let c=-1;c<cols;c++){let a0=(c+off)/cols*P,a1=(c+1+off)/cols*P;a0=Math.max(0,a0)+.03;a1=Math.min(P,a1)-.03;if(a1-a0<.06)continue;
   const r0=rAt(z0),r1=rAt(z1),am=(a0+a1)/2,L=(1-Math.cos(am))/2,n=seed*31+r*7+c;
   g.beginPath();g.ellipse(cx,cy-z0,r0,r0*RPSQ,0,a0,a1,false);g.ellipse(cx,cy-z1,r1,r1*RPSQ,0,a1,a0,true);g.closePath();
   g.fillStyle=rpMix(C.d,C.l,.08+.82*L+(rpR(n)-.5)*.2);g.fill();
   g.lineWidth=1.3;g.strokeStyle='rgba(255,255,255,.32)';g.beginPath();g.ellipse(cx,cy-z1+.9,r1,r1*RPSQ,0,a0+.03,a1-.03);g.stroke();
   g.strokeStyle='rgba(18,8,31,.38)';g.beginPath();g.ellipse(cx,cy-z0-.7,r0,r0*RPSQ,0,a0+.03,a1-.03);g.stroke();
   if(rpR(n+.37)>.78){const aa=a0+(a1-a0)*rpR(n+2),zz=z0+(z1-z0)*(.3+rpR(n+3)*.4),rr=rAt(zz);g.fillStyle='rgba(18,8,31,.3)';g.beginPath();g.arc(cx+Math.cos(aa)*rr,cy-zz+Math.sin(aa)*rr*RPSQ,1.2+rpR(n+4)*1.6,0,TAU);g.fill()}}}
 g.save();rpSide(g,cx,cy,rx,rxT,h);g.clip();const q=g.createLinearGradient(cx-rx,0,cx+rx,0);q.addColorStop(0,'rgba(255,255,255,.1)');q.addColorStop(.35,'rgba(255,255,255,0)');q.addColorStop(.72,'rgba(18,8,31,.06)');q.addColorStop(1,'rgba(18,8,31,.42)');g.fillStyle=q;g.fillRect(cx-rx-2,cy-h-rx,2*rx+4,h+2*rx);g.restore();
 rpSide(g,cx,cy,rx,rxT,h);rpOut(g,2.6)}
/* the flat top of a stone drum: flagstones split by radial seams and a carved ring */
function rpTopStone(g,cx,cy,rx,C,seed,ring){g.beginPath();g.ellipse(cx,cy,rx,rx*RPSQ,0,0,TAU);const q=g.createLinearGradient(cx-rx,cy-rx*RPSQ,cx+rx,cy+rx*RPSQ);q.addColorStop(0,C.top);q.addColorStop(1,C.topD);g.fillStyle=q;g.fill();
 g.strokeStyle='rgba(18,8,31,.35)';g.lineWidth=1.2;const n=5+(seed%3);for(let i=0;i<n;i++){const a=i/n*TAU+rpR(seed+i)*.5;g.beginPath();g.moveTo(cx+Math.cos(a)*rx*.45,cy+Math.sin(a)*rx*RPSQ*.45);g.lineTo(cx+Math.cos(a)*rx*.97,cy+Math.sin(a)*rx*RPSQ*.97);g.stroke()}
 g.beginPath();g.ellipse(cx,cy,rx*.45,rx*.45*RPSQ,0,0,TAU);g.stroke();g.strokeStyle='rgba(255,255,255,.25)';g.beginPath();g.ellipse(cx,cy+.8,rx*.45,rx*.45*RPSQ,0,.2,Math.PI-.2);g.stroke();
 if(ring){g.strokeStyle=ring;g.lineWidth=1.4;g.beginPath();g.ellipse(cx,cy,rx*.72,rx*.72*RPSQ,0,0,TAU);g.stroke()}
 g.beginPath();g.ellipse(cx,cy,rx,rx*RPSQ,0,0,TAU);rpOut(g,2.4)}
/* chunky stroked beam: outline, colour, highlight line on its upper side */
function rpBeam(g,x0,y0,x1,y1,lw,col,hi,cv){g.beginPath();g.moveTo(x0,y0);if(cv)g.quadraticCurveTo(cv[0],cv[1],x1,y1);else g.lineTo(x1,y1);g.lineWidth=lw+3.4;g.strokeStyle=RPTO;g.stroke();g.lineWidth=lw;g.strokeStyle=col;g.stroke();
 if(hi){const o=lw*.24;g.beginPath();g.moveTo(x0-o*.4,y0-o);if(cv)g.quadraticCurveTo(cv[0]-o*.4,cv[1]-o,x1-o*.4,y1-o);else g.lineTo(x1-o*.4,y1-o);g.lineWidth=Math.max(1,lw*.28);g.strokeStyle=hi;g.stroke()}}
function rpGrass(g,x,y,s,seed){for(let i=0;i<5;i++){const dx=(i-2)*2.4*s,h=(6+rpR(seed+i)*6)*s,l=(i-2)*1.6*s+(rpR(seed+i*3)-.5)*3;g.beginPath();g.moveTo(x+dx,y);g.quadraticCurveTo(x+dx+l*.3,y-h*.6,x+dx+l,y-h);g.lineWidth=3.6*s;g.strokeStyle=RPTO;g.stroke()}
 for(let i=0;i<5;i++){const dx=(i-2)*2.4*s,h=(6+rpR(seed+i)*6)*s,l=(i-2)*1.6*s+(rpR(seed+i*3)-.5)*3;g.beginPath();g.moveTo(x+dx,y);g.quadraticCurveTo(x+dx+l*.3,y-h*.6,x+dx+l,y-h);g.lineWidth=1.8*s;g.strokeStyle=i%2?'#5aa040':'#7cc24e';g.stroke()}}
function rpMoss(g,x,y,s,seed){const b=[[0,0,5],[-5,1,3.6],[5,1.2,3.8],[2,-2.4,3.2]];g.fillStyle=RPTO;for(const [dx,dy,r] of b){g.beginPath();g.arc(x+dx*s,y+dy*s,(r+1.2)*s,0,TAU);g.fill()}
 g.fillStyle='#3f7a34';for(const [dx,dy,r] of b){g.beginPath();g.arc(x+dx*s,y+dy*s,r*s,0,TAU);g.fill()}g.fillStyle='#6cb04a';for(const [dx,dy,r] of b){g.beginPath();g.arc(x+(dx-.8)*s,y+(dy-1.2)*s,r*.62*s,0,TAU);g.fill()}
 g.fillStyle='#3f7a34';g.beginPath();g.ellipse(x+(rpR(seed)*4-2)*s,y+4*s,1.6*s,3.4*s,0,0,TAU);g.fill()}

/* ---------- the build pad ---------- */
function rpPadArt(g){const C=RPSTONE.pad,P=Math.PI;
 g.fillStyle='rgba(8,4,20,.42)';g.beginPath();g.ellipse(4,18,60,23,0,0,TAU);g.fill();
 rpMason(g,0,15,50,48,15,C,2,7,3);
 g.beginPath();g.ellipse(0,0,48,48*RPSQ,0,0,TAU);g.fillStyle=C.k;g.fill();
 const n=12;for(let i=0;i<n;i++){const a0=i/n*TAU+.2+.03,a1=(i+1)/n*TAU+.2-.03,am=(a0+a1)/2,fr=Math.sin(am)>0;
  g.beginPath();g.ellipse(0,0,46.8,46.8*RPSQ,0,a0,a1);g.ellipse(0,0,31.5,31.5*RPSQ,0,a1,a0,true);g.closePath();
  g.fillStyle=rpMix(C.topD,C.top,.45+(-Math.cos(am)*.18)+(rpR(i+9)-.5)*.3);g.fill();
  g.lineWidth=1.3;g.strokeStyle=fr?'rgba(255,255,255,.35)':'rgba(18,8,31,.3)';g.beginPath();g.ellipse(0,0,32.6,32.6*RPSQ,0,a0+.03,a1-.03);g.stroke();
  g.strokeStyle=fr?'rgba(18,8,31,.25)':'rgba(255,255,255,.3)';g.beginPath();g.ellipse(0,0,45.6,45.6*RPSQ,0,a0+.03,a1-.03);g.stroke();
  if(rpR(i+40)>.7){g.fillStyle='rgba(18,8,31,.22)';const aa=a0+(a1-a0)*.6;g.beginPath();g.arc(Math.cos(aa)*40,Math.sin(aa)*40*RPSQ,1.8,0,TAU);g.fill()}}
 g.beginPath();g.ellipse(0,0,30.5,30.5*RPSQ,0,0,TAU);let q=g.createLinearGradient(-30,-12,30,12);q.addColorStop(0,C.m);q.addColorStop(1,C.d);g.fillStyle=q;g.fill();g.lineWidth=1.6;g.strokeStyle=RPTO;g.stroke();
 g.lineWidth=2;g.strokeStyle='rgba(18,8,31,.55)';g.beginPath();g.ellipse(0,-.4,21,21*RPSQ,0,0,TAU);g.stroke();g.lineWidth=1;g.strokeStyle='rgba(255,255,255,.28)';g.beginPath();g.ellipse(0,.9,21,21*RPSQ,0,.15,P-.15);g.stroke();
 for(let i=0;i<4;i++){const a=i*P/2+P/4,x=Math.cos(a)*21,y=Math.sin(a)*21*RPSQ;g.fillStyle='rgba(18,8,31,.5)';g.beginPath();g.moveTo(x,y-2.6);g.lineTo(x+2.6,y);g.lineTo(x,y+2.6);g.lineTo(x-2.6,y);g.closePath();g.fill()}
 g.beginPath();g.ellipse(0,0,48,48*RPSQ,0,0,TAU);rpOut(g,3);
 g.strokeStyle='rgba(255,255,255,.4)';g.lineWidth=1.5;g.beginPath();g.ellipse(0,0,47,47*RPSQ,0,P*1.08,P*1.55);g.stroke();
 rpMoss(g,-40,8,1,1);rpMoss(g,33,13,.8,2);rpMoss(g,-14,-19,.7,3);
 rpGrass(g,-47,26,1,5);rpGrass(g,42,28,.9,9);rpGrass(g,-10,36,.75,13)}
function rpMedalArt(g){g.beginPath();g.arc(0,0,16,0,TAU);g.fillStyle=RPTO;g.fill();g.beginPath();g.arc(0,0,14.4,0,TAU);let q=g.createLinearGradient(-14,-14,14,14);q.addColorStop(0,'#fff2a8');q.addColorStop(.45,'#ffd45a');q.addColorStop(1,'#a8701a');g.fillStyle=q;g.fill();
 g.beginPath();g.arc(0,0,10.6,0,TAU);q=g.createLinearGradient(-10,-10,10,10);q.addColorStop(0,'#2a1f5e');q.addColorStop(1,'#0e0824');g.fillStyle=q;g.fill();rpOut(g,1.6);
 g.beginPath();for(const [x,y,w,h] of [[-2.6,-8,5.2,16],[-8,-2.6,16,5.2]])g.rect(x,y,w,h);g.fillStyle=RPTO;g.fill();
 g.fillStyle='#ffd45a';g.fillRect(-1.6,-7,3.2,14);g.fillRect(-7,-1.6,14,3.2);g.fillStyle='#fff3b8';g.fillRect(-1.6,-7,1.4,6);g.fillRect(-7,-1.6,6,1.4);
 g.strokeStyle='rgba(255,255,255,.75)';g.lineWidth=1.6;g.beginPath();g.arc(0,0,12.6,Math.PI*1.05,Math.PI*1.5);g.stroke();
 for(let i=0;i<8;i++){const a=i*Math.PI/4;rpRiv(g,Math.cos(a)*12.6,Math.sin(a)*12.6,.9,'#ffe48a')}}
const rpPadS=()=>rpSpr('pad',-64,-28,130,72,rpPadArt);
function rpPadDraw(g,t,state){t=t||0;const s=rpPadS();
 if(state==='valid'){g.save();g.globalCompositeOperation='lighter';const p=.5+.5*Math.sin(t*5);rpGlow(g,0,8,74,34,'#ffc94a',.25+.2*p);g.restore()}
 rpPut(g,s);if(state==='none')return;
 const m=rpSpr('padm',-18,-18,36,36,rpMedalArt),hv=state==='hover',va=state==='valid';
 g.save();
 if(va){const p=.5+.5*Math.sin(t*5);g.globalCompositeOperation='lighter';g.globalAlpha=RPGA;
  g.lineWidth=9;g.strokeStyle='rgba(255,200,74,'+(.12+.12*p).toFixed(3)+')';g.beginPath();g.ellipse(0,0,49,49*RPSQ,0,0,TAU);g.stroke();
  g.lineWidth=2.6;g.strokeStyle='rgba(255,214,90,'+(.55+.4*p).toFixed(3)+')';g.beginPath();g.ellipse(0,0,48,48*RPSQ,0,0,TAU);g.stroke();
  for(let i=0;i<5;i++){const k=(t*.45+i/5)%1,a=i*2.4+1;rpGlow(g,Math.cos(a)*40,Math.sin(a)*15-k*34,4,4,'#ffd45a',(1-k)*.9)}
  g.globalCompositeOperation='source-over'}
 if(hv){g.globalCompositeOperation='lighter';g.globalAlpha=.55*RPGA;g.lineWidth=2;g.strokeStyle='#fff3c0';g.beginPath();g.ellipse(0,0,47.5,47.5*RPSQ,0,0,TAU);g.stroke();g.globalCompositeOperation='source-over'}
 const lift=hv?6+Math.sin(t*4)*1.5:va?3+Math.sin(t*3)*2:Math.sin(t*2)*1;
 g.globalAlpha=RPGA*.4;g.fillStyle=RPTO;g.beginPath();g.ellipse(0,1,12-lift*.4,4.6-lift*.15,0,0,TAU);g.fill();
 if(hv||va){g.globalCompositeOperation='lighter';rpGlow(g,0,-16-lift,30,30,'#ffd45a',hv?.6:.4+.2*Math.sin(t*5));g.globalCompositeOperation='source-over'}
 g.globalAlpha=RPGA;const sc=hv?1.12:1;g.translate(0,-16-lift);g.scale(sc,sc);rpPut(g,m);g.restore()}

/* ---------- flames: 8 baked frames per palette ---------- */
function rpFlameArt(g,fl,i){const ph=i/8*TAU,sw=Math.sin(ph)*4;
 const tongue=(x,w,h,s)=>{g.beginPath();g.moveTo(x-w,0);g.bezierCurveTo(x-w,-h*.38,x-w*.42+s*.5,-h*.66,x+s,-h);g.bezierCurveTo(x+w*.5+s*.4,-h*.62,x+w,-h*.36,x+w,0);g.closePath();g.fill()};
 [[fl[0],1,0],[fl[1],.8,1.5],[fl[2],.58,3],[fl[3],.32,4.2]].forEach(([c,k,dy],j)=>{g.fillStyle=c;g.beginPath();g.ellipse(0,-dy,15*k,8*k,0,0,TAU);g.fill();
  tongue(0,13*k,(56+5*Math.sin(ph+j))*k+dy,sw*k);tongue(-8*k,8*k,(34+9*Math.sin(ph*2+1+j))*k,-sw*.6*k-2);tongue(8.5*k,8*k,(40+9*Math.sin(ph*2+3.2+j))*k,sw*.5*k+2);
  if(j<2)tongue(-13*k,4.5*k,(18+7*Math.sin(ph+4))*k,-3*k)})}
function rpFlame(g,x,y,sc,t,ph,fl,key){const f=((t*13+ph*8)|0)%8,s=rpSpr('fl|'+key+'|'+f,-26,-74,52,82,q=>rpFlameArt(q,fl,f)),fy=1+.06*Math.sin(t*17+ph*9);
 g.drawImage(s.c,x-26*sc,y-74*sc*fy,52*sc,82*sc*fy)}
function rpSparks(g,x,y,t,n,h,col,ph,w){for(let i=0;i<n;i++){const k=(t*.9+i/n+ph)%1;rpGlow(g,x+Math.sin(k*9+i*2.1+ph*7)*(w||8),y-k*h,2.6+(1-k)*1.6,2.6+(1-k)*1.6,col,(1-k)*1.1)}}

/* ---------- crystals and bells ---------- */
function rpCrystal(g,x,y,h,w,tilt,C){g.save();g.translate(x,y);g.rotate(tilt);const hw=w/2,cw=w*.2,sh=h*.7,shc=sh+w*.16,b=w*.12;
 const poly=(pts,f)=>{g.beginPath();g.moveTo(pts[0][0],pts[0][1]);for(let i=1;i<pts.length;i++)g.lineTo(pts[i][0],pts[i][1]);g.closePath();g.fillStyle=f;g.fill()};
 poly([[-hw,0],[-hw,-sh],[-cw,-shc],[-cw,b]],rpVG(g,-sh,0,C.l,C.m));
 poly([[-cw,b],[-cw,-shc],[cw,-shc],[cw,b]],rpVG(g,-shc,b,rpMix(C.m,C.l,.35),rpMix(C.d,C.m,.4)));
 poly([[cw,b],[cw,-shc],[hw,-sh],[hw,0]],rpVG(g,-sh,0,C.d,C.k));
 poly([[-hw,-sh],[0,-h],[-cw,-shc]],'#ffffff');poly([[-cw,-shc],[0,-h],[cw,-shc]],C.l);poly([[cw,-shc],[0,-h],[hw,-sh]],C.m);
 g.lineWidth=1;g.strokeStyle='rgba(255,255,255,.6)';g.beginPath();g.moveTo(-cw,b);g.lineTo(-cw,-shc);g.lineTo(0,-h);g.stroke();g.strokeStyle=rpA(C.k,.6);g.beginPath();g.moveTo(cw,b);g.lineTo(cw,-shc);g.lineTo(-cw,-shc);g.stroke();
 g.strokeStyle='rgba(255,255,255,.85)';g.lineWidth=Math.max(1.2,w*.07);g.beginPath();g.moveTo(-hw+w*.12,-3);g.lineTo(-hw+w*.12,-sh+2);g.stroke();
 g.lineWidth=Math.max(.8,w*.04);g.beginPath();g.moveTo(-cw*.2,-sh*.25);g.lineTo(-cw*.2,-sh*.6);g.stroke();
 g.beginPath();g.moveTo(-hw,0);g.lineTo(-hw,-sh);g.lineTo(0,-h);g.lineTo(hw,-sh);g.lineTo(hw,0);g.lineTo(cw,b);g.lineTo(-cw,b);g.closePath();rpOut(g,Math.max(1.6,w*.11));g.restore()}
function rpShardArt(g,C){g.beginPath();g.moveTo(0,-11);g.lineTo(5,0);g.lineTo(0,11);g.lineTo(-5,0);g.closePath();g.fillStyle=rpVG(g,-11,11,C.l,C.d);g.fill();
 g.beginPath();g.moveTo(0,-11);g.lineTo(0,11);g.lineTo(5,0);g.closePath();g.fillStyle=rpA(C.k,.45);g.fill();g.beginPath();g.moveTo(0,-11);g.lineTo(5,0);g.lineTo(0,11);g.lineTo(-5,0);g.closePath();rpOut(g,1.8);
 g.strokeStyle='rgba(255,255,255,.85)';g.lineWidth=1.2;g.beginPath();g.moveTo(-2.4,-3);g.lineTo(-.6,-8);g.stroke()}
function rpBellArt(g,w,h,P){const B=P.bell;
 g.beginPath();g.arc(0,h*1.02,w*.09+1,0,TAU);g.fillStyle=B[3];g.fill();rpOut(g,1.6);
 g.beginPath();g.ellipse(0,0,w*.11,w*.13,0,0,TAU);g.lineWidth=w*.08+2.6;g.strokeStyle=RPTO;g.stroke();g.lineWidth=w*.08;g.strokeStyle=B[2];g.stroke();
 const t0=w*.1,path=()=>{g.beginPath();g.moveTo(-w*.24,t0+h*.06);g.quadraticCurveTo(0,t0-h*.08,w*.24,t0+h*.06);g.bezierCurveTo(w*.33,t0+h*.2,w*.3,h*.6,w*.5,h*.9);g.quadraticCurveTo(0,h*1.08,-w*.5,h*.9);g.bezierCurveTo(-w*.3,h*.6,-w*.33,t0+h*.2,-w*.24,t0+h*.06);g.closePath()};
 path();const q=g.createLinearGradient(-w*.5,0,w*.5,0);q.addColorStop(0,B[1]);q.addColorStop(.2,B[0]);q.addColorStop(.48,B[1]);q.addColorStop(.82,B[2]);q.addColorStop(1,B[3]);g.fillStyle=q;g.fill();
 g.save();path();g.clip();g.strokeStyle=P.band;g.lineWidth=Math.max(1.4,h*.06);g.beginPath();g.moveTo(-w*.4,t0+h*.26);g.quadraticCurveTo(0,t0+h*.32,w*.4,t0+h*.26);g.stroke();g.beginPath();g.moveTo(-w*.6,h*.76);g.quadraticCurveTo(0,h*.86,w*.6,h*.76);g.stroke();
 g.strokeStyle='rgba(255,255,255,.4)';g.lineWidth=Math.max(.8,h*.025);g.beginPath();g.moveTo(-w*.4,t0+h*.22);g.quadraticCurveTo(0,t0+h*.28,w*.4,t0+h*.22);g.stroke();
 const ey=h*.52,es=w*.13;g.beginPath();if(P.crown){g.moveTo(-es*1.2,ey+es*.6);g.lineTo(-es*1.2,ey-es*.5);g.lineTo(-es*.6,ey);g.lineTo(0,ey-es);g.lineTo(es*.6,ey);g.lineTo(es*1.2,ey-es*.5);g.lineTo(es*1.2,ey+es*.6)}
 else{g.moveTo(es*.3,ey-es*1.3);g.lineTo(-es*.7,ey+es*.15);g.lineTo(-es*.05,ey+es*.15);g.lineTo(-es*.4,ey+es*1.3);g.lineTo(es*.8,ey-es*.25);g.lineTo(es*.1,ey-es*.25)}g.closePath();g.fillStyle=P.band;g.fill();g.lineWidth=1;g.strokeStyle=RPTO;g.stroke();
 g.strokeStyle='rgba(255,255,255,.75)';g.lineWidth=Math.max(1.2,w*.06);g.beginPath();g.moveTo(-w*.16,t0+h*.12);g.quadraticCurveTo(-w*.26,h*.45,-w*.36,h*.82);g.stroke();g.restore();
 g.beginPath();g.moveTo(-w*.5,h*.9);g.quadraticCurveTo(0,h*1.08,w*.5,h*.9);g.lineWidth=Math.max(2,h*.08)+2.6;g.strokeStyle=RPTO;g.stroke();g.lineWidth=Math.max(2,h*.08);g.strokeStyle=B[2];g.stroke();g.lineWidth=1;g.strokeStyle=B[0];g.beginPath();g.moveTo(-w*.42,h*.89);g.quadraticCurveTo(-w*.2,h*.96,0,h*.97);g.stroke();
 path();rpOut(g,Math.max(1.8,w*.08))}
const rpBellS=(P,skin,w,h)=>rpSpr('bl|'+skin+'|'+w,-w*.6,-w*.25,w*1.2,h*1.25+w*.3,g=>rpBellArt(g,w,h,P));

/* ---------- layouts (screen offsets from the pad centre) ---------- */
const RPLAY={
 ballista:[0,{zt:38,s:1.2,top:72,runes:[]},{zt:43,s:1.36,top:82,runes:[]},{zt:49,s:1.52,top:118,runes:[[Math.cos(1.2)*35,Math.sin(1.2)*35*RPSQ-11],[Math.cos(1.94)*35,Math.sin(1.94)*35*RPSQ-11]]}],
 brazier:[0,{rim:-38,rx:30,top:88,vents:[[0,-38,.9]],runes:[[0,-23]]},{rim:-52,rx:33,top:108,vents:[[-31,-70,.5],[31,-70,.5],[0,-52,1.05]],runes:[[0,-36],[0,-10]]},
  {rim:-66,rx:38,top:132,vents:[[-38,-90,.58],[38,-90,.58],[-27,-43,.34],[27,-43,.34],[0,-66,1.25]],runes:[[0,-48],[0,-17]]}],
 frost:[0,{top:84,gl:[[0,-46,26]],rings:[]},{top:104,gl:[[0,-62,30],[-16,-50,18],[16,-50,18]],rings:[[-60,42]]},{top:136,gl:[[0,-82,34],[-19,-64,20],[19,-66,20]],rings:[[-64,48],[-96,36]],shard:-136,runes:[[Math.cos(1.25)*29,Math.sin(1.25)*29*RPSQ-22],[Math.cos(1.89)*29,Math.sin(1.89)*29*RPSQ-22]]}],
 bell:[0,{top:80,hang:-60,bw:28,bh:25,rod:-78,runes:[[0,-12]]},{top:116,hang:-80,bw:30,bh:27,rod:-114,runes:[[0,-16]]},{top:136,hang:-92,bw:34,bh:30,rod:-134,orb:-134,runes:[[0,-20]],minis:[[-54,-84],[54,-80]]}]};
function rpTowerTop(type,tier){const L=RPLAY[type];return L?L[Math.max(1,Math.min(3,tier|0))].top:100}

/* ---------- Rune Ballista ---------- */
function rpBallBase(g,tier,P){const S=P.stone;rpPadArt(g);
 const leg=(th,r0,z0,r1,z1,lw,col,hi)=>rpBeam(g,Math.cos(th)*r0,Math.sin(th)*r0*RPSQ-z0,Math.cos(th)*r1,Math.sin(th)*r1*RPSQ-z1,lw,col,hi);
 if(tier===1){const L=[-2.25,-.85,.62,2.5];for(const a of L)if(Math.sin(a)<0)leg(a,7,22,31,-1,5.5,P.wood,P.woodL);
  rpTube(g,0,0,11,10,32,P.woodL,P.wood,P.woodD);rpBand(g,0,0,11.2,7,4,P.ironL,P.iron,P.ironD,3);rpBand(g,0,0,10.6,22,4,P.ironL,P.iron,P.ironD,3);
  for(const a of L)if(Math.sin(a)>=0){leg(a,7,22,31,-1,5.5,P.wood,P.woodL);rpRiv(g,Math.cos(a)*31,Math.sin(a)*31*RPSQ+1,2.4,P.ironL)}
  rpTube(g,0,-32,21,21,6,P.ironL,P.iron,P.ironD);rpCap(g,0,-38,21,P.ironL,P.iron);g.strokeStyle=rpA(P.rune,.8);g.lineWidth=1.4;g.beginPath();g.ellipse(0,-38,14,14*RPSQ,0,0,TAU);g.stroke();
  for(let i=0;i<5;i++){const a=(i+.5)/5*Math.PI;rpRiv(g,Math.cos(a)*20,-35+Math.sin(a)*20*RPSQ,1.5,P.ironL)}}
 else if(tier===2){rpMason(g,0,0,31,29,14,S,1,5,11);rpTopStone(g,0,-14,29,S,4);
  const L=[-2.36,-.78,.78,2.36];for(const a of L)if(Math.sin(a)<0)leg(a,9,34,25,13,5,P.iron,P.ironL);
  rpTube(g,0,-14,12,11,22,P.woodL,P.wood,P.woodD);rpBand(g,0,-14,12.2,3,4,P.ironL,P.iron,P.ironD,3);rpBand(g,0,-14,11.4,15,4,P.ironL,P.iron,P.ironD,3);
  for(const a of L)if(Math.sin(a)>=0){leg(a,9,34,25,13,5,P.iron,P.ironL);rpRiv(g,Math.cos(a)*25,Math.sin(a)*25*RPSQ-13,2.6,P.trim)}
  rpTube(g,0,-36,25,25,7,P.ironL,P.iron,P.ironD);rpCap(g,0,-43,25,P.ironL,P.iron);g.strokeStyle=rpA(P.rune,.85);g.lineWidth=1.6;g.beginPath();g.ellipse(0,-43,17,17*RPSQ,0,0,TAU);g.stroke();
  for(let i=0;i<7;i++){const a=(i+.5)/7*Math.PI;rpRiv(g,Math.cos(a)*24.5,-39.5+Math.sin(a)*25*RPSQ,1.7,P.trim)}}
 else{/* banner pole at the back left */
  const px=-25,py=-28;rpBeam(g,px,py,px,-120,3.4,P.ironD,P.ironL);
  g.beginPath();g.moveTo(px,-116);g.quadraticCurveTo(px-18,-112,px-38,-114);g.lineTo(px-30,-104);g.lineTo(px-40,-94);g.quadraticCurveTo(px-20,-96,px,-92);g.closePath();g.fillStyle=rpHG(g,px-40,px,P.flagD,P.flag,P.flag);g.fill();rpOut(g,2.2);
  g.strokeStyle=P.trim;g.lineWidth=1.4;g.beginPath();g.moveTo(px-2,-113);g.quadraticCurveTo(px-18,-110,px-34,-112);g.stroke();
  g.fillStyle=P.trim;g.beginPath();g.moveTo(px-14,-109);g.lineTo(px-10,-104);g.lineTo(px-14,-99);g.lineTo(px-18,-104);g.closePath();g.fill();g.lineWidth=1;g.strokeStyle=RPTO;g.stroke();
  rpRiv(g,px,-122,3.4,P.trim);
  rpMason(g,0,0,37,34,22,S,2,6,17);rpBand(g,0,0,34.6,18,4.5,P.trimL,P.trim,P.trimD,8,P.trimL);rpTopStone(g,0,-22.5,34,S,7);
  for(const [x,y] of RPLAY.ballista[3].runes){g.beginPath();g.moveTo(x,y-7);g.lineTo(x+5.5,y);g.lineTo(x,y+7);g.lineTo(x-5.5,y);g.closePath();g.fillStyle=P.ironD;g.fill();rpOut(g,1.8);g.strokeStyle=rpA(P.rune,.9);g.lineWidth=1.3;g.beginPath();g.moveTo(x,y-4);g.lineTo(x,y+4);g.moveTo(x-2.5,y-1);g.lineTo(x+2.5,y+1.5);g.stroke()}
  const L=[-2.36,-.78,.78,2.36];for(const a of L)if(Math.sin(a)<0)leg(a,10,40,31,22,6,P.iron,P.ironL);
  rpTube(g,0,-23,15,14,18,P.woodL,P.wood,P.woodD);rpBand(g,0,-23,15.1,2,4,P.trimL,P.trim,P.trimD,3,P.trimL);rpBand(g,0,-23,14.4,12,4,P.ironL,P.iron,P.ironD,3);
  for(const a of L)if(Math.sin(a)>=0){leg(a,10,40,31,22,6,P.iron,P.ironL);rpRiv(g,Math.cos(a)*31,Math.sin(a)*31*RPSQ-22,3,P.trim)}
  rpTube(g,0,-41,31,31,8,P.ironL,P.iron,P.ironD);rpBand(g,0,-41,31.4,5,3.4,P.trimL,P.trim,P.trimD);rpCap(g,0,-49,31,P.ironL,P.iron);
  g.strokeStyle=rpA(P.rune,.9);g.lineWidth=1.6;g.beginPath();g.ellipse(0,-49,21,21*RPSQ,0,0,TAU);g.stroke();
  for(let i=0;i<12;i++){const a=i/12*TAU;g.beginPath();g.moveTo(Math.cos(a)*23,-49+Math.sin(a)*23*RPSQ);g.lineTo(Math.cos(a)*27,-49+Math.sin(a)*27*RPSQ);g.stroke()}}}
/* the turret, baked in RPFX.dirs yaw frames; u = forward, v = right, z = up, origin on the turntable top. It is projected a
   little steeper (RPTQ) than the ground so the bow reads clearly when it points at the camera. */
const RPTQ=.58;
function rpBallTopArt(g,tier,d,P){const s=RPLAY.ballista[tier].s,yw=d/RPFX.dirs*TAU,ca=Math.cos(yw),sa=Math.sin(yw),Q=RPTQ;
 const pr=(u,v,z)=>[(u*ca-v*sa)*s,((u*sa+v*ca)*Q-z)*s];
 const poly=(pts,fill,lw)=>{g.beginPath();pts.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.closePath();g.fillStyle=fill;g.fill();rpOut(g,lw||2)};
 const box=(u0,u1,v0,v1,z0,z1,cT,cS,cE,lw)=>{if(sa>.03)poly([pr(u1,v0,z0),pr(u1,v1,z0),pr(u1,v1,z1),pr(u1,v0,z1)],cE,lw);else if(sa<-.03)poly([pr(u0,v0,z0),pr(u0,v1,z0),pr(u0,v1,z1),pr(u0,v0,z1)],cE,lw);
  const vv=ca>0?v1:v0;if(Math.abs(ca)>.03)poly([pr(u0,vv,z0),pr(u1,vv,z0),pr(u1,vv,z1),pr(u0,vv,z1)],cS,lw);poly([pr(u0,v0,z1),pr(u1,v0,z1),pr(u1,v1,z1),pr(u0,v1,z1)],cT,lw)};
 const ln=(a,b,lw,col,hi,c)=>rpBeam(g,a[0],a[1],b[0],b[1],lw*s,col,hi,c);
 const T3=tier===3,R=tier===1?29:tier===2?33:35,zA=17;
 const yoke=()=>{for(const k of (ca>0?[-1,1]:[1,-1]))box(-9,1,k*9-1.6,k*9+1.6,0,11,P.wood,P.woodD,P.woodD,1.6)};
 const stock=()=>{box(-31,30,-4.6,4.6,8,14.5,P.woodL,P.wood,P.woodD);
  const a=pr(-27,0,14.5),b=pr(26,0,14.5);g.beginPath();g.moveTo(a[0],a[1]);g.lineTo(b[0],b[1]);g.lineWidth=1.6*s;g.strokeStyle=rpA(P.woodD,.8);g.stroke();
  for(const u of [-15,4])box(u-1.6,u+1.6,-5.2,5.2,7.6,15.1,P.ironL,P.iron,P.ironD,1.4)};
 const winch=()=>{const a=pr(-26,-11,13),b=pr(-26,11,13);ln(a,b,6,P.iron,P.ironL);for(const k of [-1,1]){const e=pr(-26,k*11.6,13);const h1=pr(-26,k*12.6,19),h2=pr(-26,k*12.6,13);ln(h2,h1,2,P.ironL);rpRiv(g,h1[0],h1[1],1.8*s,P.woodL);rpRiv(g,e[0],e[1],3.2*s,P.trim)}};
 const riser=()=>{box(17,27,-8,8,4,17,P.ironL,P.iron,P.ironD,2.2);
  if(sa>.03){const zc=10.5,k=6.2,pts=[pr(27,0,zc+k),pr(27,k*1.1,zc),pr(27,0,zc-k),pr(27,-k*1.1,zc)];poly(pts,P.ironD,1.6);
   const m=pr(27,0,zc),in2=pts.map(p=>[m[0]+(p[0]-m[0])*.55,m[1]+(p[1]-m[1])*.55]);poly(in2,P.rune,1.2);
   g.strokeStyle=P.runeL;g.lineWidth=1.2*s;const a=pr(27,0,zc+k*.42),b=pr(27,0,zc-k*.42);g.beginPath();g.moveTo(a[0],a[1]);g.lineTo(b[0],b[1]);g.stroke();
   for(const p of pts)rpRiv(g,p[0],p[1],1.3*s,P.trim)}
  for(const k of [-1,1]){const tp=pr(22,k*8,17);rpRiv(g,tp[0],tp[1],2.2*s,P.trim)}};
 const arms=(z,reach,lw,gold)=>{const order=ca>0?[-1,1]:[1,-1],tips=[];
  for(const k of order){const A=pr(23,k*7,z),C=pr(31,k*reach*.55,z),B=pr(17,k*reach,z),M=pr(26.5,k*reach*.5,z);
   ln(A,B,lw*.78,P.wood,P.woodL,C);ln(A,M,lw,P.wood,P.woodL,pr(28,k*reach*.3,z));
   if(tier>1){const m=pr(27.5,k*reach*.62,z);rpRiv(g,m[0],m[1],2.3*s,P.ironL)}
   const tc=pr(19,k*(reach+1.5),z);ln(B,tc,lw*.7,gold?P.trim:P.iron,gold?P.trimL:P.ironL);tips.push(B)}return order[0]<0?tips:[tips[1],tips[0]]};
 const str=(tp,z)=>{const n2=pr(-6,0,z);g.beginPath();g.moveTo(tp[0][0],tp[0][1]);g.lineTo(n2[0],n2[1]);g.lineTo(tp[1][0],tp[1][1]);g.lineWidth=2.8;g.strokeStyle=RPTO;g.stroke();g.lineWidth=1.3;g.strokeStyle=P.str;g.stroke();rpRiv(g,n2[0],n2[1],2*s,P.trim)};
 const bows=()=>{let t2=null;if(T3)t2=arms(zA-8,R*.86,6.4,1);const t1=arms(zA,R,tier===1?7:8,T3);if(t2)str(t2,zA-8);str(t1,zA)};
 yoke();
 if(sa>=0){winch();stock();bows();riser()}else{riser();stock();winch();bows()}}
function rpBallTopS(tier,skin,d){const s=RPLAY.ballista[tier].s,R=(44*s)+10;return rpSpr('bt|'+tier+'|'+skin+'|'+d,-R,-(30*s+R*RPTQ+6),2*R,30*s+2*R*RPTQ+16,g=>rpBallTopArt(g,tier,d,RPPAL.ballista[skin]),1.5)}
/* the loaded bolt(s), live: they leave on a shot and slide back in while fire falls from .55 to 0 */
function rpBallBolts(g,tier,P,yw,fire,ox,oy){const s=RPLAY.ballista[tier].s,ca=Math.cos(yw),sa=Math.sin(yw),pr=(u,v,z)=>[ox+(u*ca-v*sa)*s,oy+((u*sa+v*ca)*RPTQ-z)*s];
 if(fire>.55)return null;const sl=fire>0?(fire/.55)*-16:0,zb=19.5,vs=tier===3?[-2.8,2.8]:[0],heads=[];
 for(const v of vs){const sp=0,a=pr(-8+sl,v,zb),b=pr(36+sl,v+sp*4,zb),hd=pr(47+sl,v+sp*5.3,zb),w1=pr(37+sl,v+sp*4+4.2,zb),w2=pr(37+sl,v+sp*4-4.2,zb),bk=pr(40+sl,v+sp*4.4,zb),f1=pr(-8+sl,v+2.8,zb+1),f2=pr(-8+sl,v-2.8,zb+1),f0=pr(-1+sl,v,zb);
  g.beginPath();g.moveTo(a[0],a[1]);g.lineTo(b[0],b[1]);g.lineWidth=2.6*s+2.4;g.strokeStyle=RPTO;g.stroke();g.lineWidth=2.6*s;g.strokeStyle=P.shaft;g.stroke();
  for(const f of [f1,f2]){g.beginPath();g.moveTo(f[0],f[1]);g.lineTo(f0[0],f0[1]);g.lineTo(a[0]+(f0[0]-a[0])*.3,a[1]+(f0[1]-a[1])*.3);g.closePath();g.fillStyle=P.bolt;g.fill();g.lineWidth=1.2;g.strokeStyle=RPTO;g.stroke()}
  g.beginPath();g.moveTo(hd[0],hd[1]);g.lineTo(w1[0],w1[1]);g.lineTo(bk[0],bk[1]);g.lineTo(w2[0],w2[1]);g.closePath();g.fillStyle=P.bolt;g.fill();g.lineWidth=1.6;g.strokeStyle=RPTO;g.stroke();
  g.fillStyle=P.runeL;g.beginPath();g.arc((hd[0]+bk[0])/2,(hd[1]+bk[1])/2,1.4*s,0,TAU);g.fill();heads.push([(hd[0]*2+bk[0])/3,(hd[1]*2+bk[1])/3])}
 return heads}
function rpBallLive(g,tier,skin,P,t,o,L){const aim=o.aim==null?.5:o.aim,fire=o.fire||0,yw=Math.atan2(Math.sin(aim)/RPTQ,Math.cos(aim)),N=RPFX.dirs;
 let d=Math.round(yw/TAU*N)%N;if(d<0)d+=N;const yq=d/N*TAU,s=L.s,rc=fire*fire*6*s,ox=-Math.cos(aim)*rc,oy=-L.zt-Math.sin(aim)*rc*.6,sa=Math.sin(yq),ca=Math.cos(yq);
 rpPut(g,rpBallTopS(tier,skin,d),ox,oy);
 const hs=rpBallBolts(g,tier,P,yq,fire,ox,oy);
 g.globalCompositeOperation='lighter';
 if(hs)for(const h of hs)rpGlow(g,h[0],h[1],9*s,9*s,P.bolt,.7+.25*Math.sin(t*6));
 if(sa>.05){const px=ox+27*s*ca,py=oy+(27*sa*RPTQ-10.5)*s;rpGlow(g,px,py,12*s,12*s,P.rune,(.5+.2*Math.sin(t*3))*Math.min(1,sa*2))}
 if(fire>.01){const mx=ox+50*s*ca,my=oy+(50*sa*RPTQ-19.5)*s;rpGlow(g,mx,my,34*fire*s,34*fire*s,P.bolt,fire);rpGlow(g,mx,my,14*fire*s,14*fire*s,'#ffffff',fire)}
 g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}
/* ---------- Ember Brazier ---------- */
function rpBowl(g,cy,rx,dep,P,tier,part){const ry=rx*RPSQ;
 if(part!=='front'){
  g.beginPath();g.moveTo(-rx,cy);g.bezierCurveTo(-rx,cy+dep*.8,-rx*.52,cy+dep,0,cy+dep);g.bezierCurveTo(rx*.52,cy+dep,rx,cy+dep*.8,rx,cy);g.ellipse(0,cy,rx,ry,0,0,Math.PI,false);g.closePath();
  g.fillStyle=rpHG(g,-rx,rx,P.ironL,P.iron,P.ironD);g.fill();
  g.save();g.clip();for(let i=1;i<6;i++){const a=i/6*Math.PI,x=Math.cos(a)*rx*.98;g.beginPath();g.moveTo(x,cy+Math.sin(a)*ry);g.quadraticCurveTo(x*.92,cy+dep*.75,x*.5,cy+dep*1.02);g.lineWidth=3.4;g.strokeStyle=RPTO;g.stroke();g.lineWidth=1.8;g.strokeStyle=i<3?P.ironL:P.iron;g.stroke()}
  g.fillStyle='rgba(255,255,255,.22)';g.beginPath();g.ellipse(-rx*.55,cy+dep*.42,rx*.12,dep*.3,.35,0,TAU);g.fill();g.restore();
  g.beginPath();g.moveTo(-rx,cy);g.bezierCurveTo(-rx,cy+dep*.8,-rx*.52,cy+dep,0,cy+dep);g.bezierCurveTo(rx*.52,cy+dep,rx,cy+dep*.8,rx,cy);rpOut(g,2.8);
  /* the coals inside */
  g.beginPath();g.ellipse(0,cy,rx-3,ry-1.4,0,0,TAU);let q=g.createRadialGradient(0,cy+1,1,0,cy,rx);q.addColorStop(0,P.coalL);q.addColorStop(.35,P.coal);q.addColorStop(.8,P.coalD);q.addColorStop(1,'#1a0808');g.fillStyle=q;g.fill();
  for(let i=0;i<9;i++){const a=rpR(i+tier*13)*TAU,r=rpR(i+5)*.75,x=Math.cos(a)*(rx-6)*r,y=cy+Math.sin(a)*(ry-2)*r;g.beginPath();g.ellipse(x,y,3+rpR(i+9)*2.4,1.8+rpR(i+3),0,0,TAU);g.fillStyle=rpA(P.coalD,.85);g.fill();g.fillStyle=rpA(P.coalL,.7);g.beginPath();g.ellipse(x-.8,y-.6,1.4,.8,0,0,TAU);g.fill()}
  /* back half of the rim */
  g.beginPath();g.ellipse(0,cy,rx,ry,0,Math.PI,TAU);g.lineWidth=8;g.strokeStyle=RPTO;g.stroke();g.lineWidth=5;g.strokeStyle=P.trimD;g.stroke();g.lineWidth=1.4;g.strokeStyle=P.trim;g.beginPath();g.ellipse(0,cy-1.2,rx,ry,0,Math.PI,TAU);g.stroke()}
 if(part!=='back'){g.beginPath();g.ellipse(0,cy,rx,ry,0,0,Math.PI);g.lineWidth=9;g.strokeStyle=RPTO;g.stroke();g.lineWidth=6;g.strokeStyle=rpHG(g,-rx,rx,P.trimL,P.trim,P.trimD);g.stroke();
  g.lineWidth=1.6;g.strokeStyle='rgba(255,255,255,.6)';g.beginPath();g.ellipse(0,cy-1.6,rx,ry,0,Math.PI*.55,Math.PI*.98);g.stroke();
  for(let i=0;i<9;i++){const a=(i+.5)/9*Math.PI;rpRiv(g,Math.cos(a)*rx,cy+Math.sin(a)*ry,1.5,P.trimL)}}}
function rpRunePlate(g,x,y,w,P,glyph){g.beginPath();g.moveTo(x,y-w*1.15);g.lineTo(x+w,y);g.lineTo(x,y+w*1.15);g.lineTo(x-w,y);g.closePath();g.fillStyle=rpHG(g,x-w,x+w,P.trimL,P.trim,P.trimD);g.fill();rpOut(g,2);
 g.beginPath();g.moveTo(x,y-w*.75);g.lineTo(x+w*.62,y);g.lineTo(x,y+w*.75);g.lineTo(x-w*.62,y);g.closePath();g.fillStyle='#1c0e18';g.fill();g.lineWidth=1;g.strokeStyle=RPTO;g.stroke();
 g.strokeStyle=P.rune;g.lineWidth=1.5;g.beginPath();if(glyph==='bolt'){g.moveTo(x+w*.15,y-w*.5);g.lineTo(x-w*.2,y+w*.05);g.lineTo(x+w*.2,y-w*.05);g.lineTo(x-w*.15,y+w*.5)}else if(glyph==='flake'){for(let i=0;i<3;i++){const a=i*Math.PI/3+Math.PI/2;g.moveTo(x+Math.cos(a)*w*.45,y+Math.sin(a)*w*.5);g.lineTo(x-Math.cos(a)*w*.45,y-Math.sin(a)*w*.5)}}
 else{g.moveTo(x,y+w*.5);g.quadraticCurveTo(x-w*.4,y,x,y-w*.55);g.quadraticCurveTo(x+w*.4,y,x,y+w*.5)}g.stroke()}
function rpChimney(g,x,yb,yt,w,P){g.beginPath();g.rect(x-w/2,yt,w,yb-yt);g.fillStyle=rpHG(g,x-w/2,x+w/2,P.ironL,P.iron,P.ironD);g.fill();rpOut(g,2.2);
 for(const y of [yb-5,(yb+yt)/2])rpBand(g,x,y+2,w*.62,0,2.6,P.trimL,P.trim,P.trimD);
 rpTube(g,x,yt+2,w*.8,w*.95,5,P.trimL,P.trim,P.trimD,2);g.beginPath();g.ellipse(x,yt-3,w*.95,w*.95*RPSQ,0,0,TAU);g.fillStyle='#1a0808';g.fill();g.lineWidth=2;g.strokeStyle=P.trimD;g.stroke();g.lineWidth=1.2;g.strokeStyle=RPTO;g.stroke()}
function rpBrazBack(g,tier,P){const S=P.stone,L=RPLAY.brazier[tier];rpPadArt(g);
 const legs=(y0,y1,sp,lw)=>{for(const [x,b] of [[-sp,-1],[sp,-1],[-sp*.7,1],[sp*.7,1]]){const fy=y1+b*4;rpBeam(g,x*.55,y0,x,fy,lw,P.iron,P.ironL,[x*1.05,(y0+fy)/2]);g.beginPath();g.ellipse(x+(x<0?-2:2),fy+1,4.6,2.2,0,0,TAU);g.fillStyle=P.ironD;g.fill();rpOut(g,1.6)}};
 if(tier===1){legs(-24,0,24,4.6);rpBowl(g,L.rim,L.rx,24,P,1,'back');rpRunePlate(g,0,-23,6.5,P)}
 else if(tier===2){rpMason(g,0,0,24,21,26,S,2,5,21);
  g.beginPath();g.moveTo(-7,-3);g.lineTo(-7,-12);g.quadraticCurveTo(0,-20,7,-12);g.lineTo(7,-3);g.closePath();g.fillStyle='#1a0808';g.fill();rpOut(g,2);
  for(const x of [-3.5,0,3.5]){g.beginPath();g.moveTo(x,-3);g.lineTo(x,x?-12:-15);g.lineWidth=1.6;g.strokeStyle=P.iron;g.stroke()}
  legs(-32,-22,18,4);rpChimney(g,-31,-50,-66,8,P);rpChimney(g,31,-50,-66,8,P);rpBowl(g,L.rim,L.rx,24,P,2,'back');rpRunePlate(g,0,-36,7,P)}
 else{rpMason(g,0,0,32,26,40,S,3,6,29);rpBand(g,0,0,26.6,36,5,P.trimL,P.trim,P.trimD,7,P.trimL);
  g.beginPath();g.moveTo(-9,-4);g.lineTo(-9,-19);g.quadraticCurveTo(0,-30,9,-19);g.lineTo(9,-4);g.closePath();g.fillStyle='#1a0808';g.fill();g.lineWidth=5;g.strokeStyle=RPTO;g.stroke();g.lineWidth=2.6;g.strokeStyle=P.trimD;g.stroke();
  for(const x of [-4.5,0,4.5]){g.beginPath();g.moveTo(x,-4);g.lineTo(x,x?-20:-24);g.lineWidth=1.8;g.strokeStyle=P.iron;g.stroke()}
  for(const k of [-1,1]){rpChimney(g,k*27,-36,-46,6,P)}
  rpChimney(g,-38,-62,-86,9,P);rpChimney(g,38,-62,-86,9,P);
  for(let i=0;i<7;i++){const a=Math.PI+(i+.5)/7*Math.PI,x=Math.cos(a)*L.rx,y=L.rim+Math.sin(a)*L.rx*RPSQ;rpSpike(g,x,y,P)}
  rpBowl(g,L.rim,L.rx,26,P,3,'back');rpRunePlate(g,0,-48,7.5,P)}}
function rpSpike(g,x,y,P){g.beginPath();g.moveTo(x-3.6,y+1);g.lineTo(x,y-11);g.lineTo(x+3.6,y+1);g.closePath();g.fillStyle=rpHG(g,x-3.6,x+3.6,P.trimL,P.trim,P.trimD);g.fill();rpOut(g,1.8)}
function rpBrazFront(g,tier,P){const L=RPLAY.brazier[tier];rpBowl(g,L.rim,L.rx,24,P,tier,'front');
 if(tier===3)for(let i=0;i<7;i++){const a=(i+.5)/7*Math.PI,x=Math.cos(a)*L.rx,y=L.rim+Math.sin(a)*L.rx*RPSQ;rpSpike(g,x,y+1,P)}}
function rpBrazLive(g,tier,skin,P,t,o,L,ph){const fire=o.fire||0,fb=1+fire*.45;
 if(fire>.01){g.globalCompositeOperation='lighter';rpGlow(g,0,L.rim-14,L.rx*2.2,L.rx*1.8,P.glow2,fire*.7);g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}return fb}
function rpBrazFlames(g,tier,skin,P,t,o,L,ph,fb){let i=0;for(const [x,y,s] of L.vents){rpFlame(g,x,y+2,s*fb,t,ph+i*.37,P.fl,skin);i++}
 g.globalAlpha=RPGA;rpPut(g,rpSpr('bz|'+tier+'|'+skin+'|f',-64,-(L.top+20),128,L.top+66,q=>rpBrazFront(q,tier,P)));
 g.globalCompositeOperation='lighter';const v=L.vents[L.vents.length-1];rpSparks(g,v[0],v[1]-30*v[2],t,tier+1,70*v[2],P.glow2,ph,9*v[2]);g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}

/* ---------- Frost Spire ---------- */
function rptRing(g,cy,rx,P,half){const ry=rx*RPSQ,a0=half?0:Math.PI,a1=half?Math.PI:TAU;g.save();if(!half)g.globalAlpha=.8;
 g.beginPath();g.ellipse(0,cy,rx,ry,0,a0,a1);g.lineWidth=5;g.strokeStyle=rpA('#12081f',.8);g.stroke();g.lineWidth=2.6;g.strokeStyle=half?P.ring:rpMix(P.ring,P.metal,.35);g.stroke();
 g.lineWidth=1;g.strokeStyle='#ffffff';g.beginPath();g.ellipse(0,cy-.9,rx,ry,0,a0+.15,a1-.15);g.stroke();
 for(let i=0;i<3;i++){const a=a0+(i+.5)/3*(a1-a0)+.3,x=Math.cos(a)*rx,y=cy+Math.sin(a)*ry;g.beginPath();g.moveTo(x,y-5.5);g.lineTo(x+3,y);g.lineTo(x,y+5.5);g.lineTo(x-3,y);g.closePath();g.fillStyle=half?P.ring:rpMix(P.ring,P.metal,.35);g.fill();rpOut(g,1.4);g.fillStyle='#fff';g.fillRect(x-1.2,y-3,1,2.4)}
 g.restore()}
function rpFrostArt(g,tier,P){const S=P.stone,C=P.cr,c2=C[1]||C[0],L=RPLAY.frost[tier];rpPadArt(g);
 if(tier===1){rpMason(g,0,0,24,21,14,S,1,5,41);rpTopStone(g,0,-14,21,S,3);
  rpTube(g,0,-13,17,15,9,P.metalL,P.metal,P.metalD);rpBand(g,0,-13,17.2,6,3,P.trimL,P.trim,P.trimD,5,P.trimL);
  rpCrystal(g,0,-17,60,22,0,C[0]);
  for(const k of [-1,1])rpBeam(g,k*14,-21,k*9,-34,3,P.trim,P.trimL)}
 else if(tier===2){rpMason(g,0,0,29,26,20,S,2,5,43);rpTopStone(g,0,-20,26,S,5);rptRing(g,-60,42,P,0);
  rpTube(g,0,-20,22,20,10,P.metalL,P.metal,P.metalD);rpBand(g,0,-20,22.2,7,3.4,P.trimL,P.trim,P.trimD,6,P.trimL);
  rpCrystal(g,-13,-28,42,15,-.32,c2);rpCrystal(g,14,-28,46,16,.3,c2);rpCrystal(g,0,-26,74,24,0,C[0]);
  for(const k of [-1,1])rpBeam(g,k*18,-30,k*11,-44,3.2,P.trim,P.trimL);rptRing(g,-60,42,P,1)}
 else{rpMason(g,0,0,35,33,14,S,1,6,47);rpTopStone(g,0,-14,33,S,6);rpMason(g,0,-14,28,26,18,S,2,5,49);rpBand(g,0,-14,26.6,15,4,P.trimL,P.trim,P.trimD,6,P.trimL);
  for(const [x,y] of L.runes)rpRunePlate(g,x,y,5,{trim:P.metal,trimL:P.metalL,trimD:P.metalD,rune:P.rune},'flake');
  rptRing(g,-64,48,P,0);rptRing(g,-96,36,P,0);
  rpTube(g,0,-32,25,23,11,P.metalL,P.metal,P.metalD);rpBand(g,0,-32,25.2,8,3.6,P.trimL,P.trim,P.trimD,7,P.trimL);
  rpCrystal(g,-9,-44,40,13,-.12,c2);rpCrystal(g,10,-44,44,13,.14,C[0]);
  rpCrystal(g,-17,-38,52,17,-.34,C[0]);rpCrystal(g,18,-38,56,17,.32,c2);rpCrystal(g,0,-37,88,27,0,C[0]);
  for(const k of [-1,1])rpBeam(g,k*20,-42,k*12,-58,3.6,P.trim,P.trimL);for(const k of [-1,1])rpRiv(g,k*12,-58,2.4,P.trimL);
  rptRing(g,-64,48,P,1);rptRing(g,-96,36,P,1)}}
function rpShardS(skin,k,C,P){return rpSpr('fs|'+skin+'|'+k,-16,-20,32,40,q=>{q.globalCompositeOperation='lighter';q.globalAlpha=.55;q.drawImage(rpGlowC(k?P.glow2||P.glow:P.glow),-16,-18,32,36);q.globalAlpha=1;q.globalCompositeOperation='source-over';rpShardArt(q,C)})}
function rpFrostLive(g,tier,skin,P,t,o,L,ph,pass){const fire=o.fire||0,C=P.cr,c2=C[1]||C[0];
 if(tier>1){const n=tier===3?4:3,R=tier===3?46:40,zc=tier===3?-78:-60,s0=rpShardS(skin,0,C[0],P),s1=rpShardS(skin,1,c2,P);g.globalAlpha=RPGA*(pass?1:.7);
  for(let i=0;i<n;i++){const a=t*.9+i/n*TAU+ph,sn=Math.sin(a);if(pass===0&&sn>=0||pass===1&&sn<0)continue;const x=Math.cos(a)*R,y=zc+sn*R*RPSQ+Math.sin(t*2+i)*3,w=32*(.8+.2*Math.abs(Math.cos(a)));
   g.drawImage((i%2?s1:s0).c,x-w/2,y-20,w,40)}g.globalAlpha=RPGA}
 if(pass===0)return;
 g.globalCompositeOperation='lighter';
 for(let k=0;k<4;k++){const a=k*2.4+ph,tw=Math.sin(t*3.2+k*1.9);if(tw<.3)continue;const x=Math.cos(a)*(10+k*3),y=-L.top*(.35+.14*k);const r=3+tw*4;g.globalAlpha=RPGA*tw;g.fillStyle='#ffffff';g.fillRect(x-r,y-.6,r*2,1.2);g.fillRect(x-.6,y-r,1.2,r*2)}
 for(const [cy,rx] of L.rings){const a=t*1.4+ph+rx,sn=Math.sin(a);if(sn>-.2)rpGlow(g,Math.cos(a)*rx,cy+sn*rx*RPSQ,7,7,'#ffffff',.9)}
 if(fire>.01)rpGlow(g,0,-L.top*.55,70*fire,50*fire,P.glow2||P.glow,fire*.8);
 g.globalCompositeOperation='source-over';g.globalAlpha=RPGA;
 if(L.shard){const y=L.shard+Math.sin(t*1.8+ph)*4,s0=rpShardS(skin,0,C[0],P);g.drawImage(s0.c,-21,y-26,42,52)}}

/* ---------- Storm Bell ---------- */
function rpPillar(g,x,yb,yt,w,P){rpBeam(g,x,yb,x,yt,w,P.stone.m,P.stone.l);rpTube(g,x,yb+2,w*.8,w*.75,4,P.stone.l,P.stone.m,P.stone.d,1.8);rpTube(g,x,yt+3,w*.7,w*.8,4,P.trimL,P.trim,P.trimD,1.8)}
function rpRoof(g,cy,rx,ay,P){g.beginPath();g.moveTo(-rx,cy);g.lineTo(0,ay);g.lineTo(rx,cy);g.ellipse(0,cy,rx,rx*RPSQ,0,0,Math.PI,false);g.closePath();g.fillStyle=rpHG(g,-rx,rx,P.roofL,P.roof,P.roofD);g.fill();
 g.save();g.clip();g.strokeStyle=rpA(P.roofD,.9);g.lineWidth=1.4;for(let k=1;k<4;k++){const f=k/4,r=rx*f,yy=ay+(cy-ay)*f;g.beginPath();g.ellipse(0,yy,r,r*RPSQ,0,.05,Math.PI-.05);g.stroke()}
 for(let i=1;i<8;i++){const a=i/8*Math.PI;g.beginPath();g.moveTo(0,ay);g.lineTo(Math.cos(a)*rx,cy+Math.sin(a)*rx*RPSQ);g.stroke()}
 g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=2;g.beginPath();g.moveTo(-2,ay+4);g.lineTo(-rx*.62,cy+rx*RPSQ*.5);g.stroke();g.restore();
 g.beginPath();g.moveTo(-rx,cy);g.lineTo(0,ay);g.lineTo(rx,cy);g.ellipse(0,cy,rx,rx*RPSQ,0,0,Math.PI,false);g.closePath();rpOut(g,2.8);
 g.beginPath();g.ellipse(0,cy,rx,rx*RPSQ,0,0,Math.PI);g.lineWidth=6.4;g.strokeStyle=RPTO;g.stroke();g.lineWidth=3.6;g.strokeStyle=rpHG(g,-rx,rx,P.trimL,P.trim,P.trimD);g.stroke();
 for(let i=0;i<7;i++){const a=(i+.5)/7*Math.PI;rpRiv(g,Math.cos(a)*rx,cy+Math.sin(a)*rx*RPSQ,1.4,P.trimL)}}
function rpBellBack(g,tier,P){const S=P.stone,L=RPLAY.bell[tier];rpPadArt(g);
 if(tier===1){rpMason(g,0,0,25,23,24,S,2,5,61);rpTopStone(g,0,-24,23,S,2);rpRunePlate(g,0,-12,6.5,P,'bolt');
  for(const k of [-1,1]){rpBeam(g,k*19,-24,k*17,-66,6.5,P.wood,P.woodL);rpBeam(g,k*17,-38,k*8,-60,3.4,P.woodD)}}
 else{const zb=tier===2?32:42,zt=tier===2?84:98,px=tier===2?20:23,pz=8;
  rpMason(g,0,0,tier===2?29:33,tier===2?27:30,zb,S,tier===2?3:3,6,63+tier);if(tier===3)rpBand(g,0,0,30.4,zb-5,5,P.trimL,P.trim,P.trimD,7,P.trimL);
  rpTopStone(g,0,-zb,tier===2?27:30,S,4,rpA(P.rune,.5));rpRunePlate(g,0,L.runes[0][1],7,P,'bolt');
  for(const k of [-1,1])rpPillar(g,k*px,-zb-pz*RPSQ,-zt-pz*RPSQ,7,P);
  g.beginPath();g.moveTo(0,-zt+2);g.lineTo(0,L.hang);g.lineWidth=4;g.strokeStyle=RPTO;g.stroke();g.lineWidth=2;g.strokeStyle=P.iron;g.stroke()}}
function rpBellFront(g,tier,P){const L=RPLAY.bell[tier];
 if(tier===1){rpBeam(g,-26,-64,26,-64,7.5,P.wood,P.woodL);for(const k of [-1,1])rpRiv(g,k*17,-64,2.4,P.trim);
  rpBeam(g,0,-68,0,-76,3,P.iron,P.ironL);rpRiv(g,0,-78,3.6,P.trim)}
 else{const zb=tier===2?32:42,zt=tier===2?84:98,px=tier===2?20:23,pz=8,rx=tier===2?30:35,ay=tier===2?-108:-124;
  for(const k of [-1,1])rpPillar(g,k*px,-zb+pz*RPSQ,-zt+pz*RPSQ,7.5,P);
  rpRoof(g,-zt,rx,ay,P);
  if(tier===2){rpBeam(g,0,ay+2,0,L.rod+4,2.8,P.iron,P.ironL);rpRiv(g,0,ay+1,3.4,P.trim);rpRiv(g,0,L.rod+2,3,P.trim)}
  else{rpBeam(g,0,ay+2,0,L.orb+6,3.2,P.iron,P.ironL);for(const y of [ay-2,ay-7])rpBand(g,0,y+1.5,4.6,0,2.4,P.trimL,P.trim,P.trimD);rpRiv(g,0,ay+1,3.8,P.trim);
   g.beginPath();g.arc(0,L.orb,6.5,0,TAU);g.fillStyle=rpMix(P.bolt,'#ffffff',.5);g.fill();rpOut(g,2.2);g.fillStyle='#ffffff';g.beginPath();g.arc(-2,L.orb-2,2,0,TAU);g.fill()}}}
function rpBellLive(g,tier,skin,P,t,o,L,ph){const fire=o.fire||0,sw=Math.sin(t*1.9+ph)*.07+fire*Math.sin(fire*16)*.32;
 g.save();g.translate(0,L.hang);g.rotate(sw);rpPut(g,rpBellS(P,skin,L.bw,L.bh));g.restore()}
function rpBellTopLive(g,tier,skin,P,t,o,L,ph){const fire=o.fire||0,col=RPLC[skin]||RPLC.base;
 g.globalCompositeOperation='lighter';
 const tip=tier===3?L.orb:L.rod;if(fire>.01)rpGlow(g,0,tip,16+fire*30,16+fire*30,P.glow,fire);
 if(L.minis){for(let i=0;i<2;i++){const [x,y]=L.minis[i],yy=y+Math.sin(t*2.2+i*2+ph)*4;rpGlow(g,x,yy+8,16,16,P.glow,.45);rpZap(g,0,tip,x,yy-2,t+i*.37,col,.85)}}
 else if(fire>.2)for(let i=0;i<2;i++){const a=-Math.PI/2+(i?.8:-.8);rpZap(g,0,tip,Math.cos(a)*24,tip+Math.sin(a)*-8+10,t+i,col,fire)}
 g.globalCompositeOperation='source-over';g.globalAlpha=RPGA;
 if(L.minis)for(let i=0;i<2;i++){const [x,y]=L.minis[i],yy=y+Math.sin(t*2.2+i*2+ph)*4;g.save();g.translate(x,yy-8);g.rotate(Math.sin(t*2.6+i)*.14);rpPut(g,rpBellS(P,skin,16,15));g.restore()}}

/* ---------- lightning ---------- */
function rpZigPath(g,x1,y1,x2,y2,seed,amp){const dx=x2-x1,dy=y2-y1,d=Math.hypot(dx,dy)||1,n=Math.max(3,Math.min(14,d/12|0)),nx=-dy/d,ny=dx/d;g.beginPath();g.moveTo(x1,y1);
 for(let i=1;i<n;i++){const f=i/n,o=(rpR(seed*13.7+i)-.5)*2*amp*Math.sin(Math.PI*f);g.lineTo(x1+dx*f+nx*o,y1+dy*f+ny*o)}g.lineTo(x2,y2)}

/* ---------- the tower ---------- */
function rpBack(type,tier,skin){const P=RPPAL[type][skin],top=RPLAY[type][tier].top;return rpSpr('tw|'+type+'|'+tier+'|'+skin,-66,-(top+18),132,top+64,g=>{
 if(type==='ballista')rpBallBase(g,tier,P);else if(type==='brazier')rpBrazBack(g,tier,P);else if(type==='frost')rpFrostArt(g,tier,P);else rpBellBack(g,tier,P)})}
/* every static glow of a tower in one baked layer (tight bounds), stamped with 'lighter' and a pulsing alpha */
function rpGlowList(type,tier,P,L){const G=[],A=(x,y,rx,ry,c,a)=>G.push([x,y,rx,ry,c,a]);
 if(type==='ballista'){for(const [x,y] of L.runes)A(x,y,12,12,P.rune,.7);A(0,-L.zt,26*L.s,11*L.s,P.rune,.35)}
 else if(type==='brazier'){A(0,L.rim-10,L.rx*1.9,L.rx*1.5,P.glow,.5);for(const [x,y] of L.runes)A(x,y,12,12,P.rune,.8);for(const [x,y,s] of L.vents)A(x,y-14*s,26*s,24*s,P.glow2,.4)}
 else if(type==='frost'){let i=0;for(const [x,y,r] of L.gl){A(x,y,r*1.5,r*1.7,i%2&&P.glow2?P.glow2:P.glow,.42);i++}if(L.runes)for(const [x,y] of L.runes)A(x,y,10,10,P.rune,.7);if(L.shard)A(0,L.shard,22,22,P.glow,.6)}
 else{for(const [x,y] of L.runes)A(x,y,12,12,P.rune,.8);A(0,tier===3?L.orb:L.rod,17,17,P.glow,.75)}return G}
function rpGlowLayer(type,tier,skin){const k='gl|'+type+'|'+tier+'|'+skin,s=RPSPR.get(k);if(s)return s;const P=RPPAL[type][skin],L=RPLAY[type][tier],G=rpGlowList(type,tier,P,L);
 let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;for(const [x,y,rx,ry] of G){x0=Math.min(x0,x-rx);y0=Math.min(y0,y-ry);x1=Math.max(x1,x+rx);y1=Math.max(y1,y+ry)}
 return rpSpr(k,Math.floor(x0),Math.floor(y0),Math.ceil(x1-x0)+1,Math.ceil(y1-y0)+1,g=>{const ga=RPGA;RPGA=1;g.globalCompositeOperation='lighter';for(const [x,y,rx,ry,c,a] of G)rpGlow(g,x,y,rx,ry,c,a);RPGA=ga})}
const RPPULSE={ballista:[2.4,.22],brazier:[9,.16],frost:[2.6,.25],bell:[4,.2]};
function rpTowerDraw(g,type,tier,skin,t,o){o=o||{};t=t||0;if(!RPPAL[type])return;tier=Math.max(1,Math.min(3,tier|0||1));if(!RPPAL[type][skin])skin='base';
 const P=RPPAL[type][skin],L=RPLAY[type][tier],over=o.over||0,ph=o.ph||0;
 g.save();RPGA=o.ghost?.5:1;g.globalAlpha=RPGA;g.lineJoin='round';g.lineCap='round';
 if(o.sel){const p=.5+.5*Math.sin(t*4);g.globalCompositeOperation='lighter';rpGlow(g,0,14,82,36,'#ffc94a',.3+.15*p);
  g.globalAlpha=RPGA;g.lineWidth=7;g.strokeStyle='rgba(255,201,74,.25)';g.beginPath();g.ellipse(0,15,64,26,0,0,TAU);g.stroke();g.globalCompositeOperation='source-over';
  g.lineWidth=5;g.strokeStyle=RPTO;g.stroke();g.lineWidth=2.6;g.strokeStyle='rgba(255,212,90,'+(.75+.25*p).toFixed(3)+')';g.stroke()}
 if(type==='frost')rpFrostLive(g,tier,skin,P,t,o,L,ph,0);
 g.globalAlpha=RPGA;rpPut(g,rpBack(type,tier,skin));
 {const q=RPPULSE[type];g.globalCompositeOperation='lighter';g.globalAlpha=RPGA*(1-q[1]+q[1]*Math.sin(t*q[0]+ph*7));rpPut(g,rpGlowLayer(type,tier,skin));g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}
 if(type==='ballista')rpBallLive(g,tier,skin,P,t,o,L);
 else if(type==='brazier'){const fb=rpBrazLive(g,tier,skin,P,t,o,L,ph);rpBrazFlames(g,tier,skin,P,t,o,L,ph,fb)}
 else if(type==='frost')rpFrostLive(g,tier,skin,P,t,o,L,ph,1);
 else{rpBellLive(g,tier,skin,P,t,o,L,ph);g.globalAlpha=RPGA;rpPut(g,rpSpr('bf|'+tier+'|'+skin,-66,-(L.top+18),132,L.top,q=>rpBellFront(q,tier,P)));rpBellTopLive(g,tier,skin,P,t,o,L,ph)}
 if(over>.01&&!o.ghost)rpOvercharge(g,0,0,t,over,L.top);
 g.restore();RPGA=1}
/* bake everything a tower needs up front (all turret directions for a ballista), e.g. when the mode opens, so nothing is painted mid-fight */
function rpTowerWarm(type,tier,skin){if(!RPPAL[type])return;skin=RPPAL[type][skin]?skin:'base';const P=RPPAL[type][skin],L=RPLAY[type][tier];rpPadS();rpBack(type,tier,skin);rpGlowLayer(type,tier,skin);
 if(type==='ballista')for(let d=0;d<RPFX.dirs;d++)rpBallTopS(tier,skin,d);
 else if(type==='brazier'){rpSpr('bz|'+tier+'|'+skin+'|f',-64,-(L.top+20),128,L.top+66,q=>rpBrazFront(q,tier,P));for(let f=0;f<8;f++)rpSpr('fl|'+skin+'|'+f,-26,-74,52,82,q=>rpFlameArt(q,P.fl,f))}
 else if(type==='frost'){rpShardS(skin,0,P.cr[0],P);rpShardS(skin,1,P.cr[1]||P.cr[0],P)}
 else{rpSpr('bf|'+tier+'|'+skin,-66,-(L.top+18),132,L.top,q=>rpBellFront(q,tier,P));rpBellS(P,skin,L.bw,L.bh);if(L.minis)rpBellS(P,skin,16,15)}}
function rpTowerIcon(type,tier,skin,size){size=Math.max(16,size|0||96);const key='ic|'+type+'|'+tier+'|'+skin+'|'+size;let s=RPSPR.get(key);if(s)return s.c;
 const c=document.createElement('canvas');c.width=c.height=size;const top=rpTowerTop(type,tier)+6,h=top+46,k=Math.min(size*.95/h,size*.95/134),g=c.getContext('2d');g.translate(size/2,size/2+(top-46)/2*k);g.scale(k,k);
 try{rpTowerDraw(g,type,tier,skin,.42,{aim:.55,ph:.3})}catch(e){console.error(e)}RPSPR.set(key,{c});return c}

/* ---------- projectiles and effects ---------- */
function rpBoltArt(g,P){g.beginPath();g.moveTo(-40,0);g.lineTo(-6,0);g.lineWidth=5.4;g.strokeStyle=RPTO;g.stroke();g.lineWidth=3;g.strokeStyle=P.shaft;g.stroke();g.lineWidth=1;g.strokeStyle='rgba(255,255,255,.6)';g.beginPath();g.moveTo(-38,-.8);g.lineTo(-8,-.8);g.stroke();
 for(const k of [-1,1]){g.beginPath();g.moveTo(-42,k*6);g.lineTo(-33,0);g.lineTo(-28,0);g.lineTo(-36,k*6);g.closePath();g.fillStyle=P.bolt;g.fill();g.lineWidth=1.3;g.strokeStyle=RPTO;g.stroke()}
 for(const x of [-24,-16])rpRiv(g,x,0,1.4,P.bolt);
 g.beginPath();g.moveTo(6,0);g.lineTo(-8,-6);g.lineTo(-4,0);g.lineTo(-8,6);g.closePath();g.fillStyle=rpHG(g,-8,6,P.boltL,P.bolt,P.bolt);g.fill();g.lineWidth=1.8;g.strokeStyle=RPTO;g.stroke();
 g.fillStyle='#ffffff';g.beginPath();g.arc(-3,0,1.4,0,TAU);g.fill();
 if(P.sun){g.strokeStyle=P.boltL;g.lineWidth=1.5;for(let i=0;i<8;i++){const a=i*Math.PI/4;g.beginPath();g.moveTo(-1+Math.cos(a)*8,Math.sin(a)*8);g.lineTo(-1+Math.cos(a)*11.5,Math.sin(a)*11.5);g.stroke()}}}
function rpBolt(g,x,y,ang,skin){const sk=RPPAL.ballista[skin]?skin:'base',P=RPPAL.ballista[sk];g.save();g.translate(x,y);g.rotate(ang);g.scale(1.2,1.2);g.globalCompositeOperation='lighter';
 g.globalAlpha=.8;g.drawImage(rpSpr('btr|'+sk,-84,-7,90,14,q=>{const r=q.createLinearGradient(-84,0,0,0);r.addColorStop(0,rpA(P.bolt,0));r.addColorStop(1,rpA(P.bolt,.95));q.fillStyle=r;q.beginPath();q.moveTo(-84,0);q.lineTo(0,-4);q.lineTo(0,4);q.closePath();q.fill()}).c,-84,-7,90,14);
 rpGlow(g,-1,0,18,18,P.bolt,.9);g.globalCompositeOperation='source-over';g.globalAlpha=1;rpPut(g,rpSpr('bo|'+sk,-46,-13,60,26,q=>rpBoltArt(q,P)));
 g.globalCompositeOperation='lighter';rpGlow(g,0,0,8,8,'#ffffff',.9);g.restore()}
function rpEmberArt(g,P){g.beginPath();g.arc(0,0,10,0,TAU);const r=g.createRadialGradient(-3,-3,0,0,0,10);r.addColorStop(0,P.fl[3]);r.addColorStop(.4,P.fl[2]);r.addColorStop(.8,P.fl[1]);r.addColorStop(1,P.fl[0]);g.fillStyle=r;g.fill();rpOut(g,2.2);
 g.fillStyle=rpA(P.coalD,.55);for(const [a,b,c] of [[3.6,2.4,2],[-2.6,4.6,1.6],[4.6,-2.4,1.4],[-4.8,-.6,1.2]]){g.beginPath();g.arc(a,b,c,0,TAU);g.fill()}
 g.fillStyle='rgba(255,255,255,.85)';g.beginPath();g.ellipse(-3.6,-4,2.6,1.6,-.6,0,TAU);g.fill()}
function rpEmber(g,x,y,t,skin){const sk=RPPAL.brazier[skin]?skin:'base',P=RPPAL.brazier[sk];g.save();g.globalCompositeOperation='lighter';rpGlow(g,x,y,34,34,P.glow,.8);
 g.globalCompositeOperation='source-over';g.globalAlpha=1;for(let i=0;i<4;i++){const k=(t*2.2+i/4)%1,r=(1-k)*3.2+.8;g.fillStyle=i%2?P.fl[2]:P.fl[1];g.beginPath();g.arc(x+Math.sin(i*2.1+t*4)*5,y-k*22+2,r,0,TAU);g.fill()}
 rpFlame(g,x,y+3,.66,t,.2,P.fl,sk);rpPut(g,rpSpr('em|'+sk,-13,-13,26,26,q=>rpEmberArt(q,P)),x,y);
 g.globalCompositeOperation='lighter';rpGlow(g,x-2,y-2,9,9,'#ffffff',.7);g.restore()}
function rpPuff(g,x,y,R,cols){const o=[[0,0,1],[-.55,.15,.7],[.55,.12,.72],[-.25,-.45,.66],[.3,-.42,.62]];g.fillStyle=RPTO;for(const [a,b,c] of o){g.beginPath();g.arc(x+a*R,y+b*R,c*R+2.2,0,TAU);g.fill()}
 for(let j=0;j<cols.length;j++){g.fillStyle=cols[j];const sh=1-j*.26;for(const [a,b,c] of o){g.beginPath();g.arc(x+a*R*sh-j*R*.06,y+b*R*sh-j*R*.08,c*R*sh,0,TAU);g.fill()}}}
function rpBurst(g,x,y,k,r,skin){if(!(k>=0&&k<=1))return;const sk=RPPAL.brazier[skin]?skin:'base',P=RPPAL.brazier[sk],e=1-Math.pow(1-k,3),sq=RPFX.sq,f=1-k;g.save();g.lineCap='round';
 g.fillStyle='rgba(24,8,8,'+(.32*f).toFixed(3)+')';g.beginPath();g.ellipse(x,y,r*.62,r*.62*sq,0,0,TAU);g.fill();
 g.globalCompositeOperation='lighter';rpGlow(g,x,y-r*.15,r*(.7+.5*e),r*(.6+.4*e),P.glow,f*f*1.2);g.globalCompositeOperation='source-over';
 const R=r*(.2+.82*e);g.globalAlpha=Math.min(1,f*1.4);g.lineWidth=3+7*f;g.strokeStyle=P.fl[1];g.beginPath();g.ellipse(x,y,R,R*sq,0,0,TAU);g.stroke();g.lineWidth=1+2*f;g.strokeStyle=P.fl[3];g.beginPath();g.ellipse(x,y,R*.94,R*.94*sq,0,0,TAU);g.stroke();
 if(k>.3){const s=(k-.3)/.7;g.globalAlpha=.55*(1-s);for(let i=0;i<4;i++){const a=i*1.7+.5;g.fillStyle=i%2?'#4a4058':'#5e5470';g.beginPath();g.arc(x+Math.cos(a)*r*.3*(1+s),y-r*(.15+.45*s)-i*3,r*(.14+.12*s),0,TAU);g.fill()}}
 g.globalAlpha=1;if(k<.55){const kk=k/.55;rpPuff(g,x,y-r*.16-kk*r*.12,r*.3*(.7+.5*Math.sin(Math.PI*Math.min(1,kk*1.6)))*(1-kk*.55),[P.fl[0],P.fl[1],P.fl[2],P.fl[3]])}
 for(let i=0;i<9;i++){const a=i/9*TAU+.4,d=r*(.12+.8*e)*(.75+rpR(i)*.35),lift=Math.sin(Math.PI*Math.min(1,k*1.25))*r*.5*(.5+rpR(i+3)),rr=(2.4+rpR(i+7)*3)*f+1;if(k>.95||k<.14)break;const px=x+Math.cos(a)*d,py=y+Math.sin(a)*d*sq-lift;
  g.fillStyle=RPTO;g.beginPath();g.arc(px,py,rr+1.4,0,TAU);g.fill();g.fillStyle=i%2?P.fl[2]:P.fl[1];g.beginPath();g.arc(px,py,rr,0,TAU);g.fill()}
 g.globalCompositeOperation='lighter';if(k<.3)rpGlow(g,x,y-r*.2,r*.5,r*.5,'#ffffff',(1-k/.3)*.9);g.restore()}
function rpFlakeArt(g,col){g.lineCap='round';for(const [lw,c] of [[3.6,RPTO],[1.8,col]]){g.lineWidth=lw;g.strokeStyle=c;g.beginPath();for(let i=0;i<6;i++){const a=i*Math.PI/3,ca=Math.cos(a),sa=Math.sin(a);g.moveTo(0,0);g.lineTo(ca*9,sa*9);
  const bx=ca*5.4,by=sa*5.4;for(const s of [-1,1]){const b=a+s*.8;g.moveTo(bx,by);g.lineTo(bx+Math.cos(b)*3.2,by+Math.sin(b)*3.2)}}g.stroke()}
 g.fillStyle='#ffffff';g.beginPath();g.arc(0,0,1.8,0,TAU);g.fill()}
const rpFlakeS=col=>rpSpr('fk|'+col,-11,-11,22,22,q=>rpFlakeArt(q,col));
function rpFrostPulse(g,x,y,k,r,skin){if(!(k>=0&&k<=1))return;const sk=RPPAL.frost[skin]?skin:'base',P=RPPAL.frost[sk],e=1-Math.pow(1-k,2.4),f=1-k,sq=RPFX.sq,R=r*(.15+.85*e);g.save();
 g.globalCompositeOperation='lighter';rpGlow(g,x,y,R*1.1,R*sq*1.2,P.glow,f*.5);g.globalCompositeOperation='source-over';
 g.globalAlpha=f*.35;g.fillStyle=P.ring;g.beginPath();g.ellipse(x,y,R,R*sq,0,0,TAU);g.fill();
 g.globalAlpha=Math.min(1,f*1.5);g.lineWidth=6*f+3;g.strokeStyle=rpA(P.cr[0].d,.75);g.beginPath();g.ellipse(x,y,R,R*sq,0,0,TAU);g.stroke();g.lineWidth=3*f+1.4;g.strokeStyle=P.ring;g.stroke();
 g.lineWidth=1.2;g.strokeStyle='#ffffff';g.beginPath();g.ellipse(x,y-1,R*.97,R*.97*sq,0,Math.PI*1.05,Math.PI*1.95);g.stroke();
 const n=10;for(let i=0;i<n;i++){const a=i/n*TAU+k*.8,px=x+Math.cos(a)*R,py=y+Math.sin(a)*R*sq-6*Math.sin(Math.PI*k),s=(.65+.5*f)*(i%2?.75:1);g.globalAlpha=Math.min(1,f*1.8);
  g.save();g.translate(px,py);g.rotate(k*3+i);g.scale(s,s);rpPut(g,rpFlakeS(i%2&&P.cr[1]?P.cr[1].m:P.ring));g.restore()}
 g.restore()}
function rpZap(g,x1,y1,x2,y2,t,col,a){const sd=Math.floor(t*22),amp=Math.min(16,Math.hypot(x2-x1,y2-y1)*.14),op=g.globalCompositeOperation;rpZigPath(g,x1,y1,x2,y2,sd,amp);
 g.globalCompositeOperation='lighter';g.globalAlpha=.35*a*RPGA;g.lineWidth=10;g.strokeStyle=col;g.stroke();g.globalCompositeOperation='source-over';g.globalAlpha=.95*a*RPGA;g.lineWidth=3.4;g.stroke();g.lineWidth=1.4;g.strokeStyle='#ffffff';g.stroke();
 g.globalCompositeOperation=op;g.globalAlpha=RPGA}
function rpBolt2(g,x1,y1,x2,y2,t,skin){const col=RPLC[skin]||RPLC.base;g.save();g.lineJoin='round';g.lineCap='round';
 rpZap(g,x1,y1,x2,y2,t,col,1);const sd=Math.floor(t*22);if(rpR(sd)>.35){const f=.35+rpR(sd+1)*.3,mx=x1+(x2-x1)*f,my=y1+(y2-y1)*f,a=Math.atan2(y2-y1,x2-x1)+(rpR(sd+2)-.5)*1.8,l=Math.hypot(x2-x1,y2-y1)*.25;rpZap(g,mx,my,mx+Math.cos(a)*l,my+Math.sin(a)*l,t+.5,col,.6)}
 g.globalCompositeOperation='lighter';rpGlow(g,x1,y1,14,14,col,.8);rpGlow(g,x2,y2,24,24,col,1);rpGlow(g,x2,y2,9,9,'#ffffff',1);g.restore()}
function rpChill(g,x,y,t){g.save();g.globalCompositeOperation='lighter';rpGlow(g,x,y-2,24,16,'#62d4ff',.45);g.globalCompositeOperation='source-over';
 for(let i=0;i<3;i++){const a=t*1.6+i/3*TAU,px=x+Math.cos(a)*18,py=y+Math.sin(a)*8-6+Math.sin(t*3+i)*2,s=.62+.14*Math.sin(t*4+i);
  g.globalAlpha=Math.sin(a)<0?.7:1;g.save();g.translate(px,py);g.rotate(t+i);g.scale(s,s);rpPut(g,rpFlakeS('#c6f6ff'));g.restore()}
 g.globalAlpha=1;for(let i=0;i<3;i++){const tw=Math.sin(t*5+i*2.3);if(tw<0)continue;const px=x+(i-1)*11,py=y-16+((i*7)%5),r=2+tw*3.4;g.fillStyle='#ffffff';g.fillRect(px-r,py-.7,r*2,1.4);g.fillRect(px-.7,py-r,1.4,r*2)}
 g.restore()}
function rpSlowArt(g){const C='#a6ecff';g.lineCap='round';for(const [r,lw] of [[96,3.6],[82,2.2],[56,1.8]]){g.beginPath();g.arc(0,0,r,0,TAU);g.lineWidth=lw+3.4;g.strokeStyle='rgba(20,60,140,.55)';g.stroke();g.lineWidth=lw;g.strokeStyle=C;g.stroke()}
 g.strokeStyle='#effcff';g.lineWidth=2.4;for(let i=0;i<12;i++){const a=i/12*TAU,cx=Math.cos(a)*89,cy=Math.sin(a)*89;g.save();g.translate(cx,cy);g.rotate(a+Math.PI/2);g.beginPath();
  const v=i%4;if(v===0){g.moveTo(0,-4.5);g.lineTo(0,4.5);g.moveTo(-3,-1.5);g.lineTo(3,1.5)}else if(v===1){g.moveTo(-3,-4);g.lineTo(0,4);g.lineTo(3,-4)}else if(v===2){g.moveTo(-3,4);g.lineTo(-3,-4);g.lineTo(3,0);g.lineTo(-3,4)}else{g.moveTo(0,-4.5);g.lineTo(0,4.5);g.moveTo(0,-1);g.lineTo(3,-4);g.moveTo(0,1);g.lineTo(-3,4)}g.stroke();g.restore()}
 g.strokeStyle=C;g.lineWidth=2;g.beginPath();for(let i=0;i<6;i++){const a=i/6*TAU-Math.PI/2,b=a+2*TAU/6;g.moveTo(Math.cos(a)*56,Math.sin(a)*56);g.lineTo(Math.cos(b)*56,Math.sin(b)*56)}g.stroke();
 for(let i=0;i<6;i++){const a=i/6*TAU;g.beginPath();g.arc(Math.cos(a)*69,Math.sin(a)*69,3.4,0,TAU);g.fillStyle='#effcff';g.fill();g.lineWidth=1.2;g.strokeStyle='rgba(20,60,140,.6)';g.stroke()}}
function rpSlowField(g,x,y,r,t,k){k=k==null?1:Math.max(0,Math.min(1,k));if(k<=0)return;const s=r/100,sq=RPFX.sq,sp=rpSpr('slowf',-102,-102,204,204,rpSlowArt);g.save();
 g.globalAlpha=.28*k;g.fillStyle='#2a6ad8';g.beginPath();g.ellipse(x,y,r*.98,r*.98*sq,0,0,TAU);g.fill();
 g.globalCompositeOperation='lighter';rpGlow(g,x,y,r*1.1,r*1.1*sq,'#3aa8ff',.5*k);g.globalCompositeOperation='source-over';
 g.translate(x,y);g.scale(s,s*sq);g.save();g.rotate(t*.35);g.globalAlpha=k*(.8+.15*Math.sin(t*3));rpPut(g,sp);g.restore();
 g.rotate(-t*.5);g.scale(.55,.55);g.globalAlpha=k*.6;rpPut(g,sp);g.restore();
 g.save();g.globalCompositeOperation='lighter';for(let i=0;i<6;i++){const p=(t*.5+i/6)%1,a=i*2.4+1.3,d=r*(.2+.6*rpR(i));rpGlow(g,x+Math.cos(a)*d,y+Math.sin(a)*d*sq-p*34,4,4,'#c6f6ff',k*(1-p)*1.3)}g.restore()}
function rpOvercharge(g,x,y,t,a,h){a=a==null?1:a;h=h||100;if(a<=.01)return;g.save();g.lineJoin='round';g.lineCap='round';const p=.5+.5*Math.sin(t*6);g.globalCompositeOperation='lighter';
 rpGlow(g,x,y-h*.48,70+8*p,h*.78+8*p,'#ff9a1e',(.6+.2*p)*a);rpGlow(g,x,y-h*.45,34,h*.55,'#ffe08a',(.35+.15*p)*a);rpGlow(g,x,y+6,86,36,'#ffb52e',.55*a);
 for(let i=0;i<4;i++){const k=(t*.55+i/4)%1,xx=x+(i-1.5)*22;g.globalAlpha=a*Math.sin(Math.PI*k)*.6;g.drawImage(rpGlowC('#ffc94a'),xx-5,y-h*(.15+k*.9)-26,10,52)}
 g.globalCompositeOperation='source-over';g.globalAlpha=a*(.7+.3*p);g.lineWidth=5;g.strokeStyle='rgba(18,8,31,.6)';g.beginPath();g.ellipse(x,y+8,60+p*4,(60+p*4)*RPSQ,0,0,TAU);g.stroke();g.lineWidth=2.6;g.strokeStyle='#ffd45a';g.stroke();
 for(let i=0;i<3;i++){const sd=Math.floor(t*14)+i*7,a0=rpR(sd)*TAU,a1=a0+.6+rpR(sd+1)*.8,yy=y-h*(.2+.6*rpR(sd+2)),rx=40+rpR(sd+3)*10;
  rpZap(g,x+Math.cos(a0)*rx,yy+Math.sin(a0)*rx*.5,x+Math.cos(a1)*rx,yy+Math.sin(a1)*rx*.5-10,t+i,'#ffc94a',a)}
 g.globalCompositeOperation='lighter';for(let i=0;i<7;i++){const k=(t*.7+i/7)%1,ang=i*2.2;rpGlow(g,x+Math.cos(ang)*(34+8*Math.sin(i))*(1-k*.3),y-k*h*1.05+Math.sin(ang)*10,4,4,'#fff0a8',a*(1-k)*1.3)}
 g.restore()}
