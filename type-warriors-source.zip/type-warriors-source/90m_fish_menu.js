/* ===== MOONLIT FISHING: the main menu (update 3, styled after the owner's concept) =====
   Left: the spot name (opens the map), the ornate "Moonlit Fishing" title with a shine sweep, the tagline, the Tonight
   card (featured fish in a frame, 2x bite / +50% gold chips, the moon's line) with the Go Fishing button inside it.
   Right: the current spot painted mirrored so its dock and building sit on the right, the hero sitting on the dock
   with the rod, the pet beside him, a bobber bobbing and now and then a fish jumping nearby.
   Top right: gold, Back and a Fishing Spots signpost. Bottom: four tiles with detailed animated icons
   (Angler's Journal, Rod Workshop, Fish Basket, Stats). Space = Go Fishing, M = map, J = journal, W = workshop. */
function fsHub(){S.mode='fish';S.view='fishhub';FS.on=false;fsP();const F=fsP(),M=fsMoon(),n=fsFound(),lv=fsLv(),tier=fsTier(),k=fsLoc(),L=FSLOCS[k],s=F.s;
 const cr=F.cr.length,crv=F.cr.reduce((a,c)=>a+fsValue(c),0),open=FSLOCK.filter(x=>fsLocOpen(x)).length,spots=FSLOCK.filter(x=>!FSLOCS[x].soon).length;
 const upCan=FSUPK.some(x=>{const c=fsUpCost(x);return c!=null&&P.gold>=c}),skCan=FSKINK.some(x=>fsCanSkin(x)),next=[3,6,10,15].find(x=>x>lv);
 show(`<div class="fsx fshub2" id="fsx"><canvas id="fshb" width="1600" height="900" aria-hidden="true"></canvas><i class="fshvig2"></i>
 <div class="fstr"><span class="fsgold fsg">${fsCoin}<b id="fsgold">${P.gold.toLocaleString()}</b></span><button class="fsback fsg" id="fsback"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 5l-7 7 7 7" stroke="currentColor" stroke-width="2.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>Back <kbd>Esc</kbd></button></div>
 <button class="fssign" id="fssign" title="See all fishing spots (M)"><canvas id="fssgc" width="64" height="64"></canvas><span><b>Fishing Spots</b><small>${open} of ${spots} open${FSLOCK.some(x=>!fsLocOpen(x)&&!FSLOCS[x].soon)?` · next at ${FSLOCS[FSLOCK.find(x=>!fsLocOpen(x)&&!FSLOCS[x].soon)].need} species`:''}</small></span><i>›</i></button>
 <section class="fsh2l">
  <button class="fsh2k" id="fsh2k" title="Change fishing spot"><canvas id="fshmn" width="40" height="40"></canvas>${fsEsc(L.n.toUpperCase())}<i>▾</i></button>
  <h1 class="fsh2t"><span>Moonlit Fishing</span></h1><div class="fsh2orn" aria-hidden="true"><i></i><b></b><i></i></div>
  <p class="fsh2s">Cast. Wait for a bite. Type to reel it in.</p>
  <div class="fsh2card fsg"><div class="fsh2top"><div class="fsh2frame"><canvas id="fshfeat" width="230" height="180"></canvas><canvas class="fsh2moon" id="fshmoon2" width="54" height="54"></canvas></div>
   <div class="fsh2tx"><small>TONIGHT · ${fsEsc(M.n.toUpperCase())}</small><b>${FISH[M.feat].n}</b><span>Bites twice as often and sells for +50% tonight.</span>
    <div class="fsh2chips"><em class="c1">${fsFishIc()}2× bite rate</em><em class="c2">${fsCoin}+50% sell value</em></div><i>${fsEsc(M.d)}</i></div></div>
   <button class="fshgo fsh2go" id="fshgo"><span class="fshgoi" aria-hidden="true">${fsFishIc()}</span>Go Fishing<i>›</i><kbd>Space</kbd></button></div>
 </section>
 <nav class="fsh2tiles">
  <button class="fsh2t2" id="fshj" style="--c:#ffd45a"><canvas width="104" height="88" data-ic="journal"></canvas><span><b>Angler's Journal</b><small>${n} / ${FIDS.length} fish discovered</small><span class="fshpr"><i style="width:${n/FIDS.length*100}%"></i></span></span><i class="fsch">›</i></button>
  <button class="fsh2t2" id="fshw" style="--c:#a898ff"><canvas width="104" height="88" data-ic="rod"></canvas><span><b>Rod Workshop</b><small>${FSTIERN[tier]} · Lv ${lv}/15</small>${lv>=15?'<em class="fsmaxb">MAX</em>':`<small class="fsnx">${next?`next rod at Lv ${next}`:''}</small>`}</span><i class="fsch">›</i>${upCan||skCan?'<i class="fshdot">!</i>':''}</button>
  <button class="fsh2t2" id="fshc" style="--c:#7ad8ff"><canvas width="104" height="88" data-ic="basket"></canvas><span><b>Fish Basket</b><small>Creel · ${cr} / ${FSCREEL}${cr?` · ${crv.toLocaleString()} gold`:''}</small></span><i class="fsch">›</i></button>
  <button class="fsh2t2" id="fshs" style="--c:#7affb4"><canvas width="104" height="88" data-ic="stats"></canvas><span><b>Stats</b><small>${(s.caught||0).toLocaleString()} caught · best streak ${s.best||0}</small></span><i class="fsch">›</i></button>
 </nav><div class="fsmod" id="fsmod" hidden></div></div>`,'fshx');
 S.back=()=>{fsModal(null);title()};{const cn=$('cn');if(cn)cn.classList.add('dkhid')}
 const bd=$('fshb');LIVE.push({cv:bd,fn:fsHubScene(bd,k)});
 live('fshmn',c=>{const x=c.getContext('2d');return t0=>{const t=fsRM()?0:t0;x.setTransform(1,0,0,1,0,0);x.clearRect(0,0,40,40);fsMoonIcon(x,20,20,14,M.ph,t)}});
 live('fshmoon2',c=>{const x=c.getContext('2d');return t0=>{const t=fsRM()?0:t0;x.setTransform(1,0,0,1,0,0);x.clearRect(0,0,54,54);fsMoonIcon(x,27,27,18,M.ph,t)}});
 live('fshfeat',c=>{const x=c.getContext('2d');return t0=>{const t=fsRM()?0:t0;x.setTransform(1,0,0,1,0,0);x.clearRect(0,0,230,180);const sw=Math.sin(t*1.3)*6;fkGlow(x,115,95,100,FSR[FISH[M.feat].r].c,.22);fishFit(x,M.feat,115+sw,96+Math.sin(t*2)*3,206,140,{t});for(let i=0;i<5;i++){const a=t*.8+i*1.3;fkSpark(x,115+Math.cos(a)*92,92+Math.sin(a*1.3)*58,2+2*Math.abs(Math.sin(t*2+i)),'#e8f6ff',.8)}}});
 live('fssgc',c=>{const x=c.getContext('2d');return t0=>{const t=fsRM()?0:t0;x.setTransform(1,0,0,1,0,0);x.clearRect(0,0,64,64);fsIcon(x,'map',32,32,.62,t)}});
 ov.querySelectorAll('canvas[data-ic]').forEach(c=>{const kind=c.dataset.ic,x=c.getContext('2d');LIVE.push({cv:c,fn:t0=>{const t=fsRM()?0:t0;x.setTransform(1,0,0,1,0,0);x.clearRect(0,0,104,88);fsIcon(x,kind,52,46,1,t)},slow:2})});
 $('fsback').onclick=()=>title();$('fshgo').onclick=fsPond;$('fshj').onclick=()=>fsJournal();$('fshw').onclick=fsWorkshop;$('fssign').onclick=()=>fsMap(fsHub);$('fsh2k').onclick=()=>fsMap(fsHub);
 const pm=t=>{fsPanelModal(t);const m=$('fsmod');if(m)m.onclick=e=>{if(e.target===m){fsModal(null);fsHub()}}};$('fshc').onclick=()=>pm('c');$('fshs').onclick=()=>pm('s');if(FS.unlockNote)setTimeout(fsUnlockShow,700);
 setTimeout(()=>{const b=$('fshgo');try{b&&b.focus({preventScroll:true})}catch(e){}},60)}
/* hotkeys on the menu */
document.addEventListener('keydown',e=>{if(S.mode!=='fish'||S.view!=='fishhub'||e.ctrlKey||e.metaKey||e.altKey)return;const m=$('fsmod');if(m&&!m.hidden)return;const k=e.key.toLowerCase();
 if(k==='m'){e.preventDefault();e.stopImmediatePropagation();fsMap(fsHub)}else if(k==='j'){e.preventDefault();e.stopImmediatePropagation();fsJournal()}else if(k==='w'){e.preventDefault();e.stopImmediatePropagation();fsWorkshop()}},true);
/* ---------- the menu scene: the spot mirrored, the hero sitting on the dock ---------- */
function fsHubScene(cv,k){const g=cv.getContext('2d'),V={noHero:1,shadows:[],rm:fsRM(),loc:k};let mir=null,jump={t:-9},sh=[{x:860,y:690,r:24,dir:1,a:.16,ph:1},{x:1000,y:760,r:30,dir:-1,a:.13,ph:3}];
 return ()=>{const t=performance.now()/1000,rm=V.rm,ta=rm?0:t;
  if(!mir){mir=document.createElement('canvas');mir.width=1600;mir.height=900;}
  if(!rm)sh.forEach(s=>{s.x+=s.dir*.3;if(s.x>1080)s.dir=-1;if(s.x<720)s.dir=1});V.shadows=sh;
  const m=mir.getContext('2d');fsScene(m,rm?0:t,V);
  g.setTransform(1,0,0,1,0,0);g.save();g.translate(1600,0);g.scale(-1,1);g.drawImage(mir,0,0);g.restore();
  /* hide the pond's own moon (mirrored behind the title) */
  if(!k||k==='pond'){if(!V.mg){V.mg=g.createRadialGradient(670,160,0,670,160,250);V.mg.addColorStop(0,'rgba(7,4,26,.95)');V.mg.addColorStop(.4,'rgba(7,4,26,.85)');V.mg.addColorStop(.75,'rgba(7,4,26,.35)');V.mg.addColorStop(1,'rgba(7,4,26,0)')}g.fillStyle=V.mg;g.fillRect(420,0,500,410)}
  /* the hero on the dock (mirrored dock sits at x 1000..1450) */
  /* a crescent moon high on the right, like the concept */
  {const mx=1070,my=118;fkGlow(g,mx,my,120,'#fff2c8',.22+.04*Math.sin(ta*.8));g.save();g.beginPath();g.arc(mx,my,44,0,TAU);g.arc(mx+20,my-10,40,0,TAU,true);g.fillStyle=fkRad(g,mx,my,44,['#fffdf0','#f6eccc','#d8ccaa']);g.fill('evenodd');g.restore()}
  const dx=1050,dy=FSDOCK.y+4;fsHeroSit(g,dx,dy,1.35,ta);
  /* fish jumping now and then near the bobber */
  if(!rm&&t-jump.t>5.5){jump={t,x:820+Math.random()*120,id:(FSPOOL[k]||FSPOOL.pond)[Math.random()*(FSPOOL[k]||FSPOOL.pond).length|0]}}
  const u=(t-jump.t)/1.1;if(u>=0&&u<1&&FISHART[jump.id]){const x=jump.x+u*90,y=640-Math.sin(u*Math.PI)*120;g.save();g.translate(x,y);g.rotate(-.6+u*1.2);g.scale(.32,.32);fishDraw(g,jump.id,{t,flex:.8});g.restore();if(u<.06||u>.94){fkGlow(g,u<.5?jump.x:jump.x+90,646,30,'#ffffff',.35)}}}}
/* the hero sitting on the dock edge facing left, legs over the water, rod out over the pond */
function fsHeroSit(g,x,y,s,t){const A=AR[P.armor]||AR.rags,leg=A.dk||'#5e5236',lg2=A.m||'#8a7a5a';
 /* pet sitting beside him */
 try{const id=P.pet;if(id&&PDEF[id]&&petOwned(id)){const hv=PDEF[id].hover;g.save();g.translate(x+110,y+20-(hv?26:0));g.scale(-.95,.95);petDraw(g,id,Object.assign({t,pose:'idle',u:0,noSh:1},petLook(id)));g.restore()}}catch(e){}
 g.save();g.translate(x,y);g.scale(-s,s);
 /* legs hanging over the edge (drawn first, behind the body) */
 const br=Math.sin(t*1.6)*2;
 try{arSeg(g,4,-4,30,-2,13,leg);arSeg(g,30,-2,34+br*.3,32,11,leg);arSeg(g,-6,-4,22,0,13,lg2);arSeg(g,22,0,24-br*.3,34,11,lg2)}catch(e){}
 const boot=(bx,by)=>{g.fillStyle='#3a2a24';g.beginPath();g.ellipse(bx+5,by,11,7,0,0,TAU);g.fill();g.lineWidth=2;g.strokeStyle='#1b1024';g.stroke()};boot(34+br*.3,34);boot(24-br*.3,36);
 /* the body from the hips up: drawHero clipped above the waist, lowered onto the dock */
 g.save();g.translate(0,44);g.beginPath();g.rect(-90,-230,190,184);g.clip();try{drawHero(g,{arm:P.armor,wp:null,col:P.col,t,lg:.15})}catch(e){}g.restore();
 /* the rod from his hand out over the water */
 const hx=30+3,hy=-66+44+Math.sin(t*2.4)*.4,tip=fsRod(g,hx,hy,-.42+Math.sin(t*1.1)*.02,0,200/s*1.1,t,fsSkin(),fsTier());g.restore();
 /* line and bobber in world space (mirror the tip back) */
 const wx=x-tip.x*s,wy=y+tip.y*s,bx=wx-210,byy=y+60+Math.sin(t*2.2)*2;fsLine(g,{x:wx,y:wy},{x:bx,y:byy-8},.5,fsSkin().ln);fsBobber(g,bx,byy,t,0);
 if(!fsRM()){const p=(t*.45)%1;g.strokeStyle=`rgba(220,230,255,${(1-p)*.35})`;g.lineWidth=1.4;g.beginPath();g.ellipse(bx,byy+2,8+p*34,(8+p*34)*.28,0,0,TAU);g.stroke()}}
/* ---------- detailed icons (canvas) ---------- */
function fsIcon(g,kind,x,y,s,t){g.save();g.translate(x,y);g.scale(s,s);g.lineJoin='round';g.lineCap='round';
 if(kind==='journal'){g.rotate(-.06+Math.sin(t*1.2)*.02);fkGlow(g,0,0,48,'#ffd45a',.18);
  g.fillStyle=fkLin(g,0,-30,0,30,['#7a3a22','#4a2010']);g.beginPath();g.roundRect(-40,-28,80,58,7);g.fill();g.lineWidth=3;g.strokeStyle=FKO;g.stroke();
  g.fillStyle=fkLin(g,0,-26,0,26,['#fff6e0','#ead6a8']);g.beginPath();g.moveTo(-36,-24);g.quadraticCurveTo(-18,-28,-1,-22);g.lineTo(-1,26);g.quadraticCurveTo(-18,20,-36,24);g.closePath();g.fill();g.lineWidth=1.6;g.stroke();
  g.beginPath();g.moveTo(36,-24);g.quadraticCurveTo(18,-28,1,-22);g.lineTo(1,26);g.quadraticCurveTo(18,20,36,24);g.closePath();g.fill();g.stroke();
  g.strokeStyle='#b89a6a';g.lineWidth=1.2;for(let i=0;i<4;i++){g.beginPath();g.moveTo(7,-10+i*8);g.lineTo(30,-11+i*8);g.stroke()}
  g.save();g.translate(-18,0);g.scale(.12,.12);fishDraw(g,'moonfin',{t});g.restore();
  g.fillStyle='#e8364e';g.beginPath();g.moveTo(22,-30);g.lineTo(30,-30);g.lineTo(30,-6);g.lineTo(26,-10);g.lineTo(22,-6);g.closePath();g.fill();g.lineWidth=1.6;g.strokeStyle=FKO;g.stroke();
  g.fillStyle='#e6b93e';[[-40,-28],[40,-28],[-40,30],[40,30]].forEach(([a,b])=>{g.beginPath();g.arc(a,b,3.4,0,TAU);g.fill()});fkSpark(g,32,-34,4+2*Math.abs(Math.sin(t*3)),'#fff6c0',.9)}
 else if(kind==='rod'){fkGlow(g,24,-22,30,(fsSkin().gl||'#c8b8ff'),.3);g.save();g.translate(-34,30);fsRod(g,0,0,-.78,0,82,t,fsSkin(),fsTier());g.restore();
  const bx=26+Math.sin(t*2)*1.5,by=18+Math.sin(t*2.4)*2;g.strokeStyle='#f4ecd8';g.lineWidth=1.2;g.beginPath();g.moveTo(25,-30);g.quadraticCurveTo(32,-6,bx,by-8);g.stroke();fsBobber(g,bx,by,t,0);fkSpark(g,27,-34,3+2*Math.abs(Math.sin(t*3.4)),'#fff',.9)}
 else if(kind==='basket'){g.fillStyle=fkLin(g,0,-12,0,30,['#d8a868','#8a5a28']);g.beginPath();g.moveTo(-34,-10);g.lineTo(34,-10);g.lineTo(28,30);g.quadraticCurveTo(0,36,-28,30);g.closePath();g.fill();g.lineWidth=3;g.strokeStyle=FKO;g.stroke();
  g.save();g.beginPath();g.moveTo(-34,-10);g.lineTo(34,-10);g.lineTo(28,30);g.quadraticCurveTo(0,36,-28,30);g.closePath();g.clip();g.strokeStyle='#6a4218';g.lineWidth=1.6;for(let i=-4;i<=4;i++){g.beginPath();g.moveTo(i*9,-10);g.lineTo(i*8,34);g.stroke()}for(let j=0;j<4;j++){g.strokeStyle=j%2?'#f0c888':'#6a4218';g.beginPath();g.moveTo(-36,-2+j*9);g.quadraticCurveTo(0,2+j*9,36,-2+j*9);g.stroke()}g.restore();
  g.save();g.translate(-8,-18);g.rotate(-.5+Math.sin(t*3)*.08);g.scale(.17,.17);fishDraw(g,'ember',{t,flex:.4});g.restore();g.save();g.translate(14,-20);g.rotate(.5+Math.sin(t*3+1)*.08);g.scale(.15,.15);fishDraw(g,'copper',{t:t+1,flex:.4});g.restore();
  g.fillStyle='#8a5a28';g.beginPath();g.roundRect(-36,-14,72,8,4);g.fill();g.lineWidth=2.4;g.strokeStyle=FKO;g.stroke();g.strokeStyle='#4a2a10';g.lineWidth=4;g.beginPath();g.arc(0,-12,32,Math.PI*1.08,Math.PI*1.92);g.stroke();
  for(let i=0;i<3;i++){const u=((t*.8+i*.33)%1);g.fillStyle=`rgba(180,220,255,${1-u})`;g.beginPath();g.ellipse(-20+i*20,32+u*10,2,3,0,0,TAU);g.fill()}}
 else if(kind==='stats'){const H=[16,28,22,38],C=[['#7ab8ff','#3a6ad8'],['#7affb4','#2a9a5a'],['#ffd45a','#c88a1a'],['#ff9ad8','#c84a9a']];H.forEach((h,i)=>{const gr=Math.min(1,(t%6)/1.2+.4),hh=h*Math.min(1,gr+i*.1),bx=-32+i*17;g.fillStyle=fkLin(g,0,28-hh,0,28,C[i]);g.beginPath();g.roundRect(bx,28-hh,13,hh,3);g.fill();g.lineWidth=2.4;g.strokeStyle=FKO;g.stroke();g.fillStyle='#ffffff55';g.fillRect(bx+2,30-hh,3,hh-4)});
  g.strokeStyle=FKO;g.lineWidth=5;g.beginPath();g.moveTo(-30,10);g.lineTo(-14,-2);g.lineTo(2,4);g.lineTo(26,-22);g.stroke();g.strokeStyle='#fff8e8';g.lineWidth=2.6;g.stroke();g.fillStyle='#fff8e8';g.beginPath();g.moveTo(32,-28);g.lineTo(20,-24);g.lineTo(28,-16);g.closePath();g.fill();fkSpark(g,34,-32,5+2*Math.sin(t*3),'#fff6c0',1)}
 else if(kind==='map'){g.rotate(Math.sin(t*1.4)*.04);g.fillStyle=fkLin(g,0,-30,0,30,['#f4e2b8','#d8bc84']);g.beginPath();g.moveTo(-34,-24);g.lineTo(-12,-30);g.lineTo(12,-24);g.lineTo(34,-30);g.lineTo(34,26);g.lineTo(12,32);g.lineTo(-12,26);g.lineTo(-34,32);g.closePath();g.fill();g.lineWidth=3;g.strokeStyle=FKO;g.stroke();
  g.strokeStyle='#b8946044';g.lineWidth=1.4;g.beginPath();g.moveTo(-12,-30);g.lineTo(-12,26);g.moveTo(12,-24);g.lineTo(12,32);g.stroke();g.setLineDash([4,4]);g.strokeStyle='#c8282a';g.lineWidth=2.4;g.beginPath();g.moveTo(-26,18);g.quadraticCurveTo(-8,-4,4,6);g.quadraticCurveTo(16,14,24,-14);g.stroke();g.setLineDash([]);
  g.fillStyle='#4ab8ff';g.beginPath();g.ellipse(-4,-12,9,6,0,0,TAU);g.fill();g.fillStyle='#c8282a';g.font='900 16px sans-serif';g.textAlign='center';g.fillText('✕',24,-8);fkSpark(g,24,-22,4+2*Math.abs(Math.sin(t*3)),'#fff6c0',1)}
 g.restore()}
{const st=document.createElement('style');st.textContent=`
.fshub2>canvas#fshb{position:absolute;inset:0;width:1600px;height:900px}
.fshvig2{position:absolute;inset:0;pointer-events:none;background:linear-gradient(90deg,#07041af0 0%,#07041ad8 36%,#07041aa0 47%,#07041a30 58%,#07041a00 66%),linear-gradient(0deg,#07041ad0 0%,#07041a00 26%)}
.fsh2l{position:absolute;left:48px;top:40px;width:700px}
.fsh2k{display:flex;align-items:center;gap:10px;height:40px;padding:0 10px 0 0;border:none;background:none;color:#e8e0ff;font:800 14px var(--ui);letter-spacing:.3em;cursor:pointer;animation:fsIn .5s var(--sp) both}.fsh2k canvas{width:40px;height:40px}.fsh2k i{font-style:normal;letter-spacing:0;opacity:.7}.fsh2k:hover{color:#fff}
.fsh2t{position:relative;margin:2px 0 0;display:inline-block;overflow:visible;font:400 108px/1 'Pirata One',Georgia,serif;animation:fsIn .6s .05s var(--sp) both}
.fsh2t span{background:linear-gradient(180deg,#fff7c8 0%,#ffd45a 45%,#e8962a 80%,#c8701a 100%);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;filter:drop-shadow(0 5px 0 #3a1a04) drop-shadow(0 0 22px #ffb02a44)}
.fsh2sh{position:absolute;top:0;bottom:0;left:0;width:30%;background:linear-gradient(100deg,#fff0 0%,#fff8 50%,#fff0 100%);mix-blend-mode:normal;opacity:.55;transform:translateX(-120%) skewX(-18deg);animation:fsShine 6s 1.2s ease-in-out infinite;pointer-events:none;-webkit-mask:linear-gradient(#000,#000)}
@keyframes fsShine{0%{transform:translateX(-140%) skewX(-18deg)}22%,100%{transform:translateX(420%) skewX(-18deg)}}
.fsh2orn{display:flex;align-items:center;gap:10px;width:560px;margin:-6px 0 0 30px;animation:fsIn .6s .1s var(--sp) both}.fsh2orn i{flex:1;height:3px;border-radius:2px;background:linear-gradient(90deg,#ffd45a00,#ffd45a,#ffd45a00)}.fsh2orn b{width:14px;height:14px;transform:rotate(45deg);background:#ffd45a;box-shadow:0 0 0 3px #3a1a04}
.fsh2s{margin:12px 0 18px 4px!important;font:600 22px var(--ui);color:#e8e0ff;animation:fsIn .6s .14s var(--sp) both}
.fsh2card{width:690px;padding:18px 20px 20px;animation:fsIn .6s .18s var(--sp) both}.fsh2top{display:flex;gap:18px;align-items:center}
.fsh2frame{position:relative;flex:none;width:230px;height:180px;border-radius:18px;background:radial-gradient(circle at 50% 55%,#2a3a8a,#100a30 75%);border:2px solid #3a3070;overflow:hidden}.fsh2frame canvas#fshfeat{width:230px;height:180px}.fsh2moon{position:absolute;right:6px;top:6px;width:54px;height:54px}
.fsh2tx{display:flex;flex-direction:column;gap:4px}.fsh2tx small{font:800 12.5px var(--ui);letter-spacing:.18em;color:#9ff0ff}.fsh2tx b{font:400 38px/1 'Pirata One',Georgia,serif;color:var(--gold)}.fsh2tx span{font:600 16px var(--ui);color:#fff8e8}.fsh2tx>i{font:500 14px var(--ui);font-style:italic;color:#c4badf}
.fsh2chips{display:flex;gap:8px;margin:4px 0}.fsh2chips em{display:flex;align-items:center;gap:6px;height:34px;padding:0 14px;border-radius:12px;font:800 15px var(--ui);font-style:normal;animation:fsTag .5s .5s var(--sp) both}
.fsh2chips .c1{border:2px solid #5ad8ff;color:#bff0ff;background:#5ad8ff1c}.fsh2chips .c1 svg{width:28px;height:17px}.fsh2chips .c1 svg path{fill:#5ad8ff}.fsh2chips .c2{border:2px solid #ffd45a;color:#ffe9a0;background:#ffd45a1c;animation-delay:.6s}.fsh2chips .fscoin{width:18px;height:18px;margin:0}
.fsh2go{position:relative;width:100%!important;margin-top:16px!important;animation:fsIn .6s .24s var(--sp) both}.fsh2go::after{content:'';position:absolute;inset:-6px;border-radius:30px;border:3px solid #ffe27a;opacity:0;animation:fsGoP 2.4s 1.4s ease-in-out infinite;pointer-events:none}@keyframes fsGoP{0%{opacity:.7;transform:scale(1)}70%,100%{opacity:0;transform:scale(1.05)}}
.fsh2tiles{position:absolute;left:48px;right:48px;bottom:40px;display:grid;grid-template-columns:repeat(4,1fr);gap:16px}
.fsh2t2{position:relative;display:flex;align-items:center;gap:12px;height:132px;padding:0 16px 0 10px;border-radius:20px;border:2px solid color-mix(in srgb,var(--c) 40%,#3a3070);background:linear-gradient(180deg,#221a5aee,#100a30f4);box-shadow:inset 0 1px 0 #ffffff1f,0 12px 30px #000a;color:#fff8e8;text-align:left;cursor:pointer;animation:fsIn .6s calc(.3s + var(--i,0)*.06s) var(--sp) both;transition:transform .18s var(--sp),border-color .18s}
.fsh2t2:nth-child(2){--i:1}.fsh2t2:nth-child(3){--i:2}.fsh2t2:nth-child(4){--i:3}.fsh2t2:hover{transform:translateY(-5px);border-color:var(--c)}.fsh2t2:active{transform:scale(.97)}.fsh2t2:focus-visible{outline:3px solid #fff;outline-offset:3px}
.fsh2t2 canvas{flex:none;width:104px;height:88px}.fsh2t2>span{flex:1;display:flex;flex-direction:column;gap:4px;min-width:0}.fsh2t2 b{font:800 20px var(--ui)}.fsh2t2 small{font:500 14px var(--ui);color:#c4badf}.fsh2t2 .fshpr{width:90%}
.fsch{font:800 30px var(--ui);font-style:normal;color:#c8beff}.fsmaxb{align-self:flex-start;padding:2px 12px;border-radius:9px;background:linear-gradient(180deg,#ffe27a,#f2b631);color:#3a2006;font:900 13px var(--ui);font-style:normal;letter-spacing:.08em}.fsnx{font-size:12.5px!important;opacity:.8}
.fssign{position:absolute;right:22px;top:92px;display:flex;align-items:center;gap:8px;height:64px;padding:0 16px 0 6px;border-radius:14px;border:3px solid #1b1024;background:repeating-linear-gradient(180deg,#00000000 0 20px,#00000030 20px 22px),linear-gradient(180deg,#8a5a32,#5a3418);color:#fff2d0;cursor:pointer;box-shadow:0 8px 20px #000a;transform-origin:top center;animation:fsSign .8s .4s var(--sp) both;transition:transform .2s var(--sp)}
.fssign:hover{transform:rotate(-2deg) translateY(-2px)}.fssign canvas{width:64px;height:64px}.fssign span{display:flex;flex-direction:column;text-align:left}.fssign b{font:400 24px/1 'Pirata One',Georgia,serif;color:#ffe9a0}.fssign small{font:600 12px var(--ui)}.fssign>i{font:800 24px var(--ui);font-style:normal}
@keyframes fsSign{0%{opacity:0;transform:rotate(-12deg) translateY(-20px)}60%{transform:rotate(4deg)}100%{opacity:1;transform:none}}
@media (prefers-reduced-motion:reduce){.fsh2sh,.fsh2go::after{display:none}}`;document.head.appendChild(st)}
