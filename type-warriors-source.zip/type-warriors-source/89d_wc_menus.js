/* ===== WILDCARD: menus — mode select, results podium, statistics, rules, card backs and the room lobby ===== */
const wcDay=()=>{const d=new Date();return d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate()};
function wcSt(){let W=P.wc;if(!W||typeof W!=='object'||Array.isArray(W))W=P.wc={};
 const d={g:0,w:0,cur:0,best:0,net:0,pot:0,fast:0,cards:0,d4:0,ones:0,catches:0,caught:0,drawn:0,day:'',dayN:0,fw:'',back:'classic',backs:{classic:1},hist:[],tbl:'m',fr:0};
 for(const k in d)if(W[k]==null||typeof W[k]!==typeof d[k]||(Array.isArray(d[k])&&!Array.isArray(W[k])))W[k]=JSON.parse(JSON.stringify(d[k]));
 if(!W.byd||typeof W.byd!=='object')W.byd={};for(const k of['e','m','h','pp','net'])if(!W.byd[k]||typeof W.byd[k]!=='object')W.byd[k]={g:0,w:0};
 if(W.day!==wcDay()){W.day=wcDay();W.dayN=0}return W}
const wcLeftToday=()=>Math.max(0,WCE.DAILY-wcSt().dayN);
const WCI={/* small ui icons */
 book:'<svg viewBox="0 0 24 24"><path d="M3 5c3-1 6-1 9 1v14c-3-2-6-2-9-1zM21 5c-3-1-6-1-9 1v14c3-2 6-2 9-1z" fill="currentColor"/></svg>',
 chart:'<svg viewBox="0 0 24 24"><path d="M5 20V11M12 20V5M19 20v-7" stroke="currentColor" stroke-width="3.2" stroke-linecap="round"/></svg>',
 back:'<svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" stroke="currentColor" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>',
 users:'<svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.6" fill="currentColor"/><path d="M2 20c0-4 3.2-6.4 7-6.4s7 2.4 7 6.4z" fill="currentColor"/><circle cx="17" cy="9" r="2.8" fill="currentColor" opacity=".7"/><path d="M15.5 13.6c3.6.2 6.5 2.3 6.5 6.4h-4.4" fill="currentColor" opacity=".7"/></svg>',
 wifi:'<svg viewBox="0 0 24 24"><path d="M2 9a15 15 0 0 1 20 0M5.5 12.5a10 10 0 0 1 13 0M9 16a5 5 0 0 1 6 0" stroke="currentColor" stroke-width="2.4" fill="none" stroke-linecap="round"/><circle cx="12" cy="19.5" r="1.8" fill="currentColor"/></svg>',
 phone:'<svg viewBox="0 0 24 24"><rect x="6" y="2" width="12" height="20" rx="3" fill="none" stroke="currentColor" stroke-width="2.2"/><circle cx="12" cy="18" r="1.3" fill="currentColor"/></svg>',
 crown:'<svg viewBox="0 0 24 24"><path d="M3 8l4.5 3.6L12 4.5l4.5 7.1L21 8l-1.8 10.5H4.8z" fill="currentColor"/></svg>',
 bot:'<svg viewBox="0 0 24 24"><rect x="4" y="7" width="16" height="12" rx="3" fill="currentColor"/><circle cx="9" cy="13" r="1.8" fill="#1a1440"/><circle cx="15" cy="13" r="1.8" fill="#1a1440"/><path d="M12 7V3.5" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="3" r="1.6" fill="currentColor"/></svg>',
 copy:'<svg viewBox="0 0 24 24"><rect x="8" y="8" width="12" height="13" rx="2" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M5 16V5a2 2 0 0 1 2-2h9" stroke="currentColor" stroke-width="2.2" fill="none"/></svg>',
 x:'<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2.8" stroke-linecap="round"/></svg>'};
const WCHERO=[{s:'e',v:'7',id:901},{s:'t',v:'d2',id:902},{s:'s',v:'turn',id:903},{s:'w',v:'wild',id:904}];
function wcHome(){WX.tok++;wcClear();CAS.on=true;CAS.key=null;const W=wcSt(),t=WX.tbl=W.tbl||'m',left=wcLeftToday();
 const tier=k=>{const T=WCT[k];return `<button class="wcdf${k===t?' on':''}" data-tbl="${k}" aria-pressed="${k===t}"><span class="wcdfa"><canvas width="132" height="132" data-av="${T.bots[0][0]}"></canvas></span><b>${T.n}</b><small class="d-${k}">${T.lab}</small></button>`};
 show(`<div class="wch" id="wch"><div class="wcbg"></div><div class="wchfelt"></div>
 <div class="wchtag"><span>8.2 NEW</span>WILDCARD · CHOOSE HOW TO PLAY</div>
 <div class="wchtr"><button class="wcpb" id="wchow">${WCI.book}How to play</button><button class="wcpb" id="wcstats">${WCI.chart}Stats</button><span class="wcpb gold"><span class="coin"></span><b>${cmn(P.gold)}</b></span><button class="wcpb back" id="wcbk">${WCI.back}Casino</button></div>
 <h1 class="wclogo"><span>WILDCARD</span></h1><p class="wcsub">The tavern card game. Match the element or the number, and be first to empty your hand.</p>
 <div class="wcfan" id="wcfan">${WCHERO.map((c,i)=>wcCardEl(c,'',`style="--i:${i}"`)).join('')}</div>
 <div class="wcpanels">
  <section class="wcpn solo" style="--d:0"><h2>Solo</h2><p>Play against tavern regulars.</p><div class="wcdfs">${['e','m','h'].map(tier).join('')}</div>
   <div class="wcsi" id="wcsi"></div><label class="wcfr"><input type="checkbox" id="wcfrc" ${W.fr?'checked':''}><i></i><span>Friendly game (no gold)</span></label>
   <button class="wcbtn gold big" id="wcsolo">Play solo <i>›</i></button></section>
  <section class="wcpn host" style="--d:1"><span class="wctg gold">FRIENDS</span><h2>Host a room</h2><p>Play with friends on this device or the same Wi-Fi.</p>
   <div class="wcmodes"><div>${WCI.users}<b>Pass &amp; play</b><small>Share one screen. Hands stay hidden between turns.</small></div><div>${WCI.wifi}<b>Same Wi-Fi</b><small>Phones and computers on your network join with an invite.</small></div></div>
   <p class="wcfoot">2–4 players · bots fill empty seats · house rules</p><button class="wcbtn gold big" id="wchost">Create room <i>›</i></button></section>
  <section class="wcpn join" style="--d:2"><span class="wctg blue">WI-FI</span><h2>Join a room</h2><p>Paste the invite code your friend sent you.</p>
   <textarea id="wcjin" class="wcjin" rows="3" spellcheck="false" placeholder="Paste invite code here"></textarea><p class="wcfoot">Works on phone, tablet or computer on the same Wi-Fi</p>
   <button class="wcbtn purple big" id="wcjoin">Join <i>›</i></button></section></div>
 <div class="wcmod" id="wcmod" hidden></div></div>`,'casbg wcx');
 S.back=()=>{const m=$('wcmod');if(m&&!m.hidden){m.hidden=true;m.innerHTML='';return}wcLeaveHome()};$('wcbk').onclick=wcLeaveHome;
 ov.querySelectorAll('canvas[data-av]').forEach(c=>wcPortrait(c,{t:'mon',id:c.dataset.av}));
 const info=()=>{const T=WCT[WX.tbl],fr=$('wcfrc').checked,left=wcLeftToday();$('wcsi').innerHTML=fr||!left?`<b>Friendly game</b> · no buy-in, no payout${!left&&!fr?' · today\'s 15 staked games are used up':''}`:`Buy-in <b class="g">${cmn(T.stake)}</b> · winner takes <b class="g">${cmn(wcPayout(T.stake,4,0,T.fee))}</b> · 2nd gets <b>${cmn(wcPayout(T.stake,4,1,T.fee))}</b> back<small>Staked games left today: ${left} / ${WCE.DAILY}${wcSt().fw!==wcDay()?' · first win today +'+WCE.FIRSTWIN:''}</small>`};
 ov.querySelectorAll('[data-tbl]').forEach(b=>b.onclick=()=>{WX.tbl=b.dataset.tbl;wcSt().tbl=WX.tbl;save();ov.querySelectorAll('[data-tbl]').forEach(x=>{x.classList.toggle('on',x===b);x.setAttribute('aria-pressed',x===b)});wcSnd(600,.04,'triangle',.25);info()});
 $('wcfrc').onchange=()=>{wcSt().fr=$('wcfrc').checked?1:0;save();info()};info();
 $('wcsolo').onclick=()=>wcStartSolo(WX.tbl,$('wcfrc').checked);$('wchost').onclick=()=>wcLobby();$('wcjoin').onclick=()=>{const v=$('wcjin').value.trim();if(!v){$('wcjin').focus();$('wcjin').classList.add('nope');setTimeout(()=>$('wcjin')&&$('wcjin').classList.remove('nope'),500);return}wcJoin(v)};
 $('wchow').onclick=wcHowTo;$('wcstats').onclick=wcStats;
 const f=$('wcfan');if(f)f.querySelectorAll('.wcc').forEach(c=>c.onmouseenter=()=>wcSnd(700+(+c.style.getPropertyValue('--i'))*80,.03,'triangle',.12))}
function wcLeaveHome(){WX.tok++;wcClear();try{wcNetClose()}catch(e){}try{lobby()}catch(e){title()}}
function wcModal(html,cls){const m=$('wcmod');if(!m)return null;m.hidden=false;m.className='wcmod '+(cls||'');m.innerHTML=`<div class="wcmb">${html}<button class="wcmx" aria-label="Close">${WCI.x}</button></div>`;
 const close=()=>{m.hidden=true;m.innerHTML=''};m.querySelector('.wcmx').onclick=close;m.onclick=e=>{if(e.target===m)close()};setTimeout(()=>{const b=m.querySelector('.wcmx');if(b)b.focus()},40);return m}
function wcHowTo(){const c=(s,v)=>wcCardEl({s,v,id:950+WCS.indexOf(s)+v.length},'mini');
 wcModal(`<h3>How to play Wildcard</h3><div class="wchw">
 <div class="wchr"><div class="wchc2">${c('e','7')}${c('e','3')}${c('t','7')}</div><p><b>Match the element or the face.</b> Play an Ember on an Ember, or any 7 on a 7. No match? Draw a card; if it fits you may play it at once.</p></div>
 <div class="wchr"><div class="wchc2">${c('g','stun')}${c('t','turn')}${c('s','d2')}</div><p><b>Action cards.</b> <i>Stun</i> skips the next player, <i>Turnabout</i> reverses the order, <i>+2 Curse</i> makes the next player draw two. Stack a +2 on a +2 to pass it on!</p></div>
 <div class="wchr"><div class="wchc2">${c('w','wild')}${c('w','d4')}</div><p><b>Wild Rune</b> lets you pick the next element. <b>+4 Hex</b> does too, and the next player draws four (or stacks another +4).</p></div>
 <div class="wchr"><div class="wchone">WILD!</div><p><b>Down to one card?</b> Press <b>WILD!</b> before you play your second-to-last card. Forget, and anyone who taps you first makes you draw two. Catch the bots when they forget!</p></div></div>
 <p class="wchk">Keys: <kbd>D</kbd> draw · <kbd>W</kbd> call WILD! · <kbd>H</kbd> hint · <kbd>K</kbd> keep a drawn card · <kbd>Esc</kbd> leave</p>`,'wide')}
/* ---------- statistics ---------- */
function wcStats(){const W=wcSt(),pc=(a,b)=>b?Math.round(a/b*100)+'%':'–';
 const tile=(l,v,s,c)=>`<div class="wcsx${c?' '+c:''}"><small>${l}</small><b>${v}</b>${s?`<em>${s}</em>`:''}</div>`;
 const row=(k,l)=>{const b=W.byd[k];return `<div class="wcsr"><span>${l}</span><div class="wcsb"><i style="--w:${b.g?Math.round(b.w/b.g*100):0}%"></i></div><b>${b.w} / ${b.g}</b><em>${pc(b.w,b.g)}</em></div>`};
 const hist=W.hist.slice(-12).map(h=>`<i class="h${h.p===0?'w':h.p===1?'2':'l'}" title="${h.p===0?'Won':h.p===1?'2nd':'Lost'} · ${h.n>=0?'+':''}${cmn(h.n)}">${h.p===0?'W':h.p+1}</i>`).join('')||'<small>No games yet. Your last 12 results will show here.</small>';
 wcModal(`<h3>Your Wildcard record</h3><div class="wcsg">
 ${tile('Games played',cmn(W.g))}${tile('Wins',cmn(W.w),pc(W.w,W.g)+' win rate','gold')}${tile('Best streak',W.best,W.cur?'current '+W.cur:'')}${tile('Gold won',(W.net>=0?'+':'−')+cmn(Math.abs(W.net)),'all time, after buy-ins',W.net>=0?'up':'dn')}
 ${tile('Biggest pot',W.pot?cmn(W.pot):'–')}${tile('Fastest win',W.fast?W.fast+' turns':'–')}${tile('Cards played',cmn(W.cards))}${tile('+4 Hex played',cmn(W.d4))}
 ${tile('WILD! calls',cmn(W.ones))}${tile('Catches',cmn(W.catches),W.caught?'caught '+W.caught+'×':'')}</div>
 <div class="wcs2"><div><h4>By table</h4>${row('e','Easy')}${row('m','Medium')}${row('h','Hard')}${row('pp','Pass & play')}${row('net','Wi-Fi rooms')}</div>
 <div><h4>Recent games</h4><div class="wchist">${hist}</div><h4>Card backs</h4><div class="wcbks">${Object.keys(WCBK).map(k=>{const own=W.backs[k];return `<button class="wcbkc${W.back===k?' on':''}${own?'':' lk'}" data-bk="${k}" ${own?'':'disabled'} title="${WCBK[k].n}: ${own?'click to use':WCBK[k].how}"><span>${wcBack(k)}</span><b>${WCBK[k].n}</b><small>${own?(W.back===k?'In use':'Owned'):WCBK[k].how}</small></button>`}).join('')}</div></div></div>`,'wide wcsm');
 ov.querySelectorAll('[data-bk]').forEach(b=>b.onclick=()=>{W.back=b.dataset.bk;save();wcSnd(700,.05,'triangle',.25);wcStats()})}
/* ---------- solo ---------- */
function wcReset(o){wcClear();WX.tok++;Object.assign(WX,{G:null,me:0,seen:0,busy:false,sort:WX.sort||0,ended:false,recorded:false,cover:false,fresh:null,chat:[],stake:0,fee:0,mode:'solo',host:true,cfg:{timer:0}},o||{})}
function wcStartSolo(tbl,friendly){const T=WCT[tbl],W=wcSt();let stake=friendly||!wcLeftToday()?0:T.stake;
 if(stake>P.gold){wcModal(`<h3>Not enough gold</h3><p class="wcp">The ${T.lab} table buy-in is <b>${cmn(stake)}</b> gold and you have <b>${cmn(P.gold)}</b>.</p><div class="wcrow"><button class="wcbtn gold" id="wcfrg">Play a friendly game</button></div>`);$('wcfrg').onclick=()=>wcStartSolo(tbl,true);return}
 if(stake){P.gold-=stake;W.dayN++;save()}
 wcReset({mode:'solo',tbl,stake,fee:T.fee,cfg:{timer:0,tbl,friendly}});
 const players=[{id:'me',name:P.name||'You',kind:'you',av:wcMyAv()},...T.bots.map(([id,n])=>({id,name:n,kind:'bot',diff:tbl,av:{t:'mon',id}}))];
 WX.G=wcNew({players,hand:7,rules:{stack:1},seed:(Date.now()^Math.floor(Math.random()*1e9))>>>0});wcTable();wcPump()}
/* ---------- results ---------- */
function wcRecord(o){const G=WX.G;if(!G||WX.recorded)return null;WX.recorded=true;const W=wcSt(),k=WX.mode==='solo'?WX.tbl:WX.mode;const me=G.P[WX.mode==='pp'?0:WX.me];
 const rank=o&&o.forfeit?null:wcRank(G),place=rank?rank.indexOf(WX.mode==='pp'?0:WX.me):G.P.length-1,win=place===0;
 const pay=WX.stake?wcPayout(WX.stake,G.P.length,place,WX.fee):0,bonus=win&&WX.mode!=='pp'&&W.fw!==wcDay()?WCE.FIRSTWIN:0;
 if(pay+bonus>0)P.gold=Math.min(1e12,P.gold+pay+bonus);if(bonus)W.fw=wcDay();
 W.g++;if(win){W.w++;W.cur++;W.best=Math.max(W.best,W.cur);if(!W.fast||G.turns<W.fast)W.fast=G.turns}else W.cur=0;
 const net=pay+bonus-WX.stake;W.net+=net;if(win)W.pot=Math.max(W.pot,pay);W.cards+=me.played;W.d4+=me.d4;W.ones+=me.ones;W.catches+=me.catches;W.caught+=me.caught;W.drawn+=me.drawn;
 if(W.byd[k]){W.byd[k].g++;if(win)W.byd[k].w++}W.hist.push({p:place,n:net,k});if(W.hist.length>30)W.hist.splice(0,W.hist.length-30);
 const got=[];const un=(b,ok)=>{if(ok&&!W.backs[b]){W.backs[b]=1;got.push(b)}};let hw=false;try{hw=!!hwOn()}catch(e){}
 un('hallow',W.w>=3||hw);un('royal',W.w>=25);un('astral',W.byd.h.w>=10);
 try{const c=cst();c.plays++;c.net+=net;if(net>c.best)c.best=net}catch(e){}
 save();return{rank,place,pay,bonus,net,got}}
function wcEnd(){const G=WX.G;if(!G||!$('wct'))return;const R=wcRecord();if(!R)return;wcResults(R)}
function wcResults(R){const G=WX.G,rank=R.rank,n=G.P.length,W=wcSt(),wi=rank[0],wn=G.P[wi];
 const most=G.P.reduce((a,p,i)=>p.drawn>G.P[a].drawn?i:a,0),calls=G.P.map((p,i)=>p.caught?`${esc(p.name)} ×${p.caught}`:'').filter(Boolean).join(', ')||'Nobody';
 const order=[1,0,2].filter(k=>k<Math.min(3,n));
 const pod=order.map(k=>{const i=rank[k],p=G.P[i];return `<div class="wcpc p${k+1}" style="--k:${k}"><canvas width="260" height="300" data-fig="${i}"></canvas><div class="wcblk"><b>${k+1}</b><span>${esc(p.name)}</span><small>${p.hand.length?p.hand.length+' card'+(p.hand.length>1?'s':'')+' left':'Emptied their hand'}</small></div></div>`}).join('');
 const T=WX.mode==='solo'?WCT[WX.tbl]:null,pot=WX.stake*n;
 const lines=WX.stake?[[`Pot (${n} × ${cmn(WX.stake)})`,R.place===0?'+'+cmn(pot):'–'],R.place===0?[`Table fee ${Math.round(WX.fee*100)}%`,'−'+cmn(pot-R.pay)]:R.place===1?['2nd place refund','+'+cmn(R.pay)]:null,['Your buy-in','−'+cmn(WX.stake)]].filter(Boolean):[['Friendly game','no stake']];
 if(R.bonus)lines.push(['First win today','+'+cmn(R.bonus)]);
 const me=WX.mode==='pp'?0:WX.me;
 show(`<div class="wcr" id="wcr"><div class="wcrays"></div><div class="wcconf" id="wcconf"></div>
 <div class="wcrtag">${WX.mode==='solo'?T.lab.toUpperCase()+' TABLE':WX.mode==='pp'?'PASS & PLAY':'ROOM '+esc(WX.room||'')} · ${n} PLAYERS</div>
 <h1 class="wcrh">${wi===me?'You win!':esc(wn.name)+' wins!'}</h1>
 <div class="wcpod">${pod}</div>
 <div class="wcrp wcrs"><h4>Match stats</h4><div><span>Turns played</span><b>${G.turns}</b></div><div><span>Biggest stack</span><b>${G.big?'+'+G.big:'–'}</b></div><div><span>Most cards drawn</span><b>${G.P[most].drawn} (${esc(G.P[most].name)})</b></div><div><span>Caught forgetting WILD!</span><b>${calls}</b></div><div><span>Your cards played</span><b>${G.P[me].played}</b></div></div>
 <div class="wcrp wcrpay"><h4>${WX.mode==='pp'?'Result':'Your payout'}</h4>${lines.map(([a,b])=>`<div><span>${a}</span><b class="${String(b)[0]==='+'?'up':String(b)[0]==='−'?'dn':''}">${b}</b></div>`).join('')}
  <div class="wctot"><span>Total</span><b class="${R.net>=0?'up':'dn'}"><span class="coin"></span>${R.net>=0?'+':'−'}${cmn(Math.abs(R.net))}</b></div>
  <p class="wcrn">Record ${W.w}–${W.g-W.w}${W.cur>1?` · win streak ${W.cur}`:''}${WX.stake?` · staked games today ${W.dayN} / ${WCE.DAILY}`:''}</p>${R.got.map(b=>`<p class="wcunl">${wcBack(b)}<span><b>New card back!</b>${WCBK[b].n}</span></p>`).join('')}</div>
 <div class="wcrb"><button class="wcbtn gold big" id="wcagain">${WX.mode==='net'?'Back to lobby':'↻ Play again'}</button><button class="wcbtn purple big" id="wchome">Wildcard menu</button><button class="wcbtn dark big" id="wcout">Leave</button></div></div>`,'casbg wcx');
 ov.querySelectorAll('canvas[data-fig]').forEach(c=>wcFigure(c,G.P[+c.dataset.fig].av));
 if(!wcRM()){const cf=$('wcconf'),L=[];for(let k=0;k<26;k++){const c={s:WCS[k%4],v:String(k%10),id:700+k};L.push(`<i style="--x:${(k*61)%100}vw;--d:${(k%9)*.35}s;--t:${3.2+(k%5)*.6}s;--r:${(k*47)%360}deg">${wcSVG(c)}</i>`)}cf.innerHTML=L.join('')}
 if(wi===me)try{jingle('win')}catch(e){}else wcSnd(260,.2,'triangle',.25);
 const cfg=WX.cfg;$('wcagain').onclick=()=>{if(WX.mode==='solo')wcStartSolo(WX.tbl,!!(cfg&&cfg.friendly));else if(WX.mode==='pp')wcLobby(cfg);else wcLobbyBack()};
 $('wchome').onclick=()=>{try{wcNetClose()}catch(e){}wcHome()};$('wcout').onclick=wcLeaveHome;S.back=()=>{try{wcNetClose()}catch(e){}wcHome()};
 setTimeout(()=>{const b=$('wcagain');if(b)b.focus()},60)}
/* ---------- room lobby: seats, table settings and house rules ---------- */
const WCL={seats:[],set:{stake:0,timer:0,hand:7,stack:1,until:0,seven:0,bot:'m'},room:''};
const wcCode=()=>Array.from({length:4},()=>'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[Math.floor(Math.random()*32)]).join('');
function wcLobby(keep){WX.tok++;wcClear();if(!keep||!WCL.seats.length){WCL.room=wcCode();WCL.seats=[{k:'you',name:P.name||'You'},{k:'bot'},{k:'bot'},{k:'open'}]}
 if(keep&&keep.set)Object.assign(WCL.set,keep.set);wcLobbyRender()}
const WCSTK=[0,50,150,400],WCTM=[0,20,30];
function wcLobbyRender(){const S2=WCL.set,seats=WCL.seats,pp=seats.some(s=>s.k==='local'),net=seats.some(s=>s.k==='net'||s.k==='inv');if(pp)S2.stake=0;
 const filled=seats.filter(s=>['you','bot','local','net'].includes(s.k)).length,waiting=seats.some(s=>s.k==='inv'||(s.k==='net'&&!s.ready));
 const seat=(s,i)=>{if(s.k==='you')return `<div class="wcls me"><span class="wclav"><canvas width="96" height="96" data-me="1"></canvas></span><div><b>${esc(s.name)} (you)</b><small class="ok">✓ Host</small></div><i class="wccr">${WCI.crown}</i></div>`;
  if(s.k==='open')return `<div class="wcls open" data-i="${i}"><span>Open seat</span><div class="wcadd"><button data-add="bot" data-i="${i}">${WCI.bot}Bot</button><button data-add="local" data-i="${i}">${WCI.users}Player here</button><button data-add="inv" data-i="${i}">${WCI.wifi}Wi-Fi friend</button></div></div>`;
  const rm=`<button class="wclx" data-rm="${i}" aria-label="Remove">${WCI.x}</button>`;
  if(s.k==='bot')return `<div class="wcls bot"><span class="wclav"><canvas width="96" height="96" data-mon="${WCT[S2.bot].bots[(i-1)%3][0]}"></canvas></span><div><b>${WCT[S2.bot].bots[(i-1)%3][1]}</b><small>Bot · ${WCT[S2.bot].lab}</small></div>${rm}</div>`;
  if(s.k==='local')return `<div class="wcls pp"><span class="wclav ic">${WCI.users}</span><div><input class="wcnmi" data-nm="${i}" maxlength="14" value="${esc(s.name||'Player '+(i+1))}" aria-label="Player name"><small>Plays on this device</small></div>${rm}</div>`;
  if(s.k==='net')return `<div class="wcls net"><span class="wclav"><canvas width="96" height="96" data-hero="${i}"></canvas></span><div><b>${esc(s.name||'Friend')}</b><small class="${s.ready?'ok':''}">${s.ready?'✓ Ready':'Connected · getting ready…'}</small></div><span class="wcms">${s.ms!=null?s.ms+'ms':''}</span>${rm}</div>`;
  return `<div class="wcls inv"><span class="wclav ic">${WCI.wifi}</span><div><b>Inviting a friend…</b><small>Waiting for their reply code</small></div><button class="wcbtn sm" data-inv="${i}">Show invite</button>${rm}</div>`};
 const tg=(k,l,sub)=>`<label class="wctgl"><span><b>${l}</b>${sub?`<small>${sub}</small>`:''}</span><input type="checkbox" data-rule="${k}" ${S2[k]?'checked':''}><i></i></label>`;
 const cyc=(k,l,arr,fmt)=>`<button class="wcset" data-cyc="${k}"><span>${l}</span><b>${fmt(S2[k])} <i>›</i></b></button>`;
 show(`<div class="wcl" id="wcl"><div class="wcbg"></div><header class="wclh"><h1>Room Lobby</h1><p>Friends play on this device or join from the same Wi-Fi.</p><button class="wcbtn dark" id="wcll">Leave room</button></header>
 <section class="wclp code"><h4>Room</h4><div class="wcct">${WCL.room.split('').map((ch,i)=>`<span style="--i:${i}">${ch}</span>`).join('')}</div>
  <div class="wcways"><div>${WCI.users}<span><b>Pass &amp; play</b><small>Add “Player here” seats. The device is passed round, and each hand stays hidden until its owner taps in.</small></span></div>
  <div>${WCI.wifi}<span><b>Same Wi-Fi</b><small>Add a “Wi-Fi friend” seat to make an invite. Your friend opens it, then sends you back their reply code.</small></span></div></div>
  <p class="wclst ${waiting?'':'ok'}">${waiting?'● Waiting for players…':'● Room open'}</p></section>
 <section class="wclp seats"><h4>Players · ${filled} / 4</h4><div class="wclsl">${seats.map(seat).join('')}</div></section>
 <section class="wclp sets"><h4>Table settings</h4>${cyc('stake','Gold stake',WCSTK,v=>pp?'Free (pass & play)':v?cmn(v)+' each':'Free')}${cyc('timer','Turn timer',WCTM,v=>v?v+' s':'Off')}${cyc('hand','Cards per hand',[5,7,9],v=>v)}${cyc('bot','Bot skill',['e','m','h'],v=>WCT[v].lab)}
  <h4 class="hr">House rules</h4>${tg('stack','Stack +2 and +4','Pass the draw on')}${tg('until','Draw until you can play','')}${tg('seven','Sevens swap hands','With the player holding the fewest cards')}
  <button class="wcbtn gold big" id="wcgo" ${filled<2||waiting?'disabled':''}>Start game · ${filled} players</button><p class="wcfoot">${waiting?'Waiting for every Wi-Fi friend to be ready':filled<2?'Add at least one more player or bot':S2.stake&&net?'Each player pays the stake from their own gold':'Only the host can start'}</p></section>
 <div class="wcmod" id="wcmod" hidden></div></div>`,'casbg wcx');
 S.back=()=>{const m=$('wcmod');if(m&&!m.hidden){m.hidden=true;m.innerHTML='';return}wcLobbyLeave()};$('wcll').onclick=wcLobbyLeave;
 ov.querySelectorAll('canvas[data-me]').forEach(c=>wcPortrait(c,wcMyAv()));ov.querySelectorAll('canvas[data-mon]').forEach(c=>wcPortrait(c,{t:'mon',id:c.dataset.mon}));
 ov.querySelectorAll('canvas[data-hero]').forEach(c=>wcPortrait(c,WCL.seats[+c.dataset.hero].av||{t:'hero'}));
 ov.querySelectorAll('[data-add]').forEach(b=>b.onclick=()=>{const i=+b.dataset.i,k=b.dataset.add;wcSnd(640,.05,'triangle',.25);if(k==='inv'){WCL.seats[i]={k:'inv'};wcLobbyRender();wcInvite(i);return}WCL.seats[i]=k==='local'?{k:'local',name:'Player '+(i+1)}:{k:'bot'};wcLobbyRender()});
 ov.querySelectorAll('[data-rm]').forEach(b=>b.onclick=()=>{const i=+b.dataset.rm;try{wcNetDrop(i)}catch(e){}WCL.seats[i]={k:'open'};wcSnd(380,.05,'triangle',.2);wcLobbyRender()});
 ov.querySelectorAll('[data-inv]').forEach(b=>b.onclick=()=>wcInvite(+b.dataset.inv));
 ov.querySelectorAll('[data-nm]').forEach(x=>{x.onkeydown=e=>e.stopPropagation();x.oninput=()=>{WCL.seats[+x.dataset.nm].name=x.value.replace(/[<>]/g,'').slice(0,14)}});
 ov.querySelectorAll('[data-cyc]').forEach(b=>b.onclick=()=>{const k=b.dataset.cyc,A={stake:WCSTK,timer:WCTM,hand:[5,7,9],bot:['e','m','h']}[k];if(k==='stake'&&pp)return;S2[k]=A[(A.indexOf(S2[k])+1)%A.length];wcSnd(620,.04,'triangle',.22);wcLobbyRender();wcNetLobby()});
 ov.querySelectorAll('[data-rule]').forEach(x=>x.onchange=()=>{S2[x.dataset.rule]=x.checked?1:0;wcSnd(700,.04,'triangle',.2);wcNetLobby()});
 $('wcgo').onclick=wcLobbyStart;wcNetLobby()}
function wcLobbyLeave(){try{wcNetClose()}catch(e){}WCL.seats=[];wcHome()}
function wcLobbyStart(){const S2=WCL.set,seats=WCL.seats.filter(s=>['you','bot','local','net'].includes(s.k));if(seats.length<2)return;
 const pp=seats.some(s=>s.k==='local'),stake=pp?0:S2.stake;if(stake&&stake>P.gold){wcModal(`<h3>Not enough gold</h3><p class="wcp">The stake is <b>${cmn(stake)}</b> and you have <b>${cmn(P.gold)}</b>. Lower the stake to start.</p>`);return}
 const players=seats.map((s,i)=>s.k==='you'?{id:'host',name:P.name||'You',kind:'you',av:wcMyAv()}:s.k==='bot'?{id:'b'+i,name:WCT[S2.bot].bots[(WCL.seats.indexOf(s)-1)%3][1],kind:'bot',diff:S2.bot,av:{t:'mon',id:WCT[S2.bot].bots[(WCL.seats.indexOf(s)-1)%3][0]}}
  :s.k==='local'?{id:'l'+i,name:s.name||'Player '+(i+1),kind:'local',av:{t:'hero',col:(i*3)%8}}:{id:s.pid,name:s.name||'Friend',kind:'net',av:s.av||{t:'hero'},peer:s.peer});
 if(stake){P.gold-=stake;save()}
 wcReset({mode:pp?'pp':seats.some(s=>s.k==='net')?'net':'pp',host:true,stake,fee:WCE.MPFEE,room:WCL.room,cfg:{timer:S2.timer,set:Object.assign({},S2)}});
 WX.G=wcNew({players,hand:S2.hand,rules:{stack:S2.stack,until:S2.until,seven:S2.seven},seed:(Date.now()^Math.floor(Math.random()*1e9))>>>0});
 if(WX.mode==='pp'){const first=WX.G.turn;if(WX.G.P[first].kind==='local'){WX.me=first}}
 wcNetStart();wcTable();wcPump()}
