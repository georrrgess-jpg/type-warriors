/* ===== 9.6 THE CROOKED CUE: ball sets, redone and more of them (96zb) =====
   One painter for every set, still per pixel into the same atlas, with a material per set:
   classic (clear-coat phenolic), marble (veined stone, gold numbers), gem (faceted, sparkling), pearl (Moonstone,
   iridescent), neon (dark glass with glowing bands), lava (cracked rock glowing from inside), galaxy (nebula and stars),
   metal (Champion Gold: polished metal reflecting the room). Every set gets a fresnel rim, a crisp ring round the number
   disc and the old lamp, window and felt bounce. Five new sets join the three old ones (the shop or the regulars). */
Object.assign(PZ_BPAL.classic,{kind:'classic',rim:.22});
Object.assign(PZ_BPAL.gem,{kind:'gem',rim:.3});
Object.assign(PZ_BPAL.moon,{kind:'pearl',rim:.35});
PZ_BPAL.marble={kind:'marble',col:{1:[236,200,96],2:[96,128,196],3:[200,96,96],4:[150,112,186],5:[226,150,92],6:[96,160,124],7:[150,86,80],8:[52,50,58]},white:[240,236,228],disc:[252,246,232],num:[150,104,20],spec:1.2,win:.14,rim:.25};
PZ_BPAL.neon={kind:'neon',col:{1:[255,230,60],2:[60,170,255],3:[255,60,110],4:[190,90,255],5:[255,150,40],6:[60,255,160],7:[255,90,70],8:[220,220,240]},white:[244,244,255],disc:[24,20,36],num:[255,255,255],spec:1.3,win:.12,rim:.4};
PZ_BPAL.lava={kind:'lava',col:{1:[255,200,40],2:[80,150,255],3:[255,70,40],4:[200,90,255],5:[255,130,30],6:[90,255,120],7:[255,60,60],8:[255,120,40]},white:[236,226,214],disc:[40,26,22],num:[255,190,90],spec:.9,win:.08,rim:.2};
PZ_BPAL.galaxy={kind:'galaxy',col:{1:[255,210,90],2:[80,130,255],3:[255,90,140],4:[170,110,255],5:[255,150,80],6:[80,230,200],7:[230,100,120],8:[150,140,220]},white:[238,240,255],disc:[230,232,246],num:[30,26,70],spec:1.3,win:.14,rim:.35};
PZ_BPAL.royal={kind:'metal',col:{1:[255,210,90],2:[120,170,255],3:[255,110,110],4:[200,140,255],5:[255,170,90],6:[110,230,160],7:[230,120,110],8:[70,64,84]},white:[248,244,232],disc:[255,248,226],num:[60,40,10],spec:1.6,win:.2,rim:.3};
for(const b of[{id:'marble',n:'Carrara Marble',how:'Cue Rack: 2,500',price:2500},{id:'neon',n:'Neon Nights',how:'Cue Rack: 8,000',price:8000},{id:'lava',n:'Ember Core',how:'Beat Grizzle',beat:'grizzle'},{id:'galaxy',n:'Starfall',how:'Beat Professor Hootsworth',beat:'hootsworth'},{id:'royal',n:'Champion Gold',how:'Beat Mortimer',beat:'mortimer'}])
 if(!PZ_BALLS.some(x=>x.id===b.id))PZ_BALLS.push(b);
/* regular-won ball sets unlock with the felts (one win) */
{const f0=pzUnlockSweep;pzUnlockSweep=function(){const got=f0.apply(this,arguments),Z=PZS();for(const b of PZ_BALLS)if(!Z.ballsets[b.id]&&b.beat&&(Z.beat[b.beat]||0)>=1){Z.ballsets[b.id]=1;got.push({t:'balls',id:b.id,n:b.n})}return got}}
{const p0=PZS;PZS=function(){const Z=p0.apply(this,arguments);try{if(Z&&!PZ_BALLS.some(b=>b.id===Z.balls))Z.balls='classic'}catch(e){}return Z}}
const pzbF=x=>x-Math.floor(x),pzbH=(x,y,z)=>pzbF(Math.sin(x*127.1+y*311.7+z*74.7)*43758.5453);
function pzbPaint(slot,n,M){const P=PZ_BS,pal=P.pal,K=pal.kind||'classic',d=P.img.data,stripe=n>8,C=n===0?pal.white:pal.col[stripe?n-8:n],W=pal.white,DS=pal.disc,NM=pal.num,gl=n>0?P.gm[n]:null,
 m0=M[0],m1=M[1],m2=M[2],m3=M[3],m4=M[4],m5=M[5],m6=M[6],m7=M[7],m8=M[8],sk=pal.spec,wk=pal.win,rk=pal.rim||.25,cue=n===0;if(!P.rimA||P.rimA.length!==P.n){P.rimA=new Float32Array(P.n);for(let j=0;j<P.n;j++)P.rimA[j]=Math.pow(1-P.nz[j],2.6)}const RA=P.rimA;
 for(let j=0;j<P.n;j++){const wx=P.nx[j],wy=P.ny[j],wz=P.nz[j];
  const lx=m0*wx+m3*wy+m6*wz,ly=m1*wx+m4*wy+m7*wz,lz=m2*wx+m5*wy+m8*wz;
  /* band: 1 inside the coloured part (whole ball for solids), 0 on the white of a stripe */
  let band=1;if(stripe){const ay=ly<0?-ly:ly;band=1-Math.max(0,Math.min(1,(ay-.56)/.035+.5))}
  let r,g,b,er=0,eg=0,eb=0,lit=1,metal=0;
  if(cue){r=W[0];g=W[1];b=W[2]}
  else if(K==='marble'){const v=Math.sin(lx*3.1+ly*1.2+3.4*Math.sin(ly*2.7+lz*1.9+1.3*Math.sin(lx*5.1))+2.3*Math.sin(lz*4.1-lx*2.3)),v1=1-Math.abs(v),v2=v1*v1,v4=v2*v2,vm=v4*v4*v1*.55,cl=.93+.07*Math.sin(ly*7+lz*3+lx*2);
   const br=C[0]+(W[0]-C[0])*.18,bg=C[1]+(W[1]-C[1])*.18,bb=C[2]+(W[2]-C[2])*.18;r=(W[0]+(br-W[0])*band)*cl;g=(W[1]+(bg-W[1])*band)*cl;b=(W[2]+(bb-W[2])*band)*cl;const vr=band?.45:.62;r*=1-vm*(1-vr);g*=1-vm*(1-vr);b*=1-vm*(1-vr)}
  else if(K==='gem'){const fx=Math.round(lx*2.6),fy=Math.round(ly*2.6),fz=Math.round(lz*2.6),h=pzbH(fx,fy,fz),k=.72+.5*h;r=(W[0]+(C[0]-W[0])*band)*k;g=(W[1]+(C[1]-W[1])*band)*k;b=(W[2]+(C[2]-W[2])*band)*k;
   const ins=wz*wz*.3*band;er=C[0]*ins;eg=C[1]*ins;eb=C[2]*ins;if(h>.86&&P.spe[j]<.2){const s=(h-.86)*6*Math.max(0,wz);er+=255*s*.5;eg+=255*s*.5;eb+=255*s*.5}}
  else if(K==='pearl'){const a=6*lx+4*ly+(1-wz)*5,ir=(1-wz)*.6+.25;r=W[0]+(C[0]-W[0])*band+38*ir*Math.sin(a);g=W[1]+(C[1]-W[1])*band+38*ir*Math.sin(a+2.1);b=W[2]+(C[2]-W[2])*band+38*ir*Math.sin(a+4.2)}
  else if(K==='neon'){const ring=stripe?band:Math.max(0,1-Math.abs(lz)/.2),dark=[24,22,38];r=dark[0];g=dark[1];b=dark[2];if(stripe&&!band){r=46;g=44;b=64}
   const e=ring*.9+(stripe?0:.1);er=C[0]*e;eg=C[1]*e;eb=C[2]*e;const rim=RA[j]*.7;er+=C[0]*rim;eg+=C[1]*rim;eb+=C[2]*rim;lit=.8}
  else if(K==='lava'){const c=Math.abs(Math.sin(lx*6.1+Math.sin(ly*3.7)*2)*Math.sin(ly*5.3+Math.sin(lz*4.1)*2)*Math.sin(lz*5.9+Math.sin(lx*3.3)*2)),cr=Math.max(0,1-c/.13);
   const tint=band?.42:.12;r=44+(C[0]*.6-44)*tint;g=30+(C[1]*.6-30)*tint;b=26+(C[2]*.6-26)*tint;const hot=cr*cr*(band?1:.7);er=(C[0]*.6+255*.4)*hot;eg=(C[1]*.5+120*.5)*hot;eb=(C[2]*.3+30*.7)*hot}
  else if(K==='galaxy'){const nb=.5+.5*Math.sin(lx*3.3+Math.sin(ly*4.1+lz*2.3)*1.6+Math.sin(lz*3.7)*.8),k2=nb*nb;
   if(band){r=C[0]*.16+C[0]*.9*k2;g=C[1]*.16+C[1]*.9*k2;b=C[2]*.2+C[2]*.9*k2+20*(1-k2)}else{r=30+60*k2;g=28+50*k2;b=60+80*k2}
   const qx=Math.floor(lx*13),qy=Math.floor(ly*13),qz=Math.floor(lz*13),h=pzbH(qx,qy,qz);if(h>.93){const cx=lx*13-qx-.5,cy=ly*13-qy-.5,cz=lz*13-qz-.5,dd=cx*cx+cy*cy+cz*cz,s=Math.max(0,1-dd*9)*(h-.93)*14;er+=255*s;eg+=245*s;eb+=255*s}}
  else if(K==='metal'){metal=1;const rx=2*wz*wx,ry=2*wz*wy,env=.25+.75*Math.max(0,-ry*.6+.45)+.25*Math.max(0,ry)*.3+.35*Math.pow(Math.max(0,1-Math.abs(rx+.35)*1.4),3)*Math.max(0,-ry+.2),
   tr=band?C[0]*.55+255*.45:250,tg=band?C[1]*.55+214*.45:236,tb=band?C[2]*.55+120*.45:206;r=tr*env;g=tg*env;b=tb*env;lit=0}
  else{r=W[0]+(C[0]-W[0])*band;g=W[1]+(C[1]-W[1])*band;b=W[2]+(C[2]-W[2])*band}
  /* number discs on both poles, with a crisp ring round each */
  const az=lz<0?-lz:lz;
  if(n>0){if(az>.8){const u=lx*2,v=ly*2,q=u*u+v*v;if(q<1.3){const dk=Math.max(0,Math.min(1,(1-q)/.1+.2)),fade=Math.min(1,(az-.8)/.03);
    const s=lz>0?1:-1,gx=((u*s*.5+.5)*64)|0,gy=((v*.5+.5)*64)|0;let gm=0;if(gx>=0&&gx<64&&gy>=0&&gy<64)gm=gl[gy*64+gx]/255;
    const t=dk*fade;let dr=DS[0]+(NM[0]-DS[0])*gm,dg=DS[1]+(NM[1]-DS[1])*gm,db=DS[2]+(NM[2]-DS[2])*gm;
    if(K==='neon'){dr=DS[0];dg=DS[1];db=DS[2];const e=gm*t;er=er*(1-t)+C[0]*e*1.1+60*e;eg=eg*(1-t)+C[1]*e*1.1+60*e;eb=eb*(1-t)+C[2]*e*1.1+60*e}
    else if(K==='lava'){er*=1-t;eg*=1-t;eb*=1-t;const e=gm*t;er+=255*e;eg+=170*e;eb+=60*e}
    else{er*=1-t;eg*=1-t;eb*=1-t}
    r+=(dr-r)*t;g+=(dg-g)*t;b+=(db-b)*t;
    /* the ring */
    const rg=Math.max(0,1-Math.abs(q-1.02)/.09)*fade*.5;r*=1-rg;g*=1-rg;b*=1-rg}}}
  else{let dm=0;if(az>.93){const q=lx*lx+ly*ly;if(q<.026)dm=Math.min(1,(.026-q)/.006)}
   else{const ax=lx<0?-lx:lx,ay=ly<0?-ly:ly;if(ax>.95){const q=ly*ly+lz*lz;if(q<.018)dm=Math.min(1,(.018-q)/.005)}else if(ay>.95){const q=lx*lx+lz*lz;if(q<.018)dm=Math.min(1,(.018-q)/.005)}}
   if(dm>0){r+=(210-r)*dm;g+=(48-g)*dm;b+=(52-b)*dm}}
  const f=metal?1:(P.dif[j]*lit+(1-lit)*.55),sp=P.spe[j]*255*sk,o=P.idx[j]*4,bo=P.bou[j]*38,wn=P.win[j]*255*wk,rim=RA[j]*255*rk;
  let rr=r*f+sp+wn+rim*.86+er,gg=g*f+sp+wn+bo+rim*.9+eg,bb=b*f+sp+wn+bo*.4+rim+eb;d[o]=rr>255?255:rr<0?0:rr;d[o+1]=gg>255?255:gg<0?0:gg;d[o+2]=bb>255?255:bb<0?0:bb;d[o+3]=P.al[j]*255}
 P.ax.putImageData(P.img,slot*P.D,0)}
/* the richer sets cost more per ball: repaint moving balls round-robin inside a small time budget per frame
   (the break still turns every ball; a ball may simply wait a frame) */
function pzbSync(B){const all=PZ_BS.dirtyAll;PZ_BS.dirtyAll=0;let n=0;const L=B.length,o=(PZ_BS.rr=(PZ_BS.rr||0)+1)%L,t0=performance.now();
 for(let k=0;k<L;k++){const b=B[(o+k)%L];if(all||b.dirty){if(!all&&n>=4&&performance.now()-t0>2.2){continue}pzbPaint(b.id,b.id,b.M);b.dirty=0;n++}}return n}
/* the Cue Rack's ball wall: eight sets in two columns */
{const st=document.createElement('style');st.textContent=`
.pzrk9 .pzkwall.balls .pzkcards{grid-template-columns:1fr 1fr;gap:10px;inset:18px}
.pzrk9 .pzkwall.balls .pzksw>canvas{width:330px;height:66px}
.pzrk9 .pzkwall.balls .pzksw{padding:10px 14px 8px}
.pzrk9 .pzkwall.balls .pzksw b{font-size:21px;margin-top:2px}
.pzrk9 .pzkwall.balls .pzksw .pzktag{top:10px}
.pzrk9 .pzkwall.balls .pzksw .pzktag canvas{width:18px;height:18px}
`;document.head.appendChild(st)}
