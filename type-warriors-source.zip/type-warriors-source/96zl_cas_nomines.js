/* ===== Mines removed from the casino (96zl) =====
   At the owner's request the Mines game is gone: it leaves the game list (All Games and Chance tabs) and gameOpen('mi') goes back
   to the lobby. Its code in 65/66 stays unused; the 9.6 Mines bet cap in 96zf no longer matters. */
{const i=GAMES.findIndex(g=>g.id==='mi');if(i>=0)GAMES.splice(i,1)}
{const g0=gameOpen;gameOpen=function(id){if(id==='mi'){try{lobby()}catch(e){}return}return g0.apply(this,arguments)}}
