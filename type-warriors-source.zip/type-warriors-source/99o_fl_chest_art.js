/* ===== 10.4 HARVEST FESTIVAL: the Harvest Chest, art (99o, prefix flc; needs 99m_fl_core) =====
   The painted chest and every piece of the harvest-night opening scene:
   - flcChest(g,x,y,s,u,t): a wicker-and-oak harvest chest wrapped in a maple vine, a carved pumpkin lock (a glowing maple leaf cut into
     it), a wheat sheaf on the left and a harvest lantern on the right. Drawn at (x,y) = bottom centre, scale s, lid open u (0..1),
     time t; reads NCX.hov (hover glow) and NCX.ch (charge while opening) like the shop chests in 68c. Hooked into chest() as key 'f'.
   - Scene parts: maple / elm leaf sprites, pumpkins, harvest lanterns on posts, the scarecrow (its head turns), crows, the harvest
     moon (orange and gold sprites), the cornucopia, the feathered turkey silhouette, coins, acorns, an XP star.
   - flcBake(k): the static night (sky, stars, hills with a barn and silo, a fence), two corn rows and the pumpkin patch, painted once
     per opening into offscreen canvases at k x resolution; the per-frame draw only stamps them (with a skew for the corn in the wind).
   Style: chunky #12081f outlines, warm gold accents. No shadowBlur or ctx.filter; glows are pre-baked sprites. */
const FLO='#12081f';
const flcA=n=>Math.round(Math.max(0,Math.min(1,n))*255).toString(16).padStart(2,'0');
const flcRM=()=>{try{return matchMedia('(prefers-reduced-motion: reduce)').matches}catch(e){return false}};
const flcLow=()=>{try{return typeof PFM==='function'&&PFM()==='low'}catch(e){return false}};
function flcCv(w,h){const c=document.createElement('canvas');c.width=Math.max(1,Math.ceil(w));c.height=Math.max(1,Math.ceil(h));return c}
const flcRnd=s=>{let a=s>>>0;return()=>{a=(a+0x6D2B79F5)|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}};
function flcP(g,p){g.beginPath();g.moveTo(p[0],p[1]);for(let i=2;i<p.length;i+=2)g.lineTo(p[i],p[i+1]);g.closePath()}
function flcF(g,f,lw,sc){g.fillStyle=f;g.fill();if(lw!==0){g.strokeStyle=sc||FLO;g.lineWidth=lw||2.4;g.lineJoin='round';g.stroke()}}
function flcLin(g,x0,y0,x1,y1,st){const q=g.createLinearGradient(x0,y0,x1,y1);st.forEach((c,i)=>q.addColorStop(i/(st.length-1),c));return q}
const FLC_AU=['#fff4c0','#ffd45a','#e0a02a','#9a6012'];
/* ---------- glow sprites: one radial falloff per colour, stamped with drawImage ---------- */
const FLC_GS={};
function flcGlowS(col){let s=FLC_GS[col];if(s)return s;s=flcCv(128,128);const g=s.getContext('2d'),q=g.createRadialGradient(64,64,0,64,64,64);
 q.addColorStop(0,col+'ff');q.addColorStop(.22,col+'aa');q.addColorStop(.5,col+'40');q.addColorStop(1,col+'00');g.fillStyle=q;g.fillRect(0,0,128,128);return FLC_GS[col]=s}
function flcGlow(g,x,y,r,col,a){if(r<=0||a<=0)return;const s=flcGlowS(col.slice(0,7));const ga=g.globalAlpha;g.globalAlpha=ga*Math.min(1,a);g.drawImage(s,x-r,y-r,r*2,r*2);g.globalAlpha=ga}

/* ---------- leaves ---------- */
const FLC_MAPLE=[0,-1, .1,-.66, .34,-.82, .3,-.46, .64,-.58, .52,-.3, .86,-.2, .6,-.02, .7,.14, .32,.06, .3,.3, .06,.2, 0,.34, -.06,.2, -.3,.3, -.32,.06, -.7,.14, -.6,-.02, -.86,-.2, -.52,-.3, -.64,-.58, -.3,-.46, -.34,-.82, -.1,-.66];
function flcMaplePath(g,r){g.beginPath();for(let i=0;i<FLC_MAPLE.length;i+=2){const x=FLC_MAPLE[i]*r,y=FLC_MAPLE[i+1]*r;i?g.lineTo(x,y):g.moveTo(x,y)}g.closePath()}
function flcElmPath(g,r){g.beginPath();g.moveTo(0,-r);g.bezierCurveTo(r*.62,-r*.55,r*.52,r*.38,0,r*.6);g.bezierCurveTo(-r*.52,r*.38,-r*.62,-r*.55,0,-r);g.closePath()}
const FLC_LCOL=['#e8402a','#f07a22','#f4b030','#c8302a','#b8561a','#e0a020'];
const FLC_LS=[];
function flcLeafSprites(){if(FLC_LS.length)return FLC_LS;for(let k=0;k<2;k++)for(const col of FLC_LCOL){const c=flcCv(64,64),g=c.getContext('2d');g.translate(32,30);g.lineJoin='round';g.lineCap='round';
  k?flcElmPath(g,24):flcMaplePath(g,27);g.fillStyle=flcLin(g,-20,-24,20,20,[shade(col,.25),col,shade(col,-.3)]);g.fill();g.strokeStyle=FLO;g.lineWidth=3;g.stroke();
  g.strokeStyle=shade(col,-.45);g.lineWidth=1.6;g.beginPath();g.moveTo(0,k?16:9);g.lineTo(0,-20);if(!k){g.moveTo(0,-2);g.lineTo(13,-12);g.moveTo(0,-2);g.lineTo(-13,-12);g.moveTo(0,4);g.lineTo(14,4);g.moveTo(0,4);g.lineTo(-14,4)}else{for(const y of[-10,-2,6]){g.moveTo(0,y+4);g.lineTo(8,y-3);g.moveTo(0,y+4);g.lineTo(-8,y-3)}}g.stroke();
  g.strokeStyle=FLO;g.lineWidth=3.4;g.beginPath();g.moveTo(0,k?16:8);g.lineTo(1,k?26:24);g.stroke();g.strokeStyle=shade(col,-.4);g.lineWidth=1.6;g.stroke();
  FLC_LS.push(c)}return FLC_LS}
/* one leaf: i picks the sprite (0..11), s its size in px, rot its turn, fl a flip (-1..1) for the tumbling look */
function flcLeaf(g,x,y,s,rot,i,fl){const L=flcLeafSprites(),sp=L[((i|0)%L.length+L.length)%L.length];g.save();g.translate(x,y);g.rotate(rot);g.scale(fl==null?1:(Math.abs(fl)<.12?.12*Math.sign(fl||1):fl),1);g.drawImage(sp,-s/2,-s/2,s,s);g.restore()}

/* ---------- pumpkins ---------- */
/* a ribbed field pumpkin centred at (x,y), r = half width. o.c base colour, o.carve cuts a glowing maple leaf, o.glow 0..1 */
function flcPumpkin(g,x,y,r,o){o=o||{};const c=o.c||'#e8741c',lo=shade(c,.28),dk=shade(c,-.42),h=r*.82;g.save();g.translate(x,y);g.lineJoin='round';
 const lob=(cx,w,col)=>{g.beginPath();g.ellipse(cx,0,w,h,0,0,TAU);flcF(g,col,Math.max(1.6,r*.09))};
 lob(-r*.42,r*.58,flcLin(g,-r,-h,0,h,[c,dk]));lob(r*.42,r*.58,flcLin(g,r,-h,0,h,[c,dk]));lob(0,r*.6,flcLin(g,0,-h,0,h,[lo,c,dk]));
 g.strokeStyle=shade(c,-.3);g.lineWidth=Math.max(1,r*.05);g.beginPath();g.moveTo(-r*.2,-h*.82);g.quadraticCurveTo(-r*.3,0,-r*.2,h*.82);g.moveTo(r*.2,-h*.82);g.quadraticCurveTo(r*.3,0,r*.2,h*.82);g.stroke();
 g.fillStyle='#ffffff38';g.beginPath();g.ellipse(-r*.16,-h*.46,r*.12,h*.26,-.3,0,TAU);g.fill();
 /* stem and a curl of vine */
 g.beginPath();g.moveTo(-r*.08,-h*.8);g.quadraticCurveTo(-r*.12,-h*1.2,r*.08,-h*1.32);g.lineTo(r*.18,-h*1.2);g.quadraticCurveTo(r*.04,-h*1.1,r*.1,-h*.8);g.closePath();flcF(g,'#6a7a2a',Math.max(1.4,r*.07));
 if(r>14){g.strokeStyle='#4a6a24';g.lineWidth=Math.max(1.2,r*.05);g.beginPath();g.moveTo(r*.1,-h*1.1);g.bezierCurveTo(r*.5,-h*1.3,r*.6,-h*.9,r*.36,-h*.92);g.bezierCurveTo(r*.22,-h*.94,r*.28,-h*1.1,r*.4,-h*1.05);g.stroke()}
 if(o.carve){const gl=Math.max(0,Math.min(1,o.glow||0));g.save();g.translate(0,h*.02);g.scale(r/20,r/20);
  flcMaplePath(g,10.5);g.fillStyle=gl>.04?`rgb(255,${190+gl*60|0},${90+gl*110|0})`:'#3a1606';g.fill();g.strokeStyle=FLO;g.lineWidth=1.6;g.stroke();
  if(gl>.04){g.globalAlpha=Math.min(1,gl*1.3);flcMaplePath(g,6);g.fillStyle='#fff8dc';g.fill();g.globalAlpha=1}
  g.beginPath();g.arc(0,11.2,2.2,0,TAU);g.moveTo(-1.4,12);g.lineTo(-2.2,16.4);g.lineTo(2.2,16.4);g.lineTo(1.4,12);g.fillStyle=gl>.3?'#ffe9a8':'#1a0a04';g.fill();g.restore()}
 g.restore()}

/* ---------- the Harvest Chest ---------- */
const flcEOB=u=>{const c1=1.70158,c3=c1+1;return 1+c3*Math.pow(u-1,3)+c1*Math.pow(u-1,2)};
/* the wicker lid: a peek up to u .25 (hover), then it swings back on its hinge and rocks */
function flcLidPose(u){if(u<=0)return{a:0,lift:0,sh:0};const s=x=>x*x*(3-2*x),pk=s(Math.min(1,u/.25)),m=Math.max(0,(u-.25)/.75);return{a:.42*pk+1.5*Math.min(1.08,flcEOB(Math.min(1,m))),lift:3*pk,sh:0,pk}}
/* a short wheat sheaf tied with twine, its base at (x,y) */
function flcSheaf(g,x,y,s,t,lean){g.save();g.translate(x,y);g.scale(s,s);g.rotate(lean||0);const sw=Math.sin(t*1.3+x)*.02;
 g.beginPath();g.moveTo(-12,0);g.lineTo(-7,-40);g.lineTo(-22,-92);g.lineTo(22,-92);g.lineTo(7,-40);g.lineTo(12,0);g.closePath();flcF(g,flcLin(g,0,-92,0,0,['#e8c46a','#c8963e','#8a6024']),2.6);
 g.strokeStyle='#8a6024';g.lineWidth=1.2;for(let i=-3;i<=3;i++){g.beginPath();g.moveTo(i*2.6,0);g.lineTo(i*1.6,-40);g.lineTo(i*4.4,-90);g.stroke()}
 for(let i=-4;i<=4;i++){const a=i*.17+sw,bx=Math.sin(a)*92,by=-Math.cos(a)*92;g.save();g.translate(bx*.98,by*.98+6);g.rotate(a);
  for(let k=0;k<4;k++){g.beginPath();g.ellipse(-2.4,-k*6.2-3,2.9,4.2,-.35,0,TAU);g.ellipse(2.4,-k*6.2-3,2.9,4.2,.35,0,TAU);flcF(g,k%2?'#f0cc6a':'#e0b450',1.3)}
  g.strokeStyle='#e8c46a';g.lineWidth=1;g.beginPath();g.moveTo(0,-24);g.lineTo(0,-36);g.moveTo(-2,-23);g.lineTo(-5,-34);g.moveTo(2,-23);g.lineTo(5,-34);g.stroke();g.restore()}
 g.beginPath();g.moveTo(-9,-44);g.quadraticCurveTo(0,-38,9,-44);g.lineTo(9,-36);g.quadraticCurveTo(0,-30,-9,-36);g.closePath();flcF(g,'#a8743a',2);g.strokeStyle='#e8c88a';g.lineWidth=1;g.beginPath();g.moveTo(-8,-40);g.quadraticCurveTo(0,-34,8,-40);g.stroke();
 g.beginPath();g.moveTo(5,-36);g.quadraticCurveTo(14,-28,10,-18);g.strokeStyle=FLO;g.lineWidth=3.6;g.stroke();g.strokeStyle='#c89a5a';g.lineWidth=1.8;g.stroke();g.restore()}
/* a little standing harvest lantern (the chest's own), its base at (x,y) */
function flcLampSmall(g,x,y,s,t,gl){g.save();g.translate(x,y);g.scale(s,s);const f=.85+.15*Math.sin(t*9+x)+.07*Math.sin(t*23);
 g.save();g.globalCompositeOperation='lighter';flcGlow(g,0,-26,46*f,'#ffb040',.55+gl*.4);g.restore();
 flcP(g,[-15,0,15,0,13,-6,-13,-6]);flcF(g,'#5a3418',2.2);
 g.beginPath();g.roundRect(-11,-42,22,36,3);flcF(g,flcLin(g,0,-42,0,-6,['#ffe9a0','#ffb040','#e07a1a']),2.4);
 g.fillStyle='#fff6d0';g.beginPath();g.ellipse(0,-20+Math.sin(t*11)*.6,3.2*f,6.4*f,0,0,TAU);g.fill();
 g.strokeStyle='#5a3418';g.lineWidth=2.4;g.beginPath();g.moveTo(0,-42);g.lineTo(0,-6);g.moveTo(-11,-24);g.lineTo(11,-24);g.stroke();
 flcP(g,[-14,-42,0,-54,14,-42]);flcF(g,'#6a4020',2.2);g.beginPath();g.arc(0,-58,5,0,TAU);g.strokeStyle=FLO;g.lineWidth=3.4;g.stroke();g.strokeStyle='#c8963a';g.lineWidth=1.6;g.stroke();g.restore()}
function flcChest(g,x,y,s,u,t){u=Math.max(0,u||0);t=t||0;const hv=(typeof NCX==='object'&&NCX.hov)||0,ch=(typeof NCX==='object'&&NCX.ch)||0,L=flcLidPose(u);
 g.save();g.translate(x,y);g.scale(s,s);g.lineJoin='round';g.lineCap='round';
 /* ground shadow and a warm hover glow */
 const sh=g.createRadialGradient(0,4,0,0,4,104);sh.addColorStop(0,'#000a');sh.addColorStop(1,'#0000');g.fillStyle=sh;g.beginPath();g.ellipse(0,4,104,15,0,0,TAU);g.fill();
 if(hv>0||ch>0){g.save();g.globalCompositeOperation='lighter';flcGlow(g,0,-60,150,'#ffa040',.2*hv+.3*ch);g.restore()}
 /* the wheat sheaf leans on the left; fallen leaves at its foot */
 flcSheaf(g,-96,4,.78,t,-.16);
 flcLeaf(g,-62,4,13,.6,1,1);flcLeaf(g,58,6,12,-.8,8,1);flcLeaf(g,84,3,11,2.2,2,1);
 /* the lid (drawn by ncOpenLid between the body and the lock, like the shop chests) */
 const lidFace=()=>{g.beginPath();g.moveTo(-78,0);g.lineTo(-78,-26);g.quadraticCurveTo(0,-74,78,-26);g.lineTo(78,0);g.closePath();flcF(g,flcLin(g,0,-50,0,0,['#e8be6e','#c8944a','#8a5a28']),2.8);
  g.save();g.beginPath();g.moveTo(-78,0);g.lineTo(-78,-26);g.quadraticCurveTo(0,-74,78,-26);g.lineTo(78,0);g.closePath();g.clip();
  /* woven reeds: curved rows, and short over-under ribs */
  g.strokeStyle='#7a4a1e';g.lineWidth=1.8;for(const d of[10,20,30,40]){g.beginPath();g.moveTo(-78,-26+d);g.quadraticCurveTo(0,-74+d*1.08,78,-26+d);g.stroke()}
  g.strokeStyle='#f8dc96aa';g.lineWidth=1.1;for(const d of[12,22,32,42]){g.beginPath();g.moveTo(-70,-24+d);g.quadraticCurveTo(0,-70+d*1.06,70,-24+d);g.stroke()}
  g.strokeStyle='#6a3e16';g.lineWidth=1.4;for(let r=0;r<4;r++){const d=r*10+5;for(let i=-6;i<=6;i++){const xx=i*11+(r%2)*5.5;if(Math.abs(xx)>60)continue;const yy=-26+d+(-48*(1-(xx/78)**2))*(1-d/58);g.beginPath();g.moveTo(xx,yy-4);g.lineTo(xx,yy+4);g.stroke()}}g.restore();
  for(const sx of[-1,1]){g.beginPath();g.moveTo(sx*56,0);g.lineTo(sx*56,-40);g.quadraticCurveTo(sx*68,-38,sx*80,-28);g.lineTo(sx*80,0);g.closePath();flcF(g,flcLin(g,sx*56,-40,sx*80,0,['#a86a34','#7a4622','#4e2a12']),2.6);
   g.strokeStyle='#3a1e0a';g.lineWidth=1.2;g.beginPath();g.moveTo(sx*62,-4);g.lineTo(sx*62,-34);g.moveTo(sx*72,-4);g.lineTo(sx*72,-30);g.stroke();
   g.beginPath();g.arc(sx*68,-16,3.8,0,TAU);flcF(g,flcLin(g,sx*64,-20,sx*72,-12,FLC_AU),1.4)}
  /* the vine runs on over the lid: two leaves and a tiny gourd resting on top */
  g.strokeStyle=FLO;g.lineWidth=5;g.beginPath();g.moveTo(52,-8);g.bezierCurveTo(40,-34,6,-40,-26,-46);g.stroke();g.strokeStyle='#5a8a32';g.lineWidth=2.6;g.stroke();
  flcLeaf(g,18,-42,22,-.5,0,1);flcLeaf(g,-24,-50,20,.6,8,1);
  g.save();g.translate(-44,-40);g.rotate(-.35);g.beginPath();g.ellipse(0,0,10,7,0,0,TAU);flcF(g,flcLin(g,0,-7,0,7,['#f8e070','#d8a020']),2.2);g.beginPath();g.ellipse(9,-2,7,5,.3,0,TAU);flcF(g,flcLin(g,0,-7,0,7,['#7ab84a','#3a6a1e']),2.2);g.fillStyle='#5a3a1a';g.fillRect(-2,-10,3,5);g.restore()};
 const lidIn=h=>{g.beginPath();g.moveTo(-72,0);g.lineTo(-64,-h);g.lineTo(64,-h);g.lineTo(72,0);g.closePath();flcF(g,flcLin(g,0,-h,0,0,['#3a2410','#6a4220']),2.4);g.strokeStyle='#c8944a';g.lineWidth=3;g.stroke();
  g.strokeStyle='#8a5a28';g.lineWidth=1.4;for(let i=1;i<4;i++){g.beginPath();g.moveTo(-68+i*2,-h*i/4);g.lineTo(68-i*2,-h*i/4);g.stroke()}};
 const P={};if(typeof ncOpenLid==='function')ncOpenLid(g,P,L,lidFace,lidIn,46,'#ffd890');else P.lid=()=>{if(u<.02)lidFace()};
 /* body: an oak frame round a woven wicker panel */
 g.beginPath();g.roundRect(-76,-70,152,70,5);flcF(g,flcLin(g,0,-70,0,0,['#9a6232','#7a4622','#4e2a12']),2.8);
 g.save();g.beginPath();g.roundRect(-62,-62,124,50,4);g.clip();g.fillStyle='#6a3e18';g.fillRect(-62,-62,124,50);
 /* basket weave: weavers pass over and under upright stakes */
 const cw=15.5;for(let r=0;r<4;r++){const y0=-62+r*12.5;for(let c=-1;c<9;c++){if((r+c)&1){const x0=-62+c*cw;g.beginPath();g.roundRect(x0+2.5,y0+2,cw-5,8.6,4);g.fillStyle=flcLin(g,0,y0,0,y0+12,['#b8823e','#7a4a1e']);g.fill();g.strokeStyle='#3a1e08';g.lineWidth=1;g.stroke()}}}
 for(let c=0;c<9;c++){const x=-62+c*cw;g.fillStyle='#8a5628';g.fillRect(x-2.2,-62,4.4,50);g.fillStyle='#c8945a88';g.fillRect(x-1.2,-62,1.2,50)}
 for(let r=0;r<4;r++){const y0=-62+r*12.5;for(let c=-1;c<9;c++){if(!((r+c)&1)){const x0=-62+c*cw;g.beginPath();g.roundRect(x0-2.5,y0+1,cw+5,10.6,5);g.fillStyle=flcLin(g,0,y0,0,y0+12,['#f6dc96','#d4a050','#a06a30']);g.fill();g.strokeStyle='#4a2a10';g.lineWidth=1.2;g.stroke();
  g.strokeStyle='#fff4cc99';g.lineWidth=1;g.beginPath();g.moveTo(x0+1,y0+3.6);g.lineTo(x0+cw-1,y0+3.6);g.stroke()}}}
 /* moonlight from the top-left, a little shadow under the rim */
 g.fillStyle='#0000002a';g.fillRect(-62,-62,124,6);g.restore();
 g.beginPath();g.roundRect(-62,-62,124,50,4);g.strokeStyle=FLO;g.lineWidth=2.4;g.stroke();
 g.beginPath();g.roundRect(-80,-14,160,14,3);flcF(g,flcLin(g,0,-14,0,0,['#8a5428','#5e3418']),2.6);g.strokeStyle='#c88a5266';g.lineWidth=1.1;g.beginPath();g.moveTo(-74,-9);g.lineTo(74,-9);g.stroke();
 /* corner posts with brass caps */
 for(const sx of[-1,1]){const x0=sx>0?62:-82;g.beginPath();g.roundRect(x0,-78,20,82,3);flcF(g,flcLin(g,x0,0,x0+20,0,['#a86a34','#7a4622','#4e2a12']),2.6);g.fillStyle='#ffffff26';g.fillRect(x0+3,-74,3,72);
  g.strokeStyle='#3a1e0a';g.lineWidth=1.2;g.beginPath();g.moveTo(x0+12,-70);g.quadraticCurveTo(x0+15,-40,x0+11,-6);g.stroke();
  for(const yy of[-64,-20]){g.beginPath();g.arc(x0+10,yy,4.2,0,TAU);flcF(g,flcLin(g,x0+6,yy-4,x0+14,yy+4,FLC_AU),1.6)}
  flcP(g,[x0-3,4,x0-3,-2,x0+23,-2,x0+23,4]);flcF(g,flcLin(g,0,-2,0,4,FLC_AU),2)}
 /* the maple vine that wraps the front */
 g.strokeStyle=FLO;g.lineWidth=5.4;g.beginPath();g.moveTo(-84,-6);g.bezierCurveTo(-52,-4,-46,-40,-14,-34);g.bezierCurveTo(14,-28,30,-12,56,-26);g.bezierCurveTo(70,-34,70,-56,58,-70);g.stroke();
 g.strokeStyle='#5a8a32';g.lineWidth=3;g.stroke();g.strokeStyle='#9ad06a88';g.lineWidth=1;g.stroke();
 g.strokeStyle='#5a8a32';g.lineWidth=1.6;for(const [a,b,c2,d] of[[-30,-36,-36,-50],[30,-16,40,-6],[64,-50,76,-46]]){g.beginPath();g.moveTo(a,b);g.quadraticCurveTo(c2,d,(a+c2)/2+4,(b+d)/2-2);g.stroke()}
 const lv=[[-70,-8,18,-.4,0],[-46,-26,22,.2,2],[-20,-36,17,-.7,1],[16,-24,20,.5,6],[40,-16,16,-.2,3],[62,-36,19,.9,2],[56,-62,15,-.3,9]];
 for(const [lx,ly,ls,lr,li] of lv)flcLeaf(g,lx,ly,ls,lr+Math.sin(t*1.6+lx)*.06,li,1);
 /* seam band with brass studs */
 g.beginPath();g.roundRect(-64,-76,128,9,2);flcF(g,flcLin(g,0,-76,0,-67,['#a86a34','#5e3418']),2.2);for(const sx of[-48,-32,32,48]){g.beginPath();g.arc(sx,-71.5,2.8,0,TAU);flcF(g,flcLin(g,sx-3,-74,sx+3,-69,FLC_AU),1.2)}
 P.lid&&P.lid();P.lid=null;
 /* the harvest lantern on the right */
 flcLampSmall(g,108,4,.9,t,hv*.5+ch);
 /* the carved pumpkin lock: its maple leaf glows brighter as the chest charges */
 const gl=.38+.3*hv+.75*ch+.12*Math.sin(t*2.2);
 g.save();g.globalCompositeOperation='lighter';flcGlow(g,0,-72,40+ch*44,'#ffb040',Math.min(1,gl*.75));g.restore();
 const sq=ch>0?Math.sin(t*30)*ch*.04:0;g.save();g.translate(0,-72);g.scale(1+sq,1-sq);flcPumpkin(g,0,0,24,{carve:1,glow:Math.min(1,gl),c:'#ec7a1e'});g.restore();
 /* a leaf now and then lets go of the vine and drifts down */
 for(let i=0;i<2;i++){const ph=(t*.16+i*.5)%1;if(ph>.6)continue;const v=ph/.6,lx=-30+i*64+Math.sin(v*7+i)*14,ly=-58+v*70;g.globalAlpha=Math.sin(v*Math.PI);flcLeaf(g,lx,ly,12,v*5+i,i?2:0,Math.cos(v*9));g.globalAlpha=1}
 g.restore()}
{const c0=chest;chest=function(g,x,y,s,u,k,t){if(k==='f')return flcChest(g,x,y,s,u,t);return c0(g,x,y,s,u,k,t)}}

/* ---------- harvest lantern on a post (the opening scene's tier lights) ---------- */
/* (x,y) = foot of the post. lit 0..1, col = flame colour, sw = swing angle */
function flcLantern(g,x,y,s,lit,col,t,sw){g.save();g.translate(x,y);g.scale(s,s);g.lineJoin='round';g.lineCap='round';
 /* post and crook */
 g.beginPath();g.moveTo(-5,0);g.lineTo(-4,-118);g.lineTo(4,-118);g.lineTo(5,0);g.closePath();flcF(g,flcLin(g,-5,0,5,0,['#5a3a1e','#3a2210']),2.4);
 g.beginPath();g.moveTo(0,-112);g.quadraticCurveTo(2,-134,22,-132);g.quadraticCurveTo(34,-130,32,-118);g.strokeStyle=FLO;g.lineWidth=7;g.stroke();g.strokeStyle='#5a3a1e';g.lineWidth=3.6;g.stroke();
 g.beginPath();g.moveTo(-14,0);g.lineTo(14,0);g.lineTo(9,-8);g.lineTo(-9,-8);g.closePath();flcF(g,'#4a2e16',2);
 /* the lantern swings from the hook */
 g.translate(32,-118);g.rotate(sw||0);
 if(lit>0){g.save();g.globalCompositeOperation='lighter';const f=.88+.12*Math.sin(t*10+x)+.06*Math.sin(t*27+x);flcGlow(g,0,38,(110+40*lit)*f,col,.95*lit);flcGlow(g,0,38,34*f,'#fff4d0',.8*lit);g.restore()}
 g.strokeStyle=FLO;g.lineWidth=2.4;g.beginPath();g.moveTo(0,0);g.lineTo(0,8);g.stroke();g.beginPath();g.arc(0,10,4,0,TAU);g.strokeStyle='#8a6a3a';g.lineWidth=2;g.stroke();
 flcP(g,[-15,24,0,12,15,24]);flcF(g,'#6a4020',2.2);
 g.beginPath();g.roundRect(-12,24,24,30,3);const gc=lit>0?flcLin(g,0,24,0,54,['#fff6d0',col,shade(col,-.35)]):flcLin(g,0,24,0,54,['#3a3a5a','#1a1a30']);flcF(g,gc,2.4);
 if(lit<=0){g.fillStyle='#c8d0ff33';g.fillRect(-8,27,4,22)}
 else{g.globalAlpha=Math.min(1,lit*1.5);g.fillStyle='#fffbe8';const f=Math.sin(t*12+x)*.8;g.beginPath();g.moveTo(-3.4,48);g.quadraticCurveTo(-4,38,f,31);g.quadraticCurveTo(4,38,3.4,48);g.closePath();g.fill();g.globalAlpha=1}
 g.strokeStyle='#5a3418';g.lineWidth=2.6;g.beginPath();g.moveTo(0,24);g.lineTo(0,54);g.moveTo(-12,39);g.lineTo(12,39);g.stroke();
 g.beginPath();g.roundRect(-14,52,28,6,2);flcF(g,'#5a3418',2);g.restore()}

/* ---------- the scarecrow ---------- */
/* (x,y) = foot of the pole, look -1..1 turns the head (0 = facing us, 1 = towards the chest on its right), glint lights the button eyes */
function flcScarecrow(g,x,y,s,look,t,o){o=o||{};g.save();g.translate(x,y);g.scale(s,s);g.lineJoin='round';g.lineCap='round';const sw=Math.sin(t*.9)*.015+(o.gust||0)*.06;g.rotate(sw);
 g.beginPath();g.moveTo(-5,0);g.lineTo(-4,-196);g.lineTo(4,-196);g.lineTo(5,0);g.closePath();flcF(g,flcLin(g,-5,0,5,0,['#6a4a2a','#3a2614']),2.6);
 g.beginPath();g.roundRect(-104,-160,208,9,3);flcF(g,flcLin(g,0,-160,0,-151,['#7a5a32','#4a3218']),2.4);
 /* straw at the cuffs */
 for(const sx of[-1,1]){for(let i=0;i<7;i++){const a=(i-3)*.22+sx*.1+Math.sin(t*2+i)*.05*(1+(o.gust||0)*4);g.beginPath();g.moveTo(sx*92,-156);g.lineTo(sx*92+sx*Math.cos(a)*24,-156+Math.sin(a)*20);g.strokeStyle=i%2?'#e8c46a':'#c89a3e';g.lineWidth=2.4;g.stroke()}}
 /* plaid shirt with patched sleeves */
 const shirt=()=>{g.beginPath();g.moveTo(-34,-172);g.lineTo(-92,-166);g.lineTo(-94,-146);g.lineTo(-40,-142);g.lineTo(-38,-80);g.quadraticCurveTo(0,-70,38,-80);g.lineTo(40,-142);g.lineTo(94,-146);g.lineTo(92,-166);g.lineTo(34,-172);g.quadraticCurveTo(0,-180,-34,-172);g.closePath()};
 shirt();flcF(g,flcLin(g,0,-180,0,-74,['#b8483a','#8a2e26','#5e1c18']),2.8);
 g.save();shirt();g.clip();g.strokeStyle='#e8b04a55';g.lineWidth=3;for(let i=-90;i<=90;i+=16){g.beginPath();g.moveTo(i,-182);g.lineTo(i,-70);g.stroke()}for(let j=-176;j<-70;j+=16){g.beginPath();g.moveTo(-96,j);g.lineTo(96,j);g.stroke()}
 g.strokeStyle='#2a0a0a44';g.lineWidth=2;for(let i=-82;i<=90;i+=16){g.beginPath();g.moveTo(i,-182);g.lineTo(i,-70);g.stroke()}g.restore();
 g.beginPath();g.roundRect(-74,-164,18,16,2);flcF(g,'#4a6a8a',2);g.beginPath();g.roundRect(14,-122,18,18,2);flcF(g,'#c8a050',2);g.strokeStyle='#f0e0b0';g.lineWidth=1;g.setLineDash([2,3]);g.strokeRect(16,-120,14,14);g.strokeRect(-72,-162,14,12);g.setLineDash([]);
 /* rope belt and straw skirt */
 for(let i=0;i<9;i++){const xx=-34+i*8.5;g.beginPath();g.moveTo(xx,-84);g.lineTo(xx+Math.sin(t*2.4+i)*2*(1+(o.gust||0)*3)+(i-4)*1.5,-60-(i%3)*4);g.strokeStyle=i%2?'#e8c46a':'#c89a3e';g.lineWidth=2.6;g.stroke()}
 g.beginPath();g.roundRect(-38,-92,76,8,3);flcF(g,'#a8743a',2.2);
 /* neck straw */
 for(let i=0;i<6;i++){g.beginPath();g.moveTo(-10+i*4,-176);g.lineTo(-14+i*5.6,-166+(i%2)*4);g.strokeStyle='#e8c46a';g.lineWidth=2.2;g.stroke()}
 /* the burlap head, turned by look: the face slides and the head narrows */
 const lk=Math.max(-1,Math.min(1,look||0)),fx=lk*9,sq=1-Math.abs(lk)*.12;
 g.save();g.translate(0,-204);g.rotate(lk*.08);g.scale(sq,1);
 g.beginPath();g.moveTo(-26,22);g.quadraticCurveTo(-34,-10,-18,-26);g.quadraticCurveTo(0,-34,18,-26);g.quadraticCurveTo(34,-10,26,22);g.quadraticCurveTo(0,30,-26,22);g.closePath();flcF(g,flcLin(g,-30,-30,30,26,['#e0c890','#c8a868','#8a6e40']),2.8);
 g.strokeStyle='#8a6e4066';g.lineWidth=1;for(let i=-24;i<=24;i+=6){g.beginPath();g.moveTo(i,-24);g.lineTo(i*1.05,24);g.stroke()}
 g.beginPath();g.moveTo(-24,16);g.quadraticCurveTo(0,24,24,16);g.strokeStyle='#8a5a2a';g.lineWidth=3;g.stroke();
 /* face */
 g.save();g.translate(fx,0);
 for(const ex of[-10,10]){g.beginPath();g.arc(ex,-4,5.6,0,TAU);flcF(g,'#2a1a10',2);if(o.glint>0){g.save();g.globalCompositeOperation='lighter';flcGlow(g,ex,-4,16,'#ffd27a',o.glint);g.restore();g.fillStyle='#ffe9a8';g.beginPath();g.arc(ex,-4,2.4*o.glint+.4,0,TAU);g.fill()}
  g.strokeStyle='#8a7a5a';g.lineWidth=1.2;g.beginPath();g.moveTo(ex-3,-7);g.lineTo(ex+3,-1);g.moveTo(ex+3,-7);g.lineTo(ex-3,-1);g.stroke()}
 g.beginPath();g.moveTo(-12,9);g.quadraticCurveTo(0,15,12,9);g.strokeStyle=FLO;g.lineWidth=2.4;g.stroke();g.strokeStyle='#2a1a10';g.lineWidth=1.4;for(let i=-9;i<=9;i+=4.5){g.beginPath();g.moveTo(i,9.5+Math.cos(i/12)*2);g.lineTo(i+.5,14+Math.cos(i/12)*1.5);g.stroke()}
 g.fillStyle='#d8743a';g.beginPath();g.moveTo(-2,1);g.lineTo(3,1);g.lineTo(lk*3,6);g.closePath();g.fill();g.restore();
 /* floppy straw hat with a leaf in the band */
 g.beginPath();g.ellipse(0,-22,46,9,0,0,TAU);flcF(g,flcLin(g,0,-30,0,-14,['#d8b05a','#a87a30']),2.6);
 g.beginPath();g.moveTo(-22,-24);g.quadraticCurveTo(-24,-52,0,-54);g.quadraticCurveTo(24,-52,22,-24);g.closePath();flcF(g,flcLin(g,0,-54,0,-24,['#e8c46a','#b88a3a']),2.6);
 g.beginPath();g.moveTo(-22,-30);g.quadraticCurveTo(0,-26,22,-30);g.lineTo(22,-24);g.quadraticCurveTo(0,-20,-22,-24);g.closePath();flcF(g,'#6a2a1e',2);
 flcLeaf(g,16,-34,16,.7,1,1);
 g.restore();g.restore()}

/* ---------- crows ---------- */
/* (x,y) centre, s scale, flap -1..1 (wing angle), dir 1 = facing right; perched folds the wings */
function flcCrow(g,x,y,s,flap,dir,perched){g.save();g.translate(x,y);g.scale(s*(dir<0?-1:1),s);g.lineJoin='round';const B='#0c0a14',S2='#2a2a4a';
 if(perched){g.beginPath();g.moveTo(-14,2);g.lineTo(-26,10);g.lineTo(-24,4);g.lineTo(-30,6);g.lineTo(-16,-2);g.closePath();flcF(g,B,1.6);
  g.beginPath();g.ellipse(-2,0,15,9,-.25,0,TAU);flcF(g,B,1.6);g.beginPath();g.moveTo(-10,-4);g.quadraticCurveTo(0,-8,8,0);g.strokeStyle=S2;g.lineWidth=1.4;g.stroke();
  g.strokeStyle='#3a3020';g.lineWidth=1.6;g.beginPath();g.moveTo(-2,8);g.lineTo(-3,13);g.moveTo(3,7);g.lineTo(3,13);g.stroke()}
 else{const a=(flap||0),wing=(c,dy,k)=>{g.beginPath();g.moveTo(-6,dy);g.quadraticCurveTo(-2,dy-24*a*k-3,-10,dy-34*a*k);g.lineTo(-16,dy-26*a*k);g.lineTo(-22,dy-30*a*k+2);g.lineTo(-24,dy-20*a*k+4);g.quadraticCurveTo(-14,dy-4,6,dy+1);g.closePath();flcF(g,c,1.6)};
  wing('#1a1826',-2,.8);g.beginPath();g.moveTo(-12,0);g.lineTo(-25,5);g.lineTo(-23,-2);g.closePath();flcF(g,B,1.4);g.beginPath();g.ellipse(0,0,13,7,-.08,0,TAU);flcF(g,B,1.6);wing(B,1,1)}
 g.beginPath();g.arc(12,-6,6.4,0,TAU);flcF(g,B,1.6);g.beginPath();g.moveTo(16,-8);g.lineTo(25,-5);g.lineTo(16,-3);g.closePath();flcF(g,'#3a3530',1.2);
 g.fillStyle='#ffd27a';g.beginPath();g.arc(13.4,-7.4,1.4,0,TAU);g.fill();g.restore()}

/* ---------- the harvest moon (orange) and the gold moon, baked once ---------- */
const FLC_MOON={};
function flcMoonS(kind){if(FLC_MOON[kind])return FLC_MOON[kind];const R=110,P2=150,c=flcCv((R+P2)*2,(R+P2)*2),g=c.getContext('2d'),cx=R+P2;const gold=kind==='gold';
 const hq=g.createRadialGradient(cx,cx,R*.8,cx,cx,R+P2);hq.addColorStop(0,gold?'#ffd45a88':'#ff9a4066');hq.addColorStop(.35,gold?'#ffc04a30':'#ff8a3a22');hq.addColorStop(1,'#ff8a3a00');g.fillStyle=hq;g.fillRect(0,0,c.width,c.height);
 const q=g.createRadialGradient(cx-R*.3,cx-R*.35,R*.1,cx,cx,R);if(gold){q.addColorStop(0,'#fffbe0');q.addColorStop(.55,'#ffe07a');q.addColorStop(1,'#e8a020')}else{q.addColorStop(0,'#ffe0a8');q.addColorStop(.55,'#f8a850');q.addColorStop(1,'#d8702a')}
 g.fillStyle=q;g.beginPath();g.arc(cx,cx,R,0,TAU);g.fill();
 g.fillStyle=gold?'#e8a82a55':'#c8602a55';for(const [dx,dy,r] of[[-34,-28,22],[30,18,28],[24,-44,13],[-20,36,16],[52,-8,10],[-56,8,12]]){g.beginPath();g.arc(cx+dx,cx+dy,r,0,TAU);g.fill()}
 g.fillStyle='#ffffff22';for(const [dx,dy,r] of[[-36,-30,18],[28,15,23]]){g.beginPath();g.arc(cx+dx-2,cx+dy-2,r*.7,0,TAU);g.fill()}
 g.strokeStyle=gold?'#fff4c0':'#ffd8a0';g.lineWidth=3;g.globalAlpha=.6;g.beginPath();g.arc(cx,cx,R-1.5,0,TAU);g.stroke();g.globalAlpha=1;
 return FLC_MOON[kind]=c}
function flcMoon(g,x,y,kind,a,sc){if(a<=0)return;const c=flcMoonS(kind),s=(sc||1);const ga=g.globalAlpha;g.globalAlpha=ga*Math.min(1,a);g.drawImage(c,x-c.width/2*s,y-c.height/2*s,c.width*s,c.height*s);g.globalAlpha=ga}

/* ---------- coins, acorns, the XP star ---------- */
let FLC_COIN=null;
function flcCoinS(){if(FLC_COIN)return FLC_COIN;const c=flcCv(48,48),g=c.getContext('2d');g.translate(24,24);g.beginPath();g.arc(0,0,20,0,TAU);flcF(g,flcLin(g,-20,-20,20,20,['#fff6c0','#ffd45a','#d8901a','#9a6012']),3);
 g.beginPath();g.arc(0,0,13,0,TAU);g.strokeStyle='#9a6012';g.lineWidth=2;g.stroke();g.fillStyle='#fff8d8';g.font='700 18px Georgia,serif';g.textAlign='center';g.textBaseline='middle';g.fillText('★',0,1);return FLC_COIN=c}
function flcCoin(g,x,y,r,spin){const c=flcCoinS(),k=Math.max(.15,Math.abs(Math.cos(spin||0)));g.save();g.translate(x,y);g.scale(k,1);g.drawImage(c,-r,-r,r*2,r*2);g.restore()}
function flcAcorn(g,x,y,s,rot){g.save();g.translate(x,y);g.rotate(rot||0);g.scale(s,s);g.lineJoin='round';
 g.beginPath();g.moveTo(-14,-2);g.quadraticCurveTo(-16,20,0,30);g.quadraticCurveTo(16,20,14,-2);g.closePath();flcF(g,flcLin(g,-14,0,14,24,['#e8a050','#b8642a','#7a3a14']),2.6);
 g.fillStyle='#ffffff40';g.beginPath();g.ellipse(-6,8,3,8,-.2,0,TAU);g.fill();g.fillStyle='#5a2a0e';g.beginPath();g.arc(0,29,2.2,0,TAU);g.fill();
 g.beginPath();g.moveTo(-17,0);g.quadraticCurveTo(-18,-16,0,-17);g.quadraticCurveTo(18,-16,17,0);g.quadraticCurveTo(0,6,-17,0);g.closePath();flcF(g,flcLin(g,0,-17,0,4,['#a87a4a','#7a5230','#4a2e16']),2.6);
 g.strokeStyle='#3a2210';g.lineWidth=1.1;for(let i=-12;i<=12;i+=5){g.beginPath();g.moveTo(i-3,-10+Math.abs(i)*.3);g.lineTo(i+3,-3);g.moveTo(i+3,-10+Math.abs(i)*.3);g.lineTo(i-3,-3);g.stroke()}
 g.beginPath();g.moveTo(-1.5,-16);g.quadraticCurveTo(-2,-24,3,-26);g.strokeStyle=FLO;g.lineWidth=4;g.stroke();g.strokeStyle='#6a4220';g.lineWidth=2;g.stroke();g.restore()}
function flcCoinPile(g,x,y,s,t){g.save();g.translate(x,y);g.scale(s,s);const L=[[-34,0],[34,0],[-18,-4],[18,-4],[0,-6],[-26,-18],[26,-18],[-8,-22],[10,-22],[0,-38],[-16,-36],[16,-36],[0,-52]];
 for(const [cx,cy] of L){g.save();g.translate(cx,cy);g.scale(1,.5);g.beginPath();g.arc(0,0,20,0,TAU);flcF(g,flcLin(g,-20,-20,20,20,['#fff6c0','#ffd45a','#c8841a']),3);g.beginPath();g.arc(0,0,13,0,TAU);g.strokeStyle='#9a6012';g.lineWidth=2;g.stroke();g.restore()}
 flcCoin(g,30,-52,18,(t||0)*2);flcCoin(g,-32,-46,15,(t||0)*2+1.4);g.restore()}
function flcXpStar(g,x,y,s,t){g.save();g.translate(x,y);g.scale(s,s);g.rotate(Math.sin((t||0)*.8)*.08);g.beginPath();for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,r=i%2?26:60;g.lineTo(Math.cos(a)*r,Math.sin(a)*r)}g.closePath();
 flcF(g,flcLin(g,-50,-60,50,50,['#e8fbff','#7ad8ff','#3a8ae0','#2a4aa8']),4);g.beginPath();for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,r=i%2?14:34;g.lineTo(Math.cos(a)*r,Math.sin(a)*r-2)}g.closePath();g.fillStyle='#ffffff55';g.fill();
 g.font='800 34px Poppins,sans-serif';g.textAlign='center';g.textBaseline='middle';g.lineWidth=7;g.strokeStyle=FLO;g.strokeText('XP',0,4);g.fillStyle='#fff';g.fillText('XP',0,4);g.restore()}

/* ---------- the cornucopia ---------- */
/* a woven horn whose mouth opens to the right at (x,y); s scale; full 0..1 how much of the bounty shows */
function flcHorn(g,x,y,s,t,full){g.save();g.translate(x,y);g.scale(s,s);g.lineJoin='round';g.lineCap='round';
 const pts=[];for(let i=0;i<=24;i++){const u=i/24,a=-.4+u*2.6;pts.push([-150+u*150+Math.sin(u*Math.PI)*8,-30*Math.sin(u*2.6)+Math.cos(a)*10*(1-u)-u*u*10])}
 const L=[],R=[];for(let i=0;i<pts.length;i++){const a=pts[Math.max(0,i-1)],b=pts[Math.min(pts.length-1,i+1)];let dx=b[0]-a[0],dy=b[1]-a[1];const d=Math.hypot(dx,dy)||1,w=4+Math.pow(i/24,1.6)*52;L.push([pts[i][0]-dy/d*w,pts[i][1]+dx/d*w]);R.unshift([pts[i][0]+dy/d*w,pts[i][1]-dx/d*w])}
 const sh=L.concat(R);g.beginPath();sh.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.closePath();flcF(g,flcLin(g,0,-60,0,40,['#f0c878','#c8904a','#8a5424']),3);
 g.save();g.clip();g.strokeStyle='#7a4a1e';g.lineWidth=2.2;for(let i=2;i<24;i+=2){const p=pts[i],w=4+Math.pow(i/24,1.6)*52;g.beginPath();g.ellipse(p[0],p[1],3+w*.12,w,-.1,0,TAU);g.stroke()}
 g.strokeStyle='#fff0c066';g.lineWidth=1.2;for(let i=3;i<24;i+=2){const p=pts[i],w=4+Math.pow(i/24,1.6)*52;g.beginPath();g.ellipse(p[0]-2,p[1],2+w*.1,w*.9,-.1,Math.PI*1.1,Math.PI*1.6);g.stroke()}g.restore();
 /* the bounty spilling from the mouth */
 const m=pts[24];g.save();g.translate(m[0],m[1]);
 g.beginPath();g.ellipse(0,0,14,54,-.1,0,TAU);flcF(g,'#3a1e0c',3);
 if(full>0){g.globalAlpha=Math.min(1,full*1.4);
  const fruit=(fx,fy,r,c,st)=>{g.beginPath();g.arc(fx,fy,r,0,TAU);flcF(g,flcLin(g,fx-r,fy-r,fx+r,fy+r,[shade(c,.3),c,shade(c,-.35)]),2.4);g.fillStyle='#ffffff44';g.beginPath();g.arc(fx-r*.35,fy-r*.35,r*.28,0,TAU);g.fill();if(st){g.strokeStyle='#4a2e16';g.lineWidth=2.4;g.beginPath();g.moveTo(fx,fy-r);g.lineTo(fx+2,fy-r-6);g.stroke()}};
  for(const [gx,gy] of[[18,-34],[26,-26],[16,-24],[24,-16],[32,-20]]){g.beginPath();g.arc(gx,gy,6.4,0,TAU);flcF(g,flcLin(g,gx-6,gy-6,gx+6,gy+6,['#c8a0f0','#7a3ab8','#3a1a6a']),1.8)}
  fruit(22,6,15,'#d8302a',1);fruit(40,-6,12,'#f0a020',1);flcPumpkin(g,30,32,16,{c:'#ec7a1e'});fruit(6,-14,11,'#7ab83a',1);
  for(let i=0;i<5;i++)flcCoin(g,44+i*6,22+i*9-(i%2)*6,9,t*3+i);
  g.save();g.translate(4,-44);g.rotate(-.8);for(let k=0;k<4;k++){g.beginPath();g.ellipse(-2,-k*6-3,2.6,4,-.35,0,TAU);g.ellipse(2,-k*6-3,2.6,4,.35,0,TAU);flcF(g,'#e8c060',1.2)}g.restore();g.globalAlpha=1}
 g.restore();g.restore()}

/* ---------- the feathered turkey silhouette that fans across the moon (Mythic) ---------- */
/* (cx,cy) = the root of the fan, R = feather length, u 0..1 how far the fan has opened, al alpha */
function flcTurkey(g,cx,cy,R,u,al,t){if(al<=0||u<=0)return;g.save();g.translate(cx,cy);g.globalAlpha=al;g.lineJoin='round';const N=13;
 for(let i=0;i<N;i++){const k=Math.abs(i-(N-1)/2)/((N-1)/2),open=Math.max(0,Math.min(1,(u*1.35-k*.35))),a=-Math.PI/2+(i-(N-1)/2)/((N-1)/2)*1.32*open+Math.sin(t*1.4+i)*.012;if(open<=0)continue;
  g.save();g.rotate(a+Math.PI/2);const L=R*(.86+.14*(1-k))*(.6+.4*open),w=R*.13;
  g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(-w*1.2,-L*.55,-w,-L*.88);g.quadraticCurveTo(0,-L*1.04,w,-L*.88);g.quadraticCurveTo(w*1.2,-L*.55,0,0);g.closePath();g.fillStyle='#1c0e08';g.fill();g.strokeStyle='#ffd45a';g.lineWidth=2.4;g.stroke();
  g.strokeStyle='#ffd45a88';g.lineWidth=2;for(const f of[.66,.78]){g.beginPath();g.moveTo(-w*.95,-L*f);g.quadraticCurveTo(0,-L*f-6,w*.95,-L*f);g.stroke()}
  g.strokeStyle='#ffe9a855';g.lineWidth=1.2;g.beginPath();g.moveTo(0,-4);g.lineTo(0,-L*.9);g.stroke();g.restore()}
 /* the body in front of the fan: round breast, neck, head with a snood */
 const bu=Math.min(1,u*1.6);g.globalAlpha=al*bu;g.fillStyle='#1c0e08';g.strokeStyle='#ffd45a';g.lineWidth=2.4;
 g.beginPath();g.ellipse(0,R*.08,R*.3,R*.26,0,0,TAU);g.fill();g.stroke();
 g.beginPath();g.moveTo(-R*.06,-R*.12);g.quadraticCurveTo(-R*.14,-R*.3,-R*.04,-R*.42);g.quadraticCurveTo(R*.06,-R*.48,R*.08,-R*.36);g.quadraticCurveTo(R*.08,-R*.24,R*.08,-R*.12);g.closePath();g.fill();g.stroke();
 g.beginPath();g.moveTo(R*.05,-R*.4);g.lineTo(R*.15,-R*.37);g.lineTo(R*.06,-R*.34);g.closePath();g.fillStyle='#ffd45a';g.fill();
 g.beginPath();g.moveTo(R*.04,-R*.38);g.quadraticCurveTo(R*.12,-R*.3,R*.08,-R*.24);g.strokeStyle='#ff6a4a';g.lineWidth=3;g.stroke();
 g.fillStyle='#ffe9a8';g.beginPath();g.arc(R*.0,-R*.4,2.2,0,TAU);g.fill();g.restore()}

/* ---------- corn stalks (painted into the baked rows) ---------- */
function flcCorn(g,x,y,h,lean,R,tone){const C=tone||{st:'#4a5a2e',lf:'#5a6a32',dr:'#8a7a44',ed:'#c8b87a'};g.save();g.translate(x,y);g.lineJoin='round';g.lineCap='round';
 const tx=lean*h,top=[tx,-h];g.beginPath();g.moveTo(-2.6,0);g.quadraticCurveTo(tx*.4-2,-h*.5,tx-1.2,-h);g.lineTo(tx+1.2,-h);g.quadraticCurveTo(tx*.4+2,-h*.5,2.6,0);g.closePath();g.fillStyle=C.st;g.fill();g.strokeStyle=FLO;g.lineWidth=1.4;g.stroke();
 const n=4+(R()*3|0);for(let i=0;i<n;i++){const u=.18+i/n*.72,px=tx*u*u*.9,py=-h*u,sd=i%2?1:-1,len=h*(.2+R()*.12),dry=R()<.35;
  g.beginPath();g.moveTo(px,py);g.quadraticCurveTo(px+sd*len*.42,py-len*.44,px+sd*len,py+len*.2);g.quadraticCurveTo(px+sd*len*.4,py-len*.3,px,py+4);g.closePath();g.fillStyle=dry?C.dr:C.lf;g.fill();g.strokeStyle=FLO;g.lineWidth=1.1;g.stroke();
  g.strokeStyle=C.ed;g.globalAlpha=.35;g.lineWidth=1;g.beginPath();g.moveTo(px,py);g.quadraticCurveTo(px+sd*len*.42,py-len*.4,px+sd*len*.92,py+len*.14);g.stroke();g.globalAlpha=1}
 if(h>90){const eu=.5+R()*.12,ex=tx*eu*eu*.9,ey=-h*eu;g.save();g.translate(ex,ey);g.rotate(-.35+lean);g.beginPath();g.ellipse(5,-10,5,13,.2,0,TAU);g.fillStyle='#d8b050';g.fill();g.strokeStyle=FLO;g.lineWidth=1.2;g.stroke();
  g.beginPath();g.moveTo(0,4);g.quadraticCurveTo(-4,-12,4,-24);g.quadraticCurveTo(1,-8,8,4);g.closePath();g.fillStyle=C.dr;g.fill();g.stroke();g.restore()}
 g.strokeStyle='#c8a85a';g.lineWidth=1.2;for(let i=-2;i<=2;i++){g.beginPath();g.moveTo(top[0],top[1]);g.lineTo(top[0]+i*5+lean*8,top[1]-10-Math.abs(i)*-2);g.stroke()}g.restore()}

/* ---------- the baked night: sky, stars, hills, a barn and silo, a fence, two corn rows and the pumpkin patch ----------
   Three layers to stamp per frame: the sky (0..600), the land in front of the moon (430..900: hills, barn, fence, the back corn and the
   patch, merged) and the tall corn at both edges (two 340 px strips that sway). */
let FLC_BK=null;
function flcBake(k){k=k||1;if(FLC_BK&&FLC_BK.k===k)return FLC_BK;const R=flcRnd(1104);const mk=(w,h)=>{const c=flcCv(w*k,h*k),g=c.getContext('2d');g.scale(k,k);return[c,g]};
 /* sky */
 const [bg,g]=mk(W,600);let q=g.createLinearGradient(0,0,0,640);q.addColorStop(0,'#070820');q.addColorStop(.42,'#191446');q.addColorStop(.78,'#3e2048');q.addColorStop(1,'#7a3a2a');g.fillStyle=q;g.fillRect(0,0,W,600);
 for(let i=0;i<170;i++){const x=R()*W,y=R()*460,s=R()<.08?2.4:R()*1.4+.5;g.globalAlpha=.3+R()*.6;g.fillStyle=R()<.15?'#ffe8c0':'#e8eaff';g.fillRect(x,y,s,s)}g.globalAlpha=1;
 /* a thin band of cloud */
 g.fillStyle='#2a1e4a88';for(const [cx,cy,rx] of[[260,190,180],[420,178,120],[1360,150,150],[1480,166,110],[880,120,90]]){g.beginPath();g.ellipse(cx,cy,rx,13,0,0,TAU);g.ellipse(cx+rx*.3,cy-8,rx*.55,10,0,0,TAU);g.fill()}
 FLC_BK={k,bg};
 /* hills (drawn in their own layer so the rising moon can sit behind them) */
 const [hl,h]=mk(W,470);h.translate(0,-430);
 h.fillStyle='#24183e';h.beginPath();h.moveTo(0,560);for(let x=0;x<=W;x+=40)h.lineTo(x,548-Math.sin(x*.004+1.2)*34-Math.sin(x*.013)*10);h.lineTo(W,H);h.lineTo(0,H);h.closePath();h.fill();
 h.fillStyle='#1a1230';h.beginPath();h.moveTo(0,600);for(let x=0;x<=W;x+=40)h.lineTo(x,600-Math.sin(x*.006+.3)*28-Math.sin(x*.021+2)*8);h.lineTo(W,H);h.lineTo(0,H);h.closePath();h.fill();
 /* a distant tree line */
 h.fillStyle='#140e26';for(let x=-10;x<W;x+=14+R()*10){const yy=592-Math.sin(x*.006+.3)*28,r=8+R()*10;h.beginPath();h.arc(x,yy-r*.6,r,0,TAU);h.fill()}
 /* the barn and the silo on the hill, a lit window */
 h.save();h.translate(300,560);h.fillStyle='#2e1626';h.beginPath();h.moveTo(-60,0);h.lineTo(-60,-46);h.lineTo(-40,-70);h.lineTo(0,-84);h.lineTo(40,-70);h.lineTo(60,-46);h.lineTo(60,0);h.closePath();h.fill();h.strokeStyle=FLO;h.lineWidth=2;h.stroke();
 h.fillStyle='#3e1e2e';h.fillRect(-18,-36,36,36);h.strokeStyle='#5a3040';h.lineWidth=2;h.beginPath();h.moveTo(-18,-36);h.lineTo(18,0);h.moveTo(18,-36);h.lineTo(-18,0);h.stroke();
 h.fillStyle='#ffc86a';h.fillRect(-8,-62,16,12);h.fillStyle='#ffc86a44';h.beginPath();h.arc(0,-56,26,0,TAU);h.fill();
 h.fillStyle='#24142a';h.fillRect(70,-110,34,110);h.beginPath();h.arc(87,-110,17,Math.PI,0);h.fill();h.strokeStyle=FLO;h.lineWidth=2;h.strokeRect(70,-110,34,110);h.restore();
 /* fence posts along the field */
 h.strokeStyle='#2a1a30';h.lineWidth=4;for(let x=470;x<1180;x+=46){const yy=604-Math.sin(x*.006+.3)*20;h.beginPath();h.moveTo(x,yy+18);h.lineTo(x,yy-10);h.stroke()}
 h.lineWidth=2.4;h.beginPath();for(let x=470;x<1180;x+=8){const yy=600-Math.sin(x*.006+.3)*20;x===470?h.moveTo(x,yy):h.lineTo(x,yy)}h.stroke();
 FLC_BK.hills=hl;
 /* back corn rows (left and right of the patch), moonlit */
 const [cb,c2]=mk(W,330);const tb={st:'#3a4626',lf:'#46522a',dr:'#7a6a3c',ed:'#d8c890'};
 for(let x=-20;x<W+20;x+=11+R()*7){if(x>560&&x<1040)continue;const hh=150+R()*90+(Math.abs(x-800)>500?40:0);flcCorn(c2,x,326-R()*16,hh,(R()-.5)*.12,R,tb)}
 c2.fillStyle='#0a0618';c2.globalAlpha=.25;c2.fillRect(0,0,W,330);c2.globalAlpha=1;FLC_BK.cornB=cb;FLC_BK.cornBy=470;
 /* the pumpkin patch: soil, vines, leaves, pumpkins in the moonlight */
 const [pt,p]=mk(W,330);q=p.createLinearGradient(0,0,0,330);q.addColorStop(0,'#2a1a22');q.addColorStop(.3,'#24161c');q.addColorStop(1,'#0e0810');p.fillStyle=q;p.beginPath();p.moveTo(0,40);for(let x=0;x<=W;x+=50)p.lineTo(x,30+Math.sin(x*.01)*8);p.lineTo(W,330);p.lineTo(0,330);p.closePath();p.fill();
 /* a trodden path up to the chest */
 p.fillStyle='#3a2a2a';p.beginPath();p.moveTo(700,36);p.lineTo(900,36);p.lineTo(1040,330);p.lineTo(560,330);p.closePath();p.fill();p.fillStyle='#4a3632';p.beginPath();p.moveTo(740,36);p.lineTo(860,36);p.lineTo(940,330);p.lineTo(660,330);p.closePath();p.fill();
 p.strokeStyle='#2e4a24';p.lineWidth=3;for(let i=0;i<26;i++){const x=R()*W,y=50+R()*260;if(x>600&&x<1000&&y<200)continue;p.beginPath();p.moveTo(x,y);p.bezierCurveTo(x+30,y-20,x+60,y+16,x+90+R()*40,y-6);p.stroke()}
 const pk=[];for(let i=0;i<24;i++){const x=R()*W,y=60+R()*240;if(Math.abs(x-800)<230&&y<240)continue;pk.push([x,y,10+R()*14+y*.06])}pk.sort((a,b)=>a[1]-b[1]);
 for(const [x,y,r] of pk){for(let j=0;j<3;j++){const lx=x+(R()-.5)*r*4,ly=y+r*.4+(R()-.3)*r;p.save();p.translate(lx,ly);p.rotate(R()*TAU);p.globalAlpha=.85;p.beginPath();p.ellipse(0,0,r*.7,r*.45,0,0,TAU);p.fillStyle=R()<.5?'#2e4a24':'#3a5a2a';p.fill();p.strokeStyle=FLO;p.lineWidth=1.2;p.stroke();p.restore()}
  flcPumpkin(p,x,y,r,{c:shade(R()<.2?'#d8a040':R()<.5?'#e8741c':'#d8641a',-.3)})}
 p.globalAlpha=1;
 /* merge the corn and the patch into the land layer */
 h.setTransform(1,0,0,1,0,0);h.drawImage(cb,0,40*k,W*k,330*k);h.drawImage(pt,0,170*k,W*k,330*k);FLC_BK.low=hl;delete FLC_BK.hills;delete FLC_BK.cornB;
 /* front corn: tall stalks framing both edges, kept as two strips */
 const [cf,f]=mk(W,520);const tf={st:'#2a3420',lf:'#323e22',dr:'#5a4a28',ed:'#b8a870'};
 for(let x=-30;x<W+30;x+=13+R()*8){if(x>170&&x<1430)continue;const hh=360+R()*120;flcCorn(f,x,518-R()*10,hh,(x<800?1:-1)*(.04+R()*.08),R,tf)}
 const [cl,l1]=mk(340,520),[cr,l2]=mk(340,520);l1.setTransform(1,0,0,1,0,0);l1.drawImage(cf,0,0,340*k,520*k,0,0,340*k,520*k);l2.setTransform(1,0,0,1,0,0);l2.drawImage(cf,1260*k,0,340*k,520*k,0,0,340*k,520*k);
 FLC_BK.cornL=cl;FLC_BK.cornR=cr;FLC_BK.cornFy=380;
 return FLC_BK}
/* stamp a baked strip with a wind skew pivoting on its base line */
function flcSkew(g,img,x,y,w,h,sk){g.save();g.transform(1,0,-sk,1,sk*(y+h),0);g.drawImage(img,x,y,w,h);g.restore()}
