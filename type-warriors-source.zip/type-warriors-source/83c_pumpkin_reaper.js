/* ---------- 7.3 Trick-or-Treat exclusive: the Pumpkin Reaper (Mythic armor) ----------
   Sold only at the Candy Stall for candy corn. It is NOT in HWG_ID, so Graveyard crates never drop it.
   Carries Soul Harvest like the Reaper's Shroud (ab:'harvest', see 84g_gear_ability.js). */
AR.hwpreap={n:'Pumpkin Reaper',r:'Mythic',d:'+4 max HP, 3 shields, foes 12% slower, +25% score',hp:4,sh:3,sl:.88,sc:1.25,m:'#5a2c14',dk:'#120804',tr:'#ff8a22',acc:'#ffa030',base:'plate',mythic:2,tier:4,hw:1,w:1,ab:'pcurse',tt:1};
AR.hwpreap.d+='. Ability: Soul Harvest';
AR.hwpreap.col='#ff9a2e';
AK.hwpreap={mat:'plate',leg:'plate',helm:'pumpkin',crest:'',pauld:'spike',skirt:'rag',cape:'tatter',cc:'#26102e',emb:'jack',embc:'#ffa030',fx:'',aura:'hwpreap',tier:4};
/* aura: a furnace glow, flames licking the boots, embers, and bats and tiny jack-o'-lanterns circling the warrior */
HWA.hwpreap=(g,K,c,post,hx,hy,orb)=>{const {t}=c,fl=.8+.2*Math.sin(t*6)+.08*Math.sin(t*15);
 if(!post){arSmoke(g,t,'#2a0c00',.6);glow(g,-4,-96,110,'#ff7a1a'+hwA(.26*fl));glow(g,-4,-8,60,'#ff5a10'+hwA(.3*fl));
  g.save();g.globalCompositeOperation='lighter';
  for(let i=0;i<9;i++){const x=-38+i*9.5+Math.sin(t*2+i)*2,hgt=14+10*Math.abs(Math.sin(t*5+i*1.9))+(i%3)*4;
   g.fillStyle=i%2?'#ff9a2a66':'#ff5a1a55';g.beginPath();g.moveTo(x-5,-2);g.quadraticCurveTo(x-2+Math.sin(t*7+i)*3,-hgt*.6,x+Math.sin(t*6+i)*2,-hgt);g.quadraticCurveTo(x+3,-hgt*.5,x+5,-2);g.closePath();g.fill()}
  for(let i=0;i<14;i++){const u=(t*.45+i*.137)%1,x=Math.sin(i*5.3+t*.6)*34,y=-6-u*150;g.globalAlpha=Math.sin(u*Math.PI)*.85;ell(g,x,y,1.3+(i%3)*.5,1.3+(i%3)*.5,i%2?'#ffd070':'#ff8a2a')}
  g.restore();g.globalAlpha=1}
 orb(3,-2,-166,60,12,1.05,(x,y,i,a,z)=>{arBat(g,x,y,.95+z*.18,Math.sin(t*15+i*2.2),'#d8601a','#fff0a0','#000000')});
 orb(3,-2,-68,44,13,-.8,(x,y,i,a,z)=>{hwPumpkin(g,x,y,4.6+z*1.1,t+i*1.7)});
 };

/* ---------- the menacing gourd helm: slanted burning eyes, a fanged grin, iron horns and a brow plate ---------- */
HWH.pumpkin2=(g,K,c,hx,hy)=>{const {t,T}=c,P='#e0661a',f=.82+.18*Math.sin(t*9)+.07*Math.sin(t*23),fy=-1.2;
 /* spiked iron gorget */
 arBev(g,[hx-13,hy+12,hx+16,hy+13,hx+17,hy+25,hx-11,hy+25],'#1c100c',{ow:1.2,edge:'#ff8a22',ew:1.2});
 for(const rx of[-9,-1,7,14])poly(g,[hx+rx-2.4,hy+13,hx+rx,hy+8.4,hx+rx+2.4,hy+13],'#2a1810','#000b',.9);
 glow(g,hx+4,hy,46,'#ff6a10'+hwA(.4*f));
 /* iron horns sweeping back */
 arTusk(g,hx-7,hy-12,-2.5,34,1.05,8,'#1a0e0a',{});arTusk(g,hx+3,hy-15.5,-2.2,30,.95,7.4,'#2a1810',{});
 /* gourd lobes */
 ell(g,hx-11,hy+.6,6.6,16.4,shade(P,-.46));ell(g,hx-6,hy+.4,9,17.6,shade(P,-.26));ell(g,hx+10,hy+.8,7.8,16.4,shade(P,-.2));
 {const old=OL;OL=1.2;ell(g,hx+1,hy+.4,10.6,17.6,rgr(g,hx-3,hy-6,1,22,shade(P,.32),shade(P,-.1)));OL=old}
 g.strokeStyle=shade(P,-.55)+'cc';g.lineWidth=1.1;for(const d of[-6.4,0,6.8]){g.beginPath();g.moveTo(hx+1+d*.4,hy-16.6);g.quadraticCurveTo(hx+1+d*1.7,hy,hx+1+d*.5,hy+17.4);g.stroke()}
 /* glowing cracks */
 g.save();g.globalCompositeOperation='lighter';g.strokeStyle='#ffb040'+hwA(.55*f);g.lineWidth=1;for(const [x,y,dx,dy] of[[-4,-14,-3,6],[10,-12,3,5],[12,6,-3,5],[-8,8,3,6]]){g.beginPath();g.moveTo(hx+x,hy+y);g.lineTo(hx+x+dx,hy+y+dy*.5);g.lineTo(hx+x+dx*.4,hy+y+dy);g.stroke()}g.restore();
 /* stem, curled, with a little flame */
 arBev(g,[hx-3,hy-16.4,hx-4,hy-23,hx+1,hy-27,hx+6,hy-25,hx+4.4,hy-16.8],'#3a2a14',{sm:1,ow:1.1});
 g.strokeStyle='#5a4220';g.lineWidth=1.6;g.beginPath();g.moveTo(hx+4,hy-23);g.bezierCurveTo(hx+11,hy-28,hx+14,hy-19,hx+9,hy-18);g.stroke();
 g.save();g.globalCompositeOperation='lighter';{const w=Math.sin(t*8)*2;g.fillStyle='#ff7a1a99';g.beginPath();g.moveTo(hx-2,hy-27);g.quadraticCurveTo(hx-5+w,hy-34,hx+1+w,hy-42);g.quadraticCurveTo(hx+5,hy-33,hx+4,hy-27);g.fill();g.fillStyle='#ffd070cc';g.beginPath();g.moveTo(hx,hy-27);g.quadraticCurveTo(hx-1+w*.6,hy-32,hx+1.4+w*.6,hy-37);g.quadraticCurveTo(hx+3,hy-31,hx+3,hy-27);g.fill()}g.restore();
 /* burning eyes: narrow, slanted, furious */
 g.save();glow(g,hx+10,hy+fy-1.4,18,'#ff3a08'+hwA(.85*f));glow(g,hx-2,hy+fy-1.4,14,'#ff3a08'+hwA(.7*f));
 g.fillStyle=f>.9?'#fff2b0':'#ffd040';g.strokeStyle='#3a0a02';g.lineWidth=.9;
 g.beginPath();g.moveTo(hx+4,hy+1.4);g.lineTo(hx+17,hy-8.4);g.lineTo(hx+14.6,hy-.2);g.closePath();g.fill();g.stroke();
 g.beginPath();g.moveTo(hx+3,hy+1.2);g.lineTo(hx-8.2,hy-7.6);g.lineTo(hx-5.8,hy-.4);g.closePath();g.fill();g.stroke();
 g.fillStyle='#ff4a10';ell(g,hx+11.4,hy-2.4,1.5,1.9,'#ff3a08');ell(g,hx-3.2,hy-2.2,1.2,1.6,'#ff3a08');
 g.restore();
 /* brow plates: slanted, sitting a clear gap above each eye */
 poly(g,[hx+3.4,hy-3.6,hx+16.6,hy-14,hx+16.6,hy-11,hx+3.4,hy-.8],'#1a0e0a','#ff8a22',1);
 poly(g,[hx+2.8,hy-3.4,hx-8.4,hy-12,hx-8.4,hy-9.2,hx+2.8,hy-.6],'#120a07','#ff8a22',1);
 /* nose slit and the wide, fanged grin */
 g.fillStyle='#ffb020';g.strokeStyle='#3a0a02';g.lineWidth=.9;g.beginPath();g.moveTo(hx+4.6,hy+2.2);g.lineTo(hx+1.8,hy+7);g.lineTo(hx+7,hy+7);g.closePath();g.fill();g.stroke();
 g.save();glow(g,hx+4,hy+11,15,'#ff5a10'+hwA(.5*f));
 const UP=u=>[hx+(1-u)*(1-u)*-9.6+2*u*(1-u)*4+u*u*16.6,hy+(1-u)*(1-u)*6.6+2*u*(1-u)*11+u*u*5.4],LO=u=>[hx+(1-u)*(1-u)*-9.6+2*u*(1-u)*3+u*u*16.6,hy+(1-u)*(1-u)*6.6+2*u*(1-u)*24+u*u*5.4];
 g.fillStyle=f>.9?'#ffc030':'#ff8a1a';g.strokeStyle='#3a0a02';g.lineWidth=1;
 g.beginPath();for(let i=0;i<=20;i++){const p=UP(i/20);i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1])}for(let i=20;i>=0;i--){const p=LO(i/20);g.lineTo(p[0],p[1])}g.closePath();g.fill();g.stroke();
 g.fillStyle=P;g.lineWidth=.8;
 for(const u of[.14,.3,.46,.62,.78,.92]){const p=UP(u),l=u>.4&&u<.7?3.4:2.6;g.beginPath();g.moveTo(p[0]-1.7,p[1]-.2);g.lineTo(p[0],p[1]+l);g.lineTo(p[0]+1.7,p[1]-.2);g.closePath();g.fill();g.stroke()}
 for(const u of[.22,.38,.54,.7,.86]){const p=LO(u),l=u>.4&&u<.7?3.2:2.4;g.beginPath();g.moveTo(p[0]-1.6,p[1]+.2);g.lineTo(p[0],p[1]-l);g.lineTo(p[0]+1.6,p[1]+.2);g.closePath();g.fill();g.stroke()}
 g.restore()};
/* ---------- pumpkin pauldrons: a lit jack-o'-lantern on each shoulder, horned in iron ---------- */
{const p0=arPauld;arPauld=function(g,K,c,x,y,front){if(K.pauld!=='pumpd')return p0.apply(this,arguments);
 g.save();g.translate(x,y+5);g.scale(.8,.8);x=0;y=0;
 const {t}=c,dm=v=>front?v:shade(v,-.28),P=dm('#d8601a'),f=.82+.18*Math.sin(t*8+x);
 arBevE(g,x,y+6,15,8,dm('#1a0e0a'),{ow:1.1,edge:dm('#ff8a22'),ew:1.4});
 glow(g,x,y+1,22,'#ff6a10'+hwA(.4*f*(front?1:.5)));
 ell(g,x-7,y+1.4,6,9.2,shade(P,-.3));ell(g,x+7,y+1.4,6,9.2,shade(P,-.22));ell(g,x-3.4,y+1,7.4,10,shade(P,-.08));
 {const old=OL;OL=1;ell(g,x+.4,y+1,7.8,10.4,rgr(g,x-2,y-4,1,14,shade(P,.28),P));OL=old}
 {g.globalAlpha=front?1:.82;g.fillStyle=f>.9?'#fff0a0':'#ffc030';g.strokeStyle='#3a0a02';g.lineWidth=.7;
  g.beginPath();g.moveTo(x-5.4,y-.4);g.lineTo(x-.8,y-2.4);g.lineTo(x-1.2,y+1.2);g.closePath();g.fill();g.stroke();g.beginPath();g.moveTo(x+6.2,y-.4);g.lineTo(x+1.6,y-2.4);g.lineTo(x+2,y+1.2);g.closePath();g.fill();g.stroke();
  g.beginPath();g.moveTo(x-5,y+4.4);g.quadraticCurveTo(x,y+7.6,x+5.6,y+4.4);g.lineTo(x+4,y+8.6);g.lineTo(x+2,y+6.4);g.lineTo(x,y+9);g.lineTo(x-2,y+6.4);g.lineTo(x-3.8,y+8.6);g.closePath();g.fill();g.stroke();g.globalAlpha=1}
 arBev(g,[x-1.6,y-8,x-1.8,y-12,x+1.6,y-12.6,x+2,y-8],'#3a2a14',{ow:.9});
 arTusk(g,x-5,y-5,-2.1,15,.5,5.2,dm('#1a0e0a'),{});arTusk(g,x+5,y-5,-1.1,13,-.3,4.6,dm('#2a1810'),{});g.restore()}}
/* ---------- crest behind the head: a roaring halo of fire ---------- */
HWC.hwpreap=(g,K,c,hx,hy)=>{const {t}=c,f=.85+.15*Math.sin(t*7);
 g.save();g.globalCompositeOperation='lighter';glow(g,hx-1,hy-3,62,'#ff6a10'+hwA(.36*f));
 g.translate(hx-1,hy-3);g.rotate(t*.1);
 for(let i=0;i<16;i++){g.rotate(TAU/16);const L=(i%2?30:40)+Math.sin(t*6+i*1.7)*4,w=Math.sin(t*5+i)*2;g.fillStyle=i%2?'#ff7a1a88':'#ffb04a88';g.beginPath();g.moveTo(-3.4,-22);g.quadraticCurveTo(-3+w,-L*.8,w*1.4,-L);g.quadraticCurveTo(3+w,-L*.8,3.4,-22);g.closePath();g.fill()}
 g.restore()};
Object.assign(AK.hwpreap,{helm:'pumpkin2',crest:'hwpreap',pauld:'pumpd',cape:'royal',cc:'#220a30',paulc:'#d8601a'});
/* grander aura: a rune circle on the ground, rolling shock rings, a column of fire, a ring of ember motes */
{const a0=HWA.hwpreap;HWA.hwpreap=(g,K,c,post,hx,hy,orb)=>{const {t}=c;
 if(!post){g.save();g.globalCompositeOperation='lighter';
  for(let k=0;k<2;k++){const u=((t*.45+k*.5)%1);g.globalAlpha=(1-u)*.55;g.strokeStyle='#ff9a2a';g.lineWidth=2.2*(1-u)+.6;g.beginPath();g.ellipse(-4,-2,26+u*70,5+u*14,0,0,TAU);g.stroke()}
  g.globalAlpha=.7;g.strokeStyle='#ffb040';g.lineWidth=1.4;g.beginPath();g.ellipse(-4,-2,48,10,0,0,TAU);g.stroke();g.beginPath();g.ellipse(-4,-2,36,7.4,0,0,TAU);g.stroke();
  for(let i=0;i<12;i++){const a=t*.6+i*TAU/12;g.fillStyle='#ffd070';g.globalAlpha=.55+.4*Math.sin(t*3+i);g.fillRect(-4+Math.cos(a)*42-1.3,-2+Math.sin(a)*8.6-1.3,2.6,2.6)}
  for(let i=0;i<5;i++){const u=(t*.6+i*.2)%1,x=-4+Math.sin(i*3+t)*8;g.globalAlpha=Math.sin(u*Math.PI)*.4;ell(g,x,-30-u*150,10*(1-u*.6),18*(1-u*.4),'#ff7a1a')}
  g.restore();g.globalAlpha=1}
 a0(g,K,c,post,hx,hy,orb);
 if(!post)orb(7,-4,-84,52,40,-1.5,(x,y,i,a,z)=>{g.save();g.globalCompositeOperation='lighter';g.globalAlpha=.5+.4*z;glow(g,x,y,6,'#ffa030aa');ell(g,x,y,1.9,1.9,'#fff0b0');g.restore()})}}

/* Soul Harvest gear animates 30% slower, for a calmer, more ghostly rhythm: the Soulreaper, the Reaper's Shroud and the Pumpkin Reaper */
{const SLOW=.525,sl=(fn)=>function(g,K,c){const a=Array.prototype.slice.call(arguments);a[2]=Object.assign({},c,{t:c.t*SLOW});return fn.apply(this,a)};
 for(const k of['reaper','pumpkin2'])HWH[k]=sl(HWH[k]);for(const k of['hwreap','hwpreap']){HWC[k]=sl(HWC[k]);HWA[k]=sl(HWA[k])}{const f0=arFx;arFx=function(g,K,c){if(K.fx==='souls')c=Object.assign({},c,{t:c.t*SLOW});return f0.call(this,g,K,c)}}
 const w0=WNEW.hw_scythe;WNEW.hw_scythe=function(g,L,t,X){return w0.call(this,g,L,t*SLOW,X)}}
