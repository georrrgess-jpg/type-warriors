/* ---------- unique boss art (levels 7-30) ---------- */
const _mw0=mweap;
mweap=function(g,k,c,t){
 if(k==='hammer'){const L=c.wsc||1;g.save();g.scale(L,L);g.fillStyle='#4a3020';g.beginPath();g.roundRect(-3.5,-64,7,70,3);g.fill();poly(g,[-20,-86,20,-86,22,-62,-22,-62],c.bl||'#8a8f9a','#2a2e34',2);poly(g,[-20,-86,20,-86,16,-80,-16,-80],'#ffffff30');g.fillStyle='#0003';g.fillRect(-20,-70,42,4);if(c.flame){glow(g,0,-74,34,'#ff8a2a88')}g.restore();return}
 if(k==='gsword'){const L=c.wsc||1;g.save();g.scale(L,L);g.fillStyle='#3a2a20';g.fillRect(-3,-4,6,16);poly(g,[-16,-4,16,-4,16,-10,-16,-10],c.gd||'#c9a545','#000a',1.5);const bl=c.bl||'#c4cad4';poly(g,[-8,-10,8,-10,6,-104,0,-120,-6,-104],bl,'#000a',1.5);g.fillStyle='#ffffff40';poly(g,[-1,-12,3,-12,2,-100,0,-112],'#ffffff40');g.fillStyle='#0004';g.fillRect(-.7,-100,1.4,88);if(c.flame){glow(g,0,-70,44,c.flame+'88')}g.restore();return}
 if(k==='scythe'){const L=c.wsc||1;g.save();g.scale(L,L);g.fillStyle='#2a1c14';g.beginPath();g.roundRect(-2.5,-110,5,120,2);g.fill();g.fillStyle=c.bl||'#c8d0d8';g.beginPath();g.moveTo(0,-110);g.quadraticCurveTo(-46,-124,-70,-84);g.quadraticCurveTo(-42,-102,0,-98);g.closePath();g.fill();g.strokeStyle='#000a';g.lineWidth=1.5;g.stroke();if(c.orb)glow(g,-40,-104,40,c.orb+'66');g.restore();return}
 if(k==='trident'){const L=c.wsc||1;g.save();g.scale(L,L);g.fillStyle='#b8902a';g.fillRect(-2.5,-96,5,104);for(const x of[-14,0,14])poly(g,[x-3,-94,x+3,-94,x,-122],c.bl||'#ffd76a','#5a4010',1.5);poly(g,[-14,-94,14,-94,14,-88,-14,-88],'#ffd76a','#5a4010',1.5);if(c.orb)glow(g,0,-104,44,c.orb+'66');g.restore();return}
 _mw0(g,k,c,t)};
function rock(g,x,y,r,c,s,sq){const n=9,p=[];for(let i=0;i<n;i++){const a=i/n*TAU+rnd(s)*.6,rr=r*(.72+.4*rnd(s+i*3.1));p.push(x+Math.cos(a)*rr,y+Math.sin(a)*rr*(sq||.9))}
 g.beginPath();g.moveTo(p[0],p[1]);for(let i=2;i<p.length;i+=2)g.lineTo(p[i],p[i+1]);g.closePath();g.fillStyle=rgr(g,x-r*.35,y-r*.4,1,r*1.2,shade(c,.28),shade(c,-.42));g.fill();g.strokeStyle='#000000b0';g.lineWidth=2;g.lineJoin='round';g.stroke();
 g.strokeStyle='#ffffff25';g.lineWidth=1.6;g.beginPath();g.moveTo(p[0]-1,p[1]+2);g.lineTo(p[2],p[3]+1);g.lineTo(p[4],p[5]);g.stroke()}

/* Scarecrow king */
function scarecrow(g,t,o){const lg=o.lg||0,S=Math.sin(t*4),bob=Math.abs(Math.cos(t*4))*2,sw=Math.sin(t*2.4);
 g.save();g.lineJoin='round';g.lineCap='round';glow(g,-10,-96,96,'#ff7a1a44');
 // pole behind
 g.fillStyle='#4a3020';g.fillRect(6,-150,7,150);
 // legs: ragged trousers
 for(const k of[0,1]){const f=k?-S*10:S*10,c=k?'#3a2a44':'#4a3658';limb(g,4-k*10,-46,4-k*10+f*.5,-24,13,c);limb(g,4-k*10+f*.5,-24,2-k*10+f,-5,11,c);ell(g,-3-k*10+f,-3,12,4,'#2a1a10');for(let i=0;i<4;i++)limb(g,-2-k*10+f+i*2.5,-4,-4-k*10+f+i*2.5,7,1.6,'#d8b850')}
 g.translate(0,-bob);
 // coat body
 g.fillStyle=hgr(g,-24,24,'#6a4a80','#38224a');g.beginPath();g.moveTo(-22,-112);g.quadraticCurveTo(-30,-70,-26,-40);g.lineTo(-12,-32);g.lineTo(-4,-42);g.lineTo(6,-32);g.lineTo(18,-42);g.quadraticCurveTo(28,-70,22,-112);g.closePath();g.fill();g.strokeStyle='#000b';g.lineWidth=2;g.stroke();
 g.strokeStyle='#e8c860';g.lineWidth=2;g.setLineDash([4,3]);g.beginPath();g.moveTo(-1,-110);g.lineTo(-2,-44);g.stroke();g.setLineDash([]);
 for(const [x,y,w] of[[-14,-84,10],[8,-66,9]]){g.fillStyle='#8a6a2a';g.fillRect(x,y,w,w);g.strokeStyle='#ffe08a';g.lineWidth=1;g.setLineDash([2,2]);g.strokeRect(x,y,w,w);g.setLineDash([])}
 for(let i=0;i<9;i++){const x=-22+i*5,l=6+rnd(i)*7;limb(g,x,-40,x+Math.sin(t*3+i)*2,-40+l,2,i%2?'#e8c860':'#c8a040')}
 // arms straight out on the pole cross-beam
 g.fillStyle='#5a3a24';const ay=-108+sw*2;g.save();g.translate(0,ay);g.beginPath();g.roundRect(-76-lg*22,-4,110,8,3);g.fill();g.restore();
 for(const k of[0,1]){const ex=k?46:-70-lg*24,ey=ay+(k?4:lg*-18);limb(g,k?14:-12,-106,ex,ey,12,k?'#4a3060':'#6a4a80');for(let i=0;i<6;i++){limb(g,ex,ey,ex+(k?1:-1)*(8+i*2.4),ey-9+i*4,1.8,'#e8c860')}}
 // shoulders straw
 for(let i=0;i<8;i++)limb(g,-18+i*5,-112,-20+i*5+rnd(i)*6,-124-rnd(i+9)*8,2,'#d8b850');
 // pumpkin head
 const hx=-6,hy=-132;ell(g,hx,hy,26,23,rgr(g,hx-8,hy-8,2,30,'#ffb03a','#a84a0a'));for(const dx of[-14,-5,5,14])g.strokeStyle='#a84a0a99',g.lineWidth=1.6,g.beginPath(),g.ellipse(hx+dx*.5,hy,Math.abs(dx)*.9+3,22,0,-1.6,1.6),g.stroke();
 poly(g,[hx-2,hy-24,hx+4,hy-24,hx+7,hy-34,hx+1,hy-32],'#3a6a1a');
 poly(g,[hx-17,hy-6,hx-6,hy-12,hx-6,hy+2],'#1a0a02');poly(g,[hx+5,hy-12,hx+15,hy-6,hx+5,hy+2],'#1a0a02');glow(g,hx-11,hy-5,22,'#ffe04aaa');glow(g,hx+9,hy-5,22,'#ffe04aaa');
 g.fillStyle='#1a0a02';g.beginPath();g.moveTo(hx-16,hy+8);for(let i=0;i<7;i++)g.lineTo(hx-16+i*5,hy+(i%2?16:9));g.lineTo(hx+16,hy+8);g.quadraticCurveTo(hx,hy+22,hx-16,hy+8);g.fill();glow(g,hx,hy+12,24,'#ffe04a66');
 // hat
 g.fillStyle='#2a1a3a';g.beginPath();g.ellipse(hx,hy-18,38,8,-.1,0,TAU);g.fill();g.strokeStyle='#000a';g.lineWidth=2;g.stroke();poly(g,[hx-22,hy-20,hx-14,hy-56,hx+2,hy-64,hx+16,hy-54,hx+22,hy-20],'#38224a','#000a',2);g.fillStyle='#e8455a';g.fillRect(hx-22,hy-30,44,7);
 // crows
 for(let i=0;i<3;i++){const a=t*1.4+i*2.1,x=Math.cos(a)*70,y=-140+Math.sin(a*1.3)*24,f=Math.sin(t*14+i)*.6;g.save();g.translate(x,y);g.fillStyle='#120a1a';g.beginPath();g.ellipse(0,0,7,4,0,0,TAU);g.fill();for(const s of[-1,1]){g.save();g.rotate(s*(.5+f));g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(s*10,-10,s*18,-2);g.quadraticCurveTo(s*9,-3,0,3);g.fill();g.restore()}g.restore()}
 g.restore()}

/* armoured knight (warlord / marshal / tyrant) */
function knightB(g,t,o,p){const lg=o.lg||0,S=Math.sin(t*4.5),bob=Math.abs(Math.cos(t*4.5))*2.5,A=p.a,dk=shade(A,-.5),hl=shade(A,.32),Tr=p.b;
 g.save();g.lineJoin='round';g.lineCap='round';if(p.aura)glow(g,0,-80,100,p.aura+'44');
 g.fillStyle=p.cape;g.beginPath();g.moveTo(8,-112);g.quadraticCurveTo(66,-88+Math.sin(t*3)*5,56+Math.sin(t*3)*9,-4);g.lineTo(18,-40);g.closePath();g.fill();g.fillStyle='#0004';g.beginPath();g.moveTo(8,-112);g.quadraticCurveTo(44,-88,36+Math.sin(t*3)*5,-6);g.lineTo(18,-40);g.closePath();g.fill();g.strokeStyle='#000a';g.lineWidth=2;g.stroke();
 const leg=(hx,fx,c)=>{const kx=(hx+fx)/2-5;limb(g,hx,-46,kx,-24,17,c);limb(g,kx,-24,fx,-6,14,c);ell(g,kx,-25,10,10,shade(c,.15));poly(g,[fx-20,-2,fx+8,-2,fx+6,-11,fx-13,-15],shade(c,-.25),'#000a',1.5)};
 leg(9,12-S*14,dk);leg(-9,-9+S*14,A);
 poly(g,[-18,-52,18,-52,14,-30-Math.sin(t*4)*2,0,-22,-14,-30],p.tab||Tr,'#000a',1.5);
 g.save();g.translate(0,-bob);
 const arm=(sx,hx,hy,c)=>{const ex=(sx+hx)/2-6,ey=(-112+hy)/2+8;limb(g,sx,-112,ex,ey,15,c);limb(g,ex,ey,hx,hy,13,shade(c,-.1));ell(g,ex,ey,8,8,shade(c,.2));ell(g,hx,hy,10,10,shade(c,-.2))};
 const hx0=-48-lg*26,hy0=-78-lg*20;
 if(p.shield){arm(10,14,-98,dk)}else arm(10,20,-118,dk);
 g.beginPath();g.roundRect(-25,-122,50,80,12);g.fillStyle=hgr(g,-25,25,hl,dk);g.fill();g.strokeStyle='#000b';g.lineWidth=2;g.stroke();
 poly(g,[-14,-114,14,-114,10,-84,0,-74,-10,-84],shade(A,.12),'#000a',1.5);g.strokeStyle=shade(A,.45)+'aa';g.lineWidth=1.6;g.beginPath();g.moveTo(-14,-114);g.lineTo(-10,-84);g.moveTo(14,-114);g.lineTo(10,-84);g.stroke();
 g.fillStyle=Tr;g.fillRect(-25,-60,50,9);for(let i=0;i<5;i++)ell(g,-18+i*9,-55.5,2.2,2.2,'#ffd76a');
 if(p.emb){glow(g,0,-96,30,p.emb+'88');poly(g,[0,-108,8,-96,0,-84,-8,-96],p.emb,'#000a',1)}
 for(const [x,k] of[[-25,0],[25,1]]){g.beginPath();g.ellipse(x,-114,17,13,0,Math.PI,TAU);g.fillStyle=k?dk:hl;g.fill();g.strokeStyle='#000b';g.lineWidth=2;g.stroke();g.fillStyle=Tr;g.fillRect(x-14,-114,28,5);if(p.spikes)poly(g,[x-6,-124,x,-142,x+6,-124],shade(A,.4),'#000a',1.5)}
 // front arm + weapon / shield
 if(p.shield){const hx=-36,hy=-86;arm(-16,hx,hy,A);g.save();g.translate(hx-10,hy-4);const sc=p.shield;poly(g,[-22,-40,22,-40,22,6,0,34,-22,6],shade(sc,-.1),'#000c',2.5);poly(g,[-16,-34,16,-34,16,4,0,26,-16,4],sc,'#0008',1.5);g.fillStyle=Tr;g.fillRect(-2,-34,4,58);g.fillRect(-16,-16,32,4);ell(g,0,-12,5,5,'#ffd76a','#000');g.restore();
  g.save();g.translate(22,-118);g.rotate(.4+lg*-.2);mweap(g,p.wp||'gsword',{bl:p.bl,flame:p.flame,gd:'#ffd76a',wsc:1.2},t);g.restore();arm(18,22,-118,dk)}
 else{arm(-16,hx0,hy0,A);g.save();g.translate(hx0,hy0);g.rotate(.5-lg*2.1-Math.sin(t*4.5)*.05);mweap(g,p.wp||'gsword',{bl:p.bl,flame:p.flame,gd:'#ffd76a',wsc:1.3},t);g.restore();ell(g,hx0,hy0,10,10,shade(A,-.2))}
 // helm
 const hx=-4,hy=-136;limb(g,hx,hy+8,0,-118,16,dk);
 if(p.crest){g.fillStyle=p.crest;g.beginPath();g.moveTo(hx+14,hy-14);for(let i=0;i<7;i++){const u=i/6;g.lineTo(hx+14+u*32+Math.sin(t*5+i)*3,hy-16-Math.sin(u*3)*18+u*18)}g.lineTo(hx+8,hy+2);g.closePath();g.fill();g.strokeStyle='#000a';g.lineWidth=1.5;g.stroke()}
 if(p.horns){for(const k of[0,1]){g.strokeStyle=shade(A,.55);g.lineWidth=7-k*2;g.beginPath();g.moveTo(hx-8+k*18,hy-14);g.quadraticCurveTo(hx-30+k*14,hy-30,hx-34+k*22,hy-58);g.stroke();g.strokeStyle='#000a';g.lineWidth=1.5}}
 g.beginPath();g.roundRect(hx-18,hy-20,36,38,[16,16,8,8]);g.fillStyle=hgr(g,hx-18,hx+18,hl,dk);g.fill();g.strokeStyle='#000b';g.lineWidth=2;g.stroke();
 g.fillStyle='#0a0508';g.fillRect(hx-18,hy-6,34,6);poly(g,[hx-3,hy-20,hx+3,hy-20,hx+3,hy+16,hx-3,hy+16],shade(A,-.1),'#0009',1);
 eye(g,hx-9,hy-3,4,p.e||'#ff5a3a');eye(g,hx+7,hy-3,3.2,p.e||'#ff5a3a');
 g.strokeStyle='#0006';g.lineWidth=1.5;for(let i=0;i<3;i++){g.beginPath();g.moveTo(hx-15,hy+6+i*4);g.lineTo(hx-3,hy+6+i*4);g.stroke()}
 if(p.crown){g.fillStyle='#ffc94a';g.beginPath();g.moveTo(hx-16,hy-18);g.lineTo(hx-16,hy-34);g.lineTo(hx-8,hy-26);g.lineTo(hx,hy-38);g.lineTo(hx+8,hy-26);g.lineTo(hx+16,hy-34);g.lineTo(hx+16,hy-18);g.closePath();g.fill();g.strokeStyle='#5a3a08';g.lineWidth=1.6;g.stroke();ell(g,hx,hy-24,3,3,p.gem||'#e8455a')}
 g.restore();g.restore()}

/* many-headed hydra */
function hydra(g,t,o,p){const lg=o.lg||0,col=p.col,hi=shade(col,.32),dk=shade(col,-.45);
 g.save();g.lineJoin='round';g.lineCap='round';if(p.aura)glow(g,-20,-90,110,p.aura+'44');
 // tail
 g.strokeStyle=dk;g.lineCap='round';for(let j=0;j<16;j++){const u=j/15,x=52+u*66,y=-24-Math.sin(u*2.6+t*2)*16*u-u*8,r=lerp(18,3,u);ell(g,x,y,r,r*.9,j%2?col:dk)}
 // legs
 for(const [x,k] of[[-10,0],[40,1]]){const s=Math.sin(t*3+k*2)*5;limb(g,x+6,-30,x,-12,20,k?dk:col);ell(g,x-6+s,-4,20,7,shade(col,-.3));for(let i=0;i<3;i++)poly(g,[x-24+s+i*8,-2,x-20+s+i*8,-10,x-18+s+i*8,-2],'#e8dcc0')}
 ell(g,20,-56,74,46,vgr(g,-104,-10,hi,dk));ell(g,10,-30,52,22,'#e8d8a8');for(let i=0;i<6;i++)g.strokeStyle='#0002',g.lineWidth=1.4,g.beginPath(),g.moveTo(-30+i*13,-40),g.lineTo(-32+i*13,-18),g.stroke();
 for(let i=0;i<9;i++){const x=-30+i*13;poly(g,[x-5,-92+Math.abs(i-4)*3,x,-106+Math.abs(i-4)*3,x+5,-92+Math.abs(i-4)*3],p.sp||'#ffd76a')}
 const N=p.heads||3;
 const hd=[];
 const TX=[-128,-88,-46,-150,-10],HT=[96,128,106,80,90];
 for(let i=0;i<N;i++){const bx=-10+i*20,by=-80,tx=TX[i]-(i===1?lg*40:0),ht=HT[i],ph=t*1.8+i*1.9,pts=[];
  for(let j=0;j<=14;j++){const u=j/14,x=bx+(tx-bx)*Math.pow(u,1.5)+Math.sin(ph+u*4.2)*10*u,y=by-ht*Math.sin(u*Math.PI/2)+Math.sin(ph*.7+u*3)*4*u;pts.push([x,y,lerp(18,10,u)])}
  hd.push([pts,i])}
 hd.sort((a,b)=>b[1]-a[1]);
 for(const [pts,i] of hd){for(let j=0;j<pts.length;j++){const [x,y,r]=pts[j];ell(g,x,y,r,r,j%2?col:shade(col,-.12))}
  const [x,y]=pts[pts.length-1],pr=pts[pts.length-2],ang=Math.atan2(y-pr[1],x-pr[0]),jaw=(Math.sin(t*3+i*2)*.5+.5)*.5+lg*.5;
  g.save();g.translate(x,y);g.rotate(.12-ang*.0);
  poly(g,[-4,-14,-46,-6,-50,4,-4,12],vgr(g,-14,12,hi,col),'#000a',2);
  g.save();g.rotate(jaw);poly(g,[-4,10,-44,6,-40,18,-4,20],dk,'#000a',2);for(let k=0;k<4;k++)poly(g,[-14-k*8,8,-11-k*8,8,-12-k*8,17],'#f4ecd0');g.restore();
  for(let k=0;k<3;k++)poly(g,[-14-k*9,-3,-11-k*9,-3,-12.5-k*9,6],'#f4ecd0');
  poly(g,[6,-12,26,-30,12,-4],dk);poly(g,[8,-2,24,-14,12,8],shade(dk,-.2));
  eye(g,-22,-6,4.5,p.e||'#ffe04a');ell(g,-46,-2,2,1.6,'#000');g.restore()}
 g.restore()}

/* rock / crystal / lava golem */
function golem(g,t,o,p){const lg=o.lg||0,c=p.c,S=Math.sin(t*2.6),bob=Math.abs(Math.cos(t*2.6))*3,pu=.6+.4*Math.sin(t*3);
 g.save();g.lineJoin='round';if(p.aura)glow(g,0,-90,110,p.aura+'44');
 const gl=p.g;
 for(const k of[0,1]){const f=k?-S:S;rock(g,-8-k*12+f*6,-50-k*4,26,shade(c,k?-.3:0),3+k,.8);rock(g,-8-k*12+f*8,-20+Math.max(0,-f)*-4,22,shade(c,k?-.32:-.05),5+k,.75)}
 g.save();g.translate(0,-bob);
 // back arm
 const arm=(sx,sy,fx,fy,d)=>{const ex=(sx+fx)/2-8,ey=(sy+fy)/2+10;rock(g,sx,sy,26,shade(c,d),9,.85);rock(g,ex,ey,20,shade(c,d),12,.9);rock(g,fx,fy,27,shade(c,d-.05),15,.9);if(p.x==='ice')for(const a of[-.6,0,.6])poly(g,[fx+a*20-4,fy-16,fx+a*26,fy-42,fx+a*20+4,fy-16],'#c8f0ff','#000a',1.5)};
 arm(26,-126,30,-60+Math.sin(t*2)*4,-.32);
 rock(g,2,-70,34,shade(c,-.1),20,.8);rock(g,0,-112,46,c,30,.85);
 // seams
 g.save();g.shadowColor=gl;g.shadowBlur=10*pu;g.strokeStyle=gl;g.lineWidth=2.4;g.globalAlpha=.6+.4*pu;
 for(const q of[[[-22,-128],[-10,-112],[-18,-98],[-4,-84]],[[16,-120],[6,-104],[20,-92]],[[-8,-80],[0,-66],[-12,-54]]]){g.beginPath();g.moveTo(q[0][0],q[0][1]);for(let i=1;i<q.length;i++)g.lineTo(q[i][0],q[i][1]);g.stroke()}g.restore();
 ell(g,-2,-102,15*pu,10*pu,gl+'55');ell(g,-2,-102,7,6,gl);ell(g,-2,-102,3,3,'#fff');
 // shoulders
 rock(g,-36,-132,28,shade(c,.05),40,.8);rock(g,30,-134,26,shade(c,-.15),44,.8);
 if(p.x==='moss'){for(const [x,y] of[[-36,-150],[-22,-136],[26,-152],[8,-146],[-14,-92]])ell(g,x,y,10,5,'#3a7a2a'),ell(g,x-2,y-2,6,3,'#5aa83a')}
 if(p.x==='ice')for(const [x,y,h,a] of[[-46,-146,46,-.4],[-30,-154,58,.05],[22,-150,50,.2],[36,-146,40,.5]])poly(g,[x-7,y,x+Math.sin(a)*h,y-h,x+7,y],'#bff0ff','#2a5a8a',1.5),poly(g,[x-2,y-4,x+Math.sin(a)*h*.9,y-h+4,x+3,y-4],'#ffffff70');
 if(p.x==='lava'){for(let i=0;i<7;i++){const ph=t*2+i*1.7,x=-40+i*14+Math.sin(ph)*4,y=-160-((t*30+i*20)%40);ell(g,x,y,4,7,`rgba(255,${120+i*15},30,${.7-((t*30+i*20)%40)/60})`)}glow(g,0,-150,50,'#ff7a1a88')}
 // head
 rock(g,-10,-158,20,shade(c,.1),50,.85);eye(g,-18,-160,4.5,gl);eye(g,-4,-160,3.6,gl);g.strokeStyle='#000c';g.lineWidth=3;g.beginPath();g.moveTo(-26,-168);g.lineTo(-12,-163);g.moveTo(2,-170);g.lineTo(-8,-164);g.stroke();
 // front arm
 arm(-42,-124,-58-lg*42,-56-lg*24-Math.sin(t*2.6)*4,0);
 if(p.x==='lava'||p.x==='stone')glow(g,-58-lg*42,-56-lg*24,34,gl+'55');
 g.restore();g.restore()}

/* scorpion king */
function scorpKing(g,t,o,p){const lg=o.lg||0,col=p.col,hi=shade(col,.3),dk=shade(col,-.45);
 g.save();g.lineJoin='round';g.lineCap='round';if(p.aura)glow(g,0,-70,110,p.aura+'44');
 for(let i=0;i<4;i++)for(const k of[1,0]){const x=-34+i*24+k*5,ph=t*5+i*1.6+k*3.1,fx=x-24+Math.sin(ph)*9,fy=-3-Math.max(0,Math.cos(ph))*7,kx=x-16,ky=-66;limb(g,x,-42,kx,ky,9,k?dk:col);limb(g,kx,ky,fx,fy,7,k?dk:col);poly(g,[fx-3,fy,fx+3,fy,fx-2,fy-8],'#1a1008')}
 // tail
 let x=60,y=-50,a=-.25;const tp=[];for(let j=0;j<8;j++){a-=.4-(j>5?.03:0);const L=22;x+=Math.cos(a+Math.sin(t*2)*.05)*L;y+=Math.sin(a)*L;tp.push([x,y,a])}
 x=56;y=-46;for(let j=0;j<tp.length;j++){const [nx,ny]=tp[j],r=lerp(15,9,j/7);limb(g,x,y,nx,ny,r*2,j%2?col:hi);ell(g,nx,ny,r,r,j%2?hi:col);x=nx;y=ny}
 {const [sx,sy,sa]=tp[7];g.save();g.translate(sx,sy);g.rotate(sa+.5+lg*.6);ell(g,0,0,14,14,rgr(g,-3,-3,2,16,'#ff9a4a',dk));poly(g,[-8,-8,-6,8,-30,4],'#f0e8c8','#000a',1.5);glow(g,-28,3,26,p.g+'99');g.restore()}
 // body
 ell(g,10,-48,66,30,vgr(g,-80,-20,hi,dk));for(let i=0;i<6;i++){g.strokeStyle='#0004';g.lineWidth=2;g.beginPath();g.ellipse(-30+i*17,-48,4,27,0,0,TAU);g.stroke()}
 ell(g,-6,-64,40,12,'#ffffff22');for(let i=0;i<5;i++)poly(g,[-30+i*18,-76,-24+i*18,-92,-18+i*18,-76],shade(col,.5),'#000a',1.2);
 // claws
 const claw=(k,dy)=>{const sx=-56,sy=-50,ex=-86,ey=-66+dy,fx=-124-lg*30-(k?0:8),fy=-44+dy-lg*10;limb(g,sx,sy,ex,ey,14,k?dk:col);limb(g,ex,ey,fx,fy,16,k?dk:hi);ell(g,ex,ey,9,9,shade(col,.2));
  g.save();g.translate(fx,fy);const op=.3+Math.sin(t*3+k*2)*.15+lg*.4;g.save();g.rotate(-op);poly(g,[10,-8,-36,-14,-44,2,10,8],k?dk:hi,'#000a',2);g.restore();g.save();g.rotate(op);poly(g,[10,-8,-32,8,-38,22,10,10],k?shade(col,-.3):col,'#000a',2);g.restore();g.restore()};
 claw(1,10);claw(0,-6);
 // head + crown
 ell(g,-60,-64,20,17,hi);eye(g,-70,-70,4,p.e||'#ff5a3a');eye(g,-56,-72,3.2,p.e||'#ff5a3a');
 if(p.crown){g.fillStyle='#ffc94a';g.beginPath();g.moveTo(-76,-76);g.lineTo(-76,-96);g.lineTo(-66,-86);g.lineTo(-58,-100);g.lineTo(-50,-86);g.lineTo(-42,-96);g.lineTo(-42,-76);g.closePath();g.fill();g.strokeStyle='#5a3a08';g.lineWidth=1.6;g.stroke();ell(g,-59,-84,3,3,'#e8455a')}
 g.restore()}

/* wasp empress */
function wasp(g,t,o,p){const lg=o.lg||0,bob=Math.sin(t*3)*7,fl=Math.sin(t*46);
 g.save();g.lineJoin='round';g.lineCap='round';g.translate(0,-bob);if(p.aura)glow(g,0,-90,110,p.aura+'44');
 const wing=(k)=>{g.save();g.translate(-4,-116);g.rotate(-.5-k*.35+fl*.18*(k?-1:1));g.fillStyle=k?'#e8e8ff33':'#f4f4ff55';g.strokeStyle='#ffffff77';g.lineWidth=1.2;g.beginPath();g.ellipse(46,-6,58-k*12,17-k*3,0,0,TAU);g.fill();g.stroke();g.beginPath();g.moveTo(0,0);g.lineTo(100,-6);g.stroke();g.restore()};
 wing(1);
 for(let i=0;i<6;i++){const s=i%3,k=i<3?0:1,x=-14+s*14,sw=Math.sin(t*4+i)*4;limb(g,x,-88,x-10+sw-k*6,-64,3,'#1a1008');limb(g,x-10+sw-k*6,-64,x-18+sw-k*8,-38,2.4,'#1a1008')}
 // abdomen
 g.save();g.translate(44,-84);g.rotate(.4+lg*.4);ell(g,0,0,54,28,vgr(g,-28,28,p.col,shade(p.col,-.4)));g.save();g.beginPath();g.ellipse(0,0,54,28,0,0,TAU);g.clip();for(let i=0;i<4;i++){g.fillStyle='#1a0e0a';g.beginPath();g.moveTo(-34+i*24,-32);g.quadraticCurveTo(-24+i*24,0,-34+i*24,32);g.lineTo(-24+i*24,32);g.quadraticCurveTo(-14+i*24,0,-24+i*24,-32);g.fill()}g.restore();g.strokeStyle='#000a';g.lineWidth=2;g.beginPath();g.ellipse(0,0,54,28,0,0,TAU);g.stroke();
 poly(g,[46,-7,84,8,46,8],'#c8c0a8','#000a',2);glow(g,80,8,26,(p.g||'#b8ff3a')+'99');g.restore();
 // thorax
 ell(g,-8,-96,26,24,rgr(g,-14,-104,2,30,'#5a4020','#1a0e0a'));for(let i=0;i<10;i++){const a=i/10*TAU;limb(g,-8+Math.cos(a)*24,-96+Math.sin(a)*22,-8+Math.cos(a)*30,-96+Math.sin(a)*28,2,'#d8b040')}
 // arms with spear
 limb(g,-22,-92,-46,-76,7,'#1a1008');limb(g,-46,-76,-62-lg*22,-92-lg*8,6,'#1a1008');g.save();g.translate(-62-lg*22,-92-lg*8);g.rotate(-.9-lg);mweap(g,'fork',{},t);g.restore();
 wing(0);
 // head
 const hx=-48,hy=-114;ell(g,hx,hy,24,22,rgr(g,hx-6,hy-6,2,28,'#ffb02a','#a85a0a'));
 for(const [x,y,r] of[[hx-14,hy-4,12],[hx+6,hy-8,9]]){ell(g,x,y,r,r*1.2,rgr(g,x-3,y-3,1,r*1.4,'#6a1a12','#1a0404'));glow(g,x,y,r*2,(p.e||'#ff3a3a')+'66');ell(g,x-3,y-4,3,3,'#ffffff90')}
 poly(g,[hx-18,hy+12,hx-8,hy+20,hx-20,hy+24],'#3a2010');poly(g,[hx-6,hy+16,hx+2,hy+22,hx-8,hy+24],'#3a2010');
 for(const k of[0,1]){g.strokeStyle='#2a1a0a';g.lineWidth=2.4;g.beginPath();g.moveTo(hx-8+k*8,hy-18);g.quadraticCurveTo(hx-30+k*8,hy-46+Math.sin(t*5+k)*3,hx-46+k*10,hy-38);g.stroke();ell(g,hx-46+k*10,hy-38,3,3,'#ffd76a')}
 g.fillStyle='#ffc94a';g.beginPath();g.moveTo(hx-14,hy-18);g.lineTo(hx-16,hy-34);g.lineTo(hx-8,hy-26);g.lineTo(hx,hy-38);g.lineTo(hx+8,hy-26);g.lineTo(hx+14,hy-32);g.lineTo(hx+12,hy-18);g.closePath();g.fill();g.strokeStyle='#5a3a08';g.lineWidth=1.5;g.stroke();
 g.restore()}

/* abyssal angler */
function angler(g,t,o,p){const lg=o.lg||0,col=p.col,hi=shade(col,.3),dk=shade(col,-.5),cy=-96+Math.sin(t*2.2)*6;
 g.save();g.lineJoin='round';g.lineCap='round';g.translate(0,cy);if(p.aura)glow(g,-20,0,150,p.aura+'33');
 // tail
 g.save();g.translate(70,0);g.rotate(Math.sin(t*3)*.2);poly(g,[0,-14,60,-46,48,0,62,46,0,14],vgr(g,-40,40,col,dk),'#000a',2);for(let i=0;i<4;i++){g.strokeStyle='#0004';g.lineWidth=1.4;g.beginPath();g.moveTo(6,0);g.lineTo(54,-34+i*23);g.stroke()}g.restore();
 // dorsal fin
 poly(g,[-20,-56,10,-92+Math.sin(t*3)*4,30,-96,50,-74,60,-40],dk,'#000a',2);
 // body
 ell(g,0,0,86,62,vgr(g,-62,62,hi,dk));
 for(let i=0;i<40;i++){const a=rnd(i)*TAU,r=Math.sqrt(rnd(i+80))*.9,x=Math.cos(a)*r*80,y=Math.sin(a)*r*56;ell(g,x,y,3+rnd(i+3)*3,2.4,'#ffffff10')}
 for(let i=0;i<7;i++){glow(g,-40+i*14,34-Math.sin(i)*4,12,(p.g||'#6ae0ff')+'88');ell(g,-40+i*14,34-Math.sin(i)*4,2.4,2.4,p.g||'#6ae0ff')}
 // fin
 g.save();g.translate(10,20);g.rotate(Math.sin(t*4)*.3);poly(g,[0,0,30,-8,52,16,20,26],col,'#000a',2);g.restore();
 // jaws
 const op=.25+Math.sin(t*2)*.08+lg*.55;
 g.save();g.translate(-52,20);g.rotate(op);poly(g,[10,0,-58,-2,-62,26,-40,36,10,30],dk,'#000a',2.5);for(let i=0;i<6;i++)poly(g,[-6-i*9,2,-1-i*9,2,-3-i*9,-24-rnd(i)*8],'#f4ecd0','#0006',1);g.restore();
 poly(g,[-30,-18,-90,-6,-92,10,-56,14],hi,'#000a',2.5);for(let i=0;i<6;i++)poly(g,[-38-i*9,-8+i*.5,-33-i*9,-8+i*.5,-36-i*9,14+rnd(i)*8],'#f4ecd0','#0006',1);
 glow(g,-58,10,50,'#20040488');
 // eye
 ell(g,-36,-30,15,15,'#f0e8b8');ell(g,-40,-30,7,11,'#160408');glow(g,-36,-30,34,'#ffe04a55');ell(g,-42,-36,2.6,2.6,'#fff');
 // lure
 g.strokeStyle=shade(col,-.2);g.lineWidth=4;g.beginPath();g.moveTo(-20,-56);g.quadraticCurveTo(-56,-130,-110-lg*14,-96+Math.sin(t*3)*6);g.stroke();
 const lx=-110-lg*14,ly=-96+Math.sin(t*3)*6;glow(g,lx,ly,60,(p.g||'#6ae0ff')+'99');ell(g,lx,ly,9,9,'#eaffff');
 g.restore()}

/* thunderbird */
function thunderbird(g,t,o,p){const lg=o.lg||0,col=p.col,hi=shade(col,.35),dk=shade(col,-.5),fl=Math.sin(t*4.5),cy=-96;
 g.save();g.lineJoin='round';g.lineCap='round';glow(g,0,-100,130,(p.g||'#ffe04a')+'33');
 const wing=(k)=>{g.save();g.translate(10,-118);g.rotate(-.25+fl*.28+k*.22);for(let i=0;i<9;i++){const a=-1.55+i*.19,L=118-Math.abs(i-4)*4-i*2;g.save();g.rotate(a);poly(g,[0,-5,L,-8,L+16,0,L,8,0,5],k?shade(i%2?col:hi,-.4):(i%2?col:hi),'#000a',1.6);g.strokeStyle='#ffffff30';g.beginPath();g.moveTo(10,0);g.lineTo(L,0);g.stroke();g.restore()}ell(g,0,0,16,14,k?dk:col);g.restore()};
 wing(1);
 // legs
 for(const k of[0,1]){const s=Math.sin(t*3+k*2)*4,x=k?12:-8;limb(g,x,-56,x-4+s,-28,9,'#b8902a');limb(g,x-4+s,-28,x-8+s,-4,7,'#b8902a');for(let i=0;i<3;i++)poly(g,[x-8+s-i*7,-3,x-4+s-i*7,-3,x-22+s-i*7,-8+i],'#e8dcc0','#000a',1)}
 // tail feathers
 for(let i=0;i<5;i++){g.save();g.translate(50,-70);g.rotate(.5+i*.22+Math.sin(t*3+i)*.05);poly(g,[0,-6,62,-9,72,0,62,9,0,6],i%2?dk:col,'#000a',1.5);g.restore()}
 ell(g,10,-88,56,38,vgr(g,-120,-50,hi,dk),.2);ell(g,-12,-72,32,22,shade(col,.55));
 for(let i=0;i<6;i++){g.strokeStyle='#0003';g.lineWidth=1.4;g.beginPath();g.arc(-14+(i%3)*14,-70+Math.floor(i/3)*12,7,0,Math.PI);g.stroke()}
 // neck + head
 limb(g,-30,-98,-52,-124,26,shade(col,.15));const hx=-58-lg*10,hy=-132-lg*4;
 for(let i=0;i<7;i++){g.save();g.translate(hx+8,hy-10);g.rotate(1.9+i*.22+Math.sin(t*6+i)*.06);poly(g,[0,-3,26+i*2,0,0,3],i%2?(p.g||'#ffe04a'):hi,'#000a',1);g.restore()}
 ell(g,hx,hy,22,19,vgr(g,hy-20,hy+20,shade(col,.5),shade(col,.05)));
 poly(g,[hx-16,hy-6,hx-52,hy+8,hx-18,hy+12],'#e8b830','#000a',2);poly(g,[hx-16,hy+8,hx-46,hy+16,hx-16,hy+18],'#c89820','#000a',2);
 eye(g,hx-6,hy-6,5,p.e||'#ffe04a');g.strokeStyle='#000c';g.lineWidth=2.6;g.beginPath();g.moveTo(hx-16,hy-15);g.lineTo(hx+2,hy-9);g.stroke();
 wing(0);
 // lightning
 g.save();g.strokeStyle=p.g||'#ffe04a';g.shadowColor=p.g||'#ffe04a';g.shadowBlur=14;g.lineWidth=2.6;for(let k=0;k<3;k++){if(((t*7+k*3.3)%3)>1.7)continue;let x=-60+k*70,y=-200;g.beginPath();g.moveTo(x,y);for(let j=1;j<7;j++){x+=(rnd(Math.floor(t*10)+k*9+j)-.5)*34;y+=24;g.lineTo(x,y)}g.stroke()}g.restore();
 g.restore()}

/* witch */
function witch(g,t,o,p){const lg=o.lg||0,S=Math.sin(t*4),bob=Math.abs(Math.cos(t*4))*2,sw=Math.sin(t*2);
 g.save();g.lineJoin='round';g.lineCap='round';glow(g,0,-100,100,(p.g||'#7dff7a')+'33');
 // robe
 g.fillStyle=vgr(g,-120,0,'#4a1a6a','#1a0a2a');g.beginPath();g.moveTo(-18,-118);g.quadraticCurveTo(-30,-60,-46+S*4,-2);g.lineTo(40+S*4,-2);g.quadraticCurveTo(26,-60,18,-118);g.closePath();g.fill();g.strokeStyle='#000b';g.lineWidth=2;g.stroke();
 g.strokeStyle='#9a6ad0';g.lineWidth=2;g.beginPath();for(let i=0;i<8;i++){const x=-42+i*11+S*4;g.moveTo(x,-2);g.lineTo(x+3,-12)}g.stroke();
 poly(g,[-12,-112,12,-112,8,-70,0,-62,-8,-70],'#2a1040');g.fillStyle='#6a3a1a';g.fillRect(-18,-72,36,7);ell(g,0,-68.5,5,5,'#ffd76a');
 g.translate(0,-bob);
 // arms
 limb(g,12,-112,26,-88,8,'#5a3a7a');limb(g,26,-88,20,-70,7,'#5a3a7a');
 const hx=-44-lg*24,hy=-92-lg*16;limb(g,-14,-112,-28,-98,9,'#5a3a7a');limb(g,-28,-98,hx,hy,8,'#5a3a7a');ell(g,hx,hy,6,6,'#8ab060');
 g.save();g.translate(hx,hy);g.rotate(-.18-lg*.4);mweap(g,'staff',{orb:p.g||'#7dff7a'},t);g.restore();
 for(let i=0;i<5;i++){const a=t*2+i*1.3;glow(g,hx-4+Math.cos(a)*18,hy-96+Math.sin(a)*12,10,(p.g||'#7dff7a')+'aa')}
 // head
 const cx=-4,cy=-138;
 g.fillStyle='#1a0a2a';for(let i=0;i<9;i++){g.beginPath();g.moveTo(cx+8,cy-8);g.quadraticCurveTo(cx+30+i*3,cy+8+i*5+Math.sin(t*2+i)*3,cx+18+i*4,cy+34+i*7+Math.sin(t*2+i)*4);g.lineTo(cx+12,cy);g.fill()}
 ell(g,cx,cy,17,20,rgr(g,cx-5,cy-6,2,24,'#9ac070','#4a7a3a'));
 poly(g,[cx-14,cy-2,cx-34,cy+8,cx-24,cy+12,cx-12,cy+6],'#6a9a4a','#000a',1.5);poly(g,[cx-10,cy+12,cx-4,cy+30,cx+6,cy+14],'#6a9a4a','#000a',1.5);ell(g,cx-24,cy+9,2.4,2.4,'#3a5a2a');
 eye(g,cx-10,cy-6,3.6,p.e||'#ff5a9a');eye(g,cx+5,cy-7,2.8,p.e||'#ff5a9a');g.strokeStyle='#000b';g.lineWidth=2;g.beginPath();g.moveTo(cx-16,cy-13);g.lineTo(cx-4,cy-9);g.stroke();
 g.fillStyle='#1a0a2a';g.beginPath();g.ellipse(cx,cy-16,36,8,-.1,0,TAU);g.fill();g.strokeStyle='#000b';g.lineWidth=2;g.stroke();
 g.beginPath();g.moveTo(cx-20,cy-18);g.quadraticCurveTo(cx-8,cy-52,cx+8+sw*2,cy-78);g.quadraticCurveTo(cx+14,cy-62,cx+26,cy-18);g.closePath();g.fillStyle='#2a1440';g.fill();g.stroke();
 g.fillStyle='#8a2ab0';g.fillRect(cx-21,cy-30,46,8);g.fillStyle='#ffd76a';g.fillRect(cx-4,cy-31,11,10);g.fillStyle='#2a1440';g.fillRect(cx-1,cy-28,5,4);
 // raven
 g.save();g.translate(24,-118);g.fillStyle='#120a1a';g.beginPath();g.ellipse(0,0,9,6,-.3,0,TAU);g.fill();ell(g,-8,-8,4.5,4.5,'#120a1a');poly(g,[-11,-9,-19,-7,-11,-5],'#c89a2a');ell(g,-9,-9,1.2,1.2,'#ff5a5a');poly(g,[6,2,20,8,8,6],'#120a1a');g.restore();
 g.restore()}

/* crab king */
function crabKing(g,t,o,p){const lg=o.lg||0,col=p.col,hi=shade(col,.32),dk=shade(col,-.45),mid=shade(col,-.2),ol='#000000b0';
 g.save();g.lineJoin='round';g.lineCap='round';if(p.aura)glow(g,0,-70,150,p.aura+'33');
 ell(g,0,0,110,9,'#0005');
 /* six walking legs, three on each side, jointed */
 for(const sd of[-1,1])for(let k=0;k<3;k++){const ph=t*5+k*1.7+(sd>0?2.4:0),sw=Math.sin(ph)*6,lift=Math.max(0,Math.cos(ph))*7,sx=10+sd*(34+k*9),kx=10+sd*(76+k*17),ky=-84+k*10,fx=10+sd*(96+k*19)+sw,c=sd<0?col:dk;
  limb(g,sx,-44,kx,ky,10,'#000000a0');limb(g,kx,ky,fx,-3-lift,8,'#000000a0');limb(g,sx,-44,kx,ky,8.4,c);limb(g,kx,ky,fx,-3-lift,6,c);ell(g,kx,ky,5.4,5.4,hi)}
 /* the far claw sits behind the shell */
 const arm=(k)=>{const bob=Math.sin(t*3+k*2)*4,sx=-56+k*20,sy=-58-k*14,ex=-98+k*14,ey=-98-k*16+bob,wx=-126+k*22-lg*30,wy=-62-k*20+bob-lg*10,sc=1-k*.16,c=k?dk:col,h=k?mid:hi;
  limb(g,sx,sy,ex,ey,k?15:19,ol);limb(g,ex,ey,wx,wy,k?13:16,ol);limb(g,sx,sy,ex,ey,k?12:16,c);limb(g,ex,ey,wx,wy,k?10:13,c);
  ell(g,ex,ey,k?9:11,k?9:11,h);poly(g,[ex-5,ey-6,ex-1,ey-17,ex+5,ey-7],h,ol,1.5);
  g.save();g.translate(wx,wy);g.rotate(-.34+Math.sin(t*3+k*2)*.1-lg*.15);g.scale(sc*1.12,sc*1.12);crabClaw(g,c,h,dk,.3+Math.sin(t*3+k*2)*.18+lg*.55,2.6);g.restore()};
 arm(1);
 /* the shell */
 ell(g,10,-60,82,44,vgr(g,-104,-16,hi,dk));ell(g,10,-44,80,26,'#00000030');
 g.strokeStyle='#00000040';g.lineWidth=2.4;for(let i=0;i<3;i++){g.beginPath();g.ellipse(10,-62,70-i*20,36-i*9,0,Math.PI*1.1,Math.PI*1.9);g.stroke()}
 ell(g,-6,-80,52,16,'#ffffff24');
 for(let i=0;i<12;i++){const a=rnd(i)*TAU,r=Math.sqrt(rnd(i+20)),x=10+Math.cos(a)*r*62,y=-60+Math.sin(a)*r*28;ell(g,x,y,3.4+rnd(i+40)*3,2.6,'#d8d0b88a')}
 for(const x of[-44,-20,4,28,52]){const dy=-60-44*Math.sqrt(Math.max(0,1-Math.pow((x-10)/82,2)));poly(g,[x-7,dy+3,x,dy-17,x+7,dy+3],hi,ol,1.6)}
 /* the crown rests on the shell, the eyes watch on tall stalks */
 g.fillStyle='#ffc94a';g.beginPath();g.moveTo(8,-102);g.lineTo(6,-128);g.lineTo(17,-117);g.lineTo(28,-134);g.lineTo(39,-117);g.lineTo(50,-128);g.lineTo(48,-102);g.closePath();g.fill();g.strokeStyle='#5a3a08';g.lineWidth=2;g.stroke();g.fillStyle='#ffe9a0';g.fillRect(10,-110,36,5);ell(g,28,-118,4,4,p.gem||'#5ae0ff');
 for(const [x,k] of[[-40,0],[-24,1]]){const by=-100+k*2;limb(g,x,by,x-5,by-24,5,dk);glow(g,x-5,by-28,22,(p.e||'#ffe04a')+'66');ell(g,x-5,by-29,9,9,'#f4efd0');ell(g,x-8,by-29,4,6,'#111');poly(g,[x-16,by-40,x+5,by-34,x+4,by-37],'#000a')}
 arm(0);
 g.restore()}

/* CFG-driven humanoids */
CFG.ogre=o=>({lg:o.lg,sk:'#9a6a4a',dk:'#5a3a26',cl:'#3a2a20',hd:17,hunch:1.2,nose:1,tusk:1,eye:'#ff8a2a',wp:'hammer',flame:1,wsc:1.7,bulk:2,lw:14,reach:10,legH:32,belly:1,pad:'#5a5a64',padspike:1,aura:'#ff8a2a',fx:(g,t,q)=>{g.fillStyle='#4a2a1a';g.beginPath();g.moveTo(-18,q.SH+12);g.lineTo(18,q.SH+12);g.lineTo(22,-10);g.lineTo(-22,-10);g.closePath();g.fill();g.strokeStyle='#000a';g.lineWidth=2;g.stroke();for(let i=0;i<3;i++)ell(g,-10+i*10,-38-i*4,3,3,'#c8c0a8')}});
CFG.were=o=>({lg:o.lg,sk:'#7a4a5a',dk:'#3a1a26',hl:'#9a6a7a',fur:'#4a2a36',hd:19,hunch:1.3,nose:1,ear:'pt',fang:1,tusk:0,eye:'#ff3030',bulk:1.9,lw:15,reach:14,legH:30,belly:0,pad:'#4a2a36',padspike:1,tail:1,aura:'#c82a3a',fx:(g,t,q)=>{for(let i=0;i<3;i++){const x=-40-o.lg*14,y=-74-o.lg*18;poly(g,[x-4+i*5,y,x-2+i*5,y-16,x+3+i*5,y+2],'#f4ecd0')}}});
DR.ogre=(g,t,o)=>hum(g,t,CFG.ogre(o));DR.were=(g,t,o)=>hum(g,t,CFG.were(o));

/* dragon */
function dragon(g,t,o,p){const lg=o.lg||0,col=p.col,hi=shade(col,.3),dk=shade(col,-.5),be=p.belly||'#e8d8a0',fl=Math.sin(t*2.4);
 g.save();g.lineJoin='round';g.lineCap='round';if(p.aura)glow(g,0,-100,140,p.aura+'44');
 const wing=(k)=>{g.save();g.translate(24,-122);g.rotate(-.1+fl*.14+k*.16);const q=[[-4,-4],[36,-110],[92,-124],[132,-80],[122,-30],[70,-20],[30,-2]];g.beginPath();g.moveTo(0,0);g.lineTo(38,-108);g.quadraticCurveTo(70,-112,92,-124);g.quadraticCurveTo(112,-108,134,-84);g.quadraticCurveTo(114,-78,124,-32);g.quadraticCurveTo(90,-46,70,-22);g.quadraticCurveTo(50,-30,30,0);g.closePath();g.fillStyle=k?shade(p.wing||col,-.4):(p.wing||shade(col,-.1));g.fill();g.strokeStyle='#000b';g.lineWidth=2;g.stroke();g.strokeStyle=shade(col,.2);g.lineWidth=3.4;for(const [x,y] of[[38,-108],[92,-124],[134,-84],[124,-32]]){g.beginPath();g.moveTo(0,0);g.lineTo(x,y);g.stroke()}g.restore()};
 wing(1);
 // tail
 for(let j=0;j<18;j++){const u=j/17,x=56+u*110,y=-40+Math.sin(u*3+t*2.4)*14*u+u*24,r=lerp(24,3,u);if(j%2===0&&j>1)poly(g,[x-4,y-r,x,y-r-14,x+5,y-r],hi,'#000a',1);ell(g,x,y,r,r*.9,vgr(g,y-r,y+r,col,dk))}
 // hind leg
 limb(g,20,-64,34,-32,26,dk);limb(g,34,-32,20,-6,15,dk);poly(g,[4,-2,32,-2,34,-10,10,-14],dk,'#000a',1.5);for(let i=0;i<3;i++)poly(g,[2+i*8,-2,5+i*8,-2,-2+i*8,-9],'#e8dcc0');
 // body
 ell(g,10,-86,66,46,vgr(g,-134,-40,hi,dk));ell(g,-8,-70,40,30,vgr(g,-100,-40,be,shade(be,-.3)));for(let i=0;i<6;i++){g.strokeStyle='#0002';g.lineWidth=1.6;g.beginPath();g.moveTo(-40,-84+i*7);g.quadraticCurveTo(-8,-78+i*7,20,-84+i*7);g.stroke()}
 for(let i=0;i<7;i++)poly(g,[-20+i*14,-126+Math.abs(i-3)*3,-14+i*14,-140+Math.abs(i-3)*3,-8+i*14,-126+Math.abs(i-3)*3],hi,'#000a',1.2);
 // fore leg
 limb(g,-16,-66,-34-lg*22,-36,16,col);limb(g,-34-lg*22,-36,-52-lg*40,-14-lg*10,12,col);for(let i=0;i<3;i++)poly(g,[-60-lg*40+i*7,-10-lg*10,-56-lg*40+i*7,-18-lg*10,-64-lg*40+i*7,-6-lg*10],'#e8dcc0','#000a',1);
 // neck
 for(let j=0;j<10;j++){const u=j/9,x=-30-u*60-Math.sin(u*3)*4,y=-100-u*66+Math.sin(t*2+u*4)*3,r=lerp(24,15,u);ell(g,x,y,r,r,vgr(g,y-r,y+r,hi,col))}
 // head
 const hx=-100-lg*20,hy=-168;g.save();g.translate(hx,hy);g.rotate(.15+lg*.2);
 for(const k of[0,1]){g.strokeStyle=k?dk:'#e8dcc0';g.lineWidth=6;g.beginPath();g.moveTo(10+k*8,-14);g.quadraticCurveTo(28+k*8,-34,44+k*8,-30);g.stroke()}
 poly(g,[12,-18,-44,-8,-56,6,-40,14,12,16],vgr(g,-18,16,hi,col),'#000a',2.5);
 const op=.12+lg*.5+Math.max(0,Math.sin(t*2))*.15;g.save();g.translate(4,12);g.rotate(op);poly(g,[8,0,-46,-2,-50,10,-30,14,8,10],dk,'#000a',2.5);for(let i=0;i<4;i++)poly(g,[-6-i*9,-1,-2-i*9,-1,-4-i*9,-10],'#f4ecd0');g.restore();
 for(let i=0;i<4;i++)poly(g,[-14-i*9,6,-10-i*9,6,-12-i*9,15],'#f4ecd0');
 eye(g,-12,-5,4.4,p.e||'#ffdd33');g.strokeStyle='#000c';g.lineWidth=2.6;g.beginPath();g.moveTo(-22,-13);g.lineTo(0,-8);g.stroke();
 if(lg>.2||Math.sin(t*2)>.6){glow(g,-56,10,44+lg*30,(p.f||'#ff7a1a')+'aa')}
 g.restore();
 wing(0);
 g.restore()}

/* sea serpent */
function seaSerpent(g,t,o,p){const lg=o.lg||0,col=p.col,hi=shade(col,.3),dk=shade(col,-.5);
 g.save();g.lineJoin='round';g.lineCap='round';if(p.aura)glow(g,0,-100,140,p.aura+'33');
 for(let i=0;i<3;i++){g.strokeStyle=`rgba(180,230,255,${.45-i*.12})`;g.lineWidth=3;g.beginPath();g.ellipse(30,-4,60+i*26+Math.sin(t*2+i)*4,10+i*4,0,0,TAU);g.stroke()}
 const pts=[];for(let j=0;j<=44;j++){const u=j/44,x=34+Math.sin(u*6.6-t*2)*26*(.35+u*.65)-u*u*70-lg*u*30,y=-u*178-2;pts.push([x,y,lerp(30,17,u)])}
 for(let j=0;j<pts.length;j++){const [x,y,r]=pts[j];if(j>2&&j%3===0)poly(g,[x+r*.8,y+4,x+r+18,y-10,x+r*.8,y-14],dk,'#000a',1.2)}
 for(let j=0;j<pts.length;j++){const [x,y,r]=pts[j];ell(g,x,y,r,r*.8,hgr(g,x-r,x+r,hi,dk));if(j%2===0){g.strokeStyle='#0003';g.lineWidth=1.6;g.beginPath();g.ellipse(x,y,r*.5,r*.7,0,-1.4,1.4);g.stroke()}ell(g,x-r*.5,y,r*.3,r*.55,shade(p.bel||'#e8d8a0',-.05))}
 const [hx,hy]=pts[44],[px,py]=pts[42];
 g.save();g.translate(hx-6,hy-4);g.rotate(Math.atan2(hy-py,hx-px)*0+.2+lg*.15);
 for(let i=0;i<5;i++)poly(g,[6,-14+i*3,32+Math.sin(t*4+i)*4,-24+i*7,10,-6+i*4],p.fin||'#ff6a5a','#000a',1);
 poly(g,[12,-18,-40,-10,-58,4,-40,12,12,14],vgr(g,-18,14,hi,col),'#000a',2.5);
 const op=.14+lg*.55+Math.max(0,Math.sin(t*2.4))*.16;g.save();g.translate(2,10);g.rotate(op);poly(g,[8,0,-46,-2,-56,10,-30,15,8,10],dk,'#000a',2.5);for(let i=0;i<4;i++)poly(g,[-6-i*10,-1,-2-i*10,-1,-4-i*10,-12],'#f4ecd0');g.restore();
 for(let i=0;i<4;i++)poly(g,[-14-i*10,5,-10-i*10,5,-12-i*10,14],'#f4ecd0');
 eye(g,-10,-5,4.4,p.e||'#7fffd0');g.restore();
 g.restore()}

/* treant */
function treant(g,t,o,p){const lg=o.lg||0,S=Math.sin(t*2.4),bob=Math.abs(Math.cos(t*2.4))*2.4,bk=p.bark||'#5a3a22',dk=shade(bk,-.45),hi=shade(bk,.3);
 g.save();g.lineJoin='round';g.lineCap='round';if(p.aura)glow(g,0,-120,140,p.aura+'44');
 for(const k of[1,0]){const f=(k?-S:S)*8,x=-2-k*22;limb(g,x+6,-50,x+f,-14,26,k?dk:bk);limb(g,x+f,-14,x-8+f,-2,20,k?dk:bk);for(let i=0;i<4;i++)limb(g,x+f-6,-4,x-22+f+i*9,3,4,k?dk:bk)}
 g.translate(0,-bob);
 const branch=(sx,sy,fx,fy,w,c,leafy)=>{const mx=(sx+fx)/2,my=(sy+fy)/2-16;limb(g,sx,sy,mx,my,w,c);limb(g,mx,my,fx,fy,w*.7,c);for(let i=0;i<4;i++){const a=i/3;limb(g,fx,fy,fx+(i-1.5)*13,fy-18-Math.sin(t*3+i)*3,4,c)}if(leafy)for(let i=0;i<4;i++)ell(g,fx+(i-1.5)*13,fy-22,10,8,p.leaf?p.leaf[i%p.leaf.length]:'#4a9a3a')};
 branch(28,-140,44,-92+Math.sin(t*2)*6,18,dk,1);
 // trunk
 g.beginPath();g.moveTo(-34,-52);g.quadraticCurveTo(-46,-100,-34,-150);g.lineTo(34,-150);g.quadraticCurveTo(46,-100,34,-52);g.quadraticCurveTo(0,-40,-34,-52);g.fillStyle=hgr(g,-40,40,hi,dk);g.fill();g.strokeStyle='#000b';g.lineWidth=2.4;g.stroke();
 g.strokeStyle='#0004';g.lineWidth=2;for(let i=0;i<7;i++){g.beginPath();g.moveTo(-28+i*9.5,-52);g.quadraticCurveTo(-32+i*9.5+Math.sin(i)*6,-100,-28+i*9.5,-150);g.stroke()}
 ell(g,4,-84,10,16,'#00000066');
 // face
 poly(g,[-28,-132,-8,-124,-12,-116,-30,-120],'#0a0604','#000',1);poly(g,[4,-124,24,-132,24,-120,8,-116],'#0a0604','#000',1);eye(g,-18,-122,5,p.e||'#ffb03a');eye(g,14,-122,4,p.e||'#ffb03a');
 g.fillStyle='#0a0604';g.beginPath();g.moveTo(-22,-100);g.quadraticCurveTo(-4,-90-lg*10,16,-100);g.quadraticCurveTo(-4,-108,-22,-100);g.fill();
 g.strokeStyle='#000';g.lineWidth=3;g.beginPath();g.moveTo(-32,-138);g.lineTo(-6,-128);g.moveTo(30,-140);g.lineTo(6,-128);g.stroke();
 // front arm
 branch(-30,-138,-70-lg*44,-88-lg*22+Math.sin(t*2.4)*5,20,bk,1);
 // canopy
 const lc=p.leaf||['#3a8a3a','#4aa84a','#2a6a2a'];
 for(let i=0;i<22;i++){const a=i/22*TAU,r=44+rnd(i)*34,x=Math.cos(a)*r*1.05,y=-176+Math.sin(a)*r*.45-Math.abs(Math.cos(a))*4;ell(g,x,y,22+rnd(i+5)*10,16+rnd(i+9)*6,lc[i%lc.length])}
 for(let i=0;i<14;i++){ell(g,-46+i*7,-190-Math.sin(i)*6,16,11,lc[(i+1)%lc.length])}
 if(p.lanterns){for(const [x,y] of[[-60,-150],[58,-148],[-24,-168],[24,-170],[0,-150]]){const sw=Math.sin(t*2+x)*3;g.strokeStyle='#2a1a10';g.lineWidth=1.6;g.beginPath();g.moveTo(x,y-14);g.lineTo(x+sw,y);g.stroke();glow(g,x+sw,y+8,30,'#ffcf5aaa');poly(g,[x+sw-6,y,x+sw+6,y,x+sw+5,y+16,x+sw-5,y+16],'#ffe08a','#5a3a10',1.6)}}
 if(p.crown){g.fillStyle='#ffc94a';g.beginPath();g.moveTo(-26,-196);g.lineTo(-28,-216);g.lineTo(-14,-206);g.lineTo(0,-224);g.lineTo(14,-206);g.lineTo(28,-216);g.lineTo(26,-196);g.closePath();g.fill();g.strokeStyle='#5a3a08';g.lineWidth=1.6;g.stroke();ell(g,0,-206,4,4,'#e8455a')}
 g.restore()}

/* reaper */
function reaper(g,t,o,p){const lg=o.lg||0,hv=Math.sin(t*2.2)*6,gl=p.g||'#7dffb0';
 g.save();g.lineJoin='round';g.lineCap='round';glow(g,0,-100,120,gl+'44');
 // wisps at base
 for(let i=0;i<8;i++){const ph=(t*.7+i*.13)%1,x=-40+i*14+Math.sin(t*2+i)*8,y=-6-ph*30;ell(g,x,y,7*(1-ph),12*(1-ph),gl+Math.floor((1-ph)*90).toString(16).padStart(2,'0'))}
 g.translate(0,-hv);
 // cloak tail
 g.fillStyle=vgr(g,-150,-10,'#1a1a28','#04040a');g.beginPath();g.moveTo(-24,-140);g.quadraticCurveTo(-46,-80,-44+Math.sin(t*3)*6,-8);
 for(let i=0;i<7;i++)g.lineTo(-44+i*14+Math.sin(t*3+i)*5,-8+(i%2?-16:8)+Math.sin(t*2+i)*4);
 g.quadraticCurveTo(50,-80,22,-140);g.closePath();g.fill();g.strokeStyle='#000';g.lineWidth=2;g.stroke();
 g.strokeStyle=gl+'55';g.lineWidth=1.6;for(let i=0;i<5;i++){g.beginPath();g.moveTo(-20+i*10,-130);g.quadraticCurveTo(-30+i*12+Math.sin(t*2+i)*4,-70,-34+i*14,-20);g.stroke()}
 // chains
 g.strokeStyle='#8a8a98';g.lineWidth=2.4;g.setLineDash([5,3]);g.beginPath();g.moveTo(-18,-116);g.quadraticCurveTo(0,-84,18,-118);g.stroke();g.setLineDash([]);
 // back arm
 limb(g,16,-124,30,-100,9,'#2a2a3a');
 // scythe (rear hand)
 const hx=-46-lg*22,hy=-100-lg*20;
 limb(g,-14,-124,-30,-112,11,'#2a2a3a');limb(g,-30,-112,hx,hy,9,'#e0dcc8');
 g.save();g.translate(hx,hy);g.rotate(-.12-lg*.7);mweap(g,'scythe',{bl:'#cfd8e0',orb:gl,wsc:1.35},t);g.restore();
 for(let i=0;i<4;i++)limb(g,hx,hy,hx-4-i*2,hy+8,2.4,'#e0dcc8');
 // hood
 const cx=-6,cy=-150;g.beginPath();g.moveTo(cx-30,cy+28);g.quadraticCurveTo(cx-34,cy-22,cx-2,cy-40);g.quadraticCurveTo(cx+30,cy-24,cx+30,cy+28);g.closePath();g.fillStyle=hgr(g,cx-30,cx+30,'#2a2a3c','#0a0a12');g.fill();g.strokeStyle='#000';g.lineWidth=2.4;g.stroke();
 ell(g,cx-6,cy+2,20,22,'#020204');ell(g,cx-8,cy+4,13,15,'#e0dcc8');ell(g,cx-13,cy,4.4,5.4,'#050306');ell(g,cx-2,cy,3.4,4.6,'#050306');eye(g,cx-13,cy,2.8,gl);eye(g,cx-2,cy,2.2,gl);poly(g,[cx-10,cy+8,cx-6,cy+8,cx-8,cy+13],'#050306');g.fillStyle='#050306';for(let i=0;i<4;i++)g.fillRect(cx-14+i*4,cy+16,1.4,5);
 g.strokeStyle=gl+'aa';g.lineWidth=2;g.beginPath();g.moveTo(cx-34,cy-4);g.quadraticCurveTo(cx-20,cy-42,cx+4,cy-40);g.stroke();
 g.restore()}

/* mantis empress */
function mantis(g,t,o,p){const lg=o.lg||0,col=p.col,hi=shade(col,.32),dk=shade(col,-.45),sw=Math.sin(t*2.6);
 g.save();g.lineJoin='round';g.lineCap='round';if(p.aura)glow(g,0,-90,120,p.aura+'44');
 for(let i=0;i<3;i++)for(const k of[1,0]){const x=14+i*16+k*4,ph=t*4+i*2+k*3,fx=x+(k?28:-6)+Math.sin(ph)*6,fy=-3-Math.max(0,Math.cos(ph))*5,kx=x+(k?36:8),ky=-70-i*2;limb(g,x,-44,kx,ky,6,k?dk:col);limb(g,kx,ky,fx,fy,4.4,k?dk:col)}
 // wings
 g.save();g.translate(30,-100);g.rotate(.2);for(let k=0;k<2;k++){g.fillStyle=k?shade(p.wing||hi,-.3)+'cc':(p.wing||hi)+'dd';g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(50,-16+k*8+Math.sin(t*3)*2,110,10+k*10);g.quadraticCurveTo(50,22+k*8,0,4);g.fill();g.strokeStyle='#0006';g.lineWidth=1.2;g.beginPath();g.moveTo(0,2);g.lineTo(100,10+k*10);g.stroke()}g.restore();
 // abdomen
 g.save();g.translate(40,-60);g.rotate(.5);ell(g,0,0,52,17,vgr(g,-17,17,hi,dk));for(let i=0;i<7;i++){g.strokeStyle='#0004';g.lineWidth=1.6;g.beginPath();g.ellipse(-36+i*11,0,2,15,0,0,TAU);g.stroke()}g.restore();
 // thorax
 g.save();g.translate(4,-70);g.rotate(-.5);ell(g,0,-30,15,54,hgr(g,-15,15,hi,dk));g.strokeStyle='#0004';g.lineWidth=1.6;for(let i=0;i<5;i++){g.beginPath();g.moveTo(-14,-56+i*12);g.lineTo(14,-52+i*12);g.stroke()}g.restore();
 // raptorial arms
 const arm=(k)=>{const sx=-12,sy=-110+k*3,ex=-56,ey=-128+k*8+sw*3,fx=-82-lg*32-k*6,fy=-70+k*8-lg*18;limb(g,sx,sy,ex,ey,11,k?dk:col);for(let i=0;i<5;i++)poly(g,[sx-8-i*9,sy-6+i*-3.6,sx-14-i*9,sy-16+i*-3.6,sx-18-i*9,sy-4+i*-3.6],'#f0e8c8');limb(g,ex,ey,fx,fy,10,k?dk:hi);for(let i=0;i<5;i++)poly(g,[ex-8-i*4,ey+8+i*10,ex-24-i*4,ey+16+i*10,ex-6-i*4,ey+14+i*10],'#f0e8c8');poly(g,[fx-4,fy-4,fx-14,fy+16,fx+2,fy+2],'#f0e8c8','#000a',1.2)};
 arm(1);
 // head
 const hx=-24,hy=-152;limb(g,-12,-122,hx,hy+10,9,col);
 g.beginPath();g.moveTo(hx-26,hy-12);g.lineTo(hx+22,hy-12);g.lineTo(hx+8,hy+24);g.lineTo(hx-8,hy+24);g.closePath();g.fillStyle=vgr(g,hy-12,hy+24,hi,dk);g.fill();g.strokeStyle='#000a';g.lineWidth=2;g.stroke();
 ell(g,hx-15,hy,11,15,rgr(g,hx-18,hy-4,1,16,'#ffe08a',p.e||'#2ac88a'));ell(g,hx+9,hy-2,9,13,rgr(g,hx+6,hy-6,1,14,'#ffe08a',p.e||'#2ac88a'));ell(g,hx-18,hy-5,3,3,'#fff');
 poly(g,[hx-8,hy+22,hx-2,hy+30,hx+4,hy+22],dk);
 for(const k of[0,1]){g.strokeStyle=dk;g.lineWidth=2;g.beginPath();g.moveTo(hx-8+k*10,hy-12);g.quadraticCurveTo(hx-30+k*10,hy-44+Math.sin(t*4+k)*3,hx-56+k*16,hy-36);g.stroke()}
 if(p.crown){g.fillStyle='#ffc94a';g.beginPath();g.moveTo(hx-22,hy-12);g.lineTo(hx-26,hy-34);g.lineTo(hx-12,hy-24);g.lineTo(hx,hy-40);g.lineTo(hx+12,hy-24);g.lineTo(hx+20,hy-32);g.lineTo(hx+18,hy-12);g.closePath();g.fill();g.strokeStyle='#5a3a08';g.lineWidth=1.6;g.stroke();ell(g,hx,hy-22,3.4,3.4,'#e8455a')}
 arm(0);
 g.restore()}

/* djinn (ice sovereign) */
function djinn(g,t,o,p){const lg=o.lg||0,col=p.col,hi=shade(col,.35),dk=shade(col,-.5),hv=Math.sin(t*2)*7;
 g.save();g.lineJoin='round';g.lineCap='round';glow(g,0,-110,150,(p.g||'#8ad8ff')+'44');
 // swirling tail
 for(let j=0;j<26;j++){const u=j/25,a=u*7+t*2.2,x=Math.sin(a)*(30*(1-u)+4)+u*20,y=-104+hv+u*98+Math.cos(a)*4*(1-u),r=lerp(34,3,u);ell(g,x,y,r,r*.62,rgr(g,x-r*.3,y-r*.3,1,r*1.1,`rgba(${210-u*60|0},${240-u*30|0},255,${.95-u*.5})`,`rgba(70,130,220,${.9-u*.5})`))}
 g.save();g.translate(0,hv);
 // back arm
 limb(g,14,-140,44,-122,14,dk);limb(g,44,-122,60,-152+Math.sin(t*2.6)*4,12,dk);glow(g,62,-158,34,(p.g||'#8ad8ff')+'aa');
 // torso
 g.beginPath();g.moveTo(-32,-150);g.quadraticCurveTo(-38,-116,-20,-100);g.lineTo(20,-100);g.quadraticCurveTo(38,-116,32,-150);g.closePath();g.fillStyle=hgr(g,-34,34,hi,dk);g.fill();g.strokeStyle='#000b';g.lineWidth=2;g.stroke();
 g.strokeStyle='#ffffff40';g.lineWidth=1.6;g.beginPath();g.moveTo(0,-148);g.lineTo(0,-104);g.moveTo(-18,-136);g.quadraticCurveTo(0,-126,18,-136);g.stroke();
 g.fillStyle='#ffd76a';g.fillRect(-26,-124,52,7);g.fillRect(-22,-106,44,5);ell(g,0,-120.5,5,5,p.gem||'#5ae0ff');
 for(const [x,k] of[[-34,0],[34,1]]){for(let i=0;i<4;i++)poly(g,[x-7+i*4,-152,x+(k?1:-1)*(4+i*3),-172-i*6,x+3+i*4,-152],'#cfeeff','#2a5a8a',1.4);ell(g,x,-150,14,10,'#ffd76a')}
 // front arm
 const hx=-68-lg*30,hy=-134-lg*16+Math.sin(t*2.3)*4;limb(g,-28,-144,-52,-124,15,col);limb(g,-52,-124,hx,hy,13,hi);ell(g,hx,hy,10,10,hi);ell(g,-52,-124,8,8,'#ffd76a');
 for(let i=0;i<8;i++){const a=t*3+i*.8;glow(g,hx+Math.cos(a)*14,hy-10-Math.abs(Math.sin(a))*16,9,'#bfeaffcc')}
 glow(g,hx,hy-18,44,(p.g||'#8ad8ff')+'88');for(let i=0;i<5;i++)poly(g,[hx-6+i*3,hy-10,hx-10+i*5,hy-34-i%2*10,hx-2+i*5,hy-10],'#e8f8ff','#2a5a8a',1);
 // head
 const cx=-6,cy=-172;limb(g,cx,cy+10,0,-148,14,col);ell(g,cx,cy,19,21,rgr(g,cx-6,cy-6,2,26,hi,col));
 g.fillStyle='#e8f4ff';g.beginPath();g.moveTo(cx-14,cy+8);g.quadraticCurveTo(cx-12,cy+40,cx-2,cy+46);g.quadraticCurveTo(cx+10,cy+40,cx+14,cy+8);g.quadraticCurveTo(cx,cy+18,cx-14,cy+8);g.fill();g.strokeStyle='#8ab8d8';g.lineWidth=1.4;g.stroke();
 eye(g,cx-9,cy-3,3.8,p.e||'#bff0ff');eye(g,cx+6,cy-4,3,p.e||'#bff0ff');g.strokeStyle='#000c';g.lineWidth=2.4;g.beginPath();g.moveTo(cx-15,cy-11);g.lineTo(cx-2,cy-6);g.stroke();
 for(let i=0;i<7;i++){const a=-2.6+i*.4,L=26+(i%2)*14+(i===3?12:0);poly(g,[cx+Math.cos(a)*15-3,cy-4+Math.sin(a)*17,cx+Math.cos(a)*(15+L),cy-4+Math.sin(a)*(17+L),cx+Math.cos(a)*15+3,cy-4+Math.sin(a)*17],'#dff6ff','#2a5a8a',1.4)}
 g.restore();g.restore()}

/* sea king */
function seaKing(g,t,o,p){const lg=o.lg||0,col=p.col,hi=shade(col,.32),dk=shade(col,-.5),sk=p.sk||'#4a9aa8',sw=Math.sin(t*2.4);
 g.save();g.lineJoin='round';g.lineCap='round';if(p.aura)glow(g,0,-110,150,p.aura+'44');
 for(let i=0;i<3;i++){g.strokeStyle=`rgba(180,230,255,${.4-i*.1})`;g.lineWidth=3;g.beginPath();g.ellipse(36,-4,60+i*24+Math.sin(t*2+i)*4,10+i*4,0,0,TAU);g.stroke()}
 // tail
 const tp=[];for(let j=0;j<=12;j++){const u=j/12;tp.push([10+u*74+Math.sin(u*5-t*2.6)*10*u,-96+Math.sin(u*Math.PI*.9)*-6+u*u*92-u*10,lerp(28,9,u)])}
 for(let j=0;j<tp.length;j++){const [x,y,r]=tp[j];ell(g,x,y,r,r,hgr(g,x-r,x+r,hi,dk));for(let k=0;k<3;k++)ell(g,x-r*.3+k*r*.3,y-r*.3+k*r*.25,r*.34,r*.34,'#ffffff18')}
 {const [x,y]=tp[12];g.save();g.translate(x,y);g.rotate(-.4+sw*.25);poly(g,[0,0,30,-26,22,-4,32,14,0,4],vgr(g,-26,14,p.fin||'#ffd76a',dk),'#000a',2);g.restore()}
 g.save();g.translate(0,-Math.abs(sw)*2);
 // cape
 g.fillStyle=p.cape||'#1a4a6a';g.beginPath();g.moveTo(10,-160);g.quadraticCurveTo(72,-130+Math.sin(t*3)*6,60+Math.sin(t*3)*8,-60);g.lineTo(14,-100);g.closePath();g.fill();g.strokeStyle='#000a';g.lineWidth=2;g.stroke();
 limb(g,14,-150,34,-128,15,shade(sk,-.3));
 // torso
 g.beginPath();g.moveTo(-32,-160);g.quadraticCurveTo(-38,-120,-22,-96);g.lineTo(22,-96);g.quadraticCurveTo(38,-120,32,-160);g.closePath();g.fillStyle=hgr(g,-34,34,shade(sk,.25),shade(sk,-.4));g.fill();g.strokeStyle='#000b';g.lineWidth=2;g.stroke();
 for(let i=0;i<12;i++){const x=-16+(i%4)*10,y=-144+Math.floor(i/4)*14;g.strokeStyle='#0003';g.lineWidth=1.4;g.beginPath();g.arc(x,y,6,0,Math.PI);g.stroke()}
 poly(g,[-28,-158,28,-118,28,-108,-28,-148],'#ffd76a','#5a3a08',1.6);ell(g,0,-134,6,6,'#eafff8');
 for(const [x,k] of[[-34,0],[34,1]]){g.beginPath();g.ellipse(x,-158,17,12,0,Math.PI,TAU);g.fillStyle=k?shade('#e8a8b8',-.3):'#e8a8b8';g.fill();g.strokeStyle='#000b';g.lineWidth=2;g.stroke();g.strokeStyle='#0004';g.lineWidth=1.4;for(let i=-1;i<=1;i++){g.beginPath();g.moveTo(x,-158);g.lineTo(x+i*8,-168);g.stroke()}}
 // front arm + trident
 const hx=-58-lg*30,hy=-124-lg*18;limb(g,-28,-152,-46,-132,15,sk);limb(g,-46,-132,hx,hy,13,shade(sk,.1));ell(g,hx,hy,9,9,shade(sk,.1));
 g.save();g.translate(hx,hy);g.rotate(-.1-lg*.5);mweap(g,'trident',{orb:p.g||'#5ae0ff',wsc:1.5},t);g.restore();
 // head
 const cx=-6,cy=-184;limb(g,cx,cy+10,0,-158,15,sk);ell(g,cx,cy,19,21,rgr(g,cx-6,cy-6,2,26,shade(sk,.3),sk));
 g.fillStyle='#e8f4f0';g.beginPath();g.moveTo(cx-14,cy+8);g.quadraticCurveTo(cx-14,cy+36,cx-4,cy+44);g.quadraticCurveTo(cx+10,cy+36,cx+14,cy+8);g.quadraticCurveTo(cx,cy+18,cx-14,cy+8);g.fill();g.strokeStyle='#8ab8b8';g.lineWidth=1.4;g.stroke();
 for(const k of[0,1])poly(g,[cx-16+k*30,cy-4,cx-34+k*46,cy-14,cx-20+k*36,cy+6],'#3a8a98','#000a',1.4);
 eye(g,cx-9,cy-3,3.8,p.e||'#7fffe0');eye(g,cx+6,cy-4,3,p.e||'#7fffe0');g.strokeStyle='#000c';g.lineWidth=2.4;g.beginPath();g.moveTo(cx-15,cy-11);g.lineTo(cx-2,cy-6);g.stroke();
 g.fillStyle='#ffc94a';g.beginPath();g.moveTo(cx-18,cy-14);g.lineTo(cx-22,cy-38);g.lineTo(cx-10,cy-26);g.lineTo(cx-1,cy-44);g.lineTo(cx+10,cy-26);g.lineTo(cx+22,cy-38);g.lineTo(cx+18,cy-14);g.closePath();g.fill();g.strokeStyle='#5a3a08';g.lineWidth=1.6;g.stroke();ell(g,cx-1,cy-26,3.6,3.6,'#eafff8');ell(g,cx-13,cy-24,2.4,2.4,'#e8455a');
 g.restore();g.restore()}

/* ---- registry ---- */
const KN={warlord:{a:'#7a3a2a',b:'#c9a545',cape:'#5a0e14',crest:'#c82a2a',spikes:1,e:'#ff6a3a',wp:'gsword',bl:'#b8c0c8',aura:'#ff4a2a'},
 marshal:{a:'#8a94a8',b:'#3a6ac8',cape:'#1a2a5a',shield:'#5a7ac8',crest:'#3a6ac8',e:'#8ad8ff',bl:'#dde6f0',tab:'#e8e8f0'},
 tyrant:{a:'#3a2a5a',b:'#8a2ac8',cape:'#1a0a2a',horns:1,crown:1,e:'#d86aff',bl:'#a89ad8',flame:'#b04aff',aura:'#8a2ac8',gem:'#d86aff',emb:'#c86aff'}};
Object.assign(DR,{
 scarecrow,warlord:(g,t,o)=>knightB(g,t,o,KN.warlord),marshal:(g,t,o)=>knightB(g,t,o,KN.marshal),tyrantK:(g,t,o)=>knightB(g,t,o,KN.tyrant),
 hydra:(g,t,o)=>hydra(g,t,o,{col:'#4a8a3a',sp:'#ffd76a',e:'#ffe04a',aura:'#7dff7a'}),
 golemS:(g,t,o)=>golem(g,t,o,{c:'#8a8a94',g:'#6ad0ff',x:'moss',aura:'#6ad0ff'}),
 golemI:(g,t,o)=>golem(g,t,o,{c:'#a8d0e8',g:'#e8faff',x:'ice',aura:'#8ad8ff'}),
 golemL:(g,t,o)=>golem(g,t,o,{c:'#3a2a26',g:'#ff8a2a',x:'lava',aura:'#ff5a1a'}),
 wasp:(g,t,o)=>wasp(g,t,o,{col:'#ffc21a',g:'#b8ff3a',e:'#ff3a3a',aura:'#e8d81a'}),ogre:DR.ogre,were:DR.were,
 scorpK:(g,t,o)=>scorpKing(g,t,o,{col:'#c8a04a',g:'#ffcf3a',e:'#ff4a2a',crown:1,aura:'#ffcf3a'}),
 angler:(g,t,o)=>angler(g,t,o,{col:'#2a4a7a',g:'#6ae0ff',aura:'#6ae0ff'}),
 thunder:(g,t,o)=>thunderbird(g,t,o,{col:'#4a5ab8',g:'#ffe04a',e:'#ffe04a'}),
 witch:(g,t,o)=>witch(g,t,o,{g:'#7dff7a',e:'#ff5a9a'}),
 crabK:(g,t,o)=>crabKing(g,t,o,{col:'#c8342a',e:'#ffe04a',gem:'#5ae0ff',aura:'#ff4a3a'}),
 serpent:(g,t,o)=>seaSerpent(g,t,o,{col:'#1a7a8a',fin:'#ff6a8a',bel:'#e8e0b8',e:'#7fffd0',aura:'#20c8d0'}),
 dragonB:(g,t,o)=>dragon(g,t,o,{col:'#3a5a9a',wing:'#2a3a6a',belly:'#c8d8f0',f:'#8ab8ff',e:'#e8f4ff',aura:'#6a9aff'}),
 dragonR:(g,t,o)=>dragon(g,t,o,{col:'#a82a1e',wing:'#5a0a10',belly:'#e8c880',f:'#ff7a1a',e:'#ffdd33',aura:'#ff4a1a'}),
 treant:(g,t,o)=>treant(g,t,o,{bark:'#5a3a22',leaf:['#c88a2a','#e8a83a','#a86a1a','#6a8a2a'],lanterns:1,crown:1,e:'#ffcf5a',aura:'#ffb03a'}),
 reaper:(g,t,o)=>reaper(g,t,o,{g:'#7dffb0'}),
 mantis:(g,t,o)=>mantis(g,t,o,{col:'#d8407a',wing:'#ff9ac8',e:'#ffe04a',crown:1,aura:'#ff5aa0'}),
 djinn:(g,t,o)=>djinn(g,t,o,{col:'#5a90d8',g:'#8ad8ff',gem:'#5ae0ff',e:'#e8faff'}),
 seaKing:(g,t,o)=>seaKing(g,t,o,{col:'#1a8a98',sk:'#4a9aa8',fin:'#ffd76a',cape:'#1a4a6a',g:'#5ae0ff',e:'#7fffe0',aura:'#20c8d0'})});
Object.assign(MON,{
 scarecrow:{n:'Scarecrow King',h:350,sp:56,th:205,boss:1},warlord:{n:'Warlord Gorath',h:360,sp:56,th:165,boss:1},marshal:{n:'Iron Marshal',h:360,sp:54,th:170,boss:1},tyrantK:{n:'Citadel Tyrant',h:380,sp:56,th:200,boss:1},
 hydra:{n:'Bog Hydra',h:340,sp:56,th:190,tw:280,boss:1},golemS:{n:'Grave Warden',h:380,sp:50,th:190,boss:1},golemI:{n:'Winter Warden',h:380,sp:50,th:200,boss:1},golemL:{n:'Lava Colossus',h:400,sp:50,th:215,boss:1},
 wasp:{n:'Hive Empress',h:320,sp:62,th:150,tw:220,boss:1},ogre:{n:'Forge Overseer',h:370,sp:52,th:125,boss:1},were:{n:'Blood Chieftain',h:350,sp:60,th:125,boss:1},
 scorpK:{n:'Sand Tyrant',h:320,sp:56,th:160,tw:280,boss:1,cx:-20},angler:{n:'Abyssal Angler',h:340,sp:54,th:220,tw:290,boss:1},thunder:{n:'Storm Roc',h:390,sp:58,th:240,tw:260,boss:1},
 witch:{n:'Coven Mother',h:340,sp:56,th:225,boss:1},crabK:{n:'Crimson Crab King',h:310,sp:54,th:155,tw:340,boss:1,cx:-26},serpent:{n:'Grotto Leviathan',h:400,sp:54,th:215,tw:200,boss:1},
 dragonB:{n:'Thunder Drake',h:400,sp:58,th:230,tw:320,boss:1,cx:30},dragonR:{n:'Dragon Tyrant',h:400,sp:58,th:230,tw:320,boss:1,cx:30},treant:{n:'Twilight King',h:400,sp:48,th:230,boss:1},
 reaper:{n:'Necropolis Sovereign',h:370,sp:58,th:200,boss:1},mantis:{n:'Mantis Empress',h:340,sp:60,th:180,boss:1},djinn:{n:'Frozen Sovereign',h:380,sp:56,th:215,boss:1},seaKing:{n:'Abyssal King',h:400,sp:54,th:225,boss:1}});
for(const k in MON)MON[k].d=DR[k];
