# python3 t_td99.py [game.html] : Runestone Tower Defense 9.9 (95u, 95v) - the Alchemist's Still: registry, bar and key, targeting
# (ground groups, no flyers, leading), soaking and armor melt (restored when it dries, read by every tower), the overflow damage bonus,
# puddles, Midas coins, Mythic glue, Celestial gold, Overcharge, upgrades and selling, art, the info panel, frame cost and a
# Wonderland wave with stills.
import asyncio,os,re,sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
HELP=re.search(r'HELP=r"""(.*?)"""',open(os.path.join(HERE,'t_td96.py')).read(),re.S).group(1)
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:500]),flush=True)
    if not ok:FAIL.append(name)
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E("()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const T=RPP().tut;for(const k of['build','wave','coins','upgrade','abil','twist_frost','twist_ember','twist_wonder'])T[k]=1;RPP().stars.ember=1;RPP().dragon=1}")
        await E(HELP)
        # a still on a pad with ground monsters placed on the road at a chosen distance; returns [R,tw,list,spot]
        await E("""()=>{window.alSet=(tier,dist,n,id,opt)=>{opt=opt||{};const R=tdNew('wonder',6);const pads=[...R.pads].sort((a,b)=>a.x-b.x),p=pads[opt.pad==null?3:opt.pad],tw=tdBuild(R,p,'still',tier);tw.cd=0;
           let best=null;R.G.paths.forEach((P2,pi)=>{for(let s=0;s<P2.len;s+=4){const q=rpAt(R.G,s,pi),d=Math.sqrt(rpD2(q.x,q.y,tw.x,tw.y));if(Math.abs(d-dist)<8&&(!best||Math.abs(d-dist)<best.e))best={s,pi,e:Math.abs(d-dist)}}});
           const F=[];if(best)for(let k=0;k<n;k++){const e=rpSpawn(id||'golem',best.pi);e.s=best.s+k*8;e.hp=e.mx=opt.hp||1e7;e.sp=opt.sp==null?0:opt.sp;F.push(e)}R.wst='run';R.q=[];return [R,tw,F,best]};return 1}""")
        # ---------------------------------------------------------------- registry, bar, key
        r=await E("()=>[RP_TWORDER.slice(-1)[0],RP_KEYS.slice(-1)[0],RPTW.still.n,RP_TW.still.cost,RP_TW.still.air,RPSKIN.still,rpTowerTop('still',1)>80,RP_TW.still.melt[2],RP_TW.still.midas[2]]")
        chk("the Alchemist's Still is the ninth tower (key P, 220 supply, ground only; tier 3: armor -6, +30% coins)",r[:3]==['still','P',"Alchemist's Still"] and r[3][0]==220 and r[4]==0 and r[6] and r[7]==6 and r[8]==.3,r)
        r=await E("""async()=>{tdNew('moss',1);await new Promise(r=>setTimeout(r,900));const bar=document.querySelector('#rphud .rpbar'),cards=[...document.querySelectorAll('#rphud .rpcard')],wv=[...document.querySelectorAll('#rphud *')].find(x=>/THIS WAVE/i.test(x.textContent)&&x.children.length<8&&x.getBoundingClientRect().width<200);
          const bb=bar.getBoundingClientRect(),ab=[...document.querySelectorAll('#rphud .rpab,#rphud [class*=ab]')].map(x=>x.getBoundingClientRect()).filter(q=>q.width>40&&q.width<200&&q.top>700);
          const over=cards.some((c,i)=>cards.some((d,j)=>{if(i>=j)return false;const a=c.getBoundingClientRect(),e=d.getBoundingClientRect();return a.left<e.right-1&&e.left<a.right-1}));
          const w=wv?wv.getBoundingClientRect():null;return [cards.length,cards.some(c=>c.dataset.tw==='still'),Math.round(bb.left),Math.round(bb.right),w?Math.round(w.left):null,ab.length?Math.round(Math.max(...ab.map(q=>q.right))):null,over]}""")
        chk('the bar shows all nine tiles without overlap and stays clear of the abilities and the wave panel',r[0]==9 and r[1] and not r[6] and (r[4] is None or r[3]<=r[4]+2) and (r[5] is None or r[2]>=r[5]-2),r)
        r=await E("()=>{const R=RPX;R.place=null;window.dispatchEvent(new KeyboardEvent('keydown',{key:'p',bubbles:true}));return R.place}")
        chk('key P picks the still for placing',r=='still',r)
        # ---------------------------------------------------------------- throwing and soaking
        r=await E("""()=>{const [R,tw,F,b]=alSet(1,170,5,'golem');let fl=0;for(let i=0;i<60*1.4;i++){rpStep(R,1/60);fl=Math.max(fl,R.alFlasks.length)}
          return [!!b,fl>=1,F.filter(e=>e.acid>0).length,F.filter(e=>e.hp<e.mx).length,F.map(e=>e.armor),R.alPools.length]}""")
        chk('it throws a flask at a ground group in range: the splash soaks and hurts them all, melts golem armor 9 to 5, and leaves a puddle',r[0] and r[1] and r[2]==5 and r[3]==5 and r[4]==[5]*5 and r[5]>=1,r)
        r=await E("""()=>{const [R,tw,F]=alSet(1,170,2,'golem');for(let i=0;i<60*1.2;i++)rpStep(R,1/60);const a=F[0].armor;tw.cd=1e9;R.alPools=[];for(let i=0;i<60*4;i++)rpStep(R,1/60);return [a,F[0].armor,F[0].acid,F[0].melt]}""")
        chk('the melt wears off: armor returns to 9 once the monster dries',r[0]==5 and r[1]==9 and r[2]==0 and r[3]==0,r)
        r=await E("""()=>{const [R,tw,F]=alSet(1,170,0);for(const k of [0,1,2]){const e=rpSpawn('gloom',0);e.s=200+k*20;e.hp=e.mx=1e7}for(let i=0;i<60*3;i++)rpStep(R,1/60);return [R.alFlasks.length+R.alSplash.length,Math.round(tw.dmg),R.foes.filter(e=>e.acid>0).length]}""")
        chk('flyers are ignored (it never throws at the sky)',r==[0,0,0],r)
        r=await E("""()=>{const [R,tw,F]=alSet(1,180,1,'golem',{sp:60});F[0].slowT=0;let f=null;for(let i=0;i<60*.3&&!f;i++){rpStep(R,1/60);f=R.alFlasks[0]}if(!f)return ['no flask'];
          while(!f.done){rpStep(R,1/60)}const q=rpPos(R,F[0]);return [Math.round(Math.sqrt(rpD2(q.x,q.y,f.x1,f.y1))),f.r,F[0].acid>0]}""")
        chk('it leads a walking monster: the flask lands on it, not behind it',isinstance(r[0],int) and r[0]<r[1]*.5 and r[2],r)
        # ---------------------------------------------------------------- other towers hit harder
        r=await E("""()=>{const R=tdNew('moss',1);const p=[...R.pads][0],tw=tdBuild(R,p,'still',1);const g=()=>{const e=rpSpawn('golem',0);e.hp=e.mx=1e6;return e};
          const hit=(e,d,ap)=>{const h=e.hp;rpHurt(e,d,ap,null);return +(h-e.hp).toFixed(2)};const a=g(),b2=g();rplSoak(b2,tw,3);
          const s=()=>{const e=rpSpawn('scamp',0);e.hp=e.mx=1e6;return e},c=s(),d=s();rplSoak(d,tw,3);
          const pz=g(),pz2=g();rplSoak(pz2,tw,3);return [hit(a,24,3),hit(b2,24,3),hit(a,20,0),hit(b2,20,0),hit(c,100,0),hit(d,100,0),pz.armor,pz2.armor]}""")
        chk('soaked golems take more from the Ballista (18 to 22) and the Blazer (11 to 15); an unarmored scamp soaked at tier 1 takes +20%; the Prism reads the melted armor',
            r[0]==18 and r[1]==22 and r[2]==11 and r[3]==15 and r[4]==100 and abs(r[5]-120)<.01 and r[6]==9 and r[7]==5,r)
        r=await E("""()=>{const [R,tw,F]=alSet(1,170,0);R.alPools=[{x:0,y:0,r:60,t:0,d:3,tier:1,soak:1.5,seed:.2,tw}];const e=rpSpawn('golem',F.length?F[0].pi:0);e.hp=e.mx=1e6;e.sp=0;e.s=300;const q=rpPos(R,e);R.alPools[0].x=q.x;R.alPools[0].y=q.y;tw.cd=1e9;
          rpStep(R,1/60);const a=[e.acid>0,e.armor];R.alPools=[];return a}""")
        chk('a monster walking through a puddle is soaked again',r==[True,5],r)
        r=await E("""()=>{const [R,tw,F]=alSet(2,170,0);const st=tdBuild(R,[...R.pads].sort((a,b)=>a.x-b.x)[5],'still',4);const e=rpSpawn('golem',0);e.hp=e.mx=1e6;rplSoak(e,st,3);rplSoak(e,tw,4);return [e.melt,e.armor,e.acid]}""")
        chk('two stills: the stronger brew wins, a weaker flask only tops up the time',r==[8,1,4],r)
        # ---------------------------------------------------------------- tiers
        r=await E("""()=>{const run=t=>{const R=tdNew('moss',1);const p=[...R.pads][0],tw=tdBuild(R,p,'still',t);const e=rpSpawn('golem',0);e.hp=1;rplSoak(e,tw,3);const c0=R.coins;rpHurt(e,50,99,tw);return +(R.coins-c0).toFixed(3)/e.coin};return [run(2),run(3)]}""")
        chk('tier 3 Midas Gold: a soaked monster that dies pays 30% more coins (tier 2 does not)',abs(r[0]-1)<1e-6 and abs(r[1]-1.3)<1e-6,r)
        r=await E("""()=>{const [R,tw,F]=alSet(4,170,3,'golem');for(let i=0;i<60*1.4;i++)rpStep(R,1/60);const e=F[0];return [e.acid>0,+(e.slowK||0).toFixed(2),e.slowT>0,e.armor]}""")
        chk('tier 4 Mythic: the brew also slows like glue (15%) and melts 8 armor',r[0] and r[1]>=.15 and r[2] and r[3]==1,r)
        r=await E("""()=>{const [R,tw,F]=alSet(5,170,4,'golem',{hp:5000});F[1].hp=900;F[1].mx=5000;const boss=rpSpawn('behemoth',F[0].pi);boss.s=F[0].s+6;boss.hp=600;boss.mx=1e8;boss.sp=0;tw.nv=3;tw.cd=0;const c0=R.coins;let n=0;
          for(let i=0;i<60*1.3;i++)rpStep(R,1/60);return [R.alGolds,F[1].dead===1,F.filter(e=>e.dead).length,boss.dead,R.alGold.length,+((R.coins-c0)/F[1].coin).toFixed(2)]}""")
        chk('tier 5 Celestial: the fourth flask turns the weakest wounded monster (below 35% health) in the splash into gold (never a boss), paying its coins 1.85x',r[0]==1 and r[1] and r[2]==1 and not r[3] and r[4]==1 and abs(r[5]-1.85)<.05,r)
        r=await E("""()=>{const run=over=>{const [R,tw,F]=alSet(1,170,4,'golem');let n=0;for(let i=0;i<60*8;i++){if(over)tw.over=1;const v=tw.nv||0;rpStep(R,1/60);if((tw.nv||0)>v)n++}return n};return [run(false),run(true)]}""")
        chk('Overcharge makes it throw faster',r[1]>r[0],r)
        r=await E("""()=>{const R=tdNew('wonder',6),p=[...R.pads].sort((a,b)=>a.x-b.x)[3];R.supply=1e6;rpBuild(p,'still');const tw=p.tw;const out=[];for(let t=2;t<=5;t++){rpUpgrade(tw);out.push(tw.tier)}const s0=R.supply;rpSell(tw);return [out,!p.tw,R.supply>s0]}""")
        chk('it upgrades to tier 5 on Wonderland and sells for supply',r[0]==[2,3,4,5] and r[1] and r[2],r)
        r=await E("""()=>{const [R,tw,F]=alSet(3,170,3,'ooze',{hp:1});const t=tdBuild(R,[...R.pads].sort((a,b)=>a.x-b.x)[5],'tide',1);for(let i=0;i<60*2;i++)rpStep(R,1/60);return [F.every(e=>e.dead),R.foes.filter(e=>e.id==='oozelet').length,R.foes.filter(e=>!e.dead&&e.acid>0&&e.arm0==null).length]}""")
        chk('it works with splitting oozes (the children spawn clean) and alongside the Tidecaller',r[0] and r[1]>=2 and r[2]==0,r)
        # ---------------------------------------------------------------- art, info panel, cost, a real wave
        r=await E("""()=>{const c=document.createElement('canvas');c.width=c.height=300;const g=c.getContext('2d');const bad=[];
          for(let t=1;t<=5;t++)for(const k of [0,.2,.5,.8,.97,1])try{g.clearRect(0,0,300,300);g.save();g.translate(150,220);rpTowerBuild(g,'still',t,'base',k,1,{from:k<1&&t>1?t-1:0});g.restore()}catch(e){bad.push(t+':'+k+':'+e.message)}
          const ic=[1,2,3,4,5].map(t=>{const q=rpTowerIcon('still',t,'base',96),d=q.getContext('2d').getImageData(0,0,96,96).data;let n=0;for(let i=3;i<d.length;i+=4)if(d[i]>100)n++;return n});return [bad,ic]}""")
        chk('build, upgrade and ascension animations draw at every tier, and every icon has art',r[0]==[] and all(n>1200 for n in r[1]),r)
        r=await E("""async()=>{const R=tdNew('moss',3);const p=[...R.pads].sort((a,b)=>a.x-b.x)[3];const tw=tdBuild(R,p,'still',3);R.sel=tw;await new Promise(r=>setTimeout(r,700));const el=document.querySelector('#rpinfo,.rpinfo');
          const labs=el?[...el.querySelectorAll('.rpst span')].map(x=>x.textContent):[];const x=el&&el.querySelector('.rplx');return [labs,!!el&&/Alchemist/.test(el.textContent),x?x.textContent:'']}""")
        chk('the info panel shows Range, Armor melt, Splash and Fire rate, and the brew (armor -6, +30% coins)',r[0]==['Range','Armor melt','Splash','Fire rate'] and r[1] and '-6' in r[2] and '+30%' in r[2],r)
        r=await E("""()=>{const c=document.createElement('canvas');c.width=1600;c.height=900;const g=c.getContext('2d');const scene=t=>{g.clearRect(0,0,1600,900);for(let k=0;k<4;k++){g.save();g.translate(200+k*300,400);rpTowerDraw(g,'still',2+k,'base',t,{fire:.6,charge:.4,ph:k});g.restore()}
            for(let k=0;k<8;k++){rpStillFlask(g,300+k*100,300,4,t);rpStillBadge(g,300+k*100,200,8,4,1)}for(let k=0;k<6;k++){rpStillSplash(g,300+k*150,500,90,(k+1)/8,4,k);rpStillPuddle(g,300+k*150,650,80,.8,t,4,k/6)}rpStillGold(g,800,500,.4,3);for(let k=0;k<10;k++)rpStillCoin(g,400+k*30,450,t+k)};
          for(let i=0;i<10;i++)scene(i*.1);const t0=performance.now();for(let i=0;i<40;i++)scene(i*.1);return +((performance.now()-t0)/40).toFixed(3)}""")
        chk('a heavy still scene (4 towers, 8 flasks, 8 badges, 6 splashes, 6 puddles, gold, coins) draws in under 1.5 ms a frame (headless)',r<1.5,r)
        r=await E("""()=>{const R=tdNew('wonder',1);R.wst='build';const pads=[...R.pads].sort((a,b)=>a.x-b.x);[1,3,5].forEach(i=>tdBuild(R,pads[i],'still',5));tdBuild(R,pads[2],'ballista',5);tdBuild(R,pads[4],'prism',5);tdBuild(R,pads[6],'frost',5);return tdPlay(R,40,240)}""")
        chk('a whole Wonderland wave 40 with stills, ballista, prism and frost: no broken health, the wave ends',r['nan']==0 and r['over']==0 and r['wst']!='run',r)
        r=await E("()=>{const h=HELP.Modes.find(x=>x[0]==='Runestone Tower Defense');return !!h&&/Alchemist/.test(h[1])}")
        chk('the Help text mentions the still',r,r)
        chk('no page errors',not er,er)
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
