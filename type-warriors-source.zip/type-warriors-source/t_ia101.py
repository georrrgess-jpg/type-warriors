# python3 t_ia101.py [game.html] : Runestone Tower Defense 10.1 - tower and monster interactions (98p).
# On every map (World 1, the Wonderland, Worlds 2 and 3) it builds a mixed defense with all twelve towers (as high as the map allows),
# plays three waves at 3x speed with every monster type spawned on top (rpSpawn), and checks: no page errors, no NaN, every monster
# dies or leaks, none leaves its road or slides back into the cave, every wave ends, and the battle effects are gone a few seconds
# after each wave (wells, puddles, craters, waves, stars, jams, beams, bees). Then one check per fix in 98p, the twelve towers'
# jams, speed x3 / pause, Performance mode, mastery skins (no stat change), the Tide + Engine push/pull bound and the frame cost.
import asyncio,os,sys,json
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
SHOTS=os.environ.get('IA_SHOTS',os.path.join(HERE,'shots','w101_interact'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:600]),flush=True)
    if not ok:FAIL.append(name)
MAPS=['moss','frost','ember','wonder','coral','wreck','abyss','meadow','foundry','storm']
SETUP="()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const r=RPP();r.new99j=1;r.dragon=1;for(const m of ['moss','frost','ember','coral','wreck','abyss','meadow','foundry','storm'])r.stars[m]=3;for(const k in r.tut)r.tut[k]=1;save()}"
LIB=r"""()=>{const TW=['ballista','brazier','frost','bell','prism','dragon','tide','mortar','still','star','hive','grav'];
 const IA=window.IA={TW};
 IA.go=(m,fn)=>{rpStart(m);const R=RPX;R.tut=null;R.hold=false;R.supply=1e7;R.wave=3;R.wst='run';R.q=[];R.cd=999;if(R.cannon)R.cannon.t=1e9;if(R.gust)R.gust.t=1e9;if(R.rodK){R.boltT=1e9;R.boltTwT=1e9}
  try{return fn(R)}catch(x){return 'ERR '+String(x.stack).slice(0,400)}finally{rpLeave()}};
 IA.step=(R,n)=>{for(let i=0;i<n;i++)rpStep(R,1/30)};
 IA.bt=(R,pd,t,tier)=>{if(pd.tw)rpSell(pd.tw);rpBuild(pd,t);const tw=pd.tw;tw.build=1;for(let k=1;k<(tier||1);k++){tw.upK=1;if(!rpUpgrade(tw))break}tw.upK=1;return tw};
 /* a monster put on the road at a straight-line distance lo..hi from (x,y) */
 IA.place=(R,id,x,y,lo,hi)=>{for(let pi=0;pi<R.G.paths.length;pi++){const L=R.G.paths[pi].len;for(let s=10;s<L-10;s+=3){const p=rpAt(R.G,s,pi);const d=Math.sqrt(rpD2(p.x,p.y,x,y));if(d>lo&&d<hi){const e=rpSpawn(id,pi);e.s=s;e._s=-1;e.off=0;return e}}}return null};
 IA.tank=(e,hp)=>{e.hp=e.mx=hp||1e7;e.sp=.01;return e};
 IA.clr=R=>{for(const k of ['shots','mtShells','mtCraters','mtBooms','alFlasks','alPools','tdJets','tdWaves','tdWhirls','tdLevs','sfStars','gvOrbs','gvWells','hvPools','hvBursts','burns','fields'])if(R[k])R[k]=[]};
 IA.settle=(R,n)=>{IA.step(R,n||0);R.fx.length=0;R.tx=[];R.rings=[];R.banner=null;R.toast=null};
 IA.nearPad=(R,e,minD)=>{const q=rpPos(R,e);return [...R.pads].sort((a,b)=>Math.hypot(a.x-q.x,a.y-q.y)-Math.hypot(b.x-q.x,b.y-q.y)).find(p=>Math.hypot(p.x-q.x,p.y-q.y)>(minD||0))};
 return Object.keys(IA).length}"""
# ---------- A: every map, all twelve towers, three waves at 3x, every monster ----------
PLAY=r"""(m)=>{const IA=window.IA,TW=IA.TW;rpStart(m);const R=RPX;R.tut=null;R.hold=false;R.supply=1e8;R.hp=1e9;const out={m,err:[],nan:0,road:0,back:0,stuck:[],left:[],waves:[],fx:[],spawned:0,towers:0};
 const top=RP_MAXT(R.map);const pads=R.pads.slice();
 /* a mixed set with all twelve towers; tiers vary from 1 to the map's cap */
 pads.forEach((p,i)=>{const t=TW[(i*5)%TW.length];rpBuild(p,t);if(p.tw){p.tw.build=1;const n=1+(i%top);for(let k=1;k<n;k++){p.tw.upK=1;rpUpgrade(p.tw)}p.tw.upK=1}});
 const have=new Set(R.pads.filter(p=>p.tw).map(p=>p.tw.type));for(const t of TW)if(!have.has(t)){const p=R.pads.find(q=>q.tw&&[...R.pads].filter(z=>z.tw&&z.tw.type===q.tw.type).length>1);if(p){rpSell(p.tw);rpBuild(p,t);p.tw.build=1}}
 out.towers=new Set(R.pads.filter(p=>p.tw).map(p=>p.tw.type)).size;
 const ids=Object.keys(RP_FOE).filter(id=>!/_p\d$/.test(id));const all=new Map(),seen=new Set();R.spd=3;
 for(let w=0;w<3;w++){R.wst='build';R.cd=0;rpWaveStart();const W=R.wave;let k=0,t=0;
  while(R.wst==='run'&&t<300){if(k<ids.length&&t>1+k*.35){const id=ids[k++];const e=rpSpawn(id);if(e){out.spawned++;if(RP_FOE[id].boss){e.hp=e.mx=Math.round(e.mx*.25)}}}
   R.hold=false;R.pause=false;try{rpUpdate(1/30)}catch(x){out.err.push(String(x.stack).slice(0,300));break}t+=3/30;
   if(((t*10)|0)%7===0)try{rpDraw()}catch(x){out.err.push('draw '+String(x.stack).slice(0,300));break}
   for(const e of R.foes){all.set(e.uid,e);if(e.dead)continue;if(!isFinite(e.s)||!isFinite(e.hp)||!isFinite(e.sp)||!isFinite(e.armor))out.nan++;
    if(e.s>rpLen(R,e)+1||e.s<-70)out.road++;if(e.s>=0)seen.add(e);else if(seen.has(e))out.back++;
    const q=rpPos(R,e);if(!isFinite(q.x)||!isFinite(q.y))out.nan++}}
  if(R.wst==='run')out.stuck.push(W+': '+R.foes.filter(e=>!e.dead).slice(0,6).map(e=>e.id+'@'+Math.round(e.s)+' hp'+Math.round(e.hp)+(e.hide?' hid':'')).join(', '));
  out.waves.push(W);
  /* a few seconds after the wave: every effect has run its course */
  for(let i=0;i<30*8;i++)rpStep(R,1/30);
  const left=[];for(const k of ['gvWells','gvOrbs','hvPools','hvBursts','alPools','alFlasks','mtShells','mtCraters','tdWaves','tdJets','tdWhirls','tdLevs','sfStars','burns','fields','shots','inks','emps','bolts'])if(R[k]&&R[k].length)left.push(k+':'+R[k].length);
  for(const p of R.pads){const tw=p.tw;if(!tw)continue;if(tw.jam>0)left.push('jam '+tw.type);if(tw.beams&&tw.beams.length)left.push('beam '+tw.type);if(tw.type==='dragon'&&(tw.dive||tw.streams||tw.st==='breath'))left.push('dragon '+tw.st);
   if(tw.type==='hive'&&(tw.bees||[]).some(b=>b.m!=='in'&&b.e&&!b.e.dead))left.push('bees on a target');if(tw.type==='hive'&&tw.qn&&tw.qn.m!=='perch')left.push('queen out')}
  if(R.foes.some(e=>!e.dead))left.push('foes '+R.foes.filter(e=>!e.dead).length);if(R.tide&&R.tide.k>0)left.push('tide '+R.tide.k);if(R.gust&&R.gust.k>0)left.push('gust');
  out.fx.push(left.join(' '))}
 for(const e of all.values())if(!e.dead)out.left.push(e.id+'@'+Math.round(e.s));
 out.kills=R.kills;out.leaked=R.leaked;rpLeave();out.rpx=RPX===null;return out}"""
# ---------- B: one check per fix ----------
FIX=r"""()=>{const IA=window.IA,o={};const {go,step,bt,place,tank,nearPad}=IA;
 /* 1. armor: Still melt vs the Brute's shedding shell, the Shellback's shell and the Titan's plates */
 o.brute=go('coral',R=>{const e=tank(rpSpawn('brute',0),1e5);e.s=300;e._s=-1;const tw=bt(R,R.pads[0],'still',4);e.hp=e.mx*.5;step(R,1);const a=[e.armor];rplSoak(e,tw,5);a.push(e.armor);step(R,3);a.push(e.armor);e.acid=.01;step(R,2);a.push(e.armor);return a});
 o.shell=go('coral',R=>{const e=tank(rpSpawn('shell',0),1e5);e.s=300;e._s=-1;const tw=bt(R,R.pads[0],'still',4);e.shT=.05;step(R,3);const a=[e.shIn>0,e.armor];rplSoak(e,tw,9);a.push(e.armor);step(R,3);a.push(e.armor);step(R,60);a.push(e.shIn>0,e.armor);return a});
 o.titan=go('storm',R=>{const e=tank(rpSpawn('titan',0),1e6);e.s=300;e._s=-1;e.stT=1e9;const tw=bt(R,R.pads[0],'still',5);rplSoak(e,tw,9);const a=[e.armor];e.hp=e.mx*.6;step(R,2);a.push(e.shI,e.armor);return a});
 /* 2. hidden monsters */
 o.starHid=go('coral',R=>{const e=rpSpawn('jelly',0);e.s=300;e._s=-1;const tw=bt(R,R.pads[0],'star',3);e.glT=.05;step(R,3);e.hp=e.mx*.05;const h=e.hp;const a=[e.hide];rpsfStrike(R,e,500,tw,2);a.push(e.dead,e.hp===h,!(e.mk>0));return a});
 o.goldHid=go('meadow',R=>{const e=rpSpawn('spring',0);e.s=300;e._s=-1;const tw=bt(R,R.pads[0],'still',5);e.lpT=.03;step(R,2);e.hp=e.mx*.2;const a=[e.hide,e.leap>0];const p=rpPos(R,e);R.alFlasks.push({x0:p.x,y0:p.y-100,x1:p.x,y1:p.y,t:1,d:1,h:10,tw,tier:5,dmg:10,r:90,gold:1,seed:1});step(R,1);a.push(e.dead,!e.gold,!(e.acid>0));return a});
 o.aimHid=go('abyss',R=>{const res={};for(const t of ['prism','mortar','still','tide','dragon','star','ballista','bell','hive','grav','frost','brazier']){R.foes=[];const e=tank(rpSpawn('leviathan',0),1e6);e.s=R.G.paths[0].len*.4;e._s=-1;e.dvI=0;e.dive=60;e.hide=1;
   const pd=nearPad(R,e,110);const tw=bt(R,pd,t,3);for(const k of ['shots','mtShells','alFlasks','tdJets','sfStars','gvOrbs','burns'])R[k]=[];const h=e.hp;step(R,150);
   res[t]=[Math.round(h-e.hp),R.mtShells.length+R.alFlasks.length+R.tdJets.length+R.sfStars.length+R.gvOrbs.length+R.shots.length,(tw.beams||[]).length,e.slowT>0?1:0,e.kb>0?1:0].join('|');rpSell(tw)}return res});
 o.prismDrop=go('coral',R=>{const e=tank(rpSpawn('jelly',0));e.s=300;e._s=-1;const tw=bt(R,nearPad(R,e),'prism',2);step(R,3);const a=[(tw.beams||[]).length];e.glT=.05;step(R,4);a.push(e.hide,(tw.beams||[]).filter(b=>b.e===e).length);return a});
 o.knockHid=go('meadow',R=>{const e=rpSpawn('spring',0);e.s=400;e._s=-1;e.lpT=.03;step(R,2);const s=e.s;rptKnock(e,100,300);return [e.hide,!(e.kb>0)]});
 o.killHid=go('coral',R=>{const e=rpSpawn('jelly',0);e.s=300;e._s=-1;e.glT=.05;step(R,3);rpKillFoe(e,null);const a=[e.hide,e.dead];e.hide=0;e.hp=0;rpKillFoe(e,null);a.push(e.dead);return a});
 /* 3. fog */
 o.fog=go('wreck',R=>{R.fog.forEach(g=>{g.x=-3000;g.v=0});const res={};for(const t of ['prism','mortar','still','tide','dragon','star','ballista','hive','grav','bell','brazier']){let done=0;for(const p of R.pads){if(done)break;if(p.tw)rpSell(p.tw);R.foes=[];const rg=RP_TW[t].range[2]||300;const e=place(R,'brute',p.x,p.y,175,Math.min(230,rg*.95));if(!e)continue;
   const tw=bt(R,p,t,3);const q=rpPos(R,e);const f=R.fog[0];f.x=q.x;f.y=q.y;f.rx=60;f.ry=40;tank(e,1e6);e.armor=e.arm0=0;IA.clr(R);const h=e.hp;step(R,120);const fd=e.fogd;const d1=Math.round(h-e.hp);f.x=-3000;step(R,150);res[t]=[fd,d1,Math.round(h-e.hp)>d1?1:0].join('|');rpSell(tw);done=1}if(!done)res[t]='nos'}return res});
 /* 4. Glowcaps: +15% range for every tower; the ring shows it; RP_TW untouched afterwards */
 o.glow=go('abyss',R=>{const res={};const pads=R.pads.filter(p=>p.glow),plain=R.pads.filter(p=>!p.glow);const r0=JSON.stringify(IA.TW.map(t=>RP_TW[t].range));
   for(const t of ['frost','prism','mortar','still','tide','dragon','ballista','bell','brazier','hive','grav']){const one=(P)=>{for(const p of P){R.foes=[];const tw=bt(R,p,t,1);const rg=RP_TW[t].range[0];const e=place(R,t==='hive'?'brute':'brute',tw.x,tw.y,rg*1.03,rg*1.11);if(!e){rpSell(tw);continue}tank(e,1e6);e.armor=e.arm0=0;const h=e.hp;step(R,150);rpSell(tw);return Math.round(h-e.hp)}return 'nos'};res[t]=[one(pads),one(plain)].join('|')}
   const p=pads[0];const tw=bt(R,p,'frost',1);R.sel=tw;rpDraw();R.sel=null;res.same=JSON.stringify(IA.TW.map(t=>RP_TW[t].range))===r0;return res});
 /* 5. jams: all twelve towers stop and resume; prism beams; dragon dive; busiest pick */
 o.jam=go('meadow',R=>{const res={};for(const t of IA.TW){R.foes=[];for(const p of R.pads)if(p.tw)rpSell(p.tw);const L=R.G.paths[0].len;
   for(let k=0;k<6;k++){const e=rpSpawn(t==='bell'||t==='hive'?'gyro':'brute',0);e.s=L*.45+k*14;e._s=-1;tank(e);e.armor=e.arm0=0}
   const pd=nearPad(R,R.foes[0],120);const tw=bt(R,pd,t,3);step(R,150);const d0=tw.dmg;tw.jam=6;tw.jamBy='emp';step(R,105);const d1=tw.dmg,bm=(tw.beams||[]).length,ch=tw.charge||0;step(R,75);const d2=tw.dmg;R.foes.forEach((e,k)=>{e.s=L*.45+k*14;e._s=-1});step(R,150);const d3=tw.dmg;
   res[t]=[d0>0?1:0,Math.round(d2-d1),d3>d2?1:0,bm,+ch.toFixed(2)].join('|')}return res});
 o.dive=go('storm',R=>{const e=tank(rpSpawn('titan',0));e.s=R.G.paths[0].len*.4;e._s=-1;e.stT=1e9;const tw=bt(R,nearPad(R,e,100),'dragon',5);tw.nb=99;tw.cd=0;let k=0;while(!tw.dive&&k++<400)step(R,1);const a=[!!tw.dive];const t0=tw.dive&&tw.dive.t;tw.jam=1;step(R,15);a.push(tw.dive?+(tw.dive.t-t0).toFixed(2):'done');step(R,90);a.push(!tw.dive);return a});
 o.busy=go('coral',R=>{const e=tank(rpSpawn('crab',0));e.s=300;e._s=-1;const a=bt(R,nearPad(R,e),'ballista',3),b=bt(R,R.pads.find(p=>!p.tw),'ballista',1);a.jam=3;return [rpBusiest()===b,(a.jam=0,rpBusiest()===a)]});
 /* 6. a venting Steam Golem shrugs off the Slow Field */
 o.vent=go('meadow',R=>{const e=rpSpawn('steam',0);e.s=300;e._s=-1;e.hp=e.mx*.8;step(R,1);const p=rpPos(R,e);R.fields.push({x:p.x,y:p.y,r:260,t:0,d:10});const s0=e.s;step(R,15);const v1=(e.s-s0)/.5;R.fields=[];const s1=e.s;step(R,15);const v2=(e.s-s1)/.5;
   const f=rpSpawn('steam',0);f.s=300;f._s=-1;step(R,1);const q=rpPos(R,f);R.fields.push({x:q.x,y:q.y,r:260,t:0,d:10});const s2=f.s;step(R,15);const v3=(f.s-s2)/.5;return [e.vent>0,+(v1/v2).toFixed(2),+(v3/(f.sp||1)).toFixed(2)]});
 /* 7. split children start on the road */
 o.ooze=go('moss',R=>{const e=rpSpawn('ooze',0);e.s=6;e._s=-1;rpHurt(e,1e6,99,null);return R.foes.filter(f=>f.id==='oozelet').map(f=>f.s)});
 /* 8. a surfaced Leviathan waits before diving again */
 o.lev=go('abyss',R=>{const e=tank(rpSpawn('leviathan',0),1e5);e.s=300;e._s=-1;e.hp=e.mx*.2;let t=0,first=-1,end=-1,second=-1;for(let i=0;i<30*12;i++){rpStep(R,1/30);t+=1/30;if(e.dive>0&&first<0)first=t;if(first>=0&&end<0&&!(e.dive>0))end=t;if(end>=0&&second<0&&e.dive>0)second=t}return [+first.toFixed(2),+(end-first).toFixed(2),+(second-end).toFixed(2),e.dvI,R.foes.filter(f=>f.id==='crab').length]});
 /* 9. abilities follow the monster onto World 1 */
 o.w1=go('moss',R=>{const e=rpSpawn('spring',0);e.s=300;e._s=-1;e.lpT=.03;const s0=e.s;step(R,20);const j=tank(rpSpawn('jammer',0));j.s=0;const tws=R.pads.slice(0,4).map(p=>bt(R,p,'ballista',1));for(let i=0;i<30*40;i++){rpStep(R,1/30);j.s+=4}rpDraw();return [Math.round(e.s-s0),tws.filter(t=>t.jamBy==='emp').length>0]});
 /* 10. How to Play: the Engine's price */
 o.howto=(()=>{try{rampartsMenu(title);rpHowTo();const t=[...ov.querySelectorAll('#rpmod .rphw p')].map(p=>p.textContent).find(x=>/Singularity Engine\./.test(x))||'';hide();return [t.includes('600 supply'),!t.includes('650 supply')]}catch(x){return 'ERR '+x}})();
 /* 12. Rising Tide drains between waves and the next wave starts at the ebb */
 o.tide=go('coral',R=>{tank(rpSpawn('shell',0)).s=20;R.wst='build';R.cd=99;rpStep(R,1/30);R.q=[];R.cd=0;rpWaveStart();R.q=[];const a=[];for(let i=0;i<30*4;i++)rpStep(R,1/30);a.push(+R.tide.k.toFixed(2));R.wst='build';R.cd=99;for(let i=0;i<30*3;i++)rpStep(R,1/30);a.push(+R.tide.k.toFixed(2));
   R.cd=0;rpWaveStart();R.q=[];rpStep(R,1/30);a.push(+R.tide.k.toFixed(2));for(let i=0;i<30*3;i++)rpStep(R,1/30);a.push(+R.tide.k.toFixed(2));return a});
 /* mastery skins never change stats */
 o.skin=go('coral',R=>{const res=[];for(const sk of ['base','m5']){R.foes=[];for(const p of R.pads)if(p.tw)rpSell(p.tw);const L=R.G.paths[0].len;const es=[];for(let k=0;k<4;k++){const e=rpSpawn('brute',0);e.s=L*.4+k*20;e._s=-1;e.off=0;tank(e);es.push(e)}IA.clr(R);
   const tws=['ballista','prism','frost','bell'].map((t,i)=>{const tw=bt(R,R.pads.filter(p=>!p.tw).sort((a,b)=>{const q=rpPos(R,es[0]);return Math.hypot(a.x-q.x,a.y-q.y)-Math.hypot(b.x-q.x,b.y-q.y)})[0],t,3);tw.skin=sk;tw.cd=.3;return tw});step(R,150);res.push(tws.map(t=>Math.round(t.dmg)).join(','))}return res});
 /* the Tidecaller and the Engine together can delay a monster but never hold it for good */
 o.ping=go('meadow',R=>{const e=rpSpawn('steam',0);e.s=200;e._s=-1;e.hp=e.mx=1e7;e.armor=e.arm0=0;const pds=[...R.pads].sort((a,b)=>{const q=rpPos(R,e);return Math.hypot(a.x-q.x,a.y-q.y)-Math.hypot(b.x-q.x,b.y-q.y)});bt(R,pds[0],'tide',5);bt(R,pds[1],'grav',5);bt(R,pds[2],'tide',5);bt(R,pds[3],'grav',5);
   let mn=1e9,neg=0,jit=0,last=e.s;const D=[];for(let i=0;i<30*45;i++){rpStep(R,1/30);if(e.s<0)neg++;mn=Math.min(mn,e.s);const d=e.s-last;last=e.s;D.push(e.kb>0?0:Math.abs(d)>.5?Math.sign(d):0);const n=D.length;if(n>=3&&D[n-1]&&D[n-3]&&D[n-1]===D[n-3]&&D[n-2]===-D[n-1])jit++}return [Math.round(e.s),Math.round(mn),neg,jit]});
 /* speed x3 and pause */
 o.speed=go('coral',R=>{R.spd=3;const e=rpSpawn('crab',0);e.s=100;e._s=-1;tank(e);const t0=R.time;rpUpdate(1/30);const a=[+(R.time-t0).toFixed(3)];R.pause=true;const t1=R.time,s1=e.s;rpUpdate(1/30);a.push(R.time===t1&&e.s===s1);R.pause=false;return a});
 /* Performance mode plays the same */
 o.lite=go('foundry',R=>{R.lite=1;for(const p of R.pads.slice(0,12))bt(R,p,IA.TW[R.pads.indexOf(p)%12],3);const ids=['cog','knight','steam','gyro','tinker','spring','jammer'];let err=0;for(let i=0;i<30*20;i++){if(i%30===0){const e=rpSpawn(ids[(i/30)%ids.length]);}try{rpStep(R,1/30);if(i%10===0)rpDraw()}catch(x){err++}}return [err,R.kills]});
 return o}"""
COST=r"""()=>{const IA=window.IA;return IA.go('storm',R=>{R.lite=0;const res={};for(const p of R.pads)IA.bt(R,p,IA.TW[R.pads.indexOf(p)%12],4);
 const ids=['cog','knight','steam','gyro','tinker','spring','jammer','crab','shell','jelly','siren'];for(let k=0;k<70;k++){const e=rpSpawn(ids[k%ids.length]);e.s=Math.random()*1200;e._s=-1;IA.tank(e)}
 const g=R.foes.filter(e=>e.id==='spring'||e.id==='jelly');g.forEach((e,i)=>{if(i%2)e.lpT=.01})
 const run=(off)=>{RPIA.off=off;let t=0;for(let i=0;i<120;i++){const a=performance.now();rpStep(R,1/30);t+=performance.now()-a}RPIA.off=0;return t/120};
 run(0);const a=[],b=[];for(let k=0;k<5;k++){b.push(run(1));a.push(run(0))}a.sort((x,y)=>x-y);b.sort((x,y)=>x-y);res.on=+a[2].toFixed(3);res.off=+b[2].toFixed(3);res.n=R.foes.filter(e=>!e.dead).length;return res})}"""
SCENES={
 'prism_glimmer':"()=>{rpStart('coral');const R=RPX;R.tut=null;R.supply=1e7;R.wave=3;R.wst='run';R.q=[];R.cd=999;const IA=window.IA;const e=IA.tank(rpSpawn('jelly',0));e.s=R.G.paths[0].len*.42;e._s=-1;const f=IA.tank(rpSpawn('crab',0));f.s=e.s+40;f._s=-1;IA.bt(R,IA.nearPad(R,e),'prism',4);IA.bt(R,IA.nearPad(R,e,140),'hive',4);IA.settle(R,90);e.glT=.02;IA.step(R,6);IA.settle(R);R.hold=true;return 1}",
 'jams_storm':"()=>{rpStart('storm');const R=RPX;R.tut=null;R.supply=1e7;R.wave=3;R.wst='run';R.q=[];R.cd=999;const IA=window.IA;const L=R.G.paths[0].len;const t=IA.tank(rpSpawn('titan',0));t.s=L*.45;t._s=-1;t.stT=1e9;for(let k=0;k<4;k++){const j=IA.tank(rpSpawn('jammer',0));j.s=L*.45+30+k*20;j._s=-1}const pads=[...R.pads].sort((a,b)=>{const q=rpPos(R,t);return Math.hypot(a.x-q.x,a.y-q.y)-Math.hypot(b.x-q.x,b.y-q.y)});['prism','dragon','hive','grav','mortar','star'].forEach((ty,i)=>IA.bt(R,pads[i],ty,4));IA.settle(R,90);t.stT=.02;IA.step(R,10);IA.settle(R);R.hold=true;return 1}",
 'still_brute':"()=>{rpStart('coral');const R=RPX;R.tut=null;R.supply=1e7;R.wave=3;R.wst='run';R.q=[];R.cd=999;const IA=window.IA;const L=R.G.paths[0].len;const es=[];for(let k=0;k<4;k++){const e=IA.tank(rpSpawn(k%2?'shell':'brute',0));e.s=L*.5+k*30;e._s=-1;es.push(e)}const pads=[...R.pads].sort((a,b)=>{const q=rpPos(R,es[0]);return Math.hypot(a.x-q.x,a.y-q.y)-Math.hypot(b.x-q.x,b.y-q.y)});IA.bt(R,pads[0],'still',4);IA.bt(R,pads[1],'ballista',4);IA.bt(R,pads[2],'star',4);IA.settle(R,120);es[1].shT=.02;IA.step(R,8);IA.settle(R);R.hold=true;return es.map(e=>e.id+':'+e.armor).join(' ')}",
 'tide_engine':"()=>{rpStart('meadow');const R=RPX;R.tut=null;R.supply=1e7;R.wave=3;R.wst='run';R.q=[];R.cd=999;const IA=window.IA;const L=R.G.paths[0].len;const es=[];for(let k=0;k<8;k++){const e=IA.tank(rpSpawn(['cog','knight','steam','spring'][k%4],0),1e5);e.s=L*.35+k*26;e._s=-1;e.sp=40;es.push(e)}const pads=[...R.pads].sort((a,b)=>{const q=rpPos(R,es[3]);return Math.hypot(a.x-q.x,a.y-q.y)-Math.hypot(b.x-q.x,b.y-q.y)});IA.bt(R,pads[0],'grav',5);IA.bt(R,pads[1],'tide',5);IA.bt(R,pads[2],'mortar',5);IA.bt(R,pads[3],'frost',5);IA.settle(R,60);IA.step(R,50);IA.settle(R);R.hold=true;return 1}",
 'fog_wreck':"()=>{rpStart('wreck');const R=RPX;R.tut=null;R.supply=1e7;R.wave=3;R.wst='run';R.q=[];R.cd=999;const IA=window.IA;const L=R.G.paths[0].len;const es=[];for(let k=0;k<7;k++){const e=IA.tank(rpSpawn(['crab','puffer','squid','brute'][k%4],k%2),1e5);e.s=L*(.3+k*.07);e._s=-1;es.push(e)}const q=rpPos(R,es[3]);R.fog[0].x=q.x;R.fog[0].y=q.y;R.fog[0].v=0;R.fog.slice(1).forEach(f=>f.v=0);R.pads.forEach((p,i)=>{if(i%2===0)IA.bt(R,p,['prism','mortar','tide','dragon','star','still'][(i/2)%6],4)});IA.settle(R,90);IA.step(R,10);IA.settle(R);R.hold=true;return 1}",
 'w1_newcast':"()=>{rpStart('ember');const R=RPX;R.tut=null;R.supply=1e7;R.wave=3;R.wst='run';R.q=[];R.cd=999;const IA=window.IA;const L=R.G.paths[0].len;['leviathan','siren','crab','crab','knight','cog','tinker','jammer','spring'].forEach((id,k)=>{const e=IA.tank(rpSpawn(id,0),1e5);e.s=L*(.25+k*.05);e._s=-1});R.pads.forEach((p,i)=>{if(i%2)IA.bt(R,p,IA.TW[i%12],3)});IA.settle(R,150);IA.step(R,10);IA.settle(R);R.hold=true;return 1}"}
async def main():
    os.makedirs(SHOTS,exist_ok=True)
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        pg.on('console',lambda m:er.append('console: '+m.text[:300]) if m.type=='error' and 'WebSocket' not in m.text else None)
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E(SETUP);await E(LIB)
        chk('all twelve towers can be built (all worlds open)',await E("()=>IA.TW.every(t=>!rpwTwLocked(t))"))
        for m in MAPS:
            o=await E(PLAY,m)
            chk(f'{m}: all twelve towers on the field, three waves played at 3x with every monster type ({o["spawned"]} extra spawns), no errors',o['towers']==12 and len(o['waves'])==3 and not o['err'],o)
            chk(f'{m}: no NaN, no monster off its road, none slid back into the cave',o['nan']==0 and o['road']==0 and o['back']==0,o)
            chk(f'{m}: every wave ends and every monster died or leaked ({o["kills"]} kills, {o["leaked"]} leaks)',not o['stuck'] and not o['left'] and o['rpx'],o)
            chk(f'{m}: every battle effect is gone a few seconds after each wave',all(x=='' for x in o['fx']),o['fx'])
        o=await E(FIX);print(json.dumps(o)[:3000])
        chk('Still vs Barnacle Brute: the melt holds while its armor sheds with health (7 - 8 = 0), and comes back when it dries',o['brute']==[7,0,0,7],o['brute'])
        chk('Still vs Shellback: hidden in its shell it keeps the +12 minus the melt (17 - 8 = 9); out of it the melt still counts',o['shell'][:4]==[True,17,9,9] and o['shell'][4]==False and o['shell'][5]==0,o['shell'])
        chk('Still vs Titan: a plate shed keeps the melt (14 - 10 = 4, then 10 - 10 = 0)',o['titan']==[4,1,0],o['titan'])
        chk('a falling star neither hurts, marks nor finishes a glimmering Jellyglide',o['starHid']==[1,False,True,True],o['starHid'])
        chk('a Celestial flask neither soaks nor turns a leaping Springjack to gold',o['goldHid']==[1,True,False,True,True],o['goldHid'])
        ah=o['aimHid'];bad={k:v for k,v in ah.items() if v.split('|')[0]!='0' or v.split('|')[1]!='0' or v.split('|')[2]!='0' or v.split('|')[3]!='0' or v.split('|')[4]!='0'}
        chk('a diving Leviathan: none of the twelve towers aims, fires, beams, slows or shoves it',not bad and len(ah)==12,ah)
        chk('the Prism lets go of a Jellyglide that glimmers',o['prismDrop'][0]==1 and o['prismDrop'][1]==1 and o['prismDrop'][2]==0,o['prismDrop'])
        chk('a Tidecaller wave does not shove a monster in mid-leap',o['knockHid']==[1,True],o['knockHid'])
        chk('nothing executes a hidden monster that still has health (a real death still counts)',o['killHid']==[1,0,1],o['killHid'])
        fg=o['fog'];bad={k:v for k,v in fg.items() if v=='nos' or v.split('|')[0]!='1' or v.split('|')[1]!='0' or (k not in ('hive','grav','bell','ballista','brazier') and v.split('|')[2]!='1')}
        chk('fog: no tower (Prism, Mortar, Still, Tidecaller, Dragon, Starfall included) picks a fogged monster from beyond 150 px; they do once the fog drifts off',not bad,fg)
        gl=o['glow'];bad={k:v for k,v in gl.items() if k!='same' and (v.split('|')[0] in ('0','nos') or v.split('|')[1] not in ('0','nos'))}
        chk('Glowcaps: every tower on a Glowcap pad reaches 15% further (a monster just past its normal range is hit; from a plain pad it is not)',not bad,gl)
        chk('Glowcaps: drawing the selected tower\'s ring leaves the tower ranges untouched',gl.get('same') is True,gl)
        jm=o['jam'];bad={k:v for k,v in jm.items() if not (v.split('|')[0]=='1' and int(v.split('|')[1])<=12 and v.split('|')[2]=='1' and v.split('|')[3]=='0' and float(v.split('|')[4])<.05)}
        chk('jams: each of the twelve towers stops (no damage, no beams, no charge glow) and fires again afterwards',not bad and len(jm)==12,jm)
        chk('a Dragon jammed in its wing dive finishes the dive',o['dive'][0] is True and o['dive'][1]!='done' and o['dive'][1]>.4 and o['dive'][2] is True,o['dive'])
        chk("Overcharge's busiest-tower pick skips a jammed tower while another is free",o['busy']==[True,True],o['busy'])
        chk('a venting Steam Golem ignores the Slow Field (other golems are slowed by it)',o['vent'][0] is True and abs(o['vent'][1]-1)<.08 and o['vent'][2]<.65,o['vent'])
        chk('Oozelets split from an Ooze at the road start begin on the road, not in the cave',len(o['ooze'])==2 and all(s>=0 for s in o['ooze']),o['ooze'])
        lv=o['lev'];chk('Leviathan: dives at once, then stays up 1.2 s before the next dive; Crablings each time',lv[0]>0 and abs(lv[1]-2.5)<.1 and lv[2]>=1.15 and lv[4]>=8,lv)
        chk('World 2/3 abilities work on a World 1 map (a Springjack leaps, a Sparkjammer jams)',o['w1'][0]>=78 and o['w1'][1] is True,o['w1'])
        chk('How to Play gives the Singularity Engine\'s real price (600)',o['howto']==[True,True],o['howto'])
        chk('Rising Tide: the flood drains between waves and rises smoothly again in the next wave',o['tide'][0]>=.99 and o['tide'][1]==0 and o['tide'][2]<.1 and o['tide'][3]>=.99,o['tide'])
        chk('mastery skins do not change damage (Ballista, Prism, Frost, Bell)',len(o['skin'])==2 and o['skin'][0]==o['skin'][1],o['skin'])
        pg_=o['ping'];chk('two Tidecallers and two Engines delay a monster but never hold it or push it into the cave (no jitter)',pg_[0]>400 and pg_[2]==0 and pg_[3]<=2,pg_)
        chk('speed x3 runs three steps a frame; pause stops the battle',abs(o['speed'][0]-.1)<.002 and o['speed'][1] is True,o['speed'])
        chk('Performance mode plays a World 3 battle with all twelve towers without errors',o['lite'][0]==0 and o['lite'][1]>0,o['lite'])
        c=await E(COST);print('frame cost',c)
        chk(f'frame cost: a full Storm Citadel battle steps in {c["on"]} ms ({c["off"]} ms without 98p\'s per-tower veil)',c['on']<6 and c['on']-c['off']<max(.5,c['off']*.3),c)
        for k,js in SCENES.items():
            r=await E(js);await pg.wait_for_timeout(500);await pg.screenshot(path=os.path.join(SHOTS,f'ia_{k}.png'));await E("()=>{if(RPX)rpLeave()}")
        chk('no page errors',not er,er[:5])
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');sys.exit(1 if FAIL else 0)
asyncio.run(main())
