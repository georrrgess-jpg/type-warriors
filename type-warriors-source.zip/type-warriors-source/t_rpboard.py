# Wonderland Championship (95j) end to end, against local Nostr relays (the same ones t_leaderboard.py uses):
#   A 18091 honest · B 18092 honest but slow (1.2 s) · C 18093 dishonest (stores anything) · 18099 dead
# Also: the Dragon Roost (95c4/95i) locked until Ember Crown, the prize at season end, the champion's skin, the Tower Skins screen.
# Run from the source folder: PYTHONPATH=../../pylib python3 t_rpboard.py [out.html]
import asyncio,json,os,subprocess,sys,time
HERE=os.path.dirname(os.path.abspath(__file__));sys.path.insert(0,HERE)
import websockets
import t_nostr_tools as T
from playwright.async_api import async_playwright
PYLIB=os.path.abspath(os.path.join(HERE,'../../pylib'))
A,B,C,DEAD=18091,18092,18093,18099
URL=lambda p:f'ws://127.0.0.1:{p}'
RELAYS=[f'nostr:{URL(A)}',f'nostr:{URL(B)}',f'nostr:{URL(C)}',f'nostr:{URL(DEAD)}']
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:400]),flush=True)
    if not ok:FAIL.append(name)
def start(port,*flags):
    os.makedirs(os.path.join(HERE,'../lbt'),exist_ok=True);log=open(os.path.join(HERE,f'../lbt/rprelay{port}.log'),'w')
    return subprocess.Popen([sys.executable,'t_nostr_relay.py',str(port),*flags],cwd=HERE,env={**os.environ,'PYTHONPATH':PYLIB+':'+HERE},stdout=log,stderr=subprocess.STDOUT)
async def post_many(port,evs):
    async with websockets.connect(URL(port),max_size=2**22) as ws:
        for ev in evs:await ws.send(json.dumps(['EVENT',ev]))
        ok=0
        for _ in evs:
            a=json.loads(await asyncio.wait_for(ws.recv(),30));ok+=a[0]=='OK' and a[2]
        return ok
async def query(port,f):
    out=[]
    async with websockets.connect(URL(port),max_size=2**24) as ws:
        await ws.send(json.dumps(['REQ','q',f]))
        while True:
            a=json.loads(await asyncio.wait_for(ws.recv(),10))
            if a[0]=='EOSE':return out
            if a[0]=='EVENT':out.append(a[2])
async def clear(*ports):
    for p in ports:
        async with websockets.connect(URL(p)) as ws:await ws.send(json.dumps(['TESTCLEAR']));await ws.recv()
TG=lambda s:'twrp-lb-s%d'%s
def rp_event(seed,c,at=None,season=1,tags=None):
    d,pk=T.keypair(seed);now=int(time.time())
    return T.event(d,pk,c,at or now-30,tags=tags if tags is not None else [['d',TG(season)],['t',TG(season)],['t','twrp-lb']]),pk
def honest(seed,w,name=None):
    now=int(time.time());c={'v':1,'s':1,'n':name or f'Bot{seed}','w':w,'d':w*25,'k':w*18,'r':3,'t':now-600}
    return rp_event(seed,c)
SETUP="""(a)=>{RS_ASK=false;WCRELAYS=a[0];P.name=a[1];P.gold=1000;delete P.rk;delete P.rp;save();rkSt();RPP();rpLbSt();Object.assign(RPLB,{t:0,state:'idle',list:[],me:null});RKLB.ver.clear();
 const T=RPP().tut;for(const k of['build','wave','coins','upgrade','abil','twist_frost','twist_ember','twist_wonder'])T[k]=1}"""
# plays a Wonderland run that holds `w` waves and waits for it to reach the relays
RUN="""async(w)=>{const st=RPP().stars;st.moss=st.moss||1;st.frost=st.frost||1;st.ember=st.ember||1;rpStart('wonder');const R=RPX;R.tut=null;R.hold=false;R.wave=w;R.wst='build';R.time=w*30;R.kills=w*20;
 rpFinish(true);await new Promise(r=>setTimeout(r,500));while(RPLB.p)await RPLB.p;await new Promise(r=>setTimeout(r,200));const L=rpLbSt();return [L.best,L.runs,L.pend,!!document.getElementById('rplbres')]}"""
async def main():
    html='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else 'out.html')
    procs=[start(A),start(B,'--slow','1200'),start(C,'--noverify')];await asyncio.sleep(1.5)
    er=[]
    try:
        async with async_playwright() as pw:
            b=await pw.chromium.launch()
            async def player(name,relays=RELAYS):
                pg=await b.new_page(viewport={'width':1600,'height':900})
                pg.on('pageerror',lambda e:er.append(str(e)[:300]))
                await pg.goto(html);await pg.wait_for_timeout(1200);await pg.evaluate(SETUP,[relays,name]);return pg
            await clear(A,B,C)
            pg=await player('Rowan');E=pg.evaluate
            # ------------------------------------------------ 1. the Dragon Roost unlocks with Ember Crown
            r=await E("()=>{RPP().stars={moss:3,frost:3};rpStart('moss');const R=RPX;R.supply=9999;const ok=rpBuild(R.pads[0],'dragon');const c=document.querySelector('.rpcard[data-tw=\"dragon\"]');return [ok,!!R.pads[0].tw,c&&c.classList.contains('lock'),document.querySelectorAll('.rpbar .rpcard').length]}")
            chk('the Dragon Roost is locked (card and build) before Ember Crown is won; seven tower cards',r==[False,False,True,7],r)
            r=await E("()=>{rpLeave();rpStart('ember');const R=RPX;R.tut=null;R.wave=20;R.hp=20;R.winHp=20;rpVictory();rpFinish(true);const card=!!document.querySelector('.rpdun,.rpunld');rpLeave();rpStart('moss');const R2=RPX;R2.supply=9999;const ok=rpBuild(R2.pads[0],'dragon');return [card,ok,RPP().dragon,!document.querySelector('.rpcard[data-tw=\"dragon\"]').classList.contains('lock')]}")
            chk('winning Ember Crown shows the unlock card and the dragon can be built',r==[True,True,1,True],r)
            r=await E("""()=>{const R=RPX;const p=R.pads[0];p.tw.build=1;R.wst='run';R.wave=3;R.q=[];let best=0,bd=1e9,bp=0;R.G.paths.forEach((P2,pi)=>{for(let s=0;s<P2.len;s+=8){const q=rpAt(R.G,s,pi);const d=Math.hypot(q.x-p.x,(q.y-p.y)/.75);if(d<bd){bd=d;best=s;bp=pi}}});
              const fs=[];for(let k=0;k<5;k++){const e=rpSpawn(k%2?'scamp':'gloom',bp);e.sp=0;e.s=best+k*10;e.hp=e.mx=1e6;fs.push(e)}const h0=fs.map(e=>e.hp);p.tw.cd=0;for(let i=0;i<120;i++)rpStep(R,1/60);
              const hurt=fs.filter((e,i)=>e.hp<h0[i]).length,air=fs.some((e,i)=>e.air&&e.hp<h0[i]);p.tw.ckCd=0;p.tw.br=0;p.tw.st='idle';p.tw.streams=null;p.tw.cd=9;const c1=rpCrank(p.tw);const cd=p.tw.cd,c2=rpCrank(p.tw);return [hurt>=3,air,c1,cd,c2,p.tw.ckCd>0]}""")
            chk('the dragon breath burns several monsters at once and hits a flyer it targets; Wind up fires at once, then waits',r==[True,True,True,0,False,True],r)
            # 9.1: a 40-second fight with three tier-3 dragons: no flipping back and forth, the fire stays on its target, and starts at the mouth
            r=await E("""()=>{rpLeave();rpStart('ember');const R=RPX;R.tut=null;R.supply=1e7;const tws=[];for(const pi of [2,5,8]){const p=R.pads[pi];rpBuild(p,'dragon');p.tw.build=1;rpUpgrade(p.tw);rpUpgrade(p.tw);p.tw.upK=1;tws.push(p.tw)}
              R.wst='run';R.wave=6;R.q=[];for(let k=0;k<40;k++)R.q.push({id:['scamp','bulwark','gloom','golem'][k%4],at:k*.55});R.wt=0;let flips=0,on=0,n=0,gap=0,g=0,br=0;const lf=new Map();
              for(let f=0;f<60*40;f++){R.wt+=1/60;while(R.q.length&&R.q[0].at<=R.wt){const e=rpSpawn(R.q.shift().id,0);if(e)e.hp=e.mx=e.hp*40}rpStep(R,1/60);R.t+=1/60;
               for(const tw of tws){const s=tw.face>0?1:-1;if(lf.has(tw)&&lf.get(tw)!==s)flips++;lf.set(tw,s);if(tw.st!=='breath'||!tw.streams||!tw.tg)continue;br++;
                const e=tw.tg,q=rpPos(R,e),px=q.x,py=q.y-(e.air?40:18),st=tw.streams[0],[cx,cy]=rpdCtl(st.m.x,st.m.y,st.e.x,st.e.y);let hit=false;
                for(let j=0;j<=20&&!hit;j++){const u=j/20,a=1-u,x=a*a*st.m.x+2*a*u*cx+u*u*st.e.x,y=a*a*st.m.y+2*a*u*cy+u*u*st.e.y;hit=Math.hypot(x-px,y-py)<16+26*u}n++;if(hit)on++;
                const m=rpDMouthW(tw,R.t);gap+=Math.hypot(m.x-st.m.x,m.y-st.m.y);g++}}
              return [flips,br>300,Math.round(on/Math.max(1,n)*100),+(gap/Math.max(1,g)).toFixed(2),RP_TW.dragon.cost[0]]}""")
            chk('9.1: three dragons over 40 s turn only a few times, keep the fire on their target 90%+ of the breath, from the mouth; it costs 500',r[0]<=8 and r[1] and r[2]>=90 and r[3]<2 and r[4]==500,r)
            r=await E("""()=>{const R=RPX;const tw=R.pads[2].tw;const o=rpdO(tw);RPDTW=tw;const okDraw=(()=>{try{rpTowerAt(cv.getContext('2d'),R,tw);return true}catch(e){return e.message}})();RPDTW=null;
              rpLeave();rpStart('moss');const R2=RPX;R2.supply=1e7;const p=R2.pads[4];rpBuild(p,'dragon');const t=p.tw;t.build=1;R2.wst='run';R2.wave=3;R2.q=[];let best=0,bd=1e9,bp=0;R2.G.paths.forEach((P2,pi)=>{for(let s=0;s<P2.len;s+=8){const q=rpAt(R2.G,s,pi);const d=Math.hypot(q.x-p.x-150,(q.y-p.y)/.75);if(d<bd){bd=d;best=s;bp=pi}}});
              const e=rpSpawn('golem',bp);e.s=best;e.sp=0;e.hp=e.mx=1e7;t.cd=0;const seq=[];for(let f=0;f<60*3;f++){rpStep(R2,1/60);R2.t+=1/60;if(!seq.length||seq[seq.length-1]!==t.st)seq.push(t.st)}
              return [okDraw,seq.join('>'),t.an.jaw<.2]}""")
            chk('9.1: the dragon winds up before it breathes, then closes its jaw (idle > wind > breath > idle)',r[0] is True and (r[1].startswith('idle>wind>breath>idle') or r[1].startswith('wind>breath>idle')) and r[2],r)
            await E("()=>rpLeave()")
            # ------------------------------------------------ 2. an empty season, then a real Wonderland run
            st=await E("async()=>{await rpLbLoad(true);return [RPLB.state,RPLB.reached,RPLB.relays,RPLB.list.length]}")
            chk('empty season: the board loads from 3 of 4 relays',st==['ok',3,4,0],st)
            r=await E(RUN,12);chk('a Wonderland run of 12 waves becomes the season best and is sent',r==[12,1,0,True],r)
            me=await E("()=>rkLbKey().pk")
            q=await query(A,{'kinds':[30078],'authors':[me],'#t':[TG(1)]});c=json.loads(q[0]['content']) if q else {}
            chk('my entry is on relay A once, with 12 waves',len(q)==1 and c.get('w')==12 and c.get('s')==1,q)
            r=await E(RUN,7);q=await query(A,{'kinds':[30078],'authors':[me],'#t':[TG(1)]})
            chk('a worse run keeps the best (12) but counts the run',r[0]==12 and r[1]==2 and json.loads(q[0]['content'])['r']==2,(r,q and q[0]['content']))
            q=await query(A,{'kinds':[30078],'authors':[me],'#t':['twwc-lb-s1']})
            chk('the Wonderland board does not touch the Wildcard Ranked board',len(q)==0,q)
            # ------------------------------------------------ 3. other players, order and place
            bots=[honest(100+i,w) for i,w in enumerate([30,25,18,12,9,4])]
            for p_ in (A,B):await post_many(p_,[e for e,_ in bots])
            st=await E("async()=>{await rpLbLoad(true);return {n:RPLB.list.length,ws:RPLB.list.map(e=>e.w),me:RPLB.me&&RPLB.me.place,all:RPLB.all}}")
            chk('the board is sorted by waves; ties go to who reached it first',st['ws']==[30,25,18,12,12,9,4] and st['me']==5,st)
            # ------------------------------------------------ 4. cheats and forgeries stay off the board
            now=int(time.time());S0=T.season_start(1)
            bad=[rp_event(200,{'v':1,'s':1,'n':'Fast','w':80,'d':80*3,'k':2000,'r':1,'t':now-60})[0],          # too little time for the waves
                 rp_event(201,{'v':1,'s':1,'n':'NoKills','w':40,'d':40*30,'k':10,'r':1,'t':now-60})[0],       # too few kills
                 rp_event(202,{'v':1,'s':1,'n':'Early','w':40,'d':40*30,'k':900,'r':1,'t':S0-86400})[0],      # reached before the season
                 rp_event(203,{'v':1,'s':1,'n':'Spam','w':40,'d':40*30,'k':900,'r':10**6,'t':now-60})[0],     # more runs than time allows
                 rp_event(204,{'v':1,'s':2,'n':'Wrong','w':40,'d':40*30,'k':900,'r':1,'t':now-60})[0],        # another season in the content
                 rp_event(205,{'v':1,'s':1,'n':'Tag','w':40,'d':40*30,'k':900,'r':1,'t':now-60},tags=[['d','twrp-lb-s9'],['t',TG(1)]])[0]]
            forged=rp_event(206,{'v':1,'s':1,'n':'Forged','w':99,'d':99*30,'k':5000,'r':1,'t':now-60})[0];forged['sig']='00'*64
            await post_many(A,bad);await post_many(C,bad+[forged])
            xss=rp_event(207,{'v':1,'s':1,'n':'<img src=x onerror=alert(1)>','w':2,'d':80,'k':40,'r':1,'t':now-60})[0];await post_many(A,[xss])
            st=await E("async()=>{await rpLbLoad(true);await rpBoard();await new Promise(r=>setTimeout(r,400));return {ws:RPLB.list.map(e=>e.w),names:RPLB.list.map(e=>e.n),img:document.querySelectorAll('#rplbrows img').length,txt:document.getElementById('rplbrows').textContent}}")
            chk('impossible, mistagged and forged entries are hidden',st['ws']==[30,25,18,12,12,9,4,2] and 'Forged' not in st['names'],st['ws'])
            chk('names are escaped (no injected image)',st['img']==0 and '<img' in st['txt'],st['img'])
            # ------------------------------------------------ 5. the board screen, show/hide
            ui=await E("()=>({place:$('rplbplace').textContent,of:$('rplbof').textContent,me:!!document.querySelector('.rplbr.me'),st:$('rplbst').textContent})")
            chk('the board screen shows my place and the relays',ui['place']=='#5' and ui['me'] and '3 of 4 relays' in ui['st'],ui)
            await E("async()=>{document.querySelector('.rkbtog [data-h=\"1\"]').click();await new Promise(r=>setTimeout(r,300));while(RPLB.p)await RPLB.p;while(RPLB.loading)await RPLB.loading}")
            q=await query(A,{'kinds':[30078],'authors':[me],'#t':[TG(1)]})
            chk('Off posts a hide entry that replaces mine',len(q)==1 and json.loads(q[0]['content']).get('hide')==1,q and q[0]['content'])
            await E("async()=>{document.querySelector('.rkbtog [data-h=\"0\"]').click();await new Promise(r=>setTimeout(r,300));while(RPLB.p)await RPLB.p;while(RPLB.loading)await RPLB.loading}")
            q=await query(A,{'kinds':[30078],'authors':[me],'#t':[TG(1)]})
            chk('On posts my entry again',len(q)==1 and json.loads(q[0]['content']).get('w')==12,q and q[0]['content'])
            # ------------------------------------------------ 6. a second player sees me
            pg2=await player('Mira');E2=pg2.evaluate
            st=await E2("async()=>{await rpLbLoad(true);return RPLB.list.map(e=>[e.n,e.w])}")
            chk('another player sees my entry on the board',['Rowan',12] in st,st)
            # ------------------------------------------------ 7. offline: the saved copy
            st=await E("async()=>{WCRELAYS=['nostr:ws://127.0.0.1:18099'];RPLB.state='idle';await rpLbLoad(true);rpBoard();await new Promise(r=>setTimeout(r,200));return [RPLB.state,$('rplbst').textContent,document.querySelectorAll('.rplbr').length]}")
            chk('offline: the board saved on this device is shown',st[0]=='offline' and 'Offline' in st[1] and st[2]==8,st)
            await E("(a)=>{WCRELAYS=a}",RELAYS)
            # ------------------------------------------------ 8. the season ends: Rowan beats everyone, Mira does not
            r=await E(RUN,45);chk('a 45-wave run takes first place',r[0]==45,r)
            r=await E2(RUN,10)
            shift="(ms)=>{const o=Date.now.bind(Date);Date.now=()=>o()+ms}"
            end=await E("()=>rkSeasonEnd(1)-Date.now()+2*3600e3")
            r=await E(f"async()=>{{({shift})({end});const g0=P.gold;const L=rpLbSt();await rpLbPrize();return [L.s,!!L.hist[1],L.won[1],RPP().own['dragon:azure'],P.gold-g0,L.cel,!!document.getElementById('rpcel')]}}")
            chk('season over: the champion gets the Azure Dragon and 50,000 coins, and the ceremony',r==[2,True,1,1,50000,1,True],r)
            r=await E("async()=>{const g0=P.gold;await rpLbPrize();return [P.gold-g0]}")
            chk('the prize is paid only once',r==[0],r)
            r=await E("async()=>{document.getElementById('rpcelq').click();await new Promise(r=>setTimeout(r,300));const L=rpLbSt();rpLeave&&0;rpStart('moss');const R=RPX;R.supply=9999;rpBuild(R.pads[0],'dragon');const sk=R.pads[0].tw.skin;rpLeave();return [L.cel,RPP().skin.dragon,sk,!!document.getElementById('rpsk')||true]}")
            chk('Equip puts on the Azure Dragon: new dragons are built blue',r[:3]==[0,'azure','azure'],r)
            r=await E2(f"async()=>{{({shift})({end});const g0=P.gold;const L=rpLbSt();await rpLbPrize();return [L.won[1]||0,RPP().own['dragon:azure']||0,P.gold-g0,L.champ[1]&&L.champ[1].n]}}")
            chk('the other player gets nothing and sees who won',r==[0,0,0,'Rowan'],r)
            r=await E2("()=>{rampartsMenu(title);return [!!document.querySelector('.rpchamp'),(document.querySelector('.rpchamp')||{}).textContent]}")
            chk("the hub names last season's champion",r[0] and 'Rowan' in r[1],r)
            # ------------------------------------------------ 9. the Tower Skins screen
            r=await E("()=>{rpSkins();const t=document.querySelector('.rpskt[data-tw=\"dragon\"][data-k=\"azure\"]');return [document.querySelectorAll('.rpskt').length,!!t&&t.classList.contains('eq'),!!t&&!t.classList.contains('lock')]}")
            chk("Tower Skins lists every tower's skins and shows the Azure Dragon equipped",r==[12,True,True],r)
            r=await E("()=>{document.querySelector('.rpskt[data-tw=\"dragon\"][data-k=\"base\"]').click();return RPP().skin.dragon}")
            chk('clicking an owned skin equips it',r=='base',r)
            r=await E("()=>{title();return [!!document.getElementById('rphch'),document.getElementById('rphch').textContent.includes('Azure Dragon')]}")
            chk('the home screen advertises the championship prize',r==[True,True],r)
            await pg.screenshot(path=os.path.join(HERE,'shots/rp_home_champ.png')) if os.path.isdir(os.path.join(HERE,'shots')) else None
            chk('no page errors',not er,er)
            await b.close()
    finally:
        for p in procs:p.terminate()
    print(f'{N[0]-len(FAIL)} / {N[0]} passed');sys.exit(1 if FAIL else 0)
asyncio.run(main())
