/* ===== RUNESTONE RIDDLE 8.4c: a richer rune table and sanctum (replaces the 92h arch and backdrop painters) =====
   Arch (baked once per tile size): bevelled stone blocks with chips and cracks, a gold-moulded recess with corner studs,
   gold-rimmed rune plates, carved energy channels from every rune to the board, a faceted keystone setting and two crystal
   finials. Live layer (every frame, no filter or shadowBlur): channels fill with light as their rune wakes and carry
   travelling pulses; a rune waking throws a spark ring and plays a ting (rrRuneWake); the keystone gem and the crystals
   turn from violet to gold with warmth; soft light beams rise in the recess when you are close; embers trail upward; a
   golden sheen sweeps the stone once the riddle is solved.
   Backdrop (painted once per fit): rose window with light shafts, bookshelves and potion shelves in the side arches,
   candelabra, a carved floor with an arcane circle, rug, book piles. Live extras are DOM only (transform/opacity):
   floating candles, a floor rune ring that brightens with warmth, and the existing motes and torch flames. */
function rrArchBake(G){const c=document.createElement('canvas');c.width=G.W;c.height=G.H;const g=c.getContext('2d'),W=G.W,H=G.H,s=G.side,T=G.t;
 const rnd=i=>rrFr(Math.sin(i*78.233+1.7)*43758.5453);
 const path=()=>{g.beginPath();g.moveTo(4,H-4);g.lineTo(4,G.top*.72);g.quadraticCurveTo(4,G.top*.36,s*.9,G.top*.3);g.lineTo(W*.36,G.top*.22);g.quadraticCurveTo(W/2,2,W*.64,G.top*.22);g.lineTo(W-s*.9,G.top*.3);g.quadraticCurveTo(W-4,G.top*.36,W-4,G.top*.72);g.lineTo(W-4,H-4);g.closePath()};
 path();let q=g.createLinearGradient(0,0,0,H);q.addColorStop(0,'#5e5278');q.addColorStop(.5,'#463c5e');q.addColorStop(1,'#2e2640');g.fillStyle=q;g.fill();
 g.save();path();g.clip();
 /* stone blocks with bevels */
 const bh=T*.6;let n=0;for(let y=0,r=0;y<H;y+=bh,r++){const crown=y<G.top*.7;const segs=crown?[[0,W]]:[[0,s*.86],[W-s*.86,W]];
  for(const [x0,x1] of segs){let x=x0-(r%2?T*.35:0);while(x<x1){const w=Math.min(x1-x,(crown?T*1.05:T*.62)*(.75+rnd(n)*.5));const v=rnd(n*3+1);n++;
   g.fillStyle=rrMix('#4c4064','#6c5e88',v);g.beginPath();g.roundRect(x+1.5,y+1.5,w-3,bh-3,3);g.fill();
   g.strokeStyle='#ffffff26';g.lineWidth=1.5;g.beginPath();g.moveTo(x+3,y+bh-3);g.lineTo(x+3,y+3);g.lineTo(x+w-3,y+3);g.stroke();
   g.strokeStyle='#12081f66';g.beginPath();g.moveTo(x+w-2.5,y+3);g.lineTo(x+w-2.5,y+bh-2.5);g.lineTo(x+3,y+bh-2.5);g.stroke();
   if(v>.86){g.fillStyle='#00000030';g.beginPath();g.arc(x+w*rnd(n+5),y+bh*rnd(n+6),2+rnd(n)*3,0,TAU);g.fill()}
   if(v<.08){g.fillStyle='#a87aff40';g.beginPath();const cx=x+w*.5,cy=y+bh*.5;g.moveTo(cx,cy-4);g.lineTo(cx+3,cy);g.lineTo(cx,cy+4);g.lineTo(cx-3,cy);g.closePath();g.fill()}
   x+=w}}}
 /* cracks */
 g.strokeStyle='#12081f88';g.lineWidth=1.6;for(let i=0;i<5;i++){let x=rnd(i+40)<.5?s*rnd(i+41)*.8:W-s*rnd(i+42)*.8,y=G.top+rnd(i+43)*(H-G.top-20);g.beginPath();g.moveTo(x,y);for(let k=0;k<4;k++){x+=(rnd(i*9+k)-.5)*12;y+=6+rnd(i*7+k)*10;g.lineTo(x,y)}g.stroke()}
 /* light from the upper left, shadow to the right and bottom */
 q=g.createLinearGradient(0,0,W,0);q.addColorStop(0,'#ffffff14');q.addColorStop(.15,'#0000');q.addColorStop(.85,'#0000');q.addColorStop(1,'#00000050');g.fillStyle=q;g.fillRect(0,0,W,H);
 q=g.createLinearGradient(0,0,0,H);q.addColorStop(0,'#0000');q.addColorStop(.75,'#0000');q.addColorStop(1,'#00000055');g.fillStyle=q;g.fillRect(0,0,W,H);
 g.restore();
 path();g.lineWidth=6;g.strokeStyle='#12081f';g.stroke();
 /* plinth */
 const pb=Math.max(10,G.bot*.55);g.fillStyle='#2a2238';g.fillRect(6,H-pb,W-12,pb-6);g.fillStyle='#ffffff18';g.fillRect(6,H-pb,W-12,2);g.strokeStyle='#12081f';g.lineWidth=3;g.strokeRect(6,H-pb,W-12,pb-6);
 /* the recess and its gold moulding */
 const rx=s-T*.26,ry=G.top-T*.26,rw=G.gw+T*.52,rh=G.gh+T*.42,rr=T*.24;
 g.beginPath();g.roundRect(rx-7,ry-7,rw+14,rh+14,rr+6);q=g.createLinearGradient(0,ry,0,ry+rh);q.addColorStop(0,'#ffe48a');q.addColorStop(.35,'#d8a028');q.addColorStop(.7,'#9a6410');q.addColorStop(1,'#c98a1a');g.fillStyle=q;g.fill();g.lineWidth=3;g.strokeStyle='#12081f';g.stroke();
 g.beginPath();g.roundRect(rx,ry,rw,rh,rr);q=g.createLinearGradient(0,ry,0,ry+rh);q.addColorStop(0,'#0e0a18');q.addColorStop(1,'#1c1728');g.fillStyle=q;g.fill();g.lineWidth=3;g.strokeStyle='#12081f';g.stroke();
 g.save();g.beginPath();g.roundRect(rx,ry,rw,rh,rr);g.clip();q=g.createLinearGradient(0,ry,0,ry+T*.5);q.addColorStop(0,'#000000a0');q.addColorStop(1,'#0000');g.fillStyle=q;g.fillRect(rx,ry,rw,T*.5);
 q=g.createLinearGradient(rx,0,rx+T*.4,0);q.addColorStop(0,'#00000070');q.addColorStop(1,'#0000');g.fillStyle=q;g.fillRect(rx,ry,T*.4,rh);g.restore();
 const stud=(x,y,z)=>{g.beginPath();g.moveTo(x,y-z);g.lineTo(x+z,y);g.lineTo(x,y+z);g.lineTo(x-z,y);g.closePath();q=g.createLinearGradient(x-z,y-z,x+z,y+z);q.addColorStop(0,'#fff3c0');q.addColorStop(1,'#b8780e');g.fillStyle=q;g.fill();g.lineWidth=2;g.strokeStyle='#12081f';g.stroke()};
 for(const [x,y] of [[rx-3,ry-3],[rx+rw+3,ry-3],[rx-3,ry+rh+3],[rx+rw+3,ry+rh+3],[rx+rw/2,ry+rh+4]])stud(x,y,6);
 /* runes: plates, channels to the recess, and the keystone setting */
 for(const p of rrArchRunes(G)){const r=p.big?T*.36:T*.22;
  g.lineCap='round';if(p.big){g.strokeStyle='#120c1a';g.lineWidth=6;g.beginPath();g.moveTo(p.x,p.y+r*1.6);g.lineTo(p.x,ry-8);g.stroke();g.strokeStyle='#ffffff14';g.lineWidth=1.5;g.beginPath();g.moveTo(p.x+3,p.y+r*1.6);g.lineTo(p.x+3,ry-8);g.stroke()}
  else{const left=p.x<W/2,x0=left?p.x+r*1.15:p.x-r*1.15,x1=left?rx-8:rx+rw+8;g.strokeStyle='#120c1a';g.lineWidth=6;g.beginPath();g.moveTo(x0,p.y);g.lineTo(x1,p.y);g.stroke();g.strokeStyle='#ffffff12';g.lineWidth=1.5;g.beginPath();g.moveTo(x0,p.y+3);g.lineTo(x1,p.y+3);g.stroke()}
  if(p.big){for(const [sz,col] of [[1.75,'#12081f'],[1.62,'#d8a028'],[1.42,'#12081f'],[1.34,'#2a2036']]){g.beginPath();g.moveTo(p.x,p.y-r*sz);g.lineTo(p.x+r*sz,p.y);g.lineTo(p.x,p.y+r*sz);g.lineTo(p.x-r*sz,p.y);g.closePath();g.fillStyle=col;g.fill()}}
  else{g.beginPath();g.roundRect(p.x-r*1.12,p.y-r*1.42,r*2.24,r*2.84,r*.5);g.fillStyle='#12081f';g.fill();g.beginPath();g.roundRect(p.x-r*1.02,p.y-r*1.32,r*2.04,r*2.64,r*.45);g.fillStyle='#b88a2a';g.fill();
   g.beginPath();g.roundRect(p.x-r*.88,p.y-r*1.18,r*1.76,r*2.36,r*.4);g.fillStyle='#211a2e';g.fill()}
  if(!p.big){g.strokeStyle='#120c1a';g.lineWidth=4;g.beginPath();for(const [a,b,c2,d] of p.gl){g.moveTo(p.x+a*r,p.y+b*r);g.lineTo(p.x+c2*r,p.y+d*r)}g.stroke()}}
 /* crystal pedestals on the shoulders */
 for(const fx of [s*.5,W-s*.5]){const fy=G.top*.5;g.fillStyle='#2a2238';g.strokeStyle='#12081f';g.lineWidth=3;g.beginPath();g.roundRect(fx-T*.16,fy+T*.05,T*.32,T*.14,3);g.fill();g.stroke()}
 return c}
function rrRuneWake(i){try{if(typeof RRAX==='object'&&RRAX.on)return;{beep(1320+i*110,.07,'sine',.07);setTimeout(()=>beep(2640+i*160,.05,'triangle',.035),45)}}catch(e){}}
function rrArchLive(cv){const G=rrArchGeo();cv.width=G.W;cv.height=G.H;const bake=rrArchBake(G),runes=rrArchRunes(G),g=cv.getContext('2d'),T=G.t;let lt=0;const was={},bursts=[];
 const rx=G.side-T*.26,ry=G.top-T*.26,rw=G.gw+T*.52,rh=G.gh+T*.42;let primed=false;
 const path=()=>{const W=G.W,H=G.H,s=G.side;g.beginPath();g.moveTo(4,H-4);g.lineTo(4,G.top*.72);g.quadraticCurveTo(4,G.top*.36,s*.9,G.top*.3);g.lineTo(W*.36,G.top*.22);g.quadraticCurveTo(W/2,2,W*.64,G.top*.22);g.lineTo(W-s*.9,G.top*.3);g.quadraticCurveTo(W-4,G.top*.36,W-4,G.top*.72);g.lineTo(W-4,H-4);g.closePath()};
 const hex=(c,a)=>c+Math.round(Math.max(0,Math.min(1,a))*255).toString(16).padStart(2,'0');
 return t=>{if(!RR)return;const dt=Math.min(.1,Math.max(0,t-lt));lt=t;RR.hv=(RR.hv||0)+((RR.heat||0)-(RR.hv||0))*Math.min(1,dt*2.2);const h=RR.hv,rm=rrRM();
  g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,G.W,G.H);g.drawImage(bake,0,0);
  const col=h<.5?rrMix('#8a5aff','#c08aff',h*2):rrMix('#c08aff','#ffd45a',Math.min(1,(h-.5)*2)),sp=2+h*4;
  if(RR.flq){RR.fl=t;RR.flq=0}const fl=Math.max(0,1-(t-(RR.fl==null?-9:RR.fl))*2.2);
  /* recess light */
  let a=.08+h*.42+fl*.3;{const q=g.createRadialGradient(G.W/2,ry+rh*.55,10,G.W/2,ry+rh*.55,rw*.75);const c2=fl>.2?'#7af0b0':col;q.addColorStop(0,hex(c2,0));q.addColorStop(.55,hex(c2,a*.45));q.addColorStop(1,hex(c2,0));g.fillStyle=q;g.fillRect(rx,ry,rw,rh)}
  if(h>.45&&!rm){g.save();g.beginPath();g.roundRect(rx,ry,rw,rh,T*.24);g.clip();for(let i=0;i<3;i++){const bx=rx+rw*(.2+.3*i)+Math.sin(t*.4+i*2)*rw*.06,bw=rw*.14;const q=g.createLinearGradient(0,ry+rh,0,ry);q.addColorStop(0,hex(col,(h-.45)*.5));q.addColorStop(1,hex(col,0));g.fillStyle=q;g.beginPath();g.moveTo(bx-bw*.5,ry+rh);g.lineTo(bx+bw*.5,ry+rh);g.lineTo(bx+bw*.15,ry);g.lineTo(bx-bw*.15,ry);g.closePath();g.fill()}g.restore()}
  /* runes, their channels and wake bursts */
  let lit10=0;for(const p of runes){const lit=p.big?Math.max(0,(h-.55)/.45):Math.max(0,Math.min(1,h*11-p.o)),pu=rm?1:.8+.2*Math.sin(t*sp+p.o*1.3),I=(.34+.66*lit)*pu,r=p.big?T*.36:T*.22;
   if(!p.big){if(lit>.9)lit10++;const wv=was[p.o]||0;if(primed&&lit>.9&&wv<=.9){bursts.push({x:p.x,y:p.y,t0:t,c:col});rrRuneWake(p.o)}was[p.o]=lit}
   const left=p.x<G.W/2;if(lit>.02){g.lineCap='round';g.strokeStyle=hex(col,lit*.85);g.lineWidth=3;g.beginPath();if(p.big){g.moveTo(p.x,p.y+r*1.6);g.lineTo(p.x,ry-8)}else{g.moveTo(left?p.x+r*1.15:p.x-r*1.15,p.y);g.lineTo(left?rx-8:rx+rw+8,p.y)}g.stroke();
    if(!rm){const u=rrFr(t*.9+p.o*.17),x0=p.big?p.x:left?p.x+r*1.15:p.x-r*1.15,x1=p.big?p.x:left?rx-8:rx+rw+8,y0=p.big?p.y+r*1.6:p.y,y1=p.big?ry-8:p.y;g.fillStyle=hex('#fff6d8',lit*Math.sin(u*Math.PI));g.beginPath();g.arc(x0+(x1-x0)*u,y0+(y1-y0)*u,2.6,0,TAU);g.fill()}}
   const q=g.createRadialGradient(p.x,p.y,1,p.x,p.y,r*(2.2+lit*1.4));q.addColorStop(0,hex(col,I*.6));q.addColorStop(1,hex(col,0));g.fillStyle=q;g.fillRect(p.x-r*4,p.y-r*4,r*8,r*8);
   if(p.big){/* the keystone gem */const z=r*1.12,gc=h<.5?'#9a6aff':h<.85?'#c890ff':'#ffd45a',gd=rrMix(gc,'#12081f',.45),gl=rrMix(gc,'#ffffff',.55);
    g.beginPath();g.moveTo(p.x,p.y-z);g.lineTo(p.x+z,p.y);g.lineTo(p.x,p.y+z);g.lineTo(p.x-z,p.y);g.closePath();g.fillStyle=gc;g.fill();
    g.fillStyle=gd;g.beginPath();g.moveTo(p.x,p.y);g.lineTo(p.x+z,p.y);g.lineTo(p.x,p.y+z);g.closePath();g.fill();g.fillStyle=gl;g.beginPath();g.moveTo(p.x,p.y);g.lineTo(p.x-z,p.y);g.lineTo(p.x,p.y-z);g.closePath();g.fill();
    g.fillStyle=hex('#ffffff',.25+.5*I);g.beginPath();g.moveTo(p.x-z*.45,p.y-z*.2);g.lineTo(p.x-z*.1,p.y-z*.55);g.lineTo(p.x,p.y-z*.2);g.closePath();g.fill();
    g.lineWidth=2.5;g.strokeStyle='#12081f';g.beginPath();g.moveTo(p.x,p.y-z);g.lineTo(p.x+z,p.y);g.lineTo(p.x,p.y+z);g.lineTo(p.x-z,p.y);g.closePath();g.stroke();
    const gp=rrFr(t*.33);if(gp<.12&&!rm){const k=gp/.12,a2=Math.sin(k*Math.PI);g.fillStyle=hex('#ffffff',a2);rrStar4(g,p.x+z*.3,p.y-z*.35,5*a2)}}
   else{g.globalAlpha=Math.min(1,.18+I*.5);g.strokeStyle=col;g.lineWidth=7;g.lineCap='round';g.beginPath();for(const [a2,b,c2,d] of p.gl){g.moveTo(p.x+a2*r,p.y+b*r);g.lineTo(p.x+c2*r,p.y+d*r)}g.stroke();
    g.globalAlpha=Math.min(1,.3+I);g.strokeStyle=lit>.5?'#fff6d8':rrMix(col,'#ffffff',.25);g.lineWidth=3;g.beginPath();for(const [a2,b,c2,d] of p.gl){g.moveTo(p.x+a2*r,p.y+b*r);g.lineTo(p.x+c2*r,p.y+d*r)}g.stroke();g.globalAlpha=1}}
  primed=true;
  for(let i=bursts.length-1;i>=0;i--){const B=bursts[i],u=(t-B.t0)/.7;if(u>=1||u<0){bursts.splice(i,1);continue}g.globalAlpha=1-u;g.strokeStyle=B.c;g.lineWidth=3*(1-u)+1;g.beginPath();g.arc(B.x,B.y,6+u*T*.7,0,TAU);g.stroke();
   for(let k=0;k<8;k++){const an=k*TAU/8+B.t0,d=6+u*T*.9;g.fillStyle=k%2?'#fff6d8':B.c;g.beginPath();g.arc(B.x+Math.cos(an)*d,B.y+Math.sin(an)*d,2.2*(1-u)+.5,0,TAU);g.fill()}g.globalAlpha=1}
  /* crystal finials */
  for(const [i,fx] of [[0,G.side*.5],[1,G.W-G.side*.5]]){const fy=G.top*.5,ch=T*.42,cw=T*.13,bob=rm?0:Math.sin(t*1.6+i)*2,gc=h<.6?'#a87aff':'#ffd45a';
   const q=g.createRadialGradient(fx,fy-ch*.4+bob,2,fx,fy-ch*.4+bob,ch*1.3);q.addColorStop(0,hex(gc,.25+h*.5));q.addColorStop(1,hex(gc,0));g.fillStyle=q;g.fillRect(fx-ch*1.4,fy-ch*1.8+bob,ch*2.8,ch*2.8);
   g.beginPath();g.moveTo(fx,fy-ch+bob);g.lineTo(fx+cw,fy-ch*.62+bob);g.lineTo(fx+cw,fy-ch*.1+bob);g.lineTo(fx,fy+T*.05+bob);g.lineTo(fx-cw,fy-ch*.1+bob);g.lineTo(fx-cw,fy-ch*.62+bob);g.closePath();
   const q2=g.createLinearGradient(fx-cw,0,fx+cw,0);q2.addColorStop(0,rrMix(gc,'#ffffff',.5));q2.addColorStop(.5,gc);q2.addColorStop(1,rrMix(gc,'#12081f',.45));g.fillStyle=q2;g.fill();g.lineWidth=2.5;g.strokeStyle='#12081f';g.stroke();
   g.strokeStyle='#ffffff88';g.lineWidth=1.2;g.beginPath();g.moveTo(fx,fy-ch+bob+3);g.lineTo(fx,fy+bob);g.stroke()}
  /* embers */
  if(!rm){const n=Math.round(3+h*18);for(let i=0;i<n;i++){const side=i%2,u=rrFr(t*(.16+h*.25)+i*.137),x=(side?G.W-G.side*.42:G.side*.42)+Math.sin(t*2+i)*G.side*.3,y=G.H-u*G.H*1.05,al=Math.sin(u*Math.PI)*(.45+h*.55),sz=1.3+((i*7)%3)*.8;
   g.fillStyle=hex(i%3?col:'#fff3c0',al);g.beginPath();g.arc(x,y,sz,0,TAU);g.fill();g.fillStyle=hex(col,al*.35);g.beginPath();g.arc(x-Math.cos(t*2+i)*1.5,y+5,sz*.8,0,TAU);g.fill()}}
  /* golden sheen once solved */
  if(!rm&&RR&&RR.mode&&$('rrarchw')&&$('rrarchw').classList.contains('awake')){const u=rrFr(t*.4);if(u<.5){const x=-G.W*.4+u/.5*G.W*1.8;g.save();path();g.clip();const q=g.createLinearGradient(x-60,0,x+60,G.H*.3);q.addColorStop(0,'#fff6d800');q.addColorStop(.5,'#fff6d855');q.addColorStop(1,'#fff6d800');g.fillStyle=q;g.fillRect(0,0,G.W,G.H);g.restore()}}}}
function rrStar4(g,x,y,r){g.beginPath();g.moveTo(x,y-r*2);g.quadraticCurveTo(x,y,x+r*2,y);g.quadraticCurveTo(x,y,x,y+r*2);g.quadraticCurveTo(x,y,x-r*2,y);g.quadraticCurveTo(x,y,x,y-r*2);g.fill()}
/* ---------- the sanctum backdrop (detailed) ---------- */
function rrBgPaint(cv){const W=cv.width,H=cv.height,g=cv.getContext('2d');const rnd=i=>rrFr(Math.sin(i*12.9898+4.1)*43758.5453);const fl=H*.8;let q;
 q=g.createLinearGradient(0,0,0,H);q.addColorStop(0,'#1e1238');q.addColorStop(.6,'#130b28');q.addColorStop(1,'#0a0616');g.fillStyle=q;g.fillRect(0,0,W,H);
 /* wall blocks with bevels */
 const bh=46;for(let r=0,y=0;y<fl;r++,y+=bh){const off=(r%2)*55;for(let x=-off,i=0;x<W;i++){const w=90+rnd(r*31+i)*60,v=rnd(r*7+i*3),al=.55+.3*(1-y/fl);
  g.globalAlpha=al;g.fillStyle=rrMix('#241838','#36284f',v*.75);g.beginPath();g.roundRect(x+2,y+2,w-4,bh-4,6);g.fill();g.fillStyle='#ffffff10';g.fillRect(x+4,y+3,w-8,2);g.fillStyle='#00000030';g.fillRect(x+4,y+bh-5,w-8,2);x+=w}}g.globalAlpha=1;
 /* rose window behind the board's crown, with light shafts */
 const rwx=W*.445,rwy=H*.17,R=Math.min(W,H)*.15;
 q=g.createRadialGradient(rwx,rwy,R*.2,rwx,rwy,R*2.6);q.addColorStop(0,'#8a5aff40');q.addColorStop(1,'#0000');g.fillStyle=q;g.fillRect(0,0,W,H*.7);
 g.save();g.globalAlpha=.11;g.fillStyle='#c8a8ff';for(const [dx,w] of [[-.9,.5],[-.2,.4],[.55,.45]]){g.beginPath();g.moveTo(rwx+dx*R-w*R*.3,rwy);g.lineTo(rwx+dx*R+w*R*.3,rwy);g.lineTo(rwx+dx*R*3+w*R*1.4,fl);g.lineTo(rwx+dx*R*3-w*R*.6,fl);g.closePath();g.fill()}g.restore();
 g.fillStyle='#2a2040';g.beginPath();g.arc(rwx,rwy,R+14,0,TAU);g.fill();g.lineWidth=5;g.strokeStyle='#12081f';g.stroke();
 for(let i=0;i<12;i++){const a0=i*TAU/12,a1=a0+TAU/12;q=g.createRadialGradient(rwx,rwy,R*.2,rwx,rwy,R);const c=['#7a3ad8','#3a5ad8','#c03a8a','#d8a028'][i%4];q.addColorStop(0,rrMix(c,'#ffffff',.35));q.addColorStop(1,rrMix(c,'#12081f',.35));
  g.fillStyle=q;g.beginPath();g.moveTo(rwx,rwy);g.arc(rwx,rwy,R,a0,a1);g.closePath();g.fill()}
 g.strokeStyle='#12081f';g.lineWidth=4;for(let i=0;i<12;i++){const a=i*TAU/12;g.beginPath();g.moveTo(rwx,rwy);g.lineTo(rwx+Math.cos(a)*R,rwy+Math.sin(a)*R);g.stroke()}
 g.beginPath();g.arc(rwx,rwy,R*.55,0,TAU);g.stroke();g.beginPath();g.arc(rwx,rwy,R,0,TAU);g.stroke();
 g.fillStyle='#ffe48a';g.beginPath();g.arc(rwx,rwy,R*.2,0,TAU);g.fill();g.stroke();g.fillStyle='#ffffff30';g.beginPath();g.arc(rwx-R*.35,rwy-R*.4,R*.25,0,TAU);g.fill();
 /* arches */
 const arch=(cx,w,top,bot,col,rim)=>{g.beginPath();g.moveTo(cx-w/2,bot);g.lineTo(cx-w/2,top+w*.42);g.quadraticCurveTo(cx-w/2,top,cx,top-w*.08);g.quadraticCurveTo(cx+w/2,top,cx+w/2,top+w*.42);g.lineTo(cx+w/2,bot);g.closePath();
  g.fillStyle=col;g.fill();g.lineWidth=14;g.strokeStyle=rim;g.stroke();g.lineWidth=4;g.strokeStyle='#12081f';g.stroke()};
 arch(W*.17,W*.2,H*.2,fl,'#110a24','#2a2040');arch(W*.83,W*.2,H*.2,fl,'#110a24','#2a2040');
 /* bookshelves inside the side arches */
 const shelf=(cx,w)=>{const x0=cx-w*.42,x1=cx+w*.42;for(let k=0;k<4;k++){const sy=H*.38+k*H*.105;g.fillStyle='#3a2414';g.fillRect(x0,sy,x1-x0,8);g.strokeStyle='#12081f';g.lineWidth=2;g.strokeRect(x0,sy,x1-x0,8);
  let x=x0+4;let i=0;while(x<x1-10){const bw=8+rnd(cx+k*17+i)*10,bh2=H*.06+rnd(cx+k*5+i)*H*.03,c=['#6a2a8a','#2a4a8a','#8a2a3a','#2a6a4a','#8a6a20','#4a2a6a'][(k+i)%6];
   if(rnd(cx+i*3+k)<.12){g.fillStyle='#7af0b060';g.beginPath();g.arc(x+6,sy-8,6,0,TAU);g.fill();g.fillStyle='#2a6a5a';g.fillRect(x+4,sy-18,4,6);x+=16;i++;continue}
   g.fillStyle=c;g.fillRect(x,sy-bh2,bw-1,bh2);g.fillStyle='#ffe0a040';g.fillRect(x+1,sy-bh2+6,bw-3,2);g.strokeStyle='#12081f88';g.lineWidth=1;g.strokeRect(x,sy-bh2,bw-1,bh2);x+=bw;i++}}};
 shelf(W*.17,W*.2);shelf(W*.83,W*.2);
 /* banners in front of the shelves */
 const ban=(cx,top,w,h)=>{g.fillStyle='#3a2a10';g.fillRect(cx-w/2-10,top-8,w+20,8);g.fillStyle='#c98a10';g.beginPath();g.arc(cx-w/2-12,top-4,6,0,TAU);g.arc(cx+w/2+12,top-4,6,0,TAU);g.fill();
  g.beginPath();g.moveTo(cx-w/2,top);g.lineTo(cx+w/2,top);g.lineTo(cx+w/2,top+h);g.lineTo(cx,top+h+w*.32);g.lineTo(cx-w/2,top+h);g.closePath();q=g.createLinearGradient(cx-w/2,0,cx+w/2,0);q.addColorStop(0,'#5a2490');q.addColorStop(.6,'#3e1670');q.addColorStop(1,'#2a0e50');g.fillStyle=q;g.fill();
  g.lineWidth=4;g.strokeStyle='#12081f';g.stroke();g.lineWidth=3;g.strokeStyle='#d8a028';g.beginPath();g.moveTo(cx-w/2+9,top+6);g.lineTo(cx-w/2+9,top+h-4);g.lineTo(cx,top+h+w*.32-12);g.lineTo(cx+w/2-9,top+h-4);g.lineTo(cx+w/2-9,top+6);g.stroke();
  for(let i=0;i<6;i++){g.fillStyle='#d8a028';g.beginPath();g.arc(cx-w/2+9+(w-18)*i/5,top+h*.08,2.2,0,TAU);g.fill()}
  const ey=top+h*.48;g.fillStyle='#d8a028';g.beginPath();g.moveTo(cx,ey-w*.3);g.lineTo(cx+w*.22,ey);g.lineTo(cx,ey+w*.3);g.lineTo(cx-w*.22,ey);g.closePath();g.fill();g.lineWidth=3;g.strokeStyle='#12081f';g.stroke();
  g.fillStyle='#3e1670';g.beginPath();g.moveTo(cx,ey-w*.16);g.lineTo(cx+w*.11,ey);g.lineTo(cx,ey+w*.16);g.lineTo(cx-w*.11,ey);g.closePath();g.fill();g.fillStyle='#ffe48a';g.beginPath();g.arc(cx,ey,3.5,0,TAU);g.fill();
  g.fillStyle='#d8a028';for(let i=0;i<5;i++){g.fillRect(cx-w/2+6+i*(w-12)/4,top+h+w*.32*(1-Math.abs(i-2)/2)-4,2,10)}};
 ban(W*.17,H*.27,W*.075,H*.3);ban(W*.83,H*.27,W*.075,H*.3);
 /* pillars */
 const pil=(x,w,lit)=>{q=g.createLinearGradient(x,0,x+w,0);q.addColorStop(0,lit<0?'#4a3a5a':'#251a36');q.addColorStop(.5,'#3a2c4c');q.addColorStop(1,lit>0?'#4a3a5a':'#1c1428');g.fillStyle=q;g.fillRect(x,0,w,fl+8);
  g.strokeStyle='#12081f55';g.lineWidth=3;for(let i=1;i<4;i++){g.beginPath();g.moveTo(x+w*i/4,H*.12);g.lineTo(x+w*i/4,fl-30);g.stroke()}
  g.strokeStyle='#ffffff10';g.lineWidth=1.5;for(let i=1;i<4;i++){g.beginPath();g.moveTo(x+w*i/4+3,H*.12);g.lineTo(x+w*i/4+3,fl-30);g.stroke()}
  g.fillStyle='#2e2240';g.fillRect(x-10,H*.08,w+20,26);g.fillRect(x-12,fl-36,w+24,40);g.strokeStyle='#12081f';g.lineWidth=4;g.strokeRect(x-10,H*.08,w+20,26);g.strokeRect(x-12,fl-36,w+24,40);g.strokeRect(x,0,w,fl+8);
  g.fillStyle='#d8a02855';g.fillRect(x-10,H*.08+20,w+20,3)};
 pil(-10,W*.07,1);pil(W-W*.07+10,W*.07,-1);
 for(const tx of [W*.085,W*.915]){const ty=H*.43;g.fillStyle='#2a2030';g.strokeStyle='#12081f';g.lineWidth=4;g.beginPath();g.moveTo(tx-22,ty);g.lineTo(tx+22,ty);g.lineTo(tx+12,ty+18);g.lineTo(tx-12,ty+18);g.closePath();g.fill();g.stroke();
  g.fillRect(tx-5,ty+18,10,40);g.strokeRect(tx-5,ty+18,10,40);g.fillStyle='#8a5a20';g.beginPath();g.ellipse(tx,ty,22,6,0,0,TAU);g.fill();g.stroke();
  q=g.createRadialGradient(tx,ty-30,10,tx,ty-30,W*.16);q.addColorStop(0,'#ff9a3a30');q.addColorStop(1,'#0000');g.fillStyle=q;g.fillRect(0,0,W,H)}
 /* floor: flagstones in perspective, an arcane circle, the rug */
 q=g.createLinearGradient(0,fl,0,H);q.addColorStop(0,'#21163a');q.addColorStop(1,'#0e0918');g.fillStyle=q;g.fillRect(0,fl,W,H-fl);
 g.strokeStyle='#ffffff0e';g.lineWidth=2;for(let i=0;i<6;i++){const y=fl+(H-fl)*(i/6)**1.4;g.beginPath();g.moveTo(0,y);g.lineTo(W,y);g.stroke()}
 for(let i=-10;i<=10;i++){g.beginPath();g.moveTo(W/2+i*70,fl);g.lineTo(W/2+i*190,H);g.stroke()}
 g.beginPath();g.moveTo(W*.32,fl+20);g.lineTo(W*.68,fl+20);g.lineTo(W*.78,H);g.lineTo(W*.22,H);g.closePath();q=g.createLinearGradient(0,fl,0,H);q.addColorStop(0,'#3e1c64');q.addColorStop(1,'#2a1048');g.fillStyle=q;g.fill();
 g.lineWidth=4;g.strokeStyle='#12081f';g.stroke();g.strokeStyle='#c98a10';g.lineWidth=3;g.beginPath();g.moveTo(W*.335,fl+30);g.lineTo(W*.665,fl+30);g.lineTo(W*.755,H);g.moveTo(W*.335,fl+30);g.lineTo(W*.245,H);g.stroke();
 g.fillStyle='#c98a1088';for(let i=0;i<9;i++){const x=W*.36+i*(W*.28/8);g.beginPath();g.moveTo(x,fl+44);g.lineTo(x+8,fl+52);g.lineTo(x,fl+60);g.lineTo(x-8,fl+52);g.closePath();g.fill()}
 /* candelabra and potion shelf flanking the floor */
 const cand=(x,y)=>{g.strokeStyle='#12081f';g.lineWidth=3;g.fillStyle='#b8862a';g.fillRect(x-3,y-70,6,70);g.strokeRect(x-3,y-70,6,70);g.beginPath();g.ellipse(x,y,18,6,0,0,TAU);g.fill();g.stroke();
  g.beginPath();g.moveTo(x-26,y-62);g.quadraticCurveTo(x,y-46,x+26,y-62);g.lineWidth=5;g.strokeStyle='#12081f';g.stroke();g.lineWidth=3;g.strokeStyle='#b8862a';g.stroke();
  for(const dx of [-26,0,26]){const cy=y-(dx?62:74);g.fillStyle='#f0e2c0';g.strokeStyle='#12081f';g.lineWidth=2;g.beginPath();g.roundRect(x+dx-4,cy-18,8,18,2);g.fill();g.stroke();
   q=g.createRadialGradient(x+dx,cy-24,1,x+dx,cy-24,26);q.addColorStop(0,'#ffcf6a70');q.addColorStop(1,'#0000');g.fillStyle=q;g.fillRect(x+dx-26,cy-50,52,52);g.fillStyle='#ffb43a';g.beginPath();g.ellipse(x+dx,cy-25,3,6,0,0,TAU);g.fill();g.fillStyle='#fff3c0';g.beginPath();g.arc(x+dx,cy-23,1.6,0,TAU);g.fill()}};
 cand(W*.218,H-26);
 const pots=(x,y)=>{g.fillStyle='#3a2414';g.fillRect(x-60,y,120,8);g.strokeStyle='#12081f';g.lineWidth=2;g.strokeRect(x-60,y,120,8);
  [['#7af0b0',-44,16],['#ff6a9a',-18,20],['#6ad8ff',8,14],['#ffd45a',32,18]].forEach(([c,dx,hh])=>{q=g.createLinearGradient(0,y-hh-10,0,y);q.addColorStop(0,rrMix(c,'#ffffff',.35));q.addColorStop(1,rrMix(c,'#12081f',.25));g.fillStyle=q;g.beginPath();g.roundRect(x+dx-8,y-hh,16,hh,5);g.fill();g.stroke();
   g.fillStyle='#d8c8a8';g.fillRect(x+dx-3,y-hh-7,6,7);g.strokeRect(x+dx-3,y-hh-7,6,7);g.fillStyle=c+'40';g.beginPath();g.arc(x+dx,y-hh/2,14,0,TAU);g.fill()})};
 pots(W*.83,H*.38-4);
 /* book piles and candles */
 const books=(x,y,n,s)=>{const cols=['#5a2a8a','#2a4a8a','#8a2a3a','#2a6a4a','#7a5a20'];for(let i=0;i<n;i++){const w=(70+rnd(x+i)*40)*s,h=16*s,bx=x-w/2+(rnd(i+x*2)-.5)*14*s,by=y-(i+1)*h;
  g.fillStyle=cols[(i+Math.floor(x))%5];g.strokeStyle='#12081f';g.lineWidth=3;g.beginPath();g.roundRect(bx,by,w,h-2,3);g.fill();g.stroke();g.fillStyle='#ffe0a066';g.fillRect(bx+6,by+4*s,w-12,2*s);g.fillStyle='#d8a02888';g.fillRect(bx+w-12*s,by+2,3*s,h-6)}
  return y-n*16*s};
 const candle=(x,y,h)=>{g.fillStyle='#f0e2c0';g.strokeStyle='#12081f';g.lineWidth=3;g.beginPath();g.roundRect(x-7,y-h,14,h,3);g.fill();g.stroke();g.fillStyle='#e8d8b0';g.beginPath();g.ellipse(x+4,y-h+8,3,7,0,0,TAU);g.fill();
  q=g.createRadialGradient(x,y-h-10,2,x,y-h-10,60);q.addColorStop(0,'#ffcf6a66');q.addColorStop(1,'#0000');g.fillStyle=q;g.fillRect(x-60,y-h-70,120,120);
  g.fillStyle='#ffb43a';g.beginPath();g.moveTo(x,y-h-20);g.quadraticCurveTo(x+7,y-h-6,x,y-h-2);g.quadraticCurveTo(x-7,y-h-6,x,y-h-20);g.fill();g.fillStyle='#fff3c0';g.beginPath();g.arc(x,y-h-7,2.5,0,TAU);g.fill()};
 let t1=books(W*.06,H-6,5,1.1);candle(W*.06,t1,36);let t2=books(W*.94,H-6,6,1.1);candle(W*.94+6,t2,28);books(W*.13,H-4,2,.9);books(W*.87,H-4,3,.9);
 /* an open tome and a scroll on the floor */
 g.save();g.translate(W*.9,H*.86);g.rotate(-.12);g.fillStyle='#4a2a14';g.strokeStyle='#12081f';g.lineWidth=3;g.beginPath();g.roundRect(-46,-8,92,16,4);g.fill();g.stroke();
 g.fillStyle='#f2e6c8';g.beginPath();g.moveTo(-44,-8);g.quadraticCurveTo(-22,-20,0,-10);g.quadraticCurveTo(22,-20,44,-8);g.lineTo(44,4);g.quadraticCurveTo(22,-6,0,4);g.quadraticCurveTo(-22,-6,-44,4);g.closePath();g.fill();g.stroke();
 g.strokeStyle='#8a6a4a88';g.lineWidth=1.5;for(let i=0;i<4;i++){g.beginPath();g.moveTo(-38,-8+i*3);g.lineTo(-8,-4+i*3);g.moveTo(8,-4+i*3);g.lineTo(38,-8+i*3);g.stroke()}g.restore();
 q=g.createRadialGradient(W/2,H*.45,H*.3,W/2,H*.5,W*.75);q.addColorStop(0,'#0000');q.addColorStop(1,'#000000a0');g.fillStyle=q;g.fillRect(0,0,W,H)}
/* ---------- live extras: floating candles and a floor rune ring (DOM, transform/opacity only) ---------- */
function rrRingPaint(cv){const g=cv.getContext('2d'),W=cv.width,H=cv.height,cx=W/2,cy=H/2;g.clearRect(0,0,W,H);g.save();g.translate(cx,cy);g.scale(1,.32);
 g.strokeStyle='#c8a8ff';g.lineWidth=5;g.beginPath();g.arc(0,0,W*.46,0,TAU);g.stroke();g.lineWidth=2.5;g.beginPath();g.arc(0,0,W*.38,0,TAU);g.stroke();g.beginPath();g.arc(0,0,W*.24,0,TAU);g.stroke();
 for(let i=0;i<16;i++){const a=i*TAU/16,r=W*.42,gl=RRA_GLY[i%10];g.save();g.translate(Math.cos(a)*r,Math.sin(a)*r);g.lineWidth=3;g.beginPath();for(const [a2,b,c2,d] of gl){g.moveTo(a2*9,b*9);g.lineTo(c2*9,d*9)}g.stroke();g.restore()}
 g.lineWidth=2;for(let i=0;i<6;i++){const a=i*TAU/6,b=a+TAU/3;g.beginPath();g.moveTo(Math.cos(a)*W*.38,Math.sin(a)*W*.38);g.lineTo(Math.cos(b)*W*.38,Math.sin(b)*W*.38);g.stroke()}g.restore()}
{const s0=rrSceneStart;rrSceneStart=function(){const r=$('rr');if(r&&!r.querySelector('.rrfloat')){const f=document.createElement('div');f.className='rrfloat';f.setAttribute('aria-hidden','true');
  f.innerHTML=[[6,24,0],[21,14,1.3],[34,30,2.1],[63,12,.7],[76,26,1.8],[90,18,2.6]].map(([x,y,d])=>`<i style="left:${x}%;top:${y}%;animation-delay:-${d}s"><b></b></i>`).join('');r.insertBefore(f,r.firstChild.nextSibling);
  const ring=document.createElement('canvas');ring.className='rrring2';ring.width=760;ring.height=250;ring.setAttribute('aria-hidden','true');r.insertBefore(ring,f);try{rrRingPaint(ring)}catch(e){}}
 const res=s0.apply(this,arguments);try{rrRingFit()}catch(e){}return res}}
function rrRingFit(){const r=$('rr'),ring=r&&r.querySelector('.rrring2'),w=$('rrarchw');if(!ring||!w)return;const B=r.getBoundingClientRect(),k=B.width/(r.offsetWidth||1)||1,a=w.getBoundingClientRect();
 ring.style.left=((a.left-B.left)/k+a.width/k/2-380)+'px';ring.style.top=Math.max(0,(a.bottom-B.top)/k-150)+'px'}
{const f0=rrSceneFit;rrSceneFit=function(){const r=f0.apply(this,arguments);try{rrRingFit()}catch(e){}return r}}
{const st=document.createElement('style');st.textContent=`
.rrfloat{position:absolute;inset:0;pointer-events:none;z-index:-2;overflow:hidden}
.rrfloat i{position:absolute;width:12px;height:34px;animation:rrCandle 5.5s ease-in-out infinite}
.rrfloat i::before{content:"";position:absolute;left:0;bottom:0;width:12px;height:26px;border-radius:3px;background:linear-gradient(90deg,#fff6dc,#e2d0a8);border:2px solid #12081f}
.rrfloat b{position:absolute;left:1px;top:-8px;width:10px;height:14px;border-radius:50% 50% 45% 45%/60% 60% 40% 40%;background:radial-gradient(circle at 50% 70%,#fff6c8,#ffb43a 60%,#ff7a2a);animation:rrFlick .9s ease-in-out infinite alternate}
.rrfloat b::after{content:"";position:absolute;left:50%;top:50%;width:70px;height:70px;margin:-35px 0 0 -35px;border-radius:50%;background:radial-gradient(circle,#ffcf6a40,#0000 65%)}
.rrring2{position:absolute;width:760px;height:250px;z-index:-2;pointer-events:none;opacity:calc(.12 + var(--rheat,0)*.6);transition:opacity 1.2s}
@keyframes rrCandle{0%,100%{transform:translateY(0) rotate(-2deg)}50%{transform:translateY(-14px) rotate(2deg)}}
@keyframes rrFlick{0%{transform:scale(1,1);opacity:.9}100%{transform:scale(.88,1.12);opacity:1}}
.rr-rm .rrfloat i,.rr-rm .rrfloat b{animation:none}
.rr.rr-narrow .rrfloat,.rr.rr-narrow .rrring2{display:none}`;document.head.appendChild(st)}
{const h0=rrHeatSet;rrHeatSet=function(){const r=h0.apply(this,arguments);try{const x=$('rr');if(x&&RR)x.style.setProperty('--rheat',RR.heat.toFixed(2))}catch(e){}return r}}
