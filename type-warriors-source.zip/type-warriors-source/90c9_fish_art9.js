/* ===== MOONLIT FISHING: fish art 9 — Glowcap Grotto: shroom (common), geode (rare), lshark (rare), coelacanth (legendary) =====
   Each FISHART.<id>(g,t,o) draws one fish facing right, centred on the origin, ~200 units long. Helpers prefixed fa9_
   (the polish kit is a private copy so this file never depends on another file's internals). */
/* path from a command list: 'M',x,y 'L',x,y 'Q',cx,cy,x,y 'C',c1x,c1y,c2x,c2y,x,y 'Z' */
function fa9_path(g,c){g.beginPath();let i=0;while(i<c.length){const k=c[i++];
 if(k==='M'){g.moveTo(c[i],c[i+1]);i+=2}else if(k==='L'){g.lineTo(c[i],c[i+1]);i+=2}
 else if(k==='Q'){g.quadraticCurveTo(c[i],c[i+1],c[i+2],c[i+3]);i+=4}
 else if(k==='C'){g.bezierCurveTo(c[i],c[i+1],c[i+2],c[i+3],c[i+4],c[i+5]);i+=6}else if(k==='Z')g.closePath()}}
/* crisp closed polygon */
function fa9_poly(g,p){g.beginPath();g.moveTo(p[0],p[1]);for(let i=2;i<p.length;i+=2)g.lineTo(p[i],p[i+1]);g.closePath()}
/* gradient with explicit stops [[pos,colour],...] */
function fa9_grad(g,x0,y0,x1,y1,s){const q=g.createLinearGradient(x0,y0,x1,y1);for(const e of s)q.addColorStop(e[0],e[1]);return q}
function fa9_rgrad(g,x,y,r0,r1,s){const q=g.createRadialGradient(x,y,r0,x,y,r1);for(const e of s)q.addColorStop(e[0],e[1]);return q}
/* run fn in a translated + rotated frame */
function fa9_at(g,x,y,a,fn){g.save();g.translate(x,y);g.rotate(a);fn();g.restore()}
/* twinkle 0..1 */
const fa9_tw=(t,i,sp)=>.5+.5*Math.sin(t*(sp||3)+i*1.91);
/* glossy highlight: a soft white curve inside the clip path */
function fa9_gloss(g,clip,x0,y0,cx,cy,x1,y1,w,a){g.save();clip();g.clip();g.lineCap='round';g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo(cx,cy,x1,y1);
 g.strokeStyle=`rgba(255,255,255,${a*.4})`;g.lineWidth=w*2.2;g.stroke();g.strokeStyle=`rgba(255,255,255,${a})`;g.lineWidth=w;g.stroke();g.restore()}
/* gill arc (clipped to the body) */
function fa9_gill(g,clip,x,y,r,a0,a1,c,a){g.save();clip();g.clip();g.beginPath();g.arc(x,y,r,a0,a1);g.strokeStyle=c||FKO;g.globalAlpha=a==null?.6:a;g.lineWidth=2.4;g.lineCap='round';g.stroke();g.restore()}
/* rib lines from a root point to each listed point, clipped to the clip path */
function fa9_ribs(g,clip,x0,y0,pts,a,c,lw){g.save();clip();g.clip();g.strokeStyle=c||FKO;g.globalAlpha=a==null?.25:a;g.lineWidth=lw||1.3;g.lineCap='round';
 for(let i=0;i<pts.length;i+=2){g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo((x0+pts[i])/2,(y0+pts[i+1])/2*1.04,pts[i],pts[i+1]);g.stroke()}g.restore()}
/* tapered strand along a chain of cubic beziers b=[x0,y0, c1x,c1y,c2x,c2y,x1,y1, ...] */
function fa9_strand(g,b,w0,w1,col,lw,rays){const P=[[b[0],b[1]]];let x=b[0],y=b[1];
 for(let i=2;i+5<b.length;i+=6){const c1x=b[i],c1y=b[i+1],c2x=b[i+2],c2y=b[i+3],ex=b[i+4],ey=b[i+5];
  for(let s=1;s<=12;s++){const u=s/12,v=1-u;P.push([v*v*v*x+3*v*v*u*c1x+3*v*u*u*c2x+u*u*u*ex,v*v*v*y+3*v*v*u*c1y+3*v*u*u*c2y+u*u*u*ey])}x=ex;y=ey}
 const n=P.length,L=[],R=[];for(let i=0;i<n;i++){const a=P[Math.max(0,i-1)],c=P[Math.min(n-1,i+1)],dx=c[0]-a[0],dy=c[1]-a[1],d=Math.hypot(dx,dy)||1,w=(w0+(w1-w0)*i/(n-1))/2;
  L.push([P[i][0]-dy/d*w,P[i][1]+dx/d*w]);R.push([P[i][0]+dy/d*w,P[i][1]-dx/d*w])}
 g.beginPath();g.moveTo(L[0][0],L[0][1]);for(const p of L)g.lineTo(p[0],p[1]);for(let i=n-1;i>=0;i--)g.lineTo(R[i][0],R[i][1]);g.closePath();
 g.lineJoin='round';g.lineWidth=lw||2.2;g.strokeStyle=FKO;g.stroke();g.fillStyle=col;g.fill();
 /* optional fin finish: fine rays along the strand and a soft highlight on one edge */
 if(rays){g.save();g.clip();g.lineCap='round';const line=(f,c,w)=>{g.beginPath();for(let i=0;i<n;i++){const px=L[i][0]+(R[i][0]-L[i][0])*f,py=L[i][1]+(R[i][1]-L[i][1])*f;i?g.lineTo(px,py):g.moveTo(px,py)}g.strokeStyle=c;g.lineWidth=w;g.stroke()};
  for(const f of [.3,.5,.7])line(f,rays,.7);line(.16,'rgba(255,255,255,.65)',1.1);g.restore()}}
/* eyelid: amt 0 open .. 1 shut */
function fa9_lid(g,x,y,r,amt,col){if(amt<=0)return;const ly=y-r+2*r*Math.min(1,amt);g.save();g.beginPath();g.arc(x,y,r,0,TAU);g.clip();
 g.beginPath();g.moveTo(x-r-3,y-r-3);g.lineTo(x+r+3,y-r-3);g.lineTo(x+r+3,ly);g.quadraticCurveTo(x,ly+r*.2,x-r-3,ly);g.closePath();g.fillStyle=col;g.fill();
 g.beginPath();g.moveTo(x+r+3,ly);g.quadraticCurveTo(x,ly+r*.2,x-r-3,ly);g.strokeStyle=FKO;g.lineWidth=Math.max(2,r*.26);g.stroke();if(amt>.7){g.globalAlpha=Math.min(1,(amt-.7)/.22);g.beginPath();g.moveTo(x-r*.8,y+r*.02);g.quadraticCurveTo(x,y+r*.56,x+r*.8,y+r*.02);g.lineWidth=Math.max(1.8,r*.24);g.stroke();g.beginPath();g.moveTo(x-r*.5,y-r*.32);g.quadraticCurveTo(x,y-r*.02,x+r*.5,y-r*.32);g.strokeStyle='rgba(255,255,255,.32)';g.lineWidth=Math.max(1,r*.13);g.stroke();g.globalAlpha=1}g.restore();
 g.beginPath();g.arc(x,y,r,0,TAU);g.lineWidth=Math.max(2,r*.24);g.strokeStyle=FKO;g.stroke()}
/* blink: 0 open, rising to 1 for a quick blink every few seconds */
function fa9_blink(t,s){const p=((t+s)%5.1+5.1)%5.1;return p>4.9?1-Math.abs(p-5)/.1:0}
/* small cartoon smile */
function fa9_smile(g,x0,y0,cx,cy,x1,y1,w){g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo(cx,cy,x1,y1);g.strokeStyle=FKO;g.lineWidth=w||2.4;g.lineCap='round';g.stroke()}
/* rosy cheek blush */
function fa9_blush(g,x,y,r,c,a){g.save();g.globalAlpha=a==null?.45:a;g.fillStyle=fa9_rgrad(g,x,y,0,r,[[0,c||'#ff7aa0'],[1,(c||'#ff7aa0')+'00']]);g.beginPath();g.ellipse(x,y,r,r*.62,0,0,TAU);g.fill();g.restore()}
/* pectoral fin: a fan hinged at (x,y), sweeping back; a = tilt */
function fa9_pec(g,x,y,a,L,c1,c2,al,rim){fa9_at(g,x,y,a,()=>{const P=()=>fa9_path(g,['M',3,-3.5,'C',-L*.3,-L*.34,-L*.78,-L*.3,-L,-L*.08,'Q',-L*1.02,L*.08,-L*.9,L*.18,'Q',-L*.8,L*.3,-L*.62,L*.3,'C',-L*.36,L*.28,-L*.1,L*.12,3,3.5,'Z']);
 g.globalAlpha=al||1;P();fkFill(g,fkLin(g,0,0,-L,L*.1,[c1,c2]),2.2);g.globalAlpha=1;fa9_ribs(g,P,2,0,[-L,-L*.12,-L,L*.04,-L*.9,L*.2,-L*.7,L*.3],.3);
 fa9_finfx(g,P,0,0,shade(c1,.45),[-L*.98,-L*.03,-L*.96,L*.12,-L*.82,L*.26],.6,0);
 g.save();P();g.clip();g.beginPath();g.moveTo(2,-3);g.bezierCurveTo(-L*.3,-L*.3,-L*.78,-L*.26,-L*.98,-L*.06);g.strokeStyle=rim||'rgba(255,255,255,.55)';g.lineWidth=2;g.stroke();g.restore();P();g.lineJoin='round';g.lineWidth=2.2;g.strokeStyle=FKO;g.stroke()})}
/* 6-armed snowflake crystal */
function fa9_catch(g,o,c,k){const v=(o.glow||0)*(k||1);if(v>0)fkGlow(g,10,0,115,c||'#fff2c8',.24*v)}
/* ribbon outline from a centre line fn(s)->[x,y,halfWidth]; returns flat points (left side then right side reversed) */
function fa9_rib(n,fn){const c=[];for(let i=0;i<=n;i++)c.push(fn(i/n));const L=[],R=[];
 for(let i=0;i<=n;i++){const a=c[Math.max(0,i-1)],b=c[Math.min(n,i+1)],dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy)||1,nx=-dy/d,ny=dx/d,w=c[i][2];
  L.push(c[i][0]+nx*w,c[i][1]+ny*w);R.unshift(c[i][0]-nx*w,c[i][1]-ny*w)}return L.concat(R)}
/* closed smooth spline (same curve as fkPath) appended to the current path when cont is true */
function fa9_blob(g,p,cont){const n=p.length/2,mx=i=>(p[(i%n)*2]+p[((i+1)%n)*2])/2,my=i=>(p[(i%n)*2+1]+p[((i+1)%n)*2+1])/2;if(!cont)g.beginPath();g.moveTo(mx(n-1),my(n-1));for(let i=0;i<n;i++)g.quadraticCurveTo(p[i*2],p[i*2+1],mx(i),my(i));g.closePath()}
/* clip to everything OUTSIDE a spline outline (so see-through bodies do not show the fin roots behind them) */
function fa9_outside(g,p){g.beginPath();g.rect(-400,-400,800,800);fa9_blob(g,p,1);g.clip('evenodd')}
/* crystal fin polygon: pre points, then an outer edge with a sharp ice shard between every pair of edge points, then post points */
function fa9_rgba(h,a){const n=parseInt(h.slice(1,7),16);return `rgba(${n>>16},${n>>8&255},${n&255},${a})`}
/* rich eye: shaded sclera, gradient iris with a dark rim and fine striations, pupil, big catch-light, second glint and a soft lower reflection */
function fa9_eye(g,x,y,r,iris,look){look=look||0;const ix=x+r*.18+look*r*.12,iy=y+r*.05,ir=r*.62;
 g.beginPath();g.arc(x,y,r,0,TAU);g.fillStyle=fa9_rgrad(g,x-r*.25,y-r*.3,r*.1,r*1.05,[[0,'#ffffff'],[.62,'#fbf7f0'],[1,'#d8d0e6']]);g.fill();
 g.save();g.beginPath();g.arc(x,y,r,0,TAU);g.clip();
 g.beginPath();g.arc(ix,iy,ir,0,TAU);g.fillStyle=fa9_rgrad(g,ix-ir*.15,iy+ir*.25,ir*.08,ir,[[0,shade(iris,.5)],[.45,iris],[.85,shade(iris,-.35)],[1,shade(iris,-.6)]]);g.fill();
 g.strokeStyle=fa9_rgba(shade(iris,.55),.35);g.lineWidth=Math.max(.6,r*.06);g.beginPath();
 for(let i=0;i<10;i++){const a=i/10*TAU+.3;g.moveTo(ix+Math.cos(a)*ir*.42,iy+Math.sin(a)*ir*.42);g.lineTo(ix+Math.cos(a)*ir*.86,iy+Math.sin(a)*ir*.86)}g.stroke();
 g.beginPath();g.arc(ix,iy,ir,0,TAU);g.strokeStyle=fa9_rgba(shade(iris,-.7),.85);g.lineWidth=Math.max(.8,r*.08);g.stroke();
 g.beginPath();g.arc(x+r*.22+look*r*.12,y+r*.08,r*.34,0,TAU);g.fillStyle='#0c0612';g.fill();
 /* upper lid shadow */
 g.fillStyle=fa9_grad(g,0,y-r,0,y-r*.2,[[0,'rgba(40,20,60,.32)'],[1,'rgba(40,20,60,0)']]);g.fillRect(x-r,y-r,r*2,r*.8);
 /* lower reflection crescent */
 g.beginPath();g.arc(ix,iy,ir*.72,Math.PI*.25,Math.PI*.8);g.strokeStyle='rgba(255,255,255,.42)';g.lineWidth=Math.max(.8,r*.1);g.lineCap='round';g.stroke();
 g.restore();
 g.beginPath();g.arc(x,y,r,0,TAU);g.lineWidth=Math.max(2,r*.24);g.strokeStyle=FKO;g.stroke();
 g.beginPath();g.ellipse(x+r*.34,y-r*.24,r*.25,r*.21,-.5,0,TAU);g.fillStyle='#fff';g.fill();
 g.beginPath();g.arc(x+r*.08,y-r*.34,r*.08,0,TAU);g.fill();
 g.beginPath();g.arc(x-r*.06,y+r*.34,r*.1,0,TAU);g.fillStyle='rgba(255,255,255,.75)';g.fill()}
/* rim light: thin light just inside the top edge (moonlight) and a reflected glow inside the bottom edge */
function fa9_rim(g,clip,top,bot,a,w){a=a==null?1:a;w=w||2;g.save();clip();g.clip();
 if(top){g.save();g.translate(.6,w*1.25);clip();g.strokeStyle=top;g.globalAlpha=.55*a;g.lineWidth=w;g.stroke();g.restore()}
 if(bot){g.save();g.translate(-.6,-w*1.3);clip();g.strokeStyle=bot;g.globalAlpha=.5*a;g.lineWidth=w*1.2;g.stroke();g.restore()}
 g.restore()}
/* crisp specular glint (a bright tilted lozenge and a dot) */
function fa9_spec(g,x,y,s,a){g.save();g.globalAlpha=a==null?.95:a;g.fillStyle='#fff';g.beginPath();g.ellipse(x,y,3.4*s,1.25*s,-.42,0,TAU);g.fill();
 g.beginPath();g.arc(x+4.6*s,y-2.4*s,.9*s,0,TAU);g.fill();g.restore()}
/* fin finish: shadowed root, fine secondary rays, and a light translucent band toward the edge */
function fa9_finfx(g,P,rx,ry,edge,rays,a,lw){a=a==null?1:a;g.save();P();g.clip();
 if(rays&&rx!=null){g.strokeStyle=fa9_rgba(edge,.32*a);g.lineWidth=.8;g.lineCap='round';g.beginPath();for(let i=0;i<rays.length;i+=2){g.moveTo(rx,ry);g.lineTo(rx+(rays[i]-rx)*1.1,ry+(rays[i+1]-ry)*1.1)}g.stroke()}
 g.lineJoin='round';P();g.strokeStyle=fa9_rgba(edge,.16*a);g.lineWidth=12;g.stroke();P();g.strokeStyle=fa9_rgba(edge,.3*a);g.lineWidth=5;g.stroke();
 if(rx!=null&&ry!=null){g.fillStyle=fa9_rgrad(g,rx,ry,0,26,[[0,'rgba(20,8,30,.2)'],[1,'rgba(20,8,30,0)']]);g.fillRect(rx-28,ry-28,56,56)}
 g.restore();if(lw!==0){P();g.lineJoin='round';g.lineWidth=lw||2.4;g.strokeStyle=FKO;g.stroke()}}
/* embossed fine scales: dark scale edges with a lighter catch-light just inside */
function fa9_tex(g,clip,x0,x1,y0,y1,s,dark,light,a){fkScales(g,clip,x0,x1,y0,y1,s,dark,a);g.save();g.translate(0,-1);fkScales(g,clip,x0,x1,y0,y1,s,light,a*.75);g.restore()}
/* operculum: soft shade behind the gill, a crisp gill line, a highlight on its front lip and a faint second slit */
function fa9_gill2(g,clip,x,y,r,a0,a1,c,a){a=a==null?.6:a;g.save();clip();g.clip();g.lineCap='round';
 g.beginPath();g.arc(x,y,r,a0,a1);g.arc(x,y,r+10,a1,a0,true);g.closePath();g.fillStyle=fa9_rgrad(g,x,y,r,r+10,[[0,fa9_rgba(c,.24)],[1,fa9_rgba(c,0)]]);g.fill();
 g.beginPath();g.arc(x+7,y,r+6,a0+.08,a1-.08);g.strokeStyle=fa9_rgba(c,.28*a/.6);g.lineWidth=1.2;g.stroke();
 g.beginPath();g.arc(x,y,r,a0,a1);g.strokeStyle=c;g.globalAlpha=Math.min(1,a*1.2);g.lineWidth=1.8;g.stroke();
 g.beginPath();g.arc(x-1.6,y,r,a0+.06,a1-.06);g.strokeStyle='#ffffff';g.globalAlpha=.3;g.lineWidth=1.2;g.stroke();g.restore()}
/* mouth with a soft lower lip, a lip highlight and a curled corner */
function fa9_mouth(g,x0,y0,cx,cy,x1,y1,w,lip){g.save();g.lineCap='round';
 g.beginPath();g.moveTo(x0-.5,y0+1.8);g.quadraticCurveTo(cx,cy+2.4,x1+.5,y1+1.8);g.strokeStyle=fa9_rgba(lip||'#ff8aa8',.55);g.lineWidth=3.2;g.stroke();
 g.beginPath();g.moveTo(x0,y0-1.4);g.quadraticCurveTo(cx,cy-1.6,x1+1,y1-1.4);g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=1.1;g.stroke();
 fa9_smile(g,x0,y0,cx,cy,x1,y1,w||2);
 g.beginPath();g.arc(x1+1.6,y1,2,Math.PI*.72,Math.PI*1.28);g.strokeStyle=FKO;g.lineWidth=1.2;g.stroke();g.restore()}
/* gentle colour variation: a few soft tinted blotches inside a clip; b=[[x,y,r,colour,alpha],...] */
function fa9_mottle(g,clip,b){g.save();clip();g.clip();for(const m of b){g.fillStyle=fa9_rgrad(g,m[0],m[1],0,m[2],[[0,fa9_rgba(m[3],m[4])],[1,fa9_rgba(m[3],0)]]);g.fillRect(m[0]-m[2],m[1]-m[2],m[2]*2,m[2]*2)}g.restore()}
/* fine speckle texture (deterministic) inside a clip */
function fa9_speck(g,clip,x0,x1,y0,y1,n,col,a,r,seed){g.save();clip();g.clip();g.fillStyle=col;g.globalAlpha=a;g.beginPath();let s=seed||7;
 for(let i=0;i<n;i++){s=(s*9301+49297)%233280;const u=s/233280;s=(s*9301+49297)%233280;const v=s/233280;const x=x0+(x1-x0)*u,y=y0+(y1-y0)*v,rr=r*(.6+.8*((i*37)%10)/10);g.moveTo(x+rr,y);g.arc(x,y,rr,0,TAU)}g.fill();g.restore()}
/* frost rime: a dotted white crust just inside an outline */
/* ---- grotto helpers (fa9_) ---- */
/* dense polyline through control points (Catmull-Rom), resampled to m points evenly spaced by arc length */
function fa9_spline(cp,m){const d=[],n=cp.length/2,P=i=>{i=Math.max(0,Math.min(n-1,i));return [cp[i*2],cp[i*2+1]]};
 for(let i=0;i<n-1;i++){const p0=P(i-1),p1=P(i),p2=P(i+1),p3=P(i+2);for(let k=0;k<16;k++){const u=k/16,u2=u*u,u3=u2*u;
  d.push([.5*(2*p1[0]+(-p0[0]+p2[0])*u+(2*p0[0]-5*p1[0]+4*p2[0]-p3[0])*u2+(-p0[0]+3*p1[0]-3*p2[0]+p3[0])*u3),.5*(2*p1[1]+(-p0[1]+p2[1])*u+(2*p0[1]-5*p1[1]+4*p2[1]-p3[1])*u2+(-p0[1]+3*p1[1]-3*p2[1]+p3[1])*u3)])}}
 d.push(P(n-1));const L=[0];for(let i=1;i<d.length;i++)L.push(L[i-1]+Math.hypot(d[i][0]-d[i-1][0],d[i][1]-d[i-1][1]));const T=L[L.length-1],out=[];let j=0;
 for(let i=0;i<m;i++){const s=T*i/(m-1);while(j<d.length-2&&L[j+1]<s)j++;const f=(s-L[j])/((L[j+1]-L[j])||1);out.push([d[j][0]+(d[j+1][0]-d[j][0])*f,d[j][1]+(d[j+1][1]-d[j][1])*f])}
 out.len=T;return out}
/* normals (-dy,dx) of a polyline */
function fa9_norms(P){const n=P.length,N=[];for(let i=0;i<n;i++){const a=P[Math.max(0,i-1)],b=P[Math.min(n-1,i+1)],dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy)||1;N.push([-dy/d,dx/d])}return N}
/* hexagonal crystal prism standing at (x,y) pointing along angle a: lit and shadow facets, a ridge, a facet band and a tip glint */
function fa9_gem(g,x,y,a,L,w,lit,mid,dark,tw){fa9_at(g,x,y,a,()=>{const h=w*.5,P=()=>fa9_poly(g,[0,-h,L*.7,-h,L,0,L*.7,h,0,h]);
 P();g.fillStyle=fa9_grad(g,0,0,L,0,[[0,dark],[.55,mid],[1,lit]]);g.fill();
 g.beginPath();g.moveTo(0,-h);g.lineTo(L*.7,-h);g.lineTo(L,0);g.lineTo(0,0);g.closePath();g.fillStyle=fa9_grad(g,0,-h,L,0,[[0,fa9_rgba(lit,.55)],[1,fa9_rgba('#ffffff',.85)]]);g.fill();
 g.beginPath();g.moveTo(0,h*.5);g.lineTo(L*.7,h*.5);g.lineTo(L,0);g.strokeStyle=fa9_rgba(dark,.55);g.lineWidth=.8;g.stroke();
 g.beginPath();g.moveTo(L*.7,-h);g.lineTo(L*.7,h);g.strokeStyle=fa9_rgba('#ffffff',.5);g.lineWidth=.9;g.stroke();
 g.beginPath();g.moveTo(L*.08,-h*.55);g.lineTo(L*.62,-h*.55);g.strokeStyle='rgba(255,255,255,.75)';g.lineWidth=Math.max(.8,w*.12);g.lineCap='round';g.stroke();
 P();g.lineJoin='round';g.lineWidth=Math.max(1.5,w*.2);g.strokeStyle=FKO;g.stroke();
 if(tw>0)fkSpark(g,L*.94,-h*.2,2+w*.42*tw,'#ffffff',tw)})}

/* soft translucent pectoral fan hinged at (x,y), sweeping back; a = tilt */
function fa9_pec2(g,x,y,a,L,c1,c2,al){fa9_at(g,x,y,a,()=>{const pp=[3,-3,-4,-8,-L*.62,-L*.5,-L,-L*.3,-L*1.02,-L*.02,-L*.78,L*.2,-L*.36,L*.2,3,3],P=()=>fkPath(g,pp);
 g.globalAlpha=al||.85;P();g.fillStyle=fa9_grad(g,0,0,-L,0,[[0,c1],[1,c2]]);g.fill();g.globalAlpha=1;
 g.save();P();g.clip();g.strokeStyle='rgba(40,20,70,.3)';g.lineWidth=1;g.lineCap='round';g.beginPath();for(const r of [[-L*.9,-L*.36],[-L*1.02,-L*.16],[-L,L*.04],[-L*.78,L*.2],[-L*.5,L*.24]]){g.moveTo(1,0);g.lineTo(r[0],r[1])}g.stroke();
 P();g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=5;g.stroke();g.beginPath();g.moveTo(1,-3);g.quadraticCurveTo(-L*.5,-L*.52,-L*.98,-L*.3);g.strokeStyle='rgba(255,255,255,.85)';g.lineWidth=1.8;g.stroke();g.restore();
 P();g.lineJoin='round';g.lineWidth=2;g.strokeStyle=FKO;g.stroke()})}


/* ---------------- 10. Puffshroom Loach (Common): a tiny chubby lavender loach with a glowing cyan mushroom growing from its head ---------------- */
/* one mushroom: stalk from (0,0) up to the cap, cap of half-width w; k = glow pulse 0..1 */
function fa9_shroomCap(g,w,h,k,gl,spots){
 const C=()=>fa9_path(g,['M',-w,1,'C',-w*1.02,-h*.75,-w*.58,-h*1.12,0,-h*1.12,'C',w*.58,-h*1.12,w*1.02,-h*.75,w,1,'Q',w*.55,h*.1,0,h*.08,'Q',-w*.55,h*.1,-w,1,'Z']);
 // gills under the rim
 const Gl=()=>{g.beginPath();g.ellipse(0,1,w*.88,h*.36,0,0,Math.PI)};Gl();g.fillStyle=fa9_grad(g,0,0,0,h*.36,[[0,'#5ac8ea'],[.5,'#b8e8ff'],[1,'#f0e4ff']]);g.fill();
 g.save();Gl();g.clip();g.strokeStyle='rgba(50,70,150,.4)';g.lineWidth=.8;g.beginPath();
 for(let i=-7;i<=7;i++){g.moveTo(i*w*.03,1);g.lineTo(i*w*.125,h*.4)}g.stroke();g.globalCompositeOperation='lighter';g.fillStyle=`rgba(120,240,255,${.2+.3*k})`;g.fillRect(-w,0,w*2,h*.4);g.restore();
 Gl();g.strokeStyle=FKO;g.lineWidth=Math.max(1.2,w*.06);g.stroke();
 C();g.fillStyle=fa9_rgrad(g,-w*.28,-h*.78,w*.05,w*1.25,[[0,'#f2ffff'],[.25,'#8ff6ff'],[.6,'#2ad4f4'],[1,'#1576c8']]);g.fill();
 g.save();C();g.clip();
 // the inner light breathing
 g.globalCompositeOperation='lighter';g.fillStyle=fa9_rgrad(g,0,-h*.3,0,w*1.1,[[0,`rgba(120,255,255,${.18+.32*k+gl*.25})`],[1,'rgba(120,255,255,0)']]);g.fillRect(-w*1.2,-h*1.3,w*2.4,h*1.8);
 g.globalCompositeOperation='source-over';
 // rim shadow
 g.fillStyle=fa9_grad(g,0,-h*.25,0,h*.3,[[0,'rgba(20,60,140,0)'],[1,'rgba(20,60,140,.45)']]);g.fillRect(-w*1.2,-h*.3,w*2.4,h*.7);
 // white spots, squashed toward the rim for a dome feel
 for(const s of spots){const rx=s[2]*w*1.3,ry=rx*(.6+.4*(1-Math.abs(s[0]))),sx=s[0]*w,sy=s[1]*h;g.beginPath();g.ellipse(sx+.6,sy+1,rx,ry,s[0]*.5,0,TAU);g.fillStyle='rgba(10,70,140,.35)';g.fill();
  g.beginPath();g.ellipse(sx,sy,rx,ry,s[0]*.5,0,TAU);g.fillStyle=fa9_rgrad(g,sx-rx*.3,sy-ry*.4,0,rx*1.1,[[0,'#ffffff'],[.7,'#f0fbff'],[1,'#bfe6f6']]);g.fill()}
 // glossy streak
 g.beginPath();g.moveTo(-w*.72,-h*.45);g.quadraticCurveTo(-w*.55,-h*.95,-w*.05,-h*1.02);g.strokeStyle='rgba(255,255,255,.85)';g.lineWidth=Math.max(1.2,w*.09);g.lineCap='round';g.stroke();
 g.restore();
 C();g.lineJoin='round';g.lineWidth=Math.max(1.6,w*.11);g.strokeStyle=FKO;g.stroke()}
FISHART.shroom=(g,t,o)=>{const sw=fkSway(o,4.2,.15),fx=o.flex||0,fin=Math.sin(t*5)*.12,gl=o.glow||0,pu=.5+.5*Math.sin(t*1.9),k=pu*.85+.15*Math.max(0,Math.sin(t*5.3));
 g.save();g.translate(0,16);g.rotate(-sw*.12);
 const BP=[108,8,104,-12,92,-30,68,-41,32,-42,-4,-35,-33,-23,-51,-12,-59,-3,-59,5,-51,14,-33,25,-4,34,32,38,68,36,92,28,104,19],B=()=>fkPath(g,BP);
 // mushroom light cast around the head
 fkGlow(g,54,-68,48+gl*30,'#40e8ff',.14+.12*k+gl*.55);
 if(gl>0)if(g.canvas!==FKSIL)fkGlow(g,30,-4,96,'#b8f4ff',gl*.14);
 // rounded fan tail, lilac fading to a pink edge
 const T=()=>fa9_path(g,['M',8,-8,'C',-6,-12,-20,-25,-34,-24,'C',-46,-22,-51,-10,-51,0,'C',-51,10,-46,22,-34,24,'C',-20,25,-6,12,8,8,'Z']);
 fa9_at(g,-54,0,sw,()=>{g.globalAlpha=.9;T();fkFill(g,fkLin(g,6,0,-50,0,['#a468e6','#d09cff','#ff9cd8']),0);g.globalAlpha=1;
  fa9_ribs(g,T,6,0,[-36,-23,-45,-16,-50,-6,-50,6,-45,16,-36,23],.26,'#5a3a8a');
  fa9_finfx(g,T,6,0,'#ffffff',[-30,-20,-40,-12,-44,-3,-44,3,-40,12,-30,20],.85,0);
  // two soft lilac dots on the tail
  g.fillStyle='rgba(120,70,180,.32)';for(const [x,y,r] of [[-30,-9,3.4],[-34,7,3]]){g.beginPath();g.arc(x,y,r,0,TAU);g.fill()}
  T();g.lineJoin='round';g.lineWidth=2.4;g.strokeStyle=FKO;g.stroke()});
 // soft fins behind the body
 const pf=(x,y,a,pp,ribs)=>fa9_at(g,x,y,a,()=>{const P=()=>fkPath(g,pp);g.globalAlpha=.9;fkFin(g,pp,'#e8c4ff','#9a52dc',ribs,0);g.globalAlpha=1;fa9_finfx(g,P,0,0,'#ffffff',null,.85,0);P();g.lineJoin='round';g.lineWidth=2.2;g.strokeStyle=FKO;g.stroke()});
 pf(-12,-34,fin*.5,[10,4,6,-6,-4,-14,-20,-14,-30,-6,-30,4],[[2,0,-6,-12],[-6,0,-16,-13],[-14,0,-26,-6]]);
 pf(-28,26,-fin*.6,[8,-2,2,7,-10,11,-20,8,-20,-2],[[2,0,-6,9],[-6,0,-15,9]]);
 pf(32,37,-fin,[6,-3,0,7,-10,9,-12,-2],[[0,0,-8,8]]);
 // body: soft lavender back, pearly pink-lilac belly
 B();fkFill(g,fa9_grad(g,0,-32,0,31,[[0,'#5e22a4'],[.22,'#843cc8'],[.46,'#b072e8'],[.7,'#f0d4ff'],[1,'#eab8ea']]),3);
 g.save();B();g.clip();
 // plum saddle blotches across the back
 for(const [x,w] of [[38,10],[12,11],[-14,10],[-36,8],[-54,6]]){g.fillStyle=fa9_grad(g,0,-38,0,4,[[0,'rgba(52,10,104,.8)'],[.7,'rgba(70,20,130,.24)'],[1,'rgba(70,20,130,0)']]);
  g.beginPath();g.ellipse(x,-31,w,20,0,0,TAU);g.fill();g.strokeStyle='rgba(60,24,120,.22)';g.lineWidth=1.1;g.beginPath();g.ellipse(x,-31,w,20,0,Math.PI*.15,Math.PI*.85);g.stroke()}
 // cyan mushroom-light washing over the brow
 g.globalCompositeOperation='lighter';g.fillStyle=fa9_rgrad(g,60,-40,0,50,[[0,`rgba(90,230,255,${.32+.2*k+gl*.35})`],[1,'rgba(90,230,255,0)']]);g.fillRect(8,-44,104,80);g.globalCompositeOperation='source-over';
 // tiny pale freckles along the flank
 g.fillStyle='rgba(255,255,255,.55)';for(const [x,y,r] of [[54,4,1.4],[40,9,1.2],[26,4,1.5],[12,9,1.2],[-4,5,1.4],[-18,9,1.1],[-32,5,1.2],[-46,7,1]]){g.beginPath();g.arc(x,y,r,0,TAU);g.fill()}
 g.restore();
 fa9_tex(g,B,-62,98,-36,32,5.6,'#5a2a9a','#ffffff',.1);
 fkShade(g,B,-8,-38,'#3e1488',.34);
 fkShade(g,B,14,35,'#b07ad0',.3);
 fa9_rim(g,B,'#e6f8ff','#ffc8ec',1+gl*.5,1.8+gl*1);
 if(gl>0){g.save();B();g.clip();g.globalCompositeOperation='lighter';g.fillStyle=`rgba(150,240,255,${gl*.07})`;g.fillRect(-70,-50,190,100);g.restore()}
 fa9_gloss(g,B,95,-20,60,-38,-16,-32,1.7,.6);
 fa9_gill2(g,B,106,6,34,Math.PI*.74,Math.PI*1.22,'#5a3a8a',.5);
 // mycelium threads where the mushroom roots into the head
 const mx=58,my=-41;
 g.save();B();g.clip();g.strokeStyle='rgba(240,250,255,.6)';g.lineWidth=.9;g.lineCap='round';g.beginPath();
 for(const [dx,dy] of [[-14,6],[-10,10],[-4,12],[4,11],[10,9],[15,5]]){g.moveTo(mx,my);g.quadraticCurveTo(mx+dx*.4,my+dy*.9,mx+dx,my+dy)}g.stroke();
 g.globalCompositeOperation='lighter';g.fillStyle=fa9_rgrad(g,mx,my,0,12,[[0,`rgba(160,250,255,${.35+.2*k})`],[1,'rgba(160,250,255,0)']]);g.fillRect(mx-14,my-14,28,28);g.restore();
 // the mushroom: curved stalk, frilly skirt and a big puffy glowing cap; sways gently on its stalk
 const sa=Math.sin(t*1.6)*.06+sw*.35;
 fa9_at(g,mx,my+1.5,sa-.1,()=>{
  const S=()=>fa9_path(g,['M',-7,1,'C',-7,-10,-4.6,-20,-3.4,-30,'L',4.2,-30,'C',4,-21,6.6,-10,7,1,'Z']);
  S();fkFill(g,fa9_grad(g,-8,0,8,0,[[0,'#cbb8f0'],[.55,'#fbf6ff'],[1,'#e2d6fa']]),2.3);
  g.save();S();g.clip();g.strokeStyle='rgba(120,90,190,.28)';g.lineWidth=.8;g.beginPath();for(const x of [-3,0,3]){g.moveTo(x*1.6,0);g.quadraticCurveTo(x*1.2,-14,x*.8,-30)}g.stroke();
  g.globalCompositeOperation='lighter';g.fillStyle=fa9_grad(g,0,-24,0,-6,[[0,`rgba(120,240,255,${.4+.3*k})`],[1,'rgba(120,240,255,0)']]);g.fillRect(-9,-32,18,28);g.restore();
  // droopy frilled skirt
  fa9_path(g,['M',-4.4,-24,'Q',.4,-26,5,-24,'Q',8,-20.5,8.6,-17.5,'Q',7,-18.6,5.8,-17,'Q',4.2,-18.6,2.7,-17.2,'Q',.9,-18.6,-.8,-17.2,'Q',-2.4,-18.6,-4,-17.2,'Q',-5.6,-18.6,-7.8,-17.5,'Q',-7.2,-20.5,-4.4,-24,'Z']);
  fkFill(g,fa9_grad(g,0,-26,0,-17,[[0,'#ffffff'],[1,'#d6c8f6']]),1.5);
  fa9_at(g,0,-29,0,()=>fa9_shroomCap(g,31,19,k,gl,[[-.55,-.64,.12],[.1,-.9,.14],[.6,-.52,.11],[-.14,-.4,.085],[.38,-.16,.075],[-.84,-.2,.065],[.86,-.14,.055]]))});
 // a tiny baby mushroom sprouting on the back
 fa9_at(g,14,-41.5,-.22+Math.sin(t*1.6+1)*.06,()=>{
  fa9_path(g,['M',-2.6,1,'C',-2.6,-4,-2.2,-7,-1.6,-9,'L',1.8,-9,'C',2.2,-7,2.6,-4,2.6,1,'Z']);fkFill(g,'#ece2ff',1.5);
  fa9_at(g,0,-8.5,0,()=>fa9_shroomCap(g,9,7,k,gl,[[-.3,-.62,.2],[.45,-.38,.15]]))});
 // pectoral fin
 fa9_pec2(g,58,19,-.22+fin*1.3,25,'#f2dcff','#a064ec',.88);
 // sleepy half-lidded eye with lashes
 const ex=84,ey=-5,er=13.5,lid=.43+.05*Math.sin(t*.8),lidA=lid+fa9_blink(t,2.3)*.55;fa9_eye(g,ex,ey,er,'#3ac8d8',.3);fa9_lid(g,ex,ey,er,lidA,fa9_grad(g,0,ey-er,0,ey+er*.1,[[0,'#a070e8'],[.6,'#8650d6'],[1,'#6a34bc']]));
 {const ly=ey-er+2*er*Math.min(1,lidA);g.save();g.beginPath();g.arc(ex,ey,er-1.2,0,TAU);g.clip();g.beginPath();g.moveTo(ex-er,ly-2.2);g.quadraticCurveTo(ex,ly-2.2+er*.2,ex+er,ly-2.2);g.strokeStyle='rgba(255,255,255,.55)';g.lineWidth=1.3;g.lineCap='round';g.stroke();g.restore();
  g.beginPath();g.arc(ex+er*.3,ey+er*.14,er*.11,0,TAU);g.fillStyle='#ffffff';g.fill()}
 {const ly=ey-er+2*er*Math.min(1,lid)+er*.08;g.strokeStyle=FKO;g.lineWidth=1.6;g.lineCap='round';g.beginPath();g.moveTo(ex-er*.88,ly-1);g.lineTo(ex-er*1.16,ly+2);g.moveTo(ex-er*.62,ly+1);g.lineTo(ex-er*.82,ly+4.4);g.stroke()}
 fa9_blush(g,94,13,7,'#ff86c0',.62);
 // whisker barbels: three little pairs that curl and drift
 const wb=(x,y,c1x,c1y,c2x,c2y,ex2,ey2,w)=>{g.beginPath();g.moveTo(x,y);g.bezierCurveTo(c1x,c1y,c2x,c2y,ex2,ey2);g.lineCap='round';g.strokeStyle=FKO;g.lineWidth=w+2.4;g.stroke();g.strokeStyle='#f6c6ea';g.lineWidth=w;g.stroke();
  g.strokeStyle='rgba(255,255,255,.65)';g.lineWidth=w*.4;g.stroke()};
 const ww=Math.sin(t*2.4)*2.5,ww2=Math.sin(t*2.4+1.4)*2.5;
 wb(96,20,95,28,88,33+ww,82,30+ww,2.1);
 wb(101,19,103,28,100,36+ww2,93,37+ww2,2.2);
 wb(105,17,111,21,113,28+ww,109,32+ww,2.3);
 fa9_mouth(g,109,10,105,14,99,12.5,2,'#ff9ad0');
 fa9_spec(g,34,-22,.75,.9);
 // glowing spores drifting up from the cap
 g.save();g.globalCompositeOperation='lighter';for(let i=0;i<6;i++){const p=(t*.22+i/6)%1,sx=52+Math.sin(i*2.3)*16+Math.sin(p*7+i)*5,sy=-76-p*6,a=Math.sin(Math.PI*p);
  g.fillStyle=`rgba(120,250,255,${.25*a})`;g.beginPath();g.arc(sx,sy,2.6,0,TAU);g.fill();g.fillStyle=`rgba(230,255,255,${.85*a})`;g.beginPath();g.arc(sx,sy,1,0,TAU);g.fill()}g.restore();
 fkSpark(g,88,-66,2.2+fa9_tw(t,1,2.2)*2.2+gl*2,'#c8ffff',Math.min(1,.35+.55*fa9_tw(t,1,2.2)+gl*.3));
 if(gl>0){fkSpark(g,-20,-34,2+2.5*gl*fa9_tw(t,6,3),'#e0ffff',gl*.8);fkSpark(g,60,30,1.6+2*gl*fa9_tw(t,8,2.4),'#ffe8ff',gl*.7)}
 fkSpark(g,24,-62,1.8+fa9_tw(t,3,2.6)*1.6,'#e8f6ff',.3+.5*fa9_tw(t,3,2.6));
 fa9_catch(g,o,'#9af6ff',.6);g.restore()};

/* ---------------- 11. Geode Grouper (Rare): a heavy rocky grouper whose hide is cracked open on a glittering amethyst geode ---------------- */
/* deterministic jagged ring: n points around an ellipse (cx,cy,rx,ry) with chipped edges; k scales it toward the centre */
const fa9_jagR=[1,.86,1.08,.93,1.02,.84,1.1,.95,.88,1.06,.9,1.12,.97,.85,1.04,.92,1.09,.87,1.01,.94,1.07,.89];
function fa9_jag(cx,cy,rx,ry,k,sh){const p=[],n=fa9_jagR.length;for(let i=0;i<n;i++){const a=i/n*TAU+(sh||0),r=1+(fa9_jagR[i]-1)*(.6+.4*k);p.push(cx+Math.cos(a)*rx*r*k,cy+Math.sin(a)*ry*r*k)}return p}
/* jagged crack polyline with a dark core, a pale broken edge and a faint violet glow */
function fa9_crack(g,pts,w,glow){g.save();g.lineCap='round';g.lineJoin='round';const L=()=>{g.beginPath();g.moveTo(pts[0],pts[1]);for(let i=2;i<pts.length;i+=2)g.lineTo(pts[i],pts[i+1])};
 if(glow>0){g.globalCompositeOperation='lighter';L();g.strokeStyle=`rgba(190,90,255,${.22*glow})`;g.lineWidth=w*3.6;g.stroke();g.globalCompositeOperation='source-over'}
 g.translate(.7,.9);L();g.strokeStyle='rgba(230,226,240,.45)';g.lineWidth=w*.8;g.stroke();g.translate(-.7,-.9);
 L();g.strokeStyle='#1e1630';g.lineWidth=w;g.stroke();
 if(glow>0){L();g.strokeStyle=`rgba(220,150,255,${.55*glow})`;g.lineWidth=w*.35;g.stroke()}g.restore()}
FISHART.geode=(g,t,o)=>{const sw=fkSway(o,2.6,.11),fx=o.flex||0,fin=Math.sin(t*3.2)*.09,gl=o.glow||0,pu=.5+.5*Math.sin(t*1.5);g.save();g.translate(0,3);g.rotate(-sw*.16);
 const BP=[104,-6,99,-21,86,-36,62,-46,26,-49,-8,-45,-36,-35,-55,-21,-62,-8,-62,6,-55,19,-36,31,-6,41,30,46,62,43,84,34,100,22,106,6],B=()=>fkPath(g,BP);
 const GC=[-10,5],G0=fa9_jag(GC[0],GC[1],41,25,1,.1),Gp=k=>()=>fkPath(g,fa9_jag(GC[0],GC[1],41,25,k,.1));
 if(g.canvas!==FKSIL)fkGlow(g,GC[0],GC[1],78+gl*30,'#b45aff',.13+.09*pu+gl*.62);
 if(gl>0)if(g.canvas!==FKSIL)fkGlow(g,20,-4,112,'#e4c4ff',gl*.34);
 const stoneFin=(P,rx,ry,c1,c2,rays)=>{g.save();P();g.fillStyle=fa9_grad(g,rx,ry,rx+(rays?rays[0]-rx:0),ry+(rays?rays[1]-ry:-30),[[0,c1],[1,c2]]);g.fill();
  fa9_speck(g,P,rx-60,rx+60,ry-50,ry+50,70,'#16101e',.32,.9,11);fa9_speck(g,P,rx-60,rx+60,ry-50,ry+50,50,'#e8e0f0',.3,.7,23);
  if(rays){g.strokeStyle='rgba(20,14,30,.45)';g.lineWidth=1.3;g.lineCap='round';P();g.clip();g.beginPath();for(let i=0;i<rays.length;i+=2){g.moveTo(rx,ry);g.lineTo(rays[i],rays[i+1])}g.stroke()}
  g.restore();fa9_finfx(g,P,rx,ry,'#d8c8ff',null,.7,0);P();g.lineJoin='round';g.lineWidth=2.5;g.strokeStyle=FKO;g.stroke()};
 // rounded rocky tail with a pale chipped edge
 const T=()=>fa9_path(g,['M',8,-13,'C',-8,-20,-24,-32,-38,-31,'C',-49,-28,-54,-13,-53,0,'C',-54,13,-49,28,-38,31,'C',-24,32,-8,20,8,13,'Z']);
 fa9_at(g,-58,0,sw,()=>{stoneFin(T,6,0,'#5c5674','#8e86a6',[-38,-30,-47,-20,-52,-8,-52,8,-47,20,-38,30,-26,30,-26,-30]);
  g.save();T();g.clip();g.fillStyle='rgba(160,90,230,.22)';g.beginPath();g.ellipse(-44,0,9,26,0,0,TAU);g.fill();g.restore();
  fa9_crack(g,[-20,-6,-28,-3,-33,-9,-41,-7],1.3,.6+.4*pu)});
 // spiny dorsal: eight rock-hard spines, then a soft rounded rear lobe
 const D=()=>fa9_path(g,['M',60,-38,'L',56,-56,'L',48,-46,'L',41,-63,'L',33,-49,'L',25,-66,'L',17,-51,'L',9,-66,'L',1,-51,'L',-7,-64,'L',-14,-50,'L',-21,-60,'L',-27,-48,'Q',-40,-58,-50,-46,'Q',-56,-36,-50,-26,'L',-30,-32,'Z']);
 fa9_at(g,0,0,fin*.15,()=>{stoneFin(D,4,-40,'#4c4664','#8a82a2',null);
  g.save();D();g.clip();g.strokeStyle='rgba(20,14,30,.5)';g.lineWidth=1.6;g.lineCap='round';g.beginPath();for(const [x,y] of [[56,-56],[41,-63],[25,-66],[9,-66],[-7,-64],[-21,-60]]){g.moveTo(x+2,-40);g.lineTo(x,y)}g.stroke();
  g.strokeStyle='rgba(240,230,255,.5)';g.lineWidth=.9;g.beginPath();for(const [x,y] of [[56,-56],[41,-63],[25,-66],[9,-66],[-7,-64],[-21,-60]]){g.moveTo(x+.8,-40);g.lineTo(x-1,y+2)}g.stroke();g.restore();
  // faceted amethyst crystals capping the spine tips, glinting one after another
  [[56,-56,-1.9,9,5],[41,-63,-1.72,10.5,5.6],[25,-66,-1.62,11,6],[9,-66,-1.5,10.5,5.6],[-7,-64,-1.4,9.5,5.2],[-21,-60,-1.3,8.5,4.8]].forEach((c,i)=>{const tw=Math.max(0,Math.sin(t*1.5-i*1.05))**4;
   fa9_gem(g,c[0]+Math.cos(c[2])*1.5,c[1]+Math.sin(c[2])*1.5,c[2],c[3],c[4],'#fbf0ff','#d2a0ff','#8a48dc',Math.min(1,tw+gl*.4*fa9_tw(t,i,4)))})});
 // anal and pelvic fins behind the body
 const A=()=>fa9_path(g,['M',-10,34,'Q',-20,52,-36,52,'Q',-46,46,-44,30,'Z']);stoneFin(A,-22,34,'#5a5472','#8c84a4',[-30,52,-40,48,-44,36]);
 const PV=()=>fa9_path(g,['M',38,40,'Q',32,58,18,60,'Q',12,52,16,40,'Z']);fa9_at(g,0,0,-fin*.4,()=>stoneFin(PV,30,40,'#5a5472','#8c84a4',[22,58,16,50]));
 // body: slate-violet granite, lighter stony belly
 B();fkFill(g,fa9_grad(g,0,-48,0,45,[[0,'#3a3660'],[.25,'#585682'],[.55,'#817ea8'],[.8,'#a8a4c8'],[1,'#9890b8']]),3.2);
 // stony mottling, lichen and granite grain
 fa9_mottle(g,B,[[70,-28,26,'#2a2440',.55],[30,-36,22,'#2a2440',.45],[-30,-28,24,'#2a2440',.5],[60,20,20,'#c8c0d8',.35],[-40,22,22,'#c8c0d8',.3],[88,-10,14,'#6a8a8a',.4],[-48,-12,12,'#6a8a8a',.4],[44,-18,10,'#b89a6a',.3],[-20,-38,12,'#7a9a7a',.35]]);
 fa9_speck(g,B,-64,112,-48,46,240,'#140e1e',.35,.95,5);fa9_speck(g,B,-64,112,-48,46,150,'#f2ecff',.32,.75,17);
 fa9_speck(g,B,-64,112,-48,46,40,'#a8e0d0',.35,1.2,29);
 // faceted rock planes: faint broad strokes
 g.save();B();g.clip();g.lineCap='round';
 for(const [x0,y0,x1,y1] of [[86,-26,62,-8],[66,-40,48,-22],[-46,-26,-30,-14],[-56,10,-40,22],[70,26,52,36]]){g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.strokeStyle='rgba(20,14,34,.28)';g.lineWidth=1.2;g.stroke();g.beginPath();g.moveTo(x0+.8,y0+1);g.lineTo(x1+.8,y1+1);g.strokeStyle='rgba(235,228,250,.25)';g.stroke()}
 g.restore();
 // stony nodules: tiny bumps lit from the upper left
 g.save();B();g.clip();for(const [x,y,r] of [[84,-26,2.4],[70,-34,2],[54,-38,2.6],[40,-42,1.8],[14,-40,2.2],[-12,-38,2],[-30,-30,2.4],[-46,-20,1.8],[-54,-4,2],[-48,14,2.2],[-30,30,2.4],[-6,36,2],[18,38,2.6],[44,36,2.2],[64,30,2],[54,-26,1.6],[92,-12,1.8],[66,14,2],[48,22,1.6],[-50,4,1.6]]){
  g.fillStyle='rgba(16,10,28,.45)';g.beginPath();g.arc(x+.7,y+.9,r,0,TAU);g.fill();g.fillStyle='rgba(210,204,226,.85)';g.beginPath();g.arc(x,y,r,0,TAU);g.fill();g.fillStyle='rgba(255,255,255,.75)';g.beginPath();g.arc(x-r*.35,y-r*.4,r*.4,0,TAU);g.fill()}g.restore();
 fkShade(g,B,-10,-48,'#1e1834',.45);
 fkShade(g,B,18,45,'#4a3a6a',.3);
 // crusty lichen patches (sage and ochre) and violet light spilling onto the stone around the window
 g.save();B();g.clip();
 for(const [cx,cy,sc,c1,c2] of [[72,-31,1,'#8cc4a4','#4e7a64'],[-44,-22,.9,'#d8b464','#8a6a2e'],[46,32,.8,'#8cc4a4','#4e7a64'],[-50,18,.6,'#d8b464','#8a6a2e'],[14,-42,.6,'#8cc4a4','#4e7a64']]){
  for(let i=0;i<7;i++){const a=i*2.4,r=i?5.5*sc*(.5+.5*((i*3)%4)/3):0,x=cx+Math.cos(a)*r,y=cy+Math.sin(a)*r*.7,rr=(i?2.6:3.6)*sc;
   g.beginPath();g.arc(x,y,rr,0,TAU);g.fillStyle=c2;g.globalAlpha=.75;g.fill();g.beginPath();g.arc(x-.4,y-.5,rr*.72,0,TAU);g.fillStyle=c1;g.globalAlpha=.85;g.fill();
   g.beginPath();g.arc(x-.8,y-.9,rr*.28,0,TAU);g.fillStyle='#ffffff';g.globalAlpha=.4;g.fill()}}
 g.globalAlpha=1;g.globalCompositeOperation='lighter';g.fillStyle=fa9_rgrad(g,GC[0],GC[1],20,62,[[0,`rgba(170,80,255,${.22+.12*pu+gl*.3})`],[1,'rgba(170,80,255,0)']]);g.fillRect(GC[0]-64,GC[1]-64,128,128);
 g.fillStyle=fa9_rgrad(g,GC[0],GC[1],30,120,[[0,`rgba(150,70,255,${.16+.05*pu+gl*.4})`],[1,'rgba(150,70,255,0)']]);g.fillRect(-70,-60,190,120);g.restore();
 // cracks splitting outward from the geode, glowing faintly violet inside
 g.save();B();g.clip();const cg=.55+.45*pu+gl*.9;
 fa9_crack(g,[36,-8,46,-14,52,-11,60,-20,66,-18,72,-27],1.6,cg);
 fa9_crack(g,[52,-11,57,-4,64,-3],1.1,cg);
 fa9_crack(g,[30,-22,34,-32,30,-38,36,-46],1.4,cg);
 fa9_crack(g,[-40,-6,-46,-12,-52,-9,-58,-14],1.4,cg);
 fa9_crack(g,[-30,22,-36,30,-32,36,-38,42],1.3,cg);
 fa9_crack(g,[20,26,28,34,26,40],1.2,cg);
 g.restore();
 // ---- the geode window ----
 g.save();B();g.clip();
 // fresh-broken stone lip (pale, chipped), seen as a raised rim around the hole
 g.save();g.translate(1.5,2.5);fkPath(g,fa9_jag(GC[0],GC[1],41,25,1.1,.1));g.fillStyle='rgba(10,6,20,.45)';g.fill();g.restore();
 fkPath(g,fa9_jag(GC[0],GC[1],41,25,1.1,.1));g.fillStyle=fa9_grad(g,0,GC[1]-28,0,GC[1]+28,[[0,'#e2dcec'],[.5,'#b8b0c8'],[1,'#8a82a0']]);g.fill();g.lineWidth=2.4;g.strokeStyle=FKO;g.stroke();
 fa9_speck(g,()=>fkPath(g,fa9_jag(GC[0],GC[1],41,25,1.1,.1)),-50,40,-26,34,60,'#4a425e',.45,.7,41);
 // agate bands: chalcedony white, lilac and ice blue rings
 const bands=[[1,'#f6f0ff'],[.93,'#c6a8f0'],[.88,'#eae0ff'],[.83,'#9ab8f0'],[.79,'#7a4ac8']];
 for(const [k,c] of bands){Gp(k)();g.fillStyle=c;g.fill()}
 for(const k of [1,.88]){Gp(k)();g.strokeStyle='rgba(40,20,70,.5)';g.lineWidth=1;g.stroke()}
 // deep violet glowing cavity
 Gp(.79)();g.fillStyle=fa9_rgrad(g,GC[0],GC[1],0,36,[[0,'#f08cff'],[.3,'#9a3ae8'],[.65,'#4a1690'],[1,'#22084a']]);g.fill();
 g.save();Gp(.79)();g.clip();
 g.save();g.globalCompositeOperation='lighter';g.fillStyle=fa9_rgrad(g,GC[0],GC[1],0,30,[[0,`rgba(255,150,255,${.18+.18*pu+gl*.6})`],[1,'rgba(200,90,255,0)']]);g.fillRect(GC[0]-40,GC[1]-30,80,60);g.restore();
 // druse: two rings of crystal points aimed at the heart, lit facet up-left
 const ring=(k,n,len,sh,cols,tw0)=>{for(let i=0;i<n;i++){const a=i/n*TAU+sh,ca=Math.cos(a),sa=Math.sin(a);
   const bx=GC[0]+ca*41*k,by=GC[1]+sa*25*k,ang=Math.atan2(GC[1]-by,GC[0]-bx)+Math.sin(i*3.1)*.25,L=len*(.8+.4*((i*7)%5)/5),w=L*1.05;
   fa9_at(g,bx,by,ang,()=>{
    g.beginPath();g.moveTo(-1,-w*.5);g.lineTo(L*.32,-w*.42);g.lineTo(L,0);g.lineTo(L*.32,w*.42);g.lineTo(-1,w*.5);g.closePath();g.fillStyle=cols[1];g.fill();
    // lit face on the moon side, shadow face opposite
    const up=Math.sin(ang)>0;g.beginPath();g.moveTo(-1,0);g.lineTo(L*.32,up?-w*.42:w*.42);g.lineTo(L,0);g.closePath();g.fillStyle=cols[0];g.fill();
    g.beginPath();g.moveTo(-1,0);g.lineTo(L*.32,up?w*.42:-w*.42);g.lineTo(L,0);g.closePath();g.fillStyle=cols[2];g.fill();
    g.beginPath();g.moveTo(-1,-w*.5);g.lineTo(L*.32,-w*.42);g.lineTo(L,0);g.lineTo(L*.32,w*.42);g.lineTo(-1,w*.5);g.strokeStyle='rgba(28,6,56,.8)';g.lineWidth=.95;g.lineJoin='round';g.stroke();
    g.beginPath();g.moveTo(L*.36,0);g.lineTo(L*.94,0);g.strokeStyle='rgba(255,236,255,.75)';g.lineWidth=.8;g.stroke()});
   const tw=Math.max(0,Math.sin(t*1.7+i*2.37+tw0))**10;if(tw>.05)fkSpark(g,bx+Math.cos(ang)*L*.9,by+Math.sin(ang)*L*.9,2+4.4*tw,'#ffffff',tw)}};
 // deepest crystals first, then the rows nearer the viewer
 ring(.3,5,10,.4,['#b878f0','#6a28b8','#36107a'],3.9);
 ring(.52,9,12,.9,['#c88cff','#7e36d0','#42148e'],2.6);
 ring(.76,13,13,.15,['#dcaaff','#9446e4','#4e1aa0'],1.1);
 // the glowing heart
 g.save();g.globalCompositeOperation='lighter';g.fillStyle=fa9_rgrad(g,GC[0],GC[1],0,12,[[0,`rgba(255,220,255,${.4+.25*pu+gl*.6})`],[1,'rgba(255,140,255,0)']]);g.fillRect(GC[0]-14,GC[1]-14,28,28);g.restore();
 g.restore();
 // inner shadow at the top of the window (depth)
 g.save();Gp(1)();g.clip();g.fillStyle=fa9_grad(g,0,GC[1]-26,0,GC[1]-8,[[0,'rgba(20,6,40,.55)'],[1,'rgba(20,6,40,0)']]);g.fillRect(GC[0]-46,GC[1]-28,92,22);g.restore();
 g.restore();
 // stony rim light and gloss (matte, so softer)
 fa9_rim(g,B,gl>0?'#f0e4ff':'#d8d0f0','#c8a8ff',.55+gl*.9,1.6+gl*1.4);
 fa9_gloss(g,B,92,-26,62,-42,16,-45,1.4,.22);
 // heavy operculum plate behind the head
 fa9_gill2(g,B,104,4,40,Math.PI*.78,Math.PI*1.24,'#1e1630',.65);
 // big rocky pectoral fan
 fa9_at(g,70,18,-.14+fin*1.2,()=>{g.scale(.84,.84);const P=()=>fkPath(g,[3,-6,-8,-12,-24,-12,-34,-4,-36,8,-28,18,-14,18,-2,10,4,4]);stoneFin(P,0,2,'#6a6690','#a29cc0',[-24,-12,-34,-4,-36,8,-28,18,-14,18]);
  g.save();P();g.clip();g.globalCompositeOperation='lighter';g.fillStyle=fa9_rgrad(g,-40,-6,0,44,[[0,`rgba(170,90,255,${.34+gl*.3})`],[1,'rgba(170,90,255,0)']]);g.fillRect(-44,-20,56,44);g.restore()});
 // heavy brow ridge, eye and the jutting jaw
 g.save();B();g.clip();g.fillStyle=fa9_rgrad(g,80,-16,0,20,[[0,'rgba(20,14,34,.4)'],[1,'rgba(20,14,34,0)']]);g.beginPath();g.ellipse(80,-14,18,14,0,0,TAU);g.fill();g.restore();
 const ex=80,ey=-12,er=11;fa9_eye(g,ex,ey,er,'#b46aff',.4);fa9_lid(g,ex,ey,er,.3+fa9_blink(t,3.1)*.7,'#5c5676');
 // stony brow
 fa9_path(g,['M',66,-20,'Q',76,-31,92,-24,'Q',94,-21,91,-19,'Q',78,-25,68,-17,'Z']);fkFill(g,fa9_grad(g,0,-30,0,-17,[[0,'#9a92b2'],[1,'#544e6c']]),2);
 // jaw: a heavy jutting lower jaw (underbite) with thick lips and little teeth
 const J=()=>fkPath(g,[78,12,92,7,105,2,112,1,113.5,6,110,14,100,20,86,22,77,18]);
 g.save();J();g.fillStyle=fa9_grad(g,0,0,0,24,[[0,'#b0a8c4'],[.5,'#8e86a6'],[1,'#6a6286']]);g.fill();
 fa9_speck(g,J,74,116,0,26,40,'#16101e',.35,.8,61);fa9_speck(g,J,74,116,0,26,24,'#f2ecff',.35,.7,67);
 J();g.clip();g.fillStyle=fa9_grad(g,0,0,0,10,[[0,'rgba(255,180,210,.45)'],[1,'rgba(255,180,210,0)']]);g.fillRect(74,0,44,10);g.restore();
 J();g.lineJoin='round';g.lineWidth=2.6;g.strokeStyle=FKO;g.stroke();
 for(const [x,y,h] of [[108.5,3,6],[100,5,5.2],[91.5,8,4.2]]){g.beginPath();g.moveTo(x-2.4,y+1);g.lineTo(x-.3,y-h);g.lineTo(x+2.4,y+.4);g.closePath();g.fillStyle='#fffaf2';g.fill();g.strokeStyle=FKO;g.lineWidth=1.2;g.lineJoin='round';g.stroke()}
 g.save();g.lineCap='round';g.beginPath();g.moveTo(80,15);g.quadraticCurveTo(95,9,110,4.5);g.strokeStyle='rgba(255,255,255,.45)';g.lineWidth=1.2;g.stroke();
 g.beginPath();g.moveTo(104,19);g.quadraticCurveTo(96,22,88,22);g.strokeStyle='rgba(20,14,34,.4)';g.lineWidth=1.3;g.stroke();g.restore();
 fa9_spec(g,24,-36,.8,.55);
 // crystal dust motes rising from the geode
 g.save();g.globalCompositeOperation='lighter';for(let i=0;i<5;i++){const p=(t*.2+i/5)%1,x=GC[0]+Math.sin(i*2.1)*26+Math.sin(p*6+i)*4,y=GC[1]-6-p*58,a=Math.sin(Math.PI*p);
  g.fillStyle=`rgba(200,120,255,${.3*a})`;g.beginPath();g.arc(x,y,2.6,0,TAU);g.fill();g.fillStyle=`rgba(255,230,255,${.9*a})`;g.beginPath();g.arc(x,y,.9,0,TAU);g.fill()}g.restore();
 fkSpark(g,GC[0]+22,GC[1]-14,3+fa9_tw(t,1,2.1)*3.5,'#ffffff',.4+.6*fa9_tw(t,1,2.1));
 fkSpark(g,GC[0]-18,GC[1]+12,2+fa9_tw(t,4,2.6)*2.6,'#ffe8ff',.3+.6*fa9_tw(t,4,2.6));
 fkSpark(g,40,-60,2+fa9_tw(t,2,1.9)*2.2,'#e8c8ff',.3+.5*fa9_tw(t,2,1.9));
 if(gl>0)for(const [x,y,i] of [[GC[0]+6,GC[1]-20,6],[GC[0]-26,GC[1]-4,7],[GC[0]+30,GC[1]+10,8],[-50,-30,9],[86,-30,10]])fkSpark(g,x,y,1.5+3.2*gl*fa9_tw(t,i,3.1),'#ffffff',gl*(.4+.6*fa9_tw(t,i,3.1)));
 fa9_catch(g,o,'#e0b0ff',1.6);g.restore()};

/* ---------------- 12. Phantom Lanternshark (Rare): a small ghostly see-through shark with blinking lantern photophores ---------------- */
/* one photophore: soft halo, lit ring and a white-hot core; k = brightness 0..1 */
function fa9_lamp(g,x,y,r,k,c){g.fillStyle=fa9_rgba(c,.16*k);g.beginPath();g.arc(x,y,r*3.4,0,TAU);g.fill();g.fillStyle=fa9_rgba(c,.38*k);g.beginPath();g.arc(x,y,r*1.9,0,TAU);g.fill();
 g.fillStyle=fa9_rgba(c,.35+.65*k);g.beginPath();g.arc(x,y,r,0,TAU);g.fill();g.fillStyle=`rgba(255,255,255,${.25+.75*k})`;g.beginPath();g.arc(x,y,r*.45,0,TAU);g.fill()}
FISHART.lshark=(g,t,o)=>{const fx=o.flex||0,sw=fkSway(o,3.4,.1)*(1-.35*fx),fin=Math.sin(t*3.8)*.1,gl=o.glow||0,pu=.5+.5*Math.sin(t*1.6);g.save();g.translate(8,4);g.scale(.92,.92);g.rotate(-sw*.16);
 const BP=[109,3.2,105,-7.4,93,-18,70,-26.5,40,-33.1,10,-31.9,-20,-25.1,-44,-14.8,-62,-8,-72,-4.2,-72,4.2,-62,8,-44,13.7,-20,22.8,10,29.6,40,31.9,70,24.4,93,15.9,105,9.5],B=()=>fkPath(g,BP);
 const bw=(o.flex||0)*Math.sin(t*9)*3;
 if(g.canvas!==FKSIL)fkGlow(g,0,0,104+gl*20,'#8a8cff',.1+.06*pu+gl*.6);
 g.save();g.scale(1,.42);if(g.canvas!==FKSIL)fkGlow(g,10,10,120,'#6a7aff',.16+.08*pu+gl*.45);g.restore();
 // trailing ghost wisps (behind everything), drifting with t
 const wisp=(x0,y0,pts,w,a)=>{g.save();g.lineCap='round';let px=x0,py=y0;const N=14;for(let i=1;i<=N;i++){const u=i/N,v=1-u,x=v*v*v*x0+3*v*v*u*pts[0]+3*v*u*u*pts[2]+u*u*u*pts[4],y=v*v*v*y0+3*v*v*u*pts[1]+3*v*u*u*pts[3]+u*u*u*pts[5],f=1-u*.9;
  g.beginPath();g.moveTo(px,py);g.lineTo(x,y);g.strokeStyle=`rgba(170,176,255,${a*.22*f})`;g.lineWidth=w*2.8*f;g.stroke();g.strokeStyle=`rgba(226,232,255,${a*.7*f})`;g.lineWidth=w*f;g.stroke();px=x;py=y}g.restore()};
 // ---- heterocercal tail with wispy, smoke-like trailing tips ----
 const T=()=>fa9_path(g,['M',6,-5,'C',-8,-10,-22,-22,-34,-38,'Q',-40,-44,-44,-40,'C',-42,-30,-36,-16,-26,-4,'C',-30,2,-34,10,-30,18,'Q',-26,20,-22,16,'C',-14,10,-6,6,6,5,'Z']);
 fa9_at(g,-66,0,sw,()=>{const wv=Math.sin(t*2.2),wv2=Math.sin(t*2.2+1.3),wv3=Math.sin(t*2.2+2.4);
  // long smoky streamers rippling back from the lobe tips
  const st=(x0,y0,dx,dy,L,A,ph,w,a)=>{const d=Math.hypot(dx,dy);dx/=d;dy/=d;const nx=-dy,ny=dx,N=18;let px=x0,py=y0;g.save();g.lineCap='round';
   for(let i=1;i<=N;i++){const u=i/N,wa=Math.sin(u*5.5-t*3.6+ph)*A*u*(1+fx*.4),x=x0+dx*L*u+nx*wa,y=y0+dy*L*u+ny*wa,f=1-u*.92;
    g.beginPath();g.moveTo(px,py);g.lineTo(x,y);g.strokeStyle=`rgba(160,168,255,${a*.2*f})`;g.lineWidth=w*3.2*f;g.stroke();g.strokeStyle=`rgba(230,236,255,${a*.75*f})`;g.lineWidth=w*f;g.stroke();px=x;py=y}g.restore()};
  st(-43,-41,-.4,-.85,27,4,0,3,.9);
  st(-41,-36,-.7,-.6,17,3,1.6,2,.65);
  st(-30,17,-.6,.75,18,3,.8,2.4,.75);
  st(-27,-4,-1,.15,9,2,2.4,1.5,.45);
  if(g.canvas===FKSIL){T();g.fillStyle='#000';g.fill()}g.save();T();g.fillStyle=fa9_grad(g,6,0,-44,-30,[[0,'rgba(140,140,236,.68)'],[.6,'rgba(186,192,255,.5)'],[1,'rgba(230,236,255,.3)']]);g.fill();
  T();g.clip();g.fillStyle=fa9_grad(g,-20,0,-46,-40,[[0,'rgba(255,255,255,0)'],[1,'rgba(255,255,255,.35)']]);g.fillRect(-50,-46,40,50);
  // the spine bends up into the long upper lobe
  g.strokeStyle='rgba(225,236,255,.45)';g.lineWidth=1.4;g.lineCap='round';g.beginPath();g.moveTo(6,0);g.quadraticCurveTo(-18,-6,-38,-34);g.stroke();
  g.lineWidth=.9;g.beginPath();for(let i=1;i<9;i++){const u=i/9,x=6*(1-u)*(1-u)+2*(1-u)*u*-18+u*u*-38,y=2*(1-u)*u*-6+u*u*-34;g.moveTo(x-2,y-1.5);g.lineTo(x+2,y+1.5)}g.stroke();
  g.strokeStyle='rgba(200,210,255,.3)';g.lineWidth=.8;g.beginPath();for(const [x,y] of [[-30,-30],[-24,-20],[-18,-12],[-22,8],[-26,14]]){g.moveTo(0,0);g.lineTo(x,y)}g.stroke();g.restore();
  fa9_finfx(g,T,6,0,'#e8ecff',null,.9,0);
  T();g.lineJoin='round';g.lineWidth=2.3;g.strokeStyle='#241a48';g.stroke();
  // tail lanterns
  g.save();g.globalCompositeOperation='lighter';[[-12,-8],[-20,-16],[-28,-26],[-16,8]].forEach((p,i)=>{const k=Math.pow(Math.max(0,Math.sin(t*2.6-(-68+p[0])*.06-1)),3);fa9_lamp(g,p[0],p[1],1.3,.25+.75*k,'#7afcff')});g.restore()});
 // ghostly fins: clear membranes with a bright rim, rooted behind the body
 const gf=(x,y,a,pp,spine)=>fa9_at(g,x,y,a,()=>{const P=()=>fkPath(g,pp);
  g.save();P();g.fillStyle=fa9_grad(g,0,0,pp[2]||0,pp[3]||-20,[[0,'rgba(146,146,238,.7)'],[1,'rgba(225,232,255,.4)']]);g.fill();g.restore();
  fa9_finfx(g,P,0,0,'#eef0ff',null,.9,0);
  if(spine){g.beginPath();g.moveTo(spine[0],spine[1]);g.lineTo(spine[2],spine[3]);g.lineCap='round';g.strokeStyle='#241a48';g.lineWidth=3.4;g.stroke();g.strokeStyle='#f2f0ff';g.lineWidth=1.6;g.stroke()}
  P();g.lineJoin='round';g.lineWidth=2.2;g.strokeStyle='#241a48';g.stroke()});
 g.save();fa9_outside(g,BP);
 gf(24,-29,fin*.2,[9,2,2,-14,-9,-28,-13,-26,-15,-9,-20,2],[10,0,1,-20]);
 gf(-34,-16,fin*.25,[6,2,1,-8,-7,-17,-10,-15,-11,-5,-14,2],[6,0,1.5,-10]);
 gf(-22,22,-fin*.4,[6,-2,0,6,-10,13,-12,10,-10,0]);
 g.restore();
 // phantom echoes: two faint after-images trailing behind the body
 if(g.canvas!==FKSIL)for(const k of [2,1]){g.save();g.translate(-10*k+Math.sin(t*2+k)*2,Math.sin(t*1.4+k*1.7)*1.6);B();g.fillStyle=`rgba(150,140,255,${.08/k+gl*.05})`;g.fill();g.setLineDash([10,7]);g.lineDashOffset=-t*14*k;B();g.strokeStyle=`rgba(190,180,255,${.4/k+gl*.2})`;g.lineWidth=1.8;g.stroke();g.restore()}
 // ---- see-through body: pale ghost-blue above, deep violet below ----
 if(g.canvas===FKSIL){B();g.fillStyle='#000';g.fill()}B();g.fillStyle=fa9_grad(g,0,-26,0,25,[[0,'rgba(214,224,255,.74)'],[.32,'rgba(170,178,250,.66)'],[.52,'rgba(118,104,228,.74)'],[.7,'rgba(58,38,140,.86)'],[1,'rgba(30,18,92,.94)']]);g.fill();
 g.save();B();g.clip();
 // fresnel: brighter just inside the edges
 B();g.strokeStyle='rgba(230,236,255,.28)';g.lineWidth=12;g.stroke();B();g.strokeStyle='rgba(240,244,255,.4)';g.lineWidth=4;g.stroke();
 // drifting inner mist
 const ms=Math.sin(t*.9)*24;g.fillStyle=fa9_grad(g,-60+ms,0,90+ms,0,[[0,'rgba(200,180,255,0)'],[.5,'rgba(200,190,255,.2)'],[1,'rgba(200,180,255,0)']]);g.fillRect(-80,-30,200,60);
 // skeleton: skull and jaw cartilage, spine with vertebrae, pectoral girdle, faint ribs
 g.lineCap='round';g.lineJoin='round';g.strokeStyle='rgba(236,244,255,.55)';g.lineWidth=1.6;
 g.beginPath();g.moveTo(102,0);g.quadraticCurveTo(96,-10,80,-12);g.quadraticCurveTo(66,-13,60,-6);g.quadraticCurveTo(58,2,66,6);g.quadraticCurveTo(82,10,98,6);g.stroke();
 g.beginPath();g.moveTo(98,9);g.quadraticCurveTo(84,15,70,11);g.stroke();
 g.lineWidth=1.8;g.beginPath();g.moveTo(60,-3);g.quadraticCurveTo(0,-6+bw,-70,-1);g.stroke();
 g.strokeStyle='rgba(236,244,255,.5)';g.lineWidth=1.1;g.beginPath();for(let i=0;i<20;i++){const u=i/19,x=58-u*126,y=-3-Math.sin(Math.PI*u)*3+bw*Math.sin(Math.PI*u);g.moveTo(x,y-2.6);g.lineTo(x,y+2.6)}g.stroke();
 g.strokeStyle='rgba(220,230,255,.2)';g.lineWidth=1;g.beginPath();for(let i=0;i<9;i++){const x=50-i*11,y=-4-Math.sin(Math.PI*(i/19))*3;g.moveTo(x,y);g.quadraticCurveTo(x-4,y+9,x-8,y+15-i*.8);g.moveTo(x,y);g.quadraticCurveTo(x-3,y-8,x-7,y-14+i*.6)}g.stroke();
 g.strokeStyle='rgba(232,240,255,.38)';g.lineWidth=1.4;g.beginPath();g.moveTo(58,-6);g.quadraticCurveTo(54,6,58,17);g.stroke();
 g.restore();
 fkShade(g,B,-4,-26,'#e8ecff',.18);
 // five ghostly gill slits
 g.save();B();g.clip();g.lineCap='round';for(let i=0;i<5;i++){const x=70-i*4.6,h=8-Math.abs(i-1.5)*.8;g.beginPath();g.moveTo(x,-3-h*.5);g.quadraticCurveTo(x-2.6,2,x-.8,4+h*.6);
  g.strokeStyle='rgba(36,24,80,.55)';g.lineWidth=1.6;g.stroke();g.beginPath();g.moveTo(x+1.2,-3-h*.5);g.quadraticCurveTo(x-1.4,2,x+.4,4+h*.6);g.strokeStyle='rgba(230,236,255,.4)';g.lineWidth=.8;g.stroke()}g.restore();
 // ---- lantern photophores: belly row, flank row and a dotted lateral line, blinking in travelling waves ----
 g.save();B();g.clip();g.globalCompositeOperation='lighter';
 const row=(n,x0,x1,yf,r,ph,sp)=>{for(let i=0;i<n;i++){const u=i/(n-1),x=x0+(x1-x0)*u,y=yf(u),w=Math.pow(Math.max(0,Math.sin(t*2.6-x*.06+ph)),3),m=((i*5+Math.floor(t*2.2))%7)===0?.6:0;
  fa9_lamp(g,x,y,r*(.85+.3*w),Math.min(1,.18+.82*w+m+gl*.55),i%3===1&&sp?'#c8a0ff':'#7afcff')}};
 row(13,86,-58,u=>17+Math.sin(Math.PI*(u*.8+.1))*7-u*9,2.1,0,1);
 row(11,64,-54,u=>8+Math.sin(Math.PI*u)*5-u*5,1.6,1.4,0);
 row(16,94,-62,u=>-4-Math.sin(Math.PI*u)*2+u*1,1.05,2.6,1);
 g.restore();
 // ghost rim light: icy above, violet below
 fa9_rim(g,B,'#ffffff','#c8a8ff',1+gl,1.8+gl*1.4);
 if(gl>0){g.save();B();g.clip();g.globalCompositeOperation='lighter';g.fillStyle=`rgba(190,220,255,${gl*.1})`;g.fillRect(-80,-40,200,80);B();g.strokeStyle=`rgba(230,240,255,${gl*.45})`;g.lineWidth=5;g.stroke();g.restore()}
 fa9_gloss(g,B,96,-11,64,-24,-10,-24,1.6,.55);
 B();g.lineJoin='round';g.lineWidth=2.6;g.strokeStyle='#241a48';g.stroke();
 // pectoral and pelvic fins in front: clear blades with bright leading edges
 fa9_at(g,56,17,.15+fin*1.2,()=>{const P=()=>fkPath(g,[4,-3,-2,4,-12,14,-26,24,-30,22,-22,10,-12,0,-2,-4]);
  g.save();P();g.fillStyle=fa9_grad(g,0,0,-28,22,[[0,'rgba(150,150,240,.6)'],[1,'rgba(220,228,255,.3)']]);g.fill();P();g.clip();
  g.beginPath();g.moveTo(3,-2);g.quadraticCurveTo(-12,10,-29,23);g.strokeStyle='rgba(255,255,255,.85)';g.lineWidth=2;g.stroke();
  g.strokeStyle='rgba(225,232,255,.35)';g.lineWidth=.8;g.beginPath();for(const [x,y] of [[-24,22],[-20,16],[-16,10]]){g.moveTo(0,0);g.lineTo(x,y)}g.stroke();g.restore();
  P();g.lineJoin='round';g.lineWidth=2.1;g.strokeStyle='#241a48';g.stroke()});
 // lanterns on the fin edges
 g.save();g.globalCompositeOperation='lighter';
 fa9_at(g,56,17,.15+fin*1.2,()=>{[[-8,6],[-16,13],[-24,20]].forEach((p,i)=>fa9_lamp(g,p[0],p[1],1.2,.3+.7*Math.pow(Math.max(0,Math.sin(t*2.6-56*.06+i*.5)),3),'#7afcff'))});
 [[16,-45],[12,-38],[-40,-27]].forEach((p,i)=>fa9_lamp(g,p[0],p[1],1.1,.3+.7*Math.pow(Math.max(0,Math.sin(t*2.6-p[0]*.06+2)),3),'#c8a0ff'));
 g.restore();
 // glowing ghost eye: luminous cyan iris, dark pupil, halo
 const ex=86,ey=-5,er=10.5;fkGlow(g,ex,ey,er*3+gl*8,'#7afcff',.32+.2*pu+gl*.6);
 g.beginPath();g.arc(ex,ey,er,0,TAU);g.fillStyle=fa9_rgrad(g,ex-2,ey-3,1,er,[[0,'#ffffff'],[.6,'#e4f4ff'],[1,'#a8c0f0']]);g.fill();
 g.save();g.beginPath();g.arc(ex,ey,er,0,TAU);g.clip();
 g.beginPath();g.arc(ex+2,ey+.5,er*.68,0,TAU);g.fillStyle=fa9_rgrad(g,ex+2,ey+.5,0,er*.68,[[0,'#ffffff'],[.3,'#9cfeff'],[.75,'#2ad8f0'],[1,'#1a6ab8']]);g.fill();
 g.beginPath();g.ellipse(ex+2.6,ey+.6,er*.18,er*.42,0,0,TAU);g.fillStyle='#0c0a2a';g.fill();
 g.globalCompositeOperation='lighter';g.fillStyle=`rgba(120,255,255,${.25+.25*pu})`;g.beginPath();g.arc(ex+2,ey+.5,er*.68,0,TAU);g.fill();g.restore();
 g.beginPath();g.arc(ex,ey,er,0,TAU);g.lineWidth=2.4;g.strokeStyle='#241a48';g.stroke();
 g.beginPath();g.ellipse(ex+er*.3,ey-er*.32,er*.24,er*.18,-.5,0,TAU);g.fillStyle='#fff';g.fill();g.beginPath();g.arc(ex-er*.2,ey+er*.36,er*.1,0,TAU);g.fill();
 fa9_lid(g,ex,ey,er,fa9_blink(t,.9),'#9aa4ec');
 // little underslung shark grin with tiny teeth
 g.save();g.lineCap='round';g.beginPath();g.moveTo(101,10);g.quadraticCurveTo(93,15,84,12.5);g.strokeStyle='#241a48';g.lineWidth=2.2;g.stroke();
 g.fillStyle='#ffffff';for(const x of [97,93,89]){const y=12.6+(97-x)*.12;g.beginPath();g.moveTo(x-1.4,y);g.lineTo(x,y+2.6);g.lineTo(x+1.4,y);g.closePath();g.fill()}
 g.beginPath();g.arc(84,12,1.8,Math.PI*.5,Math.PI*1.3);g.lineWidth=1.2;g.stroke();g.restore();
 // nostril
 g.beginPath();g.ellipse(101,3,1.8,.9,-.3,0,TAU);g.fillStyle='rgba(36,24,80,.6)';g.fill();
 // drifting will-o-wisp motes
 g.save();g.globalCompositeOperation='lighter';for(let i=0;i<5;i++){const p=(t*.18+i/5)%1,x=60-p*170,y=-36+Math.sin(p*8+i*2)*8+i*12,a=Math.sin(Math.PI*p);
  fa9_lamp(g,x,y,1,a*.8,i%2?'#c8a0ff':'#7afcff')}g.restore();
 fkSpark(g,30,-40,2+fa9_tw(t,1,2.3)*2.6,'#e8f0ff',.35+.55*fa9_tw(t,1,2.3));
 if(gl>0)for(const [x,y,i] of [[-40,-10,5],[60,-14,6],[10,20,7],[-70,-36,8],[90,-20,9]])fkSpark(g,x,y,1.4+3*gl*fa9_tw(t,i,3.3),'#ffffff',gl*(.4+.6*fa9_tw(t,i,3.3)));
 fa9_catch(g,o,'#a8b8ff',1.6);g.restore()};

/* ---------------- 13. Runefin Coelacanth (Legendary): an ancient navy-armoured coelacanth with glowing runes and crystal paddle fins ---------------- */
/* rune glyphs as line segments in a unit box (-1..1) */
const fa9_RUNES=[[0,-1,0,1,0,-1,.7,-.4,0,-.2,.7,.3],[-.5,-1,-.5,1,-.5,-1,.6,-.2,-.5,.4,.6,-.2],[0,-1,0,1,-.6,-.5,.6,.5],[-.6,-1,-.6,1,.6,-1,.6,1,-.6,0,.6,0],
 [0,-1,0,1,-.6,-.4,0,0,.6,-.4,0,0],[-.6,-1,.6,0,.6,0,-.6,1,-.6,-1,-.6,1],[0,-1,-.6,0,-.6,0,0,1,0,1,.6,0,.6,0,0,-1],[-.6,-1,.6,1,.6,-1,-.6,1,0,-1,0,1]];
/* etched rune: a dark groove with a pale chisel edge, dim navy-cyan when asleep, cyan with a white-hot core and a halo when lit (k 0..1) */
function fa9_rune(g,x,y,s,id,k,rot){const R=fa9_RUNES[id%fa9_RUNES.length];g.save();g.translate(x,y);g.rotate(rot||0);g.lineCap='round';g.lineJoin='round';
 const P=()=>{g.beginPath();for(let i=0;i<R.length;i+=4){g.moveTo(R[i]*s,R[i+1]*s);g.lineTo(R[i+2]*s,R[i+3]*s)}};
 // chisel edge (light catching the lower-right lip of the groove), then the groove itself
 g.translate(.55,.75);P();g.strokeStyle='rgba(150,200,255,.3)';g.lineWidth=s*.5;g.stroke();g.translate(-.55,-.75);
 P();g.strokeStyle='rgba(3,6,26,.85)';g.lineWidth=s*.5;g.stroke();
 // sleeping ink: dim navy-cyan
 P();g.strokeStyle=`rgba(70,150,215,${.4+.2*k})`;g.lineWidth=s*.26;g.stroke();
 if(k>.03){g.globalCompositeOperation='lighter';
  g.fillStyle=fa9_rgrad(g,0,0,0,s*3.6,[[0,`rgba(90,225,255,${.5*k})`],[.45,`rgba(255,210,120,${.14*k})`],[1,'rgba(90,220,255,0)']]);g.fillRect(-s*3.7,-s*3.7,s*7.4,s*7.4);
  P();g.strokeStyle=`rgba(60,210,255,${.5*k})`;g.lineWidth=s*1.2;g.stroke();
  P();g.strokeStyle=`rgba(${150+105*k},${235+20*k},255,${.3+.7*k})`;g.lineWidth=s*.3;g.stroke();
  if(k>.5){P();g.strokeStyle=`rgba(255,255,255,${(k-.5)*2})`;g.lineWidth=s*.2;g.stroke()}}
 g.restore()}
/* lobed fin: a scaled fleshy stalk with gold joint rings ending in a gold-edged faceted crystal paddle; frame points along +x from (x,y) at angle a */
function fa9_lobe(g,x,y,a,L,W,k,t,ph){fa9_at(g,x,y,a,()=>{const S=L*.36,P=L-S,cx=S+P*.42,rx=P*.62,ry=W*1.18;
 // crystal fan: edge points around the far side of an ellipse, chipped into shards
 const V=[[S-1,-W*.4]];for(let i=0;i<=10;i++){const an=-1.95+i/10*3.9,r=i%2?1.05:.94;V.push([cx+Math.cos(an)*rx*r,Math.sin(an)*ry*r])}V.push([S-1,W*.4]);
 const PP=()=>{g.beginPath();g.moveTo(V[0][0],V[0][1]);for(const v of V)g.lineTo(v[0],v[1]);g.closePath()};const c0=[S-1,0];
 g.save();g.globalCompositeOperation='lighter';g.fillStyle=fa9_rgrad(g,cx,0,0,P*1.2,[[0,`rgba(70,210,255,${.2+.4*k})`],[1,'rgba(70,210,255,0)']]);g.fillRect(cx-P*1.25,-P*1.25,P*2.5,P*2.5);g.restore();
 PP();g.fillStyle=fa9_rgrad(g,S,0,2,P*1.05,[[0,'rgba(22,60,170,.95)'],[.5,'rgba(40,140,230,.86)'],[.85,'rgba(90,210,250,.82)'],[1,'rgba(150,236,255,.85)']]);g.fill();
 g.save();PP();g.clip();
 for(let i=1;i<V.length-2;i++){const v0=V[i],v1=V[i+1];g.beginPath();g.moveTo(c0[0],c0[1]);g.lineTo(v0[0],v0[1]);g.lineTo(v1[0],v1[1]);g.closePath();g.fillStyle=i%2?'rgba(200,245,255,.16)':'rgba(10,30,110,.2)';g.fill()}
 g.strokeStyle='rgba(190,240,255,.6)';g.lineWidth=.9;g.beginPath();for(let i=1;i<V.length-1;i+=2){g.moveTo(c0[0],c0[1]);g.lineTo(V[i][0],V[i][1])}g.stroke();
 g.globalCompositeOperation='lighter';const sx=S+((t*.45+ph)%1.5-.25)*P*1.3;g.fillStyle=fa9_grad(g,sx-7,-W,sx+7,W,[[0,'rgba(255,255,255,0)'],[.5,`rgba(220,250,255,${.4+.3*k})`],[1,'rgba(255,255,255,0)']]);g.fillRect(S-4,-W*1.3,P+8,W*2.6);
 g.fillStyle=`rgba(200,245,255,${.35*k})`;g.fillRect(S-4,-W*1.3,P+8,W*2.6);
 g.globalCompositeOperation='source-over';PP();g.strokeStyle=`rgba(255,214,120,${.75+.25*k})`;g.lineWidth=3.6;g.stroke();g.restore();
 PP();g.lineJoin='round';g.lineWidth=2.1;g.strokeStyle=FKO;g.stroke();
 // fleshy scaled lobe, thick at the root and tapering into the fan
 const St=()=>fa9_path(g,['M',-6,-W*.7,'C',S*.35,-W*.78,S*.75,-W*.6,S+3,-W*.42,'Q',S+7,0,S+3,W*.42,'C',S*.75,W*.6,S*.35,W*.78,-6,W*.7,'Z']);
 St();g.fillStyle=fa9_grad(g,0,-W*.7,0,W*.7,[[0,'#4068c0'],[.45,'#1e3282'],[1,'#101a50']]);g.fill();
 g.save();St();g.clip();for(let i=0;i<3;i++)for(const yy of [-1,1]){const xx=S*(.12+i*.3)+(yy>0?S*.14:0),y0=yy*W*.26;g.beginPath();g.ellipse(xx,y0,W*.36,W*.3,0,Math.PI*.55,Math.PI*1.45);g.strokeStyle='rgba(4,6,24,.7)';g.lineWidth=1.2;g.stroke();
  g.beginPath();g.ellipse(xx+1,y0,W*.3,W*.24,0,Math.PI*.6,Math.PI*1.35);g.strokeStyle='rgba(255,205,110,.42)';g.lineWidth=.8;g.stroke()}
 g.fillStyle=fa9_grad(g,0,-W*.7,0,W*.7,[[0,'rgba(180,210,255,.25)'],[.4,'rgba(180,210,255,0)']]);g.fillRect(-8,-W,S+12,W*2);
 // gold joint rings around the stalk
 for(const f of [.3,.74]){const xx=S*f,hw=W*(.7-.28*f)+1;g.beginPath();g.ellipse(xx,0,1.7,hw,0,0,TAU);g.strokeStyle='rgba(4,6,24,.8)';g.lineWidth=2.6;g.stroke();g.strokeStyle='#f0c25a';g.lineWidth=1.2;g.stroke();
  g.beginPath();g.ellipse(xx-.5,0,1.2,hw*.6,0,Math.PI*1.1,Math.PI*1.9);g.strokeStyle='rgba(255,240,190,.7)';g.lineWidth=.8;g.stroke()}
 g.restore();
 St();g.lineJoin='round';g.lineWidth=2.4;g.strokeStyle=FKO;g.stroke();
 fa9_rune(g,S*.52,0,W*.2,Math.round(ph*3),k,0);
 if(k>.5)fkSpark(g,cx+rx*.7,-ry*.5,1.5+5*(k-.5),'#ffffff',Math.min(1,(k-.5)*2.4))})}
/* gilded bony head plate: a lighter plate with a dark seam, a gold edge and rivets at its corners; pts feed fkPath */
function fa9_plate(g,pts,rivets){const P=()=>fkPath(g,pts);P();g.fillStyle='rgba(70,110,210,.22)';g.fill();
 g.save();P();g.clip();P();g.strokeStyle='rgba(150,190,255,.35)';g.lineWidth=5;g.stroke();g.restore();
 P();g.lineJoin='round';g.strokeStyle='rgba(4,6,24,.75)';g.lineWidth=2.8;g.stroke();P();g.strokeStyle='#e8b84e';g.lineWidth=1.25;g.stroke();
 g.save();P();g.clip();P();g.strokeStyle='rgba(255,240,190,.45)';g.lineWidth=.8;g.translate(.6,.8);g.stroke();g.restore();
 for(let i=0;i<rivets.length;i+=2){g.beginPath();g.arc(rivets[i],rivets[i+1],1.5,0,TAU);g.fillStyle='#ffe08a';g.fill();g.strokeStyle='rgba(4,6,24,.85)';g.lineWidth=.9;g.stroke();g.beginPath();g.arc(rivets[i]-.4,rivets[i+1]-.5,.5,0,TAU);g.fillStyle='#ffffff';g.fill()}}
FISHART.coelacanth=(g,t,o)=>{const sw=fkSway(o,2.2,.1),fx=o.flex||0,gl=o.glow||0,pu=.5+.5*Math.sin(t*1.4);g.save();g.translate(2,0);g.scale(.96,.96);g.rotate(-sw*.14);
 const BP=[108,2,105,-14,94,-31,72,-42,40,-45,8,-42,-20,-35,-42,-25,-53,-17,-57,-8,-57,8,-53,17,-42,25,-20,34,8,40,40,43,72,39,94,29,105,15],B=()=>fkPath(g,BP);
 // the rune sequence: one hot pulse travels head (index 0) to tail (index ~10) with fading neighbours, then restarts
 const SP=11,sa=((t*1.7+3)%SP)-1.5,rk=i=>Math.min(1,Math.pow(Math.max(0,1-Math.abs(i-sa)/1.9),1.6)+gl*.75);
 const wk=(ph)=>Math.sin(t*1.8+ph)*.16*(1+fx*1.5);
 if(g.canvas!==FKSIL)fkGlow(g,8,0,118+gl*10,'#3a8cff',.13+.07*pu+gl*.7);
 if(g.canvas!==FKSIL)fkGlow(g,8,0,70+gl*40,'#ffd070',.06+.05*pu+gl*.6);
 // ---- three-lobed tail: two broad fans with a clear notch between them, a scaled stalk running through to a crystal tassel lobe ----
 fa9_at(g,-50,0,sw,()=>{
  const lobe=(sg)=>()=>fa9_path(g,['M',6,-12*sg,'C',-2,-28*sg,-10,-44*sg,-22,-50*sg,'C',-32,-54*sg,-42,-46*sg,-44,-34*sg,'C',-46,-24*sg,-42,-14*sg,-37,-8*sg,'L',6,-10*sg,'Z']);
  for(const sg of [1,-1]){const P=lobe(sg);P();g.fillStyle=fa9_grad(g,6,-8*sg,-30,-48*sg,[[0,'#121e5a'],[.5,'#2848a8'],[1,sg>0?'#5aa8ff':'#4a8cf0']]);g.fill();
   g.save();P();g.clip();g.lineCap='round';
   // gold ribs
   for(let i=0;i<7;i++){const an=(-1.5-i*.21)*sg,fx0=8,fy0=-6*sg;g.beginPath();g.moveTo(fx0+Math.cos(an)*8,fy0+Math.sin(an)*8);g.quadraticCurveTo(fx0+Math.cos(an+.1*sg)*30,fy0+Math.sin(an+.1*sg)*30,fx0+Math.cos(an)*62,fy0+Math.sin(an)*62);
    g.strokeStyle='rgba(4,8,30,.55)';g.lineWidth=2.6;g.stroke();g.strokeStyle='rgba(255,214,120,.6)';g.lineWidth=1.1;g.stroke()}
   // rune veins: luminous cyan channels between the ribs, forking near the edge, lit at the end of the sequence
   g.globalCompositeOperation='lighter';for(let i=0;i<3;i++){const an=(-1.6-i*.42)*sg,k=rk(8.4+i*.5),fx0=8,fy0=-6*sg,ex2=fx0+Math.cos(an)*44,ey2=fy0+Math.sin(an)*44;
    g.beginPath();g.moveTo(fx0+Math.cos(an)*10,fy0+Math.sin(an)*10);g.quadraticCurveTo(fx0+Math.cos(an+.05*sg)*26,fy0+Math.sin(an+.05*sg)*26,ex2,ey2);
    g.moveTo(ex2,ey2);g.lineTo(ex2+Math.cos(an+.3*sg)*9,ey2+Math.sin(an+.3*sg)*9);g.moveTo(ex2,ey2);g.lineTo(ex2+Math.cos(an-.25*sg)*8,ey2+Math.sin(an-.25*sg)*8);
    g.strokeStyle=`rgba(80,220,255,${.12+.35*k})`;g.lineWidth=3.2;g.stroke();g.strokeStyle=`rgba(${190+65*k},${245+10*k},255,${.3+.6*k})`;g.lineWidth=1;g.stroke()}
   g.fillStyle=fa9_grad(g,-6,-14*sg,-26,-50*sg,[[0,'rgba(90,220,255,0)'],[1,`rgba(90,220,255,${.22+.3*rk(9)+gl*.3})`]]);g.fillRect(-48,-56,60,112);
   g.globalCompositeOperation='source-over';
   fa9_rune(g,-16,-28*sg,3.2,5,rk(8.6),-.35*sg);fa9_rune(g,-30,-38*sg,2.7,6,rk(9.3),-.5*sg);
   g.restore();
   fa9_finfx(g,P,4,-9*sg,'#a8e0ff',null,.85,0);P();g.lineJoin='round';g.lineWidth=2.4;g.strokeStyle=FKO;g.stroke()}
  // the crystal tassel lobe, a distinct small paddle on its own stalk between the two fans
  fa9_lobe(g,-38,0,Math.PI+wk(2)*.35,28,8,rk(9.8),t,2.2);
  // scaled tail stalk over the lobe roots
  const TS=()=>fa9_path(g,['M',12,-17,'C',-6,-14,-24,-9,-40,-7,'Q',-44,0,-40,7,'C',-24,9,-6,14,12,17,'Z']);
  TS();g.fillStyle=fa9_grad(g,0,-16,0,16,[[0,'#0c1646'],[.5,'#1c2e7a'],[1,'#22337a']]);g.fill();
  g.save();TS();g.clip();for(let x=-38;x<12;x+=7)for(const yy of [-5,3]){const y=yy+(Math.round(x)%2?1:0);g.beginPath();g.ellipse(x,y,4.6,4,0,Math.PI*.55,Math.PI*1.45);g.strokeStyle='rgba(4,6,24,.75)';g.lineWidth=1.2;g.stroke();
   g.beginPath();g.ellipse(x+1,y,3.8,3.2,0,Math.PI*.6,Math.PI*1.35);g.strokeStyle='rgba(255,205,110,.4)';g.lineWidth=.8;g.stroke()}
  g.beginPath();g.moveTo(12,0);g.lineTo(-40,0);g.strokeStyle='rgba(4,6,24,.6)';g.lineWidth=3;g.stroke();g.strokeStyle='#d8a848';g.lineWidth=1.3;g.stroke();
  g.globalCompositeOperation='lighter';for(let i=0;i<4;i++){const x=4-i*11,k=rk(7.6+i*.5);g.fillStyle=`rgba(255,220,130,${.2+.6*k})`;g.beginPath();g.arc(x,0,1.4+k,0,TAU);g.fill()}
  g.restore();
  TS();g.lineJoin='round';g.lineWidth=2.6;g.strokeStyle=FKO;g.stroke()});
 // ---- first dorsal: a tall gilded spiny ray-fan rooted into the back ----
 const TIPS=[[40,-56],[34,-67],[24,-75],[12,-77],[0,-73],[-10,-65],[-17,-55]],ROOT=[12,-40];
 const D1=()=>{g.beginPath();g.moveTo(38,-36);g.lineTo(TIPS[0][0],TIPS[0][1]);for(let i=1;i<TIPS.length;i++){const a=TIPS[i-1],b=TIPS[i],mx=(a[0]+b[0])/2,my=(a[1]+b[1])/2;g.quadraticCurveTo(mx+(ROOT[0]-mx)*.22,my+(ROOT[1]-my)*.22,b[0],b[1])}g.lineTo(-18,-33);g.quadraticCurveTo(10,-42,38,-36);g.closePath()};
 fa9_at(g,14,-42,wk(1)*.25,()=>{g.translate(-14,42);const dk=rk(1.2);
  D1();g.fillStyle=fa9_grad(g,0,-36,0,-80,[[0,'#15256e'],[.45,'#2b5cc4'],[1,'#7ad0ff']]);g.fill();
  g.save();D1();g.clip();g.globalCompositeOperation='lighter';g.fillStyle=fa9_grad(g,0,-50,0,-80,[[0,'rgba(90,220,255,0)'],[1,`rgba(120,230,255,${.25+.35*dk+gl*.4})`]]);g.fillRect(-30,-90,80,60);g.globalCompositeOperation='source-over';
  // gilded spines fanning from the root
  g.lineCap='round';for(const [x,y] of TIPS){g.beginPath();g.moveTo(ROOT[0],ROOT[1]);g.quadraticCurveTo((ROOT[0]+x)/2+(x-ROOT[0])*.08,(ROOT[1]+y)/2,x,y);g.strokeStyle='rgba(4,6,24,.75)';g.lineWidth=3.2;g.stroke();g.strokeStyle='#f0c25a';g.lineWidth=1.5;g.stroke();g.strokeStyle='rgba(255,240,190,.5)';g.lineWidth=.6;g.stroke()}
  // membrane rays between the spines
  g.strokeStyle='rgba(200,240,255,.28)';g.lineWidth=.8;g.beginPath();for(let i=1;i<TIPS.length;i++){const a=TIPS[i-1],b=TIPS[i];for(const f of [.35,.65]){g.moveTo(ROOT[0],ROOT[1]);g.lineTo(a[0]+(b[0]-a[0])*f,a[1]+(b[1]-a[1])*f)}}g.stroke();
  g.restore();
  fa9_finfx(g,D1,ROOT[0],ROOT[1],'#a8dcff',null,.7,0);
  D1();g.lineJoin='round';g.lineWidth=2.3;g.strokeStyle=FKO;g.stroke();
  // gold rim along the scalloped top edge
  g.save();D1();g.clip();D1();g.strokeStyle='rgba(240,194,90,.85)';g.lineWidth=2.6;g.stroke();g.restore();
  for(const [x,y] of TIPS){g.beginPath();g.arc(x,y,1.9,0,TAU);g.fillStyle='#ffe08a';g.fill();g.strokeStyle=FKO;g.lineWidth=1;g.stroke();g.beginPath();g.arc(x-.5,y-.6,.6,0,TAU);g.fillStyle='#ffffff';g.fill()}
  if(dk>.4)fkSpark(g,TIPS[3][0],TIPS[3][1]-2,2+5*(dk-.4),'#ffffff',Math.min(1,(dk-.4)*1.8))});
 // ---- lobed fins behind the body: second dorsal, anal ----
 fa9_lobe(g,-20,-34,-2.42+wk(0),40,10,rk(5.6),t,0);
 fa9_lobe(g,-20,34,2.42-wk(1.2),40,10,rk(5.9),t,1.1);
 // ---- body: deep navy armour, ink-blue back ----
 B();fkFill(g,fa9_grad(g,0,-44,0,44,[[0,'#08103a'],[.3,'#14215e'],[.62,'#1e3280'],[.9,'#2a3e8e'],[1,'#22337a']]),3.2);
 // armour scales: overlapping cosmoid plates, each free edge facing the tail, laid tail-to-head
 g.save();B();g.clip();
 g.beginPath();g.rect(-80,-60,152,120);g.clip();
 const s=12.5;for(let x=-70;x<=70;x+=s*.78){for(let r=-4;r<=4;r++){const y=r*s*.8+((Math.round((x+70)/(s*.78)))%2?s*.4:0);
   g.beginPath();g.ellipse(x,y,s*.62,s*.52,0,0,TAU);g.fillStyle=fa9_grad(g,x-s*.62,0,x+s*.5,0,[[0,'#3c62b8'],[.28,'#22388a'],[1,'#121e58']]);g.fill();
   g.beginPath();g.ellipse(x,y,s*.62,s*.52,0,Math.PI*.56,Math.PI*1.44);g.strokeStyle='rgba(6,8,28,.85)';g.lineWidth=1.5;g.stroke();
   g.beginPath();g.ellipse(x+1.3,y,s*.52,s*.42,0,Math.PI*.62,Math.PI*1.3);g.strokeStyle='rgba(150,190,255,.35)';g.lineWidth=.9;g.stroke();
   g.fillStyle='rgba(170,200,255,.28)';g.beginPath();g.arc(x-s*.28,y-s*.08,.8,0,TAU);g.arc(x-s*.2,y+s*.16,.7,0,TAU);g.fill()}}
 g.restore();
 // ancient pale markings
 fa9_mottle(g,B,[[40,10,9,'#c8dcff',.28],[-6,-14,8,'#c8dcff',.24],[-34,12,7,'#c8dcff',.22],[18,28,7,'#c8dcff',.2],[56,-24,6,'#c8dcff',.2]]);
 fkShade(g,B,-8,-44,'#040824',.55);
 fkShade(g,B,16,44,'#3a2a7a',.32);
 // gilded lateral line with glowing pores that follow the rune pulse
 g.save();B();g.clip();g.lineCap='round';g.beginPath();g.moveTo(70,-6);g.quadraticCurveTo(0,-2,-64,0);g.strokeStyle='rgba(4,6,24,.6)';g.lineWidth=3.4;g.stroke();g.strokeStyle='#d8a848';g.lineWidth=1.6;g.stroke();
 g.globalCompositeOperation='lighter';for(let i=0;i<14;i++){const u=i/13,x=68-u*130,y=-6+u*3.6+Math.sin(Math.PI*u)*1.6,k=rk((60-x)/14.5);g.fillStyle=`rgba(255,220,130,${.2+.7*k})`;g.beginPath();g.arc(x,y,1.5+1.6*k,0,TAU);g.fill()}g.restore();
 // runes etched along two curving scale rows above and below the lateral line, sized unevenly, lit head to tail
 g.save();B();g.clip();
 for(let i=0;i<8;i++){const x=60-i*14.5,v=((i*7)%5)/4,sz=4*(.8+.5*v),yu=-22+.0032*(x-8)*(x-8),yl=16-.0028*(x-8)*(x-8);
  fa9_rune(g,x,yu,sz,i,rk(i),Math.atan(.0064*(x-8)));fa9_rune(g,x-6,yl,4*(1.3-.5*v),i+3,rk(i+.35),Math.atan(-.0056*(x-8)))}
 g.restore();
 // gold glints twinkling on scale edges
 g.save();B();g.clip();for(let i=0;i<9;i++){const x=60-((i*37)%110),y=-30+((i*23)%56),k=Math.max(0,Math.sin(t*1.6+i*2.1))**8;if(k>.05)fkSpark(g,x,y,1.5+3.5*k,'#ffe6a0',k)}
 g.restore();
 // shimmer sweeping over the armour, and the whole hide brightening in the catch glow
 {const sx=((t*38)%300)-150;g.save();B();g.clip();g.globalCompositeOperation='lighter';g.fillStyle=fa9_grad(g,sx-30,-40,sx+30,40,[[0,'rgba(120,200,255,0)'],[.5,`rgba(140,210,255,${.16+gl*.3})`],[1,'rgba(120,200,255,0)']]);g.fillRect(-80,-50,200,100);
  if(gl>0){g.fillStyle=`rgba(120,190,255,${gl*.08})`;g.fillRect(-80,-50,200,100)}g.restore()}
 // ---- head: smooth bony plates trimmed in gold ----
 const H=()=>fa9_path(g,['M',72,-37,'C',62,-20,60,8,70,36,'L',120,36,'L',120,-40,'Z']);
 g.save();B();g.clip();H();g.clip();
 B();g.fillStyle=fa9_grad(g,70,-40,106,30,[[0,'#16246a'],[.5,'#22388e'],[1,'#2c4498']]);g.fill();
 fa9_speck(g,B,70,110,-40,36,60,'#9ac0ff',.3,.6,71);
 fkShade(g,B,-8,-44,'#040824',.5);fkShade(g,B,16,44,'#3a2a7a',.3);
 g.lineCap='round';g.lineJoin='round';
 // three bony plates: postorbital crown plate, cheek plate and snout plate
 fa9_plate(g,[73,-36,90,-33,100,-26,103,-18,96,-20,84,-21,76,-22,73,-30],[100,-24,76,-23]);
 fa9_plate(g,[73,-4,86,-2,96,4,100,12,96,22,84,28,74,26,70,12],[96,6,76,24]);
 fa9_plate(g,[98,-20,106,-16,110,-8,106,-2,100,-3,98,-10],[108,-12]);
 g.restore();
 // operculum: a big gilded gill plate
 g.save();B();g.clip();g.beginPath();g.moveTo(74,-36);g.bezierCurveTo(62,-18,60,10,70,34);g.strokeStyle='rgba(4,6,24,.8)';g.lineWidth=3.6;g.stroke();g.strokeStyle='#f0c25a';g.lineWidth=1.8;g.stroke();
 g.beginPath();g.moveTo(76.5,-34);g.bezierCurveTo(65,-17,63,10,72.5,32);g.strokeStyle='rgba(255,236,170,.4)';g.lineWidth=1;g.stroke();
 // gilded ridge where the dorsal fan roots into the back
 g.beginPath();g.moveTo(40,-42.5);g.quadraticCurveTo(10,-39.5,-18,-32);g.strokeStyle='rgba(4,6,24,.7)';g.lineWidth=3.2;g.stroke();g.strokeStyle='#e8b84e';g.lineWidth=1.4;g.stroke();
 for(const x of [32,18,4,-10]){g.beginPath();g.arc(x,-41.6+.0045*(x-30)*(x-30)*.5+(30-x)*.12,1.6,0,TAU);g.fillStyle='#ffe08a';g.fill();g.strokeStyle='rgba(4,6,24,.8)';g.lineWidth=.9;g.stroke()}
 g.restore();
 fa9_rim(g,B,'#9ad0ff','#a890ff',1,2);
 fa9_gloss(g,B,96,-21,66,-38,10,-42,1.7,.45);
 B();g.lineJoin='round';g.lineWidth=3.2;g.strokeStyle=FKO;g.stroke();
 // gold rim light blazing along the body outline in the catch glow
 if(gl>0){g.save();B();g.clip();B();g.strokeStyle=`rgba(255,218,130,${gl*.9})`;g.lineWidth=7;g.stroke();B();g.strokeStyle=`rgba(255,245,200,${gl*.6})`;g.lineWidth=3;g.stroke();g.restore();
  g.save();g.globalCompositeOperation='lighter';B();g.strokeStyle=`rgba(255,210,120,${gl*.45})`;g.lineWidth=6;g.stroke();g.restore()}
 // ---- near lobed fins in front: pelvic and pectoral ----
 fa9_lobe(g,22,40,2.1-wk(3.4)*.8,36,10,rk(2.6),t,2.6);
 fa9_lobe(g,62,14,2.62+wk(4.2),42,11,rk(.2),t,.6);
 // ---- the ancient, wise eye: heavy lid, molten-gold iris, crow's-feet ----
 const ex=88,ey=-12,er=12;fkGlow(g,ex,ey,er*2.6+gl*10,'#ffcf60',.16+.12*pu+gl*.55);
 fa9_eye(g,ex,ey,er,'#e8a830',.25);
 g.save();g.beginPath();g.arc(ex,ey,er,0,TAU);g.clip();g.globalCompositeOperation='lighter';g.fillStyle=fa9_rgrad(g,ex+2,ey+1,0,er*.7,[[0,'rgba(255,200,90,0)'],[.7,`rgba(255,200,90,${.18+.2*pu+gl*.3})`],[1,'rgba(255,200,90,0)']]);g.fillRect(ex-er,ey-er,er*2,er*2);g.restore();
 fa9_lid(g,ex,ey,er,.38+fa9_blink(t,1.3)*.62,'#24388e');
 g.save();g.lineCap='round';g.strokeStyle=FKO;g.lineWidth=1.4;g.beginPath();g.moveTo(ex-er-1,ey+4);g.lineTo(ex-er-5,ey+6);g.moveTo(ex-er-.5,ey+7.5);g.lineTo(ex-er-4,ey+10.5);g.stroke();
 // gilded brow
 g.beginPath();g.moveTo(ex-er*1.1,ey-er*.85);g.quadraticCurveTo(ex,ey-er*1.55,ex+er*1.05,ey-er*.95);g.strokeStyle=FKO;g.lineWidth=3.6;g.stroke();g.strokeStyle='#f0c25a';g.lineWidth=1.8;g.stroke();g.restore();
 // calm, closed mouth with a gold lip line and chin plate
 g.save();g.lineCap='round';g.beginPath();g.moveTo(107,4);g.quadraticCurveTo(98,9.5,88,8.5);g.strokeStyle=FKO;g.lineWidth=2.4;g.stroke();
 g.beginPath();g.moveTo(106,6.5);g.quadraticCurveTo(98,12,89,11);g.strokeStyle='rgba(240,194,90,.55)';g.lineWidth=1.1;g.stroke();
 g.beginPath();g.arc(88,8,2,Math.PI*.5,Math.PI*1.35);g.strokeStyle=FKO;g.lineWidth=1.3;g.stroke();g.restore();
 fa9_spec(g,30,-34,.85,.75);
 // orbiting motes of rune-light, gold and cyan, circling the whole fish
 g.save();g.globalCompositeOperation='lighter';for(let i=0;i<16;i++){const p=(t*.12+i/16)%1,a=i*1.37+t*.3,R=84+Math.sin(i*1.3)*20,x=Math.cos(a)*R*1.2+8,y=Math.sin(a)*R*.62-p*10,k=Math.sin(Math.PI*p)*(.7+.3*fa9_tw(t,i,5)),c=i%2?'255,214,120':'110,236,255';
  g.fillStyle=`rgba(${c},${.22*k+gl*.2*k})`;g.beginPath();g.arc(x,y,5+gl*3,0,TAU);g.fill();g.fillStyle=`rgba(${c},${.95*k})`;g.beginPath();g.arc(x,y,1.7+gl*.6,0,TAU);g.fill();g.fillStyle=`rgba(255,255,255,${.8*k})`;g.beginPath();g.arc(x,y,.8,0,TAU);g.fill()}g.restore();
 // gold glints twinkling around the body
 [[-6,-60,1,1.8,'#fff2c8'],[60,48,3,2.2,'#c8f6ff'],[-84,-34,5,2.5,'#ffe8a8'],[98,-46,7,2.1,'#ffe6a0'],[-100,16,9,2.4,'#fff2c8'],[36,54,11,2.7,'#ffe6a0'],[-46,-54,13,2.0,'#c8f6ff'],[104,30,15,2.3,'#ffe8a8']].forEach(([x,y,i,sp,c])=>{const w=fa9_tw(t,i,sp);fkSpark(g,x,y,2+3.5*w+gl*2.5,c,Math.min(1,.3+.6*w+gl*.3))});
 fa9_catch(g,o,'#9adcff',2);g.restore()};

/* update 7: when drawn as an undiscovered silhouette (o.sil), these fish skip additive light (auras, glows, rays), so the
   journal shows a clean solid outline instead of a hazy blob. Normal drawing is untouched. */
(()=>{const P=new WeakMap(),wrap=c=>{let p=P.get(c);if(!p){const F=new Map();p=new Proxy(c,{get(t,k){const v=t[k];if(typeof v!=='function')return v;let f=F.get(k);
  if(!f){f=(k==='fill'||k==='fillRect'||k==='stroke'||k==='strokeRect'||k==='drawImage')?function(){if(t.globalCompositeOperation==='lighter')return;return v.apply(t,arguments)}:v.bind(t);F.set(k,f)}return f},
  set(t,k,v){t[k]=v;return true}});P.set(c,p)}return p};
 ['shroom','geode','lshark','coelacanth'].forEach(id=>{const f=FISHART[id];if(f)FISHART[id]=(g,t,o)=>f(typeof FKSIL!=='undefined'&&FKSIL&&g.canvas===FKSIL?wrap(g):g,t,o)})})();
