/* ===== RUNESTONE TOWER DEFENSE 9.8: the Thunder Mortar in battle (95t, after 95s) =====
   The eighth tower (key O). Long-range artillery that cannot hit flyers: it picks the spot where a shell will catch the most ground
   monsters (it leads them with rptPred from 95r, so it also reads Tidecaller slides and Frost stuns), lights its fuse, fires, and the
   shell arcs over the map for about a second while a warning ring shrinks on the landing spot. The blast hurts every ground monster in
   the splash (full damage at the centre, 60% at the edge). It cannot fire at anything inside its dead zone (RPQM.minR).
   Tier 3: scorched craters slow ground monsters standing in them. Tier 4: every shell scatters three bomblets. Tier 5: every
   RP_TW.mortar.barrage[4]th volley calls a Thunder Barrage, five lightning shells down the road ahead of the target that also stun
   (not bosses). Overcharge speeds it up and adds 15% damage like every other tower.
   State on RPX: mtShells [{x0,y0,x1,y1,t,d,h,tw,tier,dmg,r,ap,kind:'main'|'bomb'|'storm',seed}], mtBooms [{x,y,r,t,d,tier,storm}],
   mtCraters [{x,y,r,t,d,k,tier}]. Tower: tw.cd, tw.charge (fuse 0..1), tw.fire, tw.aim, tw.nv (volleys). */
RP_TW.mortar={cost:[550,360,630,1220,1960],range:[300,315,335,355,380],dmg:[85,140,230,370,560],cd:[3,2.8,2.6,2.45,2.3],splash:[78,86,96,106,118],
 ap:[2,4,8,99,99],crater:[0,0,.4,.45,.5],cluster:[0,0,0,3,3],barrage:[0,0,0,0,5],air:0,ground:1,
 desc:'Lobs heavy shells at the biggest crowd from far away. Huge splash, slow reload. Cannot hit flyers or anything close.',
 up:['Heavier shells and a longer reach.','Rune shells: every blast leaves a scorched crater that slows.','Cluster shells: each shell scatters three bomblets.','Thunder Barrage: every fifth volley calls five lightning shells down the road.']};
RP_TWORDER.push('mortar');RP_KEYS.push('O');
const RPQM={minR:95,fuse:.55,craterT:3,bombK:.35,bombR:.55,stormK:.7,stormStun:.5,edge:.6};
/* flight time grows a little with distance */
const rpqFlight=d=>.85+d/1000;
/* where a monster will be when a shell fired now lands */
function rpqLand(R,e,ft){const s=typeof rptPred==='function'?rptPred(R,e,ft):e.s;const p=rpAt(R.G,Math.max(0,Math.min(rpLen(R,e),s)),e.pi),o=e.off||0;return{x:p.x-Math.sin(p.a)*o,y:p.y+Math.cos(p.a)*o,s}}
/* the best landing spot: the predicted position of a monster in reach that has the most ground monsters inside the splash */
function rpqAim(R,tw,T,i){const rg=T.range[i],r2=rg*rg,m2=RPQM.minR*RPQM.minR,cand=[];
 for(const e of R.foes){if(e.dead||e.air||e.s<0)continue;const q=rpPos(R,e),d2=rpD2(q.x,q.y,tw.x,tw.y);if(d2>r2||d2<m2)continue;cand.push(e)}
 if(!cand.length)return null;
 const pr=new Map();const P=e=>{let v=pr.get(e);if(!v){const q=rpPos(R,e);v=rpqLand(R,e,rpqFlight(Math.sqrt(rpD2(q.x,q.y,tw.x,tw.y))));pr.set(e,v)}return v};
 const sp=T.splash[i]*.8,s2=sp*sp;let best=null,bv=-1e18;
 for(const e of cand){const L=P(e);let n=0,hp=0;for(const f of R.foes){if(f.dead||f.air||f.s<0)continue;const M=P(f);if(rpD2(M.x,M.y,L.x,L.y)<=s2){n++;hp+=f.hp}}
  const pv=tw.prio==='strong'?e.hp/1e6:tw.prio==='close'?-rpD2(L.x,L.y,tw.x,tw.y)/1e6:e.s/rpLen(R,e);const v=n*10+pv+(e.boss?3:0);if(v>bv){bv=v;best={e,x:L.x,y:L.y,s:L.s}}}
 return best}
function rpMortarFire(R,tw,dt){const T=RP_TW.mortar,i=tw.tier-1,sp=tw.over>0?RPT.AB.over.k:1;tw.over=Math.max(0,tw.over-dt);
 tw.fire=Math.max(0,(tw.fire||0)-dt*1.6);tw.cd-=dt*sp;tw.charge=tw.cd<RPQM.fuse?Math.min(1,1-tw.cd/RPQM.fuse):Math.max(0,(tw.charge||0)-dt*3);
 if(tw.cd>0)return;const a=rpqAim(R,tw,T,i);if(!a){tw.cd=.15;tw.charge=Math.max(0,tw.charge-.4);return}
 const dmgK=tw.over>0?1.15:1;tw.cd=T.cd[i];tw.fire=1;tw.charge=0;tw.aim=Math.atan2(a.y-tw.y,a.x-tw.x);tw.nv=(tw.nv||0)+1;
 const m=rpMortarMuzzle(tw.tier,tw.aim,1),x0=tw.x+m.x,y0=tw.y+m.y,d=Math.hypot(a.x-x0,a.y-y0),ft=rpqFlight(d);
 R.mtShells.push({x0,y0,x1:a.x,y1:a.y,t:0,d:ft,h:150+d*.32,tw,tier:tw.tier,dmg:T.dmg[i]*dmgK,r:T.splash[i],ap:T.ap[i],kind:'main',seed:Math.random()*99});
 try{ptBurst(R.fx,x0,y0-6,R.lite?4:9,tw.tier>=5?['#ffffff','#fff2b0','#9ae8ff']:['#ffe6a0','#ff9a3a','#cfc6b8'],{v:150,s:3.2,up:1,g:260})}catch(e){}
 R.shake=Math.max(R.shake||0,1.6);rpqSfx('fire');
 /* tier 5: the Thunder Barrage */
 const bn=T.barrage[i];if(bn&&tw.nv%bn===0){const e=a.e;for(let k=0;k<5;k++){const off=(k-2)*46,s=Math.max(0,Math.min(rpLen(R,e)-6,a.s+off)),p=rpAt(R.G,s,e.pi),dl=.35+k*.12;
   R.mtShells.push({x0:p.x+(Math.random()-.5)*40,y0:p.y-460,x1:p.x,y1:p.y,t:-dl,d:.42,h:0,tw,tier:5,dmg:T.dmg[i]*RPQM.stormK*dmgK,r:T.splash[i]*.8,ap:99,kind:'storm',seed:Math.random()*99})}
  rpText(tw.x,tw.y-RPLAY.mortar[5].top-14,'THUNDER BARRAGE','#9ae8ff',20);setTimeout(()=>rpqSfx('thunder'),300)}}
function rpqSfx(k){try{if(k==='fire'){beep(70,.18,'square',.22);setTimeout(()=>beep(140,.06,'triangle',.25),20)}
 else if(k==='boom'){beep(55+Math.random()*15,.32,'sawtooth',.2);setTimeout(()=>beep(40,.3,'triangle',.25),40)}
 else if(k==='pop')beep(160+Math.random()*40,.08,'square',.1);
 else if(k==='thunder'){beep(1800,.05,'sawtooth',.08);setTimeout(()=>beep(60,.5,'sawtooth',.25),60)}}catch(e){}}
/* a shell lands: damage, crater, bomblets, effects */
function rpqLandShell(R,s){const T=RP_TW.mortar,i=Math.max(0,Math.min(4,s.tw.tier-1)),x=s.x1,y=s.y1;
 for(const e of R.foes){if(e.dead||e.air||e.s<0)continue;const q=rpPos(R,e),d2=rpD2(q.x,q.y,x,y);if(d2>s.r*s.r)continue;
  const k=1-(1-RPQM.edge)*Math.sqrt(d2)/s.r;rpHurt(e,s.dmg*k,s.ap,s.tw);if(!e.dead&&s.kind==='storm'&&!e.boss)e.stun=Math.max(e.stun||0,RPQM.stormStun)}
 R.mtBooms.push({x,y,r:s.r,t:0,d:s.kind==='bomb'?.45:.65,tier:s.tier,storm:s.kind==='storm',seed:s.seed});if(R.mtBooms.length>40)R.mtBooms.shift();
 if(T.crater[i]&&s.kind!=='bomb'){R.mtCraters.push({x,y,r:s.r*.85,t:0,d:RPQM.craterT,k:T.crater[i],tier:s.tier});if(R.mtCraters.length>24)R.mtCraters.shift()}
 if(s.kind==='main'&&T.cluster[i]){for(let k=0;k<T.cluster[i];k++){const a=Math.random()*TAU,dd=s.r*(.55+Math.random()*.35);
   R.mtShells.push({x0:x,y0:y-6,x1:x+Math.cos(a)*dd,y1:y+Math.sin(a)*dd*RPFX.sq,t:-k*.06,d:.34,h:46,tw:s.tw,tier:s.tier,dmg:s.dmg*RPQM.bombK,r:s.r*RPQM.bombR,ap:s.ap,kind:'bomb',seed:Math.random()*99})}}
 const big=s.kind!=='bomb';R.shake=Math.max(R.shake||0,big?3.2:1.2);
 try{ptBurst(R.fx,x,y-8,R.lite?(big?6:3):(big?16:6),s.kind==='storm'?['#e8fbff','#9ae8ff','#ffffff']:['#ffd27a','#ff8a3a','#6a5a4a','#3a2a24'],{v:big?260:160,s:big?4:3,up:1,g:520})}catch(e){}
 if(s.kind==='storm'){rpRing(x,y,'#9ae8ff',s.r*1.2,5);rpqSfx('pop')}else rpqSfx(big?'boom':'pop')}
function rpqStep(R,dt){if(!R.mtShells)return;
 for(const s of R.mtShells){s.t+=dt;if(s.t>=s.d&&!s.done){s.done=1;rpqLandShell(R,s)}}R.mtShells=R.mtShells.filter(s=>!s.done);
 for(const b of R.mtBooms)b.t+=dt;R.mtBooms=R.mtBooms.filter(b=>b.t<b.d);
 for(const c of R.mtCraters){c.t+=dt;for(const e of R.foes){if(e.dead||e.air||e.s<0)continue;const q=rpPos(R,e);if(rpD2(q.x,q.y,c.x,c.y)<c.r*c.r){e.slowK=Math.max(e.slowK||0,c.k);e.slowT=Math.max(e.slowT||0,.3)}}}
 R.mtCraters=R.mtCraters.filter(c=>c.t<c.d)}
/* hooks: fire routine, battle state, step, upgrade */
{const f0=rpFire;rpFire=function(R,tw,dt){if(tw.type==='mortar')return rpMortarFire(R,tw,dt);return f0.apply(this,arguments)}}
{const s0=rpStart;rpStart=function(){const r=s0.apply(this,arguments);if(RPX)Object.assign(RPX,{mtShells:[],mtBooms:[],mtCraters:[]});return r}}
{const s0=rpStep;rpStep=function(R,dt){const r=s0.apply(this,arguments);try{rpqStep(R,dt)}catch(e){console.error(e)}return r}}
{const u0=rpUpgrade;rpUpgrade=function(tw){const r=u0.apply(this,arguments);if(r&&tw&&tw.type==='mortar'){tw.charge=0;tw.fire=0}return r}}
/* drawing: craters, landing rings and shell shadows on the ground; shells, blasts and barrage lightning on top */
const rpqPos=s=>{const u=Math.max(0,Math.min(1,s.t/s.d));return{u,x:s.x0+(s.x1-s.x0)*u,y:s.y0+(s.y1-s.y0)*u-s.h*4*u*(1-u),gx:s.x0+(s.x1-s.x0)*u,gy:s.y0+(s.y1-s.y0)*u}};
{const a0=rpAmbient;rpAmbient=function(c,R){const r=a0.apply(this,arguments);try{if(R&&R.mtCraters){
 for(const k of R.mtCraters){const f=Math.min(1,k.t*6,(k.d-k.t)/.8);rpMortarCrater(c,k.x,k.y,k.r,f,R.t,k.tier)}
 for(const s of R.mtShells){if(s.t<0)continue;const p=rpqPos(s);if(s.kind!=='bomb')rpMortarReticle(c,s.x1,s.y1,s.r,p.u,s.tier);
  if(s.kind==='main'){const k=.35+.65*p.u;c.fillStyle=`rgba(8,4,20,${(.35*k).toFixed(3)})`;c.beginPath();c.ellipse(p.gx,p.gy+2,8*k,3.4*k,0,0,TAU);c.fill()}}}}catch(e){console.error(e)}return r}}
{const b0=rpBeamsDraw;rpBeamsDraw=function(c,R){b0.apply(this,arguments);if(!R.mtShells)return;
 for(const b of R.mtBooms){if(b.storm)rpMortarBolt(c,b.x,b.y,Math.min(.99,b.t/.25),b.seed|0);rpMortarBoom(c,b.x,b.y,b.r*(b.storm?.9:1),b.t/b.d,b.tier,b.storm)}
 for(const s of R.mtShells){if(s.t<0)continue;const p=rpqPos(s),col=rpqShellC(s.tier);
  if(s.kind==='storm'){c.save();c.globalCompositeOperation='lighter';c.strokeStyle='rgba(200,244,255,.8)';c.lineWidth=4;c.beginPath();c.moveTo(p.x,p.y-60);c.lineTo(p.x,p.y);c.stroke();rpGlow(c,p.x,p.y,24,24,'#9ae8ff',.9);c.restore();c.globalAlpha=1}
  else{/* a trail of sparks behind the shell */c.save();c.globalCompositeOperation='lighter';const n=R.lite?2:4;for(let k=1;k<=n;k++){const q=rpqPos({x0:s.x0,y0:s.y0,x1:s.x1,y1:s.y1,h:s.h,t:Math.max(0,s.t-k*.035),d:s.d});rpGlow(c,q.x,q.y,12-k*1.6,12-k*1.6,col,.85-k*.14)}c.restore();c.globalAlpha=1}
  rpMortarShell(c,p.x,p.y,s.tier,s.t*9,s.kind==='bomb'?1:1.6);
  if(s.kind!=='storm'){c.save();c.globalCompositeOperation='lighter';rpGlow(c,p.x,p.y-8,6,6,col,.8+.2*Math.sin(R.t*40));c.restore();c.globalAlpha=1}}}}
/* the info panel: range, damage, splash, fire rate */
{const i0=rpInfoBuild;rpInfoBuild=function(R,tw,el){const r=i0.apply(this,arguments);if(tw.type!=='mortar')return r;try{const T=RP_TW.mortar,i=tw.tier-1,top=RP_MAXT(R.map),nx=tw.tier<top?tw.tier:null;
  const seg=(v,max)=>Math.max(0,Math.min(6,Math.round(v/max*6))),bar=(lab,v,max,nv)=>`<div class="rpst"><span>${lab}</span><i>${[0,1,2,3,4,5].map(k=>`<s class="${k<seg(v,max)?'on':nv!=null&&k<seg(nv,max)?'up':''}"></s>`).join('')}</i></div>`;
  const dmg=j=>Math.sqrt(T.dmg[j]*(1+T.cluster[j]*RPQM.bombK)/T.cd[j]*6);
  const st=el.querySelector('.rpsts');if(st)st.innerHTML=bar('Range',T.range[i],380,nx!=null?T.range[nx]:null)+bar('Damage',dmg(i),Math.sqrt(1700),nx!=null?dmg(nx):null)+bar('Splash',T.splash[i],120,nx!=null?T.splash[nx]:null)+bar('Fire rate',1/T.cd[i],.6,nx!=null?1/T.cd[nx]:null);
  const hgt=el.offsetHeight||420;el.style.top=rpClamp(tw.y-hgt*.62,76,770-hgt)+'px'}catch(e){console.error(e)}return r}}
/* the range ring also shows the dead zone while a mortar is selected or being placed */
{const d0=rpDraw;rpDraw=function(){const r=d0.apply(this,arguments);try{const R=RPX;if(!R||!S.rp)return r;const c=ctx;let x=null,y=null;
  if(R.sel&&R.sel.type==='mortar'){x=R.sel.x;y=R.sel.y}else if(R.place==='mortar'&&R.ghost){x=R.ghost.x;y=R.ghost.y}
  if(x!=null){c.save();c.setTransform(RS,0,0,RS,0,0);c.setLineDash([7,7]);c.lineWidth=2.2;c.strokeStyle='rgba(255,110,110,.85)';c.beginPath();c.ellipse(x,y,RPQM.minR,RPQM.minR*RPFX.sq,0,0,TAU);c.stroke();c.setLineDash([]);c.fillStyle='rgba(255,90,90,.08)';c.fill();c.restore()}}catch(e){}return r}}
/* key O picks it */
{const k0=rpKeyDown;window.removeEventListener('keydown',rpKeyDown,true);rpKeyDown=function(e){const R=RPX;if(R&&S.rp&&S.mode==='ramparts'&&!R.pause&&!R.over&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&e.key.length===1&&e.key.toLowerCase()==='o'){e.preventDefault();e.stopImmediatePropagation();if(!e.repeat)rpPlace('mortar');return}return k0.apply(this,arguments)};window.addEventListener('keydown',rpKeyDown,true)}
/* eight tiles in the bar: a little narrower */
{const st=document.createElement('style');st.textContent=`.rph.rp7.rp8 .rpbar{gap:5px}.rph.rp7.rp8 .rpcard{width:99px}.rph.rp7.rp8 .rpct>b{max-width:94px;font-size:13.5px}.rph.rp7.rp8 .rpcard img{width:74px;height:74px;margin-left:-37px;top:-22px}`;document.head.appendChild(st)}
{const h0=rpHudOn;rpHudOn=function(){const r=h0.apply(this,arguments);try{const h=$('rphud');if(h&&RP_TWORDER.length>=8)h.classList.add('rp8')}catch(e){}return r}}
try{const h=HELP.Modes.find(x=>x[0]==='Runestone Tower Defense');if(h)h[1]+=' The Thunder Mortar (O, 550 supply) lobs heavy shells at the biggest crowd from very far away; it cannot hit flyers or anything close to it.'}catch(e){}
{const h0=rpHowTo;rpHowTo=function(){const r=h0.apply(this,arguments);try{const w=ov.querySelector('#rpmod .rphw');if(w)w.insertAdjacentHTML('beforeend',`<p><b>Thunder Mortar.</b> Long-range artillery (550 supply, key O). It aims each shell where it will catch the most ground monsters; a ring shows where it will land. It cannot hit flyers or anything inside its dead zone (red ring). Tier 3 leaves slowing craters, tier 4 adds cluster bomblets, tier 5 calls a Thunder Barrage every fifth volley.</p>`)}catch(e){}return r}}
