/* ===== RUNESTONE RIDDLE: the keepers of the sanctum =====
   Four Dragon Lounge regulars, re-tailored as the riddle's rotating daily hosts: a goblin rune scholar with an open
   spellbook, a golden dragon archivist in an academic gown, a skeleton librarian with a brass lantern and an octopus
   scribe with quill and inkpot. Same chunky storybook style as the crew (dark #12081f outlines, darker right halves,
   small upper-left highlights) and the same scale: feet at 0,0, about 230 units tall.
   RRK holds the four keepers (full crew A objects plus id, n name, t title, line greeting).
   rrkDraw(g,A,t,st) paints one with st={mode,k}: idle | point | cheer | think | sad (k 0..1 eases into the pose).
   rrkPortrait(cv,A,t) paints a gold-ringed head-and-shoulders medallion. Everything is a pure function of t and st. */
WCSP.rrkdrg={skin:['#f6c443','#b5791c'],belly:'#fff0c4',hats:[''],eyes:[''],hand:'claw',last:['Goldhoard']};
const RRK=[
 {id:'gob',n:'Professor Nickels',t:'Rune Scholar',line:"Five runes, six guesses. Let's crack today's stone!",
  sp:'goblin',name:'Professor Nickels',suit:'#272431',suit2:'#16141c',pants:'#1b1923',shoe:'#121016',tie:'#ffd45a',tk:'bow',hat:'bowler',eye:'',hold:'book',chain:true,seed:117,top:-252},
 {id:'drg',n:'Goldhoard the Archivist',t:'Keeper of Scrolls',line:"Every word worth knowing is in my hoard. Find today's.",
  sp:'rrkdrg',name:'Goldhoard the Archivist',suit:'#2f2170',suit2:'#1a1240',robe:'#30216e',facing:'#6a3ad0',vest:'#8a1c3c',pants:'#1c1636',shoe:'#1a1420',tie:'#9a5cff',tk:'bow',hat:'mortar',eye:'mono',hold:'quill',chain:true,seed:402,top:-258},
 {id:'skel',n:'Lorekeeper Rattles',t:'Night Librarian',line:"Shh... the runes are listening. Whisper me a word.",
  sp:'skel',name:'Lorekeeper Rattles',suit:'#2a5a58',suit2:'#173a3a',shirt:'#f2ecdc',pants:'#2a2838',shoe:'#3a2418',tie:'#a8243e',tk:'bow',hat:'',eye:'half',hold:'lantern',chain:true,seed:733,top:-232},
 {id:'oct',n:'Scribe Inkwell',t:'Glyph Copyist',line:"Eight arms, one quill, five letters. Write me a guess!",
  sp:'octo',name:'Scribe Inkwell',suit:'#2a2c72',suit2:'#181a48',apron:'#f0e2c0',tie:'#2fb8a0',tk:'bow',hat:'tam',eye:'pince',hold:'inkpot',chain:false,seed:259,top:-266}];
/* --- small maths --- */
function rrkEase(k){k=k<0?0:k>1?1:k;return k*k*(3-2*k)}
/* half-shading in one pass: a hard-stop gradient (darker right of sx) instead of a clip and a second fill */
const RRKMIX=new Map();
function rrkDark(fill,dk){const key=fill+'|'+dk;let v=RRKMIX.get(key);if(v)return v;const h=fill.replace('#','');const c=[0,2,4].map(i=>parseInt(h.substr(i,2),16));
 const m=/rgba?\(([^)]*)\)/.exec(dk||'rgba(0,0,0,.17)'),q=m[1].split(',').map(Number),a=q.length>3?q[3]:1;v='rgb('+c.map((x,i)=>Math.round(x*(1-a)+q[i]*a)).join(',')+')';RRKMIX.set(key,v);return v}
function rrkFS(g,fill,sx,lw,dk){if(sx!=null&&fill[0]==='#'&&fill.length===7){const gr=g.createLinearGradient(sx-.6,0,sx+.6,0);gr.addColorStop(0,fill);gr.addColorStop(1,rrkDark(fill,dk||'rgba(0,0,0,.17)'));g.fillStyle=gr;g.fill();if(lw!==0)wcSt2(g,lw)}else wcFS(g,fill,sx,lw,dk)}
function rrkEl(g,x,y,rx,ry,fill,lw,sx,dk){g.beginPath();g.ellipse(x,y,rx,ry,0,0,Math.PI*2);rrkFS(g,fill,sx,lw,dk)}
function rrkDots(g,pts,r,fill,lw){g.beginPath();for(const [x,y] of pts){g.moveTo(x+r,y);g.arc(x,y,r,0,Math.PI*2)}g.fillStyle=fill;g.fill();wcSt2(g,lw)}
function rrkMix(p,q,k){return p.map((v,i)=>v+(q[i]-v)*k)}
function rrkSeg(g,x0,y0,x1,y1,w,col){g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.lineCap='round';g.lineWidth=w+5;g.strokeStyle=WCO;g.stroke();g.lineWidth=w;g.strokeStyle=col;g.stroke()}
/* a bent sleeve from shoulder S through elbow E to wrist W, round at the shoulder */
function rrkSleeve(g,S,E,W,w0,w1,fill,dk){const d1x=E[0]-S[0],d1y=E[1]-S[1],l1=Math.hypot(d1x,d1y)||1,n1x=-d1y/l1,n1y=d1x/l1,d2x=W[0]-E[0],d2y=W[1]-E[1],l2=Math.hypot(d2x,d2y)||1,n2x=-d2y/l2,n2y=d2x/l2;
 let mx=n1x+n2x,my=n1y+n2y;const ml=Math.hypot(mx,my)||1,wm=(w0+w1)*.62;mx/=ml;my/=ml;const a1=Math.atan2(d1y,d1x);
 g.beginPath();g.moveTo(S[0]+n1x*w0,S[1]+n1y*w0);g.quadraticCurveTo(E[0]+mx*wm,E[1]+my*wm,W[0]+n2x*w1,W[1]+n2y*w1);g.lineTo(W[0]-n2x*w1,W[1]-n2y*w1);
 g.quadraticCurveTo(E[0]-mx*wm,E[1]-my*wm,S[0]-n1x*w0,S[1]-n1y*w0);g.arc(S[0],S[1],w0,a1-Math.PI/2,a1+Math.PI/2,true);g.closePath();
 rrkFS(g,fill,Math.max(S[0],E[0],W[0])-(Math.max(S[0],E[0],W[0])-Math.min(S[0],E[0],W[0]))*.38+2,3,dk||'rgba(0,0,0,.2)')}
function rrkCuff(g,E,W,w,col,len){g.save();g.translate(W[0],W[1]);g.rotate(Math.atan2(W[1]-E[1],W[0]-E[0]));g.beginPath();g.rect(-(len||6),-w,(len||6)+1,w*2);rrkFS(g,col,null,2.2);g.restore()}
/* hands: rest/grip (the crew mitt, turned to face ang), point (index finger out), fist */
function rrkHand(g,A,x,y,ang,kind){const D=WCSP[A.sp],sk=D.skin;g.save();g.translate(x,y);g.rotate(ang-Math.PI/2);
 if(kind==='point'){if(D.hand==='bone'){g.strokeStyle=WCO;for(const [x0,y0,x1,y1,w] of [[0,2,0,21,6.4],[-6,2,-9,9,5.6]]){g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.lineWidth=w;g.strokeStyle=WCO;g.stroke();g.lineWidth=w-3;g.strokeStyle=sk[0];g.stroke()}
   wcEl(g,0,2,7,6,sk[0],2.4);for(const dx of [2.5,5.5])wcEl(g,dx,7,1.8,1.8,sk[0],1.6);wcEl(g,0,13,2.2,1.6,sk[1],0)}
  else{g.beginPath();g.roundRect(-3.6,0,7.2,22,3.6);rrkFS(g,sk[0],1.2,2.4);if(D.hand==='claw'){g.beginPath();g.moveTo(-2.6,20);g.lineTo(0,27);g.lineTo(2.6,20);g.closePath();rrkFS(g,'#fff4dc',null,1.6)}
   rrkEl(g,1,3,9,8,sk[0],2.8,3);g.beginPath();g.moveTo(3,6);g.quadraticCurveTo(7,8,8,4);wcSt2(g,1.8);g.beginPath();g.moveTo(-8,0);g.quadraticCurveTo(-13,5,-9,11);g.quadraticCurveTo(-5,9,-4,5);g.closePath();rrkFS(g,sk[0],null,2.2)}}
 else if(kind==='fist'&&D.hand==='bone'){wcEl(g,0,1,7,6,sk[0],2.4);for(const dx of [-4.5,0,4.5])wcEl(g,dx,7.5,2.6,2.6,sk[0],1.8)}
 else if(kind==='fist'){rrkEl(g,0,2,9.5,8.5,sk[0],2.8,3);g.beginPath();g.moveTo(-5,6);g.lineTo(-5,9);g.moveTo(0,7);g.lineTo(0,10);g.moveTo(5,6);g.lineTo(5,9);wcSt2(g,1.8)}

 else rrkMitt(g,D,sk);
 g.restore()}
/* the crew hand (wcHand, fingers toward +y), redrawn with batched paths and one-pass shading */
function rrkMitt(g,D,sk){if(D.hand==='bone'){g.beginPath();for(const dx of [-5,0,5]){g.moveTo(dx*.6,0);g.lineTo(dx,10)}g.lineWidth=6;g.strokeStyle=WCO;g.stroke();g.lineWidth=3;g.strokeStyle=sk[0];g.stroke();wcEl(g,0,0,7,6,sk[0],2.4);return}
 if(D.hand==='frog'){rrkEl(g,0,0,8,7,sk[0],2.6,2);for(const dx of [-6,0,6])wcEl(g,dx,8,3.2,3.2,'#ffd06a',2);return}
 rrkEl(g,0,0,9,8,sk[0],2.8,2);g.beginPath();g.moveTo(-8,3);g.lineTo(-11,8);g.lineTo(-4,6);rrkFS(g,sk[0],null,2.2);
 if(D.hand==='claw'){g.beginPath();for(const dx of [-5,0,5]){g.moveTo(dx-2,7);g.lineTo(dx,13);g.lineTo(dx+2,7);g.closePath()}rrkFS(g,'#fff4dc',null,1.6)}}
/* --- props --- */
function rrkRune(g,x,y,s,col,lw){g.save();g.translate(x,y);g.scale(s,s);g.beginPath();g.moveTo(0,-7);g.lineTo(0,7);g.moveTo(0,-5);g.lineTo(5,-1);g.lineTo(0,3);g.moveTo(0,-2);g.lineTo(-5,-6);g.lineWidth=lw||2;g.strokeStyle=col;g.lineCap='round';g.lineJoin='round';g.stroke();g.restore()}
function rrkGlow(g,x,y,r,c,a){const gr=g.createRadialGradient(x,y,0,x,y,r);gr.addColorStop(0,'rgba('+c+','+a+')');gr.addColorStop(1,'rgba('+c+',0)');g.fillStyle=gr;g.beginPath();g.arc(x,y,r,0,Math.PI*2);g.fill()}
/* the open spellbook, spine at x,y (bottom centre); fl = page flutter phase */
function rrkBook(g,x,y,rot,t,fl,glow){g.save();g.translate(x,y);g.rotate(rot);
 g.beginPath();g.moveTo(0,4);g.lineTo(-29,-1);g.lineTo(-30,-33);g.lineTo(0,-27);g.lineTo(30,-33);g.lineTo(29,-1);g.closePath();rrkFS(g,'#4a2a8a',0,3,'rgba(0,0,0,.25)');
 for(const s of [-1,1]){g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(s*12,-6,s*26,-3);g.lineTo(s*27,-30);g.quadraticCurveTo(s*12,-31,0,-25);g.closePath();rrkFS(g,s<0?'#fff4d8':'#ecdcb6',null,2.4)}
 g.beginPath();g.moveTo(0,0);g.lineTo(0,-25);wcSt2(g,2);
 g.beginPath();for(const s of [-1,1])for(let i=0;i<4;i++){if(s<0&&i<3)continue;const yy=-22+i*5;g.moveTo(s*5,yy+1);g.lineTo(s*(i===1?14:21),yy-.4)}g.lineWidth=1.6;g.strokeStyle='rgba(90,50,160,.55)';g.stroke();
 if(glow){rrkGlow(g,-13,-15,14,'180,120,255',.45*glow)}rrkRune(g,-13,-15,.9,'#8a4ae8',2.2);
 for(const s of [-1,1]){g.beginPath();g.moveTo(s*29,-1);g.lineTo(s*24,-1.6);g.lineTo(s*29,-6);g.closePath();g.fillStyle='#ffd45a';g.fill()}
 /* a page lifting and settling */
 const p=Math.sin(fl),w=Math.max(0,p);if(w>.04){g.beginPath();g.moveTo(0,-1);g.quadraticCurveTo(10*w,-12*w-5,24*w*.9,-4-14*w);g.lineTo(26*w*.9,-30-6*w);g.quadraticCurveTo(10*w,-34*w,0,-25);g.closePath();rrkFS(g,'#fffaf0',null,2)}
 g.restore()}
/* a long quill; nib at +fw along ang, feather tip at -bk */
function rrkQuill(g,x,y,ang,fw,bk,vane,ink){g.save();g.translate(x,y);g.rotate(ang);
 g.beginPath();g.moveTo(-bk,0);g.quadraticCurveTo(-bk*.55,-9,-bk*.12,-2.4);g.lineTo(-bk*.12,2.4);g.quadraticCurveTo(-bk*.5,8,-bk,0);g.closePath();rrkFS(g,vane,null,2.4);
 g.beginPath();g.moveTo(-bk*.95,0);g.quadraticCurveTo(-bk*.55,-1.2,-bk*.12,0);for(const f of [.35,.55,.75]){g.moveTo(-bk*f,-1);g.lineTo(-bk*f-6,-5.5)}g.lineWidth=1.3;g.strokeStyle='rgba(18,8,31,.55)';g.stroke();
 g.beginPath();g.moveTo(-bk*.14,0);g.lineTo(fw-6,0);g.lineWidth=5;g.strokeStyle=WCO;g.stroke();g.lineWidth=2.4;g.strokeStyle='#fff4dc';g.stroke();
 g.beginPath();g.moveTo(fw-7,-2.6);g.lineTo(fw,0);g.lineTo(fw-7,2.6);g.closePath();rrkFS(g,ink||'#ffd45a',null,1.8);g.restore()}
/* the scroll: rolled tube in the hand, a sheet hanging below; un = unrolled length */
function rrkScroll(g,x,y,rot,un,t){g.save();g.translate(x,y);g.rotate(rot);const sw=Math.sin(t*1.7)*1.5;
 g.beginPath();g.moveTo(-14,0);g.lineTo(14,0);g.lineTo(14+sw*.3,un);g.quadraticCurveTo(0,un+4,-14+sw*.3,un);g.closePath();rrkFS(g,'#f4e6c4',null,2.6);
 g.beginPath();for(let i=0;i<Math.floor((un-6)/6);i++){const yy=8+i*6;g.moveTo(-9,yy);g.lineTo(i%2?3:7,yy)}g.lineWidth=1.6;g.strokeStyle='rgba(90,50,160,.55)';g.stroke();
 wcEl(g,sw*.3,un+1,15,3.6,'#e8d6aa',2.4);
 g.beginPath();g.roundRect(-16,-5,32,10,5);rrkFS(g,'#efdcb4',null,2.6);g.beginPath();g.ellipse(-18,0,3.4,5.6,0,0,Math.PI*2);g.moveTo(21.4,0);g.ellipse(18,0,3.4,5.6,0,0,Math.PI*2);g.fillStyle='#ffd45a';g.fill();wcSt2(g,2.2);g.restore()}
/* the brass lantern, hanging from a handle held at x,y */
function rrkLantern(g,x,y,sw,t,lit){g.save();g.translate(x,y);g.rotate(sw);const f=.86+Math.sin(t*13.1)*.07+Math.sin(t*7.7+1)*.07;
 if(lit>0){rrkGlow(g,0,30,46*f,'255,190,90',.3*lit)}
 g.beginPath();g.arc(0,4,6,Math.PI,0);g.lineWidth=5;g.strokeStyle=WCO;g.stroke();g.lineWidth=2.4;g.strokeStyle='#e8b24a';g.stroke();
 g.beginPath();g.moveTo(-6,12);g.lineTo(6,12);g.lineTo(10,18);g.lineTo(-10,18);g.closePath();rrkFS(g,'#e0a43c',2,2.6,'rgba(90,40,0,.25)');wcEl(g,0,9,3,3,'#e0a43c',2);
 g.beginPath();g.roundRect(-9,18,18,24,3);g.fillStyle='rgba(255,236,170,.4)';g.fill();
 g.save();g.translate(0,36);g.scale(f,f*1.04);g.beginPath();g.moveTo(0,-14);g.quadraticCurveTo(6,-4,4.4,0);g.quadraticCurveTo(0,4,-4.4,0);g.quadraticCurveTo(-6,-4,0,-14);g.closePath();
 const fg=g.createLinearGradient(0,-14,0,3);fg.addColorStop(0,'#fff6c8');fg.addColorStop(.5,'#ffc23a');fg.addColorStop(1,'#ff7a2a');g.fillStyle=fg;g.fill();wcEl(g,0,-1.5,1.8,3,'#fffbe8',0);g.restore();
 g.beginPath();g.roundRect(-9,18,18,24,3);wcSt2(g,2.6);g.beginPath();g.moveTo(-3,18);g.lineTo(-3,42);g.moveTo(3,18);g.lineTo(3,42);g.lineWidth=1.8;g.strokeStyle='#b07a24';g.stroke();
 g.beginPath();g.moveTo(-11,42);g.lineTo(11,42);g.lineTo(9,48);g.lineTo(-9,48);g.closePath();rrkFS(g,'#e0a43c',2,2.6,'rgba(90,40,0,.25)');wcHi(g,-7,22,-7.5,28,-7,34,1.8);g.restore()}
/* a squat inkpot held at x,y */
function rrkInk(g,x,y,rot,t){g.save();g.translate(x,y);g.rotate(rot);
 g.beginPath();g.moveTo(-6,-14);g.lineTo(6,-14);g.lineTo(7,-10);g.quadraticCurveTo(15,-8,14,2);g.quadraticCurveTo(12,8,0,8);g.quadraticCurveTo(-12,8,-14,2);g.quadraticCurveTo(-15,-8,-7,-10);g.closePath();rrkFS(g,'#3a3a8e',3,2.8,'rgba(0,0,0,.25)');
 g.beginPath();g.moveTo(-12,-2);g.quadraticCurveTo(0,1,12,-2);g.quadraticCurveTo(12,6,0,6.5);g.quadraticCurveTo(-12,6,-12,-2);g.closePath();g.fillStyle='#1a0e3a';g.fill();
 wcEl(g,0,-14,7,2.4,'#ffd45a',2.2);wcHi(g,-9,-5,-10,-1,-8,2,1.8);g.restore()}
/* --- faces --- */
function rrkEye(g,x,y,rx,ry,E,s,sk,kind){
 if(E.happy){g.beginPath();g.moveTo(x-rx,y+2);g.quadraticCurveTo(x,y-ry*1.5,x+rx,y+2);wcSt2(g,3.2);return}
 if(E.blink&&kind!=='glow'){g.beginPath();g.moveTo(x-rx,y);g.quadraticCurveTo(x,y+4,x+rx,y);wcSt2(g,2.8);return}
 if(kind==='glow'){wcEl(g,x,y,rx,ry,'#2a1440',2.6);if(E.blink)return;const px=x+s+E.lx*3,py=y+1+E.ly*3.2;wcEl(g,px,py,2.7,2.7,'#ffd45a',0);g.save();g.globalAlpha=.35;wcEl(g,px,py,5.2,5.2,'#ffd45a',0);g.restore()}
 else if(kind==='slit'){wcEl(g,x,y,rx,ry,E.ec||'#ffd45a',2.6);wcEl(g,x+E.lx*3,y+E.ly*2,1.8,ry-1.1,WCO,0)}
 else if(kind==='frog'){wcEl(g,x,y,rx,ry,'#fffaf0',2.6);wcEl(g,x+E.lx*3,y+1+E.ly*3,5.2,2.6,WCO,0);wcEl(g,x+E.lx*3-2,y-.6+E.ly*3,1,1,'#fff',0)}
 else{wcEl(g,x,y,rx,ry,'#fffaf0',2.4);const px=x+s*1.4+E.lx*3,py=y+1+E.ly*3;wcEl(g,px,py,3.4,3.8,WCO,0);wcEl(g,px-1,py-1.2,1.1,1.1,'#fff',0)}
 if(E.lid>.02&&kind!=='glow'){const top=y-ry-2,ly=y-ry+ry*1.5*E.lid,ti=E.sad?-3:0;g.save();g.beginPath();g.ellipse(x,y,rx,ry,0,0,Math.PI*2);g.clip();
  g.beginPath();g.moveTo(x-rx-2,top);g.lineTo(x+rx+2,top);g.lineTo(x+rx+2,ly+(s<0?ti:-ti));g.lineTo(x-rx-2,ly+(s<0?-ti:ti));g.closePath();g.fillStyle=sk;g.fill();g.restore();
  g.beginPath();g.moveTo(x-rx+1,ly+(s<0?-ti:ti)*.9);g.lineTo(x+rx-1,ly+(s<0?ti:-ti)*.9);wcSt2(g,2.6)}}
/* brows: inner and outer heights for each eye */
function rrkBrows(g,dx,y,E,len,lw){if(E.brow==null)return;for(const s of [-1,1]){const x=s*dx;let bi=0,bo=0;if(E.brow>0){bi=-4*E.brow;bo=-3*E.brow}else if(E.brow<0){bi=-4.5;bo=2.5}
  if(E.one&&s<0){bi-=4;bo-=4}if(E.one&&s>0){bi+=1.5;bo+=.5}g.beginPath();g.moveTo(x-s*len*.5,y+bi);g.quadraticCurveTo(x,y+Math.min(bi,bo)-2,x+s*len*.5,y+bo);wcSt2(g,lw||3.2)}}
function rrkHeadGob(g,A,t,E){const sk=WCSP.goblin.skin,dr=E.ear||0;
 for(const s of [-1,1]){g.beginPath();g.moveTo(s*22,-8);g.quadraticCurveTo(s*48,-20+dr*16,s*64,-8+dr*24);g.quadraticCurveTo(s*46,4+dr*10,s*22,8);g.closePath();rrkFS(g,sk[0],s>0?0:99,3);
  g.beginPath();g.moveTo(s*28,-4);g.quadraticCurveTo(s*44,-10+dr*12,s*54,-6+dr*18);wcSt2(g,2);g.strokeStyle='#ff9ab0';g.lineWidth=2.4;g.stroke()}
 g.beginPath();g.arc(-27,7,4,0,Math.PI*2);g.lineWidth=4.6;g.strokeStyle=WCO;g.stroke();g.lineWidth=2.4;g.strokeStyle='#ffd45a';g.stroke();
 g.beginPath();g.ellipse(0,0,28,26,0,0,Math.PI*2);rrkFS(g,sk[0],6,3.2);
 if(E.m==='laugh'){g.beginPath();g.moveTo(-18,9);g.quadraticCurveTo(0,38,18,9);g.quadraticCurveTo(0,15,-18,9);g.closePath();rrkFS(g,'#3a0a14',null,2.6);g.save();g.clip();wcEl(g,2,25,9,5,'#e85a7a',0);for(const x of [-11,-5,1,7]){g.fillStyle=x===1?'#ffd45a':'#fffaf0';g.fillRect(x,10,4.6,4.6)}g.restore();g.beginPath();g.moveTo(-18,9);g.quadraticCurveTo(0,38,18,9);g.quadraticCurveTo(0,15,-18,9);wcSt2(g,2.6)}
 else if(E.m==='hmm'){g.beginPath();g.moveTo(-8,15);g.quadraticCurveTo(2,12,12,16);wcSt2(g,2.8);g.fillStyle='#fffaf0';g.fillRect(3,14.6,3.6,3);g.beginPath();g.rect(3,14.6,3.6,3);wcSt2(g,1.4)}
 else if(E.m==='frown'){g.beginPath();g.moveTo(-13,21);g.quadraticCurveTo(0,10,13,21);g.quadraticCurveTo(0,15,-13,21);g.closePath();rrkFS(g,'#3a0a14',null,2.6);g.fillStyle='#fffaf0';g.fillRect(-3,14.8,4,3)}
 else{g.beginPath();g.moveTo(-17,11);g.quadraticCurveTo(0,30,17,11);g.quadraticCurveTo(0,17,-17,11);g.closePath();rrkFS(g,'#3a0a14',null,2.6);for(const x of [-10,-4,2,8]){g.fillStyle=x===2?'#ffd45a':'#fffaf0';g.fillRect(x,13.2,4.4,4)}}
 for(const s of [-1,1])rrkEye(g,s*11,-9,7,7.5,E,s,sk[0],'round');rrkBrows(g,11,-20,E,13,3);
 g.beginPath();g.moveTo(-5,-5);g.quadraticCurveTo(0,-9,5,-5);g.quadraticCurveTo(11,10,2,14);g.quadraticCurveTo(-5,13,-5,-5);g.closePath();rrkFS(g,sk[0],1,2.8);
 wcHi(g,-18,-12,-16,-20,-8,-23)}
function rrkHeadDrg(g,A,t,E){const D=WCSP.rrkdrg,sk=D.skin;
 g.beginPath();for(const s of [-1,1]){g.moveTo(s*14,-21);g.quadraticCurveTo(s*38,-26,s*52,-50);g.quadraticCurveTo(s*36,-36,s*8,-28);g.closePath()}rrkFS(g,'#f4e2bc',0,3,'rgba(0,0,0,.14)');
 g.beginPath();for(const s of [-1,1])for(const f of [.45,.7]){g.moveTo(s*(14+f*30),-23-f*14);g.lineTo(s*(12+f*28),-29-f*10)}wcSt2(g,1.4);
 g.beginPath();for(const s of [-1,1]){g.moveTo(s*30,-14);g.lineTo(s*46,-24);g.lineTo(s*40,-8);g.lineTo(s*50,-4);g.lineTo(s*30,4);g.closePath()}rrkFS(g,'#8a5ae8',null,2.6);
 g.beginPath();g.ellipse(0,-4,30,27,0,0,Math.PI*2);rrkFS(g,sk[0],6,3.2,'rgba(120,60,0,.2)');
 g.beginPath();for(const [x,y] of [[-14,-18],[-20,-6],[16,-20],[22,-8]]){g.moveTo(x+Math.cos(Math.PI*.1)*3,y+Math.sin(Math.PI*.1)*3);g.arc(x,y,3,Math.PI*.1,Math.PI*.9)}g.lineWidth=1.3;g.strokeStyle='rgba(140,80,10,.6)';g.stroke();
 wcEl(g,0,13,24,15,D.belly,3);g.beginPath();g.ellipse(-7,9,3,2,0,0,Math.PI*2);g.moveTo(10,9);g.ellipse(7,9,3,2,0,0,Math.PI*2);g.fillStyle=WCO;g.fill();
 if(E.m==='laugh'){g.beginPath();g.moveTo(-14,17);g.quadraticCurveTo(0,34,14,17);g.closePath();rrkFS(g,'#3a0a14',null,2.6);for(const s of [-1,1]){g.beginPath();g.moveTo(s*10,18);g.lineTo(s*8.4,22.5);g.lineTo(s*6.6,18.4);g.closePath();rrkFS(g,'#fff',null,1.4)}g.save();g.beginPath();g.moveTo(-14,17);g.quadraticCurveTo(0,34,14,17);g.closePath();g.clip();wcEl(g,0,28,7,4,'#e85a7a',0);g.restore()}
 else if(E.m==='hmm'){g.beginPath();g.moveTo(-8,21);g.quadraticCurveTo(2,19,12,21);wcSt2(g,2.6)}
 else if(E.m==='frown'){g.beginPath();g.moveTo(-12,24);g.quadraticCurveTo(0,15,12,24);wcSt2(g,2.6)}
 else{g.beginPath();g.moveTo(-13,19);g.quadraticCurveTo(0,26,13,19);wcSt2(g,2.6);g.beginPath();g.moveTo(7,21);g.lineTo(9,27);g.lineTo(11,20.5);g.closePath();rrkFS(g,'#fff',null,1.8)}
 E.ec='#7cf0c8';for(const s of [-1,1])rrkEye(g,s*12,-8,8,6.5,E,s,sk[0],'slit');
 if(E.brow==null)E.brow=0;g.beginPath();for(const s of [-1,1]){let bi=-17,bo=-14;if(E.brow>0){bi-=4*E.brow;bo-=3.5*E.brow}else if(E.brow<0){bi=-21;bo=-12}if(E.one&&s<0){bi-=4;bo-=4}g.moveTo(s*5,bi);g.lineTo(s*20,bo)}wcSt2(g,3.4);
 /* monocle on the right eye */
 g.beginPath();g.arc(12,-8,10.5,0,Math.PI*2);g.fillStyle='rgba(207,239,255,.22)';g.fill();g.lineWidth=5;g.strokeStyle=WCO;g.stroke();g.lineWidth=2.6;g.strokeStyle='#ffd45a';g.stroke();
 wcHi(g,7,-14,9,-16,12,-16.5,1.6);g.beginPath();g.moveTo(21,-3);g.quadraticCurveTo(28,18,20,40);g.lineWidth=1.6;g.strokeStyle='#ffd45a';g.stroke();
 g.beginPath();for(const [x,y,s] of [[0,-31,6],[-11,-28,4.4],[11,-28,4.4]]){g.moveTo(x-s,y+3);g.lineTo(x,y-s);g.lineTo(x+s,y+3);g.closePath()}rrkFS(g,'#8a5ae8',null,2.2);
 wcHi(g,-20,-16,-18,-24,-10,-27)}
function rrkHeadSkel(g,A,t,E){const sk=WCSP.skel.skin;g.beginPath();g.arc(0,-6,27,0,Math.PI*2);rrkFS(g,sk[0],6,3.2);
 const jd=E.m==='laugh'?6:0,jx=E.m==='hmm'?2.5:0;if(jd){g.beginPath();g.ellipse(0,15,11,6,0,0,Math.PI*2);rrkFS(g,'#2a1440',null,2.4)}
 g.beginPath();g.roundRect(-15+jx,10+jd,30,16,6);rrkFS(g,sk[0],6+jx,3);for(const x of [-7.5,0,7.5]){g.beginPath();g.moveTo(x+jx,12+jd);g.lineTo(x+jx,24+jd);wcSt2(g,1.8)}
 g.beginPath();if(E.m==='frown'){g.moveTo(-14,20);g.quadraticCurveTo(0,13,14,20)}else if(E.m==='laugh'||E.m==='grin'){g.moveTo(-14+jx,17+jd);g.quadraticCurveTo(0,21+jd,14+jx,17+jd)}else{g.moveTo(-14+jx,18);g.lineTo(14+jx,18)}wcSt2(g,1.6);
 for(const s of [-1,1])rrkEye(g,s*10,-6,8,9,E,s,sk[0],'glow');
 if(E.happy){for(const s of [-1,1]){g.beginPath();g.moveTo(s*10-4.5,-4);g.quadraticCurveTo(s*10,-11,s*10+4.5,-4);g.lineWidth=2.6;g.strokeStyle='#ffd45a';g.stroke()}}
 if(E.brow!=null&&E.brow!==0){for(const s of [-1,1]){const bi=E.brow<0?-19:-21-2*E.brow,bo=E.brow<0?-13.5:-18-2*E.brow;g.beginPath();g.moveTo(s*4,bi+(E.one&&s<0?-3:0));g.quadraticCurveTo(s*11,Math.min(bi,bo)-2,s*18,bo+(E.one&&s<0?-3:0));wcSt2(g,2.6)}}
 g.beginPath();g.moveTo(0,4);g.lineTo(-4,11);g.lineTo(4,11);g.closePath();rrkFS(g,'#2a1440',null,2);
 g.beginPath();g.moveTo(10,-30);g.lineTo(6,-22);g.lineTo(11,-17);wcSt2(g,1.8);wcHi(g,-18,-16,-16,-26,-6,-30);
 /* half-moon reading glasses perched low */
 for(const s of [-1,1]){const x=s*11,y=0;g.beginPath();g.moveTo(x-8.5,y);g.arc(x,y,8.5,Math.PI,0,true);g.closePath();g.save();g.globalAlpha=.28;g.fillStyle='#d8f0ff';g.fill();g.restore();g.lineWidth=4.6;g.strokeStyle=WCO;g.stroke();g.lineWidth=2.2;g.strokeStyle='#ffd45a';g.stroke();
  g.beginPath();g.moveTo(s*19.5,0);g.lineTo(s*26.5,-5);g.lineWidth=4.2;g.strokeStyle=WCO;g.stroke();g.lineWidth=2;g.strokeStyle='#ffd45a';g.stroke()}
 g.beginPath();g.moveTo(-2.5,0);g.quadraticCurveTo(0,-3,2.5,0);g.lineWidth=4.2;g.strokeStyle=WCO;g.stroke();g.lineWidth=2;g.strokeStyle='#ffd45a';g.stroke();wcHi(g,-16,3,-14,5.5,-11,6,1.4)}
function rrkHeadOct(g,A,t,E){const sk=WCSP.octo.skin;g.beginPath();g.ellipse(0,-12,28,34,0,0,Math.PI*2);rrkFS(g,sk[0],6,3.2);
 g.beginPath();for(const [x,y,r] of [[-12,-30,4],[8,-36,3],[16,-22,3.4],[-18,-12,2.6]]){g.moveTo(x+r,y);g.arc(x,y,r,0,Math.PI*2)}g.fillStyle='#d89aff';g.fill();
 g.save();g.globalAlpha=.85;g.beginPath();g.moveTo(-23,8);g.quadraticCurveTo(-19,2,-14,7);g.quadraticCurveTo(-12,12,-17,13);g.quadraticCurveTo(-23,14,-23,8);g.fillStyle='#24104a';g.fill();g.restore();wcEl(g,-12.5,12.5,1.3,1.3,'#24104a',0);
 for(const s of [-1,1])rrkEye(g,s*11,-2,9,9,E,s,sk[0],'frog');rrkBrows(g,11,-15,E,12,3);
 if(E.m==='laugh'){g.beginPath();g.moveTo(-9,11);g.quadraticCurveTo(0,26,9,11);g.closePath();rrkFS(g,'#5a1a6a',null,2.4)}
 else if(E.m==='frown'){g.beginPath();g.moveTo(-7,18);g.quadraticCurveTo(0,11,7,18);wcSt2(g,2.6)}
 else if(E.m==='hmm'){g.beginPath();g.ellipse(2,15,3,2.4,0,0,Math.PI*2);rrkFS(g,'#5a1a6a',null,2.2)}
 else{g.beginPath();g.moveTo(-7,12);g.quadraticCurveTo(0,20,7,12);g.quadraticCurveTo(0,15,-7,12);g.closePath();rrkFS(g,'#5a1a6a',null,2.4)}
 /* pince-nez */
 for(const s of [-1,1]){g.beginPath();g.arc(s*11,-2,11.2,0,Math.PI*2);g.lineWidth=4.4;g.strokeStyle=WCO;g.stroke();g.lineWidth=2.1;g.strokeStyle='#ffd45a';g.stroke()}
 g.beginPath();g.moveTo(-2,-5);g.quadraticCurveTo(0,-9,2,-5);g.lineWidth=4;g.strokeStyle=WCO;g.stroke();g.lineWidth=1.9;g.strokeStyle='#ffd45a';g.stroke();
 g.beginPath();g.moveTo(-22,1);g.quadraticCurveTo(-30,22,-22,40);g.lineWidth=1.5;g.strokeStyle='#ffd45a';g.stroke();
 wcHi(g,-20,-24,-16,-36,-6,-42)}
/* --- hats (head coordinates, crown at y=top) --- */
function rrkHat(g,A,top,t,hr){g.save();g.translate(0,top);
 if(A.hat==='bowler'){g.rotate(-.05);g.beginPath();g.moveTo(-20,0);g.bezierCurveTo(-21,-30,21,-30,20,0);g.closePath();rrkFS(g,'#1d1a22',4,3,'rgba(0,0,0,.3)');g.beginPath();g.rect(-20.5,-7,41,5.5);rrkFS(g,'#0e0c12',null,2);
  rrkEl(g,0,0,31,5.6,'#1a171e',2.8,8,'rgba(0,0,0,.3)');wcHi(g,-13,-12,-11,-18,-5,-20,2.2)}
 else if(A.hat==='mortar'){const sw=Math.sin(t*1.9+A.seed)*2.4-hr*30;g.beginPath();g.moveTo(-21,3);g.bezierCurveTo(-22,-14,22,-14,21,3);g.closePath();rrkFS(g,'#24184e',4,3);
  g.beginPath();  g.beginPath();g.moveTo(-31,-12);g.lineTo(0,-2);g.lineTo(31,-12);g.lineTo(31,-8);g.lineTo(0,2);g.lineTo(-31,-8);g.closePath();rrkFS(g,'#1c1238',null,2.6);
  g.beginPath();g.moveTo(-31,-12);g.lineTo(0,-22);g.lineTo(31,-12);g.lineTo(0,-2);g.closePath();rrkFS(g,'#3a2a7a',8,3,'rgba(0,0,0,.18)');
  wcHi(g,-19,-13,-11,-16.5,-4,-19,2);g.beginPath();g.moveTo(0,-12);g.quadraticCurveTo(16,-14,26,-10);g.quadraticCurveTo(28+sw*.3,2,27+sw,12);g.lineWidth=4.2;g.strokeStyle=WCO;g.stroke();g.lineWidth=2;g.strokeStyle='#ffd45a';g.stroke();
  g.beginPath();g.moveTo(27+sw,10);g.lineTo(23+sw*1.1,24);g.lineTo(31+sw*1.1,24);g.closePath();g.moveTo(30+sw,10);g.ellipse(27+sw,10,3,2.4,0,0,Math.PI*2);g.moveTo(3.6,-12);g.ellipse(0,-12,3.6,2.4,0,0,Math.PI*2);g.fillStyle='#ffd45a';g.fill();wcSt2(g,2)}
 else if(A.hat==='tam'){g.rotate(-.16);
  rrkTamQuill(g,t,A);g.beginPath();g.ellipse(5,-10,31,12,0,Math.PI,0);g.quadraticCurveTo(34,0,22,-1);g.lineTo(-14,-1);g.quadraticCurveTo(-30,0,-26,-10);g.closePath();rrkFS(g,'#8a1c3c',10,3,'rgba(0,0,0,.25)');
  g.beginPath();g.roundRect(-17,-3,40,7,3.5);rrkFS(g,'#5a0e26',null,2.4);wcEl(g,5,-22,3.6,2.8,'#ffd45a',2);wcHi(g,-14,-12,-6,-18,4,-19,2.2)}
 g.restore()}
function rrkTamQuill(g,t,A){rrkQuill(g,20,-6,2.02+Math.sin(t*1.6+A.seed)*.05,2,46,'#f4f0ff')}
/* --- poses: [elbow x, elbow y, wrist x, wrist y, hand angle] per arm, body coordinates --- */
const RRKP={
 idle:{L:[-60,-118,-46,-100,-1.9],R:[57,-116,57,-90,1.5]},
 point:{L:[-60,-118,-46,-100,-1.9],R:[76,-126,90,-166,-.95]},
 cheer:{L:[-72,-166,-88,-204,-2.0],R:[72,-166,88,-206,-1.15]},
 think:{L:[-60,-118,-46,-100,-1.9],R:[54,-110,26,-142,-1.95]},
 sad:{L:[-50,-112,-50,-84,1.7],R:[50,-112,52,-84,1.45]}};
const RRKPX={
 drg:{idle:{L:[-62,-116,-50,-102,-1.7],R:[58,-118,58,-98,-1.6]},think:{L:[-62,-116,-50,-102,-1.7]},point:{L:[-62,-116,-50,-102,-1.7],R:[72,-130,86,-160,-.75]},sad:{R:[52,-112,56,-86,1.4]}},
 skel:{idle:{L:[-56,-114,-58,-88,1.6],R:[56,-116,56,-90,1.5]},point:{L:[-56,-114,-58,-88,1.6]},think:{L:[-56,-114,-58,-88,1.6]},sad:{L:[-50,-112,-52,-84,1.6]}},
 oct:{idle:{L:[-66,-120,-60,-98,-1.6],R:[68,-112,64,-122,-.4]},point:{L:[-66,-120,-60,-98,-1.6],R:[78,-122,88,-158,-.7]},think:{L:[-66,-120,-60,-98,-1.6],R:[58,-104,22,-146,-1.4]},
  cheer:{L:[-70,-164,-62,-196,-1.7],R:[70,-164,64,-198,-1.4]},sad:{L:[-58,-110,-56,-84,1.6],R:[58,-110,58,-84,1.5]}}};
function rrkArm(A,mode,side){const X=RRKPX[A.id]||{},b=(X.idle&&X.idle[side])||RRKP.idle[side],m=(X[mode]&&X[mode][side])||(RRKP[mode]||RRKP.idle)[side];return [b,m]}
/* --- the figure --- */
function rrkDraw(g,A,t,st){st=st||{};const mode=RRKP[st.mode]?st.mode:'idle',k0=st.k==null?1:Math.max(0,Math.min(1,+st.k||0)),k=mode==='idle'?0:rrkEase(k0),id=A.id,sp=A.sp,sk=WCSP[sp].skin,octo=sp==='octo';
 const b=Math.sin(t*2.2+A.seed)*1.3,hop=mode==='cheer'?Math.abs(Math.sin(k0*Math.PI*2))*14*(1-k0*.25):0,slump=mode==='sad'?k:0;
 const pose=side=>{const [i,m]=rrkArm(A,mode,side);let p=rrkMix(i,m,k);
  if(mode==='think'&&side==='R'){const tp=Math.sin(t*5.2)*1.3*k;p[3]+=tp;p[2]+=tp*.3}
  if(mode==='cheer'){const w=Math.sin(t*6+(side==='L'?0:1.5))*2.2*k;p[2]+=w;p[0]+=w*.4}
  if(mode==='idle'||k<1){const w=Math.sin(t*2.4+A.seed+(side==='L'?0:2))*1.2*(1-k);p[3]+=w;p[1]+=w*.5}
  return p};
 const L=pose('L'),R=pose('R'),SL=[-40,-142+slump*4],SR=[40,-142+slump*4];
 /* expression */
 const blink=((t+A.seed*.37)%4.1)<.14,E={blink,lx:Math.sin(t*.7+A.seed)*.25,ly:0,lid:0,happy:0,m:'grin',brow:id==='drg'?0:null,ear:0};
 if(mode==='point'){E.lx=rrkMix([E.lx],[1],k)[0];E.ly=-.25*k;if(k>.3)E.brow=1*k}
 else if(mode==='cheer'){if(k>.25){E.happy=1;E.m='laugh';E.brow=1}}
 else if(mode==='think'){E.lx=-.7*k+Math.sin(t*.9)*.2*k;E.ly=-.95*k;E.lid=.12*k;if(k>.35){E.m='hmm';E.brow=1;E.one=1}}
 else if(mode==='sad'){E.ly=.6*k;E.lx*=1-k;E.lid=.42*k;E.sad=1;E.ear=k;if(k>.3){E.m='frown';E.brow=-1}}
 const hx=(mode==='point'?3*k:mode==='think'?-2*k:0),hy=slump*7-(mode==='cheer'?2*k:0),hr=Math.sin(t*1.3+A.seed)*.035+(mode==='point'?.07*k:mode==='think'?(-.1+Math.sin(t*1.1)*.025)*k:mode==='sad'?-.07*k:mode==='cheer'?Math.sin(t*5)*.05*k:0);
 g.save();g.lineJoin='round';g.lineCap='round';
 g.save();g.globalAlpha=.28*(1-hop/40);wcEl(g,0,-2,44*(1-hop/60),9*(1-hop/60),'#000',0);g.restore();
 g.translate(0,-hop);
 /* behind: dragon wings and tail, octopus legs */
 if(id==='drg'){const wf=Math.sin(t*1.6+A.seed)*.05+(mode==='cheer'?.12*k:0)-slump*.12;const WT=[-1,1].map(s=>{const c=Math.cos(s*-wf),n=Math.sin(s*-wf),ox=s*30,oy=-138+b+slump*4;return (x,y)=>[ox+s*x*c-y*n,oy+s*x*n+y*c]}),M=(T,x,y)=>{const q=T(x,y);g.moveTo(q[0],q[1])},Ln=(T,x,y)=>{const q=T(x,y);g.lineTo(q[0],q[1])},Q=(T,a,b2,x,y)=>{const c=T(a,b2),q=T(x,y);g.quadraticCurveTo(c[0],c[1],q[0],q[1])};
  g.beginPath();for(const T of WT){M(T,0,0);Ln(T,48,-58);Ln(T,54,-12);Q(T,42,-2,40,18);Q(T,28,14,20,34);g.closePath()}rrkFS(g,'#c9871f',null,3);
  g.beginPath();for(const T of WT){M(T,4,2);Ln(T,44,-50);M(T,10,6);Ln(T,42,4)}g.lineWidth=2;g.strokeStyle='rgba(90,40,0,.4)';g.stroke();
  g.beginPath();for(const T of WT){const q=T(48,-58);g.moveTo(q[0]+3.4,q[1]);g.arc(q[0],q[1],3.4,0,Math.PI*2)}g.fillStyle='#f4e2bc';g.fill();wcSt2(g,2);
  const sw=Math.sin(t*1.5+A.seed)*5;g.beginPath();g.moveTo(8,-58);g.bezierCurveTo(48,-44,76+sw,-30,72+sw,-74);g.lineWidth=15;g.strokeStyle=WCO;g.stroke();g.lineWidth=9;g.strokeStyle=sk[0];g.stroke();
  g.beginPath();g.moveTo(72+sw,-92);g.lineTo(84+sw,-72);g.lineTo(72+sw,-76);g.lineTo(60+sw,-72);g.closePath();rrkFS(g,'#8a5ae8',null,2.8)}
 if(octo)for(const [x0,x1,cx] of [[-22,-44,-40],[-8,-18,-22],[8,18,22],[22,44,40]]){const tp=Math.sin(t*2+x0)*3;g.beginPath();g.moveTo(x0,-74);g.bezierCurveTo(cx,-40,x1-Math.sign(x1)*12,-6,x1+tp,-10);g.quadraticCurveTo(x1+Math.sign(x1)*8+tp,-18,x1+Math.sign(x1)*2+tp,-22);
  g.lineWidth=17;g.strokeStyle=WCO;g.stroke();g.lineWidth=11;g.strokeStyle=sk[0];g.stroke();g.beginPath();for(const q of [.35,.6,.82]){const x=x0+(x1-x0)*q+Math.sign(x1)*3,y=-74+64*q;g.moveTo(x+2.2,y);g.arc(x,y,2.2,0,Math.PI*2)}g.fillStyle='#d89aff';g.fill();}
 else{g.beginPath();for(const s of [-1,1]){g.moveTo(s*3,-82);g.lineTo(s*27,-82);g.lineTo(s*24,-13);g.lineTo(s*6,-13);g.closePath()}rrkFS(g,A.pants,null,3);
  g.beginPath();for(const s of [-1,1]){g.moveTo(s*5,-12);g.quadraticCurveTo(s*6,-20,s*16,-20);g.quadraticCurveTo(s*30,-20,s*31,-6);g.quadraticCurveTo(s*18,-1,s*5,-3);g.closePath()}rrkFS(g,A.shoe,null,2.8);
  g.beginPath();for(const s of [-1,1]){g.moveTo(s*12,-14);g.quadraticCurveTo(s*16,-17,s*22,-15)}g.lineWidth=2;g.strokeStyle='rgba(255,255,255,.75)';g.stroke()}
 g.save();g.translate(0,b+slump*3);
 rrkTorso(g,A,t,slump);
 /* arms behind the head */
 const front=mode==='think'&&k>.5;rrkLimb(g,A,'L',SL,L,t,mode,k);if(!front)rrkLimb(g,A,'R',SR,R,t,mode,k);
 /* neck and head */
 if(!octo){g.beginPath();g.rect(-8,-166+slump*2,16,14);rrkFS(g,sk[0],null,2.6)}
 g.save();g.translate(hx,WCHY(A)+hy);g.rotate(hr);g.scale(WCHS,WCHS);
 if(id==='gob')rrkHeadGob(g,A,t,E);else if(id==='drg')rrkHeadDrg(g,A,t,E);else if(id==='skel')rrkHeadSkel(g,A,t,E);else rrkHeadOct(g,A,t,E);
 rrkHat(g,A,id==='oct'?-42:id==='drg'?-27:-25,t,hr);g.restore();
 if(front)rrkLimb(g,A,'R',SR,R,t,mode,k);
 if(mode==='think'&&k>.5)rrkBubbles(g,t,k);
 if(mode==='cheer'&&k>.2)rrkSparks(g,t,k0);
 g.restore();g.restore()}
function rrkBubbles(g,t,k){for(let i=0;i<3;i++){const p=(t*.8+i/3)%1,a=Math.sin(p*Math.PI)*k;if(a<.05)continue;g.save();g.globalAlpha=a;const x=-44-i*9-p*6,y=-236-i*13-p*8;wcEl(g,x,y,3+i*2.2,3+i*2.2,'#efe6ff',2);g.restore()}
 const a=(Math.sin(t*2)*.25+.75)*k;g.save();g.globalAlpha=a;rrkGlow(g,-86,-290,16,'170,110,255',.5);rrkRune(g,-86,-290,1.25,'#c8a0ff',2.6);g.restore()}
function rrkSparks(g,t,k0){for(const [x,y,ph] of [[-86,-232,0],[84,-238,1.7],[-30,-282,3.1],[44,-276,4.4]]){const a=Math.max(0,Math.sin(t*3+ph))*Math.min(1,k0*2);if(a<.05)continue;g.save();g.translate(x,y);g.rotate(t*.6+ph);g.scale(.55+a*.45,.55+a*.45);g.globalAlpha=a;
 g.beginPath();g.moveTo(0,-9);g.lineTo(2.2,-2.2);g.lineTo(9,0);g.lineTo(2.2,2.2);g.lineTo(0,9);g.lineTo(-2.2,2.2);g.lineTo(-9,0);g.lineTo(-2.2,-2.2);g.closePath();g.fillStyle='#ffe38a';g.fill();g.lineWidth=1.4;g.strokeStyle='#b07a24';g.stroke();g.restore()}}
/* --- clothes --- */
function rrkJacketPath(g){g.beginPath();g.moveTo(-16,-154);g.quadraticCurveTo(-40,-152,-46,-138);g.quadraticCurveTo(-46,-108,-36,-80);g.lineTo(-33,-68);g.quadraticCurveTo(0,-62,33,-68);g.lineTo(36,-80);g.quadraticCurveTo(46,-108,46,-138);g.quadraticCurveTo(40,-152,16,-154);g.closePath()}
function rrkBow(g,c,y){g.beginPath();g.moveTo(0,y);g.lineTo(-12,y-7);g.lineTo(-12,y+7);g.closePath();g.moveTo(0,y);g.lineTo(12,y-7);g.lineTo(12,y+7);g.closePath();rrkFS(g,c,null,2.4);wcEl(g,0,y,3.4,3.4,c,2)}
function rrkTorso(g,A,t,sl){const id=A.id;
 if(id==='gob'){rrkJacketPath(g);rrkFS(g,A.suit,4,3.2,'rgba(0,0,0,.28)');
  g.beginPath();g.moveTo(-15,-155);g.lineTo(15,-155);g.lineTo(0,-104);g.closePath();rrkFS(g,'#fffaf0',null,2.6);
  g.beginPath();g.moveTo(-12,-153);g.quadraticCurveTo(-4,-130,0,-128);g.quadraticCurveTo(4,-130,12,-153);g.lineWidth=4.4;g.strokeStyle=WCO;g.stroke();g.lineWidth=2.2;g.strokeStyle='#ffd45a';g.setLineDash([3,2]);g.stroke();g.setLineDash([]);
  rrkBow(g,A.tie,-148);
  for(const s of [-1,1]){g.beginPath();g.moveTo(s*15,-155);g.lineTo(s*3,-106);g.lineTo(s*15,-122);g.lineTo(s*25,-126);g.lineTo(s*21,-150);g.closePath();rrkFS(g,A.suit2,null,2.6)}
  rrkEl(g,0,-121,7.4,7.4,'#ffd45a',2.4,2,'rgba(150,80,0,.25)');rrkRune(g,0,-121,.62,'#8a5a10',1.8);wcHi(g,-4,-124,-3.6,-126,-2,-127,1.4);
  rrkDots(g,[[0,-96],[0,-84]],2.6,'#ffd45a',1.6);
  g.beginPath();g.moveTo(20,-133);g.lineTo(24,-140);g.lineTo(28,-134);g.lineTo(32,-139);g.lineTo(33,-131);g.closePath();rrkFS(g,A.tie,null,1.8);g.beginPath();g.moveTo(18,-131);g.lineTo(35,-131);wcSt2(g,2);
  g.beginPath();g.moveTo(-30,-84);g.lineTo(-14,-84);g.moveTo(14,-84);g.lineTo(30,-84);wcSt2(g,2)}
 else if(id==='drg'){/* academic gown over a waistcoat */
  g.beginPath();g.moveTo(-16,-156);g.quadraticCurveTo(-42,-154,-48,-138);g.quadraticCurveTo(-52,-80,-60,-30);g.quadraticCurveTo(0,-20,60,-30);g.quadraticCurveTo(52,-80,48,-138);g.quadraticCurveTo(42,-154,16,-156);g.closePath();rrkFS(g,A.robe,6,3.2,'rgba(0,0,0,.28)');
  g.beginPath();g.moveTo(-15,-156);g.lineTo(15,-156);g.lineTo(19,-25);g.quadraticCurveTo(0,-22,-19,-25);g.closePath();rrkFS(g,A.pants,null,0);
  g.beginPath();g.moveTo(-15,-154);g.lineTo(15,-154);g.lineTo(18,-82);g.lineTo(9,-72);g.lineTo(0,-79);g.lineTo(-9,-72);g.lineTo(-18,-82);g.closePath();rrkFS(g,A.vest,2,2.8,'rgba(0,0,0,.25)');
  g.beginPath();g.moveTo(-10,-156);g.lineTo(10,-156);g.lineTo(0,-128);g.closePath();rrkFS(g,'#fffaf0',null,2.4);rrkBow(g,A.tie,-149);
  rrkDots(g,[[0,-120],[0,-106],[0,-92]],2.4,'#ffd45a',1.6);
  g.beginPath();g.moveTo(-14,-110);g.quadraticCurveTo(-6,-98,0,-106);g.lineWidth=4;g.strokeStyle=WCO;g.stroke();g.lineWidth=2;g.strokeStyle='#ffd45a';g.setLineDash([2.6,1.8]);g.stroke();g.setLineDash([]);wcEl(g,-14,-108,3.6,3.6,'#ffd45a',1.8);
  g.beginPath();for(const s of [-1,1]){g.moveTo(s*14,-157);g.quadraticCurveTo(s*26,-158,s*30,-150);g.lineTo(s*30,-26);g.quadraticCurveTo(s*24,-25,s*18,-25);g.closePath()}rrkFS(g,A.facing,22,2.8,'rgba(0,0,0,.22)');
  g.beginPath();g.moveTo(-24,-150);g.lineTo(-24.5,-28);g.moveTo(24,-150);g.lineTo(24.5,-28);g.moveTo(-58,-31);g.quadraticCurveTo(0,-20,58,-31);g.lineWidth=2;g.strokeStyle='#ffd45a';g.stroke()}
 else if(id==='skel'){/* rolled-sleeve shirt and a tweed waistcoat */
  rrkJacketPath(g);rrkFS(g,A.shirt,4,3.2,'rgba(80,60,30,.14)');
  for(const s of [-1,1]){g.beginPath();g.moveTo(s*2,-156);g.lineTo(s*15,-156);g.lineTo(s*11,-143);g.closePath();rrkFS(g,A.shirt,null,2.4)}
  g.beginPath();g.moveTo(-12,-152);g.lineTo(-34,-146);g.quadraticCurveTo(-40,-112,-36,-76);g.lineTo(-34,-66);g.lineTo(-4,-60);g.lineTo(0,-66);g.lineTo(4,-60);g.lineTo(34,-66);g.lineTo(36,-76);g.quadraticCurveTo(40,-112,34,-146);g.lineTo(12,-152);g.lineTo(0,-110);g.closePath();rrkFS(g,A.suit,4,3,'rgba(0,0,0,.25)');
  g.beginPath();for(const [x,y] of [[-24,-136],[-18,-118],[-28,-96],[20,-128],[26,-104],[-14,-80],[18,-84]]){g.moveTo(x+1.2,y);g.arc(x,y,1.2,0,Math.PI*2)}g.fillStyle='rgba(255,255,255,.18)';g.fill();
  g.beginPath();g.moveTo(-30,-90);g.lineTo(-18,-90);g.moveTo(30,-90);g.lineTo(18,-90);wcSt2(g,2);
  rrkDots(g,[[0,-102],[0,-90],[0,-78]],2.4,'#ffd45a',1.6);
  g.beginPath();g.moveTo(-24,-91);g.quadraticCurveTo(-12,-80,-1,-90);g.lineWidth=4;g.strokeStyle=WCO;g.stroke();g.lineWidth=2;g.strokeStyle='#ffd45a';g.setLineDash([2.6,1.8]);g.stroke();g.setLineDash([]);
  rrkBow(g,A.tie,-149)}
 else{/* octopus scribe: indigo coat and an ink-stained tabard */
  rrkJacketPath(g);rrkFS(g,A.suit,4,3.2,'rgba(0,0,0,.25)');
  for(const s of [-1,1]){g.beginPath();g.moveTo(s*2,-157);g.lineTo(s*16,-157);g.lineTo(s*12,-144);g.closePath();rrkFS(g,'#fffaf0',null,2.4)}
  g.beginPath();g.moveTo(-17,-150);g.lineTo(17,-150);g.lineTo(20,-118);g.quadraticCurveTo(31,-112,31,-100);g.lineTo(31,-58);g.quadraticCurveTo(0,-50,-31,-58);g.lineTo(-31,-100);g.quadraticCurveTo(-31,-112,-20,-118);g.closePath();rrkFS(g,A.apron,6,3,'rgba(120,80,20,.16)');
  g.beginPath();g.moveTo(-24,-114);g.lineTo(-40,-112);g.moveTo(24,-114);g.lineTo(40,-112);wcSt2(g,3);
  g.save();g.beginPath();g.moveTo(-17,-150);g.lineTo(17,-150);g.lineTo(20,-118);g.quadraticCurveTo(31,-112,31,-100);g.lineTo(31,-58);g.quadraticCurveTo(0,-50,-31,-58);g.lineTo(-31,-100);g.quadraticCurveTo(-31,-112,-20,-118);g.closePath();g.clip();
  g.fillStyle='#2a1a5e';g.beginPath();for(const [x,y,r] of [[-14,-132,4.4],[-20,-76,5],[14,-66,3.6],[22,-120,2.4],[-6,-104,2]])for(const [ox,oy,rr] of [[0,0,1],[.9,.6,.4],[-.7,-.8,.32]]){g.moveTo(x+ox*r+rr*r,y+oy*r);g.arc(x+ox*r,y+oy*r,rr*r,0,Math.PI*2)}g.fill();
  g.fillRect(-15.1,-132,1.8,12);wcEl(g,-14.2,-119.5,1.6,1.8,'#2a1a5e',0);g.restore();
  rrkPocketQuills(g,t);g.beginPath();g.roundRect(-2,-100,22,18,3);rrkFS(g,'#e2d0a6',null,2.4);g.beginPath();g.moveTo(-2,-95);g.lineTo(20,-95);g.lineWidth=1.4;g.strokeStyle='rgba(18,8,31,.5)';g.stroke();
  rrkBow(g,A.tie,-150)}}
function rrkPocketQuills(g,t){rrkQuill(g,4,-92,1.8,6,30,'#c8f0ff','#2a1a5e');rrkQuill(g,13,-92,1.32,6,26,'#ffd0e8','#2a1a5e')}
/* one arm with its hand and prop; P=[ex,ey,wx,wy,ang] */
function rrkLimb(g,A,side,S,P,t,mode,k){const id=A.id,E=[P[0],P[1]],W=[P[2],P[3]],ang=P[4],sk=WCSP[A.sp].skin,fa=Math.atan2(W[1]-E[1],W[0]-E[0]);
 const handKind=side==='R'&&(mode==='point'||mode==='think')&&k>.4&&(id==='gob'||id==='skel')?'point':side==='R'&&mode==='cheer'&&k>.3&&id!=='drg'&&id!=='oct'?'fist':'grip';
 const prop=()=>rrkProp(g,A,side,W,ang,mode,k,t);
 if(id==='oct'){const L=side==='L';
  const tw=()=>{g.beginPath();g.moveTo(S[0],S[1]+4);g.quadraticCurveTo(E[0],E[1],W[0],W[1]);const cx=W[0]+Math.cos(ang)*8,cy=W[1]+Math.sin(ang)*8;g.quadraticCurveTo(cx+Math.cos(ang+1.6)*4,cy+Math.sin(ang+1.6)*4,cx+Math.cos(ang+2.4)*5,cy+Math.sin(ang+2.4)*5);
   g.lineWidth=17;g.strokeStyle=WCO;g.stroke();g.lineWidth=11;g.strokeStyle=sk[0];g.stroke();for(const q of [.4,.7]){const x=(1-q)*(1-q)*S[0]+2*q*(1-q)*E[0]+q*q*W[0],y=(1-q)*(1-q)*(S[1]+4)+2*q*(1-q)*E[1]+q*q*W[1];wcEl(g,x,y+3,2.2,2.2,'#d89aff',0)}};
  tw();prop();return}
 if(id==='skel'){rrkSleeve(g,S,[(S[0]*2+E[0])/3,(S[1]*2+E[1])/3],E,10.5,9,A.shirt,'rgba(80,60,30,.16)');
  const ua=Math.atan2(E[1]-S[1],E[0]-S[0]);g.save();g.translate((S[0]+E[0])/2,(S[1]+E[1])/2);g.rotate(ua);g.beginPath();g.rect(-2.2,-10,4.4,20);rrkFS(g,'#ffd45a',null,2);g.restore();
  g.save();g.translate(E[0],E[1]);g.rotate(ua);g.beginPath();g.roundRect(-4.5,-11,9,22,4);rrkFS(g,A.shirt,1,2.6,'rgba(80,60,30,.2)');g.beginPath();g.moveTo(0,-9.5);g.lineTo(0,9.5);g.lineWidth=1.4;g.strokeStyle='rgba(18,8,31,.4)';g.stroke();g.restore();
  const n=[-(W[1]-E[1]),W[0]-E[0]],nl=Math.hypot(n[0],n[1])||1;for(const o of [-2.6,2.6])rrkSeg(g,E[0]+n[0]/nl*o+(W[0]-E[0])*.12,E[1]+n[1]/nl*o+(W[1]-E[1])*.12,W[0]+n[0]/nl*o*.6,W[1]+n[1]/nl*o*.6,2.6,sk[0]);
  if(side==='L')prop();rrkHand(g,A,W[0]+Math.cos(ang)*2,W[1]+Math.sin(ang)*2,ang,handKind);if(side==='R')prop();return}
 if(id==='drg'){rrkSleeve(g,S,E,W,12,15,A.robe,'rgba(0,0,0,.28)');const ua=Math.atan2(E[1]-S[1],E[0]-S[0]);
  {const ux=Math.cos(ua),uy=Math.sin(ua);g.beginPath();for(const f of [.32,.48,.64]){const x=S[0]+(E[0]-S[0])*f,y=S[1]+(E[1]-S[1])*f;g.moveTo(x+uy*9.5,y-ux*9.5);g.lineTo(x-uy*9.5,y+ux*9.5)}g.lineCap='butt';g.lineWidth=6.6;g.strokeStyle=WCO;g.stroke();g.lineWidth=3.6;g.strokeStyle=A.facing;g.stroke();g.lineCap='round'}
  g.save();g.translate(W[0],W[1]);g.rotate(fa);g.beginPath();g.rect(-5,-15,6,30);rrkFS(g,'#ffd45a',null,2.4,'rgba(150,80,0,.25)');g.restore();
  const hx=W[0]+Math.cos(fa)*4,hy=W[1]+Math.sin(fa)*4;if(side==='L'){prop();rrkHand(g,A,hx,hy,ang,handKind)}else{prop();rrkHand(g,A,hx,hy,ang,handKind)}return}
 /* goblin: the suit sleeve with a shirt cuff */
 rrkSleeve(g,S,E,W,11,8.5,A.suit,'rgba(0,0,0,.28)');rrkCuff(g,E,W,8,'#fffaf0',6);
 const hx=W[0]+Math.cos(fa)*4,hy=W[1]+Math.sin(fa)*4;prop();rrkHand(g,A,hx,hy,ang,handKind)}
/* props per keeper and side */
function rrkProp(g,A,side,W,ang,mode,k,t){const id=A.id;
 if(id==='gob'&&side==='L'){const up=mode==='cheer'?k:0,sd=mode==='sad'?k:0;rrkBook(g,W[0]+2-up*2,W[1]-6-up*4+sd*2,-.12+up*.3+sd*.55,t,t*2.1+A.seed,mode==='cheer'||mode==='point'?k:0)}
 else if(id==='drg'&&side==='L'){const up=mode==='cheer'?k:0,sd=mode==='sad'?k:0;rrkScroll(g,W[0],W[1]-2,-.08+up*.25+sd*.3,40+up*14-sd*8,t)}
 else if(id==='drg'&&side==='R'){const bob=Math.sin(t*2.6+A.seed)*.05;let a=Math.PI/2+.25+bob,fw=12,bk=74;
  if(mode==='point'){a=a+(-.75-a)*k;fw=12+20*k;bk=74-26*k}else if(mode==='cheer'){a=a+(Math.PI/2+.45-a)*k}else if(mode==='think'){a=a+(2.3-a)*k;fw=12-4*k;bk=74-14*k}else if(mode==='sad'){a=a+(Math.PI/2-.2-a)*k}
  rrkQuill(g,W[0]+Math.cos(ang)*6,W[1]+Math.sin(ang)*6,a,fw,bk,'#fff4f8')}
 else if(id==='skel'&&side==='L'){const sw=Math.sin(t*1.8+A.seed)*.07*(mode==='cheer'?2:1);rrkLantern(g,W[0]+Math.cos(ang)*8,W[1]+Math.sin(ang)*8-4,mode==='cheer'?sw+.2*k:sw,t,mode==='sad'?1-.5*k:1)}
 else if(id==='oct'&&side==='L'){rrkInk(g,W[0]+Math.cos(ang)*4,W[1]+Math.sin(ang)*4,mode==='sad'?.5*k:mode==='cheer'?-.2*k:0,t)}
 else if(id==='oct'&&side==='R'){const bob=Math.sin(t*3.1+A.seed)*.12;let a=2.3+bob,fw=10,bk=46;if(mode==='point'){a=a+(-.7-a)*k;fw=10+22*k;bk=46-6*k}else if(mode==='cheer'){a=a+(1.9-a)*k}else if(mode==='think'){a=a+(2.6-a)*k}else if(mode==='sad'){a=a+(1.4-a)*k}
  rrkQuill(g,W[0],W[1],a,fw,bk,'#c8f0ff','#2a1a5e')}}
/* round portrait: gold ring on a deep purple disc */
function rrkPortrait(cv,A,t){const g=cv.getContext('2d'),w=cv.width,h=cv.height,r=Math.min(w,h)/2,cx=w/2,cy=h/2,lw=Math.max(3,r*.085);g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,w,h);
 const ri=r-lw*1.15,bg=g.createRadialGradient(cx,cy-ri*.3,ri*.1,cx,cy,ri);bg.addColorStop(0,'#4a2c8e');bg.addColorStop(.7,'#26164e');bg.addColorStop(1,'#140a2c');
 g.save();g.beginPath();g.arc(cx,cy,ri,0,Math.PI*2);g.fillStyle=bg;g.fill();g.clip();
 g.save();g.globalAlpha=.35;g.lineWidth=Math.max(1,ri*.02);g.strokeStyle='#9a6aff';g.beginPath();g.arc(cx,cy-ri*.12,ri*.7,0,Math.PI*2);g.stroke();for(let i=0;i<8;i++){const a=i*Math.PI/4+.4;rrkRune(g,cx+Math.cos(a)*ri*.82,cy-ri*.12+Math.sin(a)*ri*.82,ri/110,'#b48aff',2)}g.restore();
 const top=(A.top||-250)-3,bot=-116,s=(ri*2)/(bot-top);g.translate(cx,cy-ri);g.scale(s,s);g.translate(0,-top);rrkDraw(g,A,t==null?1.2:t,{mode:'idle'});g.restore();
 g.beginPath();g.arc(cx,cy,r-lw*.6,0,Math.PI*2);g.lineWidth=lw+3;g.strokeStyle=WCO;g.stroke();g.lineWidth=lw;const rg=g.createLinearGradient(cx-r,cy-r,cx+r,cy+r);rg.addColorStop(0,'#fff0a8');rg.addColorStop(.45,'#ffc94a');rg.addColorStop(1,'#a8701a');g.strokeStyle=rg;g.stroke();
 g.beginPath();g.arc(cx,cy,r-lw*.6,0,Math.PI*2);g.lineWidth=Math.max(1,lw*.18);g.strokeStyle='rgba(120,70,10,.6)';g.setLineDash([lw*.5,lw*.9]);g.stroke();g.setLineDash([]);
 for(const a of [-Math.PI/2,Math.PI/2,0,Math.PI]){const x=cx+Math.cos(a)*(r-lw*.6),y=cy+Math.sin(a)*(r-lw*.6),d=lw*.75;g.beginPath();g.moveTo(x,y-d);g.lineTo(x+d,y);g.lineTo(x,y+d);g.lineTo(x-d,y);g.closePath();g.fillStyle='#8a4ae8';g.fill();g.lineWidth=Math.max(1.5,lw*.25);g.strokeStyle=WCO;g.stroke()}
 g.beginPath();g.arc(cx,cy,r-lw*.6,Math.PI*1.12,Math.PI*1.38);g.lineWidth=Math.max(1,lw*.28);g.strokeStyle='rgba(255,255,255,.7)';g.stroke()}
/* the crew renderer hands keepers over, so wcCrewDraw / wcCrewTop / wcCrewPortrait all understand them */
{const d0=wcCrewDraw;wcCrewDraw=function(g,A,t){if(A&&A.id&&A.rrkKeeper)return rrkDraw(g,A,t,{mode:'idle'});return d0.apply(this,arguments)}}
{const t0=wcCrewTop;wcCrewTop=function(A){if(A&&A.rrkKeeper)return A.top;return t0.apply(this,arguments)}}
for(const A of RRK)A.rrkKeeper=1;
