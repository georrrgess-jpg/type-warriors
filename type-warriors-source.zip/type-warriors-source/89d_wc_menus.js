/* ===== WILDCARD: menus — the lounge home, rules, statistics, solo tables, results podium, the private room lobby
   and the join screens ===== */
const wcDay=()=>{const d=new Date();return d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate()};
function wcSt(){let W=P.wc;if(!W||typeof W!=='object'||Array.isArray(W))W=P.wc={};
 const d={g:0,w:0,cur:0,best:0,net:0,pot:0,pbeat:0,fast:0,cards:0,d4:0,ones:0,catches:0,caught:0,drawn:0,day:'',dayN:0,fw:'',back:'classic',backs:{classic:1},hist:[],tbl:'c250',fr:0,seen:{classic:1}};
 for(const k in d)if(W[k]==null||typeof W[k]!==typeof d[k]||(Array.isArray(d[k])&&!Array.isArray(W[k])))W[k]=JSON.parse(JSON.stringify(d[k]));
 if(!W.byd||typeof W.byd!=='object')W.byd={};for(const k of[...WCTK,'pp','net','e','m','h'])if(!W.byd[k]||typeof W.byd[k]!=='object')W.byd[k]={g:0,w:0};
 if(!WCT[W.tbl])W.tbl='c250';if(W.day!==wcDay()){W.day=wcDay();W.dayN=0}return W}
const wcLeftToday=()=>Math.max(0,WCE.DAILY-wcSt().dayN);
const WCI={/* small ui icons */
 book:'<svg viewBox="0 0 24 24"><path d="M3 5c3-1 6-1 9 1v14c-3-2-6-2-9-1zM21 5c-3-1-6-1-9 1v14c3-2 6-2 9-1z" fill="currentColor"/></svg>',
 chart:'<svg viewBox="0 0 24 24"><path d="M5 20V11M12 20V5M19 20v-7" stroke="currentColor" stroke-width="3.2" stroke-linecap="round"/></svg>',
 back:'<svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" stroke="currentColor" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>',
 users:'<svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.6" fill="currentColor"/><path d="M2 20c0-4 3.2-6.4 7-6.4s7 2.4 7 6.4z" fill="currentColor"/><circle cx="17" cy="9" r="2.8" fill="currentColor" opacity=".7"/><path d="M15.5 13.6c3.6.2 6.5 2.3 6.5 6.4h-4.4" fill="currentColor" opacity=".7"/></svg>',
 globe:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18" fill="none" stroke="currentColor" stroke-width="2"/></svg>',
 qr:'<svg viewBox="0 0 24 24"><path d="M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3z" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M14 14h3v3h-3zM18 18h3v3h-3zM14 19h2v2h-2zM19 14h2v2h-2z" fill="currentColor"/></svg>',
 phone:'<svg viewBox="0 0 24 24"><rect x="6" y="2" width="12" height="20" rx="3" fill="none" stroke="currentColor" stroke-width="2.2"/><circle cx="12" cy="18" r="1.3" fill="currentColor"/></svg>',
 crown:'<svg viewBox="0 0 24 24"><path d="M3 8l4.5 3.6L12 4.5l4.5 7.1L21 8l-1.8 10.5H4.8z" fill="currentColor"/></svg>',
 bot:'<svg viewBox="0 0 24 24"><path d="M7 4h10l1 5H6z" fill="currentColor"/><path d="M4 9h16v2H4z" fill="currentColor"/><circle cx="9" cy="15" r="3" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="15" cy="15" r="3" fill="none" stroke="currentColor" stroke-width="2"/><path d="M12 15h0" stroke="currentColor" stroke-width="2"/></svg>',
 copy:'<svg viewBox="0 0 24 24"><rect x="8" y="8" width="12" height="13" rx="2" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M5 16V5a2 2 0 0 1 2-2h9" stroke="currentColor" stroke-width="2.2" fill="none"/></svg>',
 note:'<svg viewBox="0 0 24 24"><path d="M9 18V5l11-2v13" fill="none" stroke="currentColor" stroke-width="2.2"/><circle cx="6.5" cy="18" r="2.6" fill="currentColor"/><circle cx="17.5" cy="16" r="2.6" fill="currentColor"/></svg>',
 snd:'<svg viewBox="0 0 24 24"><path d="M4 9h4l5-4v14l-5-4H4z" fill="currentColor"/><path d="M16 9a4 4 0 0 1 0 6M18.5 6.5a8 8 0 0 1 0 11" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
 menu:'<svg viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16" stroke="currentColor" stroke-width="2.8" stroke-linecap="round"/></svg>',
 plus:'<svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14" stroke="currentColor" stroke-width="3" stroke-linecap="round"/></svg>',
 x:'<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2.8" stroke-linecap="round"/></svg>'};
/* a casino chip for a table denomination */
const wcChip=(k,sz)=>{const T=WCT[k]||{chip:'#8a7cf0',chip2:'#3a2a8a',lab:'0'};return `<svg viewBox="-50 -50 100 100" width="${sz||84}" height="${sz||84}" aria-hidden="true"><circle r="46" fill="${T.chip}" stroke="#12081f" stroke-width="4"/>
 ${Array.from({length:8},(_,i)=>`<rect x="-6" y="-46" width="12" height="13" rx="2" fill="#fff8ec" transform="rotate(${i*45})"/>`).join('')}<circle r="31" fill="${T.chip2}" stroke="#12081f" stroke-width="3"/><circle r="27" fill="none" stroke="#fff8ec" stroke-width="1.6" stroke-dasharray="4 4" opacity=".7"/>
 <text y="${T.lab.length>2?7:9}" text-anchor="middle" font-family="Poppins,sans-serif" font-weight="900" font-size="${T.lab.length>2?20:24}" fill="#fff8ec" stroke="#12081f" stroke-width="3.4" paint-order="stroke">${T.lab}</text><ellipse cx="-14" cy="-24" rx="14" ry="7" fill="#fff" opacity=".22" transform="rotate(-28)"/></svg>`};
const WCHERO=[{s:'e',v:'7',id:901},{s:'t',v:'d2',id:902},{s:'w',v:'wild',id:904},{s:'s',v:'turn',id:903},{s:'g',v:'9',id:905}];
const wcMusLab=()=>ST.mute?'Music off':'Music on';
function wcMusBtn(id){return `<button class="wcpb${ST.mute?' off':''}" id="${id||'wcmus'}" aria-pressed="${!ST.mute}">${WCI.note}<span>${wcMusLab()}</span></button>`}
function wcMusWire(id){const b=$(id||'wcmus');if(!b)return;b.onclick=()=>{try{ensureAudio()}catch(e){}if(mt)mt.click();else{ST.mute=!ST.mute;applyVol()}b.classList.toggle('off',!!ST.mute);b.setAttribute('aria-pressed',!ST.mute);b.querySelector('span').textContent=wcMusLab();wcFx('click')}}
/* live canvases (the regulars breathe and blink) */
function wcLive(cv,A,kind){if(!cv)return;const draw=t=>kind==='por'?wcCrewPortrait(cv,A,t):wcCrewFigure(cv,A,t);draw(1.2);if(!wcRM())LIVE.push({cv,fn:draw,slow:2,ph:Math.floor(Math.random()*2)})}
/* ---------- home ---------- */
function wcHome(){WX.tok++;wcClear();wcScanStop();CAS.on=true;CAS.key=null;const W=wcSt(),t=WX.tbl=WCT[W.tbl]?W.tbl:'c250';const crew=wcCrewGen(2,null,{rare:.25});
 const bulbs=Array.from({length:46},(_,i)=>{const p=i<15?[i/14*100,0]:i<23?[100,(i-14)/8*100]:i<38?[100-(i-23)/14*100,100]:[0,100-(i-38)/8*100];return `<i style="left:${p[0]}%;top:${p[1]}%;--i:${i%6}"></i>`}).join('');
 const bok=Array.from({length:12},(_,i)=>`<i style="--x:${(i*137)%100}%;--s:${8+(i*7)%18}px;--d:${(i*1.7)%9}s;--t:${11+(i*3)%9}s;--c:${['#ffd45a','#ff5a9a','#5ab8ff','#7ae07a'][i%4]}"></i>`).join('');
 show(`<div class="wch" id="wch"><div class="wclbg"><i class="wcspot a"></i><i class="wcspot b"></i><div class="wcbok">${bok}</div></div><div class="wctbl2"></div>
 <header class="wchbar"><button class="wcpb back" id="wcbk">${WCI.back}<span>Casino</span></button><div class="wchtr"><button class="wcpb" id="wchow">${WCI.book}<span>How to play</span></button><button class="wcpb" id="wcstats">${WCI.chart}<span>Stats</span></button><button class="wcpb" id="wcvlt">${WCI2.cards}<span>Card backs</span>${WCBKK.some(k=>W.backs[k]&&!(W.seen||{})[k])?'<i class="wcdot"></i>':''}</button>${wcMusBtn()}${W.cur>=2?`<span class="wcpb streak" title="Wins in a row">${WCI2.flame}<b>${W.cur} in a row</b></span>`:''}<span class="wcpb gold"><span class="coin"></span><b>${cmn(P.gold)}</b></span></div></header>
 <canvas class="wcreg l" width="250" height="330" aria-hidden="true"></canvas><canvas class="wcreg r" width="250" height="330" aria-hidden="true"></canvas>
 <div class="wcsign"><div class="wcbulbs">${bulbs}</div><span class="wcsk">UPDATE 8.2 · THE DRAGON LOUNGE</span><h1 class="wclogo2">Wildcard</h1><p>Match the element or the number. Empty your hand first.</p></div>
 <div class="wcfan2" id="wcfan">${WCHERO.map((c,i)=>wcCardEl(c,'',`style="--i:${i}"`)).join('')}</div>
 <div class="wcmodes2">
  <section class="wcm solo" style="--d:0"><header><span class="wcmg">${wcOrb('e',40)}</span><div><h2>Solo</h2><small>Take on the lounge regulars</small></div></header>
   <p class="wcml">Pick your table<span class="wcfwb" id="wcfwb">★ First win today +${WCE.FIRSTWIN}</span></p><div class="wcchips" role="radiogroup" aria-label="Table">${WCTK.map(k=>`<button class="wcchipb${k===t?' on':''}" data-tbl="${k}" role="radio" aria-checked="${k===t}" aria-label="${WCT[k].n}, buy-in ${WCT[k].stake}">${wcChip(k,76)}<b>${WCT[k].n}</b></button>`).join('')}</div>
   <div class="wcsi2" id="wcsi"></div><label class="wcprac"><input type="checkbox" id="wcfrc" ${W.fr?'checked':''}><i></i><span>Practice game (no gold)</span></label>
   <button class="wcbtn gold big" id="wcsolo">Take a seat <i>›</i></button></section>
  <section class="wcm host" style="--d:1"><header><span class="wcmg">${wcOrb('s',40)}</span><div><h2>Play with friends</h2><small>2 to 4 players · you host</small></div></header>
   <div class="wcopts"><div>${WCI.users}<span><b>Same screen</b><small>Pass the device round. Each hand hides until its owner taps in.</small></span></div>
   <div>${WCI.globe}<span><b>Room code</b><small>Friends type your 4-letter code on their own phone or computer.</small></span></div></div>
   <button class="wcbtn gold big" id="wchost">Create a room <i>›</i></button></section>
  <section class="wcm join" style="--d:2"><header><span class="wcmg">${wcOrb('t',40)}</span><div><h2>Join a room</h2><small>Type the code your host shows</small></div></header>
   <div class="wcotp" id="wcotp">${[0,1,2,3].map(i=>`<input maxlength="1" inputmode="text" autocomplete="off" spellcheck="false" aria-label="Code letter ${i+1}" data-o="${i}">`).join('')}</div>
   <p class="wcerr" id="wcjerr"></p><p class="wcjtip">${WCI.phone}<span>Your host sees a <b>4-letter code</b> at the top of their room. Type it in, and you'll sit down at their table.</span></p><button class="wcbtn blue big" id="wcjoin">Join <i>›</i></button><button class="wclink" id="wcscanj">${WCI.qr}No internet? Scan to join</button></section></div>
 <div class="wcmod" id="wcmod" hidden></div></div>`,'casbg wcx');
 S.back=()=>{const m=$('wcmod');if(m&&!m.hidden){m.hidden=true;m.innerHTML='';wcScanStop();return}wcLeaveHome()};$('wcbk').onclick=wcLeaveHome;
 wcLive(ov.querySelector('.wcreg.l'),crew[0]);wcLive(ov.querySelector('.wcreg.r'),crew[1]);
 const info=()=>{const T=WCT[WX.tbl],fr=$('wcfrc').checked,left=wcLeftToday();$('wcsi').innerHTML=fr||!left?`<b>${T.n}</b> · practice: no buy-in, no payout${!left&&!fr?'<small>Today\'s 15 staked games are used up, so tables are free until tomorrow.</small>':'<small>Games still count toward your stats.</small>'}`
  :`<b>${T.n}</b> · buy-in <b class="g">${cmn(T.stake)}</b> · win <b class="g">${cmn(wcPayout(T.stake,4,0,WCFEE))}</b><small>2nd place gets ${cmn(wcPayout(T.stake,4,1,WCFEE))} back · ${left}/${WCE.DAILY} paid games left today</small>`;const fb=$('wcfwb');if(fb)fb.hidden=wcSt().fw===wcDay()};
 ov.querySelectorAll('[data-tbl]').forEach(b=>{b.onclick=()=>{WX.tbl=b.dataset.tbl;wcSt().tbl=WX.tbl;save();ov.querySelectorAll('[data-tbl]').forEach(x=>{x.classList.toggle('on',x===b);x.setAttribute('aria-checked',x===b)});b.classList.remove('spin');void b.offsetWidth;b.classList.add('spin');wcFx('chip');info()};b.onmouseenter=()=>wcFx('hover')});
 $('wcfrc').onchange=()=>{wcSt().fr=$('wcfrc').checked?1:0;save();wcFx('click');info()};info();
 $('wcsolo').onclick=()=>{wcFx('click');wcStartSolo(WX.tbl,$('wcfrc').checked)};$('wchost').onclick=()=>{wcFx('click');wcLobby()};
 const box=[...ov.querySelectorAll('#wcotp input')],code=()=>box.map(x=>x.value).join('');
 const go=()=>{const v=code();if(v.length<4){$('wcjerr').textContent='Type all 4 letters of the room code.';$('wcotp').classList.remove('nope');void $('wcotp').offsetWidth;$('wcotp').classList.add('nope');wcFx('bad');(box.find(x=>!x.value)||box[0]).focus();return}wcFx('click');wcJoinCode(v)};
 box.forEach((x,i)=>{x.onkeydown=e=>{e.stopPropagation();if(e.key==='Backspace'&&!x.value&&box[i-1]){box[i-1].focus();box[i-1].value=''}else if(e.key==='Enter')go();else if(e.key==='ArrowLeft'&&box[i-1])box[i-1].focus();else if(e.key==='ArrowRight'&&box[i+1])box[i+1].focus()};
  x.oninput=()=>{const v=wcCodeNorm(x.value);x.value=v.slice(-1);$('wcjerr').textContent='';x.classList.toggle('in',!!x.value);if(x.value){wcFx('tick');if(box[i+1])box[i+1].focus();else if(code().length===4)$('wcjoin').focus()}};
  x.onpaste=e=>{const t=(e.clipboardData||window.clipboardData).getData('text')||'';if(/WC1~|#wcj=/.test(t)){e.preventDefault();wcJoin(t);return}const v=wcCodeNorm(t);if(v.length>1){e.preventDefault();box.forEach((y,j)=>{y.value=v[j]||'';y.classList.toggle('in',!!y.value)});(box[Math.min(3,v.length)]||box[3]).focus()}}});
 $('wcjoin').onclick=go;$('wcscanj').onclick=()=>{wcFx('click');wcJoinView('scan')};
 $('wchow').onclick=()=>{wcFx('click');wcHowTo()};$('wcstats').onclick=()=>{wcFx('click');wcStats()};$('wcvlt').onclick=()=>{wcFx('click');wcVault()};wcMusWire();
 ov.querySelectorAll('.wcm').forEach(s=>s.onmouseenter=()=>wcFx('hover'));
 const f=$('wcfan');if(f)f.querySelectorAll('.wcc').forEach(c=>c.onmouseenter=()=>wcFx('shimmer',+c.style.getPropertyValue('--i')));
 setTimeout(()=>wcFx('shuffle'),350)}
function wcLeaveHome(){WX.tok++;wcClear();try{wcNetClose()}catch(e){}wcFx('back');try{lobby()}catch(e){title()}}
function wcModal(html,cls){const m=$('wcmod');if(!m)return null;m.hidden=false;m.className='wcmod '+(cls||'');m.innerHTML=`<div class="wcmb">${html}<button class="wcmx" aria-label="Close">${WCI.x}</button></div>`;
 const close=()=>{m.hidden=true;m.innerHTML='';wcScanStop()};m.querySelector('.wcmx').onclick=close;m.onclick=e=>{if(e.target===m)close()};setTimeout(()=>{const b=m.querySelector('.wcmx');if(b)b.focus()},40);wcFx('pop');return m}
function wcHowTo(){const c=(s,v)=>wcCardEl({s,v,id:950+WCS.indexOf(s)+v.length},'mini');
 wcModal(`<h3>How to play Wildcard</h3><div class="wchw">
 <div class="wchr"><div class="wchc2">${c('e','7')}${c('e','3')}${c('t','7')}</div><p><b>Match the element or the face.</b> Play an Ember on an Ember, or any 7 on a 7. No match? Draw a card. If it fits, you can play it straight away.</p></div>
 <div class="wchr"><div class="wchc2">${c('g','stun')}${c('t','turn')}${c('s','d2')}</div><p><b>Action cards.</b> <i>Stun</i> skips the next player. <i>Turnabout</i> reverses the order. <i>+2 Curse</i> makes the next player draw two, unless they stack another +2 on it.</p></div>
 <div class="wchr"><div class="wchc2">${c('w','wild')}${c('w','d4')}</div><p><b>Wild Rune</b> lets you pick the next element. <b>+4 Hex</b> does too, and the next player draws four (or stacks another +4).</p></div>
 <div class="wchr"><div class="wchone">WILD!</div><p><b>Down to two cards?</b> Press <b>WILD!</b> before you play your second-to-last card. Forget, and the first player to tap you makes you draw two. Catch the regulars when they forget!</p></div></div>
 <p class="wchk">Keys: <kbd>D</kbd> draw · <kbd>W</kbd> call WILD! · <kbd>H</kbd> hint · <kbd>K</kbd> keep a drawn card · <kbd>Esc</kbd> menu</p>`,'wide')}
/* ---------- statistics and the card back vault live in 89o ---------- */
/* ---------- solo ---------- */
function wcReset(o){wcClear();WX.tok++;Object.assign(WX,{G:null,me:0,seen:0,busy:false,sort:WX.sort||0,ended:false,recorded:false,cover:false,fresh:null,chat:[],stake:0,fee:0,mode:'solo',host:true,cfg:{timer:0}},o||{})}
function wcStartSolo(tbl,friendly){if(!WCT[tbl])tbl='c250';const T=WCT[tbl],W=wcSt();let stake=friendly||!wcLeftToday()?0:T.stake;
 if(stake>P.gold){wcModal(`<h3>Not enough gold</h3><p class="wcp">The ${T.n} buy-in is <b>${cmn(stake)}</b> gold and you have <b>${cmn(P.gold)}</b>. Try a smaller table, or play a practice game.</p><div class="wcrow"><button class="wcbtn gold" id="wcfrg">Play a practice game</button></div>`);$('wcfrg').onclick=()=>wcStartSolo(tbl,true);return}
 if(stake){P.gold-=stake;W.dayN++;save();wcFx('chip')}
 wcReset({mode:'solo',tbl,stake,fee:WCFEE,cfg:{timer:0,tbl,friendly}});
 const players=[{id:'me',name:P.name||'You',kind:'you',av:wcMyAv()},...wcCrewGen(3,null,{rare:.1}).map((A,i)=>({id:'r'+i,name:A.name,kind:'bot',av:A}))];
 WX.G=wcNew({players,hand:7,rules:{stack:1},seed:(Date.now()^Math.floor(Math.random()*1e9))>>>0});wcTable();
 const rg=players.find(p=>p.av&&p.av.rare);if(rg){wcToast(`✨ A rare guest joins the table: <b>${esc(rg.name)}</b>. Beat him for a legendary card back!`);wcFx('wild')}wcPump()}
/* ---------- results ---------- */
function wcRecord(o){const G=WX.G;if(!G||WX.recorded)return null;WX.recorded=true;const W=wcSt(),k=WX.mode==='solo'?WX.tbl:WX.mode;const me=G.P[WX.mode==='pp'?0:WX.me];
 const rank=o&&o.forfeit?null:wcRank(G),place=rank?rank.indexOf(WX.mode==='pp'?0:WX.me):G.P.length-1,win=place===0;
 const pay=WX.stake?wcPayout(WX.stake,G.P.length,place,WX.fee):0,bonus=win&&WX.mode!=='pp'&&W.fw!==wcDay()?WCE.FIRSTWIN:0;
 if(pay+bonus>0)P.gold=Math.min(1e12,P.gold+pay+bonus);if(bonus)W.fw=wcDay();
 W.g++;if(win){W.w++;W.cur++;W.best=Math.max(W.best,W.cur);if(!W.fast||G.turns<W.fast)W.fast=G.turns}else W.cur=0;
 const net=pay+bonus-WX.stake;W.net+=net;if(win)W.pot=Math.max(W.pot,pay);W.cards+=me.played;W.d4+=me.d4;W.ones+=me.ones;W.catches+=me.catches;W.caught+=me.caught;W.drawn+=me.drawn;
 if(W.byd[k]){W.byd[k].g++;if(win)W.byd[k].w++}W.hist.push({p:place,n:net,k});if(W.hist.length>30)W.hist.splice(0,W.hist.length-30);
 const got=[];const un=(b,ok)=>{if(ok&&!W.backs[b]){W.backs[b]=1;got.push(b)}};let hw=false;try{hw=!!hwOn()}catch(e){}
 if(win&&G.P.some(p=>p.av&&p.av.rare))W.pbeat=1;
 un('neon',W.g>=10);un('hallow',W.w>=3||hw);un('emerald',W.w>=10);un('royal',W.w>=25);un('astral',W.byd.c1k.w+W.byd.c2k5.w+W.byd.h.w>=10);un('dragon',W.best>=5);un('pastel',W.pbeat>=1);
 try{const c=cst();c.plays++;c.net+=net;if(net>c.best)c.best=net}catch(e){}
 save();return{rank,place,pay,bonus,net,got}}
function wcEnd(){const G=WX.G;if(!G||!$('wct'))return;const R=wcRecord();if(!R)return;wcResults(R)}
function wcResults(R){const G=WX.G,rank=R.rank,n=G.P.length,W=wcSt(),wi=rank[0],wn=G.P[wi];
 const most=G.P.reduce((a,p,i)=>p.drawn>G.P[a].drawn?i:a,0),calls=G.P.map((p,i)=>p.caught?`${esc(p.name)} ×${p.caught}`:'').filter(Boolean).join(', ')||'Nobody';
 const order=[1,0,2].filter(k=>k<Math.min(3,n));
 const pod=order.map(k=>{const i=rank[k],p=G.P[i];return `<div class="wcpc p${k+1}" style="--k:${k}"><canvas width="260" height="300" data-fig="${i}"></canvas><div class="wcblk"><b>${k+1}</b><span>${esc(p.name)}</span><small>${p.hand.length?p.hand.length+' card'+(p.hand.length>1?'s':'')+' left':'Emptied their hand'}</small></div></div>`}).join('');
 const T=WX.mode==='solo'?WCT[WX.tbl]:null,pot=WX.stake*n;
 const lines=WX.stake?[[`Pot (${n} × ${cmn(WX.stake)})`,R.place===0?'+'+cmn(pot):'–'],R.place===0?[`House cut ${Math.round(WX.fee*100)}%`,'−'+cmn(pot-R.pay)]:R.place===1?['2nd place refund','+'+cmn(R.pay)]:null,['Your buy-in','−'+cmn(WX.stake)]].filter(Boolean):[['Practice game','no stake']];
 if(R.bonus)lines.push(['First win today','+'+cmn(R.bonus)]);
 const me=WX.mode==='pp'?0:WX.me,won=wi===me;
 show(`<div class="wcr${won?' won':''}" id="wcr"><div class="wcrays"></div><div class="wcconf" id="wcconf"></div>
 <div class="wcrtag">${WX.mode==='solo'?esc(T.n).toUpperCase():WX.mode==='pp'?'SAME SCREEN':'ROOM '+esc(WX.room||'')} · ${n} PLAYERS</div>
 <h1 class="wcrh">${won?'You win!':esc(wn.name)+' wins!'}</h1>
 <div class="wcpod">${pod}</div>
 <div class="wcrp wcrs"><h4>Match stats</h4><div><span>Turns played</span><b>${G.turns}</b></div><div><span>Biggest stack</span><b>${G.big?'+'+G.big:'–'}</b></div><div><span>Most cards drawn</span><b>${G.P[most].drawn} · ${esc(G.P[most].name)}</b></div><div><span>Caught forgetting WILD!</span><b>${calls}</b></div><div><span>Your cards played</span><b>${G.P[me].played}</b></div></div>
 <div class="wcrp wcrpay"><h4>${WX.mode==='pp'?'Result':'Your payout'}</h4>${lines.map(([a,b])=>`<div><span>${a}</span><b class="${String(b)[0]==='+'?'up':String(b)[0]==='−'?'dn':''}">${b}</b></div>`).join('')}
  <div class="wctot"><span>Total</span><b class="${R.net>=0?'up':'dn'}"><span class="coin"></span>${R.net>=0?'+':'−'}${cmn(Math.abs(R.net))}</b></div>
  <p class="wcrn">Record ${W.w}–${W.g-W.w}${W.cur>1?` · win streak ${W.cur}`:''}${WX.stake?` · staked games today ${W.dayN} / ${WCE.DAILY}`:''}</p>${R.got.map(b=>`<button class="wcunl" data-bk="${b}" style="--rc:${WCRARC[WCBK[b].r]}">${wcBack(b)}<span><b>New card back!</b>${WCBK[b].n} · <i style="color:${WCRARC[WCBK[b].r]}">${WCRAR[WCBK[b].r]}</i><small>Open the vault ›</small></span></button>`).join('')}</div>
 <div class="wcrb"><button class="wcbtn gold big" id="wcagain">${WX.mode==='net'?'Back to the room':'↻ Play again'}</button><button class="wcbtn purple big" id="wchome">Wildcard menu</button><button class="wcbtn dark big" id="wcout">Leave</button></div></div>`,'casbg wcx');
 ov.querySelectorAll('canvas[data-fig]').forEach(c=>{const av=G.P[+c.dataset.fig].av;if(av&&av.t==='crew')wcLive(c,av);else wcFigure(c,av)});
 if(!wcRM()&&won){const cf=$('wcconf'),L=[];for(let k=0;k<26;k++){const c={s:WCS[k%4],v:String(k%10),id:700+k};L.push(`<i style="--x:${(k*61)%100}vw;--d:${(k%9)*.35}s;--t:${3.2+(k%5)*.6}s;--r:${(k*47)%360}deg">${wcSVG(c)}</i>`)}cf.innerHTML=L.join('')}
 wcFx(won?'win':'lose');if(R.net>0)setTimeout(()=>wcFx('chip'),900);
 ov.querySelectorAll('.wcunl[data-bk]').forEach(b=>b.onclick=()=>{try{wcNetClose()}catch(e){}wcVault(b.dataset.bk)});if(R.got.length)setTimeout(()=>wcFx('rare'),1700);
 const cfg=WX.cfg;$('wcagain').onclick=()=>{wcFx('click');if(WX.mode==='solo')wcStartSolo(WX.tbl,!!(cfg&&cfg.friendly));else if(WX.mode==='pp')wcLobby(cfg);else if(WX.host)wcLobbyBack();else wcJoinView('in')};
 $('wchome').onclick=()=>{try{wcNetClose()}catch(e){}wcHome()};$('wcout').onclick=wcLeaveHome;S.back=()=>{try{wcNetClose()}catch(e){}wcHome()};
 setTimeout(()=>{const b=$('wcagain');if(b)b.focus()},60)}
/* ---------- the private room: a mini table with four seats, the room code and the table settings ---------- */
const WCL={seats:[],set:{stake:0,timer:0,hand:7,stack:1,until:0,seven:0},room:'',crew:[],net:'off'};
const wcCode=()=>Array.from({length:4},()=>WCAB[Math.floor(Math.random()*32)]).join('');
function wcLobby(keep){WX.tok++;wcClear();if(!keep||!WCL.seats.length){WCL.room=wcCode();WCL.seats=[{k:'you',name:P.name||'You'},{k:'open'},{k:'open'},{k:'open'}];WCL.crew=wcCrewGen(3,null,{rare:.1})}
 if(keep&&keep.set)Object.assign(WCL.set,keep.set);wcHostRelay();wcLobbyRender()}
const WCSTK=[0,50,250,1000],WCTM=[0,20,30],WCHN=[5,7,9];
const WCRULE=[['stack','Stacking','Pass a +2 or +4 on with another','<path d="M5 9h10v11H5z" fill="currentColor" opacity=".5"/><path d="M9 4h10v11H9z" fill="currentColor"/>'],
 ['until','Draw till it fits','Keep drawing until a card plays','<path d="M7 3h10v14H7z" fill="none" stroke="currentColor" stroke-width="2"/><path d="M12 19v3M9 20l3 2 3-2" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round"/>'],
 ['seven','Lucky sevens','A 7 swaps hands with the shortest hand','<path d="M6 5h12l-7 15" stroke="currentColor" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/>']];
/* the four seats around the felt; host=true makes them editable */
function wcSeatsHTML(seats,host,meIdx){const pos=['b','l','t','r'];return `<div class="wcmini"><div class="wcmfelt"><span>${wcBack(wcBackSel())}</span></div>${seats.map((s,i)=>{const p=pos[i],me=i===meIdx,av=s.k==='bot'||s.k==='you'||s.k==='net'||(s.av&&s.k!=='open');
  const tag=s.k==='you'?'<em class="gold">Host</em>':s.k==='bot'?(((host?WCL.crew[i-1]:s.av)||{}).rare?'<em class="rare">★ Rare guest</em>':'<em>Regular</em>'):s.k==='local'?'<em class="pp">This screen</em>':s.k==='net'?(s.ready?'<em class="ok">✓ Ready</em>':'<em class="wait">Getting ready…</em>'):s.k==='inv'?`<em class="wait">${s.via==='code'?'Joining…':'Invite sent'}</em>`:s.k==='none'?'<em>Closed</em>':'<em>Open seat</em>';
  const nm=s.k==='open'?(host?'Add a player':'Waiting…'):s.k==='none'?'Empty':s.k==='bot'&&host?esc((WCL.crew[i-1]||{}).name||'Regular'):s.k==='inv'?(s.name||'Friend'):s.k==='local'?(host?`<input class="wcnmi" data-nm="${i}" maxlength="14" value="${esc(s.name||'Player '+(i+1))}" aria-label="Player name">`:esc(s.name)):esc(s.name||'');
  const ctl=!host||s.k==='you'?'':s.k==='open'?`<button class="wcadd2" data-addm="${i}" aria-label="Add a player to this seat">${WCI.plus}</button>`:`<button class="wclx" data-rm="${i}" aria-label="Clear this seat">${WCI.x}</button>`;
  return `<div class="wcseat2 s-${p}${s.k==='open'?' open':''}${s.k==='none'?' none':''}${s.fresh?' fresh':''}${me?' me':''}" data-i="${i}"><div class="wcsav">${s.k==='open'?(host?'':'<i class="wcspin"></i>'):s.k==='inv'?'<i class="wcspin"></i>':s.k==='local'?`<span class="ic">${WCI.users}</span>`:s.k==='none'?'':`<canvas width="112" height="112" data-sv="${i}"></canvas>`}${ctl}</div>
   <div class="wcsnm"><b>${nm}</b>${tag}${s.k==='net'?`<span class="wcms">${s.ms?s.ms+' ms':''}</span>`:''}</div></div>`}).join('')}</div>`}
function wcSeatAv(s,i,crew){return s.k==='you'?wcMyAv():s.k==='bot'?crew[i-1]:s.av||{t:'hero',col:(i*3)%8}}
function wcLobbyNet(){const e=$('wclnet');if(!e)return;const st=WCL.net;e.className='wclnet '+st;e.innerHTML=st==='online'?'<i></i>Online · friends can join with this code':st==='connecting'?'<i></i>Opening the room…':'<i></i>No internet · invite friends on your Wi-Fi with a QR code';const q=$('wclqr');if(q)q.classList.toggle('hot',st==='offline')}
function wcLobbyRender(){const S2=WCL.set,seats=WCL.seats,pp=seats.some(s=>s.k==='local'),net=seats.some(s=>s.k==='net'||s.k==='inv');if(pp)S2.stake=0;
 const playing=seats.filter(s=>s.k!=='none').length,waiting=seats.some(s=>s.k==='inv'||(s.k==='net'&&!s.ready));
 const seg=(k,arr,fmt)=>`<div class="wcseg" role="radiogroup">${arr.map(v=>`<button data-seg="${k}" data-v="${v}" class="${S2[k]===v?'on':''}" role="radio" aria-checked="${S2[k]===v}">${fmt(v)}</button>`).join('')}</div>`;
 const chips=`<div class="wcbuy">${WCSTK.map(v=>`<button data-stk="${v}" class="${S2.stake===v?'on':''}${pp&&v?' off':''}" ${pp&&v?'disabled':''} aria-label="${v?'Buy-in '+v:'Free'}">${v?wcChip(v===50?'c50':v===250?'c250':'c1k',58):`<span class="free">FREE</span>`}<small>${v?cmn(v):'Just for fun'}</small></button>`).join('')}</div>`;
 show(`<div class="wcl" id="wcl"><div class="wclbg"><i class="wcspot a"></i><i class="wcspot b"></i></div>
 <header class="wclh"><button class="wcpb back" id="wcll">${WCI.back}<span>Leave room</span></button><h1>Private Room</h1>${wcMusBtn('wcmusl')}</header>
 <section class="wclp code"><h4>Room code</h4><div class="wcct">${WCL.room.split('').map((ch,i)=>`<span style="--i:${i}">${ch}</span>`).join('')}</div><p class="wclnet" id="wclnet"></p>
  <ol class="wchowj"><li><b>1</b>Friends open Wildcard</li><li><b>2</b>They tap <i>Join a room</i></li><li><b>3</b>They type <i>${WCL.room}</i></li></ol>
  <div class="wcshare"><small>Send this to your friends</small><p>“Join my Wildcard table in the Dragon Lounge! Room code: <b>${WCL.room}</b>”</p><button class="wcbtn sm" id="wclcp">${WCI.copy}Copy message</button></div>
  <div class="wcoff"><span>${WCI.qr}</span><p><b>No internet?</b> Friends on your Wi-Fi can scan a QR instead.</p><button class="wcbtn sm" id="wclqr">Invite by QR</button></div></section>
 <section class="wclp seats"><h4>Players · ${playing} seat${playing>1?'s':''}</h4>${wcSeatsHTML(seats,true,0)}<p class="wclsh">${pp?'Same-screen game: pass the device when it says so.':'Open seats are filled by lounge regulars when you deal.'}</p></section>
 <section class="wclp sets"><h4>Buy-in</h4>${chips}<p class="wcnote">${pp?'Same-screen games are always free.':S2.stake?`Winner takes ${cmn(wcPayout(S2.stake,playing,0,WCE.MPFEE))} · each player pays from their own gold`:'No gold changes hands.'}</p>
  <h4>Turn timer</h4>${seg('timer',WCTM,v=>v?v+' sec':'Off')}<h4>Cards in hand</h4>${seg('hand',WCHN,v=>v)}
  <h4>House rules</h4><div class="wcrules">${WCRULE.map(([k,l,d,ic])=>`<button class="wcrule${S2[k]?' on':''}" data-rule="${k}" aria-pressed="${!!S2[k]}"><svg viewBox="0 0 24 24">${ic}</svg><b>${l}</b><small>${d}</small><em>${S2[k]?'ON':'OFF'}</em></button>`).join('')}</div>
  <button class="wcbtn gold big" id="wcgo" ${playing<2||waiting?'disabled':''}>Deal the cards · ${playing} players</button><p class="wcfoot">${waiting?'Waiting for every friend to tap Ready':playing<2?'You need at least one more player':S2.stake&&net?'Each player pays the buy-in from their own gold':'Only the host can deal'}</p></section>
 <div class="wcmod" id="wcmod" hidden></div></div>`,'casbg wcx');
 S.back=()=>{const m=$('wcmod');if(m&&!m.hidden){m.hidden=true;m.innerHTML='';wcScanStop();return}const pm=document.querySelector('.wcpop2');if(pm){pm.remove();return}wcLobbyLeave()};$('wcll').onclick=wcLobbyLeave;
 ov.querySelectorAll('canvas[data-sv]').forEach(c=>{const i=+c.dataset.sv,s=seats[i],A=wcSeatAv(s,i,WCL.crew);if(A.t==='crew')wcLive(c,A,'por');else wcPortrait(c,A)});
 seats.forEach(s=>{if(s.fresh){s.fresh=0}});wcLobbyNet();wcMusWire('wcmusl');
 $('wclcp').onclick=()=>wcCopy('Join my Wildcard table in the Dragon Lounge! Room code: '+WCL.room,$('wclcp'));$('wclqr').onclick=()=>{const i=WCL.seats.findIndex(x=>x.k==='open');if(i<0){wcModal('<h3>The room is full</h3><p class="wcp">Clear a seat first to invite someone else.</p>');return}WCL.seats[i]={k:'inv',via:'scan',name:'Friend'};wcLobbyRender();wcInvite(i)};
 ov.querySelectorAll('[data-addm]').forEach(b=>b.onclick=e=>{e.stopPropagation();wcSeatMenu(+b.dataset.addm,b)});
 ov.querySelectorAll('[data-rm]').forEach(b=>b.onclick=()=>{const i=+b.dataset.rm;try{wcNetDrop(i)}catch(e){}WCL.seats[i]={k:'open'};wcFx('leave');wcLobbyRender();wcNetLobby()});
 ov.querySelectorAll('[data-nm]').forEach(x=>{x.onkeydown=e=>e.stopPropagation();x.oninput=()=>{WCL.seats[+x.dataset.nm].name=x.value.replace(/[<>]/g,'').slice(0,14)}});
 ov.querySelectorAll('[data-stk]').forEach(b=>b.onclick=()=>{S2.stake=+b.dataset.stk;wcFx('chip');wcLobbyRender();wcNetLobby()});
 ov.querySelectorAll('[data-seg]').forEach(b=>b.onclick=()=>{S2[b.dataset.seg]=+b.dataset.v;wcFx('click');wcLobbyRender();wcNetLobby()});
 ov.querySelectorAll('[data-rule]').forEach(b=>b.onclick=()=>{const k=b.dataset.rule;S2[k]=S2[k]?0:1;wcFx(S2[k]?'ready':'back');wcLobbyRender();wcNetLobby()});
 $('wcgo').onclick=wcLobbyStart;wcNetLobby()}
/* the little menu on an empty seat */
function wcSeatMenu(i,btn){document.querySelectorAll('.wcpop2').forEach(x=>x.remove());const m=document.createElement('div');m.className='wcpop2';
 m.innerHTML=`<button data-a="bot">${WCI.bot}<span><b>Lounge regular</b><small>A computer player</small></span></button><button data-a="local">${WCI.users}<span><b>Player on this screen</b><small>Pass the device round</small></span></button><button data-a="inv">${WCI.qr}<span><b>Invite by QR</b><small>Same Wi-Fi, no internet needed</small></span></button><button data-a="none">${WCI.x}<span><b>Leave it empty</b><small>Play with fewer seats</small></span></button>`;
 const seat=btn.closest('.wcseat2');seat.appendChild(m);wcFx('pop');const close=()=>{m.remove();document.removeEventListener('click',close)};setTimeout(()=>document.addEventListener('click',close),0);
 m.querySelectorAll('[data-a]').forEach(b=>b.onclick=e=>{e.stopPropagation();close();const k=b.dataset.a;if(k==='inv'){WCL.seats[i]={k:'inv',via:'scan',name:'Friend'};wcLobbyRender();wcInvite(i);return}
  WCL.seats[i]=k==='local'?{k:'local',name:'Player '+(i+1),fresh:1}:k==='bot'?{k:'bot',fresh:1}:{k:'none'};wcFx(k==='none'?'back':'join');wcLobbyRender();wcNetLobby()});
 setTimeout(()=>{const b=m.querySelector('button');if(b)b.focus()},30)}
function wcLobbyLeave(){try{wcNetClose()}catch(e){}WCL.seats=[];wcHome()}
function wcLobbyStart(){const S2=WCL.set,raw=WCL.seats.map((s,i)=>s.k==='open'?{k:'bot',auto:1,_i:i}:Object.assign({},s,{_i:i})),seats=raw.filter(s=>['you','bot','local','net'].includes(s.k));if(seats.length<2)return;
 const pp=seats.some(s=>s.k==='local'),stake=pp?0:S2.stake;if(stake&&stake>P.gold){wcModal(`<h3>Not enough gold</h3><p class="wcp">The buy-in is <b>${cmn(stake)}</b> and you have <b>${cmn(P.gold)}</b>. Pick a smaller buy-in to deal.</p>`);return}
 const players=seats.map((s,j)=>{const i=s._i;if(s.k==='you')return{id:'host',name:P.name||'You',kind:'you',av:wcMyAv()};if(s.k==='bot'){const A=WCL.crew[i-1]||wcCrewGen(1)[0];return{id:'b'+i,name:A.name,kind:'bot',av:A}}
  if(s.k==='local')return{id:'l'+i,name:s.name||'Player '+(i+1),kind:'local',av:{t:'hero',col:(i*3)%8}};const real=WCL.seats[i];return{id:real.pid,name:real.name||'Friend',kind:'net',av:real.av||{t:'hero'}}});
 if(stake){P.gold-=stake;save()}wcFx('shuffle');
 wcReset({mode:pp?'pp':seats.some(s=>s.k==='net')?'net':'pp',host:true,stake,fee:WCE.MPFEE,room:WCL.room,cfg:{timer:S2.timer,set:Object.assign({},S2)}});
 WX.G=wcNew({players,hand:S2.hand,rules:{stack:S2.stack,until:S2.until,seven:S2.seven},seed:(Date.now()^Math.floor(Math.random()*1e9))>>>0});
 if(WX.mode==='pp'){const first=WX.G.turn;if(WX.G.P[first].kind==='local'){WX.me=first}}
 wcNetStart();wcTable();wcPump()}
/* ---------- joining: finding the room, the offline scan, and the guest's view of the room ---------- */
function wcJoinView(state){WX.tok++;wcClear();const g=WCNET.guest,L=g&&g.lobby,code=g&&g.code||'';
 const msg={find:['Finding the room…',`Looking for room <b class="mono">${esc(code)}</b>. This takes a second or two.`,'radar'],link:['Found it!','Connecting to the host…','radar'],
  slow:['Still connecting…','If you are on different networks, some routers block direct play. Joining from the host\'s Wi-Fi always works.','radar'],
  none:['No room found',`Nobody is hosting <b class="mono">${esc(code)}</b> right now. Check the code, and that the host's room is open.`,'bad'],full:['That room is full','Ask the host to clear a seat for you.','bad'],
  started:['The game has started','Wait for the round to end, then try again.','bad'],bad:['Check the code','Room codes have 4 letters or numbers.','bad'],
  nonet:['Can\'t reach the internet','Room codes need an internet connection. On the same Wi-Fi you can scan to join instead.','bad'],badinv:['That code didn\'t work','Scan the invite again, or ask the host for a fresh one.','bad']}[state];
 let body='';
 if(msg)body=`<div class="wcjic ${msg[2]}">${msg[2]==='radar'?'<i></i><i></i><i></i><span>'+wcOrb('t',46)+'</span>':'<span>!</span>'}</div><h2>${msg[0]}</h2><p>${msg[1]}</p>${msg[2]==='bad'?`<div class="wcrow">${state==='nonet'||state==='badinv'?'<button class="wcbtn gold" id="wcjs">Scan to join</button>':''}<button class="wcbtn" id="wcjh">Back to the menu</button>${code&&state!=='bad'?`<button class="wcbtn gold" id="wcjr">Try again</button>`:''}</div>`:''}`;
 else if(state==='scan')body=`<h2>Scan to join</h2><p>Point your camera at the QR code in the host's room. No internet needed — you just need the same Wi-Fi.</p><div class="wcscan big" id="wcscan"></div><p class="wcerr" id="wcjse"></p>
  <details class="wcpdet"><summary>No camera? Paste an invite code</summary><textarea id="wcjin" class="wccode in" rows="3" spellcheck="false" placeholder="Paste the invite code"></textarea><button class="wcbtn gold" id="wcjgo">Join</button></details>`;
 else if(state==='reply')body=`<h2>Show this to the host</h2><p>The host taps <i>Scan their reply</i> and points their camera at your screen.</p><div class="wcqr big" id="wcqr"></div><div class="wcrow"><button class="wcbtn sm" id="wcrcp">${WCI.copy}Copy reply code</button></div><p class="wcwait"><i></i>Waiting for the host…</p>`;
 else if(state==='in'){if(!L)body=`<div class="wcjic radar"><i></i><i></i><i></i><span>${wcOrb('g',46)}</span></div><h2>Connected!</h2><p>Getting the table details…</p>`;
  else{const set=L.set,seats=L.seats.map(s=>Object.assign({},s));const poor=set.stake&&P.gold<set.stake;
   body=`<h2>Room <span class="mono">${esc(L.room)}</span></h2><p>You're in! Check the table, then tap Ready.</p>${wcSeatsHTML(seats,false,L.you)}
   <div class="wcjset"><div><span>Buy-in</span><b>${set.stake?cmn(set.stake)+' each':'Free'}</b></div><div><span>Turn timer</span><b>${set.timer?set.timer+' sec':'Off'}</b></div><div><span>Cards in hand</span><b>${set.hand}</b></div><div><span>House rules</span><b>${[set.stack&&'Stacking',set.until&&'Draw till you can',set.seven&&'Lucky sevens'].filter(Boolean).join(', ')||'Standard'}</b></div></div>
   ${poor?`<p class="wcerr">You need ${cmn(set.stake)} gold for this buy-in. You have ${cmn(P.gold)}.</p>`:''}<button class="wcbtn ${g.ready?'ok':'gold'} big" id="wcrdy" ${poor?'disabled':''}>${g.ready?'✓ Ready · waiting for the host to deal':'Ready'}</button>`}}
 show(`<div class="wcj" id="wcj"><div class="wclbg"><i class="wcspot a"></i><i class="wcspot b"></i></div><header class="wclh"><button class="wcpb back" id="wcjl">${WCI.back}<span>Leave</span></button><h1>Join a room</h1></header><div class="wcjs${state==='in'&&L?' wide':''}">${body}</div><div class="wcmod" id="wcmod" hidden></div></div>`,'casbg wcx');
 S.back=()=>{wcNetClose();wcHome()};$('wcjl').onclick=S.back;if($('wcjh'))$('wcjh').onclick=S.back;if($('wcjr'))$('wcjr').onclick=()=>wcJoinCode(code);if($('wcjs'))$('wcjs').onclick=()=>wcJoinView('scan');
 if(msg&&msg[2]==='bad')wcFx('bad');
 if(state==='scan'){const e=$('wcjse');wcScan($('wcscan'),t=>{wcFx('coin');wcJoin(t)},m=>{e.textContent=m;const d=document.querySelector('.wcpdet');if(d)d.open=true});
  const ta=$('wcjin');ta.onkeydown=e=>e.stopPropagation();$('wcjgo').onclick=()=>{if(ta.value.trim())wcJoin(ta.value.trim())}}
 if(state==='reply'){try{$('wcqr').innerHTML=wcQR(g.reply)}catch(e){}$('wcrcp').onclick=()=>wcCopy(g.reply,$('wcrcp'))}
 if(state==='in'&&L){ov.querySelectorAll('canvas[data-sv]').forEach(c=>{const i=+c.dataset.sv,A=i===L.you?wcMyAv():L.seats[i].av||{t:'hero'};if(A&&A.t==='crew')wcLive(c,A,'por');else wcPortrait(c,A)});
  if($('wcrdy'))$('wcrdy').onclick=()=>{g.ready=g.ready?0:1;wcNetSend({t:'ready',v:g.ready});wcFx(g.ready?'ready':'back');wcJoinView('in')}}}
