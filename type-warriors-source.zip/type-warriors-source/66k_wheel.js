/* ---------- wheel of fortune: every slice is a lit slot with its own prize ---------- */
const WN=20,WSEG=TAU/WN,WC=260,WR=206;
const whTier=m=>m===0?'lose':m<1.5?'blue':m<3?'green':m<6?'gold':m<15?'orange':'purple';
const whLab=m=>m===0?'0':fmM(m)+'×';
const WFACE={};
function whFace(k,segs){if(WFACE[k])return WFACE[k];
 const c=cdMk(WC*2,WC*2),g=c.getContext('2d');g.translate(WC,WC);
 const path=(i,r0,r1,ins)=>{const a0=i*WSEG+ins,a1=(i+1)*WSEG-ins;g.beginPath();g.arc(0,0,r1,a0,a1);g.arc(0,0,r0,a1,a0,true);g.closePath()};
 for(let i=0;i<WN;i++){const m=segs[i],col=whCol(m,i);
  path(i,52,WR,0);const q=g.createRadialGradient(0,0,52,0,0,WR);q.addColorStop(0,mixc(col,'#000000',.55));q.addColorStop(.55,col);q.addColorStop(1,mixc(col,'#ffffff',.18));g.fillStyle=q;g.fill();
  /* the recessed slot */
  path(i,84,WR-16,.035);g.fillStyle='rgba(0,0,0,.42)';g.fill();g.lineWidth=2.4;g.strokeStyle='rgba(0,0,0,.65)';g.stroke();
  g.save();g.clip();path(i,84,WR-16,.035);const sg=g.createLinearGradient(0,-WR,0,WR);g.restore();
  path(i,86,WR-18,.05);const ig=g.createRadialGradient(0,0,84,0,0,WR-16);ig.addColorStop(0,mixc(col,'#000000',.62));ig.addColorStop(1,mixc(col,'#000000',.2));g.fillStyle=ig;g.fill();
  g.lineWidth=1.4;g.strokeStyle='rgba(255,255,255,.28)';path(i,84,WR-16,.035);g.stroke();
  /* label */
  g.save();g.rotate((i+.5)*WSEG);g.translate(150,0);g.textAlign='center';g.textBaseline='middle';
  const big=m>=10;g.font=`400 ${big?38:m===0?30:34}px 'Pirata One',Georgia,serif`;g.shadowColor='rgba(0,0,0,.85)';g.shadowBlur=5;g.shadowOffsetY=2;g.fillStyle=m===0?'#8a8aa8':'#fff8e0';g.fillText(whLab(m),0,2);
  if(m>=10){g.shadowBlur=0;g.shadowOffsetY=0;g.fillStyle='#ffe490';g.font='700 16px Georgia,serif';g.fillText('★',-58,0);g.fillText('★',58,0)}
  g.restore();
  /* the lamp at the foot of the slot */
  g.save();g.rotate((i+.5)*WSEG);g.translate(97,0);const lg=g.createRadialGradient(-1,-1,.5,0,0,6);lg.addColorStop(0,m===0?'#8a8aa8':'#fff6c0');lg.addColorStop(1,m===0?'#3a3a50':'#a8801c');g.fillStyle=lg;g.beginPath();g.arc(0,0,5.5,0,TAU);g.fill();g.strokeStyle='#2a1a06';g.lineWidth=1.2;g.stroke();g.restore();
  /* divider */
  g.save();g.rotate(i*WSEG);const dg=g.createLinearGradient(52,0,WR,0);dg.addColorStop(0,'#6a4a10');dg.addColorStop(.5,'#ffe490');dg.addColorStop(1,'#a8801c');g.fillStyle=dg;g.fillRect(52,-2,WR-52,4);g.restore()}
 /* pegs */
 for(let i=0;i<WN;i++){g.save();g.rotate(i*WSEG);g.translate(WR-6,0);const pg=g.createRadialGradient(-1.5,-1.5,.5,0,0,7);pg.addColorStop(0,'#fffbe0');pg.addColorStop(.6,'#e8b02a');pg.addColorStop(1,'#7a4a08');g.fillStyle=pg;g.shadowColor='#000a';g.shadowBlur=4;g.beginPath();g.arc(0,0,6.5,0,TAU);g.fill();g.restore()}
 g.lineWidth=5;g.strokeStyle='#d8a828';g.beginPath();g.arc(0,0,52,0,TAU);g.stroke();
 return WFACE[k]=c}
function whBack(){const c=cdMk(WC*2,WC*2),g=c.getContext('2d');
 g.fillStyle='rgba(0,0,0,.5)';g.beginPath();g.ellipse(WC,WC+14,WR+36,WR+28,0,0,TAU);g.fill();
 let q=g.createRadialGradient(WC-60,WC-80,40,WC,WC,WR+34);q.addColorStop(0,'#fff0a0');q.addColorStop(.35,'#d8a020');q.addColorStop(1,'#6a4208');g.fillStyle=q;g.beginPath();g.arc(WC,WC,WR+30,0,TAU);g.fill();
 g.lineWidth=3;g.strokeStyle='#3a2406';g.beginPath();g.arc(WC,WC,WR+30,0,TAU);g.stroke();
 g.fillStyle='#1a0e04';g.beginPath();g.arc(WC,WC,WR+13,0,TAU);g.fill();
 g.lineWidth=2;g.strokeStyle='#e8c660';g.beginPath();g.arc(WC,WC,WR+13,0,TAU);g.stroke();
 return c}
function mWH(el,tok){
 const alive=()=>CAS.tok===tok;let risk='m',segs=whlSegs(risk),phi=-Math.PI/2,st='idle',bet=0,spin=null,last=performance.now(),lastIdx=-1,lastTick=0,flick=0,win=-1,winT=0,winM=0,hist=[];
 const parts=[];const BACK=whBack();
 el.innerHTML=`<div class="felt whf"><div class="whw"><canvas id="wh" width="${WC*2}" height="${WC*2}"></canvas></div><div class="whp"><h4>Prize slots</h4><div id="wp"></div><div class="whr" id="wrt"></div><h4>Recent spins</h4><div class="whh" id="whh"></div></div></div><p class="cmsg" id="cm"> </p>
<div class="ctl">${betBar()}<div class="ac"><div class="seg2" id="whk">${[['l','Low'],['m','Medium'],['h','High']].map(([v,n])=>`<button data-k="${v}" class="${v==='m'?'on':''}">${n} risk</button>`).join('')}</div></div><div class="btns"><button class="bbig" id="whs">Spin</button></div></div>`;
 const rtp=()=>segs.reduce((a,b)=>a+b,0)/WN;
 const P2=()=>{const c=WHL[risk].c;$('wp').innerHTML=Object.keys(c).map(Number).sort((a,b)=>b-a).map(m=>`<span class="whc ${whTier(m)}" data-m="${m}"><i class="sw" style="background:${whCol(m,0)}"></i><em>${m===0?'Lose':fmM(m)+'×'}</em><b>${c[m]} of ${WN}</b><u>${Math.round(c[m]/WN*100)}%</u></span>`).join('');$('wrt').innerHTML=`Return to player <b>${(rtp()*100).toFixed(0)}%</b>`};
 const H=()=>{$('whh').innerHTML=hist.map((m,i)=>`<span class="${whTier(m)}${i===0?' new':''}">${whLab(m)}</span>`).join('')||'<small>None yet</small>'};
 const spark=(x,y,n,cols,pw)=>{for(let i=0;i<n;i++){const an=Math.random()*TAU,v=(pw||200)*(.3+Math.random());parts.push({x,y,vx:Math.cos(an)*v,vy:Math.sin(an)*v-90,l:1,d:.8+Math.random()*.9,r:2.5+Math.random()*3.5,c:cols[i%cols.length]})}};
 const lock=on=>{ov.querySelectorAll('#whk button').forEach(b=>b.disabled=on);$('whs').disabled=on};
 const spinIt=()=>{if(st!=='idle'||CAS.lock)return;if(CAS.bet<1){msg(broke()||'Place a bet first.');return}if(CAS.bet>P.gold){msg('Not enough gold.');return}bet=CAS.bet;if(!cTake(bet))return;betLock(true);lock(true);win=-1;winM=0;
  ov.querySelectorAll('.whc').forEach(x=>x.classList.remove('hit'));
  const s=Math.floor(Math.random()*WN),off=(Math.random()-.5)*.7,tg=-Math.PI/2-(s+.5+off)*WSEG;let fin=tg;while(fin<phi+TAU*6)fin+=TAU;
  spin={t:0,T:5.8,a:phi,b:fin,s};st='spin';msg('');beep(220,.3,'sawtooth',.3)};
 const finish=()=>{const m=segs[spin.s],pay=Math.floor(bet*m);win=spin.s;winT=performance.now();winM=m;st='idle';stat('whl',m,'max');cPay(bet,pay);hist.unshift(m);hist.length=Math.min(hist.length,8);H();
  const hc=ov.querySelector(`.whc[data-m="${m}"]`);if(hc)hc.classList.add('hit');
  msg(m===0?`The wheel stops on a loss. −${cmn(bet)}.${broke()?' '+broke():''}`:`${fmM(m)}×  +${cmn(pay-bet>0?pay-bet:0)}${pay<=bet?' (only your stake back)':''}`,pay>bet?'w':pay<bet?'l':'');
  if(pay>bet){spark(WC,WC,m>=10?90:40,['#ffe490','#ffd04a','#fff6c0',whCol(m,0)],m>=10?420:260);[0,90,180].forEach((d,i)=>setTimeout(()=>alive()&&beep(660+i*220,.12,'triangle',.4),d))}else if(m===0)beep(150,.25,'sawtooth',.25);else beep(520,.1,'triangle',.3);
  betLock(false);lock(false);spin=null};
 live('wh',cv=>{const g=cv.getContext('2d');
  return()=>{if(!alive())return;const now=performance.now(),dt=Math.min(.05,(now-last)/1000);last=now;
   if(st==='spin'){spin.t+=dt;const u=Math.min(1,spin.t/spin.T),e=1-Math.pow(1-u,4);phi=spin.a+(spin.b-spin.a)*e;if(u>=1){phi=spin.b;finish()}}
   else phi+=dt*.12;
   const idx=((Math.floor(((-Math.PI/2-phi)/WSEG)%WN)%WN)+WN)%WN;if(idx!==lastIdx){lastIdx=idx;if(st==='spin'&&now-lastTick>38){lastTick=now;flick=1;beep(640+(segs[idx]>0?120:0),.02,'square',.14)}}
   flick=Math.max(0,flick-dt*9);
   g.clearRect(0,0,WC*2,WC*2);g.drawImage(BACK,0,0);
   const wa=win>=0?(now-winT)/1000:0;
   g.save();g.translate(WC,WC);g.rotate(phi);g.translate(-WC,-WC);g.drawImage(whFace(risk,segs),0,0);
   if(win>=0){const gl=.5+.5*Math.sin(wa*9);g.translate(WC,WC);g.beginPath();g.arc(0,0,WR-16,win*WSEG+.035,(win+1)*WSEG-.035);g.arc(0,0,84,(win+1)*WSEG-.035,win*WSEG+.035,true);g.closePath();g.fillStyle='rgba(255,236,150,'+(.22+.3*gl)+')';g.fill();g.lineWidth=3;g.strokeStyle='rgba(255,246,190,'+(.6+.4*gl)+')';g.stroke();
    g.save();g.rotate((win+.5)*WSEG);g.translate(97,0);cdGlow(g,0,0,22,'rgba(255,240,150,'+(.5+.5*gl)+')');g.restore()}
   g.restore();
   /* rim bulbs: chase while spinning, pulse when idle, flash gold on a win */
   for(let i=0;i<WN*2;i++){const an=i*WSEG/2-Math.PI/2,x=WC+Math.cos(an)*(WR+21.5),y=WC+Math.sin(an)*(WR+21.5);
    let on=st==='spin'?((i+Math.floor(now/70))%4<2):win>=0&&wa<2.4?((i+Math.floor(now/110))%2===0):((i+Math.floor(now/500))%2===0);
    const gold=win>=0&&wa<2.4&&winM>0;g.fillStyle=on?(gold?'#fff6a0':'#ffe9a0'):'#5a3a10';g.beginPath();g.arc(x,y,4.4,0,TAU);g.fill();if(on)cdGlow(g,x,y,12,gold?'rgba(255,230,100,.65)':'rgba(255,210,90,.4)')}
   /* hub */
   g.save();g.translate(WC,WC);const hb=g.createRadialGradient(-10,-12,4,0,0,50);hb.addColorStop(0,'#fffbe0');hb.addColorStop(.45,'#e8b02a');hb.addColorStop(1,'#7a4a08');g.fillStyle=hb;g.beginPath();g.arc(0,0,48,0,TAU);g.fill();g.strokeStyle='#3a2406';g.lineWidth=4;g.stroke();g.lineWidth=1.5;g.strokeStyle='#fff8';g.beginPath();g.arc(0,0,41,0,TAU);g.stroke();
   if(win>=0&&st==='idle'){const k=Math.min(1,wa/.4),sc=k<1?(1-Math.pow(1-k,3))*(1+.2*Math.sin(k*Math.PI)):1;g.scale(sc,sc);g.fillStyle=winM===0?'#3a3a50':whCol(winM,0);g.beginPath();g.arc(0,0,36,0,TAU);g.fill();g.fillStyle='#fff';g.font=`400 ${whLab(winM).length>3?26:34}px 'Pirata One',Georgia,serif`;g.textAlign='center';g.textBaseline='middle';g.shadowColor='#000';g.shadowBlur=4;g.fillText(whLab(winM),0,2)}
   else{g.fillStyle='#4a2c06';g.font="400 24px 'Pirata One',Georgia,serif";g.textAlign='center';g.textBaseline='middle';g.fillText(st==='spin'?'…':'SPIN',0,2)}
   g.restore();
   /* pointer with a flapper that kicks on every peg */
   g.save();g.translate(WC,WC-WR-24);g.rotate(-flick*.4);g.fillStyle='#e8455a';g.strokeStyle='#fff';g.lineWidth=3;g.shadowColor='#000a';g.shadowBlur=8;g.beginPath();g.moveTo(-18,-26);g.lineTo(18,-26);g.lineTo(0,26);g.closePath();g.fill();g.stroke();g.shadowBlur=0;g.fillStyle='#fff6c0';g.beginPath();g.arc(0,-14,5,0,TAU);g.fill();g.restore();
   if(parts.length){g.save();g.globalCompositeOperation='lighter';for(let i=parts.length-1;i>=0;i--){const p=parts[i];p.l-=dt/p.d;if(p.l<=0){parts.splice(i,1);continue}p.vy+=260*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;g.globalAlpha=Math.min(1,p.l*1.6);g.fillStyle=p.c;g.beginPath();g.arc(p.x,p.y,p.r*p.l+.6,0,TAU);g.fill()}g.restore()}
  }});
 ov.querySelectorAll('#whk button').forEach(b=>b.onclick=()=>{if(st!=='idle')return;risk=b.dataset.k;segs=whlSegs(risk);win=-1;P2();ov.querySelectorAll('#whk button').forEach(x=>x.classList.toggle('on',x===b));beep(560,.05,'triangle',.4)});
 $('whs').onclick=spinIt;wireBet();CAS.key={' ':spinIt,enter:spinIt};P2();H();
 msg('Pick a risk level, place your bet and spin. Every slot is lit. Space spins.')}
