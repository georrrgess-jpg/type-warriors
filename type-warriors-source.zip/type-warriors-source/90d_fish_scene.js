/* ===== MOONLIT FISHING: the pond scene =====
   One 1600x900 canvas. The still parts (sky, moon, castle, far shore, bridge, tavern, dock, water base, lily pads) are
   painted once into a cached layer; each frame adds only the moving parts: star twinkle, moon shimmer on the water,
   ripples, reeds, fish shadows, fireflies, willow fronds, the hero with the rod, the line, the bobber and the effects.
   fsScene(g,t,V) draws a frame from the view state V (built by the game, 90e). Reduced motion freezes ambient motion. */
const FSW_Y=520;/* far shoreline / top of the water */
const FSDOCK={x0:150,x1:600,y:648};
const FSHERO={x:500,y:650,s:1.5};
let FSBG=null,FSFF=null;
const fsRnd=s=>{let x=Math.sin(s*12.9898)*43758.5453;return x-Math.floor(x)};
/* ---------- cached still layer ---------- */
function fsBGBuild(){const c=document.createElement('canvas');c.width=1600;c.height=900;const g=c.getContext('2d');g.lineJoin='round';g.lineCap='round';
 /* sky */
 g.fillStyle=fkLin(g,0,0,0,FSW_Y,['#070420','#14104a','#2c1d6e','#4a2e86']);g.fillRect(0,0,1600,FSW_Y+4);
 fkGlow(g,930,170,520,'#5a48c0',.32);fkGlow(g,930,160,240,'#c8c0ff',.22);
 for(let i=0;i<220;i++){const x=fsRnd(i)*1600,y=fsRnd(i+500)*(FSW_Y-60),r=fsRnd(i+900)<.08?1.7:fsRnd(i+900)<.4?1.1:.7;g.globalAlpha=.35+fsRnd(i+77)*.6;g.fillStyle=fsRnd(i+3)<.15?'#ffe6b0':'#f0eaff';g.beginPath();g.arc(x,y,r,0,TAU);g.fill()}g.globalAlpha=1;
 /* wisps of cloud */
 const cloud=(x,y,w,a)=>{g.save();g.globalAlpha=a;g.fillStyle='#8a7ad0';for(let i=0;i<6;i++){g.beginPath();g.ellipse(x+i*w*.18-w*.45,y+Math.sin(i*1.7)*6,w*.2,10+fsRnd(i+x)*8,0,0,TAU);g.fill()}g.restore()};
 cloud(400,120,360,.10);cloud(1260,90,420,.09);cloud(760,250,300,.07);
 /* the moon */
 fkGlow(g,930,160,150,'#fff4d0',.35);
 g.beginPath();g.arc(930,160,64,0,TAU);g.fillStyle=fkRad(g,930,160,64,['#fffdf0','#f6eccc','#d8ccaa']);g.fill();
 g.save();g.beginPath();g.arc(930,160,64,0,TAU);g.clip();g.fillStyle='#c8bc9a';[[905,140,12],[952,178,15],[944,128,7],[910,186,8],[968,150,6]].forEach(([x,y,r])=>{g.globalAlpha=.45;g.beginPath();g.arc(x,y,r,0,TAU);g.fill()});g.globalAlpha=1;
 g.fillStyle='#ffffff22';g.beginPath();g.arc(915,140,58,0,TAU);g.fill();g.restore();
 /* far hills */
 g.fillStyle='#22165a';g.beginPath();g.moveTo(0,FSW_Y);for(let x=0;x<=1600;x+=40)g.lineTo(x,FSW_Y-60-Math.sin(x*.004)*26-Math.sin(x*.011+1)*14);g.lineTo(1600,FSW_Y);g.fill();
 /* the castle on the hill */
 const cx=760;g.fillStyle='#1a1046';
 const tower=(x,w,h,sp)=>{g.fillRect(x-w/2,FSW_Y-h,w,h);g.beginPath();g.moveTo(x-w/2-5,FSW_Y-h);g.lineTo(x,FSW_Y-h-sp);g.lineTo(x+w/2+5,FSW_Y-h);g.fill()};
 g.fillRect(cx-170,FSW_Y-150,340,150);tower(cx-150,34,200,54);tower(cx-70,42,250,70);tower(cx+10,54,300,96);tower(cx+95,40,232,62);tower(cx+165,30,180,48);tower(cx-200,24,130,34);tower(cx+215,26,140,38);
 for(let i=0;i<14;i++)g.fillRect(cx-170+i*25,FSW_Y-162,13,14);
 const win=(x,y)=>{fkGlow(g,x,y,16,'#ffb44a',.5);g.fillStyle='#ffd27a';g.fillRect(x-3,y-5,6,10);g.fillStyle='#1a1046'};
 [[cx-150,FSW_Y-160],[cx-70,FSW_Y-210],[cx-70,FSW_Y-160],[cx+10,FSW_Y-250],[cx+10,FSW_Y-196],[cx+95,FSW_Y-190],[cx+165,FSW_Y-140],[cx-30,FSW_Y-100],[cx+50,FSW_Y-110],[cx+130,FSW_Y-90]].forEach(([x,y])=>win(x,y));
 g.fillStyle='#1a1046';g.beginPath();g.moveTo(cx+10,FSW_Y-396);g.lineTo(cx+10,FSW_Y-420);g.lineTo(cx+34,FSW_Y-412);g.lineTo(cx+10,FSW_Y-404);g.fill();
 /* far treeline */
 g.fillStyle='#120a34';g.beginPath();g.moveTo(0,FSW_Y+2);for(let x=0;x<=1600;x+=18){const h=24+fsRnd(x)*30;g.lineTo(x,FSW_Y-h*.6);g.lineTo(x+9,FSW_Y-h)}g.lineTo(1600,FSW_Y+2);g.fill();
 /* stone bridge on the right */
 const by=FSW_Y-36;g.fillStyle='#2a1f5a';g.fillRect(960,by,560,22);g.fillStyle='#1d1448';g.fillRect(960,by+22,560,34);
 g.fillStyle='#120a30';for(let i=0;i<5;i++){const ax=1000+i*112;g.beginPath();g.moveTo(ax-44,by+56);g.lineTo(ax-44,by+40);g.quadraticCurveTo(ax,by+4,ax+44,by+40);g.lineTo(ax+44,by+56);g.fill()}
 g.fillStyle='#3a2e74';for(let i=0;i<29;i++)g.fillRect(962+i*19.5,by-10,9,10);g.fillStyle='#3a2e74';g.fillRect(960,by-2,560,3);
 for(let i=0;i<4;i++){const lx=1030+i*150;g.fillStyle='#120a30';g.fillRect(lx-2,by-34,4,26);fkGlow(g,lx,by-38,30,'#ffb44a',.55);g.fillStyle='#ffd88a';g.beginPath();g.arc(lx,by-38,4,0,TAU);g.fill()}
 /* water base */
 g.fillStyle=fkLin(g,0,FSW_Y,0,900,['#2a1f6a','#1a1350','#100b38','#0a0726']);g.fillRect(0,FSW_Y,1600,380);
 /* reflections of the shore, castle and bridge (soft, darker, squashed) */
 {const R=document.createElement('canvas');R.width=1600;R.height=260;const r=R.getContext('2d');r.translate(0,260);r.scale(1,-1);r.drawImage(c,0,FSW_Y-260,1600,260,0,0,1600,260);r.setTransform(1,0,0,1,0,0);
  r.globalCompositeOperation='destination-in';const m=r.createLinearGradient(0,0,0,260);m.addColorStop(0,'#000000');m.addColorStop(.55,'#00000080');m.addColorStop(1,'#00000000');r.fillStyle=m;r.fillRect(0,0,1600,260);
  g.save();g.globalAlpha=.34;g.drawImage(R,0,FSW_Y+4,1600,260);g.restore()}
 g.fillStyle=fkLin(g,0,FSW_Y,0,FSW_Y+240,['#1a135000','#14104490','#0e0a34e0']);g.fillRect(0,FSW_Y,1600,240);
 /* moon path base glow on the water */
 {const M=document.createElement('canvas');M.width=600;M.height=380;const m=M.getContext('2d');const hx=m.createLinearGradient(0,0,600,0);hx.addColorStop(0,'#fff4d000');hx.addColorStop(.38,'#fff4d018');hx.addColorStop(.5,'#fff4d040');hx.addColorStop(.62,'#fff4d018');hx.addColorStop(1,'#fff4d000');m.fillStyle=hx;m.fillRect(0,0,600,380);
  m.globalCompositeOperation='destination-in';const vy=m.createLinearGradient(0,0,0,380);vy.addColorStop(0,'#000');vy.addColorStop(1,'#0000');m.fillStyle=vy;m.fillRect(0,0,600,380);
  g.save();g.globalCompositeOperation='lighter';g.translate(960,FSW_Y);g.transform(1,0,.1,1,0,0);g.drawImage(M,-300,0,600,380);g.restore()}
 /* bridge lantern reflections */
 for(let i=0;i<4;i++){const lx=1030+i*150;for(let k=0;k<5;k++){g.globalAlpha=.22-k*.035;g.fillStyle='#ffb44a';g.fillRect(lx-10+k*2,FSW_Y+18+k*12,20-k*4,3)}}g.globalAlpha=1;
 /* lily pads (static) */
 FSLILY.forEach(L=>fsLilyPad(g,L));
 /* the tavern */
 fsTavern(g);
 /* the dock */
 fsDock(g);
 /* near shore under the tavern: dark bank with grass */
 g.fillStyle='#0e0a24';g.beginPath();g.moveTo(0,620);g.quadraticCurveTo(120,640,170,700);g.quadraticCurveTo(190,790,120,900);g.lineTo(0,900);g.fill();
 for(let i=0;i<40;i++){const x=fsRnd(i+40)*190,y=640+fsRnd(i+41)*250,h=14+fsRnd(i+42)*22;g.strokeStyle=i%3?'#1c3a2a':'#24503a';g.lineWidth=2.4;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+4,y-h*.6,x+(fsRnd(i)-.5)*12,y-h);g.stroke()}
 return c}
const FSLILY=[{x:640,y:760,r:40,a:.2,f:1},{x:700,y:800,r:28,a:2.4},{x:590,y:820,r:24,a:1.2},{x:1090,y:660,r:34,a:3.1,f:1},{x:1040,y:690,r:22,a:.8},{x:1150,y:820,r:44,a:1.9,f:1},{x:830,y:870,r:30,a:.4}];
function fsLilyPad(g,L){g.save();g.translate(L.x,L.y);g.scale(1,.42);g.beginPath();g.moveTo(0,0);g.arc(0,0,L.r,L.a+.32,L.a-.32+TAU);g.closePath();g.fillStyle=fkLin(g,-L.r,-L.r,L.r,L.r,['#4aa060','#2a6a3e']);g.fill();g.lineWidth=3;g.strokeStyle=FKO;g.stroke();
 g.strokeStyle='#ffffff30';g.lineWidth=2;for(let i=0;i<5;i++){const a=L.a+.6+i*1.1;g.beginPath();g.moveTo(0,0);g.lineTo(Math.cos(a)*L.r*.85,Math.sin(a)*L.r*.85);g.stroke()}g.restore()}
/* a pink lotus (drawn live so it can glow softly) */
function fsLotus(g,x,y,s,t){fkGlow(g,x,y-6*s,40*s,'#ff7ad8',.28+.08*Math.sin(t*1.6+x));
 const pet=(a,l,w,c1,c2)=>{g.save();g.translate(x,y);g.rotate(a);g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(-w*s,-l*s*.55,0,-l*s);g.quadraticCurveTo(w*s,-l*s*.55,0,0);g.fillStyle=fkLin(g,0,0,0,-l*s,[c1,c2]);g.fill();g.lineWidth=2;g.strokeStyle=FKO;g.stroke();g.restore()};
 [-1.2,1.2,-.7,.7].forEach(a=>pet(a,20,8,'#c84aa8','#ff9ae0'));[-.3,.3,0].forEach(a=>pet(a,26,9,'#e86ac0','#ffe0f6'));fkGlow(g,x,y-8*s,10*s,'#ffe9a0',.6)}
function fsTavern(g){
 /* back wall and roof */
 g.fillStyle='#2a1a2e';g.fillRect(0,170,300,470);
 const wood=fkLin(g,0,170,300,640,['#5a3a2a','#3a2418']);g.fillStyle=wood;g.fillRect(0,200,286,440);
 g.strokeStyle='#24140e';g.lineWidth=2;for(let y=220;y<640;y+=26){g.beginPath();g.moveTo(0,y);g.lineTo(286,y);g.stroke()}
 /* timber frame */
 g.fillStyle='#2a180e';[[0,196,286,14],[0,420,286,14],[0,626,286,14],[60,196,14,444],[200,196,14,444],[272,196,14,444]].forEach(r=>g.fillRect(...r));
 g.lineWidth=3;g.strokeStyle=FKO;g.strokeRect(0,196,286,444);
 /* roof */
 g.beginPath();g.moveTo(-20,210);g.lineTo(150,40);g.lineTo(320,210);g.closePath();g.fillStyle=fkLin(g,0,40,0,210,['#5a2a3a','#3a1626']);g.fill();g.lineWidth=4;g.strokeStyle=FKO;g.stroke();
 g.strokeStyle='#2a0e1a';g.lineWidth=2;for(let i=1;i<7;i++){const y=40+i*24.3,w=(y-40)*1;g.beginPath();g.moveTo(150-w,y);g.lineTo(150+w,y);g.stroke()}
 g.fillStyle='#2a180e';g.fillRect(222,70,34,90);g.strokeStyle=FKO;g.lineWidth=3;g.strokeRect(222,70,34,90);
 /* windows with warm light */
 const win=(x,y,w,h)=>{fkGlow(g,x+w/2,y+h/2,w*1.6,'#ffaa3a',.42);g.fillStyle=fkLin(g,x,y,x,y+h,['#ffe7a0','#ffb04a','#e07a20']);g.beginPath();g.moveTo(x,y+h);g.lineTo(x,y+w/2);g.arc(x+w/2,y+w/2,w/2,Math.PI,0);g.lineTo(x+w,y+h);g.closePath();g.fill();g.lineWidth=4;g.strokeStyle='#2a180e';g.stroke();
  g.lineWidth=3;g.beginPath();g.moveTo(x+w/2,y);g.lineTo(x+w/2,y+h);g.moveTo(x,y+h*.55);g.lineTo(x+w,y+h*.55);g.stroke();g.fillStyle='#ffffff40';g.fillRect(x+5,y+w*.5,w*.3,h*.25)};
 win(92,240,82,130);win(110,470,64,100);win(226,470,40,96);
 /* the door */
 g.fillStyle=fkLin(g,0,500,0,640,['#4a2a1a','#2a160c']);g.beginPath();g.moveTo(10,640);g.lineTo(10,530);g.arc(40,530,30,Math.PI,0);g.lineTo(70,640);g.fill();g.lineWidth=3;g.strokeStyle=FKO;g.stroke();
 /* hanging sign with a mug */
 g.strokeStyle='#2a180e';g.lineWidth=6;g.beginPath();g.moveTo(286,262);g.lineTo(356,262);g.stroke();g.lineWidth=2;g.strokeStyle='#1a1008';g.beginPath();g.moveTo(304,262);g.lineTo(304,282);g.moveTo(342,262);g.lineTo(342,282);g.stroke();
 g.fillStyle='#3a2a6a';g.beginPath();g.moveTo(290,282);g.lineTo(356,282);g.lineTo(356,334);g.lineTo(323,352);g.lineTo(290,334);g.closePath();g.fill();g.lineWidth=3;g.strokeStyle='#e6b93e';g.stroke();
 g.fillStyle='#e6b93e';g.fillRect(312,298,18,24);g.beginPath();g.arc(332,310,6,-1.4,1.4);g.lineWidth=3;g.strokeStyle='#e6b93e';g.stroke();g.fillStyle='#fff8e8';g.beginPath();g.ellipse(321,298,11,5,0,0,TAU);g.fill();
 /* a lantern by the door */
 g.strokeStyle='#1a1008';g.lineWidth=3;g.beginPath();g.moveTo(86,500);g.lineTo(98,500);g.lineTo(98,512);g.stroke();
 /* barrels and a crate on the porch */
 const barrel=(x,y,s)=>{g.save();g.translate(x,y);g.scale(s,s);g.beginPath();g.moveTo(-22,0);g.quadraticCurveTo(-28,-30,-22,-60);g.lineTo(22,-60);g.quadraticCurveTo(28,-30,22,0);g.closePath();g.fillStyle=fkLin(g,-25,0,25,0,['#8a5a32','#5a3418']);g.fill();g.lineWidth=3;g.strokeStyle=FKO;g.stroke();
  g.strokeStyle='#2a2a34';g.lineWidth=4;[-50,-10].forEach(yy=>{g.beginPath();g.moveTo(-25,yy);g.lineTo(25,yy);g.stroke()});g.fillStyle='#3a2414';g.beginPath();g.ellipse(0,-60,22,6,0,0,TAU);g.fill();g.restore()};
 barrel(230,648,1);barrel(268,650,.85);
 g.fillStyle='#6a4426';g.fillRect(150,600,52,48);g.lineWidth=3;g.strokeStyle=FKO;g.strokeRect(150,600,52,48);g.strokeStyle='#3a2414';g.beginPath();g.moveTo(150,600);g.lineTo(202,648);g.moveTo(202,600);g.lineTo(150,648);g.stroke();
 /* banner */
 g.fillStyle='#3a2a7a';g.beginPath();g.moveTo(14,250);g.lineTo(54,250);g.lineTo(54,330);g.lineTo(34,316);g.lineTo(14,330);g.closePath();g.fill();g.lineWidth=2.5;g.strokeStyle='#e6b93e';g.stroke();g.fillStyle='#e6b93e';g.fillRect(28,268,12,16);g.beginPath();g.arc(34,268,7,Math.PI,0);g.fill()}
function fsDock(g){const D=FSDOCK;
 /* posts in the water */
 for(let i=0;i<6;i++){const x=D.x0+40+i*80;g.fillStyle=fkLin(g,x-9,0,x+9,0,['#5a3a22','#2e1c10']);g.fillRect(x-9,D.y,18,110-(i%2)*20);g.lineWidth=2.5;g.strokeStyle=FKO;g.strokeRect(x-9,D.y,18,110-(i%2)*20);
  g.fillStyle='#ffffff14';g.fillRect(x-14,D.y+92-(i%2)*20,28,4)}
 /* deck: planks seen slightly from above */
 g.beginPath();g.moveTo(D.x0-20,D.y-30);g.lineTo(D.x1,D.y-22);g.lineTo(D.x1+8,D.y+8);g.lineTo(D.x0-20,D.y+14);g.closePath();g.fillStyle=fkLin(g,0,D.y-30,0,D.y+14,['#9a6a3e','#6a4426']);g.fill();g.lineWidth=3;g.strokeStyle=FKO;g.stroke();
 g.strokeStyle='#3a2414';g.lineWidth=1.6;for(let i=1;i<14;i++){const x=D.x0-20+i*(D.x1-D.x0+20)/14;g.beginPath();g.moveTo(x,D.y-30+i*.6);g.lineTo(x+2,D.y+12);g.stroke()}
 g.strokeStyle='#ffffff26';g.lineWidth=2;g.beginPath();g.moveTo(D.x0-18,D.y-27);g.lineTo(D.x1-2,D.y-19);g.stroke();
 g.fillStyle='#3a2414';g.beginPath();g.moveTo(D.x0-20,D.y+14);g.lineTo(D.x1+8,D.y+8);g.lineTo(D.x1+8,D.y+24);g.lineTo(D.x0-20,D.y+30);g.closePath();g.fill();g.lineWidth=2.5;g.strokeStyle=FKO;g.stroke();
 /* two tall lantern posts and a rope rail */
 [[D.x0+110,0],[D.x1-12,1]].forEach(([x])=>{g.fillStyle=fkLin(g,x-7,0,x+7,0,['#7a4e2c','#3a2414']);g.fillRect(x-7,D.y-120,14,110);g.lineWidth=2.5;g.strokeStyle=FKO;g.strokeRect(x-7,D.y-120,14,110)});
 g.strokeStyle='#c8a46a';g.lineWidth=3;g.beginPath();g.moveTo(D.x0+110,D.y-96);g.quadraticCurveTo((D.x0+D.x1)/2+50,D.y-60,D.x1-12,D.y-96);g.stroke()}
/* lantern on a post (live, it flickers) */
function fsLantern(g,x,y,t){const f=.85+.15*Math.sin(t*9+x)*Math.sin(t*5.3);fkGlow(g,x,y,110*f,'#ffa53a',.32);fkGlow(g,x,y,40,'#ffe6a0',.5*f);
 g.fillStyle='#2a1a10';g.fillRect(x-14,y-26,28,6);g.beginPath();g.moveTo(x-10,y-26);g.lineTo(x,y-38);g.lineTo(x+10,y-26);g.fill();
 g.fillStyle=fkLin(g,0,y-20,0,y+16,['#ffe9a0','#ffae3a']);g.fillRect(x-10,y-20,20,34);g.lineWidth=3;g.strokeStyle='#2a1a10';g.strokeRect(x-10,y-20,20,34);g.beginPath();g.moveTo(x,y-20);g.lineTo(x,y+14);g.stroke();g.fillStyle='#2a1a10';g.fillRect(x-13,y+14,26,5)}
/* willow fronds hanging from the top edge (cached sprite, swayed live) */
function fsWillowSprite(flip){const c=document.createElement('canvas');c.width=420;c.height=520;const g=c.getContext('2d');g.lineCap='round';
 for(let i=0;i<10;i++){const x=10+i*30+fsRnd(i+flip*31)*20,L=(i<4?260:120)+fsRnd(i+7+flip)*(i<4?220:140),b=(fsRnd(i+9)-.5)*60;g.strokeStyle=i%2?'#1e3a26':'#28503a';g.lineWidth=2.2;g.beginPath();g.moveTo(x,0);g.quadraticCurveTo(x+b,L*.5,x+b*.4,L);g.stroke();
  for(let k=0;k<L/14;k++){const u=k/(L/14),px=x+b*(2*u*(1-u))+b*.4*u*u,py=L*u,s=k%2?1:-1;g.fillStyle=k%3?'#2e6a42':'#3e8a52';g.save();g.translate(px,py);g.rotate(s*.7+.1);g.beginPath();g.ellipse(s*5,0,7,2.6,0,0,TAU);g.fill();g.restore()}}
 return c}
/* firefly sprite */
function fsFFSprite(){const c=document.createElement('canvas');c.width=c.height=48;const g=c.getContext('2d');const q=g.createRadialGradient(24,24,0,24,24,24);q.addColorStop(0,'#fffbd0ff');q.addColorStop(.18,'#ffe86acc');q.addColorStop(.5,'#ffd24a33');q.addColorStop(1,'#ffd24a00');g.fillStyle=q;g.fillRect(0,0,48,48);return c}
/* ---------- the rod, line and bobber ---------- */
function fsSkin(){return FSKIN[fsP().skin]||FSKIN.willow}
/* draws the rod from the hand (hx,hy) at angle a with bend b (0..1, how hard a fish pulls); returns the tip point */
function fsRod(g,hx,hy,a,b,len,t,sk){sk=sk||fsSkin();const tx=hx+Math.cos(a)*len,ty=hy+Math.sin(a)*len,mx=hx+Math.cos(a)*len*.55,my=hy+Math.sin(a)*len*.55,bx=tx+b*len*.08,by=ty+b*len*.34;
 const cpx=mx+(-Math.sin(a))*-b*len*.12,cpy=my+Math.cos(a)*-b*len*.12+b*len*.12;
 const seg=(w,c)=>{g.strokeStyle=c;g.lineWidth=w;g.beginPath();g.moveTo(hx-Math.cos(a)*26,hy-Math.sin(a)*26);g.quadraticCurveTo(cpx,cpy,bx,by);g.stroke()};
 g.lineCap='round';seg(9,FKO);seg(5.5,sk.c[0]);seg(2.2,sk.c[1]);
 if(sk.rb){const n=6;for(let i=0;i<n;i++){const u=.3+i*.11,x=(1-u)*(1-u)*hx+2*u*(1-u)*cpx+u*u*bx,y=(1-u)*(1-u)*hy+2*u*(1-u)*cpy+u*u*by;g.fillStyle=`hsl(${(t*80+i*50)%360},90%,70%)`;g.beginPath();g.arc(x,y,2.4,0,TAU);g.fill()}}
 /* guides */
 for(let i=1;i<4;i++){const u=i*.24,x=(1-u)*(1-u)*hx+2*u*(1-u)*cpx+u*u*bx,y=(1-u)*(1-u)*hy+2*u*(1-u)*cpy+u*u*by;g.fillStyle='#e6e0f0';g.beginPath();g.arc(x,y+2,2.2,0,TAU);g.fill()}
 /* grip and reel */
 const gx=hx-Math.cos(a)*14,gy=hy-Math.sin(a)*14;g.strokeStyle=FKO;g.lineWidth=12;g.beginPath();g.moveTo(hx-Math.cos(a)*30,hy-Math.sin(a)*30);g.lineTo(hx+Math.cos(a)*4,hy+Math.sin(a)*4);g.stroke();g.strokeStyle='#c8945a';g.lineWidth=8;g.stroke();
 g.save();g.translate(gx+Math.sin(a)*9,gy-Math.cos(a)*-9);g.beginPath();g.arc(0,0,8,0,TAU);g.fillStyle=fkRad(g,0,0,8,['#f4f0ff','#9a94b8','#5a5478']);g.fill();g.lineWidth=2.4;g.strokeStyle=FKO;g.stroke();g.rotate(t*(b>.2?14:0));g.strokeStyle='#5a5478';g.lineWidth=2;g.beginPath();g.moveTo(-5,0);g.lineTo(5,0);g.stroke();g.restore();
 if(sk.gl)fkGlow(g,bx,by,22,sk.gl,.55+.2*Math.sin(t*3));g.fillStyle=sk.tip;g.beginPath();g.arc(bx,by,2.6,0,TAU);g.fill();
 return{x:bx,y:by}}
function fsBobber(g,x,y,t,dip,sk){sk=sk||fsSkin();const bob=Math.sin(t*2.4)*1.6;y+=bob+dip*16;
 if(dip<.9){g.save();g.beginPath();g.rect(x-20,y-30,40,30+Math.max(0,8-dip*8));g.clip();
  g.beginPath();g.arc(x,y-6,8,0,TAU);g.fillStyle=fkRad(g,x,y-6,8,[shade(sk.bob[1],.2),sk.bob[1],shade(sk.bob[1],-.25)]);g.fill();
  g.save();g.beginPath();g.arc(x,y-6,8,0,TAU);g.clip();g.fillStyle=sk.bob[0];g.fillRect(x-9,y-16,18,9);g.restore();g.lineWidth=2.4;g.strokeStyle=FKO;g.beginPath();g.arc(x,y-6,8,0,TAU);g.stroke();
  g.strokeStyle=FKO;g.lineWidth=2;g.beginPath();g.moveTo(x,y-14);g.lineTo(x,y-20);g.stroke();g.fillStyle='#ffffff99';g.beginPath();g.arc(x-3,y-9,2.2,0,TAU);g.fill();g.restore()}
 g.save();g.strokeStyle='#ffffff40';g.lineWidth=1.6;g.beginPath();g.ellipse(x,y,12+Math.sin(t*2.4)*2,3.4,0,0,TAU);g.stroke();g.restore();return{x,y:y-20}}
/* the fishing line from the rod tip to the bobber: sags when slack, straight when taut */
function fsLine(g,a,b,slack,col,vib){const mx=(a.x+b.x)/2,my=(a.y+b.y)/2+slack*70;g.strokeStyle=col||'#f4ecd8';g.globalAlpha=.85;g.lineWidth=1.6;g.beginPath();g.moveTo(a.x,a.y);
 if(vib>.05){const dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy)||1,nx=-dy/d,ny=dx/d,T=performance.now()/1000;for(let i=1;i<=18;i++){const u=i/18,x=(1-u)*(1-u)*a.x+2*u*(1-u)*mx+u*u*b.x,y=(1-u)*(1-u)*a.y+2*u*(1-u)*my+u*u*b.y,o=Math.sin(i*2.1+T*46)*vib*Math.sin(u*Math.PI);g.lineTo(x+nx*o,y+ny*o)}}else g.quadraticCurveTo(mx,my,b.x,b.y);g.stroke();g.globalAlpha=1}
/* ---------- a frame ---------- */
/* other fishing spots paint themselves (FSLOCART[k] = {bg(g), back(g,t), front(g,t)}; see 90k1/90k2) */
const FSLOCART={},FSBGS={};
function fsSceneLoc(g,t,V,k){const A=FSLOCART[k],rm=!!V.rm,ta=rm?0:t;if(!FSFF)FSFF={ff:fsFFSprite(),wl:fsWillowSprite(0),wr:fsWillowSprite(1)};
 if(!FSBGS[k]){const c=document.createElement('canvas');c.width=1600;c.height=900;const cg=c.getContext('2d');cg.lineJoin='round';cg.lineCap='round';try{A.bg(cg)}catch(e){console.error(e)}FSBGS[k]=c}
 g.setTransform(1,0,0,1,0,0);const sh=V.shake||0;if(sh)g.translate((Math.random()-.5)*sh,(Math.random()-.5)*sh);
 g.drawImage(FSBGS[k],0,0);try{A.back&&A.back(g,ta)}catch(e){}
 (V.shadows||[]).forEach(s=>{g.save();g.translate(s.x,s.y);g.scale(s.dir,1);g.globalAlpha=s.a;g.fillStyle='#05031a';g.beginPath();g.ellipse(0,0,s.r,s.r*.32,0,0,TAU);g.fill();g.beginPath();g.moveTo(-s.r*.9,0);g.lineTo(-s.r*1.5,-s.r*.3);g.lineTo(-s.r*1.5,s.r*.3);g.fill();g.restore()});g.globalAlpha=1;
 if(!V.noHero)fsHero(g,ta,V);if(V.fx)V.fx(g,t);try{A.front&&A.front(g,ta)}catch(e){}
 if(!FSFF.ov2){const c=document.createElement('canvas');c.width=1600;c.height=900;const o=c.getContext('2d');const vg=o.createRadialGradient(800,460,380,800,460,1000);vg.addColorStop(0,'#00000000');vg.addColorStop(1,'#000000a0');o.fillStyle=vg;o.fillRect(0,0,1600,900);FSFF.ov2=c}
 g.drawImage(FSFF.ov2,0,0);if(V.dim){g.fillStyle=`rgba(4,2,16,${V.dim})`;g.fillRect(0,0,1600,900)}}
function fsScene(g,t,V){{const k=V.loc||(typeof fsLoc==='function'&&P.fish?fsLoc():'pond');if(k!=='pond'&&FSLOCART[k]&&FSLOCART[k].bg)return fsSceneLoc(g,t,V,k)}if(!FSBG)FSBG=fsBGBuild();if(!FSFF)FSFF={ff:fsFFSprite(),wl:fsWillowSprite(0),wr:fsWillowSprite(1)};const rm=!!V.rm,ta=rm?0:t;
 g.setTransform(1,0,0,1,0,0);
 const sh=V.shake||0;if(sh){g.translate((Math.random()-.5)*sh,(Math.random()-.5)*sh)}
 g.drawImage(FSBG,0,0);
 /* twinkling stars */
 for(let i=0;i<26;i++){const x=fsRnd(i+300)*1600,y=fsRnd(i+600)*(FSW_Y-120),a=.5+.5*Math.sin(ta*(1.2+fsRnd(i)*1.6)+i*2);fkSpark(g,x,y,2+fsRnd(i+4)*3,'#fff6dc',a*.85)}
 /* the moon breathes a little (brighter during a legendary catch) */
 fkGlow(g,930,160,130+(V.moonUp||0)*160,'#fff2c8',.10+.04*Math.sin(ta*.7)+(V.moonUp||0)*.45);
 /* moonlight shimmer on the water */
 g.save();g.globalCompositeOperation='lighter';for(let i=0;i<34;i++){const u=i/34,y=FSW_Y+10+u*u*370,w=(18+u*120)*(.6+.4*Math.sin(ta*1.3+i*1.7)),x=930+(u*60)+Math.sin(ta*.9+i*2.3)*(10+u*40);g.globalAlpha=(.45-u*.3)*(.5+.5*Math.sin(ta*2+i));g.fillStyle='#fff4d0';g.fillRect(x-w/2,y,w,2+u*2)}g.restore();g.globalAlpha=1;
 /* slow ripple rings */
 for(let i=0;i<5;i++){const p=((ta*.18+i*.21)%1),x=700+fsRnd(i+70)*620,y=600+fsRnd(i+71)*230;g.strokeStyle=`rgba(200,190,255,${(1-p)*.22})`;g.lineWidth=1.4;g.beginPath();g.ellipse(x,y,10+p*60,(10+p*60)*.28,0,0,TAU);g.stroke()}
 /* fish shadows swimming under the surface */
 (V.shadows||[]).forEach(s=>{g.save();g.translate(s.x,s.y);g.scale(s.dir,1);g.globalAlpha=s.a;g.fillStyle='#05031a';g.beginPath();g.ellipse(0,0,s.r,s.r*.32,0,0,TAU);g.fill();g.beginPath();g.moveTo(-s.r*.9,0);g.lineTo(-s.r*1.5,-s.r*.3+Math.sin(ta*6+s.ph)*s.r*.1);g.lineTo(-s.r*1.5,s.r*.3+Math.sin(ta*6+s.ph)*s.r*.1);g.fill();g.restore()});g.globalAlpha=1;
 /* lotus flowers */
 FSLILY.filter(L=>L.f).forEach(L=>fsLotus(g,L.x+4,L.y-2,L.r/40,ta));
 /* lanterns */
 fsLantern(g,FSDOCK.x0+110,FSDOCK.y-134,ta);fsLantern(g,FSDOCK.x1-12,FSDOCK.y-134,ta);fsLantern(g,92,520,ta);
 /* reeds and cattails at the right of the dock and by the near bank */
 const reed=(x,y,h,ph,cat)=>{const sw=Math.sin(ta*1.1+ph)*6;g.strokeStyle='#1e4630';g.lineWidth=3;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+sw*.3,y-h*.6,x+sw,y-h);g.stroke();if(cat){g.fillStyle='#6a3e22';g.beginPath();g.ellipse(x+sw,y-h-8,4,11,sw*.02,0,TAU);g.fill();g.lineWidth=1.6;g.strokeStyle=FKO;g.stroke()}};
 for(let i=0;i<14;i++)reed(610+i*9+fsRnd(i)*6,690+fsRnd(i+3)*20,60+fsRnd(i+5)*70,i,i%3===0);
 for(let i=0;i<9;i++)reed(1015+i*10,880+fsRnd(i+8)*10,60+fsRnd(i+9)*60,i+3,i%4===1);
 /* the hero, pet, rod, line and bobber */
 if(!V.noHero)fsHero(g,ta,V);
 /* effects behind the HUD */
 if(V.fx)V.fx(g,t);
 /* willow fronds from the top corners */
 g.save();g.translate(-40,-10);g.rotate(Math.sin(ta*.5)*.012);g.drawImage(FSFF.wl,0,0);g.restore();
 g.save();g.translate(1640,-10);g.scale(-1,1);g.rotate(Math.sin(ta*.45+1)*.012);g.drawImage(FSFF.wr,0,0);g.restore();
 /* fireflies */
 g.save();g.globalCompositeOperation='lighter';for(let i=0;i<26;i++){const x=(fsRnd(i+1)*1700+ta*(8+fsRnd(i+2)*14)*(i%2?1:-1)+Math.sin(ta*.7+i)*40)%1700-50,y=380+fsRnd(i+3)*480+Math.sin(ta*.9+i*1.3)*26,a=.35+.65*Math.max(0,Math.sin(ta*1.4+i*2.1)),s=14+fsRnd(i+5)*14;g.globalAlpha=a;g.drawImage(FSFF.ff,(x+1700)%1700-50-s/2,y-s/2,s,s)}g.restore();
 /* foreground grass silhouettes and a soft vignette */
 if(!FSFF.ov){const c=document.createElement('canvas');c.width=1600;c.height=900;const o=c.getContext('2d');o.fillStyle='#07051a';o.beginPath();o.moveTo(0,900);for(let x=0;x<=1600;x+=16)o.lineTo(x,900-12-fsRnd(x+11)*26-Math.max(0,Math.sin(x*.004)*20));o.lineTo(1600,900);o.fill();
  const vg=o.createRadialGradient(800,460,380,800,460,1000);vg.addColorStop(0,'#00000000');vg.addColorStop(1,'#000000a0');o.fillStyle=vg;o.fillRect(0,0,1600,900);FSFF.ov=c}
 g.drawImage(FSFF.ov,0,0);
 if(V.dim){g.fillStyle=`rgba(4,2,16,${V.dim})`;g.fillRect(0,0,1600,900)}}
/* the hero on the dock with the rod, the pet beside him */
function fsHero(g,t,V){const H=FSHERO,s=H.s,lg=V.lg||0;
 /* pet */
 try{const id=P.pet;if(id&&PDEF[id]&&petOwned(id)){const hv=PDEF[id].hover,hop=V.petHop?-Math.sin(Math.min(1,V.petHop)*Math.PI)*16:0;g.save();g.translate(H.x-120,H.y-2-(hv?30:0)+hop);g.scale(.95,.95);petDraw(g,id,Object.assign({t,pose:V.cheer?'greet':'idle',u:V.cheer?(t%2.2)/2.2:0,noSh:hv?1:0},petLook(id)));g.restore()}}catch(e){}
 /* hero shadow and body */
 g.save();g.fillStyle='#00000055';g.beginPath();g.ellipse(H.x,H.y+2,60,9,0,0,TAU);g.fill();g.translate(H.x,H.y);g.scale(s,s);
 try{drawHero(g,{arm:P.armor,wp:null,col:P.col,t,lg:lg*.6,pose:V.cheer?'victory':undefined,pu:V.cheer?Math.min(1,V.cheerU||0):0})}catch(e){}g.restore();
 /* hand position (mirrors drawHero's weapon hand) */
 const br=Math.sin(t*2.4)*1.4,hx=H.x+(30+lg*.6*20)*s,hy=H.y+(-66-lg*.6*30+br*.3)*s;
 const a=(V.rodA!=null?V.rodA:-.62)+Math.sin(t*1.2)*.012,tip=fsRod(g,hx,hy,a,V.bend||0,190,t,V.skin);
 /* line and bobber */
 if(V.bob){if(V.bobA<1)g.globalAlpha=Math.max(0,V.bobA);const b=fsBobber(g,V.bob.x,V.bob.y,t,V.bob.dip||0,V.skin);g.globalAlpha=1;if(!V.noLine)fsLine(g,tip,b,V.slack==null?.4:V.slack,(V.skin||fsSkin()).ln,V.vib||0)}
 else if(V.lineTo)fsLine(g,tip,V.lineTo,V.slack||0,(V.skin||fsSkin()).ln);
 V.tip=tip}
