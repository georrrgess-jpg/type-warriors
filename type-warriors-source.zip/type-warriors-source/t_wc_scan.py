# Wildcard scan-to-join with no internet: the host's invite QR is shown to the guest's camera, the guest's reply QR to
# the host's camera. Each page's camera is a live canvas stream of the other screen's QR (slightly tilted and noisy),
# so the real path runs: getUserMedia -> <video> -> frame grab -> QR decoder -> WebRTC.
import asyncio,os,sys,time
from playwright.async_api import async_playwright
CAM="""()=>{const c=document.createElement('canvas');c.width=640;c.height=480;window.__camCv=c;window.__camText='';let img=null,last='';const g=c.getContext('2d');
 const tick=async()=>{const t=window.__camText;if(t&&t!==last){last=t;const s=wcQR(t).replace('<svg ','<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400" ');const im=new Image();im.src='data:image/svg+xml;base64,'+btoa(s);await im.decode();img=im}
  g.setTransform(1,0,0,1,0,0);g.fillStyle='#3a3440';g.fillRect(0,0,640,480);if(img){const a=Math.sin(performance.now()/700)*.08;g.translate(320,240);g.rotate(.12+a);g.transform(1,.06,-.05,.95,0,0);g.drawImage(img,-170,-170,340,340)}
  const d=g.getImageData(0,0,640,480);for(let i=0;i<d.data.length;i+=16){const n=(Math.random()-.5)*50;d.data[i]+=n;d.data[i+1]+=n;d.data[i+2]+=n}g.putImageData(d,0,0)};setInterval(tick,60);
 navigator.mediaDevices.getUserMedia=async()=>c.captureStream(20)}"""
async def main():
    html=os.path.abspath(sys.argv[1] if len(sys.argv)>1 else 'out.html')
    async with async_playwright() as p:
        b=await p.chromium.launch();A=await (await b.new_context(viewport={'width':1600,'height':900})).new_page();B=await (await b.new_context(viewport={'width':1600,'height':900})).new_page();er=[];bad=0
        for pg,n in ((A,'A'),(B,'B')):pg.on('pageerror',lambda e,n=n:er.append(n+' PE '+str(e)[:300]))
        def chk(name,r,ok):
            nonlocal bad;bad+=not ok;print(name,r,'OK' if ok else 'BAD')
        await A.goto('file://'+html);await B.goto('file://'+html);await A.wait_for_timeout(1200)
        for pg,nm in ((A,'Seth'),(B,'Mia')):await pg.evaluate(f"()=>{{RS_ASK=false;WCRELAYS=['ws://127.0.0.1:9/mqtt'];P.name='{nm}';P.gold=900;save();wcHome()}}");await pg.evaluate(CAM)
        await A.click('#wchost');await A.wait_for_timeout(2600)
        r=await A.evaluate("()=>WCL.net");chk('host offline -> QR hint',r,r=='offline')
        await A.click('#wclqr');await A.wait_for_timeout(3500)
        code=await A.evaluate("()=>(WCL.seats.find(s=>s.k==='inv')||{}).code||''");chk('invite made',code[:6],code.startswith('WC1~o'))
        await A.screenshot(path='shots/wc_scan_invite.png')
        await B.click('#wcscanj');await B.wait_for_timeout(400);await B.evaluate(f"()=>{{window.__camText={code!r}}}")
        t0=time.time()
        while time.time()-t0<20 and not await B.evaluate("()=>!!(WCNET.guest&&WCNET.guest.reply&&document.getElementById('wcqr'))"):await B.wait_for_timeout(150)
        reply=await B.evaluate("()=>WCNET.guest&&WCNET.guest.reply||''");chk(f'guest scanned the invite {time.time()-t0:.1f}s',reply[:6],reply.startswith('WC1~a'))
        await B.screenshot(path='shots/wc_scan_reply.png')
        await A.evaluate(f"()=>{{window.__camText={reply!r}}}");t1=time.time()
        while time.time()-t1<20 and not await A.evaluate("()=>WCL.seats.some(s=>s.k==='net')"):await A.wait_for_timeout(150)
        t2=time.time()
        while time.time()-t2<2 and not await A.evaluate("()=>WCL.seats.some(s=>s.k==='net'&&s.name==='Mia')"):await A.wait_for_timeout(50)  # the guest's name follows the connection by a moment
        chk(f'host scanned the reply, connected {time.time()-t1:.1f}s',await A.evaluate("()=>WCL.seats.map(s=>s.k+':'+(s.name||''))"),await A.evaluate("()=>WCL.seats.some(s=>s.k==='net'&&s.name==='Mia')"))
        await B.wait_for_timeout(800);r=await B.evaluate("()=>[!!document.getElementById('wcrdy'),WCNET.guest&&WCNET.guest.lobby&&WCNET.guest.lobby.room]");chk('guest sees the room',r,r[0])
        r=await A.evaluate("()=>[document.getElementById('wcmod').hidden,WCSCAN.stream===null]");chk('invite closed, camera off',r,r==[True,True])
        await B.click('#wcrdy');await A.wait_for_timeout(600);await A.click('#wcgo');await A.wait_for_timeout(1500)
        r=await B.evaluate("()=>[!!document.getElementById('wct'),WX.mode,WX.G&&WX.G.P.length]");chk('dealt over the direct link',r,r==[True,'net',4])
        await A.screenshot(path='shots/wc_scan_table_A.png')
        print('bad',bad);print(er[:6]);await b.close()
asyncio.run(main())
