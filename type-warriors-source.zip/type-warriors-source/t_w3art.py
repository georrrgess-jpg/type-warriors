# python3 t_w3art.py [game.html] : World 3 art, Skyforge Heights (98g, 98g2): the three map bakes (Cloudspire Meadows, Gearworks Foundry,
# Storm Citadel), every pad on solid ground and clear of props, the roads on ground off the rope bridges, the castles, the live layers and
# their frame cost on a full battle, the twist visuals with the state set by hand (gale, the switch both ways, lightning), the map icons,
# the world painting for the hub, and the tower layers of other modules still drawn on these maps.
import asyncio,os,sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:500]),flush=True)
    if not ok:FAIL.append(name)
HELP=r"""()=>{
 /* the twist state the core (98b) keeps is set by hand when the core is not loaded */
 window.w3New=(map)=>{try{rpLeave()}catch(e){}rpStart(map);const R=RPX,m=R.map;R.tut=null;R.supply=1e9;R.banner=null;if(m.gustT&&!R.gust)R.gust={t:9,k:0,on:0};if(m.sw&&R.sw==null){R.sw=0;R.swK=1}
  if(m.rods&&!R.rodK)R.rodK=m.rods.map(()=>0);if(!R.bolts)R.bolts=[];R.flash=R.flash||0;return R};
 window.w3Full=(R)=>{const T=Object.keys(RP_TW).filter(t=>RP_TW[t]&&!['hive','grav'].includes(t));R.pads.forEach((p,i)=>{rpBuild(p,T[i%T.length]);if(p.tw){p.tw.build=1;p.tw.upK=1}});
  R.wave=5;R.wst='run';const M=Object.keys(RPMOB).filter(k=>!RPMOB[k].boss&&RP_FOE[k]);for(let i=0;i<26;i++){const e=rpSpawn(M[i%M.length],i%R.G.paths.length);if(e)e.s=60+i*70}for(let i=0;i<20;i++)rpStep(R,1/30);return R};
 /* the pad stone (top face 50 x 21, foot 15 px lower) as 16 points */
 window.w3Ring=(p)=>{const o=[];for(let k=0;k<16;k++){const a=k/16*Math.PI*2,c=Math.cos(a)*50,s=Math.sin(a)*21;o.push([p.x+c,p.y+(s<0?s:15+s)])}return o};
 window.w3Clear=(B)=>{const bad=[];for(const p of B.G.pads)for(const q of B.occ||[]){if(Math.abs(q.x-p.x)<54+q.w&&q.y>p.y-44&&q.y-q.h<p.y+36)bad.push([p.x,p.y,q.x|0,q.y|0])}return bad};
 return 1}"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        pg.on('console',lambda m:er.append('console: '+m.text[:300]) if m.type=='error' and not any(w in m.text for w in('WebSocket','wss:','net::','Failed to load resource')) else None)
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E("()=>{window.TWA_RELAYS=[];RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const r=RPP();r.new99j=1;r.dragon=1;for(const k in r.tut)r.tut[k]=1}")
        await E(HELP)
        # ---- registries
        r=await E("()=>['meadow','foundry','storm'].map(id=>[typeof RPW.bake[id],typeof RPW.amb[id],typeof RPW.twist[id],typeof RPW.castleHit[id],typeof RPW.icon[id]]).concat([[typeof RPW.ambTop.meadow,typeof RPW.ambTop.storm,typeof RPW.world[3]]])")
        chk('the World 3 registries are filled: bake, live layer, twist, castle hit and icon for each map; ambTop for meadow and storm; the world painting',all(x=='function' for row in r for x in row),r)
        # ---- bakes
        r=await E("""()=>['meadow','foundry','storm'].map(id=>{delete RPBAKE[id];const t0=performance.now();const B=rpBake(RP_MAP(id));const ms=performance.now()-t0;
          const g=B.c.getContext('2d'),d=g.getImageData(0,0,1600,900).data;let op=0,cols=new Set();for(let i=0;i<d.length;i+=4*997){if(d[i+3]===255)op++;cols.add((d[i]>>4)+'.'+(d[i+1]>>4)+'.'+(d[i+2]>>4))}
          return [id,B.c.width,B.c.height,B.id,!!B.G,B.G.pads.length,Math.round(ms),op>=Math.floor(d.length/4/997)-1,cols.size,B.cast.w,B.cast.h,B.trees.length]})""")
        print('   bakes [id,w,h,id,G,pads,ms,opaque,colours,castW,castH,props]:',r)
        chk('each map bakes once into an opaque 1600 x 900 canvas with its castle box and many colours',all(x[1]==1600 and x[2]==900 and x[3]==x[0] and x[4] and x[7] and x[8]>60 and x[9]==300 and x[10]==520 and x[11]>20 for x in r),r)
        r2=await E("()=>['meadow','foundry','storm'].map(id=>rpBake(RP_MAP(id))===rpBake(RP_MAP(id)))")
        chk('bakes are cached',all(r2),r2)
        m1=await E("()=>{const o=[];for(const id of['moss','ember']){delete RPBAKE[id];const t0=performance.now();rpBake(RP_MAP(id));o.push(Math.round(performance.now()-t0))}return o}")
        print('   World 1 bakes for comparison [moss, ember] ms:',m1)
        chk('bake time stays reasonable: each map bakes in under 5x a World 1 map (it is done once, when the map starts)',all(x[6]<5*max(m1)+300 for x in r),[x[6] for x in r]+m1)
        # ---- the castle stands at the road's end
        r=await E("()=>['meadow','foundry','storm'].map(id=>{const B=rpBake(RP_MAP(id)),A=rpw3aCastle(id);return [Math.round(B.cast.x+A.gx-B.G.gate.x),Math.round(B.cast.y+A.gy-B.G.gate.y)]})")
        chk('each castle\'s gate point sits on the end of the road',all(abs(a)<=1 and abs(b)<=1 for a,b in r),r)
        # ---- pads on ground, clear of props; roads on ground off the bridges; real gaps under the bridges
        r=await E("""()=>['meadow','storm'].map(id=>{const B=rpBake(RP_MAP(id)),M=B.M,bad=[];for(const p of B.G.pads)for(const [x,y] of w3Ring(p))if(M.at(x,y)<=0)bad.push([p.x,p.y,x|0,y|0]);return [id,B.G.pads.length,bad]})""")
        chk('Cloudspire Meadows and Storm Citadel: every pad stone stands on solid ground',all(len(x[2])==0 for x in r),r)
        r=await E("""()=>['meadow','storm'].map(id=>{const map=RP_MAP(id),B=rpBake(map),M=B.M,br=map.bridge||[],bad=[];let n=0;for(const P of B.G.paths)for(let i=0;i<P.S.length;i+=2){const q=P.S[i];if(!P.own[i]||q.x<4||q.x>1596)continue;if(br.some(b=>Math.hypot(q.x-b[0],q.y-b[1])<b[2]))continue;n++;
          for(const o of[-36,0,36]){const x=q.x-Math.sin(q.a)*o,y=q.y+Math.cos(q.a)*o;if(M.at(x,y)<=0){bad.push([x|0,y|0]);break}}}return [id,n,bad.slice(0,6),bad.length]})""")
        chk('the whole road off the bridges (centre and both curbs) is on ground',all(x[3]==0 and x[1]>200 for x in r),r)
        r=await E("()=>{const map=RP_MAP('meadow'),B=rpBake(map);return map.bridge.map(b=>[b[0],b[1],Math.round(B.M.at(b[0],b[1]))])}")
        chk('every rope bridge spans open sky (the ground under its middle is a gap)',len(r)==4 and all(x[2]<0 for x in r),r)
        r=await E("()=>['meadow','foundry','storm'].map(id=>[id,(rpBake(RP_MAP(id)).occ||[]).length,w3Clear(rpBake(RP_MAP(id)))])")
        chk('props keep clear of every pad and of the tower standing on it, on all three maps',all(x[1]>10 and len(x[2])==0 for x in r),r)
        r=await E("""()=>{const hit=[],inE=(x,y,cx,cy,rx,ry)=>((x-cx)/rx)**2+((y-cy)/ry)**2<1;const B=rpBake(RP_MAP('foundry'));
          for(const p of B.G.pads)for(const [x,y] of w3Ring(p)){if(inE(x,y,B.CX,B.CY,102,76))hit.push(['crucible',p.x,p.y]);for(const [mx,my] of[[B.CX-178,B.CY+14],[B.CX+128,B.CY+118]])if(Math.abs(x-mx)<32&&Math.abs(y-my)<14)hit.push(['mould',p.x,p.y]);
           if(x>B.lever.x-34&&x<B.lever.x+34&&y>B.lever.y-70&&y<B.lever.y+6)hit.push(['lever',p.x,p.y])}
          const S=RP_MAP('storm'),BS=rpBake(S);for(const p of BS.G.pads)for(const [x,y] of w3Ring(p))for(const r of S.rods)if(inE(x,y,r[0],r[1],32,16))hit.push(['rod',p.x,p.y]);return hit}""")
        chk('the switch lever, the crucible, the moulds and the rod plinths keep clear of the pads',r==[],r)
        r=await E("""()=>{const m=RP_MAP('foundry'),B=rpBake(m),g=B.c.getContext('2d');return m.vents.map(v=>{const d=g.getImageData(v[0]-30,v[1]-12,60,24).data;let hot=0;for(let i=0;i<d.length;i+=4)if(d[i]>180&&d[i+1]>60&&d[i+2]<120)hot++;return hot})}""")
        chk('Gearworks Foundry: the furnace vent grates are baked into the track and glow',all(x>40 for x in r),r)
        # ---- the live layers: drawn inside the base chain, the other modules' tower layers still drawn
        r=await E("""()=>{const out=[];for(const id of['meadow','foundry','storm']){const R=w3New(id);let n=0;const l0=rpCastleLive;rpCastleLive=function(g,i){if(i===id)n++;return l0.apply(this,arguments)};let a=0;const f=RPW.amb[id];RPW.amb[id]=function(){a++;return f.apply(this,arguments)};
          try{R.t=1;rpDraw();rpDraw()}finally{rpCastleLive=l0;RPW.amb[id]=f}out.push([id,n,a,RPW.amb[id]===f])}return out}""")
        chk('each map\'s live layer is drawn once a frame from inside the usual ambience chain (so the tower layers of other modules still draw)',all(x[1]==2 and x[2]==2 and x[3] for x in r),r)
        # ---- twist visuals with the state set by hand
        r=await E("""()=>{const res={};const snap=()=>{const d=ctx.getImageData(0,0,1600,900).data;let h=0;for(let i=0;i<d.length;i+=4*61)h=(h*31+d[i]+d[i+1]*7+d[i+2]*13)%1000000007;return h};
          let R=w3New('meadow');R.t=5;R.gust.k=0;rpDraw();const m0=snap();R.gust.k=1;rpDraw();res.gale=m0!==snap();
          R=w3New('foundry');R.t=5;R.sw=0;R.swK=1;rpDraw();const f0=snap();R.sw=1;R.swK=1;rpDraw();const f1=snap();R.swK=.4;rpDraw();const f2=snap();res.sw=[f0!==f1,f1!==f2];
          R=w3New('storm');R.t=5;R.bolts=[];R.flash=0;rpDraw();const s0=snap();R.bolts=[{x:820,y:550,t:.05,d:.55,tw:0},{x:690,y:500,t:.1,d:.55,tw:1}];R.flash=.8;R.rodK=[0,1,0];rpDraw();const s1=snap();R.bolts=[];R.flash=0;R.rodK=[0,0,0];R.t=5.2;rpDraw();res.storm=[s0!==s1,(R._w3sc||[]).length];return res}""")
        chk('twists: the gale draws wind, the switch lever shows both lines and its swing, lightning draws bolts, a flash and lasting scorch marks',r.get('gale') and r.get('sw')==[True,True] and r['storm'][0] and r['storm'][1]==2,r)
        r=await E("""()=>{const R=w3New('foundry');const L=RPX.bake.lever;const g=ctx;const look=(sw,k)=>{R.sw=sw;R.swK=k;R.t=3;rpDraw();const d=g.getImageData(L.x-50,L.y-90,100,70).data;let sx=0,n=0;for(let y=0;y<70;y++)for(let x=0;x<100;x++){const i=(y*100+x)*4;if(d[i]>180&&d[i+1]<90&&d[i+2]<80){sx+=x;n++}}return n?Math.round(sx/n-50):null};return [look(0,1),look(1,1)]}""")
        chk('the lever knob leans to N on the north line and to S on the south line',r[0] is not None and r[1] is not None and r[0]<-8 and r[1]>8,r)
        # ---- castle hit flinch
        r=await E("()=>['meadow','foundry','storm'].map(id=>{const R=w3New(id);R.castHit=.6;let ok=1;try{rpDraw()}catch(e){ok=0}return ok})")
        chk('the castle flinch draws on every map',all(r),r)
        # ---- frame cost of the live layers on a full battle (each frame timed alone, flushed; the fastest frames filter out a busy machine)
        r=await E("""()=>{const out={};const meas=(f)=>{const L=[];for(let k=0;k<120;k++){ctx.getImageData(0,0,1,1);const t0=performance.now();ctx.save();try{f(k)}finally{ctx.restore()}ctx.getImageData(0,0,1,1);L.push(performance.now()-t0)}L.sort((a,b)=>a-b);return +((L[0]+L[6]+L[12])/3).toFixed(2)};
          for(const id of['ember','meadow','foundry','storm']){const R=id==='ember'?w3New(id):w3Full(w3New(id));if(id==='ember')w3Full(R);if(id==='meadow')R.gust.k=1;if(id==='foundry'){R.sw=1;R.swK=.5}
           const f=k=>{R.t=10+k/60;rpAmbient(ctx,R);if(RPW.ambTop[id])RPW.ambTop[id](ctx,R)};
           R.lite=0;const a=meas(f);R.lite=1;const l=meas(f);R.lite=0;out[id]=[a,l,R.pads.filter(p=>p.tw).length,R.foes.length];
           if(id==='storm'){R.bolts=[{x:520,y:450,t:.1,d:.55,tw:0}];R.flash=.6;out.storm_bolt=meas(f);R.bolts=[];R.flash=0}}return out}""")
        print('   live layers ms per frame [normal, lite, towers, monsters] (Ember Crown = World 1 reference):',r)
        em=r['ember'][0]
        chk('frame cost: each map\'s live layers on a full battle (meadow mid-gale, storm in the rain) stay within 2x World 1\'s Ember Crown, lite mode draws less, and a lightning frame (bolt + flash, 0.55 s now and then) within 3x',
            all(r[k][0]<=max(1.2,2*em) and r[k][1]<=r[k][0]+.05 and r[k][2]>=14 for k in['meadow','foundry','storm']) and r['storm_bolt']<=max(1.8,3*em),r)
        # ---- icons and the world painting
        r=await E("""()=>['meadow','foundry','storm'].map(id=>{const a=RPW.icon[id](88,88),b=RPW.icon[id](88,88),c=rpMapIcon(id,72,72),d=a.getContext('2d').getImageData(0,0,88,88).data;let n=0;for(let i=3;i<d.length;i+=4)if(d[i]>200)n++;return [a.width,a.height,a===b,c.width,n>5000]})""")
        chk('map icons: cached, the right size, through rpMapIcon too, and painted',all(x[0]==88 and x[1]==88 and x[2] and x[3]==72 and x[4] for x in r),r)
        r=await E("""()=>{const W=RPW.world[3](),W2=RPW.world[3]();const g=document.createElement('canvas').getContext('2d');g.canvas.width=1600;g.canvas.height=900;g.drawImage(W.c,0,0);let ok=1;try{W.anim(g,1.3);W.anim(g,7.9)}catch(e){ok=0}
          return [W.c.width,W.c.height,W.c===W2.c,Object.keys(W.nodes).sort().join(','),Object.values(W.nodes).every(n=>n.x>60&&n.x<1180&&n.y>90&&n.y<680),ok]}""")
        chk('the world painting: 1600 x 900, cached, a node per map clear of the side panel, the top bar and the armory, and its live layer runs',r[:4]==[1600,900,True,'foundry,meadow,storm'] and r[4] and r[5],r)
        r=await E("""()=>{const W=RPW.world[3](),g=W.c.getContext('2d'),t0=performance.now();for(let f=0;f<60;f++)W.anim(g,f/30);return +((performance.now()-t0)/60).toFixed(3)}""")
        chk('the painting\'s live layer is cheap',r<2,r)
        # ---- reduced motion and a short real run
        r=await E("()=>{const out=[];for(const id of['meadow','foundry','storm']){const R=w3Full(w3New(id));R.rm=true;let ok=1;try{for(let i=0;i<30;i++){rpStep(R,1/30);rpDraw()}}catch(e){ok=0}R.rm=false;out.push(ok)}return out}")
        chk('reduced motion draws every map without errors',all(r),r)
        await E("()=>{const R=w3New('storm');w3Full(R);R.bolts=[{x:830,y:552,t:.05,d:.55,tw:0}];R.flash=.6;R.lite=0;rpDraw()}")
        os.makedirs(os.path.join(HERE,'shots'),exist_ok=True)
        await pg.screenshot(path=os.path.join(HERE,'shots','w3art_test.png'))
        chk('no page errors',not er,er)
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
