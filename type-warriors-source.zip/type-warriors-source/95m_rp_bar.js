/* ===== RUNESTONE TOWER DEFENSE 9.2: the tower bar and the build ring, redesigned (95m, after 95l) =====
   Seven towers now. The bar is a row of tiles: the tower stands up out of each tile, with its name, cost and key; a coloured glow
   rises from the tile floor. Hovering a tile springs it up and enlarges it over its neighbours (z-index) with an info flyout above;
   the tower in it bobs. The tile being placed stays raised with a gold rim; unaffordable tiles dim with a red cost; locked tiles show a
   lock. Tiles rise in one after another when the HUD appears. The build ring spreads all seven buttons on an arc (below the pad near
   the top of the map, above it elsewhere); hovering one pops it over the others and shows its name and cost.
   Only transform and opacity animate (glows are pre-drawn layers whose opacity changes). */
{const h0=rpHudOn;rpHudOn=function(){const r=h0.apply(this,arguments);try{const h=$('rphud');if(h){h.classList.add('rp7');
  h.querySelectorAll('.rpcard').forEach((c,i)=>{c.style.setProperty('--i',i);const T=RP_TW[c.dataset.tw],TW=RPTW[c.dataset.tw];const tip=c.querySelector('.rptip');
   if(tip&&!c.classList.contains('lock'))tip.innerHTML=`<b>${esc(TW.n)}</b><em>${esc(TW.role||'')}</em>${esc(T.desc)}<i>${RPI.sup} ${T.cost[0]} supply · key ${RP_KEYS[i]}</i>`;
   if(!c.querySelector('.rpglo')){const g=document.createElement('i');g.className='rpglo';c.prepend(g)}})}}catch(e){console.error(e)}return r}}
/* the ring: N buttons on an arc */
{const g0=rpHudRing;rpHudRing=function(R,C){const was=C.rg;const r=g0.apply(this,arguments);try{if(C.rg!==was&&C.rg){const el=$('rpring'),p=R.selPad,bs=el.querySelectorAll('.rprb'),n=bs.length,below=p.y<340,rad=192;
  bs.forEach((b,i)=>{const deg=below?(180-i*(180/(n-1))):(-180+i*(180/(n-1))),a=deg*Math.PI/180;b.style.setProperty('--x',(Math.cos(a)*rad).toFixed(1)+'px');b.style.setProperty('--y',(Math.sin(a)*rad*.84).toFixed(1)+'px');b.style.setProperty('--d',(i*.035).toFixed(3)+'s');
   if(!b.querySelector('.rpglo')){const g=document.createElement('i');g.className='rpglo';b.prepend(g)}})}}catch(e){console.error(e)}return r}}
{const st=document.createElement('style');st.textContent=`
.rph.rp7 .rpbar{left:744px;gap:7px;padding:10px 10px 9px;border-radius:24px;border:2px solid #7a5ac8;background:linear-gradient(180deg,#261c62f2,#100a30f6);box-shadow:0 0 0 2px #12081f,0 12px 26px #000a}
.rph.rp7 .rpbar::before{content:'';position:absolute;left:18px;right:18px;top:-2px;height:3px;border-radius:3px;background:linear-gradient(90deg,transparent,#ffd45a,transparent);opacity:.8;pointer-events:none}
.rph.rp7 .rpcard{width:110px;height:94px;padding:0;display:block;border-radius:18px;border:2px solid #3a3070;background:linear-gradient(180deg,#2c2270,#130c38);overflow:visible;
 transition:transform .26s cubic-bezier(.34,1.56,.64,1);animation:rpTileIn .5s cubic-bezier(.34,1.56,.64,1) backwards;animation-delay:calc(var(--i,0)*45ms + .05s);z-index:1}
@keyframes rpTileIn{from{opacity:0;transform:translateY(26px) scale(.86)}}
.rph.rp7 .rpcard .rpglo{position:absolute;inset:0;border-radius:16px;background:radial-gradient(90% 70% at 50% 100%,var(--c) 0%,transparent 70%);opacity:.28;transition:opacity .2s;pointer-events:none}
.rph.rp7 .rpcard::after{content:'';position:absolute;inset:-2px;border-radius:18px;border:2px solid var(--c);opacity:0;transition:opacity .2s;pointer-events:none}
.rph.rp7 .rpcard img{position:absolute;left:50%;top:-26px;width:80px;height:80px;margin:0 0 0 -40px;transition:transform .26s cubic-bezier(.34,1.56,.64,1);pointer-events:none}
.rph.rp7 .rpct{position:absolute;left:0;right:0;bottom:5px;display:flex;flex-direction:column;align-items:center;gap:1px}
.rph.rp7 .rpct>b{font:400 14px/1.05 'Pirata One',Georgia,serif;letter-spacing:-.01em;text-align:center;white-space:nowrap;max-width:104px;overflow:hidden;text-overflow:ellipsis}
.rph.rp7 .rpcost{gap:3px;padding:1px 8px 1px 5px;border-radius:9px;background:#0a0620d8;font-size:13px}.rph.rp7 .rpcost svg{width:14px;height:14px}.rph.rp7 .rpcost b{font-size:13px}
.rph.rp7 .rpcard kbd{position:absolute;left:6px;right:auto;top:5px;min-width:18px;padding:1px 4px;font-size:11px}
.rph.rp7 .rpcard:hover{transform:translateY(-30px) scale(1.24);z-index:6}
.rph.rp7 .rpcard:hover .rpglo{opacity:.65}.rph.rp7 .rpcard:hover::after{opacity:1}
.rph.rp7 .rpcard:hover img{animation:rpBob 1.2s ease-in-out infinite}
@keyframes rpBob{0%,100%{transform:translateY(0)}50%{transform:translateY(-5px)}}
.rph.rp7 .rpcard:active{transform:translateY(-24px) scale(1.16)}
.rph.rp7 .rpcard.on{transform:translateY(-14px);z-index:4;border-color:#ffd45a}.rph.rp7 .rpcard.on::after{opacity:1;border-color:#ffd45a}.rph.rp7 .rpcard.on .rpglo{opacity:.6}
.rph.rp7 .rpcard.on:hover{transform:translateY(-30px) scale(1.24)}
.rph.rp7 .rpcard.no{opacity:1}.rph.rp7 .rpcard.no img{opacity:.55}.rph.rp7 .rpcard.no .rpct>b{opacity:.7}
.rph.rp7 .rpcard.lock img{opacity:.35}.rph.rp7 .rpcard .rplk{left:42px;top:2px}
.rph.rp7 .rptip{bottom:calc(100% + 34px);width:250px;padding:10px 13px 11px;border-radius:14px;border:2px solid var(--c);background:linear-gradient(180deg,#1e1650fa,#0c0824fc);box-shadow:0 0 0 2px #12081f;font-size:12px;transform:translateX(-50%) scale(.81);transform-origin:50% 100%;transition:opacity .18s}
.rph.rp7 .rptip em{display:block;margin:-1px 0 4px;font:700 11px var(--ui);font-style:normal;letter-spacing:.12em;text-transform:uppercase;color:var(--c)}
.rph.rp7 .rptip i{display:flex;align-items:center;gap:4px;margin-top:6px;font:800 12px var(--ui);font-style:normal;color:#ffd45a}.rph.rp7 .rptip i svg{width:14px;height:14px}
.rph.rp7 .rprb{width:78px;height:78px;left:-39px;top:-39px;transition:transform .24s cubic-bezier(.34,1.56,.64,1);z-index:1;overflow:visible}
.rph.rp7 .rprb .rpglo{position:absolute;inset:-3px;border-radius:50%;background:radial-gradient(circle at 50% 70%,var(--c),transparent 70%);opacity:.3;transition:opacity .2s;pointer-events:none}
.rph.rp7 .rprb img{position:relative;width:66px;height:66px;margin-top:-14px}
.rph.rp7 .rprb:hover{transform:translate(var(--x),var(--y)) scale(1.32);z-index:6}.rph.rp7 .rprb:hover .rpglo{opacity:.75}
.rph.rp7 .rprb em{top:-26px;padding:2px 8px;border-radius:8px;background:#12081fe0;font-size:12px}
.rph.rp7 .rprb.lock img{opacity:.4}`;document.head.appendChild(st)}
