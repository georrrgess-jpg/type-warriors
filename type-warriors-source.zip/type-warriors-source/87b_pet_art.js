/* ===== COMPANIONS: painted canvas rigs =====
   petDraw(g,id,o) draws a companion with its feet (or hover shadow) at the origin, facing right, about 100 units tall.
   o = {t, pose:'idle'|'walk'|'ability'|'greet', u:0..1 progress for ability/greet, pal:0|1, acc:0|1, trim:0|1, noSh}
   Every pose keeps the same limb count, proportions and colours; ability and greet are driven by u so callers can scrub them. */
const PTO='#1b1024';
function pP(g,a){g.beginPath();g.moveTo(a[0],a[1]);for(let i=2;i<a.length;i+=2)g.lineTo(a[i],a[i+1]);g.closePath()}
function pF(g,f,lw,sc){g.fillStyle=f;g.fill();if(lw!==0){g.lineWidth=lw||3;g.strokeStyle=sc||PTO;g.stroke()}}
function pE(g,x,y,rx,ry,r){g.beginPath();g.ellipse(x,y,Math.max(.1,rx),Math.max(.1,ry),r||0,0,TAU)}
function pC(g,x,y,r){g.beginPath();g.arc(x,y,Math.max(.1,r),0,TAU)}
function pLin(g,x0,y0,x1,y1,cs){const q=g.createLinearGradient(x0,y0,x1,y1);cs.forEach((c,i)=>q.addColorStop(i/(cs.length-1),c));return q}
function pRad(g,x,y,r,cs){const q=g.createRadialGradient(x-r*.3,y-r*.35,r*.05,x,y,r);cs.forEach((c,i)=>q.addColorStop(i/(cs.length-1),c));return q}
function pGlow(g,x,y,r,c,a){if(r<=0||a<=0)return;g.save();g.globalCompositeOperation='lighter';const q=g.createRadialGradient(x,y,0,x,y,r);q.addColorStop(0,c+Math.round(Math.min(1,a)*255).toString(16).padStart(2,'0'));q.addColorStop(1,c+'00');g.fillStyle=q;g.beginPath();g.arc(x,y,r,0,TAU);g.fill();g.restore()}
const pS=x=>x<=0?0:x>=1?1:x*x*(3-2*x);
const pSeg=(u,a,b)=>pS((u-a)/(b-a));
/* a blink every few seconds: 1 open, 0 shut */
function pBlink(t,seed){const p=((t+seed*1.7)%4.1+4.1)%4.1;return p<.14?Math.abs(p-.07)/.07:1}
/* big friendly eye; happy draws a closed smiling arc */
function pEye(g,x,y,r,col,open,happy,lx){lx=lx||0;if(happy){g.beginPath();g.arc(x,y+r*.35,r*.75,Math.PI*1.12,Math.PI*1.88);g.strokeStyle=PTO;g.lineWidth=Math.max(2,r*.32);g.stroke();return}
 if(open<.25){g.beginPath();g.moveTo(x-r*.8,y);g.quadraticCurveTo(x,y+r*.25,x+r*.8,y);g.strokeStyle=PTO;g.lineWidth=Math.max(2,r*.3);g.stroke();return}
 pE(g,x,y,r*.82,r*open);pF(g,col,Math.max(1.6,r*.22));pE(g,x+lx*r*.18,y+r*.08*open,r*.52,r*.6*open);g.fillStyle='#0c0612';g.fill();
 pC(g,x+r*.24+lx*r*.1,y-r*.32*open,r*.26);g.fillStyle='#fff';g.fill();pC(g,x-r*.2,y+r*.3*open,r*.12);g.fillStyle='#ffffffcc';g.fill()}
/* a leaf with a midrib, base at (x,y) pointing along angle a */
function pLeaf(g,x,y,len,w,a,c1,c2,lw){g.save();g.translate(x,y);g.rotate(a);g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(len*.35,-w,len,0);g.quadraticCurveTo(len*.35,w,0,0);g.closePath();pF(g,pLin(g,0,-w,0,w,[c1,c2]),lw||2.4);
 g.beginPath();g.moveTo(len*.08,0);g.quadraticCurveTo(len*.5,-w*.12,len*.88,0);g.strokeStyle=c2;g.globalAlpha=.75;g.lineWidth=1.6;g.stroke();g.restore()}
function pFlower(g,x,y,r,c,cc){for(let i=0;i<5;i++){const a=i*TAU/5-Math.PI/2;pE(g,x+Math.cos(a)*r*.62,y+Math.sin(a)*r*.62,r*.48,r*.42,a);pF(g,c,1.6)}pC(g,x,y,r*.34);pF(g,cc||'#ffd45a',1.4)}
function pStar4(g,x,y,r,c){g.fillStyle=c;g.beginPath();g.moveTo(x,y-r);g.quadraticCurveTo(x+r*.16,y-r*.16,x+r,y);g.quadraticCurveTo(x+r*.16,y+r*.16,x,y+r);g.quadraticCurveTo(x-r*.16,y+r*.16,x-r,y);g.quadraticCurveTo(x-r*.16,y-r*.16,x,y-r);g.fill()}
function pStar5(g,x,y,r,c,lw){g.beginPath();for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,rr=i%2?r*.45:r;g.lineTo(x+Math.cos(a)*rr,y+Math.sin(a)*rr)}g.closePath();pF(g,c,lw||2)}
function pHeart(g,x,y,s,c,lw){g.beginPath();g.moveTo(x,y+s*.9);g.bezierCurveTo(x-s*1.4,y,x-s*.9,y-s*1.1,x,y-s*.35);g.bezierCurveTo(x+s*.9,y-s*1.1,x+s*1.4,y,x,y+s*.9);g.closePath();pF(g,c,lw||2)}
/* a simple limb: rounded tapered segment */
function pLimb(g,x0,y0,x1,y1,w0,w1,c){const a=Math.atan2(y1-y0,x1-x0),nx=-Math.sin(a),ny=Math.cos(a);g.beginPath();g.moveTo(x0+nx*w0,y0+ny*w0);g.lineTo(x1+nx*w1,y1+ny*w1);g.arc(x1,y1,w1,a+Math.PI/2,a-Math.PI/2,true);g.lineTo(x0-nx*w0,y0-ny*w0);g.arc(x0,y0,w0,a-Math.PI/2,a+Math.PI/2,true);g.closePath();pF(g,c,2.4)}
/* gold trim stroke used by the level 10 signature style */
function pTrim(g,lw){}

/* ---------- palettes: [default, bond level 5 alternate] ---------- */
const PCOL={
 bramble:[{sh:'#6e9a2c',shd:'#476a1a',shl:'#a6cc48',pl:'#3a5a16',sk:'#dcc678',skd:'#b49a52',sp:'#94b040',lf:'#86d040',lfd:'#3f9a2a',fl:'#7ab8ff',ey:'#2ad0c4'},
          {sh:'#b0642a',shd:'#7a4018',shl:'#e09a44',pl:'#5a2e10',sk:'#e2c88a',skd:'#b8965a',sp:'#c88a3a',lf:'#ff9a3a',lfd:'#d0541a',fl:'#7ab8ff',ey:'#2ad0c4'}],
 mosskip:[{b:'#e2c28c',bd:'#b8945a',ch:'#fff4dc',rf:'#6ac44a',rfd:'#36862a',ea:'#86d24e',ead:'#3a962a',ie:'#f6c0a8',ey:'#4a2e16',no:'#ff8aa0'},
          {b:'#eef2fa',bd:'#b4c0d6',ch:'#ffffff',rf:'#5ad6c4',rfd:'#2a8a8a',ea:'#6ae0cc',ead:'#2a9a90',ie:'#ffd0dc',ey:'#2a3a5a',no:'#ff9ab8'}],
 antler:[{b:'#f8eed6',bd:'#d8c6a2',tl:'#5cbca2',tld:'#2e8a74',an:'#ffd45a',and:'#c88a1a',hg:'#3cff86',hf:'#3a2a2e',lf:'#6ad06a',ie:'#f6b8b0',ey:'#1f6a5a'},
         {b:'#fff0ec',bd:'#e2c0bc',tl:'#ee90a6',tld:'#b85a74',an:'#ffd45a',and:'#c88a1a',hg:'#3cff86',hf:'#4a2a34',lf:'#f4a2b8',ie:'#ffc8d0',ey:'#7a2a4a'}],
 cinder:[{b:'#ff7e2c',bd:'#d24a18',bl:'#ffb05a',be:'#f4cc94',sp:'#ffc24a',spd:'#b83410',ft:'#3c3646',ftd:'#25202e',f1:'#fff2a0',f2:'#ffa21a',f3:'#ff4a14',ey:'#fff2d8'},
         {b:'#3cbccc',bd:'#1a7a9a',bl:'#7ae2ea',be:'#d4f2f0',sp:'#9ff6ff',spd:'#145a78',ft:'#2c3446',ftd:'#1a2030',f1:'#eaffff',f2:'#5ad8ff',f3:'#2a7aff',ey:'#effcff'}],
 beetle:[{b:'#3c3c4c',bd:'#252532',bl:'#5e5e70',pl:'#e6ac3c',pld:'#a8701a',pll:'#ffdc86',ey:'#3cffea',cn:'#ffd45a'},
         {b:'#34384c',bd:'#20222e',bl:'#5a6078',pl:'#c8d0e0',pld:'#7a8298',pll:'#ffffff',ey:'#7affb4',cn:'#ffd45a'}],
 ember:[{f:'#d8323c',fd:'#981a2a',ch:'#f8ecd4',bk:'#f4e2bc',bkd:'#c4a476',cr:'#ffd45a',w1:'#ffb02a',w2:'#ff6e1a',wt:'#ffe07a',rb:'#3c3444',rbd:'#262030',cl:'#e6aa3a',ey:'#ffb81a'},
        {f:'#5c34b0',fd:'#341a74',ch:'#fbf0dc',bk:'#f8ecd0',bkd:'#c8a878',cr:'#ffd45a',w1:'#ffe27a',w2:'#a86aff',wt:'#fff6d0',rb:'#2e2650',rbd:'#1a1636',cl:'#ffcc4a',ey:'#ffd45a'}],
 gloom:[{b:'#9c46a6',bd:'#6a2a7a',bl:'#c870c8',w:'#b856b8',wd:'#7a2e8a',wl:'#e08ae0',ie:'#ff8ab4',ey:'#3cfcff',cr:'#ffe6a0'},
        {b:'#8a4aa0',bd:'#5a2a72',bl:'#b880c8',w:'#a4aac2',wd:'#6a708a',wl:'#e2e6f2',ie:'#ff9ac0',ey:'#7affff',cr:'#ffffff'}],
 wisp:[{m:'#e6aa3a',md:'#9a661a',ml:'#ffe08a',sp:'#7affc8',spd:'#2ad09a',spl:'#e2fff2'},
       {m:'#c4c8d6',md:'#6e7286',ml:'#ffffff',sp:'#7ac8ff',spd:'#2a7ad8',spl:'#eaf6ff'}],
 noct:[{b:'#4c3c7e',bd:'#2c2252',bl:'#6e5ca6',ch:'#b8a8e2',tf:'#2a1e48',ey:'#ffb42a',cr:'#eef0ff',tl:'#a85aff',tl2:'#e0b8ff',co:'#ffd45a'},
       {b:'#283456',bd:'#161e36',bl:'#46567e',ch:'#9ab4d8',tf:'#121a30',ey:'#7affe0',cr:'#eef0ff',tl:'#3ad8d0',tl2:'#b4fff6',co:'#ffd45a'}],
 crab:[{b:'#baa2e2',bd:'#8a70c2',bl:'#dccafa',cr:'#5ad8ff',crd:'#2a98d8',crl:'#c8f6ff',hd:'#1a1430',ey:'#3cf0ff',ru:'#ffd45a'},
       {b:'#cca2c8',bd:'#9a6a9a',bl:'#f0d0ec',cr:'#ff8ad8',crd:'#c84aa8',crl:'#ffd8f2',hd:'#24122a',ey:'#ff9ae0',ru:'#ffd45a'}],
 quill:[{bu:'#5ab8ff',b:'#2a3c9c',bd:'#18226e',bl:'#4c6ad8',fp:'#f8ecd4',qf:'#ffd45a',qfd:'#c88a1a',tl:'#a86aff',tl2:'#d8b0ff'},
        {bu:'#5af0e0',b:'#1e5a8a',bd:'#103a5e',bl:'#3a8ac0',fp:'#f0fff8',qf:'#5ff0d0',qfd:'#1a9a8a',tl:'#3ad8c8',tl2:'#b4fff2'}],
 starcoil:[{b:'#1e2c6c',bd:'#121a48',bl:'#34489a',be:'#c2eaff',hn:'#ffd45a',hnd:'#c88a1a',fn:'#a86aff',fn2:'#dab0ff',ey:'#c48aff',st:'#ffd45a'},
           {b:'#0f5a5a',bd:'#073636',bl:'#1e9a86',be:'#e2fff2',hn:'#fff0b0',hnd:'#c8a03a',fn:'#5affa8',fn2:'#e2b4ff',ey:'#7affe8',st:'#fff6c0'}],
 lily:[{b:'#5ccc7c',bd:'#2a8a4c',bl:'#a2f2aa',be:'#f6f2cc',ck:'#ff8aa6',ey:'#ffd45a',pd:'#3caa52',pdd:'#1e7a36',lo:'#ff9ad2',lol:'#ffe0f2'},
       {b:'#ffc83c',bd:'#cc8a1a',bl:'#fff09a',be:'#fff8e2',ck:'#ff8a7a',ey:'#5ad8ff',pd:'#3caa52',pdd:'#1e7a36',lo:'#ffffff',lol:'#fff4c0'}],
 tick:[{m:'#e2aa3c',md:'#986618',ml:'#ffe48e',cu:'#cc6c3a',cud:'#8a3e1a',fc:'#fff4dc',ey:'#ffb42a',hn:'#3a2416'},
       {m:'#b8c0d2',md:'#646c84',ml:'#ffffff',cu:'#7a86a6',cud:'#444c66',fc:'#f0f6ff',ey:'#5af0ff',hn:'#1a2236'}],
 prism:[{b:'#f2eeff',bd:'#c6bcee',ie:'#a8e8ff',c1:'#9ff0ff',c2:'#d4a6ff',c3:'#ffb4e4',c4:'#fff0a0',ey:'#7a4aff',st:'#fff6c0'},
        {b:'#ffe6cc',bd:'#e0b48e',ie:'#ffd09a',c1:'#ffd45a',c2:'#ff9a6a',c3:'#ffc4a0',c4:'#fff6c0',ey:'#c2501a',st:'#fff6c0'}]
};

/* ---------- the rigs ---------- */
const PRIG={};
/* BRAMBLEKIN: moss tortoise with three leaf plates and a blue flower; peeks from its shell, retracts to guard */
PRIG.bramble=(g,o,C)=>{const t=o.t,P=o.pose,u=o.u;
 const walk=P==='walk',ab=P==='ability',gr=P==='greet',sig=o.trim;
 /* idle peek: every 9 s it tucks its head and feet in for a moment */
 const pk=((t%9)+9)%9,peekIn=!walk&&!ab&&!gr?Math.max(0,Math.min(1,(pk-7)/.3))*Math.max(0,Math.min(1,(8.3-pk)/.4)):0;
 const ret=ab?(u<.3?pSeg(u,0,.25):u<.75?1:1-pSeg(u,.75,.95)):peekIn,re=ret*ret*(3-2*ret);
 const rock=walk?Math.sin(t*6)*.03:0,br=1+Math.sin(t*2)*.012,hop=gr?Math.sin(pSeg(u,0,.5)*Math.PI)*-8:0;
 g.save();g.translate(0,hop);g.rotate(rock);
 const lg=i=>walk?Math.max(0,Math.sin(t*6+i*Math.PI))*5:0;
 /* a stubby leg that slides up under the shell when it tucks in */
 const leg=(x,i,far)=>{g.save();g.beginPath();g.rect(x-16,far?-30:-13,32,far?44:27);g.clip();g.translate(x+(walk?Math.sin(t*6+i*Math.PI)*2:0),-4-lg(i)-re*15);
  g.beginPath();g.roundRect(-8.5,-14,17,20,8);pF(g,far?C.skd:C.sk,2.4);if(!far){for(let k=-1;k<=1;k++){pC(g,k*4.6,4.6,2.2);g.fillStyle=C.skd;g.fill()}pC(g,-2,-6,2.3);g.fillStyle=C.sp;g.fill()}g.restore()};
 leg(-14,1,1);leg(32,0,1);
 /* little pointed tail */
 g.save();g.translate(-48+re*8,-17);g.rotate(Math.sin(t*2.4)*.18-.15);g.beginPath();g.moveTo(4,-4);g.quadraticCurveTo(-6,-2,-11,3);g.quadraticCurveTo(-4,3,4,4);g.closePath();pF(g,C.sk,2.2);g.restore();
 /* neck and head: they slide forward out of the shell, and back in */
 const out=1-re,hx=40+out*16,hy=-26+Math.sin(t*1.6)*1.2-(gr?pSeg(u,.1,.4)*7:0),hs=.7+out*.3;
 g.save();g.translate(hx,hy);g.rotate(gr?-.22*pSeg(u,.1,.4):Math.sin(t*.9)*.05);g.scale(hs,hs);
 pLimb(g,-24,10,-6,3,8.5,9.5,C.sk);g.beginPath();g.moveTo(-20,2);g.quadraticCurveTo(-14,6,-8,5);g.strokeStyle=C.skd;g.lineWidth=1.6;g.stroke();
 pE(g,4,-2,16,13.5);pF(g,C.sk);pE(g,10,6,6,3);g.fillStyle=C.skd;g.fill();
 for(const [x,y,r] of[[-4,-10,2.6],[-8,-1,2],[0,6,1.8]]){pC(g,x,y,r);g.fillStyle=C.sp;g.fill()}
 pEye(g,8,-5,6.2,C.ey,pBlink(t,1),gr&&u>.25&&u<.9);g.beginPath();g.moveTo(13,5);g.quadraticCurveTo(17,7,19,4);g.strokeStyle=PTO;g.lineWidth=1.8;g.stroke();
 if(gr&&u>.25&&u<.9){pE(g,12,1,3.4,2);g.fillStyle='#ff8aa077';g.fill()}g.restore();
 /* shell: skirt, dome, plates and a curved rim of marginal scutes */
 const dome=()=>{g.beginPath();g.moveTo(-50,-24);g.bezierCurveTo(-48,-74,40,-74,42,-24);g.closePath()};
 g.save();g.scale(1,br);pE(g,-4,-21,47,10);pF(g,C.shd);
 dome();pF(g,pLin(g,0,-70,0,-24,[C.shl,C.sh,C.shd]),3);
 g.save();dome();g.clip();g.strokeStyle=C.pl;g.lineWidth=2;
 const hex=(x,y,r)=>{g.beginPath();for(let i=0;i<6;i++){const a=i*Math.PI/3;g.lineTo(x+Math.cos(a)*r,y+Math.sin(a)*r*.8)}g.closePath()};
 const HX=[[-4,-46,13],[-28,-36,11],[20,-36,11],[-42,-27,8],[36,-27,8]];
 for(const [x,y,r] of HX){hex(x,y,r);g.fillStyle=C.shl+'44';g.fill();g.stroke()}
 if(sig){/* Elder Grove: amber sap glows in the seams and moss creeps over the plates */
  const pu=.6+.4*Math.sin(t*2.2);g.save();g.globalCompositeOperation='lighter';for(const [x,y,r] of HX){hex(x,y,r);g.strokeStyle=`rgba(255,200,90,${.55*pu})`;g.lineWidth=2.2;g.stroke();pGlow(g,x,y,r*.9,'#ffc84a',.22*pu)}g.restore();
  for(const [x,y] of[[-36,-44],[12,-56],[30,-46],[-16,-58]]){for(let k=0;k<5;k++){pC(g,x+Math.cos(k*1.3)*4,y+Math.sin(k*1.9)*2.4,2.6);g.fillStyle=k%2?'#7ad04a':'#a6e85a';g.fill()}}
  /* a glowing seed of sap at the heart of each big plate */for(const [x,y,r] of HX.slice(0,3)){pGlow(g,x,y,r*.7,'#ffd27a',.5*pu);pE(g,x,y,2.6,3.4);g.fillStyle='#fff0b8';g.fill()}}
 g.restore();
 /* rim scutes follow the curve of the shell */
 for(let i=0;i<10;i++){const x=-45+i*9.6,y=-24+Math.pow((x+4)/46,2)*-2.5;g.beginPath();g.roundRect(x-4.6,y-4.4,9.2,8.8,3.4);pF(g,pLin(g,0,y-4,0,y+4,[C.sh,C.shd]),1.8);g.fillStyle=C.shl+'55';g.fillRect(x-2.6,y-3,5.2,1.6)}
 g.restore();
 /* near legs */
 leg(-30,0,0);leg(20,1,0);
 /* the crown: three leaf plates and a blue flower (a sapling for the Elder Grove style) */
 const lw=Math.sin(t*1.3)*.05;
 if(sig){g.beginPath();g.moveTo(-4,-60);g.quadraticCurveTo(-7,-72,-2,-84);g.moveTo(-5,-70);g.quadraticCurveTo(-12,-74,-14,-80);g.moveTo(-4,-74);g.quadraticCurveTo(4,-76,8,-82);g.strokeStyle='#4a2e14';g.lineWidth=5;g.stroke();g.strokeStyle='#a87a4a';g.lineWidth=2.6;g.stroke();
  const sw=Math.sin(t*1.2)*1.5;g.save();g.translate(sw,0);const CB=[[-15,-84,11],[9,-85,12],[-3,-96,13],[-5,-80,10],[5,-78,9]];g.beginPath();for(const [x,y,r] of CB){g.moveTo(x+r,y);g.arc(x,y,r,0,TAU)}g.strokeStyle=PTO;g.lineWidth=4.8;g.stroke();g.fillStyle=pLin(g,0,-110,0,-70,[C.lf,C.lfd,'#1e5a1e']);g.fill();
  for(const [x,y,r] of CB){pC(g,x-r*.3,y-r*.35,r*.42);g.fillStyle='#ffffff26';g.fill()}
  for(const [x,y] of[[-14,-90],[5,-94],[-4,-84],[12,-86],[-18,-80],[-6,-102],[2,-77]]){pGlow(g,x,y,6,'#ffe27a',.4+.3*Math.sin(t*3+x));pC(g,x,y,2.3);g.fillStyle='#ffe27a';g.fill();pC(g,x-.6,y-.6,.9);g.fillStyle='#fff';g.fill()}g.restore()}
 else{pLeaf(g,-8,-60,30,10,-2.5+lw,C.lf,C.lfd);pLeaf(g,-4,-62,32,11,-1.45-lw,C.lf,C.lfd);pLeaf(g,0,-60,30,10,-.5+lw,C.lf,C.lfd)}
 if(o.acc){g.beginPath();g.moveTo(-44,-33);g.quadraticCurveTo(-4,-25+Math.sin(t*1.4),38,-33);g.strokeStyle='#3a8a2a';g.lineWidth=2.4;g.stroke();for(let i=0;i<7;i++){const x=-40+i*12.5,y=-32+Math.sin(i*1.3)*1.6+(i===0||i===6?-2:0);if(i%2)pLeaf(g,x,y,8,3,.6+i,'#8ae04a','#3a8a2a',1.2);else pFlower(g,x,y,4.6,['#ffb4e0','#fff2a0','#b4d8ff'][i%3])}}
 pFlower(g,-3,-60,7.5,C.fl);{const gp=(t*.35)%2.2;if(gp<1){g.save();dome();g.clip();g.globalCompositeOperation='lighter';g.translate(-60+gp*110,-50);g.rotate(.5);const q=g.createLinearGradient(-8,0,8,0);q.addColorStop(0,'#ffffff00');q.addColorStop(.5,'#ffffff30');q.addColorStop(1,'#ffffff00');g.fillStyle=q;g.fillRect(-8,-40,16,80);g.restore()}}
 /* Leafguard: the retracted shell glows and a leaf dome forms */
 if(ab){const s=pSeg(u,.25,.45)*(1-pSeg(u,.8,1));if(s>0){pGlow(g,0,-40,70*s,'#7aff6a',.45*s);g.save();g.globalAlpha=.55*s;g.beginPath();g.ellipse(4,-40,62*s,58*s,0,Math.PI*1.05,Math.PI*1.95+.4);g.lineWidth=7;g.strokeStyle='#9aff7a';g.stroke();g.restore();
   for(let i=0;i<5;i++){const a=t*2+i*TAU/5;pLeaf(g,Math.cos(a)*54*s,-40+Math.sin(a)*40*s,12,4,a+1.6,'#a6ff6a','#3a9a2a',1.2)}}}
 g.restore()};

/* MOSSKIP: leaf-eared hare; two short hops, a pause to sniff */
PRIG.mosskip=(g,o,C)=>{const t=o.t,P=o.pose,u=o.u,walk=P==='walk',ab=P==='ability',gr=P==='greet';
 let hopY=0,sq=1,lean=0;if(walk){const c=(t*.85)%1,h=(a,b)=>c>a&&c<b?Math.sin((c-a)/(b-a)*Math.PI):0,v=h(0,.28)+h(.34,.62);hopY=-v*14;sq=1+(c<.04||(c>.3&&c<.36)?-.06:0);lean=v*.12}
 const stand=gr?Math.sin(pSeg(u,0,.6)*Math.PI*.5)*(1-pSeg(u,.8,1)):0,sniff=walk&&(t*.85)%1>.66?Math.sin(t*30)*1.2:Math.sin(t*14)*.6*(((t%5)<1)?1:0);
 g.save();g.translate(0,hopY);g.scale(1,sq);g.rotate(-lean-stand*.42);
 /* leaf tail */pLeaf(g,-30,-26,18,7,-2.6+Math.sin(t*3)*.15,C.ea,C.ead,2);
 /* far legs */pLimb(g,8,-18,10,-1,4,3.6,C.bd);pE(g,-14,-3,10,4.5);pF(g,C.bd);
 /* body and haunch */pE(g,-6,-28,26,20,-.15);pF(g,pLin(g,0,-48,0,-8,[C.b,C.b,C.bd]));pE(g,-16,-20,16,16);pF(g,C.b);
 pE(g,8,-34,12,15,.2);pF(g,C.ch,2);
 if(o.trim){/* a glowing spirit-leaf mark on the haunch */g.save();g.globalAlpha=.55+.2*Math.sin(t*2.4);g.globalCompositeOperation='lighter';pLeaf(g,-26,-16,20,7,-.5,'#b8ffd8','#5ad8a0',0);g.restore();pGlow(g,-17,-21,14,'#9affc8',.25)}
 /* near legs */pE(g,-12,-2,13,5);pF(g,C.b);pLimb(g,14,-20,16,-1,4.4,4,C.b);
  /* head */const hx=20,hy=-60+(stand*-4);g.save();g.translate(hx,hy);g.rotate(stand*.3+(sniff*.02));
 /* ears: broad leaves, one twitches */const tw=(t%3.3)<.25?Math.sin((t%3.3)/.25*Math.PI)*.35:0;
 const a1=-1.95+Math.sin(t*1.1)*.04,a2=-1.6+tw-(gr?pSeg(u,.3,.5)*.3*(1-pSeg(u,.7,.9)):0),sb=o.trim;
 if(sb){const pu=.5+.3*Math.sin(t*2.4);pGlow(g,-8+Math.cos(a1)*20,-8+Math.sin(a1)*20,24,'#9affc8',pu);pGlow(g,-2+Math.cos(a2)*21,-10+Math.sin(a2)*21,24,'#9affc8',pu)}
 const e1=sb?'#eafff2':C.ea,e2=sb?'#3ac890':C.ead;pLeaf(g,-8,-8,36,11,a1,e1,e2);pLeaf(g,-2,-10,38,12,a2,e1,e2);
 if(sb){g.save();g.globalCompositeOperation='lighter';for(const [x,y,a,l] of[[-8,-8,a1,36],[-2,-10,a2,38]]){g.beginPath();g.moveTo(x+Math.cos(a)*3,y+Math.sin(a)*3);g.lineTo(x+Math.cos(a)*l*.86,y+Math.sin(a)*l*.86);g.strokeStyle='#9affd0';g.lineWidth=2;g.stroke()}g.restore();
  for(const [x,y,a,l,r] of[[-8,-8,a1,36,4.4],[-2,-10,a2,38,5]]){const fx=x+Math.cos(a)*l,fy=y+Math.sin(a)*l;pGlow(g,fx,fy,10,'#fff6c0',.5);pFlower(g,fx,fy,r,'#ffffff','#ffd45a')}}
 pE(g,0,0,15,13);pF(g,C.b);pE(g,11,4,8,6.5);pF(g,C.ch,2);pE(g,18,2+sniff*.4,2.8,2.2);pF(g,C.no,1.4);g.beginPath();for(const d of[-2,1.4]){g.moveTo(17,4+d*.4);g.lineTo(26,2+d*2+sniff*.5)}g.strokeStyle='#5a4a3a88';g.lineWidth=1;g.stroke();
 g.beginPath();g.moveTo(16,6);g.quadraticCurveTo(14,10,11,9);g.strokeStyle=PTO;g.lineWidth=1.6;g.stroke();
 pEye(g,4,-2,5.6,C.ey,pBlink(t,2),gr&&u>.2&&u<.9);if(o.acc){/* explorer scarf */}
 g.restore();
 /* green neck ruff */for(let i=0;i<5;i++)pLeaf(g,6+i*3.4,-48+Math.abs(i-2)*1.2,12,5,1.05+i*.26,C.rf,C.rfd,1.8);
 if(o.acc){g.beginPath();g.moveTo(2,-52);g.quadraticCurveTo(14,-44,26,-50);g.lineTo(26,-44);g.quadraticCurveTo(14,-38,2,-46);g.closePath();pF(g,'#e2463a',2);pP(g,[4,-50,-6,-38+Math.sin(t*4)*2,0,-36,8,-46]);pF(g,'#c2302a',2)}
 g.restore();
 /* Trail Scholar: a little book of leaves flips open overhead */
 if(ab){const s=pSeg(u,.1,.35)*(1-pSeg(u,.8,1)),y=-96-pSeg(u,.1,.5)*10;if(s>0){g.save();g.translate(8,y);g.scale(s,s);pGlow(g,0,0,40,'#9aff7a',.5);
  const op=pSeg(u,.25,.5);for(const d of[-1,1]){g.save();g.scale(d,1);g.beginPath();g.moveTo(0,8);g.quadraticCurveTo(10,4-op*4,22,6);g.lineTo(22,-12);g.quadraticCurveTo(10,-16-op*4,0,-10);g.closePath();pF(g,'#fff6dc',2);g.restore()}
  pLeaf(g,-2,-2,14,5,-.6,'#86d24e','#3a962a',1.4);for(let i=0;i<4;i++){const a=t*3+i*1.6;pStar4(g,Math.cos(a)*26,-8+Math.sin(a)*12,3,'#fff6a0')}g.restore()}}};

/* ANTLERLIGHT: cream-and-teal fawn with golden antlers and a heart gem; bows to heal */
PRIG.antler=(g,o,C)=>{const t=o.t,P=o.pose,u=o.u,walk=P==='walk',ab=P==='ability',gr=P==='greet';
 const bow=ab?pSeg(u,0,.3)*(1-pSeg(u,.75,1)):0,lift=gr?Math.sin(pSeg(u,0,.7)*Math.PI):0;
 const tr=walk?t*7:0,leg=(ph,amp)=>walk?Math.sin(tr+ph)*amp:0,br=Math.sin(t*2)*.8;
 if(P==='idle'||gr||ab){/* drifting leaves around a Legendary */for(let i=0;i<3;i++){const v=((t*.18+i/3)%1);g.globalAlpha=Math.sin(v*Math.PI)*.8;pLeaf(g,-30+i*30+Math.sin(t+i)*8,-20-v*80,8,3,t+i,'#9aff8a','#3aa04a',1);g.globalAlpha=1}}
 const L=(x,y,ph,c,band,front)=>{const k=front&&gr?lift:0,sw=leg(ph,.45);g.save();g.translate(x,y);g.rotate(sw-k*.9);pLimb(g,0,0,0,24,5.2,3.8,c);g.translate(0,24);g.rotate(-sw*.6+k*1.6);pLimb(g,0,0,0,22,3.8,3,c);pE(g,0,23,4,3.4);pF(g,C.hf,2);if(band){g.beginPath();g.roundRect(-4.6,14,9.2,4.4,2);pF(g,'#ffd45a',1.6)}g.restore()};
 g.save();g.translate(0,-br*.3);
 L(-18,-50,Math.PI,C.bd,1,0);L(16,-50,0,C.bd,1,1);
 /* leaf tail */pLeaf(g,-30,-56,18,8,-2.3+Math.sin(t*4)*.25,C.lf,'#2e8a3a',2);
 /* body */pE(g,-4,-52,30,15);pF(g,pLin(g,0,-66,0,-38,[C.b,C.b,C.bd]));
 g.save();pE(g,-4,-52,30,15);g.clip();pE(g,-10,-60,26,10);g.fillStyle=C.tl;g.fill();for(const [x,y] of[[-22,-58],[-12,-62],[-2,-58],[-28,-52],[6,-62]]){if(o.trim){pGlow(g,x,y,6,'#bff6ff',.6);pStar4(g,x,y,3,'#ffffff')}else{pC(g,x,y,2.2);g.fillStyle='#fff';g.fill()}}g.restore();
 if(o.trim){g.beginPath();g.ellipse(-4,-52,30,15,0,Math.PI*1.08,Math.PI*1.92);pTrim(g,2.4)}
 L(-22,-46,0,C.b,1,0);L(14,-46,Math.PI,C.b,1,1);
 /* neck and head, bowing for Heartgrove */
 g.save();g.translate(18,-58);g.rotate(bow*1.1-(gr?lift*.15:0)+Math.sin(t*.7)*.04);
 pLimb(g,0,0,8,-20,8,6.5,C.b);g.save();g.beginPath();g.moveTo(-4,-2);g.lineTo(6,-20);g.lineTo(10,-18);g.lineTo(4,0);g.closePath();g.fillStyle=C.tl;g.globalAlpha=.8;g.fill();g.restore();
 g.translate(10,-26);
 /* antlers */const ag=.4+.3*Math.sin(t*2.4),sl=o.trim;pGlow(g,-2,-14,22,'#ffd45a',.2*ag);if(sl)pGlow(g,-2,-22,40,'#8ae8ff',.55*ag+.15);
 for(const [x,s] of[[-6,-1],[2,1]]){g.beginPath();g.moveTo(x,-8);g.quadraticCurveTo(x+s*2,-18,x-2,-26);g.moveTo(x+.6,-16);g.quadraticCurveTo(x+6,-20,x+7,-24);if(sl){g.moveTo(x-1,-21);g.quadraticCurveTo(x-6,-24,x-9,-30);g.moveTo(x-2,-26);g.lineTo(x-1,-33)}
  g.strokeStyle=PTO;g.lineWidth=sl?6.6:6;g.stroke();g.strokeStyle=sl?'#e8fcff':C.an;g.lineWidth=sl?4:3.4;g.stroke();if(sl){g.save();g.globalCompositeOperation='lighter';g.strokeStyle='#7ae0ff';g.lineWidth=1.4;g.stroke();g.restore()}}
 if(sl){/* star lanterns hang from the tines */for(const [x,y,ph] of[[1,-24,0],[9,-24,1.7],[-11,-30,3.1],[-3,-33,4.2]]){const sw=Math.sin(t*2+ph)*.25,ly=y+7;g.beginPath();g.moveTo(x,y);g.lineTo(x+Math.sin(sw)*7,ly);g.strokeStyle='#cfefff99';g.lineWidth=.8;g.stroke();const tw=.7+.3*Math.sin(t*3+ph);pGlow(g,x+Math.sin(sw)*7,ly+2,9,'#9af0ff',.55*tw);pStar4(g,x+Math.sin(sw)*7,ly+2,3.4*tw+.8,'#ffffff')}}
 /* ears */const tw=(t%3.7)<.2?.3:0;pLeaf(g,-8,-6,18,7,-2.7-tw,C.b,C.bd,2.2);pLeaf(g,4,-6,18,7,-.45+tw*.5,C.b,C.bd,2.2);pE(g,-15,-10,4,2,-.4);g.fillStyle=C.ie;g.fill();
 pE(g,0,0,13,12);pF(g,C.b);pE(g,10,5,8,5.6,.2);pF(g,C.b);pE(g,17,4,2.4,2);g.fillStyle=PTO;g.fill();pE(g,-6,-5,7,5);g.fillStyle=C.tl;g.globalAlpha=.6;g.fill();g.globalAlpha=1;
 pEye(g,3,-2,5.4,C.ey,ab&&u>.25&&u<.75?0:pBlink(t,3),gr&&u>.3&&u<.9);
 if(o.acc){pFlower(g,-8,-12,4.4,'#ffb4e0');pFlower(g,-2,-14,3.6,'#fff2a0')}
 g.restore();
 /* heart gem */const hgw=.5+.5*Math.sin(t*2.6)+(ab?pSeg(u,.25,.45)*(1-pSeg(u,.7,.9))*2:0);pGlow(g,22,-50,18+hgw*6,'#3cff86',.25+hgw*.15);pHeart(g,22,-50,5.4,pLin(g,0,-56,0,-44,['#c8ffd8',C.hg,'#0a9a4a']),1.8);
 g.restore();
 if(ab){const s=pSeg(u,.25,.5),f=1-pSeg(u,.8,1);if(s>0){g.save();g.scale(1,.28);for(let i=0;i<2;i++){const r=30+s*80+i*24;g.beginPath();g.arc(10,0,r,0,TAU);g.strokeStyle='#7aff9a';g.globalAlpha=.6*f*(1-i*.35);g.lineWidth=6;g.stroke()}g.restore();g.globalAlpha=1;
  const hy=-60-pSeg(u,.35,.85)*60;pGlow(g,20,hy,30,'#3cff86',.6*f);g.globalAlpha=f;pHeart(g,20,hy,10,'#5aff9a',2.2);g.globalAlpha=1;
  for(let i=0;i<6;i++){const a=t*2+i;g.globalAlpha=f*.8;pLeaf(g,10+Math.cos(a)*60*s,-10-Math.abs(Math.sin(a))*50*s,9,3.5,a,'#9aff8a','#3aa04a',1);g.globalAlpha=1}}}};

/* CINDERNEWT: ember salamander; warms its feet, exhales one readable ember */
PRIG.cinder=(g,o,C)=>{const t=o.t,P=o.pose,u=o.u,walk=P==='walk',ab=P==='ability',gr=P==='greet';
 const wig=walk?Math.sin(t*9):0,inh=ab?pSeg(u,0,.3)*(1-pSeg(u,.35,.45)):0,mouth=ab?pSeg(u,.35,.42)*(1-pSeg(u,.6,.75)):0;
 const fb=1+(gr?pSeg(u,.1,.4)*.6*(1-pSeg(u,.8,1)):0)+(ab?inh*.3:0);
 const flame=(x,y,s)=>{const f=Math.sin(t*14)*.12,f2=Math.sin(t*9+1)*.1;pGlow(g,x,y-8*s,30*s,C.f2,.45);g.save();g.translate(x,y);g.scale(s,s);
  g.beginPath();g.moveTo(-9,4);g.bezierCurveTo(-14,-10,-4+f*10,-18,-2+f*16,-32);g.bezierCurveTo(4,-20,14+f2*10,-16,9,4);g.closePath();pF(g,C.f3,2.2);
  g.beginPath();g.moveTo(-6,3);g.bezierCurveTo(-8,-6,-2,-12,0+f*10,-22);g.bezierCurveTo(4,-12,9,-8,6,3);g.closePath();g.fillStyle=C.f2;g.fill();
  g.beginPath();g.moveTo(-3,3);g.bezierCurveTo(-4,-3,0,-6,1+f*6,-12);g.bezierCurveTo(3,-6,5,-3,3,3);g.closePath();g.fillStyle=C.f1;g.fill();
  if(o.trim){g.beginPath();g.moveTo(-1.6,2);g.bezierCurveTo(-2,-1,0,-3,.6+f*4,-7);g.bezierCurveTo(2,-3,2.6,-1,1.6,2);g.closePath();g.fillStyle='#ffffff';g.fill()}g.restore()};
 /* warms its feet: lifts a forefoot now and then */const warm=!walk&&!ab&&!gr&&(t%6)<1.2?Math.sin((t%6)/1.2*Math.PI):0;
 const leg=(x,ph,c,lift)=>{const l=walk?Math.max(0,Math.sin(t*9+ph))*5:lift;g.save();g.translate(x,-10-l);pLimb(g,0,-4,x>0?5:-5,8,5,4.4,c);for(let i=-1;i<=1;i++){pE(g,(x>0?5:-5)+i*3.4,12,2.6,2);g.fillStyle=c;g.fill()}g.restore()};
 g.save();g.rotate(wig*.02);
 leg(-22,Math.PI,C.ftd,0);leg(20,0,C.ftd,0);
 /* tail curling up with the flame at its tip */const tw=Math.sin(t*2.2)*.12+wig*.15;
 g.save();g.translate(-30,-20);g.rotate(tw);g.beginPath();g.moveTo(4,-8);g.bezierCurveTo(-18,-6,-34,-14,-30,-36);g.bezierCurveTo(-28,-44,-22,-46,-20,-40);g.bezierCurveTo(-24,-24,-12,-14,6,6);g.closePath();pF(g,pLin(g,0,-40,0,8,[C.bl,C.b,C.bd]));
 for(const [x,y,r] of[[-20,-12,3],[-27,-24,2.4]]){pC(g,x,y,r);g.fillStyle=C.sp;g.fill()}flame(-25,-42,(o.trim?1.12:.85)*fb);g.restore();
 /* body */g.beginPath();g.moveTo(-34,-14);g.bezierCurveTo(-30,-34,10,-36,28,-28);g.lineTo(32,-14);g.bezierCurveTo(10,-6,-20,-4,-34,-14);g.closePath();pF(g,pLin(g,0,-34,0,-6,[C.bl,C.b,C.bd]),3);
 g.save();g.clip();pE(g,-2,-8,34,6);g.fillStyle=C.be;g.fill();if(o.trim){/* Magma Veins: molten cracks pulse under the skin */const pu=.6+.4*Math.sin(t*3);g.fillStyle='#00000030';g.fillRect(-40,-40,80,40);g.save();g.globalCompositeOperation='lighter';
  const V=[[[-32,-16],[-24,-22],[-16,-17],[-8,-26],[2,-21],[10,-29],[18,-24],[28,-27]],[[-16,-17],[-13,-9]],[[2,-21],[5,-11]],[[10,-29],[14,-33]],[[-24,-22],[-26,-30]]];
  for(const [w,c] of[[6,`rgba(255,90,20,${.5*pu})`],[2.4,`rgba(255,220,120,${.9*pu})`]]){g.beginPath();for(const L of V){g.moveTo(L[0][0],L[0][1]);for(const p of L.slice(1))g.lineTo(p[0],p[1])}g.strokeStyle=c;g.lineWidth=w;g.stroke()}g.restore()}
 for(const [x,y,r] of[[-18,-24,4],[-4,-28,4.6],[12,-28,3.6],[-26,-18,2.6],[4,-21,2.6]]){if(o.trim){pGlow(g,x,y,r*2.4,'#ffb03a',.6);pC(g,x,y,r*.8);g.fillStyle='#fff2b0';g.fill()}else{pC(g,x,y,r);g.fillStyle=C.sp;g.fill();pC(g,x+1,y+1,r*.4);g.fillStyle=C.spd;g.fill()}}g.restore();
 if(o.trim){g.beginPath();g.moveTo(-34,-14);g.bezierCurveTo(-30,-34,10,-36,28,-28);pTrim(g,2.2)}
 leg(-26,0,C.ft,0);leg(16,Math.PI,C.ft,warm*6);
 /* head */g.save();g.translate(36,-24);g.rotate(-inh*.15+Math.sin(t*1.3)*.03);const ps=1+inh*.12;g.scale(ps,ps);
 pE(g,0,0,17,12.5);pF(g,pLin(g,0,-12,0,12,[C.bl,C.b,C.bd]));pE(g,6,6,10,4);g.fillStyle=C.be;g.fill();
 if(mouth>0){pE(g,12,5,6*mouth+1,4*mouth+1);pF(g,'#5a1a0a',1.8)}else{g.beginPath();g.moveTo(6,5);g.quadraticCurveTo(12,8,16,4);g.strokeStyle=PTO;g.lineWidth=1.8;g.stroke()}
 pC(g,4,-4,7.4);pF(g,C.ey,2);pEye(g,5,-4,5.8,'#1a0e10',pBlink(t,4),gr&&u>.25&&u<.9);
 if(o.trim){g.save();g.globalCompositeOperation='lighter';g.beginPath();g.moveTo(-14,2);g.lineTo(-8,-2);g.lineTo(-4,4);g.moveTo(-8,-2);g.lineTo(-9,-8);g.strokeStyle=`rgba(255,200,90,${.6+.3*Math.sin(t*3)})`;g.lineWidth=1.8;g.stroke();g.restore()}
 if(inh>.3){pE(g,10,2,5*inh,4*inh);g.fillStyle='#ff9a6a66';g.fill()}
 if(o.acc){g.beginPath();g.ellipse(2,-9,16,4,-.1,Math.PI*.95,Math.PI*2.05);g.strokeStyle='#5a3a24';g.lineWidth=3;g.stroke();for(const [x,y] of[[-2,-11],[9,-12]]){pC(g,x,y,4.6);pF(g,'#8a6a4a',1.8);pC(g,x,y,3.2);pF(g,pRad(g,x,y,3.4,['#fff2c0','#ffb04a','#a8501a']),1);pC(g,x-1,y-1.2,1);g.fillStyle='#fff';g.fill()}}
 g.restore();g.restore();
 if(o.acc){for(let i=0;i<3;i++){const v=(t*.5+i/3)%1;g.globalAlpha=(1-v)*.8;pC(g,-24+i*6+Math.sin(t*3+i)*4,-60-v*30,1.8);g.fillStyle=C.f1;g.fill();g.globalAlpha=1}}
 /* Ember Tag: one ember flies forward */
 if(ab&&u>.38&&u<.85){const v=pSeg(u,.38,.85),x=56+v*90,y=-26-Math.sin(v*Math.PI)*16;pGlow(g,x,y,26,C.f2,.7*(1-v*.6));g.save();g.translate(x,y);g.rotate(Math.PI/2);flame(0,6,.55);g.restore()}};

/* FORGEBEETLE: six-legged iron beetle with bronze plates and a forehead coin */
PRIG.beetle=(g,o,C)=>{const t=o.t,P=o.pose,u=o.u,walk=P==='walk',ab=P==='ability',gr=P==='greet';
 const rear=gr?Math.sin(pSeg(u,0,.6)*Math.PI*.5)*(1-pSeg(u,.8,1)):0,bob=walk?Math.abs(Math.sin(t*10))*1.4:Math.sin(t*2)*.6;
 const polish=!walk&&!ab&&!gr&&(t%7)<1.6?Math.sin((t%7)/1.6*Math.PI*4):0;
 g.save();g.translate(0,-bob);g.rotate(-rear*.32);
 const leg=(x,i,c,front)=>{const l=walk?Math.max(0,Math.sin(t*10+i*2.1))*5:0,sw=walk?Math.sin(t*10+i*2.1)*.25:0;g.save();g.translate(x,-16);g.rotate(sw+(front&&polish?polish*.3-.4:0));pP(g,[-5,-2,5,-2,(x>0?12:-8),9-l,(x>0?8:-2),20-l,(x>0?2:-6),20-l,(x>0?0:-12),8-l]);pF(g,c,2.4);g.restore()};
 leg(-20,1,C.bd);leg(-2,3,C.bd);leg(16,5,C.bd);
 /* body */pE(g,4,-26,34,21);pF(g,pLin(g,0,-42,0,-6,[C.bl,C.b,C.bd]));
 /* head with horns, eyes and the coin badge */g.save();g.translate(32,-24);g.rotate(rear*.2);
 for(const [x,a] of[[-4,-.5],[6,.3]]){g.save();g.translate(x,-10);g.rotate(a);pP(g,[-3,0,3,0,1,-12]);pF(g,o.trim?pLin(g,0,-12,0,0,['#fff6c0','#ffd45a','#b8801a']):C.bl,2);g.restore()}
 pE(g,0,0,15,13);pF(g,C.b);const ey=pBlink(t,5);for(const [x,s] of[[4,1],[10,.8]]){pGlow(g,x,1,10,C.ey,.4);if(gr&&u>.25&&u<.9){g.beginPath();g.arc(x,3,3.2*s,Math.PI*1.1,Math.PI*1.9);g.strokeStyle=C.ey;g.lineWidth=2.4;g.stroke()}else{pE(g,x,1,3.6*s,4.2*s*ey);pF(g,C.ey,1.6);pC(g,x+1,0,1.2);g.fillStyle='#fff';g.fill()}}
 /* antennae */for(const [x,a] of[[-2,-.5],[7,-.2]]){const bob=Math.sin(t*3+x)*1.6;g.beginPath();g.moveTo(x,-10);g.quadraticCurveTo(x+a*10+4,-24,x+a*16+10,-26+bob);g.strokeStyle=PTO;g.lineWidth=2;g.stroke();pC(g,x+a*16+10,-26+bob,2.2);pF(g,C.ey,1)}
 const cs=1+(ab?pSeg(u,.2,.4)*.3*(1-pSeg(u,.6,.8)):0);pC(g,2,-12,6.8*cs);pF(g,pLin(g,-6,-18,6,-6,['#fff2a0',C.cn,'#b8801a']),2);g.beginPath();g.moveTo(2,-16);g.lineTo(2,-8);g.strokeStyle='#9a661a';g.lineWidth=1.6;g.stroke();
 const gl=(t%3.2)/.5;if(gl<1){pStar4(g,4+gl*2,-15,3+Math.sin(gl*Math.PI)*2,'#ffffffdd')}
 g.restore();
 /* three bronze plates, front to back */
 for(let i=2;i>=0;i--){const x=-22+i*15,w=22;g.beginPath();g.moveTo(x-w*.8,-24);g.bezierCurveTo(x-w*.8,-64+i*4,x+w*.8,-64+i*4,x+w*.9,-24);g.closePath();pF(g,pLin(g,0,-50,0,-24,[C.pll,C.pl,C.pld]),2.6);g.beginPath();g.moveTo(x-w*.45,-50+i*4);g.quadraticCurveTo(x,-55+i*4,x+w*.45,-50+i*4);g.strokeStyle='#ffffff88';g.lineWidth=2;g.stroke();if(o.trim){/* a cut gem set into every plate */const gy=-38+i*2,gc=[['#ffb0c0','#e0283a','#7a0a1a'],['#c8ffd8','#2ad06a','#0a6a3a'],['#c8e4ff','#3a7aff','#1a2a8a']][i];pP(g,[x,gy-6,x+5,gy,x,gy+6,x-5,gy]);pF(g,pLin(g,0,gy-6,0,gy+6,gc),1.6);pP(g,[x,gy-6,x+2,gy-1,x,gy+1,x-2,gy-1]);g.fillStyle='#ffffffaa';g.fill();
   g.beginPath();g.moveTo(x-w*.75,-27);g.bezierCurveTo(x-w*.75,-60+i*4,x+w*.75,-60+i*4,x+w*.85,-27);g.strokeStyle='#ffe48a';g.lineWidth=1.4;g.setLineDash([2,3]);g.stroke();g.setLineDash([])}}
 if(o.trim){/* the hoard: a little stack of coins and a ruby on its back */for(let k=0;k<4;k++){const y=-58-k*3.4,x=-8+Math.sin(k*1.9)*1.6;pE(g,x,y,9-k*.6,3.2);pF(g,pLin(g,0,y-3,0,y+3,['#fff2a0','#ffd45a','#a8701a']),1.6)}
  pP(g,[-8,-78,-3,-73,-8,-68,-13,-73]);pF(g,pLin(g,0,-78,0,-68,['#ffb0c0','#e0283a','#7a0a1a']),1.6);const gt=(t%2.4)/.4;if(gt<1)pStar4(g,-6,-76,2+Math.sin(gt*Math.PI)*4,'#ffffff');
  for(const [x,y] of[[16,-30],[-34,-30]]){pE(g,x,y,5,2);pF(g,'#ffd45a',1.2)}}
 if(o.acc){g.save();g.translate(-24,-44);pP(g,[0,0,0,-22,2,-22,2,0]);pF(g,'#8a6a3a',1.4);pP(g,[2,-22,18,-20+Math.sin(t*4)*1.5,16,-14,18,-8+Math.sin(t*4)*1.5,2,-10]);pF(g,'#3a5ad8',1.8);pStar4(g,9,-15,3,'#ffd45a');g.restore()}
 leg(-26,0,C.b);leg(-6,2,C.b);leg(12,4,C.b,1);
 g.restore();
 /* Gilded Gatherer: a coin flips up out of the shell */
 if(ab){const v=pSeg(u,.25,.85);if(v>0&&v<1){const y=-50-Math.sin(v*Math.PI)*46,sx=Math.abs(Math.cos(v*TAU*2));g.save();g.translate(20,y);g.scale(Math.max(.15,sx),1);pC(g,0,0,9);pF(g,pLin(g,-9,-9,9,9,['#fff2a0','#ffd45a','#b8801a']),2.2);g.restore();pGlow(g,20,y,22,'#ffd45a',.4);if(v>.7)for(let i=0;i<4;i++)pStar4(g,20+Math.cos(i*1.6)*18*v,y+Math.sin(i*1.6)*12*v,3,'#fff6c0')}}};

/* EMBERCREST: gryphon hatchling; ruffles its wings, spreads them wide for Cinder Sweep */
PRIG.ember=(g,o,C)=>{const t=o.t,P=o.pose,u=o.u,walk=P==='walk',ab=P==='ability',gr=P==='greet';
 const spread=ab?pSeg(u,.1,.35)*(1-pSeg(u,.8,1)):gr?pSeg(u,0,.35)*(1-pSeg(u,.75,1)):(t%6)<.6?Math.sin((t%6)/.6*Math.PI)*.18:0;
 const sweep=ab?pSeg(u,.4,.62):0,strut=walk?Math.sin(t*7):0,br=Math.sin(t*2)*.8;
 const leg=(x,y,ph,c,talon)=>{const s=walk?Math.sin(t*7+ph)*.4:0;g.save();g.translate(x,y);g.rotate(s);pLimb(g,0,0,1,18,5.6,4.4,c);g.translate(1,20);if(talon){for(let i=-1;i<=1;i++){g.beginPath();g.moveTo(i*3,-2);g.lineTo(i*3+3,4);g.strokeStyle=PTO;g.lineWidth=4;g.stroke();g.strokeStyle=C.cl;g.lineWidth=2.2;g.stroke()}}else{pE(g,0,0,6,3.6);pF(g,c,2)}g.restore()};
 /* far wing (spread only) */
 const wing=(far)=>{g.save();g.translate(4,-56);const a=spread*1.2+(far?.16:0)+sweep*1.5*(far?.6:1);g.rotate(a);g.scale(1,far?.85:1);
  const ph=o.trim,L=(i,len,c)=>{g.save();g.rotate(-.5+i*.2);g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(-len*.5,-8,-len,2);g.quadraticCurveTo(-len*.55,8,0,6);g.closePath();pF(g,c,2);
   if(ph){/* each plume ends in a living flame */const fl=Math.sin(t*13+i*1.7)*.18,fx=-len+2,s=.9+.15*Math.sin(t*9+i);g.save();g.translate(fx,2);g.rotate(Math.PI/2+.25);g.scale(s,s);pGlow(g,0,-6,14,'#ff8a2a',.55);g.globalCompositeOperation='lighter';
    for(const [c2,k] of[['#ff5a1a',1],['#ffb03a',.7],['#fff2b0',.4]]){g.beginPath();g.moveTo(-4*k,0);g.quadraticCurveTo(-6*k,-8*k,fl*10,-16*k);g.quadraticCurveTo(6*k,-8*k,4*k,0);g.closePath();g.fillStyle=c2;g.fill()}g.restore()}g.restore()};
  for(let i=4;i>=0;i--)L(i,40+i*3,ph?pLin(g,-50,0,0,0,['#fff2b0','#ffb03a','#e83a1a']):pLin(g,-50,0,0,0,[C.wt,C.w1,C.w2]));pE(g,-10,0,16,10,-.3);pF(g,far?C.fd:C.f,2.4);g.restore()};
 g.save();g.translate(0,-br*.3);
 if(spread>.05)wing(1);
 leg(-20,-26,Math.PI,C.rbd,0);leg(14,-30,0,C.cl,1);
 /* lion tail with a flame tuft */g.save();g.translate(-30,-34);g.rotate(Math.sin(t*2.3)*.18);g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(-18,8,-26,-6);g.strokeStyle=PTO;g.lineWidth=7;g.stroke();g.strokeStyle=C.rb;g.lineWidth=4;g.stroke();
 g.translate(-28,-8);const fl=Math.sin(t*12)*.15;if(o.trim){g.scale(1.6,1.6);pGlow(g,0,-6,16,'#ff8a2a',.6)}for(const [c,s] of(o.trim?[['#e83a1a',1],['#ffb03a',.75],['#fff2b0',.45]]:[[C.f,1],[C.w2,.75],[C.wt,.45]])){g.beginPath();g.moveTo(0,6*s);g.quadraticCurveTo(-12*s,0,-6*s+fl*8,-14*s);g.quadraticCurveTo(0,-6*s,6*s,-12*s);g.quadraticCurveTo(10*s,0,0,6*s);g.closePath();pF(g,c,s===1?2:0)}g.restore();
 /* body: charcoal hind, crimson front */pE(g,-14,-36,18,13);pF(g,C.rb);pE(g,4,-42,24,16,-.2);pF(g,pLin(g,0,-58,0,-26,[C.f,C.f,C.fd]));
 pE(g,18,-46,12,14,-.3);pF(g,C.ch,2);for(let i=0;i<3;i++){g.beginPath();g.arc(16+i*2,-52+i*7,4,.2,2.4);g.strokeStyle='#d8c8a8';g.lineWidth=1.4;g.stroke()}
 leg(-14,-26,0,C.rb,0);leg(20,-32,Math.PI,C.cl,1);
 /* near wing */wing(0);
 /* head */g.save();g.translate(28,-66);g.rotate((gr?-.25*spread:0)+Math.sin(t*.8)*.05+strut*.03);
 const cf=Math.sin(t*5)*.1;if(o.trim){/* a crest of flame */pGlow(g,-2,-20,20,'#ff8a2a',.5);for(let i=0;i<4;i++){const fl=Math.sin(t*12+i*2)*.2;g.save();g.translate(-10+i*5,-10);g.rotate(-.9+i*.3+cf);for(const [c2,k] of[['#e83a1a',1],['#ffb03a',.7],['#fff2b0',.42]]){g.beginPath();g.moveTo(-4*k,0);g.quadraticCurveTo(-5*k,-10*k,fl*12,-(18+i*2)*k);g.quadraticCurveTo(5*k,-10*k,4*k,0);g.closePath();g.fillStyle=c2;g.fill()}g.restore()}}
 else for(let i=0;i<3;i++){g.save();g.translate(-8+i*5,-11);g.rotate(-.9+i*.35+cf);pP(g,[-3,0,3,0,0,-14-i*2]);pF(g,C.cr,2);g.restore()}
 pE(g,0,0,14,13);pF(g,pLin(g,0,-13,0,13,[C.f,C.f,C.fd]));pE(g,-2,7,9,5);g.fillStyle=C.ch;g.fill();
 /* hooked beak */const op=ab?pSeg(u,.38,.48)*(1-pSeg(u,.65,.8)):0;g.beginPath();g.moveTo(9,-3);g.quadraticCurveTo(22,-4,22,6);g.quadraticCurveTo(16,3,9,4);g.closePath();pF(g,pLin(g,9,-4,22,6,[C.bk,C.bkd]),2.2);if(op>0){pP(g,[9,4,18,6+op*6,10,8]);pF(g,C.bkd,1.8)}
 pEye(g,3,-3,5.2,C.ey,pBlink(t,6),gr&&u>.3&&u<.9);g.beginPath();g.moveTo(-3,-9);g.lineTo(8,-7);g.strokeStyle=PTO;g.lineWidth=2.2;g.stroke();
 if(o.acc){g.beginPath();g.ellipse(-1,-8,13,4,-.15,Math.PI*1.02,Math.PI*1.98);g.strokeStyle=PTO;g.lineWidth=5;g.stroke();g.strokeStyle='#ffd45a';g.lineWidth=3;g.stroke();pP(g,[-1,-15,2.6,-11.5,-1,-8,-4.6,-11.5]);pF(g,pLin(g,0,-15,0,-8,['#ffb0c0','#e0283a','#7a0a1a']),1.4);for(let i=0;i<3;i++){const v=(t*.6+i/3)%1;g.globalAlpha=(1-v);pStar4(g,-10+i*9+Math.sin(t*2+i)*3,-18-v*26,2.4,'#ffd45a');g.globalAlpha=1}}
 g.restore();g.restore();
 /* Cinder Sweep: a crescent of fire swept forward */
 if(ab&&u>.42&&u<.9){const v=pSeg(u,.42,.9);g.save();g.translate(40+v*60,-40);g.globalAlpha=1-v;g.globalCompositeOperation='lighter';g.beginPath();g.arc(0,0,40+v*30,-1.2,1.2);g.lineWidth=16*(1-v)+4;g.strokeStyle='#ff8a2a';g.stroke();g.lineWidth=6;g.strokeStyle='#fff2a0';g.stroke();g.restore()}};

/* GLOOMBAT: friendly cave bat with segmented wings; hovers below shoulder height */
PRIG.gloom=(g,o,C)=>{const t=o.t,P=o.pose,u=o.u,walk=P==='walk',ab=P==='ability',gr=P==='greet';
 const hov=-62+Math.sin(t*2.2)*4;const cyc=walk?(t*5)%1:(t*1.1)%1.6;/* glides between flaps */
 let fl=walk?Math.sin(t*12)*.7:(cyc<.5?Math.sin(cyc/.5*TAU)*.6:.12);if(ab)fl=-.6*pSeg(u,0,.3)*(1-pSeg(u,.8,1));if(gr)fl=u<.4?.9-pSeg(u,0,.4)*.2:-.7*Math.sin(pSeg(u,.4,.8)*Math.PI);
 g.save();g.translate(0,hov);g.rotate(walk?.12:0);
 const wing=(s,far)=>{g.save();g.translate(s*8,-3);g.scale(s,1);g.rotate(-fl*(far?.85:1));
  const ec=o.trim;pP(g,[0,-4,26,-30,48,-34,54,-24,50,-8,40,-10,34,4,22,0,12,10]);pF(g,ec?pLin(g,0,-34,40,10,['#4a3a9a','#241a5a','#0e0a2a']):pLin(g,0,-34,40,10,[far?C.wd:C.wl,far?C.wd:C.w,C.wd]),2.6);
  if(ec){/* the membranes hold a night sky */g.save();pP(g,[0,-4,26,-30,48,-34,54,-24,50,-8,40,-10,34,4,22,0,12,10]);g.clip();pGlow(g,30,-18,22,'#a86aff',.35);pGlow(g,18,-4,14,'#5ad8ff',.25);
   for(const [x,y,r] of[[14,-12,1.6],[26,-22,2.2],[38,-26,1.4],[44,-18,2],[32,-8,1.4],[20,-2,1.2],[48,-28,1.2]]){const tw=.6+.4*Math.sin(t*3+x);pStar4(g,x,y,r*1.6*tw+.4,'#ffffff')}g.restore();g.beginPath();g.moveTo(0,-4);g.lineTo(26,-30);g.lineTo(48,-34);g.lineTo(54,-24);g.strokeStyle='#e0d0ff';g.lineWidth=1.4;g.stroke()}
  g.strokeStyle=ec?'#6a5ac8':C.wd;g.lineWidth=1.6;g.beginPath();g.moveTo(4,-6);g.lineTo(48,-32);g.moveTo(26,-30);g.lineTo(40,-10);g.moveTo(26,-30);g.lineTo(22,0);g.stroke();
  if(o.trim){pP(g,[0,-4,26,-30,48,-34,54,-24]);pTrim(g,1.6)}g.restore()};
 if(o.trim){/* an eclipse rises behind it */const pu=.7+.3*Math.sin(t*1.8);g.save();g.translate(0,-10);pGlow(g,0,0,40,'#ffe6b0',.35*pu);g.globalCompositeOperation='lighter';g.beginPath();g.arc(0,0,23,0,TAU);g.strokeStyle=`rgba(255,236,190,${.8*pu})`;g.lineWidth=3;g.stroke();
  for(let i=0;i<12;i++){const a=i*TAU/12+t*.3;g.beginPath();g.moveTo(Math.cos(a)*24,Math.sin(a)*24);g.lineTo(Math.cos(a)*(29+(i%2)*5),Math.sin(a)*(29+(i%2)*5));g.strokeStyle=`rgba(255,220,160,${.5*pu})`;g.lineWidth=1.6;g.stroke()}g.restore();pC(g,0,-10,22);g.fillStyle='#0c0820';g.fill()}
 wing(-1,1);wing(1,0);
 /* body */pE(g,0,0,17,16);pF(g,pRad(g,0,0,18,[C.bl,C.b,C.bd]));
 g.beginPath();g.arc(2,6,5,-1.2,1.9);g.lineTo(0,4);g.closePath();g.fillStyle=C.cr;g.fill();
 /* ears */for(const [x,a] of[[-9,-.3],[8,.25]]){g.save();g.translate(x,-12);g.rotate(a+((t%2.8)<.2&&x>0?.25:0));pP(g,[-6,2,0,-18,6,2]);pF(g,C.b,2.4);pP(g,[-3,0,0,-12,3,0]);g.fillStyle=C.ie;g.fill();g.restore()}
 /* face */const e=ab&&u>.3&&u<.7?0:pBlink(t,7);pEye(g,-5,-3,5.6,C.ey,e,gr&&u>.6);pEye(g,7,-3,5.6,C.ey,e,gr&&u>.6);
 g.beginPath();g.moveTo(-3,6);g.quadraticCurveTo(1,9,5,6);g.strokeStyle=PTO;g.lineWidth=1.6;g.stroke();for(const x of[-2,4]){pP(g,[x-1.6,6.5,x+1.6,6.5,x,11]);pF(g,'#fff6e8',1)}
 for(const x of[-4,4]){g.beginPath();g.moveTo(x,15);g.lineTo(x,19);g.strokeStyle=PTO;g.lineWidth=3;g.stroke()}
 if(o.acc){g.beginPath();g.moveTo(-13,3);g.quadraticCurveTo(0,14,13,3);g.strokeStyle='#e8ecff';g.lineWidth=1.8;g.stroke();const sw=Math.sin(t*2.2)*.15;g.save();g.translate(0,10);g.rotate(sw);g.scale(1.5,1.5);pGlow(g,0,5,10,'#fff2c0',.6);g.beginPath();g.arc(0,5,5,.5,Math.PI*1.75);g.arc(2,4,4,Math.PI*1.75,.5,true);g.closePath();pF(g,pLin(g,0,0,0,10,['#fff6d0','#ffd45a']),1.2);g.restore()}
 g.restore();
 /* Echo Veil: three sonar arcs roll forward */
 if(ab){for(let i=0;i<3;i++){const v=pSeg(u,.3+i*.1,.75+i*.1);if(v<=0||v>=1)continue;g.save();g.translate(20+v*90,hov);g.globalCompositeOperation='lighter';g.globalAlpha=1-v;g.beginPath();g.arc(0,0,14+v*30,-.9,.9);g.lineWidth=7;g.strokeStyle='#b07aff';g.stroke();g.lineWidth=2.4;g.strokeStyle='#e8d0ff';g.stroke();g.restore()}}};

/* WICKWISP: mint spirit in an open brass lantern; the lantern swings with its motion */
PRIG.wisp=(g,o,C)=>{const t=o.t,P=o.pose,u=o.u,walk=P==='walk',ab=P==='ability',gr=P==='greet';
 const sw=(walk?.22:0)+Math.sin(t*1.6)*.08+(gr?Math.sin(u*Math.PI*3)*.2*(1-u):0),hov=-12+Math.sin(t*2)*3;
 const lit=.55+.2*Math.sin(t*3)+(gr?pSeg(u,.2,.5)*(1-pSeg(u,.8,1))*.8:0)+(ab?pSeg(u,.2,.4)*(1-pSeg(u,.8,1)):0);
 g.save();g.translate(0,hov);g.translate(0,-96);g.rotate(sw);g.translate(0,96);
 /* ribbon tail below */g.beginPath();g.moveTo(-6,-44);g.bezierCurveTo(-10,-30,10+Math.sin(t*3)*6,-28,4+Math.sin(t*3+1)*8,-14);g.bezierCurveTo(10,-24,6,-34,6,-44);g.closePath();pF(g,pLin(g,0,-44,0,-14,[C.sp,C.spd+'cc']),2);
 pGlow(g,0,-68,46,C.sp,.35*lit);
 if(o.trim){/* coloured light falls from the stained glass */g.save();g.globalCompositeOperation='lighter';const SG=['#ff6a9a','#ffc84a','#5ae8c8','#9a7aff'];SG.forEach((c,i)=>{const a=-.9+i*.6+Math.sin(t*.8)*.05;g.save();g.translate(0,-68);g.rotate(a);const q=g.createLinearGradient(0,0,0,70);q.addColorStop(0,c+'55');q.addColorStop(1,c+'00');g.fillStyle=q;g.beginPath();g.moveTo(-6,0);g.lineTo(6,0);g.lineTo(16,70);g.lineTo(-16,70);g.closePath();g.fill();g.restore()});g.restore()}
 /* back bars */for(const x of[-10,10]){g.beginPath();g.moveTo(x*.6,-86);g.lineTo(x*.6,-50);g.strokeStyle=C.md;g.lineWidth=3;g.stroke()}
 /* spirit */const by=-68+Math.sin(t*2.6)*2;g.beginPath();g.moveTo(-12,by+12);g.bezierCurveTo(-14,by-4,-8,by-16,0,by-16);g.bezierCurveTo(10,by-16,14,by-4,12,by+12);g.quadraticCurveTo(0,by+20,-12,by+12);g.closePath();pF(g,pRad(g,0,by,18,[C.spl,C.sp,C.spd]),0);
 const e=pBlink(t,8),hap=(gr&&u>.35)||(ab&&u>.4&&u<.85);for(const x of[-5,5]){if(hap){g.beginPath();g.arc(x,by+1,3.2,Math.PI*1.1,Math.PI*1.9);g.strokeStyle='#1a5a4a';g.lineWidth=2.2;g.stroke()}else{pE(g,x,by-1,3,4.6*e);g.fillStyle='#ffffff';g.fill()}}
 if(ab){const s=pSeg(u,.25,.45)*(1-pSeg(u,.8,1));if(s>0){pGlow(g,0,by,30,'#ff8aa8',.4*s);g.save();g.globalAlpha=s;pHeart(g,0,by+2,7*s+.1,'#ff8aa8',1.6);g.restore()}}
 /* frame: base, cage bars, cap and handle */
 g.beginPath();g.moveTo(-18,-50);g.lineTo(18,-50);g.lineTo(10,-42);g.lineTo(-10,-42);g.closePath();pF(g,pLin(g,0,-50,0,-42,[C.ml,C.m,C.md]),2.4);
 if(o.trim){/* stained-glass panes in the frame */const SG=[['#ff6a9a','#ffc84a'],['#5ae8c8','#9a7aff']];for(const [s,cs] of[[-1,SG[0]],[1,SG[1]]]){for(let k=0;k<2;k++){const y0=-86+k*18,y1=y0+18;g.beginPath();g.moveTo(s*17,y1);g.lineTo(s*16.2,y0);g.lineTo(s*9,y0);g.lineTo(s*10,y1);g.closePath();g.save();g.globalAlpha=.42+.12*Math.sin(t*2+k+s);g.fillStyle=cs[k];g.fill();g.restore();g.strokeStyle=C.md;g.lineWidth=1.6;g.stroke()}
   g.beginPath();g.arc(s*13,-77,2.2,0,TAU);g.fillStyle='#ffffffaa';g.fill()}}
 for(const x of[-17,17]){g.beginPath();g.moveTo(x,-50);g.lineTo(x*.95,-86);g.strokeStyle=PTO;g.lineWidth=5;g.stroke();g.strokeStyle=C.m;g.lineWidth=2.8;g.stroke()}
 g.beginPath();g.roundRect(-20,-90,40,6,3);pF(g,C.m,2.2);g.beginPath();g.moveTo(-17,-90);g.quadraticCurveTo(0,-110,17,-90);g.closePath();pF(g,pLin(g,0,-106,0,-90,[C.ml,C.m,C.md]),2.4);
 g.beginPath();g.arc(0,-112,6,0,TAU);g.strokeStyle=PTO;g.lineWidth=5;g.stroke();g.strokeStyle=C.m;g.lineWidth=2.6;g.stroke();
 if(o.trim){/* a jewel on the cap */pGlow(g,0,-98,10,'#ff6a9a',.5);pP(g,[0,-103,4,-98,0,-93,-4,-98]);pF(g,pLin(g,0,-103,0,-93,['#ffd0e0','#ff4a8a','#8a1a4a']),1.4)}
 if(o.acc){const w2=Math.sin(t*2.6)*3;for(const s of[-1,1]){g.beginPath();g.moveTo(0,-104);g.quadraticCurveTo(s*14,-112,s*12,-100);g.closePath();pF(g,'#ff7ab4',1.6);g.beginPath();g.moveTo(0,-103);g.quadraticCurveTo(s*6,-92,s*8+w2*.5,-82);g.lineTo(s*5+w2*.5,-82);g.quadraticCurveTo(s*3,-92,0,-102);g.closePath();pF(g,'#e2508a',1.2)}pC(g,0,-104,2.4);pF(g,'#ffd45a',1);pStar5(g,8+w2*.5,-78,4,'#ffd45a',1)}
 g.restore()};

/* NOCTURNE: ink-purple lynx with ear tufts, a crescent mark and a comet tail; pounces to bind */
PRIG.noct=(g,o,C)=>{const t=o.t,P=o.pose,u=o.u,walk=P==='walk',ab=P==='ability',gr=P==='greet';
 const crouch=ab?pSeg(u,0,.25)*(1-pSeg(u,.3,.4)):0,pounce=ab?Math.sin(pSeg(u,.3,.7)*Math.PI):0,bow=gr?Math.sin(pSeg(u,0,.7)*Math.PI):0;
 const tr=walk?t*6:0,leg=(ph)=>walk?Math.sin(tr+ph)*.4:0;
 g.save();g.translate(pounce*26,-pounce*18+crouch*6);g.rotate(-pounce*.12);
 /* comet tail */const ts=Math.sin(t*1.6)*.12;g.save();g.translate(-24,-38);g.rotate(ts);pGlow(g,-16,-30,46,C.tl,.4);
 g.beginPath();g.moveTo(0,0);g.bezierCurveTo(-30,-6,-46,-40,-24,-66);g.bezierCurveTo(-34,-40,-18,-22,6,-8);g.closePath();pF(g,pLin(g,-30,-60,0,0,[C.tl2,C.tl,C.b]),2.4);
 for(let i=0;i<(o.trim?9:4);i++){const a=t*1.5+i*1.7;pStar4(g,-26+Math.cos(a)*(o.trim?14:10),-40+Math.sin(a)*(o.trim?20:14),o.trim?2+Math.sin(t*3+i):2.4,'#ffffffcc')}
 if(o.trim){g.save();g.globalCompositeOperation='lighter';for(let i=0;i<6;i++){const v=(t*.5+i/6)%1;pGlow(g,-24-v*14,-66+v*10+i*2,4,'#e0b8ff',.8*(1-v))}g.restore()}g.restore();
 const L=(x,y,ph,c,fr)=>{g.save();g.translate(x,y+(fr?bow*8:0));g.rotate(leg(ph)+(fr?-bow*.5:0)-(fr?pounce*.6:pounce*-.4));pLimb(g,0,0,0,20,5,4,c);pE(g,1,21,5.4,3.4);pF(g,c,2);g.restore()};
 L(-16,-30,Math.PI,C.bd,0);L(16,-30,0,C.bd,1);
 g.save();g.rotate(bow*.18);pE(g,-2,-36,26,13);pF(g,pLin(g,0,-50,0,-22,[C.bl,C.b,C.bd]));
 if(o.trim){/* Nebula Coat: a slowly turning galaxy lives in its fur */g.save();pE(g,-2,-36,25,12);g.clip();g.fillStyle='#120a30';g.fillRect(-30,-50,56,30);g.globalCompositeOperation='lighter';
  for(const [x,y,r,c] of[[-12+Math.sin(t*.5)*4,-38,16,'#c84aff'],[6,-34+Math.cos(t*.4)*2,14,'#3ac8ff'],[-2,-40,10,'#ff7ab4']])pGlow(g,x,y,r,c,.55);
  for(let i=0;i<9;i++){const x=-24+((i*13.7+t*3)%48),y=-44+((i*7.3)%18);pStar4(g,x,y,1+(i%3)*.6+.5*Math.sin(t*3+i),'#ffffff')}g.restore()}
 pE(g,14,-34,10,10);g.fillStyle=C.ch;g.fill();
 if(o.acc){const SP=[[-20,-36],[-14,-43],[-6,-46],[2,-41],[-10,-35],[8,-37]];g.save();g.globalCompositeOperation='lighter';g.beginPath();g.moveTo(-20,-36);g.lineTo(-14,-43);g.lineTo(-6,-46);g.lineTo(2,-41);g.lineTo(8,-37);g.moveTo(-14,-43);g.lineTo(-10,-35);g.strokeStyle='#bcd8ff99';g.lineWidth=1.1;g.stroke();
  SP.forEach(([x,y],i)=>{const tw=.65+.35*Math.sin(t*3+i*1.7);pGlow(g,x,y,7,'#9ad0ff',.45*tw);pStar4(g,x,y,(i===2?3.6:2.6)*tw+.6,'#ffffff')});g.restore()}
 if(o.trim){g.beginPath();g.ellipse(-2,-36,26,13,0,Math.PI*1.08,Math.PI*1.92);pTrim(g,2.4)}g.restore();
 L(-20,-28,0,C.b,0);L(12,-28,Math.PI,C.b,1);
 /* head */g.save();g.translate(24,-52+bow*14);g.rotate(Math.sin(t*.7)*.05+bow*.2);
 const tw=(t%4.3)<.18?.3:0;for(const [x,s] of[[-9,-1],[6,1]]){g.save();g.translate(x,-8);g.rotate(s*.25+(s>0?tw:0));pP(g,[-7,2,0,-20,7,2]);pF(g,C.b,2.4);pP(g,[-3,0,0,-12,3,0]);g.fillStyle=C.ch;g.fill();g.beginPath();g.moveTo(0,-20);g.quadraticCurveTo(s*2,-28,s*-1,-32);g.strokeStyle=C.tf;g.lineWidth=2.6;g.stroke();g.restore()}
 pE(g,0,0,15,13);pF(g,C.b);for(const s of[-1,1]){pP(g,[s*12,2,s*19,6,s*13,9]);pF(g,C.b,2)}pE(g,4,6,8,5);g.fillStyle=C.ch;g.fill();
 /* crescent */g.beginPath();g.arc(0,-8,4.4,.6,Math.PI*1.7);g.arc(1.6,-9,3.4,Math.PI*1.7,.6,true);g.closePath();pF(g,C.cr,1.2);
 const nar=ab&&u<.35?1:0;for(const x of[-5,7]){if(gr&&u>.3&&u<.9){g.beginPath();g.arc(x,2,3.4,Math.PI*1.1,Math.PI*1.9);g.strokeStyle=PTO;g.lineWidth=2.2;g.stroke()}else{const e=pBlink(t,9);pE(g,x,1,4.2,(nar?2.4:4.6)*e);pF(g,C.ey,1.6);pE(g,x+.6,1,1.2,3.4*e);g.fillStyle='#120818';g.fill()}}
 g.beginPath();g.moveTo(4,6);g.lineTo(6,8);g.lineTo(8,6);g.strokeStyle=PTO;g.lineWidth=1.6;g.stroke();g.beginPath();for(const d of[-1,1.6]){g.moveTo(10,6+d);g.lineTo(21,4+d*2.2)}g.strokeStyle='#e8e0ff88';g.lineWidth=1;g.stroke();
 g.restore();
 /* gold collar and bell */g.beginPath();g.arc(20,-42+bow*12,10,.4,2.6);g.strokeStyle=PTO;g.lineWidth=5;g.stroke();g.strokeStyle=C.co;g.lineWidth=3;g.stroke();pC(g,20,-32+bow*12,3.6);pF(g,pLin(g,0,-36,0,-29,['#fff2a0',C.co,'#b8801a']),1.6);
 g.restore();
 if(ab&&u>.35){const v=pSeg(u,.35,.95);g.save();g.translate(70,-20);g.scale(1,.35);g.globalCompositeOperation='lighter';g.globalAlpha=1-v;for(let i=0;i<2;i++){g.beginPath();g.arc(0,0,20+v*50+i*12,0,TAU);g.lineWidth=5;g.strokeStyle=i?'#e0b8ff':'#a85aff';g.stroke()}g.restore();g.save();g.translate(70,-46-v*10);g.globalAlpha=1-v;g.beginPath();g.arc(0,0,10,.6,Math.PI*1.7);g.arc(3,-2,8,Math.PI*1.7,.6,true);g.closePath();pF(g,'#e8e0ff',1.6);g.restore()}};

/* PEBBLECRAB: lilac stone hermit crab with a geode shell, two blunt claws and four small legs */
PRIG.crab=(g,o,C)=>{const t=o.t,P=o.pose,u=o.u,walk=P==='walk',ab=P==='ability',gr=P==='greet';
 const sc=walk?Math.sin(t*12):0,click=!walk&&!ab&&!gr&&(t%4)<.6?Math.abs(Math.sin((t%4)/.6*Math.PI*3)):0;
 const raise=ab?pSeg(u,.05,.3)*(1-pSeg(u,.8,1)):0,both=gr?Math.sin(pSeg(u,0,.8)*Math.PI):0;
 g.save();g.translate(sc*1.2,-Math.abs(sc)*1.5);
 const leg=(x,ph,c)=>{const l=walk?Math.max(0,Math.sin(t*12+ph))*4:0;g.save();g.translate(x,-12);pP(g,[-2,-2,3,-2,(x>0?8:-8),10-l,(x>0?5:-6),12-l]);pF(g,c,2);g.restore()};
 leg(-18,0,C.bd);leg(-6,2,C.bd);
 /* geode shell mound */g.beginPath();g.moveTo(-34,-14);g.lineTo(-30,-38);g.lineTo(-14,-50);g.lineTo(6,-48);g.lineTo(18,-34);g.lineTo(20,-14);g.closePath();pF(g,pLin(g,0,-50,0,-14,[C.bl,C.b,C.bd]),3);
 g.strokeStyle=C.bd;g.lineWidth=1.6;g.beginPath();g.moveTo(-30,-38);g.lineTo(-12,-30);g.lineTo(6,-48);g.moveTo(-12,-30);g.lineTo(-14,-14);g.stroke();
 g.beginPath();g.moveTo(-6,-38);g.lineTo(-2,-32);g.lineTo(2,-38);g.lineTo(-2,-44);g.closePath();pF(g,C.ru,1.4);
 /* crystals */const gl=(t%2.6)/.4;
 const am=o.trim,cl=am?['#f4e0ff','#b47aff','#5a2aa8']:[C.crl,C.cr,C.crd];
 if(am){/* gold veins glow through the stone */g.save();g.globalCompositeOperation='lighter';g.beginPath();g.moveTo(-30,-38);g.lineTo(-12,-30);g.lineTo(6,-48);g.moveTo(-12,-30);g.lineTo(-14,-14);g.moveTo(-12,-30);g.lineTo(8,-24);g.lineTo(18,-30);g.moveTo(-22,-20);g.lineTo(-30,-26);g.strokeStyle=`rgba(255,212,90,${.7+.3*Math.sin(t*2)})`;g.lineWidth=2.2;g.stroke();g.restore();
  /* the spire: a tall amethyst with a beating heart of light */const pu=.6+.4*Math.sin(t*2.6);pGlow(g,-10,-80,34,'#c88aff',.45*pu);g.save();g.translate(-10,-46);pP(g,[-8,2,-8,-30,0,-44,8,-30,8,2]);pF(g,pLin(g,-8,0,8,0,['#ffffff','#c88aff','#4a1a98']),2.4);g.beginPath();g.moveTo(0,-44);g.lineTo(0,2);g.strokeStyle='#ffffff88';g.lineWidth=1.4;g.stroke();pGlow(g,0,-22,10,'#ffffff',.6*pu);g.restore()}
 for(const [x,y,h,a] of[[-26,-40,20,-.4],[-16,-48,28,-.1],[-4,-48,24,.15],[8,-44,18,.4],[-34,-28,14,-.8]]){g.save();g.translate(x,y);g.rotate(a);pP(g,[-5,2,-5,-h*.7,0,-h,5,-h*.7,5,2]);pF(g,pLin(g,-5,0,5,0,cl),2.2);g.beginPath();g.moveTo(0,-h);g.lineTo(0,2);g.strokeStyle='#ffffff66';g.lineWidth=1.2;g.stroke();g.restore()}
 if(gl<1)pStar4(g,-16+gl*4,-74,4,'#ffffffee');if(o.trim){g.beginPath();g.moveTo(-34,-14);g.lineTo(-30,-38);g.lineTo(-14,-50);g.lineTo(6,-48);g.lineTo(18,-34);g.lineTo(20,-14);pTrim(g,2)}
 if(o.acc){pGlow(g,-10,-70,26,'#ff9ad8',.4+.2*Math.sin(t*2));for(const [x,h,a] of[[-16,22,-.25],[-8,32,0],[0,24,.25]]){g.save();g.translate(x,-50);g.rotate(a);pP(g,[-4,2,-4,-h*.7,0,-h,4,-h*.7,4,2]);pF(g,pLin(g,-4,0,4,0,['#ffe0f4','#ff8ad8','#b04aa8']),2);g.restore()}g.beginPath();g.moveTo(-24,-24);g.lineTo(-20,-30);g.lineTo(-16,-24);g.lineTo(-20,-18);g.closePath();pF(g,'#ffd45a',1.4)}
 /* face hood */pE(g,18,-24,13,12);pF(g,C.hd,2.4);const e=pBlink(t,10);for(const x of[14,23]){pGlow(g,x,-24,9,C.ey,.5);if(gr&&u>.3&&u<.9){g.beginPath();g.arc(x,-22,2.8,Math.PI*1.1,Math.PI*1.9);g.strokeStyle=C.ey;g.lineWidth=2.2;g.stroke()}else{pE(g,x,-24,3,3.8*e);g.fillStyle=C.ey;g.fill()}}
 leg(8,1,C.b);leg(20,3,C.b);
 /* claws */const claw=(x,y,s,up,op)=>{g.save();g.translate(x,y);g.rotate(-up*1.4);g.scale(s,s);pLimb(g,0,0,10,-2,4,3.6,C.b);g.translate(14,-3);g.save();g.rotate(-op*.35);g.beginPath();g.moveTo(-4,0);g.quadraticCurveTo(2,-14,14,-6);g.quadraticCurveTo(8,-2,-4,0);g.closePath();pF(g,pLin(g,0,-14,0,0,[C.bl,C.b]),2.2);g.restore();
  g.beginPath();g.moveTo(-4,0);g.quadraticCurveTo(4,10,14,4);g.quadraticCurveTo(6,2,-4,0);g.closePath();pF(g,C.b,2.2);g.restore()};
 claw(24,-14,.8,both,click*.6);claw(26,-10,1,Math.max(raise,both),click);
 g.restore();
 /* Crystal Catch: a crystal plate forms in front */
 if(ab){const s=pSeg(u,.25,.45)*(1-pSeg(u,.8,1));if(s>0){g.save();g.translate(64,-40);g.scale(s,s);pGlow(g,0,0,40,'#5ad8ff',.5);pP(g,[0,-30,12,-10,8,24,-6,30,-10,0]);pF(g,'#9ff0ffcc',2.4,'#2a98d8');g.beginPath();g.moveTo(0,-30);g.lineTo(-2,20);g.strokeStyle='#ffffffaa';g.lineWidth=2;g.stroke();g.restore()}}};

/* QUILLFIN: a little fish in a water bubble with gold quill fins and a violet ink tail */
PRIG.quill=(g,o,C)=>{const t=o.t,P=o.pose,u=o.u,walk=P==='walk',ab=P==='ability',gr=P==='greet';
 const hov=-58+Math.sin(t*2.1)*4-(gr?Math.sin(pSeg(u,0,.6)*Math.PI*2)*6*(1-u):0),wob=Math.sin(t*3.2)*.04;
 g.save();g.translate(0,hov);
 /* ink tail out of the back */const tw=Math.sin(t*4)*6;g.beginPath();g.moveTo(-26,-4);g.bezierCurveTo(-40,-14+tw,-52,-4-tw,-58,8+tw);g.bezierCurveTo(-46,4,-40,10,-26,8);g.closePath();pF(g,pLin(g,-58,0,-26,0,[C.tl2,C.tl]),2.4);
 g.beginPath();g.moveTo(-26,2);g.bezierCurveTo(-38,10-tw,-46,22,-44,28-tw*.5);g.bezierCurveTo(-36,20,-30,14,-24,8);g.closePath();pF(g,C.tl,2.2);
 /* bubble back */g.save();g.scale(1+wob,1-wob);pC(g,0,0,32);g.fillStyle=C.bu+'2a';g.fill();
 if(o.trim){/* Ink Galaxy: the water becomes a swirling sky of ink and stars */pC(g,0,0,31);g.fillStyle=pRad(g,0,0,32,['#3a2a9a','#1a1460','#0a0a2ae6']);g.fill();g.save();pC(g,0,0,31);g.clip();g.globalCompositeOperation='lighter';
  for(let k=0;k<3;k++){g.beginPath();for(let i=0;i<=40;i++){const q=i/40,a=q*TAU*.9+t*.5+k*2.1,r=6+q*22;g.lineTo(Math.cos(a)*r,Math.sin(a)*r)}g.strokeStyle=['#c08aff66','#5ad8ff55','#ff8ad866'][k];g.lineWidth=3;g.stroke()}
  for(let i=0;i<10;i++){const a=i*2.4+t*.2,r=8+(i*5.3)%22;pStar4(g,Math.cos(a)*r,Math.sin(a)*r,1+(i%3)*.5+.4*Math.sin(t*3+i),'#ffffff')}g.restore()}
 g.restore();
 /* fish */g.save();g.rotate(Math.sin(t*1.4)*.06);
 for(let i=0;i<5;i++){const a=-2.5+i*.42+Math.sin(t*2.2+i)*.05;g.save();g.translate(-2,-2);g.rotate(a);g.translate(18,0);pP(g,[0,0,6,-5,14,0,6,5]);pF(g,pLin(g,0,-5,0,5,['#fff2a0',C.qf,C.qfd]),1.8);g.restore()}
 pE(g,0,0,20,17);pF(g,pRad(g,0,0,20,[C.bl,C.b,C.bd]));pE(g,9,2,11,11);pF(g,C.fp,0);
 pEye(g,10,0,7,'#2a1a3a',pBlink(t,11),gr&&u>.3&&u<.9);g.beginPath();g.moveTo(15,10);g.quadraticCurveTo(18,11,20,9);g.strokeStyle=PTO;g.lineWidth=1.6;g.stroke();
 if(o.acc){g.save();g.translate(4,-17);g.rotate(-.12);g.scale(1.3,1.3);g.beginPath();g.ellipse(0,0,13,3.4,0,0,TAU);pF(g,'#1a2448',1.6);g.beginPath();g.moveTo(-9,0);g.quadraticCurveTo(-9,-11,0,-12);g.quadraticCurveTo(9,-11,9,0);g.closePath();pF(g,'#f4f0e8',1.8);g.fillStyle='#1a2448';g.fillRect(-9,-3.4,18,3.4);pStar4(g,0,-7,2.6,'#ffd45a');g.restore()}
 g.restore();
 /* bubble rim and shine */g.save();g.scale(1+wob,1-wob);pC(g,0,0,32);g.strokeStyle=C.bu;g.lineWidth=3;g.stroke();g.strokeStyle=PTO+'66';g.lineWidth=1;g.stroke();
 g.beginPath();g.arc(0,0,26,-2.6,-1.6);g.strokeStyle='#ffffffcc';g.lineWidth=3.4;g.stroke();pC(g,14,-18,3);g.fillStyle='#ffffffcc';g.fill();
 if(o.trim){/* gold filigree rim */pC(g,0,0,33);g.strokeStyle='#ffd45a';g.lineWidth=2.4;g.stroke();for(let i=0;i<8;i++){const a=i*TAU/8+t*.15;g.save();g.translate(Math.cos(a)*33,Math.sin(a)*33);g.rotate(a);if(i%2){pP(g,[0,-3.4,3,0,0,3.4,-3,0]);pF(g,'#fff2a0',1.2)}else{g.beginPath();g.arc(0,0,3.4,Math.PI*.5,Math.PI*1.5);g.strokeStyle='#ffd45a';g.lineWidth=1.6;g.stroke()}g.restore()}}g.restore();
 /* tiny bubbles */for(let i=0;i<3;i++){const v=(t*.4+i/3)%1;g.globalAlpha=Math.sin(v*Math.PI);pC(g,16+i*6+Math.sin(t*2+i)*3,-30-v*30,2+i*.6);g.strokeStyle=C.bu;g.lineWidth=1.4;g.stroke();g.globalAlpha=1}
 if(o.acc){for(let i=0;i<3;i++){const a=t*1.2+i*2.1;pC(g,Math.cos(a)*40,Math.sin(a)*22,2.4);g.fillStyle='#ffffffaa';g.fill()}}
 /* Inkflow: a violet flourish curls around the bubble */
 if(ab){const v=pSeg(u,.1,.8),a0=-Math.PI*.8;g.save();g.globalCompositeOperation='lighter';g.globalAlpha=1-pSeg(u,.75,1);g.beginPath();for(let i=0;i<=30;i++){const k=i/30;if(k>v)break;const a=a0+k*TAU*1.15,r=42+k*8;g.lineTo(Math.cos(a)*r,Math.sin(a)*r*.7)}g.lineWidth=6;g.strokeStyle=C.tl;g.stroke();g.lineWidth=2;g.strokeStyle='#fff';g.stroke();g.restore()}
 g.restore()};

/* STARCOIL: miniature skywyrm; a living S-curve with a star at its tail, coils for Astral Reservoir */
PRIG.starcoil=(g,o,C)=>{const t=o.t,P=o.pose,u=o.u,walk=P==='walk',ab=P==='ability',gr=P==='greet';
 const coil=ab?pSeg(u,0,.35)*(1-pSeg(u,.75,1)):gr?(1-pSeg(u,.1,.6))*.6:0,stretch=walk?1:0;
 const N=26,pts=[];for(let i=0;i<=N;i++){const s=i/N;
  let x=22-62*s+(1-stretch)*Math.sin(s*Math.PI*2+t*2)*12,y=-104+66*s+Math.sin(s*Math.PI*2.2-t*2.4)*6+stretch*(-(1-s)*14);
  if(stretch){x=20-78*s;y=-72+Math.sin(s*Math.PI*2-t*6)*7+s*4}
  const a=-Math.PI/2+s*TAU*.92+t*.4,cx=Math.cos(a)*30,cy=-68+Math.sin(a)*30;x=x+(cx-x)*coil;y=y+(cy-y)*coil;pts.push([x,y])}
 const wid=s=>s<.08?9+s*50:(1-s)*13+3;
 const side=(k)=>{const L=[];for(let i=0;i<=N;i++){const p=pts[i],q=pts[Math.min(N,i+1)],r=pts[Math.max(0,i-1)],dx=q[0]-r[0],dy=q[1]-r[1],l=Math.hypot(dx,dy)||1,w=wid(i/N)*k;L.push([p[0]-dy/l*w,p[1]+dx/l*w])}return L};
 const A=side(1),B=side(-1);
 /* orbit ring, back half */const orb=(front)=>{g.save();g.translate(0,-70);g.rotate(-.35);g.scale(1,.32);g.beginPath();g.arc(0,0,44,front?0:Math.PI,front?Math.PI:TAU);g.strokeStyle='#c08aff'+(front?'cc':'66');g.lineWidth=3;g.stroke();const a=t*1.8;if((Math.sin(a)>0)===front){pC(g,Math.cos(a)*44,Math.sin(a)*44,5);g.fillStyle='#fff2c0';g.fill()}if(o.acc){const b=t*1.8+Math.PI;if((Math.sin(b)>0)===front){pC(g,Math.cos(b)*44,Math.sin(b)*44,4);g.fillStyle='#e0b8ff';g.fill()}}g.restore()};
 orb(false);
 /* back fin along the spine */for(let i=3;i<N-3;i+=2){const p=pts[i],q=pts[i+1],a=Math.atan2(q[1]-p[1],q[0]-p[0]);g.save();g.translate(A[i][0],A[i][1]);g.rotate(a-Math.PI/2);const h=10+(1-i/N)*6+Math.sin(t*4+i)*1.5;pP(g,[-4,0,-1,-h,5,0]);pF(g,pLin(g,0,-h,0,0,[C.fn2,C.fn]),1.8);g.restore()}
 /* body */g.beginPath();g.moveTo(A[0][0],A[0][1]);for(const p of A)g.lineTo(p[0],p[1]);for(let i=B.length-1;i>=0;i--)g.lineTo(B[i][0],B[i][1]);g.closePath();pF(g,pLin(g,-40,-100,20,-40,[C.bl,C.b,C.bd]),3);
 g.beginPath();for(let i=1;i<N;i++){const p=pts[i],b=B[i];g.lineTo(p[0]*.4+b[0]*.6,p[1]*.4+b[1]*.6)}g.strokeStyle=C.be;g.lineWidth=4;g.stroke();
 if(o.acc&&!o.trim){for(let i=8;i<N;i+=4){pStar4(g,pts[i][0],pts[i][1]-2,2.6,'#fff2c0')}}
 if(o.trim){/* Constellation Scales: a star map traced down its whole body */g.save();g.beginPath();g.moveTo(A[0][0],A[0][1]);for(const p of A)g.lineTo(p[0],p[1]);for(let i=B.length-1;i>=0;i--)g.lineTo(B[i][0],B[i][1]);g.closePath();g.clip();g.fillStyle='#0a0a3066';g.fillRect(-90,-140,180,140);g.restore();
  g.save();g.globalCompositeOperation='lighter';const SP=[];for(let i=3;i<N-1;i+=3){const p=pts[i],a=A[i],k=(i%2?.35:-.25);SP.push([p[0]+(a[0]-p[0])*k,p[1]+(a[1]-p[1])*k])}
  g.beginPath();SP.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.strokeStyle='#bfe4ff88';g.lineWidth=1.2;g.stroke();
  SP.forEach((p,i)=>{const tw=.6+.4*Math.sin(t*3+i*1.3);pGlow(g,p[0],p[1],8,'#9ad8ff',.5*tw);pStar4(g,p[0],p[1],(i%3===0?3.6:2.4)*tw+.6,'#ffffff')});g.restore()}
 /* tail star */const tp=pts[N];pGlow(g,tp[0],tp[1],o.trim?32:20,'#ffd45a',o.trim?.7:.5);if(o.trim){g.save();g.translate(tp[0],tp[1]);g.rotate(-t*.5);g.globalCompositeOperation='lighter';for(let i=0;i<8;i++){g.rotate(TAU/8);g.beginPath();g.moveTo(0,0);g.lineTo(0,i%2?16:24);g.strokeStyle='#fff2c088';g.lineWidth=1.4;g.stroke()}g.restore()}g.save();g.translate(tp[0],tp[1]);g.rotate(t*.8);pStar5(g,0,0,9,pLin(g,0,-9,0,9,['#fff6c0',C.st,'#c88a1a']),2);g.restore();
 /* forelimbs */const fp=pts[4];for(const d of[-3,4]){g.save();g.translate(fp[0]+d,fp[1]+8);g.rotate(.4);pLimb(g,0,0,4,8,2.4,2,C.b);for(let k=-1;k<=1;k++){g.beginPath();g.moveTo(4+k*1.6,9);g.lineTo(5+k*2,12);g.strokeStyle=C.hn;g.lineWidth=1.6;g.stroke()}g.restore()}
 /* head */const h0=pts[0],h1=pts[2],ha=Math.atan2(h0[1]-h1[1],h0[0]-h1[0]);g.save();g.translate(h0[0],h0[1]);g.rotate(ha*.35-(gr?.2:0));g.scale(1.25,1.25);
 for(const [x,a] of[[-6,-.6],[0,-.25]]){g.save();g.translate(x,-8);g.rotate(a);pP(g,[-2.6,0,2.6,0,1,-14]);pF(g,pLin(g,0,-14,0,0,['#fff6c0',C.hn,C.hnd]),1.8);g.restore()}
 g.beginPath();g.moveTo(-10,-6);g.quadraticCurveTo(-2,-12,10,-4);g.quadraticCurveTo(18,-2,18,3);g.quadraticCurveTo(8,8,-8,6);g.closePath();pF(g,pLin(g,0,-12,0,8,[C.bl,C.b,C.bd]),2.6);
 g.beginPath();g.moveTo(-6,5);g.quadraticCurveTo(6,6,16,3);g.strokeStyle=C.be;g.lineWidth=2;g.stroke();pC(g,15,0,1);g.fillStyle=PTO;g.fill();
 pEye(g,2,-3,4.4,C.ey,ab&&u>.3&&u<.75?0:pBlink(t,12),gr&&u>.5);
 if(o.acc){g.beginPath();g.moveTo(-6,-8);for(let i=1;i<=7;i++)g.lineTo(-6-i*8,-10+Math.sin(t*3-i*.8)*5+i*1.4);for(let i=7;i>=1;i--)g.lineTo(-6-i*8,-3+Math.sin(t*3-i*.8)*5+i*1.4-i*.4);g.closePath();pF(g,pLin(g,-62,0,-6,0,['#ffc8f0','#c08aff','#ff7ab4']),1.4);pStar4(g,-6,-8,3,'#fff2c0')}
 /* whisker barbels */g.beginPath();g.moveTo(14,2);g.quadraticCurveTo(22,8+Math.sin(t*2.4)*2,28,4+Math.sin(t*2.4+1)*3);g.moveTo(12,4);g.quadraticCurveTo(18,12+Math.sin(t*2.1)*2,22,12);g.strokeStyle=C.hn;g.lineWidth=1.4;g.stroke();
 g.restore();
 orb(true);
 if(ab&&u>.3){const v=pSeg(u,.3,.75);pGlow(g,0,-68,50,'#c08aff',.5*(1-pSeg(u,.75,1)));for(let i=0;i<6;i++){const a=t*3+i*TAU/6;pStar4(g,Math.cos(a)*40*v,-68+Math.sin(a)*40*v,3.4,'#fff2c0')}}};

/* LILYHOP (new): a pond frog wearing a lily pad; catches fireflies, keeps calm when you slip */
PRIG.lily=(g,o,C)=>{const t=o.t,P=o.pose,u=o.u,walk=P==='walk',ab=P==='ability',gr=P==='greet';
 let hy=0,sq=1;if(walk){const c=(t*1.4)%1;hy=-Math.sin(Math.min(1,c/.6)*Math.PI)*16*(c<.6?1:0);sq=c>.6&&c<.7?.9:1}
 if(gr){const v=pSeg(u,.1,.6);hy=-Math.sin(v*Math.PI)*26;sq=u<.12?1-u:1}
 const puff=Math.max(0,Math.sin(t*2.6))*(walk?0:1),tongue=!walk&&!ab&&!gr?((t%7.5)>6.6&&(t%7.5)<7.1?Math.sin(((t%7.5)-6.6)/.5*Math.PI):0):0;
 if(o.trim){/* a moonlit pool under its feet */g.save();g.scale(1,.26);pGlow(g,0,0,56,'#9ad8ff',.35);for(let i=0;i<3;i++){const k=((t*.35+i/3)%1);g.beginPath();g.arc(0,0,24+k*40,0,TAU);g.strokeStyle=`rgba(200,236,255,${(1-k)*.6})`;g.lineWidth=3;g.stroke()}g.restore()}
 /* the firefly it is watching */if(!walk&&!ab){const fx=40+Math.sin(t*.9)*8,fy=-58+Math.sin(t*1.7)*6;if(!(tongue>.6)){pGlow(g,fx,fy,10,'#d8ff7a',.6);pC(g,fx,fy,1.6);g.fillStyle='#f6ffc0';g.fill()}}
 g.save();g.translate(0,hy);g.scale(1,sq);
 /* folded back leg */pE(g,-14,-14,15,11,-.3);pF(g,pLin(g,0,-24,0,-4,[C.b,C.bd]));pE(g,-6,-3,14,4);pF(g,C.bd);
 /* body */g.beginPath();g.moveTo(-22,-12);g.bezierCurveTo(-24,-44,-6,-54,8,-50);g.bezierCurveTo(26,-46,30,-24,22,-8);g.quadraticCurveTo(0,0,-22,-12);g.closePath();pF(g,pLin(g,0,-54,0,-4,[C.bl,C.b,C.bd]),3);
 pE(g,8,-18+0,14,12+puff*2);pF(g,C.be,2);if(o.trim){g.beginPath();g.moveTo(-22,-12);g.bezierCurveTo(-24,-44,-6,-54,8,-50);g.bezierCurveTo(26,-46,30,-24,22,-8);pTrim(g,2)}
  /* glossy skin highlights */for(const [x,y,r] of[[-8,-46,2.4],[-14,-36,1.4],[12,-44,1.2]]){pC(g,x,y,r);g.fillStyle='#ffffffaa';g.fill()}
 if(o.trim){/* moon-silver markings */g.save();g.globalCompositeOperation='lighter';for(const [x,y,r] of[[-14,-28,3.4],[-8,-38,2.6],[-18,-18,2.2],[16,-30,1.8]]){pGlow(g,x,y,r*2.4,'#bfe0ff',.45);pC(g,x,y,r*.7);g.fillStyle='#e8f4ff';g.fill()}g.restore()}
 if(o.acc){for(let i=0;i<7;i++){const a=.3+i*.36,x=6+Math.cos(a)*16,y=-28+Math.sin(a)*6;pC(g,x,y,2.6);pF(g,pRad(g,x,y,2.6,['#ffffff','#d8f4ff','#8ab8d8']),1)}pGlow(g,10,-24,10,'#bff6ff',.4)}
 /* spots */for(const [x,y,r] of[[-12,-30,3],[-6,-40,2.4],[-16,-20,2]]){pC(g,x,y,r);g.fillStyle=C.bd;g.globalAlpha=.6;g.fill();g.globalAlpha=1}
 /* front leg */pLimb(g,14,-12,18,-1,3.6,3.2,C.b);for(let i=-1;i<=1;i++){pE(g,18+i*3.4,0,2.4,1.8);g.fillStyle=C.b;g.fill()}
 /* eyes on top */const e=pBlink(t,13),hap=(gr&&u>.2)||(ab&&u>.2&&u<.85);for(const [x,y] of[[-4,-50],[14,-50]]){pC(g,x,y,9.4);pF(g,C.b,2.6);pEye(g,x+1,y-1,6.4,C.ey,e,hap,1)}
 pE(g,-6,-38,4,2.4);g.fillStyle=C.ck;g.globalAlpha=.7;g.fill();pE(g,22,-36,4,2.4);g.fill();g.globalAlpha=1;
 g.beginPath();g.moveTo(4,-34);g.quadraticCurveTo(14,-28,24,-36);g.strokeStyle=PTO;g.lineWidth=2;g.stroke();
 if(tongue>0){g.beginPath();g.moveTo(16,-33);g.quadraticCurveTo(26+tongue*10,-48*tongue-30,24+tongue*20,-30-tongue*28);g.strokeStyle='#ff6a8a';g.lineWidth=3;g.stroke()}
 /* lily pad hat with a lotus */g.save();g.translate(4,-60);g.rotate(-.18+Math.sin(t*1.5)*.04);g.beginPath();g.ellipse(0,0,20,6.4,0,.25,TAU-.05);g.lineTo(0,0);g.closePath();pF(g,pLin(g,0,-6,0,6,[C.pd,C.pdd]),2.2);
 g.beginPath();for(let i=0;i<5;i++){g.moveTo(0,0);const a=.6+i*1.1;g.lineTo(Math.cos(a)*16,Math.sin(a)*5)}g.strokeStyle='#ffffff40';g.lineWidth=1;g.stroke();
 if(o.trim){/* Moonlit Lotus: a great white lotus with a pearl of moonlight */pGlow(g,-6,-8,26,'#d8e8ff',.55);for(let i=0;i<7;i++){g.save();g.translate(-6,-1);g.rotate(-1.5+i*.5);pE(g,0,-9,4.6,10);pF(g,pLin(g,0,-19,0,0,['#ffffff','#e0d8ff','#a89aff']),1.6);g.restore()}
  for(let i=0;i<5;i++){g.save();g.translate(-6,-2);g.rotate(-1.2+i*.6);pE(g,0,-7,3.4,8);pF(g,pLin(g,0,-15,0,0,['#ffffff','#f4f0ff']),1.4);g.restore()}const pp=.7+.3*Math.sin(t*2.4);pGlow(g,-6,-6,12,'#ffffff',.7*pp);pC(g,-6,-6,3.6);pF(g,pRad(g,-7,-7,3.6,['#ffffff','#dff0ff','#9ab8e8']),1.2)}
 else{for(let i=0;i<5;i++){g.save();g.translate(-6,-2);g.rotate(-1.2+i*.6);pE(g,0,-6,3.4,7);pF(g,pLin(g,0,-13,0,0,[C.lol,C.lo]),1.6);g.restore()}pC(g,-6,-3,2.4);pF(g,'#ffd45a',1.2)}
 if(o.acc){for(const x of[-14,10]){pE(g,x,-1,1.8,2.4);g.fillStyle='#bff6ff';g.fill()}}g.restore();
 g.restore();
 /* Calm Pond: ripples at its feet */
 if(ab||o.ripple){const v=ab?pSeg(u,.1,.9):o.ripple;g.save();g.scale(1,.3);for(let i=0;i<3;i++){const k=Math.max(0,Math.min(1,v*1.4-i*.2));if(k<=0||k>=1)continue;g.beginPath();g.arc(0,0,10+k*60,0,TAU);g.strokeStyle='#9ff0ff';g.globalAlpha=(1-k)*.8;g.lineWidth=4;g.stroke()}g.restore();g.globalAlpha=1}};

/* TICKPIP (new): a brass clockwork owl; its key winds, its clock ticks, and it chimes to slow a boss's clock */
PRIG.tick=(g,o,C)=>{const t=o.t,P=o.pose,u=o.u,walk=P==='walk',ab=P==='ability',gr=P==='greet';
 const hop=walk?-Math.abs(Math.sin(t*6))*8:gr?-Math.sin(pSeg(u,0,.4)*Math.PI)*12:0,flap=ab?Math.sin(u*Math.PI*8)*(1-pSeg(u,.6,1)):gr?Math.sin(u*Math.PI*6)*(1-u):walk?Math.sin(t*12)*.3:0;
 const swiv=Math.sin(t*.8)*.08+(((t%6)<.5)?Math.sin((t%6)/.5*Math.PI)*.2:0);
 g.save();g.translate(0,hop);
 /* Grand Orrery: brass rings with little planets circle the owl (back halves first) */
 const orr=(front)=>{if(!o.trim)return;for(const [r,tl,sp,pc,ps] of[[40,-.32,.9,'#7ad8ff',4.2],[50,.22,-.6,'#ff9a6a',3.4]]){g.save();g.translate(0,-40);g.rotate(tl);g.scale(1,.3);g.beginPath();g.arc(0,0,r,front?0:Math.PI,front?Math.PI:TAU);g.strokeStyle=PTO;g.lineWidth=5;g.stroke();g.strokeStyle=front?'#ffd45a':'#c8963a';g.lineWidth=2.6;g.stroke();
  const a=t*sp+r;if((Math.sin(a)>0)===front){g.scale(1,1/.3);const px=Math.cos(a)*r,py=Math.sin(a)*r*.3;pGlow(g,px,py,ps*3,pc,.5);pC(g,px,py,ps);pF(g,pRad(g,px-1,py-1,ps,['#ffffff',pc,'#2a2050']),1.4)}g.restore()}};
 orr(false);
 /* feet */for(const x of[-8,8]){g.beginPath();g.moveTo(x,-10);g.lineTo(x,-2);for(const d of[-3,0,3]){g.moveTo(x,-3);g.lineTo(x+d,1)}g.strokeStyle=PTO;g.lineWidth=4.4;g.stroke();g.strokeStyle=C.cu;g.lineWidth=2.2;g.stroke()}
 /* wind-up key behind, spinning */g.save();g.translate(-24,-50);g.rotate(t*(ab?9:1.2));g.scale(Math.cos(t*(ab?9:1.2))*.4+.6,1);for(const s of[-1,1]){pE(g,s*9,0,7,5);pF(g,C.m,2.2);pE(g,s*9,0,3,2);g.fillStyle=C.md;g.fill()}g.restore();g.beginPath();g.moveTo(-22,-50);g.lineTo(-14,-46);g.strokeStyle=PTO;g.lineWidth=5;g.stroke();g.strokeStyle=C.md;g.lineWidth=2.6;g.stroke();
 /* gear wings */const gear=(x,s)=>{g.save();g.translate(x,-36);g.rotate(s*(.3+flap*.7));g.translate(s*4,6);g.rotate(t*.4*s);g.beginPath();for(let i=0;i<24;i++){const a=i*TAU/24,r=i%2?12:15.4;g.lineTo(Math.cos(a)*r,Math.sin(a)*r)}g.closePath();pF(g,pLin(g,0,-15,0,15,[C.ml,C.m,C.md]),2.2);pC(g,0,0,7.6);pF(g,C.cu,1.8);for(let i=0;i<4;i++){g.beginPath();g.moveTo(0,0);g.lineTo(Math.cos(i*1.57)*7.6,Math.sin(i*1.57)*7.6);g.strokeStyle=C.cud;g.lineWidth=1.6;g.stroke()}g.restore()};
 gear(-22,-1);
 /* body */g.beginPath();g.moveTo(-20,-12);g.bezierCurveTo(-28,-48,-14,-70,0,-70);g.bezierCurveTo(14,-70,28,-48,20,-12);g.quadraticCurveTo(0,-4,-20,-12);g.closePath();pF(g,pLin(g,0,-70,0,-6,[C.ml,C.m,C.md]),3);
 if(o.trim){g.beginPath();g.moveTo(-20,-12);g.bezierCurveTo(-28,-48,-14,-70,0,-70);g.bezierCurveTo(14,-70,28,-48,20,-12);pTrim(g,2)}
 for(const [x,y] of[[-16,-20],[16,-20],[-18,-40],[18,-40]]){pC(g,x,y,1.8);g.fillStyle=C.md;g.fill()}
 /* clock face with ticking hands (a star chart for the orrery) */const sc=o.trim;pC(g,1,-26,12.6);pF(g,sc?pRad(g,1,-26,13,['#3a4aa8','#1a1e5a','#0c0c2a']):C.fc,2.4);
 if(sc){for(const [x,y] of[[-4,-30],[4,-32],[7,-24],[-5,-21],[0,-28]]){pStar4(g,1+x,y,1.6+Math.sin(t*3+x)*.6,'#fff6c0')}g.beginPath();g.moveTo(-3,-30);g.lineTo(5,-32);g.lineTo(8,-24);g.strokeStyle='#fff6c055';g.lineWidth=.8;g.stroke()}
 for(let i=0;i<12;i++){const a=i*Math.PI/6;g.beginPath();g.moveTo(1+Math.cos(a)*9,-26+Math.sin(a)*9);g.lineTo(1+Math.cos(a)*11,-26+Math.sin(a)*11);g.strokeStyle=sc?'#ffd45a':C.hn;g.lineWidth=i%3?1:2;g.stroke()}
 const sec=ab?u*TAU*6:Math.floor(t)*TAU/12,mn=ab?u*TAU*1.5:t*.05;g.strokeStyle=sc?'#ffd45a':C.hn;g.lineCap='round';g.lineWidth=2.2;g.beginPath();g.moveTo(1,-26);g.lineTo(1+Math.cos(mn-Math.PI/2)*6,-26+Math.sin(mn-Math.PI/2)*6);g.stroke();g.lineWidth=1.4;g.strokeStyle='#c83a2a';g.beginPath();g.moveTo(1,-26);g.lineTo(1+Math.cos(sec-Math.PI/2)*9.4,-26+Math.sin(sec-Math.PI/2)*9.4);g.stroke();pC(g,1,-26,1.6);g.fillStyle=C.hn;g.fill();
 /* head: ear tufts, lens eyes, beak */g.save();g.translate(0,-52);g.rotate(swiv);
 for(const s of[-1,1]){pP(g,[s*6,-14,s*16,-24,s*14,-10]);pF(g,C.m,2.2)}
 const hap=(gr&&u>.3&&u<.9),shut=pBlink(t,14);for(const [x,r] of[[-8,9.4],[9,9.4]]){pC(g,x,0,r);pF(g,pLin(g,0,-r,0,r,[C.ml,C.cu]),2.4);pC(g,x,0,r-3.4);pF(g,'#2a1a10',1.4);pGlow(g,x,0,12,C.ey,.35);
  if(hap){g.beginPath();g.arc(x,2,3.4,Math.PI*1.1,Math.PI*1.9);g.strokeStyle=C.ey;g.lineWidth=2.4;g.stroke()}else{pE(g,x,0,3.8,3.8*shut);g.fillStyle=C.ey;g.fill();pC(g,x+1.4,-1.4,1.1);g.fillStyle='#fff';g.fill()}
  for(let i=0;i<6;i++){const a=i*Math.PI/3;pC(g,x+Math.cos(a)*(r-1.6),Math.sin(a)*(r-1.6),.9);g.fillStyle=C.md;g.fill()}}
 pP(g,[-2,5,4,5,1,11]);pF(g,C.cu,1.6);
 /* Top hat: a dapper little stovepipe with a gold band and a tiny gear pin */
 if(o.acc){g.save();g.translate(1,-12);g.rotate(-.14+Math.sin(t*1.6)*.03);
  pE(g,0,0,17,4.6);pF(g,pLin(g,0,-4,0,5,['#5a4a70','#2a2036']),2.2);
  g.beginPath();g.moveTo(-10,0);g.lineTo(-11.5,-21);g.quadraticCurveTo(0,-24,11.5,-21);g.lineTo(10,0);g.quadraticCurveTo(0,2.4,-10,0);g.closePath();pF(g,pLin(g,-11,0,11,0,['#3a2e4c','#5c4c78','#2a2038']),2.2);
  g.beginPath();g.moveTo(-10.6,-6);g.quadraticCurveTo(0,-3.6,10.6,-6);g.lineTo(10.9,-10);g.quadraticCurveTo(0,-7.6,-10.9,-10);g.closePath();g.fillStyle=C.m;g.fill();g.strokeStyle=C.md;g.lineWidth=1;g.stroke();
  g.fillStyle='#ffffff2a';g.beginPath();g.moveTo(-7.5,-11);g.lineTo(-8.5,-20);g.lineTo(-6,-20.6);g.lineTo(-5.4,-11);g.fill();
  g.save();g.translate(6,-8);g.rotate(t*.8);g.beginPath();for(let i=0;i<12;i++){const a=i*TAU/12,r=i%2?2.6:3.6;g.lineTo(Math.cos(a)*r,Math.sin(a)*r)}g.closePath();g.fillStyle=C.ml;g.fill();g.strokeStyle=C.md;g.lineWidth=.8;g.stroke();g.restore();g.restore()}
 g.restore();
 gear(22,1);
 orr(true);
 g.restore();
 /* Second Hand: a ring of golden ticks expands */
 if(ab&&u>.2){const v=pSeg(u,.2,.9);g.save();g.translate(0,-40);g.globalCompositeOperation='lighter';g.globalAlpha=1-v;g.rotate(v*2);for(let i=0;i<12;i++){const a=i*Math.PI/6,r=24+v*50;g.beginPath();g.moveTo(Math.cos(a)*r,Math.sin(a)*r);g.lineTo(Math.cos(a)*(r+8),Math.sin(a)*(r+8));g.strokeStyle='#ffd45a';g.lineWidth=3;g.stroke()}g.beginPath();g.arc(0,0,24+v*50,0,TAU);g.lineWidth=1.6;g.stroke();g.restore()}};

/* PRISMKIT (new Legendary): a crystal fox whose faceted tail splits light into a rainbow */
PRIG.prism=(g,o,C)=>{const t=o.t,P=o.pose,u=o.u,walk=P==='walk',ab=P==='ability',gr=P==='greet';
 const fan=ab?pSeg(u,.1,.35)*(1-pSeg(u,.8,1)):gr?pSeg(u,.2,.5)*(1-pSeg(u,.85,1)):0,sit=gr?pSeg(u,0,.25)*(1-pSeg(u,.85,1)):0;
 const tr=walk?t*7:0,leg=(ph)=>walk?Math.sin(tr+ph)*.45:0;
 /* the faceted tail */const tw=Math.sin(t*1.5)*.1;g.save();g.translate(-24,-36+sit*8);g.rotate(tw-fan*.5);
 const cols=[C.c1,C.c2,C.c3,C.c4];const fanN=6;pGlow(g,-18,-30,40+fan*20,'#d0b0ff',.25+fan*.3);
 const RB=['#ff5a6a','#ffa03a','#fff05a','#5aff8a','#5ad0ff','#a87aff'];
 for(let i=0;i<fanN;i++){const a=-2.0+i*(.18+fan*.14),len=44+Math.sin(i*1.7)*6+fan*8;g.save();g.rotate(a);
  if(o.trim){/* Rainbow Facets: every crystal splits light into a spectrum */const sh=.55+.45*Math.sin(t*2.2+i*1.1);g.save();g.globalCompositeOperation='lighter';RB.forEach((c,k)=>{g.beginPath();g.moveTo(len-2,0);g.lineTo(len+20+sh*10,(k-2.5)*3.2);g.strokeStyle=c;g.globalAlpha=.75*sh;g.lineWidth=2;g.stroke()});g.restore()}
  pP(g,[0,-5,len*.55,-9,len,0,len*.55,9,0,5]);pF(g,o.trim?pLin(g,0,-9,0,9,['#ffffff',RB[(i*2)%6],RB[(i*2+2)%6]]):pLin(g,0,-9,0,9,['#ffffff',cols[i%4],cols[(i+1)%4]]),2.2);g.beginPath();g.moveTo(4,0);g.lineTo(len*.9,0);g.strokeStyle='#ffffff99';g.lineWidth=1.2;g.stroke();g.restore()}
 /* a glint runs across the facets */const gp=(t*.6)%2;if(gp<1){g.save();g.rotate(-2+gp*1.2);pStar4(g,34,0,5,'#ffffffee');g.restore()}
 g.restore();
 const L=(x,y,ph,c,fr)=>{g.save();g.translate(x,y);g.rotate(leg(ph)+(fr?0:-sit*.9));pLimb(g,0,0,0,20,4.8,3.6,c);pE(g,1,21,4.6,3);pF(g,c,2);g.restore()};
 L(-16,-28,Math.PI,C.bd,0);L(14,-28,0,C.bd,1);
 g.save();g.translate(0,sit*6);g.rotate(-sit*.3);pE(g,-2,-34,24,12);pF(g,pLin(g,0,-46,0,-22,[C.b,C.b,C.bd]));
 /* crystal patches */for(const [x,y,s] of[[-10,-40,6],[2,-42,5]]){pP(g,[x,y-s,x+s,y,x,y+s*.6,x-s,y]);pF(g,pLin(g,0,y-s,0,y+s,['#ffffff',C.c1,C.c2]),1.4)}
 if(o.trim){g.beginPath();g.ellipse(-2,-34,24,12,0,Math.PI*1.08,Math.PI*1.92);pTrim(g,2.4)}g.restore();
 L(-20,-26,0,C.b,0);L(10,-26,Math.PI,C.b,1);
 /* chest ruff of crystal */g.save();g.translate(16,-38+sit*2);for(let i=0;i<3;i++){pP(g,[-4+i*3,-6,2+i*3,6,-6+i*3,4]);pF(g,i%2?C.c2:C.c1,1.4)}g.restore();
 /* head */g.save();g.translate(22,-52+sit*-2);g.rotate(Math.sin(t*.7)*.05-sit*.15);
 const tw2=(t%3.9)<.18?.3:0;for(const [x,s] of[[-8,-1],[5,1]]){g.save();g.translate(x,-8);g.rotate(s*.2+(s>0?tw2:0));pP(g,[-7,2,0,-22,7,2]);pF(g,C.b,2.4);pP(g,[-3.6,0,0,-14,3.6,0]);g.fillStyle=C.ie;g.fill();g.restore()}
 pE(g,0,0,14,12);pF(g,C.b);g.beginPath();g.moveTo(8,-4);g.quadraticCurveTo(20,-2,22,4);g.quadraticCurveTo(14,8,6,6);g.closePath();pF(g,C.b,2.4);pC(g,21,3,2);g.fillStyle=PTO;g.fill();
 pEye(g,4,-1,5.2,C.ey,pBlink(t,15),gr&&u>.35&&u<.9);
 /* forehead star gem */const sg=.5+.5*Math.sin(t*2.6)+(ab?pSeg(u,.2,.4)*(1-pSeg(u,.7,.9)):0);pGlow(g,-2,-10,12+sg*6,'#fff6c0',.4+sg*.2);
 if(o.trim){/* a tiny prism: light enters white, leaves as a rainbow */pP(g,[-2,-16,3,-7,-7,-7]);pF(g,pLin(g,-7,-16,3,-7,['#ffffff','#e0f4ff','#c8b8ff']),1.4);g.save();g.globalCompositeOperation='lighter';['#ff5a6a','#fff05a','#5aff8a','#5ad0ff','#a87aff'].forEach((c,k)=>{g.beginPath();g.moveTo(1,-11);g.lineTo(9,-16+k*2.2);g.strokeStyle=c;g.lineWidth=1.2;g.stroke()});g.restore()}else pStar4(g,-2,-10,4.4,C.st);
 if(o.acc){g.beginPath();g.moveTo(-10,6);g.quadraticCurveTo(0,12,10,8);g.strokeStyle='#ff6aa8';g.lineWidth=3;g.stroke();pC(g,0,11,2.4);pF(g,'#ffd45a',1.2)}
 g.restore();
 /* Prism Sight: a rainbow arc beam leaps forward */
 if(ab&&u>.3){const v=pSeg(u,.3,.8),f=1-pSeg(u,.75,1);g.save();g.globalCompositeOperation='lighter';g.globalAlpha=f;const rc=['#ff6a6a','#ffb04a','#fff06a','#7aff8a','#6ad8ff','#b07aff'];rc.forEach((c,i)=>{g.beginPath();g.arc(70,-10,40-i*4,Math.PI*1.02,Math.PI*(1.02+.96*v));g.strokeStyle=c;g.lineWidth=4;g.stroke()});g.restore()}};

/* ---------- the companions' public draw ---------- */
/* the Bond 10 Signature: each companion has its own glow and its own drifting particles */
const PSIG={bramble:['#ffd27a','firefly'],mosskip:['#9affc8','petal'],antler:['#8ae8ff','star'],lily:['#bfe0ff','drop'],cinder:['#ff8a2a','ember'],beetle:['#ffd45a','coin'],ember:['#ff6a2a','flame'],tick:['#ffd45a','spark'],
 gloom:['#c8a8ff','star'],wisp:['#ff9ad0','glass'],noct:['#c84aff','dust'],crab:['#c88aff','shard'],quill:['#7ab8ff','ink'],starcoil:['#9ad8ff','comet'],prism:['#ffffff','rainbow']};
function petAura(g,id,t,front){const D=PDEF[id]||{},bx=D.box||[-60,-110,120,115],cx=bx[0]+bx[2]/2,cy=bx[1]+bx[3]*.55,R=Math.max(bx[2],bx[3])*.55,S=PSIG[id]||['#ffd45a','spark'],c=S[0],k=S[1],hv=D.hover;
 if(!front){pGlow(g,cx,cy,R*1.2,c,.16+.06*Math.sin(t*1.8));g.save();g.translate(cx*.3,hv?-6:2);g.scale(1,.26);pGlow(g,0,0,R*.9,c,.35);g.restore()}
 const N=7,RB=['#ff5a6a','#ffa03a','#fff05a','#5aff8a','#5ad0ff','#a87aff'],GL=['#ff6a9a','#ffc84a','#5ae8c8','#9a7aff'];
 for(let i=0;i<N;i++){const sd=i*1.618,v=((t*(.16+(i%3)*.04)+sd)%1+1)%1,lane=((i*.37+.11)%1);
  /* half the motes drift behind the companion, half in front */if((i%2===0)!==front)continue;
  let x=bx[0]-10+lane*(bx[2]+20),y=bx[1]+bx[3]-v*(bx[3]+20),a=Math.sin(v*Math.PI);x+=Math.sin(t*1.3+sd*3)*8;
  if(k==='drop'||k==='coin'||k==='shard'){y=bx[1]-10+v*(bx[3]+10)}
  if(a<.04)continue;g.save();g.globalAlpha=a;
  if(k==='firefly'){pGlow(g,x,y,9,'#ffe27a',.8);pC(g,x,y,1.8);g.fillStyle='#fff6c0';g.fill()}
  else if(k==='petal'){g.translate(x,y);g.rotate(t*2+sd);pGlow(g,0,0,8,'#bfffe0',.5);pE(g,0,0,4.4,2.2);g.fillStyle='#f0fff6';g.fill()}
  else if(k==='star'){pGlow(g,x,y,8,c,.6);pStar4(g,x,y,3+Math.sin(t*4+sd)*1.2,'#ffffff')}
  else if(k==='drop'){pGlow(g,x,y,7,'#bfe0ff',.6);g.beginPath();g.moveTo(x,y-4);g.quadraticCurveTo(x+3,y+1,x,y+3);g.quadraticCurveTo(x-3,y+1,x,y-4);g.fillStyle='#e8f6ff';g.fill()}
  else if(k==='ember'){pGlow(g,x,y,8,'#ff8a2a',.8);pC(g,x,y,1.8);g.fillStyle='#fff2a0';g.fill()}
  else if(k==='coin'){g.translate(x,y);g.scale(Math.max(.2,Math.abs(Math.cos(t*4+sd))),1);pC(g,0,0,3.6);pF(g,'#ffd45a',1.2,'#a8701a')}
  else if(k==='flame'){g.translate(x,y);pGlow(g,0,0,10,'#ff8a2a',.7);g.beginPath();g.moveTo(-2.6,2);g.quadraticCurveTo(-3,-3,0,-7);g.quadraticCurveTo(3,-3,2.6,2);g.closePath();g.fillStyle='#ffb03a';g.fill()}
  else if(k==='spark'){pGlow(g,x,y,7,'#ffd45a',.7);g.translate(x,y);g.rotate(t*2+sd);g.beginPath();for(let j=0;j<8;j++){const aa=j*TAU/8,r=j%2?1.6:3.2;g.lineTo(Math.cos(aa)*r,Math.sin(aa)*r)}g.closePath();g.fillStyle='#ffe48a';g.fill()}
  else if(k==='glass'){const col=GL[i%4];pGlow(g,x,y,9,col,.7);pP(g,[x,y-3,x+3,y,x,y+3,x-3,y]);g.fillStyle=col;g.fill()}
  else if(k==='dust'){pGlow(g,x,y,8,i%2?'#3ac8ff':'#c84aff',.6);pStar4(g,x,y,2.4,'#ffffff')}
  else if(k==='shard'){g.translate(x,y);g.rotate(t+sd);pGlow(g,0,0,9,'#c88aff',.5);pP(g,[0,-5,2.4,0,0,5,-2.4,0]);pF(g,'#e8d0ff',1,'#6a3ab8')}
  else if(k==='ink'){pGlow(g,x,y,8,'#7ab8ff',.5);pC(g,x,y,2.4);g.strokeStyle='#bfe0ff';g.lineWidth=1.2;g.stroke()}
  else if(k==='comet'){const tx=-10,ty=4;g.beginPath();g.moveTo(x,y);g.lineTo(x+tx,y+ty);g.strokeStyle='#bfe4ff88';g.lineWidth=2.4;g.stroke();pGlow(g,x,y,8,'#9ad8ff',.7);pC(g,x,y,1.8);g.fillStyle='#ffffff';g.fill()}
  else if(k==='rainbow'){const col=RB[i%6];pGlow(g,x,y,8,col,.7);pStar4(g,x,y,2.6,'#ffffff')}
  g.restore()}}
/* every companion is drawn into a small layer and lit: a warm key light from above and a soft shade below */
const PLIT=document.createElement('canvas');
function petDraw(g,id,o){if(o&&o.flat)return petDrawRaw(g,id,o);const D=PDEF[id];if(!D||!PRIG[id])return;let m;try{m=g.getTransform()}catch(e){return petDrawRaw(g,id,o)}
 const sc=Math.min(4,Math.hypot(m.a,m.b)||1),bx=D.box||[-60,-110,120,115],L=bx[0]-90,T=bx[1]-100,cw=Math.ceil((bx[2]+280)*sc),ch=Math.ceil((bx[3]+140)*sc);if(cw*ch>3.2e6||!cw||!ch)return petDrawRaw(g,id,o);
 if(PLIT.width<cw)PLIT.width=cw;if(PLIT.height<ch)PLIT.height=ch;const x=PLIT.getContext('2d');x.setTransform(1,0,0,1,0,0);x.globalCompositeOperation='source-over';x.globalAlpha=1;x.clearRect(0,0,cw,ch);x.setTransform(sc,0,0,sc,-L*sc,-T*sc);petDrawRaw(x,id,o);
 x.setTransform(1,0,0,1,0,0);x.globalCompositeOperation='source-atop';const y0=(bx[1]-T)*sc,y1=(bx[1]+bx[3]-T)*sc,x0=(bx[0]-L)*sc,x1=(bx[0]+bx[2]-L)*sc;
 let q=x.createLinearGradient(0,y0,0,y1);q.addColorStop(0,'rgba(255,248,230,.17)');q.addColorStop(.42,'rgba(255,255,255,0)');q.addColorStop(.7,'rgba(16,4,40,0)');q.addColorStop(1,'rgba(16,4,40,.3)');x.fillStyle=q;x.fillRect(0,0,cw,ch);
 q=x.createLinearGradient(x0,0,x1,0);q.addColorStop(0,'rgba(20,6,50,.12)');q.addColorStop(.55,'rgba(0,0,0,0)');q.addColorStop(1,'rgba(255,236,210,.1)');x.fillStyle=q;x.fillRect(0,0,cw,ch);x.globalCompositeOperation='source-over';
 g.save();g.scale(1/sc,1/sc);g.drawImage(PLIT,0,0,cw,ch,L*sc,T*sc,cw,ch);g.restore()}
function petDrawRaw(g,id,o){const R=PRIG[id];if(!R)return;o=Object.assign({t:0,pose:'idle',u:0,pal:0,acc:0,trim:0},o||{});const C=(PCOL[id]||[])[o.pal]||(PCOL[id]||[])[0];
 g.save();g.lineJoin='round';g.lineCap='round';
 if(!o.noSh){const D=PDEF[id]||{},hv=D.hover;g.save();g.globalCompositeOperation='source-over';const q=g.createRadialGradient(0,2,0,0,2,hv?28:40);q.addColorStop(0,'#00000070');q.addColorStop(1,'#00000000');g.fillStyle=q;g.beginPath();g.ellipse(0,2,hv?26:40,hv?5:8,0,0,TAU);g.fill();g.restore()}
 const D2=PDEF[id]||{};if(o.pose==='idle'&&!o.still){const t=o.t,sd=id.length*1.37+id.charCodeAt(0)*.11,ph=((t+sd)%7.6+7.6)%7.6;
  if(!D2.hover){const br=Math.sin(t*2.1+sd)*.013;let sy=1+br,sx=1-br*.6,hy=0;
   /* now and then a little hop-and-settle */if(ph<.7){const k=ph/.7;hy=-Math.sin(k*Math.PI)*6;const sq=k<.15?(1-k/.15)*.06:k>.85?((k-.85)/.15)*.05:0;sy-=sq;sx+=sq*.8}
   g.translate(0,hy);g.scale(sx,sy)}
  else{/* hovering companions sway and occasionally do a little loop */const lp=ph<1.1?Math.sin(ph/1.1*Math.PI):0;g.translate(0,-lp*10);g.rotate(Math.sin(t*.9+sd)*.04+lp*.12)}}
 if(o.trim)try{petAura(g,id,o.t,false)}catch(e){}
 try{R(g,o,C)}catch(e){}
 if(o.trim)try{petAura(g,id,o.t,true)}catch(e){}
 g.restore()}
/* ---------- victory greetings (Bond 7): a themed celebration drawn around a companion ---------- */
const PCEL={bramble:'leaf',mosskip:'leaf',antler:'heart',lily:'splash',cinder:'ember',beetle:'coin',ember:'ember',tick:'chime',gloom:'sonar',wisp:'orb',noct:'moon',crab:'crystal',quill:'bubble',starcoil:'star',prism:'rainbow'};
/* u: 0..1 through the celebration; cy: centre height above the feet; R: size */
function petCelFx(g,id,u,t,cy,R){const k=PCEL[id]||'star',a0=1-pSeg(u,.65,1),N=14;if(u<=0||u>=1)return;cy=cy||-50;R=R||70;
 g.save();g.translate(0,cy);
 for(let i=0;i<N;i++){const an=i/N*TAU+i*.37,sp=.6+((i*53)%10)/14,r=R*(.25+pSeg(u,0,.6)*sp),x=Math.cos(an)*r,y=Math.sin(an)*r*.75-pSeg(u,.2,1)*R*.35*(k==='ember'||k==='orb'||k==='bubble'?1.4:k==='leaf'?-.4:.6),rot=t*2+i,al=a0*(i%3?1:.8);
  g.globalAlpha=Math.max(0,al);
  if(k==='leaf')pLeaf(g,x,y,12,4.5,rot,i%2?'#a6ff6a':'#ffd45a','#3a8a2a',1.4);
  else if(k==='heart'){if(i%2)pHeart(g,x,y,6,'#ff8ab4',1.4);else{pE(g,x,y,5,3,rot);pF(g,'#ffc8e0',1)}}
  else if(k==='splash'){pE(g,x,y,3.4,5,an+Math.PI/2);pF(g,'#9ff0ff',1.2)}
  else if(k==='ember'){pGlow(g,x,y,10,'#ff8a2a',.6*al);pC(g,x,y,2.4);g.fillStyle='#fff2a0';g.fill()}
  else if(k==='coin'){g.save();g.translate(x,y);g.scale(Math.abs(Math.cos(rot)),1);pC(g,0,0,5.5);pF(g,'#ffd45a',1.4,'#9a661a');g.restore()}
  else if(k==='chime'){if(i<3){g.beginPath();g.arc(0,0,R*.3+pSeg(u,0,1)*R*(1+i*.35),0,TAU);g.strokeStyle='#ffd45a';g.lineWidth=2.4;g.stroke()}else{g.font='700 15px Poppins,system-ui';g.fillStyle='#ffe48e';g.fillText(i%2?'♪':'♫',x,y)}}
  else if(k==='sonar'){if(i<3){g.beginPath();g.arc(0,0,R*.3+pSeg(u,0,1)*R*(1+i*.3),-.8,.8);g.strokeStyle='#c08aff';g.lineWidth=3;g.stroke();g.beginPath();g.arc(0,0,R*.3+pSeg(u,0,1)*R*(1+i*.3),Math.PI-.8,Math.PI+.8);g.stroke()}else{g.font='700 15px Poppins,system-ui';g.fillStyle='#e0c0ff';g.fillText('♪',x,y)}}
  else if(k==='orb'){pGlow(g,x,y,12,'#7affc8',.7*al);pC(g,x,y,3);g.fillStyle='#e2fff2';g.fill()}
  else if(k==='moon'){if(i%2){g.beginPath();g.arc(x,y,6,.6,Math.PI*1.7);g.arc(x+2,y-1,4.6,Math.PI*1.7,.6,true);g.closePath();pF(g,'#e8e0ff',1.2)}else pStar4(g,x,y,4,'#fff6c0')}
  else if(k==='crystal'){g.save();g.translate(x,y);g.rotate(rot);pP(g,[0,-6,3.4,0,0,6,-3.4,0]);pF(g,i%2?'#9ff0ff':'#e0b8ff',1.2);g.restore()}
  else if(k==='bubble'){pC(g,x,y,3+i%3);g.strokeStyle='#9fdcff';g.lineWidth=1.6;g.stroke();pC(g,x-1,y-1,1);g.fillStyle='#fff';g.fill()}
  else if(k==='rainbow'){pStar4(g,x,y,4+i%3,['#ff6a6a','#ffb04a','#fff06a','#7aff8a','#6ad8ff','#b07aff'][i%6])}
  else pStar4(g,x,y,4+i%3,i%2?'#fff2c0':'#c08aff')}
 g.globalAlpha=1;g.restore()}
/* draw a companion scaled to fit a canvas (portraits, roster cards); sil paints it as a silhouette */
function petFit(cv,id,o){const g=cv.getContext('2d'),w=cv.width,h=cv.height;o=o||{};g.setTransform(1,0,0,1,0,0);if(!o.keep)g.clearRect(0,0,w,h);const D=PDEF[id]||{},bx=D.box||[-60,-110,120,115],s=Math.min((w*.86)/bx[2],(h*.86)/bx[3])*(o.zoom||1);
 g.save();g.translate(w/2-(bx[0]+bx[2]/2)*s,h/2-(bx[1]+bx[3]/2)*s+(o.dy||0));g.scale(s,s);petDraw(g,id,Object.assign({noSh:1},o));g.restore();
 if(o.sil){g.save();g.globalCompositeOperation='source-atop';g.fillStyle=o.sil===true?'#140c24':o.sil;g.fillRect(0,0,w,h);g.restore()}}

/* ---------- EGGS ---------- */
/* egg outline: base at y 0, height 120, half-width 44 */
function eggPath(g,w,h){w=w||44;h=h||120;g.beginPath();g.moveTo(0,-h);g.bezierCurveTo(w*.95,-h,w*1.08,-h*.38,w*.92,-h*.18);g.bezierCurveTo(w*.75,0,-w*.75,0,-w*.92,-h*.18);g.bezierCurveTo(-w*1.08,-h*.38,-w*.95,-h,0,-h);g.closePath()}
/* the zig-zag crack line across the egg at height y */
function eggCrackPts(y,n,amp){const P=[];for(let i=0;i<=n;i++){const x=-60+120*i/n;P.push([x,y+(i%2?-amp:amp)])}return P}
/* shared shell finish: core shadow, rim light, a few speckles and a glint that sweeps across now and then */
function eggFinish(g,w,h,t,rim,spk){g.save();eggPath(g,w,h);g.clip();
 let q=g.createRadialGradient(-w*.55,-h*.25,4,-w*.2,-h*.45,w*1.4);q.addColorStop(0,'#00000000');q.addColorStop(.7,'#00000000');q.addColorStop(1,'#0000004a');g.fillStyle=q;g.fillRect(-w*1.2,-h*1.1,w*2.4,h*1.2);
 q=g.createLinearGradient(-w,0,w,0);q.addColorStop(0,'#00000038');q.addColorStop(.35,'#00000000');q.addColorStop(.8,'#00000000');q.addColorStop(1,rim+'66');g.fillStyle=q;g.fillRect(-w*1.2,-h*1.1,w*2.4,h*1.2);
 for(let i=0;i<9;i++){const x=Math.sin(i*12.9)*w*.7,y=-h*(.15+((i*.37)%1)*.75);pC(g,x,y,.9+(i%3)*.5);g.fillStyle=spk;g.fill()}
 const gp=((t*.22)%1.5);if(gp<1){g.globalCompositeOperation='lighter';g.translate(-w*1.4+gp*w*2.8,-h*.5);g.rotate(.45);const q2=g.createLinearGradient(-10,0,10,0);q2.addColorStop(0,'#ffffff00');q2.addColorStop(.5,'#ffffff55');q2.addColorStop(1,'#ffffff00');g.fillStyle=q2;g.fillRect(-10,-h,20,h*2)}
 g.restore()}
/* RUNESHELL (Rare): blue scaled shell, bevelled silver chevrons engraved with runes, glowing cyan inlays and a silver-ringed paw seal */
const RUNE_CY=-80,RUNE_P=eggCrackPts(-80,10,5);
const RUNE_BR=[[2,[-24,-90],[-27,-100],[-22,-108]],[4,[-10,-70],[-14,-61]],[6,[6,-92],[11,-101]],[7,[18,-70],[15,-60],[20,-52]],[9,[38,-92],[34,-100]]];
function eggRuneBody(g,t,gl){eggPath(g);pF(g,pLin(g,-44,-120,44,0,['#86b2ff','#3a6ad8','#18307e']),3.4);
 g.save();eggPath(g);g.clip();
 let q=g.createLinearGradient(0,-30,0,0);q.addColorStop(0,'#0e1a4a00');q.addColorStop(1,'#0c1848');g.fillStyle=q;g.fillRect(-60,-32,120,34);
 g.strokeStyle='#ffffff12';g.lineWidth=1.1;for(let r=0;r<7;r++)for(let i=-4;i<=4;i++){g.beginPath();g.arc(i*13+(r%2)*6.5,-116+r*15,6.5,.15,Math.PI-.15);g.stroke()}
 const pu=.5+.5*Math.sin(t*2.4);
 /* glowing cyan inlays in the grooves */for(const yb of[-82,-52])for(let i=-5;i<=5;i++){const x=i*10;if(yb===-52&&Math.abs(x)<18)continue;if(yb===-82&&Math.abs(x)<4)continue;const yy=yb+18*(1-Math.abs(x)/60);pGlow(g,x,yy,3.4+gl*6,'#5ff0ff',.12+.14*pu+gl*.5);pC(g,x,yy,1.3);g.fillStyle=gl>.3?'#e8ffff':'#8ff6ff';g.fill()}
 for(const [y,c] of[[-96,'#f2f6fd'],[-66,'#dbe3f3'],[-36,'#f2f6fd']]){g.beginPath();g.moveTo(-60,y-6);g.lineTo(0,y+12);g.lineTo(60,y-6);g.lineTo(60,y+4);g.lineTo(0,y+22);g.lineTo(-60,y+4);g.closePath();pF(g,pLin(g,0,y-6,0,y+22,['#ffffff',c,'#98a4c2']),2.4);
  g.beginPath();g.moveTo(-60,y-4);g.lineTo(0,y+14);g.lineTo(60,y-4);g.strokeStyle='#ffffffcc';g.lineWidth=1.2;g.stroke();g.beginPath();g.moveTo(-60,y+2.4);g.lineTo(0,y+20.4);g.lineTo(60,y+2.4);g.strokeStyle='#6a7898';g.lineWidth=1.1;g.stroke();
  /* engraved runes */g.strokeStyle='#7a88aa';g.lineWidth=1.2;[-36,-20,20,36].forEach((x,i)=>{const yc=y-1+18*(1-Math.abs(x)/60);g.beginPath();if(i%2){g.moveTo(x-2,yc-3);g.lineTo(x,yc+3);g.lineTo(x+2,yc-3)}else{g.moveTo(x,yc-3);g.lineTo(x,yc+3);g.moveTo(x-2.4,yc-1);g.lineTo(x+2.4,yc+1)}g.stroke()})}
 g.beginPath();g.ellipse(-17,-84,7,22,-.3,0,TAU);g.fillStyle='#ffffff38';g.fill();g.beginPath();g.ellipse(-12,-104,3,6,-.3,0,TAU);g.fillStyle='#ffffff66';g.fill();g.restore();
 eggFinish(g,44,120,t,'#bfe6ff','#cfe0ff55');
 /* the paw seal in a silver ring with four cyan studs */const sx=0,sy=-56;pGlow(g,sx,sy,30+gl*24,'#5ff0ff',.28+gl*.6+.08*pu);
 pC(g,sx,sy,16.5);pF(g,pLin(g,-16,sy-16,16,sy+16,['#ffffff','#b8c4dc','#6a7896']),2.4);pC(g,sx,sy,12.4);pF(g,pRad(g,sx,sy,13,['#3a4a8a','#1a2458','#0c1238']),1.6);
 for(let i=0;i<4;i++){const a=Math.PI/4+i*Math.PI/2,x=sx+Math.cos(a)*14.5,y=sy+Math.sin(a)*14.5;pP(g,[x,y-2.4,x+2.4,y,x,y+2.4,x-2.4,y]);pF(g,'#8ff6ff',.8)}
 const pc=gl>.1?'#e8ffff':'#6ff4ff';g.save();if(gl>.05){g.shadowColor='#5ff0ff';g.shadowBlur=8+gl*10}pE(g,sx,sy+2.6,4.6,3.8);g.fillStyle=pc;g.fill();for(const [x,y] of[[-5.6,-3.6],[-2,-6.6],[2,-6.6],[5.6,-3.6]]){pE(g,sx+x,sy+y,1.8,2.3);g.fill()}g.restore();
 g.beginPath();g.arc(sx,sy,16.5,-2.5,-1);g.strokeStyle='#ffffffaa';g.lineWidth=1.6;g.stroke()}
function eggRuneCrack(g,cr,cg){const P=RUNE_P,n=Math.max(1,Math.round(P.length*Math.min(1,cr*1.6)));g.save();eggPath(g);g.clip();
 const path=()=>{g.beginPath();g.moveTo(P[0][0],P[0][1]);for(let i=1;i<n;i++)g.lineTo(P[i][0],P[i][1]);const bk=Math.max(0,(cr-.45)/.55);for(const b of RUNE_BR){if(b[0]>=n)continue;const p=P[b[0]];g.moveTo(p[0],p[1]);const m=Math.max(1,Math.round((b.length-1)*bk));for(let j=1;j<=m&&j<b.length;j++)g.lineTo(b[j][0],b[j][1])}};
 g.globalCompositeOperation='lighter';path();g.strokeStyle=ptHexA('#5ff0ff',.35*cg);g.lineWidth=10;g.stroke();g.strokeStyle=ptHexA('#bfffff',.7*cg);g.lineWidth=4;g.stroke();g.globalCompositeOperation='source-over';path();g.strokeStyle='#effffff0';g.lineWidth=1.8;g.stroke();g.restore()}
const ptHexA=(c,a)=>c+Math.round(Math.max(0,Math.min(1,a))*255).toString(16).padStart(2,'0');
function eggRune(g,o){const t=o.t||0,gl=o.glow||0,cr=o.crack||0,op=o.open||0,cy=RUNE_CY,P=RUNE_P,split=o.cap||op>0;
 if(!split){eggRuneBody(g,t,gl);if(cr>0)eggRuneCrack(g,cr,o.cg==null?1:o.cg);return}
 g.save();g.beginPath();g.moveTo(-70,10);P.forEach(p=>g.lineTo(p[0],p[1]));g.lineTo(70,10);g.closePath();g.clip();eggRuneBody(g,t,gl);
 /* the jagged rim lights up from inside */eggPath(g);g.clip();g.beginPath();g.moveTo(P[0][0],P[0][1]);P.forEach(p=>g.lineTo(p[0],p[1]));g.strokeStyle='#dffcff';g.lineWidth=3;g.stroke();g.restore();
 pGlow(g,0,cy,70,'#9ff8ff',.55*(o.cap?(o.cap.glow==null?1:o.cap.glow):op));
 if(o.hideCap)return;g.save();if(o.cap){const c=o.cap;g.globalAlpha=c.a==null?1:c.a;g.translate(c.x||0,c.y||0);g.translate(0,cy-22);g.rotate(c.r||0);g.scale(c.s||1,c.s||1);g.translate(0,-(cy-22))}else{g.translate(46,cy-18*op);g.rotate(1.05*op);g.translate(-46-6*op,-cy)}
 g.beginPath();g.moveTo(-70,-140);P.forEach(p=>g.lineTo(p[0],p[1]));g.lineTo(70,-140);g.closePath();g.clip();eggRuneBody(g,t,gl);eggPath(g);g.clip();g.beginPath();g.moveTo(P[0][0],P[0][1]);P.forEach(p=>g.lineTo(p[0],p[1]));g.strokeStyle='#bfffff';g.lineWidth=3;g.stroke();g.restore()}
/* CROWNHEART (Legendary): indigo star-flecked cup, pearl-ivory shell with gold filigree and jewelled ribs, a jewelled crown and an amber heart diamond */
function eggCrown(g,o){const t=o.t||0,gl=o.glow||0,lf=o.lift||0,op=o.open||0,pu=.5+.5*Math.sin(t*2.2);
 const lower=()=>{g.save();eggPath(g,46,124);g.clip();g.beginPath();g.rect(-70,-58,140,70);pF(g,pLin(g,0,-58,0,0,['#5242b8','#2a1e78','#140c40']),0);
  for(let i=0;i<14;i++){const x=Math.sin(i*7.7)*40,y=-50+((i*.37)%1)*44,tw=.5+.5*Math.sin(t*2.6+i*1.9);pStar4(g,x,y,1+tw*1.6,ptHexA('#e8d8ff',.35+.5*tw))}
  g.beginPath();g.ellipse(0,-6,44,7,0,.05,Math.PI-.05);g.strokeStyle='#e8b04a';g.lineWidth=3;g.stroke();for(let i=-3;i<=3;i++){pC(g,i*12,-4+Math.abs(i)*-.6,1.6);g.fillStyle='#fff2a0';g.fill()}
  /* violet seam */const sg=.6+.4*pu+lf;g.beginPath();for(let i=0;i<=8;i++){g.lineTo(-56+i*14,-58+(i%2?-8:6))}g.lineTo(60,-50);g.lineTo(-60,-50);g.closePath();g.fillStyle='#b070ff';g.fill();
  g.save();g.globalCompositeOperation='lighter';g.beginPath();for(let i=0;i<=8;i++){g.lineTo(-56+i*14,-52+(i%2?-8:6))}g.strokeStyle=ptHexA('#e0b8ff',.5*sg);g.lineWidth=6;g.stroke();g.restore();g.beginPath();for(let i=0;i<=8;i++){g.lineTo(-56+i*14,-52+(i%2?-8:6))}g.strokeStyle='#f0dcff';g.lineWidth=1.6;g.stroke();g.restore();
  g.save();g.beginPath();g.rect(-70,-60,140,72);g.clip();eggPath(g,46,124);g.strokeStyle=PTO;g.lineWidth=3.4;g.stroke();g.restore()};
 const ribs=()=>{for(const x of[-30,0,30]){g.beginPath();g.moveTo(x*.5,-124);g.quadraticCurveTo(x*1.12,-70,x*.92,-20);g.strokeStyle=PTO;g.lineWidth=9;g.stroke();g.strokeStyle=pLin(g,x-6,0,x+6,0,['#fff6c0','#ffd45a','#b8801a']);g.lineWidth=5.4;g.stroke();g.strokeStyle='#fff8d0aa';g.lineWidth=1.4;g.beginPath();g.moveTo(x*.5-1.4,-122);g.quadraticCurveTo(x*1.12-1.4,-70,x*.92-1.4,-24);g.stroke();
   if(x){const sx=x*.66,sy=-108;pP(g,[sx,sy-4.4,sx+3.4,sy,sx,sy+4.4,sx-3.4,sy]);pF(g,pLin(g,0,sy-4,0,sy+4,['#f0c8ff','#a050e0','#4a1a80']),1.2)}}};
 const filigree=()=>{g.strokeStyle='#d8a838';g.lineWidth=1.2;for(const s of[-1,1])for(const [y,k] of[[-98,1],[-78,.8]]){const x=s*15;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+s*8*k,y-6*k,x+s*10*k,y+1);g.quadraticCurveTo(x+s*10*k,y+6*k,x+s*5*k,y+4*k);g.stroke();pC(g,x+s*5*k,y+4*k,1.1);g.fillStyle='#ffd45a';g.fill()}};
 const upper=(part)=>{g.save();eggPath(g,46,124);g.clip();
  if(part!=='all'){g.beginPath();if(part==='L'){g.moveTo(-80,-140);g.lineTo(-15,-140);g.lineTo(-15,-50);g.lineTo(-80,-50)}else if(part==='R'){g.moveTo(80,-140);g.lineTo(15,-140);g.lineTo(15,-50);g.lineTo(80,-50)}else{g.moveTo(-15,-140);g.lineTo(15,-140);g.lineTo(15,-50);g.lineTo(-15,-50)}g.closePath();g.clip()}
  g.beginPath();g.rect(-70,-140,140,84);pF(g,pLin(g,-40,-124,40,-56,['#fffdf6','#f4ead4','#c8b494']),0);
  const sh=g.createLinearGradient(-46,-120,46,-60);sh.addColorStop(0,'#ffe8ff22');sh.addColorStop(.5,'#e8f8ff26');sh.addColorStop(1,'#fff0c822');g.fillStyle=sh;g.fillRect(-60,-140,120,84);
  filigree();g.beginPath();g.ellipse(-18,-94,6.5,20,-.3,0,TAU);g.fillStyle='#ffffff90';g.fill();ribs();g.restore();
  g.save();g.beginPath();g.rect(part==='R'?15:-70,-140,part==='all'?140:part==='C'?30:55,84);if(part==='C'){g.beginPath();g.rect(-15,-140,30,84)}g.clip();eggPath(g,46,124);g.strokeStyle=PTO;g.lineWidth=3.4;g.stroke();g.restore()};
 const crown=()=>{if(o.hideCrown)return;g.save();if(o.crownT){const c=o.crownT;g.globalAlpha=c.a==null?1:c.a;g.translate(c.x||0,-120+(c.y||0));g.rotate(c.r||0);g.scale(c.s||1,c.s||1)}else{g.translate(0,-120-lf*26-op*20);g.rotate(op*.2)}
  pGlow(g,0,-4,26,'#ffd45a',.18+.3*lf);pP(g,[-22,6,-24,-6,-14,-2,-8,-16,0,-4,8,-16,14,-2,24,-6,22,6]);pF(g,pLin(g,0,-16,0,6,['#fff6c0','#ffd45a','#b8801a']),2.6);
  g.beginPath();g.roundRect(-22,1,44,6,2);pF(g,pLin(g,0,1,0,7,['#ffe48a','#c8901a']),1.6);for(const [x,y] of[[-24,-6],[-8,-16],[8,-16],[24,-6]]){pC(g,x,y,2.2);pF(g,'#fff8e8',1.2)}
  pP(g,[-4,-6,0,-13,4,-6,0,0]);pF(g,pLin(g,0,-13,0,0,['#ffb0c0','#e02a4a','#7a0a1a']),1.4);for(const x of[-13,13]){pC(g,x,3.6,1.9);pF(g,'#5ab0ff',1)}
  const tw=(t*.9)%2.4;if(tw<.4)pStar4(g,-6,-10,2+Math.sin(tw/.4*Math.PI)*4,'#ffffffee');g.restore()};
 const gem=()=>{const y=-72;pGlow(g,0,y,30+gl*34,'#ffb02a',.35+gl*.55+.08*pu);pP(g,[0,y-18,12,y,0,y+18,-12,y]);pF(g,pLin(g,0,y-18,0,y+18,['#fff6c0','#ffd45a','#b8801a']),2.6);
  pP(g,[0,y-11,7,y,0,y+11,-7,y]);pF(g,pLin(g,0,y-11,0,y+11,['#fff6c0','#ffa21a','#c85a0a']),1.4);g.fillStyle='#ffffffb0';pP(g,[0,y-11,7,y,0,y]);g.fill();g.fillStyle='#7a2a0a55';pP(g,[0,y+11,-7,y,0,y]);g.fill();
  g.strokeStyle='#ffffff60';g.lineWidth=.9;g.beginPath();g.moveTo(-7,y);g.lineTo(7,y);g.moveTo(0,y-11);g.lineTo(0,y+11);g.stroke()};
 if(op<=0){if(lf>0)pGlow(g,0,-56,50,'#b070ff',.5*lf);lower();upper('all');eggFinish(g,46,124,t,'#fff2c8','#a8987055');gem();const tw=(t*.7)%3;if(tw<.4)pStar4(g,6,-84,3+Math.sin(tw/.4*Math.PI)*4,'#ffffffee');crown();
  if(lf>0){g.save();g.beginPath();for(let i=0;i<=8;i++){g.lineTo(-42+i*10.5,-56+(i%2?-5:4))}g.strokeStyle='#e0b8ff';g.globalAlpha=lf;g.lineWidth=3;g.shadowColor='#b070ff';g.shadowBlur=12;g.stroke();g.restore();
   /* light seams along the ribs */g.save();g.globalCompositeOperation='lighter';g.globalAlpha=lf;for(const x of[-30,0,30]){g.beginPath();g.moveTo(x*.5,-124);g.quadraticCurveTo(x*1.12,-70,x*.92,-20);g.strokeStyle='#fff2b0';g.lineWidth=3+lf*3;g.stroke()}g.restore()}return}
 pGlow(g,0,-60,80+op*40,'#ffd45a',.5*op+.2);lower();
 for(const [k,s] of[['L',-1],['R',1]]){g.save();g.translate(s*40,-56);g.rotate(s*op*(o.petalR||.78));g.translate(-s*40-s*op*10,56);if(o.petalA!=null)g.globalAlpha=o.petalA;upper(k);g.restore()}
 g.save();g.translate(0,-op*30);g.globalAlpha=Math.max(0,1-op);upper('C');g.restore();g.globalAlpha=1;crown()}
function eggDraw(g,kind,o){g.save();g.lineJoin='round';g.lineCap='round';o=o||{};if(!o.noSh){const q=g.createRadialGradient(0,2,0,0,2,52);q.addColorStop(0,'#00000080');q.addColorStop(1,'#00000000');g.fillStyle=q;g.beginPath();g.ellipse(0,2,50,10,0,0,TAU);g.fill()}
 g.rotate(o.lean||0);(kind==='l'?eggCrown:eggRune)(g,o);g.restore()}
function eggFit(cv,kind,o){const g=cv.getContext('2d'),w=cv.width,h=cv.height;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,w,h);const s=Math.min(w/120,h/150)*((o&&o.zoom)||1);g.save();g.translate(w/2,h*.92);g.scale(s,s);eggDraw(g,kind,o||{});g.restore()}

/* ---------- ability icons: one readable symbol per power, drawn in a 100-unit box centred at 0,0 ---------- */
const PICO={
 leafguard:g=>{g.beginPath();g.moveTo(0,-38);g.lineTo(30,-26);g.lineTo(28,8);g.quadraticCurveTo(20,30,0,40);g.quadraticCurveTo(-20,30,-28,8);g.lineTo(-30,-26);g.closePath();pF(g,pLin(g,0,-38,0,40,['#c8ff8a','#6ad040','#2e8a2a']),4);g.beginPath();g.moveTo(0,-30);g.lineTo(0,32);g.strokeStyle='#2e7a22';g.lineWidth=3;g.stroke();for(let i=0;i<3;i++){g.beginPath();g.moveTo(0,-16+i*14);g.lineTo(14,-24+i*14);g.moveTo(0,-16+i*14);g.lineTo(-14,-24+i*14);g.stroke()}
  for(const s of[-1,1])pLeaf(g,s*30,-30,16,6,s>0?-.6:Math.PI+.6,'#a6ff6a','#3a9a2a',2)},
 scholar:g=>{for(const d of[-1,1]){g.save();g.scale(d,1);g.beginPath();g.moveTo(0,14);g.quadraticCurveTo(18,6,36,12);g.lineTo(36,-20);g.quadraticCurveTo(18,-26,0,-18);g.closePath();pF(g,'#fff6dc',4);for(let i=0;i<3;i++){g.beginPath();g.moveTo(8,-10+i*8);g.lineTo(28,-12+i*8);g.strokeStyle='#c8b890';g.lineWidth=2;g.stroke()}g.restore()}pLeaf(g,-4,-16,30,10,-1.1,'#86d24e','#3a962a',3)},
 heartgrove:g=>{for(const s of[-1,1]){g.beginPath();g.moveTo(s*12,-10);g.quadraticCurveTo(s*26,-26,s*20,-42);g.moveTo(s*20,-26);g.quadraticCurveTo(s*34,-30,s*36,-38);g.strokeStyle=PTO;g.lineWidth=10;g.stroke();g.strokeStyle='#ffd45a';g.lineWidth=6;g.stroke()}pHeart(g,0,4,20,pLin(g,0,-16,0,22,['#c8ffd8','#3cff86','#0a9a4a']),4)},
 calm:g=>{g.save();g.scale(1,.34);for(let i=0;i<3;i++){g.beginPath();g.arc(0,70,30+i*14,0,TAU);g.strokeStyle=['#9ff0ff','#5ad8ff','#2a98d8'][i];g.lineWidth=7;g.stroke()}g.restore();g.beginPath();g.moveTo(0,-38);g.bezierCurveTo(18,-14,22,4,0,12);g.bezierCurveTo(-22,4,-18,-14,0,-38);g.closePath();pF(g,pLin(g,0,-38,0,12,['#dffcff','#5ad8ff','#2a7ad8']),4)},
 embertag:g=>{g.beginPath();g.moveTo(-18,30);g.bezierCurveTo(-30,4,-8,-10,-4,-40);g.bezierCurveTo(8,-18,30,-8,20,30);g.closePath();pF(g,pLin(g,0,-40,0,30,['#fff2a0','#ffa21a','#ff4a14']),4);g.beginPath();g.moveTo(-8,28);g.bezierCurveTo(-14,10,0,0,2,-14);g.bezierCurveTo(8,0,14,10,8,28);g.closePath();g.fillStyle='#fff6c0';g.fill()},
 gilded:g=>{pC(g,0,0,34);pF(g,pLin(g,-34,-34,34,34,['#fff2a0','#ffd45a','#b8801a']),4);pC(g,0,0,24);g.strokeStyle='#c8901a';g.lineWidth=3;g.stroke();g.beginPath();g.moveTo(0,-14);g.lineTo(0,14);g.strokeStyle='#9a661a';g.lineWidth=5;g.stroke();pStar4(g,24,-24,10,'#ffffff')},
 sweep:g=>{g.beginPath();g.moveTo(-30,26);g.quadraticCurveTo(-20,-30,34,-36);g.quadraticCurveTo(14,-20,22,-12);g.quadraticCurveTo(4,-6,14,4);g.quadraticCurveTo(-6,6,4,18);g.quadraticCurveTo(-14,18,-30,26);g.closePath();pF(g,pLin(g,-30,26,34,-36,['#c2282a','#ff8a2a','#ffe07a']),4)},
 second:g=>{pC(g,0,4,34);pF(g,pLin(g,0,-30,0,38,['#ffe48e','#e2aa3c','#986618']),4);pC(g,0,4,26);pF(g,'#fff4dc',3);for(let i=0;i<12;i++){const a=i*Math.PI/6;g.beginPath();g.moveTo(Math.cos(a)*20,4+Math.sin(a)*20);g.lineTo(Math.cos(a)*24,4+Math.sin(a)*24);g.strokeStyle='#3a2416';g.lineWidth=i%3?2:3.4;g.stroke()}g.beginPath();g.moveTo(0,4);g.lineTo(0,-14);g.moveTo(0,4);g.lineTo(12,10);g.strokeStyle='#3a2416';g.lineWidth=4;g.stroke();g.beginPath();g.roundRect(-8,-40,16,8,3);pF(g,'#e2aa3c',3)},
 echo:g=>{g.beginPath();g.moveTo(-14,-14);g.lineTo(-8,-26);g.lineTo(-2,-14);g.moveTo(2,-14);g.lineTo(8,-26);g.lineTo(14,-14);g.strokeStyle=PTO;g.lineWidth=3;pC(g,0,0,14);pF(g,'#c870c8',4);for(const s of[-1,1])for(let i=0;i<3;i++){g.beginPath();g.arc(0,0,22+i*10,s>0?-.7:Math.PI-.7,s>0?.7:Math.PI+.7);g.strokeStyle='#d0a0ff';g.lineWidth=5;g.stroke()}},
 lantern:g=>{g.beginPath();g.roundRect(-20,-26,40,48,6);pF(g,'#2a1a3a',4);pGlow(g,0,0,30,'#7affc8',.6);pHeart(g,0,-2,13,'#7affc8',3);for(const x of[-20,20]){g.beginPath();g.moveTo(x,-26);g.lineTo(x,22);g.strokeStyle='#e6aa3a';g.lineWidth=5;g.stroke()}g.beginPath();g.moveTo(-22,-26);g.quadraticCurveTo(0,-44,22,-26);g.closePath();pF(g,'#e6aa3a',4);g.beginPath();g.roundRect(-22,20,44,8,3);pF(g,'#e6aa3a',3)},
 moonbind:g=>{g.beginPath();g.arc(0,0,34,.5,Math.PI*1.75);g.arc(10,-6,28,Math.PI*1.75,.5,true);g.closePath();pF(g,pLin(g,0,-34,0,34,['#f0e8ff','#b88aff','#6a3ab8']),4);for(const x of[2,14]){g.beginPath();g.roundRect(x-3,-12,6,24,2);pF(g,'#fff',2.4)}},
 catch:g=>{g.beginPath();g.moveTo(0,-38);g.lineTo(28,-24);g.lineTo(24,12);g.lineTo(0,38);g.lineTo(-24,12);g.lineTo(-28,-24);g.closePath();pF(g,pLin(g,0,-38,0,38,['#c8f6ff','#5ad8ff','#2a6ad8']),4);g.beginPath();g.moveTo(0,-18);g.lineTo(12,0);g.lineTo(0,18);g.lineTo(-12,0);g.closePath();pF(g,'#ffd45a',3)},
 inkflow:g=>{g.save();g.rotate(-.7);g.beginPath();g.moveTo(0,-40);g.quadraticCurveTo(16,-10,4,26);g.lineTo(-4,26);g.quadraticCurveTo(-16,-10,0,-40);g.closePath();pF(g,pLin(g,0,-40,0,26,['#fff2a0','#ffd45a','#c88a1a']),4);g.beginPath();g.moveTo(0,-30);g.lineTo(0,22);g.strokeStyle='#c88a1a';g.lineWidth=2.4;g.stroke();g.restore();pP(g,[18,-28,6,0,16,0,4,28,26,-6,16,-6]);pF(g,'#b07aff',3.4)},
 reservoir:g=>{g.beginPath();g.arc(0,0,30,-.4,Math.PI*1.6);g.strokeStyle=PTO;g.lineWidth=14;g.stroke();g.strokeStyle=pLin(g,-30,0,30,0,['#3a4a9a','#a86aff']);g.lineWidth=9;g.stroke();pStar5(g,0,0,18,pLin(g,0,-18,0,18,['#fff6c0','#ffd45a','#c88a1a']),3.4)},
 prism:g=>{pP(g,[0,-34,30,24,-30,24]);pF(g,pLin(g,-30,24,30,-34,['#c8f6ff','#ffffff','#e0c8ff']),4);const rc=['#ff6a6a','#ffb04a','#fff06a','#7aff8a','#6ad8ff','#b07aff'];rc.forEach((c,i)=>{g.beginPath();g.moveTo(10,4);g.lineTo(44,-10+i*6);g.strokeStyle=c;g.lineWidth=4;g.stroke()});g.beginPath();g.moveTo(-44,-2);g.lineTo(-10,6);g.strokeStyle='#ffffff';g.lineWidth=4;g.stroke()}
};
function petIcon(g,k,x,y,s){const f=PICO[k];if(!f)return;g.save();g.translate(x,y);g.scale(s/100,s/100);g.lineJoin='round';g.lineCap='round';try{f(g)}catch(e){}g.restore()}
function petIconCv(cv,k){const g=cv.getContext('2d');g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,cv.width,cv.height);petIcon(g,k,cv.width/2,cv.height/2,Math.min(cv.width,cv.height)*.92)}
