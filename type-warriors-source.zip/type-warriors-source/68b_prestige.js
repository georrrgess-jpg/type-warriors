/* ---------- prestige: reset for permanent perks, exclusive armor and profile badges ---------- */
const PMAX=10,PBP=[['#e0a060','#6a3a16','#ffd0a0'],['#eef2f8','#7a8498','#ffffff'],['#ffe27a','#a8701a','#fff6c0'],['#7ab0ff','#1a3a90','#d0e8ff'],['#ff5a70','#6a0a1c','#ffc0c8'],['#5aeaa0','#0c5a34','#d8ffe8'],['#c890ff','#3a1478','#f4e0ff'],['#585870','#0c0c18','#ff9a4a'],['#fff4b0','#c88a10','#ffffff'],['#ffffff','#8a70c8','#ffffff']];
const PNAME=['Squire','Vanguard','Warden','Regent','Paragon','Sovereign','Archon','Overlord','Exemplar','Eternal'];
const canPres=()=>P.pres<PMAX&&lvl(P.xp)>=MAXLV&&!!P.stars[30];
const carrySlots=n=>n;
const CARRY_LEG=4,CARRY_MYTH=7,carryMin=r=>RKM[r]>=5?CARRY_MYTH:RKM[r]===4?CARRY_LEG:0;
const pscore=n=>10*n,pxp=n=>10*n,pgold=n=>5*n;
const perkLines=n=>{const a=[`+${pscore(n)}% score`,`+${pxp(n)}% XP`,`+${pgold(n)}% gold from monsters and rounds`,`${carrySlots(n)} carry-over slot${carrySlots(n)>1?'s':''}`];if(n===CARRY_LEG)a.push('Legendary gear can now be carried over');if(n===CARRY_MYTH)a.push('Mythic gear can now be carried over');if(n>=3)a.push('Start every run with +1 shield');if(n>=5)a.push('+1 max HP');if(n>=10)a.push('Title: Eternal Champion');return a};
/* badge: a medallion with wings, ribbons and gems that grows richer with every rank */
function prBadge(g,cx,cy,s,n,t){if(n<1)return;const P0=PBP[n-1],rb=n===10,m=rb?hsx(t*60,70,72):P0[0],d=rb?hsx(t*60+90,60,32):P0[1],h=rb?hsx(t*60+180,80,86):P0[2];
 g.save();g.translate(cx,cy);g.scale(s,s);g.lineJoin='round';
 glow(g,0,0,84+n*3,m+'55');
 if(n>=4){for(const sd of[-1,1]){g.save();g.scale(sd,1);const f=Math.min(6,n-1);for(let i=0;i<f;i++){const a=-.35+i*.3,L=52+i*7+Math.sin(t*2+i)*1.5;g.save();g.rotate(a);poly(g,[30,-4,30+L,-9-i*1.5,30+L*.9,4,30,10],i%2?d:m);g.strokeStyle=h+'99';g.lineWidth=1;g.beginPath();g.moveTo(32,0);g.lineTo(30+L*.8,-2);g.stroke();g.restore()}g.restore()}}
 /* ribbons */
 poly(g,[-20,28,-34,74,-22,66,-14,78,-6,34],rb?hsx(t*60+40,80,50):'#b8203a');poly(g,[20,28,34,74,22,66,14,78,6,34],rb?hsx(t*60+200,80,50):'#b8203a');
 poly(g,[-20,28,-6,34,-14,78],'#0004');poly(g,[20,28,6,34,14,78],'#0004');
 /* medallion */
 ell(g,0,0,44,44,rgr(g,-14,-16,4,50,h,d));ell(g,0,0,37,37,vgr(g,-37,37,shade(d,-.3),shade(d,-.6)));
 g.strokeStyle=h;g.lineWidth=1.6;g.beginPath();g.arc(0,0,34,0,TAU);g.stroke();
 for(let i=0;i<24;i++){const a=i*TAU/24;g.fillStyle=i%2?h:m;g.beginPath();g.arc(Math.cos(a)*40.5,Math.sin(a)*40.5,1.9,0,TAU);g.fill()}
 /* shield emblem */
 g.beginPath();g.moveTo(0,-27);g.lineTo(21,-19);g.lineTo(21,3);g.quadraticCurveTo(20,20,0,29);g.quadraticCurveTo(-20,20,-21,3);g.lineTo(-21,-19);g.closePath();g.fillStyle=vgr(g,-27,29,m,d);g.fill();g.lineWidth=2;g.strokeStyle=h;g.stroke();
 g.beginPath();g.moveTo(0,-22);g.lineTo(16,-16);g.lineTo(16,2);g.quadraticCurveTo(15,15,0,23);g.quadraticCurveTo(-15,15,-16,2);g.lineTo(-16,-16);g.closePath();g.strokeStyle='#0006';g.lineWidth=1.2;g.stroke();
 g.fillStyle=n>=8?'#fff':'#1a1020';g.textAlign='center';g.textBaseline='middle';g.font=(n>=8?"400 22px":"400 27px")+" 'Pirata One',Georgia,serif";if(n>=8){g.shadowColor=h;g.shadowBlur=8}g.fillText(PRN[n-1],0,-1);g.shadowBlur=0;
 /* rank pips */
 for(let i=0;i<n;i++){const a=Math.PI*(.18+.64*(n===1?.5:i/(n-1))),x=Math.cos(a)*50,y=Math.sin(a)*50;glow(g,x,y,7,h+'aa');ell(g,x,y,2.6,2.6,h);ell(g,x-.7,y-.7,1,1,'#fff')}
 /* crown */
 if(n>=7){const c=rb?hsx(t*60+120,80,70):h;poly(g,[-20,-42,-24,-64,-11,-52,0,-70,11,-52,24,-64,20,-42],vgr(g,-70,-42,c,m));g.strokeStyle='#0005';g.lineWidth=1.2;g.stroke();for(const [x,y] of[[-24,-64],[0,-70],[24,-64]]){glow(g,x,y,6,'#fff9');ell(g,x,y,2.2,2.2,'#fff')}}
 else if(n>=3){poly(g,[-9,-43,-12,-57,-4,-50,0,-60,4,-50,12,-57,9,-43],vgr(g,-60,-43,h,m))}
 /* shimmer */
 g.save();g.beginPath();g.arc(0,0,43,0,TAU);g.clip();g.globalAlpha=.32;const sx=((t*.45)%1.6-.8)*110;poly(g,[sx-14,-46,sx+2,-46,sx+22,46,sx+6,46],'#fff');g.restore();
 g.restore()}
/* ---------- profile block ---------- */
const presReqs=()=>[[lvl(P.xp)>=MAXLV,`Reach player level ${MAXLV}`],[!!P.stars[30],'Clear all 30 campaign levels']];
function presBlock(){const n=P.pres||0;
 return `<div class="pres"><div class="pl">Prestige ${n?PRN[n-1]+' · '+PNAME[n-1]:'none yet'}</div><div class="prow"><canvas id="bdg" width="150" height="150"></canvas><div class="pperk">${n?perkLines(n).map(x=>`<span>${x}</span>`).join(''):'<i>Reach level 30 and clear the campaign to prestige.</i>'}</div></div>
 <div class="pmini">${Array.from({length:PMAX},(_,i)=>`<canvas width="44" height="48" data-pb="${i+1}" class="${i<n?'on':''}" title="Prestige ${PRN[i]}"></canvas>`).join('')}</div>
 ${n<PMAX?`<div class="row"><button class="sm${canPres()?' rl':''}" id="pgo" ${canPres()?'':'disabled'}>${canPres()?'Prestige':'Prestige locked'}</button></div>${canPres()?'':`<small class="preq">${presReqs().map(r=>`${r[0]?'✔':'✘'} ${r[1]}`).join('   ')}</small>`}`:'<small class="preq">Maximum prestige reached.</small>'}</div>`}
function presBind(){const n=P.pres||0;live('bdg',c=>{const g=c.getContext('2d');return t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,c.width,c.height);if(n)prBadge(g,75,82,.86,n,t)}});
 ov.querySelectorAll('canvas[data-pb]').forEach(c=>{const i=+c.dataset.pb,g=c.getContext('2d');g.translate(22,26);if(i<=n)prBadge(g,0,0,.3,i,1.2);else{g.globalAlpha=.28;g.filter='grayscale(1) brightness(.6)';prBadge(g,0,0,.3,i,1.2)}});
 if($('pgo'))$('pgo').onclick=()=>{P.name=$('nm').value.trim()||'Hero';save();prestigeScreen(profile)}}
/* ---------- prestige screen ---------- */
function prestigeScreen(back){if(!canPres()){back();return}
 const nx=P.pres+1,slots=carrySlots(nx),A=AR['pr'+nx],pick={w:{},a:{}};let armed=false;
 const base=(T,o)=>Object.keys(T).filter(k=>P[o][k]&&!T[k].pr&&k!=='rusty'&&k!=='rags'&&!(o==='own'&&PK.some(p=>PATHS[p].st===k))),cand=(T,o)=>base(T,o).filter(k=>carryMin(T[k].r)<=nx).sort((x,y)=>RKM[T[y].r]-RKM[T[x].r]);
 const used=()=>Object.keys(pick.w).length+Object.keys(pick.a).length;
 const chips=(T,o,k)=>cand(T,o).map(id=>`<button class="cy${pick[k][id]?' on':''}" data-k="${k}" data-i="${id}" style="--c:${T[id].col}">${esc(T[id].n)}<small>${T[id].r}</small></button>`).join('')||'<i>Nothing to carry yet.</i>';
 const draw=()=>{const wcard=$('cw'),acard=$('ca');wcard.innerHTML=chips(WP,'own','w');acard.innerHTML=chips(AR,'ownA','a');$('cn').textContent=`${used()} / ${slots}`;$('pgc').textContent=armed?'Click again to confirm':`Prestige to ${PRN[nx-1]}`;
  ov.querySelectorAll('.cy').forEach(el=>el.onclick=()=>{const k=el.dataset.k,i=el.dataset.i;if(pick[k][i])delete pick[k][i];else if(used()<slots)pick[k][i]=1;armed=false;draw()})};
 show(`<h2>Prestige ${PRN[nx-1]}</h2><div class="pcols"><div class="pcol"><canvas id="pv" width="330" height="420"></canvas><b style="color:${A.col};font:26px 'Pirata One',serif">${esc(A.n)}</b><small>${esc(A.d)}</small><canvas id="pbg" width="150" height="150"></canvas></div>
 <div class="pcol wide"><div class="pbox"><b>Perks at Prestige ${PRN[nx-1]}</b><div class="pperk">${perkLines(nx).map(x=>`<span>${x}</span>`).join('')}</div></div>
 <div class="pbox"><b>Resets</b><small>Player level and XP, skill tree, campaign progress and stars, and your weapons and armor except carried ones.</small><b>Kept</b><small>Up to 25 of your bonus skill points from trophies and the calendar (${P.spb||0} now, ${Math.min(25,P.spb||0)} after), gold, crates, trophies, catalog progress, Prestige armors, casino and settings.</small></div>
 <div class="pbox"><b>Carry over <span id="cn"></span></b><small>Choose which items come with you into the next run of the climb. Legendary gear can be carried from Prestige ${PRN[CARRY_LEG-1]}, and Mythic gear from Prestige ${PRN[CARRY_MYTH-1]}.${(()=>{const n=base(WP,'own').concat(base(AR,'ownA')).length-cand(WP,'own').length-cand(AR,'ownA').length;return n?` <b>${n} of your items are too rare to carry yet.</b>`:''})()}</small><div class="cyh">Weapons</div><div class="cyg" id="cw"></div><div class="cyh">Armor</div><div class="cyg" id="ca"></div></div></div></div>
 <div class="row"><button class="rl" id="pgc"></button><button class="sm" id="b">Back</button></div>`,'m');
 S.back=back;$('b').onclick=back;draw();
 live('pv',c=>heroView(c,{arm:'pr'+nx,wp:P.weapon,scale:2.6}));live('pbg',c=>{const g=c.getContext('2d');return t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,c.width,c.height);prBadge(g,75,82,.86,nx,t)}});
 $('pgc').onclick=()=>{if(!armed){armed=true;draw();return}doPrestige(pick,back)}}
function doPrestige(pick,back){if(!canPres())return;try{sgSnap('Before prestige','safe')}catch(e){}const nx=++P.pres,keepW=Object.keys(pick.w),keepA=Object.keys(pick.a),wOld=P.weapon;
 const spOld=P.spb||0;P.spb=Math.min(25,spOld);P.xp=0;P.camp=1;P.stars={};P.upg={};P.us=0;P.wsel={};P.path='knight';
 const ow={rusty:1};for(const k of keepW)if(WP[k])ow[k]=1;P.own=ow;
 const oa={rags:1};for(const k of keepA)if(AR[k])oa[k]=1;for(let i=1;i<=nx;i++)oa['pr'+i]=1;P.ownA=oa;
 P.armor='pr'+nx;P.weapon=ow[wOld]?wOld:'rusty';if(WP[P.weapon].p!=='knight')P.weapon='rusty';syncPaths();save();
 const A=AR['pr'+nx];
 show(`<h2>Prestige ${PRN[nx-1]}!</h2><div class="pcols"><div class="pcol"><canvas id="pv" width="330" height="420"></canvas></div><div class="pcol wide" style="align-items:center;text-align:center"><canvas id="pbg" width="200" height="200"></canvas><p>You are now <b style="color:var(--gold)">${PNAME[nx-1]}</b>, level 1 once more.<br>You begin every run in <b style="color:${A.col}">${esc(A.n)}</b>.</p><div class="pperk">${perkLines(nx).map(x=>`<span>${x}</span>`).join('')}</div><p style="opacity:.75;color:#ffd76a">Weapon masteries are never reset.</p><p style="opacity:.75">Carried over: ${keepW.length+keepA.length} item${keepW.length+keepA.length===1?'':'s'} and ${P.spb} bonus skill point${P.spb===1?'':'s'} (${spOld>25?'capped at 25 of '+spOld:'all of them'}).</p></div></div><div class="row"><button id="pgd">Begin the ascent</button></div>`,'m');
 live('pv',c=>heroView(c,{arm:P.armor,wp:P.weapon,scale:2.6}));live('pbg',c=>{const g=c.getContext('2d');return t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,c.width,c.height);prBadge(g,100,108,1.15,nx,t)}});
 try{jingle('win')}catch(e){}setTimeout(achCheck,30);$('pgd').onclick=title}
