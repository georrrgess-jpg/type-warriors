/* ===== 10.7 THE CROOKED CUE: The Gilded Hoard, the hub and the way in (97be) =====
   The way in: a gold vault-key button in the top bar of both the tavern hub and the Orbit 8 hub (pzdKey), locked until you beat
   Mortimer or Empress Vantara (it says so), NEW until your first visit; V works as a key. Beating either one the first time puts a
   NEW VENUE card on the results. P.pz.venue = 'hoard' is remembered, so the casino tile, "The bar" on the results, the side screens and
   a finished Hoard match all come back here (pzHub is wrapped; pzdHub opens when the venue is 'hoard'). From the Hoard, Esc / the back
   button goes down to the tavern and an Orbit 8 pass (O) flies to Orbit 8.
   The Hoard hub (pzdHub) mirrors the 9.7 / Orbit 8 hub so every key, test hook and the stake logic carry over (#pzh, .pzrow
   medallions, #pzopp, #pz97bar, #pzrackem, #pzprac, .pznav); its stake chips go up to 10,000 and its pay up to 50,000 because
   pzHubOpp is re-declared below with the room's limits (pzdStakeCap / pzdCap; otherwise the 9.7 body unchanged).
   Its own look: the far wall of the vault with a giant open round vault door full of gold, carved walnut and a gold frieze,
   coin mountains, gem lanterns, a gold-chain chandelier over the table, a crimson rug with gold border on black marble, the table in
   perspective (ebony, gold rails, ruby pockets, the crimson felt), gold medallions round the table (Clasp, Zephyra, Brassknuckle,
   Hornsby, then Aurelion in the champion's seat), Clasp guarding his treasure chest at the bottom left and the high rollers' lounge
   at the bottom right. Per frame: two slow LIVE canvases (glints on the gold, the foreground). Results, The Regulars and the
   spotlight are wrapped to show the Hoard players with vault backdrops. */
const PZD_SLOT={clasp:[418,500,120],zephyra:[440,262,120],brass:[926,262,120],hornsby:[930,500,120],aurelion:[682,546,128]};
const PZD_HUB={bg:null,tb:null,cone:null,port:{},stage:{},ico:{}};
/* ---------- the stake card with this room's limits (the 9.7 pzHubOpp, cap per room) ---------- */
function pzHubOpp(){const id=PZ.sel,R=PZ_REG[id],Z=PZS(),el=$('pzopp');if(!el||!R)return;const hustler=id==='shade',cap=pzdStakeCap(id);
 if(hustler&&!PZ.shadeStake)PZ.shadeStake=Math.min(cap,Math.max(500,Math.min(P.gold,1000)));
 const stake=hustler?PZ.shadeStake:pzStakeOf(id),mult=pzMultS(id,stake),wise=Z.rep[id]||0,paid=Z.dayN<PZ_DAILY;
 const list=hustler?[500,1000,2000,3000,5000].filter(s=>s<=cap):R.stakes.filter(s=>s<=cap),lo=list.length?Math.min(...list):0,poor=P.gold<lo;
 const cue=hustler?PZ_CUES.find(c=>c.beatShade):PZ_CUES.find(c=>c.beat===id),cn=hustler?(Z.shade.beat||0):(Z.beat[id]||0),have=cue&&Z.cues[cue.id];
 const vs=pzVs()[id]||[0,0],win=Math.round(stake*mult),fm=x=>x.toFixed(2).replace(/0$/,'').replace(/\.0$/,'');
 const sw=PZ.oppSwap,newFace=sw!==0||PZ.oppFace!==id;PZ.oppSwap=0;PZ.oppFace=id;
 const wiseShow=wise&&paid&&!poor,full=Math.min(R.mult,Math.floor(pzdCap(id)/Math.max(1,stake)*100)/100),free=poor||!paid||!!Z.live;
 const a=R.ai,mtr=hustler?null:[['Aim',1+(3-a.sig)/2.1*4],['Position',1+a.pos*5],['Safety',1+a.safe*9],['Planning',a.look*.62]];
 const kk=s=>s>=1000?(s/1000)+'K':s;
 el.innerHTML=`<div class="pzo9 ${sw?(sw>0?'swd':'swu'):''}"><div class="pzstage"><canvas class="pzstbg" width="214" height="496"></canvas><canvas id="pzoppc" width="214" height="392"></canvas><div class="pzbub ${newFace?'pop':''}">“${R.lines.hi[0]}”</div></div>
  <div class="pzoppi"><div class="pzh3" style="color:${R.c}">${R.n}</div><div class="pzsub2"${R.k.length>20?' style="font-size:12px"':''}>${R.k}${R.lvl?` <span class="pzstars">${pzStars(R.lvl)}</span>`:' <span class="pz97tn">TONIGHT ONLY</span>'}</div>
   <div class="pzfacts"><div><b>${R.race}</b><small>${R.race>1?'RACKS TO WIN':'RACK WINS IT'}</small></div><div class="g"><b>${wiseShow&&full>mult?`<s>×${fm(full)}</s>`:''}×${fm(mult)}</b><small>${wiseShow?'WISE TO YOU':'PAYS'}</small></div><div><b>${vs[0]||vs[1]||!cn?`${vs[0]}-${vs[1]}`:`${cn}W`}</b><small>YOUR RECORD</small></div></div>
   <div class="pzhrc pz97hr"><canvas width="44" height="44" data-ico="rules"></canvas><div><b>House rule</b><span>${PZ97_HOUSE[id]||R.houseTxt}</span></div><button class="pz97info" aria-label="House rule details">i</button><div class="pz97tip"><b>${R.houseTxt}</b>${PZ_TIPS[id]?`<em>${PZ_TIPS[id]}</em>`:''}</div></div>
   ${mtr?`<div class="pzmtr">${mtr.map(([n,x])=>{const k=Math.max(1,Math.min(5,Math.round(x)));return `<div><span>${n}</span><i>${'<u class="on"></u>'.repeat(k)}${'<u></u>'.repeat(5-k)}</i></div>`}).join('')}</div>`:'<div class="pzmtr shd">Bets small, wins big, shows up when he likes. Beat him three times for the Shadow Cue.</div>'}
   <div class="pz97stk"><small>STAKE</small><div class="pz97cc ${list.length>4?'many':''}">${list.map(s=>`<button class="pz97c ${s===stake&&!free?'on':''}" data-s="${s}" ${s>P.gold?'disabled':''} style="--cc:${PZ_CHIPC[s]||'#6a5ab0'};--ct:${s===50?'#2a1a3a':s===1000?'#ffd45a':'#fff'}" aria-label="Stake ${s}"><i></i><b>${kk(s)}</b></button>`).join('')}</div></div>
   <div class="pzpay9">${poor?`<span class="warn">You need ${cmn(lo)} gold to play for stakes. Practice is free.</span>`:!paid?`<span class="warn">Daily paid matches used: this one is a friendly.</span>`:`Win pays <b id="pzpayv">${cmn(PZ.payShown!=null&&!newFace?PZ.payShown:win)}</b><em>+${cmn(win-stake)} profit</em>`}</div>
   ${cue?`<div class="pzrew ${have?'have':''}"><canvas id="pzrewc" width="180" height="30"></canvas><div><b>${cue.n}</b><span>${have?'Yours':`${Math.min(cn,3)} / 3 wins`}</span></div><em><i style="transform:scaleX(${have?1:Math.min(cn,3)/3})"></i></em></div>`:''}</div></div>`;
 el.style.setProperty('--c',R.c);
 {const h=el.querySelector('.pzh3');let fs=40;h.style.fontSize=fs+'px';while(h.scrollWidth>h.clientWidth+1&&fs>26){fs-=2;h.style.fontSize=fs+'px'}}
 el.querySelector('.pzstbg').getContext('2d').drawImage(pz97Stage(R.c),0,0);el.querySelectorAll('canvas[data-ico]').forEach(cv=>cv.getContext('2d').drawImage(pzIco(cv.dataset.ico,44),0,0));
 const cv=$('pzoppc'),g=cv.getContext('2d');g.lineJoin='round';g.lineCap='round';const ex=Object.assign(pzCastEx(),PZ_EXP[newFace?'happy':'neutral']),fit=(()=>{const b=pzMonBox(id);return pzMonFit(id,214,372,10,Math.max(1.1,Math.min(1.6,(b.x1-b.x0)/300)))})(),t0=performance.now()/1000;let calm=!newFace;
 const f=()=>{if(!cv.isConnected)return;const t=performance.now()/1000,ht=t-t0,hy=newFace&&ht<.55?-Math.sin(ht/.55*Math.PI)*22:0;if(ht>1.2&&!calm){Object.assign(ex,PZ_EXP.neutral);calm=true}
  g.clearRect(0,0,214,392);g.save();g.translate(fit.x,fit.y+hy+16);g.scale(fit.s,fit.s);pzMon[id](g,t,ex,{breath:Math.sin(t*2.2)*.012,tilt:Math.sin(t*.8)*.025,bob:Math.sin(t*1.7)*1.4,hop:0});g.restore()};f();LIVE.push({cv,fn:f,slow:1,ph:1});
 {const rc=$('pzrewc');if(rc&&cue){try{pzRackThumb(rc.getContext('2d'),'cues',cue,180,30)}catch(e){}}}
 el.querySelectorAll('.pz97c').forEach(b=>b.onclick=()=>{if(b.disabled)return;pzHubStake(+b.dataset.s)});
 /* the payout rolls to its new value (card and bar) */
 const roll=(node,to,fmt)=>{if(!node)return;const from=+(node.dataset.v||to);node.dataset.v=to;if(from===to||newFace||pzRM()){node.textContent=fmt(to);return}const t1=performance.now(),stp=()=>{if(!node.isConnected)return;const u=Math.min(1,(performance.now()-t1)/320),e=1-Math.pow(1-u,3);node.textContent=fmt(Math.round(from+(to-from)*e));if(u<1)requestAnimationFrame(stp)};node.textContent=fmt(from);requestAnimationFrame(stp)};
 {const pv=$('pzpayv');if(pv){pv.dataset.v=PZ.payShown!=null&&!newFace?PZ.payShown:win;roll(pv,win,cmn)}PZ.payShown=paid&&!poor?win:null}
 /* the stake bar */
 const chips=$('pz97chips');if(chips){const prev=+(chips.dataset.s||0);chips.className='pz97chips'+(list.length>4?' many':'')+(free?' off':'');
  chips.innerHTML=list.map((s,i)=>`<button class="pzchip2 pz97ch ${s===stake&&!free?'on':''} ${s===stake&&!free&&prev&&prev!==s?'pop':''}" data-s="${s}" ${s>P.gold||Z.live?'disabled':''} style="--cc:${PZ_CHIPC[s]||'#6a5ab0'};--ct:${s===50?'#2a1a3a':s===1000?'#ffd45a':'#fff'};--j:${i}" aria-label="Stake ${s}"><s class="pz97pill"></s><u></u><i></i><b>${cmn(s)}</b></button>`).join('');chips.dataset.s=stake;
  chips.querySelectorAll('.pz97ch').forEach(b=>b.onclick=()=>{if(b.disabled)return;pzHubStake(+b.dataset.s)})}
 const ret=$('pz97ret'),net=$('pz97net'),mx=$('pz97mx'),nx=$('pz97nx');
 if(ret){if(free){ret.dataset.v='';ret.textContent='—';net.dataset.v='';net.textContent=Z.live?'—':'Free';mx.textContent=Z.live?'match in progress':poor?`need ${cmn(lo)} gold`:'daily limit reached';nx.textContent=Z.live?'':'no stake'}
  else{roll(ret,win,cmn);roll(net,win-stake,v=>(v<0?'−':'+')+cmn(Math.abs(v)));mx.textContent=`(×${fm(mult)})`;nx.textContent=''}}
 const rb=$('pzrackem');if(rb){const p1=$('pz97p1'),p2=$('pz97p2');p1.textContent=Z.live?'Resume':poor?'Free game':!paid?'Friendly':'Play';
  p2.textContent=Z.live?`vs ${pzShort(Z.live.opp)} ${Z.live.score[0]}-${Z.live.score[1]}`:poor||!paid?`vs ${pzShort(hustler?'gloop':id)}`:`${cmn(stake)} coins`;rb.classList.toggle('alt',free);
  const pt=$('pz97pt');let fs=44;pt.style.fontSize=fs+'px';while(pt.offsetWidth>300&&fs>28){fs-=2;pt.style.fontSize=fs+'px'}}
 const ps=$('pzpracs');if(ps)ps.textContent=`free vs ${pzShort(hustler?'gloop':id)}`}
/* ---------- icons ---------- */
function pzdIco(kind,S){const key=kind+S;if(PZD_HUB.ico[key])return PZD_HUB.ico[key];const c=pzCv(S,S),g=c.getContext('2d');g.scale(S/120,S/120);g.lineJoin='round';g.lineCap='round';
 if(kind==='key'){pzGlow(g,60,60,58,'rgba(255,200,90,1)',.35);g.save();g.translate(60,60);g.rotate(-.7);
  g.fillStyle=pzdGoldG(g,-50,-20,50,20);/* the bow: a ring with a gem */g.beginPath();g.arc(-30,0,24,0,TAU);g.arc(-30,0,11,0,TAU,true);g.fill('evenodd');g.strokeStyle=PZ_O;g.lineWidth=4.5;g.beginPath();g.arc(-30,0,24,0,TAU);g.stroke();g.beginPath();g.arc(-30,0,11,0,TAU);g.stroke();
  for(let i=0;i<6;i++){const a=i/6*TAU;pzEll(g,'#fff2b0',-30+Math.cos(a)*18,Math.sin(a)*18,2.6,2.6,0,0)}
  g.fillStyle=pzdGoldG(g,0,-8,0,8);pzRR(g,-8,-6,62,12,4);g.fill();g.strokeStyle=PZ_O;g.lineWidth=4;g.stroke();
  g.beginPath();g.moveTo(34,4);g.lineTo(34,20);g.lineTo(42,20);g.lineTo(42,12);g.lineTo(48,12);g.lineTo(48,4);g.closePath();g.fill();g.stroke();g.fillRect(20,5,8,10);g.strokeRect(20,5,8,10);
  pzdGem(g,-30,0,7.5,'ruby',2.2);g.fillStyle='rgba(255,255,240,.7)';g.fillRect(-4,-4,48,3);g.restore()}
 else if(kind==='coin'){pzGlow(g,60,60,58,'rgba(255,200,90,1)',.4);g.fillStyle='#8a5a0e';g.beginPath();g.arc(60,64,44,0,TAU);g.fill();g.fillStyle=pzdGoldG(g,16,16,104,104);g.beginPath();g.arc(60,60,44,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=5;g.stroke();
  g.strokeStyle='rgba(122,74,10,.85)';g.lineWidth=3;g.beginPath();g.arc(60,60,35,0,TAU);g.stroke();for(let i=0;i<24;i++){const a=i/24*TAU;g.fillStyle='rgba(122,74,10,.7)';g.beginPath();g.arc(60+Math.cos(a)*40,60+Math.sin(a)*40,1.6,0,TAU);g.fill()}
  /* a dragon's eye */g.fillStyle='#fff4c8';g.beginPath();g.moveTo(32,60);g.quadraticCurveTo(60,36,88,60);g.quadraticCurveTo(60,84,32,60);g.closePath();g.fill();g.strokeStyle=PZ_O;g.lineWidth=4;g.stroke();
  g.fillStyle=pzLin(g,0,44,0,76,[[0,'#ff8a3a'],[1,'#c8102e']]);g.beginPath();g.arc(60,60,14,0,TAU);g.fill();g.stroke();g.fillStyle='#12081f';g.beginPath();g.ellipse(60,60,3.6,12,0,0,TAU);g.fill();g.fillStyle='rgba(255,255,255,.85)';g.beginPath();g.arc(55,54,3.4,0,TAU);g.fill();
  g.fillStyle='rgba(255,255,240,.55)';g.beginPath();g.ellipse(42,36,14,6,-.6,0,TAU);g.fill()}
 else if(kind==='orbit'){g.drawImage(pznIco('planet',120),0,0)}
 else if(kind==='tavern'){g.drawImage(pznIco('mug',120),0,0)}
 return PZD_HUB.ico[key]=c}
/* ---------- the hub background ---------- */
function pzdHubBg(){if(PZD_HUB.bg)return PZD_HUB.bg;const c=pzCv(1600,900),g=c.getContext('2d');g.lineJoin='round';g.lineCap='round';g.fillStyle='#160806';g.fillRect(0,0,1600,900);
 /* coffered ceiling and the gold frieze */
 g.fillStyle=pzLin(g,0,0,0,104,[[0,'#120503'],[1,'#261006']]);g.fillRect(0,0,1600,104);
 for(let x=0;x<1600;x+=100){g.fillStyle=pzLin(g,x,0,x,96,[[0,'#1c0904'],[1,'#301508']]);g.fillRect(x+8,6,84,86);g.strokeStyle='rgba(0,0,0,.6)';g.lineWidth=4;g.strokeRect(x+8,6,84,86);g.strokeStyle='rgba(232,176,64,.32)';g.lineWidth=1.5;g.strokeRect(x+15,13,70,72);pzEll(g,'#c8901e',x+50,49,6,6,0,2)}
 g.fillStyle=pzdGoldG(g,0,98,0,122);g.fillRect(0,98,1600,22);g.strokeStyle=PZ_O;g.lineWidth=3;g.beginPath();g.moveTo(0,98);g.lineTo(1600,98);g.moveTo(0,120);g.lineTo(1600,120);g.stroke();
 for(let x=0;x<1600;x+=36){g.fillStyle='#7a4a0a';g.beginPath();g.moveTo(x+18,102);g.lineTo(x+25,109);g.lineTo(x+18,116);g.lineTo(x+11,109);g.closePath();g.fill();g.fillStyle='#fff2b0';g.beginPath();g.arc(x,109,2,0,TAU);g.fill()}
 /* the far wall: carved walnut panels */
 const wy0=120,wy1=362;g.fillStyle=pzLin(g,0,wy0,0,wy1,[[0,'#2c1208'],[1,'#1c0a04']]);g.fillRect(0,wy0,1600,wy1-wy0);
 for(let x=-40;x<1640;x+=120){pzdPanel(g,x+14,wy0+18,92,wy1-wy0-40,true);g.fillStyle=pzLin(g,x-9,0,x+9,0,[[0,'#160603'],[.5,'#40200c'],[1,'#160603']]);g.fillRect(x-8,wy0,16,wy1-wy0)}
 /* the giant round vault door, open, gold light pouring out */
 {const cx=PZ97_TX,cy=232,R=128;pzGlow(g,cx,cy,R+150,'rgba(255,190,70,1)',.4);
  g.fillStyle='#0c0402';g.beginPath();g.arc(cx,cy,R+28,0,TAU);g.fill();
  g.save();g.beginPath();g.arc(cx,cy,R,0,TAU);g.clip();g.fillStyle=pzLin(g,0,cy-R,0,cy+R,[[0,'#6a3a08'],[.5,'#c88a1e'],[1,'#ffd860']]);g.fillRect(cx-R,cy-R,R*2,R*2);
   pzGlow(g,cx,cy+30,R*1.2,'rgba(255,240,170,1)',.55);
   pzdHeap(g,cx-R-20,cx+R+20,cy+R+8,cx-20,cy-20,31,{n:360,r:6.5,gems:7});pzdCrown(g,cx-24,cy-26,1,-.18);pzdGoblet(g,cx+56,cy+20,.9);
   /* the inner tunnel ring */g.strokeStyle='rgba(60,30,4,.55)';g.lineWidth=16;g.beginPath();g.arc(cx,cy,R-6,0,TAU);g.stroke();g.restore();
  g.lineWidth=26;g.strokeStyle=pzLin(g,cx-R,cy-R,cx+R,cy+R,[[0,'#fff0a8'],[.35,'#d8a030'],[.7,'#8a5a14'],[1,'#4a2a06']]);g.beginPath();g.arc(cx,cy,R+13,0,TAU);g.stroke();
  g.strokeStyle=PZ_O;g.lineWidth=4;g.beginPath();g.arc(cx,cy,R+27,0,TAU);g.stroke();g.beginPath();g.arc(cx,cy,R,0,TAU);g.stroke();
  for(let i=0;i<18;i++){const a=i/18*TAU;pzEll(g,'#ffe890',cx+Math.cos(a)*(R+13),cy+Math.sin(a)*(R+13),3.8,3.8,0,1.4)}
  /* the door itself swung open to the right, seen edge-on */
  {const dx=cx+R+64,dy=cy+4;g.fillStyle=pzLin(g,dx-40,0,dx+40,0,[[0,'#3a3440'],[.5,'#9a92a0'],[1,'#4a4250']]);g.beginPath();g.ellipse(dx,dy,44,R+6,0,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=4;g.stroke();
   g.fillStyle=pzLin(g,dx-30,0,dx+30,0,[[0,'#5a5260'],[1,'#c8c0c8']]);g.beginPath();g.ellipse(dx+8,dy,30,R-14,0,0,TAU);g.fill();g.stroke();
   for(let i=-3;i<=3;i++){g.fillStyle=pzdGoldG(g,dx-50,dy+i*30-5,dx-26,dy+i*30+5);pzRR(g,dx-50,dy+i*30-5,22,10,4);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2;g.stroke()}
   g.strokeStyle='#e8b040';g.lineWidth=5;g.beginPath();g.ellipse(dx+10,dy,14,44,0,0,TAU);g.stroke();g.strokeStyle=PZ_O;g.lineWidth=2;g.stroke();
   /* the hinge */g.fillStyle=pzdGoldG(g,cx+R+10,dy-40,cx+R+40,dy+40);pzRR(g,cx+R+14,dy-50,22,100,8);g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke()}}
 /* gem lanterns on the wall */
 for(const [x,k] of[[392,'ruby'],[1018,'emer']]){const y=172;pzGlow(g,x,y+20,80,k==='ruby'?'rgba(255,70,90,1)':'rgba(70,255,150,1)',.35);g.strokeStyle='#8a6018';g.lineWidth=3;g.beginPath();g.moveTo(x,wy0);g.lineTo(x,y-26);g.stroke();
  g.fillStyle=pzdGoldG(g,x-20,y-28,x+20,y-16);g.beginPath();g.moveTo(x-10,y-28);g.lineTo(x+10,y-28);g.lineTo(x+20,y-18);g.lineTo(x-20,y-18);g.closePath();g.fill();g.strokeStyle=PZ_O;g.lineWidth=2.5;g.stroke();
  g.fillStyle='rgba(20,8,4,.5)';g.beginPath();g.moveTo(x-17,y-18);g.lineTo(x+17,y-18);g.lineTo(x+14,y+26);g.lineTo(x-14,y+26);g.closePath();g.fill();pzdGem(g,x,y+3,13,k,2.5);
  g.strokeStyle=pzdGoldG(g,x-20,y-18,x+20,y+26);g.lineWidth=3;g.beginPath();g.moveTo(x-17,y-18);g.lineTo(x-14,y+26);g.moveTo(x+17,y-18);g.lineTo(x+14,y+26);g.stroke();g.fillStyle=pzdGoldG(g,x-18,y+24,x+18,y+32);pzRR(g,x-19,y+24,38,8,3);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2.5;g.stroke()}
 /* coin mountains against the wall on both sides */
 pzdHeap(g,250,520,wy1+6,330,236,41,{n:240,r:6.5,gems:5});pzdHeap(g,930,1110,wy1+6,1010,262,43,{n:170,r:6.5,gems:4});
 /* the skirting */
 g.fillStyle=pzLin(g,0,wy1-4,0,wy1+24,[[0,'#5a2a10'],[1,'#1c0a04']]);g.fillRect(0,wy1,1600,22);g.fillStyle=pzdGoldG(g,0,wy1-2,0,wy1+3);g.fillRect(0,wy1-2,1600,4);g.strokeStyle=PZ_O;g.lineWidth=3;g.beginPath();g.moveTo(0,wy1+22);g.lineTo(1600,wy1+22);g.stroke();
 /* black marble floor with gold inlay in perspective */
 const fy=wy1+22,vx=PZ97_TX,vy=-340,tq=(fy-vy)/(900-vy);g.fillStyle='#120806';g.fillRect(0,fy,1600,900-fy);
 for(let i=-24;i<=24;i++){const b0=vx+i*96,b1=vx+(i+1)*96,t0=vx+(b0-vx)*tq,t1=vx+(b1-vx)*tq;g.fillStyle=pzMix('#140806','#1e0e0a',pzNoise(i+51));g.beginPath();g.moveTo(t0,fy);g.lineTo(t1,fy);g.lineTo(b1,900);g.lineTo(b0,900);g.closePath();g.fill();
  g.strokeStyle=i%3===0?'rgba(232,176,64,.32)':'rgba(0,0,0,.45)';g.lineWidth=i%3===0?2.2:2;g.beginPath();g.moveTo(t0,fy);g.lineTo(b0,900);g.stroke()}
 for(let k=1;k<9;k++){const yy=fy+(900-fy)*Math.pow(k/9,1.5);g.strokeStyle='rgba(0,0,0,.4)';g.lineWidth=2;g.beginPath();g.moveTo(0,yy);g.lineTo(1600,yy);g.stroke();g.strokeStyle='rgba(232,176,64,.08)';g.beginPath();g.moveTo(0,yy+2);g.lineTo(1600,yy+2);g.stroke()}
 for(let i=0;i<50;i++){const x=pzNoise(i*4.7)*1600,y=fy+10+pzNoise(i*2.1)*500;g.strokeStyle='rgba(255,255,255,.04)';g.lineWidth=1;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+40,y+10,x+80,y-6);g.stroke()}
 g.fillStyle=pzLin(g,0,fy,0,fy+90,[[0,'rgba(8,2,0,.7)'],[1,'rgba(8,2,0,0)']]);g.fillRect(0,fy,1600,90);
 /* the crimson rug with a gold border under the table */
 {const cx=PZ97_TX,cy=470;g.fillStyle='rgba(6,0,0,.5)';g.beginPath();g.ellipse(cx,cy+8,300,98,0,0,TAU);g.fill();g.fillStyle=pzLin(g,0,cy-90,0,cy+90,[[0,'#5a0a18'],[1,'#8a1426']]);g.beginPath();g.ellipse(cx,cy,292,92,0,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();
  g.strokeStyle=pzdGoldG(g,0,cy-90,0,cy+90);g.lineWidth=6;g.beginPath();g.ellipse(cx,cy,276,85,0,0,TAU);g.stroke();g.strokeStyle='rgba(255,210,110,.45)';g.lineWidth=1.5;g.beginPath();g.ellipse(cx,cy,262,79,0,0,TAU);g.stroke();
  for(let i=0;i<40;i++){const a=i/40*TAU;g.fillStyle='rgba(255,210,110,.6)';g.beginPath();g.arc(cx+Math.cos(a)*284,cy+Math.sin(a)*88.5,1.8,0,TAU);g.fill()}
  pzGlow(g,cx,cy,300,'rgba(255,170,90,1)',.12)}
 pzGlow(g,PZ97_TX,410,330,'rgba(255,220,160,1)',.12);
 /* bottom left: Clasp's treasure chest and a heap (Clasp himself is drawn live) */
 pzdHeap(g,-30,250,930,60,770,57,{n:200,r:7.5,gems:4});
 {const x=118,y=770;g.fillStyle=pzLin(g,0,y,0,y+90,[[0,'#7a3a14'],[1,'#3a1806']]);pzRR(g,x,y,150,90,8);g.fill();g.strokeStyle=PZ_O;g.lineWidth=4;g.stroke();
  g.fillStyle=pzLin(g,0,y-44,0,y,[[0,'#9a4e1c'],[1,'#5a2a0c']]);g.beginPath();g.moveTo(x,y);g.lineTo(x,y-20);g.quadraticCurveTo(x+75,y-60,x+150,y-20);g.lineTo(x+150,y);g.closePath();g.fill();g.stroke();
  for(const bx of[x+20,x+130]){g.fillStyle=pzdGoldG(g,bx-7,y-40,bx+7,y+90);g.fillRect(bx-7,y-38,14,128);g.strokeStyle=PZ_O;g.lineWidth=2.5;g.strokeRect(bx-7,y-38,14,128)}
  g.fillStyle=pzdGoldG(g,0,y-6,0,y+6);g.fillRect(x-2,y-5,154,10);g.strokeRect(x-2,y-5,154,10);g.fillStyle=pzdGoldG(g,x+62,y-4,x+88,y+26);pzRR(g,x+62,y-4,26,30,5);g.fill();g.stroke();g.fillStyle='#12081f';g.beginPath();g.arc(x+75,y+8,4,0,TAU);g.fill();g.fillRect(x+73.5,y+8,3,9);
  for(let i=0;i<7;i++)pzdCoin(g,x+20+i*18,y-24-Math.sin(i/6*Math.PI)*18,8,.4);pzdGem(g,x+60,y-40,7,'sapph');pzdGem(g,x+100,y-36,6,'ruby')}
 /* bottom right: the high rollers' lounge (back) and its sign */
 {g.fillStyle=pzLin(g,0,760,0,840,[[0,'#8a1426'],[1,'#4a0a14']]);g.beginPath();g.moveTo(1080,840);g.quadraticCurveTo(1090,760,1180,756);g.lineTo(1560,756);g.quadraticCurveTo(1600,760,1600,800);g.lineTo(1600,840);g.closePath();g.fill();g.strokeStyle=PZ_O;g.lineWidth=4;g.stroke();
  g.strokeStyle='rgba(255,200,120,.4)';g.lineWidth=2;for(let x=1200;x<1600;x+=90){g.beginPath();g.moveTo(x,764);g.lineTo(x,836);g.stroke()}
  g.fillStyle='rgba(20,6,2,.9)';pzRR(g,1366,664,178,34,12);g.fill();g.strokeStyle='#e8b040';g.lineWidth=2.5;g.stroke();g.fillStyle='#ffe8b0';g.font='800 14px Poppins,sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillText('HIGH ROLLERS ONLY',1455,682);pzGlow(g,1455,681,90,'rgba(255,190,80,1)',.18)}
 const v=g.createRadialGradient(760,470,380,760,470,1050);v.addColorStop(0,'rgba(0,0,0,0)');v.addColorStop(1,'rgba(8,2,0,.62)');g.fillStyle=v;g.fillRect(0,0,1600,900);
 return PZD_HUB.bg=c}
/* the table in perspective, stage box x 450-994, y 320-556 (2x canvas, like pz97Table) */
function pzdHubTable(){const key=PZ_BS.set;if(PZD_HUB.tb&&PZD_HUB.tbKey===key)return PZD_HUB.tb;pzdFeltSync();const F=PZD_FELT;
 const c=pzCv(1088,472),g=c.getContext('2d');g.scale(2,2);g.translate(-450,-320);g.lineJoin='round';g.lineCap='round';const cx=PZ97_TX,tr=(y0,y1,w0,w1)=>(u,v)=>[cx+(u-.5)*(w0+(w1-w0)*v),y0+(y1-y0)*v];
 const O=tr(338,482,414,462),C=tr(351,468,382,428),Fe=tr(355,463,370,414);
 const quad=(T,a0=0,a1=1,b0=0,b1=1)=>{g.beginPath();const p=[T(a0,b0),T(a1,b0),T(a1,b1),T(a0,b1)];g.moveTo(...p[0]);for(const q of p.slice(1))g.lineTo(...q);g.closePath()};
 /* carved legs with gold bands */
 for(const u of[.06,.94]){const [x,y]=O(u,1);g.fillStyle=pzLin(g,x-12,0,x+12,0,[[0,'#1a0804'],[.5,'#4a2410'],[1,'#120604']]);pzRR(g,x-12,y+8,24,40,6);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2.5;g.stroke();g.fillStyle=pzdGoldG(g,x-13,y+20,x+13,y+26);g.fillRect(x-13,y+20,26,6);g.strokeRect(x-13,y+20,26,6);pzEll(g,'#ffd45a',x,y+50,9,4,0,2)}
 {const [ax0,ay]=O(0,1),[ax1]=O(1,1);g.fillStyle=pzLin(g,0,ay,0,ay+22,[[0,'#3a1a0a'],[.5,'#240e06'],[1,'#120604']]);g.beginPath();g.moveTo(ax0,ay);g.lineTo(ax1,ay);g.lineTo(ax1-7,ay+22);g.lineTo(ax0+7,ay+22);g.closePath();g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();
  g.strokeStyle='rgba(232,176,64,.8)';g.lineWidth=1.5;g.beginPath();for(let x=ax0+14;x<ax1-24;x+=20){g.moveTo(x,ay+15);g.bezierCurveTo(x+5,ay+7,x+10,ay+7,x+10,ay+12);g.bezierCurveTo(x+10,ay+17,x+15,ay+17,x+20,ay+12)}g.stroke();
  {const mx=(ax0+ax1)/2;g.drawImage(pzdIco('coin',40),mx-10,ay+1,20,20)}}
 quad(O);g.fillStyle=pzLin(g,0,338,0,482,[[0,'#1e0c05'],[.6,'#3a1a0a'],[1,'#4a2410']]);g.fill();g.strokeStyle=PZ_O;g.lineWidth=3.4;g.stroke();
 quad(O,.006,.994,.02,.98);g.strokeStyle=pzdGoldG(g,0,338,0,482);g.lineWidth=2.4;g.stroke();
 quad(C,-.012,1.012,-.03,1.03);g.strokeStyle='#e8b040';g.lineWidth=1.6;g.stroke();
 for(const u of[.125,.25,.375,.625,.75,.875])for(const v of[-.045,1.045]){const [x,y]=C(u,v);g.fillStyle='#ffd45a';g.beginPath();g.moveTo(x,y-2.2);g.lineTo(x+2.6,y);g.lineTo(x,y+2.2);g.lineTo(x-2.6,y);g.closePath();g.fill()}
 for(const [u,v] of[[0,0],[1,0],[0,1],[1,1]]){const [x,y]=O(u,v);g.fillStyle=pzdGoldG(g,x-10,y-10,x+10,y+10);g.beginPath();g.arc(x+(u?-8:8),y+(v?-6:6),9,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2;g.stroke()}
 quad(C);g.fillStyle=pzMix(F.c,'#000000',.25);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2;g.stroke();
 g.save();quad(Fe);g.clip();g.fillStyle=F.b;g.fillRect(450,320,560,240);g.translate(cx,404);g.scale(1,.42);const q=g.createRadialGradient(0,0,10,0,0,240);q.addColorStop(0,pzMix(F.a,'#ffffff',.2));q.addColorStop(.45,F.a);q.addColorStop(1,F.c);g.fillStyle=q;g.fillRect(-300,-300,600,600);g.restore();
 g.save();quad(Fe);g.clip();let pat=false;if(typeof pzf7Felt==='function'){try{pat=pzf7Felt(g,'hoard',Fe)}catch(e){}}if(!pat){g.strokeStyle='rgba(255,210,110,.08)';g.lineWidth=.8;for(let i=-12;i<14;i++){const [x0,y0]=Fe(i/12,0),[x1,y1]=Fe(i/12+.5,1),[x2]=Fe(i/12-.5,1);g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.moveTo(x0,y0);g.lineTo(x2,y1);g.stroke()}}
 g.fillStyle='rgba(20,0,0,.22)';g.beginPath();g.moveTo(...Fe(0,0));g.lineTo(...Fe(1,0));g.lineTo(...Fe(1,.12));g.lineTo(...Fe(0,.12));g.fill();g.restore();
 quad(Fe);g.strokeStyle='rgba(0,0,0,.45)';g.lineWidth=1.5;g.stroke();
 for(const [u,v,r] of[[0,0,10],[.5,0,9],[1,0,10],[0,1,13],[.5,1,11.5],[1,1,13]]){const [x,y]=C(u,v),k=.55+.12*v;pzGlow(g,x,y,r+10,'rgba(255,40,70,1)',.5);g.fillStyle=pzdGoldG(g,x-r,y-r,x+r,y+r);g.beginPath();g.ellipse(x,y,r+3,(r+3)*k,0,0,TAU);g.fill();g.strokeStyle='#ff3a5a';g.lineWidth=1.4;g.beginPath();g.ellipse(x,y,r+.5,(r+.5)*k,0,0,TAU);g.stroke();g.fillStyle='#0a0204';g.beginPath();g.ellipse(x,y,r-.5,(r-.5)*k,0,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=2;g.stroke()}
 const balls=[[0,.25,.52]],cols=[[1],[9,2],[10,8,3],[11,7,14,4],[5,13,15,6,12]];cols.forEach((col,ci)=>col.forEach((n,ri)=>balls.push([n,.685+ci*.037,.5+(ri-(col.length-1)/2)*.095])));
 balls.sort((a,b)=>a[2]-b[2]);for(const [n,u,v] of balls){const [x,y]=Fe(u,v),d=15+v*2,im=pz97Ball(n,9);g.fillStyle='rgba(0,0,0,.35)';g.beginPath();g.ellipse(x+2,y+d*.42,d*.5,d*.2,0,0,TAU);g.fill();if(im)g.drawImage(im,x-d/2,y-d*.62,d,d)}
 PZD_HUB.tbKey=key;return PZD_HUB.tb=c}
function pzdCone(){if(PZD_HUB.cone)return PZD_HUB.cone;const K=pzCv(320,300),k=K.getContext('2d');const q=k.createLinearGradient(0,0,0,300);q.addColorStop(0,'rgba(255,214,120,.34)');q.addColorStop(.75,'rgba(255,200,110,.1)');q.addColorStop(1,'rgba(255,200,110,0)');k.fillStyle=q;k.beginPath();k.moveTo(80,0);k.lineTo(240,0);k.lineTo(318,300);k.lineTo(2,300);k.closePath();k.fill();return PZD_HUB.cone=K}
/* the lounge's velvet chaise front, baked for the live foreground */
function pzdSofa(){if(PZD_HUB.sofa)return PZD_HUB.sofa;const c=pzCv(540,54),g=c.getContext('2d');g.lineJoin='round';
 g.fillStyle=pzLin(g,0,0,0,54,[[0,'#c8243e'],[1,'#5a0a18']]);g.beginPath();g.moveTo(10,54);g.quadraticCurveTo(14,4,80,2);g.lineTo(540,2);g.lineTo(540,54);g.closePath();g.fill();g.strokeStyle=PZ_O;g.lineWidth=4;g.stroke();
 g.strokeStyle=pzdGoldG(g,0,8,0,16);g.lineWidth=3;g.beginPath();g.moveTo(80,12);g.lineTo(540,12);g.stroke();for(let x=170;x<540;x+=130){pzEll(g,'#ffd45a',x,32,4.5,4.5,0,1.5)}return PZD_HUB.sofa=c}
/* a medallion portrait on a velvet-and-gold backdrop */
function pzdPort(id,lock){const key=id+(lock?'L':'');if(PZD_HUB.port[key])return PZD_HUB.port[key];const S=180,c=pzCv(S,S),g=c.getContext('2d'),R=PZ_REG[id];
 const q=g.createRadialGradient(S/2,S*.38,8,S/2,S*.5,S*.62);if(lock){q.addColorStop(0,'#2a1208');q.addColorStop(1,'#0c0402')}else{q.addColorStop(0,pzMix(R.c,'#8a2a1a',.45));q.addColorStop(.62,pzMix(R.c,'#3a0a0a',.72));q.addColorStop(1,'#140404')}g.fillStyle=q;g.fillRect(0,0,S,S);
 g.globalAlpha=lock?.25:.5;for(let i=0;i<14;i++)pzdCoin(g,pzNoise(i*3.1+id.length)*S,S*.55+pzNoise(i*7.3)*S*.5,6+pzNoise(i)*4,.4);g.globalAlpha=1;
 g.strokeStyle='rgba(255,210,110,.08)';g.lineWidth=1;for(let i=-6;i<12;i++){g.beginPath();g.moveTo(i*18,0);g.lineTo(i*18+S,S);g.moveTo(i*18+S,0);g.lineTo(i*18,S);g.stroke()}
 const f=pzCv(S,S),fg=f.getContext('2d');pz97Bust(fg,id,S,Object.assign(pzCastEx(),PZ_EXP[lock?'neutral':id==='aurelion'?'smug':'happy']),1.3);
 if(lock){const rim=pzCv(S,S),rg=rim.getContext('2d');rg.drawImage(f,0,0);rg.globalCompositeOperation='source-in';rg.fillStyle='#b8862a';rg.fillRect(0,0,S,S);fg.globalCompositeOperation='source-in';fg.fillStyle='#120602';fg.fillRect(0,0,S,S);fg.globalCompositeOperation='source-over';g.drawImage(rim,0,-2.5);g.drawImage(f,0,0);g.drawImage(pzIco('lock',84),S/2-42,S/2-34)}
 else g.drawImage(f,0,0);
 return PZD_HUB.port[key]=c}
/* a gold pedestal under a chandelier for the spotlight card and the results (W x H) */
function pzdStage(col,W,H){const key=col+W+'x'+H;if(PZD_HUB.stage[key])return PZD_HUB.stage[key];const c=pzCv(W,H),g=c.getContext('2d');
 g.fillStyle=pzLin(g,0,0,0,H,[[0,'#2a0c08'],[1,'#0e0402']]);g.fillRect(0,0,W,H);
 g.strokeStyle='rgba(255,210,110,.07)';g.lineWidth=1;for(let i=-12;i<20;i++){g.beginPath();g.moveTo(i*28,0);g.lineTo(i*28+H*.6,H);g.moveTo(i*28+H*.6,0);g.lineTo(i*28,H);g.stroke()}
 g.save();g.globalCompositeOperation='lighter';const cone=g.createLinearGradient(0,H-40,0,60);cone.addColorStop(0,pzRgba(col).replace(',1)',',.3)'));cone.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=cone;g.beginPath();g.moveTo(W*.18,H-34);g.lineTo(W*.82,H-34);g.lineTo(W,40);g.lineTo(0,40);g.closePath();g.fill();g.restore();
 g.globalAlpha=.6;for(let i=0;i<10;i++)pzdCoin(g,W*.1+pzNoise(i*5.1+W)*W*.8,H-26+pzNoise(i*2.2)*14,6+pzNoise(i)*3,.35);g.globalAlpha=1;
 const py=H-34;g.fillStyle='#4a2a08';g.beginPath();g.ellipse(W/2,py+8,W*.44,16,0,0,TAU);g.fill();g.strokeStyle=PZ_O;g.lineWidth=3;g.stroke();g.fillStyle=pzdGoldG(g,0,py-14,0,py+14);g.beginPath();g.ellipse(W/2,py,W*.44,14,0,0,TAU);g.fill();g.stroke();
 g.strokeStyle='#8a1426';g.lineWidth=3;g.beginPath();g.ellipse(W/2,py,W*.36,9,0,0,TAU);g.stroke();pzGlow(g,W/2,py,W*.5,pzRgba(col),.3);
 g.save();g.translate(W/2,8);g.scale(.42,.42);g.drawImage(pzdChandBake(),-210,-150);g.restore();pzGlow(g,W/2,20,50,'rgba(255,210,120,1)',.5);
 return PZD_HUB.stage[key]=c}
/* ---------- the Gilded Hoard hub ---------- */
function pzdHub(){const Z=PZS();if(!pzdVenueOpen(Z)){Z.venue='tavern';save();return pzHub()}
 const tokH=++PZ.tok;PZ.on=false;PZ.hub=true;CAS.on=true;CAS.key=null;CAS.tok++;pzCastInit(PZD_ORDER[0]);try{pzMusicOn()}catch(e){}
 Z.venue='hoard';Z.hoard.seen=(Z.hoard.seen||0)+1;save();
 if(PZ.sel&&!pzdIs(PZ.sel))PZD.prevSel=PZ.sel;
 const pick=()=>PZD_ORDER.slice().reverse().find(k=>pzdOpen(k)&&!(Z.beat[k]>0))||PZD_ORDER.filter(pzdOpen).pop()||'clasp';
 if(!pzdIs(PZ.sel)||!pzdOpen(PZ.sel))PZ.sel=pick();
 try{pzbSetup(52,Z.balls)}catch(e){}
 const beatN=PZD_ORDER.filter(k=>(Z.beat[k]||0)>0).length,nextK=PZD_ORDER.find(k=>pzdOpen(k)&&!(Z.beat[k]>0)),rm=pzRM();
 const med=(k,i)=>{const R=PZ_REG[k],[cx,cy,d]=PZD_SLOT[k],open=pzdOpen(k),n=Z.beat[k]||0,lv=Z.live&&Z.live.opp===k,next=k===nextK,prev=i>0?PZ_REG[PZD_ORDER[i-1]]:null,boss=k==='aurelion';
  const tag=lv?`<em class="pz97tag live"><i></i>LIVE ${Z.live.score[0]}-${Z.live.score[1]}</em>`:!open?`<em class="pz97tag stars">${'★'.repeat(Math.min(7,i+3))}<u>${'★'.repeat(Math.max(0,4-i))}</u></em>`:boss&&n?'<em class="pz97tag champ">♛ HOARD KEEPER</em>':next?'<em class="pz97tag nx">NEXT</em>':boss?'<em class="pz97tag boss pzdboss">BOSS</em>':'';
  const tip=!open?(prev?`Beat ${prev.n} to open this table`:'Beat Mortimer or Empress Vantara to open the vault'):`${R.n}: ${R.k}${n?` · beaten ×${n}`:''}`;
  return `<button class="pzrow pz97md ${PZ.sel===k?'sel':''} ${open?'':'lock'} ${next?'next':''} ${n?'won':''} ${lv?'live':''} ${boss?'boss':''}" data-k="${k}" ${open?'':'disabled'} title="${tip.replace(/"/g,'&quot;')}" aria-label="${tip.replace(/"/g,'&quot;')}" style="left:${cx-300-d/2}px;top:${cy-116-d/2}px;--d:${d}px;--c:${R.c};--i:${i}">
   <span class="pz97in"><span class="pz97m"><i class="pz97halo"></i><canvas width="180" height="180" data-m="${k}"></canvas>${n?'<s class="pz97ck"></s>':''}</span><b class="pz97nm">${open?PZ97_PLATE[k]:'? ? ?'}</b>${tag}</span></button>`};
 const live=Z.live?`<div class="pzresume2 pz97res" id="pzresume"><canvas width="88" height="88" data-p="${Z.live.opp}"></canvas><div><b>Match in progress</b><span>vs ${PZ_REG[Z.live.opp].n} · ${Z.live.score[0]} - ${Z.live.score[1]}${Z.live.stake&&!Z.live.practice?` · stake ${cmn(Z.live.stake)}`:' · practice'}</span></div><button id="pzrs1">Resume</button><button id="pzrs2" class="ghost">Forfeit</button></div>`:'';
 const own=pzOwnCount(),W=Z.wins||0,L=Z.losses||0,tro=pzTrophies(),troN=tro.filter(a=>P.ach&&P.ach[a.id]).length,nets=Z.net||0;
 const nav=[['tavern','#ffb04a','The Crooked Cue','down to the tavern','Esc',''],['cues','#ffd45a','Cue Rack',`${own.n} / ${own.t} owned${own.nw?` · ${own.nw} new`:''}`,'C',own.nw?`<s class="pzbdg">${own.nw} NEW</s>`:''],
  ['regs','#ff9ab0','The Regulars',`${W}W · ${L}L · ${troN} / ${tro.length} trophies`,'R',''],['rules','#c8a0ff','How to Play','rules, controls, tutorials','H','']];
 show(`<div class="pzh pzh9 pzh97 pzd8 pzin${rm?' rm':''}" id="pzh"><canvas id="pzhbg" width="1600" height="900"></canvas><canvas class="pzd8amb" width="1600" height="900"></canvas>
  <div class="pzboard pz97tab" id="pz97tab"><div class="pzd8ch"><canvas class="pzd8cone" width="320" height="300"></canvas></div><canvas class="pz97tbc" width="1088" height="472"></canvas>${PZD_ORDER.every(k=>(Z.beat[k]||0)>0)?'<div class="pz97champ pzd8cp">♛ Keeper of the Hoard</div>':''}${PZD_ORDER.map(med).join('')}</div>
  <canvas id="pzhfg" width="1600" height="900"></canvas>
  <button class="pzback" id="pzbk">‹&nbsp; Crooked Cue <kbd>Esc</kbd></button>
  <button class="pzd8o8" id="pzd8o8" aria-label="Fly to Orbit 8"><canvas width="56" height="56"></canvas><span><b>Orbit 8</b><small>zero-g lounge</small></span><kbd>O</kbd></button>
  <div class="pzgold"><i></i><b id="pzgold">${cmn(P.gold)}</b></div>
  <div class="pznet">Pool net <b class="${nets<0?'neg':''}">${nets<0?'−':'+'}${cmn(Math.abs(nets))}</b>${(Z.streak||0)>1?` · streak <b class="hot">${Z.streak}</b>`:''}</div>
  <div class="pztitle pzd8sign"><canvas class="pzd8emb" width="96" height="96"></canvas><span data-t="The Gilded Hoard">The Gilded Hoard</span></div><div class="pzprog pzd8prog"><b>${beatN}</b> of 5 beaten in the vault · <b>${Z.dayN}</b> / ${PZ_DAILY} paid matches today · top pay <b>${cmn(PZD_CAP)}</b></div>
  <nav class="pznav">${nav.map(([a,c,t,s,k,x],i)=>`<button data-a="${a}" style="--c:${c};--i:${i}"><span class="pzni"><canvas width="72" height="72" data-ico="${a==='regs'?'trophy':a}"></canvas></span><span class="pznt"><b>${t}</b><span>${s}</span></span><i class="pz97chev"></i><kbd>${k}</kbd>${x}</button>`).join('')}</nav>
  <div class="pzopp pzopp9 pz97opp" id="pzopp"></div>
  <div class="pz97bar" id="pz97bar"><div class="pz97lab">Choose your stake:</div><div class="pz97chips" id="pz97chips"></div><i class="pz97sep"></i>
   <div class="pz97num"><small>Total return</small><b id="pz97ret">0</b><em id="pz97mx"></em></div><i class="pz97sep"></i><div class="pz97num g"><small>Net profit</small><b id="pz97net">0</b><em id="pz97nx"></em></div>
   <button class="pzrackem pz97play" id="pzrackem"><span class="pz97pt" id="pz97pt"><span id="pz97p1">Play</span><i>•</i><span id="pz97p2"></span></span><kbd>Enter</kbd><i class="pzshine"></i></button>
   <button class="pzprac pz97prac" id="pzprac"><b>Practice</b><span id="pzpracs">free</span><kbd>P</kbd></button></div>${live}</div>`,'casbg pzx');
 const root=$('pzh');
 $('pzhbg').getContext('2d').drawImage(pzdHubBg(),0,0);
 root.querySelector('.pzd8cone').getContext('2d').drawImage(pzdCone(),0,0);
 root.querySelector('.pz97tbc').getContext('2d').drawImage(pzdHubTable(),0,0);
 root.querySelector('.pzd8emb').getContext('2d').drawImage(pzdIco('coin',96),0,0);root.querySelector('#pzd8o8 canvas').getContext('2d').drawImage(pzdIco('orbit',56),0,0);
 root.querySelectorAll('canvas[data-m]').forEach(cv=>{cv.getContext('2d').drawImage(pzdPort(cv.dataset.m,cv.closest('.lock')),0,0)});
 root.querySelectorAll('canvas[data-ico]').forEach(cv=>{const k=cv.dataset.ico;cv.getContext('2d').drawImage(k==='tavern'?pzdIco('tavern',72):pzIco(k,72),0,0)});
 {const cv=root.querySelector('.pzresume2 canvas');if(cv)pzCastPortrait(cv.getContext('2d'),'mon',cv.dataset.p,88,1,Object.assign(pzCastEx(),PZ_EXP.neutral))}
 /* glints on the gold (the open vault, the heaps, the chest) */
 {const cv=root.querySelector('.pzd8amb'),g=cv.getContext('2d');const gl=[[640,250],[700,212],[772,262],[730,300],[310,262],[360,300],[452,332],[990,300],[1040,330],[40,800],[160,770],[210,846],[680,186],[598,300],[956,334],[818,232]];
  const f=()=>{if(PZ.tok!==tokH||!cv.isConnected)return;const t=performance.now()/1000;g.clearRect(0,160,1100,200);g.clearRect(0,740,300,160);if(pzRM())return;
   gl.forEach(([x,y],i)=>{const a=Math.max(0,Math.sin(t*1.2+i*2.3));if(a<.55)return;const k=(a-.55)/.45;g.globalAlpha=k;g.drawImage(pzGlowS('rgba(255,240,190,1)'),x-9,y-9,18,18);g.fillStyle='#fffbe8';g.fillRect(x-.8,y-6*k,1.6,12*k);g.fillRect(x-6*k,y-.8,12*k,1.6)});g.globalAlpha=1};
  f();LIVE.push({cv,fn:f,slow:2,ph:1})}
 /* the foreground: Clasp guarding his chest, the high rollers' lounge */
 const fg=$('pzhfg').getContext('2d');fg.lineJoin='round';fg.lineCap='round';
 let lounge=[];const loungeFill=()=>{const sel=PZ.sel,met=PZD_ORDER.filter(k=>k!=='clasp'&&k!==sel&&pzdOpen(k)).sort((a,b)=>(Z.beat[b]||0)-(Z.beat[a]||0)).slice(0,3),now=performance.now()/1000;
  lounge=[1230,1360,1490].map((x,i)=>{const id=met[i];if(!id)return null;const old=lounge.find(o=>o&&o.i===i);if(old&&old.id===id)return old;const b=pzMonBox(id),s=Math.min(150/(b.x1-b.x0),190/(b.y1-b.y0));return {i,id,x:x-(b.x0+b.x1)/2*s,y:772-b.y0*s,s,ex:Object.assign(pzCastEx(),PZ_EXP[['happy','smug','happy'][i]]),ph:i*2.1,t0:old?now:0}}).filter(Boolean)};
 loungeFill();PZD.loungeFill=loungeFill;PZ97.barFill=null;
 const cb=pzMonBox('clasp'),cS=Math.min(.62,150/Math.max(60,cb.y1-cb.y0)),cEx=Object.assign(pzCastEx(),PZ_EXP.happy);
 const drawFg=()=>{if(PZ.tok!==tokH)return;const t=performance.now()/1000;fg.clearRect(1060,600,540,300);fg.clearRect(0,600,450,300);
  for(const s of lounge){const u=s.t0?Math.min(1,(t-s.t0)/.5):1,rise=u<1?(1-u)*(1-u)*90:0;fg.save();fg.translate(s.x,s.y+rise);fg.scale(s.s,s.s);pzMon[s.id](fg,t+s.ph,s.ex,{breath:Math.sin(t*2.2+s.ph)*.012,tilt:Math.sin(t*.9+s.ph)*.02,bob:0,hop:0});fg.restore()}
  fg.drawImage(pzdSofa(),1060,846);
  if(!lounge.length){fg.fillStyle='rgba(255,232,176,.85)';fg.font='700 14px Poppins,sans-serif';fg.textAlign='center';fg.fillText('Players you meet relax here',1360,800)}
  if(PZ.sel!=='clasp'){fg.save();fg.translate(350-(cb.x0+cb.x1)/2*cS,888-cb.y1*cS);fg.scale(cS,cS);pzMon.clasp(fg,t+1,cEx,{breath:Math.sin(t*2)*.012,tilt:Math.sin(t*.7)*.02,bob:0,hop:0});fg.restore()}
  else{fg.fillStyle='rgba(20,6,2,.88)';pzRR(fg,280,812,150,36,12);fg.fill();fg.strokeStyle='#e8b040';fg.lineWidth=2.5;fg.stroke();fg.fillStyle='#ffe8b0';fg.font='800 14px Poppins,sans-serif';fg.textAlign='center';fg.fillText('DOOR UNGUARDED',355,835)}};
 LIVE.push({cv:$('pzhfg'),fn:drawFg,slow:2,ph:0});drawFg();
 PZ.oppSwap=0;PZ.payShown=null;PZ.oppFace=null;pzHubOpp();
 root.querySelectorAll('.pz97md').forEach(b=>b.onclick=()=>{if(b.disabled)return;pzHubSel(b.dataset.k);try{if(PZD.loungeFill)PZD.loungeFill()}catch(e){}});
 const toTavern=()=>{pzFx('tick');Z.venue='tavern';save();PZ.sel=PZD.prevSel&&!pzdIs(PZD.prevSel)&&!pznIs(PZD.prevSel)?PZD.prevSel:null;pzGo(pzHub)};
 const toO8=()=>{pzFx('tick');Z.venue='o8';save();PZ.sel=PZD.prevSel&&pznIs(PZD.prevSel)?PZD.prevSel:null;pzGo(pzHub)};
 const go=a=>{pzFx('tick');if(a==='practice'){pzMusicOff();pzStart({opp:PZ.sel,practice:true})}else if(a==='tavern')toTavern();else if(a==='cues')pzGo(pzCueRack);else if(a==='rules')pzGo(pzRules);else if(a==='regs')pzGo(pzRegs)};
 root.querySelectorAll('.pznav button').forEach(b=>b.onclick=()=>go(b.dataset.a));$('pzprac').onclick=()=>go('practice');
 $('pzbk').onclick=toTavern;S.back=()=>$('pzbk').click();$('pzd8o8').onclick=toO8;
 $('pzrackem').onclick=()=>{if(Z.live){$('pzrs1').click();return}const sel=PZ.sel,R=PZ_REG[sel],lo=Math.min(...R.stakes.filter(s=>s<=pzdStakeCap(sel)));if(P.gold<lo){pzMusicOff();pzNote('Not enough gold for stakes, so this one is a free practice game.');pzStart({opp:sel,practice:true});return}pzMusicOff();pzStart({opp:sel,stake:pzStakeOf(sel)})};
 if(Z.live){$('pzrs1').onclick=()=>{pzStart({opp:Z.live.opp,resume:Z.live,race:Z.live.race})};$('pzrs2').onclick=function(){if(!this.dataset.sure){this.dataset.sure=1;const t=this.textContent;this.textContent=Z.live&&Z.live.stake&&!Z.live.practice?'Sure? You lose the stake':'Sure? Drop this match';setTimeout(()=>{if(this.isConnected){delete this.dataset.sure;this.textContent=t}},3200);return}const Lv=Z.live;Z.live=null;if(Lv.stake&&!Lv.practice){Z.losses++;Z.streak=0;ecSrc('pool',()=>cPay(Lv.stake,0));Z.net-=Lv.stake;const v=pzVs();v[Lv.opp]=v[Lv.opp]||[0,0];v[Lv.opp][1]++}save();
   const el=$('pzresume');el.classList.add('out');const lm=root.querySelector('.pz97md.live');if(lm){lm.classList.remove('live');const tg=lm.querySelector('.pz97tag.live');if(tg)tg.remove()}setTimeout(()=>{el.remove();pzHubOpp()},260)}}
 setTimeout(()=>{const h=$('pzh');if(h&&PZ.tok===tokH)h.classList.remove('pzin')},1500);
 pzFitTM();
 /* a short welcome the first time */
 if(!Z.tut.hoard&&!Z.live){setTimeout(()=>{if(PZ.tok!==tokH||!$('pzh')||pzCoachActive())return;try{pzCoach('hoard',[
  {title:'Welcome to the Gilded Hoard!',text:'A dragon’s vault turned high-roller room. Stakes go up to <b>10,000</b> here and a win can pay up to <b>50,000</b>. Five new players, and each one is sharper than the last.',w:440},
  {sel:()=>({x:340,y:150,w:704,h:500}),side:'right',pad:0,title:'Climb to the dragon',text:'Start with <b>Clasp</b> at the bottom left and go round clockwise. <b>Aurelion the Hoardwing</b> guards the champion’s seat. Some of them pay out a new felt the first time you beat them.',w:340},
  {sel:'#pzbk',side:'bottom',title:'The other rooms',text:'<b>Crooked Cue</b> (<kbd>Esc</kbd>) goes back down to the tavern and the <b>Orbit 8</b> pass (<kbd>O</kbd>) flies you up. The game remembers where you were.',w:340}],{kicker:'THE GILDED HOARD',last:"Let's play"})}catch(e){}},700)}}
/* the spotlight card in the Hoard: a gold pedestal, and what a first win pays (gold, and a felt from some of them) */
function pzdFeltOf(id){try{const f=PZ_FELT.find(x=>x.beat===id);return f||null}catch(e){return null}}
{const f0=pzHubOpp;pzHubOpp=function(){const r=f0.apply(this,arguments);try{const h=$('pzh');if(h&&h.classList.contains('pzd8')&&pzdIs(PZ.sel)){const id=PZ.sel,R=PZ_REG[id],Z=PZS(),el=$('pzopp');
  const st=el.querySelector('.pzstbg');if(st)st.getContext('2d').drawImage(pzdStage(R.c,214,496),0,0);
  const inf=el.querySelector('.pzoppi');if(inf&&!inf.querySelector('.pzd8rew')){const fb=!(Z.beat[id]>0)&&!((Z.first||{})[id]),boss=id==='aurelion',felt=pzdFeltOf(id),d=document.createElement('div');d.className='pzrew pzd8rew'+(fb?'':' have');
   const sub=felt?(Z.felts&&Z.felts[felt.id]?`${felt.n} felt: yours`:`+ the ${felt.n} felt`):fb?'a one-time bonus':boss?'keep the hoard':'they are wise to you';
   d.innerHTML=`<canvas width="44" height="44"></canvas><div><b>${fb?`First win: +${cmn(100*(R.lvl||1))} gold`:boss?'Keeper of the Hoard':`Beaten ×${Z.beat[id]||0}`}</b><span>${sub}</span></div>`;inf.appendChild(d);d.querySelector('canvas').getContext('2d').drawImage(pzdIco('coin',44),0,0)}}}catch(e){console.error(e)}return r}}
/* ---------- the way in: a vault key in the tavern and Orbit 8 top bars ---------- */
function pzdKey(){const h=$('pzh');if(!h||h.classList.contains('pzd8')||h.querySelector('#pzd8key'))return;const Z=PZS(),open=pzdVenueOpen(Z),nw=open&&!Z.hoard.seen;
 const b=document.createElement('button');b.id='pzd8key';b.className='pzd8key'+(open?'':' lock')+(nw?' new':'');b.setAttribute('aria-label',open?'Go to the Gilded Hoard, the high-roller room':'The Gilded Hoard: beat Mortimer or Empress Vantara for the vault key');
 b.innerHTML=`<canvas width="56" height="56"></canvas><span><b>The Gilded Hoard</b><small>${open?(nw?'new venue · high rollers':'stakes to 10,000'):'beat Mortimer or Vantara'}</small></span>${open?'<kbd>V</kbd>':'<i class="pzn8lk"></i>'}${nw?'<s class="pzbdg">NEW</s>':''}`;
 h.appendChild(b);b.querySelector('canvas').getContext('2d').drawImage(pzdIco('key',56),0,0);
 b.onclick=()=>{if(!pzdVenueOpen()){pzFx('no');b.classList.remove('shake');void b.offsetWidth;b.classList.add('shake');pzNote('Beat Mortimer at the Crooked Cue or Empress Vantara in Orbit 8 to earn the key to the Gilded Hoard.');return}pzFx('tick');const Z2=PZS();if(PZ.sel&&!pzdIs(PZ.sel))PZD.prevSel=PZ.sel;Z2.venue='hoard';save();pzGo(pzHub)}}
{const f0=pzHub;pzHub=function(){const Z=PZS();if(Z.venue==='hoard'&&pzdVenueOpen(Z))return pzdHub();if(pzdIs(PZ.sel))PZ.sel=PZD.prevSel&&!pzdIs(PZD.prevSel)?PZD.prevSel:null;if(pzdIs(PZN.prevSel))PZN.prevSel=null;
 const r=f0.apply(this,arguments);try{pzdKey()}catch(e){console.error(e)}return r}}
/* playing a Hoard player puts you in the Hoard when you come back (97b4 sets the tavern / Orbit 8 for the others) */
{const f0=pzStart;pzStart=function(o){const r=f0.apply(this,arguments);try{if(r&&o&&o.opp&&pzdIs(o.opp)){const Z=PZS();if(Z.venue!=='hoard'){Z.venue='hoard';save()}}}catch(e){}return r}}
/* V opens the vault from either hub; in the Hoard, O flies to Orbit 8 and 1-5 pick a player */
if(!window.__pzdKeys){window.__pzdKeys=1;addEventListener('keydown',e=>{try{if(e.repeat||!$('pzh')||PZ.modal||pzCoachActive()||PZ.on)return;if(document.activeElement&&/INPUT|TEXTAREA/.test(document.activeElement.tagName))return;if(e.ctrlKey||e.metaKey||e.altKey)return;
 const h=$('pzh'),inH=h.classList.contains('pzd8');if(e.key==='v'||e.key==='V'){const b=inH?null:$('pzd8key');if(b){e.preventDefault();b.click()}return}
 if(inH&&(e.key==='o'||e.key==='O')){const b=$('pzd8o8');e.preventDefault();e.stopImmediatePropagation();if(b)b.click();return}
 if(inH&&/^[1-7]$/.test(e.key)){e.preventDefault();e.stopImmediatePropagation();const k=PZD_ORDER[+e.key-1],b=k&&ov.querySelector(`.pzrow[data-k="${k}"]`);if(b&&!b.disabled)b.click()}}catch(err){}},true)}
/* ---------- results, The Regulars ---------- */
{const f0=pzMatchEnd;pzMatchEnd=function(){try{PZD.open0=PZD_ORDER.filter(k=>pzdOpen(k));PZD.vopen0=pzdVenueOpen()}catch(e){}return f0.apply(this,arguments)}}
{const f0=pzResults;pzResults=function(res){let fresh=false;try{if(res&&pzdIs(res.opp)&&!res.practice&&PZD.open0){res.opened=PZD_ORDER.find(k=>pzdOpen(k)&&!PZD.open0.includes(k))||null}fresh=!!(PZD.open0&&!PZD.vopen0&&pzdVenueOpen());PZD.open0=null}catch(e){}
 const r=f0.apply(this,arguments);try{pzdResultsFix(res,fresh)}catch(e){console.error(e)}return r}}
function pzdResultsFix(res,fresh){const root=ov.querySelector('.pzres9');if(!root)return;const Z=PZS();
 if(fresh){const u=root.querySelector('.pzuns');if(u)u.insertAdjacentHTML('afterbegin','<div class="pzun open pzd8un"><small>NEW VENUE</small><b>The Gilded Hoard</b></div>');const gl=root.querySelector('.pzgoal');if(gl)gl.textContent='Next: the key to the Gilded Hoard is waiting in the top bar. High rollers only.'}
 if(!pzdIs(res.opp))return;const R=PZ_REG[res.opp],win=res.win;root.classList.add('pzd8r');
 {const bg=$('pzrbg');if(bg)bg.getContext('2d').drawImage(pzdHubBg(),0,0)}
 {const st=root.querySelector('.pzrstage .pzstbg');if(st){const g=st.getContext('2d');g.clearRect(0,0,300,424);g.drawImage(pzdStage(win?'#a87a3a':R.c,300,424),0,0)}}
 const gl=root.querySelector('.pzgoal');if(gl&&!res.practice&&res.opened)gl.textContent=`Next: ${PZ_REG[res.opened].n} is waiting in the vault.`;else if(gl&&!res.practice){const nx=PZD_ORDER.find(k=>pzdOpen(k)&&!(Z.beat[k]>0));gl.textContent=nx?`Next: ${PZ_REG[nx].n} is still unbeaten in the Hoard.`:'You keep the Hoard. Come back and defend it.'}
 const bb=$('pzbb');if(bb)bb.innerHTML='The vault <kbd>Esc</kbd>';
 /* rematch with this room's stakes (the 9.x button filters by the 5,000 casino limit) */
 const re=$('pzre');if(re&&!res.practice){re.onclick=()=>{const k=res.opp;let stake=res.stake,prac=false;const aff=PZ_REG[k].stakes.filter(s=>s<=pzdStakeCap(k)&&s<=P.gold);if(stake>P.gold||!stake){stake=aff.length?aff[aff.length-1]:0}if(!stake){prac=true;pzNote('Not enough gold for stakes: a free practice game.')}pzMusicOff();pzStart(prac?{opp:k,practice:true}:{opp:k,stake})}}}
{const f0=pzRegs;pzRegs=function(){const r=f0.apply(this,arguments);try{pzdRegsTab()}catch(e){console.error(e)}return r}}
function pzdRegsTab(){const Z=PZS(),grid=ov.querySelector('.pzrggrid'),tabs=ov.querySelector('.pzn8tabs');if(!grid||!tabs||!pzdVenueOpen(Z))return;const root=$('pzk');
 const b=document.createElement('button');b.dataset.v='hoard';b.textContent='The Gilded Hoard';tabs.appendChild(b);let k0=null;
 const v=pzVs();const card=(k,i)=>{const R=PZ_REG[k],open=pzdOpen(k),n=Z.beat[k]||0,r=v[k]||[0,0],prev=i?PZ_REG[PZD_ORDER[i-1]]:null,fb=!n&&!((Z.first||{})[k]);
  return `<button class="pzrg pzd8rg ${open?'':'lock'} ${n?'won':''}" data-k="${k}" style="--c:${R.c};--i:${i}" ${open?'':'disabled'}><canvas width="176" height="176" data-p="${k}"></canvas>
   <b>${open?R.n:'? ? ?'}</b><small>${open?R.k:`Beat ${prev?prev.n:'Mortimer or Vantara'} to meet them`}</small>
   ${open?`<div class="pzrgr"><span><b>${r[0]}</b>W</span><span><b>${r[1]}</b>L</span><span><b>${n}</b>beaten</span></div>
   <div class="pzrgc"><span>Race to ${R.race} · pays ×${R.mult}</span><i>${'<u class="on"></u>'.repeat(Math.min(3,n))}${'<u></u>'.repeat(3-Math.min(3,n))}</i></div>
   <div class="pzrgf ${fb?'':'on'}">${fb?`first win +${cmn(100*(R.lvl||1))} gold`:k==='aurelion'?'Keeper of the Hoard':'beaten'}</div>`:''}</button>`};
 const showH=()=>{if(k0==null)k0=grid.innerHTML;tabs.querySelectorAll('button').forEach(x=>x.classList.toggle('on',x===b));root.classList.remove('pzn8k');root.classList.add('pzd8k');
  grid.innerHTML=PZD_ORDER.map(card).join('');grid.querySelectorAll('canvas[data-p]').forEach(cv=>{const k=cv.dataset.p,g=cv.getContext('2d'),lock=cv.closest('.lock');pzCastPortrait(g,'mon',k,176,1.3,Object.assign(pzCastEx(),PZ_EXP.happy));if(lock){g.globalCompositeOperation='source-in';g.fillStyle='#120602';g.fillRect(0,0,176,176);g.globalCompositeOperation='source-over'}});
  grid.querySelectorAll('.pzrg').forEach(x=>x.onclick=()=>{if(x.disabled)return;PZ.sel=x.dataset.k;const Z2=PZS();Z2.venue='hoard';save();pzFx('tick');pzGo(pzHub)});const bg=$('pzkbg');if(bg)bg.getContext('2d').drawImage(pzdHubBg(),0,0)};
 b.onclick=()=>{pzFx('tick');showH()};
 tabs.querySelectorAll('button:not([data-v=hoard])').forEach(x=>x.addEventListener('click',()=>root.classList.remove('pzd8k'),true));
 if(Z.venue==='hoard'){showH();const bk=$('pzbk');if(bk)bk.innerHTML='‹&nbsp; The Gilded Hoard'}}
{const st=document.createElement('style');st.textContent=`
.pzd8 .pzd8amb{position:absolute;left:0;top:0;width:1600px;height:900px;pointer-events:none}
.pzd8 .pzd8sign{top:6px;display:flex;align-items:center;justify-content:center;gap:12px;font-size:66px;text-shadow:none;white-space:nowrap}
.pzd8 .pzd8sign span{position:relative;background:linear-gradient(180deg,#fffbe0 8%,#ffd45a 48%,#e8a02a 70%,#ffe890);-webkit-background-clip:text;background-clip:text;color:transparent;text-shadow:none}
.pzd8 .pzd8sign span::before{content:attr(data-t);position:absolute;left:0;top:0;z-index:-1;color:#12081f;-webkit-text-stroke:9px #12081f;text-shadow:0 5px 0 #12081f}
.pzd8 .pzd8emb{width:68px;height:68px;animation:pzd8sway 6s ease-in-out infinite}
@keyframes pzd8sway{0%,100%{transform:rotate(-5deg) scale(1)}50%{transform:rotate(5deg) scale(1.04)}}
.pzd8 .pzd8prog{border-color:#b8862a}.pzd8 .pzd8prog b{color:#ffe27a}
.pzd8 .pzd8ch{position:absolute;left:262px;top:150px;width:320px;height:300px;pointer-events:none}
.pzd8 .pzd8cone{position:absolute;left:0;top:0;width:320px;height:300px;animation:pz97glow 3.4s ease-in-out infinite}
.pzh97.pzd8.pzin .pzd8ch{animation:pzd8chIn .9s .1s ease-out both}
@keyframes pzd8chIn{from{opacity:0}to{opacity:1}}
.pzh97.pzd8 .pz97m{background:linear-gradient(#1a0806,#1a0806) padding-box,linear-gradient(160deg,#fff2b0,#e8b040 45%,#8a5a14) border-box}
.pzh97.pzd8 .pz97md.lock .pz97m{background:linear-gradient(#0c0402,#0c0402) padding-box,linear-gradient(160deg,#5a3a14,#2a1406) border-box}
.pzh97.pzd8 .pz97md.next .pz97m{background:linear-gradient(#1a0806,#1a0806) padding-box,linear-gradient(160deg,#fff8d0,#ffd45a 40%,#ff9a3a) border-box}
.pzh97.pzd8 .pz97md.boss:not(.lock):not(.next) .pz97m{background:linear-gradient(#1a0806,#1a0806) padding-box,conic-gradient(from 0deg,#fff2b0,#ff5a6a,#ffd45a,#7affb4,#8ac8ff,#fff2b0) border-box}
.pzh97.pzd8 .pz97nm{background:linear-gradient(180deg,#7a1424,#3a0610);border-color:#d8a030;color:#ffe8b0}
.pzh97.pzd8 .pz97md.lock .pz97nm{border-color:#5a3a14;background:linear-gradient(180deg,#2a0c08,#140402)}
.pzh97 .pz97tag.pzdboss{background:linear-gradient(180deg,#fff2b0,#e8a02a);color:#2a1004;box-shadow:0 4px 0 #0007}
.pzd8 .pzd8cp{background:linear-gradient(180deg,#fff2b0,#e8a02a)}
.pzh97.pzd8 .pz97opp{border-color:#d8a030;background:linear-gradient(180deg,#2a0c10,#14040a)}.pzh97.pzd8 .pz97bar{border-color:#d8a030;background:linear-gradient(180deg,#3a0c14,#160408)}
.pzh97.pzd8 .pznav button{background:linear-gradient(180deg,#3a0e16,#180408);border-color:#a8782a}
.pzh97.pzd8 .pzni{background:radial-gradient(circle at 50% 40%,#8a2a1a,#2a0804 72%)}
.pzh97.pzd8 .pzback{background:linear-gradient(180deg,#3a0e16,#180408);border-color:#a8782a}
.pzh97 .pzrew.pzd8rew{gap:12px;padding:8px 12px}.pzh97 .pzd8rew canvas{width:40px;height:40px;flex:none}.pzh97 .pzd8rew div{text-align:left;min-width:0}.pzh97 .pzd8rew b{font-size:14px}.pzh97 .pzd8rew span{font-size:12px}
.pzd8key,.pzd8o8{position:absolute;left:252px;top:20px;width:272px;height:52px;box-sizing:border-box;padding:0 14px 0 6px;display:flex;align-items:center;gap:8px;border-radius:16px;background:linear-gradient(180deg,#5a1420,#24060c);border:3px solid #e8b040;color:#fff2c8;cursor:pointer;z-index:5;box-shadow:0 0 0 3px #12081f,0 8px 18px #0009;transition:transform .25s cubic-bezier(.3,1.6,.5,1);animation:pzfade .5s .3s both}
.pzd8o8{background:linear-gradient(180deg,#1a2a6a,#0a1038);border-color:#5ac8ff;color:#e8f8ff}
.pzd8key canvas,.pzd8o8 canvas{width:46px;height:46px;flex:none}.pzd8key span,.pzd8o8 span{display:flex;flex-direction:column;text-align:left;line-height:1.05;min-width:0}
.pzd8key b,.pzd8o8 b{font:400 24px/1 "Pirata One",serif;color:#ffe27a;white-space:nowrap}.pzd8o8 b{color:#bff8ff}.pzd8key small,.pzd8o8 small{font:700 11.5px Poppins,sans-serif;color:#e8c890;white-space:nowrap}.pzd8o8 small{color:#9ab8e8}
.pzd8key kbd,.pzd8o8 kbd{position:absolute;right:8px;top:6px;font-size:9.5px;opacity:.7}.pzd8key:hover,.pzd8o8:hover{transform:translateY(-3px) scale(1.02)}.pzd8key:active,.pzd8o8:active{transform:scale(.97)}
.pzd8key.new{border-color:#fff2b0}.pzd8key.new canvas{animation:pzd8wig 2.2s ease-in-out infinite}@keyframes pzd8wig{0%,100%{transform:rotate(-10deg)}50%{transform:rotate(12deg)}}.pzd8key .pzbdg{top:-12px;right:6px}
.pzd8key.lock{border-color:#5a4020;background:linear-gradient(180deg,#2a1410,#120604);cursor:default}.pzd8key.lock canvas{opacity:.4}.pzd8key.lock b{color:#a8906a}.pzd8key.lock small{color:#8a7a60}
.pzd8key.shake{animation:pzn8shake .4s}
.pzd8k .pzd8rg canvas{background:radial-gradient(circle at 50% 42%,#8a2a1a,#2a0804 70%)}
.pzd8k .pzn8tabs button.on[data-v=hoard]{background:linear-gradient(180deg,#fff2b0,#e8a02a);color:#2a1004;box-shadow:0 3px 0 #8a5a10}
.pzun.pzd8un{border-color:#e8b040}
`;document.head.appendChild(st)}
