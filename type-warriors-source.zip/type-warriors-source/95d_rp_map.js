/* ===== RUNESTONE RAMPARTS (8.8b): the maps =====
   rpGeo(map): every road as a smooth curve sampled every 4 px (G.paths[i] = {S:[{x,y,a}], len, own, ice}), a union distance dRoad(x,y),
   the river (Mossgate), and the build pads (chosen once: off the roads, clear of the HUD bands, the castle, the river, the lava lake and the
   vents, spread out by a greedy cover so every stretch of road is guarded). rpBake(map): the whole 1600x900 map baked once - ground,
   twist features (river and bridge, ice, lava lake and vents), roads, caves, scatter and the castle. rpAmbient draws the live bits. */
const RPGEO={},RPBAKE={};
RPFX.sq=.75;/* ground squash shared by the range rings, splash and frost effects and the targeting metric (dy/sq) */
const RPO='#12081f';
const RP_PADBOX={x0:70,x1:1250,y0:200,y1:728};/* pads stay inside: below the top HUD, above the bottom bar, left of the castle */
function rpSpline(pts){const o=[];const p=i=>pts[Math.max(0,Math.min(pts.length-1,i))];
 for(let i=0;i<pts.length-1;i++){const p0=p(i-1),p1=p(i),p2=p(i+1),p3=p(i+2),n=Math.max(4,Math.ceil(Math.hypot(p2[0]-p1[0],p2[1]-p1[1])/6));
  for(let k=0;k<n;k++){const t=k/n,t2=t*t,t3=t2*t;o.push([.5*((2*p1[0])+(-p0[0]+p2[0])*t+(2*p0[0]-5*p1[0]+4*p2[0]-p3[0])*t2+(-p0[0]+3*p1[0]-3*p2[0]+p3[0])*t3),
   .5*((2*p1[1])+(-p0[1]+p2[1])*t+(2*p0[1]-5*p1[1]+4*p2[1]-p3[1])*t2+(-p0[1]+3*p1[1]-3*p2[1]+p3[1])*t3)])}}
 o.push(pts[pts.length-1]);return o}
function rpSamp(pts){const sp=rpSpline(pts),S=[];let acc=0,prev=sp[0];S.push({x:prev[0],y:prev[1],a:0});
 for(let i=1;i<sp.length;i++){const c=sp[i];let d=Math.hypot(c[0]-prev[0],c[1]-prev[1]);while(d>0&&acc+d>=4){const u=(4-acc)/d,x=prev[0]+(c[0]-prev[0])*u,y=prev[1]+(c[1]-prev[1])*u;
   S.push({x,y,a:0});prev=[x,y];d=Math.hypot(c[0]-prev[0],c[1]-prev[1]);acc=0}acc+=d;prev=c}
 for(let i=0;i<S.length;i++){const a=S[Math.max(0,i-3)],b=S[Math.min(S.length-1,i+3)];S[i].a=Math.atan2(b.y-a.y,b.x-a.x)}
 return{S,len:(S.length-1)*4}}
const rpDTo=(S,x,y,st)=>{let m=1e9;for(let i=0;i<S.length;i+=st||2){const q=S[i],d=(q.x-x)*(q.x-x)+(q.y-y)*(q.y-y);if(d<m)m=d}return Math.sqrt(m)};
function rpGeo(map){if(RPGEO[map.id])return RPGEO[map.id];
 const paths=map.paths.map(rpSamp);
 /* own[i]: the sample is not a repeat of an earlier road (shared stretches are drawn and counted once) */
 paths.forEach((P,k)=>{P.own=new Uint8Array(P.S.length);for(let i=0;i<P.S.length;i++){let own=1;for(let j=0;j<k;j++)if(rpDTo(paths[j].S,P.S[i].x,P.S[i].y,1)<8){own=0;break}P.own[i]=own}
  P.ice=new Uint8Array(P.S.length);if(map.ice)for(let i=0;i<P.S.length;i++){const q=P.S[i];for(const z of map.ice){const dx=q.x-z[0],dy=(q.y-z[1])/RPFX.sq;if(dx*dx+dy*dy<z[2]*z[2])P.ice[i]=1}}});
 const U=[];for(const P of paths)for(let i=0;i<P.S.length;i+=2)if(P.own[i])U.push(P.S[i]);
 const dRoad=(x,y)=>rpDTo(U,x,y,1);
 const RV=map.river?rpSamp(map.river):null,dRiver=(x,y)=>RV?rpDTo(RV.S,x,y,2):1e9;
 const gate=paths[0].S[paths[0].S.length-1];
 const ent=[];for(const P of paths){const q=P.S[Math.min(P.S.length-1,18)];if(ent.every(e=>Math.hypot(e.x-q.x,e.y-q.y)>60))ent.push({x:q.x,y:q.y,a:q.a})}
 const lake=map.lake,inLake=(x,y,m)=>lake&&((x-lake[0])/(lake[2]+m))**2+((y-lake[1])/(lake[3]+m))**2<1;
 const B=RP_PADBOX,ok=(x,y)=>x>=B.x0&&x<=B.x1&&y>=B.y0&&y<=B.y1&&dRoad(x,y)>=80&&dRiver(x,y)>=74&&!inLake(x,y,40)&&!(map.vents||[]).some(v=>Math.hypot(v[0]-x,v[1]-y)<84)&&!ent.some(e=>Math.hypot(e.x-x,e.y-y)<120);
 /* greedy cover: each pick scores the road it reaches, counting already-guarded road less */
 const C=[];for(const P of paths)for(let i=0;i<P.S.length;i+=3)if(P.own[i]&&P.S[i].x>0&&P.S[i].x<gate.x-20)C.push(P.S[i]);
 const cand=[];for(const P of paths)for(let i=14;i<P.S.length-12;i+=6)if(P.own[i]||i%12===0)for(const sd of[-1,1])for(const off of[88,110]){const q=P.S[i],x=Math.round(q.x-Math.sin(q.a)*off*sd),y=Math.round(q.y+Math.cos(q.a)*off*sd);
  if(!ok(x,y))continue;const ids=[];for(let j=0;j<C.length;j++){const dx=C[j].x-x,dy=(C[j].y-y)/RPFX.sq;if(dx*dx+dy*dy<205*205)ids.push(j)}cand.push({x,y,ids})}
 const cov=new Float32Array(C.length),pads=[],want=map.pads||12;
 while(pads.length<want){let best=null,bs=0;for(const c of cand){if(c.used)continue;let s=0;for(const j of c.ids)s+=1/(1+1.6*cov[j]);if(s>bs){bs=s;best=c}}
  if(!best)break;best.used=1;pads.push({x:best.x,y:best.y});for(const j of best.ids)cov[j]++;
  for(const c of cand)if(!c.used&&(c.x-best.x)**2+((c.y-best.y)*1.15)**2<142*142)c.used=1}
 pads.sort((a,b)=>a.x-b.x||a.y-b.y);
 return RPGEO[map.id]={paths,S:paths[0].S,len:paths[0].len,pads,dRoad,dRiver,RV,U,gate:{x:gate.x,y:gate.y},ent,inLake}}
function rpAt(G,s,pi){const P=G.paths[pi||0]||G.paths[0],S=P.S,f=Math.max(0,Math.min(S.length-1.001,s/4)),i=f|0,u=f-i,a=S[i],b=S[Math.min(S.length-1,i+1)];return{x:a.x+(b.x-a.x)*u,y:a.y+(b.y-a.y)*u,a:a.a,ice:P.ice[i]}}
/* palettes */
const RP_PAL={
 moss:{g0:'#1d4a2c',g1:'#2c6638',g2:'#163b24',blot:['#2f6b3a','#245a30','#1a4527','#3a8044'],tree:['#1b4d2e','#256b3a','#123821'],treeHi:'#5aa85c',trunk:'#5a3a22',
  rock:'#6a6478',rockHi:'#9a94a8',edge:'#2a2236',curb:'#8a8070',dirt:'#7c6b56',dirt2:'#6a5a48',cob:['#9a8e7c','#8a7e6c','#a89c88'],chev:'rgba(255,255,255,.34)',water:'#2a6aa0',waterHi:'#8ad8ff',mote:'#d8ff8a',sky:'#0c1830'},
 frost:{g0:'#b9cde2',g1:'#e6f0f9',g2:'#a9bfd6',blot:['#d6e4f2','#bccfe2','#f2f8fd','#b2c6dc'],tree:['#1f4a4a','#2a5e5a','#163a3c'],treeHi:'#f4fbff',trunk:'#4a3a32',
  rock:'#5a6a82',rockHi:'#a8bcd4',edge:'#3a4a66',curb:'#8a9ab2',dirt:'#9aaac0',dirt2:'#8494ac',cob:['#b2c2d6','#a2b2c8','#c4d2e2'],chev:'rgba(40,60,100,.3)',water:'#4a8ac0',waterHi:'#d8f2ff',mote:'#ffffff',sky:'#1a2a4a'},
 wonder:{g0:'#2a2a6a',g1:'#3a4a8a',g2:'#22205a',blot:['#4a5aa8','#3a3a8a','#5a4ab0','#2e3a7a'],tree:['#3a2a7a','#5a3a9a','#2a5a8a'],treeHi:'#ffb8f0',trunk:'#4a3a6a',
  rock:'#6a5aa8',rockHi:'#c8b8ff',edge:'#1a1440',curb:'#8a80c8',dirt:'#6a62a8',dirt2:'#5a5298',cob:['#9a92d8','#8a82c8','#aaa2e8'],chev:'rgba(255,230,255,.4)',water:'#6a4ad0',waterHi:'#ffd8ff',mote:'#ffe8ff',sky:'#120a30'},
 ember:{g0:'#24141a',g1:'#3a2228',g2:'#1c1016',blot:['#3a2026','#2e1a20','#4a2a2a','#24141a'],tree:['#2a1a18','#3a2420','#1a100e'],treeHi:'#ff8a3a',trunk:'#2a1810',
  rock:'#4a3a42',rockHi:'#7a6070',edge:'#140a0e',curb:'#5a4248',dirt:'#5a3e3a',dirt2:'#4a3230',cob:['#6a5050','#5a4444','#7a5a56'],chev:'rgba(255,190,120,.32)',water:'#ff6a1a',waterHi:'#ffd27a',mote:'#ffb84a',sky:'#1a0a10'}};
function rpBlob(g,x,y,rx,ry,col,a){g.globalAlpha=a==null?1:a;g.fillStyle=col;g.beginPath();g.ellipse(x,y,rx,ry,0,0,TAU);g.fill();g.globalAlpha=1}
function rpTree(g,x,y,h,pal,i,kind){const C=pal.tree[i%3];g.save();g.translate(x,y);
 rpBlob(g,h*.12,4,h*.42,h*.13,'#000',.28);
 if(kind==='ember'){/* charred dead tree with glowing cracks */
  g.strokeStyle=RPO;g.lineWidth=h*.11+3;g.lineCap='round';g.beginPath();g.moveTo(0,0);g.lineTo(0,-h*.8);g.moveTo(0,-h*.45);g.lineTo(-h*.28,-h*.75);g.moveTo(0,-h*.6);g.lineTo(h*.26,-h*.9);g.moveTo(0,-h*.3);g.lineTo(h*.2,-h*.45);g.stroke();
  g.strokeStyle=C;g.lineWidth=h*.11;g.stroke();g.strokeStyle='#ff7a2a';g.lineWidth=1.6;g.globalAlpha=.7;g.beginPath();g.moveTo(-1,-h*.15);g.lineTo(1,-h*.35);g.lineTo(-1,-h*.55);g.stroke();g.globalAlpha=1;g.restore();return}
 g.fillStyle=pal.trunk;g.strokeStyle=RPO;g.lineWidth=2.4;g.beginPath();g.rect(-h*.05,-h*.16,h*.1,h*.18);g.fill();g.stroke();
 for(let k=0;k<3;k++){const ty=-h*(1-k*.22),by=-h*(.22+(2-k)*.17),w=h*(.24+k*.09);
  g.beginPath();g.moveTo(0,ty);g.quadraticCurveTo(w*.35,ty+(by-ty)*.45,w,by);g.quadraticCurveTo(0,by+h*.08,-w,by);g.quadraticCurveTo(-w*.35,ty+(by-ty)*.45,0,ty);g.closePath();
  g.fillStyle=C;g.fill();g.lineWidth=2.6;g.strokeStyle=RPO;g.stroke();
  g.save();g.clip();g.fillStyle='rgba(0,0,0,.22)';g.fillRect(0,ty,w,by-ty+10);g.fillStyle=pal.treeHi;g.globalAlpha=kind==='frost'?.95:.35;
  g.beginPath();g.moveTo(0,ty);g.quadraticCurveTo(-w*.25,ty+(by-ty)*.4,-w*.7,by-2);g.quadraticCurveTo(-w*.3,by-(by-ty)*.25,0,ty+(by-ty)*.2);g.fill();g.restore()}
 g.restore()}
/* a round leafy tree for the forest map (so Mossgate is not all pines) */
function rpOak(g,x,y,h,pal,i){g.save();g.translate(x,y);rpBlob(g,h*.1,3,h*.4,h*.12,'#000',.28);
 g.fillStyle=pal.trunk;g.strokeStyle=RPO;g.lineWidth=2.4;g.beginPath();g.moveTo(-h*.06,0);g.lineTo(-h*.04,-h*.42);g.lineTo(h*.04,-h*.42);g.lineTo(h*.07,0);g.closePath();g.fill();g.stroke();
 const C=pal.tree[(i+1)%3],cl=[[0,-h*.66,h*.3],[-h*.24,-h*.5,h*.22],[h*.24,-h*.52,h*.23],[0,-h*.44,h*.24]];
 g.beginPath();for(const [cx,cy,r] of cl){g.moveTo(cx+r,cy);g.arc(cx,cy,r,0,TAU)}g.fillStyle=C;g.fill();g.lineWidth=2.6;g.strokeStyle=RPO;g.stroke();
 g.fillStyle='rgba(0,0,0,.2)';for(const [cx,cy,r] of cl){g.beginPath();g.arc(cx+r*.25,cy+r*.2,r*.78,0,TAU);g.fill()}
 g.fillStyle=pal.treeHi;g.globalAlpha=.5;for(const [cx,cy,r] of cl){g.beginPath();g.arc(cx-r*.3,cy-r*.35,r*.42,0,TAU);g.fill()}g.globalAlpha=1;
 if(i%4===0){g.fillStyle='#ff5a6a';for(let k=0;k<4;k++){g.beginPath();g.arc(-h*.2+rnd(i+k)*h*.4,-h*.62+rnd(i*3+k)*h*.3,2.6,0,TAU);g.fill()}}
 g.restore()}
function rpRock(g,x,y,s,pal){g.save();g.translate(x,y);rpBlob(g,s*.15,s*.18,s*.62,s*.2,'#000',.3);
 g.beginPath();g.moveTo(-s*.55,s*.12);g.lineTo(-s*.42,-s*.32);g.lineTo(-s*.05,-s*.5);g.lineTo(s*.38,-s*.38);g.lineTo(s*.58,s*.05);g.lineTo(s*.3,s*.22);g.lineTo(-s*.3,s*.24);g.closePath();
 g.fillStyle=pal.rock;g.fill();g.lineWidth=2.4;g.strokeStyle=RPO;g.stroke();g.save();g.clip();g.fillStyle='rgba(0,0,0,.25)';g.fillRect(0,-s,s,s*2);
 g.fillStyle=pal.rockHi;g.globalAlpha=.55;g.beginPath();g.moveTo(-s*.42,-s*.3);g.lineTo(-s*.05,-s*.48);g.lineTo(-s*.12,-s*.18);g.closePath();g.fill();g.restore();g.restore()}
/* an ice crystal cluster (Frostfang) or an obsidian spike (Ember Crown) */
function rpShard(g,x,y,s,kind,i){g.save();g.translate(x,y);rpBlob(g,s*.1,2,s*.5,s*.14,'#000',.25);
 const sh=kind==='frost'?['#bfe9ff','#7ac8f0','#ffffff']:['#2a1a22','#140a10','#5a3a4a'];
 for(const [dx,h,w,r] of[[-s*.22,s*.7,s*.16,-.25],[s*.2,s*.55,s*.14,.3],[0,s,s*.2,0]]){g.save();g.translate(dx,0);g.rotate(r+(rnd(i)-.5)*.2);
  g.beginPath();g.moveTo(-w,0);g.lineTo(-w*.8,-h*.7);g.lineTo(0,-h);g.lineTo(w*.8,-h*.7);g.lineTo(w,0);g.closePath();g.fillStyle=sh[1];g.fill();g.lineWidth=2.4;g.strokeStyle=RPO;g.stroke();
  g.fillStyle=sh[0];g.beginPath();g.moveTo(-w*.8,-h*.05);g.lineTo(-w*.65,-h*.68);g.lineTo(0,-h*.96);g.lineTo(-w*.05,-h*.1);g.closePath();g.fill();
  if(kind==='ember'){g.strokeStyle='#ff7a2a';g.lineWidth=1.5;g.globalAlpha=.8;g.beginPath();g.moveTo(w*.3,-h*.15);g.lineTo(w*.1,-h*.45);g.lineTo(w*.32,-h*.62);g.stroke();g.globalAlpha=1}
  else{g.fillStyle=sh[2];g.globalAlpha=.8;g.fillRect(-w*.45,-h*.6,2,h*.3);g.globalAlpha=1}g.restore()}
 g.restore()}
function rpCave(g,x,y,pal,kind,flip){g.save();g.translate(x,y);if(flip)g.scale(1,1);
 g.fillStyle=pal.rock;g.strokeStyle=RPO;g.lineWidth=3;g.beginPath();g.moveTo(-70,56);g.lineTo(-60,-30);g.quadraticCurveTo(-34,-92,12,-80);g.quadraticCurveTo(60,-70,66,-10);g.lineTo(70,56);g.closePath();g.fill();g.stroke();
 g.save();g.clip();g.fillStyle='rgba(0,0,0,.25)';g.fillRect(4,-100,80,170);g.fillStyle=pal.rockHi;g.globalAlpha=.4;g.beginPath();g.moveTo(-58,-20);g.quadraticCurveTo(-34,-84,10,-76);g.lineTo(-10,-60);g.quadraticCurveTo(-40,-50,-50,0);g.closePath();g.fill();g.restore();
 g.fillStyle='#0a0612';g.beginPath();g.moveTo(-38,52);g.lineTo(-34,-12);g.quadraticCurveTo(-10,-50,20,-34);g.quadraticCurveTo(40,-18,40,52);g.closePath();g.fill();
 glow(g,0,14,64,kind==='ember'?'#ff5a1a50':kind==='frost'?'#6ad0ff38':'#9a6aff34');
 if(kind==='frost'){/* icicles and a snow cap */g.fillStyle='#f4fbff';g.strokeStyle=RPO;g.lineWidth=2;g.beginPath();g.moveTo(-62,-26);g.quadraticCurveTo(-36,-96,12,-84);g.quadraticCurveTo(62,-74,68,-14);g.quadraticCurveTo(40,-40,10,-54);g.quadraticCurveTo(-30,-56,-62,-26);g.fill();g.stroke();
  g.fillStyle='#cfefff';for(let k=0;k<6;k++){const ix=-30+k*12,iy=-26-Math.sin(k)*8;g.beginPath();g.moveTo(ix-4,iy);g.lineTo(ix,iy+12+k%3*6);g.lineTo(ix+4,iy);g.closePath();g.fill();g.stroke()}}
 else if(kind==='ember'){g.strokeStyle='#ff7a2a';g.lineWidth=2;g.globalAlpha=.85;g.beginPath();g.moveTo(-50,40);g.lineTo(-44,0);g.lineTo(-52,-24);g.moveTo(50,40);g.lineTo(56,6);g.lineTo(48,-20);g.stroke();g.globalAlpha=1;
  for(const [hx,hy,r] of[[-46,-50,-.7],[40,-60,.6]]){g.save();g.translate(hx,hy);g.rotate(r);g.fillStyle='#2a1a22';g.beginPath();g.moveTo(-8,6);g.lineTo(0,-30);g.lineTo(8,6);g.closePath();g.fill();g.stroke();g.restore()}}
 else{/* moss and vines */g.fillStyle='#3a8044';g.strokeStyle=RPO;g.lineWidth=2;g.beginPath();g.moveTo(-60,-26);g.quadraticCurveTo(-34,-94,12,-82);g.quadraticCurveTo(60,-72,66,-12);g.quadraticCurveTo(40,-50,10,-60);g.quadraticCurveTo(-30,-62,-60,-26);g.fill();g.stroke();
  g.strokeStyle='#2a6a34';g.lineWidth=2.4;for(const vx of[-26,-8,14,30]){g.beginPath();g.moveTo(vx,-44-Math.abs(vx)*.2);g.quadraticCurveTo(vx+6,-24,vx-2,-6+(vx%3)*4);g.stroke()}}
 g.restore()}
/* a lava vent crater (Ember Crown); the eruption itself is live (rpVentDraw) */
function rpVentArt(g,x,y,pal){g.save();g.translate(x,y);rpBlob(g,0,4,60,26,'#000',.35);
 for(let k=0;k<9;k++){const a=k/9*TAU,rx=Math.cos(a)*44,ry=Math.sin(a)*20;rpRock(g,rx,ry+2,16+rnd(k+x)*8,pal)}
 const q=g.createRadialGradient(0,0,2,0,0,34);q.addColorStop(0,'#ffe48a');q.addColorStop(.4,'#ff8a1a');q.addColorStop(1,'#5a1408');g.fillStyle=q;g.strokeStyle=RPO;g.lineWidth=3;g.beginPath();g.ellipse(0,0,32,15,0,0,TAU);g.fill();g.stroke();
 g.fillStyle='#3a120a';g.globalAlpha=.6;g.beginPath();g.ellipse(-8,-2,10,4,.3,0,TAU);g.fill();g.beginPath();g.ellipse(10,3,8,3,-.2,0,TAU);g.fill();g.globalAlpha=1;g.restore()}
function rpBake(map){if(RPBAKE[map.id])return RPBAKE[map.id];const G=rpGeo(map),pal=RP_PAL[map.pal],H=900,K=map.pal;
 const c=document.createElement('canvas');c.width=1600;c.height=H;const g=c.getContext('2d');g.lineJoin='round';g.lineCap='round';
 /* the castle footprint (art from 95h when present) */
 let CA=null;try{if(typeof rpCastleArt==='function')CA=rpCastleArt(map.id)}catch(e){CA=null}
 const cast=CA?{x:Math.round(G.gate.x-CA.gx),y:Math.round(G.gate.y-CA.gy),w:CA.w,h:CA.h}:{x:G.gate.x-138,y:G.gate.y-370,w:270,h:490};
 const nearCastle=(x,y)=>x>cast.x-30&&y>cast.y+40&&y<cast.y+cast.h+20;
 const wet=(x,y,m)=>G.dRiver(x,y)<(m||52)||G.inLake(x,y,m?m-40:18);
 /* ground */
 let q=g.createLinearGradient(0,0,0,H);q.addColorStop(0,pal.g1);q.addColorStop(1,pal.g0);g.fillStyle=q;g.fillRect(0,0,1600,H);
 for(let i=0;i<300;i++){const x=rnd(i*3+map.id.length)*1600,y=rnd(i*3+7)*H,r=30+rnd(i*5+1)*90;rpBlob(g,x,y,r,r*.55,pal.blot[i%4],.45)}
 if(K==='ember'){g.globalCompositeOperation='lighter';for(let i=0;i<40;i++){const x=rnd(i+400)*1600,y=rnd(i+430)*H;if(G.dRoad(x,y)<90)continue;
   g.strokeStyle='rgba(255,110,30,.45)';g.lineWidth=2.4;g.beginPath();g.moveTo(x,y);let px=x,py=y;for(let k=0;k<5;k++){px+=(rnd(i*9+k)-.5)*60;py+=(rnd(i*7+k+3)-.5)*30;g.lineTo(px,py)}g.stroke();
   glow(g,x,y,40,'#ff6a1a33')}g.globalCompositeOperation='source-over'}
 if(K==='wonder'&&typeof rpWonderGround==='function')try{rpWonderGround(g,G,H)}catch(e){console.error(e)}
 if(K==='frost')for(let i=0;i<60;i++){const x=rnd(i+300)*1600,y=rnd(i+330)*H;rpBlob(g,x,y,60+rnd(i)*80,16+rnd(i+1)*14,'#ffffff',.5)}
 for(let i=0;i<700;i++){const x=rnd(i*2+90)*1600,y=rnd(i*2+91)*H;if(G.dRoad(x,y)<44||wet(x,y))continue;g.strokeStyle=pal.blot[(i+1)%4];g.lineWidth=1.6;g.globalAlpha=.8;
  g.beginPath();g.moveTo(x,y);g.lineTo(x-2,y-6-rnd(i)*5);g.moveTo(x+3,y);g.lineTo(x+4,y-5-rnd(i+3)*5);g.stroke()}g.globalAlpha=1;
 /* twist: the river (Mossgate) */
 if(G.RV){const RS=G.RV.S,line=(w,col,a)=>{g.globalAlpha=a==null?1:a;g.beginPath();g.moveTo(RS[0].x,RS[0].y);for(let i=1;i<RS.length;i++)g.lineTo(RS[i].x,RS[i].y);g.lineWidth=w;g.strokeStyle=col;g.stroke();g.globalAlpha=1};
  line(104,'#000',.18);line(96,'#5a4a34');line(90,RPO);line(84,'#7a6a4a');line(70,'#1e5288');line(52,pal.water);line(18,'#6ac0f0',.35);
  g.strokeStyle='rgba(255,255,255,.4)';g.lineWidth=2;for(let i=4;i<RS.length-4;i+=7){const p=RS[i],o=(rnd(i)-.5)*40;g.beginPath();const x=p.x-Math.sin(p.a)*o,y=p.y+Math.cos(p.a)*o;g.moveTo(x-Math.cos(p.a)*8,y-Math.sin(p.a)*8);g.lineTo(x+Math.cos(p.a)*8,y+Math.sin(p.a)*8);g.stroke()}
  for(let i=0;i<RS.length;i+=9)for(const sd of[-1,1]){if(rnd(i*2+sd)<.45)continue;const p=RS[i],x=p.x-Math.sin(p.a)*46*sd,y=p.y+Math.cos(p.a)*46*sd;if(G.dRoad(x,y)<60)continue;
   if(rnd(i+sd*3)<.5)rpRock(g,x,y,12+rnd(i)*8,pal);else{g.strokeStyle='#4a8a3a';g.lineWidth=2.4;for(let k=-1;k<=1;k++){g.beginPath();g.moveTo(x+k*4,y);g.quadraticCurveTo(x+k*6,y-10,x+k*9,y-20-rnd(i+k)*6);g.stroke()}}}
  /* lily pads */for(let i=10;i<RS.length-10;i+=23){const p=RS[i],o=(rnd(i+5)-.5)*30,x=p.x-Math.sin(p.a)*o,y=p.y+Math.cos(p.a)*o;if(G.dRoad(x,y)<60)continue;rpBlob(g,x,y,8,4.5,'#4a9a4a');g.strokeStyle=RPO;g.lineWidth=1.2;g.beginPath();g.ellipse(x,y,8,4.5,0,0,TAU);g.stroke()}}
 /* twist: the lava lake (Ember Crown) */
 if(map.lake){const [lx,ly,rx,ry]=map.lake;rpBlob(g,lx,ly+8,rx+26,ry+20,'#000',.35);g.fillStyle='#2a1418';g.strokeStyle=RPO;g.lineWidth=3;g.beginPath();g.ellipse(lx,ly,rx+16,ry+12,0,0,TAU);g.fill();g.stroke();
  q=g.createRadialGradient(lx,ly,10,lx,ly,rx);q.addColorStop(0,'#ffe48a');q.addColorStop(.35,'#ffa030');q.addColorStop(.75,'#ff5a1a');q.addColorStop(1,'#8a1a08');
  g.fillStyle=q;g.beginPath();g.ellipse(lx,ly,rx,ry,0,0,TAU);g.fill();g.save();g.clip();
  for(let i=0;i<26;i++){const a=rnd(i+600)*TAU,rr=.25+rnd(i+640)*.72,x=lx+Math.cos(a)*rx*rr,y=ly+Math.sin(a)*ry*rr;g.fillStyle=i%3?'#7a2a0e':'#4a140a';g.globalAlpha=.55;g.beginPath();for(let k=0;k<6;k++){const aa=k/6*TAU,r2=(7+rnd(i*7+k)*9)*(1+rr*.6);k?g.lineTo(x+Math.cos(aa)*r2,y+Math.sin(aa)*r2*.55):g.moveTo(x+Math.cos(aa)*r2,y+Math.sin(aa)*r2*.55)}g.closePath();g.fill()}
  g.globalAlpha=.5;g.strokeStyle='#ffe48a';g.lineWidth=2;for(let i=0;i<9;i++){const a=rnd(i+660)*TAU,x=lx+Math.cos(a)*rx*.5,y=ly+Math.sin(a)*ry*.5;g.beginPath();g.moveTo(x-14,y);g.quadraticCurveTo(x,y-5,x+14,y);g.stroke()}
  g.globalAlpha=1;g.restore();g.strokeStyle='#ffd27a';g.lineWidth=2;g.globalAlpha=.5;g.beginPath();g.ellipse(lx,ly,rx-6,ry-5,0,Math.PI*1.1,Math.PI*1.7);g.stroke();g.globalAlpha=1;
  for(let i=0;i<22;i++){const a=i/22*TAU,x=lx+Math.cos(a)*(rx+18),y=ly+Math.sin(a)*(ry+14);if(G.dRoad(x,y)<50)continue;if(rnd(i+700)<.35)rpShard(g,x,y+6,22+rnd(i)*12,'ember',i);else rpRock(g,x,y+4,14+rnd(i+3)*10,pal)}}
 /* the roads: all edges first, then all fills, so the shared stretches and the forks merge cleanly */
 const each=f=>{for(const P of G.paths)f(P)};
 const stroke=(P,w,col)=>{const S=P.S;g.beginPath();g.moveTo(S[0].x,S[0].y);for(let i=1;i<S.length;i++)g.lineTo(S[i].x,S[i].y);g.lineWidth=w;g.strokeStyle=col;g.stroke()};
 each(P=>stroke(P,86,'rgba(0,0,0,.25)'));each(P=>stroke(P,78,pal.edge));each(P=>stroke(P,72,pal.curb));each(P=>stroke(P,60,pal.dirt));
 each(P=>{const S=P.S;for(let i=0;i<S.length;i+=3){if(!P.own[i])continue;const p=S[i];for(let k=0;k<3;k++){const off=(rnd(i*3+k)-.5)*44,x=p.x-Math.sin(p.a)*off+(rnd(i+k*7)-.5)*4,y=p.y+Math.cos(p.a)*off;
  g.fillStyle=pal.cob[(i+k)%3];g.strokeStyle='rgba(0,0,0,.22)';g.lineWidth=1.2;g.beginPath();g.ellipse(x,y,4+rnd(i*5+k)*3,3+rnd(i*7+k)*2,p.a,0,TAU);g.fill();g.stroke()}}});
 /* curb stones along both edges (skipped where another road joins) */
 each(P=>{const S=P.S;for(let i=0;i<S.length;i+=5){if(!P.own[i])continue;for(const sd of[-1,1]){const p=S[i],x=p.x-Math.sin(p.a)*35*sd,y=p.y+Math.cos(p.a)*35*sd;if(G.dRoad(x,y)<30)continue;g.fillStyle=pal.curb;g.strokeStyle=RPO;g.lineWidth=1.6;
  g.beginPath();g.ellipse(x,y,7,4.5,p.a,0,TAU);g.fill();g.stroke();g.fillStyle='rgba(255,255,255,.18)';g.beginPath();g.ellipse(x-1,y-1.5,4,1.6,p.a,0,TAU);g.fill()}}});
 /* the bridge where the road crosses the river */
 if(G.RV)each(P=>{const S=P.S,on=[];for(let i=0;i<S.length;i++)if(P.own[i]&&G.dRiver(S[i].x,S[i].y)<58)on.push(i);if(!on.length)return;
  const i0=on[0],i1=on[on.length-1];g.save();g.beginPath();g.moveTo(S[i0].x,S[i0].y);for(let i=i0+1;i<=i1;i++)g.lineTo(S[i].x,S[i].y);g.lineWidth=84;g.strokeStyle='rgba(0,0,0,.3)';g.stroke();g.lineWidth=76;g.strokeStyle=RPO;g.stroke();g.lineWidth=70;g.strokeStyle='#7a5230';g.stroke();
  for(let i=i0;i<=i1;i+=3){const p=S[i],nx=-Math.sin(p.a),ny=Math.cos(p.a),tx=Math.cos(p.a),ty=Math.sin(p.a);g.fillStyle=i%2?'#9a6a3a':'#8a5c32';g.strokeStyle='#4a2e18';g.lineWidth=1.4;
   g.beginPath();g.moveTo(p.x+nx*33-tx*5,p.y+ny*33-ty*5);g.lineTo(p.x+nx*33+tx*5,p.y+ny*33+ty*5);g.lineTo(p.x-nx*33+tx*5,p.y-ny*33+ty*5);g.lineTo(p.x-nx*33-tx*5,p.y-ny*33-ty*5);g.closePath();g.fill();g.stroke()}
  for(const sd of[-1,1]){g.beginPath();for(let i=i0;i<=i1;i++){const p=S[i],x=p.x-Math.sin(p.a)*38*sd,y=p.y+Math.cos(p.a)*38*sd-8;i===i0?g.moveTo(x,y):g.lineTo(x,y)}g.lineWidth=9;g.strokeStyle=RPO;g.stroke();g.lineWidth=5;g.strokeStyle='#b4824a';g.stroke();
   for(let i=i0;i<=i1;i+=8){const p=S[i],x=p.x-Math.sin(p.a)*38*sd,y=p.y+Math.cos(p.a)*38*sd;g.fillStyle='#6a4426';g.strokeStyle=RPO;g.lineWidth=2;g.beginPath();g.rect(x-4,y-14,8,16);g.fill();g.stroke();g.fillStyle='#ffd45a';g.beginPath();g.arc(x,y-15,2.6,0,TAU);g.fill()}}
  g.restore()});
 /* twist: ice patches on the road (Frostfang) */
 if(map.ice)for(const [x,y,r] of map.ice){g.save();q=g.createRadialGradient(x-r*.3,y-r*.3,4,x,y,r);q.addColorStop(0,'#ffffff');q.addColorStop(.5,'#cdeeff');q.addColorStop(1,'#8ac8ec');
  g.fillStyle=q;g.strokeStyle='#4a7aa8';g.lineWidth=2.4;g.beginPath();for(let k=0;k<=12;k++){const a=k/12*TAU,rr=r*(.86+rnd(k+x)*.18);k?g.lineTo(x+Math.cos(a)*rr,y+Math.sin(a)*rr*RPFX.sq):g.moveTo(x+Math.cos(a)*rr,y+Math.sin(a)*rr*RPFX.sq)}g.closePath();g.fill();g.stroke();
  g.clip();g.strokeStyle='rgba(74,122,168,.6)';g.lineWidth=1.4;for(let k=0;k<5;k++){const a=rnd(k+y)*TAU;g.beginPath();g.moveTo(x,y);g.lineTo(x+Math.cos(a)*r*.6,y+Math.sin(a)*r*.45);g.lineTo(x+Math.cos(a+.4)*r,y+Math.sin(a+.4)*r*.7);g.stroke()}
  g.fillStyle='rgba(255,255,255,.75)';g.beginPath();g.ellipse(x-r*.35,y-r*.2,r*.28,4,-.4,0,TAU);g.fill();g.restore()}
 /* chevrons pointing the way */
 g.strokeStyle=pal.chev;g.lineWidth=4;each(P=>{const S=P.S;for(let i=40;i<S.length-30;i+=34){if(!P.own[i])continue;const p=S[i];g.save();g.translate(p.x,p.y);g.rotate(p.a);g.beginPath();g.moveTo(-6,-9);g.lineTo(4,0);g.lineTo(-6,9);g.stroke();g.restore()}});
 /* twist: lava vents beside the road (Ember Crown) */
 if(map.vents)for(const v of map.vents)rpVentArt(g,v[0],v[1],pal);
 /* ground detail: clearings, flowers / snow drifts / embers, small bushes */
 for(let i=0;i<60;i++){const x=rnd(i+900)*1600,y=rnd(i+930)*H;if(G.dRoad(x,y)<70||wet(x,y,70))continue;rpBlob(g,x,y,40+rnd(i)*50,18+rnd(i+1)*20,K==='frost'?'#f2f8ff':K==='ember'?'#4a2a2a':'#3a7a40',.55)}
 for(let i=0;i<420;i++){const x=rnd(i+1000)*1600,y=rnd(i+1300)*H;if(G.dRoad(x,y)<46||wet(x,y,56))continue;const col=K==='frost'?(i%3?'#ffffff':'#bfe6ff'):K==='ember'?(i%3?'#ff7a2a':'#ffb84a'):['#ffe46a','#ffffff','#ff9ad8','#b4a0ff'][i%4];
  g.fillStyle=col;g.globalAlpha=K==='ember'?.55:.9;g.beginPath();g.arc(x,y,K==='frost'?1.6:2.2,0,TAU);g.fill()}g.globalAlpha=1;
 const padNear=(x,y,r)=>G.pads.some(p=>Math.hypot(p.x-x,(p.y-y)*1.3)<r);
 if(K==='moss')for(let i=0;i<50;i++){const x=rnd(i+1600)*1600,y=rnd(i+1650)*H;if(G.dRoad(x,y)<62||wet(x,y,70)||padNear(x,y,76)||nearCastle(x,y))continue;g.save();g.translate(x,y);
  for(const [dx,dy,r] of[[-9,0,9],[7,-2,10],[0,-8,9]]){g.fillStyle=pal.tree[1];g.strokeStyle=RPO;g.lineWidth=2;g.beginPath();g.arc(dx,dy,r,0,TAU);g.fill();g.stroke()}g.fillStyle=pal.treeHi;g.globalAlpha=.45;g.beginPath();g.arc(-4,-10,5,0,TAU);g.fill();g.globalAlpha=1;g.restore()}
 if(K==='moss')for(let i=0;i<16;i++){const x=rnd(i+1900)*1600,y=rnd(i+1950)*H;if(G.dRoad(x,y)<56||wet(x,y,64)||padNear(x,y,70))continue;/* red mushrooms */
  for(let k=0;k<2;k++){const mx=x+k*12,my=y-k*3;g.fillStyle='#f4ead8';g.strokeStyle=RPO;g.lineWidth=1.6;g.fillRect(mx-2,my-8,4,8);g.strokeRect(mx-2,my-8,4,8);g.fillStyle='#e04a4a';g.beginPath();g.ellipse(mx,my-9,7-k*2,4.5-k,0,Math.PI,0);g.closePath();g.fill();g.stroke();g.fillStyle='#fff';g.beginPath();g.arc(mx-2,my-11,1.3,0,TAU);g.fill()}}
 /* scatter: trees, rocks and crystals away from the roads, the pads, the water and the castle */
 const items=[];for(let i=0;i<1400&&items.length<230;i++){const x=rnd(i*4+11)*1660-30,y=rnd(i*4+12)*(H+40)-20,d=G.dRoad(x,y);if(d<70)continue;if(nearCastle(x,y))continue;if(wet(x,y,66))continue;
  if(padNear(x,y,84))continue;if((map.vents||[]).some(v=>Math.hypot(v[0]-x,v[1]-y)<90))continue;if(G.ent.some(e=>Math.hypot(e.x-x,e.y-y)<110))continue;
  const dense=d>190||x<40||y<60||y>H-60;if(rnd(i+5)<(dense?.2:.68))continue;const r=rnd(i*4+13);
  items.push({x,y,k:K==='moss'?(r<.42?'t':r<.86?'o':'r'):K==='frost'?(r<.7?'t':r<.86?'s':'r'):K==='wonder'?(r<.8?'w':'r'):(r<.5?'t':r<.78?'s':'r'),h:46+rnd(i*4+14)*38,i})}
 items.sort((a,b)=>a.y-b.y);for(const it of items){if(it.k==='t')rpTree(g,it.x,it.y,it.h,pal,it.i,K);else if(it.k==='o')rpOak(g,it.x,it.y,it.h*1.05,pal,it.i);else if(it.k==='s')rpShard(g,it.x,it.y,it.h*.7,K,it.i);else if(it.k==='w'){if(typeof rpWonderProp==='function')rpWonderProp(g,it.x,it.y,it.h,it.i);else rpTree(g,it.x,it.y,it.h,pal,it.i,K)}else rpRock(g,it.x,it.y,it.h*.45,pal)}
 /* the caves the monsters come from (one per entrance) */
 for(const e of G.ent){if(K==='wonder'&&typeof rpPortalArt==='function')rpPortalArt(g,Math.max(30,e.x-14),e.y);else rpCave(g,Math.max(30,e.x-14),e.y,pal,K)}
 /* the castle */
 if(CA)g.drawImage(CA.c,cast.x,cast.y,CA.w,CA.h);else g.drawImage(rpKeepArt(map,pal),cast.x,cast.y);
 return RPBAKE[map.id]={c,pal,G,trees:items,cast,id:map.id}}
/* fallback keep (used only if the castle art module is missing): gate bottom at canvas (138,370) */
function rpKeepArt(map,pal){const c=document.createElement('canvas');c.width=270;c.height=490;const g=c.getContext('2d');g.lineJoin='round';
 g.translate(-1330,-170+8);
 const st=map.pal==='frost'?['#8a9ab4','#6a7a94','#b4c4da']:map.pal==='ember'?['#5a4448','#463438','#7a5e60']:['#7a7488','#5e586c','#a49eb2'];
 const block=(x,y,w,h)=>{g.fillStyle=st[0];g.fillRect(x,y,w,h);g.fillStyle='rgba(0,0,0,.2)';g.fillRect(x+w*.62,y,w*.38,h);g.fillStyle='rgba(255,255,255,.14)';g.fillRect(x,y,w*.12,h);g.strokeStyle=RPO;g.lineWidth=3;g.strokeRect(x,y,w,h)};
 rpBlob(g,1470,640,150,26,'#000',.3);block(1400,330,180,300);block(1365,260,70,330);block(1525,240,72,360);
 for(const [x,w,y] of[[1365,70,248],[1525,72,228]]){g.fillStyle=map.pal==='ember'?'#5a1a1a':'#2a3a7a';g.strokeStyle=RPO;g.lineWidth=3;g.beginPath();g.moveTo(x-8,y);g.lineTo(x+w/2,y-74);g.lineTo(x+w+8,y);g.closePath();g.fill();g.stroke()}
 g.fillStyle='#3a2414';g.strokeStyle=RPO;g.lineWidth=3;g.beginPath();g.moveTo(1432,532);g.lineTo(1432,470);g.quadraticCurveTo(1468,424,1504,470);g.lineTo(1504,532);g.closePath();g.fill();g.stroke();
 return c}
/* a vent eruption: k 0..1 over the burst (drawn by the engine while a vent fires) */
function rpVentDraw(c,x,y,t,k){c.save();c.globalCompositeOperation='lighter';const a=k<.15?k/.15:1-(k-.15)/.85;
 glow(c,x,y-10,70+60*a,'#ff7a1a'+Math.round(40+90*a).toString(16).padStart(2,'0'));
 for(let i=0;i<7;i++){const u=(k*1.4+i/7)%1,h=u*120*a,xx=x+Math.sin(i*2.3+t*3)*14*u;c.globalAlpha=a*(1-u);c.fillStyle=i%2?'#ffd27a':'#ff8a2a';c.beginPath();c.arc(xx,y-6-h,7*(1-u)+2,0,TAU);c.fill()}
 c.globalAlpha=a*.7;c.strokeStyle='#ffb84a';c.lineWidth=4*(1-k);c.beginPath();c.ellipse(x,y,RPT.VENT_R*(.3+.7*k),RPT.VENT_R*(.3+.7*k)*RPFX.sq,0,0,TAU);c.stroke();c.restore()}
/* live ambience: river shimmer, snowfall and ice glints, lava glow and vent smoke, motes, the castle's own live bits */
function rpAmbient(c,R){const B=R.bake,pal=B.pal,t=R.t,rm=R.rm,G=R.G,K=R.map.pal;
 c.save();c.globalCompositeOperation='lighter';
 if(G.RV){const RS=G.RV.S;c.strokeStyle=pal.waterHi;c.lineWidth=2.4;for(let i=0;i<18;i++){const u=((t*.035+i/18)%1),j=Math.min(RS.length-1,(u*RS.length)|0),p=RS[j],o=(rnd(i)-.5)*34;
   c.globalAlpha=.45*Math.sin(u*Math.PI);const x=p.x-Math.sin(p.a)*o,y=p.y+Math.cos(p.a)*o;c.beginPath();c.moveTo(x-Math.cos(p.a)*10,y-Math.sin(p.a)*10);c.lineTo(x+Math.cos(p.a)*10,y+Math.sin(p.a)*10);c.stroke()}}
 if(R.map.ice){for(let i=0;i<R.map.ice.length;i++){const z=R.map.ice[i],u=(t*.6+i*.37)%1;if(u>.3)continue;const a=Math.sin(u/.3*Math.PI);c.globalAlpha=a;c.fillStyle='#ffffff';
   const x=z[0]-z[2]*.3+rnd(i+Math.floor(t*.6))*z[2]*.6,y=z[1]-z[2]*.2;c.beginPath();c.moveTo(x,y-9*a);c.lineTo(x+2,y);c.lineTo(x,y+9*a);c.lineTo(x-2,y);c.closePath();c.fill();c.fillRect(x-9*a,y-1,18*a,2)}}
 if(R.map.lake){const [lx,ly,rx]=R.map.lake;c.globalAlpha=.22+.12*Math.sin(t*1.7);glow(c,lx,ly,rx*1.25,'#ff8a2a');
  for(let i=0;i<6;i++){const u=(t*.25+i/6)%1;c.globalAlpha=.6*(1-u);c.fillStyle='#ffd27a';c.beginPath();c.arc(lx+(rnd(i)-.5)*rx*1.4,ly-u*80,2.2,0,TAU);c.fill()}}
 c.globalAlpha=1;
 if(!rm&&!R.lite){const n=K==='frost'?70:K==='ember'?36:26,H=900;for(let i=0;i<n;i++){const ph=t*.2+i*1.7,x0=rnd(i+3)*1600+Math.sin(ph)*40,y0=rnd(i+9)*H+(K==='frost'?t*34:-t*16)+i*40;
   const x=((x0%1600)+1600)%1600,y=((y0%H)+H)%H;c.globalAlpha=.35+.35*Math.sin(t*2+i);c.fillStyle=pal.mote;c.beginPath();c.arc(x,y,K==='frost'?2.4:1.8,0,TAU);c.fill()}}
 c.restore();
 if(K==='wonder'&&typeof rpWonderAmbient==='function')try{rpWonderAmbient(c,t,R)}catch(e){}
 if(typeof rpCastleLive==='function'&&B.cast)try{rpCastleLive(c,B.id,B.cast.x,B.cast.y,t)}catch(e){}}
