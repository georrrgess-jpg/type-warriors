# python3 t_td98.py [game.html] : Runestone Tower Defense 9.8 (95s, 95t) - the Thunder Mortar: registry, bar and key, targeting
# (crowds, leading, no flyers, dead zone), splash falloff, craters, cluster bomblets, the Thunder Barrage, Overcharge, upgrades and
# selling, build/ascension/icon art, the info panel, frame cost and a full Wonderland wave with mortars.
import asyncio,os,re,sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
HELP=re.search(r'HELP=r"""(.*?)"""',open(os.path.join(HERE,'t_td96.py')).read(),re.S).group(1)
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:500]),flush=True)
    if not ok:FAIL.append(name)
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E("()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const T=RPP().tut;for(const k of['build','wave','coins','upgrade','abil','twist_frost','twist_ember','twist_wonder'])T[k]=1;RPP().stars.ember=1;RPP().dragon=1}")
        await E(HELP)
        # a mortar on a pad with ground monsters placed on the road at a chosen distance; returns [R,tw,list]
        await E("""()=>{window.mtSet=(tier,dist,n,id,opt)=>{opt=opt||{};const R=tdNew('wonder',6);const pads=[...R.pads].sort((a,b)=>a.x-b.x),p=pads[opt.pad==null?3:opt.pad],tw=tdBuild(R,p,'mortar',tier);tw.cd=0;
           let best=null;R.G.paths.forEach((P2,pi)=>{for(let s=0;s<P2.len;s+=4){const q=rpAt(R.G,s,pi),d=Math.sqrt(rpD2(q.x,q.y,tw.x,tw.y));if(Math.abs(d-dist)<8&&(!best||Math.abs(d-dist)<best.e))best={s,pi,e:Math.abs(d-dist)}}});
           const F=[];if(best)for(let k=0;k<n;k++){const e=rpSpawn(id||'golem',best.pi);e.s=best.s+k*8;e.hp=e.mx=1e7;e.sp=opt.sp==null?0:opt.sp;F.push(e)}R.wst='run';R.q=[];return [R,tw,F,best]};return 1}""")
        # ---------------------------------------------------------------- registry, bar, key
        r=await E("()=>[RP_TWORDER[7],RP_KEYS[7],RPTW.mortar.n,RP_TW.mortar.cost,RP_TW.mortar.air,RPSKIN.mortar,rpTowerTop('mortar',1)>80]")
        chk('the Thunder Mortar is the eighth tower (key O, 550 supply since 9.9b, ground only)',r[:3]==['mortar','O','Thunder Mortar'] and r[3][0]==550 and r[4]==0 and r[6],r)
        r=await E("""async()=>{tdNew('moss',1);await new Promise(r=>setTimeout(r,900));const bar=document.querySelector('#rphud .rpbar'),cards=[...document.querySelectorAll('#rphud .rpcard')],wv=[...document.querySelectorAll('#rphud *')].find(x=>/THIS WAVE/i.test(x.textContent)&&x.children.length<8&&x.getBoundingClientRect().width<200);
          const bb=bar.getBoundingClientRect(),last=cards[cards.length-1].getBoundingClientRect(),ab=[...document.querySelectorAll('#rphud .rpab,#rphud [class*=ab]')].map(x=>x.getBoundingClientRect()).filter(q=>q.width>40&&q.width<200&&q.top>700);
          const w=wv?wv.getBoundingClientRect():null;return [cards.length,cards.some(c=>c.dataset.tw==='mortar'),Math.round(bb.left),Math.round(bb.right),w?Math.round(w.left):null,ab.length?Math.round(Math.max(...ab.map(q=>q.right))):null,(typeof rpwTwLocked==='function'?RP_TWORDER.filter(t=>!rpwTwLocked(t)):RP_TWORDER).length]}""")
        chk('the bar shows every open tower's tile (10 in World 1, up to 12 with the new worlds) and stays clear of the abilities and the wave panel',r[0]==r[6] and r[0]>=10 and r[1] and (r[4] is None or r[3]<=r[4]+2) and (r[5] is None or r[2]>=r[5]-2),r)
        r=await E("()=>{const R=RPX;R.place=null;window.dispatchEvent(new KeyboardEvent('keydown',{key:'o',bubbles:true}));return R.place}")
        chk('key O picks the mortar for placing',r=='mortar',r)
        # ---------------------------------------------------------------- targeting
        r=await E("""()=>{const [R,tw,F,b]=mtSet(1,230,6,'golem');let shots=0;const n0=R.mtShells.length;for(let i=0;i<60*1.6;i++){rpStep(R,1/60);shots=Math.max(shots,R.mtShells.length)}
          const dm=F.filter(e=>e.hp<e.mx).length;return [!!b,shots>=1,dm,F.length,Math.round(tw.dmg)]}""")
        chk('it fires at a ground group in range and the blast hurts the whole group',r[0] and r[1] and r[2]>=5 and r[4]>0,r)
        r=await E("""()=>{const [R,tw,F]=mtSet(1,230,0);for(const k of [0,1,2]){const e=rpSpawn('gloom',0);e.s=200+k*20;e.hp=e.mx=1e7}const air=R.foes.filter(e=>e.air).length;for(let i=0;i<60*3;i++)rpStep(R,1/60);return [air,R.mtShells.length+R.mtBooms.length,Math.round(tw.dmg)]}""")
        chk('flyers are ignored (it never fires at the sky)',r[1]==0 and r[2]==0,r)
        r=await E("""()=>{const [R,tw,F,b]=mtSet(1,230,3,'golem');const q=rpPos(R,F[0]);tw.x=q.x+40;tw.y=q.y+20;for(let i=0;i<60*3;i++)rpStep(R,1/60);return [R.mtShells.length+R.mtBooms.length,F.every(e=>e.hp===e.mx),Math.round(Math.sqrt(rpD2(q.x,q.y,tw.x,tw.y)))]}""")
        chk('monsters inside the dead zone are safe from it',r[0]==0 and r[1] and r[2]<95,r)
        r=await E("""()=>{const [R,tw,F]=mtSet(1,240,1,'golem',{sp:60});F[0].slowT=0;let s=null;for(let i=0;i<60*.3&&!s;i++){rpStep(R,1/60);s=R.mtShells[0]}if(!s)return ['no shell'];
          while(!s.done){rpStep(R,1/60)}const q=rpPos(R,F[0]);return [Math.round(Math.sqrt(rpD2(q.x,q.y,s.x1,s.y1))),s.r,F[0].hp<F[0].mx]}""")
        chk('it leads a walking monster: the shell lands on it, not behind it',isinstance(r[0],int) and r[0]<r[1]*.5 and r[2],r)
        r=await E("""()=>{const [R,tw,F]=mtSet(1,240,0);const e=rpSpawn('golem',0),f=rpSpawn('golem',0);const b=[...R.G.paths[0].S];e.s=f.s=0;
          const s={x0:0,y0:0,x1:0,y1:0,t:1,d:1,h:0,tw,tier:1,dmg:100,r:80,ap:99,kind:'main'};let best=null;for(let k=0;k<R.G.paths[0].len;k+=4){const q=rpAt(R.G,k,0);if(rpD2(q.x,q.y,tw.x,tw.y)>250*250&&rpD2(q.x,q.y,tw.x,tw.y)<300*300){best=k;break}}
          e.s=best;f.s=best+60;e.hp=e.mx=f.hp=f.mx=1e5;const q=rpPos(R,e);s.x1=q.x;s.y1=q.y;const qf=rpPos(R,f),df=Math.sqrt(rpD2(qf.x,qf.y,q.x,q.y));R.mtShells=[s];rpStep(R,1/60);return [Math.round(e.mx-e.hp),Math.round(f.mx-f.hp),Math.round(df)]}""")
        chk('splash falls off: full damage at the centre, less toward the edge',r[0]==100 and (r[1]==0 or 60<=r[1]<100),r)
        # ---------------------------------------------------------------- abilities by tier
        r=await E("""()=>{const [R,tw,F]=mtSet(3,230,4,'golem');for(let i=0;i<60*2;i++)rpStep(R,1/60);const c=R.mtCraters[0];if(!c)return ['no crater'];
          const e=F.find(x=>!x.dead);e.slowK=0;e.slowT=0;const q=rpPos(R,e);c.x=q.x;c.y=q.y;c.t=0;rpStep(R,1/60);return [R.mtCraters.length,+e.slowK.toFixed(2),e.slowT>0]}""")
        chk('tier 3: shells leave craters that slow monsters standing in them (40%)',r[0]>=1 and r[1]>=.4 and r[2],r)
        r=await E("""()=>{const [R,tw,F]=mtSet(4,230,4,'golem');let bombs=0;for(let i=0;i<60*2.2;i++){rpStep(R,1/60);bombs=Math.max(bombs,R.mtShells.filter(s=>s.kind==='bomb').length)}return [bombs]}""")
        chk('tier 4: every shell scatters three bomblets',r[0]==3,r)
        r=await E("""()=>{const [R,tw,F]=mtSet(5,230,5,'golem');const boss=rpSpawn('behemoth',F[0].pi);boss.s=F[0].s+10;boss.hp=boss.mx=1e8;boss.sp=0;let storms=0,stun=0,bossStun=0;tw.nv=4;tw.cd=0;
          for(let i=0;i<60*2.5;i++){rpStep(R,1/60);storms=Math.max(storms,R.mtShells.filter(s=>s.kind==='storm').length);for(const e of F)if(!e.dead&&e.stun>0)stun=1;if(boss.stun>0)bossStun=1}return [storms,stun,bossStun,tw.nv]}""")
        chk('tier 5: every fifth volley calls a five-shell Thunder Barrage that stuns (but not bosses)',r[0]==5 and r[1]==1 and r[2]==0,r)
        r=await E("""()=>{const run=over=>{const [R,tw,F]=mtSet(1,230,4,'golem');let n=0;for(let i=0;i<60*8;i++){if(over)tw.over=1;const v=tw.nv||0;rpStep(R,1/60);if((tw.nv||0)>v)n++}return n};return [run(false),run(true)]}""")
        chk('Overcharge makes it fire faster',r[1]>r[0],r)
        # ---------------------------------------------------------------- upgrades, sell, art
        r=await E("""()=>{const R=tdNew('wonder',6),p=[...R.pads].sort((a,b)=>a.x-b.x)[3];R.supply=1e6;rpBuild(p,'mortar');const tw=p.tw;const out=[];for(let t=2;t<=5;t++){rpUpgrade(tw);out.push(tw.tier)}const s0=R.supply;rpSell(tw);return [out,!p.tw,R.supply>s0]}""")
        chk('it upgrades to tier 5 on Wonderland and sells for supply',r[0]==[2,3,4,5] and r[1] and r[2],r)
        r=await E("""()=>{const c=document.createElement('canvas');c.width=c.height=300;const g=c.getContext('2d');const bad=[];
          for(let t=1;t<=5;t++)for(const k of [0,.2,.5,.8,.97,1])try{g.clearRect(0,0,300,300);g.save();g.translate(150,220);rpTowerBuild(g,'mortar',t,'base',k,1,{from:k<1&&t>1?t-1:0,aim:-.5});g.restore()}catch(e){bad.push(t+':'+k+':'+e.message)}
          const ic=[1,2,3,4,5].map(t=>{const q=rpTowerIcon('mortar',t,'base',96),d=q.getContext('2d').getImageData(0,0,96,96).data;let n=0;for(let i=3;i<d.length;i+=4)if(d[i]>100)n++;return n});return [bad,ic]}""")
        chk('build, upgrade and ascension animations draw at every tier, and every icon has art',r[0]==[] and all(n>1200 for n in r[1]),r)
        r=await E("""async()=>{const R=tdNew('moss',3);const p=[...R.pads].sort((a,b)=>a.x-b.x)[3];const tw=tdBuild(R,p,'mortar',2);R.sel=tw;await new Promise(r=>setTimeout(r,700));const el=document.querySelector('#rpinfo,.rpinfo');
          const labs=el?[...el.querySelectorAll('.rpst span')].map(x=>x.textContent):[];return [labs,!!el&&/Thunder Mortar/.test(el.textContent)]}""")
        chk('the info panel shows Range, Damage, Splash and Fire rate',r[0]==['Range','Damage','Splash','Fire rate'] and r[1],r)
        # ---------------------------------------------------------------- frame cost and a real wave
        r=await E("""()=>{const c=document.createElement('canvas');c.width=1600;c.height=900;const g=c.getContext('2d');const scene=t=>{g.clearRect(0,0,1600,900);for(let k=0;k<4;k++){g.save();g.translate(200+k*300,400);rpTowerDraw(g,'mortar',2+k,'base',t,{aim:-1+k,fire:.6,charge:.4,ph:k});g.restore()}
            for(let k=0;k<8;k++){rpMortarReticle(g,300+k*100,600,96,.5,4);rpMortarShell(g,300+k*100,300,4,t)}for(let k=0;k<6;k++){rpMortarBoom(g,300+k*150,500,106,(k+1)/8,4,k===5);rpMortarCrater(g,300+k*150,650,90,.8,t,4)}rpMortarBolt(g,800,500,.3,3)};
          for(let i=0;i<10;i++)scene(i*.1);const t0=performance.now();for(let i=0;i<40;i++)scene(i*.1);return +((performance.now()-t0)/40).toFixed(3)}""")
        chk('a heavy mortar scene (4 towers, 8 shells, 6 blasts, 6 craters, lightning) draws in under 1.5 ms a frame (headless, canvas cleared each frame like the game)',r<1.5,r)
        r=await E("""()=>{const R=tdNew('wonder',1);R.wst='build';const pads=[...R.pads].sort((a,b)=>a.x-b.x);[1,3,5].forEach(i=>tdBuild(R,pads[i],'mortar',5));tdBuild(R,pads[2],'ballista',5);tdBuild(R,pads[4],'frost',5);tdBuild(R,pads[6],'tide',5);return tdPlay(R,40,240)}""")
        chk('a whole Wonderland wave 40 with mortars, frost and tide: no broken health, the wave ends',r['nan']==0 and r['over']==0 and r['wst']!='run',r)
        chk('no page errors',not er,er)
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
