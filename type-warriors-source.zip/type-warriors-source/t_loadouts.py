import asyncio,os
from playwright.async_api import async_playwright
SET="""()=>{RS_ASK=false;P.xp=999999;P.gold=50000;syncPaths();P.petSt=2;P.pets={ember:{b:300},bramble:{b:120},antler:{b:10}};P.pet='ember';petNorm();
 for(const k in WP)P.own[k]=1;for(const k in AR)P.ownA[k]=1;P.weapon='rusty';P.path='knight';P.armor='rags';
 const wk=Object.keys(WP),ak=Object.keys(AR);window._W=wk.find(k=>WP[k].r==='Mythic'&&WP[k].p==='knight');window._M=wk.find(k=>WP[k].p==='mage'&&WP[k].r==='Epic');window._A=ak.find(k=>AR[k].r==='Legendary');window._A2=ak.find(k=>AR[k].r==='Epic');
 P.lo={s:[{n:'Campaign',w:_W,a:_A,p:'ember'},{n:'Endless',w:_M,a:_A2,p:'bramble'},{}],sel:0,ask:0};save();loadouts()}"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append('PE '+str(e)[:300]))
        await pg.goto('file://'+os.path.abspath('out.html'));await pg.wait_for_timeout(900);E=pg.evaluate
        await E("()=>{RS_ASK=false;title()}");await pg.wait_for_timeout(300)
        # reach it from the dock: Gear -> Loadouts sub-tab
        await pg.click('#dk_gr');await pg.wait_for_timeout(400)
        print('subtabs',await E("()=>[...document.querySelectorAll('.dkst')].map(b=>b.textContent.trim())"))
        await pg.click('[data-dks="lo"]');await pg.wait_for_timeout(500)
        print('open from dock',await E("()=>[!!document.getElementById('lol'),document.querySelector('.dkst.on').dataset.dks,!!document.querySelector('.fback')]"))
        await E("()=>title()");await pg.wait_for_timeout(200);await pg.click('#dk_gr');await pg.wait_for_timeout(400)
        print('gear remembers loadouts',await E("()=>!!document.getElementById('lol')"))
        await E(SET);await pg.wait_for_timeout(900)
        await pg.screenshot(path='shots/lo_main.png')
        # hover preview swaps the stage without equipping
        await pg.hover('[data-lo="1"]');await pg.wait_for_timeout(500)
        print('hover',await E("()=>[LOX.hov,document.getElementById('lostn').textContent,P.weapon]"))
        await pg.screenshot(path='shots/lo_hover.png')
        await pg.mouse.move(5,5);await pg.wait_for_timeout(100)
        # equip campaign directly (ask off)
        await pg.click('#loeq');await pg.wait_for_timeout(450)
        print('equip',await E("()=>[P.weapon===_W,P.armor===_A,P.pet,P.path,document.getElementById('loeq').disabled,!!document.querySelector('[data-lo=\"0\"] .loact')]"))
        await pg.screenshot(path='shots/lo_equip.png')
        # skill tree untouched
        print('upg untouched',await E("()=>JSON.stringify(P.upg).length>=2"))
        # select Endless by key 2, ask on -> modal
        await pg.keyboard.press('2');await pg.wait_for_timeout(300)
        await pg.click('.loask span');await pg.wait_for_timeout(100)
        await pg.click('#loeq');await pg.wait_for_timeout(500)
        print('ask modal',await E("()=>[P.lo.sel,P.lo.ask,!document.getElementById('lomod').hidden,document.querySelectorAll('.loch2').length]"))
        await pg.screenshot(path='shots/lo_ask.png')
        await pg.keyboard.press('Escape');await pg.wait_for_timeout(200)
        print('esc closes modal only',await E("()=>[!!document.getElementById('lol'),document.getElementById('lomod').hidden,P.weapon===_W]"))
        await pg.click('#loeq');await pg.wait_for_timeout(200);await pg.click('#lomy');await pg.wait_for_timeout(500)
        print('equipped endless',await E("()=>[P.weapon===_M,P.path,P.armor===_A2,P.pet]"))
        # missing pet + locked class
        await E("()=>{delete P.pets.ember;P.xp=0;save();loadouts()}");await pg.wait_for_timeout(500)
        await pg.keyboard.press('1');await pg.wait_for_timeout(300)
        print('plan',await E("()=>{const r=loPlan(P.lo.s[0]);return [r.w.ok,r.w.why,r.a.ok,r.p.ok,r.p.why,document.querySelectorAll('[data-lo=\"0\"] .lotile.bad').length]}"))
        await E("()=>{P.lo.ask=0}");await pg.click('#loeq');await pg.wait_for_timeout(400)
        print('partial equip',await E("()=>[P.armor===_A,P.weapon===_M,P.pet,document.querySelector('.lotst')&&document.querySelector('.lotst').textContent]"))
        await pg.screenshot(path='shots/lo_partial.png')
        await E("()=>{P.xp=999999;P.pets.ember={b:300};petNorm();save();loadouts()}");await pg.wait_for_timeout(400)
        # save into empty slot 3 then overwrite slot 2 (needs second click)
        await pg.keyboard.press('3');await pg.wait_for_timeout(200);await pg.click('#losv');await pg.wait_for_timeout(500)
        print('saved empty',await E("()=>[P.lo.s[2].w===P.weapon,P.lo.s[2].a===P.armor,P.lo.s[2].p,P.lo.s[2].c]"))
        await pg.screenshot(path='shots/lo_saved.png')
        await E("()=>{setWeapon('rusty');P.armor='rags';save()}");await pg.keyboard.press('2');await pg.wait_for_timeout(200)
        await pg.click('#losv');await pg.wait_for_timeout(150)
        print('armed',await E("()=>[document.getElementById('losv').className,P.lo.s[1].w===_M]"))
        await pg.click('#losv');await pg.wait_for_timeout(300)
        print('overwritten',await E("()=>[P.lo.s[1].w,P.lo.s[1].a]"))
        # rename
        await pg.click('[data-lo="2"] [data-ren]');await pg.wait_for_timeout(200)
        await pg.keyboard.press('Control+a');await pg.keyboard.type('Gold Rush');await pg.screenshot(path='shots/lo_rename.png')
        await pg.keyboard.press('Enter');await pg.wait_for_timeout(300)
        print('renamed',await E("()=>[P.lo.s[2].n,document.getElementById('lodn').textContent,!!document.getElementById('lol')]"))
        await pg.click('[data-lo="2"] [data-ren]');await pg.wait_for_timeout(150);await pg.keyboard.type('zzz');await pg.keyboard.press('Escape');await pg.wait_for_timeout(200)
        print('esc cancels rename',await E("()=>[P.lo.s[2].n,!!document.getElementById('lol')]"))
        # persistence
        await E("()=>{load(JSON.parse(JSON.stringify(P)));loNorm()}")
        print('persist',await E("()=>P.lo.s.map(s=>s.n)"))
        await pg.keyboard.press('Escape');await pg.wait_for_timeout(300)
        print('esc home',await E("()=>[ov.className,!!document.getElementById('lol')]"))
        # small viewport
        await pg.set_viewport_size({'width':1280,'height':720});await E("()=>loadouts()");await pg.wait_for_timeout(800)
        await pg.screenshot(path='shots/lo_1280.png')
        print(er);await b.close()
asyncio.run(main())
