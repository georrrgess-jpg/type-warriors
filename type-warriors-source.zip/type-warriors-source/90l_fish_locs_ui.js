/* ===== MOONLIT FISHING: fishing spots (travel, unlocks, the world map) =====
   FSLOCS / FSPOOL live in 90a. The current spot is P.fish.loc (fsLoc() falls back to the pond if it is locked).
   New spots open when enough species are logged (Frostfall Lake at 10, Glowcap Grotto at 18); Stormreach Coast is shown
   as coming soon. The old painted world map below (fsMap/fsMapPaint) is superseded by the destination gallery in
   90l3_fish_spots.js, whose later fsMap declaration wins; fsMapPaint is no longer called. Unlocks are celebrated on the spot.
   The pond HUD and the journal know about spots (title, "fish here", "Found at", a spot filter). */
function fsTravel(k){if(!fsLocOpen(k))return false;const F=fsP();F.loc=k;save();try{fsSfx('buy')}catch(e){}return true}
const fsLocFound=k=>FSPOOL[k].filter(i=>fsP().b[i]&&fsP().b[i].n).length;
/* tell the player as soon as a catch opens a new spot */
{const r0=fsRecord;fsRecord=function(c){const before=FSLOCK.filter(k=>fsLocOpen(k));const out=r0.apply(this,arguments);try{const now=FSLOCK.filter(k=>fsLocOpen(k)&&!before.includes(k));if(now.length){const k=now[0];FS.unlockNote=k;setTimeout(fsUnlockShow,2600)}}catch(e){}return out}}
/* shows the pending unlock once nothing else is on screen: a banner in the pond, a toast on the fishing menu */
function fsUnlockShow(){const k=FS.unlockNote;if(!k||!FSLOCS[k]||S.mode!=='fish')return;const L=FSLOCS[k];
 if(S.view==='fish'&&$('fsban')&&FS.st!=='show'){try{fsBanner('New fishing spot!',L.n+' is open. Visit it from the map.',L.c,2.6)}catch(e){}FS.unlockNote=null;return}
 if(S.view==='fishhub'&&$('fsx')){try{fsWorkToast(`New fishing spot: ${L.n} is open! Visit it from the map.`)}catch(e){}FS.unlockNote=null;return}
 setTimeout(fsUnlockShow,1200)}
/* a spot's painted thumbnail (cached) */
const FSTHUMB={};
function fsLocThumb(k){if(FSTHUMB[k])return FSTHUMB[k];const c=document.createElement('canvas');c.width=360;c.height=220;const g=c.getContext('2d');
 if(k==='pond'){if(!FSBG)FSBG=fsBGBuild();g.drawImage(FSBG,420,60,1000,611,0,0,360,220)}
 else if(FSLOCART[k]&&FSLOCART[k].bg){if(!FSBGS[k]){const b=document.createElement('canvas');b.width=1600;b.height=900;try{FSLOCART[k].bg(b.getContext('2d'))}catch(e){}FSBGS[k]=b}g.drawImage(FSBGS[k],420,60,1000,611,0,0,360,220)}
 else{/* Stormreach: a stormy sea under lightning */g.fillStyle=fkLin(g,0,0,0,220,['#0a0c22','#1a2a4a','#2a3a5a']);g.fillRect(0,0,360,220);g.fillStyle='#0c1430';g.beginPath();g.moveTo(0,150);for(let x=0;x<=360;x+=20)g.lineTo(x,140+Math.sin(x*.05)*10);g.lineTo(360,220);g.lineTo(0,220);g.fill();
  g.fillStyle='#121024';g.beginPath();g.moveTo(250,150);g.lineTo(270,70);g.lineTo(290,150);g.fill();g.fillStyle='#ffe9a0';g.fillRect(266,74,8,10);fkGlow(g,270,79,40,'#ffe9a0',.4);
  g.strokeStyle='#cfe6ff';g.lineWidth=3;g.beginPath();g.moveTo(120,0);g.lineTo(100,50);g.lineTo(125,55);g.lineTo(95,120);g.stroke();fkGlow(g,105,60,70,'#9ac8ff',.25)}
 return FSTHUMB[k]=c}
/* ---------- the world map ---------- */
const FSMAPN={pond:[330,640],frost:[470,250],grotto:[1080,250],storm:[1250,640]};
function fsMap(back){back=back||fsHub;S.mode='fish';S.view='fishmap';FS.on=false;const cur=fsLoc(),n=fsFound();
 const node=k=>{const L=FSLOCS[k],[x,y]=FSMAPN[k],open=fsLocOpen(k),here=k===cur,tot=FSPOOL[k].length,got=fsLocFound(k);
  const st=L.soon?`<span class="fsmst soon">Coming in a future update</span>`:open?(here?`<span class="fsmst here">You are fishing here</span>`:`<button class="fsmgo" data-go="${k}">Fish here ›</button>`)
   :`<span class="fsmst lock">Discover ${L.need} species <b>${n} / ${L.need}</b></span><span class="fsmbar"><i style="width:${Math.min(100,n/L.need*100)}%"></i></span>`;
  return `<div class="fsmnode${open?' open':''}${here?' here':''}${L.soon?' soon':''}" style="left:${x}px;top:${y}px;--lc:${L.c}"><div class="fsmmed"><canvas width="200" height="200" data-th="${k}"></canvas>${open?'':`<i class="fsmlock">${L.soon?'?':'🔒'}</i>`}${here?'<i class="fsmpin"></i>':''}</div>
   <div class="fsmcard fsg"><b>${L.n}</b><small>${L.d}</small>${!L.soon?`<span class="fsmfc">${open?`${got} / ${tot} fish found here`:`${tot} fish to find`}</span>`:''}${st}</div></div>`};
 show(`<div class="fsx fsmx" id="fsx"><canvas id="fsmcv" width="1600" height="900" aria-hidden="true"></canvas>
 <h2 class="fswh">Fishing Spots</h2><p class="fsmsub">${n} / ${FIDS.length} species logged. Log more fish to open new spots.</p>
 <div class="fstr"><span class="fsgold fsg">${fsCoin}<b id="fsgold">${P.gold.toLocaleString()}</b></span><button class="fsback fsg" id="fsback"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 5l-7 7 7 7" stroke="currentColor" stroke-width="2.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>Back <kbd>Esc</kbd></button></div>
 ${FSLOCK.map(node).join('')}</div>`,'fshx');
 S.back=back;$('fsback').onclick=back;{const cn=$('cn');if(cn)cn.classList.add('dkhid')}
 const cv=$('fsmcv'),g=cv.getContext('2d');LIVE.push({cv,fn:t=>fsMapPaint(g,t,cur),slow:2});
 ov.querySelectorAll('canvas[data-th]').forEach(c=>{const k=c.dataset.th,x=c.getContext('2d');x.save();x.beginPath();x.arc(100,100,96,0,TAU);x.clip();x.drawImage(fsLocThumb(k),-80,-10,360,220);if(!fsLocOpen(k)){x.fillStyle='#0a0620b0';x.fillRect(0,0,200,200)}x.restore()});
 ov.querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>{if(fsTravel(b.dataset.go)){fsHub()}})}
let FSMAPBG=null;
function fsMapPaint(g,t,cur){if(fsRM())t=0;if(!FSMAPBG){const c=document.createElement('canvas');c.width=1600;c.height=900;const m=c.getContext('2d');m.lineJoin='round';
  m.fillStyle=fkLin(m,0,0,0,900,['#0a0828','#141048','#1c1656']);m.fillRect(0,0,1600,900);
  for(let i=0;i<160;i++){m.globalAlpha=.3+fsRnd(i)*.6;m.fillStyle='#f0eaff';m.beginPath();m.arc(fsRnd(i+3)*1600,fsRnd(i+9)*900,fsRnd(i+5)<.1?1.6:.8,0,TAU);m.fill()}m.globalAlpha=1;
  /* the sea and the land */
  m.fillStyle='#10204a';m.fillRect(0,0,1600,900);const land=(pts,c1,c2)=>{fkPath(m,pts);m.fillStyle=fkLin(m,0,0,0,900,[c1,c2]);m.fill();m.save();m.translate(0,6);fkPath(m,pts);m.strokeStyle='#cfe6ff55';m.lineWidth=10;m.stroke();m.restore();m.lineWidth=4;m.strokeStyle='#1b1024';fkPath(m,pts);m.stroke();m.save();fkPath(m,pts);m.clip();for(let i=0;i<260;i++){m.fillStyle=i%2?'#ffffff0c':'#0000001a';m.beginPath();m.arc(fsRnd(i+70)*1600,fsRnd(i+71)*900,2+fsRnd(i+72)*5,0,TAU);m.fill()}m.restore()};
  for(let i=0;i<40;i++){const x=fsRnd(i+200)*1600,y=fsRnd(i+201)*900;m.strokeStyle='#ffffff16';m.lineWidth=2;m.beginPath();m.moveTo(x-14,y);m.quadraticCurveTo(x-7,y-5,x,y);m.quadraticCurveTo(x+7,y+5,x+14,y);m.stroke()}
  land([60,860,40,520,180,300,340,120,700,80,980,110,1300,90,1500,200,1560,460,1440,560,1180,560,1060,700,820,820,500,880],'#2a4a3e','#1e3a32');
  /* snowy mountains (Frostfall) */
  for(let i=0;i<5;i++){const x=300+i*70,y=270-(i%2)*30;m.fillStyle='#4a5a8a';m.beginPath();m.moveTo(x-60,y+60);m.lineTo(x,y-50);m.lineTo(x+60,y+60);m.fill();m.lineWidth=3;m.strokeStyle='#1b1024';m.stroke();m.fillStyle='#f0f6ff';m.beginPath();m.moveTo(x-22,y-8);m.lineTo(x,y-50);m.lineTo(x+22,y-8);m.lineTo(x+8,y-14);m.lineTo(x,y-4);m.lineTo(x-8,y-14);m.fill()}
  /* the cave mountain (Grotto) */
  m.fillStyle='#3a2a5a';m.beginPath();m.moveTo(940,330);m.quadraticCurveTo(1000,120,1090,130);m.quadraticCurveTo(1200,140,1240,330);m.fill();m.lineWidth=3;m.strokeStyle='#1b1024';m.stroke();m.fillStyle='#0c0820';m.beginPath();m.ellipse(1090,300,40,34,0,Math.PI,0);m.fill();
  /* forests */
  for(let i=0;i<40;i++){const x=120+fsRnd(i+40)*1300,y=360+fsRnd(i+41)*420;if(Math.hypot(x-330,y-640)<120||Math.hypot(x-1250,y-640)<150)continue;m.fillStyle=i%2?'#2a5a3e':'#1e4a32';m.beginPath();m.moveTo(x,y-22);m.lineTo(x+12,y+6);m.lineTo(x-12,y+6);m.fill()}
  /* the coast and lighthouse (Stormreach) */
  m.fillStyle='#1e2a52';m.beginPath();m.moveTo(1180,560);m.quadraticCurveTo(1300,600,1440,560);m.lineTo(1600,600);m.lineTo(1600,900);m.lineTo(1150,900);m.fill();
  FSMAPBG=c}
 g.setTransform(1,0,0,1,0,0);g.drawImage(FSMAPBG,0,0);
 /* drifting clouds and the dotted route */
 g.save();g.globalAlpha=.12;g.fillStyle='#c8c0ff';for(let i=0;i<4;i++){const x=((t*12+i*480)%2000)-200,y=140+i*170;g.beginPath();g.ellipse(x,y,140,26,0,0,TAU);g.ellipse(x+80,y-14,90,22,0,0,TAU);g.fill()}g.restore();
 const route=[FSMAPN.pond,[380,460],FSMAPN.frost,[760,170],FSMAPN.grotto,[1200,440],FSMAPN.storm];
 g.save();g.setLineDash([14,12]);g.lineDashOffset=-t*24;g.lineWidth=5;g.strokeStyle='#1b1024';g.beginPath();g.moveTo(route[0][0],route[0][1]);for(let i=1;i<route.length-1;i+=2)g.quadraticCurveTo(route[i][0],route[i][1],route[i+1][0],route[i+1][1]);g.stroke();
 g.lineWidth=2.6;g.strokeStyle='#ffd45a';g.stroke();g.restore();
 /* the current spot glows */
 const [cx,cy]=FSMAPN[cur];fkGlow(g,cx,cy,150+10*Math.sin(t*2),FSLOCS[cur].c,.25)}
/* ---------- the pond HUD and the journal know about spots ---------- */
{const p0=fsPond;fsPond=function(){const r=p0.apply(this,arguments);try{const k=fsLoc(),L=FSLOCS[k],h=ov.querySelector('.fstop h2');if(h){h.textContent=L.n;h.style.cursor='pointer';h.title='See all fishing spots';h.onclick=()=>{if(FS.st==='idle'){fsStop();fsMap(fsPond)}}}
  const fo=$('fsfound');if(fo)fo.parentNode.innerHTML=`<span class="fsfi" aria-hidden="true">${fsFishIc()}</span>Fish here <b id="fsfhere">${fsLocFound(k)} / ${FSPOOL[k].length}</b> <span class="fsfall">· all <b id="fsfound">${fsFound()} / ${FIDS.length}</b></span>`}catch(e){console.error(e)}return r}}
{const h0=fsHudRefresh;fsHudRefresh=function(){const r=h0.apply(this,arguments);try{const e=$('fsfhere');if(e){const k=fsLoc();e.textContent=`${fsLocFound(k)} / ${FSPOOL[k].length}`}}catch(x){}return r}}
/* journal: a spot filter and "Found at" */
FSH.jloc='all';
fsJList=function(){return FIDS.filter(i=>(FSH.jflt==='all'||FISH[i].r===FSH.jflt)&&(FSH.jloc==='all'||FSPOOL[FSH.jloc].includes(i)))};
{const j0=fsJournal;fsJournal=function(id){const r=j0.apply(this,arguments);try{const hd=ov.querySelector('.fsjpg.l header');if(hd&&!ov.querySelector('.fsjloc')){const d=document.createElement('div');d.className='fsjloc';
  d.innerHTML=[['all','All spots'],...FSLOCK.filter(k=>!FSLOCS[k].soon).map(k=>[k,FSLOCS[k].n])].map(([k,n])=>`<button data-jl="${k}" class="${FSH.jloc===k?'on':''}">${n}</button>`).join('');hd.after(d);
  d.querySelectorAll('[data-jl]').forEach(b=>b.onclick=()=>{FSH.jloc=b.dataset.jl;d.querySelectorAll('[data-jl]').forEach(x=>x.classList.toggle('on',x===b));fsJGrid()});fsJGrid()}}catch(e){console.error(e)}return r}}
{const p0=fsJPage;fsJPage=function(dir){const r=p0.apply(this,arguments);try{const id=FSH.jsel,box=ov.querySelector('.fsjent .fsjtop');if(box&&FISH[id]){const at=FISH[id].at||[];const s=document.createElement('span');s.className='fsjat';s.innerHTML='Found at: '+at.map(k=>`<i style="--lc:${FSLOCS[k].c}">${FSLOCS[k].n}${fsLocOpen(k)?'':' 🔒'}</i>`).join(' ');box.appendChild(s)}}catch(e){}return r}}
{const st=document.createElement('style');st.textContent=`
.fsmx>canvas{position:absolute;inset:0;width:1600px;height:900px}.fsmsub{position:absolute;left:66px;top:96px;font:600 16px var(--ui);color:#d8d0f4}
.fsmnode{position:absolute;width:0;height:0;animation:fsIn .5s var(--sp) both}.fsmmed{position:absolute;left:-80px;top:-80px;width:160px;height:160px;border-radius:50%;border:5px solid color-mix(in srgb,var(--lc) 70%,#1b1024);box-shadow:0 0 0 4px #1b1024,0 14px 30px #000a;overflow:hidden;background:#0a0620;transition:transform .2s var(--sp)}
.fsmnode.open .fsmmed:hover{transform:scale(1.06)}.fsmmed canvas{width:160px;height:160px;display:block}.fsmnode.here .fsmmed{border-color:var(--lc);box-shadow:0 0 0 4px #1b1024,0 0 30px color-mix(in srgb,var(--lc) 60%,transparent)}
.fsmlock{position:absolute;inset:0;display:grid;place-items:center;font-style:normal;font-size:44px;color:#fff;text-shadow:0 3px 0 #000}
.fsmpin{position:absolute;left:50%;top:6px;width:24px;height:24px;margin-left:-12px;border-radius:50% 50% 50% 0;background:var(--lc);border:3px solid #1b1024;transform:rotate(-45deg);animation:fsPin 1.4s ease-in-out infinite}@keyframes fsPin{50%{translate:0 -6px}}
.fsmcard{position:absolute;left:-150px;top:92px;width:300px;padding:10px 14px;display:flex;flex-direction:column;gap:3px;text-align:center}
.fsmcard b{font:400 28px/1 'Pirata One',Georgia,serif;color:var(--lc)}.fsmcard small{font:500 12.5px/1.35 var(--ui);color:#c4badf}.fsmfc{font:700 13px var(--ui);color:#fff8e8}
.fsmst{font:700 13px var(--ui)}.fsmst.here{color:#9affc8}.fsmst.soon{color:#a8a0d0;font-style:italic}.fsmst.lock{color:#ffd0a0}.fsmst b{color:#fff;font:800 13px var(--ui)}
.fsmbar{display:block;height:8px;border-radius:4px;background:#07041a;border:1px solid #ffffff22;overflow:hidden}.fsmbar i{display:block;height:100%;background:linear-gradient(90deg,var(--lc),#fff)}
.fsmgo{align-self:center;margin-top:4px;height:40px;padding:0 20px;border:none;border-radius:12px;background:linear-gradient(180deg,#ffe27a,#f2b631);color:#3a2006;font:800 16px var(--ui);box-shadow:0 4px 0 #9a6a10;cursor:pointer}
.fsmnode.soon .fsmmed{filter:none;opacity:.8}
.fsfall{font-weight:500;opacity:.8}.fstop h2[title]:hover{text-decoration:underline dotted}
.fsjloc{display:flex;gap:5px;padding:0 30px 4px}.fsjloc button{height:28px;padding:0 10px;border-radius:8px;border:1.5px solid #c8a87a;background:#f6ead0;color:#5a3a24;font:700 11.5px 'Cinzel',Georgia,serif;cursor:pointer}.fsjloc button.on{background:#5a2a14;color:#ffe9a0;border-color:#5a2a14}
.fsjat{margin-left:auto;font:700 11.5px 'Cinzel',Georgia,serif;color:#7a5a3a}.fsjat i{font-style:normal;margin-left:4px;padding:1px 8px;border-radius:8px;background:color-mix(in srgb,var(--lc) 35%,#f6ead0);color:#3a2414}
`;document.head.appendChild(st)}
