/* ---------- app shell: sidebar, new home screen, play hub ---------- */
/* a static picture of any scenery, for card backgrounds */
const SHOTC={};
function sceneShot(L,w,h,tag,fx){const k=tag+'_'+L.i+'_'+w;if(SHOTC[k]!==undefined)return SHOTC[k];let url='';const c=ctx;
 try{c.save();c.setTransform(RS,0,0,RS,0,0);c.globalAlpha=1;c.filter='none';c.globalCompositeOperation='source-over';c.shadowBlur=0;c.fillStyle='#000';c.fillRect(0,0,W,H);zoneBG(L.z,3.2,L);
  const t=document.createElement('canvas');t.width=w;t.height=h;const tg=t.getContext('2d');if(fx)tg.filter=fx;tg.drawImage(cv,0,0,cv.width,cv.height,0,0,w,h);url=t.toDataURL('image/jpeg',.88);c.restore()}catch(e){try{c.restore()}catch(_){}}
 return SHOTC[k]=url}

/* ----- the sidebar ----- */
const SBN=[['hm','home','Home',''],['pl','play','Play',''],['wp','arm','Armory','A'],['ut','skill','Skill Tree','K'],['bt','crate','Collection','L'],['sh','shop','Shop','S'],['bb','bounty','Bounties','B']];
const SBL=[['pf','user','Profile','O'],['st','gear','Settings',',']];
let SBSEEN=false;
const sbBadge=k=>k==='wp'?(newPaths().length?'<i class="bdg">!</i>':''):k==='ut'?(spNote()>0?`<i class="bdg">${spNote()}</i>`:''):k==='pf'?(canPres()?'<i class="bdg">!</i>':''):k==='bb'?(btyReady()?`<i class="bdg">${btyReady()}</i>`:''):'';
const sbItem=(it,nav)=>`<button class="sbi${nav===it[0]?' on':''}" data-nav="${it[0]}" id="sb_${it[0]}" ${nav===it[0]?'aria-current="page"':''}>${it[0]==='pf'?'<canvas id="sbav" width="44" height="44"></canvas>':`<span class="sbic">${mico(it[1],34)}</span>`}<b>${it[2]}</b>${sbBadge(it[0])}${it[3]?`<kbd>${it[3]}</kbd>`:''}</button>`;
function sbHTML(nav){const first=!SBSEEN;SBSEEN=true;
 return `<aside class="sb${first?' in':''}"><div class="sbl"><svg class="sbsw" viewBox="0 0 40 130" aria-hidden="true"><path d="M20 2L27 16V84H13V16Z" fill="#cfd8ea"/><path d="M20 2L27 16V84H20Z" fill="#8fa0bf"/><path d="M4 84H36V94H4Z" fill="#d8a830"/><path d="M16 94H24V122H16Z" fill="#7a4a24"/><circle cx="20" cy="126" r="5" fill="#d8a830"/></svg><h1><span>Type</span><span>Warriors</span></h1><p>Type fast<br>Strike true<br>Slay the dark</p></div>
 <div class="sbd"><i></i><u></u><i></i></div>
 <nav class="sbn" aria-label="Main menu">${SBN.map(i=>sbItem(i,nav)).join('')}</nav><div class="sbs"></div><div class="sbline"></div><nav class="sbn sbw" aria-label="Account">${SBL.map(i=>sbItem(i,nav)).join('')}</nav></aside>`}
const NAVGO={hm:()=>title(),pl:()=>playHub(),wp:()=>armory(),ut:()=>upgrades(),bt:()=>catalog(title),sh:()=>shop(),bb:()=>bountyBoard(),pf:()=>{profile.tab='Overview';profile()},st:()=>settings(title)};
function sbBind(){ov.querySelectorAll('.sbi').forEach(b=>b.onclick=()=>{const k=b.dataset.nav;if(b.classList.contains('on')&&k!=='hm')return;try{beep(520,.04,'triangle',.25)}catch(e){}NAVGO[k]()});
 const av=$('sbav');if(av)LIVE.push({cv:av,fn:portraitView(av)})}
/* which sidebar entry belongs to the screen that is being shown */
const NAVDET=[[/<h2[^>]*>\s*Armory/,'wp'],[/<h2[^>]*>\s*Skill Tree/,'ut'],[/<h2[^>]*>\s*Shop/,'sh'],[/<h2[^>]*>\s*Bounty Board/,'bb'],[/<h2[^>]*>\s*Profile/,'pf'],[/<h2[^>]*>\s*Prestige/,'pf'],[/<h2[^>]*>\s*Catalog/,'bt'],[/<h2[^>]*>\s*Settings/,'st'],[/<h2[^>]*>\s*Menu background/,'hm'],[/<h2[^>]*>\s*(Campaign|Choose a map|Practice Range|Play\s*<)/,'pl'],[/class="dcx/,'pl']];
function shellNav(cls,html){if(S.mode!=='title'||!(S.view==='menu'||S.view==='camp'||S.view==='dc'))return null;if(/\b(casbg|clear|home|drw|nosb)\b/.test(cls))return null;
 for(const [re,k] of NAVDET)if(re.test(html))return k;return ''}

/* ----- shared card builders ----- */
const mcard=o=>`<button class="hxm ${o.cls||''}${o.dis?' dis':''}" id="${o.id}" ${o.dis?'disabled':''} style="--c:${o.c}" title="${esc(o.tip||'')}">${o.img?`<img class="bg" alt="" src="${o.img}">`:''}<span class="hart">${o.art}</span>${o.kbd?`<kbd>${o.kbd}</kbd>`:''}${o.tag?`<span class="htg">${o.tag}</span>`:''}<span class="htx"><b>${o.t}</b><em>${o.d}</em>${o.s?`<small>${o.s}</small>`:''}<span class="hpl">${o.dis?mico('lock',20)+' Locked':o.btn+' <i>›</i>'}</span></span></button>`;
const monArt=id=>`<canvas width="200" height="190" data-m="${id}"></canvas>`;
function dailyCard(o){const {run,dd,st,img,wide}=o;
 return `<button class="hxd${dd?' dn':''}${wide?' wide':''}" id="dcb" style="--c:${run.L.a}"><span class="hxdh"><span class="hxdi">${mico('daily',wide?54:46)}</span><span class="hxdt"><small>DAILY CHALLENGE #${run.n}</small><b>${run.R.n}</b></span></span>
 <span class="hxdimg"${img?` style="background-image:url(${img})"`:''}><u>${run.M.n}</u>${st?`<em>${st} day streak</em>`:''}</span>
 <span class="hxds">${dd?`<span class="hok">✓</span><b>Completed!</b><span class="hrk" style="--g:${DCGC[dd.grade]}">Rank <i>${dd.grade}</i></span>`:`<b>New today</b><span class="hrk go">Play <i>›</i></span>`}</span></button>`}
/* the picture-cards need the same set-up wherever they are shown */
function cardsBind(){ov.querySelectorAll('canvas[data-m]').forEach(c=>tileArt(c,c.dataset.m));
 const g=(id,fn)=>{const e=$(id);if(e)e.onclick=fn};
 g('go',()=>endlessMenu(S.view==='menu'&&ov.querySelector('.phg')?playHub:title));g('cp',()=>campaign(cmCur()));g('rf',()=>{if(ARENA_ON)return waMenu(S.view==='menu'&&ov.querySelector('.phg')?playHub:title);if(riftOpen())start(0,'rift')});g('pr',()=>pracMenu(title));g('gy',()=>gyMenu(S.view==='menu'&&ov.querySelector('.phg')?playHub:title));g('dcb',()=>dcMenu(title))}
const camT=()=>P.stars[30]?'Replay':(Object.keys(P.stars).length?'Continue':'Begin');

/* ----- the notification bell ----- */
function alertList(run,dd){const a=[],npth=newPaths(),ncr=(P.crates||0)+(P.acr||0)+(P.scr||0)+(P.pcr||0)+(P.hcr||0)+(P.ccr||0);
 if(dailyReady())a.push(['dg','gift','Daily reward ready','Open the calendar and claim it']);
 if(!dd)a.push(['dgc','daily','Daily Challenge #'+run.n+' is live',run.R.n+' · '+run.M.n]);
 if(canPres())a.push(['pg','user','Prestige available','Ascend and start anew']);
 if(npth.length)a.push(['np2','arm','New path unlocked',npth.map(p=>PATHS[p].n).join(', ')+'. Choose it in the Armory']);
 if(btyReady())a.push(['bty','bounty',btyReady()+' bount'+(btyReady()>1?'ies':'y')+' ready to claim','Open the Bounty Board']);
 if(SGS.stale||SGS.mem||SGS.fail)a.push(['svp','save','Progress may not be saved',SGS.stale?'Changed in another window. Open the Save Center':SGS.mem?'Browser storage is blocked. Open the Save Center':'Storage may be full. Open the Save Center']);
 if(SGS.offer)a.push(['svo','save','A better backup was found','Level '+SGS.offer.info.lvl+'. Open the Save Center to restore it']);
 if(sgExportDue())a.push(['sve','save','Back up your progress','Export a file so it survives cleared browser data']);
 return updFilter(a)}
let bellOff=null;
function bellBind(al){const b=$('bell'),p=$('bellp');if(!b||!p)return;BELL_AL=al||[];BELL_TAB=BELL_AL.length||!updUnread()?'a':'u';
 const close=()=>{p.classList.remove('open');b.setAttribute('aria-expanded','false')};
 b.onclick=e=>{e.stopPropagation();const o=!p.classList.contains('open');p.classList.toggle('open',o);b.setAttribute('aria-expanded',o);if(o){b.classList.remove('ring')}};
 if(bellOff)document.removeEventListener('pointerdown',bellOff,true);
 bellOff=e=>{if(!document.getElementById('bellp')){document.removeEventListener('pointerdown',bellOff,true);return}if(!e.target.closest||!e.target.closest('.hxn'))close()};document.addEventListener('pointerdown',bellOff,true);
 const act={dg:()=>dailyMenu(title),dgc:()=>dcMenu(title),pg:()=>prestigeScreen(title),np2:armory,sk2:()=>upgrades(),cx2:crateHub,bty:()=>bountyBoard(),svp:()=>saveCenter(title),svo:()=>saveCenter(title),sve:()=>saveCenter(title),dr:()=>dailyMenu(title)};
 window.__bellAct=act;p.innerHTML=bellInner();bellWire(p,act)}

/* ----- the main menu ----- */
function title(){S.rift=0;S.prac=null;S.dc=null;dcSync();syncPaths();S.mode='title';S.view='menu';S.cr2=null;
 const l=lvl(P.xp),cur=Math.min(30,P.camp),LV=LEVELS[cur-1],M8=homeMon(),done=Object.keys(P.stars).length,stars=Object.values(P.stars).reduce((x,y)=>x+(y||0),0),ro=riftOpen(),ncr=(P.crates||0)+(P.acr||0)+(P.scr||0)+(P.pcr||0)+(P.hcr||0)+(P.ccr||0);
 const key=dcKey(),run=dcBuild(key),dd=dcDone(key),st=dcStreak();dcApply(run);
 const imgC=sceneShot(LV,960,540,'c'),imgE=sceneShot(LEVELS[17],640,480,'e'),imgR=sceneShot(mapDef(30),640,480,'r'),imgP=sceneShot(mapDef(31),640,480,'p'),imgD=sceneShot(run.L,600,300,'d'+key,'brightness(2.5) contrast(1.12) saturate(1.5)');
 const al=alertList(run,dd),tro=ACH.filter(a=>P.ach[a.id]).length,pcol=PATHS[P.path].c;
 const kick=P.stars[30]?'REPLAY YOUR':(done?'CONTINUE YOUR':'BEGIN YOUR');
 show(`<div class="hm2">${sbHTML('hm')}<section class="hx">
 <header class="hxh"><div class="hxt1"><h1>Ready for <em>battle?</em></h1><p>Type faster. Grow stronger. Defeat the darkness.</p></div>
  <div class="hxt"><button class="hxc" id="cx" title="Crates (X)"><span class="ci">${mico('crate',34)}</span><b>Crates</b>${ncr?`<i class="bdg">${ncr}</i>`:''}</button><button class="hxb" id="cal" title="Daily rewards calendar (D)" aria-label="Daily rewards calendar">${updCalIc(30)}${dailyReady()?'<i class="bdg">!</i>':''}</button><button class="hxb" id="hp" title="How to play (H)" aria-label="How to play">${mico('help',32)}</button><button class="hxb" id="bgb" title="Menu background" aria-label="Menu background">${mico('bg',32)}</button>
  <div class="hxn"><button class="hxb${al.length+updUnread()?' ring':''}" id="bell" title="Notifications" aria-label="Notifications" aria-haspopup="true" aria-expanded="false">${mico('bell',32)}${al.length+updUnread()?`<i class="bdg">${al.length+updUnread()}</i>`:''}</button>
   <div class="bellp" id="bellp" role="menu"></div></div></div></header>
 <div class="hxg"><div class="hxl">
  <button class="hxcamp${!P.runs?' first':''}" id="cp" title="Campaign (C)">${imgC?`<img class="bg" alt="" src="${imgC}">`:''}<span class="shade"></span><canvas class="hxhero" id="hxhero" width="560" height="430"></canvas>
   <span class="ctx"><span class="kick">${mico('camp',30)}<i>${kick}</i></span><b class="hbig">CAMPAIGN</b><span class="lvl">${P.stars[30]?'All 30 levels conquered':`Level ${cur} <u>•</u> ${esc(LV.n)}`}</span><span class="prg"><small>${done} / 30 stages <u>·</u> ${stars} / 90 stars</small><span class="hbar"><i style="--w:${done/30*100}%"></i></span></span><span class="hpl gold">${camT()} <i>›</i></span></span><kbd>C</kbd>${!P.runs?'<span class="htg">Start here</span>':''}</button>
  <div class="hxms">
   ${mcard({id:'go',cls:'end',c:'#ff8a3a',img:imgE,art:mico('endless',150),t:'Endless',d:'Survive round after round.<br>How long can you last?',btn:'Play',kbd:'E',tip:P.best?`Best round ${P.bestWave} · ${P.best.toLocaleString()} points`:'No record yet. Set one!'})}
   ${ARENA_ON?waCard(0):mcard({id:'rf',cls:'rift',c:'#b07aff',img:imgR,art:monArt(M8.rift),t:'Starfall Rift',d:ro?'A timed frenzy.<br>Kills add time.':'Unlocks at level 5',btn:'Enter',dis:!ro,kbd:'R',tip:P.rb&&P.rb.s?`Best ${P.rb.s.toLocaleString()} points`:'Kills add time. Chain a Starfall!'})}
   ${hwOn()?mcard({id:'gy',cls:'gyc',c:'#7affc8',img:gyThumb(),art:monArt(gyHomeMon()),t:'Monster Mash',d:'A cursed Endless run.<br>New curse every level.',btn:'Enter',kbd:'M',tag:'LIMITED TIME',s:hwLeft(),tip:'Halloween event: new monsters, curses and the Graveyard crate'}):mcard({id:'pr',cls:'prac',c:'#3fe0b8',img:imgP,art:monArt(M8.prac),t:'Practice Range',d:'Drill your keys, no pressure.<br>Build speed and accuracy.',btn:'Train',kbd:'P',tip:pbw()?`Best ${pbw()} WPM`:'Your own words, speed and goals'})}
  </div></div>
  <div class="hxr2">${dailyCard({run,dd,st,img:imgD})}
   <div class="hxp"><button class="hxhe" id="np" title="Profile (O)"><span class="hlb">${mico('arm',24)}<i>HERO</i><u style="color:${pcol}">${PATHS[P.path].n}</u></span><span class="hrw"><span class="hav"><canvas id="hxav" width="112" height="112"></canvas></span><span class="hnm"><b>${esc(P.name)}${P.pres?'<canvas id="tb" width="44" height="50"></canvas>':''}</b>${btyTitleHTML()}<small>${rankOf(l)} <u>•</u> Level ${l}</small>${P.pres?`<small class="hpr">Prestige ${PRN[P.pres-1]}</small>`:''}<span class="hgd"><span class="coin"></span>${P.gold.toLocaleString()}</span></span></span><span class="xb"><i style="width:${xpPct(P.xp)}%"></i></span></button>
   <button class="hxtr" id="tr" title="Trophies (T)"><span class="hlb">${mico('cup',24)}<i>TROPHIES</i></span><span class="hrw"><b>${tro}<small> / ${ACH.length}</small></b><span class="hchev">›</span></span><span class="xb"><i style="width:${tro/ACH.length*100}%"></i></span></button></div></div>
 </div><div class="hxtip">${tipLine()}</div></section></div>`,'m home');HOME=true;
 sbBind();cardsBind();bellBind(al);
 live('tb',c=>{const g=c.getContext('2d');return t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,44,50);prBadge(g,22,27,.34,P.pres,t)}});
 live('hxav',portraitView);
 live('hxhero',c=>{const g=c.getContext('2d');return t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,c.width,c.height);
   g.save();g.translate(290,396);g.fillStyle='#0008';g.beginPath();g.ellipse(0,6,96,13,0,0,TAU);g.fill();glow(g,0,-130,190,pcol+'30');
   g.save();g.scale(1,.2);g.strokeStyle=pcol+'88';g.lineWidth=4;g.setLineDash([14,10]);g.lineDashOffset=-t*26;g.beginPath();g.arc(0,30,104,0,TAU);g.stroke();g.restore();
   g.scale(1.95,1.95);drawHero(g,{arm:P.armor,wp:P.weapon,col:P.col,t,lg:0});g.restore();
   for(let i=0;i<14;i++){const u=(t*.18+i*.137)%1,x=130+((i*97)%330)+Math.sin(t*.9+i)*14,y=396-u*330;g.globalAlpha=Math.sin(u*Math.PI)*.8;g.fillStyle=i%3?'#ffe9a0':pcol;g.beginPath();g.arc(x,y,1.2+(i%3)*.8,0,TAU);g.fill()}g.globalAlpha=1}});
 $('cal').onclick=()=>dailyMenu(title);$('hp').onclick=()=>help(title);$('bgb').onclick=()=>hbgPick(title);$('cx').onclick=crateHub;$('np').onclick=()=>{profile.tab='Overview';profile()};$('tr').onclick=()=>profile(1)}

/* ----- the Play hub ----- */
function playHub(){S.mode='title';S.view='menu';
 const cur=Math.min(30,P.camp),LV=LEVELS[cur-1],M8=homeMon(),done=Object.keys(P.stars).length,stars=Object.values(P.stars).reduce((x,y)=>x+(y||0),0),ro=riftOpen();
 const key=dcKey(),run=dcBuild(key),dd=dcDone(key),st=dcStreak();dcApply(run);
 const imgC=sceneShot(LV,640,480,'c2'),imgE=sceneShot(LEVELS[17],640,480,'e'),imgR=sceneShot(mapDef(30),640,480,'r'),imgP=sceneShot(mapDef(31),640,480,'p'),imgD=sceneShot(run.L,900,300,'dw'+key,'brightness(2.5) contrast(1.12) saturate(1.5)');
 show(`<h2>Play</h2><p class="sub">Choose your battle. Every mode earns XP and gold.</p>
 <div class="phg${hwOn()?' g5':''}">
  ${mcard({id:'cp',cls:'camp',c:'#ffc94a',img:imgC,art:mico('camp',150),t:'Campaign',d:P.stars[30]?'All 30 levels conquered':`Level ${cur}: ${esc(LV.n)}`,s:`${done} / 30 cleared · ${stars} / 90 stars`,btn:camT(),kbd:''})}
  ${mcard({id:'go',cls:'end',c:'#ff8a3a',img:imgE,art:mico('endless',150),t:'Endless',d:'Survive round after round.',s:P.best?`Best round ${P.bestWave} · ${P.best.toLocaleString()} pts`:'No record yet. Set one!',btn:'Play'})}
  ${ARENA_ON?waCard(1):mcard({id:'rf',cls:'rift',c:'#b07aff',img:imgR,art:monArt(M8.rift),t:'Starfall Rift',d:ro?'A timed frenzy. Kills add time.':'Unlocks at level 5',s:ro?(P.rb&&P.rb.s?`Best ${P.rb.s.toLocaleString()} points`:'Chain a Starfall!'):'',btn:'Enter',dis:!ro})}
  ${mcard({id:'pr',cls:'prac',c:'#3fe0b8',img:imgP,art:monArt(M8.prac),t:'Practice Range',d:'Drill your keys, no pressure.',s:pbw()?`Best ${pbw()} WPM`:'Your own words, speed and goals',btn:'Train'})}
${hwOn()?mcard({id:'gy',cls:'gyc',c:'#7affc8',img:gyThumb(),art:monArt(gyHomeMon()),t:'Monster Mash',d:'A cursed Endless run.',s:hwLeft()+(P.gyb&&P.gyb.lv?` · best level ${P.gyb.lv}`:''),btn:'Enter',tag:'LIMITED TIME'}):''}
 </div>${dailyCard({run,dd,st,img:imgD,wide:1})}`);
 S.back=title;cardsBind()}

/* wide pages were laid out for the full screen: shrink any block that is wider than the room beside the sidebar */
function shellFit(){const mn=ov.querySelector('.mn');if(!mn)return;const av=mn.clientWidth-72;if(av<400)return;
 for(const el of mn.children){if(el.tagName==='H2'||el.tagName==='P')continue;const need=Math.max(el.offsetWidth,el.scrollWidth);if(need>av+2)el.style.zoom=Math.max(.5,av/need).toFixed(3)}}
