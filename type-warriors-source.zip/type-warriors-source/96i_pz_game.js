/* ===== 9.4 THE CROOKED CUE: the match (96i) =====
   Flow: start -> intro -> rerack -> turns (aim | ai) -> stroke -> roll -> settle -> judge -> next turn / rack end / match end.
   The match runs on its own clock (performance.now), never S.t. Physics steps at 1/120 s; events from the physics drive sound, fx and the
   rules. Rendering is in 96i2, input and the HUD DOM in 96i3, screens in 96j. */
const PZ={on:false,tok:0,ph:'',pht:0,t:0,last:0,paused:false,lite:false,lastPow:.5};
/* how each monster thinks before a shot: seconds of routine, practice strokes, whether it chalks */
const PZ_THINK={gloop:{dur:.7,pr:0,chalk:0},moldwick:{dur:1.15,pr:1,chalk:1},grizzle:{dur:.85,pr:1,chalk:0},vesper:{dur:1.15,pr:2,chalk:1},barnacle:{dur:1.2,pr:2,chalk:0},hootsworth:{dur:1.35,pr:2,chalk:1},mortimer:{dur:1.2,pr:1,chalk:1},shade:{dur:1.3,pr:2,chalk:1}};
const PZ_RMC={t:-1e9,v:false};
const pzRM=()=>{const n=performance.now();if(n-PZ_RMC.t>250){PZ_RMC.t=n;try{PZ_RMC.v=!!(ccReduce()||document.body.classList.contains('pf-low'))}catch(e){PZ_RMC.v=false}}return PZ_RMC.v};
const pzFx=(n,a)=>{try{if(typeof pzSound==='function')pzSound(n,a)}catch(e){}};
const pzPick=(a,rng)=>a[((rng||Math.random)()*a.length)|0];
/* ---------- starting, resuming, saving ---------- */
function pzStart(o){const R=PZ_REG[o.opp],Z=PZS();if(!R)return false;let stake=o.practice?0:(o.stake||0),practice=!!o.practice;
 const seed=o.resume?o.resume.seed:(o.seed||((Math.random()*1e9)|0));
 if(!o.resume){if(Z.live){pzNote('Finish or forfeit your match in progress first.');return false}
  if(stake&&Z.dayN>=PZ_DAILY){stake=0;practice=true}
  if(stake){if(stake>casCap('pz')){pzNote('That stake is above the table limit.');return false}if(stake>P.gold||!cTake(stake)){pzNote(`You need ${cmn(stake)} gold for that stake. The practice table is free.`);return false}Z.dayN++;
   /* the stake is gone, so the match exists from this instant: a reload during the intro resumes into it */
   Z.live={v:PZ_LIVE_V,pre:1,opp:R.id,stake,mult:o.mult||pzMultS(R.id,stake),race:o.race||R.race,practice:false,extended:false,score:[0,0],rack:1,breaker:0,bnr:0,golden:0,pots:0,banks:0,racks:[],bonus:0,seed,st:null,B:Array.from({length:16},(_,i)=>[i,0,0,1]),pend:null,rattled:0};save()}}
 PZ.tok++;const tok=PZ.tok;PZ.on=true;PZ.hub=false;CAS.on=true;CAS.key=null;PZ.reg=R;PZ.seed=seed;PZ.rng=pzRng(PZ.seed);PZ.paused=false;PZ.lite=false;PZ.silent=false;const race=o.race||R.race;
 PZ.M=pzMatchNew({opp:R.id,stake,mult:o.resume?o.resume.mult:(practice?1:(o.mult||pzMultS(R.id,stake))),race:o.resume?o.resume.race:race,practice,house:Object.assign({},R.house),hustle:!!R.hustler,breaker:0});
 PZ.M.bonus=0;PZ.M.proOnly=true;PZ.M.t0=Date.now();PZ.lastPow=.5;PZ.rattled=0;PZ.tauntOffer=false;PZ.nextTaunt=false;
 if(o.resume){const L=o.resume,M=PZ.M;M.score=L.score.slice();M.rack=L.rack;M.breaker=L.breaker;M.bnr=L.bnr;M.golden=L.golden;M.pots=L.pots;M.banks=L.banks;M.racks=L.racks||[];M.bonus=L.bonus||0;M.extended=!!L.extended;M.race=L.race;M.stake=L.stake;M.mult=L.mult;M.practice=!!L.practice;M.proOnly=L.proOnly!==0}
 pzCastInit(R.id);PZ.dim=!!R.house.dim;pzMount(R,tok);
 if(o.resume&&!o.resume.pre){pzResumeState(o.resume)}else{PZ.ph='intro';PZ.pht=0;pzIntro(R,()=>{if(PZ.tok!==tok)return;pzNewRack(true)})}
 return true}
/* a snapshot at the start of every turn; `pend` is a shot that has been struck but not yet judged (so a reload cannot undo a bad shot) */
function pzSave(pend){if(!PZ.on||!PZ.st)return;const Z=PZS(),M=PZ.M,st=PZ.st;if(M.over)return;
 Z.live={v:PZ_LIVE_V,opp:M.opp,stake:M.stake,mult:M.mult,race:M.race,practice:M.practice,extended:M.extended,score:M.score.slice(),rack:M.rack,breaker:M.breaker,bnr:M.bnr,golden:M.golden,pots:M.pots,banks:M.banks,racks:M.racks.slice(-12),bonus:M.bonus||0,seed:PZ.seed,
  st:{grp:st.grp.slice(),open:st.open,brk:st.brk,bih:st.bih,kitchen:st.kitchen,turn:st.turn,breaker:st.breaker,visits:st.visits.slice(),fouls:st.fouls.slice(),shots:st.shots,call:st.call},
  B:PZ.B.map(b=>[b.id,b.x,b.y,b.on?1:0]),pend:pend||null,rattled:PZ.rattled||0,proOnly:M.proOnly===false?0:1};save()}
function pzResumeState(L){const M=PZ.M,R=PZ.reg;PZ.B=PZ.B||[];const B=L.B.map(([id,x,y,on])=>({id,x,y,on:!!on,vx:0,vy:0,ux:0,uy:0,es:0})).sort((a,b)=>a.id-b.id);PZ.B=B;pzbInitBalls(B,pzRng(PZ.seed+9));
 const st=pzrNew(B,L.st.breaker,M.house);Object.assign(st,{grp:L.st.grp.slice(),open:L.st.open,brk:L.st.brk,bih:L.st.bih,kitchen:L.st.kitchen,turn:L.st.turn,visits:L.st.visits.slice(),fouls:L.st.fouls.slice(),shots:L.st.shots,call:L.st.call});PZ.st=st;
 PZ.tray=[];PZ.drops=[];PZ.fx=[];PZ.rings=[];PZ.flashes=[];PZ.floats=[];for(const b of B)if(!b.on&&b.id>0)pzTrayAdd(b.id,true);PZ.rattled=L.rattled||0;
 PZ.cueA=1;PZ.ph='gap';PZ.pht=0;PZ.vis=true;PZ.hadOpen=!!L.st.open;
 if(L.pend){PZ.silent=true;pzApplySilent(L.pend);PZ.silent=false}else{pzBeginTurn(false)}}
function pzApplySilent(shot){const B=PZ.B,st=PZ.st;PZ.ev=[];if(B[0].on||st.bih===false){}pzpStrike(B[0],shot.ang,shot.pow,shot.a,shot.b);const r=pzpRun(B,16);PZ.ev=r.ev;PZ.drops=[];
 for(const e of r.ev)if(e.t==='pk'&&e.a>0)pzTrayAdd(e.a,true);pzJudgeShot(true)}
/* ---------- racks ---------- */
function pzNewRack(first){const M=PZ.M,R=PZ.reg;PZ.B=pzpRack(PZ.rng).sort((a,b)=>a.id-b.id);pzbInitBalls(PZ.B,PZ.rng);const B=PZ.B;/* B[id] is the ball with that id (code below relies on it) */PZ.st=pzrNew(B,M.breaker,M.house);PZ.st.visits[M.breaker]=1;
 B[0].x=PZ_PHY.W*.25;B[0].y=PZ_PHY.H/2;PZ.tray=[];PZ.drops=[];PZ.fx=[];PZ.rings=[];PZ.flashes=[];PZ.floats=[];PZ.ev=[];PZ.cueA=0;PZ.call=-1;
 /* the re-rack: balls drop in from above one by one, the wooden triangle settles and lifts */
 const rm=pzRM();PZ.rk={t:0,items:B.map((b,i)=>({id:b.id,delay:b.id===0?.5:(i*.04),done:false})),tri:1,dur:rm?.3:1.35};for(const b of B){b.fly=rm?null:{t:-1}}PZ.vis=true;
 PZ.ph='rerack';PZ.pht=0;pzCastReact('mon','neutral');pzCastReact('hero','neutral');pzCastLean('hero',0);pzCastLean('mon',0);pzFx('rerack');pzHudAll();
 const banner=first?`Race to ${M.race}`:`Rack ${M.rack}`;pzBanner(banner,'info',1100)}
/* ---------- turns ---------- */
function pzClockMax(){const R=PZ.reg;return R.house.clock||45}
function pzGuideNote(){try{if(PZ.M&&PZS().guide!=='pro')PZ.M.proOnly=false}catch(e){}}
function pzBeginTurn(brk){PZ.fineBtn=false;pzGuideNote();const st=PZ.st,M=PZ.M,B=PZ.B;PZ.who=st.turn;PZ.rng=pzRng(PZ.seed*7919+M.rack*131+st.shots*17+st.turn*3+1);const human=st.turn===0;PZ.cueA=0;PZ.call=-1;PZ.callManual=false;PZ.clockOn=human&&!M.practice&&(PZS().clockOn||M.stake>0);PZ.clock=pzClockMax();PZ.stroke=null;PZ.shotFired=false;
 if(B[0].on===false){B[0].on=true;B[0].vx=B[0].vy=B[0].ux=B[0].uy=B[0].es=0}
 if(brk||st.brk){B[0].x=PZ_PHY.W*.22;B[0].y=PZ_PHY.H/2}
 pzCastLean('hero',human?1:0);pzCastLean('mon',human?0:1);
 if(human){PZ.ph='aim';PZ.mode=st.bih?'place':'aim';PZ.aim={ang:pzDefaultAim(),pow:st.brk?.8:.55,a:0,b:0};PZ.moved=false;PZ.fineOff=0;PZ.lastPtr=null;PZ.cueAng=PZ.aim.ang;PZ.cueAv=0;PZ.pull=0;PZ.drag=null;PZ.place=null;PZ.canPick=!!st.brk;
  if(st.bih&&!B[0].placed){const p=pzpNearestPlace(B,PZ_PHY.W*.35,PZ_PHY.H/2,st.kitchen);B[0].x=p.x;B[0].y=p.y}
  pzBanner(st.bih?(st.kitchen?'Ball in hand behind the line':'Ball in hand'):(st.brk?'You break':'Your shot'),st.bih?'foul':'turn',1000);
  pzSayMaybeTaunt();pzSave();pzSpinDraw();pzHudBar()}
 else{PZ.ph='ai';PZ.mode=null;PZ.canPick=false;pzAiBegin();pzBanner(st.brk?`${PZ.reg.n} breaks`:`${PZ.reg.n}'s shot`,'turn',900);pzSave()}
 pzHudAll()}
/* the first aim of a turn: toward the closest legal ball (or the head ball on the break) */
function pzDefaultAim(){const st=PZ.st,B=PZ.B,c=B[0];if(st.brk)return 0;const tg=pzrTargets(st);let best=null;for(const id of tg){const b=B[id];if(!b||!b.on)continue;const d=Math.hypot(b.x-c.x,b.y-c.y);if(!best||d<best.d)best={d,a:Math.atan2(b.y-c.y,b.x-c.x)}}return best?best.a:0}
/* ---------- the shot ---------- */
function pzStartStroke(shot,ai){const st=PZ.st,B=PZ.B;if(PZ.ph==='stroke'||PZ.ph==='roll')return;PZ.shot=shot;PZ.shotAi=!!ai;PZ.stroke={t:0,g0:5+(PZ.pull||0),dur:(.15-.075*shot.pow)*(ai?1.1:1),ai:!!ai};PZ.ph='stroke';PZ.mode=null;PZ.drag=null;PZ.shotFired=true;PZ.clockOn=false;
 /* the 8 must be called */
 if(pzrOn8(st)){let k=PZ.call;if(k<0){k=pzCall8(shot.ang);PZ.call=k}st.call=k}else st.call=null;
 pzCastLean(ai?'mon':'hero',1.3)}
function pzContact(){const st=PZ.st,B=PZ.B,s=PZ.shot;B[0].placed=false;pzpStrike(B[0],s.ang,s.pow,s.a,s.b);PZ.ev=[];PZ.simT=0;PZ.acc=0;PZ.ph='roll';PZ.pht=0;PZ.rollT=0;PZ.firstHit=false;PZ.crack=false;PZ.hitStop=0;PZ.slow=null;PZ.ts=1;PZ.tsT=1;
 pzSave({ang:s.ang,pow:s.pow,a:s.a,b:s.b});
 pzFx('cue',s.pow);const c=B[0];if(s.pow>.5)pzFlash(PZ_G.x+c.x-Math.cos(s.ang)*11,PZ_G.y+c.y-Math.sin(s.ang)*11,700*s.pow,false);pzPuff(PZ_G.x+c.x-Math.cos(s.ang)*10,PZ_G.y+c.y-Math.sin(s.ang)*10,6+(s.pow*8|0),'rgba(150,200,255,.7)',90+s.pow*160);
 if(st.brk&&s.pow>.8)PZ.shake=Math.max(PZ.shake||0,.9);if(s.pow>.7)PZ.shake=Math.max(PZ.shake||0,.25*s.pow);
 PZ.cueFade=1;PZ.lastShotAng=s.ang}
/* which pocket does the 8 head for (the auto-call): the pocket the object path points at, else the nearest */
function pzCall8(ang){const B=PZ.B,c=B[0],h=pzRay(B,c.x,c.y,Math.cos(ang),Math.sin(ang),0);if(h&&h.type==='ball'&&h.id===8){const e=B[8],ux=e.x-h.gx,uy=e.y-h.gy,l=Math.hypot(ux,uy)||1;const k=pzPocketToward(e.x,e.y,ux/l,uy/l);if(k>=0)return k}
 const e=B[8];let bi=0,bd=1e9;for(let k=0;k<6;k++){const d=Math.hypot(PZ_AIM[k][0]-e.x,PZ_AIM[k][1]-e.y);if(d<bd){bd=d;bi=k}}return bi}
/* ---------- the roll: physics events drive sound, fx and the drop animations ---------- */
function pzOnEvent(e){const G=PZ_G,sx=G.x+(e.x||0),sy=G.y+(e.y||0);
 if(e.t==='bb'){const s=e.s;if(!PZ.firstHit&&(e.a===0||e.b===0)){PZ.firstHit=true;PZ.fhx=sx;PZ.fhy=sy}
  pzFx('click',s);if(s>520){pzSpecks(sx,sy,Math.min(7,2+(s/260|0)),'#fff8e0');PZ.rings.push({x:sx,y:sy,t:0,d:.16,r:6+Math.min(16,s/90),c:'rgba(255,255,240,.85)'})}
  if(!PZ.crack&&PZ.st&&PZ.st.brk&&s>900&&(e.a===0||e.b===0)){PZ.crack=true;pzFlash(sx,sy,s,true);PZ.rings.push({x:sx,y:sy,t:0,d:.5,r:48,c:'rgba(255,255,240,.7)',ring:1});pzDust(sx,sy,10);pzSpecks(sx,sy,10,'#fff8e0');if(!pzRM()){PZ.shake=Math.max(PZ.shake||0,.55+.4*Math.min(1,s/2600));PZ.hitStop=.06}}
  else if(s>1000)pzFlash(sx,sy,s,false);
  if(s>1500&&!pzRM())PZ.shake=Math.max(PZ.shake||0,.12);
  const a=PZ.B[e.a],b=PZ.B[e.b];if(a)a.dirty=1;if(b)b.dirty=1}
 else if(e.t==='cu'){pzFx('rail',e.s);if(e.s>800)pzDust(sx,sy,Math.min(8,2+(e.s/400|0)))}
 else if(e.t==='pk'){const b=PZ.B[e.a];PZ.drops.push({id:e.a,x:e.x,y:e.y,k:e.p,t:0,M:b.M,dur:.2});pzFx('pocket',e.a);if(e.p>=0){const P=PZ_POCK[e.p];pzSpecks(G.x+P[0],G.y+P[1],9,'#ffd45a');pzPuff(G.x+P[0],G.y+P[1],4,'rgba(20,12,30,.8)',40);PZ.rings.push({x:G.x+P[0],y:G.y+P[1],t:0,d:.45,r:26,c:'rgba(255,212,90,.9)',ring:1})}
  /* a hard drop shakes the screen a hair */
  if(e.a===8)pzFx('eight')}}
function pzRollStep(dt){const B=PZ.B,st=PZ.st;if(PZ.hitStop>0){PZ.hitStop-=dt;return}PZ.ts+=(PZ.tsT-PZ.ts)*Math.min(1,dt*9);const ts=PZ.ts;let acc=PZ.acc+dt*ts,n=0,done=false;
 while(acc>=1/120&&n<28){const ev=[];const moving=pzpStep(B,1/120,ev,PZ.simT);PZ.simT+=1/120;acc-=1/120;n++;for(const e of ev){PZ.ev.push(e);pzOnEvent(e)}if(!moving){done=true;break}}
 PZ.acc=acc;PZ.rollT+=dt*ts;for(const b of B)if(b.on)pzbRoll(b,dt*ts);
 pzSlowMoCheck(dt);
 if((done||PZ.simT>16)&&!(PZ.slow&&PZ.slow.on&&PZ.slow.drop!=null)){if(!done)for(const b of B){b.vx=b.vy=b.ux=b.uy=b.es=0}PZ.ph='settle';PZ.pht=0;PZ.tsT=1;PZ.slow=null}}
/* the deciding 8: slow motion and a zoom while it rolls toward its pocket */
function pzSlowMoCheck(dt){const st=PZ.st,e=PZ.B[8];dt=dt||0;
 /* the 8 has dropped: hold the slow motion and the zoom for a beat, then let the table breathe out */
 if(PZ.slow&&PZ.slow.on){PZ.slow.t+=dt;if(PZ.slow.drop!=null){PZ.slow.drop+=dt;if(PZ.slow.drop>.7){PZ.slow.on=false;PZ.tsT=1;pzLetterbox(false)}return}
  PZ.slow.beat=(PZ.slow.beat||0)+dt;if(PZ.slow.beat>.6){PZ.slow.beat=0;pzFx('thump')}}
 if(pzRM()||!e.on||!pzrOn8(st)){if(PZ.slow&&PZ.slow.on){if(!e.on&&!pzRM()){PZ.slow.drop=0;PZ.tsT=.3;pzFx('drop',8)}else{PZ.slow.on=false;PZ.tsT=1;pzLetterbox(false)}}return}
 const sp=Math.hypot(e.vx,e.vy);let near=null;if(sp>70)for(let k=0;k<6;k++){const P=PZ_PHY,[ax,ay]=PZ_AIM[k],dx=ax-e.x,dy=ay-e.y,d=Math.hypot(dx,dy);if(d<135&&(dx*e.vx+dy*e.vy)/(d*sp)>.8&&(st.call<0||st.call===k||PZ.call===k)){near={k,d};break}}
 if(near&&!PZ.slowDone){if(!PZ.slow||!PZ.slow.on){PZ.slow={on:true,k:near.k,t:0,beat:0};PZ.slowDone=true;PZ.tsT=.3;pzFx('thump');pzFx('hush');pzLetterbox(true)}}
 else if(!near&&PZ.slow&&PZ.slow.on&&PZ.slow.drop==null){PZ.slow.on=false;PZ.tsT=1;pzLetterbox(false)}}
/* ---------- after the balls stop ---------- */
function pzSettleStep(dt){PZ.pht+=dt;if(PZ.drops.length&&PZ.pht<1.5)return;if(PZ.pht<.35)return;pzJudgeShot(false)}
function pzJudgeShot(silent){const st=PZ.st,M=PZ.M,Z=PZS(),who=st.turn,R=PZ.reg,B=PZ.B;PZ.slowDone=false;pzLetterbox(false);PZ.tsT=1;PZ.cueA=0;
 const rep=pzrJudge(st,PZ.ev);PZ.rep=rep;
 const mine=who===0,pk=rep.pk;if(mine){M.pots+=pk.length;M.banks+=rep.banks;if(!silent&&!M.practice){Z.pots+=pk.length;Z.banks+=rep.banks;stat('pzp',Z.pots,'set');stat('pzbk',Z.banks,'set')}}
 /* the 8 is spotted back on the table */
 if(rep.spot8){pzTrayRemove(8);const e=B[8];e.on=true;e.fly=null;PZ.rings.push({x:PZ_G.x+e.x,y:PZ_G.y+e.y,t:0,d:.5,r:30,c:'rgba(255,212,90,.9)',ring:1});pzFx('spot')}
 /* a scratched cue ball goes back on the table for ball in hand */
 if(!B[0].on){B[0].on=true;B[0].vx=B[0].vy=B[0].ux=B[0].uy=B[0].es=0;B[0].x=st.kitchen?PZ_PHY.W*.2:PZ_PHY.W*.5;B[0].y=PZ_PHY.H/2;B[0].placed=false}
 if(silent){pzAfterJudge(rep,true);return}
 /* the show: banners, reactions, floating texts */
 const who2=R.n;
 if(rep.golden){pzBanner('GOLDEN BREAK!','gold',1800);pzFx('golden');pzCoinBurst(PZ_G.x+PZ_PHY.W*.75,PZ_G.y+PZ_PHY.H/2,26);pzCastReact(mine?'mon':'hero','wow',1600);pzCastReact(mine?'hero':'mon','cheer',1600)}
 if(rep.foul){pzBanner(rep.reason+(rep.scratch?'!':''),'foul',1500);pzSub(rep.spot8?'The 8 goes back on the table · '+(mine?`${who2} has ball in hand`:'ball in hand for you'):(mine?`${who2} has ball in hand`:'You have ball in hand'),2400);pzFx('foul');PZ.shake=Math.max(PZ.shake||0,.5);
  pzCastReact(mine?'hero':'mon','angry',1200);pzCastReact(mine?'mon':'hero','smug',1500);
  if(mine)pzSay(pzPick(R.lines.foul,PZ.rng),2400);else pzSay(pzPick(['Ouch!','Bah!','Oops.'],PZ.rng),1600)}
 else if(rep.banks){pzFloat(PZ.fhx||800,(PZ.fhy||400)-20,rep.banks>1?'BANKS!':'BANK!','#9fe8ff')}
 if(rep.combos&&!rep.foul)pzFloat(PZ.fhx||800,(PZ.fhy||400)-44,'COMBO!','#ffd45a');
 if(!rep.foul&&!st.over){
  if(pk.length&&rep.keep){if(mine){pzCastReact('mon',Math.random()<.5?'wow':'sad',900);if(Math.random()<.45)pzSay(pzPick(R.lines.you,PZ.rng),2200)}else{pzCastReact('mon','happy',1100);pzCastReact('hero','sad',900);pzSay(pzPick(R.lines.pot,PZ.rng),2200)}}
  else if(!pk.length&&!rep.keep&&who===1){pzCastReact('mon','sad',1100);pzSay(pzPick(R.lines.miss,PZ.rng),2400);PZ.nextTaunt=true}
  else if(!pk.length&&who===0){pzCastReact('mon','smug',900)}}
 /* groups assigned */
 if(!st.open&&PZ.hadOpen){const g=st.grp[0];pzBanner(g==='s'?"You're solids":"You're stripes",'info',1400);pzHudAll()}
 PZ.hadOpen=st.open;
 if(pk.length>=2&&!rep.foul)pzFloat(800,PZ_G.y+PZ_PHY.H+66,pk.length+' down!','#8affb4');
 pzAfterJudge(rep,false)}
function pzAfterJudge(rep,silent){const st=PZ.st;if(st.over){PZ.ph='rackend';PZ.pht=0;pzRackEnd(silent);return}
 PZ.ph='gap';PZ.pht=0;PZ.gapT=silent?.01:(rep.foul?1.0:(rep.keep?.45:.55));pzHudAll()}
function pzGapStep(dt){PZ.pht+=dt;if(PZ.pht>=PZ.gapT)pzBeginTurn(false)}
/* a foul for running out of the shot clock */
function pzTimeFoul(){const st=PZ.st;if(PZ.ph!=='aim')return;try{pzTauntStop()}catch(e){}st.bih=true;st.kitchen=false;pzrPass(st,1);st.fouls[0]++;PZ.clockOn=false;pzBanner('Out of time!','foul',1400);pzFx('foul');pzCastReact('hero','sad',1000);pzCastReact('mon','smug',1400);pzSay(pzPick(PZ.reg.lines.foul,PZ.rng),2200);PZ.ph='gap';PZ.pht=0;PZ.gapT=1.1;PZ.mode=null;PZ.drag=null;pzSave();pzHudAll()}
/* ---------- racks and match end ---------- */
function pzRackEnd(silent){const st=PZ.st,M=PZ.M,Z=PZS(),R=PZ.reg,w=st.over.winner,mine=w===0;const info=pzMatchRack(M,st);
 if(!silent&&!M.practice){Z.racks++;if(mine){Z.rackWins++;stat('pzr',Z.rackWins,'set');if(info.bnr){Z.bnr++;stat('pzbnr',Z.bnr,'set')}if(st.golden){Z.golden++;stat('pzgold',Z.golden,'set')}}}
 if(silent){PZ.rackSilent=true}
 const why=st.over.why,txt=why==='golden'?'Golden break!':why==='8 ball'?(mine?'You sink the 8!':`${R.n} sinks the 8`):why==='8 too early'?(mine?`${R.n} sinks the 8 too early`:'You sank the 8 too early'):why==='8 in the wrong pocket'?(mine?`${R.n} missed the called pocket`:'Wrong pocket for the 8'):why==='8 with a foul'?(mine?`${R.n} fouled on the 8`:'You fouled on the 8'):'Rack over';
 if(!silent){const run=info.bnr&&mine;pzBanner(run?'BREAK & RUN!':(mine?'Rack to you!':`${R.n} takes the rack`),mine?'gold':'foul',run?2300:1600);pzSub(txt,1900);if(run){pzFx('golden');pzCoinBurst(800,440,34);pzCoinBurst(560,500,10);pzCoinBurst(1040,500,10)}
  pzCastReact(mine?'hero':'mon','cheer',1800);pzCastReact(mine?'mon':'hero','sad',1800);pzSay(pzPick(mine?R.lines.you:R.lines.pot,PZ.rng),2400);pzFx(mine?'rackwin':'racklose')}
 pzHudAll();
 if(M.over){PZ.ph='endhold';PZ.pht=0;PZ.endT=silent?.2:2.1;return}
 /* Slick Shade offers to let it ride after you win the first rack */
 if(M.hustle&&!M.extended&&mine&&M.rack===2&&M.score[0]===1&&M.score[1]===0){PZ.ph='endhold';PZ.pht=0;PZ.endT=1.5;PZ.offer=true;return}
 PZ.ph='endhold';PZ.pht=0;PZ.endT=silent?.2:1.7}
function pzEndStep(dt){PZ.pht+=dt;if(PZ.pht<PZ.endT)return;const M=PZ.M;if(M.over){pzMatchEnd();return}
 if(PZ.offer){PZ.offer=false;PZ.ph='offer';pzShadeOffer();return}pzNewRack(false)}
function pzExtend(yes){const M=PZ.M;if(yes){M.extended=true;M.race=3;M.mult=Math.min(2.8,Math.floor(PZ_CAP/Math.max(1,M.stake)*100)/100);PZ.shadeK=1}else{PZ.shadeK=1}PZ.ph='endhold';PZ.pht=0;PZ.endT=0;pzNewRack(false)}
/* ---------- settling the match: money, stats, unlocks ---------- */
function pzMatchEnd(){const M=PZ.M,Z=PZS(),R=PZ.reg,win=M.over.winner===0;PZ.ph='over';PZ.on=true;try{pzTauntStop()}catch(e){}const open0=PZ_ORDER.filter(k=>pzOpen(k));
 const res={win,opp:R.id,stake:M.stake,score:M.score.slice(),race:M.race,practice:M.practice,pay:0,bonus:0,bnr:M.bnr,golden:M.golden,pots:M.pots,banks:M.banks,time:Math.round((Date.now()-M.t0)/1000),unlocks:[],mult:M.mult,forfeit:!!M.forfeit,beatN:0};
 if(!M.practice){
  Z.live=null;save();/* the snapshot goes first, so a crash after this can never pay twice */
  if(win){const bonus=Math.min(500*Math.max(1,M.bnr),Math.round(M.stake*.1)*M.bnr)+(M.golden?Math.min(1000,Math.round(M.stake*.25)*M.golden):0);const base=Math.round(M.stake*M.mult);res.pay=Math.min(PZ_CAP,base+bonus);res.bonus=Math.max(0,res.pay-base);
   ecSrc('pool',()=>cPay(M.stake,res.pay));Z.wins++;Z.streak++;if(Z.streak>Z.best)Z.best=Z.streak;Z.net+=res.pay-M.stake;
   if(R.id==='shade'){Z.shade.beat=(Z.shade.beat||0)+1}else{Z.beat[R.id]=(Z.beat[R.id]||0)+1;Z.rep[R.id]=(Z.rep[R.id]||0)+1}res.beatN=R.id==='shade'?Z.shade.beat:Z.beat[R.id];
   if(R.id==='mortimer'&&Z.guide==='pro'&&M.proOnly)Z.proGuideBeat=(Z.proGuideBeat||0)+1}
  else{ecSrc('pool',()=>cPay(M.stake,0));Z.losses++;Z.streak=0;Z.net-=M.stake}
  stat('pzw',Z.wins,'set')}
 else if(win){res.beatN=0}
 res.opened=PZ_ORDER.find(k=>pzOpen(k)&&!open0.includes(k))||null;res.unlocks=pzUnlockSweep();try{stat('pzall',PZ_ORDER.filter(k=>(Z.beat[k]||0)>0).length,'set');stat('pzchamp',Z.beat.mortimer||0,'set');stat('pzpro',Z.proGuideBeat||0,'set');stat('pzshade',Z.shade.beat||0,'set');stat('pztaunt',Z.taunts,'set')}catch(e){}
 Z.live=null;save();try{achCheck()}catch(e){}
 PZ.result=res;pzResults(res)}
/* leaving mid-match = a loss of the stake */
function pzForfeit(){if(!PZ.on||!PZ.M||PZ.ph==='over')return;const M=PZ.M;M.forfeit=true;M.over={winner:1};PZ.ph='over';pzMatchEnd()}
function pzLeave(toHub){PZ.tok++;PZ.on=false;PZ.ph='';pzLetterbox(false);pzTauntStop();try{pzMusicOff()}catch(e){}if(toHub)pzHub();else{try{lobby()}catch(e){title()}}}
/* ---------- the monster's routine ---------- */
function pzAiBegin(){const st=PZ.st,B=PZ.B,R=PZ.reg,th=PZ_THINK[R.id]||PZ_THINK.gloop,me=Object.assign({},R.ai),rng=PZ.rng;
 let sigK=PZ.rattled>0?1.6:1;if(R.hustler&&!PZ.M.extended&&PZ.M.rack===1)sigK*=1.5;
 const ai={t:0,dur:th.dur,th,gen:null,dec:null,shot:null,placed:!st.bih,sigK,me,stage:'think',chalk:0,pr:th.pr,prT:0,skip:false};PZ.ai=ai;PZ.cueA=0;
 if(st.bih){pzaPlace(st,me);B[0].on=true;B[0].placed=true;PZ.placePop={x:B[0].x,y:B[0].y,t:0}}
 if(st.brk){ai.dec=pzaBreak(st,me,rng);ai.shot=pzaNoise(ai.dec,me,rng,sigK);ai.shot.brk=true;ai.dur=Math.max(.7,th.dur*.7);ai.pr=Math.min(ai.pr,1)}
 else{ai.gen=pzaThink(st,me,rng,{sigK:sigK})}
 PZ.aim={ang:pzDefaultAim(),pow:.5,a:0,b:0};PZ.cueAng=PZ.aim.ang;PZ.cueAv=0;PZ.pull=0;PZ.pullV=0;PZ.base=PZ.aim.ang}
function pzAiStep(dt){const ai=PZ.ai,st=PZ.st,B=PZ.B;if(!ai)return;ai.t+=dt;
 if(!ai.dec&&ai.gen){const t0=performance.now();do{const r=ai.gen.next();if(r.done){ai.dec=r.value;ai.shot=pzaNoise(ai.dec,ai.me,PZ.rng,ai.sigK);break}}while(performance.now()-t0<5)}
 PZ.cueA=Math.min(1,PZ.cueA+dt*4);const T=ai.dur,t=ai.t,base=pzDefaultAim();
 let tgt=base;
 if(t<T*.5){/* considering: the cue sweeps over the table */tgt=base+Math.sin(t*2.4+1)*.2*(ai.dec?.3:1);if(ai.dec&&t>T*.3)tgt=ai.dec.ang+Math.sin(t*3)*.03}
 else tgt=ai.shot?ai.shot.ang:base+Math.sin(t*2.4)*.06;
 PZ.aim.ang=tgt;PZ.aim.pow=ai.shot?ai.shot.pow:.4;
 /* chalking */
 ai.chalk=(ai.th.chalk&&t>T*.5&&t<T*.7)?(t-T*.5)/(T*.2):0;if(ai.chalk&&!ai.chalked){ai.chalked=1;pzFx('chalk')}
 /* practice strokes */
 let pull=0;const p0=T*.8;if(ai.pr>0&&t>p0&&ai.shot){const u=(t-p0)/.38;if(u<ai.pr){pull=Math.sin((u%1)*Math.PI)*(14+ai.shot.pow*30)}}
 PZ.aiPull=pull;
 const total=T+(ai.pr>0&&ai.shot?ai.pr*.38+.2:0);
 if(ai.skip){if(ai.shot&&t>.3){ai.skip=false;pzAiFire()}}
 else if(ai.shot&&t>=total)pzAiFire()}
function pzAiFire(){const ai=PZ.ai,s=ai.shot;PZ.ai=null;if(PZ.rattled>0)PZ.rattled--;if(ai.dec&&ai.dec.id===8&&ai.dec.k!=null&&pzrOn8(PZ.st))PZ.call=ai.dec.k;pzStartStroke({ang:s.ang,pow:s.pow,a:s.a,b:s.b},true)}
