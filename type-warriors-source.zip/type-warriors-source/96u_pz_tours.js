/* ===== 9.5 THE CROOKED CUE: first-visit tours of the screens (96u) =====
   The hub, Trick Shots and the Cue Rack each explain themselves once (P.pz.tut.hub / trick / rack).
   How to Play has a button that plays every tutorial again. */
function pzHubTour(){const Z=PZS();if(Z.tut.hub||Z.live)return;const tk=PZ.tok;setTimeout(()=>{if(PZ.tok!==tk||!$('pzh')||pzCoachActive())return;
 pzCoach('hub',[
  {title:'Welcome to the Crooked Cue!',text:'Play 8-ball against the casino\'s monster regulars. Beat one to open the next table, win their gold and collect their <b>signature cues</b>.',w:440},
  {sel:'.pzboard9',side:'right',title:"Tonight's tables",text:'Each regular plays better than the last; the stars show how tough they are. Beat one to open the next table. <b>Click a name</b> (or use <kbd>↑</kbd> <kbd>↓</kbd>) to pick your opponent.',w:340},
  {sel:'#pzopp',side:'left',title:'Know your opponent',text:'Every regular has a <b>house rule</b> and a weakness (the tip). Pick a <b>stake chip</b> (or <kbd>←</kbd> <kbd>→</kbd>): the card shows what a win pays. Beat them 3 times to earn their cue.',w:330},
  {sel:'#pzrackem',side:'left',title:"Rack 'em up!",text:'Starts the match. Paid matches take your stake now and pay it back, with the winnings, if you win.',w:330},
  {sel:'#pzprac',side:'left',title:'New to pool?',text:'<b>Practice</b> against the selected regular is free: no stake, no pressure. It is the best place to learn the controls.',w:330},
  {sel:['.pznav button[data-a="trick"]','.pznav button[data-a="cues"]'],side:'right',title:'Trick Shots and the Cue Rack',text:'<b>Trick Shots</b> are one-shot puzzles that pay gold for stars. The <b>Cue Rack</b> holds the cues, felts and ball sets you win or buy. They only change the look.',w:340},
  {sel:['.pznav button[data-a="regs"]','.pznav button[data-a="rules"]'],side:'right',title:'Your record and the rules',text:'<b>The Regulars</b> keeps your record and trophies. <b>How to Play</b> has the rules and controls, and a button to see these tips again. Ready?',w:340,extra:['Practice first',()=>{pzMusicOff();pzStart({opp:'gloop',practice:true})}]}
 ],{kicker:'THE CROOKED CUE',last:'Got it'})},700)}
{const f0=pzTrick;pzTrick=function(){const r=f0.apply(this,arguments);try{const Z=PZS(),tk=PZ.tok;if(!Z.tut.trick)setTimeout(()=>{if(PZ.tok!==tk||pzCoachActive()||!ov.querySelector('.pzti'))return;
 pzCoach('trick',[
  {sel:'.pzti',side:'right',title:'Trick Shots',text:'Every puzzle is <b>one shot</b> from a set layout, with a goal under its name. Click a card to try it; a miss puts the balls back.',w:340},
  {sel:'.pztsub',side:'bottom',title:'Stars and gold',text:'Make it within <b>3 tries</b> for 3 stars, within 8 for 2. Your first 3 stars on a puzzle pay <b>200 gold</b>. Granny Moldwick will give you a hint.',w:420}
 ],{kicker:'FIRST VISIT'})},900)}catch(e){}return r}}
{const f0=pzCueRack;pzCueRack=function(){const r=f0.apply(this,arguments);try{const Z=PZS(),tk=PZ.tok;if(!Z.tut.rack)setTimeout(()=>{if(PZ.tok!==tk||pzCoachActive()||!ov.querySelector('.pzkwall'))return;
 pzCoach('rack',[
  {sel:'.pzktabs',side:'bottom',title:'The Cue Rack',text:'Your <b>cues</b>, table <b>felts</b> and <b>ball sets</b>. Switch between them here.',w:360},
  {sel:'.pzkwall',side:'right',title:'Win them or buy them',text:'Signature cues come from beating a regular <b>3 times</b>; felts and ball sets from beating certain regulars. Some can be bought with gold.',w:340},
  {sel:'.pzkdet',side:'left',title:'Equip',text:'Pick anything you own and press <b>Equip</b>. You will see it at your next match.',w:320}
 ],{kicker:'FIRST VISIT'})},900)}catch(e){}return r}}
