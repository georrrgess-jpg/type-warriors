/* ===== RUNESTONE TOWER DEFENSE 9.9s: ability tooltips stay on screen (97n) =====
   The 9.2 tower bar (95m) centres every .rptip on its card (translateX(-50%)) with a higher specificity than the ability rule
   `.rpab .rptip{left:0;transform:none}`, so the Overcharge tooltip (the leftmost button) was pushed half off the left edge. Ability
   tooltips are now anchored to the left edge of their button and grow from its lower left corner. */
{const st=document.createElement('style');st.textContent=`.rph.rp7 .rpab .rptip{left:0;right:auto;transform:scale(.81);transform-origin:0 100%;z-index:12}.rph.rp7.rptyon .rpab .rptip{bottom:calc(100% + 50px)}`;document.head.appendChild(st)}
