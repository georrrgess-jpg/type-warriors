# python3 t_ia102.py [game.html] [--nosoak] [--soak-only] [--long] : Runestone Tower Defense 10.2 - tower and monster interactions
# with all fourteen towers (the Moonblade Sentinel and the Phantom Lantern included; 99f fixes).
# A. Every map (World 1, the Wonderland, Worlds 2 and 3): all fourteen towers (rotated through the waves where a map has fewer pads),
#    three waves at 3x with every monster type spawned on top: no page errors, no NaN (monsters, glaives, wisps, souls, phantoms), every
#    monster dies once or leaks, none leaves its road, every wave ends, every effect is gone a few seconds after each wave, the damage
#    meter adds up (live towers + sold towers + map hazards = all health lost) and both new towers deal damage.
# B. The 10.1 rules (98p) for all fourteen: hidden monsters, fog, Glowcaps, jams, skins, Performance mode, frame cost.
# C. The new towers against every monster ability (shell, puff, glimmer, shed, song, ink, dive + crablings, guard, vents, haste, leap,
#    EMP, stomp + plates, boss phases, healers, oozes), slows (Frost, Moonlit Wake, Grave Chill, honey, Slow Field, slow immunity),
#    armor and armor-piercing, Starfall marks, pollen, Overcharge, wading, storm rods.
# D. Fourteen towers x every monster: damage applies and is booked on the right tower; every monster each tower can reach dies, pays once.
# E. Selling / upgrading mid-action, effects of removed towers, end of a wave, game over, leaving, pause, speed 1x-3x, early calls.
# F. Phantoms on every road of every map (bridges, the switch track, crossing roads); the Moonlit Wake stays on the road.
# S. Soak: full Wonderland and world-map battles with all fourteen towers upgraded at 3x, and a randomized fuzz (builds, upgrades,
#    sells, abilities, early waves, pauses, speeds, target modes) over many minutes of game time. --long runs it longer.
import asyncio,os,sys,json,time
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
ARGS=[a for a in sys.argv[1:] if not a.startswith('--')];FL=[a for a in sys.argv[1:] if a.startswith('--')]
H='file://'+os.path.abspath(ARGS[0] if ARGS else os.path.join(HERE,'out.html'))
SHOTS=os.environ.get('IA_SHOTS',os.path.join(HERE,'shots','w102_ia'))
DO_SOAK='--nosoak' not in FL;ONLY_SOAK='--soak-only' in FL;LONG='--long' in FL
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:700]),flush=True)
    if not ok:FAIL.append(name)
MAPS=['moss','frost','ember','wonder','coral','wreck','abyss','meadow','foundry','storm']
SETUP="()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const r=RPP();r.new99j=1;r.dragon=1;for(const m of ['moss','frost','ember','coral','wreck','abyss','meadow','foundry','storm'])r.stars[m]=3;for(const k in r.tut)r.tut[k]=1;for(const k of ['abil','coins','rune','upgrade','wave'])r.tut[k]=1;for(const m of RP_MAPS)r.tut['twist_'+m.id]=1;save()}"
LIB=r"""()=>{const TW=RP_TWORDER.slice();
 const IA=window.IA={TW,log:null};
 /* test-only outermost wrappers: kill transitions per monster (e._iaK) and an optional log of every rpHurt call */
 if(!window._iaW){window._iaW=1;
  const k0=rpKillFoe;rpKillFoe=function(e,src){const was=!e||e.dead;const r=k0.apply(this,arguments);if(!was&&e.dead)e._iaK=(e._iaK||0)+1;return r};
  const h0=rpHurt;rpHurt=function(e,dmg,ap,src){const L=IA.log;if(!L||!e||e.dead)return h0.apply(this,arguments);const hp=e.hp;const r=h0.apply(this,arguments);
   L.push({id:e.id,uid:e.uid,t:src&&src.type||(src?'obj':null),src,dmg,ap,lost:hp-Math.max(0,e.hp),dead:!!e.dead,arm:e.armor,hide:!!e.hide});return r};
  const l0=rplnLaunch;rplnLaunch=function(R,tw,e,dmg,hd,from,jump){if(!jump&&tw)tw._iaL=(tw._iaL||0)+1;return l0.apply(this,arguments)}}
 IA.go=(m,fn)=>{rpStart(m);const R=RPX;R.tut=null;R.hold=false;R.supply=1e7;R.wave=3;R.wst='run';R.q=[];R.cd=999;if(R.cannon)R.cannon.t=1e9;if(R.gust)R.gust.t=1e9;if(R.rodK){R.boltT=1e9;R.boltTwT=1e9}if(R.tide){R._tide=R.tide;R.tide=null}
  try{return fn(R)}catch(x){return 'ERR '+String(x.stack).slice(0,500)}finally{IA.log=null;rpLeave()}};
 IA.step=(R,n)=>{for(let i=0;i<n;i++)rpStep(R,1/30)};
 IA.bt=(R,pd,t,tier)=>{if(pd.tw)rpSell(pd.tw);rpBuild(pd,t);const tw=pd.tw;tw.build=1;for(let k=1;k<(tier||1);k++){tw.upK=1;if(!rpUpgrade(tw))break}tw.upK=1;return tw};
 /* a monster put on the road at a straight-line distance lo..hi from (x,y) */
 IA.place=(R,id,x,y,lo,hi,pi0)=>{for(let pi=0;pi<R.G.paths.length;pi++){if(pi0!=null&&pi!==pi0)continue;const L=R.G.paths[pi].len;for(let s=40;s<L-60;s+=3){const p=rpAt(R.G,s,pi);const d=Math.sqrt(rpD2(p.x,p.y,x,y));if(d>lo&&d<hi){const e=rpSpawn(id,pi);e.s=s;e._s=-1;e.off=0;return e}}}return null};
 IA.tank=(e,hp)=>{e.hp=e.mx=hp||1e7;e.sp=.01;return e};
 IA.FX=['shots','mtShells','mtCraters','mtBooms','alFlasks','alPools','tdJets','tdWaves','tdWhirls','tdLevs','sfStars','gvOrbs','gvWells','hvPools','hvBursts','burns','fields','mbGl','mbWake','mbEcl','lnWisps','lnSouls','lnPh'];
 IA.clr=R=>{for(const k of IA.FX)if(R[k])R[k]=[]};
 IA.reset=R=>{R.foes=[];IA.clr(R);for(const p of R.pads)if(p.tw)rpSell(p.tw);R.rpqSold=[];R.rpqUn=0;R.rpqTot=0;R.q=[];R.wst='run';R.cd=999;R.wave=3;R.rpqDue=[];R.hold=false};
 IA.nearPad=(R,e,minD)=>{const q=rpPos(R,e);return [...R.pads].sort((a,b)=>Math.hypot(a.x-q.x,a.y-q.y)-Math.hypot(b.x-q.x,b.y-q.y)).find(p=>Math.hypot(p.x-q.x,p.y-q.y)>(minD||0))};
 /* a pad with road at lo..hi (fraction of the tower's tier-3 range) of it, and the monster there */
 IA.pair=(R,t,id,lo,hi,k)=>{const rg=t==='star'?200:RP_TW[t].range[2];const P=[...R.pads];for(let j=0;j<P.length;j++){const pd=P[(j+(k||0))%P.length];if(pd.tw)continue;const e=IA.place(R,id,pd.x,pd.y,rg*(lo||.35),rg*(hi||.75));if(e)return [pd,e]}return [null,null]};
 /* the damage meter: live towers + sold ones + hazards vs. everything booked */
 IA.meter=R=>{let s=R.rpqUn||0;for(const x of rpqDmList(R))s+=x.d;return [Math.round(s),Math.round(R.rpqTot||0)]};
 /* NaN in any moving effect of the new towers */
 IA.nanFx=R=>{let n=0;const bad=v=>typeof v!=='number'||!isFinite(v);for(const g of R.mbGl||[])if(bad(g.X)||bad(g.Y)||bad(g.h)||bad(g.u))n++;for(const w of R.lnWisps||[])if(bad(w.x)||bad(w.y))n++;
  for(const s of R.lnSouls||[])if(bad(s.x)||bad(s.y))n++;for(const p of R.lnPh||[])if(bad(p.x)||bad(p.y)||bad(p.s))n++;for(const w of R.mbWake||[])if(bad(w.x)||bad(w.y))n++;return n};
 IA.left=R=>{const left=[];for(const k of IA.FX.concat(['inks','emps','bolts']))if(k!=='mbWake'&&k!=='fields'&&R[k]&&R[k].length)left.push(k+':'+R[k].length);if((R.mbWake||[]).length)left.push('mbWake:'+R.mbWake.length);
  for(const p of R.pads){const tw=p.tw;if(!tw)continue;if(tw.jam>0)left.push('jam '+tw.type);if(tw.beams&&tw.beams.length)left.push('beam '+tw.type);if(tw.type==='dragon'&&(tw.dive||tw.streams||tw.st==='breath'))left.push('dragon '+tw.st);
   if(tw.type==='hive'&&(tw.bees||[]).some(b=>b.m!=='in'&&b.e&&!b.e.dead))left.push('bees on a target');if(tw.type==='hive'&&tw.qn&&tw.qn.m!=='perch')left.push('queen out');
   if(tw.type==='moon'&&(tw.mbOut>0||(tw.mbHold||[1,1,1]).some(h=>!h)))left.push('glaives out '+tw.mbOut);if(tw.type==='lant'&&tw.inc>0)left.push('souls due '+tw.inc)}
  if(R.foes.some(e=>!e.dead))left.push('foes '+R.foes.filter(e=>!e.dead).length);if(R.foes.some(e=>e.lnT>0&&!e.dead))left.push('haunts');if(R.tide&&R.tide.k>0)left.push('tide '+R.tide.k);if(R.gust&&R.gust.k>0)left.push('gust');return left};
 return Object.keys(IA).length}"""
# ---------- A: every map, all fourteen towers, three waves at 3x, every monster ----------
PLAY=r"""(m)=>{const IA=window.IA,TW=IA.TW;rpStart(m);const R=RPX;R.tut=null;R.hold=false;R.supply=1e8;R.hp=1e9;
 const out={m,err:[],nan:0,fxnan:0,road:0,back:0,stuck:[],left:[],waves:[],fx:[],spawned:0,types:[],twice:0,nopay:0,phRoad:0,phBack:0,meter:[],newD:{}};
 const top=R.map.maxT||RP_MAXT(R.map),pads=R.pads.slice(),np=pads.length,others=TW.filter(t=>t!=='moon'&&t!=='lant'),seenT=new Set();
 /* wave w: the Moonblade and the Lantern always, the other twelve rotated through the remaining pads; tiers vary 1..cap */
 const lay=w=>{const want=['moon','lant'];for(let j=0;want.length<Math.min(np,TW.length);j++)want.push(others[(w*(np-2)+j)%others.length]);
  pads.forEach((p,i)=>{const t=want[(i*5+w)%want.length];if(p.tw&&p.tw.type===t)return;if(p.tw)rpSell(p.tw);rpBuild(p,t);if(p.tw){p.tw.build=1;const n=1+((i+w)%top);for(let k=1;k<n;k++){p.tw.upK=1;rpUpgrade(p.tw)}p.tw.upK=1}});
  for(const p of pads)if(p.tw)seenT.add(p.tw.type)};
 const ids=Object.keys(RP_FOE).filter(id=>!/_p\d$/.test(id));const all=new Map(),seen=new Set(),last=new Map();R.spd=3;
 for(let w=0;w<3;w++){lay(w);R.wst='build';R.cd=0;rpWaveStart();const W=R.wave;let k=0,t=0;
  while(R.wst==='run'&&t<300){if(k<ids.length&&t>1+k*.35){const id=ids[k++];const e=rpSpawn(id);if(e){out.spawned++;if(RP_FOE[id].boss){e.hp=e.mx=Math.round(e.mx*.25)}}}
   R.hold=false;R.pause=false;try{rpUpdate(1/30)}catch(x){out.err.push(String(x.stack).slice(0,300));break}t+=3/30;
   if(((t*10)|0)%7===0)try{rpDraw()}catch(x){out.err.push('draw '+String(x.stack).slice(0,300));break}
   out.fxnan+=IA.nanFx(R);
   for(const ph of R.lnPh){if(ph.st!=='march')continue;const p=rpAt(R.G,ph.s,ph.pi);if(Math.hypot(p.x-ph.x,p.y-ph.y)>1||ph.s<0||ph.s>R.G.paths[ph.pi].len)out.phRoad++;const o=last.get(ph);if(o!=null&&ph.s>o+1e-6)out.phBack++;last.set(ph,ph.s)}
   for(const e of R.foes){all.set(e.uid,e);if(e.dead)continue;if(!isFinite(e.s)||!isFinite(e.hp)||!isFinite(e.sp)||!isFinite(e.armor)||!isFinite(e.slowK||0)||(e.slowK||0)>=1)out.nan++;
    if(e.s>rpLen(R,e)+1||e.s<-70)out.road++;if(e.s>=0)seen.add(e);else if(seen.has(e))out.back++;
    const q=rpPos(R,e);if(!isFinite(q.x)||!isFinite(q.y))out.nan++}}
  if(R.wst==='run')out.stuck.push(W+': '+R.foes.filter(e=>!e.dead).slice(0,6).map(e=>e.id+'@'+Math.round(e.s)+' hp'+Math.round(e.hp)+(e.hide?' hid':'')).join(', '));
  out.waves.push(W);
  /* a few seconds after the wave: every effect has run its course */
  for(let i=0;i<30*8;i++){rpStep(R,1/30);out.fxnan+=IA.nanFx(R)}
  out.fx.push(IA.left(R).join(' '));out.meter.push(IA.meter(R))}
 for(const e of all.values()){if(!e.dead)out.left.push(e.id+'@'+Math.round(e.s));if((e._iaK||0)>1)out.twice++;if(e.dead&&!e.leak&&!e._iaK)out.nopay++}
 const kills=[...all.values()].filter(e=>e._iaK).length;out.killsOk=kills===R.kills;
 for(const x of rpqDmList(R))out.newD[x.type]=Math.round((out.newD[x.type]||0)+x.d);
 out.types=[...seenT];out.kills=R.kills;out.leaked=R.leaked;rpLeave();out.rpx=RPX===null;return out}"""
# ---------- B: the 10.1 rules (98p) for all fourteen towers ----------
FIX=r"""()=>{const IA=window.IA,o={},TW=IA.TW;const {go,step,bt,place,tank,nearPad}=IA;
 /* hidden: a diving Leviathan; no tower aims, fires, beams, slows, shoves, haunts or cuts it */
 o.aimHid=go('abyss',R=>{const res={};for(const t of TW){IA.reset(R);const e=tank(rpSpawn('leviathan',0),1e6);e.s=R.G.paths[0].len*.4;e._s=-1;e.dvI=0;e.dive=60;e.hide=1;
   const pd=t==='star'?R.pads[0]:nearPad(R,e,110);const tw=bt(R,pd,t,4);if(t==='lant'){e.lnT=3;e.lnH=60;e.lnS=tw;tw.souls=RP_TW.lant.souls[3]}IA.clr(R);const h=e.hp;step(R,150);
   const n=R.mtShells.length+R.alFlasks.length+R.tdJets.length+R.sfStars.length+R.gvOrbs.length+R.shots.length+(R.mbThrows||0)+(R.lnShots||0)+(R.lnPhN||0);
   res[t]=[Math.round(h-e.hp),n,(tw.beams||[]).length,e.slowT>0?1:0,e.kb>0?1:0].join('|');rpSell(tw)}return res});
 /* fog: no tower picks a fogged monster from beyond 150 px; they do once the fog drifts off */
 o.fog=go('wreck',R=>{R.fog.forEach(g=>{g.x=-3000;g.v=0});const res={};for(const t of TW.filter(t=>t!=='frost')){let done=0;for(const p of R.pads){if(done)break;if(p.tw)rpSell(p.tw);R.foes=[];const rg=t==='star'?260:RP_TW[t].range[2]||300;const e=place(R,'brute',p.x,p.y,175,Math.min(230,rg*.95));if(!e)continue;
   const tw=bt(R,p,t,3);const q=rpPos(R,e);const f=R.fog[0];f.x=q.x;f.y=q.y;f.rx=60;f.ry=40;tank(e,1e6);e.armor=e.arm0=0;IA.clr(R);const h=e.hp;step(R,120);const fd=e.fogd;const d1=Math.round(h-e.hp);f.x=-3000;step(R,150);res[t]=[fd,d1,Math.round(h-e.hp)>d1?1:0].join('|');rpSell(tw);done=1}if(!done)res[t]='nos'}return res});
 /* Glowcaps: +15% range for every tower (the Starfall reaches the whole map) */
 o.glow=go('abyss',R=>{const res={};const pads=R.pads.filter(p=>p.glow),plain=R.pads.filter(p=>!p.glow);const r0=JSON.stringify(TW.map(t=>RP_TW[t].range));
   for(const t of TW.filter(t=>t!=='star')){const one=(P)=>{for(const p of P){R.foes=[];IA.clr(R);const tw=bt(R,p,t,1);const rg=RP_TW[t].range[0];const e=place(R,'brute',tw.x,tw.y,rg*1.03,rg*1.11);if(!e){rpSell(tw);continue}tank(e,1e6);e.armor=e.arm0=0;const h=e.hp;step(R,150);rpSell(tw);return Math.round(h-e.hp)}return 'nos'};res[t]=[one(pads),one(plain)].join('|')}
   const p=pads[0];for(const t of ['moon','lant','frost']){const tw=bt(R,p,t,1);R.sel=tw;rpDraw();R.sel=null}res.same=JSON.stringify(TW.map(t=>RP_TW[t].range))===r0;return res});
 /* jams: all fourteen towers stop and resume */
 o.jam=go('meadow',R=>{const res={};for(const t of TW){IA.reset(R);const L=R.G.paths[0].len;
   for(let k=0;k<6;k++){const e=rpSpawn(t==='bell'||t==='hive'?'gyro':'brute',0);e.s=L*.45+k*14;e._s=-1;tank(e);e.armor=e.arm0=0}
   const pd=t==='star'?R.pads[0]:nearPad(R,R.foes[0],120);const tw=bt(R,pd,t,3);if(t==='lant')tw.souls=6;step(R,150);const d0=tw.dmg;tw.jam=6;tw.jamBy='emp';const th=R.mbThrows||0,ls=tw._iaL||0,lp=R.lnPhN||0;step(R,15);const d15=tw.dmg;step(R,90);const d1=tw.dmg,bm=(tw.beams||[]).length,ch=tw.charge||0;
   const gl=(R.mbGl||[]).length,nt=(R.mbThrows||0)-th+(tw._iaL||0)-ls+(R.lnPhN||0)-lp;step(R,75);const d2=tw.dmg;R.foes.forEach((e,k)=>{e.s=L*.45+k*14;e._s=-1});step(R,150);const d3=tw.dmg;
   res[t]=[d0>0?1:0,Math.round(d2-d1),d3>d2?1:0,bm,+ch.toFixed(2),gl,nt,t==='moon'?Math.round(d1-d15):0].join('|')}return res});
 /* mastery skins never change stats (the new towers too) */
 o.skin=go('coral',R=>{const res=[];for(const sk of ['base','m5']){IA.reset(R);const L=R.G.paths[0].len;const es=[];for(let k=0;k<4;k++){const e=rpSpawn('brute',0);e.s=L*.4+k*20;e._s=-1;e.off=0;tank(e);es.push(e)}
   const tws=['ballista','moon','lant','frost'].map((t,i)=>{const tw=bt(R,R.pads.filter(p=>!p.tw).sort((a,b)=>{const q=rpPos(R,es[0]);return Math.hypot(a.x-q.x,a.y-q.y)-Math.hypot(b.x-q.x,b.y-q.y)})[0],t,3);tw.skin=sk;tw.cd=.3;return tw});
   const r0=Math.random;let sd=7;Math.random=()=>{sd=(sd*16807)%2147483647;return sd/2147483647};try{step(R,150)}finally{Math.random=r0}res.push(tws.map(t=>Math.round(t.dmg)).join(','))}return res});
 /* Performance mode with all fourteen */
 o.lite=go('foundry',R=>{R.lite=1;for(const p of R.pads)bt(R,p,TW[R.pads.indexOf(p)%TW.length],4);for(const p of R.pads)if(p.tw&&p.tw.type==='lant')p.tw.souls=5;const ids=['cog','knight','steam','gyro','tinker','spring','jammer'];let err=0;
  for(let i=0;i<30*20;i++){R.rm=i>=300?1:0;if(i%15===0){const e=rpSpawn(ids[(i/15)%ids.length]);e.s=Math.random()*rpLen(R,e)*.8;e._s=-1}try{rpStep(R,1/30);if(i%10===0)rpDraw()}catch(x){err++}}return [err,R.kills,R.mbThrows,R.lnShots,R.lnPhN]});
 /* How to Play and help: fourteen towers, both new towers explained */
 o.howto=(()=>{try{rampartsMenu(title);rpHowTo();const t=[...ov.querySelectorAll('#rpmod .rphw p')].map(p=>p.textContent).join(' ');hide();return [/Moonblade Sentinel\./.test(t),/Phantom Lantern\./.test(t),/All fourteen are open/i.test(t)]}catch(x){return 'ERR '+x}})();
 /* speed x3 and pause */
 o.speed=go('coral',R=>{R.spd=3;const e=rpSpawn('crab',0);e.s=100;e._s=-1;tank(e);const t0=R.time;rpUpdate(1/30);const a=[+(R.time-t0).toFixed(3)];R.pause=true;const t1=R.time,s1=e.s;rpUpdate(1/30);a.push(R.time===t1&&e.s===s1);R.pause=false;return a});
 return o}"""
COST=r"""()=>{const IA=window.IA;return IA.go('storm',R=>{R.lite=0;const res={};for(const p of R.pads)IA.bt(R,p,IA.TW[R.pads.indexOf(p)%IA.TW.length],5);
 const ids=['cog','knight','steam','gyro','tinker','spring','jammer','crab','shell','jelly','siren'];for(let k=0;k<70;k++){const e=rpSpawn(ids[k%ids.length]);e.s=Math.random()*1200;e._s=-1;IA.tank(e)}
 const g=R.foes.filter(e=>e.id==='spring'||e.id==='jelly');g.forEach((e,i)=>{if(i%2)e.lpT=.01});for(const p of R.pads)if(p.tw&&p.tw.type==='lant')p.tw.souls=5;
 const B=typeof RPIB!=='undefined'?RPIB:{};const run=(off)=>{B.off=off;let t=0;for(let i=0;i<120;i++){const a=performance.now();rpStep(R,1/30);t+=performance.now()-a}B.off=0;return t/120};
 run(0);const a=[],b=[];for(let k=0;k<5;k++){b.push(run(1));a.push(run(0))}a.sort((x,y)=>x-y);b.sort((x,y)=>x-y);res.ms=+a[2].toFixed(3);res.off=+b[2].toFixed(3);res.n=R.foes.filter(e=>!e.dead).length;res.gl=R.mbGl.length;res.ph=R.lnPh.length;res.w=R.lnWisps.length;
 return res})}"""
# ---------- C: the Moonblade Sentinel and the Phantom Lantern against every ability, slow, armor rule and bonus ----------
NEW=r"""()=>{const IA=window.IA,o={};const {go,step,bt,place,tank,nearPad}=IA;
 const solo=(R,t,tier,id,lo,hi,k)=>{IA.reset(R);const [pd,e]=IA.pair(R,t,id,lo||.3,hi||.6,k);if(!pd)return {};tank(e,1e6);e.sp=0;const tw=bt(R,pd,t,tier);return {tw,e,pd}};
 const H=(L,e,t,f)=>L.filter(x=>x.uid===e.uid&&x.t===t&&(!f||f(x)));
 const U=a=>[...new Set(a.map(v=>Math.round(v*100)/100))].sort((x,y)=>x-y);
 const kind=x=>x.ap>=99?(x.dmg<20?'haunt':'ph'):'wisp';
 /* 1. armor and armor-piercing on a Steam Golem (armor 9): glaive per tier, the eclipse; wisp (no piercing), haunt and phantom (through armor) */
 o.ap=go('meadow',R=>{const r={moon:[],lant:[]};for(let tier=1;tier<=5;tier++){const {tw,e}=solo(R,'moon',tier,'steam');if(!tw){r.moon.push('nos');continue}IA.log=[];step(R,30*(tier>=5?16:5));
   const L=H(IA.log,e,'moon');r.moon.push(U(L.map(x=>x.lost)).join('/'))}
  for(let tier=1;tier<=5;tier++){const {tw,e}=solo(R,'lant',tier,'steam');if(!tw){r.lant.push('nos');continue}tw.souls=RP_TW.lant.souls[tier-1];if(tier>=5)tw.rel=2;IA.log=[];step(R,30*5);
   const L=H(IA.log,e,'lant'),k={};for(const x of L){const g=kind(x);(k[g]=k[g]||[]).push(Math.round((x.dmg-x.lost)*1000)/1000)}r.lant.push(Object.keys(k).sort().map(g=>g+':'+U(k[g]).join('/')).join(' '))}return r});
 /* 2. Shellback in its shell (armor 5 + 12) */
 o.shell=go('coral',R=>{const r=[];for(const [t,tier] of [['moon',1],['moon',2],['moon',3],['lant',1]]){const {tw,e}=solo(R,t,tier,'shell');if(!tw){r.push('nos');continue}e.shIn=1e9;step(R,2);const a=e.armor;IA.log=[];step(R,150);
   const L=H(IA.log,e,t,x=>t==='moon'||kind(x)==='wisp');r.push(a+':'+U(L.map(x=>x.lost)).join('/')+(t==='lant'?' haunt '+U(H(IA.log,e,t,x=>kind(x)==='haunt').map(x=>x.dmg-x.lost)).join('/'):''))}return r});
 /* 3. Reef Puffer puffs up at half health (armor 2 + 6) */
 o.puff=go('coral',R=>{const {tw,e}=solo(R,'moon',2,'puffer');if(!tw)return 'nos';IA.log=[];step(R,90);const a=U(H(IA.log,e,'moon').map(x=>x.lost)).join('/');e.hp=e.mx*.4;step(R,2);const arm=e.armor;IA.log=[];step(R,90);return [a,arm,U(H(IA.log,e,'moon').map(x=>x.lost)).join('/')]});
 /* 4. Barnacle Brute: armor falls with health (14 -> 7 at half) */
 o.brute=go('coral',R=>{const r=[];for(const t of ['moon','lant']){const {tw,e}=solo(R,t,1,'brute');if(!tw){r.push('nos');continue}IA.log=[];step(R,90);const a=U(H(IA.log,e,t,x=>t==='moon'||kind(x)==='wisp').map(x=>x.lost)).join('/');
   e.hp=e.mx*.5;IA.log=[];step(R,90);r.push(a+' > '+U(H(IA.log,e,t,x=>t==='moon'||kind(x)==='wisp').map(x=>x.lost)).join('/')+' arm '+e.armor)}return r});
 /* 5. Siren song shields absorb first; the meter books only the health lost */
 o.song=go('coral',R=>{const r=[];for(const t of ['moon','lant']){const {tw,e}=solo(R,t,1,'crab');if(!tw){r.push('nos');continue}e.hp=e.mx=1000;const s=rpSpawn('siren',e.pi);s.s=e.s+12;s._s=-1;tank(s,1e6);s.sp=0;s.sgT=.01;
   step(R,2);const sh=e.shield;IA.log=[];const h0=e.hp,d0=tw.rpqD||0;step(R,t==='moon'?45:75);const L=H(IA.log,e,t),dmg=L.reduce((a,x)=>a+x.dmg,0),lost=L.reduce((a,x)=>a+x.lost,0);
   r.push([Math.round(sh),Math.round(dmg),Math.round(dmg-lost),Math.round(h0-e.hp),Math.round((tw.rpqD||0)-d0-(H(IA.log,s,t).reduce((a,x)=>a+x.lost,0)))])}return r});
 /* 6. Reef Inkling: inks the nearest tower when hurt (2.5 s); glaives fly home, no new throws or wisps; both resume */
 o.ink=go('coral',R=>{const r={};for(const t of ['moon','lant']){const {tw,e}=solo(R,t,4,'squid',.2,.45);if(!tw){r[t]='nos';continue}const c=()=>t==='moon'?R.mbThrows:(tw._iaL||0);step(R,60);const n0=c();e.hp=e.mx*.5;
   let jam=0,by='',k=0;while(!(tw.jam>0)&&k++<60)step(R,1);jam=tw.jam;by=tw.jamBy;const n1=c();IA.log=[];step(R,8);const cutJ=H(IA.log,e,t,x=>x.lost>0&&t==='moon').length;
   step(R,Math.ceil(jam*30)-10);const n2=c();step(R,90);r[t]=[by,+jam.toFixed(1),n1>n0?1:0,n2-n1,cutJ,(R.mbGl||[]).filter(g=>g.tw===tw&&!g.home).length,c()>n2?1:0,tw.jamImm>0?1:0].join('|')}return r});
 /* 7. Leviathan: no hits while it dives, its Crablings are cut and haunted; a phantom walks past a diving Leviathan */
 o.dive=go('abyss',R=>{const r={};for(const t of ['moon','lant']){const {tw,e}=solo(R,t,4,'leviathan',.25,.5);if(!tw){r[t]='nos';continue}e.hp=e.mx*.7;step(R,3);const dv=e.dive>0;IA.log=[];let k=0;while(e.dive>0&&k++<120)step(R,1);
   const hid=IA.log.filter(x=>x.uid===e.uid&&x.t===t&&x.hide&&x.lost>0).length,crabs=R.foes.filter(f=>f.id==='crab');crabs.forEach(f=>{f.sp=0});IA.log=[];step(R,120);
   r[t]=[dv?1:0,hid,crabs.length,crabs.filter(f=>IA.log.some(x=>x.uid===f.uid&&x.t===t&&x.lost>0)).length].join('|')}
  /* a phantom passes a diving Leviathan and cuts the Crablings around it */
  const {tw,e}=solo(R,'lant',4,'leviathan',.2,.5);if(!tw)return r;e.dive=60;e.dvI=1;const cs=[];for(let k=0;k<3;k++){const c=rpSpawn('crab',e.pi);c.s=e.s-30-k*25;c._s=-1;tank(c,1e5);c.sp=0;cs.push(c)}
  tw.souls=5;tw.cd=99;IA.log=[];let ph=null;for(let i=0;i<30*9;i++){rpStep(R,1/30);tw.cd=99;if(!ph&&R.lnPh.length)ph=R.lnPh[0]}
  r.ph=[!!ph,ph?ph.hit.has(e):'-',IA.log.filter(x=>x.uid===e.uid&&x.t==='lant').length,cs.filter(c=>IA.log.some(x=>x.uid===c.uid&&x.t==='lant'&&x.ap>=99&&x.lost>0)).length].join('|');return r});
 /* 8. Brass Knight guard: 25% less damage to the monster it guards, never to another knight */
 o.guard=go('meadow',R=>{const r={};for(const t of ['moon','lant']){const {tw,e}=solo(R,t,3,'knight',.3,.55);if(!tw){r[t]='nos';continue}const c=rpSpawn('cog',e.pi);c.s=e.s-30;c._s=-1;tank(c,1e6);c.sp=0;const k2=rpSpawn('knight',e.pi);k2.s=e.s-50;k2._s=-1;tank(k2,1e6);k2.sp=0;
   IA.log=[];step(R,120);const f=x=>t==='moon'||x.ap>=99;r[t]=[+(c.guardK||0).toFixed(2),+(k2.guardK||0).toFixed(2),U(H(IA.log,c,t,f).map(x=>x.lost/x.dmg)).join('/'),U(H(IA.log,k2,t,f).map(x=>x.lost/x.dmg)).join('/')].join('|')}return r});
 /* 9. a venting Steam Golem ignores every slow (Frost, Moonlit Wake, Grave Chill, honey); afterwards they slow it again */
 o.vent=go('meadow',R=>{IA.reset(R);const L=R.G.paths[0].len;const e=rpSpawn('steam',0);e.s=L*.3;e._s=-1;e.hp=e.mx=1e6;const q=rpPos(R,e);
  const pads=[...R.pads].sort((a,b)=>Math.hypot(a.x-q.x,a.y-q.y)-Math.hypot(b.x-q.x,b.y-q.y));bt(R,pads[0],'moon',4);bt(R,pads[1],'frost',3);bt(R,pads[2],'hive',3);const ln=bt(R,pads[3],'lant',4);ln.souls=5;
  step(R,60);e.hp=e.mx*.8;let vs=0,vbad=0,after=0,mn=9;for(let i=0;i<30*8;i++){const s0=e.s;rpStep(R,1/30);const r=(e.s-s0)/(e.sp/30);if(e.vent>0&&!(e.stun>0)&&!e.ice){vs++;if(Math.abs(r-1)>.02)vbad++}else if(vs&&!(e.vent>0)){after++;mn=Math.min(mn,r)}if(e.hp<e.mx*.5)e.hp=e.mx*.9}
  return [vs,vbad,after,+mn.toFixed(2),R.mbWakeN>0?1:0]});
 /* 11. a leaping Springjack is never cut by a glaive passing over it (the glaive keeps its cut for later) */
 o.leap=go('meadow',R=>{const {tw,e}=solo(R,'moon',1,'cog',.4,.6);if(!tw)return 'nos';const sp=rpSpawn('spring',e.pi);sp.s=e.s+4;sp._s=-1;tank(sp,1e6);sp.sp=0;IA.log=[];const s0=sp.s;
  for(let i=0;i<150;i++){sp.leap=.3;sp.s=s0;sp._s=-1;rpStep(R,1/30)}const a=[IA.log.filter(x=>x.uid===sp.uid).length,H(IA.log,e,'moon').length>0?1:0];sp.leap=0;sp.lpT=99;IA.log=[];step(R,90);a.push(H(IA.log,sp,'moon').length>0?1:0);return a});
 /* 12. Sparkjammer EMP: jams each new tower once (then 4 s immunity) */
 o.emp=go('meadow',R=>{const r={};for(const t of ['moon','lant']){IA.reset(R);let best=null;for(const p of R.pads){const S=R.G.paths[0].S;for(let i=20;i<S.length-20;i+=2){const d=rpD2(S[i].x,S[i].y,p.x,p.y);if(!best||d<best.d)best={p,d,s:i*4}}}
   const e=rpSpawn('jammer',0);e.s=best.s;e._s=-1;tank(e,1e6);e.sp=0;const tw=bt(R,best.p,t,3);step(R,3);const a=[tw.jamBy,tw.jam>0?1:0];step(R,70);a.push(tw.jam>0?1:0,tw.jamImm>0?1:0);r[t]=a.join('|')}return r});
 /* 13. Titan: the stomp jams both, its plates fall (armor 14 -> 10 -> 6) and the wisps cut deeper */
 o.titan=go('storm',R=>{const r={};for(const t of ['moon','lant']){const {tw,e}=solo(R,t,1,'titan',.25,.5);if(!tw){r[t]='nos';continue}e.stT=.02;step(R,3);const a=[tw.jamBy,tw.jam>0?1:0];step(R,30*6);
   IA.log=[];step(R,60);const w0=U(H(IA.log,e,t,x=>t==='moon'||kind(x)==='wisp').map(x=>x.lost));e.stT=1e9;e.hp=e.mx*.6;step(R,2);const arm=e.armor;tw.jam=0;IA.log=[];step(R,60);
   a.push(w0.join('/'),arm,U(H(IA.log,e,t,x=>t==='moon'||kind(x)==='wisp').map(x=>x.lost)).join('/'));r[t]=a.join('|')}return r});
 /* 14. the Reaper: three times the cut on bosses, never an execute; non-bosses below 15% are finished */
 o.reap=go('storm',R=>{const r={};for(const id of ['titan','cog']){const {tw,e}=solo(R,'lant',5,id,.2,.45);if(!tw){r[id]='nos';continue}e.stT=1e9;e.hp=e.mx*.1;e.armor=e.arm0=e.armor;tw.souls=5;tw.rel=2;tw.cd=99;IA.log=[];const k0=R.kills;
   for(let i=0;i<30*9;i++){rpStep(R,1/30);tw.cd=99;if(e.dead)break}const P=H(IA.log,e,'lant',x=>x.ap>=99&&x.dmg>=90);r[id]=[R.lnReapN,P.length?Math.round(P[0].dmg):0,e.dead?1:0,R.lnFin||0,e.boss?1:0].join('|')}return r});
 /* 15. a Hex Shaman heals a haunted monster: no health above max */
 o.heal=go('moss',R=>{const {tw,e}=solo(R,'lant',3,'golem',.3,.55);if(!tw)return 'nos';e.hp=e.mx=600;const sh=rpSpawn('shaman',e.pi);sh.s=e.s+10;sh._s=-1;tank(sh,1e6);sh.sp=0;let over=0,nan=0,heals=0;let h=e.hp;
  for(let i=0;i<30*8;i++){rpStep(R,1/30);if(e.hp>e.mx+1e-9)over++;if(!isFinite(e.hp))nan++;if(e.hp>h)heals++;h=e.hp;if(e.dead)break}return [over,nan,heals>0?1:0,e.dead?1:0]});
 /* 16. an Ooze cut by a glaive: its Oozelets start on the road, are cut too, and every death feeds the Lantern's jar */
 o.ooze=go('moss',R=>{IA.reset(R);const L=R.G.paths[0].len;const e=rpSpawn('ooze',0);e.s=L*.35;e._s=-1;e.sp=0;e.hp=e.mx=20;const q=rpPos(R,e);const pads=[...R.pads].sort((a,b)=>Math.hypot(a.x-q.x,a.y-q.y)-Math.hypot(b.x-q.x,b.y-q.y));
  const m=bt(R,pads[0],'moon',3),ln=bt(R,pads[1],'lant',1);ln.cd=99;let kids=[];for(let i=0;i<30*6;i++){rpStep(R,1/30);ln.cd=99;for(const f of R.foes)if(f.id==='oozelet'&&!kids.includes(f)){kids.push(f);f.sp=0}}
  return [e.dead?1:0,kids.length,kids.filter(k=>k.s>=0).length,kids.filter(k=>k.dead).length,ln.souls+(ln.inc||0)]});
 /* 17. slows: the strongest one counts, a weaker one never lowers or shortens it; air and venting monsters are never slowed by the new towers */
 o.slow=go('meadow',R=>{IA.reset(R);const L=R.G.paths[0].len;const mk=(id)=>{const e=rpSpawn(id,0);e.s=L*.2+R.foes.length*30;e._s=-1;tank(e,1e6);e.sp=40;return e};const r={};
  const run=(e,n)=>{let mn=9,mx=0;for(let i=0;i<n;i++){const s0=e.s;rpStep(R,1/30);const v=(e.s-s0)/(e.sp/30);mn=Math.min(mn,v);mx=Math.max(mx,v)}return [+mn.toFixed(3),+mx.toFixed(3)]};
  let e=mk('cog');e.mbWk=1.5;r.wake=run(e,3).concat([+e.slowK.toFixed(2)]);
  e=mk('cog');e.slowK=.58;e.slowT=2.3;e.mbWk=1.5;rpStep(R,1/30);r.frostWake=[+e.slowK.toFixed(2),+e.slowT.toFixed(2)];
  e=mk('cog');e.hnS=1;e.mbWk=1.5;rpStep(R,1/30);const a=+e.slowK.toFixed(2);e.hnP=1;e.mbWk=1.5;rpStep(R,1/30);r.honeyWake=[a,+e.slowK.toFixed(2)];
  e=mk('cog');e.mbWk=1.5;rpStep(R,1/30);rplnChill(e);const c0=[+e.slowK.toFixed(2),+e.slowT.toFixed(2)];for(let i=0;i<20;i++){e.mbWk=1.5;rpStep(R,1/30)}c0.push(+e.slowK.toFixed(2));for(let i=0;i<60;i++){e.mbWk=1.5;rpStep(R,1/30)}c0.push(+e.slowK.toFixed(2));r.chillWake=c0;
  e=mk('cog');e.slowK=.58;e.slowT=2.3;rplnChill(e);r.chillFrost=[+e.slowK.toFixed(2),+e.slowT.toFixed(2)];
  e=mk('cog');const q=rpPos(R,e);R.fields.push({x:q.x,y:q.y,r:200,t:0,d:10});let mn=9;for(let i=0;i<10;i++){e.mbWk=1.5;const s0=e.s;rpStep(R,1/30);mn=Math.min(mn,(e.s-s0)/(e.sp/30))}R.fields=[];r.field=+mn.toFixed(3);
  const g=mk('gyro');g.mbWk=1.5;rplnChill(g);rpStep(R,1/30);r.air=[+(g.slowK||0).toFixed(2),g.slowT>0?1:0];
  let bad=0;for(const f of R.foes){if(!isFinite(f.slowK)||f.slowK>=1||f.slowK<0)bad++}r.bad=bad;return r});
 /* 18-22. Starfall marks, pollen, Overcharge, wading, storm rods: multipliers on glaives, wisps, haunts and phantoms */
 const mult=(m,setup,k)=>go(m,R=>{const r={};for(const t of ['moon','lant']){R.abCd.over=0;const {tw,e,pd}=solo(R,t,3,m==='coral'?'crab':'cog',.3,.55,k);if(!tw){r[t]='nos';continue}e.armor=e.arm0=0;if(t==='lant'){tw.souls=6}
   const ex=setup(R,tw,e,pd);if(ex==='nos'){r[t]='nos';continue}const T2=ex&&ex.tw||tw;IA.log=[];step(R,120);const L=H(IA.log,e,t,x=>x.dmg>.01);
   r[t]={k:U(L.map(x=>x.lost/x.dmg)),ex:ex&&ex.tw?ex.v:ex,n:L.length,kinds:[...new Set(L.map(x=>t==='moon'?'glaive':kind(x)))].sort().join(','),dmg:U(L.filter(x=>kind(x)!=='haunt').map(x=>x.dmg)),hd:U(L.filter(x=>kind(x)==='haunt').map(x=>x.dmg*30))}}return r});
 o.mark=mult('meadow',(R,tw,e)=>{e.mk=99;e.mkK=.25});
 o.pollen=go('meadow',R=>{const r={};let pr=null;for(const a of R.pads){for(const b of R.pads)if(a!==b&&Math.hypot(a.x-b.x,a.y-b.y)<=145){const e=IA.place(R,'cog',a.x,a.y,60,150);if(e){R.foes=[];pr=[a,b];break}}if(pr)break}if(!pr)return 'nopair';
   for(const t of ['moon','lant']){IA.reset(R);const e=IA.place(R,'cog',pr[0].x,pr[0].y,60,150);tank(e,1e6);e.sp=0;e.armor=e.arm0=0;const tw=bt(R,pr[0],t,3);if(t==='lant')tw.souls=6;bt(R,pr[1],'hive',4);step(R,20);const pol=tw.pol>0?1:0;IA.log=[];
    for(let i=0;i<120;i++){rpStep(R,1/30)}const L=H(IA.log,e,t,x=>x.dmg>.01);r[t]={k:U(L.map(x=>x.lost/x.dmg)),pol,kinds:[...new Set(L.map(x=>t==='moon'?'glaive':kind(x)))].sort().join(',')}}return r});
 o.over=mult('meadow',(R,tw,e)=>{rpAbility('over',tw);return tw.over>0?1:0});
 o.wade=mult('coral',(R,tw,e)=>{R.tide=R._tide;const m=R.map,z=m.tide.find(z=>{for(let s=40;s<R.G.paths[0].len-40;s+=4){const p=rpAt(R.G,s,0);if((p.x-z[0])**2+((p.y-z[1])/.8)**2<z[2]*z[2]*.5){e.s=s;e._s=-1;return true}}return false});if(!z)return 'nos';R.tide.t=RPWK.tideRamp+.5;
   const q=rpPos(R,e);const pd=[...R.pads].filter(p=>!p.tw).sort((a,b)=>Math.hypot(a.x-q.x,a.y-q.y)-Math.hypot(b.x-q.x,b.y-q.y))[0];rpSell(tw);const t2=bt(R,pd,tw.type,3);if(t2.type==='lant')t2.souls=6;step(R,2);return {tw:t2,v:e.wade}});
 o.rod=go('storm',R=>{const r={};for(const t of ['moon','lant']){IA.reset(R);const pd=R.pads.find(p=>p.rod);if(!pd){r[t]='norod';continue}const e=IA.place(R,'cog',pd.x,pd.y,60,150);if(!e){r[t]='nos';continue}tank(e,1e6);e.sp=0;e.armor=e.arm0=0;const tw=bt(R,pd,t,3);if(t==='lant')tw.souls=6;
   IA.log=[];step(R,120);r[t]=U(H(IA.log,e,t,x=>x.dmg>.01).map(x=>x.lost/x.dmg)).join('/')+' rod'+tw.rodK}return r});
 /* World 1: an ink blob in flight lands and an EMP ring fades after their monster died */
 o.w1fx=go('moss',R=>{IA.reset(R);let best=null;for(const p of R.pads){const S=R.G.paths[0].S;for(let i=20;i<S.length-20;i+=2){const d=rpD2(S[i].x,S[i].y,p.x,p.y);if(!best||d<best.d)best={p,d,s:i*4}}}
  const tw=bt(R,best.p,'moon',3);const j=rpSpawn('jammer',0);j.s=best.s;j._s=-1;tank(j,1e6);j.sp=0;rpStep(R,1/30);const a=[R.emps.length,tw.jamBy];rpKillFoe(j,null);for(let i=0;i<30*2;i++)rpStep(R,1/30);a.push(R.emps.length);
  tw.jam=0;tw.jamImm=0;const sq=rpSpawn('squid',0);sq.s=best.s;sq._s=-1;tank(sq,1e6);sq.sp=0;sq.hp=sq.mx*.5;rpStep(R,1/30);a.push(R.inks.length);rpKillFoe(sq,null);for(let i=0;i<30*2;i++)rpStep(R,1/30);a.push(R.inks.length,tw.jamBy,+(tw.jam||0).toFixed(1));return a});
 /* a jammed Sentinel's eclipse loses its edge with its glaives (it fades) */
 o.eclJam=go('meadow',R=>{const {tw,e}=solo(R,'moon',5,'cog',.58,.68);if(!tw)return 'nos';const c2=rpSpawn('cog',e.pi);c2.s=e.s+15;c2._s=-1;tank(c2,1e6);c2.sp=0;tw.nv=4;tw.cd=0;let k=0;while(!R.mbEcl.length&&k++<200)step(R,1);step(R,12);
  const a=[R.mbEcl.length];tw.jam=3;tw.jamBy='emp';const h=R.mbEclHits;step(R,75);a.push(R.mbEclHits-h,R.mbEcl.length);const E2=R.mbEclHits;tw.jam=0;tw.jamImm=0;tw.nv=4;tw.cd=0;k=0;while(!R.mbEcl.length&&k++<200)step(R,1);step(R,60);a.push(R.mbEclHits-E2);return a});
 /* storm bolts jam the Sentinel and the Lantern too (not on a lightning-rod pad) */
 o.bolt=go('storm',R=>{const r={};for(const t of ['moon','lant']){IA.reset(R);const pd=R.pads.find(p=>!p.rod);const tw=bt(R,pd,t,3);R.boltTwT=.01;rpStep(R,1/30);r[t]=[tw.jamBy,tw.jam>0?1:0].join('|');R.boltTwT=1e9}return r});
 /* several towers on one monster: every point of health lost is booked on the tower that dealt it (pollen and marks included) */
 o.attr=go('meadow',R=>{IA.reset(R);let pr=null;for(const a of R.pads){const b=R.pads.filter(b=>b!==a&&Math.hypot(a.x-b.x,a.y-b.y)<=145);if(b.length<2)continue;const e=IA.place(R,'knight',a.x,a.y,60,140);if(e){pr=[a,...b];break}}if(!pr)return 'nopair';
  const e=R.foes[0];tank(e,1e7);e.sp=0;const c=rpSpawn('cog',e.pi);c.s=e.s-25;c._s=-1;tank(c,1e7);c.sp=0;const q=rpPos(R,e);const rest=[...R.pads].filter(p=>!pr.includes(p)).sort((a,b)=>Math.hypot(a.x-q.x,a.y-q.y)-Math.hypot(b.x-q.x,b.y-q.y));
  const tws=[bt(R,pr[0],'moon',5),bt(R,pr[1],'lant',5),bt(R,pr[2],'hive',4),bt(R,rest[0],'star',4),bt(R,rest[1],'still',4),bt(R,rest[2],'ballista',4)];tws[1].souls=5;IA.log=[];step(R,30*8);
  const r={};for(const tw of tws){const mine=IA.log.filter(x=>rpqDmOf(x.src)===tw).reduce((a,x)=>a+x.lost,0);r[tw.type]=[Math.round(tw.rpqD||0),Math.round(mine)]}r.un=Math.round(R.rpqUn||0);r.pol=tws[0].pol>0?1:0;return r});
 /* Overcharge: the Sentinel throws about 2.4x as often; rpBusiest can pick either new tower */
 o.overRate=go('meadow',R=>{const {tw,e}=solo(R,'moon',3,'cog',.3,.5);if(!tw)return 'nos';step(R,60);let n=R.mbThrows;step(R,30*8);const a=R.mbThrows-n;rpAbility('over',tw);n=R.mbThrows;step(R,30*8);const b=R.mbThrows-n;
  const busy=rpBusiest();return [a,b,busy===tw?1:0]});
 return o}"""
# ---------- D: fourteen towers x every monster ----------
MATRIX=r"""(grp)=>{const IA=window.IA,TW=IA.TW;const [m,ids]=grp;const res={};
 IA.go(m,R=>{for(const t of TW){let k=0;for(const id of ids){k++;
   /* damage: a frozen tank in range of one tier-3 tower for 4 s */
   IA.reset(R);let [pd,e]=IA.pair(R,t,id,.45,.7,k*3);if(!pd){res[t+':'+id]='nos';continue}IA.tank(e,1e6);e.sp=0;if(RP_FOE[id].stompT)e.stT=1e9;const tw=IA.bt(R,pd,t,3);
   const h0=e.hp;let nan=0;for(let i=0;i<120;i++){rpStep(R,1/30);if(!isFinite(e.hp)||!isFinite(e.s)||!isFinite(e.armor)||IA.nanFx(R))nan++}
   const lost=h0-e.hp,D=[Math.round(lost),Math.round(tw.rpqD||0),Math.round(R.rpqUn||0),Math.round(R.rpqTot||0),nan];
   /* a kill: the same monster with its real health (bosses at 800), frozen in range: it dies once and pays once */
   IA.reset(R);[pd,e]=IA.pair(R,t,id,.45,.7,k*3);e.sp=0;e.hp=e.mx=Math.min(e.mx,e.boss?500:400);if(RP_FOE[id].stompT)e.stT=1e9;const tw2=IA.bt(R,pd,t,3);const k0=R.kills,all=new Set([e]),s0=e.s;let tt=0,fr=0;
   while(tt<40){rpStep(R,1/30);tt+=1/30;fr++;for(const f of R.foes){all.add(f);if(!f.dead)f.sp=0}if(fr%15===0&&!e.dead&&Math.abs(e.s-s0)>40){e.s=s0;e._s=-1}if(e.dead&&!R.foes.some(f=>!f.dead))break}
   const died=[...all].filter(f=>f._iaK).length,twice=[...all].filter(f=>f._iaK>1).length;
   res[t+':'+id]=D.concat([e.dead?1:0,e.leak?1:0,R.kills-k0,died,twice,Math.round(tt*10)/10,tw2.kills||0]).join('|')}}return 1});return res}"""
# ---------- E: selling, upgrading, wave end, game over, leaving, pause, speed, early calls ----------
LIFE=r"""()=>{const IA=window.IA,TW=IA.TW,o={};const {go,step,bt,tank}=IA;
 const column=(R,n,hp,id)=>{const L=R.G.paths[0].len,es=[];for(let k=0;k<n;k++){const e=rpSpawn(id||(k%3?'cog':'gyro'),0);e.s=L*.25+k*22;e._s=-1;e.hp=e.mx=hp||3000;e.sp=30;es.push(e)}return es};
 const padNear=(R,e,n)=>{const q=rpPos(R,e);return [...R.pads].filter(p=>!p.tw).sort((a,b)=>Math.hypot(a.x-q.x,a.y-q.y)-Math.hypot(b.x-q.x,b.y-q.y))[n||0]};
 /* 1. sold mid-action: each tower's effects; the new towers take theirs along; damage after the sale stays on the sold tower */
 o.sell=go('meadow',R=>{const r={};for(const t of TW){IA.reset(R);const es=column(R,10,4000);const tw=bt(R,t==='star'?R.pads[0]:padNear(R,es[4]),t,5);if(t==='lant'){tw.souls=5}step(R,75);
   const fx0={gl:(R.mbGl||[]).filter(g=>g.tw===tw).length,ec:(R.mbEcl||[]).filter(E=>E.tw===tw).length,w:(R.lnWisps||[]).filter(w=>w.tw===tw).length,ph:(R.lnPh||[]).filter(p=>p.tw===tw&&p.st!=='fade').length,so:(R.lnSouls||[]).filter(s=>s.tw===tw).length};
   const d0=tw.rpqD||0;rpSell(tw);step(R,15);
   const fx1={gl:(R.mbGl||[]).filter(g=>g.tw===tw).length,ec:(R.mbEcl||[]).filter(E=>E.tw===tw).length,w:(R.lnWisps||[]).filter(w=>w.tw===tw&&!(w.fade>0)).length,ph:(R.lnPh||[]).filter(p=>p.tw===tw&&p.st!=='fade').length,so:(R.lnSouls||[]).filter(s=>s.tw===tw&&!s.gone).length};
   step(R,30*6);const rec=rpqDmList(R).filter(x=>x.sold&&x.type===t);const mt=IA.meter(R);r[t]={fx0,fx1,d0:Math.round(d0),after:Math.round((tw.rpqD||0)-d0),rec:rec.length?Math.round(rec.reduce((a,x)=>a+x.d,0)):-1,meter:mt,
    left:IA.left(R).filter(x=>!/^foes|^mbWake|^haunts/.test(x)).join(' ')}}return r});
 /* 2. upgraded mid-action, tier 1 to 5, every 0.4 s: no NaN, the tower keeps fighting, glaive and soul counts stay sane */
 o.up=go('meadow',R=>{const r={};for(const t of TW){IA.reset(R);const es=column(R,10,1e5);const tw=bt(R,t==='star'?R.pads[0]:padNear(R,es[4]),t,1);if(t==='lant')tw.souls=6;let nan=0,bad=0;
   for(let i=0;i<30*3;i++){rpStep(R,1/30);if(i%12===11){tw.upK=1;rpUpgrade(tw);tw.upK=1;if(t==='lant'&&tw.tier>=3)tw.souls=RP_TW.lant.souls[tw.tier-1]}nan+=IA.nanFx(R);
    if(t==='moon'&&(tw.mbOut<0||tw.mbOut>RP_TW.moon.glaives[tw.tier-1]||R.mbGl.filter(g=>g.tw===tw).length!==tw.mbOut))bad++;if(t==='lant'&&tw.souls>RP_TW.lant.souls[tw.tier-1])bad++}
   const d1=tw.rpqD||0;step(R,90);const d2=tw.rpqD||0;R.foes=[];step(R,30*4);
   r[t]=[tw.tier,nan,bad,d2>d1?1:0,t==='moon'?tw.mbOut+':'+tw.mbHold.join(''):t==='lant'?(tw.inc||0):'-'].join('|')}return r});
 /* 3. a wave ends while glaives, wisps, souls and phantoms are out: they finish or fade within a few seconds */
 o.waveEnd=go('meadow',R=>{IA.reset(R);const es=column(R,12,600,'cog');const m=bt(R,padNear(R,es[5]),'moon',5),ln=bt(R,padNear(R,es[6]),'lant',5);ln.souls=5;let k=0;while(!(R.lnPh.length&&R.mbGl.length)&&k++<150)step(R,1);
   const a=[R.lnPh.length,R.mbGl.length];for(const e of R.foes)if(!e.dead)rpKillFoe(e,null);step(R,1);a.push(R.wst);step(R,30*3);a.push(R.lnPh.length,R.mbGl.length,R.lnWisps.length,R.lnSouls.length,R.mbEcl.length,m.mbOut);return a});
 /* 5. leaving the map with every effect alive, then a new battle starts clean */
 o.leave=(()=>{try{rpStart('meadow');let R=RPX;R.tut=null;R.supply=1e7;R.wave=3;R.wst='run';R.q=[];R.cd=999;IA.reset(R);const es=column(R,12,3000);const m=bt(R,padNear(R,es[5]),'moon',5),ln=bt(R,padNear(R,es[6]),'lant',5);ln.souls=5;step(R,90);
   const a=[R.mbGl.length+R.lnWisps.length+R.lnPh.length+R.lnSouls.length];R.pause=true;rpLeave();rpStart('coral');R=RPX;a.push(IA.FX.filter(k=>R[k]&&R[k].length).join(','),RPX.pads.filter(p=>p.tw).length);R.tut=null;
   for(let i=0;i<30;i++){rpUpdate(1/30);rpDraw()}rpLeave();return a}catch(x){return 'ERR '+String(x.stack).slice(0,300)}})();
 /* 6. pause freezes glaives, wisps, souls and phantoms; 7. speed 1x-3x */
 o.pause=go('meadow',R=>{IA.reset(R);const es=column(R,12,3000);bt(R,padNear(R,es[5]),'moon',5);const ln=bt(R,padNear(R,es[6]),'lant',5);ln.souls=5;let k=0;while(!(R.lnPh.length&&R.mbGl.length&&R.lnWisps.length)&&k++<200)step(R,1);
   const snap=()=>JSON.stringify([R.time,R.mbGl.map(g=>[g.X,g.Y]),R.lnWisps.map(w=>[w.x,w.y]),R.lnPh.map(p=>[p.x,p.s]),R.lnSouls.map(s=>[s.x,s.y]),R.foes.map(e=>[e.s,e.hp])]);
   const s0=snap();R.pause=true;for(let i=0;i<30;i++){rpUpdate(1/30);rpDraw()}const s1=snap();R.pause=false;R.spd=1;rpUpdate(1/30);const s2=snap();
   const sp=[];for(const v of [1,2,3]){R.spd=v;const t0=R.time;rpUpdate(1/30);sp.push(+(R.time-t0).toFixed(4))}return [s0===s1,s1!==s2,sp]});
 o.speedEq=(()=>{const run=(spd)=>go('meadow',R=>{IA.reset(R);const es=column(R,12,1e5);const m=bt(R,padNear(R,es[5]),'moon',5),ln=bt(R,padNear(R,es[6]),'lant',5);R.spd=spd;const n=Math.round(30*6/spd);
   const r0=Math.random;let sd=11;Math.random=()=>{sd=(sd*16807)%2147483647;return sd/2147483647};try{for(let i=0;i<n;i++)rpUpdate(1/30)}finally{Math.random=r0}return [Math.round(m.rpqD||0),Math.round(ln.rpqD||0),+R.time.toFixed(2)]});
   return [run(1),run(3)]})();
 /* 8. waves called early with both new towers fighting: every wave is flushed */
 o.early=go('coral',R=>{R.wave=0;R.wst='build';R.cd=0;R.hp=1e6;const pads=R.pads;pads.forEach((p,i)=>bt(R,p,['moon','lant','frost','ballista'][i%4],3));rpWaveStart();let calls=0,err=0,t=0;
   while(t<240&&!(R.wave>=4&&R.wst==='build')){R.hold=false;try{rpUpdate(1/30)}catch(x){err++}t+=R.spd/30;if(R.wst==='run'&&R.wave<4&&t>3*R.wave){if(rpqWvCall(false))calls++}}
   for(let i=0;i<30*5;i++)rpStep(R,1/30);return [calls,R.wave,R.wst,(R.rpqDue||[]).length,err,R.leaked,IA.left(R).filter(x=>!/^mbWake/.test(x)).join(' ')]});
 return o}"""
DEFEAT=r"""()=>{const IA=window.IA;rpStart('meadow');const R=RPX;R.tut=null;R.supply=1e7;R.wave=3;R.wst='run';R.q=[];R.cd=999;R.hp=1;IA.reset(R);R.hp=1;const L=R.G.paths[0].len;
 for(let k=0;k<12;k++){const e=rpSpawn(k%3?'cog':'knight',0);e.s=L*.6+k*22;e._s=-1;e.hp=e.mx=5000;e.sp=60}const q=rpPos(R,R.foes[4]);const pads=[...R.pads].sort((a,b)=>Math.hypot(a.x-q.x,a.y-q.y)-Math.hypot(b.x-q.x,b.y-q.y));
 const m=IA.bt(R,pads[0],'moon',5),ln=IA.bt(R,pads[1],'lant',5);ln.souls=5;IA.step(R,40);const lead=R.foes.reduce((a,e)=>e.s>a.s?e:a);lead.s=rpLen(R,lead)-5;lead._s=-1;
 return [R.mbGl.length+R.lnPh.length+R.lnWisps.length+R.lnSouls.length,R.hp]}"""
# ---------- F: phantoms on every road of every map; the Moonlit Wake stays on the road ----------
ROADS=r"""(m)=>{const IA=window.IA;return IA.go(m,R=>{const res={roads:R.G.paths.length,ph:[],wake:null};const G=R.G;
 for(let pi=0;pi<G.paths.length;pi++){IA.reset(R);
  /* the pad with the closest point of road pi, that point nearer road pi than any other road */
  let best=null;for(const p of R.pads){const S=G.paths[pi].S;let bi=-1,bd=1e18;for(let i=0;i<S.length;i++){const d=rpD2(S[i].x,S[i].y,p.x,p.y);if(d<bd){bd=d;bi=i}}if(bi*4<300||bd>200*200)continue;
   let other=1e18;G.paths.forEach((P,j)=>{if(j===pi)return;for(const q of P.S){const d=rpD2(q.x,q.y,p.x,p.y);if(d<other)other=d}});if(other<bd+400)continue;if(!best||bd<best.d)best={p,d:bd,s:bi*4}}
  if(!best){res.ph.push({pi,skip:'no pad'});continue}
  const cut=[];for(let k=0;k<6;k++){const e=rpSpawn('cog',pi);e.s=best.s-40-k*36;e._s=-1;IA.tank(e);e.sp=0;cut.push(e)}
  for(let j=0;j<G.paths.length;j++)if(j!==pi)for(let k=0;k<4;k++){const e=rpSpawn('cog',j);e.s=best.s-60-k*40;e._s=-1;IA.tank(e);e.sp=0}
  const tw=IA.bt(R,best.p,'lant',3);tw.souls=6;tw.cd=99;let ph=null,off=0,back=0,neg=0,last=null,cuts=[],wrong=0,t=0;IA.log=[];
  for(let i=0;i<30*11;i++){const n0=IA.log.length;rpStep(R,1/30);tw.cd=99;t+=1/30;if(!ph&&R.lnPh.length)ph=R.lnPh[0];if(ph&&ph.st==='march'){const q=rpAt(G,ph.s,ph.pi);if(Math.hypot(q.x-ph.x,q.y-ph.y)>.5)off++;if(last!=null&&ph.s>last+1e-9)back++;if(ph.s<0)neg++;last=ph.s}
   for(let j=n0;j<IA.log.length;j++){const x=IA.log[j];if(x.t!=='lant'||x.ap<99||x.dmg<90)continue;const e=R.foes.find(f=>f.uid===x.uid);if(!e)continue;cuts.push(e);if(ph&&e.pi!==ph.pi&&Math.abs(Math.cos(rpPos(R,e).a-ph.a))<RPLNB.par)wrong++}}
  res.ph.push({pi,got:ph?ph.pi:-1,off,back,neg,cuts:cuts.length,mine:cuts.filter(e=>e.pi===pi).length,wrong,end:R.lnPh.length})}
 /* the wake: every silver mark lies on a road */
 IA.reset(R);const L=G.paths[0].len;for(let k=0;k<10;k++){const e=rpSpawn('cog',0);e.s=L*.3+k*30;e._s=-1;IA.tank(e);e.sp=20}const q=rpPos(R,R.foes[4]);const pd=[...R.pads].sort((a,b)=>Math.hypot(a.x-q.x,a.y-q.y)-Math.hypot(b.x-q.x,b.y-q.y))[0];
 if(R.map.maxT>=4||R.map.endless){IA.bt(R,pd,'moon',4);let n=0,off=0;for(let i=0;i<30*8;i++){rpStep(R,1/30);for(const w of R.mbWake)if(w.t===1/30||Math.abs(w.t-1/30)<1e-9){n++;if(G.dRoad(w.x,w.y)>RPMBL.wakeRoad+2)off++}}res.wake=[n,off]}
 return res})}"""
# ---------- S: soak (full battles, all fourteen towers upgraded, 3x) and fuzz ----------
SOAK=r"""(cfg)=>{const IA=window.IA,TW=IA.TW;const t0=performance.now();rpStart(cfg.m);const R=RPX;R.tut=null;R.hold=false;R.supply=1e9;R.hp=1e9;R.spd=3;
 const out={m:cfg.m,err:[],nan:0,fxnan:0,road:0,stuck:[],still:[],waves:0,left:[],twice:0,nopay:0,frames:0,game:0,maxStepMs:0,meter:null,types:0,won:false};const ck=new Map();
 const top=R.map.maxT||RP_MAXT(R.map),pads=R.pads,np=pads.length;
 const lay=w=>{pads.forEach((p,i)=>{const t=TW[(i+w*np)%TW.length];if(p.tw&&p.tw.type===t)return;if(p.tw)rpSell(p.tw);rpBuild(p,t);if(p.tw){p.tw.build=1;p.tw.upK=1;for(let k=1;k<top;k++){p.tw.upK=1;rpUpgrade(p.tw)}p.tw.upK=1;if(p.tw.type==='star'||p.tw.type==='frost')p.tw.prio=['first','strong','close'][i%3]}})};
 lay(0);const all=new Set(),types=new Set();R.wst='build';R.cd=0;rpWaveStart();let runT=0,buildT=0,lastW=0,checked=false;
 while(R.wave<cfg.waves||R.wst==='run'){if(R.wst==='done'||R.over)break;R.hold=false;R.pause=false;const a=performance.now();
  try{rpUpdate(1/30)}catch(x){out.err.push(String(x.stack).slice(0,300));break}const dt=performance.now()-a;if(out.frames>30)out.maxStepMs=Math.max(out.maxStepMs,dt);out.frames++;out.game+=R.spd/30;
  if(out.frames%60===0)try{rpDraw()}catch(x){out.err.push('draw '+String(x.stack).slice(0,300));break}
  if(out.frames%3===0){out.fxnan+=IA.nanFx(R);for(const e of R.foes){all.add(e);if(e.dead)continue;if(!isFinite(e.s)||!isFinite(e.hp)||!isFinite(e.sp)||!isFinite(e.armor)||!isFinite(e.slowK||0))out.nan++;if(e.s>rpLen(R,e)+1)out.road++}}
  for(const p of pads)if(p.tw)types.add(p.tw.type);
  /* a monster that has not moved at all for 300 frames (10-30 s of game time) is stuck; one held back by crowd control still moves */
  for(const e of R.foes){if(e.dead)continue;if(e._iaLs!==e.s){e._iaMv=1;e._iaLs=e.s}}
  if(out.frames%300===0){for(const e of R.foes){if(e.dead||e.s<0)continue;if(ck.has(e)&&!e._iaMv)out.still.push(R.wave+':'+e.id+'@'+Math.round(e.s));ck.set(e,1);e._iaMv=0}}
  if(R.wst==='run'){runT+=R.spd/30;buildT=0;checked=false;if(runT>400){out.stuck.push(R.wave+': '+R.foes.filter(e=>!e.dead).slice(0,5).map(e=>e.id+'@'+Math.round(e.s)+' hp'+Math.round(e.hp)+(e.hide?' hid':'')).join(', '));for(const e of R.foes)if(!e.dead)rpKillFoe(e,null);R.q=[];runT=0}}
  else{if(runT>0){out.waves++;runT=0}buildT+=R.spd/30;
   /* 10 s into the build phase: everything from the last wave has run its course */
   if(buildT>10&&!checked){checked=true;const L=IA.left(R).filter(x=>!/^mbWake|^tide|^gust/.test(x));if(L.length)out.left.push(R.wave+': '+L.join(' '));if(np<TW.length&&R.wave%3===0)lay(R.wave/3)}}
  if(performance.now()-t0>cfg.ms)break}
 out.won=!!R.won;out.wave=R.wave;for(const e of all){if((e._iaK||0)>1)out.twice++;if(e.dead&&!e.leak&&!e._iaK)out.nopay++}out.types=types.size;out.meter=IA.meter(R);out.kills=R.kills;out.leaked=R.leaked;
 out.game=Math.round(out.game);out.maxStepMs=Math.round(out.maxStepMs*10)/10;out.ms=Math.round(performance.now()-t0);rpLeave();return out}"""
FUZZ=r"""(cfg)=>{const IA=window.IA,TW=IA.TW;const t0=performance.now();let sd=cfg.seed;const rnd=()=>{sd=(sd*16807)%2147483647;return (sd-1)/2147483646};const pick=a=>a[Math.floor(rnd()*a.length)];
 rpStart(cfg.m);const R=RPX;R.tut=null;R.hold=false;R.supply=cfg.rich?1e6:3000;R.hp=cfg.hp||1e6;R.spd=3;
 const out={m:cfg.m,err:[],nan:0,fxnan:0,road:0,still:[],acts:{},frames:0,game:0,twice:0,nopay:0,waves:0,defeat:false,finished:false,meter:null};const ck=new Map();
 const act=k=>{out.acts[k]=(out.acts[k]||0)+1};const ids=Object.keys(RP_FOE).filter(id=>!/_p\d$/.test(id));const all=new Set();let runT=0,doneT=0,next=0,pauseN=0;
 R.wst='build';R.cd=0;rpWaveStart();
 while(out.game<cfg.secs){R.hold=false;if(pauseN>0){pauseN--;R.pause=true}else R.pause=false;
  try{rpUpdate(1/30)}catch(x){out.err.push(String(x.stack).slice(0,300));break}out.frames++;if(!R.pause)out.game+=R.spd/30;
  if(out.frames%25===0)try{rpDraw()}catch(x){out.err.push('draw '+String(x.stack).slice(0,300));break}
  if(R.wst==='done'){out.defeat=out.defeat||!R.won;doneT+=1/30;if(doneT>2.6&&!R.over){try{R.won?rpFinish(true):rpFinish(false)}catch(x){out.err.push('finish '+String(x.stack).slice(0,300))}out.finished=true;break}continue}
  if(cfg.rich&&R.supply<2e5)R.supply+=5e5;
  if(out.game>=next&&!R.pause){next=out.game+.25+rnd()*.9;const tws=R.pads.filter(p=>p.tw).map(p=>p.tw);const r=rnd();
   try{
    if(r<.22){const p=pick(R.pads);if(!p.tw){rpBuild(p,pick(TW));act('build')}}
    else if(r<.38){if(tws.length){const tw=pick(tws);if(rpUpgrade(tw))act('up')}}
    else if(r<.46){if(tws.length&&tws.length>4){rpSell(pick(tws));act('sell')}}
    else if(r<.52){const tw=tws.length?pick(tws):null;if(tw){R.abCd.over=0;rpAbility('over',tw);act('over')}}
    else if(r<.57){const L=R.foes.filter(e=>!e.dead&&e.s>0);if(L.length){const e=pick(L),q=rpPos(R,e);R.abCd.slow=0;rpAbility('slow',{x:q.x,y:q.y});act('slow')}}
    else if(r<.60){R.abCd.repair=0;rpAbility('repair');act('repair')}
    else if(r<.68){if(rpqWvCall(false))act('early')}
    else if(r<.72){pauseN=2+Math.floor(rnd()*20);act('pause')}
    else if(r<.77){R.spd=1+Math.floor(rnd()*3);act('speed')}
    else if(r<.82){if(tws.length){pick(tws).prio=pick(['first','strong','close']);act('prio')}}
    else if(r<.87){R.sel=tws.length&&rnd()<.8?pick(tws):null;act('sel')}
    else if(r<.95){const e=rpSpawn(pick(ids));if(e&&e.boss){e.hp=e.mx=Math.round(e.mx*.3)}act('spawn')}
    else{if(tws.length){const tw=pick(tws);rpwJam(R,tw,1+rnd()*2,pick(['ink','emp','bolt']));act('jam')}}
   }catch(x){out.err.push('act '+String(x.stack).slice(0,300))}}
  if(R.wst==='build'&&R.cd>3&&rnd()<.02)R.cd=.5;
  if(out.frames%3===0){out.fxnan+=IA.nanFx(R);for(const e of R.foes){all.add(e);if(e.dead)continue;if(!isFinite(e.s)||!isFinite(e.hp)||!isFinite(e.sp)||!isFinite(e.armor)||!isFinite(e.slowK||0))out.nan++;if(e.s>rpLen(R,e)+1)out.road++}}
  if(!R.pause)for(const e of R.foes){if(e.dead)continue;if(e._iaLs!==e.s){e._iaMv=1;e._iaLs=e.s}}
  if(out.frames%300===0){for(const e of R.foes){if(e.dead||e.s<0)continue;if(ck.has(e)&&!e._iaMv)out.still.push(R.wave+':'+e.id+'@'+Math.round(e.s)+(e.hide?' hid':'')+(cfg.diag?' '+JSON.stringify({sp:e.sp,sk:e.slowK,st:e.slowT,stun:e.stun,kb:e.kb}):''));ck.set(e,1);e._iaMv=0}}
  if(R.wst==='run'){runT+=R.spd/30}else{if(runT>0)out.waves++;runT=0}
  if(performance.now()-t0>cfg.ms)break}
 for(const e of all){if((e._iaK||0)>1)out.twice++;if(e.dead&&!e.leak&&!e._iaK)out.nopay++}out.meter=IA.meter(R);out.wave=R.wave;out.kills=R.kills;out.game=Math.round(out.game);out.ms=Math.round(performance.now()-t0);
 try{rpLeave()}catch(x){out.err.push('leave '+String(x.stack).slice(0,300))}return out}"""
PRE="rpStart('%s');const R=RPX;R.tut=null;R.supply=1e7;R.wave=3;R.wst='run';R.q=[];R.cd=999;if(R.cannon)R.cannon.t=1e9;if(R.rodK){R.boltT=1e9;R.boltTwT=1e9}const IA=window.IA;const L=R.G.paths[0].len;const near=(q,n)=>[...R.pads].filter(p=>!p.tw).sort((a,b)=>Math.hypot(a.x-q.x,a.y-q.y)-Math.hypot(b.x-q.x,b.y-q.y))[n||0];"
SCENES={
 'phantoms_bridge':"()=>{"+PRE%'meadow'+"const es=[];for(let k=0;k<9;k++){const e=IA.tank(rpSpawn(['cog','knight','steam'][k%3],0),1e5);e.s=L*.42+k*24;e._s=-1;e.sp=26;es.push(e)}const q=rpPos(R,es[4]);const ln=IA.bt(R,near(q),'lant',5);IA.bt(R,near(q),'moon',4);ln.souls=5;ln.rel=2;let k=0;while(!(R.lnPh.length>1&&R.lnPh.every(p=>p.st==='march'&&p.t>.7))&&k++<200)IA.step(R,1);R.hold=true;R.toast=null;R.banner=null;return R.lnPh.length}",
 'glaives_wake_eclipse':"()=>{"+PRE%'meadow'+"const es=[];for(let k=0;k<10;k++){const e=IA.tank(rpSpawn(k%4?'cog':'gyro',0),1e5);e.s=L*.3+k*22;e._s=-1;e.sp=30;es.push(e)}const q=rpPos(R,es[5]);const m=IA.bt(R,near(q),'moon',5);const ln=IA.bt(R,near(q),'lant',4);m.nv=4;m.cd=0;let k=0;while(!(R.mbEcl.length&&R.mbGl.length>1&&R.mbEcl[0].t>.6)&&k++<300)IA.step(R,1);const j=IA.tank(rpSpawn('jammer',0),1e5);j.s=es[5].s;j._s=-1;j.sp=0;IA.step(R,2);R.hold=true;R.toast=null;R.banner=null;return [R.mbGl.length,R.mbEcl.length,R.mbWake.length]}",
 'dive_crablings':"()=>{"+PRE%'abyss'+"const e=IA.tank(rpSpawn('leviathan',0),1e6);e.s=L*.42;e._s=-1;e.sp=10;const q=rpPos(R,e);const m=IA.bt(R,near(q),'moon',4),ln=IA.bt(R,near(q),'lant',4);IA.step(R,40);e.hp=e.mx*.7;let k=0;while(!(e.dive>0&&e.dive<.4)&&k++<200)IA.step(R,1);IA.step(R,20);R.hold=true;R.toast=null;R.banner=null;return R.foes.filter(f=>f.id==='crab').length}",
 'fog_wreck':"()=>{"+PRE%'wreck'+"R.fog.forEach(f=>f.v=0);const es=[];for(let k=0;k<6;k++){const e=IA.tank(rpSpawn(['crab','squid','brute'][k%3],k%2),1e5);e.s=R.G.paths[k%2].len*(.35+k*.06);e._s=-1;e.sp=8;es.push(e)}const q=rpPos(R,es[2]);R.fog[0].x=q.x;R.fog[0].y=q.y;const m=IA.bt(R,near(q,2),'moon',4),ln=IA.bt(R,near(q,3),'lant',4);IA.step(R,90);R.hold=true;R.toast=null;R.banner=null;return 1}",
 'switch_phantom':"()=>{"+PRE%'foundry'+"for(let pi=0;pi<2;pi++)for(let k=0;k<6;k++){const e=IA.tank(rpSpawn(['cog','knight'][k%2],pi),1e5);e.s=R.G.paths[pi].len*.55+k*26;e._s=-1;e.sp=20}const q=rpPos(R,R.foes[3]);const ln=IA.bt(R,near(q),'lant',4);ln.souls=5;IA.bt(R,near(q),'moon',4);let k=0;while(!(R.lnPh.length&&R.lnPh[0].st==='march'&&R.lnPh[0].t>1)&&k++<300)IA.step(R,1);R.hold=true;R.toast=null;R.banner=null;return R.lnPh.map(p=>p.pi)}",
 'reaper_titan':"()=>{"+PRE%'storm'+"const t=IA.tank(rpSpawn('titan',0),1e6);t.s=L*.45;t._s=-1;t.sp=8;t.stT=1e9;for(let k=0;k<4;k++){const e=IA.tank(rpSpawn('cog',0),1e5);e.s=L*.45-30-k*30;e._s=-1;e.sp=20}const q=rpPos(R,t);const ln=IA.bt(R,near(q),'lant',5);IA.bt(R,near(q),'star',4);ln.souls=5;ln.rel=2;let k=0;while(!(R.lnPh.some(p=>p.kind==='reaper'&&p.st==='march'&&p.cut>0))&&k++<300)IA.step(R,1);R.hold=true;R.toast=null;R.banner=null;return R.lnReapN}"}
def bar(v):return v.split('|')
W1=['scamp','bulwark','golem','gloom','ooze','oozelet','shaman','behemoth'];W2=['crab','shell','puffer','jelly','brute','siren','squid','leviathan'];W3=['cog','knight','steam','gyro','tinker','spring','jammer','titan']
AIR={'gloom','jelly','gyro'}
async def main():
    os.makedirs(SHOTS,exist_ok=True);T0=time.time()
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        pg.on('console',lambda m:er.append('console: '+m.text[:300]) if m.type=='error' and 'WebSocket' not in m.text else None)
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate
        await E(SETUP);await E(LIB)
        TW=await E("()=>IA.TW");chk(f'{len(TW)} towers in the bar, the Moonblade Sentinel and the Phantom Lantern among them, all open',len(TW)==14 and 'moon' in TW and 'lant' in TW and await E("()=>IA.TW.every(t=>!rpwTwLocked(t))"),TW)
        if not ONLY_SOAK:
            # ---------- A ----------
            for m in MAPS:
                o=await E(PLAY,m)
                chk(f'{m}: all fourteen towers fought ({len(o["types"])} types over three waves at 3x, {o["spawned"]} extra spawns of every monster type), no errors',len(o['types'])==14 and len(o['waves'])==3 and not o['err'],o)
                chk(f'{m}: no NaN (monsters, glaives, wisps, souls, phantoms), no monster off its road or back in the cave, phantoms on their road',o['nan']==0 and o['fxnan']==0 and o['road']==0 and o['back']==0 and o['phRoad']==0 and o['phBack']==0,o)
                chk(f'{m}: every wave ends, every monster died once and paid once or leaked ({o["kills"]} kills, {o["leaked"]} leaks)',not o['stuck'] and not o['left'] and o['rpx'] and o['twice']==0 and o['nopay']==0 and o['killsOk'],o)
                chk(f'{m}: every effect is gone a few seconds after each wave (phantoms too)',all(x=='' for x in o['fx']),o['fx'])
                chk(f'{m}: the damage meter adds up (towers + sold towers + hazards = health lost) and both new towers dealt damage',all(abs(a-b)<=2 for a,b in o['meter']) and o['newD'].get('moon',0)>0 and o['newD'].get('lant',0)>0,[o['meter'],o['newD']])
            # ---------- B ----------
            o=await E(FIX)
            ah=o['aimHid'];bad={k:v for k,v in ah.items() if v!='0|0|0|0|0'}
            chk('a diving Leviathan: none of the fourteen towers aims, fires, throws, haunts, beams, slows or shoves it (a running haunt pauses)',not bad and len(ah)==14,ah)
            fg=o['fog'];bad={k:v for k,v in fg.items() if v=='nos' or bar(v)[0]!='1' or bar(v)[1]!='0' or bar(v)[2]!='1'}
            chk('fog: no tower (the Sentinel and the Lantern included) picks a fogged monster from beyond 150 px; all of them do once it drifts off',not bad and len(fg)==13,fg)
            gl=o['glow'];bad={k:v for k,v in gl.items() if k!='same' and (bar(v)[0] in ('0','nos') or bar(v)[1] not in ('0','nos'))}
            chk('Glowcaps: every tower on a Glowcap pad reaches 15% further (the Sentinel and the Lantern too); drawing a selected ring leaves the ranges alone',not bad and gl.get('same') is True and len(gl)==14,gl)
            jm=o['jam'];bad={k:v for k,v in jm.items() if not (bar(v)[0]=='1' and int(bar(v)[1])<=12 and bar(v)[2]=='1' and bar(v)[3]=='0' and float(bar(v)[4])<.05 and bar(v)[5]=='0' and bar(v)[6]=='0' and int(bar(v)[7])==0)}
            chk('jams: each of the fourteen towers stops (no throws, wisps or phantoms; glaives fly home without cutting) and fights again afterwards',not bad and len(jm)==14,jm)
            chk('mastery skins do not change damage (Ballista, Sentinel, Lantern, Frost)',len(o['skin'])==2 and o['skin'][0]==o['skin'][1],o['skin'])
            chk('Performance mode (and reduced motion) plays a World 3 battle with all fourteen towers at tier 4 without errors; glaives, wisps and phantoms fly',o['lite'][0]==0 and o['lite'][1]>0 and o['lite'][2]>0 and o['lite'][3]>0 and o['lite'][4]>0,o['lite'])
            chk('How to Play explains the Sentinel and the Lantern and counts fourteen towers',o['howto']==[True,True,True],o['howto'])
            chk('speed x3 runs three steps a frame; pause stops the battle',abs(o['speed'][0]-.1)<.002 and o['speed'][1] is True,o['speed'])
            c=await E(COST);print('frame cost',c)
            if not isinstance(c,dict):c={'ms':99,'off':0}
            chk(f'frame cost: Storm Citadel with fourteen tier-5 towers and 70 monsters steps in {c["ms"]} ms ({c["off"]} ms without 99f\'s step hooks)',c['ms']<6 and c['ms']-c['off']<max(.3,c['off']*.2),c)
            # ---------- C ----------
            o=await E(NEW);print(json.dumps(o)[:3000])
            # expected numbers follow the live tower data (99g retuned the Lantern and the Moonblade after this test was written)
            TV=await E("()=>({m:RP_TW.moon.dmg,ap:RP_TW.moon.ap,l:RP_TW.lant.dmg,ph:RP_TW.lant.ph,ha:RP_TW.lant.haunt,ecl:RPMBL.eclDmg})")
            def gl(t,arm):return max(0,TV['m'][t-1]-max(0,arm-TV['ap'][t-1]))
            def fm(v):return str(int(v)) if float(v).is_integer() else str(v)
            em=[fm(gl(t,9)) for t in range(1,5)]+['/'.join(sorted([fm(TV['ecl']),fm(gl(5,9))],key=float))]
            chk(f'armor-piercing on a Steam Golem (armor 9): glaives {" / ".join(em[:4])} / {fm(gl(5,9))}, the eclipse {fm(TV["ecl"])}',o['ap']['moon']==em,[o['ap'],em])
            chk('the Lantern on armor: wisps lose the armor (9), haunts and phantoms ignore it, at every tier',all(x=='haunt:0 ph:0 wisp:9' for x in o['ap']['lant']),o['ap'])
            es=['17:'+fm(gl(1,17)),'17:'+fm(gl(2,17)),'17:'+fm(gl(3,17)),'17:'+fm(TV['l'][0]-17)+' haunt 0']
            chk(f'a Shellback in its shell (armor 17): glaives {fm(gl(1,17))} / {fm(gl(2,17))} / {fm(gl(3,17))}, wisps {fm(TV["l"][0]-17)}, haunts the full amount',o['shell']==es,[o['shell'],es])
            ep=[fm(gl(2,2)),8,fm(gl(2,8))]
            chk(f'a Puffer puffs up (armor 8): tier-2 glaives {ep[0]} -> {ep[2]}',o['puff']==ep,[o['puff'],ep])
            eb=[f'{fm(gl(1,14))} > {fm(gl(1,7))} arm 7',f'{fm(TV["l"][0]-14)} > {fm(TV["l"][0]-7)} arm 7']
            chk(f'a Barnacle Brute sheds armor with health: glaives {fm(gl(1,14))} -> {fm(gl(1,7))}, wisps {fm(TV["l"][0]-14)} -> {fm(TV["l"][0]-7)}',o['brute']==eb,[o['brute'],eb])
            sg=o['song'];chk('Siren shields absorb glaives and wisps first; the meter books only the health lost',all(isinstance(x,list) and x[0]==120 and x[1]>0 and abs(x[2]-min(x[0],x[1]))<=1 and x[4]==0 for x in sg),sg)
            ik=o['ink'];chk('an Inkling inks the Sentinel and the Lantern: 2.5 s jam, no new throws or wisps, glaives come home without cutting, then they fight again',all(bar(ik[t])[0]=='ink' and bar(ik[t])[1]=='2.5' and bar(ik[t])[3]=='0' and bar(ik[t])[4]=='0' and bar(ik[t])[6]=='1' and bar(ik[t])[7]=='1' for t in ('moon','lant')),ik)
            dv=o['dive'];chk('a diving Leviathan takes no glaive, wisp or haunt; its Crablings are cut and haunted; a phantom walks past it and cuts the Crablings',dv['moon']=='1|0|4|4' and dv['lant']=='1|0|4|4' and bar(dv['ph'])[:3]==['true','false','0'] and int(bar(dv['ph'])[3])>=2,dv)
            gd=o['guard'];chk('a Brass Knight guard: 25% off glaives, haunts and phantoms on the monster behind it, never for another knight',gd['moon']=='0.25|0|0.75|1' and gd['lant']=='0.25|0|0.75|1',gd)
            vt=o['vent'];chk('a venting Steam Golem ignores the Wake, Grave Chill, honey and Frost (every venting step at full speed); after the vent they slow it again',vt[0]>20 and vt[1]==0 and vt[2]>0 and vt[3]<.9 and vt[4]==1,vt)
            chk('a leaping Springjack is never cut by a glaive passing over it; it is once it lands',o['leap']==[0,1,1],o['leap'])
            em=o['emp'];chk('a Sparkjammer jams the Sentinel and the Lantern once (then 4 s immunity)',em['moon']=='emp|1|0|1' and em['lant']=='emp|1|0|1',em)
            ti=o['titan'];et=[f"emp|1|{fm(gl(1,14))}|10|{fm(gl(1,10))}",f"emp|1|{fm(TV['l'][0]-14)}|10|{fm(TV['l'][0]-10)}"];chk(f'a Titan stomp jams both; its plates fall (14 -> 10) and glaives ({fm(gl(1,14))} -> {fm(gl(1,10))}) and wisps ({fm(TV["l"][0]-14)} -> {fm(TV["l"][0]-10)}) cut deeper',ti['moon']==et[0] and ti['lant']==et[1],[ti,et])
            rp=o['reap'];rb=fm(round(TV['ph'][4]*1.6*3,1));rc=fm(round(TV['ph'][4]*1.6,1));chk(f'the Reaper: x3 on a boss ({rb}) and no execute; a Cogling below 15% is finished',bar(rp['titan'])[1:]==[rb,'0','0','1'] and bar(rp['cog'])[1:4]==[rc,'1','1'],[rp,rb,rc])
            chk('a Hex Shaman heals a haunted Golem without passing its maximum health',o['heal'][:3]==[0,0,1],o['heal'])
            chk('an Ooze cut by a glaive: both Oozelets start on the road, are cut too, and all three feed the Lantern\'s jar',o['ooze']==[1,2,2,2,3],o['ooze'])
            sl=o['slow'];chk('slows: Wake 20%; a Frost slow is neither lowered nor shortened by the Wake; honey + Wake = 20%, puddle + Wake = 25%; Grave Chill over the Wake, then back to it; Grave Chill never over Frost; Slow Field + Wake = the field\'s 45%; flyers untouched; no bad slow values',
                sl['wake']==[.8,.8,.2] and sl['frostWake'][0]==.58 and sl['frostWake'][1]>=2.2 and sl['honeyWake']==[.2,.25] and sl['chillWake']==[.3,2,.3,.2] and sl['chillFrost']==[.58,2.3] and sl['field']==.55 and sl['air']==[0,0] and sl['bad']==0,sl)
            def mk(x,k,kinds):return isinstance(x,dict) and x['k']==[k] and x['kinds']==kinds and x['n']>0
            chk('a Starfall mark (+25%) boosts glaives, wisps, haunts and phantoms',mk(o['mark']['moon'],1.25,'glaive') and mk(o['mark']['lant'],1.25,'haunt,ph,wisp'),o['mark'])
            pl=o['pollen'];chk('Royal Jelly pollen (+10%) boosts glaives, wisps, haunts and phantoms',isinstance(pl,dict) and pl['moon']['k']==[1.1] and pl['moon']['pol']==1 and pl['lant']['k']==[1.1] and pl['lant']['pol']==1 and pl['lant']['kinds']=='haunt,ph,wisp',pl)
            ov=o['over'];q=lambda v:round(v*1.15,1);chk(f"Overcharge: +15% on glaives ({q(TV['m'][2])}), wisps ({q(TV['l'][2])}), haunts ({q(TV['ha'][2])}/s) and phantoms ({q(TV['ph'][2])})",ov['moon']['ex']==1 and ov['moon']['dmg']==[q(TV['m'][2])] and ov['lant']['ex']==1 and ov['lant']['dmg']==[q(TV['l'][2]),q(TV['ph'][2])] and ov['lant']['hd']==[q(TV['ha'][2])],ov)
            w1=o['w1fx'];chk('World 1: an EMP ring fades and an ink blob in flight still lands after its monster died (nothing frozen on screen)',w1[0]>0 and w1[1]=='emp' and w1[2]==0 and w1[3]>0 and w1[4]==0 and w1[5]=='ink',w1)
            ej=o['eclJam'];chk('a jammed Sentinel\'s eclipse loses its edge with its glaives: no more cuts, it fades (an eclipse without a jam cuts the same monsters)',ej[0]==1 and ej[1]==0 and ej[2]==0 and ej[3]>0,ej)
            bo=o['bolt'];chk('a storm bolt jams the Sentinel and the Lantern (on a pad without a lightning rod)',bo['moon']=='bolt|1' and bo['lant']=='bolt|1',bo)
            at=o['attr'];chk('towers around one Brass Knight (Sentinel, Lantern, Hive with pollen, Starfall marks, Still, Ballista): every point of health is booked on the tower that dealt it, nothing unattributed',isinstance(at,dict) and all(v[0]==v[1] for k,v in at.items() if k not in ('un','pol')) and all(at[k][0]>0 for k in ('moon','lant','hive','star')) and at['un']==0 and at['pol']==1,at)
            orr=o['overRate'];chk('Overcharge: the Sentinel throws about 2.4x as often, and the busiest-tower pick finds it',orr[1]>=orr[0]*1.8 and orr[2]==1,orr)
            wd=o['wade'];chk('Rising Tide: a wading monster takes 80% from glaives, wisps, haunts and phantoms',mk(wd['moon'],.8,'glaive') and wd['moon']['ex']==1 and mk(wd['lant'],.8,'haunt,ph,wisp'),wd)
            rd=o['rod'];chk('a lightning-rod pad: +10% on the Sentinel and the Lantern',rd['moon']=='1.1 rod1' and rd['lant']=='1.1 rod1',rd)
            # ---------- D ----------
            bad=[];dz=[];kl=[];n=0
            for g in [['moss',W1],['coral',W2],['meadow',W3]]:
                r=await E(MATRIX,g)
                for k,v in r.items():
                    n+=1;t,id=k.split(':')
                    if v=='nos':bad.append(k+' no place');continue
                    lost,rd_,un,tot,nan,dead,leak,kills,died,twice,tt,twk=[float(x) for x in bar(v)]
                    can=not(id in AIR and t in ('brazier','frost','tide','mortar','still','grav'))
                    if nan or abs(lost-rd_)>max(2,lost*.01) or un or abs(tot-lost)>max(2,lost*.01):bad.append(k+' '+v)
                    if can!=(lost>0):dz.append(k+' '+v)
                    if can and (not dead or leak or twice or kills!=died):kl.append(k+' '+v)
                    if not can and (dead or kills):kl.append(k+' '+v)
            chk(f'all fourteen towers x all {len(W1+W2+W3)} monsters ({n} pairs): damage applies with no NaN and is booked on that tower (nothing unattributed)',not bad and n==14*24,bad[:12])
            chk('every tower hurts every monster it can reach, and ground-only towers never touch flyers',not dz,dz[:12])
            chk('every monster each tower can reach dies once and pays once (Oozelets and bosses included); flyers are never killed by ground-only towers',not kl,kl[:12])
            # ---------- E ----------
            o=await E(LIFE);print(json.dumps(o)[:2500])
            se=o['sell'];bad={k:v for k,v in se.items() if abs(v['meter'][0]-v['meter'][1])>2 or v['left'] or v['rec']<v['d0']+v['after']-2}
            chk('a tower sold mid-action: its leftover shots, puddles, waves and wells finish and that damage stays booked on the sold tower; the meter adds up',not bad,bad)
            mo=se['moon'];ln=se['lant']
            chk('a sold Sentinel takes its glaives and eclipse along; a sold Lantern fades its phantoms and wisps, its souls fade',mo['fx1']['gl']==0 and mo['fx1']['ec']==0 and ln['fx1']['ph']==0 and ln['fx1']['w']==0 and ln['fx1']['so']==0 and ln['fx0']['ph']+ln['fx0']['w']>0,[mo,ln])
            up=o['up'];bad={k:v for k,v in up.items() if bar(v)[:4]!=['5','0','0','1'] or (k=='moon' and bar(v)[4]!='0:111') or (k=='lant' and bar(v)[4]!='0')}
            chk('every tower upgraded tier 1 to 5 mid-action keeps fighting, no NaN; glaives in flight come home to the right hands, souls never overfill',not bad,up)
            we=o['waveEnd'];chk('a wave cleared with phantoms, glaives, wisps and souls out: 3 s later the phantoms have faded and everything else is home',we[0]>0 and we[1]>0 and we[2]=='build' and we[3:]==[0,0,0,0,0,0],we)
            lv=o['leave'];chk('leaving a battle with every effect alive (and paused), then a new battle starts clean and runs',isinstance(lv,list) and lv[0]>0 and lv[1]=='' and lv[2]==0,lv)
            pa=o['pause'];chk('pause freezes glaives, wisps, souls, phantoms and monsters; speed 1x / 2x / 3x run 1 / 2 / 3 steps a frame',pa[0] is True and pa[1] is True and pa[2]==[.0333,.0667,.1],pa)
            se_=o['speedEq'];chk('3x speed deals the same damage per game second as 1x (Sentinel and Lantern)',all(abs(a-b)<=max(a,b)*.2 for a,b in zip(se_[0][:2],se_[1][:2])) and se_[0][2]==se_[1][2],se_)
            d0=await E(DEFEAT);await pg.wait_for_timeout(3600)
            d1=await E("()=>{const R=RPX;return R?[R.wst,!!R.over,!!document.querySelector('#ov .rpres'),!!document.querySelector('#ov .rpqmvp'),R.lnPh.length]:'gone'}")
            await E("()=>{try{if(RPX)rpLeave()}catch(e){}try{hide()}catch(e){}}")
            chk('game over with glaives, wisps and phantoms out: the defeat runs through the game\'s own timers to the results with the MVP card, no errors',d0[0]>0 and d1[:4]==['done',True,True,True],[d0,d1])
            ea=o['early'];chk('waves called early while the new towers fight: every wave is flushed, nothing stuck or left',ea[0]>=1 and ea[1]==4 and ea[2]=='build' and ea[3]==0 and ea[4]==0 and ea[6]=='',ea)
            # ---------- F ----------
            for m in MAPS:
                r=await E(ROADS,m);P=r['ph'];okp=[x for x in P if 'skip' not in x]
                chk(f'{m}: a phantom rises on each of its {r["roads"]} road(s), stays on it, marches toward the spawn, cuts monsters on its road only (never a crossing road) and fades',len(okp)==r['roads'] and all(x['got']==x['pi'] and x['off']==0 and x['back']==0 and x['neg']==0 and x['mine']>=3 and x['wrong']==0 and x['end']==0 for x in okp),P)
                if r['wake'] is not None:chk(f'{m}: every Moonlit Wake mark lies on the road ({r["wake"][0]} marks)',r['wake'][0]>0 and r['wake'][1]==0,r['wake'])
            # screenshots of interesting cases
            for k,js in SCENES.items():
                await E(js);await pg.wait_for_timeout(400);await pg.screenshot(path=os.path.join(SHOTS,f'ia_{k}.png'));await E("()=>{if(RPX)rpLeave()}")
        # ---------- S ----------
        if DO_SOAK or ONLY_SOAK:
            k=3 if LONG else 1
            for cfg in [{'m':'wonder','waves':25*k,'ms':90000*k},{'m':'storm','waves':25,'ms':90000*k},{'m':'coral','waves':15,'ms':60000*k}]+([{'m':'foundry','waves':20,'ms':90000},{'m':'abyss','waves':20,'ms':90000},{'m':'meadow','waves':18,'ms':90000},{'m':'wreck','waves':18,'ms':90000}] if LONG else []):
                t0=time.time();r=await E(SOAK,cfg);print('soak',round(time.time()-t0),'s',json.dumps(r)[:900])
                chk(f'soak {cfg["m"]}: {r["waves"]} waves ({r["game"]} s of game time) with all fourteen towers upgraded at 3x: no errors, NaN, stuck or leftover effects, each monster paid once, the meter adds up',
                    not r['err'] and r['nan']==0 and r['fxnan']==0 and r['road']==0 and not r['stuck'] and not r['still'] and not r['left'] and r['twice']==0 and r['nopay']==0 and abs(r['meter'][0]-r['meter'][1])<=2 and r['types']==14 and r['waves']>=min(cfg['waves'],8),r)
            seeds=[7,3,11,19,23,29,31,37] if LONG else [7,3,11]
            fz=[{'m':MAPS[(i*3+1)%len(MAPS)],'secs':600 if LONG else 300,'seed':sd,'ms':90000,'rich':1} for i,sd in enumerate(seeds)]+[{'m':'moss','secs':300,'seed':5,'ms':60000,'hp':12},{'m':'storm','secs':300,'seed':13,'ms':60000,'hp':12}]
            tot=0
            for cfg in fz:
                t0=time.time();r=await E(FUZZ,cfg);tot+=r['game'];print('fuzz',round(time.time()-t0),'s',json.dumps(r)[:900])
                chk(f'fuzz {cfg["m"]} (seed {cfg["seed"]}, {r["game"]} s of game time, {sum(r["acts"].values())} random actions{", to a defeat" if r["defeat"] else ""}): no errors, NaN or stuck monster, each monster paid once, the meter adds up',
                    not r['err'] and r['nan']==0 and r['fxnan']==0 and r['road']==0 and not r['still'] and r['twice']==0 and r['nopay']==0 and abs(r['meter'][0]-r['meter'][1])<=2,r)
            print('fuzz game time',tot,'s')
        chk('no page errors or console errors',not er,er[:5])
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed in {round(time.time()-T0)} s');sys.exit(1 if FAIL else 0)
asyncio.run(main())
