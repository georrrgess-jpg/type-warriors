/* ---------- Cheat codes ----------
   Players type a code in Settings > Data > Cheat codes. Codes are created in Developer tools > Codes (password-protected).
   No codes ship with the game. Shared codes live in the Google Sheet behind SUGGEST_ENDPOINT (same on every device, one redeem count);
   local codes live in this browser only. Which codes a save has used is kept in the save (P.ccUsed). */
const CC_KEY='twCodes1',CC_MAXLEN=24;
/* codes built into the game: they work on every device with no server. max 0 = unlimited; each save can still use a code once */
const CC_BUILTIN=[{text:'COINS500',type:'gold',n:500,id:'',max:0,used:0,builtin:1},
 {text:'COINS600',type:'gold',n:600,id:'',max:0,used:0,builtin:1},
 {text:'NICEPRESTIGE69',type:'gold',n:5000,id:'',max:1,used:0,builtin:1},
 {text:'FREECOINS2500',type:'gold',n:2500,id:'',max:0,used:0,builtin:1},
 {text:'BRAYDENSGIFT',type:'gold',n:10000,id:'',max:1,used:0,builtin:1}];
const ccNorm=s=>String(s||'').toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,CC_MAXLEN);
const ccClean=s=>String(s||'').toUpperCase().replace(/[^A-Z0-9 _-]/g,'').replace(/\s+/g,' ').trim().slice(0,CC_MAXLEN);
const ccInt=(n,lo,hi)=>Math.max(lo,Math.min(hi,Math.floor(+n)||0));
function ccValid(c){return c&&typeof c==='object'&&typeof c.text==='string'&&ccNorm(c.text).length>=3&&['gold','corn','w','a'].includes(c.type)}
/* built-in codes with a max keep their count in this browser only: a server is needed for a count shared by all players */
function ccBUsed(k){try{return ccInt((JSON.parse(localStorage.getItem('twCodeUse1')||'{}')||{})[k],0,1e9)}catch(e){return 0}}
function ccBBump(k){try{const m=JSON.parse(localStorage.getItem('twCodeUse1')||'{}')||{};m[k]=ccInt(m[k],0,1e9)+1;localStorage.setItem('twCodeUse1',JSON.stringify(m))}catch(e){}}
function ccLoad(){try{const a=JSON.parse(localStorage.getItem(CC_KEY)||'[]');return(Array.isArray(a)?a:[]).filter(ccValid).map(c=>({text:ccClean(c.text),type:c.type,n:ccInt(c.n,0,1e9),id:String(c.id||''),max:ccInt(c.max,0,1e9),used:ccInt(c.used,0,1e9),ts:+c.ts||0}))}catch(e){return[]}}
function ccStore(a){try{localStorage.setItem(CC_KEY,JSON.stringify(a));return true}catch(e){return false}}
const ccItem=c=>c.type==='w'?WP[c.id]:c.type==='a'?AR[c.id]:null;
function ccDesc(c){if(c.type==='gold')return c.n.toLocaleString('en-US')+' coins';if(c.type==='corn')return c.n.toLocaleString('en-US')+' candy corn';const it=ccItem(c);return it?it.n+' ('+it.r+' '+(c.type==='w'?'weapon':'armor')+')':'Unknown item'}

/* ---- redeeming ----
   Two places a code can live: this browser (local codes made in Developer tools) and the shared Google Sheet behind
   SUGGEST_ENDPOINT (shared codes, the same on every device, with a redeem count everyone adds to). */
let ccFails=0,ccLockUntil=0;
function ccDevId(){try{let d=localStorage.getItem('twDev1');if(!d){d=Array.from({length:16},()=>'abcdefghijkmnpqrstuvwxyz23456789'[Math.random()*32|0]).join('');localStorage.setItem('twDev1',d)}return d}catch(e){return'nodev'}}
function ccJsonp(o,ms){return new Promise(res=>{const name='__cc'+Date.now().toString(36)+Math.random().toString(36).slice(2,6),sc=document.createElement('script');let fin=0;
 const done=r=>{if(fin)return;fin=1;clearTimeout(tm);try{delete window[name]}catch(e){window[name]=undefined}sc.remove();res(r)};
 const tm=setTimeout(()=>done({ok:0,net:1,m:'Could not reach the code server. Check your connection and try again.'}),ms||12000);
 window[name]=j=>done(Array.isArray(j)?{ok:0,net:1,m:'The Google script is still the old version (it does not know about codes). Redeploy it as a New version.'}:j&&typeof j==='object'?j:{ok:0,net:1,m:'The code server sent an unexpected answer.'});
 sc.onerror=()=>done({ok:0,net:1,m:'Could not reach the code server. Check your connection and try again.'});
 sc.src=SUGGEST_ENDPOINT+'?'+Object.keys(o).map(k=>encodeURIComponent(k)+'='+encodeURIComponent(o[k])).join('&')+'&callback='+name;document.head.appendChild(sc)})}
function ccApi(o,ms){if(typeof SUGGEST_ENDPOINT==='undefined'||!SUGGEST_ENDPOINT)return Promise.resolve({ok:0,m:'Shared codes are not set up.',net:1});
 const ctl=typeof AbortController==='function'?new AbortController():null,tm=setTimeout(()=>{try{ctl&&ctl.abort()}catch(e){}},ms||12000);
 return fetch(SUGGEST_ENDPOINT+'?'+Object.keys(o).map(k=>encodeURIComponent(k)+'='+encodeURIComponent(o[k])).join('&'),{cache:'no-store',credentials:'omit',signal:ctl?ctl.signal:undefined}).then(r=>r.text().then(t=>{clearTimeout(tm);let j=null;try{j=JSON.parse(t)}catch(e){}
  if(Array.isArray(j))return{ok:0,net:1,m:'The Google script is still the old version (it does not know about codes). Redeploy it as a New version.'};
  if(j&&typeof j==='object')return j;
  return{ok:0,net:1,m:'The code server answered with a web page instead of data. In the Google script deployment, set "Who has access" to Anyone and deploy a New version.'}})).catch(()=>{clearTimeout(tm);return ccJsonp(o,ms)})}
function ccGrant(c,k){/* gives the reward and remembers that this save used the code */
 if(!P.ccUsed||typeof P.ccUsed!=='object')P.ccUsed={};
 if(c.type==='w'||c.type==='a')(c.type==='w'?P.own:P.ownA)[c.id]=1;
 else if(c.type==='gold')P.gold=Math.min(1e12,P.gold+c.n);
 else{ttNormalize();P.candyCorn+=c.n}
 P.ccUsed[k]=1;save();ccSync();return{ok:1,rw:{t:c.type,n:c.n,id:c.id},m:'Code accepted!'}}
function ccBad(m,bad){const now=Date.now();if(bad&&++ccFails>=5){ccFails=0;ccLockUntil=now+30000;return{ok:0,m:'That code is not valid. Too many tries, wait 30 seconds.'}}return{ok:0,m}}
async function ccRedeem(raw){
 const now=Date.now();if(now<ccLockUntil)return{ok:0,m:'Too many wrong codes. Try again in '+Math.ceil((ccLockUntil-now)/1000)+' seconds.'};
 const k=ccNorm(raw);if(k.length<3)return{ok:0,m:'Type a code first.'};
 if(!P.ccUsed||typeof P.ccUsed!=='object')P.ccUsed={};
 const list=ccLoad(),c=list.find(x=>ccNorm(x.text)===k);
 const own=c=>(c.type==='w'?P.own:P.ownA)[c.id];
 if(c){ccFails=0;
  if(P.ccUsed[k])return{ok:0,m:'You already used this code on this save.'};
  if(c.max>0&&c.used>=c.max)return{ok:0,m:'This code has been fully redeemed.'};
  const it=ccItem(c);if((c.type==='w'||c.type==='a')){if(!it)return{ok:0,m:'That reward is not available.'};if(own(c))return{ok:0,m:'You already own '+it.n+'. The code was not used up.'}}
  c.used++;ccStore(list);return ccGrant(c,k)}
 const bc=CC_BUILTIN.find(x=>ccNorm(x.text)===k);
 if(bc){ccFails=0;if(P.ccUsed[k])return{ok:0,m:'You already used this code on this save.'};if(bc.max>0&&ccBUsed(k)>=bc.max)return{ok:0,m:'This code has been fully redeemed.'};ccBBump(k);return ccGrant(bc,k)}
 /* not a local code: ask the shared list */
 if(typeof SUGGEST_ENDPOINT==='undefined'||!SUGGEST_ENDPOINT)return ccBad('That code is not valid.',1);
 if(P.ccUsed[k])return{ok:0,m:'You already used this code on this save.'};
 const dev=ccDevId(),q=await ccApi({action:'lookup',code:k,dev});
 if(!q.ok)return q.net?{ok:0,m:q.m}:ccBad(q.m||'That code is not valid.',q.bad);
 ccFails=0;const sc={type:q.type,n:ccInt(q.n,0,q.type==='gold'?1e6:1e5),id:String(q.id||'')};
 if(!['gold','corn','w','a'].includes(sc.type)||((sc.type==='gold'||sc.type==='corn')&&sc.n<1))return{ok:0,m:'That reward is not available.'};
 if(sc.type==='w'||sc.type==='a'){const it=ccItem(sc);if(!it)return{ok:0,m:'That reward is not in this version of the game.'};if(own(sc))return{ok:0,m:'You already own '+it.n+'. The code was not used up.'}}
 const r=await ccApi({action:'redeem',code:k,dev});
 if(!r.ok)return{ok:0,m:r.m||'That code could not be redeemed.'};
 return ccGrant(sc,k)}
function ccSync(){try{if(typeof devGoldSync==='function')devGoldSync()}catch(e){}}
function ccToast(t){let e=document.getElementById('cctoast');if(!e){e=document.createElement('div');e.id='cctoast';document.body.appendChild(e)}e.textContent=t;e.className='';void e.offsetWidth;e.className='show';clearTimeout(ccToast.h);ccToast.h=setTimeout(()=>e.className='',2600)}

/* ---- the player's code box ---- */
function ccAsk(){
 if(document.getElementById('ccm'))return;const m=document.createElement('div');m.id='ccm';m.setAttribute('role','dialog');m.setAttribute('aria-modal','true');m.setAttribute('aria-label','Enter cheat code');
 m.innerHTML=`<div class="ccb"><h3>Cheat code</h3><p>Got a secret code? Type it in to unlock a prize.</p><input id="ccin" type="text" maxlength="${CC_MAXLEN}" autocomplete="off" autocapitalize="characters" spellcheck="false" placeholder="ENTER CODE"><div class="ccmsg" id="ccmsg"> </div><div class="ccbt"><button class="cccancel" id="cccx">Cancel</button><button class="ccgo" id="ccgo">Redeem</button></div></div>`;
 document.body.appendChild(m);const inp=m.querySelector('#ccin'),out=m.querySelector('#ccmsg');
 const close=()=>{document.removeEventListener('keydown',ek,true);m.remove()};
 let busy=0;const go=async()=>{if(busy)return;busy=1;const gb=m.querySelector('#ccgo');gb.textContent='Checking...';out.textContent=' ';out.className='ccmsg';const r=await ccRedeem(inp.value);busy=0;gb.textContent='Redeem';if(!document.getElementById('ccm'))return;if(!r.ok){out.textContent=r.m;out.className='ccmsg bad';m.querySelector('.ccb').classList.remove('shake');void m.offsetWidth;m.querySelector('.ccb').classList.add('shake');return}close();await ccPlay(r.rw);try{if(S.mode==='title'&&typeof refreshGold==='function')refreshGold()}catch(e){}};
 const ek=e=>{if(!document.getElementById('ccm')){document.removeEventListener('keydown',ek,true);return}e.stopPropagation();if(e.key==='Escape'){e.preventDefault();close()}else if(e.key==='Enter'&&e.target===inp){e.preventDefault();go()}};
 document.addEventListener('keydown',ek,true);m.querySelector('#ccgo').onclick=go;m.querySelector('#cccx').onclick=close;m.addEventListener('pointerdown',e=>{if(e.target===m)close()});
 inp.addEventListener('input',()=>{inp.value=inp.value.toUpperCase();out.textContent=' ';out.className='ccmsg'});setTimeout(()=>inp.focus(),30)}
SETG.Data.push('Cheat codes');
{const st0=settingsTabs;settingsTabs=function(){const box=ov.querySelector('.opts');if(box&&!box.querySelector('#ccsw')){const d=document.createElement('div');d.className='opt';d.innerHTML=`<div><label>Cheat codes</label><small>Have a secret code? Type it in to unlock coins, candy corn or gear.</small></div><div class="seg"><button class="sm on" id="ccsw">Enter code</button></div>`;box.appendChild(d);$('ccsw').onclick=ccAsk}return st0.apply(this,arguments)}}

/* ---- the unlock animation ---- */
const ccReduce=()=>{try{return matchMedia('(prefers-reduced-motion: reduce)').matches}catch(e){return false}};
let ccStopFn=null;
function ccStop(){if(ccStopFn)ccStopFn()}
function ccPlay(rw){return new Promise(res=>{
 ccStop();const lite=ccReduce();
 const it=rw.t==='w'?WP[rw.id]:rw.t==='a'?AR[rw.id]:null,rank=it?(RKM[it.r]||0):0;
 const col=rw.t==='gold'?'#ffc93c':rw.t==='corn'?'#ff8a1f':(RC[it.r]||'#ffffff');
 const root=document.createElement('div');root.id='ccfx';const cv=document.createElement('canvas');root.appendChild(cv);
 const card=document.createElement('div');card.className='cccard';root.appendChild(card);document.body.appendChild(root);
 const dpr=Math.min(1.5,devicePixelRatio||1);let W=0,H=0;const g=cv.getContext('2d');
 const fit=()=>{W=innerWidth;H=innerHeight;cv.width=W*dpr;cv.height=H*dpr;cv.style.width=W+'px';cv.style.height=H+'px'};fit();addEventListener('resize',fit);
 const R=(a,b)=>a+Math.random()*(b-a),P2=[];let t0=performance.now(),last=t0,raf=0,done=0,shown=0,canClose=0,cardT=0,burst=0,rings=[],spawnAcc=0;
 const label=rw.t==='gold'?'COINS':rw.t==='corn'?'CANDY CORN':(rw.t==='w'?'NEW WEAPON':'NEW ARMOR');
 const coinSVG='<svg viewBox="0 0 64 64" width="92" height="92"><circle cx="32" cy="32" r="29" fill="#8a5a08"/><circle cx="32" cy="32" r="26" fill="#ffd34d"/><circle cx="32" cy="32" r="20" fill="none" stroke="#c98a10" stroke-width="3"/><path d="M32 17v30M25 24c0-4 14-4 14 1s-14 4-14 9 14 5 14 1" fill="none" stroke="#b0740a" stroke-width="4" stroke-linecap="round"/><path d="M14 22a21 21 0 0 1 14-9" fill="none" stroke="#fff6c4" stroke-width="3" stroke-linecap="round"/></svg>';
 const cornSVG='<svg viewBox="0 0 64 64" width="92" height="92"><path d="M32 6L56 56H8z" fill="#ffb21f" stroke="#5a2a04" stroke-width="3" stroke-linejoin="round"/><path d="M32 6L20 34h24z" fill="#fffaf0"/><path d="M20 34L8 56h48L44 34z" fill="#ff7a14"/><path d="M32 6L56 56H8z" fill="none" stroke="#5a2a04" stroke-width="3" stroke-linejoin="round"/></svg>';
 card.style.setProperty('--cc',col);
 if(it)card.innerHTML=`<i class="ccl">${label} UNLOCKED</i><canvas id="ccart" width="360" height="300"></canvas><span class="ccr">${it.r.toUpperCase()}</span><b class="ccn">${esc(it.n)}</b><button class="ccok">Awesome!</button>`;
 else card.innerHTML=`<i class="ccl">${label} UNLOCKED</i><div class="ccic">${rw.t==='gold'?coinSVG:cornSVG}</div><b class="ccn" id="ccnum">+0</b><span class="ccr">${label}</span><button class="ccok">Awesome!</button>`;
 const num=card.querySelector('#ccnum'),art2=card.querySelector('#ccart'),tcv=document.createElement('canvas');
 const star=(x,y,r,a,c)=>{g.save();g.translate(x,y);g.rotate(a);g.fillStyle=c;g.beginPath();for(let i=0;i<8;i++){const rr=i%2?r*.28:r,an=i*Math.PI/4;g.lineTo(Math.cos(an)*rr,Math.sin(an)*rr)}g.closePath();g.fill();g.restore()};
 const addCoin=(x,y,vx,vy)=>P2.push({k:'coin',x,y,vx,vy,r:R(10,19),rot:R(0,6.28),vr:R(5,12),life:R(2.2,3.4),age:0,gr:900});
 const addCorn=(x,y)=>P2.push({k:'corn',x,y,vx:R(-30,30),vy:R(90,200),r:R(12,24),rot:R(-.6,.6),ph:R(0,6.28),life:R(3,4.4),age:0,gr:0});
 const addSpark=(x,y,c,sp)=>{const a=R(0,6.28),v=R(60,sp||420);P2.push({k:'sp',x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v,r:R(5,12),rot:R(0,6.28),vr:R(-4,4),life:R(.7,1.5),age:0,gr:120,c})};
 const sfx=(f,d,ty,v,at)=>setTimeout(()=>{try{beep(f,d,ty,v)}catch(e){}},at);
 if(rw.t==='gold'){for(let i=0;i<8;i++)sfx(660+i*95,.1,'triangle',.55,i*70);sfx(1320,.3,'triangle',.7,640);sfx(1760,.4,'sine',.5,780)}
 else if(rw.t==='corn'){sfx(98,.55,'triangle',.7,0);sfx(147,.5,'triangle',.6,160);sfx(196,.6,'sawtooth',.25,330);[880,1175,1568].forEach((f,i)=>sfx(f,.18,'sine',.5,560+i*110))}
 else{[523,659,784,1047].forEach((f,i)=>sfx(f,.2+rank*.05,'triangle',.6,i*110));if(rank>=3)[1319,1568,2093].forEach((f,i)=>sfx(f,.3,'sine',.5,520+i*120));sfx(131,.7,'triangle',.7,0)}
 const tick=now=>{if(done)return;const dt=Math.min(.05,(now-last)/1000);last=now;const t=(now-t0)/1000;
  g.setTransform(dpr,0,0,dpr,0,0);g.clearRect(0,0,W,H);const cx=W/2,cy=H*.45;
  const bg=Math.min(.82,t*1.6);g.fillStyle=`rgba(6,3,16,${bg})`;g.fillRect(0,0,W,H);
  if(rw.t==='corn'){const f=.75+.25*Math.sin(t*9)*Math.sin(t*3.7),gr=g.createRadialGradient(cx,H*.62,10,cx,H*.62,Math.max(W,H)*.7);gr.addColorStop(0,`rgba(255,120,20,${.34*f*Math.min(1,t*2)})`);gr.addColorStop(.55,`rgba(120,30,160,${.2*Math.min(1,t*2)})`);gr.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=gr;g.fillRect(0,0,W,H)}
  else{const gr=g.createRadialGradient(cx,cy,10,cx,cy,Math.max(W,H)*.6);gr.addColorStop(0,col+Math.round(Math.min(1,t*2)*70).toString(16).padStart(2,'0'));gr.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=gr;g.fillRect(0,0,W,H)}
  if(rw.t==='w'||rw.t==='a'){const n=10+rank*3,spin=t*.45;g.save();g.translate(cx,cy);for(let i=0;i<n;i++){const a=spin+i*6.2832/n,wdt=.09+.03*Math.sin(t*3+i);g.fillStyle=col+'2a';g.beginPath();g.moveTo(0,0);g.arc(0,0,Math.max(W,H),a-wdt,a+wdt);g.closePath();g.fill()}g.restore()}
  if(!burst&&t>.35){burst=1;const n=lite?14:rw.t==='gold'?90:rw.t==='corn'?50:40+rank*26;
   if(rw.t==='gold')for(let i=0;i<n;i++){const a=R(-Math.PI,0)-.0,v=R(380,980);addCoin(cx,cy,Math.cos(a)*v*.9,Math.sin(a)*v)}
   else if(rw.t==='corn')for(let i=0;i<n;i++)addSpark(cx,cy,i%2?'#ff9a2a':'#c77dff',520);
   else for(let i=0;i<n;i++)addSpark(cx,cy,i%3?col:'#ffffff',560+rank*60);
   rings=[0,.18,.36].map(d=>({t:t+d}))}
  if(!lite){spawnAcc+=dt;const rate=rw.t==='gold'?70:rw.t==='corn'?55:0,until=rw.t==='gold'?2.6:3.2;if(rate&&t<until&&t>.2)while(spawnAcc>1/rate){spawnAcc-=1/rate;if(rw.t==='gold')addCoin(R(0,W),-20,R(-40,40),R(80,260));else addCorn(R(0,W),-24)}else if(!rate)spawnAcc=0;
   if((rw.t==='w'||rw.t==='a')&&t>.5&&t<4.5&&Math.random()<.3+rank*.08){const a=R(0,6.28),d=R(60,260);P2.push({k:'sp',x:cx+Math.cos(a)*d,y:cy+Math.sin(a)*d*.7+40,vx:0,vy:-R(30,90),r:R(4,9),rot:R(0,6.28),vr:R(-3,3),life:R(.8,1.6),age:0,gr:-20,c:col})}}
  for(const r of rings){const a=t-r.t;if(a<0||a>1.1)continue;g.strokeStyle=col+Math.round((1-a/1.1)*200).toString(16).padStart(2,'0');g.lineWidth=6*(1-a/1.1)+1;g.beginPath();g.arc(cx,cy,40+a*Math.max(W,H)*.5,0,6.2832);g.stroke()}
  for(let i=P2.length-1;i>=0;i--){const p=P2[i];p.age+=dt;if(p.age>p.life||p.y>H+60){P2.splice(i,1);continue}p.vy+=p.gr*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.rot+=(p.vr||0)*dt;
   const fade=Math.min(1,(p.life-p.age)*2);g.globalAlpha=Math.max(0,fade);
   if(p.k==='coin'){const sx=Math.abs(Math.cos(p.rot));g.save();g.translate(p.x,p.y);g.scale(Math.max(.12,sx),1);g.fillStyle='#8a5a08';g.beginPath();g.arc(0,0,p.r,0,6.2832);g.fill();g.fillStyle='#ffd34d';g.beginPath();g.arc(0,0,p.r*.82,0,6.2832);g.fill();g.strokeStyle='#c98a10';g.lineWidth=p.r*.14;g.beginPath();g.arc(0,0,p.r*.55,0,6.2832);g.stroke();g.fillStyle='#fff6c4';g.beginPath();g.arc(-p.r*.3,-p.r*.3,p.r*.16,0,6.2832);g.fill();g.restore()}
   else if(p.k==='corn'){p.x+=Math.sin(p.age*3+p.ph)*30*dt;const r=p.r,rot=p.rot+Math.sin(p.age*2.4+p.ph)*.5;g.save();g.translate(p.x,p.y);g.rotate(rot);g.beginPath();g.moveTo(0,-r);g.lineTo(r*.78,r);g.lineTo(-r*.78,r);g.closePath();g.save();g.clip();g.fillStyle='#ff7a14';g.fillRect(-r,-r,2*r,2*r);g.fillStyle='#ffc21f';g.fillRect(-r,-r,2*r,r*.9);g.fillStyle='#fffaf0';g.fillRect(-r,-r,2*r,r*.55);g.restore();g.strokeStyle='#4a2204';g.lineWidth=1.6;g.beginPath();g.moveTo(0,-r);g.lineTo(r*.78,r);g.lineTo(-r*.78,r);g.closePath();g.stroke();g.restore()}
   else star(p.x,p.y,p.r*(.6+.4*Math.sin(p.age*9)),p.rot,p.c);
   g.globalAlpha=1}
  if(t>.55&&!shown){shown=1;cardT=t;card.classList.add('show');setTimeout(()=>{canClose=1},900)}
  if(shown){const k=Math.min(1,(t-cardT-.2)/1.3),e=1-Math.pow(1-Math.max(0,k),3);if(num)num.textContent='+'+Math.round(rw.n*e).toLocaleString('en-US')}
  if(art2){const c2=art2.getContext('2d');tcv.width=art2.width;tcv.height=art2.height;art(tcv,rw.t,rw.id,t);c2.setTransform(1,0,0,1,0,0);c2.clearRect(0,0,art2.width,art2.height);const bob=Math.sin(t*2.2)*6,sc=1.04+Math.sin(t*2.2)*.02;c2.save();c2.translate(art2.width/2,art2.height/2+bob);c2.scale(sc,sc);c2.drawImage(tcv,-art2.width/2,-art2.height/2);c2.restore();c2.globalCompositeOperation='destination-in';const mk=c2.createRadialGradient(art2.width/2,art2.height/2,40,art2.width/2,art2.height/2,art2.width*.5);mk.addColorStop(0,'#fff');mk.addColorStop(.8,'#fff');mk.addColorStop(1,'#fff0');c2.fillStyle=mk;c2.fillRect(0,0,art2.width,art2.height);c2.globalCompositeOperation='source-over'}
  if(t>9)return fin();raf=requestAnimationFrame(tick)};
 const fin=()=>{if(done)return;done=1;cancelAnimationFrame(raf);removeEventListener('resize',fit);document.removeEventListener('keydown',ek,true);ccStopFn=null;root.classList.add('out');setTimeout(()=>{root.remove();res()},320)};
 const ek=e=>{e.stopPropagation();if(canClose&&(e.key==='Enter'||e.key===' '||e.key==='Escape')){e.preventDefault();fin()}else e.preventDefault()};
 document.addEventListener('keydown',ek,true);root.addEventListener('pointerdown',()=>{if(canClose)fin()});card.querySelector('.ccok').onclick=()=>{if(canClose)fin()};
 ccStopFn=()=>{if(!done){done=1;cancelAnimationFrame(raf);removeEventListener('resize',fit);document.removeEventListener('keydown',ek,true);root.remove();res()}ccStopFn=null};
 raf=requestAnimationFrame(tick)})}

/* ---- Developer tools > Codes ---- */
{const p0=devPanelEl;devPanelEl=function(){const el=p0.apply(this,arguments);if(el){const bar=el.querySelector('.dvtabs');if(bar&&!bar.querySelector('[data-t=Codes]')){const b=document.createElement('button');b.dataset.t='Codes';b.textContent='Codes';b.onclick=()=>{DEV.tab='Codes';devRender()};bar.appendChild(b)}}return el}}
{const r0=devRender;devRender=function(){r0.apply(this,arguments);ccDevRender()}}
const CC_DRAFT={text:'',type:'gold',n:1000,id:'',max:1,msg:'',del:'',where:'shared'},CC_SH={rows:null,busy:0,err:'',key:''};
try{CC_SH.key=localStorage.getItem('twCcKey')||''}catch(e){}
const ccHasShared=()=>typeof SUGGEST_ENDPOINT!=='undefined'&&!!SUGGEST_ENDPOINT;
function ccItemList(type){const T=type==='w'?WP:AR;return Object.keys(T).filter(k=>T[k]&&T[k].n).sort((a,b)=>(RKM[T[b].r]||0)-(RKM[T[a].r]||0)||T[a].n.localeCompare(T[b].n))}
function ccRandCode(){const A='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';let s='';for(let i=0;i<8;i++)s+=A[Math.random()*A.length|0];return s}
async function ccShLoad(){if(!ccHasShared()||!CC_SH.key||CC_SH.busy)return;CC_SH.busy=1;CC_SH.err='';ccDevRender();
 const r=await ccApi({action:'list',key:CC_SH.key});CC_SH.busy=0;
 if(r.ok&&Array.isArray(r.rows)){CC_SH.rows=r.rows.filter(ccValid).map(c=>({text:ccClean(c.text),type:c.type,n:ccInt(c.n,0,1e9),id:String(c.id||''),max:ccInt(c.max,0,1e9),used:ccInt(c.used,0,1e9),shared:1}));try{localStorage.setItem('twCcKey',CC_SH.key)}catch(e){}}
 else{CC_SH.rows=null;CC_SH.err=r.m||'Could not load shared codes.'}ccDevRender()}
function ccDevRender(){
 if(!DEV.on||!DEV.open||DEV.tab!=='Codes')return;const B=document.querySelector('#devpanel .dvbody');if(!B)return;const D=CC_DRAFT,loc=ccLoad().map(c=>Object.assign(c,{shared:0}));
 if(!ccHasShared())D.where='local';
 if(ccHasShared()&&CC_SH.key&&CC_SH.rows===null&&!CC_SH.busy&&!CC_SH.err&&!ccDevRender.tried){ccDevRender.tried=1;setTimeout(ccShLoad,0)}
 if((D.type==='w'||D.type==='a')&&!ccItemList(D.type).includes(D.id))D.id=ccItemList(D.type)[0]||'';
 const T=D.type==='w'?WP:AR,isItem=D.type==='w'||D.type==='a',rows=(CC_SH.rows||[]).concat(loc,CC_BUILTIN);
 const keyBox=ccHasShared()?`<div class="ccf"><label>Admin key for shared codes<input id="ccd-key" type="password" autocomplete="off" value="${esc(CC_SH.key)}" placeholder="the ADMIN_KEY from your Google script"></label><button class="dvb" data-cc="conn">${CC_SH.busy?'Loading...':'Connect / refresh'}</button></div>${CC_SH.err?`<p class="dvnote" style="color:#ff8a98">${esc(CC_SH.err)}</p>`:CC_SH.rows?`<p class="dvnote" style="color:#7dff9a">Connected. ${CC_SH.rows.length} shared code${CC_SH.rows.length===1?'':'s'}.</p>`:''}`:'<p class="dvnote">No Google script link is set in this build, so only codes on this device can be made.</p>';
 B.innerHTML=`<p class="dvnote"><b>Shared</b> codes live in your Google Sheet and work on every device. <b>This device</b> codes stay in this browser only. You can also type shared codes straight into the sheet's "Codes" tab.</p>${keyBox}
<div class="ccf"><label>Code text<input id="ccd-text" maxlength="${CC_MAXLEN}" value="${esc(D.text)}" placeholder="e.g. PUMPKINKING"></label><button class="dvb" data-cc="rand">Random</button></div>
<div class="ccf"><label>Reward<select id="ccd-type"><option value="gold"${D.type==='gold'?' selected':''}>Coins</option><option value="corn"${D.type==='corn'?' selected':''}>Candy corn</option><option value="w"${D.type==='w'?' selected':''}>Weapon</option><option value="a"${D.type==='a'?' selected':''}>Armor</option></select></label>
${isItem?`<label>Item<select id="ccd-id">${ccItemList(D.type).map(k=>`<option value="${esc(k)}"${k===D.id?' selected':''}>${esc(T[k].n)} (${esc(T[k].r)})</option>`).join('')}</select></label>`:`<label>Amount<input id="ccd-n" type="number" min="1" max="${D.type==='gold'?1000000:100000}" step="${D.type==='gold'?1000:100}" value="${D.n}"></label>`}
<label>Max redemptions<input id="ccd-max" type="number" min="0" max="1000000" value="${D.max}" title="0 = unlimited"></label>
<label>Save to<select id="ccd-where"><option value="shared"${D.where==='shared'?' selected':''}${ccHasShared()?'':' disabled'}>Everyone (shared)</option><option value="local"${D.where==='local'?' selected':''}>This device only</option></select></label></div>
<div class="dvrow"><button class="dvb gd" data-cc="create">Create code</button><button class="dvb" data-cc="prev">Preview animation</button><span id="ccd-msg" class="ccdm">${esc(D.msg)}</span></div>
<p class="dvnote">Max redemptions: how many times the code works in total (0 = unlimited). Each save and device can use a code once.</p>
<div class="ccl2">${rows.length?rows.slice().reverse().map(c=>{const k=ccNorm(c.text),w=c.shared?'s':'l',full=c.max>0&&(c.builtin?ccBUsed(k):c.used)>=c.max,dk=w+':'+k;return `<div class="ccrow${full?' full':''}"><div><b>${esc(c.text)} <em class="ccwh${c.shared?' sh':''}">${c.builtin?'Built in':c.shared?'Shared':'This device'}</em></b><small>${esc(ccDesc(c))}</small></div><span class="ccu" title="Times redeemed">${c.builtin?(c.max>0?ccBUsed(k)+' / '+c.max:'unlimited'):c.used+' / '+(c.max>0?c.max:'∞')}</span><div class="ccrb">${c.builtin?`<button class="dvb" data-cc="pv" data-k="${esc(k)}" data-w="b">Preview</button>`:`<button class="dvb" data-cc="pv" data-k="${esc(k)}" data-w="${w}">Preview</button><button class="dvb" data-cc="rs" data-k="${esc(k)}" data-w="${w}">Reset count</button><button class="dvb ${D.del===dk?'dg':''}" data-cc="del" data-k="${esc(k)}" data-w="${w}">${D.del===dk?'Confirm delete':'Delete'}</button>`}</div></div>`}).join(''):'<p class="dvok" style="color:#9d97c0">No codes yet. Create one above.</p>'}</div>`;
 const q=id=>B.querySelector(id);
 if(q('#ccd-key'))q('#ccd-key').oninput=e=>{CC_SH.key=e.target.value.trim()};
 q('#ccd-text').oninput=e=>{D.text=e.target.value.toUpperCase().replace(/[^A-Z0-9 _-]/g,'');e.target.value=D.text};
 q('#ccd-type').onchange=e=>{D.type=e.target.value;if(D.type==='gold'&&D.n<1)D.n=1000;D.msg='';ccDevRender()};
 if(q('#ccd-id'))q('#ccd-id').onchange=e=>{D.id=e.target.value};
 if(q('#ccd-n'))q('#ccd-n').oninput=e=>{D.n=+e.target.value||0};
 q('#ccd-max').oninput=e=>{D.max=+e.target.value||0};
 q('#ccd-where').onchange=e=>{D.where=e.target.value};
 B.querySelectorAll('[data-cc]').forEach(b=>b.onclick=()=>ccDevAct(b.dataset.cc,b.dataset.k,b.dataset.w))}
async function ccDevAct(a,k,w){const D=CC_DRAFT;
 const say=m=>{D.msg=m;const e=document.getElementById('ccd-msg');if(e)e.textContent=m};
 const draftRw=()=>{const isI=D.type==='w'||D.type==='a';return{t:D.type,n:isI?1:ccInt(D.n,1,D.type==='gold'?1e6:1e5),id:isI?D.id:''}};
 const needKey=()=>{if(!CC_SH.key){say('Enter your admin key first, then press Connect.');return true}return false};
 if(a==='rand'){D.text=ccRandCode();ccDevRender()}
 else if(a==='conn'){CC_SH.err='';CC_SH.rows=null;if(needKey())return;ccShLoad()}
 else if(a==='prev'){ccPlay(draftRw())}
 else if(a==='create'){const text=ccClean(D.text),nk=ccNorm(text);
  if(nk.length<3)return say('Code text needs at least 3 letters or numbers.');
  const isI=D.type==='w'||D.type==='a';if(isI&&!ccItem({type:D.type,id:D.id}))return say('Pick an item.');
  if(!isI&&!(D.n>=1))return say('Enter an amount of at least 1.');
  const rw=draftRw(),max=ccInt(D.max,0,1e6);
  if(D.where==='shared'){if(needKey())return;
   if((CC_SH.rows||[]).some(c=>ccNorm(c.text)===nk))return say('A shared code with that text already exists.');
   say('Saving to the sheet...');const r=await ccApi({action:'create',key:CC_SH.key,code:text,type:D.type,n:isI?0:rw.n,id:isI?D.id:'',max});
   if(!r.ok)return say(r.m||'Could not save to the sheet.');
   D.text='';D.msg='Created shared code '+text+'.';D.del='';await ccShLoad()}
  else{const list=ccLoad();if(list.some(c=>ccNorm(c.text)===nk))return say('A code with that text already exists on this device.');
   list.push({text,type:D.type,n:isI?0:rw.n,id:isI?D.id:'',max,used:0,ts:Date.now()});
   if(!ccStore(list))return say('Could not save: browser storage is blocked.');
   D.text='';D.msg='Created '+text+' (this device only).';D.del='';ccDevRender()}}
 else{const shared=w==='s',list=w==='b'?CC_BUILTIN:shared?(CC_SH.rows||[]):ccLoad(),c=list.find(x=>ccNorm(x.text)===k);if(!c)return;const dk=w+':'+k;
  if(a==='pv'){ccPlay({t:c.type,n:c.n,id:c.id})}
  else if(a==='rs'){if(shared){if(needKey())return;const r=await ccApi({action:'reset',key:CC_SH.key,code:k});if(!r.ok)return say(r.m||'Could not reset.');D.msg='Reset '+c.text+': count is 0.';await ccShLoad()}
   else{c.used=0;ccStore(list);D.msg='Reset '+c.text+': count is 0.';ccDevRender()}
   if(P.ccUsed)delete P.ccUsed[k];save()}
  else if(a==='del'){if(D.del!==dk){D.del=dk;ccDevRender();return}D.del='';
   if(shared){if(needKey())return;const r=await ccApi({action:'delete',key:CC_SH.key,code:k});if(!r.ok)return say(r.m||'Could not delete.');D.msg='Deleted '+c.text+'.';await ccShLoad()}
   else{ccStore(list.filter(x=>x!==c));D.msg='Deleted '+c.text+'.';ccDevRender()}}}}

/* ---- styles ---- */
{const s=document.createElement('style');s.textContent=`
#ccm{position:fixed;inset:0;z-index:99990;display:flex;align-items:center;justify-content:center;background:#05030ccc;backdrop-filter:blur(3px)}
.ccb{width:min(440px,92vw);padding:24px 26px 20px;border-radius:18px;background:linear-gradient(180deg,#1f1752,#0e0c34);border:2px solid #c8902a;box-shadow:0 24px 60px #000;animation:ccin .22s ease-out}
.ccb.shake{animation:ccsh .35s}
@keyframes ccin{from{transform:translateY(14px) scale(.96);opacity:0}to{transform:none;opacity:1}}@keyframes ccsh{20%{transform:translateX(-9px)}40%{transform:translateX(8px)}60%{transform:translateX(-6px)}80%{transform:translateX(4px)}}
.ccb h3{margin:0 0 6px;font:400 40px 'Pirata One',Georgia,serif;color:#ffd76a}.ccb p{margin:0 0 14px;font:16px/1.4 Georgia,serif;color:#e8e0f8;max-width:none}
.ccb input{width:100%;box-sizing:border-box;text-align:center;letter-spacing:.18em;font:700 22px var(--ui,Poppins,sans-serif);color:#fff;background:#0008;border:1.5px solid #6a58b8;border-radius:10px;padding:12px}.ccb input:focus{outline:none;border-color:#ffd76a;box-shadow:0 0 0 3px #ffd76a33}
.ccmsg{min-height:22px;margin:10px 0 4px;text-align:center;font:600 14px var(--ui,Poppins,sans-serif);color:#cfc8ee}.ccmsg.bad{color:#ff8a98}
.ccbt{display:flex;justify-content:flex-end;gap:10px;margin-top:6px}.cccancel,.ccgo{all:unset;box-sizing:border-box;cursor:pointer;height:44px;padding:0 22px;line-height:44px;border-radius:10px;font:700 15px var(--ui,Poppins,sans-serif)}
.cccancel{color:#cfc8ee;background:#2a2450}.ccgo{color:#2a1700;background:linear-gradient(180deg,#ffd76a,#e8a820)}.cccancel:focus-visible,.ccgo:focus-visible{outline:3px solid #fff}
#ccfx{position:fixed;inset:0;z-index:99991;cursor:pointer;animation:ccfi .2s ease-out}#ccfx.out{opacity:0;transition:opacity .3s}#ccfx>canvas{position:absolute;inset:0}
@keyframes ccfi{from{opacity:0}to{opacity:1}}
.cccard{position:absolute;left:50%;top:46%;transform:translate(-50%,-50%) scale(.3);opacity:0;display:flex;flex-direction:column;align-items:center;gap:8px;padding:22px 34px 22px;min-width:min(380px,88vw);border-radius:22px;text-align:center;background:linear-gradient(180deg,#241a5a,#0e0b2e);border:3px solid var(--cc);box-shadow:0 0 50px var(--cc),0 0 120px color-mix(in srgb,var(--cc) 40%,transparent),inset 0 0 40px #0008;pointer-events:none}
.cccard.show{opacity:1;transform:translate(-50%,-50%) scale(1);transition:transform .55s cubic-bezier(.2,1.5,.4,1),opacity .2s;pointer-events:auto}
.ccl{font:700 13px var(--ui,Poppins,sans-serif);letter-spacing:.3em;color:var(--cc);font-style:normal}
.ccic{animation:ccbob 1.6s ease-in-out infinite;filter:drop-shadow(0 0 16px var(--cc))}@keyframes ccbob{50%{transform:translateY(-8px) scale(1.06)}}
.ccn{font:400 56px/1 'Pirata One',Georgia,serif;color:#fff;text-shadow:0 0 18px var(--cc)}.cccard #ccart{max-width:100%;height:auto;filter:drop-shadow(0 0 20px var(--cc))}
.ccr{font:700 12px var(--ui,Poppins,sans-serif);letter-spacing:.25em;color:#1a1020;background:var(--cc);padding:4px 12px;border-radius:99px}
.ccok{all:unset;cursor:pointer;margin-top:6px;height:44px;line-height:44px;padding:0 30px;border-radius:12px;font:700 16px var(--ui,Poppins,sans-serif);color:#2a1700;background:linear-gradient(180deg,#ffd76a,#e8a820);box-shadow:0 4px 0 #8a5a08}.ccok:focus-visible{outline:3px solid #fff}
#cctoast{position:fixed;left:50%;bottom:36px;transform:translate(-50%,20px);z-index:99996;padding:10px 18px;border-radius:12px;background:#171326;border:1px solid #6d5fd0;color:#fff;font:600 14px var(--ui,Poppins,sans-serif);opacity:0;pointer-events:none;transition:.25s}#cctoast.show{opacity:1;transform:translate(-50%,0)}
.ccf{display:flex;gap:8px;align-items:flex-end;flex-wrap:wrap;margin:0 0 8px}.ccf label{display:flex;flex-direction:column;gap:3px;font:600 11px var(--ui,Poppins,sans-serif);color:#a9a2d4;flex:1;min-width:110px}
.ccf input,.ccf select{background:#0d0a1e;border:1px solid #4a4090;border-radius:7px;color:#fff;padding:6px 8px;font:600 13px var(--ui,Poppins,sans-serif);min-width:0}
.ccwh{font:700 10px var(--ui,Poppins,sans-serif);font-style:normal;letter-spacing:.08em;color:#a9a2d4;background:#2a2348;border-radius:99px;padding:2px 7px;margin-left:6px;vertical-align:middle}.ccwh.sh{color:#7dff9a;background:#13402a}
.ccdm{color:#ffe9a8;font:600 12px var(--ui,Poppins,sans-serif)}
.ccl2{display:flex;flex-direction:column;gap:6px;margin-top:6px}.ccrow{display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding:8px 10px;border-radius:9px;background:#1b1630;border:1px solid #3a3360}.ccrow.full{opacity:.65}
.ccrow>div:first-child{flex:1;min-width:130px;display:flex;flex-direction:column}.ccrow b{font:700 14px var(--ui,Poppins,sans-serif);letter-spacing:.08em;color:#ffd76a}.ccrow small{color:#a9a2d4;font:500 11px var(--ui,Poppins,sans-serif)}
.ccu{font:700 13px var(--ui,Poppins,sans-serif);color:#fff;background:#2a2348;border-radius:99px;padding:3px 10px}.ccrb{display:flex;gap:5px;flex-wrap:wrap}.dvb.dg{background:#6a1a2a;border-color:#ff6b86}
`;document.head.appendChild(s)}
