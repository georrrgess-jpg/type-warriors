/* ===== RUNESTONE TOWER DEFENSE 10.0: the Singularity Engine, art (98j, after 98a) =====
   The twelfth tower (TD_WORLDS_PLAN.md section 3): a brass orrery around a contained black-hole core. A round stone plinth carries a
   brass gear plate that turns; a fluted brass column ends in an emitter cup whose cyan beam holds the core afloat; two brass claws rise
   from the plate and hold the rim of its disk with cyan emitter gems. The core is a black sphere with a photon ring, a lensed arc over
   its top and a swirling magenta-cyan accretion disk (the far side behind the sphere, the near half over it); flat brass orbits ring it
   at their own tilts (baked; the near halves in front of the core), with brass beads and coloured planets running along them.
   Charging runs the beads, the disk and the gear faster, sparks crackle from the claws and motes spiral into the core; firing flashes
   the core and throws a shock ring. The battle module drives o.aim as an extra spin phase (it accumulates while charging), so the
   speed-up is smooth instead of a jump.
   Tiers: 1 brass, one orbit; 2 taller, two orbits, tesla pylons with cyan orbs on the plinth; 3 Event frame: a brass arch closes the
   claws over the core with a magenta crystal finial, gold-ringed top stone, cyan conduits up the claws, three planets; 4 Mythic
   (violet stone, dark iron and gold, a gold-hot core disk, three orbits, gems, orbiting runes); 5 Celestial (marble, white gold, a
   white-gold and cyan disk, a star finial, claw fins, wings and halo). Plugs into the shared pipeline of 95c (RPPAL/RPLAY/RPPULSE/
   RPWING/RPHALO + wrapped rpBodyArt, rpGlowList, rpTowerParts, rpTowerWarm), so icons, the build, upgrade and ascension animations and the 97k glow layer work as for every tower.
   Baked (rpSpr; the tower layers keyed by tier and skin so a recolouring skin can map them): the plinth, 8 gear frames per tier (one
   tooth of rotation), the column / claws / arch layer, the orbits, the sphere, the disk swirl, beads and planets; the well art (basin,
   spiral arms, debris chips), the orb. Per tower and frame: about as many draw calls as the Starfall Observatory.
   No shadowBlur, no ctx.filter; glows are the shared radial sprites drawn with 'lighter'. RPFX.lite draws less.
   The 9.9p layer of 97k gets the Engine's light sources (RPG_SRC.grav: core, cup, claw gems) and motes orbiting the core (RPG_PAR.grav).
   API (used by 98k)
     rpgvCore(tier,bob)                  the core centre relative to the pad centre {x,y} (unscaled: 98k multiplies by RPG.k)
     rpgvOrbDraw(g,x,y,tier,t,sc)        the gravity orb in flight (lensing ring, dark core, small disk)
     rpgvWell(g,x,y,r,k,t,tier,seed)     the well on the road (ground layer): k = 0..1 open, basin, accretion disk, spiral arms, ripples,
                                         debris spiralling in, the event horizon
     rpgvWellTop(g,x,y,r,k,t,tier,seed)  the singularity floating over the well and its lensing ring (top layer)
     rpgvTether(g,x0,y0,x1,y1,t,a,tier)  the strand from a caught monster to the centre (ground layer)
     rpgvLand(g,x,y,r,u,tier)            the burst when an orb lands, u = 0..1
     rpgvNova(g,x,y,r,u,tier)            the collapse: the well spins in, implosion flash, shock rings, rays, flung debris, u = 0..1 */
RPTW.grav={n:'Singularity Engine',role:'Crowd control',col:'#b86aff'};
RPSKIN.grav=['base'];
RPPAL.grav={base:{stone:RPSTONE.base,trim:'#ffd45a',trimL:'#fff0a8',trimD:'#b07a1a',iron:'#3a3466',ironL:'#6e66a8',ironD:'#191433',
 cyan:'#4af0ff',cyanL:'#dcfdff',mag:'#ff4ad8',magL:'#ffc8f4',copper:'#e08a4a',copperD:'#7a3a1a',glow:'#a04aff',glow2:'#4af0ff'}};
/* per tier: plinth radius/height pr ph, gear radius rg, core centre cy and radius cr, rings, planets, arch, pylons, top, tier 4-5 gems */
RPLAY.grav=[0,
 {pr:34,ph:8,rg:25,cy:-60,cr:13.5,rings:1,pl:1,arch:0,py:0,top:96,runes:[]},
 {pr:36,ph:9,rg:27,cy:-67,cr:14.5,rings:2,pl:2,arch:0,py:1,top:106,runes:[]},
 {pr:38,ph:10,rg:29,cy:-74,cr:15.5,rings:2,pl:3,arch:1,py:1,top:124,runes:[]},
 {pr:39,ph:10,rg:30,cy:-78,cr:16.5,rings:3,pl:3,arch:1,py:1,top:132,runes:[],inl:[[0,10,4.4],[-30,4,3.6],[30,4,3.6]]},
 {pr:40,ph:11,rg:31,cy:-82,cr:17.5,rings:3,pl:4,arch:1,py:1,top:146,runes:[],inl:[[0,10,4.6],[-30,4,3.8],[30,4,3.8]]}];
RPPULSE.grav=[2.2,.24];RPWING.grav=[40,-72];RPHALO.grav=[-156,24];
const rpgvT=t=>Math.max(1,Math.min(5,t|0||1));
/* metals per tier: m = [light, mid, dark, deep], band, ring = [light, mid, dark] */
const rpgvMet=tier=>tier>=5?{m:['#fffdf2','#f4e2a8','#d0a24a','#7a5a1a'],band:'#ffffff',bandD:'#c99a2a',ring:['#fffbe6','#ffe27a','#c99a2a']}
 :tier===4?{m:['#8e86b8','#4e4672','#2a2244','#14102a'],band:'#ffd45a',bandD:'#a8741a',ring:['#fff0a8','#ffd45a','#a8741a']}
 :{m:['#fff0b0','#e8b450','#a8701a','#5a3a10'],band:'#8a5418',bandD:'#4a2c08',ring:['#fff3c0','#e8b450','#8a5a14']};
/* energy per tier: disk stops (hot inside to cool outside), a = cyan (beams, arcs), b = magenta, g = core glow, f = finial crystal */
const rpgvEn=tier=>tier>=5?{d:['#ffffff','#fff4c0','#7af0ff','#c86aff'],a:'#8af4ff',b:'#ffc8f0',g:'#fff0c0',f:'#ffffff'}
 :tier===4?{d:['#ffffff','#ffe9a0','#ff4ad8','#5a12b0'],a:'#d8a0ff',b:'#ff5ad8',g:'#b060ff',f:'#c08aff'}
 :{d:['#ffffff','#7af8ff','#ff4ad8','#5a1aa8'],a:'#4af0ff',b:'#ff4ad8',g:'#a04aff',f:'#ff6ae0'};
/* vertical anchors: plinth top y0, gear top gy, cup rim cu */
function rpgvY(L){const y0=2-L.ph,gy=y0-4;return{y0,gy,cu:L.cy+L.cr+9}}
const rpgvCore=(tier,bob)=>{const L=RPLAY.grav[rpgvT(tier)];return{x:0,y:L.cy+(bob||0)}};
const rpgvDR=L=>L.cr*2,rpgvRingR=(L,i)=>rpgvDR(L)+5+i*4.6;

/* ---------- static body: the plinth (lower layer) ---------- */
function rpgvLowerArt(g,tier,P){const L=RPLAY.grav[tier],S=P.stone,Y=rpgvY(L);rpPadArt(g);
 rpMason(g,0,2,L.pr,L.pr-1,L.ph,S,1,8,9);rpTopStone(g,0,Y.y0,L.pr-1,S,13,tier>=3?P.trim:null);
 /* a brass band round the plinth foot (tier 2+) */
 if(tier>=2){g.beginPath();g.ellipse(0,2-L.ph*.45,L.pr-.4,(L.pr-.4)*RPSQ,0,.06,Math.PI-.06);g.lineWidth=4.4;g.strokeStyle=RPTO;g.stroke();g.lineWidth=2.2;g.strokeStyle=P.trim;g.stroke()}}
/* ---------- the gear plate (live: 8 frames over one tooth) ---------- */
const RPGV_TEETH=18,RPGV_GF=8;
function rpgvGearPath(g,cx,cy,r,rot,n,dep){const st=TAU/n;g.beginPath();for(let k=0;k<n;k++){const b=rot+k*st;
 for(const [u,rr] of [[0,r],[.12,r+dep],[.5,r+dep],[.62,r]]){const a=b+u*st;const x=cx+Math.cos(a)*rr,y=cy+Math.sin(a)*rr*RPSQ;k||u?g.lineTo(x,y):g.moveTo(x,y)}}g.closePath()}
function rpgvGearArt(g,tier,P,f){const L=RPLAY.grav[tier],Y=rpgvY(L),M=rpgvMet(tier),m=M.m,r=L.rg-3.2,rot=f/RPGV_GF*TAU/RPGV_TEETH;
 /* side (the plate is 4 px thick), then the toothed top face */
 rpgvGearPath(g,0,Y.gy+4,r,rot,RPGV_TEETH,3.2);g.fillStyle=m[2];g.fill();rpOut(g,2);
 g.fillStyle=m[3];g.fillRect(-r-4,Y.gy+3,2*r+8,1.4);
 rpgvGearPath(g,0,Y.gy,r,rot,RPGV_TEETH,3.2);g.fillStyle=rpHG(g,-r,r,m[0],m[1],m[2]);g.fill();rpOut(g,2);
 /* the recessed iron face with rivets and a rune ring */
 const ri=r*.72;g.beginPath();g.ellipse(0,Y.gy+.4,ri,ri*RPSQ,0,0,TAU);g.fillStyle=rpVG(g,Y.gy-ri*RPSQ,Y.gy+ri*RPSQ,tier===4?'#241a44':P.ironD,tier>=5?'#b8a6d8':tier===4?'#4a3a7a':P.iron);g.fill();rpOut(g,1.6);
 g.strokeStyle=tier>=5?'rgba(255,255,255,.6)':'rgba(255,255,255,.22)';g.lineWidth=1;g.beginPath();g.ellipse(0,Y.gy+1.2,ri,ri*RPSQ,0,.15,Math.PI-.15);g.stroke();
 for(let i=0;i<9;i++){const a=rot*2+i/9*TAU,x=Math.cos(a)*ri*.82,y=Y.gy+.4+Math.sin(a)*ri*.82*RPSQ;g.fillStyle=Math.sin(a)>0?m[0]:m[1];g.beginPath();g.arc(x,y,1.1,0,TAU);g.fill()}}
const rpgvGearS=(tier,skin,f)=>{const L=RPLAY.grav[tier];return rpSpr('gvg|'+tier+'|'+skin+'|'+f,-L.rg-6,-L.ph-L.rg*RPSQ-16,2*L.rg+12,2*L.rg*RPSQ+24,g=>rpgvGearArt(g,tier,rpPalT('grav',skin,tier),f))};
/* ---------- the upper layer: column, emitter cup, claws, arch, pylons ---------- */
/* a claw: from the gear plate out and up to the rim of the disk, where a hooked head with a cyan emitter gem holds it */
const rpgvTip=(L,k)=>({x:k*(rpgvDR(L)+5),y:L.cy+2});
function rpgvClaw(g,k,L,Y,M,P,tier){const x0=k*(L.rg-7),y0=Y.gy+1,T=rpgvTip(L,k),tx=T.x,ty=T.y+7,cx=k*(L.rg+12),cyy=(y0+ty)/2+6;
 const path=()=>{g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo(cx,cyy,tx,ty)};
 /* foot clamp on the gear */
 g.beginPath();g.ellipse(x0,y0+1,6,2.8,0,0,TAU);g.fillStyle=rpVG(g,y0-2,y0+4,M.m[1],M.m[2]);g.fill();rpOut(g,1.6);
 path();g.lineWidth=8.6;g.strokeStyle=RPTO;g.stroke();g.lineWidth=5.8;g.strokeStyle=M.m[k<0?1:2];g.stroke();
 g.lineWidth=1.6;g.strokeStyle=M.m[0];g.save();g.translate(-k*1.3,-.6);path();g.stroke();g.restore();
 /* cyan conduit along the claw (tier 3+) */
 if(tier>=3){g.save();g.translate(k*.8,.6);path();g.lineWidth=1.3;g.strokeStyle=rpgvEn(tier).a;g.setLineDash([3,3]);g.stroke();g.setLineDash([]);g.restore()}
 /* knuckle band */
 {const u=.5,bx=(1-u)*(1-u)*x0+2*u*(1-u)*cx+u*u*tx,by=(1-u)*(1-u)*y0+2*u*(1-u)*cyy+u*u*ty;g.beginPath();g.ellipse(bx,by,5,3.4,k*.35,0,TAU);g.fillStyle=rpHG(g,bx-5,bx+5,M.band,M.band,M.bandD);g.fill();rpOut(g,1.4)}
 /* the head: a hook that curls in over the rim of the disk */
 g.beginPath();g.moveTo(tx+k*4,ty+2);g.quadraticCurveTo(tx+k*6,ty-10,tx-k*2,ty-14);g.quadraticCurveTo(tx-k*7,ty-15,tx-k*8,ty-10);g.quadraticCurveTo(tx-k*3,ty-10,tx-k*1.6,ty-5);g.quadraticCurveTo(tx-k*1,ty+1,tx+k*4,ty+2);g.closePath();
 g.fillStyle=rpHG(g,tx-7,tx+7,M.m[0],M.m[1],M.m[2]);g.fill();rpOut(g,1.8);
 const E=rpgvEn(tier),gx=tx-k*6.4,gy=ty-9.4;g.beginPath();g.moveTo(gx,gy-4.4);g.lineTo(gx+3,gy);g.lineTo(gx,gy+4.4);g.lineTo(gx-3,gy);g.closePath();g.fillStyle=rpVG(g,gy-4,gy+4,'#ffffff',E.a);g.fill();rpOut(g,1.3);
 /* fins on the claw (tier 5) */
 if(tier>=5){g.beginPath();g.moveTo(tx+k*3,ty+4);g.quadraticCurveTo(tx+k*16,ty+2,tx+k*15,ty-12);g.quadraticCurveTo(tx+k*9,ty-3,tx+k*4,ty-4);g.closePath();g.fillStyle=rpHG(g,tx,tx+k*16,'#ffffff','#ffe9b0','#d8b060');g.fill();rpOut(g,1.4)}}
function rpgvUpperArt(g,tier,P){const L=RPLAY.grav[tier],Y=rpgvY(L),M=rpgvMet(tier),m=M.m,E=rpgvEn(tier);
 /* the arch over the core (tier 3+), behind it */
 if(L.arch){const ax=rpgvDR(L)+5-4,ay=L.cr+22,yb=L.cy-5;g.beginPath();g.ellipse(0,yb,ax,ay,0,Math.PI,TAU);g.lineWidth=6.6;g.strokeStyle=RPTO;g.stroke();g.lineWidth=4;g.strokeStyle=rpHG(g,-ax,ax,m[0],m[1],m[2]);g.stroke();
  g.lineWidth=1.2;g.strokeStyle='rgba(255,255,255,.6)';g.beginPath();g.ellipse(0,yb,ax-1.2,ay-1.2,0,Math.PI+.25,TAU-.9);g.stroke();
  /* gradation ticks on the arch */
  g.strokeStyle=M.bandD;g.lineWidth=1;g.beginPath();for(let i=1;i<12;i++){const a=Math.PI+i/12*Math.PI,c=Math.cos(a),s=Math.sin(a);g.moveTo(c*(ax-2.2),yb+s*(ay-2.2));g.lineTo(c*(ax+2.2),yb+s*(ay+2.2))}g.stroke();
  /* the finial: a collar and a crystal (a star at tier 5) */
  const fy=yb-ay;g.beginPath();g.ellipse(0,fy-1,4.4,2.4,0,0,TAU);g.fillStyle=rpHG(g,-4.4,4.4,M.band,M.band,M.bandD);g.fill();rpOut(g,1.4);
  if(tier>=5){rpsfStarArt(g,0,fy-10,7.6,'#ffffff','#ffe27a','#ffffff',1.6)}
  else{g.beginPath();g.moveTo(0,fy-16);g.lineTo(4.2,fy-7);g.lineTo(0,fy-1.5);g.lineTo(-4.2,fy-7);g.closePath();g.fillStyle=rpHG(g,-4.2,4.2,'#ffffff',E.f,rpMix(E.f,'#12081f',.45));g.fill();rpOut(g,1.5);
   g.fillStyle='rgba(255,255,255,.85)';g.beginPath();g.moveTo(-1.2,fy-12.5);g.lineTo(.6,fy-8.5);g.lineTo(-1.8,fy-7.6);g.closePath();g.fill()}}
 /* the fluted column from the gear hub to the emitter cup */
 const ch=Y.gy-(Y.cu+5);rpTube(g,0,Y.gy+.5,7.6,7.6,3,m[1],m[2],m[3],1.8);
 rpTube(g,0,Y.gy-2,6,4.6,ch-2,m[0],m[1],m[2],2);
 g.strokeStyle='rgba(18,8,31,.3)';g.lineWidth=1;for(const x of [-2.2,1.4])/* flutes */{g.beginPath();g.moveTo(x*1.15,Y.gy-3);g.lineTo(x,Y.cu+5);g.stroke()}
 for(const z of tier>=2?[.3,.72]:[.5])rpBand(g,0,Y.gy-2,6-1.4*z,ch*z,3,M.band,M.band,M.bandD,0);
 /* emitter cup: an upturned bowl with a dark mouth */
 g.beginPath();g.moveTo(-11,Y.cu);g.quadraticCurveTo(-9,Y.cu+7,-4.6,Y.cu+6.4);g.lineTo(4.6,Y.cu+6.4);g.quadraticCurveTo(9,Y.cu+7,11,Y.cu);g.closePath();g.fillStyle=rpHG(g,-11,11,m[0],m[1],m[2]);g.fill();rpOut(g,2);
 g.beginPath();g.ellipse(0,Y.cu,11,4.4,0,0,TAU);g.fillStyle=rpVG(g,Y.cu-4,Y.cu+4,m[1],m[3]);g.fill();rpOut(g,1.8);
 g.beginPath();g.ellipse(0,Y.cu+.4,7.6,2.8,0,0,TAU);g.fillStyle='#120a24';g.fill();
 /* the claws (left first, so the right one, in shade, overlaps nothing important) */
 rpgvClaw(g,-1,L,Y,M,P,tier);rpgvClaw(g,1,L,Y,M,P,tier);
 /* tesla pylons on the plinth front (tier 2+): an iron post, copper coils and a cyan orb */
 if(L.py)for(const k of [-1,1]){const x=k*(L.pr-8),yb=Y.y0+6,h=13+tier*1.4;
  g.beginPath();g.ellipse(x,yb,4.6,2,0,0,TAU);g.fillStyle=P.ironD;g.fill();rpOut(g,1.2);
  g.strokeStyle=RPTO;g.lineWidth=4.2;g.beginPath();g.moveTo(x,yb);g.lineTo(x,yb-h);g.stroke();g.strokeStyle=tier===4?'#4e4672':tier>=5?'#e8dcc0':P.iron;g.lineWidth=2.4;g.stroke();
  for(let i=0;i<3;i++){const y=yb-3-i*3.4;g.beginPath();g.ellipse(x,y,3.6,1.4,0,0,TAU);g.lineWidth=2.6;g.strokeStyle=RPTO;g.stroke();g.lineWidth=1.4;g.strokeStyle=tier>=5?'#ffe27a':P.copper;g.stroke()}
  const oy=yb-h-2.6;g.beginPath();g.arc(x,oy,3.4,0,TAU);g.fillStyle=rpHG(g,x-3.4,x+3.4,'#ffffff',E.a,rpMix(E.a,'#12081f',.4));g.fill();rpOut(g,1.4)}
 if(tier>=4)rpAscArt(g,'grav',tier,P,L)}
function rpgvBodyArt(g,tier,P){rpgvLowerArt(g,tier,P);rpgvGearArt(g,tier,P,0);rpgvUpperArt(g,tier,P)}
const rpgvLowS=(tier,skin,nopad)=>{const L=RPLAY.grav[tier];return rpSpr('gvl|'+tier+'|'+skin+'|'+(nopad?1:0),-66,-34,132,82,g=>{if(nopad)RPNOPAD=1;else RPPADT=tier;
 try{rpgvLowerArt(g,tier,rpPalT('grav',skin,tier))}finally{RPNOPAD=0;RPPADT=0}if(!nopad){g.save();g.translate(0,RPPIPY);rpPipArt(g,tier);g.restore()}})};
const rpgvUpS=(tier,skin)=>{const L=RPLAY.grav[tier];return rpSpr('gvu|'+tier+'|'+skin,-62,-(L.top+18),124,L.top+42,g=>rpgvUpperArt(g,tier,rpPalT('grav',skin,tier)))};
{const b0=rpBodyArt;rpBodyArt=function(g,type,tier,P){if(type==='grav')return rpgvBodyArt(g,tier,P);return b0.apply(this,arguments)}}
{const l0=rpGlowList;rpGlowList=function(type,tier,P,L){if(type!=='grav')return l0.apply(this,arguments);const G=[],A=(x,y,rx,ry,c,a)=>G.push([x,y,rx,ry,c,a]),Y=rpgvY(L),E=rpgvEn(tier);
 A(0,Y.cu,14,7,E.a,.6);for(const k of [-1,1]){const T=rpgvTip(L,k);A(T.x-k*6.4,T.y-2.4,9,9,E.a,.75)}
 if(L.py)for(const k of [-1,1])A(k*(L.pr-8),Y.y0+6-15-tier*1.4,10,10,E.a,.8);
 if(L.arch)A(0,L.cy-5-L.cr-22-8,12,14,tier>=5?'#fff6c8':E.f,.7);
 A(0,Y.gy,L.rg*.7,L.rg*.32,E.g,.22);{const R=rpgvDR(L);A(0,L.cy,R*1.5,R*1.15,E.g,.45);A(0,L.cy,R*1.1,R*.5,E.b,.25);A(0,L.cy+1,R*1.05,R*.4,E.d[1],.2);A(0,(Y.cu+L.cy+L.cr*.6)/2,2.6,(Y.cu-L.cy-L.cr*.6)/2+2,'#ffffff',.6)}
 if(tier>=4){const A4=RPASC[tier];for(const [x,y,z] of L.inl)A(x,y,z*3.4,z*3.4,A4.glow,.85);A(0,-L.top*.5,46,L.top*.5,A4.glow,.16)}return G}}

/* ---------- the core: sphere, accretion disk, lensed arc ---------- */
function rpgvSphereArt(g,r,tier){const E=rpgvEn(tier);
 g.beginPath();g.arc(0,0,r,0,TAU);const q=g.createRadialGradient(-r*.15,-r*.2,r*.05,0,0,r);q.addColorStop(0,'#000000');q.addColorStop(.62,'#05020c');q.addColorStop(.88,tier===4?'#2a0c5a':'#1c0a3a');q.addColorStop(1,tier>=5?'#6a5aa0':'#4a1c8a');g.fillStyle=q;g.fill();
 /* the photon ring hugging the edge */
 g.lineWidth=1.6;g.strokeStyle=rpA(tier>=5?'#ffffff':E.d[1],.9);g.beginPath();g.arc(0,0,r-1.1,0,TAU);g.stroke();
 g.beginPath();g.arc(0,0,r,0,TAU);rpOut(g,2.2);
 /* the lensed far side of the disk, bent up over the top */
 for(const [lw,c,a] of [[4.6,RPTO,.55],[2.6,E.d[2],.95],[1.1,'#ffffff',.95]]){g.globalAlpha=a;g.lineWidth=lw;g.strokeStyle=c;g.beginPath();g.ellipse(0,r*.08,r*1.34,r*1.2,0,Math.PI+.42,TAU-.42);g.stroke()}g.globalAlpha=1}
const rpgvSphS=(tier,skin)=>{const L=RPLAY.grav[tier],r=L.cr;return rpSpr('gvs|'+tier+'|'+skin,-r*1.5-4,-r*1.4-4,r*3+8,r*2.6+8,g=>rpgvSphereArt(g,r,tier))};
/* the accretion disk: a ring of hot gas with streaks, unit outer radius 64 (drawn squashed and turning) */
function rpgvDiskArt(g,tier){const E=rpgvEn(tier),R=64,ri=34;
 const q=g.createRadialGradient(0,0,ri-2,0,0,R);q.addColorStop(0,rpA(E.d[0],0));q.addColorStop(.03,rpA(E.d[0],1));q.addColorStop(.16,rpA(E.d[0],1));q.addColorStop(.3,rpA(E.d[1],1));q.addColorStop(.58,rpA(E.d[2],1));q.addColorStop(.84,rpA(E.d[3],.9));q.addColorStop(1,rpA(E.d[3],.35));
 g.fillStyle=q;g.beginPath();g.arc(0,0,R,0,TAU);g.arc(0,0,ri-2,0,TAU,true);g.fill();
 /* streaks so the turning shows: dark lanes and bright filaments */
 g.lineCap='round';for(let i=0;i<16;i++){const a=i/16*TAU+rpR(i)*.4,rr=ri+5+rpR(i+3)*(R-ri-12),len=.5+rpR(i+5)*1.1;g.beginPath();g.arc(0,0,rr,a,a+len);
  g.lineWidth=2+rpR(i+7)*3.4;g.strokeStyle=i%3?'rgba(40,6,70,.3)':'rgba(255,255,255,.6)';g.stroke()}
 g.beginPath();g.arc(0,0,R-1.5,0,TAU);g.lineWidth=3;g.strokeStyle='rgba(18,8,31,.75)';g.stroke()}
const rpgvDiskS=tier=>rpSpr('gvd|'+rpgvT(tier),-66,-66,132,132,g=>rpgvDiskArt(g,rpgvT(tier)),1.4);
/* the disk around (x,y), outer radius R, turned by spin */
/* front = 0 draws the whole disk (it goes behind the core, so no clip is needed), 1 the near half only (over the core) */
function rpgvDiskHalf(g,x,y,R,tier,spin,front,tilt,sq){const s=rpgvDiskS(tier);g.save();g.translate(x,y);g.rotate(tilt||0);if(front){g.beginPath();g.rect(-R-2,0,2*R+4,R+2);g.clip()}
 g.scale(R/64,R/64*(sq||.34));g.rotate(spin);g.globalAlpha=RPGA;g.drawImage(s.c,s.x0,s.y0,s.w,s.h);g.restore()}
/* the orrery orbits: flat brass rings round the core at fixed tilts (baked, back halves and front halves), and beads that run along
   them (live: they show the spin) */
const RPGV_OF=[.36,.5,.3],RPGV_OT=[-.3,.36,-.46];
function rpgvOrbitArt(g,tier,front){const L=RPLAY.grav[tier],M=rpgvMet(tier).ring,lw=tier>=4?2.2:1.9,lo=front?0:Math.PI;
 for(let i=0;i<L.rings;i++){const rr=rpgvRingR(L,i);g.beginPath();g.ellipse(0,0,rr,rr*RPGV_OF[i],RPGV_OT[i],lo,lo+Math.PI);g.lineWidth=lw+2.6;g.strokeStyle=RPTO;g.stroke();g.lineWidth=lw;g.strokeStyle=front?M[1]:M[2];g.stroke();
  if(front){g.lineWidth=Math.max(.8,lw*.4);g.strokeStyle=M[0];g.stroke()}}}
const rpgvOrbS2=(tier,front)=>{const L=RPLAY.grav[tier],e=rpgvRingR(L,L.rings-1)+4;return rpSpr('gvr|'+tier+'|'+(front?1:0),-e,-e,2*e,2*e,g=>rpgvOrbitArt(g,tier,front))};
/* beads and planets are small baked balls (one drawImage each) */
const rpgvBallS=(col,front)=>rpSpr('gvb|'+col+'|'+(front?1:0),-6,-6,12,12,g=>{g.beginPath();g.arc(0,0,4.4,0,TAU);g.fillStyle=col;g.fill();if(front){rpOut(g,1.6);g.fillStyle='rgba(255,255,255,.85)';g.beginPath();g.arc(-1.5,-1.5,1.5,0,TAU);g.fill()}},3);
function rpgvBeads(g,x,y,rr,f,tilt,front,M,lw,run,nb){const ry=rr*f,ct=Math.cos(tilt),st=Math.sin(tilt),b=rpgvBallS(front?M[0]:M[1],front),z=(lw*.85+.6)/4.4;
 for(let j=0;j<nb;j++){const th=run+j/nb*TAU,sn=Math.sin(th);if(front?sn<0:sn>=0)continue;const X=Math.cos(th)*rr,Yy=sn*ry,px=x+X*ct-Yy*st,py=y+X*st+Yy*ct;g.drawImage(b.c,px-6*z,py-6*z,12*z,12*z)}}
const RPGV_PLC=['#4af0ff','#ff5ad8','#ffd45a','#8aff7a'];
function rpgvPlanet(g,x,y,r,col){const b=rpgvBallS(col,1),z=r/4.4;g.drawImage(b.c,x-6*z,y-6*z,12*z,12*z)}
function rpgvLive(g,tier,P,t,o,L,ph){const E=rpgvEn(tier),M=rpgvMet(tier),lt=RPFX.lite,ch=Math.max(0,Math.min(1,o.charge||0)),f=Math.max(0,Math.min(1,o.fire||0)),Y=rpgvY(L),
  sp=(o.aim||0),bob=Math.sin(t*2+ph*5)*1.4-ch*1.5,x=0,y=L.cy+bob,cr=L.cr,R=rpgvDR(L),tilt=-.1+Math.sin(t*.7+ph)*.04;
 /* orbits: flat, each tilted its own way and slowly precessing; beads and planets run along them */
 const rings=[];for(let i=0;i<L.rings;i++){const dir=i%2?-1:1;rings.push({rr:rpgvRingR(L,i),f:RPGV_OF[i],tl:RPGV_OT[i],run:(t*(.9+i*.25)+sp*1.4)*dir+ph*3+i*1.7,i})}
 const pls=[];for(let i=0;i<L.pl;i++){const q=rings[i%rings.length],th=q.run*1.15+i*2.4+(i>=rings.length?Math.PI:0),X=Math.cos(th)*q.rr,Yy=Math.sin(th)*q.rr*q.f,ct=Math.cos(q.tl),st=Math.sin(q.tl);
  pls.push({x:x+X*ct-Yy*st,y:y+X*st+Yy*ct,z:Math.sin(th),c:RPGV_PLC[i%4]})}
 const orbits=(front)=>{rpPut(g,rpgvOrbS2(tier,front),x,y);for(const q of rings)rpgvBeads(g,x,y,q.rr,q.f,q.tl,front,M.ring,tier>=4?2.2:1.9,q.run,3);for(const p of pls)if((p.z>=0)===front)rpgvPlanet(g,p.x,p.y,(2.6+tier*.25)*(.85+.15*p.z),p.c)};
 /* glow behind the core */
 if(ch>.03||f>.03){g.globalCompositeOperation='lighter';rpGlow(g,x,y,R*1.5,R*1.15,E.g,.35*ch+.5*f);rpGlow(g,x,y,R*1.1,R*.5,E.b,.3*ch+.3*f);g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}
 orbits(false);
 /* the containment beam from the cup */
 g.globalCompositeOperation='lighter';{const yb=Y.cu,yt=y+cr*.6,h=(yb-yt)/2;rpGlow(g,0,(yb+yt)/2,7+3*ch,h+5,E.a,.6+.2*Math.sin(t*11+ph)+.3*ch)}
 g.globalCompositeOperation='source-over';g.globalAlpha=RPGA;
 const dspin=t*(1.6+tier*.1)+sp*2.2;
 rpgvDiskHalf(g,x,y,R,tier,dspin,0,tilt);
 g.globalAlpha=RPGA;rpPut(g,rpgvSphS(tier,'base'),x,y);
 rpgvDiskHalf(g,x,y,R,tier,dspin,1,tilt);
 g.globalAlpha=RPGA;orbits(true);
 g.globalCompositeOperation='lighter';
 /* the disk's inner edge burns brighter while charging */
 if(ch>.03||f>.03)rpGlow(g,x,y+1,R*1.05,R*.4,E.d[1],.4*ch+.4*f);
 /* sparks from the claw gems to the disk */
 if(!lt){const on=(((t*9+ph*7)|0)%4===0)||ch>.35;if(on)for(const k of [-1,1]){const T=rpgvTip(L,k),tx=T.x-k*6.4,ty=T.y-2.4;g.globalAlpha=RPGA*(.55+.45*ch);rpZigPath(g,tx,ty,x+k*cr*1.05,y-1,((t*20)|0)+k*7,2.5+ch*2);
   g.lineWidth=2.6;g.strokeStyle=rpA(E.a,.55);g.stroke();g.lineWidth=1.1;g.strokeStyle='#ffffff';g.stroke()}}
 /* charging: motes spiral into the core */
 if(ch>.05&&!lt){for(let i=0;i<6;i++){const u=(ch*1.7+i/6)%1,d=(1-u)*(R+14)+cr*.6,a=i/6*TAU+t*4+u*3;rpGlow(g,x+Math.cos(a)*d,y+Math.sin(a)*d*.45,3+2*ch,3+2*ch,i%2?E.a:E.b,Math.min(1,ch*2)*(.3+.7*u))}}
 /* firing: a white flash and a shock ring off the core */
 if(f>.02){const fl=f*f;rpGlow(g,x,y,cr*2+18*fl,cr*2+18*fl,'#ffffff',fl);rpGlow(g,x,y,R*1.4+30*fl,R*1.1+24*fl,E.b,.75*fl);
  g.globalCompositeOperation='source-over';const u=1-f,rr=R*.95+u*30;g.globalAlpha=RPGA*f*f;g.beginPath();g.ellipse(x,y,rr,rr*.36,tilt,0,TAU);g.lineWidth=2+3*f;g.strokeStyle=E.d[1];g.stroke();g.lineWidth=1;g.strokeStyle='#ffffff';g.stroke()}
 g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}
{const p0=rpTowerParts;rpTowerParts=function(g,type,tier,skin,t,o,nopad){if(type!=='grav')return p0.apply(this,arguments);
 const P=rpPalT(type,skin,tier),L=RPLAY[type][tier],ph=o.ph||0,ch=Math.max(0,Math.min(1,o.charge||0));
 if(tier>=4){if(!nopad)rpAscGround(g,tier,t,ph,1);rpAscLive(g,type,tier,t,ph,L,0)}
 g.globalAlpha=RPGA;rpPut(g,rpgvLowS(tier,skin,nopad));
 /* the gear plate turns (faster while charging) */
 {const gr=(t*.55+ph+(o.aim||0)*.25)*RPGV_TEETH/TAU*RPGV_GF,fi=((Math.floor(gr)%RPGV_GF)+RPGV_GF)%RPGV_GF;g.globalAlpha=RPGA;rpPut(g,rpgvGearS(tier,skin,fi))}
 rpPut(g,rpgvUpS(tier,skin));
 {const q=RPPULSE[type];g.globalCompositeOperation='lighter';g.globalAlpha=RPGA*(1-q[1]+q[1]*Math.sin(t*q[0]+ph*7))*(1+.4*ch);rpPut(g,rpGlowLayer(type,tier,skin));g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}
 if(!nopad){const u=((t+ph*2.3)*.28)%1;if(u<.12){const v=u/.12*tier,i=Math.min(tier-1,v|0);g.globalCompositeOperation='lighter';rpGlow(g,(i-(tier-1)/2)*10,RPPIPY-1,8,8,'#fff6c8',Math.sin(Math.PI*(v-i))*.95);g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}}
 rpgvLive(g,tier,P,t,o,L,ph);
 if(tier>=4)rpAscLive(g,type,tier,t,ph,L,1);
 g.globalCompositeOperation='source-over';g.globalAlpha=RPGA}}
{const w0=rpTowerWarm;rpTowerWarm=function(type,tier,skin){const r=w0.apply(this,arguments);if(type==='grav'){tier=rpgvT(tier);skin=RPPAL.grav[skin]?skin:'base';
  try{rpgvLowS(tier,skin,0);rpgvLowS(tier,skin,1);rpgvUpS(tier,skin);for(let f=0;f<RPGV_GF;f++)rpgvGearS(tier,skin,f);rpgvSphS(tier,skin);rpgvSphS(tier,'base');rpgvDiskS(tier);rpgvOrbS2(tier,0);rpgvOrbS2(tier,1);rpgvOrbS(tier);rpgvWellS(tier);rpgvArmS(tier)}catch(e){}}return r}}

/* 97k glow and particle layer: the core, the claw gems, the cup and pylons glow; motes orbit the core */
try{if(typeof RPG_SRC!=='undefined'){RPG_SRC.grav=[0,1,2,3,4,5].map(t=>{if(!t)return null;const L=RPLAY.grav[t],E=rpgvEn(t),a=[[0,L.cy,L.cr*2.4,t===4?'#c070ff':t===5?'#fff0c0':'#b05aff'],[0,L.cy+L.cr+9,16,E.a]];
  for(const k of [-1,1]){const T=rpgvTip(L,k);a.push([T.x-k*6.4,T.y-2.4,12,E.a])}return a});
 RPG_PAR.grav={k:'orbit',n:[0,3,4,5,6,7],c:['#9af6ff','#ff9af0','#e8c8ff'],s:'dot',y:[0,-60,-67,-74,-78,-82],r:[0,36,38,40,42,44],z:2.8}}}catch(e){}

/* ---------- the gravity orb ---------- */
function rpgvOrbArt(g,tier){const E=rpgvEn(tier);g.drawImage(rpGlowC(E.g),-22,-22,44,44);
 g.beginPath();g.arc(0,0,7,0,TAU);const q=g.createRadialGradient(-1,-1.5,.5,0,0,7);q.addColorStop(0,'#000000');q.addColorStop(.75,'#0a0418');q.addColorStop(1,'#5a2aa8');g.fillStyle=q;g.fill();
 g.lineWidth=1.2;g.strokeStyle=E.d[1];g.beginPath();g.arc(0,0,6,0,TAU);g.stroke();g.beginPath();g.arc(0,0,7,0,TAU);rpOut(g,2)}
const rpgvOrbS=tier=>rpSpr('gvo|'+rpgvT(tier),-22,-22,44,44,g=>rpgvOrbArt(g,rpgvT(tier)));
function rpgvOrbDraw(g,x,y,tier,t,sc){tier=rpgvT(tier);const E=rpgvEn(tier),k=sc||1;g.save();g.translate(x,y);g.scale(k,k);
 g.globalCompositeOperation='lighter';rpGlow(g,0,0,30,30,E.b,.55);rpGlow(g,0,0,16,16,E.a,.6);g.globalCompositeOperation='source-over';g.globalAlpha=1;
 /* a small disk round the orb */
 rpgvDiskHalf(g,0,0,13,tier,t*7,0,-.3,.36);rpPut(g,rpgvOrbS(tier));rpgvDiskHalf(g,0,0,13,tier,t*7,1,-.3,.36);
 /* the lensing ring: space bends round it, so a thin bright ring wobbles a little way out */
 const w=1+.08*Math.sin(t*17);g.globalAlpha=.9;g.beginPath();g.ellipse(0,0,19*w,17/w,t*2,0,TAU);g.lineWidth=3.6;g.strokeStyle='rgba(18,8,31,.35)';g.stroke();g.lineWidth=1.6;g.strokeStyle=E.d[1];g.stroke();
 g.globalAlpha=.6;g.beginPath();g.ellipse(0,0,24/w,21*w,-t*1.4,0,TAU);g.lineWidth=1;g.strokeStyle='#ffffff';g.stroke();g.restore();g.globalAlpha=1}

/* ---------- the well ---------- */
/* the dark basin and its rune rim (unit radius 100, drawn squashed) */
function rpgvWellArt(g,tier){const E=rpgvEn(tier);
 const q=g.createRadialGradient(0,0,0,0,0,100);q.addColorStop(0,'rgba(2,0,8,1)');q.addColorStop(.2,'rgba(14,2,36,.92)');q.addColorStop(.5,rpA(rpMix(E.d[3],'#0a0418',.35),.7));q.addColorStop(.82,rpA(E.d[3],.38));q.addColorStop(1,rpA(E.d[3],0));
 g.fillStyle=q;g.beginPath();g.arc(0,0,100,0,TAU);g.fill();
 /* contour lines bending down into the pit */
 g.lineWidth=1.2;for(const [r,a] of [[30,.35],[48,.28],[66,.22]]){g.strokeStyle=rpA(E.d[1],a);g.beginPath();g.arc(0,0,r,0,TAU);g.stroke()}
 /* the rim: a dark band, a dashed cyan rune ring and a magenta line */
 g.lineWidth=7;g.strokeStyle='rgba(18,8,31,.5)';g.beginPath();g.arc(0,0,93,0,TAU);g.stroke();g.lineWidth=3;g.strokeStyle=rpA(E.a,.95);g.setLineDash([14,9]);g.stroke();g.setLineDash([]);
 g.lineWidth=2;g.strokeStyle=rpA(E.b,.8);g.beginPath();g.arc(0,0,85,0,TAU);g.stroke()}
/* spiral arms: three logarithmic arms, magenta outside, cyan-white inside (drawn with 'lighter', turning) */
function rpgvArmArt(g,tier){const E=rpgvEn(tier);g.lineCap='round';
 for(let a=0;a<3;a++){const a0=a/3*TAU;for(let j=0;j<26;j++){const u0=j/26,u1=(j+1)/26,r0=96*Math.pow(1-u0,1.1)+4,r1=96*Math.pow(1-u1,1.1)+4,t0=a0+u0*4.2,t1=a0+u1*4.2;
   g.beginPath();g.moveTo(Math.cos(t0)*r0,Math.sin(t0)*r0);g.lineTo(Math.cos(t1)*r1,Math.sin(t1)*r1);g.lineWidth=3+12*(1-u0)*u0*2.2;g.strokeStyle=rpA(rpMix(E.b,E.a,u0),.3+.6*u0);g.stroke();
   g.lineWidth=1.6;g.strokeStyle=rpA('#ffffff',.15+.55*u0*u0);g.stroke()}}}
const rpgvWellS=tier=>rpSpr('gvw|'+rpgvT(tier),-102,-102,204,204,g=>rpgvWellArt(g,rpgvT(tier)),1);
const rpgvArmS=tier=>rpSpr('gva|'+rpgvT(tier),-102,-102,204,204,g=>rpgvArmArt(g,rpgvT(tier)),1);
/* debris chips: three little rocks (baked) */
const rpgvChipS=v=>rpSpr('gvc|'+v,-6,-6,12,12,g=>{g.beginPath();const n=5+v;for(let i=0;i<n;i++){const a=i/n*TAU,r=3.6+rpR(i+v*9)*1.6;i?g.lineTo(Math.cos(a)*r,Math.sin(a)*r):g.moveTo(Math.cos(a)*r,Math.sin(a)*r)}g.closePath();
 g.fillStyle=['#8a7a6a','#6a6080','#a08a70'][v%3];g.fill();rpOut(g,1.3);g.fillStyle='rgba(255,255,255,.4)';g.beginPath();g.arc(-1.2,-1.2,1.2,0,TAU);g.fill()});
function rpgvWell(g,x,y,r,k,t,tier,seed){if(k<=.01)return;tier=rpgvT(tier);const E=rpgvEn(tier),sq=RPFX.sq,lt=RPFX.lite,rk=r*(.25+.75*k),s=rk/100;seed=seed||0;
 g.save();g.translate(x,y);g.scale(s,s*sq);g.globalAlpha=Math.min(1,k*1.3);rpPut(g,rpgvWellS(tier));
 {const d=rpgvDiskS(tier);g.save();g.rotate(t*1.8+seed);g.scale(.95,.95);g.globalAlpha=Math.min(1,k)*.85;g.drawImage(d.c,d.x0,d.y0,d.w,d.h);g.restore()}
 g.globalCompositeOperation='lighter';g.rotate(t*2.4+seed);g.globalAlpha=Math.min(1,k)*.8;rpPut(g,rpgvArmS(tier));g.restore();
 /* ripples running inward */
 g.save();for(let i=0;i<(lt?2:3);i++){const u=(t*.9+i/3+seed)%1,rr=rk*(1-u)*.95;if(rr<4)continue;g.globalAlpha=Math.min(1,k)*Math.sin(Math.PI*u)*.7;
  g.beginPath();g.ellipse(x,y,rr,rr*sq,0,0,TAU);g.lineWidth=1.4+2*u;g.strokeStyle=i%2?E.a:E.b;g.stroke()}
 /* debris spiralling in */
 g.globalCompositeOperation='source-over';const n=lt?5:9;for(let i=0;i<n;i++){const u=(t*.55+i/n+seed*.37)%1,rho=rk*.95*Math.pow(1-u,.8),th=rpR(i*7+seed)*TAU+u*5.5+t*.6,px=x+Math.cos(th)*rho,py=y+Math.sin(th)*rho*sq-u*6;
  const a=Math.min(1,k)*Math.min(1,u*4)*Math.min(1,(1-u)*5);if(a<.03)continue;if(i%3===2){g.globalCompositeOperation='lighter';rpGlow(g,px,py,4+3*u,4+3*u,i%2?E.a:E.b,a);g.globalCompositeOperation='source-over'}
  else{const z=(1.1-.5*u);g.globalAlpha=a;g.save();g.translate(px,py);g.rotate(u*9+i);g.scale(z,z);rpPut(g,rpgvChipS(i%3));g.restore()}}
 g.globalAlpha=1;
 /* the event horizon at the centre: a black pit with a burning rim */
 const hr=Math.max(3,rk*.17);g.globalCompositeOperation='lighter';rpGlow(g,x,y,hr*3.2,hr*3.2*sq,E.b,.6*k);rpGlow(g,x,y,hr*2,hr*2*sq,E.d[1],.55*k);g.globalCompositeOperation='source-over';
 g.globalAlpha=Math.min(1,k*1.5);g.beginPath();g.ellipse(x,y,hr,hr*sq,0,0,TAU);g.fillStyle='#05010c';g.fill();g.lineWidth=2.2;g.strokeStyle=E.d[1];g.stroke();g.lineWidth=1;g.strokeStyle='#ffffff';g.stroke();g.restore();g.globalAlpha=1}
/* the singularity floating over the well, with a lensing ring (drawn over the monsters) */
function rpgvWellTop(g,x,y,r,k,t,tier,seed){if(k<=.01)return;tier=rpgvT(tier);const E=rpgvEn(tier),hy=y-62-Math.sin(t*3+(seed||0))*3,z=(.55+.45*k)*(.72+.05*tier);
 g.save();g.globalCompositeOperation='lighter';
 /* a thin beam down to the pit */
 g.globalAlpha=.35*k;rpGlow(g,x,(hy+y)/2,4,(y-hy)/2+4,E.a,.45*k);
 rpGlow(g,x,hy,26*z,26*z,E.g,.55*k);g.globalCompositeOperation='source-over';g.globalAlpha=Math.min(1,k*1.4);
 g.translate(x,hy);g.scale(z,z);rpgvDiskHalf(g,0,0,17,tier,t*6,0,-.2,.34);rpPut(g,rpgvOrbS(tier));rpgvDiskHalf(g,0,0,17,tier,t*6,1,-.2,.34);
 /* the lensing ring: a bright ring that breathes, bending the light round the core */
 const w=1+.1*Math.sin(t*5+(seed||0));g.globalAlpha=Math.min(1,k)*.85;g.beginPath();g.ellipse(0,0,28*w,24/w,t*.8,0,TAU);g.lineWidth=3.4;g.strokeStyle='rgba(18,8,31,.3)';g.stroke();g.lineWidth=1.4;g.strokeStyle=E.d[1];g.stroke();
 g.globalAlpha=Math.min(1,k)*.5;g.beginPath();g.ellipse(0,0,34/w,30*w,-t*.6,0,TAU);g.lineWidth=1;g.strokeStyle='#ffffff';g.stroke();g.restore();g.globalAlpha=1}
/* a strand from a caught monster (x0,y0) to the centre (x1,y1), bent sideways like the swirl */
function rpgvTether(g,x0,y0,x1,y1,t,a,tier){if(a<=.02)return;const E=rpgvEn(tier),dx=x1-x0,dy=y1-y0,mx=(x0+x1)/2-dy*.35,my=(y0+y1)/2+dx*.2;g.globalAlpha=a*(.7+.3*Math.sin(t*12+x0));
 g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo(mx,my,x1,y1);g.lineWidth=2;g.strokeStyle=E.b;g.stroke();g.globalAlpha=1}
/* an orb landing: a flash and a ring that unrolls the well */
function rpgvLand(g,x,y,r,u,tier){if(u<=0||u>=1)return;const E=rpgvEn(tier),e=1-Math.pow(1-u,3),sq=RPFX.sq;g.save();g.globalCompositeOperation='lighter';
 rpGlow(g,x,y-8,46+34*e,34+24*e,E.b,(1-u)*1.05);rpGlow(g,x,y-10,22,18,'#ffffff',Math.max(0,1-u*2.2));if(u<.5){g.save();g.translate(x,y-12);g.rotate(u*3);const z=(.25+.45*e);g.scale(z,z*.8);g.globalAlpha=(1-u/.5)*.7;rpPut(g,rpRaysS());g.restore()}
 g.globalCompositeOperation='source-over';
 for(let j=0;j<2;j++){const v=Math.max(0,u-j*.12)/(1-j*.12);if(v<=0)continue;const rr=r*(.15+(j?.8:1.02)*(1-Math.pow(1-v,3)));g.globalAlpha=1-v;g.beginPath();g.ellipse(x,y,rr,rr*sq,0,0,TAU);g.lineWidth=5*(1-v)+2;g.strokeStyle='rgba(18,8,31,.55)';g.stroke();g.lineWidth=3*(1-v)+1;g.strokeStyle=j?E.a:E.b;g.stroke()}
 g.restore();g.globalAlpha=1}
/* the collapse: everything rushes in (the well spins down, streaks pour into the centre), a white flash, then a shock ring, rays and
   flung debris (r = the nova radius). Vivid magenta / cyan / gold whatever the tier, so it reads on every map */
const RPGV_NV=['#ff4ad8','#4af0ff','#ffd45a','#a04aff'];
function rpgvNova(g,x,y,r,u,tier){if(u<=0||u>=1)return;const C=RPGV_NV,sq=RPFX.sq,lt=RPFX.lite;g.save();
 const ui=Math.min(1,u/.22),uo=Math.max(0,(u-.18)/.82),eo=1-Math.pow(1-uo,3);
 if(u<.22){rpgvWell(g,x,y,r*.78*(1-ui*ui),1-ui,u*24,tier,0);g.globalCompositeOperation='lighter';
  /* streaks pouring into the centre */
  const n=lt?6:12;for(let i=0;i<n;i++){const a=i/n*TAU+ui*2.2,d0=r*(1.05-.9*ui)*(.75+.3*rpR(i)),d1=d0*(.45+.2*ui);g.globalAlpha=Math.sin(Math.PI*ui)*.9;
   g.beginPath();g.moveTo(x+Math.cos(a)*d0,y+Math.sin(a)*d0*sq);g.lineTo(x+Math.cos(a+.35)*d1,y+Math.sin(a+.35)*d1*sq);g.lineWidth=2.4;g.strokeStyle=C[i%2];g.stroke()}
  /* the converging ring */
  const rr=r*.8*(1-ui*ui);g.globalAlpha=.95;g.beginPath();g.ellipse(x,y,rr,rr*sq,0,0,TAU);g.lineWidth=4+5*ui;g.strokeStyle=C[0];g.stroke();g.lineWidth=1.8;g.strokeStyle='#ffffff';g.stroke();
  rpGlow(g,x,y-10,18+34*ui,18+34*ui,C[3],ui);rpGlow(g,x,y-10,8+16*ui,8+16*ui,'#ffffff',ui)}
 g.globalCompositeOperation='lighter';
 /* the flash */
 const fl=u<.22?ui*ui:Math.max(0,1-uo*2.4);rpGlow(g,x,y-14,46+r*.5*eo,40+r*.35*eo,'#ffffff',fl*.9);rpGlow(g,x,y-14,r*(.55+.6*eo),r*(.45+.45*eo),C[0],(1-uo)*.85);rpGlow(g,x,y-8,r*(.5+.6*eo),r*(.5+.6*eo)*sq,C[1],(1-uo)*.55);
 /* rays */
 if(uo>0&&uo<.7){g.save();g.translate(x,y-14);g.rotate(uo*1.4);const z=(40+r*1.1*eo)/120;g.scale(z,z);g.globalAlpha=(1-uo/.7)*.8;rpPut(g,rpRaysS());g.restore()}
 g.globalCompositeOperation='source-over';
 /* the shock rings on the ground: magenta, then cyan, with a dark edge */
 if(uo>0){for(let j=0;j<2;j++){const v=Math.max(0,uo-j*.12)/(1-j*.12);if(v<=0||v>=1)continue;const rr=r*(.15+.95*(1-Math.pow(1-v,3)));g.globalAlpha=Math.min(1,(1-v)*1.4);g.beginPath();g.ellipse(x,y,rr,rr*sq,0,0,TAU);
   g.lineWidth=11*(1-v)+3;g.strokeStyle='rgba(18,8,31,.6)';g.stroke();g.lineWidth=7*(1-v)+1.6;g.strokeStyle=C[j];g.stroke();g.lineWidth=1.8*(1-v)+.6;g.strokeStyle='#ffffff';g.stroke()}}
 /* debris flung outward */
 if(uo>0&&uo<.8){const n=lt?6:14;for(let i=0;i<n;i++){const a=i/n*TAU+rpR(i+(x|0))*.5,d=r*(.2+.85*eo)*(.7+.4*rpR(i+3)),px=x+Math.cos(a)*d,py=y+Math.sin(a)*d*sq-50*eo*(1-eo)*2*rpR(i+5)-6;
   g.globalAlpha=1-uo/.8;if(i%2){g.globalCompositeOperation='lighter';rpGlow(g,px,py,6,6,C[(i>>1)%3],1-uo/.8);g.globalCompositeOperation='source-over'}else{g.save();g.translate(px,py);g.rotate(uo*12+i);rpPut(g,rpgvChipS(i%3));g.restore()}}}
 g.restore();g.globalAlpha=1}
