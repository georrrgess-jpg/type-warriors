/* ===== UPDATE 10.4, THE HARVEST FESTIVAL: the gear ability Bountiful Harvest (99n3, prefix flb) =====
   Carried by the two Mythic harvest relics, Feastlord's Aegis and the Horn of Plenty (84g_gear_ability.js style; Soul Harvest is
   its Halloween sibling). Wearing one gives the ability; wearing both is a set and makes it stronger.
   - The harvest meter fills on every word you type: 2 grains for a flawless word, 1 for a word that slipped or a boss sentence.
   - Full (30 grains, 21 as a set): a golden cornucopia flies in over the field, tips and pours a stream of fruit-light from left to
     right. Every monster the stream reaches is harvested (killed, worth 50% bonus score). Bosses are partly spared: the last quarter
     of their sentence falls away (at a word break); all projectiles are swept up at once.
   - The fruit leaves an overgrowth of wheat: all monsters move (and wind up their attacks) 30% slower for 6 s (9 s as a set).
     The set also restores 1 health with each burst.
   Balance (tools/fl/gab_bal.py, a typing bot in Endless against Soul Harvest with the same gear stats): a flawless typist needs
   15 words (10-11 as a set) against Soul Harvest's 13 (9); a 94%-accurate bot triggers both about equally often (0.9 vs 0.86 a
   minute at 35 WPM, 1.2 vs 1.08 at 50) for the same score. Soul Harvest gives a shield, this gives the overgrowth and bounty score.
   Art: the cornucopia, the fruit and their glows are painted once into sprites; each frame only places them. Sounds are
   synthesized: a wooden marimba note and a seed rattle per word climbing a pentatonic scale, a harvest horn call, a woody thump,
   a tumbling cascade of plucks as the fruit falls and a warm choir chord. */
GAB.bounty={n:FL.ab.n,c:'#ffc23a',
 d:"Every word you type fills the harvest: 2 grains for a flawless word, 1 if it slipped or for a boss sentence. At 30 grains a golden cornucopia bursts over the field. Its fruit-light harvests every monster it reaches for 50% bonus score and leaves an overgrowth that slows all foes by 30% for 6 seconds. Bosses are partly spared: they only lose the last quarter of their sentence. Projectiles are swept away.",
 set:"Set bonus: wear Feastlord's Aegis and the Horn of Plenty together and the harvest needs only 21 grains, the overgrowth lasts 9 seconds and each burst also restores 1 health."};
AR.flfeast.ab='bounty';WP.fl_horn.ab='bounty';AR.flfeast.d+='. Ability: Bountiful Harvest';WP.fl_horn.d+='. Ability: Bountiful Harvest';
const FLB={need:[0,30,21],slow:[0,6,9],k:.7,bonus:.5,cut:.25,col:'#ffcf4a',lt:'#fff2b8',
 FR:['apple','pear','grapes','pumpkin','wheat','apple2'],FC:['#ff5a3a','#c8e04a','#b06aff','#ff9a2a','#ffe08a','#ffc040']};
const flbNeed=()=>FLB.need[Math.max(1,Math.min(2,(S&&S.fbN)|0))];
const flbRM=()=>{try{return(typeof ccReduce==='function'&&ccReduce())||ST.perf==='low'}catch(e){return false}};

/* run start: count the equipped pieces once (the run snapshot keeps it for resumed runs) */
{const st0=start;start=function(){const r=st0.apply(this,arguments);try{S.fbN=S.prac?0:gabCount('bounty',P.armor,S.wpn||P.weapon);S.fbm=0;S.fbB=null;S.fbG=[];S.fbS=0;S.fbS0=0;S.fbP=0;S.fbU=0;S.fbK=0}catch(e){}return r}}

/* every typed word feeds the harvest (forced kills, chains and the harvest itself do not) */
{const k0=kill;kill=function(e,force){const on=!!(S&&S.fbN>0&&!force&&S.mode==='play'&&!S.prac&&e&&S.en.includes(e)),boss=!!(e&&e.boss),bad=!!(e&&(e.bad||e.slip>0)),v0=boss?(e.vul||0):0;
  const r=k0.apply(this,arguments);
  try{if(on){if(!boss){if(!S.en.includes(e))flbAdd(e,bad?1:2)}else if((e.vul||0)>0&&!(v0>0))flbAdd(e,1)}}catch(x){}
  return r}}
function flbAdd(e,n){S.fbm=(S.fbm||0)+n;S.fbP=1;(S.fbG||(S.fbG=[])).push({x:e.x,y:e.y-(e.h||80)*.6,t:0,n});if(S.fbG.length>14)S.fbG.shift();flbTone(S.fbm);
 if(S.fbm>=flbNeed()){S.fbm=0;flbBurst()}}

/* ---------- the burst ---------- */
function flbBurst(){const set=S.fbN>=2;S.fbU=(S.fbU||0)+1;
 S.fbB={t:0,set,x:KX+40,done:new Set(),fr:[],sp:0,hx:KX+250,hy:GY-470};
 for(const j of S.pj||[]){burst(j.x,j.y,'#ffcf4a',10,{v:240});S.fbB.fr.push({x:j.x,y:j.y,vx:-60+Math.random()*120,vy:-260,k:Math.random()*FLB.FR.length|0,r:Math.random()*6,vr:(Math.random()-.5)*8,s:.8})}
 S.pj=[];
 S.fbS0=FLB.slow[set?2:1];S.fbS=S.fbS0;
 let healed=false;if(set&&S.hp>0&&S.hp<S.max){S.hp++;healed=true}
 float(W/2,250,'BOUNTIFUL HARVEST!',FLB.col,64);float(KX+60,GY-300,healed?'+1 HP  Overgrowth':'Overgrowth: foes slowed',healed?'#7dffb0':'#d8f08a',30);
 S.flash=Math.max(S.flash,.22);S.shake=Math.max(S.shake,12);flbBoom(set)}
/* a boss is partly spared: only the last quarter of its sentence falls away (at a word break) */
function flbSpare(e){if(!e||e.state!=='fight'||e.vul>0||typeof e.w!=='string')return false;const L=e.w.length,i0=e.i|0,left=L-i0;let cut=false;
 if(left>8){let keep=L-Math.floor(left*FLB.cut);const sp=e.w.lastIndexOf(' ',keep);if(sp>i0+3)keep=sp;keep=Math.max(i0+3,keep);if(keep<L){e.w=e.w.slice(0,keep).replace(/\s+$/,'');cut=e.w.length<L}}
 e.fl=.5;float(e.x-40,GY-e.h-60,cut?'The harvest takes a quarter!':'Spared',FLB.col,30);burst(e.x-40,GY-e.h*.5,FLB.col,24,{v:360});return cut}
function flbHarvest(e){const s0=S.score,x=e.x,y=e.y-(e.h||80)*.5;kill(e,true);const d=S.score-s0,bn=Math.max(0,Math.round(d*FLB.bonus));if(bn){S.score+=bn;float(x+30,y-(e.h||80)*.5-96,'+'+bn+' bounty',FLB.col,26)}
 S.fbK=(S.fbK||0)+1;burst(x,y,FLB.col,16,{v:320});burst(x,y,'#ff7a3a',8,{v:240});if(S.fx)S.fx.push({k:'ring',x,y,t:0,ml:.45,c:'#ffd86a',w:6,r0:10,r1:130})}

/* overgrowth slows monsters; the burst sweeps the field; timers tick */
{const u0=update;update=function(dt){if(!S||S.mode!=='play'||!(S.fbN>0))return u0.apply(this,arguments);
  const slow=S.fbS>0&&!S.cine,mod=[];
  if(slow){for(const e of S.en){if(!e.boss){mod.push([e,e.sp,e.at]);e.sp*=FLB.k}}}
  const r=u0.apply(this,arguments);
  for(const [e,sp,at] of mod){e.sp=sp;if(at!=null&&e.at!=null&&e.at<at)e.at=at-(at-e.at)*FLB.k}
  if(S.mode!=='play')return r;
  S.fbP=Math.max(0,(S.fbP||0)-dt*2.4);if(S.fbS>0)S.fbS=Math.max(0,S.fbS-dt);
  if(S.fbG&&S.fbG.length){for(const o of S.fbG)o.t+=dt*1.1;S.fbG=S.fbG.filter(o=>o.t<1)}
  const B=S.fbB;if(B){B.t+=dt;const k=sstep(0,1,Math.min(1,Math.max(0,(B.t-.5)/.95)));B.x=lerp(KX+40,W+90,k);
   if(B.t>.5&&B.t<1.6){S.inChain=1;try{for(const e of[...S.en]){if(B.done.has(e)||e.x>B.x||e.x>W-10)continue;B.done.add(e);if(e.boss)flbSpare(e);else flbHarvest(e)}}finally{S.inChain=0}}
   flbFruitStep(B,dt);if(B.t>2.6)S.fbB=null}
  return r}}
RS_SKIP.add('fbB');RS_SKIP.add('fbG');

/* ---------- sprites (painted once) ---------- */
const FLBS={};
const flbFruitSpr=i=>flgFruitSpr(FLB.FR[i]);
function flbGlowSpr(col){const k='g'+col;if(FLBS[k])return FLBS[k];const c=document.createElement('canvas');c.width=c.height=96;const g=c.getContext('2d'),q=g.createRadialGradient(48,48,0,48,48,48);q.addColorStop(0,col+'cc');q.addColorStop(.35,col+'55');q.addColorStop(1,col+'00');g.fillStyle=q;g.fillRect(0,0,96,96);return FLBS[k]=c}
/* the great cornucopia: woven gold, banded, its mouth glowing and heaped with fruit. M = the mouth centre in sprite pixels */
const FLBH={w:460,h:330,M:null,MA:0};
function flbHornSpr(){if(FLBS.h)return FLBS.h;const c=document.createElement('canvas');c.width=FLBH.w;c.height=FLBH.h;const g=c.getContext('2d');g.lineJoin='round';g.lineCap='round';
 const B=[[96,92],[176,30],[330,60],[372,214]],bz=(u,k)=>{const m=1-u;return m*m*m*B[0][k]+3*m*m*u*B[1][k]+3*m*u*u*B[2][k]+u*u*u*B[3][k]};
 const C=[];{let x=B[0][0],y=B[0][1],h=Math.atan2(B[0][1]-B[1][1],B[0][0]-B[1][0]);const cu=[];for(let k=0;k<14;k++){h+=.27+k*.04;x+=Math.cos(h)*7.2;y+=Math.sin(h)*7.2;cu.push([x,y])}for(let k=cu.length-1;k>=0;k--)C.push(cu[k])}
 for(let i=0;i<=24;i++){const u=i/24;C.push([bz(u,0),bz(u,1)])}
 const n=C.length,wf=u=>3+Math.pow(u,1.2)*64,pp=hwTube(C,wf);
 const OL0=OL;OL=0;
 arBev(g,pp,'#e0a02c',{ow:5,edge:'#fff2b8',ew:6,tex:(g2,b)=>{g2.strokeStyle='#7a4a10cc';g2.lineWidth=3.4;g2.beginPath();for(let k=-400;k<400;k+=13){g2.moveTo(b[0]+k,b[1]);g2.lineTo(b[0]+k+300,b[1]+300);g2.moveTo(b[0]+k+300,b[1]);g2.lineTo(b[0]+k,b[1]+300)}g2.stroke();
  g2.strokeStyle='#ffe8a050';g2.lineWidth=2;g2.beginPath();for(let k=-400;k<400;k+=13){g2.moveTo(b[0]+k+2,b[1]);g2.lineTo(b[0]+k+302,b[1]+300)}g2.stroke();
  const q=g2.createLinearGradient(0,b[1],0,b[3]);q.addColorStop(0,'#ffffff40');q.addColorStop(.5,'#ffffff00');q.addColorStop(1,'#00000050');g2.fillStyle=q;g2.fillRect(b[0],b[1],b[2]-b[0],b[3]-b[1])}});
 for(const u of[.42,.58,.74,.9]){const i=Math.round((14+u*24)),p=C[Math.min(n-2,i)],q=C[Math.min(n-1,i+1)],a=Math.atan2(q[1]-p[1],q[0]-p[0]),w=wf(u)*1.04;g.strokeStyle='#12081f';g.lineWidth=9;g.beginPath();g.moveTo(p[0]-Math.sin(a)*w,p[1]+Math.cos(a)*w);g.lineTo(p[0]+Math.sin(a)*w,p[1]-Math.cos(a)*w);g.stroke();g.strokeStyle='#ffe07a';g.lineWidth=5;g.stroke();g.strokeStyle='#fff6d0';g.lineWidth=1.6;g.stroke()}
 const m=C[n-1],mp=C[n-4],ma=Math.atan2(m[1]-mp[1],m[0]-mp[0]),mw=wf(1)*1.03;FLBH.M=[m[0],m[1]];FLBH.MA=ma;
 g.save();g.translate(m[0],m[1]);g.rotate(ma);g.beginPath();g.ellipse(0,0,13,mw,0,0,TAU);g.fillStyle='#3a1a06';g.fill();{const q=g.createRadialGradient(6,0,0,6,0,mw*1.3);q.addColorStop(0,'#fff2b8');q.addColorStop(.4,'#ffc84a99');q.addColorStop(1,'#ffc84a00');g.fillStyle=q;g.fill()}
 g.strokeStyle='#12081f';g.lineWidth=10;g.stroke();g.strokeStyle='#ffd86a';g.lineWidth=6;g.stroke();g.strokeStyle='#fff6d0';g.lineWidth=2;g.stroke();g.restore();
 /* fruit heaped in the mouth */
 const ox=Math.cos(ma),oy=Math.sin(ma),nx=-oy,ny=ox;
 for(const [k,a,b,s,r] of[[4,8,-50,6.4,ma+1.3],[2,18,40,6,ma-.6],[1,30,-22,6.4,.4],[3,22,4,6.6,.1],[0,40,14,6.8,-.2],[5,48,-38,5.6,.6],[0,50,40,5.8,.3]])flgFruit(g,FLB.FR[k],m[0]+ox*a+nx*b,m[1]+oy*a+ny*b,s,1.2,r);
 OL=OL0;return FLBS.h=c}
/* the small cornucopia icon on the HUD meter */
function flbIconSpr(){if(FLBS.i)return FLBS.i;const h=flbHornSpr(),c=document.createElement('canvas');c.width=92;c.height=66;c.getContext('2d').drawImage(h,0,0,FLBH.w,FLBH.h,0,0,92,66);return FLBS.i=c}

/* fruit-light: launched from the mouth toward the sweep front, falling under gravity */
function flbMouth(B){const k=Math.min(1,B.t/.45),e=1-Math.pow(1-k,3),cx=lerp(KX-120,B.hx,e),cy=lerp(-160,B.hy,e),tip=B.t<.45?0:Math.min(1,(B.t-.45)/.3),rot=-.25+tip*.42-(B.t>1.4?(B.t-1.4)*.25:0),sc=.55+.45*e;
 const M=FLBH.M||[372,214],dx=(M[0]-FLBH.w/2)*sc*.8,dy=(M[1]-FLBH.h/2)*sc*.8,c=Math.cos(rot),s=Math.sin(rot);return{cx,cy,rot,sc,mx:cx+dx*c-dy*s,my:cy+dx*s+dy*c}}
function flbFruitStep(B,dt){const rm=flbRM();
 if(B.t>.5&&B.t<1.45&&!rm){B.sp+=dt*34;const m=flbMouth(B);while(B.sp>=1){B.sp--;const tx=Math.min(W-30,B.x+(Math.random()-.3)*160),ty=GY-30-Math.random()*190,T=.42+Math.random()*.2,gr=1500;
   B.fr.push({x:m.mx,y:m.my,vx:(tx-m.mx)/T,vy:(ty-m.my)/T-.5*gr*T,k:Math.random()*FLB.FR.length|0,r:Math.random()*6,vr:(Math.random()-.5)*10,s:.7+Math.random()*.5,land:0})}}
 for(const f of B.fr){f.vy+=1500*dt;f.x+=f.vx*dt;f.y+=f.vy*dt;f.r+=f.vr*dt;if(f.y>GY-8&&!f.land){f.land=1;f.vy*=-.28;f.vx*=.4;f.y=GY-8;if(B.fr.length<70)burst(f.x,GY-10,FLB.FC[f.k],4,{v:140,l:.5})}}
 B.fr=B.fr.filter(f=>f.x>-60&&f.x<W+60&&(f.land<1||f.vy<0||f.y<GY-6)&&!(f.land&&Math.abs(f.vy)<30))}

/* ---------- drawing on the field ---------- */
{const dw0=drawWorld;drawWorld=function(){dw0.apply(this,arguments);if(!S||!(S.fbN>0))return;const c=ctx;
  if(S.fbS>0&&S.fbS0>0)try{flbDrawGrowth(c)}catch(e){}
  if(S.fbB)try{flbDrawBurst(c,S.fbB)}catch(e){}}}
/* the overgrowth: wheat sprouts round each monster's feet and a golden shimmer runs along the ground */
function flbDrawGrowth(c){const k=S.fbS/S.fbS0,inA=Math.min(1,(S.fbS0-S.fbS)/.35),a=Math.min(inA,Math.min(1,S.fbS/.6)),t=S.t;c.save();
 c.globalAlpha=a*.55;const q=c.createLinearGradient(0,GY-40,0,GY+30);q.addColorStop(0,'#ffcf4a00');q.addColorStop(.6,'#ffcf4a55');q.addColorStop(1,'#ffcf4a00');c.fillStyle=q;c.fillRect(KX+40,GY-40,W-KX-40,70);
 c.globalAlpha=a;for(const e of S.en){if(e.boss||e.x>W-10)continue;const y0=(MON[e.id]&&MON[e.id].fly)?e.y+18:GY+2;for(let i=0;i<5;i++){const dx=(i-2)*13+Math.sin(i*2.3)*4,h=(18+(i%3)*7)*inA,sw=Math.sin(t*2.4+i+e.ph)*3,x0=e.x+dx;
   c.strokeStyle='#5a4a14';c.lineWidth=3.2;c.beginPath();c.moveTo(x0,y0);c.quadraticCurveTo(x0+sw*.4,y0-h*.5,x0+sw,y0-h);c.stroke();c.strokeStyle=i%2?'#d8b84a':'#a8b84a';c.lineWidth=1.8;c.stroke();
   if(h>10){c.fillStyle='#f0c860';c.beginPath();c.ellipse(x0+sw,y0-h-3,2.4,5,sw*.05,0,TAU);c.fill();c.strokeStyle='#12081f99';c.lineWidth=1;c.stroke()}}}
 c.restore()}
function flbDrawBurst(c,B){const t=B.t,m=flbMouth(B),H=flbHornSpr(),fade=t>1.7?Math.max(0,1-(t-1.7)/.8):1,app=Math.min(1,t/.2);
 c.save();c.globalCompositeOperation='lighter';
 /* warm light behind the horn */
 const gs=flbGlowSpr('#ffc84a'),R=260*m.sc*(1+.08*Math.sin(t*9));c.globalAlpha=.7*fade*app;c.drawImage(gs,m.cx-R,m.cy-R,R*2,R*2);
 /* the pouring stream of light from the mouth to the sweep front */
 if(t>.45&&t<1.9){const s=Math.min(1,(t-.45)/.15)*fade*(t>1.45?Math.max(0,1-(t-1.45)/.45):1);c.globalAlpha=.5*s;const bx=Math.min(W,B.x),g=c.createLinearGradient(m.mx,m.my,bx,GY);g.addColorStop(0,'#fff2b8');g.addColorStop(.5,'#ffc84a88');g.addColorStop(1,'#ff9a2a00');c.fillStyle=g;
  c.beginPath();c.moveTo(m.mx-30,m.my-10);c.quadraticCurveTo((m.mx+bx)/2-60,(m.my+GY)/2-40,bx-240,GY+10);c.lineTo(bx+90,GY+10);c.quadraticCurveTo((m.mx+bx)/2+40,(m.my+GY)/2-90,m.mx+34,m.my+14);c.closePath();c.fill();
  c.globalAlpha=.6*s;const gl=flbGlowSpr('#fff2b8');c.drawImage(gl,bx-90,GY-120,180,180)}
 c.restore();
 /* the cornucopia */
 c.save();c.globalAlpha=fade*app;c.translate(m.cx,m.cy);c.rotate(m.rot+Math.sin(t*14)*.012*(t>.45&&t<1.45?1:0));const s=m.sc*.8*(1+(t>1.7?(t-1.7)*.25:0));c.scale(s,s);c.drawImage(H,-FLBH.w/2,-FLBH.h/2);c.restore();
 /* fruit-light in flight */
 c.save();for(const f of B.fr){const sp=flbFruitSpr(f.k),gl=flbGlowSpr(FLB.FC[f.k]),z=f.s*40;c.globalAlpha=fade*.8;c.globalCompositeOperation='lighter';c.drawImage(gl,f.x-z*1.2,f.y-z*1.2,z*2.4,z*2.4);c.globalCompositeOperation='source-over';c.globalAlpha=fade;
  c.save();c.translate(f.x,f.y);c.rotate(f.r);c.drawImage(sp,-z*.5,-z*.5,z,z);c.restore()}c.restore();
 /* sparkles round the horn */
 if(!flbRM()){c.save();c.globalCompositeOperation='lighter';for(let i=0;i<10;i++){const u=(t*1.3+i*.37)%1,a=i*2.4+t,r=60+u*170*m.sc,x=m.cx+Math.cos(a)*r,y=m.cy+Math.sin(a)*r*.7,z=(1-u)*7+2;c.globalAlpha=Math.sin(u*Math.PI)*fade;c.fillStyle='#fff6d0';c.fillRect(x-1,y-z,2,z*2);c.fillRect(x-z,y-1,z*2,2)}c.restore()}}

/* ---------- the HUD meter: bottom left, above the Pause button (above Soul Harvest's gauge when both are worn) ---------- */
{const dh0=drawHUD;drawHUD=function(){dh0.apply(this,arguments);try{if(S&&S.fbN>0&&S.mode!=='title')flbHUD(ctx)}catch(e){}}}
function flbHUD(c){const need=flbNeed(),n=Math.min(need,S.fbm||0),fr=n/need,og=S.fbS>0&&S.fbS0>0,x0=20,ph=og?70:56,y0=S.hvN>0?(og?692:706):772,bw=226,pop=S.fbP||0,t=S.t;c.save();
 c.fillStyle='rgba(6,4,16,.66)';c.beginPath();c.roundRect(x0-6,y0-22,bw+96,ph,12);c.fill();c.strokeStyle=FLB.col+flgA(.3+fr*.55);c.lineWidth=1.5;c.stroke();
 c.textBaseline='middle';c.textAlign='left';c.font='18px "Pirata One",Georgia,serif';c.fillStyle=FLB.col;c.fillText('Bountiful Harvest',x0+4,y0-6);
 if(S.fbN>=2){const tw=c.measureText('Bountiful Harvest').width,px=x0+12+tw;c.fillStyle='#ffcf4a';c.beginPath();c.roundRect(px,y0-14,34,16,8);c.fill();c.font='800 10px Poppins,sans-serif';c.fillStyle='#2a1406';c.textAlign='center';c.fillText('SET',px+17,y0-5.6);c.textAlign='left'}
 c.textAlign='right';c.font='18px "Pirata One",Georgia,serif';c.fillStyle='#fff2b8';c.fillText(n+' / '+need,x0+bw+4,y0-6);c.textAlign='left';
 /* the grain bar */
 const by=y0+11,bh=11;c.fillStyle='#ffffff18';c.beginPath();c.roundRect(x0+4,by,bw,bh,5.5);c.fill();
 if(fr>0){const g=c.createLinearGradient(x0+4,0,x0+4+bw,0);g.addColorStop(0,'#c8862a');g.addColorStop(1,'#ffe07a');c.fillStyle=g;c.beginPath();c.roundRect(x0+4,by,Math.max(bh,bw*fr),bh,5.5);c.fill()}
 c.fillStyle='#12081f66';for(let i=2;i<need;i+=2){const x=x0+4+bw*i/need;c.fillRect(x-.6,by+2,1.2,bh-4)}
 c.strokeStyle='#12081f';c.lineWidth=1.5;c.beginPath();c.roundRect(x0+4,by,bw,bh,5.5);c.stroke();
 /* overgrowth: a third row with its countdown */
 if(og){const oy=by+bh+9,k=S.fbS/S.fbS0;c.fillStyle='#ffffff14';c.beginPath();c.roundRect(x0+4,oy,bw-104,6,3);c.fill();c.fillStyle='#b8e05a';c.beginPath();c.roundRect(x0+4,oy,Math.max(6,(bw-104)*k),6,3);c.fill();
  c.font='600 12.5px Poppins,sans-serif';c.fillStyle='#d8f08a';c.textAlign='right';c.fillText('Overgrowth '+Math.ceil(S.fbS)+'s',x0+bw+4,oy+3.4);c.textAlign='left'}
 /* the cornucopia icon at the end of the bar: it wiggles as grain arrives and glows when nearly full */
 const ic=flbIconSpr(),ix=x0+bw+12,iy=y0-14,wob=Math.sin(t*30)*pop*.12;
 if(fr>.75){c.save();c.globalCompositeOperation='lighter';c.globalAlpha=(fr-.75)*4*(.6+.4*Math.sin(t*6));c.drawImage(flbGlowSpr('#ffcf4a'),ix-24,iy-30,120,110);c.restore()}
 c.save();c.translate(ix+38,iy+26);c.rotate(wob);c.scale(1+pop*.1,1+pop*.1);c.drawImage(ic,-38,-26,76,54);c.restore();
 /* grain flying from a word to the bar */
 c.globalCompositeOperation='lighter';const tx=x0+4+bw*fr,ty=by+bh/2;for(const o of S.fbG||[]){for(let k=3;k>=0;k--){const u=sstep(0,1,Math.max(0,o.t-k*.05)),x=lerp(o.x,tx,u),y=lerp(o.y,ty,u)-Math.sin(u*Math.PI)*110,f=1-k*.2;c.globalAlpha=f*Math.min(1,o.t*4);c.drawImage(flbGlowSpr('#ffcf4a'),x-12*f,y-12*f,24*f,24*f);if(!k){c.fillStyle='#fff2b8';c.beginPath();c.ellipse(x,y,2.4,4,u*6,0,TAU);c.fill()}}}
 c.restore()}

/* ---------- sound ---------- */
const FLB_SC=[0,2,4,7,9,12,14,16,19,21,24,26];
function flbTone(n){if(typeof axOn!=='function'||!axOn())return;try{const t=ac.currentTime+.01,need=flbNeed(),k=Math.min(FLB_SC.length-1,Math.floor(n/need*(FLB_SC.length-1))),f=nf(62+FLB_SC[k]),full=n>=need-4;
 cTone(sg,t,f,.55,'triangle',.07,{a:.003,lp:2600,lp2:600});cTone(sg,t,f*4,.1,'sine',.022,{a:.002});cTone(sg,t,f*.5,.32,'sine',.045,{a:.004});
 cNoise(sg,t,.09,.03,{type:'highpass',f1:5200,f2:3800,a:.006});cNoise(sg,t+.06,.07,.018,{type:'highpass',f1:6200,f2:4200,a:.006});
 if(full){cTone(sg,t+.04,f*1.5,.7,'triangle',.028,{a:.03,lp:1800,lp2:900});cTone(sg,t,nf(50),.8,'sawtooth',.016,{a:.1,lp:800,lp2:420})}}catch(e){}}
function flbBoom(set){if(typeof axOn!=='function'||!axOn())return;try{const t=ac.currentTime+.02;
 /* a harvest horn call: a rising fifth, then the octave */
 cBrass(sg,t,nf(55),.36,.045);cBrass(sg,t+.2,nf(62),.36,.045);cBrass(sg,t+.4,nf(67),1,.055);cBrass(sg,t+.4,nf(59),1,.03);
 /* the cornucopia bursts: a woody thump and a rush of air */
 cKick(sg,t+.48,.5,120,40,.55);cNoise(sg,t+.4,.7,.07,{type:'bandpass',f1:300,f2:3600,q:1.1,a:.25});
 /* the cascade: plucks tumbling down a major pentatonic scale, each with a little wooden knock */
 const sc=[96,93,91,88,86,84,81,79,76,74,72,69,67,64,62,60];sc.forEach((m,i)=>{const tt=t+.52+i*.06+Math.random()*.02;cTone(sg,tt,nf(m-12),.5,'triangle',.05,{a:.003,lp:3000,lp2:700});cNoise(sg,tt,.04,.025,{type:'bandpass',f1:1800,f2:900,q:3,a:.003})});
 /* a warm major chord swells under it, a seed rattle shakes */
 for(const m of[60,64,67,72])cChoir(sg,t+.55,nf(m),1.9,.015);cTone(sg,t+.55,nf(36),1.6,'sine',.09,{a:.3,hold:1,r:.8});
 for(let i=0;i<7;i++)cNoise(sg,t+.52+i*.12,.08,.028,{type:'highpass',f1:5600,f2:4200,a:.005});
 if(set)cSpark(sg,t+.75,8,1.1,84,.03)}catch(e){}}
