/* ===== 10.7 THE CROOKED CUE: three LEGENDARY ball sets (97bf, prefix pzbl, after 97ba and the venue modules) =====
   Painted by the shared material painter of 97b6 (pzb3Reg); every pattern is laid on the ball's own normal (lx,ly,lz) so it rolls.
   - Phoenix Plume (100,000): rows of long flame-tongued feathers that sweep round the ball in a curling spiral, the row above lying over
     the row below. Each feather burns hottest along its quill (the ball's hue pushed bright), cools through the ball's colour to a warmer,
     deeper edge with a dark lip and a molten line, and carries a hot ring "eye" near its tip; the gaps between feathers glow, ember sparks
     drift over the plume and a fire aura sits at the silhouette. Stripes: ash-white feathers with faint warm quills. The 8: charcoal
     feathers edged with thin ember lines, an ivory disc ringed in fire.
   - Thunder Orb (150,000): tinted storm glass (the ball's colour all through it, never black) with storm cloud inside (sampled under the
     surface, so it slides against it as the ball turns), deeper glass toward the rim, a plasma core glowing in the middle of the ball as you
     look at it, and five jagged lightning bolts with three forks, each a hot thread in its ball's tint inside a coloured halo.
     Stripes: frosted silver glass caps with pale lilac bolts. The 8: black storm glass with violet-white lightning, a white disc ringed in violet.
   - Gilded Hoard (250,000): cloisonne. Coloured glossy enamel in organic cells divided by raised, polished gold wire (the zero line of
     a gyroid field), an inner filigree loop round each cell and a small cut gem (ruby or sapphire, emerald on red) in a gold bezel at the
     heart of some cells. Stripes: ivory porcelain enamel caps with finer wire. The 8: black enamel with gold wire and rubies, an ivory
     disc ringed in gold.
   Cost: the feather layout and the bolt network depend only on where a point is on the ball, so they are baked once into a ball-space
   cube map (pzblCube: 3 ms slices starting shortly after load, or at first use; until it is ready the same function runs per pixel). No allocation in the
   materials. pzbPaint is wrapped once to hand the view direction (ball-local) to the thunder cloud parallax.
   Also: the Cue Rack marks sets of 100,000 and more (b.leg) with a gold-and-red LEGENDARY ribbon (cards and the detail title) instead of
   PREMIUM, and the strip stays sorted by price. Test: t_pzb107.py. */
const PZBL={vx:0,vy:0,vz:1,LEG:100000};
{const f0=pzbPaint;pzbPaint=function(slot,n,M){const K=PZ_BS&&PZ_BS.pal&&PZ_BS.pal.kind;if(K==='thunder'){PZBL.vx=M[6];PZBL.vy=M[7];PZBL.vz=M[8]}return f0.apply(this,arguments)}}
/* fast atan2 (error about 1e-5 rad) */
function pzblAt2(y,x){const ax=x<0?-x:x,ay=y<0?-y:y,mx=ax>ay?ax:ay;if(mx<1e-9)return 0;const a=(ax>ay?ay:ax)/mx,s=a*a;let r=((-.0464964749*s+.15931422)*s-.327622764)*s*a+a;if(ay>ax)r=1.57079637-r;if(x<0)r=3.14159274-r;return y<0?-r:r}
/* triangle wave of period 1, -1..1 */
const pzblT=x=>{const u=x-Math.floor(x);return u<.5?u*4-1:3-u*4};
/* a ball-space cube map: the parts of a pattern that only depend on where you are on the ball are baked once into six faces
   (nearest texel, about one texel per pixel of a 64 px ball), so a material reads them back instead of working them out per pixel */
function pzblCubeIx(x,y,z,N){const ax=x<0?-x:x,ay=y<0?-y:y,az=z<0?-z:z;let f,m,u,v;
 if(ax>=ay&&ax>=az){f=x>0?0:1;m=ax;u=x>0?-z:z;v=-y}else if(ay>=az){f=y>0?2:3;m=ay;u=x;v=y>0?z:-z}else{f=z>0?4:5;m=az;u=z>0?x:-x;v=-y}
 const k=.5*N/m;let iu=(u*k+N*.5)|0,iv=(v*k+N*.5)|0;if(iu>=N)iu=N-1;if(iv>=N)iv=N-1;return (f*N+iv)*N+iu}
/* a cube bake made a slice at a time (about 3 ms a frame, so opening the Cue Rack or a match never stalls); until it is ready the
   material works the same texel function out for the pixel itself (pzblLook), so the look is the same either way */
const pzblTMP=new Float32Array(4);
function pzblCube(N,fn){return {N,fn,A:null,f:0,iv:0,ready:0,busy:0}}
function pzblSlice(B){if(!B.A)B.A=new Float32Array(6*B.N*B.N*4);const N=B.N,A=B.A,fn=B.fn,t0=performance.now();
 while(B.f<6){const f=B.f,iv=B.iv,v=(iv+.5)/N*2-1;for(let iu=0;iu<N;iu++){const u=(iu+.5)/N*2-1;let x,y,z;
   if(f===0){x=1;z=-u;y=-v}else if(f===1){x=-1;z=u;y=-v}else if(f===2){y=1;x=u;z=v}else if(f===3){y=-1;x=u;z=-v}else if(f===4){z=1;x=u;y=-v}else{z=-1;x=-u;y=-v}
   const m=1/Math.sqrt(x*x+y*y+z*z);fn(x*m,y*m,z*m,A,((f*N+iv)*N+iu)*4)}
  if(++B.iv>=N){B.iv=0;B.f++}if(performance.now()-t0>3)break}
 if(B.f>=6){B.ready=1;B.busy=0;try{PZ_BS.dirtyAll=1}catch(e){}}else setTimeout(()=>pzblSlice(B),16)}
function pzblStart(B){if(!B.ready&&!B.busy){B.busy=1;setTimeout(()=>pzblSlice(B),0)}}
/* the texel values at a point: from the bake when it is ready, else worked out now */
function pzblLook(B,lx,ly,lz){if(B.ready){const q=pzblCubeIx(lx,ly,lz,B.N)*4,A=B.A;pzblTMP[0]=A[q];pzblTMP[1]=A[q+1];pzblTMP[2]=A[q+2];pzblTMP[3]=A[q+3]}else B.fn(lx,ly,lz,pzblTMP,0);return pzblTMP}

/* ---------------------------------------------------------------- Phoenix Plume */
const pzblNR=5,pzblH=Math.PI/pzblNR,pzblIH=1/pzblH,pzblNC=new Int16Array(16),pzblPW=new Float32Array(16);
for(let i=-7;i<=7;i++){const c=Math.abs(Math.cos(i*pzblH)),nc=Math.max(3,Math.round(2*Math.PI*c/(.92*pzblH)));pzblNC[i+7]=nc;pzblPW[i+7]=2*Math.PI/(nc*pzblH)}
/* one feather of row i under the point (t rows up, fr turns round, rad from the axis): sets pzblS (0 root .. 1 tip), pzblX (-1..1 across), pzblHs */
let pzblS=0,pzblX=0,pzblHs=0;
function pzblFeather(i,t,fr,rad){const nc=pzblNC[i+7],y=i-t,sv=(y+.5)*.54;if(sv<=0||sv>=1)return 0;
 const u=fr*nc+((i&1)?.5:0)+y*.3+y*y*.12,jn=((u+64.5)|0)-64,x=(u-jn)*pzblPW[i+7]*rad,ax0=x<0?-x:x,w0=.6*(1-sv*sv)*(1-.3*sv)*(sv<.12?.6+sv*3.3:1);
 if(ax0>w0*(1+.16*sv))return 0;const w=w0*(1+.16*sv*pzblT(sv*2.4+(x<0?.27:0)+i*.37+jn*.18));if(ax0>=w)return 0;
 pzblS=sv;pzblX=x/w;const h=(jn*.6180339+i*.4142136+64)*7.31;pzblHs=h-(h|0);return 1}
/* the plume, baked: per texel the feather's s (-1 in a gap), x across, its random tint and the spark */
const PZBL_PH=pzblCube(80,(lx,ly,lz,A,o)=>{const rad=Math.sqrt(lx*lx+lz*lz),t=pzblAt2(ly,rad)*pzblIH,i0=Math.floor(t+.5),fr=pzblAt2(lx,lz)*.15915494;
 /* the row above first: its tips lie over the roots of this row; the feathers lean (a slow spiral round the ball) */
 const hit=pzblFeather(i0+1,t,fr,rad)||pzblFeather(i0,t,fr,rad);A[o]=hit?pzblS:-1;A[o+1]=hit?pzblX:0;A[o+2]=hit?pzblHs:.5;
 let sp=0;const qx=Math.floor(lx*7),qy=Math.floor(ly*7),qz=Math.floor(lz*7),h=pzb2Hash(qx,qy,qz);if(h>.88){const cx=lx*7-qx-.5,cy=ly*7-qy-.5,cz=lz*7-qz-.5,dd=cx*cx+cy*cy+cz*cz,v=1-dd*16;if(v>0)sp=v*v*(h-.88)*8.3}A[o+3]=sp});
function pzblPhoenix(o){
 const PC=pzblLook(PZBL_PH,o.lx,o.ly,o.lz),s0=PC[0],hit=s0>=0,s=hit?s0:0,xn=PC[1],hs=PC[2],sp=PC[3];
 const C=o.C,CP=o.CP,band=o.band,ab=o.ab,ax=xn<0?-xn:xn;
 let r=0,g=0,b=0,er=0,eg=0,eb=0;
 /* feather parts: the quill (a hot thread down the middle), barbs, a dark lip at the edge and a molten line just inside it */
 let quill=0,barb=1,lip=0,mel=0,dome=0,heat=0;
 if(hit){const q0=1-ax*6;quill=q0>0?q0*q0*(1-s*.7):0;barb=.95+.1*pzblT((ax*.9-s*1.1)*2.5+hs);
  const l0=(ax-.82)*6;lip=l0>0?(l0>1?1:l0):0;const m0=1-(ax>.7?ax-.7:.7-ax)*8;mel=m0>0?m0*m0*(.3+.7*s):0;dome=1-ax*ax*.3;const hx=1-ax;heat=hx*hx*(.55+.45*(1-s))}
 if(o.is8){/* charcoal feathers with ember edges, a glowing quill root and a red glow in the gaps */
  const k=hit?(.8+.45*dome)*barb*(1-lip*.7)*(.9+.2*hs):.5;r=(C[0]+10)*k;g=(C[1]+7)*k;b=(C[2]+7)*k;
  const em=mel*1.2+lip*(1-lip)*1.4,gp=hit?0:1,hq=quill*heat;er=230*em+70*gp+200*hq*.5;eg=70*em+12*gp+90*hq*.5;eb=14*em+4*gp+20*hq*.5;
  er+=255*sp*.7;eg+=150*sp*.7;eb+=40*sp*.7}
 else{
  /* the fire: emitted colour from the hot root (the hue pushed bright) through the ball colour to a deep ember tip */
  const h2=heat*heat,tk=.5+.5*heat,cw=1-heat,mr=C[0]*tk+(o.hr-C[0]*tk)*h2*.85+(C[0]>C[2]?30:6)*cw,mg=C[1]*tk*(1-.2*cw)+(o.hg-C[1]*tk)*h2*.85,mb=C[2]*tk*(1-.25*cw)+(o.hb-C[2]*tk)*h2*.85,
   fk=hit?dome*barb*(1-lip*.85)*(.9+.2*hs):.3;
  let fR=mr*fk,fG=mg*fk,fB=mb*fk;
  const hq=quill*.85+mel*.7;fR+=(o.hr+40-fR)*hq*.55;fG+=(o.hg+20-fG)*hq*.55;fB+=(o.hb-fB)*hq*.55;
  if(!hit){fR=o.hr*.95;fG=o.hg*.8;fB=o.hb*.6}
  /* the eye near each tip: a hot ring round a deep core with a bright spark in it (the signature of the set) */
  else if(s>.5){const ey=(s-.7)*7.7,ex=xn*2.3,e=ey*ey+ex*ex;if(e<1.6){const rg0=1-(e>1?e-1:1-e)*3.2,rg=rg0>0?rg0:0;
   if(e<.62){const d=(.62-e)*4,k=d>1?1:d;fR+=(C[0]*.28-fR)*k;fG+=(C[1]*.22-fG)*k;fB+=(C[2]*.25-fB)*k;if(e<.1){const c=(.1-e)*10;fR+=(o.hr-fR)*c;fG+=(o.hg-fG)*c;fB+=(o.hb-fB)*c}}
   fR+=(o.hr+30-fR)*rg;fG+=(o.hg+18-fG)*rg;fB+=(o.hb-fB)*rg}}
  /* a fire aura at the silhouette */
  {const ra=o.RA*.7;fR+=o.hr*ra;fG+=o.hg*ra*.8;fB+=o.hb*ra*.5}
  /* ash caps: pale feathers, warm along the quill and the edge */
  const ak=hit?(.9+.1*dome)*(.95+.05*barb)*(1-lip*.4):.6;
  r=C[0]*.2*fk*band+CP[0]*ak*ab;g=C[1]*.2*fk*band+CP[1]*ak*ab;b=C[2]*.2*fk*band+CP[2]*ak*ab;
  er=fR*.92*band+(50*quill+60*mel+(hit?0:36))*ab+CP[0]*.07*ab;eg=fG*.92*band+(22*quill+22*mel+(hit?0:8))*ab+CP[1]*.07*ab;eb=fB*.92*band+CP[2]*.06*ab;
  const sk=sp*(band+ab*.4);er+=255*sk;eg+=(150+70*band)*sk;eb+=60*sk;
  if(o.edge>0){const e=o.edge*o.edge*.85;er+=o.hr*e;eg+=o.hg*e*.85;eb+=o.hb*e*.5}}
 o.r=r;o.g=g;o.b=b;o.er=er;o.eg=eg;o.eb=eb}
pzb3Reg({id:'phoenix',n:'Phoenix Plume',price:100000,tag:'Feathers of living fire, reborn every rack.',mat:pzblPhoenix,pal:{prep:()=>pzblStart(PZBL_PH),
 col:{1:[255,196,30],2:[44,128,255],3:[255,52,28],4:[178,72,255],5:[255,122,14],6:[36,214,96],7:[176,24,58],8:[14,9,9]},
 white:[248,242,232],cap:[244,234,220],disc:[255,244,222],num:[66,22,6],disc8:[255,240,214],num8:[30,12,6],ring8:[255,118,24],spec:1.05,win:.08,rim:.2}});

/* ---------------------------------------------------------------- Thunder Orb */
/* five bolts (jagged great circles that run over part of the ball) and three forks; normals in ball space */
const pzblBN=(()=>{const a=[[.62,.55,.56],[-.5,.7,-.51],[.2,-.6,.77],[.9,-.1,-.4],[-.35,-.8,-.45],[.85,-.2,-.48],[-.3,-.35,.88],[.4,.88,.25]];return Float32Array.from(a.flatMap(v=>{const m=Math.hypot(v[0],v[1],v[2]);return [v[0]/m,v[1]/m,v[2]/m]}))})();
let pzblCo=0,pzblHa=0;
/* one bolt: d the signed distance to its line, m > 0 where it runs (fades in), w the hot thread's half width; keeps the strongest */
function pzblBolt(d,m,w){if(m<=0||d>.17||d<-.17)return;const a=d<0?-d:d;if(a>.17)return;const mm=m>.25?1:m*4,c=1-a/w;if(c>0){const q=c*c*mm;if(q>pzblCo)pzblCo=q}const h=1-a/.17,q=h*h*mm;if(q>pzblHa)pzblHa=q}
/* the baked storm: per texel the hot thread, the halo and the two cloud stirs */
const PZBL_TH=pzblCube(128,(lx,ly,lz,A,o)=>{const N=pzblBN;
 /* jagged bolts: four shared zigzag fields push each great circle about */
 const J1=pzblT(lx*2.3+lz*1.7)*.07,J2=pzblT(ly*6.1-lz*5.3)*.028,J3=pzblT(lz*2.6+ly*1.5)*.07,J4=pzblT(lx*5.9-ly*6.3)*.028;
 const d1=N[0]*lx+N[1]*ly+N[2]*lz+J1+J2,d2=N[3]*lx+N[4]*ly+N[5]*lz+J3-J2,d3=N[6]*lx+N[7]*ly+N[8]*lz-J1+J4,d4=N[9]*lx+N[10]*ly+N[11]*lz+J3+J4,d5=N[12]*lx+N[13]*ly+N[14]*lz-J3-J2;
 const m1=lx*.7-lz*.7+.25,m2=ly*.6+lz*.8+.15,m3=lx*.8+ly*.6+.2,m4=lz*.8-ly*.6+.1,m5=-lx*.7+lz*.5+.05;
 pzblCo=0;pzblHa=0;pzblBolt(d1,m1,.03);pzblBolt(d2,m2,.03);pzblBolt(d3,m3,.03);pzblBolt(d4,m4,.026);pzblBolt(d5,m5,.026);
 /* forks: thinner bolts that only exist near their parent */
 const ad1=d1<0?-d1:d1,ad2=d2<0?-d2:d2,ad3=d3<0?-d3:d3;
 if(ad1<.45)pzblBolt(N[15]*lx+N[16]*ly+N[17]*lz+J3*.8-J4,(.45-ad1)*m1*2,.016);
 if(ad2<.45)pzblBolt(N[18]*lx+N[19]*ly+N[20]*lz-J1*.8+J4,(.45-ad2)*m2*2,.016);
 if(ad3<.45)pzblBolt(N[21]*lx+N[22]*ly+N[23]*lz+J1*.8+J2,(.45-ad3)*m3*2,.016);
 A[o]=pzblCo;A[o+1]=pzblHa;A[o+2]=pzb2Sin(ly*3.7+lz*2.1)*1.5;A[o+3]=.2*pzb2Sin(ly*8.3-lz*6.1+lx*4.4)+.08*pzb2Sin(lx*15.1+lz*13.3-ly*7.7)});
function pzblThunder(o){
 const lx=o.lx,ly=o.ly,lz=o.lz,wx=o.wx,wy=o.wy,wz=o.wz,C=o.C,CP=o.CP,band=o.band,ab=o.ab,k2=wz*wz,TC=pzblLook(PZBL_TH,lx,ly,lz),core=TC[0],halo=TC[1];
 /* storm cloud inside, sampled a little under the surface and stirred by the bolts' fields */
 const vx=PZBL.vx,vy=PZBL.vy,vz=PZBL.vz,cx=lx-vx*.35,cy=ly-vy*.35,cz=lz-vz*.35,
  c0=.5+.4*pzb2Sin(cx*3.1+cz*1.3+TC[2])+TC[3],cl=c0<0?0:c0>1?1:c0,cl2=cl*cl;
 /* the plasma core: in the middle of the ball as you look at it */
 const qd=wx*wx+wy*wy,pc0=1-qd*2.4,pc=pc0>0?pc0*pc0:0,dep=.3+.7*k2;
 let r,g,b,er=0,eg=0,eb=0;
 if(o.is8){const k=.6+.6*cl2;r=C[0]*k;g=C[1]*k;b=C[2]*k;
  er=(22*cl2+34*pc)*dep+150*halo*.6+225*core;eg=(10*cl2+10*pc)*dep+70*halo*.6+215*core;eb=(54*cl2+90*pc)*dep+255*halo*.6+255*core}
 else{
  /* storm glass in the ball colour: a dark body, light scattered through the cloud (deeper glass toward the rim), the core glowing */
  const gk=(.14+.66*cl2)*dep*band,ck=pc*.8*band;r=C[0]*.16*band;g=C[1]*.16*band;b=C[2]*.16*band;
  er=C[0]*gk+o.hr*ck;eg=C[1]*gk+o.hg*ck;eb=C[2]*gk+o.hb*ck+22*(1-cl2)*dep*band;
  /* the bolt: a coloured halo and a hot thread in the bolt's own tint */
  const hb=halo*band;er+=(o.hr*1.1-er)*hb;eg+=(o.hg*1.1-eg)*hb;eb+=(o.hb*1.1-eb)*hb;r*=1-hb;g*=1-hb;b*=1-hb;
  const cc=core*band;er+=(o.hr*.62+96-er)*cc;eg+=(o.hg*.62+96-eg)*cc;eb+=(o.hb*.62+110-eb)*cc;
  if(ab>0){/* frosted silver glass caps with pale lilac bolts */
   const fk=(.86+.14*cl)*ab;r+=CP[0]*fk;g+=CP[1]*fk;b+=CP[2]*fk;const pl=(halo*.3+core*.5)*ab;r-=70*pl;g-=60*pl;b-=10*pl;er+=40*core*ab;eg+=20*core*ab;eb+=80*core*ab}
  if(o.edge>0){const e=o.edge*o.edge*.8;er+=(o.hr*.5+110)*e;eg+=(o.hg*.5+110)*e;eb+=(o.hb*.5+140)*e}}
 /* a thin cool fresnel at the silhouette */
 const fz=o.RA*.35;er+=50*fz;eg+=60*fz;eb+=110*fz;
 o.r=r;o.g=g;o.b=b;o.er=er;o.eg=eg;o.eb=eb}
pzb3Reg({id:'thunder',n:'Thunder Orb',price:150000,tag:'A storm in a glass, and it is angry.',mat:pzblThunder,pal:{prep:()=>pzblStart(PZBL_TH),
 col:{1:[255,212,40],2:[40,120,255],3:[255,46,70],4:[176,80,255],5:[255,128,30],6:[30,220,150],7:[190,36,90],8:[10,8,20]},
 white:[244,246,255],cap:[226,230,248],disc:[244,246,255],num:[20,22,62],disc8:[246,244,255],num8:[16,10,36],ring8:[176,130,255],spec:1.0,win:.12,rim:.18}});

/* both bakes start shortly after load, a slice at a time, so they are ready long before anyone racks these balls */
setTimeout(()=>{pzblStart(PZBL_PH);pzblStart(PZBL_TH)},600);

/* ---------------------------------------------------------------- Gilded Hoard */
const pzblGS=4.6,pzblGC=1.5707963,pzblGI=4.6/Math.PI;
function pzblHoard(o){
 const lx=o.lx*pzblGS,ly=o.ly*pzblGS,lz=o.lz*pzblGS,wx=o.wx,wy=o.wy,wz=o.wz,C=o.C,CP=o.CP,band=o.band,ab=o.ab;
 /* a gyroid field: its zero line makes organic cells, its peaks sit at their hearts */
 const sx=pzb2Sin(lx),sy=pzb2Sin(ly),sz=pzb2Sin(lz),cx=pzb2Sin(lx+pzblGC),cy=pzb2Sin(ly+pzblGC),cz=pzb2Sin(lz+pzblGC),G=sx*cy+sy*cz+sz*cx,aG=G<0?-G:G;
 /* the gold: the cell wall (finer on the ivory caps), an inner filigree loop on the enamel, a bezel round each gem */
 const ww=.2-.115*ab,wa=1-aG/ww,wall=wa>0?wa:0;
 let loop=0;if(band>.5){const lp=aG-.9,la=1-(lp<0?-lp:lp)/.11;loop=la>0?la*.9:0}
 let gem=0,bez=0;if(aG>1.16){const h=pzb2Hash(Math.floor(o.lx*pzblGI*1.0+.5),Math.floor(o.ly*pzblGI+.5),Math.floor(o.lz*pzblGI+.5));if(h>.35){const gd=(aG-1.3)/.17;if(gd>0)gem=gd>1?1:gd;const bz=aG-1.25,ba=1-(bz<0?-bz:bz)/.06;bez=ba>0?ba:0}}
 const gold=wall>loop?(wall>bez?wall:bez):(loop>bez?loop:bez),gp=gold>.45?1:gold/.45;
 let r,g,b,er=0,eg=0,eb=0,lit=1;
 /* enamel: glossy colour, deeper near the wire where it pools, a little light through it */
 const pl=aG<.5?.7+.6*aG:1,sm=wa<0&&wa>-.7?(.7+wa)/.7:0,pool=pl*(1-sm*.3);
 if(o.is8){r=C[0]*pool+12;g=C[1]*pool+10;b=C[2]*pool+14}
 else{const ek=pool*band,ik=(.93+.07*pl)*(1-sm*.22)*ab;r=C[0]*ek+CP[0]*ik;g=C[1]*ek+CP[1]*ik;b=C[2]*ek+CP[2]*ik;const sc=(.1+.2*wz*wz)*band*pl;er=C[0]*sc;eg=C[1]*sc;eb=C[2]*sc}
 /* a cut gem: ruby, or sapphire, emerald on red enamel; brighter toward its crown, a white glint on the lit side */
 if(gem>0){const red=!o.is8&&C[0]>C[1]*2.2&&C[0]>C[2]*2.2,sap=G<0;let kr,kg,kb;if(red){kr=30;kg=210;kb=110}else if(sap&&!o.is8){kr=50;kg=110;kb=255}else{kr=255;kg=24;kb=60}
  const fc=.5+.5*pzb2Sin(lx*7+ly*5-lz*6),k=(.45+.5*gem)*(.8+.35*fc),gl0=gem*(1-((wx+.3)*(wx+.3)+(wy+.35)*(wy+.35))*1.4),gl=gl0>0?gl0*gl0:0;
  r=kr*.25;g=kg*.25;b=kb*.25;er=kr*k*.85+255*gl*.7;eg=kg*k*.85+255*gl*.7;eb=kb*k*.85+255*gl*.7}
 if(gp>0){/* polished gold: a studio reflection on a raised wire, the crown brightest */
  const rx=2*wz*wx,ry=2*wz*wy,hz=1-(ry+.25<0?-(ry+.25):ry+.25)*2.2,sky=ry<.35?(.35-ry)*.9:0,env=.38+(hz>0?hz*hz*.8:0)+sky+.25*(1-wz),cr=.62+.5*gold,e=env*cr;
  const Gr=255*e+30,Gg=188*e+18,Gb=64*e;r*=1-gp;g*=1-gp;b*=1-gp;er+=(Gr-er)*gp;eg+=(Gg-eg)*gp;eb+=(Gb-eb)*gp;lit=1-gp}
 /* the number discs keep the ordinary lighting (the painter lays them over this pixel) */
 if(lit<1){const az=o.lz<0?-o.lz:o.lz;if(az>.8){const q=4*(o.lx*o.lx+o.ly*o.ly);if(q<1.3){const dk=(1-q)/.1+.2,fd=(az-.8)/.03,t=(dk>1?1:dk<0?0:dk)*(fd>1?1:fd);lit+=(1-lit)*t}}}
 o.r=r;o.g=g;o.b=b;o.er=er;o.eg=eg;o.eb=eb;o.lit=lit}
pzb3Reg({id:'hoard',n:'Gilded Hoard',price:250000,tag:'Enamel, gold wire and gems: the dragon’s own set.',mat:pzblHoard,pal:{
 col:{1:[250,196,24],2:[22,84,214],3:[214,28,40],4:[112,40,184],5:[240,106,16],6:[16,150,84],7:[128,20,36],8:[12,10,14]},
 white:[250,246,236],cap:[250,244,226],disc:[255,248,230],num:[24,22,64],disc8:[255,244,214],num8:[26,16,6],ring8:[255,200,80],spec:1.25,win:.14,rim:.24}});

/* the strip stays sorted by price, legendary sets last */
{const pr=PZ_BALLS.filter(b=>b.prem).sort((a,b)=>a.price-b.price);for(const b of pr)PZ_BALLS.splice(PZ_BALLS.indexOf(b),1);PZ_BALLS.push(...pr);for(const b of PZ_BALLS)if(b.prem&&b.price>=PZBL.LEG)b.leg=1}

/* ---------------------------------------------------------------- the LEGENDARY marks in the Cue Rack */
{const st=document.createElement('style');st.textContent=`
.pzkbc.prem.leg{border-color:#b8322a;background:linear-gradient(180deg,#3a0f1c 0%,#1c0a2a 62%,#140c36 100%)}
.pzkbc.prem.leg.sel{border-color:#ffd45a}
.pzkbc.prem.leg::before{content:'LEGENDARY';padding:2px 10px 2px 10px;background:linear-gradient(180deg,#fff0a0 0%,#ffc23a 38%,#e0482a 62%,#a01a22 100%);color:#fff8e0;font:800 10px/1.3 Poppins,sans-serif;letter-spacing:.11em;text-shadow:0 1px 0 #4a0808,0 -1px 0 #4a0808,1px 0 0 #4a0808,-1px 0 0 #4a0808}
.pzkbc.prem.leg::after{content:'';position:absolute;left:8px;right:8px;top:4px;height:3px;border-radius:2px;background:linear-gradient(90deg,#a01a22,#ffd45a,#a01a22);opacity:.9;pointer-events:none}
.pzkbc.prem.leg b{color:#ffe08a}
.pzrk97 .pzkbc.prem.sel::before{top:-5px}
.pzblleg{display:flex;width:max-content;align-items:center;gap:6px;margin:0 0 6px auto;height:28px;box-sizing:border-box;padding:0 12px 0 10px;border-radius:14px;border:3px solid #12081f;background:linear-gradient(180deg,#fff0a0 0%,#ffc23a 38%,#e0482a 62%,#a01a22 100%);color:#fff8e0;font:800 12px/1 Poppins,sans-serif;letter-spacing:.12em;vertical-align:middle;text-shadow:0 1px 0 #4a0808,0 -1px 0 #4a0808,1px 0 0 #4a0808,-1px 0 0 #4a0808;white-space:nowrap}
.pzblleg i{width:12px;height:12px;background:#fff6c8;clip-path:polygon(50% 0,62% 38%,100% 50%,62% 62%,50% 100%,38% 62%,0 50%,38% 38%);box-shadow:none}
`;document.head.appendChild(st)}
{const f0=pzRk97Wall;pzRk97Wall=function(){const r=f0.apply(this,arguments);try{if(PZ.rackTab==='balls'){const s=document.querySelector('#pzkwall .pzkbstrip');
  if(s)s.querySelectorAll('.pzkbc').forEach(b=>{const it=PZ_BALLS.find(x=>x.id===b.dataset.i);if(it&&it.leg)b.classList.add('prem','leg')})}}catch(e){console.error(e)}return r}}
{const f0=pzRk97Detail;pzRk97Detail=function(){const r=f0.apply(this,arguments);try{if(PZ.rackTab==='balls'){const items=pzRkList('balls'),it=items.find(x=>x.id===PZ.rackSel)||items[0],t=document.querySelector('#pzkdet .pzkbt');
  /* on its own line above the title, so a long name and the EQUIPPED chip still fit on one line */
  if(it&&it.leg&&t&&!document.querySelector('#pzkdet .pzblleg')){const sp=document.createElement('span');sp.className='pzblleg';sp.innerHTML='<i></i>LEGENDARY';t.before(sp)}}}catch(e){console.error(e)}return r}}
