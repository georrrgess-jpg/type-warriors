# python3 t_gtt105.py [game.html] : 10.5 The Great Turkey Trot, the game (99u4 game, 99u5 sound, 99u6 style; prefix gttu): registration and the tile (first in the
# casino, NEW badge), the paddock (six rows with portrait, cloth, name, style, form, tip, odds), bet types and the exact 1st/2nd flow, the slip and every
# limit (bet over 5,000, slip over 5,000, a fourth bet, the same turkey twice in an Exact), the money (Start takes the stakes once together with the
# pending record, a win pays once, a loss nothing, three bets settle independently, a cash out pays once and the rest settles without it, the totals
# match the gold ledger, the 20,000 cap, the 98t / 98v guard enforced with window.TW_AC_TEST), a reload in the middle of a race (same result, paid once,
# a second reload pays nothing), leaving with a race running (CAS.flush), the keyboard, Esc / Back and the Lobby lock, the first-visit tutorial (once),
# photo finish, results and Race again, trophies, festival acorns (only while on, at most 10 races a day), reduced motion, sound off when muted,
# frame cost of the race screen, UI fit at 1600x900 / 1280x720 / 1024x640 (tools/td/rpu_ovl.js), no shadowBlur / ctx.filter / backdrop-filter, no page errors.
# The sim, odds and art may be the real modules or the throwaway stubs in tools/gtt (injected only when a real module is missing). Screenshots in shots/w105_gtt/.
import asyncio,os,re,sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 and not sys.argv[1].startswith('-') else os.path.join(HERE,'out.html'))
OVL=open(os.path.join(HERE,'..','tools','td','rpu_ovl.js')).read()
STUBS=''.join(open(os.path.join(HERE,'..','tools','gtt',f)).read() for f in ('stub_sim.js','stub_art.js') if os.path.exists(os.path.join(HERE,'..','tools','gtt',f)))
SHOTS=os.path.join(HERE,'shots','w105_gtt');os.makedirs(SHOTS,exist_ok=True)
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:900]),flush=True)
    if not ok:FAIL.append(name)
SETUP="()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}try{window.TWA_RELAYS=[]}catch(e){}window.FL_FORCE=window.FL_FORCE||1;return 1}"
HELP=r"""()=>{window.__g={
 sleep(ms){return new Promise(r=>setTimeout(r,ms))},
 async open(){lobby();await __g.sleep(300);gameOpen('gtt');await __g.sleep(300);for(let i=0;i<300&&!GTTU.cur.px();i++)await __g.sleep(100);return !!GTTU.cur.px()},
 async card(cs){GTTU.cur.newCard(cs);for(let i=0;i<300&&!GTTU.cur.px();i++)await __g.sleep(100);return !!GTTU.cur.px()},
 key(k){window.dispatchEvent(new KeyboardEvent('keydown',{key:k,bubbles:true}))},
 /* add a bet through the UI paths: kind, lane(s), stake */
 bet(k,a,b,stake){const c=GTTU.cur;CAS.bet=stake;betRefresh();c.setKind(k);if(k==='exact'){c.pick(a);c.pick(b)}else c.pick(a);return c.add()},
 fin(cs,rs){return gttRun(gttCard(cs),rs)},
 /* a finished race screen: skip to the end */
 async finish(){GTTU.cur.skip();await __g.sleep(150);return GTTU.cur.R()},
 async runTo(t){const c=GTTU.cur;GTTDBG.hold(true);for(let i=0;i<600&&c.ph()!=='race';i++)c.frame(1,1/60);for(let i=0;i<4000&&c.st()&&c.st().t<t&&c.ph()==='race';i++)c.frame(1,1/60);return c.st().t},
 gold(){return P.gold}};return 1}"""
async def page(b,vw=1600,vh=900,rm=False,init=None,stubs=True,ach=True,guard=False):
    ctx=await b.new_context(viewport={'width':vw,'height':vh},reduced_motion='reduce' if rm else 'no-preference')
    await ctx.add_init_script("window.TWA_RELAYS=[];")
    if init:await ctx.add_init_script(init)
    pg=await ctx.new_page();er=[];pg.on('pageerror',lambda e:er.append(str(e)[:300]))
    await pg.goto(H);await pg.wait_for_timeout(1400);E=pg.evaluate
    await E(SETUP);await E(OVL);await E(HELP)
    if stubs and STUBS:await E("()=>{"+STUBS+"}")
    if guard:await E("()=>{setTimeout(cPay,0,0,20000)}");await pg.wait_for_timeout(300)
    await E("()=>{if(!GUARD)P.gold=200000;P.gtt=null;try{gttNorm()}catch(e){};P.gtt.seen=1;for(const a of ACH){if(/^gtt/.test(a.id)&&CLR)delete P.ach[a.id];else P.ach[a.id]=1}save()}".replace('GUARD','true' if guard else 'false').replace('CLR','false' if ach else 'true'))
    return ctx,pg,E,er
def stk(t):return os.path.join(SHOTS,t)
CS,RS=4242,777
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch()
        # ============ static: build lists, forbidden calls ============
        bl=[open(os.path.join(HERE,f)).read() for f in ('build.sh','build_ast3.sh')]
        def order(x):
            L=x.split();ix=[L.index(m) for m in ('99t_update89.js','99u_gtt_data.js','99u2_gtt_sim.js','99u3_gtt_art.js','99u5_gtt_audio.js','99u4_gtt_game.js','99u6_gtt_style.js') if m in L]
            return ix==sorted(ix) and len(ix)>=4
        have=lambda x,m:(' '+m+' ') in x
        chk('the Turkey Trot modules are registered in both build lists in the contract order, after 99t_update89.js',all(order(x) and have(x,'99u4_gtt_game.js') and have(x,'99u5_gtt_audio.js') and have(x,'99u6_gtt_style.js') for x in bl))
        bad=[]
        for f in ('99u4_gtt_game.js','99u5_gtt_audio.js','99u6_gtt_style.js'):
            t=open(os.path.join(HERE,f)).read()
            for pat in ('shadowBlur','ctx.filter','.filter=','backdrop-filter','soft-light','mix-blend-mode'):
                if pat in t:bad.append((f,pat))
        chk('no shadowBlur, ctx.filter, backdrop-filter or blend modes in the game, sound or style modules',not bad,bad)
        mods=[open(os.path.join(HERE,f)).read() for f in ('99u4_gtt_game.js','99u5_gtt_audio.js','99u6_gtt_style.js')]
        names=set();dup=[]
        for t in mods:
            for m in re.finditer(r'^(?:const|let|function|class)\s+([A-Za-z_$][\w$]*)',t,re.M):names.add(m.group(1))
        allsrc=[f for f in os.listdir(HERE) if f.endswith('.js') and re.match(r'^\d',f) and f not in ('99u4_gtt_game.js','99u5_gtt_audio.js','99u6_gtt_style.js')]
        mine=names
        for f in allsrc:
            t=open(os.path.join(HERE,f)).read()
            for m in re.finditer(r'^(?:const|let|function|class)\s+([A-Za-z_$][\w$]*)',t,re.M):
                if m.group(1) in mine:dup.append((f,m.group(1)))
        chk('no top-level name of the game, sound or style modules is declared in another module (the data, sim and art modules included)',not dup,dup[:5])

        # ============ registration, the tile, the paddock ============
        ctx,pg,E,er=await page(b)
        r=await E("async()=>{casinoOpen();await __g.sleep(500);const t=document.querySelector('.gdt');return [GAMES[0].id,!!TA.gtt,!!ICON.gtt,GAMES.filter(g=>g.id==='gtt').length,t&&t.dataset.g,getComputedStyle(document.querySelector('.gdt[data-g=gtt]'),'::after').content,CAS_FULL.has('gtt'),casCap('gtt')]}")
        chk('the Turkey Trot is first in the casino with its tile, icon and a NEW badge; it is not in CAS_FULL and bets up to 5,000',r[:5]==['gtt',True,True,1,'gtt'] and 'NEW' in r[5] and r[6]==False and r[7]==5000,r)
        await pg.screenshot(path=stk('lobby_tile_1600.png'))
        await pg.click('.gdt[data-g=gtt]');await pg.wait_for_timeout(800)
        r=await E("()=>[!!document.querySelector('#gttcard'),CAS.cap,document.querySelectorAll('input[type=text],textarea').length,document.querySelectorAll('.gttrow').length]")
        chk('clicking the tile opens the paddock: six runners, no text input (no typing), bets up to 5,000',r==[True,5000,0,6],r)
        for _ in range(60):
            if await E("()=>!!GTTU.cur.px()"):break
            await pg.wait_for_timeout(100)
        r=await E("""()=>{const c=GTTU.cur.card();return [...document.querySelectorAll('.gttrow')].map((row,l)=>({cl:!!row.querySelector('.gttcl b'),cv:!!row.querySelector('canvas'),nm:row.querySelector('.gttnm b').textContent===GTT_RUN.find(x=>x.id===c.field[l]).n,
          st:!!row.querySelector('.gttnm em').textContent,tip:row.querySelector('.gttnm small').textContent.length>3,form:row.querySelectorAll('.gttform i').length,od:row.querySelector('.gttodds').textContent}))}""")
        chk('every row has the cloth number, portrait canvas, name, style chip, tip, five form medals and a multiplier button once the odds are set',all(x['cl'] and x['cv'] and x['nm'] and x['st'] and x['tip'] and x['form']==5 and re.match(r'^(×\d|—)',x['od']) for x in r),r)
        r=await E("()=>[document.querySelector('#gttno').textContent,document.querySelector('#gttgo').textContent.trim(),document.querySelector('#gttwx').textContent.trim(),!!document.querySelector('#gtthelp'),document.querySelector('#gttpricing').hidden]")
        chk('the header shows the race number, the going and the weather; "Setting the odds..." is gone once priced',re.match(r'Race \d+',r[0]) and 'going' in r[1] and r[2] and r[3] and r[4],r)
        await pg.screenshot(path=stk('paddock_1600.png'))
        r=await E("""()=>{const out={};for(const k of ['win','top2','top3','exact']){GTTU.cur.setKind(k);out[k]=[...document.querySelectorAll('.gttodds')].map(x=>x.textContent)}const w=GTTU.cur.px().mult;return [out,w.win.slice(0,3),w.top3.slice(0,3)]}""")
        chk('the odds buttons follow the bet type (Win pays more than Top 3 for the same turkey; Exact asks for the 1st first)',r[0]['exact'][0]=='1st?' and r[0]['win']!=r[0]['top3'] and r[0]['win'][0]==('×'+str(r[1][0]).rstrip('0').rstrip('.') if r[1][0] else '—'),r)
        r=await E("""async()=>{const c=GTTU.cur;c.setKind('exact');c.pick(1);const a=document.querySelector('#gttpick').textContent;const o1=document.querySelectorAll('.gttodds')[1].textContent;c.pick(1);const same=[c.sel(),c.ex1()];c.pick(1);c.pick(3);const b=document.querySelector('#gttpick').textContent;const o3=document.querySelectorAll('.gttodds')[3].textContent;
          CAS.bet=100;betRefresh();c.setKind('exact');c.pick(2);c.pick(2);const e=document.getElementById('cm').textContent;c.setKind('win');return [a,o1,same,b,o3,e,c.slip().length]}""")
        chk('Exact 1-2 asks "1st?" then "2nd?", shows the exact multiplier on the runner-up, and the same turkey twice is refused',r[0].startswith('2nd?') and r[1]=='1st' and r[2]==[None,None] and '#2' in r[3] and '×' in r[4] and r[6]==0,r)
        await E("()=>{GTTU.cur.help()}");await pg.wait_for_timeout(500)
        r=await E("()=>[document.querySelectorAll('.gtthg>div').length,document.querySelector('.gtthow h3').textContent,GTTU.cur.overlay()]")
        chk('the Help (?) button opens the three-card How to Play',r[0]==3 and 'How to play' in r[1] and r[2],r)
        await pg.screenshot(path=stk('howto_1600.png'))
        await E("()=>GTTU.cur.close()")
        await E("()=>{GTTU.cur.stats()}");await pg.wait_for_timeout(500)
        r=await E("()=>[document.querySelectorAll('.gttstg>div').length,document.querySelectorAll('.gttstt tbody tr').length,GTTU.cur.overlay()]")
        chk('My stats lists races, wins, best payout, longshot, favourite and every turkey',r[0]==6 and r[1]==12 and r[2],r)
        await pg.screenshot(path=stk('stats_1600.png'));await E("()=>GTTU.cur.close()")

        # ============ limits ============
        r=await E("""async()=>{await __g.card(%d);const c=GTTU.cur,out={};c.setKind('win');c.pick(0);
          CAS.bet=6000;let ok=c.add();out.over=[ok,c.slip().length,document.getElementById('cm').textContent];
          CAS.bet=5;ok=c.add();out.low=[ok,document.getElementById('cm').textContent];
          CAS.bet=3000;ok=c.add();c.pick(1);CAS.bet=2500;ok=c.add();out.tot=[ok,c.slip().length,document.getElementById('cm').textContent];
          CAS.bet=2000;c.pick(2);ok=c.add();out.ok2=[ok,c.slip().length];
          c.rm(0);c.rm(0);CAS.bet=100;c.setKind('win');for(let i=0;i<3;i++){c.pick(i);c.add()}c.pick(4);ok=c.add();out.four=[ok,c.slip().length,document.getElementById('cm').textContent];return out}"""%CS)
        chk('a bet over 5,000, a stake under 10 and a slip over 5,000 in total are refused (the slip keeps 5,000 at most)',r['over'][0]==False and r['over'][1]==0 and r['low'][0]==False and r['tot'][0]==False and r['ok2'][0]==True and 'limit' in r['tot'][2].lower(),r)
        chk('a fourth bet is refused ("Three bets per race")',r['four'][0]==False and r['four'][1]==3 and 'Three' in r['four'][2],r)
        r=await E("""async()=>{const c=GTTU.cur;const n=c.slip().length;const t=document.querySelectorAll('.gttsl').length;c.rm(0);c.rm(0);c.rm(0);return [n,t,c.slip().length,document.querySelector('.gttempty')!=null]}""")
        chk('each slip line can be removed',r==[3,3,0,True],r)
        # ============ money: win / loss / three independent bets, ledger ============
        r=await E("""async(a)=>{await __g.card(a[0]);const fin=__g.fin(a[0],a[1]),W=fin.order[0],S=fin.order[1],Lz=fin.order[5],c=GTTU.cur;GTTDBG.setRace(a[1]);
          const L0=Date.now();const g0=P.gold;
          __g.bet('win',W,0,100);__g.bet('win',Lz,0,200);__g.bet('top2',S,0,300);const px=c.px().mult;const slip=c.slip().map(b=>({...b}));const tot=slip.reduce((x,b)=>x+b.stake,0);
          const exp=Math.floor(100*px.win[W])+Math.floor(300*px.top2[S]);
          c.start();await __g.sleep(100);const g1=P.gold,pend=GTTDBG.pend(),ph=c.ph(),lock=[CAS.lock,document.getElementById('cb').disabled];
          const R=await __g.finish();const g2=P.gold;
          const led=ledgerRecent(30).filter(e=>e.t>=L0).reduce((x,e)=>x+e.d,0);
          return {tot,taken:g0-g1,pend:!!pend&&pend.bets.length,ph,lock,exp,paid:R.paid,delta:g2-g0,won:R.lines.map(l=>l.won),pay:R.lines.map(l=>l.pay),after:GTTDBG.pend(),led,ph2:c.ph(),lock2:CAS.lock}}"""%() if False else """async(a)=>{await __g.card(a[0]);const fin=__g.fin(a[0],a[1]),W=fin.order[0],S=fin.order[1],Lz=fin.order[5],c=GTTU.cur;GTTDBG.setRace(a[1]);
          const L0=Date.now();const g0=P.gold;
          __g.bet('win',W,0,100);__g.bet('win',Lz,0,200);__g.bet('top2',S,0,300);const px=c.px().mult;const tot=c.slip().reduce((x,b)=>x+b.stake,0);
          const exp=Math.floor(100*px.win[W])+Math.floor(300*px.top2[S]);
          c.start();await __g.sleep(100);const g1=P.gold,pend=GTTDBG.pend(),ph=c.ph(),lock=[CAS.lock,document.getElementById('cb').disabled];
          const R=await __g.finish();const g2=P.gold;
          const led=ledgerRecent(30).filter(e=>e.t>=L0).reduce((x,e)=>x+e.d,0);
          return {tot,taken:g0-g1,pend:!!pend&&pend.bets.length,ph,lock,exp,paid:R.paid,delta:g2-g0,won:R.lines.map(l=>l.won),pay:R.lines.map(l=>l.pay),after:GTTDBG.pend(),led,ph2:c.ph(),lock2:CAS.lock}}""",[CS,RS])
        chk('Start takes the three stakes once (600) and saves the pending race in the same step; the Lobby locks during the race',r['taken']==r['tot']==600 and r['pend']==3 and r['ph'] in('gate','race') and r['lock']==[True,True],r)
        chk('three bets settle independently: the winner and the Top 2 pay, the loser pays nothing; paid once, the pending record is gone, the Lobby unlocks',r['won']==[True,False,True] and r['pay'][1]==0 and r['paid']==r['exp'] and r['delta']==r['exp']-600 and r['after'] is None and r['ph2']=='over' and r['lock2']==False,r)
        chk('the gold ledger shows exactly the stakes taken and the payout received',r['led']==r['delta'],r)
        await pg.screenshot(path=stk('results_1600.png'))
        r=await E("""()=>[[...document.querySelectorAll('.gttrl')].map(x=>x.className),document.querySelectorAll('.gttor').length,!!document.querySelector('#gttpc'),!!document.querySelector('#gttagain'),!!document.querySelector('#gttnew2'),!!document.querySelector('#gttback'),[...document.querySelectorAll('.gttrt b')].map(x=>x.textContent)]""")
        chk('results: podium canvas, six finishers, each bet ticked or crossed, totals, Race again / New card / Back',r[0]==['gttrl won','gttrl lost','gttrl won'] and r[1]==6 and r[2] and r[3] and r[4] and r[5] and len(r[6])==3,r)
        r=await E("""()=>{const s=P.gtt;return [s.races,s.bets,s.wins,s.best>0,Object.values(s.rec).filter(q=>q.s>0).length,Object.values(s.rec).filter(q=>q.s>0).every(q=>q.last.length>=1)&&Object.values(s.rec).reduce((a,q)=>a+q.s,0),Object.values(s.fav).filter(v=>v>0).length]}""")
        chk('the stats are updated once per race (races, bets, winning bets, best payout, per-turkey starts and form, favourites)',r[0]==1 and r[1]==3 and r[2]==2 and r[3] and r[4]==6 and r[5]==6 and r[6]>=1,r)
        # Race again
        r=await E("""async()=>{const c=GTTU.cur,g=P.gold;c.again();await __g.sleep(200);const n0=c.slip().length;const msg=document.getElementById('cm').textContent;for(let i=0;i<300&&!c.px();i++)await __g.sleep(100);return [c.ph(),n0,c.slip().length,c.slip().map(b=>b.stake),c.slip().every(b=>b.mult>0),P.gold===g]}""")
        chk('Race again: a new card with the same bets and stakes where affordable (odds refreshed, no gold taken until Start)',r[0]=='paddock' and r[1]==3 and r[2]==3 and r[3]==[100,200,300] and r[4] and r[5],r)
        await E("()=>GTTU.cur.newCard()");
        # cash out
        r=await E("""async(a)=>{await __g.card(a[0]);const c=GTTU.cur;const fin=__g.fin(a[0],a[1]),W=fin.order[0],Lz=fin.order[5];GTTDBG.setRace(a[1]);
          __g.bet('win',W,0,100);__g.bet('top3',W,0,400);__g.bet('win',Lz,0,50);const g0=P.gold;c.start();await __g.sleep(50);const taken=g0-P.gold;
          const t=await __g.runTo(5);const gA=P.gold;c.cash(1);const gB=P.gold;const pay=gB-gA;const cash1=c.rec().cash.slice();
          c.cash(1);const gC=P.gold;
          const done=document.querySelector('.gttb[data-i="1"] .gttdone')&&document.querySelector('.gttb[data-i="1"] .gttdone').textContent;
          const R=await __g.finish();return {taken,t,pay,cash1,again:gC-gB,paid:R.paid,delta:P.gold-g0,fp:R.lines.map(l=>[l.cashed,l.won,l.pay]),pend:GTTDBG.pend(),done,expWin:Math.floor(100*c.rec().bets[0].mult)}}""",[CS,RS])
        chk('cash out settles that bet once through cPay (a second press pays nothing), shows "Cashed out", and the rest settles without it',r['pay']>=1 and r['pay']==r['cash1'][0]['pay'] and r['again']==0 and r['done'] and 'Cashed' in r['done'] and r['fp'][1][0]==True and r['fp'][0][2]==r['expWin'] and r['fp'][2][2]==0 and r['pend'] is None,r)
        chk('the final totals match: stakes out, the cash out and the settlement in (paid once in total)',r['delta']==r['paid']-550 and r['paid']==r['expWin']+r['pay'],r)
        # the cap
        r=await E("""()=>{const fin=__g.fin(%d,%d),W=fin.order[0],rec={cardSeed:%d,raceSeed:%d,bets:[{k:'exact',a:W,b:fin.order[1],stake:5000,mult:150}],cash:[],t0:0};const R=gttuLines(rec,fin);
          const rec2={cardSeed:%d,raceSeed:%d,bets:[{k:'win',a:W,stake:5000,mult:40},{k:'win',a:W,stake:100,mult:2}],cash:[{i:1,pay:19000}],t0:0};const R2=gttuLines(rec2,fin);return [R.paid,R.capped,R2.paid,R2.cashPaid]}"""%(CS,RS,CS,RS,CS,RS))
        chk('a race never pays more than 20,000 (a 5,000 Exact at x150 is capped; a cash out counts toward the cap)',r[0]==20000 and r[1] and r[2]<=20000 and r[3]==19000,r)
        chk('no page errors (paddock, bets, money)',not er,er);await ctx.close()

        # ============ reload mid-race, pays once; flush ============
        ctx,pg,E,er=await page(b)
        r=await E("""async(a)=>{await __g.open();await __g.card(a[0]);const fin=__g.fin(a[0],a[1]);GTTDBG.setRace(a[1]);__g.bet('win',fin.order[0],0,500);__g.bet('top3',fin.order[5],0,200);const exp=Math.floor(500*GTTU.cur.slip()[0].mult);
          window.__g0=P.gold;const c=GTTU.cur;c.start();await __g.runTo(3);return {exp,g:P.gold,g0:window.__g0,ph:c.ph(),pend:!!GTTDBG.pend()}}""",[CS,RS])
        chk('a race in progress: stakes are out (700), the pending record is saved',r['g0']-r['g']==700 and r['pend'] and r['ph']=='race',r)
        await pg.reload();await pg.wait_for_timeout(1500);await E(SETUP);await E(HELP)
        if STUBS:await E("()=>{"+STUBS+"}")
        r=await E("""async()=>{const g0=P.gold,pend=!!(P.gtt&&P.gtt.pend);lobby();await __g.sleep(300);gameOpen('gtt');await __g.sleep(600);const c=GTTU.cur;return {g0,pend,ph:c.ph(),g1:P.gold,after:GTTDBG.pend(),note:!!document.querySelector('.gttnote'),lines:document.querySelectorAll('.gttrl').length,races:P.gtt.races}}""")
        chk('after a reload in the middle of the race the pending race is finished from the save: the result screen shows, paid once (700 staked, winnings in)',r['pend'] and r['ph']=='over' and r['g1']-r['g0']==1*(r['g1']-r['g0']) and r['note'] and r['lines']==2 and r['after'] is None and r['races']==1,r)
        exp=await E("()=>{const R=GTTU.cur.R();return [R.paid,R.staked]}")
        await pg.wait_for_timeout(300)
        r=await E("()=>({g:P.gold})");g1=r['g']
        chk('the reload paid exactly the settled amount (gold = before the race - stakes + winnings)',g1==200000-700+exp[0],[g1,exp])
        await pg.reload();await pg.wait_for_timeout(1500);await E(SETUP);await E(HELP)
        if STUBS:await E("()=>{"+STUBS+"}")
        r=await E("""async()=>{const g0=P.gold;lobby();await __g.sleep(300);gameOpen('gtt');await __g.sleep(500);return [g0,P.gold,GTTU.cur.ph(),P.gtt.races]}""")
        chk('a second reload pays nothing more and opens the paddock',r[0]==g1 and r[1]==g1 and r[2]=='paddock' and r[3]==1,r)
        # leaving with a race running (the safety net)
        r=await E("""async(a)=>{await __g.card(a[0]);const fin=__g.fin(a[0],a[1]+1);GTTDBG.setRace(a[1]+1);__g.bet('win',fin.order[0],0,300);const g0=P.gold;GTTU.cur.start();await __g.runTo(2);const mid=P.gold;
          cFlush();const g1=P.gold,exp=Math.floor(300*GTTU.cur.rec().bets[0].mult);return [g0-mid,g1-g0,exp-300,GTTDBG.pend()]}""",[CS,RS])
        chk('CAS.flush (leaving) finishes the race and pays once: the same win as watching it',r[0]==300 and r[1]==r[2] and r[3] is None,r)
        chk('no page errors (reload and flush)',not er,er);await ctx.close()

        # ============ keyboard, Esc, Lobby lock, tutorial once ============
        ctx,pg,E,er=await page(b,init="window.GTT_NEWS=1;")
        await E("()=>{P.gtt.seen=0;save()}")
        r=await E("""async()=>{lobby();await __g.sleep(300);gameOpen('gtt');await __g.sleep(900);const a=GTTU.cur.overlay();const n=document.querySelectorAll('.gtthg>div').length;__g.key('Escape');await __g.sleep(100);const still=GTTDBG.ph();const gone=!GTTU.cur.overlay();return [a,n,gone,still,P.gtt.seen]}""")
        chk('first visit: the three-card How to Play shows once (Esc closes it without leaving the game)',r==[True,3,True,'paddock',1],r)
        r=await E("""async()=>{lobby();await __g.sleep(300);gameOpen('gtt');await __g.sleep(900);return [GTTU.cur.overlay(),!!document.querySelector('#gttcard')]}""")
        chk('the tutorial does not show again on the second visit',r==[False,True],r)
        r=await E("""async()=>{await __g.card(%d);const c=GTTU.cur,o=[];__g.key('3');o.push(c.sel());__g.key('1');o.push(c.sel());__g.key('t');o.push(c.kind());__g.key('p');o.push(c.kind());__g.key('e');o.push(c.kind());__g.key('w');o.push(c.kind());
          const b0=CAS.bet;__g.key('+');o.push(CAS.bet>b0);__g.key('-');o.push(CAS.bet===b0);__g.key('2');__g.key('Enter');o.push(c.slip().length);__g.key('e');__g.key('1');__g.key('4');__g.key('Enter');o.push(c.slip().length);o.push(c.slip()[1]&&c.slip()[1].k);
          __g.key('n');await __g.sleep(100);o.push(c.slip().length);return o}"""%CS)
        chk('keyboard: 1-6 pick a turkey, W / T / P / E bet types, + / - stake, Enter adds a bet (Exact takes two picks), N draws a new card and clears the slip',r==[2,0,'top2','top3','exact','win',True,True,1,2,'exact',0],r)
        r=await E("""async()=>{await __g.card(%d);const g0=P.gold;__g.key('2');__g.key(' ');await __g.sleep(150);const o=[GTTDBG.ph(),g0-P.gold>0,CAS.lock];GTTDBG.hold(true);GTTU.cur.frame(80,1/60);__g.key('Escape');await __g.sleep(100);o.push(GTTDBG.ph());o.push(!!document.querySelector('#gttrc'));
          const b=document.getElementById('cb');o.push(b.disabled);const bef=S.mode;GTTU.cur.skip();await __g.sleep(200);o.push(GTTDBG.ph(),CAS.lock,b.disabled);return o}"""%CS)
        chk('Space with an empty slip starts the race on the picked turkey; Esc and the Lobby button are locked while it runs and free again after',r[0] in('gate','race') and r[1] and r[2] and r[3] in('gate','race') and r[4] and r[5] and r[6]=='over' and r[7]==False and r[8]==False,r)
        r=await E("""async()=>{GTTDBG.hold(false);const c=GTTU.cur;__g.key('Escape');await __g.sleep(500);return [!!document.querySelector('.gd'),!!document.querySelector('#gttcard'),CAS.on]}""")
        chk('Esc on the results leaves for the casino lobby (Back)',r==[True,False,True],r)
        r=await E("""async()=>{gameOpen('gtt');await __g.sleep(500);const b=document.querySelector('#gttnew');b.click();await __g.sleep(100);document.querySelector('#cb').click();await __g.sleep(500);return [!!document.querySelector('.gd')]}""")
        chk('the Lobby button leaves the paddock',r==[True],r)
        chk('no page errors (keyboard)',not er,er);await ctx.close()

        # ============ photo finish, the race screen, sound, reduced motion ============
        ctx,pg,E,er=await page(b)
        ph=await E("""()=>{for(let r=1;r<600;r++){const f=gttRun(gttCard(%d),r);if(f.photo)return [r,f.order[0],f.order[1],!!f.photo.a||f.photo.a===0]}return null}"""%CS)
        chk('a photo-finish race exists on a fixed card (found by searching race seeds)',ph is not None,ph)
        if ph:
            r=await E("""async(a)=>{await __g.open();await __g.card(%d);GTTDBG.setRace(a[0]);__g.bet('win',a[1],0,200);const c=GTTU.cur;const g0=P.gold;c.start();GTTDBG.hold(true);
              for(let i=0;i<900&&c.ph()!=='photo'&&c.ph()!=='over';i++)c.frame(1,1/30);const ph=c.ph();const cls=document.querySelector('#cg').classList.contains('gttph');await __g.sleep(30);const pho=c.ph()==='photo';
              c.frame(40,1/30);const mid=c.ph();c.frame(80,1/30);const end=c.ph();return [ph,cls,mid,end,c.R()&&!!c.R().photo,P.gold-g0,Math.floor(200*c.slip()[0]?.mult||0)]}"""%CS,[ph[0],ph[1]])
            chk('photo finish: the screen freezes into the photo (HUD hidden), develops for about 2.5 s, then the result appears with the Photo finish tag',r[0]=='photo' and r[1] and r[2]=='photo' and r[3]=='over' and r[4],r)
            await E("()=>{GTTDBG.hold(false)}")
            r=await E("""async(a)=>{GTTU.cur.again();await __g.sleep(200);for(let i=0;i<300&&!GTTU.cur.px();i++)await __g.sleep(100);return 1}""",[1])
            # screenshot of the photo screen
            await E("""async(a)=>{await __g.card(%d);GTTDBG.setRace(a[0]);__g.bet('win',a[1],0,100);const c=GTTU.cur;c.start();GTTDBG.hold(true);for(let i=0;i<900&&c.ph()!=='photo';i++)c.frame(1,1/30);c.frame(60,1/30);return c.ph()}"""%CS,[ph[0],ph[1]])
            await pg.wait_for_timeout(100);await pg.screenshot(path=stk('photo_1600.png'))
            await E("()=>{GTTDBG.hold(false);GTTU.cur.skip()}");await pg.wait_for_timeout(300)
            r=await E("()=>GTTU.cur.R().photo")
            await pg.screenshot(path=stk('results_photo_1600.png'))
        # a normal race: gate, race, HUD, ticker
        r=await E("""async()=>{await __g.card(%d);GTTDBG.setRace(%d);__g.bet('win',1,0,100);const c=GTTU.cur;c.start();GTTDBG.hold(true);c.frame(40,1/60);const a=[c.ph(),document.querySelector('#gttban').textContent];c.frame(140,1/60);a.push(c.ph());return a}"""%(CS,RS))
        await pg.screenshot(path=stk('gate_1600.png'))
        chk('the race begins with the call to the post, then the gate opens and the race runs',r[0]=='gate' and 'Call' in r[1] and r[2]=='race',r)
        await E("""async()=>{const t=await __g.runTo(7);return t}""");await E("()=>{GTTU.cur.frame(30,1/60)}")
        await pg.screenshot(path=stk('race_mid_1600.png'))
        r=await E("""()=>{const c=GTTU.cur,st=c.st();return {t:+st.t.toFixed(2),dots:[...document.querySelectorAll('.gttpd')].map(d=>d.style.transform).filter(x=>/translateX/.test(x)).length,clock:document.querySelector('#gttclkt').textContent,say:document.querySelectorAll('#gttsay p').length,bets:document.querySelectorAll('.gttb').length,co:[...document.querySelectorAll('.gttco u')].map(x=>x.textContent),now:document.querySelector('.gttb .now').textContent}}""")
        chk('the race HUD: six position dots, race clock, commentary ticker, your bet with its live position',r['dots']==6 and r['clock'].startswith('0:0') and r['say']>=1 and r['bets']==1 and r['now'].startswith('now '),r)
        r=await E("""async()=>{const c=GTTU.cur;await __g.sleep(1500);GTTU.cur.frame(1,1/60);for(let i=0;i<4000&&(c.st().run.reduce((m,q)=>Math.max(m,q.x),0)<925);i++)c.frame(1,1/60);const q=c.st().run.reduce((m,q)=>Math.max(m,q.x),0);c.frame(2,1/60);await __g.sleep(500);c.frame(2,1/60);return [Math.round(q),document.querySelector('.gttco').disabled,document.querySelector('.gttco u').textContent]}""")
        chk('cash-out offers are greyed in the last 10% of the track',r[0]>=900 and r[1] and r[2]=='closed',r)
        await E("()=>{GTTDBG.hold(false);GTTU.cur.skip()}");await pg.wait_for_timeout(300)
        # offers refresh about once a second and offers are real
        r=await E("""async()=>{await __g.card(%d);GTTDBG.setRace(%d);__g.bet('win',2,0,300);__g.bet('top3',3,0,300);const c=GTTU.cur;c.start();GTTDBG.hold(true);const t=await __g.runTo(4);GTTDBG.hold(false);GTTDBG.speed(1);await __g.sleep(2600);const a=c.offers().slice();const b=[document.querySelectorAll('.gttco u')[0].textContent,document.querySelectorAll('.gttco u')[1].textContent];GTTDBG.hold(true);GTTU.cur.skip();return [a,b,c.st().t>3]}"""%(CS,RS))
        chk('live offers appear on the bets within a second or two and show on the Cash out buttons',all(x is not None and x>=0 for x in r[0]) and sum(1 for x in r[0] if x)>=1 and any(re.match(r'^\d',x) for x in r[1]),r)
        # sound
        r=await E("""()=>{ensureAudio();const c0=[0];const o=ac.createOscillator;const bs=ac.createBufferSource;ac.createOscillator=function(){c0[0]++;return o.apply(this,arguments)};ac.createBufferSource=function(){c0[0]++;return bs.apply(this,arguments)};
          const sv=ST.svol;ST.svol=0;const n0=c0[0];gttSnd.call();gttSnd.gate();gttSnd.step(1);gttSnd.gobble(2);gttSnd.crowd(.8);gttSnd.ding();gttSnd.shutter();gttSnd.win(true);gttSnd.lose();gttSnd.stop();const muted=c0[0]-n0;
          ST.svol=1;const n1=c0[0];gttSnd.call();gttSnd.gate();gttSnd.gobble(1);gttSnd.win(false);const live=c0[0]-n1;gttSnd.crowd(.5);const bed=!!gttsndS.bed;gttSnd.stop();const bed2=!!gttsndS.bed;
          let fp=0;ST.svol=1;for(let i=0;i<20;i++){const q=c0[0];gttSnd.step(1);fp+=c0[0]-q}ac.createOscillator=o;ac.createBufferSource=bs;ST.svol=sv;return [muted,live>0,bed,bed2,fp]}""")
        chk('sound: nothing is created when the effects are off; call, gate, gobble and win make sounds; the crowd bed starts and stop() ends it; footfalls are rate-limited',r[0]==0 and r[1] and r[2] and not r[3] and r[4]<=4,r)
        chk('no page errors (race, photo, sound)',not er,er);await ctx.close()

        # ============ reduced motion / Performance mode ============
        ctx,pg,E,er=await page(b,rm=True)
        r=await E("""async()=>{await __g.open();await __g.card(%d);const seen=[];const f0=window.gttDrawRace;window.gttDrawRace=function(c,st,cam,o){seen.push(o&&o.low);return f0.apply(this,arguments)};GTTDBG.setRace(%d);__g.bet('win',1,0,100);const c=GTTU.cur;c.start();GTTDBG.hold(true);c.frame(200,1/60);
          const shk=document.querySelector('#gttrace').classList.contains('shk');await __g.sleep(50);window.gttDrawRace=f0;GTTDBG.hold(false);GTTU.cur.skip();await __g.sleep(300);return [seen.length>10&&seen.every(x=>x===true),shk]}"""%(CS,RS))
        chk('reduced motion: the race is drawn with low:true (no crowd wave, fewer particles) and the gate does not shake the screen',r==[True,False],r)
        chk('no page errors (reduced motion)',not er,er);await ctx.close()
        ctx,pg,E,er=await page(b)
        r=await E("""async()=>{await __g.open();ST.perf='low';await __g.card(%d);const seen=[];const f0=window.gttDrawRace;window.gttDrawRace=function(c,st,cam,o){seen.push(o&&o.low);return f0.apply(this,arguments)};GTTDBG.setRace(%d);__g.bet('win',1,0,100);const c=GTTU.cur;c.start();GTTDBG.hold(true);c.frame(200,1/60);
          const shk=document.querySelector('#gttrace').classList.contains('shk');window.gttDrawRace=f0;GTTDBG.hold(false);GTTU.cur.skip();await __g.sleep(300);ST.perf='high';
          GTTU.cur.again();await __g.sleep(200);for(let i=0;i<300&&!GTTU.cur.px();i++)await __g.sleep(100);__g.bet('win',1,0,100);const seen2=[];window.gttDrawRace=function(c,st,cam,o){seen2.push(o&&o.low);return f0.apply(this,arguments)};GTTU.cur.start();GTTDBG.hold(true);GTTU.cur.frame(200,1/60);window.gttDrawRace=f0;GTTDBG.hold(false);GTTU.cur.skip();await __g.sleep(200);
          return [seen.length>10&&seen.every(x=>x===true),shk,seen2.length>10&&seen2.every(x=>x===false)]}"""%(CS,RS))
        chk('Performance mode passes low:true and no shake; full quality passes low:false',r==[True,False,True],r)
        chk('no page errors (performance mode)',not er,er);await ctx.close()

        # ============ trophies, festival acorns ============
        ctx,pg,E,er=await page(b,ach=False)
        r=await E("""async()=>{await __g.open();const S0=JSON.parse(JSON.stringify(P.as||{}));const fin=__g.fin(%d,%d);const W=fin.order[0],S=fin.order[1];
          const mk=(bets,card,race)=>{P.gtt.pend={cardSeed:card,raceSeed:race,bets,cash:[],t0:0};return gttuFinishNow()};
          const has=id=>!!P.ach[id];const o={};
          mk([{k:'win',a:W,stake:100,mult:2}],%d,%d);o.t1=[has('gtt1'),has('gtt2'),has('gtt3'),has('gtt4')];
          mk([{k:'win',a:W,stake:100,mult:20}],%d,%d);o.t3=[has('gtt2'),has('gtt3')];
          mk([{k:'exact',a:W,b:S,stake:100,mult:30}],%d,%d);o.t4=has('gtt4');
          o.ids=ACH.filter(a=>/^gtt/.test(a.id)).map(a=>[a.id,a.cat,a.g]);return o}"""%(CS,RS,CS,RS,CS,RS,CS,RS))
        chk('trophies (Casino): Off to the Races on the first race, Backed a Winner on a Win win, Longshot on x15 or more, Called It on an Exact win; six trophies in ACH',r['t1']==[True,True,False,False],r)
        chk('Backed a Winner, Longshot and Called It unlock when earned; six Turkey Trot trophies exist in the Casino category',r['t3']==[True,True] and r['t4'] is True and len(r['ids'])==6 and all(x[1]=='Casino' for x in r['ids']),r)
        # by a beak and smart money
        beak=await E("""()=>{for(let r=1;r<800;r++){const f=gttRun(gttCard(%d),r);if(f.photo)return [r,f.order[0]]}return null}"""%CS)
        if beak:
            r=await E("""async(a)=>{P.gtt.pend={cardSeed:%d,raceSeed:a[0],bets:[{k:'top3',a:a[1],stake:100,mult:1.3}],cash:[],t0:0};gttuFinishNow();return !!P.ach.gtt5}"""%CS,beak)
            chk('By a Beak unlocks when your runner wins a photo finish',r is True,r)
        r=await E("""async()=>{await __g.card(%d);const fin=__g.fin(%d,%d+9);GTTDBG.setRace(%d+9);__g.bet('win',fin.order[0],0,500);const c=GTTU.cur;c.start();await __g.runTo(4);const s=c.rec().bets[0].stake;let g=P.gold;c.cash(0);const pay=P.gold-g;const unlocked=!!P.ach.gtt6;GTTDBG.hold(true);GTTU.cur.skip();return [pay,s,unlocked]}"""%(CS,CS,RS,RS))
        chk('Smart Money unlocks when a cash out pays more than the stake (and only then)',(r[0]>r[1])==r[2],r)
        # festival acorns
        r=await E("""async()=>{const fin=__g.fin(%d,%d),W=fin.order[0],L=fin.order[5];const win={k:'win',a:W,stake:100,mult:2},lose={k:'win',a:L,stake:100,mult:2};
          window.FL_FORCE=1;P.gtt.acorn={day:'',n:0};const a0=fleAcorns();const mk=b=>{P.gtt.pend={cardSeed:%d,raceSeed:%d,bets:[b],cash:[],t0:0};return gttuFinishNow()};
          const rl=mk(lose);const a1=fleAcorns();const rw=mk(win);const a2=fleAcorns();const o=[rl.acorns,a1-a0,rw.acorns,a2-a1];
          for(let i=0;i<12;i++)mk(win);const a3=fleAcorns();o.push(a3-a2,P.gtt.acorn.n);
          const last=mk(win);o.push(last.acorns);
          window.FL_FORCE=-1;P.gtt.acorn={day:'',n:0};const b0=fleAcorns();const rr=mk(win);o.push(rr.acorns,fleAcorns()-b0);window.FL_FORCE=1;return o}"""%(CS,RS,CS,RS))
        chk('festival acorns: a lost race pays none, a race with a winning bet pays +5, at most 10 races (50 acorns) a day, nothing with the festival off',r[0]==0 and r[1]==0 and r[2]==5 and r[3]==5 and r[4]==45 and r[5]==10 and r[6]==0 and r[7]==0 and r[8]==0,r)
        await E("()=>{window.FL_FORCE=1;P.gtt.acorn={day:'',n:0}}")
        r=await E("""async()=>{await __g.card(%d);const fin=__g.fin(%d,%d);GTTDBG.setRace(%d);__g.bet('win',fin.order[0],0,100);GTTU.cur.start();await __g.sleep(100);GTTU.cur.skip();await __g.sleep(300);return [document.querySelector('.gttac')?document.querySelector('.gttac').textContent:null]}"""%(CS,CS,RS,RS))
        chk('the results screen shows "+5 acorns" when they were paid',r[0] and '+5' in r[0],r)
        chk('DEV > Cheats lists the Turkey Trot buttons (hidden stats, fast race, next seed)',await E("()=>/Turkey Trot/.test(dvxHTML())&&/gtt_hid/.test(dvxHTML())&&/gtt_fast/.test(dvxHTML())&&/gtt_seed/.test(dvxHTML())"))
        chk('no page errors (trophies and acorns)',not er,er);await ctx.close()

        # ============ determinism of the replay ============
        ctx,pg,E,er=await page(b)
        r=await E("""async()=>{await __g.open();await __g.card(%d);GTTDBG.setRace(%d);__g.bet('win',0,0,100);const c=GTTU.cur;c.start();GTTDBG.hold(true);await __g.runTo(99999);const st=c.st();const a=gttRun(gttCard(%d),%d);const same=st.order.join()===a.order.join()&&st.times.join()===a.times.join();const p=c.fin();return [same,st.done,p.order.join()===a.order.join(),c.ph()]}"""%(CS,RS,CS,RS))
        chk('the race on screen is the stored race replayed step by step: same finish order and times as gttRun with the same seeds',r[0] and r[1] and r[2],r)
        chk('no page errors (replay)',not er,er);await ctx.close()

        # ============ the 98t / 98v guard enforced ============
        ctx,pg,E,er=await page(b,init='window.TW_AC_TEST=1',guard=True)
        r=await E("""async(a)=>{const enforced=TWAC.stat().enforced;await __g.open();await __g.card(a[0]);const fin=__g.fin(a[0],a[1]);GTTDBG.setRace(a[1]);CAS.bet=400;betRefresh();window.__W=fin.order[0];window.__g0=P.gold;return [enforced,fin.order[0],P.gold]}""",[CS,RS])
        await pg.click(f'.gttrow[data-l="{r[1]}"]');await pg.keyboard.press('Space');await pg.wait_for_timeout(300)
        q=await E("()=>[window.__g0-P.gold,GTTDBG.ph(),!!GTTDBG.pend()]")
        await pg.click('#gttskip');await pg.wait_for_timeout(500)
        q2=await E("""()=>{const R=GTTU.cur.R(),g2=P.gold;const exp=Math.floor(400*R.lines[0].bet.mult);let c=0;try{P.gold=9999999}catch(e){}return [g2-window.__g0,exp-400,P.gold===g2,GTTDBG.pend(),(ledgerRecent(5).map(e=>e.src))]}""")
        chk('with the 98t / 98v guard enforced (window.TW_AC_TEST): the stake is taken and the winnings paid by real clicks and keys (Start, race, payout), the pending race clears, and a console write to the coins is refused',
            r[0] is True and r[2]>=20000 and q[0]==400 and q[2] and q2[0]==q2[1] and q2[2] and q2[3] is None,[r,q,q2])
        chk('no page errors (guard page)',not er,er);await ctx.close()

        # ============ frame cost ============
        ctx,pg,E,er=await page(b)
        r=await E("""async()=>{await __g.open();await __g.card(%d);GTTDBG.setRace(%d);__g.bet('win',1,0,100);__g.bet('top3',2,0,100);__g.bet('exact',3,4,100);const c=GTTU.cur;c.start();GTTDBG.hold(true);await __g.runTo(5);
          let cc=0;const ce=document.createElement.bind(document);document.createElement=function(t){if(String(t).toLowerCase()==='canvas')cc++;return ce(t)};
          let dr=0;const d0=window.gttDrawRace;window.gttDrawRace=function(){const a=performance.now();try{return d0.apply(this,arguments)}finally{dr+=performance.now()-a}};
          const run=n=>{dr=0;const T=[];for(let i=0;i<n;i++){const a=performance.now();c.frame(1,1/60);T.push(performance.now()-a)}return [T.reduce((a,b)=>a+b,0)/n,dr/n,Math.max(...T)]};
          run(60);const A=[run(60),run(60),run(60)];ST.perf='low';run(20);const B=[run(60),run(60),run(60)];ST.perf='high';window.gttDrawRace=d0;document.createElement=ce;
          const med=a=>a.slice().sort((x,y)=>x-y)[a.length>>1];const st=c.st(),b=c.rec().bets[0];
          const a2=performance.now();for(let i=0;i<5;i++)gttOffers(st,[b],30,i);const sl=(performance.now()-a2)/5;const a3=performance.now();gttOffers(st,[b],300,9);const full=performance.now()-a3;
          return {avg:+med(A.map(x=>x[0])).toFixed(2),draw:+med(A.map(x=>x[1])).toFixed(2),low:+med(B.map(x=>x[0])).toFixed(2),lowdraw:+med(B.map(x=>x[1])).toFixed(2),worst:+Math.max(...A.map(x=>x[2])).toFixed(0),slice:+sl.toFixed(1),full:+full.toFixed(1),canv:cc,t:+st.t.toFixed(1)}}"""%(CS,RS))
        print('frame cost:',r)
        chk('frame cost of the race screen (game step + HUD + draw, software rendering, busy middle t=5-11 s, three bets, median of three 60-frame runs): average under 7 ms (a real-time race in this software renderer holds 60 fps; 10.5 lead measured median 16.7 ms frames, none over 100 ms), the game part (all but gttDrawRace) under 1 ms, no canvas created per frame, Performance mode no slower',r['avg']<7 and r['avg']-r['draw']<1 and r['canv']==0 and r['low']<=r['avg']*1.3+.3,r)
        chk('a cash-out pricing slice (30 continuations, one per frame) costs under 6 ms and a full 300-run price (at the click) under 60 ms',r['slice']<6 and r['full']<60,r)
        chk('no page errors (frame cost)',not er,er);await ctx.close()

        # ============ UI fit at three sizes ============
        for (vw,vh) in [(1600,900),(1280,720),(1024,640)]:
            ctx,pg,E,er=await page(b,vw,vh)
            o={}
            o['paddock']=await E("""async()=>{await __g.open();await __g.card(%d);return __rpuOvl(document.querySelector('.gttw'))}"""%CS)
            await pg.screenshot(path=stk(f'paddock_{vw}.png')) if vw!=1600 else None
            o['slip']=await E("""async()=>{CAS.bet=300;betRefresh();__g.bet('win',0,0,300);__g.bet('top3',2,0,300);__g.bet('exact',3,4,300);return __rpuOvl(document.querySelector('.gttw'))}""")
            await pg.screenshot(path=stk(f'slip_{vw}.png'))
            o['howto']=await E("""async()=>{GTTU.cur.help();await __g.sleep(500);const r=__rpuOvl(document.querySelector('.gttmod'));GTTU.cur.close();GTTU.cur.stats();await __g.sleep(500);const r2=__rpuOvl(document.querySelector('.gttmod'));GTTU.cur.close();return r.concat(r2)}""")
            o['race']=await E("""async()=>{GTTDBG.setRace(%d);GTTU.cur.start();GTTDBG.hold(true);await __g.runTo(8);GTTU.cur.frame(20,1/60);await __g.sleep(300);return __rpuOvl(document.querySelector('.gttw'))}"""%RS)
            await pg.screenshot(path=stk(f'race_{vw}.png'))
            o['results']=await E("""async()=>{GTTDBG.hold(false);GTTU.cur.skip();await __g.sleep(500);return __rpuOvl(document.querySelector('.gttw'))}""")
            await pg.screenshot(path=stk(f'results_{vw}.png'))
            chk(f'UI fit at {vw}x{vh}: paddock, a full slip with an Exact bet, tutorial, stats, race HUD and results: nothing overlaps, is clipped or leaves the stage',all(v==[] for v in o.values()),{k:v for k,v in o.items() if v})
            chk(f'no page errors at {vw}x{vh}',not er,er);await ctx.close()
        await b.close()
    print(f'\n{N[0]-len(FAIL)} / {N[0]} passed',flush=True)
    if FAIL:print('FAILED:',FAIL)
asyncio.run(main())
