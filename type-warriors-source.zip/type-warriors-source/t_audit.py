import asyncio,os,sys
from playwright.async_api import async_playwright
SET="()=>{RS_ASK=false;P.camp=6;for(let i=1;i<=5;i++){P.stars[i]=3}P.gold=300719;P.pets={antler:{b:560}};P.pet='antler';P.petSt=2;petNorm();title()}"
ST="()=>[ov.className,(document.querySelector('#ov h2')||{}).textContent||'',!!document.querySelector('.dkrow'),(document.querySelector('.dki.on')||{dataset:{}}).dataset.dk||'-',typeof S.back]"
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append('PE '+str(e)[:300]));pg.on('console',lambda m:er.append('C '+m.text[:160]) if m.type=='error' and 'ERR_' not in m.text else None)
        await pg.goto('file://'+os.path.abspath('out.html'));await pg.wait_for_timeout(1500);E=pg.evaluate
        await E(SET);await pg.wait_for_timeout(1500)
        # Escape from each dock destination
        for k in ['gr','pt','pg','sh']:
            await E(SET);await pg.wait_for_timeout(300);await pg.click('#dk_'+k);await pg.wait_for_timeout(500)
            a=await E(ST);await pg.keyboard.press('Escape');await pg.wait_for_timeout(400);print('esc from',k,a[1],'->',await E(ST))
        # sub tabs then Escape
        for c in ["upgrades()","bountyBoard()","profile(1)","crateHub()","settings(title)","help(title)","hbgPick(title)","saveCenter(title)","dailyMenu(title)"]:
            await E(SET);await pg.wait_for_timeout(300);await E("()=>{"+c+"}");await pg.wait_for_timeout(450)
            a=await E(ST);await pg.keyboard.press('Escape');await pg.wait_for_timeout(400);print(c.ljust(18),a[1][:16].ljust(16),a[2],'-> esc ->',await E(ST))
        # casino return
        await E(SET);await pg.wait_for_timeout(300);await E("()=>casinoOpen()");await pg.wait_for_timeout(600);await E("()=>casinoBack()");await pg.wait_for_timeout(600);print('after casino',await E(ST))
        # back from a run
        await E(SET);await pg.wait_for_timeout(300);await pg.click('#dkcont');await pg.wait_for_timeout(600);await E("()=>over(true)");await pg.wait_for_timeout(900)
        print('results',await E(ST));bs=await E("()=>[...document.querySelectorAll('#ov button')].map(b=>b.id+':'+b.textContent.trim().slice(0,20)).slice(0,12)");print(bs)
        await E("()=>title()");await pg.wait_for_timeout(500);print('home again',await E(ST),await E("()=>getComputedStyle(document.getElementById('cn')).display"))
        # hover states
        await E(SET);await pg.wait_for_timeout(1200)
        for sel,nm in [('#dkcont','cont'),('#dkmode','mode'),('#dcb','daily'),('#dk_gr','dock'),('#np','me')]:
            await pg.hover(sel);await pg.wait_for_timeout(350);await pg.screenshot(path=f'shots/au_h_{nm}.png')
        await pg.mouse.move(5,5);await pg.keyboard.press('Tab');await pg.keyboard.press('Tab');await pg.wait_for_timeout(200);await pg.screenshot(path='shots/au_focus.png');print('focus',await E("()=>document.activeElement.id||document.activeElement.className"))
        print(er[:8]);await b.close()
asyncio.run(main())
