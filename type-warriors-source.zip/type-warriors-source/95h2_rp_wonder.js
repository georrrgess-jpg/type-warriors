/* ===== RUNESTONE RAMPARTS 8.8c art: the Wonderland battle map (95h2_rp_wonder.js) =====
   Fills the optional hooks 95d calls for the 'wonder' map: a twilight palette with a starlight river (RP_PAL.wonder), rpWonderGround (aurora
   light pools, glowing crystal veins, glowing ponds, star dust), rpWonderProp (crystal trees, giant glowing mushrooms, floating lantern flowers,
   rainbow-leaf trees, crystal clusters), rpPortalArt (rune-ring portals with a swirling vortex) and rpWonderAmbient (portal swirl, aurora
   shimmer, twinkles, lantern and pool glow; batched, no filter or shadowBlur). rpBake is wrapped once to paint the starlight into the river
   after the map is baked (skipping the bridge). The painters are shared with the world map (95h). */
Object.assign(RP_PAL.wonder,{g0:'#1c1846',g1:'#2a2c6a',g2:'#16123a',blot:['#36388a','#28286a','#46389a','#243c7a'],tree:['#5a3aa8','#3a6ab8','#7a3aa0'],treeHi:'#ffd0f8',trunk:'#4a3a7a',
 rock:'#6a5cac',rockHi:'#cabcff',edge:'#120e36',curb:'#9a92dc',dirt:'#5a56a0',dirt2:'#4a4690',cob:['#8e88d4','#7e78c4','#a8a2e6'],chev:'rgba(255,230,255,.5)',water:'#7448e0',waterHi:'#ffdcff',mote:'#ffe8ff',sky:'#120a30'});
const RPWL={glow:[],port:[],star:[],sp:null};
/* one wonder prop; kind from i: 0 crystal tree, 1 giant mushroom, 2 lantern flowers, 3 rainbow-leaf tree, 4 crystal cluster. rec = record glow points */
function rpwWProp(g,x,y,h,i,rec){const k=((i*7)>>>0)%5,O=RPWO;g.save();g.fillStyle='rgba(8,4,30,.3)';g.beginPath();g.ellipse(x+h*.1,y+2,h*.4,h*.12,0,0,RPW_PI*2);g.fill();
 const add=(px,py,r,c)=>{if(rec)RPWL.glow.push([px,py,r,c])};
 if(k===0){const C=RPW_CRY[i%3];g.fillStyle=C[2];g.beginPath();g.moveTo(x-h*.06,y);g.lineTo(x-h*.04,y-h*.5);g.lineTo(x+h*.04,y-h*.5);g.lineTo(x+h*.07,y);g.closePath();g.fill();rpwOut(g,2);
  for(const [dx,dy,s,a] of[[-.2,-.55,.26,-.5],[.2,-.58,.24,.5],[0,-.78,.32,0],[-.12,-.95,.2,-.3],[.14,-.92,.18,.35]])rpwCrystal(g,x+dx*h,y+dy*h+s*h*.5,s*h,a,s*h*.5,C);add(x,y-h*.75,h*.5,'cry')}
 else if(k===1){const cap=i%2?['#5ae0ff','#b8f6ff','#2a8ad0']:['#ff6ad8','#ffc8f4','#b02aa0'];
  if(rec){g.globalCompositeOperation='lighter';g.globalAlpha=.55;const gs=rpwGlow(i%2?'90,220,255':'255,110,220',40);g.drawImage(gs,x-h*.7,y-h*.4,h*1.4,h*.8);g.globalAlpha=1;g.globalCompositeOperation='source-over'}
  for(const [dx,s] of[[h*.32,.42],[0,1]]){const sh=h*.62*s,cw=h*.42*s;g.fillStyle='#efe6ff';g.beginPath();g.moveTo(x+dx-cw*.18,y);g.quadraticCurveTo(x+dx-cw*.1,y-sh*.6,x+dx-cw*.12,y-sh);g.lineTo(x+dx+cw*.12,y-sh);g.quadraticCurveTo(x+dx+cw*.1,y-sh*.6,x+dx+cw*.2,y);g.closePath();g.fill();rpwOut(g,2);
   g.fillStyle='rgba(120,90,200,.3)';g.fillRect(x+dx,y-sh,cw*.12,sh);
   const cy=y-sh;g.beginPath();g.moveTo(x+dx-cw,cy+cw*.08);g.quadraticCurveTo(x+dx-cw*.95,cy-cw*.8,x+dx,cy-cw*.82);g.quadraticCurveTo(x+dx+cw*.95,cy-cw*.8,x+dx+cw,cy+cw*.08);g.quadraticCurveTo(x+dx,cy+cw*.26,x+dx-cw,cy+cw*.08);g.closePath();
   const q=g.createLinearGradient(0,cy-cw*.8,0,cy+cw*.2);q.addColorStop(0,cap[1]);q.addColorStop(.6,cap[0]);q.addColorStop(1,cap[2]);g.fillStyle=q;g.fill();rpwOut(g,2.2);
   g.fillStyle='rgba(255,255,255,.85)';for(const [sx,sy,r] of[[-.45,-.3,.12],[.1,-.55,.1],[.5,-.2,.09],[-.1,-.15,.07]]){g.beginPath();g.ellipse(x+dx+sx*cw,cy+sy*cw,r*cw,r*cw*.7,0,0,RPW_PI*2);g.fill()}
   g.fillStyle='rgba(255,255,255,.35)';g.beginPath();g.ellipse(x+dx-cw*.45,cy-cw*.5,cw*.28,cw*.12,-.5,0,RPW_PI*2);g.fill();add(x+dx,cy-cw*.3,cw*1.3,i%2?'cy':'pk')}}
 else if(k===2){for(let j=0;j<3;j++){const sx=x+(j-1)*h*.22,top=y-h*(.62+((j*5+i)%3)*.12),bend=(j-1)*h*.18+h*.12;g.strokeStyle=O;g.lineWidth=4.2;g.beginPath();g.moveTo(sx,y);g.quadraticCurveTo(sx-bend*.2,top,sx+bend,top+h*.06);g.stroke();
   g.strokeStyle='#3a8a6a';g.lineWidth=2.2;g.stroke();const lx=sx+bend,ly=top+h*.08,c=['#ffe46a','#ff9ae8','#9af0ff'][(i+j)%3];
   g.fillStyle=c;g.beginPath();g.moveTo(lx-h*.09,ly);g.quadraticCurveTo(lx-h*.1,ly+h*.16,lx,ly+h*.17);g.quadraticCurveTo(lx+h*.1,ly+h*.16,lx+h*.09,ly);g.quadraticCurveTo(lx,ly-h*.05,lx-h*.09,ly);g.closePath();g.fill();rpwOut(g,1.8);
   g.fillStyle='rgba(255,255,255,.75)';g.beginPath();g.ellipse(lx-h*.03,ly+h*.06,h*.025,h*.05,0,0,RPW_PI*2);g.fill();add(lx,ly+h*.09,h*.3,c)}
  for(const s of[-1,1]){g.fillStyle='#3a9a6a';g.beginPath();g.ellipse(x+s*h*.14,y-h*.06,h*.16,h*.05,s*.5,0,RPW_PI*2);g.fill();rpwOut(g,1.5)}}
 else if(k===3){g.fillStyle='#5a3a6a';g.fillRect(x-h*.05,y-h*.38,h*.1,h*.39);g.strokeStyle=O;g.lineWidth=1.8;g.strokeRect(x-h*.05,y-h*.38,h*.1,h*.39);
  const C=[[-.26,-.5,.24,'#ff7ab8'],[.26,-.52,.24,'#7ad8ff'],[-.12,-.72,.25,'#ffd46a'],[.16,-.74,.24,'#8af0a0'],[0,-.92,.22,'#c08aff']];
  g.beginPath();for(const [dx,dy,r] of C){g.moveTo(x+dx*h+r*h,y+dy*h);g.arc(x+dx*h,y+dy*h,r*h,0,RPW_PI*2)}g.strokeStyle=O;g.lineWidth=4;g.stroke();
  for(const [dx,dy,r,c] of C){g.fillStyle=c;g.beginPath();g.arc(x+dx*h,y+dy*h,r*h,0,RPW_PI*2);g.fill();g.fillStyle='rgba(255,255,255,.4)';g.beginPath();g.arc(x+dx*h-r*h*.3,y+dy*h-r*h*.35,r*h*.38,0,RPW_PI*2);g.fill()}
  g.fillStyle='rgba(30,10,70,.18)';g.beginPath();g.arc(x+h*.24,y-h*.46,h*.2,0,RPW_PI*2);g.fill();add(x,y-h*.7,h*.45,'rb')}
 else{for(const [dx,s,a,c] of[[-.16,.5,-.4,0],[0,.82,-.05,2],[.15,.6,.3,1],[.3,.36,.6,0]])rpwCrystal(g,x+dx*h,y,s*h,a,s*h*.32,RPW_CRY[(c+i)%3]);add(x,y-h*.4,h*.4,'cry')}
 g.restore()}
/* the swirling rune portal (replaces the cave); x,y is the old cave anchor */
function rpwVortex(){if(RPWL.sp)return RPWL.sp;const r=56,c=rpwCv(r*2,r*2),g=c.getContext('2d');g.translate(r,r);g.lineCap='round';
 for(let k=0;k<4;k++){g.rotate(RPW_PI/2);g.beginPath();for(let u=0;u<=1;u+=.04){const a=u*4.2,rr=4+u*(r-8);u?g.lineTo(Math.cos(a)*rr,Math.sin(a)*rr):g.moveTo(Math.cos(a)*rr,Math.sin(a)*rr)}
  g.strokeStyle=k%2?'rgba(255,170,250,.75)':'rgba(140,230,255,.75)';g.lineWidth=5;g.stroke();g.strokeStyle='rgba(255,255,255,.7)';g.lineWidth=1.6;g.stroke()}return RPWL.sp=c}
function rpPortalArt(g,x,y){const cx=x+4,cy=y-16,rx=50,ry=64;RPWL.port.push([cx,cy,rx,ry]);g.save();
 g.fillStyle='rgba(8,4,30,.4)';g.beginPath();g.ellipse(cx+6,y+50,74,16,0,0,RPW_PI*2);g.fill();
 /* vortex disc */
 let q=g.createRadialGradient(cx,cy,4,cx,cy,rx);q.addColorStop(0,'#ffffff');q.addColorStop(.18,'#ffc8fa');q.addColorStop(.5,'#9a4ae0');q.addColorStop(1,'#1a0a4a');g.fillStyle=q;g.beginPath();g.ellipse(cx,cy,rx,ry,0,0,RPW_PI*2);g.fill();
 g.save();g.beginPath();g.ellipse(cx,cy,rx,ry,0,0,RPW_PI*2);g.clip();g.translate(cx,cy);g.scale(1,ry/rx);g.globalAlpha=.8;g.drawImage(rpwVortex(),-56,-56);g.restore();
 /* rune-stone ring */
 const n=14;for(let k=0;k<n;k++){const a0=k/n*RPW_PI*2,a1=(k+.86)/n*RPW_PI*2,R0=1,R1=1.24;g.beginPath();g.ellipse(cx,cy,rx*R1,ry*R1,0,a0,a1);g.ellipse(cx,cy,rx*R0,ry*R0,0,a1,a0,true);g.closePath();
  g.fillStyle=k%2?'#8e80cc':'#a89ce0';g.fill();rpwOut(g,2);const am=(a0+a1)/2,mx=cx+Math.cos(am)*rx*1.12,my=cy+Math.sin(am)*ry*1.12;g.fillStyle=k%3?'#7af0ff':'#ff9af0';g.beginPath();g.arc(mx,my,2.2,0,RPW_PI*2);g.fill()}
 g.fillStyle='rgba(255,255,255,.35)';g.beginPath();g.ellipse(cx,cy,rx*1.18,ry*1.18,0,RPW_PI*.95,RPW_PI*1.45);g.ellipse(cx,cy,rx*1.04,ry*1.04,0,RPW_PI*1.45,RPW_PI*.95,true);g.closePath();g.fill();
 /* keystone gem and base */
 g.fillStyle='#ff7ae0';g.beginPath();g.moveTo(cx,cy-ry*1.36);g.lineTo(cx+9,cy-ry*1.2);g.lineTo(cx,cy-ry*1.02);g.lineTo(cx-9,cy-ry*1.2);g.closePath();g.fill();rpwOut(g,2);
 g.fillStyle='#6a5cac';g.beginPath();g.moveTo(cx-rx*1.4,y+52);g.lineTo(cx-rx*1.1,y+34);g.lineTo(cx+rx*1.1,y+34);g.lineTo(cx+rx*1.4,y+52);g.closePath();g.fill();rpwOut(g,2.4);g.fillStyle='#8e80cc';g.fillRect(cx-rx*1.1,y+34,rx*2.2,5);
 for(const [dx,h,a,c] of[[-rx*1.25,40,-.3,0],[-rx*1.05,26,.2,1],[rx*1.2,36,.3,2],[rx*1.4,22,.5,0]])rpwCrystal(g,cx+dx,y+46,h,a,h*.32,RPW_CRY[c]);
 g.globalCompositeOperation='lighter';g.globalAlpha=.6;g.drawImage(rpwGlow('200,120,255',70),cx-90,cy-90,180,180);g.restore()}
/* ground detail after the base ground: aurora light, glowing crystal veins, glowing ponds, star dust */
function rpWonderGround(g,G,H){RPWL.glow=[];RPWL.port=[];RPWL.star=[];const rnd2=rpwR,free=(x,y,m)=>G.dRoad(x,y)>m&&G.dRiver(x,y)>m+20&&!G.pads.some(p=>Math.hypot(p.x-x,(p.y-y)*1.3)<70);
 g.save();g.globalCompositeOperation='lighter';
 for(let i=0;i<14;i++){const x=rnd2(i+2000)*1600,y=rnd2(i+2050)*H,r=140+rnd2(i+2100)*160;g.globalAlpha=.16;g.drawImage(rpwGlow(['90,200,255','255,110,220','150,120,255','90,255,190'][i%4],80),x-r,y-r*.6,r*2,r*1.2)}
 g.globalAlpha=1;for(let i=0;i<30;i++){let x=rnd2(i+2200)*1600,y=rnd2(i+2260)*H;if(!free(x,y,56))continue;const col=['120,230,255','255,140,240','180,150,255'][i%3];
  g.beginPath();g.moveTo(x,y);const pts=[[x,y]];for(let k=0;k<6;k++){x+=(rnd2(i*13+k)-.5)*34;y+=(rnd2(i*11+k+5)-.5)*16;if(G.dRoad(x,y)<44)break;g.lineTo(x,y);pts.push([x,y])}
  g.strokeStyle=`rgba(${col},.22)`;g.lineWidth=7;g.stroke();g.strokeStyle=`rgba(${col},.55)`;g.lineWidth=2.2;g.stroke();const e=pts[pts.length-1];g.globalAlpha=.5;g.drawImage(rpwGlow(col,14),e[0]-14,e[1]-14);g.globalAlpha=1}
 g.restore();
 /* glowing ponds */
 let n=0;for(let i=0;i<60&&n<6;i++){const x=80+rnd2(i+2400)*1150,y=240+rnd2(i+2450)*460,rx=34+rnd2(i+2500)*22,ry=rx*.42;if(!free(x,y,rx+38))continue;n++;
  g.fillStyle='#120e36';g.beginPath();g.ellipse(x,y,rx+7,ry+5,0,0,RPW_PI*2);g.fill();rpwOut(g,2.4);const q=g.createRadialGradient(x,y,2,x,y,rx);q.addColorStop(0,'#e8fbff');q.addColorStop(.35,'#7ae8ff');q.addColorStop(1,'#3a3ac0');g.fillStyle=q;g.beginPath();g.ellipse(x,y,rx,ry,0,0,RPW_PI*2);g.fill();
  g.strokeStyle='rgba(255,255,255,.6)';g.lineWidth=1.6;g.beginPath();g.ellipse(x,y,rx*.6,ry*.55,0,RPW_PI*1.1,RPW_PI*1.6);g.stroke();
  for(let k=0;k<7;k++){const a=k/7*RPW_PI*2+.3,sx=x+Math.cos(a)*(rx+8),sy=y+Math.sin(a)*(ry+6);g.fillStyle=k%2?'#8e80cc':'#a89ce0';g.beginPath();g.ellipse(sx,sy,6,4,0,0,RPW_PI*2);g.fill();rpwOut(g,1.4)}
  RPWL.glow.push([x,y,rx*1.4,'cy'])}
 /* star dust */
 for(let i=0;i<520;i++){const x=rnd2(i+2600)*1600,y=rnd2(i+3200)*H;if(G.dRoad(x,y)<42)continue;g.fillStyle=['#ffffff','#ffd0fa','#a8f0ff','#fff2a8'][i%4];g.globalAlpha=.55+rnd2(i)*.4;g.fillRect(x,y,i%7?1.6:2.4,i%7?1.6:2.4);if(i%9===0&&G.dRoad(x,y)>60)RPWL.star.push([x,y])}g.globalAlpha=1}
function rpWonderProp(g,x,y,h,i){rpwWProp(g,x,y,h*.92,i,true)}
/* starlight in the river, painted once after the bake (the bridge is skipped) */
{const b0=rpBake;rpBake=function(map){const had=!!RPBAKE[map.id],B=b0.apply(this,arguments);if(!had&&map.pal==='wonder'&&B&&B.G&&B.G.RV)try{rpwStarRiver(B)}catch(e){console.error(e)}return B}}
function rpwStarRiver(B){const g=B.c.getContext('2d'),G=B.G,RS=G.RV.S;g.save();g.lineCap='round';g.lineJoin='round';
 const seg=(w,col,a)=>{g.globalAlpha=a==null?1:a;g.strokeStyle=col;g.lineWidth=w;g.beginPath();let on=false;for(let i=0;i<RS.length;i++){const p=RS[i],ok=G.dRoad(p.x,p.y)>58+w*.1;if(ok){on?g.lineTo(p.x,p.y):g.moveTo(p.x,p.y);on=true}else on=false}g.stroke();g.globalAlpha=1};
 seg(70,'#2a1a7a');seg(56,'#5a36c8');seg(36,'#8a5af0');seg(14,'#d8b0ff',.55);
 g.globalCompositeOperation='lighter';for(let i=0;i<RS.length;i+=6){const p=RS[i];if(G.dRoad(p.x,p.y)<70)continue;g.globalAlpha=.22;g.drawImage(rpwGlow('170,120,255',30),p.x-34,p.y-34,68,68)}g.globalAlpha=1;g.globalCompositeOperation='source-over';
 for(let i=0;i<RS.length;i+=2){const p=RS[i],o=(rpwR(i+77)-.5)*48,x=p.x-Math.sin(p.a)*o,y=p.y+Math.cos(p.a)*o;if(G.dRoad(x,y)<62)continue;const c=['#ffffff','#ffd8ff','#a8f4ff'][i%3];g.fillStyle=c;
  if(i%10===0){rpwStar(g,x,y,3.4,4);g.fill()}else{g.globalAlpha=.8;g.fillRect(x-.9,y-.9,1.8,1.8);g.globalAlpha=1}}
 g.restore()}
/* live: portal swirl, aurora veils, twinkles, lantern and pond glow (all batched; about 0.1 ms) */
function rpWonderAmbient(c,t,R){if(R&&R.rm)return;c.save();const sp=rpwVortex();
 for(const p of RPWL.port){c.save();c.beginPath();c.ellipse(p[0],p[1],p[2],p[3],0,0,RPW_PI*2);c.clip();c.translate(p[0],p[1]);c.scale(1,p[3]/p[2]);c.rotate(t*1.4);c.globalAlpha=.85;c.drawImage(sp,-56,-56);c.rotate(-t*2.3);c.globalAlpha=.4;c.drawImage(sp,-40,-40,80,80);c.restore()}
 c.globalCompositeOperation='lighter';
 for(const p of RPWL.port){c.globalAlpha=.3+.2*Math.sin(t*2.2+p[1]);c.drawImage(rpwGlow('200,120,255',70),p[0]-80,p[1]-90,160,180)}
 /* aurora veils drifting over the top of the map */
 const av=rpwAurora();for(let k=0;k<2;k++){c.globalAlpha=.32+.16*Math.sin(t*.7+k*2.1);c.drawImage(av,-80+k*760+Math.sin(t*.13+k)*60,46+k*18,900,120)}
 const L=RPWL.glow;for(let i=0;i<L.length;i+=1){const l=L[i];if(i>14)break;c.globalAlpha=.18+.14*Math.sin(t*2+i*1.3);const col=l[3]==='cy'||l[3]==='cry'?'110,220,255':l[3]==='pk'?'255,120,230':l[3]==='rb'?'255,200,150':'255,220,140';c.drawImage(rpwGlow(col,24),l[0]-l[2],l[1]-l[2]*.7,l[2]*2,l[2]*1.4)}
 c.globalCompositeOperation='source-over';c.fillStyle='#ffffff';const S=RPWL.star;c.globalAlpha=.9;c.beginPath();
 for(let i=0;i<S.length&&i<40;i++){const u=(t*.5+i*.137)%1;if(u>.4)continue;const a=Math.sin(u/.4*RPW_PI),s=1+a*3.6,x=S[i][0],y=S[i][1];c.moveTo(x,y-s*1.5);c.lineTo(x+s*.3,y-s*.3);c.lineTo(x+s*1.5,y);c.lineTo(x+s*.3,y+s*.3);c.lineTo(x,y+s*1.5);c.lineTo(x-s*.3,y+s*.3);c.lineTo(x-s*1.5,y);c.lineTo(x-s*.3,y-s*.3);c.closePath()}c.fill();
 c.restore()}
/* a soft aurora ribbon sprite (baked once) */
function rpwAurora(){if(RPWL.au)return RPWL.au;const w=450,h=60,c=rpwCv(w,h),g=c.getContext('2d');for(let k=0;k<3;k++){const q=g.createLinearGradient(0,0,w,0);q.addColorStop(0,'rgba(90,255,190,0)');q.addColorStop(.3,k===1?'rgba(255,120,230,.5)':'rgba(90,255,190,.5)');q.addColorStop(.7,'rgba(120,180,255,.5)');q.addColorStop(1,'rgba(120,180,255,0)');
  g.strokeStyle=q;g.lineWidth=10-k*3;g.beginPath();for(let x=0;x<=w;x+=10){const y=h/2+Math.sin(x*.018+k)*14+k*4;x?g.lineTo(x,y):g.moveTo(x,y)}g.stroke()}
 return RPWL.au=c}
