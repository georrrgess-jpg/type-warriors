/* ===== UPDATE 8.2: Wildcard notification and its secret code =====
   Pushed at the owner's request: an Updates entry (unread on the bell) with a collage of the new card game.
   The owner chose no News card for 8.2. The code WILDRUNE82 (2,500 coins and the Elder Rune card back, once per save) is hidden at the
   end of the Updates notes only. */
const UPD82_IMG=typeof WC82_IMG==='string'?WC82_IMG:'';
const UPD82_ALT='Update 8.2 collage: the Wildcard menu, a game in progress, the element picker, the results podium and the room lobby';
const UPD82_B="Wildcard, the tavern card game, is now open in the Casino!\n\n"
+"• SOLO: three tables of tavern regulars. The Goblin (Easy), the Coven Mother (Medium) and Warlord Gorath (Hard), with buy-ins of 60, 150 and 400 gold. Win the pot, or come second and get some of your buy-in back.\n"
+"• THE DECK: four elements (Ember, Tide, Grove and Spark), plus Stun, Turnabout, +2 Curse, Wild Rune and +4 Hex. Match the element or the face and be the first to empty your hand.\n"
+"• CALL WILD! when you are down to one card. Forget, and anyone who taps you first makes you draw two. The bots forget too, so catch them!\n"
+"• FRIENDS: Pass & play on one device (hands stay hidden between turns), or same Wi-Fi rooms where phones and computers join with an invite. No accounts and no servers.\n"
+"• HOUSE RULES: stack +2 and +4, draw until you can play, sevens swap hands, turn timers and gold stakes.\n"
+"• STATS: games, wins, streaks, gold won, fastest win and more, plus unlockable card backs (Hallow's Eve, Royal Gold, Astral and one secret).\n"
+"• Find it in the Casino under Cards, or on the Special tab.";
UPDATES.push({id:'u-8.2',ts:Date.UTC(2026,9,14,18,0),tag:'New',h:'8.2 Wildcard is OUT!',b:UPD82_B+'\n\nP.S. Every tavern keeps a secret rune. Speak it in Settings › Data › Cheat codes: wildrune82',img:UPD82_IMG||undefined,alt:UPD82_ALT});
{const b0=bellInner;bellInner=function(){let h=b0.apply(this,arguments);try{if(BELL_TAB==='u')h=h.replace('wildrune82','<span class="blsec" title="Try it in Settings › Data › Cheat codes">wildrune82</span>')}catch(e){}return h}}
/* the code: coins plus the Elder Rune card back */
CC_BUILTIN.push({text:'WILDRUNE82',type:'gold',n:2500,id:'',max:0,used:0,builtin:1,back:'rune'});
{const g0=ccGrant;ccGrant=function(c,k){const r=g0.apply(this,arguments);try{if(r&&r.ok&&c&&c.back&&WCBK[c.back]){const W=wcSt();W.backs[c.back]=1;W.back=c.back;save();r.rw.back=c.back;r.m='Code accepted! +'+c.n.toLocaleString('en-US')+' coins and the '+WCBK[c.back].n+' card back.'}}catch(e){}return r}}
{const p0=ccPlay;ccPlay=function(rw){const pr=p0.apply(this,arguments);try{const card=document.querySelector('#ccfx .cccard'),k=rw&&rw.back;if(card&&k&&WCBK[k]&&!card.querySelector('.ccegg')){
 const d=document.createElement('div');d.className='ccegg ccbk';d.innerHTML=`<span class="ccbki">${wcBack(k)}</span><span><b>+ ${WCBK[k].n} card back</b><small>Wildcard · now in use on your cards</small></span>`;
 const ok=card.querySelector('.ccok');card.insertBefore(d,ok||null)}}catch(e){}return pr}}
{const st=document.createElement('style');st.textContent=`.ccbk{border-color:#8affc8!important;background:linear-gradient(180deg,#0e3a2c,#06201a)!important}.ccbki{width:44px;height:64px;display:block}.ccbki svg{width:100%;height:100%;display:block}.ccbk small{color:#a8ffd8!important}`;document.head.appendChild(st)}
