/* ===== 9.5 THE CROOKED CUE: pop-up tutorials (96q) =====
   A small coach engine: a spotlight on one element, a card with the step text, Next / Skip, step dots.
   Tours are shown once each (P.pz.tut[id]) and can be replayed from House Rules.
   pzCoach(id,steps,opts): steps are {sel, title, text, side, pad, free, until, wait, btn, onShow}.
     sel   : CSS selector or a function returning an element or a {x,y,w,h} box on the 1600 x 900 stage (none = centred card)
     free  : the player may use the screen while the card is up (no dim, clicks pass through)
     until : a function; the step moves on by itself when it returns true (polled 5 times a second)
     btn   : the label of the Next button (false = no button, the step waits for until)
   Only transform and opacity are animated. */
const PZC={cur:null,tick:0,keyOn:false};
function pzCoachRoot(){return ov.querySelector(':scope>.pzh,:scope>.pzm,:scope>.pzr,:scope>.pzk')}
function pzCoachBox(root,t){try{if(!t)return null;if(typeof t==='function')t=t();if(!t)return null;
 if(Array.isArray(t)){const bs=t.map(x=>pzCoachBox(root,x)).filter(Boolean);if(!bs.length)return null;const x0=Math.min(...bs.map(b=>b.x)),y0=Math.min(...bs.map(b=>b.y)),x1=Math.max(...bs.map(b=>b.x+b.w)),y1=Math.max(...bs.map(b=>b.y+b.h));return {x:x0,y:y0,w:x1-x0,h:y1-y0}}if(typeof t==='string')t=root.querySelector(t);if(!t)return null;
 if(t.x!=null&&t.w!=null&&!(t instanceof Element))return t;const r=t.getBoundingClientRect(),rr=root.getBoundingClientRect(),s=rr.width/1600||1;if(!r.width&&!r.height)return null;
 return {x:(r.left-rr.left)/s,y:(r.top-rr.top)/s,w:r.width/s,h:r.height/s}}catch(e){return null}}
function pzCoachActive(){return !!(PZC.cur&&PZC.cur.el&&PZC.cur.el.isConnected)}
var PZ_TUT_OFF=false;/* test scripts switch the tutorials off */
function pzCoach(id,steps,o){o=o||{};const Z=PZS();if(!o.force&&(Z.tut[id]||PZ_TUT_OFF))return false;if(pzCoachActive()){if(!o.queue)return false;PZC.q=PZC.q||[];PZC.q.push([id,steps,o]);return true}
 const root=o.root||pzCoachRoot();if(!root)return false;steps=steps.filter(s=>!s.skipIf||!s.skipIf());if(!steps.length)return false;
 const el=document.createElement('div');el.className='pztu';el.innerHTML=`<div class="pztudim"></div><div class="pztus"><i></i></div><div class="pztuc"><div class="pztuar"></div><small></small><div class="pztut"></div><p></p><div class="pztub"><button class="pztusk">Skip</button><button class="pztun">Next</button></div><div class="pztud"></div></div>`;
 root.appendChild(el);const C={id,steps,o,i:-1,el,root,tok:PZ.tok};PZC.cur=C;
 el.querySelector('.pztun').onclick=e=>{e.stopPropagation();pzCoachNext()};el.querySelector('.pztusk').onclick=e=>{e.stopPropagation();pzCoachEnd(true)};
 el.querySelector('.pztudim').onclick=e=>{e.stopPropagation();const s=C.steps[C.i];if(s&&s.btn!==false&&!s.free)pzCoachNext()};
 if(!PZC.keyOn){PZC.keyOn=true;addEventListener('keydown',pzCoachKey,true)}
 clearInterval(PZC.tick);PZC.tick=setInterval(pzCoachPoll,200);if(o.onStart)try{o.onStart()}catch(e){}
 pzCoachNext();return true}
function pzCoachKey(e){const C=PZC.cur;if(!pzCoachActive())return;const s=C.steps[C.i];if(!s)return;
 if(e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();pzCoachEnd(true);return}
 if(s.free)return;/* free steps let the game have its keys */
 if(e.key==='Enter'||e.key===' '||e.key==='ArrowRight'){e.preventDefault();e.stopImmediatePropagation();if(!e.repeat&&s.btn!==false)pzCoachNext();return}
 e.stopImmediatePropagation()}
function pzCoachPoll(){const C=PZC.cur;if(!C)return;try{if(PZ.on&&PZ.clockOn&&PZ.M&&!PZ.M.trick){PZ.clock=pzClockMax();pzHudClock()}}catch(e){}if(!C.el.isConnected||PZ.tok!==C.tok&&!C.o.keepTok){pzCoachEnd(false,true);return}const s=C.steps[C.i];if(!s)return;
 if(s.until){let ok=false;try{ok=s.until()}catch(e){}if(ok){pzCoachNext();return}}
 if(s.follow)pzCoachPlace(C,s)}
function pzCoachNext(){const C=PZC.cur;if(!C)return;C.i++;while(C.i<C.steps.length&&C.steps[C.i].skipIf&&(()=>{try{return C.steps[C.i].skipIf()}catch(e){return false}})())C.i++;
 if(C.i>=C.steps.length){pzCoachEnd(false);return}const s=C.steps[C.i],el=C.el,card=el.querySelector('.pztuc');pzFx('tick');
 el.classList.toggle('free',!!s.free);el.classList.toggle('nodim',!!s.free||!!s.nodim);
 card.querySelector('small').textContent=(s.kicker||C.o.kicker||'TUTORIAL')+(C.steps.length>1?` · ${C.i+1} / ${C.steps.length}`:'');
 card.querySelector('.pztut').textContent=s.title||'';card.querySelector('p').innerHTML=s.text||'';
 const nb=card.querySelector('.pztun');nb.hidden=s.btn===false;nb.textContent=s.btn||(C.i===C.steps.length-1?(C.o.last||'Got it'):'Next');
 card.querySelector('.pztusk').hidden=C.steps.length<2||C.i===C.steps.length-1&&!C.o.skipLast||!!s.noSkip;
 card.querySelector('.pztud').innerHTML=C.steps.length>1?C.steps.map((x,k)=>`<i class="${k===C.i?'on':k<C.i?'done':''}"></i>`).join(''):'';
 if(s.extra){const b=document.createElement('button');b.className='pztux';b.textContent=s.extra[0];b.onclick=e=>{e.stopPropagation();pzCoachEnd(false);try{s.extra[1]()}catch(err){}};card.querySelector('.pztub').prepend(b)}else{const x=card.querySelector('.pztux');if(x)x.remove()}
 if(s.onShow)try{s.onShow()}catch(e){}
 card.classList.remove('in');void card.offsetWidth;card.classList.add('in');pzCoachPlace(C,s)}
function pzCoachPlace(C,s){const el=C.el,sp=el.querySelector('.pztus'),card=el.querySelector('.pztuc'),ar=card.querySelector('.pztuar');const b=s.sel?pzCoachBox(C.root,s.sel):null;
 const cw=s.w||400;card.style.width=cw+'px';const ch=card.offsetHeight||170;let x,y,side='c';
 if(b){const p=s.pad==null?10:s.pad,bx=b.x-p,by=b.y-p,bw=b.w+p*2,bh=b.h+p*2;const fresh=sp.hidden||!sp.dataset.on;sp.hidden=false;if(fresh){sp.style.transition='none'}sp.style.width=bw+'px';sp.style.height=bh+'px';sp.style.transform=`translate(${bx}px,${by}px)`;if(fresh){void sp.offsetWidth;sp.style.transition='';sp.dataset.on=1}sp.style.borderRadius=(s.r!=null?s.r:Math.min(26,Math.min(bw,bh)/2))+'px';
  el.classList.toggle('round',!!s.round);el.classList.add('spot');
  side=s.side||(bx+bw+cw+40<1600?'right':bx-cw-40>0?'left':by+bh+ch+40<900?'bottom':'top');
  if(side==='right'){x=bx+bw+28;y=by+bh/2-ch/2}else if(side==='left'){x=bx-cw-28;y=by+bh/2-ch/2}else if(side==='bottom'){x=bx+bw/2-cw/2;y=by+bh+28}else{x=bx+bw/2-cw/2;y=by-ch-28}
  x=Math.max(16,Math.min(1600-cw-16,x));y=Math.max(16,Math.min(900-ch-16,y));
  /* the little arrow points from the card at the spotlight */
  if(side==='right'||side==='left'){ar.style.top=Math.max(18,Math.min(ch-34,by+bh/2-y-8))+'px';ar.style.left=''}else{ar.style.left=Math.max(18,Math.min(cw-34,bx+bw/2-x-8))+'px';ar.style.top=''}}
 else{sp.hidden=true;sp.dataset.on='';el.classList.remove('spot');x=800-cw/2;y=s.y!=null?s.y:450-ch/2}
 if(s.at){x=s.at.x;y=s.at.y;side=s.at.side||'c'}
 ar.className='pztuar '+side;card.style.left=x+'px';card.style.top=y+'px'}
function pzCoachEnd(skipped,silent){const C=PZC.cur;if(!C)return;PZC.cur=null;clearInterval(PZC.tick);const Z=PZS();
 if(!C.o.noSave&&!(silent&&!skipped&&C.i<C.steps.length-1&&C.o.resumable)){Z.tut[C.id]=1;save()}
 const el=C.el;el.classList.add('out');setTimeout(()=>el.remove(),260);
 if(C.o.onEnd)try{C.o.onEnd(!!skipped)}catch(e){}
 if(!silent&&PZC.q&&PZC.q.length){const n=PZC.q.shift();setTimeout(()=>{if(!pzCoachActive())pzCoach(n[0],n[1],n[2])},320)}}
/* forget every tutorial, so they all play again */
function pzCoachReset(){const Z=PZS();Z.tut={};save();PZC.q=[]}
{const st=document.createElement('style');st.textContent=`
.pztu{position:absolute;inset:0;z-index:60;pointer-events:none;font-family:var(--ui),Poppins,sans-serif}
.pztu.out{opacity:0;transition:opacity .24s}
.pztudim{position:absolute;inset:0;background:#06030ea8;pointer-events:auto;animation:pztuFade .3s both}
.pztu.spot:not(.nodim) .pztus{box-shadow:0 0 0 2400px #06030eb0}
.pztu.spot .pztudim{background:transparent;animation:none}
.pztu.nodim .pztudim{display:none}
.pztus{position:absolute;left:0;top:0;border-radius:22px;pointer-events:none;transition:transform .34s cubic-bezier(.3,1.25,.5,1)}
.pztus i{position:absolute;inset:-6px;border-radius:inherit;border:3px solid #ffd45a;animation:pztuRing 1.4s ease-out infinite}
.pztu.round .pztus,.pztu.round .pztus i{border-radius:50%}
.pztuc{position:absolute;left:0;top:0;box-sizing:border-box;text-align:left;padding:18px 22px 16px;border-radius:22px;background:linear-gradient(180deg,#2a2070,#120b38);border:3px solid #ffd45a;box-shadow:0 0 0 3px #12081f,0 18px 40px #000c;pointer-events:auto;color:#efe8ff;opacity:0}
.pztuc.in{animation:pztuIn .38s cubic-bezier(.25,1.45,.45,1) both}
.pztuc small{display:block;font-size:11px;font-weight:800;letter-spacing:.14em;color:#ffd45a;margin-bottom:2px}
.pztut{font:400 30px/1.1 "Pirata One",Georgia,serif;color:#fff2c8;text-shadow:0 2px 0 #12081f;margin-bottom:6px}
.pztuc p{margin:0;font-size:15px;line-height:1.45;font-weight:500;color:#e2dafc}.pztuc p b{color:#ffd45a;font-weight:800}.pztuc p em{font-style:normal;color:#8affb4;font-weight:700}
.pztuc kbd{display:inline-block;min-width:18px;padding:0 6px;border-radius:6px;background:#12081f;border:1px solid #5a4ca0;font:800 12px/20px Poppins,sans-serif;color:#fff2c8;text-align:center}
.pztub{display:flex;justify-content:flex-end;gap:10px;margin-top:14px}
.pztub button{height:40px;padding:0 20px;border-radius:13px;border:3px solid #12081f;font:800 15px Poppins,sans-serif;cursor:pointer;transition:transform .12s}
.pztub button:hover{transform:translateY(-2px)}.pztub button:active{transform:translateY(1px)}
.pztun,.pztux{background:linear-gradient(180deg,#ffe27a,#f2b631);color:#2a1a04;box-shadow:0 4px 0 #9a6a10}
.pztux{background:linear-gradient(180deg,#a8ffcc,#3ccf86);box-shadow:0 4px 0 #1a7a4a;color:#06200f}
.pztusk{background:#2a2070;color:#c4badf;margin-right:auto}
.pztub button[hidden]{display:none}
.pztud{position:absolute;left:22px;bottom:-14px;display:flex;gap:6px}
.pztud i{width:9px;height:9px;border-radius:50%;background:#2a2070;border:2px solid #12081f;transition:transform .25s}.pztud i.done{background:#c99a3a}.pztud i.on{background:#ffd45a;transform:scale(1.35)}
.pztuar{position:absolute;width:18px;height:18px;background:#2a2070;border:3px solid #ffd45a;transform:rotate(45deg)}
.pztuar.c{display:none}.pztuar.right{left:-12px;border-top:0;border-right:0;background:#221a5c}.pztuar.left{right:-12px;border-bottom:0;border-left:0;background:#221a5c}
.pztuar.bottom{top:-12px;border-bottom:0;border-right:0;background:#2a2070}.pztuar.top{bottom:-12px;border-top:0;border-left:0;background:#140c3c}
.pztu.free .pztuc{box-shadow:0 0 0 3px #12081f,0 12px 30px #000b}
@keyframes pztuIn{0%{opacity:0;transform:translateY(14px) scale(.92)}100%{opacity:1;transform:none}}
@keyframes pztuRing{0%{opacity:.95;transform:scale(1)}100%{opacity:0;transform:scale(1.06)}}
@keyframes pztuFade{from{opacity:0}to{opacity:1}}
`;document.head.appendChild(st)}
