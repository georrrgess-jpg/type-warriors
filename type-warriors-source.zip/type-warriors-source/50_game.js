/* ---------- persistence ---------- */
const KEY='typeWarriorsSave',SKEY='typeWarriorsSettings';
const MAXLV=30,LVK=1.2096,lvx=l=>Math.round(LVK*(l<=1?0:l<=8?(l-1)*(l-1)*220:10780+(l-8)*2000+30*(l-8)*(l-7))),lvl=x=>{let l=1;while(l<MAXLV&&x>=lvx(l+1))l++;return l},rankOf=l=>RK[Math.min(7,(l-1)>>2)],xpPct=x=>{const l=lvl(x);return l>=MAXLV?100:Math.max(0,Math.min(100,(x-lvx(l))/(lvx(l+1)-lvx(l))*100))};
const fresh=()=>({pcr:0,bs:{},sn:{},tips:{},zv:{},name:'Hero',col:0,xp:0,weapon:'rusty',own:{rusty:1},armor:'rags',ownA:{rags:1},crates:0,acr:0,best:0,bestWave:0,bestLv:1,camp:1,stars:{},cbest:{},runs:0,kills:0,bestCombo:0,bestWpm:0,path:'knight',wsel:{},seen:{knight:1},gold:0,scr:0,daily:'',dstreak:0,ach:{},as:{},upg:{},ug:0,us:0,spb:0,pity:0});
let P,ST,S,RS=1,LIVE=[];
function load(src){try{P=Object.assign(fresh(),src||sgLoad())}catch(e){P=fresh()}
 if(!P||typeof P!=='object')P=fresh();if(P.xpv!==3){P.xp=Math.round((P.xp||0)*(P.xpv===2?1.08:LVK));P.xpv=3}P.own=P.own||{rusty:1};P.ownA=P.ownA||{rags:1};if(!WP[P.weapon])P.weapon='rusty';if(!AR[P.armor])P.armor='rags';P.own[P.weapon]=1;P.ownA[P.armor]=1;P.stars=P.stars||{};P.zv=P.zv||{};P.pcr=P.pcr||0;P.hcr=Math.max(0,Math.floor(+P.hcr||0));P.hpity=Math.max(0,Math.floor(+P.hpity||0));P.gyb=P.gyb||{};P.bs=P.bs||{};P.sn=P.sn||{};P.tips=P.tips||{};P.cbest=P.cbest||{};if(typeof P.col!=='number')P.col=0;P.gold=Math.max(0,+P.gold||0);P.scr=Math.max(0,+P.scr||0);P.ach=P.ach||{};P.as=P.as||{};P.upg=P.upg||{};P.ug=+P.ug||0;P.us=+P.us||0;P.spb=+P.spb||0;P.pity=+P.pity||0;P.pres=Math.max(0,Math.min(10,+P.pres||0));P.wxp=P.wxp||{};P.ks=P.ks||{};P.pb=P.pb||{};for(let i=1;i<=P.pres;i++)P.ownA['pr'+i]=1;P.dye=+P.dye||0;if(typeof P.cc!=='string')P.cc='';P.wsel=P.wsel||{};P.seen=P.seen||{knight:1};syncPaths()}
function pathOpen(p){return lvl(P.xp)>=PATHS[p].lv}
function syncPaths(){if(!PATHS[P.path]||!pathOpen(P.path))P.path='knight';for(const p of PK)if(pathOpen(p))P.own[PATHS[p].st]=1;if(!WP[P.weapon]||WP[P.weapon].p!==P.path||!P.own[P.weapon])P.weapon=P.wsel[P.path]&&P.own[P.wsel[P.path]]?P.wsel[P.path]:PATHS[P.path].st;P.wsel[P.path]=P.weapon}
function setPath(p){if(!pathOpen(p))return;P.path=p;P.weapon=P.wsel[p]&&P.own[P.wsel[p]]?P.wsel[p]:PATHS[p].st;P.wsel[p]=P.weapon;P.seen[p]=1;save()}
function setWeapon(id){P.weapon=id;P.path=WP[id].p;P.wsel[P.path]=id;save()}
function save(){if(SGS.lock||SGS.stale)return;try{const s=JSON.stringify(P);SGS.last=s;if(sgPut(KEY,s)){SGS.saved=Date.now();SGS.fail=0}else SGS.fail++;sgTick()}catch(e){}}
const defST={cine:true,touch:'auto',size:'fit',res:'auto',mvol:.6,svol:.7,mute:false,shake:true,flash:true,fps:false};
function loadST(){try{ST=Object.assign({},defST,JSON.parse(sgGet(SKEY)||'{}'))}catch(e){ST=Object.assign({},defST)}}
function saveST(){try{sgPut(SKEY,JSON.stringify(ST))}catch(e){}}
loadST();
load();
const U=id=>{if(DCN||S.dc)return 0;const r=(P.upg&&P.upg[id])||0;return typeof NM!=='undefined'&&NM[id]?Math.min(r,NM[id].max):r};
function vocab(w){if(S&&S.bg)return;const z=WZ.get(w);if(z===undefined)return;const a=P.zv[z]||(P.zv[z]=[]);if(!a.includes(w)){a.push(w);if(a.length===ZW[z].length){setTimeout(()=>{try{achCheck()}catch(e){}},0)}}}
function stat(k,v,m){if(S&&S.bg)return;const a=P.as;if(m==='add')a[k]=(a[k]||0)+v;else if(m==='set')a[k]=v;else if(v>(a[k]||0))a[k]=v}
const WCOL=()=>{const r=RKM[WP[P.weapon].r];return r>=5?hsx(S.t*140,100,68):r===4?hsx(45,100,61+9*Math.sin(S.t*3)):WP[P.weapon].col};/* Legendary: a slow gold shimmer. Rainbow is kept for Mythic. */
const SHC=n=>n>=2?{s:'#f2c8ff',g:'#c05cff',f:'#c05cff2a',b:'#e3a6ff'}:{s:'#bff4ff',g:'#7fdcff',f:'#7fdcff22',b:'#9fe8ff'};/* shield tint: icy blue for one shield, violet for two */

/* ---------- state ---------- */
function reset(){S={mode:'title',view:'menu',bgz:0,t:0,cr:[],pj:[],en:[],dy:[],ps:[],fl:[],tgt:null,ban:null,cr2:null,
 runCr:0,runAr:0,inv:0,pcd:0,hurt:0,rr:1,kills:0,sc:1,wave:0,round:1,d:0,hp:3,max:3,shield:0,score:0,combo:0,maxCombo:0,fury:0,furyMul:1,slow:1,cq:0,cl:0,rev:0,
 spawnLeft:0,spawnT:0,shake:0,lunge:0,chars:0,ok:0,flash:0,tt:0,wpm:0,dmgTaken:0,camp:0,back:null,fps:60,gold:0,gp:0,runC:0,mev:0,crit:0,cast:0,mk:0,fg:0,chain:0,vamp:0,regen:0,thund:0,moon:0,revFull:0,tk:{},gc:{},bl:[],bn:0,rt:0,endT:0,chips:[],shots:[],mk:0,pop:0,fx:[],dn:[],sl:[],pose:null,poseT:0,late:null,lateAt:0,landed:0,fm:100,keep:.5,qm:0,gm:1,invT:.75,vm:3.2,pcdT:.55,pf:7,cw:0,slowE:1,flaw:0}}
reset();
const mult=()=>Math.min(10,1+Math.floor(S.combo/Math.max(S.qm?3:4,10-2*S.cq-S.qm)));
const speedMul=()=>S.prac?S.prac.spd:(1+1.1*(1-Math.exp(-S.d/28)))*(S.rift?RFT.spd:1)*(S.dcSpd||1)*(S.camp>=28?.58:S.camp>=27?.72:S.camp>=20?.84:S.camp>=11?.9:1)*(S.camp>=7?.93:1)*(S.camp>30?astDiff()/*ASTRAL*/:1);
function burst(x,y,c,n=18,o){o=o||{};for(let i=0;i<n;i++){const a=Math.random()*TAU,v=(o.v||260)*(.3+Math.random());S.ps.push({x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v-(o.up||120),l:o.l||.8,ml:o.l||.8,c,s:o.s||5,g:o.g===undefined?800:o.g})}}
function float(x,y,txt,c='#ffc94a',sz){S.fl.push({x,y,t:1.1,txt,c,sz:sz||30})}
const zi0=()=>zoneIdx(S.wave||1);

/* ---------- layout / settings ---------- */
function applyLayout(){const vw=innerWidth,vh=innerHeight,tm=TM();document.body.classList.toggle('tm',tm);
 let ah=vh,on=false;
 if(tm){on=kbWant();if(on)ah=vh-kbH(vw,vh);touchLayout(vw,vh,ah,on);inp.setAttribute('inputmode','none')}else{touchOff();inp.removeAttribute('inputmode')}
 let k=Math.min(vw/W,ah/H);if(!tm&&ST.size!=='fit')k=Math.min(k,+ST.size);
 if(tm)wrap.style.top=(ah/2)+'px';
 wrap.style.transform=`translate(-50%,-50%) scale(${k})`;const dpr=window.devicePixelRatio||1;
 RS=ST.res==='auto'?Math.max(1,Math.min(2.5,k*dpr)):+ST.res;RS=Math.round(RS*4)/4;
 const nw=Math.round(W*RS),nh=Math.round(H*RS);if(cv.width!==nw||cv.height!==nh){cv.width=nw;cv.height=nh}}
/* Fullscreen that also works when the game is embedded in an iframe. A page inside an iframe may only go fullscreen if the embedding page allows it (allow="fullscreen"). When that is missing, explain it and offer the next best thing instead of doing nothing. */
const fsOn=()=>document.fullscreenElement||document.webkitFullscreenElement||null;
const inFrame=()=>{try{return window.self!==window.top}catch(e){return true}};
function toggleFS(){const d=document,el=d.documentElement;
 try{if(fsOn()){const ex=d.exitFullscreen||d.webkitExitFullscreen;if(ex){const p=ex.call(d);if(p&&p.catch)p.catch(()=>{})}return}
  const rq=el.requestFullscreen||el.webkitRequestFullscreen||el.msRequestFullscreen,en=d.fullscreenEnabled!==undefined?d.fullscreenEnabled:d.webkitFullscreenEnabled;
  if(!rq||en===false){fsFallback();return}
  const p=rq.call(el,{navigationUI:'hide'});if(p&&p.catch)p.catch(()=>fsFallback())}catch(e){fsFallback()}}
function fsFallback(){
 try{if(inFrame())parent.postMessage({type:'type-warriors-fullscreen'},'*')}catch(e){}
 const url=(()=>{try{const h=location.href;return /^(https?|file):/.test(h)?h:''}catch(e){return ''}})(),emb=inFrame();
 let m=document.getElementById('fsmsg');if(m)m.remove();m=document.createElement('div');m.id='fsmsg';
 m.innerHTML=`<b>Fullscreen is blocked here</b><p>${emb?'This website does not let the game go fullscreen. Use your browser\'s own full screen instead (F11 on Windows, Ctrl+Cmd+F on Mac).':'This browser does not allow fullscreen for this page.'}${url&&emb?' You can also open the game in a new tab, but that tab keeps a separate save from this page, and some browsers cannot save there at all, so unfinished runs may not be kept.':url?' Open the game in its own tab to play fullscreen there.':''}</p><div class="row">${url?`<button class="sm${emb?'':' gd'}" id="fso">${emb?'Open in new tab anyway':'Open in new tab'}</button>`:''}<button class="sm${emb?' gd':''}" id="fsx">${emb?'Got it':'Close'}</button></div>`;
 document.body.appendChild(m);const kill=()=>{if(m.isConnected)m.remove()};$('fsx').onclick=kill;if($('fso'))$('fso').onclick=()=>{try{window.open(url,'_blank','noopener')}catch(e){}kill()};setTimeout(kill,25000)}

/* ---------- run flow ---------- */
function start(n,kind){reset();S.camp=n||0;if(S.camp){S.wave=(S.camp-1)*5;S.bgz=S.camp}const w=WP[P.weapon],a=AR[P.armor];
 const pa=PATHS[P.path];S.sc=(w.sc||1)*(a.sc||1)*(pa.sc||1)*(1+.1*(P.pres||0));S.slow=Math.max(.6,(w.sl||1)*(a.sl||1));S.furyMul=(w.fu||1)*(pa.fu||1);S.cq=w.cq||0;S.max=3+(a.hp||0);S.hp=S.max;S.shield=(a.sh||0)+(pa.sh||0);S.fg=pa.fg||0;S.chain=0;S.mev=pa.ev||0;S.crit=(pa.cr||0)+(w.cr||0);S.chain=w.ch||0;
 S.max+=U('hardy')+(P.pres>=5?1:0);S.hp=S.max;S.shield+=U('iron')+(P.pres>=3?1:0);S.rev=U('wind')?1:0;S.fg+=U('forgive');S.qm=U('qmul');S.keep=.5+.05*U('keeper');S.slowE=1-.02*U('calm');S.furyMul*=1+.05*U('kind');S.fm=100+25*U('vessel');S.pcdT=.55-.06*U('parry');S.pf=7+3*U('parry');S.vm=3.2+.3*U('breaker');S.cl+=.004*U('lucky');S.gm=1+.04*U('prosp')+.05*(P.pres||0);S.flaw=U('flaw');S.invT=.75+.2*U('will');
 S.gm+=w.gm||0;applyMastery();S.gs=1;S.gsA=1;S.gsT=0;S.gsW=0;S.wpn=P.weapon;S.mode='play';hide();if(kind)modeSetup(kind);startWave();if(kind)modeAfter(kind)}
function startWave(){S.wave++;S.round=(S.wave-1)%5+1;const boss=S.round===5,z=lvDef(S.wave),md=z.mod;S.rt=0;
 S.d=S.camp?(S.camp<=10?(S.camp-1)*3:S.camp<=19?27+(S.camp-10)*1.8:(S.camp>=28?37:S.camp>=27?43.4+(S.camp-27)*.3:43.2+(S.camp-19)*.7))+(S.round-1)*(S.camp>=27?.4:.6):S.wave-1;
 let sl=S.camp?Math.min(S.camp>=28?11:S.camp>=27?14:18,4+S.round*2+(S.camp>=28?4:S.camp>=27?7:S.camp/3|0)):Math.min(17,4+lvOf(S.wave)*2+S.round);if(S.camp>=13)sl=Math.max(4,Math.round(sl*Math.max(.8,.9-.0075*(S.camp-13))));if(md==='swarm'||md==='finale')sl=Math.min(20,Math.round(sl*1.45));if(md==='giants')sl=Math.max(3,Math.round(sl*.6));if(S.bg)sl=Math.max(3,Math.round(sl*BG_FEW));S.spawnLeft=boss?4:sl;S.spawnT=1.2;
 S.ban={t:2.8,txt:S.round===1?`Level ${lvOf(S.wave)}: ${z.n}`:boss?'Boss round':`Round ${S.round} of 5`,c:boss?'#ff5c6c':'#ffc94a',sub:S.round===1?(md?MODS[md].n+': '+MODS[md].d:ACTS[Math.min(4,(lvOf(S.wave)-1)/6|0)]):boss?'Boss: '+z.bn:''};S.ban.t=S.round===1&&md?3.6:2.8;
 if(S.regen&&S.shield<4){S.shield++}if(S.thund)S.fury=100;if(U('berserk'))S.fury=Math.max(S.fury,20);
 if(S.dc)dcWave();S.mode='play';jingle(boss?'boss':'wave')}
function spawn(){const zi=zoneIdx(S.wave),z=lvDef(S.wave),md=z.mod,boss=S.round===5&&S.spawnLeft===1;let role=0,id;
 if(boss)id=z.b;else{const r=Math.random();role=S.round===1?(r<.55?0:1):(r<.4?0:r<.75?1:2);if(md==='giants')role=2;{const pool=(S.camp>30?AST_MOBS/*ASTRAL*/:S.gy?GY_MOBS:ZR[zi])[role],q=Math.random();id=q<.4?z.m[role]:q<.75?pool[(lvOf(S.wave)+role)%pool.length]:pool[Math.random()*pool.length|0]}if(S.rift||S.prac){id=modeMon(role);role=modeRole(id,role)}if(S.dc){const q=dcNext();id=q.id;role=q.role;S.dcq=q}}
 const M=MON[id],e={id,role,boss:!!boss,i:0,x:W+(boss?220:110),ph:Math.random()*6,fl:0,lg:0,slip:0,y:GY,h:M.h,el:false,rg:false,hv:0};
 if(boss){const tier=((lvOf(S.wave)-1)/6)|0;e.tier=tier;e.h=M.h*(1+Math.min(.12,tier*.03));e.phs=Math.max(3,Math.min(6,3+tier)-(S.camp>=27?3:S.camp>=20?2:S.camp>=11?1:0));e.state='enter';e.sp=M.sp*K;e.used=[];e.hue=z.hue;e.nm=['','Elder ','Ancient ','Cursed ','Eternal ','Mythic '][Math.min(5,((lvOf(S.wave)-1)/30)|0)]+z.bn;e.w='';e.tm=99;e.tmax=99;e.d0=S.dmgTaken;e.ak=4.2;e.q=[];e.tel=null;{const h=[...id].reduce((a,c)=>a+c.charCodeAt(0),0);e.pat=tier<1?['volley','summon']:tier<2?['volley','slam','summon']:tier<3?['slam','volley','rain','summon']:['rain','volley','slam','summon','volley'];bossSig(e,tier,id);e.pk=((h%e.pat.length)+e.pat.length-1)%e.pat.length}S.ban={t:2.8,txt:e.nm,c:'#ff5c6c',sub:'Type the sentence. Press SPACE when it is weak.'};jingle('boss')}
 else{e.sp=M.sp*K*(.94+Math.random()*.12);e.w=S.dc?S.dcq.w:(S.rift||S.prac)?modeWord(role,id):pickWord(role,zi,S.d,S.en.map(q=>q.w));e.el=S.dc?!!S.dcq.el:md==='elite'?Math.random()<.34:S.d>=4&&Math.random()<.12;if(e.el)e.h*=1.12;e.rg=S.dc?!!S.dcq.rg:role===0&&!!M.pj&&(md==='ranged'?Math.random()<.7:md==='finale'?Math.random()<.5:S.d>=2&&Math.random()<(M.rgp||.32));if(M.fly)e.hv=50+Math.random()*80;if(M.tr)initTr(e,M);if(S.prac)modeInit(e,M)}
 S.en.push(e);S.spawnLeft--;if(!S.prac&&!S.bg)P.sn[id]=1;if(!boss&&!S.prac&&!S.dc&&!S.bg)rbRoll(e,M);if(M.tr&&!S.prac&&!P.tips[M.tr]&&!boss){P.tips[M.tr]=1;S.tip={t:4.2,txt:M.n+': '+TRD[M.tr]}}
 if(!boss&&!S.dc&&!S.bg&&S.d>=5&&S.spawnLeft>1&&S.en.length<(S.rift?riftMax()-1:8)&&Math.random()<Math.min(.3,.08+S.d*.006)){const b=S.en[S.en.length-1];spawn();const c2=S.en[S.en.length-1];c2.x=b.x+110+Math.random()*60}}
function newBossLine(e,msg){e.w=S.dc?dcBossLine():bossLine(lvDef(S.wave),e.tier,e.used);e.used.push(e.w);e.tel=null;e.q=[];e.i=0;e.slip=0;e.vul=0;e.tmax=(S.camp>=28?1.65:S.camp>=27?1.3:1)*(S.camp>=7?1.08:1)*1.25*(6+e.w.length/(2.6+Math.min(2,S.d*.03)));e.tm=e.tmax;if(msg)float(e.x-30,GY-e.h-30,msg,'#ff5c6c')}
function drop(e,kk){S.cr.push({x:e.x,y:e.y-e.h*.6,vy:-260,k:kk||(()=>{const q=Math.random();return e.boss?(q<.5?'a':q<.85?'w':'s'):(q<.4?'a':q<.95?'w':'s')})()})}
const CN={w:'crates',a:'acr',s:'scr',p:'pcr',h:'hcr'},CT={w:'Weapon crate added!',a:'Armor crate added!',s:'SPECIAL crate added!',p:'Eclipse Chest added!',h:'Graveyard Crate added!'};
const EGK=.9,EGK_GY=1.5;/* Endless gold multiplier (cut from 1.5 in 8.3); the Graveyard keeps its old base */
function gain(n){if(S.prac||S.dc)return;n=Math.round((S.camp?n:n*(S.bg?BG_GOLD:(S.gy?EGK_GY*GYK:EGK)))*S.gm);if(n<=0)return;S.gold+=n;P.gold+=n;stat('gold',n,'add');S.gp=.5}
function collect(c){if(c.k==='p')c.k='a';P[CN[c.k]]++;S.runC=(S.runC||0)+1;try{if(!S.prac)btyAdd('crate',1)}catch(x){}save();if(c.k==='h')S.gyH=(S.gyH||0)+1;float(KX,GY-280,CT[c.k],c.k==='h'?'#7affc8':c.k==='s'?'#e08aff':'#ffb02e',34);beep(880,.15,'triangle',.8)}
function roundGold(){const g=(S.camp?10+S.round*3+S.camp*2:14+Math.min(S.wave,60)*3.4)*(1+.25*U('treasure'));gain(g);float(W/2,360,'+'+Math.round((S.camp?g:g*(S.bg?BG_GOLD:S.gy?EGK_GY*GYK:EGK))*S.gm)+' gold','#ffd76a',40);stat('rounds',1,'add');if(U('rec')&&S.wave%3===0&&S.hp<S.max){S.hp++;float(KX,GY-300,'Recovered +1 HP','#7dffb0',34)}achCheck()}
function kill(e,force){S.lunge=1;const m=mult();if(!(e.boss&&e.phs>1)&&!(e.boss&&!force)&&!e.mn&&!S.bg){P.bs[e.id]=(P.bs[e.id]||0)+1;mastKill(e,!force&&!e.bad)}
 if(e.boss&&!force&&e.ward>0){e.ward--;e.fl=.5;S.shake=Math.max(S.shake,12);burst(e.x,GY-e.h*.5,'#9fe8ff',30,{v:400});S.fx.push({k:'ring',x:e.x,y:GY-e.h*.5,t:0,ml:.5,c:'#9fe8ff',w:6,r0:20,r1:240});beep(1000,.1,'triangle',.8);newBossLine(e,'Ward shattered! Type again!');return}
 if(e.boss&&!force){e.vul=S.vm;e.fl=.3;e.slip=0;float(e.x,GY-e.h-30,'PRESS SPACE!','#ffc94a',44);beep(660,.12,'triangle',.7);return}
 if(e.boss&&e.phs>1){e.phs--;const q=Math.round(150*m*S.sc);S.score+=q;burst(e.x,GY-e.h*.5,'#ff8a3a',36,{v:420});float(e.x,GY-e.h-30,'Phase broken! +'+q,'#ff8a3a',36);impactFx(e.x,GY-e.h*.5,true);slashFx(e);S.shake=16;e.fl=.5;e.lg=0;phaseBreakFx(e);if(S.moon&&S.hp<S.max){S.hp++;float(KX,GY-300,'+1 HP','#ff8aa0',34)}newBossLine(e);S.tsT=.16;S.tsS=.12;return}
 if(!force&&!e.boss){if(!e.bad){S.cw++;if(!S.prac)stat('flw',S.cw,'max');if(S.flaw){S.fury=Math.min(S.fm,S.fury+2);S.score+=Math.round(e.w.length*1)}}if(!S.prac){stat('words',1,'add');vocab(e.w)}}
 const crit=!e.boss&&S.crit&&Math.random()<S.crit,pts=Math.round(e.w.length*10*m*(e.boss?3:e.el?2:1)*S.sc*(crit?2:1));S.score+=pts;S.kills++;S.wk=(S.wk||0)+1;S.cast=.3;if(S.rift||S.prac)modeKill(e,pts);
 gain(Math.max(1,Math.round(e.w.length/4))*(e.boss?12:e.el?2:1)*(e.sh&&!e.rb?5:1)+(e.boss?Math.round((30+(e.tier||0)*20)*(1+.25*U('bounty'))):0));if(crit){float(e.x,e.y-e.h-110,'CRIT!','#ff5c8a',44);burst(e.x,e.y-e.h*.5,'#ff5c8a',24,{v:420})}
 const a=lvDef(S.wave).a;burst(e.x,e.y-e.h*.5,e.boss?'#ff8a3a':a,e.boss?80:26,{v:e.boss?520:340});burst(e.x,e.y-e.h*.5,'#ffffff',10,{v:200,s:3});
 dnum(e.x,e.y-e.h-24,'+'+pts,{big:1,crit:!!crit});slashFx(e);impactFx(e.x,e.y-e.h*.5,true);S.dy.push({id:e.id,x:e.x,y:e.y,h:e.h,t:0,boss:e.boss,ph:e.ph,el:e.el,hue:e.hue,sh:e.sh,rb:e.rb});
 S.en=S.en.filter(x=>x!==e);if(S.tgt===e)S.tgt=null;S.shake=e.boss?26:7;if(e.tr&&!e.boss)deathTrait(e);
 if(e.sh&&!S.dc&&!S.prac){const fl=!force&&!e.bad;if(fl||Math.random()<.4)drop(e,mbShinyDrop(e,fl))}
 if(!S.dc&&((e.boss&&Math.random()<.84)||(Math.random()<((e.el?.12:.025)+S.cl)*1.2*(S.rift?RFT.crK:1)&&(!S.rift||(S.runCd=(S.runCd||0)+1)<=RFT.crMax))))drop(e);
 if(S.gy)gyDrop(e);
 if(S.vamp&&S.kills%10===0&&S.hp<S.max){S.hp++;float(KX,GY-300,'+1 HP','#ff8aa0',34)}
 if(!e.boss&&!S.inChain&&((S.chain&&Math.random()<S.chain)||(S.mev&&++S.mk>=S.mev&&!(S.mk=0)))){const o=S.en.filter(q=>!q.boss&&q.x<W-20).sort((a,b)=>a.x-b.x)[0];if(o){S.inChain=1;float(o.x,o.y-o.h-70,'Chain!','#c86bff',34);S.shots.push({x:e.x,y:e.y-e.h*.5,tx:o.x,ty:o.y-o.h*.5,u:0,k:'chain'});kill(o,true);S.inChain=0}}
 if(e.boss){S.pose='victory';S.poseT=0;stat('boss',1,'add');if(S.dmgTaken===e.d0)stat('bnh',1,'add');S.pj=[];S.bk=[];S.blind=0;for(const q of S.en.filter(x=>x.mn))burst(q.x,GY-60,'#c86bff',20);S.en=S.en.filter(x=>!x.mn);S.hp=Math.min(S.max,S.hp+1);S.ban={t:2.4,txt:'Boss slain',c:'#7dffb0'};S.tsT=1.1;S.tsS=.3;S.flash=Math.max(S.flash,.5);beep(90,.6,'sawtooth',1);jingle('win')}else beep(520+m*40,.12,'triangle',.7);try{btyKill(e,force)}catch(x){}achCheck()}
function dmg(d){if(S.rift||S.prac)return modeDmg(d);if(S.inv>0||S.mode!=='play')return;S.inv=S.invT;S.hurt=.55;S.combo=Math.floor(S.combo*S.keep);S.shake=18;burst(KX+30,GY-100,'#e8455a',18,{v:300});
 if(S.shield>0){S.shield--;float(KX,GY-260,'Blocked!','#7fd8ff');beep(300,.15,'triangle',.7)}
 else{S.hp-=d;S.dmgTaken+=d;float(KX,GY-260,'-'+d,'#ff5c6c',40);beep(70,.3,'sawtooth',1);if(S.hp<=0){if(S.rev>0){S.rev--;S.hp=S.revFull?S.max:2;S.revFull=0;S.shield=Math.max(S.shield,1);float(KX,GY-300,S.hp===S.max&&S.max>2?'Reborn!':'Second wind!','#7dffb0',44);burst(KX,GY-120,'#ffd76a',50,{v:500})}else{S.hp=0;over()}}}}
function hit(e){S.en=S.en.filter(x=>x!==e);if(S.tgt===e)S.tgt=null;S.dy.push({id:e.id,x:e.x,y:e.y,h:e.h,t:0,ph:e.ph,el:e.el,hit:1});S.by=(MON[e.id]||{}).n;if(e.tr==='bomb'){burst(KX+30,GY-100,'#ff8a2a',30,{v:420});S.fx.push({k:'ring',x:KX+30,y:GY-100,t:0,ml:.5,c:'#ff8a2a',w:8,r0:10,r1:200});S.shake=26;dmg(2)}else dmg(1)}
function fury(){if(S.mode!=='play')return;if(S.cine){if(S.cine.t>.5)S.cine.skip=1;return}if(S.fury<100)return;S.fury=Math.max(0,S.fury-100);S.flash=1;S.shake=26;S.lunge=1;const k0=S.kills;
 S.inChain=1;for(const e of [...S.en]){if(!S.en.includes(e))continue;if(!e.boss)kill(e,true);else if(e.phs>1)kill(e,true);else if(!(e.vul>0)){e.vul=S.vm;e.fl=.4;float(e.x,GY-e.h-30,'Finish it: SPACE!','#ffc94a',40)}}
 S.inChain=0;stat('fury',1,'add');stat('fk',S.kills-k0,'max');achCheck();float(W/2,300,'FURY STRIKE!','#fff',64);beep(160,.4,'sawtooth',1);jingle('fury')}

/* ---------- boss attacks ---------- */
function mkMinion(e){const z=lvDef(S.wave),zi=zoneIdx(S.wave),pl=ZR[zi][0].filter(x=>MON[x].tr!=='summon'),id=pl[Math.random()*pl.length|0],M=MON[id];
 const m={id,role:0,boss:false,i:0,x:Math.min(W-60,e.x-100),ph:Math.random()*6,fl:.25,lg:0,slip:0,y:GY,h:M.h,el:false,rg:false,hv:0,sp:M.sp*K,w:pickWord(0,zi,S.d,S.en.map(q=>q.w)),mn:1};
 if(M.fly)m.hv=50+Math.random()*80;if(M.tr)initTr(m,M);S.en.push(m);burst(m.x,GY-60,'#c86bff',16)}
function bossAtk(e,dt){
 if(e.ds){lungeStep(e,dt);return}
 for(const it of e.q){it.t-=dt;if(it.t<=0){it.done=1;const col=e.col;
  if(it.k==='orb')S.pj.push({x:e.x-70,y:e.y-e.h*.5+(Math.random()-.5)*50,v:it.v,k:'orb',c:col,b:1});
  else if(it.k==='wave'){S.pj.push({x:e.x-90,y:GY-6,v:it.v,k:'wave',c:col,b:1});S.shake=Math.max(S.shake,12);beep(90,.3,'sawtooth',.8)}
  else if(it.k==='meteor'){const x=KX+520+Math.random()*260,y=-50,tt=(x-KX-70)/it.v;S.pj.push({x,y,v:it.v,vy:(GY-118-y)/tt,k:'meteor',c:col,b:1})}
  else if(it.k==='minion'){mkMinion(e);beep(300,.15,'triangle',.6)}
  if(it.k==='orb'){e.lg=.6;beep(420,.12,'sawtooth',.6)}}}
 e.q=e.q.filter(x=>!x.done);
 if(e.tel){e.tel.t-=dt;e.fl=Math.max(e.fl,Math.floor(S.t*14)%2?.05:0);if(e.tel.t<=0){const k=e.tel.k;e.tel=null;bossFire(e,k)}return}
 if(e.tm<2.6)return;
 e.ak-=dt;if(e.ak>0)return;
 if(S.pj.length>2||e.q.length||(S.bk&&S.bk.length)){e.ak=.6;return}
 const k=e.pat[e.pk=(e.pk+1)%e.pat.length];{const d=k==='summon'?1.2:1.4;e.tel={k,t:d,d}}
 e.ak=Math.max(4.8,1.4*(5.4-e.tier*.35)*(e.phs<=1?.78:1)*(S.camp>=28?2.3:S.camp>=27?1.75:S.camp>=20?1.35:S.camp>=11?1.18:1)*(.85+Math.random()*.3));
 e.col=lvDef(S.wave).a;S.shake=Math.max(S.shake,6);beep(200,.3,'sawtooth',.7)}
function bossFire(e,k){e.col=e.col||lvDef(S.wave).a;const hard=S.camp>=28?-2:S.camp>=20?-1:0,n=Math.max(2,2+(e.tier>=2?1:0)+(e.phs<=1?1:0)+hard),v=250+e.tier*14;e.lg=.8;S.shake=Math.max(S.shake,10);
 if(k==='volley')for(let i=0;i<n;i++)e.q.push({t:i*1.05,k:'orb',v});
 else if(k==='slam'){e.q.push({t:0,k:'wave',v:v+30});if(e.phs<=1)e.q.push({t:1.4,k:'wave',v:v+30})}
 else if(k==='rain')for(let i=0;i<n;i++)e.q.push({t:i*1,k:'meteor',v:v-20});
 else if(k==='barrage')for(let i=0;i<4;i++)e.q.push({t:i*.62,k:'orb',v:v+40});
 else if(k==='tremor')for(let i=0;i<3;i++)e.q.push({t:i*.9,k:'wave',v:v+55});
 else if(k==='blind'){S.blind=5.5;float(W/2,340,'Darkness falls!','#b8a0ff',48);beep(120,.5,'sawtooth',.7)}
 else if(k==='ward'){if(!e.ward){e.ward=1;float(e.x-60,GY-e.h-20,'Ward raised!','#9fe8ff',38);beep(700,.3,'triangle',.7)}}
 else if(k==='bolt'){S.bk=S.bk||[];const nb=e.tier>=2?3:2;for(let i=0;i<nb;i++)S.bk.push({k:'bolt',t:1+i*.85,t0:1+i*.85})}
 else if(k==='beam'){S.bk=S.bk||[];S.bk.push({k:'beam',t:1.4,t0:1.4})}
 else if(k==='lunge'){e.ds={ph:'in',t:0,x0:e.x};float(e.x-60,GY-e.h-20,'Charging!','#ff9a5a',38)}
 else if(k==='summon'){float(e.x-60,GY-e.h-20,'Minions!','#c86bff',38);for(let i=0;i<(e.tier>=2?3:2);i++)e.q.push({t:i*.5,k:'minion'})}}

/* ---------- input ---------- */
function spaceAct(){
 const vb=S.en.find(e=>e.boss&&e.vul>0);
 if(vb){if(S.pcd>0)return true;S.pcd=.3;S.lunge=1;vb.vul=0;kill(vb,true);return true}
 {const ld=S.en.find(q=>q.boss&&q.ds&&q.ds.ph==='in');if(ld){if(S.pcd>0)return true;S.pcd=S.pcdT;stat('parry',1,'add');S.lunge=1;ld.ds.ph='back';ld.ds.t=0;ld.fl=.6;S.fury=Math.min(S.fm,S.fury+S.pf+8);S.score+=250;float(ld.x,GY-ld.h*.6,'Parried the lunge! +250','#7fd8ff',40);burst(ld.x-40,GY-ld.h*.4,'#7fd8ff',36,{v:460});S.fx.push({k:'ring',x:ld.x-40,y:GY-ld.h*.4,t:0,ml:.45,c:'#7fd8ff',w:8,r0:10,r1:200});S.shake=16;beep(1200,.2,'triangle',.9);return true}
 const sk=S.bk&&S.bk.find(q=>q.t<.65);if(sk){if(S.pcd>0)return true;S.pcd=S.pcdT;stat('parry',1,'add');S.lunge=.8;S.bk=S.bk.filter(q=>q!==sk);S.fury=Math.min(S.fm,S.fury+S.pf);S.score+=100;float(KX+40,GY-260,'Deflected!','#7fd8ff',36);burst(KX+40,GY-120,'#7fd8ff',24,{v:400});S.fx.push({k:'ring',x:KX+40,y:GY-120,t:0,ml:.4,c:'#7fd8ff',w:6,r0:10,r1:150});beep(1100,.1,'triangle',.9);return true}}
 const j=S.pj.find(q=>q.x<KX+420),b=S.en.find(e=>e.boss&&e.state==='fight'&&e.tm<2.2&&!(e.vul>0));
 if(j||b){if(S.pcd>0)return true;S.pcd=S.pcdT;stat('parry',1,'add');S.lunge=.7;
  if(j){S.pj=S.pj.filter(q=>q!==j);S.fury=Math.min(S.fm,S.fury+S.pf);S.score+=50;float(j.x,j.y-40,'Parried!','#7fd8ff');burst(j.x,j.y,'#7fd8ff',16);beep(1000,.1,'triangle',.8)}
  else{b.tm=b.tmax;b.fl=.5;S.fury=Math.min(S.fm,S.fury+12+S.pf-7);S.score+=200;float(b.x-40,GY-b.h*.6,'Parried! +200','#7fd8ff',40);burst(b.x-60,GY-b.h*.45,'#7fd8ff',30,{v:400});S.shake=12;beep(1200,.2,'triangle',.9)}
  return true}
 return false}
function key(c){if(S.mode!=='play'||!c)return;if(S.cine){if(S.cine.t>.5)S.cine.skip=1;return}c=String(c).toLowerCase();if(c===' '&&spaceAct())return;if(!/^[a-z ]$/.test(c))return;
 if(!S.tgt||(S.tgt.i===0&&S.tgt.w[0]!==c)){let b=null;for(const e of S.en)if(e.x<W-10&&!(e.vul>0)&&e.w[0]===c&&(!b||e.x<b.x))b=e;if(b)S.tgt=b}
 const t=S.tgt;
 if(c===' '&&(!t||t.w[t.i]!==' ')){return}
 if(!t){beep(150,.04,'triangle',.3);return}
 if(t.vul>0)return;S.chars++;ksLog(t.w[t.i],c);
 if(t.w[t.i]===c){t.i++;S.ok++;if(P.bty&&P.bty.trail)btyTrail(t,c);S.combo++;if(S.combo>S.maxCombo){S.maxCombo=S.combo;if(S.combo%25===0||S.combo===10){if(!S.prac){stat('combo',S.combo,'max');achCheck()}}}S.fury=Math.min(S.fm,S.fury+.7*S.furyMul);t.fl=.08;burst(t.x,t.y-t.h*.5,WP[P.weapon].col,3,{v:160,s:4});impactFx(t.x,t.y-t.h*.5,false);dnum(t.x+(Math.random()-.5)*44,t.y-t.h*.55,''+Math.round(10*mult()*S.sc),{});if(P.path==='rogue')S.shots.push({x:KX+70,y:GY-118,tx:t.x,ty:t.y-t.h*.5,u:0,k:'rogue'});const MS={10:'Sharp!',25:'On fire!',50:'Unstoppable!',100:'LEGENDARY!',200:'MYTHIC!'};if(MS[S.combo]){float(W/2,330,MS[S.combo],'#ffd76a',54);S.flash=Math.max(S.flash,.25);beep(1000,.2,'triangle',.9)}beep(700+Math.min(S.combo,30)*15,.04);if(t.i>=t.w.length){if(t.shd>0){shieldBreak(t);return}if(P.path==='archer')S.shots.push({x:KX+70,y:GY-130,tx:t.x,ty:t.y-t.h*.5,u:0,k:'archer'});else if(P.path==='mage')S.shots.push({x:KX+90,y:GY-190,tx:t.x,ty:t.y-t.h*.5,u:0,k:'mage'});kill(t)}}
 else if(t.slip<1+S.fg){t.slip++;t.bad=1;S.cw=0;float(t.x,t.y-t.h-60,'Slip forgiven','#9fe8ff',24);beep(260,.06,'triangle',.6)}
 else{t.bad=1;S.cw=0;S.combo=Math.floor(S.combo*S.keep);S.fury=Math.max(0,S.fury-5);S.shake=Math.max(S.shake,4);beep(110,.08,'sawtooth',.6)}}

/* ---------- update ---------- */
function update(dt){
 if(S.mode==='pause')return;
 if(S.cine){cineTick(dt);return}
 if(S.tsT>0){S.tsT-=dt;dt*=S.tsS}
 S.t+=dt;S.fps+=(1/Math.max(dt,.001)-S.fps)*.05;
 for(const p of S.ps){p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=p.g*dt;p.l-=dt}S.ps=S.ps.filter(p=>p.l>0);
 for(const f of S.fl){f.y-=44*dt;f.t-=dt}S.fl=S.fl.filter(f=>f.t>0);
 for(const q of S.fx)q.t+=dt;S.fx=S.fx.filter(q=>q.t<q.ml);for(const q of S.sl)q.t+=dt;S.sl=S.sl.filter(q=>q.t<q.ml);for(const q of S.dn){q.t+=dt;q.x+=q.vx*dt;q.y+=q.vy*dt;q.vy+=q.g*dt}S.dn=S.dn.filter(q=>q.t<q.ml);
 if(S.pose){S.poseT+=dt;if(S.pose==='victory'&&S.mode!=='over'&&S.poseT>2.3)S.pose=null;if(S.pose==='dead'&&!S.landed&&S.poseT>1.3){S.landed=1;burst(KX+240,GY-8,'#bfa88a',34,{v:320,l:.9,g:500});S.shake=16;beep(60,.45,'sawtooth',.9);burst(KX+60,GY-120,'#bfe8ff',14,{v:60,l:1.6,g:-90,s:4,up:0})}if(S.late&&S.poseT>=S.lateAt){const f=S.late;S.late=null;f()}}
 for(const d of S.dy)d.t+=dt;S.dy=S.dy.filter(d=>d.t<(d.boss?1:.5));
 S.shake=Math.max(0,S.shake-46*dt);S.lunge=Math.max(0,S.lunge-4*dt);S.flash=Math.max(0,S.flash-2*dt);S.hurt=Math.max(0,S.hurt-dt);S.inv=Math.max(0,S.inv-dt);S.pcd=Math.max(0,S.pcd-dt);
 pb.style.display=(S.mode==='play'||S.mode==='pause')?'':'none';pb.textContent=S.mode==='pause'?'Resume':'Pause';spUI();
 if(S.mode==='crate'){crateUpdate(dt);return}
 if(S.mode!=='play')return;
 S.cast=Math.max(0,S.cast-dt);S.gp=Math.max(0,S.gp-dt);
 wpmStep(dt);
 for(const q of S.shots)q.u+=dt*(q.k==='chain'?5:q.k==='archer'?9:7);S.shots=S.shots.filter(q=>q.u<1);
 if(S.rift||S.prac||S.gy){modeTick(dt);if(S.mode!=='play')return}
 if(S.ban){S.ban.t-=dt;if(S.ban.t<=0)S.ban=null}
 if(!S.ban||S.ban.t<1.6){S.spawnT-=dt;if(S.spawnT<=0&&S.spawnLeft>0&&(!S.prac||S.en.length<S.prac.max)&&(!S.rift||S.en.length<riftMax())){spawn();S.spawnT=Math.max(.85,2.6-1.7*(1-Math.exp(-S.d/30)))*(S.camp>=28?1.8:S.camp>=27?1.4:S.camp>=20?1.15:1)*(.75+Math.random()*.5)*spawnK()*(S.camp>=7?1.07:1)*(lvDef(S.wave).mod==='swarm'||lvDef(S.wave).mod==='finale'?.7:lvDef(S.wave).mod==='giants'?1.4:1)}}
 S.rt+=S.ban?0:dt;const md=lvDef(S.wave).mod,spd=speedMul()*(md==='swarm'?.93:md==='giants'?.82:md==='gusts'?.72+1.15*Math.pow(Math.max(0,Math.sin(S.t*.9)),3):md==='frenzy'||md==='finale'?1+Math.min(.45,S.rt*.014):1);
 for(const e of [...S.en]){const M=MON[e.id];e.fl=Math.max(0,e.fl-dt);e.lg=Math.max(0,e.lg-dt*2.2);
  if(e.tr&&!e.boss)trait(e,dt);
  if(e.boss){
   if(e.state==='enter'){e.x-=e.sp*dt;if(e.x<=W-340){e.x=W-340;if(ST.cine!==false){cineStart(e);return}e.state='fight';newBossLine(e)}}
   else if(e.vul>0){e.vul-=dt;if(e.vul<=0){e.vul=0;newBossLine(e,'Too slow!')}}
   else{e.tm-=dt;bossAtk(e,dt);if(e.tm<=0){e.lg=1;S.shake=22;float(e.x-80,GY-e.h*.6,'Boss strike!','#ff5c6c',40);S.by=e.nm;dmg(1);if(S.mode!=='play')return;newBossLine(e)}}}
  else if(M.fly||e.role===1){e.x-=e.sp*spd*S.slow*S.slowE*dt*chg(e);if(e.x<KX+60){hit(e);if(S.mode!=='play')return;continue}}
  else{const stop=e.rg?W*.6+(e.ph%1)*90:KX+180+(e.role===2?50:0)+(e.ph%1)*80;
   if(e.x>stop)e.x-=e.sp*spd*S.slow*S.slowE*dt*chg(e);
   else{if(e.at===undefined)e.at=e.rg?1.8:1.5;e.at-=dt;
    if(e.at<=0){if(e.tr==='bomb'){bombBlast(e,1);if(S.mode!=='play')return;continue}e.at=Math.max(1.6,(e.rg?3.2:2.8)-S.d*.03)*(e.role===2?1.3:1);e.lg=1;
     if(e.rg)S.pj.push({x:e.x-30,y:e.y-e.h*.5,v:430*K/2*(1+S.d*.006),k:M.pj,src:M.n});
     else{float(e.x-40,e.y-e.h-70,'Hit!','#ff5c6c',28);S.by=M.n;dmg(1);if(S.mode!=='play')return}}}}
  if(M.fly){const prog=Math.max(0,Math.min(1,1-(e.x-KX)/(W-KX)));e.y=GY-e.hv*(1-prog*.75)+Math.sin(S.t*(e.id==='bat'?5:2.4)+e.ph)*(e.id==='bat'?22:14)}else e.y=GY}
 strikeStep(dt);if(S.mode!=='play')return;if(S.tip){S.tip.t-=dt;if(S.tip.t<=0)S.tip=null}if(S.blind>0)S.blind-=dt;
 for(const c of [...S.cr]){c.vy+=1200*dt;c.y=Math.min(GY-16,c.y+c.vy*dt);if(c.y>=GY-16)c.x-=460*dt;if(c.x<KX+40){S.cr=S.cr.filter(z=>z!==c);collect(c)}}
 for(const j of [...S.pj]){j.x-=j.v*dt;if(j.vy)j.y+=j.vy*dt;if(j.x<KX+70){S.pj=S.pj.filter(q=>q!==j);S.by=j.src||'a boss attack';if(j.k==='web'){S.fury=Math.max(0,S.fury-20);float(KX,GY-300,'Webbed! -Fury','#e8f4ff',30)}dmg(1);if(S.mode!=='play')return}}
 if(S.mode==='play'&&!S.ban&&S.spawnLeft===0&&S.en.length===0&&(!S.cr.length||(S.endT=(S.endT||0)+dt)>5)&&!S.dy.some(d=>d.boss)){S.endT=0;if(S.dc){dcRoundEnd();return}roundGold();save();if(S.camp&&S.round===5)victory();else if(!S.camp&&S.bn>=BOONCAP){if(S.round===5)boonSwap();else{S.hp=Math.min(S.max,S.hp+1);float(W/2,300,'Boon limit reached: +1 HP','#7dffb0',44);gain(20);startWave()}}else boons()}}

/* ---------- drawing ---------- */
let PW=13.4;
function pillFont(){ctx.font='bold 24px ui-monospace,Menlo,Consolas,"Courier New",monospace';PW=ctx.measureText('M').width}
function pillGeom(e){pillFont();const w=PW*e.w.length+28,h=42;let x=Math.max(8,Math.min(W-w-8,e.x-w/2)),y=e.y-e.h-(e.boss?110:24)-h;if(e.y<GY)y=Math.max(70,y);return{x,y,w,h}}
function pill(e,tgt,al){const txt=e.w,{x,y,w,h}=pillGeom(e),ra=RKM[WP[P.weapon].r],col=WCOL();
 ctx.save();if(al!==undefined)ctx.globalAlpha=al;if(S.blind>0&&!tgt&&!e.boss)ctx.globalAlpha*=.1;if(S.gy&&gyHas('dark')&&!e.boss&&!tgt&&gyRank(e)>=2)ctx.globalAlpha*=.07;if((lvDef(S.wave).mod==='fog'||gyHas('mist'))&&!e.boss&&!tgt){ctx.globalAlpha=(al===undefined?1:al)*Math.max(.06,Math.min(1,(W*.68-e.x)/260))}ctx.textBaseline='middle';ctx.textAlign='left';
 ctx.shadowColor='#000a';ctx.shadowBlur=10;ctx.fillStyle=tgt?'rgba(38,24,8,.94)':'rgba(6,4,16,.8)';ctx.beginPath();ctx.roundRect(x,y,w,h,11);ctx.fill();ctx.shadowBlur=0;
 if(tgt){ctx.shadowColor=col;ctx.shadowBlur=ra*7;let st=col;if(ra>=5){const q=ctx.createLinearGradient(x,y,x+w,y);for(let i=0;i<=4;i++)q.addColorStop(i/4,`hsl(${(S.t*160+i*70)%360},100%,66%)`);st=q}else if(ra===4){const q=ctx.createLinearGradient(x,y,x+w,y);for(let i=0;i<=4;i++)q.addColorStop(i/4,`hsl(${44+(i%2)*3},100%,${Math.round(56+22*Math.sin(S.t*2.4-i*1.3))}%)`);st=q}ctx.strokeStyle=st;ctx.lineWidth=2+ra*.5;ctx.stroke();ctx.shadowBlur=0;
  if(ra>=3){for(let i=0;i<3+ra;i++){const u=(S.t*.7+i*.31)%1,px=x+((i*97)%100)/100*w,py=y-u*16;ctx.globalAlpha=1-u;ctx.fillStyle=col;ctx.fillRect(px,py,3,3)}ctx.globalAlpha=1}}
 else{ctx.strokeStyle='#ffffff30';ctx.lineWidth=1.5;ctx.stroke()}
 const x0=x+14,cy=y+h/2+1;
 const gyP=S.gy&&!e.boss&&S.gyc&&e.w.length>2,dtx=gyP&&e.rv&&e.dw?e.dw:txt;
 for(let i=0;i<dtx.length;i++){const ch=dtx[i],cx=x0+i*PW;
  if(ch===' '){if(i>=e.i){ctx.fillStyle=tgt&&i===e.i?col:'#ffffff66';ctx.fillRect(cx+PW*.25,cy+6,PW*.5,3)}continue}
  if(gyP){gyPillChar(e,i,ch,cx,cy,col,tgt);continue}
  ctx.fillStyle=i<e.i?col:'#fff';ctx.fillText(ch,cx,cy)}
 if(tgt&&e.i<txt.length){ctx.fillStyle=col;ctx.fillRect(x0+(gyP&&e.rv?txt.length-1-e.i:e.i)*PW,cy+13,PW,3.4)}else if(!tgt){ctx.fillStyle='#ffffff77';ctx.fillRect(x0,cy+13,PW,2.4)}
 ctx.restore();return y}
function drawEnemy(e,al,dead){const M=MON[e.id],sc=e.h/M.th,a=lvDef(S.wave||1).a,ac=e.el?'#ff3b3b':a,cyc=e.y-e.h*.5;
 ctx.save();
 if(!dead){ctx.fillStyle=`rgba(0,0,0,${.35*Math.max(.2,1-(GY-e.y)/260)})`;ctx.beginPath();ctx.ellipse(e.x,GY+6,Math.max(2,e.h*(M.fly?.24:.34)*(1-(GY-e.y)/500)),8,0,0,TAU);ctx.fill()}
 const pu=1+.08*Math.sin(S.t*6+e.ph);glow(ctx,e.x,cyc,e.h*.85*pu,ac+(e.el?'88':e.boss?'66':'40'));if(e.sh&&!dead)glow(ctx,e.x,cyc,e.h*(1.05+.12*Math.sin(S.t*5+e.ph)),e.rb?rbHex(rbHue(e))+'73':'#ffe27a55');if(e.rb&&!dead)glow(ctx,e.x,cyc,e.h*(1.35+.15*Math.sin(S.t*3+e.ph)),rbHex((rbHue(e)+140)%360)+'47');if(e.boss&&!dead)bossAura(e,cyc,ac,1);
 if(e.el)for(let i=0;i<6;i++){const u=(S.t*.9+i/6)%1;ctx.globalAlpha=1-u;ell(ctx,e.x+Math.sin(i*5+S.t)*e.h*.2,e.y-e.h*(.2+u*.8),4*(1-u)+1,7*(1-u)+2,'#ff5a2a');ctx.globalAlpha=1}
 ctx.globalAlpha=al===undefined?1:al;{const mf=monFilter(e,M);if(mf||(e.fl>0&&!dead))ctx.filter=(mf?mf+' ':'')+(e.fl>0&&!dead?'brightness(2.6)':'')}
 ctx.translate(e.x-(e.lg||0)*(e.boss?90:64)+(e.boss&&e.pm&&e.phs<e.pm?Math.sin(S.t*45)*(e.pm-e.phs)/e.pm*2.2:0),e.y);ctx.scale(sc,sc);
 if(dead){{const mf=monFilter(e,M);ctx.filter=(mf?mf+' ':'')+'brightness(3)'}}
 M.d(ctx,S.t+e.ph*3,{lg:e.lg||0,el:e.el});
 ctx.restore();if(e.sh&&!dead)shinyFx(e,cyc);if(e.boss&&!dead){ctx.save();bossAura(e,cyc,ac,0);ctx.restore()}if(!dead&&(e.tr||e.ward))traitDraw(e,cyc,al)}
function shotArt(g,q){const u=q.u,x=lerp(q.x,q.tx,u),y=lerp(q.y,q.ty,u)-Math.sin(u*Math.PI)*(q.k==='archer'?26:q.k==='chain'?50:8),ang=Math.atan2(q.ty-q.y,q.tx-q.x);g.save();g.translate(x,y);
 if(q.k==='archer'){g.rotate(ang+Math.sin(u*Math.PI)*-.12);for(let i=1;i<6;i++){g.globalAlpha=.5/i;ell(g,-i*16,0,14,3,WP[P.weapon].col)}g.globalAlpha=1;glow(g,0,0,54,WP[P.weapon].col+'88');g.strokeStyle='#f4e4b8';g.lineWidth=5;g.beginPath();g.moveTo(-46,0);g.lineTo(24,0);g.stroke();poly(g,[24,-10,50,0,24,10],'#ffffff',WP[P.weapon].col,2);poly(g,[-46,0,-58,-11,-40,0,-58,11],WP[P.weapon].col)}
 else if(q.k==='rogue'){g.rotate(u*18);poly(g,[-10,0,0,-4,12,0,0,4],'#e8eefc',WP[P.weapon].col,1.5);glow(g,0,0,18,WP[P.weapon].col+'66')}
 else{glow(g,0,0,q.k==='chain'?46:30,(q.k==='chain'?'#c86bff':WP[P.weapon].col)+'aa');ell(g,0,0,7,7,'#fff');ell(g,-10,0,5,4,WP[P.weapon].col+'88')}
 g.restore()}
function drawHeroGame(){const ra=RKM[WP[P.weapon].r],col=WCOL(),l=S.lunge,pz=S.pose,pt=S.poseT||0,dead=pz==='dead';let x=KX+l*90,hop=0,rot=0,pu=0,sxx=1,syy=1;
 {const b=Math.sin(S.t*2.3);syy=1+b*.011;sxx=1-b*.006}if(S.hurt>.35)x-=(S.hurt-.35)*70;
 if(pz==='victory'){pu=Math.min(1,pt/.3);hop=-Math.abs(Math.sin(pt*5.5))*24*Math.min(1,pt/.5)}
 else if(dead){pu=Math.min(1,pt/1.2);const k1=Math.min(1,pt/.2),k2=Math.max(0,Math.min(1,(pt-.2)/.5)),k3=Math.max(0,Math.min(1,(pt-.7)/.65));x-=Math.sin(k1*Math.PI)*28;syy*=1-.22*k2*(1-k3*.4);rot=.18*k2+1.32*k3*k3;if(pt>1.35)rot+=Math.sin((pt-1.35)*16)*.04*Math.exp(-(pt-1.35)*6)}
 {const pc=PATHS[P.path].c;ctx.save();ctx.translate(KX,GY+4);ctx.scale(1,.2);ctx.strokeStyle=pc+'aa';ctx.lineWidth=5;ctx.shadowColor=pc;ctx.shadowBlur=14;for(const [r,sp] of[[92,1],[70,-1.4]]){ctx.setLineDash([16,10]);ctx.lineDashOffset=-S.t*30*sp;ctx.beginPath();ctx.arc(0,0,r,0,TAU);ctx.stroke()}ctx.restore()}
 ctx.save();ctx.translate(x,GY);
 ctx.fillStyle='#0007';ctx.beginPath();ctx.ellipse(0,6,74,12,0,0,TAU);ctx.fill();
 if(!dead)glow(ctx,0,-130,150+ra*26,col+(ra?'66':'33'));
 if(ra>2&&!dead)for(let i=0;i<4+ra*2;i++){const a=S.t*(1.5+ra*.3)+i*TAU/(4+ra*2);ctx.fillStyle=col;ctx.beginPath();ctx.arc(Math.cos(a)*88,-130+Math.sin(a)*112,3.4,0,TAU);ctx.fill()}
 if(S.fury>=100&&!dead){ctx.strokeStyle=`hsl(${45+Math.sin(S.t*10)*15},100%,60%)`;ctx.lineWidth=4;ctx.shadowColor='#ffc94a';ctx.shadowBlur=20;ctx.beginPath();ctx.arc(0,-130,112,0,TAU);ctx.stroke();ctx.shadowBlur=0}
 if(S.shield>0&&!dead){ctx.strokeStyle='#7fd8ff';ctx.fillStyle='#7fd8ff14';ctx.lineWidth=4;ctx.beginPath();ctx.arc(0,-130,104,0,TAU);ctx.fill();ctx.stroke()}
 if(S.inv>0&&Math.floor(S.t*20)%2)ctx.globalAlpha=.5;
 if(S.cast>0){glow(ctx,58,-190,150*S.cast/.3+40,PATHS[P.path].c+'99')}ctx.translate(0,hop);ctx.rotate(rot);
 if(dead){const gr=Math.min(.85,Math.max(0,(pt-.5)*.7));if(!HO){HO=document.createElement('canvas');HO.width=HO.height=440}const g2=HO.getContext('2d');g2.setTransform(1,0,0,1,0,0);g2.clearRect(0,0,440,440);g2.translate(220,340);g2.scale(1.95*sxx,1.95*syy);drawHero(g2,{arm:P.armor,wp:P.weapon,col:P.col,t:S.t,lg:l,pose:pz,pu});ctx.filter=`grayscale(${gr}) brightness(${1-gr*.3})`;ctx.drawImage(HO,-220,-340);ctx.filter='none'}
 else{ctx.scale(1.95*sxx,1.95*syy);drawHero(ctx,{arm:P.armor,wp:P.weapon,col:P.col,t:S.t,lg:l,pose:pz,pu})}
 ctx.restore()}
let HO=null;
function heartPath(x,y,full){heart(ctx,x,y,13,full?'#e8455a':'#2a1a2a',full?'#ffb0b8':'#5a3a4a');if(full){ctx.fillStyle='#fff6';ctx.beginPath();ctx.ellipse(x-5,y-6,3,2,-.6,0,TAU);ctx.fill()}}
function drawHUD(){const c=ctx;c.save();c.textBaseline='middle';
 if(S.tip){const a=Math.min(1,S.tip.t,(4.2-S.tip.t)*4);c.save();c.globalAlpha=a;c.font='22px Georgia,serif';const w=c.measureText(S.tip.txt).width+44;c.fillStyle='rgba(8,4,20,.82)';c.strokeStyle='#9fe8ff';c.lineWidth=2;c.beginPath();c.roundRect(W/2-w/2,118,w,44,12);c.fill();c.stroke();c.fillStyle='#e8f8ff';c.textAlign='center';c.fillText(S.tip.txt,W/2,141);c.restore()}
 if(S.rift)riftHUD(c);else if(S.prac)pracHUD(c);else{c.fillStyle='rgba(6,4,16,.55)';c.beginPath();c.roundRect(14,14,S.max*34+26+(P.pres?44:0),52,14);c.fill();
 for(let i=0;i<S.max;i++)heartPath(40+i*34,40,i<S.hp);if(P.pres)prBadge(c,14+S.max*34+52,42,.3,P.pres,S.t)}
 if(S.shield>0){c.fillStyle='#7fd8ff';c.font='26px "Pirata One",Georgia,serif';c.textAlign='left';c.fillText('Shield x'+S.shield,20,88)}
 if(S.rev>0){c.fillStyle='#7dffb0';c.font='22px "Pirata One",Georgia,serif';c.textAlign='left';c.fillText('Second Wind',20,S.shield>0?116:88)}
 {c.font='19px "Pirata One",Georgia,serif';c.textAlign='left';let yy=S.shield>0||S.rev>0?(S.shield>0&&S.rev>0?146:118):96;S.chips=[];if(S.bl.length){c.fillStyle='#b8c4e8';c.fillText(S.camp?'Boons (click to view)':`Boons ${S.bn} of ${BOONCAP} (click to view)`,20,yy);yy+=28}const L=S.bl.slice(-7);if(S.bl.length>7){c.fillStyle='#b8c4e8';c.fillText('+'+(S.bl.length-7)+' more',20,yy);yy+=26}for(const b of L){const lb=b.n+(b.c>1?' x'+b.c:''),tw=c.measureText(lb).width+22;c.fillStyle='rgba(6,4,16,.6)';c.beginPath();c.roundRect(14,yy-12,tw,24,8);c.fill();c.strokeStyle=BC[b.r];c.lineWidth=b.r>2?2.4:1.4;c.stroke();c.fillStyle=BC[b.r];c.fillText(lb,25,yy+1);S.chips.push({x:14,y:yy-12,w:tw,h:24});yy+=29}}
 c.textAlign='right';c.fillStyle='rgba(6,4,16,.55)';c.beginPath();c.roundRect(W-280,14,266,ST.fps?156:132,14);c.fill();
 c.fillStyle='#ffc94a';c.font='44px "Pirata One",Georgia,serif';c.fillText(S.score.toLocaleString(),W-28,40);
 c.fillStyle='#f4ecd8';c.font='22px "Pirata One",Georgia,serif';c.fillText(modeLabel(),W-28,72);
 c.font='20px "Pirata One",Georgia,serif';c.fillStyle='#b8c4e8';c.fillText(`${S.wpm} WPM   ${S.prac?pracAcc()+'% acc':(S.runC||0)+' crates'}`,W-28,96);{const gp=Math.min(1,S.gp*3),tx=W-28,gs=1+gp*.25;c.save();c.translate(tx,120);c.scale(gs,gs);c.fillStyle=gp>0?'#fff3a0':'#ffd76a';c.font='22px "Pirata One",Georgia,serif';c.fillText(S.prac?'no rewards':S.gold.toLocaleString()+' gold',-30,0);if(!S.prac)coin(c,-12,0,10);c.restore()}if(ST.fps){c.fillStyle='#7dffb0';c.fillText(Math.round(S.fps)+' FPS',W-28,146)}
 gyHud(c);c.textAlign='center';const m=mult();
 if(S.combo>1){c.font=(30+m*3)+'px "Pirata One",Georgia,serif';c.fillStyle=m>3?'#ff8a3a':'#fff';c.shadowColor='#000';c.shadowBlur=8;c.fillText(`${S.combo} streak   x${m}`,W/2,(S.rift||S.prac)?112:44);c.shadowBlur=0}
 const bw=440,bx=(W-bw)/2,by=H-64,full=S.fury>=100;
 c.fillStyle='rgba(0,0,0,.65)';c.beginPath();c.roundRect(bx-6,by-6,bw+12,32,12);c.fill();
 const q=c.createLinearGradient(bx,0,bx+bw,0);q.addColorStop(0,full?'#ffb02e':'#8a2436');q.addColorStop(1,full?'#fff3a0':'#e8455a');c.fillStyle=q;c.beginPath();c.roundRect(bx,by,bw*Math.min(100,S.fury)/100,20,8);c.fill();if(S.fury>100){const q2=c.createLinearGradient(bx,0,bx+bw,0);q2.addColorStop(0,'#ffb02e');q2.addColorStop(1,'#fff3a0');c.fillStyle=q2;c.beginPath();c.roundRect(bx,by+20,bw*(S.fury-100)/100,7,3);c.fill()}
 c.strokeStyle=full?`hsl(${40+Math.sin(S.t*12)*20},100%,60%)`:'#b8862a';c.lineWidth=2.4;c.beginPath();c.roundRect(bx,by,bw,20,8);c.stroke();
 c.font='24px "Pirata One",Georgia,serif';c.fillStyle='#fff';c.fillText(full?'FURY READY  press Enter'+(S.fury>=200?'  x2':''):'Fury',W/2,by-24);if(S.mev){c.font='20px "Pirata One",Georgia,serif';c.fillStyle='#d8a8ff';c.fillText('Arcane bolt: '+S.mk+' of '+S.mev+' kills',W/2,by+46)}
 for(let i=0;i<S.cr.length;i++){}
 if(S.ban){c.globalAlpha=Math.min(1,S.ban.t*1.4);c.textAlign='center';c.font='92px "Pirata One",Georgia,serif';c.fillStyle=S.ban.c;c.strokeStyle='#000';c.lineWidth=9;c.lineJoin='round';const yy=250-Math.max(0,S.ban.t-2.4)*90;c.strokeText(S.ban.txt,W/2,yy);c.fillText(S.ban.txt,W/2,yy);if(S.ban.sub){c.font='30px "Pirata One",Georgia,serif';c.lineWidth=6;c.fillStyle='#fff';c.strokeText(S.ban.sub,W/2,yy+56);c.fillText(S.ban.sub,W/2,yy+56)}c.globalAlpha=1}
 c.restore()}
function drawBossUI(e){const c=ctx;if(e.state!=='fight')return;c.save();c.textAlign='center';c.textBaseline='middle';const y=e.y-e.h-176;
 c.font='34px "Pirata One",Georgia,serif';c.fillStyle='#fff';c.shadowColor='#000';c.shadowBlur=8;c.fillText(e.nm,e.x,y);c.shadowBlur=0;
 for(let i=0;i<e.phs;i++)heart(c,e.x+(i-(e.phs-1)/2)*30,y+34,10,'#e8455a','#ffb0b8');
 const bw=300;c.fillStyle='#000a';c.beginPath();c.roundRect(e.x-bw/2,y+56,bw,12,6);c.fill();const f=Math.max(0,e.vul>0?e.vul/S.vm:e.tm/e.tmax);c.fillStyle=e.vul>0?'#7dffb0':e.tm<3?'#ff3b3b':'#ffc94a';c.beginPath();c.roundRect(e.x-bw/2,y+56,bw*f,12,6);c.fill();
 if(e.vul>0){c.font='56px "Pirata One",Georgia,serif';c.fillStyle=`hsl(${(S.t*300)%360},100%,66%)`;c.strokeStyle='#000';c.lineWidth=7;c.strokeText('PRESS SPACE!',e.x,e.y-e.h*.5);c.fillText('PRESS SPACE!',e.x,e.y-e.h*.5)}
 else if(e.tel){const u=1-e.tel.t/e.tel.d;c.strokeStyle=`rgba(255,120,60,${.35+u*.6})`;c.lineWidth=6;c.beginPath();c.arc(e.x,e.y-e.h*.5,e.h*.5+16+(1-u)*60,0,TAU);c.stroke();c.font='46px "Pirata One",Georgia,serif';c.fillStyle=Math.floor(S.t*10)%2?'#ffb02e':'#fff';c.strokeStyle='#000';c.lineWidth=7;const tx=({volley:'Volley incoming!',slam:'Ground slam!',summon:'Summoning minions!',rain:'Meteors!',barrage:'Barrage!',tremor:'Tremor!',blind:'Darkness!',ward:'Raising a ward!',bolt:'Lightning! Watch the sky',beam:'Death beam! Parry it',lunge:'He is winding up a lunge!'})[e.tel.k]||'Attack!';c.strokeText(tx,e.x-20,e.y-e.h*.5);c.fillText(tx,e.x-20,e.y-e.h*.5)}
 else if(e.tm<2.2){c.font='44px "Pirata One",Georgia,serif';c.fillStyle=Math.floor(S.t*8)%2?'#ff5c6c':'#fff';c.strokeStyle='#000';c.lineWidth=7;c.strokeText('SPACE to parry!',e.x-20,e.y-e.h*.5);c.fillText('SPACE to parry!',e.x-20,e.y-e.h*.5)}
 c.restore()}
const pillOK=e=>!!(e.w&&e.w.length)&&!(e.boss&&e.state!=='fight');
function drawPills(){const T=S.tgt&&S.en.includes(S.tgt)&&pillOK(S.tgt)?S.tgt:null,tg=T?pillGeom(T):null;
 for(const e of S.en){if(e===T||!(e.x<W-10)||!pillOK(e))continue;let al=1;if(tg){const g=pillGeom(e);if(g.x<tg.x+tg.w+12&&g.x+g.w>tg.x-12&&g.y<tg.y+tg.h+12&&g.y+g.h>tg.y-12)al=.3}pill(e,false,al)}
 if(T)pill(T,true)}
function drawWorld(){const c=ctx;
 for(const d of S.dy){const u=d.t/(d.boss?1:.5),e={id:d.id,x:d.x,y:d.y-u*(d.boss?10:40),h:d.h*(1+u*.12),ph:d.ph,el:d.el,hue:d.hue,lg:0,fl:0,sh:d.sh,rb:d.rb};drawEnemy(e,1-u,true);if(d.boss&&Math.random()<.5)burst(d.x+(Math.random()-.5)*d.h*.5,d.y-Math.random()*d.h,'#ffb84a',3,{v:300})}
 const list=[...S.en].sort((a,b)=>(S.tgt===a)-(S.tgt===b)||a.y-b.y);for(const e of list){try{drawEnemy(e)}catch(err){console.error(err);ctx.restore();ctx.globalAlpha=1;ctx.filter='none'}}
 if(S.mode==='play'&&S.en.some(e=>e.boss&&e.x<W)&&S.en.some(e=>e.mn&&!e.boss)){c.save();c.textAlign='center';c.font='24px "Pirata One",Georgia,serif';c.fillStyle='rgba(255,226,168,'+(.7+.25*Math.sin(S.t*4))+')';c.strokeStyle='rgba(0,0,0,.7)';c.lineWidth=4;const tt='TAB  switch between the boss and its minions';c.strokeText(tt,W/2,H-22);c.fillText(tt,W/2,H-22);c.restore()}
 for(const e of S.en){if(e.boss)drawBossUI(e);
  if(!e.boss&&e.at!==undefined&&e.at<.6&&e.at>0){c.save();c.font='40px "Pirata One",Georgia,serif';c.fillStyle='#ff5c6c';c.textAlign='center';c.strokeStyle='#000';c.lineWidth=5;c.strokeText('!',e.x,e.y-e.h-86);c.fillText('!',e.x,e.y-e.h-86);c.restore()}}
 drawSlash(c);
 for(const e of S.en){if(S.tgt===e){c.strokeStyle=WCOL();c.lineWidth=3;c.setLineDash([10,8]);c.lineDashOffset=-S.t*30;c.beginPath();c.ellipse(e.x,e.y-e.h*.5,e.h*.5+18,e.h*.5+8,0,0,TAU);c.stroke();c.setLineDash([])}}
 for(const j of S.pj){projArt(c,j,S.t);if(j.b&&j.x<KX+520){c.save();c.font='34px "Pirata One",Georgia,serif';c.textAlign='center';c.fillStyle=Math.floor(S.t*8)%2?'#7fd8ff':'#fff';c.strokeStyle='#000';c.lineWidth=5;c.strokeText('SPACE!',j.x,j.y-46);c.fillText('SPACE!',j.x,j.y-46);c.restore()}}
 for(const q of S.shots)shotArt(c,q);try{btyDrawTrails(c)}catch(x){}
 for(const cr of S.cr){chest(c,cr.x,cr.y+16,.26,0,cr.k,S.t);}
 for(const p of S.ps){c.globalAlpha=Math.max(0,p.l/p.ml);c.fillStyle=p.c;c.fillRect(p.x-p.s/2,p.y-p.s/2,p.s,p.s)}c.globalAlpha=1;drawFxList(c);
 c.textAlign='center';c.textBaseline='middle';for(const f of S.fl){c.globalAlpha=Math.min(1,f.t*1.6);c.font=f.sz+'px "Pirata One",Georgia,serif';c.fillStyle=f.c;c.strokeStyle='#000';c.lineWidth=5;c.lineJoin='round';c.strokeText(f.txt,f.x,f.y);c.fillText(f.txt,f.x,f.y)}c.globalAlpha=1;drawDn(c)}

/* ---------- main draw ---------- */
function drawBG(){if(S.mode==='title')(S.view==='dc'&&S.dcv?zoneBG(0,S.t,S.dcv):S.view==='camp'?(ctx.fillStyle='#05030c',ctx.fillRect(0,0,W,H)):(hbgCur()>=0?zoneBG(LEVELS[hbgCur()].z,S.t,LEVELS[hbgCur()]):menuBG(S.t),HOME&&homeScene(S.t)));else if(S.mode==='crate')(S.cr2&&S.cr2.ck==='h'?sceneGen(SCN[32],S.t):menuBG(S.t));else{const L=(S.prac&&S.prac.map!=null&&S.prac.map!==31)?mapDef(S.prac.map):lvDef(S.wave||1);bgBlend(L)}}
let NEEDRESET=false;
function draw(){const c=ctx;if(NEEDRESET){NEEDRESET=false;if(c.reset)c.reset()}c.globalAlpha=1;c.filter='none';c.globalCompositeOperation='source-over';c.shadowBlur=0;c.setTransform(RS,0,0,RS,0,0);c.save();
 if(S.shake>0&&ST.shake)c.translate((Math.random()-.5)*S.shake,(Math.random()-.5)*S.shake);
 c.fillStyle='#000';c.fillRect(-30,-30,W+60,H+60);{const cz=cineZoom();if(cz){c.translate(cz.fx,cz.fy);c.scale(cz.z,cz.z);c.translate(-cz.fx,-cz.fy)}}try{drawBG()}catch(err){console.error(err);c.restore();c.save();c.setTransform(RS,0,0,RS,0,0);c.globalAlpha=1;c.filter='none';c.globalCompositeOperation='source-over';c.fillStyle='#10121c';c.fillRect(-30,-30,W+60,H+60)}
 const inRun=S.mode==='play'||S.mode==='pause'||S.mode==='boon'||S.mode==='over';
 if(inRun){drawHeroGame();drawWorld();bgxOver();if(lvDef(S.wave).mod==='dark'&&S.mode!=='over'){const fl=1+Math.sin(S.t*9)*.03,g=c.createRadialGradient(KX+60,GY-120,120*fl,KX+60,GY-120,560*fl);g.addColorStop(0,'rgba(2,2,8,0)');g.addColorStop(1,'rgba(2,2,8,.82)');c.fillStyle=g;c.fillRect(-30,-30,W+60,H+60)}}
 gyVignette(c);if(S.blind>0&&inRun){const a=Math.min(.75,S.blind*.6),g2=c.createRadialGradient(KX+60,GY-120,90,KX+60,GY-120,620);g2.addColorStop(0,'rgba(8,4,24,0)');g2.addColorStop(1,`rgba(8,4,24,${a})`);c.fillStyle=g2;c.fillRect(-30,-30,W+60,H+60)}
 drawStrikes(c);
 if(S.mode==='crate'&&S.cr2)drawCrateScene();
 c.restore();
 vignette();
 if(S.cine)drawCine();
 if(inRun)drawPills();
 if(S.flash>0&&ST.flash&&S.mode!=='crate'){c.fillStyle=`rgba(255,255,255,${S.flash*.7})`;c.fillRect(0,0,W,H)}
 if(inRun){if(S.hurt>0){const g=c.createRadialGradient(W/2,H/2,H*.3,W/2,H/2,H*.9);g.addColorStop(0,'#0000');g.addColorStop(1,`rgba(255,30,50,${S.hurt})`);c.fillStyle=g;c.fillRect(0,0,W,H)}drawHUD()}}

/* ---------- monster traits ---------- */
const chg=e=>e.tr==='charge'&&e.x<W*.62?(e.ch||(e.ch=1,float(e.x,e.y-e.h-70,'Charging!','#ff9a5a',26),beep(200,.1,'sawtooth',.4)),1.75):1;
function addMob(src,id,dx,short,mn){const M=MON[id],zi=zoneIdx(S.wave),m={id,role:1,boss:false,i:0,x:Math.min(W-40,src.x+dx),ph:Math.random()*6,fl:.3,lg:0,slip:0,y:GY,h:M.h*(short?.72:1),el:false,rg:false,hv:0,sp:M.sp*K*(short?1.25:1),w:S.rift?riftWord(1,id,S.en.map(q=>q.w)):pickWord(short?1:0,zi,S.d,S.en.map(q=>q.w)),mn:mn?1:0};
 if(M.fly)m.hv=50+Math.random()*80;S.en.push(m);burst(m.x,GY-60,mn?'#c86bff':'#ffb0d0',14);return m}
function trait(e,dt){const T=e.tr;
 if(T==='blink'){e.bt-=dt;if(e.bt<=0&&e.x>KX+340&&e.x<W-60){e.bt=2.4+Math.random()*1.6;burst(e.x,e.y-e.h*.5,'#c86bff',16);e.x-=110+Math.random()*90;e.fl=.25;burst(e.x,e.y-e.h*.5,'#c86bff',16);beep(900,.08,'sine',.5)}}
 else if(T==='summon'){e.sm-=dt;if(e.sm<=0&&e.x<W-100&&e.x>KX+300&&S.en.filter(q=>q.mn).length<3){e.sm=6.5+Math.random()*2;e.lg=.8;const z=lvDef(S.wave);addMob(e,S.gy?'gyshamble':S.camp>30?'astmote'/*ASTRAL*/:ZR[zoneIdx(S.wave)][0][0],-70,true,true);float(e.x,e.y-e.h-60,'Summons!','#c86bff',26);beep(320,.15,'triangle',.5)}}}
function shieldBreak(t){t.shd--;t.i=0;t.slip=0;t.bad=0;t.w=pickWord(1,zoneIdx(S.wave),S.d,S.en.map(q=>q.w));t.fl=.3;S.score+=25;S.shake=Math.max(S.shake,8);const sc=SHC(t.shd+1).b;burst(t.x,t.y-t.h*.5,sc,26,{v:380});S.fx.push({k:'ring',x:t.x,y:t.y-t.h*.5,t:0,ml:.4,c:sc,w:5,r0:10,r1:110});float(t.x,t.y-t.h-70,t.shd>0?'Shield cracked!':'Shield broken!',sc,30);beep(1100,.09,'triangle',.7)}
function bombBlast(e,toHero){S.en=S.en.filter(x=>x!==e);if(S.tgt===e)S.tgt=null;burst(e.x,e.y-e.h*.5,'#ff8a2a',40,{v:480});S.fx.push({k:'ring',x:e.x,y:e.y-e.h*.5,t:0,ml:.5,c:'#ff8a2a',w:9,r0:10,r1:220},{k:'flash',x:e.x,y:e.y-e.h*.5,t:0,ml:.35,c:'#ffb040',r:150});S.shake=Math.max(S.shake,24);beep(70,.35,'sawtooth',1);S.dy.push({id:e.id,x:e.x,y:e.y,h:e.h,t:0,ph:e.ph,el:e.el,hit:1});if(toHero)dmg(2)}
function deathTrait(e){
 if(e.tr==='bomb'&&!S.inBomb){S.inBomb=1;const near=S.en.filter(q=>!q.boss&&Math.abs(q.x-e.x)<270&&q.x<W-20);burst(e.x,e.y-e.h*.5,'#ff8a2a',34,{v:460});S.fx.push({k:'ring',x:e.x,y:e.y-e.h*.5,t:0,ml:.5,c:'#ffb040',w:8,r0:10,r1:260});S.shake=Math.max(S.shake,18);if(near.length)float(e.x,e.y-e.h-110,'BLAST x'+near.length+'!','#ffb040',40);const w0=S.inChain;S.inChain=1;for(const q of near)if(S.en.includes(q))kill(q,true);S.inChain=w0;S.inBomb=0}
 else if(e.tr==='split'){for(const dx of[-46,46]){const m=addMob(e,e.id==='shard'?'wisp':'mite',dx,true,false);m.x=Math.max(KX+120,Math.min(W-40,e.x+dx));m.fl=.4}float(e.x,e.y-e.h-90,'Spawnlings!','#ffb0d0',30)}}
function traitDraw(e,cyc,al){const c=ctx;c.save();if(al!==undefined)c.globalAlpha=al;
 if(e.ward>0){c.strokeStyle='#bff4ff';c.lineWidth=5;c.shadowColor='#7fdcff';c.shadowBlur=18;c.setLineDash([22,12]);c.lineDashOffset=-S.t*50;c.beginPath();c.ellipse(e.x,cyc,e.h*.5,e.h*.62,0,0,TAU);c.stroke();c.setLineDash([]);c.shadowBlur=0;c.fillStyle='#7fdcff22';c.fill()}
 if(e.shd>0){const R=e.h*.42,sh=SHC(e.shd);c.strokeStyle=sh.s;c.lineWidth=3;c.shadowColor=sh.g;c.shadowBlur=12;c.setLineDash([14,9]);c.lineDashOffset=-S.t*40;for(let k=0;k<e.shd;k++){c.beginPath();c.ellipse(e.x,cyc,R+k*9,e.h*.58+k*9,0,0,TAU);c.stroke()}c.setLineDash([]);c.shadowBlur=0;c.fillStyle=sh.f;c.beginPath();c.ellipse(e.x,cyc,R,e.h*.58,0,0,TAU);c.fill()}
 else if(e.tr==='bomb'){const p=.5+.5*Math.sin(S.t*9);c.fillStyle=`rgba(255,120,30,${.25+.3*p})`;c.beginPath();c.arc(e.x,cyc,e.h*.5*(1+.05*p),0,TAU);c.fill()}
 else if(e.tr==='summon'&&e.sm<1.2){c.strokeStyle='#c86bff';c.lineWidth=3;c.beginPath();c.arc(e.x,GY,50*(1.4-e.sm/1.2*.6),0,TAU);c.stroke()}
 c.restore()}
function initTr(e,M){e.tr=M.tr;if(M.tr==='shield')e.shd=S.d>=22?2:1;else if(M.tr==='blink')e.bt=2+Math.random()*2;else if(M.tr==='summon')e.sm=3.5+Math.random()*2}
const TRD={shield:'armored, type its word twice.',split:'bursts into spawnlings when slain.',bomb:'explodes for 2 damage if it reaches you. Slay it near others to blast them.',blink:'teleports forward without warning.',summon:'calls minions to its side.',charge:'sprints at you when it gets close.'};

const GSPD=[1,1.25,1.5,1.75,2];
function setSpeed(v){if(S.mode!=='play'&&S.mode!=='pause')return;if(S.rift||S.prac||S.dc||!GSPD.includes(v)||v===S.gs)return;const r=v/S.gs;S.gm*=r;S.sc*=r;S.gs=v;P.gsp=v;spUI();beep(v>1?640+v*120:480,.06,'triangle',.5);float(W/2,300,v+'× speed','#ffd76a',44)}
function stepSpeed(d){const i=GSPD.indexOf(S.gs||1);setSpeed(GSPD[Math.max(0,Math.min(GSPD.length-1,i+d))])}
function spUI(){const b=document.getElementById('spb');if(!b)return;const on=(S.mode==='play'||S.mode==='pause')&&!S.rift&&!S.prac&&!S.dc;b.style.display=on?'':'none';b.textContent=(S.gs||1)+'× speed';b.classList.toggle('on',(S.gs||1)>1)}

function tabTarget(){const boss=S.en.find(e=>e.boss&&e.x<W);if(!boss){S.tgt=null;return}
 const mins=S.en.filter(e=>!e.boss&&e.mn&&e.x<W-10).sort((a,b)=>a.x-b.x);if(!mins.length){S.tgt=boss;return}
 const list=[boss,...mins],i=list.indexOf(S.tgt),n=list[(i+1)%list.length];S.tgt=n;S.tabT=1.6;beep(n.boss?420:760,.05,'triangle',.4)}
