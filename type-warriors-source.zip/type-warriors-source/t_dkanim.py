import asyncio,os
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900},device_scale_factor=2);er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:200]))
        await pg.goto('file://'+os.path.abspath('out.html'));await pg.wait_for_timeout(2500);await pg.evaluate("()=>{RS_ASK=false;title()}");await pg.wait_for_timeout(2000)
        bb=await pg.locator('.dk').first.bounding_box()
        rows=[]
        for k in ['pl','gr','pt','pg','sh','mo']:
            await pg.hover(f'#dk_{k}');await pg.wait_for_timeout(30)
            for ms in [120,260,420]:
                await pg.evaluate(f"()=>document.querySelector('#dk_{k} .dkico').getAnimations({{subtree:true}}).forEach(a=>{{a.pause();a.currentTime={ms}}})")
                ib=await pg.locator(f'#dk_{k}').bounding_box()
                f=f'shots/an_{k}_{ms}.png';await pg.screenshot(path=f,clip={'x':ib['x'],'y':ib['y']-14,'width':ib['width'],'height':ib['height']+14});rows.append(f)
            await pg.evaluate(f"()=>document.querySelector('#dk_{k} .dkico').getAnimations({{subtree:true}}).forEach(a=>a.play())")
            await pg.mouse.move(10,10);await pg.wait_for_timeout(950)
            print(k,'cleared',await pg.evaluate(f"()=>document.querySelector('#dk_{k} .dkico').classList.contains('k-go')"))
        from PIL import Image
        ims=[Image.open(f) for f in rows];w=ims[0].width;h=ims[0].height
        o=Image.new('RGB',(w*3,h*6))
        for i,im in enumerate(ims):o.paste(im,((i%3)*w,(i//3)*h))
        o.save('shots/an_grid.png');print(er);await b.close()
asyncio.run(main())
