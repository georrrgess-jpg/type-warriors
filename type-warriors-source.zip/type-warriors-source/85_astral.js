/* ===== ASTRAL ASCENDANCE (Act VI, optional module) =====
   Self-contained. To remove: delete this file, drop it from build.sh, and revert every line tagged ASTRAL (a comment marker) in 10_data.js and 50_game.js.
   Levels 31-33 (S.camp>30) never touch P.camp, P.stars or P.cbest; progress lives in P.ast only. */
const AD={};
const asStar=(g,x,y,r,col,n,k)=>{n=n||4;k=k||.38;const p=[];for(let i=0;i<n*2;i++){const a=-Math.PI/2+i*Math.PI/n,rr=i%2?r*k:r;p.push(x+Math.cos(a)*rr,y+Math.sin(a)*rr)}poly(g,p,col)};
const asRing=(g,x,y,rx,ry,rot,col,w)=>{g.save();g.translate(x,y);g.rotate(rot);g.strokeStyle=col;g.lineWidth=w;g.beginPath();g.ellipse(0,0,rx,ry,0,0,TAU);g.stroke();g.restore()};
const asTw=(t,k)=>.65+.35*Math.sin(t*k);

/* 1. Cosmic Stalker: a star-dust panther, constellations running along its flank */
AD.astalker=(g,t,o)=>{const lg=(o&&o.lg)||0,s=Math.sin(t*7),b=Math.abs(Math.cos(t*7))*3,c='#ff70a6',c2='#ffd1e6',d='#240a22',m='#5e1d4c';g.save();g.lineJoin='round';g.lineCap='round';
 glow(g,0,-8,80,c+'30');
 /* tail */
 const tw=Math.sin(t*3)*8,tp=()=>{g.beginPath();g.moveTo(24,-54-b);g.bezierCurveTo(50,-58,66,-88+tw,86,-74+tw*1.3)};
 g.strokeStyle=d;g.lineWidth=9;tp();g.stroke();g.strokeStyle=shade(m,.2);g.lineWidth=3;tp();g.stroke();g.strokeStyle=c;g.lineWidth=1.4;g.globalAlpha=.8;tp();g.stroke();g.globalAlpha=1;
 glow(g,86,-74+tw*1.3,16,c+'aa');asStar(g,86,-74+tw*1.3,8,c2,4);
 /* legs: far pair first */
 const leg=(hx,ph,col,w)=>{const sp=Math.sin(t*7+ph),kx=hx+sp*9,fx=hx+sp*17;limb(g,hx,-42,kx,-23,w,col);limb(g,kx,-23,fx,-4,w*.72,col);poly(g,[fx-9,-1,fx+3,-1,fx+3,-9,fx-7,-8],col,'#000a',1);g.fillStyle=c2;for(let i=0;i<3;i++)g.fillRect(fx-9+i*3,-2,1.6,2.5)};
 leg(-18,Math.PI,shade(d,-.3),11);leg(20,0,shade(d,-.3),12);
 g.translate(0,-b);
 /* body */
 g.beginPath();g.moveTo(-36,-56);g.bezierCurveTo(-28,-72,-6,-66,6,-62);g.bezierCurveTo(18,-66,34,-66,36,-52);g.bezierCurveTo(36,-40,26,-32,12,-32);g.bezierCurveTo(-4,-28,-24,-30,-32,-38);g.closePath();
 g.fillStyle=vgr(g,-70,-28,shade(m,.2),d);g.fill();g.strokeStyle='#000b';g.lineWidth=1.8;g.stroke();
 /* flank constellation */
 const cs=[[-18,-56],[-8,-48],[4,-54],[14,-44],[24,-52],[-2,-40]];g.strokeStyle=c2;g.lineWidth=.9;g.globalAlpha=.55;g.beginPath();cs.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.stroke();g.globalAlpha=1;
 cs.forEach((p,i)=>{g.globalAlpha=asTw(t*1.6+i,5);glow(g,p[0],p[1],6,c+'99');ell(g,p[0],p[1],1.8,1.8,'#fff')});g.globalAlpha=1;
 /* glowing stripes on haunch */
 g.strokeStyle=c;g.lineWidth=2;g.globalAlpha=asTw(t,3);for(let i=0;i<3;i++){g.beginPath();g.moveTo(20+i*5,-60+i*2);g.quadraticCurveTo(24+i*5,-50,18+i*5,-38);g.stroke()}g.globalAlpha=1;
 /* spine crest of light */
 for(let i=0;i<7;i++){const x=-28+i*9,y=-68+Math.abs(i-2)*1.2,h=14+Math.sin(t*5+i)*3+(i<4?4:0);g.globalAlpha=.85;poly(g,[x-3,y,x+3,y,x+1+Math.sin(t*4+i)*1.5,y-h],hgr(g,x-3,x+3,c2,c),null)}g.globalAlpha=1;
 /* near legs */
 leg(-14,0,d,12);leg(24,Math.PI,m,13);
 /* head, lowered and forward */
 const hx=-46-lg*16,hy=-64+lg*4,jaw=3+lg*14+Math.sin(t*7)*1.2;
 ell(g,hx+14,hy+8,13,11,m);
 poly(g,[hx+6,hy-12,hx+12,hy-32,hx+22,hy-12],d,'#000a',1.3);poly(g,[hx+10,hy-14,hx+13,hy-26,hx+18,hy-14],c+'aa');poly(g,[hx+18,hy-10,hx+30,hy-28,hx+32,hy-4],shade(d,-.2),'#000a',1.3);
 g.beginPath();g.moveTo(hx+16,hy-13);g.bezierCurveTo(hx,hy-18,hx-16,hy-8,hx-19,hy-1);g.lineTo(hx-19,hy+4);g.lineTo(hx-4,hy+4);g.bezierCurveTo(hx+8,hy+14,hx+22,hy+12,hx+24,hy-2);g.closePath();g.fillStyle=hgr(g,hx-26,hx+24,shade(m,.3),d);g.fill();g.strokeStyle='#000b';g.lineWidth=1.6;g.stroke();
 poly(g,[hx-19,hy+4,hx-5,hy+4,hx+10,hy+8+jaw,hx-12,hy+8+jaw],shade(d,.1),'#000a',1.2);
 g.fillStyle='#2a0014';g.beginPath();g.moveTo(hx-17,hy+4);g.lineTo(hx-4,hy+4);g.lineTo(hx-2,hy+5+jaw*.7);g.lineTo(hx-15,hy+6+jaw*.7);g.fill();
 g.fillStyle='#fff';for(let i=0;i<3;i++){poly(g,[hx-17+i*5.2,hy+4,hx-14+i*5.2,hy+4,hx-15.5+i*5.2,hy+10],'#fff');poly(g,[hx-14+i*5.2,hy+6+jaw*.7,hx-11+i*5.2,hy+6+jaw*.7,hx-12.5+i*5.2,hy+1+jaw*.4],'#fff')}
 ell(g,hx-19,hy,2.4,1.8,'#ff9ac8');
 glow(g,hx-1,hy-5,15,c+'cc');poly(g,[hx-10,hy-5,hx+8,hy-9,hx+7,hy-4,hx-8,hy-2],'#0a0010');poly(g,[hx-5,hy-5,hx+5,hy-7,hx+4,hy-4,hx-4,hy-3],'#fff');
 g.strokeStyle=c2;g.lineWidth=1;g.globalAlpha=.6;for(let i=0;i<3;i++){g.beginPath();g.moveTo(hx-18,hy+1+i*2);g.quadraticCurveTo(hx-30,hy-4+i*5+Math.sin(t*3+i)*2,hx-40,hy+i*6)}g.stroke();g.globalAlpha=1;
 for(let i=0;i<7;i++){const u=(t*.7+i/7)%1;g.globalAlpha=(1-u)*.8;asStar(g,30-u*60+Math.sin(i*3)*8,-72-u*10+i%3*4,2.4*(1-u)+1,'#fff',4)}g.globalAlpha=1;g.restore()};

/* 2. Astral Wisp: a drifting star core in a tilted ring */
AD.awisp=(g,t,o)=>{const bob=Math.sin(t*2.8)*6,fl=asTw(t,9),lg=(o&&o.lg)||0;g.save();g.lineJoin='round';g.lineCap='round';g.translate(0,-48+bob);
 for(let i=0;i<8;i++){const u=i/8;g.globalAlpha=.6*(1-u);ell(g,14+u*44,Math.sin(t*5-i*.7)*6*u+u*8,11*(1-u)+2,7*(1-u)+1.4,i%2?'#bfeaff':'#70d6ff')}g.globalAlpha=1;
 glow(g,0,0,60,'#70d6ff'+hwA(.5*fl));asRing(g,0,0,30,9,-.5+t*.8,'#bfeaff',2.4);
 ell(g,0,0,17,17,rgr(g,-4,-4,1,20,'#ffffff','#38a8e8'));ell(g,-3,-3,8,8,'#ffffffcc');
 g.globalAlpha=.9;asRing(g,0,0,30,9,-.5+t*.8+Math.PI,'#70d6ff',1.2);g.globalAlpha=1;
 ell(g,-7-lg*5,0,3,4,'#082a44');ell(g,2-lg*5,0,3,4,'#082a44');eye(g,-7-lg*5,0,1.4,'#fff');eye(g,2-lg*5,0,1.4,'#fff');
 for(let i=0;i<3;i++){const a=t*1.5+i*2.1;asStar(g,Math.cos(a)*36,Math.sin(a)*14-8,4,'#fff',4)}g.restore()};

/* 3. Celestial Sentinel: an armoured guardian with a halo and a tower shield */
AD.asentinel=(g,t,o)=>{const lg=(o&&o.lg)||0,s=Math.sin(t*3.4),b=Math.abs(Math.cos(t*3.4))*1.6,c='#e7c6ff',d='#4a3a78',gd='#ffd98a';g.save();g.lineJoin='round';g.lineCap='round';
 limb(g,6,-52,10+s*5,-28,13,shade(d,-.2));limb(g,10+s*5,-28,14+s*9,-5,11,shade(d,-.2));poly(g,[6+s*9,-2,26+s*9,-2,24+s*9,-12,8+s*9,-12],shade(c,-.5),'#000a',1.2);
 limb(g,-6,-52,-10-s*5,-28,14,d);limb(g,-10-s*5,-28,-14-s*9,-5,12,shade(d,.1));poly(g,[-26-s*9,-2,-4-s*9,-2,-6-s*9,-12,-24-s*9,-12],shade(c,-.4),'#000a',1.2);
 g.translate(0,-b);
 poly(g,[-20,-52,20,-52,24,-120,-22,-122],hgr(g,-22,24,shade(c,-.15),d),'#000a',2);poly(g,[-20,-52,20,-52,18,-40,-18,-40],gd,'#000a',1.4);
 g.strokeStyle=gd;g.lineWidth=2.4;g.beginPath();g.moveTo(0,-118);g.lineTo(0,-54);g.moveTo(-14,-96);g.lineTo(14,-96);g.stroke();
 glow(g,0,-96,22,gd+hwA(.5*asTw(t,3)));asStar(g,0,-96,7,'#fff',4);
 ell(g,-24,-118,13,10,gd);ell(g,24,-118,13,10,gd);
 limb(g,22,-114,34,-92,9,d);limb(g,34,-92,30,-72,8,shade(d,.1));
 const sx=-34-lg*16;limb(g,-22,-114,-30,-96,9,d);
 poly(g,[sx-26,-122,sx+16,-122,sx+16,-58,sx-5,-34,sx-26,-58],hgr(g,sx-26,sx+16,'#f4e4ff',shade(c,-.3)),'#000a',2.4);
 g.strokeStyle=gd;g.lineWidth=3;g.beginPath();g.moveTo(sx-8,-116);g.lineTo(sx-8,-48);g.moveTo(sx-22,-90);g.lineTo(sx+12,-90);g.stroke();asStar(g,sx-5,-90,9,gd,4);
 g.save();g.translate(32,-70);g.rotate(.05);g.strokeStyle='#8a7aa8';g.lineWidth=4;g.beginPath();g.moveTo(0,40);g.lineTo(-2,-90);g.stroke();poly(g,[-7,-90,3,-90,-2,-112],'#f4e4ff','#000a',1.4);g.restore();
 ell(g,0,-138,15,16,rgr(g,-4,-142,1,20,'#fff0ff',c));poly(g,[-14,-142,14,-142,14,-130,-14,-130],'#1a1030');g.fillStyle='#fff';g.fillRect(-9,-139,18,3);glow(g,0,-137,8,'#fff8');
 asRing(g,0,-158,22,6,0,gd,3);glow(g,0,-158,22,gd+hwA(.4*asTw(t,4)));g.restore()};

/* 4. Void Weaver: a hooded thing that spins a web of dark thread between six hands */
AD.aweaver=(g,t,o)=>{const lg=(o&&o.lg)||0,hv=Math.sin(t*2.2)*4,c='#b5179e',d='#1a0620';g.save();g.lineJoin='round';g.lineCap='round';g.translate(0,hv);
 poly(g,[-6,-150,22,-150,34,-70].concat(gyHem(36,-34,-12,9,7,t,1.6),[-24,-90]),hgr(g,-34,36,shade(d,.4),d),'#000a',2);
 g.fillStyle=c+'55';for(let i=0;i<5;i++){g.beginPath();g.moveTo(-26+i*14,-20);g.quadraticCurveTo(-24+i*14,-70,-18+i*14,-120);g.lineTo(-14+i*14,-118);g.quadraticCurveTo(-20+i*14,-68,-18+i*14,-20);g.fill()}
 const hs=[[-52-lg*18,-100],[-60,-70],[-46,-132],[50,-96],[58,-64],[44,-126]];
 for(const [x,y] of hs){limb(g,x<0?-16:18,-112,x,y+Math.sin(t*3+x)*3,3.4,shade(c,-.3));ell(g,x,y+Math.sin(t*3+x)*3,3.4,3.4,'#ffd6f6')}
 g.strokeStyle='#e08aff';g.lineWidth=1.2;for(let i=0;i<hs.length;i++)for(let j=i+1;j<hs.length;j++){if((i+j)%2)continue;g.globalAlpha=.4+.3*Math.sin(t*3+i+j);g.beginPath();g.moveTo(hs[i][0],hs[i][1]);g.quadraticCurveTo((hs[i][0]+hs[j][0])/2+Math.sin(t*2+i)*8,(hs[i][1]+hs[j][1])/2+8,hs[j][0],hs[j][1]);g.stroke()}g.globalAlpha=1;
 g.save();g.translate(2,-150);ell(g,0,0,22,24,d);poly(g,[-20,-8,0,-34,20,-8,14,14,-14,14],hgr(g,-20,20,shade(d,.5),d),'#000a',1.6);ell(g,0,2,13,14,'#06000a');
 glow(g,-5,0,10,c);glow(g,6,-1,10,c);eye(g,-5,0,2.8,'#ff9af0');eye(g,6,-1,2.8,'#ff9af0');eye(g,0,-9,2,'#ff9af0');eye(g,-11,-7,1.6,'#ff9af0');eye(g,12,-8,1.6,'#ff9af0');g.restore();g.restore()};

/* 5. Nova Drake: a wyrm with wings of burning plasma */
AD.adrake=(g,t,o)=>{const bob=Math.sin(t*3)*7,fl=asTw(t,11),lg=(o&&o.lg)||0,w=Math.sin(t*6),c='#ff4d6d',d='#4a0f24';g.save();g.lineJoin='round';g.lineCap='round';g.translate(0,-52+bob);
 for(let i=0;i<10;i++){const u=i/10;limb(g,24+u*50,10+u*8+Math.sin(t*4-i*.6)*5*u,24+(u+.1)*50,10+(u+.1)*8+Math.sin(t*4-(i+1)*.6)*5*(u+.1),12*(1-u)+2,shade(d,.1+u*.2))}
 for(const k of[1,-1]){g.save();g.translate(8,-6);g.rotate(-.5+w*.35*k*(k>0?1:.6));poly(g,[0,0,24,-70,52,-84,64,-48,86,-52,76,-14,92,0,40,16],hgr(g,0,92,'#ff9a5a','#ff2d55'),'#000a',1.6);g.strokeStyle='#ffd0a0';g.lineWidth=2;g.beginPath();g.moveTo(0,0);g.lineTo(52,-84);g.moveTo(0,0);g.lineTo(76,-14);g.stroke();g.restore()}
 g.beginPath();g.ellipse(6,4,34,20,-.1,0,TAU);g.fillStyle=hgr(g,-28,40,shade(c,.1),d);g.fill();g.strokeStyle='#000a';g.lineWidth=1.8;g.stroke();
 g.fillStyle='#ffc9a8';for(let i=0;i<5;i++){g.beginPath();g.ellipse(-8+i*8,10,6,3,0,0,TAU);g.fill()}
 limb(g,-22,-6,-38-lg*16,-18,16,shade(d,.2));
 const hx=-52-lg*16,hy=-22;ell(g,hx,hy,19,15,rgr(g,hx-5,hy-5,1,22,shade(c,.3),d));poly(g,[hx-14,hy-2,hx-38,hy+4,hx-34,hy+13,hx-12,hy+11],shade(c,.1),'#000a',1.4);
 poly(g,[hx+4,hy-12,hx+16,hy-36,hx+20,hy-8],'#ffd9b0','#000a',1.2);poly(g,[hx-6,hy-13,hx-2,hy-34,hx+8,hy-10],'#ffd9b0','#000a',1.2);
 glow(g,hx-6,hy-4,12,'#ffd040');eye(g,hx-6,hy-4,3,'#fff0a0');g.fillStyle='#fff';for(let i=0;i<3;i++)poly(g,[hx-34+i*7,hy+11,hx-31+i*7,hy+17,hx-28+i*7,hy+11],'#fff');
 glow(g,hx-40,hy+6,18,'#ff9a3a'+hwA(.6*fl));ell(g,hx-40,hy+6,6*fl+2,4,'#ffe0a0');
 g.restore()};

/* 6. Ethereal Construct: floating crystal blocks bound by a blue core */
AD.aconstruct=(g,t,o)=>{const lg=(o&&o.lg)||0,fl=asTw(t,3),c='#4cc9f0',d='#0e3a58';g.save();g.lineJoin='round';g.lineCap='round';
 const blk=(x,y,w,h,k)=>{const yy=y+Math.sin(t*2+k)*3;poly(g,[x,yy,x+w,yy,x+w,yy+h,x,yy+h],hgr(g,x,x+w,shade(c,-.1),d),'#000a',1.8);g.strokeStyle='#bff0ff';g.lineWidth=1.2;g.strokeRect(x+3,yy+3,w-6,h-6);g.fillStyle=c+'66';g.fillRect(x+w*.3,yy+h*.3,w*.4,h*.4);return yy};
 blk(-26,-30,22,26,0);blk(4,-30,22,26,1);blk(-34,-70,68,44,2);glow(g,0,-48,30,c+hwA(.7*fl));asStar(g,0,-48,12,'#fff',4);
 blk(-30,-124,60,50,3);blk(-12,-150,24,20,4);ell(g,-8,-102,3,2,'#fff');ell(g,8,-102,3,2,'#fff');glow(g,0,-100,16,c+'aa');
 const ax=-62-lg*20;blk(ax,-122,26,30,5);blk(ax-12,-90,30,28,6);blk(48,-118,24,28,7);blk(52,-88,26,26,8);
 g.strokeStyle='#bff0ff88';g.lineWidth=2;g.setLineDash([4,5]);g.beginPath();g.moveTo(-30,-110);g.lineTo(ax+22,-108);g.moveTo(ax+6,-92);g.lineTo(ax+2,-90);g.moveTo(30,-110);g.lineTo(50,-104);g.stroke();g.setLineDash([]);
 for(let i=0;i<5;i++){const a=t*1.2+i*1.26;g.globalAlpha=.8;ell(g,Math.cos(a)*54,-76+Math.sin(a)*28,3,3,'#e0fbff')}g.globalAlpha=1;g.restore()};

/* 7. Dimensional Horror: a knot of tentacles around a mouth that is a tear in space */
AD.ahorror=(g,t,o)=>{const lg=(o&&o.lg)||0,c='#4895ef',d='#0a1a3a';g.save();g.lineJoin='round';g.lineCap='round';
 for(let i=0;i<7;i++){const x0=-24+i*8,ph=i*1.1;g.strokeStyle=shade(d,.1+(i%3)*.08);g.lineWidth=11-i%3*2;g.beginPath();g.moveTo(x0,-44);g.quadraticCurveTo(x0+Math.sin(t*3+ph)*14+(i-3)*8,-24,x0+(i-3)*10+Math.sin(t*4+ph)*8,-2);g.stroke()}
 g.beginPath();g.moveTo(-40,-40);g.quadraticCurveTo(-52,-110,-20,-136);g.quadraticCurveTo(14,-150,38,-120);g.quadraticCurveTo(54,-80,40,-40);g.closePath();g.fillStyle=rgr(g,-6,-90,4,70,shade(c,-.2),d);g.fill();g.strokeStyle='#000a';g.lineWidth=2;g.stroke();
 const ex=[[-18,-112,6],[10,-120,5],[26,-98,6],[-30,-86,4],[14,-80,3.4]];for(const [x,y,r] of ex){ell(g,x,y,r+2,r+2,'#05101e');glow(g,x,y,r*2.4,'#9ad4ff55');eye(g,x,y,r*.7,'#fff');g.fillStyle='#000';g.beginPath();g.ellipse(x+Math.sin(t*2+x)*1.5,y,r*.22,r*.5,0,0,TAU);g.fill()}
 const mw=16+Math.sin(t*3)*5+lg*8,mx=-14-lg*14;g.save();g.translate(mx,-62);g.beginPath();g.moveTo(-26,0);g.quadraticCurveTo(0,-mw,26,0);g.quadraticCurveTo(0,mw,-26,0);g.fillStyle='#02040c';g.fill();g.strokeStyle='#bfe4ff';g.lineWidth=2;g.stroke();
 for(let i=0;i<9;i++){const a=t*2+i*.7;g.globalAlpha=.8;asStar(g,Math.cos(a)*14,Math.sin(a)*mw*.5,2.4,'#fff',4)}g.globalAlpha=1;g.restore();
 limb(g,-38,-96,-56-lg*14,-70,6,shade(d,.2));limb(g,-56-lg*14,-70,-66-lg*18,-50+Math.sin(t*4)*3,4,shade(d,.2));g.restore()};

/* 8. Chrono Devourer: a clock-faced serpent. Brass bezel, jagged maw, a trail of afterimages where it skipped through time */
AD.adevourer=(g,t,o)=>{const bob=Math.sin(t*2.4)*6,lg=(o&&o.lg)||0,c='#5a52ff',d='#0c0a3a',br='#e8c060',bd='#7a5418';g.save();g.lineJoin='round';g.lineCap='round';g.translate(0,-70+bob);
 /* afterimages: it blinked through here a moment ago */
 for(let i=3;i>=1;i--){g.save();g.globalAlpha=.1+.04*(3-i);g.translate(i*26,Math.sin(t*2.4-i*.5)*4);ell(g,0,0,40,40,'#8f86ff');asRing(g,0,0,44,44,0,'#8f86ff',3);g.restore()}
 g.globalAlpha=1;
 /* segmented body with fins */
 const seg=[];for(let i=0;i<9;i++){const u=i/9,x=34+u*84,y=Math.sin(t*3-i*.75)*15*(u+.2)+u*30;seg.push([x,y,26*(1-u*.75)+3])}
 for(let i=seg.length-1;i>=0;i--){const [x,y,r]=seg[i];if(i%2===0){poly(g,[x-4,y-r*.7,x+6,y-r*1.7,x+10,y-r*.6],shade(c,-.3),'#000a',1);poly(g,[x-4,y+r*.7,x+6,y+r*1.7,x+10,y+r*.6],shade(c,-.3),'#000a',1)}
  ell(g,x,y,r,r,rgr(g,x-r*.3,y-r*.4,1,r*1.3,shade(c,.3),d));g.strokeStyle='#000a';g.lineWidth=1.4;g.beginPath();g.arc(x,y,r,0,TAU);g.stroke();
  g.strokeStyle=br+'aa';g.lineWidth=1.4;g.beginPath();g.arc(x,y,r*.7,-.8,.8);g.stroke();if(r>8){ell(g,x,y,2.4,2.4,br);}}
 /* time-sand shed from the tail */
 for(let i=0;i<10;i++){const u=(t*.5+i/10)%1,x=100+u*70,y=seg[8][1]+Math.sin(i*4+t*2)*10-u*20;g.globalAlpha=(1-u)*.7;ell(g,x,y,1.8,1.8,br)}g.globalAlpha=1;
 glow(g,0,0,86,c+hwA(.5*asTw(t,4)));
 /* gear-toothed brass bezel */
 const R=44;g.save();g.rotate(t*.35);g.fillStyle=bd;for(let i=0;i<16;i++){const a=i*TAU/16;g.save();g.rotate(a);g.fillRect(R-2,-4,9,8);g.restore()}g.restore();
 ell(g,0,0,R+1,R+1,hgr(g,-R,R,shade(br,.3),bd));g.strokeStyle='#000b';g.lineWidth=2;g.beginPath();g.arc(0,0,R+1,0,TAU);g.stroke();
 for(let i=0;i<4;i++){const a=i*TAU/4+Math.PI/4;ell(g,Math.cos(a)*(R-4),Math.sin(a)*(R-4),3.4,3.4,i%2?'#ff4d6d':'#7affea');glow(g,Math.cos(a)*(R-4),Math.sin(a)*(R-4),9,(i%2?'#ff4d6d':'#7affea')+'88')}
 /* face */
 ell(g,0,0,36,36,rgr(g,-8,-10,3,44,'#f6f2ff','#bdb4ee'));g.strokeStyle='#1a1450';g.lineWidth=1.6;g.beginPath();g.arc(0,0,36,0,TAU);g.stroke();
 g.fillStyle='#1a1450';g.font='700 9px Georgia,serif';g.textAlign='center';g.textBaseline='middle';
 for(let i=0;i<12;i++){const a=i*Math.PI/6-Math.PI/2,r=29;if(i%3===0){g.fillText(['XII','III','VI','IX'][i/3],Math.cos(a)*r,Math.sin(a)*r)}else{g.lineWidth=1.4;g.beginPath();g.moveTo(Math.cos(a)*31,Math.sin(a)*31);g.lineTo(Math.cos(a)*35,Math.sin(a)*35);g.stroke()}}
 /* maw bites into the lower-left of the face */
 const my=14+lg*8,mo=7+lg*10+Math.sin(t*4)*2;g.save();g.beginPath();g.arc(0,0,36,0,TAU);g.clip();
 g.fillStyle='#08041c';g.beginPath();g.moveTo(-40-lg*6,my-mo);g.quadraticCurveTo(-14,my-mo-10,8,my-mo+2);g.lineTo(6,my+mo+2);g.quadraticCurveTo(-14,my+mo+12,-40-lg*6,my+mo);g.closePath();g.fill();
 g.fillStyle='#ff4d6d55';g.beginPath();g.ellipse(-14,my,16,mo*.7,0,0,TAU);g.fill();
 g.fillStyle='#fff';for(let i=0;i<5;i++){const x=-34+i*8;poly(g,[x,my-mo+1,x+4,my-mo+1,x+2,my-mo+9],'#fff');poly(g,[x+3,my+mo+1,x+7,my+mo+1,x+5,my+mo-8],'#fff')}g.restore();
 /* hands */
 g.lineCap='round';g.strokeStyle='#1a1450';g.lineWidth=3.4;g.beginPath();g.moveTo(0,0);g.lineTo(Math.cos(t*3)*30,Math.sin(t*3)*30);g.stroke();g.lineWidth=2.6;g.beginPath();g.moveTo(0,0);g.lineTo(Math.cos(t*.5)*20,Math.sin(t*.5)*20);g.stroke();ell(g,0,0,3.4,3.4,br);
 /* glass glare */
 g.globalAlpha=.35;g.fillStyle='#fff';g.beginPath();g.ellipse(-12,-22,18,8,-.5,0,TAU);g.fill();g.globalAlpha=1;
 for(let i=0;i<3;i++){const a=-t*1.1+i*2.1;g.fillStyle='#fff';g.globalAlpha=.8;g.fillRect(Math.cos(a)*(58+i*5)-1.5,Math.sin(a)*(58+i*5)-1.5,3,3)}g.globalAlpha=1;g.restore()};

/* 9. Cosmic Behemoth: a brute with a small planet for a belly and a ring of rubble */
AD.abehemoth=(g,t,o)=>{const lg=(o&&o.lg)||0,s=Math.sin(t*2.4),b=Math.abs(Math.cos(t*2.4))*2.4,c='#7209b7',d='#240640';g.save();g.lineJoin='round';g.lineCap='round';
 limb(g,12,-76,18+s*5,-40,30,shade(d,-.1));limb(g,18+s*5,-40,22+s*9,-8,26,shade(d,-.1));poly(g,[2+s*9,0,48+s*9,0,44+s*9,-18,6+s*9,-18],'#120224','#000',2);
 limb(g,-14,-76,-20-s*5,-40,32,d);limb(g,-20-s*5,-40,-24-s*9,-8,27,shade(d,.1));poly(g,[-50-s*9,0,-4-s*9,0,-8-s*9,-18,-46-s*9,-18],'#1a0430','#000',2);
 g.translate(0,-b);
 ell(g,0,-130,54,66,rgr(g,-14,-150,6,92,shade(c,.3),d));g.strokeStyle='#000a';g.lineWidth=2;g.beginPath();g.ellipse(0,-130,54,66,0,0,TAU);g.stroke();
 g.save();g.beginPath();g.ellipse(0,-130,54,66,0,0,TAU);g.clip();g.fillStyle='#ffffff14';for(const [x,y,r] of[[-20,-150,14],[16,-110,10],[-8,-96,8],[26,-160,7]]){g.beginPath();g.arc(x,y,r,0,TAU);g.fill()}
 g.strokeStyle='#e0aaff55';g.lineWidth=5;for(let i=0;i<4;i++){g.beginPath();g.moveTo(-60,-170+i*20);g.quadraticCurveTo(0,-160+i*20,60,-176+i*20);g.stroke()}g.restore();
 asRing(g,0,-124,98,16,-.2,'#c77dff',5);g.save();g.beginPath();g.rect(-110,-124,220,40);g.clip();g.restore();
 for(let i=0;i<9;i++){const a=t*.7+i*.7;ell(g,Math.cos(a)*98,-124+Math.sin(a)*16-Math.cos(-.2)*0,3+(i%3),3,'#e0c8ff')}
 limb(g,-40,-170,-70-lg*22,-130,34,d);limb(g,-70-lg*22,-130,-76-lg*26,-88,26,shade(d,.15));ell(g,-78-lg*26,-80,22,20,shade(d,.25));
 limb(g,38,-170,62,-130,30,shade(d,-.1));limb(g,62,-130,60,-96,24,shade(d,-.1));ell(g,60,-88,18,16,shade(d,.1));
 const hy=-206;ell(g,-4,hy,22,20,shade(d,.2));glow(g,-12,hy-2,14,'#ff70e0');eye(g,-12,hy-2,4,'#fff');eye(g,2,hy-4,3,'#fff');poly(g,[-18,hy+8,10,hy+8,6,hy+16,-14,hy+16],'#0a0014');g.restore()};

/* ---------- bosses ---------- */
/* Astraeus: a golden giant forged inside a dying star */
AD.bastraeus=(g,t,o)=>{const lg=(o&&o.lg)||0,fl=asTw(t,4),c='#ffd166',d='#7a4a10',b=Math.abs(Math.sin(t*1.6))*3;g.save();g.lineJoin='round';g.lineCap='round';
 for(let i=0;i<14;i++){const a=t*.25+i*TAU/14;g.globalAlpha=.14;poly(g,[0,-190,Math.cos(a)*300,-190+Math.sin(a)*300,Math.cos(a+.1)*300,-190+Math.sin(a+.1)*300],'#ffe8a0')}g.globalAlpha=1;
 limb(g,18,-110,26,-56,32,shade(d,-.1));limb(g,26,-56,30,-10,28,shade(d,-.1));poly(g,[10,0,62,0,56,-20,16,-20],'#3a2208','#000',2);
 limb(g,-18,-110,-26,-56,34,d);limb(g,-26,-56,-30,-10,30,shade(d,.1));poly(g,[-60,0,-6,0,-12,-20,-54,-20],'#4a2a0a','#000',2);
 g.translate(0,-b);
 g.save();g.translate(20,-196);g.rotate(.5);for(let i=0;i<5;i++){const a=-Math.PI/2+(i-2)*.2;g.fillStyle=i%2?'#ffe9b0':'#ff9a3a';g.globalAlpha=.55;poly(g,[0,0,Math.cos(a)*30,Math.sin(a)*30-170,Math.cos(a+.1)*30,Math.sin(a+.1)*30-170],'#ffe0a0')}g.globalAlpha=1;g.restore();
 poly(g,[-46,-130,46,-132,52,-224,-50,-226],hgr(g,-50,52,shade(c,-.2),d),'#000a',3);poly(g,[-46,-130,46,-132,40,-112,-40,-112],shade(c,.2),'#000a',2);
 glow(g,0,-176,64,'#fff3b8'+hwA(.75*fl));ell(g,0,-176,26,26,rgr(g,-6,-182,2,30,'#fffbe8','#ffb02e'));for(let i=0;i<8;i++){const a=t*1.4+i*TAU/8;poly(g,[Math.cos(a)*24,-176+Math.sin(a)*24,Math.cos(a+.2)*38,-176+Math.sin(a+.2)*38,Math.cos(a-.2)*38,-176+Math.sin(a-.2)*38],'#fff1b0')}
 ell(g,-56,-218,28,22,shade(c,.1));ell(g,56,-218,28,22,shade(c,.1));poly(g,[-70,-226,-36,-252,-34,-216],'#ffe9a0','#000a',1.6);poly(g,[70,-226,36,-252,34,-216],'#ffe9a0','#000a',1.6);
 limb(g,52,-212,76,-160,26,d);limb(g,76,-160,70,-116,22,shade(d,.1));ell(g,70,-108,17,15,shade(c,-.1));
 const sx=-86-lg*34;limb(g,-52,-212,-72,-170,28,d);limb(g,-72,-170,sx,-170+lg*-20,24,shade(d,.1));
 g.save();g.translate(sx-6,-176-lg*20);g.rotate(-.3-lg*.9+Math.sin(t*1.6)*.05);poly(g,[-6,30,6,30,5,-170,0,-210,-5,-170],hgr(g,-6,6,'#fff6d0','#ffb02e'),'#000a',2);poly(g,[-26,-30,26,-30,22,-18,-22,-18],c,'#000a',2);glow(g,0,-110,36,'#ffe8a0'+hwA(.5*fl));g.restore();
 g.save();g.translate(0,-250);ell(g,0,0,28,31,rgr(g,-6,-8,2,36,'#ffe9a8',shade(c,-.3)));poly(g,[-24,-6,24,-6,22,6,-22,6],'#1a1020');g.fillStyle='#fff6c0';g.fillRect(-18,-3,13,3);g.fillRect(5,-3,13,3);glow(g,0,0,12,'#fff8');
 for(let i=0;i<9;i++){const a=-Math.PI/2+(i-4)*.2,r2=i%2?38:52;poly(g,[Math.cos(a-.1)*28,Math.sin(a-.1)*30,Math.cos(a)*r2,Math.sin(a)*r2,Math.cos(a+.1)*28,Math.sin(a+.1)*30],'#ffd166','#000a',1)}g.restore();
 for(let i=0;i<6;i++){const a=t*.9+i*1.05;g.globalAlpha=asTw(t*1.5+i,4);asStar(g,Math.cos(a)*110,-170+Math.sin(a)*60,5,'#fff6c0',4)}g.globalAlpha=1;g.restore()};

/* Nyx: the eclipse given a body, a black sun with a burning rim behind a cloaked queen */
AD.bnyx=(g,t,o)=>{const lg=(o&&o.lg)||0,fl=asTw(t,3.6),hv=Math.sin(t*1.3)*8,c='#f72585',d='#12041c';g.save();g.lineJoin='round';g.lineCap='round';g.translate(0,hv);
 glow(g,6,-240,150,c+hwA(.55*fl));ell(g,6,-240,64,64,'#020006');g.strokeStyle='#ffd0ea';g.lineWidth=3;g.beginPath();g.arc(6,-240,64,0,TAU);g.stroke();
 for(let i=0;i<22;i++){const a=i*TAU/22+t*.2,l=70+(i%3)*16+Math.sin(t*3+i)*5;g.globalAlpha=.6;g.strokeStyle=i%2?'#ff9ad0':c;g.lineWidth=2.4;g.beginPath();g.moveTo(6+Math.cos(a)*66,-240+Math.sin(a)*66);g.lineTo(6+Math.cos(a)*l,-240+Math.sin(a)*l);g.stroke()}g.globalAlpha=1;
 poly(g,[-18,-210,28,-212,60,-120].concat(gyHem(74,-76,-4,12,9,t,2),[-52,-130]),hgr(g,-76,74,shade(d,.5),d),'#000a',2.4);
 g.strokeStyle=c;g.lineWidth=2;g.globalAlpha=.55;for(let i=0;i<5;i++){g.beginPath();g.moveTo(-20+i*14,-196);g.quadraticCurveTo(-26+i*18+Math.sin(t*2+i)*4,-100,-34+i*22,-12);g.stroke()}g.globalAlpha=1;
 poly(g,[-52,-196,-90,-168,-84,-132,-50,-152],shade(d,.2),'#000a',2);poly(g,[54,-196,92,-168,86,-132,52,-152],shade(d,.2),'#000a',2);
 const ax=-98-lg*34;limb(g,-70,-176,ax+14,-150,16,d);ell(g,ax,-152,9,9,'#ffd6ea');
 limb(g,70,-176,100,-146,16,d);ell(g,104,-142,9,9,'#ffd6ea');
 g.save();g.translate(ax-4,-152);g.rotate(-.15-lg*.5);g.strokeStyle='#d8b8e8';g.lineWidth=4;g.beginPath();g.moveTo(0,90);g.lineTo(0,-120);g.stroke();g.strokeStyle=c;g.lineWidth=7;g.beginPath();g.arc(-6,-130,22,-1.2,1.2,false);g.stroke();glow(g,-10,-130,34,c+'88');g.restore();
 g.save();g.translate(6,-222);ell(g,0,0,24,28,rgr(g,-4,-8,2,32,'#3a1858',d));poly(g,[-26,-8,0,-44,26,-8,18,16,-18,16],hgr(g,-26,26,shade(d,.4),d),'#000a',1.8);ell(g,0,2,16,18,'#08000e');
 glow(g,-7,-1,10,c);glow(g,8,-1,10,c);ell(g,-7,-1,5,3.4,'#fff');ell(g,8,-1,5,3.4,'#fff');eye(g,-7,-1,1.8,c);eye(g,8,-1,1.8,c);g.restore();
 asStar(g,6,-280,8,'#ffd0ea',4);g.restore()};

/* Chronos: a sovereign woven from time. A robe of deep space, a hand-wound hourglass heart, a halo of turning clocks and echoes of himself a second behind */
AD.bchronos=(g,t,o)=>{const lg=(o&&o.lg)||0,fl=asTw(t,3),c='#00f5d4',gd='#ffd98a',gd2='#a8741c',dp='#07123a',hv=Math.sin(t*1.3)*7,rom=['XII','I','II','III','IV','V','VI','VII','VIII','IX','X','XI'];g.save();g.lineJoin='round';g.lineCap='round';
 const HX=0,HY=-206;
 /* halo: gear ring, numeral ring, sweeping hands */
 g.save();g.translate(HX,HY+hv);
 glow(g,0,0,230,c+hwA(.22*fl));
 for(let k=0;k<3;k++){const R=150+k*34,sp=(k%2?-1:1)*(.18+k*.08);g.save();g.rotate(t*sp);g.strokeStyle=k===1?gd:c;g.globalAlpha=.55-k*.1;g.lineWidth=k===1?3:2;g.beginPath();g.arc(0,0,R,0,TAU);g.stroke();
  if(k===0){g.fillStyle=c;for(let i=0;i<40;i++){g.save();g.rotate(i*TAU/40);g.globalAlpha=.5;g.fillRect(R-4,-2.5,10,5);g.restore()}}
  if(k===1){g.globalAlpha=.8;g.fillStyle=gd;g.font='700 17px Georgia,serif';g.textAlign='center';g.textBaseline='middle';for(let i=0;i<12;i++){g.save();g.rotate(i*TAU/12);g.translate(0,-R+14);g.fillText(rom[i],0,0);g.restore()}}
  if(k===2){g.globalAlpha=.45;g.setLineDash([3,9]);g.beginPath();g.arc(0,0,R-12,0,TAU);g.stroke();g.setLineDash([])}
  g.restore()}
 g.globalAlpha=.9;const ha=(a,l,w,col)=>{g.strokeStyle=col;g.lineWidth=w;g.beginPath();g.moveTo(-Math.cos(a)*24,-Math.sin(a)*24);g.lineTo(Math.cos(a)*l,Math.sin(a)*l);g.stroke()};ha(t*.5-1.6,118,5,gd);ha(t*3-1.6,176,2.4,c);g.globalAlpha=1;g.restore();
 /* time echoes: the same silhouette a beat behind */
 for(let i=3;i>=1;i--){g.save();g.globalAlpha=.07+.03*(3-i);g.translate(i*34,hv*(1-i*.15)+Math.sin(t*2+i)*3);poly(g,[-38,-250,40,-250,56,-130,70,-6,-70,-6,-56,-130],i%2?c:'#8a7aff');g.restore()}
 g.translate(0,hv*.6);
 /* sand streaming up out of the hem: time running backwards */
 for(let i=0;i<30;i++){const u=(t*.38+i/30)%1,x=-70+rnd(i)*140+Math.sin(t*2+i)*8,y=-8-u*260;g.globalAlpha=Math.sin(u*Math.PI)*.85;ell(g,x,y,1.8+rnd(i+3)*1.6,1.8,i%3?gd:c)}g.globalAlpha=1;
 /* robe, with a galaxy inside */
 const rb=()=>{g.beginPath();g.moveTo(-34,-262);g.quadraticCurveTo(0,-278,34,-262);g.quadraticCurveTo(54,-196,64,-120);g.quadraticCurveTo(86,-50,76,-6);for(let i=0;i<=8;i++){const x=76-i*19,y=-6+(i%2?-12:2)+Math.sin(t*2+i)*2;g.lineTo(x,y)}g.quadraticCurveTo(-86,-50,-64,-120);g.quadraticCurveTo(-54,-196,-34,-262);g.closePath()};
 rb();g.fillStyle=vgr(g,-270,0,'#16226a',dp);g.fill();
 g.save();rb();g.clip();
 for(let i=0;i<3;i++){const x=-30+i*30+Math.sin(t*.3+i)*10,y=-150+i*14;const gg=g.createRadialGradient(x,y,2,x,y,70);gg.addColorStop(0,['#7a5cff55','#00f5d455','#ff70c855'][i]);gg.addColorStop(1,'#0000');g.fillStyle=gg;g.fillRect(-100,-290,200,300)}
 g.save();g.translate(0,-120);g.rotate(t*.18);g.strokeStyle='#bfe8ff';g.globalAlpha=.4;g.lineWidth=1.4;for(let a=0;a<2;a++){g.beginPath();for(let r=4;r<90;r+=3){const th=r*.09+a*Math.PI;g.lineTo(Math.cos(th)*r*.8,Math.sin(th)*r*.5)}g.stroke()}g.restore();
 for(let i=0;i<46;i++){const x=-70+rnd(i+40)*140,y=-270+rnd(i+80)*260;g.globalAlpha=asTw(t*1.4+i,3+rnd(i)*3)*.9;g.fillStyle='#fff';g.fillRect(x,y,1.6,1.6)}g.globalAlpha=1;
 g.restore();
 rb();g.strokeStyle='#000c';g.lineWidth=3;g.stroke();
 /* gold trim down the front and along the hem */
 g.strokeStyle=gd;g.lineWidth=3;g.beginPath();g.moveTo(0,-250);g.lineTo(0,-6);g.stroke();g.strokeStyle=gd2;g.lineWidth=1;g.beginPath();g.moveTo(3,-250);g.lineTo(3,-6);g.stroke();
 for(let i=0;i<5;i++){const y=-228+i*30;poly(g,[0,y-6,5,y,0,y+6,-5,y],gd,'#000a',.8)}
 /* hourglass heart */
 const hgx=0,hgy=-168;glow(g,hgx,hgy,64,c+hwA(.55*fl));
 poly(g,[-20,hgy-34,20,hgy-34,4,hgy,20,hgy+34,-20,hgy+34,-4,hgy],'#06182a99','#d8fff9',2.4);
 const top=(1-((t*.14)%1)),sandT=Math.max(0,top),sandB=1-sandT;
 g.save();g.beginPath();g.moveTo(-18,hgy-32);g.lineTo(18,hgy-32);g.lineTo(3,hgy);g.lineTo(-3,hgy);g.closePath();g.clip();g.fillStyle=gd;g.fillRect(-20,hgy-32+(1-sandT)*32,40,32*sandT);g.restore();
 g.save();g.beginPath();g.moveTo(-3,hgy);g.lineTo(3,hgy);g.lineTo(18,hgy+32);g.lineTo(-18,hgy+32);g.closePath();g.clip();g.fillStyle=gd;g.fillRect(-20,hgy+32-32*sandB,40,32*sandB);g.restore();
 g.strokeStyle=gd;g.lineWidth=1.4;g.beginPath();g.moveTo(0,hgy);g.lineTo(0,hgy+32-32*sandB);g.stroke();
 g.fillStyle=gd;g.fillRect(-24,hgy-38,48,6);g.fillRect(-24,hgy+32,48,6);g.strokeStyle='#000a';g.lineWidth=1;g.strokeRect(-24,hgy-38,48,6);g.strokeRect(-24,hgy+32,48,6);
 /* shoulders: drifting plates of gold */
 for(const sx of[-1,1]){g.save();g.translate(sx*58,-236+Math.sin(t*1.6+sx)*3);g.rotate(sx*.35);poly(g,[-22,-6,22,-6,26,6,0,22,-26,6],hgr(g,-26,26,gd,gd2),'#000a',2);glow(g,0,2,14,c+'66');g.restore()}
 /* detached hands */
 const hand=(x,y,rot,open,sc,fl)=>{g.save();g.translate(x,y);g.rotate(rot);g.scale(sc*(fl?-1:1),sc);
  poly(g,[-26,-13,-12,-13,-12,13,-26,13],hgr(g,-26,-12,gd2,gd),'#000a',1.6);
  for(let i=0;i<4;i++){const y0=-9+i*6,an=(i-1.5)*.2*open,l1=12+(i===1||i===2?3:0),x1=-6+6+Math.cos(an)*l1,y1=y0+Math.sin(an)*l1,an2=an+.3*open,x2=x1+Math.cos(an2)*10,y2=y1+Math.sin(an2)*10;limb(g,4,y0,x1+6,y1,4.6,shade(gd,-.05));limb(g,x1+6,y1,x2+6,y2,3.6,gd);ell(g,x2+6,y2,2.4,2.4,shade(gd,.3));ell(g,x1+6,y1,2,2,gd2)}
  poly(g,[-12,-12,8,-13,12,0,8,13,-12,12],hgr(g,-12,12,shade(gd,.25),gd2),'#000a',1.6);limb(g,-2,-10,8,-24*open-2,4.6,gd);ell(g,8,-24*open-2,2.4,2.4,shade(gd,.3));
  g.strokeStyle='#000a';g.lineWidth=1;g.beginPath();g.moveTo(-6,-4);g.lineTo(6,-4);g.moveTo(-6,4);g.lineTo(6,4);g.stroke();glow(g,0,0,20,c+'88');ell(g,-1,0,4,4,'#e8fffb');g.restore()};
 const fx=-96-lg*40,fy=-186-lg*20;
 /* the front hand holds a pocket-watch sun that ticks */
 hand(fx,fy,.25+lg*.3,1.1,1.2,1);
 {const px=fx-16,py=fy-40;glow(g,px,py,52,c+hwA(.6*fl));ell(g,px,py,24,24,hgr(g,px-24,px+24,gd,gd2));ell(g,px,py,19,19,'#e8fffb');for(let i=0;i<12;i++){const a=i*Math.PI/6;g.strokeStyle='#04302c';g.lineWidth=i%3?1:2;g.beginPath();g.moveTo(px+Math.cos(a)*15,py+Math.sin(a)*15);g.lineTo(px+Math.cos(a)*18,py+Math.sin(a)*18);g.stroke()}
  g.strokeStyle='#04302c';g.lineWidth=2;g.beginPath();g.moveTo(px,py);g.lineTo(px+Math.cos(t*6)*15,py+Math.sin(t*6)*15);g.stroke();g.beginPath();g.moveTo(px,py);g.lineTo(px+Math.cos(t*.8)*9,py+Math.sin(t*.8)*9);g.stroke();ell(g,px,py-28,4,5,gd)}
 hand(94,-196,-.3,.9,1.05,0);
 /* the mask: a gold oval, one slit, an eye that is a clock */
 g.save();g.translate(0,-292+Math.sin(t*1.5)*3);
 for(let i=0;i<7;i++){const a=t*.9+i*TAU/7,x=Math.cos(a)*50,y=Math.sin(a)*13-6,fr=Math.sin(a)>0?1:.55;g.save();g.globalAlpha=fr;g.translate(x,y);g.rotate(Math.cos(a)*.5);poly(g,[-6,-9,6,-9,2,0,6,9,-6,9,-2,0],gd,'#000a',1);g.restore()}
 g.beginPath();g.ellipse(0,0,25,32,0,0,TAU);g.fillStyle=hgr(g,-25,25,shade(gd,.35),gd2);g.fill();g.strokeStyle='#000b';g.lineWidth=2;g.stroke();
 g.strokeStyle=gd2;g.lineWidth=1.2;g.beginPath();g.moveTo(0,-30);g.lineTo(0,-14);g.moveTo(-14,14);g.quadraticCurveTo(0,26,14,14);g.stroke();
 poly(g,[-19,-19,-5,-21,-4,-16,-18,-13],'#0a0a20');poly(g,[5,-21,19,-19,18,-13,4,-16],'#0a0a20');
 glow(g,0,2,22,c+'aa');ell(g,0,2,11,11,'#e8fffb');g.strokeStyle='#04302c';g.lineWidth=1.4;g.beginPath();g.arc(0,2,11,0,TAU);g.stroke();g.beginPath();g.moveTo(0,2);g.lineTo(Math.cos(t*4)*9,2+Math.sin(t*4)*9);g.stroke();g.beginPath();g.moveTo(0,2);g.lineTo(Math.cos(t*.6)*6,2+Math.sin(t*.6)*6);g.stroke();
 for(let i=0;i<5;i++){const a=-Math.PI/2+(i-2)*.34;poly(g,[Math.cos(a-.1)*26,Math.sin(a-.1)*32,Math.cos(a)*(i%2?44:56),Math.sin(a)*(i%2?44:56)-4,Math.cos(a+.1)*26,Math.sin(a+.1)*32],gd,'#000a',1.2)}
 g.restore();g.restore()};

/* Star Mote: the small thing every Astral summoner casts off, so no goblin wanders into the heavens */
AD.astmote=(g,t,o)=>{const lg=(o&&o.lg)||0,sw=Math.sin(t*9),b=Math.abs(Math.cos(t*9))*3,c='#9ad8ff',d='#1a2a6a';g.save();g.lineJoin='round';g.lineCap='round';
 for(let i=0;i<6;i++){const u=(t*.9+i/6)%1;g.globalAlpha=(1-u)*.7;ell(g,16+u*30,-34-u*10+Math.sin(i*3)*4,3*(1-u)+1,3*(1-u)+1,i%2?'#fff':c)}g.globalAlpha=1;
 limb(g,-6,-16,-8+sw*5,-8,6,shade(d,.1));limb(g,-8+sw*5,-8,-10+sw*8,-1,5,shade(d,.1));limb(g,6,-16,8-sw*5,-8,6,d);limb(g,8-sw*5,-8,10-sw*8,-1,5,d);
 g.translate(0,-b);glow(g,0,-34,46,c+'66');
 g.save();g.translate(0,-34);g.rotate(t*.8);for(let i=0;i<4;i++){g.save();g.rotate(i*Math.PI/2);poly(g,[-5,-20,0,-36,5,-20],'#e8f6ff','#000a',1);g.restore()}g.restore();
 ell(g,0,-34,21,20,rgr(g,-6,-42,2,28,'#ffffff',shade(c,-.3)));g.strokeStyle='#000a';g.lineWidth=1.6;g.beginPath();g.ellipse(0,-34,21,20,0,0,TAU);g.stroke();
 limb(g,-18,-30,-30-lg*10,-26,4,c);limb(g,18,-30,26,-24,4,shade(c,-.2));
 ell(g,-6-lg*4,-36,8,9,'#0a1030');eye(g,-6-lg*4,-36,4,'#fff');ell(g,-7-lg*4,-36,2,2.6,'#0a1030');
 g.strokeStyle='#0a1030';g.lineWidth=2;g.beginPath();g.arc(-4-lg*3,-24,5,.2,Math.PI-.2);g.stroke();g.restore()};
const ASM={
 astmote:{n:'Star Mote',h:84,sp:100,th:78,ds:'A spark the size of a thought, shed by anything that dwells too long among the stars. Summoners call it by name.'},
 astalker:{n:'Cosmic Stalker',h:112,sp:60,th:100,tr:'charge',ds:'A panther of pressed star-dust. It does not hunt by scent, but by the light you give off.'},
 awisp:{n:'Astral Wisp',h:100,sp:122,th:100,fly:1,ds:'A small star that wandered out of its constellation and is looking for a new one to join.'},
 asentinel:{n:'Celestial Sentinel',h:230,sp:30,th:170,tr:'shield',ds:'It has guarded the threshold for longer than there have been stars to guard it from.'},
 aweaver:{n:'Void Weaver',h:180,sp:40,th:166,tr:'summon',ds:'Spins a net from the dark between stars and calls whatever gets caught in it.'},
 adrake:{n:'Nova Drake',h:118,sp:104,th:130,fly:1,pj:'fire',ds:'Its wings are plasma. It breathes the last second of a dying sun.'},
 aconstruct:{n:'Ethereal Construct',h:220,sp:30,th:170,tr:'shield',ds:'Blocks of crystal held together by one blue thought. Break the thought and the blocks forget.'},
 ahorror:{n:'Dimensional Horror',h:172,sp:42,th:150,ds:'Something from a room that does not exist. Its mouth is a tear and the stars inside it are falling.'},
 adevourer:{n:'Chrono Devourer',h:150,sp:84,th:140,fly:1,tr:'blink',ds:'It eats minutes. The ones it takes from you are always the ones you needed.'},
 abehemoth:{n:'Cosmic Behemoth',h:260,sp:26,th:230,tr:'shield',ds:'A small planet with opinions. Its rings are mostly the rubble of people who disagreed.'},
 bastraeus:{n:'Astraeus, The Star-Forged',h:380,sp:52,th:330,tw:380,boss:1,cx:20,ds:'Hammered together inside a dying star. He wears what is left of it as a crown.'},
 bnyx:{n:'Nyx, Queen of the Eclipse',h:390,sp:48,th:340,tw:380,boss:1,ds:'She stands in front of the sun and decides that it is now night.'},
 bchronos:{n:'Chronos, Sovereign of Infinity',h:400,sp:46,th:350,tw:380,boss:1,ds:'He is every second at once. Yours are the ones he is holding right now.'}};
Object.assign(DR,AD);Object.assign(MON,ASM);for(const k in AD)MON[k].d=AD[k];
Object.assign(ROARK,{bastraeus:'thunder',bnyx:'screech',bchronos:'deep'});
const AST_MOBS=[['astalker','aweaver','ahorror'],['awisp','adrake','adevourer'],['asentinel','aconstruct','abehemoth']];
const AST_X=['dusk','nova','star','orbit','comet','halo','flare','void','lunar','solar','pulsar','quasar','aether','zenith','gleam','beam','warp','rift','aeon','cosmic','galaxy','meteor','eclipse','vortex','photon','plasma','stellar','gravity','horizon','starfall','twilight','moonlit','sunburst','spiral','orbital','eternal','ascend','radiant','endless','beyond'];
const ASTRAL=[
 {i:35,ast:1,n:'Starlight Threshold',z:0,tint:'#c77dff',sky:['#03001e','#240046'],wx:'',prop:'',m:['astalker','awisp','asentinel'],b:'bastraeus',bn:'Astraeus, The Star-Forged',bl:'astraeus the star-forged',pl:'the starlight threshold',hue:0,blurb:'The first gate of the heavens. Whatever guards it was forged to keep you out.',a:'#ffd166',
  w:['starlight','supernova','celestial','astral','lightspeed','nebula','cosmos','infinity','radiance']},
 {i:36,ast:1,n:'Nebula Rift',z:0,tint:'#f72585',sky:['#12001c','#3a0a4e'],wx:'',prop:'',m:['aweaver','adrake','aconstruct'],b:'bnyx',bn:'Nyx, Queen of the Eclipse',bl:'nyx the eclipse queen',pl:'the nebula rift',hue:0,blurb:'A tear in the sky where colour pours out. Something at the far end is blocking out the light.',a:'#f72585',
  w:['singularity','eventhorizon','eclipsed','graviton','darkmatter','pulsar','wormhole','hypernova']},
 {i:37,ast:1,n:'The Astral Throne',z:0,tint:'#00f5d4',sky:['#00131c','#0a2a5e'],wx:'',prop:'',m:['ahorror','adevourer','abehemoth'],b:'bchronos',bn:'Chronos, Sovereign of Infinity',bl:'chronos the sovereign',pl:'the astral throne',hue:0,blurb:'The seat at the end of everything. The one who sits in it has been waiting a very long time.',a:'#00f5d4',
  w:['transcendence','omnipresence','timewarp','eternity','multiverse','godslayer','existential','omnipotence']}];
ASTRAL.forEach(L=>{L.w=L.w.concat(AST_X)});

/* words: the attachment lists first, with short astral words mixed in so every monster length has a match */
{const pw=pickWord;pickWord=function(role,zi,d,on){if(!(S.camp>30)||Array.isArray(zi))return pw(role,zi,d,on);const L=lvDef(S.wave),GS=new Set(L.w);let w;for(let i=0;i<8;i++){w=pw(role,L.w,d,on);if(GS.has(w))return w}return w}}

/* ---------- background: deep space, one look per node ---------- */
function astBG(L,t){const c=ctx,k=L.i-35,N=[[['#8a5cff','#ffd166'],['#38a8e8','#ff70a6']],[['#f72585','#7209b7'],['#b5179e','#4cc9f0']],[['#00f5d4','#3f37c9'],['#4895ef','#7209b7']]][k];
 let g=c.createLinearGradient(0,0,0,GY);g.addColorStop(0,L.sky[0]);g.addColorStop(1,L.sky[1]);c.fillStyle=g;c.fillRect(0,0,W,H);
 c.save();c.globalCompositeOperation='lighter';
 for(let i=0;i<4;i++){const x=(i*.31+.12)*W+Math.sin(t*.07+i*2)*60,y=130+i*90+Math.cos(t*.09+i)*30,r=380+i*60,col=N[i%2][i>>1&1]||N[0][0];g=c.createRadialGradient(x,y,10,x,y,r);g.addColorStop(0,col+'3a');g.addColorStop(.5,col+'16');g.addColorStop(1,col+'00');c.fillStyle=g;c.fillRect(0,0,W,GY)}
 c.restore();
 for(let layer=0;layer<3;layer++){const n=60+layer*30,sp=3+layer*5;for(let i=0;i<n;i++){const x=(rnd(i+layer*200)*W-t*sp+W*2)%W,y=rnd(i+layer*200+77)*(GY-40),tw=.4+.6*Math.abs(Math.sin(t*(.6+rnd(i)*1.6)+i)),r=.6+layer*.55+rnd(i+9)*.8;c.globalAlpha=tw*(.4+layer*.2);c.fillStyle=rnd(i+5)<.2?'#ffd9a8':rnd(i+6)<.4?'#bfe8ff':'#fff';c.beginPath();c.arc(x,y,r,0,TAU);c.fill();if(layer==2&&rnd(i+3)<.25){c.fillRect(x-4,y-.4,8,.8);c.fillRect(x-.4,y-4,.8,8)}}}c.globalAlpha=1;
 const P1=[[W*.78,190,92,'#ffd9a0','#7a4a2a',1],[W*.2,250,74,'#b8d8ff','#2a3a6a',0],[W*.55,150,120,'#e8c8ff','#3a1a5a',1]][k];
 {const [x,y,r,c1,c2,rg]=P1,ring=h=>{c.save();c.translate(x,y);c.rotate(-.3);c.strokeStyle=c1+'99';c.lineWidth=r*.12;c.beginPath();c.ellipse(0,0,r*1.7,r*.34,0,h?0:Math.PI,h?Math.PI:TAU);c.stroke();c.restore()};
  if(rg)ring(0);g=c.createRadialGradient(x-r*.35,y-r*.35,r*.1,x,y,r*1.1);g.addColorStop(0,c1);g.addColorStop(1,c2);c.save();c.shadowColor=c1;c.shadowBlur=60;c.fillStyle=g;c.beginPath();c.arc(x,y,r,0,TAU);c.fill();c.restore();if(rg)ring(1)}
 /* floor: a pane of starlit glass */
 c.save();c.beginPath();c.rect(0,0,W,H);c.clip();
 g=c.createLinearGradient(0,GY-6,0,H);g.addColorStop(0,N[0][0]+'66');g.addColorStop(.12,'#0a0620');g.addColorStop(1,'#02000a');c.fillStyle=g;c.fillRect(0,GY-6,W,H-GY+6);
 c.strokeStyle=N[0][0]+'44';c.lineWidth=1;for(let i=-12;i<=12;i++){c.beginPath();c.moveTo(W/2+i*40,GY);c.lineTo(W/2+i*190,H);c.stroke()}for(let i=0;i<7;i++){const y=GY+Math.pow((i+((t*.35)%1))/7,2)*(H-GY);c.beginPath();c.moveTo(0,y);c.lineTo(W,y);c.stroke()}
 c.globalAlpha=.8;g=c.createLinearGradient(0,GY-3,0,GY+14);g.addColorStop(0,N[0][0]+'cc');g.addColorStop(1,N[0][0]+'00');c.fillStyle=g;c.fillRect(0,GY-3,W,17);c.globalAlpha=1;
 for(let i=0;i<26;i++){const x=(rnd(i+500)*W+Math.sin(t*.5+i)*24)%W,y=GY+20+rnd(i+520)*(H-GY-30),f=Math.abs(Math.sin(t*1.3+i*1.7));c.globalAlpha=f*.7;c.fillStyle='#fff';c.fillRect(x,y,2,2)}c.globalAlpha=1;c.restore();
 /* drifting motes in front */
 for(let i=0;i<28;i++){const u=(t*(.03+rnd(i)*.04)+rnd(i+3))%1,x=(rnd(i+2)*W+Math.sin(t*.6+i)*40)%W,y=GY-30-u*(GY-60);c.globalAlpha=Math.sin(u*Math.PI)*.6;c.fillStyle=N[i%2][0];c.beginPath();c.arc(x,y,1.6+rnd(i+4)*2,0,TAU);c.fill()}c.globalAlpha=1}
{const z0=zoneBG;zoneBG=function(zi,t,L){if(L&&L.ast){ctxT=t;return astBG(L,t)}return z0.apply(this,arguments)}}

/* ---------- progress, difficulty, payout ---------- */
const AST_DIFF=1.35,AST_PAY=.55;const astDiff=()=>AST_DIFF*(S.camp<33?1.1:1);/* levels 31 and 32 get a further 10% *//* Astral levels: 35% harder, 45% less gold */
const AP=()=>P.ast||(P.ast={cl:0,stars:{},best:{}});
const astAct5=()=>!!(P.stars&&P.stars[30]);/* Act V must be finished to enter Act VI */
const astOpen=k=>astAct5()&&(k===0||AP().cl>=k);
const astMul=()=>1+.5*(P.pres||0);
{const sw0=startWave;startWave=function(){const r=sw0.apply(this,arguments);if(S.camp>30){if(S.ban&&S.round===1)S.ban.sub='Act VI: Astral Ascendance';S.spawnLeft=Math.ceil(S.spawnLeft*astDiff());if(S.camp===33&&S.ban&&S.round===1)S.ban.c='#ffd166'}return r}}
{const nb0=newBossLine;newBossLine=function(e,msg){const r=nb0.apply(this,arguments);if(S.camp>30&&e.tmax){e.tmax/=astDiff();e.tm=e.tmax}return r}}
{const s0=start;start=function(n,kind){astMusicBack();const r=s0.apply(this,arguments);if(S.camp>30)S.gm*=astMul()*AST_PAY;return r}}
{const o0=over;over=function(q){if(S.camp>30&&S.mode!=='over'&&!S.dc&&!S.rift&&!S.prac&&!S.gy)return astOver(q);return o0.apply(this,arguments)}}
{const v0=victory;victory=function(){if(S.camp>30)return astVictory();return v0.apply(this,arguments)}}
function astOver(quit){S.mode='over';const n=S.camp,A=AP(),xp=Math.round((S.score/16+S.wave*8)*(1+.1*U('scholar')+.1*(P.pres||0)+(S.xpm||0))),l0=finishRun(),wxm=wxpEnd();
 P.xp+=xp;A.best[n]=Math.max(A.best[n]||0,S.score);save();jingle('lose');const l1=lvl(P.xp),cr=S.runC||0,lg=levelGold(l0,l1);save();
 const later=()=>{show(`<h2>The stars have gone out</h2>${resBlock()}<p>Astral level ${n}: ${esc(ASTRAL[n-31].n)}, round ${S.round} of 5.${S.by&&!quit?` Slain by ${esc(S.by)}.`:''} Earned ${xp} XP, ${S.gold+lg} gold and ${cr} crate${cr===1?'':'s'}.${wxm}${l1>l0?`<br><b style="color:var(--gold)">Level up! You are now level ${l1}, ${rankOf(l1)}. Bonus: ${lg} gold.</b>`:''}${pathMsg(l0,l1)}</p><div class="row"><button id="go">Rise again</button><button class="sm" id="am">Astral levels</button><button class="sm" id="hm">Home</button></div>`);
  $('go').onclick=()=>start(n);$('am').onclick=()=>astralMenu();$('hm').onclick=title};
 if(quit)later();else{S.pose='dead';S.poseT=0;S.landed=0;S.late=later;S.lateAt=2.2}}
function astVictory(){S.mode='over';const n=S.camp,A=AP(),k=n-31,prev=!!A.stars[n],xp=Math.round((S.score/12+n*40)*(1+.1*U('scholar')+.1*(P.pres||0)+(S.xpm||0))),stars=1+(S.dmgTaken<=2?1:0)+(S.dmgTaken===0?1:0),l0=finishRun(),wxm=wxpEnd();
 P.xp+=xp;A.cl=Math.max(A.cl,k+1);A.stars[n]=Math.max(A.stars[n]||0,stars);A.best[n]=Math.max(A.best[n]||0,S.score);save();jingle('win');
 const vg=Math.round((140+n*10+stars*40)*(prev?.5:1)*(S.gsA||1)*astMul()*AST_PAY);P.gold+=vg;const l1=lvl(P.xp),cr=S.runC||0,lg=levelGold(l0,l1);save();
 S.pose='victory';S.poseT=0;const later=()=>{show(`<h1 style="font-size:100px">Ascended</h1><div style="font-size:64px;color:#c77dff;letter-spacing:10px;text-shadow:0 0 22px #c77dff">${'★'.repeat(stars)}<span style="opacity:.3">${'★'.repeat(3-stars)}</span></div><p>${esc(ASTRAL[k].bn)} falls. Level ${n} cleared${k===2?': the heavens are yours':''}.</p>${resBlock()}<p>Earned ${xp} XP, ${S.gold+vg+lg} gold and ${cr} crate${cr===1?'':'s'}.${wxm}${l1>l0?`<br><b style="color:var(--gold)">Level up! You are now level ${l1}, ${rankOf(l1)}. Bonus: ${lg} gold.</b>`:''}${pathMsg(l0,l1)}</p><div class="row">${k<2?'<button id="nx">Next level</button>':''}<button class="sm" id="am">Astral levels</button><button class="sm" id="hm">Home</button></div>`,'m');
  if($('nx'))$('nx').onclick=()=>start(n+1);$('am').onclick=()=>astralMenu();$('hm').onclick=title};
 try{btyClear()}catch(e){}S.late=later;S.lateAt=1.6}

/* ---------- boss intro: a warp, a constellation, a title card and a theme ---------- */
let AST_AUD=null,AST_MUTED=0;
function astMusicOff(){try{if(mg&&ac){AST_MUTED=1;mg.gain.cancelScheduledValues(ac.currentTime);mg.gain.setTargetAtTime(0,ac.currentTime,.12)}}catch(e){}}
function astMusicBack(){try{if(AST_MUTED&&mg&&ac){AST_MUTED=0;mg.gain.cancelScheduledValues(ac.currentTime);mg.gain.setTargetAtTime(ST.mute?0:ST.mvol*.6,ac.currentTime,.5)}}catch(e){}}
function astTheme(k){if(!axOn())return;const o=ac.createGain();o.gain.value=1;o.connect(sg);AST_AUD=o;const T=ac.currentTime+.05,nf=n=>440*2**((n-69)/12),R=[50,45,52][k],maj=k===0;
 cTone(o,T,nf(R-24),6.2,'sine',.2,{a:1.6,hold:1,r:1.4});cTone(o,T,nf(R-12),6.2,'sawtooth',.05,{a:1.8,hold:1,r:1.4,lp:500,lp2:1400});
 cNoise(o,T,2.4,.16,{type:'bandpass',f1:260,f2:6500,q:1.4,rev:1});
 /* rising pulse */
 const gap=k===2?.25:.3,pat=maj?[0,0,4,0,7,4,7,12]:[0,0,3,0,6,3,5,0];for(let i=0;i<8;i++){const tt=T+.15+i*gap,n=R+pat[i];cTone(o,tt,nf(n),.24,'square',.045+i*.004,{a:.01,lp:900+i*220,lp2:300});if(i%2===0)cTone(o,tt,nf(R-12),.3,'sine',.14,{f2:nf(R-24),a:.004})}
 if(k===2)for(let i=0;i<10;i++){const tt=T+i*.24*(1-i*.03);cTone(o,tt,3200+(i%2)*500,.04,'square',.03,{a:.001});cNoise(o,tt,.03,.05,{type:'highpass',f1:6000,f2:6000})}
 cTimp(o,T+1.2,6,.2*(k===2?1.2:1),.15);
 [0,4,7,12].forEach((d,i)=>cChoir(o,T+1.1,nf(R+12+(maj?d:[0,3,7,12][i])),1.5,.02));
 /* the hit on the title */
 const H=T+2.45;cKick(o,H,.9,110,28,1.1);cNoise(o,H,1.4,.2,{type:'lowpass',f1:7000,f2:180});
 (maj?[0,7,12,16]:[0,7,12,15]).forEach((d,i)=>{cBrass(o,H+.02,nf(R+d),1.9,.06);cBell(o,H+.02+i*.1,nf(R+24+d),.06,3)});
 cBrass(o,H+.02,nf(R-12),2.2,.07);
 /* theme: a rising bell line with a choir swell */
 const mel=maj?[0,4,7,12,11,7,9,12]:[0,3,7,10,12,10,8,7];mel.forEach((d,i)=>cBell(o,H+.35+i*.3,nf(R+24+d),.055,2.2));
 [0,7,12,16].forEach(d=>cChoir(o,H+.3,nf(R+12+d+(maj?0:-(d===16?1:0))),3.2,.024));
 cSpark(o,H+.2,14,3,96,.028)}
function astThemeStop(){try{if(AST_AUD){const o=AST_AUD;AST_AUD=null;o.gain.setValueAtTime(o.gain.value,ac.currentTime);o.gain.linearRampToValueAtTime(0,ac.currentTime+.35);setTimeout(()=>{try{o.disconnect()}catch(e){}},500)}}catch(e){}}
{const c0=cineStart;cineStart=function(e){const r=c0.apply(this,arguments);if(S.camp>30&&S.cine){S.cine.dur=6.4;S.cine.ast=1;astMusicOff();try{astTheme(S.camp-31)}catch(x){}}return r}}
{const e0=cineEnd;cineEnd=function(){const c=S.cine;if(c&&c.ast){astThemeStop();astMusicBack()}return e0.apply(this,arguments)}}
{const t0=cineTick;cineTick=function(dt){const c=S.cine;t0.apply(this,arguments);if(c&&c.ast&&!c.hit&&c.t>2.45){c.hit=1;const e=c.e,col=lvDef(S.wave).a;S.flash=1;S.shake=44;
  for(const [r1,w,d,cc] of[[620,12,0,'#fff'],[480,8,.06,col],[340,5,.12,'#ffd98a']])S.fx.push({k:'ring',x:e.x,y:GY-e.h*.5,t:0,ml:1.1+d*4,c:cc,w,r0:10,r1});
  burst(e.x,GY-e.h*.5,col,70,{v:760,l:1.2,g:-20,s:5});burst(e.x,GY-e.h*.5,'#ffffff',40,{v:520,l:1,g:0,s:3})}}}
{const d0=drawCine;drawCine=function(){const c=S.cine;if(!c||!c.ast)return d0.apply(this,arguments);astCine(c)}}
function astCine(c){const g=ctx,t=c.t,e=c.e,L=lvDef(S.wave),k=S.camp-31,col=L.a,eo=easeO,bar=eo(t/.35)*(1-eo((t-(c.dur-.3))/.3))*H*.12,fo=1-eo((t-(c.dur-.4))/.35),cx=W*.64,cy=GY-e.h*.5-30;
 g.save();g.fillStyle='#000';g.fillRect(0,0,W,bar);g.fillRect(0,H-bar,W,bar);
 const gv=g.createRadialGradient(W/2,H/2,H*.3,W/2,H/2,H*.95);gv.addColorStop(0,'#0000');gv.addColorStop(1,`rgba(2,0,14,${.75*eo(t/.6)})`);g.fillStyle=gv;g.fillRect(0,0,W,H);
 /* warp streaks rush toward the boss, then burst */
 g.save();g.globalCompositeOperation='lighter';const wa=t<2.45?eo(t/1.2):Math.max(0,1-(t-2.45)/1.1);
 for(let i=0;i<90;i++){const a=rnd(i)*TAU,sp=.5+rnd(i+9)*1.2,u=t<2.45?((t*sp*.55+rnd(i+3))%1):((t-2.45)*sp*.9+.4),r0=(t<2.45?(1-u):u)*(260+rnd(i+5)*520)+30,r1=r0+(t<2.45?-1:1)*(30+rnd(i+7)*90)*wa;g.globalAlpha=wa*.55*(t<2.45?u:1-Math.min(1,u*.6));g.strokeStyle=rnd(i+2)<.3?'#fff':col;g.lineWidth=1+rnd(i+8)*1.8;g.beginPath();g.moveTo(cx+Math.cos(a)*r0,cy+Math.sin(a)*r0*.7);g.lineTo(cx+Math.cos(a)*r1,cy+Math.sin(a)*r1*.7);g.stroke()}g.restore();
 /* a constellation draws itself around the boss */
 const N=9,pr=eo((t-.4)/1.8),pts=[];for(let i=0;i<N;i++){const a=-Math.PI/2+i*TAU/N+t*.12,r=(i%2?210:290)*(.6+.4*eo(t/1.2));pts.push([cx+Math.cos(a)*r,cy+Math.sin(a)*r*.82])}
 g.save();g.globalAlpha=.85*fo;g.strokeStyle=col;g.lineWidth=2;g.shadowColor=col;g.shadowBlur=14;g.beginPath();const segs=pr*N;for(let i=0;i<=Math.floor(segs)&&i<N;i++){const p=pts[i],q=pts[(i+2)%N],f=Math.min(1,segs-i);if(i%1===0){g.moveTo(p[0],p[1]);g.lineTo(p[0]+(q[0]-p[0])*f,p[1]+(q[1]-p[1])*f)}}g.stroke();g.shadowBlur=0;
 pts.forEach((p,i)=>{if(i<=segs){const tw=asTw(t*2+i,5);glow(g,p[0],p[1],20*tw,col+'88');asStar(g,p[0],p[1],8+tw*4,'#fff',4)}});g.restore();
 /* title card */
 const parts=L.bn.split(', '),nm=parts[0].toUpperCase(),ep=(parts[1]||'').toUpperCase(),tc=eo((t-.7)/.7)*fo;
 if(tc>0){g.globalAlpha=tc;g.textAlign='center';g.textBaseline='middle';g.font='600 22px Cinzel,Georgia,serif';g.fillStyle='#d8ccff';g.shadowColor='#000';g.shadowBlur=8;
  const top='ACT VI  ·  ASTRAL ASCENDANCE';let s2='';for(let i=0;i<top.length;i++)s2+=top[i]+(i<top.length-1?'  ':'');g.fillText(s2,W/2,bar+70-(1-tc)*14);g.shadowBlur=0;g.globalAlpha=1}
 if(t>2.45){const u=eo((t-2.45)/.5),sh=(t-2.45)*520-200;g.save();g.globalAlpha=u*fo;g.textAlign='center';g.textBaseline='middle';const y=H-bar-168;
  g.fillStyle='rgba(2,0,12,.62)';g.fillRect(0,y-100,W,214);const lg=g.createLinearGradient(0,0,W,0);lg.addColorStop(0,'#0000');lg.addColorStop(.5,col);lg.addColorStop(1,'#0000');g.fillStyle=lg;g.fillRect(0,y-100,W,3);g.fillRect(0,y+111,W,3);
  g.font='34px Cinzel,Georgia,serif';g.fillStyle=col;g.shadowColor=col;g.shadowBlur=18;let shown=ep.slice(0,Math.floor((t-2.7)*22));g.fillText(shown.split('').join(' '),W/2,y-74);
  g.font='150px "Pirata One",Georgia,serif';const ng=g.createLinearGradient(0,y-40,0,y+60);ng.addColorStop(0,'#ffffff');ng.addColorStop(.55,col);ng.addColorStop(1,shade(col.length===7?col:'#c77dff',-.4));g.fillStyle=ng;g.shadowColor=col;g.shadowBlur=40;g.scale(1,1);g.fillText(nm,W/2,y+30);g.shadowBlur=0;
  g.save();g.beginPath();g.rect(0,y-60,W,170);g.clip();g.globalCompositeOperation='lighter';const sg2=g.createLinearGradient(sh-120,0,sh+120,0);sg2.addColorStop(0,'#fff0');sg2.addColorStop(.5,'#ffffffaa');sg2.addColorStop(1,'#fff0');g.fillStyle=sg2;g.font='150px "Pirata One",Georgia,serif';g.fillText(nm,W/2,y+26);g.restore();
  g.font='20px Georgia,serif';g.fillStyle='#fff';g.globalAlpha=u*fo*.9;if(k===2)g.fillStyle='#ffd166';g.fillText(`LEVEL ${S.camp}  -  ${L.n.toUpperCase()}`,W/2,y+92);g.restore()}
 if(t>.5){g.globalAlpha=.55;g.font='20px Georgia,serif';g.fillStyle='#fff';g.textAlign='right';g.fillText('Press any key to skip',W-30,H-bar-18)}
 g.restore()}

/* ---------- Act VI menu: a starlit staircase of three levels ---------- */
{const st=document.createElement('style');st.textContent=`
#ov.cmo .ax6 .cmht{background:linear-gradient(180deg,#e8fbff,#9ad8ff 40%,#b48cff 75%,#ffd98a);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;filter:drop-shadow(0 3px 0 #1a0a50) drop-shadow(0 0 18px #7a6aff99);letter-spacing:3px}
#ov.cmo .ax6 .cmsub{color:#dcd6ff}
#ov.cmo .ax6 .cmp{border-color:#8a7aff;box-shadow:0 0 0 1px #00f5d444,0 0 40px #5a3aff66,inset 0 0 40px #2a1a7a55}
#ov.cmo .ax6 .cmpt{background:linear-gradient(180deg,#fff,#b8c8ff);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent}
#ov.cmo .ax6 .cmgo{background:linear-gradient(180deg,#9a8aff,#5a3ad8);border-color:#d8ccff;color:#fff;box-shadow:0 6px 18px #000a,0 0 26px #7a5aff99}
#ov.cmo .ax6 .cmgo:disabled{background:linear-gradient(180deg,#3a3560,#221e40);color:#a8a0d0;box-shadow:none}
#ov.cmo .ax6 .cmvg{background:radial-gradient(ellipse at 40% 56%,#0000 45%,#02000ab0 100%),linear-gradient(180deg,#02000ab0 0,#0000 22%),linear-gradient(90deg,#0000 62%,#02000ab8 78%),linear-gradient(0deg,#02000ac0,#0000 18%)}
#ov.cmo .ax6 .cmr b.g{color:#9ad8ff}
#ov.cmo .ax6 .cn[data-i="2"] .clb{color:#ffd166;border-color:#ffd16699;text-shadow:0 0 10px #ffb02e}
#ov.cmo .ax6 .cmpt.gld{background:linear-gradient(180deg,#fff3b0,#ffc83a 55%,#e88a12);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;filter:drop-shadow(0 0 10px #ffb02e66)}
.ax6 .axlk{position:absolute;left:150px;top:300px;width:830px;text-align:center;z-index:5;padding:26px 30px;border:1.5px solid #8a7aff;border-radius:18px;background:linear-gradient(180deg,#1a1048ee,#0a0626ee);box-shadow:0 0 40px #5a3aff66;font:500 20px/1.5 var(--ui)}
.ax6 .axlk b{display:block;font:400 40px 'Pirata One',Georgia,serif;color:#ffd98a;margin-bottom:6px}
.cmt.ast{background:linear-gradient(180deg,#3a2a98e0,#1a0e5ae0)!important;border-color:#9a8aff!important;color:#fff}
.cmt.ast.lk{opacity:.7;filter:saturate(.6)}
.cmt.ast:hover:not(.lk){box-shadow:0 0 18px #8a7aff}`;document.head.appendChild(st)}
const AXPOS=[[210,690],[560,470],[900,270]];
let astSel=0;
function astMenuBG(c){const g=c.getContext('2d');
 return t=>{const w=1600,h=900;let q=g.createLinearGradient(0,0,0,h);q.addColorStop(0,'#02000f');q.addColorStop(.55,'#120a40');q.addColorStop(1,'#1f0a4a');g.fillStyle=q;g.fillRect(0,0,w,h);
  g.save();g.globalCompositeOperation='lighter';
  for(let i=0;i<5;i++){const x=(.1+i*.22)*w+Math.sin(t*.06+i*2)*70,y=160+(i%3)*190+Math.cos(t*.08+i)*40,r=420+i*50,col=['#5a3aff','#00c8d4','#c83aa8','#ffb04a','#3a6aff'][i];q=g.createRadialGradient(x,y,10,x,y,r);q.addColorStop(0,col+'40');q.addColorStop(.55,col+'14');q.addColorStop(1,col+'00');g.fillStyle=q;g.fillRect(0,0,w,h)}
  /* a slow galaxy */
  g.translate(1080,330);g.rotate(t*.02);g.scale(1,.42);for(let a=0;a<3;a++){for(let i=0;i<140;i++){const u=i/140,th=u*9+a*TAU/3,r=30+u*330,x=Math.cos(th)*r+(rnd(i+a*300)-.5)*38,y=Math.sin(th)*r+(rnd(i+a*300+5)-.5)*38;g.globalAlpha=(1-u*.7)*.55;g.fillStyle=u<.3?'#ffe9b0':u<.6?'#bfa8ff':'#7ad8ff';g.beginPath();g.arc(x,y,1.2+rnd(i+9)*2.2,0,TAU);g.fill()}}
  q=g.createRadialGradient(0,0,2,0,0,110);q.addColorStop(0,'#fff6d8cc');q.addColorStop(1,'#fff6d800');g.globalAlpha=1;g.fillStyle=q;g.beginPath();g.arc(0,0,110,0,TAU);g.fill();
  g.setTransform(1,0,0,1,0,0);g.restore();
  for(let L=0;L<3;L++){const n=70+L*35,sp=2+L*5;for(let i=0;i<n;i++){const x=(rnd(i+L*400)*w-t*sp+w*3)%w,y=rnd(i+L*400+77)*h,tw=.4+.6*Math.abs(Math.sin(t*(.5+rnd(i)*1.5)+i));g.globalAlpha=tw*(.35+L*.22);g.fillStyle=rnd(i+5)<.2?'#ffd9a8':rnd(i+6)<.4?'#bfe8ff':'#fff';const r=.6+L*.5+rnd(i+9)*.8;g.beginPath();g.arc(x,y,r,0,TAU);g.fill();if(L===2&&rnd(i+3)<.3){g.fillRect(x-5,y-.4,10,.8);g.fillRect(x-.4,y-5,.8,10)}}}g.globalAlpha=1;
  /* shooting stars */
  for(let i=0;i<3;i++){const u=((t*.16+i*.37)%1);if(u<.18){const x=w*(.2+i*.3)-u*1400+700,y=60+i*130+u*500,a=Math.min(1,u*14)*(1-u/.18);g.globalAlpha=a;const lg=g.createLinearGradient(x,y,x+150,y-60);lg.addColorStop(0,'#fff');lg.addColorStop(1,'#fff0');g.strokeStyle=lg;g.lineWidth=2.4;g.beginPath();g.moveTo(x,y);g.lineTo(x+150,y-60);g.stroke()}}g.globalAlpha=1;
  /* planet with rings, low left */
  {const x=260,y=760,r=190;q=g.createRadialGradient(x-r*.4,y-r*.4,r*.1,x,y,r*1.1);q.addColorStop(0,'#5a4a9a');q.addColorStop(1,'#0c0830');g.save();g.shadowColor='#7a6aff';g.shadowBlur=60;g.fillStyle=q;g.beginPath();g.arc(x,y,r,0,TAU);g.fill();g.restore();g.save();g.translate(x,y);g.rotate(-.25);g.strokeStyle='#b8a8ff55';g.lineWidth=14;g.beginPath();g.ellipse(0,0,r*1.5,r*.28,0,Math.PI,TAU);g.stroke();g.restore()}
  /* rising beam of light, the stair up to the heavens */
  g.save();g.globalCompositeOperation='lighter';q=g.createLinearGradient(0,h,w*.6,0);q.addColorStop(0,'#7a6aff00');q.addColorStop(.5,'#7a6aff1c');q.addColorStop(1,'#00f5d400');g.fillStyle=q;g.beginPath();g.moveTo(80,h);g.lineTo(380,h);g.lineTo(w*.78,0);g.lineTo(w*.5,0);g.fill();g.restore()}}
function astMapHTML(){const A=AP(),pts=AXPOS,segs=cmSegs(pts);let svg='<svg class="cmsv" viewBox="0 0 1130 900">',last='';
 segs.forEach((d,i)=>{const open=astOpen(i+1);svg+=`<path class="cmrd" d="${d}"/>`;if(open){last=d;svg+=`<path class="cmgg" d="${d}"/><path class="cmgl" pathLength="1" style="--i:${i}" d="${d}"/>`}else svg+=`<path class="cmdl" d="${d}"/>`});
 if(last)svg+=`<circle class="cmsp" r="5"><animateMotion dur="2.4s" repeatCount="indefinite" path="${last}"/></circle>`;svg+='</svg>';
 const nodes=pts.map(([x,y],i)=>{const n=31+i,Z=ASTRAL[i],lk=!astOpen(i),dn=A.cl>i,cr=!lk&&A.cl===i,st=A.stars[n]||0;
  return `<button class="cn${lk?' lk':''}${cr?' cur':''}${dn?' dn':''}${i===astSel?' sel':''}${i===2?' bs':''}" data-i="${i}" style="left:${x}px;top:${y}px;--c:${Z.a};--i:${i}" aria-label="Level ${n}, ${esc(Z.n)}${lk?', locked':''}">`+
   (dn?`<span class="cst">${[1,2,3].map(q=>`<i class="${q<=st?'on':''}">★</i>`).join('')}</span>`:'')+
   `<span class="crg"></span><span class="cds"><img alt="" src="${bossMedal(Z)}"></span><span class="cnm">${n}</span>`+
   (dn?`<span class="cck">${cmi('check',17)}</span>`:'')+(lk?`<span class="clk">${cmi('lock',30)}</span>`:'')+
   `<span class="clb">${esc(Z.n)}</span>${cr?'<span class="cpl">Next Battle</span>':''}</button>`}).join('');
 return svg+nodes}
function astPanelHTML(){const i=astSel,n=31+i,Z=ASTRAL[i],A=AP(),lk=!astOpen(i),dn=A.cl>i,st=A.stars[n]||0,why=!astAct5()?'Complete Act V (defeat the Abyssal King, level 30) to enter the heavens.':'Defeat the boss of the previous level to unlock this one.';
 return `<div class="cmpt${i===2?' gld':''}">Level ${n}: ${esc(Z.n)}</div>
 <div class="cmart" style="--c:${Z.a}"><canvas id="cmhero" width="640" height="396"></canvas><span class="cmac">Act VI${i===2?' · Final boss':''}</span></div>
 <div class="cmrows">
  <div class="cmr"><span class="cmi">${cmi('skull',24)}</span><span class="cmx"><small>Boss</small><b>${esc(Z.bn)}</b></span><span class="cmsk" title="Danger">☠☠☠☠☠☠</span></div>
  <div class="cmr"><span class="cmi">${cmi('shield',24)}</span><span class="cmx"><small>Astral rules</small><b class="g">35% harder, 45% less gold</b><em>Faster, more numerous foes.${(P.pres||0)?` Prestige bonus: +${(P.pres||0)*50}% gold.`:''}</em></span></div>
  <div class="cmr"><span class="cmi">${cmi('trophy',24)}</span><span class="cmx"><small>Best score</small><b>${A.best[n]?A.best[n].toLocaleString():'Not set yet'}</b></span>${dn?`<span class="cmrt" title="Your rating">${'★'.repeat(st)}${'☆'.repeat(3-st)}</span>`:''}</div>
  <div class="cmr"><span class="cmi">${cmi('scroll',24)}</span><span class="cmx"><small>Level briefing</small><em>${lk?why:esc(Z.blurb)+' Five rounds, then the boss.'}</em></span></div>
  <div class="cmr three"><span class="cmi">${cmi('star',24)}</span><span class="cmx"><em><b>Three Stars:</b> Finish the level without losing a heart.</em></span></div>
 </div>
 <button class="cmgo" id="go" ${lk?'disabled':''}>${lk?cmi('lock',26)+'<span>Locked</span>':cmi('swords',28)+`<span>${dn?'Replay Level':'Begin Level'}</span>`}</button>`}
function astBind(){ov.querySelectorAll('.cn').forEach(el=>el.onclick=()=>{const i=+el.dataset.i;if(!astOpen(i)){el.classList.remove('shk');void el.offsetWidth;el.classList.add('shk');return}if(i===astSel)start(31+i);else astSelect(i)});
 const g=$('go');if(g)g.onclick=()=>{if(astOpen(astSel))start(31+astSel)};
 const c=$('cmhero');if(c)LIVE.push({cv:c,fn:bossHero(c,ASTRAL[astSel]),slow:2,ph:1,vis:true});
 const t=document.querySelector('#cmp .cmpt');if(t){let f=40;t.style.fontSize='';while(t.scrollWidth>t.clientWidth&&f>20){f-=2;t.style.fontSize=f+'px'}}}
function astSelect(i){astSel=i;S.bgz=31+i;ov.querySelectorAll('.cn').forEach(e=>e.classList.toggle('sel',+e.dataset.i===i));$('cmp').innerHTML=astPanelHTML();astBind()}
function astralMenu(){S.mode='title';S.view='ast';const A=AP(),ok=astAct5(),tot=Object.values(A.stars).reduce((a,b)=>a+b,0);
 if(!ok)astSel=0;else if(!(astSel>=0&&astOpen(astSel)))astSel=Math.min(2,A.cl);
 if(ok&&A.cl<3&&astSel!==Math.min(2,A.cl)&&!ast_keep)astSel=Math.min(2,A.cl);ast_keep=0;
 S.bgz=31+astSel;
 show(`<div class="cm ax6" id="cm"><canvas class="cmbg" id="cmbg" width="1600" height="900"></canvas><div class="cmvg"></div>
  <button class="cmback" id="cmBack">${cmi('back',20)}<span>Back</span></button>
  <div class="cmh"><div class="cmht">Astral Ascendance</div><div class="cmsub">Act VI<i>·</i>${tot} of 9 stars<i>·</i>${A.cl} of 3 levels cleared</div></div>
  <div class="cmmap" id="cmmap">${astMapHTML()}</div>
  ${ok?'':`<div class="axlk"><b>The heavens are sealed</b>Finish Act V first: defeat the Abyssal King on level 30. Then the stairway of stars opens.</div>`}
  <aside class="cmp" id="cmp">${astPanelHTML()}</aside></div>`,'cmo nosb');
 S.back=()=>campaign();LIVE.push({cv:$('cmbg'),fn:astMenuBG($('cmbg')),slow:2,ph:0,vis:true});
 astBind();$('cmBack').onclick=S.back;
 if(!AST_KEYS){AST_KEYS=1;addEventListener('keydown',e=>{if(S.mode!=='title'||S.view!=='ast'||!$('cm')||!document.querySelector('.ax6')||ov.className.indexOf('hide')>=0||e.ctrlKey||e.metaKey||e.altKey)return;const k=e.key;
  if(k==='ArrowRight'||k==='ArrowDown'){e.preventDefault();if(astOpen(Math.min(2,astSel+1)))astSelect(Math.min(2,astSel+1))}
  else if(k==='ArrowLeft'||k==='ArrowUp'){e.preventDefault();astSelect(Math.max(0,astSel-1))}
  else if(k==='Enter'&&!e.repeat&&astOpen(astSel)){e.preventDefault();start(31+astSel)}})}}
let AST_KEYS=0,ast_keep=0;

/* ---------- campaign screen: a sixth tab (locked until Act V is finished) ---------- */
{const c0=campaign;campaign=function(){c0.apply(this,arguments);try{const tb=$('cmtabs');if(tb&&!tb.querySelector('.ast')){const lk=!astAct5(),b=document.createElement('button');b.className='cmt ast'+(lk?' lk':'');b.innerHTML=(lk?cmi('lock',16):'')+'<span>Act VI: Astral Ascendance</span>';b.title=lk?'Complete Act V to unlock':'';b.onclick=()=>{if(lk){b.classList.remove('shk');return}astralMenu()};tb.appendChild(b)}}catch(e){}}}
