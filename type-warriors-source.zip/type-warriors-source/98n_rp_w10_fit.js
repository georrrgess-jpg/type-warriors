/* ===== RUNESTONE TOWER DEFENSE 10.0: integration fixes (98n, after 98m) =====
   - The tower bar fits twelve cards once the Clockwork Hive (World 2) and the Singularity Engine (World 3) are unlocked: 95m/97e
     size the bar for up to ten (.rp10), 98i/98k add .rp11; this adds .rp12 (cards 68 px, smaller icons and names) in the same
     871 px between the abilities and Next wave. Locked towers stay hidden (98b's rpwTwOnly), so the bar shows 10, 11 or 12. */
{const st=document.createElement('style');const P='.rph.rp7.rp8.rp9.rp10.rp11.rp12';
 st.textContent=`${P} .rpbar{gap:2px;padding-left:8px;padding-right:8px}${P} .rpcard{width:68px}${P} .rpct>b{max-width:66px;font-size:10px;letter-spacing:-.1px}
${P} .rpcard img{width:56px;height:56px;margin-left:-28px;top:-15px}${P} .rpcard .rpcc{font-size:11px}`;document.head.appendChild(st)}
{const h0=rpHudOn;rpHudOn=function(){const r=h0.apply(this,arguments);try{const h=$('rphud');if(h){const n=h.querySelectorAll('.rpcard').length;h.classList.toggle('rp11',n>=11);h.classList.toggle('rp12',n>=12)}}catch(e){}return r}}
/* - Clockwork Hive (98i) hooks: its bees skip monsters the core hides this frame (glimmer, dive, leap, shell-free: e.hide), and its reach
     gets the Glowcap bonus like every other tower (tw.glowK, 98b). */
function rpwCanHit(e){return !!e&&!e.dead&&!e.hide}
{const r0=rphvRange;rphvRange=function(R,tw){const r=r0.apply(this,arguments);return tw&&tw.glowK>1&&!tw.rangeK?r*tw.glowK:r}}
/* - Singularity Engine (98k) hooks: its aim skips monsters the core hides (e.hide) and fogged monsters out of reach (Shipwreck Cove),
     like rpTarget does for every other tower in 98b. */
RPGV.see=(R,tw,e)=>{if(e.hide)return false;const fn=R.map&&R.map.fogNear;if(fn&&e.fogd&&tw){const q=rpPos(R,e);if(rpD2(q.x,q.y,tw.x,tw.y)>fn*fn)return false}return true};
{const a0=rpgvAim;rpgvAim=function(R,tw,T,i){if(tw&&tw.glowK>1&&T&&T.range){const k=tw.glowK;T=Object.create(T,{range:{value:T.range.map(r=>r*k)}})}return a0.call(this,R,tw,T,i)}}
/* - the build ring with twelve buttons (World 3): a little wider and slightly smaller buttons, so the price tags never overlap */
{const st=document.createElement('style');st.textContent=`.rph.rp12 .rprb{width:72px;height:72px;left:-36px;top:-36px}.rph.rp12 .rprb img{width:60px;height:60px;margin-top:-12px}.rph.rp12 .rprb em{font-size:11px;padding:2px 6px}`;document.head.appendChild(st)}
{const g0=rpHudRing;rpHudRing=function(R,C){const was=C.rg;const r=g0.apply(this,arguments);try{if(C.rg!==was&&C.rg){const bs=[...$('rpring').querySelectorAll('.rprb')];if(bs.length>=12)bs.forEach(b=>{for(const v of["--x","--y"]){const n=parseFloat(b.style.getPropertyValue(v));if(isFinite(n))b.style.setProperty(v,(n*1.16).toFixed(1)+'px')}})}}catch(e){}return r}}
