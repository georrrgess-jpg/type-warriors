/* ===== RUNESTONE TOWER DEFENSE 10.0: World 3 art - Skyforge Heights, part 2 (98g2) =====
   Gearworks Foundry (bake, live layer, the switch lever), Storm Citadel (bake, live layers, rain and lightning), the map icons and the
   world painting for the hub (RPW.world[3]). Helpers, castles and Cloudspire Meadows are in 98g. */

/* ======================================================================================================================
   Gearworks Foundry
   ====================================================================================================================== */
const RPW3A_FP={steel:['#3e3c46','#46434e','#36343e','#4a4240','#3a3a44'],rust:'#5a3a2a',seam:'rgba(8,4,12,.75)',edge:'#141018',curb:'#6a6876',bed:'#3c3836',bed2:'#2e2a2a',sleeper:'#5a3e2e',rail:'#c4c0d0',brass:['#c89a3a','#ffe08a','#6a4a14'],
 iron:['#5a5868','#8a88a0','#2a2834'],brick:['#7a3a2e','#9a4a36','#5a2a22'],hot:['#fff4b0','#ffc84a','#ff7a1a','#c8300a']};
/* a pipe along a polyline with flanges every so often */
function rpw3aPipe(g,pts,w,C,fl){const line=()=>{g.beginPath();g.moveTo(pts[0][0],pts[0][1]);for(let i=1;i<pts.length;i++)g.lineTo(pts[i][0],pts[i][1])};
 g.lineCap='butt';line();g.strokeStyle=RPO;g.lineWidth=w+4;g.stroke();line();g.strokeStyle=C[0];g.lineWidth=w;g.stroke();g.save();g.translate(-w*.18,-w*.18);line();g.strokeStyle=C[1];g.lineWidth=w*.28;g.globalAlpha=.7;g.stroke();g.restore();
 g.lineCap='round';if(fl===0)return;for(let i=0;i<pts.length-1;i++){const [x0,y0]=pts[i],[x1,y1]=pts[i+1],L=Math.hypot(x1-x0,y1-y0),n=Math.max(1,Math.floor(L/(fl||70))),a=Math.atan2(y1-y0,x1-x0);
  for(let k=1;k<=n;k++){const u=k/(n+1),x=x0+(x1-x0)*u,y=y0+(y1-y0)*u;g.save();g.translate(x,y);g.rotate(a);g.fillStyle=C[2];g.beginPath();g.rect(-3,-w/2-3,6,w+6);g.fill();rpw3aO(g,1.6);g.restore()}}}
/* a box seen from the front and above: front face and top face */
function rpw3aBox(g,x,y,w,h,d,C,o){const t=d*.55;g.beginPath();g.rect(x-w/2,y-h,w,h);g.fillStyle=C[0];g.fill();rpw3aO(g,2);g.beginPath();g.rect(x-w/2,y-h-t,w,t);g.fillStyle=C[1];g.fill();rpw3aO(g,2);
 if(o==='crate'){g.strokeStyle=C[2];g.lineWidth=2;g.beginPath();g.moveTo(x-w/2+3,y-3);g.lineTo(x+w/2-3,y-h+3);g.moveTo(x-w/2+3,y-h+3);g.lineTo(x+w/2-3,y-3);g.stroke();g.strokeStyle=RPO;g.lineWidth=1;g.strokeRect(x-w/2+3,y-h+3,w-6,h-6);
  g.fillStyle='#8a8898';for(const [cx,cy] of[[x-w/2,y-h],[x+w/2,y-h],[x-w/2,y],[x+w/2,y]]){g.fillRect(cx-2.5,cy-2.5,5,5)}}}
function rpw3aBarrel(g,x,y,col,i){g.save();g.translate(x,y);rpBlob(g,3,1,13,4,'#000',.3);g.beginPath();g.moveTo(-10,0);g.lineTo(-10,-24);g.ellipse(0,-24,10,4,0,Math.PI,0);g.lineTo(10,0);g.ellipse(0,0,10,4,0,0,Math.PI);g.closePath();
 const q=g.createLinearGradient(-10,0,10,0);q.addColorStop(0,col);q.addColorStop(.3,'#ffffff55');q.addColorStop(.35,col);q.addColorStop(1,'#12081f');g.fillStyle=col;g.fill();g.fillStyle=q;g.globalAlpha=.55;g.fill();g.globalAlpha=1;rpw3aO(g,2);
 g.strokeStyle='rgba(18,8,31,.6)';g.lineWidth=1.6;for(const yy of[-8,-17]){g.beginPath();g.ellipse(0,yy,10,4,0,0,Math.PI);g.stroke()}g.fillStyle='#2a2630';g.beginPath();g.ellipse(0,-24,8,3,0,0,TAU);g.fill();
 if(i%3===0){g.fillStyle='#ffd45a';g.beginPath();g.moveTo(0,-15);g.lineTo(4,-8);g.lineTo(-4,-8);g.closePath();g.fill();g.strokeStyle=RPO;g.lineWidth=1;g.stroke()}g.restore()}
function rpw3aIngots(g,x,y){g.save();g.translate(x,y);rpBlob(g,2,2,22,6,'#000',.3);const bar=(bx,by)=>{g.beginPath();g.moveTo(bx-9,by);g.lineTo(bx-7,by-5);g.lineTo(bx+7,by-5);g.lineTo(bx+9,by);g.closePath();g.fillStyle='#ffc94a';g.fill();rpw3aO(g,1.4);g.fillStyle='#fff2b0';g.fillRect(bx-6,by-4.5,8,1.6)};
 for(const [bx,by] of[[-10,0],[8,0],[-1,-5],[17,-5],[-10,-10],[8,-10],[0,-15]])bar(bx,by);g.restore()}
function rpw3aCoal(g,x,y,r){g.save();g.translate(x,y);rpBlob(g,2,1,r+4,r*.35,'#000',.3);g.beginPath();g.moveTo(-r,0);g.quadraticCurveTo(-r*.6,-r*.9,0,-r*.85);g.quadraticCurveTo(r*.7,-r*.8,r,0);g.closePath();g.fillStyle='#1e1a20';g.fill();rpw3aO(g,2);
 g.fillStyle='rgba(255,255,255,.22)';for(let k=0;k<7;k++){g.beginPath();g.arc(-r*.6+rpw3aR(k+x)*r*1.2,-r*.15-rpw3aR(k+y)*r*.6,1.6,0,TAU);g.fill()}g.restore()}
function rpw3aTanks(g,x,y,i){g.save();g.translate(x,y);rpBlob(g,2,1,20,5,'#000',.3);const C=[['#c8402a','#ff8a6a'],['#3a8ae0','#8ad0ff'],['#4aa85a','#9ae8a0']];
 for(const [dx,k] of[[-9,i%3],[9,(i+1)%3],[0,(i+2)%3]]){const yy=dx?0:4,h=dx?36:30;g.beginPath();g.moveTo(dx-7,yy);g.lineTo(dx-7,yy-h+6);g.quadraticCurveTo(dx-7,yy-h,dx,yy-h);g.quadraticCurveTo(dx+7,yy-h,dx+7,yy-h+6);g.lineTo(dx+7,yy);g.closePath();g.fillStyle=C[k][0];g.fill();rpw3aO(g,1.8);
  g.fillStyle=C[k][1];g.globalAlpha=.6;g.fillRect(dx-5,yy-h+6,3,h-10);g.globalAlpha=1;g.fillStyle='#8a8898';g.fillRect(dx-2,yy-h-5,4,5);g.strokeStyle=RPO;g.lineWidth=1.2;g.strokeRect(dx-2,yy-h-5,4,5)}g.restore()}
function rpw3aAnvil(g,x,y){g.save();g.translate(x,y);rpBlob(g,2,1,22,6,'#000',.3);g.fillStyle='#5a3e2e';g.beginPath();g.rect(-9,-14,18,14);g.fill();rpw3aO(g,1.8);
 g.beginPath();g.moveTo(-16,-14);g.lineTo(18,-14);g.lineTo(18,-20);g.lineTo(28,-22);g.lineTo(18,-26);g.lineTo(-14,-26);g.quadraticCurveTo(-22,-24,-16,-14);g.closePath();g.fillStyle='#4a4858';g.fill();rpw3aO(g,2);g.fillStyle='#8a88a0';g.fillRect(-12,-26,28,3);
 g.save();g.rotate(-.5);g.fillStyle='#7a5030';g.fillRect(4,-30,4,22);g.fillStyle='#3a3844';g.fillRect(-2,-36,16,8);g.strokeStyle=RPO;g.lineWidth=1.4;g.strokeRect(-2,-36,16,8);g.restore();g.restore()}
function rpw3aGauge(g,x,y){g.save();g.translate(x,y);g.strokeStyle=RPO;g.lineWidth=5;g.beginPath();g.moveTo(0,0);g.lineTo(0,-26);g.stroke();g.strokeStyle='#8a88a0';g.lineWidth=3;g.stroke();
 g.fillStyle='#c89a3a';g.beginPath();g.arc(0,-32,9,0,TAU);g.fill();rpw3aO(g,2);g.fillStyle='#fff8e8';g.beginPath();g.arc(0,-32,6.5,0,TAU);g.fill();g.strokeStyle='#c8402a';g.lineWidth=1.6;g.beginPath();g.moveTo(0,-32);g.lineTo(4,-36);g.stroke();
 g.strokeStyle=RPO;g.lineWidth=1;for(let k=0;k<5;k++){const a=Math.PI*(.8+k*.35);g.beginPath();g.moveTo(Math.cos(a)*5,-32+Math.sin(a)*5);g.lineTo(Math.cos(a)*6.5,-32+Math.sin(a)*6.5);g.stroke()}g.restore()}
function rpw3aCart(g,x,y){g.save();g.translate(x,y);rpBlob(g,2,2,26,6,'#000',.3);g.strokeStyle=RPO;g.lineWidth=4;g.beginPath();g.moveTo(-30,2);g.lineTo(30,2);g.stroke();g.strokeStyle='#8a88a0';g.lineWidth=2;g.stroke();
 for(const dx of[-12,12]){g.fillStyle='#2a2834';g.beginPath();g.arc(dx,-2,5,0,TAU);g.fill();rpw3aO(g,1.6)}g.beginPath();g.moveTo(-20,-4);g.lineTo(-24,-22);g.lineTo(24,-22);g.lineTo(20,-4);g.closePath();g.fillStyle='#6a5a52';g.fill();rpw3aO(g,2);
 g.fillStyle='#8a5a32';g.fillRect(-22,-15,44,3);g.beginPath();g.moveTo(-22,-22);g.quadraticCurveTo(-10,-34,0,-30);g.quadraticCurveTo(12,-36,22,-22);g.closePath();g.fillStyle='#d88a4a';g.fill();rpw3aO(g,1.6);
 g.fillStyle='#ffd45a';for(let k=0;k<4;k++){g.beginPath();g.arc(-12+k*8,-26+(k%2)*3,2,0,TAU);g.fill()}g.restore()}
function rpw3aGearPile(g,x,y){g.save();g.translate(x,y);g.scale(1,.6);for(const [dx,dy,r,n] of[[-8,0,14,10],[10,-4,10,8],[0,-10,8,7]]){const G=rpw3aGear('pile'+r,r,n,['#8a88a0','#c8c4d8','#3a3844']);g.drawImage(G.c,dx-G.ax,dy-G.ay)}g.restore()}
function rpw3aILamp(g,x,y){g.save();g.translate(x,y);rpBlob(g,2,1,7,3,'#000',.3);g.strokeStyle=RPO;g.lineWidth=5;g.beginPath();g.moveTo(0,0);g.lineTo(0,-46);g.quadraticCurveTo(0,-52,8,-52);g.stroke();g.strokeStyle='#5a5868';g.lineWidth=3;g.stroke();
 g.fillStyle='#3a3844';g.beginPath();g.moveTo(3,-52);g.lineTo(15,-52);g.lineTo(13,-46);g.lineTo(5,-46);g.closePath();g.fill();rpw3aO(g,1.4);g.fillStyle='#ffd27a';g.beginPath();g.arc(9,-44,3.4,0,TAU);g.fill();rpw3aO(g,1.2);g.restore()}
function rpw3aBoiler(g,x,y){g.save();g.translate(x,y);rpBlob(g,4,2,44,9,'#000',.3);for(const dx of[-26,26]){g.fillStyle='#3a3844';g.beginPath();g.rect(dx-5,-12,10,12);g.fill();rpw3aO(g,1.6)}
 const body=()=>{g.beginPath();g.moveTo(-34,-12);g.lineTo(34,-12);g.arc(34,-30,18,Math.PI/2,-Math.PI/2,true);g.lineTo(-34,-48);g.arc(-34,-30,18,-Math.PI/2,Math.PI/2,true);g.closePath()};
 body();const q=g.createLinearGradient(0,-48,0,-12);q.addColorStop(0,'#5a5868');q.addColorStop(.3,'#9a98b0');q.addColorStop(1,'#2a2834');g.fillStyle=q;g.fill();rpw3aO(g,2.4);
 g.strokeStyle='rgba(18,8,31,.5)';g.lineWidth=1.4;for(const dx of[-20,0,20]){g.beginPath();g.moveTo(dx,-48);g.lineTo(dx,-12);g.stroke()}rpw3aRiv(g,-28,-44,28,-44,8,1.4,'#c8c4d8');
 g.fillStyle='#c89a3a';g.beginPath();g.rect(-6,-60,8,12);g.fill();rpw3aO(g,1.6);rpw3aGauge(g,24,-46);g.restore()}
/* a smith's forge: brick hearth with glowing coals under an iron hood, bellows */
function rpw3aForge(g,x,y,A){g.save();g.translate(x,y);rpBlob(g,4,2,54,12,'#000',.35);
 rpw3aBox(g,0,0,92,34,40,['#8a3e30','#a84e3a']);g.fillStyle='#1a0c0c';g.beginPath();g.ellipse(0,-42,34,9,0,0,TAU);g.fill();rpw3aO(g,2);const q=g.createRadialGradient(0,-42,2,0,-42,32);q.addColorStop(0,'#fff4b0');q.addColorStop(.5,'#ff8a1a');q.addColorStop(1,'#5a1408');
 g.fillStyle=q;g.beginPath();g.ellipse(0,-42,28,6.5,0,0,TAU);g.fill();g.fillStyle='rgba(40,10,10,.6)';for(let k=0;k<6;k++){g.beginPath();g.arc(-20+k*8,-42+(k%2)*2,2.4,0,TAU);g.fill()}
 g.beginPath();g.moveTo(-30,-60);g.lineTo(30,-60);g.lineTo(14,-86);g.lineTo(-14,-86);g.closePath();g.fillStyle='#4a4858';g.fill();rpw3aO(g,2.2);g.fillStyle='#3a3844';g.beginPath();g.rect(-8,-124,16,40);g.fill();rpw3aO(g,2);
 g.strokeStyle=RPO;g.lineWidth=2;g.beginPath();g.moveTo(-28,-60);g.lineTo(-30,-44);g.moveTo(28,-60);g.lineTo(30,-44);g.stroke();
 /* bellows */g.fillStyle='#7a5030';g.beginPath();g.moveTo(52,-8);g.lineTo(78,-16);g.lineTo(78,-2);g.closePath();g.fill();rpw3aO(g,1.8);g.fillStyle='#c8884a';g.beginPath();g.ellipse(66,-10,10,6,-.3,0,TAU);g.fill();rpw3aO(g,1.6);
 A.glows.push([x,y-42,60]);A.smoke.push([x,y-126,14]);A.sparks.push([x,y-48]);g.restore()}
/* a spherical gas tank on legs with a ladder */
function rpw3aSphere(g,x,y,i){g.save();g.translate(x,y);rpBlob(g,4,2,38,10,'#000',.35);g.strokeStyle=RPO;g.lineWidth=5;g.beginPath();for(const dx of[-26,-9,9,26]){g.moveTo(dx,0);g.lineTo(dx*.8,-34)}g.stroke();g.strokeStyle='#5a5868';g.lineWidth=3;g.stroke();
 const C=i%2?['#d8d4e4','#ffffff','#8a88a0']:['#e8c86a','#fff2b0','#a8802a'];const q=g.createRadialGradient(-12,-62,4,0,-50,40);q.addColorStop(0,C[1]);q.addColorStop(.5,C[0]);q.addColorStop(1,C[2]);g.fillStyle=q;g.beginPath();g.arc(0,-50,36,0,TAU);g.fill();rpw3aO(g,2.6);
 g.strokeStyle='rgba(18,8,31,.35)';g.lineWidth=1.4;g.beginPath();g.ellipse(0,-50,36,10,0,0,Math.PI);g.stroke();rpw3aRiv(g,-30,-46,30,-46,7,1.3,'#8a88a0');
 g.fillStyle='#c8402a';g.beginPath();g.rect(-14,-60,28,10);g.fill();rpw3aO(g,1.4);g.fillStyle='#fff';g.font='bold 8px Poppins,sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillText('GAS',0,-55);
 g.strokeStyle=RPO;g.lineWidth=1.6;g.beginPath();g.moveTo(24,-80);g.lineTo(24,-14);g.moveTo(30,-78);g.lineTo(30,-16);for(let yy=-74;yy<-16;yy+=7){g.moveTo(24,yy);g.lineTo(30,yy)}g.stroke();g.restore()}
/* the blast furnace (top left): a riveted iron stack on brick, a glowing mouth and a chimney */
function rpw3aBlast(g,x,y,A){g.save();g.translate(x,y);rpBlob(g,6,4,80,16,'#000',.35);
 /* brick base */g.beginPath();g.rect(-70,-60,140,60);const q=g.createLinearGradient(-70,0,70,0);q.addColorStop(0,'#9a4a36');q.addColorStop(1,'#4a2420');g.fillStyle=q;g.fill();g.save();g.clip();
 g.strokeStyle='rgba(18,8,31,.4)';g.lineWidth=1;for(let yy=-54;yy<0;yy+=7){g.beginPath();g.moveTo(-70,yy);g.lineTo(70,yy);g.stroke();for(let xx=-70+(yy%14?0:6);xx<70;xx+=12){g.beginPath();g.moveTo(xx,yy);g.lineTo(xx,yy+7);g.stroke()}}g.restore();g.beginPath();g.rect(-70,-60,140,60);rpw3aO(g,2.4);
 /* the stack: a tapered riveted iron tower */
 const st=()=>{g.beginPath();g.moveTo(-54,-60);g.lineTo(-40,-170);g.lineTo(40,-170);g.lineTo(54,-60);g.closePath()};st();const q2=g.createLinearGradient(-54,0,54,0);q2.addColorStop(0,'#6a6878');q2.addColorStop(.3,'#9a98b0');q2.addColorStop(1,'#2a2834');g.fillStyle=q2;g.fill();rpw3aO(g,2.6);
 for(const yy of[-80,-110,-140]){const hw=54-(-60-yy)*14/110;g.fillStyle='#4a4858';g.beginPath();g.rect(-hw-2,yy-4,hw*2+4,8);g.fill();rpw3aO(g,1.6);rpw3aRiv(g,-hw+6,yy,hw-6,yy,7,1.4,'#c8c4d8')}
 g.fillStyle='#3a3844';g.beginPath();g.rect(-46,-182,92,14);g.fill();rpw3aO(g,2.2);
 /* chimney */g.beginPath();g.rect(-14,-250,28,70);g.fillStyle='#7a3a2e';g.fill();rpw3aO(g,2.2);g.fillStyle='#2a2428';g.fillRect(-17,-256,34,8);g.strokeRect(-17,-256,34,8);A.smoke.push([x,y-258,28]);
 /* the glowing mouth */g.fillStyle='#1a0c0c';g.beginPath();g.moveTo(-24,-4);g.lineTo(-24,-34);g.arc(0,-34,24,Math.PI,0);g.lineTo(24,-4);g.closePath();g.fill();rpw3aO(g,2.4);
 const m=g.createRadialGradient(0,-16,2,0,-16,30);m.addColorStop(0,'#fff4b0');m.addColorStop(.4,'#ffa030');m.addColorStop(1,'#8a1a08');g.fillStyle=m;g.beginPath();g.moveTo(-19,-4);g.lineTo(-19,-32);g.arc(0,-32,19,Math.PI,0);g.lineTo(19,-4);g.closePath();g.fill();
 g.strokeStyle='#2a2834';g.lineWidth=3;g.beginPath();for(const dx of[-10,0,10]){g.moveTo(dx,-4);g.lineTo(dx,-48+Math.abs(dx))}g.stroke();A.glows.push([x,y-20,70]);
 g.restore()}
/* the factory gate the rails come out of (facing the viewer, like World 1's caves) */
function rpw3aPortal(g,x,y){g.save();g.translate(x,y);const L=-84,Rr=56,T=-118;
 g.beginPath();g.rect(L,T,Rr-L,158);let q=g.createLinearGradient(L,0,Rr,0);q.addColorStop(0,'#9a4a36');q.addColorStop(1,'#4a2420');g.fillStyle=q;g.fill();g.save();g.clip();
 g.strokeStyle='rgba(18,8,31,.4)';g.lineWidth=1;for(let yy=T+4;yy<40;yy+=8){g.beginPath();g.moveTo(L,yy);g.lineTo(Rr,yy);g.stroke();for(let xx=L+((yy/8|0)%2?0:7);xx<Rr;xx+=14){g.beginPath();g.moveTo(xx,yy);g.lineTo(xx,yy+8);g.stroke()}}g.restore();
 g.fillStyle='#3a3844';g.beginPath();g.rect(L-2,T-8,Rr-L+4,12);g.fill();rpw3aO(g,2.2);rpw3aRiv(g,L+8,T-2,Rr-8,T-2,8,1.4,'#a8a6b8');g.beginPath();g.rect(L,T,Rr-L,158);rpw3aO(g,2.6);
 /* iron frame and hazard stripes round the opening */
 g.beginPath();g.moveTo(-50,40);g.lineTo(-50,-52);g.arc(0,-52,50,Math.PI,0);g.lineTo(50,40);g.closePath();g.fillStyle='#ffc94a';g.fill();rpw3aO(g,2.4);
 g.save();g.clip();g.fillStyle='#1e1a20';for(let k=-12;k<14;k++){g.beginPath();g.moveTo(k*14,-120);g.lineTo(k*14+8,-120);g.lineTo(k*14+8+120,40);g.lineTo(k*14+120,40);g.closePath();g.fill()}g.restore();
 g.beginPath();g.moveTo(-41,40);g.lineTo(-41,-50);g.arc(0,-50,41,Math.PI,0);g.lineTo(41,40);g.closePath();g.fillStyle='#0c080e';g.fill();rpw3aO(g,2.4);
 q=g.createLinearGradient(0,-90,0,40);q.addColorStop(0,'rgba(12,8,14,1)');q.addColorStop(1,'rgba(255,140,50,.35)');g.fillStyle=q;g.fill();
 const G=rpw3aGear('key',13,10,['#ffc94a','#fff0b0','#8a5a14']);g.drawImage(G.c,-G.ax,-104-G.ay);g.fillStyle='#c8402a';g.beginPath();g.arc(0,-104,4,0,TAU);g.fill();rpw3aO(g,1.2);
 for(const dx of[-68,44]){g.fillStyle='#3a3844';g.beginPath();g.rect(dx-6,-96,12,14);g.fill();rpw3aO(g,1.6);g.fillStyle='#ff9a2a';g.beginPath();g.arc(dx,-89,4,0,TAU);g.fill();rpw3aO(g,1.2)}
 g.restore()}
/* bake Gearworks Foundry */
function rpw3aBakeFoundry(map){const G=rpGeo(map),H=900,FP=RPW3A_FP,pal=Object.assign({},RP_PAL.foundry),dR=rpw3aDR(G);
 const CA=rpw3aCastle('foundry'),cast={x:Math.round(G.gate.x-CA.gx),y:Math.round(G.gate.y-CA.gy),w:CA.w,h:CA.h};
 const c=rpw3aCv(1600,H),g=c.getContext('2d');g.lineJoin='round';g.lineCap='round';const A={smoke:[],glows:[],steam:[],lamps:[],sparks:[],gears:[],chan:[]};
 /* ---- the floor: riveted steel plates ---- */
 g.fillStyle='#2e2c34';g.fillRect(0,0,1600,H);
 for(let r=0,y=150;y<H;r++,y+=60){for(let x=-((r%2)*46),k=0;x<1600;x+=92,k++){const n=rpw3aR(r*61+k*7),C=n<.1?FP.rust:n<.18?'#2c2a30':FP.steel[(r+k)%5];
  g.fillStyle=C;g.fillRect(x+1,y+1,90,58);g.fillStyle='rgba(255,255,255,.07)';g.fillRect(x+1,y+1,90,3);g.fillRect(x+1,y+1,3,58);g.fillStyle='rgba(0,0,0,.3)';g.fillRect(x+1,y+56,90,3);g.fillRect(x+88,y+1,3,58);
  if(n>.82){/* diamond plate */g.fillStyle='rgba(255,255,255,.1)';for(let yy=y+8;yy<y+54;yy+=9)for(let xx=x+8+((yy/9|0)%2)*6;xx<x+86;xx+=12){g.save();g.translate(xx,yy);g.rotate(((yy/9|0)%2)?.6:-.6);g.fillRect(-3.5,-1,7,2);g.restore()}}
  rpw3aRiv(g,x+7,y+7,x+84,y+7,2,1.6,'#6a6878');rpw3aRiv(g,x+7,y+52,x+84,y+52,2,1.6,'#6a6878')}}
 g.strokeStyle=FP.seam;g.lineWidth=2;for(let y=150;y<H;y+=60){g.beginPath();g.moveTo(0,y);g.lineTo(1600,y);g.stroke()}
 /* soot, oil, rust stains */
 for(let i=0;i<70;i++){const x=rpw3aR(i+40)*1600,y=150+rpw3aR(i+90)*750,r=20+rpw3aR(i+140)*60;g.globalAlpha=.18+rpw3aR(i)*.15;g.fillStyle=i%4?'#0e0a10':'#5a2e1a';g.beginPath();g.ellipse(x,y,r,r*.5,rpw3aR(i+3),0,TAU);g.fill()}g.globalAlpha=1;
 for(let i=0;i<10;i++){const x=rpw3aR(i+240)*1500+50,y=200+rpw3aR(i+260)*600;if(dR(x,y)<70)continue;g.fillStyle='rgba(10,8,14,.7)';g.beginPath();g.ellipse(x,y,26,11,0,0,TAU);g.fill();g.globalCompositeOperation='lighter';g.globalAlpha=.25;
  for(const [c2,dy] of[['#ff6aff',-2],['#6affff',1],['#ffff6a',3]]){g.strokeStyle=c2;g.lineWidth=1.4;g.beginPath();g.ellipse(x-4,y+dy,14,4,0,Math.PI*1.1,Math.PI*1.8);g.stroke()}g.globalCompositeOperation='source-over';g.globalAlpha=1}
 /* painted bays with hazard borders, manholes and drain grates */
 const bay=(x0,y0,x1,y1)=>{g.save();g.fillStyle='rgba(255,201,74,.06)';g.fillRect(x0,y0,x1-x0,y1-y0);g.beginPath();g.rect(x0,y0,x1-x0,y1-y0);g.rect(x0+9,y0+9,x1-x0-18,y1-y0-18);g.clip('evenodd');
  for(let k=x0-(y1-y0);k<x1;k+=16){g.fillStyle='rgba(255,201,74,.7)';g.beginPath();g.moveTo(k,y1);g.lineTo(k+8,y1);g.lineTo(k+8+(y1-y0),y0);g.lineTo(k+(y1-y0),y0);g.closePath();g.fill()}g.restore()};
 for(const b of[[24,612,262,790],[1092,612,1300,800],[440,696,566,790],[58,206,318,296],[1100,186,1296,300]])if(b)bay(...b);
 for(let i=0;i<40;i++){const x=rpw3aR(i+800)*1560+20,y=190+rpw3aR(i+840)*600;if(dR(x,y)<64||G.pads.some(p=>Math.hypot(p.x-x,(p.y-y)*1.3)<80)||x>cast.x-20&&y>cast.y+120||Math.hypot(x-826,(y-452)*1.3)<150)continue;
  if(i%3===0){g.fillStyle='#24222a';g.beginPath();g.ellipse(x,y,15,8,0,0,TAU);g.fill();rpw3aO(g,1.8);g.strokeStyle='rgba(255,255,255,.12)';g.lineWidth=1;g.beginPath();g.ellipse(x,y,10,5,0,0,TAU);g.stroke();for(let k=-1;k<=1;k++){g.beginPath();g.moveTo(x-8,y+k*2.5);g.lineTo(x+8,y+k*2.5);g.stroke()}}
  else if(i%3===1){g.fillStyle='#1a181e';g.fillRect(x-16,y-6,32,12);g.strokeStyle='#5a5868';g.lineWidth=2;g.beginPath();for(let k=-12;k<=12;k+=6){g.moveTo(x+k,y-5);g.lineTo(x+k,y+5)}g.stroke();g.strokeStyle=RPO;g.lineWidth=1.6;g.strokeRect(x-16,y-6,32,12)}}
 /* ---- the back wall: brick between riveted pillars, with pipes ---- */
 {const WY=158;let q=g.createLinearGradient(0,0,0,WY);q.addColorStop(0,'#3a1e1c');q.addColorStop(1,'#6a3226');g.fillStyle=q;g.fillRect(0,0,1600,WY);
  g.strokeStyle='rgba(10,4,8,.45)';g.lineWidth=1.2;for(let y=WY-8;y>0;y-=8){g.beginPath();g.moveTo(0,y);g.lineTo(1600,y);g.stroke();for(let x=((y/8|0)%2)*8;x<1600;x+=16){g.beginPath();g.moveTo(x,y);g.lineTo(x,y+8);g.stroke()}}
  for(let i=0;i<60;i++){g.fillStyle=i%2?'rgba(255,140,90,.12)':'rgba(10,4,8,.2)';g.fillRect(((rpw3aR(i+500)*100|0)*16),((rpw3aR(i+600)*19|0)*8),16,8)}
  for(let x=60;x<1600;x+=230){g.fillStyle='#3a3844';g.beginPath();g.rect(x-14,0,28,WY+4);g.fill();rpw3aO(g,2.4);g.fillStyle='#5a5868';g.fillRect(x-14,0,6,WY+4);rpw3aRiv(g,x,10,x,WY-8,7,1.6,'#a8a6b8')}
  g.fillStyle='#1e1c24';g.fillRect(0,WY,1600,8);g.fillStyle='#4a4858';g.fillRect(0,WY-4,1600,5);g.strokeStyle=RPO;g.lineWidth=2;g.beginPath();g.moveTo(0,WY+8);g.lineTo(1600,WY+8);g.moveTo(0,WY-4);g.lineTo(1600,WY-4);g.stroke();
  /* hazard stripe along the wall foot */g.save();g.beginPath();g.rect(0,WY+8,1600,8);g.clip();for(let x=-10;x<1610;x+=18){g.fillStyle='#ffc94a';g.beginPath();g.moveTo(x,WY+16);g.lineTo(x+9,WY+16);g.lineTo(x+17,WY+8);g.lineTo(x+8,WY+8);g.closePath();g.fill()}g.fillStyle='#1e1a20';g.globalCompositeOperation='destination-over';g.fillRect(0,WY+8,1600,8);g.restore();
  rpw3aPipe(g,[[0,92],[540,92],[560,72],[1600,72]],12,FP.brass,90);rpw3aPipe(g,[[300,126],[1300,126]],9,FP.iron,80);
  /* gear holes (the gears turn in the live layer) */
  for(const [x,y,r] of[[690,96,72],[806,130,46],[888,100,34],[430,112,52],[1170,106,60]]){g.fillStyle='#160e12';g.beginPath();g.arc(x,y,r*.72,0,TAU);g.fill();g.fillStyle='#4a4858';g.beginPath();g.arc(x,y,7,0,TAU);g.fill();rpw3aO(g,1.6);A.gears.push([x,y,r])}
  /* steam valves on the pipes */for(const [x,y] of[[980,72],[300,92],[1240,126]]){g.fillStyle='#c8402a';g.beginPath();g.arc(x,y-12,6,0,TAU);g.fill();rpw3aO(g,1.6);g.strokeStyle=RPO;g.lineWidth=2;g.beginPath();g.moveTo(x,y-6);g.lineTo(x,y);g.stroke();A.steam.push([x,y-14])}}
 /* ---- painted safety lines beside the tracks ---- */
 g.save();g.setLineDash([16,12]);g.lineCap='butt';for(const P of G.paths){const S=P.S;for(const sd of[-1,1]){g.beginPath();let on=false;for(let i=0;i<S.length;i+=2){const p=S[i],x=p.x-Math.sin(p.a)*52*sd,y=p.y+Math.cos(p.a)*52*sd,ok=P.own[i]&&dR(x,y)>48&&y>176;if(ok){on?g.lineTo(x,y):g.moveTo(x,y);on=true}else on=false}
  g.strokeStyle='rgba(255,201,74,.55)';g.lineWidth=3;g.stroke()}}g.restore();
 /* ---- the great crucible in the middle: molten pool in a riveted ring, channels to the moulds ---- */
 const CX=826,CY=452;
 const chan=(pts,w)=>{const L=rpwSpl(pts,6);rpwPoly(g,rpwRibbon(L,w+12,w+12));g.fillStyle='#1a1418';g.fill();rpw3aO(g,2.2);rpwPoly(g,rpwRibbon(L,w,w));let q=g.createLinearGradient(L[0][0],L[0][1],L[L.length-1][0],L[L.length-1][1]);q.addColorStop(0,FP.hot[1]);q.addColorStop(1,FP.hot[2]);g.fillStyle=q;g.fill();
  rpwPoly(g,rpwRibbon(L,w*.35,w*.35,-.2));g.fillStyle=FP.hot[0];g.globalAlpha=.75;g.fill();g.globalAlpha=1;
  g.fillStyle='rgba(120,30,10,.55)';for(let i=3;i<L.length-2;i+=4){const p=L[i];g.beginPath();g.ellipse(p[0]+(rpw3aR(i+p[0])-.5)*w*.5,p[1]+(rpw3aR(i)-.5)*w*.3,3+rpw3aR(i+2)*3,1.6,0,0,TAU);g.fill()}A.chan.push(L)};
 const mould=(x,y)=>{g.fillStyle='#1a1418';g.beginPath();g.rect(x-30,y-12,60,24);g.fill();rpw3aO(g,2.2);for(let k=0;k<3;k++){const xx=x-24+k*18;g.fillStyle=k===1?'#ff9a2a':k===0?'#ffd45a':'#8a3a1a';g.beginPath();g.rect(xx,y-7,12,14);g.fill();g.strokeStyle=RPO;g.lineWidth=1.2;g.stroke()}A.glows.push([x,y,40])};
 chan([[CX-60,CY+10],[CX-110,CY+20],[CX-150,CY+14]],12);mould(CX-178,CY+14);chan([[CX+40,CY+30],[CX+80,CY+70],[CX+110,CY+102]],11);mould(CX+128,CY+118);
 {g.fillStyle='rgba(0,0,0,.35)';g.beginPath();g.ellipse(CX+6,CY+10,104,74,0,0,TAU);g.fill();
  g.fillStyle='#2a2834';g.beginPath();g.ellipse(CX,CY,98,72,0,0,TAU);g.fill();rpw3aO(g,2.6);
  g.save();g.beginPath();g.ellipse(CX,CY,98,72,0,0,TAU);g.clip();for(let a=0;a<TAU;a+=TAU/32){g.fillStyle=(a/(TAU/32)|0)%2?'#ffc94a':'#1e1a20';g.beginPath();g.moveTo(CX,CY);g.arc(CX,CY,110,a,a+TAU/32);g.closePath();g.fill()}g.restore();
  g.fillStyle='#3a3844';g.beginPath();g.ellipse(CX,CY,88,64,0,0,TAU);g.fill();rpw3aO(g,2);
  g.fillStyle='#160e12';g.beginPath();g.ellipse(CX,CY,72,52,0,0,TAU);g.fill();rpw3aO(g,2);
  const q=g.createRadialGradient(CX-10,CY-8,4,CX,CY,62);q.addColorStop(0,FP.hot[0]);q.addColorStop(.35,FP.hot[1]);q.addColorStop(.75,FP.hot[2]);q.addColorStop(1,FP.hot[3]);g.fillStyle=q;g.beginPath();g.ellipse(CX,CY+2,60,42,0,0,TAU);g.fill();
  g.save();g.clip();g.fillStyle='rgba(120,30,10,.5)';for(let i=0;i<12;i++){const a=rpw3aR(i+700)*TAU,r=.3+rpw3aR(i+720)*.6;g.beginPath();g.ellipse(CX+Math.cos(a)*56*r,CY+Math.sin(a)*38*r,6+rpw3aR(i)*8,3,a,0,TAU);g.fill()}
  g.strokeStyle='rgba(255,250,200,.5)';g.lineWidth=2;for(let i=0;i<5;i++){const y=CY-26+i*13;g.beginPath();g.moveTo(CX-40+i*4,y);g.quadraticCurveTo(CX,y-5,CX+40-i*4,y);g.stroke()}g.restore();
  A.pool=[CX,CY,60,42];A.glows.push([CX,CY,150])}
 /* ---- the rails: ballast bed, sleepers, two rails; conveyors replace the track at map.conv ---- */
 const conv=map.conv||[],onC=(x,y)=>conv.some(cv=>Math.hypot(x-cv[0],y-cv[1])<cv[2]),own=[];
 for(const P of G.paths){const S=P.S;own.push({S,runs:rpw3aRuns(S.length,i=>P.own[i]),track:rpw3aRuns(S.length,i=>P.own[i]&&!onC(S[i].x,S[i].y)),belt:rpw3aRuns(S.length,i=>P.own[i]&&onC(S[i].x,S[i].y))})}
 for(const [w,col] of[[88,'rgba(0,0,0,.35)'],[78,FP.edge],[72,FP.curb],[60,FP.bed]])for(const o of own)for(const r of o.runs)rpw3aLine(g,o.S,Math.max(0,r[0]-1),r[1],w,col);
 for(const o of own){const S=o.S;for(const r of o.runs)for(let i=r[0];i<=r[1];i+=2){const p=S[i];for(let k=0;k<3;k++){const off=(rpw3aR(i*3+k)-.5)*54,x=p.x-Math.sin(p.a)*off,y=p.y+Math.cos(p.a)*off;g.fillStyle=k%2?'#56504c':'#24201e';g.globalAlpha=.8;g.fillRect(x-1.5,y-1.5,3,3)}}}g.globalAlpha=1;
 for(const o of own){const S=o.S;for(const r of o.runs)for(let i=r[0];i<=r[1];i+=6)for(const sd of[-1,1]){const p=S[i],x=p.x-Math.sin(p.a)*35*sd,y=p.y+Math.cos(p.a)*35*sd;if(dR(x,y)<30)continue;g.fillStyle='#a8a6b8';g.beginPath();g.arc(x,y,2,0,TAU);g.fill();g.strokeStyle=RPO;g.lineWidth=1;g.stroke()}}
 for(const o of own){const S=o.S;for(const r of o.track)for(let i=r[0];i<=r[1];i+=3){const p=S[i],nx=-Math.sin(p.a),ny=Math.cos(p.a),tx=Math.cos(p.a)*3.4,ty=Math.sin(p.a)*3.4;
  g.fillStyle=FP.sleeper;g.strokeStyle=RPO;g.lineWidth=1.4;g.beginPath();g.moveTo(p.x+nx*27-tx,p.y+ny*27-ty);g.lineTo(p.x+nx*27+tx,p.y+ny*27+ty);g.lineTo(p.x-nx*27+tx,p.y-ny*27+ty);g.lineTo(p.x-nx*27-tx,p.y-ny*27-ty);g.closePath();g.fill();g.stroke()}}
 /* furnace vent grates set into the track bed (the engine draws the eruptions); the rails run over them */
 for(const [vx,vy] of map.vents||[]){g.fillStyle='rgba(0,0,0,.4)';g.beginPath();g.ellipse(vx+3,vy+5,46,22,0,0,TAU);g.fill();g.fillStyle='#3a3844';g.beginPath();g.ellipse(vx,vy,44,20,0,0,TAU);g.fill();rpw3aO(g,2.4);
  g.save();g.beginPath();g.ellipse(vx,vy,44,20,0,0,TAU);g.clip();for(let a=0;a<TAU;a+=TAU/20){g.fillStyle=(a/(TAU/20)|0)%2?'#ffc94a':'#1e1a20';g.beginPath();g.moveTo(vx,vy);g.arc(vx,vy,50,a,a+TAU/20);g.closePath();g.fill()}g.restore();
  g.fillStyle='#24202a';g.beginPath();g.ellipse(vx,vy,35,15,0,0,TAU);g.fill();rpw3aO(g,2);const q=g.createRadialGradient(vx,vy,2,vx,vy,30);q.addColorStop(0,'#ffe48a');q.addColorStop(.5,'#ff7a1a');q.addColorStop(1,'#5a1408');g.fillStyle=q;g.beginPath();g.ellipse(vx,vy,30,12,0,0,TAU);g.fill();
  g.strokeStyle='#1e1a20';g.lineWidth=3.4;g.beginPath();for(let k=-3;k<=3;k++){const xx=vx+k*8,hh=12*Math.sqrt(1-(k*8/31)**2);g.moveTo(xx,vy-hh);g.lineTo(xx,vy+hh)}g.stroke();g.strokeStyle='#5a5868';g.lineWidth=1.2;g.stroke();
  rpw3aRiv(g,vx-38,vy-2,vx+38,vy-2,2,1.8,'#a8a6b8');A.glows.push([vx,vy,46])}
 for(const [w,col,off] of[[7,RPO,0],[4,'#8a8898',0],[1.4,'rgba(255,255,255,.7)',-1]])for(const o of own){const S=o.S;for(const r of o.track)for(const sd of[-1,1]){g.beginPath();for(let i=r[0];i<=r[1];i++){const p=S[i],x=p.x-Math.sin(p.a)*15*sd,y=p.y+Math.cos(p.a)*15*sd+off;i===r[0]?g.moveTo(x,y):g.lineTo(x,y)}g.lineWidth=w;g.strokeStyle=col;g.stroke()}}
 g.strokeStyle=pal.chev;g.lineWidth=4;for(const o of own){const S=o.S;for(const r of o.track)for(let i=r[0]+30;i<r[1]-12;i+=40){const p=S[i];g.save();g.translate(p.x,p.y);g.rotate(p.a);g.beginPath();g.moveTo(-5,-7);g.lineTo(3,0);g.lineTo(-5,7);g.stroke();g.restore()}}
 /* conveyor belts: frame, rollers; the belt surface moves in the live layer */
 const belts=[];for(const o of own){const S=o.S;for(const r of o.belt){const i0=r[0],i1=r[1];rpw3aLine(g,S,i0,i1,74,RPO);rpw3aLine(g,S,i0,i1,70,'#4a4858');
  for(const sd of[-1,1]){g.save();g.beginPath();for(let i=i0;i<=i1;i++){const p=S[i],x=p.x-Math.sin(p.a)*31*sd,y=p.y+Math.cos(p.a)*31*sd;i===i0?g.moveTo(x,y):g.lineTo(x,y)}g.lineWidth=9;g.strokeStyle=RPO;g.stroke();g.lineWidth=6;g.strokeStyle='#ffc94a';g.stroke();g.setLineDash([7,7]);g.strokeStyle='#1e1a20';g.stroke();g.restore()}
  rpw3aLine(g,S,i0,i1,50,'#1a1618');for(const i of[i0,i1]){const p=S[i];g.save();g.translate(p.x,p.y);g.rotate(p.a);g.fillStyle='#8a88a0';g.beginPath();g.rect(-7,-27,14,54);g.fill();rpw3aO(g,2);g.fillStyle='#c8c4d8';g.fillRect(-7,-27,4,54);rpw3aRiv(g,0,-22,0,22,3,1.6,'#3a3844');g.restore()}
  belts.push({S,i0,i1})}}
 /* ---- the rail switch: frog plate and the lever stand (the lever arm and lamps are live) ---- */
 const sw=map.sw;let lever=null;if(sw){const lx=sw[0]-28,ly=sw[1]-80;lever={x:lx,y:ly};
  g.fillStyle='#4a4858';g.beginPath();g.ellipse(sw[0]+18,sw[1],30,14,0,0,TAU);g.fill();rpw3aO(g,2);rpw3aRiv(g,sw[0]-4,sw[1],sw[0]+40,sw[1],4,1.6,'#c8c4d8');
  rpBlob(g,lx+4,ly+4,30,9,'#000',.35);rpw3aBox(g,lx,ly,40,22,18,['#3a3844','#5a5868']);g.save();g.beginPath();g.rect(lx-20,ly-6,40,6);g.clip();for(let x=lx-26;x<lx+26;x+=10){g.fillStyle='#ffc94a';g.beginPath();g.moveTo(x,ly);g.lineTo(x+5,ly);g.lineTo(x+11,ly-6);g.lineTo(x+6,ly-6);g.closePath();g.fill()}g.restore();
  /* dial plate */g.fillStyle='#2a2834';g.beginPath();g.moveTo(lx-30,ly-32);g.arc(lx,ly-32,30,Math.PI,0);g.closePath();g.fill();rpw3aO(g,2);g.fillStyle='#ffc94a';g.font='bold 12px Poppins,sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillText('N',lx-19,ly-42);g.fillText('S',lx+19,ly-42)}
 /* ---- props ---- */
 const O=rpw3aOcc(G,cast,{rw:40,ok:(x,y,w,h)=>y-h>40&&y>178&&!(Math.abs(x-CX)<110+w&&Math.abs(y-CY)<84+h*.5)&&!(map.vents||[]).some(v=>Math.hypot(x-v[0],(y-v[1])*1.4)<60+w)&&!(lever&&Math.abs(x-lever.x)<44+w&&Math.abs(y-lever.y)<60)&&!(Math.abs(x-(CX-178))<40+w&&Math.abs(y-(CY+14))<26)&&!(Math.abs(x-(CX+128))<40+w&&Math.abs(y-(CY+118))<26)});
 /* the blast furnace (top left) and the forge (bottom left) */
 O.add(370,262,84,262);rpw3aBlast(g,370,262,A);
 const items=[],put=(k,x,y,w,h,m)=>{if(!O.take(x,y,w,h,m==null?2:m))return false;items.push({x,y,k,i:items.length+((x*7+y*3)|0)});return true};
 /* set pieces in the free bays: a smithy, a tank farm, a coal yard with an ore siding, a store, a boiler corner */
 const SZ={crate:[16,30],barrel:[10,30],tanks:[18,40],ingots:[22,18],coal:[18,16],anvil:[22,30],gauge:[10,42],cart:[30,32],gears:[16,12],forge:[50,80],sphere:[38,86],lamp:[8,54],boiler:[44,62],quench:[14,20]};
 const SETS=[[[110,690],[['forge',0,0],['anvil',84,14],['anvil',-56,52],['quench',40,40],['ingots',120,48],['gears',-60,8],['coal',-20,60]]],
  [[1170,700],[['sphere',0,0],['sphere',96,24],['gauge',-52,30],['barrel',50,62],['barrel',66,70]]],
  [[196,256],[['coal',0,0],['coal',44,14],['coal',-38,10],['cart',-100,-2],['lamp',96,-8],['ingots',30,34]]],
  [[480,740],[['crate',0,0],['crate',28,4],['crate',12,-24],['barrel',-28,6],['barrel',52,8]]],
  [[1190,262],[['boiler',0,0],['gauge',64,12],['tanks',-74,10]]],
  [[960,560],[['ingots',0,0],['gears',36,16]]],[[690,470],[['ingots',0,0]]],[[300,640],[['crate',0,0],['crate',26,6],['barrel',-26,8],['lamp',52,0]]]];
 for(const [[cx,cy],L] of SETS)for(const [kk,dx,dy] of L){const z=SZ[kk];put(kk,cx+dx,cy+dy,z[0],z[1],kk==='crate'||kk==='barrel'||kk==='coal'?0:2)}
 for(let i=0;i<3000;i++){const n=items.filter(it=>it.k==='lamp'||it.k==='gauge'||it.k==='boiler'||it.k==='pipe').length;if(n>=16)break;const x=rpw3aR(i*4+61)*1600,y=190+rpw3aR(i*4+62)*600,r=rpw3aR(i*4+63);
  if(r<.45)put('lamp',x,y,8,54,0);else if(r<.65)put('gauge',x,y,10,42,0);else if(r<.8)put('boiler',x,y,44,62,8);else put('pipe',x,y,40,14,4)}
 items.sort((a,b)=>a.y-b.y);
 g.save();g.globalCompositeOperation='lighter';for(const it of items)if(it.k==='lamp'){g.globalAlpha=.3;g.drawImage(rpwGlow('255,190,100',40),it.x-36,it.y-24,90,56)}g.restore();
 /* floor pipes from the boilers and the tank farm */
 for(const it of items){if(it.k==='boiler')rpw3aPipe(g,[[it.x+30,it.y-30],[it.x+30,174]],8,FP.iron,40);if(it.k==='sphere'&&it.x>1200)rpw3aPipe(g,[[it.x+30,it.y-40],[1300,it.y-40]],8,FP.brass,40)}
 for(const it of items){const{x,y,k,i}=it;if(k==='crate'){const s=1+(i%3)*.12;rpw3aBox(g,x,y,26*s,20*s,18*s,['#a86e3a','#c8884a','#6a4426'],'crate');if(i%3===0)rpw3aBox(g,x+3,y-20*s-5,18,14,14,['#a86e3a','#c8884a','#6a4426'],'crate')}
  else if(k==='barrel')rpw3aBarrel(g,x,y,['#c8402a','#3a6ac8','#4a8a4a','#c89a3a'][i%4],i);else if(k==='tanks')rpw3aTanks(g,x,y,i);else if(k==='ingots')rpw3aIngots(g,x,y);else if(k==='coal')rpw3aCoal(g,x,y,16);
  else if(k==='anvil'){rpw3aAnvil(g,x,y);A.sparks.push([x+6,y-28])}else if(k==='gauge')rpw3aGauge(g,x,y);else if(k==='cart')rpw3aCart(g,x,y);else if(k==='gears')rpw3aGearPile(g,x,y);else if(k==='lamp'){rpw3aILamp(g,x,y);A.lamps.push([x+9,y-44])}
  else if(k==='boiler'){rpw3aBoiler(g,x,y);A.steam.push([x-2,y-62])}else if(k==='forge'){rpw3aForge(g,x,y,A)}else if(k==='sphere'){rpw3aSphere(g,x,y,i)}else if(k==='quench'){rpw3aBarrel(g,x,y,'#5a5868',1);g.fillStyle='#4a8ac8';g.beginPath();g.ellipse(x,y-24,8,3,0,0,TAU);g.fill();A.steam.push([x,y-30])}else rpw3aPipe(g,[[x-40,y-6],[x+40,y-6]],10,i%2?FP.brass:FP.iron,0)}
 /* the entrance and the castle */
 for(const e of G.ent)rpw3aPortal(g,Math.max(30,e.x-14),e.y+24);
 g.save();g.globalCompositeOperation='lighter';for(const [x,y,r] of A.glows){g.globalAlpha=.35;g.drawImage(rpwGlow('255,130,40',40),x-r,y-r*.7,r*2,r*1.4)}g.restore();
 g.drawImage(CA.c,cast.x,cast.y,CA.w,CA.h);
 /* warm light and a vignette */
 let q=g.createLinearGradient(0,0,0,H);q.addColorStop(0,'rgba(8,4,12,.25)');q.addColorStop(.3,'rgba(8,4,12,0)');q.addColorStop(.85,'rgba(8,4,12,0)');q.addColorStop(1,'rgba(8,4,12,.35)');g.fillStyle=q;g.fillRect(0,0,1600,H);
 return{c,pal,G,trees:items,cast,id:map.id,A,belts,lever,CX,CY,occ:O.L}}
/* live: wall gears, the crucible's gear ring, belts, molten glow, steam, smoke, sparks, lamps */
function rpw3aAmbFoundry(c,R){const B=R.bake,A=B.A,t=R.t,lite=R.lite||R.rm;c.save();
 /* wall gears: neighbours turn the other way, speeds by size */
 for(let i=0;i<A.gears.length;i++){const [x,y,r]=A.gears[i],n=Math.max(8,Math.round(r/5)),G=rpw3aGear('w'+r+(i%2),r,n,i%2?['#8a88a0','#c8c4d8','#3a3844']:RPW3A_FP.brass);rpw3aSpinPut(c,rpw3aSpin('w'+r+(i%2),G,TAU/n,12),x,y,(i%2?-1:1)*t*24/r)}
 /* the gear ring round the crucible */
 {const GR=rpw3aSpr('ring',230,230,115,115,g=>{const n=36,R1=108,R0=92;g.beginPath();for(let i=0;i<n;i++){const a=i/n*TAU,w=TAU/n;g.lineTo(Math.cos(a-w*.3)*R0,Math.sin(a-w*.3)*R0);g.lineTo(Math.cos(a-w*.18)*R1,Math.sin(a-w*.18)*R1);g.lineTo(Math.cos(a+w*.18)*R1,Math.sin(a+w*.18)*R1);g.lineTo(Math.cos(a+w*.3)*R0,Math.sin(a+w*.3)*R0)}g.closePath();
  g.moveTo(84,0);g.arc(0,0,84,0,TAU,true);g.fillStyle='#c89a3a';g.fill('evenodd');rpw3aO(g,2.4);g.strokeStyle='rgba(255,240,180,.5)';g.lineWidth=2;g.beginPath();g.arc(0,0,88,Math.PI*1.1,Math.PI*1.6);g.stroke();for(let i=0;i<12;i++){const a=i/12*TAU;g.fillStyle='#6a4a14';g.beginPath();g.arc(Math.cos(a)*88,Math.sin(a)*88,2.4,0,TAU);g.fill()}});
  rpw3aSpinPut(c,rpw3aSpin('ring',GR,TAU/36,8,.72),B.CX,B.CY,t*.25)}
 /* conveyor belts: slats and arrows run along the road */
 c.lineCap='butt';for(const b of B.belts){const S=b.S,n=b.i1-b.i0,off=(t*38)%28;c.strokeStyle='#2e2a30';c.lineWidth=3;c.beginPath();
  for(let s=off;s<n*4;s+=14){const i=b.i0+Math.floor(s/4);if(i>b.i1)break;const p=S[i],nx=-Math.sin(p.a),ny=Math.cos(p.a);c.moveTo(p.x+nx*24,p.y+ny*24);c.lineTo(p.x-nx*24,p.y-ny*24)}c.stroke();
  c.strokeStyle='rgba(255,200,74,.55)';c.lineWidth=3;c.beginPath();for(let s=off*2;s<n*4-8;s+=56){const i=b.i0+Math.floor(s/4);if(i+2>b.i1)break;const p=S[i],tx=Math.cos(p.a),ty=Math.sin(p.a),nx=-ty,ny=tx;c.moveTo(p.x-tx*6+nx*10,p.y-ty*6+ny*10);c.lineTo(p.x+tx*4,p.y+ty*4);c.lineTo(p.x-tx*6-nx*10,p.y-ty*6-ny*10)}c.stroke()}
 c.lineCap='round';
 /* molten glow: the pool breathes, specks flow down the channels */
 c.globalCompositeOperation='lighter';const gl=rpwGlow('255,120,30',40);
 for(let i=0;i<A.glows.length;i++){const [x,y,r]=A.glows[i];if(r<60||lite&&i%2)continue;const rr=Math.min(r,90);c.globalAlpha=.14+.1*Math.sin(t*2.1+i*1.7);c.drawImage(gl,x-rr,y-rr*.6,rr*2,rr*1.2)}
 c.fillStyle='#fff4b0';c.globalAlpha=.8;c.beginPath();for(const L of A.chan)for(let k=0;k<5;k++){const u=(t*.35+k/5)%1,p=L[Math.min(L.length-1,(u*L.length)|0)];c.rect(p[0]-2,p[1]-1.5,4,3)}c.fill();
 if(A.pool&&!lite){const [x,y,rx,ry]=A.pool;c.globalAlpha=.7;c.fillStyle='#fff8d0';c.beginPath();for(let k=0;k<6;k++){const u=(t*.6+k/6)%1,a=k*1.9,px=x+Math.cos(a)*rx*.55,py=y+Math.sin(a)*ry*.5;c.moveTo(px+3*(1-u)+1,py-u*6);c.arc(px,py-u*6,3*(1-u)+1,0,TAU)}c.fill()}
 /* sparks off the anvils */
 if(!lite){c.strokeStyle='#ffd27a';c.lineWidth=1.6;c.beginPath();for(let i=0;i<A.sparks.length;i++){const [x,y]=A.sparks[i],ph=(t*1.3+i*.37)%1;if(ph>.35)continue;const u=ph/.35;for(let k=0;k<6;k++){const a=-Math.PI*(.15+rpw3aR(k+i*7)*.7),v=10+rpw3aR(k+i)*26,px=x+Math.cos(a)*v*u,py=y+Math.sin(a)*v*u+18*u*u;c.moveTo(px,py);c.lineTo(px-Math.cos(a)*4,py-Math.sin(a)*4)}}c.globalAlpha=.9;c.stroke()}
 /* lamps */for(let i=lite?1:0;i<A.lamps.length;i+=lite?2:1){const [x,y]=A.lamps[i];c.globalAlpha=.4+.08*Math.sin(t*9+i);c.drawImage(rpwGlow('255,200,110',24),x-16,y-14,32,32)}
 c.globalCompositeOperation='source-over';
 /* steam from the valves and boilers, smoke from the furnace stack */
 if(!lite){const ST=rpw3aPuff(5,44,36,['rgba(255,255,255,.75)','rgba(240,240,250,.4)','rgba(240,240,250,0)']),SM=rpw3aPuff(2,40,32,['rgba(70,60,66,.55)','rgba(70,60,66,.3)','rgba(70,60,66,0)']);
  for(let i=0;i<A.steam.length;i++){const [x,y]=A.steam[i];for(let k=0;k<2;k++){const u=(t*.5+k/2+i*.27)%1,s=.4+u*1.1;c.globalAlpha=(1-u)*.8;c.drawImage(ST.c,x-22*s+Math.sin(t+k+i)*4,y-18*s-u*46,44*s,36*s)}}
  for(let i=0;i<A.smoke.length;i++){const [x,y]=A.smoke[i];for(let k=0;k<3;k++){const u=(t*.25+k/3+i*.31)%1,s=.6+u*1.6;c.globalAlpha=(1-u)*.85;c.drawImage(SM.c,x-20*s+u*30,y-16*s-u*80,40*s,32*s)}}}
 c.globalAlpha=1;
 /* the blinking lamps on the factory gate */
 for(const e of B.G.ent){const x=Math.max(30,e.x-14),y=e.y+24,on=Math.sin(t*5)>0;c.globalCompositeOperation='lighter';for(const dx of[-68,44]){c.globalAlpha=(dx<0)===on?.75:.15;c.drawImage(rpwGlow('255,150,40',20),x+dx-18,y-107,36,36)}c.globalCompositeOperation='source-over';c.globalAlpha=1}
 c.restore();rpw3aCastleLive(c,'foundry',B.cast.x,B.cast.y,t,lite)}
/* twist: the switch lever (R.sw 0 north / 1 south, R.swK springs 0 -> 1 after a flip), lamps, and the live line lit up */
function rpw3aTwFoundry(c,R){const B=R.bake,L=B.lever,m=R.map;if(!L||!m.sw)return;const t=R.t,sw=R.sw||0,k=R.swK==null?1:R.swK,e=k>=1?1:1-Math.pow(1-k,3)*Math.cos(k*9);
 const a1=sw?.62:-.62,a0=-a1,a=a0+(a1-a0)*e;c.save();
 /* the live line: a run of lit chevrons just past the switch */
 const P=B.G.paths[sw]||B.G.paths[0],S=P.S;let i0=0,bd=1e9;for(let i=0;i<S.length;i++){const d=Math.hypot(S[i].x-m.sw[0],S[i].y-m.sw[1]);if(d<bd){bd=d;i0=i}}
 c.globalCompositeOperation='lighter';for(let j=0;j<4;j++){const i=i0+8+j*9;if(i>=S.length)break;const p=S[i],u=(t*2-j*.25)%1;c.globalAlpha=(.35+.5*Math.max(0,Math.sin(u*Math.PI)))*Math.min(1,k*2);c.strokeStyle='#7aff9a';c.lineWidth=4;
  c.save();c.translate(p.x,p.y);c.rotate(p.a);c.beginPath();c.moveTo(-6,-9);c.lineTo(4,0);c.lineTo(-6,9);c.stroke();c.restore()}
 const Q=B.G.paths[1-sw];if(Q){const S2=Q.S;let j0=0,bd2=1e9;for(let i=0;i<S2.length;i++){const d=Math.hypot(S2[i].x-m.sw[0],S2[i].y-m.sw[1]);if(d<bd2){bd2=d;j0=i}}const p=S2[Math.min(S2.length-1,j0+14)];
  c.globalAlpha=.5+.3*Math.sin(t*6);c.drawImage(rpwGlow('255,60,60',20),p.x-20,p.y-20,40,40);c.globalCompositeOperation='source-over';c.globalAlpha=1;
  c.save();c.translate(p.x,p.y);c.strokeStyle=RPO;c.lineWidth=6;c.beginPath();c.moveTo(-7,-7);c.lineTo(7,7);c.moveTo(7,-7);c.lineTo(-7,7);c.stroke();c.strokeStyle='#ff5a5a';c.lineWidth=3;c.stroke();c.restore()}
 c.globalCompositeOperation='source-over';c.globalAlpha=1;
 /* switch blades: two short rails swung toward the live line */
 {const p=S[Math.min(S.length-1,i0+6)];c.strokeStyle=RPO;c.lineWidth=6;c.beginPath();for(const sd of[-1,1]){c.moveTo(m.sw[0]-10,m.sw[1]+sd*15);c.lineTo(p.x-Math.sin(p.a)*15*sd,p.y+Math.cos(p.a)*15*sd)}c.stroke();c.strokeStyle='#e8e4f4';c.lineWidth=3;c.stroke()}
 /* the lever */
 const x=L.x,y=L.y-22;c.save();c.translate(x,y);c.rotate(a);c.strokeStyle=RPO;c.lineWidth=8;c.beginPath();c.moveTo(0,0);c.lineTo(0,-50);c.stroke();c.strokeStyle='#c8c4d8';c.lineWidth=5;c.stroke();c.strokeStyle='#ffffff';c.lineWidth=1.4;c.beginPath();c.moveTo(-1.5,-4);c.lineTo(-1.5,-46);c.stroke();
 c.fillStyle='#c8402a';c.beginPath();c.arc(0,-54,8,0,TAU);c.fill();rpw3aO(c,2.2);c.fillStyle='rgba(255,255,255,.55)';c.beginPath();c.arc(-2.5,-56.5,3,0,TAU);c.fill();c.restore();
 c.fillStyle='#5a5868';c.beginPath();c.arc(x,y,6,0,TAU);c.fill();rpw3aO(c,2);
 /* the lamps on the stand: green for the live line */
 for(const [dx,s] of[[-14,0],[14,1]]){const on=s===sw;c.fillStyle=on?'#7aff9a':'#3a2a2e';c.beginPath();c.arc(x+dx,L.y-12,4.2,0,TAU);c.fill();rpw3aO(c,1.4);if(on){c.globalCompositeOperation='lighter';c.globalAlpha=.55+.25*Math.sin(t*6);c.drawImage(rpwGlow('120,255,150',16),x+dx-16,L.y-28,32,32);c.globalCompositeOperation='source-over';c.globalAlpha=1}}
 c.restore()}
RPW.bake.foundry=rpw3aBakeFoundry;RPW.amb.foundry=rpw3aAmbFoundry;RPW.twist.foundry=rpw3aTwFoundry;RPW.castleHit.foundry=(c,x,y,k)=>rpw3aCastleHit('foundry',c,x,y,k);

/* ======================================================================================================================
   Storm Citadel: a mountain top over a sea of storm clouds, cut by chasms; wet flagstone roads, lightning rods, crackling spires
   ====================================================================================================================== */
const RPW3A_SP={void0:'#151a33',void1:'#0a0d1c',flag:['#7a86a6','#6e7a9a','#8692b2','#66728f','#7e8aa8'],curb:['#aab4ce','#8e98b4'],crys:['#e8fbff','#9ae8ff','#5a9ae8','#2a3a98'],vio:['#f4e8ff','#c8a8ff','#8a6ae8','#4a2a98'],
 slate:['#323e56','#3a4662','#2c364c','#263042','#424e6a'],stone:{rock:'#4a5470',rockL:'#7a86a8',rockD:'#262c44'}};
/* the land: rock everywhere but the chasms; the roads, the pads and the rod plinths stay solid */
function rpw3aStormField(map,G,cast){const dR=rpw3aDR(G),holes=[[960,165,140,100],[80,470,130,80],[525,580,100,64],[1110,775,190,80],[110,30,200,52],[1560,800,120,80],[1000,330,70,42]];
 const ell=(x,y,b)=>{const dx=(x-b[0])/b[2],dy=(y-b[1])/b[3];return(1-Math.sqrt(dx*dx+dy*dy))*Math.min(b[2],b[3])};
 return(x,y)=>{const n=rpw3aN(x,y,2)*16+rpw3aN(x*2.2,y*2.2,6)*7;let f=90+n;for(const h of holes)f=Math.min(f,-ell(x,y,h)+n*.8);
  f=Math.max(f,56-dR(x,y));for(const p of G.pads)f=Math.max(f,ell(x,y,[p.x,p.y+8,70,40]));for(const r of map.rods||[])f=Math.max(f,ell(x,y,[r[0],r[1],50,30]));
  if(x>cast.x-30&&y>cast.y+420)f=Math.max(f,30);return f}}
/* a mountain gate the monsters come out of: a rock mound with a masonry arch and a glowing keystone */
function rpw3aGateArt(g,x,y){g.save();g.translate(x,y);const P=RPW3A_SP.stone;
 g.fillStyle=P.rock;g.strokeStyle=RPO;g.lineWidth=3;g.beginPath();g.moveTo(-76,58);g.lineTo(-66,-34);g.quadraticCurveTo(-40,-100,10,-90);g.quadraticCurveTo(64,-80,72,-14);g.lineTo(76,58);g.closePath();g.fill();g.stroke();
 g.save();g.clip();g.fillStyle='rgba(0,0,0,.28)';g.fillRect(6,-110,90,180);g.fillStyle=P.rockL;g.globalAlpha=.35;g.beginPath();g.moveTo(-62,-24);g.quadraticCurveTo(-38,-92,10,-84);g.lineTo(-10,-66);g.quadraticCurveTo(-42,-56,-54,-4);g.closePath();g.fill();g.globalAlpha=1;
 g.strokeStyle='rgba(18,8,31,.4)';g.lineWidth=1.4;for(let k=0;k<6;k++){g.beginPath();g.moveTo(-60+k*22,-60+rpw3aR(k)*20);g.lineTo(-56+k*22+rpw3aR(k+3)*8,-20+rpw3aR(k+5)*30);g.stroke()}g.restore();
 /* masonry arch */g.beginPath();g.moveTo(-48,56);g.lineTo(-48,-14);g.arc(0,-14,48,Math.PI,0);g.lineTo(48,56);g.closePath();g.fillStyle='#7a84a0';g.fill();rpw3aO(g,2.4);
 g.strokeStyle='rgba(18,8,31,.5)';g.lineWidth=1.3;g.beginPath();for(let i=1;i<9;i++){const a=Math.PI+i/9*Math.PI;g.moveTo(Math.cos(a)*38,-14+Math.sin(a)*38);g.lineTo(Math.cos(a)*48,-14+Math.sin(a)*48)}for(let yy=-4;yy<56;yy+=10){g.moveTo(-48,yy);g.lineTo(-38,yy);g.moveTo(38,yy);g.lineTo(48,yy)}g.stroke();
 g.beginPath();g.moveTo(-38,56);g.lineTo(-38,-14);g.arc(0,-14,38,Math.PI,0);g.lineTo(38,56);g.closePath();g.fillStyle='#080a14';g.fill();rpw3aO(g,2.4);
 const q=g.createLinearGradient(0,-50,0,56);q.addColorStop(0,'rgba(8,10,20,1)');q.addColorStop(1,'rgba(90,160,255,.3)');g.fillStyle=q;g.fill();
 g.strokeStyle='#3a3e52';g.lineWidth=2.6;g.beginPath();for(let xx=-32;xx<=32;xx+=8){g.moveTo(xx,-48+Math.abs(xx)*.5);g.lineTo(xx,-26)}g.moveTo(-36,-30);g.lineTo(36,-30);g.stroke();
 g.fillStyle='#9ae8ff';g.beginPath();g.moveTo(-7,-66);g.lineTo(7,-66);g.lineTo(5,-50);g.lineTo(-5,-50);g.closePath();g.fill();rpw3aO(g,1.8);g.restore()}
/* a crackling spire: a dark stone obelisk banded with glowing runes, a copper crown of prongs holding the orb (arcs are live) */
function rpw3aSpire(g,x,y){g.save();g.translate(x,y);rpBlob(g,4,2,36,11,'#000',.4);
 rpw3aBox(g,0,0,56,18,32,['#3e4864','#5e6888']);rpw3aBox(g,0,-18,40,10,24,['#4a5470','#6a7494']);
 const L=()=>{g.beginPath();g.moveTo(-15,-28);g.lineTo(-8,-118);g.lineTo(0,-124);g.lineTo(0,-28);g.closePath()},Rt=()=>{g.beginPath();g.moveTo(0,-28);g.lineTo(0,-124);g.lineTo(8,-118);g.lineTo(15,-28);g.closePath()};
 L();g.fillStyle='#5a6484';g.fill();Rt();g.fillStyle='#2e3550';g.fill();g.beginPath();g.moveTo(-15,-28);g.lineTo(-8,-118);g.lineTo(0,-124);g.lineTo(8,-118);g.lineTo(15,-28);g.closePath();rpw3aO(g,2.4);
 g.strokeStyle='rgba(255,255,255,.25)';g.lineWidth=1.4;g.beginPath();g.moveTo(-12,-34);g.lineTo(-6,-114);g.stroke();
 for(const yy of[-48,-74,-98]){const hw=15-(-28-yy)*7/90;g.fillStyle='#2a2e44';g.beginPath();g.rect(-hw-2,yy-4,hw*2+4,8);g.fill();rpw3aO(g,1.6);g.fillStyle='#9ae8ff';for(let k=-1;k<=1;k++){g.fillRect(k*hw*.6-1.5,yy-2,3,4)}}
 /* copper crown */for(const s of[-1,1])for(const k of[0,1]){const ox=s*(5+k*6);g.strokeStyle=RPO;g.lineWidth=5;g.beginPath();g.moveTo(s*3,-122);g.quadraticCurveTo(ox*1.6,-128-k*4,ox*1.2,-146+k*6);g.stroke();g.strokeStyle='#d8843a';g.lineWidth=2.6;g.stroke()}
 g.fillStyle='#c8743a';g.beginPath();g.ellipse(0,-122,9,3.4,0,0,TAU);g.fill();rpw3aO(g,1.6);
 g.fillStyle='#bff0ff';g.beginPath();g.arc(0,-136,8,0,TAU);g.fill();rpw3aO(g,2.2);g.fillStyle='#ffffff';g.beginPath();g.arc(-2.6,-139,3,0,TAU);g.fill();g.restore()}
/* a blue-fire brazier (the flame is live) */
function rpw3aBrazier(g,x,y){g.save();g.translate(x,y);rpBlob(g,2,1,13,4,'#000',.35);g.strokeStyle=RPO;g.lineWidth=4;g.beginPath();g.moveTo(-8,0);g.lineTo(0,-16);g.lineTo(8,0);g.stroke();g.strokeStyle='#5a6480';g.lineWidth=2.2;g.stroke();
 g.beginPath();g.moveTo(-13,-18);g.lineTo(13,-18);g.lineTo(9,-26);g.lineTo(-9,-26);g.closePath();g.fillStyle='#3a4058';g.fill();rpw3aO(g,1.8);g.fillStyle='#1a2a4a';g.beginPath();g.ellipse(0,-26,9,3,0,0,TAU);g.fill();g.restore()}
function rpw3aDeadTree(g,x,y,h,i){g.save();g.translate(x,y);rpBlob(g,h*.1,1,h*.3,h*.08,'#000',.3);const lean=-.15-rpw3aR(i)*.2;g.lineCap='round';
 const br=()=>{g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(-h*.05,-h*.4,h*lean,-h*.8);g.moveTo(-h*.02,-h*.42);g.lineTo(-h*.3,-h*.62);g.lineTo(-h*.42,-h*.6);g.moveTo(h*lean*.6,-h*.6);g.lineTo(h*.22,-h*.86);g.moveTo(-h*.03,-h*.25);g.lineTo(h*.2,-h*.36)};
 br();g.strokeStyle=RPO;g.lineWidth=h*.1+2.6;g.stroke();br();g.strokeStyle='#3a3440';g.lineWidth=h*.1;g.stroke();g.strokeStyle='rgba(154,232,255,.35)';g.lineWidth=1.2;g.beginPath();g.moveTo(-1,-h*.1);g.lineTo(-2,-h*.4);g.stroke();g.restore()}
function rpw3aPillar(g,x,y,h,i){g.save();g.translate(x,y);rpBlob(g,3,1,16,5,'#000',.3);rpw3aBox(g,0,0,30,8,16,['#4a5470','#6a7494']);
 g.beginPath();g.moveTo(-10,-12);g.lineTo(-10,-h);g.lineTo(-3,-h-6);g.lineTo(4,-h+2);g.lineTo(10,-h-3);g.lineTo(10,-12);g.closePath();const q=g.createLinearGradient(-10,0,10,0);q.addColorStop(0,'#7a86a8');q.addColorStop(1,'#3a4260');g.fillStyle=q;g.fill();rpw3aO(g,2);
 g.strokeStyle='rgba(18,8,31,.4)';g.lineWidth=1.2;g.beginPath();for(const dx of[-4,3]){g.moveTo(dx,-14);g.lineTo(dx,-h+4)}g.stroke();if(i%2){g.fillStyle='#9ae8ff';g.globalAlpha=.85;g.beginPath();g.arc(0,-h*.55,3,0,TAU);g.fill();g.globalAlpha=1}g.restore()}
/* bake Storm Citadel */
function rpw3aBakeStorm(map){const G=rpGeo(map),H=900,SP=RPW3A_SP,pal=Object.assign({},RP_PAL.storm),dR=rpw3aDR(G);
 const CA=rpw3aCastle('storm'),cast={x:Math.round(G.gate.x-CA.gx),y:Math.round(G.gate.y-CA.gy),w:CA.w,h:CA.h};
 const M=rpw3aMask(rpw3aStormField(map,G,cast),4),land=(x,y,m)=>M.at(x,y)>(m||0);
 /* ---- the void: storm clouds far below ---- */
 const sky=rpw3aCv(1600,H),s=sky.getContext('2d');let q=s.createLinearGradient(0,0,0,H);q.addColorStop(0,'#1c2244');q.addColorStop(1,SP.void1);s.fillStyle=q;s.fillRect(0,0,1600,H);
 for(let i=0;i<70;i++){const x=rpw3aR(i+21)*1700-50,y=rpw3aR(i+41)*H,sc=16+rpw3aR(i+61)*26;rpw3aCloud(s,x,y,sc,['#4a5582','#3e4874','#56628e'][i%3],'rgba(10,12,30,.55)',null)}
 s.globalCompositeOperation='lighter';for(let i=0;i<10;i++){const x=rpw3aR(i+81)*1600,y=rpw3aR(i+91)*H;s.globalAlpha=.26;s.drawImage(rpwGlow('120,170,255',90),x-130,y-80,260,160)}s.globalCompositeOperation='source-over';s.globalAlpha=1;
 /* ---- the rock (B.isl: everything but the void) ---- */
 const isl=rpw3aCv(1600,H),g=isl.getContext('2d');g.lineJoin='round';g.lineCap='round';
 const top=rpw3aCv(1600,H),tg=top.getContext('2d');tg.lineJoin='round';q=tg.createLinearGradient(0,0,0,H);q.addColorStop(0,'#2e384e');q.addColorStop(1,'#232a3c');tg.fillStyle=q;tg.fillRect(0,0,1600,H);
 /* slate slabs */for(let i=0;i<300;i++){const x=rpw3aR(i*3+7)*1640-20,y=rpw3aR(i*3+8)*940-20,r=22+rpw3aR(i*3+9)*34,n=5+(i%3),a0=rpw3aR(i)*TAU;tg.beginPath();for(let k=0;k<n;k++){const a=a0+k/n*TAU,rr=r*(.7+rpw3aR(i*7+k)*.4);tg.lineTo(x+Math.cos(a)*rr,y+Math.sin(a)*rr*.6)}tg.closePath();
  tg.fillStyle=SP.slate[i%5];tg.globalAlpha=.8;tg.fill();tg.globalAlpha=1;tg.strokeStyle='rgba(8,10,20,.45)';tg.lineWidth=1.6;tg.stroke();tg.strokeStyle='rgba(170,200,255,.16)';tg.lineWidth=1.6;tg.beginPath();tg.moveTo(x-r*.6,y-r*.2);tg.lineTo(x,y-r*.5);tg.stroke()}
 /* moss and wet sheen */for(let i=0;i<170;i++){const x=rpw3aR(i+900)*1600,y=rpw3aR(i+950)*H,r=14+rpw3aR(i+990)*40;tg.fillStyle=i%3?'rgba(40,96,88,.5)':'rgba(64,124,100,.42)';tg.beginPath();tg.ellipse(x,y,r,r*.45,0,0,TAU);tg.fill()}
 for(let i=0;i<900;i++){const x=rpw3aR(i*2+1300)*1600,y=rpw3aR(i*2+1301)*H;tg.strokeStyle=i%2?'#3a7462':'#58a08a';tg.lineWidth=1.5;tg.beginPath();tg.moveTo(x,y);tg.quadraticCurveTo(x-3,y-4,x-7,y-6);tg.moveTo(x+2,y);tg.quadraticCurveTo(x,y-5,x-3,y-8);tg.stroke()}
 tg.strokeStyle='rgba(8,10,20,.55)';tg.lineWidth=1.6;for(let i=0;i<70;i++){let x=rpw3aR(i+1500)*1600,y=rpw3aR(i+1540)*H;tg.beginPath();tg.moveTo(x,y);for(let k=0;k<4;k++){x+=(rpw3aR(i*5+k)-.5)*40;y+=(rpw3aR(i*7+k)-.5)*20;tg.lineTo(x,y)}tg.stroke()}
 const TR=rpw3aTerrain(g,M,{D:48,top,coneL:90,cone:['#2e3450','#1a1e32'],glint:'#9ae8ff',vein:['rgba(90,170,255,.25)','#9ae8ff'],lip:'rgba(170,210,255,.35)',tuft:['#2e5a5a','#4a8a7a'],
  bands:[[0,'#2e5050'],[5,'#2a3046'],[12,'#3a4260'],[24,'#323a54'],[36,'#2a3048'],[48,'#22273c']]});
 /* battlements along the chasm rims */
 {const cl=(x,y)=>dR(x,y)<64||G.pads.some(p=>Math.abs(p.x-x)<64&&y>p.y-40&&y<p.y+70)||(map.rods||[]).some(r=>Math.hypot(r[0]-x,r[1]-y)<50)||x>cast.x-20&&y>cast.y+100||y>880||y<20;
  const W=TR.edgeB.filter((p,k)=>k%3===0&&!cl(p[0],p[1]-8)).sort((a,b)=>a[1]-b[1]);
  for(const [x,y] of W){const k=(x/12|0),tall=k%2===0,h=tall?17:12;g.fillStyle='#6a7494';g.beginPath();g.rect(x-6.5,y-h,13,h+2);g.fill();g.fillStyle='#8e98b6';g.fillRect(x-6.5,y-h,13,3.5);g.fillStyle='rgba(18,8,31,.25)';g.fillRect(x+2.5,y-h,4,h+2);
   g.strokeStyle=RPO;g.lineWidth=1.8;g.strokeRect(x-6.5,y-h,13,h+2)}}
 /* puddles on the rock */
 const pud=[],dRp=(x,y)=>dR(x,y),padNear=(x,y,r)=>G.pads.some(p=>Math.hypot(p.x-x,(p.y-y)*1.3)<r);
 for(let i=0;i<40;i++){const x=rpw3aR(i+2000)*1600,y=rpw3aR(i+2040)*H,r=10+rpw3aR(i+2080)*16;if(!land(x,y,20)||dRp(x,y)<56||padNear(x,y,70)||x>cast.x-10&&y>cast.y+120)continue;rpw3aPuddle(g,x,y,r);pud.push([x,y,r])}
 /* ---- the roads: wet flagstones in three courses, block curbs, puddles ---- */
 const own=G.paths.map(P=>({S:P.S,runs:rpw3aRuns(P.S.length,i=>P.own[i])}));
 for(const [w,col] of[[92,'rgba(0,0,0,.4)'],[80,'#10131f'],[74,'#8e98b4'],[62,'#262c40']])for(const o of own)for(const r of o.runs)rpw3aLine(g,o.S,Math.max(0,r[0]-1),r[1],w,col);
 for(const o of own){const S=o.S;for(const r of o.runs)for(let i=r[0];i<=r[1];i+=5){const p=S[i],nx=-Math.sin(p.a),ny=Math.cos(p.a),tx=Math.cos(p.a),ty=Math.sin(p.a);for(let l=-1;l<=1;l++){const off=l*19+((i/5|0)%2?3:-3),sh=(rpw3aR(i*3+l)-.5)*3,cx=p.x+nx*off+tx*sh,cy=p.y+ny*off+ty*sh,a=9,b=8.4;
   g.beginPath();g.moveTo(cx-tx*a-nx*b,cy-ty*a-ny*b);g.lineTo(cx+tx*a-nx*b,cy+ty*a-ny*b);g.lineTo(cx+tx*a+nx*b,cy+ty*a+ny*b);g.lineTo(cx-tx*a+nx*b,cy-ty*a+ny*b);g.closePath();
   g.fillStyle=SP.flag[(i+l*2)%5];g.fill();g.strokeStyle='rgba(16,18,34,.75)';g.lineWidth=1.4;g.stroke();g.strokeStyle='rgba(210,230,255,.32)';g.lineWidth=1.2;g.beginPath();g.moveTo(cx-tx*a*.7-nx*b*.6,cy-ty*a*.7-ny*b*.6);g.lineTo(cx+tx*a*.5-nx*b*.6,cy+ty*a*.5-ny*b*.6);g.stroke()}}}
 for(const o of own){const S=o.S;for(const r of o.runs)for(let i=r[0]+12;i<r[1];i+=29){if(rpw3aR(i+5)<.45)continue;const p=S[i],off=(rpw3aR(i)-.5)*30;rpw3aPuddle(g,p.x-Math.sin(p.a)*off,p.y+Math.cos(p.a)*off,8+rpw3aR(i+1)*8,p.a);pud.push([p.x-Math.sin(p.a)*off,p.y+Math.cos(p.a)*off,10])}}
 for(const o of own){const S=o.S;for(const r of o.runs)for(let i=r[0];i<=r[1];i+=3)for(const sd of[-1,1]){const p=S[i],x=p.x-Math.sin(p.a)*36*sd,y=p.y+Math.cos(p.a)*36*sd;if(dR(x,y)<31)continue;g.save();g.translate(x,y);g.rotate(p.a);
   g.fillStyle=SP.curb[(i/3|0)%2];g.beginPath();g.rect(-6,-4.5,11,9);g.fill();g.strokeStyle=RPO;g.lineWidth=1.5;g.stroke();g.fillStyle='rgba(255,255,255,.22)';g.fillRect(-6,-4.5,11,2.4);g.restore()}}
 g.strokeStyle='rgba(160,220,255,.35)';g.lineWidth=4;for(const o of own){const S=o.S;for(const r of o.runs)for(let i=r[0]+40;i<r[1]-30;i+=40){const p=S[i];g.save();g.translate(p.x,p.y);g.rotate(p.a);g.beginPath();g.moveTo(-6,-9);g.lineTo(4,0);g.lineTo(-6,9);g.stroke();g.restore()}}
 /* ---- lightning rods: rune plinths and the ring of ground they guard (the masts are drawn above everything) ---- */
 for(const [rx,ry] of map.rods||[]){const RR=map.rodR||130;g.save();g.setLineDash([10,9]);g.strokeStyle='rgba(154,232,255,.28)';g.lineWidth=2.4;g.beginPath();g.ellipse(rx,ry,RR,RR*.8,0,0,TAU);g.stroke();g.restore();
  for(let k=0;k<10;k++){const a=k/10*TAU,x=rx+Math.cos(a)*RR,y=ry+Math.sin(a)*RR*.8;g.fillStyle='rgba(154,232,255,.45)';g.beginPath();g.moveTo(x,y-4);g.lineTo(x+3,y);g.lineTo(x,y+4);g.lineTo(x-3,y);g.closePath();g.fill()}
  rpBlob(g,rx+4,ry+4,34,12,'#000',.35);g.fillStyle='#3a4260';g.beginPath();g.ellipse(rx,ry,30,14,0,0,TAU);g.fill();rpw3aO(g,2.4);g.fillStyle='#525c7c';g.beginPath();g.ellipse(rx,ry-5,24,11,0,0,TAU);g.fill();rpw3aO(g,2);
  g.strokeStyle='#9ae8ff';g.lineWidth=1.6;g.globalAlpha=.8;for(let k=0;k<6;k++){const a=k/6*TAU;g.beginPath();g.moveTo(rx+Math.cos(a)*15,ry-5+Math.sin(a)*7);g.lineTo(rx+Math.cos(a+.3)*19,ry-5+Math.sin(a+.3)*9);g.stroke()}g.globalAlpha=1}
 /* ---- props ---- */
 const rods=map.rods||[],O=rpw3aOcc(G,cast,{rw:40,ok:(x,y,w,h)=>land(x-w*.8,y,6)&&land(x+w*.8,y,6)&&land(x,y+6,8)&&!rods.some(r=>Math.abs(x-r[0])<36+w&&y>r[1]-40&&y-h<r[1]+20)&&y-h>30});
 const spires=[];{const C=[];for(let y=200;y<=740;y+=16)for(let x=60;x<=1290;x+=16)if(O.ok(x,y,26,140,10))C.push([x,y]);
  while(spires.length<3&&C.length){let best=null,bs=-1;for(const c of C){const d=spires.length?Math.min(...spires.map(m=>Math.hypot(m.x-c[0],m.y-c[1]))):400,sc=Math.min(d,400)+(c[1]>230?30:0);if(sc>bs){bs=sc;best=c}}if(!best||bs<200)break;
   O.add(best[0],best[1],26,140);spires.push({x:best[0],y:best[1]});for(let i=C.length-1;i>=0;i--)if(Math.hypot(C[i][0]-best[0],C[i][1]-best[1])<180)C.splice(i,1)}}
 const lamps=[];for(const P of G.paths){const S=P.S;for(let i=30;i<S.length-20;i+=38){if(!P.own[i])continue;const p=S[i],sd=(i/38|0)%2?1:-1,x=p.x-Math.sin(p.a)*52*sd,y=p.y+Math.cos(p.a)*52*sd;if(O.take(x,y,6,44,-4)){lamps.push([x,y])}}}
 g.save();g.globalCompositeOperation='lighter';for(const [x,y] of lamps){g.globalAlpha=.3;g.drawImage(rpwGlow('255,180,90',40),x-46,y-26,92,52)}g.restore();
 g.save();g.globalCompositeOperation='lighter';for(const r of rods){g.globalAlpha=.32;g.drawImage(rpwGlow('110,190,255',60),r[0]-110,r[1]-60,220,120)}for(const sp of spires){g.globalAlpha=.3;g.drawImage(rpwGlow('110,190,255',60),sp.x-100,sp.y-50,200,100)}g.restore();
 const items=[],KIND=[['crys',.16,14,36,2],['dead',.14,18,56,6],['boulder',.2,16,20,2],['pillar',.12,14,52,4],['brazier',.04,12,30,2],['vcrys',.06,14,30,2],['banner',.06,8,62,4],['rubble',.12,14,10,0],['grass',.1,12,16,0]];
 for(let i=0;i<5000&&items.length<140;i++){const x=rpw3aR(i*4+31)*1640-20,y=rpw3aR(i*4+32)*(H+40)-20;let r=rpw3aR(i*4+33),K=KIND[0];for(const k of KIND){if(r<k[1]){K=k;break}r-=k[1]}if(!O.take(x,y,K[2],K[3],K[4]))continue;items.push({x,y,k:K[0],i})}
 for(const sp of spires)items.push({x:sp.x,y:sp.y,k:'spire',i:0});for(const [x,y] of lamps)items.push({x,y,k:'lamp',i:0});items.sort((a,b)=>a.y-b.y);const fl=[];
 for(const it of items){const{x,y,k,i}=it;if(k==='spire')rpw3aSpire(g,x,y);else if(k==='crys'||k==='vcrys'){const C=k==='crys'?SP.crys:SP.vio;for(const [dx,h,a] of[[-7,22+i%3*5,-.3],[0,30+i%4*4,0],[8,18,.35]])rpwCrystal(g,x+dx,y,h,a,0,C)}
  else if(k==='dead')rpw3aDeadTree(g,x,y,48+i%4*6,i);else if(k==='boulder')rpwBoulder(g,SP.stone,x,y,26+i%3*6,18+i%2*6,i);else if(k==='pillar')rpw3aPillar(g,x,y,42+i%3*8,i);
  else if(k==='brazier'){rpw3aBrazier(g,x,y);fl.push([x,y-26])}else if(k==='banner')rpw3aStormBanner(g,x,y,i);else if(k==='lamp'){rpw3aLamp(g,x,y);fl.push([x+7.5,y-31,1])}else if(k==='grass'){for(let j=0;j<7;j++){const a=(j/6-.5)*1.4,l=12+rpw3aR(i+j)*10;g.strokeStyle=j%2?'#2e6a5a':'#5aa08a';g.lineWidth=2.4;g.beginPath();g.moveTo(x+j*2-6,y);g.quadraticCurveTo(x+j*2-6+a*5,y-l*.6,x+j*2-6+a*12-4,y-l);g.stroke()}}else{for(let j=0;j<4;j++)rpwBoulder(g,SP.stone,x-10+j*7,y+(j%2)*3,8+j%2*4,6+j%3*2,i+j)}}
 /* the mountain gates and the citadel */
 for(const e of G.ent)rpw3aGateArt(g,Math.max(30,e.x-14),e.y);
 g.drawImage(CA.c,cast.x,cast.y,CA.w,CA.h);
 /* storm light: darker edges, a cold glow over the middle */
 q=g.createRadialGradient(760,460,200,760,460,980);q.addColorStop(0,'rgba(10,12,30,0)');q.addColorStop(1,'rgba(10,12,30,.5)');g.fillStyle=q;g.globalCompositeOperation='source-atop';g.fillRect(0,0,1600,H);g.globalCompositeOperation='source-over';
 const c=rpw3aCv(1600,H),cg=c.getContext('2d');cg.drawImage(sky,0,0);cg.drawImage(isl,0,0);M.m=null;
 return{c,isl,pal,G,trees:items,cast,id:map.id,M,pud,spires,fl,occ:O.L,
  clouds:[[168,960],[470,80],[580,525],[775,1110],[330,1000]].map(([y,x],i)=>({y:y+(rpw3aR(i+3)-.5)*30,v:10+rpw3aR(i+7)*14,x0:x+600})),
  rain:[...Array(160)].map((_,i)=>[rpw3aR(i+4000)*1700,rpw3aR(i+4200)*900,.8+rpw3aR(i+4400)*.5])}}
function rpw3aPuddle(g,x,y,r,a){g.save();g.translate(x,y);g.rotate(a||0);g.beginPath();g.ellipse(0,0,r*1.6,r*.62,0,0,TAU);const q=g.createLinearGradient(0,-r,0,r);q.addColorStop(0,'#8aa8d8');q.addColorStop(.5,'#3a4a78');q.addColorStop(1,'#1e2846');g.fillStyle=q;g.fill();
 g.strokeStyle='rgba(10,12,26,.6)';g.lineWidth=1.4;g.stroke();g.strokeStyle='rgba(220,240,255,.6)';g.lineWidth=1.6;g.beginPath();g.moveTo(-r*.9,-r*.15);g.lineTo(-r*.2,-r*.32);g.stroke();g.restore()}
function rpw3aStormBanner(g,x,y,i){g.save();g.translate(x,y);rpBlob(g,2,1,8,3,'#000',.3);g.strokeStyle=RPO;g.lineWidth=4.6;g.beginPath();g.moveTo(0,0);g.lineTo(0,-62);g.stroke();g.strokeStyle='#8a94b0';g.lineWidth=2.6;g.stroke();
 g.beginPath();g.moveTo(1,-58);g.lineTo(22,-56);g.lineTo(20,-30);g.lineTo(12,-36);g.lineTo(2,-28);g.closePath();g.fillStyle='#3a4ac8';g.fill();rpw3aO(g,1.8);
 g.fillStyle='#ffe46a';g.beginPath();g.moveTo(14,-54);g.lineTo(8,-45);g.lineTo(12,-45);g.lineTo(9,-37);g.lineTo(16,-48);g.lineTo(12,-48);g.closePath();g.fill();g.fillStyle='#9ae8ff';g.beginPath();g.arc(0,-64,3,0,TAU);g.fill();g.restore()}
/* live: drifting storm clouds and lightning in the void (covered again by B.isl patches), puddle ripples, spire arcs, blue braziers */
function rpw3aAmbStorm(c,R){const B=R.bake,t=R.t,lite=R.lite||R.rm;c.save();
 const PF=rpw3aPuff(7,260,90,['rgba(70,82,124,.8)','rgba(50,60,96,.5)','rgba(40,48,80,0)']);
 const patch=(x,y,w,h)=>{const sx=Math.max(0,Math.floor(x)),sy=Math.max(0,Math.floor(y)),sw=Math.min(1600,Math.ceil(x+w))-sx,sh=Math.min(900,Math.ceil(y+h))-sy;if(sw>0&&sh>0)c.drawImage(B.isl,sx,sy,sw,sh,sx,sy,sw,sh)};
 for(let i=0;i<B.clouds.length;i+=lite?2:1){if(i===4&&!lite)continue;const k=B.clouds[i],x=((k.x0+t*k.v)%(1600+PF.w))-PF.w/2,y=k.y;c.drawImage(PF.c,x-PF.w/2,y-PF.h/2);patch(x-PF.w/2,y-PF.h/2,PF.w,PF.h)}
 /* lightning deep in the clouds */
 {const ph=t%5.3,k=Math.floor(t/5.3);if(ph<.35&&!R.rm){const x=200+rpw3aR(k+11)*1200,y=120+rpw3aR(k+12)*640,a=(ph<.08||ph>.16&&ph<.22)?1:.35;c.globalCompositeOperation='lighter';c.globalAlpha=.45*a;c.drawImage(rpwGlow('140,190,255',90),x-160,y-100,320,200);
   c.strokeStyle='#cfe8ff';c.lineWidth=2;c.globalAlpha=.6*a;c.beginPath();let px=x-30,py=y-80;c.moveTo(px,py);for(let j=0;j<6;j++){px+=(rpw3aR(k*9+j)-.4)*30;py+=26;c.lineTo(px,py)}c.stroke();c.globalCompositeOperation='source-over';c.globalAlpha=1;patch(x-160,y-100,320,200)}}
 /* shadows of the storm clouds drifting over the citadel */
 if(!R.rm){const SH=rpw3aPuff(8,360,170,['rgba(6,8,20,.34)','rgba(6,8,20,.2)','rgba(6,8,20,0)']);for(let i=0;i<(lite?0:2);i++){const x=((t*(16+i*5)+i*900)%2100)-250,y=260+i*300+Math.sin(t*.1+i)*30;c.drawImage(SH.c,x-SH.ax,y-SH.ay)}}
 /* rain rings in the puddles */
 if(!R.rm&&!lite){c.strokeStyle='rgba(200,225,255,.55)';c.lineWidth=1.2;c.beginPath();for(let i=(t*.7|0)%2;i<B.pud.length;i+=2){const [x,y,r]=B.pud[i],u=(t*1.4+i*.37)%1,rr=r*.3+u*r*.9;c.moveTo(x+rr*1.5,y);c.ellipse(x,y,rr*1.5,rr*.55,0,0,TAU)}c.stroke()}
 /* crackling arcs between the spires (or from each orb) */
 c.globalCompositeOperation='lighter';const S=B.spires;
 for(let i=0;i<S.length;i++){const a=S[i],ax=a.x,ay=a.y-136;c.globalAlpha=.5+.25*Math.sin(t*9+i);c.drawImage(rpwGlow('140,210,255',30),ax-30,ay-30,60,60);if(lite)continue;
  const b=S[(i+1)%S.length],near=S.length>1&&Math.hypot(b.x-a.x,b.y-a.y)<520,on=(t*1.7+i*.53)%1<.7;if(!on)continue;const k=Math.floor(t*14+i*7),bx=near?b.x:a.x+(rpw3aR(k)-.5)*90,by=near?b.y-136:a.y-60-rpw3aR(k+1)*40;
  c.strokeStyle='rgba(150,210,255,.35)';c.lineWidth=6;c.beginPath();let px=ax,py=ay;c.moveTo(px,py);const n=near?9:5;const pts=[];for(let j=1;j<=n;j++){const u=j/n;px=ax+(bx-ax)*u+(j<n?(rpw3aR(k*13+j)-.5)*34:0);py=ay+(by-ay)*u-(near?Math.sin(u*Math.PI)*30:0)+(j<n?(rpw3aR(k*7+j)-.5)*22:0);pts.push([px,py]);c.lineTo(px,py)}c.stroke();
  c.strokeStyle='#e8f8ff';c.lineWidth=1.8;c.beginPath();c.moveTo(ax,ay);for(const p of pts)c.lineTo(p[0],p[1]);c.stroke()}
 /* blue braziers */
 for(let i=0;i<B.fl.length;i++){const [x,y,w]=B.fl[i],f=.85+.15*Math.sin(t*13+i*3)+.08*Math.sin(t*29+i);if(w){if(lite||i%2)continue;c.globalAlpha=.45+.1*Math.sin(t*7+i);c.drawImage(rpwGlow('255,190,100',20),x-13,y-13,26,26);continue}c.globalAlpha=.5;c.drawImage(rpwGlow('90,170,255',24),x-16,y-24,32,32);c.globalAlpha=1;c.fillStyle='#5ab8ff';c.beginPath();c.ellipse(x,y-6*f,5,9*f,0,0,TAU);c.fill();c.fillStyle='#e8f8ff';c.beginPath();c.ellipse(x,y-4*f,2.4,4.6*f,0,0,TAU);c.fill()}
 c.globalCompositeOperation='source-over';c.globalAlpha=1;c.restore();rpw3aCastleLive(c,'storm',B.cast.x,B.cast.y,t,lite)}
/* twist (on the ground, under the monsters): scorch marks where the bolts land, lingering a few seconds */
function rpw3aTwStorm(c,R){const t=R.t;if(!R._w3sc)R._w3sc=[];const L=R._w3sc;for(const b of R.bolts||[])if(!b._w3){b._w3=1;L.push({x:b.x,y:b.tw?b.y+60:b.rod?b.y+70:b.y+10,t0:t,s:b.rod?.6:1})}
 for(let i=L.length-1;i>=0;i--)if(t-L[i].t0>6||t<L[i].t0)L.splice(i,1);if(!L.length)return;c.save();
 for(const s of L){const u=(t-s.t0)/6,a=1-u;c.globalAlpha=.55*a;c.fillStyle='#0a0c14';c.beginPath();c.ellipse(s.x,s.y,30*s.s,13*s.s,0,0,TAU);c.fill();c.globalAlpha=.7*a;c.strokeStyle='#0a0c14';c.lineWidth=2;c.beginPath();
  for(let k=0;k<7;k++){const an=k/7*TAU+s.x,l=(26+rpw3aR(k+s.x)*24)*s.s;c.moveTo(s.x+Math.cos(an)*10,s.y+Math.sin(an)*4);c.lineTo(s.x+Math.cos(an)*l,s.y+Math.sin(an)*l*.45)}c.stroke();
  if(u<.5){c.globalCompositeOperation='lighter';c.globalAlpha=(.5-u)*1.2;c.drawImage(rpwGlow('140,200,255',30),s.x-34,s.y-16,68,32);c.globalCompositeOperation='source-over'}}
 c.restore()}
/* above everything: the rod masts, rain, the lightning bolts and the flash */
function rpw3aRodSpr(){return rpw3aSpr('rod',44,96,22,90,g=>{g.beginPath();g.moveTo(-5,-4);g.lineTo(-3,-70);g.lineTo(0,-82);g.lineTo(3,-70);g.lineTo(5,-4);g.closePath();const q=g.createLinearGradient(-5,0,5,0);q.addColorStop(0,'#5a6480');q.addColorStop(.4,'#c8d0e8');q.addColorStop(1,'#262c44');g.fillStyle=q;g.fill();rpw3aO(g,2);
 for(const [yy,r] of[[-22,11],[-38,9],[-52,7]]){g.fillStyle='#c8743a';g.beginPath();g.ellipse(0,yy,r,r*.34,0,0,TAU);g.fill();rpw3aO(g,1.6);g.strokeStyle='#ffb27a';g.lineWidth=1;g.beginPath();g.ellipse(0,yy-1,r*.75,r*.2,0,Math.PI*1.1,Math.PI*1.7);g.stroke()}
 g.fillStyle='#9ae8ff';g.beginPath();g.arc(0,-72,4.5,0,TAU);g.fill();rpw3aO(g,1.6)})}
function rpw3aTopStorm(c,R){const B=R.bake,t=R.t,lite=R.lite||R.rm,m=R.map;
 /* rod masts (in front of the towers near them) */
 const RS=rpw3aRodSpr();(m.rods||[]).forEach((r,i)=>{const k=R.rodK?R.rodK[i]||0:0;c.drawImage(RS.c,r[0]-RS.ax,r[1]+2-RS.ay);c.globalCompositeOperation='lighter';c.globalAlpha=.35+.15*Math.sin(t*4+i)+k*.65;c.drawImage(rpwGlow('140,210,255',30),r[0]-30-k*20,r[1]-70-30-k*20,60+k*40,60+k*40);
  if(k>0){c.globalAlpha=k;c.drawImage(rpwGlow('160,220,255',60),r[0]-130,r[1]-60,260,120);c.strokeStyle='#e8f8ff';c.lineWidth=1.6;c.beginPath();const s=Math.floor(t*20);for(let j=0;j<3;j++){let px=r[0],py=r[1]-70;c.moveTo(px,py);for(let q=0;q<4;q++){px=r[0]+(rpw3aR(s+j*5+q)-.5)*18;py+=16;c.lineTo(px,py)}}c.stroke()}
  c.globalCompositeOperation='source-over';c.globalAlpha=1});
 /* rain */
 if(!R.rm){const n=lite?36:90;c.strokeStyle='rgba(180,210,255,.4)';c.lineWidth=1.3;c.beginPath();for(let i=0;i<n;i++){const d=B.rain[i],x=((d[0]+t*140*d[2])%1700)-50,y=((d[1]+t*900*d[2])%960)-30;c.moveTo(x,y);c.lineTo(x-4*d[2],y-18*d[2])}c.stroke();
  c.strokeStyle='rgba(200,225,255,.4)';c.beginPath();for(let i=0;i<(lite?6:16);i++){const u=(t*2.3+i*.41)%1,k=Math.floor(t*2.3+i*.41),x=rpw3aR(k*31+i)*1600,y=120+rpw3aR(k*17+i)*700,rr=2+u*6;c.moveTo(x+rr,y);c.ellipse(x,y,rr,rr*.4,0,0,TAU)}c.stroke()}
 /* bolts: a jagged main stroke from the clouds with forks, a glow and sparks where it lands */
 for(const b of R.bolts||[]){const u=b.t/b.d,a=u<.15?1:Math.max(0,1-(u-.15)/.85),k=Math.floor(b.x*3+b.y*7)+Math.floor(t*18),x1=b.x,y1=b.y,x0=x1+(rpw3aR(k%97+3)-.5)*160,y0=-20;
  const pts=[[x0,y0]];const n=9;for(let j=1;j<n;j++){const v=j/n;pts.push([x0+(x1-x0)*v+(rpw3aR(k+j*3)-.5)*46*(1-v*.6),y0+(y1-y0)*v])}pts.push([x1,y1]);
  c.save();c.globalCompositeOperation='lighter';c.lineJoin='round';c.lineCap='round';
  const line=(P)=>{c.beginPath();c.moveTo(P[0][0],P[0][1]);for(let j=1;j<P.length;j++)c.lineTo(P[j][0],P[j][1])};
  const forks=[];for(let f=0;f<(lite?1:3);f++){const j=2+((rpw3aR(k+f*11)*(n-3))|0),p=pts[j],P=[p];let px=p[0],py=p[1];for(let q=0;q<3;q++){px+=(rpw3aR(k+f*7+q)-.5)*50+(f%2?16:-16);py+=22+rpw3aR(k+q)*14;P.push([px,py])}forks.push(P)}
  for(const [w,col,al,f] of[[12,'rgba(110,170,255,.32)',.8,0],[5.5,'rgba(170,215,255,.85)',1,1],[2.4,'#ffffff',1,1]]){c.globalAlpha=a*al;c.strokeStyle=col;c.lineWidth=w;line(pts);c.stroke();if(f){c.lineWidth=w*.6;for(const P of forks){line(P);c.stroke()}}}
  c.globalAlpha=a;c.drawImage(rpwGlow('170,215,255',60),x1-56,y1-40,112,80);c.globalAlpha=a*.8;c.drawImage(rpwGlow('255,255,255',24),x1-20,y1-20,40,40);
  if(u<.6){c.strokeStyle='#e8f8ff';c.lineWidth=1.6;c.beginPath();for(let s=0;s<8;s++){const an=-Math.PI*(.1+rpw3aR(s+k%13)*.8),v=20+u*90*rpw3aR(s+3),px=x1+Math.cos(an)*v,py=y1+Math.sin(an)*v*.6+u*u*60;c.moveTo(px,py);c.lineTo(px-Math.cos(an)*5,py-Math.sin(an)*5)}c.stroke()}
  c.globalAlpha=(1-u)*.9;c.strokeStyle='#cfe8ff';c.lineWidth=3*(1-u);c.beginPath();c.ellipse(x1,y1+8,14+u*60,(14+u*60)*.4,0,0,TAU);c.stroke();c.restore()}
 /* the flash: everything lights up for a moment */
 if(R.flash>0){c.save();c.globalAlpha=Math.min(1,R.flash)*(R.rm?.1:.2);c.fillStyle='#e4eeff';c.fillRect(0,0,1600,900);c.restore()}
 /* sheet lightning now and then, far away */
 if(!R.rm){const ph=t%7.7;if(ph<.18){c.save();c.globalAlpha=(ph<.06||ph>.11&&ph<.15)?.08:.03;c.fillStyle='#c8d8ff';c.fillRect(0,0,1600,900);c.restore()}}}
RPW.bake.storm=rpw3aBakeStorm;RPW.amb.storm=rpw3aAmbStorm;RPW.twist.storm=rpw3aTwStorm;RPW.ambTop.storm=rpw3aTopStorm;RPW.castleHit.storm=(c,x,y,k)=>rpw3aCastleHit('storm',c,x,y,k);

/* ======================================================================================================================
   Map icons (next-region cards) and the world painting for the hub
   ====================================================================================================================== */
const RPW3A_IC={};
function rpw3aIcon(id,w,h){w=Math.round(w||88);h=Math.round(h||88);const k=id+w+'x'+h;if(RPW3A_IC[k])return RPW3A_IC[k];const c=rpw3aCv(w,h),g=c.getContext('2d'),A=rpw3aCastle(id),r=Math.min(w,h)*.16;g.lineJoin='round';
 g.beginPath();g.roundRect(0,0,w,h,r);g.save();g.clip();const BG={meadow:['#8fd4ff','#4a9ce8','#5cc24a'],foundry:['#3a1e1c','#6a3226','#3a3844'],storm:['#1c2244','#2e384e','#232a3c']}[id];
 let q=g.createLinearGradient(0,0,0,h);q.addColorStop(0,BG[0]);q.addColorStop(.55,BG[1]);q.addColorStop(.62,BG[2]);q.addColorStop(1,BG[2]);g.fillStyle=q;g.fillRect(0,0,w,h);
 if(id==='meadow'){g.globalAlpha=.85;rpw3aCloud(g,w*.2,h*.3,h*.08,'#ffffff','#d6e4f6',null);rpw3aCloud(g,w*.85,h*.42,h*.06,'#ffffff','#d6e4f6',null);g.globalAlpha=1;g.fillStyle='#a87a52';g.beginPath();g.moveTo(-2,h*.62);g.lineTo(w+2,h*.62);g.lineTo(w*.7,h);g.lineTo(w*.3,h);g.closePath();g.fill()}
 if(id==='foundry'){g.globalCompositeOperation='lighter';g.globalAlpha=.6;g.drawImage(rpwGlow('255,120,30',60),w*.1,h*.45,w*.8,h*.6);g.globalCompositeOperation='source-over';g.globalAlpha=1;g.strokeStyle='rgba(18,8,31,.4)';g.lineWidth=1;for(let y=h*.62;y<h;y+=h*.1){g.beginPath();g.moveTo(0,y);g.lineTo(w,y);g.stroke()}}
 if(id==='storm'){g.globalCompositeOperation='lighter';g.globalAlpha=.5;g.drawImage(rpwGlow('120,180,255',60),-w*.1,-h*.1,w*.8,h*.6);g.globalAlpha=.9;g.strokeStyle='#e8f8ff';g.lineWidth=Math.max(1.5,h*.025);g.beginPath();g.moveTo(w*.18,0);g.lineTo(w*.24,h*.18);g.lineTo(w*.16,h*.26);g.lineTo(w*.26,h*.46);g.stroke();g.globalCompositeOperation='source-over';g.globalAlpha=1}
 const s=Math.min(h*.98/500,w*1.2/300),x0=w/2-160*s,y0=h-512*s-h*.02;g.imageSmoothingQuality='high';g.drawImage(s<.35?A.c:A.c2,x0,y0,A.w*s,A.h*s);
 q=g.createLinearGradient(0,0,0,h);q.addColorStop(0,'rgba(255,255,255,.12)');q.addColorStop(.4,'rgba(255,255,255,0)');g.fillStyle=q;g.fillRect(0,0,w,h);g.restore();
 g.beginPath();g.roundRect(1,1,w-2,h-2,r);g.strokeStyle='rgba(18,8,31,.85)';g.lineWidth=2;g.stroke();return RPW3A_IC[k]=c}
for(const id of['meadow','foundry','storm'])RPW.icon[id]=(w,h)=>rpw3aIcon(id,w,h);
/* a floating island for the painting: a noisy top (C = [top, top light, rock, rock dark]) over a tapering rock underside */
function rpw3aIsle(g,x,y,rx,ry,dep,C,seed){const N=30,T=[];for(let i=0;i<N;i++){const a=i/N*TAU,j=.9+rpw3aR(seed*13+i)*.16;T.push([x+Math.cos(a)*rx*j,y+Math.sin(a)*ry*j])}
 const U=[[x-rx*.98,y]];for(let k=1;k<=6;k++){const u=k/7;U.push([x-rx*(1-u)*(.9+rpw3aR(seed+k)*.15),y+dep*Math.pow(u,1.3)*(.8+rpw3aR(seed*3+k)*.25)])}U.push([x+(rpw3aR(seed)-.5)*rx*.2,y+dep]);for(let k=6;k>=1;k--){const u=k/7;U.push([x+rx*(1-u)*(.9+rpw3aR(seed+k+9)*.15),y+dep*Math.pow(u,1.4)*(.8+rpw3aR(seed*5+k)*.25)])}U.push([x+rx*.98,y]);
 /* hanging rocks under the rim */for(let k=0;k<7;k++){const u=(k+.5)/7,hx=x-rx*.85+u*rx*1.7,top=y+dep*.25*(1-Math.abs(u-.5)*2)+ry*.4,l=dep*(.2+rpw3aR(seed+k*3)*.25),w=rx*.08+rpw3aR(seed+k)*rx*.05;if(Math.abs(u-.5)<.15)continue;
  g.beginPath();g.moveTo(hx-w,top);g.quadraticCurveTo(hx-w*.3,top+l*.7,hx,top+l);g.quadraticCurveTo(hx+w*.4,top+l*.6,hx+w,top);g.closePath();g.fillStyle=C[3];g.fill();rpw3aO(g,2)}
 rpw3aPoly(g,U);let q=g.createLinearGradient(x-rx,0,x+rx,0);q.addColorStop(0,C[2]);q.addColorStop(1,C[3]);g.fillStyle=q;g.fill();g.save();g.clip();
 /* facets from the rim to the tip, lit from the left */const tip=U[7];for(let k=0;k<6;k++){const a=U[k],b=U[k+1];g.fillStyle=k%2?'rgba(255,230,200,.14)':'rgba(18,8,31,.12)';g.beginPath();g.moveTo(a[0],a[1]);g.lineTo(b[0],b[1]);g.lineTo(tip[0],tip[1]);g.closePath();g.fill()}
 for(let k=8;k<U.length-1;k++){const a=U[k],b=U[k+1];g.fillStyle=k%2?'rgba(18,8,31,.25)':'rgba(18,8,31,.1)';g.beginPath();g.moveTo(a[0],a[1]);g.lineTo(b[0],b[1]);g.lineTo(tip[0],tip[1]);g.closePath();g.fill()}
 g.strokeStyle='rgba(18,8,31,.4)';g.lineWidth=1.4;for(let k=0;k<6;k++){const u=(k+.5)/6,xx=x-rx*.75+u*rx*1.5,l=dep*(.18+rpw3aR(k+seed)*.22);g.beginPath();g.moveTo(xx,y+ry*.7);g.lineTo(xx+(tip[0]-xx)*.25+(rpw3aR(seed*7+k)-.5)*8,y+ry*.7+l*.5);g.lineTo(xx+(tip[0]-xx)*.4,y+ry*.7+l);g.stroke()}
 g.fillStyle='rgba(255,240,220,.18)';for(let k=0;k<14;k++){g.beginPath();g.ellipse(x-rx*.7+rpw3aR(seed+k*5)*rx*1.4,y+ry+rpw3aR(seed+k*3)*dep*.4,3,2,0,0,TAU);g.fill()}
 q=g.createLinearGradient(0,y,0,y+dep);q.addColorStop(0,'rgba(255,180,120,0)');q.addColorStop(1,'rgba(255,150,130,.3)');g.fillStyle=q;g.fillRect(x-rx,y,rx*2,dep);g.restore();rpw3aPoly(g,U);rpw3aO(g,2.6);
 rpw3aPoly(g,T);g.fillStyle=C[0];g.fill();g.save();g.clip();g.fillStyle=C[1];g.beginPath();g.ellipse(x-rx*.15,y-ry*.2,rx*.8,ry*.6,0,0,TAU);g.fill();g.restore();rpw3aPoly(g,T);rpw3aO(g,2.6);return T}
/* the world painting: Skyforge Heights at sunset */
let RPW3A_W=null;
function rpw3aWorld(){if(RPW3A_W)return RPW3A_W;const c=rpw3aCv(1600,900),g=c.getContext('2d');g.lineJoin='round';g.lineCap='round';
 const N={meadow:{x:300,y:590},foundry:{x:690,y:470},storm:{x:1030,y:330}},S=.46,W={c,nodes:N,scale:S,mills:[],smoke:[],ships:[],cast:[],bolt:null};
 /* sunset sky and a sea of clouds */
 let q=g.createLinearGradient(0,0,1600,900);q.addColorStop(0,'#2c1f5c');q.addColorStop(.45,'#7a3a7a');q.addColorStop(.75,'#e8706a');q.addColorStop(1,'#ffb46a');g.fillStyle=q;g.fillRect(0,0,1600,900);
 g.globalCompositeOperation='lighter';g.globalAlpha=.7;g.drawImage(rpwGlow('255,190,120',160),1060,420,700,560);g.globalAlpha=.35;g.drawImage(rpwGlow('255,140,170',160),200,300,900,500);g.globalCompositeOperation='source-over';g.globalAlpha=1;
 for(let i=0;i<90;i++){const x=rpw3aR(i+11)*1750-80,y=120+rpw3aR(i+41)*820,sc=18+rpw3aR(i+71)*30*(y/900+.4),u=y/900;const top=u<.45?'#a07ab8':u<.7?'#f0a0a8':'#ffd0a0',sh=u<.45?'rgba(60,30,100,.5)':'rgba(170,70,110,.45)';g.globalAlpha=.55+u*.4;rpw3aCloud(g,x,y,sc,top,sh,null)}g.globalAlpha=1;
 /* stars at the top */for(let i=0;i<60;i++){g.fillStyle='rgba(255,255,255,.7)';g.fillRect(rpw3aR(i+300)*1600,rpw3aR(i+330)*160,1.8,1.8)}
 /* skyship routes (dashed) */
 const route=(pts)=>{const L=rpwSpl(pts,6);g.save();g.setLineDash([12,10]);g.beginPath();g.moveTo(L[0][0],L[0][1]);for(const p of L)g.lineTo(p[0],p[1]);g.strokeStyle='rgba(18,8,31,.45)';g.lineWidth=6;g.stroke();g.strokeStyle='#ffe08a';g.lineWidth=3;g.stroke();g.restore();return L};
 /* the storm peak (back, upper right): a tall rock spire wrapped in dark clouds */
 {const x=N.storm.x,y=N.storm.y+20;g.save();g.globalAlpha=.9;for(let i=0;i<14;i++){const a=i/14*TAU,cx=x+Math.cos(a)*170,cy=y-30+Math.sin(a)*70;rpw3aCloud(g,cx,cy,24+rpw3aR(i)*12,'#3a3e66','rgba(10,10,30,.5)',null)}g.restore();
  g.globalCompositeOperation='lighter';g.globalAlpha=.4;g.drawImage(rpwGlow('120,170,255',90),x-200,y-200,400,320);g.globalCompositeOperation='source-over';g.globalAlpha=1;
  rpw3aIsle(g,x,y,150,52,330,['#3e4862','#4e5a78','#3a4058','#1a1e32'],7);
  g.save();g.globalCompositeOperation='lighter';g.strokeStyle='rgba(120,190,255,.6)';g.lineWidth=2;for(let k=0;k<6;k++){let px=x-110+k*44,py=y+30;g.beginPath();g.moveTo(px,py);for(let j=0;j<4;j++){px+=(rpw3aR(k*9+j)-.5)*20;py+=22+rpw3aR(k+j)*20;g.lineTo(px,py)}g.stroke()}g.restore();
  for(const [dx,dy,h] of[[-110,-6,40],[100,4,34],[-70,18,26],[124,16,22]])rpwCrystal(g,x+dx,y+dy,h,(rpw3aR(dx)-.5)*.6,0,RPW3A_SP.crys);
  for(const dx of[-130,-90,90,130]){g.fillStyle='#6a7494';g.beginPath();g.rect(x+dx-7,y-26,14,24);g.fill();rpw3aO(g,1.8)}
  W.bolt=[x,y-10];W.storm=[x,y]}
 /* the foundry island (middle): iron plates, chimneys, gears and a molten glow */
 {const x=N.foundry.x,y=N.foundry.y-10;rpw3aIsle(g,x,y,190,62,210,['#4a4450','#5e5866','#4a3a36','#241c1e'],3);
  g.save();rpw3aPoly(g,rpw3aIsleTop(x,y,190,62,3));g.clip();g.strokeStyle='rgba(18,8,31,.4)';g.lineWidth=1.4;for(let xx=x-200;xx<x+200;xx+=36){g.beginPath();g.moveTo(xx,y-70);g.lineTo(xx+10,y+70);g.stroke()}for(let yy=y-60;yy<y+70;yy+=22){g.beginPath();g.moveTo(x-200,yy);g.lineTo(x+200,yy);g.stroke()}
   g.globalCompositeOperation='lighter';g.globalAlpha=.6;g.drawImage(rpwGlow('255,120,30',60),x-160,y-40,160,90);g.globalCompositeOperation='source-over';g.globalAlpha=1;
   g.fillStyle='#ffb84a';g.beginPath();g.ellipse(x-80,y+6,34,12,0,0,TAU);g.fill();rpw3aO(g,2);g.fillStyle='#fff2b0';g.beginPath();g.ellipse(x-84,y+4,18,5,0,0,TAU);g.fill();g.restore();
  for(const [dx,dy,h,w] of[[-150,-10,96,18],[130,-16,120,22],[160,4,80,16],[-120,-30,70,14]]){const cx=x+dx,by=y+dy;g.beginPath();g.moveTo(cx-w/2,by);g.lineTo(cx-w*.4,by-h);g.lineTo(cx+w*.4,by-h);g.lineTo(cx+w/2,by);g.closePath();g.fillStyle='#8a4a3a';g.fill();rpw3aO(g,2.2);g.fillStyle='#2a2428';g.fillRect(cx-w*.5,by-h-5,w,6);W.smoke.push([cx,by-h-6,w])}
  for(const [dx,dy,r] of[[60,-30,26],[96,-8,16]]){const G=rpw3aGear('wg'+r,r,Math.round(r/3),RPW3A_FP.brass);g.drawImage(G.c,x+dx-G.ax,y+dy-G.ay);W.mills.push({x:x+dx,y:y+dy,r,gear:1})}
  W.glow=[x-80,y+6]}
 /* the meadow islands (front, lower left) with rope bridges */
 const MC=['#5cc24a','#86dc62','#a87a52','#5a4a48'];
 {const isl=[[110,470,80,30,150,11],[480,470,90,32,160,13],[N.meadow.x,N.meadow.y-14,200,64,240,5],[160,740,70,26,120,17]];
  const bridge=(x0,y0,x1,y1)=>{const n=12;g.strokeStyle=RPO;g.lineWidth=7;g.beginPath();for(let k=0;k<=n;k++){const u=k/n,xx=x0+(x1-x0)*u,yy=y0+(y1-y0)*u+Math.sin(u*Math.PI)*10;k?g.lineTo(xx,yy):g.moveTo(xx,yy)}g.stroke();g.strokeStyle='#b07a46';g.lineWidth=4;g.stroke();
   g.strokeStyle='rgba(18,8,31,.5)';g.lineWidth=1;for(let k=1;k<n;k++){const u=k/n,xx=x0+(x1-x0)*u,yy=y0+(y1-y0)*u+Math.sin(u*Math.PI)*10;g.beginPath();g.moveTo(xx-1,yy-3);g.lineTo(xx+1,yy+3);g.stroke()}};
  for(const [x,y,rx,ry,dep,sd] of isl)rpw3aIsle(g,x,y,rx,ry,dep,MC,sd);
  bridge(176,476,N.meadow.x-180,N.meadow.y-34);bridge(N.meadow.x+170,N.meadow.y-40,412,478);
  /* windmills, cottages, trees and flowers on the islands */
  for(const [x,y] of[[96,462],[500,462]]){g.save();g.translate(x,y);g.scale(.55,.55);rpw3aMill(g,0,0);g.restore();W.mills.push({x,y:y-86*.55,r:44*.55})}
  for(const [x,y,i] of[[150,478,1],[440,480,2],[N.meadow.x-150,N.meadow.y-20,3],[N.meadow.x+150,N.meadow.y-14,0]]){g.save();g.translate(x,y);g.scale(.6,.6);rpw3aHouse(g,0,0,i);g.restore()}
  for(const [x,y,i] of[[N.meadow.x-110,N.meadow.y,4],[N.meadow.x+104,N.meadow.y+6,5],[60,486,6],[530,488,7],[150,744,8],[184,738,10]]){if(i%3)rpOak(g,x,y,34,{tree:RPW3A_MP.tree,treeHi:RPW3A_MP.treeHi,trunk:RPW3A_MP.trunk},i);else rpw3aBlossom(g,x,y,34,i)}
  for(let i=0;i<70;i++){const a=rpw3aR(i+600)*TAU,r=Math.sqrt(rpw3aR(i+640)),x=N.meadow.x+Math.cos(a)*180*r,y=N.meadow.y-14+Math.sin(a)*52*r;if(Math.abs(x-N.meadow.x)<80)continue;g.fillStyle=['#ffe46a','#ffffff','#ff9ad8','#c8a0ff'][i%4];g.beginPath();g.arc(x,y,2.2,0,TAU);g.fill()}}
 /* skyship routes between the regions */
 W.routes=[route([[505,500],[540,440],[590,410],[600,400]]),route([[880,420],[900,380],[905,340],[905,320]]),route([[110,600],[40,640],[-40,660]])];
 /* the storm closes round the peak: a dark cloud mass on both flanks, in front of the rock */
 {const [x,y]=W.storm;for(let i=0;i<16;i++){const side=i%2?1:-1,cx=x+side*(120+rpw3aR(i+50)*90),cy=y+40+rpw3aR(i+60)*240,sc=20+rpw3aR(i+70)*16;rpw3aCloud(g,cx,cy,sc,i%3?'#2e3256':'#3a3e66','rgba(8,8,26,.55)',null)}
  g.save();g.globalCompositeOperation='lighter';for(let i=0;i<5;i++){g.globalAlpha=.22;g.drawImage(rpwGlow('130,180,255',60),x-200+rpw3aR(i+80)*400-60,y+40+rpw3aR(i+90)*220-40,120,80)}g.restore();
  g.strokeStyle='rgba(170,200,255,.35)';g.lineWidth=1.4;g.beginPath();for(let i=0;i<70;i++){const rx=x-230+rpw3aR(i+100)*460,ry=y-60+rpw3aR(i+110)*360;g.moveTo(rx,ry);g.lineTo(rx-4,ry+16)}g.stroke()}
 /* the castles at the nodes (labels hang below them) */
 for(const id of['storm','foundry','meadow']){const A=rpw3aCastle(id),n=N[id],x0=n.x-155*S,y0=n.y-512*S;g.fillStyle='rgba(0,0,0,.3)';g.beginPath();g.ellipse(n.x+8,n.y-4,140*S,22*S,0,0,TAU);g.fill();g.imageSmoothingQuality='high';g.drawImage(A.c2,x0,y0,A.w*S,A.h*S);W.cast.push({id,x0,y0})}
 /* a few low clouds in front, and the vignette */
 g.globalAlpha=.9;for(const [x,y,s] of[[40,820,30],[620,700,22],[900,640,26],[1180,760,30],[760,240,18],[420,250,20]])rpw3aCloud(g,x,y,s,'#ffd8c0','rgba(200,90,120,.4)',null);g.globalAlpha=1;
 q=g.createRadialGradient(170,120,40,170,120,560);q.addColorStop(0,'rgba(10,6,24,.55)');q.addColorStop(1,'rgba(10,6,24,0)');g.fillStyle=q;g.fillRect(0,0,800,700);
 q=g.createLinearGradient(0,660,0,900);q.addColorStop(0,'rgba(10,6,24,0)');q.addColorStop(1,'rgba(10,6,24,.5)');g.fillStyle=q;g.fillRect(0,660,1600,240);
 W.anim=(h,t)=>rpw3aWorldLive(h,t);return RPW3A_W=W}
function rpw3aIsleTop(x,y,rx,ry,seed){const N=30,T=[];for(let i=0;i<N;i++){const a=i/N*TAU,j=.9+rpw3aR(seed*13+i)*.16;T.push([x+Math.cos(a)*rx*j,y+Math.sin(a)*ry*j])}return T}
/* the painting's live layer: windmills and gears turn, chimney smoke, airships along the routes, lightning round the storm peak, castle lights */
function rpw3aWorldLive(g,t){const W=RPW3A_W;if(!W)return;g.save();
 const BL=rpw3aSpin('bl',rpw3aBlades(),TAU/4,20);for(const m of W.mills){if(m.gear){const n=Math.round(m.r/3),G=rpw3aGear('wg'+m.r,m.r,n,RPW3A_FP.brass);rpw3aSpinPut(g,rpw3aSpin('wg'+m.r,G,TAU/n,10),m.x,m.y,t*(m.r>20?.5:-.8))}else rpw3aSpinPut(g,BL,m.x,m.y,t*.8,.55)}
 const SM=rpw3aPuff(2,40,32,['rgba(60,50,60,.6)','rgba(60,50,60,.3)','rgba(60,50,60,0)']);for(let i=0;i<W.smoke.length;i++){const [x,y,w]=W.smoke[i];for(let k=0;k<3;k++){const u=(t*.22+k/3+i*.3)%1,s=.5+u*1.6;g.globalAlpha=(1-u)*.85;g.drawImage(SM.c,x-20*s+u*24,y-16*s-u*70,40*s,32*s)}}g.globalAlpha=1;
 /* airships along the routes */
 for(let i=0;i<W.routes.length;i++){const L=W.routes[i],u=((t*.05+i*.37)%1),p=L[Math.min(L.length-1,(u*L.length)|0)],S=rpw3aShip('wm'+i,.38,i===1?['#ffd45a','#c8402a','#8a2a1a','#ffffff']:['#ffffff','#3a8ae0','#2a5aa8','#ffd45a']);g.drawImage(S.c,p[0]-S.ax,p[1]-S.ay-14+Math.sin(t*1.4+i)*3)}
 /* the foundry glow and the storm */
 g.globalCompositeOperation='lighter';g.globalAlpha=.25+.12*Math.sin(t*2.2);g.drawImage(rpwGlow('255,120,30',60),W.glow[0]-70,W.glow[1]-40,140,80);
 if(W.bolt){const ph=t%3.1,k=Math.floor(t/3.1);if(ph<.3){const [x,y]=W.bolt,bx=x+(rpw3aR(k)-.5)*240,a=ph<.1||ph>.18&&ph<.24?1:.3;g.globalAlpha=.5*a;g.drawImage(rpwGlow('150,200,255',90),bx-120,y-180,240,220);
   g.strokeStyle='#e8f8ff';g.lineWidth=2.4;g.globalAlpha=a;g.beginPath();let px=bx+(rpw3aR(k+3)-.5)*40,py=y-190;g.moveTo(px,py);for(let j=0;j<7;j++){px+=(rpw3aR(k*7+j)-.5)*30;py+=26;g.lineTo(px,py)}g.stroke()}}
 g.globalCompositeOperation='source-over';g.globalAlpha=1;
 for(const it of W.cast){g.save();g.translate(it.x0,it.y0);g.scale(W.scale,W.scale);rpw3aCastleLive(g,it.id,0,0,t,1);g.restore()}
 g.restore()}
RPW.world[3]=()=>{const W=rpw3aWorld();return{c:W.c,nodes:W.nodes,scale:W.scale,anim:W.anim}};
