# python3 t_ui101.py [game.html] : Runestone Tower Defense 10.1 UI (98b, 98n, 98o): the Clockwork Hive and the Singularity Engine open
# from the start on every map, the twelve-button build ring on every pad of every map, the bar names, the audit fixes (text, How to
# Play, results, Tower Skins, locked world, tip under the info panel), the overlap / clipping / off-stage check on every screen
# (tools/td/rpu_ovl.js), and the new feedback: combo counter, wave-cleared fanfare, personal bests, star and mastery reveals, the hub's
# Next goals card, reduced motion and Performance mode, and that none of it pays coins or supply.
import asyncio,os,sys,json
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
OVL=open(os.path.join(HERE,'..','tools','td','rpu_ovl.js')).read() if os.path.exists(os.path.join(HERE,'..','tools','td','rpu_ovl.js')) else open(os.path.join(HERE,'rpu_ovl.js')).read()
SHOTS=os.path.join(HERE,'shots','w101_tdui');os.makedirs(SHOTS,exist_ok=True)
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:600]),flush=True)
    if not ok:FAIL.append(name)
SETUP="()=>{RS_ASK=false;WCRELAYS=[];ST.perfAsked=1;try{PFW.asked=true}catch(e){}const r=RPP();r.new99j=1;r.dragon=%s;r.stars=%s;r.mast={};r.rpu={};for(const k in r.tut)r.tut[k]=1;for(const k of ['build','wave','coins','upgrade','abil'])r.tut[k]=1;save()}"
MAPS=['moss','frost','ember','wonder','coral','wreck','abyss','meadow','foundry','storm']
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1600,'height':900});er=[]
        pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(H);await pg.wait_for_timeout(1500);E=pg.evaluate;await E(OVL)
        # ---------- 1. the new towers from the start ----------
        await E(SETUP%(0,'{}'))
        r=await E("""async()=>{const out=[rpwTwLocked('hive'),rpwTwLocked('grav'),Object.keys(RPW_TWNEED).length,rpWorldOpen(2)];rpStart('moss');const R=RPX;R.tut=null;R.supply=5000;await new Promise(r=>setTimeout(r,300));
          out.push(document.querySelectorAll('.rpbar .rpcard').length,!!document.querySelector('.rpbar .rpcard[data-tw="hive"]'),!!document.querySelector('.rpbar .rpcard[data-tw="grav"]'),document.getElementById('rphud').classList.contains('rp12'));
          const ok1=rpBuild(R.pads[0],'hive'),ok2=rpBuild(R.pads[1],'grav');out.push(ok1!==false&&!!R.pads[0].tw&&R.pads[0].tw.type,ok2!==false&&!!R.pads[1].tw&&R.pads[1].tw.type);
          R.sel=null;R.place=null;R.selPad=R.pads[3];await new Promise(r=>setTimeout(r,120));out.push(document.querySelectorAll('#rpring .rprb').length);R.selPad=null;
          window.dispatchEvent(new KeyboardEvent('keydown',{key:'h'}));out.push(R.place);window.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape'}));rpLeave();return out}""")
        chk('fresh save (no stars): the Hive and the Engine are not locked, their cards are in the bar (12 cards, .rp12), they build on Mossgate Hollow, the ring has 12 buttons, H picks the Hive',
            r[:4]==[False,False,0,False] and r[4]==12 and r[5] and r[6] and r[7] and r[8]=='hive' and r[9]=='grav' and r[10]==12 and r[11]=='hive',r)
        r=await E("""async()=>{const out=[];for(const m of ['wonder','coral','meadow']){rpStart(m);RPX.tut=null;RPX.supply=5000;await new Promise(r=>setTimeout(r,150));out.push([m,document.querySelectorAll('.rpbar .rpcard').length,rpBuild(RPX.pads[2],'grav')!==false&&RPX.pads[2].tw&&RPX.pads[2].tw.type]);rpLeave()}return out}""")
        chk('the Wonderland and the World 2/3 maps also show 12 cards and build the Engine',all(x[1]==12 and x[2]=='grav' for x in r),r)
        # texts
        await E(SETUP%(1,"{moss:3,frost:3}"))
        r=await E("""()=>{RPW_FORCE=2;rampartsMenu(title);const lk=ov.querySelector('.rpwlk');const t1=lk?lk.textContent:'';RPW_FORCE=3;rampartsMenu(title);const t2=(ov.querySelector('.rpwlk')||{}).textContent||'';
          const h=HELP.Modes.find(x=>x[0]==='Runestone Tower Defense')[1];return [!!lk,/Clockwork Hive|Singularity Engine/.test(t1+t2),/Q W E R T|Q, W, E, R, T/.test(h+RP_TUT.build.p),/World 2\\)|World 3\\)/.test(h),/twelve/.test(h)]}""")
        chk('texts: the locked-world cards no longer promise the new towers; help and the first tip no longer list only five keys; help says all twelve are open',r==[True,False,False,False,True],r)
        # ---------- 2. the build ring on every pad of every map ----------
        await E(SETUP%(1,"{moss:3,frost:3,ember:3,coral:3,abyss:3}"))
        r=await E("""async()=>{const out=[];for(const m of %s){rpStart(m);const R=RPX;R.tut=null;R.supply=1e5;
          for(const p of R.pads){R.sel=null;R.selPad=p;await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));const el=document.getElementById('rpring'),ex=parseFloat(el.style.left),ey=parseFloat(el.style.top);
           const bs=[...el.querySelectorAll('.rprb')].map(b=>[ex+parseFloat(b.style.getPropertyValue('--x')),ey+parseFloat(b.style.getPropertyValue('--y'))]);let mn=1e9;
           for(let i=0;i<bs.length;i++)for(let j=i+1;j<bs.length;j++)mn=Math.min(mn,Math.hypot(bs[i][0]-bs[j][0],bs[i][1]-bs[j][1]));
           out.push([m,p.i,bs.length,Math.round(mn),Math.round(Math.min(...bs.map(q=>Math.hypot(q[0]-p.x,q[1]-p.y)))),bs.filter(q=>q[0]<44||q[0]>1556||q[1]<44||q[1]>856).length])}R.selPad=null;rpLeave()}return out}"""%json.dumps(MAPS))
        bad=[x for x in r if x[2]!=12 or x[3]<80 or x[4]<70 or x[5]]
        chk(f'build ring on all {len(r)} pads of the ten maps: 12 buttons, at least 80 px apart, clear of the pad, all on the stage',not bad and len(r)>100,bad[:6])
        # ---------- 3. the bar on every map: names fit, nothing overlaps ----------
        r=await E("""async()=>{const out=[];for(const m of %s){rpStart(m);RPX.tut=null;await new Promise(r=>setTimeout(r,250));const h=document.getElementById('rphud');
          const cut=[...h.querySelectorAll('.rpcard .rpct>b')].filter(b=>b.scrollWidth>b.clientWidth+1).map(b=>b.textContent);const bar=h.querySelector('.rpbar').getBoundingClientRect(),ab=[...h.querySelectorAll('.rpab')].map(x=>x.getBoundingClientRect()),nx=h.querySelector('#rpgo').getBoundingClientRect();
          out.push([m,cut,Math.round(bar.left-Math.max(...ab.map(q=>q.right))),Math.round(nx.left-bar.right),__rpuOvl(h).filter(x=>!/rpfoe|NEW MONSTER/.test(x))]);rpLeave()}return out}"""%json.dumps(MAPS))
        chk('tower bar on all ten maps: every name fits its card (Starfall Observatory included), the bar sits between the abilities and Next wave, no overlaps in the HUD',all(not x[1] and x[2]>=0 and x[3]>=0 and not x[4] for x in r),[x for x in r if x[1] or x[2]<0 or x[3]<0 or x[4]][:3])
        r=await E("""async()=>{rpStart('storm');RPX.tut=null;await new Promise(r=>setTimeout(r,300));document.querySelector('.rpsort').click();await new Promise(r=>setTimeout(r,250));const m=document.querySelector('.rpsortm');const o=__rpuOvl(m);const n=m?m.querySelectorAll('[data-k]').length:0;
          m.querySelector('[data-k=hi]').click();await new Promise(r=>setTimeout(r,150));const ord=[...document.querySelectorAll('.rpbar .rpcard')].sort((a,b)=>a.style.order-b.style.order).map(c=>c.dataset.tw);const first=ord[0];
          document.querySelector('.rpsort').click();document.querySelector('.rpsortm [data-k=def]').click();rpLeave();return [n,o,ord.length,first]}""")
        chk('the Sort menu with twelve towers: on the stage, no overlaps; Highest price puts the Singularity Engine or another 600 tower first',r[0]>=3 and not r[1] and r[2]==12 and r[3] in ('grav','tide'),r)
        r=await E("""async()=>{rptySet(1);rpStart('meadow');const R=RPX;R.tut=null;await new Promise(r=>setTimeout(r,400));const h=document.getElementById('rphud');const w=[...h.querySelectorAll('.rpty,.rptyw,[class*=rpty]')].filter(e=>e.offsetWidth&&e.textContent.trim()).length;
          window.dispatchEvent(new KeyboardEvent('keydown',{key:'h'}));const pl=R.place;const o=__rpuOvl(h).filter(x=>!/rpfoe|NEW MONSTER/.test(x));rpLeave();rptySet(0);return [w>0,pl,o]}""")
        chk('Rune Typing on with twelve towers: the words show over the abilities, H types instead of picking the Hive, nothing overlaps',r[0] and not r[1] and not r[2],r)
        # ---------- 4. info panel for every tower at every tier (tier V on a World 3 map) ----------
        r=await E("""async()=>{const out=[];rpStart('meadow');const R=RPX;R.tut=null;R.supply=1e8;const P=R.pads;const pick=f=>P.reduce((a,b)=>f(b)<f(a)?b:a);const pads=[pick(p=>p.x),pick(p=>-p.x),pick(p=>p.y),pick(p=>-p.y)];
          for(const [j,t] of RP_TWORDER.entries()){const p=pads[j%4];if(p.tw)rpSell(p.tw);R.supply=1e8;rpBuild(p,t);p.tw.build=1;R.sel=p.tw;for(let k=1;k<=5;k++){if(k>1){R.supply=1e8;R.sel.upK=1;rpUpgrade(R.sel);R.sel.up=0}
           await new Promise(r=>setTimeout(r,60));const el=document.getElementById('rpinfo');const q=__rpuOvl(el);if(q.length)out.push([t,k,q])}}rpLeave();return out}""")
        chk('the info panel for all twelve towers at tiers I-V: no overlap, clipped title or off-stage text',not r,r[:4])
        # ---------- 5. tip under the info panel / ring ----------
        r=await E("""async()=>{const r0=RPP();delete r0.tut.build;rpStart('moss');const R=RPX;R.tut=null;rpTut('build');await new Promise(r=>setTimeout(r,300));const t=document.getElementById('rptut');const a=[!t.hidden,getComputedStyle(t).opacity];
          rpBuild(R.pads[0],'ballista');R.pads[0].tw.build=1;R.sel=R.pads[0].tw;await new Promise(r=>setTimeout(r,350));a.push(+getComputedStyle(t).opacity<.3||t.hidden);R.sel=null;rpLeave();r0.tut.build=1;return a}""")
        chk('the info panel no longer covers a tutorial tip: the tip fades back while the panel is open',r[0] and r[2],r)
        # ---------- 6. How to Play ----------
        r=await E("""async()=>{RPSEL='moss';RPW_FORCE=1;rampartsMenu(title);rpHowTo();await new Promise(r=>setTimeout(r,450));const m=ov.querySelector('#rpmod'),c=m.querySelector('.rpmc2'),w=c.querySelector('.rphw');const B=c.getBoundingClientRect(),W=document.getElementById('wrap').getBoundingClientRect();
          const s0=w.scrollTop;w.scrollTop=1e5;await new Promise(r=>setTimeout(r,700));const s1=w.scrollTop;const txt=w.textContent;const cards=w.querySelectorAll('.rputw>span').length;const o=__rpuOvl(c);m.hidden=true;
          return [B.top>=W.top-1&&B.bottom<=W.bottom+1,w.scrollHeight>w.clientHeight&&s1>s0?true:[w.scrollHeight,w.clientHeight,s0,s1,document.querySelectorAll('#rpmod').length,c.className],cards,/650 supply/.test(txt),txt.includes('('+rpCost('grav',1)+' supply, key G)'),/Q, W, E, R, T/.test(txt),o]}""")
        chk('How to Play stays on the stage and scrolls; twelve tower cards; the Engine price is current; no five-key text; no overlaps',r[0] and r[1] and r[2]==12 and not r[3] and r[4] and not r[5] and not r[6],r)
        # ---------- 7. the hub: three worlds, locked world, goals ----------
        await E(SETUP%(1,"{moss:3,frost:2}"))
        r=await E("""async()=>{RPSEL='moss';RPW_FORCE=1;rampartsMenu(title);await new Promise(r=>setTimeout(r,500));const g=ov.querySelector('.rpugoal');const lines=g?[...g.querySelectorAll('.rpug')].map(p=>p.className.split(' ')[1].replace('rpug-','')+':'+p.textContent.trim()):[];
          const d=!!(g&&g.querySelector('.rpugd'));const st=g&&g.querySelector('.rpug-star');if(st)st.click();await new Promise(r=>setTimeout(r,400));return [lines,d,RPSEL,__rpuOvl(ov.querySelector('.rphub'))]}""")
        chk('hub Next goals (World 1): next stars (Frostfang Pass), the next skin by stars, the closest mastery level, the daily first-win bonus; clicking the star goal selects that map; no overlaps on the hub',
            len(r[0])==3 and r[0][0].startswith('star:') and 'Frostfang' in r[0][0] and r[0][1].startswith('chest:') and r[0][2].startswith('mast:') and r[1] and r[2]=='frost' and not r[3],r)
        r=await E("""async()=>{RPW_FORCE=2;rampartsMenu(title);await new Promise(r=>setTimeout(r,600));const lk=ov.querySelector('.rpwlk'),side=ov.querySelector('.rpside');const sb=side.getBoundingClientRect();const top=document.elementFromPoint(sb.left+sb.width/2,sb.top+12);
          const tab=ov.querySelector('.rpwt[data-w="1"]').getBoundingClientRect();const tt=document.elementFromPoint(tab.left+tab.width/2,tab.top+tab.height/2);
          rpHowTo();await new Promise(r=>setTimeout(r,300));const m=document.getElementById('rpmod'),c=m.querySelector('.rpmc2').getBoundingClientRect();const hm=document.elementFromPoint(c.left+c.width/2,c.top+30);m.hidden=true;
          return [!!lk,!!(top&&lk.contains(top)),!!(tt&&tt.closest('.rpwt')),!!(hm&&m.contains(hm)),!ov.querySelector('.rpugoal'),__rpuOvl(lk)]}""")
        chk('locked world: the shade covers the whole side panel, the world tabs stay clickable, How to Play opens above the card, no goals card, no overlaps on the card',r[:5]==[True]*5 and not r[5],r)
        await E(SETUP%(1,"{moss:3,frost:3,ember:3,coral:3,wreck:3,abyss:1}"))
        out=[]
        for w,m in [(1,'moss'),(1,'wonder'),(2,'coral'),(2,'abyss'),(3,'meadow'),(3,'storm')]:
            await E(f"()=>{{RPSEL='{m}';RPW_FORCE={w};rampartsMenu(title)}}");await pg.wait_for_timeout(700)
            o=await E("()=>__rpuOvl(ov.querySelector('.rphub'))");out.append([w,m,o])
            if m in ('moss','coral','meadow'):await pg.screenshot(path=os.path.join(SHOTS,f'hub{w}_{m}.png'))
        chk('the hub on all three worlds (six selections): no overlaps, clipped text or off-stage boxes',all(not x[2] for x in out),[x for x in out if x[2]][:3])
        # ---------- 8. Tower Skins ----------
        r=await E("""async()=>{rpSkins();await new Promise(r=>setTimeout(r,400));const out=[];for(const t of RP_TWORDER){const c=[...document.querySelectorAll('#ov .rpcsn')].find(x=>x.textContent.includes(RPTW[t].n));if(c)c.click();await new Promise(r=>setTimeout(r,120));
          const pn=document.querySelector('#ov .rpcsm').getBoundingClientRect();const cards=[...document.querySelectorAll('#ov .rpcsm .rpcsk')].map(x=>x.getBoundingClientRect());const spill=cards.filter(q=>q.right>pn.right-6||q.left<pn.left+6).length;
          const o=__rpuOvl(document.querySelector('#ov .rpskxx')||ov);if(spill||o.length)out.push([t,spill,o.slice(0,3)])}return out}""")
        chk('Tower Skins for all twelve towers: the skin grid stays inside its panel, names wrap instead of clipping, the title clears Back',not r,r[:3])
        await pg.screenshot(path=os.path.join(SHOTS,'skins_grav.png'))
        # ---------- 9. pause, settings ----------
        r=await E("""async()=>{rpStart('coral');RPX.tut=null;rpPause(true);await new Promise(r=>setTimeout(r,400));const p=ov.querySelector('.rppause');const sub=getComputedStyle(p.querySelector('p')).fontFamily;const keys=p.querySelector('.rpph span').textContent;const o=__rpuOvl(p);rpPause(false);rpLeave();return [/Poppins/.test(sub),/its key is on its card/.test(keys),o]}""")
        chk('pause menu: subtitle in Poppins, the tower keys line speaks of all towers, no overlaps',r[0] and r[1] and not r[2],r)
        # ---------- 10. combo and wave fanfare ----------
        r=await E("""async()=>{const run=async(on)=>{const m0=RPU.min;if(!on)RPU.min=1e9;rpStart('moss');const R=RPX;R.tut=null;R.supply=0;R.coins=0;rpWaveStart();R.q=[];const names=[];
          for(let i=0;i<22;i++){const e=rpSpawn('scamp');e.hp=1;rpKillFoe(e,null);rpStep(R,.2);if(i===11)names.push(document.querySelector('#rpucombo em')&&document.querySelector('#rpucombo em').textContent)}
          const el=document.getElementById('rpucombo');const a=[!!el&&!el.hidden,el&&el.querySelector('b').textContent,names[0],el&&el.querySelector('em').textContent,R.rpuC.best,Math.round(R.supply),Math.round(R.coins)];
          for(let i=0;i<70;i++)rpStep(R,1/30);rpHudTick();await new Promise(r=>setTimeout(r,350));a.push(!el||el.hidden||el.classList.contains('out'));RPU.min=m0;rpLeave();return a};
          const on=await run(true),off=await run(false);return [...on.slice(0,5),on[5]===off[5]&&on[6]===off[6],on[7],off[0]]}""")
        chk('combo: kills within 1.6 s count up (×22), the name escalates (Rampage! at 10, Unstoppable! at 20), it fades after the streak ends; it pays nothing extra',r[0] and r[1]=='×22' and r[2]=='Rampage!' and r[3]=='Unstoppable!' and r[4]==22 and r[5] and r[6] and not r[7],r)
        r=await E("""async()=>{ST.perf='high';rpStart('moss');const R=RPX;R.tut=null;R.wave=1;R.foes=[];R.q=[];R.leaked=0;R.rpuL0=0;R.wst='run';rpWaveDone();await new Promise(r=>setTimeout(r,200));const w=document.getElementById('rpuwave');
          const a=[!!w,w&&w.querySelector('b').textContent,w&&w.querySelector('small')&&w.querySelector('small').textContent,R.tx.some(t=>/ cleared · /.test(t.s)),w&&w.querySelectorAll('.rpusp s').length,__rpuOvl(document.getElementById('rphud'))];
          await new Promise(r=>setTimeout(r,2400));a.push(!document.getElementById('rpuwave'));rpLeave();return a}""")
        chk('wave cleared: a fanfare ribbon ("Wave 1 cleared!", FLAWLESS when nothing got through, supply and coins chips, sparkles) replaces the canvas line, sits clear of the HUD and leaves by itself',
            r[0] and r[1]=='Wave 1 cleared!' and r[2]=='FLAWLESS' and not r[3] and r[4]==8 and not r[5] and r[6],r)
        await E("()=>{RPP().ebest=3;save()}")
        r=await E("""async()=>{rpStart('wonder');const R=RPX;R.tut=null;R.wave=4;R.wst='run';R.foes=[];R.q=[];rpWaveDone();await new Promise(r=>setTimeout(r,150));const w=document.getElementById('rpuwave');const a=[w&&w.querySelector('small').textContent,w&&w.textContent.includes('past your best of 3')];
          R.wave=5;R.wst='run';rpWaveDone();await new Promise(r=>setTimeout(r,100));a.push(document.getElementById('rpuwave').querySelector('small')&&document.getElementById('rpuwave').querySelector('small').textContent);rpLeave();return a}""")
        chk('endless: passing your best wave calls out NEW PERSONAL BEST once',r[0]=='NEW PERSONAL BEST' and r[1] and r[2]!='NEW PERSONAL BEST',r)
        r=await E("""async()=>{const t0=performance.now();rpStart('meadow');const R=RPX;R.tut=null;rpWaveStart();R.q=[];for(let i=0;i<400;i++){const e=rpSpawn('cog');rpKillFoe(e,null);rpStep(R,.01)}const t=performance.now()-t0;rpLeave();return t}""")
        chk('the combo costs little: 400 kills with steps in well under a second',r<1500,r)
        # ---------- 11. results ----------
        await E(SETUP%(1,"{moss:3,frost:3}"))
        r=await E("""async()=>{rpStart('ember');const R=RPX;R.tut=null;R.supply=1e5;for(const p of R.pads.slice(0,6)){rpBuild(p,['frost','hive','grav','ballista','bell','still'][R.pads.indexOf(p)]);p.tw.build=1}for(let i=0;i<300;i++)rpStep(R,1/30);
          R.wave=R.map.waves;R.wst='run';R.foes=[];R.q=[];R.hp=18;R.rpuC={n:0,t:-9,best:14};rpVictory();rpFinish(true);await new Promise(r=>setTimeout(r,3200));const box=ov.querySelector('.rpres');const B=box.getBoundingClientRect(),W=document.getElementById('wrap').getBoundingClientRect();
          const btn=[...box.querySelectorAll('.row button')].map(b=>b.getBoundingClientRect()).every(q=>q.bottom<=W.bottom+1&&q.top>=W.top);const sub=box.querySelector('.rpsub'),nb=sub.querySelector('.rpnb');
          const pb=[...box.querySelectorAll('.rpupb')].map(x=>x.textContent);const lab=getComputedStyle(box.querySelector('.res>div')).fontFamily;
          return [B.top>=W.top-1&&B.bottom<=W.bottom+1,btn,!!box.querySelector('.rpwnew'),!!box.querySelector('.rpyres'),nb?Math.abs(nb.getBoundingClientRect().top-sub.getBoundingClientRect().top)<6:null,/Poppins/.test(lab),pb,box.querySelectorAll('.rpusb').length,RPP().rpu.bt.ember,RPP().rpu.bc,__rpuOvl(box)]}""")
        await pg.screenshot(path=os.path.join(SHOTS,'res_win_newworld.png'))
        chk('results (a win that opens World 2, with unlock cards and mastery): the card and its buttons stay on the stage; "new best!" sits on the line; stat labels in Poppins; best time and best combo chips; a burst per star; bests saved; no overlaps',
            r[0] and r[1] and r[2] and r[3] and r[4] and r[5] and any('New best time' in x for x in r[6]) and any('×14' in x for x in r[6]) and r[7]==3 and r[8]>0 and r[9]==14 and not r[10],r)
        r=await E("""async()=>{const rows=[...ov.querySelectorAll('.rpyres .rpyr em s')].map(s=>s.style.transform);return rows}""")
        chk('mastery bars on the results fill up (scaleX set after the animation)',len(r)>=3 and all('scaleX' in x for x in r),r)
        r=await E("""async()=>{rpLeave();rpStart('ember');const R=RPX;R.tut=null;for(let i=0;i<600;i++)rpStep(R,1/30);R.wave=R.map.waves;R.wst='run';R.foes=[];R.q=[];R.hp=18;rpVictory();rpFinish(true);await new Promise(r=>setTimeout(r,1500));
          return [[...ov.querySelectorAll('.rpupb')].map(x=>x.textContent).join('|'),RPP().rpu.bt.ember]}""")
        chk('a slower second win shows the time with the best beside it and keeps the record',r[0].startswith('Time') and 'best' in r[0] and r[1]<20,r)
        r=await E("""async()=>{rpStart('coral');const R=RPX;R.tut=null;R.wave=4;R.wst='run';R.hp=0;rpDefeat();await new Promise(r=>setTimeout(r,3200));const box=ov.querySelector('.rpres');const o=__rpuOvl(box);
          rpStart('wonder');const R2=RPX;R2.tut=null;R2.wave=23;R2.wst='run';R2.hp=0;rpDefeat();await new Promise(r=>setTimeout(r,3200));const o2=__rpuOvl(ov.querySelector('.rpres'));rpLeave();return [o,o2]}""")
        chk('results for a loss and for the endless Wonderland: no overlaps or off-stage boxes',not r[0] and not r[1],r)
        # ---------- 12. reduced motion and Performance mode ----------
        r=await E("""async()=>{const q0=ST.perf;ST.perf='low';rpStart('moss');let R=RPX;R.tut=null;R.foes=[];R.q=[];R.wst='run';rpWaveDone();const a=[!!document.querySelector('#rpuwave'),document.querySelectorAll('#rpuwave .rpusp').length];rpLeave();ST.perf=q0;return a}""")
        await pg.emulate_media(reduced_motion='reduce')
        r+=await E("""async()=>{rpStart('moss');const R=RPX;R.tut=null;R.foes=[];R.q=[];R.wst='run';rpWaveDone();const a=[document.querySelectorAll('#rpuwave .rpusp').length];for(let i=0;i<8;i++){const e=rpSpawn('scamp');rpKillFoe(e,null)}a.push(!document.getElementById('rpucombo').hidden,rpRM());rpLeave();return a}""")
        await pg.emulate_media(reduced_motion='no-preference')
        chk('Performance mode and reduced motion: the ribbon shows without sparkles; the combo still counts',r==[True,0,0,True,True],r)
        chk('no page errors',not er,er)
        await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
