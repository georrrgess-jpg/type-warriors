/* ===== RUNESTONE RAMPARTS (8.8b): styles (HUD over the full-screen map, tower bar, abilities, tower panel, build ring, tutorials,
   world hub, pause, victory, result) =====
   Stage units only (the stage is 1600x900, scaled by #wrap). Motion: transform and opacity only, springy one-shots, calm under reduced motion. */
{const st=document.createElement('style');st.textContent=`
.rph{position:absolute;left:0;top:0;width:1600px;height:900px;pointer-events:none;z-index:6;font-family:var(--ui);color:#fff8e8;--rpg:#ffd45a;--rpb:#5a4ca0;--sp:cubic-bezier(.3,1.5,.5,1)}
.rph[hidden]{display:none}
.rph button{pointer-events:auto;font-family:var(--ui);cursor:pointer;margin:0;min-height:0}
.rph svg{display:block}
.rph kbd{font:800 11px var(--ui);color:#c4badf}
/* top row */
.rpplq{position:absolute;left:14px;top:12px;padding:6px 20px 8px;border-radius:14px;background:linear-gradient(180deg,#2a1e5af0,#140c36f2);border:2px solid #c99a3a;box-shadow:0 0 0 2px #12081f,0 8px 20px #0008}
.rpplq b{display:block;font:400 30px/1 'Pirata One',Georgia,serif;letter-spacing:.02em;color:#ffd45a;text-shadow:0 2px 0 #12081f}
.rpplq small{display:block;margin-top:3px;font:800 12px var(--ui);letter-spacing:.2em;color:#e8dcff;text-transform:uppercase}
.rpchips{position:absolute;left:50%;top:12px;transform:translateX(-50%);display:flex;gap:10px}
.rpchip{display:flex;align-items:center;gap:8px;height:50px;padding:0 18px 0 12px;border-radius:14px;background:linear-gradient(180deg,#221a52ee,#120c34f2);border:2px solid var(--rpb);box-shadow:0 0 0 2px #12081f,0 6px 16px #0007;font:600 15px var(--ui);color:#e8e0ff;position:relative}
.rpchip svg{width:28px;height:28px}.rpchip b{font:800 21px var(--ui);color:#fff8e8;min-width:44px;text-align:right}
.rphp{border-color:#c94a5a}.rphp b{min-width:76px}.rpcoin{border-color:#c99a3a}.rpcoin b{color:#ffd45a}
.rpchip.low{border-color:#ff5a6a}.rpchip.low svg{animation:rpBeat .8s ease-in-out infinite}@keyframes rpBeat{50%{transform:scale(1.18)}}
.rpchip.bump b{animation:rpBump .3s var(--sp)}.rpchip.hurt{animation:rpHurt .4s ease}
.rpkb{position:absolute;left:12px;right:12px;bottom:5px;height:4px;border-radius:2px;background:#0a0618;overflow:hidden}.rpkb i{display:block;height:100%;background:linear-gradient(90deg,#ff5a6a,#ffd45a 45%,#7dffb0);transform-origin:left;transition:transform .3s ease}
@keyframes rpBump{40%{transform:scale(1.22)}}@keyframes rpHurt{20%{transform:translateX(-6px)}45%{transform:translateX(5px)}70%{transform:translateX(-3px)}}
.rptr{position:absolute;right:14px;top:12px;display:flex;gap:8px}
.rpsq{width:52px;height:52px;padding:0;border-radius:14px;border:2px solid var(--rpb);background:linear-gradient(180deg,#2a2060,#160f3e);color:#fff8e8;font:800 19px var(--ui);display:grid;place-items:center;box-shadow:0 0 0 2px #12081f,0 6px 14px #0007;transition:transform .12s}
.rpsq svg{width:24px;height:24px}.rpsq:hover{transform:translateY(-2px)}.rpsq:active{transform:scale(.92)}.rpsq.on{border-color:var(--rpg);color:var(--rpg)}
.rpboss{position:absolute;left:50%;top:74px;transform:translateX(-50%);display:flex;align-items:center;gap:10px;padding:6px 16px 6px 8px;border-radius:14px;background:#160c1cee;border:2px solid #ff8a3a;box-shadow:0 0 0 2px #12081f}
.rpboss[hidden]{display:none}.rpboss img{width:44px;height:44px}.rpboss b{display:block;font:400 22px/1 'Pirata One',Georgia,serif;color:#ffb06a}.rpboss em{display:block;width:340px;height:10px;margin-top:5px;border-radius:5px;background:#2a0e14;overflow:hidden}
.rpboss em i{display:block;height:100%;background:linear-gradient(90deg,#ff5a2a,#ffb04a);transform-origin:left;transition:transform .2s}
.rptoast{position:absolute;left:50%;top:76px;transform:translateX(-50%);padding:8px 20px;border-radius:12px;background:#0c0822ec;border:1px solid var(--rpb);font:700 17px var(--ui);white-space:nowrap;box-shadow:0 0 0 2px #12081f}
.rph.bossup .rptoast{top:136px}
.rptoast[hidden]{display:none}.rptoast.in{animation:rpTin .35s var(--sp)}@keyframes rpTin{from{opacity:0;transform:translate(-50%,-10px) scale(.9)}}
/* new monster card: top right, above the castle, clear of every pad */
.rpfoe{position:absolute;right:14px;top:76px;display:flex;align-items:center;gap:10px;width:330px;padding:8px 14px 8px 6px;border-radius:18px;background:linear-gradient(180deg,#2a1e5af2,#140c36f4);border:2px solid #ff8a3a;box-shadow:0 0 0 2px #12081f,0 10px 24px #000a;pointer-events:auto;cursor:pointer}
.rpfoe[hidden]{display:none}.rpfoe.in{animation:rpFin .45s var(--sp)}@keyframes rpFin{from{opacity:0;transform:translateX(40px)}}
.rpfoe img{width:72px;height:72px;flex:none}.rpfoe small{display:block;font:800 10.5px var(--ui);letter-spacing:.24em;color:#ffb06a}.rpfoe b{display:block;font:400 24px/1.05 'Pirata One',Georgia,serif;color:#fff8e8}.rpfoe em{display:block;font:500 12.5px/1.3 var(--ui);font-style:normal;color:#c4badf}
/* tutorial bubbles */
.rptut{position:absolute;width:440px;padding:14px 18px 14px;border-radius:20px;background:linear-gradient(180deg,#2e2270f8,#160c40f8);border:2px solid #ffd45a;box-shadow:0 0 0 3px #12081f,0 18px 40px #000b;pointer-events:auto;animation:rpTut .45s var(--sp)}
.rptut[hidden]{display:none}@keyframes rpTut{from{opacity:0;transform:translateY(16px) scale(.94)}}
.rptut small{display:block;font:800 11px var(--ui);letter-spacing:.3em;color:#9fe8ff}.rptut b{display:block;margin:2px 0 4px;font:400 30px/1.05 'Pirata One',Georgia,serif;color:#ffd45a;text-shadow:0 2px 0 #12081f}
.rptut p{margin:0 0 10px;font:500 15px/1.4 var(--ui);color:#f0eaff}
.rph .rptut button{padding:7px 22px;border:none;border-radius:12px;background:linear-gradient(180deg,#fff0a8,#ffd45a 45%,#e8a426);color:#3a1a04;font:800 16px var(--ui);box-shadow:0 0 0 2px #12081f,0 3px 0 #8a4a0a}
.rptut::after{content:'';position:absolute;width:18px;height:18px;background:#160c40;border:2px solid #ffd45a;border-top:0;border-left:0;transform:rotate(45deg)}
.rptut.at-bar{left:580px;bottom:118px}.rptut.at-bar::after{left:211px;bottom:-11px}
.rptut.at-go{right:24px;bottom:118px}.rptut.at-go::after{right:120px;bottom:-11px}
.rptut.at-abil{left:16px;bottom:126px}.rptut.at-abil::after{left:120px;bottom:-11px}
.rptut.at-top{left:580px;top:84px}.rptut.at-top::after{left:211px;top:-11px;transform:rotate(225deg)}
.rptut.at-mid{left:580px;top:120px}.rptut.at-mid::after{display:none}
/* bottom row: abilities, tower bar, next wave, start */
.rpabs{position:absolute;left:14px;bottom:12px;display:flex;gap:10px}
.rpab{position:relative;width:86px;height:86px;padding:0;border-radius:50%;border:3px solid #ffd45a;background:radial-gradient(circle at 50% 35%,#3a2c86,#140c38);box-shadow:0 0 0 3px #12081f,0 8px 18px #000a;display:grid;place-items:center;overflow:visible;transition:transform .14s var(--sp)}
.rpab .rpabi{position:relative;z-index:1}.rpab .rpabi svg{width:40px;height:40px}
.rpcdf{position:absolute;inset:0;border-radius:50%;background:#0a0618d8;transform-origin:50% 100%;transform:scaleY(0);z-index:2;pointer-events:none}
.rpcdn{position:absolute;inset:0;display:grid;place-items:center;z-index:3;font:800 24px var(--ui);color:#fff8e8;text-shadow:0 2px 0 #12081f;pointer-events:none}
.rpab kbd{position:absolute;left:-2px;top:-2px;z-index:4;width:24px;height:24px;border-radius:50%;display:grid;place-items:center;background:#12081f;border:2px solid #ffd45a;color:#ffd45a}
.rpab em{position:absolute;left:50%;bottom:-6px;transform:translateX(-50%);z-index:4;padding:1px 8px;border-radius:8px;background:#12081f;font:700 11.5px var(--ui);font-style:normal;color:#fff8e8;white-space:nowrap}
.rpab.cd{border-color:#5a4ca0}.rpab.cd em{color:#a89cc8}.rpab.dim{opacity:.6}
.rpab.aim{transform:translateY(-6px)}.rpab.aim::before{content:'';position:absolute;inset:-7px;border-radius:50%;border:3px solid #fff6c0;animation:rpAbP 1s ease-in-out infinite}@keyframes rpAbP{50%{opacity:.2}}
.rpab.rdy{animation:rpRdy .5s var(--sp)}@keyframes rpRdy{40%{transform:scale(1.16)}}
.rpab:hover{transform:translateY(-3px)}.rpab:active{transform:scale(.94)}
.rpbar{position:absolute;left:50%;bottom:12px;transform:translateX(-50%);display:flex;gap:10px;padding:8px;border-radius:22px;background:linear-gradient(180deg,#1e1650ec,#0e0a2cf2);border:2px solid #6a4ab0;box-shadow:0 0 0 2px #12081f,0 10px 24px #0009;pointer-events:auto}
.rpcard{position:relative;width:140px;height:84px;padding:0 6px 0 0;display:flex;align-items:center;gap:2px;border-radius:16px;border:2px solid #3a3070;background:linear-gradient(180deg,#241a5c,#120c34);color:#fff8e8;text-align:left;transition:transform .15s var(--sp)}
.rpcard img{width:70px;height:70px;flex:none;margin:-14px -8px 0 -4px}
.rpct{display:flex;flex-direction:column;gap:3px;min-width:0}.rpct>b{font:400 17px/1 'Pirata One',Georgia,serif;color:#fff8e8;text-shadow:0 2px 0 #12081f}
.rpcost{display:flex;align-items:center;gap:4px;font:800 16px var(--ui);color:var(--rpg)}.rpcost svg{width:18px;height:18px}.rpcost b{font:800 16px var(--ui);color:inherit}
.rpcard kbd{position:absolute;right:7px;top:5px}
.rpcard:hover{transform:translateY(-4px)}.rpcard.on{border-color:#ffd45a;transform:translateY(-8px);box-shadow:0 0 0 2px #12081f,0 0 0 5px #ffd45a55}.rpcard.no{opacity:.6}.rpcard.no .rpcost{color:#ff8a9a}
.rptip{position:absolute;left:50%;bottom:calc(100% + 14px);transform:translateX(-50%);width:240px;padding:8px 12px;border-radius:12px;background:#0c0824f4;border:1px solid #5a4ca0;font:500 12.5px/1.35 var(--ui);color:#e8e0ff;text-align:left;opacity:0;pointer-events:none;transition:opacity .15s;white-space:normal;z-index:9}
.rptip b{display:block;margin-bottom:2px;font:800 13px var(--ui);color:#ffd45a}
.rpcard:hover .rptip,.rpab:hover .rptip{opacity:1}.rpab .rptip{left:0;transform:none}
.rpnext{position:absolute;right:298px;bottom:12px;width:120px;padding:7px 10px;border-radius:16px;border:2px solid #3a3070;background:#0c0824e8;box-shadow:0 0 0 2px #12081f}
.rpnext[hidden]{display:none}.rpnext small{display:block;font:800 10.5px var(--ui);letter-spacing:.16em;color:#c4badf;text-transform:uppercase}.rpnext div{display:flex;flex-wrap:wrap;gap:0 6px;margin-top:2px}
.rpnext span{display:flex;align-items:center}.rpnext img{width:34px;height:34px}.rpnext b{font:800 13px var(--ui);color:#fff8e8;margin-left:-3px}
.rpgo{position:absolute;right:14px;bottom:14px;width:276px;display:flex;align-items:center;gap:12px;height:80px;padding:0 16px 0 10px;border:none;border-radius:22px;background:linear-gradient(180deg,#fff0a8,#ffd45a 45%,#e8a426);color:#3a1a04;box-shadow:0 0 0 3px #12081f,0 5px 0 #8a4a0a,0 12px 24px #0009;transition:transform .15s var(--sp);text-align:left}
.rpgo:hover{transform:translateY(-3px)}.rpgo:active{transform:translateY(2px) scale(.97)}.rpgo[hidden]{display:none}
.rpgoi{width:56px;height:56px;flex:none;border-radius:50%;background:#fff6c8;display:grid;place-items:center;box-shadow:inset 0 -3px 0 #e0a83a}.rpgoi svg{width:28px;height:28px;margin-left:3px}
.rpgot{display:flex;flex-direction:column;align-items:flex-start;line-height:1.1;min-width:0}.rpgo.run .rpgot b{font-size:19px}.rpgot b{font:800 22px var(--ui)}.rpgot small{font:700 12px var(--ui);opacity:.8}
.rph .rpgo:disabled{opacity:1}.rpgo.run{background:linear-gradient(180deg,#2a2060,#160f3e);color:#fff8e8;box-shadow:0 0 0 3px #12081f,0 5px 0 #0a0620,0 12px 24px #0009;cursor:default}.rpgo.run:hover{transform:none}.rpgo.run .rpgoi{background:#3a3070;box-shadow:none}.rpgo.run .rpgoi svg path{fill:#ffd45a;stroke:#ffd45a}
/* the tower panel, beside the selected tower */
.rpinfo{position:absolute;z-index:4;width:316px;padding:14px 16px 14px;border-radius:20px;background:linear-gradient(180deg,#241a5cf6,#120a34f8);border:2px solid #c99a3a;box-shadow:0 0 0 2px #12081f,0 14px 30px #000a;pointer-events:auto}
.rpinfo[hidden]{display:none}.rpinfo.in{animation:rpPin .3s var(--sp)}.rpinfo.lf.in{animation-name:rpPinL}@keyframes rpPin{from{opacity:0;transform:translateX(-24px)}}@keyframes rpPinL{from{opacity:0;transform:translateX(24px)}}
.rph .rpix{position:absolute;right:6px;top:4px;width:30px;height:30px;padding:0;border:none;border-radius:50%;background:transparent;color:#c4badf;font:700 24px/1 var(--ui)}.rpix:hover{color:#fff8e8}
.rpih{display:flex;gap:10px;align-items:center}.rpih img{width:92px;height:92px;flex:none;margin:-8px -4px -4px -8px}
.rpih span{min-width:0;padding-right:18px}.rpih b{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font:400 26px/1 'Pirata One',Georgia,serif;color:var(--rpg);text-shadow:0 2px 0 #12081f}.rpih em{display:flex;align-items:center;gap:2px;margin:4px 0;font:700 12px var(--ui);font-style:normal;color:#e8e0ff}.rpih em svg{display:inline-block}
.rpih small{display:block;font:500 12.5px/1.3 var(--ui);color:#c4badf}
.rpup{position:relative;display:flex;flex-direction:column;align-items:center;width:100%;margin:12px 0 10px;padding:8px 10px;border:none;border-radius:14px;background:linear-gradient(180deg,#fff0a8,#ffd45a 45%,#e8a426);color:#3a1a04;box-shadow:0 0 0 2px #12081f,0 4px 0 #8a4a0a;transition:transform .12s}
.rpup b{display:flex;align-items:center;gap:4px;font:800 18px var(--ui)}.rpup b svg{width:18px;height:18px}.rpup small{font:600 11.5px/1.25 var(--ui);opacity:.85}.rpup kbd{position:absolute;right:9px;top:7px;color:#7a4a0a}.rpup:hover{transform:translateY(-2px)}.rpup:active{transform:translateY(2px)}
.rpup.no{background:linear-gradient(180deg,#4a4270,#2c2650);color:#c4badf;box-shadow:0 0 0 2px #12081f,0 4px 0 #120c30}.rpup.no kbd{color:#8a80b0}
.rpmax.asc{border-color:#c89aff;color:#f0e0ff;background:linear-gradient(180deg,#2a1450,#120a30)}.rpmax{margin:12px 0 10px;padding:10px;border-radius:14px;background:#0c0824;border:1px solid #c99a3a;text-align:center;font:800 15px var(--ui);color:var(--rpg)}
.rpsts{display:flex;flex-direction:column;gap:6px;padding:10px 12px;border-radius:14px;background:#0a0620cc;border:1px solid #3a3070}
.rpst{display:flex;align-items:center;justify-content:space-between;font:600 13px var(--ui);color:#e8e0ff}.rpst i{display:flex;gap:3px}
.rpst s{width:20px;height:9px;border-radius:3px;background:#2a2450}.rpst s.on{background:linear-gradient(180deg,#7ad8ff,#2a8ae0)}.rpst s.up{background:#7ad8ff55;outline:1px dashed #7ad8ff}
.rppri{display:flex;align-items:center;gap:6px;margin-top:10px;font:700 12px var(--ui);color:#c4badf}.rppri span{margin-right:auto}
.rph .rppri button{padding:5px 11px;border-radius:9px;border:1px solid #3a3070;background:#160f3e;color:#e8e0ff;font:700 12.5px var(--ui)}.rph .rppri button.on{background:#ffd45a;color:#3a1a04;border-color:#ffd45a}
.rpif{display:flex;align-items:center;justify-content:space-between;margin-top:10px;font:600 12.5px var(--ui);color:#c4badf}.rpif i{font-style:normal}.rpoc{color:var(--rpg)}.rpoc[hidden]{display:none}
.rph .rpsell{padding:6px 12px;border-radius:10px;border:1px solid #8a3a4a;background:#3a1424;color:#ffb0ba;font:800 13px var(--ui)}.rpsell:hover{background:#5a1a30}.rpsell kbd{color:#ff8a9a;margin-left:4px}
/* build ring around a pad */
.rpring{position:absolute;width:0;height:0}.rpring[hidden]{display:none}
.rph .rprb{position:absolute;left:-40px;top:-40px;width:80px;height:80px;border-radius:50%;border:3px solid var(--c);background:radial-gradient(circle at 50% 35%,#2e2470,#120a34);box-shadow:0 0 0 3px #12081f,0 10px 20px #000a;
 transform:translate(var(--x),var(--y));animation:rpRb .32s var(--d) var(--sp) backwards;transition:transform .14s var(--sp);display:grid;place-items:center;padding:0}
.rprb img{width:64px;height:64px;margin-top:-12px}.rprb b{position:absolute;bottom:-10px;left:50%;transform:translateX(-50%);display:flex;align-items:center;gap:3px;padding:2px 8px;border-radius:9px;background:#12081f;color:var(--rpg);font:800 13px var(--ui);white-space:nowrap}.rprb b svg{width:14px;height:14px}
.rprb em{position:absolute;top:-22px;left:50%;transform:translateX(-50%);font:700 11.5px var(--ui);font-style:normal;color:#fff8e8;white-space:nowrap;opacity:0;transition:opacity .15s;text-shadow:0 1px 3px #000}
.rprb:hover{transform:translate(var(--x),var(--y)) scale(1.1)}.rprb:hover em{opacity:1}.rprb.no{opacity:.55}.rprb.no b{color:#ff8a9a}
@keyframes rpRb{from{transform:translate(0,0) scale(.2);opacity:0}}
/* menus */
#ov.rphubx,#ov.rpvx,#ov.rprx,#ov.rppx{background:rgba(9,5,22,.8)}
#ov.rphubx{padding:0;overflow:hidden}
.rphub{position:absolute;inset:0;text-align:left}.rphbg{position:absolute;inset:0;width:1600px;height:900px}
.rphtop{position:absolute;left:26px;top:20px;display:flex;gap:12px}
#ov .rphub .rpbk{display:flex;align-items:center;gap:8px;height:48px;margin:0;padding:0 20px;border-radius:14px;border:2px solid #6a5ac8;background:linear-gradient(180deg,#2a2070f0,#160f46f2);color:#fff8e8;font:700 18px var(--ui);box-shadow:0 0 0 2px #12081f,0 6px 14px #0008}
.rpbk i{width:24px;height:24px;border-radius:50%;display:grid;place-items:center;background:#e8e0ff;color:#2a2070;font:800 15px var(--ui);font-style:normal}
.rphl{position:absolute;left:44px;top:84px;width:520px;pointer-events:none}
.rpkick{margin:0;font:800 15px var(--ui);letter-spacing:.42em;color:#9fe8ff;text-shadow:0 2px 0 #12081f}
.rptitle,#ov .rphub .rptitle{margin:8px 0 0;font:400 104px/.92 'Pirata One',Georgia,serif;background:linear-gradient(180deg,#fff6c0 8%,#ffd45a 46%,#e8801a);-webkit-background-clip:text;background-clip:text;color:transparent;-webkit-text-fill-color:transparent;text-shadow:none;filter:drop-shadow(0 5px 0 #12081f);animation:none}
/* map nodes on the world */
#ov .rphub .rpnode{position:absolute;width:0;height:0;margin:0;padding:0;border:none;background:none;box-shadow:none;cursor:pointer}
.rpnglow{position:absolute;left:-95px;top:-150px;width:190px;height:150px;border-radius:50%;opacity:0;background:radial-gradient(closest-side,#ffd45a66,#ffd45a00);pointer-events:none}
.rpnode.on .rpnglow{opacity:1;animation:rpGlow 2.2s ease-in-out infinite}@keyframes rpGlow{50%{opacity:.55;transform:scale(1.06)}}
.rpnbn{position:absolute;left:-110px;top:6px;width:220px;display:flex;flex-direction:column;align-items:center;transition:transform .16s var(--sp)}
.rpnbn>b{width:220px;padding:6px 0 7px;text-align:center;font:400 25px/1 'Pirata One',Georgia,serif;color:#3a1a04;background:linear-gradient(180deg,#fff2c8,#e8c47a);border:3px solid #12081f;border-radius:10px;box-shadow:0 4px 0 #8a5a1a,0 8px 16px #0008}
.rpnbn>span{display:flex;align-items:center;gap:2px;margin-top:-2px;padding:4px 12px 5px;border-radius:0 0 12px 12px;background:#1c1446;border:2px solid #12081f;border-top:0}
.rpnbn em{margin-left:6px;font:800 13px var(--ui);font-style:normal;color:#e8e0ff}
.rpnode:hover .rpnbn{transform:translateY(-4px)}.rpnode.on .rpnbn>b{background:linear-gradient(180deg,#fff6c0,#ffd45a);box-shadow:0 4px 0 #8a5a1a,0 0 0 4px #ffd45a66,0 8px 16px #0008}
.rpnlk{position:absolute;left:-26px;top:-96px;width:52px;height:52px;border-radius:50%;display:grid;place-items:center;background:#1c1446ee;border:3px solid #12081f;box-shadow:0 6px 14px #000a}.rpnlk svg{width:30px;height:30px}
.rpnode.lock .rpnbn>b{background:linear-gradient(180deg,#c8bfd8,#9a90b0);color:#2a2040}
/* the side panel */
.rpside{position:absolute;right:22px;top:20px;width:370px;padding:14px 16px 16px;border-radius:24px;background:linear-gradient(180deg,#1e1650f2,#0e0a2cf6);border:2px solid #5a4ca0;box-shadow:0 0 0 2px #12081f,0 18px 40px #000a}
.rpprev{display:block;width:338px;height:190px;border-radius:14px;border:2px solid #12081f;box-shadow:0 0 0 2px #5a4ca0}
.rpsn{margin:12px 0 0;font:400 40px/1 'Pirata One',Georgia,serif;color:#ffd45a;text-shadow:0 3px 0 #12081f;text-align:left}
.rpss{margin:4px 0 0;font:700 16px var(--ui);color:#9fe8ff}
.rpsst{display:flex;align-items:center;gap:4px;margin-top:8px}.rpsst em{margin-left:8px;font:600 13px var(--ui);font-style:normal;color:#c4badf}
.rpstw{margin:8px 0 0;font:500 13.5px/1.4 var(--ui);color:#e8e0ff}
.rpscn{display:flex;align-items:flex-start;gap:8px;margin:10px 0 0;font:600 14px/1.35 var(--ui);color:#fff8e8}.rpscn svg{width:24px;height:24px;flex:none}.rpscn b{color:#ffd45a}
.rphub .rpgo2,.rphub .rpgo2 span{color:#3a1a04}#ov .rphub .rpgo2{width:100%;font:800 24px var(--ui)!important;padding:0 22px!important;margin:12px 0 0}.rpgo2{display:flex;align-items:center;justify-content:space-between;height:62px;border:none;border-radius:18px;background:linear-gradient(180deg,#fff0a8,#ffd45a 45%,#e8a426);box-shadow:0 0 0 3px #12081f,0 6px 0 #8a4a0a;cursor:pointer;transition:transform .15s var(--sp)}
.rpgo2 i{font-style:normal;font-size:32px}.rpgo2:hover{transform:translateY(-3px)}.rpgo2:active{transform:translateY(2px)}
.rpnr{margin-top:14px;padding-top:10px;border-top:1px solid #3a3070}.rpnr small{font:800 11px var(--ui);letter-spacing:.24em;color:#9fe8ff}.rpnr>div{display:flex;align-items:center;gap:12px;margin-top:6px}
.rpnri{position:relative;width:72px;height:72px;flex:none;border-radius:12px;overflow:hidden;border:2px solid #12081f;box-shadow:0 0 0 2px #5a4ca0}.rpnri:empty{display:none}.rpnric{display:block;width:72px;height:72px}
.rpnrl{position:absolute;right:2px;bottom:2px;width:28px;height:28px}.rpnrl svg{width:28px;height:28px}
.rpnr b{display:block;font:400 24px/1 'Pirata One',Georgia,serif;color:#fff8e8}.rpnr em{display:block;margin-top:3px;font:600 13px var(--ui);font-style:normal;color:#c4badf}
/* the Rampart Armory band */
.rparm{position:absolute;left:22px;right:22px;bottom:16px;height:126px;display:flex;align-items:center;gap:24px;padding:0 22px;border-radius:24px;background:linear-gradient(180deg,#1c1446f4,#0c0826f8);border:2px solid #5a4ca0;box-shadow:0 0 0 2px #12081f,0 -6px 30px #0007}
.rparmh{width:250px;flex:none;display:flex;flex-direction:column;gap:6px}.rparmh b{font:400 36px/1 'Pirata One',Georgia,serif;color:#ffd45a;text-shadow:0 2px 0 #12081f}.rparmh span{display:flex;align-items:center;gap:6px;font:800 17px var(--ui)}
.rparmh em{height:12px;border-radius:6px;background:#0a0620;border:1px solid #3a3070;overflow:hidden}.rparmh em i{display:block;height:100%;background:linear-gradient(90deg,#ffd45a,#ff9a3a);transform-origin:left}
.rptrk{position:relative;flex:1;height:100px;margin:0 30px}
.rptrl{position:absolute;left:0;right:0;top:78px;height:4px;border-radius:2px;background:#3a3070}.rptrl s{display:block;height:100%;background:#ffd45a;transform-origin:left}
.rptk{position:absolute;top:0;width:74px;margin-left:-37px;display:flex;flex-direction:column;align-items:center}.rptk img{width:66px;height:66px;margin-top:4px;opacity:.5}.rptki{width:66px;height:66px;margin-top:4px;display:grid;place-items:center;opacity:.5}.rptki svg{width:46px;height:46px}
.rptk em{display:flex;align-items:center;gap:3px;margin-top:4px;padding:1px 7px;border-radius:8px;background:#12081f;font:800 12px var(--ui);font-style:normal;color:#c4badf}
.rptk.own img,.rptk.own .rptki{opacity:1}.rptk.own em{color:#ffd45a}.rptk.nx img,.rptk.nx .rptki{opacity:.85}.rptk.nx em{color:#fff8e8;box-shadow:0 0 0 2px #ffd45a}
.rpnu{width:150px;flex:none;display:flex;flex-direction:column}.rpnu small{font:700 12px var(--ui);color:#c4badf}.rpnu b{font:800 20px var(--ui);color:#ffd45a}.rpnu span{font:600 13px var(--ui);color:#e8e0ff}
#ov .rphub .rpvr{height:54px;margin:0;padding:0 22px;border-radius:14px;border:2px solid #6a5ac8;background:linear-gradient(180deg,#2a2070,#160f46);color:#fff8e8;font:700 17px var(--ui);box-shadow:0 0 0 2px #12081f}
/* hub modals: how to play, rewards */
.rpmod{position:absolute;inset:0;display:grid;place-items:center;background:#08051ccc;z-index:5}.rpmod[hidden]{display:none}
.rpmc2{position:relative;width:760px;padding:24px 30px 26px;border-radius:24px;background:linear-gradient(180deg,#241a5cfa,#100a30fc);border:2px solid #c99a3a;box-shadow:0 0 0 3px #12081f,0 30px 80px #000c;animation:rpTut .35s var(--sp)}.rpmc2.wide{width:900px}
.rpmc2 h2{margin:0 0 10px;font:400 46px/1 'Pirata One',Georgia,serif;color:#ffd45a;text-align:left}
#ov .rpmc2 .rpix{position:absolute;right:10px;top:8px;width:36px;height:36px;margin:0;padding:0;border:none;background:none;box-shadow:none;color:#c4badf;font:700 28px/1 var(--ui)}
.rphw p{margin:0 0 9px;font:500 15px/1.45 var(--ui);color:#e8e0ff;text-align:left}.rphw b{color:#ffd45a}
.rpsks{display:flex;gap:10px;margin-top:12px}
#ov .rpsk{position:relative;flex:1;display:flex;flex-direction:column;align-items:center;gap:2px;margin:0;padding:8px 6px 10px;border-radius:16px;border:2px solid #3a3070;background:#0c0824;color:#fff8e8;cursor:pointer;box-shadow:none;transition:transform .15s var(--sp)}
.rpsk img{width:84px;height:84px}.rpsk b{font:700 12.5px var(--ui);text-align:center}.rpsk small{display:flex;align-items:center;gap:3px;font:700 11.5px var(--ui);color:#c4badf}
#ov .rpsk:hover{transform:translateY(-3px)}#ov .rpsk.on{border-color:#ffd45a}.rpsk.on small{color:#ffd45a}.rpsk.lock img{opacity:.32}#ov .rpsk.lock{cursor:default}
.rpttl{cursor:default}.rpttli{width:84px;height:84px;display:grid;place-items:center}.rpttli svg{width:60px;height:60px}.rpttl.lock .rpttli{opacity:.32}
.rparmn{margin:0;font:500 13.5px var(--ui);color:#c4badf;text-align:left}
/* pause, victory, result */
.rppause,.rpvic,.rpres{display:flex;flex-direction:column;align-items:center;gap:12px}
.rpph{display:flex;flex-wrap:wrap;justify-content:center;gap:10px 22px;max-width:980px;font:15px var(--ui);color:#c4badf}.rpph kbd{font:700 13px var(--ui);color:#ffd45a;border:1px solid #5a4ca0;border-radius:6px;padding:1px 7px;margin-right:4px;background:#1c1446}
.rphowx{display:flex;gap:16px;max-width:900px}.rphowx p{flex:1;margin:0;padding:10px 14px;border-radius:14px;background:#0c0824d8;border:1px solid #3a3070;font:500 14px/1.4 var(--ui);color:#e8e0ff;text-align:left}.rphowx b{color:#ffd45a}
.rpvic,.rpres{width:min(940px,100%);padding:30px 34px 26px;border-radius:26px;background:linear-gradient(180deg,#221a5af4,#100a30fa);border:2px solid #c99a3a;box-shadow:0 30px 80px #000c}
.rpvic h2,.rpres h2{font-size:64px;margin:0}.rpres.lose{border-color:#8a3a4a}.rpres.lose h2{color:#ff8a9a;text-shadow:0 3px 0 #3a0c18}
.rpvst{display:flex;gap:10px}.rpvst span{animation:rpStar .5s var(--d) var(--sp) backwards}@keyframes rpStar{from{transform:scale(0) rotate(-40deg);opacity:0}}
.rpvc{display:flex;align-items:center;gap:8px;margin:0;font:600 17px var(--ui);color:#e8e0ff}.rpvc svg{width:28px;height:28px}.rpvc b{color:#ffd45a}
.rpvch{display:flex;gap:12px}.rpvic>small{font:500 13px var(--ui);color:#c4badf;max-width:620px;text-align:center}
.rpsub{margin:0;font:600 17px var(--ui);color:#e8e0ff}.rpnb{color:#7dffb0}
.rpres .res{gap:8px 28px;font-size:16px}.rpres .res>div{display:flex;flex-direction:column;align-items:center}.rpres .res b{font:800 26px var(--ui);color:#fff8e8}
.rpunls{display:flex;gap:12px}.rpunl{display:flex;flex-direction:column;align-items:center;padding:8px 14px;border-radius:16px;border:2px solid #ffd45a;background:#1c1446;animation:rpStar .5s .9s var(--sp) backwards}
.rpunl img{width:84px;height:84px}.rpunl b{font:700 14px var(--ui);color:#ffd45a}.rpunl small{font:600 11.5px var(--ui);color:#c4badf}
/* 8.9: the Wonderland (endless) node, panel, Ascended collection and result */
.rpplq.rpend{border-color:#c89aff}.rpplq.rpend b{color:#ffd8ff}
.rpnq{position:absolute;left:-34px;top:-118px;width:68px;height:68px;border-radius:50%;display:grid;place-items:center;background:radial-gradient(circle at 50% 40%,#5a3aa8,#1c1046);border:3px solid #12081f;box-shadow:0 0 0 3px #c89aff88,0 8px 18px #000a;font:400 52px/1 'Pirata One',Georgia,serif;color:#ffd8ff;animation:rpQ 2.4s ease-in-out infinite}
@keyframes rpQ{50%{transform:translateY(-8px) scale(1.06)}}
.rpnode.myst .rpnbn>b{background:linear-gradient(180deg,#d8c8ff,#9a88d8);color:#2a1a50;letter-spacing:.2em}
.rpnode.rpwn:not(.lock) .rpnbn>b{background:linear-gradient(90deg,#ffd8f4,#fff2c8 35%,#c8f4ff 70%,#e8d0ff);color:#3a1a5a}
.rpnend{font:800 13px var(--ui);color:#ffd8ff}
.rpsidew{border-color:#c89aff}.rpsnw{color:#ffd8ff}
#ov .rphub .rpgo2.rpgow{font-size:21px!important}#ov .rphub .rpgow{background:linear-gradient(180deg,#ffe8ff,#e0a8ff 45%,#9a6ae8);box-shadow:0 0 0 3px #12081f,0 6px 0 #4a2a8a}
.rpasc{margin-top:12px;padding-top:10px;border-top:1px solid #3a3070}.rpasc small{font:800 11px var(--ui);letter-spacing:.2em;color:#d8b8ff}.rpasc small b{color:#ffd45a;letter-spacing:0;margin-left:6px}
.rpasc>div{display:flex;gap:6px;margin-top:6px}.rpai{position:relative;width:62px;height:62px;border-radius:12px;background:#0c0824;border:2px solid #3a3070;display:grid;place-items:center}
.rpai img{width:56px;height:56px;opacity:.28}.rpai.t4{border-color:#c89aff}.rpai.t4 img{opacity:.8}.rpai.t5{border-color:#ffe8a8;background:radial-gradient(circle at 50% 40%,#3a2a6a,#0c0824)}.rpai.t5 img{opacity:1}
.rpai em{position:absolute;right:3px;bottom:1px;font:400 14px 'Pirata One',Georgia,serif;font-style:normal;color:#ffd45a}
.rpebig{display:flex;flex-direction:column;align-items:center}.rpebig b{font:400 96px/1 'Pirata One',Georgia,serif;color:#ffd8ff;text-shadow:0 4px 0 #12081f}.rpebig span{font:700 15px var(--ui);color:#c4badf;letter-spacing:.2em;text-transform:uppercase}
.rph,.rph button,.rphub,.rphub button,#dkrp{touch-action:manipulation}
#ov .rphub .rptitle{font-size:70px;line-height:.98}
@media (prefers-reduced-motion:reduce){.rph *,.rphub *,.rpvic *,.rpres *{animation:none!important;transition:none!important}}`;document.head.appendChild(st)}
