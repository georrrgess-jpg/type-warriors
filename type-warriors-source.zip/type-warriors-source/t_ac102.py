# python3 t_ac102.py [game.html] : 10.1g save integrity, second layer (98v_integrity2.js). Runs with window.TW_AC_TEST so the guard is
# enforced under automation. Replays the owner's updated cheat tool (it copies 98t's key and formula from the source, writes the save
# and a matching signature straight into localStorage, locks the game's saving and reloads), the same forgery made before the game
# script runs (no watchdog), with the device key deleted too, a legitimate write from a second game tab, a 10.1f save getting the
# device key, and that normal play and reloads keep their coins.
import asyncio,os,sys,tempfile
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
H='file://'+os.path.abspath(sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'out.html'))
FAIL=[];N=[0]
def chk(name,ok,info=''):
    N[0]+=1;print(('PASS ' if ok else 'FAIL ')+name+('' if ok else '  '+str(info)[:400]),flush=True)
    if not ok:FAIL.append(name)
# the forging steps of the owner's tool (key and formula copied from 98t, as the tool did)
FORGE=r"""(function(){const SK=[116,119,45,107,101,101,112,45,51,57,49,55,45,114,117,110,101,115,116,111,110,101].map((c,i)=>String.fromCharCode(c^((i*7)&3))).join('');
function mac(v){const s=SK+'|'+v+'|'+SK.length;let a=0x6b2fe4c1^s.length,b=0x9e3779b9,c=0x1f83d9ab;for(let i=0;i<s.length;i++){const k=s.charCodeAt(i);a=Math.imul(a^k,2654435761);b=Math.imul(b^k,1597334677)^(a>>>15);c=Math.imul(c+k,0x27d4eb2f)^(b>>>13)}
a=Math.imul(a^(a>>>16),2246822507)^Math.imul(b^(b>>>13),3266489909);b=Math.imul(b^(b>>>16),2246822507)^Math.imul(c^(c>>>13),3266489909);c=Math.imul(c^(c>>>15),0x85ebca6b)^a;return [a,b,c].map(v=>(v>>>0).toString(16).padStart(8,'0')).join('')}
window.twForge=function(gold,xp){const K='typeWarriorsSave',before=localStorage.getItem(K);if(!before)return 'nosave';const n=JSON.parse(before);n.gold=gold;n.xp=xp;n.xpv=3;const u=JSON.stringify(n);
 const g=Math.round(+n.gold||0),x=Math.round(+n.xp||0),p=n.pres|0;localStorage.setItem(K,u);localStorage.setItem('typeWarriorsAux',JSON.stringify({m:mac('s|'+u),g,x,p,a:mac('a|'+g+'|'+x+'|'+p)}));return 'ok'}})();"""
async def ready(pg):
    for _ in range(40):
        if await pg.evaluate("()=>typeof TWAC2!=='undefined'&&TWAC2.stat().ready===1"):return True
        await pg.wait_for_timeout(100)
    return False
async def main():
    td=tempfile.mkdtemp();cf=os.path.join(td,'tool.js');open(cf,'w').write(FORGE)
    async with async_playwright() as p:
        b=await p.chromium.launch();ctx=await b.new_context(viewport={'width':1600,'height':900});await ctx.add_init_script('window.TW_AC_TEST=1')
        pg=await ctx.new_page();er=[];pg.on('pageerror',lambda e:er.append(str(e)[:300]))
        await pg.goto(H);await pg.wait_for_timeout(1200);await ready(pg);E=pg.evaluate
        await E("()=>{RS_ASK=false;WCRELAYS=[];RPP();rpStart('moss');RPX.tut=null;RPX.won=true;RPX.free=false;RPX.wave=RPX.map.waves;window.g0=P.gold;setTimeout(rpFinish,0,true)}");await pg.wait_for_timeout(2500)
        await E("()=>{try{rpLeave()}catch(e){}title()}");await pg.wait_for_timeout(400)
        base=await E("()=>[P.gold,P.xp,lvl(P.xp),TWAC2.stat().dk]")
        chk('a device key exists and the game paid a map win',base[0]>0 and base[3],base)
        await pg.reload();await pg.wait_for_timeout(1200);await ready(pg)
        r=await E("()=>[P.gold,P.xp,TWAC2.stat().edited]")
        chk('a normal reload keeps the coins and level (nothing reverted)',r==[base[0],base[1],0],[base,r])
        # 1. the owner's updated tool: forge, lock saving, reload (same tab)
        await pg.add_script_tag(path=cf)
        await E("()=>{twForge(999999999,lvx(30));SGS.lock=true;location.reload()}")
        await pg.wait_for_timeout(1500);await ready(pg)
        r=await E("()=>[P.gold,P.xp,lvl(P.xp),JSON.parse(localStorage.getItem(KEY)).gold]")
        chk('the updated cheat tool (forged signature, locked saving, reload) leaves the real coins and level',r[0]==base[0] and r[1]==base[1] and r[3]==base[0],[base,r])
        # 2. the same forgery before the game script runs (no watchdog in the way): the device key catches it
        await ctx.add_init_script(FORGE+";try{if(sessionStorage.getItem('twForgeOnce')==='1'){sessionStorage.setItem('twForgeOnce','2');twForge(999999999,99999999)}}catch(e){}")
        await E("()=>sessionStorage.setItem('twForgeOnce','1')");await pg.reload();await pg.wait_for_timeout(1500);await ready(pg);await pg.wait_for_timeout(300)
        r=await E("()=>[P.gold,P.xp,TWAC2.stat().edited+TWAC2.stat().ledger,JSON.parse(localStorage.getItem(KEY)).gold,sessionStorage.getItem('twForgeOnce'),TWAC.stat().tamper]")
        chk('a forgery written before the game loads is caught by the device key and put back',r[0]==base[0] and r[1]==base[1] and r[2]>=1 and r[3]==base[0],[base,r])
        # 3. forgery plus deleting the device key: back to the ledger balance (a daily bonus may follow) and at most level 8
        await E("()=>new Promise(res=>{const q=indexedDB.deleteDatabase('typeWarriorsK');q.onsuccess=q.onerror=q.onblocked=()=>res(1)})")
        await E("()=>sessionStorage.setItem('twForgeOnce','1')");await pg.reload();await pg.wait_for_timeout(1500);await ready(pg);await pg.wait_for_timeout(300)
        r=await E("()=>[P.gold,lvl(P.xp),TWAC2.stat().dk,TWAC2.stat().lost,(P.ldg||[]).slice(-4).map(l=>[l.d,l.bal,l.src])]")
        chk('deleting the device key as well does not help (coins back to the ledger, level 8 at most, a new key made)',r[0]<=base[0]+500 and r[1]<=max(8,base[2]) and r[2] and r[3]==1,[base,r])
        chk('no page errors',not er,er)
        await ctx.close()
        # 4. a second game tab saving legitimately is not undone by the first tab's watchdog
        ctx2=await b.new_context();await ctx2.add_init_script('window.TW_AC_TEST=1');a1=await ctx2.new_page();await a1.goto(H);await a1.wait_for_timeout(1200);await ready(a1)
        a2=await ctx2.new_page();await a2.goto(H);await a2.wait_for_timeout(1200);await ready(a2)
        await a2.evaluate("()=>{RS_ASK=false;WCRELAYS=[];RPP();rpStart('moss');RPX.tut=null;RPX.won=true;RPX.free=false;RPX.wave=RPX.map.waves;setTimeout(rpFinish,0,true)}");await a2.wait_for_timeout(2500)
        g2=await a2.evaluate("()=>P.gold");await a1.wait_for_timeout(2500)
        r=await a1.evaluate("()=>[JSON.parse(localStorage.getItem(KEY)).gold,TWAC2.stat().restored]")
        chk("a save from another game tab is accepted (the watchdog only undoes writes made behind the game's back)",r[0]==g2 and r[1]==0,[g2,r])
        await ctx2.close()
        # 5. a 10.1f save (signature without the device fields, no key yet, no device marker in the save or meta) gets the key on its first start; coins checked against the ledger
        ctx3=await b.new_context();p3=await ctx3.new_page();await p3.goto(H);await p3.wait_for_timeout(1200);await ready(p3)
        await p3.evaluate("()=>{RS_ASK=false;WCRELAYS=[];RPP();rpStart('moss');RPX.tut=null;RPX.won=true;RPX.free=false;RPX.wave=RPX.map.waves;setTimeout(rpFinish,0,true)}");await p3.wait_for_timeout(2500)
        gl=await p3.evaluate("()=>P.gold")
        await p3.evaluate("()=>new Promise(res=>{const r=JSON.parse(localStorage.getItem('typeWarriorsAux'));for(const k of ['m2','a2','g2','x2','p2'])delete r[k];localStorage.setItem('typeWarriorsAux',JSON.stringify(r));const s=JSON.parse(localStorage.getItem(KEY));delete s.ac3;localStorage.setItem(KEY,JSON.stringify(s));const m=JSON.parse(localStorage.getItem(META_K)||'{}');delete m.v3k;localStorage.setItem(META_K,JSON.stringify(m));const q=indexedDB.deleteDatabase('typeWarriorsK');q.onsuccess=q.onerror=q.onblocked=()=>res(1)})")
        await ctx3.add_init_script('window.TW_AC_TEST=1');await p3.reload();await p3.wait_for_timeout(1300);await ready(p3)
        r=await p3.evaluate("()=>[P.gold,TWAC2.stat().migrated,TWAC2.stat().dk,typeof JSON.parse(localStorage.getItem('typeWarriorsAux')).m2]")
        chk('a 10.1f save is accepted once, gets a device key and its device signature',r==[gl,1,True,'string'],[gl,r])
        await ctx3.close();await b.close()
    print(f'{N[0]-len(FAIL)}/{N[0]} passed');print('FAILED:',FAIL) if FAIL else print('ALL OK')
    sys.exit(1 if FAIL else 0)
asyncio.run(main())
