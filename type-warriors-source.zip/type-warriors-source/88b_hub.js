/* ===== HUB DIORAMA: the main menu becomes a lit, living view into your current land =====
   Replaces homeScene/drawBG from 88_dock with a colour-graded region scene: light shafts, a stone platform for the
   hero, region-specific life (fish and bubbles underwater, leaves in the woods, embers in the forges...), swaying
   foreground framing, mouse parallax, and a hero who raises their sword now and then (or when you click them). */

/* ---------- the dock's new icon set: one illustrated family, each with its own little hover animation ---------- */
const DKI={
 pl:`<g class="dkia"><g class="dkis1">${bL(24,24,74,74,'#e8eef8',7)}${bP('M70 70L80 80L76 84L66 74Z','#d8a830',2)}${bL(22,80,32,70,'#7a4a24',6)}${bC(20,82,5,'#ffd24a',1.6)}${bL(28,62,40,74,'#ffd24a',5)}</g>
  <g class="dkis2">${bL(76,24,26,74,'#e8eef8',7)}${bL(78,80,68,70,'#7a4a24',6)}${bC(80,82,5,'#ffd24a',1.6)}${bL(72,62,60,74,'#ffd24a',5)}</g>${bH('M30 28L46 44','#ffffffcc',2.6)}${bH('M70 28L54 44','#ffffffcc',2.6)}<g class="dkspark">${bS(50,50,9,'#fff6c0')}</g></g>`,
 gr:`<g class="dkia">${bP('M50 14L56 22L50 30L44 22Z','#b47aff',2)}${bP('M24 56C24 34 36 22 50 22C64 22 76 34 76 56V78H64V64H36V78H24Z','#c8d2e2')}${bF('M50 22C64 22 76 34 76 56V78H64V64H50Z','#000',.18)}
  ${bP('M33 46H67V56H33Z','#1a1030',1.8)}${bP('M46 46H54V70H46Z','#1a1030',1.6)}${bL(28,76,72,76,'#ffd24a',4)}${bH('M31 48C32 36 40 28 48 26','#fff',3)}<g class="dkspark">${bS(80,22,6,'#fff6c0')}</g></g>`,
 pt:`<g class="dkia"><g class="dkpd">${bP('M50 44C38 44 28 54 28 66C28 76 38 82 50 82C62 82 72 76 72 66C72 54 62 44 50 44Z','#ffa24a')}${bF('M50 44C62 44 72 54 72 66C72 76 62 82 50 82Z','#000',.15)}</g>
  <g class="dkpt1">${bP('M24 30C30 30 34 36 33 43C32 49 26 50 22 46C17 41 18 30 24 30Z','#ffb86a')}</g><g class="dkpt2">${bP('M40 14C47 14 50 22 49 29C48 35 41 37 37 32C33 26 34 14 40 14Z','#ffb86a')}</g>
  <g class="dkpt3">${bP('M60 14C66 14 67 26 63 32C59 37 52 35 51 29C50 22 53 14 60 14Z','#ffb86a')}</g><g class="dkpt4">${bP('M76 30C82 30 83 41 78 46C74 50 68 49 67 43C66 36 70 30 76 30Z','#ffb86a')}</g>${bH('M36 56C40 50 46 48 52 48','#fff8',2.6)}${bP('M44 60C44 56 50 56 50 60C50 56 56 56 56 60C56 66 50 70 50 70C50 70 44 66 44 60Z','#ff5a8a',1.4)}</g>`,
 pg:`<g class="dkia">${bP('M14 82H86V88H14Z','#6a5a8a',2)}<g class="dkb1">${bP('M20 56H34V82H20Z','#7ab8ff')}</g><g class="dkb2">${bP('M43 40H57V82H43Z','#b47aff')}</g><g class="dkb3">${bP('M66 22H80V82H66Z','#ff7ab4')}</g>
  ${bF('M27 56H34V82H27ZM50 40H57V82H50ZM73 22H80V82H73Z','#000',.18)}${bH('M23 60V76M46 44V76M69 26V76','#ffffff99',2.4)}<g class="dkspark">${bS(73,12,8,'#ffd45a')}</g></g>`,
 sh:`<g class="dkia"><g class="dkpo">${bP('M36 30C30 20 42 14 50 22C58 14 70 20 64 30Z','#a8743a')}${bP('M32 30H68C82 46 84 80 50 84C16 80 18 46 32 30Z','#e0a840')}${bF('M50 30H68C82 46 84 80 50 84Z','#000',.18)}
  ${bP('M34 30H66V38H34Z','#7a4a24',2)}${bC(50,60,14,'#ffd24a')}${bC(50,60,9,'#f0b020',1.6)}${bP('M47 54H53V66H47Z','#fff0a0',0)}${bH('M28 48C30 42 34 38 38 36','#fff',2.6)}</g>
  <g class="dkcn">${bC(80,22,7,'#ffd24a',1.8)}${bC(80,22,4,'#f0b020',1.2)}</g></g>`,
 mo:`<g class="dkia"><g class="dkd1">${bC(22,50,10,'#c8b8ff')}</g><g class="dkd2">${bC(50,50,10,'#ffd45a')}</g><g class="dkd3">${bC(78,50,10,'#c8b8ff')}</g>${bH('M18 46A6 6 0 0 1 24 42M46 46A6 6 0 0 1 52 42M74 46A6 6 0 0 1 80 42','#fff',2)}</g>`
};
const dkIco=(k,sz)=>`<svg class="mico dkico dkico-${k}" viewBox="0 0 100 100" width="${sz}" height="${sz}" aria-hidden="true">${DKI[k]}</svg>`;
{const m0=mico;window.__dkm0=m0}
/* the dock uses the new set; the More sheet's Notifications/Calendar icons stay as they are */
{const h0=dkHTML;dkHTML=function(fine){let h=h0.apply(this,arguments);for(const [k,,ic] of DKN){h=h.replace(new RegExp(`(id="dk_${k}"[^>]*><span class="dkic">)<svg[\\s\\S]*?</svg>`),`$1${dkIco(k,46)}`)}return h};sbHTML=function(nav){return dkHTML(nav)}}

/* ---------- pointer: smooth parallax target, and glare/tilt on anything marked .dkg ---------- */
const DKM={x:0,y:0,tx:0,ty:0};
document.addEventListener('pointermove',e=>{if(!HOME)return;const r=ov.getBoundingClientRect();if(!r.width)return;DKM.tx=Math.max(-1,Math.min(1,((e.clientX-r.left)/r.width-.5)*2));DKM.ty=Math.max(-1,Math.min(1,((e.clientY-r.top)/r.height-.5)*2))},{passive:true});
document.addEventListener('pointermove',e=>{const el=e.target&&e.target.closest&&e.target.closest('.dkg');if(!el)return;const r=el.getBoundingClientRect(),x=(e.clientX-r.left)/r.width,y=(e.clientY-r.top)/r.height;
 el.style.setProperty('--gx',(x*100).toFixed(1)+'%');el.style.setProperty('--gy',(y*100).toFixed(1)+'%');if(el.classList.contains('dktilt')&&!dkRM()){el.style.setProperty('--rx',((.5-y)*7).toFixed(2)+'deg');el.style.setProperty('--ry',((x-.5)*9).toFixed(2)+'deg')}},{passive:true});
document.addEventListener('pointerout',e=>{const el=e.target&&e.target.closest&&e.target.closest('.dktilt');if(el&&!el.contains(e.relatedTarget)){el.style.setProperty('--rx','0deg');el.style.setProperty('--ry','0deg')}},{passive:true});

/* ---------- region looks ---------- */
const DKZ=[
 {st:'#7c8676',sd:'#3e4a3e',ms:'#5ab040',gl:'#c8ff8a',life:'forest'},
 {st:'#7e8498',sd:'#3a3e54',ms:'#7a8aa8',gl:'#b8d0ff',life:'crypt'},
 {st:'#6e5e92',sd:'#2e2450',ms:'#9a6ad8',gl:'#e0a8ff',life:'cave'},
 {st:'#5e4c4a',sd:'#2a1c1c',ms:'#ff6a1a',gl:'#ffb05a',life:'fire'},
 {st:'#a8c2da',sd:'#56708e',ms:'#f2f8ff',gl:'#e8f6ff',life:'frost'},
 {st:'#5a8c8a',sd:'#22484a',ms:'#3ac890',gl:'#9ff6e8',life:'water'}];
const dkZone=()=>{const L=dkHomeL();return DKZ[L?L.z:1]||DKZ[1]};
const DKPC={};
/* the stone platform the hero stands on, cached per region */
function dkPlatform(z){const key=DKZ.indexOf(z);if(DKPC[key])return DKPC[key];const c=document.createElement('canvas');c.width=760;c.height=260;const g=c.getContext('2d');const cx=380,ty=70,rx=330,ry=46,fh=86;
 const R=(i)=>{const x=Math.sin(i*127.1+key*31.7)*43758.5453;return x-Math.floor(x)};
 /* front face */g.save();g.beginPath();g.moveTo(cx-rx,ty);g.ellipse(cx,ty,rx,ry,0,Math.PI,0,true);g.lineTo(cx+rx,ty+fh);g.ellipse(cx,ty+fh,rx,ry,0,0,Math.PI);g.closePath();
 let q=g.createLinearGradient(0,ty,0,ty+fh+ry);q.addColorStop(0,dkMix(z.st,'#000000',.2));q.addColorStop(.5,z.sd);q.addColorStop(1,'#0a0612');g.fillStyle=q;g.fill();g.clip();
 g.strokeStyle='#00000066';g.lineWidth=2.4;for(let row=0;row<3;row++){const y=ty+18+row*30;g.beginPath();g.ellipse(cx,y,rx,ry,0,0,Math.PI);g.stroke();for(let k=0;k<11;k++){const a=Math.PI*(k+(row%2)*.5)/11,x=cx+Math.cos(a)*rx,yy=y+Math.sin(a)*ry;g.beginPath();g.moveTo(x,yy-2);g.lineTo(x,yy+30);g.stroke()}}
 g.fillStyle='#ffffff10';for(let k=0;k<26;k++){const a=Math.PI*R(k),x=cx+Math.cos(a)*rx*.98,y=ty+10+R(k+40)*fh;g.fillRect(x-10,y,20,3)}g.restore();
 /* top surface of cobbles */g.save();g.beginPath();g.ellipse(cx,ty,rx,ry,0,0,Math.PI*2);q=g.createRadialGradient(cx,ty-14,20,cx,ty,rx);q.addColorStop(0,dkMix(z.st,'#ffffff',.22));q.addColorStop(.7,z.st);q.addColorStop(1,z.sd);g.fillStyle=q;g.fill();g.clip();
 for(let row=-4;row<=4;row++){const y=ty+row*11,w=46-Math.abs(row)*2;for(let k=-8;k<=8;k++){const x=cx+k*w+(row%2)*w/2+(R(row*20+k)-.5)*6;const s=(1-Math.abs(row)/5);g.fillStyle=`rgba(255,255,255,${.04+R(k*3+row)*.08})`;g.beginPath();g.roundRect(x-w/2+2,y-4,w-4,9*s+3,4);g.fill();g.strokeStyle='#00000040';g.lineWidth=1.4;g.stroke()}}
 g.restore();
 /* rim light and moss / snow / glow along the edge */
 g.strokeStyle='#ffffff40';g.lineWidth=2;g.beginPath();g.ellipse(cx,ty,rx-2,ry-2,0,Math.PI*1.05,Math.PI*1.95);g.stroke();
 for(let k=0;k<34;k++){const a=Math.PI*(.02+R(k+90)*.96),x=cx+Math.cos(a)*rx,y=ty+Math.sin(a)*ry;const s=6+R(k)*12;if(z.life==='fire'){g.fillStyle='#ff6a1a33';g.beginPath();g.ellipse(x,y+4,s,3,0,0,TAU);g.fill()}else{g.fillStyle=z.ms+(z.life==='frost'?'ee':'cc');g.beginPath();g.ellipse(x,y+1,s,s*.42,0,0,TAU);g.fill();g.fillStyle=z.ms+'66';g.beginPath();g.ellipse(x,y+6+R(k+7)*10,s*.4,s*.9,0,0,TAU);g.fill()}}
 if(z.life==='fire'){g.strokeStyle='#ff7a2a';g.lineWidth=2;g.shadowColor='#ff6a1a';g.shadowBlur=8;for(let k=0;k<6;k++){const x=cx-rx*.8+k*rx*.32,y=ty+ry*.4+R(k)*fh*.6;g.beginPath();g.moveTo(x,y);g.lineTo(x+14,y+18);g.lineTo(x+6,y+34);g.stroke()}g.shadowBlur=0}
 if(z.life==='cave'){for(let k=0;k<5;k++){const x=cx-rx+40+k*150+R(k)*40,y=ty+ry*.7+R(k+3)*10,h=24+R(k+9)*26;g.fillStyle=z.gl+'cc';g.beginPath();g.moveTo(x-8,y);g.lineTo(x,y-h);g.lineTo(x+8,y);g.closePath();g.fill();g.strokeStyle='#2a1050';g.lineWidth=2;g.stroke()}}
 return DKPC[key]=c}

/* a misty midground of the land's own shapes adds depth between the backdrop and the stage */
const DKMG={};
function dkMid(z,ac){const key=DKZ.indexOf(z)+ac;if(DKMG[key])return DKMG[key];const c=document.createElement('canvas');c.width=1000;c.height=640;const g=c.getContext('2d'),life=z.life;
 const R=(i)=>{const x=Math.sin(i*91.7+key.length*13.3)*43758.5453;return x-Math.floor(x)};
 const layer=(depth,col)=>{g.fillStyle=col;const base=640-depth*60;
  if(life==='water'||life==='crypt'){for(let k=0;k<6;k++){const x=40+k*170+R(k+depth*9)*60,w=34+R(k)*20,h=200+R(k+5)*220-depth*40,broken=R(k+11)>.45;g.fillRect(x-w/2,base-h,w,h);g.fillRect(x-w/2-8,base-h,w+16,12);if(!broken)g.fillRect(x-w/2-10,base-h-16,w+20,16);else{g.beginPath();g.moveTo(x-w/2,base-h);g.lineTo(x-w/2+w*.3,base-h-22);g.lineTo(x+w*.1,base-h-8);g.lineTo(x+w/2,base-h-26);g.lineTo(x+w/2,base-h);g.fill()}
   if(k%2===0&&k<5){const x2=x+170,r=(x2-x)/2;g.beginPath();g.moveTo(x+w/2,base-h+30);g.arc(x+r,base-h+30,r-w/2,Math.PI,0);g.lineTo(x2-w/2,base-h+30);g.arc(x+r,base-h+30,r-w/2-18,0,Math.PI,true);g.closePath();g.fill()}}
   if(life==='water'){for(let k=0;k<14;k++){const x=R(k+50)*1000,h=40+R(k+60)*90;g.beginPath();g.moveTo(x-6,base);g.quadraticCurveTo(x+10,base-h*.5,x,base-h);g.quadraticCurveTo(x-4,base-h*.5,x+6,base);g.fill()}}}
  else if(life==='forest'){for(let k=0;k<9;k++){const x=R(k+depth)*1000,w=20+R(k+3)*20;g.fillRect(x-w/2,base-500,w,500);g.beginPath();g.ellipse(x,base-420,90+R(k)*50,70,0,0,TAU);g.fill()}}
  else if(life==='cave'){for(let k=0;k<10;k++){const x=R(k+depth*3)*1000,h=120+R(k+8)*200;g.beginPath();g.moveTo(x-30,0);g.lineTo(x,h);g.lineTo(x+30,0);g.fill();g.beginPath();g.moveTo(x+40,base);g.lineTo(x+60,base-h*.7);g.lineTo(x+80,base);g.fill()}}
  else if(life==='fire'){for(let k=0;k<5;k++){const x=100+k*200+R(k+depth)*60,w=60+R(k)*40,h=260+R(k+2)*200;g.fillRect(x-w/2,base-h,w,h);for(let b=0;b<4;b++)g.fillRect(x-w/2+b*w/4,base-h-14,w/8,14)}}
  else{for(let k=0;k<7;k++){const x=R(k+depth*5)*1000,h=180+R(k+4)*260;g.beginPath();g.moveTo(x-50,base);g.lineTo(x-6,base-h);g.lineTo(x+8,base-h*.92);g.lineTo(x+50,base);g.fill()}}};
 layer(2,dkMix(ac,'#c8d8e8',.25)+'2e');layer(1,dkMix(ac,'#0a1420',.45)+'99');
 return DKMG[key]=c}
/* drifting creatures and particles, one set per region */
const DKP=Array.from({length:60},(_,i)=>{const r=k=>{const x=Math.sin((i+1)*12.9898+k*78.233)*43758.5453;return x-Math.floor(x)};return{a:r(1),b:r(2),c:r(3),d:r(4),e:r(5)}});
function dkLife(c,z,t,ox){const life=z.life;c.save();c.translate(ox*.5,0);
 if(life==='water'){/* schools of fish */for(let s=0;s<3;s++){const sp=18+s*7,base=((t*sp+s*700)%2200)-300,yy=170+s*90+Math.sin(t*.4+s)*20,dir=s%2?1:-1,x0=dir>0?base:1900-base;
   for(let k=0;k<9;k++){const p=DKP[s*9+k],x=x0+(p.a-.5)*120*dir*-1+Math.sin(t*1.5+k)*6,y=yy+(p.b-.5)*50+Math.sin(t*2+k*1.7)*4,sz=5+p.c*4;if(x<720)continue;c.fillStyle=`rgba(10,40,48,${.45+p.d*.25})`;c.beginPath();c.ellipse(x,y,sz*1.6,sz*.7,0,0,TAU);c.fill();c.beginPath();c.moveTo(x-dir*sz*1.4,y);c.lineTo(x-dir*sz*2.6,y-sz*.8+Math.sin(t*12+k)*1.5);c.lineTo(x-dir*sz*2.6,y+sz*.8+Math.sin(t*12+k)*1.5);c.closePath();c.fill()}}
  /* bubbles */for(let k=0;k<18;k++){const p=DKP[30+k%30],v=((t*(.05+p.c*.06)+p.a)%1),x=780+p.b*800+Math.sin(t*1.4+k)*8,y=820-v*780,r=1.5+p.d*4;c.globalAlpha=Math.sin(v*Math.PI)*.75;c.strokeStyle='#cffcff';c.lineWidth=1.2;c.beginPath();c.arc(x,y,r,0,TAU);c.stroke();c.fillStyle='#ffffff88';c.beginPath();c.arc(x-r*.35,y-r*.35,r*.3,0,TAU);c.fill()}c.globalAlpha=1}
 else if(life==='forest'){for(let k=0;k<16;k++){const p=DKP[k],v=((t*(.04+p.c*.05)+p.a)%1),x=780+p.b*820+Math.sin(t*.8+k)*40,y=-20+v*860,rot=t*(1+p.d)+k;c.save();c.translate(x,y);c.rotate(rot);c.globalAlpha=Math.sin(v*Math.PI)*.85;c.fillStyle=k%3?'#7ac850':'#e8a83a';c.beginPath();c.ellipse(0,0,7,3,0,0,TAU);c.fill();c.restore()}c.globalAlpha=1}
 else if(life==='crypt'){for(let k=0;k<6;k++){const p=DKP[k],x=820+((t*(8+p.c*10)+p.a*800)%820),y=300+p.b*380+Math.sin(t*.7+k)*20;const q=c.createRadialGradient(x,y,1,x,y,16);q.addColorStop(0,'#e0f0ffcc');q.addColorStop(1,'#a0c0ff00');c.fillStyle=q;c.beginPath();c.arc(x,y,16,0,TAU);c.fill()}
  for(let k=0;k<3;k++){const x=((t*(12+k*5)+k*500)%1600)+400,y=690+k*24;const q=c.createRadialGradient(x,y,4,x,y,300);q.addColorStop(0,'#c8d4ff22');q.addColorStop(1,'#c8d4ff00');c.fillStyle=q;c.beginPath();c.ellipse(x,y,320,50,0,0,TAU);c.fill()}}
 else if(life==='cave'){for(let k=0;k<20;k++){const p=DKP[k],v=((t*(.03+p.c*.04)+p.a)%1),x=780+p.b*820+Math.sin(t+k)*20,y=820-v*700;c.globalAlpha=Math.sin(v*Math.PI);const q=c.createRadialGradient(x,y,0,x,y,6);q.addColorStop(0,z.gl);q.addColorStop(1,z.gl+'00');c.fillStyle=q;c.beginPath();c.arc(x,y,6,0,TAU);c.fill()}c.globalAlpha=1}
 else if(life==='fire'){for(let k=0;k<26;k++){const p=DKP[k],v=((t*(.08+p.c*.1)+p.a)%1),x=760+p.b*840+Math.sin(t*2+k)*18*v,y=860-v*760;c.globalAlpha=(1-v)*.95;c.fillStyle=k%3?'#ffb04a':'#ff5a1a';c.beginPath();c.arc(x,y,1.4+p.d*2.2,0,TAU);c.fill()}c.globalAlpha=1;
  const q=c.createLinearGradient(0,600,0,900);q.addColorStop(0,'#ff4a1a00');q.addColorStop(1,'#ff4a1a33');c.fillStyle=q;c.fillRect(740,600,860,300)}
 else if(life==='frost'){for(let k=0;k<40;k++){const p=DKP[k%60],v=((t*(.05+p.c*.05)+p.a)%1),x=760+p.b*860+Math.sin(t*.9+k)*30,y=-10+v*880;c.globalAlpha=.4+p.d*.5;c.fillStyle='#ffffff';c.beginPath();c.arc(x,y,1+p.e*2.4,0,TAU);c.fill()}c.globalAlpha=1}
 c.restore()}
/* silhouettes framing the bottom of the stage, swaying gently */
function dkFront(c,z,t,ox){c.save();c.translate(ox,0);const life=z.life,dark='#06040c';
 const blade=(x,h,w,ph,col)=>{const sw=Math.sin(t*1.1+ph)*12;c.fillStyle=col;c.beginPath();c.moveTo(x-w,H+10);c.quadraticCurveTo(x-w*.4+sw*.5,H-h*.55,x+sw,H-h);c.quadraticCurveTo(x+w*.4+sw*.5,H-h*.55,x+w,H+10);c.closePath();c.fill()};
 if(life==='water'){for(let k=0;k<9;k++){const x=k<5?1320+k*58:760+(k-5)*40,h=k<5?120+(k%3)*60:80+(k%2)*40;blade(x,h,10,k,k%2?'#0a2a2c':'#0e3a3a');blade(x+16,h*.7,8,k+2,'#06201f')}}
 else if(life==='forest'){for(let k=0;k<7;k++){const x=1360+k*42;for(let f=0;f<5;f++){const a=-1.4+f*.35+Math.sin(t*.9+k)*.05;c.save();c.translate(x,H+6);c.rotate(a);c.fillStyle=f%2?'#0a1a10':'#0e2416';c.beginPath();c.ellipse(0,-70,10,72,0,0,TAU);c.fill();c.restore()}}}
 else if(life==='cave'){for(let k=0;k<4;k++){const x=1380+k*60,h=70+k%2*50;c.fillStyle='#1a0e30';c.beginPath();c.moveTo(x-22,H);c.lineTo(x,H-h);c.lineTo(x+22,H);c.fill();const pu=.4+.3*Math.sin(t*2+k);c.fillStyle=`rgba(200,140,255,${pu})`;c.beginPath();c.moveTo(x-8,H);c.lineTo(x,H-h*.8);c.lineTo(x+8,H);c.fill()}}
 else if(life==='fire'){c.fillStyle=dark;c.beginPath();c.moveTo(1300,H);c.quadraticCurveTo(1380,H-90,1470,H-70);c.quadraticCurveTo(1540,H-120,1610,H-60);c.lineTo(1610,H);c.fill();c.strokeStyle=`rgba(255,110,30,${.5+.3*Math.sin(t*3)})`;c.lineWidth=2.4;c.beginPath();c.moveTo(1380,H-60);c.lineTo(1420,H-30);c.lineTo(1470,H-50);c.stroke()}
 else if(life==='frost'){c.fillStyle='#1a2a44';for(let k=0;k<5;k++){const x=1360+k*50,h=60+k%3*40;c.beginPath();c.moveTo(x-16,H);c.lineTo(x+3,H-h);c.lineTo(x+18,H);c.fill()}c.fillStyle='#e8f4ff22';c.fillRect(1320,H-14,300,14)}
 else{for(let k=0;k<5;k++){const x=1380+k*50;c.strokeStyle='#0a0814';c.lineWidth=5;c.beginPath();c.moveTo(x,H);c.quadraticCurveTo(x+20+Math.sin(t*.8+k)*4,H-60,x-10,H-110-k%2*30);c.stroke()}}
 c.restore()}

/* the hero's flourish: raise the sword, hold a beat, lower it */
const DKF={t:-99,auto:6};
function dkFlourish(){if(S.t-DKF.t<2)return;DKF.t=S.t;try{beep(660,.06,'triangle',.18);setTimeout(()=>beep(990,.08,'triangle',.16),90)}catch(e){}}
const dkFlu=()=>{const k=S.t-DKF.t;if(k<0||k>2)return 0;return k<.45?1-Math.pow(1-k/.45,3):k<1.45?1:1-Math.min(1,(k-1.45)/.55)};

/* ---------- the backdrop: the land itself, zoomed in a touch with parallax ---------- */
function drawBG(){if(S.mode==='title'){if(S.view==='dc'&&S.dcv)zoneBG(0,S.t,S.dcv);else if(S.view==='camp'){ctx.fillStyle='#05030c';ctx.fillRect(0,0,W,H)}
  else{const L=HOME?dkHomeL():(hbgCur()>=0?LEVELS[hbgCur()]:null);
   if(HOME&&!ov.classList.contains('dknar')){const rm=dkRM();DKM.x+=(DKM.tx-DKM.x)*.06;DKM.y+=(DKM.ty-DKM.y)*.06;const ek=rm?1:Math.max(0,Math.min(1,(S.t-DKE.t0)/1.4)),ee=1-Math.pow(1-ek,3),sc=1.03+(1-ee)*.05;
    if(ek<1){ctx.save();ctx.translate(W/2,H/2);ctx.scale(1+(1-ee)*.05,1+(1-ee)*.05);ctx.translate(-W/2,-H/2);if(L)zoneBG(L.z,S.t,L);else menuBG(S.t);ctx.restore()}else{if(L)zoneBG(L.z,S.t,L);else menuBG(S.t)}}
   else{if(L)zoneBG(L.z,S.t,L);else menuBG(S.t)}
   if(HOME)homeScene(S.t)}}
 else if(S.mode==='crate')(S.cr2&&S.cr2.ck==='h'?sceneGen(SCN[32],S.t):menuBG(S.t));else{const L=(S.prac&&S.prac.map!=null&&S.prac.map!==31)?mapDef(S.prac.map):lvDef(S.wave||1);bgBlend(L)}}

/* ---------- the diorama ---------- */
const DKH={x:1160,y:648,s:2.3};
/* static light layers, baked once per land */
const DKLC={};
function dkLight(z,ac,warm){const key=ac+z.life;if(DKLC[key])return DKLC[key];const mk=()=>{const c=document.createElement('canvas');c.width=1000;c.height=900;return c};
 const G=mk(),g=G.getContext('2d');let q=g.createRadialGradient(660,240,40,660,300,760);q.addColorStop(0,dkMix(ac,'#ffffff',.5)+'5a');q.addColorStop(.5,ac+'26');q.addColorStop(1,ac+'00');g.fillStyle=q;g.fillRect(0,0,1000,900);
 q=g.createLinearGradient(0,260,0,760);q.addColorStop(0,ac+'00');q.addColorStop(.6,ac+'2c');q.addColorStop(1,ac+'08');g.fillStyle=q;g.fillRect(40,260,960,500);
 const shafts=(cv,ph)=>{const x=cv.getContext('2d'),n=z.life==='water'?7:5;for(let i=0;i<n;i++){const a=(z.life==='water'?.11:.075)*(.6+.4*Math.sin(i*2.1+ph));x.save();x.translate(400+i*95+ph*30,-40);x.rotate(.26+i*.035+Math.sin(i*1.7+ph)*.05);const q=x.createLinearGradient(0,0,0,900);q.addColorStop(0,warm+Math.round(a*255).toString(16).padStart(2,'0'));q.addColorStop(1,warm+'00');x.fillStyle=q;x.beginPath();x.moveTo(-18-i*3,0);x.lineTo(18+i*3,0);x.lineTo(80+i*18,900);x.lineTo(-80-i*18,900);x.closePath();x.fill();x.restore()}};
 shafts(G,0);return DKLC[key]={g:G}}
let DKVC=null;const dkVigC=()=>{if(DKVC)return DKVC;const c=document.createElement('canvas');c.width=900;c.height=900;const g=c.getContext('2d'),q=g.createRadialGradient(450,420,300,450,450,1000);q.addColorStop(0,'#05030c00');q.addColorStop(1,'#05030c5a');g.fillStyle=q;g.fillRect(0,0,900,900);return DKVC=c};
const DKGLOW={};const dkGlow=col=>{if(DKGLOW[col])return DKGLOW[col];const c=document.createElement('canvas');c.width=c.height=16;const g=c.getContext('2d'),q=g.createRadialGradient(8,8,0,8,8,8);q.addColorStop(0,col+'aa');q.addColorStop(1,col+'00');g.fillStyle=q;g.fillRect(0,0,16,16);g.fillStyle=col;g.beginPath();g.arc(8,8,1.6,0,TAU);g.fill();return DKGLOW[col]=c};
function homeScene(t){if(ov.classList.contains('dknar'))return homeEmbers(t);const c=ctx,rm=dkRM(),tt=rm?2:t,pc=(PATHS[P.path]||{}).c||'#ffd45a',z=dkZone(),L=dkHomeL();
 const ac=(L&&L.a&&/^#[0-9a-f]{6}$/i.test(L.a))?L.a:'#b49cff',warm=dkMix(ac,'#ffe6b0',.55),hx=DKH.x,hy=DKH.y,ox=rm?0:DKM.x*10,oy=rm?0:DKM.y*5;
 const ed=DKE.first?1.2:.4,ek=rm?1:Math.max(0,Math.min(1,(S.t-DKE.t0)/ed)),ee=1-Math.pow(1-ek,3);if(ek>=1)DKE.first=false;
 const hx2=hx+ox,hy2=hy+oy;
 /* baked light: grade, haze and two sets of light shafts that cross-fade so the beams seem to drift */
 {const LC=dkLight(z,ac,warm);let q;c.save();c.globalCompositeOperation='lighter';c.globalAlpha=ee;c.drawImage(LC.g,600+ox*.4,0);c.restore();
 c.save();c.globalAlpha=ee;c.drawImage(dkMid(z,ac),640+ox*.35,130+oy*.3);c.restore()}
 let q;
 /* region life behind the hero */
 c.globalAlpha=ee;dkLife(c,z,tt,ox);c.globalAlpha=1;
 /* the platform, with a soft glow and live details */
 const pl=dkPlatform(z),px=hx2-100-380,py=hy2-70+(1-ee)*20;c.save();c.globalAlpha=ee;
 q=c.createRadialGradient(hx2-100,hy2+40,20,hx2-100,hy2+40,420);q.addColorStop(0,'#00000070');q.addColorStop(1,'#00000000');c.fillStyle=q;c.beginPath();c.ellipse(hx2-100,hy2+110,420,60,0,0,TAU);c.fill();
 c.drawImage(pl,px,py);
 if(z.life==='water'){c.save();c.translate(hx2-100,hy2+86);c.scale(1,.14);for(let i=0;i<3;i++){const k=((tt*.3+i/3)%1);c.strokeStyle=`rgba(190,255,250,${(1-k)*.45})`;c.lineWidth=6;c.beginPath();c.arc(0,0,340+k*90,0,TAU);c.stroke()}c.restore();
  c.save();c.beginPath();c.ellipse(hx2-100,hy2,330,46,0,0,TAU);c.clip();c.globalCompositeOperation='lighter';for(let i=0;i<9;i++){const x=hx2-420+((tt*22+i*80)%660),y=hy2-30+(i%3)*22;c.strokeStyle='#bffff422';c.lineWidth=3;c.beginPath();c.moveTo(x,y);c.quadraticCurveTo(x+30,y-10+Math.sin(tt*2+i)*6,x+60,y);c.stroke()}c.restore()}
 if(z.life==='fire'){c.globalCompositeOperation='lighter';q=c.createRadialGradient(hx2-100,hy2+60,10,hx2-100,hy2+60,340);q.addColorStop(0,`rgba(255,90,20,${.18+.08*Math.sin(tt*3)})`);q.addColorStop(1,'#ff5a1a00');c.fillStyle=q;c.fillRect(hx2-460,hy2-60,720,240);c.globalCompositeOperation='source-over'}
 if(z.life==='cave'||z.life==='frost'){for(let i=0;i<5;i++){const k=((tt*.4+i*.21)%1);c.globalAlpha=Math.sin(k*Math.PI)*ee;const x=hx2-380+i*150,y=hy2+8+(i%2)*14;c.fillStyle=z.gl;c.beginPath();c.moveTo(x,y-6);c.lineTo(x+1.6,y-1.6);c.lineTo(x+6,y);c.lineTo(x+1.6,y+1.6);c.lineTo(x,y+6);c.lineTo(x-1.6,y+1.6);c.lineTo(x-6,y);c.lineTo(x-1.6,y-1.6);c.fill()}c.globalAlpha=1}
 c.restore();
 /* rune ring under the hero, with a pulse */
 c.save();c.translate(hx2,hy2+2);c.scale(1,.24);c.globalAlpha=ee;c.strokeStyle=pc+'80';c.lineWidth=5;c.setLineDash([16,12]);c.lineDashOffset=-tt*20;c.beginPath();c.arc(0,0,118,0,TAU);c.stroke();c.setLineDash([]);
 const pk=rm?1:((tt%5.5)/1.6);if(pk<1){c.strokeStyle=pc+Math.round((1-pk)*170).toString(16).padStart(2,'0');c.lineWidth=7*(1-pk)+1;c.beginPath();c.arc(0,0,118+pk*110,0,TAU);c.stroke()}
 if(ek<1){const fk=Math.min(1,ek*1.3);c.strokeStyle=warm+Math.round((1-fk)*230).toString(16).padStart(2,'0');c.lineWidth=14*(1-fk)+2;c.beginPath();c.arc(0,0,60+fk*280,0,TAU);c.stroke()}c.restore();
 /* light pool on the hero */
 q=c.createRadialGradient(hx2,hy2-170,10,hx2,hy2-170,300);q.addColorStop(0,pc+Math.round(40*ee).toString(16).padStart(2,'0'));q.addColorStop(1,pc+'00');c.fillStyle=q;c.fillRect(hx2-320,hy2-480,640,500);
 /* the companion, arriving a moment after the hero */
 if(P.pet&&typeof PDEF!=='undefined'&&PDEF[P.pet]){const pe=rm?1:Math.max(0,Math.min(1,(S.t-DKE.t0-ed*.25)/(ed*.7))),pee=1-Math.pow(1-pe,3),hv=PDEF[P.pet].hover,gk=S.t-DKF.t,gr=gk>=.1&&gk<1.9;
  c.save();c.globalAlpha=pee;c.translate(hx2-230-(1-pee)*40,hy2-4-(hv?40:0));c.scale(1.5,1.5);try{petDraw(c,P.pet,Object.assign({t:tt+3,pose:gr?'greet':'idle',u:gr?(gk-.1)/1.8:0},petLook(P.pet)))}catch(e){}c.restore()}
 /* the hero (with the flourish now and then) */
 if(!rm&&S.t-DKF.t>DKF.auto+5&&ek>=1){DKF.t=S.t;DKF.auto=7+Math.random()*6}
 const fl=rm?0:dkFlu(),dy=(1-ee)*26;c.save();c.globalAlpha=ee;c.translate(hx2,hy2+dy);c.scale(DKH.s,DKH.s);try{drawHero(c,fl>0?{arm:P.armor,wp:P.weapon,col:P.col,t:tt,lg:0,pose:'victory',pu:fl}:{arm:P.armor,wp:P.weapon,col:P.col,t:tt,lg:0})}catch(e){}c.restore();
 if(fl>.6){const k=S.t-DKF.t;c.save();c.globalCompositeOperation='lighter';const sx=hx2+58,sy=hy2-DKH.s*178;q=c.createRadialGradient(sx,sy,0,sx,sy,90);q.addColorStop(0,`rgba(255,250,220,${.55*fl})`);q.addColorStop(1,'#fff6d000');c.fillStyle=q;c.beginPath();c.arc(sx,sy,90,0,TAU);c.fill();
  for(let i=0;i<10;i++){const a=i*TAU/10+k*2,r=30+k*60;const x=sx+Math.cos(a)*r,y=sy+Math.sin(a)*r;c.fillStyle=i%2?'#fff6c0':pc;c.beginPath();c.moveTo(x,y-5);c.lineTo(x+1.4,y-1.4);c.lineTo(x+5,y);c.lineTo(x+1.4,y+1.4);c.lineTo(x,y+5);c.lineTo(x-1.4,y+1.4);c.lineTo(x-5,y);c.lineTo(x-1.4,y-1.4);c.fill()}c.restore()}
 if(ek<1){q=c.createRadialGradient(hx2,hy2-170,10,hx2,hy2-170,260);q.addColorStop(0,'#ffffff'+Math.round(Math.max(0,1-ek*1.6)*120).toString(16).padStart(2,'0'));q.addColorStop(1,'#ffffff00');c.globalCompositeOperation='lighter';c.fillStyle=q;c.fillRect(hx2-280,hy2-440,560,480);c.globalCompositeOperation='source-over'}
 /* fireflies of light around the stage */
 for(let i=0;i<14;i++){const u=((tt*.12+i*.137)%1),x=hx2-280+((i*97)%560)+Math.sin(tt*.9+i)*14,y=hy2-u*420;c.globalAlpha=Math.sin(u*Math.PI)*.8*ee;const col=i%3?'#ffe9a0':i%2?pc:warm;c.drawImage(dkGlow(col),x-8,y-8)}c.globalAlpha=1;
 /* foreground framing and a soft vignette */
 c.globalAlpha=ee;dkFront(c,z,tt,rm?0:DKM.x*22);c.globalAlpha=1;
 }

{const st=document.createElement('style');st.textContent=`
/* ----- new dock icons: each one moves its own way on hover and when it becomes active ----- */
.dkico{overflow:visible;filter:drop-shadow(0 3px 4px #0009)}.dkico g{transform-box:fill-box;transform-origin:50% 50%}
.dki .dkic svg{width:46px;height:46px}.dki .dkic{height:46px}
.dkico .dkspark{opacity:0;transition:opacity .2s}
.dki:hover .dkico .dkspark{opacity:1;animation:dktw 1.4s ease-in-out infinite}.dki.on .dkico .dkspark{opacity:1;animation:dktw 1.4s ease-in-out 2}@keyframes dktw{50%{transform:scale(.55) rotate(45deg)}}
.dki:hover .dkico-pl .dkis1{animation:dkclL .5s cubic-bezier(.3,1.6,.5,1)}.dki:hover .dkico-pl .dkis2{animation:dkclR .5s cubic-bezier(.3,1.6,.5,1)}
@keyframes dkclL{40%{transform:rotate(-14deg)}}@keyframes dkclR{40%{transform:rotate(14deg)}}
.dki:hover .dkico-gr .dkia{animation:dknod .55s ease-in-out}@keyframes dknod{30%{transform:rotate(-8deg)}70%{transform:rotate(6deg)}}
.dki:hover .dkico-pt .dkpt1{animation:dkbean .5s ease-out}.dki:hover .dkico-pt .dkpt2{animation:dkbean .5s .06s ease-out}.dki:hover .dkico-pt .dkpt3{animation:dkbean .5s .12s ease-out}.dki:hover .dkico-pt .dkpt4{animation:dkbean .5s .18s ease-out}@keyframes dkbean{40%{transform:translateY(-6px)}}
.dkico-pg .dkb1,.dkico-pg .dkb2,.dkico-pg .dkb3{transform-origin:50% 100%}.dki:hover .dkico-pg .dkb1{animation:dkgrow .6s ease-out}.dki:hover .dkico-pg .dkb2{animation:dkgrow .6s .08s ease-out}.dki:hover .dkico-pg .dkb3{animation:dkgrow .6s .16s ease-out}@keyframes dkgrow{0%{transform:scaleY(.2)}70%{transform:scaleY(1.08)}}
.dki:hover .dkico-sh .dkpo{animation:dkjig .5s ease-in-out}.dki:hover .dkico-sh .dkcn{animation:dkflip .7s ease-out}@keyframes dkjig{25%{transform:rotate(-7deg)}75%{transform:rotate(7deg)}}@keyframes dkflip{50%{transform:translateY(-10px) scaleX(.2)}}
.dki:hover .dkico-mo .dkd1{animation:dkbean .45s ease-out}.dki:hover .dkico-mo .dkd2{animation:dkbean .45s .07s ease-out}.dki:hover .dkico-mo .dkd3{animation:dkbean .45s .14s ease-out}
.dki.on .dkico{filter:drop-shadow(0 0 10px #ffffff66) drop-shadow(0 3px 4px #0009)}
.dk{background:linear-gradient(180deg,#221a52f2,#100a2cf6);box-shadow:0 14px 40px #000d,0 0 0 1px #6a58c044,inset 0 1px 0 #ffffff1c}
.dk::before{content:'';position:absolute;inset:0;border-radius:inherit;pointer-events:none;background:linear-gradient(105deg,transparent 30%,#ffffff14 48%,transparent 62%) -120% 0/250% 100% no-repeat;animation:none}@keyframes dkdocks{0%,78%{background-position:140% 0}100%{background-position:-40% 0}}
.dkhome .dk{animation:dkdock .6s .25s cubic-bezier(.2,1.2,.4,1) both}@keyframes dkdock{from{opacity:0;transform:translateY(40px)}}
.dkhome .dki{animation:dkip .45s cubic-bezier(.3,1.6,.5,1) both}.dkhome .dki:nth-of-type(1){animation-delay:.35s}.dkhome .dki:nth-of-type(2){animation-delay:.4s}.dkhome .dki:nth-of-type(3){animation-delay:.45s}.dkhome .dki:nth-of-type(4){animation-delay:.5s}.dkhome .dki:nth-of-type(5){animation-delay:.55s}.dkhome .dki:nth-of-type(6){animation-delay:.6s}
@keyframes dkip{from{opacity:0;transform:translateY(14px) scale(.8)}}
/* ----- glare: a soft light follows the cursor across buttons and cards ----- */
.dkg{position:relative;--gx:50%;--gy:0%}
.dkg>.dkgl{position:absolute;inset:0;border-radius:inherit;pointer-events:none;z-index:2;opacity:0;transition:opacity .2s;background:radial-gradient(260px circle at var(--gx) var(--gy),#ffffff2e,transparent 60%)}
.dkg:hover>.dkgl{opacity:1}
.dktilt{transform:perspective(900px) rotateX(var(--rx,0deg)) rotateY(var(--ry,0deg));transition:transform .18s ease-out,box-shadow .16s,border-color .16s}
.dktilt:hover{transform:perspective(900px) rotateX(var(--rx,0deg)) rotateY(var(--ry,0deg)) translateY(-4px)}
.dkcp .dkgl{background:radial-gradient(520px circle at var(--gx) var(--gy),#ffffff12,transparent 60%)}
/* the panel arrives with a sweep of light */
.dkcp::after{content:'';position:absolute;inset:0;pointer-events:none;border-radius:inherit;background:linear-gradient(110deg,transparent 35%,#ffffff1c 48%,#ffffff30 50%,#ffffff1c 52%,transparent 65%) 160% 0/260% 100% no-repeat;animation:dkpsw 1.4s .5s ease-out both}@keyframes dkpsw{to{background-position:-60% 0}}
.dkcp{background:linear-gradient(180deg,#151132f0,#0e0b24f2);border-color:#4a3e8a}
#ov.dkhome{background:radial-gradient(ellipse 70% 80% at 72% 45%,rgba(6,3,16,0),rgba(6,3,16,.18)),linear-gradient(90deg,rgba(6,3,16,.82),rgba(6,3,16,.5) 46%,rgba(6,3,16,.04) 64%,rgba(6,3,16,.12)),linear-gradient(0deg,rgba(6,3,16,.75),rgba(6,3,16,0) 24%)}
.dkcp{border:1px solid #4e4290;box-shadow:0 22px 60px #000c,0 0 0 1px #00000060,inset 0 1px 0 #ffffff18}
/* region boss line */
.dkbs small{font:500 15px var(--ui);color:#c4badf;margin-right:2px}
/* ----- hero stage controls ----- */
.dkhs{position:absolute;left:${DKH.x-100-232}px;top:${DKH.y+32}px;width:464px;display:flex;gap:14px;justify-content:center;z-index:3;animation:dkin .5s .7s cubic-bezier(.2,.8,.2,1) both}
.dkhb{all:unset;box-sizing:border-box;position:relative;cursor:pointer;flex:1;display:flex;align-items:center;justify-content:center;gap:10px;min-height:48px;padding:0 18px;border-radius:14px;font:700 16px var(--ui);color:#fff8e8;background:linear-gradient(180deg,#22195aee,#130d36f2);border:1px solid #6a58c0;box-shadow:0 10px 24px #000b,inset 0 1px 0 #ffffff1c;transition:transform .16s,border-color .16s,background .16s}
.dkhb:hover{border-color:#b49cff;background:linear-gradient(180deg,#2c2270,#181046);transform:translateY(-2px)}.dkhb:focus-visible{outline:3px solid #ffd45a;outline-offset:2px}.dkhb svg{width:30px;height:30px}.dkhb .bdg{position:absolute;top:-7px;right:-6px;min-width:20px;height:20px;padding:0 6px;box-sizing:border-box;border-radius:10px;display:grid;place-items:center;font:800 11.5px var(--ui);font-style:normal;color:#fff;background:#e8364e;box-shadow:0 0 0 2px #0f0a28}
.dkhot{position:absolute;left:${DKH.x-120}px;top:${DKH.y-DKH.s*175}px;width:240px;height:${DKH.s*170}px;cursor:pointer;z-index:2;border-radius:40%}
#ov.dknar .dkhs{position:static;width:auto;margin:10px 14px 0;animation:none;grid-column:1;grid-row:4}#ov.dknar.dkhome .dkrow{grid-row:5}#ov.dknar .dkh{grid-template-rows:auto auto auto auto auto}
#ov.dknar.dkshort .dkhs{grid-column:2;grid-row:3;margin:8px 14px 0}#ov.dknar.dkshort.dkhome .dkrow{grid-row:4}#ov.dknar.dkshort .dkbl,#ov.dknar.dkshort .dkbs,#ov.dknar.dkshort .dkst1>i:nth-of-type(2){display:none}#ov.dknar.dkshort .dkhb{min-height:40px;font-size:14px}#ov.dknar .dkhot{display:none}
body.tm #ov .dkhb{min-height:48px;padding:0 18px}
@media (prefers-reduced-motion:reduce){.dk::before,.dkhome .dk,.dkhome .dki,.dkcp::after,.dkhs,.dki .dkico *{animation:none!important}.dktilt{transform:none!important}}

/* the shines run as single sweeps on a timer, so nothing repaints while it waits */
#ov.dkshine .dklogo h1 span{animation:dkshimO 1.3s ease-in-out both}#ov.dkshine .dklogo h1 span+span{animation-delay:.15s}
#ov.dkshine .dkttl em{animation:dkshimO 1.3s .5s ease-in-out both}
#ov.dkshine .dkgo::after{animation:dksheenO 1.1s .9s ease-in-out both}
#ov.dkshine .dk::before{animation:dksheenO 1.4s 1.3s ease-in-out both}
@keyframes dkshimO{from{background-position:140% 0,0 0}to{background-position:-50% 0,0 0}}@keyframes dksheenO{from{background-position:130% 0}to{background-position:-40% 0}}
@media (prefers-reduced-motion:reduce){#ov.dkshine *{animation:none!important}}
`;document.head.appendChild(st)}

{let n=0;setInterval(()=>{try{if(!HOME||dkRM()||document.hidden){ov.classList.remove('dkshine');return}n++;if(n%3===1){ov.classList.remove('dkshine');void ov.offsetWidth;ov.classList.add('dkshine')}else if(n%3===0)ov.classList.remove('dkshine')}catch(e){}},2500)}

/* ---------- the Daily Challenge card: a living postcard of today's land, crowned with a medallion for today's twist ---------- */
const DKDG={
 frenzy:(g,s,c)=>{g.beginPath();g.moveTo(4*s,-16*s);g.lineTo(-8*s,2*s);g.lineTo(0,2*s);g.lineTo(-4*s,16*s);g.lineTo(9*s,-3*s);g.lineTo(1*s,-3*s);g.closePath();g.fillStyle=c;g.fill()},
 turbo:(g,s,c)=>{g.lineWidth=5*s;g.strokeStyle=c;g.lineJoin='round';g.lineCap='round';for(const x of[-7,5]){g.beginPath();g.moveTo((x-5)*s,-11*s);g.lineTo((x+5)*s,0);g.lineTo((x-5)*s,11*s);g.stroke()}},
 dark:(g,s,c)=>{g.fillStyle=c;g.beginPath();g.arc(0,0,14*s,0,TAU);g.fill();g.globalCompositeOperation='destination-out';g.beginPath();g.arc(7*s,-5*s,12*s,0,TAU);g.fill();g.globalCompositeOperation='source-over'},
 fog:(g,s,c)=>{g.strokeStyle=c;g.lineWidth=4*s;g.lineCap='round';for(let i=-1;i<=1;i++){g.beginPath();for(let x=-14;x<=14;x+=2){const y=i*9+Math.sin(x*.45+i)*2.6;x===-14?g.moveTo(x*s,y*s):g.lineTo(x*s,y*s)}g.stroke()}},
 giants:(g,s,c)=>{g.fillStyle=c;g.beginPath();g.ellipse(0,5*s,9*s,11*s,0,0,TAU);g.fill();for(const [x,y,r] of[[-10,-9,3.4],[-4,-14,3.6],[3,-14,3.6],[10,-10,3.2]]){g.beginPath();g.arc(x*s,y*s,r*s,0,TAU);g.fill()}},
 glass:(g,s,c)=>{g.fillStyle=c;g.beginPath();g.moveTo(0,-16*s);g.lineTo(12*s,-4*s);g.lineTo(0,16*s);g.lineTo(-12*s,-4*s);g.closePath();g.fill();g.strokeStyle='#00000066';g.lineWidth=2*s;g.beginPath();g.moveTo(-3*s,-10*s);g.lineTo(2*s,-2*s);g.lineTo(-2*s,4*s);g.lineTo(3*s,11*s);g.stroke()},
 gusts:(g,s,c)=>{g.strokeStyle=c;g.lineWidth=4*s;g.lineCap='round';g.beginPath();g.moveTo(-15*s,-6*s);g.lineTo(6*s,-6*s);g.arc(6*s,-11*s,5*s,Math.PI/2,-Math.PI*.8,true);g.stroke();g.beginPath();g.moveTo(-15*s,3*s);g.lineTo(9*s,3*s);g.arc(9*s,8*s,5*s,-Math.PI/2,Math.PI*.8);g.stroke();g.beginPath();g.moveTo(-12*s,11*s);g.lineTo(0,11*s);g.stroke()},
 ranged:(g,s,c)=>{g.strokeStyle=c;g.fillStyle=c;g.lineWidth=4*s;g.lineCap='round';g.beginPath();g.moveTo(-12*s,12*s);g.lineTo(10*s,-10*s);g.stroke();g.beginPath();g.moveTo(14*s,-14*s);g.lineTo(3*s,-11*s);g.lineTo(11*s,-3*s);g.closePath();g.fill();g.beginPath();g.moveTo(-12*s,12*s);g.lineTo(-15*s,5*s);g.moveTo(-12*s,12*s);g.lineTo(-5*s,15*s);g.stroke()},
 swarm:(g,s,c)=>{g.fillStyle=c;for(const [x,y,r] of[[0,0,5],[-10,-7,4],[10,-6,4],[-8,9,3.6],[9,9,3.6],[0,-14,3],[-15,2,2.6],[15,2,2.6]]){g.beginPath();g.arc(x*s,y*s,r*s,0,TAU);g.fill()}},
 elite:(g,s,c)=>{g.fillStyle=c;g.beginPath();g.moveTo(0,-16*s);g.lineTo(13*s,-10*s);g.lineTo(11*s,6*s);g.lineTo(0,16*s);g.lineTo(-11*s,6*s);g.lineTo(-13*s,-10*s);g.closePath();g.fill();g.fillStyle='#00000055';g.beginPath();for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,r=i%2?3:7;g.lineTo(Math.cos(a)*r*s,Math.sin(a)*r*s-1*s)}g.closePath();g.fill()},
 wordsmith:(g,s,c)=>{g.fillStyle=c;g.beginPath();g.moveTo(12*s,-15*s);g.quadraticCurveTo(-8*s,-8*s,-10*s,12*s);g.quadraticCurveTo(4*s,4*s,12*s,-15*s);g.fill();g.strokeStyle=c;g.lineWidth=2.4*s;g.beginPath();g.moveTo(-10*s,12*s);g.lineTo(-14*s,16*s);g.stroke()},
 star:(g,s,c)=>{g.fillStyle=c;g.beginPath();for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,r=i%2?6:15;g.lineTo(Math.cos(a)*r*s,Math.sin(a)*r*s)}g.closePath();g.fill()},
 check:(g,s,c)=>{g.strokeStyle=c;g.lineWidth=5*s;g.lineCap='round';g.lineJoin='round';g.beginPath();g.moveTo(-11*s,0);g.lineTo(-3*s,9*s);g.lineTo(12*s,-9*s);g.stroke()}};
function dkDailyLive(cv,run,img,dd){const g=cv.getContext('2d'),W2=cv.width,H2=cv.height,ac=/^#[0-9a-f]{6}$/i.test(run.R.a||'')?run.R.a:'#5ad8e8',gold='#ffd45a';
 const im=new Image();let ok=false;if(img){im.onload=()=>{ok=true;draw(2)};im.src=img}
 const wx=(run.R.sc&&run.R.sc.wx)||run.L.wx||'motes',mk=(run.M&&run.M.k)||'star',glyph=DKDG[dd?'check':mk]||DKDG.star;
 const P_=Array.from({length:26},(_,i)=>{const r=k=>{const x=Math.sin((i+1)*7.13+k*3.7)*43758.5453;return x-Math.floor(x)};return[r(1),r(2),r(3),r(4)]});
 const mx=W2-92,my=82;
 const draw=t=>{g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,W2,H2);
  /* today's land, drifting slowly */
  if(ok){const k=(Math.sin(t*.09)+1)/2,sc=1.08+k*.05,dx=(k-.5)*30;const w=W2*sc,h=w*im.height/im.width;g.drawImage(im,(W2-w)/2+dx,(H2-h)/2-10,w,h)}else{const q=g.createLinearGradient(0,0,0,H2);q.addColorStop(0,'#1a1040');q.addColorStop(1,dkMix(ac,'#000000',.6));g.fillStyle=q;g.fillRect(0,0,W2,H2)}
  /* colour wash from today's accent, and a darker base for the words */
  let q=g.createLinearGradient(W2,0,0,H2);q.addColorStop(0,ac+'55');q.addColorStop(.5,ac+'10');q.addColorStop(1,'#00000000');g.fillStyle=q;g.fillRect(0,0,W2,H2);
  /* the weather of that land */
  g.save();for(let i=0;i<P_.length;i++){const [a,b,c2,d]=P_[i];let x,y,col,r=1.2+d*2.2,al;
   if(wx==='snow'){y=((a+t*(.04+c2*.04))%1)*H2;x=b*W2+Math.sin(t+i)*14;col='#ffffff';al=.8}
   else if(wx==='rain'){y=((a+t*(.5+c2*.3))%1)*H2;x=(b*W2+y*.25)%W2;g.strokeStyle='#cfe8ff88';g.lineWidth=1.4;g.beginPath();g.moveTo(x,y);g.lineTo(x-4,y-14);g.stroke();continue}
   else if(wx==='sand'||wx==='wind'){x=((b+t*(.06+c2*.06))%1)*W2;y=a*H2+Math.sin(t*2+i)*6;col='#ffd8a0';al=.55;r=1+d*1.6}
   else if(wx==='embers'||wx==='ash'){y=H2-((a+t*(.06+c2*.06))%1)*H2;x=b*W2+Math.sin(t*1.6+i)*10;col=wx==='ash'?'#c8c0c8':(i%2?'#ffb04a':'#ff6a2a');al=.85}
   else{y=H2-((a+t*(.03+c2*.03))%1)*H2;x=b*W2+Math.sin(t+i)*16;col=dkMix(ac,'#ffffff',.6);al=.7}
   const fade=Math.sin(Math.min(1,y/H2)*Math.PI);g.globalAlpha=al*Math.max(.15,fade);g.fillStyle=col;g.beginPath();g.arc(x,y,r,0,TAU);g.fill()}g.restore();
  /* the medallion */
  const pu=.5+.5*Math.sin(t*2.2),R=50;g.save();g.translate(mx,my);
  g.globalCompositeOperation='lighter';q=g.createRadialGradient(0,0,10,0,0,R*2);q.addColorStop(0,(dd?gold:ac)+Math.round(90+60*pu).toString(16));q.addColorStop(1,(dd?gold:ac)+'00');g.fillStyle=q;g.beginPath();g.arc(0,0,R*2,0,TAU);g.fill();g.globalCompositeOperation='source-over';
  /* light rays turning behind it */g.save();g.rotate(t*.25);g.globalAlpha=.35;for(let i=0;i<12;i++){g.rotate(TAU/12);q=g.createLinearGradient(0,0,0,-R*1.8);q.addColorStop(0,'#ffffffaa');q.addColorStop(1,'#ffffff00');g.fillStyle=q;g.beginPath();g.moveTo(-4,-R*.8);g.lineTo(4,-R*.8);g.lineTo(0,-R*1.8);g.closePath();g.fill()}g.restore();
  g.shadowColor='#000a';g.shadowBlur=14;g.shadowOffsetY=4;
  q=g.createLinearGradient(0,-R,0,R);q.addColorStop(0,'#fff2b0');q.addColorStop(.5,'#e8a830');q.addColorStop(1,'#8a5a10');g.fillStyle=q;g.beginPath();g.arc(0,0,R,0,TAU);g.fill();g.shadowColor='transparent';
  /* notched rim */g.save();g.rotate(-t*.4);g.fillStyle='#fff6c8';for(let i=0;i<24;i++){g.rotate(TAU/24);g.fillRect(-1.4,-R+2,2.8,5)}g.restore();
  const ic=dd?dkMix(gold,'#ffffff',.2):ac;q=g.createRadialGradient(-10,-12,4,0,0,R-9);q.addColorStop(0,dkMix(ic,'#ffffff',.45));q.addColorStop(.6,ic);q.addColorStop(1,dkMix(ic,'#000000',.55));g.fillStyle=q;g.beginPath();g.arc(0,0,R-9,0,TAU);g.fill();
  g.strokeStyle='#5a3a08';g.lineWidth=2;g.stroke();
  /* today's twist, gently breathing */const bs=1+.05*Math.sin(t*2.6);g.save();g.scale(bs,bs);g.shadowColor='#0008';g.shadowBlur=6;glyph(g,1.45,'#ffffff');g.restore();
  /* glint */g.save();g.beginPath();g.arc(0,0,R-9,0,TAU);g.clip();const gp=((t*.35)%2.4)-.7;g.globalCompositeOperation='lighter';q=g.createLinearGradient(gp*R*2-30,0,gp*R*2+30,0);q.addColorStop(0,'#ffffff00');q.addColorStop(.5,'#ffffff70');q.addColorStop(1,'#ffffff00');g.fillStyle=q;g.save();g.rotate(-.5);g.fillRect(-R*2,-R*2,R*4,R*4);g.restore();g.restore();
  /* sparkles orbiting */for(let i=0;i<5;i++){const a=t*.8+i*TAU/5,rr=R+12+Math.sin(t*2+i)*4,x=Math.cos(a)*rr,y=Math.sin(a)*rr*.85,s2=2.5+2*Math.max(0,Math.sin(t*3+i*1.3));g.fillStyle='#fff8d8';g.beginPath();g.moveTo(x,y-s2*2);g.lineTo(x+s2*.5,y-s2*.5);g.lineTo(x+s2*2,y);g.lineTo(x+s2*.5,y+s2*.5);g.lineTo(x,y+s2*2);g.lineTo(x-s2*.5,y+s2*.5);g.lineTo(x-s2*2,y);g.lineTo(x-s2*.5,y-s2*.5);g.fill()}
  g.restore();
  /* bottom shade for legible text */q=g.createLinearGradient(0,H2*.35,0,H2);q.addColorStop(0,'#07041200');q.addColorStop(1,'#070412f0');g.fillStyle=q;g.fillRect(0,0,W2,H2)};
 draw(2);if(!dkRM())LIVE.push({cv,fn:t=>draw(t),slow:2,ph:1})}
{const st=document.createElement('style');st.textContent=`
.dkdaily{border-color:color-mix(in srgb,var(--dac) 70%,transparent)!important}.dkdaily:hover{border-color:var(--dac)!important;box-shadow:0 14px 30px #000c,0 0 22px color-mix(in srgb,var(--dac) 40%,transparent)}
.dkdaily.dklive::after{background:linear-gradient(90deg,#070412cc 0%,#07041266 55%,transparent 75%)}
.dkdaily .dkcl{max-width:58%}.dkdaily .dkchip{right:auto;left:auto;position:static;align-self:flex-start;margin-top:6px}
.dkdaily .dkcl{z-index:3}.dkstk{color:#ffb06a}
.dkdaily .dkchip{display:inline-block}
.dkdaily .dkcl small{white-space:nowrap;letter-spacing:1.6px}.dkdaily .dkcl{max-width:62%}
.dkdaily:not(.done) .dkchip{color:#06121a;background:linear-gradient(180deg,color-mix(in srgb,var(--dac) 45%,#fff),var(--dac));box-shadow:0 0 12px color-mix(in srgb,var(--dac) 50%,transparent)}
#ov>.dkrow{animation:none!important}
`;document.head.appendChild(st)}
