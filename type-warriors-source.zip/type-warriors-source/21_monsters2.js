/* ---------- expanded bestiary: 23 new monsters with special behaviours ----------
   tr: shield (needs two words), split (bursts into spawnlings), bomb (explodes, chain-kills neighbours),
       blink (teleports forward), summon (calls minions), charge (sprints when close) */
function mushroom(g,t,o){const w=Math.sin(t*6)*2,cy=-40;glow(g,0,-44,60,'#c8ff6a44');
 const leg=(x,ph)=>{const a=Math.sin(t*8+ph)*7;limb(g,x,-14,x+a*.5,-4-Math.max(0,-a)*.4,6,'#e8dcc0');ell(g,x+a,-3,7,3.4,'#b8a888')};leg(-8,0);leg(10,Math.PI);
 g.beginPath();g.roundRect(-13,-52,26,42,9);g.fillStyle=hgr(g,-13,13,'#f4ead0','#c8b890');g.fill();
 g.beginPath();g.ellipse(0,-58+w*.3,38,26,0,Math.PI,TAU);g.lineTo(38,-56);g.quadraticCurveTo(0,-46,-38,-56);g.closePath();g.fillStyle=rgr(g,-10,-72,2,50,'#ff6a6a','#8a1a2a');g.fill();g.strokeStyle='#0008';g.lineWidth=1.6;g.stroke();
 for(const [x,y,r] of[[-20,-70,5],[4,-80,6],[22,-68,4.5],[-4,-66,3.5]])ell(g,x,y,r,r*.85,'#fff0e0');
 eye(g,-10,-44,3.4,'#ffe04a');eye(g,4,-44,3.4,'#ffe04a');ell(g,-3,-34,5,2.6,'#3a1010');
 for(let i=0;i<5;i++){const u=(t*.6+i/5)%1;g.globalAlpha=1-u;ell(g,Math.sin(i*5+t)*22,-92-u*34,3,3,'#c8ff6a');g.globalAlpha=1}}
function magmaBomb(g,t,o){const r=Math.sin(t*9)*2,hot=.5+.5*Math.sin(t*10);glow(g,0,-40,80,'#ff5a1a'+(hot>.5?'99':'66'));
 const leg=(x,ph)=>{const a=Math.sin(t*9+ph)*8;limb(g,x,-18,x+a*.5,-4,7,'#3a2018');ell(g,x+a,-3,8,3.6,'#2a1410')};leg(-12,0);leg(12,Math.PI);
 ell(g,0,-46+r*.4,34,34,rgr(g,-8,-58,3,44,'#5a3a30','#1a0e0a'));
 g.strokeStyle='#ff8a2a';g.lineWidth=3;g.shadowColor='#ff5a1a';g.shadowBlur=10;for(const p of[[-22,-60,-8,-50,-14,-36],[8,-72,14,-56,4,-44],[20,-46,8,-40,16,-26]]){g.beginPath();g.moveTo(p[0],p[1]);g.lineTo(p[2],p[3]);g.lineTo(p[4],p[5]);g.stroke()}g.shadowBlur=0;
 eye(g,-14,-52,4,'#ffe04a');eye(g,4,-52,4,'#ffe04a');ell(g,-5,-38,9,4,'#1a0808');
 g.strokeStyle='#c8a870';g.lineWidth=3;g.beginPath();g.moveTo(-2,-80);g.quadraticCurveTo(6,-96,16,-92);g.stroke();
 const fx=16,fy=-92;glow(g,fx,fy,22,'#ffcf3acc');ell(g,fx,fy,5+hot*2,5+hot*2,'#fff0a0');for(let i=0;i<4;i++){const u=(t*3+i/4)%1;g.globalAlpha=1-u;ell(g,fx+Math.sin(i*4)*8,fy-u*22,2,2,'#ffb040');g.globalAlpha=1}}
function jelly(g,t,o){const p=Math.sin(t*4),cy=-62;glow(g,0,cy,84,'#ff8ae888');
 for(let i=0;i<6;i++){const x=-24+i*9.6;g.strokeStyle='#ffb0f0'+(i%2?'aa':'ff');g.lineWidth=3.4;g.lineCap='round';g.beginPath();g.moveTo(x,cy+16);for(let k=1;k<=6;k++)g.lineTo(x+Math.sin(t*5+i+k*.8)*(3+k),cy+16+k*9);g.stroke()}
 g.beginPath();g.moveTo(-36,cy+14);g.quadraticCurveTo(-42,cy-44-p*4,0,cy-46-p*4);g.quadraticCurveTo(42,cy-44-p*4,36,cy+14);g.quadraticCurveTo(18,cy+6+p*3,0,cy+14);g.quadraticCurveTo(-18,cy+6+p*3,-36,cy+14);g.closePath();
 g.fillStyle=vgr(g,cy-46,cy+14,'#ffd0f8','#c04ab8');g.globalAlpha=.9;g.fill();g.globalAlpha=1;g.strokeStyle='#fff8';g.lineWidth=1.6;g.stroke();
 ell(g,-12,cy-20,6,9,'#ffffff55');eye(g,-12,cy-8,3.4,'#ffffff');eye(g,6,cy-8,3.4,'#ffffff');
 g.strokeStyle='#fff';g.lineWidth=1.6;g.shadowColor='#ffffff';g.shadowBlur=8;for(const x of[-18,10,26]){g.beginPath();g.moveTo(x,cy-30);g.lineTo(x+4,cy-22);g.lineTo(x-2,cy-16);g.stroke()}g.shadowBlur=0}
const barn=(g,t,q)=>{for(const [x,y,r] of[[-10,q.SH+6,4],[8,q.SH+12,5],[-2,-40,4],[12,-46,3.4]]){ell(g,x,y,r,r*.7,'#bfe0d0');ell(g,x,y,r*.5,r*.35,'#5a7a6a')}};
const CFG2={
shaman:o=>({lg:o.lg,sk:'#7ab04a',cl:'#5a3a5a',robe:1,hd:14,hunch:1,ear:'pt',nose:1,eye:'#c8ff5a',wp:'staff',orb:'#c8ff5a',cape:'#3a2a4a',bulk:.85,legH:30,walk:.6,horn:'#8a6a3a',hornL:.8,aura:'#9aff4a'}),
ent:o=>({lg:o.lg,sk:'#6a4a2a',dk:'#3a2412',hl:'#8a6a3a',top:'#5a3a1e',fur:'#4a8a2a',hd:14,eye:'#ffcf3a',bulk:1.9,lw:13,reach:10,hunch:.8,legH:34,wp:'club',wsc:1.4,pad:'#3a7a2a',padspike:1}),
dknight:o=>({lg:o.lg,bone:1,sk:'#cfd2e0',dk:'#6a6e82',eye:'#ff5a5a',wp:'gsword',bl:'#a0a8bc',top:'#5a5e74',pad:'#4a4e64',padspike:1,cl:'#1a1a2a',cape:'#5a0a1a',bulk:1.25,hd:13,lw:5,legH:34}),
necro:o=>({lg:o.lg,bone:1,sk:'#d8d2bc',dk:'#8a8470',eye:'#b06bff',wp:'staff',orb:'#b06bff',cl:'#2a1a3a',robe:1,cape:'#1a0f2a',bulk:1,hd:13,walk:.3,legH:32,aura:'#b06bff',horn:'#d8d0b8',hornL:.9}),
cgolem:o=>({lg:o.lg,sk:'#9a5ac8',dk:'#4a2a78',hl:'#d8a0ff',top:'#7a3aa8',hd:14,eye:'#ffffff',bulk:1.9,lw:13,reach:10,hunch:.6,legH:32,belly:1,aura:'#c86bff',pad:'#c8a0ff',padspike:1,wp:'club',wsc:1.3}),
cultist:o=>({lg:o.lg,sk:'#c89a7a',cl:'#8a1a1a',robe:1,cape:'#4a0a0a',hd:13,eye:'#ffcf3a',wp:'staff',orb:'#ff7a2a',bulk:.95,legH:30,walk:.6,aura:'#ff5a2a',hunch:.4}),
lavagol:o=>({lg:o.lg,sk:'#4a2a26',dk:'#1a0e0c',hl:'#8a4a30',top:'#2a1a18',hd:14,eye:'#ffdd33',bulk:2,lw:14,reach:10,hunch:.4,legH:30,belly:1,aura:'#ff6a1a',pad:'#5a3a30',padspike:1,wp:'hammer',wsc:1.3,fx:(g,t,q)=>{g.strokeStyle='#ff9a2a';g.lineWidth=2.6;g.shadowColor='#ff7a1a';g.shadowBlur=10;for(const p of[[-14,q.SH+6,-4,q.SH+18,-12,q.SH+28],[10,q.SH+4,16,q.SH+16,6,q.SH+26],[-8,-46,0,-38,-6,-30]]){g.beginPath();g.moveTo(p[0],p[1]);g.lineTo(p[2],p[3]);g.lineTo(p[4],p[5]);g.stroke()}g.shadowBlur=0}}),
igol:o=>({lg:o.lg,sk:'#8fd4f0',dk:'#3a78a8',hl:'#e8faff',top:'#bfe8ff',hd:14,eye:'#ffffff',bulk:2,lw:14,reach:10,legH:30,belly:1,aura:'#8fdcff',pad:'#e8faff',padspike:1,wp:'hammer',wsc:1.2}),
fwitch:o=>({lg:o.lg,sk:'#c8d8e8',cl:'#3a6aa8',robe:1,cape:'#1a3a68',hd:13,eye:'#7fe8ff',wp:'staff',orb:'#7fe8ff',hunch:.5,walk:.5,legH:30,aura:'#7fe8ff',horn:'#e8faff',hornL:.9}),
siren:o=>({lg:o.lg,sk:'#5ad0c0',dk:'#2a7a80',cl:'#1a5a68',robe:1,cape:'#0a3a50',hd:13,eye:'#ffffff',hunch:0,walk:.6,wp:'staff',orb:'#8ff8e0',legH:30,aura:'#5ad0c0'}),
drown:o=>({lg:o.lg,sk:'#6a9a8a',dk:'#2a4a4a',cl:'#3a4a5a',top:'#3a4a5a',hd:13,hunch:1.3,eye:'#e8ff7a',fang:1,bulk:1.4,lw:10,legH:33,wp:'hammer',wsc:1.1,fx:barn})};
const NM2={
mush:{n:'Spore Shroom',h:112,sp:40,th:100,tr:'bomb'},shaman:{n:'Goblin Shaman',h:150,sp:44,th:96,tr:'summon'},warg:{n:'Feral Warg',h:110,sp:86,th:82,cx:-8,tr:'charge'},ent:{n:'Thorn Ent',h:230,sp:28,th:118,tr:'shield'},
necro:{n:'Necromancer',h:158,sp:38,th:98,tr:'summon'},banshee:{n:'Banshee',h:160,sp:68,th:110,fly:1,tr:'blink',hue:80},hound:{n:'Bone Hound',h:104,sp:100,th:82,cx:-8,tr:'charge'},dknight:{n:'Death Knight',h:196,sp:30,th:100,tr:'shield'},
weaver:{n:'Web Weaver',h:112,sp:50,th:64,pj:'web',rgp:.7},mite:{n:'Venom Mite',h:74,sp:150,th:64},brood:{n:'Broodmother',h:150,sp:30,th:64,tr:'split'},cgolem:{n:'Crystal Golem',h:236,sp:28,th:118,tr:'shield'},
cultist:{n:'Fire Cultist',h:150,sp:46,th:96,pj:'fire',rgp:.65,tr:'summon'},bomber:{n:'Magma Bomb',h:112,sp:44,th:100,tr:'bomb'},hellhound:{n:'Hellhound',h:108,sp:118,th:82,cx:-8,tr:'charge'},garg:{n:'Gargoyle',h:124,sp:78,th:68,fly:1,tr:'shield'},lavagol:{n:'Lava Golem',h:238,sp:28,th:118,tr:'shield'},
fwitch:{n:'Frost Witch',h:154,sp:42,th:96,tr:'summon'},harpy:{n:'Frost Harpy',h:112,sp:130,th:68,fly:1,tr:'blink'},lynx:{n:'Snow Lynx',h:102,sp:104,th:82,cx:-8,tr:'charge'},igol:{n:'Ice Golem',h:236,sp:28,th:118,tr:'shield'},
siren:{n:'Siren',h:152,sp:46,th:96,pj:'bubble',rgp:.6,tr:'blink'},drown:{n:'Drowned Sailor',h:176,sp:34,th:98,tr:'shield'},jelly:{n:'Storm Jelly',h:130,sp:96,th:100,fly:1,tr:'bomb'},eel:{n:'Moray Eel',h:138,sp:60,th:90,cx:20,tr:'charge'}};
Object.assign(MON,NM2);
Object.assign(DR,{mush:mushroom,bomber:magmaBomb,jelly,
shaman:(g,t,o)=>hum(g,t,CFG2.shaman(o)),ent:(g,t,o)=>hum(g,t,CFG2.ent(o)),necro:(g,t,o)=>hum(g,t,CFG2.necro(o)),dknight:(g,t,o)=>hum(g,t,CFG2.dknight(o)),cgolem:(g,t,o)=>hum(g,t,CFG2.cgolem(o)),
cultist:(g,t,o)=>hum(g,t,CFG2.cultist(o)),lavagol:(g,t,o)=>hum(g,t,CFG2.lavagol(o)),igol:(g,t,o)=>hum(g,t,CFG2.igol(o)),fwitch:(g,t,o)=>hum(g,t,CFG2.fwitch(o)),siren:(g,t,o)=>hum(g,t,CFG2.siren(o)),drown:(g,t,o)=>hum(g,t,CFG2.drown(o)),
warg:(g,t,o)=>wolf(g,t,o,{col:'#6a4a30',hi:'#9a7248',eye:'#ff5a3a'}),hound:(g,t,o)=>wolf(g,t,o,{col:'#cfc8b0',hi:'#efe8d0',eye:'#7fffd0'}),hellhound:(g,t,o)=>wolf(g,t,o,{col:'#3a1210',hi:'#c8402a',eye:'#ffcf3a'}),lynx:(g,t,o)=>wolf(g,t,o,{col:'#e0e8f0',hi:'#ffffff',eye:'#7fd8ff'}),
banshee:ghost,eel:snake,
weaver:(g,t,o)=>spid(g,t,o,{col:'#1a2a3a',hi:'#4a8aa8',s:1.05,eye:'#7fe8ff',aura:'#7fe8ff'}),mite:(g,t,o)=>spid(g,t,o,{col:'#b0902a',hi:'#e8d060',s:.62,eye:'#ff3a3a'}),brood:(g,t,o)=>spid(g,t,o,{col:'#3a1a2a',hi:'#8a3a5a',s:1.35,eye:'#ff5a8a'}),
garg:(g,t,o)=>bat(g,t,o,{col:'#6a6a78'}),harpy:(g,t,o)=>bat(g,t,o,{col:'#9ac8e8',aura:'#bfe8ff'})});
for(const k in NM2)MON[k].d=DR[k];
/* zone rosters by role: [walkers, divers, tanks] */
const ZR=[[['gob','shaman','mush'],['bat','warg'],['troll','ent']],
 [['skel','necro','zomb'],['ghost','banshee','hound'],['zomb','dknight']],
 [['snake','weaver','mite'],['spid','mite'],['scor','brood','cgolem']],
 [['imp','cultist','bomber'],['flame','hellhound','garg'],['brute','lavagol']],
 [['fsk','fwitch','fsk'],['wolf','harpy','lynx'],['yeti','igol']],
 [['crab','siren','drown'],['fish','jelly','eel'],['octo','drown']]];
