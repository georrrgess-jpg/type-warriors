/* ===== 94c_fix_menus.js: menu behaviour fixes for update 8.7 (stream "menus") =====
   Everything here wraps or overrides an earlier function; nothing is edited in place except the small source edits listed with each item.
   B7   dkRefreshBadges(): dock badges, sub-tab badges, bell count and the calendar "!" are re-rendered in place (at most once a frame)
        from a save() wrapper and after shop purchases and crate opens.
   B8   Settings keeps its scroll position (and the focused option) when an option is clicked and the page re-renders.
   B9   Bell: Esc closes it and returns focus to the bell, focus moves into the popover on open, the count refreshes after the updates
        are read, "Clear" really clears (the Runestone Riddle alert used to come back), and a brand-new save starts with the old updates
        marked as read (adds no notice).
   B10  The legacy corner buttons (#cn: Casino, Music, Fullscreen) are hidden on every menu screen; gameplay and game over keep them.
   B11  A timer that was set on a pet screen can no longer open a pet screen after you pressed Back.
   B12  Empty stats read "No record yet" in the body font (source edits in 60_ui.js, 84i_beginner.js, 84e_gy_ui.js; prestige label here).
   B13  Performance mode rests infinite CSS animations in their natural pose instead of freezing them mid-squash.
   B14  Codes used on this browser survive "Reset save" (localStorage twCodesUsed87, merged with the save's own list).
   D6   "Reset save" moved from the Profile header to Settings > Data (two clicks, a backup is kept). */
const MFM={bt:0,bt2:0,tok:0};
const mfxRM=()=>{try{return matchMedia('(prefers-reduced-motion: reduce)').matches}catch(e){return false}};
/* a counter that moves on every screen change; timers compare against it */
{const s0=show;show=function(){MFM.tok++;return s0.apply(this,arguments)}}

/* ---------- B7: badges refreshed in place ---------- */
function mfxSetBdg(host,v){if(!host)return;let i=null;for(const c of host.children)if(c.classList&&c.classList.contains('bdg')){i=c;break}
 const s=(v===''||v==null||v===0||v===false)?'':String(v);
 if(!s){if(i)i.remove();return}
 if(i&&i.textContent===s)return;
 const fresh=!i;if(!i){i=document.createElement('i');i.className='bdg';host.appendChild(i)}i.textContent=s;
 if(!mfxRM()&&i.animate)try{i.animate([{transform:'scale(.4)'},{transform:'scale(1.25)',offset:.6},{transform:'scale(1)'}],{duration:fresh?340:260,easing:'cubic-bezier(.3,1.5,.5,1)'})}catch(e){}}
/* the bell: badge, ring, label and the popover's own tab counts */
function mfxBellCount(){const b=$('bell');if(!b)return;
 let al=[];try{al=dkAlerts()}catch(e){}
 BELL_AL=al;const un=updUnread(),n=al.length+un,p=$('bellp'),open=!!(p&&p.classList.contains('open'));
 const old=b.querySelector(':scope>.bdg'),prev=old?(parseInt(old.textContent)||0):0,had=b.classList.contains('ring');
 if(p&&!open&&window.__bellAct){try{bellRender(window.__bellAct)}catch(e){}}
 else if(p&&open){const chip=(sel,v)=>{const t=p.querySelector(sel);if(!t)return;let i=t.querySelector(':scope>i');if(v){if(!i){i=document.createElement('i');t.appendChild(i)}i.textContent=v}else if(i)i.remove()};
  chip('[data-bt="a"]',al.length);chip('[data-bt="u"]',un);const c=p.querySelector('#blclr');if(c)c.disabled=!(al.length||un)}
 mfxSetBdg(b,n||'');b.classList.toggle('ring',n>0&&!open&&(had||n>prev));
 b.setAttribute('aria-label','Notifications'+(n?` (${n} new)`:''))}
function mfxBadgesNow(){if(!ov||ov.classList.contains('hide'))return;
 ov.querySelectorAll('.dki[data-dk]').forEach(b=>mfxSetBdg(b,dkBadge(b.dataset.dk)));
 ov.querySelectorAll('.dkst[data-dks]').forEach(b=>{const k=b.dataset.dks;let v='';try{v=k==='cr'?dkCrates():k==='bb'?btyReady():k==='ut'?(spNote()>0?spNote():''):''}catch(e){}mfxSetBdg(b,v)});
 const cal=$('dkcal');if(cal){let v='';try{v=dailyReady()?'!':''}catch(e){}mfxSetBdg(cal,v)}
 const mp=$('dkmp');if(mp){let v='';try{v=P.petSt===1||P.petPend?'!':(petEggsN()||'')}catch(e){}mfxSetBdg(mp,v)}
 const mg=$('dkmg');if(mg){let v='';try{v=newPaths().length?'!':''}catch(e){}mfxSetBdg(mg,v)}
 const np=$('np');if(np){let v='';try{v=canPres()?'!':''}catch(e){}mfxSetBdg(np,v)}
 mfxBellCount()}
/* debounced: at most one refresh per animation frame (a timer backs it up when frames are paused) */
function dkRefreshBadges(){if(MFM.bt||!$('bell'))return;
 const run=()=>{if(!MFM.bt)return;cancelAnimationFrame(MFM.bt);clearTimeout(MFM.bt2);MFM.bt=0;MFM.bt2=0;try{mfxBadgesNow()}catch(e){console.error(e)}};
 MFM.bt=requestAnimationFrame(run);MFM.bt2=setTimeout(run,160)}
{const sv0=save;save=function(){const r=sv0.apply(this,arguments);try{dkRefreshBadges()}catch(e){}return r}}
{const b0=shBuy;shBuy=function(){const r=b0.apply(this,arguments);try{dkRefreshBadges()}catch(e){}return r}}
{const c0=crateStart;crateStart=function(){const r=c0.apply(this,arguments);try{dkRefreshBadges()}catch(e){}return r}}
{const c0=crateBatch;crateBatch=function(){const r=c0.apply(this,arguments);try{dkRefreshBadges()}catch(e){}return r}}

/* ---------- B8: Settings keeps its scroll position and focus across a re-render ---------- */
/* an option click may change the layout (touch controls, display size) before the page is rebuilt, so the position is taken when the click starts */
const MFS={top:0,at:-1e9};
ov.addEventListener('click',e=>{try{if(e.target.closest&&e.target.closest('.opts')){MFS.top=ov.scrollTop;MFS.at=performance.now()}}catch(x){}},true);
{const s0=settings;settings=function(back){
  let keep=null;
  try{const box=ov.querySelector('.opts'),h=ov.querySelector('h2');if(box&&h&&/^\s*Settings\b/.test(h.textContent)&&!ov.classList.contains('hide')){const ae=document.activeElement;let sel='';
   if(ae&&box.contains(ae))sel=ae.dataset&&ae.dataset.k!=null?`[data-k="${ae.dataset.k}"][data-v="${ae.dataset.v}"]`:ae.id?'#'+ae.id:'';
   keep={top:performance.now()-MFS.at<400?MFS.top:ov.scrollTop,sel}}}catch(e){}
  const r=s0.apply(this,arguments);
  if(keep){try{ov.scrollTop=keep.top;if(keep.sel){const el=ov.querySelector(keep.sel);if(el&&el.offsetParent)el.focus({preventScroll:true})}}catch(e){}}
  return r}}

/* ---------- B14: codes already used on this browser survive "Reset save" ---------- */
const MFCU='twCodesUsed87';
function mfxCuLoad(){try{const o=JSON.parse(localStorage.getItem(MFCU)||'{}');return o&&typeof o==='object'&&!Array.isArray(o)?o:{}}catch(e){return{}}}
/* the codes this browser has used: what is stored plus the open save's own list (also written back, so an older save's codes are kept too) */
function mfxCuAll(){const o=Object.assign({},mfxCuLoad());
 try{if(P&&P.ccUsed&&typeof P.ccUsed==='object')for(const k of Object.keys(P.ccUsed))if(P.ccUsed[k])o[k]=1}catch(e){}
 try{if(Object.keys(o).length)localStorage.setItem(MFCU,JSON.stringify(o))}catch(e){}return o}
{const g0=ccGrant;ccGrant=function(c,k){const r=g0.apply(this,arguments);try{if(r&&r.ok)mfxCuAll()}catch(e){}return r}}
/* the developer tool that gives a code back to this save also lets the stored list forget it */
{const d0=ccDevAct;ccDevAct=async function(a,k){const r=await d0.apply(this,arguments);try{if(a==='rs'){const nk=ccNorm(k);if(!(P.ccUsed&&P.ccUsed[nk])){const o=mfxCuLoad();if(o[nk]){delete o[nk];localStorage.setItem(MFCU,JSON.stringify(o))}}}}catch(e){}return r}}
try{mfxCuAll()}catch(e){}

/* ---------- B9: a brand-new save starts with every existing update marked as read ---------- */
function mfxFreshUpd(){try{if(!P||typeof P!=='object')return;const u=P.upd;if(u&&Array.isArray(u.seen)&&u.seen.length)return;
 if(!sgTrivial())return;const U=UPD(),ids=[];for(const e of[...UPDATES,...U.feed,...U.mine])if(updOk(e)&&ids.indexOf(e.id)<0)ids.push(e.id);
 if(ids.length)U.seen=ids.slice(-300)}catch(e){}}
{const l0=load;load=function(){const r=l0.apply(this,arguments);try{mfxFreshUpd()}catch(e){}return r}}
mfxFreshUpd();

/* ---------- D6: Reset save lives in Settings > Data ---------- */
function mfxResetSave(t){
 if(t.dataset.a){const keep=mfxCuAll();try{sgSnap('Before erase','safe');sgMuteOffer();load({});P.ccUsed=Object.assign({},keep);save();title()}catch(e){console.error(e)}return}
 t.dataset.a=1;t.textContent='Click again to erase. A backup is kept.';
 setTimeout(()=>{if(t.isConnected){t.dataset.a='';t.textContent='Reset save'}},3000)}
SETG.Data.push('Reset save');
{const st0=settingsTabs;settingsTabs=function(){
  try{const box=ov.querySelector('.opts');if(box&&!box.querySelector('#mfxrs')){const inRun=S.mode==='pause';
   const d=document.createElement('div');d.className='opt';d.id='mfxrs';
   d.innerHTML=`<div><label>Reset save</label><small>${inRun?'Open Settings from the main menu to reset your save.':'Erase this hero and start again. A backup is kept in the Save Center.'}</small></div><button class="sm dg" id="mfxrsb"${inRun?' disabled':''}>Reset save</button>`;
   const sv=[...box.querySelectorAll(':scope>.opt')].find(o=>(o.querySelector('label')||{}).textContent==='Save and backups');if(sv)sv.after(d);else box.appendChild(d);
   d.querySelector('#mfxrsb').onclick=e=>mfxResetSave(e.currentTarget)}}catch(e){}
  const r=st0.apply(this,arguments);
  try{const d=ov.querySelector('#mfxrs'),box=d&&d.parentNode;if(box&&box.lastElementChild!==d)box.appendChild(d)}catch(e){}
  return r}}

/* ---------- B9: the bell ---------- */
/* a dismissed alert stays dismissed: the Runestone Riddle alert is added after the usual filter, so filter once more */
{const a0=alertList;alertList=function(){return updFilter(a0.apply(this,arguments))}}
/* the popover fades in from visibility:hidden, and a hidden element cannot take focus yet, so keep trying for a moment.
   When it opens on the Updates tab (no alerts, some unread), showing them counts as reading them, as clicking the tab already does. */
function mfxBellFocus(p){let n=0;const go=()=>{const t=p.querySelector('.bltabs button.on')||p.querySelector('button');if(t)try{t.focus({preventScroll:true})}catch(x){}};
 const iv=setInterval(()=>{if(!p.classList.contains('open')||p.contains(document.activeElement)||++n>16){clearInterval(iv);return}go()},40);go()}
function mfxBellClose(toBell){const p=$('bellp'),b=$('bell');if(!p||!b)return;p.classList.remove('open');b.setAttribute('aria-expanded','false');if(toBell)try{b.focus({preventScroll:true})}catch(x){}}
{const b0=bellBind;bellBind=function(){const r=b0.apply(this,arguments);
  try{const b=$('bell'),p=$('bellp'),orig=b&&b.onclick;if(b&&p&&orig)b.onclick=function(e){const was=p.classList.contains('open');const x=orig.call(this,e);if(!was&&p.classList.contains('open')){mfxBellFocus(p);try{if(BELL_TAB==='u'&&updUnread())updMarkRead()}catch(_){}}return x}}catch(e){}
  return r}}
window.addEventListener('keydown',e=>{if(e.key!=='Escape'||e.defaultPrevented)return;const p=document.getElementById('bellp');if(!p||!p.classList.contains('open'))return;
 const t=e.target;if(t&&/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName)&&p.contains(t))return;if(document.querySelector('.dks,#ccm,.sgm,#svm'))return;
 e.preventDefault();e.stopImmediatePropagation();mfxBellClose(true)},true);
/* "Clear" sets the alerts aside for today and then shows exactly what is left, never a stale empty list */
{const w0=bellWire;bellWire=function(p,act){const r=w0.apply(this,arguments);
  try{const c=p.querySelector('#blclr');if(c)c.onclick=e=>{e.stopPropagation();updClear(BELL_AL);let al=[];try{al=dkAlerts()}catch(x){}BELL_AL=al;BELL_MSG='';
    bellRender(act);try{beep(520,.05,'triangle',.4)}catch(x){}
    if(al.length){const bd=p.querySelector('.blbody');if(bd)bd.insertAdjacentHTML('afterbegin',`<p class="blm">${al.length} action${al.length>1?'s':''} left. Open ${al.length>1?'them':'it'} to finish.</p>`)}
    dkRefreshBadges()}}catch(e){}
  return r}}

/* ---------- B10: no legacy corner buttons on menu screens ---------- */
{const c0=dkCorner;dkCorner=function(){const r=c0.apply(this,arguments);try{mfxCorner()}catch(e){}return r}}
function mfxCorner(){const c=$('cn');if(!c)return;
 const menu=!ov.classList.contains('hide')&&S.mode==='title';
 /* a casino table is play, so Music and Fullscreen stay there; the Casino button itself makes no sense inside the casino */
 const table=menu&&typeof CAS!=='undefined'&&CAS.on&&ov.classList.contains('casbg')&&!ov.classList.contains('gdo');
 c.classList.toggle('mfxhid',menu&&!table);const z=$('cz');if(z)z.classList.toggle('mfxhid',!!table)}
try{mfxCorner()}catch(e){}

/* ---------- B11: no pet screen from a timer that outlived its screen ---------- */
const MFT={late:0};
/* run fn; every timer it sets remembers the screen it was set on, and while such a timer runs after the screen changed, pet screens stay shut */
function mfxScoped(fn,self,args){const st0=window.setTimeout;
 window.setTimeout=function(f,ms){if(typeof f!=='function')return st0.apply(window,arguments);const tok=MFM.tok,rest=Array.prototype.slice.call(arguments,2);
  return st0.call(window,function(){const was=MFT.late;MFT.late=(MFM.tok!==tok||ov.classList.contains('hide'))?1:0;try{return f.apply(this,rest)}finally{MFT.late=was}},ms)};
 try{return fn.apply(self,args)}finally{window.setTimeout=st0}}
{const h0=petHall;petHall=function(){if(MFT.late)return;return h0.apply(this,arguments)}}
{const c0=ptCustom;ptCustom=function(){if(MFT.late)return;const r=c0.apply(this,arguments);mfxRewrap('ptcs');mfxRewrap('patsave');return r}}
{const b0=ptBuyModal;ptBuyModal=function(){const r=b0.apply(this,arguments);mfxRewrap('ptby');return r}}
{const c0=ptConvertModal;ptConvertModal=function(){const r=c0.apply(this,arguments);mfxRewrap('ptcy');return r}}
{const f0=petFromStyle;petFromStyle=function(){return mfxScoped(f0,this,arguments)}}
function mfxRewrap(id){const b=document.getElementById(id);if(b&&typeof b.onclick==='function'&&!b._fxs){const h=b.onclick;b._fxs=1;b.onclick=function(){return mfxScoped(h,this,arguments)}}}

/* ---------- B12: empty stats in the body font ---------- */
{const p0=presBlock;presBlock=function(){let h=p0.apply(this,arguments);try{h=h.replace(/Prestige none yet/,'<span class="nrec">No prestige yet</span>')}catch(e){}return h}}

/* ---------- B13: Performance mode rests looping animations in their natural pose ---------- */
/* paused first, then set to the start of the cycle (a negative delay starts before the cycle, so it goes to the delay): the hold is exact and nothing is left mid-squash */
function mfxRest(a){try{const d=+a.effect.getTiming().delay||0;a.currentTime=d<0?d:0}catch(e){try{a.currentTime=0}catch(x){}}}
function pfAnims(){try{if(PFM()!=='low'){for(const a of PFA.paused)try{a.play()}catch(e){}PFA.paused.clear();return}
 for(const a of document.getAnimations())if(a.playState==='running'&&a.effect&&a.effect.getTiming().iterations===Infinity&&a.constructor&&a.constructor.name==='CSSAnimation'){a.pause();mfxRest(a);PFA.paused.add(a)}
 for(const a of PFA.paused)if(!a.effect||!a.effect.target||!a.effect.target.isConnected)PFA.paused.delete(a)}catch(e){}}

{const st=document.createElement('style');st.textContent=`
#cn.mfxhid,#cz.mfxhid{display:none!important}
#ov .nrec,.nrec{font:600 15px/1.25 var(--ui);font-style:normal;letter-spacing:0;color:#b9b3d6;opacity:1;text-shadow:none;text-transform:none;white-space:nowrap}
#ov .pres .nrec{font-size:17px;color:#cfc6f2}
#mfxrs.opt small{font-family:var(--ui);font-size:13px}
#mfxrs button.dg[disabled]{opacity:.45;cursor:default}
`;document.head.appendChild(st)}
