/* ---------- save safety: guarded storage, validation, rolling backups, export and import ----------
   Everything the game keeps lives in one browser store. This layer makes sure a bad write, a damaged save,
   a second open tab or a wrong import can never silently destroy progress. */
const SGV=2,SGP='TWSAVE2:',BKP='typeWarriorsBk.',META_K='typeWarriorsMeta',DMG_K='typeWarriorsSave.damaged';
const SGS={armed:false,mem:false,fail:0,err:'',saved:0,stale:false,lock:false,last:'',lastSum:'',lastAuto:0,errs:0,notes:[],offer:null,restored:0};
const SGM=new Map(),SG_BAD=new Set(['__proto__','constructor','prototype']);
let SGMT=null;

/* ----- guarded storage: every call is safe, a failed write falls back to memory ----- */
function sgProbe(){try{const k='typeWarriorsProbe';localStorage.setItem(k,'1');const ok=localStorage.getItem(k)==='1';localStorage.removeItem(k);SGS.mem=!ok}catch(e){SGS.mem=true;SGS.err=String(e&&e.name||e)}}
function sgGet(k){if(SGM.has(k))return SGM.get(k);if(SGS.mem)return null;try{return localStorage.getItem(k)}catch(e){return null}}
function sgDel(k){SGM.delete(k);if(!SGS.mem){try{localStorage.removeItem(k)}catch(e){}}}
function sgKeys(pre){const o=new Set();if(!SGS.mem){try{for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k&&k.indexOf(pre)===0)o.add(k)}}catch(e){}}for(const k of SGM.keys())if(k.indexOf(pre)===0)o.add(k);return[...o]}
/* true only when the value is really in browser storage */
function sgPut(k,v){if(!SGS.mem){for(let i=0;i<40;i++){try{localStorage.setItem(k,v);SGM.delete(k);return true}catch(e){SGS.err=String(e&&e.name||e);if(!sgFree(k))break}}}SGM.set(k,v);return false}
/* storage is full: let go of the least valuable thing, never the best backup */
function sgFree(k){const dm=sgGet(DMG_K);if(dm!==null&&k!==DMG_K){sgDel(DMG_K);return true}
 const l=sgList().filter(r=>k!==BKP+r.id),pk=sgPeak(l),order=['auto','manual','safe'];
 for(const kind of order){const g=l.filter(r=>r.kind===kind&&r!==pk).reverse();if(g.length&&(kind!=='safe'||g.length>1)){sgDel(BKP+g[0].id);return true}}
 const bad=l.find(r=>!r.ok);if(bad){sgDel(BKP+bad.id);return true}return false}

/* ----- small helpers ----- */
function sgHash(s){let h1=0xdeadbeef,h2=0x41c6ce57;for(let i=0;i<s.length;i++){const c=s.charCodeAt(i);h1=Math.imul(h1^c,2654435761);h2=Math.imul(h2^c,1597334677)}
 h1=Math.imul(h1^(h1>>>16),2246822507)^Math.imul(h2^(h2>>>13),3266489909);h2=Math.imul(h2^(h2>>>16),2246822507)^Math.imul(h1^(h1>>>13),3266489909);
 return(4294967296*(2097151&h2)+(h1>>>0)).toString(16).padStart(14,'0')+'.'+s.length.toString(16)}
function sgB64(s){const b=new TextEncoder().encode(s);let o='';for(let i=0;i<b.length;i+=8192)o+=String.fromCharCode.apply(null,b.subarray(i,i+8192));return btoa(o)}
function sgUnb64(t){const bin=atob(t),b=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)b[i]=bin.charCodeAt(i);return new TextDecoder('utf-8',{fatal:true}).decode(b)}
function sgClean(v,d){if(d>14)return null;if(Array.isArray(v))return v.slice(0,20000).map(x=>sgClean(x,d+1));
 if(v&&typeof v==='object'){const o={};for(const k of Object.keys(v)){if(SG_BAD.has(k))continue;o[k]=sgClean(v[k],d+1)}return o}
 if(typeof v==='number'&&!isFinite(v))return 0;return v}
/* make every known field the right type so the rest of the game can trust it */
function sgShape(o){const f=fresh(),out=Object.assign({},o);
 for(const k of Object.keys(f)){const t=typeof f[k],g=out[k];if(g===undefined||g===null||typeof g!==t||(t==='object'&&Array.isArray(g)))out[k]=f[k]}
 out.xp=Math.max(0,Math.floor(out.xp)||0);out.camp=Math.max(1,Math.min(30,Math.floor(out.camp)||1));
 for(const k of ['gold','scr','crates','acr','pcr','hcr','ccr','hpity','ug','us','spb','pity','runs','kills'])out[k]=Math.max(0,Math.floor(+out[k]||0));
 out.name=String(out.name||'Hero').slice(0,24);
 for(const k of ['wxp','ks','pb'])if(out[k]!==undefined&&(typeof out[k]!=='object'||out[k]===null||Array.isArray(out[k])))out[k]={};
 return out}
const sgProg=p=>{try{let st=0;for(const k in(p.stars||{}))st+=+p.stars[k]||0;return Math.round((+p.xp||0)+(p.pres|0)*1e6+(Object.keys(p.own||{}).length+Object.keys(p.ownA||{}).length)*150+st*300+(+p.camp||0)*400+Object.keys(p.ach||{}).length*200)}catch(e){return 0}};
function sgInfo(p){let st=0,cl=0;for(const k in(p.stars||{})){cl++;st+=+p.stars[k]||0}
 return{name:String(p.name||'Hero').slice(0,24),lvl:lvl(+p.xp||0),pres:p.pres|0,gold:Math.round(+p.gold||0),camp:Math.min(30,+p.camp||1),cl,st,w:Object.keys(p.own||{}).length,a:Object.keys(p.ownA||{}).length,t:Object.keys(p.ach||{}).length,runs:+p.runs||0,prog:sgProg(p)}}
const sgTrivial=()=>!P||(!P.runs&&(P.xp||0)<60&&!Object.keys(P.stars||{}).length);

/* ----- reading a save from anything: main store, a backup record, a file, a pasted code ----- */
function sgRead(txt,lenient){const bad=c=>({ok:false,code:c});
 try{if(typeof txt!=='string')return bad('empty');let s=txt.replace(/^﻿/,'').trim();if(!s)return bad('empty');if(s.length>12e6)return bad('big');
  let m=s.match(/^TWSAVE(\d+):/);
  if(m){if(+m[1]>SGV)return bad('newer');try{s=sgUnb64(s.slice(m[0].length).replace(/\s+/g,''))}catch(e){return bad('code')}}
  let o;try{o=JSON.parse(s)}catch(e){return bad(m?'code':'json')}
  let verified=false,exported=0,legacy=false;
  if(o&&typeof o==='object'&&typeof o.payload==='string'&&typeof o.game==='string'){
   if(!(+o.format<=SGV))return bad('newer');if(sgHash(o.payload)!==o.sum)return bad('damaged');
   exported=Date.parse(o.exported)||0;verified=true;try{o=JSON.parse(o.payload)}catch(e){return bad('damaged')}}
  else legacy=true;
  if(!o||typeof o!=='object'||Array.isArray(o))return bad('notsave');
  if(!lenient&&(typeof o.xp!=='number'||!isFinite(o.xp)||!o.own||typeof o.own!=='object'||!o.ownA||typeof o.ownA!=='object'))return bad('notsave');
  o=sgShape(sgClean(o,0));return{ok:true,P:o,verified,legacy,exported}}
 catch(e){return bad('json')}}
const SGMSG={empty:'Nothing was found to import.',big:'That file is far too large to be a Type Warriors save.',newer:'That save was made by a newer version of the game. Update the game first, then import it.',code:'That save code is incomplete or damaged. Copy the whole code again.',json:'That is not a Type Warriors save.',notsave:'That is not a Type Warriors save.',damaged:'That save file is damaged or was edited, so it was not imported. Your current progress is untouched.'};

/* ----- exporting ----- */
function sgPack(){const payload=JSON.stringify(P);return{game:'Type Warriors',format:SGV,exported:new Date().toISOString(),summary:sgInfo(P),sum:sgHash(payload),payload}}
const sgFileText=()=>JSON.stringify(sgPack(),null,1);
const sgCode=()=>SGP+sgB64(JSON.stringify(sgPack()));
function sgFileName(p,t){p=p||P;const d=new Date(t||Date.now()),z=n=>String(n).padStart(2,'0'),nm=String(p.name||'hero').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,16)||'hero';
 return `type-warriors-${nm}-lv${lvl(+p.xp||0)}${(p.pres|0)?'-p'+(p.pres|0):''}-${d.getFullYear()}-${z(d.getMonth()+1)}-${z(d.getDate())}-${z(d.getHours())}${z(d.getMinutes())}.json`}

/* ----- meta: small facts about backups, kept apart from the save ----- */
function sgMeta(){if(!SGMT){try{SGMT=JSON.parse(sgGet(META_K)||'{}')}catch(e){SGMT={}}if(!SGMT||typeof SGMT!=='object'||Array.isArray(SGMT))SGMT={}}return SGMT}
const sgMetaSave=()=>{sgPut(META_K,JSON.stringify(sgMeta()))};
function sgMarkExport(){const m=sgMeta();m.lastExport=Date.now();m.expProg=sgProg(P);m.expSum=sgHash(JSON.stringify(P));m.remind=0;sgMetaSave()}
function sgExportDue(){if(sgTrivial())return false;const m=sgMeta(),pr=sgProg(P),dp=pr-(m.expProg||0),days=(Date.now()-(m.lastExport||0))/864e5;
 if(m.remind&&Date.now()<m.remind)return false;
 return !m.lastExport?pr>=1500:(days>=10&&dp>=800)||(days>=2&&dp>=6000)}
function sgSnooze(){const m=sgMeta();m.remind=Date.now()+3*864e5;sgMetaSave()}

/* ----- rolling backups: kept in the browser, newest first ----- */
function sgRec(id){const raw=sgGet(BKP+id);if(!raw)return null;
 try{const r=JSON.parse(raw);if(!r||r.tw!==2||typeof r.data!=='string'||!r.info)throw 0;r.id=id;r.ok=sgHash(r.data)===r.sum;r.size=raw.length;return r}
 catch(e){return{id,ok:false,t:0,kind:'auto',why:'Damaged backup',info:null,size:raw.length}}}
const sgList=()=>sgKeys(BKP).map(k=>sgRec(k.slice(BKP.length))).filter(Boolean).sort((a,b)=>(b.t||0)-(a.t||0));
function sgPeak(l){let p=null;for(const r of(l||sgList()))if(r.ok&&r.info&&(!p||r.info.prog>p.info.prog))p=r;return p}
function sgPrune(){const l=sgList(),pk=sgPeak(l),lim={auto:5,safe:4,manual:6};
 for(const k in lim)for(const r of l.filter(r=>r.kind===k&&r.ok&&r!==pk).slice(lim[k]))sgDel(BKP+r.id);
 for(const r of l.filter(r=>!r.ok))sgDel(BKP+r.id)}
/* stores `data` (a save as JSON text) as a backup and returns the backup's id, or null if it could not be kept */
function sgSnapStr(data,why,kind){try{
 const sum=sgHash(data),l=sgList(),same=l.find(r=>r.ok&&r.sum===sum&&(kind==='auto'||r.kind===kind));if(same)return same.id;
 const rd=sgRead(data,1);if(!rd.ok)return null;
 const rec={tw:2,t:Date.now(),why,kind,sum,info:sgInfo(rd.P),data},id=Date.now().toString(36)+Math.random().toString(36).slice(2,5);
 sgPut(BKP+id,JSON.stringify(rec));sgPrune();return sgGet(BKP+id)!==null?id:null}catch(e){return null}}
function sgSnap(why,kind){if(!P)return null;try{const d=JSON.stringify(P),s=sgHash(d);if(kind==='auto'&&s===SGS.lastSum)return null;const id=sgSnapStr(d,why,kind||'auto');if(id){SGS.lastSum=s;SGS.lastAuto=Date.now()}return id}catch(e){return null}}
function sgDelete(id){sgDel(BKP+id)}

/* ----- starting up: pick the save to use, repair what can be repaired ----- */
function sgLoad(){sgProbe();let p=null;const m=sgMeta();
 /* a risky import that failed to start is undone */
 if(m.pending&&m.pending.bad){const r=m.pending.id&&sgRec(m.pending.id);if(r&&r.ok){const q=sgRead(r.data,1);if(q.ok){sgPut(KEY,JSON.stringify(q.P));SGS.notes.push('The save you imported caused a problem, so your previous progress was put back.')}}m.pending=null;sgMetaSave()}
 SGS.armed=!!(m.pending&&!m.pending.bad);
 const raw=sgGet(KEY);
 if(raw!==null){const r=sgRead(raw,1);if(r.ok)p=r.P;else{sgPut(DMG_K,raw);
  const b=sgList().find(x=>x.ok);if(b){const q=sgRead(b.data,1);if(q.ok){p=q.P;sgPut(KEY,JSON.stringify(p));SGS.restored=b.t;SGS.notes.push('Your save file was damaged, so the newest backup was restored.')}}
  else SGS.notes.push('Your save file was damaged and no backup was found. A copy of the damaged data was kept.')}}
 if(p)SGS.last=JSON.stringify(p);return p||{}}
/* after the game is up: checks that need the rest of the game */
function sgBoot(){try{
 if(SGS.armed)setTimeout(()=>{const m=sgMeta();if(m.pending&&!m.pending.bad){m.pending=null;sgMetaSave()}},5000);
 if(!sgTrivial())sgSnap('Game opened','auto');SGS.lastAuto=Date.now();SGS.last=JSON.stringify(P);
 const pk=sgPeak(),m=sgMeta();SGS.offer=pk&&pk.info.prog>=1500&&sgProg(P)<pk.info.prog*.3&&m.mute!==pk.sum?pk:null}catch(e){}}
function sgMuteOffer(){const pk=sgPeak();if(pk){sgMeta().mute=pk.sum;sgMetaSave()}SGS.offer=null}

/* ----- replacing the save: back up first, write, check it landed, undo on any doubt ----- */
function sgInstall(np,why,risky){try{
 const prev=sgGet(KEY),bid=sgSnap('Before '+why,'safe')||(prev&&sgSnapStr(prev,'Before '+why,'safe'))||null;
 const s=JSON.stringify(np),stored=sgPut(KEY,s);
 if(!SGS.mem&&(!stored||sgGet(KEY)!==s)){if(prev!==null)sgPut(KEY,prev);else sgDel(KEY);return{ok:false,msg:'The browser would not store this save, so nothing was changed. Free some space or try another browser.'}}
 const m=sgMeta();m.pending=risky&&bid?{id:bid,t:Date.now()}:null;m.mute='';sgMetaSave();
 SGS.last=s;SGS.lastSum='';SGS.stale=false;SGS.offer=null;SGS.lock=!SGS.mem;return{ok:true,P:np,bid}}
 catch(e){return{ok:false,msg:'Something went wrong, so nothing was changed.'}}}
/* an error right after a risky import means that import goes back */
window.addEventListener('error',()=>{SGS.errs++;try{const m=SGMT;if(SGS.armed&&m&&m.pending&&!m.pending.bad&&performance.now()<6000){m.pending.bad=1;sgMetaSave();setTimeout(()=>location.reload(),300)}}catch(e){}});

/* ----- keeping things safe while playing ----- */
function sgTick(){if(Date.now()-SGS.lastAuto>480000&&!sgTrivial()){SGS.lastAuto=Date.now();sgSnap('Automatic','auto')}if(typeof sgChipUpd==='function')sgChipUpd()}
const sgMilestone=why=>{if(Date.now()-SGS.lastAuto>120000&&!sgTrivial())sgSnap(why,'auto')};
function sgFlush(){if(SGS.lock||SGS.stale||!P)return;try{const s=JSON.stringify(P);if(s!==SGS.last){SGS.last=s;sgPut(KEY,s)}if(Date.now()-SGS.lastAuto>90000&&!sgTrivial())sgSnap('Automatic','auto')}catch(e){}}
document.addEventListener('visibilitychange',()=>{if(document.hidden)sgFlush()});
window.addEventListener('pagehide',()=>{sgFlush();try{const m=SGMT;if(SGS.armed&&m&&m.pending&&!m.pending.bad){m.pending=null;sgMetaSave()}}catch(e){}});
/* another window saved: this one must not overwrite it by accident */
window.addEventListener('storage',e=>{try{if(e.storageArea!==localStorage||e.key!==KEY||e.newValue==null||e.newValue===SGS.last)return;SGS.stale=true;SGMT=null;if(typeof sgStaleUI==='function')sgStaleUI()}catch(x){}});
sgProbe();
