/* ===== 10.2b THE CROOKED CUE: ball sets you can read at a glance, and your group on show (97b5, prefix pzb2, after 97b4) =====
   The owner's rule for every ball set, old or new: solids are coloured all over, stripes show a clearly lighter area above and
   below a coloured band, the 8 is clearly the darkest ball with a high-contrast disc, the cue ball is white, numbers are readable.
   t_pzb102.py measures it per set (light-area fraction of stripes against solids, the 8's luminance against every other ball,
   disc and number contrast, cue-ball whiteness), so a new set that breaks it fails.
   - Ember Core redone: solids are molten through in their colour with white-hot veins and darker crust plates; stripes are pale
     bone-ash stone with a molten band and a glowing seam where the band meets the ash; the 8 is black obsidian with an ember seam
     and a bright bone disc ringed in fire. Number discs are obsidian with glowing numbers.
   - Starfall: solids are bright nebulae, stripes have pale stardust caps with an aurora edge, the 8 is a black hole with a
     violet event-horizon ring and a white disc. Neon Nights: solids glow through, stripes have frosted white caps with neon tube
     edges, the 8 is black glass with a white tube and a white disc. Champion Gold: solids are anodised colour, stripes polished
     platinum, the 8 black chrome with a gold seam and a gold disc. Moonstone: deeper pearl colours (the stripes now read), a
     black-pearl 8. Carrara Marble: slightly deeper colours, darker numbers, a black Nero Marquina 8 with white veins.
     Classic and Gemstone already followed the rule and paint exactly as before.
   The painter is the 96zb one (same atlas, conventions and per-pixel lighting) with the new materials; it replaces it whole. */
Object.assign(PZ_BPAL.moon,{col:{1:[244,196,64],2:[74,124,232],3:[232,78,112],4:[150,92,222],5:[246,138,62],6:[52,182,140],7:[176,62,92],8:[30,26,46]},
 white:[240,242,255],disc:[255,255,255],num:[50,58,140],disc8:[250,250,255],num8:[22,20,40]});
Object.assign(PZ_BPAL.marble,{col:{1:[236,194,72],2:[78,112,190],3:[198,78,78],4:[138,92,180],5:[228,138,70],6:[70,150,108],7:[140,66,62],8:[26,25,30]},num:[118,76,8],num8:[24,20,24],mk:.1});
Object.assign(PZ_BPAL.neon,{col:{1:[255,226,50],2:[50,160,255],3:[255,50,110],4:[186,80,255],5:[255,140,30],6:[40,240,150],7:[255,80,60],8:[10,9,18]},
 white:[244,244,255],cap:[222,228,246],disc:[22,18,34],num:[255,255,255],disc8:[240,242,255],num8:[14,12,24],ring8:[230,236,255],spec:1.3,win:.12,rim:.4});
Object.assign(PZ_BPAL.lava,{col:{1:[255,196,36],2:[56,140,255],3:[255,62,38],4:[196,80,255],5:[255,128,22],6:[64,236,104],7:[206,30,64],8:[14,10,14]},
 white:[244,236,224],cap:[238,228,210],disc:[30,20,18],num:[255,214,140],disc8:[252,232,196],num8:[24,14,10],ring8:[255,120,30],spec:1.1,win:.1,rim:.22});
Object.assign(PZ_BPAL.galaxy,{col:{1:[255,206,80],2:[70,124,255],3:[255,82,136],4:[168,100,255],5:[255,144,70],6:[64,224,196],7:[226,84,112],8:[6,5,14]},
 white:[240,242,255],cap:[224,226,244],disc:[232,234,248],num:[28,24,70],disc8:[244,244,255],num8:[14,10,36],ring8:[190,150,255],spec:1.3,win:.14,rim:.32});
Object.assign(PZ_BPAL.royal,{col:{1:[255,200,60],2:[70,130,255],3:[255,80,80],4:[176,100,255],5:[255,150,60],6:[60,210,130],7:[200,70,70],8:[30,28,36]},
 white:[248,244,232],cap:[250,246,236],disc:[255,248,226],num:[60,40,10],disc8:[255,220,130],num8:[20,14,6],ring8:[255,200,90],spec:1.6,win:.2,rim:.3});
/* a fast sine (parabolic, error under 0.001): the lava cracks and the galaxy nebula call it several times a pixel */
const pzb2Sin=x=>{x-=6.283185307*Math.floor(x*.159154943+.5);const y=1.27323954*x-.405284735*x*(x<0?-x:x);return .225*(y*(y<0?-y:y)-y)+y};
/* an integer hash for the galaxy's star cells (cheaper than the sine hash) */
const pzb2Hash=(x,y,z)=>{let h=(Math.imul(x,374761393)+Math.imul(y,668265263)+Math.imul(z,1274126177))|0;h=Math.imul(h^(h>>>13),1103515245);return ((h^(h>>>16))>>>0)/4294967296};
function pzbPaint(slot,n,M){const P=PZ_BS,pal=P.pal,K=pal.kind||'classic',d=P.img.data,stripe=n>8,is8=n===8,cue=n===0,C=cue?pal.white:pal.col[stripe?n-8:n],W=pal.white,CP=pal.cap||W,
 DS=(is8&&pal.disc8)||pal.disc,NM=(is8&&pal.num8)||pal.num,R8=is8?(pal.ring8||null):null,RB=R8||[240,240,255],gl=n>0?P.gm[n]:null,
 m0=M[0],m1=M[1],m2=M[2],m3=M[3],m4=M[4],m5=M[5],m6=M[6],m7=M[7],m8=M[8],sk=pal.spec,wk=pal.win,rk=pal.rim||.25,mk=pal.mk==null?.18:pal.mk;
 if(!P.rimA||P.rimA.length!==P.n){P.rimA=new Float32Array(P.n);for(let j=0;j<P.n;j++)P.rimA[j]=Math.pow(1-P.nz[j],2.6)}const RA=P.rimA;
 /* hot vein colour (same hue, brighter) and the stripe seam colour */
 const hr=Math.min(255,C[0]*1.2+70),hg=Math.min(255,C[1]*1.2+52),hb=Math.min(255,C[2]*1.2+24);
 for(let j=0;j<P.n;j++){const wx=P.nx[j],wy=P.ny[j],wz=P.nz[j];
  const lx=m0*wx+m3*wy+m6*wz,ly=m1*wx+m4*wy+m7*wz,lz=m2*wx+m5*wy+m8*wz,ay=ly<0?-ly:ly;
  /* band: 1 inside the coloured part (whole ball for solids), 0 on the light caps of a stripe; edge: 1 on the band's border */
  let band=1,edge=0;if(stripe){band=1-Math.max(0,Math.min(1,(ay-.56)/.035+.5));const de=ay-.56;edge=Math.max(0,1-(de<0?-de:de)/.05)}
  let r,g,b,er=0,eg=0,eb=0,lit=1,metal=0;
  if(cue){r=W[0];g=W[1];b=W[2]}
  else if(K==='marble'){const v=Math.sin(lx*3.1+ly*1.2+3.4*Math.sin(ly*2.7+lz*1.9+1.3*Math.sin(lx*5.1))+2.3*Math.sin(lz*4.1-lx*2.3)),v1=1-Math.abs(v),v2=v1*v1,v4=v2*v2,vm=v4*v4*v1*.55,cl=.93+.07*Math.sin(ly*7+lz*3+lx*2);
   if(is8){const w=Math.min(1,vm*1.5);r=(C[0]+(214-C[0])*w)*cl;g=(C[1]+(212-C[1])*w)*cl;b=(C[2]+(220-C[2])*w)*cl}
   else{const br=C[0]+(W[0]-C[0])*mk,bg=C[1]+(W[1]-C[1])*mk,bb=C[2]+(W[2]-C[2])*mk;r=(W[0]+(br-W[0])*band)*cl;g=(W[1]+(bg-W[1])*band)*cl;b=(W[2]+(bb-W[2])*band)*cl;const vr=band?.45:.62;r*=1-vm*(1-vr);g*=1-vm*(1-vr);b*=1-vm*(1-vr)}}
  else if(K==='gem'){const fx=Math.round(lx*2.6),fy=Math.round(ly*2.6),fz=Math.round(lz*2.6),h=pzbH(fx,fy,fz),k=.72+.5*h;r=(W[0]+(C[0]-W[0])*band)*k;g=(W[1]+(C[1]-W[1])*band)*k;b=(W[2]+(C[2]-W[2])*band)*k;
   const ins=wz*wz*.3*band;er=C[0]*ins;eg=C[1]*ins;eb=C[2]*ins;if(h>.86&&P.spe[j]<.2){const s=(h-.86)*6*Math.max(0,wz);er+=255*s*.5;eg+=255*s*.5;eb+=255*s*.5}}
  else if(K==='pearl'){const a=6*lx+4*ly+(1-wz)*5,ir=((1-wz)*.6+.25)*(is8?30:band?30:40);r=W[0]+(C[0]-W[0])*band+ir*Math.sin(a);g=W[1]+(C[1]-W[1])*band+ir*Math.sin(a+2.1);b=W[2]+(C[2]-W[2])*band+ir*Math.sin(a+4.2)}
  else if(K==='neon'){const cu=wz*wz;
   if(is8){r=C[0];g=C[1];b=C[2];const s=Math.max(0,1-ay/.05),e=s*s;er=RB[0]*e;eg=RB[1]*e;eb=RB[2]*e;const rm=RA[j]*.3;er+=150*rm;eg+=150*rm;eb+=190*rm}
   else{/* coloured glass lit from inside; stripes: frosted white caps and a neon tube on each edge of the band */
    const gk=.42+.5*cu;r=CP[0]+(C[0]*.22-CP[0])*band;g=CP[1]+(C[1]*.22-CP[1])*band;b=CP[2]+(C[2]*.22-CP[2])*band;const fr=(1-band)*.12;er=C[0]*gk*band+CP[0]*fr;eg=C[1]*gk*band+CP[1]*fr;eb=C[2]*gk*band+CP[2]*fr;
    const rm=RA[j]*.6*band;er+=C[0]*rm;eg+=C[1]*rm;eb+=C[2]*rm;if(edge){const e=edge*edge;er+=(C[0]*.7+110)*e;eg+=(C[1]*.7+110)*e;eb+=(C[2]*.7+110)*e}}}
  else if(K==='lava'){const c=Math.abs(pzb2Sin(lx*6.1+pzb2Sin(ly*3.7)*2)*pzb2Sin(ly*5.3+pzb2Sin(lz*4.1)*2)*pzb2Sin(lz*5.9+pzb2Sin(lx*3.3)*2)),cr=c<.13?1-c/.13:0,c2=cr*cr;
   if(is8){/* black obsidian, an ember seam round the middle and faint embers in its cracks */
    r=C[0];g=C[1];b=C[2];const s=Math.max(0,1-ay/.06),e=s*s,c4=c2*c2*.3;er=255*e+190*c4;eg=150*e+50*c4;eb=50*e+10*c4}
   else{/* molten: emissive colour with white-hot veins and darker crust plates; stripes: bone ash with char veins */
    const ab=1-band;r=0;g=0;b=0;
    if(band>0){const pl=c>.42?(c>.72?1:(c-.42)/.3):0,em=.74-.3*pl,mr=C[0]*em,mg=C[1]*em,mb=C[2]*em;r=C[0]*.26*band;g=C[1]*.26*band;b=C[2]*.26*band;er=(mr+(hr-mr)*c2)*band;eg=(mg+(hg-mg)*c2)*band;eb=(mb+(hb-mb)*c2)*band}
    if(ab>0){/* the ash keeps a little warmth: a faint inner glow, hotter near the band */const ash=(.9+.14*c)*(1-c2*.2)*ab,w0=Math.max(0,1-(ay-.56)/.16),w=w0*w0*ab;r+=CP[0]*ash;g+=CP[1]*ash;b+=CP[2]*ash;er+=(CP[0]*.1+70*w)*ab;eg+=(CP[1]*.1+30*w)*ab;eb+=(CP[2]*.1+6*w)*ab}
    if(edge){const e=edge*edge*.95;er+=hr*e;eg+=hg*e;eb+=hb*e}}}
  else if(K==='galaxy'){const nb=.5+.5*pzb2Sin(lx*3.3+pzb2Sin(ly*4.1+lz*2.3)*1.6+pzb2Sin(lz*3.7)*.8),k2=nb*nb;let sa=1;
   if(is8){r=C[0];g=C[1];b=C[2];const s=Math.max(0,1-ay/.1),e=s*s,h=Math.max(0,1-ay/.026),hh=Math.max(0,1-ay/.3),ha=hh*hh*hh*.22;
    er=RB[0]*e+255*h*.7+90*ha;eg=RB[1]*e+255*h*.7+50*ha;eb=RB[2]*e+255*h*.7+200*ha;sa=.45}
   else{/* the nebula in the ball's colour (thinner and darker in places, a little blue in the dark); stripes: pale stardust caps */
    const ab=1-band,cl=.95+.08*k2,kk=(.32+.72*k2)*band;r=CP[0]*cl*ab+C[0]*kk;g=CP[1]*cl*ab+C[1]*kk;b=CP[2]*cl*ab+C[2]*kk+18*(1-k2)*band;
    const ek=(.22+.38*k2*k2)*band;er=C[0]*ek;eg=C[1]*ek;eb=C[2]*ek;sa=band;if(edge){const e=edge*edge*.7;er+=(C[0]*.8+60)*e;eg+=(C[1]*.8+60)*e;eb+=(C[2]*.8+80)*e}}
   if(sa>.05){const qx=Math.floor(lx*13),qy=Math.floor(ly*13),qz=Math.floor(lz*13),h=pzb2Hash(qx,qy,qz);if(h>.88){const cx=lx*13-qx-.5,cy=ly*13-qy-.5,cz=lz*13-qz-.5,dd=cx*cx+cy*cy+cz*cz,s=Math.max(0,1-dd*9)*(h-.88)*11*sa;er+=255*s;eg+=245*s;eb+=255*s}}}
  else if(K==='metal'){metal=1;const rx=2*wz*wx,ry=2*wz*wy,env=.25+.75*Math.max(0,-ry*.6+.45)+.25*Math.max(0,ry)*.3+.35*Math.pow(Math.max(0,1-Math.abs(rx+.35)*1.4),3)*Math.max(0,-ry+.2);
   if(is8){const s=Math.max(0,1-ay/.05),e=s*s;r=C[0]*(.5+env);g=C[1]*(.5+env);b=C[2]*(.5+env);er=RB[0]*e;eg=RB[1]*e;eb=RB[2]*e}
   else{const ce=.5+.62*env,tr=C[0]*.82+255*.18,tg=C[1]*.82+214*.18,tb=C[2]*.82+120*.18;r=(CP[0]*ce+(tr*env-CP[0]*ce)*band);g=(CP[1]*ce+(tg*env-CP[1]*ce)*band);b=(CP[2]*ce+(tb*env-CP[2]*ce)*band)}lit=0}
  else{r=W[0]+(C[0]-W[0])*band;g=W[1]+(C[1]-W[1])*band;b=W[2]+(C[2]-W[2])*band}
  /* number discs on both poles, with a crisp ring round each */
  const az=lz<0?-lz:lz;
  if(n>0){if(az>.8){const u=lx*2,v=ly*2,q=u*u+v*v;if(q<1.3){const dk=Math.max(0,Math.min(1,(1-q)/.1+.2)),fade=Math.min(1,(az-.8)/.03);
    const s=lz>0?1:-1,gx=((u*s*.5+.5)*64)|0,gy=((v*.5+.5)*64)|0;let gm=0;if(gx>=0&&gx<64&&gy>=0&&gy<64)gm=gl[gy*64+gx]/255;
    const t=dk*fade;let dr=DS[0]+(NM[0]-DS[0])*gm,dg=DS[1]+(NM[1]-DS[1])*gm,db=DS[2]+(NM[2]-DS[2])*gm;
    if(is8&&pal.disc8){er*=1-t;eg*=1-t;eb*=1-t}
    else if(K==='neon'){dr=DS[0];dg=DS[1];db=DS[2];const e=gm*t;er=er*(1-t)+C[0]*e*.8+110*e;eg=eg*(1-t)+C[1]*e*.8+110*e;eb=eb*(1-t)+C[2]*e*.8+110*e}
    else if(K==='lava'){er*=1-t;eg*=1-t;eb*=1-t;const e=gm*t;er+=255*e;eg+=196*e;eb+=110*e;dr=DS[0];dg=DS[1];db=DS[2]}
    else{er*=1-t;eg*=1-t;eb*=1-t}
    r+=(dr-r)*t;g+=(dg-g)*t;b+=(db-b)*t;
    /* the ring: a dark line, or a glowing one round the 8's bright disc */
    const rg=Math.max(0,1-Math.abs(q-1.02)/.09)*fade*.5;if(R8){const e=rg*1.6;er+=R8[0]*e;eg+=R8[1]*e;eb+=R8[2]*e;r*=1-rg;g*=1-rg;b*=1-rg}else{r*=1-rg;g*=1-rg;b*=1-rg}}}}
  else{let dm=0;if(az>.93){const q=lx*lx+ly*ly;if(q<.026)dm=Math.min(1,(.026-q)/.006)}
   else{const ax=lx<0?-lx:lx;if(ax>.95){const q=ly*ly+lz*lz;if(q<.018)dm=Math.min(1,(.018-q)/.005)}else if(ay>.95){const q=lx*lx+lz*lz;if(q<.018)dm=Math.min(1,(.018-q)/.005)}}
   if(dm>0){r+=(210-r)*dm;g+=(48-g)*dm;b+=(52-b)*dm}}
  const f=metal?1:(P.dif[j]*lit+(1-lit)*.55),sp=P.spe[j]*255*sk,o=P.idx[j]*4,bo=P.bou[j]*38,wn=P.win[j]*255*wk,rim=RA[j]*255*rk;
  let rr=r*f+sp+wn+rim*.86+er,gg=g*f+sp+wn+bo+rim*.9+eg,bb=b*f+sp+wn+bo*.4+rim+eb;d[o]=rr>255?255:rr<0?0:rr;d[o+1]=gg>255?255:gg<0?0:gg;d[o+2]=bb>255?255:bb<0?0:bb;d[o+3]=P.al[j]*255}
 P.ax.putImageData(P.img,slot*P.D,0)}
try{Object.assign(PZ_TAG97,{lava:'Molten solids, ash-white stripes, an obsidian 8.',galaxy:'Nebula solids, stardust stripes, a black-hole 8.',neon:'Glowing solids, frosted stripes, a black-glass 8.'})}catch(e){}
/* ---------- the Cue Rack's set cards show a solid, its stripe and the 8, so the rule is visible before you buy ---------- */
function pzBallCard97(cv,it){const g=cv.getContext('2d');g.clearRect(0,0,300,100);const D0=PZ_BS.D||64;pzbSetup(D0,it.id);const n=[1,9,8];for(let i=0;i<3;i++){const M=pzbRot(pzbRot(pzbI(),0,1,0,.25+i*.22),1,0,0,-.22);pzbPaint(15,n[i],M);const sz=88;g.fillStyle='rgba(0,0,0,.35)';g.beginPath();g.ellipse(58+i*92,94,34,6,0,0,TAU);g.fill();g.drawImage(PZ_BS.atlas,15*PZ_BS.D,0,PZ_BS.D,PZ_BS.D,14+i*92,2,sz,sz)}pzbSetup(D0,PZ.rackSel&&PZ.rackTab==='balls'?PZ.rackSel:PZS().balls)}
/* ---------- your group in the HUD: a badge (OPEN TABLE / SOLIDS / STRIPES / 8-BALL) and the balls left, the 8 at the end ---------- */
const pzb2Left=(st,p)=>{const g=st&&st.grp[p];if(!g||st.open)return -1;let k=0;for(const b of st.B)if(b.on&&b.id&&b.id!==8&&pzGrp(b.id)===g)k++;return k};
function pzBallsHTML(grp,B){if(!grp)return '';const ids=grp==='s'?[1,2,3,4,5,6,7]:[9,10,11,12,13,14,15],on8=ids.every(n=>!B[n]||!B[n].on),e8=B[8]&&B[8].on;
 return ids.map(n=>`<img class="${B[n]&&B[n].on?'':'out'}" src="${pzbIcon(n,22)}" alt="${n}">`).join('')+`<b class="pzb2sep"></b><span class="pzb2e8${on8&&e8?' tgt':''}${e8?'':' out'}"><img src="${pzbIcon(8,22)}" alt="8"><i></i></span>`}
function pzb2Badge(p){const st=PZ.st;if(!st)return {k:'',h:''};const g=st.grp[p],left=pzb2Left(st,p),me=p===0;
 let k,lab,sm;if(!g||st.open){k='o';lab='Open table';sm=st.brk?'':'pot any ball'}else if(left===0){k='e';lab='8-ball';sm=me?'your target':'on the 8'}else{k=g==='s'?'s':'t';lab=g==='s'?'Solids':'Stripes';sm=`${left} left`}
 return {k,h:`<span class="pzb2c ${k}"><em class="pzb2i ${k}"></em><b>${lab}</b></span><small>${sm}</small>`}}
{const f0=pzMount;pzMount=function(R){PZ.pzb2E8=null;PZ.pzb2P=null;const r=f0.apply(this,arguments);try{const m=$('pzm');if(m){m.classList.add('pzb2');for(const [c,id] of [['pzcm','pzb2gm'],['pzco','pzb2go']]){const card=$(c);if(card&&!$(id)){const d=document.createElement('div');d.className='pzb2g';d.id=id;card.appendChild(d)}}pzb2Hud()}}catch(e){console.error(e)}return r}}
function pzb2Hud(){if(!PZ.on||!PZ.st||(PZ.M&&PZ.M.trick))return;for(const [p,id] of [[0,'pzb2gm'],[1,'pzb2go']]){const el=$(id);if(!el)continue;const o=pzb2Badge(p);
 if(el._h!==o.h){const was=el._k;el.innerHTML=o.h;el._h=o.h;if(was&&was!==o.k&&o.k!=='o'){el.classList.remove('pop');void el.offsetWidth;el.classList.add('pop')}el._k=o.k}}}
{const f0=pzHudAll;pzHudAll=function(){const r=f0.apply(this,arguments);try{pzb2Hud()}catch(e){console.error(e)}return r}}
/* ---------- on the table: your balls flash when your turn starts, the 8 is marked once it is your target ---------- */
{const f0=pzBeginTurn;pzBeginTurn=function(){const r=f0.apply(this,arguments);try{const st=PZ.st,M=PZ.M,B=PZ.B;if(PZ.on&&st&&M&&!M.trick&&st.turn===0&&!st.brk&&!st.open&&st.grp[0]){
  const on8=pzrOn8(st),ids=on8?[8]:B.filter(b=>b.on&&b.id&&b.id!==8&&pzGrp(b.id)===st.grp[0]).map(b=>b.id);PZ.pzb2P={t0:PZ.t,ids,e8:on8};
  const e=$('pzbm');if(e&&!pzRM()){e.classList.remove('hop');void e.offsetWidth;e.classList.add('hop');clearTimeout(PZ.pzb2HT);PZ.pzb2HT=setTimeout(()=>e.classList.remove('hop'),1400)}
  if(on8&&PZ.pzb2E8!==M.rack){PZ.pzb2E8=M.rack;if(!st.bih)pzBanner('On the 8!','turn',1200);pzSub('Your target now: the 8 · call its pocket',2200)}}}catch(e){console.error(e)}return r}}
function pzb2Draw(g,t){const st=PZ.st,B=PZ.B,M=PZ.M;if(!st||!B||!M||M.trick||PZ.rk)return;const G=PZ_G,R=PZ_PHY.R,rm=pzRM();
 const P=PZ.pzb2P;if(P&&st.turn===0){const age=t-P.t0;if(age>1.6||age<0)PZ.pzb2P=null;else{g.save();g.lineCap='round';
  P.ids.forEach((id,k)=>{const b=B[id];if(!b||!b.on)return;const u=(age-k*.045)/.75;if(u<=0||u>=1)return;const x=G.x+b.x,y=G.y+b.y,e=1-(1-u)*(1-u);
   if(rm){g.globalAlpha=(1-u)*.9;g.strokeStyle='#ffd45a';g.lineWidth=3;g.beginPath();g.arc(x,y,R+5,0,TAU);g.stroke();return}
   g.globalAlpha=Math.min(1,(1-u)*1.3);g.strokeStyle='#12081f';g.lineWidth=4.4*(1-u)+2.4;g.beginPath();g.arc(x,y,R+3+e*(P.e8?24:16),0,TAU);g.stroke();
   g.strokeStyle=P.e8?'#fff3b0':'#ffd45a';g.lineWidth=3.6*(1-u)+1.2;g.stroke();g.globalAlpha=(1-u)*.7;g.lineWidth=2.2;g.beginPath();g.arc(x,y,R+3+e*6,0,TAU);g.stroke()});g.restore()}}
 /* the 8 as your target: a turning gold ring and a bobbing marker while you aim */
 const e=B[8];if(st.turn===0&&PZ.ph==='aim'&&!st.open&&e&&e.on&&pzrOn8(st)){const x=G.x+e.x,y=G.y+e.y,bob=rm?0:Math.sin(t*4.2)*2.5;g.save();
  g.strokeStyle='#12081f';g.lineWidth=5;g.beginPath();g.arc(x,y,R+6,0,TAU);g.stroke();g.strokeStyle='#ffd45a';g.lineWidth=2.6;g.setLineDash([7,5]);g.lineDashOffset=rm?0:-t*14;g.beginPath();g.arc(x,y,R+6,0,TAU);g.stroke();g.setLineDash([]);
  const my=y-R-14+bob;g.beginPath();g.moveTo(x-9,my-11);g.lineTo(x+9,my-11);g.lineTo(x,my+1);g.closePath();g.lineJoin='round';g.lineWidth=4;g.strokeStyle='#12081f';g.stroke();g.fillStyle='#ffd45a';g.fill();g.restore()}}
{const f0=pzDrawTable;pzDrawTable=function(g,t){const r=f0.apply(this,arguments);try{pzb2Draw(g,t)}catch(e){}return r}}
{const st=document.createElement('style');st.textContent=`
.pzm.pzb2:not(.trick) .pzct i{display:none}
.pzm.pzb2:not(.trick) .pzturn{top:44px;bottom:auto}
.pzm.trick .pzb2g{display:none}
.pzb2g{position:absolute;left:108px;top:44px;height:23px;display:flex;align-items:center;gap:8px;pointer-events:none;transform-origin:20% 50%}
.pzb2g.pop{animation:pzb2pop .5s cubic-bezier(.3,1.7,.5,1)}
@keyframes pzb2pop{0%{transform:scale(.6);opacity:.3}100%{transform:none;opacity:1}}
.pzb2c{display:flex;align-items:center;gap:6px;height:23px;padding:0 11px 0 3px;border-radius:12px;border:2px solid #12081f;box-sizing:border-box;font:800 12px/1 Poppins,sans-serif;letter-spacing:.09em;text-transform:uppercase;white-space:nowrap}
.pzb2c b{font-weight:800}
.pzcard.me .pzb2c{background:linear-gradient(180deg,#ffe189,#e9b43a);color:#2a1a04}
.pzcard.opp .pzb2c{background:linear-gradient(180deg,#4a3c9c,#2e2272);color:#efe8ff;border-color:#12081f}
.pzb2c.o{background:#1c1450!important;color:#a89ed0!important;border:2px dashed #5a4ca0}
.pzb2c.e{background:linear-gradient(180deg,#2a2236,#0c0812)!important;color:#ffd45a!important;border-color:#ffd45a}
.pzb2g small{font:700 12px Poppins,sans-serif;color:#c4badf;white-space:nowrap}
.pzcard.me .pzb2g small{color:#ffe6a0}
.pzb2i{width:15px;height:15px;border-radius:50%;border:1.5px solid #12081f;box-sizing:border-box;flex:none}
.pzb2i.s{background:radial-gradient(circle at 34% 30%,#ffffffc0 0 14%,transparent 18%),radial-gradient(circle at 40% 36%,#ff7a3a,#c42a1e 72%)}
.pzb2i.t{background:radial-gradient(circle at 34% 30%,#ffffffc0 0 14%,transparent 18%),linear-gradient(180deg,#f6f0e2 0 30%,#3a72ff 30% 70%,#f6f0e2 70%)}
.pzb2i.e{background:radial-gradient(circle at 50% 52%,#fff 0 24%,transparent 28%),radial-gradient(circle at 40% 34%,#4a4458,#08060c 72%)}
.pzb2i.o{background:transparent;border:1.5px dashed #8a80c8}
.pzballs .pzb2sep{width:2px;height:15px;align-self:center;border-radius:2px;background:#5a4ca0;flex:none}
.pzballs .pzb2e8{position:relative;width:23px;height:23px;flex:none;opacity:.5;transition:opacity .25s,transform .25s}
.pzballs .pzb2e8.tgt{opacity:1;transform:scale(1.14)}
.pzballs .pzb2e8.out{opacity:.22;transform:scale(.8)}
.pzballs .pzb2e8 i{position:absolute;left:-4px;top:-4px;width:31px;height:31px;border-radius:50%;border:2px solid #ffd45a;box-sizing:border-box;opacity:0}
.pzballs .pzb2e8.tgt i{animation:pzb2pul 1.4s ease-out infinite}
@keyframes pzb2pul{0%{transform:scale(.78);opacity:.95}100%{transform:scale(1.45);opacity:0}}
.pzballs.hop>img:not(.out){animation:pzb2hop .62s cubic-bezier(.3,1.6,.5,1) both}
.pzballs.hop>img:nth-child(2){animation-delay:.05s}.pzballs.hop>img:nth-child(3){animation-delay:.1s}.pzballs.hop>img:nth-child(4){animation-delay:.15s}
.pzballs.hop>img:nth-child(5){animation-delay:.2s}.pzballs.hop>img:nth-child(6){animation-delay:.25s}.pzballs.hop>img:nth-child(7){animation-delay:.3s}
@keyframes pzb2hop{0%{transform:none}40%{transform:translateY(-7px) scale(1.15)}100%{transform:none}}
body.pf-low .pzballs .pzb2e8.tgt i{animation:none;opacity:.9;transform:none}
@media (prefers-reduced-motion:reduce){.pzballs .pzb2e8.tgt i{animation:none;opacity:.9;transform:none}.pzb2g.pop{animation:none}}
`;document.head.appendChild(st)}
