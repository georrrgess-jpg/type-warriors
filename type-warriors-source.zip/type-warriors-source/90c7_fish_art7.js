/* ===== MOONLIT FISHING: fish art 7 — Frostfall Lake: herring (common), sculpin (common), narwhal (rare), colossus (legendary) =====
   Each FISHART.<id>(g,t,o) draws one fish facing right, centred on the origin, ~200 units long. Helpers prefixed fa7_
   (the polish kit is a private copy so this file never depends on another file's internals). */
/* path from a command list: 'M',x,y 'L',x,y 'Q',cx,cy,x,y 'C',c1x,c1y,c2x,c2y,x,y 'Z' */
function fa7_path(g,c){g.beginPath();let i=0;while(i<c.length){const k=c[i++];
 if(k==='M'){g.moveTo(c[i],c[i+1]);i+=2}else if(k==='L'){g.lineTo(c[i],c[i+1]);i+=2}
 else if(k==='Q'){g.quadraticCurveTo(c[i],c[i+1],c[i+2],c[i+3]);i+=4}
 else if(k==='C'){g.bezierCurveTo(c[i],c[i+1],c[i+2],c[i+3],c[i+4],c[i+5]);i+=6}else if(k==='Z')g.closePath()}}
/* crisp closed polygon */
function fa7_poly(g,p){g.beginPath();g.moveTo(p[0],p[1]);for(let i=2;i<p.length;i+=2)g.lineTo(p[i],p[i+1]);g.closePath()}
/* gradient with explicit stops [[pos,colour],...] */
function fa7_grad(g,x0,y0,x1,y1,s){const q=g.createLinearGradient(x0,y0,x1,y1);for(const e of s)q.addColorStop(e[0],e[1]);return q}
function fa7_rgrad(g,x,y,r0,r1,s){const q=g.createRadialGradient(x,y,r0,x,y,r1);for(const e of s)q.addColorStop(e[0],e[1]);return q}
/* run fn in a translated + rotated frame */
function fa7_at(g,x,y,a,fn){g.save();g.translate(x,y);g.rotate(a);fn();g.restore()}
/* twinkle 0..1 */
const fa7_tw=(t,i,sp)=>.5+.5*Math.sin(t*(sp||3)+i*1.91);
/* glossy highlight: a soft white curve inside the clip path */
function fa7_gloss(g,clip,x0,y0,cx,cy,x1,y1,w,a){g.save();clip();g.clip();g.lineCap='round';g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo(cx,cy,x1,y1);
 g.strokeStyle=`rgba(255,255,255,${a*.4})`;g.lineWidth=w*2.2;g.stroke();g.strokeStyle=`rgba(255,255,255,${a})`;g.lineWidth=w;g.stroke();g.restore()}
/* gill arc (clipped to the body) */
function fa7_gill(g,clip,x,y,r,a0,a1,c,a){g.save();clip();g.clip();g.beginPath();g.arc(x,y,r,a0,a1);g.strokeStyle=c||FKO;g.globalAlpha=a==null?.6:a;g.lineWidth=2.4;g.lineCap='round';g.stroke();g.restore()}
/* rib lines from a root point to each listed point, clipped to the clip path */
function fa7_ribs(g,clip,x0,y0,pts,a,c,lw){g.save();clip();g.clip();g.strokeStyle=c||FKO;g.globalAlpha=a==null?.25:a;g.lineWidth=lw||1.3;g.lineCap='round';
 for(let i=0;i<pts.length;i+=2){g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo((x0+pts[i])/2,(y0+pts[i+1])/2*1.04,pts[i],pts[i+1]);g.stroke()}g.restore()}
/* tapered strand along a chain of cubic beziers b=[x0,y0, c1x,c1y,c2x,c2y,x1,y1, ...] */
function fa7_strand(g,b,w0,w1,col,lw,rays){const P=[[b[0],b[1]]];let x=b[0],y=b[1];
 for(let i=2;i+5<b.length;i+=6){const c1x=b[i],c1y=b[i+1],c2x=b[i+2],c2y=b[i+3],ex=b[i+4],ey=b[i+5];
  for(let s=1;s<=12;s++){const u=s/12,v=1-u;P.push([v*v*v*x+3*v*v*u*c1x+3*v*u*u*c2x+u*u*u*ex,v*v*v*y+3*v*v*u*c1y+3*v*u*u*c2y+u*u*u*ey])}x=ex;y=ey}
 const n=P.length,L=[],R=[];for(let i=0;i<n;i++){const a=P[Math.max(0,i-1)],c=P[Math.min(n-1,i+1)],dx=c[0]-a[0],dy=c[1]-a[1],d=Math.hypot(dx,dy)||1,w=(w0+(w1-w0)*i/(n-1))/2;
  L.push([P[i][0]-dy/d*w,P[i][1]+dx/d*w]);R.push([P[i][0]+dy/d*w,P[i][1]-dx/d*w])}
 g.beginPath();g.moveTo(L[0][0],L[0][1]);for(const p of L)g.lineTo(p[0],p[1]);for(let i=n-1;i>=0;i--)g.lineTo(R[i][0],R[i][1]);g.closePath();
 g.lineJoin='round';g.lineWidth=lw||2.2;g.strokeStyle=FKO;g.stroke();g.fillStyle=col;g.fill();
 /* optional fin finish: fine rays along the strand and a soft highlight on one edge */
 if(rays){g.save();g.clip();g.lineCap='round';const line=(f,c,w)=>{g.beginPath();for(let i=0;i<n;i++){const px=L[i][0]+(R[i][0]-L[i][0])*f,py=L[i][1]+(R[i][1]-L[i][1])*f;i?g.lineTo(px,py):g.moveTo(px,py)}g.strokeStyle=c;g.lineWidth=w;g.stroke()};
  for(const f of [.3,.5,.7])line(f,rays,.7);line(.16,'rgba(255,255,255,.65)',1.1);g.restore()}}
/* eyelid: amt 0 open .. 1 shut */
function fa7_lid(g,x,y,r,amt,col){if(amt<=0)return;const ly=y-r+2*r*Math.min(1,amt);g.save();g.beginPath();g.arc(x,y,r,0,TAU);g.clip();
 g.beginPath();g.moveTo(x-r-3,y-r-3);g.lineTo(x+r+3,y-r-3);g.lineTo(x+r+3,ly);g.quadraticCurveTo(x,ly+r*.2,x-r-3,ly);g.closePath();g.fillStyle=col;g.fill();
 g.beginPath();g.moveTo(x+r+3,ly);g.quadraticCurveTo(x,ly+r*.2,x-r-3,ly);g.strokeStyle=FKO;g.lineWidth=Math.max(2,r*.26);g.stroke();if(amt>.7){g.globalAlpha=Math.min(1,(amt-.7)/.22);g.beginPath();g.moveTo(x-r*.8,y+r*.02);g.quadraticCurveTo(x,y+r*.56,x+r*.8,y+r*.02);g.lineWidth=Math.max(1.8,r*.24);g.stroke();g.beginPath();g.moveTo(x-r*.5,y-r*.32);g.quadraticCurveTo(x,y-r*.02,x+r*.5,y-r*.32);g.strokeStyle='rgba(255,255,255,.32)';g.lineWidth=Math.max(1,r*.13);g.stroke();g.globalAlpha=1}g.restore();
 g.beginPath();g.arc(x,y,r,0,TAU);g.lineWidth=Math.max(2,r*.24);g.strokeStyle=FKO;g.stroke()}
/* blink: 0 open, rising to 1 for a quick blink every few seconds */
function fa7_blink(t,s){const p=((t+s)%5.1+5.1)%5.1;return p>4.9?1-Math.abs(p-5)/.1:0}
/* small cartoon smile */
function fa7_smile(g,x0,y0,cx,cy,x1,y1,w){g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo(cx,cy,x1,y1);g.strokeStyle=FKO;g.lineWidth=w||2.4;g.lineCap='round';g.stroke()}
/* rosy cheek blush */
function fa7_blush(g,x,y,r,c,a){g.save();g.globalAlpha=a==null?.45:a;g.fillStyle=fa7_rgrad(g,x,y,0,r,[[0,c||'#ff7aa0'],[1,(c||'#ff7aa0')+'00']]);g.beginPath();g.ellipse(x,y,r,r*.62,0,0,TAU);g.fill();g.restore()}
/* pectoral fin: a fan hinged at (x,y), sweeping back; a = tilt */
function fa7_pec(g,x,y,a,L,c1,c2,al,rim){fa7_at(g,x,y,a,()=>{const P=()=>fa7_path(g,['M',3,-3.5,'C',-L*.3,-L*.34,-L*.78,-L*.3,-L,-L*.08,'Q',-L*1.02,L*.08,-L*.9,L*.18,'Q',-L*.8,L*.3,-L*.62,L*.3,'C',-L*.36,L*.28,-L*.1,L*.12,3,3.5,'Z']);
 g.globalAlpha=al||1;P();fkFill(g,fkLin(g,0,0,-L,L*.1,[c1,c2]),2.2);g.globalAlpha=1;fa7_ribs(g,P,2,0,[-L,-L*.12,-L,L*.04,-L*.9,L*.2,-L*.7,L*.3],.3);
 fa7_finfx(g,P,0,0,shade(c1,.45),[-L*.98,-L*.03,-L*.96,L*.12,-L*.82,L*.26],.6,0);
 g.save();P();g.clip();g.beginPath();g.moveTo(2,-3);g.bezierCurveTo(-L*.3,-L*.3,-L*.78,-L*.26,-L*.98,-L*.06);g.strokeStyle=rim||'rgba(255,255,255,.55)';g.lineWidth=2;g.stroke();g.restore();P();g.lineJoin='round';g.lineWidth=2.2;g.strokeStyle=FKO;g.stroke()})}
/* 6-armed snowflake crystal */
function fa7_snow(g,x,y,r,rot,c,a){g.save();g.translate(x,y);g.rotate(rot);g.globalAlpha=a==null?1:a;g.strokeStyle=c||'#fff';g.lineCap='round';g.lineWidth=Math.max(1,r*.26);
 for(let i=0;i<6;i++){g.rotate(TAU/6);g.beginPath();g.moveTo(0,0);g.lineTo(r,0);g.moveTo(r*.55,0);g.lineTo(r*.8,-r*.24);g.moveTo(r*.55,0);g.lineTo(r*.8,r*.24);g.stroke()}
 g.beginPath();g.arc(0,0,r*.2,0,TAU);g.fillStyle=c||'#fff';g.fill();g.restore()}
/* catch-spectacle wash */
function fa7_catch(g,o,c,k){const v=(o.glow||0)*(k||1);if(v>0)fkGlow(g,10,0,115,c||'#fff2c8',.24*v)}
/* ribbon outline from a centre line fn(s)->[x,y,halfWidth]; returns flat points (left side then right side reversed) */
function fa7_rib(n,fn){const c=[];for(let i=0;i<=n;i++)c.push(fn(i/n));const L=[],R=[];
 for(let i=0;i<=n;i++){const a=c[Math.max(0,i-1)],b=c[Math.min(n,i+1)],dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy)||1,nx=-dy/d,ny=dx/d,w=c[i][2];
  L.push(c[i][0]+nx*w,c[i][1]+ny*w);R.unshift(c[i][0]-nx*w,c[i][1]-ny*w)}return L.concat(R)}
/* closed smooth spline (same curve as fkPath) appended to the current path when cont is true */
function fa7_blob(g,p,cont){const n=p.length/2,mx=i=>(p[(i%n)*2]+p[((i+1)%n)*2])/2,my=i=>(p[(i%n)*2+1]+p[((i+1)%n)*2+1])/2;if(!cont)g.beginPath();g.moveTo(mx(n-1),my(n-1));for(let i=0;i<n;i++)g.quadraticCurveTo(p[i*2],p[i*2+1],mx(i),my(i));g.closePath()}
/* clip to everything OUTSIDE a spline outline (so see-through bodies do not show the fin roots behind them) */
function fa7_outside(g,p){g.beginPath();g.rect(-400,-400,800,800);fa7_blob(g,p,1);g.clip('evenodd')}
/* crystal fin polygon: pre points, then an outer edge with a sharp ice shard between every pair of edge points, then post points */
function fa7_crys(pre,edge,post,len){const out=pre.slice();let cx=0,cy=0;const all=pre.concat(edge,post);for(let i=0;i<all.length;i+=2){cx+=all[i];cy+=all[i+1]}cx/=all.length/2;cy/=all.length/2;
 for(let i=0;i<edge.length;i+=2){out.push(edge[i],edge[i+1]);if(i+3<edge.length){const ax=edge[i],ay=edge[i+1],bx=edge[i+2],by=edge[i+3],mx=(ax+bx)/2,my=(ay+by)/2;let nx=-(by-ay),ny=bx-ax;const d=Math.hypot(nx,ny)||1;nx/=d;ny/=d;
  if(nx*(mx-cx)+ny*(my-cy)<0){nx=-nx;ny=-ny}const L=len*(i/2%2?.72:1);out.push(mx+nx*L,my+ny*L)}}
 return out.concat(post)}
/* ---- polish kit (fa7_) ---- */
/* hex colour + alpha -> rgba() */
function fa7_rgba(h,a){const n=parseInt(h.slice(1,7),16);return `rgba(${n>>16},${n>>8&255},${n&255},${a})`}
/* rich eye: shaded sclera, gradient iris with a dark rim and fine striations, pupil, big catch-light, second glint and a soft lower reflection */
function fa7_eye(g,x,y,r,iris,look){look=look||0;const ix=x+r*.18+look*r*.12,iy=y+r*.05,ir=r*.62;
 g.beginPath();g.arc(x,y,r,0,TAU);g.fillStyle=fa7_rgrad(g,x-r*.25,y-r*.3,r*.1,r*1.05,[[0,'#ffffff'],[.62,'#fbf7f0'],[1,'#d8d0e6']]);g.fill();
 g.save();g.beginPath();g.arc(x,y,r,0,TAU);g.clip();
 g.beginPath();g.arc(ix,iy,ir,0,TAU);g.fillStyle=fa7_rgrad(g,ix-ir*.15,iy+ir*.25,ir*.08,ir,[[0,shade(iris,.5)],[.45,iris],[.85,shade(iris,-.35)],[1,shade(iris,-.6)]]);g.fill();
 g.strokeStyle=fa7_rgba(shade(iris,.55),.35);g.lineWidth=Math.max(.6,r*.06);g.beginPath();
 for(let i=0;i<10;i++){const a=i/10*TAU+.3;g.moveTo(ix+Math.cos(a)*ir*.42,iy+Math.sin(a)*ir*.42);g.lineTo(ix+Math.cos(a)*ir*.86,iy+Math.sin(a)*ir*.86)}g.stroke();
 g.beginPath();g.arc(ix,iy,ir,0,TAU);g.strokeStyle=fa7_rgba(shade(iris,-.7),.85);g.lineWidth=Math.max(.8,r*.08);g.stroke();
 g.beginPath();g.arc(x+r*.22+look*r*.12,y+r*.08,r*.34,0,TAU);g.fillStyle='#0c0612';g.fill();
 /* upper lid shadow */
 g.fillStyle=fa7_grad(g,0,y-r,0,y-r*.2,[[0,'rgba(40,20,60,.32)'],[1,'rgba(40,20,60,0)']]);g.fillRect(x-r,y-r,r*2,r*.8);
 /* lower reflection crescent */
 g.beginPath();g.arc(ix,iy,ir*.72,Math.PI*.25,Math.PI*.8);g.strokeStyle='rgba(255,255,255,.42)';g.lineWidth=Math.max(.8,r*.1);g.lineCap='round';g.stroke();
 g.restore();
 g.beginPath();g.arc(x,y,r,0,TAU);g.lineWidth=Math.max(2,r*.24);g.strokeStyle=FKO;g.stroke();
 g.beginPath();g.ellipse(x+r*.34,y-r*.24,r*.25,r*.21,-.5,0,TAU);g.fillStyle='#fff';g.fill();
 g.beginPath();g.arc(x+r*.08,y-r*.34,r*.08,0,TAU);g.fill();
 g.beginPath();g.arc(x-r*.06,y+r*.34,r*.1,0,TAU);g.fillStyle='rgba(255,255,255,.75)';g.fill()}
/* rim light: thin light just inside the top edge (moonlight) and a reflected glow inside the bottom edge */
function fa7_rim(g,clip,top,bot,a,w){a=a==null?1:a;w=w||2;g.save();clip();g.clip();
 if(top){g.save();g.translate(.6,w*1.25);clip();g.strokeStyle=top;g.globalAlpha=.55*a;g.lineWidth=w;g.stroke();g.restore()}
 if(bot){g.save();g.translate(-.6,-w*1.3);clip();g.strokeStyle=bot;g.globalAlpha=.5*a;g.lineWidth=w*1.2;g.stroke();g.restore()}
 g.restore()}
/* crisp specular glint (a bright tilted lozenge and a dot) */
function fa7_spec(g,x,y,s,a){g.save();g.globalAlpha=a==null?.95:a;g.fillStyle='#fff';g.beginPath();g.ellipse(x,y,3.4*s,1.25*s,-.42,0,TAU);g.fill();
 g.beginPath();g.arc(x+4.6*s,y-2.4*s,.9*s,0,TAU);g.fill();g.restore()}
/* fin finish: shadowed root, fine secondary rays, and a light translucent band toward the edge */
function fa7_finfx(g,P,rx,ry,edge,rays,a,lw){a=a==null?1:a;g.save();P();g.clip();
 if(rays&&rx!=null){g.strokeStyle=fa7_rgba(edge,.32*a);g.lineWidth=.8;g.lineCap='round';g.beginPath();for(let i=0;i<rays.length;i+=2){g.moveTo(rx,ry);g.lineTo(rx+(rays[i]-rx)*1.1,ry+(rays[i+1]-ry)*1.1)}g.stroke()}
 g.lineJoin='round';P();g.strokeStyle=fa7_rgba(edge,.16*a);g.lineWidth=12;g.stroke();P();g.strokeStyle=fa7_rgba(edge,.3*a);g.lineWidth=5;g.stroke();
 if(rx!=null&&ry!=null){g.fillStyle=fa7_rgrad(g,rx,ry,0,26,[[0,'rgba(20,8,30,.2)'],[1,'rgba(20,8,30,0)']]);g.fillRect(rx-28,ry-28,56,56)}
 g.restore();if(lw!==0){P();g.lineJoin='round';g.lineWidth=lw||2.4;g.strokeStyle=FKO;g.stroke()}}
/* embossed fine scales: dark scale edges with a lighter catch-light just inside */
function fa7_tex(g,clip,x0,x1,y0,y1,s,dark,light,a){fkScales(g,clip,x0,x1,y0,y1,s,dark,a);g.save();g.translate(0,-1);fkScales(g,clip,x0,x1,y0,y1,s,light,a*.75);g.restore()}
/* operculum: soft shade behind the gill, a crisp gill line, a highlight on its front lip and a faint second slit */
function fa7_gill2(g,clip,x,y,r,a0,a1,c,a){a=a==null?.6:a;g.save();clip();g.clip();g.lineCap='round';
 g.beginPath();g.arc(x,y,r,a0,a1);g.arc(x,y,r+10,a1,a0,true);g.closePath();g.fillStyle=fa7_rgrad(g,x,y,r,r+10,[[0,fa7_rgba(c,.24)],[1,fa7_rgba(c,0)]]);g.fill();
 g.beginPath();g.arc(x+7,y,r+6,a0+.08,a1-.08);g.strokeStyle=fa7_rgba(c,.28*a/.6);g.lineWidth=1.2;g.stroke();
 g.beginPath();g.arc(x,y,r,a0,a1);g.strokeStyle=c;g.globalAlpha=Math.min(1,a*1.2);g.lineWidth=1.8;g.stroke();
 g.beginPath();g.arc(x-1.6,y,r,a0+.06,a1-.06);g.strokeStyle='#ffffff';g.globalAlpha=.3;g.lineWidth=1.2;g.stroke();g.restore()}
/* mouth with a soft lower lip, a lip highlight and a curled corner */
function fa7_mouth(g,x0,y0,cx,cy,x1,y1,w,lip){g.save();g.lineCap='round';
 g.beginPath();g.moveTo(x0-.5,y0+1.8);g.quadraticCurveTo(cx,cy+2.4,x1+.5,y1+1.8);g.strokeStyle=fa7_rgba(lip||'#ff8aa8',.55);g.lineWidth=3.2;g.stroke();
 g.beginPath();g.moveTo(x0,y0-1.4);g.quadraticCurveTo(cx,cy-1.6,x1+1,y1-1.4);g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=1.1;g.stroke();
 fa7_smile(g,x0,y0,cx,cy,x1,y1,w||2);
 g.beginPath();g.arc(x1+1.6,y1,2,Math.PI*.72,Math.PI*1.28);g.strokeStyle=FKO;g.lineWidth=1.2;g.stroke();g.restore()}
/* gentle colour variation: a few soft tinted blotches inside a clip; b=[[x,y,r,colour,alpha],...] */
function fa7_mottle(g,clip,b){g.save();clip();g.clip();for(const m of b){g.fillStyle=fa7_rgrad(g,m[0],m[1],0,m[2],[[0,fa7_rgba(m[3],m[4])],[1,fa7_rgba(m[3],0)]]);g.fillRect(m[0]-m[2],m[1]-m[2],m[2]*2,m[2]*2)}g.restore()}
/* fine speckle texture (deterministic) inside a clip */
function fa7_speck(g,clip,x0,x1,y0,y1,n,col,a,r,seed){g.save();clip();g.clip();g.fillStyle=col;g.globalAlpha=a;g.beginPath();let s=seed||7;
 for(let i=0;i<n;i++){s=(s*9301+49297)%233280;const u=s/233280;s=(s*9301+49297)%233280;const v=s/233280;const x=x0+(x1-x0)*u,y=y0+(y1-y0)*v,rr=r*(.6+.8*((i*37)%10)/10);g.moveTo(x+rr,y);g.arc(x,y,rr,0,TAU)}g.fill();g.restore()}
/* frost rime: a dotted white crust just inside an outline */
function fa7_rime(g,P,a,w){g.save();P();g.clip();P();g.strokeStyle=`rgba(255,255,255,${a==null?.7:a})`;g.lineWidth=w||3;g.setLineDash([1.6,3.4]);g.lineCap='round';g.stroke();g.setLineDash([]);g.restore()}
/* frosted fin: translucent ice gradient, fine rays, a misty edge band and a rime crust */
function fa7_frostFin(g,pp,rx,ry,c1,c2,ribs,lw,al){const P=()=>fkPath(g,pp);g.globalAlpha=al==null?.92:al;fkFin(g,pp,c1,c2,ribs,lw||2.3);g.globalAlpha=1;
 fa7_finfx(g,P,null,null,'#ffffff',null,1,0);fa7_rime(g,P,.8,2.4);P();g.lineJoin='round';g.lineWidth=lw||2.3;g.strokeStyle=FKO;g.stroke()}
/* faceted ice crystal (a hexagonal prism with a pointed cap) standing at (x,y), pointing along angle a; length L, width w */
function fa7_icicle(g,x,y,a,L,w,al,t){fa7_at(g,x,y,a,()=>{const h=w*.5,P=()=>fa7_poly(g,[-2,-h,L*.66,-h,L,0,L*.66,h,-2,h]);
 g.globalAlpha=al==null?1:al;P();fkFill(g,fa7_grad(g,0,-h,0,h,[[0,'#ffffff'],[.45,'#d4f2ff'],[.5,'#9ad6ff'],[1,'#5aa8f0']]),2);
 g.save();P();g.clip();g.fillStyle='rgba(255,255,255,.55)';fa7_poly(g,[-2,-h,L*.66,-h,L,0,L*.62,-h*.15,-2,-h*.15]);g.fill();
 g.beginPath();g.moveTo(L*.66,-h);g.lineTo(L*.62,-h*.15);g.lineTo(L*.66,h);g.moveTo(L*.62,-h*.15);g.lineTo(L,0);g.strokeStyle='rgba(30,90,180,.5)';g.lineWidth=.9;g.stroke();g.restore();
 P();g.lineWidth=2;g.strokeStyle=FKO;g.stroke();g.globalAlpha=1})}
/* a little cluster of three ice crystals fanning out of a surface at (x,y); a = outward angle; a frosty rime patch hides the roots */
function fa7_cluster(g,x,y,a,s,t,i){const k=fa7_tw(t,i||0,2.2),ix=x-Math.cos(a)*3*s,iy=y-Math.sin(a)*3*s;
 fa7_icicle(g,ix+Math.sin(a)*3*s,iy-Math.cos(a)*3*s,a-.7,13*s,6.2*s);fa7_icicle(g,ix-Math.sin(a)*3*s,iy+Math.cos(a)*3*s,a+.66,11.5*s,5.8*s);fa7_icicle(g,ix,iy,a,18*s,7.4*s);
 g.save();g.translate(x-Math.cos(a)*1.5*s,y-Math.sin(a)*1.5*s);g.rotate(a+Math.PI/2);g.beginPath();g.ellipse(0,0,10*s,3.6*s,0,0,TAU);g.fillStyle=fa7_rgrad(g,0,0,0,8*s,[[0,'rgba(255,255,255,.95)'],[.6,'rgba(220,246,255,.7)'],[1,'rgba(200,240,255,0)']]);g.fill();
 g.fillStyle='#fff';for(const d of [[-5,.6,1],[4.5,.4,.9],[0,1.4,.8]]){g.beginPath();g.arc(d[0]*s,d[1]*s,d[2]*s,0,TAU);g.fill()}g.restore();
 fkSpark(g,x+Math.cos(a)*18*s,y+Math.sin(a)*18*s,(2.4+3.4*k)*s,'#ffffff',.45+.55*k)}
/* soft travelling sheen band clipped to a path */
function fa7_sheen(g,P,t,sp,c,a){const sx=((t*sp)%280)-130;g.save();P();g.clip();g.fillStyle=fa7_grad(g,sx-24,-34,sx+24,34,[[0,'rgba(255,255,255,0)'],[.5,fa7_rgba(c,a)],[1,'rgba(255,255,255,0)']]);g.fillRect(-120,-60,240,120);g.restore()}

/* ---- frost helpers (fa7_) ---- */
/* a clear icicle spine standing on a surface at (x,y), pointing along angle a: glassy body, a lit facet, a frost collar at its root and a bead of light at the tip */
function fa7_spine(g,x,y,a,L,w,tw){fa7_at(g,x,y,a,()=>{const h=w*.5,P=()=>fa7_poly(g,[-1,-h,L*.62,-h*.6,L,0,L*.62,h*.6,-1,h]);
 P();g.fillStyle=fa7_grad(g,0,-h,0,h,[[0,'#ffffff'],[.45,'#eefaff'],[.55,'#c4ecff'],[1,'#86c8f8']]);g.fill();
 g.save();P();g.clip();g.fillStyle=fa7_grad(g,0,0,L,0,[[0,'rgba(60,140,230,.35)'],[.35,'rgba(200,240,255,0)'],[1,'rgba(255,255,255,.9)']]);g.fillRect(-2,-h,L+2,w);
 g.beginPath();g.moveTo(L*.06,-h*.4);g.quadraticCurveTo(L*.5,-h*.42,L*.92,-h*.04);g.strokeStyle='#ffffff';g.lineWidth=Math.max(.9,w*.2);g.lineCap='round';g.stroke();
 g.beginPath();g.moveTo(-1,0);g.lineTo(L*.62,0);g.lineTo(L,0);g.strokeStyle='rgba(60,130,220,.45)';g.lineWidth=.8;g.stroke();g.fillStyle='rgba(120,190,250,.35)';fa7_poly(g,[-1,0,L*.62,0,L,0,L*.62,h*.6,-1,h]);g.fill();g.restore();
 P();g.lineJoin='round';g.lineWidth=1.5;g.strokeStyle='#1b2a5e';g.stroke();
 if(tw>0)fkSpark(g,L+.5,0,1.5+w*.7*tw,'#ffffff',tw)})}
/* a single prismatic scale flash: an arc-edged scale filled with a shifting rainbow */
function fa7_prism(g,x,y,s,hue,a){if(a<=.02)return;g.save();g.globalAlpha=a;const P=()=>{g.beginPath();g.arc(x,y,s,Math.PI*.08,Math.PI*.92);g.closePath()};
 P();g.fillStyle=fa7_grad(g,x-s,y,x+s,y+s*.5,[[0,`hsl(${hue},95%,64%)`],[.5,`hsl(${hue+50},95%,70%)`],[1,`hsl(${hue+110},95%,66%)`]]);g.fill();
 P();g.strokeStyle='rgba(70,90,170,.55)';g.lineWidth=.8;g.stroke();
 g.beginPath();g.moveTo(x-s*.92,y+.6);g.lineTo(x+s*.92,y+.6);g.strokeStyle='rgba(255,255,255,.95)';g.lineWidth=1.2;g.lineCap='round';g.stroke();g.restore()}
/* icy herring fin: frosted blue-to-white gradient from the root (rx,ry) toward the tips, pale cyan rib lines, a misty edge band and a rime crust */
function fa7_hfin(g,pp,rx,ry,ribs,lw,al){const P=()=>fkPath(g,pp);let fx=rx,fy=ry,fd=0;for(let i=0;i<pp.length;i+=2){const d=Math.hypot(pp[i]-rx,pp[i+1]-ry);if(d>fd){fd=d;fx=pp[i];fy=pp[i+1]}}
 g.globalAlpha=al==null?.92:al;P();g.fillStyle=fa7_grad(g,rx,ry,fx,fy,[[0,'#2a6ed0'],[.38,'#6ab4f6'],[.72,'#bfe6ff'],[1,'#ffffff']]);g.fill();g.globalAlpha=1;
 g.save();P();g.clip();g.lineCap='round';g.strokeStyle='rgba(140,230,255,.8)';g.lineWidth=1.1;g.beginPath();for(const r of ribs){g.moveTo(r[0],r[1]);g.quadraticCurveTo((r[0]+r[2])/2,(r[1]+r[3])/2*1.04,r[2],r[3])}g.stroke();
 g.translate(.6,-.6);g.strokeStyle='rgba(255,255,255,.55)';g.lineWidth=.7;g.stroke();g.translate(-.6,.6);
 P();g.strokeStyle='rgba(255,255,255,.5)';g.lineWidth=4;g.stroke();g.restore();
 fa7_rime(g,P,.75,2);P();g.lineJoin='round';g.lineWidth=lw||2.2;g.strokeStyle=FKO;g.stroke()}

/* ---------------- 1. Icicle Herring (Common): a slim silver herring with a frosted blue back, a comb of clear icicle spines and prismatic scales ---------------- */
FISHART.herring=(g,t,o)=>{const sw=fkSway(o,5.4,.16),fin=Math.sin(t*7)*.12,fx=o.flex||0,gl=o.glow||0;g.save();g.translate(2,0);g.rotate(-sw*.2);
 const BP=[108,-3,102,-13,85,-22,54,-27,16,-28,-22,-22,-50,-11,-65,-5,-67,0,-65,5,-50,11,-22,22,16,30,54,29,84,20,100,9,107,2],B=()=>fkPath(g,BP);
 // tail: long, deeply forked, frosted blue at the root fading to white-ice tips
 const T=()=>fa7_path(g,['M',12,-4,'Q',-4,-5,-16,-12,'Q',-32,-25,-50,-42,'Q',-46,-27,-39,-15,'Q',-32,-5,-26,0,'Q',-32,5,-39,15,'Q',-46,27,-50,42,'Q',-32,25,-16,12,'Q',-4,5,12,4,'Z']);
 fa7_at(g,-60,0,sw,()=>{T();fkFill(g,fa7_grad(g,8,0,-50,0,[[0,'#2a6ed0'],[.4,'#6ab4f6'],[.75,'#bfe6ff'],[1,'#ffffff']]),0);
  fa7_ribs(g,T,8,0,[-49,-39,-43,-28,-35,-14,-35,14,-43,28,-49,39],.3,'#1a3c8a',1);
  fa7_finfx(g,T,10,0,'#ffffff',[-48,-34,-40,-22,-33,-8,-33,8,-40,22,-48,34],.85,0);
  g.save();T();g.clip();g.globalAlpha=.75;g.strokeStyle=fa7_grad(g,-50,42,-50,-42,[[0,'#ffffff'],[.3,'#c8b4ff'],[.5,'#8ef0ff'],[.7,'#ffd0f0'],[1,'#ffffff']]);g.lineWidth=5;T();g.stroke();g.restore();
  fa7_rime(g,T,.85,2.2);for(const k of [-1,1])fa7_snow(g,-44,33*k,2.4,t*.5*k,'#ffffff',.9);
  T();g.lineJoin='round';g.lineWidth=2.4;g.strokeStyle=FKO;g.stroke()});
 // anal + pelvic fins (small, frosted), dorsal fin mid-back
 fa7_at(g,-40,13,-fin*.6,()=>fa7_hfin(g,[8,-1,3,8,-8,11,-16,7,-15,-2],4,-1,[[2,0,-5,9],[0,0,-11,9],[-3,0,-14,5]],2.2));
 fa7_at(g,6,26,-fin,()=>fa7_hfin(g,[7,-2,0,9,-11,11,-12,-2],3,-2,[[1,0,-4,9],[0,0,-10,9]],2.1));
 fa7_at(g,12,-27,fin*.5,()=>fa7_hfin(g,[14,2,8,-9,-2,-21,-10,-22,-16,-9,-18,3],4,2,[[6,0,2,-18],[2,0,-6,-21],[-2,0,-12,-18],[-6,0,-16,-8]],2.3));
 // icicle spines: a comb of clear crystals running along the back, tallest over the shoulder, chiming gently
 const SP=[[75,-21,17,7],[63.5,-23.6,24,7.8],[51.5,-24.8,21,7.4],[39.5,-25.2,15,6.6],[-8,-23.4,19,7.2],[-21,-20,15,6.6],[-33,-16,12,6],[-44,-11.6,9,5.2]];
 SP.forEach((s,i)=>{const a=-Math.PI/2-.42+Math.sin(t*2.6+i*.8)*.04*(1+fx*2);fa7_spine(g,s[0],s[1]+3,a,s[2]+3,s[3],0)});
 // body: midnight-blue back frosting to ice blue, then mirror silver flanks and a pearly keel
 B();fkFill(g,fa7_grad(g,0,-24,0,27,[[0,'#061648'],[.16,'#0c2e80'],[.3,'#1a56b8'],[.37,'#3a8ee6'],[.41,'#a8dcff'],[.46,'#eef6ff'],[.62,'#f6f8ff'],[.82,'#e2e8fc'],[1,'#aab6e6']]),3);
 g.save();B();g.clip();
 // frosted dusting across the blue back
 g.fillStyle=fa7_grad(g,0,-26,0,-8,[[0,'rgba(255,255,255,.0)'],[.5,'rgba(220,240,255,.22)'],[1,'rgba(220,240,255,0)']]);g.fillRect(-80,-28,200,22);
 // drifting prismatic sheen across the silver
 const sh=Math.sin(t*1.2)*40;g.globalAlpha=.2;g.fillStyle=fa7_grad(g,-80+sh,-10,100+sh,20,[[0,'#ff9ad8'],[.18,'#ffd28a'],[.36,'#a8ffb8'],[.54,'#8ae8ff'],[.72,'#b49aff'],[.9,'#ff9ad8'],[1,'#ffd28a']]);g.fillRect(-80,-12,200,40);g.globalAlpha=1;
 g.restore();
 // a bright frost-cyan seam where the blue back meets the silver
 {g.save();B();g.clip();g.beginPath();g.moveTo(104,-7);g.quadraticCurveTo(40,-15,-66,-3);g.strokeStyle='rgba(140,230,255,.55)';g.lineWidth=4;g.stroke();g.strokeStyle='rgba(255,255,255,.8)';g.lineWidth=1.2;g.stroke();g.restore()}
 // big herring scales on the silver flank, dark edges with a bright lip
 fa7_tex(g,B,-62,86,-8,26,8.6,'#6a7ec0','#ffffff',.22);
 fa7_tex(g,B,-62,86,-26,-8,5.6,'#0a2a6a','#bfe4ff',.16);
 fkShade(g,B,-6,-26,'#071a50',.4);
 fkShade(g,B,14,28,'#7a86d8',.3);
 fa7_speck(g,B,-60,96,-25,-12,26,'#ffffff',.65,.65,11);
 // prismatic scale flashes: individual scales catch the moonlight in rainbow colours
 g.save();B();g.clip();
 [[45.5,8],[15.4,13.3],[-14.7,8],[62.7,-2.7]].forEach((p,i)=>{const k=Math.max(0,Math.sin(t*1.4+i*1.6)),a=Math.pow(k,1.5)*(.9+gl*.1);fa7_prism(g,p[0],p[1],4.6,(i*70+t*30)%360,a)});
 g.restore();
 // silver lateral line with a sliding glint
 {const lc=s=>{const x=88-150*s;return [x,-4+2*s-Math.sin(Math.PI*s)*2.2]};g.save();B();g.clip();g.beginPath();for(let i=0;i<=30;i++){const c=lc(i/30);i?g.lineTo(c[0],c[1]):g.moveTo(c[0],c[1])}
  g.lineCap='round';g.strokeStyle='rgba(40,80,170,.35)';g.lineWidth=2.6;g.stroke();g.translate(0,-.8);g.strokeStyle='rgba(255,255,255,.95)';g.lineWidth=1.2;g.stroke();g.restore();
  for(let k=0;k<2;k++){const c=lc((.12+k*.48+t*.11)%1*.9+.04),w=fa7_tw(t,k*2.4,3);fkSpark(g,c[0],c[1]-.6,2.4+3.4*w,'#ffffff',.35+.65*w)}}
 fa7_rim(g,B,'#cfeeff','#d8c8ff',1,1.7);
 g.save();g.beginPath();g.rect(-70,-40,170,28);g.clip();fa7_rime(g,B,.55,2.6);g.restore();
 fa7_gloss(g,B,90,-14,50,-24,-14,-22,1.7,.6);
 B();g.lineJoin='round';g.lineWidth=3;g.strokeStyle=FKO;g.stroke();
 // frost collars where each icicle grows out of the back
 g.save();B();g.clip();SP.forEach((p,i)=>{const x=p[0]-1,y=p[1]+2.4;g.fillStyle=fa7_rgrad(g,x,y,0,7,[[0,'rgba(255,255,255,.9)'],[.5,'rgba(220,244,255,.55)'],[1,'rgba(220,244,255,0)']]);g.beginPath();g.ellipse(x,y,7,3.4,-.1,0,TAU);g.fill();
  g.fillStyle='#fff';g.beginPath();g.arc(x-3,y+.4,.9,0,TAU);g.arc(x+2.6,y-.2,.8,0,TAU);g.fill()});g.restore();
 fa7_gill2(g,B,95,2,23,Math.PI*.72,Math.PI*1.28,'#203a7e',.55);
 // pectoral: a little frosted fan behind the gill
 fa7_at(g,64,10,-.32+fin,()=>{const P=()=>fa7_path(g,['M',3,-3.5,'Q',-8,-7.5,-22,-.5,'Q',-19,5,-11,5,'Q',-4,5,3,3,'Z']);
  g.globalAlpha=.94;P();g.fillStyle=fa7_grad(g,0,-4,-21,4,[[0,'#ffffff'],[.5,'#cfe6ff'],[1,'#5aa2f0']]);g.fill();g.globalAlpha=1;
  fa7_ribs(g,P,2,0,[-21,-.4,-18,3.4,-12,4.8],.3,'#2a5aa0',.9);fa7_rime(g,P,.7,2);
  g.save();P();g.clip();g.beginPath();g.moveTo(3,-3.5);g.quadraticCurveTo(-8,-7.5,-22,-.5);g.strokeStyle='#ffffff';g.lineWidth=2.4;g.stroke();g.restore();
  P();g.lineJoin='round';g.lineWidth=2;g.strokeStyle=FKO;g.stroke()});
 // upturned jutting lower jaw, a herring's signature
 const J=()=>fa7_path(g,['M',90,6.2,'Q',100,5.6,106.6,3.2,'Q',109.8,2.2,108.8,4.8,'Q',106.8,8.4,100,9.6,'Q',95,10.4,90,9.4,'Z']);
 J();fkFill(g,fa7_grad(g,0,2,0,10,[[0,'#ffffff'],[.6,'#dce6fa'],[1,'#a8b6e2']]),2.1);
 fa7_eye(g,84,-4,11,'#2a7ee0',.35);fa7_lid(g,84,-4,11,fa7_blink(t,2.3),'#2a5ab8');
 fa7_blush(g,88,9,5,'#ff8ab8',.5);
 fa7_smile(g,107.4,3.4,101.4,6.2,95.6,5.8,1.9);g.beginPath();g.arc(95,4.2,1.9,Math.PI*.45,Math.PI*1.05);g.lineWidth=1.3;g.stroke();
 fa7_spec(g,60,-14,.75,.9);
 // icicle tips sparkle in turn
 SP.forEach((s,i)=>{const k=Math.max(0,Math.sin(t*1.7-i*.7))**6;if(k>.05){const a=-Math.PI/2-.42,L=s[2]+3;fkSpark(g,s[0]+Math.cos(a)*L,s[1]+3+Math.sin(a)*L,1.6+3.2*k,'#ffffff',k)}});
 fkSpark(g,26,-6,2.6+fa7_tw(t,1,2.3)*2,'#ffffff',.45+.5*fa7_tw(t,1,2.3));
 fa7_catch(g,o,'#e4f2ff');g.restore()};

/* fluffy cloud outline: base points P (flat x,y list, closed); each edge bulges outward by amount b[i] (array or number) */
function fa7_fluff(g,P,b){const n=P.length/2;let cx=0,cy=0;for(let i=0;i<n;i++){cx+=P[i*2];cy+=P[i*2+1]}cx/=n;cy/=n;g.beginPath();g.moveTo(P[0],P[1]);
 for(let i=0;i<n;i++){const ax=P[i*2],ay=P[i*2+1],bx=P[((i+1)%n)*2],by=P[((i+1)%n)*2+1],mx=(ax+bx)/2,my=(ay+by)/2;let nx=-(by-ay),ny=bx-ax;const d=Math.hypot(nx,ny)||1;nx/=d;ny/=d;
  if(nx*(mx-cx)+ny*(my-cy)<0){nx=-nx;ny=-ny}const k=typeof b==='number'?b:b[i%b.length];g.quadraticCurveTo(mx+nx*k,my+ny*k,bx,by)}g.closePath()}
/* frilly fan fin hinged at the origin: n rays spread from angle a0 to a1 with length L(i); frilled scalloped edge; banded colour */
function fa7_frill(g,a0,a1,n,L,c1,c2,band,al,t,ph){const pts=[];for(let i=0;i<=n;i++){const a=a0+(a1-a0)*i/n,l=L(i/n)*(1+.03*Math.sin(t*5+i+ph));pts.push([Math.cos(a)*l,Math.sin(a)*l])}
 const P=()=>{g.beginPath();g.moveTo(0,0);g.lineTo(pts[0][0],pts[0][1]);for(let i=0;i<n;i++){const p=pts[i],q=pts[i+1],mx=(p[0]+q[0])/2,my=(p[1]+q[1])/2,d=Math.hypot(mx,my)||1;g.quadraticCurveTo(mx+mx/d*5.5,my+my/d*5.5,q[0],q[1])}g.closePath()};
 const Lm=L(.5);g.globalAlpha=al==null?1:al;P();g.fillStyle=fa7_rgrad(g,0,0,0,Lm*1.15,[[0,c1],[1,c2]]);g.fill();g.globalAlpha=1;
 g.save();P();g.clip();
 // concentric bands like a real sculpin's barred fins
 for(const [r,w] of band){g.beginPath();g.arc(0,0,Lm*r,0,TAU);g.strokeStyle='rgba(40,60,170,.32)';g.lineWidth=w;g.stroke()}
 g.strokeStyle='rgba(30,30,110,.32)';g.lineWidth=1.1;g.lineCap='round';g.beginPath();for(const p of pts){g.moveTo(0,0);g.lineTo(p[0]*1.05,p[1]*1.05)}g.stroke();
 P();g.strokeStyle='rgba(255,255,255,.45)';g.lineWidth=6;g.stroke();
 g.fillStyle=fa7_rgrad(g,0,0,0,16,[[0,'rgba(20,10,60,.25)'],[1,'rgba(20,10,60,0)']]);g.fillRect(-18,-18,36,36);g.restore();
 fa7_rime(g,P,.75,2.2);P();g.lineJoin='round';g.lineWidth=2.3;g.strokeStyle=FKO;g.stroke();return pts}

/* ---------------- 2. Snowball Sculpin (Common): a round fluffy snowball of a fish with a huge grumpy frown ---------------- */
FISHART.sculpin=(g,t,o)=>{const sw=fkSway(o,3.6,.15),fin=Math.sin(t*4.4)*.1,fx=o.flex||0,gl=o.glow||0,br=Math.sin(t*1.6);g.save();g.translate(4,2);g.rotate(-sw*.12);
 // base outline: a big round snowball head-body tapering to a short tail stalk
 const BASE=[];{const N=26;for(let i=0;i<N;i++){const a=i/N*TAU,c=Math.cos(a),s=Math.sin(a);let rx=c>0?62:70,ry=s<0?50:44;
   // squash toward the tail: the left side narrows into the stalk
   const tl=Math.max(0,-c),nar=1-.52*Math.pow(tl,3);let x=22+c*(c>0?rx:rx)*(1+.02*br),y=-2+s*ry*nar*(1+.02*br);if(c<-.9)x-=6;BASE.push(x,y)}}
 const FB=[5,4.2,5.4,4.4];
 const B=()=>fa7_fluff(g,BASE,FB);
 // tail: a small rounded fan with frosty bands
 fa7_at(g,-44,-1,sw,()=>{const T=()=>fkPath(g,[6,-6,-10,-12,-30,-22,-46,-20,-56,-8,-58,0,-56,8,-46,20,-30,22,-10,12,6,6]);
  T();fkFill(g,fa7_grad(g,4,0,-58,0,[[0,'#9ab8ff'],[.5,'#6a86f0'],[1,'#c4d4ff']]),2.4);
  g.save();T();g.clip();for(const x of [-20,-34,-46]){g.beginPath();g.moveTo(x,-30);g.quadraticCurveTo(x-6,0,x,30);g.strokeStyle='rgba(40,50,160,.3)';g.lineWidth=3.4;g.stroke()}g.restore();
  fa7_ribs(g,T,6,0,[-52,-15,-57,-5,-57,5,-52,15,-40,21,-40,-21],.3,'#20206a');
  fa7_finfx(g,T,6,0,'#ffffff',null,.9,0);fa7_rime(g,T,.85,2.2);T();g.lineJoin='round';g.lineWidth=2.4;g.strokeStyle=FKO;g.stroke()});
 // spiny frosty dorsal: five frosty curved spines tapering to points, with pale periwinkle webbing that fades out toward the tips
 {const fl=1+fin*.5,S=[[-12,-45,15],[0,-50,20],[12,-53,23],[24,-54,21],[36,-52,15]].map((s,i)=>{const H=s[2]*fl,lean=-5-1.5*Math.sin(t*2.2+i*.9)*(1+fx*2);return {bx:s[0],by:s[1],tx:s[0]+lean,ty:s[1]-H,cx:s[0]+lean*.3-2,cy:s[1]-H*.55}});
  // webbing: reaches ~70% up each spine, scalloped between them, fading out upward
  const WEB=()=>{g.beginPath();g.moveTo(S[0].bx,S[0].by+8);for(let i=0;i<S.length;i++){const s=S[i],u=.7,wx=s.bx+(s.tx-s.bx)*u,wy=s.by+(s.ty-s.by)*u;g.lineTo(wx,wy);
    if(i<S.length-1){const n=S[i+1],nx=n.bx+(n.tx-n.bx)*u,ny=n.by+(n.ty-n.by)*u;g.quadraticCurveTo((wx+nx)/2,(wy+ny)/2+7,nx,ny)}}g.lineTo(S[4].bx,S[4].by+8);g.closePath()};
  WEB();g.fillStyle=fa7_grad(g,0,-50,0,-70,[[0,'rgba(170,186,250,.95)'],[.55,'rgba(190,204,255,.6)'],[1,'rgba(220,230,255,0)']]);g.fill();
  g.save();WEB();g.clip();g.strokeStyle='rgba(120,140,230,.45)';g.lineWidth=1;g.lineCap='round';g.beginPath();for(let i=0;i<4;i++){const a=S[i],b=S[i+1];for(const u of [.3,.5]){const ax=a.bx+(a.tx-a.bx)*u,ay=a.by+(a.ty-a.by)*u,bx=b.bx+(b.tx-b.bx)*u,by=b.by+(b.ty-b.by)*u;g.moveTo(ax,ay);g.quadraticCurveTo((ax+bx)/2,(ay+by)/2+4,bx,by)}}g.stroke();g.restore();
  WEB();g.strokeStyle=fa7_grad(g,0,-50,0,-68,[[0,FKO],[1,'rgba(27,16,36,0)']]);g.lineWidth=1.6;g.lineJoin='round';g.stroke();
  // the spines: tapered, slightly curved, frosty white over periwinkle, each with a lit facet
  S.forEach((s,i)=>{const w=4.6,SP=()=>{g.beginPath();g.moveTo(s.bx-w,s.by+3);g.quadraticCurveTo(s.cx-w*.55,s.cy,s.tx,s.ty);g.quadraticCurveTo(s.cx+w*.55,s.cy,s.bx+w,s.by+3);g.closePath()};
   SP();g.fillStyle=fa7_grad(g,s.bx,s.by,s.tx,s.ty,[[0,'#8a9cf0'],[.35,'#d4defc'],[.8,'#ffffff'],[1,'#ffffff']]);g.fill();
   g.save();SP();g.clip();g.beginPath();g.moveTo(s.bx-w*.45,s.by);g.quadraticCurveTo(s.cx-w*.3,s.cy,s.tx-.3,s.ty+2);g.strokeStyle='rgba(255,255,255,.95)';g.lineWidth=1.2;g.lineCap='round';g.stroke();
   g.beginPath();g.moveTo(s.bx+w*.5,s.by);g.quadraticCurveTo(s.cx+w*.3,s.cy,s.tx+.2,s.ty+3);g.strokeStyle='rgba(90,110,210,.45)';g.lineWidth=1.1;g.stroke();g.restore();
   SP();g.lineJoin='round';g.lineWidth=2;g.strokeStyle=FKO;g.stroke();
   const k=Math.max(0,Math.sin(t*1.8-i*1.1))**3;if((i===2||i===3)&&k>.08)fkSpark(g,s.tx,s.ty-1,1.6+3*k,'#ffffff',k)})}
 // body: snow-white puff with soft blue shadowing
 B();fkFill(g,fa7_rgrad(g,30,-24,6,92,[[0,'#ffffff'],[.45,'#f6faff'],[.72,'#dfeaff'],[1,'#b4c8f4']]),3);
 g.save();B();g.clip();
 // soft snow "clumps" for a fluffy, packed-snow feel
 [[0,-30,18],[30,-38,16],[-24,-14,16],[56,-26,14],[-6,10,20],[34,6,22],[-30,18,12],[64,4,14]].forEach((c,i)=>{g.fillStyle=fa7_rgrad(g,c[0]-c[2]*.3,c[1]-c[2]*.35,0,c[2],[[0,'rgba(255,255,255,.95)'],[.6,'rgba(255,255,255,.3)'],[1,'rgba(200,220,255,0)']]);g.beginPath();g.arc(c[0],c[1],c[2],0,TAU);g.fill();
  g.beginPath();g.arc(c[0]+c[2]*.15,c[1]+c[2]*.2,c[2]*.95,Math.PI*.15,Math.PI*.85);g.strokeStyle='rgba(120,150,220,.18)';g.lineWidth=2;g.stroke()});
 g.restore();
 fkShade(g,B,8,46,'#7a90e0',.4);
 fkShade(g,B,-20,-54,'#c8d8ff',.2);
 // pale blue speckles, like a snowball rolled over blue ice
 fa7_speck(g,B,-40,96,-46,40,46,'#8ab4f2',.75,1.5,13);
 fa7_speck(g,B,-40,96,-46,40,26,'#5a86e0',.6,1.1,29);
 fa7_speck(g,B,-30,90,-44,30,30,'#ffffff',.9,1.1,41);
 fa7_rim(g,B,'#ffffff','#9ab0f0',1,2);
 fa7_gloss(g,B,64,-40,30,-52,-12,-42,2,.7);
 B();g.lineJoin='round';g.lineWidth=3;g.strokeStyle=FKO;g.stroke();
 // frosted gill: a soft blue crescent
 fa7_gill2(g,B,98,-2,46,Math.PI*.76,Math.PI*1.2,'#4a62b8',.5);
 // frost tufts on the head: little sprigs of rime crystals
 // frost tufts on the head: fluffy rime curls, each tipped with a twinkle
 const tuft=(x,y,a,s,i)=>fa7_at(g,x,y,a+Math.sin(t*2.6+i)*.07*(1+fx*2),()=>{const k=fa7_tw(t,i*1.7,2.2);
  for(const [dx,ln,cu] of [[-3,.8,-1],[0,1,1],[3,.75,1.4]]){const L=13*s*ln;fa7_strand(g,[dx*s,2, dx*s-2*cu,-L*.45, dx*s+3*cu*s,-L*.8, dx*s+5*cu*s+2,-L],5.6*s,1.2,'#f4f8ff',1.7)}
  g.beginPath();g.ellipse(0,1.5,6.5*s,2.8*s,0,0,TAU);g.fillStyle='#ffffff';g.fill();
  fkSpark(g,5*s+2,-13*s,1.4+2.4*k*s,'#ffffff',.3+.7*k)});
 tuft(57,-44,.2,1,0);tuft(66,-38,.55,.8,1);
 // small banded pelvic fan under the belly, behind the big pectoral
 fa7_at(g,26,36,-fin*.6,()=>{g.scale(.72,.72);fa7_frill(g,1.2,2.6,7,u=>26+7*Math.sin(Math.PI*u),'#dce6ff','#6a7ee8',[[.55,3],[.8,2.6]],.95,t,1)});
 // near frilly fan pectoral: big, banded periwinkle, rippling
 fa7_at(g,40,16,-.05+fin,()=>{fa7_frill(g,1.95,3.75,9,u=>30+12*Math.sin(Math.PI*u),'#d4e0ff','#5a6ee8',[[.5,3.4],[.78,3]],.97,t,0)});
 // a clear soft pink cheek under the eye
 g.save();g.beginPath();g.ellipse(62,5,8.6,5,-.1,0,TAU);g.fillStyle='rgba(255,150,184,.5)';g.fill();g.fillStyle=fa7_rgrad(g,62,5,0,9,[[0,'rgba(255,130,170,.45)'],[1,'rgba(255,130,170,0)']]);g.fill();
 g.beginPath();g.ellipse(59.5,3.4,3,1.4,-.3,0,TAU);g.fillStyle='rgba(255,255,255,.55)';g.fill();g.restore();
 // the eye: big, but half-lidded and glowering under a heavy brow
 const ex=74,ey=-14,er=12.5;
 fa7_eye(g,ex,ey,er,'#3a6ee0',.55);fa7_lid(g,ex,ey,er,Math.max(.4,fa7_blink(t,3.1)),'#d8e6ff');
 // heavy fluffy brow, slanting down toward the snout (permanent grump)
 {const by=Math.sin(t*1.3)*.8;const BR=()=>fa7_path(g,['M',54,-33+by,'Q',70,-42+by,90,-25+by,'Q',94,-21+by,89,-18+by,'Q',72,-27+by,56,-25+by,'Q',50,-28+by,54,-33+by,'Z']);
  BR();fkFill(g,fa7_grad(g,0,-40,0,-19,[[0,'#eef4ff'],[.5,'#b8c8f4'],[1,'#6a82d8']]),2.6);
  g.save();BR();g.clip();g.strokeStyle='rgba(110,140,220,.45)';g.lineWidth=1;g.beginPath();for(let i=0;i<7;i++){const x=59+i*4.4;g.moveTo(x,-30+by+i*.6);g.lineTo(x+2.4,-24.5+by+i*.8)}g.stroke();g.restore();
  g.beginPath();g.moveTo(60,-30+by);g.quadraticCurveTo(70,-36+by,84,-25+by);g.strokeStyle='rgba(255,255,255,.9)';g.lineWidth=1.4;g.stroke()}
 // the HUGE downturned frown with a pouty lower lip
 const mo=Math.sin(t*1.1)*.8;
 {const F=(o2)=>{g.beginPath();g.moveTo(56,24+o2);g.quadraticCurveTo(80,6+mo+o2,106,20+o2)};
  const L=()=>fa7_path(g,['M',60,24,'Q',80,8+mo,102,20,'Q',104,26,98,27,'Q',80,18+mo,64,30,'Q',58,29,60,24,'Z']);
  L();fkFill(g,fa7_grad(g,0,14,0,30,[[0,'#ff9ab8'],[1,'#d8608a']]),2.2);
  g.save();L();g.clip();g.beginPath();g.moveTo(66,26);g.quadraticCurveTo(82,17+mo,98,23);g.strokeStyle='rgba(255,255,255,.65)';g.lineWidth=1.4;g.stroke();g.restore();
  F(0);g.strokeStyle=FKO;g.lineWidth=3;g.lineCap='round';g.stroke();
  g.lineWidth=1.6;g.beginPath();g.moveTo(55,21);g.quadraticCurveTo(52,25,54,29);g.moveTo(106,17);g.quadraticCurveTo(110,20,108,24);g.stroke()}
 // a huffy little puff of cold breath from the mouth now and then
 {const p=(t*.4)%1;if(p<.7){const q=p/.7,a=Math.sin(Math.PI*q)*.5,x=107+q*6,y=4-q*20;g.save();g.lineCap='round';
   // three puffs shrinking along a little curl, trailing the lead puff
   [[0,0,2.2+q*2.6],[-3.4-q*2,2.8+q*1.5,1.6+q*1.8],[-5.6-q*3,6.2+q*2.4,1.1+q*1.2]].forEach(([dx,dy,r],i)=>{const px=x+dx,py=y+dy,al=a*(1-i*.22);
    g.fillStyle=fa7_rgrad(g,px-r*.3,py-r*.3,0,r*1.15,[[0,`rgba(255,255,255,${al*1.3})`],[.6,`rgba(228,248,255,${al})`],[1,`rgba(170,230,255,0)`]]);g.beginPath();g.arc(px,py,r*1.15,0,TAU);g.fill();
    g.strokeStyle=`rgba(150,225,255,${al*.5})`;g.lineWidth=1.6;g.beginPath();g.arc(px,py,r,Math.PI*1.05,Math.PI*1.95);g.stroke()});
   // a thin curl of mist behind the lead puff
   g.beginPath();g.moveTo(x-7-q*4,y+9+q*3);g.quadraticCurveTo(x-10-q*4,y+3,x-4,y+2);g.strokeStyle=`rgba(200,240,255,${a*.6})`;g.lineWidth=1.1;g.stroke();g.restore()}}
 fa7_spec(g,22,-34,.9,.9);
 fkSpark(g,-30,-44,2.4+fa7_tw(t,2,2)*2,'#ffffff',.4+.5*fa7_tw(t,2,2));
 fa7_snow(g,-60,-40+Math.sin(t*.8)*3,3,t*.5,'#e8f4ff',.5+.4*fa7_tw(t,3,1.7));
 fa7_catch(g,o,'#eef4ff');g.restore()};

/* faceted crystal fin: polygon pts (sharp corners), facet lines from root (rx,ry) to every vertex, translucent ice fill, bright edges, a shimmer band */
function fa7_icefin(g,pts,rx,ry,t,ph,al,c1,c2){const P=()=>fa7_poly(g,pts);let x0=1e9,x1=-1e9,y0=1e9,y1=-1e9;for(let i=0;i<pts.length;i+=2){x0=Math.min(x0,pts[i]);x1=Math.max(x1,pts[i]);y0=Math.min(y0,pts[i+1]);y1=Math.max(y1,pts[i+1])}
 g.globalAlpha=al==null?.9:al;P();g.fillStyle=fa7_grad(g,rx,ry,(x0+x1)/2+(x0+x1)/2-rx,(y0+y1)/2+(y0+y1)/2-ry,[[0,c1||'#2a7ae8'],[.4,'#5ab8f6'],[.75,'#b4e8ff'],[1,c2||'#ffffff']]);g.fill();g.globalAlpha=1;
 g.save();P();g.clip();
 // alternating lit / shaded facets
 for(let i=0;i<pts.length-2;i+=2){if((i/2)%2)continue;g.beginPath();g.moveTo(rx,ry);g.lineTo(pts[i],pts[i+1]);g.lineTo(pts[i+2],pts[i+3]);g.closePath();g.fillStyle='rgba(255,255,255,.16)';g.fill()}
 g.strokeStyle='rgba(40,110,200,.38)';g.lineWidth=1;g.beginPath();for(let i=0;i<pts.length;i+=2){g.moveTo(rx,ry);g.lineTo(pts[i],pts[i+1])}g.stroke();
 const sx=((t*40+ph*50)%(x1-x0+80))+x0-40;g.fillStyle=fa7_grad(g,sx-12,y0,sx+12,y1,[[0,'rgba(255,255,255,0)'],[.5,'rgba(220,255,255,.55)'],[1,'rgba(255,255,255,0)']]);g.fillRect(x0-5,y0-5,x1-x0+10,y1-y0+10);
 P();g.strokeStyle='rgba(60,140,240,.22)';g.lineWidth=12;g.stroke();
 // prismatic rim: a thin violet-to-mint-to-pink band just inside the edge
 P();g.strokeStyle=fa7_grad(g,x0,y0,x1,y1,[[0,'#c88aff'],[.28,'#8affd8'],[.5,'#ffffff'],[.72,'#ff9ad8'],[1,'#c88aff']]);g.lineWidth=3.8;g.globalAlpha=.92;g.stroke();g.globalAlpha=1;
 g.fillStyle=fa7_rgrad(g,rx,ry,0,18,[[0,'rgba(20,40,100,.25)'],[1,'rgba(20,40,100,0)']]);g.fillRect(rx-20,ry-20,40,40);g.restore();
 P();g.lineJoin='miter';g.miterLimit=3;g.lineWidth=2.2;g.strokeStyle=FKO;g.stroke();g.lineJoin='round'}

/* ---------------- 3. Frost Narwhalfin (Rare): a sleek pale-blue fish with silver bands and a spiral horn of living ice ---------------- */
FISHART.narwhal=(g,t,o)=>{const sw=fkSway(o,4,.13),fin=Math.sin(t*4.6)*.1,fx=o.flex||0,gl=o.glow||0,pu=.5+.5*Math.sin(t*2.1);g.save();g.translate(-6,2);g.scale(.92,.92);g.rotate(-sw*.16);
 const BP=[70,-3,66,-14,52,-24,26,-29,-6,-27,-36,-19,-58,-9,-70,-4,-72,0,-70,4,-58,9,-36,17,-6,24,26,26,52,21,66,11],B=()=>fkPath(g,BP);
 // cold aura and slowly orbiting frost motes
 g.save();g.translate(4,-6);g.scale(1,.6);g.fillStyle=fa7_rgrad(g,0,0,20,118,[[0,'rgba(150,236,255,.2)'],[.45,'rgba(190,170,255,.16)'],[.75,'rgba(130,220,255,.08)'],[1,'rgba(130,220,255,0)']]);if(g.canvas!==FKSIL){g.beginPath();g.arc(0,0,118,0,TAU);g.fill()}
 // aurora tint: a soft lavender and mint drift through the halo
 const au=Math.sin(t*.5)*30;g.fillStyle=fa7_grad(g,-90+au,0,90+au,0,[[0,'rgba(200,150,255,0)'],[.3,`rgba(200,150,255,${.14+gl*.1})`],[.55,`rgba(140,255,220,${.1+gl*.08})`],[.8,`rgba(255,170,230,${.1+gl*.08})`],[1,'rgba(255,170,230,0)']]);if(g.canvas!==FKSIL){g.beginPath();g.arc(0,0,110,0,TAU);g.fill()}g.restore();
 if(g.canvas!==FKSIL)fkGlow(g,0,-4,100,'#8ad8ff',.12+.06*pu+gl*.28);
 for(let i=0;i<10;i++){const a=t*.25+i/10*TAU,x=Math.cos(a)*104,y=-6+Math.sin(a)*58,w=fa7_tw(t,i*1.4,2.4);if(x<-112||x>110)continue;g.beginPath();g.arc(x,y,.9+.9*w,0,TAU);g.fillStyle=i%3?'#d8f8ff':'#ffffff';g.globalAlpha=.3+.5*w;g.fill();g.globalAlpha=1}
 // crescent tail with crystal shards along its trailing edge
 fa7_at(g,-66,0,sw,()=>{fa7_icefin(g,[8,-4,-8,-9,-22,-22,-36,-40,-44,-50,-42,-38,-44,-32,-38,-22,-34,-12,-30,0,-34,12,-38,22,-44,32,-42,38,-44,50,-36,40,-22,22,-8,9,8,4],4,0,t,0,.95,'#1a5ad8','#efe6ff')});
 // far pectoral
 fa7_at(g,30,14,.25-fin,()=>{g.scale(.75,.75);fa7_icefin(g,[4,-4,-12,-7,-28,-6,-44,2,-34,6,-40,13,-24,13,-12,9,4,4],0,0,t,2,.75,'#2a7ae0','#bfe8ff')});
 // sweeping crystal dorsal sail
 fa7_at(g,-4,-25,fin*.4,()=>fa7_icefin(g,[22,4,12,-8,0,-17,-12,-23,-14,-14,-22,-18,-28,-9,-36,-11,-34,-2,-40,4],-6,2,t,1,.94,'#2a86e8','#f0e8ff'));
 // small anal fin
 fa7_at(g,-38,16,-fin*.6,()=>fa7_icefin(g,[10,-2,4,8,-4,14,-8,10,-14,16,-16,8,-12,0],0,0,t,3,.9,'#3aa6f4','#f0fcff'));
 // body: pale ice-blue with a deeper teal-blue back and a pearly belly
 B();fkFill(g,fa7_grad(g,0,-29,0,26,[[0,'#0c2a66'],[.2,'#1a54a8'],[.38,'#3a90e0'],[.52,'#8ed0ff'],[.66,'#d4f0ff'],[.86,'#ece4ff'],[1,'#b2a8ee']]),3);
 g.save();B();g.clip();
 // narwhal mottling on the back
 [[48,-18,3.4],[38,-22,2.6],[28,-16,3],[16,-23,3.6],[4,-17,2.6],[-8,-22,3.2],[-20,-15,2.6],[-30,-12,2.2],[-42,-9,2],[22,-9,2],[-2,-10,2.2],[44,-10,2]].forEach(m=>{g.fillStyle='rgba(10,36,100,.45)';g.beginPath();g.ellipse(m[0],m[1],m[2]*1.3,m[2],-.2,0,TAU);g.fill();g.fillStyle='rgba(180,230,255,.35)';g.beginPath();g.ellipse(m[0]-.6,m[1]-.8,m[2]*.6,m[2]*.4,-.2,0,TAU);g.fill()});
 // silver bands: brushed-metal stripes wrapping the body, each with a travelling glint
 const sx=Math.sin(t*1.2)*30;
 [[40,5],[22,5.4],[4,5.4],[-14,5],[-31,4.4],[-47,3.6]].forEach((b,i)=>{const x=b[0],w=b[1],P=()=>fa7_path(g,['M',x+w*.5,-34,'Q',x-w*.1,0,x+w*.5,34,'L',x-w*.5,34,'Q',x-w*1.1,0,x-w*.5,-34,'Z']);
  P();g.fillStyle=fa7_grad(g,0,-30+sx*.3,0,30+sx*.3,[[0,'rgba(190,214,255,.7)'],[.3,'rgba(255,255,255,.92)'],[.45,'rgba(150,186,236,.75)'],[.62,'rgba(250,252,255,.9)'],[1,'rgba(180,200,250,.6)']]);g.fill();
  g.save();P();g.clip();P();g.strokeStyle='rgba(255,255,255,.6)';g.lineWidth=3.4;g.stroke();g.restore();
  P();g.strokeStyle='rgba(40,70,150,.22)';g.lineWidth=.8;g.stroke();
  g.beginPath();g.moveTo(x+w*.15,-30);g.quadraticCurveTo(x-w*.45,0,x+w*.15,30);g.strokeStyle='rgba(255,255,255,.9)';g.lineWidth=1;g.stroke()});
 // drifting mint / lilac / pink sheen
 g.globalAlpha=.2;g.fillStyle=fa7_grad(g,-70+sx,-20,80+sx,20,[[0,'#8af0ff'],[.3,'#d0b0ff'],[.55,'#9affd8'],[.8,'#ffb4e4'],[1,'#ffffff']]);g.fillRect(-80,-30,160,60);g.globalAlpha=1;
 g.restore();
 fa7_tex(g,B,-66,60,-28,24,6,'#2a5ab0','#ffffff',.12);
 fkShade(g,B,-6,-30,'#0a2a6a',.35);
 fkShade(g,B,12,26,'#6a8ae0',.3);
 fa7_speck(g,B,-60,66,-26,-8,22,'#ffffff',.6,.6,9);
 // glowing frost lateral line
 {const lc=s=>{const x=54-120*s;return [x,-2+2*s-Math.sin(Math.PI*s)*2]};g.save();B();g.clip();g.globalCompositeOperation='lighter';g.beginPath();for(let i=0;i<=24;i++){const c=lc(i/24);i?g.lineTo(c[0],c[1]):g.moveTo(c[0],c[1])}
  g.lineCap='round';g.strokeStyle=`rgba(90,230,255,${.25+.2*pu+gl*.2})`;g.lineWidth=5;g.stroke();g.strokeStyle='rgba(230,255,255,.8)';g.lineWidth=1.3;g.stroke();g.restore();
  const c=lc((t*.35)%1);fkSpark(g,c[0],c[1],2.4+3*fa7_tw(t,1,4),'#ffffff',.8)}
 fa7_rim(g,B,'#d8f6ff','#bfe0ff',1,1.8);
 fa7_gloss(g,B,58,-17,30,-28,-24,-22,1.8,.65);
 B();g.lineJoin='round';g.lineWidth=3;g.strokeStyle=FKO;g.stroke();
 fa7_gill2(g,B,64,0,22,Math.PI*.72,Math.PI*1.28,'#1e4486',.55);
 // THE HORN: a long tapering spiral of translucent living ice
 {const hx=66,hy=-5.5,L=58,ang=-.08,tw=t*1.6;fa7_at(g,hx,hy,ang,()=>{const W=10.6,P=()=>fa7_path(g,['M',-4,-W,'Q',L*.45,-W*.62,L,0,'Q',L*.45,W*.62,-4,W,'Z']);
   fkGlow(g,L*.55,0,38,'#9ae8ff',.2+.1*pu+gl*.3);
   g.globalAlpha=.95;P();g.fillStyle=fa7_grad(g,0,-W,0,W,[[0,'#ffffff'],[.28,'#dcf8ff'],[.6,'#8ad8ff'],[1,'#3a8ee6']]);g.fill();g.globalAlpha=1;
   g.save();P();g.clip();
   // soft inner cyan core
   g.globalCompositeOperation='lighter';g.fillStyle=fa7_grad(g,0,-W*.45,0,W*.45,[[0,'rgba(90,220,255,0)'],[.5,`rgba(120,236,255,${.45+.15*pu+gl*.2})`],[1,'rgba(90,220,255,0)']]);g.beginPath();g.moveTo(-4,-W*.45);g.quadraticCurveTo(L*.5,-W*.2,L,0);g.quadraticCurveTo(L*.5,W*.2,-4,W*.45);g.closePath();g.fill();g.globalCompositeOperation='source-over';
   // the helix: dark twisted bands alternating with the light ice, each light band with a bright leading rim; the twist creeps toward the tip
   const wAt=x=>W*(1-Math.max(0,x)/L*.9),cv=(x,w,dir)=>{g.moveTo(x-w*.95,-w);g.quadraticCurveTo(x+w*.15,0,x+w*.95,w)};
   let x=-12+(tw%1)*7;while(x<L){const w0=wAt(x),p=4+w0*.6,x1=x+p*.5,w1=wAt(x1);
    g.beginPath();cv(x,w0);g.lineTo(x1+w1*.95,w1);g.quadraticCurveTo(x1+w1*.15,0,x1-w1*.95,-w1);g.closePath();g.fillStyle=fa7_grad(g,0,-w0,0,w0,[[0,'rgba(50,120,215,.3)'],[.5,'rgba(30,90,190,.62)'],[1,'rgba(20,70,160,.72)']]);g.fill();
    g.beginPath();cv(x1+.9,w1);g.strokeStyle='rgba(255,255,255,.9)';g.lineWidth=1.2;g.lineCap='round';g.stroke();x+=p}
   // a bright highlight spiralling along the top
   g.beginPath();g.moveTo(-2,-W*.62);g.quadraticCurveTo(L*.5,-W*.42,L*.95,-.6);g.strokeStyle='rgba(255,255,255,.95)';g.lineWidth=1.7;g.stroke();g.restore();
   P();g.lineJoin='round';g.lineWidth=2.4;g.strokeStyle=FKO;g.stroke();
   // the horn grows out of the snout through a soft glow ring and three small frost facets
   g.fillStyle=fa7_rgrad(g,-1,0,W*.5,W*1.7,[[0,'rgba(220,248,255,.55)'],[1,'rgba(220,248,255,0)']]);g.beginPath();g.ellipse(-1,0,W*1.7,W*1.7,0,0,TAU);g.fill();
   [[-3,-W+1,3,-W-5,9,-W+1.5],[-3,W-1,3,W+5,9,W-1.5],[-6,-W*.35,-11,0,-6,W*.35]].forEach(f=>{fa7_poly(g,f);fkFill(g,fa7_grad(g,f[0],f[1],f[4],f[5],[[0,'#ffffff'],[1,'#9ad8fc']]),1.6)});
   // sparkles running up the horn and a star at its tip
   for(let k=0;k<3;k++){const u=(t*.4+k/3)%1,x=u*L,w=Math.sin(Math.PI*u);fkSpark(g,x,-W*(1-u*.86)*.3,1.4+2.6*w,'#ffffff',.3+.7*w)}
   const kt=.5+.5*Math.sin(t*3.2);fkGlow(g,L,0,13,'#d8d0ff',.45+.3*kt+gl*.3);fkSpark(g,L+1,0,4+4*kt+gl*3,'#ffffff',.9)})}
 // near pectoral: a crystal blade
 fa7_at(g,32,10,.36+fin,()=>fa7_icefin(g,[4,-4,-12,-7,-28,-6,-44,2,-34,6,-40,13,-24,13,-12,9,4,4],0,0,t,2.6,.94,'#3a9ef4','#f4eeff'));
 fa7_eye(g,46,-7,11,'#1ab0d8',.4);fa7_lid(g,46,-7,11,fa7_blink(t,.6),'#3a7ad0');
 fa7_blush(g,56,6,5,'#9ae0ff',.5);
 fa7_mouth(g,68,7,63,10.5,57,8.5,2,'#a8d8ff');
 fa7_spec(g,22,-20,.8,.95);
 // drifting snowflakes and twinkles
 for(let k=0;k<3;k++){const w=fa7_tw(t,k*2.3+.4,1.8),x=[-96,30,-30][k]+Math.sin(t*.7+k)*4,y=[-46,-62,48][k]+Math.cos(t*.6+k*2)*3;fa7_snow(g,x,y,3+1.4*w,t*.4+k,'#e8f8ff',.45+.45*w)}
 [[92,-34,4.5],[-64,-34,4],[70,34,3.4]].forEach(([x,y,r],i)=>{const k=fa7_tw(t,i*1.9,2.5);fkSpark(g,x,y,r*(.6+.5*k)*(1+gl*.4),'#ffffff',.35+.6*k)});
 fa7_catch(g,o,'#c8f6ff',1.2);g.restore()};

/* glowing ice crack: a jagged polyline drawn as a soft additive glow, a bright core and a hairline white centre */
function fa7_crack(g,pts,a,w){g.save();g.lineCap='round';g.lineJoin='round';const P=()=>{g.beginPath();g.moveTo(pts[0],pts[1]);for(let i=2;i<pts.length;i+=2)g.lineTo(pts[i],pts[i+1])};
 g.globalCompositeOperation='lighter';P();g.strokeStyle=`rgba(60,200,255,${Math.min(1,.2*a)})`;g.lineWidth=(w||2)*4.2;g.stroke();P();g.strokeStyle=`rgba(120,236,255,${Math.min(1,.5*a)})`;g.lineWidth=(w||2)*1.7;g.stroke();
 g.globalCompositeOperation='source-over';P();g.strokeStyle=`rgba(235,255,255,${Math.min(1,.45+.5*a)})`;g.lineWidth=(w||2)*.5;g.stroke();g.restore()}
/* a thin curling ribbon of frosty breath fading white to cyan, with two small puffs shrinking along it; p 0..1 is its life */
function fa7_wisp(g,x,y,p,s,dir){if(p<=0||p>=1)return;const a=Math.sin(Math.PI*p)*.5,L=(9+p*8)*s;g.save();g.translate(x+p*8*s,y-p*20*s);g.rotate(-.5-p*.6);g.lineCap='round';
 const R=()=>{g.beginPath();g.moveTo(-L*.3,L*.1*dir);g.quadraticCurveTo(0,-L*.3*dir,L*.5,0);g.quadraticCurveTo(L*.85,L*.25*dir,L,-L*.1*dir)};
 R();g.strokeStyle=fa7_grad(g,-L*.3,0,L,0,[[0,`rgba(255,255,255,${a*.25})`],[.5,`rgba(220,246,255,${a*.35})`],[1,'rgba(140,230,255,0)']]);g.lineWidth=(3.6-p*1.5)*s;g.stroke();
 R();g.strokeStyle=fa7_grad(g,-L*.3,0,L,0,[[0,`rgba(255,255,255,${a*.9})`],[.6,`rgba(210,244,255,${a*.6})`],[1,'rgba(140,230,255,0)']]);g.lineWidth=(1.5-p*.6)*s;g.stroke();
 for(const [u,r,al] of [[.55,2.4,.8],[.95,1.6,.5]]){const px=L*u,py=(u<.7?-L*.12:0)*dir,rr=r*s*(1+p*.4);g.fillStyle=fa7_rgrad(g,px,py,0,rr,[[0,`rgba(255,255,255,${a*al})`],[1,'rgba(160,230,255,0)']]);g.beginPath();g.arc(px,py,rr,0,TAU);g.fill()}
 g.restore()}
/* a big jagged glacier shard standing at (x,y): faceted ice with a lit left plane, a shaded right plane, a ridge line and a twinkle at the tip */
function fa7_shard(g,x,y,H,w,lean,t,i){const pts=[-w*.5,3,-w*.46,-H*.42,-w*.18,-H*.78,lean,-H,w*.3,-H*.6,w*.52,-H*.2,w*.5,3],P=()=>{g.beginPath();g.moveTo(x+pts[0],y+pts[1]);for(let k=2;k<pts.length;k+=2)g.lineTo(x+pts[k],y+pts[k+1]);g.closePath()};
 P();g.fillStyle=fa7_grad(g,x,y,x+lean,y-H,[[0,'#2a6ec0'],[.3,'#5aaef0'],[.62,'#b4e6ff'],[1,'#ffffff']]);g.fill();
 g.save();P();g.clip();
 g.beginPath();g.moveTo(x+lean,y-H);g.lineTo(x-w*.18,y-H*.78);g.lineTo(x-w*.46,y-H*.42);g.lineTo(x-w*.5,y+3);g.lineTo(x+lean*.3,y+3);g.closePath();g.fillStyle='rgba(255,255,255,.3)';g.fill();
 g.beginPath();g.moveTo(x+lean,y-H);g.lineTo(x+w*.3,y-H*.6);g.lineTo(x+w*.52,y-H*.2);g.lineTo(x+w*.5,y+3);g.lineTo(x+lean*.3,y+3);g.closePath();g.fillStyle='rgba(20,60,140,.28)';g.fill();
 g.beginPath();g.moveTo(x+lean,y-H);g.lineTo(x+lean*.3,y+3);g.strokeStyle='rgba(255,255,255,.55)';g.lineWidth=1;g.stroke();
 g.beginPath();g.moveTo(x+lean-1,y-H+2);g.lineTo(x-w*.3,y-H*.3);g.strokeStyle='rgba(255,255,255,.9)';g.lineWidth=1.3;g.lineCap='round';g.stroke();
 g.fillStyle=fa7_rgrad(g,x,y,0,H*.6,[[0,'rgba(120,220,255,.35)'],[1,'rgba(120,220,255,0)']]);g.fillRect(x-w,y-H,w*2,H+4);
 g.restore();P();g.lineJoin='miter';g.miterLimit=4;g.lineWidth=2.2;g.strokeStyle=FKO;g.stroke();g.lineJoin='round';
 const k=fa7_tw(t,i*1.3,2.3);fkSpark(g,x+lean,y-H-1,(2+3.4*k)*Math.min(1,w/14),'#ffffff',.4+.6*k)}
/* a little clump of packed snow sitting on a shard shoulder */
function fa7_clump(g,x,y,s){g.save();g.translate(x,y);g.scale(s,s);fa7_fluff(g,[-7,2,-5,-3,0,-5,5,-3,7,2,3,4,-3,4],1.6);g.fillStyle=fa7_grad(g,0,-5,0,4,[[0,'#ffffff'],[1,'#c4e2ff']]);g.fill();g.strokeStyle='rgba(30,70,140,.6)';g.lineWidth=1.2/s;g.stroke();
 g.beginPath();g.ellipse(-2,-2,2.6,1.1,-.2,0,TAU);g.fillStyle='rgba(255,255,255,.95)';g.fill();g.restore()}
/* faceted ice-plate fin (matches the head armour): sharp polygon, facet fan from the root, 2-3 ribs, a bright edge highlight */
function fa7_platefin(g,pts,rx,ry,ribs){const P=()=>fa7_poly(g,pts);let x0=1e9,x1=-1e9,y1=-1e9;for(let i=0;i<pts.length;i+=2){x0=Math.min(x0,pts[i]);x1=Math.max(x1,pts[i]);y1=Math.max(y1,pts[i+1])}
 P();g.fillStyle=fa7_grad(g,rx,ry,(x0+x1)/2,y1,[[0,'#1a4a86'],[.4,'#3a86d0'],[.75,'#9ad6ff'],[1,'#e8f8ff']]);g.fill();
 g.save();P();g.clip();for(let i=0;i<pts.length-2;i+=2){if((i/2)%2)continue;g.beginPath();g.moveTo(rx,ry);g.lineTo(pts[i],pts[i+1]);g.lineTo(pts[i+2],pts[i+3]);g.closePath();g.fillStyle='rgba(255,255,255,.14)';g.fill()}
 g.strokeStyle='rgba(20,40,90,.35)';g.lineWidth=1;g.beginPath();for(let i=0;i<pts.length;i+=2){g.moveTo(rx,ry);g.lineTo(pts[i],pts[i+1])}g.stroke();
 g.strokeStyle='rgba(255,255,255,.55)';g.lineWidth=1.2;g.lineCap='round';g.beginPath();for(const r of ribs){g.moveTo(r[0],r[1]);g.lineTo(r[2],r[3])}g.stroke();
 P();g.strokeStyle='rgba(210,242,255,.85)';g.lineWidth=3;g.stroke();g.restore();
 P();g.lineJoin='miter';g.miterLimit=3;g.lineWidth=2.6;g.strokeStyle=FKO;g.stroke();g.lineJoin='round'}

/* ---------------- 4. Frostjaw Colossus (Legendary): an armoured prehistoric giant with jaws of ancient glacier ice ---------------- */
FISHART.colossus=(g,t,o)=>{const sw=fkSway(o,2.4,.1),fin=Math.sin(t*2.6)*.08,fx=o.flex||0,gl=o.glow||0,pu=.5+.5*Math.sin(t*1.5),open=.4+.07*Math.sin(t*1.1)+fx*.14*Math.max(0,Math.sin(t*7));
 g.save();g.translate(2,6);g.scale(.84,.84);g.rotate(-sw*.1);
 // body outline: a colossal blunt head, a deep armoured trunk tapering to the tail stalk; the upper jaw ends in a down-hooked ice fang
 const B=()=>fa7_path(g,['M',113,-2,'L',112,-30,'C',110,-50,98,-60,62,-62,'C',30,-66,0,-56,-24,-42,'C',-44,-30,-58,-17,-68,-9,'L',-68,9,'C',-56,14,-40,21,-20,28,'C',0,35,22,42,40,42,'C',52,42,60,38,62,30,'L',66,14,'Q',84,11,100,12,'L',110,12,'Q',113,10,113,-2,'Z']);
 // aura: a cold halo
 g.save();g.translate(14,-8);g.scale(1,.62);g.fillStyle=fa7_rgrad(g,0,0,30,130,[[0,'rgba(120,220,255,.2)'],[.55,'rgba(110,200,255,.09)'],[1,'rgba(110,200,255,0)']]);if(g.canvas!==FKSIL){g.beginPath();g.arc(0,0,130,0,TAU);g.fill()}g.restore();
 if(g.canvas!==FKSIL)fkGlow(g,66,-16,96,'#5ad8ff',.14+.08*pu+gl*.32);
 // a veil of aurora light hanging behind the giant, its curtains slowly rippling
 g.save();g.globalCompositeOperation='lighter';
 [[-104,58,0],[-84,80,1],[-62,66,2],[-40,90,0],[-18,72,1],[4,54,2]].forEach(([x,h,ci],i)=>{const c=['70,255,170','90,230,255','200,130,255'][ci],a=(.22+.08*Math.sin(t*1.1+i*1.7))*(1+gl*.8),w=11+4*Math.sin(i*2.3),top=-98;
  g.fillStyle=fa7_grad(g,0,top,0,top+h,[[0,`rgba(${c},0)`],[.18,`rgba(${c},${a})`],[.55,`rgba(${c},${a*.45})`],[1,`rgba(${c},0)`]]);
  g.beginPath();for(let k=0;k<=6;k++){const u=k/6,y=top+h*u,wx=Math.sin(t*.8+i*1.3+u*4)*5*u;k?g.lineTo(x-w*.5+wx,y):g.moveTo(x-w*.5+wx,y)}for(let k=6;k>=0;k--){const u=k/6,y=top+h*u,wx=Math.sin(t*.8+i*1.3+u*4+.9)*5*u;g.lineTo(x+w*.5+wx+3*u,y)}g.closePath();g.fill()});g.restore();
 // ice crystals trailing in its wake
 for(let i=0;i<18;i++){const p=(t*.22+i/18)%1,u=((i*7)%18)/17,x=-66-p*64+Math.sin(t+i)*2,y=-44+u*76+Math.sin(p*6+i)*5*p,sz=(1-p)*(1.8+(i%3));if(x<-134)continue;
  if(i%3===0)fa7_snow(g,x,y,sz*1.4,t*.6+i,'#e4f6ff',(1-p)*.85);else fkSpark(g,x,y,sz*1.5,i%2?'#bff0ff':'#ffffff',(1-p)*.9)}
 // powerful heterocercal tail: a towering upper lobe, frost-rimmed
 const finCol=(x0,y0,x1,y1)=>fa7_grad(g,x0,y0,x1,y1,[[0,'#0e2244'],[.55,'#1e4a80'],[1,'#7ac4f4']]);
 fa7_at(g,-64,0,sw,()=>{const T=()=>fa7_path(g,['M',8,-9,'C',-6,-16,-22,-32,-36,-52,'Q',-44,-62,-52,-74,'Q',-46,-52,-44,-36,'C',-42,-20,-37,-8,-31,0,'C',-35,8,-40,18,-50,34,'Q',-32,32,-18,18,'C',-8,10,0,8,8,9,'Z']);
  T();fkFill(g,finCol(8,0,-52,-60),2.8);
  fa7_ribs(g,T,6,0,[-50,-70,-46,-54,-42,-36,-38,-20,-33,-4,-40,16,-48,32],.35,'#040c20',1.2);
  fa7_finfx(g,T,6,0,'#bfe8ff',null,.9,0);
  g.save();T();g.clip();g.fillStyle=fa7_grad(g,-52,-74,-34,-34,[[0,'rgba(255,255,255,.8)'],[1,'rgba(255,255,255,0)']]);g.fillRect(-60,-78,40,50);g.restore();
  fa7_rime(g,T,.95,2.8);fa7_rim(g,T,'#bfe8ff',null,1,1.6);T();g.lineJoin='round';g.lineWidth=2.8;g.strokeStyle=FKO;g.stroke()});
 // fins behind the body: a shark-like first dorsal, a small second dorsal, pelvic and anal fins
 const dfin=(x,y,a,pp,ribs)=>fa7_at(g,x,y,a,()=>{const P=()=>fkPath(g,pp);P();let x0=1e9,x1=-1e9,y0=1e9,y1=-1e9;for(let i=0;i<pp.length;i+=2){x0=Math.min(x0,pp[i]);x1=Math.max(x1,pp[i]);y0=Math.min(y0,pp[i+1]);y1=Math.max(y1,pp[i+1])}
  const up=y0<-10;fkFill(g,up?finCol(0,y1,0,y0):finCol(0,y0,0,y1),2.6);
  fa7_ribs(g,P,0,0,ribs,.32,'#040c20',1.1);fa7_finfx(g,P,0,0,'#bfe8ff',null,.8,0);fa7_rime(g,P,.95,2.6);P();g.lineJoin='round';g.lineWidth=2.6;g.strokeStyle=FKO;g.stroke()});
 dfin(6,-54,fin*.3,[18,8,10,-8,0,-22,-10,-32,-16,-24,-22,-10,-30,6],[-10,-30,-10,-18,-18,-8]);
 dfin(-44,-24,fin*.4,[8,4,2,-8,-6,-15,-14,-11,-16,2],[-6,-13,-12,-8]);
 fa7_at(g,-38,22,-fin*.4,()=>fa7_platefin(g,[10,-2,4,8,-6,16,-12,12,-17,10,-16,-2],0,0,[[0,0,-7,13],[0,0,-13,9]]));
 fa7_at(g,6,38,-fin*.6,()=>fa7_platefin(g,[12,-4,6,10,-6,19,-14,16,-20,12,-20,-2],0,0,[[0,0,-4,16],[0,0,-12,15],[0,0,-16,8]]));
 // ---- body: midnight steel, armoured in overlapping frost-crusted bands ----
 B();fkFill(g,fa7_grad(g,0,-62,0,42,[[0,'#2a7890'],[.22,'#1c4a74'],[.5,'#0f2650'],[.78,'#132e5a'],[1,'#1e4c80']]),3.2);
 g.save();B();g.clip();
 // armour: domed, faceted glacier plates with a teal crown and violet underside, seams edged in frost and cold gold
 const bands=[34,8,-16,-38,-56];
 bands.forEach((bx,i)=>{const nx=i<bands.length-1?bands[i+1]:-82,mx=(bx+nx)/2,FE=(x,c)=>{c?g.lineTo(x-1,50):g.moveTo(x-1,50);g.bezierCurveTo(x+9,14,x+9,-34,x-3,-72)};
  const P=()=>{g.beginPath();FE(bx,0);g.lineTo(nx-16,-72);g.lineTo(nx-16,50);g.closePath()};
  P();g.fillStyle=fa7_grad(g,bx+6,0,nx,0,[[0,'rgba(2,8,30,.5)'],[.12,'rgba(90,170,220,.3)'],[.4,'rgba(60,140,200,.12)'],[.8,'rgba(6,16,50,.1)'],[1,'rgba(2,6,24,.6)']]);g.fill();
  g.save();P();g.clip();
  g.fillStyle=fa7_grad(g,0,-72,0,50,[[0,'rgba(90,230,210,.24)'],[.45,'rgba(90,230,210,0)'],[.7,'rgba(160,110,255,0)'],[1,'rgba(160,110,255,.22)']]);g.fillRect(nx-20,-72,bx-nx+24,122);
  // facets: a fan of planes from the crown of the dome, alternately lit and shaded
  const cx=mx+3,cy=-12,E=[bx+1,-66,bx+8,-30,bx+8,8,bx,44,nx-2,44,nx+6,8,nx+6,-30,nx-1,-66];
  for(let k=0;k<E.length;k+=2){const a=k+2<E.length?k+2:0;g.beginPath();g.moveTo(cx,cy);g.lineTo(E[k],E[k+1]);g.lineTo(E[a],E[a+1]);g.closePath();g.fillStyle=(k/2)%2?'rgba(255,255,255,.07)':'rgba(0,8,40,.14)';g.fill()}
  g.strokeStyle='rgba(180,230,255,.14)';g.lineWidth=1;g.beginPath();for(let k=0;k<E.length;k+=2){g.moveTo(cx,cy);g.lineTo(E[k],E[k+1])}g.stroke();
  g.fillStyle=fa7_rgrad(g,cx,cy,0,38,[[0,'rgba(160,220,255,.26)'],[1,'rgba(160,220,255,0)']]);g.fillRect(cx-40,cy-40,80,80);
  g.restore();
  // plate seam: dark groove, a bright frost lip and a thin cold-gold edge
  g.beginPath();FE(bx,0);g.strokeStyle='rgba(2,8,26,.95)';g.lineWidth=3;g.stroke();g.save();g.translate(-2.2,0);g.beginPath();FE(bx,0);g.strokeStyle='rgba(180,226,255,.75)';g.lineWidth=1.5;g.stroke();g.translate(4.4,0);g.beginPath();FE(bx,0);g.strokeStyle='rgba(255,224,150,.5)';g.lineWidth=1;g.stroke();g.restore();
  // icing snow along the top of each seam, with uneven drip lengths
  const fy=-52+i*6.5,ds=[1.35,.8,1.2,.7,1][i];g.save();g.translate(bx-5,fy);g.scale(1,ds);const SD=()=>fa7_fluff(g,[6,-8,4,4,0,14,-4,18,-8,8,-10,-4,-6,-12],1.8);SD();g.fillStyle=fa7_grad(g,0,-12,0,18,[[0,'#ffffff'],[.6,'#e8f6ff'],[1,'#a8d0f4']]);g.fill();g.strokeStyle='rgba(30,70,140,.55)';g.lineWidth=1/ds;g.stroke();g.restore()});
 // a slow aurora sheen drifting over the armour
 {const ax=Math.sin(t*.45)*50;g.globalAlpha=.16+gl*.1;g.fillStyle=fa7_grad(g,-80+ax,-40,30+ax,30,[[0,'rgba(90,255,200,0)'],[.3,'#5affc8'],[.55,'#7ad8ff'],[.8,'#c89aff'],[1,'rgba(200,154,255,0)']]);g.fillRect(-84,-72,120,124);g.globalAlpha=1}
 // frost-white rime blanket over the back, and snow dust
 g.fillStyle=fa7_grad(g,0,-66,0,-30,[[0,'rgba(240,250,255,.75)'],[.5,'rgba(220,240,255,.25)'],[1,'rgba(220,240,255,0)']]);g.fillRect(-80,-70,130,40);
 fa7_speck(g,B,-66,40,-62,-26,46,'#ffffff',.85,.9,17);
 fa7_speck(g,B,-66,40,-30,30,20,'#bfe4ff',.5,.7,23);
 g.restore();
 fkShade(g,B,10,44,'#030820',.55);
 // glacier shards: a jagged ridge of big crystals rising toward the head, with snow clumps packed on their shoulders
 fa7_shard(g,-34,-32,14,11,-4,t,3);fa7_shard(g,-24,-40,9,8,-3,t,7);
 fa7_shard(g,-12,-45,20,14,-4,t,2);fa7_shard(g,-2,-54,12,9,-3,t,6);
 fa7_shard(g,10,-55,27,18,-4,t,1);fa7_clump(g,15,-71,.65);
 fa7_shard(g,30,-58,34,22,-3,t,0);fa7_clump(g,36.8,-78,.75);fa7_clump(g,21.5,-65.5,.6);
 fa7_shard(g,42,-61,13,10,-2,t,5);
 // ---- the head: great faceted plates of ancient glacier ice ----
 const HB=[38,-70, 24,-38, 22,-6, 28,20, 40,50];
 const H=()=>fa7_path(g,['M',38,-70,'C',24,-38,22,-6,28,20,'C',31,34,36,44,40,50,'L',130,50,'L',130,-70,'Z']);
 g.save();B();g.clip();H();g.clip();
 g.fillStyle=fa7_grad(g,50,-62,92,30,[[0,'#f0fbff'],[.25,'#b0e2ff'],[.55,'#62acec'],[.8,'#2e6cc0'],[1,'#1a4692']]);g.fillRect(20,-70,110,120);
 // glacier facets: flat planes of ice, each a slightly different shade, edged with light
 const F=[[[40,-66,70,-66,58,-42,32,-44],'#ffffff',.38],[[70,-66,104,-50,84,-38,58,-42],'#e8f8ff',.22],[[104,-50,112,-14,92,-22,84,-38],'#b8e8ff',.18],
  [[32,-44,58,-42,52,-16,26,-14],'#2a6ac0',.22],[[58,-42,84,-38,92,-22,70,-12,52,-16],'#ffffff',.14],[[26,-14,52,-16,48,8,28,10],'#123a80',.3],
  [[52,-16,70,-12,66,12,48,8],'#4a9ae0',.25],[[70,-12,92,-22,112,-14,108,6,66,12],'#dff6ff',.2]];
 F.forEach(f=>{const p=f[0];fa7_poly(g,p);g.fillStyle=fa7_rgba(f[1],f[2]);g.fill();g.strokeStyle='rgba(255,255,255,.22)';g.lineWidth=1;g.stroke()});
 // depth: a bright core high on the brow and a deep blue heart below
 [[70,-48,26,'#ffffff',.45],[50,2,22,'#0e2c70',.45]].forEach(m=>{g.fillStyle=fa7_rgrad(g,m[0],m[1],0,m[2],[[0,fa7_rgba(m[3],m[4])],[1,fa7_rgba(m[3],0)]]);g.fillRect(m[0]-m[2],m[1]-m[2],m[2]*2,m[2]*2)});
 // packed snow-white glacier patches and deep blue crevasse veins
 [[[46,-60,60,-64,66,-56,58,-50,48,-52],.75],[[84,-52,96,-46,100,-38,92,-40,86,-46],.6],[[100,-30,108,-26,108,-18,102,-20],.5]].forEach(q=>{const P=()=>fa7_blob(g,q[0]);P();g.fillStyle=`rgba(250,253,255,${q[1]})`;g.fill();g.save();P();g.clip();g.translate(1,1.6);P();g.strokeStyle='rgba(120,180,240,.5)';g.lineWidth=1.6;g.stroke();g.restore()});
 g.strokeStyle='rgba(20,60,150,.35)';g.lineWidth=2.2;g.beginPath();g.moveTo(34,-26);g.quadraticCurveTo(48,-30,62,-24);g.moveTo(70,-4);g.quadraticCurveTo(84,-8,102,-4);g.stroke();
 // glacial strata
 g.strokeStyle='rgba(255,255,255,.15)';g.lineWidth=.9;g.beginPath();for(let i=0;i<6;i++){const y=-52+i*12;g.moveTo(26,y+9);g.quadraticCurveTo(70,y-3,114,y+3)}g.stroke();
 // aurora light drifting through the ice
 [['#5affc8',0],['#7ad8ff',40],['#c89aff',80]].forEach(([c,ph])=>{const bx=20+((t*9+ph)%120),hw=12;g.globalAlpha=.3+gl*.1;g.fillStyle=fa7_grad(g,bx-hw,0,bx+hw,0,[[0,fa7_rgba(c,0)],[.5,c],[1,fa7_rgba(c,0)]]);g.beginPath();g.moveTo(bx-hw+6,-70);g.lineTo(bx+hw+6,-70);g.lineTo(bx+hw-6,50);g.lineTo(bx-hw-6,50);g.closePath();g.fill()});g.globalAlpha=1;
 // frost rime crusting the crown of the skull
 g.translate(0,2);B();g.strokeStyle='rgba(255,255,255,.9)';g.lineWidth=4;g.setLineDash([2,2.6]);g.stroke();g.setLineDash([]);
 g.restore();
 // head/body boundary: a crisp edge with a frost lip
 g.save();B();g.clip();g.beginPath();g.moveTo(38,-70);g.bezierCurveTo(24,-38,22,-6,28,20);g.bezierCurveTo(31,34,36,44,40,50);g.lineWidth=3.2;g.strokeStyle=FKO;g.stroke();
 g.translate(2.6,0);g.strokeStyle='rgba(255,255,255,.85)';g.lineWidth=1.8;g.stroke();g.translate(-5.4,0);g.strokeStyle='rgba(255,224,150,.6)';g.lineWidth=1.1;g.stroke();g.restore();
 // plate sutures: cranial shield, cheek plate and gill cover
 const seam=(pp,w)=>{g.save();B();g.clip();g.beginPath();g.moveTo(pp[0],pp[1]);for(let i=2;i<pp.length;i+=4)g.quadraticCurveTo(pp[i],pp[i+1],pp[i+2],pp[i+3]);g.lineCap='round';
  g.strokeStyle='rgba(6,16,50,.85)';g.lineWidth=w||2.6;g.stroke();g.translate(-1.2,-1.5);g.strokeStyle='rgba(255,255,255,.75)';g.lineWidth=1.2;g.stroke();g.translate(2.6,3.2);g.strokeStyle='rgba(255,224,150,.6)';g.lineWidth=1;g.stroke();g.restore()};
 seam([36,-34,58,-46,82,-42,98,-38,108,-24]);
 seam([44,-6,56,-10,62,4,64,9,66,14]);
 seam([44,-6,38,-20,42,-34]);
 // glowing cracks branching through the ice, pulsing in sequence
 const cr=[[34,-28,24,-30,16,-34,6,-30,-4,-35,-14,-31],[32,2,22,0,12,4,2,-2,-10,2],[50,-68,53,-58,52,-50,57,-38,58,-30],[53,-56,62,-52,70,-54],[57,-40,50,-34],[96,-54,93,-46,94,-38],[28,-2,38,-6,46,-14,50,-24],[46,-14,52,-12],[48,10,54,6,58,14,57,24],[100,-12,96,-6,97,2],[74,-64,75,-56,72,-50]];
 g.save();B();g.clip();cr.forEach((c,i)=>fa7_crack(g,c,(.4+.6*Math.max(0,Math.sin(t*2-i*.9)))*(1+gl*.9),1.3));g.restore();
 fa7_rim(g,B,'#cfeeff','#6aa8ff',1,2.2);
 fa7_gloss(g,B,102,-40,84,-60,48,-62,2.4,.85);
 B();g.lineJoin='round';g.lineWidth=3.4;g.strokeStyle=FKO;g.stroke();
 // ---- the jaws: a glowing gullet, an icy upper fang and a massive shearing lower jaw ----
 const oc=Math.cos(open),os=Math.sin(open),jx=(x,y)=>[66+x*oc-y*os,15+x*os+y*oc];
 {const a=jx(30,-5),b=jx(39,-3);g.save();g.beginPath();g.moveTo(66,14);g.quadraticCurveTo(84,11,100,12);g.lineTo(110,12);g.lineTo(b[0]+3,b[1]);g.lineTo(a[0],a[1]);g.lineTo(66,18);g.closePath();
  g.fillStyle=fa7_grad(g,68,10,104,26,[[0,'#040a20'],[.55,'#0a2252'],[1,'#164e8e']]);g.fill();
  g.save();g.clip();g.globalCompositeOperation='lighter';g.fillStyle=fa7_rgrad(g,92,18,0,22,[[0,`rgba(150,244,255,${.6+.3*pu+gl*.3})`],[1,'rgba(80,200,255,0)']]);g.fillRect(66,-4,48,46);g.restore();
  // little ice serrations along the upper jaw edge
  g.beginPath();for(let k=0;k<5;k++){const x=72+k*5.5,y=12.2-k*.3;g.moveTo(x,y);g.lineTo(x+1.6,y+4.2+(k%2));g.lineTo(x+3.2,y)}g.fillStyle='#e8f8ff';g.fill();g.strokeStyle='rgba(10,30,80,.6)';g.lineWidth=.8;g.stroke();g.restore()}
 fa7_at(g,66,15,open,()=>{const J=()=>fa7_path(g,['M',0,-2,'Q',18,-5,32,-4,'L',40,-4,'L',42,10,'L',34,24,'C',20,30,4,32,-10,28,'Q',-7,12,0,-2,'Z']);
  J();fkFill(g,fa7_grad(g,0,-14,10,30,[[0,'#f0fbff'],[.3,'#a4daff'],[.7,'#3a7ad0'],[1,'#1a4692']]),3.2);
  g.save();J();g.clip();
  fa7_poly(g,[-8,-4,22,-4,16,14,-8,18]);g.fillStyle='rgba(255,255,255,.14)';g.fill();fa7_poly(g,[16,14,42,6,34,30,8,30]);g.fillStyle='rgba(10,30,90,.22)';g.fill();
  g.strokeStyle='rgba(255,255,255,.26)';g.lineWidth=.9;g.beginPath();for(let i=0;i<4;i++){const y=3+i*6;g.moveTo(-6,y+4);g.quadraticCurveTo(16,y-2,42,y)}g.stroke();
  g.globalAlpha=.24+gl*.15;g.fillStyle=fa7_grad(g,-10+Math.sin(t*.7)*22,0,44,20,[[0,'#5affc8'],[.5,'#7ad8ff'],[1,'#c89aff']]);g.fillRect(-10,-16,62,48);g.globalAlpha=1;
  fa7_crack(g,[4,26,9,18,11,10,17,4],(.45+.55*Math.max(0,Math.sin(t*2-3.3)))*(1+gl*.9),1.5);
  fa7_crack(g,[30,20,27,12,29,5],(.45+.55*Math.max(0,Math.sin(t*2-4.4)))*(1+gl*.9),1.3);
  g.translate(-1.4,-1.6);J();g.strokeStyle='rgba(255,255,255,.75)';g.lineWidth=1.6;g.stroke();g.restore();
  // small serrations along the lower jaw
  g.beginPath();for(let k=0;k<4;k++){const x=6+k*6;g.moveTo(x,-3.4);g.lineTo(x+1.6,-7.6-(k%2));g.lineTo(x+3.2,-3.6)}g.fillStyle='#e8f8ff';g.fill();g.strokeStyle='rgba(10,30,80,.6)';g.lineWidth=.8;g.stroke();
  J();g.lineJoin='round';g.lineWidth=3.2;g.strokeStyle=FKO;g.stroke()});
 // ---- the great ice fangs: one hooked down from the upper jaw, one rising from the lower jaw, crossing like shears ----
 const fang=(pp,hx,hy,tx,ty)=>{const P=()=>fa7_path(g,pp);g.globalAlpha=.92;P();g.fillStyle=fa7_grad(g,hx,hy,tx,ty,[[0,'#2a6ec8'],[.3,'#7ec2f8'],[.7,'#dff4ff'],[1,'#ffffff']]);g.fill();g.globalAlpha=1;
  g.save();P();g.clip();g.beginPath();g.moveTo(hx-2.5,hy+(ty-hy)*.08);g.quadraticCurveTo(hx-3+(tx-hx)*.5,hy+(ty-hy)*.5,tx-.6,ty);g.strokeStyle='rgba(255,255,255,.9)';g.lineWidth=1.5;g.lineCap='round';g.stroke();
  g.fillStyle=fa7_rgrad(g,tx,ty,0,9,[[0,'rgba(255,255,255,.95)'],[1,'rgba(255,255,255,0)']]);g.fillRect(tx-9,ty-9,18,18);g.restore();
  P();g.lineJoin='round';g.lineWidth=2.4;g.strokeStyle=FKO;g.stroke()};
 fa7_at(g,66,15,open,()=>fang(['M',24,-3,'Q',27,-17,38,-28,'Q',38,-14,35,-3,'Z'],30,-3,38,-28));
 fang(['M',102,11,'Q',101,24,106,35,'Q',112,24,112.5,11,'Z'],107,11,106,35);
 // near pectoral: a broad armoured paddle with frosted edge
 fa7_at(g,32,24,.2+fin,()=>{const pp=[4,-5,-8,-9,-26,-4,-40,8,-44,16,-30,16,-16,12,-4,8,4,5],P=()=>fkPath(g,pp);fkFin(g,pp,'#7ac4f4','#0e2244',null,2.6);
  fa7_ribs(g,P,2,0,[-40,6,-42,13,-30,15,-18,12],.32,'#040c20',1.1);fa7_finfx(g,P,2,0,'#bfe8ff',null,.8,0);fa7_rime(g,P,.95,2.6);P();g.lineJoin='round';g.lineWidth=2.6;g.strokeStyle=FKO;g.stroke()});
 // the eye: a fierce glacier-blue eye glowing under a heavy slanted ice brow
 const ex=80,ey=-24,er=10.5;
 fkGlow(g,ex,ey,26,'#6ae8ff',.25+.15*pu+gl*.35);
 fa7_eye(g,ex,ey,er,'#16c8ff',.6);
 {const bl=fa7_blink(t,2.7),dy=bl*er*1.4;g.save();g.beginPath();g.arc(ex,ey,er,0,TAU);g.clip();g.beginPath();g.moveTo(ex-er-2,ey-er-4);g.lineTo(ex+er+2,ey-er-4);g.lineTo(ex+er+2,ey-er*.05+dy);g.lineTo(ex-er-2,ey-er*.62+dy);g.closePath();
  g.fillStyle=fa7_grad(g,0,ey-er,0,ey,[[0,'#8ac8f4'],[1,'#3a7ad0']]);g.fill();g.beginPath();g.moveTo(ex+er+2,ey-er*.05+dy);g.lineTo(ex-er-2,ey-er*.62+dy);g.strokeStyle=FKO;g.lineWidth=2.6;g.stroke();g.restore();
  g.beginPath();g.arc(ex,ey,er,0,TAU);g.strokeStyle=FKO;g.lineWidth=2.6;g.stroke();
  // cold-gold eye ring
  g.beginPath();g.arc(ex,ey,er+2.9,0,TAU);g.strokeStyle='rgba(255,222,150,.9)';g.lineWidth=2;g.stroke();g.beginPath();g.arc(ex,ey,er+2.9,Math.PI*1.05,Math.PI*1.6);g.strokeStyle='rgba(255,250,225,.95)';g.lineWidth=1;g.stroke()}
 {const BR=()=>fa7_path(g,['M',62,-44,'Q',80,-46,98,-30,'L',96,-24,'Q',80,-34,64,-36,'Z']);BR();fkFill(g,fa7_grad(g,0,-46,0,-24,[[0,'#ffffff'],[.55,'#b4e2ff'],[1,'#4a8ad8']]),2.8);
  g.beginPath();g.moveTo(66,-42);g.quadraticCurveTo(80,-43,94,-31);g.strokeStyle='rgba(255,255,255,.95)';g.lineWidth=1.4;g.stroke()}
 // ---- cold breath curling from the jaws ----
 for(let k=0;k<3;k++){const p=(t*.3+k/3)%1;fa7_wisp(g,118+k,24-k*8,p,1,k%2?1:-1)}
 // sparkles on the ice
 [[100,-50,5.5],[58,-70,4.4],[114,26,3.6],[-22,-52,3.8]].forEach(([x,y,r],i)=>{const k=fa7_tw(t,i*1.6,2.2);fkSpark(g,x,y,r*(.6+.6*k)*(1+gl*.5),'#ffffff',.35+.65*k)});
 fa7_spec(g,74,-54,1.1,.95);fa7_spec(g,-8,-48,.8,.7);
 fa7_catch(g,o,'#bfeeff',1.4);g.restore()};

/* update 7: when drawn as an undiscovered silhouette (o.sil), these fish skip additive light (auras, glows, rays), so the
   journal shows a clean solid outline instead of a hazy blob. Normal drawing is untouched. */
(()=>{const P=new WeakMap(),wrap=c=>{let p=P.get(c);if(!p){const F=new Map();p=new Proxy(c,{get(t,k){const v=t[k];if(typeof v!=='function')return v;let f=F.get(k);
  if(!f){f=(k==='fill'||k==='fillRect'||k==='stroke'||k==='strokeRect'||k==='drawImage')?function(){if(t.globalCompositeOperation==='lighter')return;return v.apply(t,arguments)}:v.bind(t);F.set(k,f)}return f},
  set(t,k,v){t[k]=v;return true}});P.set(c,p)}return p};
 ['herring','sculpin','narwhal','colossus'].forEach(id=>{const f=FISHART[id];if(f)FISHART[id]=(g,t,o)=>f(typeof FKSIL!=='undefined'&&FKSIL&&g.canvas===FKSIL?wrap(g):g,t,o)})})();
