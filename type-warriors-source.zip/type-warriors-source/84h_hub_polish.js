/* ---------- crates menu polish ----------
   A moonlit graveyard scene lives behind the Graveyard Crate banner, the banner gets a flowing border and a big pulsing Open button,
   and the regular crates become lit pedestal cards with hover lift. Everything is drawn live on canvas, so no extra assets. */
function hwBgScene(g,w,h,t){
 g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,w,h);
 const sky=g.createLinearGradient(0,0,0,h);sky.addColorStop(0,'#0b3a36');sky.addColorStop(.5,'#1b1448');sky.addColorStop(1,'#0c0820');g.fillStyle=sky;g.fillRect(0,0,w,h);
 /* stars */
 for(let i=0;i<46;i++){const x=(i*173.3)%w,y=(i*61.7)%(h*.55),tw=.35+.65*Math.abs(Math.sin(t*1.3+i));g.globalAlpha=tw*.7;g.fillStyle='#e8fff4';g.fillRect(x,y,i%5?1.2:2,i%5?1.2:2)}g.globalAlpha=1;
 /* moon with a breathing halo */
 const mx=190,my=118,pu=.85+.15*Math.sin(t*1.4);
 g.globalCompositeOperation='lighter';glow(g,mx,my,260*pu,'#5affb040');glow(g,mx,my,130,'#bfffe044');g.globalCompositeOperation='source-over';
 g.fillStyle='#f1ffe6';g.beginPath();g.arc(mx,my,64,0,TAU);g.fill();g.fillStyle='#cfe6c6';for(const [dx,dy,r] of [[-20,-10,14],[16,14,11],[12,-24,8]]){g.beginPath();g.arc(mx+dx,my+dy,r,0,TAU);g.fill()}
 /* rolling hills and tombstones */
 g.fillStyle='#0b1a18';g.beginPath();g.moveTo(0,h);g.lineTo(0,h-92);for(let x=0;x<=w;x+=40)g.lineTo(x,h-86-Math.sin(x*.012+1)*16-Math.sin(x*.031)*6);g.lineTo(w,h);g.fill();
 g.fillStyle='#070e0d';for(const [x,hh,ww] of [[28,48,22],[74,36,18],[w-70,50,24],[w-122,34,18],[w-30,40,20],[132,28,16]]){g.beginPath();g.roundRect(x-ww/2,h-30-hh,ww,hh+30,[ww/2,ww/2,0,0]);g.fill();g.fillStyle='#16322b';g.fillRect(x-1,h-24-hh*.7,2,hh*.35);g.fillRect(x-5,h-18-hh*.62,10,2);g.fillStyle='#070e0d'}
 /* gnarled trees on both edges */
 g.strokeStyle='#050b0a';g.lineCap='round';
 const tree=(x,y,L,a,d)=>{if(d>5||L<5)return;const x2=x+Math.cos(a)*L,y2=y+Math.sin(a)*L;g.lineWidth=Math.max(1,(6-d)*1.7);g.beginPath();g.moveTo(x,y);g.lineTo(x2,y2);g.stroke();const sw=Math.sin(t*.8+d)*.04;tree(x2,y2,L*.72,a-.5+sw,d+1);tree(x2,y2,L*.7,a+.45+sw,d+1)};
 tree(44,h-70,64,-1.35,0);tree(w-32,h-66,58,-1.8,0);
 /* drifting fog */
 g.globalCompositeOperation='lighter';
 for(let i=0;i<5;i++){const x=((t*14+i*260)%(w+400))-200,y=h-58+Math.sin(t*.6+i)*10;glow(g,x,y,200,'#5affb01c')}
 /* rising wisps */
 for(let i=0;i<14;i++){const k=(t*.11+i*.0714)%1,x=(i*97.7)%w+Math.sin(t*1.2+i*2)*18,y=h-60-k*(h*.8),a=Math.sin(k*Math.PI);g.globalAlpha=a*.8;glow(g,x,y,14,'#7affc8aa');g.fillStyle='#e8fff4';g.beginPath();g.arc(x,y,1.8,0,TAU);g.fill()}g.globalAlpha=1;g.globalCompositeOperation='source-over';
 /* bats crossing the moon */
 g.fillStyle='#04080a';
 for(let i=0;i<4;i++){const k=((t*.045+i*.27)%1.2)-.1,x=w*(1-k)+Math.sin(t+i)*20,y=60+i*36+Math.sin(t*2.2+i*3)*16,f=Math.sin(t*14+i*2)*.7,s=.8+i*.1;
  g.save();g.translate(x,y);g.scale(s,s);g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(-10,-9-f*8,-22,-2+f*5);g.quadraticCurveTo(-13,-1,-9,4);g.quadraticCurveTo(-4,0,0,5);g.quadraticCurveTo(4,0,9,4);g.quadraticCurveTo(13,-1,22,-2+f*5);g.quadraticCurveTo(10,-9-f*8,0,0);g.fill();g.restore()}
 /* keep the middle readable */
 const sc=g.createLinearGradient(0,0,w,0);sc.addColorStop(0,'rgba(6,4,16,0)');sc.addColorStop(.3,'rgba(6,4,16,.34)');sc.addColorStop(.72,'rgba(6,4,16,.34)');sc.addColorStop(1,'rgba(6,4,16,.05)');g.fillStyle=sc;g.fillRect(0,0,w,h)}
function hwDecorate(){
 const hero=ov.querySelector('.hwb'),hub=ov.querySelector('.chub'),h2=ov.querySelector('h2');if(h2)h2.classList.add('chh');
 if(hero){const cv=document.createElement('canvas');cv.width=1060;cv.height=500;cv.className='hwbg';hero.prepend(cv);const g=cv.getContext('2d');
  LIVE.push({cv,fn:t=>{try{hwBgScene(g,cv.width,cv.height,t)}catch(e){}},slow:2});
  const nh=P.hcr||0,l=hero.querySelector('.hwbl');const lc=l&&l.querySelector('canvas');if(lc){lc.width=440;lc.height=300}
  if(l&&nh){const b=document.createElement('span');b.className='hwcnt';b.textContent=nh;l.appendChild(b)}
  if(nh)hero.classList.add('glowing');
  const lab=document.createElement('div');lab.className='chsec';lab.innerHTML='<i></i><span>Seasonal event</span><i></i>';hero.before(lab)}
 if(hub){const lab=document.createElement('div');lab.className='chsec';lab.innerHTML='<i></i><span>Everyday crates</span><i></i>';hub.before(lab)}}
{const ch0=crateHub;crateHub=function(){ch0.apply(this,arguments);hwDecorate()}}
